v2117 후보 전달 권한 단일화
- Strategy만 candidate_commit_spine과 잠금파일 기록
- Paper/Review는 각자 소유 ack 디렉터리에만 기록
- Main은 읽기 전용
- 구조선·후보 기준·진입·청산 변경 없음
- 자동매수 OFF
