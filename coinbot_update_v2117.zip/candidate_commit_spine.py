#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Canonical candidate commit spine v2117.

Strategy is the only writer inside the immutable commit spine. Paper and Review
never touch the Strategy-owned lock or commit directories; each writes an ack
into its own service-owned directory under BASE_DIR. Main is read-only.
"""
from __future__ import annotations

import contextlib
import fcntl
import hashlib
import json
import os
import shutil
import stat
import time
from pathlib import Path
from typing import Any, Callable, Dict, Iterable, List, Mapping, Optional, Tuple

SCHEMA = "candidate_commit_spine_v2117"
ROOT_DIRNAME = "candidate_commit_spine"
CURRENT_POINTER = "candidate_commit_current.json"
COMPLETED_POINTER = "candidate_commit_completed.json"
STATUS_FILE = "candidate_commit_spine_status.json"
CLEANUP_FILE = "candidate_commit_cleanup_status.json"
STRATEGY_LOCK_FILE = "strategy_candidate_commit.lock"
OLD_SHARED_LOCK_FILE = "candidate_commit_spine.lock"
KEEP_COMMITS = 4
KEEP_ACKS = 12
ACK_DIRS = {"paper": "paper_candidate_commit_acks", "review": "review_candidate_commit_acks"}

LEGACY_STATE_FILES = (
    "unified_structure_contract_status_v2111.json", "unified_structure_contract_status_v2113.json",
    "unified_structure_contract_status_v2114.json", "unified_structure_contract_status_v2115.json",
    "strategy_candidate_contract_snapshot_v2113.json", "strategy_candidate_contract_snapshot_v2114.json",
    "strategy_candidate_contract_snapshot_v2115.json", "strategy_unified_contract_cycle_proof_v2111.json",
    "strategy_unified_contract_cycle_proof_v2113.json", "strategy_unified_contract_cycle_proof_v2114.json",
    "strategy_unified_contract_cycle_proof_v2115.json", "strategy_candidate_transport_status_v2114.json",
    "strategy_candidate_transport_status_v2115.json", "strategy_handoff_stage_status_v2115.json",
    "strategy_unified_contract_boot_v2111.json", "strategy_unified_contract_boot_v2113.json",
    "strategy_unified_contract_boot_v2114.json", "strategy_unified_contract_boot_v2115.json",
    "review_unified_structure_status_v2111.json", "review_unified_structure_status_v2113.json",
    "review_unified_structure_status_v2114.json", "review_unified_structure_status_v2115.json",
    "review_snapshot_writer_status_v2111.json", "review_snapshot_writer_status_v2113.json",
    "review_snapshot_writer_status_v2114.json", "review_snapshot_writer_status_v2115.json",
    "review_snapshot_boot_v2111.json", "review_snapshot_boot_v2113.json",
    "review_snapshot_boot_v2114.json", "review_snapshot_boot_v2115.json",
    "paper_unified_contract_owner_status_v2111.json", "paper_unified_contract_owner_status_v2112.json",
    "paper_unified_contract_owner_status_v2113.json", "paper_unified_contract_owner_status_v2114.json",
    "paper_unified_contract_owner_status_v2115.json",
    # v2116 transport/operator state only. Core ledgers are never listed here.
    "candidate_commit_strategy_status_v2116.json", "candidate_commit_strategy_boot_v2116.json",
    "candidate_commit_paper_status_v2116.json", "candidate_commit_review_status_v2116.json",
    "candidate_commit_review_boot_v2116.json",
)

LEGACY_CODE_FILES = (
    "coinbot_main_v2_13_2093.py", "coinbot_main_v2_13_2094.py", "coinbot_main_v2_13_2095.py",
    "coinbot_main_v2_13_2096.py", "coinbot_main_v2_13_2097.py", "coinbot_main_v2_13_2098.py",
    "paper_bot_v2.064.py", "paper_bot_v2.065.py", "paper_bot_v2.066.py", "paper_bot_v2.067.py",
    "paper_bot_v2.068.py", "paper_bot_v2.069.py",
    "strategy_worker_v2.031.py", "strategy_worker_v2.032.py", "strategy_worker_v2.033.py",
    "strategy_worker_v2.034.py", "strategy_worker_v2.035.py",
    "review_worker_v2.040.py", "review_worker_v2.041.py", "review_worker_v2.042.py",
    "review_worker_v2.043.py", "review_worker_v2.044.py",
)


def _json_default(value: Any) -> Any:
    return str(value) if isinstance(value, Path) else str(value)


def _json_bytes(obj: Any) -> bytes:
    return json.dumps(obj, ensure_ascii=False, separators=(",", ":"), default=_json_default).encode("utf-8")


def _atomic_write_bytes(path: Path, payload: bytes, mode: int = 0o644) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    tmp = path.with_name(path.name + f".tmp.{os.getpid()}.{time.time_ns()}")
    with tmp.open("wb") as handle:
        handle.write(payload)
        handle.flush()
        os.fsync(handle.fileno())
    os.chmod(tmp, mode)
    os.replace(tmp, path)


def atomic_write_json(path: Path, obj: Any) -> None:
    _atomic_write_bytes(path, _json_bytes(obj))


def atomic_write_jsonl(path: Path, rows: Iterable[Mapping[str, Any]]) -> Tuple[int, int, int]:
    path.parent.mkdir(parents=True, exist_ok=True)
    tmp = path.with_name(path.name + f".tmp.{os.getpid()}.{time.time_ns()}")
    count = total = max_row = 0
    with tmp.open("wb") as handle:
        for row in rows:
            line = _json_bytes(dict(row)) + b"\n"
            handle.write(line)
            count += 1
            total += len(line)
            max_row = max(max_row, len(line) - 1)
        handle.flush()
        os.fsync(handle.fileno())
    os.chmod(tmp, 0o644)
    os.replace(tmp, path)
    return count, total, max_row


def read_json(path: Path, default: Any = None) -> Any:
    try:
        if not path.is_file():
            return default
        return json.loads(path.read_text(encoding="utf-8", errors="strict"))
    except (OSError, json.JSONDecodeError, UnicodeError):
        return default


def read_jsonl(path: Path, limit: Optional[int] = None) -> List[Dict[str, Any]]:
    rows: List[Dict[str, Any]] = []
    try:
        with path.open("r", encoding="utf-8") as handle:
            for line in handle:
                line = line.strip()
                if not line:
                    continue
                try:
                    obj = json.loads(line)
                except json.JSONDecodeError:
                    continue
                if isinstance(obj, dict):
                    rows.append(obj)
                    if limit is not None and len(rows) >= limit:
                        break
    except OSError:
        pass
    return rows


def _root(base_dir: Path) -> Path:
    return Path(base_dir) / ROOT_DIRNAME


def _commit_dir(base_dir: Path, commit_id: str) -> Path:
    return _root(base_dir) / "commits" / str(commit_id)


def _ack_dir(base_dir: Path, role: str) -> Path:
    if role not in ACK_DIRS:
        raise ValueError("role must be paper or review")
    return Path(base_dir) / ACK_DIRS[role]


def _ack_path(base_dir: Path, role: str, commit_id: str) -> Path:
    return _ack_dir(base_dir, role) / f"{commit_id}.json"


def _contract(row: Mapping[str, Any]) -> Dict[str, Any]:
    value = row.get("unified_structure_contract_v2110")
    return dict(value) if isinstance(value, dict) else {}


def _stage(row: Mapping[str, Any]) -> str:
    for key in ("s_stage", "candidate_stage", "candidate_grade", "stage", "grade",
                "selected_s_stage_v510", "candidate_stage_v510", "final_stage_v510",
                "s_grade", "candidate_final_grade"):
        value = str(row.get(key) or "").upper().strip()
        if value in {"S1", "S2", "S3"}:
            return value
    return "S3"


def _counts(rows: Iterable[Mapping[str, Any]]) -> Dict[str, Any]:
    data = [r for r in rows if isinstance(r, Mapping)]
    stages = {"S1": 0, "S2": 0, "S3": 0}
    contracts = executable = 0
    for row in data:
        stages[_stage(row)] += 1
        contract = _contract(row)
        if contract:
            contracts += 1
            executable += int(str(contract.get("final_state") or "").upper() == "EXECUTABLE")
    return {
        "row_count": len(data), "contract_count": contracts,
        "contract_missing": max(0, len(data) - contracts),
        "coverage_pct": round(contracts / len(data) * 100.0, 2) if data else 100.0,
        "stage_counts": stages, "executable_contract_count": executable,
    }


@contextlib.contextmanager
def _strategy_lock(base_dir: Path):
    """Strategy-only lock. Paper and Review never open this file."""
    root = _root(base_dir)
    root.mkdir(parents=True, exist_ok=True)
    os.chmod(root, 0o755)
    path = root / STRATEGY_LOCK_FILE
    with path.open("a+b") as handle:
        try:
            os.chmod(path, 0o600)
        except OSError:
            pass
        fcntl.flock(handle.fileno(), fcntl.LOCK_EX)
        try:
            yield
        finally:
            fcntl.flock(handle.fileno(), fcntl.LOCK_UN)


def _make_commit_readable(commit_dir: Path) -> None:
    for directory in (commit_dir.parent.parent, commit_dir.parent, commit_dir):
        try:
            os.chmod(directory, 0o755)
        except OSError:
            pass
    for path in commit_dir.rglob("*"):
        try:
            os.chmod(path, 0o755 if path.is_dir() else 0o644)
        except OSError:
            pass


def read_ack(base_dir: Path, role: str, commit_id: str) -> Dict[str, Any]:
    obj = read_json(_ack_path(Path(base_dir), role, str(commit_id or "")), {})
    return obj if isinstance(obj, dict) else {}


def _ack_valid(ack: Mapping[str, Any], manifest: Mapping[str, Any], role: str) -> bool:
    return bool(
        isinstance(ack, Mapping) and isinstance(manifest, Mapping)
        and ack.get("role") == role and ack.get("state") == "PASS"
        and str(ack.get("candidate_commit_id") or "") == str(manifest.get("candidate_commit_id") or "")
        and str(ack.get("cycle_id") or "") == str(manifest.get("cycle_id") or "")
    )


def read_pointer(base_dir: Path, *, completed: bool = False) -> Dict[str, Any]:
    obj = read_json(Path(base_dir) / (COMPLETED_POINTER if completed else CURRENT_POINTER), {})
    return obj if isinstance(obj, dict) else {}


def _read_commit_by_id(base_dir: Path, commit_id: str, pointer: Optional[Dict[str, Any]] = None) -> Dict[str, Any]:
    selected = str(commit_id or "").strip()
    if not selected:
        return {"pointer": pointer or {}, "manifest": {}, "candidates": [], "hold": {}, "paper_ack": {}, "review_ack": {}}
    commit_dir = _commit_dir(Path(base_dir), selected)
    manifest = read_json(commit_dir / "manifest.json", {}) or {}
    hold = read_json(commit_dir / "s1_hold.json", {}) or {}
    return {
        "pointer": pointer or {}, "manifest": manifest if isinstance(manifest, dict) else {},
        "candidates": read_jsonl(commit_dir / "candidates.jsonl"),
        "hold": hold if isinstance(hold, dict) else {},
        "paper_ack": read_ack(base_dir, "paper", selected),
        "review_ack": read_ack(base_dir, "review", selected),
        "commit_dir": str(commit_dir),
    }


def _virtual_completed_pointer(base_dir: Path) -> Dict[str, Any]:
    current = read_pointer(base_dir)
    commit_id = str(current.get("candidate_commit_id") or "")
    if not commit_id:
        return {}
    commit = _read_commit_by_id(base_dir, commit_id, current)
    manifest = commit.get("manifest") if isinstance(commit.get("manifest"), dict) else {}
    paper = commit.get("paper_ack") if isinstance(commit.get("paper_ack"), dict) else {}
    review = commit.get("review_ack") if isinstance(commit.get("review_ack"), dict) else {}
    if not (_ack_valid(paper, manifest, "paper") and _ack_valid(review, manifest, "review")):
        return {}
    return {
        "schema": "candidate_commit_completed_v2117", "version": manifest.get("version"),
        "build": manifest.get("build"), "updated_ts": max(float(paper.get("updated_ts") or 0), float(review.get("updated_ts") or 0)),
        "commit_created_ts": manifest.get("created_ts"), "candidate_commit_id": commit_id,
        "cycle_id": manifest.get("cycle_id"), "candidate_count": manifest.get("candidate_count"),
        "hold_count": (manifest.get("hold_counts") or {}).get("row_count") if isinstance(manifest.get("hold_counts"), dict) else 0,
        "paper_ack_ts": paper.get("updated_ts"), "review_ack_ts": review.get("updated_ts"),
        "state": "PASS", "virtual_from_service_acks": True, "auto_buy": False,
    }


def read_commit(base_dir: Path, commit_id: Optional[str] = None, *, completed: bool = False) -> Dict[str, Any]:
    base_dir = Path(base_dir)
    pointer = read_pointer(base_dir, completed=completed)
    if completed:
        virtual = _virtual_completed_pointer(base_dir)
        persisted_ts = float(pointer.get("commit_created_ts") or 0.0) if pointer else 0.0
        virtual_ts = float(virtual.get("commit_created_ts") or 0.0) if virtual else 0.0
        if virtual_ts >= persisted_ts and virtual:
            pointer = virtual
    selected = str(commit_id or pointer.get("candidate_commit_id") or "").strip()
    return _read_commit_by_id(base_dir, selected, pointer)


def validate_commit(base_dir: Path, commit_id: str) -> Dict[str, Any]:
    commit = _read_commit_by_id(Path(base_dir), str(commit_id), {})
    manifest = commit.get("manifest") if isinstance(commit.get("manifest"), dict) else {}
    hold = commit.get("hold") if isinstance(commit.get("hold"), dict) else {}
    rows = commit.get("candidates") if isinstance(commit.get("candidates"), list) else []
    errors: List[str] = []
    if manifest.get("candidate_commit_id") != commit_id:
        errors.append("manifest identity mismatch")
    if int(manifest.get("candidate_count") or 0) != len(rows):
        errors.append(f"candidate count {manifest.get('candidate_count')}!={len(rows)}")
    hold_rows = hold.get("rows") if isinstance(hold.get("rows"), list) else []
    if int(hold.get("row_count") or 0) != len(hold_rows):
        errors.append(f"hold count {hold.get('row_count')}!={len(hold_rows)}")
    cycle_id = str(manifest.get("cycle_id") or "")
    for label, data in (("candidate", rows), ("hold", hold_rows)):
        for idx, row in enumerate(data):
            if not isinstance(row, dict):
                errors.append(f"{label}[{idx}] not dict")
                break
            if str(row.get("candidate_commit_id_v2117") or "") != commit_id:
                errors.append(f"{label}[{idx}] commit mismatch")
                break
            if str(row.get("candidate_pipeline_cycle_id_v1150") or "") != cycle_id:
                errors.append(f"{label}[{idx}] cycle mismatch")
                break
    return {"state": "PASS" if not errors else "CHECK", "errors": errors,
            "candidate_count": len(rows), "hold_count": len(hold_rows),
            "cycle_id": cycle_id or None, "candidate_commit_id": commit_id}


def _persist_completed_unlocked(base_dir: Path, commit_id: str, *, now_ts: float) -> Dict[str, Any]:
    commit = _read_commit_by_id(base_dir, commit_id, {})
    manifest = commit.get("manifest") if isinstance(commit.get("manifest"), dict) else {}
    paper = commit.get("paper_ack") if isinstance(commit.get("paper_ack"), dict) else {}
    review = commit.get("review_ack") if isinstance(commit.get("review_ack"), dict) else {}
    if not (_ack_valid(paper, manifest, "paper") and _ack_valid(review, manifest, "review")):
        return {}
    existing = read_pointer(base_dir, completed=True)
    if float(manifest.get("created_ts") or 0.0) < float(existing.get("commit_created_ts") or 0.0):
        return existing
    pointer = {
        "schema": "candidate_commit_completed_v2117", "version": manifest.get("version"), "build": manifest.get("build"),
        "updated_ts": now_ts, "commit_created_ts": manifest.get("created_ts"), "candidate_commit_id": commit_id,
        "cycle_id": manifest.get("cycle_id"), "candidate_count": manifest.get("candidate_count"),
        "hold_count": (manifest.get("hold_counts") or {}).get("row_count") if isinstance(manifest.get("hold_counts"), dict) else 0,
        "paper_ack_ts": paper.get("updated_ts"), "review_ack_ts": review.get("updated_ts"),
        "state": "PASS", "auto_buy": False,
    }
    atomic_write_json(base_dir / COMPLETED_POINTER, pointer)
    return pointer


def _prune_commits(base_dir: Path, keep_ids: Iterable[str]) -> List[str]:
    commits = _root(base_dir) / "commits"
    if not commits.exists():
        return []
    keep = {str(x) for x in keep_ids if x}
    dirs = [p for p in commits.iterdir() if p.is_dir() and not p.name.startswith(".tmp.")]
    dirs.sort(key=lambda p: p.stat().st_mtime, reverse=True)
    keep.update(p.name for p in dirs[:KEEP_COMMITS])
    deleted: List[str] = []
    for path in dirs:
        if path.name in keep:
            continue
        try:
            shutil.rmtree(path)
            deleted.append(path.name)
        except OSError:
            pass
    return deleted


def publish_commit(*, base_dir: Path, cycle_id: str, full_rows: List[Dict[str, Any]],
                   hold_rows: List[Dict[str, Any]], compact_builder: Callable[[Dict[str, Any]], Dict[str, Any]],
                   version: str, build: str, now_ts: Optional[float] = None,
                   candidate_alias: Optional[Path] = None, hold_alias: Optional[Path] = None) -> Dict[str, Any]:
    base_dir = Path(base_dir)
    cycle_id = str(cycle_id or "").strip()
    if not cycle_id:
        raise ValueError("candidate commit cycle_id missing")
    nowv = float(now_ts if now_ts is not None else time.time())
    source_rows = [dict(r) for r in full_rows if isinstance(r, dict)]
    source_hold = [dict(r) for r in hold_rows if isinstance(r, dict)]
    source_counts, hold_counts = _counts(source_rows), _counts(source_hold)
    if source_counts["contract_missing"]:
        raise RuntimeError(f"candidate contract missing before commit: {source_counts['contract_missing']}")
    if hold_counts["contract_missing"]:
        raise RuntimeError(f"S1 hold contract missing before commit: {hold_counts['contract_missing']}")
    compact_rows = [compact_builder(dict(row)) for row in source_rows]
    if any(not isinstance(row, dict) for row in compact_rows) or len(compact_rows) != len(source_rows):
        raise RuntimeError("candidate compact builder mismatch")
    digest = hashlib.sha256(f"{cycle_id}|{len(source_rows)}|{len(source_hold)}|{nowv:.6f}".encode()).hexdigest()[:20]
    commit_id = f"candidate-{digest}"
    root, commits = _root(base_dir), _root(base_dir) / "commits"
    final_dir = commits / commit_id
    tmp_dir = commits / f".tmp.{commit_id}.{os.getpid()}.{time.time_ns()}"
    with _strategy_lock(base_dir):
        previous = read_pointer(base_dir)
        previous_id = str(previous.get("candidate_commit_id") or "")
        if previous_id:
            _persist_completed_unlocked(base_dir, previous_id, now_ts=nowv)
        commits.mkdir(parents=True, exist_ok=True)
        os.chmod(commits, 0o755)
        shutil.rmtree(tmp_dir, ignore_errors=True)
        tmp_dir.mkdir(parents=True, exist_ok=False)
        os.chmod(tmp_dir, 0o755)
        for row in compact_rows:
            row["candidate_commit_id_v2117"] = commit_id
            row["candidate_pipeline_cycle_id_v1150"] = cycle_id
        for row in source_hold:
            row["candidate_commit_id_v2117"] = commit_id
            row["candidate_pipeline_cycle_id_v1150"] = cycle_id
        count, total, max_row = atomic_write_jsonl(tmp_dir / "candidates.jsonl", compact_rows)
        hold_payload = {
            "schema": "paper_s1_hold_cache_v2117", "version": version, "build": build,
            "updated_ts": nowv, "cycle_id": cycle_id, "candidate_commit_id": commit_id,
            "candidate_pipeline_cycle_id_v1150": cycle_id, "candidate_pipeline_cycle_consistent_v1150": True,
            "source_s1_count": len(source_hold), "row_count": len(source_hold), "rows": source_hold,
            "hold_ttl_sec": 120.0, "auto_buy": False,
        }
        atomic_write_json(tmp_dir / "s1_hold.json", hold_payload)
        manifest = {
            "schema": SCHEMA, "version": version, "build": build, "created_ts": nowv,
            "cycle_id": cycle_id, "candidate_commit_id": commit_id, "state": "COMMITTED",
            "candidate_file": "candidates.jsonl", "hold_file": "s1_hold.json",
            "candidate_count": count, "candidate_bytes": total, "candidate_max_row_bytes": max_row,
            "integrity_state": "PASS", "source_counts": source_counts, "hold_counts": hold_counts,
            "writer_owner": "Strategy", "ack_write_location": "role-owned directories outside commit spine",
            "candidate_deleted": False, "candidate_threshold_relaxed": False,
            "buy_ready_forced": False, "auto_buy": False,
        }
        atomic_write_json(tmp_dir / "manifest.json", manifest)
        shutil.rmtree(final_dir, ignore_errors=True)
        os.replace(tmp_dir, final_dir)
        _make_commit_readable(final_dir)
        integrity = validate_commit(base_dir, commit_id)
        if integrity.get("state") != "PASS":
            raise RuntimeError("candidate commit integrity failed: " + "; ".join(integrity.get("errors") or []))
        if candidate_alias is not None:
            alias_count, _, _ = atomic_write_jsonl(Path(candidate_alias), compact_rows)
            if alias_count != count:
                raise RuntimeError(f"candidate compatibility mirror mismatch {count}->{alias_count}")
        if hold_alias is not None:
            atomic_write_json(Path(hold_alias), hold_payload)
        pointer = {
            "schema": "candidate_commit_current_v2117", "version": version, "build": build,
            "updated_ts": nowv, "candidate_commit_id": commit_id, "cycle_id": cycle_id,
            "commit_dir": str(final_dir), "candidate_path": str(final_dir / "candidates.jsonl"),
            "hold_path": str(final_dir / "s1_hold.json"), "manifest_path": str(final_dir / "manifest.json"),
            "candidate_count": count, "hold_count": len(source_hold), "state": "CURRENT",
            "integrity_state": "PASS", "auto_buy": False,
        }
        atomic_write_json(base_dir / CURRENT_POINTER, pointer)
        atomic_write_json(base_dir / STATUS_FILE, {
            "schema": "candidate_commit_spine_status_v2117", "version": version, "build": build,
            "updated_ts": nowv, "current": pointer, "completed": read_pointer(base_dir, completed=True),
            "state": "CURRENT_COMMITTED", "permission_model": "Strategy spine read-only; role-owned ack directories",
            "auto_buy": False,
        })
        completed = read_pointer(base_dir, completed=True)
        _prune_commits(base_dir, [commit_id, completed.get("candidate_commit_id")])
    return {**manifest, "commit_dir": str(final_dir)}


def _prune_role_acks(base_dir: Path, role: str, keep_ids: Iterable[str]) -> None:
    directory = _ack_dir(base_dir, role)
    try:
        files = [p for p in directory.glob("candidate-*.json") if p.is_file()]
        files.sort(key=lambda p: p.stat().st_mtime, reverse=True)
        keep = {str(x) for x in keep_ids if x}
        keep.update(p.stem for p in files[:KEEP_ACKS])
        for path in files:
            if path.stem not in keep:
                path.unlink()
    except OSError:
        pass


def write_ack(*, base_dir: Path, role: str, commit_id: str, state: str,
              version: str, build: str, details: Mapping[str, Any],
              now_ts: Optional[float] = None) -> Dict[str, Any]:
    """Write only to the calling role's own ack directory. No shared lock."""
    if role not in ACK_DIRS:
        raise ValueError("role must be paper or review")
    base_dir = Path(base_dir)
    commit_id = str(commit_id or "").strip()
    if not commit_id:
        raise ValueError("ack commit_id missing")
    commit = _read_commit_by_id(base_dir, commit_id, {})
    manifest = commit.get("manifest") if isinstance(commit.get("manifest"), dict) else {}
    if not manifest:
        raise FileNotFoundError(f"candidate commit missing: {commit_id}")
    nowv = float(now_ts if now_ts is not None else time.time())
    ack = {
        "schema": f"candidate_commit_{role}_ack_v2117", "role": role,
        "version": version, "build": build, "updated_ts": nowv,
        "candidate_commit_id": commit_id, "cycle_id": manifest.get("cycle_id"),
        "state": str(state).upper(), "details": dict(details),
        "write_owner": role, "shared_spine_write": False, "auto_buy": False,
    }
    directory = _ack_dir(base_dir, role)
    directory.mkdir(parents=True, exist_ok=True)
    os.chmod(directory, 0o755)
    path = _ack_path(base_dir, role, commit_id)
    atomic_write_json(path, ack)
    _prune_role_acks(base_dir, role, [commit_id])
    return ack


def cleanup_legacy_state(base_dir: Path, *, version: str, build: str,
                         code_dir: Optional[Path] = None) -> Dict[str, Any]:
    base_dir = Path(base_dir)
    deleted: List[str] = []
    deleted_code: List[str] = []
    errors: List[str] = []
    missing = 0
    for name in LEGACY_STATE_FILES:
        path = base_dir / name
        try:
            if path.is_file():
                path.unlink(); deleted.append(name)
            else:
                missing += 1
        except OSError as exc:
            errors.append(f"state/{name}: {type(exc).__name__}: {exc}")
    if code_dir is not None:
        root = Path(code_dir).resolve()
        for name in LEGACY_CODE_FILES:
            path = (root / name).resolve()
            try:
                if path.parent != root:
                    errors.append(f"code/{name}: unsafe path"); continue
                if path.is_file():
                    path.unlink(); deleted_code.append(name)
                else:
                    missing += 1
            except OSError as exc:
                errors.append(f"code/{name}: {type(exc).__name__}: {exc}")
    transport_deleted: List[str] = []
    spine_root = _root(base_dir)
    old_lock = spine_root / OLD_SHARED_LOCK_FILE
    try:
        if old_lock.is_file():
            old_lock.unlink(); transport_deleted.append(str(old_lock.relative_to(base_dir)))
    except OSError as exc:
        errors.append(f"transport/{OLD_SHARED_LOCK_FILE}: {type(exc).__name__}: {exc}")
    commits = spine_root / "commits"
    if commits.exists():
        for name in ("paper_ack.json", "review_ack.json"):
            for path in commits.glob(f"*/{name}"):
                try:
                    path.unlink(); transport_deleted.append(str(path.relative_to(base_dir)))
                except OSError as exc:
                    errors.append(f"transport/{path.name}: {type(exc).__name__}: {exc}")
    result = {
        "schema": "candidate_commit_cleanup_status_v2117", "version": version, "build": build,
        "updated_ts": time.time(), "deleted_state_count": len(deleted), "deleted_state_files": deleted,
        "deleted_code_count": len(deleted_code), "deleted_code_files": deleted_code,
        "deleted_transport_count": len(transport_deleted), "deleted_transport_files": transport_deleted,
        "missing_count": missing, "errors": errors,
        "protected": ["OPEN/CLOSED/trade_log/decision/exact ledgers", "change_verify/issue ledgers",
                      "Shadow ledgers and generations", "canonical performance snapshots"],
        "cleanup_scope": "exact v2111-v2116 candidate transport code/state and old shared lock only",
        "broad_disk_cleanup": False, "auto_buy": False,
    }
    atomic_write_json(base_dir / CLEANUP_FILE, result)
    return result


def status_model(base_dir: Path, *, freshness_sec: float = 180.0) -> Dict[str, Any]:
    nowv = time.time()
    current = read_pointer(base_dir)
    completed = read_commit(base_dir, completed=True).get("pointer") or {}
    current_id = str(current.get("candidate_commit_id") or "")
    commit = read_commit(base_dir, current_id) if current_id else {}
    manifest = commit.get("manifest") if isinstance(commit.get("manifest"), dict) else {}
    paper = commit.get("paper_ack") if isinstance(commit.get("paper_ack"), dict) else {}
    review = commit.get("review_ack") if isinstance(commit.get("review_ack"), dict) else {}
    current_age = max(0.0, nowv - float(current.get("updated_ts") or 0.0)) if current.get("updated_ts") else None
    completed_age = max(0.0, nowv - float(completed.get("updated_ts") or 0.0)) if completed.get("updated_ts") else None
    complete = bool(current_id and _ack_valid(paper, manifest, "paper") and _ack_valid(review, manifest, "review"))
    return {
        "schema": "candidate_commit_spine_model_v2117", "current": current, "completed": completed,
        "manifest": manifest, "paper_ack": paper, "review_ack": review,
        "current_age_sec": current_age, "completed_age_sec": completed_age,
        "current_fresh": current_age is not None and current_age <= freshness_sec,
        "current_complete": complete,
        "ready": bool(completed.get("state") == "PASS" and completed_age is not None and completed_age <= freshness_sec),
        "permission_model": "Strategy-only spine writer; Paper/Review role-owned ack directories",
        "auto_buy": False,
    }
