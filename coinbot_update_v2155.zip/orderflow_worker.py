#!/usr/bin/env python3
# -*- coding: utf-8 -*-

from __future__ import annotations
import json, os, time, math, traceback, urllib.request
from pathlib import Path
from typing import Any, Dict, List, Tuple, Optional
BASE_DIR = Path(os.getenv("TRADING_BOT_DIR", "/home/dangdang971216/trading_bot"))
def now_ts() -> float: return time.time()
def now_text(ts: Optional[float]=None) -> str: return time.strftime("%Y-%m-%d %H:%M:%S", time.localtime(ts or now_ts()))
def fnum(*vals: Any, default: float=0.0) -> float:
    for v in vals:
        try:
            if v is None or v == "": continue
            return float(str(v).replace(",", "").replace("%", ""))
        except Exception: continue
    return default
def load_json(path: Path, default: Any=None) -> Any:
    try:
        if not path.exists(): return default
        return json.loads(path.read_text(encoding="utf-8", errors="ignore"))
    except Exception: return default
def save_json(path: Path, obj: Any) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    tmp = path.with_suffix(path.suffix + ".tmp")
    tmp.write_text(json.dumps(obj, ensure_ascii=False, separators=(",", ":"), default=str), encoding="utf-8")
    os.replace(tmp, path)
def append_jsonl(path: Path, obj: Dict[str, Any]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("a", encoding="utf-8") as f:
        f.write(json.dumps(obj, ensure_ascii=False, separators=(",", ":"), default=str)+"\n")
def write_jsonl_atomic(path: Path, rows: List[Dict[str, Any]]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    tmp = path.with_suffix(path.suffix + ".tmp")
    with tmp.open("w", encoding="utf-8") as f:
        for r in rows:
            f.write(json.dumps(r, ensure_ascii=False, separators=(",", ":"), default=str)+"\n")
    os.replace(tmp, path)
def read_jsonl(path: Path, max_lines: int=1000) -> List[Dict[str, Any]]:
    if not path.exists(): return []
    try:
        lines = path.read_text(encoding="utf-8", errors="ignore").splitlines()
        if max_lines and len(lines) > max_lines: lines = lines[-max_lines:]
        out=[]
        for ln in lines:
            try:
                if ln.strip():
                    o=json.loads(ln)
                    if isinstance(o,dict): out.append(o)
            except Exception: pass
        return out
    except Exception: return []
def append_error(path: Path, where: str, exc: BaseException) -> None:
    try:
        path.parent.mkdir(parents=True, exist_ok=True)
        with path.open("a", encoding="utf-8") as f:
            f.write(f"[{now_text()}] {where}: {exc.__class__.__name__}: {exc}\n")
            f.write(traceback.format_exc()[-1500:]+"\n")
    except Exception: pass
def ticker_norm(x: Any) -> str:
    t = str(x or "").strip().upper().replace("/", "-").replace("_", "-")
    parts=[p for p in t.split("-") if p]
    if len(parts)>=2:
        non=[p for p in parts if p != "KRW"]
        t = non[-1] if non else parts[-1]
    if t.endswith("KRW") and len(t)>3: t=t[:-3]
    return t.strip().upper()
def pct(a: float, b: float) -> float: return ((a-b)/b*100.0) if b else 0.0
def age_sec(path: Path) -> float:
    try: return max(0.0, now_ts()-path.stat().st_mtime)
    except Exception: return 999999.0
def map_rows(obj: Any) -> Dict[str, Dict[str, Any]]:
    if isinstance(obj, dict) and isinstance(obj.get("rows"), list): obj = obj.get("rows")
    elif isinstance(obj, dict) and isinstance(obj.get("rows"), dict): obj = obj.get("rows")
    elif isinstance(obj, dict) and isinstance(obj.get("cache"), dict): obj = obj.get("cache")
    out: Dict[str, Dict[str, Any]] = {}
    if isinstance(obj, list):
        for r in obj:
            if isinstance(r, dict):
                t=ticker_norm(r.get("ticker") or r.get("symbol") or r.get("market"))
                if t: out[t]=r
    elif isinstance(obj, dict):
        for k,v in obj.items():
            t=ticker_norm(k)
            if t and isinstance(v, dict):
                vv=dict(v); vv.setdefault("ticker", t); out[t]=vv
    return out

VERSION="orderflow_worker_v0.11"
INTERVAL_SEC=float(os.getenv("ORDERFLOW_WORKER_INTERVAL_SEC","2.0"))
WS_TTL_SEC=float(os.getenv("ORDERFLOW_WS_TTL_SEC","45"))
MICRO_TTL_SEC=float(os.getenv("ORDERFLOW_MICRO_TTL_SEC","60"))
STATUS=BASE_DIR/"clean_orderflow_status.json"; OUT=BASE_DIR/"clean_orderflow_summary_cache.json"; ERROR=BASE_DIR/"clean_orderflow_error.log"
FEATURE=BASE_DIR/"clean_feature_cache.json"; WS=BASE_DIR/"clean_ws_live_cache.json"; MICRO=BASE_DIR/"clean_bithumb_micro_cache.json"; TARGET_QUEUE=BASE_DIR/"clean_target_router_queue.json"
MICRO_TARGETS=BASE_DIR/"clean_micro_targets.json"
MICRO_URGENT=BASE_DIR/"clean_micro_urgent_targets.json"
STRATEGY_REQ=BASE_DIR/"clean_strategy_priority_requests.json"
SUSTAIN_STATE=BASE_DIR/"clean_orderflow_buy_sustain_state.json"
SUSTAIN_WINDOW_SEC=float(os.getenv("ORDERFLOW_BUY_SUSTAIN_WINDOW_SEC","60"))
SUSTAIN_KEEP_SEC=float(os.getenv("ORDERFLOW_BUY_SUSTAIN_KEEP_SEC","75"))
SUSTAIN_READY_MIN_SPAN=float(os.getenv("ORDERFLOW_BUY_SUSTAIN_MIN_SPAN_SEC","45"))
SUSTAIN_READY_MIN_SAMPLES=int(float(os.getenv("ORDERFLOW_BUY_SUSTAIN_MIN_SAMPLES","8")))
SPIKE_STATE=BASE_DIR/"clean_orderflow_spike_fast_state.json"
CONTINUATION_STATE_V2130=BASE_DIR/"clean_orderflow_continuation_state_v2130.json"
SPIKE_KEEP_SEC=float(os.getenv("ORDERFLOW_SPIKE_FAST_KEEP_SEC","90"))
def write_status(state:str, **extra:Any)->None: save_json(STATUS,{"version":VERSION,"state":state,"pid":os.getpid(),"updated_ts":now_ts(),"updated_text":now_text(),**extra})
def row_age_sec(row:Dict[str,Any])->float:
    ts=fnum(row.get("updated_ts"), row.get("ts"), row.get("fresh_ts"), row.get("timestamp"), row.get("time"), default=0)
    return max(0.0, now_ts()-ts) if ts>0 else 999999.0

def is_fresh(row:Dict[str,Any], ttl:float)->bool:
    ts=fnum(row.get("updated_ts"), row.get("ts"), row.get("fresh_ts"), row.get("timestamp"), row.get("time"), default=0)
    return ts>0 and now_ts()-ts <= ttl


def _obj_updated_ts(obj: Any, fallback_path: Path) -> float:
    if isinstance(obj, dict):
        for k in ("updated_ts", "ts", "timestamp", "created_at"):
            try:
                v = obj.get(k)
                if v not in (None, ""):
                    return float(v)
            except Exception:
                pass
    try:
        return fallback_path.stat().st_mtime
    except Exception:
        return 0.0


def _row_ts(row: Dict[str, Any], global_ts: float = 0.0) -> float:
    for k in ("updated_ts", "orderflow_ts", "ts", "timestamp", "created_at", "detected_ts"):
        try:
            v = row.get(k)
            if v not in (None, ""):
                return float(v)
        except Exception:
            pass
    return global_ts or 0.0


def _scanner_quote(row: Dict[str, Any], global_ts: float, ttl: float = 35.0) -> Dict[str, Any]:
    """WS가 바로 안 들어오는 active 후보에 대해 scanner/feature REST 현재가를 표준 시세로 보강한다.
    fake fresh가 아니라 이미 scanner/feature worker가 만든 최신 REST 값을 쓰는 것이다.
    """
    price = fnum(row.get("current_price"), row.get("price"), row.get("close"), row.get("trade_price"), default=0.0)
    rts = _row_ts(row, global_ts)
    fresh = bool(price > 0 and rts > 0 and (now_ts() - rts) <= ttl)
    return {"rest_price": price, "rest_ts": rts, "rest_fresh": fresh, "rest_age_sec": round(max(0.0, now_ts() - rts), 3) if rts else None}

def _ratio01(v: Any, default: float = -1.0) -> float:
    x = fnum(v, default=default)
    if x > 1.5:
        x = x / 100.0
    if x < 0:
        return default
    return max(0.0, min(1.0, x))


def _load_sustain_state() -> Dict[str, List[List[float]]]:
    obj = load_json(SUSTAIN_STATE, {}) or {}
    raw = obj.get("history") if isinstance(obj, dict) and isinstance(obj.get("history"), dict) else obj
    out: Dict[str, List[List[float]]] = {}
    if isinstance(raw, dict):
        for k, vals in raw.items():
            t = ticker_norm(k)
            if not t or not isinstance(vals, list):
                continue
            hist: List[List[float]] = []
            for item in vals[-80:]:
                try:
                    if isinstance(item, (list, tuple)) and len(item) >= 2:
                        ts = float(item[0]); ratio = _ratio01(item[1], default=-1.0)
                    elif isinstance(item, dict):
                        ts = fnum(item.get("ts"), item.get("updated_ts"), default=0.0)
                        ratio = _ratio01(item.get("buy_ratio"), default=-1.0)
                    else:
                        continue
                    if ts > 0 and ratio >= 0:
                        hist.append([ts, round(ratio, 6)])
                except Exception:
                    continue
            if hist:
                out[t] = hist
    return out


def _save_sustain_state(history: Dict[str, List[List[float]]], ts: float) -> None:
    # Keep compact rolling state only. This is a producer state, not a long-term log.
    compact = {k: v[-80:] for k, v in history.items() if v}
    save_json(SUSTAIN_STATE, {
        "version": VERSION,
        "schema": "orderflow_buy_sustain_state_v527",
        "updated_ts": ts,
        "window_sec": SUSTAIN_WINDOW_SEC,
        "keep_sec": SUSTAIN_KEEP_SEC,
        "ready_min_span_sec": SUSTAIN_READY_MIN_SPAN,
        "ready_min_samples": SUSTAIN_READY_MIN_SAMPLES,
        "history": compact,
    })


def _direct_sustain_from_micro(m: Dict[str, Any]) -> Tuple[Optional[float], str]:
    # If micro sidecar already provides a real 60s/1m field, use it directly.
    for k in ("buy_sustain_1m", "buy_sustain_60s", "buy_persist_1m", "buy_flow_1m", "buy_pressure_1m", "micro_buy_sustain_1m"):
        v = _ratio01(m.get(k), default=-1.0)
        if v >= 0:
            return v, k
    return None, ""


def _update_sustain(history: Dict[str, List[List[float]]], ticker: str, buy_ratio: float, ts: float, micro_fresh: bool, m: Dict[str, Any]) -> Dict[str, Any]:
    direct, direct_src = _direct_sustain_from_micro(m)
    if direct is not None:
        return {
            "value": direct,
            "real": True,
            "source": direct_src,
            "sample_count": 1,
            "span_sec": 60.0,
            "persist": 1.0 if direct >= 0.70 else 0.0,
            "ready": True,
        }

    hist = history.get(ticker, [])
    if micro_fresh and buy_ratio >= 0:
        hist.append([ts, round(buy_ratio, 6)])
    cutoff = ts - SUSTAIN_KEEP_SEC
    hist = [[a, b] for a, b in hist if a >= cutoff and b >= 0]
    history[ticker] = hist

    win_cut = ts - SUSTAIN_WINDOW_SEC
    win = [[a, b] for a, b in hist if a >= win_cut]
    if not win:
        return {"value": None, "real": False, "source": "insufficient_history", "sample_count": 0, "span_sec": 0.0, "persist": None, "ready": False}

    vals = [b for _, b in win]
    span = max(0.0, win[-1][0] - win[0][0])
    ready = bool(len(vals) >= SUSTAIN_READY_MIN_SAMPLES and span >= SUSTAIN_READY_MIN_SPAN)
    avg = sum(vals) / len(vals)
    persist = sum(1 for x in vals if x >= 0.70) / len(vals)
    if ready:
        return {"value": avg, "real": True, "source": "orderflow_rolling_60s", "sample_count": len(vals), "span_sec": span, "persist": persist, "ready": True}
    return {"value": None, "real": False, "source": "insufficient_history", "sample_count": len(vals), "span_sec": span, "persist": persist, "ready": False}


# =============================================================================
# v535: 급등 초입용 5~30초 orderflow/price history
# =============================================================================

def _load_spike_state() -> Dict[str, List[Dict[str, float]]]:
    obj = load_json(SPIKE_STATE, {}) or {}
    raw = obj.get("history") if isinstance(obj, dict) and isinstance(obj.get("history"), dict) else obj
    out: Dict[str, List[Dict[str, float]]] = {}
    if isinstance(raw, dict):
        for k, vals in raw.items():
            t = ticker_norm(k)
            if not t or not isinstance(vals, list):
                continue
            hist: List[Dict[str, float]] = []
            for item in vals[-120:]:
                try:
                    if not isinstance(item, dict):
                        continue
                    ts = fnum(item.get("ts"), default=0.0)
                    price = fnum(item.get("price"), default=0.0)
                    buy = _ratio01(item.get("buy_ratio"), default=-1.0)
                    spread = fnum(item.get("spread_pct"), default=-1.0)
                    if ts > 0 and price > 0:
                        hist.append({"ts": ts, "price": price, "buy_ratio": max(0.0, buy), "spread_pct": max(0.0, spread)})
                except Exception:
                    continue
            if hist:
                out[t] = hist
    return out


def _save_spike_state(history: Dict[str, List[Dict[str, float]]], ts: float) -> None:
    cutoff = ts - SPIKE_KEEP_SEC
    compact: Dict[str, List[Dict[str, float]]] = {}
    for k, vals in history.items():
        vv = [x for x in vals[-120:] if fnum(x.get("ts"), default=0.0) >= cutoff]
        if vv:
            compact[k] = vv[-80:]
    save_json(SPIKE_STATE, {
        "version": VERSION,
        "schema": "orderflow_spike_fast_state_v535",
        "updated_ts": ts,
        "keep_sec": SPIKE_KEEP_SEC,
        "history": compact,
    })


def _window_items(hist: List[Dict[str, float]], ts: float, sec: float) -> List[Dict[str, float]]:
    cut = ts - sec
    return [x for x in hist if fnum(x.get("ts"), default=0.0) >= cut]


def _chg_from_window(hist: List[Dict[str, float]], ts: float, sec: float, price_now: float) -> float:
    if not hist or price_now <= 0:
        return 0.0
    win = _window_items(hist, ts, sec)
    base = win[0] if win else hist[0]
    p0 = fnum(base.get("price"), default=0.0)
    return pct(price_now, p0) if p0 > 0 else 0.0


def _avg_buy(win: List[Dict[str, float]], default: float = 0.0) -> float:
    vals = [fnum(x.get("buy_ratio"), default=-1.0) for x in win if fnum(x.get("buy_ratio"), default=-1.0) >= 0]
    return sum(vals) / len(vals) if vals else default


def _min_spread(win: List[Dict[str, float]], default: float = 0.0) -> float:
    vals = [fnum(x.get("spread_pct"), default=-1.0) for x in win if fnum(x.get("spread_pct"), default=-1.0) >= 0]
    return min(vals) if vals else default


def _update_spike_history(history: Dict[str, List[Dict[str, float]]], ticker: str, price_now: float, buy_ratio: float, spread_pct: float, ts: float, fresh: bool) -> Dict[str, Any]:
    hist = history.get(ticker, [])
    if fresh and price_now > 0:
        hist.append({"ts": ts, "price": float(price_now), "buy_ratio": float(max(0.0, buy_ratio)), "spread_pct": float(max(0.0, spread_pct))})
    cutoff = ts - SPIKE_KEEP_SEC
    hist = [x for x in hist[-120:] if fnum(x.get("ts"), default=0.0) >= cutoff]
    history[ticker] = hist

    win5 = _window_items(hist, ts, 5)
    win10 = _window_items(hist, ts, 10)
    win20 = _window_items(hist, ts, 20)
    win30 = _window_items(hist, ts, 30)
    win60 = _window_items(hist, ts, 60)
    chg5 = _chg_from_window(hist, ts, 5, price_now)
    chg10 = _chg_from_window(hist, ts, 10, price_now)
    chg20 = _chg_from_window(hist, ts, 20, price_now)
    chg30 = _chg_from_window(hist, ts, 30, price_now)
    chg60 = _chg_from_window(hist, ts, 60, price_now)
    buy5 = _avg_buy(win5, buy_ratio)
    buy10 = _avg_buy(win10, buy_ratio)
    buy20 = _avg_buy(win20, buy_ratio)
    spmin20 = _min_spread(win20, spread_pct)
    spread_widen = max(0.0, spread_pct - spmin20)
    accel10 = chg10 - chg30
    accel20 = chg20 - chg60
    ready = bool(len(win10) >= 2 or len(win20) >= 3)
    return {
        "price_chg_5s": round(chg5, 4),
        "price_chg_10s": round(chg10, 4),
        "price_chg_20s": round(chg20, 4),
        "price_chg_30s": round(chg30, 4),
        "price_chg_60s": round(chg60, 4),
        "price_accel_10s": round(accel10, 4),
        "price_accel_20s": round(accel20, 4),
        "buy_ratio_5s": round(buy5, 4),
        "buy_ratio_10s": round(buy10, 4),
        "buy_sustain_20s": round(buy20, 4),
        "trade_burst_10s": round(max(0.0, buy10 - _avg_buy(win60, buy_ratio)), 4),
        "spread_min_20s": round(spmin20, 4),
        "spread_widening_10s": round(spread_widen, 4),
        "spike_fast_ready": ready,
        "spike_fast_sample_count_20s": len(win20),
    }


def run_once()->Dict[str,Any]:
    st=now_ts(); ts=now_ts()
    feature_obj = load_json(FEATURE,{}) or {}
    feature_ts = _obj_updated_ts(feature_obj, FEATURE)
    fmap = map_rows(feature_obj)
    qobj=load_json(TARGET_QUEUE,{}) or {}
    mtargets_obj=load_json(MICRO_TARGETS,{}) or {}
    murgent_obj=load_json(MICRO_URGENT,{}) or {}
    sreq_obj=load_json(STRATEGY_REQ,{}) or {}
    qrows = qobj.get("active_rows") if isinstance(qobj,dict) and isinstance(qobj.get("active_rows"), list) else []
    micro_target_rows = mtargets_obj.get("rows") if isinstance(mtargets_obj,dict) and isinstance(mtargets_obj.get("rows"), list) else []
    micro_urgent_set = {ticker_norm(x) for x in (murgent_obj.get("targets") if isinstance(murgent_obj,dict) and isinstance(murgent_obj.get("targets"), list) else []) if ticker_norm(x)}
    strategy_req_rows = sreq_obj.get("requests") if isinstance(sreq_obj,dict) and isinstance(sreq_obj.get("requests"), list) else []
    strategy_req_map = {ticker_norm(r.get("ticker")): r for r in strategy_req_rows if isinstance(r,dict) and ticker_norm(r.get("ticker"))}
    micro_target_map = {ticker_norm(r.get("ticker")): r for r in micro_target_rows if isinstance(r,dict) and ticker_norm(r.get("ticker"))}
    qmap={ticker_norm(r.get("ticker")):r for r in qrows if isinstance(r,dict) and ticker_norm(r.get("ticker"))}
    # active target을 먼저, 그 뒤 feature 전체를 붙여 canonical rows를 만든다.
    ordered=[]; seen=set()
    for t,qr in qmap.items():
        base = dict(fmap.get(t, {}) or {})
        base.setdefault("ticker", t)
        base["router_priority"] = fnum(qr.get("priority"), default=0)
        base["router_bucket"] = qr.get("bucket")
        base["router_need"] = qr.get("need")
        base["router_active"] = True
        ordered.append(base); seen.add(t)
    for t,r in fmap.items():
        if t not in seen:
            rr=dict(r); rr.setdefault("ticker", t); rr["router_active"] = False
            ordered.append(rr); seen.add(t)
    ws=map_rows(load_json(WS,{}) or {}); micro=map_rows(load_json(MICRO,{}) or {})
    sustain_history = _load_sustain_state()
    spike_history = _load_spike_state()
    rows=[]; fresh_ws=0; fresh_micro=0; quote_fresh_count=0; info_ready_count=0; router_fresh=0; active_count=0; entry_slippage_confirmed_count=0
    _v2130_state=load_json(CONTINUATION_STATE_V2130,{}) or {}; _v2130_prev=_v2130_state.get("rows") if isinstance(_v2130_state,dict) and isinstance(_v2130_state.get("rows"),dict) else {}; _v2130_next={}; continuation_ready_v2130=0; continuation_missing_v2130=0
    buy_sustain_ready_count=0; buy_sustain_pending_count=0; buy_sustain_direct_count=0; buy_sustain_rolling_count=0
    spike_fast_ready_count=0
    micro_target_count=micro_target_fresh=0; micro_urgent_count=micro_urgent_fresh=0; strategy_req_count=strategy_req_micro_ready=strategy_req_info_ready=0
    for r in ordered:
        t=ticker_norm(r.get("ticker"));
        if not t: continue
        w=ws.get(t,{}) or {}; m=micro.get(t,{}) or {}
        wf=is_fresh(w,WS_TTL_SEC); mf=is_fresh(m,MICRO_TTL_SEC)
        ws_age=row_age_sec(w) if w else 999999.0
        micro_age=row_age_sec(m) if m else 999999.0
        rest = _scanner_quote(r, feature_ts)
        quote_fresh = bool(wf or rest.get("rest_fresh"))
        quote_source = "ws" if wf else ("scanner_rest" if rest.get("rest_fresh") else "missing")
        fresh_ws += 1 if wf else 0
        fresh_micro += 1 if mf else 0
        quote_fresh_count += 1 if quote_fresh else 0
        info_ready = bool(quote_fresh and mf)
        info_ready_count += 1 if info_ready else 0
        active = bool(r.get("router_active"))
        micro_target = t in micro_target_map
        micro_urgent = t in micro_urgent_set or bool((micro_target_map.get(t) or {}).get("micro_urgent"))
        strategy_req = t in strategy_req_map
        active_count += 1 if active else 0
        micro_target_count += 1 if micro_target else 0
        micro_target_fresh += 1 if micro_target and mf else 0
        micro_urgent_count += 1 if micro_urgent else 0
        micro_urgent_fresh += 1 if micro_urgent and mf else 0
        strategy_req_count += 1 if strategy_req else 0
        strategy_req_micro_ready += 1 if strategy_req and mf else 0
        strategy_req_info_ready += 1 if strategy_req and info_ready else 0
        if active and info_ready: router_fresh += 1
        price=fnum(r.get("current_price"), r.get("price"), default=0)
        ws_price=fnum(w.get("price"),w.get("current_price"),w.get("trade_price"),w.get("close"), default=0)
        quote_price = ws_price if wf and ws_price else fnum(rest.get("rest_price"), default=0.0)
        spread=fnum(m.get("spread_pct"),m.get("orderbook_spread_pct"),m.get("micro_spread_pct"), default=0.0)
        ask=fnum(m.get("ask_price"),m.get("best_ask"), default=0); bid=fnum(m.get("bid_price"),m.get("best_bid"), default=0)
        if not spread and ask and bid: spread=pct(ask,bid)
        buy_ratio=fnum(m.get("buy_ratio"),m.get("trade_buy_ratio_30"),m.get("micro_trade_buy_ratio_30"),m.get("buy_trade_ratio"),m.get("buy_ratio_30s"), default=0.0)
        if buy_ratio>1.5: buy_ratio=buy_ratio/100.0
        bid_wall=fnum(m.get("bid_ask_wall_ratio"),m.get("micro_bid_ask_wall_ratio"),m.get("buy_wall_ratio"), default=0.0)
        ask_wall_raw=fnum(m.get("ask_wall_ratio"),m.get("micro_ask_wall_ratio"),m.get("sell_wall_ratio"), default=-1.0)
        ask_wall_ratio = ask_wall_raw if ask_wall_raw >= 0 else ((1.0/bid_wall) if bid_wall>0 else (1.0 if mf else None))
        sustain_info = _update_sustain(sustain_history, t, buy_ratio, ts, mf, m)
        buy_sustain_1m = sustain_info.get("value") if sustain_info.get("real") else None
        buy_sustain_ready_count += 1 if sustain_info.get("real") else 0
        buy_sustain_pending_count += 1 if not sustain_info.get("real") else 0
        buy_sustain_direct_count += 1 if str(sustain_info.get("source") or "").startswith(("buy_", "micro_")) and sustain_info.get("real") else 0
        buy_sustain_rolling_count += 1 if sustain_info.get("source") == "orderflow_rolling_60s" else 0
        # v1100 canonical entry slippage owner. Never copy spread into slippage.
        # Paper currently has no notional/quantity contract, so the executable reference is
        # the fresh best ask versus the freshest trade/quote reference price.
        explicit_slip=fnum(m.get("slippage_est_pct"),m.get("expected_slippage_pct"), default=-1.0)
        explicit_slip_source=str(m.get("entry_slippage_source") or m.get("slippage_source") or "").strip().lower()
        explicit_slip_trusted=any(token in explicit_slip_source for token in ("micro_depth", "orderbook_depth"))
        reference_price = quote_price if quote_price > 0 else price
        best_ask = ask if ask > 0 else fnum(m.get("best_ask"), default=0.0)
        slippage_est_pct = None
        slippage_source = "missing"
        slippage_confirmed = False
        slippage_basis = "missing"
        if mf and explicit_slip >= 0 and explicit_slip_trusted:
            slippage_est_pct = max(0.0, explicit_slip)
            slippage_source = "micro_depth_estimate_orderflow_v1100"
            slippage_confirmed = True
            slippage_basis = "trusted_micro_depth_execution_estimate"
        elif mf and best_ask > 0 and reference_price > 0:
            slippage_est_pct = max(0.0, pct(best_ask, reference_price))
            slippage_source = "best_ask_reference_orderflow_v1100"
            slippage_confirmed = True
            slippage_basis = "fresh_best_ask_vs_quote_reference_no_notional"
        slippage_ts = fnum(m.get("updated_ts"), m.get("ts"), default=0.0) if slippage_confirmed else 0.0
        slippage_age_sec = max(0.0, ts-slippage_ts) if slippage_ts > 0 else None
        fast_price = quote_price if quote_price else price
        spike_info = _update_spike_history(spike_history, t, fast_price, buy_ratio, spread, ts, bool(quote_fresh or mf))
        spike_fast_ready_count += 1 if spike_info.get("spike_fast_ready") else 0
        sell_pressure=bool(m.get("ask_wall_pressure") or m.get("micro_ask_wall_pressure") or m.get("sell_trade_pressure") or m.get("micro_sell_trade_pressure") or m.get("ask_pressure"))
        gap=pct(quote_price,price) if price and quote_price else 0.0
        strength_score=0
        strength_score += 2 if quote_fresh else -1
        strength_score += 2 if mf else -1
        strength_score += 1 if 0<spread<=0.22 else (-1 if spread>0.35 else 0)
        strength_score += 1 if buy_ratio>=0.62 else (-1 if buy_ratio and buy_ratio<0.5 else 0)
        strength_score += -1 if sell_pressure else 1
        rr={
            "ticker":t,
            "orderflow_ts":ts,
            "schema":"orderflow_canonical_v5_s123",
            "quote_fresh":quote_fresh,
            "quote_source":quote_source,
            "quote_price":quote_price,
            "quote_gap_pct":round(gap,3),
            "quote_age_sec": 0.0 if wf else rest.get("rest_age_sec"),
            "ws_age_sec": round(ws_age, 3) if ws_age < 999999 else None,
            "micro_age_sec": round(micro_age, 3) if micro_age < 999999 else None,
            "ws_fresh":wf,
            "micro_fresh":mf,
            "info_ready":info_ready,
            "ws_price":ws_price,
            "ws_gap_pct":round(pct(ws_price,price),3) if price and ws_price else 0.0,
            "rest_fresh":bool(rest.get("rest_fresh")),
            "rest_price":rest.get("rest_price"),
            "rest_age_sec":rest.get("rest_age_sec"),
            "spread_pct":round(spread,3),
            "buy_ratio":round(buy_ratio,3),
            "price_chg_5s":spike_info.get("price_chg_5s"),
            "price_chg_10s":spike_info.get("price_chg_10s"),
            "price_chg_20s":spike_info.get("price_chg_20s"),
            "price_chg_30s":spike_info.get("price_chg_30s"),
            "price_chg_60s":spike_info.get("price_chg_60s"),
            "price_accel_10s":spike_info.get("price_accel_10s"),
            "price_accel_20s":spike_info.get("price_accel_20s"),
            "buy_ratio_5s":spike_info.get("buy_ratio_5s"),
            "buy_ratio_10s":spike_info.get("buy_ratio_10s"),
            "buy_sustain_20s":spike_info.get("buy_sustain_20s"),
            "trade_burst_10s":spike_info.get("trade_burst_10s"),
            "spread_min_20s":spike_info.get("spread_min_20s"),
            "spread_widening_10s":spike_info.get("spread_widening_10s"),
            "spike_fast_ready":bool(spike_info.get("spike_fast_ready")),
            "spike_fast_sample_count_20s":spike_info.get("spike_fast_sample_count_20s"),
            "buy_sustain_1m":round(buy_sustain_1m,3) if buy_sustain_1m is not None else None,
            "buy_sustain_60s":round(buy_sustain_1m,3) if buy_sustain_1m is not None else None,
            "buy_persist_1m":round(sustain_info.get("persist"),3) if sustain_info.get("persist") is not None else None,
            "buy_flow_1m":round(buy_sustain_1m,3) if buy_sustain_1m is not None else None,
            "buy_pressure_1m":round(buy_sustain_1m,3) if buy_sustain_1m is not None else None,
            "micro_buy_sustain_1m":round(buy_sustain_1m,3) if buy_sustain_1m is not None else None,
            "buy_ratio_1m":round(buy_sustain_1m,3) if buy_sustain_1m is not None else None,
            "buy_ratio_60":round(buy_sustain_1m,3) if buy_sustain_1m is not None else None,
            "micro_buy_ratio_sustain_1m":round(buy_sustain_1m,3) if buy_sustain_1m is not None else None,
            "buy_ratio_sustain":round(buy_sustain_1m,3) if buy_sustain_1m is not None else None,
            "buy_sustain_1m_real":bool(sustain_info.get("real")),
            "buy_sustain_1m_source":sustain_info.get("source"),
            "buy_sustain_1m_ready":bool(sustain_info.get("ready")),
            "buy_sustain_sample_count":int(sustain_info.get("sample_count") or 0),
            "buy_sustain_span_sec":round(float(sustain_info.get("span_sec") or 0.0),3),
            "entry_slippage_est_pct":round(slippage_est_pct,6) if slippage_est_pct is not None else None,
            "entry_slippage_source":slippage_source,
            "entry_slippage_ts":slippage_ts or None,
            "entry_slippage_age_sec":round(slippage_age_sec,3) if slippage_age_sec is not None else None,
            "entry_slippage_confirmed":bool(slippage_confirmed),
            "entry_slippage_basis":slippage_basis,
            "entry_slippage_order_amount_krw":None,
            "entry_slippage_order_amount_state":"paper_notional_not_configured",
            "entry_slippage_owner":"orderflow_worker",
            "slippage_pct_confirmed":round(slippage_est_pct,6) if slippage_est_pct is not None else None,
            "slippage_pct_source_v903":slippage_source,
            "slippage_source":slippage_source,
            "slippage_pct":round(slippage_est_pct,6) if slippage_est_pct is not None else None,
            "slippage_est_pct":round(slippage_est_pct,6) if slippage_est_pct is not None else None,
            "tick_pct_est":round(slippage_est_pct,6) if slippage_est_pct is not None else None,
            "expected_slippage_pct":round(slippage_est_pct,6) if slippage_est_pct is not None else None,
            "bid_wall_ratio":round(bid_wall,3),
            "ask_wall_ratio":round(ask_wall_ratio,3) if ask_wall_ratio is not None else None,
            "micro_ask_wall_ratio":round(ask_wall_ratio,3) if ask_wall_ratio is not None else None,
            "canonical_orderflow_ready": bool(mf and buy_sustain_1m is not None and slippage_confirmed and slippage_est_pct is not None and ask_wall_ratio is not None),
            "canonical_missing": [x for x,v in {"buy_sustain_1m":buy_sustain_1m,"slippage_est_pct":slippage_est_pct,"ask_wall_ratio":ask_wall_ratio}.items() if v is None],
            "sell_pressure":sell_pressure,
            "orderflow_score":strength_score,
            "micro_status":"fresh" if mf else ("stale" if m else "missing"),
            "ws_status":"fresh" if wf else ("stale" if w else "missing"),
            "quote_status":"fresh" if quote_fresh else "missing",
            "router_active": active,
            "micro_target": micro_target,
            "micro_urgent": micro_urgent,
            "strategy_request": strategy_req,
            "strategy_request_bucket": (strategy_req_map.get(t) or {}).get("bucket"),
            "strategy_request_need": (strategy_req_map.get(t) or {}).get("need"),
            "router_priority":r.get("router_priority"),
            "router_bucket":r.get("router_bucket"),
            "router_need":r.get("router_need"),
        }
        prev=_v2130_prev.get(t) if isinstance(_v2130_prev.get(t),dict) else {}
        def _d(cur: Any, key: str) -> Optional[float]:
            oldv=prev.get(key)
            try:return float(cur)-float(oldv) if cur is not None and oldv is not None else None
            except Exception:return None
        buy_ratio_delta=_d(buy_ratio,"buy_ratio")
        buy_sustain_delta=_d(buy_sustain_1m,"buy_sustain_1m")
        ask_wall_delta=_d(ask_wall_ratio,"ask_wall_ratio")
        ask_depletion=(-ask_wall_delta) if ask_wall_delta is not None else None
        spread_delta=_d(spread,"spread_pct")
        bid_wall_delta=_d(bid_wall,"bid_wall_ratio")
        components=[]
        if buy_ratio_delta is not None: components.append(max(0.0,min(100.0,50.0+buy_ratio_delta*180.0)))
        if buy_sustain_delta is not None: components.append(max(0.0,min(100.0,50.0+buy_sustain_delta*180.0)))
        if ask_depletion is not None: components.append(max(0.0,min(100.0,50.0+ask_depletion*35.0)))
        if spread_delta is not None: components.append(max(0.0,min(100.0,50.0-spread_delta*220.0)))
        if spike_info.get("trade_burst_10s") is not None:
            try:components.append(max(0.0,min(100.0,50.0+float(spike_info.get("trade_burst_10s"))*8.0)))
            except Exception:pass
        cont_score=sum(components)/len(components) if components else None
        missing=[]
        if buy_sustain_delta is None:missing.append("buy_sustain_velocity_warmup")
        if ask_depletion is None:missing.append("ask_wall_depletion_warmup")
        if spread_delta is None:missing.append("spread_velocity_warmup")
        if not mf:missing.append("fresh_micro")
        cont_state="READY" if cont_score is not None and len(missing)<=1 else ("PARTIAL" if cont_score is not None else "SOURCE_MISSING")
        rr["orderflow_continuation_v2130"]={
            "schema":"orderflow_prediction_context_v2155","owner":"orderflow_worker","state":cont_state,
            # current level and change speed are both preserved; Strategy must never infer level from delta.
            "continuation_score_v2130":round(cont_score,3) if cont_score is not None else None,
            "buy_ratio_level_v2155":round(buy_ratio,6),
            "buy_sustain_level_v2155":round(buy_sustain_1m,6) if buy_sustain_1m is not None else None,
            "buy_persist_level_v2155":round(float(sustain_info.get("persist")),6) if sustain_info.get("persist") is not None else None,
            "ask_wall_ratio_level_v2155":round(ask_wall_ratio,6) if ask_wall_ratio is not None else None,
            "bid_wall_ratio_level_v2155":round(bid_wall,6),
            "sell_pressure_level_v2155":bool(sell_pressure),
            "orderflow_score_level_v2155":strength_score,
            "spread_level_pct_v2155":round(spread,6),
            "buy_ratio_delta_v2130":round(buy_ratio_delta,6) if buy_ratio_delta is not None else None,
            "buy_sustain_delta_v2130":round(buy_sustain_delta,6) if buy_sustain_delta is not None else None,
            "ask_wall_depletion_v2130":round(ask_depletion,6) if ask_depletion is not None else None,
            "bid_wall_delta_v2130":round(bid_wall_delta,6) if bid_wall_delta is not None else None,
            "spread_delta_v2130":round(spread_delta,6) if spread_delta is not None else None,
            "micro_reaction_v2155":{
                "price_chg_5s":spike_info.get("price_chg_5s"),"price_chg_10s":spike_info.get("price_chg_10s"),
                "price_chg_20s":spike_info.get("price_chg_20s"),"price_chg_30s":spike_info.get("price_chg_30s"),
                "price_chg_60s":spike_info.get("price_chg_60s"),"price_accel_10s":spike_info.get("price_accel_10s"),
                "price_accel_20s":spike_info.get("price_accel_20s"),"buy_ratio_5s":spike_info.get("buy_ratio_5s"),
                "buy_ratio_10s":spike_info.get("buy_ratio_10s"),"buy_sustain_20s":spike_info.get("buy_sustain_20s"),
                "trade_burst_10s":spike_info.get("trade_burst_10s"),"spread_widening_10s":spike_info.get("spread_widening_10s"),
                "sample_count_20s":spike_info.get("spike_fast_sample_count_20s"),"ready":bool(spike_info.get("spike_fast_ready")),
            },
            "freshness_v2155":{
                "sample_ts":ts,"prior_sample_ts":prev.get("ts"),"micro_fresh":bool(mf),"ws_fresh":bool(wf),
                "quote_fresh":bool(quote_fresh),"micro_age_sec":round(micro_age,3) if micro_age<999999 else None,
                "ws_age_sec":round(ws_age,3) if ws_age<999999 else None,"owner_version":VERSION,
            },
            "spread_widening_v2130":bool(spread_delta is not None and spread_delta>0.03),
            "sell_wall_refill_v2130":bool(ask_wall_delta is not None and ask_wall_delta>0.12),
            "source_missing_v2130":missing,"sample_ts":ts,"prior_sample_ts":prev.get("ts"),
            "execution_cost_owner_unchanged_v2130":True,"actual_entry_changed_v2130":False,"auto_buy":False,
        }
        continuation_ready_v2130+=int(cont_state=="READY");continuation_missing_v2130+=int(cont_state=="SOURCE_MISSING")
        _v2130_next[t]={"ts":ts,"buy_ratio":buy_ratio,"buy_sustain_1m":buy_sustain_1m,"ask_wall_ratio":ask_wall_ratio,"bid_wall_ratio":bid_wall,"spread_pct":spread}
        entry_slippage_confirmed_count += 1 if slippage_confirmed else 0
        rows.append(rr)
    save_json(CONTINUATION_STATE_V2130,{"schema":"orderflow_continuation_state_v2130","version":VERSION,"build":BUILD_LABEL,"updated_ts":ts,"rows":_v2130_next,"auto_buy":False})
    _save_sustain_state(sustain_history, ts)
    _save_spike_state(spike_history, ts)
    save_json(OUT,{"version":VERSION,"schema":"orderflow_canonical_v2155_full_prediction_and_entry_slippage","updated_ts":ts,"updated_text":now_text(ts),"row_count":len(rows),"active_count":active_count,"fresh_ws":fresh_ws,"fresh_micro":fresh_micro,"quote_fresh":quote_fresh_count,"info_ready":info_ready_count,"entry_slippage_confirmed_count_v1100":entry_slippage_confirmed_count,"buy_sustain_ready_count":buy_sustain_ready_count,"buy_sustain_pending_count":buy_sustain_pending_count,"buy_sustain_direct_count":buy_sustain_direct_count,"buy_sustain_rolling_count":buy_sustain_rolling_count,"spike_fast_ready_count":spike_fast_ready_count,"buy_sustain_window_sec":SUSTAIN_WINDOW_SEC,"buy_sustain_ready_min_span_sec":SUSTAIN_READY_MIN_SPAN,"buy_sustain_ready_min_samples":SUSTAIN_READY_MIN_SAMPLES,"router_queue_age":age_sec(TARGET_QUEUE),"router_target_count":qobj.get("active_target_count", qobj.get("target_count","-")),"router_queue_count":qobj.get("queue_count","-"),"router_backlog_count":qobj.get("backlog_count","-"),"router_fresh_ready":router_fresh,"micro_target_count":micro_target_count,"micro_target_fresh":micro_target_fresh,"micro_urgent_count":micro_urgent_count,"micro_urgent_fresh":micro_urgent_fresh,"strategy_req_count":strategy_req_count,"strategy_req_micro_ready":strategy_req_micro_ready,"strategy_req_info_ready":strategy_req_info_ready,"ws_cache_count":len(ws),"micro_cache_count":len(micro),"feature_age_sec":round(max(0.0, ts-feature_ts),3) if feature_ts else None,"ws_ttl_sec":WS_TTL_SEC,"micro_ttl_sec":MICRO_TTL_SEC,"continuation_ready_v2130":continuation_ready_v2130,"continuation_source_missing_v2130":continuation_missing_v2130,"continuation_owner_v2130":"orderflow_worker","note":"v2155: current buy/sustain/wall/pressure levels, change speed and micro reaction are sealed together for Strategy prediction; execution slippage ownership remains unchanged.","rows":rows})
    sec=now_ts()-st
    write_status("running", row_count=len(rows), active_count=active_count, fresh_ws=fresh_ws, fresh_micro=fresh_micro, quote_fresh=quote_fresh_count, info_ready=info_ready_count, entry_slippage_confirmed_count_v1100=entry_slippage_confirmed_count, continuation_ready_v2130=continuation_ready_v2130, continuation_source_missing_v2130=continuation_missing_v2130, continuation_owner_v2130="orderflow_worker", buy_sustain_ready_count=buy_sustain_ready_count, buy_sustain_pending_count=buy_sustain_pending_count, buy_sustain_direct_count=buy_sustain_direct_count, buy_sustain_rolling_count=buy_sustain_rolling_count, spike_fast_ready_count=spike_fast_ready_count, buy_sustain_window_sec=SUSTAIN_WINDOW_SEC, router_target_count=qobj.get("active_target_count", qobj.get("target_count","-")), router_queue_count=qobj.get("queue_count","-"), router_backlog_count=qobj.get("backlog_count","-"), router_fresh_ready=router_fresh, micro_target_count=micro_target_count, micro_target_fresh=micro_target_fresh, micro_urgent_count=micro_urgent_count, micro_urgent_fresh=micro_urgent_fresh, strategy_req_count=strategy_req_count, strategy_req_micro_ready=strategy_req_micro_ready, strategy_req_info_ready=strategy_req_info_ready, ws_cache_count=len(ws), micro_cache_count=len(micro), feature_age_sec=round(max(0.0, ts-feature_ts),3) if feature_ts else None, ws_ttl_sec=WS_TTL_SEC, micro_ttl_sec=MICRO_TTL_SEC, last_sec=round(sec,3))
    return {"rows":len(rows), "active":active_count, "quote_fresh":quote_fresh_count, "info_ready":info_ready_count}

def main()->None:
    write_status("initializing")
    while True:
        try: run_once()
        except KeyboardInterrupt: write_status("stopping"); raise
        except Exception as exc: append_error(ERROR,"loop",exc); write_status("error", error=f"{exc.__class__.__name__}: {exc}")
        time.sleep(max(0.5,INTERVAL_SEC))

# v1401 identity unification override (no trading-rule changes)
VERSION = 'orderflow_worker_v2.002'
BUILD_LABEL = 'v2155_orderflow_full_prediction_input_owner_2026-07-22'
MAIN_DEPLOY_VERSION = BUILD_LABEL

if __name__=="__main__": main()
