# CORE V2 v1068 전체 점검표

- [x] scanner/candle/market/feature/orderflow/ws/micro 기존 검증 worker 보존
- [x] Strategy 최종 active 함수·재바인딩 순서 exact 이식
- [x] S1·trigger·invalid·target·candidate/decision key 산식 변경 없음
- [x] Risk latest loss·재진입 source 계약 exact 이식
- [x] Paper 후보선택·OPEN·MFE/MAE·청산·CLOSED commit exact 이식
- [x] Review canonical 성과 writer exact 이식
- [x] Main 명령 registry·화면 handler exact 이식
- [x] Paper 최종 command handler exact 이식
- [x] Guard 기존 명령 보존 + verify/cutover 즉시 접수 메시지
- [x] 중복 top-level 정의 0
- [x] 죽은 overwritten 정의 제거
- [x] live ledger 미포함
- [x] 검증 read-only
- [x] 전환 실패 시 전체 rollback
- [x] 자동매수 OFF

서버 DONE 조건: `/gcore_v2_verify` PASS 후 `/gcore_v2_cutover` runtime proof PASS, Risk–Paper READY/signature true, exact 0/0/0, 새 오류 0, 재시작 유지.
