#!/usr/bin/env python3
# -*- coding: utf-8 -*-

from __future__ import annotations
import json, os, time, math, traceback, urllib.request, gc, ctypes
from pathlib import Path
from typing import Any, Dict, List, Tuple, Optional
BASE_DIR = Path(os.getenv("TRADING_BOT_DIR", "/home/dangdang971216/trading_bot"))
def now_ts() -> float: return time.time()
def now_text(ts: Optional[float]=None) -> str: return time.strftime("%Y-%m-%d %H:%M:%S", time.localtime(ts or now_ts()))
def fnum(*vals: Any, default: float=0.0) -> float:
    for v in vals:
        try:
            if v is None or v == "": continue
            return float(str(v).replace(",", "").replace("%", ""))
        except Exception: continue
    return default
def load_json(path: Path, default: Any=None) -> Any:
    try:
        if not path.exists(): return default
        with path.open("r", encoding="utf-8", errors="ignore") as handle:
            return json.load(handle)
    except Exception: return default
def save_json(path: Path, obj: Any) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    tmp = path.with_name(path.name + f".tmp.{os.getpid()}.{time.time_ns()}")
    try:
        with tmp.open("w", encoding="utf-8") as handle:
            json.dump(obj, handle, ensure_ascii=False, separators=(",", ":"), default=str)
            handle.flush(); os.fsync(handle.fileno())
        os.replace(tmp, path)
    finally:
        try: tmp.unlink(missing_ok=True)
        except OSError: pass
def append_jsonl(path: Path, obj: Dict[str, Any]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("a", encoding="utf-8") as f:
        f.write(json.dumps(obj, ensure_ascii=False, separators=(",", ":"), default=str)+"\n")
def write_jsonl_atomic(path: Path, rows: List[Dict[str, Any]]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    tmp = path.with_suffix(path.suffix + ".tmp")
    with tmp.open("w", encoding="utf-8") as f:
        for r in rows:
            f.write(json.dumps(r, ensure_ascii=False, separators=(",", ":"), default=str)+"\n")
    os.replace(tmp, path)
def _tail_text_lines(path: Path, max_lines: int) -> List[str]:
    if max_lines <= 0:
        with path.open("r", encoding="utf-8", errors="ignore") as handle:
            return [line.rstrip("\n") for line in handle]
    blocks: List[bytes] = []
    newline_count = 0
    with path.open("rb") as handle:
        handle.seek(0, os.SEEK_END)
        pos = handle.tell()
        while pos > 0 and newline_count <= max_lines:
            size = min(65536, pos)
            pos -= size
            handle.seek(pos)
            block = handle.read(size)
            blocks.append(block)
            newline_count += block.count(b"\n")
    return b"".join(reversed(blocks)).decode("utf-8", errors="ignore").splitlines()[-max_lines:]

def read_jsonl(path: Path, max_lines: int=1000) -> List[Dict[str, Any]]:
    if not path.exists(): return []
    try:
        out=[]
        for ln in _tail_text_lines(path, int(max_lines)):
            try:
                if ln.strip():
                    o=json.loads(ln)
                    if isinstance(o,dict): out.append(o)
            except Exception: pass
        return out
    except Exception: return []

def _runtime_rss_mb() -> float:
    try:
        for line in Path('/proc/self/status').read_text(encoding='utf-8', errors='ignore').splitlines():
            if line.startswith('VmRSS:'):
                return round(float(line.split()[1])/1024.0, 2)
    except Exception:
        pass
    return 0.0

def _release_memory_v1050() -> Dict[str, Any]:
    before=_runtime_rss_mb(); collected=gc.collect(); trimmed=False
    try: trimmed=bool(ctypes.CDLL('libc.so.6').malloc_trim(0))
    except Exception: trimmed=False
    after=_runtime_rss_mb()
    return {'rss_before_mb':before,'rss_after_mb':after,'released_mb':round(max(0.0,before-after),2),'gc_collected':int(collected),'malloc_trim':trimmed}
def append_error(path: Path, where: str, exc: BaseException) -> None:
    try:
        path.parent.mkdir(parents=True, exist_ok=True)
        with path.open("a", encoding="utf-8") as f:
            f.write(f"[{now_text()}] {where}: {exc.__class__.__name__}: {exc}\n")
            f.write(traceback.format_exc()[-1500:]+"\n")
    except Exception: pass
def ticker_norm(x: Any) -> str:
    t = str(x or "").strip().upper().replace("/", "-").replace("_", "-")
    parts=[p for p in t.split("-") if p]
    if len(parts)>=2:
        non=[p for p in parts if p != "KRW"]
        t = non[-1] if non else parts[-1]
    if t.endswith("KRW") and len(t)>3: t=t[:-3]
    return t.strip().upper()
def pct(a: float, b: float) -> float: return ((a-b)/b*100.0) if b else 0.0
def age_sec(path: Path) -> float:
    try: return max(0.0, now_ts()-path.stat().st_mtime)
    except Exception: return 999999.0
def map_rows(obj: Any) -> Dict[str, Dict[str, Any]]:
    if isinstance(obj, dict) and isinstance(obj.get("rows"), list): obj = obj.get("rows")
    elif isinstance(obj, dict) and isinstance(obj.get("rows"), dict): obj = obj.get("rows")
    elif isinstance(obj, dict) and isinstance(obj.get("cache"), dict): obj = obj.get("cache")
    out: Dict[str, Dict[str, Any]] = {}
    if isinstance(obj, list):
        for r in obj:
            if isinstance(r, dict):
                t=ticker_norm(r.get("ticker") or r.get("symbol") or r.get("market"))
                if t: out[t]=r
    elif isinstance(obj, dict):
        for k,v in obj.items():
            t=ticker_norm(k)
            if t and isinstance(v, dict):
                vv=dict(v); vv.setdefault("ticker", t); out[t]=vv
    return out

VERSION="risk_worker_v0.8"
BUILD_LABEL="v1057_canonical_loss_closed_ts_owner_2026-06-26"
INTERVAL_SEC=float(os.getenv("RISK_WORKER_INTERVAL_SEC","10.0")); RETENTION_DAYS=float(os.getenv("RISK_RETENTION_DAYS","2"))
STATUS=BASE_DIR/"clean_risk_status.json"; OUT=BASE_DIR/"clean_risk_filter_cache.json"; ERROR=BASE_DIR/"clean_risk_error.log"; CLOSED=BASE_DIR/"paper_bot_closed.jsonl"; OPEN=BASE_DIR/"paper_bot_open.json"
def write_status(state:str, **extra:Any)->None: save_json(STATUS,{"version":VERSION,"state":state,"pid":os.getpid(),"updated_ts":now_ts(),"updated_text":now_text(),**extra})
def ts_of(r:Dict[str,Any])->float: return fnum(r.get("closed_ts"),r.get("exit_ts"),r.get("closed_at"),r.get("sell_ts"),r.get("updated_ts"),default=0)
def profit(r:Dict[str,Any])->float: return fnum(r.get("profit_pct"),r.get("return_pct"),r.get("pnl_pct"),r.get("profit_rate"),default=0)


def _v1037_net_profit(r: Dict[str, Any]) -> float:
    return fnum(
        r.get("net_after_configured_fee_pct_v983"), r.get("final_realized_pnl_pct"),
        r.get("pnl_pct"), r.get("profit_pct"), r.get("return_pct"), r.get("result_pct"), r.get("net_pct"),
        default=0,
    )


def _v1037_text(value: Any) -> str:
    if value in (None, "", "-", [], {}):
        return ""
    return str(value).strip()


def _v1037_first_dict(*values: Any) -> Dict[str, Any]:
    for value in values:
        if isinstance(value, dict) and value:
            return value
    return {}


def _v1037_candidate_key(row: Dict[str, Any]) -> str:
    row = row if isinstance(row, dict) else {}
    gate = _v1037_first_dict(row.get("loss_reentry_gate_v1037"))
    current = _v1037_first_dict(gate.get("current"), row.get("reentry_event_identity_v1037"))
    evidence = _v1037_first_dict(row.get("entry_evidence_v983"), row.get("entry_evidence"))
    profitability = _v1037_first_dict(row.get("profitability_entry_evidence_v1034"))
    for value in (
        current.get("candidate_key"), row.get("trigger_occurrence_candidate_key_v1037"),
        row.get("candidate_entry_build_key"), evidence.get("candidate_key"),
        profitability.get("candidate_key"), row.get("entry_build_key"), row.get("event_id"), row.get("event_key"),
    ):
        text = _v1037_text(value)
        if text:
            return text
    return ""


def _v1037_decision_key(row: Dict[str, Any]) -> str:
    row = row if isinstance(row, dict) else {}
    gate = _v1037_first_dict(row.get("loss_reentry_gate_v1037"))
    current = _v1037_first_dict(gate.get("current"), row.get("reentry_event_identity_v1037"))
    swing = _v1037_first_dict(row.get("swing_entry_gate_v977"))
    for value in (
        current.get("decision_key"), row.get("paper_decision_key_v926"), row.get("swing_gate_decision_key_v977"),
        swing.get("decision_key"),
    ):
        text = _v1037_text(value)
        if text:
            return text
    return ""


def _v1037_trigger_price(row: Dict[str, Any]) -> float:
    row = row if isinstance(row, dict) else {}
    gate = _v1037_first_dict(row.get("loss_reentry_gate_v1037"))
    current = _v1037_first_dict(gate.get("current"), row.get("reentry_event_identity_v1037"))
    swing = _v1037_first_dict(row.get("swing_entry_gate_v977"))
    plan = _v1037_first_dict(row.get("swing_structure_plan_v977"), swing.get("structure_plan"), row.get("entry_plan"))
    trigger = _v1037_first_dict(plan.get("trigger"))
    return fnum(
        current.get("trigger_price"), row.get("swing_trigger_price_v977"), row.get("trigger_price"),
        trigger.get("rounded_price"), trigger.get("raw_price"), swing.get("trigger_price"),
        default=0.0,
    )


def _v1037_file_signature(path: Path) -> Dict[str, Any]:
    try:
        st=path.stat()
        return {"inode":int(st.st_ino),"size":int(st.st_size),"mtime_ns":int(st.st_mtime_ns)}
    except Exception:
        return {"inode":-1,"size":-1,"mtime_ns":-1}


def _v1037_loss_event(row: Dict[str, Any], ticker: str) -> Dict[str, Any]:
    row = row if isinstance(row, dict) else {}
    closed_ts = ts_of(row)
    candidate_key = _v1037_candidate_key(row)
    decision_key = _v1037_decision_key(row)
    trigger_price = _v1037_trigger_price(row)
    exit_price = fnum(row.get("exit_price"), row.get("sell_price"), row.get("close_price"), row.get("current_price"), default=0.0)
    loss_event_key = f"{ticker}|{decision_key or '-'}|{int(closed_ts*1000) if closed_ts>0 else 0}"
    return {
        "schema":"loss_reentry_previous_loss_v1037", "ticker":ticker, "loss_event_key":loss_event_key,
        "candidate_key":candidate_key or None, "decision_key":decision_key or None,
        "trigger_price":round(trigger_price, 12) if trigger_price>0 else None,
        "exit_price":round(exit_price, 12) if exit_price>0 else None,
        "closed_ts":closed_ts or None, "profit_pct":_v1037_net_profit(row),
        "exit_reason":row.get("exit_reason") or row.get("exit_rule"),
        "identity_complete":bool(candidate_key and decision_key and trigger_price>0 and closed_ts>0),
        "source":"paper_bot_closed.jsonl exact OPEN-time identity",
        "policy":"major/setup/target/invalid lines may remain; current Strategy trigger occurrence must prove a reset/rebreak after this loss",
    }


def _iter_jsonl_reverse_v1053(path: Path, max_lines: int):
    """Yield newest complete JSONL rows without materializing a multi-gigabyte tail."""
    if max_lines <= 0 or not path.exists():
        return
    yielded=0; carry=b''
    with path.open('rb') as handle:
        handle.seek(0,os.SEEK_END); pos=handle.tell()
        while pos>0 and yielded<max_lines:
            size=min(65536,pos); pos-=size; handle.seek(pos)
            data=handle.read(size)+carry
            parts=data.split(b'\n')
            carry=parts[0]
            for raw in reversed(parts[1:]):
                if yielded>=max_lines: break
                if not raw.strip(): continue
                try: obj=json.loads(raw.decode('utf-8','ignore'))
                except Exception: continue
                if isinstance(obj,dict):
                    yielded+=1; yield obj
        if yielded<max_lines and carry.strip():
            try: obj=json.loads(carry.decode('utf-8','ignore'))
            except Exception: obj=None
            if isinstance(obj,dict): yield obj


def _stream_top_level_values_v1053(path: Path):
    """Incrementally decode one top-level JSON value at a time."""
    if not path.exists():
        return
    dec=json.JSONDecoder(); buf=''; pos=0; eof=False; started=False; mode=''; expect_key=True; current_key=''
    with path.open('r',encoding='utf-8',errors='ignore') as handle:
        def refill():
            nonlocal buf,pos,eof
            if pos>0: buf=buf[pos:]; pos=0
            chunk=handle.read(65536)
            if chunk=='': eof=True
            else: buf+=chunk
        refill()
        while True:
            while pos<len(buf) and buf[pos].isspace(): pos+=1
            if not started:
                if pos>=len(buf):
                    if eof: return
                    refill(); continue
                mode=buf[pos]; started=True; pos+=1
                if mode not in '{[': return
            while pos<len(buf) and buf[pos].isspace(): pos+=1
            if pos>=len(buf):
                if eof: return
                refill(); continue
            if mode=='{' and buf[pos]=='}': return
            if mode=='[' and buf[pos]==']': return
            try:
                if mode=='{' and expect_key:
                    current_key,newpos=dec.raw_decode(buf,pos)
                    if not isinstance(current_key,str): return
                    pos=newpos
                    while True:
                        while pos<len(buf) and buf[pos].isspace(): pos+=1
                        if pos<len(buf): break
                        if eof: return
                        refill()
                    if buf[pos] != ':': return
                    pos+=1; expect_key=False
                while True:
                    while pos<len(buf) and buf[pos].isspace(): pos+=1
                    try: value,newpos=dec.raw_decode(buf,pos); break
                    except json.JSONDecodeError:
                        if eof: return
                        refill()
                pos=newpos
                yield current_key if mode=='{' else '', value
                if mode=='{': expect_key=True
                while True:
                    while pos<len(buf) and buf[pos].isspace(): pos+=1
                    if pos<len(buf): break
                    if eof: return
                    refill()
                if buf[pos]==',': pos+=1; continue
                if (mode=='{' and buf[pos]=='}') or (mode=='[' and buf[pos]==']'): return
                return
            except json.JSONDecodeError:
                if eof: return
                refill()


def _open_tickers_stream_v1053(path: Path) -> Tuple[List[str],Dict[str,Any]]:
    tickers=[]; rows=0; max_value_chars=0
    try:
        for key,value in _stream_top_level_values_v1053(path) or []:
            rows+=1
            if isinstance(value,dict):
                t=ticker_norm(value.get('ticker') or value.get('market') or value.get('symbol') or key)
            else:
                t=ticker_norm(key)
            if t: tickers.append(t)
            # Do not serialize the already-decoded position again just for diagnostics.
            del value
    except Exception:
        tickers=[]; rows=0
    return tickers,{'open_stream_rows_v1053':rows,'open_stream_max_value_bytes_v1053':max_value_chars,'open_full_object_loaded_v1053':False}

# v655: CLOSED/OPEN 파일이 변하지 않았으면 위험 cache를 재계산하지 않는다.
# risk_worker는 최근 손실 cooldown의 주인이고, strategy_worker는 그 cache를 읽는다.
_LAST_FP: tuple = ()
_LAST_RESULT: Dict[str, Any] = {}
_LAST_METRICS: Dict[str, Any] = {}

def _v655_file_fp(path: Path) -> tuple:
    try:
        st = path.stat()
        return (int(st.st_ino), int(st.st_size), int(st.st_mtime_ns))
    except Exception:
        return (0.0, 0)

def run_once()->Dict[str,Any]:
    global _LAST_FP, _LAST_RESULT, _LAST_METRICS
    st=now_ts(); cutoff=now_ts()-RETENTION_DAYS*86400
    fp = (_v655_file_fp(CLOSED), _v655_file_fp(OPEN))
    if fp == _LAST_FP and _LAST_RESULT:
        m = dict(_LAST_METRICS)
        write_status("running", phase="cached_v655", cached=True, last_sec=round(now_ts()-st,3), **m)
        return dict(_LAST_RESULT)
    write_status("running", phase="reading", recent_closed=0, risk_count=0, open_count=0, last_sec=0)
    closed_signature_before_v1037=_v1037_file_signature(CLOSED)
    by:Dict[str,List[Dict[str,Any]]]={}; last_loss_event_by_ticker:Dict[str,Dict[str,Any]]={}
    scanned=0; recent_scanned=0; loss_rows_considered_v1057=0; loss_rows_missing_closed_ts_v1057=0; latest_loss_replacements_v1057=0
    for r in _iter_jsonl_reverse_v1053(CLOSED,2500) or []:
        scanned+=1; t=ticker_norm(r.get('ticker'))
        if not t: continue
        row_closed_ts=ts_of(r)
        if recent_scanned<600:
            recent_scanned+=1
            if row_closed_ts>=cutoff or row_closed_ts==0:
                by.setdefault(t,[]).append({'ticker':t,'closed_at':row_closed_ts,'profit_pct':profit(r)})
        mode=str(r.get('strategy_mode') or r.get('strategy_mode_v977') or '').upper()
        if mode=='ALT_SWING_V977' and _v1037_net_profit(r)<0:
            loss_rows_considered_v1057+=1
            if row_closed_ts<=0:
                loss_rows_missing_closed_ts_v1057+=1
            else:
                prior=last_loss_event_by_ticker.get(t) if isinstance(last_loss_event_by_ticker.get(t),dict) else {}
                prior_ts=fnum(prior.get('closed_ts'),default=0.0)
                if row_closed_ts>prior_ts:
                    if prior: latest_loss_replacements_v1057+=1
                    last_loss_event_by_ticker[t]=_v1037_loss_event(r,t)
        del r
    risks=[]; cooldown={}; recent_count=sum(len(v) for v in by.values())
    for t,rs in by.items():
        rs=sorted(rs,key=ts_of,reverse=True); last=rs[0] if rs else {}; losses=[r for r in rs[:5] if profit(r)<=-0.45]; hard=[r for r in rs[:5] if profit(r)<=-0.9]
        level='ok'; reasons=[]
        if len(hard)>=1: level='hard_recent'; reasons.append('최근하드손실')
        if len(losses)>=2: level='loss_cluster'; reasons.append('최근반복손실')
        if level!='ok': cooldown[t]={'level':level,'reasons':reasons,'last_profit':profit(last),'last_ts':ts_of(last)}; risks.append({'ticker':t,**cooldown[t]})
    closed_signature_after_v1037=_v1037_file_signature(CLOSED)
    source_complete_v1037=closed_signature_before_v1037==closed_signature_after_v1037
    open_ticks,open_meta=_open_tickers_stream_v1053(OPEN)
    loss_contract_v1057={
        'schema':'loss_reentry_source_contract_v1057','owner':'risk_worker','source_complete':source_complete_v1037,
        'closed_signature':closed_signature_after_v1037,'event_map_field':'last_loss_event_by_ticker',
        'event_count':len(last_loss_event_by_ticker),'latest_loss_selection':'max_numeric_closed_ts_per_ticker',
        'closed_ts_owner':'paper CLOSED numeric closed_ts','thresholds_changed':False,
    }
    save_json(OUT,{'version':VERSION,'build':BUILD_LABEL,'schema':'risk_filter_v1057_canonical_loss_closed_ts','updated_ts':now_ts(),'updated_text':now_text(),'retention_days':RETENTION_DAYS,'recent_closed':recent_count,'closed_rows_scanned_v1037':scanned,'closed_signature_v1037':closed_signature_after_v1037,'source_complete_v1037':source_complete_v1037,'loss_reentry_source_contract_v1057':loss_contract_v1057,'loss_rows_considered_v1057':loss_rows_considered_v1057,'loss_rows_missing_closed_ts_v1057':loss_rows_missing_closed_ts_v1057,'latest_loss_replacements_v1057':latest_loss_replacements_v1057,'risk_count':len(risks),'open_tickers':[x for x in open_ticks if x],'cooldown':cooldown,'last_loss_event_by_ticker':last_loss_event_by_ticker,'last_loss_event_count':len(last_loss_event_by_ticker),'risks':risks[:80],**open_meta,'policy':'one stable Risk->Paper loss-reentry contract; ticker latest loss is max numeric closed_ts within bounded exact tail; OPEN streams one top-level value at a time; thresholds unchanged'})
    sec=now_ts()-st
    del by
    memory_v1053=_release_memory_v1050()
    _LAST_FP=fp
    _LAST_RESULT={'risk':len(risks),'last_loss_event_count':len(last_loss_event_by_ticker)}
    _LAST_METRICS={'recent_closed':recent_count,'risk_count':len(risks),'open_count':len(open_ticks),'last_loss_event_count':len(last_loss_event_by_ticker),'source_complete_v1037':source_complete_v1037,'loss_reentry_contract_ready_v1057':source_complete_v1037,'loss_rows_considered_v1057':loss_rows_considered_v1057,'loss_rows_missing_closed_ts_v1057':loss_rows_missing_closed_ts_v1057,'latest_loss_replacements_v1057':latest_loss_replacements_v1057,'latest_loss_selection_v1057':'max_numeric_closed_ts_per_ticker','closed_tail_rows_v1053':scanned,'closed_tail_recent_rows_v1053':recent_scanned,'single_closed_scan_v1053':True,**open_meta}
    write_status('running',cached=False,**_LAST_METRICS,memory_reclaim_v1053=memory_v1053,last_sec=round(sec,3))
    return dict(_LAST_RESULT)

def main()->None:
    write_status("running", phase="boot", recent_closed=0, risk_count=0, open_count=0, last_sec=0)
    while True:
        try: run_once()
        except KeyboardInterrupt: write_status("stopping"); raise
        except Exception as exc: append_error(ERROR,"loop",exc); write_status("error", error=f"{exc.__class__.__name__}: {exc}")
        time.sleep(max(3.0,INTERVAL_SEC))

# v1068 exact active-spine release identity
VERSION = "risk_worker_v0.9"
BUILD_LABEL = "v1068_exact_active_spine_zero_duplicate_defs_2026-06-27"

if __name__=="__main__": main()
