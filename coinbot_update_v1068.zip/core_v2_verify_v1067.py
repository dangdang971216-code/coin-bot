#!/usr/bin/env python3
# Deployment compatibility entrypoint for the already-running v1067 Guard.
# Runtime verification is owned by core_v2_verify_v1068.py.
from core_v2_verify_v1068 import verify, render
from pathlib import Path
import sys
if __name__ == '__main__':
    base=Path(sys.argv[1] if len(sys.argv)>1 else Path(__file__).resolve().parent)
    out=Path(sys.argv[2] if len(sys.argv)>2 else base/'core_v2_verify_status_v1068.json')
    r=verify(base,out); print(render(r)); raise SystemExit(0 if r.get('pass') else 2)
