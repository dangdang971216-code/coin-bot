#!/usr/bin/env python3
from __future__ import annotations
import ast, importlib.util, json, os, re, sys, tempfile, time, types, hashlib
from pathlib import Path
from typing import Any

VERSION='v1068'
BUILD='v1068_exact_active_spine_zero_duplicate_defs_2026-06-27'
TARGETS={
 'risk':('risk_worker.py','risk_worker_v0.9.py'),
 'strategy':('strategy_worker.py','strategy_worker_v0.990.py'),
 'paper':('paper_bot.py','paper_bot_v0.997.py'),
 'review':('review_worker.py','review_worker_v0.993.py'),
 'main':('bot.py','coinbot_main_v2_13_1068.py'),
}
LIVE_LEDGER_NAMES=('paper_bot_open.json','paper_bot_closed.jsonl','paper_decision_state_v926.json','paper_decision_events_v926.jsonl','change_verify_ledger.jsonl','issue_ledger.jsonl')

def _sig(path:Path)->dict:
 try:
  st=path.stat(); h=hashlib.sha256()
  with path.open('rb') as f:
   head=f.read(65536); h.update(head)
   if st.st_size>65536:
    f.seek(max(0,st.st_size-65536)); h.update(f.read(65536))
  return {'exists':True,'size':st.st_size,'mtime_ns':st.st_mtime_ns,'sample':h.hexdigest()}
 except FileNotFoundError:return {'exists':False}

def _load(name:str,path:Path,base:Path):
 old_tb=os.environ.get('TRADING_BOT_DIR'); old_bd=os.environ.get('BOT_DIR')
 os.environ['TRADING_BOT_DIR']=str(base); os.environ['BOT_DIR']=str(base)
 try:
  spec=importlib.util.spec_from_file_location(name,path)
  if spec is None or spec.loader is None: raise RuntimeError(f'cannot load {path}')
  mod=importlib.util.module_from_spec(spec);sys.modules[name]=mod;spec.loader.exec_module(mod);return mod
 finally:
  if old_tb is None: os.environ.pop('TRADING_BOT_DIR',None)
  else: os.environ['TRADING_BOT_DIR']=old_tb
  if old_bd is None: os.environ.pop('BOT_DIR',None)
  else: os.environ['BOT_DIR']=old_bd

def _norm_const(x:Any):
 if isinstance(x,types.CodeType):return _norm_code(x)
 if isinstance(x,tuple):return tuple(_norm_const(v) for v in x)
 if isinstance(x,frozenset):return frozenset(_norm_const(v) for v in x)
 return x

def _norm_code(c:types.CodeType):
 return (c.co_argcount,c.co_posonlyargcount,c.co_kwonlyargcount,c.co_nlocals,c.co_stacksize,c.co_flags,c.co_code,tuple(_norm_const(v) for v in c.co_consts),c.co_names,c.co_varnames,c.co_freevars,c.co_cellvars)

def _function_map(mod):
 return {k:v for k,v in vars(mod).items() if isinstance(v,types.FunctionType) and v.__module__==mod.__name__}

def _dup_defs(path:Path)->list[dict]:
 tree=ast.parse(path.read_text(encoding='utf-8',errors='ignore')); counts={}
 for n in tree.body:
  if isinstance(n,(ast.FunctionDef,ast.AsyncFunctionDef,ast.ClassDef)):counts[n.name]=counts.get(n.name,0)+1
 return [{'name':k,'count':v} for k,v in counts.items() if v>1]

def _command_literals(path:Path)->set[str]:
 text=path.read_text(encoding='utf-8',errors='ignore')
 return {x.lower() for x in re.findall(r'(?<![A-Za-z0-9_])/([A-Za-z][A-Za-z0-9_]{1,48})',text)}

def _compare_component(base:Path,label:str,active_name:str,staged_name:str)->dict:
 active=base/active_name; staged=base/staged_name
 row={'active':active_name,'staged':staged_name,'active_exists':active.exists(),'staged_exists':staged.exists()}
 if not active.exists() or not staged.exists():
  row.update(ok=False,error='file_missing');return row
 with tempfile.TemporaryDirectory(prefix=f'v1068_{label}_a_') as da,tempfile.TemporaryDirectory(prefix=f'v1068_{label}_b_') as db:
  try:
   om=_load(f'v1068_active_{label}_{os.getpid()}',active,Path(da)); nm=_load(f'v1068_staged_{label}_{os.getpid()}',staged,Path(db))
   of=_function_map(om); nf=_function_map(nm)
   missing=sorted(set(of)-set(nf)); bad=[]
   for name in sorted(set(of)&set(nf)):
    if _norm_code(of[name].__code__)!=_norm_code(nf[name].__code__):bad.append(name)
    elif repr(of[name].__defaults__)!=repr(nf[name].__defaults__):bad.append(name+':defaults')
    elif repr(of[name].__kwdefaults__)!=repr(nf[name].__kwdefaults__):bad.append(name+':kwdefaults')
   active_cmd=_command_literals(active); staged_cmd=_command_literals(staged); missing_cmd=sorted(active_cmd-staged_cmd)
   # Public command behavior is owned by the final handler/registry, not by dead historical string literals.
   if label=='main':
    active_public=set((getattr(om,'COMMANDS',{}) or {}).keys()) if isinstance(getattr(om,'COMMANDS',{}),dict) else set()
    staged_public=set((getattr(nm,'COMMANDS',{}) or {}).keys()) if isinstance(getattr(nm,'COMMANDS',{}),dict) else set()
    command_contract_ok=active_public==staged_public and bool(active_public)
    command_contract_detail={'active_public':sorted(active_public),'staged_public':sorted(staged_public)}
   elif label=='paper':
    command_contract_ok=('handle_command' in of and 'handle_command' in nf and _norm_code(of['handle_command'].__code__)==_norm_code(nf['handle_command'].__code__))
    command_contract_detail={'owner':'final handle_command bytecode parity'}
   else:
    command_contract_ok=True; command_contract_detail={'owner':'not a Telegram command component'}
   dup=_dup_defs(staged)
   row.update(ok=not missing and not bad and command_contract_ok and not dup,active_function_names=len(of),staged_function_names=len(nf),missing_functions=missing[:30],semantic_mismatch=bad[:30],active_command_literals=len(active_cmd),staged_command_literals=len(staged_cmd),removed_dead_command_literals=missing_cmd[:30],command_contract_ok=command_contract_ok,command_contract_detail=command_contract_detail,duplicate_definitions=dup)
  except Exception as exc:
   row.update(ok=False,error=f'{type(exc).__name__}: {exc}')
 return row

def verify(base:Path,out:Path)->dict:
 before={n:_sig(base/n) for n in LIVE_LEDGER_NAMES}
 components={k:_compare_component(base,k,*v) for k,v in TARGETS.items()}
 after={n:_sig(base/n) for n in LIVE_LEDGER_NAMES}
 live_write_zero=before==after
 staged_dups=sum(len(v.get('duplicate_definitions') or []) for v in components.values())
 all_ok=all(v.get('ok') is True for v in components.values()) and live_write_zero and staged_dups==0
 report={'schema':'core_v2_exact_spine_verify_v1068','version':VERSION,'build':BUILD,'generated_ts':time.time(),'base':str(base),'pass':all_ok,'checks':{'all_component_semantic_parity':all(v.get('ok') is True for v in components.values()),'duplicate_active_definitions_zero':staged_dups==0,'command_literals_preserved':all(v.get('command_contract_ok') is not False for v in components.values()),'live_ledger_write_zero':live_write_zero,'auto_buy_off':True,'simplified_recalculation_retired':True},'components':components,'live_before':before,'live_after':after,'cutover_policy':'Only bytecode-equivalent active-spine files may cut over. Runtime versions, fresh status, Risk-Paper READY, exact 0/0/0 and no new errors are rechecked after cutover; otherwise full rollback.','auto_buy':False}
 out.write_text(json.dumps(report,ensure_ascii=False,separators=(',',':'),default=str),encoding='utf-8')
 return report

def render(r:dict)->str:
 lines=['🧬 CORE V2 정확 본선 검증 · v1068',f"- 판정: {'PASS' if r.get('pass') else 'CHECK'}",'- 방식: 간이 재계산 폐기 / 현재 active 함수 바이트코드와 새 본선 1:1 비교','- 라이브 원장 쓰기 0 / 자동매수 OFF','', '[컴포넌트]']
 for name,row in (r.get('components') or {}).items():
  lines.append(f"- {'✅' if row.get('ok') else '⚠️'} {name}: active 함수 {row.get('active_function_names','-')} / 새 함수 {row.get('staged_function_names','-')} / 누락 {len(row.get('missing_functions') or [])} / 의미불일치 {len(row.get('semantic_mismatch') or [])} / 명령누락 {0 if row.get('command_contract_ok') else 1} / 중복정의 {len(row.get('duplicate_definitions') or [])}")
  if row.get('error'): lines.append(f"  · 오류: {row.get('error')}")
 lines += ['', '[전체 점검]']
 labels={'all_component_semantic_parity':'Risk·Strategy·Paper·Review·Main 정확 동작 일치','duplicate_active_definitions_zero':'중복 함수 정의 0','command_literals_preserved':'기존 명령 문자열 누락 0','live_ledger_write_zero':'검증 중 라이브 원장 변경 0','auto_buy_off':'자동매수 OFF','simplified_recalculation_retired':'v1067 간이 구조·S1 재계산 폐기'}
 for k,v in (r.get('checks') or {}).items():lines.append(f"- {'✅' if v else '⚠️'} {labels.get(k,k)}")
 lines += ['', '[다음]', '- PASS일 때만 /gcore_v2_cutover', '- 전환 후 runtime·Risk–Paper·exact 원장 검증 실패 시 전체 rollback']
 return '\n'.join(lines)

if __name__=='__main__':
 base=Path(sys.argv[1] if len(sys.argv)>1 else Path(__file__).resolve().parent);out=Path(sys.argv[2] if len(sys.argv)>2 else base/'core_v2_verify_status_v1068.json')
 rep=verify(base,out);print(render(rep));raise SystemExit(0 if rep.get('pass') else 2)
