v1411 MINIMAL TARGETED GUARD BUNDLE RESTORE
- 수정 파일만 포함: backga_guard_bot.py, backga_guard_bot_v2_5_1411.py
- workers/main/paper/ws/micro 미포함: 적용·재시작 대상 아님
- 디스크정리/감사/helper 없음
- 전략수치·자동매수 변경 없음
