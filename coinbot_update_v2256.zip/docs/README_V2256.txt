코인봇 v2256 코드추적·단일 owner 수리

- Main의 최종 Paper reader가 exact 상태파일을 읽던 실제 active-path 오류를 runtime paper_bot_status.json으로 직접 수정.
- Paper runtime OPEN과 성과 OPEN을 분리해 같은 canonical status에서 일치 여부를 증명.
- OPEN 손익은 last_pnl_pct를 포함해 읽고 누락을 0%로 덮지 않음.
- Strategy는 상승예측 자료정상/누락, 속도 양수, 지속성 양수, 둘 다 양수, 최종통과와 보류 원인을 한 writer에서 저장.
- Review는 진입 당시 봉인식 성과를 보존하고 현재 활성식 재생을 별도로 계산. 현재식 통과는 score>0이 아니라 CONTINUATION_FAVORED state 기준.
- v2255 상승예측 수치·가중치·양수선은 다시 바꾸지 않음. 데이터 연결과 판정 증명만 수리.
- 새 Shadow 없음, 후보 삭제 0, BUY_READY 강제 0, 자동매수 OFF.
