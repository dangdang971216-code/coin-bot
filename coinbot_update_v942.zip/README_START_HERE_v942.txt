v942 active legacy 대형 cache 제거판. docs 인수인계와 APPLY_AFTER_v942.txt 확인. guard 변경이라 2단계 적용.
