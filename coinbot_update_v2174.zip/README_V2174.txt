v2174 root repair
- WAIT_TRIGGER contract id and decision-key template are presealed
- one completed trigger bar creates one event id shared by fast/full cycles
- fast direct S1 reuses the current canonical candidate commit
- Paper first receipt timestamp is immutable; polling never grows latency
- no strategy/candidate-quality/entry/exit number changes
- auto-buy OFF
