# v2205 Review 고정 계약 reader

- 원인: Review 완료본은 READY였지만 Main이 구 schema/worker 버전명만 허용해 정상 snapshot을 거부함.
- 수정: Main은 고정 상태파일·고정 필드의 실제 내용으로만 검증함. 생산 schema와 worker 버전은 표시용임.
- Review 재시작 없음. Main만 교체·재시작.
- 상승예측식, 후보, 구조선, Paper, 청산, 초기화, 원장 변경 없음. 자동매수 OFF.
