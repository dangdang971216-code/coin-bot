#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""target_router_worker_v0.21

정보배차 직원 v0.7.
목표:
- 정보부족 전체를 한꺼번에 WS/micro target으로 밀어넣지 않는다.
- 전체 후보 queue는 보존하되, sidecar가 실제 우선수집할 active target은 우선순위 높은 후보 중심으로 분리한다.
- 개수 고정 전략이 아니라, 우선순위/버킷/서버보호 active window를 분리한다.
"""
from __future__ import annotations
import json, os, time, traceback
from pathlib import Path
from typing import Any, Dict, List, Optional

BASE_DIR = Path(os.getenv("TRADING_BOT_DIR", "/home/dangdang971216/trading_bot"))
VERSION = "target_router_worker_v0.25_structure_recheck_priority_2026-06-10"
INTERVAL_SEC = float(os.getenv("TARGET_ROUTER_INTERVAL_SEC", "1.5"))
# v0.7: 고정 N개 제한을 제거하고, 전체 queue를 보존한 뒤
# sidecar가 감당 가능한 "내보내기 창"만 순환한다.
# 이 값은 전략/후보 제한이 아니라 장애 방지용 export 안전창이다.
# micro sidecar 자체 안전상한(CLEAN_MICRO_TARGET_SAFETY_MAX)과 맞춰 둔다.
EXPORT_SAFETY_WINDOW = int(float(os.getenv("TARGET_ROUTER_EXPORT_SAFETY_WINDOW", os.getenv("CLEAN_MICRO_TARGET_SAFETY_MAX", "180"))))
HIGH_PRIORITY_THRESHOLD = float(os.getenv("TARGET_ROUTER_HIGH_PRIORITY", "85"))
HOT_ROTATION_THRESHOLD = float(os.getenv("TARGET_ROUTER_HOT_ROTATION_PRIORITY", "72"))
STATUS = BASE_DIR / "clean_target_router_status.json"
ERROR = BASE_DIR / "clean_target_router_error.log"
STRATEGY_REQ = BASE_DIR / "clean_strategy_priority_requests.json"
FEATURE = BASE_DIR / "clean_feature_cache.json"
ORDERFLOW = BASE_DIR / "clean_orderflow_summary_cache.json"
PAPER_OPEN = BASE_DIR / "paper_bot_open.json"
S1_HOLD = BASE_DIR / "paper_s1_hold_cache.json"
QUEUE = BASE_DIR / "clean_target_router_queue.json"
WS_TARGETS = BASE_DIR / "clean_ws_targets.json"
MICRO_TARGETS = BASE_DIR / "clean_micro_targets.json"
MICRO_URGENT = BASE_DIR / "clean_micro_urgent_targets.json"
S2_URGENT_STATE = BASE_DIR / "clean_s2_urgent_refresh_state.json"
RECHECK_CACHE = BASE_DIR / "clean_recheck_candidates_cache.json"
HOT = BASE_DIR / "clean_scanner_hot_rank_cache.json"
PAPER_LATEST = BASE_DIR / "paper_candidates_latest.jsonl"
ORDERFLOW_MICRO_URGENT = BASE_DIR / "clean_orderflow_micro_urgent_targets.json"
ORDERFLOW_MICRO_URGENT_ACK = BASE_DIR / "clean_orderflow_micro_urgent_ack.json"
RECHECK_FRESH_MAX_SEC = float(os.getenv("TARGET_ROUTER_RECHECK_FRESH_MAX_SEC", "480"))

CRITICAL_BUCKETS = {"open_position", "spike_fast_urgent", "s_candidate", "paper_handoff", "near_s_info_wait", "s_near_info", "s1_info_wait", "s1_safety_info_wait", "s1_candidate", "recheck_s1_promote", "recheck_s1_wait", "s2_candidate_refresh", "s1_candidate_refresh", "s1_hold_open_ready", "s1_hold_final_check"}
HIGH_BUCKETS = {"info_wait_high", "high_score_info_wait", "s2_recheck_info_wait", "s2_recheck_soft", "s3_observe_soft", "recheck_partial", "recheck_info_wait", "recheck_near_s", "quality_recheck_s2", "flow_trap_watch", "structure_recheck_s2"}
LOW_BUCKETS = {"market_rotation", "normal_rotation", "normal_info_wait", "hard_blocked_info_wait"}

INFO_PRIORITY_PREFIXES_V676 = ("v675_T0", "v675_T2", "v675_T3", "v675_T4", "v675_T5", "v675_T6", "v676_T0", "v676_T2", "v676_T3", "v676_T4", "v676_T5", "v676_T6")
def is_high_bucket_name(bucket: Any) -> bool:
    b = str(bucket or "")
    return b in HIGH_BUCKETS or b.startswith(INFO_PRIORITY_PREFIXES_V676)

def is_critical_bucket_name(bucket: Any) -> bool:
    b = str(bucket or "")
    return b in CRITICAL_BUCKETS or b.startswith(("v675_T0", "v676_T0"))


def now_ts() -> float:
    return time.time()

def now_text(ts: Optional[float] = None) -> str:
    return time.strftime("%Y-%m-%d %H:%M:%S", time.localtime(ts or now_ts()))

def fnum(*vals: Any, default: float = 0.0) -> float:
    for v in vals:
        try:
            if v is None or v == "":
                continue
            return float(str(v).replace(",", "").replace("%", ""))
        except Exception:
            continue
    return default

def ticker_norm(x: Any) -> str:
    t = str(x or "").strip().upper().replace("/", "-").replace("_", "-")
    parts = [p for p in t.split("-") if p]
    if len(parts) >= 2:
        non = [p for p in parts if p != "KRW"]
        t = non[-1] if non else parts[-1]
    if t.endswith("KRW") and len(t) > 3:
        t = t[:-3]
    return t.strip().upper()

def load_json(path: Path, default: Any = None) -> Any:
    try:
        if not path.exists():
            return default
        return json.loads(path.read_text(encoding="utf-8", errors="ignore"))
    except Exception:
        return default

def save_json(path: Path, obj: Any) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    tmp = path.with_suffix(path.suffix + ".tmp")
    tmp.write_text(json.dumps(obj, ensure_ascii=False, separators=(",", ":"), default=str), encoding="utf-8")
    os.replace(tmp, path)

def read_jsonl(path: Path, max_lines: int = 0) -> List[Dict[str, Any]]:
    try:
        if not path.exists():
            return []
        lines = path.read_text(encoding="utf-8", errors="ignore").splitlines()
        if max_lines and len(lines) > max_lines:
            lines = lines[-max_lines:]
        out: List[Dict[str, Any]] = []
        for line in lines:
            line = line.strip()
            if not line:
                continue
            try:
                obj = json.loads(line)
                if isinstance(obj, dict):
                    out.append(obj)
            except Exception:
                continue
        return out
    except Exception:
        return []

def append_error(where: str, exc: BaseException) -> None:
    try:
        ERROR.parent.mkdir(parents=True, exist_ok=True)
        with ERROR.open("a", encoding="utf-8") as f:
            f.write(f"[{now_text()}] {where}: {exc.__class__.__name__}: {exc}\n")
            f.write(traceback.format_exc()[-1600:] + "\n")
    except Exception:
        pass

def write_status(state: str, **extra: Any) -> None:
    save_json(STATUS, {"version": VERSION, "state": state, "pid": os.getpid(), "updated_ts": now_ts(), "updated_text": now_text(), **extra})

def map_rows(obj: Any) -> Dict[str, Dict[str, Any]]:
    if isinstance(obj, dict) and isinstance(obj.get("rows"), list):
        obj = obj.get("rows")
    elif isinstance(obj, dict) and isinstance(obj.get("rows"), dict):
        obj = obj.get("rows")
    elif isinstance(obj, dict) and isinstance(obj.get("cache"), dict):
        obj = obj.get("cache")
    out: Dict[str, Dict[str, Any]] = {}
    if isinstance(obj, list):
        for r in obj:
            if isinstance(r, dict):
                t = ticker_norm(r.get("ticker") or r.get("symbol") or r.get("market"))
                if t:
                    vv = dict(r); vv.setdefault("ticker", t)
                    out[t] = vv
    elif isinstance(obj, dict):
        for k, v in obj.items():
            if isinstance(v, dict):
                t = ticker_norm(k)
                vv = dict(v); vv.setdefault("ticker", t)
                out[t] = vv
    return out

def _open_tickers() -> List[str]:
    obj = load_json(PAPER_OPEN, {}) or {}
    out: List[str] = []
    if isinstance(obj, dict):
        values = obj.get("positions") if isinstance(obj.get("positions"), list) else obj.values()
        for r in values:
            if isinstance(r, dict):
                t = ticker_norm(r.get("ticker") or r.get("market") or r.get("symbol"))
                if t:
                    out.append(t)
    return out

def _request_rows() -> List[Dict[str, Any]]:
    obj = load_json(STRATEGY_REQ, {}) or {}
    rows = obj.get("requests") if isinstance(obj, dict) else []
    return rows if isinstance(rows, list) else []


def _stage_of_candidate(row: Dict[str, Any]) -> str:
    st = str(row.get("s_stage") or row.get("candidate_grade") or row.get("candidate_stage") or row.get("stage") or row.get("grade") or "").upper()
    return st if st in {"S1", "S2", "S3"} else ""

def _row_age_sec(row: Dict[str, Any], ts: Optional[float] = None) -> float:
    nowv = ts or now_ts()
    raw = fnum(row.get("updated_ts"), row.get("created_ts"), row.get("event_ts"), row.get("ts"), row.get("created_at"), default=0.0)
    return max(0.0, nowv - raw) if raw > 0 else 0.0

def _iter_recheck_cache_rows(obj: Any) -> List[Dict[str, Any]]:
    if not isinstance(obj, dict):
        return []
    rows: List[Dict[str, Any]] = []
    for key in ("top", "rows", "candidates", "items", "display", "display_rows", "top_candidates"):
        val = obj.get(key)
        if isinstance(val, list):
            rows.extend([x for x in val if isinstance(x, dict)])
    # 중복 key가 있어도 뒤에서 ticker 기준으로 한 번 더 정리한다.
    return rows

def _paper_latest_recheck_rows() -> List[Dict[str, Any]]:
    """v497 fallback: recheck cache schema가 바뀌거나 늦어도 S2/S3 후보를 정보배차에서 잃지 않는다.
    조건/승격을 여기서 판단하지 않는다. S2/S3 row를 micro/orderflow 보강 대상으로만 올린다.
    """
    nowv = now_ts()
    rows: List[Dict[str, Any]] = []
    for row in read_jsonl(PAPER_LATEST, max_lines=0):
        if not isinstance(row, dict):
            continue
        st = _stage_of_candidate(row)
        if st not in {"S1", "S2", "S3"}:
            continue
        age = _row_age_sec(row, nowv)
        # timestamp가 있는 오래된 row는 늦은진입을 막기 위해 배차에서 제외한다. timestamp가 없으면 표시만 남기고 낮은 가점으로 보낸다.
        if age > RECHECK_FRESH_MAX_SEC and age > 0:
            continue
        rows.append(row)
    return rows

def _recheck_bucket_state(it: Dict[str, Any], state: str, block: List[Any], missing: List[Any]) -> str:
    lane = str(((it.get("condition_policy_v480") if isinstance(it.get("condition_policy_v480"), dict) else {}) or {}).get("lane") or "")
    # v0.25/v788: strategy_worker가 확정 저장한 S2 재확인 결과를 target bucket에 직접 반영한다.
    # 조건/S등급 변경이 아니라 fresh/trigger/confirm/exec 정보수집 우선순위 분리다.
    outcome = it.get("s2_recheck_outcome_v788") if isinstance(it.get("s2_recheck_outcome_v788"), dict) else {}
    s2_state = str(it.get("s2_recheck_last_state_v788") or outcome.get("state") or "")
    qroute = it.get('quality_route_v810') if isinstance(it.get('quality_route_v810'), dict) else {}
    if bool(it.get('quality_recheck_s2_v810') or qroute.get('quality_recheck_s2')):
        return 'quality_recheck_s2'
    if bool(it.get('flow_trap_watch_v810') or qroute.get('flow_trap_watch')):
        return 'flow_trap_watch'
    if s2_state == "fresh_wait":
        return "recheck_info_wait"
    if s2_state == "trigger_wait":
        return "recheck_s1_wait"
    if s2_state in {"confirm_wait", "exec_risk_wait", "s2_recheck_active"}:
        return "recheck_partial"
    if s2_state == "hard_risk_hold":
        return "recheck_near_s"
    if any("상대기준" in str(x) or "정보" in str(x) or "미확정" in str(x) for x in list(block) + list(missing)):
        return "recheck_info_wait"
    if state in {"S1승격", "승격대기"}:
        return "recheck_s1_wait"
    if state == "부분확인":
        return "recheck_partial"
    if lane == "flexible_recheck":
        return "recheck_partial"
    return "recheck_near_s"



def _s1_hold_urgent_rows_v746() -> List[Dict[str, Any]]:
    """v750: S1 hold/open 직전 후보는 target_router P0 lane으로 직접 올린다.
    후보 수 제한이 아니라 정보수집 우선순위다.
    """
    obj = load_json(S1_HOLD, {}) or {}
    raw: List[Dict[str, Any]] = []
    if isinstance(obj, dict):
        for key in ("rows", "candidates", "items", "holds", "open_ready", "data"):
            val = obj.get(key)
            if isinstance(val, list):
                raw.extend([x for x in val if isinstance(x, dict)])
        if not raw:
            for v in obj.values():
                if isinstance(v, dict):
                    raw.append(v)
                elif isinstance(v, list):
                    raw.extend([x for x in v if isinstance(x, dict)])
    elif isinstance(obj, list):
        raw = [x for x in obj if isinstance(x, dict)]
    out: Dict[str, Dict[str, Any]] = {}
    nowv = now_ts()
    for r in raw:
        t = ticker_norm(r.get("ticker") or r.get("market") or r.get("symbol"))
        if not t:
            continue
        age = _row_age_sec(r, nowv)
        status = str(r.get("s1_hold_status_v738") or r.get("s1_hold_status_v737") or r.get("s1_hold_status_v736") or r.get("s1_hold_status_v735") or r.get("s1_hold_status_v734") or r.get("hold_status") or "s1_hold")
        pri = 990.0 if "open_ready" in status else 930.0
        row = {
            "ticker": t,
            "priority": round(pri + max(0.0, 60.0 - min(60.0, age)), 3),
            "bucket": "s1_hold_open_ready" if "open_ready" in status else "s1_hold_final_check",
            "need": ["ws", "micro", "orderflow"],
            "source": "paper_s1_hold_cache_v751_priority_refresh",
            "candidate_stage": "S1",
            "hold_status": status,
            "candidate_age_sec": round(age, 1),
            "micro_urgent": True,
            "strategy_force_active": True,
            "target_router_policy_v750": "P0 S1 hold/open 직전 후보는 OPEN 전 최신값 재봉인용으로 최우선 refresh",
        }
        old = out.get(t)
        if old is None or fnum(row.get("priority"), default=0.0) > fnum(old.get("priority"), default=0.0):
            out[t] = row
    return sorted(out.values(), key=lambda x: fnum(x.get("priority"), default=0.0), reverse=True)

def _recheck_request_rows() -> List[Dict[str, Any]]:
    """v497: recheck 후보 -> target_router -> micro/orderflow 배차 단일 경로.
    - recheck cache만 믿지 않고 paper_latest S2/S3를 fallback으로 함께 읽는다.
    - 고정 N개 제한 없이 ticker별 최고 priority만 남긴다.
    - 이것은 조건 완화/승격이 아니라 정보 보강 요청이다.
    """
    # v525: legacy clean_recheck_candidates_cache is no longer a source.
    # Recheck dispatch reads the same canonical paper_candidates_latest.jsonl as main/paper.
    cache_rows: List[Dict[str, Any]] = []
    latest_rows = _paper_latest_recheck_rows()
    merged: Dict[str, Dict[str, Any]] = {}
    source_counts: Dict[str, int] = {"paper_latest": 0}

    def add_item(it: Dict[str, Any], idx: int, source: str) -> None:
        t = ticker_norm(it.get("ticker") or it.get("market") or it.get("symbol"))
        if not t:
            return
        state = str(it.get("recheck_state") or ("재확인중" if source == "cache" else _stage_of_candidate(it) or "S2/S3"))
        gate = it.get("s1_promotion_gate") if isinstance(it.get("s1_promotion_gate"), dict) else {}
        block = gate.get("block_reasons") if isinstance(gate.get("block_reasons"), list) else (it.get("promotion_block_reasons") if isinstance(it.get("promotion_block_reasons"), list) else [])
        rel = it.get("relative_context") if isinstance(it.get("relative_context"), dict) else {}
        missing = rel.get("missing") if isinstance(rel.get("missing"), list) else (it.get("information_deficits") if isinstance(it.get("information_deficits"), list) else [])
        bucket = _recheck_bucket_state(it, state, list(block), list(missing))
        stage = _stage_of_candidate(it)
        if stage == "S1":
            bucket = "s1_candidate_refresh"
        elif stage == "S2":
            bucket = "s2_candidate_refresh"
        score = fnum(it.get("recheck_score"), it.get("score"), default=0.0)
        base = 620.0 if stage == "S1" else (470.0 if stage == "S2" else (360.0 if state in {"S1승격", "승격대기"} else (285.0 if bucket in {"recheck_info_wait", "recheck_partial"} else 245.0)))
        s2_state_v788 = str(it.get("s2_recheck_last_state_v788") or ((it.get("s2_recheck_outcome_v788") if isinstance(it.get("s2_recheck_outcome_v788"), dict) else {}) or {}).get("state") or "")
        qroute_v810 = it.get('quality_route_v810') if isinstance(it.get('quality_route_v810'), dict) else {}
        qrecheck_v810 = bool(it.get('quality_recheck_s2_v810') or qroute_v810.get('quality_recheck_s2'))
        trap_v810 = bool(it.get('flow_trap_watch_v810') or qroute_v810.get('flow_trap_watch'))
        if qrecheck_v810:
            bucket = 'quality_recheck_s2'
            base += 170.0
        elif trap_v810:
            bucket = 'flow_trap_watch'
            base += 70.0 if stage == 'S1' else -40.0
        if stage == "S2":
            if s2_state_v788 == "trigger_wait":
                base += 80.0
            elif s2_state_v788 in {"confirm_wait", "s2_recheck_active"}:
                base += 60.0
            elif s2_state_v788 in {"fresh_wait", "exec_risk_wait"}:
                base += 45.0
            elif s2_state_v788 == "hard_risk_hold":
                base -= 80.0
        age = _row_age_sec(it)
        # 신선하고 점수 높은 recheck 후보를 먼저 본다. count cap이 아니라 priority score다.
        age_bonus = max(0.0, 80.0 - min(80.0, age / 3.0)) if age > 0 else 20.0
        pri = base + min(80.0, score * 3.0) + age_bonus
        row = {
            "ticker": t,
            "priority": round(pri, 3),
            "bucket": bucket,
            "need": ["ws", "micro", "orderflow"] if stage in {"S1", "S2"} else ["ws", "micro"],
            "source": f"{source}_recheck_v746",
            "micro_urgent": bool(stage in {"S1", "S2"}),
            "strategy_force_active": bool(stage in {"S1", "S2"}),
            "recheck_state": state,
            "candidate_stage": stage,
            "recheck_score": it.get("recheck_score", it.get("score")),
            "candidate_age_sec": round(age, 1),
            "recheck_block_reasons": list(block)[:8],
            "recheck_missing": list(missing)[:8],
            "target_router_recheck_policy": "v497_recheck_candidate_to_priority_queue",
            "s2_recheck_state_v788": str(it.get("s2_recheck_last_state_v788") or ((it.get("s2_recheck_outcome_v788") if isinstance(it.get("s2_recheck_outcome_v788"), dict) else {}) or {}).get("state") or ""),
            "s2_recheck_outcome_v788": it.get("s2_recheck_outcome_v788") if isinstance(it.get("s2_recheck_outcome_v788"), dict) else {},
            "quality_route_v810": qroute_v810,
            "quality_recheck_s2_v810": qrecheck_v810,
            "flow_trap_watch_v810": trap_v810,
        }
        old = merged.get(t)
        if old is None or fnum(row.get("priority"), default=0.0) > fnum(old.get("priority"), default=0.0):
            merged[t] = row
        source_counts[source] = source_counts.get(source, 0) + 1

    for idx, it in enumerate(latest_rows):
        add_item(it, idx, "paper_latest")
    out = sorted(merged.values(), key=lambda x: fnum(x.get("priority"), default=0.0), reverse=True)
    try:
        # build_queue status에 붙일 수 있게 lightweight 진단만 남긴다.
        globals()["_V497_LAST_RECHECK_SOURCE_COUNTS"] = source_counts
        globals()["_V497_LAST_RECHECK_CACHE_ROW_COUNT"] = len(cache_rows)
        globals()["_V497_LAST_RECHECK_LATEST_ROW_COUNT"] = len(latest_rows)
    except Exception:
        pass
    return out


def _feature_priority(features: Dict[str, Dict[str, Any]]) -> List[Dict[str, Any]]:
    out = []
    for t, r in features.items():
        score = 6.0
        score += min(28.0, max(0.0, fnum(r.get("change_3m"), default=0.0) * 7))
        score += min(26.0, max(0.0, fnum(r.get("change_5m"), default=0.0) * 5))
        score += min(22.0, max(0.0, fnum(r.get("change_15m"), default=0.0) * 3))
        score += min(18.0, max(0.0, fnum(r.get("turnover_24h"), default=0.0) / 500_000_000))
        if r.get("volume_expanding"):
            score += 8
        if r.get("breakout_hint") or r.get("sweep_reclaim_hint"):
            score += 7
        bucket = "market_hot_rotation" if score >= HOT_ROTATION_THRESHOLD else "market_rotation"
        out.append({"ticker": t, "priority": round(score, 3), "bucket": bucket, "need": [], "source": "feature_rotation"})
    return out



def _hot_rank_priority(hot_rows: Dict[str, Dict[str, Any]]) -> List[Dict[str, Any]]:
    """v481: scanner hot-rank를 target priority로 올린다.
    - 전략 후보 제한이 아니라, 방금 튄 코인에 WS/micro/feature가 빨리 붙게 하는 정보 배관이다.
    - 고정 N개로 시장을 자르지 않고 score/threshold와 전체 queue rotation을 같이 사용한다.
    """
    out: List[Dict[str, Any]] = []
    for t, r in hot_rows.items():
        ch1_known = r.get("scanner_change_1m_pct") not in (None, "")
        ch3_known = r.get("scanner_change_3m_pct") not in (None, "")
        ch1 = fnum(r.get("scanner_change_1m_pct"), default=0.0)
        ch3 = fnum(r.get("scanner_change_3m_pct"), default=0.0)
        score = 0.0
        if ch1_known:
            score += max(0.0, ch1) * 26.0
        if ch3_known:
            score += max(0.0, ch3) * 16.0
        score += min(12.0, fnum(r.get("scanner_hot_score"), default=0.0) * 3.0)
        score += min(8.0, fnum(r.get("turnover_24h"), default=0.0) / 800_000_000.0)
        if score <= 0:
            continue
        # v535: 급등형은 scan 후 보강하면 늦으므로 hot-rank 상위는 urgent lane으로 올린다.
        urgent = bool((ch1_known and ch1 >= 0.50) or (ch3_known and ch3 >= 0.90) or score >= 18)
        bucket = "spike_fast_urgent" if urgent else ("market_hot_rank" if score >= 12 else "market_rotation")
        out.append({
            "ticker": t, "priority": round((145.0 if urgent else 70.0) + score, 3), "bucket": bucket,
            "need": ["ws", "micro"] if bucket in {"spike_fast_urgent", "market_hot_rank"} else [],
            "source": "scanner_hot_rank_v535",
            "change_1m": r.get("scanner_change_1m_pct"), "change_3m": r.get("scanner_change_3m_pct"),
            "hot_rank_1m": r.get("scanner_hot_rank_1m"), "hot_rank_3m": r.get("scanner_hot_rank_3m"),
            "hot_observed_1m_sec": r.get("scanner_hot_observed_1m_sec"), "hot_observed_3m_sec": r.get("scanner_hot_observed_3m_sec"),
        })
    return out

def _bucket_counts(rows: List[Dict[str, Any]]) -> Dict[str, int]:
    d: Dict[str, int] = {}
    for r in rows:
        b = str(r.get("bucket") or "unknown")
        d[b] = d.get(b, 0) + 1
    return d


def _v613_orderflow_micro_urgent_requests() -> List[Dict[str, Any]]:
    """strategy_worker v613이 봉인한 체결/호가 fresh urgent를 target_router 본선으로 합친다."""
    obj = load_json(ORDERFLOW_MICRO_URGENT, {}) or {}
    rows = obj.get("rows") if isinstance(obj, dict) and isinstance(obj.get("rows"), list) else []
    out: List[Dict[str, Any]] = []
    for r in rows:
        if not isinstance(r, dict):
            continue
        t = ticker_norm(r.get("ticker") or r.get("symbol") or r.get("market"))
        if not t:
            continue
        need = r.get("need") if isinstance(r.get("need"), list) else ["quote", "ws", "micro"]
        out.append({
            "ticker": t,
            "priority": fnum(r.get("priority"), default=980.0),
            "bucket": "near_s_info_wait",
            "sub_bucket": r.get("sub_bucket") or "core_S2_orderflow_micro_fresh_lock",
            "need": need,
            "source": "strategy_worker_v613_orderflow_micro_urgent_file",
            "stage": r.get("stage") or "S2",
            "micro_urgent": True,
            "strategy_force_active": True,
            "reasons": r.get("detail") if isinstance(r.get("detail"), list) else ["체결/호가 fresh 보강"],
            "updated_ts": now_ts(),
        })
    return out



# =============================================================================
# target_router_worker v0.22 / v614: S2 fresh urgent ACK 단일화
# - strategy가 만든 체결/호가 fresh urgent 요청을 active/micro/urgent target 맨 앞에 직접 고정한다.
# - target_router가 ACK 파일을 써서 strategy가 같은 cycle의 target 파일을 추측하지 않게 한다.
# - 조건/S등급/청산/BUY_READY 변경 없음.
# =============================================================================
def _v614_unique_targets(vals: List[Any]) -> List[str]:
    out: List[str] = []
    seen = set()
    for x in vals or []:
        t = ticker_norm(x)
        if t and t not in seen:
            seen.add(t)
            out.append(t)
    return out


def _v614_direct_targets_from_reqs(reqs: List[Dict[str, Any]]) -> List[str]:
    return _v614_unique_targets([r.get("ticker") for r in reqs or [] if isinstance(r, dict)])


def _v615_direct_rows_from_reqs(reqs: List[Dict[str, Any]]) -> List[Dict[str, Any]]:
    """v615: strategy urgent 요청 row를 target/micro/urgent row까지 같은 본선으로 고정한다."""
    out: List[Dict[str, Any]] = []
    seen = set()
    for r in reqs or []:
        if not isinstance(r, dict):
            continue
        t = ticker_norm(r.get("ticker") or r.get("market") or r.get("symbol"))
        if not t or t in seen:
            continue
        seen.add(t)
        need = r.get("need") if isinstance(r.get("need"), list) else ["quote", "ws", "micro"]
        rr = dict(r)
        rr.update({
            "ticker": t,
            "bucket": rr.get("bucket") or "near_s_info_wait",
            "need": need,
            "priority": fnum(rr.get("priority"), default=980.0),
            "source": rr.get("source") or "strategy_worker_orderflow_micro_urgent",
            "strategy_force_active": True,
            "active_target": True,
            "micro_priority": True,
            "micro_urgent": True,
            "target_reason": "v616_orderflow_micro_direct_urgent_lane",
        })
        out.append(rr)
    return out


def _v614_write_orderflow_micro_ack(
    reqs: List[Dict[str, Any]],
    active_targets: List[str],
    micro_targets: List[str],
    urgent_targets: List[str],
    *,
    ts: float,
) -> Dict[str, Any]:
    req_targets = _v614_direct_targets_from_reqs(reqs)
    active_set = set(_v614_unique_targets(active_targets))
    micro_set = set(_v614_unique_targets(micro_targets))
    urgent_set = set(_v614_unique_targets(urgent_targets))
    rows: List[Dict[str, Any]] = []
    req_map = {ticker_norm(r.get("ticker")): r for r in reqs or [] if isinstance(r, dict) and ticker_norm(r.get("ticker"))}
    for t in req_targets:
        r = req_map.get(t, {})
        req_ts = fnum(r.get("requested_ts"), r.get("updated_ts"), default=0.0)
        rows.append({
            "ticker": t,
            "in_active_targets": t in active_set,
            "in_micro_targets": t in micro_set,
            "in_micro_urgent_targets": t in urgent_set,
            "bucket": r.get("bucket"),
            "priority": r.get("priority"),
            "source": r.get("source"),
            "need": r.get("need"),
            "request_ts": req_ts,
            "request_text": now_text(req_ts) if req_ts > 0 else None,
            "ack_ts": ts,
            "updated_ts": ts,
        })
    obj = {
        "schema": "orderflow_micro_urgent_ack_v616_priority_lane",
        "version": VERSION,
        "updated_ts": ts,
        "updated_text": now_text(ts),
        "requested_count": len(req_targets),
        "active_count": sum(1 for t in req_targets if t in active_set),
        "micro_target_count": sum(1 for t in req_targets if t in micro_set),
        "micro_urgent_count": sum(1 for t in req_targets if t in urgent_set),
        "targets": req_targets,
        "active_targets": [t for t in req_targets if t in active_set],
        "micro_targets": [t for t in req_targets if t in micro_set],
        "micro_urgent_targets": [t for t in req_targets if t in urgent_set],
        "rows": rows[:120],
        "policy": "v616: strategy orderflow/micro urgent 요청은 active/micro/urgent 전용 lane 맨 앞에 고정하고 ticker별 request_ts/ACK를 봉인한다.",
    }
    save_json(ORDERFLOW_MICRO_URGENT_ACK, obj)
    return obj

def build_queue() -> Dict[str, Any]:
    ts = now_ts()
    features = map_rows(load_json(FEATURE, {}) or {})
    hot_rows = map_rows(load_json(HOT, {}) or {})
    orderflow = map_rows(load_json(ORDERFLOW, {}) or {})
    reqs = _request_rows()
    hold_reqs_v746 = _s1_hold_urgent_rows_v746()
    recheck_reqs = _recheck_request_rows()
    v613_ofmicro_reqs = _v613_orderflow_micro_urgent_requests()
    if hold_reqs_v746:
        reqs = hold_reqs_v746 + reqs
    if recheck_reqs:
        reqs = reqs + recheck_reqs
    if v613_ofmicro_reqs:
        reqs = reqs + v613_ofmicro_reqs
    merged: Dict[str, Dict[str, Any]] = {}

    def add(row: Dict[str, Any], bonus: float = 0.0) -> None:
        t = ticker_norm(row.get("ticker") or row.get("market") or row.get("symbol"))
        if not t:
            return
        cur = dict(row)
        cur["ticker"] = t
        cur["priority"] = fnum(cur.get("priority"), default=0.0) + bonus
        cur["priority"] = round(cur["priority"], 3)
        of = orderflow.get(t, {})
        cur["quote_fresh"] = bool(of.get("quote_fresh") or of.get("ws_fresh"))
        cur["ws_fresh"] = bool(of.get("ws_fresh"))
        cur["micro_fresh"] = bool(of.get("micro_fresh"))
        cur["fresh_ready"] = bool(cur["quote_fresh"] and cur["micro_fresh"])
        cur["orderflow_info_ready"] = bool(of.get("info_ready") or cur["fresh_ready"])
        cur["micro_age_sec"] = of.get("micro_age_sec")
        cur["quote_age_sec"] = of.get("quote_age_sec")
        need0 = cur.get("need") if isinstance(cur.get("need"), list) else []
        cur["need_micro"] = "micro" in need0
        cur["need_quote"] = ("quote" in need0) or ("ws" in need0)
        cur["updated_ts"] = ts
        old = merged.get(t)
        if old is None or fnum(cur.get("priority"), default=0) > fnum(old.get("priority"), default=0):
            merged[t] = cur

    # 1. OPEN은 항상 최상단.
    for t in _open_tickers():
        add({"ticker": t, "priority": 600, "bucket": "open_position", "need": ["ws", "micro"], "source": "paper_open"})

    # 2. strategy 요청은 이미 v0.7에서 S/S근접/high만 들어오게 줄인다.
    for r in reqs:
        bucket = str(r.get("bucket") or "strategy_request")
        base = fnum(r.get("priority"), default=50.0)
        if bucket in {"s_candidate", "paper_handoff"}:
            base += 500
        elif bucket in {"near_s_info_wait", "s_near_info"}:
            base += 420
        elif bucket in HIGH_BUCKETS:
            base += 180
        add({**r, "priority": base, "source": r.get("source") or "strategy"})

    # 3. 전체시장 순환은 queue에 보존한다. v481 hot-rank는 정보수집 우선순위만 높인다.
    for r in _feature_priority(features):
        add(r)
    hot_rank_reqs = _hot_rank_priority(hot_rows)
    for r in hot_rank_reqs:
        add(r)

    rows = sorted(merged.values(), key=lambda x: (fnum(x.get("priority"), default=0.0), bool(x.get("fresh_ready"))), reverse=True)

    critical: List[Dict[str, Any]] = []
    high: List[Dict[str, Any]] = []
    rotation: List[Dict[str, Any]] = []
    for r in rows:
        b = str(r.get("bucket") or "")
        p = fnum(r.get("priority"), default=0.0)
        if is_critical_bucket_name(b):
            critical.append(r)
        elif is_high_bucket_name(b) or p >= HIGH_PRIORITY_THRESHOLD:
            high.append(r)
        elif b == "market_hot_rotation" and p >= HOT_ROTATION_THRESHOLD:
            rotation.append(r)

    # v0.7 핵심: 고정 N개 target 제한이 아니라 전체 queue를 보존하고 순환 내보내기한다.
    # - OPEN/S/S근접/정보요청은 최우선 보호
    # - 고우선 후보는 그 다음
    # - 나머지 전체시장은 버리지 않고 rotation cursor로 계속 순환
    # EXPORT_SAFETY_WINDOW는 sidecar 장애 방지용 "한 번에 내보낼 창"일 뿐, 후보 제한 조건이 아니다.
    prev_payload = load_json(QUEUE, {}) or {}
    prev_cursor = int(fnum(prev_payload.get("rotation_cursor"), default=0)) if isinstance(prev_payload, dict) else 0
    export_window = max(1, EXPORT_SAFETY_WINDOW)

    active_rows: List[Dict[str, Any]] = []
    seen = set()
    forced_strategy_rows: List[Dict[str, Any]] = []
    forced_missing_before = 0

    def push_active(row: Dict[str, Any], *, reason: str, force: bool = False) -> None:
        t = str(row.get("ticker") or "")
        if not t or t in seen:
            return
        rr = dict(row)
        rr["active_target"] = True
        rr["target_reason"] = reason
        if force:
            rr["strategy_force_active"] = True
        active_rows.append(rr)
        seen.add(t)

    # OPEN은 항상 맨 앞.
    for r in critical:
        if str(r.get("bucket")) == "open_position":
            push_active(r, reason="open_position", force=True)

    # strategy_worker가 직접 요청한 S/S근접/정보대기 후보는 누락되면 안 된다.
    for req in reqs:
        if not isinstance(req, dict):
            continue
        t = ticker_norm(req.get("ticker") or req.get("market") or req.get("symbol"))
        if not t:
            continue
        bucket = str(req.get("bucket") or "strategy_request")
        need = req.get("need") if isinstance(req.get("need"), list) else []
        must_force = is_critical_bucket_name(bucket) or is_high_bucket_name(bucket) or ("micro" in need) or ("quote" in need) or ("ws" in need) or ("feature" in need) or ("orderflow" in need) or ("candle" in need)
        if not must_force:
            continue
        base = dict(merged.get(t, req))
        base["ticker"] = t
        base["bucket"] = bucket
        base["need"] = need
        base["source"] = base.get("source") or "strategy_force"
        base["strategy_force_active"] = True
        base["active_target"] = True
        if t not in seen:
            forced_missing_before += 1
            forced_strategy_rows.append(base)
            push_active(base, reason="strategy_request", force=True)

    # 나머지 CRITICAL/HIGH는 우선 보강.
    for r in critical:
        push_active(r, reason="critical", force=True)
    for r in high:
        push_active(r, reason="high_priority", force=False)

    protected_count = len(active_rows)

    # 전체시장 순환 pool. 이미 보호/우선에 들어간 대상은 제외하고, 남은 전체를 버리지 않고 회전한다.
    normal_pool: List[Dict[str, Any]] = []
    for r in rows:
        t = str(r.get("ticker") or "")
        if not t or t in seen:
            continue
        normal_pool.append(r)

    # v0.7 확정: target_router는 전체 queue를 target 파일에 내보낸다.
    # 실제 API/네트워크 보호는 sidecar의 poll batch, TTL, urgent lane, 회전 로직이 담당한다.
    # 여기서 몇 개만 잘라내면 시장 후보가 아예 정보수집 대상에서 사라지므로 금지.
    rotation_export_count = 0
    rotation_wait_count = 0
    rotation_cursor = prev_cursor
    next_rotation_cursor = prev_cursor
    for r in normal_pool:
        push_active(r, reason="market_rotation", force=False)
        rotation_export_count += 1

    export_over_budget_count = 0
    dropped_count = 0
    active_targets = [r.get("ticker") for r in active_rows if r.get("ticker")]
    urgent_rows = [r for r in active_rows if is_critical_bucket_name(str(r.get("bucket"))) or bool(r.get("strategy_force_active"))]
    urgent_targets = [r.get("ticker") for r in urgent_rows if r.get("ticker")]

    # v0.5: micro sidecar에는 S/S근접·micro필요 후보를 active 여부와 무관하게 맨 앞에 둔다.
    # active window는 서버보호 처리창일 뿐이고, 전략 후보 제한이 아니다.
    micro_priority_rows: List[Dict[str, Any]] = []
    micro_seen = set()
    def add_micro_row(r: Dict[str, Any]) -> None:
        t = str(r.get("ticker") or "")
        if not t or t in micro_seen:
            return
        rr = dict(r)
        rr["micro_priority"] = True
        rr["micro_urgent"] = is_critical_bucket_name(str(r.get("bucket"))) or bool(r.get("need_micro")) or ("orderflow" in (r.get("need") if isinstance(r.get("need"), list) else []))
        micro_priority_rows.append(rr)
        micro_seen.add(t)
    strategy_req_rows_for_micro: List[Dict[str, Any]] = []
    for req in reqs:
        if not isinstance(req, dict):
            continue
        t = ticker_norm(req.get("ticker") or req.get("market") or req.get("symbol"))
        if not t:
            continue
        need = req.get("need") if isinstance(req.get("need"), list) else []
        bucket = str(req.get("bucket") or "strategy_request")
        if is_critical_bucket_name(bucket) or is_high_bucket_name(bucket) or "micro" in need or "orderflow" in need:
            rr = dict(merged.get(t, req))
            rr["ticker"] = t
            rr["bucket"] = bucket
            rr["need"] = need
            rr["micro_urgent"] = True
            rr["strategy_force_active"] = True
            strategy_req_rows_for_micro.append(rr)
    for group in (strategy_req_rows_for_micro, urgent_rows, [r for r in active_rows if r.get("need_micro") and not r.get("micro_fresh")], active_rows):
        for r in group:
            add_micro_row(r)
    micro_targets = [r.get("ticker") for r in micro_priority_rows if r.get("ticker")]

    def need_counts(rs: List[Dict[str, Any]]) -> tuple[int, int, int]:
        need_ws = need_micro = fresh_ready = 0
        for r in rs:
            need = r.get("need") if isinstance(r.get("need"), list) else []
            # quote는 WS 구독 또는 scanner/feature REST 시세를 통해 채울 수 있지만,
            # WS sidecar target에도 같이 올려 빠른 실시간 시세를 시도한다.
            if ("ws" in need or "quote" in need) and not r.get("quote_fresh"):
                need_ws += 1
            if "micro" in need and not r.get("micro_fresh"):
                need_micro += 1
            if r.get("fresh_ready"):
                fresh_ready += 1
        return need_ws, need_micro, fresh_ready

    need_ws, need_micro, fresh_recovered = need_counts(active_rows)
    near_s_count = sum(1 for r in active_rows if str(r.get("bucket")) in {"near_s_info_wait", "s_near_info"})
    payload = {
        "version": VERSION,
        "updated_ts": ts,
        "updated_text": now_text(ts),
        "queue_count": len(rows),
        "active_target_count": len(active_targets),
        "target_count": len(active_targets),  # 기존 화면 호환
        "backlog_count": max(0, len(rows) - len(active_rows)),
        "export_safety_window": export_window,
        "targets": active_targets,
        "active_targets": active_targets,
        "urgent_targets": urgent_targets,
        "rows": rows[:700],
        "active_rows": active_rows[:350],
        "urgent_rows": urgent_rows[:120],
        "buckets": _bucket_counts(rows),
        "active_buckets": _bucket_counts(active_rows),
        "fresh_recovered": fresh_recovered,
        "need_ws": need_ws,
        "need_micro": need_micro,
        "near_s_count": near_s_count,
        "micro_priority_target_count": len(micro_targets),
        "micro_need_count": sum(1 for r in active_rows if r.get("need_micro") and not r.get("micro_fresh")),
        "export_safety_window": export_window,
        "priority_protected_count": protected_count,
        "rotation_pool_count": len(normal_pool),
        "rotation_export_count": rotation_export_count,
        "rotation_wait_count": rotation_wait_count,
        "rotation_cursor": rotation_cursor,
        "next_rotation_cursor": next_rotation_cursor,
        "export_over_budget_count": export_over_budget_count,
        "dropped_count": dropped_count,
        "strategy_req_total_count": len(reqs),
        "hot_rank_req_count": len(hot_rank_reqs),
        "hot_rank_active_count": sum(1 for r in active_rows if str(r.get("source")) in {"scanner_hot_rank_v481","scanner_hot_rank_v535"}),
        "s1_hold_priority_req_count_v746": len(hold_reqs_v746),
        "recheck_req_count": len(recheck_reqs),
        "quality_recheck_s2_req_count_v810": sum(1 for r in recheck_reqs if bool(r.get('quality_recheck_s2_v810')) or str(r.get('bucket')) == 'quality_recheck_s2'),
        "flow_trap_watch_req_count_v810": sum(1 for r in recheck_reqs if bool(r.get('flow_trap_watch_v810')) or str(r.get('bucket')) == 'flow_trap_watch'),
        "v613_orderflow_micro_req_count": len(v613_ofmicro_reqs),
        "recheck_source_counts_v497": dict(globals().get("_V497_LAST_RECHECK_SOURCE_COUNTS", {})),
        "recheck_cache_row_count_v497": int(globals().get("_V497_LAST_RECHECK_CACHE_ROW_COUNT", 0) or 0),
        "recheck_latest_row_count_v497": int(globals().get("_V497_LAST_RECHECK_LATEST_ROW_COUNT", 0) or 0),
        "recheck_dispatch_policy_v497": "paper_latest S2/S3 -> target priority queue; legacy recheck cache source disabled; no fixed count cap",
        "strategy_req_forced_active_count": len(forced_strategy_rows),
        "strategy_req_missing_before_force": forced_missing_before,
        "strategy_req_micro_target_count": len(strategy_req_rows_for_micro),
        "recheck_micro_target_count": sum(1 for r in strategy_req_rows_for_micro if "recheck" in str(r.get("source"))),
        "strategy_req_count": sum(1 for r in active_rows if str(r.get("bucket")) in {"s_candidate", "paper_handoff", "near_s_info_wait", "s_near_info", "info_wait_high"} or bool(r.get("strategy_force_active"))),
        "strategy_req_info_ready": sum(1 for r in active_rows if (str(r.get("bucket")) in {"s_candidate", "paper_handoff", "near_s_info_wait", "s_near_info", "info_wait_high"} or bool(r.get("strategy_force_active"))) and r.get("fresh_ready")),
        "critical_count": len(critical),
        "high_count": len(high),
        "rotation_count": len(rotation),
        "v613_orderflow_micro": {"schema":"target_router_orderflow_micro_urgent_v613", "request_count": len(v613_ofmicro_reqs), "targets": [r.get("ticker") for r in v613_ofmicro_reqs[:80]], "policy":"strategy 체결/호가 fresh urgent를 active/micro/urgent 전용 lane 맨 앞에 row/meta/ACK까지 고정(v616)"},
        "v676_info_priority_active_count": sum(1 for r in active_rows if str(r.get("bucket") or "").startswith(INFO_PRIORITY_PREFIXES_V676)),
        "v676_info_priority_micro_count": sum(1 for r in micro_priority_rows if str(r.get("bucket") or "").startswith(INFO_PRIORITY_PREFIXES_V676)),
        "note": "v0.25/v812: P0 OPEN/S1 hold, P1 S1, P2 structure_recheck_s2 + quality_recheck_s2 + flow_trap_watch. 고정 후보 제한 아님.",
    }
    # v575: strategy_worker의 S2 fresh urgent 요청이 실제 target_router/micro 우선순위에 탔는지 결과를 저장한다.
    s2_urgent_rows = [r for r in active_rows if str(r.get("bucket")) == "near_s_info_wait" or str(r.get("source") or "").startswith("strategy_worker_v574") or str(r.get("source") or "").startswith("strategy_worker_v575")]
    s2_urgent_fresh_ready = sum(1 for r in s2_urgent_rows if bool(r.get("fresh_ready")))
    s2_urgent_need_micro = sum(1 for r in s2_urgent_rows if bool(r.get("need_micro")) and not bool(r.get("micro_fresh")))
    s2_urgent_need_ws = sum(1 for r in s2_urgent_rows if bool(r.get("need_quote")) and not bool(r.get("quote_fresh")))
    s2_urgent_micro_targets = [str(r.get("ticker")) for r in micro_priority_rows if (str(r.get("bucket")) == "near_s_info_wait" or str(r.get("source") or "").startswith("strategy_worker_v574") or str(r.get("source") or "").startswith("strategy_worker_v575")) and r.get("ticker")]
    s2_urgent_targets_ordered = [str(r.get("ticker")) for r in s2_urgent_rows if r.get("ticker")]
    s2_urgent_targets_ordered = list(dict.fromkeys(s2_urgent_targets_ordered))

    # v614/v615: v613 orderflow/micro 요청은 active_rows 추출 결과와 무관하게 직접 맨 앞에 고정한다.
    # v615에서는 target 이름만 앞에 붙이지 않고 active/micro/urgent row도 같은 direct row로 맞춘다.
    # 그래야 ACK/target_meta/sidecar rows가 서로 다른 값을 찍지 않는다.
    v614_direct_urgent_targets = _v614_direct_targets_from_reqs(v613_ofmicro_reqs)
    v615_direct_rows = _v615_direct_rows_from_reqs(v613_ofmicro_reqs)
    if v614_direct_urgent_targets:
        s2_urgent_targets_ordered = _v614_unique_targets(v614_direct_urgent_targets + s2_urgent_targets_ordered)

    if v615_direct_rows:
        direct_seen = set()
        direct_ordered_rows: List[Dict[str, Any]] = []
        for rr in v615_direct_rows:
            t = str(rr.get("ticker") or "")
            if t and t not in direct_seen:
                direct_seen.add(t)
                direct_ordered_rows.append(rr)
        direct_set = set(direct_seen)
        active_rows = direct_ordered_rows + [r for r in active_rows if str(r.get("ticker") or "") not in direct_set]
        urgent_rows = direct_ordered_rows + [r for r in urgent_rows if str(r.get("ticker") or "") not in direct_set]
        micro_priority_rows = direct_ordered_rows + [r for r in micro_priority_rows if str(r.get("ticker") or "") not in direct_set]
        # row 배열을 재정렬했으므로 target 배열도 같은 순서로 다시 만든다.
        active_targets = [r.get("ticker") for r in active_rows if r.get("ticker")]
        urgent_targets = [r.get("ticker") for r in urgent_rows if r.get("ticker")]
        micro_targets = [r.get("ticker") for r in micro_priority_rows if r.get("ticker")]

    # v576: S2 urgent 대상은 "요청만 생성"으로 끝내지 않고 실제 micro/ws urgent 파일 맨 앞에 고정한다.
    # 서버 보호는 sidecar 시간예산/worker가 담당한다. 여기서는 순서만 보장한다.
    if s2_urgent_targets_ordered:
        s2set = set(s2_urgent_targets_ordered)
        active_targets = s2_urgent_targets_ordered + [t for t in active_targets if t not in s2set]
        urgent_targets = s2_urgent_targets_ordered + [t for t in urgent_targets if t not in s2set]
        micro_targets = s2_urgent_targets_ordered + [t for t in micro_targets if t not in s2set]

        # v616: target 이름만 앞에 붙이면 rows/meta/ACK와 실제 micro urgent lane이 갈라진다.
        # S2 fresh urgent direct row를 urgent_rows/micro_priority_rows에도 같은 순서로 재고정한다.
        row_by_t = {}
        for rr in list(v615_direct_rows or []) + active_rows + urgent_rows + micro_priority_rows:
            if isinstance(rr, dict):
                tt = str(rr.get("ticker") or "")
                if tt and tt not in row_by_t:
                    row_by_t[tt] = dict(rr)
        fixed_front_rows = []
        for tt in s2_urgent_targets_ordered:
            rr = dict(row_by_t.get(tt, {"ticker": tt}))
            rr.update({
                "ticker": tt,
                "bucket": rr.get("bucket") or "near_s_info_wait",
                "need": rr.get("need") if isinstance(rr.get("need"), list) else ["quote", "ws", "micro"],
                "strategy_force_active": True,
                "active_target": True,
                "micro_priority": True,
                "micro_urgent": True,
                "target_reason": "v619_s2_fresh_urgent_front_lane",
                "source": rr.get("source") or "strategy_worker_orderflow_micro_urgent",
                "updated_ts": ts,
            })
            fixed_front_rows.append(rr)
        fixed_set = set(s2_urgent_targets_ordered)
        active_rows = fixed_front_rows + [r for r in active_rows if str(r.get("ticker") or "") not in fixed_set]
        urgent_rows = fixed_front_rows + [r for r in urgent_rows if str(r.get("ticker") or "") not in fixed_set]
        micro_priority_rows = fixed_front_rows + [r for r in micro_priority_rows if str(r.get("ticker") or "") not in fixed_set]

    payload["v575_s2_urgent"] = {
        "schema": "target_router_s2_urgent_refresh_state_v619_priority_lane_keepalive",
        "version": VERSION,
        "updated_ts": ts,
        "request_active_count": len(s2_urgent_rows),
        "fresh_ready_count": s2_urgent_fresh_ready,
        "need_micro_count": s2_urgent_need_micro,
        "need_ws_count": s2_urgent_need_ws,
        "micro_target_count": len(s2_urgent_micro_targets),
        "targets": s2_urgent_targets_ordered[:80],
        "micro_targets": s2_urgent_micro_targets[:80],
        "urgent_front_count": len(s2_urgent_targets_ordered),
        "state": "active" if s2_urgent_rows else "idle",
        "policy": "v619: S2 fresh urgent 후보는 target 이름/row/meta/ACK를 micro urgent lane 맨 앞에 고정하고, micro sidecar는 normal keepalive를 유지한다.",
    }
    try:
        save_json(S2_URGENT_STATE, payload["v575_s2_urgent"])
    except Exception as exc:
        append_error("v575_s2_urgent_state", exc)

    try:
        v614_ack = _v614_write_orderflow_micro_ack(v613_ofmicro_reqs, active_targets, micro_targets, urgent_targets, ts=ts)
        payload["v614_orderflow_micro_ack"] = {
            "schema": v614_ack.get("schema"),
            "requested_count": v614_ack.get("requested_count"),
            "active_count": v614_ack.get("active_count"),
            "micro_target_count": v614_ack.get("micro_target_count"),
            "micro_urgent_count": v614_ack.get("micro_urgent_count"),
            "targets": v614_ack.get("targets"),
        }
    except Exception as exc:
        append_error("v614_orderflow_micro_ack", exc)

    save_json(QUEUE, payload)

    # WS sidecar가 target 변경을 확실히 감지하도록 meta와 reconnect_seq를 넣는다.
    prev_ws = load_json(WS_TARGETS, {}) or {}
    prev_targets = prev_ws.get("targets") if isinstance(prev_ws, dict) and isinstance(prev_ws.get("targets"), list) else []
    changed = set(map(str, prev_targets)) != set(map(str, active_targets))
    prev_seq = int(fnum(prev_ws.get("reconnect_seq"), default=0)) if isinstance(prev_ws, dict) else 0
    reconnect_seq = prev_seq + 1 if changed else prev_seq
    target_meta = {}
    for r in active_rows:
        t = str(r.get("ticker") or "")
        if not t:
            continue
        target_meta[t] = {
            "priority": r.get("priority"),
            "bucket": r.get("bucket"),
            "need": r.get("need"),
            "source": "current_candidate" if str(r.get("bucket")) in CRITICAL_BUCKETS else "priority_queue",
            "auto_candidate": str(r.get("bucket")) in {"s_candidate", "paper_handoff"},
            "updated_ts": ts,
        }

    active_payload = {
        "version": VERSION,
        "updated_ts": ts,
        "updated_text": now_text(ts),
        "target_count": len(active_targets),
        "targets": active_targets,
        "rows": active_rows[:300],
        "queue_count": len(rows),
        "backlog_count": payload["backlog_count"],
        "active_buckets": payload["active_buckets"],
        "target_meta": target_meta,
        "force_reconnect": bool(changed),
        "reconnect_seq": reconnect_seq,
        "reconnect_reason": "target_router_active_changed" if changed else "unchanged",
        "reason": "target_router_active_priority",
        "note": "full queue target export. 전체 queue를 보존하고 target 파일에도 내보냄. sidecar가 batch/TTL/urgent lane으로 처리.",
    }
    micro_target_meta = {}
    for idx, r in enumerate(micro_priority_rows):
        t = str(r.get("ticker") or "")
        if not t:
            continue
        micro_target_meta[t] = {
            "priority": r.get("priority"),
            "bucket": r.get("bucket"),
            "need": r.get("need"),
            "micro_rank": idx + 1,
            "micro_urgent": bool(r.get("micro_urgent")),
            "source": "micro_priority" if bool(r.get("micro_urgent")) else "active_rotation",
            "updated_ts": ts,
        }
    micro_payload = dict(active_payload)
    micro_payload.update({
        "target_count": len(micro_targets),
        "targets": micro_targets,
        "rows": micro_priority_rows[:350],
        "target_meta": micro_target_meta,
        "micro_priority_target_count": len(micro_targets),
        "note": "v0.8 micro: S1정보부족/S근접·micro필요 후보 최우선 + 나머지 전체시장도 target에 포함. sidecar가 batch 회전. 버림 없음.",
    })
    urgent_payload = dict(micro_payload)
    urgent_payload.update({
        "target_count": len(urgent_targets),
        "targets": urgent_targets,
        "rows": urgent_rows[:160],
        "ttl_sec": 45.0,
        "reason": "v617_s2_urgent_cpu_guard",
        "s2_urgent_front_count": len(s2_urgent_targets_ordered),
        "s2_urgent_front_targets": s2_urgent_targets_ordered[:80],
        "note": "v617 urgent: S2 fresh 부족 후보를 micro urgent 전용 lane 맨 앞에 고정하고, micro CPU guard가 urgent pending을 우선 처리. 정보부족은 탈락이 아니라 먼저 보강.",
    })
    save_json(WS_TARGETS, active_payload)
    save_json(MICRO_TARGETS, micro_payload)
    save_json(MICRO_URGENT, urgent_payload)

    write_status(
        "running",
        queue_count=len(rows), active_target_count=len(active_targets), target_count=len(active_targets),
        backlog_count=payload["backlog_count"], near_s_count=near_s_count, fresh_recovered=fresh_recovered,
        v575_s2_urgent_active_count=payload.get("v575_s2_urgent",{}).get("request_active_count",0), v575_s2_urgent_fresh_ready=payload.get("v575_s2_urgent",{}).get("fresh_ready_count",0), v575_s2_urgent_micro_targets=payload.get("v575_s2_urgent",{}).get("micro_target_count",0), v576_s2_urgent_front_count=payload.get("v575_s2_urgent",{}).get("urgent_front_count",0),
        need_ws=need_ws, need_micro=need_micro, micro_priority_target_count=len(micro_targets),
        export_safety_window=export_window, priority_protected_count=protected_count,
        rotation_pool_count=len(normal_pool), rotation_export_count=rotation_export_count, rotation_wait_count=rotation_wait_count,
        rotation_cursor=rotation_cursor, next_rotation_cursor=next_rotation_cursor, export_over_budget_count=export_over_budget_count,
        dropped_count=dropped_count, last_sec=0, hot_rank_req_count=payload.get("hot_rank_req_count",0), hot_rank_active_count=payload.get("hot_rank_active_count",0), recheck_req_count=payload.get("recheck_req_count", 0), v613_orderflow_micro_req_count=payload.get("v613_orderflow_micro_req_count",0), recheck_micro_target_count=payload.get("recheck_micro_target_count", 0), recheck_cache_row_count_v497=payload.get("recheck_cache_row_count_v497", 0), recheck_latest_row_count_v497=payload.get("recheck_latest_row_count_v497", 0),
    )
    return payload

def run_once() -> Dict[str, Any]:
    st = now_ts()
    p = build_queue()
    sec = now_ts() - st
    write_status(
        "running", queue_count=p.get("queue_count", 0), active_target_count=p.get("active_target_count", 0),
        target_count=p.get("target_count", 0), backlog_count=p.get("backlog_count", 0),
        near_s_count=p.get("near_s_count", 0), fresh_recovered=p.get("fresh_recovered", 0),
        v575_s2_urgent_active_count=(p.get("v575_s2_urgent",{}) or {}).get("request_active_count",0), v575_s2_urgent_fresh_ready=(p.get("v575_s2_urgent",{}) or {}).get("fresh_ready_count",0), v575_s2_urgent_micro_targets=(p.get("v575_s2_urgent",{}) or {}).get("micro_target_count",0),
        need_ws=p.get("need_ws", 0), need_micro=p.get("need_micro", 0), micro_priority_target_count=p.get("micro_priority_target_count", 0),
        export_safety_window=p.get("export_safety_window", EXPORT_SAFETY_WINDOW), priority_protected_count=p.get("priority_protected_count", 0),
        rotation_pool_count=p.get("rotation_pool_count", 0), rotation_export_count=p.get("rotation_export_count", 0), rotation_wait_count=p.get("rotation_wait_count", 0),
        rotation_cursor=p.get("rotation_cursor", 0), next_rotation_cursor=p.get("next_rotation_cursor", 0), export_over_budget_count=p.get("export_over_budget_count", 0),
        dropped_count=p.get("dropped_count", 0), last_sec=round(sec, 3), hot_rank_req_count=p.get("hot_rank_req_count",0), hot_rank_active_count=p.get("hot_rank_active_count",0), recheck_req_count=p.get("recheck_req_count", 0), v613_orderflow_micro_req_count=p.get("v613_orderflow_micro_req_count",0), recheck_micro_target_count=p.get("recheck_micro_target_count", 0), recheck_cache_row_count_v497=p.get("recheck_cache_row_count_v497", 0), recheck_latest_row_count_v497=p.get("recheck_latest_row_count_v497", 0),
    )
    return p

def main() -> None:
    write_status("running", phase="boot", target_count=0, queue_count=0, dropped_count=0, last_sec=0)
    while True:
        try:
            run_once()
        except KeyboardInterrupt:
            write_status("stopping")
            raise
        except Exception as exc:
            append_error("loop", exc)
            write_status("error", error=f"{exc.__class__.__name__}: {exc}")
        time.sleep(max(0.5, INTERVAL_SEC))


# =============================================================================
# target_router_worker v0.12 / v500: 급등 진행형 urgent 배차 보강
# - 급등 전략 자체 판단은 strategy_worker가 한다.
# - 여기서는 hot-rank 급변 종목을 micro/orderflow가 초 단위로 보게 우선순위를 올린다.
# - 고정 N개 제한 없음. priority/TTL/rotation 구조 유지.
# =============================================================================
VERSION = "target_router_worker_v0.25_structure_recheck_priority_2026-06-10"
try:
    CRITICAL_BUCKETS.update({"spike_momentum_urgent", "spike_momentum_recheck"})
    HIGH_BUCKETS.update({"spike_pullback_watch", "spike_pullback_recheck"})
except Exception:
    pass

_v500_prev_hot_rank_priority = _hot_rank_priority

def _hot_rank_priority(hot_rows: Dict[str, Dict[str, Any]]) -> List[Dict[str, Any]]:  # type: ignore[override]
    base_rows = _v500_prev_hot_rank_priority(hot_rows) if callable(_v500_prev_hot_rank_priority) else []
    out: List[Dict[str, Any]] = list(base_rows)
    nowv = now_ts()
    for t, r in hot_rows.items():
        t = ticker_norm(t or r.get('ticker') or r.get('symbol') or r.get('market'))
        if not t:
            continue
        ch1 = fnum(r.get('scanner_change_1m_pct'), r.get('change_1m_pct'), default=0.0)
        ch3 = fnum(r.get('scanner_change_3m_pct'), r.get('change_3m_pct'), default=0.0)
        observed = fnum(r.get('scanner_hot_observed_1m_sec'), r.get('hot_observed_1m_sec'), default=-1.0)
        ts = fnum(r.get('updated_ts'), r.get('detected_ts'), r.get('ts'), default=0.0)
        age = observed if observed >= 0 else (max(0.0, nowv-ts) if ts > 1000000000 else 999999.0)
        # 급등 진행형은 신호나이가 짧을수록 최우선. 늦으면 눌림 전략 감시 lane으로 넘긴다.
        if age <= 75 and (ch1 >= 0.80 or ch3 >= 1.50):
            pri = 430.0 + max(0.0, ch1)*28.0 + max(0.0, ch3)*18.0 + max(0.0, 75.0-age)*0.8
            out.append({'ticker':t,'priority':round(pri,3),'bucket':'spike_momentum_urgent','need':['ws','micro'],'source':'scanner_hot_rank_v500_spike_urgent','micro_urgent':True,'hot_signal_age_sec':round(age,1),'change_1m':ch1,'change_3m':ch3})
        elif age <= 600 and (ch1 >= 0.25 or ch3 >= 0.80):
            pri = 250.0 + max(0.0, ch1)*14.0 + max(0.0, ch3)*10.0
            out.append({'ticker':t,'priority':round(pri,3),'bucket':'spike_pullback_watch','need':['ws','micro'],'source':'scanner_hot_rank_v500_pullback_watch','micro_urgent':False,'hot_signal_age_sec':round(age,1),'change_1m':ch1,'change_3m':ch3})
    return out


def main() -> None:  # type: ignore[override]
    write_status("running", phase="boot", target_count=0, queue_count=0, dropped_count=0, v500_spike_urgent=True)
    while True:
        try:
            run_once()
        except KeyboardInterrupt:
            write_status("stopping")
            raise
        except Exception as exc:
            append_error("loop", exc)
            write_status("error", error=f"{exc.__class__.__name__}: {exc}")
        time.sleep(max(0.5, INTERVAL_SEC))


# =============================================================================
# target_router_worker v0.13 / v504: 급등 urgent age lane 강화
# - 전체시장은 유지하고, hot signal age가 짧은 후보만 urgent lane으로 더 빨리 태운다.
# - 고정 N개 제한 없음. priority/TTL/rotation 구조 유지.
# =============================================================================
VERSION = "target_router_worker_v0.25_structure_recheck_priority_2026-06-10"
try:
    CRITICAL_BUCKETS.update({"spike_momentum_urgent", "spike_momentum_recheck", "spike_momentum_age_urgent"})
    HIGH_BUCKETS.update({"spike_pullback_watch", "spike_pullback_recheck", "spike_stale_recheck"})
except Exception:
    pass

_v504_prev_hot_rank_priority = _hot_rank_priority

def _v504_hot_age(r: Dict[str, Any]) -> float:
    nowv = now_ts()
    observed = fnum(r.get('scanner_hot_observed_1m_sec'), r.get('hot_signal_age_sec'), r.get('signal_age_sec'), r.get('hot_observed_1m_sec'), default=-1.0)
    if observed >= 0:
        return float(observed)
    ts = fnum(r.get('detected_ts'), r.get('updated_ts'), r.get('ts'), default=0.0)
    return max(0.0, nowv - ts) if ts > 1000000000 else 999999.0


def _hot_rank_priority(hot_rows: Dict[str, Dict[str, Any]]) -> List[Dict[str, Any]]:  # type: ignore[override]
    base_rows = _v504_prev_hot_rank_priority(hot_rows) if callable(_v504_prev_hot_rank_priority) else []
    out: List[Dict[str, Any]] = list(base_rows)
    for t, r in hot_rows.items():
        t = ticker_norm(t or r.get('ticker') or r.get('symbol') or r.get('market'))
        if not t:
            continue
        ch1 = fnum(r.get('scanner_change_1m_pct'), r.get('change_1m_pct'), default=0.0)
        ch3 = fnum(r.get('scanner_change_3m_pct'), r.get('change_3m_pct'), default=0.0)
        age = _v504_hot_age(r)
        # 초입 급등은 urgent lane. 늦은 급등은 버리지 않고 눌림/재확인 lane으로 보낸다.
        if age <= 45 and (ch1 >= 0.70 or ch3 >= 1.20):
            pri = 520.0 + max(0.0, ch1)*35.0 + max(0.0, ch3)*22.0 + max(0.0, 45.0-age)*1.2
            out.append({'ticker':t,'priority':round(pri,3),'bucket':'spike_momentum_age_urgent','need':['ws','micro'],'source':'scanner_hot_rank_v504_age_urgent','micro_urgent':True,'hot_signal_age_sec':round(age,1),'change_1m':ch1,'change_3m':ch3,'v504_urgent_age_lane':True})
        elif age <= 180 and (ch1 >= 0.35 or ch3 >= 0.90):
            pri = 310.0 + max(0.0, ch1)*18.0 + max(0.0, ch3)*12.0
            out.append({'ticker':t,'priority':round(pri,3),'bucket':'spike_momentum_recheck','need':['ws','micro'],'source':'scanner_hot_rank_v504_momentum_recheck','micro_urgent':True,'hot_signal_age_sec':round(age,1),'change_1m':ch1,'change_3m':ch3,'v504_recheck_age_lane':True})
        elif age <= 600 and (ch1 >= 0.20 or ch3 >= 0.60):
            pri = 230.0 + max(0.0, ch1)*12.0 + max(0.0, ch3)*8.0
            out.append({'ticker':t,'priority':round(pri,3),'bucket':'spike_pullback_watch','need':['ws','micro'],'source':'scanner_hot_rank_v504_pullback_watch','micro_urgent':False,'hot_signal_age_sec':round(age,1),'change_1m':ch1,'change_3m':ch3})
    return out

_v504_prev_run_once = run_once

def run_once() -> Dict[str, Any]:  # type: ignore[override]
    p = _v504_prev_run_once()
    try:
        write_status(
            'running',
            v504_spike_urgent_age_lane=True,
            v504_policy='전체시장 유지 + 초입 급등 urgent age lane + 늦은 급등 재확인/눌림 lane',
            queue_count=p.get('queue_count', 0),
            active_target_count=p.get('active_target_count', p.get('target_count', 0)),
            target_count=p.get('target_count', 0),
            hot_rank_req_count=p.get('hot_rank_req_count', 0),
            hot_rank_active_count=p.get('hot_rank_active_count', 0),
            recheck_req_count=p.get('recheck_req_count', 0),
            recheck_micro_target_count=p.get('recheck_micro_target_count', 0),
        )
    except Exception as exc:
        append_error('v504_status_marker', exc)
    return p


def main() -> None:  # type: ignore[override]
    write_status('running', phase='boot', target_count=0, queue_count=0, dropped_count=0, v504_spike_urgent_age_lane=True)
    while True:
        try:
            run_once()
        except KeyboardInterrupt:
            write_status('stopping')
            raise
        except Exception as exc:
            append_error('loop', exc)
            write_status('error', error=f"{exc.__class__.__name__}: {exc}")
        time.sleep(max(0.5, INTERVAL_SEC))


# =============================================================================
# target_router_worker v0.14 / v506: spike urgent freshness acceleration + stale cause trace
# - v505/v504 results showed spike entries with hot≈60s and micro/orderflow≈10s.
# - Stale candidates must not only be blocked in strategy; the router must show WHY
#   they became stale and push early spike candidates to the fastest lane.
# - No fixed-N market cut: full queue/export remains. This only changes priority/lane.
# =============================================================================
VERSION = "target_router_worker_v0.25_structure_recheck_priority_2026-06-10"
try:
    CRITICAL_BUCKETS.update({"spike_momentum_age_urgent", "spike_momentum_urgent", "spike_fresh_s1_probe"})
    HIGH_BUCKETS.update({"spike_momentum_recheck", "spike_pullback_watch", "spike_pullback_recheck", "spike_stale_recheck"})
except Exception:
    pass

V506_TARGET_TRACE = BASE_DIR / "clean_target_router_spike_v506_trace.json"
_v506_prev_hot_rank_priority = _hot_rank_priority

def _v506_hot_age(r: Dict[str, Any]) -> float:
    try:
        age = fnum(r.get('scanner_hot_observed_1m_sec'), r.get('hot_signal_age_sec'), r.get('signal_age_sec'), r.get('hot_observed_1m_sec'), default=-1.0)
        if age >= 0:
            return float(age)
        ts = fnum(r.get('detected_ts'), r.get('updated_ts'), r.get('ts'), default=0.0)
        return max(0.0, now_ts() - ts) if ts > 1000000000 else 999999.0
    except Exception:
        return 999999.0


def _hot_rank_priority(hot_rows: Dict[str, Dict[str, Any]]) -> List[Dict[str, Any]]:  # type: ignore[override]
    base_rows = _v506_prev_hot_rank_priority(hot_rows) if callable(_v506_prev_hot_rank_priority) else []
    out: List[Dict[str, Any]] = list(base_rows)
    trace_rows: List[Dict[str, Any]] = []
    counts = {'urgent_fresh':0, 'stale_recheck':0, 'pullback_watch':0, 'ignored':0}
    for t, r in hot_rows.items():
        t = ticker_norm(t or r.get('ticker') or r.get('symbol') or r.get('market'))
        if not t:
            continue
        ch1 = fnum(r.get('scanner_change_1m_pct'), r.get('change_1m_pct'), default=0.0)
        ch3 = fnum(r.get('scanner_change_3m_pct'), r.get('change_3m_pct'), default=0.0)
        age = _v506_hot_age(r)
        row = {'ticker':t,'hot_signal_age_sec':round(age,1),'change_1m':ch1,'change_3m':ch3}
        # Fresh spike lane: highest router priority. These are the only rows that should be able
        # to become immediate spike_momentum S1 after strategy confirms micro/orderflow freshness.
        if age <= 45 and (ch1 >= 0.70 or ch3 >= 1.20):
            pri = 760.0 + max(0.0, ch1)*45.0 + max(0.0, ch3)*30.0 + max(0.0, 45.0-age)*2.0
            item = {
                'ticker':t,'priority':round(pri,3),'bucket':'spike_momentum_age_urgent',
                'need':['ws','micro'],'need_micro':True,'need_quote':True,
                'source':'scanner_hot_rank_v506_fresh_urgent','micro_urgent':True,
                'hot_signal_age_sec':round(age,1),'change_1m':ch1,'change_3m':ch3,
                'v506_spike_fresh_urgent':True,
                'stale_reason':'fresh_urgent_candidate',
            }
            out.append(item)
            counts['urgent_fresh'] += 1
            row.update({'lane':'urgent_fresh','priority':item['priority']})
        elif age <= 180 and (ch1 >= 0.35 or ch3 >= 0.90):
            # Late spike is not for immediate ride. Keep it alive as recheck/pullback watch,
            # but make the stale cause visible so strategy/paper can explain why it cannot S1.
            pri = 300.0 + max(0.0, ch1)*18.0 + max(0.0, ch3)*12.0
            item = {
                'ticker':t,'priority':round(pri,3),'bucket':'spike_stale_recheck',
                'need':['ws','micro'],'need_micro':True,'need_quote':True,
                'source':'scanner_hot_rank_v506_stale_recheck','micro_urgent':False,
                'hot_signal_age_sec':round(age,1),'change_1m':ch1,'change_3m':ch3,
                'v506_spike_stale_recheck':True,
                'stale_reason':f'hot_signal_age>{45.0:.0f}s',
            }
            out.append(item)
            counts['stale_recheck'] += 1
            row.update({'lane':'stale_recheck','priority':item['priority'],'stale_reason':item['stale_reason']})
        elif age <= 600 and (ch1 >= 0.20 or ch3 >= 0.60):
            pri = 220.0 + max(0.0, ch1)*12.0 + max(0.0, ch3)*8.0
            item = {
                'ticker':t,'priority':round(pri,3),'bucket':'spike_pullback_watch',
                'need':['ws','micro'],'need_micro':True,'need_quote':True,
                'source':'scanner_hot_rank_v506_pullback_watch','micro_urgent':False,
                'hot_signal_age_sec':round(age,1),'change_1m':ch1,'change_3m':ch3,
                'v506_spike_pullback_watch':True,
                'stale_reason':'pullback_watch_not_immediate_spike',
            }
            out.append(item)
            counts['pullback_watch'] += 1
            row.update({'lane':'pullback_watch','priority':item['priority']})
        else:
            counts['ignored'] += 1
            row.update({'lane':'ignored'})
        if row.get('lane') != 'ignored':
            trace_rows.append(row)
    try:
        save_json(V506_TARGET_TRACE, {
            'schema':'target_router_spike_freshness_trace_v506',
            'version':VERSION,
            'updated_ts':now_ts(),
            'updated_text':now_text(),
            'counts':counts,
            'sample':trace_rows[:80],
            'policy':'초입 급등은 urgent lane으로 빠르게 보내고, hot age가 늦은 급등은 S1용이 아니라 stale recheck/pullback watch로 보낸다. 전체시장은 자르지 않는다.',
        })
    except Exception as exc:
        append_error('v506_target_spike_trace', exc)
    return out

_v506_prev_run_once = run_once

def run_once() -> Dict[str, Any]:  # type: ignore[override]
    p = _v506_prev_run_once()
    try:
        tr = load_json(V506_TARGET_TRACE, {}) or {}
        cnt = tr.get('counts') if isinstance(tr, dict) and isinstance(tr.get('counts'), dict) else {}
        write_status(
            'running',
            v506_spike_freshness_lane=True,
            v506_policy='v576 S2 urgent front + 전체시장 유지 + fresh spike urgent lane',
            queue_count=p.get('queue_count', 0),
            active_target_count=p.get('active_target_count', p.get('target_count', 0)),
            target_count=p.get('target_count', 0),
            hot_rank_req_count=p.get('hot_rank_req_count', 0),
            hot_rank_active_count=p.get('hot_rank_active_count', 0),
            recheck_req_count=p.get('recheck_req_count', 0),
            recheck_micro_target_count=p.get('recheck_micro_target_count', 0),
            v506_urgent_fresh_count=cnt.get('urgent_fresh', 0),
            v506_stale_recheck_count=cnt.get('stale_recheck', 0),
            v506_pullback_watch_count=cnt.get('pullback_watch', 0),
            v613_orderflow_micro_req_count=p.get('v613_orderflow_micro_req_count', 0),
            v614_orderflow_micro_ack=(p.get('v614_orderflow_micro_ack') or {}),
        )
    except Exception as exc:
        append_error('v506_status_marker', exc)
    return p

def main() -> None:  # type: ignore[override]
    write_status('running', phase='boot', target_count=0, queue_count=0, dropped_count=0, v506_spike_freshness_lane=True)
    while True:
        try:
            run_once()
        except KeyboardInterrupt:
            write_status('stopping')
            raise
        except Exception as exc:
            append_error('loop', exc)
            write_status('error', error=f"{exc.__class__.__name__}: {exc}")
        time.sleep(max(0.5, INTERVAL_SEC))

if __name__ == "__main__":
    main()
