from __future__ import annotations
import ast
import hashlib
import importlib.util
import json
import tempfile
import shutil
import time
from pathlib import Path

ROOT=Path(__file__).resolve().parent
PAPER=ROOT/'paper_bot_v1.022.py'
PREV=Path('/mnt/data/coinbot_v1134_src/코인봇_최신전체코드_v1134_CHECK_20260629/paper_bot_v1.021.py')


_IMPORT_TMP=tempfile.TemporaryDirectory()
_IMPORT_PAPER=Path(_IMPORT_TMP.name)/PAPER.name
shutil.copy2(PAPER,_IMPORT_PAPER)

def import_paper():
    spec=importlib.util.spec_from_file_location('paper_v1135_contract_test',_IMPORT_PAPER)
    mod=importlib.util.module_from_spec(spec)
    assert spec and spec.loader
    spec.loader.exec_module(mod)
    return mod


def remap(mod, base: Path):
    mod.BASE_DIR=base
    names={
        'open':'paper_bot_open.json','closed':'paper_bot_closed.jsonl','status':'paper_bot_status.json',
        'control':'paper_bot_control.json','error':'paper_bot_error.log','s1_hold':'paper_s1_hold_cache.json',
    }
    for key,name in names.items(): mod.FILES[key]=base/name
    mod.BOOK_RESET_CONTROL_V1044=base/'paper_quality_rebuild_control_v1095.json'
    mod.BOOK_RESET_MANIFEST_V1044=base/'paper_quality_rebuild_manifest_v1095.json'
    mod.BOOK_RESET_STATUS_V1044=base/'paper_quality_rebuild_status_v1095.json'
    mod.BOOK_RESET_EVENTS_V1044=base/'paper_quality_rebuild_events_v1095.jsonl'
    mod.BOOK_RESET_EXECUTION_V1045=base/'paper_quality_rebuild_execution_v1095.json'
    mod.PERFORMANCE_EPOCH_V1045=base/'paper_quality_rebuild_epoch_v1095.json'
    mod.PERFORMANCE_EPOCH_EVENTS_V1045=base/'paper_performance_epoch_events_v1045.jsonl'
    mod.V1135_RESET_BASELINE=base/'paper_v1135_fresh_epoch_reset_baseline.json'
    mod.V1135_RESET_MARKER=base/'runtime'/'v1135_user_approved_fresh_epoch_reset.seeded'
    mod.V1135_TRIGGER_AUDIT=base/'paper_trigger_occurrence_audit_v1135.json'
    mod.V1135_FRESH_PATH_EVIDENCE=base/'paper_fresh_path_evidence_v1135.json'
    mod.V1135_STRATEGY_TRIGGER_STATE=base/'clean_strategy_swing_gate_state_v977.json'
    if hasattr(mod,'_v1054_open_cache_invalidate'):
        mod._v1054_open_cache_invalidate('test-remap')


def function_segment(path: Path, name: str) -> str:
    text=path.read_text(encoding='utf-8')
    tree=ast.parse(text)
    nodes=[n for n in ast.walk(tree) if isinstance(n,(ast.FunctionDef,ast.AsyncFunctionDef)) and n.name==name]
    assert nodes, name
    node=nodes[0]
    lines=text.splitlines(keepends=True)
    return ''.join(lines[node.lineno-1:node.end_lineno])

m=import_paper()
assert m.VERSION=='paper_bot_v1.022'
assert m.BUILD_LABEL=='v1135_fresh_epoch_reset_rr_reader_truth_2026-06-29'

# RR owner truth and missing contract.
rr,src=m._v1135_candidate_rr({'swing_entry_gate_v977':{'risk_reward':2.345}})
assert abs(rr-2.345)<1e-9 and src=='swing_entry_gate_v977.risk_reward'
rr,src=m._v1135_candidate_rr({})
assert rr is None and src=='MISSING'

with tempfile.TemporaryDirectory() as td:
    base=Path(td); remap(m,base)
    old=time.time()-600
    (base/'paper_bot_open.json').write_text(json.dumps({'p1':{'pos_id':'p1','ticker':'KRW-TEST','entry_price':100.0,'opened_at':old}}),encoding='utf-8')
    (base/'paper_bot_status.json').write_text(json.dumps({'version':'paper_bot_v1.021','pick_stats':{}}),encoding='utf-8')
    hold={'rows':[{'ticker':'KRW-POL','swing_entry_gate_v977':{'trigger_occurrence_v1037':{'decision_key':'d1','event_ts':time.time()-999,'qualification_state':'QUALIFIED_EVENT','contract_ready_at_cross':True}}}]}
    (base/'paper_s1_hold_cache.json').write_text(json.dumps(hold),encoding='utf-8')
    (base/'paper_bot_control.json').write_text(json.dumps({'candidate_ttl_sec':120}),encoding='utf-8')
    (base/'paper_quality_rebuild_epoch_v1095.json').write_text(json.dumps({'epoch_id':'old-epoch','state':'ACTIVE','zero_open_proof':True,'started_at':old}),encoding='utf-8')
    if hasattr(m,'_v1054_open_cache_invalidate'): m._v1054_open_cache_invalidate('reset-test')
    m._v1135_start_fresh_epoch_reset_once()
    baseline=json.loads(m.V1135_RESET_BASELINE.read_text(encoding='utf-8'))
    manifest=json.loads(m.BOOK_RESET_MANIFEST_V1044.read_text(encoding='utf-8'))
    control=json.loads(m.BOOK_RESET_CONTROL_V1044.read_text(encoding='utf-8'))
    assert baseline['target_open_count']==1
    assert baseline['stale_occurrence_proof_before_reset']['stale']>=1
    assert manifest['target_open_count']==1
    assert manifest['recovery_reason_v1097']==m.V1135_RESET_REASON
    assert control['entry_freeze'] is True and control['state']=='PREPARED_ENTRY_FREEZE'
    assert m.V1135_RESET_MARKER.exists()

    # Reset close metadata is added without replacing the canonical commit spine.
    original=m._V1135_PREV_BUILD_RESET_CLOSED
    try:
        m._V1135_PREV_BUILD_RESET_CLOSED=lambda *a,**k: ({'x':1},{'operator_book_reset_v1045':True})
        _u,c=m._v1045_build_reset_closed('p1',{}, {}, {'recovery_reason_v1097':m.V1135_RESET_REASON})
        assert c['fresh_epoch_reset_v1135'] is True
        assert c['operator_reset_cohort_label_v1135']=='PRE_V1135_LEGACY_OPEN'
    finally:
        m._V1135_PREV_BUILD_RESET_CLOSED=original

    # Same-above audit: stable key is accepted, changed key on same reset is a violation.
    def write_state(ts,decision):
        obj={'updated_ts':ts,'active':{'market:TEST':{'trigger_side_v1133':'above','trigger_reset_ts_v1133':10.0,'trigger_event_ts_v1133':20.0,'trigger_occurrence_decision_key_v1133':decision,'trigger_qualification_state_v1133':'QUALIFIED_EVENT'}}}
        m.V1135_STRATEGY_TRIGGER_STATE.write_text(json.dumps(obj),encoding='utf-8')
    write_state(1.0,'A'); m._v1135_update_trigger_stability_audit()
    write_state(2.0,'A'); a=m._v1135_update_trigger_stability_audit()
    assert a['qualified_above_stable_samples']>=1 and a['same_above_decision_violation_count']==0
    write_state(3.0,'B'); a=m._v1135_update_trigger_stability_audit()
    assert a['same_above_decision_violation_count']==1

    # Fresh path evidence persists across different cycles instead of requiring one status snapshot.
    m.PERFORMANCE_EPOCH_V1045.write_text(json.dumps({'epoch_id':'post-v1135','state':'ACTIVE','started_at':time.time()}),encoding='utf-8')
    keys=['trigger_occurrence_fresh_pass_v1133','paper_ttl_pass_v1099','paper_execution_pass_v1099','paper_final_safety_pass_v1099','selected_s1']
    for key in keys:
        m._v1135_update_fresh_path_evidence({'pick_stats':{key:1}})
    evidence=json.loads(m.V1135_FRESH_PATH_EVIDENCE.read_text(encoding='utf-8'))
    assert evidence['complete'] is True

# Core trading and exact-commit functions from v1134 are unchanged.
for name in ('trigger_occurrence_freshness_v1133','paper_final_safety','update_position','commit_closed_position_exact','open_position__L23309','_v1045_execute_bulk_close'):
    assert hashlib.sha256(function_segment(PREV,name).encode()).hexdigest()==hashlib.sha256(function_segment(PAPER,name).encode()).hexdigest(), name

print('PASS v1135 reset, RR reader, fresh evidence, same-above audit, core invariants')
