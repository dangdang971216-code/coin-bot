from pathlib import Path
import ast,re
p=Path(__file__).resolve().parent/'coinbot_main_v2_13_1102.py'
s=p.read_text(encoding='utf-8')
ast.parse(s)
versions=re.findall(r"^BOT_VERSION\s*=\s*['\"]([^'\"]+)",s,re.M)
builds=re.findall(r"^V650_BUILD_LABEL\s*=\s*['\"]([^'\"]+)",s,re.M)
assert versions[-1]=='수익형 v2.13.1102'
assert builds[-1]=='v1135_fresh_epoch_reset_rr_reader_closeout_2026-06-29'
assert "trigger_regression_v1133.fresh_path_server_done_v1135" in s
assert "paper_fresh_path_evidence_v1135.json" in s
assert "same_above_new_decision_zero" in s
assert "version-only v1133 DONE condition" in s
assert "EXPECTED_PAPER_VERSION = 'paper_bot_v1.022'" in s
print('PASS v1135 main evidence closeout contract')
