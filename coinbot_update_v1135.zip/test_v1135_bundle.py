from pathlib import Path
import ast,json,py_compile,re
root=Path(__file__).resolve().parent
m=json.loads((root/'DEPLOY_BUNDLE.json').read_text(encoding='utf-8'))
assert m['version']=='v1135'
assert m['main']=='coinbot_main_v2_13_1102.py'
assert m['paper']=='paper_bot_v1.022.py'
assert m.get('workers')=={}
assert m['auto_buy'] is False
assert m['live_ledger_included'] is False
assert m['user_approved_operator_reset'] is True
required=[m['main'],m['paper'],*m['support_files']]
missing=[x for x in required if not (root/x).exists()]
assert not missing,missing
for name in (m['main'],m['paper']):
 p=root/name; ast.parse(p.read_text(encoding='utf-8')); py_compile.compile(str(p),doraise=True)
inv=json.loads((root/'TRADING_RULES_INVARIANT_V1135.json').read_text(encoding='utf-8'))
assert inv['strategy_source']['changed'] is False
assert all(x['unchanged'] for x in inv['paper_core_functions'].values())
assert inv['limits']=={'max_open':30,'max_new_per_cycle':3,'changed':False}
assert not any(inv['formulas'].values())
print('PASS v1135 bundle contract')
