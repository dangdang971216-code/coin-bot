# v1135 scope and verification

## Locked scope

- User-approved exact close of every current PAPER OPEN.
- Preserve all original OPEN/CLOSED/decision history; no delete, shrink or rewrite.
- Start a new post-v1135 performance epoch only after OPEN zero proof.
- Fix `/candidate_summary` RR owner to `swing_entry_gate_v977.risk_reward`.
- Show `MISSING/CHECK` instead of fabricated `0.000`.
- Preserve pre-reset stale-occurrence proof.
- Accumulate fresh occurrence path evidence across cycles.
- Audit same-above decision stability read-only from Strategy state.
- Replace the weak version-only v1133 DONE condition with evidence checks.

## Not changed

- Strategy v1.011 source.
- Quality Gate and rank.
- Trigger price, candidate TTL, invalid, target and trailing formulas.
- OPEN limit 30 and cycle new limit 3.
- Auto-buy remains OFF.

## Exact reset transaction

1. Capture pre-reset status, current OPEN membership and stale occurrence evidence.
2. Reseal current OPEN into a new v1135 reset batch.
3. Freeze new PAPER entries.
4. For each target: append/fsync/verify CLOSED -> decision CLOSED -> remove OPEN.
5. Failed positions remain OPEN and the reset stays PARTIAL.
6. After zero OPEN proof, create a new post-v1135 epoch.
7. Reset closures remain exact history but are excluded from strategy performance windows.

## Server DONE contract

- Paper v1.022 and Main v2.13.1102 runtime identities.
- v1135 reset batch, remaining 0, unresolved 0, failed 0.
- zero-open proof and active post-v1135 epoch.
- RR reader owner active and no zero fallback.
- stale occurrence proof preserved from pre-reset runtime.
- one fresh qualified rebreak reaches occurrence TTL, execution freshness, final safety and selection/open.
- same-above stable sample at least 1 and decision churn violations 0.
- owner gap 0 and runtime mismatch 0.

Until the fresh event occurs, v1135 remains CHECK.
