#!/usr/bin/env python3
from pathlib import Path
import ast
from collections import Counter
SRC=Path(__file__).with_name('coinbot_main_v2_13_1124.py')
text=SRC.read_text(encoding='utf-8')
mod=ast.parse(text)
names=Counter(n.name for n in mod.body if isinstance(n,(ast.FunctionDef,ast.AsyncFunctionDef,ast.ClassDef)))
assert not {k:v for k,v in names.items() if v>1}, names
assert "BOT_VERSION = '수익형 v2.13.1124'" in text
assert "V650_BUILD_LABEL = 'v1164_main_ledger_status_closeout_bundle_2026-06-30'" in text
assert "EXPECTED_STRATEGY_VERSION = 'strategy_worker_v1.023'" in text
assert "return _v1161_compact_issue_ledger(body)" in text
assert "활성 issue 없음" not in text[text.index('def compact_command_output'):text.index('def build_command_summary_text')]
assert "운영 요약집 v1159" not in text
assert "코인봇 운영지도 v1160" not in text
assert "코인봇 후보·구조 기준판 v1160" not in text
assert "숫자 범위: 전달=current Strategy cycle" in text
assert "v1164-closeout-v1152-pipeline-progress-001" in text
assert "v1164-closeout-v1156-same-snapshot-001" in text
assert "LEGACY-ISSUE-LIFECYCLE-CLOSEOUT-001','DONE'" in text
assert "Gate·rank·TTL·RR·trigger·invalid·target·청산·OPEN 30/cycle 3" in text
print('PASS v1164 contract')
