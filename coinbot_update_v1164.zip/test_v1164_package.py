#!/usr/bin/env python3
from pathlib import Path
import json, hashlib
ROOT=Path(__file__).parent
manifest=json.loads((ROOT/'DEPLOY_BUNDLE.json').read_text(encoding='utf-8'))
assert manifest['version']=='v1164'
assert manifest['main']=='coinbot_main_v2_13_1124.py'
assert manifest['approved_target']==manifest['main']
assert manifest['approved_target_sha256']==hashlib.sha256((ROOT/manifest['main']).read_bytes()).hexdigest()
assert manifest['guard'] is None and manifest['paper'] is None and manifest['workers']=={}
assert manifest['expected_unchanged_runtime']['strategy']=='strategy_worker_v1.023'
assert manifest['main_source_change'] is True
assert manifest['guard_source_change'] is False
assert manifest['paper_source_change'] is False
assert manifest['strategy_source_change'] is False
assert manifest['auto_buy'] is False
for name in manifest['support_files']:
    assert (ROOT/name).exists(), name
for forbidden in ('paper_bot.py','strategy_worker.py','backga_guard_bot.py','paper_bot_open.jsonl','paper_bot_closed.jsonl','issue_ledger.jsonl'):
    assert not (ROOT/forbidden).exists(), forbidden
print('PASS v1164 package')
