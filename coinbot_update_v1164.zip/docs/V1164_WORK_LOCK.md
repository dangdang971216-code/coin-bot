# v1164 작업 잠금
- 증상: Main이 v1160이라 문제장부 요약은 비고, v1162 신규 issue와 과거 CHECK closeout이 서버 장부에 반영되지 않음.
- 실제 원인: 구 compact parser, 고정 버전 제목, 미적용 v1161/v1162 Main source, lifecycle 최신 이벤트 부족.
- 수정 owner: Main 장부·명령 요약·후보판 scope·배포 신원만.
- 수정 파일: coinbot_main_v2_13_1124.py.
- 삭제 구경로: 구 OPEN/CHECK 재파싱, 중복 renderer, 고정 v1159/v1160 제목, 미종결 v1152~v1156 최신상태.
- 새 본선: canonical 한글 board 1개 + dynamic release tag + append-only closeout + current/completed/cohort scope.
- 변경 금지: Gate·rank·TTL·RR·trigger·invalid·target·청산·OPEN 30/cycle 3·자동매수.
- Guard/Paper/Strategy source와 자체 VERSION/BUILD는 변경하지 않음.
