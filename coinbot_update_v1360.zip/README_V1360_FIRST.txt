v1360: old-base rebuild compatibility fix. Main command spine restored; Strategy cycle/commit bridge added. No trading criteria change. Auto-buy OFF.
