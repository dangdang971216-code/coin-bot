v1357 OLD_BASE_REBUILD_RUNTIME_START
- Applies old-base Main/Paper/Strategy only.
- Keeps current Guard and other workers unchanged.
- Auto-buy stays OFF.
- This is runtime-start stage, not final latest-feature graft.
- Safer preflight: apply after current OPEN is 0, or after operator-approved reset/close.
