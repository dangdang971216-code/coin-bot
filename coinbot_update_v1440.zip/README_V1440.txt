coinbot_update_v1440

목적: shadow 출력 가독성 정리판입니다.
- /dynamic_structure_shadow, /no_progress_shadow, /exit_shadow_contracts, /profit_shadow, /buried_shadow 를 이모지 섹션/줄바꿈/한글 원인명/TOP 3/하단 결론 형식으로 정리
- /shadow_board 통합요약 추가
- dynamic shadow의 OPEN 표시는 version_score와 같은 OPEN book 기준도 함께 사용
- 실제 S1, Paper 진입, OPEN, trigger, invalid, target, trailing, 청산, 자동정지, 자동매수 변경 없음

적용 후 확인:
/shadow_board
/dynamic_structure_shadow
/no_progress_shadow
/exit_shadow_contracts
/profit_shadow
/buried_shadow
/version_score
/errorlog
