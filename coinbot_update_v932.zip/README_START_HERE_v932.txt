v932: v931 부분적용 닫기 + 장부 실표시 + S1 hold/reject 실경량화 + 다중명령 TXT + 후보품질 읽기전용 감사. 적용 후 메인봇 /change_verify /issue_ledger /health /candidate_quality_audit /errorlog. 가드봇은 별도 /gdeep_audit 20.
