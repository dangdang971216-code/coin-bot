#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Coinbot Review worker v1.025 / v1236.

Single owner for observation, candidate-standard, and read-only trade review.
The worker never changes Strategy candidate decisions, Paper OPEN/CLOSED, or
trading rules. It consumes the immutable Strategy generation committed before
handoff and the canonical Paper performance snapshot.
"""
from __future__ import annotations

import argparse
import hashlib
import json
import re
import math
import statistics
import atexit
import fcntl
import os
import signal
import sys
import time
import traceback
from pathlib import Path
from typing import Any, Dict, Optional

from canonical_spine_v1187 import (
    AUTO_BUY,
    SPINE_SCHEMA,
    STRATEGY_MODE,
    SpinePaths,
    append_jsonl,
    atomic_write_json,
    build_candidate_standard,
    build_review_snapshot,
    digest_obj,
    integer,
    mapping,
    num,
    now_text,
    now_ts,
    read_json,
    read_candidate_rows,
)

VERSION = "review_worker_v1.025"
BUILD_LABEL = "v1236_multistate_truth_and_semantic_dedupe_2026-07-05"
DEFAULT_INTERVAL_SEC = 3.0
HEARTBEAT_SEC = 5.0
_STOP = False
_LOCK_HANDLE: Optional[Any] = None

V1233_RETENTION_SEC = 24.0 * 3600.0
V1233_MISSED_HORIZON_SEC = 6.0 * 3600.0
V1233_SHADOW_FEE_PCT = 0.10
V1233_STATE_SCHEMA = "version_score_review_state_v1236"
V1233_SUMMARY_SCHEMA = "canonical_version_score_review_v1236"


def version_score_state_path(base: Path) -> Path:
    return base / "version_score_review_state_v1236.json"


def version_score_summary_path(base: Path) -> Path:
    return base / "canonical_version_score_review_v1236.json"


def _v1233_float(*values: Any, default: float = 0.0) -> float:
    for value in values:
        try:
            if value is None or value == "":
                continue
            out = float(value)
            if out == out and abs(out) != float("inf"):
                return out
        except (TypeError, ValueError, OverflowError):
            continue
    return default


def _v1233_ticker(row: Dict[str, Any]) -> str:
    return str(row.get("ticker") or row.get("market") or row.get("symbol") or "").strip().upper()


def _v1233_price(row: Dict[str, Any]) -> float:
    return _v1233_float(
        row.get("current_price"), row.get("live_price"), row.get("price"),
        row.get("trade_price"), row.get("close"), row.get("last_price"), default=0.0,
    )


def _v1233_nested(row: Dict[str, Any], *names: str) -> Dict[str, Any]:
    for name in names:
        value = row.get(name)
        if isinstance(value, dict):
            return value
    gate = row.get("swing_entry_gate_v977") if isinstance(row.get("swing_entry_gate_v977"), dict) else {}
    for name in names:
        value = gate.get(name)
        if isinstance(value, dict):
            return value
    return {}


def _v1233_line_price(obj: Any) -> float:
    if not isinstance(obj, dict):
        return 0.0
    return _v1233_float(obj.get("rounded_price"), obj.get("raw_price"), obj.get("price"), default=0.0)


def _v1236_sig_price(value: float) -> str:
    try:
        value=float(value)
    except (TypeError,ValueError):
        return "0"
    if value<=0:
        return "0"
    return f"{value:.6g}"


def _v1236_line_tf(obj: Any) -> str:
    return str(obj.get("tf") or obj.get("timeframe") or "") if isinstance(obj,dict) else ""


def _v1233_event_identity(row: Dict[str, Any], ticker: str, suffix: str) -> str:
    """Semantic occurrence key, stable across repeated Strategy cycles.

    v1235 preferred trigger event_ts, but that timestamp can be refreshed every
    cycle and created duplicate review/shadow events. v1236 keys by the sealed
    executable structure. v1211 shadow suffix already contains its three lines.
    """
    if str(suffix).startswith("v1211:"):
        stable=str(suffix)
    else:
        plan=_v1233_nested(row,"dynamic_structure_plan_v1212","structure_contract_v1212")
        trigger=plan.get("trigger") if isinstance(plan.get("trigger"),dict) else {}
        invalid=plan.get("invalid") if isinstance(plan.get("invalid"),dict) else {}
        target=plan.get("target") if isinstance(plan.get("target"),dict) else {}
        intermediate=plan.get("intermediate_resistance_v1225") if isinstance(plan.get("intermediate_resistance_v1225"),dict) else {}
        line_sig='|'.join((
            _v1236_sig_price(_v1233_line_price(trigger)),_v1236_line_tf(trigger),
            _v1236_sig_price(_v1233_line_price(invalid)),_v1236_line_tf(invalid),
            _v1236_sig_price(_v1233_line_price(target)),_v1236_line_tf(target),
            _v1236_sig_price(_v1233_line_price(intermediate)),_v1236_line_tf(intermediate),
        ))
        structure_hash=str(row.get("structure_contract_hash") or plan.get("structure_contract_hash") or "").strip()
        if line_sig.replace('|','').replace('0',''):
            stable=f"{suffix}|lines:{line_sig}"
        elif structure_hash:
            stable=f"{suffix}|hash:{structure_hash}"
        else:
            # No structure means one active semantic event per ticker/reason,
            # not one event per refreshed cycle timestamp.
            stable=f"{suffix}|no_structure"
    return hashlib.sha256(f"{ticker}|{stable}".encode("utf-8",errors="ignore")).hexdigest()[:24]

def _v1233_return_pct(price: float, start: float) -> Optional[float]:
    if price <= 0 or start <= 0:
        return None
    return (price - start) / start * 100.0


def _v1233_empty_state(nowv: float) -> Dict[str, Any]:
    return {
        "schema": V1233_STATE_SCHEMA,
        "started_ts": nowv, "started_text": now_text(nowv),
        "updated_ts": nowv, "updated_text": now_text(nowv),
        "retention_sec": V1233_RETENTION_SEC,
        "missed": {"events": {}},
        "previous_structure_shadow": {"pending": {}, "open": {}, "closed": [], "skipped": []},
        "auto_buy": False,
    }


def _v1233_metric(rows: list[Dict[str, Any]]) -> Dict[str, Any]:
    values = [_v1233_float(r.get("net_pnl_pct"), default=0.0) for r in rows]
    wins = sum(1 for x in values if x > 0)
    losses = sum(1 for x in values if x < 0)
    return {
        "count": len(rows), "wins": wins, "losses": losses,
        "win_rate": (wins / len(rows) * 100.0) if rows else None,
        "total_pct": sum(values) if values else 0.0,
        "avg_pct": (sum(values) / len(values)) if values else None,
        "avg_mfe_pct": (sum(_v1233_float(r.get("mfe_pct"), default=0.0) for r in rows) / len(rows)) if rows else None,
        "avg_mae_pct": (sum(_v1233_float(r.get("mae_pct"), default=0.0) for r in rows) / len(rows)) if rows else None,
    }


def _v1233_missed_reason(row: Dict[str, Any]) -> str:
    plan = _v1233_nested(row, "dynamic_structure_plan_v1212", "structure_contract_v1212")
    pair = plan.get("pairing_contract_v1229") if isinstance(plan.get("pairing_contract_v1229"), dict) else {}
    inv = int(_v1233_float(pair.get("invalid_candidates"), default=0.0))
    tgt = int(_v1233_float(pair.get("target_candidates"), default=0.0))
    passing = int(_v1233_float(pair.get("passing"), default=0.0))
    cost_complete = pair.get("cost_complete") is not False
    intermediate = plan.get("intermediate_resistance_v1225") if isinstance(plan.get("intermediate_resistance_v1225"), dict) else {}
    if inv > 0 and tgt > 0 and passing == 0 and cost_complete:
        return "risk_reward_pair_shortage"
    if inv > 0 and tgt == 0 and intermediate:
        return "only_intermediate_resistance"
    return ""


def _v1233_update_missed(state: Dict[str, Any], rows: list[Dict[str, Any]], prices: Dict[str, float], nowv: float) -> None:
    root=state.setdefault("missed",{}); events=root.setdefault("events",{})
    cutoff=nowv-V1233_RETENTION_SEC
    for key in list(events):
        event=events.get(key) if isinstance(events.get(key),dict) else {}
        if _v1233_float(event.get("created_ts"),default=0.0)<cutoff:
            events.pop(key,None)
    for row in rows:
        ticker=_v1233_ticker(row); price=_v1233_price(row); reason=_v1233_missed_reason(row)
        if not ticker or price<=0 or not reason: continue
        plan=_v1233_nested(row,"dynamic_structure_plan_v1212","structure_contract_v1212")
        trigger=plan.get("trigger") if isinstance(plan.get("trigger"),dict) else {}
        invalid=plan.get("invalid") if isinstance(plan.get("invalid"),dict) else {}
        target=plan.get("target") if isinstance(plan.get("target"),dict) else {}
        intermediate=plan.get("intermediate_resistance_v1225") if isinstance(plan.get("intermediate_resistance_v1225"),dict) else {}
        event_id=_v1233_event_identity(row,ticker,f"missed:{reason}")
        event=events.get(event_id)
        if not isinstance(event,dict):
            event={
                "event_id":event_id,"semantic_event_id":event_id,"ticker":ticker,"reason":reason,
                "created_ts":nowv,"created_text":now_text(nowv),"start_price":price,
                "high_price":price,"low_price":price,"current_price":price,"last_seen_ts":nowv,
                "trigger_price":_v1233_line_price(trigger),"invalid_price":_v1233_line_price(invalid),
                "target_price":_v1233_line_price(target),"intermediate_price":_v1233_line_price(intermediate),
                "trigger_tf":_v1236_line_tf(trigger),"invalid_tf":_v1236_line_tf(invalid),"target_tf":_v1236_line_tf(target),
                "candidate_cycle_id_first":row.get("candidate_pipeline_cycle_id_v1150"),
            }
            events[event_id]=event
        event["candidate_cycle_id_last"]=row.get("candidate_pipeline_cycle_id_v1150")
    for event in events.values():
        if not isinstance(event,dict): continue
        ticker=str(event.get("ticker") or ""); price=prices.get(ticker,0.0); start_price=_v1233_float(event.get("start_price"),default=0.0)
        if price<=0 or start_price<=0: continue
        event["current_price"]=price
        event["high_price"]=max(_v1233_float(event.get("high_price"),default=price),price)
        event["low_price"]=min(_v1233_float(event.get("low_price"),default=price),price)
        event["last_seen_ts"]=nowv
        event["current_return_pct"]=_v1233_return_pct(price,start_price)
        event["max_gain_pct"]=_v1233_return_pct(_v1233_float(event.get("high_price"),default=price),start_price)
        event["max_drawdown_pct"]=_v1233_return_pct(_v1233_float(event.get("low_price"),default=price),start_price)
        age=max(0.0,nowv-_v1233_float(event.get("created_ts"),default=nowv)); event["age_sec"]=age
        if age>=V1233_MISSED_HORIZON_SEC and event.get("return_6h_pct") is None:
            event["return_6h_pct"]=event.get("current_return_pct"); event["completed_6h_ts"]=nowv

def _v1233_shadow_close(root: Dict[str, Any], event_id: str, event: Dict[str, Any], price: float, nowv: float, reason: str) -> None:
    open_map = root.setdefault("open", {})
    open_map.pop(event_id, None)
    entry = _v1233_float(event.get("entry_price"), default=0.0)
    gross = _v1233_return_pct(price, entry) or 0.0
    high = _v1233_float(event.get("high_price"), default=price)
    low = _v1233_float(event.get("low_price"), default=price)
    closed = dict(event)
    closed.update({
        "closed_ts": nowv, "closed_text": now_text(nowv), "close_price": price,
        "exit_reason": reason, "gross_pnl_pct": gross,
        "fee_pct": V1233_SHADOW_FEE_PCT, "net_pnl_pct": gross - V1233_SHADOW_FEE_PCT,
        "mfe_pct": _v1233_return_pct(high, entry) or 0.0,
        "mae_pct": _v1233_return_pct(low, entry) or 0.0,
        "hold_sec": max(0.0, nowv - _v1233_float(event.get("opened_ts"), default=nowv)),
    })
    root.setdefault("closed", []).append(closed)


def _v1233_update_shadow(state: Dict[str, Any], rows: list[Dict[str, Any]], prices: Dict[str, float], nowv: float) -> None:
    root = state.setdefault("previous_structure_shadow", {})
    pending = root.setdefault("pending", {})
    open_map = root.setdefault("open", {})
    closed = root.setdefault("closed", [])
    skipped = root.setdefault("skipped", [])
    cutoff = nowv - V1233_RETENTION_SEC
    root["closed"] = [r for r in closed if isinstance(r, dict) and _v1233_float(r.get("closed_ts"), default=0.0) >= cutoff]
    root["skipped"] = [r for r in skipped if isinstance(r, dict) and _v1233_float(r.get("ts"), default=0.0) >= cutoff]
    closed_ids = {str(r.get("event_id")) for r in root["closed"] if isinstance(r, dict)}
    skipped_ids = {str(r.get("event_id")) for r in root["skipped"] if isinstance(r, dict)}
    for key in list(pending):
        event = pending.get(key) if isinstance(pending.get(key), dict) else {}
        if _v1233_float(event.get("created_ts"), default=0.0) < cutoff:
            pending.pop(key, None)
    for key in list(open_map):
        event = open_map.get(key) if isinstance(open_map.get(key), dict) else {}
        if _v1233_float(event.get("opened_ts"), default=0.0) < cutoff:
            price = prices.get(str(event.get("ticker") or ""), _v1233_float(event.get("last_price"), default=0.0))
            if price > 0:
                _v1233_shadow_close(root, key, event, price, nowv, "REVIEW_24H_TIMEOUT")
            else:
                open_map.pop(key, None)
    for row in rows:
        ticker = _v1233_ticker(row)
        price = _v1233_price(row)
        shadow = row.get("v1211_structure_shadow_v1222") if isinstance(row.get("v1211_structure_shadow_v1222"), dict) else {}
        trigger = _v1233_line_price(shadow.get("trigger"))
        invalid = _v1233_line_price(shadow.get("invalid"))
        target = _v1233_line_price(shadow.get("target"))
        if not ticker or price <= 0 or shadow.get("source_exact") is not True or not (0 < invalid < trigger < target):
            continue
        event_id = _v1233_event_identity(row, ticker, f"v1211:{trigger:.12g}:{invalid:.12g}:{target:.12g}")
        if event_id in pending or event_id in open_map or event_id in closed_ids or event_id in skipped_ids:
            continue
        pending[event_id] = {
            "event_id": event_id, "ticker": ticker, "created_ts": nowv, "created_text": now_text(nowv),
            "trigger_price": trigger, "invalid_price": invalid, "target_price": target,
            "last_price": price, "candidate_cycle_id": row.get("candidate_pipeline_cycle_id_v1150"),
            "source": "v1211_structure_shadow_v1222",
        }
    for event_id in list(pending):
        event = pending.get(event_id) if isinstance(pending.get(event_id), dict) else {}
        ticker = str(event.get("ticker") or "")
        price = prices.get(ticker, _v1233_float(event.get("last_price"), default=0.0))
        trigger = _v1233_float(event.get("trigger_price"), default=0.0)
        invalid = _v1233_float(event.get("invalid_price"), default=0.0)
        target = _v1233_float(event.get("target_price"), default=0.0)
        event["last_price"] = price
        if price <= 0:
            continue
        if price <= invalid:
            pending.pop(event_id, None)
            root["skipped"].append({"event_id":event_id,"ticker":ticker,"ts":nowv,"reason":"INVALID_BEFORE_ENTRY"})
        elif price >= target:
            pending.pop(event_id, None)
            root["skipped"].append({"event_id":event_id,"ticker":ticker,"ts":nowv,"reason":"TARGET_ALREADY_PASSED_BEFORE_OBSERVED_ENTRY"})
        elif price >= trigger:
            pending.pop(event_id, None)
            opened = dict(event)
            opened.update({
                "opened_ts": nowv, "opened_text": now_text(nowv), "entry_price": price,
                "high_price": price, "low_price": price, "last_price": price,
            })
            open_map[event_id] = opened
    for event_id in list(open_map):
        event = open_map.get(event_id) if isinstance(open_map.get(event_id), dict) else {}
        ticker = str(event.get("ticker") or "")
        price = prices.get(ticker, _v1233_float(event.get("last_price"), default=0.0))
        if price <= 0:
            continue
        event["last_price"] = price
        event["high_price"] = max(_v1233_float(event.get("high_price"), default=price), price)
        event["low_price"] = min(_v1233_float(event.get("low_price"), default=price), price)
        invalid = _v1233_float(event.get("invalid_price"), default=0.0)
        target = _v1233_float(event.get("target_price"), default=0.0)
        if price <= invalid:
            _v1233_shadow_close(root, event_id, event, price, nowv, "INVALID")
        elif price >= target:
            _v1233_shadow_close(root, event_id, event, price, nowv, "TARGET")


def _v1233_build_summary(state: Dict[str, Any], nowv: float) -> Dict[str, Any]:
    missed_events = [e for e in ((state.get("missed") or {}).get("events") or {}).values() if isinstance(e, dict)]
    primary = [e for e in missed_events if e.get("reason") == "risk_reward_pair_shortage"]
    intermediate_only = [e for e in missed_events if e.get("reason") == "only_intermediate_resistance"]
    missed_top = sorted(missed_events, key=lambda e: _v1233_float(e.get("max_gain_pct"), default=-9999.0), reverse=True)[:5]
    missed_reason_counts: Dict[str, int] = {}
    for event in missed_events:
        reason = str(event.get("reason") or "unknown")
        missed_reason_counts[reason] = missed_reason_counts.get(reason, 0) + 1
    shadow = state.get("previous_structure_shadow") if isinstance(state.get("previous_structure_shadow"), dict) else {}
    closed = [r for r in shadow.get("closed", []) if isinstance(r, dict)]
    windows = {}
    for name, seconds in (("recent_3h",3*3600),("recent_6h",6*3600),("recent_12h",12*3600),("recent_24h",24*3600)):
        windows[name] = _v1233_metric([r for r in closed if _v1233_float(r.get("closed_ts"), default=0.0) >= nowv-seconds])
    reasons: Dict[str,int] = {}
    for row in closed:
        reason = str(row.get("exit_reason") or "UNKNOWN")
        reasons[reason] = reasons.get(reason, 0) + 1
    top_profit = sorted(closed, key=lambda r:_v1233_float(r.get("net_pnl_pct"), default=-9999.0), reverse=True)[:5]
    top_loss = sorted(closed, key=lambda r:_v1233_float(r.get("net_pnl_pct"), default=9999.0))[:5]
    return {
        "schema": V1233_SUMMARY_SCHEMA,
        "version": VERSION, "build": BUILD_LABEL,
        "generated_ts": nowv, "generated_text": now_text(nowv),
        "started_ts": state.get("started_ts"), "started_text": state.get("started_text"),
        "retention_sec": V1233_RETENTION_SEC, "auto_buy": False,
        "missed_current_structure": {
            "scope": "current structure exclusions tracked from first v1234 semantic occurrence; 6h path; 24h retention",
            "tracked_total": len(missed_events),
            "risk_reward_shortage_count": len(primary),
            "intermediate_only_count": len(intermediate_only),
            "reason_counts": missed_reason_counts,
            "completed_6h": sum(1 for e in missed_events if e.get("return_6h_pct") is not None),
            "completed_6h_risk_reward": sum(1 for e in primary if e.get("return_6h_pct") is not None),
            "completed_6h_intermediate": sum(1 for e in intermediate_only if e.get("return_6h_pct") is not None),
            "positive_max_count": sum(1 for e in missed_events if _v1233_float(e.get("max_gain_pct"), default=0.0) > 0),
            "gain_1_2_count": sum(1 for e in missed_events if _v1233_float(e.get("max_gain_pct"), default=0.0) >= 1.2),
            "gain_3_count": sum(1 for e in missed_events if _v1233_float(e.get("max_gain_pct"), default=0.0) >= 3.0),
            "top": missed_top,
        },
        "previous_structure_shadow": {
            "scope": "v1211 comparison-only virtual trades from v1233 start; unlimited simultaneous virtual OPEN; isolated from Paper",
            "pending_count": len(shadow.get("pending", {}) or {}),
            "open_count": len(shadow.get("open", {}) or {}),
            "closed_count": len(closed),
            "skipped_count": len(shadow.get("skipped", []) or []),
            "windows": windows, "exit_reasons": reasons,
            "fee_pct": V1233_SHADOW_FEE_PCT,
            "top_profit": top_profit, "top_loss": top_loss,
        },
        "invariants": {
            "live_paper_ledger_changed": False, "actual_open_limit_changed": False,
            "actual_entry_exit_changed": False, "shadow_open_limit": None,
            "actual_and_shadow_ledgers_separate": True, "core_ledger_retention_changed": False,
        },
    }



def _v1234_stat(rows: list[Dict[str, Any]]) -> Dict[str, Any]:
    values=[_v1233_float(r.get('net_pnl_pct'),r.get('pnl_pct'),default=0.0) for r in rows]
    wins=sum(1 for v in values if v>0); losses=sum(1 for v in values if v<0)
    def avg(key: str) -> Optional[float]:
        nums=[_v1233_float(r.get(key),default=0.0) for r in rows if r.get(key) not in (None,'')]
        return sum(nums)/len(nums) if nums else None
    return {
        'count':len(rows),'wins':wins,'losses':losses,'win_rate':wins/len(rows)*100.0 if rows else None,
        'total_pct':sum(values),'avg_pct':sum(values)/len(values) if values else None,
        'avg_mfe_pct':avg('mfe_pct'),'avg_mae_pct':avg('mae_pct'),'avg_giveback_pct':avg('giveback_pct'),'avg_hold_sec':avg('hold_sec'),
    }


def _v1234_quality_replay(row: Dict[str, Any]) -> Dict[str, Any]:
    def known(*keys: str) -> tuple[Optional[float], str]:
        for key in keys:
            if row.get(key) in (None,''):
                continue
            try:
                value=float(row.get(key))
                if value==value and abs(value)!=float('inf'):
                    return value,key
            except Exception:
                continue
        return None,'source_missing'
    reaction,reaction_src=known('price_reaction_pct')
    relative_rank,relative_rank_src=known('relative_strength_rank_pct')
    relative,relative_src=known('relative_strength')
    money,money_src=known('money_flow')
    buy,buy_src=known('buy_ratio')
    sustain,sustain_src=known('buy_sustain_1m')
    rr=_v1233_float(row.get('actual_entry_rr'),row.get('risk_reward'),default=0.0)
    room=_v1233_float(row.get('target_distance_pct'),row.get('target_room_pct'),default=0.0)
    spread=_v1233_float(row.get('spread_pct'),default=-1.0)
    slip=row.get('paper_reference_cost_pct')
    slip_n=None if slip in (None,'') else _v1233_float(slip,default=0.0)
    reaction_safe=reaction is not None and reaction>=-0.35
    reaction_strong=reaction is not None and reaction>=0.05
    relative_pass=(relative_rank is not None and relative_rank>=50.0) or (relative is not None and ((relative>=50.0) if abs(relative)>5.0 else (relative>=0.0)))
    money_pass=money is not None and money>=50.0
    buy_pass=buy is not None and sustain is not None and buy>=0.50 and sustain>=0.45
    known_axes=sum(1 for value in (reaction is not None, relative_rank is not None or relative is not None, money is not None, buy is not None and sustain is not None) if value)
    confirmations=sum(1 for value in (relative_pass,money_pass,buy_pass) if value)
    reasons=[]
    if known_axes<3: reasons.append('quality_source_missing')
    if reaction is None: reasons.append('quality_reaction_source_missing')
    elif not reaction_safe: reasons.append('quality_reaction_unsafe')
    if confirmations<1: reasons.append('quality_confirmation_absent')
    passed=bool(known_axes>=3 and reaction_safe and confirmations>=1)
    clip=lambda v,lo,hi:max(lo,min(hi,v))
    structure_score=15.0*clip((rr-1.5)/2.5,0.0,1.0)+15.0*clip((room-1.2)/2.8,0.0,1.0)
    reaction_score=20.0*clip(((reaction if reaction is not None else -0.35)+0.35)/1.35,0.0,1.0)
    rel_basis=relative_rank if relative_rank is not None else (relative if relative is not None and abs(relative)>5.0 else 50.0+clip(relative or 0.0,-2.0,2.0)*12.5)
    rel_score=20.0*clip(rel_basis/100.0,0.0,1.0)
    money_score=20.0*clip((money if money is not None else 40.0)/100.0,0.0,1.0)
    execution_base=((buy or 0.0)+(sustain or 0.0))/2.0 if buy is not None and sustain is not None else 0.40
    cost=max(0.0,spread if spread>=0 else 1.2)+max(0.0,slip_n if slip_n is not None else 1.2)
    execution_score=10.0*clip(execution_base-(cost/2.4)*0.35,0.0,1.0)
    return {
        'evaluable':known_axes>=3 and reaction is not None,'would_pass':passed,'known_axes':known_axes,'confirmations':confirmations,
        'reaction_safe':reaction_safe,'reaction_strong':reaction_strong,'reasons':reasons,
        'score':round(structure_score+reaction_score+rel_score+money_score+execution_score,4),
        'sources':{'reaction':reaction_src,'relative':relative_rank_src if relative_rank is not None else relative_src,'money':money_src,'buy':buy_src,'sustain':sustain_src},
    }


def _v1234_trigger_grace_minutes(row: Dict[str, Any]) -> float:
    trigger=row.get('trigger') if isinstance(row.get('trigger'),dict) else {}
    tf=str(trigger.get('tf') or trigger.get('timeframe') or 'm15').lower()
    return {'m1':1.0,'m3':3.0,'m5':5.0,'m15':15.0,'m30':30.0,'h1':60.0}.get(tf,15.0)


def _v1234_exit_diagnostic(row: Dict[str, Any]) -> Dict[str, Any]:
    hold_min=max(0.0,_v1233_float(row.get('hold_sec'),default=0.0)/60.0)
    grace=_v1234_trigger_grace_minutes(row)
    mfe=_v1233_float(row.get('mfe_pct'),default=0.0)
    net=_v1233_float(row.get('net_pnl_pct'),row.get('pnl_pct'),default=0.0)
    giveback=_v1233_float(row.get('giveback_pct'),default=max(0.0,mfe-net))
    fee=_v1233_float(row.get('configured_fee_pct'),default=0.10)
    spread=max(0.0,_v1233_float(row.get('spread_pct'),default=0.0))
    recovery=max(0.25,fee+spread*2.0)
    reason=str(row.get('exit_reason') or '')
    early=bool(reason=='swing_dynamic_momentum_decay' and hold_min<grace)
    profit_to_loss=bool(mfe>=recovery and net<=0.0)
    small_gap=bool(mfe>0.0 and mfe<1.0 and giveback>=max(0.20,mfe*0.55))
    delayed=bool(reason=='swing_dynamic_momentum_decay' and hold_min>=grace and profit_to_loss)
    return {'early_timeframe_conflict':early,'profit_to_loss_gap':profit_to_loss,'small_profit_giveback_gap':small_gap,'delayed_momentum_exit':delayed,'grace_min':grace,'recovery_trigger_pct':recovery}


def _v1234_hybrid_replay(base: Path, candidate_rows: list[Dict[str, Any]], nowv: float) -> Dict[str, Any]:
    perf=read_json(base/'canonical_performance_snapshot_v987.json',{}) or {}
    all_rows=[r for r in (perf.get('rows') or []) if isinstance(r,dict)]
    previous=[]; current=[]; unclassified=[]
    for row in all_rows:
        raw=str(row.get('structure_contract_version') or '').strip()
        if raw=='structure_contract_v1211_legacy': previous.append(row); continue
        match=re.search(r'structure_contract_v(\d+)',raw) if raw else None
        if match and int(match.group(1))>1211: current.append(row)
        else: unclassified.append(row)
    pass_rows=[]; block_rows=[]; missing_rows=[]; reason_counts={}; replay_rows=[]
    for row in current:
        decision=_v1234_quality_replay(row)
        replay_rows.append((row,decision))
        if not decision['evaluable']:
            missing_rows.append(row)
        elif decision['would_pass']:
            pass_rows.append(row)
        else:
            block_rows.append(row)
        for reason in decision['reasons']:
            reason_counts[reason]=reason_counts.get(reason,0)+1
    diagnostics=[(row,_v1234_exit_diagnostic(row)) for row in current]
    early=[row for row,d in diagnostics if d['early_timeframe_conflict']]
    profit_loss=[row for row,d in diagnostics if d['profit_to_loss_gap']]
    small_gap=[row for row,d in diagnostics if d['small_profit_giveback_gap']]
    delayed=[row for row,d in diagnostics if d['delayed_momentum_exit']]
    combined=[row for row,d in diagnostics if d['early_timeframe_conflict'] or d['profit_to_loss_gap']]
    candidate_pass=[r for r in candidate_rows if r.get('hybrid_entry_shadow_pass_v1234') is True]
    candidate_block=[r for r in candidate_rows if r.get('hybrid_entry_shadow_pass_v1234') is False]
    current_s1=[r for r in candidate_rows if str(r.get('s_stage') or r.get('candidate_stage') or '')=='S1' or r.get('open_eligible') is True]
    current_s1_block=[r for r in current_s1 if r.get('hybrid_entry_shadow_pass_v1234') is False]
    cand_reasons={}
    for row in candidate_block:
        for reason in str(row.get('hybrid_entry_shadow_reason_v1234') or '').split('|'):
            if reason and reason!='PASS': cand_reasons[reason]=cand_reasons.get(reason,0)+1
    examples=[]
    for row in current_s1_block[:8]:
        examples.append({'ticker':_v1233_ticker(row),'reason':row.get('hybrid_entry_shadow_reason_v1234'),'current_score':row.get('global_entry_score_v1212'),'hybrid_score':row.get('hybrid_entry_shadow_score_v1234')})
    return {
        'schema':'hybrid_surgery_replay_v1234','mode':'SHADOW_ONLY','performance_snapshot_id':perf.get('snapshot_id'),
        'source_rows':len(all_rows),'previous_actual':_v1234_stat(previous),'current_actual':_v1234_stat(current),'unclassified_rows':len(unclassified),
        'entry_replay':{
            'current_rows':len(current),'evaluable_rows':len(pass_rows)+len(block_rows),'source_missing_rows':len(missing_rows),
            'hybrid_would_pass':len(pass_rows),'hybrid_would_block':len(block_rows),'block_reason_counts':reason_counts,
            'actual_outcomes_if_hybrid_pass':_v1234_stat(pass_rows),'actual_outcomes_if_hybrid_block':_v1234_stat(block_rows),
            'interpretation':'actual historical outcomes split by sealed OPEN-time metrics; not counterfactual fills',
        },
        'exit_replay':{
            'current_rows':len(current),'early_timeframe_conflict':len(early),'profit_to_loss_gap':len(profit_loss),
            'small_profit_giveback_gap':len(small_gap),'delayed_momentum_exit':len(delayed),'combined_flagged':len(combined),
            'early_stats':_v1234_stat(early),'profit_to_loss_stats':_v1234_stat(profit_loss),'combined_stats':_v1234_stat(combined),
            'variants':['timeframe_grace_only','cost_recovery_floor_only','combined'],
            'interpretation':'eligibility and damage audit from exact CLOSED fields; no fabricated counterfactual exit price',
        },
        'current_generation':{
            'rows':len(candidate_rows),'hybrid_pass':len(candidate_pass),'hybrid_block':len(candidate_block),
            'current_s1':len(current_s1),'current_s1_hybrid_block':len(current_s1_block),
            'block_reason_counts':cand_reasons,'s1_block_examples':examples,
        },
        'contract':{
            'candidate_quality':'v1211 source/reaction/confirmation gate','structure_lines':'current coherent stop-target pairing',
            'exit_variants':'trigger-timeframe grace + cost recovery floor','hard_target_invalid_unchanged':True,
            'actual_entry_changed':False,'actual_exit_changed':False,'existing_open_changed':False,'auto_buy':False,
        },
    }



# -----------------------------------------------------------------------------
# v1236 - multi-state truth labels / conservative EV / semantic evidence
#
# Review remains the only owner. Live Strategy/Paper decisions are untouched.
# Target-vs-invalid is no longer forced to 100%: intermediate exits, ambiguous
# path evidence and unresolved events are first-class outcomes.
# -----------------------------------------------------------------------------

V1236_MODEL_SCHEMA="probability_policy_shadow_v1236"
V1236_MIN_SHARED_NUMERIC=4
V1236_MAX_NEIGHBORS=60
V1236_PRIOR_STRENGTH=12.0
V1236_STATES=("TARGET_FIRST","INVALID_FIRST","INTERMEDIATE_EXIT","AMBIGUOUS_BOTH","UNRESOLVED")


def _v1236_finite(value: Any) -> Optional[float]:
    try:
        out=float(value)
        if out==out and abs(out)!=float('inf'): return out
    except (TypeError,ValueError,OverflowError): pass
    return None


def _v1236_first_num(row: Dict[str, Any], *keys: str) -> Optional[float]:
    for key in keys:
        out=_v1236_finite(row.get(key))
        if out is not None: return out
    return None


def _v1236_line(row: Dict[str, Any], name: str) -> Dict[str, Any]:
    direct=row.get(name)
    if isinstance(direct,dict): return direct
    gate=row.get('swing_entry_gate_v977') if isinstance(row.get('swing_entry_gate_v977'),dict) else {}
    plan=gate.get('structure_plan') if isinstance(gate.get('structure_plan'),dict) else {}
    if not plan:
        for key in ('dynamic_structure_plan_v1212','swing_structure_plan_v977','structure_plan'):
            if isinstance(row.get(key),dict): plan=row[key]; break
    value=plan.get(name) if isinstance(plan,dict) else None
    return value if isinstance(value,dict) else {}


def _v1236_line_price(line: Dict[str, Any]) -> Optional[float]:
    for key in ('price','rounded_price','raw_price','value'):
        out=_v1236_finite(line.get(key))
        if out is not None and out>0: return out
    return None


def _v1236_tf(line: Dict[str, Any], default: str='unknown') -> str:
    return str(line.get('tf') or line.get('timeframe') or default).strip().lower()


def _v1236_tf_minutes(tf: str) -> float:
    return {'m1':1.0,'1m':1.0,'m3':3.0,'3m':3.0,'m5':5.0,'5m':5.0,'m15':15.0,'15m':15.0,
            'm30':30.0,'30m':30.0,'h1':60.0,'1h':60.0,'h2':120.0,'2h':120.0,'h4':240.0,'4h':240.0}.get(str(tf).lower(),15.0)


def _v1236_route_family(row: Dict[str, Any]) -> str:
    text=' '.join(str(row.get(k) or '') for k in ('entry_method','strategy','strategy_label','strategy_key','paper_strategy_key','source_lane')).lower()
    if 'hot-rank' in text or 'hot_rank' in text or '급등' in text: return 'hot_rank'
    if 'coverage' in text or '전체커버' in text: return 'coverage'
    if 's3_observe' in text or '관찰경로' in text: return 's3_observe'
    if '돌파' in text or 'breakout' in text or 'rebreak' in text: return 'breakout'
    if '주도' in text or 'leader' in text or '유동보유' in text: return 'leader_trend'
    if '돈흐름' in text or 'flow' in text or '재가속' in text: return 'money_flow'
    if 'vwap' in text or '저점' in text or '회복' in text: return 'vwap_recovery'
    return 'other'


def _v1236_market_family(row: Dict[str, Any]) -> str:
    text=str(row.get('market_mode_at_open') or row.get('market_mode') or row.get('market_regime') or row.get('market_state') or '').strip().lower()
    if not text:
        ctx=row.get('market_context') if isinstance(row.get('market_context'),dict) else {}
        text=str(ctx.get('market_regime') or ctx.get('regime') or ctx.get('market_state') or '').strip().lower()
    if any(x in text for x in ('bull','상승','risk_on','strong')): return 'bull'
    if any(x in text for x in ('bear','하락','risk_off','weak')): return 'bear'
    if any(x in text for x in ('side','range','횡보','neutral')): return 'sideways'
    return 'unknown'


def _v1236_features(row: Dict[str, Any], candidate: bool=False) -> Dict[str, Any]:
    gate=row.get('swing_entry_gate_v977') if isinstance(row.get('swing_entry_gate_v977'),dict) else {}
    trigger=_v1236_line(row,'trigger'); invalid=_v1236_line(row,'invalid'); target=_v1236_line(row,'target')
    entry=_v1236_first_num(row,'entry_price','actual_entry_price','current_price','live_price','price','last_price')
    if entry is None: entry=_v1236_line_price(trigger)
    target_distance=_v1236_first_num(row,'target_distance_pct','target_room_pct')
    invalid_distance=_v1236_first_num(row,'invalid_distance_pct','stop_distance_pct','invalid_distance_pct_v925')
    tp=_v1236_line_price(target); ip=_v1236_line_price(invalid)
    if entry and entry>0 and target_distance is None and tp and tp>entry: target_distance=(tp-entry)/entry*100.0
    if entry and entry>0 and invalid_distance is None and ip and ip<entry: invalid_distance=(entry-ip)/entry*100.0
    rr=_v1236_first_num(row,'actual_entry_rr','risk_reward','risk_reward_ratio')
    if rr is None: rr=_v1236_finite(gate.get('risk_reward'))
    reaction=_v1236_first_num(row,'price_reaction_pct','reaction_pct','change_1m_pct','change_1m')
    relative_rank=_v1236_first_num(row,'relative_strength_rank_pct','relative_strength_rank_pct_v1095')
    relative=_v1236_first_num(row,'relative_strength','relative_strength_pct')
    if relative_rank is None and relative is not None: relative_rank=relative if abs(relative)>5.0 else 50.0+max(-2.0,min(2.0,relative))*12.5
    money=_v1236_first_num(row,'money_flow','money_flow_score','money_expand_score','turnover_change_pct')
    buy=_v1236_first_num(row,'buy_ratio','buy_trade_ratio','micro_buy_ratio')
    sustain=_v1236_first_num(row,'buy_sustain_1m','buy_sustain_60s','micro_buy_ratio_sustain_1m')
    spread=_v1236_first_num(row,'spread_pct','micro_spread_pct','entry_spread_pct')
    if spread is None: spread=_v1236_finite(gate.get('spread_pct'))
    slip=_v1236_first_num(row,'paper_reference_cost_pct','paper_reference_slippage_pct','confirmed_slippage_pct')
    if slip is None: slip=_v1236_finite(gate.get('confirmed_slippage_pct'))
    fee=_v1236_first_num(row,'configured_fee_pct','configured_roundtrip_fee_pct_v983')
    if fee is None: fee=0.10
    cost=max(0.0,spread or 0.0)+max(0.0,slip or 0.0)+max(0.0,fee or 0.0)
    numeric={'reaction':reaction,'relative_rank':relative_rank,'money_flow':money,'buy_ratio':buy,'buy_sustain':sustain,
             'rr':rr,'target_distance':target_distance,'invalid_distance':invalid_distance,'spread':spread,'cost':cost}
    return {'ticker':_v1233_ticker(row),'route':_v1236_route_family(row),'market':_v1236_market_family(row),
            'trigger_tf':_v1236_tf(trigger),'invalid_tf':_v1236_tf(invalid),'target_tf':_v1236_tf(target),
            'numeric':numeric,'known_numeric':sum(1 for v in numeric.values() if v is not None),'candidate':candidate}


_V1236_SCALES={'reaction':0.80,'relative_rank':30.0,'money_flow':25.0,'buy_ratio':0.25,'buy_sustain':0.25,
               'rr':1.20,'target_distance':4.0,'invalid_distance':3.0,'spread':0.50,'cost':0.60}
_V1236_WEIGHTS={'reaction':1.25,'relative_rank':1.15,'money_flow':1.15,'buy_ratio':1.0,'buy_sustain':1.0,
                'rr':0.75,'target_distance':0.85,'invalid_distance':0.75,'spread':0.8,'cost':0.9}


def _v1236_similarity(a: Dict[str, Any], b: Dict[str, Any]) -> tuple[float,int,float]:
    av=a.get('numeric') or {}; bv=b.get('numeric') or {}; total=weight=0.0; shared=0
    for key,scale in _V1236_SCALES.items():
        x=av.get(key); y=bv.get(key)
        if x is None or y is None: continue
        w=_V1236_WEIGHTS[key]; shared+=1; weight+=w; total+=w*min(3.0,abs(float(x)-float(y))/scale)
    if shared<V1236_MIN_SHARED_NUMERIC or weight<=0: return 0.0,shared,0.0
    penalty=0.0
    if a.get('route')!='other' and b.get('route')!='other' and a.get('route')!=b.get('route'): penalty+=0.75
    if a.get('market')!='unknown' and b.get('market')!='unknown' and a.get('market')!=b.get('market'): penalty+=0.35
    penalty+=min(0.35,abs(math.log(max(_v1236_tf_minutes(str(a.get('trigger_tf'))),1.0)/max(_v1236_tf_minutes(str(b.get('trigger_tf'))),1.0)))*0.18)
    return 1.0/(1.0+total/weight+penalty),shared,shared/float(len(_V1236_SCALES))


def _v1236_outcome(row: Dict[str, Any], feature: Optional[Dict[str, Any]]=None) -> Dict[str, Any]:
    feature=feature or _v1236_features(row,False); numeric=feature.get('numeric') or {}
    pnl=_v1233_float(row.get('net_pnl_pct'),row.get('pnl_pct'),default=0.0)
    mfe=_v1233_float(row.get('mfe_pct'),row.get('peak_pct'),default=0.0)
    mae=_v1233_float(row.get('mae_pct'),row.get('trough_pct'),default=0.0)
    giveback=_v1233_float(row.get('giveback_pct'),default=max(0.0,mfe-pnl))
    cost=max(0.0,_v1233_float(row.get('configured_fee_pct'),default=0.10))+max(0.0,_v1233_float(row.get('spread_pct'),default=0.0))+max(0.0,_v1233_float(row.get('paper_reference_cost_pct'),default=0.0))
    opened=_v1236_first_num(row,'opened_at','open_ts','entry_ts'); closed=_v1236_first_num(row,'closed_at','close_ts','exit_ts')
    target_ts=_v1236_first_num(row,'target_first_touch_ts'); invalid_ts=_v1236_first_num(row,'invalid_first_touch_ts')
    reason=str(row.get('exit_reason') or row.get('reason') or '')
    target_reason=reason=='structure_target'; invalid_reason=reason=='structure_invalid'
    target_dist=_v1236_finite(numeric.get('target_distance')); invalid_dist=_v1236_finite(numeric.get('invalid_distance'))
    tol=0.03
    target_path=bool(target_dist is not None and target_dist>0 and mfe>=target_dist-tol)
    invalid_path=bool(invalid_dist is not None and invalid_dist>0 and mae<=-(invalid_dist-tol))
    target_exact=target_ts is not None or target_reason; invalid_exact=invalid_ts is not None or invalid_reason
    if target_reason and target_ts is None: target_ts=closed
    if invalid_reason and invalid_ts is None: invalid_ts=closed
    target_delay=(target_ts-opened) if target_ts is not None and opened is not None and target_ts>=opened else None
    invalid_delay=(invalid_ts-opened) if invalid_ts is not None and opened is not None and invalid_ts>=opened else None
    if target_exact and invalid_exact and target_ts is not None and invalid_ts is not None:
        state='TARGET_FIRST' if target_ts<=invalid_ts else 'INVALID_FIRST'; evidence='EXACT_TOUCH_TIME'
    elif target_exact and not invalid_exact: state='TARGET_FIRST'; evidence='EXACT_REASON_OR_TIME'
    elif invalid_exact and not target_exact: state='INVALID_FIRST'; evidence='EXACT_REASON_OR_TIME'
    elif target_path and invalid_path: state='AMBIGUOUS_BOTH'; evidence='MFE_MAE_INFERRED_NO_ORDER'
    elif target_path: state='TARGET_FIRST'; evidence='MFE_INFERRED'
    elif invalid_path: state='INVALID_FIRST'; evidence='MAE_INFERRED'
    elif closed is not None or reason: state='INTERMEDIATE_EXIT'; evidence='CLOSED_WITHOUT_LINE_TOUCH'
    else: state='UNRESOLVED'; evidence='OPEN_OR_INCOMPLETE'
    hold_sec=_v1233_float(row.get('hold_sec'),default=max(0.0,(closed-opened) if closed is not None and opened is not None else 0.0))
    recovery=max(0.25,cost)
    return {'pnl':pnl,'win':pnl>0.0,'loss':pnl<0.0,'mfe':mfe,'mae':mae,'giveback':giveback,'cost':cost,
            'outcome_state':state,'evidence':evidence,'target_delay':target_delay,'invalid_delay':invalid_delay,
            'target_timing_exact':target_delay is not None,'invalid_timing_exact':invalid_delay is not None,
            'giveback_risk':bool(mfe>=recovery and (pnl<=0.0 or giveback>=max(0.25,mfe*0.55))),
            'tail_loss':bool(pnl<=-1.50),'hold_sec':hold_sec,'closed':closed is not None or bool(reason)}


def _v1236_prepare(rows: list[Dict[str, Any]]) -> list[Dict[str, Any]]:
    out=[]
    for row in rows:
        feature=_v1236_features(row,False); out.append({'row':row,'feature':feature,'outcome':_v1236_outcome(row,feature)})
    return out


def _v1236_weighted_mean(items: list[tuple[float,float]], default: float=0.0) -> float:
    sw=sum(w for _,w in items if w>0)
    return sum(v*w for v,w in items if w>0)/sw if sw>0 else default


def _v1236_prior(prepared: list[Dict[str, Any]]) -> Dict[str, Any]:
    outs=[x['outcome'] for x in prepared]
    if not outs:
        states={k:0.0 for k in V1236_STATES}; states['INTERMEDIATE_EXIT']=1.0
        return {'p_win':0.5,'states':states,'p_giveback':0.35,'p_tail':0.15,'avg_win':0.8,'avg_loss':0.8,'mean':0.0,'std':1.0,'avg_cost':0.10}
    pnl=[o['pnl'] for o in outs]; wins=[v for v in pnl if v>0]; losses=[-v for v in pnl if v<0]
    states={k:sum(1 for o in outs if o['outcome_state']==k)/len(outs) for k in V1236_STATES}
    return {'p_win':sum(1 for o in outs if o['win'])/len(outs),'states':states,
            'p_giveback':sum(1 for o in outs if o['giveback_risk'])/len(outs),'p_tail':sum(1 for o in outs if o['tail_loss'])/len(outs),
            'avg_win':sum(wins)/len(wins) if wins else 0.8,'avg_loss':sum(losses)/len(losses) if losses else 0.8,
            'mean':sum(pnl)/len(pnl),'std':statistics.pstdev(pnl) if len(pnl)>1 else 1.0,'avg_cost':sum(o['cost'] for o in outs)/len(outs)}


def _v1236_probability(success_weight: float,total_weight: float,prior: float,strength: float=V1236_PRIOR_STRENGTH) -> float:
    return (success_weight+prior*strength)/(total_weight+strength) if total_weight+strength>0 else prior


def _v1236_profile(feature: Dict[str, Any], p_giveback: float, p_tail: float, candidate_cost: float) -> tuple[str,Dict[str,Any]]:
    route=str(feature.get('route') or 'other'); n=feature.get('numeric') or {}; trigger_minutes=_v1236_tf_minutes(str(feature.get('trigger_tf') or 'm15')); target_minutes=_v1236_tf_minutes(str(feature.get('target_tf') or 'h2'))
    target_dist=float(n.get('target_distance') or 0.0); invalid_dist=float(n.get('invalid_distance') or 0.0)
    if p_giveback>=0.50: profile='giveback_guard'
    elif route in {'hot_rank','breakout'} and trigger_minutes<=15: profile='fast_breakout'
    elif target_minutes>=120 or target_dist>=5.0: profile='slow_trend'
    elif invalid_dist>=3.5 or float(n.get('spread') or 0.0)>=0.35 or p_tail>=0.28: profile='volatile_structure'
    else: profile='balanced'
    if profile=='fast_breakout': grace=max(3.0,trigger_minutes); no_progress=max(6.0,trigger_minutes*2.0); arm=max(candidate_cost+0.20,0.40); floor=max(0.02,candidate_cost*0.15)
    elif profile=='slow_trend': grace=max(15.0,trigger_minutes); no_progress=max(45.0,trigger_minutes*3.0); arm=max(candidate_cost+0.45,0.80); floor=max(0.05,candidate_cost*0.25)
    elif profile=='giveback_guard': grace=max(5.0,trigger_minutes); no_progress=max(20.0,trigger_minutes*2.0); arm=max(candidate_cost+0.15,0.35); floor=max(0.03,candidate_cost*0.15)
    elif profile=='volatile_structure': grace=max(10.0,trigger_minutes); no_progress=max(30.0,trigger_minutes*2.5); arm=max(candidate_cost+0.35,0.70); floor=max(0.03,candidate_cost*0.20)
    else: grace=max(5.0,trigger_minutes); no_progress=max(20.0,trigger_minutes*2.0); arm=max(candidate_cost+0.25,0.55); floor=max(0.03,candidate_cost*0.20)
    return profile,{'observation_grace_min':round(grace,2),'no_progress_review_min':round(no_progress,2),'profit_protect_arm_pct':round(arm,3),'profit_floor_pct':round(floor,3),'target_invalid_immediate':True,'mode':'SHADOW_ONLY'}


def _v1236_horizon(outcome: Dict[str, Any], sec: float) -> str:
    td=outcome.get('target_delay'); idd=outcome.get('invalid_delay')
    if td is not None and td<=sec and (idd is None or td<=idd): return 'TARGET_FIRST'
    if idd is not None and idd<=sec and (td is None or idd<td): return 'INVALID_FIRST'
    state=outcome.get('outcome_state'); hold=float(outcome.get('hold_sec') or 0.0)
    if state=='INTERMEDIATE_EXIT' and hold<=sec: return 'INTERMEDIATE_EXIT'
    if state=='INTERMEDIATE_EXIT' or (td is not None and td>sec) or (idd is not None and idd>sec): return 'NO_TOUCH_BY_HORIZON'
    return 'UNKNOWN_TIMING'


def _v1236_estimate(candidate: Dict[str, Any], prepared: list[Dict[str, Any]], nowv: Optional[float]=None) -> Dict[str, Any]:
    nowv=nowv or now_ts(); cf=_v1236_features(candidate,True); prior=_v1236_prior(prepared); pool=[]
    for item in prepared:
        sim,shared,coverage=_v1236_similarity(cf,item['feature'])
        if sim<=0: continue
        row=item['row']; closed=_v1236_first_num(row,'closed_at','close_ts') or nowv; age_days=max(0.0,(nowv-closed)/86400.0)
        recency=0.65+0.35*math.exp(-age_days/14.0); route_bonus=1.15 if cf.get('route')==item['feature'].get('route') and cf.get('route')!='other' else 1.0
        pool.append((sim*recency*route_bonus,sim,coverage,item['outcome']))
    pool.sort(key=lambda x:x[0],reverse=True); pool=pool[:V1236_MAX_NEIGHBORS]
    candidate_cost=float((cf.get('numeric') or {}).get('cost') or 0.10)
    if not pool:
        profile,policy=_v1236_profile(cf,prior['p_giveback'],prior['p_tail'],candidate_cost)
        states=prior['states']; conservative=prior['mean']-0.75*prior['std']
        return {'schema':V1236_MODEL_SCHEMA,'state':'LOW','neighbors':0,'effective_n':0.0,'coverage':0.0,'confidence':0.0,
                'p_win':prior['p_win'],'outcome_probs':states,'p_target_first':states['TARGET_FIRST'],'p_invalid_first':states['INVALID_FIRST'],
                'p_intermediate_exit':states['INTERMEDIATE_EXIT'],'p_ambiguous':states['AMBIGUOUS_BOTH'],'p_unresolved':states['UNRESOLVED'],
                'p_giveback':prior['p_giveback'],'p_tail_loss':prior['p_tail'],'expected_net_pct':prior['mean'],'conservative_ev_pct':conservative,
                'uncertainty_penalty_pct':0.75*prior['std'],'profile':profile,'exit_policy':policy,'candidate_cost_pct':candidate_cost,'horizons':{},
                'feature_known':cf.get('known_numeric'),'route':cf.get('route'),'market':cf.get('market')}
    sw=sum(x[0] for x in pool); sw2=sum(x[0]**2 for x in pool); neff=sw*sw/sw2 if sw2>0 else 0.0
    coverage=_v1236_weighted_mean([(x[2],x[0]) for x in pool],0.0); pnl_items=[(x[3]['pnl'],x[0]) for x in pool]; mean_net=_v1236_weighted_mean(pnl_items,prior['mean'])
    std=math.sqrt(max(0.0,_v1236_weighted_mean([((v-mean_net)**2,w) for v,w in pnl_items],prior['std']**2)))
    p_win=_v1236_probability(sum(x[0] for x in pool if x[3]['win']),sw,prior['p_win']); p_loss=_v1236_probability(sum(x[0] for x in pool if x[3]['loss']),sw,1.0-prior['p_win'])
    state_probs={state:_v1236_probability(sum(x[0] for x in pool if x[3]['outcome_state']==state),sw,prior['states'].get(state,0.0)) for state in V1236_STATES}
    total_state=sum(state_probs.values()) or 1.0; state_probs={k:v/total_state for k,v in state_probs.items()}
    p_give=_v1236_probability(sum(x[0] for x in pool if x[3]['giveback_risk']),sw,prior['p_giveback']); p_tail=_v1236_probability(sum(x[0] for x in pool if x[3]['tail_loss']),sw,prior['p_tail'])
    avg_win=_v1236_weighted_mean([(x[3]['pnl'],x[0]) for x in pool if x[3]['pnl']>0],prior['avg_win']); avg_loss=_v1236_weighted_mean([(-x[3]['pnl'],x[0]) for x in pool if x[3]['pnl']<0],prior['avg_loss'])
    hist_cost=_v1236_weighted_mean([(x[3]['cost'],x[0]) for x in pool],prior['avg_cost']); cost_delta=candidate_cost-hist_cost
    probability_ev=p_win*avg_win-p_loss*avg_loss-cost_delta; blended=0.55*probability_ev+0.45*(mean_net-cost_delta)
    standard_error=std/math.sqrt(max(1.0,neff)); unknown_mass=state_probs['AMBIGUOUS_BOTH']+state_probs['UNRESOLVED']
    uncertainty=0.70*standard_error+max(0.0,0.72-coverage)*0.55+0.30/math.sqrt(max(1.0,neff))+0.20*unknown_mass
    risk_penalty=0.22*p_tail*avg_loss+0.10*p_give+0.08*state_probs['INVALID_FIRST']*avg_loss
    conservative=blended-uncertainty-risk_penalty
    confidence=max(0.0,min(100.0,100.0*(0.50*min(1.0,neff/30.0)+0.35*coverage+0.15*_v1236_weighted_mean([(x[1],x[0]) for x in pool],0.0))*(1.0-0.35*unknown_mass)))
    state='HIGH' if neff>=30 and coverage>=0.80 and unknown_mass<0.25 else ('MEDIUM' if neff>=15 and coverage>=0.65 else 'LOW')
    horizons={}
    for hours in (3,6,12):
        sec=hours*3600.0; counts={k:0.0 for k in ('TARGET_FIRST','INVALID_FIRST','INTERMEDIATE_EXIT','NO_TOUCH_BY_HORIZON','UNKNOWN_TIMING')}
        for w,_,_,outcome in pool: counts[_v1236_horizon(outcome,sec)]+=w
        known=sw-counts['UNKNOWN_TIMING']; probs={k:(counts[k]/known if known>0 else None) for k in ('TARGET_FIRST','INVALID_FIRST','INTERMEDIATE_EXIT','NO_TOUCH_BY_HORIZON')}
        horizons[f'{hours}h']={'state_probs_known':probs,'known_evidence_weight':round(known,4),'unknown_timing_weight':round(counts['UNKNOWN_TIMING'],4),'unknown_timing_ratio':round(counts['UNKNOWN_TIMING']/sw,6) if sw>0 else None}
    profile,policy=_v1236_profile(cf,p_give,p_tail,candidate_cost)
    return {'schema':V1236_MODEL_SCHEMA,'state':state,'neighbors':len(pool),'effective_n':round(neff,4),'coverage':round(coverage,4),'confidence':round(confidence,2),
            'p_win':round(p_win,6),'outcome_probs':{k:round(v,6) for k,v in state_probs.items()},'p_target_first':round(state_probs['TARGET_FIRST'],6),
            'p_invalid_first':round(state_probs['INVALID_FIRST'],6),'p_intermediate_exit':round(state_probs['INTERMEDIATE_EXIT'],6),
            'p_ambiguous':round(state_probs['AMBIGUOUS_BOTH'],6),'p_unresolved':round(state_probs['UNRESOLVED'],6),
            'p_giveback':round(p_give,6),'p_tail_loss':round(p_tail,6),'avg_win_pct':round(avg_win,6),'avg_loss_pct':round(avg_loss,6),
            'expected_net_pct':round(blended,6),'conservative_ev_pct':round(conservative,6),'uncertainty_penalty_pct':round(uncertainty+risk_penalty,6),
            'candidate_cost_pct':round(candidate_cost,6),'historical_neighbor_cost_pct':round(hist_cost,6),'profile':profile,'exit_policy':policy,
            'horizons':horizons,'feature_known':cf.get('known_numeric'),'route':cf.get('route'),'market':cf.get('market')}


def _v1236_score_bucket(rows: list[Dict[str, Any]], score_key: str) -> Dict[str, Any]:
    valid=[r for r in rows if _v1236_finite(r.get(score_key)) is not None]; valid.sort(key=lambda r:float(r[score_key]),reverse=True)
    if not valid: return {'evaluable':0,'top_count':0,'top':_v1234_stat([]),'bottom':_v1234_stat([])}
    n=max(1,len(valid)//3); return {'evaluable':len(valid),'top_count':n,'top':_v1234_stat([r['row'] for r in valid[:n]]),'bottom':_v1234_stat([r['row'] for r in valid[-n:]])}


def _v1236_walk_forward(prepared: list[Dict[str, Any]]) -> Dict[str, Any]:
    ordered=sorted(prepared,key=lambda x:_v1236_first_num(x['row'],'closed_at','opened_at') or 0.0); predictions=[]
    for idx,item in enumerate(ordered):
        train=ordered[:idx]
        if len(train)<12: continue
        model=_v1236_estimate(item['row'],train,nowv=_v1236_first_num(item['row'],'closed_at') or now_ts()); quality=_v1234_quality_replay(item['row']); current=_v1236_first_num(item['row'],'global_entry_score_v1212')
        predictions.append({'row':item['row'],'current_score':current,'quality_score':quality.get('score'),'ev_score':model.get('conservative_ev_pct'),'model_state':model.get('state')})
    return {'schema':'policy_walk_forward_v1236','prediction_rows':len(predictions),'minimum_train_rows':12,
            'current_score':_v1236_score_bucket(predictions,'current_score'),'v1211_quality_score':_v1236_score_bucket(predictions,'quality_score'),
            'conservative_ev_score':_v1236_score_bucket(predictions,'ev_score'),'policy_note':'walk-forward; each row uses only earlier CLOSED evidence'}


def _v1236_probability_policy(base: Path, candidate_rows: list[Dict[str, Any]], nowv: float) -> Dict[str, Any]:
    perf=read_json(base/'canonical_performance_snapshot_v987.json',{}) or {}; all_rows=[r for r in (perf.get('rows') or []) if isinstance(r,dict)]; current=[]
    for row in all_rows:
        raw=str(row.get('structure_contract_version') or '').strip(); match=re.search(r'structure_contract_v(\d+)',raw) if raw else None
        if match and int(match.group(1))>1211: current.append(row)
    prepared=_v1236_prepare(current); ranked=[]
    for row in candidate_rows:
        model=_v1236_estimate(row,prepared,nowv); quality=_v1234_quality_replay(row)
        ranked.append({'ticker':_v1233_ticker(row),'route':model.get('route'),'market':model.get('market'),'current_stage':str(row.get('s_stage') or row.get('candidate_stage') or ''),
                       'current_score':_v1236_first_num(row,'global_entry_score_v1212','rank_score','score'),'v1211_quality_score':quality.get('score'),
                       'conservative_ev_pct':model.get('conservative_ev_pct'),'expected_net_pct':model.get('expected_net_pct'),'p_win':model.get('p_win'),
                       'p_target_first':model.get('p_target_first'),'p_invalid_first':model.get('p_invalid_first'),'p_intermediate_exit':model.get('p_intermediate_exit'),
                       'p_ambiguous':model.get('p_ambiguous'),'p_unresolved':model.get('p_unresolved'),'p_giveback':model.get('p_giveback'),'p_tail_loss':model.get('p_tail_loss'),
                       'confidence':model.get('confidence'),'state':model.get('state'),'neighbors':model.get('neighbors'),'effective_n':model.get('effective_n'),
                       'coverage':model.get('coverage'),'profile':model.get('profile'),'exit_policy':model.get('exit_policy'),'horizons':model.get('horizons')})
    key=lambda r:(_v1236_finite(r.get('conservative_ev_pct')) if _v1236_finite(r.get('conservative_ev_pct')) is not None else -999.0,_v1236_finite(r.get('confidence')) or 0.0)
    ranked_ev=sorted(ranked,key=key,reverse=True); ranked_current=sorted(ranked,key=lambda r:_v1236_finite(r.get('current_score')) if _v1236_finite(r.get('current_score')) is not None else -999.0,reverse=True); ranked_quality=sorted(ranked,key=lambda r:_v1236_finite(r.get('v1211_quality_score')) if _v1236_finite(r.get('v1211_quality_score')) is not None else -999.0,reverse=True)
    topn=min(20,len(ranked)); ev_t={r['ticker'] for r in ranked_ev[:topn]}; cur_t={r['ticker'] for r in ranked_current[:topn]}; qua_t={r['ticker'] for r in ranked_quality[:topn]}
    states={}; profiles={}
    for r in ranked: states[str(r.get('state') or 'UNKNOWN')]=states.get(str(r.get('state') or 'UNKNOWN'),0)+1; profiles[str(r.get('profile') or 'unknown')]=profiles.get(str(r.get('profile') or 'unknown'),0)+1
    truth_counts={k:0 for k in V1236_STATES}; evidence_counts={}
    for item in prepared:
        o=item['outcome']; truth_counts[o['outcome_state']]=truth_counts.get(o['outcome_state'],0)+1; evidence_counts[o['evidence']]=evidence_counts.get(o['evidence'],0)+1
    return {'schema':V1236_MODEL_SCHEMA,'mode':'SHADOW_ONLY','performance_snapshot_id':perf.get('snapshot_id'),'generated_at':nowv,'history_rows':len(current),
            'truth_label_counts':truth_counts,'truth_evidence_counts':evidence_counts,'candidate_rows':len(ranked),
            'positive_conservative_ev':sum(1 for r in ranked if (_v1236_finite(r.get('conservative_ev_pct')) or -999)>0),'evidence_states':states,'profile_counts':profiles,
            'current_candidates':{'top_ev':ranked_ev[:20],'top_current':ranked_current[:20],'top_v1211_quality':ranked_quality[:20],
                                  'top20_overlap':{'ev_current':len(ev_t&cur_t),'ev_v1211':len(ev_t&qua_t),'current_v1211':len(cur_t&qua_t)}},
            'walk_forward':_v1236_walk_forward(prepared),'invariants':{'actual_candidate_stage_changed':False,'actual_rank_changed':False,'paper_intake_changed':False,'actual_exit_changed':False,'existing_open_changed':False,'core_ledgers_changed':False,'auto_buy':False},
            'limitations':['historical executed trades only','horizon probabilities expose unknown timing instead of treating unknown as loss','no fabricated fills or exit prices']}


def _v1234_shadow_signature(event: Dict[str, Any]) -> str:
    return '|'.join((str(event.get('ticker') or ''),f"{_v1233_float(event.get('trigger_price'),default=0.0):.12g}",f"{_v1233_float(event.get('invalid_price'),default=0.0):.12g}",f"{_v1233_float(event.get('target_price'),default=0.0):.12g}"))


def _v1236_shadow_signature_event(event: Dict[str, Any]) -> str:
    ticker=str(event.get('ticker') or '').upper(); trigger=_v1236_sig_price(_v1233_float(event.get('trigger_price'),default=0.0)); invalid=_v1236_sig_price(_v1233_float(event.get('invalid_price'),default=0.0)); target=_v1236_sig_price(_v1233_float(event.get('target_price'),default=0.0))
    return f"{ticker}|{trigger}|{invalid}|{target}"


def _v1236_compact_state(state: Dict[str, Any], nowv: float) -> Dict[str, int]:
    stats={'missed_before':0,'missed_after':0,'shadow_before':0,'shadow_after':0,'removed':0}
    missed=state.setdefault('missed',{}).setdefault('events',{}); stats['missed_before']=len(missed)
    merged={}
    for event in missed.values():
        if not isinstance(event,dict): continue
        # Old v1235 rows did not preserve lines; collapse their cycle copies by ticker/reason.
        line_sig='|'.join(_v1236_sig_price(_v1233_float(event.get(k),default=0.0)) for k in ('trigger_price','invalid_price','target_price','intermediate_price'))
        base=f"{str(event.get('ticker') or '').upper()}|{event.get('reason') or ''}|{line_sig if line_sig.replace('|','').replace('0','') else 'legacy'}"
        key=hashlib.sha256(base.encode()).hexdigest()[:24]; old=merged.get(key)
        if old is None: old=dict(event); old['event_id']=key; old['semantic_event_id']=key; merged[key]=old
        else:
            old['created_ts']=min(_v1233_float(old.get('created_ts'),default=nowv),_v1233_float(event.get('created_ts'),default=nowv))
            old['high_price']=max(_v1233_float(old.get('high_price'),default=0.0),_v1233_float(event.get('high_price'),default=0.0))
            lows=[x for x in (_v1233_float(old.get('low_price'),default=0.0),_v1233_float(event.get('low_price'),default=0.0)) if x>0]; old['low_price']=min(lows) if lows else 0.0
            if _v1233_float(event.get('last_seen_ts'),default=0.0)>=_v1233_float(old.get('last_seen_ts'),default=0.0):
                for k in ('last_seen_ts','current_price','current_return_pct','age_sec'): old[k]=event.get(k)
    state['missed']['events']=merged; stats['missed_after']=len(merged)
    shadow=state.setdefault('previous_structure_shadow',{}); all_before=sum(len(shadow.get(k) or {}) if isinstance(shadow.get(k),dict) else len(shadow.get(k) or []) for k in ('pending','open','closed','skipped')); stats['shadow_before']=all_before
    closed_map={}
    for event in shadow.get('closed',[]) if isinstance(shadow.get('closed'),list) else []:
        if not isinstance(event,dict): continue
        sig=_v1236_shadow_signature_event(event)+'|'+str(event.get('exit_reason') or ''); key=hashlib.sha256(sig.encode()).hexdigest()[:24]
        if key not in closed_map or _v1233_float(event.get('closed_ts'),default=0.0)<_v1233_float(closed_map[key].get('closed_ts'),default=1e30):
            clone=dict(event); clone['event_id']=key; clone['semantic_event_id']=key; closed_map[key]=clone
    skipped_map={}
    for event in shadow.get('skipped',[]) if isinstance(shadow.get('skipped'),list) else []:
        if not isinstance(event,dict): continue
        sig=_v1236_shadow_signature_event(event)+'|'+str(event.get('reason') or ''); key=hashlib.sha256(sig.encode()).hexdigest()[:24]
        if key not in skipped_map: clone=dict(event); clone['event_id']=key; clone['semantic_event_id']=key; skipped_map[key]=clone
    terminal={_v1236_shadow_signature_event(x) for x in closed_map.values()}|{_v1236_shadow_signature_event(x) for x in skipped_map.values()}
    for bucket in ('open','pending'):
        result={}
        source=shadow.get(bucket) if isinstance(shadow.get(bucket),dict) else {}
        for event in source.values():
            if not isinstance(event,dict): continue
            sig=_v1236_shadow_signature_event(event)
            if sig in terminal: continue
            key=hashlib.sha256(sig.encode()).hexdigest()[:24]
            old=result.get(key)
            if old is None: clone=dict(event); clone['event_id']=key; clone['semantic_event_id']=key; result[key]=clone
            else:
                old['high_price']=max(_v1233_float(old.get('high_price'),default=0.0),_v1233_float(event.get('high_price'),default=0.0)); lows=[x for x in (_v1233_float(old.get('low_price'),default=0.0),_v1233_float(event.get('low_price'),default=0.0)) if x>0]; old['low_price']=min(lows) if lows else 0.0
        shadow[bucket]=result
    shadow['closed']=list(closed_map.values()); shadow['skipped']=list(skipped_map.values())
    stats['shadow_after']=sum(len(shadow.get(k) or {}) if isinstance(shadow.get(k),dict) else len(shadow.get(k) or []) for k in ('pending','open','closed','skipped'))
    stats['removed']=(stats['missed_before']-stats['missed_after'])+(stats['shadow_before']-stats['shadow_after'])
    state['semantic_compaction_v1236']={**stats,'ts':nowv}
    return stats


def _v1236_load_state(base: Path, nowv: float) -> Dict[str, Any]:
    current=read_json(version_score_state_path(base),{}) or {}
    if isinstance(current,dict) and current.get('schema')==V1233_STATE_SCHEMA:
        _v1236_compact_state(current,nowv); return current
    prior=read_json(base/'version_score_review_state_v1235.json',{}) or {}
    if isinstance(prior,dict) and prior:
        state=dict(prior); state['schema']=V1233_STATE_SCHEMA; state['migration_v1236_from_v1235']={'performed':True,'source':'version_score_review_state_v1235.json','ts':nowv}; _v1236_compact_state(state,nowv); return state
    state=_v1233_empty_state(nowv); _v1236_compact_state(state,nowv); return state

def update_version_score_review(base: Path, rows: Optional[list[Dict[str, Any]]] = None) -> Dict[str, Any]:
    nowv = now_ts()
    state = _v1236_load_state(base, nowv)
    candidate_rows = rows if isinstance(rows, list) else read_candidate_rows(SpinePaths(base).strategy_candidates, 5000)
    prices = {_v1233_ticker(row): _v1233_price(row) for row in candidate_rows if _v1233_ticker(row) and _v1233_price(row)>0}
    _v1233_update_missed(state, candidate_rows, prices, nowv)
    _v1233_update_shadow(state, candidate_rows, prices, nowv)
    state["updated_ts"] = nowv; state["updated_text"] = now_text(nowv)
    state["candidate_rows"] = len(candidate_rows)
    state["retention_policy"] = "only v1236 read-only review/shadow state is pruned after 24h; core ledgers untouched"
    summary = _v1233_build_summary(state, nowv)
    summary['hybrid_surgery_v1234'] = _v1234_hybrid_replay(base, candidate_rows, nowv)
    summary['probability_policy_v1236'] = _v1236_probability_policy(base, candidate_rows, nowv)
    summary['semantic_occurrence_dedupe_v1236'] = True
    summary['semantic_compaction_v1236'] = state.get('semantic_compaction_v1236') or {}
    summary['migration_v1234'] = state.get('migration_v1234') or {}
    summary['migration_v1236_from_v1235'] = state.get('migration_v1236_from_v1235') or {}
    atomic_write_json(version_score_state_path(base), state)
    atomic_write_json(version_score_summary_path(base), summary)
    return summary


def base_dir() -> Path:
    override = os.getenv("COINBOT_BASE_DIR", "").strip()
    return Path(override).expanduser().resolve() if override else Path(__file__).resolve().parent


def status_path(base: Path) -> Path:
    return base / "clean_review_worker_status.json"


def error_path(base: Path) -> Path:
    return base / "clean_review_worker_error.log"


def pid_path(base: Path) -> Path:
    return base / "review_worker.pid"


def lock_path(base: Path) -> Path:
    return base / "runtime" / "review_worker_singleton_v1121.lock"


def log_error(base: Path, where: str, exc: BaseException) -> None:
    path = error_path(base)
    path.parent.mkdir(parents=True, exist_ok=True)
    message = (
        f"[{now_text()}] {where}: {type(exc).__name__}: {exc}\n"
        f"{traceback.format_exc()[-4000:]}\n"
    )
    with path.open("a", encoding="utf-8") as handle:
        handle.write(message)


def write_status(base: Path, state: str, **extra: Any) -> Dict[str, Any]:
    health_state = str(state or "COLLECTING").upper()
    runtime_state = "error" if health_state == "ERROR" else ("stopped" if health_state == "STOPPED" else "running")
    payload: Dict[str, Any] = {
        "schema": "review_worker_status_v1183",
        "version": VERSION,
        "build": BUILD_LABEL,
        "running": runtime_state == "running",
        "state": runtime_state,
        "health_state": health_state,
        "phase": extra.pop("phase", health_state.lower()),
        "updated_ts": now_ts(),
        "updated_text": now_text(),
        "pid": os.getpid(),
        "strategy_mode": STRATEGY_MODE,
        "auto_buy": False,
        "owner": "review_worker_single_candidate_standard_owner_v1215",
        "live_ledger_write": False,
    }
    payload.update(extra)
    # Guard convenience metrics; aliases only, no Review calculation or owner change.
    payload["row_count"] = integer(payload.get("candidate_rows"), payload.get("row_count"), default=0)
    payload["last_sec"] = num(payload.get("last_cycle_sec"), payload.get("last_sec"), default=0.0)
    payload["closed_recent"] = integer(payload.get("performance_count"), payload.get("closed_recent"), default=0)
    atomic_write_json(status_path(base), payload)
    return payload


def acquire_singleton(base: Path) -> None:
    global _LOCK_HANDLE
    path = lock_path(base)
    path.parent.mkdir(parents=True, exist_ok=True)
    handle = path.open("a+", encoding="utf-8")
    try:
        fcntl.flock(handle.fileno(), fcntl.LOCK_EX | fcntl.LOCK_NB)
    except BlockingIOError as exc:
        raise RuntimeError("review_worker v1181 already running") from exc
    acquired_ts = now_ts()
    handle.seek(0)
    handle.truncate(0)
    handle.write(__import__("json").dumps({
        "schema": "review_worker_singleton_lock_v1183",
        "pid": os.getpid(),
        "version": VERSION,
        "build": BUILD_LABEL,
        "acquired_ts": acquired_ts,
        "acquired_text": now_text(),
        "lock_path": str(path),
    }, ensure_ascii=False, separators=(",", ":")))
    handle.flush()
    os.fsync(handle.fileno())
    _LOCK_HANDLE = handle
    pid_path(base).write_text(str(os.getpid()), encoding="utf-8")


def release_singleton(base: Path) -> None:
    global _LOCK_HANDLE
    try:
        if _LOCK_HANDLE is not None:
            fcntl.flock(_LOCK_HANDLE.fileno(), fcntl.LOCK_UN)
            _LOCK_HANDLE.close()
    except OSError:
        pass
    _LOCK_HANDLE = None
    try:
        pid_path(base).unlink(missing_ok=True)
    except OSError:
        pass


def signal_handler(signum: int, _frame: Any) -> None:
    global _STOP
    _STOP = True


def _v1195_review_commit_view(snapshot: Any, standard: Any) -> Dict[str, Any]:
    """Validate and normalize one Review generation before any file commit.

    Review previously wrote the canonical snapshot first and only afterwards
    dereferenced nested fields for its event/status payload.  A malformed or
    temporarily missing nested object could therefore leave a current snapshot
    on disk while the worker status switched to ERROR.  Build every scalar used
    by the commit before writing either canonical file, and fail with an exact
    contract error instead of an ambiguous ``NoneType.get`` exception.
    """
    if not isinstance(snapshot, dict):
        raise TypeError(f"review snapshot contract expected dict, got {type(snapshot).__name__}")
    if not isinstance(standard, dict):
        raise TypeError(f"candidate standard contract expected dict, got {type(standard).__name__}")
    source = mapping(snapshot.get("source"))
    candidate = mapping(snapshot.get("candidate"))
    performance = mapping(snapshot.get("performance"))
    return {
        "pipeline_cycle_id": source.get("pipeline_cycle_id"),
        "candidate_commit_id": source.get("candidate_commit_id"),
        "source_state": source.get("state"),
        "review_snapshot_id": snapshot.get("snapshot_id"),
        "candidate_standard_state": standard.get("state"),
        "candidate_rows": candidate.get("total"),
        "performance_count": integer(performance.get("count"), default=0),
    }


def process_once(base: Path, force: bool = False) -> Dict[str, Any]:
    paths = SpinePaths(base)
    request = read_json(paths.review_request, {}) or {}
    prior = read_json(paths.review_snapshot, {}) or {}
    request_identity = (
        str(request.get("candidate_commit_id") or request.get("candidate_commit_id_v1150") or ""),
        str(request.get("pipeline_cycle_id") or request.get("candidate_pipeline_cycle_id_v1150") or ""),
    )
    prior_source = prior.get("source") if isinstance(prior.get("source"), dict) else {}
    prior_identity = (
        str(prior_source.get("candidate_commit_id") or ""),
        str(prior_source.get("pipeline_cycle_id") or ""),
    )
    if not force and request_identity == prior_identity and prior_identity != ("", ""):
        version_score_review = update_version_score_review(base)
        return {
            "processed": False,
            "reason": "same_committed_generation",
            "snapshot_id": prior.get("snapshot_id"),
            "candidate_rows": (prior.get("candidate") or {}).get("total") if isinstance(prior.get("candidate"), dict) else None,
            "version_score_review": version_score_review,
        }

    started = time.monotonic()
    write_status(
        base,
        "RUNNING",
        phase="candidate_standard_build",
        current_pipeline_cycle_id=request_identity[1] or None,
        current_candidate_commit_id=request_identity[0] or None,
    )
    snapshot = build_review_snapshot(base, request=request)
    standard = build_candidate_standard(snapshot)
    commit_view = _v1195_review_commit_view(snapshot, standard)
    event = {
        "schema": "review_generation_event_v1181",
        "event": "REVIEW_GENERATION_COMMITTED",
        "created_ts": now_ts(),
        "created_text": now_text(),
        "pipeline_cycle_id": commit_view["pipeline_cycle_id"],
        "candidate_commit_id": commit_view["candidate_commit_id"],
        "review_snapshot_id": commit_view["review_snapshot_id"],
        "candidate_standard_state": commit_view["candidate_standard_state"],
        "candidate_rows": commit_view["candidate_rows"],
        "live_ledger_write": False,
        "auto_buy": False,
    }
    # Commit boundary: every nested field used by event/status is normalized
    # before either canonical file becomes visible.
    atomic_write_json(paths.review_snapshot, snapshot)
    atomic_write_json(paths.candidate_standard, standard)
    append_jsonl(base / "review_generation_events_v1181.jsonl", event)
    version_score_review = update_version_score_review(base, read_candidate_rows(paths.strategy_candidates, 5000))
    elapsed = max(0.0, time.monotonic() - started)
    write_status(
        base,
        "NORMAL",
        phase="idle",
        last_success_ts=now_ts(),
        last_cycle_sec=round(elapsed, 6),
        last_pipeline_cycle_id=event["pipeline_cycle_id"],
        last_candidate_commit_id=event["candidate_commit_id"],
        last_review_snapshot_id=event["review_snapshot_id"],
        candidate_standard_state=event["candidate_standard_state"],
        candidate_rows=event["candidate_rows"],
        performance_count=commit_view["performance_count"],
        source_state=commit_view["source_state"],
        snapshot_digest=digest_obj(snapshot),
        review_commit_contract_v1195=True,
        review_commit_values_normalized_before_files_v1195=True,
        version_score_review_v1236=True,
        version_score_shadow_open_count=((version_score_review.get("previous_structure_shadow") or {}).get("open_count")),
        version_score_missed_count=((version_score_review.get("missed_current_structure") or {}).get("risk_reward_shortage_count")),
        hybrid_shadow_current_s1_block_v1234=(((version_score_review.get('hybrid_surgery_v1234') or {}).get('current_generation') or {}).get('current_s1_hybrid_block')),
        probability_ev_positive_v1236=((version_score_review.get('probability_policy_v1236') or {}).get('positive_conservative_ev')),
        probability_ev_history_rows_v1236=((version_score_review.get('probability_policy_v1236') or {}).get('history_rows')),
    )
    return {
        "processed": True,
        "elapsed_sec": elapsed,
        "snapshot": snapshot,
        "candidate_standard": standard,
        "version_score_review": version_score_review,
    }


def run_loop(base: Path, interval_sec: float) -> int:
    acquire_singleton(base)
    atexit.register(release_singleton, base)
    signal.signal(signal.SIGTERM, signal_handler)
    signal.signal(signal.SIGINT, signal_handler)
    write_status(base, "STARTING", phase="boot")
    last_heartbeat = 0.0
    consecutive_errors = 0
    while not _STOP:
        try:
            result = process_once(base)
            if not isinstance(result, dict):
                raise RuntimeError(f"review process_once contract returned {type(result).__name__}")
            consecutive_errors = 0
            now = now_ts()
            if not result.get("processed") and now - last_heartbeat >= HEARTBEAT_SEC:
                prior = read_json(SpinePaths(base).review_snapshot, {}) or {}
                source = prior.get("source") if isinstance(prior.get("source"), dict) else {}
                candidate = prior.get("candidate") if isinstance(prior.get("candidate"), dict) else {}
                write_status(
                    base,
                    "NORMAL" if prior else "COLLECTING",
                    phase="idle",
                    last_review_snapshot_id=prior.get("snapshot_id"),
                    last_pipeline_cycle_id=source.get("pipeline_cycle_id"),
                    last_candidate_commit_id=source.get("candidate_commit_id"),
                    candidate_rows=candidate.get("total"),
                    heartbeat=True,
                )
                last_heartbeat = now
        except Exception as exc:  # fail visible; no stale fallback
            consecutive_errors += 1
            log_error(base, "review_loop", exc)
            write_status(
                base,
                "ERROR",
                phase="error",
                last_error=f"{type(exc).__name__}: {exc}",
                consecutive_errors=consecutive_errors,
            )
        slept = 0.0
        while slept < interval_sec and not _STOP:
            step = min(0.2, interval_sec - slept)
            time.sleep(step)
            slept += step
    write_status(base, "STOPPED", phase="shutdown")
    return 0


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--base-dir", default="")
    parser.add_argument("--interval", type=float, default=DEFAULT_INTERVAL_SEC)
    parser.add_argument("--once", action="store_true")
    parser.add_argument("--force", action="store_true")
    args = parser.parse_args()
    base = Path(args.base_dir).expanduser().resolve() if args.base_dir else base_dir()
    if args.once:
        result = process_once(base, force=args.force)
        print(result.get("candidate_standard") or result)
        return 0
    return run_loop(base, max(0.5, args.interval))


# v1190 read-only phase timing evidence
from runtime_phase_probe_v1190 import wrap_function as _v1190_wrap_function
_v1190_wrap_function(globals(), "process_once", "review", "cycle", VERSION, 300.0)

if __name__ == "__main__":
    raise SystemExit(main())
