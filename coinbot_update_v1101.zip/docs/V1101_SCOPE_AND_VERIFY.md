# v1101 Guard slippage verifier hotfix

- Root cause: `collect_quality_spine_verify()` uses `Counter` but Guard v2.5.153 did not import it.
- Fix: add `from collections import Counter` and advance Guard to v2.5.154.
- No trading or strategy behavior changes.
- The verifier still audits the v1100 Orderflow→Strategy→Paper slippage contract.
- Refresh the ops snapshot only after the current worker/Paper runtimes are confirmed.
