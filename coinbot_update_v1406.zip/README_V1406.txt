coinbot v1406
- 목적: v1405 디스크 광역정리 NameError 수정, 명령 ACK 유지, 비핵심 trace/cache 정리 범위 유지
- 전략 수치/자동매수/핵심 거래원장 변경 없음
- 기준: v1158 restored completed-generation handoff + v1405 identity 유지
