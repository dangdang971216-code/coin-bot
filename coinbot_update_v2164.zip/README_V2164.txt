v2164: Main binding order, exact OPEN linkage, Review memory/cycle rotation, Guard fast boot proof. Strategy/Paper/exit unchanged. Auto-buy OFF.
