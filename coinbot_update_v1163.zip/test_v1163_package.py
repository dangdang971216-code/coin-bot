#!/usr/bin/env python3
from pathlib import Path
import json
root=Path(__file__).parent
m=json.loads((root/'DEPLOY_BUNDLE.json').read_text(encoding='utf-8'))
assert m['version']=='v1163'
assert m['main'] is None and m['guard'] is None and m['paper'] is None
assert m['workers']=={'strategy':'strategy_worker_v1.023.py'}
assert m['auto_buy'] is False
assert m['candidate_ttl_change'] is False
assert m['trigger_price_formula_change'] is False
assert m['invalid_formula_change'] is False and m['target_formula_change'] is False
assert m['exit_contract_change'] is False and m['open_limit_change'] is False
for bad in ('paper_bot_open.json','paper_bot_closed.jsonl','trade_log.jsonl','issue_ledger_events.jsonl'):
    assert not (root/bad).exists()
print('PASS v1163 package')
