# v1163 원인과 수정

## 실제 흐름
1. `_v510_publish()`가 시작할 때 `nowv`를 1회 생성한다.
2. canonical row·재검사·plan state·freshness·priority 작업이 진행된다.
3. `apply_swing_entry_gate()` 최종 Gate에서 처음으로 qualified trigger occurrence가 생성된다.
4. 구 경로는 1번의 오래된 `nowv`를 3번의 새 사건 `event_ts`로 저장했다.
5. `_v1153`은 현재시각으로 quality를 기록하고 Paper는 두 시각 차이를 trigger→quality 및 TTL에 사용했다.

## 확정 원인
실제 queue 체류가 아니라 **새 사건의 생성시각 소급 기록**이다. Guard는 Paper 결과를 읽어 표시했을 뿐 원인이 아니다.

## 수정
최종 Gate 직전에 새 wall clock을 잡아 occurrence와 path writer에 동일하게 전달한다. pre-gate 경과는 진단값으로 별도 기록한다. Source freshness는 기존 실행자료 freshness 계약으로 계속 fail-closed다.

## 변경하지 않은 것
Gate·rank·TTL 120초·RR·trigger 가격·invalid·target·spread·slippage·재진입·청산·OPEN 한도.
