# v1163 작업 잠금

- 기록: 2026-06-30 22:06:57 KST
- issue: `TRIGGER-TO-QUALITY-DELAY-001` / OPEN
- 증상: trigger→quality 74~149초, 일부 후보 TTL 120초 이전 소진
- 실제 owner: `strategy_worker.apply_swing_entry_gate`의 occurrence 시각 전달
- 수정 파일: `strategy_worker_v1.023.py` 1개
- 삭제할 구 경로: `_v510_publish` 시작시각 `nowv`를 새 occurrence `event_ts`로 재사용
- 새 본선: final-gate 감지시각 → occurrence → path writer → Paper reader
- 검수: runtime/alias/hash, 신규 event 시각, TTL false stale, 오류 0
- 전략 영향: 가격·Gate·RR·TTL·invalid·target·exit·OPEN 수치 변경 없음
- 자동매수: OFF
