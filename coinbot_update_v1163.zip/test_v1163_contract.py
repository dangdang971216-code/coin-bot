#!/usr/bin/env python3
from pathlib import Path
import ast, re
SRC=Path(__file__).with_name('strategy_worker_v1.023.py')
text=SRC.read_text(encoding='utf-8')
ast.parse(text)
assert "VERSION = 'strategy_worker_v1.023'" in text
assert "BUILD_LABEL = 'v1163_trigger_detection_timestamp_owner_2026-06-30'" in text
start=text.index('def apply_swing_entry_gate')
end=text.index('def _v510_publish', start) if 'def _v510_publish' in text[start:] else len(text)
body=text[start:end]
assert 'trigger_detected_at_v1163 = now_ts()' in body
assert 'trigger_price, trigger_detected_at_v1163, contract_ready_at_cross_v1133' in body
assert 'quality_gate, trigger_detected_at_v1163, state_key' in body
assert "trigger_event_time_owner_v1163']='strategy_worker.apply_swing_entry_gate.final_gate'" in body
assert "V925_MIN_RR = 1.50" in text
assert "V925_MIN_TARGET_ROOM_PCT = 1.20" in text
assert "V977_MAX_TRIGGER_OVERSHOOT_PCT = 0.60" in text
print('PASS v1163 contract')
