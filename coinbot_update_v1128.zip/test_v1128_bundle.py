#!/usr/bin/env python3
from __future__ import annotations
import ast, hashlib, json, pathlib, py_compile, subprocess, sys
ROOT=pathlib.Path(__file__).resolve().parent
FILES={
 'main':ROOT/'coinbot_main_v2_13_1100.py',
 'review':ROOT/'review_worker_v1.006.py',
 'strategy':ROOT/'strategy_worker_v1.010.py',
 'guard':ROOT/'backga_guard_bot_v2_5_173.py',
}
REVIEW_AST={
 '_quality_gate':'eabbf7d72e8b00afc287bb0830e65a9983917d9912c069716f3dd1d4d4d42e7e',
 '_quality_block_reasons':'31186b4094cb219f215a7191f90ede51bd5045858c705641e4c5a673acfd7e24',
 '_quality_cohort':'806735a9c7829d727c4b7832c64efd53db8da9dc5f79e3d811f27cd453750a68',
 '_quality_initial_metrics':'b8204256973797b2582c418564228755ffb4d91836197b508dfab68eb14d0758',
 '_quality_policy_variants_v1120':'b224d0bb7e65894cf7529e050348d79a32c0f95a3eee3489c81bf3fa7989d70f',
}
STRATEGY_AST={
 '_swing_quality_gate':'1d97ab0738d5eb0bab21979aecce9161603c8dc166c4c03d4549758f21ee00f1',
 '_v925_quality_observation':'40e18af05fd7aa08214c4e2aad9e7cc192565a34e7866a4425fb9b7d52abc30a',
 '_v810_quality_metrics':'eec1aa6da75243d7aeb3d9870fb2974701db35ede776a20eddec1aa80c256f88',
 '_v810_quality_decision':'28074427e347f5a50e1ec20b3f9819125dc7314222fdce47a804fca10a9d7e33',
 'collect_quality_reaction_status':'3863df0e0382a3dc9b655710de7aba74769e412f46f9f9d2db6c4c11ccdd2c19',
}
def ast_hashes(path):
    tree=ast.parse(path.read_text(encoding='utf-8'))
    return {n.name:hashlib.sha256(ast.dump(n,include_attributes=False).encode()).hexdigest() for n in ast.walk(tree) if isinstance(n,(ast.FunctionDef,ast.AsyncFunctionDef))}
def main():
    result={'ok':True,'compile':{},'versions':{},'contracts':{},'tests':{}}
    for key,path in FILES.items():
        py_compile.compile(str(path),doraise=True); result['compile'][key]='PASS'
    manifest=json.loads((ROOT/'DEPLOY_BUNDLE.json').read_text(encoding='utf-8'))
    assert manifest['version']=='v1128'
    assert manifest['main']==FILES['main'].name and manifest['guard']==FILES['guard'].name
    assert manifest['workers']['review']==FILES['review'].name and manifest['workers']['strategy']==FILES['strategy'].name
    assert manifest['strategy_mode']=='ALT_SWING' and manifest['auto_buy'] is False
    for flag in ('strategy_contract_change','quality_threshold_change','quality_formula_change','rank_formula_change','slippage_contract_change','open_limit_change','cycle_limit_change','exit_contract_change','performance_formula_change'):
        assert manifest[flag] is False,flag
    for name,digest in REVIEW_AST.items(): assert ast_hashes(FILES['review']).get(name)==digest,name
    for name,digest in STRATEGY_AST.items(): assert ast_hashes(FILES['strategy']).get(name)==digest,name
    assert not list(ROOT.glob('paper_bot*.py'))
    forbidden=('paper_bot_open.json','paper_bot_closed.jsonl','trade_log.json','decision_ledger.jsonl','change_verify_ledger.jsonl','issue_ledger.jsonl','issue_ledger_events.jsonl','canonical_performance_snapshot.json')
    all_names=[p.name for p in ROOT.rglob('*') if p.is_file()]
    assert not any(name in all_names for name in forbidden)
    source_review=FILES['review'].read_text(encoding='utf-8')
    source_strategy=FILES['strategy'].read_text(encoding='utf-8')
    source_guard=FILES['guard'].read_text(encoding='utf-8')
    source_main=FILES['main'].read_text(encoding='utf-8')
    for required in ('EXPECTED_S3_PRECONTRACT_NO_OWNER','FINAL_OWNER_RESEEN_BLOCKED','exact_append_accounting_ok','cycle_file_delta_comparable'):
        assert required in source_review,required
    for required in ('trigger_occurrence_owner_state_v1128','CANONICAL_TRIGGER_DECISION','EXPECTED_S3_PRECONTRACT_NO_OWNER'):
        assert required in source_strategy,required
    for required in ('positive_growth_bytes_sec_raw_v1128','quality_bounded_remaining_bytes_v1128','FINITE_BOUNDED_FAMILY_NOT_LINEAR_FOREVER'):
        assert required in source_guard,required
    for required in ('v1128 후보품질 owner·writer 마감','v1128-quality-owner-writer-server-proof-001','runtime_mismatch_count_v1128','EXPECTED_REVIEW_VERSION = "review_worker_v1.006"'):
        assert required in source_main,required
    tests=(
      'test_review_horizon_v1128.py','test_review_storage_v1128.py','test_review_restart_finalize_v1128.py','test_review_owner_writer_v1128.py',
      'test_strategy_owner_contract_v1128.py','test_guard_projection_v1128.py','test_main_command_v1128.py','test_main_ledger_v1128.py')
    for test_name in tests:
        run=subprocess.run([sys.executable,str(ROOT/test_name)],capture_output=True,text=True,check=True)
        result['tests'][test_name]=run.stdout.strip()
    result['versions']={'main':'v2.13.1100','review':'v1.006','strategy':'v1.010','guard':'v2.5.173','paper':'v1.020 unchanged'}
    result['contracts']={
      'horizon_gate':'UNCHANGED_PASS','identity_owner':'UNCHANGED_PASS','expected_s3_split':'PASS','actual_owner_gap':'SEPARATE',
      'final_owner_retrack_block':'PASS','append_once_exact_bytes':'PASS','rotation_aware_accounting':'PASS','bounded_disk_projection':'PASS',
      'live_quality_formula':'UNCHANGED','open_limit':'30_UNCHANGED','cycle_limit':'3_UNCHANGED','exit_contract':'UNCHANGED','auto_buy':'OFF'}
    print(json.dumps(result,ensure_ascii=False,sort_keys=True)); return 0
if __name__=='__main__': raise SystemExit(main())
