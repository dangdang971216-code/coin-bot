#!/usr/bin/env python3
from __future__ import annotations
import importlib.util, json, pathlib, shutil, tempfile, time
ROOT=pathlib.Path(__file__).resolve().parent
base=pathlib.Path(tempfile.mkdtemp(prefix='coinbot_main_ledger_v1128_'))
module_copy=base/'coinbot_main_v2_13_1100.py'; shutil.copy2(ROOT/'coinbot_main_v2_13_1100.py',module_copy)
spec=importlib.util.spec_from_file_location('main_ledger_v1128',module_copy)
mod=importlib.util.module_from_spec(spec); spec.loader.exec_module(mod)
change_path=mod._v870_path('change'); issue_path=mod._v870_path('issue_event')
change_text=change_path.read_text(encoding='utf-8')
assert 'v1128-quality-owner-writer-closeout-001' in change_text
assert 'QUALITY-SHADOW-OWNER-WRITER-1128' in issue_path.read_text(encoding='utf-8')
status={
 'version':'review_worker_v1.006','updated_ts':time.time(),'identity_owner_field_v1126':'trigger_occurrence_v1037.decision_key','identity_owner_missing_this_cycle_v1126':2,
 'missing_owner_expected_counts_v1128':{'EXPECTED_S3_PRECONTRACT_NO_OWNER':2},'missing_owner_gap_counts_v1128':{},
 'final_append_truth_v1128':{'append_once':True,'exact_append_accounting_ok':True},
 'storage_truth_v1127':{'active_state_schema':'quality_shadow_state_v1127_packed_active','terminal_rows_in_active_state':0,'active_unfinished_rows':2}
}
(base/'clean_quality_shadow_status_v1125.json').write_text(json.dumps(status),encoding='utf-8')
(base/'clean_quality_eye_status_v1125.json').write_text(json.dumps({'updated_ts':time.time(),'comparison_contract':'10m completed rows provisional; 60m completed comparison-ready final'}),encoding='utf-8')
ops={'flow_map_v1103':{'runtime_summary':{'mismatch':[]}},'sections':{'system':{'components':{
 'strategy':{'runtime_status_identity':{'version':'strategy_worker_v1.010'}},
 'guard':{'runtime_status_identity':{'version':'guard_v2.5.173_quality_append_bounded_projection_truth_v1128_2026-06-29'}}}},'ledger':{'multi_writer_count':0}}}
(base/'ops_map_snapshot.json').write_text(json.dumps(ops),encoding='utf-8')
result=mod._v1128_finalize_quality_p0_server_proof_once()
assert result['ok'] is True, result
assert all(result['checks'].values()),result
assert (base/'runtime'/'quality_owner_writer_v1128.server_done').exists()
assert 'v1128-quality-owner-writer-server-proof-001' in change_path.read_text(encoding='utf-8')
print('PASS canonical v1128 seed and server-proof closeout with actual runtime summary/components')
