#!/usr/bin/env python3
from __future__ import annotations
import ast, hashlib, pathlib
ROOT=pathlib.Path(__file__).resolve().parent
new=ROOT/'strategy_worker_v1.010.py'
EXPECTED={
 '_swing_quality_gate':'1d97ab0738d5eb0bab21979aecce9161603c8dc166c4c03d4549758f21ee00f1',
 '_v925_quality_observation':'40e18af05fd7aa08214c4e2aad9e7cc192565a34e7866a4425fb9b7d52abc30a',
 '_v810_quality_metrics':'eec1aa6da75243d7aeb3d9870fb2974701db35ede776a20eddec1aa80c256f88',
 '_v810_quality_decision':'28074427e347f5a50e1ec20b3f9819125dc7314222fdce47a804fca10a9d7e33',
 'collect_quality_reaction_status':'3863df0e0382a3dc9b655710de7aba74769e412f46f9f9d2db6c4c11ccdd2c19',
}
tree=ast.parse(new.read_text(encoding='utf-8'))
hashes={n.name:hashlib.sha256(ast.dump(n,include_attributes=False).encode()).hexdigest() for n in ast.walk(tree) if isinstance(n,(ast.FunctionDef,ast.AsyncFunctionDef))}
for name,digest in EXPECTED.items(): assert hashes.get(name)==digest,(name,hashes.get(name),digest)
s=new.read_text(encoding='utf-8')
assert "trigger_occurrence_owner_state_v1128='EXPECTED_S3_PRECONTRACT_NO_OWNER'" in s
assert "trigger_occurrence_v1037={}" in s
assert "trigger_occurrence_owner_state_v1128='CANONICAL_TRIGGER_DECISION'" in s
print('PASS Strategy canonical/precontract owner semantics; quality formulas unchanged')
