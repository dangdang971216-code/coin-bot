#!/usr/bin/env python3
from __future__ import annotations
import importlib.util, os, pathlib, tempfile, time
ROOT=pathlib.Path(__file__).resolve().parent
base=tempfile.mkdtemp(prefix='coinbot_review_owner_writer_v1128_')
os.environ['TRADING_BOT_DIR']=base
spec=importlib.util.spec_from_file_location('review_owner_writer_v1128',ROOT/'review_worker_v1.006.py')
mod=importlib.util.module_from_spec(spec); spec.loader.exec_module(mod)

def classify(row):
    key,mode=mod._quality_exact_identity(row)
    evidence=mod._quality_identity_evidence_v1126(row)
    return mod._quality_missing_owner_class_v1128(row,evidence)

code,severity,_=classify({'ticker':'AAA','s_stage':'S3','trigger_occurrence_owner_state_v1128':'EXPECTED_S3_PRECONTRACT_NO_OWNER'})
assert (code,severity)==('EXPECTED_S3_PRECONTRACT_NO_OWNER','EXPECTED')
code,severity,_=classify({'ticker':'AAA','s_stage':'S3','trigger_occurrence_v1037':{'candidate_key':'c1'}})
assert (code,severity)==('EXPECTED_S3_PRECONTRACT_NO_OWNER','EXPECTED')
code,severity,_=classify({'ticker':'AAA','s_stage':'S2','trigger_occurrence_v1037':{}})
assert severity=='GAP' and code=='TRADE_PATH_NO_TRIGGER_OBJECT'
code,severity,_=classify({'ticker':'AAA','s_stage':'S2','trigger_occurrence_v1037':{'kind':'REBREAK','sequence':1}})
assert severity=='GAP' and code=='TRIGGER_OBJECT_NO_DECISION_KEY'

final={'quality_event_key_v946':'trigger_decision:done1','ticker':'AAA','first_seen_ts':time.time()-3600,'finalized_ts':time.time(),'first_price':100.0,'samples':{},'policy_variants_v1120':{}}
size0=mod.QUALITY_SHADOW_LEDGER.stat().st_size if mod.QUALITY_SHADOW_LEDGER.exists() else 0
assert mod._quality_append_final(final) is True
size1=mod.QUALITY_SHADOW_LEDGER.stat().st_size
assert mod._quality_append_final(final) is False
size2=mod.QUALITY_SHADOW_LEDGER.stat().st_size
assert size1>size0 and size2==size1
assert mod._QUALITY_FINAL_APPEND_CYCLE_V1128['attempts']==2
assert mod._QUALITY_FINAL_APPEND_CYCLE_V1128['appended']==1
assert mod._QUALITY_FINAL_APPEND_CYCLE_V1128['duplicate_blocked']==1
assert mod._QUALITY_FINAL_APPEND_CYCLE_V1128['bytes_appended']==size1-size0

row={'ticker':'ABC','trigger_occurrence_v1037':{'decision_key':'plan1','base_plan_decision_key':'plan1','kind':'INITIAL_ABOVE','sequence':0},'current_price':100.0,'s_stage':'S3','swing_entry_gate_v977':{'hard_pass':False,'stage':'S3','hard_block_reasons':['watch']}}
key,_=mod._quality_exact_identity(row)
mod._dedup_commit_v1013(mod.QUALITY_DEDUP_KIND_V1125,key)
status,rows=mod.update_quality_shadow(time.time(),{'ABC':{'current_price':100.0}}, {}, [row], {})
assert status['new_records_this_cycle']==0 and len(rows)==0
assert status['identity_event_counts_v1126']['FINAL_OWNER_RESEEN_BLOCKED']==1
print('PASS expected S3 split, actual gap split, append-once bytes, duplicate block and finalized-owner re-track block')
