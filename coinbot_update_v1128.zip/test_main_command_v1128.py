#!/usr/bin/env python3
from __future__ import annotations
import importlib.util, json, pathlib, shutil, tempfile, time
ROOT=pathlib.Path(__file__).resolve().parent
base=pathlib.Path(tempfile.mkdtemp(prefix='coinbot_main_command_v1128_'))
module_copy=base/'coinbot_main_v2_13_1100.py'; shutil.copy2(ROOT/'coinbot_main_v2_13_1100.py',module_copy)
spec=importlib.util.spec_from_file_location('main_command_v1128',module_copy)
mod=importlib.util.module_from_spec(spec); spec.loader.exec_module(mod)
mod.BASE_DIR=base
mod.QUALITY_SHADOW_STATUS=base/'clean_quality_shadow_status_v1125.json'
mod.QUALITY_EYE_STATUS_V1124=base/'clean_quality_eye_status_v1125.json'
mod.QUALITY_POLICY_COMPARISON_STATUS_V1120=base/'clean_quality_policy_comparison_status_v1125.json'
mod.QUALITY_SHADOW_STATUS.write_text(json.dumps({
 'updated_ts':time.time(),'version':'review_worker_v1.006','source_rows_raw_v1125':3,'source_unique_trigger_decisions_v1125':2,'tracked_records':1,'new_records_this_cycle':0,
 'identity_owner_field_v1126':'trigger_occurrence_v1037.decision_key','identity_owner_values_sample_v1126':['plan1'],
 'identity_event_counts_v1126':{'NEW_PLAN':0,'NEW_RESET_REBREAK':0,'SAME_PLAN_KEY_CHURN_BLOCKED':0,'FINAL_OWNER_RESEEN_BLOCKED':1,'MISSING_OWNER_KEY':2},
 'missing_owner_reason_counts_v1127':{'EXPECTED_S3_PRECONTRACT_NO_OWNER':2},'missing_owner_expected_counts_v1128':{'EXPECTED_S3_PRECONTRACT_NO_OWNER':2},'missing_owner_gap_counts_v1128':{},
 'storage_truth_v1127':{'active_state_schema':'quality_shadow_state_v1127_packed_active','active_unfinished_rows':1,'terminal_rows_in_active_state':0,'state_bytes':1024,'final_ledger_file':'quality_shadow_result_ledger_v1125.jsonl','aggregate_file':'clean_quality_eye_aggregate_v1125.json'},
 'final_append_truth_v1128':{'cycle':{'appended':1,'duplicate_blocked':0,'bytes_appended':500},'process':{'appended':2,'duplicate_blocked':1,'bytes_appended':1000},'final_owner_reseen_blocked_this_cycle':1,'exact_append_accounting_ok':True}
}),encoding='utf-8')
empty60={k:{'n':0,'comparison_ready_n':0} for k in ('safety_only','current_quality','improved_quality')}
ten={k:{'n':1,'adjusted_n':1,'mfe_n':1,'mae_n':1} for k in ('safety_only','current_quality','improved_quality')}
mod.QUALITY_EYE_STATUS_V1124.write_text(json.dumps({'updated_ts':time.time(),'version':'review_worker_v1.006','state':'COLLECTING','identity_owner_field':'trigger_occurrence_v1037.decision_key','identity_contract':'exact owner only','comparison_contract':'10m completed provisional; 60m completed comparison-ready final','ten_minute_completed_events':1,'finalized_events':0,'active_unfinalized_events':1,'minimum_ready_n':0,'minimum_60m_samples_per_policy':30,'leader_state':'INSUFFICIENT_60M_SAMPLE','horizons':{'10m':ten,'60m':empty60},'false_pass_10m_provisional':{},'false_pass_60m_final':{},'false_block_60m_final':{}}),encoding='utf-8')
(base/'ops_map_snapshot.json').write_text(json.dumps({'sections':{'ledger':{'quality_shadow_writer_truth_v1126':[{'name':'quality_shadow_result_ledger_v1125.jsonl','inode':1,'since_owner_start_growth_bytes':500,'since_owner_start_state':'MEASURED','current_write_fd_pids':[],'active_writer_verdict':'NO_CURRENT_WRITE_PROVEN','exact_append_truth_v1128':{'process':{'appended':2,'bytes_appended':1000,'duplicate_blocked':1},'exact_process_append_rate_bytes_sec':1.0},'bounded_storage_contract_v1128':{'projection_mode':'FINITE_CAP_RESERVE','family_remaining_bytes':10485760}}]}}}),encoding='utf-8')
text='\n'.join(mod.quality_shadow_lines(True))
for required in ('[v1128 후보 보는 눈','FINAL_OWNER_RESEEN_BLOCKED 1','owner 없음 정상: S3_PRECONTRACT 2 / 실제 gap 0','final append: cycle 신규 1','exact append process 2건','bounded FINITE_CAP_RESERVE','60m 비교가능 최소표본 0/30'):
    assert required in text, required
assert mod.render_quality_shadow_text().startswith('🧬 /quality_shadow · v1128 후보품질 owner·writer 마감')
source=(ROOT/'coinbot_main_v2_13_1100.py').read_text(encoding='utf-8')
assert "runtime_summary=flow.get('runtime_summary')" in source
assert 'runtime_mismatch_count_v1128' in source
assert "strategy_runtime_version_v1128=='strategy_worker_v1.010'" in source
assert "append_truth.get('exact_append_accounting_ok') is True" in source
print('PASS Main v1128 owner/writer renderer and exact runtime proof reader')
