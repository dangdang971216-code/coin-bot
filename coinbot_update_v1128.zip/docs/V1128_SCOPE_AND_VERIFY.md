# v1128 후보품질 owner·writer 마감

## 실제 원인

1. Strategy의 S3 pre-contract row가 canonical decision key 없이 candidate key만 든 trigger object로 바뀌어 실제 owner 누락처럼 보였다.
2. 60분 완료 row가 active state에서 빠진 뒤에도 동일 owner가 source에 남으면 새 active row가 다시 만들어질 수 있었다. 최종 ledger append는 dedup됐지만 불필요한 60분 재추적은 지속될 수 있었다.
3. Guard의 최근 60분 파일 증가율에는 v1127 migration/finalization burst가 섞였고, bounded ledger/state를 무한 선형 증가로 투영했다.
4. exact append rows/bytes와 duplicate block을 cycle/process 기준으로 직접 증명하는 status가 없었다.

## 수정 본선

- Strategy: canonical `trigger_occurrence_v1037`는 decision key가 있을 때만 공개한다. S3 미완성 계획은 `EXPECTED_S3_PRECONTRACT_NO_OWNER`로 봉인한다.
- Review: expected S3와 실제 gap을 분리하고, dedup 완료 owner를 active create 전에 차단한다.
- Review writer: append attempts/appended/duplicate/bytes를 exact로 기록하며 rotation cycle은 file delta 비교 불가로 명시한다.
- Guard: raw rate는 보이되 bounded final ledger/archive와 packed state의 남은 최대용량을 reserve하고, 나머지 persistent rate로만 소진일을 계산한다.
- Main: `/quality_shadow`에 expected/gap, final owner re-seen, exact append, bounded storage를 표시하고 실제 runtime summary/component version으로 server proof를 닫는다.

## 변경하지 않은 영역

- 품질 Gate·점수·rank 공식
- trigger·invalid·target 값
- 실제 Strategy/Paper selector
- OPEN 30 / cycle 신규 3
- 청산계약
- OPEN/CLOSED/trade_log/decision/exact/change/issue 원장 삭제·축소·재작성
- 자동매수 OFF
