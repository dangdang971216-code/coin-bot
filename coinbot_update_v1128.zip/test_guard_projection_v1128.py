#!/usr/bin/env python3
from __future__ import annotations
import importlib.util, os, pathlib, tempfile, time
ROOT=pathlib.Path(__file__).resolve().parent
s=(ROOT/'backga_guard_bot_v2_5_173.py').read_text(encoding='utf-8')
for token in ('positive_growth_bytes_sec_raw_v1128','positive_growth_bytes_sec','quality_bounded_remaining_bytes_v1128','projected_available_v1128','bounded_storage_contract_v1128','exact_append_truth_v1128','FINITE_BOUNDED_FAMILY_NOT_LINEAR_FOREVER','FINITE_PACKED_ACTIVE_STATE_NOT_APPEND_LEDGER'):
    assert token in s, token
assert "bounded_quality_names_v1128={'quality_shadow_result_ledger_v1125.jsonl','clean_quality_shadow_state_v1125.json'}" in s
base=tempfile.mkdtemp(prefix='coinbot_guard_projection_v1128_')
os.environ['TRADING_BOT_DIR']=base; os.environ['GUARD_BOT_TOKEN']='test'; os.environ['GUARD_CHAT_ID']='1'
spec=importlib.util.spec_from_file_location('guard_projection_v1128',ROOT/'backga_guard_bot_v2_5_173.py')
mod=importlib.util.module_from_spec(spec); spec.loader.exec_module(mod)
ledger=[{'name':'quality_shadow_result_ledger_v1125.jsonl','size_bytes':1024,'growth_bytes_sec':100.0},{'name':'other.jsonl','size_bytes':1,'growth_bytes_sec':2.0}]
flow=mod._ops_build_flow_map_v1103({},[],{},[],ledger,[],{'total_bytes':10**9,'available_bytes':9*10**8},{'total_bytes':10**9,'available_bytes':9*10**8},time.time(),{})
resource=flow['resource_summary']
assert resource['positive_growth_bytes_sec_raw_v1128']==102.0
assert resource['positive_growth_bytes_sec']==2.0
assert resource['quality_bounded_remaining_bytes_v1128']>0
print('PASS Guard runtime calculation separates raw growth from bounded quality storage')
