import importlib.util
import json
import sys
import tempfile
import time
import unittest
from pathlib import Path

ROOT = Path(__file__).resolve().parent
OLD_SOURCE = Path('/mnt/data/v1201_bundle_stage/paper_bot_v1.053.py')
NEW_SOURCE = ROOT / 'paper_bot_v1.062.py'
for directory in {str(ROOT), str(OLD_SOURCE.parent)}:
    if directory not in sys.path:
        sys.path.insert(0, directory)


def load_module(name: str, source: Path):
    spec = importlib.util.spec_from_file_location(name, source)
    module = importlib.util.module_from_spec(spec)
    assert spec and spec.loader
    spec.loader.exec_module(module)
    return module


class TerminalFeedbackSingleLoadV1202Tests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.old = load_module('paper_v1201_old', OLD_SOURCE)
        cls.new = load_module('paper_v1202_new', NEW_SOURCE)
        cls.old_load_json = cls.old.load_json
        cls.new_load_json = cls.new.load_json

    def setUp(self):
        self.old.load_json = type(self).old_load_json
        self.new.load_json = type(self).new_load_json
        self.tmp = tempfile.TemporaryDirectory()
        self.root = Path(self.tmp.name)
        self.events = []
        self.records = {}
        now = time.time()
        for i in range(24):
            decision = f'decision-{i}'
            event_ts = now - 1.0
            self.events.append({
                'ticker': f'T{i}',
                'event_id': f'event-{i}',
                's_stage': 'S1',
                'candidate_grade': 'S1',
                'strategy_mode': 'ALT_SWING_V977',
                'swing_gate_decision_key_v977': decision,
                'swing_entry_gate_v977': {
                    'schema': 'swing_entry_gate_v977_single_owner',
                    'strategy_mode': 'ALT_SWING_V977',
                    'hard_pass': True,
                    'final_trade_state': 'S1_PASS',
                    'decision_key': decision,
                    'risk_reward': 3.0,
                    'target_room_pct': 5.0,
                    'source_fresh': True,
                    'trigger_occurrence': {
                        'decision_key': decision,
                        'event_ts': event_ts,
                        'candidate_key': f'candidate-{i}',
                    },
                },
                'candidate_created_at': now,
                'source_created_at': now,
                'current_price': 100.0,
                'entry_context': {},
            })
            self.records[decision] = {
                'terminal_code': 'STALE_TRIGGER_OCCURRENCE',
                'trigger_event_ts': event_ts,
                'first_handoff_id_v1160': 'handoff-current',
                'first_pipeline_cycle_id_v1160': 'cycle-current',
                'event_uid': f'uid-{i}',
                'first_seen_ts': now - 2.0,
                'payload': 'x' * 512,
            }
        self.state_path = self.root / 'paper_trigger_terminal_feedback_v1159.json'
        self.state_path.write_text(json.dumps({'records': self.records}, ensure_ascii=False), encoding='utf-8')

    def tearDown(self):
        self.tmp.cleanup()

    def configure(self, module):
        module.V1159_TRIGGER_TERMINAL_FEEDBACK_STATE = self.state_path
        module.V1153_PAPER_PATH_STATE = self.root / f'{module.VERSION}_path_state.json'
        module.V1153_PAPER_PATH_LEDGER = self.root / f'{module.VERSION}_path_events.jsonl'
        module.BOOK_RESET_CONTROL_V1044 = self.root / f'{module.VERSION}_reset.json'
        module._V1192_PAPER_PATH_BATCH = None
        module._V1192_PAPER_PATH_BATCH_LAST = {'schema':'paper_candidate_path_batch_v1192','state':'NOT_RUN','active':False}
        handoff = {
            's1_rows': [dict(row, paper_consumed_handoff_id_v1158='handoff-current', candidate_pipeline_cycle_id_v1150='cycle-current') for row in self.events],
            'cycle_id': 'cycle-current',
            'handoff_id_v1158': 'handoff-current',
            'completed_ts': time.time(),
        }
        module._v1158_resolve_completed_handoff_v1158 = lambda ctrl: ({
            'ready': True,
            'cycle_id': 'cycle-current',
            'effective_generation_source_v1158': 'CURRENT_COMPLETE',
            'committed_handoff_id_v1158': 'handoff-current',
        }, handoff)
        module.latest_scan_filter = lambda rows, ctrl: rows
        module.closed_recent_ids = lambda limit=2000: set()
        module._v926_seed_decision_state = lambda open_pos: {'records': {f'decision-{i}': {'status':'OPEN'} for i in range(24)}}
        module._v926_save_decision_state = lambda state: True
        module._v938_load_trigger_reach_state = lambda: {}
        module._v938_save_trigger_reach_state = lambda state: None
        module.write_paper_timing_spine_status = lambda stats, picked: None
        original_load = module.load_json
        counts = {'terminal': 0, 'all': 0}

        def counted_load(path, default=None):
            counts['all'] += 1
            if Path(path) == self.state_path:
                counts['terminal'] += 1
                return original_load(path, default)
            return default

        module.load_json = counted_load
        return counts

    def test_old_reloads_terminal_state_for_each_s1(self):
        counts = self.configure(self.old)
        picked, stats, latest = self.old.select_candidates({}, {})
        self.assertEqual(len(picked), 0)
        self.assertEqual(len(latest), 24)
        self.assertEqual(counts['terminal'], 24)
        self.assertEqual(int(stats.get('decision_already_consumed_v926') or 0), 24)

    def test_new_selector_loads_terminal_state_once(self):
        counts = self.configure(self.new)
        picked, stats, latest = self.new.select_candidates({}, {})
        self.assertEqual(len(picked), 0)
        self.assertEqual(len(latest), 24)
        self.assertEqual(counts['terminal'], 1)
        self.assertEqual(stats['terminal_feedback_state_load_count_v1202'], 1)
        self.assertEqual(stats['terminal_feedback_lookup_count_v1202'], 24)
        self.assertEqual(stats['terminal_feedback_record_count_v1202'], 24)
        self.assertEqual(int(stats.get('decision_already_consumed_v926') or 0), 24)

    def test_terminal_classification_is_identical(self):
        self.old.V1159_TRIGGER_TERMINAL_FEEDBACK_STATE = self.state_path
        self.new.V1159_TRIGGER_TERMINAL_FEEDBACK_STATE = self.state_path
        old_results = [self.old._v1160_existing_terminal_feedback(row) for row in self.events]
        new_results = [self.new._v1160_existing_terminal_feedback(row, self.records) for row in self.events]
        self.assertEqual(old_results, new_results)

    def test_strategy_and_exit_contracts_unchanged(self):
        source = NEW_SOURCE.read_text(encoding='utf-8')
        self.assertIn("PAPER_MIN_RR = 1.50", source)
        self.assertIn("PAPER_MIN_TARGET_ROOM_PCT = 1.20", source)
        self.assertIn("PAPER_MAX_TRIGGER_CHASE_PCT = 0.60", source)
        self.assertIn("'max_open_strict':0,'max_new_per_cycle':0", source)
        self.assertIn("'auto_buy': False", source)


if __name__ == '__main__':
    unittest.main(verbosity=2)
