import importlib.util
import sys
import unittest
from pathlib import Path
from unittest import mock

ROOT=Path(__file__).resolve().parent

def load():
    name='paper_v1209_test'
    spec=importlib.util.spec_from_file_location(name,ROOT/'paper_bot_v1.062.py')
    mod=importlib.util.module_from_spec(spec); assert spec and spec.loader
    sys.modules[name]=mod
    spec.loader.exec_module(mod)
    return mod

paper=load()

class V1209TimingBridgeTests(unittest.TestCase):
    def base(self):
        return {
            'ticker':'KRW-X',
            'paper_decision_key_v926':'decision-1',
            'opened_at':1010.0,
            'paper_selected_ts_v940':1008.0,
            'first_seen_ts':990.0,
        }

    def test_top_level_strategy_s1_ready_is_used(self):
        row=self.base() | {
            's1_ready_at_v1173':1000.0,
            's1_ready_decision_key_v1173':'decision-1',
        }
        ev=paper._v938_quality_evidence_from_row(row)
        self.assertEqual(ev['s1_seen_ts'],1000.0)
        self.assertEqual(ev['s1_timing_status_v1209'],'EXACT')
        self.assertEqual(ev['s1_timing_source_v1209'],'strategy_worker.s1_ready_at_v1173')
        spine=paper.collect_paper_timing_spine(row,selected_ts=1008.0,opened_ts=1010.0,phase='test')
        self.assertEqual(spine['s1_to_open_delay_sec'],10.0)
        self.assertEqual(spine['s1_to_selected_delay_sec'],8.0)

    def test_nested_candidate_path_is_used_after_compaction(self):
        row=self.base() | {
            'candidate_path_timestamps_v1153':{
                's1_ready_at_v1173':1001.5,
                'quality_pass_at':1001.5,
            },
            'trigger_occurrence_contract':{
                's1_ready_decision_key_v1173':'decision-1',
            },
        }
        ev=paper._v938_quality_evidence_from_row(row)
        self.assertEqual(ev['s1_seen_ts'],1001.5)
        self.assertEqual(ev['s1_timing_status_v1209'],'EXACT')
        spine=paper.collect_paper_timing_spine(row,opened_ts=1010.0,phase='test')
        self.assertEqual(spine['s1_to_open_delay_sec'],8.5)

    def test_nested_trigger_occurrence_owner_is_used(self):
        row=self.base() | {
            'trigger_occurrence_v1037':{
                's1_ready_ts_v1173':1002.0,
                's1_ready_decision_key_v1173':'decision-1',
                'event_ts':998.0,
            },
        }
        ev=paper._v938_quality_evidence_from_row(row)
        self.assertEqual(ev['s1_seen_ts'],1002.0)
        self.assertEqual(ev['s1_timing_status_v1209'],'EXACT')

    def test_mismatched_decision_key_is_not_backfilled(self):
        row=self.base() | {
            's1_ready_at_v1173':1000.0,
            's1_ready_decision_key_v1173':'different-decision',
        }
        ev=paper._v938_quality_evidence_from_row(row)
        self.assertIsNone(ev['s1_seen_ts'])
        self.assertEqual(ev['s1_timing_status_v1209'],'DECISION_KEY_MISMATCH')
        spine=paper.collect_paper_timing_spine(row,opened_ts=1010.0,phase='test')
        self.assertNotIn('s1_to_open_delay_sec',spine)
        self.assertEqual(spine['s1_timing_status_v1209'],'DECISION_KEY_MISMATCH')

    def test_missing_source_stays_missing_without_current_time_fabrication(self):
        row=self.base()
        ev=paper._v938_quality_evidence_from_row(row)
        self.assertIsNone(ev['s1_seen_ts'])
        self.assertEqual(ev['s1_timing_status_v1209'],'SOURCE_MISSING')
        self.assertIsNone(ev['s1_timing_source_v1209'])

    def test_open_alert_uses_exact_delay_and_precise_missing_reason(self):
        pos={
            'ticker':'X','candidate_grade':'S1','score':1.0,'entry_price':100.0,
            'paper_decision_key_v926':'decision-1','opened_at':1010.0,
            'paper_timing_spine_v940':{
                's1_to_open_delay_sec':8.5,'first_to_open_delay_sec':20.0,
                'selected_to_open_delay_sec':2.0,'s1_timing_status_v1209':'EXACT',
            },
        }
        with mock.patch.object(paper,'_v983_build_entry_evidence',return_value={
            'timing':pos['paper_timing_spine_v940'],'trigger':{},'invalid':{},'target':{},'cost':{}
        }):
            text=paper._v983_open_message_text(pos)
        self.assertIn('S1→OPEN: +8.5초',text)
        self.assertNotIn('S1→OPEN: 자료 없음',text)

        pos2=dict(pos)
        pos2['paper_timing_spine_v940']={'s1_timing_status_v1209':'SOURCE_MISSING'}
        with mock.patch.object(paper,'_v983_build_entry_evidence',return_value={
            'timing':pos2['paper_timing_spine_v940'],'trigger':{},'invalid':{},'target':{},'cost':{}
        }):
            text2=paper._v983_open_message_text(pos2)
        self.assertIn('S1→OPEN: 자료 없음(SOURCE_MISSING)',text2)

    def test_release_identity(self):
        self.assertEqual(paper.VERSION,'paper_bot_v1.062')
        self.assertIn('v1211_paper_hotpath_durability_tiers',paper.BUILD_LABEL)

if __name__=='__main__':
    unittest.main(verbosity=2)
