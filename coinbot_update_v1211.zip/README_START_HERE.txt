코인봇 업데이트 v1211
======================
목적: v1210 이후 남은 Paper fsync·후처리 반복과 Strategy 같은-cycle 중복계산을 제거합니다.

핵심 파일
- paper_bot_v1.062.py
- strategy_worker_v1.043.py
- coinbot_main_v2_13_1140.py
- backga_guard_bot_v2_5_209.py
- bithumb_micro_sidecar_v0.17.py (변경 없음)
- canonical_spine_v1190.py

안전 계약
- exact OPEN/CLOSED/decision/reset/TOP10 파일은 기존 fsync·검증 유지
- 전체시장·후보·S1·trigger·invalid·target·RR 변경 없음
- TOP10 10/9/1, generation당 신규 2, v1207 동적청산 유지
- 자동매수 OFF

검수
- 로컬 68/68 PASS
- 서버 적용 전 CHECK
- 자세한 내용: docs/V1211_WORK_LOCK_AND_ROOT_CAUSE.txt
