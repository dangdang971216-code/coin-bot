import ast
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
SRC=(ROOT/'backga_guard_bot_v2_5_233.py').read_text()

def load_helper():
    tree=ast.parse(SRC)
    node=next(n for n in tree.body if isinstance(n,ast.FunctionDef) and n.name=='worker_semantic_ready')
    ns={}
    exec(compile(ast.Module(body=[node],type_ignores=[]),'<helper>','exec'),ns)
    return ns['worker_semantic_ready']

def test_collecting_normal_is_ready():
    f=load_helper()
    assert f({'state':'NORMAL','health_state':'COLLECTING_V1211_ROOT_AUDIT'})
    assert f({'state':'running','health_state':'COLLECTING_POLICY_RESULTS'})
    assert f({'state':'ready','health_state':'NORMAL'})

def test_check_fail_error_are_rejected():
    f=load_helper()
    assert not f({'state':'NORMAL','health_state':'CHECK_NO_COMPARABLE_STRUCTURE_ROWS'})
    assert not f({'state':'NORMAL','health_state':'FAIL_RUNTIME'})
    assert not f({'state':'NORMAL','health_state':'ERROR_IO'})
    assert not f({'state':'CHECK','health_state':'COLLECTING'})

def test_all_three_guard_paths_use_semantic_contract():
    assert 'worker_semantic_ready(st if isinstance(st, dict) else {})' in SRC
    assert 'worker_semantic_ready(last)' in SRC
    assert 'worker_semantic_ready(after)' in SRC
    assert 'after.get("state") == "running"' not in SRC

def test_version():
    assert 'guard_v2.5.233_v1254_worker_semantic_readiness_contract_2026-07-05' in SRC
