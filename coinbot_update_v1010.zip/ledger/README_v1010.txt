이 디렉터리는 v1010 릴리스의 기록 설명만 포함한다.
라이브 change_verify/issue/OPEN/CLOSED/trade_log/decision/exact 원장은 bundle에 포함하지 않는다.
실제 v1009 PARTIAL/FAIL과 v1010 CHECK 이벤트는 main active bind의 seed_v1010_runtime_board_change()가 기존 append-only writer를 통해 기록한다.
