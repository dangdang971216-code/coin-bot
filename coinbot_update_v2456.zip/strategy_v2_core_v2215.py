from __future__ import annotations

import hashlib
import json
import math
import statistics
import time
from collections import Counter
from typing import Any, Dict, Iterable, List, Optional, Tuple

VERSION = "strategy_v2_core_v2215"
BUILD_LABEL = "prediction_material_role_stage_normalization_2026-08-04"
GENERATION = "ALT_SWING_V2_COMBINED_V2149_RESET_20260722"
PREDICTION_MODEL_GENERATION = "RISE_MATERIAL_ROLE_STAGE_DIRECTION_V13"

REQUIRED_ROWS = {"m5": 48, "m15": 32, "m30": 48, "h1": 48, "h2": 32, "h4": 20}
TF_WEIGHT = {"m5": 1.0, "m15": 1.5, "m30": 2.1, "h1": 2.9, "h2": 4.0, "h4": 5.0}
RISE_MATERIAL_NAMES = (
    "return_30m_atr_adjusted",
    "price_acceleration_30m",
    "price_acceleration_1h",
    "relative_strength_1h",
    "relative_strength_acceleration_1h",
    "turnover_growth_recent1h_vs_prior3h",
    "turnover_acceleration_30m",
    "higher_low_strength_atr",
    "pullback_recovery_ratio",
    "btc_price_acceleration_1h",
    "market_breadth_change",
    "market_liquidity_state",
)
POST_STRUCTURE_MATERIAL_NAMES = ("target_path_consumed_ratio",)

TIMEFRAME_ROLE_CONTRACT_ID = "PRE_STRUCTURE_1H_4H_24H"
TIMEFRAME_ROLE_FORMULA_ID = "OFFICIAL_1H_4H_24H_V13_ROLE_STAGE_DIRECTION"
PRIOR_TIMEFRAME_ROLE_FORMULA_ID = "OFFICIAL_1H_4H_24H_V12_ANTI_CHASE_RECOVERY_TRANSITION"
TIMEFRAME_ROLE_AXES = ("1h_timing", "4h_structure", "24h_context")


MATERIAL_ROLE_CONTRACT = {
    "return_30m_atr_adjusted": {
        "role": "ENTRY_POSITION",
        "value_kind": "LEVEL",
        "meaning": "CURRENT_30M_MOVE_LOCATION_ONLY",
        "positive_level_is_automatic_up": False,
    },
    "price_acceleration_30m": {
        "role": "ENTRY_TRANSITION",
        "value_kind": "CHANGE",
        "meaning": "CURRENT_30M_RETURN_MINUS_PRIOR_30M_RETURN",
        "positive_level_is_automatic_up": False,
    },
    "price_acceleration_1h": {
        "role": "TIMING_TRANSITION",
        "value_kind": "CHANGE",
        "meaning": "CURRENT_1H_RETURN_MINUS_PRIOR_1H_RETURN",
        "positive_level_is_automatic_up": False,
    },
    "relative_strength_1h": {
        "role": "TIMING_POSITION",
        "value_kind": "LEVEL",
        "meaning": "CURRENT_COIN_MINUS_BTC_RELATIVE_POSITION",
        "positive_level_is_automatic_up": False,
    },
    "relative_strength_acceleration_1h": {
        "role": "TIMING_TRANSITION",
        "value_kind": "CHANGE",
        "meaning": "CURRENT_RELATIVE_STRENGTH_MINUS_PRIOR_RELATIVE_STRENGTH",
        "positive_level_is_automatic_up": False,
    },
    "turnover_growth_recent1h_vs_prior3h": {
        "role": "FLOW_POSITION",
        "value_kind": "CONTEXTUAL_LEVEL",
        "meaning": "TURNOVER_EXPANSION_REQUIRES_PRICE_DIRECTION_CONTEXT",
        "positive_level_is_automatic_up": False,
    },
    "turnover_acceleration_30m": {
        "role": "FLOW_TRANSITION",
        "value_kind": "CONTEXTUAL_CHANGE",
        "meaning": "TURNOVER_CHANGE_REQUIRES_PRICE_DIRECTION_CONTEXT",
        "positive_level_is_automatic_up": False,
    },
    "higher_low_strength_atr": {
        "role": "STRUCTURE",
        "value_kind": "CONFIRMED_STRUCTURE",
        "meaning": "LATEST_CONFIRMED_LOW_VS_PRIOR_CONFIRMED_LOW",
        "positive_level_is_automatic_up": False,
    },
    "pullback_recovery_ratio": {
        "role": "STRUCTURE_LOCATION",
        "value_kind": "POSITION",
        "meaning": "POSITION_INSIDE_CONFIRMED_PRE_LOW_HIGH_RANGE",
        "positive_level_is_automatic_up": False,
    },
    "btc_price_acceleration_1h": {
        "role": "ENVIRONMENT_TRANSITION",
        "value_kind": "CHANGE",
        "meaning": "BTC_1H_RETURN_CHANGE_CONTEXT_ONLY",
        "positive_level_is_automatic_up": False,
    },
    "market_breadth_change": {
        "role": "ENVIRONMENT_TRANSITION",
        "value_kind": "OWNER_LEVEL",
        "meaning": "MARKET_BREADTH_CONTEXT_ONLY",
        "positive_level_is_automatic_up": False,
    },
    "market_liquidity_state": {
        "role": "ENVIRONMENT",
        "value_kind": "CATEGORICAL",
        "meaning": "MARKET_LIQUIDITY_AND_RISK_CONTEXT_ONLY",
        "positive_level_is_automatic_up": False,
    },
}


def _num(value: Any, default: Optional[float] = None) -> Optional[float]:
    try:
        if value is None or isinstance(value, bool):
            return default
        out = float(value)
        return out if math.isfinite(out) else default
    except Exception:
        return default

def _clip(value: float, low: float, high: float) -> float:
    return max(low, min(high, float(value)))

def _median(values: Iterable[float], default: float = 0.0) -> float:
    vals = [float(x) for x in values if _num(x) is not None]
    return float(statistics.median(vals)) if vals else float(default)

def _ema(values: List[float], period: int) -> Optional[float]:
    clean = [float(x) for x in values if _num(x) is not None]
    if len(clean) < max(2, period):
        return None
    alpha = 2.0 / (float(period) + 1.0)
    value = sum(clean[:period]) / float(period)
    for item in clean[period:]:
        value = alpha * item + (1.0 - alpha) * value
    return value

def _atr(rows: List[Dict[str, float]], period: int = 14) -> float:
    if len(rows) < 2:
        return 0.0
    trs: List[float] = []
    prev: Optional[float] = None
    for row in rows[-max(period * 4, 48):]:
        high = float(row.get("h") or 0.0)
        low = float(row.get("l") or 0.0)
        close = float(row.get("c") or 0.0)
        if min(high, low, close) <= 0:
            continue
        tr = high - low if prev is None else max(high - low, abs(high - prev), abs(low - prev))
        trs.append(max(0.0, tr))
        prev = close
    if not trs:
        return 0.0
    seed = min(period, len(trs))
    value = sum(trs[:seed]) / seed
    for tr in trs[seed:]:
        value = ((period - 1.0) * value + tr) / period
    return max(0.0, value)

def _pivots(rows: List[Dict[str, float]], side: str, window: int) -> List[Dict[str, Any]]:
    out: List[Dict[str, Any]] = []
    if len(rows) < window * 2 + 3:
        return out
    for idx in range(window, len(rows) - window):
        row = rows[idx]
        value = float(row["l"] if side == "low" else row["h"])
        peers = [float(rows[j]["l"] if side == "low" else rows[j]["h"]) for j in range(idx - window, idx + window + 1) if j != idx]
        confirmed = value < min(peers) if side == "low" else value > max(peers)
        if confirmed:
            out.append({"price": value, "ts": float(row["ts"]), "index": idx, "side": side})
    return out

def _cluster_levels(levels: List[Dict[str, Any]], *, atr_ref: float, current: float) -> List[Dict[str, Any]]:
    clean = [dict(x) for x in levels if (_num(x.get("price"), 0.0) or 0.0) > 0]
    clean.sort(key=lambda x: float(x["price"]))
    groups: List[List[Dict[str, Any]]] = []
    tolerance = max(atr_ref * 0.22, current * 0.0012)
    for item in clean:
        price = float(item["price"])
        if groups:
            center = sum(float(x["price"]) * float(x.get("weight") or 1.0) for x in groups[-1]) / max(1e-12, sum(float(x.get("weight") or 1.0) for x in groups[-1]))
            if abs(price - center) <= tolerance:
                groups[-1].append(item)
                continue
        groups.append([item])
    out: List[Dict[str, Any]] = []
    for group in groups:
        weight_sum = sum(float(x.get("weight") or 1.0) for x in group)
        center = sum(float(x["price"]) * float(x.get("weight") or 1.0) for x in group) / max(weight_sum, 1e-12)
        out.append({
            "price": center,
            "low": min(float(x["price"]) for x in group) - tolerance * 0.35,
            "high": max(float(x["price"]) for x in group) + tolerance * 0.35,
            "score": weight_sum + min(3.0, len({str(x.get("tf")) for x in group})) * 0.5,
            "source_count": len(group),
            "timeframes": sorted({str(x.get("tf")) for x in group}),
            "last_source_ts": max(float(x.get("ts") or 0.0) for x in group),
        })
    return out

def _level_candidates(frames: Dict[str, List[Dict[str, float]]], tfs: Tuple[str, ...], side: str) -> List[Dict[str, Any]]:
    levels: List[Dict[str, Any]] = []
    for tf in tfs:
        rows = frames.get(tf) or []
        window = 2 if tf in {"m5", "m15"} else 3
        for item in _pivots(rows[-120:], "low" if side == "support" else "high", window):
            item["tf"] = tf
            item["weight"] = TF_WEIGHT.get(tf, 1.0)
            levels.append(item)
    return levels

def _trend_axis(rows: List[Dict[str, float]]) -> Optional[float]:
    closes = [float(r["c"]) for r in rows if float(r.get("c") or 0.0) > 0]
    if len(closes) < 24:
        return None
    fast = _ema(closes, 8)
    slow = _ema(closes, 21)
    prior_fast = _ema(closes[:-3], 8) if len(closes) >= 27 else None
    if fast is None or slow is None or prior_fast is None or slow <= 0:
        return None
    spread = (fast - slow) / slow * 100.0
    slope = (fast - prior_fast) / max(abs(prior_fast), 1e-12) * 100.0
    return _clip(spread * 2.8 + slope * 5.0, -1.0, 1.0)

def _row_price(row: Dict[str, Any]) -> Optional[float]:
    for obj in (row, row.get("raw") if isinstance(row.get("raw"), dict) else {}, row.get("entry_context") if isinstance(row.get("entry_context"), dict) else {}):
        if not isinstance(obj, dict):
            continue
        for key in ("current_price", "trade_price", "price", "last_price", "close", "entry_price"):
            value = _num(obj.get(key))
            if value is not None and value > 0:
                return value
    return None

def _nested(row: Dict[str, Any], *keys: str) -> Dict[str, Any]:
    for key in keys:
        value = row.get(key)
        if isinstance(value, dict):
            return value
    return {}

def _plan_hash(payload: Dict[str, Any]) -> str:
    raw = json.dumps(payload, ensure_ascii=False, sort_keys=True, separators=(",", ":")).encode("utf-8")
    return hashlib.sha256(raw).hexdigest()[:20]

def _return_pct(rows: List[Dict[str, float]], bars: int, end_offset: int = 0) -> Optional[float]:
    if bars <= 0 or len(rows) < bars + 1 + end_offset:
        return None
    end_index = len(rows) - 1 - end_offset
    start_index = end_index - bars
    start = _num(rows[start_index].get("c"))
    end = _num(rows[end_index].get("c"))
    if start is None or end is None or start <= 0:
        return None
    return (end / start - 1.0) * 100.0


def _bar_turnover(row: Dict[str, float]) -> Optional[float]:
    close = _num(row.get("c"))
    volume = _num(row.get("v"))
    if close is None or volume is None or close <= 0 or volume < 0:
        return None
    return close * volume


def _avg_turnover(rows: List[Dict[str, float]]) -> Optional[float]:
    values = [_bar_turnover(row) for row in rows]
    ready = [float(value) for value in values if value is not None]
    return sum(ready) / len(ready) if ready else None



def _frame_state(rows: List[Dict[str, float]], need: int, nowv: float, frame_sec: float, truth: Optional[Dict[str,Any]] = None) -> Dict[str, Any]:
    count=len(rows)
    latest=_num(rows[-1].get('ts')) if rows else None
    latest_close=latest+frame_sec if latest is not None else None
    age=max(0.0,nowv-latest_close) if latest_close is not None else None
    truth=truth if isinstance(truth,dict) else {}
    owner_state=str(truth.get('data_state') or truth.get('state') or '').upper()
    owner_reason=str(truth.get('data_reason') or truth.get('reason') or '')
    if owner_state=='SOURCE_MISSING':
        state='SOURCE_MISSING'; reason=owner_reason or 'SOURCE_MISSING'
    elif owner_state=='MISSING':
        state='MISSING'; reason=owner_reason or 'SOURCE_HAS_NO_USABLE_COMPLETED_BAR'
    elif count<need:
        state='MISSING'; reason='INSUFFICIENT_COMPLETED_BARS'
    elif owner_state=='STALE' or (not owner_state and age is not None and age>frame_sec*2.25):
        state='STALE'; reason=owner_reason or 'REFRESH_DUE'
    else:
        state='READY'; reason=None
    return {
        'state':state,'owner_data_state':owner_state or None,'owner_data_reason':owner_reason or None,
        'count':count,'required':need,'last_source_bar_ts':latest,'last_completed_ts':latest_close,
        'age_sec':round(age,3) if age is not None else None,'reason':reason,
        'attempted_ts':_num(truth.get('attempted_ts')),'api_success_ts':_num(truth.get('api_success_ts')),
        'completed_update_ts':_num(truth.get('completed_update_ts')),'completed_bar_changed':truth.get('completed_bar_changed') is True,
        'fetch_state':truth.get('fetch_state')
    }


def _material(name: str, value: Any, source_owner: str, source: str, state: str, raw: Any = None) -> Dict[str, Any]:
    numeric=_num(value)
    source_state=str(state or 'MISSING').upper()
    if source_state not in {'READY','STALE','MISSING','SOURCE_MISSING'}:
        source_state='MISSING'
    public_value=round(numeric,8) if numeric is not None else value if isinstance(value,(str,dict,list)) else None
    observed_value_available=public_value is not None
    if source_state=='READY' and observed_value_available:
        material_state='READY'; value_state='READY'; missing_reason=None
    elif source_state=='STALE':
        material_state='STALE'; value_state='STALE'; missing_reason='SOURCE_STALE'
    elif source_state=='SOURCE_MISSING':
        material_state='SOURCE_MISSING'; value_state='MISSING'; missing_reason='SOURCE_MISSING'
    elif source_state=='MISSING':
        material_state='MISSING'; value_state='MISSING'; missing_reason='SOURCE_MISSING'
    else:
        material_state='MISSING'; value_state='MISSING'; missing_reason='DERIVED_VALUE_NOT_AVAILABLE'
    return {
        'name':name,'value':public_value,'raw':raw,'owner':'strategy_v2_core','calculation_owner':'strategy_v2_core',
        'source_owner':source_owner,'source':source,'state':material_state,'source_state':source_state,'value_state':value_state,
        'observed_value_available':observed_value_available,'missing_reason':missing_reason,
        'source_last_completed_ts':None,'source_updated_ts':None,'source_age_sec':None,'source_attempted_ts':None,'source_success_ts':None,
        'source_completed_update_ts':None,'source_completed_bar_changed':None,'source_fetch_states':[],
        'used_as_gate':False,'zero_filled':False
    }


def _source_state(*states: str) -> str:
    values=[str(value or 'MISSING').upper() for value in states]
    if any(value=='SOURCE_MISSING' for value in values): return 'SOURCE_MISSING'
    if any(value=='MISSING' for value in values): return 'MISSING'
    if any(value=='STALE' for value in values): return 'STALE'
    return 'READY'


def _latest_confirmed_swing_low(rows: List[Dict[str, float]]) -> Dict[str, Any]:
    lows = _pivots(rows[-80:], "low", 2)
    if not lows:
        return {"state": "MISSING", "price": None, "ts": None}
    item = lows[-1]
    return {"state": "READY", "price": _num(item.get("price")), "ts": _num(item.get("ts"))}


def _market_context(row: Dict[str, Any]) -> Dict[str, Any]:
    for key in ("global_market_context_v2130", "market_context_v2130"):
        value = row.get(key)
        if isinstance(value, dict):
            return value
    return {}




def _owner_meta(row: Dict[str, Any], owner_key: str, nowv: float) -> Dict[str, Any]:
    root = row.get("prediction_owner_meta_v2155") if isinstance(row.get("prediction_owner_meta_v2155"), dict) else {}
    item = root.get(owner_key) if isinstance(root.get(owner_key), dict) else {}
    updated = _num(item.get("updated_ts"))
    attempted = _num(item.get("attempted_ts"), _num(item.get("last_attempt_ts")))
    success = _num(item.get("success_ts"), _num(item.get("last_success_ts"), updated))
    return {
        "owner": item.get("owner"),
        "updated_ts": updated,
        "attempted_ts": attempted,
        "success_ts": success,
        "age_sec": round(max(0.0, nowv - updated), 3) if updated is not None else None,
    }


def _completed_close_ts(row: Dict[str, float], sec: float) -> Optional[float]:
    ts = _num(row.get("ts"))
    return ts + sec if ts is not None else None


def _acceleration_series(rows: List[Dict[str, float]], mode: str) -> List[Dict[str, Any]]:
    out: List[Dict[str, Any]] = []
    if mode == "price":
        for idx in range(2, len(rows)):
            p0 = _num(rows[idx - 2].get("c")); p1 = _num(rows[idx - 1].get("c")); p2 = _num(rows[idx].get("c"))
            if p0 is None or p1 is None or p2 is None or min(p0, p1) <= 0:
                continue
            r0 = (p1 / p0 - 1.0) * 100.0
            r1 = (p2 / p1 - 1.0) * 100.0
            out.append({"ts": _completed_close_ts(rows[idx], 1800.0), "value": r1 - r0})
    else:
        turns = [_bar_turnover(row) for row in rows]
        for idx in range(1, len(rows)):
            prev = turns[idx - 1]; cur = turns[idx]
            if prev is None or cur is None or prev <= 0:
                continue
            out.append({"ts": _completed_close_ts(rows[idx], 1800.0), "value": ((cur / prev) - 1.0) * 100.0})
    return out


def _latest_positive_transition(series: List[Dict[str, Any]]) -> Optional[float]:
    latest: Optional[float] = None
    previous: Optional[float] = None
    for item in series:
        value = _num(item.get("value"))
        ts = _num(item.get("ts"))
        if value is None or ts is None:
            continue
        if value > 0 and (previous is None or previous <= 0):
            latest = ts
        previous = value
    return latest


def _price_volume_sequence(m30: List[Dict[str, float]]) -> Dict[str, Any]:
    price_ts = _latest_positive_transition(_acceleration_series(m30[-12:], "price"))
    volume_ts = _latest_positive_transition(_acceleration_series(m30[-12:], "turnover"))
    if price_ts is None or volume_ts is None:
        state = "UNKNOWN"
        reason = "POSITIVE_TRANSITION_TIMESTAMP_MISSING"
    elif abs(price_ts - volume_ts) < 1.0:
        state = "SAME_BAR"
        reason = "PRICE_AND_TURNOVER_ACCELERATION_TURNED_POSITIVE_ON_SAME_COMPLETED_30M_BAR"
    elif volume_ts < price_ts:
        state = "VOLUME_LEADS"
        reason = "TURNOVER_ACCELERATION_TURNED_POSITIVE_BEFORE_PRICE_ACCELERATION"
    else:
        state = "PRICE_LEADS"
        reason = "PRICE_ACCELERATION_TURNED_POSITIVE_BEFORE_TURNOVER_ACCELERATION"
    return {
        "state": state,
        "price_positive_transition_ts": price_ts,
        "turnover_positive_transition_ts": volume_ts,
        "reason": reason,
        "completed_candles_only": True,
        "used_as_gate": False,
    }


def _explanation_tags(
    *, price_accel: Optional[float], prior_price_accel: Optional[float],
    rs_accel: Optional[float], prior_rs_accel: Optional[float],
    turnover_accel: Optional[float], prior_turnover_accel: Optional[float],
    higher_low: Optional[float], prior_return_30m: Optional[float],
    recovery: Optional[float], prior_recovery: Optional[float],
    pre_signal_rise: Optional[float], episode_bar_count: Optional[int],
) -> Dict[str, Any]:
    evidence: Dict[str, Dict[str, Any]] = {}
    beginning = bool(
        price_accel is not None and price_accel > 0
        and rs_accel is not None and rs_accel > 0
        and ((prior_price_accel is not None and prior_price_accel <= 0) or (prior_rs_accel is not None and prior_rs_accel <= 0))
    )
    evidence["BEGINNING"] = {
        "matched": beginning,
        "reason": "PRICE_AND_RELATIVE_STRENGTH_ACCELERATION_POSITIVE_AFTER_PRIOR_NONPOSITIVE_AXIS",
        "values": {"price_acceleration_30m": price_accel, "prior_price_acceleration_30m": prior_price_accel, "relative_strength_acceleration_1h": rs_accel, "prior_relative_strength_acceleration_1h": prior_rs_accel},
    }
    restart = bool(
        higher_low is not None and higher_low > 0
        and prior_return_30m is not None and prior_return_30m <= 0
        and price_accel is not None and price_accel > 0
        and recovery is not None and prior_recovery is not None and recovery > prior_recovery
    )
    evidence["RESTART"] = {
        "matched": restart,
        "reason": "HIGHER_LOW_WITH_PULLBACK_THEN_PRICE_ACCELERATION_AND_RECOVERY_REEXPANSION",
        "values": {"higher_low_strength_atr": higher_low, "prior_30m_return_pct": prior_return_30m, "price_acceleration_30m": price_accel, "pullback_recovery_ratio": recovery, "prior_pullback_recovery_ratio": prior_recovery},
    }
    chase = bool(
        pre_signal_rise is not None and pre_signal_rise > 0
        and episode_bar_count is not None and episode_bar_count >= 2
    )
    evidence["CHASE"] = {
        "matched": chase,
        "reason": "PRE_SIGNAL_RISE_ALREADY_IN_PROGRESS_BEFORE_STRUCTURE",
        "values": {"pre_signal_rise_pct": pre_signal_rise, "episode_completed_30m_bars": episode_bar_count},
    }
    weakened = [
        price_accel is not None and prior_price_accel is not None and price_accel < prior_price_accel,
        rs_accel is not None and prior_rs_accel is not None and rs_accel < prior_rs_accel,
        turnover_accel is not None and prior_turnover_accel is not None and turnover_accel < prior_turnover_accel,
    ]
    exhaustion = sum(bool(item) for item in weakened) >= 2 and bool(prior_price_accel is not None and prior_price_accel > 0)
    evidence["EXHAUSTION"] = {
        "matched": exhaustion,
        "reason": "AT_LEAST_TWO_ACCELERATION_AXES_WEAKEN_AFTER_PRIOR_POSITIVE_PRICE_ACCELERATION",
        "values": {"price_acceleration_30m": price_accel, "prior_price_acceleration_30m": prior_price_accel, "relative_strength_acceleration_1h": rs_accel, "prior_relative_strength_acceleration_1h": prior_rs_accel, "turnover_acceleration_30m": turnover_accel, "prior_turnover_acceleration_30m": prior_turnover_accel},
    }
    tags = [name for name, item in evidence.items() if item.get("matched")]
    return {
        "tags": tags,
        "labels_ko": [{"BEGINNING": "초입", "RESTART": "재출발", "CHASE": "추격", "EXHAUSTION": "소진"}[name] for name in tags],
        "evidence": evidence,
        "overlap_allowed": True,
        "no_tag_allowed": True,
        "used_as_gate": False,
        "used_as_score": False,
    }



def _model_value(value: Any) -> Tuple[str,Any]:
    numeric=_num(value)
    if numeric is not None: return 'numeric',float(numeric)
    if isinstance(value,dict):
        risk=str(value.get('risk_state') or 'UNKNOWN'); context=str(value.get('context_state') or 'UNKNOWN'); concentration=_num(value.get('turnover_concentration_top10_pct'))
        band='UNKNOWN' if concentration is None else 'HIGH' if concentration>=65 else 'MID' if concentration>=40 else 'LOW'
        return 'categorical',f'RISK_{risk}|CONTEXT_{context}|CONCENTRATION_{band}'
    if value is None: return 'missing',None
    return 'categorical',str(value)


def _model_bucket(value: float, edges: List[float]) -> str:
    if len(edges)<3: return 'ALL'
    if value<=edges[0]: return 'Q1'
    if value<=edges[1]: return 'Q2'
    if value<=edges[2]: return 'Q3'
    return 'Q4'


def _logit(probability: float) -> float:
    p=max(0.01,min(0.99,float(probability)))
    return math.log(p/(1.0-p))


def _logistic(value: float) -> float:
    if value>=0: return 1.0/(1.0+math.exp(-min(60.0,value)))
    exp=math.exp(max(-60.0,value)); return exp/(1.0+exp)


def _score_target(target: Dict[str,Any], payload: Dict[str,Any]) -> Dict[str,Any]:
    target=target if isinstance(target,dict) else {}
    base_pct=_num(target.get('base_probability_pct'),50.0) or 50.0
    base=max(0.01,min(0.99,base_pct/100.0))
    materials=payload.get('materials') if isinstance(payload.get('materials'),dict) else {}
    feature_models=target.get('feature_models') if isinstance(target.get('feature_models'),dict) else {}
    evidence=[]
    for name,model in feature_models.items():
        item=materials.get(name) if isinstance(materials.get(name),dict) else {}
        # Only the Candle/owner READY truth is eligible. Old numeric values from
        # STALE/MISSING sources remain visible for audit but never enter prediction.
        if str(item.get('state') or '')!='READY' or str(item.get('source_state') or '')!='READY' or item.get('value') is None:
            continue
        kind,value=_model_value(item.get('value'))
        buckets=model.get('buckets') if isinstance(model.get('buckets'),dict) else {}
        bucket=None
        if kind=='numeric' and str(model.get('kind'))=='numeric':
            bucket=_model_bucket(float(value),[float(x) for x in (model.get('edges') or [])])
        elif kind=='categorical':
            bucket=str(value)
        stats=buckets.get(bucket) if bucket and isinstance(buckets.get(bucket),dict) else None
        if not stats: continue
        probability=_num(stats.get('probability_pct')); sample=_num(stats.get('effective_sample'),0.0) or 0.0
        if probability is None: continue
        weight=min(1.0,sample/20.0)
        delta=_logit(probability/100.0)-_logit(base)
        evidence.append((weight,delta,f'{name}:{bucket}'))
    tags=[str(tag) for tag in (payload.get('explanation_tags') or [])]
    for tag in tags:
        stats=(target.get('tag_models') or {}).get(tag) if isinstance(target.get('tag_models'),dict) else None
        if isinstance(stats,dict) and _num(stats.get('probability_pct')) is not None:
            sample=_num(stats.get('effective_sample'),0.0) or 0.0
            evidence.append((min(0.65,sample/30.0),_logit(float(stats['probability_pct'])/100.0)-_logit(base),f'TAG:{tag}'))
    combo='+'.join(sorted(tags)) or 'NONE'
    stats=(target.get('tag_combination_models') or {}).get(combo) if isinstance(target.get('tag_combination_models'),dict) else None
    if isinstance(stats,dict) and _num(stats.get('probability_pct')) is not None:
        sample=_num(stats.get('effective_sample'),0.0) or 0.0
        evidence.append((min(0.8,sample/20.0),_logit(float(stats['probability_pct'])/100.0)-_logit(base),f'TAG_COMBO:{combo}'))
    sequence=str((payload.get('price_volume_sequence') or {}).get('state') or 'UNKNOWN') if isinstance(payload.get('price_volume_sequence'),dict) else 'UNKNOWN'
    stats=(target.get('sequence_models') or {}).get(sequence) if isinstance(target.get('sequence_models'),dict) else None
    if isinstance(stats,dict) and _num(stats.get('probability_pct')) is not None:
        sample=_num(stats.get('effective_sample'),0.0) or 0.0
        evidence.append((min(0.65,sample/30.0),_logit(float(stats['probability_pct'])/100.0)-_logit(base),f'SEQUENCE:{sequence}'))
    # Neutral evidence used to dilute every candidate back to the market base.
    # Keep the strongest current matches only; each bucket is already posterior-
    # shrunk in Review, so no second blanket shrink is applied here.
    ranked=sorted(evidence,key=lambda item:abs(item[0]*item[1]),reverse=True)
    selected=ranked[:6]
    weight_sum=sum(weight for weight,_,_ in selected)
    adjustment=(sum(weight*delta for weight,delta,_ in selected)/weight_sum) if weight_sum>0 else 0.0
    probability=_logistic(_logit(base)+adjustment)*100.0
    return {
        'probability_pct':round(max(1.0,min(99.0,probability)),3),
        'evidence_count':len(selected),'available_evidence_count':len(evidence),'evidence_weight':round(weight_sum,6),
        'evidence_keys':[key for _,_,key in selected],
        'target_sample_count':int(target.get('raw_sample_count') or 0),
        'target_effective_sample':_num(target.get('effective_sample'),0.0) or 0.0,
        'base_probability_pct':round(base*100.0,3),
        'target_basis':target.get('target_basis')
    }




def _raw_material_probability(payload: Dict[str,Any], horizon: str) -> Dict[str,Any]:
    """Immediate prediction from the current 12 upstream materials.

    Review outcomes calibrate this later; lack of completed Review samples must not
    stop the upstream selector or force every coin to 50/HOLD. Missing materials
    are excluded, never zero-filled.
    """
    materials=payload.get('materials') if isinstance(payload.get('materials'),dict) else {}
    # Positive means stronger forward rise evidence. Scales only normalize unlike
    # units into comparable bounded signals; they are not candidate thresholds.
    scales={
        'return_30m_atr_adjusted':1.0, 'price_acceleration_30m':0.8,
        'price_acceleration_1h':1.2, 'relative_strength_1h':1.5,
        'relative_strength_acceleration_1h':1.0,
        'turnover_growth_recent1h_vs_prior3h':35.0,
        'turnover_acceleration_30m':35.0, 'higher_low_strength_atr':0.8,
        'pullback_recovery_ratio':0.35, 'btc_price_acceleration_1h':1.0,
        'market_breadth_change':8.0,
    }
    weights_3h={
        'return_30m_atr_adjusted':1.20,'price_acceleration_30m':1.35,
        'price_acceleration_1h':0.90,'relative_strength_1h':1.00,
        'relative_strength_acceleration_1h':1.15,
        'turnover_growth_recent1h_vs_prior3h':0.80,
        'turnover_acceleration_30m':1.10,'higher_low_strength_atr':0.95,
        'pullback_recovery_ratio':0.75,'btc_price_acceleration_1h':0.65,
        'market_breadth_change':0.70,
    }
    weights_6h={
        'return_30m_atr_adjusted':0.75,'price_acceleration_30m':0.70,
        'price_acceleration_1h':1.25,'relative_strength_1h':1.30,
        'relative_strength_acceleration_1h':1.15,
        'turnover_growth_recent1h_vs_prior3h':1.05,
        'turnover_acceleration_30m':0.75,'higher_low_strength_atr':1.10,
        'pullback_recovery_ratio':0.90,'btc_price_acceleration_1h':0.85,
        'market_breadth_change':0.90,
    }
    weights=weights_3h if horizon=='3h' else weights_6h
    terms=[]
    for name,weight in weights.items():
        item=materials.get(name) if isinstance(materials.get(name),dict) else {}
        if str(item.get('state') or '')!='READY' or str(item.get('source_state') or '')!='READY':
            continue
        value=_num(item.get('value'))
        if value is None:
            continue
        signal=math.tanh(value/max(1e-9,scales[name]))
        terms.append((weight,signal,name))
    # Liquidity is categorical and remains owned by Market. Read only its sealed
    # value; do not recreate market calculations here.
    liq=materials.get('market_liquidity_state') if isinstance(materials.get('market_liquidity_state'),dict) else {}
    if str(liq.get('state') or '')=='READY' and str(liq.get('source_state') or '')=='READY':
        value=liq.get('value')
        if isinstance(value,dict):
            risk=str(value.get('risk_state') or '').upper()
            context=str(value.get('context_state') or '').upper()
            signal=0.0
            if risk in {'RISK_OFF','HIGH_RISK','DEFENSIVE'}: signal-=0.65
            elif risk in {'RISK_ON','LOW_RISK'}: signal+=0.45
            if context in {'BULL','UP','RISK_ON'}: signal+=0.30
            elif context in {'BEAR','DOWN','RISK_OFF'}: signal-=0.30
            terms.append((0.75,max(-1.0,min(1.0,signal)),'market_liquidity_state'))
    weight_sum=sum(weight for weight,_,_ in terms)
    raw=(sum(weight*signal for weight,signal,_ in terms)/weight_sum) if weight_sum>0 else 0.0
    probability=_logistic(raw*1.65)*100.0
    return {
        'probability_pct':round(max(1.0,min(99.0,probability)),3),
        'evidence_count':len(terms),'evidence_weight':round(weight_sum,6),
        'evidence_keys':[name for _,_,name in terms],
        'raw_material_score':round(raw,8),'basis':'CURRENT_12_MATERIAL_RAW_DIRECTION',
    }


def _raw_risk_probability(payload: Dict[str,Any], risk_name: str) -> Dict[str,Any]:
    materials=payload.get('materials') if isinstance(payload.get('materials'),dict) else {}
    def ready_num(name):
        item=materials.get(name) if isinstance(materials.get(name),dict) else {}
        if str(item.get('state') or '')!='READY' or str(item.get('source_state') or '')!='READY': return None
        return _num(item.get('value'))
    recovery=ready_num('pullback_recovery_ratio')
    ret=ready_num('return_30m_atr_adjusted')
    accel=ready_num('price_acceleration_30m')
    if risk_name=='giveback_risk':
        parts=[]
        if recovery is not None: parts.append(math.tanh((recovery-0.72)/0.22))
        if ret is not None: parts.append(math.tanh((ret-0.8)/0.8))
        if accel is not None: parts.append(-math.tanh(accel/0.8))
    else:
        pre=_num(payload.get('pre_signal_rise_pct'))
        parts=[]
        if pre is not None: parts.append(math.tanh((pre-1.0)/1.2))
        if recovery is not None: parts.append(math.tanh((recovery-0.78)/0.18))
        if ret is not None: parts.append(math.tanh((ret-1.0)/0.8))
    raw=sum(parts)/len(parts) if parts else 0.0
    return {'probability_pct':round(_logistic(raw*1.4)*100.0,3),'evidence_count':len(parts),'evidence_weight':float(len(parts)),'evidence_keys':[], 'raw_material_score':round(raw,8),'basis':'CURRENT_MATERIAL_PATH_RISK'}


def _role_frame_state(rows: List[Dict[str,float]], minimum: int, nowv: float, interval_sec: float, truth: Dict[str,Any], source_mode: str) -> Dict[str,Any]:
    if source_mode == 'HISTORICAL_COMPLETED':
        state = 'READY' if len(rows) >= minimum else 'MISSING'
        last_ts = _num(rows[-1].get('ts')) if rows else None
        return {'state':state,'last_completed_ts':(last_ts + interval_sec if last_ts is not None else None),'age_sec':None,'reason':None if state=='READY' else 'HISTORICAL_COMPLETED_ROWS_MISSING','source_mode':source_mode}
    return _frame_state(rows, minimum, nowv, interval_sec, truth)


def _latest_swing_pair(rows: List[Dict[str,float]], side: str, window: int=1) -> Tuple[Optional[float],Optional[float]]:
    pts=_pivots(rows,side,window)
    if len(pts)<2:
        return None,None
    return _num(pts[-2].get('price')),_num(pts[-1].get('price'))


def _confirmed_pullback_snapshot(rows: List[Dict[str,float]], current: Optional[float], window: int=1) -> Dict[str,Any]:
    """Return the latest confirmed pullback range without future-high leakage.

    The high must be confirmed before the latest confirmed low.  Values above 1
    mean the prior high was reclaimed; they are location, not extra bullish
    strength.  The prior ratio is measured against the same immutable range.
    """
    lows=_pivots(rows,'low',window)
    highs=_pivots(rows,'high',window)
    if not lows:
        return {'state':'MISSING','reason':'CONFIRMED_LOW_NOT_AVAILABLE','low':None,'high':None,'ratio':None,'prior_ratio':None,'delta':None}
    low_item=lows[-1]
    low=_num(low_item.get('price')); low_ts=_num(low_item.get('ts'))
    preceding=[item for item in highs if _num(item.get('ts')) is not None and low_ts is not None and float(item.get('ts')) < low_ts]
    if low is None or low_ts is None or not preceding:
        return {'state':'MISSING','reason':'CONFIRMED_HIGH_BEFORE_LOW_NOT_AVAILABLE','low':low,'high':None,'ratio':None,'prior_ratio':None,'delta':None,'low_ts':low_ts}
    high_item=preceding[-1]
    high=_num(high_item.get('price')); high_ts=_num(high_item.get('ts'))
    if high is None or high<=low:
        return {'state':'MISSING','reason':'CONFIRMED_PULLBACK_RANGE_INVALID','low':low,'high':high,'ratio':None,'prior_ratio':None,'delta':None,'low_ts':low_ts,'high_ts':high_ts}
    ratio=((current-low)/(high-low)) if current is not None else None
    prior_ratio=None
    if len(rows)>=2:
        prior_close=_num(rows[-2].get('c')); prior_ts=_num(rows[-2].get('ts'))
        if prior_close is not None and prior_ts is not None and prior_ts>=low_ts:
            prior_ratio=(prior_close-low)/(high-low)
    delta=(ratio-prior_ratio) if ratio is not None and prior_ratio is not None else None
    if ratio is None:
        phase='MISSING'
    elif ratio<0:
        phase='BELOW_CONFIRMED_LOW'
    elif ratio<1:
        phase='RECOVERING' if delta is not None and delta>0 else 'FALLING_BACK' if delta is not None and delta<0 else 'INSIDE_PULLBACK_RANGE'
    else:
        phase='RECLAIMED_WEAKENING' if delta is not None and delta<0 else 'RECLAIMED'
    return {
        'state':'READY','reason':None,'low':low,'high':high,'low_ts':low_ts,'high_ts':high_ts,
        'ratio':ratio,'prior_ratio':prior_ratio,'delta':delta,'phase':phase,
        'ratio_above_one_means_reclaimed_not_more_strength':True,
    }


def _recovery_ratio(rows: List[Dict[str,float]], current: Optional[float], window: int=1) -> Optional[float]:
    return _num(_confirmed_pullback_snapshot(rows,current,window).get('ratio'))


def _turnover_growth(rows: List[Dict[str,float]], recent_count: int=1, prior_count: int=3, end_offset: int=0) -> Optional[float]:
    end=len(rows)-max(0,int(end_offset))
    if end<recent_count+prior_count:
        return None
    view=rows[:end]
    recent=_avg_turnover(view[-recent_count:]); prior=_avg_turnover(view[-(recent_count+prior_count):-recent_count])
    if recent is None or prior is None or prior<=0:
        return None
    return (recent/prior-1.0)*100.0


def _movement_state(delta: Optional[float]) -> str:
    if delta is None:
        return 'UNKNOWN'
    if delta>0:
        return 'IMPROVING'
    if delta<0:
        return 'WEAKENING'
    return 'FLAT'


def _position_state(value: Optional[float]) -> str:
    if value is None:
        return 'UNKNOWN'
    if value>0:
        return 'POSITIVE'
    if value<0:
        return 'NEGATIVE'
    return 'NEUTRAL'


def _flow_state(flow_change: Optional[float], price_change: Optional[float]) -> str:
    if flow_change is None or price_change is None:
        return 'UNKNOWN'
    if flow_change>0 and price_change>0:
        return 'BUYING_EXPANSION'
    if flow_change>0 and price_change<0:
        return 'SELLING_EXPANSION'
    if flow_change<0 and price_change<0:
        return 'PULLBACK_FLOW_CONTRACTION'
    if flow_change<0 and price_change>0:
        return 'RISE_WITH_FLOW_CONTRACTION'
    return 'NEUTRAL'


def _flow_vote(flow_state: str) -> Optional[float]:
    return {
        'BUYING_EXPANSION':1.0,
        'SELLING_EXPANSION':-1.0,
        'PULLBACK_FLOW_CONTRACTION':0.5,
        'RISE_WITH_FLOW_CONTRACTION':-0.5,
        'NEUTRAL':0.0,
    }.get(str(flow_state or '').upper())


def _trend_position(rows: List[Dict[str,float]], period: int, atr_period: int, end_offset: int=0, current_override: Optional[float]=None) -> Optional[float]:
    end=len(rows)-max(0,int(end_offset))
    if end<=0:
        return None
    view=rows[:end]
    closes=[float(x.get('c') or 0) for x in view if _num(x.get('c')) is not None]
    ema=_ema(closes,period)
    atr=_atr(view,atr_period)
    price=_num(current_override) if end_offset==0 and current_override is not None else _num(view[-1].get('c'))
    if price is None or ema is None or atr<=0:
        return None
    return (price-ema)/atr


def _annotate_material_roles(
    material_rows: Dict[str,Dict[str,Any]],
    prior_values: Dict[str,Any],
    movement_values: Dict[str,Any],
    contextual_states: Dict[str,Any],
) -> Dict[str,Any]:
    role_counts=Counter()
    stage_groups={'environment':[],'structure':[],'transition':[],'entry':[]}
    for name,item in material_rows.items():
        contract=dict(MATERIAL_ROLE_CONTRACT.get(name) or {})
        role=str(contract.get('role') or 'UNCLASSIFIED')
        prior=_num(prior_values.get(name))
        movement=_num(movement_values.get(name))
        item['material_role']=role
        item['value_kind']=contract.get('value_kind')
        item['role_meaning']=contract.get('meaning')
        item['prior_value']=round(prior,8) if prior is not None else None
        item['change_from_prior']=round(movement,8) if movement is not None else None
        item['movement_state']=_movement_state(movement)
        item['position_state']=_position_state(_num(item.get('value')))
        item['contextual_state']=contextual_states.get(name)
        item['positive_level_is_automatic_up']=False
        item['used_as_direct_up_level']=False
        item['role_normalized']=True
        role_counts[role]+=1
        if role.startswith('ENVIRONMENT'):
            stage_groups['environment'].append(name)
        elif role.startswith('STRUCTURE'):
            stage_groups['structure'].append(name)
        elif role in {'ENTRY_POSITION','ENTRY_TRANSITION','FLOW_POSITION','FLOW_TRANSITION'}:
            stage_groups['entry'].append(name)
        else:
            stage_groups['transition'].append(name)
    return {
        'schema':'material_role_contract','version':'ROLE_STAGE_DIRECTION_V1','role_counts':dict(role_counts),
        'groups':stage_groups,'positive_level_is_automatic_up':False,
        'direction_change_has_priority_over_positive_level':True,
        'owner':'strategy_v2_core','reader_recalculation':False,
    }


def _axis_probability(terms: List[Tuple[float,Optional[float],str]], *, multiplier: float=1.55) -> Dict[str,Any]:
    used=[(float(w),float(v),str(k)) for w,v,k in terms if v is not None and math.isfinite(float(v))]
    weight=sum(w for w,_,_ in used)
    raw=sum(w*v for w,v,_ in used)/weight if weight>0 else 0.0
    probability=_logistic(raw*multiplier)*100.0
    return {'probability_pct':round(_clip(probability,1.0,99.0),3),'raw_score':round(raw,8),'evidence_count':len(used),'evidence_weight':round(weight,6),'evidence_keys':[k for _,_,k in used]}


def _norm(value: Optional[float], scale: float) -> Optional[float]:
    return math.tanh(float(value)/max(1e-9,float(scale))) if value is not None else None


def _axis_role_vote(terms: List[Tuple[Optional[float],str]]) -> Dict[str,Any]:
    """Equal-vote role evidence.

    Each available official-timeframe signal contributes one vote.  No fixed
    material weight, score cut, or legacy short-path tag is allowed here.
    Probability is display-only around the natural neutral center; decisions use
    the positive/negative vote majority directly.
    """
    used=[(float(v),str(k)) for v,k in terms if v is not None and math.isfinite(float(v))]
    positive=sum(1 for value,_ in used if value>0.0)
    negative=sum(1 for value,_ in used if value<0.0)
    neutral=len(used)-positive-negative
    raw=sum(value for value,_ in used)/len(used) if used else 0.0
    probability=_logistic(raw*1.55)*100.0
    direction='POSITIVE' if positive>negative else 'NEGATIVE' if negative>positive else 'NEUTRAL'
    return {
        'probability_pct':round(_clip(probability,1.0,99.0),3),
        'raw_score':round(raw,8),
        'direction':direction,
        'evidence_count':len(used),
        'positive_evidence_count':positive,
        'negative_evidence_count':negative,
        'neutral_evidence_count':neutral,
        'evidence_keys':[key for _,key in used],
        'weights_applied':False,
        'fixed_score_cut_applied':False,
    }


def _market_signal_from_context(market: Dict[str,Any]) -> Optional[float]:
    if not isinstance(market,dict) or not market:
        return None
    risk=str(market.get('risk_state_v2130') or market.get('risk_state') or '').upper()
    context=str(market.get('state') or market.get('context_state') or '').upper()
    breadth=_num(market.get('breadth_velocity_pct_v2130'),_num(market.get('breadth_change')))
    signal=0.0; used=False
    if risk in {'RISK_OFF','HIGH_RISK','DEFENSIVE'}: signal-=0.45; used=True
    elif risk in {'RISK_ON','LOW_RISK'}: signal+=0.30; used=True
    if context in {'BULL','UP','RISK_ON','CONTEXT_SUPPORTIVE'}: signal+=0.20; used=True
    elif context in {'BEAR','DOWN','RISK_OFF','CONTEXT_DEFENSIVE'}: signal-=0.20; used=True
    if breadth is not None: signal+=0.25*math.tanh(breadth/8.0); used=True
    return _clip(signal,-1.0,1.0) if used else None


def build_timeframe_role_input_from_frames(
    ticker: str,
    frames: Dict[str,List[Dict[str,float]]],
    benchmark_frames: Dict[str,List[Dict[str,float]]],
    market_context: Dict[str,Any],
    nowv: float,
    *,
    current_price: Optional[float]=None,
    frame_truth: Optional[Dict[str,Dict[str,Any]]]=None,
    benchmark_truth: Optional[Dict[str,Dict[str,Any]]]=None,
    source_mode: str='LIVE',
) -> Dict[str,Any]:
    """Build official-timeframe role inputs with position and direction separated.

    24h is environment, 4h is structure/location, 1h is transition timing.
    Positive levels are retained for audit but do not become automatic UP evidence.
    """
    truth=frame_truth if isinstance(frame_truth,dict) else {}
    btruth=benchmark_truth if isinstance(benchmark_truth,dict) else {}
    h1=frames.get('h1') if isinstance(frames.get('h1'),list) else []
    h4=frames.get('h4') if isinstance(frames.get('h4'),list) else []
    d1=frames.get('d1') if isinstance(frames.get('d1'),list) else []
    bh1=benchmark_frames.get('h1') if isinstance(benchmark_frames.get('h1'),list) else []
    bh4=benchmark_frames.get('h4') if isinstance(benchmark_frames.get('h4'),list) else []
    bd1=benchmark_frames.get('d1') if isinstance(benchmark_frames.get('d1'),list) else []
    states={
        'h1':_role_frame_state(h1,12,nowv,3600.0,truth.get('h1') if isinstance(truth.get('h1'),dict) else {},source_mode),
        'h4':_role_frame_state(h4,8,nowv,14400.0,truth.get('h4') if isinstance(truth.get('h4'),dict) else {},source_mode),
        'd1':_role_frame_state(d1,6,nowv,86400.0,truth.get('d1') if isinstance(truth.get('d1'),dict) else {},source_mode),
        'btc_h1':_role_frame_state(bh1,4,nowv,3600.0,btruth.get('h1') if isinstance(btruth.get('h1'),dict) else {},source_mode),
        'btc_h4':_role_frame_state(bh4,4,nowv,14400.0,btruth.get('h4') if isinstance(btruth.get('h4'),dict) else {},source_mode),
        'btc_d1':_role_frame_state(bd1,4,nowv,86400.0,btruth.get('d1') if isinstance(btruth.get('d1'),dict) else {},source_mode),
    }
    current=_num(current_price)
    if current is None:
        current=_num(h1[-1].get('c')) if h1 else _num(h4[-1].get('c')) if h4 else _num(d1[-1].get('c')) if d1 else None

    # 1h timing: all directional evidence is current versus prior.
    ret1=_return_pct(h1,1); prior1=_return_pct(h1,1,1); priorprior1=_return_pct(h1,1,2)
    accel1=(ret1-prior1) if ret1 is not None and prior1 is not None else None
    prior_accel1=(prior1-priorprior1) if prior1 is not None and priorprior1 is not None else None
    accel_change1=(accel1-prior_accel1) if accel1 is not None and prior_accel1 is not None else None
    btc1=_return_pct(bh1,1); btc_prior1=_return_pct(bh1,1,1); btc_priorprior1=_return_pct(bh1,1,2)
    btc_accel1=(btc1-btc_prior1) if btc1 is not None and btc_prior1 is not None else None
    prior_btc_accel1=(btc_prior1-btc_priorprior1) if btc_prior1 is not None and btc_priorprior1 is not None else None
    rs1=(ret1-btc1) if ret1 is not None and btc1 is not None else None
    prior_rs1=(prior1-btc_prior1) if prior1 is not None and btc_prior1 is not None else None
    rs_change1=(rs1-prior_rs1) if rs1 is not None and prior_rs1 is not None else None
    atr1=_atr(h1,14); low1_prev,low1_last=_latest_swing_pair(h1,'low',1)
    hl1=((low1_last-low1_prev)/max(atr1,1e-12)) if low1_last is not None and low1_prev is not None and atr1>0 else None
    rec1_snapshot=_confirmed_pullback_snapshot(h1,current,1)
    rec1=_num(rec1_snapshot.get('ratio')); prior_rec1=_num(rec1_snapshot.get('prior_ratio')); rec1_delta=_num(rec1_snapshot.get('delta'))
    turn1=_turnover_growth(h1,1,3); prior_turn1=_turnover_growth(h1,1,3,1)
    turn1_delta=(turn1-prior_turn1) if turn1 is not None and prior_turn1 is not None else None
    flow1_state=_flow_state(turn1_delta,accel1)

    # 4h structure: location is separated from recovery direction.
    ret4=_return_pct(h4,1); prior_ret4=_return_pct(h4,1,1); ret4_2=_return_pct(h4,2)
    accel4=(ret4-prior_ret4) if ret4 is not None and prior_ret4 is not None else None
    btc4=_return_pct(bh4,1); prior_btc4=_return_pct(bh4,1,1)
    rs4=(ret4-btc4) if ret4 is not None and btc4 is not None else None
    prior_rs4=(prior_ret4-prior_btc4) if prior_ret4 is not None and prior_btc4 is not None else None
    rs4_delta=(rs4-prior_rs4) if rs4 is not None and prior_rs4 is not None else None
    atr4=_atr(h4,14); atr4_pct=(atr4/current*100.0) if current and current>0 and atr4>0 else None
    trend4=_trend_position(h4,5,14,0,current)
    prior_trend4=_trend_position(h4,5,14,1)
    trend4_delta=(trend4-prior_trend4) if trend4 is not None and prior_trend4 is not None else None
    low4_prev,low4_last=_latest_swing_pair(h4,'low',1)
    hl4=((low4_last-low4_prev)/max(atr4,1e-12)) if low4_last is not None and low4_prev is not None and atr4>0 else None
    rec4_snapshot=_confirmed_pullback_snapshot(h4,current,1)
    rec4=_num(rec4_snapshot.get('ratio')); prior_rec4=_num(rec4_snapshot.get('prior_ratio')); rec4_delta=_num(rec4_snapshot.get('delta'))
    turn4=_turnover_growth(h4,1,3); prior_turn4=_turnover_growth(h4,1,3,1)
    turn4_delta=(turn4-prior_turn4) if turn4 is not None and prior_turn4 is not None else None
    flow4_state=_flow_state(turn4_delta,accel4)
    ret4_atr=(ret4_2/atr4_pct) if ret4_2 is not None and atr4_pct and atr4_pct>0 else None

    # 24h context: environment only, never a direct entry owner.
    retd1=_return_pct(d1,1); prior_retd1=_return_pct(d1,1,1); retd3=_return_pct(d1,3)
    d1_change=(retd1-prior_retd1) if retd1 is not None and prior_retd1 is not None else None
    btcd1=_return_pct(bd1,1); prior_btcd1=_return_pct(bd1,1,1)
    rsd1=(retd1-btcd1) if retd1 is not None and btcd1 is not None else None
    prior_rsd1=(prior_retd1-prior_btcd1) if prior_retd1 is not None and prior_btcd1 is not None else None
    rsd1_delta=(rsd1-prior_rsd1) if rsd1 is not None and prior_rsd1 is not None else None
    atrd=_atr(d1,10)
    trendd=_trend_position(d1,5,10,0,current)
    prior_trendd=_trend_position(d1,5,10,1)
    trendd_delta=(trendd-prior_trendd) if trendd is not None and prior_trendd is not None else None
    ema_d5=_ema([float(x.get('c') or 0) for x in d1 if _num(x.get('c')) is not None],5)
    ema_d10=_ema([float(x.get('c') or 0) for x in d1 if _num(x.get('c')) is not None],10)
    stackd=((ema_d5-ema_d10)/atrd) if ema_d5 is not None and ema_d10 is not None and atrd>0 else None
    atrd_pct=(atrd/current*100.0) if current and current>0 and atrd>0 else None
    ret_d_atr=(retd3/atrd_pct) if retd3 is not None and atrd_pct and atrd_pct>0 else None
    market_signal=_market_signal_from_context(market_context)

    tag_source=market_context.get('_sealed_prediction_payload') if isinstance(market_context,dict) and isinstance(market_context.get('_sealed_prediction_payload'),dict) else {}
    tags=sorted({str(x).upper() for x in (tag_source.get('explanation_tags') or [])})
    sequence_obj=tag_source.get('price_volume_sequence') if isinstance(tag_source.get('price_volume_sequence'),dict) else {}
    sequence=str(sequence_obj.get('state') or 'UNKNOWN').upper()
    price_transition=_num(sequence_obj.get('price_positive_transition_ts'))
    volume_transition=_num(sequence_obj.get('turnover_positive_transition_ts'))
    volume_lead_bars=((price_transition-volume_transition)/1800.0) if price_transition is not None and volume_transition is not None else None
    flow=tag_source.get('existing_flow_inputs') if isinstance(tag_source.get('existing_flow_inputs'),dict) else {}
    buy_ratio=_num(flow.get('buy_ratio')); buy_sustain=_num(flow.get('buy_sustain_1m'))
    buy_ratio_delta=_num(flow.get('buy_ratio_delta')); buy_sustain_delta=_num(flow.get('buy_sustain_delta'))
    sell_pressure=flow.get('sell_pressure') if isinstance(flow.get('sell_pressure'),bool) else None
    pullback_volume_contract=flow.get('pullback_volume_contract') if isinstance(flow.get('pullback_volume_contract'),bool) else None
    reclaim_volume_expand=flow.get('reclaim_volume_expand') if isinstance(flow.get('reclaim_volume_expand'),bool) else None
    market_supportive=flow.get('market_liquidity_supportive') if isinstance(flow.get('market_liquidity_supportive'),bool) else None

    def _group_signal(values):
        clean=[float(v) for v in values if v is not None and math.isfinite(float(v))]
        return sum(clean)/len(clean) if clean else None

    timing_groups={
        'price_direction_change':_group_signal([_norm(accel1,1.2),_norm(accel_change1,1.2)]),
        'relative_strength_change':_group_signal([_norm(rs_change1,1.5)]),
        'recovery_progress':_group_signal([_norm(rec1_delta,0.28)]),
        'flow_direction':_flow_vote(flow1_state),
    }
    structure_groups={
        'structure_location':_group_signal([_norm(hl4,0.8),_norm(trend4,1.0)]),
        'structure_direction_change':_group_signal([_norm(accel4,1.4),_norm(trend4_delta,0.8)]),
        'relative_strength_change':_group_signal([_norm(rs4_delta,2.0)]),
        'recovery_progress':_group_signal([_norm(rec4_delta,0.28)]),
        'flow_direction':_flow_vote(flow4_state),
    }
    context_groups={
        'trend_location':_group_signal([_norm(trendd,1.2),_norm(stackd,0.8)]),
        'environment_direction_change':_group_signal([_norm(d1_change,3.0),_norm(trendd_delta,0.8)]),
        'relative_strength_change':_group_signal([_norm(rsd1_delta,3.0)]),
    }
    timing=_axis_role_vote([(v,k) for k,v in timing_groups.items()])
    structure=_axis_role_vote([(v,k) for k,v in structure_groups.items()])
    context=_axis_role_vote([(v,k) for k,v in context_groups.items()])
    role_states={name:states[name]['state'] for name in ('h1','h4','d1')}
    source_ready=all(role_states[name]=='READY' for name in role_states)
    return {
        'schema':'official_timeframe_role_input','contract_id':TIMEFRAME_ROLE_CONTRACT_ID,'formula_id':TIMEFRAME_ROLE_FORMULA_ID,
        'ticker':ticker,'source_mode':source_mode,'official_completed_frames_only':True,'synthetic_3h_6h_candles_used':False,
        'axis_source_state':role_states,'source_states':states,'source_ready':source_ready,'current_price':current,
        'evidence_groups':{'1h_timing':timing_groups,'4h_structure':structure_groups,'24h_context':context_groups},
        'axes':{
            '1h_timing':{**timing,'role':'ENTRY_TIMING_DIRECTION_CHANGE','inputs':{
                'return_1h_pct':ret1,'prior_return_1h_pct':prior1,'price_acceleration_1h':accel1,'prior_price_acceleration_1h':prior_accel1,'price_acceleration_change_1h':accel_change1,
                'relative_strength_1h':rs1,'prior_relative_strength_1h':prior_rs1,'relative_strength_change_1h':rs_change1,
                'higher_low_strength_atr':hl1,'pullback_recovery_ratio':rec1,'prior_pullback_recovery_ratio':prior_rec1,'pullback_recovery_change':rec1_delta,'pullback_phase':rec1_snapshot.get('phase'),
                'turnover_growth_pct':turn1,'prior_turnover_growth_pct':prior_turn1,'turnover_growth_change':turn1_delta,'flow_state':flow1_state,
                'legacy_short_path_tags_observation_only':tags,'price_volume_sequence':sequence,'volume_lead_bars':volume_lead_bars,
                'buy_ratio':buy_ratio,'buy_sustain_1m':buy_sustain,'buy_ratio_delta':buy_ratio_delta,'buy_sustain_delta':buy_sustain_delta,'sell_pressure':sell_pressure,
                'pullback_volume_contract':pullback_volume_contract,'reclaim_volume_expand':reclaim_volume_expand,'market_liquidity_supportive':market_supportive,
                'orderflow_observations':dict(flow),'orderflow_observations_owner':'orderflow_worker','orderflow_observations_used_in_v13_entry_classification':True,
                'btc_price_acceleration_1h':btc_accel1,'prior_btc_price_acceleration_1h':prior_btc_accel1,'legacy_short_path_used_in_decision':False,
            }},
            '4h_structure':{**structure,'role':'SWING_STRUCTURE_LOCATION_AND_DIRECTION','inputs':{
                'return_4h_pct':ret4,'prior_return_4h_pct':prior_ret4,'price_acceleration_4h':accel4,'return_8h_pct':ret4_2,
                'relative_strength_4h':rs4,'prior_relative_strength_4h':prior_rs4,'relative_strength_change_4h':rs4_delta,
                'higher_low_strength_atr':hl4,'pullback_recovery_ratio':rec4,'prior_pullback_recovery_ratio':prior_rec4,'pullback_recovery_change':rec4_delta,'pullback_phase':rec4_snapshot.get('phase'),
                'close_vs_ema5_atr':trend4,'prior_close_vs_ema5_atr':prior_trend4,'trend_position_change':trend4_delta,
                'turnover_growth_pct':turn4,'prior_turnover_growth_pct':prior_turn4,'turnover_growth_change':turn4_delta,'flow_state':flow4_state,
            }},
            '24h_context':{**context,'role':'LARGE_DIRECTION_ENVIRONMENT_ONLY','inputs':{
                'return_24h_pct':retd1,'prior_return_24h_pct':prior_retd1,'return_24h_change':d1_change,'return_3d_pct':retd3,
                'relative_strength_24h':rsd1,'prior_relative_strength_24h':prior_rsd1,'relative_strength_change_24h':rsd1_delta,
                'close_vs_ema5_atr':trendd,'prior_close_vs_ema5_atr':prior_trendd,'trend_position_change':trendd_delta,'ema5_vs_ema10_atr':stackd,
                'market_signal_observation_only':market_signal,'market_signal_used_in_decision':False,
            }},
        },
        'role_contract':{
            '24h':'ENVIRONMENT_ONLY','4h':'STRUCTURE_AND_LOCATION','1h':'DIRECTION_CHANGE_AND_RESTART','30m_orderflow':'FRESH_ENTRY_CONFIRMATION',
            'positive_level_is_automatic_up':False,'direction_change_has_priority':True,'fixed_probability_cut_used':False,
        },
        'owner_contract':{'raw_frames':'candle_worker:Bithumb official completed h1/h4/d1','derived_role_values':'strategy_v2_core','reader_recalculation_owner':False},
        'auto_buy':False,
    }


def evaluate_timeframe_role_input(role_input: Dict[str,Any]) -> Dict[str,Any]:
    axes=role_input.get('axes') if isinstance(role_input.get('axes'),dict) else {}
    timing=axes.get('1h_timing') if isinstance(axes.get('1h_timing'),dict) else {}
    structure=axes.get('4h_structure') if isinstance(axes.get('4h_structure'),dict) else {}
    context=axes.get('24h_context') if isinstance(axes.get('24h_context'),dict) else {}
    p1=_num(timing.get('probability_pct')); p4=_num(structure.get('probability_pct')); p24=_num(context.get('probability_pct'))
    states=role_input.get('axis_source_state') if isinstance(role_input.get('axis_source_state'),dict) else {}
    missing=[axis for axis in ('h1','h4','d1') if str(states.get(axis) or '')!='READY']
    d1=str(timing.get('direction') or 'NEUTRAL'); d4=str(structure.get('direction') or 'NEUTRAL'); d24=str(context.get('direction') or 'NEUTRAL')
    inputs=timing.get('inputs') if isinstance(timing.get('inputs'),dict) else {}
    s4=structure.get('inputs') if isinstance(structure.get('inputs'),dict) else {}
    c24=context.get('inputs') if isinstance(context.get('inputs'),dict) else {}
    short=role_input.get('sealed_short_timing_materials') if isinstance(role_input.get('sealed_short_timing_materials'),dict) else {}
    groups=role_input.get('evidence_groups') if isinstance(role_input.get('evidence_groups'),dict) else {}
    tags={str(x).upper() for x in (inputs.get('legacy_short_path_tags_observation_only') or [])}
    seq=str(inputs.get('price_volume_sequence') or 'UNKNOWN').upper()
    buy_ratio_delta=_num(inputs.get('buy_ratio_delta')); buy_sustain_delta=_num(inputs.get('buy_sustain_delta'))
    flow_improving=bool((buy_ratio_delta is not None and buy_ratio_delta>0) or (buy_sustain_delta is not None and buy_sustain_delta>0))
    flow_weakening=bool((buy_ratio_delta is not None and buy_ratio_delta<0) or (buy_sustain_delta is not None and buy_sustain_delta<0))
    sell_pressure=inputs.get('sell_pressure') is True
    no_hard_sell=not sell_pressure
    volume_leads=seq=='VOLUME_LEADS'
    beginning='BEGINNING' in tags
    restart='RESTART' in tags

    ret30=_num(short.get('return_30m_atr_adjusted')); accel30=_num(short.get('price_acceleration_30m')); rsacc=_num(short.get('relative_strength_acceleration_1h'))
    r1=_num(inputs.get('return_1h_pct')); a1=_num(inputs.get('price_acceleration_1h')); prior_a1=_num(inputs.get('prior_price_acceleration_1h'))
    rs1=_num(inputs.get('relative_strength_1h')); rs1_delta=_num(inputs.get('relative_strength_change_1h'))
    hl1=_num(inputs.get('higher_low_strength_atr')); rec1=_num(inputs.get('pullback_recovery_ratio')); rec1_delta=_num(inputs.get('pullback_recovery_change'))
    tv1=_num(inputs.get('turnover_growth_pct')); tv1_delta=_num(inputs.get('turnover_growth_change'))
    hl4=_num(s4.get('higher_low_strength_atr')); tr4=_num(s4.get('close_vs_ema5_atr')); tr4_delta=_num(s4.get('trend_position_change'))
    rec4=_num(s4.get('pullback_recovery_ratio')); rec4_delta=_num(s4.get('pullback_recovery_change'))
    tv4=_num(s4.get('turnover_growth_pct')); tv4_delta=_num(s4.get('turnover_growth_change')); a4=_num(s4.get('price_acceleration_4h'))
    trend24=_num(c24.get('close_vs_ema5_atr')); stack24=_num(c24.get('ema5_vs_ema10_atr'))
    combined_probability=round(0.40*float(p1)+0.40*float(p4)+0.20*float(p24),3) if None not in (p1,p4,p24) else None
    positive_axes=sum(1 for d in (d1,d4,d24) if d=='POSITIVE'); negative_axes=sum(1 for d in (d1,d4,d24) if d=='NEGATIVE')

    # Preserve V12 from the same immutable input as the transition baseline.
    extension=sum(1 for v in (ret30,accel30,a1,rs1,rsacc) if v is not None and v>0)
    h4_anchor=bool((hl4 is not None and hl4>0) or (tr4 is not None and tr4>=0) or (rec4 is not None and rec4>=0.5))
    flow_positive_v12=flow_improving or ((_num(inputs.get('buy_ratio')) or 0)>0.5 and (_num(inputs.get('buy_sustain_1m')) or 0)>0.5)
    no_hard_sell_v12=bool(no_hard_sell or flow_positive_v12 or (tv1 is not None and tv1>0))
    restart_v12=bool(restart and (inputs.get('pullback_volume_contract') is True or inputs.get('reclaim_volume_expand') is True) and flow_positive_v12 and no_hard_sell)
    beginning_v12=bool(beginning and volume_leads and flow_positive_v12 and no_hard_sell)
    raw_chase_v12=bool(extension>=3 and ('CHASE' in tags or 'EXHAUSTION' in tags or seq=='PRICE_LEADS'))
    hard_chase_v12=bool(raw_chase_v12 and not volume_leads and not restart_v12 and not beginning_v12)
    recovery_proof_v12=bool((hl1 is not None and hl1>0 or rec1 is not None and rec1>=0.5) and h4_anchor and no_hard_sell_v12 and p1 is not None and p1>=50.0 and p4 is not None and p4>=48.0)
    early_recovery_v12=bool(rec1 is not None and 0.15<=rec1<0.5 and tv4 is not None and tv4>0 and no_hard_sell_v12 and p1 is not None and p1>=48.0 and p4 is not None and p4>=45.0 and extension<=2)
    continuation_v12=bool(d4=='POSITIVE' and p1 is not None and p1>=52.0 and p4 is not None and p4>=52.0 and no_hard_sell_v12 and not hard_chase_v12)
    start_v12=bool((beginning_v12 or restart_v12 or (volume_leads and flow_positive_v12)) and h4_anchor and p1 is not None and p1>=52.0 and p4 is not None and p4>=50.0 and not hard_chase_v12)
    chase_v12=bool(raw_chase_v12 and not (start_v12 or recovery_proof_v12 or early_recovery_v12 or continuation_v12))
    weak_rebound_v12=bool(d24=='NEGATIVE' and (h4_anchor or d4=='POSITIVE') and (recovery_proof_v12 or early_recovery_v12 or p1 is not None and p1>=50.0))
    down_v12=bool(combined_probability is not None and combined_probability<=42.0 and d1=='NEGATIVE' and d4=='NEGATIVE' and not h4_anchor and negative_axes>=2)
    broad_up_v12=bool(combined_probability is not None and combined_probability>=55.0 and positive_axes>=1 and d4!='NEGATIVE' and no_hard_sell_v12 and not hard_chase_v12)
    if missing or None in (p1,p4,p24):
        prior_state='SOURCE_WAIT'; prior_decision='HOLD'; prior_reason='SOURCE_MISSING_OR_STALE:'+','.join(missing or ['ROLE_OUTPUT'])
    elif down_v12:
        prior_state='DOWN_CONTINUATION'; prior_decision='DOWN'; prior_reason='LOW_COMBINED_PROBABILITY_WITH_1H_4H_DOWNTREND'
    elif start_v12:
        prior_state='UP_START'; prior_decision='UP'; prior_reason='VOLUME_OR_FLOW_LED_START_WITH_4H_ANCHOR'
    elif restart_v12 and (recovery_proof_v12 or early_recovery_v12):
        prior_state='PULLBACK_RESTART'; prior_decision='UP'; prior_reason='PULLBACK_RECLAIM_WITH_1H_4H_RECOVERY'
    elif early_recovery_v12 and (volume_leads or flow_positive_v12 or restart_v12):
        prior_state='RECOVERY_RESTART'; prior_decision='UP'; prior_reason='EARLY_PULLBACK_RECOVERY_WITH_4H_TURNOVER_CONFIRMATION'
    elif continuation_v12 or broad_up_v12:
        prior_state='UP_CONTINUATION'; prior_decision='UP'; prior_reason='BALANCED_1H_4H_EVIDENCE_SUPPORTS_CONTINUATION'
    elif recovery_proof_v12 or weak_rebound_v12:
        prior_state='RECOVERY_RECHECK'; prior_decision='HOLD'; prior_reason='RECOVERY_PRESENT_NEXT_CYCLE_CONFIRMATION_REQUIRED'
    elif chase_v12:
        prior_state='CHASE_OVERHEAT_RECHECK'; prior_decision='HOLD'; prior_reason='EXTENSION_WITHOUT_BALANCED_1H_4H_SUPPORT'
    elif combined_probability is not None and combined_probability>=48.0:
        prior_state='NEUTRAL_RECHECK'; prior_decision='HOLD'; prior_reason='MID_PROBABILITY_CONFLICT_REQUIRES_NEXT_CYCLE'
    else:
        prior_state='WEAK_REBOUND_RECHECK'; prior_decision='HOLD'; prior_reason='WEAK_OR_CONFLICTED_EVIDENCE_NOT_CONFIRMED_DOWN'

    # V13: stage classification uses direction changes first. Positive levels are
    # location evidence only and cannot create UP by themselves.
    recovery1_phase=str(inputs.get('pullback_phase') or 'MISSING').upper()
    recovery4_phase=str(s4.get('pullback_phase') or 'MISSING').upper()
    flow1_state=str(inputs.get('flow_state') or 'UNKNOWN').upper()
    flow4_state=str(s4.get('flow_state') or 'UNKNOWN').upper()
    entry_state='SELLING_PRESSURE' if sell_pressure or (flow_weakening and not flow_improving) or flow1_state=='SELLING_EXPANSION' else 'BUYING_IMPROVING' if flow_improving and no_hard_sell else 'VOLUME_LEADS' if volume_leads and no_hard_sell else 'PENDING_TRIGGER_CONFIRMATION'
    if hl4 is not None and hl4<0 and tr4 is not None and tr4<0 and (rec4_delta is None or rec4_delta<=0):
        structure_state='BROKEN'
    elif recovery4_phase=='RECOVERING' or (hl4 is not None and hl4>0 and tr4_delta is not None and tr4_delta>0):
        structure_state='RECOVERY'
    elif recovery4_phase in {'RECLAIMED','RECLAIMED_WEAKENING'} or (hl4 is not None and hl4>0 and tr4 is not None and tr4>=0):
        structure_state='TREND'
    elif recovery4_phase=='FALLING_BACK' or (tr4_delta is not None and tr4_delta<0):
        structure_state='WEAKENING'
    else:
        structure_state='MIXED'
    transition_state='IMPROVING' if d1=='POSITIVE' else 'WEAKENING' if d1=='NEGATIVE' else 'MIXED'
    environment_state='SUPPORTIVE' if d24=='POSITIVE' else 'DEFENSIVE' if d24=='NEGATIVE' else 'NEUTRAL'
    start_evidence=bool(beginning or volume_leads or recovery1_phase=='RECOVERING')
    restart_evidence=bool(restart or (hl1 is not None and hl1>0 and rec1_delta is not None and rec1_delta>0))
    extended_weakening=bool((recovery4_phase in {'RECLAIMED','RECLAIMED_WEAKENING'} or ('CHASE' in tags)) and transition_state=='WEAKENING')
    if structure_state=='BROKEN' and transition_state=='WEAKENING':
        lifecycle='DOWNTREND'
    elif structure_state=='RECOVERY' and transition_state=='IMPROVING' and start_evidence and entry_state!='SELLING_PRESSURE':
        lifecycle='RECOVERY_START'
    elif structure_state in {'RECOVERY','TREND'} and transition_state=='IMPROVING' and restart_evidence and entry_state!='SELLING_PRESSURE':
        lifecycle='PULLBACK_RESTART'
    elif structure_state=='TREND' and transition_state=='IMPROVING' and entry_state!='SELLING_PRESSURE':
        lifecycle='CONTINUATION'
    elif extended_weakening:
        lifecycle='EXTENDED_WEAKENING'
    elif structure_state=='WEAKENING' and transition_state=='WEAKENING':
        lifecycle='STRUCTURE_WEAKENING'
    else:
        lifecycle='MIXED_RECHECK'
    if missing or None in (p1,p4,p24):
        state='SOURCE_WAIT'; decision='HOLD'; reason='SOURCE_MISSING_OR_STALE:'+','.join(missing or ['ROLE_OUTPUT'])
    elif lifecycle=='DOWNTREND':
        state='DOWN_CONTINUATION'; decision='DOWN'; reason='4H_STRUCTURE_BROKEN_AND_1H_DIRECTION_WEAKENING'
    elif lifecycle in {'RECOVERY_START','PULLBACK_RESTART','CONTINUATION'}:
        state=lifecycle; decision='UP'; reason='ROLE_STAGE_DIRECTION_ALIGNED_AND_ENTRY_NOT_SELLING'
    elif lifecycle=='EXTENDED_WEAKENING':
        state='EXTENDED_WEAKENING_RECHECK'; decision='HOLD'; reason='POSITIVE_LOCATION_BUT_DIRECTION_CHANGE_WEAKENING'
    elif lifecycle=='STRUCTURE_WEAKENING':
        state='STRUCTURE_WEAKENING_RECHECK'; decision='HOLD'; reason='STRUCTURE_AND_DIRECTION_WEAKENING_WITHOUT_FULL_DOWN_PROOF'
    else:
        state='ROLE_CONFLICT_RECHECK'; decision='HOLD'; reason='ENVIRONMENT_STRUCTURE_TRANSITION_OR_ENTRY_NOT_ALIGNED'
    recheck=decision=='HOLD' and state!='SOURCE_WAIT'
    return {
        'schema':'official_timeframe_role_evaluation','contract_id':TIMEFRAME_ROLE_CONTRACT_ID,'formula_id':TIMEFRAME_ROLE_FORMULA_ID,
        'decision':decision,'structure_allowed':decision=='UP','reason':reason,'prediction_path':state,'market_state':state,
        'probability_1h_timing':p1,'probability_4h_structure':p4,'probability_24h_context':p24,'combined_probability_pct':combined_probability,
        'axis_states':{'1h_timing':d1,'4h_structure':d4,'24h_context':d24},'evidence_groups':groups,
        'role_stage_classification':{
            'environment':environment_state,'structure':structure_state,'transition':transition_state,'entry':entry_state,'lifecycle':lifecycle,
            'recovery_1h_phase':recovery1_phase,'recovery_4h_phase':recovery4_phase,'flow_1h_state':flow1_state,'flow_4h_state':flow4_state,
            'positive_level_is_automatic_up':False,'direction_change_has_priority':True,
        },
        'decision_basis':'ROLE_STAGE_DIRECTION_CHANGE_FIRST_NO_FIXED_PROBABILITY_CUT',
        'recheck_contract':{'active':recheck,'next_cycle':True,'preserve_candidate':True,'promote_to_up_when':['RECOVERY_START','PULLBACK_RESTART','CONTINUATION'],'confirm_down_when':['4H_STRUCTURE_BROKEN_AND_1H_DIRECTION_WEAKENING'],'source_missing_is_not_quality_failure':True},
        'probability_calibration':{'state':'DISPLAY_ONLY_NOT_DECISION_CUT','probability_is_not_accuracy_claim':True,'fixed_cut_used':False},
        'material_contract':{'duplicate_counting_prevented':True,'groups':['environment','structure','transition','entry'],'raw_materials_deleted':False,'positive_level_is_automatic_up':False},
        'source_missing_axes':missing,
        'prior_formula_id':PRIOR_TIMEFRAME_ROLE_FORMULA_ID,'prior_formula_decision':prior_decision,'prior_formula_prediction_path':prior_state,'prior_formula_reason':prior_reason,
        'baseline_role_decision':prior_decision,'baseline_prediction_path':prior_state,'decision_transition_class':f'{prior_decision}_TO_{decision}',
        'transition_sealed_at_strategy':True,'transition_historical_replay_used':False,
        'candidate_count_target_used':False,'forced_up_used':False,'weights_applied':False,'thresholds_applied':False,'auto_buy':False,
    }


def _apply_live_prediction(payload: Dict[str,Any], row: Dict[str,Any]) -> Dict[str,Any]:
    role_input=payload.get('timeframe_role_input') if isinstance(payload.get('timeframe_role_input'),dict) else {}
    evaluation=evaluate_timeframe_role_input(role_input)
    axes=role_input.get('axes') if isinstance(role_input.get('axes'),dict) else {}
    evidence=sum(int((axes.get(name) or {}).get('evidence_count') or 0) for name in TIMEFRAME_ROLE_AXES if isinstance(axes.get(name),dict))
    source_states=role_input.get('axis_source_state') if isinstance(role_input.get('axis_source_state'),dict) else {}
    ready=sum(1 for axis in ('h1','h4','d1') if str(source_states.get(axis) or '')=='READY')
    material_state=str(payload.get('state') or 'MISSING').upper()
    coverage=float(payload.get('input_coverage_pct') or 0.0)
    confidence=round(min(100.0,coverage)*(ready/3.0),3)
    confidence_state='HIGH' if material_state=='READY' and ready==3 else 'MEDIUM' if material_state=='PARTIAL' and ready==3 else 'LOW'
    payload.update({
        'prediction_contract_id':TIMEFRAME_ROLE_CONTRACT_ID,'timeframe_role_formula_id':TIMEFRAME_ROLE_FORMULA_ID,
        'timeframe_role_evaluation':evaluation,'primary_selection':evaluation,
        'probability_1h_timing':evaluation.get('probability_1h_timing'),'probability_4h_structure':evaluation.get('probability_4h_structure'),'probability_24h_context':evaluation.get('probability_24h_context'),
        'probability_3h':None,'probability_6h':None,'predicted_direction_3h':None,'predicted_direction_6h':None,
        'giveback_risk':None,'late_capture_risk':None,
        'output_states':{'1h_timing':source_states.get('h1'),'4h_structure':source_states.get('h4'),'24h_context':source_states.get('d1')},
        'model_state':'LIVE_OFFICIAL_TIMEFRAME_ROLE' if not evaluation.get('source_missing_axes') else 'SOURCE_WAIT',
        'prediction_model_id':TIMEFRAME_ROLE_FORMULA_ID,'prediction_model_generated_ts':None,'prediction_model_retention_days':5,
        'prediction_confidence_pct':confidence,'prediction_confidence_state':confidence_state,
        'prediction_confidence_meaning':'OFFICIAL_FRAME_COMPLETENESS_AND_ROLE_EVIDENCE_NOT_VERIFIED_ACCURACY',
        'prediction_evidence_count':evidence,'prediction_target_scores':axes,
        'probability_calculation_active':True,'raw_material_prediction_active':False,'review_calibration_active':False,
        'weights_applied':False,'thresholds_applied':False,'prediction_used_as_gate':True,'candidate_preserved':True,'zero_fill_used':False,'auto_buy':False,
    })
    return payload


def build_rise_prediction_input(row: Dict[str, Any], frames: Dict[str, List[Dict[str, float]]], structure: Dict[str, Any], nowv: float) -> Dict[str, Any]:
    ticker = str(row.get("ticker") or row.get("symbol") or "").upper().replace("KRW-", "").strip()
    m30 = frames.get("m30") if isinstance(frames.get("m30"), list) else []
    h1 = frames.get("h1") if isinstance(frames.get("h1"), list) else []
    h4 = frames.get("h4") if isinstance(frames.get("h4"), list) else []
    d1 = frames.get("d1") if isinstance(frames.get("d1"), list) else []
    benchmark_frames = row.get("prediction_benchmark_frames") if isinstance(row.get("prediction_benchmark_frames"), dict) else {}
    btc_h1 = benchmark_frames.get("h1") if isinstance(benchmark_frames.get("h1"), list) else (row.get("prediction_benchmark_h1") if isinstance(row.get("prediction_benchmark_h1"), list) else [])
    btc_h4 = benchmark_frames.get("h4") if isinstance(benchmark_frames.get("h4"), list) else []
    btc_d1 = benchmark_frames.get("d1") if isinstance(benchmark_frames.get("d1"), list) else []

    ticker_truth=row.get('prediction_candle_frame_truth') if isinstance(row.get('prediction_candle_frame_truth'),dict) else {}
    btc_truth=row.get('prediction_benchmark_frame_truth') if isinstance(row.get('prediction_benchmark_frame_truth'),dict) else {}
    states = {
        "m30": _frame_state(m30, 8, nowv, 1800.0, ticker_truth.get('m30') if isinstance(ticker_truth.get('m30'),dict) else {}),
        "h1": _frame_state(h1, 16, nowv, 3600.0, ticker_truth.get('h1') if isinstance(ticker_truth.get('h1'),dict) else {}),
        "btc_h1": _frame_state(btc_h1, 4, nowv, 3600.0, btc_truth.get('h1') if isinstance(btc_truth.get('h1'),dict) else {}),
    }
    current = _row_price(row)
    atr1h = _atr(h1, 14) if h1 else 0.0
    atr1h_pct = (atr1h / current * 100.0) if current and current > 0 and atr1h > 0 else None

    ret30 = _return_pct(m30, 1)
    prior30 = _return_pct(m30, 1, 1)
    priorprior30 = _return_pct(m30, 1, 2)
    ret1h = _return_pct(h1, 1)
    prior1h = _return_pct(h1, 1, 1)
    priorprior1h = _return_pct(h1, 1, 2)
    btc1h = _return_pct(btc_h1, 1)
    btc_prior1h = _return_pct(btc_h1, 1, 1)
    btc_priorprior1h = _return_pct(btc_h1, 1, 2)
    price_accel_30m = (ret30 - prior30) if ret30 is not None and prior30 is not None else None
    prior_price_accel_30m = (prior30 - priorprior30) if prior30 is not None and priorprior30 is not None else None
    price_accel_1h = (ret1h - prior1h) if ret1h is not None and prior1h is not None else None
    prior_price_accel_1h = (prior1h - priorprior1h) if prior1h is not None and priorprior1h is not None else None

    recent1h_turn = _avg_turnover(h1[-1:]) if len(h1) >= 1 else None
    prior3h_turn = _avg_turnover(h1[-4:-1]) if len(h1) >= 4 else None
    previous1h_turn = _avg_turnover(h1[-2:-1]) if len(h1) >= 2 else None
    previous_prior3h_turn = _avg_turnover(h1[-5:-2]) if len(h1) >= 5 else None
    recent30_turn = _avg_turnover(m30[-1:]) if len(m30) >= 1 else None
    prior30_turn = _avg_turnover(m30[-2:-1]) if len(m30) >= 2 else None
    priorprior30_turn = _avg_turnover(m30[-3:-2]) if len(m30) >= 3 else None
    turnover_accel_30m = ((recent30_turn / prior30_turn) - 1.0) * 100.0 if recent30_turn is not None and prior30_turn and prior30_turn > 0 else None
    prior_turnover_accel_30m = ((prior30_turn / priorprior30_turn) - 1.0) * 100.0 if prior30_turn is not None and priorprior30_turn and priorprior30_turn > 0 else None

    swing = _latest_confirmed_swing_low(m30)
    previous_swings = _pivots(m30[-80:], "low", 2)
    prior_swing_price = _num(previous_swings[-2].get("price")) if len(previous_swings) >= 2 else None
    current_swing_price = _num(swing.get("price"))
    higher_low = ((current_swing_price - prior_swing_price) / max(atr1h, 1e-12)) if current_swing_price is not None and prior_swing_price is not None and atr1h > 0 else None
    prior_higher_low = None
    if len(previous_swings) >= 3 and atr1h > 0:
        older_swing_price = _num(previous_swings[-3].get("price"))
        if older_swing_price is not None and prior_swing_price is not None:
            prior_higher_low = (prior_swing_price - older_swing_price) / max(atr1h, 1e-12)

    pullback_snapshot = _confirmed_pullback_snapshot(m30, current, 2)
    prior_high = _num(pullback_snapshot.get("high"))
    pullback_recovery = _num(pullback_snapshot.get("ratio"))
    prior_pullback_recovery = _num(pullback_snapshot.get("prior_ratio"))

    market = _market_context(row)
    breadth_change = _num(market.get("breadth_velocity_pct_v2130"))
    market_age = None
    market_updated = _num(market.get("updated_ts"))
    if market_updated is not None:
        market_age = max(0.0, nowv - market_updated)
    market_state = "MISSING" if not market else ("STALE" if market_age is not None and market_age > 300.0 else "READY")
    liquidity_raw = {
        "turnover_concentration_top10_pct": _num(market.get("turnover_concentration_top10_pct_v2130")),
        "turnover_concentration_velocity": _num(market.get("turnover_concentration_velocity_v2130")),
        "market_change_dispersion_pct": _num(market.get("market_change_dispersion_pct_v2155")),
        "risk_state": market.get("risk_state_v2130"),
        "context_state": market.get("state"),
    }

    material_rows: Dict[str, Dict[str, Any]] = {}
    material_rows["return_30m_atr_adjusted"] = _material(
        "return_30m_atr_adjusted",
        (ret30 / atr1h_pct) if ret30 is not None and atr1h_pct and atr1h_pct > 0 else None,
        "candle_worker", "completed m30 return / h1 ATR%", _source_state(states["m30"]["state"], states["h1"]["state"]),
        {"return_30m_pct": ret30, "atr_1h_pct": atr1h_pct},
    )
    material_rows["price_acceleration_30m"] = _material(
        "price_acceleration_30m", price_accel_30m,
        "candle_worker", "recent completed 30m return - prior completed 30m return", states["m30"]["state"],
        {"recent_30m_pct": ret30, "prior_30m_pct": prior30},
    )
    material_rows["price_acceleration_1h"] = _material(
        "price_acceleration_1h", price_accel_1h,
        "candle_worker", "recent completed 1h return - prior completed 1h return", states["h1"]["state"],
        {"recent_1h_pct": ret1h, "prior_1h_pct": prior1h},
    )
    rs1h = (ret1h - btc1h) if ret1h is not None and btc1h is not None else None
    prior_rs1h = (prior1h - btc_prior1h) if prior1h is not None and btc_prior1h is not None else None
    priorprior_rs1h = (priorprior1h - btc_priorprior1h) if priorprior1h is not None and btc_priorprior1h is not None else None
    rs_accel_1h = (rs1h - prior_rs1h) if rs1h is not None and prior_rs1h is not None else None
    prior_rs_accel_1h = (prior_rs1h - priorprior_rs1h) if prior_rs1h is not None and priorprior_rs1h is not None else None
    rs_state = _source_state(states["h1"]["state"], states["btc_h1"]["state"])
    material_rows["relative_strength_1h"] = _material(
        "relative_strength_1h", rs1h, "strategy_v2_core", "ticker completed h1 return - BTC completed h1 return", rs_state,
        {"ticker_1h_pct": ret1h, "btc_1h_pct": btc1h},
    )
    material_rows["relative_strength_acceleration_1h"] = _material(
        "relative_strength_acceleration_1h", rs_accel_1h,
        "strategy_v2_core", "current 1h relative strength - prior 1h relative strength", rs_state,
        {"current_rs_1h": rs1h, "prior_rs_1h": prior_rs1h},
    )
    material_rows["turnover_growth_recent1h_vs_prior3h"] = _material(
        "turnover_growth_recent1h_vs_prior3h",
        ((recent1h_turn / prior3h_turn) - 1.0) * 100.0 if recent1h_turn is not None and prior3h_turn and prior3h_turn > 0 else None,
        "candle_worker", "completed OHLCV close*volume recent 1h vs prior 3h hourly average", states["h1"]["state"],
        {"recent_1h_turnover_proxy": recent1h_turn, "prior_3h_hourly_avg_proxy": prior3h_turn},
    )
    material_rows["turnover_acceleration_30m"] = _material(
        "turnover_acceleration_30m",
        turnover_accel_30m,
        "candle_worker", "completed OHLCV close*volume recent 30m vs prior 30m", states["m30"]["state"],
        {"recent_30m_turnover_proxy": recent30_turn, "prior_30m_turnover_proxy": prior30_turn},
    )
    material_rows["higher_low_strength_atr"] = _material(
        "higher_low_strength_atr", higher_low, "strategy_v2_core", "latest two confirmed m30 swing lows / h1 ATR", _source_state(states["m30"]["state"], states["h1"]["state"]),
        {"latest_swing_low": current_swing_price, "prior_swing_low": prior_swing_price, "atr_1h": atr1h},
    )
    material_rows["pullback_recovery_ratio"] = _material(
        "pullback_recovery_ratio", pullback_recovery, "strategy_v2_core", "current recovery between latest confirmed m30 swing low and prior confirmed high", states["m30"]["state"],
        {"current_price": current, "swing_low": current_swing_price, "prior_swing_high": prior_high, "pullback_snapshot": pullback_snapshot},
    )
    material_rows["btc_price_acceleration_1h"] = _material(
        "btc_price_acceleration_1h", (btc1h - btc_prior1h) if btc1h is not None and btc_prior1h is not None else None,
        "candle_worker", "BTC recent completed 1h return - prior completed 1h return", states["btc_h1"]["state"],
        {"recent_btc_1h_pct": btc1h, "prior_btc_1h_pct": btc_prior1h},
    )
    material_rows["market_breadth_change"] = _material(
        "market_breadth_change", breadth_change, "market_regime_worker", "breadth_velocity_pct_v2130", market_state,
        {"breadth_up_pct": _num(market.get("breadth_up_pct")), "breadth_change": breadth_change, "age_sec": market_age},
    )
    material_rows["market_liquidity_state"] = _material(
        "market_liquidity_state", liquidity_raw, "market_regime_worker", "turnover concentration + concentration velocity + market dispersion + risk state", market_state, liquidity_raw,
    )

    owner_meta = {
        "candle": _owner_meta(row, "candle", nowv),
        "market": _owner_meta(row, "market", nowv),
        "strategy": {"owner": "strategy_v2_core", "updated_ts": nowv, "attempted_ts": nowv, "success_ts": nowv, "age_sec": 0.0},
    }
    material_source_contract = {
        "return_30m_atr_adjusted": ("candle", [states["m30"], states["h1"]], ["m30", "h1"]),
        "price_acceleration_30m": ("candle", [states["m30"]], ["m30"]),
        "price_acceleration_1h": ("candle", [states["h1"]], ["h1"]),
        "relative_strength_1h": ("candle", [states["h1"], states["btc_h1"]], ["ticker_h1", "btc_h1"]),
        "relative_strength_acceleration_1h": ("candle", [states["h1"], states["btc_h1"]], ["ticker_h1", "btc_h1"]),
        "turnover_growth_recent1h_vs_prior3h": ("candle", [states["h1"]], ["h1"]),
        "turnover_acceleration_30m": ("candle", [states["m30"]], ["m30"]),
        "higher_low_strength_atr": ("candle", [states["m30"], states["h1"]], ["m30_confirmed_swings", "h1_atr"]),
        "pullback_recovery_ratio": ("candle", [states["m30"]], ["m30_confirmed_swing_low", "m30_confirmed_swing_high"]),
        "btc_price_acceleration_1h": ("candle", [states["btc_h1"]], ["btc_h1"]),
        "market_breadth_change": ("market", [], ["market_regime"]),
        "market_liquidity_state": ("market", [], ["market_regime"]),
    }
    for name, item in material_rows.items():
        owner_key, frame_items, required_inputs = material_source_contract[name]
        completed_values = [_num(frame.get("last_completed_ts")) for frame in frame_items if isinstance(frame, dict)]
        completed_values = [value for value in completed_values if value is not None]
        item["source_last_completed_ts"] = min(completed_values) if completed_values else (market_updated if owner_key == "market" else nowv if owner_key == "strategy" else None)
        item["source_updated_ts"] = owner_meta[owner_key].get("updated_ts")
        item["source_attempted_ts"] = owner_meta[owner_key].get("attempted_ts")
        frame_attempts=[_num(frame.get('attempted_ts')) for frame in frame_items if isinstance(frame,dict) and _num(frame.get('attempted_ts')) is not None]
        frame_successes=[_num(frame.get('api_success_ts')) for frame in frame_items if isinstance(frame,dict) and _num(frame.get('api_success_ts')) is not None]
        frame_updates=[_num(frame.get('completed_update_ts')) for frame in frame_items if isinstance(frame,dict) and _num(frame.get('completed_update_ts')) is not None]
        item["source_attempted_ts"] = max(frame_attempts) if frame_attempts else owner_meta[owner_key].get("attempted_ts")
        item["source_success_ts"] = max(frame_successes) if frame_successes else owner_meta[owner_key].get("success_ts")
        item["source_completed_update_ts"] = max(frame_updates) if frame_updates else None
        item["source_completed_bar_changed"] = any(bool(frame.get('completed_bar_changed')) for frame in frame_items if isinstance(frame,dict))
        item["source_fetch_states"] = [str(frame.get('fetch_state') or '') for frame in frame_items if isinstance(frame,dict) and frame.get('fetch_state')]
        source_reasons=[str(frame.get('reason') or frame.get('owner_data_reason') or '') for frame in frame_items if isinstance(frame,dict) and (frame.get('reason') or frame.get('owner_data_reason'))]
        item["source_reasons"] = list(dict.fromkeys(source_reasons))
        if item.get("state") != "READY" and source_reasons:
            item["missing_reason"] = '|'.join(dict.fromkeys(source_reasons))
        item["source_age_sec"] = max([float(frame.get('age_sec')) for frame in frame_items if isinstance(frame,dict) and _num(frame.get('age_sec')) is not None],default=owner_meta[owner_key].get("age_sec"))
        item["source_required_inputs"] = required_inputs
        if item.get("source_state") == "READY" and item.get("value") is None:
            item["state"] = "MISSING"
            item["value_state"] = "MISSING"
            if name == "higher_low_strength_atr":
                item["missing_reason"] = "TWO_CONFIRMED_M30_SWING_LOWS_NOT_AVAILABLE"
            elif name == "pullback_recovery_ratio":
                item["missing_reason"] = "CONFIRMED_PULLBACK_RANGE_NOT_AVAILABLE"
            elif name in {"market_breadth_change", "market_liquidity_state"}:
                item["missing_reason"] = "MARKET_OWNER_VALUE_NOT_AVAILABLE"
            else:
                item["missing_reason"] = "DERIVED_VALUE_NOT_AVAILABLE_FROM_COMPLETED_SOURCE"

    current_return_atr = (ret30 / atr1h_pct) if ret30 is not None and atr1h_pct and atr1h_pct > 0 else None
    prior_return_atr = (prior30 / atr1h_pct) if prior30 is not None and atr1h_pct and atr1h_pct > 0 else None
    current_turn_growth = ((recent1h_turn / prior3h_turn) - 1.0) * 100.0 if recent1h_turn is not None and prior3h_turn and prior3h_turn > 0 else None
    prior_turn_growth = ((previous1h_turn / previous_prior3h_turn) - 1.0) * 100.0 if previous1h_turn is not None and previous_prior3h_turn and previous_prior3h_turn > 0 else None
    btc_accel = (btc1h - btc_prior1h) if btc1h is not None and btc_prior1h is not None else None
    prior_btc_accel = (btc_prior1h - btc_priorprior1h) if btc_prior1h is not None and btc_priorprior1h is not None else None
    prior_values = {
        "return_30m_atr_adjusted": prior_return_atr,
        "price_acceleration_30m": prior_price_accel_30m,
        "price_acceleration_1h": prior_price_accel_1h,
        "relative_strength_1h": prior_rs1h,
        "relative_strength_acceleration_1h": prior_rs_accel_1h,
        "turnover_growth_recent1h_vs_prior3h": prior_turn_growth,
        "turnover_acceleration_30m": prior_turnover_accel_30m,
        "higher_low_strength_atr": prior_higher_low,
        "pullback_recovery_ratio": prior_pullback_recovery,
        "btc_price_acceleration_1h": prior_btc_accel,
        "market_breadth_change": None,
        "market_liquidity_state": None,
    }
    movement_values = {
        "return_30m_atr_adjusted": (current_return_atr-prior_return_atr) if current_return_atr is not None and prior_return_atr is not None else None,
        "price_acceleration_30m": (price_accel_30m-prior_price_accel_30m) if price_accel_30m is not None and prior_price_accel_30m is not None else None,
        "price_acceleration_1h": (price_accel_1h-prior_price_accel_1h) if price_accel_1h is not None and prior_price_accel_1h is not None else None,
        "relative_strength_1h": rs_accel_1h,
        "relative_strength_acceleration_1h": (rs_accel_1h-prior_rs_accel_1h) if rs_accel_1h is not None and prior_rs_accel_1h is not None else None,
        "turnover_growth_recent1h_vs_prior3h": (current_turn_growth-prior_turn_growth) if current_turn_growth is not None and prior_turn_growth is not None else None,
        "turnover_acceleration_30m": (turnover_accel_30m-prior_turnover_accel_30m) if turnover_accel_30m is not None and prior_turnover_accel_30m is not None else None,
        "higher_low_strength_atr": (higher_low-prior_higher_low) if higher_low is not None and prior_higher_low is not None else None,
        "pullback_recovery_ratio": (pullback_recovery-prior_pullback_recovery) if pullback_recovery is not None and prior_pullback_recovery is not None else None,
        "btc_price_acceleration_1h": (btc_accel-prior_btc_accel) if btc_accel is not None and prior_btc_accel is not None else None,
        "market_breadth_change": None,
        "market_liquidity_state": None,
    }
    contextual_states = {
        "turnover_growth_recent1h_vs_prior3h": _flow_state(movement_values.get("turnover_growth_recent1h_vs_prior3h"), price_accel_1h),
        "turnover_acceleration_30m": _flow_state(movement_values.get("turnover_acceleration_30m"), price_accel_30m),
        "pullback_recovery_ratio": pullback_snapshot.get("phase"),
        "market_liquidity_state": market.get("state") if isinstance(market,dict) else None,
    }
    material_role_summary = _annotate_material_roles(material_rows, prior_values, movement_values, contextual_states)
    state_counts = Counter(str(item.get("state") or "MISSING") for item in material_rows.values())
    ready_count = state_counts.get("READY", 0)
    usable_count = ready_count
    latest_m30_ts = _num(m30[-1].get("ts")) if m30 else None
    event_bar_close_ts = latest_m30_ts + 1800.0 if latest_m30_ts is not None else None
    episode_low_ts = _num(swing.get("ts"))
    episode_id = f"{ticker}:{int(episode_low_ts)}" if ticker and episode_low_ts is not None else None
    event_key = f"{ticker}:{int(event_bar_close_ts)}" if ticker and event_bar_close_ts is not None else None
    event_price = _num(m30[-1].get("c")) if m30 else current
    pre_signal_rise_pct = None
    if event_price is not None and current_swing_price is not None and current_swing_price > 0:
        pre_signal_rise_pct = (event_price / current_swing_price - 1.0) * 100.0
    episode_bar_count = None
    if episode_low_ts is not None:
        episode_bar_count = sum(1 for bar in m30 if (_num(bar.get("ts")) or -1.0) >= episode_low_ts)
    signal_position = {
        "episode_low_ts": episode_low_ts,
        "episode_low_price": current_swing_price,
        "episode_completed_30m_bars": episode_bar_count,
        "pre_signal_rise_pct": round(pre_signal_rise_pct, 8) if pre_signal_rise_pct is not None else None,
        "pullback_recovery_ratio": pullback_recovery,
        "prior_pullback_recovery_ratio": prior_pullback_recovery,
        "prior_confirmed_swing_high": prior_high,
        "pullback_range_state": pullback_snapshot.get("state"),
        "pullback_phase": pullback_snapshot.get("phase"),
        "event_price": event_price,
        "late_capture_reason_inputs": {
            "pre_signal_rise_pct": pre_signal_rise_pct,
                "episode_completed_30m_bars": episode_bar_count,
        },
    }
    sequence = _price_volume_sequence(m30)
    tags = _explanation_tags(
        price_accel=price_accel_30m,
        prior_price_accel=prior_price_accel_30m,
        rs_accel=rs_accel_1h,
        prior_rs_accel=prior_rs_accel_1h,
        turnover_accel=turnover_accel_30m,
        prior_turnover_accel=prior_turnover_accel_30m,
        higher_low=higher_low,
        prior_return_30m=prior30,
        recovery=pullback_recovery,
        prior_recovery=prior_pullback_recovery,
        pre_signal_rise=pre_signal_rise_pct,
        episode_bar_count=episode_bar_count,
    )
    values = {name: material_rows[name].get("value") for name in RISE_MATERIAL_NAMES}
    role_market=dict(market) if isinstance(market,dict) else {}
    market_liq_value=(material_rows.get('market_liquidity_state') or {}).get('value') if isinstance(material_rows.get('market_liquidity_state'),dict) else {}
    market_supportive=None
    if isinstance(market_liq_value,dict):
        risk=str(market_liq_value.get('risk_state') or '').upper(); context_state=str(market_liq_value.get('context_state') or '').upper()
        market_supportive=False if risk in {'RISK_OFF','HIGH_RISK','DEFENSIVE'} or context_state in {'BEAR','DOWN','RISK_OFF','CONTEXT_DEFENSIVE'} else True if risk in {'RISK_ON','LOW_RISK'} or context_state in {'BULL','UP','RISK_ON','CONTEXT_SUPPORTIVE'} else None
    orderflow_ctx=row.get('orderflow_continuation_v2130') if isinstance(row.get('orderflow_continuation_v2130'),dict) else {}
    micro_reaction=orderflow_ctx.get('micro_reaction_v2155') if isinstance(orderflow_ctx.get('micro_reaction_v2155'),dict) else {}
    freshness=orderflow_ctx.get('freshness_v2155') if isinstance(orderflow_ctx.get('freshness_v2155'),dict) else {}
    # Existing Orderflow Owner values are transported into the immutable Strategy
    # event only as observations. V12 decisions continue to use the same five flow
    # facts below; ask-wall/bid-wall/spread/micro-reaction fields are not promoted
    # into the mainline until Review proves them on actual outcomes.
    existing_flow={
        'orderflow_state':str(orderflow_ctx.get('state') or 'MISSING'),
        'continuation_score':_num(orderflow_ctx.get('continuation_score_v2130')),
        'buy_ratio':_num(orderflow_ctx.get('buy_ratio_level_v2155'),_num(row.get('buy_ratio'),_num(row.get('trade_buy_ratio_30')))),
        'buy_sustain_1m':_num(orderflow_ctx.get('buy_sustain_level_v2155'),_num(row.get('buy_sustain_1m'),_num(row.get('buy_sustain_60s')))),
        'buy_persist':_num(orderflow_ctx.get('buy_persist_level_v2155')),
        'buy_ratio_delta':_num(orderflow_ctx.get('buy_ratio_delta_v2130')),
        'buy_sustain_delta':_num(orderflow_ctx.get('buy_sustain_delta_v2130')),
        'ask_wall_ratio':_num(orderflow_ctx.get('ask_wall_ratio_level_v2155')),
        'bid_wall_ratio':_num(orderflow_ctx.get('bid_wall_ratio_level_v2155')),
        'ask_wall_depletion':_num(orderflow_ctx.get('ask_wall_depletion_v2130')),
        'bid_wall_delta':_num(orderflow_ctx.get('bid_wall_delta_v2130')),
        'spread_pct':_num(orderflow_ctx.get('spread_level_pct_v2155')),
        'spread_delta':_num(orderflow_ctx.get('spread_delta_v2130')),
        'trade_burst_10s':_num(micro_reaction.get('trade_burst_10s')),
        'buy_ratio_5s':_num(micro_reaction.get('buy_ratio_5s')),
        'buy_ratio_10s':_num(micro_reaction.get('buy_ratio_10s')),
        'buy_sustain_20s':_num(micro_reaction.get('buy_sustain_20s')),
        'price_accel_10s':_num(micro_reaction.get('price_accel_10s')),
        'price_accel_20s':_num(micro_reaction.get('price_accel_20s')),
        'sell_pressure':orderflow_ctx.get('sell_pressure_level_v2155') if isinstance(orderflow_ctx.get('sell_pressure_level_v2155'),bool) else row.get('sell_pressure') if isinstance(row.get('sell_pressure'),bool) else None,
        'spread_widening':orderflow_ctx.get('spread_widening_v2130') if isinstance(orderflow_ctx.get('spread_widening_v2130'),bool) else None,
        'sell_wall_refill':orderflow_ctx.get('sell_wall_refill_v2130') if isinstance(orderflow_ctx.get('sell_wall_refill_v2130'),bool) else None,
        'pullback_volume_contract':row.get('pullback_volume_contract') if isinstance(row.get('pullback_volume_contract'),bool) else None,
        'reclaim_volume_expand':row.get('reclaim_volume_expand') if isinstance(row.get('reclaim_volume_expand'),bool) else None,
        'market_liquidity_supportive':market_supportive,
        'micro_fresh':freshness.get('micro_fresh') if isinstance(freshness.get('micro_fresh'),bool) else None,
        'ws_fresh':freshness.get('ws_fresh') if isinstance(freshness.get('ws_fresh'),bool) else None,
        'quote_fresh':freshness.get('quote_fresh') if isinstance(freshness.get('quote_fresh'),bool) else None,
        'sample_ts':_num(orderflow_ctx.get('sample_ts')),
        'owner':'orderflow_worker',
        'decision_use_contract':'V12_EXISTING_FIELDS_ONLY_NEW_FIELDS_OBSERVATION_ONLY',
    }
    role_market['_sealed_prediction_payload']={'explanation_tags':tags.get('tags'),'price_volume_sequence':sequence,'existing_flow_inputs':existing_flow}
    timeframe_role_input=build_timeframe_role_input_from_frames(
        ticker,{'h1':h1,'h4':h4,'d1':d1},{'h1':btc_h1,'h4':btc_h4,'d1':btc_d1},role_market,nowv,
        current_price=event_price,frame_truth=ticker_truth,benchmark_truth=btc_truth,source_mode='LIVE',
    )
    # Reuse the canonical 12-material Owner values.  No duplicate 30m/1h
    # calculation is introduced for the decision layer.
    def _sealed_ready_value(name: str) -> Optional[float]:
        item=material_rows.get(name) if isinstance(material_rows.get(name),dict) else {}
        if str(item.get('state') or '').upper()!='READY' or str(item.get('source_state') or '').upper()!='READY':
            return None
        return _num(item.get('value'))
    timeframe_role_input['sealed_short_timing_materials']={
        'return_30m_atr_adjusted':_sealed_ready_value('return_30m_atr_adjusted'),
        'price_acceleration_30m':_sealed_ready_value('price_acceleration_30m'),
        'relative_strength_acceleration_1h':_sealed_ready_value('relative_strength_acceleration_1h'),
        'return_30m_change':movement_values.get('return_30m_atr_adjusted'),
        'price_acceleration_30m_change':movement_values.get('price_acceleration_30m'),
        'relative_strength_change_1h':movement_values.get('relative_strength_1h'),
        'turnover_direction_30m':contextual_states.get('turnover_acceleration_30m'),
        'owner':'strategy_v2_core.material_rows',
        'recalculated':False,
    }

    payload = {
        "schema": "rise_prediction_input",
        "state": "READY" if ready_count == len(RISE_MATERIAL_NAMES) else ("PARTIAL" if usable_count else "MISSING"),
        "owner": "strategy_v2_core",
        "ticker": ticker,
        "event_key": event_key,
        "event_bar_close_ts": event_bar_close_ts,
        "event_price": round(event_price, 12) if event_price is not None else None,
        "episode_id": episode_id,
        "episode_low_ts": episode_low_ts,
        "episode_low_price": current_swing_price,
        "pre_signal_rise_pct": round(pre_signal_rise_pct, 8) if pre_signal_rise_pct is not None else None,
        "signal_position": signal_position,
        "price_volume_sequence": sequence,
        "existing_flow_inputs": existing_flow,
        "explanation_tags": tags.get("tags"),
        "explanation_tag_labels_ko": tags.get("labels_ko"),
        "explanation_tag_evidence": tags.get("evidence"),
        "tag_overlap_allowed": True,
        "tag_used_as_gate": False,
        "prediction_contract_id": TIMEFRAME_ROLE_CONTRACT_ID,
        "timeframe_role_formula_id": TIMEFRAME_ROLE_FORMULA_ID,
        "timeframe_role_input": timeframe_role_input,
        "materials": material_rows,
        "material_values": values,
        "material_role_summary": material_role_summary,
        "positive_level_is_automatic_up": False,
        "direction_change_has_priority": True,
        "material_names": list(RISE_MATERIAL_NAMES),
        "prediction_material_count": len(RISE_MATERIAL_NAMES),
        "post_structure_material_names": list(POST_STRUCTURE_MATERIAL_NAMES),
        "target_path_stage": "POST_STRUCTURE_ONLY",
        "source_state_counts": dict(state_counts),
        "input_coverage_pct": round(ready_count / len(RISE_MATERIAL_NAMES) * 100.0, 3),
        "usable_input_count": usable_count,
        "usable_input_coverage_pct": round(usable_count / len(RISE_MATERIAL_NAMES) * 100.0, 3),
        "probability_1h_timing": None,
        "probability_4h_structure": None,
        "probability_24h_context": None,
        "probability_3h": None,
        "probability_6h": None,
        "giveback_risk": None,
        "late_capture_risk": None,
        "output_states": {},
        "model_state": "MODEL_LOADING",
        "probability_calculation_active": True,
        "weights_applied": False,
        "thresholds_applied": False,
        "prediction_used_as_gate": True,
        "candidate_preserved": True,
        "zero_fill_used": False,
        "auto_buy": False,
    }
    return _apply_live_prediction(payload,row)



def _prediction(row: Dict[str, Any], frames: Dict[str, List[Dict[str, float]]]) -> Dict[str, Any]:
    nowv = _num(
        row.get('prediction_owner_meta_v2155', {}).get('strategy_cycle_ts')
        if isinstance(row.get('prediction_owner_meta_v2155'), dict) else None,
        time.time(),
    ) or time.time()
    payload = build_rise_prediction_input(row, frames, {}, nowv)
    return {
        'schema': 'rise_prediction_observation',
        'state': payload.get('model_state'),
        'prediction_model_generation': PREDICTION_MODEL_GENERATION,
        'rise_prediction_input': payload,
        'materials': payload.get('materials'),
        'material_values': payload.get('material_values'),
        'input_coverage_pct': payload.get('input_coverage_pct'),
        'usable_input_coverage_pct': payload.get('usable_input_coverage_pct'),
        'probability_1h_timing': payload.get('probability_1h_timing'),
        'probability_4h_structure': payload.get('probability_4h_structure'),
        'probability_24h_context': payload.get('probability_24h_context'),
        'timeframe_role_evaluation': payload.get('timeframe_role_evaluation'),
        'probability_3h': payload.get('probability_3h'),
        'probability_6h': payload.get('probability_6h'),
        'giveback_risk': payload.get('giveback_risk'),
        'late_capture_risk': payload.get('late_capture_risk'),
        'prediction_model_id': payload.get('prediction_model_id'),
        'prediction_confidence_pct': payload.get('prediction_confidence_pct'),
        'prediction_confidence_state': payload.get('prediction_confidence_state'),
        'weights_applied': False,
        'thresholds_applied': False,
        'prediction_used_in_final_decision': True,
        'decision_reason': '빗썸 공식 1h·4h·24h 완료봉의 동일가중 역할증거 다수결로 판정하고 UP만 기존 구조선 계산으로 전달',
        'candidate_preserved': True,
        'auto_buy': False,
    }


def _prediction_selection(prediction: Dict[str, Any]) -> Dict[str, Any]:
    payload=prediction.get('rise_prediction_input') if isinstance(prediction.get('rise_prediction_input'),dict) else {}
    evaluation=payload.get('timeframe_role_evaluation') if isinstance(payload.get('timeframe_role_evaluation'),dict) else evaluate_timeframe_role_input(payload.get('timeframe_role_input') if isinstance(payload.get('timeframe_role_input'),dict) else {})
    return {
        'schema':'rise_prediction_primary_selection','decision':evaluation.get('decision') or 'HOLD','structure_allowed':bool(evaluation.get('structure_allowed')),
        'reason':evaluation.get('reason'),'probability_1h_timing':evaluation.get('probability_1h_timing'),'probability_4h_structure':evaluation.get('probability_4h_structure'),'probability_24h_context':evaluation.get('probability_24h_context'),
        'combined_probability_pct':evaluation.get('combined_probability_pct'),'axis_states':evaluation.get('axis_states'),'source_missing_axes':evaluation.get('source_missing_axes'),
        'usable_input_count':payload.get('usable_input_count'),'model_state':payload.get('model_state'),'model_id':TIMEFRAME_ROLE_FORMULA_ID,
        'prediction_first':True,'candidate_count_target_used':False,'forced_up_used':False,'auto_buy':False,
    }


def _combine_prediction_structure(selection: Dict[str, Any], structure: Dict[str, Any]) -> Dict[str, Any]:
    decision = str(selection.get('decision') or 'HOLD')
    structure_state = str(structure.get('state') or 'NOT_BUILT')
    if decision != 'UP':
        state = 'PREDICTION_DOWN' if decision == 'DOWN' else 'PREDICTION_HOLD'
        eligible = False
        reason = f"상승예측 {decision} · 구조선 계산 미실행 · {selection.get('reason') or '-'}"
    elif structure_state == 'STRUCTURE_READY':
        state = 'ENTRY_READY'
        eligible = True
        reason = '1h·4h·24h 역할판정 UP 통과 후 기존 동적 trigger·invalid·target 구조 준비 완료'
    else:
        state = structure_state
        eligible = False
        reason = f"1h·4h·24h 역할판정 UP 통과 · 구조 상태 {structure_state}"
    return {
        'schema': 'prediction_primary_structure_combiner',
        'state': state,
        'entry_eligible': eligible,
        'owner': 'strategy_v2_core.rise_prediction_primary',
        'reason': reason,
        'prediction_decision': decision,
        'prediction_reason': selection.get('reason'),
        'structure_state': structure_state,
        'prediction_first': True,
        'prediction_recomputed_in_paper': False,
        'prediction_used_as_gate': True,
        'candidate_preserved': True,
        'auto_buy': False,
    }

def build_combined_v2_contract(row: Dict[str, Any], frames: Dict[str, List[Dict[str, float]]], *, now_ts: Optional[float] = None) -> Dict[str, Any]:
    ts = float(now_ts if now_ts is not None else time.time())
    ticker = str(row.get("ticker") or row.get("symbol") or "").upper().replace("KRW-", "").strip()
    current = _row_price(row)
    counts = {tf: len(frames.get(tf) or []) for tf in REQUIRED_ROWS}
    missing = [tf for tf, need in REQUIRED_ROWS.items() if counts.get(tf, 0) < need]
    if current is None or current <= 0:
        missing.append("current_price")
    base: Dict[str, Any] = {
        "schema": "combined_v2_trade_contract_v2149", "version": VERSION, "build": BUILD_LABEL,
        "generation": GENERATION, "prediction_model_generation": PREDICTION_MODEL_GENERATION, "ticker": ticker, "evaluated_ts": ts,
        "candidate_preserved": True, "historical_ledger_rewritten": False,
        "legacy_structure_used": False, "legacy_entry_gate_used": False,
        "prediction_gate_active": True, "prediction_first": True, "decision_combiner_active": True, "auto_buy": False,
    }

    # Single active order: prediction on the whole universe first. Structure is
    # never calculated for DOWN/HOLD rows, but every row remains in the canonical
    # snapshot for missed-rise review.
    prediction = _prediction(row, frames)
    selection = _prediction_selection(prediction)
    prediction["primary_selection"] = dict(selection)
    rise_input = prediction.get("rise_prediction_input") if isinstance(prediction.get("rise_prediction_input"), dict) else {}
    rise_input["primary_selection"] = dict(selection)
    rise_input["prediction_used_as_gate"] = True
    rise_input["candidate_preserved"] = True

    if selection.get("structure_allowed") is not True:
        structure = {
            "schema": "prediction_primary_structure_not_built",
            "state": "NOT_BUILT_PREDICTION_FIRST",
            "reason": selection.get("reason"),
            "frame_counts": counts,
            "completed_candles_only": True,
        }
        combiner = _combine_prediction_structure(selection, structure)
        base.update({
            "state": combiner["state"], "decision_key": None, "plan_key": None,
            "material_diagnosis": {"state": combiner["state"], "owner": "strategy_v2_core.rise_prediction_primary", "missing": [], "candidate_quality_failed": False},
            "structure": structure, "prediction": prediction, "prediction_selection": selection, "decision_combiner": combiner,
            "execution_policy": {
                "schema": "combined_v2_execution_policy_v2149", "actual_price_required": True,
                "fresh_spread_slippage_required": True, "after_cost_reward_must_be_positive": True,
                "entry_must_remain_in_first_half_to_t1": True, "fixed_legacy_rr_room_chase_thresholds_used": False,
                "prediction_recomputed_in_paper": False, "decision_combiner_active": True,
                "prediction_calculated_in_strategy": True, "prediction_used_in_strategy": True,
            },
        })
        return base

    if missing:
        structure = {"state": "DATA_MISSING", "frame_counts": counts, "completed_candles_only": True}
        combiner = _combine_prediction_structure(selection, structure)
        base.update({
            "state": "DATA_MISSING", "decision_key": None, "plan_key": None,
            "material_diagnosis": {"state": "DATA_MISSING", "owner": "candle_worker" if "current_price" not in missing else "feature_worker", "missing": sorted(set(missing)), "candidate_quality_failed": False},
            "structure": structure,
            "prediction": prediction,
            "prediction_selection": selection,
            "decision_combiner": combiner,
        })
        return base

    m5, m15, m30, h1, h2, h4 = (frames[tf] for tf in ("m5", "m15", "m30", "h1", "h2", "h4"))
    atr5, atr15, atr30, atr1h, atr2h, atr4h = (_atr(x) for x in (m5, m15, m30, h1, h2, h4))
    major_axes = [x for x in (_trend_axis(h4), _trend_axis(h2)) if x is not None]
    setup_axes = [x for x in (_trend_axis(h1), _trend_axis(m30)) if x is not None]
    major_axis = sum(major_axes) / len(major_axes) if major_axes else 0.0
    setup_axis = sum(setup_axes) / len(setup_axes) if setup_axes else 0.0

    entry_levels = _level_candidates(frames, ("m5", "m15"), "resistance")
    entry_clusters = _cluster_levels(entry_levels, atr_ref=max(atr5, atr15 * 0.6), current=current)
    setup_levels = _level_candidates(frames, ("m30", "h1"), "support")
    support_clusters = _cluster_levels(setup_levels, atr_ref=max(atr30, atr1h * 0.55), current=current)
    target_levels = _level_candidates(frames, ("h2", "h4"), "resistance")
    target_clusters = _cluster_levels(target_levels, atr_ref=max(atr2h, atr4h * 0.55), current=current)

    # v2159 Trigger correctness repair.
    # - A resistance is a zone, so breakout ownership is the zone HIGH, never the center.
    # - A completed breakout remains valid for up to three completed 5m bars while closes hold above it.
    # - Among equally near zones (same clustering tolerance), prefer the better confirmed/recent zone.
    recent_rows = m5[-6:]
    recent_closes = [float(r["c"]) for r in recent_rows]
    recent_lows = [float(r["l"]) for r in recent_rows]
    # v2166: the 5m close remains the primary confirmation, but completed 1m/3m
    # candles may confirm the same already-built WAIT_TRIGGER contract earlier.
    # Forming candles are still excluded by the candle owner.
    m1 = list(frames.get("m1") or [])
    m3 = list(frames.get("m3") or [])
    short_frames_ready_v2166 = bool(len(m1) >= 3 or len(m3) >= 2)
    trigger_obj: Optional[Dict[str, Any]] = None
    trigger_state = "WAIT_TRIGGER"
    trigger_event_ts: Optional[float] = None
    trigger_mode = "WAIT_BREAK"
    trigger_break_index: Optional[int] = None
    trigger_selection_policy = "ZONE_HIGH_RECENT_HOLD_QUALITY_WITHIN_NEAREST_CLUSTER_BAND_V2159"

    def zone_line(zone: Dict[str, Any]) -> float:
        return float(zone.get("high") or zone.get("price") or 0.0)

    def zone_quality(zone: Dict[str, Any]) -> Tuple[float, float, float, float]:
        return (
            float(len(zone.get("timeframes") or [])),
            float(zone.get("source_count") or 0),
            float(zone.get("score") or 0.0),
            float(zone.get("last_source_ts") or 0.0),
        )

    fired: List[Tuple[float, Tuple[float, float, float, float], Dict[str, Any], str, int]] = []
    for zone in entry_clusters:
        level = zone_line(zone)
        if level <= 0 or len(recent_closes) < 2:
            continue
        break_idx: Optional[int] = None
        # Only the last three completed bars can own a still-valid breakout.
        first_idx = max(1, len(recent_closes) - 4)
        for idx in range(first_idx, len(recent_closes)):
            if recent_closes[idx - 1] <= level < recent_closes[idx]:
                break_idx = idx
        crossed_now = break_idx == len(recent_closes) - 1
        held_after_break = break_idx is not None and all(c > level for c in recent_closes[break_idx:])
        retested_now = (
            any(c > level for c in recent_closes[-5:-1])
            and recent_lows[-1] <= level + max(atr5 * 0.18, current * 0.0008)
            and recent_closes[-1] > level
        )
        early_mode = None
        early_event_ts = None
        early_tolerance = max(atr5 * 0.10, current * 0.0005)
        if len(m1) >= 3:
            c0, c1, c2 = (float(m1[-3]["c"]), float(m1[-2]["c"]), float(m1[-1]["c"]))
            l1, l2 = float(m1[-2]["l"]), float(m1[-1]["l"])
            if c0 <= level < c1 and c2 > level and min(l1, l2) >= level - early_tolerance:
                early_mode = "EARLY_M1_DOUBLE_HOLD"
                early_event_ts = float(m1[-2]["ts"])
        if early_mode is None and len(m3) >= 2:
            c0, c1 = float(m3[-2]["c"]), float(m3[-1]["c"])
            l1 = float(m3[-1]["l"])
            if c0 <= level < c1 and l1 >= level - early_tolerance:
                early_mode = "EARLY_M3_BREAK_HOLD"
                early_event_ts = float(m3[-1]["ts"])
        if crossed_now:
            mode = "COMPLETED_BREAK"
            event_idx = len(recent_closes) - 1
        elif retested_now:
            mode = "COMPLETED_RETEST_HOLD"
            event_idx = len(recent_closes) - 1
        elif held_after_break:
            mode = "COMPLETED_BREAK_HOLD"
            event_idx = int(break_idx)
        elif early_mode is not None and early_event_ts is not None:
            mode = early_mode
            event_idx = -1
        else:
            continue
        event_ts = float(early_event_ts if mode.startswith("EARLY_") else recent_rows[event_idx]["ts"])
        fired.append((event_ts, zone_quality(zone), zone, mode, event_idx))

    if fired:
        fired.sort(key=lambda item: (item[0], item[1]), reverse=True)
        trigger_event_ts, _, trigger_obj, trigger_mode, trigger_break_index = fired[0]
        trigger_state = "TRIGGER_FIRED"
    else:
        above = [z for z in entry_clusters if zone_line(z) >= current * 0.999]
        if above:
            nearest = min(zone_line(z) for z in above)
            selection_band = max(max(atr5, atr15 * 0.6) * 0.22, current * 0.0012)
            near_band = [z for z in above if zone_line(z) <= nearest + selection_band]
            trigger_obj = max(near_band, key=lambda z: (zone_quality(z), -abs(zone_line(z) - current)))
            trigger_state = "WAIT_TRIGGER"
        else:
            below = [z for z in entry_clusters if zone_line(z) < current]
            if below:
                trigger_obj = max(below, key=lambda z: zone_line(z))
                trigger_state = "TRIGGER_PASSED"
                trigger_mode = "OLD_LEVEL_ALREADY_CONSUMED"
    if trigger_obj is None:
        base.update({
            "state": "NO_TRIGGER_STRUCTURE", "decision_key": None, "plan_key": None,
            "material_diagnosis": {"state": "NO_TRIGGER_STRUCTURE", "owner": "strategy_v2_core_v2161", "candidate_quality_failed": False},
            "structure": {"state": "NO_TRIGGER_STRUCTURE", "frame_counts": counts, "major_trend_axis": major_axis, "setup_trend_axis": setup_axis},
        })
        base["prediction"] = prediction
        base["prediction_selection"] = selection
        base["decision_combiner"] = _combine_prediction_structure(selection, base["structure"])
        return base

    trigger = float(trigger_obj.get("high") or trigger_obj["price"])
    support_candidates = [z for z in support_clusters if float(z["high"]) < trigger and (int(z.get("source_count") or 0) >= 2 or "h1" in (z.get("timeframes") or []))]
    support = max(support_candidates, key=lambda z: float(z["price"]), default=None)
    if support is None:
        structure = {"state": "NO_INVALID_STRUCTURE", "trigger": trigger, "trigger_state": trigger_state, "frame_counts": counts, "major_trend_axis": major_axis, "setup_trend_axis": setup_axis}
        base.update({"state": "NO_INVALID_STRUCTURE", "decision_key": None, "plan_key": None, "material_diagnosis": {"state": "NO_INVALID_STRUCTURE", "owner": "strategy_v2_core_v2161", "candidate_quality_failed": False}, "structure": structure})
        base["prediction"] = prediction
        base["prediction_selection"] = selection
        base["decision_combiner"] = _combine_prediction_structure(selection, structure)
        return base

    invalid_buffer = max(atr30 * 0.22, atr1h * 0.10, trigger * 0.0008)
    invalid = float(support["low"]) - invalid_buffer
    target_floor = max(trigger, current)
    targets = [z for z in target_clusters if float(z["low"]) > target_floor * 1.00001]
    if not targets:
        structure = {"state": "NO_REACHABLE_T1", "trigger": trigger, "execution_invalid": invalid, "trigger_state": trigger_state, "frame_counts": counts, "major_trend_axis": major_axis, "setup_trend_axis": setup_axis}
        base.update({"state": "NO_REACHABLE_T1", "decision_key": None, "plan_key": None, "material_diagnosis": {"state": "NO_REACHABLE_T1", "owner": "strategy_v2_core_v2161", "candidate_quality_failed": False}, "structure": structure})
        base["prediction"] = prediction
        base["prediction_selection"] = selection
        base["decision_combiner"] = _combine_prediction_structure(selection, structure)
        return base
    targets.sort(key=lambda z: float(z["low"]))
    t1 = float(targets[0]["low"])
    t2 = float(targets[1]["low"]) if len(targets) > 1 else None
    reference = current if trigger_state == "TRIGGER_FIRED" else trigger
    if not (invalid < reference < t1):
        structure_state = "PRICE_ORDER_INVALID"
    elif trigger_state == "WAIT_TRIGGER":
        structure_state = "WAIT_TRIGGER"
    elif trigger_state == "TRIGGER_PASSED":
        structure_state = "TRIGGER_PASSED"
    else:
        structure_state = "STRUCTURE_READY"

    risk_pct = (reference - invalid) / reference * 100.0
    room_pct = (t1 - reference) / reference * 100.0
    rr = room_pct / risk_pct if risk_pct > 0 else None
    fraction = max(0.0, (current - trigger) / max(t1 - trigger, 1e-12))
    # v2166 candidate-quality axis: after early detection is enabled, a remaining
    # non-retest entry that already consumed a large part of T1 and arrived after
    # an outsized 15m/30m run is held for a retest instead of chased.
    change_15m = _num(row.get("change_15m"), 0.0) or 0.0
    change_30m = _num(row.get("change_30m"), 0.0) or 0.0
    pre_entry_run_pct_v2166 = max(change_15m, change_30m)
    atr15_pct_v2166 = (atr15 / current * 100.0) if current > 0 else 0.0
    late_run_limit_v2166 = max(2.0, atr15_pct_v2166 * 2.4)
    entry_timing_wait_v2166 = bool(
        trigger_state == "TRIGGER_FIRED"
        and trigger_mode not in {"COMPLETED_RETEST_HOLD"}
        and fraction >= 0.32
        and pre_entry_run_pct_v2166 >= late_run_limit_v2166
    )
    if entry_timing_wait_v2166:
        structure_state = "ENTRY_TIMING_WAIT"
    vol_now = sum(float(r.get("v") or 0.0) for r in m5[-3:]) / 3.0
    vol_base = _median([float(r.get("v") or 0.0) for r in m5[-30:-3]], default=0.0)
    volume_axis = _clip(math.log(max(vol_now, 1e-12) / max(vol_base, 1e-12)) / 1.2, -1.0, 1.0) if vol_base > 0 else 0.0
    trigger_quality = (
        0.75 if trigger_state == "TRIGGER_FIRED" and trigger_mode == "COMPLETED_RETEST_HOLD"
        else 0.62 if trigger_state == "TRIGGER_FIRED" and trigger_mode == "EARLY_M1_DOUBLE_HOLD"
        else 0.58 if trigger_state == "TRIGGER_FIRED" and trigger_mode == "EARLY_M3_BREAK_HOLD"
        else 0.60 if trigger_state == "TRIGGER_FIRED" and trigger_mode == "COMPLETED_BREAK_HOLD"
        else 0.45 if trigger_state == "TRIGGER_FIRED"
        else -0.15 if trigger_state == "WAIT_TRIGGER"
        else -0.65
    )
    last_bar=m5[-1];bar_range=max(float(last_bar["h"])-float(last_bar["l"]),1e-12)
    breakout_body_pct=abs(float(last_bar["c"])-float(last_bar["o"]))/bar_range*100.0
    breakout_upper_wick_pct=(float(last_bar["h"])-max(float(last_bar["o"]),float(last_bar["c"])))/bar_range*100.0
    breakout_close_position_pct=(float(last_bar["c"])-float(last_bar["l"]))/bar_range*100.0
    trigger_hold_above_pct=(float(last_bar["c"])-trigger)/trigger*100.0 if trigger>0 else None
    atr_pct={"m5":atr5/current*100.0,"m15":atr15/current*100.0,"m30":atr30/current*100.0,"h1":atr1h/current*100.0,"h2":atr2h/current*100.0,"h4":atr4h/current*100.0}
    tr_now=_median([float(r["h"])-float(r["l"]) for r in m5[-5:]],default=0.0)
    tr_base=_median([float(r["h"])-float(r["l"]) for r in m5[-30:-5]],default=0.0)
    short_atr_expansion_ratio=(tr_now/tr_base) if tr_base>0 else None
    invalid_noise_ref=max(atr_pct["m30"],atr_pct["h1"]*0.55,0.000001)
    target_atr_ref=max(atr_pct["h2"],atr_pct["h4"]*0.55,0.000001)
    invalid_noise_multiple=risk_pct/invalid_noise_ref if invalid_noise_ref>0 else None
    target_atr_multiple=room_pct/target_atr_ref if target_atr_ref>0 else None
    plan_seed = {
        "ticker": ticker, "trigger": round(trigger, 12), "invalid": round(invalid, 12), "t1": round(t1, 12),
        "t2": round(t2, 12) if t2 else None, "trigger_state": trigger_state,
        "trigger_event_ts": trigger_event_ts, "h4_ts": float(h4[-1]["ts"]), "m5_ts": float(m5[-1]["ts"]),
    }
    plan_key = "v2149-plan:" + _plan_hash(plan_seed)
    structure = {
        "schema": "combined_v2_structure_v2149", "state": structure_state, "reference_entry": round(reference, 12),
        "current_price": round(current, 12), "trigger": round(trigger, 12), "trigger_state": trigger_state,
        "trigger_mode": trigger_mode, "trigger_event_ts": trigger_event_ts,
        "trigger_selection_policy_v2159": trigger_selection_policy,
        "trigger_breakout_line_source_v2159": "entry_zone_high",
        "trigger_valid_hold_bars_v2159": 3,
        "trigger_early_completed_frames_v2166": ["m1", "m3"],
        "trigger_short_frames_ready_v2166": short_frames_ready_v2166,
        "pretrigger_contract_ready_v2166": True,
        "entry_timing_wait_v2166": entry_timing_wait_v2166,
        "pre_entry_run_pct_v2166": round(pre_entry_run_pct_v2166, 6),
        "late_run_limit_pct_v2166": round(late_run_limit_v2166, 6),
        "trigger_break_index_v2159": trigger_break_index,
        "trigger_zone_score_v2159": round(float(trigger_obj.get("score") or 0.0), 6),
        "trigger_zone_source_count_v2159": int(trigger_obj.get("source_count") or 0),
        "trigger_zone_timeframes_v2159": list(trigger_obj.get("timeframes") or []),
        "entry_zone_low": round(float(trigger_obj["low"]), 12), "entry_zone_high": round(float(trigger_obj["high"]), 12),
        "execution_invalid": round(invalid, 12), "structural_support": round(float(support["price"]), 12),
        "target_t1": round(t1, 12), "target_t2": round(t2, 12) if t2 else None,
        "risk_pct": round(risk_pct, 6), "t1_room_pct": round(room_pct, 6), "rr_t1": round(rr, 6) if rr is not None else None,
        "entry_fraction_to_t1": round(fraction, 6),
        "target_path_consumed_ratio": round(fraction, 6),
        "target_path_owner": "strategy_v2_core.structure",
        "target_path_stage": "POST_PREDICTION_STRUCTURE",
        "target_path_used_by_primary_prediction": False,
        "major_trend_axis": round(major_axis, 6),
        "setup_trend_axis": round(setup_axis, 6), "trigger_quality_axis": round(trigger_quality, 6),
        "volume_expansion_axis": round(volume_axis, 6), "frame_counts": counts,
        "breakout_body_pct":round(breakout_body_pct,6),"breakout_upper_wick_pct":round(breakout_upper_wick_pct,6),
        "breakout_close_position_pct":round(breakout_close_position_pct,6),"trigger_hold_above_pct":round(trigger_hold_above_pct,6) if trigger_hold_above_pct is not None else None,
        "trigger_age_sec":round(max(0.0,ts-trigger_event_ts),3) if trigger_event_ts else None,"atr_pct_v2155":{k:round(v,6) for k,v in atr_pct.items()},
        "short_atr_expansion_ratio":round(short_atr_expansion_ratio,6) if short_atr_expansion_ratio is not None else None,
        "invalid_noise_multiple":round(invalid_noise_multiple,6) if invalid_noise_multiple is not None else None,
        "target_atr_multiple":round(target_atr_multiple,6) if target_atr_multiple is not None else None,
        "completed_candles_only": True, "forming_candle_excluded": True,
        "timeframe_contract": {"major": "4h/2h", "setup": "1h/30m", "trigger": "15m/5m", "execution": "1m/quote"},
        "source": "strategy_v2_core_v2168_only", "legacy_structure_used": False,
    }
    post_structure_observation = {
        "target_path_consumed_ratio": structure.get("target_path_consumed_ratio"),
        "owner": structure.get("target_path_owner"),
        "stage": structure.get("target_path_stage"),
        "used_by_primary_prediction": False,
        "structure_state": structure.get("state"),
    }
    prediction["post_structure_observation"] = post_structure_observation
    rise_payload = prediction.get("rise_prediction_input") if isinstance(prediction.get("rise_prediction_input"), dict) else {}
    rise_payload["post_structure_observation"] = post_structure_observation
    combiner = _combine_prediction_structure(selection, structure)
    state = str(combiner.get("state") or "ENGINE_ERROR")
    decision_key = None
    if state == "ENTRY_READY" and trigger_event_ts:
        decision_key = f"v2149:{ticker}:{plan_key.split(':')[-1]}:{int(trigger_event_ts * 1000)}"
    base.update({
        "state": state, "decision_key": decision_key, "plan_key": plan_key,
        "material_diagnosis": {"state": "READY" if state in {"ENTRY_READY", "WAIT_TRIGGER", "TRIGGER_PASSED", "ENTRY_TIMING_WAIT"} else state, "owner": str(combiner.get("owner") or "strategy_v2_core.structure"), "candidate_quality_failed": False, "missing": []},
        "structure": structure, "prediction": prediction, "prediction_selection": selection, "decision_combiner": combiner,
        "execution_policy": {
            "schema": "combined_v2_execution_policy_v2149", "actual_price_required": True,
            "fresh_spread_slippage_required": True, "after_cost_reward_must_be_positive": True,
            "entry_must_remain_in_first_half_to_t1": True, "fixed_legacy_rr_room_chase_thresholds_used": False,
            "prediction_recomputed_in_paper": False, "decision_combiner_active": True,
            "prediction_calculated_in_strategy": True, "prediction_used_in_strategy": True,
        },
    })
    return base



def compact_combined_v2_contract(value: Any) -> Dict[str, Any]:
    if not isinstance(value, dict):
        return {}
    structure = value.get("structure") if isinstance(value.get("structure"), dict) else {}
    prediction = value.get("prediction") if isinstance(value.get("prediction"), dict) else {}
    combiner = value.get("decision_combiner") if isinstance(value.get("decision_combiner"), dict) else {}
    rise_input = prediction.get("rise_prediction_input") if isinstance(prediction.get("rise_prediction_input"), dict) else {}
    structure_keys = (
        "state", "reference_entry", "current_price", "trigger", "trigger_state", "trigger_mode", "trigger_event_ts",
        "entry_zone_low", "entry_zone_high", "execution_invalid", "structural_support", "target_t1", "target_t2",
        "risk_pct", "t1_room_pct", "rr_t1", "entry_fraction_to_t1", "target_path_consumed_ratio", "target_path_owner", "target_path_stage", "target_path_used_by_primary_prediction", "major_trend_axis", "setup_trend_axis",
        "trigger_quality_axis", "volume_expansion_axis", "frame_counts", "completed_candles_only", "forming_candle_excluded",
        "timeframe_contract", "source", "legacy_structure_used", "entry_timing_wait_v2166", "pre_entry_run_pct_v2166",
        "late_run_limit_pct_v2166", "trigger_selection_policy_v2159", "trigger_breakout_line_source_v2159",
        "trigger_valid_hold_bars_v2159", "trigger_break_index_v2159", "trigger_zone_score_v2159",
        "trigger_zone_source_count_v2159", "trigger_zone_timeframes_v2159",
    )
    compact_input = {
        "schema": rise_input.get("schema"),
        "state": rise_input.get("state"),
        "owner": rise_input.get("owner"),
        "ticker": rise_input.get("ticker"),
        "event_key": rise_input.get("event_key"),
        "event_bar_close_ts": rise_input.get("event_bar_close_ts"),
        "event_price": rise_input.get("event_price"),
        "episode_id": rise_input.get("episode_id"),
        "episode_low_ts": rise_input.get("episode_low_ts"),
        "episode_low_price": rise_input.get("episode_low_price"),
        "pre_signal_rise_pct": rise_input.get("pre_signal_rise_pct"),
        "signal_position": rise_input.get("signal_position"),
        "price_volume_sequence": rise_input.get("price_volume_sequence"),
        "explanation_tags": rise_input.get("explanation_tags"),
        "explanation_tag_labels_ko": rise_input.get("explanation_tag_labels_ko"),
        "explanation_tag_evidence": rise_input.get("explanation_tag_evidence"),
        "tag_overlap_allowed": True,
        "tag_used_as_gate": False,
        "materials": rise_input.get("materials"),
        "material_values": rise_input.get("material_values"),
        "material_role_summary": rise_input.get("material_role_summary"),
        "positive_level_is_automatic_up": False,
        "direction_change_has_priority": True,
        "material_names": rise_input.get("material_names"),
        "prediction_material_count": rise_input.get("prediction_material_count"),
        "post_structure_material_names": rise_input.get("post_structure_material_names"),
        "target_path_stage": rise_input.get("target_path_stage"),
        "post_structure_observation": rise_input.get("post_structure_observation"),
        "source_state_counts": rise_input.get("source_state_counts"),
        "input_coverage_pct": rise_input.get("input_coverage_pct"),
        "prediction_contract_id": rise_input.get("prediction_contract_id"),
        "timeframe_role_formula_id": rise_input.get("timeframe_role_formula_id"),
        "timeframe_role_input": rise_input.get("timeframe_role_input"),
        "timeframe_role_evaluation": rise_input.get("timeframe_role_evaluation"),
        "primary_selection": rise_input.get("primary_selection"),
        "probability_1h_timing": rise_input.get("probability_1h_timing"),
        "probability_4h_structure": rise_input.get("probability_4h_structure"),
        "probability_24h_context": rise_input.get("probability_24h_context"),
        "probability_3h": rise_input.get("probability_3h"),
        "probability_6h": rise_input.get("probability_6h"),
        "giveback_risk": rise_input.get("giveback_risk"),
        "late_capture_risk": rise_input.get("late_capture_risk"),
        "predicted_direction_3h": rise_input.get("predicted_direction_3h"),
        "predicted_direction_6h": rise_input.get("predicted_direction_6h"),
        "output_states": rise_input.get("output_states") or {},
        "model_state": rise_input.get("model_state"),
        "prediction_model_id": rise_input.get("prediction_model_id"),
        "prediction_model_generated_ts": rise_input.get("prediction_model_generated_ts"),
        "prediction_confidence_pct": rise_input.get("prediction_confidence_pct"),
        "prediction_confidence_state": rise_input.get("prediction_confidence_state"),
        "prediction_evidence_count": rise_input.get("prediction_evidence_count"),
        "usable_input_count": rise_input.get("usable_input_count"),
        "usable_input_coverage_pct": rise_input.get("usable_input_coverage_pct"),
        "weights_applied": False,
        "thresholds_applied": False,
        "prediction_used_as_gate": True,
        "zero_fill_used": False,
        "auto_buy": False,
    }
    return {
        "schema": "combined_v2_trade_contract_compact",
        "version": value.get("version"),
        "build": value.get("build"),
        "generation": value.get("generation"),
        "prediction_model_generation": value.get("prediction_model_generation"),
        "state": value.get("state"),
        "ticker": value.get("ticker"),
        "evaluated_ts": value.get("evaluated_ts"),
        "decision_key": value.get("decision_key"),
        "plan_key": value.get("plan_key"),
        "material_diagnosis": value.get("material_diagnosis"),
        "structure": {key: structure.get(key) for key in structure_keys},
        "prediction_selection": value.get("prediction_selection") if isinstance(value.get("prediction_selection"), dict) else (prediction.get("primary_selection") if isinstance(prediction.get("primary_selection"), dict) else {}),
        "prediction": {
            "schema": prediction.get("schema"),
            "state": prediction.get("state"),
            "prediction_model_generation": prediction.get("prediction_model_generation"),
            "rise_prediction_input": compact_input,
            "input_coverage_pct": prediction.get("input_coverage_pct"),
            "probability_1h_timing": prediction.get("probability_1h_timing"),
            "probability_4h_structure": prediction.get("probability_4h_structure"),
            "probability_24h_context": prediction.get("probability_24h_context"),
            "timeframe_role_evaluation": prediction.get("timeframe_role_evaluation"),
            "probability_3h": prediction.get("probability_3h"),
            "probability_6h": prediction.get("probability_6h"),
            "giveback_risk": prediction.get("giveback_risk"),
            "late_capture_risk": prediction.get("late_capture_risk"),
            "prediction_model_id": prediction.get("prediction_model_id"),
            "prediction_confidence_pct": prediction.get("prediction_confidence_pct"),
            "prediction_confidence_state": prediction.get("prediction_confidence_state"),
            "weights_applied": False,
            "thresholds_applied": False,
            "prediction_used_in_final_decision": True,
            "decision_reason": prediction.get("decision_reason"),
            "candidate_preserved": True,
            "prediction_first": True,
            "auto_buy": False,
        },
        "prediction_evidence": {
            "rise_prediction_input": compact_input,
            "materials": compact_input.get("materials"),
            "material_values": compact_input.get("material_values"),
            "source_state_counts": compact_input.get("source_state_counts"),
            "input_coverage_pct": compact_input.get("input_coverage_pct"),
            "zero_fill_used": False,
        },
        "decision_combiner": {
            "state": combiner.get("state"),
            "entry_eligible": combiner.get("entry_eligible"),
            "owner": combiner.get("owner"),
            "reason": combiner.get("reason"),
            "structure_state": combiner.get("structure_state"),
            "prediction_state": combiner.get("prediction_state"),
            "prediction_used_as_gate": True,
            "candidate_preserved": True,
        },
        "execution_policy": value.get("execution_policy"),
        "prediction_gate_active": True,
        "candidate_preserved": True,
        "auto_buy": False,
    }


def prediction_contract_identity(role_contract_hash: Optional[str] = None) -> Dict[str, Any]:
    payload = {
        "schema": "rise_prediction_material_contract",
        "model_generation": PREDICTION_MODEL_GENERATION,
        "material_names": list(RISE_MATERIAL_NAMES),
        "material_role_contract": MATERIAL_ROLE_CONTRACT,
        "positive_level_is_automatic_up": False,
        "direction_change_has_priority": True,
        "weights_applied": False,
        "thresholds_applied": False,
        "prediction_used_as_gate": True,
    }
    digest = hashlib.sha256(json.dumps(payload, ensure_ascii=False, sort_keys=True, separators=(",", ":")).encode("utf-8")).hexdigest()
    return {**payload, "contract_hash": digest, "ready": True, "auto_buy": False}

