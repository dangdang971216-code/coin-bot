v2235 적용 후 먼저 /gguard_restart로 Guard v2.6.58을 활성화하십시오.
그 다음 /gupgrade_bundle coinbot_update_v2236.zip을 실행하십시오.
v2234 ZIP은 다시 실행하지 않습니다.
