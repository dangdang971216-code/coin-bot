coinbot v1477 - exact release rebuild using the stable v1469-v1471 deployment shape

Purpose
- Repackage the completed v1476 candidate-flow recovery as one exact Main/Paper/Strategy release.
- Keep literal runtime identities in each source file so Guard can verify the same versions it deploys.
- Force active aliases to be replaced and restarted from this manifest.
- Preserve fixed active status filenames and the S2 quality-shadow lane.

Runtime order
S3 observe -> S2 recheck/shadow -> new-event S1 -> Paper -> trigger -> safety -> selected -> OPEN.

No strategy thresholds, RR, trigger, invalid, target, exit contract, or OPEN limits changed.
Auto-buy remains OFF.
