v1459 candidate contract field restore. Auto-buy OFF. Restores missing target/invalid/RR/trigger_reached aliases from canonical structure context/levels. No criteria or threshold relaxation.
