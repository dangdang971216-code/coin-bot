# v1116 Paper heap owner closeout

## 증상
v1115 적용 후 Strategy cycle은 13.3초로 정상화됐지만 Paper RSS는 1124.5MB, 회귀 추세 약 +502MB/h로 `RSS_SUSTAINED_HIGH`가 남았다. 기존 phase/helper probe에서는 단일 helper가 25MB 이상을 반복 보유한다는 증거가 없었다.

## 실제 원인 구분 방법
- exact commit이 아닌 cycle/exit-monitor 종료 경계에서만 측정한다.
- RSS 768MB 미만이면 아무 작업도 하지 않는다.
- 60초 cooldown으로 반복 gc/trim을 막는다.
- 고RSS이면 기존 canonical `_v1081_release_heap`을 1회 실행한다.
- 64MB 이상 반환되면 allocator retention 증거로 표시한다.
- 의미 있는 RSS 반환이 없고 Python allocated blocks가 증가하면 live-reference 성장 의심으로 남긴다.

## 변경하지 않은 영역
- select_candidates / open_position / update_position / CLOSED commit 함수 AST 동일
- 품질 gate/rank, trigger, invalid, target, actual-entry RR, spread, slippage, 비용 변경 없음
- OPEN 30 / cycle 3 변경 없음
- OPEN/CLOSED/decision/performance 원장 변경 없음
- 자동매수 OFF

## 서버 검수
같은 PID로 30~60분 관찰한다. 순간 RSS가 아니라 `paper_heap_reclaim_status_v1116.json` 전후 RSS와 Guard 추세를 함께 본다. 회수 효과가 없으면 DONE 처리하지 않고 live-reference owner 추적으로 이어간다.
