from __future__ import annotations
import ast, hashlib, importlib.util, json
from pathlib import Path

ROOT=Path(__file__).resolve().parent
OLD=ROOT/'paper_bot_v1.015.py'
NEW=ROOT/'paper_bot_v1.016.py'

def load(path: Path, name: str):
    spec=importlib.util.spec_from_file_location(name,path)
    mod=importlib.util.module_from_spec(spec)
    assert spec and spec.loader
    spec.loader.exec_module(mod)
    return mod

def fn_hash(path: Path, name: str) -> str:
    tree=ast.parse(path.read_text(encoding='utf-8'))
    found=[n for n in tree.body if isinstance(n,(ast.FunctionDef,ast.AsyncFunctionDef)) and n.name==name]
    assert found, name
    return hashlib.sha256(ast.dump(found[-1],include_attributes=False).encode()).hexdigest()

def main():
    old=load(OLD,'paper_old_v1116_test')
    new=load(NEW,'paper_new_v1116_test')
    assert new.VERSION=='paper_bot_v1.016'
    assert new.PAPER_VERSION==new.VERSION
    assert new.BUILD_LABEL=='v1116_paper_heap_owner_closeout_2026-06-28'

    unchanged=['_exit_decision_spine','select_candidates__L23042','open_position__L23309','update_position','commit_closed_position_exact','persist_open_positions']
    hashes={}
    for name in unchanged:
        a,b=fn_hash(OLD,name),fn_hash(NEW,name)
        assert a==b,(name,a,b)
        hashes[name]=a

    writes=[]
    new._v1116_write_reclaim_status=lambda payload: writes.append(dict(payload)) or True
    new._V1116_LAST_RECLAIM_MONO=0.0
    new._V1116_RECLAIM_COUNT=0
    new._EXACT_COMMIT_DEPTH=0
    new._v1081_rss_bytes=lambda: 900*1024*1024
    new._v1116_allocated_blocks=lambda: 123456
    new._v1081_release_heap=lambda reason:{
        'reason':reason,'before_rss_bytes':900*1024*1024,'after_rss_bytes':500*1024*1024,
        'released_rss_bytes':400*1024*1024,'gc_collected':7,'malloc_trim_result':1,'error':None,
    }
    r=new._v1116_maybe_reclaim_heap('unit')
    assert r['attempted'] is True
    assert r['allocator_retention_proven'] is True
    assert r['released_rss_bytes']==400*1024*1024
    assert writes and writes[-1]['scope']=='unit'

    # Cooldown blocks repeated trim.
    r2=new._v1116_maybe_reclaim_heap('unit2')
    assert r2['attempted'] is False and r2['blocked_reason']=='cooldown'

    # Exact commit is never crossed.
    new._V1116_LAST_RECLAIM_MONO=0.0
    new._EXACT_COMMIT_DEPTH=1
    r3=new._v1116_maybe_reclaim_heap('exact')
    assert r3['attempted'] is False and r3['blocked_reason']=='exact_commit_active'

    # Low RSS does not reclaim.
    new._EXACT_COMMIT_DEPTH=0
    new._V1116_LAST_RECLAIM_MONO=0.0
    new._v1081_rss_bytes=lambda: 400*1024*1024
    r4=new._v1116_maybe_reclaim_heap('low')
    assert r4['attempted'] is False and r4['blocked_reason']=='rss_below_trigger'

    tree=ast.parse(NEW.read_text(encoding='utf-8'))
    defs=[n.name for n in tree.body if isinstance(n,(ast.FunctionDef,ast.AsyncFunctionDef))]
    assert defs.count('load_json')==1
    assert defs.count('save_json')==1

    result={
        'ok':True,'version':new.VERSION,'build':new.BUILD_LABEL,
        'unchanged_function_hashes':hashes,
        'allocator_reclaim_test':{'released_mb':400,'proven':True},
        'exact_commit_block_test':True,'cooldown_test':True,'low_rss_test':True,
        'load_json_defs':defs.count('load_json'),'save_json_defs':defs.count('save_json'),
    }
    print(json.dumps(result,ensure_ascii=False,indent=2))

if __name__=='__main__':
    main()
