from __future__ import annotations
import importlib.util, json, tempfile, sys, argparse
from pathlib import Path
ap=argparse.ArgumentParser(); ap.add_argument('version_dir'); ap.add_argument('worker'); ap.add_argument('tag'); args=ap.parse_args()
basecode=Path(args.version_dir); sys.path.insert(0,str(basecode))
def load(name,path):
    spec=importlib.util.spec_from_file_location(name,path); mod=importlib.util.module_from_spec(spec); sys.modules[name]=mod; spec.loader.exec_module(mod); return mod
mod=load('review_under_test',basecode/args.worker)
def row(ticker,cycle,stage='S1',price=100.0):
    return {'ticker':ticker,'s_stage':stage,'candidate_grade':stage,'candidate_pipeline_cycle_id_v1150':cycle,'current_price':price,'entry_price':price,'rank_score':50.0,'candidate_decision_key':'d-'+ticker,'candidate_key':'c-'+ticker,
      'dynamic_structure_plan_v1212':{'trigger':{'price':price,'source':'x'},'invalid':{'price':price*.98,'source':'x'},'target':{'price':price*1.03,'source':'x'}},
      'v1211_structure_shadow_v1222':{'source_exact':True,'trigger':{'price':price,'source':'old'},'invalid':{'price':price*.985,'source':'old'},'target':{'price':price*1.04,'source':'old'}}}
def wrj(p,o): p.write_text(json.dumps(o,ensure_ascii=False),encoding='utf-8')
def wrr(p,rs): p.write_text(''.join(json.dumps(x,ensure_ascii=False)+'\n' for x in rs),encoding='utf-8')
with tempfile.TemporaryDirectory() as td:
    base=Path(td); cycle='cycle-A'; commit='commit-A'; wrr(base/'paper_candidates_latest.jsonl',[row('AAA',cycle)])
    req={'pipeline_cycle_id':cycle,'candidate_commit_id':commit,'candidate_rows':1,'s1_count':1,'s2_count':0,'s3_count':0,'created_ts':1,'committed_handoff_completed_ts':1}
    wrj(base/'review_observation_request_v1181.json',req)
    wrj(base/'clean_strategy_candidate_pipeline_status_v1150.json',{'state':'NORMAL','complete':True,'cycle_id':cycle,'candidate_commit_id':commit,'all_required_commits_v1150':True})
    wrj(base/'canonical_review_snapshot_v1181.json',{})
    mod.update_version_score_review=lambda *a,**k:{'paired_matchup_v1241':{'entry_ready_pairs':1},'paper_exact_exit_replay_v1242':{}}
    orig=mod.build_review_snapshot
    if args.tag=='v1245':
      def wrapped(basep,request=None):
        wrr(Path(basep)/'paper_candidates_latest.jsonl',[row('BBB','cycle-B','S3',99)])
        return orig(basep,request=request)
    else:
      def wrapped(basep,request=None,candidate_rows=None):
        wrr(Path(basep)/'paper_candidates_latest.jsonl',[row('BBB','cycle-B','S3',99)])
        return orig(basep,request=request,candidate_rows=candidate_rows)
    mod.build_review_snapshot=wrapped
    result=mod.process_once(base,force=True)
    snap=json.loads((base/'canonical_review_snapshot_v1181.json').read_text())
    status=json.loads((base/'clean_review_worker_status.json').read_text())
    print(json.dumps({'result':{k:result.get(k) for k in ('processed','reason','check')},'snapshot_source':snap.get('source'),'candidate':snap.get('candidate'),'status':{k:status.get(k) for k in ('health_state','phase','candidate_rows','last_pipeline_cycle_id')}},ensure_ascii=False))
