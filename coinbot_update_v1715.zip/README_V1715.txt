v1715: restore 1150s-style fast Paper selection by consuming current sealed S1 hold preview; no trading criteria or auto-buy change.
