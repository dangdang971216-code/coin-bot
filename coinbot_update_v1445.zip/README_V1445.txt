v1445_COMMAND_ROUTER_PAPER_STATUS_FAILSAFE_FIX

목적:
- v1444 Main 병목지도/공개명령 블록이 main() 아래에 있어 실행되지 않던 문제 수정
- Paper no-progress shadow cache 변수명 오류 수정
- shadow/status writer 오류가 Paper 본체를 죽이지 않도록 fail-safe 처리

변경 없음:
- Gate/TTL/RR/trigger/invalid/target/청산/S1/S2/S3/OPEN/자동매수 변경 없음
- 35초 기준 완화 없음
- stale 강제통과 없음
- 자동매수 OFF

검수:
/gupgrade_bundle
/grelease_verify
/gpaperlog 120

메인봇:
/bottleneck_map
/pstatus
/candidate_summary
/entry_latency_core
/shadow_board
/version_score
/errorlog
