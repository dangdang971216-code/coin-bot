#!/usr/bin/env python3
# -*- coding: utf-8 -*-

from __future__ import annotations
import json, os, time, math, traceback, urllib.request
from pathlib import Path
from typing import Any, Dict, List, Tuple, Optional
BASE_DIR = Path(os.getenv("TRADING_BOT_DIR", "/home/dangdang971216/trading_bot"))
def now_ts() -> float: return time.time()
def now_text(ts: Optional[float]=None) -> str: return time.strftime("%Y-%m-%d %H:%M:%S", time.localtime(ts or now_ts()))
def fnum(*vals: Any, default: float=0.0) -> float:
    for v in vals:
        try:
            if v is None or v == "": continue
            return float(str(v).replace(",", "").replace("%", ""))
        except Exception: continue
    return default
def load_json(path: Path, default: Any=None) -> Any:
    try:
        if not path.exists(): return default
        return json.loads(path.read_text(encoding="utf-8", errors="ignore"))
    except Exception: return default
def save_json(path: Path, obj: Any) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    tmp = path.with_suffix(path.suffix + ".tmp")
    tmp.write_text(json.dumps(obj, ensure_ascii=False, separators=(",", ":"), default=str), encoding="utf-8")
    os.replace(tmp, path)
def append_jsonl(path: Path, obj: Dict[str, Any]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("a", encoding="utf-8") as f:
        f.write(json.dumps(obj, ensure_ascii=False, separators=(",", ":"), default=str)+"\n")
def write_jsonl_atomic(path: Path, rows: List[Dict[str, Any]]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    tmp = path.with_suffix(path.suffix + ".tmp")
    with tmp.open("w", encoding="utf-8") as f:
        for r in rows:
            f.write(json.dumps(r, ensure_ascii=False, separators=(",", ":"), default=str)+"\n")
    os.replace(tmp, path)
def read_jsonl(path: Path, max_lines: int=1000) -> List[Dict[str, Any]]:
    if not path.exists(): return []
    try:
        lines = path.read_text(encoding="utf-8", errors="ignore").splitlines()
        if max_lines and len(lines) > max_lines: lines = lines[-max_lines:]
        out=[]
        for ln in lines:
            try:
                if ln.strip():
                    o=json.loads(ln)
                    if isinstance(o,dict): out.append(o)
            except Exception: pass
        return out
    except Exception: return []
def append_error(path: Path, where: str, exc: BaseException) -> None:
    try:
        path.parent.mkdir(parents=True, exist_ok=True)
        with path.open("a", encoding="utf-8") as f:
            f.write(f"[{now_text()}] {where}: {exc.__class__.__name__}: {exc}\n")
            f.write(traceback.format_exc()[-1500:]+"\n")
    except Exception: pass
def ticker_norm(x: Any) -> str:
    t = str(x or "").strip().upper().replace("/", "-").replace("_", "-")
    parts=[p for p in t.split("-") if p]
    if len(parts)>=2:
        non=[p for p in parts if p != "KRW"]
        t = non[-1] if non else parts[-1]
    if t.endswith("KRW") and len(t)>3: t=t[:-3]
    return t.strip().upper()
def pct(a: float, b: float) -> float: return ((a-b)/b*100.0) if b else 0.0
def age_sec(path: Path) -> float:
    try: return max(0.0, now_ts()-path.stat().st_mtime)
    except Exception: return 999999.0
def map_rows(obj: Any) -> Dict[str, Dict[str, Any]]:
    if isinstance(obj, dict) and isinstance(obj.get("rows"), list): obj = obj.get("rows")
    elif isinstance(obj, dict) and isinstance(obj.get("rows"), dict): obj = obj.get("rows")
    elif isinstance(obj, dict) and isinstance(obj.get("cache"), dict): obj = obj.get("cache")
    out: Dict[str, Dict[str, Any]] = {}
    if isinstance(obj, list):
        for r in obj:
            if isinstance(r, dict):
                t=ticker_norm(r.get("ticker") or r.get("symbol") or r.get("market"))
                if t: out[t]=r
    elif isinstance(obj, dict):
        for k,v in obj.items():
            t=ticker_norm(k)
            if t and isinstance(v, dict):
                vv=dict(v); vv.setdefault("ticker", t); out[t]=vv
    return out

VERSION="strategy_worker_v0.24"
INTERVAL_SEC=float(os.getenv("STRATEGY_WORKER_INTERVAL_SEC","2.0"))
STATUS=BASE_DIR/"clean_strategy_worker_status.json"; ERROR=BASE_DIR/"clean_strategy_worker_error.log"
FEATURE=BASE_DIR/"clean_feature_cache.json"; ORDERFLOW=BASE_DIR/"clean_orderflow_summary_cache.json"; REGIME=BASE_DIR/"clean_market_regime_cache.json"; RISK=BASE_DIR/"clean_risk_filter_cache.json"
PAPER=BASE_DIR/"paper_candidates.jsonl"; PAPER_LATEST=BASE_DIR/"paper_candidates_latest.jsonl"; SUMMARY=BASE_DIR/"clean_strategy_s_summary.json"; REJECT=BASE_DIR/"clean_strategy_s_reject_summary.json"; HANDOFF=BASE_DIR/"clean_strategy_paper_handoff_status.json"; WS_TARGETS=BASE_DIR/"clean_ws_targets.json"; MICRO_TARGETS=BASE_DIR/"clean_micro_targets.json"; MICRO_URGENT=BASE_DIR/"clean_micro_urgent_targets.json"; PRIORITY_REQ=BASE_DIR/"clean_strategy_priority_requests.json"; TARGET_ROUTER_QUEUE=BASE_DIR/"clean_target_router_queue.json"
CANDIDATE_TTL_SEC=float(os.getenv("STRATEGY_PAPER_CANDIDATE_TTL_SEC","120"))
STRATEGIES={"money_reaccel_s":"돈흐름 재가속 S","leader_momentum_s":"주도추세 지속 S","breakout_early_s":"돌파 초입 S","sweep_vwap_recovery_s":"저점 VWAP 회복 S","surge_rebreak_s":"급등 후 재돌파 S","leader_flow_adaptive_hold_s":"주도흐름 유동보유 S"}
MAIN_DEPLOY_VERSION="v2.13.377"
MAIN_BOT_VERSION="수익형 v2.13.377"
def write_status(state:str, **extra:Any)->None:
    # v0.13: 성공 사이클이 돌면 이전 error 표시가 남지 않게 상태를 매번 완전히 덮어쓴다.
    obj={"version":VERSION,"state":state,"pid":os.getpid(),"updated_ts":now_ts(),"updated_text":now_text(),"last_error":""}
    obj.update(extra)
    if state == "error" and "error" in extra:
        obj["last_error"] = str(extra.get("error") or "")[:240]
    save_json(STATUS,obj)

def _event_created_ts(ev: Dict[str, Any]) -> float:
    return fnum(ev.get("created_at"), ev.get("candidate_created_at"), ev.get("source_created_at"), ev.get("detected_ts"), ev.get("event_ts"), ev.get("ts"), ev.get("timestamp"), default=0.0)

def _normalize_paper_event(ev: Dict[str, Any], ttl_sec: float = CANDIDATE_TTL_SEC) -> Dict[str, Any]:
    row = dict(ev or {})
    ts = _event_created_ts(row) or now_ts()
    ticker = ticker_norm(row.get("ticker") or row.get("market") or row.get("symbol"))
    skey = str(row.get("strategy_key") or row.get("strategy_bucket_primary") or "strategy_s")
    scan_id = row.get("scan_id") or row.get("source_scan_id") or f"strategy_s_{int(ts // 60)}"
    eid = row.get("event_id") or row.get("id") or row.get("event_key") or f"{ticker}:{skey}:{int(ts // 60)}"
    row.update({
        "ticker": ticker,
        "market": f"KRW-{ticker}" if ticker else row.get("market"),
        "symbol": f"{ticker}_KRW" if ticker else row.get("symbol"),
        "created_at": ts,
        "candidate_created_at": ts,
        "source_created_at": ts,
        "detected_ts": ts,
        "event_ts": ts,
        "created_at_text": row.get("created_at_text") or now_text(ts),
        "detected_at_text": row.get("detected_at_text") or now_text(ts),
        "updated_ts": now_ts(),
        "expires_at": row.get("expires_at") or (ts + ttl_sec),
        "event_id": eid,
        "event_key": eid,
        "scan_id": scan_id,
        "lane": "strict",
        "paper_bot_open": True,
        "open_eligible": True,
        "trade_ready": True,
        "candidate_grade": "S",
        "grade": "S",
    })
    ctx = row.get("entry_context") if isinstance(row.get("entry_context"), dict) else {}
    # paper_bot의 pre-open check가 top-level 또는 entry_context를 모두 볼 수 있게 복제한다.
    for k in ("ws_fresh", "micro_fresh", "spread_pct", "buy_ratio", "sell_pressure", "orderflow_score"):
        if k in ctx and row.get(k) in (None, ""):
            row[k] = ctx.get(k)
    return row

def _paper_event_fresh(ev: Dict[str, Any], nowv: Optional[float] = None) -> bool:
    nowv = nowv or now_ts()
    exp = fnum(ev.get("expires_at"), default=0.0)
    ts = _event_created_ts(ev)
    if exp > 0:
        return exp >= nowv
    return ts > 0 and (nowv - ts) <= CANDIDATE_TTL_SEC

def _paper_dedupe_key(ev: Dict[str, Any]) -> str:
    t = ticker_norm(ev.get("ticker") or ev.get("market") or ev.get("symbol"))
    sk = str(ev.get("strategy_key") or ev.get("strategy_bucket_primary") or "strategy_s")
    return f"{t}:{sk}"

def persist_paper_handoff(events: List[Dict[str, Any]], evaluated: int = 0) -> Tuple[List[Dict[str, Any]], int]:
    """S 후보 handoff를 휘발성 latest 한 번으로 날리지 않는다.
    - 새 S 후보에는 created_at/detected_ts/expires_at/event_id를 고정한다.
    - 새 루프에서 S가 0이어도 TTL 내 기존 S 후보는 latest에 유지한다.
    - archive paper_candidates.jsonl에는 신규 event_id만 append한다.
    """
    nowv = now_ts()
    new_rows = [_normalize_paper_event(e) for e in (events or [])]
    old_latest = [_normalize_paper_event(e) for e in read_jsonl(PAPER_LATEST, max_lines=120)]
    old_archive = [_normalize_paper_event(e) for e in read_jsonl(PAPER, max_lines=500)]
    merged: Dict[str, Dict[str, Any]] = {}
    # 오래된 후보가 새 후보를 덮지 않게 old 먼저, new 나중에 넣는다.
    for ev in old_archive + old_latest + new_rows:
        if not _paper_event_fresh(ev, nowv):
            continue
        key = _paper_dedupe_key(ev)
        if not key:
            continue
        prev = merged.get(key)
        if (prev is None) or fnum(ev.get("score"), default=0.0) >= fnum(prev.get("score"), default=0.0) or _event_created_ts(ev) >= _event_created_ts(prev):
            merged[key] = ev
    latest = sorted(merged.values(), key=lambda e: (fnum(e.get("score"), default=0.0), _event_created_ts(e)), reverse=True)[:40]
    write_jsonl_atomic(PAPER_LATEST, latest)
    recent_ids = {str(r.get("event_id") or r.get("event_key") or "") for r in read_jsonl(PAPER, max_lines=800)}
    appended = 0
    for ev in new_rows:
        eid = str(ev.get("event_id") or ev.get("event_key") or "")
        if eid and eid not in recent_ids:
            append_jsonl(PAPER, ev)
            recent_ids.add(eid)
            appended += 1
    save_json(HANDOFF, {
        "version": VERSION,
        "updated_ts": nowv,
        "updated_text": now_text(nowv),
        "evaluated": evaluated,
        "new_s_count": len(new_rows),
        "paper_latest_count": len(latest),
        "archive_appended": appended,
        "latest_tickers": [e.get("ticker") for e in latest[:20]],
        "ttl_sec": CANDIDATE_TTL_SEC,
        "note": "v0.7: 정보요청은 S/S근접/high만 target_router에 넘김. 일반 정보부족은 queue 폭주 방지를 위해 요청하지 않음.",
    })
    return latest, appended

def risk_bad(t:str)->List[str]:
    r=load_json(RISK,{}) or {}; cd=(r.get("cooldown") or {}) if isinstance(r,dict) else {}
    out=[]
    if t in cd: out.append("최근반복손실/하드손실")
    if t in set(r.get("open_tickers",[]) if isinstance(r,dict) else []): out.append("이미OPEN중")
    return out
def common_hard(row:Dict[str,Any], of:Dict[str,Any])->List[str]:
    """cheap/기본 차단만 본다.
    WS/micro 부족은 여기서 붙이지 않는다.
    v0.8: 붙일 필요도 없는 후보까지 정보부족으로 보이는 문제를 막기 위해
    정보부족은 cheap gate 통과 후보에게만 별도 부여한다.
    """
    hard=[]; t=ticker_norm(row.get("ticker")); hard+=risk_bad(t)
    if row.get("major_watch"): hard.append("대형주는시장참고")
    if bool(of.get("micro_fresh")):
        spread=fnum(of.get("spread_pct"),default=0)
        buy=fnum(of.get("buy_ratio"),default=0)
        if spread>0.28: hard.append(f"스프레드넓음 {spread:.2f}%")
        if buy and buy<0.58: hard.append(f"매수체결약함 {buy:.2f}")
        if of.get("sell_pressure"): hard.append("매도벽/매도체결압력")
    if fnum(row.get("turnover_24h"))<250_000_000: hard.append("거래대금부족")
    if row.get("long_upper_wick"): hard.append("윗꼬리위험")
    if fnum(row.get("day_pos_pct"),default=50)>94 and fnum(row.get("change_5m"))<0.2: hard.append("고점끝물위험")
    return hard[:8]

def orderflow_info_bad(of:Dict[str,Any])->List[str]:
    """v0.9: strategy는 WS 단독 fresh가 아니라 표준 시세(quote_fresh)를 본다.
    quote_fresh는 orderflow_worker가 WS 또는 scanner/feature REST 현재가로 만든 canonical 시세다.
    micro는 호가·체결 판단 재료라 별도로 필요하다.
    """
    info=[]
    if not bool(of.get("quote_fresh") or of.get("ws_fresh")):
        info.append("시세정보보강대기")
    if not bool(of.get("micro_fresh")):
        info.append("micro정보보강대기")
    return info[:4]
def eval_money(r,o):
    no=[]
    if fnum(r.get("change_3m"))<0.25 or fnum(r.get("change_5m"))<0.35: no.append("3/5분재가속부족")
    if fnum(r.get("vwap_gap_pct"))<-0.05 or fnum(r.get("ema5_gap_pct"))<-0.08: no.append("VWAP/EMA유지부족")
    if not r.get("volume_expanding"): no.append("캔들거래량확장부족")
    # micro가 fresh일 때만 매수체결비를 전략 실패로 본다. fresh가 없으면 정보보강대기로 분리한다.
    if o.get("micro_fresh") and fnum(o.get("buy_ratio"))<0.65: no.append("매수체결우세부족")
    return (not no, ["돈흐름재가속","3/5분재가속","VWAP/EMA유지","체결우세"], no)
def eval_leader(r,o):
    no=[]
    if fnum(r.get("change_15m"))<0.65 or fnum(r.get("change_30m"))<0.65: no.append("15/30분주도부족")
    if fnum(r.get("relative_strength_pct"))<0.3: no.append("시장대비강도부족")
    if fnum(r.get("vwap_gap_pct"))<0 or fnum(r.get("ema5_gap_pct"))<0: no.append("VWAP/EMA위치부족")
    if r.get("market_mode") == "약함": no.append("장세약함")
    return (not no, ["15/30분주도","시장대비강함","VWAP/EMA위"], no)
def eval_breakout(r,o):
    no=[]
    if not r.get("breakout_hint"): no.append("돌파캔들미확인")
    if fnum(r.get("recent_high_gap_pct"))<-0.15: no.append("돌파후유지부족")
    if fnum(r.get("change_15m"))>5.0 and not r.get("volume_expanding"): no.append("끝물추격위험")
    return (not no, ["돌파초입","거래량확장","고점돌파유지"], no)
def eval_sweep(r,o):
    no=[]
    if not r.get("sweep_reclaim_hint"): no.append("저점쓸림회복미확인")
    if fnum(r.get("vwap_gap_pct"))<-0.05: no.append("VWAP회복부족")
    if fnum(r.get("recent_low_rebound_pct"))<0.4: no.append("저점방어반등부족")
    return (not no, ["저점이탈실패","VWAP회복","매수회복"], no)
def eval_surge(r,o):
    no=[]
    if fnum(r.get("change_15m"))<1.2: no.append("1차상승부족")
    if fnum(r.get("change_3m"))<0.15: no.append("재돌파시도부족")
    if fnum(r.get("recent_high_gap_pct"))<-0.25: no.append("고점재접근부족")
    if r.get("long_upper_wick"): no.append("윗꼬리반락위험")
    return (not no, ["급등후재돌파","얕은눌림","체결재상승"], no)


def eval_adaptive_hold(r,o):
    """v0.19/v367 주도흐름 유동보유 전략.
    시간 고정이 아니라 0~5분 검증, 5~30분 확인, 30~120분 확장으로 나눠 본다.
    """
    no=[]
    ch1=fnum(r.get("change_1m"), r.get("price_change_1m"), default=0.0)
    ch3=fnum(r.get("change_3m"), r.get("price_change_3m"), default=0.0)
    ch5=fnum(r.get("change_5m"), r.get("price_change_5m"), default=0.0)
    ch15=fnum(r.get("change_15m"), r.get("price_change_15m"), default=0.0)
    ch30=fnum(r.get("change_30m"), r.get("price_change_30m"), default=0.0)
    vwap=fnum(r.get("vwap_gap_pct"), default=-9.0)
    ema=fnum(r.get("ema5_gap_pct"), r.get("ma5_gap_pct"), default=-9.0)
    rel=fnum(r.get("relative_strength_pct"), r.get("relative_strength"), default=0.0)
    day=fnum(r.get("day_pos_pct"), r.get("current_close_pos_ratio"), default=50.0)
    high_gap=fnum(r.get("recent_high_gap_pct"), r.get("below_high_pct"), default=-9.0)
    money=fnum(r.get("turnover_24h"), default=0.0)
    buy=fnum(o.get("buy_ratio"), o.get("micro_trade_buy_ratio_30"), default=0.0)
    spread=fnum(o.get("spread_pct"), default=99.0)
    if not ((ch3 >= 0.20 and ch5 >= 0.25) or (ch15 >= 0.70 and ch30 >= 0.40) or (ch5 >= 0.80 and ch15 >= 0.40)):
        no.append("흐름유지부족")
    if vwap < -0.10 or ema < -0.15:
        no.append("VWAP/EMA유지부족")
    if rel < -1.0 and ch5 < 1.0:
        no.append("시장대비약함")
    if money < 300_000_000:
        no.append("거래대금부족")
    if o.get("micro_fresh") and buy < 0.58:
        no.append("매수체결최소부족")
    if o.get("micro_fresh") and spread > 0.30:
        no.append("스프레드과다")
    if day >= 97.0 and high_gap >= -0.05 and ch1 <= 0.05:
        no.append("고점끝물재확인필요")
    if ch5 >= 12.0 and ema >= 6.0:
        no.append("급등과열재확인필요")
    return (not no, ["주도흐름유지","유동보유","VWAP/EMA방어","시간확장후보"], no)

def _pickv(src: Dict[str, Any], *keys: str, default: Any = None) -> Any:
    for k in keys:
        if isinstance(src, dict) and src.get(k) not in (None, "", "-"):
            return src.get(k)
    return default

def _boolv(v: Any) -> bool:
    if isinstance(v, bool): return v
    return str(v).lower() in {"1", "true", "yes", "ok", "fresh", "신선"}

def _entry_snapshot(row: Dict[str, Any], of: Dict[str, Any], skey: str, reasons: List[str], ts: float, eid: str) -> Dict[str, Any]:
    """v0.11: 진입 당시 전략 판단/복기용 표준 스냅샷.
    조건을 바로 조이는 용도가 아니라, OPEN/CLOSED/score/review가 같은 근거를 보게 하는 저장 schema다.
    """
    t = ticker_norm(row.get("ticker") or row.get("market") or row.get("symbol"))
    snap = {
        "schema": "entry_snapshot_v1",
        "version": VERSION,
        "captured_ts": ts,
        "captured_text": now_text(ts),
        "event_id": eid,
        "ticker": t,
        "price": fnum(row.get("current_price"), row.get("price"), of.get("quote_price"), default=0.0),
        "strategy": {
            "primary_key": skey,
            "primary_label": STRATEGIES.get(skey, skey),
            "reasons": list(reasons or [])[:8],
            "decision_stage": "S1_immediate_candidate",
            "decision_note": "v0.11 정보스냅샷: 조건 변경 없이 S 진입 당시 재료를 보존",
        },
        "price_flow": {
            "change_30s": _pickv(row, "change_30s", "price_change_30s"),
            "change_1m": _pickv(row, "change_1m", "price_change_1m", "change_1"),
            "change_3m": _pickv(row, "change_3m", "price_change_3m", "change_3"),
            "change_5m": _pickv(row, "change_5m", "price_change_5m", "change_5"),
            "change_15m": _pickv(row, "change_15m", "price_change_15m", "change_15"),
            "change_30m": _pickv(row, "change_30m", "price_change_30m", "change_30"),
            "price_reaction_score": _pickv(row, "price_reaction_score", "price_recheck_pct"),
        },
        "position": {
            "vwap_gap_pct": _pickv(row, "vwap_gap_pct"),
            "ema5_gap_pct": _pickv(row, "ema5_gap_pct", "ma5_gap_pct"),
            "ema12_gap_pct": _pickv(row, "ema12_gap_pct"),
            "ema21_gap_pct": _pickv(row, "ema21_gap_pct"),
            "recent_high_gap_pct": _pickv(row, "recent_high_gap_pct", "below_high_pct", "below_30m_high_pct"),
            "recent_low_gap_pct": _pickv(row, "recent_low_gap_pct", "from_low_pct", "from_30m_low_pct"),
            "day_pos_pct": _pickv(row, "day_pos_pct", "current_close_pos_ratio"),
            "recent_low_rebound_pct": _pickv(row, "recent_low_rebound_pct", "low_defense_pct"),
            "breakout_hint": bool(row.get("breakout_hint")),
            "breakout_hold_hint": _pickv(row, "breakout_hold_hint", "breakout_retain_hint"),
            "sweep_reclaim_hint": bool(row.get("sweep_reclaim_hint")),
            "long_upper_wick": bool(row.get("long_upper_wick")),
            "upper_wick_pct": _pickv(row, "upper_wick_pct", "current_upper_wick_pct"),
        },
        "money_flow": {
            "turnover_24h": _pickv(row, "turnover_24h"),
            "turnover_1m": _pickv(row, "turnover_1m", "money_flow_1m"),
            "turnover_3m": _pickv(row, "turnover_3m", "money_flow_3m"),
            "turnover_5m": _pickv(row, "turnover_5m", "money_flow_5m"),
            "volume_expanding": bool(row.get("volume_expanding")),
            "volume_expansion_ratio": _pickv(row, "volume_expansion_ratio", "vol_ratio"),
            "relative_strength_pct": _pickv(row, "relative_strength_pct", "relative_strength"),
            "market_mode": _pickv(row, "market_mode"),
            "market_pressure": _pickv(row, "market_pressure"),
        },
        "orderflow": {
            "quote_fresh": _boolv(of.get("quote_fresh") or of.get("ws_fresh")),
            "quote_source": _pickv(of, "quote_source"),
            "quote_price": _pickv(of, "quote_price"),
            "quote_age_sec": _pickv(of, "quote_age_sec"),
            "ws_fresh": _boolv(of.get("ws_fresh")),
            "ws_age_sec": _pickv(of, "ws_age_sec"),
            "ws_gap_pct": _pickv(of, "ws_gap_pct", "quote_gap_pct", "current_price_ws_gap_pct"),
            "micro_fresh": _boolv(of.get("micro_fresh")),
            "micro_age_sec": _pickv(of, "micro_age_sec"),
            "spread_pct": _pickv(of, "spread_pct"),
            "buy_ratio": _pickv(of, "buy_ratio", "micro_trade_buy_ratio_30"),
            "buy_ratio_30s": _pickv(of, "buy_ratio_30s", "buy_ratio_30", "micro_trade_buy_ratio_30"),
            "buy_ratio_1m": _pickv(of, "buy_ratio_1m", "buy_ratio_60"),
            "bid_wall_ratio": _pickv(of, "bid_wall_ratio", "micro_bid_ask_wall_ratio"),
            "ask_wall_ratio": _pickv(of, "ask_wall_ratio"),
            "sell_pressure": bool(of.get("sell_pressure") or of.get("ask_wall_pressure") or of.get("sell_trade_pressure")),
            "ask_wall_pressure": bool(of.get("ask_wall_pressure")),
            "sell_trade_pressure": bool(of.get("sell_trade_pressure")),
            "slippage_est_pct": _pickv(of, "slippage_est_pct", "tick_pct_est"),
            "orderflow_score": _pickv(of, "orderflow_score"),
        },
        "risk": {
            "major_watch": bool(row.get("major_watch")),
            "quality_risk_tags": row.get("quality_risk_tags") if isinstance(row.get("quality_risk_tags"), list) else [],
            "hard_flags": common_hard(row, of),
            "recent_loss_or_hard": "최근반복손실/하드손실" in common_hard(row, of),
            "high_end_risk": bool(fnum(row.get("day_pos_pct"), default=50)>94 and fnum(row.get("change_5m"))<0.2),
            "sell_pressure": bool(of.get("sell_pressure") or of.get("ask_wall_pressure") or of.get("sell_trade_pressure")),
        },
        "review_after_entry": {
            "track_30s_peak_pct": None,
            "track_1m_peak_pct": None,
            "track_3m_peak_pct": None,
            "peak_reach_sec": None,
            "note": "paper_bot 청산감시가 진입 후 반응/최고수익 도달시간을 보강할 수 있는 자리",
        },
    }
    # 자주 쓰는 값은 flat alias도 같이 보존해 paper_bot 구/신 경로가 모두 읽게 한다.
    flat = {
        "entry_snapshot_schema": snap["schema"],
        "entry_snapshot_version": snap["version"],
                "change_30s": snap["price_flow"].get("change_30s"),
        "change_1m": snap["price_flow"].get("change_1m"),
        "change_3m": snap["price_flow"].get("change_3m"),
        "change_5m": snap["price_flow"].get("change_5m"),
        "change_15m": snap["price_flow"].get("change_15m"),
        "change_30m": snap["price_flow"].get("change_30m"),
        "price_change_3m": snap["price_flow"].get("change_3m"),
        "price_change_5m": snap["price_flow"].get("change_5m"),
        "vwap_gap_pct": snap["position"].get("vwap_gap_pct"),
        "ema5_gap_pct": snap["position"].get("ema5_gap_pct"),
        "recent_high_gap_pct": snap["position"].get("recent_high_gap_pct"),
        "recent_low_gap_pct": snap["position"].get("recent_low_gap_pct"),
        "day_pos_pct": snap["position"].get("day_pos_pct"),
        "relative_strength_pct": snap["money_flow"].get("relative_strength_pct"),
        "relative_strength": snap["money_flow"].get("relative_strength_pct"),
        "turnover_24h": snap["money_flow"].get("turnover_24h"),
        "money_flow_1m": snap["money_flow"].get("turnover_1m"),
        "money_flow_3m": snap["money_flow"].get("turnover_3m"),
        "money_flow_5m": snap["money_flow"].get("turnover_5m"),
        "volume_expanding": snap["money_flow"].get("volume_expanding"),
        "quote_fresh": snap["orderflow"].get("quote_fresh"),
        "quote_source": snap["orderflow"].get("quote_source"),
        "quote_price": snap["orderflow"].get("quote_price"),
        "quote_age_sec": snap["orderflow"].get("quote_age_sec"),
        "ws_fresh": snap["orderflow"].get("ws_fresh"),
        "ws_age_sec": snap["orderflow"].get("ws_age_sec"),
        "ws_gap_pct": snap["orderflow"].get("ws_gap_pct"),
        "current_price_ws_gap_pct": snap["orderflow"].get("ws_gap_pct"),
        "micro_fresh": snap["orderflow"].get("micro_fresh"),
        "micro_age_sec": snap["orderflow"].get("micro_age_sec"),
        "spread_pct": snap["orderflow"].get("spread_pct"),
        "micro_spread_pct": snap["orderflow"].get("spread_pct"),
        "buy_ratio": snap["orderflow"].get("buy_ratio"),
        "micro_trade_buy_ratio_30": snap["orderflow"].get("buy_ratio"),
        "micro_buy_ratio_sustain_1m": snap["orderflow"].get("buy_ratio_1m"),
        "bid_wall_ratio": snap["orderflow"].get("bid_wall_ratio"),
        "micro_bid_ask_wall_ratio": snap["orderflow"].get("bid_wall_ratio"),
        "ask_wall_ratio": snap["orderflow"].get("ask_wall_ratio"),
        "sell_pressure": snap["orderflow"].get("sell_pressure"),
        "micro_ask_wall_pressure": snap["orderflow"].get("ask_wall_pressure"),
        "micro_sell_trade_pressure": snap["orderflow"].get("sell_trade_pressure"),
        "slippage_est_pct": snap["orderflow"].get("slippage_est_pct"),
        "orderflow_score": snap["orderflow"].get("orderflow_score"),
        "quality_risk_tags": snap["risk"].get("quality_risk_tags"),
    }
    snap["flat"] = flat
    return snap

def _snapshot_flat_aliases(snap: Dict[str, Any]) -> Dict[str, Any]:
    if isinstance(snap, dict) and isinstance(snap.get("flat"), dict):
        # v0.13: flat alias 안에는 snapshot 본체를 넣지 않는다.
        # flat -> entry_snapshot -> flat 순환참조가 생기면 json 저장에서 Circular reference로 worker가 error 상태가 된다.
        out = dict(snap.get("flat") or {})
        out.pop("entry_snapshot", None)
        return out
    return {}

def _minimal_entry_snapshot(row: Dict[str, Any], of: Dict[str, Any], skey: str, reasons: List[str], ts: float, eid: str, err: str = "") -> Dict[str, Any]:
    t = ticker_norm(row.get("ticker") or of.get("ticker"))
    snap = {
        "schema": "entry_snapshot_v1", "version": VERSION, "snapshot_status": "partial",
        "snapshot_error": err[:180], "ticker": t, "event_id": eid, "created_at": ts, "created_at_text": now_text(ts),
        "price_flow": {}, "position": {}, "money_flow": {},
        "orderflow": {
            "quote_fresh": bool(of.get("quote_fresh") or of.get("ws_fresh")),
            "ws_fresh": bool(of.get("ws_fresh")), "micro_fresh": bool(of.get("micro_fresh")),
            "spread_pct": of.get("spread_pct"), "buy_ratio": of.get("buy_ratio"),
            "bid_wall_ratio": of.get("bid_wall_ratio"), "ask_wall_ratio": of.get("ask_wall_ratio"),
        },
        "risk": {"hard_flags": common_hard(row, of)},
        "strategy": {"primary_key": skey, "primary_label": STRATEGIES.get(skey, skey), "reasons": reasons[:8]},
        "review_after_entry": {},
    }
    snap["flat"] = {
        "entry_snapshot_schema": snap["schema"], "entry_snapshot_version": snap["version"],         "quote_fresh": snap["orderflow"].get("quote_fresh"), "ws_fresh": snap["orderflow"].get("ws_fresh"),
        "micro_fresh": snap["orderflow"].get("micro_fresh"), "spread_pct": snap["orderflow"].get("spread_pct"),
        "buy_ratio": snap["orderflow"].get("buy_ratio"), "bid_wall_ratio": snap["orderflow"].get("bid_wall_ratio"),
        "ask_wall_ratio": snap["orderflow"].get("ask_wall_ratio"),
        "snapshot_status": snap["snapshot_status"], "snapshot_error": snap["snapshot_error"],
    }
    return snap


def _v361_adaptive_hold_profile(row: Dict[str, Any], of: Dict[str, Any], skey: str) -> Dict[str, Any]:
    """유동 보유형 후보별 청산/복기 프로필."""
    ch5=fnum(row.get('change_5m'), row.get('price_change_5m'), default=0.0)
    ch15=fnum(row.get('change_15m'), row.get('price_change_15m'), default=0.0)
    ch30=fnum(row.get('change_30m'), row.get('price_change_30m'), default=0.0)
    rel=fnum(row.get('relative_strength_pct'), row.get('relative_strength'), default=0.0)
    vwap=fnum(row.get('vwap_gap_pct'), default=0.0)
    ema=fnum(row.get('ema5_gap_pct'), row.get('ma5_gap_pct'), default=0.0)
    strong = (ch15 >= 1.2 and ch30 >= 0.8 and rel >= 0.3) or (ch5 >= 1.2 and ch15 >= 0.8 and vwap >= 0 and ema >= 0)
    ext_tp = 2.20 if strong else 1.80
    max_min = 120 if strong else 75
    return {
        'strategy_family': 'adaptive_hold',
        'strategy_family_label': '주도흐름 유동보유',
        'hold_model': 'adaptive_0_5_30_120',
        'phase_1': '0~5분 진입검증: 가격반응/체결지속/VWAP 방어 없으면 빠른정리',
        'phase_2': '5~30분 수익확인: +0.5~1.2% 도달·VWAP/EMA 유지 시 보유',
        'phase_3': '30~120분 확장: +1.2% 이상 도달 후 추세 유지 시 보호익절로 연장',
        'take_profit_pct': 1.20,
        'extended_target_pct': ext_tp,
        'extended_take_profit_pct': ext_tp,
        'protect_trigger_pct': 0.70,
        'protect_floor_pct': 0.35,
        'stop_loss_pct': -0.60,
        'hard_loss_guard_pct': -0.90,
        'time_exit_minutes': max_min,
        'time_exit_min': max_min,
        'early_validation_minutes': 5,
        'mid_validation_minutes': 30,
        'adaptive_hold_note': '나쁜 후보는 0~5분 검증 실패로 빨리 정리하고, +1.2% 이상 간 후보만 30~120분 확장 관찰',
    }

def build_event(row, of, skey, reasons):
    ts = now_ts()
    t = ticker_norm(row.get("ticker"))
    price = fnum(row.get("current_price"), row.get("price"), of.get("quote_price"), default=0)
    label = STRATEGIES.get(skey, skey)
    eid = f"{t}:{skey}:{int(ts // 60)}"
    try:
        entry_snapshot = _entry_snapshot(row, of, skey, reasons, ts, eid)
    except Exception as exc:
        append_error(ERROR, "entry_snapshot_build", exc)
        entry_snapshot = _minimal_entry_snapshot(row, of, skey, reasons, ts, eid, f"{exc.__class__.__name__}: {exc}")
    aliases = _snapshot_flat_aliases(entry_snapshot)
    base_ctx = dict(aliases)
    base_ctx.update({
        "candidate_created_at": ts,
        "event_id": eid,
        "strategy_key": skey,
        "strategy_name": label,
        "strategy_bucket_primary": skey,
        "strategy_bucket_primary_label": label,
        "strategy_bucket_labels": [label],
        "final_entry_reasons": reasons[:6],
        "entry_snapshot": entry_snapshot,
        "main_version": MAIN_DEPLOY_VERSION,
        "main_bot_version": MAIN_BOT_VERSION,
        "deploy_version": MAIN_DEPLOY_VERSION,
    })
    ev = {
        "event_id": eid,
        "event_key": eid,
        "created_at": ts,
        "candidate_created_at": ts,
        "source_created_at": ts,
        "detected_ts": ts,
        "event_ts": ts,
        "updated_ts": ts,
        "expires_at": ts + CANDIDATE_TTL_SEC,
        "created_at_text": now_text(ts),
        "detected_at_text": now_text(ts),
        "scan_id": f"strategy_s_{int(ts // 60)}",
        "ticker": t,
        "market": f"KRW-{t}",
        "symbol": f"{t}_KRW",
        "strategy_key": skey,
        "strategy": label,
        "strategy_name": label,
        "paper_strategy_key": skey,
        "paper_strategy_label": label,
        "strategy_bucket_primary": skey,
        "strategy_bucket_primary_label": label,
        "strategy_bucket_labels": [label],
        "candidate_grade": "S",
        "grade": "S",
        "candidate_grade_label": "✅ S급 자동매매 상위",
        "paper_bot_open": True,
        "open_eligible": True,
        "trade_ready": True,
        "lane": "strict",
        "current_price": price,
        "entry_price": price,
        "detected_price": price,
        "score": round(13.0 + len(reasons) * 0.9 + fnum(of.get("orderflow_score")) * 0.15, 2),
        "take_profit_pct": 1.80,
        "extended_take_profit_pct": 2.80,
        "protect_trigger_pct": 1.00,
        "protect_floor_pct": 0.45,
        "stop_loss_pct": -0.45,
        "time_exit_minutes": 60,
        "reasons": reasons[:6],
        "quality_risk_tags": aliases.get("quality_risk_tags") or [],
        "entry_context": base_ctx,
        "entry_snapshot": entry_snapshot,
        "entry_snapshot_schema": "entry_snapshot_v1",
        "strategy_reasons": reasons[:6],
        "final_entry_reasons": reasons[:6],
        "brain_version": VERSION,
        "main_version": MAIN_DEPLOY_VERSION,
        "main_bot_version": MAIN_BOT_VERSION,
        "deploy_version": MAIN_DEPLOY_VERSION,
    }
    profile = _v361_adaptive_hold_profile(row, of, skey) if skey == "leader_flow_adaptive_hold_s" else {}
    if profile:
        ev["profile"] = profile
        ev["strategy_family"] = profile.get("strategy_family")
        ev["strategy_family_label"] = profile.get("strategy_family_label")
        ev["hold_model"] = profile.get("hold_model")
        ev["take_profit_pct"] = profile.get("take_profit_pct", ev.get("take_profit_pct"))
        ev["extended_target_pct"] = profile.get("extended_target_pct")
        ev["extended_take_profit_pct"] = profile.get("extended_take_profit_pct")
        ev["protect_trigger_pct"] = profile.get("protect_trigger_pct", ev.get("protect_trigger_pct"))
        ev["protect_floor_pct"] = profile.get("protect_floor_pct", ev.get("protect_floor_pct"))
        ev["stop_loss_pct"] = profile.get("stop_loss_pct", ev.get("stop_loss_pct"))
        ev["hard_loss_guard_pct"] = profile.get("hard_loss_guard_pct")
        ev["time_exit_minutes"] = profile.get("time_exit_minutes", ev.get("time_exit_minutes"))
        ev["time_exit_min"] = profile.get("time_exit_min")
        base_ctx.update(profile)
        if isinstance(entry_snapshot, dict):
            entry_snapshot.setdefault("adaptive_hold_profile", profile)
            strat = entry_snapshot.get("strategy") if isinstance(entry_snapshot.get("strategy"), dict) else {}
            strat.update({"hold_model": profile.get("hold_model"), "strategy_family": profile.get("strategy_family_label"), "decision_note": "v367 주도흐름 유동보유 후보"})
            entry_snapshot["strategy"] = strat
            ev["entry_snapshot"] = entry_snapshot
    ev.update(aliases)
    return ev
def _priority_score(row: Dict[str, Any], core_hits: List[Tuple[str, List[str]]], info_bad: List[str], hard_bad: List[str]) -> float:
    score = 0.0
    score += fnum(row.get("scanner_priority_score"), default=0.0)
    score += min(30.0, max(0.0, fnum(row.get("change_3m"), default=0.0) * 8))
    score += min(30.0, max(0.0, fnum(row.get("change_5m"), default=0.0) * 6))
    score += min(25.0, max(0.0, fnum(row.get("change_15m"), default=0.0) * 3))
    score += min(20.0, max(0.0, fnum(row.get("turnover_24h"), default=0.0) / 400_000_000))
    score += 25.0 * len(core_hits)
    if info_bad:
        score += 15.0
    if hard_bad:
        score -= 35.0
    return round(score, 3)


def _make_priority_request(t: str, row: Dict[str, Any], bucket: str, priority: float, need: List[str], core_hits: List[Tuple[str, List[str]]], reasons: List[str]) -> Dict[str, Any]:
    return {
        "ticker": t,
        "bucket": bucket,
        "priority": round(priority, 3),
        "need": need,
        "core_strategies": [k for k, _ in core_hits],
        "core_strategy_labels": [STRATEGIES.get(k, k) for k, _ in core_hits],
        "reasons": reasons[:8],
        "score": fnum(row.get("scanner_priority_score"), default=0.0),
        "change_3m": fnum(row.get("change_3m"), default=0.0),
        "change_5m": fnum(row.get("change_5m"), default=0.0),
        "change_15m": fnum(row.get("change_15m"), default=0.0),
        "turnover_24h": fnum(row.get("turnover_24h"), default=0.0),
        "updated_ts": now_ts(),
        "source": "strategy_worker",
    }


def _cheap_gate(row: Dict[str, Any], core_hits: List[Tuple[str, List[str]]], hard_bad: List[str]) -> Tuple[bool, str]:
    """정보를 붙일 가치가 있는 후보인지 cheap 재료만으로 먼저 가른다.
    개수 제한이 아니라 우선순위 gate다.
    - S 코어가 맞는 후보는 정보필요 후보
    - 코어가 아직 안 맞아도 돈/흐름/캔들/VWAP가 좋은 후보는 high 후보
    - 나머지는 WS/micro를 붙일 필요 없는 cheap 탈락 후보
    """
    if hard_bad:
        return False, "hard_block"
    if core_hits:
        return True, "core_hit"
    ch3=fnum(row.get("change_3m"), default=0.0)
    ch5=fnum(row.get("change_5m"), default=0.0)
    ch15=fnum(row.get("change_15m"), default=0.0)
    money=fnum(row.get("turnover_24h"), default=0.0)
    score=fnum(row.get("scanner_priority_score"), default=0.0)
    good_flow = (ch3 >= 0.35 and ch5 >= 0.45) or (ch5 >= 0.70) or (ch15 >= 1.20)
    good_position = fnum(row.get("vwap_gap_pct"), default=-9.0) >= -0.10 and fnum(row.get("ema5_gap_pct"), default=-9.0) >= -0.12
    good_signal = bool(row.get("volume_expanding") or row.get("breakout_hint") or row.get("sweep_reclaim_hint"))
    good_money = money >= 500_000_000
    if (good_flow and good_position and (good_signal or good_money)) or (score >= 88 and good_flow):
        return True, "high_cheap"
    return False, "cheap_drop"


def run_once()->Dict[str,Any]:
    st=now_ts(); ts=now_ts(); write_status("running", phase="evaluating", evaluated=0, s_count=0, target_count=0, last_sec=0)
    fobj=load_json(FEATURE,{}) or {}; rows=fobj.get("rows") if isinstance(fobj,dict) else []
    if not isinstance(rows,list): rows=[]
    ofmap=map_rows(load_json(ORDERFLOW,{}) or {})
    evals=[("leader_flow_adaptive_hold_s",eval_adaptive_hold),("money_reaccel_s",eval_money),("leader_momentum_s",eval_leader),("breakout_early_s",eval_breakout),("sweep_vwap_recovery_s",eval_sweep),("surge_rebreak_s",eval_surge)]
    events=[]; rejects=[]; priority_requests=[]; strat_counts={k:0 for k in STRATEGIES}
    info_pending=0; near_s_info_pending=0; hard_blocked=0; info_not_requested=0
    info_needed_count=0; cheap_drop_count=0; fresh_ready_count=0
    orderflow_attached_count=0; quote_ready_count=0; micro_ready_count=0; full_info_ready_count=0
    priority_buckets={}; cheap_buckets={}
    for row in rows:
        t=ticker_norm(row.get("ticker"))
        if not t: continue
        of=ofmap.get(t,{}) or {}
        if of:
            orderflow_attached_count += 1
        quote_ready = bool(of.get("quote_fresh") or of.get("ws_fresh"))
        micro_ready = bool(of.get("micro_fresh"))
        if quote_ready:
            quote_ready_count += 1
        if micro_ready:
            micro_ready_count += 1
        if quote_ready and micro_ready:
            full_info_ready_count += 1
        hard_bad = common_hard(row,of)
        s_hits=[]; reasons=[]; core_hits=[]; core_fail=[]
        for skey,fn in evals:
            ok,why,no=fn(row,of)
            if ok:
                core_hits.append((skey,why))
            else:
                core_fail += [f"{STRATEGIES.get(skey,skey)}:{x}" for x in no[:2]]
        need_info, cheap_bucket = _cheap_gate(row, core_hits, hard_bad)
        cheap_buckets[cheap_bucket]=cheap_buckets.get(cheap_bucket,0)+1
        info_bad = orderflow_info_bad(of) if need_info else []
        need=[]
        if "시세정보보강대기" in info_bad:
            need.append("quote")
        if "WS정보보강대기" in info_bad:
            need.append("ws")
        if "micro정보보강대기" in info_bad:
            need.append("micro")
        if need_info:
            info_needed_count += 1
        if need_info and not info_bad:
            fresh_ready_count += 1
        pscore=_priority_score(row, core_hits, info_bad, hard_bad)
        if info_bad:
            info_pending += 1
        for skey, why in core_hits:
            if not hard_bad and not info_bad:
                s_hits.append((skey,why)); strat_counts[skey]+=1
        if s_hits:
            ev=build_event(row,of,s_hits[0][0],s_hits[0][1])
            if len(s_hits)>1:
                ev["multi_strategy_s"]=[k for k,_ in s_hits]; ev["strategy_bucket_labels"]=[STRATEGIES.get(k,k) for k,_ in s_hits]
            events.append(ev)
            priority_requests.append(_make_priority_request(t,row,"s_candidate",130+pscore, ["quote","micro"], s_hits, ["S후보유지"]))
            priority_buckets["s_candidate"]=priority_buckets.get("s_candidate",0)+1
        elif core_hits and info_bad and not hard_bad:
            near_s_info_pending += 1
            reasons += [f"정보보강대기:{x}" for x in info_bad[:3]] + [f"S근접:{STRATEGIES.get(k,k)}" for k,_ in core_hits[:2]]
            priority_requests.append(_make_priority_request(t,row,"near_s_info_wait",110+pscore, need, core_hits, reasons))
            priority_buckets["near_s_info_wait"]=priority_buckets.get("near_s_info_wait",0)+1
        elif core_hits and hard_bad:
            hard_blocked += 1
            reasons += hard_bad[:4] + [f"S근접차단:{STRATEGIES.get(k,k)}" for k,_ in core_hits[:2]]
            if info_bad:
                info_not_requested += 1
                priority_buckets["hard_blocked_not_requested"]=priority_buckets.get("hard_blocked_not_requested",0)+1
        else:
            if info_bad:
                reasons += [f"정보보강대기:{x}" for x in info_bad[:2]]
            reasons += hard_bad[:2] + core_fail[:4]
            if info_bad:
                # cheap gate를 통과한 high 후보만 정보요청한다. cheap 탈락 후보에는 정보부족을 붙이지 않는다.
                bucket = "info_wait_high"
                priority_requests.append(_make_priority_request(t,row,bucket, 70+pscore, need, core_hits, reasons))
                priority_buckets[bucket]=priority_buckets.get(bucket,0)+1
            else:
                if cheap_bucket == "cheap_drop":
                    cheap_drop_count += 1
                elif not need_info:
                    info_not_requested += 1
        if not s_hits:
            rejects.append({"ticker":t,"score":fnum(row.get("scanner_priority_score")),"priority":pscore,"reasons":reasons[:8],"price":row.get("current_price"),"updated_ts":ts,"info_pending":bool(info_bad),"info_needed":bool(need_info),"near_s_info_pending":bool(core_hits and info_bad and not hard_bad),"cheap_bucket":cheap_bucket})
    events.sort(key=lambda e:fnum(e.get("score")), reverse=True)
    latest, appended = persist_paper_handoff(events, evaluated=len(rows))
    ctr={}
    for r in rejects:
        for reason in r.get("reasons",[])[:5]: ctr[reason]=ctr.get(reason,0)+1
    top=sorted(ctr.items(), key=lambda x:x[1], reverse=True)[:20]
    priority_requests = sorted(priority_requests, key=lambda x: fnum(x.get("priority"), default=0), reverse=True)
    target = list(dict.fromkeys([r.get("ticker") for r in priority_requests if r.get("ticker")]))
    save_json(PRIORITY_REQ,{"version":VERSION,"updated_ts":ts,"updated_text":now_text(ts),"request_count":len(priority_requests),"targets":target,"requests":priority_requests,"buckets":priority_buckets,"cheap_buckets":cheap_buckets,"note":"v0.13: entry_snapshot 순환참조 제거 + cheap gate/orderflow canonical 유지."})
    tq=load_json(TARGET_ROUTER_QUEUE,{}) or {}
    active_set=set(tq.get("active_targets",[]) if isinstance(tq,dict) and isinstance(tq.get("active_targets"),list) else [])
    priority_wait_sample=[]
    for pr in priority_requests[:12]:
        tt=ticker_norm(pr.get("ticker"))
        of=ofmap.get(tt,{}) or {}
        priority_wait_sample.append({
            "ticker": tt,
            "bucket": pr.get("bucket"),
            "need": pr.get("need"),
            "priority": pr.get("priority"),
            "quote_ready": bool(of.get("quote_fresh") or of.get("ws_fresh")),
            "micro_ready": bool(of.get("micro_fresh")),
            "info_ready": bool((of.get("quote_fresh") or of.get("ws_fresh")) and of.get("micro_fresh")),
            "router_active": tt in active_set or bool(of.get("router_active")),
            "micro_age_sec": of.get("micro_age_sec"),
            "quote_age_sec": of.get("quote_age_sec"),
            "reasons": pr.get("reasons",[])[:4],
        })
    common_summary={"version":VERSION,"updated_ts":ts,"updated_text":now_text(ts),"s_count":len(events),"paper_latest_count":len(latest),"archive_appended":appended,"strategies":strat_counts,"events":latest[:12],"evaluated":len(rows),"info_needed_count":info_needed_count,"info_pending_count":info_pending,"near_s_info_pending":near_s_info_pending,"fresh_ready_count":fresh_ready_count,"cheap_reject_count":cheap_drop_count,"hard_blocked_near_s":hard_blocked,"priority_request_count":len(priority_requests),"priority_buckets":priority_buckets,"cheap_buckets":cheap_buckets,"target_count":len(target),"info_not_requested":info_not_requested,"orderflow_attached_count":orderflow_attached_count,"quote_ready_count":quote_ready_count,"micro_ready_count":micro_ready_count,"full_info_ready_count":full_info_ready_count,"router_target_count":tq.get("active_target_count", tq.get("target_count","-")),"router_queue_count":tq.get("queue_count","-"),"router_backlog_count":tq.get("backlog_count","-"),"router_fresh_recovered":tq.get("fresh_recovered","-"),"router_need_ws":tq.get("need_ws","-"),"router_need_micro":tq.get("need_micro","-"),"router_micro_priority_target_count":tq.get("micro_priority_target_count","-"),"router_strategy_req_info_ready":tq.get("strategy_req_info_ready","-"),"priority_wait_sample":priority_wait_sample}
    save_json(SUMMARY,common_summary)
    save_json(REJECT,{**common_summary,"reject_count":len(rejects),"reason_top":[{"reason":k,"count":v} for k,v in top],"sample":rejects[:30],"note":"v0.13: 전체평가 후보에 정보부족을 찍지 않고 cheap gate 통과 후보만 정보요청. entry_snapshot 순환참조 제거."})
    sec=now_ts()-st; write_status("running", evaluated=len(rows), s_count=len(events), paper_latest_count=len(latest), info_needed_count=info_needed_count, info_pending_count=info_pending, near_s_info_pending=near_s_info_pending, cheap_reject_count=cheap_drop_count, fresh_ready_count=fresh_ready_count, info_not_requested=info_not_requested, orderflow_attached_count=orderflow_attached_count, quote_ready_count=quote_ready_count, micro_ready_count=micro_ready_count, full_info_ready_count=full_info_ready_count, priority_request_count=len(priority_requests), target_count=len(target), router_target_count=tq.get("active_target_count", tq.get("target_count","-")), router_queue_count=tq.get("queue_count","-"), router_backlog_count=tq.get("backlog_count","-"), last_sec=round(sec,3)); return {"eval":len(rows),"s":len(events),"paper_latest":len(latest),"priority_requests":len(priority_requests),"info_needed":info_needed_count,"info_pending":info_pending,"cheap_drop":cheap_drop_count}
def main()->None:
    write_status("running", phase="boot", evaluated=0, s_count=0, target_count=0, last_sec=0)
    while True:
        try: run_once()
        except KeyboardInterrupt: write_status("stopping"); raise
        except Exception as exc: append_error(ERROR,"loop",exc); write_status("error", error=f"{exc.__class__.__name__}: {exc}")
        time.sleep(max(0.5,INTERVAL_SEC))


# =============================================================================
# strategy_worker v0.15: 후보 event_id/trace_id 단일화
# - 전략 후보가 archive/latest/paper OPEN/CLOSED까지 같은 ID로 이어지도록 보강한다.
# - 조건/S통과/청산 변경 없음. handoff 추적용 메타만 추가한다.
# =============================================================================
VERSION = "strategy_worker_v0.24"


def _v014_stable_event_id(row: Dict[str, Any], skey: str, ts: Optional[float] = None) -> str:
    t = ticker_norm((row or {}).get("ticker") or (row or {}).get("market") or (row or {}).get("symbol")) or "UNKNOWN"
    sk = str(skey or (row or {}).get("strategy_key") or (row or {}).get("strategy_bucket_primary") or "strategy_s")
    base_ts = fnum((row or {}).get("candidate_created_at"), (row or {}).get("source_created_at"), (row or {}).get("detected_ts"), (row or {}).get("event_ts"), (row or {}).get("created_at"), default=0.0)
    if base_ts <= 0:
        base_ts = ts or now_ts()
    # 30초 버킷: 같은 S 후보가 너무 자주 새 ID로 갈라지지 않게 하되, 너무 오래 같은 후보로 묶이지 않게 한다.
    return f"ev:{t}:{sk}:{int(base_ts // 30)}"


def _v014_attach_trace_fields(row: Dict[str, Any], skey: Optional[str] = None) -> Dict[str, Any]:
    out = dict(row or {})
    sk = str(skey or out.get("strategy_key") or out.get("strategy_bucket_primary") or "strategy_s")
    eid = str(out.get("event_id") or out.get("event_key") or out.get("id") or "")
    if not eid:
        eid = _v014_stable_event_id(out, sk)
        out["event_id_origin"] = "v014_fallback"
    else:
        out.setdefault("event_id_origin", "strategy")
    out["event_id"] = eid
    out["event_key"] = eid
    out["trace_id"] = eid
    out["handoff_id"] = eid
    out["candidate_uid"] = eid
    out["source_event_id"] = eid
    out["handoff_stage"] = "strategy_handoff"
    out["handoff_status"] = "candidate_created"
    ctx = out.get("entry_context") if isinstance(out.get("entry_context"), dict) else {}
    ctx.update({"event_id": eid, "event_key": eid, "trace_id": eid, "handoff_id": eid, "candidate_uid": eid})
    out["entry_context"] = ctx
    snap = out.get("entry_snapshot") if isinstance(out.get("entry_snapshot"), dict) else None
    if snap is not None:
        snap["event_id"] = eid
        snap["trace_id"] = eid
        snap["handoff_id"] = eid
        flat = snap.get("flat") if isinstance(snap.get("flat"), dict) else {}
        flat.update({"event_id": eid, "trace_id": eid, "handoff_id": eid})
        snap["flat"] = flat
        out["entry_snapshot"] = snap
    return out

_v014_prev_build_event = build_event

def build_event(row, of, skey, reasons):  # type: ignore[override]
    ev = _v014_prev_build_event(row, of, skey, reasons)
    return _v014_attach_trace_fields(ev, skey)

_v014_prev_normalize_paper_event = _normalize_paper_event

def _normalize_paper_event(ev: Dict[str, Any], ttl_sec: float = CANDIDATE_TTL_SEC) -> Dict[str, Any]:  # type: ignore[override]
    row = _v014_prev_normalize_paper_event(ev, ttl_sec)
    return _v014_attach_trace_fields(row, row.get("strategy_key") or row.get("strategy_bucket_primary"))



# =============================================================================
# strategy_worker v0.15: S 단일 OPEN을 S1/S2/S3 단계로 분리
# - S1만 즉시 paper OPEN 대상이다.
# - S2는 재확인 후보로 handoff/trace에는 남기되 즉시 OPEN하지 않는다.
# - S3는 관찰/복기 후보로 남긴다.
# - ABC 등급은 새 후보에서 사용하지 않는다.
# =============================================================================
VERSION = "strategy_worker_v0.24"

_v015_prev_build_event = build_event

def _v015_bool(v: Any) -> bool:
    if isinstance(v, bool): return v
    return str(v).strip().lower() in {"1","true","yes","ok","fresh","신선"}

def _v015_stage_decision(row: Dict[str, Any], of: Dict[str, Any], skey: str) -> Tuple[str, List[str]]:
    """v0.16/v359 S1 안전문.
    점수만 높고 가격반응/체결지속/호가 검증이 비어 있던 후보가 S1로 즉시 OPEN되던 구멍을 막는다.
    결측값은 통과가 아니라 S2/S3 강등 사유로 본다.
    """
    def _known(*keys: str, src: Optional[Dict[str, Any]] = None) -> bool:
        d = src if isinstance(src, dict) else row
        for k in keys:
            v = d.get(k)
            if v is not None and str(v).strip() not in {'', '-', 'None', 'nan'}:
                return True
        return False

    ch30s=fnum(row.get('change_30s'), row.get('price_change_30s'), default=0.0)
    ch1=fnum(row.get('change_1m'), row.get('price_change_1m'), default=0.0)
    ch3=fnum(row.get('change_3m'), row.get('price_change_3m'), default=0.0)
    ch5=fnum(row.get('change_5m'), row.get('price_change_5m'), default=0.0)
    ch15=fnum(row.get('change_15m'), row.get('price_change_15m'), default=0.0)
    ch30=fnum(row.get('change_30m'), row.get('price_change_30m'), default=0.0)
    price_react_known=_known('price_reaction_score','price_recheck_pct','price_reaction_pct')
    price_react=fnum(row.get('price_reaction_score'), row.get('price_recheck_pct'), row.get('price_reaction_pct'), default=-999.0)
    vwap=fnum(row.get('vwap_gap_pct'), default=-9.0)
    ema=fnum(row.get('ema5_gap_pct'), row.get('ma5_gap_pct'), default=-9.0)
    high_gap=fnum(row.get('recent_high_gap_pct'), row.get('below_high_pct'), default=0.0)
    low_reb=fnum(row.get('recent_low_rebound_pct'), row.get('low_defense_pct'), default=0.0)
    day=fnum(row.get('day_pos_pct'), row.get('current_close_pos_ratio'), default=50.0)
    rel=fnum(row.get('relative_strength_pct'), row.get('relative_strength'), default=0.0)
    buy=fnum(of.get('buy_ratio'), of.get('buy_ratio_30s'), of.get('micro_trade_buy_ratio_30'), default=0.0)
    buy1_known=_known('buy_ratio_1m','buy_ratio_60','micro_buy_ratio_sustain_1m','buy_ratio_sustain', src=of)
    buy1=fnum(of.get('buy_ratio_1m'), of.get('buy_ratio_60'), of.get('micro_buy_ratio_sustain_1m'), of.get('buy_ratio_sustain'), default=-1.0)
    spread=fnum(of.get('spread_pct'), of.get('micro_spread_pct'), default=99.0)
    slip_known=_known('slippage_est_pct','tick_pct_est','expected_slippage_pct', src=of)
    slip=fnum(of.get('slippage_est_pct'), of.get('tick_pct_est'), of.get('expected_slippage_pct'), default=99.0)
    ask_known=_known('ask_wall_ratio','ask_wall','micro_ask_wall_ratio', src=of)
    ask_wall=fnum(of.get('ask_wall_ratio'), of.get('ask_wall'), of.get('micro_ask_wall_ratio'), default=-1.0)
    bid_wall=fnum(of.get('bid_wall_ratio'), of.get('micro_bid_ask_wall_ratio'), default=0.0)
    micro=_v015_bool(of.get('micro_fresh'))
    ws=_v015_bool(of.get('ws_fresh') or of.get('quote_fresh'))
    vol=bool(row.get('volume_expanding'))
    breakout=bool(row.get('breakout_hint'))
    sweep=bool(row.get('sweep_reclaim_hint'))
    sell=bool(of.get('sell_pressure') or of.get('ask_wall_pressure') or of.get('sell_trade_pressure'))
    hard=common_hard(row, of)
    recent_loss = any('최근반복손실' in str(x) or '하드손실' in str(x) for x in hard)

    tags: List[str]=[]
    if not micro: tags.append('micro재확인필요')
    if not ws: tags.append('WS재확인필요')
    if not price_react_known: tags.append('가격반응미확인')
    elif price_react < 0.05: tags.append('가격반응부족')
    if not buy1_known: tags.append('매수체결지속미확인')
    elif buy1 < 0.64: tags.append('매수체결지속부족')
    if buy and buy < 0.68: tags.append('매수체결우세부족')
    if spread > 0.18: tags.append('스프레드주의')
    if not slip_known or slip > 0.20: tags.append('슬리피지미확인/주의')
    if not ask_known: tags.append('매도벽미확인')
    if sell or (ask_known and ask_wall >= 1.15 and bid_wall < ask_wall): tags.append('매도압력주의')
    if recent_loss: tags.append('최근반복손실주의')

    high_end = day >= 90.0 and high_gap >= -0.20
    overheat = (ch5 >= 6.0 and (ema >= 3.0 or vwap >= 0.80)) or ch15 >= 12.0 or ema >= 8.0
    top_without_react = high_end and (not price_react_known or price_react < 0.08)
    weak_relative_money = skey == 'money_reaccel_s' and rel < 0 and ch5 < 5.0
    if high_end: tags.append('고점권')
    if overheat: tags.append('급등과열/과이격')
    if weak_relative_money: tags.append('상대강도음수')

    # S1은 결측값 대체 금지. 실제 가격반응+체결지속+호가안정이 모두 있어야 한다.
    price_alive_s1 = price_react_known and price_react >= 0.05 and (ch30s >= 0.02 or ch1 >= 0.08 or ch3 >= 0.25)
    flow_alive = (ch3 >= 0.20 or ch5 >= 0.35)
    order_ok_s1 = micro and ws and buy >= 0.70 and buy1_known and buy1 >= 0.64 and spread <= 0.18 and slip_known and slip <= 0.20 and ask_known and not sell
    position_ok_s1 = not recent_loss and not top_without_react and not overheat and not weak_relative_money and vwap >= -0.03 and ema >= -0.05
    base_s1 = order_ok_s1 and position_ok_s1 and price_alive_s1 and flow_alive

    # S2는 살려야 할 후보: 점수/흐름은 있는데 즉시진입 안전문이 부족한 경우.
    # 결측/고점/과열 후보도 버리지 않고 재확인으로 보낸다.
    price_alive_s2 = (price_react_known and price_react >= 0.00) or ch1 >= 0.05 or ch3 >= 0.18 or ch5 >= 0.30 or vol
    order_ok_s2 = micro and buy >= 0.62 and spread <= 0.28 and not sell
    position_ok_s2 = not recent_loss and vwap >= -0.08 and ema >= -0.12

    if skey == 'money_reaccel_s':
        s1 = base_s1 and ch3 >= 0.35 and ch5 >= 0.45 and vol and rel >= 0.0
        s2 = order_ok_s2 and position_ok_s2 and (ch3 >= 0.20 or ch5 >= 0.35 or vol) and not (overheat and not price_react_known)
    elif skey == 'breakout_early_s':
        s1 = base_s1 and breakout and vol and high_gap >= -0.08 and ch3 >= 0.15 and not high_end
        s2 = order_ok_s2 and breakout and high_gap >= -0.25 and (vol or ch3 >= 0.15)
    elif skey == 'sweep_vwap_recovery_s':
        s1 = base_s1 and sweep and low_reb >= 0.55 and ch3 >= 0.08 and day < 88
        s2 = order_ok_s2 and sweep and vwap >= -0.08 and low_reb >= 0.35 and price_alive_s2
    elif skey == 'surge_rebreak_s':
        s1 = base_s1 and ch15 >= 1.20 and ch3 >= 0.25 and high_gap >= -0.15 and not overheat
        s2 = order_ok_s2 and ch15 >= 1.00 and high_gap >= -0.30 and price_alive_s2
    elif skey == 'leader_flow_adaptive_hold_s':
        mid_trend = ch15 >= 0.70 and ch30 >= 0.40 and rel >= 0.0 and vwap >= -0.03 and ema >= -0.05
        early_alive = ch3 >= 0.20 or ch5 >= 0.45 or vol
        s1 = base_s1 and mid_trend and early_alive and not high_end
        s2 = order_ok_s2 and position_ok_s2 and (ch15 >= 0.55 or ch5 >= 0.55) and vwap >= -0.08 and ema >= -0.12 and not recent_loss
    elif skey == 'leader_momentum_s':
        s1 = base_s1 and ch15 >= 0.75 and ch30 >= 0.75 and rel >= 0.40 and row.get('market_mode') != '약함'
        s2 = order_ok_s2 and ch15 >= 0.60 and rel >= 0.25 and vwap >= -0.05 and price_alive_s2
    else:
        s1 = base_s1
        s2 = order_ok_s2 and position_ok_s2 and price_alive_s2

    if s1:
        return 'S1', ['즉시진입안전문통과'] + tags[:7]
    if s2:
        return 'S2', ['재확인후진입후보'] + tags[:7]
    return 'S3', ['관찰복기후보'] + tags[:7]

def _v015_apply_stage(ev: Dict[str, Any], row: Dict[str, Any], of: Dict[str, Any], skey: str) -> Dict[str, Any]:
    stage, why = _v015_stage_decision(row, of, skey)
    out = dict(ev or {})
    label = {'S1':'✅ S1 즉시진입','S2':'⚠️ S2 재확인','S3':'❔ S3 관찰복기'}[stage]
    out['s_stage'] = stage
    out['candidate_grade'] = stage
    out['grade'] = stage
    out['entry_grade'] = stage
    out['signal_grade'] = stage
    out['candidate_grade_label'] = label
    out['s_stage_reasons'] = why[:8]
    out['paper_bot_open'] = stage == 'S1'
    out['open_eligible'] = stage == 'S1'
    out['trade_ready'] = stage == 'S1'
    out['recheck_required'] = stage == 'S2'
    out['observe_only'] = stage == 'S3'
    out['decision_stage'] = stage
    ctx = out.get('entry_context') if isinstance(out.get('entry_context'), dict) else {}
    ctx.update({'s_stage': stage, 'candidate_grade': stage, 'candidate_grade_label': label, 'paper_bot_open': stage == 'S1', 'open_eligible': stage == 'S1', 'trade_ready': stage == 'S1', 's_stage_reasons': why[:8]})
    out['entry_context'] = ctx
    snap = out.get('entry_snapshot') if isinstance(out.get('entry_snapshot'), dict) else None
    if snap is not None:
        strat = snap.get('strategy') if isinstance(snap.get('strategy'), dict) else {}
        strat.update({'decision_stage': stage, 'decision_note': label, 's_stage_reasons': why[:8]})
        snap['strategy'] = strat
        flat = snap.get('flat') if isinstance(snap.get('flat'), dict) else {}
        flat.update({'s_stage': stage, 'candidate_grade': stage, 'candidate_grade_label': label})
        snap['flat'] = flat
        out['entry_snapshot'] = snap
    return out

def build_event(row, of, skey, reasons):  # type: ignore[override]
    ev = _v015_prev_build_event(row, of, skey, reasons)
    return _v015_apply_stage(ev, row, of, skey)

def _normalize_paper_event(ev: Dict[str, Any], ttl_sec: float = CANDIDATE_TTL_SEC) -> Dict[str, Any]:  # type: ignore[override]
    row = dict(ev or {})
    ts = _event_created_ts(row) or now_ts()
    ticker = ticker_norm(row.get('ticker') or row.get('market') or row.get('symbol'))
    skey = str(row.get('strategy_key') or row.get('strategy_bucket_primary') or 'strategy_s')
    scan_id = row.get('scan_id') or row.get('source_scan_id') or f"strategy_s_{int(ts // 60)}"
    eid = row.get('event_id') or row.get('id') or row.get('event_key') or f"{ticker}:{skey}:{int(ts // 60)}"
    stage = str(row.get('s_stage') or row.get('candidate_grade') or row.get('grade') or 'S3').upper()
    if stage == 'S': stage = 'S1'
    if stage not in {'S1','S2','S3'}: stage = 'S3'
    row.update({
        'ticker': ticker, 'market': f'KRW-{ticker}' if ticker else row.get('market'), 'symbol': f'{ticker}_KRW' if ticker else row.get('symbol'),
        'created_at': ts, 'candidate_created_at': ts, 'source_created_at': ts, 'detected_ts': ts, 'event_ts': ts,
        'created_at_text': row.get('created_at_text') or now_text(ts), 'detected_at_text': row.get('detected_at_text') or now_text(ts),
        'updated_ts': now_ts(), 'expires_at': row.get('expires_at') or (ts + ttl_sec), 'event_id': eid, 'event_key': eid,
        'scan_id': scan_id, 'lane': 'strict', 's_stage': stage, 'candidate_grade': stage, 'grade': stage,
        'entry_grade': stage, 'signal_grade': stage,
        'candidate_grade_label': row.get('candidate_grade_label') or {'S1':'✅ S1 즉시진입','S2':'⚠️ S2 재확인','S3':'❔ S3 관찰복기'}[stage],
        'paper_bot_open': stage == 'S1', 'open_eligible': stage == 'S1', 'trade_ready': stage == 'S1',
        'recheck_required': stage == 'S2', 'observe_only': stage == 'S3',
    })
    ctx = row.get('entry_context') if isinstance(row.get('entry_context'), dict) else {}
    for k in ('ws_fresh','micro_fresh','spread_pct','buy_ratio','sell_pressure','orderflow_score'):
        if k in ctx and row.get(k) in (None, ''):
            row[k] = ctx.get(k)
    ctx.update({'s_stage': stage, 'candidate_grade': stage, 'candidate_grade_label': row.get('candidate_grade_label'), 'paper_bot_open': stage == 'S1', 'open_eligible': stage == 'S1', 'trade_ready': stage == 'S1'})
    row['entry_context'] = ctx
    return _v014_attach_trace_fields(row, skey) if '_v014_attach_trace_fields' in globals() else row

_v015_prev_persist_paper_handoff = persist_paper_handoff

def persist_paper_handoff(events: List[Dict[str, Any]], evaluated: int = 0) -> Tuple[List[Dict[str, Any]], int]:  # type: ignore[override]
    latest, appended = _v015_prev_persist_paper_handoff(events, evaluated=evaluated)
    try:
        counts = {'S1':0,'S2':0,'S3':0}
        for r in latest:
            g = str(r.get('s_stage') or r.get('candidate_grade') or r.get('grade') or 'S3').upper()
            if g == 'S': g = 'S1'
            if g in counts: counts[g] += 1
        h = load_json(HANDOFF, {}) or {}
        h.update({'s_stage_counts': counts, 's1_count': counts.get('S1',0), 's2_count': counts.get('S2',0), 's3_count': counts.get('S3',0), 'stage_note': 'v0.15: S1만 즉시 OPEN, S2 재확인, S3 관찰복기'})
        save_json(HANDOFF, h)
    except Exception as exc:
        append_error(ERROR, 'v015_persist_stage_counts', exc)
    return latest, appended


# =============================================================================
# strategy_worker v0.17 / v360: S2/S3 관찰·재확인 배관 복구
# - v359는 S1 안전문으로 손실 폭탄은 막았지만, S 후보를 통과한 뒤에만 S2/S3를 만들었다.
# - 그래서 S1이 0이면 S2/S3도 0이 되어 복기 재료가 사라졌다.
# - v360은 S1 안전문은 유지하고, core_hit 정보대기/차단/근접 후보를 S2/S3로 저장한다.
# - S2/S3는 paper_bot_open=False라 즉시 OPEN하지 않고, 1시간 요약/복기/trace용으로만 남긴다.
# =============================================================================

def _v360_force_stage(ev: Dict[str, Any], stage: str, extra_reasons: List[str]) -> Dict[str, Any]:
    stage = str(stage or 'S3').upper()
    if stage not in {'S1','S2','S3'}:
        stage = 'S3'
    out = dict(ev or {})
    label = {'S1':'✅ S1 즉시진입','S2':'⚠️ S2 재확인','S3':'❔ S3 관찰복기'}[stage]
    reasons = list(out.get('s_stage_reasons') if isinstance(out.get('s_stage_reasons'), list) else [])
    for r in extra_reasons or []:
        if r and r not in reasons:
            reasons.append(str(r))
    out.update({
        's_stage': stage,
        'candidate_grade': stage,
        'grade': stage,
        'entry_grade': stage,
        'signal_grade': stage,
        'candidate_grade_label': label,
        's_stage_reasons': reasons[:10],
        'paper_bot_open': stage == 'S1',
        'open_eligible': stage == 'S1',
        'trade_ready': stage == 'S1',
        'recheck_required': stage == 'S2',
        'observe_only': stage == 'S3',
        'decision_stage': stage,
        'final_entry_action': 'paper_open' if stage == 'S1' else ('recheck_wait' if stage == 'S2' else 'observe'),
        'final_entry_label': label,
        'trade_ready_label': label,
        'summary_reason': ','.join(reasons[:5]) or label,
    })
    ctx = out.get('entry_context') if isinstance(out.get('entry_context'), dict) else {}
    ctx.update({
        's_stage': stage,
        'candidate_grade': stage,
        'candidate_grade_label': label,
        'paper_bot_open': stage == 'S1',
        'open_eligible': stage == 'S1',
        'trade_ready': stage == 'S1',
        'recheck_required': stage == 'S2',
        'observe_only': stage == 'S3',
        's_stage_reasons': reasons[:10],
        'final_entry_action': out.get('final_entry_action'),
        'final_entry_label': label,
    })
    out['entry_context'] = ctx
    snap = out.get('entry_snapshot') if isinstance(out.get('entry_snapshot'), dict) else None
    if snap is not None:
        strat = snap.get('strategy') if isinstance(snap.get('strategy'), dict) else {}
        strat.update({'decision_stage': stage, 'decision_note': label, 's_stage_reasons': reasons[:10]})
        snap['strategy'] = strat
        flat = snap.get('flat') if isinstance(snap.get('flat'), dict) else {}
        flat.update({'s_stage': stage, 'candidate_grade': stage, 'candidate_grade_label': label, 'paper_bot_open': stage == 'S1'})
        snap['flat'] = flat
        out['entry_snapshot'] = snap
    return out

def _v360_near_strategy_hits(row: Dict[str, Any], of: Dict[str, Any], evals: List[Tuple[str, Any]]) -> List[Tuple[str, List[str], List[str]]]:
    """S1/S strict 통과 전 단계의 근접 후보를 찾는다.
    조건을 통과하지 못한 후보를 전부 살리는 게 아니라, 한두 개 부족한 후보만 S3 관찰로 남긴다.
    """
    near: List[Tuple[str, List[str], List[str]]] = []
    for skey, fn in evals:
        try:
            ok, why, no = fn(row, of)
            if ok:
                continue
            no = list(no or [])
            # v367: S2/S3 관찰은 strict 통과 직전만 보지 않는다.
            # 거래대금 자체가 부족한 후보는 버리되, 흐름/위치/체결 중 3~4개 부족한 근접 후보는 S3 복기로 남긴다.
            no_text = ','.join(map(str, no))
            hard_missing = ('거래대금부족' in no_text) or ('흐름유지부족' in no_text and 'VWAP/EMA유지부족' in no_text and len(no) >= 5)
            limit = 4 if skey == 'leader_flow_adaptive_hold_s' else 3
            if (not hard_missing) and len(no) <= limit:
                near.append((skey, list(why or []), no))
        except Exception:
            continue
    def score(item: Tuple[str, List[str], List[str]]) -> float:
        skey, _why, no = item
        pri = _priority_score(row, [(skey, _why)], [], [])
        return pri - len(no) * 3.0
    near.sort(key=score, reverse=True)
    return near[:3]

def run_once()->Dict[str,Any]:  # type: ignore[override]
    st=now_ts(); ts=now_ts(); write_status("running", phase="evaluating_v367", evaluated=0, s_count=0, target_count=0, last_sec=0)
    fobj=load_json(FEATURE,{}) or {}; rows=fobj.get("rows") if isinstance(fobj,dict) else []
    if not isinstance(rows,list): rows=[]
    ofmap=map_rows(load_json(ORDERFLOW,{}) or {})
    evals=[("leader_flow_adaptive_hold_s",eval_adaptive_hold),("money_reaccel_s",eval_money),("leader_momentum_s",eval_leader),("breakout_early_s",eval_breakout),("sweep_vwap_recovery_s",eval_sweep),("surge_rebreak_s",eval_surge)]
    events=[]; rejects=[]; priority_requests=[]; strat_counts={k:0 for k in STRATEGIES}
    info_pending=0; near_s_info_pending=0; hard_blocked=0; info_not_requested=0
    info_needed_count=0; cheap_drop_count=0; fresh_ready_count=0
    orderflow_attached_count=0; quote_ready_count=0; micro_ready_count=0; full_info_ready_count=0
    priority_buckets={}; cheap_buckets={}; stage_source_counts={"S1":0,"S2":0,"S3":0,"core_ready":0,"core_info_wait":0,"core_hard_block":0,"near_observe":0}
    for row in rows:
        t=ticker_norm(row.get("ticker"))
        if not t: continue
        of=ofmap.get(t,{}) or {}
        if of: orderflow_attached_count += 1
        quote_ready = bool(of.get("quote_fresh") or of.get("ws_fresh"))
        micro_ready = bool(of.get("micro_fresh"))
        if quote_ready: quote_ready_count += 1
        if micro_ready: micro_ready_count += 1
        if quote_ready and micro_ready: full_info_ready_count += 1
        hard_bad = common_hard(row,of)
        reasons=[]; core_hits=[]; core_fail=[]
        for skey,fn in evals:
            ok,why,no=fn(row,of)
            if ok:
                core_hits.append((skey,why))
            else:
                core_fail += [f"{STRATEGIES.get(skey,skey)}:{x}" for x in no[:2]]
        need_info, cheap_bucket = _cheap_gate(row, core_hits, hard_bad)
        cheap_buckets[cheap_bucket]=cheap_buckets.get(cheap_bucket,0)+1
        info_bad = orderflow_info_bad(of) if need_info else []
        need=[]
        if "시세정보보강대기" in info_bad: need.append("quote")
        if "WS정보보강대기" in info_bad: need.append("ws")
        if "micro정보보강대기" in info_bad: need.append("micro")
        if need_info: info_needed_count += 1
        if need_info and not info_bad: fresh_ready_count += 1
        pscore=_priority_score(row, core_hits, info_bad, hard_bad)
        if info_bad: info_pending += 1

        # 1) core strategy가 맞고 정보/하드 문제가 없으면 기존처럼 이벤트 생성. v359 안전문이 S1/S2/S3를 최종 결정한다.
        if core_hits and not hard_bad and not info_bad:
            ev=build_event(row,of,core_hits[0][0],core_hits[0][1])
            if len(core_hits)>1:
                ev["multi_strategy_s"]=[k for k,_ in core_hits]; ev["strategy_bucket_labels"]=[STRATEGIES.get(k,k) for k,_ in core_hits]
            events.append(ev)
            g=str(ev.get('s_stage') or ev.get('candidate_grade') or 'S3').upper(); stage_source_counts[g if g in stage_source_counts else 'S3']+=1; stage_source_counts['core_ready']+=1
            strat_counts[core_hits[0][0]]+=1
            priority_requests.append(_make_priority_request(t,row,"s_candidate",130+pscore, ["quote","micro"], core_hits, ["S후보유지"]))
            priority_buckets["s_candidate"]=priority_buckets.get("s_candidate",0)+1
        # 2) core는 맞지만 정보가 모자라면 S2 재확인으로 남긴다. 즉시 OPEN은 절대 안 한다.
        elif core_hits and info_bad and not hard_bad:
            near_s_info_pending += 1
            reasons += [f"정보보강대기:{x}" for x in info_bad[:3]] + [f"S2재확인:{STRATEGIES.get(k,k)}" for k,_ in core_hits[:2]]
            ev=build_event(row,of,core_hits[0][0],core_hits[0][1])
            ev=_v360_force_stage(ev,'S2',reasons[:8])
            events.append(ev); stage_source_counts['S2']+=1; stage_source_counts['core_info_wait']+=1
            priority_requests.append(_make_priority_request(t,row,"s2_recheck_info_wait",115+pscore, need or ["quote","micro"], core_hits, reasons))
            priority_buckets["s2_recheck_info_wait"]=priority_buckets.get("s2_recheck_info_wait",0)+1
        # 3) core는 맞지만 최근손실/고점/스프레드 등 hard가 있으면 S3 관찰로 남긴다.
        elif core_hits and hard_bad:
            hard_blocked += 1
            reasons += hard_bad[:4] + [f"S3관찰:{STRATEGIES.get(k,k)}" for k,_ in core_hits[:2]]
            ev=build_event(row,of,core_hits[0][0],core_hits[0][1])
            ev=_v360_force_stage(ev,'S3',reasons[:8])
            events.append(ev); stage_source_counts['S3']+=1; stage_source_counts['core_hard_block']+=1
            if info_bad:
                info_not_requested += 1
                priority_buckets["hard_blocked_not_requested"]=priority_buckets.get("hard_blocked_not_requested",0)+1
        else:
            # 4) strict S는 아니지만 한두 조건만 부족한 후보는 S3 관찰복기로 살린다.
            near_hits = _v360_near_strategy_hits(row, of, evals)
            if near_hits and not any('거래대금부족' in str(x) for x in hard_bad):
                skey, why, missing = near_hits[0]
                reasons += [f"근접부족:{x}" for x in missing[:3]] + [f"S3관찰:{STRATEGIES.get(skey,skey)}"]
                if info_bad:
                    reasons += [f"정보보강대기:{x}" for x in info_bad[:2]]
                ev=build_event(row,of,skey,why)
                ev=_v360_force_stage(ev,'S3',reasons[:8])
                events.append(ev); stage_source_counts['S3']+=1; stage_source_counts['near_observe']+=1
                if info_bad:
                    bucket="s3_observe_info_wait"
                    priority_requests.append(_make_priority_request(t,row,bucket, 75+pscore, need, [(skey,why)], reasons))
                    priority_buckets[bucket]=priority_buckets.get(bucket,0)+1
            else:
                if info_bad:
                    reasons += [f"정보보강대기:{x}" for x in info_bad[:2]]
                reasons += hard_bad[:2] + core_fail[:4]
                if info_bad:
                    bucket = "info_wait_high"
                    priority_requests.append(_make_priority_request(t,row,bucket, 70+pscore, need, core_hits, reasons))
                    priority_buckets[bucket]=priority_buckets.get(bucket,0)+1
                else:
                    if cheap_bucket == "cheap_drop": cheap_drop_count += 1
                    elif not need_info: info_not_requested += 1
        if not core_hits:
            rejects.append({"ticker":t,"score":fnum(row.get("scanner_priority_score")),"priority":pscore,"reasons":reasons[:8] if reasons else core_fail[:8],"price":row.get("current_price"),"updated_ts":ts,"info_pending":bool(info_bad),"info_needed":bool(need_info),"near_s_info_pending":False,"cheap_bucket":cheap_bucket})
        elif not (not hard_bad and not info_bad):
            rejects.append({"ticker":t,"score":fnum(row.get("scanner_priority_score")),"priority":pscore,"reasons":reasons[:8],"price":row.get("current_price"),"updated_ts":ts,"info_pending":bool(info_bad),"info_needed":bool(need_info),"near_s_info_pending":bool(core_hits and info_bad and not hard_bad),"cheap_bucket":cheap_bucket})
    events.sort(key=lambda e:(0 if str(e.get('s_stage') or e.get('candidate_grade')).upper()=='S1' else -1, fnum(e.get("score")), _event_created_ts(e)), reverse=True)
    latest, appended = persist_paper_handoff(events, evaluated=len(rows))
    ctr={}
    for r in rejects:
        for reason in r.get("reasons",[])[:5]: ctr[reason]=ctr.get(reason,0)+1
    top=sorted(ctr.items(), key=lambda x:x[1], reverse=True)[:20]
    priority_requests = sorted(priority_requests, key=lambda x: fnum(x.get("priority"), default=0), reverse=True)
    target = list(dict.fromkeys([r.get("ticker") for r in priority_requests if r.get("ticker")]))
    save_json(PRIORITY_REQ,{"version":VERSION,"updated_ts":ts,"updated_text":now_text(ts),"request_count":len(priority_requests),"targets":target,"requests":priority_requests,"buckets":priority_buckets,"cheap_buckets":cheap_buckets,"stage_source_counts":stage_source_counts,"note":"v0.19/v367: S1 안전문 유지 + S2/S3 관찰배관 복구. core 정보대기/차단/근접 후보를 OPEN 없이 복기용으로 저장."})
    tq=load_json(TARGET_ROUTER_QUEUE,{}) or {}
    active_set=set(tq.get("active_targets",[]) if isinstance(tq,dict) and isinstance(tq.get("active_targets"),list) else [])
    priority_wait_sample=[]
    for pr in priority_requests[:12]:
        tt=ticker_norm(pr.get("ticker")); of=ofmap.get(tt,{}) or {}
        priority_wait_sample.append({"ticker": tt,"bucket": pr.get("bucket"),"need": pr.get("need"),"priority": pr.get("priority"),"quote_ready": bool(of.get("quote_fresh") or of.get("ws_fresh")),"micro_ready": bool(of.get("micro_fresh")),"info_ready": bool((of.get("quote_fresh") or of.get("ws_fresh")) and of.get("micro_fresh")),"router_active": tt in active_set or bool(of.get("router_active")),"micro_age_sec": of.get("micro_age_sec"),"quote_age_sec": of.get("quote_age_sec"),"reasons": pr.get("reasons",[])[:4]})
    stage_counts={"S1":0,"S2":0,"S3":0}
    for ev in latest:
        g=str(ev.get('s_stage') or ev.get('candidate_grade') or ev.get('grade') or 'S3').upper()
        if g == 'S': g='S1'
        if g in stage_counts: stage_counts[g]+=1
    common_summary={"version":VERSION,"updated_ts":ts,"updated_text":now_text(ts),"s_count":len(events),"paper_latest_count":len(latest),"archive_appended":appended,"strategies":strat_counts,"events":latest[:12],"evaluated":len(rows),"s_stage_counts":stage_counts,"stage_source_counts":stage_source_counts,"info_needed_count":info_needed_count,"info_pending_count":info_pending,"near_s_info_pending":near_s_info_pending,"fresh_ready_count":fresh_ready_count,"cheap_reject_count":cheap_drop_count,"hard_blocked_near_s":hard_blocked,"priority_request_count":len(priority_requests),"priority_buckets":priority_buckets,"cheap_buckets":cheap_buckets,"target_count":len(target),"info_not_requested":info_not_requested,"orderflow_attached_count":orderflow_attached_count,"quote_ready_count":quote_ready_count,"micro_ready_count":micro_ready_count,"full_info_ready_count":full_info_ready_count,"router_target_count":tq.get("active_target_count", tq.get("target_count","-")),"router_queue_count":tq.get("queue_count","-"),"router_backlog_count":tq.get("backlog_count","-"),"router_fresh_recovered":tq.get("fresh_recovered","-"),"router_need_ws":tq.get("need_ws","-"),"router_need_micro":tq.get("need_micro","-"),"router_micro_priority_target_count":tq.get("micro_priority_target_count","-"),"router_strategy_req_info_ready":tq.get("strategy_req_info_ready","-"),"priority_wait_sample":priority_wait_sample,"note":"v0.19/v367: S1은 엄격, S2/S3는 OPEN 없이 관찰·복기용으로 저장"}
    save_json(SUMMARY,common_summary)
    save_json(REJECT,{**common_summary,"reject_count":len(rejects),"reason_top":[{"reason":k,"count":v} for k,v in top],"sample":rejects[:30],"note":"v0.19/v367: S2/S3 관찰 후보를 살리되 S1 즉시진입은 안전문 유지."})
    sec=now_ts()-st; write_status("running", evaluated=len(rows), s_count=len(events), paper_latest_count=len(latest), s1_count=stage_counts.get('S1',0), s2_count=stage_counts.get('S2',0), s3_count=stage_counts.get('S3',0), info_needed_count=info_needed_count, info_pending_count=info_pending, near_s_info_pending=near_s_info_pending, cheap_reject_count=cheap_drop_count, fresh_ready_count=fresh_ready_count, info_not_requested=info_not_requested, orderflow_attached_count=orderflow_attached_count, quote_ready_count=quote_ready_count, micro_ready_count=micro_ready_count, full_info_ready_count=full_info_ready_count, priority_request_count=len(priority_requests), target_count=len(target), router_target_count=tq.get("active_target_count", tq.get("target_count","-")), router_queue_count=tq.get("queue_count","-"), router_backlog_count=tq.get("backlog_count","-"), last_sec=round(sec,3)); return {"eval":len(rows),"s":len(events),"paper_latest":len(latest),"s_stage_counts":stage_counts,"priority_requests":len(priority_requests),"info_needed":info_needed_count,"info_pending":info_pending,"cheap_drop":cheap_drop_count}



# =============================================================================
# strategy_worker v0.22 / v370: 끊긴 main_version stamping 본선 재연결
# - v367은 near 조건이 strict eval 실패 개수에 묶여 S2/S3가 0으로 죽었다.
# - v368은 strict S1 안전문은 유지하되, 거래대금·흐름·위치·주도성 기반 관찰 후보를 S2/S3로 별도 저장한다.
# - S2/S3는 paper OPEN 대상이 아니며 복기/1시간요약/정보보강 대상이다.
# =============================================================================
VERSION = "strategy_worker_v0.24"
MAIN_VERSION = "v2.13.377"


def _v370_apply_main_version(ev: Dict[str, Any]) -> Dict[str, Any]:
    """v370 worker-only surgery.
    v369 tail called a removed _v368_apply_main_version() helper and strategy worker
    stopped before writing paper/S2/S3 handoff files. This is not a fallback; it is
    the single metadata stamping path used right before S1/S2/S3 persistence.
    """
    out = dict(ev or {})
    main_version = MAIN_VERSION
    main_bot_version = globals().get("MAIN_BOT_VERSION", f"수익형 {main_version}")
    out["main_version"] = main_version
    out["deploy_version"] = main_version
    out["main_bot_version"] = main_bot_version
    out["strategy_worker_version"] = VERSION
    out["worker_patch"] = "v370_strategy_main_version_stamping"
    ctx = out.get("entry_context") if isinstance(out.get("entry_context"), dict) else {}
    ctx.update({
        "main_version": main_version,
        "deploy_version": main_version,
        "main_bot_version": main_bot_version,
        "strategy_worker_version": VERSION,
    })
    out["entry_context"] = ctx
    snap = out.get("entry_snapshot") if isinstance(out.get("entry_snapshot"), dict) else None
    if snap is not None:
        snap["main_version"] = main_version
        snap["deploy_version"] = main_version
        snap["strategy_worker_version"] = VERSION
        flat = snap.get("flat") if isinstance(snap.get("flat"), dict) else {}
        flat.update({
            "main_version": main_version,
            "deploy_version": main_version,
            "main_bot_version": main_bot_version,
            "strategy_worker_version": VERSION,
        })
        snap["flat"] = flat
        out["entry_snapshot"] = snap
    return out


def _v368_soft_signal(row: Dict[str, Any], of: Dict[str, Any]) -> Tuple[str, str, List[str], float]:
    """v369: strict S1은 아니어도 복기할 가치가 있는 후보를 S2/S3로 남긴다.
    쓰레기 후보(거래대금 부족/강한 매도압력)는 제외한다.
    """
    ch1=fnum(row.get('change_1m'), row.get('price_change_1m'), default=0.0)
    ch3=fnum(row.get('change_3m'), row.get('price_change_3m'), default=0.0)
    ch5=fnum(row.get('change_5m'), row.get('price_change_5m'), default=0.0)
    ch15=fnum(row.get('change_15m'), row.get('price_change_15m'), default=0.0)
    ch30=fnum(row.get('change_30m'), row.get('price_change_30m'), default=0.0)
    money=fnum(row.get('turnover_24h'), row.get('acc_trade_price_24h'), default=0.0)
    vwap=fnum(row.get('vwap_gap_pct'), default=-9.0)
    ema=fnum(row.get('ema5_gap_pct'), row.get('ma5_gap_pct'), default=-9.0)
    rel=fnum(row.get('relative_strength_pct'), row.get('relative_strength'), default=0.0)
    day=fnum(row.get('day_pos_pct'), row.get('current_close_pos_ratio'), default=50.0)
    score=fnum(row.get('scanner_priority_score'), default=0.0)
    buy=fnum(of.get('buy_ratio'), of.get('buy_ratio_30s'), of.get('micro_trade_buy_ratio_30'), default=0.0)
    spread=fnum(of.get('spread_pct'), of.get('micro_spread_pct'), default=99.0)
    micro=bool(of.get('micro_fresh'))
    quote=bool(of.get('quote_fresh') or of.get('ws_fresh'))
    vol=bool(row.get('volume_expanding'))
    hard=common_hard(row, of)
    hard_text=','.join(map(str, hard))
    if money < 250_000_000:
        return '', '', ['거래대금부족'], 0.0
    if '매도벽/매도체결압력' in hard_text and buy < 0.68:
        return '', '', ['매도압력+매수부족'], 0.0
    info_missing = not (micro and quote) or spread > 0.18
    position_ok = (vwap >= -0.45 and ema >= -0.35)
    not_extreme_hot = not (day >= 98.5 and ch5 >= 5.0 and rel < 3.0)
    # 유동보유: 5/15/30분 흐름, 상대강도, 위치 중 2개 이상 살아있으면 관찰
    trend_score = 0
    if ch5 >= 0.35: trend_score += 1
    if ch15 >= 0.35: trend_score += 1
    if ch30 >= 0.10: trend_score += 1
    if rel >= 1.2: trend_score += 1
    if vol: trend_score += 1
    if position_ok: trend_score += 1
    if trend_score >= 4 and not_extreme_hot:
        reasons=['유동보유근접', f'흐름점수{trend_score}', f'5m{ch5:.2f}', f'15m{ch15:.2f}', f'상대{rel:.2f}']
        return ('S3' if info_missing else 'S2'), 'leader_flow_adaptive_hold_s', reasons, 105.0 + score + trend_score
    # 돈흐름/돌파 근접: 한두 재료만 있어도 완전 폐기하지 않고 S3 복기
    if (ch3 >= 0.45 and ch5 >= 0.45 and position_ok) or (rel >= 2.0 and ch5 >= 0.20):
        reasons=['S근접관찰', f'3m{ch3:.2f}', f'5m{ch5:.2f}', f'상대{rel:.2f}']
        return ('S3' if info_missing else 'S2'), 'money_reaccel_s', reasons, 95.0 + score
    return '', '', [], 0.0

def _v370_build_stage_event(row: Dict[str, Any], of: Dict[str, Any], skey: str, why: List[str], stage: str, reasons: List[str]) -> Dict[str, Any]:
    ev=build_event(row, of, skey, why or reasons)
    ev=_v360_force_stage(ev, stage, reasons[:10])
    ev=_v370_apply_main_version(ev)
    return ev


def run_once()->Dict[str,Any]:  # type: ignore[override]
    st=now_ts(); ts=now_ts(); write_status("running", phase="evaluating_v370", evaluated=0, s_count=0, target_count=0, last_sec=0)
    fobj=load_json(FEATURE,{}) or {}; rows=fobj.get("rows") if isinstance(fobj,dict) else []
    if not isinstance(rows,list): rows=[]
    ofmap=map_rows(load_json(ORDERFLOW,{}) or {})
    evals=[("leader_flow_adaptive_hold_s",eval_adaptive_hold),("money_reaccel_s",eval_money),("leader_momentum_s",eval_leader),("breakout_early_s",eval_breakout),("sweep_vwap_recovery_s",eval_sweep),("surge_rebreak_s",eval_surge)]
    events=[]; rejects=[]; priority_requests=[]; strat_counts={k:0 for k in STRATEGIES}
    info_pending=0; near_s_info_pending=0; hard_blocked=0; info_not_requested=0
    info_needed_count=0; cheap_drop_count=0; fresh_ready_count=0
    orderflow_attached_count=0; quote_ready_count=0; micro_ready_count=0; full_info_ready_count=0
    priority_buckets={}; cheap_buckets={}; stage_source_counts={"S1":0,"S2":0,"S3":0,"core_ready":0,"core_info_wait":0,"core_hard_block":0,"soft_observe":0}
    for row in rows:
        t=ticker_norm(row.get("ticker"))
        if not t: continue
        of=ofmap.get(t,{}) or {}
        if of: orderflow_attached_count += 1
        quote_ready=bool(of.get("quote_fresh") or of.get("ws_fresh")); micro_ready=bool(of.get("micro_fresh"))
        if quote_ready: quote_ready_count += 1
        if micro_ready: micro_ready_count += 1
        if quote_ready and micro_ready: full_info_ready_count += 1
        hard_bad=common_hard(row,of)
        reasons=[]; core_hits=[]; core_fail=[]
        for skey,fn in evals:
            try:
                ok,why,no=fn(row,of)
            except Exception as exc:
                ok=False; why=[]; no=[f"eval오류:{skey}"]
            if ok: core_hits.append((skey,why))
            else: core_fail += [f"{STRATEGIES.get(skey,skey)}:{x}" for x in list(no or [])[:2]]
        need_info, cheap_bucket=_cheap_gate(row, core_hits, hard_bad)
        cheap_buckets[cheap_bucket]=cheap_buckets.get(cheap_bucket,0)+1
        info_bad=orderflow_info_bad(of) if need_info else []
        need=[]
        if "시세정보보강대기" in info_bad: need.append("quote")
        if "WS정보보강대기" in info_bad: need.append("ws")
        if "micro정보보강대기" in info_bad: need.append("micro")
        if need_info: info_needed_count += 1
        if need_info and not info_bad: fresh_ready_count += 1
        pscore=_priority_score(row, core_hits, info_bad, hard_bad)
        if info_bad: info_pending += 1
        made=False
        if core_hits and not hard_bad and not info_bad:
            ev=_v370_build_stage_event(row,of,core_hits[0][0],core_hits[0][1],'S1', ['core_ready'])
            if len(core_hits)>1:
                ev["multi_strategy_s"]=[k for k,_ in core_hits]; ev["strategy_bucket_labels"]=[STRATEGIES.get(k,k) for k,_ in core_hits]
            events.append(ev); made=True
            g=str(ev.get('s_stage') or 'S3').upper(); stage_source_counts[g if g in stage_source_counts else 'S3']+=1; stage_source_counts['core_ready']+=1
            strat_counts[core_hits[0][0]]+=1
            priority_requests.append(_make_priority_request(t,row,"s1_candidate",130+pscore,["quote","micro"],core_hits,["S1후보"]))
            priority_buckets["s1_candidate"]=priority_buckets.get("s1_candidate",0)+1
        elif core_hits and info_bad and not hard_bad:
            near_s_info_pending += 1
            reasons += [f"정보보강대기:{x}" for x in info_bad[:3]] + [f"S2재확인:{STRATEGIES.get(k,k)}" for k,_ in core_hits[:2]]
            ev=_v370_build_stage_event(row,of,core_hits[0][0],core_hits[0][1],'S2',reasons)
            events.append(ev); made=True; stage_source_counts['S2']+=1; stage_source_counts['core_info_wait']+=1
            priority_requests.append(_make_priority_request(t,row,"s2_recheck_info_wait",115+pscore,need or ["quote","micro"],core_hits,reasons))
            priority_buckets["s2_recheck_info_wait"]=priority_buckets.get("s2_recheck_info_wait",0)+1
        elif core_hits and hard_bad:
            hard_blocked += 1
            reasons += hard_bad[:4] + [f"S3관찰:{STRATEGIES.get(k,k)}" for k,_ in core_hits[:2]]
            ev=_v370_build_stage_event(row,of,core_hits[0][0],core_hits[0][1],'S3',reasons)
            events.append(ev); made=True; stage_source_counts['S3']+=1; stage_source_counts['core_hard_block']+=1
        else:
            stage, skey, soft_reasons, bonus = _v368_soft_signal(row, of)
            if stage:
                ev=_v370_build_stage_event(row,of,skey,soft_reasons,stage,soft_reasons)
                events.append(ev); made=True; stage_source_counts[stage]+=1; stage_source_counts['soft_observe']+=1
                priority = bonus + (15 if stage=='S2' else 0)
                if stage=='S2': near_s_info_pending += 1
                bucket='s2_recheck_soft' if stage=='S2' else 's3_observe_soft'
                priority_requests.append(_make_priority_request(t,row,bucket,priority,need or ["quote","micro"],[(skey,soft_reasons)],soft_reasons))
                priority_buckets[bucket]=priority_buckets.get(bucket,0)+1
        if not made:
            if info_bad:
                reasons += [f"정보보강대기:{x}" for x in info_bad[:2]]
            reasons += hard_bad[:2] + core_fail[:4]
            if info_bad:
                bucket="info_wait_high"; priority_requests.append(_make_priority_request(t,row,bucket,70+pscore,need,core_hits,reasons)); priority_buckets[bucket]=priority_buckets.get(bucket,0)+1
            else:
                if cheap_bucket == "cheap_drop": cheap_drop_count += 1
                elif not need_info: info_not_requested += 1
            rejects.append({"ticker":t,"score":fnum(row.get("scanner_priority_score")),"priority":pscore,"reasons":reasons[:8] if reasons else core_fail[:8],"price":row.get("current_price"),"updated_ts":ts,"info_pending":bool(info_bad),"info_needed":bool(need_info),"near_s_info_pending":False,"cheap_bucket":cheap_bucket})
    events.sort(key=lambda e:(0 if str(e.get('s_stage') or e.get('candidate_grade')).upper()=='S1' else (-1 if str(e.get('s_stage') or e.get('candidate_grade')).upper()=='S2' else -2), fnum(e.get("score")), _event_created_ts(e)), reverse=True)
    latest, appended = persist_paper_handoff(events, evaluated=len(rows))
    ctr={}
    for r in rejects:
        for reason in r.get("reasons",[])[:5]: ctr[reason]=ctr.get(reason,0)+1
    top=sorted(ctr.items(), key=lambda x:x[1], reverse=True)[:20]
    priority_requests=sorted(priority_requests, key=lambda x:fnum(x.get("priority"), default=0), reverse=True)
    target=list(dict.fromkeys([r.get("ticker") for r in priority_requests if r.get("ticker")]))
    save_json(PRIORITY_REQ,{"version":VERSION,"main_version":MAIN_VERSION,"updated_ts":ts,"updated_text":now_text(ts),"request_count":len(priority_requests),"targets":target,"requests":priority_requests,"buckets":priority_buckets,"cheap_buckets":cheap_buckets,"stage_source_counts":stage_source_counts,"note":"v0.24/v378: S3→S2→S1 재평가 흐름. feature/orderflow canonical 판단값을 사용하고, 정보미생성은 진짜 정보부족으로만 남긴다."})
    tq=load_json(TARGET_ROUTER_QUEUE,{}) or {}
    active_set=set(tq.get("active_targets",[]) if isinstance(tq,dict) and isinstance(tq.get("active_targets"),list) else [])
    priority_wait_sample=[]
    for pr in priority_requests[:12]:
        tt=ticker_norm(pr.get("ticker")); of=ofmap.get(tt,{}) or {}
        priority_wait_sample.append({"ticker":tt,"bucket":pr.get("bucket"),"need":pr.get("need"),"priority":pr.get("priority"),"quote_ready":bool(of.get("quote_fresh") or of.get("ws_fresh")),"micro_ready":bool(of.get("micro_fresh")),"info_ready":bool((of.get("quote_fresh") or of.get("ws_fresh")) and of.get("micro_fresh")),"router_active":tt in active_set or bool(of.get("router_active")),"micro_age_sec":of.get("micro_age_sec"),"quote_age_sec":of.get("quote_age_sec"),"reasons":pr.get("reasons",[])[:4]})
    stage_counts={"S1":0,"S2":0,"S3":0}
    for ev in latest:
        g=str(ev.get('s_stage') or ev.get('candidate_grade') or ev.get('grade') or 'S3').upper()
        if g == 'S': g='S1'
        if g in stage_counts: stage_counts[g]+=1
    common_summary={"version":VERSION,"main_version":MAIN_VERSION,"updated_ts":ts,"updated_text":now_text(ts),"s_count":len(events),"paper_latest_count":len(latest),"archive_appended":appended,"strategies":strat_counts,"events":latest[:12],"evaluated":len(rows),"s_stage_counts":stage_counts,"stage_source_counts":stage_source_counts,"info_needed_count":info_needed_count,"info_pending_count":info_pending,"near_s_info_pending":near_s_info_pending,"fresh_ready_count":fresh_ready_count,"cheap_reject_count":cheap_drop_count,"hard_blocked_near_s":hard_blocked,"priority_request_count":len(priority_requests),"priority_buckets":priority_buckets,"cheap_buckets":cheap_buckets,"target_count":len(target),"info_not_requested":info_not_requested,"orderflow_attached_count":orderflow_attached_count,"quote_ready_count":quote_ready_count,"micro_ready_count":micro_ready_count,"full_info_ready_count":full_info_ready_count,"router_target_count":tq.get("active_target_count",tq.get("target_count","-")),"router_queue_count":tq.get("queue_count","-"),"router_backlog_count":tq.get("backlog_count","-"),"priority_wait_sample":priority_wait_sample,"note":"v0.24/v378: S3 관찰→S2 재확인→S1 즉시진입 흐름. micro/WS fresh에서 판단값 누락이 생기지 않도록 canonical schema 기준으로 재평가."}
    save_json(SUMMARY,common_summary)
    save_json(REJECT,{**common_summary,"reject_count":len(rejects),"reason_top":[{"reason":k,"count":v} for k,v in top],"sample":rejects[:30],"note":"v0.23/v374: 실제 쓰레기 후보만 탈락. 정보부족 근접 후보는 S2 정보보강/긴급재확인으로 저장."})
    sec=now_ts()-st
    write_status("running", evaluated=len(rows), s_count=len(events), paper_latest_count=len(latest), s1_count=stage_counts.get('S1',0), s2_count=stage_counts.get('S2',0), s3_count=stage_counts.get('S3',0), info_needed_count=info_needed_count, info_pending_count=info_pending, near_s_info_pending=near_s_info_pending, cheap_reject_count=cheap_drop_count, fresh_ready_count=fresh_ready_count, info_not_requested=info_not_requested, orderflow_attached_count=orderflow_attached_count, quote_ready_count=quote_ready_count, micro_ready_count=micro_ready_count, full_info_ready_count=full_info_ready_count, priority_request_count=len(priority_requests), target_count=len(target), router_target_count=tq.get("active_target_count",tq.get("target_count","-")), router_queue_count=tq.get("queue_count","-"), router_backlog_count=tq.get("backlog_count","-"), last_sec=round(sec,3))
    return {"eval":len(rows),"s":len(events),"paper_latest":len(latest),"s_stage_counts":stage_counts,"priority_requests":len(priority_requests),"info_needed":info_needed_count,"info_pending":info_pending,"cheap_drop":cheap_drop_count}


# =============================================================================
# strategy_worker v0.23: S1 근접 정보부족 긴급보강
# - core_ready라고 무조건 S1로 강제하지 않는다.
# - 가격반응/체결지속/슬리피지/호가 세부값이 미확인인 S1 근접 후보는
#   S2 정보보강대기로 남기고 target_router 우선요청에 태운다.
# - 정보부족 문구를 s_stage_reasons/entry_context에 명확히 남긴다.
# =============================================================================

def _v374_is_info_shortage_reason(x: Any) -> bool:
    t = str(x or '')
    return any(k in t for k in ('미확인', '정보보강', '재확인필요', '슬리피지미확인', 'micro재확인', 'WS재확인'))

def _v374_s1_info_need(row: Dict[str, Any], of: Dict[str, Any], stage_reasons: List[str]) -> Tuple[bool, List[str], List[str]]:
    reasons = [str(x) for x in (stage_reasons or []) if str(x or '').strip()]
    info_tags = [x for x in reasons if _v374_is_info_shortage_reason(x)]
    need: List[str] = []
    txt = ','.join(info_tags)
    if 'micro' in txt or '매수체결' in txt or '스프레드' in txt or '슬리피지' in txt or '매도벽' in txt:
        need.append('micro')
    if 'WS' in txt or '가격반응' in txt or '시세' in txt:
        need.append('quote'); need.append('ws')
    # orderflow_info_bad는 quote/micro fresh만 보므로, 세부 미확인값도 여기서 보강 대상으로 승격한다.
    if not need and info_tags:
        need = ['quote', 'micro']
    return (bool(info_tags), list(dict.fromkeys(need)), info_tags[:8])

_v374_prev_build_stage_event = _v370_build_stage_event

def _v370_build_stage_event(row: Dict[str, Any], of: Dict[str, Any], skey: str, why: List[str], stage: str, reasons: List[str]) -> Dict[str, Any]:  # type: ignore[override]
    ev = build_event(row, of, skey, why or reasons)
    # build_event 안의 S1/S2/S3 실제 안전문 판단을 먼저 존중한다.
    pre_stage = str(ev.get('s_stage') or ev.get('candidate_grade') or '').upper()
    pre_reasons = list(ev.get('s_stage_reasons') if isinstance(ev.get('s_stage_reasons'), list) else [])
    requested_stage = str(stage or 'S3').upper()
    info_wait, need, info_tags = _v374_s1_info_need(row, of, pre_reasons)
    final_stage = requested_stage
    final_reasons = list(reasons or [])
    if requested_stage == 'S1' and (pre_stage != 'S1' or info_wait):
        # 전략 core는 맞지만 S1 직전 정보가 비어 있으면 탈락/무시가 아니라 S2 정보보강대기로 둔다.
        final_stage = 'S2'
        final_reasons = ['S1정보부족재확인'] + info_tags + final_reasons
    ev = _v360_force_stage(ev, final_stage, final_reasons[:10])
    if final_stage == 'S2' and (info_wait or any(_v374_is_info_shortage_reason(x) for x in final_reasons)):
        ev['info_shortage_pending'] = True
        ev['urgent_recheck_needed'] = True
        ev['info_shortage_reasons'] = info_tags or [x for x in final_reasons if _v374_is_info_shortage_reason(x)][:8]
        ev['info_shortage_need'] = need or ['quote', 'micro']
        ev['recheck_required'] = True
        ev['recheck_reason'] = 'S1정보부족재확인'
        ev['summary_reason'] = ','.join((['S1정보부족재확인'] + (info_tags or []))[:5])
        ctx = ev.get('entry_context') if isinstance(ev.get('entry_context'), dict) else {}
        ctx.update({
            'info_shortage_pending': True,
            'urgent_recheck_needed': True,
            'info_shortage_reasons': ev.get('info_shortage_reasons'),
            'info_shortage_need': ev.get('info_shortage_need'),
            'recheck_reason': 'S1정보부족재확인',
        })
        ev['entry_context'] = ctx
    ev = _v370_apply_main_version(ev)
    ev['worker_patch'] = 'v378_canonical_s123_promotion'
    return ev



# =============================================================================
# strategy_worker v0.25 / v379: S1/S2/S3 생애주기 상태머신 본선
# - S1/S2/S3는 점수 등급이 아니라 후보 흐름이다.
# - S3 관찰포착 -> S2 재확인 -> S1 최종진입 순서로만 승격한다.
# - S2/S3는 승패 대상이 아니며 승격률/놓친상승률/정보보강 상태만 추적한다.
# - 기존 전략 조건/청산/자동매수는 변경하지 않는다.
# =============================================================================
VERSION = "strategy_worker_v0.26"
LIFECYCLE = BASE_DIR / "clean_strategy_s123_lifecycle.json"
_v379_base_run_once = run_once

_STAGE_RANK = {"S3": 1, "S2": 2, "S1": 3}
_STAGE_LABEL = {"S1": "✅ S1 최종진입", "S2": "⚠️ S2 재확인", "S3": "❔ S3 관찰포착"}

def _v379_stage_norm(v: Any) -> str:
    g = str(v or "").upper().strip()
    if g == "S":
        return "S1"
    if g in {"S1", "S2", "S3"}:
        return g
    return "S3"

def _v379_life_key(ev: Dict[str, Any]) -> str:
    t = ticker_norm(ev.get("ticker") or ev.get("market") or ev.get("symbol")) or "UNKNOWN"
    # S3/S2/S1은 같은 코인의 생애주기이므로 전략별로 쪼개지 않는다.
    # 대표 전략은 별도 필드로만 보존한다.
    return t

def _v379_price(ev: Dict[str, Any]) -> float:
    ctx = ev.get("entry_context") if isinstance(ev.get("entry_context"), dict) else {}
    snap = ev.get("entry_snapshot") if isinstance(ev.get("entry_snapshot"), dict) else {}
    flat = snap.get("flat") if isinstance(snap.get("flat"), dict) else {}
    return fnum(ev.get("current_price"), ev.get("entry_price"), ev.get("price"), ev.get("detected_price"), ctx.get("current_price"), ctx.get("entry_price"), flat.get("current_price"), flat.get("entry_price"), default=0.0)

def _v379_load_lifecycle() -> Dict[str, Any]:
    obj = load_json(LIFECYCLE, {}) or {}
    if not isinstance(obj, dict):
        obj = {}
    items = obj.get("items") if isinstance(obj.get("items"), dict) else {}
    return {"version": VERSION, "updated_ts": now_ts(), "items": dict(items)}

def _v379_save_lifecycle(life: Dict[str, Any], stats: Dict[str, Any]) -> None:
    nowv = now_ts()
    items = life.get("items") if isinstance(life.get("items"), dict) else {}
    # 2시간 이상 안 보인 후보는 순환 제거. 장부/체결 기록은 건드리지 않는다.
    keep = {}
    for k, v in items.items():
        if not isinstance(v, dict):
            continue
        last = fnum(v.get("last_seen_ts"), default=0.0)
        if last and nowv - last <= 7200:
            keep[k] = v
    out = {
        "version": VERSION,
        "schema": "s123_lifecycle_v379",
        "updated_ts": nowv,
        "updated_text": now_text(nowv),
        "items": keep,
        "stats": stats,
        "note": "S3/S2/S1은 점수 등급이 아니라 생애주기다. S2/S3 승패 대신 승격/정보보강/놓친상승을 본다.",
    }
    save_json(LIFECYCLE, out)

def _v379_signal_ready(ev: Dict[str, Any]) -> Tuple[bool, List[str]]:
    """S2 -> S1 승격 전에 필요한 판단값이 실제로 채워졌는지 본다.
    조건을 새로 풀지 않고, v378 canonical 값 존재 여부와 S1 판단 결과를 함께 확인한다.
    """
    ctx = ev.get("entry_context") if isinstance(ev.get("entry_context"), dict) else {}
    snap = ev.get("entry_snapshot") if isinstance(ev.get("entry_snapshot"), dict) else {}
    flat = snap.get("flat") if isinstance(snap.get("flat"), dict) else {}
    def val(*keys: str, default: float = -999.0) -> float:
        vals = []
        for src in (ev, ctx, flat):
            if isinstance(src, dict):
                vals += [src.get(k) for k in keys]
        return fnum(*vals, default=default)
    def known(*keys: str) -> bool:
        for src in (ev, ctx, flat):
            if not isinstance(src, dict):
                continue
            for k in keys:
                v = src.get(k)
                if v is not None and str(v).strip() not in {"", "-", "None", "nan"}:
                    return True
        return False
    miss: List[str] = []
    pr_known = known("price_reaction_score", "price_reaction_pct", "price_recheck_pct", "change_1m", "change_3m")
    br_known = known("buy_ratio_1m", "micro_buy_ratio_sustain_1m", "buy_ratio", "buy_ratio_30s")
    sl_known = known("slippage_est_pct", "tick_pct_est", "spread_pct")
    if not pr_known: miss.append("가격반응판단값없음")
    if not br_known: miss.append("체결지속판단값없음")
    if not sl_known: miss.append("슬리피지판단값없음")
    spread = val("spread_pct", "micro_spread_pct", default=99.0)
    buy = val("buy_ratio_1m", "micro_buy_ratio_sustain_1m", "buy_ratio", "buy_ratio_30s", default=0.0)
    ch1 = val("price_reaction_pct", "price_recheck_pct", "change_1m", "price_change_1m", default=0.0)
    ch3 = val("money_flow_3m_pct", "three_min_flow_pct", "change_3m", "price_change_3m", default=0.0)
    # 이 기준은 신규 전략 조건이 아니라 S1 진입 가능 신호가 계산됐는지/무너졌는지 보는 최소 검문소다.
    if spread > 0.28: miss.append("스프레드과다")
    if buy and buy < 0.58: miss.append("매수체결약함")
    if ch1 < -0.40 and ch3 < -0.40: miss.append("가격반응역행")
    return (not miss), miss[:8]

def _v379_apply_lifecycle_to_event(ev: Dict[str, Any], rec: Dict[str, Any], new_stage: str, reasons: List[str], nowv: float) -> Dict[str, Any]:
    out = dict(ev or {})
    old = str(rec.get("stage") or "")
    label = _STAGE_LABEL.get(new_stage, new_stage)
    life_age = max(0.0, nowv - fnum(rec.get("first_seen_ts"), default=nowv))
    recheck_count = int(fnum(rec.get("recheck_count"), default=0))
    out.update({
        "s_stage": new_stage,
        "candidate_grade": new_stage,
        "grade": new_stage,
        "entry_grade": new_stage,
        "signal_grade": new_stage,
        "candidate_grade_label": label,
        "paper_bot_open": new_stage == "S1",
        "open_eligible": new_stage == "S1",
        "trade_ready": new_stage == "S1",
        "observe_only": new_stage == "S3",
        "recheck_required": new_stage == "S2",
        "lifecycle_schema": "s123_lifecycle_v379",
        "lifecycle_stage": new_stage,
        "previous_lifecycle_stage": old or None,
        "lifecycle_age_sec": round(life_age, 2),
        "recheck_count": recheck_count,
        "first_seen_price": rec.get("first_seen_price"),
        "highest_after_seen": rec.get("highest_price"),
        "highest_after_seen_pct": rec.get("highest_pct"),
        "stage_transition": f"{old or 'NEW'}->{new_stage}",
        "promote_reason": reasons[:8],
        "s_stage_reasons": reasons[:8] or list(out.get("s_stage_reasons") if isinstance(out.get("s_stage_reasons"), list) else [])[:8],
        "final_entry_action": "paper_open" if new_stage == "S1" else ("recheck_wait" if new_stage == "S2" else "observe"),
        "summary_reason": ",".join((reasons or [label])[:5]),
        "worker_patch": "v379_s123_lifecycle_state_machine",
    })
    ctx = out.get("entry_context") if isinstance(out.get("entry_context"), dict) else {}
    ctx.update({k: out.get(k) for k in ("lifecycle_schema", "lifecycle_stage", "previous_lifecycle_stage", "lifecycle_age_sec", "recheck_count", "first_seen_price", "highest_after_seen", "highest_after_seen_pct", "stage_transition", "promote_reason", "s_stage", "candidate_grade", "paper_bot_open", "open_eligible", "trade_ready")})
    out["entry_context"] = ctx
    snap = out.get("entry_snapshot") if isinstance(out.get("entry_snapshot"), dict) else None
    if snap is not None:
        strat = snap.get("strategy") if isinstance(snap.get("strategy"), dict) else {}
        strat.update({"decision_stage": new_stage, "decision_note": label, "lifecycle_stage": new_stage, "stage_transition": out.get("stage_transition"), "promote_reason": reasons[:8]})
        snap["strategy"] = strat
        flat = snap.get("flat") if isinstance(snap.get("flat"), dict) else {}
        flat.update({"s_stage": new_stage, "candidate_grade": new_stage, "lifecycle_stage": new_stage, "stage_transition": out.get("stage_transition")})
        snap["flat"] = flat
        out["entry_snapshot"] = snap
    return out

def _v379_finalize_lifecycle(base_result: Dict[str, Any]) -> Dict[str, Any]:
    nowv = now_ts()
    rows = [r for r in read_jsonl(PAPER_LATEST, max_lines=160) if isinstance(r, dict)]
    life = _v379_load_lifecycle()
    items = life.get("items") if isinstance(life.get("items"), dict) else {}
    revised: List[Dict[str, Any]] = []
    transitions = {"new_s3": 0, "s3_to_s2": 0, "s2_to_s1": 0, "s2_hold": 0, "s3_hold": 0, "demoted_or_reset": 0, "blocked_s1_signal": 0}
    stage_counts = {"S1": 0, "S2": 0, "S3": 0}
    for ev in rows:
        key = _v379_life_key(ev)
        obs = _v379_stage_norm(ev.get("s_stage") or ev.get("candidate_grade") or ev.get("grade"))
        price = _v379_price(ev)
        rec = items.get(key) if isinstance(items.get(key), dict) else {}
        if not rec:
            rec = {"ticker": key, "first_seen_ts": nowv, "first_seen_text": now_text(nowv), "first_seen_price": price, "stage": "S3", "recheck_count": 0, "highest_price": price, "highest_pct": 0.0, "strategy_keys": []}
            new_stage = "S3"
            reasons = ["S3관찰포착", f"관측단계:{obs}"]
            transitions["new_s3"] += 1
        else:
            old_stage = _v379_stage_norm(rec.get("stage"))
            first_price = fnum(rec.get("first_seen_price"), default=price)
            high = max(fnum(rec.get("highest_price"), default=0.0), price)
            rec["highest_price"] = high
            rec["highest_pct"] = round(((high - first_price) / first_price * 100.0), 3) if first_price else 0.0
            # 새 관측값이 S1이라도 생애주기는 S3->S2->S1 순서로만 올린다.
            if old_stage == "S3":
                if _STAGE_RANK.get(obs, 1) >= 2:
                    new_stage = "S2"; transitions["s3_to_s2"] += 1
                    reasons = ["S3→S2승격", f"관측단계:{obs}"]
                else:
                    new_stage = "S3"; transitions["s3_hold"] += 1
                    reasons = ["S3관찰유지", f"관측단계:{obs}"]
            elif old_stage == "S2":
                signal_ok, signal_miss = _v379_signal_ready(ev)
                if obs == "S1" and signal_ok:
                    new_stage = "S1"; transitions["s2_to_s1"] += 1
                    reasons = ["S2→S1승격", "최종진입판단값확인"]
                elif obs == "S1" and not signal_ok:
                    new_stage = "S2"; transitions["blocked_s1_signal"] += 1
                    reasons = ["S1승격보류"] + signal_miss
                elif obs == "S2":
                    new_stage = "S2"; transitions["s2_hold"] += 1
                    reasons = ["S2재확인유지"]
                else:
                    new_stage = "S3"; transitions["demoted_or_reset"] += 1
                    reasons = ["S2→S3강등", f"관측단계:{obs}"]
            else:  # old S1은 paper가 읽을 수 있게 한 사이클 유지하되, 다음 관측이 내려가면 강등
                if obs == "S1":
                    new_stage = "S1"; reasons = ["S1진입유지"]
                elif obs == "S2":
                    new_stage = "S2"; transitions["demoted_or_reset"] += 1; reasons = ["S1→S2강등"]
                else:
                    new_stage = "S3"; transitions["demoted_or_reset"] += 1; reasons = ["S1→S3강등"]
        rec["stage"] = new_stage
        rec["last_observed_stage"] = obs
        rec["last_seen_ts"] = nowv
        rec["last_seen_text"] = now_text(nowv)
        rec["last_price"] = price
        if not fnum(rec.get("first_seen_price"), default=0.0) and price:
            rec["first_seen_price"] = price
        first_price = fnum(rec.get("first_seen_price"), default=price)
        rec["highest_price"] = max(fnum(rec.get("highest_price"), default=0.0), price)
        rec["highest_pct"] = round(((fnum(rec.get("highest_price"), default=0.0) - first_price) / first_price * 100.0), 3) if first_price else 0.0
        rec["recheck_count"] = int(fnum(rec.get("recheck_count"), default=0)) + (1 if new_stage == "S2" else 0)
        sk = str(ev.get("strategy_key") or ev.get("strategy_bucket_primary") or "")
        if sk:
            keys = list(rec.get("strategy_keys") if isinstance(rec.get("strategy_keys"), list) else [])
            if sk not in keys:
                keys.append(sk)
            rec["strategy_keys"] = keys[:8]
        items[key] = rec
        stage_counts[new_stage] += 1
        revised.append(_v379_apply_lifecycle_to_event(ev, rec, new_stage, reasons, nowv))
    # 생애주기에서 S1/S2/S3 순서가 반영된 latest를 다시 쓴다.
    latest, appended = persist_paper_handoff(revised, evaluated=int((load_json(SUMMARY, {}) or {}).get("evaluated") or 0))
    stats = {"stage_counts": stage_counts, "transitions": transitions, "active_count": len(items), "latest_count": len(latest), "archive_appended": appended}
    _v379_save_lifecycle({"items": items}, stats)
    # strategy summary에도 생애주기 통계를 실어 main /score, /quality에서 볼 수 있게 한다.
    try:
        sm = load_json(SUMMARY, {}) or {}
        sm.update({
            "version": VERSION,
            "lifecycle_schema": "s123_lifecycle_v379",
            "lifecycle_stats": stats,
            "s_stage_counts": stage_counts,
            "paper_latest_count": len(latest),
            "s_count": len(latest),
            "note": "v0.25/v379: S1/S2/S3는 등급이 아니라 S3→S2→S1 생애주기. S2/S3는 승패가 아니라 승격/복기 지표다.",
        })
        save_json(SUMMARY, sm)
    except Exception as exc:
        append_error(ERROR, "v379_summary_update", exc)
    try:
        pr = load_json(PRIORITY_REQ, {}) or {}
        if isinstance(pr, dict):
            pr["version"] = VERSION
            pr["lifecycle_schema"] = "s123_lifecycle_v379"
            pr["lifecycle_stats"] = stats
            pr["note"] = "v379: target_router 요청은 생애주기 S2/S3 정보보강을 우선한다. S2/S3는 OPEN 승패 대상이 아니다."
            save_json(PRIORITY_REQ, pr)
    except Exception as exc:
        append_error(ERROR, "v379_priority_update", exc)
    try:
        write_status("running", evaluated=int((load_json(SUMMARY, {}) or {}).get("evaluated") or 0), s_count=len(latest), paper_latest_count=len(latest), s1_count=stage_counts.get("S1", 0), s2_count=stage_counts.get("S2", 0), s3_count=stage_counts.get("S3", 0), lifecycle_schema="s123_lifecycle_v379", lifecycle_active=len(items), lifecycle_transitions=transitions, last_sec=fnum((base_result or {}).get("last_sec"), default=0.0))
    except Exception:
        pass
    out = dict(base_result or {})
    out.update({"s_stage_counts": stage_counts, "lifecycle_stats": stats, "paper_latest": len(latest), "s": len(latest)})
    return out

def run_once() -> Dict[str, Any]:  # type: ignore[override]
    base = _v379_base_run_once()
    return _v379_finalize_lifecycle(base)


# =============================================================================
# strategy_worker v0.26 / v383: 생애주기 승격 로직 수술
# - S3에서 실제로 오른 후보(+0.7% 이상)는 단순 관찰에 묶지 않고 S2 재확인으로 올린다.
# - S2는 관측값이 S1로 직접 올라오지 않아도, 가격추적 상승 + canonical 판단값 통과 시 S1로 올린다.
# - S2/S3는 여전히 OPEN하지 않는다. S1만 paper OPEN 대상이다.
# - 조건을 풀어 무조건 매수하는 수정이 아니라, 추적값/판단값을 승격에 실제 반영하는 배관 수술이다.
# =============================================================================
VERSION = "strategy_worker_v0.26"
_v383_base_run_once = run_once


def _v383_ev_val(ev: Dict[str, Any], *keys: str, default: float = 0.0) -> float:
    ctx = ev.get("entry_context") if isinstance(ev.get("entry_context"), dict) else {}
    snap = ev.get("entry_snapshot") if isinstance(ev.get("entry_snapshot"), dict) else {}
    flat = snap.get("flat") if isinstance(snap.get("flat"), dict) else {}
    strat = snap.get("strategy") if isinstance(snap.get("strategy"), dict) else {}
    for src in (ev, ctx, flat, strat):
        if not isinstance(src, dict):
            continue
        for k in keys:
            v = src.get(k)
            if v is not None and str(v).strip() not in {"", "-", "None", "nan"}:
                return fnum(v, default=default)
    return default


def _v383_gain_now(ev: Dict[str, Any], rec: Dict[str, Any]) -> float:
    price = _v379_price(ev)
    first = fnum(rec.get("first_seen_price"), default=0.0) or price
    if not first or not price:
        return 0.0
    return round((price - first) / first * 100.0, 3)


def _v383_promote_s3_to_s2(ev: Dict[str, Any], rec: Dict[str, Any], obs: str) -> Tuple[bool, List[str]]:
    """관찰 후보가 실제로 움직였으면 재확인 단계로 올린다.
    S2는 매수 단계가 아니라 재확인/정보보강 단계라서, +0.7% 이상 놓친 상승 후보는 S2로 올리는 게 맞다.
    """
    if _STAGE_RANK.get(obs, 1) >= 2:
        return True, ["S3→S2승격", f"관측단계:{obs}"]
    hp = fnum(rec.get("highest_pct"), default=0.0)
    gn = _v383_gain_now(ev, rec)
    flow5 = _v383_ev_val(ev, "change_5m", "five_min_flow_pct", "price_change_5m", default=0.0)
    flow3 = _v383_ev_val(ev, "money_flow_3m_pct", "three_min_flow_pct", "change_3m", "price_change_3m", default=0.0)
    spread = _v383_ev_val(ev, "spread_pct", "micro_spread_pct", default=0.0)
    # 관찰 후 이미 오른 후보는 S2에서 재확인해야 한다. 스프레드가 매우 넓으면 관찰 유지.
    if hp >= 0.70 and (spread <= 0 or spread <= 0.45):
        return True, ["S3→S2승격:관찰후상승", f"최고+{hp:.2f}%", f"현재+{gn:.2f}%"]
    # 아직 +0.7% 전이라도 5분 흐름이 강하면 S2로 올려 재확인한다.
    if gn >= 0.35 and (flow5 >= 0.50 or flow3 >= 0.25) and (spread <= 0 or spread <= 0.35):
        return True, ["S3→S2승격:흐름재확인", f"현재+{gn:.2f}%", f"5m{flow5:+.2f}", f"3m{flow3:+.2f}"]
    return False, []


def _v383_promote_s2_to_s1(ev: Dict[str, Any], rec: Dict[str, Any], obs: str) -> Tuple[bool, List[str], List[str]]:
    signal_ok, miss = _v379_signal_ready(ev)
    hp = fnum(rec.get("highest_pct"), default=0.0)
    gn = _v383_gain_now(ev, rec)
    pr = _v383_ev_val(ev, "price_reaction_pct", "price_recheck_pct", "change_1m", "price_change_1m", default=0.0)
    buy = _v383_ev_val(ev, "buy_ratio_1m", "micro_buy_ratio_sustain_1m", "buy_ratio", "buy_ratio_30s", default=0.0)
    spread = _v383_ev_val(ev, "spread_pct", "micro_spread_pct", default=0.0)
    # 기존 obs S1은 그대로 존중하되 canonical 안전값이 있어야 실제 S1로 올린다.
    if obs == "S1" and signal_ok:
        return True, ["S2→S1승격", "관측S1+최종판단값확인"], []
    # S2가 이미 관찰 후 충분히 움직이고, 가격반응/체결/스프레드가 통과하면 S1로 올린다.
    strong_follow = (hp >= 0.70 and gn >= 0.10 and pr >= -0.10 and (not buy or buy >= 0.58) and (not spread or spread <= 0.28))
    if signal_ok and strong_follow:
        return True, ["S2→S1승격:재확인통과", f"최고+{hp:.2f}%", f"현재+{gn:.2f}%", f"가격반응{pr:+.2f}", f"매수비율{buy:.2f}"], []
    fail = list(miss or [])
    if not signal_ok:
        return False, [], fail[:8]
    if not strong_follow:
        if hp < 0.70: fail.append("관찰상승부족")
        if gn < 0.10: fail.append("현재반응부족")
        if pr < -0.10: fail.append("가격반응약함")
        if buy and buy < 0.58: fail.append("매수체결약함")
        if spread and spread > 0.28: fail.append("스프레드과다")
    return False, [], fail[:8]


def _v383_finalize_lifecycle(base_result: Dict[str, Any]) -> Dict[str, Any]:
    nowv = now_ts()
    rows = [r for r in read_jsonl(PAPER_LATEST, max_lines=160) if isinstance(r, dict)]
    life = _v379_load_lifecycle()
    items = life.get("items") if isinstance(life.get("items"), dict) else {}
    revised: List[Dict[str, Any]] = []
    transitions = {"new_s3": 0, "s3_to_s2": 0, "s3_to_s2_by_rise": 0, "s2_to_s1": 0, "s2_hold": 0, "s3_hold": 0, "demoted_or_reset": 0, "blocked_s1_signal": 0}
    fail_reasons: Dict[str, int] = {}
    stage_counts = {"S1": 0, "S2": 0, "S3": 0}
    for ev in rows:
        key = _v379_life_key(ev)
        obs = _v379_stage_norm(ev.get("s_stage") or ev.get("candidate_grade") or ev.get("grade"))
        price = _v379_price(ev)
        rec = items.get(key) if isinstance(items.get(key), dict) else {}
        if not rec:
            rec = {"ticker": key, "first_seen_ts": nowv, "first_seen_text": now_text(nowv), "first_seen_price": price, "stage": "S3", "recheck_count": 0, "highest_price": price, "highest_pct": 0.0, "strategy_keys": []}
            new_stage = "S3"
            reasons = ["S3관찰포착", f"관측단계:{obs}"]
            transitions["new_s3"] += 1
        else:
            old_stage = _v379_stage_norm(rec.get("stage"))
            first_price = fnum(rec.get("first_seen_price"), default=price)
            high = max(fnum(rec.get("highest_price"), default=0.0), price)
            rec["highest_price"] = high
            rec["highest_pct"] = round(((high - first_price) / first_price * 100.0), 3) if first_price else 0.0
            if old_stage == "S3":
                promote, preasons = _v383_promote_s3_to_s2(ev, rec, obs)
                if promote:
                    new_stage = "S2"
                    transitions["s3_to_s2"] += 1
                    if any("관찰후상승" in str(x) for x in preasons):
                        transitions["s3_to_s2_by_rise"] += 1
                    reasons = preasons
                else:
                    new_stage = "S3"
                    transitions["s3_hold"] += 1
                    reasons = ["S3관찰유지", f"관측단계:{obs}"]
            elif old_stage == "S2":
                ok, preasons, fail = _v383_promote_s2_to_s1(ev, rec, obs)
                if ok:
                    new_stage = "S1"
                    transitions["s2_to_s1"] += 1
                    reasons = preasons
                else:
                    new_stage = "S2"
                    transitions["s2_hold"] += 1
                    transitions["blocked_s1_signal"] += 1
                    reasons = ["S2→S1보류"] + (fail or [f"관측단계:{obs}"])
                    for r in (fail or ["미상"]):
                        fail_reasons[str(r)] = fail_reasons.get(str(r), 0) + 1
            else:
                if obs == "S1":
                    new_stage = "S1"; reasons = ["S1진입유지"]
                elif obs == "S2":
                    new_stage = "S2"; transitions["demoted_or_reset"] += 1; reasons = ["S1→S2강등"]
                else:
                    new_stage = "S3"; transitions["demoted_or_reset"] += 1; reasons = ["S1→S3강등"]
        rec["stage"] = new_stage
        rec["last_observed_stage"] = obs
        rec["last_seen_ts"] = nowv
        rec["last_seen_text"] = now_text(nowv)
        rec["last_price"] = price
        if not fnum(rec.get("first_seen_price"), default=0.0) and price:
            rec["first_seen_price"] = price
        first_price = fnum(rec.get("first_seen_price"), default=price)
        rec["highest_price"] = max(fnum(rec.get("highest_price"), default=0.0), price)
        rec["highest_pct"] = round(((fnum(rec.get("highest_price"), default=0.0) - first_price) / first_price * 100.0), 3) if first_price else 0.0
        rec["last_gain_pct"] = _v383_gain_now(ev, rec)
        rec["last_promote_reasons"] = reasons[:8]
        rec["s2_to_s1_fail_reasons"] = reasons[1:8] if new_stage == "S2" and reasons and str(reasons[0]).startswith("S2") else []
        rec["recheck_count"] = int(fnum(rec.get("recheck_count"), default=0)) + (1 if new_stage == "S2" else 0)
        sk = str(ev.get("strategy_key") or ev.get("strategy_bucket_primary") or "")
        if sk:
            keys = list(rec.get("strategy_keys") if isinstance(rec.get("strategy_keys"), list) else [])
            if sk not in keys:
                keys.append(sk)
            rec["strategy_keys"] = keys[:8]
        items[key] = rec
        stage_counts[new_stage] += 1
        revised.append(_v379_apply_lifecycle_to_event(ev, rec, new_stage, reasons, nowv))
    latest, appended = persist_paper_handoff(revised, evaluated=int((load_json(SUMMARY, {}) or {}).get("evaluated") or 0))
    stats = {"schema": "s123_lifecycle_v383", "stage_counts": stage_counts, "transitions": transitions, "s2_to_s1_fail_reasons": fail_reasons, "active_count": len(items), "latest_count": len(latest), "archive_appended": appended}
    _v379_save_lifecycle({"items": items}, stats)
    try:
        sm = load_json(SUMMARY, {}) or {}
        sm.update({"version": VERSION, "lifecycle_schema": "s123_lifecycle_v383", "lifecycle_stats": stats, "s_stage_counts": stage_counts, "paper_latest_count": len(latest), "s_count": len(latest), "note": "v0.26/v383: S3 상승후보를 S2 재확인으로 올리고, S2 최종판단값 통과 시 S1로 승격한다."})
        save_json(SUMMARY, sm)
    except Exception as exc:
        append_error(ERROR, "v383_summary_update", exc)
    try:
        pr = load_json(PRIORITY_REQ, {}) or {}
        if isinstance(pr, dict):
            pr["version"] = VERSION
            pr["lifecycle_schema"] = "s123_lifecycle_v383"
            pr["lifecycle_stats"] = stats
            pr["note"] = "v383: S3/S2 승격 실패 원인을 target_router·상태판에 전달한다."
            save_json(PRIORITY_REQ, pr)
    except Exception as exc:
        append_error(ERROR, "v383_priority_update", exc)
    try:
        write_status("running", evaluated=int((load_json(SUMMARY, {}) or {}).get("evaluated") or 0), s_count=len(latest), paper_latest_count=len(latest), s1_count=stage_counts.get("S1", 0), s2_count=stage_counts.get("S2", 0), s3_count=stage_counts.get("S3", 0), lifecycle_schema="s123_lifecycle_v383", lifecycle_active=len(items), lifecycle_transitions=transitions, s2_to_s1_fail_reasons=fail_reasons, last_sec=fnum((base_result or {}).get("last_sec"), default=0.0))
    except Exception:
        pass
    out = dict(base_result or {})
    out.update({"s_stage_counts": stage_counts, "lifecycle_stats": stats, "paper_latest": len(latest), "s": len(latest)})
    return out


def run_once() -> Dict[str, Any]:  # type: ignore[override]
    base = _v383_base_run_once()
    return _v383_finalize_lifecycle(base)


# v385: early main disabled. Final __main__ is at file end after all lifecycle tails load.
# if __name__=="__main__": main()


# =============================================================================
# v384 / 2026-05-23
# - S2/S3가 못 올라간 이유를 단계별로 남긴다.
# - 정보부족은 "정보부족"으로만 끝내지 않고, 왜 없는지(root cause)를 나눈다.
# - 전략 조건/청산/자동매수는 변경하지 않고 생애주기 진단과 승격 실패 원인만 정밀화한다.
# =============================================================================
VERSION = "strategy_worker_v0.27"

def _v384_ev_sources(ev: Dict[str, Any]) -> List[Dict[str, Any]]:
    srcs: List[Dict[str, Any]] = []
    for obj in (ev, ev.get("entry_context"), ev.get("entry_snapshot")):
        if isinstance(obj, dict):
            srcs.append(obj)
            for k in ("flat", "strategy", "orderflow", "feature"):
                v = obj.get(k)
                if isinstance(v, dict):
                    srcs.append(v)
    return srcs

def _v384_known(ev: Dict[str, Any], *keys: str) -> bool:
    for src in _v384_ev_sources(ev):
        for k in keys:
            v = src.get(k)
            if v is not None and str(v).strip() not in {"", "-", "None", "nan", "NaN"}:
                return True
    return False

def _v384_bool(ev: Dict[str, Any], *keys: str) -> bool:
    for src in _v384_ev_sources(ev):
        for k in keys:
            v = src.get(k)
            if isinstance(v, bool):
                return v
            if str(v).strip().lower() in {"1", "true", "yes", "ok", "fresh", "신선"}:
                return True
    return False

def _v384_val(ev: Dict[str, Any], *keys: str, default: float = 0.0) -> float:
    vals: List[Any] = []
    for src in _v384_ev_sources(ev):
        vals.extend(src.get(k) for k in keys)
    return fnum(*vals, default=default)

def _v384_info_root_causes(ev: Dict[str, Any]) -> List[str]:
    """S1/S2/S3 판단값이 없을 때 원천 원인을 분리한다.
    - 수집 미신선: WS/micro/candle 자체가 안 들어옴
    - 판단값 미생성: 수집은 신선한데 feature/orderflow canonical key가 안 붙음
    """
    quote_fresh = _v384_bool(ev, "quote_fresh", "ws_fresh", "rest_fresh")
    micro_fresh = _v384_bool(ev, "micro_fresh")
    candle_ready = _v384_bool(ev, "candle_ready", "candle_ok") or _v384_known(ev, "change_3m", "change_5m")
    causes: List[str] = []
    if not _v384_known(ev, "price_reaction_score", "price_reaction_pct", "price_recheck_pct", "change_1m", "price_change_1m"):
        causes.append("가격반응:시세미신선" if not quote_fresh else "가격반응:판단값미생성")
    if not _v384_known(ev, "money_flow_3m_pct", "three_min_flow_pct", "change_3m", "price_change_3m"):
        causes.append("3분흐름:candle미신선" if not candle_ready else "3분흐름:판단값미생성")
    if not _v384_known(ev, "buy_ratio_1m", "micro_buy_ratio_sustain_1m", "buy_ratio", "buy_ratio_30s"):
        causes.append("체결지속:micro미신선" if not micro_fresh else "체결지속:판단값미생성")
    if not _v384_known(ev, "slippage_est_pct", "tick_pct_est", "spread_pct", "micro_spread_pct"):
        causes.append("슬리피지:micro미신선" if not micro_fresh else "슬리피지:판단값미생성")
    if not _v384_known(ev, "ask_wall_ratio", "sell_wall_ratio", "ask_size_ratio"):
        causes.append("매도벽:micro미신선" if not micro_fresh else "매도벽:판단값미생성")
    return list(dict.fromkeys(causes))[:10]

def _v384_s3_fail_reasons(ev: Dict[str, Any], rec: Dict[str, Any], obs: str) -> List[str]:
    hp = fnum(rec.get("highest_pct"), default=0.0)
    gn = _v383_gain_now(ev, rec)
    flow5 = _v384_val(ev, "change_5m", "five_min_flow_pct", "price_change_5m", default=0.0)
    flow3 = _v384_val(ev, "money_flow_3m_pct", "three_min_flow_pct", "change_3m", "price_change_3m", default=0.0)
    spread = _v384_val(ev, "spread_pct", "micro_spread_pct", default=0.0)
    reasons: List[str] = []
    info = _v384_info_root_causes(ev)
    if info:
        reasons += ["정보부족:" + x for x in info[:5]]
    if hp < 0.70 and gn < 0.35:
        reasons.append(f"상승반응부족:최고{hp:+.2f}/현재{gn:+.2f}")
    if flow5 < 0.50 and flow3 < 0.25:
        reasons.append(f"흐름재확인부족:5m{flow5:+.2f}/3m{flow3:+.2f}")
    if spread and spread > 0.45:
        reasons.append(f"스프레드과다:{spread:.2f}%")
    if not reasons:
        reasons.append(f"관측단계유지:{obs or 'S3'}")
    return reasons[:8]

def _v384_promote_s3_to_s2(ev: Dict[str, Any], rec: Dict[str, Any], obs: str) -> Tuple[bool, List[str], List[str]]:
    promote, reasons = _v383_promote_s3_to_s2(ev, rec, obs)
    if promote:
        return True, reasons, []
    return False, [], _v384_s3_fail_reasons(ev, rec, obs)

def _v384_s2_fail_detail(ev: Dict[str, Any], rec: Dict[str, Any], fail: List[str]) -> Dict[str, Any]:
    return {
        "ticker": _v379_life_key(ev),
        "score": _v384_val(ev, "score", "trade_ready", default=0.0),
        "highest_pct": round(fnum(rec.get("highest_pct"), default=0.0), 3),
        "gain_now_pct": _v383_gain_now(ev, rec),
        "price_reaction_pct": _v384_val(ev, "price_reaction_pct", "price_recheck_pct", "change_1m", default=0.0),
        "buy_ratio": _v384_val(ev, "buy_ratio_1m", "micro_buy_ratio_sustain_1m", "buy_ratio", default=0.0),
        "spread_pct": _v384_val(ev, "spread_pct", "micro_spread_pct", default=0.0),
        "fail_reasons": list(fail or [])[:8],
        "info_root_causes": _v384_info_root_causes(ev),
    }

def _v384_finalize_lifecycle(base_result: Dict[str, Any]) -> Dict[str, Any]:
    nowv = now_ts()
    rows = [r for r in read_jsonl(PAPER_LATEST, max_lines=160) if isinstance(r, dict)]
    life = _v379_load_lifecycle()
    items = life.get("items") if isinstance(life.get("items"), dict) else {}
    revised: List[Dict[str, Any]] = []
    transitions = {"new_s3": 0, "s3_to_s2": 0, "s3_to_s2_by_rise": 0, "s2_to_s1": 0, "s2_hold": 0, "s3_hold": 0, "demoted_or_reset": 0, "blocked_s1_signal": 0}
    fail_reasons: Dict[str, int] = {}
    s3_fail_reasons: Dict[str, int] = {}
    info_root_causes: Dict[str, int] = {}
    s2_fail_samples: List[Dict[str, Any]] = []
    s3_fail_samples: List[Dict[str, Any]] = []
    stage_counts = {"S1": 0, "S2": 0, "S3": 0}
    for ev in rows:
        key = _v379_life_key(ev)
        obs = _v379_stage_norm(ev.get("s_stage") or ev.get("candidate_grade") or ev.get("grade"))
        price = _v379_price(ev)
        rec = items.get(key) if isinstance(items.get(key), dict) else {}
        if not rec:
            rec = {"ticker": key, "first_seen_ts": nowv, "first_seen_text": now_text(nowv), "first_seen_price": price, "stage": "S3", "recheck_count": 0, "highest_price": price, "highest_pct": 0.0, "strategy_keys": []}
            new_stage = "S3"
            reasons = ["S3관찰포착", f"관측단계:{obs}"]
            transitions["new_s3"] += 1
        else:
            old_stage = _v379_stage_norm(rec.get("stage"))
            first_price = fnum(rec.get("first_seen_price"), default=price)
            high = max(fnum(rec.get("highest_price"), default=0.0), price)
            rec["highest_price"] = high
            rec["highest_pct"] = round(((high - first_price) / first_price * 100.0), 3) if first_price else 0.0
            if old_stage == "S3":
                promote, preasons, fail = _v384_promote_s3_to_s2(ev, rec, obs)
                if promote:
                    new_stage = "S2"
                    transitions["s3_to_s2"] += 1
                    if any("관찰후상승" in str(x) for x in preasons):
                        transitions["s3_to_s2_by_rise"] += 1
                    reasons = preasons
                else:
                    new_stage = "S3"
                    transitions["s3_hold"] += 1
                    reasons = ["S3관찰유지", f"관측단계:{obs}"] + fail[:6]
                    for r in fail or ["미상"]:
                        s3_fail_reasons[str(r)] = s3_fail_reasons.get(str(r), 0) + 1
                        if str(r).startswith("정보부족:"):
                            k = str(r).replace("정보부족:", "", 1)
                            info_root_causes[k] = info_root_causes.get(k, 0) + 1
                    if len(s3_fail_samples) < 8:
                        s3_fail_samples.append(_v384_s2_fail_detail(ev, rec, fail))
            elif old_stage == "S2":
                ok, preasons, fail = _v383_promote_s2_to_s1(ev, rec, obs)
                if ok:
                    new_stage = "S1"
                    transitions["s2_to_s1"] += 1
                    reasons = preasons
                else:
                    new_stage = "S2"
                    transitions["s2_hold"] += 1
                    transitions["blocked_s1_signal"] += 1
                    root = _v384_info_root_causes(ev)
                    reasons = ["S2→S1보류"] + (fail or [f"관측단계:{obs}"]) + (["정보원인:" + x for x in root[:4]] if root else [])
                    for r in (fail or ["미상"]):
                        fail_reasons[str(r)] = fail_reasons.get(str(r), 0) + 1
                    for r in root:
                        info_root_causes[str(r)] = info_root_causes.get(str(r), 0) + 1
                    if len(s2_fail_samples) < 8:
                        s2_fail_samples.append(_v384_s2_fail_detail(ev, rec, fail))
            else:
                if obs == "S1":
                    new_stage = "S1"; reasons = ["S1진입유지"]
                elif obs == "S2":
                    new_stage = "S2"; transitions["demoted_or_reset"] += 1; reasons = ["S1→S2강등"]
                else:
                    new_stage = "S3"; transitions["demoted_or_reset"] += 1; reasons = ["S1→S3강등"]
        rec["stage"] = new_stage
        rec["last_observed_stage"] = obs
        rec["last_seen_ts"] = nowv
        rec["last_seen_text"] = now_text(nowv)
        rec["last_price"] = price
        if not fnum(rec.get("first_seen_price"), default=0.0) and price:
            rec["first_seen_price"] = price
        first_price = fnum(rec.get("first_seen_price"), default=price)
        rec["highest_price"] = max(fnum(rec.get("highest_price"), default=0.0), price)
        rec["highest_pct"] = round(((fnum(rec.get("highest_price"), default=0.0) - first_price) / first_price * 100.0), 3) if first_price else 0.0
        rec["last_gain_pct"] = _v383_gain_now(ev, rec)
        rec["last_promote_reasons"] = reasons[:10]
        rec["last_info_root_causes"] = _v384_info_root_causes(ev)
        if new_stage == "S3" and reasons and str(reasons[0]).startswith("S3"):
            rec["s3_to_s2_fail_reasons"] = reasons[2:10]
        if new_stage == "S2" and reasons and str(reasons[0]).startswith("S2"):
            rec["s2_to_s1_fail_reasons"] = reasons[1:10]
        rec["recheck_count"] = int(fnum(rec.get("recheck_count"), default=0)) + (1 if new_stage == "S2" else 0)
        sk = str(ev.get("strategy_key") or ev.get("strategy_bucket_primary") or "")
        if sk:
            keys = list(rec.get("strategy_keys") if isinstance(rec.get("strategy_keys"), list) else [])
            if sk not in keys:
                keys.append(sk)
            rec["strategy_keys"] = keys[:8]
        items[key] = rec
        stage_counts[new_stage] += 1
        revised.append(_v379_apply_lifecycle_to_event(ev, rec, new_stage, reasons, nowv))
    latest, appended = persist_paper_handoff(revised, evaluated=int((load_json(SUMMARY, {}) or {}).get("evaluated") or 0))
    stats = {
        "schema": "s123_lifecycle_v384",
        "stage_counts": stage_counts,
        "transitions": transitions,
        "s2_to_s1_fail_reasons": fail_reasons,
        "s3_to_s2_fail_reasons": s3_fail_reasons,
        "info_missing_root_causes": info_root_causes,
        "s2_to_s1_fail_samples": s2_fail_samples,
        "s3_to_s2_fail_samples": s3_fail_samples,
        "active_count": len(items),
        "latest_count": len(latest),
        "archive_appended": appended,
        "note": "v384: S2/S3가 못 올라간 이유와 정보부족 원천 원인을 단계별로 남긴다.",
    }
    _v379_save_lifecycle({"items": items}, stats)
    try:
        sm = load_json(SUMMARY, {}) or {}
        sm.update({"version": VERSION, "lifecycle_schema": "s123_lifecycle_v384", "lifecycle_stats": stats, "s_stage_counts": stage_counts, "paper_latest_count": len(latest), "s_count": len(latest), "note": "v0.27/v384: S3→S2, S2→S1 미승격 이유와 정보부족 root cause를 분리한다."})
        save_json(SUMMARY, sm)
    except Exception as exc:
        append_error(ERROR, "v384_summary_update", exc)
    try:
        write_status("running", evaluated=int((load_json(SUMMARY, {}) or {}).get("evaluated") or 0), s_count=len(latest), paper_latest_count=len(latest), s1_count=stage_counts.get("S1", 0), s2_count=stage_counts.get("S2", 0), s3_count=stage_counts.get("S3", 0), lifecycle_schema="s123_lifecycle_v384", lifecycle_active=len(items), lifecycle_transitions=transitions, s2_to_s1_fail_reasons=fail_reasons, s3_to_s2_fail_reasons=s3_fail_reasons, info_missing_root_causes=info_root_causes, last_sec=fnum((base_result or {}).get("last_sec"), default=0.0))
    except Exception:
        pass
    out = dict(base_result or {})
    out.update({"s_stage_counts": stage_counts, "lifecycle_stats": stats, "paper_latest": len(latest), "s": len(latest)})
    return out

def run_once() -> Dict[str, Any]:  # type: ignore[override]
    base = _v383_base_run_once()
    return _v384_finalize_lifecycle(base)


# =============================================================================
# strategy_worker v0.28 / v385: final main order fix
# - v384 code existed after an earlier if __main__: main(), so runtime started before v384 loaded.
# - Do not add another strategy condition. Ensure final loaded run_once(v384) is the one executed.
# - Paper/open problems must be diagnosed after this runtime-order fix.
# =============================================================================
VERSION = "strategy_worker_v0.28"
_v385_base_run_once = run_once

def run_once() -> Dict[str, Any]:  # type: ignore[override]
    return _v385_base_run_once()



# =============================================================================
# strategy_worker v0.29 / v386: S1 lifecycle -> paper handoff single factory seal
# - Root cause: lifecycle summary could report S1, but paper handoff merge could still expose
#   the older S2/S3 row, so paper saw S1 handoff 입구 0.
# - This is not a condition change. It seals the factory output: a lifecycle S1 row must carry
#   paper_bot_open/open_eligible/trade_ready/open_source and remain S1 in latest handoff.
# =============================================================================
VERSION = "strategy_worker_v0.29"
_v386_base_run_once = run_once

def _v386_stage_of(row: Dict[str, Any]) -> str:
    srcs: List[Dict[str, Any]] = []
    if isinstance(row, dict):
        srcs.append(row)
        for k in ("entry_context", "entry_snapshot"):
            v = row.get(k)
            if isinstance(v, dict):
                srcs.append(v)
                for kk in ("flat", "strategy", "orderflow", "feature"):
                    vv = v.get(kk)
                    if isinstance(vv, dict):
                        srcs.append(vv)
    for src in srcs:
        g = str(src.get("lifecycle_stage") or src.get("s_stage") or src.get("candidate_stage") or src.get("candidate_grade") or src.get("grade") or "").upper().strip()
        if g == "S":
            return "S1"
        if g in {"S1", "S2", "S3"}:
            return g
    return "S3"

def _v386_force_stage_fields(row: Dict[str, Any], stage: str) -> Dict[str, Any]:
    out = dict(row or {})
    stage = stage if stage in {"S1", "S2", "S3"} else "S3"
    out.update({
        "s_stage": stage,
        "candidate_grade": stage,
        "grade": stage,
        "entry_grade": stage,
        "signal_grade": stage,
        "lifecycle_stage": stage,
        "candidate_grade_label": _STAGE_LABEL.get(stage, stage) if '_STAGE_LABEL' in globals() else stage,
        "paper_bot_open": stage == "S1",
        "open_eligible": stage == "S1",
        "trade_ready": stage == "S1",
        "recheck_required": stage == "S2",
        "observe_only": stage == "S3",
    })
    if stage == "S1":
        out["open_source"] = "s1_lifecycle"
        out["paper_handoff_ready"] = True
        out["final_entry_action"] = "paper_open"
    ctx = out.get("entry_context") if isinstance(out.get("entry_context"), dict) else {}
    ctx.update({
        "s_stage": stage,
        "candidate_grade": stage,
        "grade": stage,
        "lifecycle_stage": stage,
        "paper_bot_open": stage == "S1",
        "open_eligible": stage == "S1",
        "trade_ready": stage == "S1",
    })
    if stage == "S1":
        ctx["open_source"] = "s1_lifecycle"
        ctx["paper_handoff_ready"] = True
    out["entry_context"] = ctx
    snap = out.get("entry_snapshot") if isinstance(out.get("entry_snapshot"), dict) else None
    if isinstance(snap, dict):
        flat = snap.get("flat") if isinstance(snap.get("flat"), dict) else {}
        flat.update({"s_stage": stage, "candidate_grade": stage, "grade": stage, "lifecycle_stage": stage})
        snap["flat"] = flat
        strat = snap.get("strategy") if isinstance(snap.get("strategy"), dict) else {}
        strat.update({"decision_stage": stage, "lifecycle_stage": stage, "paper_bot_open": stage == "S1"})
        snap["strategy"] = strat
        out["entry_snapshot"] = snap
    return out

def _v386_rewrite_latest_stage_priority() -> Dict[str, Any]:
    rows = [r for r in read_jsonl(PAPER_LATEST, max_lines=240) if isinstance(r, dict)]
    fixed: List[Dict[str, Any]] = []
    counts = {"S1": 0, "S2": 0, "S3": 0}
    for r in rows:
        st = _v386_stage_of(r)
        counts[st] = counts.get(st, 0) + 1
        fixed.append(_v386_force_stage_fields(r, st))
    # keep S1 first so paper's merge/picker cannot lose it behind an older S3 row
    fixed.sort(key=lambda x: ({"S1": 3, "S2": 2, "S3": 1}.get(_v386_stage_of(x), 0), fnum(x.get("updated_ts"), x.get("created_at"), default=0.0), fnum(x.get("score"), default=0.0)), reverse=True)
    if fixed:
        write_jsonl_atomic(PAPER_LATEST, fixed[:40])
    try:
        h = load_json(HANDOFF, {}) or {}
        h.update({
            "version": VERSION,
            "v386_factory_sealed": True,
            "v386_latest_stage_counts": counts,
            "s1_count": counts.get("S1", 0),
            "s2_count": counts.get("S2", 0),
            "s3_count": counts.get("S3", 0),
            "note": "v386: lifecycle S1 rows are forced into paper handoff with open_eligible/trade_ready before paper reads them.",
        })
        save_json(HANDOFF, h)
    except Exception as exc:
        append_error(ERROR, "v386_handoff_status", exc)
    return counts

def run_once() -> Dict[str, Any]:  # type: ignore[override]
    out = _v386_base_run_once()
    try:
        counts = _v386_rewrite_latest_stage_priority()
        try:
            write_status("running", evaluated=int((load_json(SUMMARY, {}) or {}).get("evaluated") or 0), s_count=sum(counts.values()), paper_latest_count=sum(counts.values()), s1_count=counts.get("S1",0), s2_count=counts.get("S2",0), s3_count=counts.get("S3",0), lifecycle_schema="s123_lifecycle_v386_factory_sealed", v386_factory_sealed=True, last_sec=fnum((out or {}).get("last_sec"), default=0.0))
        except Exception:
            pass
        if isinstance(out, dict):
            out["s_stage_counts"] = counts
            out["v386_factory_sealed"] = True
    except Exception as exc:
        append_error(ERROR, "v386_factory_seal", exc)
    return out


# =============================================================================
# strategy_worker v0.30 / v403: 전략별 S3/S2/S1 단일 본선 + 조건지도
# - 기존 독립 lifecycle S3→S2→S1 가격추적 승격판을 최종 OPEN 경로에서 격리한다.
# - 각 전략의 core/S2/S1 조건과 공통 안전문을 한 번에 적용한다.
# - S2/S3는 계속 관찰/재확인으로 남기지만, paper OPEN은 전략별 S1 + 공통 S1 안전문만 허용한다.
# =============================================================================
VERSION = "strategy_worker_v0.30"

V403_CONDITION_MAP = {
    "version": VERSION,
    "main_version": MAIN_VERSION if 'MAIN_VERSION' in globals() else MAIN_DEPLOY_VERSION,
    "schema": "strategy_stage_unified_v403",
    "summary": "전략 조건과 S3/S2/S1 단계를 하나로 합침. 독립 lifecycle 가격추적 S2→S1 승격은 최종 OPEN 경로에서 격리.",
    "common_hard_blocks": [
        "최근 반복손실/하드손실", "이미 OPEN 중", "거래대금 2.5억 미만", "윗꼬리/고점끝물 위험",
        "micro fresh 시 스프레드 과다", "micro fresh 시 매수체결 부족", "매도벽/매도체결압력"
    ],
    "common_s1_safety": [
        "micro fresh + WS/quote fresh", "매수체결비 >= 0.70", "1분 체결지속 >= 0.64",
        "스프레드 <= 0.18%", "슬리피지 확인 <= 0.20%", "매도벽 확인 + 매도압력 없음",
        "가격반응 >= 0.05", "30초/1분/3분 중 단기반응", "VWAP >= -0.03", "EMA5 >= -0.05",
        "최근반복손실/고점무반응/과열 제외"
    ],
    "common_s2_recheck": [
        "micro fresh", "매수체결비 >= 0.62", "스프레드 <= 0.28%", "매도압력 없음",
        "VWAP >= -0.08", "EMA5 >= -0.12", "가격반응/단기흐름/거래량 중 재확인 재료"
    ],
    "stage_policy": [
        "S3=전략별 관찰/복기", "S2=전략별 재확인/정보보강", "S1=전략별 S1 추가조건 + 공통 S1 안전문 통과만 paper OPEN",
        "기존 lifecycle S3→S2→S1 가격추적 승격은 최신 handoff에서 재계산/격리"
    ],
    "strategies": {
        "money_reaccel_s": {"label":"돈흐름 재가속", "core":["3m>=0.25", "5m>=0.35", "VWAP>=-0.05", "EMA5>=-0.08", "volume_expanding"], "s1_extra":["3m>=0.35", "5m>=0.45", "volume_expanding", "relative>=0"], "s2_extra":["3m>=0.20 or 5m>=0.35 or volume_expanding"]},
        "leader_momentum_s": {"label":"주도추세 지속", "core":["15m>=0.65", "30m>=0.65", "relative>=0.30", "VWAP/EMA>=0", "market!=약함"], "s1_extra":["15m>=0.75", "30m>=0.75", "relative>=0.40", "market!=약함"], "s2_extra":["15m>=0.60", "relative>=0.25", "VWAP>=-0.05", "price_alive_s2"]},
        "breakout_early_s": {"label":"돌파 초입", "core":["breakout_hint", "recent_high_gap>=-0.15", "끝물추격 제외"], "s1_extra":["breakout_hint", "volume_expanding", "recent_high_gap>=-0.08", "3m>=0.15", "not high_end"], "s2_extra":["breakout_hint", "recent_high_gap>=-0.25", "volume or 3m>=0.15"]},
        "sweep_vwap_recovery_s": {"label":"저점 VWAP 회복", "core":["sweep_reclaim_hint", "VWAP>=-0.05", "low_rebound>=0.40"], "s1_extra":["sweep", "low_rebound>=0.55", "3m>=0.08", "day_pos<88"], "s2_extra":["sweep", "VWAP>=-0.08", "low_rebound>=0.35", "price_alive_s2"]},
        "surge_rebreak_s": {"label":"급등 후 재돌파", "core":["15m>=1.20", "3m>=0.15", "recent_high_gap>=-0.25", "no long_upper_wick"], "s1_extra":["15m>=1.20", "3m>=0.25", "recent_high_gap>=-0.15", "not overheat"], "s2_extra":["15m>=1.00", "recent_high_gap>=-0.30", "price_alive_s2"]},
        "leader_flow_adaptive_hold_s": {"label":"주도흐름 유동보유", "core":["3m/5m or 15m/30m trend", "VWAP>=-0.10", "EMA5>=-0.15", "turnover>=3억", "min buy/spread"], "s1_extra":["15m>=0.70", "30m>=0.40", "relative>=0", "VWAP>=-0.03", "EMA5>=-0.05", "3m>=0.20 or 5m>=0.45 or volume", "not high_end"], "s2_extra":["15m>=0.55 or 5m>=0.55", "VWAP>=-0.08", "EMA5>=-0.12"]}
    }
}

CONDITION_MAP_FILE = BASE_DIR / "clean_strategy_condition_map.json"


def _v403_event_sources(ev: Dict[str, Any]) -> List[Dict[str, Any]]:
    srcs: List[Dict[str, Any]] = []
    if isinstance(ev, dict):
        srcs.append(ev)
        for k in ("entry_context", "entry_snapshot", "profile"):
            v = ev.get(k)
            if isinstance(v, dict):
                srcs.append(v)
                for kk in ("flat", "strategy", "orderflow", "feature", "price_flow", "position", "money_flow", "risk"):
                    vv = v.get(kk)
                    if isinstance(vv, dict):
                        srcs.append(vv)
    return srcs


def _v403_merge_from_event(ev: Dict[str, Any], current_row: Dict[str, Any], current_of: Dict[str, Any]) -> Tuple[Dict[str, Any], Dict[str, Any]]:
    row = dict(current_row or {})
    of = dict(current_of or {})
    for src in _v403_event_sources(ev):
        for k, v in src.items():
            if k in {"buy_ratio", "buy_ratio_30s", "buy_ratio_1m", "micro_buy_ratio_sustain_1m", "spread_pct", "micro_spread_pct", "slippage_est_pct", "expected_slippage_pct", "ask_wall_ratio", "bid_wall_ratio", "sell_pressure", "ask_wall_pressure", "sell_trade_pressure", "micro_fresh", "ws_fresh", "quote_fresh"}:
                of.setdefault(k, v)
            else:
                row.setdefault(k, v)
    t = ticker_norm(ev.get("ticker") or row.get("ticker") or row.get("market") or row.get("symbol"))
    if t:
        row.setdefault("ticker", t)
    return row, of


def _v403_stage_policy(ev: Dict[str, Any], feature_map: Dict[str, Dict[str, Any]], ofmap: Dict[str, Dict[str, Any]]) -> Tuple[str, List[str], Dict[str, Any], Dict[str, Any]]:
    t = ticker_norm(ev.get("ticker") or ev.get("market") or ev.get("symbol"))
    row, of = _v403_merge_from_event(ev, feature_map.get(t, {}) if t else {}, ofmap.get(t, {}) if t else {})
    skey = str(ev.get("strategy_key") or ev.get("strategy_bucket_primary") or row.get("strategy_key") or "strategy_s")
    stage, why = _v015_stage_decision(row, of, skey)
    why = ["전략별단계판정"] + [str(x) for x in why[:8]]
    return stage, why, row, of


def _v403_force_policy_fields(row: Dict[str, Any], stage: str, reasons: List[str]) -> Dict[str, Any]:
    out = _v386_force_stage_fields(row, stage) if '_v386_force_stage_fields' in globals() else dict(row or {})
    stage = stage if stage in {"S1", "S2", "S3"} else "S3"
    out["s_stage"] = stage
    out["candidate_grade"] = stage
    out["grade"] = stage
    out["entry_grade"] = stage
    out["signal_grade"] = stage
    out["lifecycle_stage"] = stage
    out["stage_policy_schema"] = "strategy_stage_unified_v403"
    out["stage_policy_note"] = "전략별 조건 안에서 S3/S2/S1 결정; 독립 lifecycle 승격 격리"
    out["s_stage_reasons"] = reasons[:10]
    out["stage_transition"] = f"strategy_direct->{stage}"
    out["paper_bot_open"] = stage == "S1"
    out["open_eligible"] = stage == "S1"
    out["trade_ready"] = stage == "S1"
    out["recheck_required"] = stage == "S2"
    out["observe_only"] = stage == "S3"
    if stage == "S1":
        out["open_source"] = "strategy_stage_unified_v403"
        out["paper_handoff_ready"] = True
        out["final_entry_action"] = "paper_open"
    else:
        out.pop("open_source", None)
        out["paper_handoff_ready"] = False
        out["final_entry_action"] = "recheck" if stage == "S2" else "observe"
    ctx = out.get("entry_context") if isinstance(out.get("entry_context"), dict) else {}
    ctx.update({"s_stage": stage, "candidate_grade": stage, "stage_policy_schema": "strategy_stage_unified_v403", "paper_bot_open": stage == "S1", "open_eligible": stage == "S1", "trade_ready": stage == "S1", "s_stage_reasons": reasons[:10]})
    out["entry_context"] = ctx
    snap = out.get("entry_snapshot") if isinstance(out.get("entry_snapshot"), dict) else None
    if isinstance(snap, dict):
        flat = snap.get("flat") if isinstance(snap.get("flat"), dict) else {}
        flat.update({"s_stage": stage, "candidate_grade": stage, "stage_policy_schema": "strategy_stage_unified_v403"})
        snap["flat"] = flat
        strat = snap.get("strategy") if isinstance(snap.get("strategy"), dict) else {}
        strat.update({"decision_stage": stage, "lifecycle_stage": stage, "stage_policy_schema": "strategy_stage_unified_v403", "decision_note": "v403 전략별 S3/S2/S1 단일판정", "s_stage_reasons": reasons[:10], "paper_bot_open": stage == "S1"})
        snap["strategy"] = strat
        out["entry_snapshot"] = snap
    return out


def _v403_reseal_strategy_stage() -> Dict[str, Any]:
    feature_obj = load_json(FEATURE, {}) or {}
    feature_map = map_rows(feature_obj)
    ofmap = map_rows(load_json(ORDERFLOW, {}) or {})
    rows = [r for r in read_jsonl(PAPER_LATEST, max_lines=240) if isinstance(r, dict)]
    fixed: List[Dict[str, Any]] = []
    counts = {"S1": 0, "S2": 0, "S3": 0}
    reason_top: Dict[str, int] = {}
    transitions: Dict[str, int] = {}
    for ev in rows:
        before = _v386_stage_of(ev) if '_v386_stage_of' in globals() else str(ev.get('s_stage') or 'S3')
        stage, why, row, of = _v403_stage_policy(ev, feature_map, ofmap)
        after = stage if stage in counts else "S3"
        transitions[f"{before}->{after}"] = transitions.get(f"{before}->{after}", 0) + 1
        counts[after] += 1
        for r in why[:5]:
            reason_top[str(r)] = reason_top.get(str(r), 0) + 1
        fixed.append(_v403_force_policy_fields(ev, after, why))
    fixed.sort(key=lambda x: ({"S1": 3, "S2": 2, "S3": 1}.get(str(x.get('s_stage')), 0), fnum(x.get("updated_ts"), x.get("created_at"), default=0.0), fnum(x.get("score"), default=0.0)), reverse=True)
    write_jsonl_atomic(PAPER_LATEST, fixed[:40])
    stats = {"schema": "strategy_stage_unified_v403", "stage_counts": counts, "transitions": transitions, "reason_top": reason_top, "latest_count": len(fixed[:40]), "policy": "strategy_direct_only"}
    save_json(CONDITION_MAP_FILE, V403_CONDITION_MAP)
    try:
        h = load_json(HANDOFF, {}) or {}
        h.update({"version": VERSION, "stage_policy_schema": "strategy_stage_unified_v403", "v403_stage_counts": counts, "s1_count": counts.get("S1",0), "s2_count": counts.get("S2",0), "s3_count": counts.get("S3",0), "note": "v403: paper handoff S1 is sealed by strategy-specific S1 + common S1 safety only."})
        save_json(HANDOFF, h)
    except Exception as exc:
        append_error(ERROR, "v403_handoff_status", exc)
    try:
        sm = load_json(SUMMARY, {}) or {}
        sm.update({"version": VERSION, "main_version": MAIN_VERSION if 'MAIN_VERSION' in globals() else MAIN_DEPLOY_VERSION, "condition_map": V403_CONDITION_MAP, "stage_policy_schema": "strategy_stage_unified_v403", "lifecycle_schema": "strategy_stage_unified_v403", "lifecycle_stats": stats, "s_stage_counts": counts, "paper_latest_count": len(fixed[:40]), "s_count": len(fixed[:40]), "note": "v403: 전략 조건과 S3/S2/S1 단계를 합치고, 독립 lifecycle 가격추적 S2→S1 승격은 최종 OPEN에서 격리."})
        save_json(SUMMARY, sm)
    except Exception as exc:
        append_error(ERROR, "v403_summary_update", exc)
    try:
        pr = load_json(PRIORITY_REQ, {}) or {}
        if isinstance(pr, dict):
            pr["version"] = VERSION
            pr["stage_policy_schema"] = "strategy_stage_unified_v403"
            pr["condition_map"] = V403_CONDITION_MAP
            save_json(PRIORITY_REQ, pr)
    except Exception as exc:
        append_error(ERROR, "v403_priority_update", exc)
    return stats


def run_once() -> Dict[str, Any]:  # type: ignore[override]
    # v403 final path: pre-lifecycle strategy evaluation -> strategy-specific stage reseal.
    base = _v379_base_run_once()
    stats = _v403_reseal_strategy_stage()
    try:
        c = stats.get("stage_counts", {}) if isinstance(stats, dict) else {}
        write_status("running", evaluated=int((load_json(SUMMARY, {}) or {}).get("evaluated") or 0), s_count=sum(int(v) for v in c.values()), paper_latest_count=int(stats.get("latest_count", 0) if isinstance(stats, dict) else 0), s1_count=c.get("S1",0), s2_count=c.get("S2",0), s3_count=c.get("S3",0), lifecycle_schema="strategy_stage_unified_v403", stage_policy_schema="strategy_stage_unified_v403", condition_map_version=VERSION, last_sec=fnum((base or {}).get("last_sec"), default=0.0))
    except Exception:
        pass
    out = dict(base or {})
    out.update({"s_stage_counts": stats.get("stage_counts", {}) if isinstance(stats, dict) else {}, "lifecycle_stats": stats, "stage_policy_schema": "strategy_stage_unified_v403", "condition_map_version": VERSION})
    return out



# =============================================================================
# strategy_worker v0.31 / v405: S1 후보 탈락 사유 세분화 + 전략별 필요정보 점검
# - 조건 수치를 새로 풀거나 조이지 않는다.
# - v403의 전략별 S3/S2/S1 단일 구조를 유지한다.
# - 후보마다 "왜 S1이 아닌지"를 사람말로 남긴다.
# - 정보부족은 한 단어로 뭉치지 않고 가격/WS/micro/체결/스프레드/슬리피지/매도벽 등으로 나눈다.
# =============================================================================
VERSION = "strategy_worker_v0.31"
S1_BLOCK_AUDIT = BASE_DIR / "clean_strategy_s1_block_audit.json"

V405_STRATEGY_LABELS = {
    "money_reaccel_s": "돈흐름 재가속",
    "leader_momentum_s": "주도추세 지속",
    "breakout_early_s": "돌파 초입",
    "sweep_vwap_recovery_s": "저점 VWAP 회복",
    "surge_rebreak_s": "급등 후 재돌파",
    "leader_flow_adaptive_hold_s": "주도흐름 유동보유",
}

V405_INFO_LABELS = {
    "price": "현재가",
    "quote_fresh": "실시간 시세",
    "ws_fresh": "웹소켓 시세",
    "micro_fresh": "호가·체결",
    "buy_ratio": "매수체결비",
    "buy_sustain_1m": "1분 매수지속",
    "spread": "스프레드",
    "slippage": "예상 미끄러짐",
    "ask_wall": "매도벽",
    "sell_pressure": "매도압력",
    "price_reaction": "가격반응",
    "short_flow": "30초~3분 흐름",
    "mid_flow": "5~30분 흐름",
    "vwap": "VWAP 위치",
    "ema5": "EMA5 위치",
    "relative_strength": "시장대비 힘",
    "volume_expanding": "거래량 확장",
    "recent_high_gap": "고점 거리",
    "low_rebound": "저점 반등",
    "day_position": "당일 위치",
    "breakout_hint": "돌파 신호",
    "sweep_hint": "저점 회복 신호",
    "market_mode": "장세 모드",
}

V405_COMMON_REQUIRED = [
    "price", "quote_fresh", "micro_fresh", "buy_ratio", "buy_sustain_1m", "spread", "slippage",
    "ask_wall", "sell_pressure", "price_reaction", "short_flow", "vwap", "ema5",
]

V405_STRATEGY_REQUIRED = {
    "money_reaccel_s": ["short_flow", "mid_flow", "vwap", "ema5", "volume_expanding", "relative_strength", "buy_ratio", "spread"],
    "leader_momentum_s": ["mid_flow", "relative_strength", "vwap", "ema5", "market_mode", "buy_ratio", "spread"],
    "breakout_early_s": ["breakout_hint", "recent_high_gap", "short_flow", "volume_expanding", "buy_ratio", "spread"],
    "sweep_vwap_recovery_s": ["sweep_hint", "low_rebound", "vwap", "short_flow", "day_position", "buy_ratio", "spread"],
    "surge_rebreak_s": ["mid_flow", "short_flow", "recent_high_gap", "vwap", "ema5", "buy_ratio", "spread"],
    "leader_flow_adaptive_hold_s": ["mid_flow", "short_flow", "relative_strength", "vwap", "ema5", "volume_expanding", "buy_ratio", "spread"],
}

V405_OUTSIDE_REFERENCE_INFO = [
    {"name":"RSI/과매수·과매도", "status":"미사용", "note":"전략 필수값은 아님. 나중에 과열/저점 회복 보조지표로 검토 가능."},
    {"name":"MACD/이동평균 교차", "status":"미사용", "note":"현재는 EMA/VWAP/흐름으로 대체 중. 추세 지속 전략 보조로만 검토."},
    {"name":"볼린저밴드/변동성 밴드", "status":"미사용", "note":"돌파·저점회복의 위치 판단 보조 후보. 지금 바로 조건 추가 금지."},
    {"name":"체결 속도 가속도", "status":"부분", "note":"매수체결비는 있으나 초당 체결속도 변화는 별도 지표가 약함."},
    {"name":"호가잔량 변화율", "status":"부분", "note":"매도벽/스프레드는 있으나 벽이 빠지는 속도는 아직 약함."},
    {"name":"BTC/전체장 선행 방향", "status":"부분", "note":"장세 모드는 있으나 특정 대장 흐름 선행성은 추가 검토 영역."},
]

def _v405_sources(row: Dict[str, Any], of: Dict[str, Any]) -> List[Dict[str, Any]]:
    srcs: List[Dict[str, Any]] = []
    for obj in (row, of, row.get("entry_context"), row.get("entry_snapshot")):
        if isinstance(obj, dict):
            srcs.append(obj)
            for k in ("flat", "strategy", "orderflow", "feature", "price_flow", "position", "money_flow", "risk", "profile"):
                v = obj.get(k)
                if isinstance(v, dict):
                    srcs.append(v)
    return srcs

def _v405_first(row: Dict[str, Any], of: Dict[str, Any], *keys: str) -> Any:
    for src in _v405_sources(row, of):
        for k in keys:
            if k in src:
                v = src.get(k)
                if v is not None and str(v).strip() not in {"", "-", "None", "nan", "NaN"}:
                    return v
    return None

def _v405_known(row: Dict[str, Any], of: Dict[str, Any], *keys: str) -> bool:
    return _v405_first(row, of, *keys) is not None

def _v405_bool_val(v: Any) -> bool:
    if isinstance(v, bool): return v
    return str(v).strip().lower() in {"1", "true", "yes", "ok", "fresh", "신선", "ready"}

def _v405_num(row: Dict[str, Any], of: Dict[str, Any], *keys: str, default: float = 0.0) -> float:
    vals = []
    for src in _v405_sources(row, of):
        vals += [src.get(k) for k in keys]
    return fnum(*vals, default=default)

def _v405_info_ready(row: Dict[str, Any], of: Dict[str, Any]) -> Dict[str, Dict[str, Any]]:
    ch30s = _v405_num(row, of, "change_30s", "price_change_30s", default=0.0)
    ch1 = _v405_num(row, of, "change_1m", "price_change_1m", default=0.0)
    ch3 = _v405_num(row, of, "change_3m", "price_change_3m", "money_flow_3m_pct", "three_min_flow_pct", default=0.0)
    ch5 = _v405_num(row, of, "change_5m", "price_change_5m", "five_min_flow_pct", default=0.0)
    ch15 = _v405_num(row, of, "change_15m", "price_change_15m", default=0.0)
    ch30 = _v405_num(row, of, "change_30m", "price_change_30m", default=0.0)
    def item(key: str, ready: bool, value: Any = None, note: str = "") -> Dict[str, Any]:
        return {"key": key, "label": V405_INFO_LABELS.get(key, key), "ready": bool(ready), "value": value, "note": note}
    price = _v405_first(row, of, "current_price", "entry_price", "price", "detected_price", "close")
    quote_fresh = _v405_bool_val(_v405_first(row, of, "quote_fresh", "ws_fresh"))
    ws_fresh = _v405_bool_val(_v405_first(row, of, "ws_fresh", "quote_fresh"))
    micro_fresh = _v405_bool_val(_v405_first(row, of, "micro_fresh"))
    buy = _v405_num(row, of, "buy_ratio", "buy_ratio_30s", "micro_trade_buy_ratio_30", default=-1.0)
    buy1 = _v405_num(row, of, "buy_ratio_1m", "buy_ratio_60", "micro_buy_ratio_sustain_1m", "buy_ratio_sustain", default=-1.0)
    spread = _v405_num(row, of, "spread_pct", "micro_spread_pct", default=99.0)
    slip = _v405_num(row, of, "slippage_est_pct", "tick_pct_est", "expected_slippage_pct", default=99.0)
    ask = _v405_num(row, of, "ask_wall_ratio", "ask_wall", "micro_ask_wall_ratio", default=-1.0)
    sell_known = _v405_known(row, of, "sell_pressure", "ask_wall_pressure", "sell_trade_pressure")
    sell = _v405_bool_val(_v405_first(row, of, "sell_pressure", "ask_wall_pressure", "sell_trade_pressure"))
    pr = _v405_num(row, of, "price_reaction_score", "price_recheck_pct", "price_reaction_pct", default=-999.0)
    vwap = _v405_num(row, of, "vwap_gap_pct", default=-999.0)
    ema = _v405_num(row, of, "ema5_gap_pct", "ma5_gap_pct", default=-999.0)
    rel = _v405_num(row, of, "relative_strength_pct", "relative_strength", default=-999.0)
    high_gap = _v405_num(row, of, "recent_high_gap_pct", "below_high_pct", default=-999.0)
    low_reb = _v405_num(row, of, "recent_low_rebound_pct", "low_defense_pct", default=-999.0)
    day_pos = _v405_num(row, of, "day_pos_pct", "current_close_pos_ratio", default=-999.0)
    vol = _v405_first(row, of, "volume_expanding")
    breakout = _v405_first(row, of, "breakout_hint")
    sweep = _v405_first(row, of, "sweep_reclaim_hint")
    market = _v405_first(row, of, "market_mode")
    return {
        "price": item("price", price is not None, price),
        "quote_fresh": item("quote_fresh", quote_fresh, quote_fresh),
        "ws_fresh": item("ws_fresh", ws_fresh, ws_fresh),
        "micro_fresh": item("micro_fresh", micro_fresh, micro_fresh),
        "buy_ratio": item("buy_ratio", buy >= 0, buy),
        "buy_sustain_1m": item("buy_sustain_1m", buy1 >= 0, buy1),
        "spread": item("spread", spread < 90, spread),
        "slippage": item("slippage", slip < 90, slip),
        "ask_wall": item("ask_wall", ask >= 0, ask),
        "sell_pressure": item("sell_pressure", sell_known, sell),
        "price_reaction": item("price_reaction", pr > -900, pr),
        "short_flow": item("short_flow", _v405_known(row, of, "change_30s", "price_change_30s", "change_1m", "price_change_1m", "change_3m", "price_change_3m"), {"30s": ch30s, "1m": ch1, "3m": ch3}),
        "mid_flow": item("mid_flow", _v405_known(row, of, "change_5m", "price_change_5m", "change_15m", "price_change_15m", "change_30m", "price_change_30m"), {"5m": ch5, "15m": ch15, "30m": ch30}),
        "vwap": item("vwap", vwap > -900, vwap),
        "ema5": item("ema5", ema > -900, ema),
        "relative_strength": item("relative_strength", rel > -900, rel),
        "volume_expanding": item("volume_expanding", vol is not None, bool(vol) if vol is not None else None),
        "recent_high_gap": item("recent_high_gap", high_gap > -900, high_gap),
        "low_rebound": item("low_rebound", low_reb > -900, low_reb),
        "day_position": item("day_position", day_pos > -900, day_pos),
        "breakout_hint": item("breakout_hint", breakout is not None, bool(breakout) if breakout is not None else None),
        "sweep_hint": item("sweep_hint", sweep is not None, bool(sweep) if sweep is not None else None),
        "market_mode": item("market_mode", market is not None, market),
    }

def _v405_fail_details(row: Dict[str, Any], of: Dict[str, Any], skey: str, stage: str) -> Tuple[List[Dict[str, str]], List[Dict[str, str]], List[Dict[str, Any]]]:
    info = _v405_info_ready(row, of)
    fail: List[Dict[str, str]] = []
    missing: List[Dict[str, str]] = []
    def add(cat: str, key: str, text: str, value: Any = "") -> None:
        fail.append({"category": cat, "key": key, "label": text, "value": str(value)})
    def miss(key: str, why: str = "값 없음") -> None:
        label = V405_INFO_LABELS.get(key, key)
        missing.append({"key": key, "label": label, "why": why})
        add("정보부족", key, f"{label} 없음", why)
    def req_missing(keys: List[str]) -> None:
        for k in keys:
            if not info.get(k, {}).get("ready"):
                miss(k)
    req_missing(V405_COMMON_REQUIRED + V405_STRATEGY_REQUIRED.get(skey, []))
    buy = _v405_num(row, of, "buy_ratio", "buy_ratio_30s", "micro_trade_buy_ratio_30", default=-1.0)
    buy1 = _v405_num(row, of, "buy_ratio_1m", "buy_ratio_60", "micro_buy_ratio_sustain_1m", "buy_ratio_sustain", default=-1.0)
    spread = _v405_num(row, of, "spread_pct", "micro_spread_pct", default=99.0)
    slip = _v405_num(row, of, "slippage_est_pct", "tick_pct_est", "expected_slippage_pct", default=99.0)
    ask = _v405_num(row, of, "ask_wall_ratio", "ask_wall", "micro_ask_wall_ratio", default=-1.0)
    bid = _v405_num(row, of, "bid_wall_ratio", "micro_bid_ask_wall_ratio", default=0.0)
    sell = _v405_bool_val(_v405_first(row, of, "sell_pressure", "ask_wall_pressure", "sell_trade_pressure"))
    pr = _v405_num(row, of, "price_reaction_score", "price_recheck_pct", "price_reaction_pct", default=-999.0)
    ch30s = _v405_num(row, of, "change_30s", "price_change_30s", default=0.0)
    ch1 = _v405_num(row, of, "change_1m", "price_change_1m", default=0.0)
    ch3 = _v405_num(row, of, "change_3m", "price_change_3m", "money_flow_3m_pct", "three_min_flow_pct", default=0.0)
    ch5 = _v405_num(row, of, "change_5m", "price_change_5m", default=0.0)
    ch15 = _v405_num(row, of, "change_15m", "price_change_15m", default=0.0)
    ch30 = _v405_num(row, of, "change_30m", "price_change_30m", default=0.0)
    vwap = _v405_num(row, of, "vwap_gap_pct", default=-999.0)
    ema = _v405_num(row, of, "ema5_gap_pct", "ma5_gap_pct", default=-999.0)
    rel = _v405_num(row, of, "relative_strength_pct", "relative_strength", default=0.0)
    high_gap = _v405_num(row, of, "recent_high_gap_pct", "below_high_pct", default=0.0)
    low_reb = _v405_num(row, of, "recent_low_rebound_pct", "low_defense_pct", default=0.0)
    day = _v405_num(row, of, "day_pos_pct", "current_close_pos_ratio", default=50.0)
    vol = bool(_v405_first(row, of, "volume_expanding"))
    breakout = bool(_v405_first(row, of, "breakout_hint"))
    sweep = bool(_v405_first(row, of, "sweep_reclaim_hint"))
    market = str(_v405_first(row, of, "market_mode") or "")
    quote_fresh = _v405_bool_val(_v405_first(row, of, "quote_fresh", "ws_fresh"))
    micro_fresh = _v405_bool_val(_v405_first(row, of, "micro_fresh"))
    if not quote_fresh: add("공통S1", "quote_fresh", "실시간 시세가 오래됐거나 없음")
    if not micro_fresh: add("공통S1", "micro_fresh", "호가·체결 정보가 오래됐거나 없음")
    if buy >= 0 and buy < 0.70: add("공통S1", "buy_ratio", "매수체결비 부족", f"{buy:.2f} < 0.70")
    if buy1 >= 0 and buy1 < 0.64: add("공통S1", "buy_sustain_1m", "1분 매수지속 부족", f"{buy1:.2f} < 0.64")
    if spread < 90 and spread > 0.18: add("공통S1", "spread", "스프레드 부담", f"{spread:.2f}% > 0.18%")
    if slip < 90 and slip > 0.20: add("공통S1", "slippage", "예상 미끄러짐 부담", f"{slip:.2f}% > 0.20%")
    if sell or (ask >= 0 and ask >= 1.15 and bid < ask): add("공통S1", "sell_pressure", "매도벽/매도압력 부담")
    if pr > -900 and pr < 0.05: add("공통S1", "price_reaction", "가격반응 부족", f"{pr:+.2f} < +0.05")
    if not (ch30s >= 0.02 or ch1 >= 0.08 or ch3 >= 0.25): add("공통S1", "short_flow", "진입 직전 단기반응 부족", f"30s {ch30s:+.2f} / 1m {ch1:+.2f} / 3m {ch3:+.2f}")
    if vwap > -900 and vwap < -0.03: add("공통S1", "vwap", "VWAP 아래라 위치 부담", f"{vwap:+.2f}%")
    if ema > -900 and ema < -0.05: add("공통S1", "ema5", "EMA5 아래라 추세 부담", f"{ema:+.2f}%")
    high_end = day >= 90.0 and high_gap >= -0.20
    overheat = (ch5 >= 6.0 and (ema >= 3.0 or vwap >= 0.80)) or ch15 >= 12.0 or ema >= 8.0
    if high_end and (pr < 0.08): add("공통S1", "high_end", "고점권인데 가격반응 약함")
    if overheat: add("공통S1", "overheat", "급등 과열/이격 부담")
    # strategy-specific S1 reasons
    if skey == "money_reaccel_s":
        if ch3 < 0.35: add("전략S1", "ch3", "돈흐름 3분 부족", f"{ch3:+.2f} < +0.35")
        if ch5 < 0.45: add("전략S1", "ch5", "돈흐름 5분 부족", f"{ch5:+.2f} < +0.45")
        if not vol: add("전략S1", "volume", "거래량 확장 부족")
        if rel < 0: add("전략S1", "relative", "시장대비 힘 부족", f"{rel:+.2f}")
    elif skey == "leader_momentum_s":
        if ch15 < 0.75: add("전략S1", "ch15", "15분 주도흐름 부족", f"{ch15:+.2f} < +0.75")
        if ch30 < 0.75: add("전략S1", "ch30", "30분 주도흐름 부족", f"{ch30:+.2f} < +0.75")
        if rel < 0.40: add("전략S1", "relative", "시장대비 힘 부족", f"{rel:+.2f} < +0.40")
        if market == "약함": add("전략S1", "market", "장이 약한 모드")
    elif skey == "breakout_early_s":
        if not breakout: add("전략S1", "breakout", "돌파 신호 부족")
        if not vol: add("전략S1", "volume", "돌파 거래량 부족")
        if high_gap < -0.08: add("전략S1", "high_gap", "돌파선과 거리 부족", f"{high_gap:+.2f} < -0.08")
        if ch3 < 0.15: add("전략S1", "ch3", "돌파 후 3분 흐름 부족", f"{ch3:+.2f} < +0.15")
    elif skey == "sweep_vwap_recovery_s":
        if not sweep: add("전략S1", "sweep", "저점 회복 신호 부족")
        if low_reb < 0.55: add("전략S1", "low_rebound", "저점 반등폭 부족", f"{low_reb:+.2f} < +0.55")
        if ch3 < 0.08: add("전략S1", "ch3", "회복 후 3분 흐름 부족", f"{ch3:+.2f} < +0.08")
        if day >= 88: add("전략S1", "day_position", "당일 위치가 높음", f"{day:.1f} >= 88")
    elif skey == "surge_rebreak_s":
        if ch15 < 1.20: add("전략S1", "ch15", "급등 후 힘 부족", f"{ch15:+.2f} < +1.20")
        if ch3 < 0.25: add("전략S1", "ch3", "재돌파 3분 힘 부족", f"{ch3:+.2f} < +0.25")
        if high_gap < -0.15: add("전략S1", "high_gap", "고점 재접근 부족", f"{high_gap:+.2f} < -0.15")
    elif skey == "leader_flow_adaptive_hold_s":
        if ch15 < 0.70: add("전략S1", "ch15", "15분 주도흐름 부족", f"{ch15:+.2f} < +0.70")
        if ch30 < 0.40: add("전략S1", "ch30", "30분 유지흐름 부족", f"{ch30:+.2f} < +0.40")
        if rel < 0.0: add("전략S1", "relative", "시장대비 힘 부족", f"{rel:+.2f} < 0")
        if not (ch3 >= 0.20 or ch5 >= 0.45 or vol): add("전략S1", "early_alive", "초입 반응/거래량 부족", f"3m {ch3:+.2f} / 5m {ch5:+.2f}")
    # 중복 제거
    seen=set(); out_fail=[]
    for x in fail:
        sig=(x.get('category'),x.get('key'),x.get('label'))
        if sig in seen: continue
        seen.add(sig); out_fail.append(x)
    seen=set(); out_miss=[]
    for x in missing:
        sig=x.get('key')
        if sig in seen: continue
        seen.add(sig); out_miss.append(x)
    required = []
    for k in list(dict.fromkeys(V405_COMMON_REQUIRED + V405_STRATEGY_REQUIRED.get(skey, []))):
        d = dict(info.get(k, {"key": k, "label": V405_INFO_LABELS.get(k,k), "ready": False}))
        required.append(d)
    return out_fail[:20], out_miss[:20], required

def _v405_human_summary(fail: List[Dict[str, str]], missing: List[Dict[str, str]]) -> str:
    if fail:
        top = []
        for x in fail[:4]:
            val = x.get('value')
            top.append(x.get('label','-') + (f"({val})" if val else ""))
        return " / ".join(top)
    if missing:
        return "부족정보: " + ", ".join(x.get('label','-') for x in missing[:4])
    return "S1 조건 거의 충족 · 추가확인 필요"

def _v405_reseal_strategy_stage() -> Dict[str, Any]:
    feature_obj = load_json(FEATURE, {}) or {}
    feature_map = map_rows(feature_obj)
    ofmap = map_rows(load_json(ORDERFLOW, {}) or {})
    rows = [r for r in read_jsonl(PAPER_LATEST, max_lines=240) if isinstance(r, dict)]
    fixed: List[Dict[str, Any]] = []
    counts = {"S1": 0, "S2": 0, "S3": 0}
    reason_top: Dict[str, int] = {}
    missing_top: Dict[str, int] = {}
    strategy_missing: Dict[str, Dict[str, int]] = {}
    samples: List[Dict[str, Any]] = []
    for ev in rows:
        stage, why, row, of = _v403_stage_policy(ev, feature_map, ofmap)
        skey = str(ev.get("strategy_key") or ev.get("strategy_bucket_primary") or row.get("strategy_key") or "strategy_s")
        fail, missing, required = _v405_fail_details(row, of, skey, stage)
        after = stage if stage in counts else "S3"
        counts[after] += 1
        out = _v403_force_policy_fields(ev, after, why)
        out["stage_policy_schema"] = "strategy_stage_unified_v405"
        out["stage_policy_note"] = "전략별 S3/S2/S1 단일판정 + S1 탈락이유 세분화"
        out["s1_block_reasons_detail"] = fail
        out["s1_missing_info_detail"] = missing
        out["strategy_required_info"] = required
        out["s1_block_summary"] = _v405_human_summary(fail, missing)
        out["easy_status_label"] = "✅ 실제진입" if after == "S1" else ("⚠️ 재확인" if after == "S2" else "❔ 관찰")
        out["strategy_label_easy"] = V405_STRATEGY_LABELS.get(skey, skey)
        ctx = out.get("entry_context") if isinstance(out.get("entry_context"), dict) else {}
        ctx.update({"s1_block_reasons_detail": fail, "s1_missing_info_detail": missing, "strategy_required_info": required, "s1_block_summary": out["s1_block_summary"], "stage_policy_schema":"strategy_stage_unified_v405"})
        out["entry_context"] = ctx
        snap = out.get("entry_snapshot") if isinstance(out.get("entry_snapshot"), dict) else None
        if isinstance(snap, dict):
            strat = snap.get("strategy") if isinstance(snap.get("strategy"), dict) else {}
            strat.update({"stage_policy_schema":"strategy_stage_unified_v405", "s1_block_reasons_detail": fail, "s1_missing_info_detail": missing, "strategy_required_info": required, "s1_block_summary": out["s1_block_summary"]})
            snap["strategy"] = strat
            flat = snap.get("flat") if isinstance(snap.get("flat"), dict) else {}
            flat.update({"stage_policy_schema":"strategy_stage_unified_v405", "s1_block_summary": out["s1_block_summary"]})
            snap["flat"] = flat
            out["entry_snapshot"] = snap
        for x in fail:
            label = str(x.get("label") or x.get("key") or "기타")
            reason_top[label] = reason_top.get(label, 0) + 1
        for x in missing:
            label = str(x.get("label") or x.get("key") or "기타")
            missing_top[label] = missing_top.get(label, 0) + 1
            sm = strategy_missing.setdefault(V405_STRATEGY_LABELS.get(skey, skey), {})
            sm[label] = sm.get(label, 0) + 1
        if after != "S1" and len(samples) < 20:
            samples.append({
                "ticker": ticker_norm(out.get("ticker") or out.get("market") or out.get("symbol")),
                "strategy": V405_STRATEGY_LABELS.get(skey, skey),
                "strategy_key": skey,
                "stage": after,
                "score": out.get("score"),
                "summary": out.get("s1_block_summary"),
                "missing": missing[:6],
                "fail": fail[:8],
                "required_ready": sum(1 for d in required if d.get("ready")),
                "required_total": len(required),
            })
        fixed.append(out)
    fixed.sort(key=lambda x: ({"S1": 3, "S2": 2, "S3": 1}.get(str(x.get('s_stage')), 0), fnum(x.get("score"), default=0.0), fnum(x.get("updated_ts"), x.get("created_at"), default=0.0)), reverse=True)
    write_jsonl_atomic(PAPER_LATEST, fixed[:40])
    stats = {"schema": "strategy_stage_unified_v405", "stage_counts": counts, "reason_top": reason_top, "missing_info_top": missing_top, "strategy_missing_info": strategy_missing, "samples": samples, "latest_count": len(fixed[:40]), "policy": "strategy_direct_only_with_s1_block_detail"}
    cmap = dict(V403_CONDITION_MAP)
    cmap["version"] = VERSION
    cmap["schema"] = "strategy_stage_unified_v405"
    cmap["summary"] = "전략별 S3/S2/S1 단일 구조 유지 + S1 탈락 이유와 부족정보를 세분화"
    cmap["info_labels"] = V405_INFO_LABELS
    cmap["strategy_required_info"] = {V405_STRATEGY_LABELS.get(k,k): [V405_INFO_LABELS.get(x,x) for x in v] for k,v in V405_STRATEGY_REQUIRED.items()}
    cmap["outside_reference_info"] = V405_OUTSIDE_REFERENCE_INFO
    save_json(CONDITION_MAP_FILE, cmap)
    save_json(S1_BLOCK_AUDIT, {"version": VERSION, "updated_ts": now_ts(), "updated_text": now_text(), **stats, "outside_reference_info": V405_OUTSIDE_REFERENCE_INFO})
    try:
        h = load_json(HANDOFF, {}) or {}
        h.update({"version": VERSION, "stage_policy_schema": "strategy_stage_unified_v405", "v405_stage_counts": counts, "s1_count": counts.get("S1",0), "s2_count": counts.get("S2",0), "s3_count": counts.get("S3",0), "s1_block_audit": stats, "note":"v405: S1 미달 이유를 공통S1/전략S1/부족정보로 나눠 handoff에 저장."})
        save_json(HANDOFF, h)
    except Exception as exc:
        append_error(ERROR, "v405_handoff_status", exc)
    try:
        sm = load_json(SUMMARY, {}) or {}
        sm.update({"version": VERSION, "main_version": "v2.13.377", "condition_map": cmap, "stage_policy_schema": "strategy_stage_unified_v405", "lifecycle_schema": "strategy_stage_unified_v405", "lifecycle_stats": stats, "s_stage_counts": counts, "paper_latest_count": len(fixed[:40]), "s_count": len(fixed[:40]), "s1_block_audit": stats, "note":"v405: S1 후보가 왜 실제진입이 아닌지 쉬운 사유와 부족정보 세부항목을 남긴다."})
        save_json(SUMMARY, sm)
    except Exception as exc:
        append_error(ERROR, "v405_summary_update", exc)
    try:
        pr = load_json(PRIORITY_REQ, {}) or {}
        if isinstance(pr, dict):
            pr["version"] = VERSION
            pr["stage_policy_schema"] = "strategy_stage_unified_v405"
            pr["s1_block_audit"] = stats
            save_json(PRIORITY_REQ, pr)
    except Exception as exc:
        append_error(ERROR, "v405_priority_update", exc)
    return stats

def run_once() -> Dict[str, Any]:  # type: ignore[override]
    base = _v379_base_run_once()
    stats = _v405_reseal_strategy_stage()
    try:
        c = stats.get("stage_counts", {}) if isinstance(stats, dict) else {}
        write_status("running", evaluated=int((load_json(SUMMARY, {}) or {}).get("evaluated") or 0), s_count=sum(int(v) for v in c.values()), paper_latest_count=int(stats.get("latest_count", 0) if isinstance(stats, dict) else 0), s1_count=c.get("S1",0), s2_count=c.get("S2",0), s3_count=c.get("S3",0), lifecycle_schema="strategy_stage_unified_v405", stage_policy_schema="strategy_stage_unified_v405", condition_map_version=VERSION, s1_block_audit=stats, last_sec=fnum((base or {}).get("last_sec"), default=0.0))
    except Exception:
        pass
    out = dict(base or {})
    out.update({"s_stage_counts": stats.get("stage_counts", {}) if isinstance(stats, dict) else {}, "lifecycle_stats": stats, "stage_policy_schema": "strategy_stage_unified_v405", "condition_map_version": VERSION})
    return out


# =============================================================================
# strategy_worker v0.32 / v407: 가격반응 배관 수리 + 보조정보 수집/표시
# - 조건 수치를 풀거나 조이지 않는다.
# - 가격반응 값이 비었을 때 30초/1분/3분 흐름, 포착가 대비 현재가로 계산 가능한 대체값을 만든다.
# - RSI/MACD/볼린저/BTC방향 같은 보조정보는 조건이 아니라 수집·표시용으로만 남긴다.
# =============================================================================
VERSION = "strategy_worker_v0.33"

V407_SCHEMA = "strategy_stage_unified_v407_price_reaction_aux_info"

V407_AUX_INFO = {
    "rsi": {"label": "RSI/과열 위치", "keys": ["rsi", "rsi14", "rsi_14"], "note": "아직 매수조건 아님. 과열/저점회복 참고용."},
    "macd": {"label": "MACD/추세 전환", "keys": ["macd", "macd_hist", "macd_signal", "macd_histogram"], "note": "아직 매수조건 아님. 추세 지속 참고용."},
    "bollinger": {"label": "볼린저밴드 위치", "keys": ["bb_pos", "bollinger_pos", "bb_width", "bollinger_width"], "note": "아직 매수조건 아님. 돌파/저점 위치 참고용."},
    "trade_speed_accel": {"label": "체결 속도 가속도", "keys": ["trade_speed_accel", "buy_trade_speed_accel", "trade_count_accel"], "note": "30초 매수비와 1분 매수지속 차이로 보조 계산 가능."},
    "orderbook_wall_change": {"label": "호가잔량 변화", "keys": ["ask_wall_change", "bid_wall_change", "orderbook_wall_change", "ask_wall_delta"], "note": "매도벽이 빠지는 속도 확인용. 아직 조건 아님."},
    "btc_market_lead": {"label": "BTC/전체장 선행 방향", "keys": ["btc_1m", "btc_3m", "btc_5m", "btc_trend", "market_lead_direction", "market_mode"], "note": "장세 모드는 있으나 BTC 선행성은 추가 보강 후보."},
}


def _v407_num_any(row: Dict[str, Any], of: Dict[str, Any], *keys: str, default: float = -999.0) -> float:
    return _v405_num(row, of, *keys, default=default) if '_v405_num' in globals() else fnum(*[row.get(k) for k in keys], *[of.get(k) for k in keys], default=default)


def _v407_known_any(row: Dict[str, Any], of: Dict[str, Any], *keys: str) -> bool:
    if '_v405_known' in globals():
        return _v405_known(row, of, *keys)
    for src in (row, of):
        if isinstance(src, dict):
            for k in keys:
                v = src.get(k)
                if v is not None and str(v).strip() not in {'', '-', 'None', 'nan', 'NaN'}:
                    return True
    return False


def _v407_find_price(row: Dict[str, Any], of: Dict[str, Any], *keys: str) -> float:
    return _v407_num_any(row, of, *keys, default=-999.0)


def _v407_price_reaction(row: Dict[str, Any], of: Dict[str, Any]) -> Dict[str, Any]:
    """가격반응을 비워두지 않는다. 명시값이 있으면 그것을 쓰고, 없으면 계산 가능한 안전 대체값을 만든다."""
    explicit = _v407_num_any(row, of, "price_reaction_score", "price_recheck_pct", "price_reaction_pct", default=-999.0)
    if explicit > -900:
        return {"ready": True, "value": explicit, "source": "전용 가격반응값", "note": f"기존값 {explicit:+.2f}%"}

    # 1순위: 후보 포착가/재확인가 대비 현재가
    current = _v407_find_price(row, of, "current_price", "price", "last_price", "close", "trade_price")
    ref = _v407_find_price(row, of, "detected_price", "watch_price", "first_seen_price", "s3_price", "s2_price", "candidate_price", "base_price", "entry_signal_price")
    if current > 0 and ref > 0:
        pct = (current - ref) / ref * 100.0
        return {"ready": True, "value": pct, "source": "포착가 대비 현재가", "note": f"현재 {current:.6g} / 기준 {ref:.6g}"}

    # 2순위: 단기 흐름. 이미 S1 안전문에 같이 쓰는 값이라 새 조건이 아니라 빈 값 보정이다.
    ch30s = _v407_num_any(row, of, "change_30s", "price_change_30s", default=-999.0)
    ch1 = _v407_num_any(row, of, "change_1m", "price_change_1m", default=-999.0)
    ch3 = _v407_num_any(row, of, "change_3m", "price_change_3m", "money_flow_3m_pct", "three_min_flow_pct", default=-999.0)
    candidates = [("30초 흐름", ch30s), ("1분 흐름", ch1), ("3분 흐름", ch3)]
    known = [(name, val) for name, val in candidates if val > -900]
    if known:
        # 진입 직전 반응 확인용이므로 가장 좋은 값이 아니라, 30초/1분을 우선하고 없을 때 3분을 쓴다.
        for name, val in known:
            if name in {"30초 흐름", "1분 흐름"}:
                return {"ready": True, "value": val, "source": f"{name} 대체", "note": "전용 가격반응값이 없어 단기흐름으로 계산"}
        name, val = known[-1]
        return {"ready": True, "value": val, "source": f"{name} 대체", "note": "전용 가격반응값이 없어 3분 흐름으로 계산"}

    return {"ready": False, "value": -999.0, "source": "계산불가", "note": "가격반응 전용값·포착가·단기흐름 모두 없음"}


def _v407_hydrate_row(row: Dict[str, Any], of: Dict[str, Any]) -> Tuple[Dict[str, Any], Dict[str, Any]]:
    r = dict(row or {})
    o = dict(of or {})
    pr = _v407_price_reaction(r, o)
    if pr.get("ready"):
        val = fnum(pr.get("value"), default=0.0)
        r.setdefault("price_reaction_pct", val)
        r.setdefault("price_recheck_pct", val)
        r["price_reaction_source"] = pr.get("source")
        r["price_reaction_note"] = pr.get("note")
        ctx = r.get("entry_context") if isinstance(r.get("entry_context"), dict) else {}
        ctx.update({"price_reaction_pct": val, "price_reaction_source": pr.get("source"), "price_reaction_note": pr.get("note")})
        r["entry_context"] = ctx
    return r, o


def _v407_aux_info(row: Dict[str, Any], of: Dict[str, Any]) -> Dict[str, Dict[str, Any]]:
    out: Dict[str, Dict[str, Any]] = {}
    buy30 = _v407_num_any(row, of, "buy_ratio", "buy_ratio_30s", "micro_trade_buy_ratio_30", default=-999.0)
    buy1 = _v407_num_any(row, of, "buy_ratio_1m", "buy_ratio_60", "micro_buy_ratio_sustain_1m", "buy_ratio_sustain", default=-999.0)
    ask = _v407_num_any(row, of, "ask_wall_ratio", "ask_wall", "micro_ask_wall_ratio", default=-999.0)
    bid = _v407_num_any(row, of, "bid_wall_ratio", "micro_bid_wall_ratio", default=-999.0)
    market_mode = _v405_first(row, of, "market_mode") if '_v405_first' in globals() else row.get("market_mode")
    for key, spec in V407_AUX_INFO.items():
        keys = spec.get("keys", [])
        ready = _v407_known_any(row, of, *keys)
        value: Any = None
        status = "수집됨" if ready else "없음"
        if key == "trade_speed_accel" and buy30 > -900 and buy1 > -900:
            ready = True; value = round(buy30 - buy1, 4); status = "보조계산"
        elif key == "orderbook_wall_change" and ask > -900 and bid > -900:
            ready = True; value = {"매도벽": ask, "매수벽": bid}; status = "현재벽만 있음"
        elif key == "btc_market_lead" and market_mode is not None:
            ready = True; value = market_mode; status = "장세모드 있음"
        else:
            if ready:
                value = _v405_first(row, of, *keys) if '_v405_first' in globals() else None
        out[key] = {"key": key, "label": spec.get("label", key), "ready": bool(ready), "status": status, "value": value, "note": spec.get("note", "")}
    return out


def _v407_stage_policy(ev: Dict[str, Any], feature_map: Dict[str, Dict[str, Any]], ofmap: Dict[str, Dict[str, Any]]) -> Tuple[str, List[str], Dict[str, Any], Dict[str, Any]]:
    t = ticker_norm(ev.get("ticker") or ev.get("market") or ev.get("symbol"))
    row, of = _v403_merge_from_event(ev, feature_map.get(t, {}) if t else {}, ofmap.get(t, {}) if t else {})
    row, of = _v407_hydrate_row(row, of)
    skey = str(ev.get("strategy_key") or ev.get("strategy_bucket_primary") or row.get("strategy_key") or "strategy_s")
    stage, why = _v015_stage_decision(row, of, skey)
    pr = _v407_price_reaction(row, of)
    if pr.get("ready"):
        why = [f"가격반응:{pr.get('source')} {fnum(pr.get('value'), default=0.0):+.2f}%"] + list(why)
    why = ["전략별단계판정"] + [str(x) for x in why[:8]]
    return stage, why, row, of


_v407_prev_fail_details = _v405_fail_details


def _v405_fail_details(row: Dict[str, Any], of: Dict[str, Any], skey: str, stage: str):  # type: ignore[override]
    row2, of2 = _v407_hydrate_row(row, of)
    fail, missing, required = _v407_prev_fail_details(row2, of2, skey, stage)
    aux = _v407_aux_info(row2, of2)
    for d in required:
        if isinstance(d, dict) and d.get("key") == "price_reaction":
            pr = _v407_price_reaction(row2, of2)
            if pr.get("ready"):
                d["ready"] = True
                d["value"] = fnum(pr.get("value"), default=0.0)
                d["note"] = f"{pr.get('source')} · {pr.get('note')}"
    # v405에서 이미 만들어진 '가격반응 없음'은 보조계산이 되면 제거한다.
    pr = _v407_price_reaction(row2, of2)
    if pr.get("ready"):
        missing = [x for x in missing if not (isinstance(x, dict) and x.get("key") == "price_reaction")]
        fail = [x for x in fail if not (isinstance(x, dict) and x.get("key") == "price_reaction" and "없음" in str(x.get("label")))]
    return fail, missing, required


def _v407_reseal_strategy_stage() -> Dict[str, Any]:
    feature_obj = load_json(FEATURE, {}) or {}
    feature_map = map_rows(feature_obj)
    ofmap = map_rows(load_json(ORDERFLOW, {}) or {})
    rows = [r for r in read_jsonl(PAPER_LATEST, max_lines=240) if isinstance(r, dict)]
    fixed: List[Dict[str, Any]] = []
    counts = {"S1": 0, "S2": 0, "S3": 0}
    reason_top: Dict[str, int] = {}
    missing_top: Dict[str, int] = {}
    strategy_missing: Dict[str, Dict[str, int]] = {}
    samples: List[Dict[str, Any]] = []
    pr_sources: Dict[str, int] = {}
    aux_ready_top: Dict[str, int] = {}
    aux_missing_top: Dict[str, int] = {}
    for ev in rows:
        stage, why, row, of = _v407_stage_policy(ev, feature_map, ofmap)
        skey = str(ev.get("strategy_key") or ev.get("strategy_bucket_primary") or row.get("strategy_key") or "strategy_s")
        fail, missing, required = _v405_fail_details(row, of, skey, stage)
        aux = _v407_aux_info(row, of)
        pr = _v407_price_reaction(row, of)
        pr_sources[str(pr.get("source") or "계산불가")] = pr_sources.get(str(pr.get("source") or "계산불가"), 0) + 1
        for av in aux.values():
            label = str(av.get("label") or av.get("key") or "보조정보")
            if av.get("ready"):
                aux_ready_top[label] = aux_ready_top.get(label, 0) + 1
            else:
                aux_missing_top[label] = aux_missing_top.get(label, 0) + 1
        after = stage if stage in counts else "S3"
        counts[after] += 1
        out = _v403_force_policy_fields(ev, after, why)
        out["stage_policy_schema"] = V407_SCHEMA
        out["stage_policy_note"] = "전략별 S3/S2/S1 단일판정 + 가격반응 보조계산 + 보조정보 표시"
        out["price_reaction_pct"] = row.get("price_reaction_pct")
        out["price_reaction_source"] = row.get("price_reaction_source")
        out["price_reaction_note"] = row.get("price_reaction_note")
        out["s1_block_reasons_detail"] = fail
        out["s1_missing_info_detail"] = missing
        out["strategy_required_info"] = required
        out["s1_block_summary"] = _v405_human_summary(fail, missing)
        out["auxiliary_info_status"] = aux
        out["easy_status_label"] = "✅ 실제진입" if after == "S1" else ("⚠️ 재확인" if after == "S2" else "❔ 관찰")
        out["strategy_label_easy"] = V405_STRATEGY_LABELS.get(skey, skey)
        ctx = out.get("entry_context") if isinstance(out.get("entry_context"), dict) else {}
        ctx.update({"price_reaction_pct": row.get("price_reaction_pct"), "price_reaction_source": row.get("price_reaction_source"), "price_reaction_note": row.get("price_reaction_note"), "s1_block_reasons_detail": fail, "s1_missing_info_detail": missing, "strategy_required_info": required, "auxiliary_info_status": aux, "s1_block_summary": out["s1_block_summary"], "stage_policy_schema": V407_SCHEMA})
        out["entry_context"] = ctx
        snap = out.get("entry_snapshot") if isinstance(out.get("entry_snapshot"), dict) else None
        if isinstance(snap, dict):
            strat = snap.get("strategy") if isinstance(snap.get("strategy"), dict) else {}
            strat.update({"stage_policy_schema": V407_SCHEMA, "price_reaction_pct": row.get("price_reaction_pct"), "price_reaction_source": row.get("price_reaction_source"), "s1_block_reasons_detail": fail, "s1_missing_info_detail": missing, "strategy_required_info": required, "auxiliary_info_status": aux, "s1_block_summary": out["s1_block_summary"]})
            snap["strategy"] = strat
            flat = snap.get("flat") if isinstance(snap.get("flat"), dict) else {}
            flat.update({"stage_policy_schema": V407_SCHEMA, "price_reaction_pct": row.get("price_reaction_pct"), "price_reaction_source": row.get("price_reaction_source"), "s1_block_summary": out["s1_block_summary"]})
            snap["flat"] = flat
            out["entry_snapshot"] = snap
        for x in fail:
            label = str(x.get("label") or x.get("key") or "기타")
            reason_top[label] = reason_top.get(label, 0) + 1
        for x in missing:
            label = str(x.get("label") or x.get("key") or "기타")
            missing_top[label] = missing_top.get(label, 0) + 1
            sm = strategy_missing.setdefault(V405_STRATEGY_LABELS.get(skey, skey), {})
            sm[label] = sm.get(label, 0) + 1
        if after != "S1" and len(samples) < 20:
            samples.append({
                "ticker": ticker_norm(out.get("ticker") or out.get("market") or out.get("symbol")),
                "strategy": V405_STRATEGY_LABELS.get(skey, skey),
                "strategy_key": skey,
                "stage": after,
                "score": out.get("score"),
                "summary": out.get("s1_block_summary"),
                "missing": missing[:6],
                "fail": fail[:8],
                "required_ready": sum(1 for d in required if d.get("ready")),
                "required_total": len(required),
                "price_reaction": {"value": row.get("price_reaction_pct"), "source": row.get("price_reaction_source"), "note": row.get("price_reaction_note")},
                "auxiliary_info_status": aux,
            })
        fixed.append(out)
    fixed.sort(key=lambda x: ({"S1": 3, "S2": 2, "S3": 1}.get(str(x.get('s_stage')), 0), fnum(x.get("score"), default=0.0), fnum(x.get("updated_ts"), x.get("created_at"), default=0.0)), reverse=True)
    write_jsonl_atomic(PAPER_LATEST, fixed[:40])
    stats = {"schema": V407_SCHEMA, "stage_counts": counts, "reason_top": reason_top, "missing_info_top": missing_top, "strategy_missing_info": strategy_missing, "samples": samples, "latest_count": len(fixed[:40]), "policy": "strategy_direct_only_with_price_reaction_hydration", "price_reaction_sources": pr_sources, "aux_ready_top": aux_ready_top, "aux_missing_top": aux_missing_top}
    cmap = dict(V403_CONDITION_MAP)
    cmap["version"] = VERSION
    cmap["schema"] = V407_SCHEMA
    cmap["summary"] = "전략별 S3/S2/S1 단일 구조 유지 + 가격반응 빈값 보정 + 보조정보 수집/표시. 조건 수치는 변경하지 않음."
    cmap["info_labels"] = V405_INFO_LABELS
    cmap["strategy_required_info"] = {V405_STRATEGY_LABELS.get(k,k): [V405_INFO_LABELS.get(x,x) for x in v] for k,v in V405_STRATEGY_REQUIRED.items()}
    cmap["outside_reference_info"] = [{"name": v.get("label"), "status": "수집/표시 대상", "note": v.get("note")} for v in V407_AUX_INFO.values()]
    cmap["price_reaction_policy"] = ["1순위: 전용 가격반응값", "2순위: 포착가 대비 현재가", "3순위: 30초/1분/3분 흐름으로 보조계산", "조건 수치 +0.05는 변경하지 않음"]
    save_json(CONDITION_MAP_FILE, cmap)
    save_json(S1_BLOCK_AUDIT, {"version": VERSION, "updated_ts": now_ts(), "updated_text": now_text(), **stats, "outside_reference_info": cmap["outside_reference_info"], "price_reaction_policy": cmap["price_reaction_policy"]})
    try:
        h = load_json(HANDOFF, {}) or {}
        h.update({"version": VERSION, "stage_policy_schema": V407_SCHEMA, "v407_stage_counts": counts, "s1_count": counts.get("S1",0), "s2_count": counts.get("S2",0), "s3_count": counts.get("S3",0), "s1_block_audit": stats, "note":"v407: 가격반응 빈값을 실제 값/포착가/단기흐름으로 보조계산하고 보조정보 상태를 handoff에 저장."})
        save_json(HANDOFF, h)
    except Exception as exc:
        append_error(ERROR, "v407_handoff_status", exc)
    try:
        sm = load_json(SUMMARY, {}) or {}
        sm.update({"version": VERSION, "main_version": "v2.13.377", "condition_map": cmap, "stage_policy_schema": V407_SCHEMA, "lifecycle_schema": V407_SCHEMA, "lifecycle_stats": stats, "s_stage_counts": counts, "paper_latest_count": len(fixed[:40]), "s_count": len(fixed[:40]), "s1_block_audit": stats, "price_reaction_sources": pr_sources, "aux_info_status": {"ready": aux_ready_top, "missing": aux_missing_top}, "note":"v407: 가격반응 배관 수리 + 보조정보 수집/표시. 조건 수치는 변경하지 않음."})
        save_json(SUMMARY, sm)
    except Exception as exc:
        append_error(ERROR, "v407_summary_update", exc)
    return stats


def run_once() -> Dict[str, Any]:  # type: ignore[override]
    base = _v379_base_run_once()
    stats = _v407_reseal_strategy_stage()
    try:
        c = stats.get("stage_counts", {}) if isinstance(stats, dict) else {}
        write_status("running", evaluated=int((load_json(SUMMARY, {}) or {}).get("evaluated") or 0), s_count=sum(int(v) for v in c.values()), paper_latest_count=int(stats.get("latest_count", 0) if isinstance(stats, dict) else 0), s1_count=c.get("S1",0), s2_count=c.get("S2",0), s3_count=c.get("S3",0), lifecycle_schema=V407_SCHEMA, stage_policy_schema=V407_SCHEMA, condition_map_version=VERSION, s1_block_audit=stats, last_sec=fnum((base or {}).get("last_sec"), default=0.0))
    except Exception:
        pass
    out = dict(base or {})
    out.update({"s_stage_counts": stats.get("stage_counts", {}) if isinstance(stats, dict) else {}, "lifecycle_stats": stats, "stage_policy_schema": V407_SCHEMA, "condition_map_version": VERSION})
    return out





# =============================================================================
# strategy_worker v0.33 / v408: 후보 판독 결론 + 보조지표 완성
# - S1/S2/S3를 더 쪼개지 않는다.
# - S1 미달 후보에 복기용 판독(아까움/재확인/안 산 게 맞음)을 붙인다.
# - RSI/MACD/볼린저는 조건이 아니라 수집/표시/비교용이다.
# =============================================================================
VERSION = "strategy_worker_v0.33"
V408_SCHEMA = "strategy_stage_unified_v408_s1_decision_aux_complete"


def _v408_extract_closes(row: Dict[str, Any], of: Dict[str, Any], limit: int = 80) -> List[float]:
    vals: Any = None
    for src in (row, of, row.get('entry_context') if isinstance(row.get('entry_context'), dict) else {}, row.get('entry_snapshot') if isinstance(row.get('entry_snapshot'), dict) else {}):
        if not isinstance(src, dict): continue
        for k in ('closes','close_history','candle_closes','ohlcv_closes','recent_closes','close_list'):
            if isinstance(src.get(k), list) and len(src.get(k)) >= 5:
                vals = src.get(k); break
        if vals is not None: break
        for k in ('candles','ohlcv','kline','klines','candle_rows'):
            arr = src.get(k)
            if isinstance(arr, list) and len(arr) >= 5:
                tmp=[]
                for x in arr:
                    if isinstance(x, dict):
                        tmp.append(fnum(x.get('close'), x.get('c'), x.get('trade_price'), default=0.0))
                    elif isinstance(x, (list, tuple)) and len(x) >= 5:
                        tmp.append(fnum(x[4], default=0.0))
                tmp=[v for v in tmp if v>0]
                if len(tmp)>=5: vals=tmp; break
        if vals is not None: break
    if not isinstance(vals, list): return []
    out=[]
    for v in vals[-limit:]:
        fv=fnum(v, default=0.0)
        if fv>0: out.append(fv)
    return out


def _v408_rsi(closes: List[float], period: int=14) -> Optional[float]:
    if len(closes) < period + 1: return None
    gains=[]; losses=[]
    for a,b in zip(closes[-period-1:-1], closes[-period:]):
        d=b-a
        gains.append(max(d,0.0)); losses.append(max(-d,0.0))
    ag=sum(gains)/period; al=sum(losses)/period
    if al <= 0 and ag <= 0: return 50.0
    if al <= 0: return 100.0
    rs=ag/al
    return 100.0 - (100.0/(1.0+rs))


def _v408_ema(vals: List[float], period: int) -> Optional[float]:
    if len(vals) < period: return None
    k=2.0/(period+1.0)
    ema=sum(vals[:period])/period
    for v in vals[period:]: ema = v*k + ema*(1-k)
    return ema


def _v408_macd(closes: List[float]) -> Dict[str, Any]:
    if len(closes) < 35: return {"ready": False, "value": None, "status": "캔들 부족"}
    # Compute EMA series for MACD signal roughly by rolling from available closes.
    macd_line=[]
    for i in range(26, len(closes)+1):
        sub=closes[:i]
        e12=_v408_ema(sub, 12); e26=_v408_ema(sub, 26)
        if e12 is not None and e26 is not None: macd_line.append(e12-e26)
    if len(macd_line) < 9: return {"ready": False, "value": None, "status": "신호선 부족"}
    signal=_v408_ema(macd_line, 9)
    if signal is None: return {"ready": False, "value": None, "status": "신호선 부족"}
    hist=macd_line[-1]-signal
    return {"ready": True, "value": round(hist, 6), "status": "양호" if hist>=0 else "약함", "macd": round(macd_line[-1],6), "signal": round(signal,6)}


def _v408_bollinger(closes: List[float], period: int=20) -> Dict[str, Any]:
    if len(closes) < period: return {"ready": False, "value": None, "status": "캔들 부족"}
    arr=closes[-period:]
    ma=sum(arr)/period
    var=sum((x-ma)*(x-ma) for x in arr)/period
    sd=math.sqrt(var)
    upper=ma+2*sd; lower=ma-2*sd
    cur=arr[-1]
    if upper == lower: pos=50.0
    else: pos=(cur-lower)/(upper-lower)*100.0
    return {"ready": True, "value": round(pos,2), "status": "상단부근" if pos>=80 else "하단부근" if pos<=20 else "중간", "ma": round(ma,6), "upper": round(upper,6), "lower": round(lower,6)}


def _v408_enhanced_aux_info(row: Dict[str, Any], of: Dict[str, Any]) -> Dict[str, Dict[str, Any]]:
    aux=_v407_aux_info(row, of)
    closes=_v408_extract_closes(row, of)
    # RSI: prefer supplied values, then compute from closes.
    rsi_val=_v407_num_any(row, of, 'rsi', 'rsi14', 'rsi_14', default=-999.0)
    if rsi_val <= -900:
        calc=_v408_rsi(closes)
        if calc is not None: rsi_val=calc
    aux['rsi']={"key":"rsi","label":"RSI/과열 위치","ready": rsi_val>-900,"status": "과열" if rsi_val>=70 else "침체" if rsi_val<=30 and rsi_val>-900 else "중간" if rsi_val>-900 else "캔들 부족","value": None if rsi_val<=-900 else round(rsi_val,2),"note":"조건 아님. 과열/저점회복 비교용."}
    # MACD: prefer supplied histogram/value, then compute.
    mh=_v407_num_any(row, of, 'macd_hist', 'macd_histogram', 'macd', default=-999.0)
    if mh>-900:
        aux['macd']={"key":"macd","label":"MACD/추세 전환","ready":True,"status":"양호" if mh>=0 else "약함","value":round(mh,6),"note":"조건 아님. 추세 비교용."}
    else:
        m=_v408_macd(closes)
        aux['macd']={"key":"macd","label":"MACD/추세 전환","ready":bool(m.get('ready')),"status":m.get('status'),"value":m.get('value'),"note":"조건 아님. 추세 비교용."}
    # Bollinger
    bb=_v407_num_any(row, of, 'bb_pos', 'bollinger_pos', default=-999.0)
    if bb>-900:
        aux['bollinger']={"key":"bollinger","label":"볼린저밴드 위치","ready":True,"status":"상단부근" if bb>=80 else "하단부근" if bb<=20 else "중간","value":round(bb,2),"note":"조건 아님. 위치 비교용."}
    else:
        b=_v408_bollinger(closes)
        aux['bollinger']={"key":"bollinger","label":"볼린저밴드 위치","ready":bool(b.get('ready')),"status":b.get('status'),"value":b.get('value'),"note":"조건 아님. 위치 비교용."}
    return aux


def _v408_fail_labels(fail: List[Dict[str, Any]]) -> List[str]:
    out=[]
    for x in fail or []:
        if isinstance(x, dict): out.append(str(x.get('label') or x.get('key') or ''))
        else: out.append(str(x))
    return out


def _v408_review_decision(stage: str, fail: List[Dict[str, Any]], missing: List[Dict[str, Any]], required: List[Dict[str, Any]], row: Dict[str, Any], of: Dict[str, Any]) -> Dict[str, str]:
    labels=_v408_fail_labels(fail)
    text=' / '.join(labels)
    pr=_v407_price_reaction(row, of)
    pr_val=fnum(pr.get('value'), default=-999.0) if pr.get('ready') else -999.0
    spread=_v407_num_any(row, of, 'spread_pct', 'micro_spread_pct', 'orderbook_spread_pct', default=-999.0)
    slip=_v407_num_any(row, of, 'slippage_pct', 'expected_slippage_pct', 'estimated_slippage_pct', default=-999.0)
    buy=_v407_num_any(row, of, 'buy_ratio', 'buy_ratio_30s', 'micro_trade_buy_ratio_30', default=-999.0)
    short_bad = any(k in text for k in ['진입 직전 단기반응 부족','단기반응 부족'])
    wall_bad = any(k in text for k in ['매도벽','매도압력'])
    spread_bad = (spread > 0.28) or (slip > 0.28) or any(k in text for k in ['스프레드 부담','예상 미끄러짐 부담'])
    buy_bad = (buy > -900 and buy < 0.62) or any(k in text for k in ['매수체결비 부족','1분 매수지속 부족'])
    major_bad = spread_bad or wall_bad or (buy > -900 and buy < 0.58) or short_bad
    ready = sum(1 for d in required if isinstance(d, dict) and d.get('ready'))
    total = max(1, len(required))
    missing_count = len(missing or [])
    # 아까움: 정보는 거의 다 있고, 위험비용은 낮고, 가격반응만 아주 조금 부족한 쪽.
    if stage != 'S1' and missing_count == 0 and ready >= total-1 and not major_bad and pr_val > -900 and -0.03 <= pr_val < 0.05 and (spread <= 0.22 or spread <= -900) and (slip <= 0.22 or slip <= -900) and (buy >= 0.66 or buy <= -900):
        return {"decision":"✅ 아까운 후보", "reason":"정보는 거의 준비됨 · 비용/체결은 양호 · 가격반응만 조금 부족"}
    if stage != 'S1' and major_bad:
        reasons=[]
        if spread_bad: reasons.append('스프레드/미끄러짐 부담')
        if buy_bad: reasons.append('매수체결 약함')
        if wall_bad: reasons.append('매도벽/매도압력 부담')
        if short_bad: reasons.append('진입 직전 반응 약함')
        return {"decision":"❌ 안 산 게 맞음", "reason":' · '.join(reasons[:3]) or '손실위험이 큼'}
    if stage != 'S1' and missing_count > 0:
        return {"decision":"⚠️ 재확인 후보", "reason":"필요정보 일부가 아직 비어 있음"}
    if stage != 'S1':
        return {"decision":"⚠️ 재확인 후보", "reason":"정보는 있으나 S1 조건에 아직 못 미침"}
    return {"decision":"✅ 실제진입 후보", "reason":"S1 조건 통과"}


def _v408_reseal_strategy_stage() -> Dict[str, Any]:
    feature_obj = load_json(FEATURE, {}) or {}
    feature_map = map_rows(feature_obj)
    ofmap = map_rows(load_json(ORDERFLOW, {}) or {})
    rows = [r for r in read_jsonl(PAPER_LATEST, max_lines=240) if isinstance(r, dict)]
    fixed: List[Dict[str, Any]] = []
    counts = {"S1": 0, "S2": 0, "S3": 0}
    reason_top: Dict[str, int] = {}
    missing_top: Dict[str, int] = {}
    strategy_missing: Dict[str, Dict[str, int]] = {}
    samples: List[Dict[str, Any]] = []
    pr_sources: Dict[str, int] = {}
    aux_ready_top: Dict[str, int] = {}
    aux_missing_top: Dict[str, int] = {}
    decision_top: Dict[str, int] = {}
    decision_by_strategy: Dict[str, Dict[str, int]] = {}
    for ev in rows:
        stage, why, row, of = _v407_stage_policy(ev, feature_map, ofmap)
        skey = str(ev.get("strategy_key") or ev.get("strategy_bucket_primary") or row.get("strategy_key") or "strategy_s")
        fail, missing, required = _v405_fail_details(row, of, skey, stage)
        aux = _v408_enhanced_aux_info(row, of)
        pr = _v407_price_reaction(row, of)
        dec = _v408_review_decision(stage, fail, missing, required, row, of)
        dname = dec.get('decision','❔ 판독대기')
        decision_top[dname] = decision_top.get(dname, 0) + 1
        s_label = V405_STRATEGY_LABELS.get(skey, skey)
        decision_by_strategy.setdefault(s_label, {})[dname] = decision_by_strategy.setdefault(s_label, {}).get(dname, 0) + 1
        pr_sources[str(pr.get("source") or "계산불가")] = pr_sources.get(str(pr.get("source") or "계산불가"), 0) + 1
        for av in aux.values():
            label = str(av.get("label") or av.get("key") or "보조정보")
            if av.get("ready"):
                aux_ready_top[label] = aux_ready_top.get(label, 0) + 1
            else:
                aux_missing_top[label] = aux_missing_top.get(label, 0) + 1
        after = stage if stage in counts else "S3"
        counts[after] += 1
        out = _v403_force_policy_fields(ev, after, why)
        out["stage_policy_schema"] = V408_SCHEMA
        out["stage_policy_note"] = "전략별 S3/S2/S1 단일판정 + 가격반응 보조계산 + 후보 판독 결론 + 보조지표 표시"
        out["price_reaction_pct"] = row.get("price_reaction_pct")
        out["price_reaction_source"] = row.get("price_reaction_source")
        out["price_reaction_note"] = row.get("price_reaction_note")
        out["s1_block_reasons_detail"] = fail
        out["s1_missing_info_detail"] = missing
        out["strategy_required_info"] = required
        out["s1_block_summary"] = _v405_human_summary(fail, missing)
        out["auxiliary_info_status"] = aux
        out["review_decision"] = dname
        out["review_decision_reason"] = dec.get('reason')
        out["easy_status_label"] = "✅ 실제진입" if after == "S1" else ("⚠️ 재확인" if after == "S2" else "❔ 관찰")
        out["strategy_label_easy"] = s_label
        ctx = out.get("entry_context") if isinstance(out.get("entry_context"), dict) else {}
        ctx.update({"price_reaction_pct": row.get("price_reaction_pct"), "price_reaction_source": row.get("price_reaction_source"), "price_reaction_note": row.get("price_reaction_note"), "s1_block_reasons_detail": fail, "s1_missing_info_detail": missing, "strategy_required_info": required, "auxiliary_info_status": aux, "s1_block_summary": out["s1_block_summary"], "stage_policy_schema": V408_SCHEMA, "review_decision": dname, "review_decision_reason": dec.get('reason')})
        out["entry_context"] = ctx
        for x in fail:
            label = str(x.get("label") or x.get("key") or "기타")
            reason_top[label] = reason_top.get(label, 0) + 1
        for x in missing:
            label = str(x.get("label") or x.get("key") or "기타")
            missing_top[label] = missing_top.get(label, 0) + 1
            sm = strategy_missing.setdefault(s_label, {})
            sm[label] = sm.get(label, 0) + 1
        if after != "S1" and len(samples) < 24:
            samples.append({
                "ticker": ticker_norm(out.get("ticker") or out.get("market") or out.get("symbol")),
                "strategy": s_label,
                "strategy_key": skey,
                "stage": after,
                "score": out.get("score"),
                "summary": out.get("s1_block_summary"),
                "missing": missing[:6],
                "fail": fail[:8],
                "required_ready": sum(1 for d in required if d.get("ready")),
                "required_total": len(required),
                "price_reaction": {"value": row.get("price_reaction_pct"), "source": row.get("price_reaction_source"), "note": row.get("price_reaction_note")},
                "auxiliary_info_status": aux,
                "review_decision": dname,
                "review_decision_reason": dec.get('reason'),
            })
        fixed.append(out)
    fixed.sort(key=lambda x: ({"S1": 3, "S2": 2, "S3": 1}.get(str(x.get('s_stage')), 0), fnum(x.get("score"), default=0.0), fnum(x.get("updated_ts"), x.get("created_at"), default=0.0)), reverse=True)
    write_jsonl_atomic(PAPER_LATEST, fixed[:40])
    stats = {"schema": V408_SCHEMA, "stage_counts": counts, "reason_top": reason_top, "missing_info_top": missing_top, "strategy_missing_info": strategy_missing, "samples": samples, "latest_count": len(fixed[:40]), "policy": "strategy_direct_only_with_price_reaction_and_decision", "price_reaction_sources": pr_sources, "aux_ready_top": aux_ready_top, "aux_missing_top": aux_missing_top, "decision_top": decision_top, "decision_by_strategy": decision_by_strategy}
    cmap = dict(V403_CONDITION_MAP)
    cmap["version"] = VERSION
    cmap["schema"] = V408_SCHEMA
    cmap["summary"] = "전략별 S3/S2/S1 구조 유지 + 가격반응 보정 + 후보 판독 결론 + 보조지표 표시. 조건 수치는 변경하지 않음."
    cmap["info_labels"] = V405_INFO_LABELS
    cmap["strategy_required_info"] = {V405_STRATEGY_LABELS.get(k,k): [V405_INFO_LABELS.get(x,x) for x in v] for k,v in V405_STRATEGY_REQUIRED.items()}
    cmap["outside_reference_info"] = [{"name": "RSI/과열 위치", "status":"수집/표시", "note":"조건 아님. 과열/저점회복 비교용."}, {"name":"MACD/추세 전환", "status":"수집/표시", "note":"조건 아님. 추세 전환 비교용."}, {"name":"볼린저밴드 위치", "status":"수집/표시", "note":"조건 아님. 위치 비교용."}, {"name":"체결 속도 가속도", "status":"수집/표시", "note":"조건 아님. 매수세 변화 비교용."}, {"name":"호가잔량 변화", "status":"수집/표시", "note":"조건 아님. 벽 변화 비교용."}, {"name":"BTC/전체장 선행 방향", "status":"수집/표시", "note":"조건 아님. 장세 비교용."}]
    cmap["review_decision_policy"] = ["새 S단계가 아님", "아까운 후보=정보/비용은 양호하나 가격반응만 조금 부족", "재확인 후보=정보 일부 또는 조건 일부 재확인 필요", "안 산 게 맞음=스프레드/미끄러짐/체결/매도벽/단기역행 부담"]
    save_json(CONDITION_MAP_FILE, cmap)
    save_json(S1_BLOCK_AUDIT, {"version": VERSION, "updated_ts": now_ts(), "updated_text": now_text(), **stats, "outside_reference_info": cmap["outside_reference_info"], "review_decision_policy": cmap["review_decision_policy"]})
    try:
        h = load_json(HANDOFF, {}) or {}
        h.update({"version": VERSION, "stage_policy_schema": V408_SCHEMA, "v408_stage_counts": counts, "s1_count": counts.get("S1",0), "s2_count": counts.get("S2",0), "s3_count": counts.get("S3",0), "s1_block_audit": stats, "note":"v408: S1/S2/S3는 유지하고, S1 미달 후보에 복기용 판독 결론과 보조지표 상태를 저장."})
        save_json(HANDOFF, h)
    except Exception as exc:
        append_error(ERROR, "v408_handoff_status", exc)
    try:
        sm = load_json(SUMMARY, {}) or {}
        sm.update({"version": VERSION, "main_version": "v2.13.377", "condition_map": cmap, "stage_policy_schema": V408_SCHEMA, "lifecycle_schema": V408_SCHEMA, "lifecycle_stats": stats, "s_stage_counts": counts, "paper_latest_count": len(fixed[:40]), "s_count": len(fixed[:40]), "s1_block_audit": stats, "price_reaction_sources": pr_sources, "aux_info_status": {"ready": aux_ready_top, "missing": aux_missing_top}, "decision_top": decision_top, "note":"v408: 후보 판독 결론 + 보조지표 표시. 조건 수치는 변경하지 않음."})
        save_json(SUMMARY, sm)
    except Exception as exc:
        append_error(ERROR, "v408_summary_update", exc)
    return stats


def run_once() -> Dict[str, Any]:  # type: ignore[override]
    base = _v379_base_run_once()
    stats = _v408_reseal_strategy_stage()
    try:
        c = stats.get("stage_counts", {}) if isinstance(stats, dict) else {}
        write_status("running", evaluated=int((load_json(SUMMARY, {}) or {}).get("evaluated") or 0), s_count=sum(int(v) for v in c.values()), paper_latest_count=int(stats.get("latest_count", 0) if isinstance(stats, dict) else 0), s1_count=c.get("S1",0), s2_count=c.get("S2",0), s3_count=c.get("S3",0), lifecycle_schema=V408_SCHEMA, stage_policy_schema=V408_SCHEMA, condition_map_version=VERSION, s1_block_audit=stats, last_sec=fnum((base or {}).get("last_sec"), default=0.0))
    except Exception:
        pass
    out = dict(base or {})
    out.update({"s_stage_counts": stats.get("stage_counts", {}) if isinstance(stats, dict) else {}, "lifecycle_stats": stats, "stage_policy_schema": V408_SCHEMA, "condition_map_version": VERSION})
    return out



# =============================================================================
# strategy_worker v0.34 / v409: v408 판독 결과 실제 표시 연결 확인용 스키마 고정
# - 조건 수치 변경 없음.
# - v408에서 만든 후보 판독 결론/보조정보를 v409 스키마로 다시 저장해 메인봇이 구 v407 캐시를 읽지 않게 한다.
# =============================================================================
VERSION = "strategy_worker_v0.34"
MAIN_VERSION = "v2.13.377"
MAIN_DEPLOY_VERSION = "v2.13.377"
MAIN_BOT_VERSION = "수익형 v2.13.377"
V409_SCHEMA = "strategy_stage_unified_v409_decision_route_fix"

_v409_base_run_once = run_once

def _v409_relabel_outputs(stats: Dict[str, Any]) -> Dict[str, Any]:
    try:
        audit = load_json(S1_BLOCK_AUDIT, {}) or {}
        if isinstance(audit, dict):
            audit["version"] = VERSION
            audit["schema"] = V409_SCHEMA
            audit["stage_policy_schema"] = V409_SCHEMA
            audit["note"] = "v409: v408 후보 판독 결론을 실제 메인봇 명령에 연결. 조건 수치는 변경하지 않음."
            save_json(S1_BLOCK_AUDIT, audit)
            if isinstance(stats, dict):
                stats.update({k:v for k,v in audit.items() if k in ("decision_top","decision_by_strategy","aux_ready_top","aux_missing_top","samples","reason_top","missing_info_top","strategy_missing_info","price_reaction_sources")})
    except Exception as exc:
        append_error(ERROR, "v409_audit_relabel", exc)
    try:
        cmap = load_json(CONDITION_MAP_FILE, {}) or {}
        if isinstance(cmap, dict):
            cmap["version"] = VERSION
            cmap["schema"] = V409_SCHEMA
            cmap["summary"] = "전략별 S3/S2/S1 구조 유지 + 가격반응 보정 + 후보 판독 결론 실제 연결. 조건 수치는 변경하지 않음."
            cmap["review_decision_policy"] = ["새 S단계가 아님", "아까운 후보=정보/비용은 양호하나 가격반응만 조금 부족", "재확인 후보=정보 일부 또는 조건 일부 재확인 필요", "안 산 게 맞음=스프레드/미끄러짐/체결/매도벽/단기역행 부담"]
            save_json(CONDITION_MAP_FILE, cmap)
    except Exception as exc:
        append_error(ERROR, "v409_condition_map_relabel", exc)
    try:
        h = load_json(HANDOFF, {}) or {}
        h.update({"version": VERSION, "stage_policy_schema": V409_SCHEMA, "note":"v409: 후보 판독 결론 실제 연결. S1/S2/S3 및 조건 수치 변경 없음."})
        save_json(HANDOFF, h)
    except Exception as exc:
        append_error(ERROR, "v409_handoff_relabel", exc)
    try:
        sm = load_json(SUMMARY, {}) or {}
        sm.update({"version": VERSION, "main_version": MAIN_VERSION, "stage_policy_schema": V409_SCHEMA, "lifecycle_schema": V409_SCHEMA, "condition_map_version": VERSION, "note":"v409: v408 판독판 실제 연결. 조건 수치 변경 없음."})
        save_json(SUMMARY, sm)
    except Exception as exc:
        append_error(ERROR, "v409_summary_relabel", exc)
    if isinstance(stats, dict):
        stats["schema"] = V409_SCHEMA
        stats["version"] = VERSION
    return stats


def run_once() -> Dict[str, Any]:  # type: ignore[override]
    base = _v409_base_run_once()
    stats = {}
    try:
        stats = (load_json(S1_BLOCK_AUDIT, {}) or {})
    except Exception:
        stats = {}
    stats = _v409_relabel_outputs(stats if isinstance(stats, dict) else {})
    try:
        c = stats.get("stage_counts", {}) if isinstance(stats, dict) else {}
        write_status("running", evaluated=int((load_json(SUMMARY, {}) or {}).get("evaluated") or 0), s_count=sum(int(v) for v in c.values()) if isinstance(c, dict) else 0, paper_latest_count=int(stats.get("latest_count", 0) if isinstance(stats, dict) else 0), s1_count=c.get("S1",0) if isinstance(c, dict) else 0, s2_count=c.get("S2",0) if isinstance(c, dict) else 0, s3_count=c.get("S3",0) if isinstance(c, dict) else 0, lifecycle_schema=V409_SCHEMA, stage_policy_schema=V409_SCHEMA, condition_map_version=VERSION, s1_block_audit=stats, last_sec=fnum((base or {}).get("last_sec"), default=0.0))
    except Exception:
        pass
    out = dict(base or {})
    out.update({"stage_policy_schema": V409_SCHEMA, "condition_map_version": VERSION, "lifecycle_stats": stats})
    return out


if __name__ == "__main__":
    main()
