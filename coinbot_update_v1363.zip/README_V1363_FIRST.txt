v1363 applies main/paper only and keeps old-base strategy v1.099 running. Main seeds old-base bridge status for current Guard verification. No trading rule changes. Auto-buy OFF.
