v1264는 사용자 승인 Paper 표본 수량 변경입니다. v1263 적용·정리 증명 후 적용하십시오. 전체 OPEN 50, generation 신규 5, 기존 global score 순서 유지, 자동매수 OFF.
