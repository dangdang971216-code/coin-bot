import importlib.util
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
spec=importlib.util.spec_from_file_location('paper_v1264',ROOT/'paper_bot_v1.078.py')
mod=importlib.util.module_from_spec(spec); spec.loader.exec_module(mod)
assert mod.VERSION=='paper_bot_v1.078'
assert mod.V1206_TOTAL_CAP==50
assert mod.V1208_CYCLE_NEW_OPEN_CAP==5
picked=[]
for i in range(10):
    picked.append((f'p{i}',{
        'ticker':f'T{i}','event_id':f'e{i}','global_entry_score_v1212':100-i,
        'risk_reward_ratio':2.0,'target_room_pct':5.0,'current_price':100.0,
        'pipeline_cycle_id':'cycle-a','candidate_commit_id':'commit-a',
    }))
selected,evidence=mod.rank_executable_candidates_for_open(picked,{})
assert len(selected)==5,len(selected)
assert [row['ticker'] for _,row in selected]==['T0','T1','T2','T3','T4']
assert evidence['total_cap']==50 and evidence['cycle_new_open_cap']==5
assert evidence['selected_total']==5
# Existing OPEN capacity remains the stricter remaining constraint.
open_pos={f'o{i}':{'ticker':f'O{i}'} for i in range(48)}
selected2,evidence2=mod.rank_executable_candidates_for_open(picked,open_pos)
assert len(selected2)==2
assert evidence2['cycle_slots_available']==2
assert mod.V1264_OPEN_CAPACITY_CONTRACT['auto_buy'] is False
print('PASS v1264 open capacity')
