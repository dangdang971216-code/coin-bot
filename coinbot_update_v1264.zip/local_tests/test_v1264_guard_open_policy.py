import importlib.util, json, tempfile
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
spec=importlib.util.spec_from_file_location('guard_v1264',ROOT/'backga_guard_bot_v2_5_242.py')
mod=importlib.util.module_from_spec(spec); spec.loader.exec_module(mod)
with tempfile.TemporaryDirectory() as td:
    base=Path(td); mod.BOT_DIR=base
    (base/'paper_active_contract_snapshot_v1208.json').write_text(json.dumps({'auto_buy':False,'entry':{'total_cap':50,'cycle_new_open_cap':5,'entry_mode':'Strategy exact S1 + Paper integrity + ranked capacity pacing'}}))
    (base/'paper_bot_status.json').write_text(json.dumps({'version':'paper_bot_v1.078','auto_buy':False}))
    text=mod.gopen_policy_v1264_text()
    assert '상태: DONE' in text,text
    assert '전체 OPEN 최대: 50' in text
    assert '신규 최대: 5' in text
print('PASS v1264 guard policy')
