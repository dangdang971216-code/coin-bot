from pathlib import Path
import json

base = Path(__file__).resolve().parents[1]
bundle = json.loads((base / 'DEPLOY_BUNDLE.json').read_text(encoding='utf-8'))
assert bundle['release'] == 'v1264'
assert bundle['server_status'] == 'CHECK_PENDING_APPLY'
assert bundle['auto_buy'] is False
assert bundle['open_capacity_before'] == {'total': 10, 'generation_new': 2}
assert bundle['open_capacity_after'] == {'total': 50, 'generation_new': 5}
assert bundle['runtime_files']['main'] == 'coinbot_main_v2_13_1165.py'
assert bundle['runtime_files']['paper'] == 'paper_bot_v1.078.py'
assert bundle['runtime_files']['review'] == 'review_worker_v1.039.py'
assert bundle['runtime_files']['strategy'] == 'strategy_worker_v1.062.py'
assert bundle['runtime_files']['guard'] == 'backga_guard_bot_v2_5_242.py'
for rel in bundle['runtime_files'].values():
    assert (base / rel).is_file(), rel
for rel in bundle['support_files']:
    assert (base / rel).is_file(), rel
for forbidden in ('paper_bot_open.json','paper_bot_closed.jsonl','paper_trade_log.jsonl','paper_decision_state.jsonl','change_verify_ledger.jsonl','issue_ledger.jsonl'):
    assert not (base / forbidden).exists(), forbidden
paper = (base / bundle['runtime_files']['paper']).read_text(encoding='utf-8')
guard = (base / bundle['runtime_files']['guard']).read_text(encoding='utf-8')
main = (base / bundle['runtime_files']['main']).read_text(encoding='utf-8')
assert 'paper_bot_v1.078' in paper
assert 'V1206_TOTAL_CAP = 50' in paper
assert 'V1208_CYCLE_NEW_OPEN_CAP = 5' in paper
assert 'V1264_OPEN_CAPACITY_CONTRACT' in paper
assert 'TOTAL50_GLOBAL_SCORE_CYCLE5_AUTO_BUY_OFF' in guard
assert '/gopen_policy_v1264' in guard
assert '수익형 v2.13.1165' in main
print('PASS v1264 bundle contract')
