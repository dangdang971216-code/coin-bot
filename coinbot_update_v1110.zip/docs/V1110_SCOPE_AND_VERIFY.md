# v1110 Strategy 단일 인스턴스 runtime 수술

## 서버에서 확인된 원인
v1109 적용 후 Strategy service log/err에 PID 1542714와 3825996이 동시에 열린 증거가 남았다.
기존 worker 적용기는 재시작 전 direct PID를 정리하면서 당시 systemd MainPID는 보호해 건너뛰었다. 그 뒤 새 process가 시작되면 구 MainPID가 잔존할 수 있었다.

## 수정
- Strategy 적용을 `systemctl stop → matching PID 0 증명 → survivor TERM/KILL → systemctl start` transaction으로 변경.
- 적용 완료 조건을 `matching PID 1개 = systemd MainPID = status PID = singleton lock PID`로 강화.
- Strategy process 자체에 non-blocking `flock` singleton을 추가해 배포 외 경로의 중복 실행도 차단.
- worker unit에 `KillMode=control-group`, `TimeoutStopSec=15`, `SendSIGKILL=yes` 적용.
- service log/err는 비장부로 유지하고, 중복 프로세스는 `RUNTIME:strategy / WORKER_MULTI_INSTANCE` 한 그룹으로 표시.
- 같은 root에서 생긴 MULTI_WRITER 증상은 한 그룹으로 압축.

## 변경 금지 영역
품질 threshold, trigger, invalid, target, actual-entry RR, slippage, OPEN 30/cycle 3, 청산계약, Paper/성과 원장은 변경하지 않았다. 자동매수 OFF 유지.

## 서버 검수
1. Guard `/gupgrade_bundle` 단독
2. 적용 완료 후 Guard `/gops_refresh`
3. Main `/flow_map` + `/errorlog`

## DONE 기대
- Main v2.13.1094
- Guard v2.5.163
- Strategy v1.003
- Strategy matching PID 1개
- systemd MainPID = Strategy status PID = singleton lock PID
- WORKER_MULTI_INSTANCE 0
- service log 기반 MULTI_WRITER 0
- runtime mismatch 0
- 전략·청산 계약 변경 0 / 자동매수 OFF
