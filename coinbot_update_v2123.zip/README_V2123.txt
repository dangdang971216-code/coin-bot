v2123: 0전 초기화 최대 20건 batch, 완료 즉시 current epoch 0전 성과 봉인, Main stale epoch 차단, 15일 core/Shadow 보관정리 및 /gclean_disk 내부 20초 대기 제거. 후보품질·전략·실제 진입/청산 미변경. LOCAL DONE / SERVER CHECK / 자동매수 OFF.
