v1316: Paper core restore. Apply with /gupgrade_bundle. No strategy/RR/exit/autobuy changes.
