# v1091 운영 지도 완전고정 마감

## 실제 원인
1. Main 지도 reader가 각 명령마다 `ops_map_snapshot.json`을 다시 읽어 한 배치 안에서 snapshot이 섞일 수 있었다.
2. Guard 지도는 active 파일 hash만 맞으면 실행 중 Main heartbeat의 PID·버전과 다른 상태도 NORMAL로 처리할 수 있었다.
3. AST cache 준비 증거가 수동 `/gops_refresh` snapshot에만 붙어 periodic refresh가 덮어쓰면 `None`으로 사라졌다.
4. RSS 최고점과 가장 가까운 phase를 원인처럼 표시했고, 짧은 표본을 시간당 추세로 과장했다.
5. 프로세스가 재시작돼 PID가 바뀌어도 이전 PID 자원 표본이 이어질 수 있었다.

## 새 본선
- Guard writer 1개 → `ops_map_snapshot.json` 1개.
- Main `begin_command_snapshot()`이 운영지도 snapshot까지 한 번만 봉인.
- 같은 다중명령/TXT의 지도 9개는 봉인된 동일 snapshot ID·digest만 읽음.
- Main runtime 증거: systemd MainPID + heartbeat PID/version + active source identity + process start/source mtime.
- AST collector는 모든 snapshot에 실제 reuse 목록, miss component, 현재 cache 준비 14/14, 다음 cycle 기대상태를 기록.
- 자원 표본은 PID별로 분리하고 5분 미만은 시간당 추세를 계산하지 않음.
- RSS phase는 `nearest_sampled_phase`이며 인과관계가 아님을 명시.

## 변경하지 않은 영역
Paper, Strategy, Risk, Review, scanner/candle/orderflow 등 worker, 진입·청산·OPEN 한도, OPEN/CLOSED/decision/exact 원장, 자동매수 OFF.

## 서버 DONE 기준
- `/gops_refresh`: writer 1, snapshot 1, cache 준비 14/14, Main runtime PID/version 일치.
- 한 번의 메인 다중명령 TXT에서 모든 지도 snapshot ID·digest 동일.
- `/code_map`: Main source identity와 runtime status identity 일치, source-after-start False.
- 신규 실행 오류 0, exact 0/0/0, 자동매수 OFF.
