Coinbot v1482
Recheck-first candidate lifecycle.
S1 = currently executable.
S2 = current-cycle hold and next-cycle recheck.
S3 = observation-only.
Missing/stale information creates producer refresh requests.
No S2 direct OPEN. Numeric thresholds unchanged. Auto-buy OFF.
Build v1482_RECHECK_FIRST_RESTORE_CANDIDATE_SAMPLE_KEEP_OPEN_SAFETY_AUTOBUY_OFF_2026-07-12
