v1601: v1427 spine S1->Paper handoff reconnect. Contract missing is CHECK/re-request. Auto-buy OFF. No trading thresholds changed.
