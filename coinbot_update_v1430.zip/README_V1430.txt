coinbot update v1430
- Fixes Paper exit shadow contract writer single path.
- Active shadow files: paper_exit_shadow_contract_status.json and paper_exit_shadow_contract_ledger.jsonl.
- Main only reads Paper-owned status; no Main recomputation.
- No candidate flow, real exit contract, OPEN/CLOSED/decision/exact rewrite, or auto-buy change.
