v1444_PUBLIC_COMMAND_RESTORE_BOTTLENECK_MAP_NO_TRADING_RULE_CHANGE

목적:
- /pstatus, /candidate_summary 공개 명령 복구
- 오래 걸린 사유를 /version_score 하단과 /bottleneck_map에서 바로 표시
- cycle 원문을 뒤지기 전에 병목구간을 한 화면에서 확인

변경 없음:
- Gate/TTL/RR/trigger/invalid/target/청산/S1/S2/S3/OPEN/자동매수 변경 없음
- 자동매수 OFF

검수:
/gupgrade_bundle
/pstatus
/candidate_summary
/bottleneck_map
/entry_latency_core
/shadow_board
/version_score
/errorlog
