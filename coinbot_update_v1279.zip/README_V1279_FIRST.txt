v1279: fix v1278 row hard ceiling. Keep v977 restored active; dynamic shadow compact only. Auto-buy OFF.
