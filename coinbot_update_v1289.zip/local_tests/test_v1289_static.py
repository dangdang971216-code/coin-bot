from pathlib import Path
root = Path(__file__).resolve().parents[1]
assert "v1289_version_score_readable_cause_board" in (root/"coinbot_main_v2_13_1169.py").read_text()
assert "version_score_detail_v1289" in (root/"paper_bot_v1.086.py").read_text()
assert "gledger_v1289" in (root/"backga_guard_bot_v2_5_267.py").read_text()
