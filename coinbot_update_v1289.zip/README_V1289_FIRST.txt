v1289: /version_score readability + source-fill board. Trading rules unchanged. Auto-buy OFF. Apply with /gupgrade_bundle first.
