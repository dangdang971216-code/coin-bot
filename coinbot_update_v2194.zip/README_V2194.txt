코인봇 v2194 Paper 알림-성과 연결 및 버전스코어 원형 복원

- Paper 알림을 만든 exact OPEN/CLOSED가 같은 epoch 성과에 반영
- 기존에 도착한 post-reset 알림 행도 기존 exact event 원장으로 연결 복구
- 성과 0전 초기화 다시 실행하지 않음
- /version_score 오늘/3h/6h/12h/24h/전체, OPEN/CLOSED TOP, PASS/CHECK 이모지 복원
- 상승예측·구조·진입·청산·비용 수치 변경 없음
- 자동매수 OFF

LOCAL PASS / SERVER CHECK
