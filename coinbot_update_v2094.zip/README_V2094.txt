코인봇 v2094 · 메인봇 명령별 출력 최종 통일

목적
- 모든 메인봇 명령은 자기 명령을 1회만 실행한다.
- Telegram은 그 명령 결과 body에서 필요한 내용만 보여준다.
- TXT는 같은 body 전체와 분석용 상세를 자동 첨부한다.
- Telegram이 별도 snapshot을 다시 읽어 TXT와 값이 달라지는 경로를 없앤다.

/version_score 핵심판
- reset 이후 새 성과구간의 오늘·3h·6h·24h·전체 CLOSED 성과
- 현재 OPEN 평가합·수익수·손실수
- 현재 수익 TOP 3
- 현재 손실 TOP 3
- 오늘 CLOSED 수익 TOP 3
- 오늘 CLOSED 손실 TOP 3
- Telegram과 TXT 핵심 TOP의 값과 순서가 동일
- TXT는 같은 봉인본에서 TOP 10, 수익반납, 원천 snapshot을 확장 표시

모든 명령
- 현재 등록된 Main 명령마다 개별 output profile 보유
- 중요한 명령은 명령별 줄 수와 우선 섹션을 따로 설정
- 나머지 명령도 안전 기본 profile로 compact Telegram + full TXT 적용
- compact 화면은 이미 계산된 command body만 사용하며 별도 reader 재계산 없음

변경하지 않음
- Strategy/Paper/Review/Guard 실행경로
- 후보 수·S1/S2/S3·rank
- trigger·invalid·target
- 기존 OPEN/CLOSED/decision/exact 원장
- 진입·청산·수익보호
- 자동매수 OFF

판정
- 로컬 py_compile·AST·synthetic import PASS
- 74개 public command와 74개 output profile 연결 확인
- /version_score 4개 TOP 동일 body 추출 검수 PASS
- 서버에서 /grelease_verify와 /version_score 실제 출력 확인 전 CHECK
