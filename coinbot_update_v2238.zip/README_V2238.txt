적용 직후 Review는 기존 4.8GB canonical outcome 원장을 한 번 읽어 파생 cache v2를 복구합니다.
이는 누락된 진입 당시 점수/상태를 되찾기 위한 1회 migration이며, canonical 원장 삭제/재작성은 없습니다.
완료 후에는 기존처럼 append byte 증분만 읽습니다. 새 Shadow/worker/명령/전략 변경은 없습니다.
