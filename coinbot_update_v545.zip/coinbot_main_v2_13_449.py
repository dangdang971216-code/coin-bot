#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""수익형_v2.13.352.py

Clean main bot renewal phase v366.
- 메인봇은 무거운 전체시장 스캔/정밀/전략판정을 직접 하지 않는다.
- scanner/feature/orderflow/strategy/review worker가 만든 캐시만 읽는다.
- 실제 paper OPEN은 strategy worker의 S급 후보만 허용한다.
- A/B/C 실시간 후보와 무거운 가상복기는 메인봇 경로에서 제거한다.
"""
from __future__ import annotations
import json, os, sys, time, traceback, re
from pathlib import Path
from typing import Any, Dict, List, Optional, Tuple
import threading
from collections import Counter

try:
    from telegram import Bot, BotCommand
    from telegram.ext import Updater, CommandHandler, MessageHandler, Filters
except Exception:
    Bot = None; BotCommand = None; Updater = None; CommandHandler = None; MessageHandler = None; Filters = None

BOT_VERSION = "수익형 v2.13.389"
BASE_DIR=Path(__file__).resolve().parent
TELEGRAM_TOKEN=os.getenv("TELEGRAM_TOKEN","").strip()
CHAT_ID=os.getenv("CHAT_ID","").strip()
WORKERS={
    "scanner": {"file":"scanner_worker_v0.3.py", "status":"clean_scanner_status.json"},
    "candle": {"file":"candle_worker_v0.2.py", "status":"clean_candle_status.json"},
    "market": {"file":"market_regime_worker_v0.1.py", "status":"clean_market_regime_status.json"},
    "feature": {"file":"feature_worker_v0.2.py", "status":"clean_feature_status.json"},
    "orderflow": {"file":"orderflow_worker_v0.8.py", "status":"clean_orderflow_status.json"},
    "risk": {"file":"risk_worker_v0.2.py", "status":"clean_risk_status.json"},
    "strategy": {"file":"strategy_worker_v0.52.py", "status":"clean_strategy_worker_status.json"},
    "target_router": {"file":"target_router_worker_v0.8.py", "status":"clean_target_router_status.json"},
    "review": {"file":"review_worker_v0.11.py", "status":"clean_review_worker_status.json"},
}
FILES={
    "brain_status":BASE_DIR/"clean_brain_status.json",
    "brain_runtime":BASE_DIR/"clean_brain_runtime.log",
    "brain_error":BASE_DIR/"clean_brain_error.log",
    "resource":BASE_DIR/"clean_resource_status.json",
    "scanner_market":BASE_DIR/"clean_scanner_market_cache.json",
    "feature":BASE_DIR/"clean_feature_cache.json",
    "orderflow":BASE_DIR/"clean_orderflow_summary_cache.json",
    "strategy_summary":BASE_DIR/"clean_strategy_s_summary.json",
    "candle":BASE_DIR/"clean_candle_cache.json",
    "market_regime":BASE_DIR/"clean_market_regime_cache.json",
    "risk":BASE_DIR/"clean_risk_filter_cache.json",
    "strategy_reject":BASE_DIR/"clean_strategy_s_reject_summary.json",
    "review":BASE_DIR/"clean_review_summary.json",
    "paper_status":BASE_DIR/"paper_bot_status.json",
    "paper_open":BASE_DIR/"paper_bot_open.json",
    "paper_score":BASE_DIR/"paper_bot_score_cache.json",
    "paper_latest":BASE_DIR/"paper_candidates_latest.jsonl",
    "paper_archive":BASE_DIR/"paper_candidates.jsonl",
    "paper_handoff":BASE_DIR/"clean_strategy_paper_handoff_status.json",
    "paperbot_handoff":BASE_DIR/"paper_bot_candidate_handoff_status.json",
    "candidate_handoff_trace":BASE_DIR/"paper_bot_candidate_handoff_trace.json",
    "paper_closed":BASE_DIR/"paper_bot_closed.jsonl",
    "score_anchor":BASE_DIR/"paper_bot_current_score_anchor.json",
    "target_router":BASE_DIR/"clean_target_router_queue.json",
    "ws_status":BASE_DIR/"clean_ws_sidecar_status.json",
    "micro_status":BASE_DIR/"clean_bithumb_micro_status.json",
    "micro_targets":BASE_DIR/"clean_micro_targets.json",
}
START_TS=time.time()

def now_ts()->float: return time.time()
def now_text(ts:Optional[float]=None)->str: return time.strftime("%Y-%m-%d %H:%M:%S", time.localtime(ts or now_ts()))
def fnum(v:Any, *more:Any, default:float=0.0)->float:
    """안전 숫자 변환.

    기존 호출(fnum(x, -1.0))은 두 번째 인자를 fallback 값처럼 쓰고,
    v345 preview 쪽 호출(fnum(a,b,c, default=0))은 앞에서부터 숫자값을 고른다.
    """
    for val in (v,) + tuple(more):
        try:
            if val is None or val == "":
                continue
            return float(str(val).replace(",", ""))
        except Exception:
            continue
    return default

def norm_ticker(v: Any) -> str:
    """메인봇 preview 전용 안전 티커 정규화.

    v345에서 paper 추적 로직이 norm_ticker를 참조했지만 메인봇 파일에는
    정의가 없어 /preview NameError가 났다. 여기서는 거래소 접두사/마켓 접미사만
    정리하고, 판단 로직에는 관여하지 않는다.
    """
    try:
        s = str(v or "").strip().upper()
        if not s:
            return ""
        if ":" in s:
            s = s.split(":", 1)[1]
        for suf in ("_KRW", "-KRW", "/KRW", "KRW"):
            if s.endswith(suf):
                s = s[:-len(suf)]
                break
        s = s.replace("_", "").replace("-", "").replace("/", "")
        return s
    except Exception:
        return ""

def load_json(path:Path, default:Any=None)->Any:
    try:
        if not path.exists(): return default
        return json.loads(path.read_text(encoding="utf-8", errors="ignore"))
    except Exception: return default

def save_json(path:Path,obj:Any)->None:
    path.parent.mkdir(parents=True,exist_ok=True)
    tmp=path.with_suffix(path.suffix+".tmp")
    tmp.write_text(json.dumps(obj,ensure_ascii=False,separators=(",",":"),default=str),encoding="utf-8")
    os.replace(tmp,path)

def read_jsonl(path:Path,max_lines:int=1000)->List[Dict[str,Any]]:
    """JSONL tail reader for Telegram status commands.

    Older code used path.read_text().splitlines(), which read the entire paper
    CLOSED ledger even when only recent rows were needed. That made /health,
    /pstatus and /version_score block for minutes after the ledger grew.
    This keeps default commands cache/tail-only: read only the end of the file,
    then parse at most max_lines rows.
    """
    if not path.exists(): return []
    try:
        max_lines = max(1, int(max_lines or 1000))
    except Exception:
        max_lines = 1000
    try:
        size = path.stat().st_size
        # Enough for normal JSONL status rows, bounded so a huge ledger never
        # blocks the Telegram command loop. Larger requests get a larger tail,
        # but are still capped for safety.
        tail_bytes = min(size, max(256_000, min(8_000_000, max_lines * 4096)))
        with path.open('rb') as f:
            if size > tail_bytes:
                f.seek(-tail_bytes, os.SEEK_END)
                f.readline()  # drop possible partial first line
            data = f.read().decode('utf-8', errors='ignore')
        lines = data.splitlines()
        if len(lines) > max_lines:
            lines = lines[-max_lines:]
        out=[]
        for ln in lines:
            try:
                if ln.strip():
                    o=json.loads(ln)
                    if isinstance(o,dict): out.append(o)
            except Exception:
                pass
        return out
    except Exception:
        return []

def line_count(path: Path, max_bytes: int = 2_000_000) -> int:
    try:
        if not path.exists(): return 0
        if path.stat().st_size > max_bytes:
            # 큰 archive는 기본 명령에서 전체를 세지 않는다. tail이 아니라 대략 표시만 한다.
            return -1
        return len(path.read_text(encoding="utf-8", errors="ignore").splitlines())
    except Exception: return 0

def log_runtime(msg:str)->None:
    try:
        with FILES["brain_runtime"].open("a",encoding="utf-8") as f: f.write(f"[{now_text()}] {msg}\n")
    except Exception: pass

def log_error(where:str,exc:BaseException)->None:
    try:
        with FILES["brain_error"].open("a",encoding="utf-8") as f:
            f.write(f"[{now_text()}] {where}: {exc.__class__.__name__}: {exc}\n{traceback.format_exc()[-1500:]}\n")
    except Exception: pass

def age(path:Path)->float:
    try: return max(0.0, now_ts()-path.stat().st_mtime)
    except Exception: return 999999.0

def pid_alive(pid:int)->bool:
    if pid<=0: return False
    try: os.kill(pid,0); return True
    except Exception: return False

def worker_status(name:str)->Dict[str,Any]:
    spec=WORKERS[name]; path=BASE_DIR/spec["status"]
    obj=load_json(path,{}) or {}; pid=int(fnum(obj.get("pid"),default=0)); alive=pid_alive(pid)
    a=age(path)
    state=str(obj.get("state") or "missing") if obj else "missing"
    return {"name":name,"state":state,"pid":pid,"alive":alive,"age":round(a,1),"version":obj.get("version","-"),"last_sec":obj.get("last_sec","-"),"row_count":obj.get("row_count",obj.get("evaluated",obj.get("closed_recent","-"))),"raw":obj}

def ensure_workers()->None:
    # v329: worker 실행/재시작은 가드봇 systemd 전담. 메인봇은 절대 직접 worker를 켜지 않는다.
    return

def resource_snapshot()->Dict[str,Any]:
    try:
        import shutil
        total, used, free = shutil.disk_usage(BASE_DIR)
        mem_total=mem_free=0
        try:
            for ln in Path('/proc/meminfo').read_text().splitlines():
                if ln.startswith('MemTotal:'): mem_total=int(ln.split()[1])*1024
                if ln.startswith('MemAvailable:'): mem_free=int(ln.split()[1])*1024
        except Exception: pass
        load=os.getloadavg() if hasattr(os,'getloadavg') else (0,0,0)
        return {"disk_free_gb":round(free/1024**3,2),"disk_used_pct":round(used/total*100,1),"mem_free_mb":round(mem_free/1024**2,1) if mem_free else 0,"mem_used_pct":round((1-mem_free/mem_total)*100,1) if mem_total and mem_free else 0,"load":[round(x,2) for x in load]}
    except Exception as exc:
        log_error("resource_snapshot",exc); return {}

def update_brain_status(state:str="running")->None:
    """메인봇 heartbeat/status만 저장한다.
    v329 기준 worker 실행/재시작은 가드봇 systemd 전담이다.
    """
    workers={k:worker_status(k) for k in WORKERS}
    save_json(FILES["brain_status"],{
        "version":BOT_VERSION,
        "state":state,
        "telegram_state":state,
        "pid":os.getpid(),
        "updated_ts":now_ts(),
        "updated_text":now_text(),
        "uptime_sec":round(now_ts()-START_TS,1),
        "workers":workers,
        "resource":resource_snapshot(),
        "note":"v330 main is cache-only; worker lifecycle is guard/systemd only",
    })

def worker_ok(st:Dict[str,Any])->str:
    state=str(st.get('state') or '').lower()
    a=fnum(st.get('age'), default=999999)
    if state in {'error','failed','stopped','missing','dead'}:
        return '❌'
    if state in {'running','ready','ok','initializing'}:
        return '✅' if a < 45 else '⚠️'
    return '❔'

def line_worker(st:Dict[str,Any], detail:bool=False)->str:
    icon=worker_ok(st)
    base=f"- {icon} {st['name']}: {st.get('version','-')} / {st.get('state')} / age {st.get('age')}s"
    if detail:
        base += f" / rows {st.get('row_count')} / sec {st.get('last_sec')}"
    return base

def router_flow_summary(router: Dict[str, Any]) -> str:
    """v337: target_router를 개수 제한표가 아니라 전체/우선/순환/대기/버림으로 보여준다."""
    if not isinstance(router, dict) or not router:
        return "- 정보배차: 상태 없음"
    return (
        f"- 정보배차: 전체 {router.get('queue_count','-')} / 최우선 {router.get('priority_protected_count','-')} "
        f"/ 이번내보냄 {router.get('active_target_count', router.get('target_count','-'))} "
        f"/ 순환대기 {router.get('rotation_wait_count', router.get('backlog_count','-'))} "
        f"/ 버림 {router.get('dropped_count',0)}"
    )

def router_flow_detail(router: Dict[str, Any]) -> List[str]:
    if not isinstance(router, dict) or not router:
        return ["- 정보배차 상태 없음"]
    return [
        router_flow_summary(router),
        f"- 채워야할 정보: WS필요 {router.get('need_ws','-')} / micro필요 {router.get('need_micro','-')} / fresh회복 {router.get('fresh_recovered','-')}",
        f"- 순환상태: rotation pool {router.get('rotation_pool_count','-')} / 이번순환 {router.get('rotation_export_count','-')} / 다음커서 {router.get('next_rotation_cursor','-')}",
        f"- 보호슬롯: 전략요청 {router.get('strategy_req_total_count','-')} / 강제보호 {router.get('strategy_req_forced_active_count','-')} / micro요청 {router.get('strategy_req_micro_target_count','-')}",
    ]


def health_text()->str:
    # v340: health는 기본 상태판이므로 v338 형식 유지. worker 시작/재시작/직접계산 금지.
    update_brain_status('running')
    workers=[worker_status(k) for k in WORKERS]
    res=resource_snapshot()
    paper=load_json(FILES['paper_status'],{}) or {}
    ws=load_json(FILES['ws_status'],{}) or {}
    micro=load_json(FILES['micro_status'],{}) or {}
    strat=load_json(FILES['strategy_summary'],{}) or {}
    reject=load_json(FILES['strategy_reject'],{}) or {}
    oflow=load_json(FILES['orderflow'],{}) or {}
    router=load_json(FILES['target_router'],{}) or {}
    good=sum(1 for w in workers if worker_ok(w)=='✅')
    warn=sum(1 for w in workers if worker_ok(w)=='⚠️')
    bad=sum(1 for w in workers if worker_ok(w)=='❌')
    evaluated = int(fnum(reject.get('evaluated') or strat.get('evaluated') or 0, 0))
    quote_ready = int(fnum(strat.get('quote_ready_count') or reject.get('quote_ready_count') or oflow.get('quote_fresh') or 0, 0))
    micro_ready = int(fnum(strat.get('micro_ready_count') or reject.get('micro_ready_count') or oflow.get('fresh_micro') or 0, 0))
    full_ready = int(fnum(strat.get('full_info_ready_count') or reject.get('full_info_ready_count') or oflow.get('info_ready') or 0, 0))
    sent_count = router.get('export_count', router.get('active_target_count', router.get('target_count','-')))
    lines=[
        "🧭 건강상태 /health",
        f"✅ 메인봇 {BOT_VERSION} / clean worker hub v369 / uptime {int(now_ts()-START_TS)}s",
        "",
        "[한눈요약 · 기존 health 값 유지]",
        f"✅ 전체 {evaluated or '-'}개 평가 / 시세 {quote_ready}/{evaluated or '-'} / 호가·체결 {micro_ready}/{evaluated or '-'} / 둘다 {full_ready}/{evaluated or '-'}",
        f"✅ 배차 전체 {router.get('queue_count','-')}개 → 이번내보냄 {sent_count}개 / 순환대기 {router.get('rotation_wait_count','-')}개 / 버림 {router.get('dropped_count',0)}개",
        f"✅ worker 정상 {good}개 / 주의 {warn}개 / 문제 {bad}개",
        f"✅ 오류 없음 기준은 /errorlog / 메모리 {res.get('mem_used_pct','-')}% / load {res.get('load','-')}",
        "",
        f"- worker: ✅ {good} / ⚠️ {warn} / ❌ {bad}",
        f"- paper: {paper.get('version','-')} / OPEN {paper.get('open_count', paper.get('open_total','-'))} / age {age(FILES['paper_status']):.1f}s",
        f"- WS: age {age(FILES['ws_status']):.1f}s / cache {ws.get('cache', ws.get('cache_count','-'))} / fresh {ws.get('fresh','-')}",
        f"- micro: age {age(FILES['micro_status']):.1f}s / targets {micro.get('targets','-')} / batch {micro.get('poll_batch','-')} / cached {micro.get('cached','-')} / fresh {micro.get('fresh','-')}",
        f"- orderflow: quote {oflow.get('quote_fresh','-')} / micro {oflow.get('fresh_micro','-')} / ready {oflow.get('info_ready','-')} / active {oflow.get('active_count','-')}",
        router_flow_summary(router),
        f"- S 후보 {strat.get('s_count',0)} / 평가 {reject.get('evaluated','-')} / 탈락 {reject.get('reject_count','-')}",
        f"- 디스크 {res.get('disk_used_pct','-')}% / 남음 {res.get('disk_free_gb','-')}GB / 메모리 {res.get('mem_used_pct','-')}% / load {res.get('load','-')}",
        "",
        "[worker 요약]",
    ]
    lines += [line_worker(w, detail=False) for w in workers]
    lines += ["", "[worker 품질 · v482]"]
    try:
        lines += _v482_worker_quality_lines({k: worker_status(k) for k in WORKERS})
    except Exception as exc:
        lines.append(f"- ⚠️ worker 품질 요약 생성 실패: {exc.__class__.__name__}")
    lines += ["", "[원칙] 메인봇은 worker cache만 읽음. worker 실행/재시작은 가드봇 systemd 전담. v482부터 running/age뿐 아니라 data-quality도 같이 봄."]
    return "\n".join(lines)

def _worker_metric_int(st: Dict[str, Any], *keys: str) -> Any:
    raw = st.get('raw') if isinstance(st.get('raw'), dict) else {}
    for k in keys:
        v = raw.get(k)
        if v not in (None, '', '-'):
            return v
    return '-'


def _v482_worker_quality_lines(workers: Dict[str, Dict[str, Any]]) -> List[str]:
    """v482: worker가 살아있는지만 보던 상태판 착시를 줄인다.

    메인봇은 여전히 cache/status만 읽는다. 여기서는 worker가 이미 저장한
    품질 숫자만 요약한다: hot-rank 생성, 1m/3m 실제 source, hot target 배차,
    strategy canonical source coverage. 값이 없으면 계산 fallback을 하지 않고 '-'로 표시한다.
    """
    def raw(name: str) -> Dict[str, Any]:
        st = workers.get(name, {}) if isinstance(workers, dict) else {}
        return st.get('raw') if isinstance(st.get('raw'), dict) else {}
    scanner = raw('scanner')
    feature = raw('feature')
    target = raw('target_router')
    strategy = raw('strategy')
    router = load_json(FILES.get('target_router', BASE_DIR/'clean_target_router_queue.json'), {}) or {}
    hot = load_json(BASE_DIR/'clean_scanner_hot_rank_cache.json', {}) or {}
    feat_cache = load_json(FILES.get('feature', BASE_DIR/'clean_feature_cache.json'), {}) or {}
    lines: List[str] = []
    # Scanner: process alive != hot-rank usable. Show both known count and hot cache age.
    lines.append(
        f"- scanner 품질: hot1m {scanner.get('hot_known_1m', hot.get('known_1m','-'))} / "
        f"hot3m {scanner.get('hot_known_3m', hot.get('known_3m','-'))} / "
        f"hot cache age {age(BASE_DIR/'clean_scanner_hot_rank_cache.json'):.1f}s"
    )
    # Feature: show real short-flow source coverage. v481 removed fake 24h/1440 fallback.
    lines.append(
        f"- feature 품질: 1m known {feature.get('known_1m', feat_cache.get('known_1m','-'))} / "
        f"3m known {feature.get('known_3m', feat_cache.get('known_3m','-'))} / "
        f"1m missing {feature.get('missing_1m', feat_cache.get('missing_1m','-'))} / "
        f"3m missing {feature.get('missing_3m', feat_cache.get('missing_3m','-'))} / "
        f"hot 사용 {feature.get('hot_used', feat_cache.get('hot_used','-'))}"
    )
    # Router: show whether hot-rank actually entered active collection targets.
    lines.append(
        f"- target 품질: hot 요청 {target.get('hot_rank_req_count', router.get('hot_rank_req_count','-'))} / "
        f"hot active {target.get('hot_rank_active_count', router.get('hot_rank_active_count','-'))} / "
        f"recheck 요청 {target.get('recheck_req_count', router.get('recheck_req_count','-'))} / "
        f"recheck micro {target.get('recheck_micro_target_count', router.get('recheck_micro_target_count','-'))}"
    )
    # Strategy: show current canonical source schema where available.
    lines.append(
        f"- strategy 품질: canonical {strategy.get('canonical_metric_schema', strategy.get('stage_policy_schema','-'))} / "
        f"S1 {strategy.get('s1_count','-')} / S2 {strategy.get('s2_count','-')} / S3 {strategy.get('s3_count','-')} / "
        f"target {strategy.get('target_count','-')}"
    )
    return lines

def workers_text()->str:
    update_brain_status('running')
    workers={k:worker_status(k) for k in WORKERS}
    router=load_json(FILES['target_router'],{}) or {}
    strat=load_json(FILES['strategy_summary'],{}) or {}
    oflow=load_json(FILES['orderflow'],{}) or {}
    scanner=workers.get('scanner',{})
    feature=workers.get('feature',{})
    candle=workers.get('candle',{})
    market=workers.get('market',{})
    orderflow=workers.get('orderflow',{})
    risk=workers.get('risk',{})
    strategy=workers.get('strategy',{})
    target=workers.get('target_router',{})
    review=workers.get('review',{})
    lines=["🧩 worker 상태 /workers", "- 메인봇은 상태파일만 읽고 worker를 직접 실행하지 않음.", "", "[시장/재료]"]
    lines.append(f"- {worker_ok(scanner)} 스캐너: 전체 {_worker_metric_int(scanner,'row_count','pool_count')}개 수집 / {scanner.get('last_sec','-')}초")
    lines.append(f"- {worker_ok(feature)} 특징: {_worker_metric_int(feature,'row_count')}개 표준값 / {feature.get('last_sec','-')}초")
    lines.append(f"- {worker_ok(candle)} 캔들: {_worker_metric_int(candle,'row_count')}개 보강 / target {_worker_metric_int(candle,'target_count')} / {candle.get('last_sec','-')}초")
    lines.append(f"- {worker_ok(market)} 장세: {_worker_metric_int(market,'row_count')}개 확인 / {market.get('last_sec','-')}초")
    lines += ["", "[정보 보강]"]
    lines.append(f"- {worker_ok(orderflow)} 호가요약: 전체 {_worker_metric_int(orderflow,'row_count')}개 / WS {_worker_metric_int(orderflow,'fresh_ws')} / micro {_worker_metric_int(orderflow,'fresh_micro')} / {orderflow.get('last_sec','-')}초")
    lines.append(f"- {worker_ok(target)} 정보배차: 전체 {router.get('queue_count','-')}개 → 내보냄 {router.get('export_count',router.get('active_target_count','-'))}개 / 순환대기 {router.get('rotation_wait_count','-')} / 버림 {router.get('dropped_count',0)}")
    lines += ["", "[판정/복기]"]
    # v346: strategy status가 순간적으로 rows 0으로 보일 때 summary 캐시 기준값으로 보정 표시.
    # 상태 판단은 worker status를 쓰되, 숫자 표시는 clean_strategy_s_summary / reject summary까지 같이 본다.
    reject_sum = load_json(FILES['strategy_reject'], {}) or {}
    st_eval = _worker_metric_int(strategy,'evaluated','row_count')
    if st_eval in ('-', None, '', 0, '0'):
        st_eval = strat.get('evaluated') or reject_sum.get('evaluated') or '-'
    st_s = _worker_metric_int(strategy,'s_count')
    if st_s in ('-', None, ''):
        st_s = strat.get('s_count', 0)
    st_pending = _worker_metric_int(strategy,'info_pending_count')
    if st_pending in ('-', None, ''):
        st_pending = strat.get('info_pending_count') or reject_sum.get('info_pending_count') or 0
    st_sec = strategy.get('last_sec','-')
    if st_sec in ('-', None, '', 0, '0'):
        st_sec = strat.get('last_sec') or reject_sum.get('last_sec') or st_sec
    lines.append(f"- {worker_ok(strategy)} 전략판정: 평가 {st_eval}개 / S {st_s}개 / 정보대기 {st_pending}개 / {st_sec}초")
    lines.append(f"- {worker_ok(risk)} 위험: 최근손실/쿨다운 확인 / {risk.get('last_sec','-')}초")
    lines.append(f"- {worker_ok(review)} 복기: 최근완료 {_worker_metric_int(review,'closed_recent')}개 / 큰손실 {_worker_metric_int(review,'big_loss')} / 좋은승리 {_worker_metric_int(review,'good_win')} / {review.get('last_sec','-')}초")
    lines += ["", "[데이터 품질 · v482]"]
    try:
        lines += _v482_worker_quality_lines(workers)
    except Exception as exc:
        lines.append(f"- ⚠️ 데이터 품질 요약 생성 실패: {exc.__class__.__name__}")
    lines += ["", "[상세 원본]"]
    lines += [line_worker(workers[k], detail=True) for k in WORKERS]
    return "\n".join(lines)

def _paper_score_cache_version_ok(ver: str) -> bool:
    """v355: paper score cache gate 단일화.

    기존 v354는 허용 버전을 v0.86~v0.92 목록으로 박아두어 paper_bot이 v0.95로
    올라가면 같은 current-version score cache도 구버전으로 오판했다.
    이제 schema/scope는 그대로 엄격히 보되, paper_bot_v0.86 이상은 버전 숫자로 판정한다.
    구 v0.77/v0.80 계열 cache가 섞이지 않게 86 미만은 계속 차단한다.
    """
    m = re.search(r"paper_bot_v0\.(\d+)", str(ver or ""))
    if not m:
        return False
    return int(m.group(1)) >= 86


def _current_paper_score_cache() -> Dict[str, Any]:
    """v355: /score는 현재판 paper score cache만 읽는다.

    오래된 직접계산 fallback은 쓰지 않는다. 다만 paper_bot 버전이 올라갈 때마다
    메인봇 허용목록을 손으로 추가해야 하는 구경로는 제거했다.
    """
    c = load_json(FILES['paper_score'], {}) or {}
    if not isinstance(c, dict):
        return {}
    if not _paper_score_cache_version_ok(str(c.get('version') or '')):
        return {}
    if str(c.get('schema') or '') != 'paper_score_cache_v086':
        return {}
    if str(c.get('score_scope') or '') != 'current_version_anchor':
        return {}
    if c.get('current_closed_count') is None:
        return {}
    return c


def _score_stat_line(label: str, st: Dict[str, Any]) -> str:
    if not isinstance(st, dict):
        st = {}
    n = int(fnum(st.get('n', st.get('count', 0)), default=0))
    wins = int(fnum(st.get('wins', 0), default=0))
    losses = int(fnum(st.get('losses', 0), default=0))
    wr = fnum(st.get('win_rate', st.get('win_rate_pct', 0)), default=0.0)
    total = fnum(st.get('total', st.get('total_pct', st.get('profit_sum', 0))), default=0.0)
    avg = fnum(st.get('avg', st.get('avg_pct', 0)), default=0.0)
    return f"- {label}: {n}전 {wins}승 {losses}패 / 승률 {wr:.1f}% / 합산 {total:+.2f}% / 평균 {avg:+.2f}%"



def score_text()->str:
    cache = _current_paper_score_cache()
    raw = load_json(FILES['paper_score'], {}) or {}
    lines=["📊 전략별 스코어 /score", "- 목적: 닫힌 paper 결과를 대표전략 기준으로 본다. 중복태그 성과는 참고용."]
    label_map={'money_reaccel_s':'돈흐름 재가속','leader_momentum_s':'주도추세 지속','breakout_early_s':'돌파 초입','sweep_vwap_recovery_s':'저점 VWAP 회복','surge_rebreak_s':'급등 후 재돌파','leader_flow_adaptive_hold_s':'주도흐름 유동보유'}
    if cache:
        gs = cache.get('grade_stats') if isinstance(cache.get('grade_stats'), dict) else {}
        current_n=int(fnum(cache.get('current_closed_count') or 0,0))
        primary_stats = cache.get('strategy_primary_stats') if isinstance(cache.get('strategy_primary_stats'), list) else cache.get('strategy_s_stats') if isinstance(cache.get('strategy_s_stats'), list) else []
        overlap_stats = cache.get('strategy_overlap_stats') if isinstance(cache.get('strategy_overlap_stats'), list) else []
        primary_total=int(fnum(cache.get('strategy_primary_total') or sum(int(fnum(x.get('n') or 0,0)) for x in primary_stats if isinstance(x,dict)),0))
        overlap_total=int(fnum(cache.get('strategy_overlap_total') or sum(int(fnum(x.get('n') or 0,0)) for x in overlap_stats if isinstance(x,dict)),0))
        lines.append(f"- 캐시 age {age(FILES['paper_score']):.1f}s / 현재판 CLOSED {current_n}개 / 대표전략 집계 {primary_total}개")
        lines += [
            _score_stat_line('✅ S 전체', gs.get('S', {})),
            _score_stat_line('현재판 전체', gs.get('ALL', {})),
        ]
        lines += ["", "[대표전략 기준 · 실제 거래수와 맞는 성과]"]
        stat_map={str(st.get('key') or st.get('label') or ''):st for st in primary_stats if isinstance(st,dict)}
        for key,label in label_map.items():
            lines.append(_score_stat_line(label, stat_map.get(key, {})))
        if overlap_stats:
            lines += ["", f"[중복태그 포함 · 참고용 / 합계 {overlap_total}개]"]
            over_map={str(st.get('key') or st.get('label') or ''):st for st in overlap_stats if isinstance(st,dict)}
            for key,label in label_map.items():
                lines.append(_score_stat_line(label, over_map.get(key, {})))
            if overlap_total > current_n:
                lines.append(f"- ⚠️ 중복태그 때문에 참고용 합계가 CLOSED보다 {overlap_total-current_n}개 많습니다.")
    else:
        old_ver = raw.get('version','없음') if isinstance(raw,dict) else '없음'
        old_schema = raw.get('schema','-') if isinstance(raw,dict) else '-'
        lines.append(f"- ✅ 구 score cache 차단: {old_ver} / {old_schema}")
        lines.append("- 현재판 paper_bot score cache 준비중입니다. 예전 승률·수익률은 기본 /score에 섞지 않습니다.")
    strat=load_json(FILES['strategy_summary'],{}) or {}
    pbh=load_json(FILES['paperbot_handoff'],{}) or {}
    if strat:
        router=load_json(FILES.get('target_router', BASE_DIR/'clean_target_router_queue.json'),{}) or {}
        lines += ["", "[현재 후보/정보 흐름]"]
        lines.append(f"- 현재 S {strat.get('s_count',0)} / latest {strat.get('paper_latest_count',0)} / paper 병합 {pbh.get('merged_fresh','-')} / archive {pbh.get('archive_window','-')}")
        lines.append(f"- 정보: 전체 {strat.get('evaluated','-')}개 / 시세 {strat.get('quote_ready_count','-')} / micro {strat.get('micro_ready_count','-')} / 둘다 {strat.get('full_info_ready_count','-')}")
        lines.append(f"- 배차: 전체 {router.get('queue_count','-')} / 내보냄 {router.get('export_count', router.get('active_target_count','-'))} / 대기 {router.get('rotation_wait_count','-')} / 버림 {router.get('dropped_count',0)}")
    return "\n".join(lines)



def quality_text()->str:
    reject=load_json(FILES['strategy_reject'],{}) or {}; strat=load_json(FILES['strategy_summary'],{}) or {}
    hand=load_json(FILES['paper_handoff'],{}) or {}
    pbh=load_json(FILES['paperbot_handoff'],{}) or {}
    latest_lines=line_count(FILES['paper_latest'])
    archive_lines=line_count(FILES['paper_archive'])
    router=load_json(FILES.get('target_router', BASE_DIR/'clean_target_router_queue.json'),{}) or {}
    evaluated=int(fnum(reject.get('evaluated') or strat.get('evaluated') or 0,0))
    quote=int(fnum(reject.get('quote_ready_count') or strat.get('quote_ready_count') or evaluated,0))
    micro=int(fnum(reject.get('micro_ready_count') or strat.get('micro_ready_count') or 0,0))
    both=int(fnum(reject.get('full_info_ready_count') or strat.get('full_info_ready_count') or min(quote,micro),0))
    not_micro=max(0,evaluated-micro) if evaluated else 0
    dropped=int(fnum(router.get('dropped_count') or 0,0))
    rot_wait=int(fnum(router.get('rotation_wait_count') or 0,0))
    need_micro=int(fnum(router.get('need_micro') or reject.get('info_pending_count') or 0,0))
    lines=[
        "🔍 후보품질 /quality",
        f"✅ 전체 {evaluated}개 평가 / 최종 S {strat.get('s_count',0)}개 / paper latest {latest_lines}줄 / 병합 {pbh.get('merged_fresh','-')}",
        "",
        "[정보가 얼마나 채워졌나]",
        f"- 시세: {quote}/{evaluated}개 / 호가·체결: {micro}/{evaluated}개 / 둘다: {both}/{evaluated}개",
        f"- 아직 micro 미신선: {not_micro}개 / 지금 꼭 필요한 micro: {need_micro}개",
        "",
        "[안 넣은 게 아니라 순환 상태]",
        f"- 전체배차 {router.get('queue_count','-')}개 → 이번내보냄 {router.get('export_count', router.get('active_target_count','-'))}개",
        f"- 순환대기 {rot_wait}개 / 버림 {dropped}개 / safety초과 {router.get('export_over_budget_count',0)}개",
        f"- 최우선 {router.get('priority_protected_count','-')}개 / 보호슬롯 req {router.get('strategy_req_total_count','-')}개 / req_micro_target {router.get('strategy_req_micro_target_count','-')}개",
        "",
        "[후보 판정]",
        f"- cheap탈락 {reject.get('cheap_reject_count','-')} / 정보대기 {reject.get('info_pending_count','-')} / 정보불필요 {reject.get('info_not_requested','-')} / fresh완료 {reject.get('fresh_ready_count','-')}",
        f"- paper 전달: strategy handoff {hand.get('paper_latest_count','-')} / archive {'대형' if archive_lines<0 else str(archive_lines)+'줄'}",
    ]
    evs=strat.get('events') if isinstance(strat.get('events'),list) else []
    cur_s=int(fnum(strat.get('s_count') or 0,0))
    lines += ["", "[현재 최종 S 후보 TOP]" if cur_s else "[latest/handoff 후보 TOP · 현재 S 0이면 보관 후보]"]
    if evs:
        for e in evs[:8]:
            lines.append(f"- {'✅' if cur_s else '❔'} {e.get('ticker')} / {e.get('strategy_bucket_primary_label', e.get('strategy_name'))} / 점수 {e.get('score')} / 근거 {', '.join(e.get('reasons',[])[:4])}")
    else: lines.append("- 없음")
    wait_sample=reject.get('priority_wait_sample') if isinstance(reject.get('priority_wait_sample'),list) else []
    micro_payload=load_json(FILES.get('micro_targets', BASE_DIR/'clean_micro_targets.json'),{}) or {}
    micro_targets=set(str(x).upper() for x in (micro_payload.get('targets') if isinstance(micro_payload.get('targets'),list) else []))
    active_targets=set(str(x).upper() for x in ((router.get('active_targets') or router.get('targets')) if isinstance((router.get('active_targets') or router.get('targets')),list) else []))
    lines += ["", "[정보대기 TOP · 왜 아직 못 들어갔나]"]
    if wait_sample:
        for x in wait_sample[:6]:
            t=str(x.get('ticker') or '').upper(); mt_bool=bool(x.get('micro_target')) or t in micro_targets; act_bool=bool(x.get('router_active')) or t in active_targets
            q='✅' if x.get('quote_ready') else '❌'; m='✅' if x.get('micro_ready') else '❌'; mt='✅' if mt_bool else '❌'; a='✅' if act_bool else '❌'
            if (not mt_bool): why='target 미반영'
            elif not x.get('micro_ready'): why='micro 수집대기'
            else: why='확인필요'
            lines.append(f"- {t}: 시세 {q} / micro {m} / target {mt} / active {a} / {why}")
    else:
        lines.append("- 없음")
    lines += ["", "[탈락 사유 TOP]"]
    tops=reject.get('reason_top') if isinstance(reject.get('reason_top'),list) else []
    for x in tops[:12]:
        reason=str(x.get('reason') or '-')
        icon='⚠️' if ('고점' in reason or '손실' in reason or '매도' in reason or '윗꼬리' in reason) else '❔'
        lines.append(f"- {icon} {reason}: {x.get('count')}")
    if not tops: lines.append("- 아직 없음")
    return "\n".join(lines)


def strategy_watch_text()->str:
    strat=load_json(FILES['strategy_summary'],{}) or {}
    hand=load_json(FILES['paper_handoff'],{}) or {}
    lines=["👀 전략 감시 /strategy_watch", "- 전략별 S만 감시. A/B/C는 기본화면에서 제외.", f"- handoff: latest {hand.get('paper_latest_count','-')} / 새S {hand.get('new_s_count','-')} / append {hand.get('archive_appended','-')}"]
    for k,v in (strat.get('strategies') or {}).items(): lines.append(f"- {k}: S {v}")
    evs=strat.get('events') if isinstance(strat.get('events'),list) else []
    lines += ["", "[OPEN 전달 후보]"]
    if evs:
        for e in evs[:10]: lines.append(f"- ✅ {e.get('ticker')} / {e.get('strategy_bucket_primary_label')} / {e.get('score')} / {', '.join(e.get('reasons',[])[:3])}")
    else: lines.append("- 없음")
    return "\n".join(lines)

def errorlog_text()->str:
    path=FILES['brain_error']
    header="🧯 오류로그 /errorlog"
    if not path.exists():
        return header+"\n\n✅ 새 실행 중 오류 없음"
    txt=path.read_text(encoding='utf-8',errors='ignore')
    lines=txt.splitlines()
    # 로그 형식: [YYYY-MM-DD HH:MM:SS] where: Error
    new_lines=[]; old_lines=[]
    for ln in lines[-300:]:
        ts=0.0
        m=re.match(r"\[(\d{4}-\d{2}-\d{2} \d{2}:\d{2}:\d{2})\]", ln)
        if m:
            try:
                ts=time.mktime(time.strptime(m.group(1), "%Y-%m-%d %H:%M:%S"))
            except Exception:
                ts=0.0
        if ts and ts >= START_TS:
            new_lines.append(ln)
        elif '[' in ln:
            old_lines.append(ln)
    out=[header]
    if new_lines:
        out += ["", "❌ 새 실행 이후 오류", *new_lines[-10:]]
    else:
        out += ["", "✅ 새 실행 중 오류 없음"]
        if old_lines:
            out.append(f"- 과거 오류 흔적 {len(old_lines)}줄 있음 / 최근 2개만 참고")
            out += old_lines[-2:]
    return "\n".join(out)

def open_text()->str:
    obj=load_json(FILES['paper_open'],{}) or {}
    lines=["📂 OPEN 요약 /popen_short"]
    if not obj: return "\n".join(lines+["- OPEN 없음"])
    for _,p in list(obj.items())[:12]: lines.append(f"- {p.get('ticker')} / {p.get('strategy_name',p.get('strategy_key','-'))} / {p.get('profit_pct',p.get('current_profit_pct','-'))}%")
    return "\n".join(lines)



def _rows_for_pipe(obj:Any)->List[Any]:
    if isinstance(obj,list): return obj
    if isinstance(obj,dict):
        for k in ("rows","items","targets","active","active_rows","queue","data","symbols"):
            if isinstance(obj.get(k),list): return obj.get(k)
    return []

def _sym_for_pipe(x:Any)->str:
    if isinstance(x,str): v=x
    elif isinstance(x,dict): v=x.get("symbol") or x.get("ticker") or x.get("market") or x.get("coin") or x.get("code") or ""
    else: v=""
    return str(v).replace("KRW-","").replace("_KRW","").replace("/KRW","").upper()

def _set_from_file(path:Path)->set:
    return {_sym_for_pipe(r) for r in _rows_for_pipe(load_json(path,{}) or {}) if _sym_for_pipe(r)}

def pipe_check_text()->str:
    update_brain_status('running')
    paths={
        'ws_targets': BASE_DIR/'clean_ws_targets.json',
        'micro_targets': BASE_DIR/'clean_micro_targets.json',
        'router': BASE_DIR/'clean_target_router_queue.json',
        'strategy_req': BASE_DIR/'clean_strategy_priority_requests.json',
        'strategy': BASE_DIR/'clean_strategy_s_reject_summary.json',
        'orderflow': BASE_DIR/'clean_orderflow_summary_cache.json',
        'ws_status': FILES['ws_status'],
        'micro_status': FILES['micro_status'],
    }
    sets={k:_set_from_file(p) for k,p in paths.items()}
    router=load_json(paths['router'],{}) or {}; reject=load_json(paths['strategy'],{}) or {}; req=load_json(paths['strategy_req'],{}) or {}; of=load_json(paths['orderflow'],{}) or {}; ws=load_json(paths['ws_status'],{}) or {}; mi=load_json(paths['micro_status'],{}) or {}
    of_rows=_rows_for_pipe(of)
    quote_ready=sum(1 for r in of_rows if isinstance(r,dict) and (r.get('quote_fresh') or r.get('ws_fresh')))
    micro_ready=sum(1 for r in of_rows if isinstance(r,dict) and r.get('micro_fresh'))
    full_ready=sum(1 for r in of_rows if isinstance(r,dict) and (r.get('info_ready') or ((r.get('quote_fresh') or r.get('ws_fresh')) and r.get('micro_fresh'))))
    active_ready=sum(1 for r in of_rows if isinstance(r,dict) and r.get('router_active') and (r.get('info_ready') or ((r.get('quote_fresh') or r.get('ws_fresh')) and r.get('micro_fresh'))))
    lines=["🧪 정보배관 점검 /pipe_check", "- SSH 없이 target → orderflow → strategy 병합 상태만 봅니다."]
    lines.append(f"- WS 상태: age {age(paths['ws_status']):.1f}s / fresh {ws.get('fresh','-')} / targets {len(sets['ws_targets'])}")
    lines.append(f"- micro 상태: age {age(paths['micro_status']):.1f}s / fresh {mi.get('fresh','-')} / targets {mi.get('targets','-')} / target파일 {len(sets['micro_targets'])}")
    lines.append(f"- orderflow: rows {len(of_rows)} / quote준비 {quote_ready} / micro준비 {micro_ready} / 둘다준비 {full_ready} / active준비 {active_ready}")
    lines.append(router_flow_summary(router))
    lines.append(f"- router 세부: 이번순환 {router.get('rotation_export_count','-')} / 순환대기 {router.get('rotation_wait_count','-')} / 버림 {router.get('dropped_count',0)} / fresh회복 {router.get('fresh_recovered','-')}")
    lines.append(f"- strategy: 평가 {reject.get('evaluated','-')} / cheap탈락 {reject.get('cheap_reject_count','-')} / 정보필요 {reject.get('info_needed_count','-')} / 정보대기 {reject.get('info_pending_count','-')} / fresh완료 {reject.get('fresh_ready_count','-')} / 병합 {reject.get('orderflow_attached_count','-')}")
    lines.append("")
    checks=[('ws_targets','orderflow'),('micro_targets','orderflow'),('router','ws_targets'),('router','micro_targets'),('strategy_req','orderflow')]
    for a,b in checks:
        lines.append(f"- 겹침 {a}↔{b}: {len(sets[a] & sets[b])}")
    lines.append("")
    if len(sets['ws_targets']) and len(sets['ws_targets'] & sets['orderflow']): lines.append("✅ WS target은 orderflow에 심볼 기준 붙음")
    elif len(sets['ws_targets']): lines.append("❌ WS target은 있으나 orderflow에 심볼이 안 붙음")
    else: lines.append("⚠️ WS active target 없음")
    if len(sets['micro_targets']) and len(sets['micro_targets'] & sets['orderflow']): lines.append("✅ micro target은 orderflow에 심볼 기준 붙음")
    elif len(sets['micro_targets']): lines.append("❌ micro target은 있으나 orderflow에 심볼이 안 붙음")
    else: lines.append("⚠️ micro active target 없음")
    # 전략 요청 후보를 개별로 짧게 보여준다. 흐름이 막히면 여기서 quote/micro/target 중 무엇이 빠졌는지 바로 보인다.
    of_map = { _sym_for_pipe(r): r for r in of_rows if isinstance(r, dict) and _sym_for_pipe(r) }
    req_rows = _rows_for_pipe(req)
    if isinstance(req, dict) and isinstance(req.get('requests'), list):
        req_rows = req.get('requests')
    if req_rows:
        lines += ["", "[전략요청 후보 상태]"]
        for r in req_rows[:8]:
            t=_sym_for_pipe(r)
            ofr=of_map.get(t,{})
            q=bool(ofr.get('quote_fresh') or ofr.get('ws_fresh'))
            m=bool(ofr.get('micro_fresh'))
            a=t in sets['micro_targets']
            active=bool(ofr.get('router_active'))
            qicon='✅' if q else '❌'
            micon='✅' if m else '❌'
            ticon='✅' if a else '❌'
            aicon='✅' if active else '❌'
            need = r.get('need') if isinstance(r,dict) and isinstance(r.get('need'),list) else []
            why=''
            if not a:
                why=' / 원인 microTarget 미반영'
            elif not active:
                why=' / 원인 orderflow active 미표시'
            elif not m:
                why=' / 원인 micro 수집대기'
            lines.append(f"- {t}: quote {qicon} / micro {micon} / microTarget {ticon} / active {aicon} / {r.get('bucket','-') if isinstance(r,dict) else '-'} / need {','.join(need)}{why}")
    if full_ready:
        lines.append("✅ orderflow canonical 정보가 준비된 후보 있음")
    else:
        lines.append("⚠️ orderflow canonical 둘다준비 후보 없음: micro/quote 중 하나가 부족")
    lines.append("- 판단: v340 기준: strategy는 quote_fresh(WS 또는 scanner REST)+micro_fresh를 기준으로 보고, S근접 micro 대기는 우선배차로 따로 추적합니다.")
    return "\n".join(lines)


# -----------------------------
# v343: 메인봇에서 paper 복기/성과 명령을 캐시 전용으로 읽는다.
# paper_bot은 실행/장부/알림 담당, 메인봇은 사용자가 한 방에서 볼 수 있게 요약만 읽는다.
# -----------------------------
STRATEGY_LABELS = {
    'money_reaccel_s': '돈흐름 재가속',
    'leader_momentum_s': '주도추세 지속',
    'breakout_early_s': '돌파 초입',
    'sweep_vwap_recovery_s': '저점 VWAP 회복',
    'surge_rebreak_s': '급등 후 재돌파',
    'leader_flow_adaptive_hold_s': '주도흐름 유동보유',
}

def _short_ticker(v: Any) -> str:
    return str(v or '').upper().replace('KRW-', '').replace('_KRW', '').replace('/KRW', '').replace('KRW', '').strip()

def _paper_open_positions() -> Dict[str, Dict[str, Any]]:
    obj = load_json(FILES['paper_open'], {}) or {}
    return obj if isinstance(obj, dict) else {}

def _paper_score_cache_current() -> Dict[str, Any]:
    return _current_paper_score_cache()

def _stat_line(label: str, st: Dict[str, Any]) -> str:
    return _score_stat_line(label, st)

def _paper_strategy_label(row_or_key: Any) -> str:
    if isinstance(row_or_key, dict):
        k = str(row_or_key.get('strategy_key') or row_or_key.get('primary_strategy_key') or row_or_key.get('representative_strategy_key') or '')
        name = str(row_or_key.get('strategy_bucket_primary_label') or row_or_key.get('strategy_name') or row_or_key.get('strategy') or '')
        if k in STRATEGY_LABELS:
            return STRATEGY_LABELS[k]
        for kk, vv in STRATEGY_LABELS.items():
            if vv in name:
                return vv
        return name or '-'
    k = str(row_or_key or '')
    return STRATEGY_LABELS.get(k, k or '-')

def _paper_grade(row: Dict[str, Any]) -> str:
    g = str(row.get('grade') or row.get('entry_grade') or row.get('signal_grade') or 'S').upper()
    return g if g else 'S'

def pstatus_text() -> str:
    status = load_json(FILES['paper_status'], {}) or {}
    open_pos = _paper_open_positions()
    cache = _paper_score_cache_current()
    hand = load_json(FILES['paperbot_handoff'], {}) or {}
    grade_counts = Counter(_paper_grade(p) for p in open_pos.values() if isinstance(p, dict))
    lines = [
        '🧪 paper 상태 /pstatus · 메인봇 캐시전용',
        '- paper_bot 명령을 메인봇방에서 읽는 요약입니다. 실행/장부/알림은 paper_bot 담당.',
        f"- 상태: {'ON' if status.get('running', True) else '확인필요'} / loop {status.get('loop_sec', status.get('loop_interval_sec', '-'))}s / OPEN {len(open_pos)} / age {age(FILES['paper_status']):.1f}s",
        f"- OPEN: S {grade_counts.get('S',0)} / A {grade_counts.get('A',0)} / B {grade_counts.get('B',0)} / C {grade_counts.get('C',0)} / 제외 {grade_counts.get('X',0)}",
        f"- handoff: latest {hand.get('latest_count', hand.get('paper_latest_count','-'))} / archive창 {hand.get('archive_window','-')} / 병합fresh {hand.get('merged_fresh','-')}",
        f"- 선별배관: 읽음 {status.get('pick_stats',{}).get('paper_file','-') if isinstance(status.get('pick_stats'),dict) else '-'} / S1선택 {status.get('pick_stats',{}).get('v369_s1_selected', status.get('pick_stats',{}).get('v368_s1_open','-')) if isinstance(status.get('pick_stats'),dict) else '-'} / S2보류 {status.get('pick_stats',{}).get('v369_s2_trace','-') if isinstance(status.get('pick_stats'),dict) else '-'} / S3관찰 {status.get('pick_stats',{}).get('v369_s3_trace','-') if isinstance(status.get('pick_stats'),dict) else '-'} / 실제OPEN {status.get('opened_this_cycle','-')}",
    ]
    if cache:
        gs = cache.get('grade_stats') if isinstance(cache.get('grade_stats'), dict) else {}
        current_n = int(fnum(cache.get('current_closed_count') or 0, 0))
        primary_total = int(fnum(cache.get('strategy_primary_total') or 0, 0))
        lines += [
            f"- 성과범위: 현재판 앵커 이후 / {cache.get('anchor_text','-')} / CLOSED {current_n}개 / 대표전략 집계 {primary_total}개",
            '[현재판 성과]',
            _stat_line('✅ S', gs.get('S', {})),
            _stat_line('현재판 전체', gs.get('ALL', {})),
            '- 전략별 상세는 /pscore 또는 /score',
        ]
    else:
        raw = load_json(FILES['paper_score'], {}) or {}
        lines += [
            '- 현재판 score cache 준비중',
            f"- 구버전 성과캐시 무시: {raw.get('version','-')} / {raw.get('schema','-')}",
        ]
    return '\n'.join(lines)

def pscore_text() -> str:
    # 메인봇 /score와 같은 현재판 cache를 사용하되 paper 명령 이름으로 보여준다.
    txt = score_text()
    return txt.replace('📊 전략별 스코어 /score', '📊 paper 전략별 스코어 /pscore · 메인봇 캐시전용', 1)

def _pos_profit_pct(pos: Dict[str, Any]) -> float:
    for k in ('pnl_pct','profit_pct','current_profit_pct','unrealized_pct'):
        if pos.get(k) not in (None, ''):
            return fnum(pos.get(k), 0.0)
    entry = fnum(pos.get('entry_price'), 0.0)
    cur = fnum(pos.get('current_price') or pos.get('last_price'), 0.0)
    if entry > 0 and cur > 0:
        return (cur - entry) / entry * 100.0
    return 0.0

def _pos_entry_price(pos: Dict[str, Any]) -> str:
    v = pos.get('entry_price') or pos.get('entry') or '-'
    try:
        fv = float(str(v).replace(',', ''))
        if fv >= 1000:
            return f"{fv:,.0f}"
        return f"{fv:.4f}"
    except Exception:
        return str(v)

def _pos_current_price(pos: Dict[str, Any]) -> str:
    v = pos.get('current_price') or pos.get('last_price') or pos.get('entry_price') or '-'
    try:
        fv = float(str(v).replace(',', ''))
        if fv >= 1000:
            return f"{fv:,.0f}"
        return f"{fv:.4f}"
    except Exception:
        return str(v)

def _pos_snapshot_flat(pos: Dict[str, Any]) -> Dict[str, Any]:
    ctx = pos.get('entry_context') if isinstance(pos.get('entry_context'), dict) else {}
    snap = ctx.get('entry_snapshot') if isinstance(ctx.get('entry_snapshot'), dict) else pos.get('entry_snapshot') if isinstance(pos.get('entry_snapshot'), dict) else {}
    vals: Dict[str, Any] = {}
    if isinstance(snap, dict):
        flat = snap.get('flat')
        if isinstance(flat, dict): vals.update(flat)
        for gname in ('price_flow','position','money_flow','orderflow','risk','strategy'):
            g = snap.get(gname)
            if isinstance(g, dict):
                for k, v in g.items(): vals.setdefault(k, v)
    if isinstance(ctx, dict):
        for k, v in ctx.items(): vals.setdefault(k, v)
    for k, v in pos.items():
        if k not in vals and k not in {'entry_context','entry_snapshot'}:
            vals[k] = v
    return vals

def _pos_hold_sec(pos: Dict[str, Any]) -> float:
    for k in ('hold_sec','age_sec'):
        v = fnum(pos.get(k), default=-1.0)
        if v > 0:
            return v
    for k in ('opened_at','entry_ts','open_ts','opened_ts','created_at','start_ts'):
        v = pos.get(k)
        ts = fnum(v, default=0.0)
        if ts > 10_000_000_000:
            ts = ts / 1000.0
        if ts <= 0 and isinstance(v, str):
            try:
                # ISO/text time fallback. timezone 없는 서버 로컬 기준.
                ts = time.mktime(time.strptime(v[:19].replace('T',' '), '%Y-%m-%d %H:%M:%S'))
            except Exception:
                ts = 0.0
        if ts > 0:
            return max(0.0, now_ts() - ts)
    return 0.0

def popen_text() -> str:
    open_pos = _paper_open_positions()
    lines = ['📂 paper OPEN /popen · 메인봇 캐시전용']
    if not open_pos:
        return '\n'.join(lines + ['OPEN 없음'])
    rows = [p for p in open_pos.values() if isinstance(p, dict)]
    rows.sort(key=lambda p: fnum(p.get('opened_at') or p.get('entry_ts') or 0, 0), reverse=True)
    by_strategy = Counter(_paper_strategy_label(p) for p in rows)
    lines.append('전략별 OPEN: ' + ' / '.join(f'{k} {v}' for k, v in by_strategy.items()))
    for p in rows[:10]:
        t = _short_ticker(p.get('ticker') or p.get('symbol'))
        pnl = _pos_profit_pct(p)
        hold = _pos_hold_sec(p)
        vals = _pos_snapshot_flat(p)
        buy = vals.get('buy_ratio') or vals.get('micro_trade_buy_ratio_30') or '-'
        reason = p.get('reason') or p.get('entry_reason') or p.get('watch_note') or 'time_exit 대기'
        try: buy_txt = f"{float(buy):.2f}"
        except Exception: buy_txt = str(buy)
        lines.append(f"- ✅ {_paper_grade(p)}급 {t} / {_paper_strategy_label(p)} / 진입 {_pos_entry_price(p)} / 현재 {_pos_current_price(p)} / {pnl:+.2f}% / 보유 {int(hold//60)}분 {int(hold%60)}초 / 감시 {reason}")
        lines.append(f"  · 근거: 매수체결 {buy_txt} / 주의: {p.get('risk_label') or p.get('risk_tags') or '특이사항 없음'}")
    if len(rows) > 10:
        lines.append(f"- 나머지 {len(rows)-10}개는 paper_bot /popen 단독 또는 이후 full에서 확인")
    return '\n'.join(lines)


# =============================================================================
# v347: paper review canonical module
# - 기존 v341~v346에서 덧붙은 preview/missed_review override들을 제거하고
#   단일 canonical 경로로 재작성한다.
# - 목적: /preview가 어떤 필드 타입(dict/float/list/None)을 만나도 죽지 않게 하고,
#   놓친 후보 추적/손실 복기 판단을 한 곳에서만 수행한다.
# =============================================================================

def as_dict(v: Any) -> Dict[str, Any]:
    return v if isinstance(v, dict) else {}

def as_list(v: Any) -> List[Any]:
    if isinstance(v, list):
        return v
    if isinstance(v, tuple):
        return list(v)
    return []

def first_value(*vals: Any, default: Any = None) -> Any:
    for v in vals:
        if v is None or v == "":
            continue
        return v
    return default

def price_from_any(v: Any) -> float:
    """dict/float/int/str/list 어떤 형태든 current price 후보를 안전하게 숫자로 변환."""
    if isinstance(v, dict):
        return fnum(v.get('current_price'), v.get('price'), v.get('trade_price'), v.get('close'), v.get('last'), default=0.0)
    if isinstance(v, (int, float, str)):
        return fnum(v, default=0.0)
    return 0.0

def _event_ts(ev: Dict[str, Any]) -> float:
    row = as_dict(ev)
    return fnum(
        row.get('candidate_created_at'), row.get('source_created_at'), row.get('detected_ts'),
        row.get('event_ts'), row.get('created_at'), row.get('timestamp'), default=0.0
    )

def _primary_strategy_key(row: Dict[str, Any]) -> str:
    row = as_dict(row)
    ctx = as_dict(row.get('entry_context'))
    snap = as_dict(row.get('entry_snapshot') or ctx.get('entry_snapshot'))
    strat = as_dict(snap.get('strategy'))
    candidates = [
        row.get('representative_strategy_key'), row.get('primary_strategy_key'), row.get('paper_strategy_key'),
        row.get('strategy_bucket_primary'), row.get('strategy_key'), row.get('strategy'), row.get('strategy_name'),
        row.get('strategy_label'), row.get('strategy_bucket_primary_label'),
        ctx.get('representative_strategy_key'), ctx.get('primary_strategy_key'), ctx.get('paper_strategy_key'),
        ctx.get('strategy_bucket_primary'), ctx.get('strategy_key'), ctx.get('strategy'), ctx.get('strategy_name'),
        ctx.get('strategy_bucket_primary_label'), strat.get('primary_key'), strat.get('primary_label')
    ]
    for v in candidates:
        text = str(v or '')
        if not text:
            continue
        if text in STRATEGY_LABELS:
            return text
        for k, label in STRATEGY_LABELS.items():
            if k in text or label in text or f'{label} S' in text:
                return k
    for vals in (
        row.get('multi_strategy_s'), row.get('strategy_bucket_keys'), ctx.get('multi_strategy_s'),
        ctx.get('strategy_bucket_keys'), strat.get('tags')
    ):
        for x in as_list(vals):
            text = str(x or '')
            if text in STRATEGY_LABELS:
                return text
            for k, label in STRATEGY_LABELS.items():
                if k in text or label in text:
                    return k
    return 'unknown'

def _paper_anchor_ts() -> float:
    c = _paper_score_cache_current()
    if isinstance(c, dict) and c:
        return fnum(c.get('anchor_ts'), c.get('current_anchor_ts'), default=0.0)
    a = load_json(FILES.get('score_anchor', BASE_DIR/'paper_bot_current_score_anchor.json'), {}) or {}
    return fnum(as_dict(a).get('anchor_ts'), default=0.0)

def _paper_current_closed_rows(max_lines:int=2600) -> List[Dict[str, Any]]:
    rows = read_jsonl(FILES.get('paper_closed', BASE_DIR/'paper_bot_closed.jsonl'), max_lines=max_lines)
    anchor = _paper_anchor_ts()
    if not anchor:
        return rows
    out=[]
    for r in rows:
        if not isinstance(r, dict):
            continue
        ts = fnum(r.get('closed_at'), r.get('closed_ts'), r.get('close_ts'), r.get('timestamp'), default=0.0)
        ots = fnum(r.get('opened_at'), r.get('entry_ts'), r.get('open_ts'), default=0.0)
        if max(ts, ots) >= anchor:
            out.append(r)
    return out

def _snapshot_flat(row: Dict[str, Any]) -> Dict[str, Any]:
    """entry_context/entry_snapshot nested group을 안전하게 평탄화한다."""
    row = as_dict(row)
    ctx = as_dict(row.get('entry_context'))
    snap = as_dict(row.get('entry_snapshot') or ctx.get('entry_snapshot'))
    vals: Dict[str, Any] = {}
    for gname in ('price_flow','position','money_flow','orderflow','risk','strategy'):
        g = as_dict(snap.get(gname))
        vals.update({k:v for k,v in g.items() if k not in vals})
    vals.update({k:v for k,v in ctx.items() if k not in vals and k != 'entry_snapshot'})
    vals.update({k:v for k,v in row.items() if k not in vals and k not in {'entry_context','entry_snapshot'}})
    return vals

def _loss_causes(row: Dict[str, Any]) -> List[str]:
    row = as_dict(row); ctx=_snapshot_flat(row)
    causes=[]
    pnl=fnum(row.get('pnl_pct'), row.get('profit_pct'), row.get('return_pct'), default=0.0)
    peak=fnum(row.get('peak_pct'), row.get('max_profit_pct'), row.get('max_pnl_pct'), default=0.0)
    trough=fnum(row.get('trough_pct'), row.get('min_profit_pct'), row.get('min_pnl_pct'), default=0.0)
    hold=fnum(row.get('hold_sec'), row.get('duration_sec'), default=0.0)
    spread=fnum(ctx.get('spread_pct'), default=-1.0)
    buy=fnum(ctx.get('buy_ratio'), ctx.get('micro_trade_buy_ratio_30'), ctx.get('buy_trade_ratio'), default=-1.0)
    buy_s=fnum(ctx.get('buy_ratio_1m'), ctx.get('micro_buy_ratio_sustain_1m'), ctx.get('buy_ratio_sustain'), default=-1.0)
    vwap=fnum(ctx.get('vwap_gap_pct'), default=999.0)
    ema=fnum(ctx.get('ema5_gap_pct'), ctx.get('ema_gap_pct'), default=999.0)
    ch3=fnum(ctx.get('change_3m'), ctx.get('price_change_3m'), default=999.0)
    ch5=fnum(ctx.get('change_5m'), ctx.get('price_change_5m'), default=999.0)
    if pnl < 0:
        if peak <= 0.10: causes.append('진입후반응없음(최고+0.1%이하)')
        elif peak <= 0.30: causes.append('반응약함(최고+0.3%이하)')
        if hold and hold <= 180: causes.append('초반빠른손실(3분이내)')
        if trough <= -0.70: causes.append('깊은역행')
    if spread >= 0.28: causes.append('스프레드넓음')
    if 0 <= buy < 0.65: causes.append('매수체결약함')
    if 0 <= buy_s < 0.60: causes.append('매수체결지속약함')
    if ctx.get('sell_pressure') or ctx.get('ask_wall_pressure') or ctx.get('sell_trade_pressure'):
        causes.append('매도압력')
    if vwap != 999.0 and vwap < -0.15: causes.append('VWAP아래')
    if ema != 999.0 and ema < -0.20: causes.append('EMA아래')
    if ch3 != 999.0 and ch5 != 999.0 and ch3 <= 0.05 and ch5 <= 0.10:
        causes.append('가격반응부족')
    if not any(k in ctx for k in ('change_3m','price_change_3m','vwap_gap_pct','buy_ratio','spread_pct')):
        causes.append('근거스냅샷부족')
    if not causes and pnl < 0:
        causes.append('기타손실')
    # 중복 제거, 순서 유지
    out=[]
    for c in causes:
        if c not in out: out.append(c)
    return out

def ploss_review_text() -> str:
    rows=_paper_current_closed_rows()
    losses=[r for r in rows if fnum(r.get('pnl_pct'), r.get('profit_pct'), default=0.0)<0]
    wins=[r for r in rows if fnum(r.get('pnl_pct'), r.get('profit_pct'), default=0.0)>0]
    cc=Counter(); by={k:[] for k in STRATEGY_LABELS}; sc={k:Counter() for k in STRATEGY_LABELS}; unknown=[]
    for r in losses:
        key=_primary_strategy_key(r)
        if key not in STRATEGY_LABELS:
            unknown.append(r); key='unknown'
        by.setdefault(key,[]).append(r); sc.setdefault(key,Counter())
        for cause in _loss_causes(r):
            cc[cause]+=1; sc[key][cause]+=1
    lines=['🧯 손실 원인 복기 /ploss_review · 메인봇 캐시전용', '- 현재판 CLOSED 손실에서 공통 패배 패턴을 봅니다.', f'- 현재판 CLOSED {len(rows)}개 / 승리 {len(wins)}개 / 손실 {len(losses)}개 / 미분류손실 {len(unknown)}개', '', '[공통 손실 TOP]']
    if cc:
        for k,v in cc.most_common(10): lines.append(f'- ⚠️ {k}: {v}개')
    else:
        lines.append('- 아직 손실 표본 없음')
    lines += ['', '[전략별 손실 원인 · 대표전략 기준]']
    for k,label in STRATEGY_LABELS.items():
        sub=by.get(k,[]); tops=', '.join(f'{a} {b}' for a,b in sc.get(k,Counter()).most_common(3)) or '-'
        lines.append(f'- {label}: 손실 {len(sub)}개 / {tops}')
    if unknown:
        tops=', '.join(f'{a} {b}' for a,b in sc.get('unknown',Counter()).most_common(3)) or '-'
        lines.append(f'- 미분류: 손실 {len(unknown)}개 / {tops}')
    lines += ['', '[조건 설계 힌트]']
    if cc.get('진입후반응없음(최고+0.1%이하)',0) >= max(3, len(losses)*0.25): lines.append('- 진입 전/직후 가격반응 조건을 전략별로 넣을 가치가 큼')
    if cc.get('매수체결약함',0) or cc.get('매수체결지속약함',0): lines.append('- 매수체결 순간값보다 지속성 조건을 봐야 함')
    if cc.get('매도압력',0): lines.append('- 매도벽/매도체결압력은 공통 하드차단이 아니라 전략별 강도 조절 필요')
    if cc.get('근거스냅샷부족',0): lines.append('- 일부 구 OPEN/CLOSED는 snapshot 부족. 신규 snapshot CLOSED를 더 신뢰')
    return '\n'.join(lines)

def _market_price_map() -> Dict[str, Dict[str, Any]]:
    """시장 가격 map을 항상 dict 형태로 반환한다. 기존 float 반환 경로 제거."""
    out: Dict[str, Dict[str, Any]] = {}
    for p in (FILES['scanner_market'], FILES['feature'], FILES['orderflow']):
        obj=load_json(p,{}) or {}; rows=[]
        if isinstance(obj, list):
            rows=obj
        elif isinstance(obj, dict):
            for key in ('rows','items','data'):
                if isinstance(obj.get(key), list):
                    rows=obj.get(key); break
            if not rows and isinstance(obj.get('cache'), dict):
                for k,v in obj.get('cache',{}).items():
                    if isinstance(v,dict):
                        vv=dict(v); vv.setdefault('ticker',k); rows.append(vv)
        for r in rows or []:
            if not isinstance(r,dict):
                continue
            t=norm_ticker(r.get('ticker') or r.get('symbol') or r.get('market'))
            price=price_from_any(r)
            if t and price>0:
                cur=out.setdefault(t, {})
                cur['current_price']=price
                cur.setdefault('source', p.name)
    return out

def _candidate_norm(ev: Dict[str, Any]) -> Dict[str, Any]:
    row=dict(as_dict(ev))
    raw_id = first_value(row.get('event_id'), row.get('event_key'), row.get('trace_id'), row.get('handoff_id'), row.get('candidate_uid'), row.get('id'))
    t=norm_ticker(row.get('ticker') or row.get('market') or row.get('symbol')) or 'UNKNOWN'
    sk=_primary_strategy_key(row) or 'strategy_s'
    ts=_event_ts(row) or now_ts()
    eid=str(raw_id or f"ev:{t}:{sk}:{int(ts//30)}")
    row['event_id']=eid; row['event_key']=eid
    row.setdefault('trace_id', eid); row.setdefault('handoff_id', eid); row.setdefault('candidate_uid', eid)
    if not raw_id:
        row.setdefault('event_id_origin','legacy_fallback')
    return row

def _candidate_keys(ev: Dict[str, Any]) -> set:
    row=_candidate_norm(ev); keys=set()
    for k in ('event_id','event_key','trace_id','handoff_id','candidate_uid','pos_id'):
        v=row.get(k)
        if v not in (None,'','-'): keys.add(str(v))
    t=norm_ticker(row.get('ticker') or row.get('market') or row.get('symbol')) or ''
    sk=_primary_strategy_key(row); ts=_event_ts(row)
    if t and sk and ts:
        keys.add(f'fb:{t}:{sk}:{int(ts//30)}')
        keys.add(f'fbm:{t}:{sk}:{int(ts//60)}')
    if t: keys.add(f'ticker:{t}')
    return keys

def _open_closed_candidate_keys():
    open_rows=[]
    try:
        op=load_json(BASE_DIR/'paper_open_positions.json',{})
        if isinstance(op,dict): open_rows=list(op.values())
    except Exception: pass
    closed_rows = _paper_current_closed_rows(max_lines=2600)
    open_keys=set(); closed_keys=set(); open_tickers=set()
    for p in open_rows:
        if isinstance(p,dict):
            open_keys |= _candidate_keys(p)
            t=norm_ticker(p.get('ticker') or p.get('market') or p.get('symbol')) or ''
            if t: open_tickers.add(t)
    for r in closed_rows:
        if isinstance(r,dict):
            closed_keys |= _candidate_keys(r)
            src=as_dict(r.get('source_event'))
            if src: closed_keys |= _candidate_keys(src)
    return open_keys, closed_keys, open_tickers



# v349: preview/missed_review/open-closed key canonical alias.
# 기존 pmissed_review 계열에서 _open_closed_keys 이름을 쓰는 경로와
# _open_closed_candidate_keys 이름을 쓰는 경로를 하나로 통일한다.
def _open_closed_keys():
    return _open_closed_candidate_keys()

def _merged_candidate_keys():
    rows=[]
    for name in ['paper_candidates_handoff_merged.jsonl','paper_candidates_latest.jsonl']:
        try: rows += read_jsonl(BASE_DIR/name, max_lines=500)
        except Exception: pass
    keys=set()
    for r in rows:
        if isinstance(r,dict): keys |= _candidate_keys(r)
    return keys

def _missed_reason(row: Dict[str,Any], merged_keys=None) -> str:
    row=_candidate_norm(row); nowv=now_ts(); reasons=[]
    keys=_candidate_keys(row); merged_keys=merged_keys if merged_keys is not None else _merged_candidate_keys()
    exp=fnum(row.get('expires_at'), default=0.0); ts=_event_ts(row)
    if exp and exp < nowv: reasons.append('handoff만료')
    if ts and nowv-ts>180: reasons.append('후보오래됨')
    if not (keys & merged_keys): reasons.append('paper미병합')
    ctx=as_dict(row.get('entry_context'))
    if not (row.get('micro_fresh') or ctx.get('micro_fresh')): reasons.append('micro미확인')
    if row.get('stale') or row.get('is_stale'): reasons.append('stale')
    if row.get('open_eligible') is False or row.get('paper_bot_open') is False: reasons.append('open_eligible_false')
    if row.get('event_id_origin') == 'legacy_fallback': reasons.append('구후보ID보정')
    if not reasons: reasons.append('paper미병합/만료확인')
    out=[]
    for r in reasons:
        if r not in out: out.append(r)
    return ','.join(out[:5])

def pmissed_review_text() -> str:
    anchor_ts = _paper_anchor_ts()
    events=[]
    for name,maxn in [('paper_candidates.jsonl',1000),('paper_candidates_latest.jsonl',250)]:
        try: events += read_jsonl(BASE_DIR/name, max_lines=maxn)
        except Exception: pass
    market = _market_price_map()
    open_keys, closed_keys, open_tickers = _open_closed_candidate_keys()
    merged_keys = _merged_candidate_keys()
    seen=set(); missed=[]; watched=0; counter=Counter()
    for raw in events:
        if not isinstance(raw,dict): continue
        ev=_candidate_norm(raw); ts=_event_ts(ev)
        if anchor_ts and ts and ts<anchor_ts: continue
        t=norm_ticker(ev.get('ticker') or ev.get('market') or ev.get('symbol')) or ''
        if not t: continue
        keys=_candidate_keys(ev); dedupe=str(ev.get('event_id') or f'{t}:{_primary_strategy_key(ev)}:{int(ts//30) if ts else 0}')
        if dedupe in seen: continue
        seen.add(dedupe); watched+=1
        if (keys & closed_keys) or (keys & open_keys) or t in open_tickers: continue
        cur=market.get(t,{}) if isinstance(market,dict) else {}
        cur_price=price_from_any(cur)
        entry=fnum(ev.get('entry_price'), ev.get('current_price'), ev.get('detected_price'), default=0.0)
        if cur_price<=0 or entry<=0: continue
        gain=(cur_price-entry)/entry*100.0
        if gain>=0.70:
            why=_missed_reason(ev, merged_keys)
            for r in why.split(','):
                if r: counter[r]+=1
            rs=ev.get('reasons') or ev.get('final_entry_reasons') or []
            missed.append({'ticker':t,'gain':gain,'strategy':ev.get('strategy_bucket_primary_label') or ev.get('strategy_name') or ev.get('strategy'), 'score':ev.get('score'), 'reasons':rs if isinstance(rs,list) else [], 'missed_reason':why})
    missed.sort(key=lambda x:x.get('gain',0), reverse=True)
    lines=['🔎 놓친 후보 복기 /pmissed_review · 메인봇 캐시전용','- 후보 archive/latest 중 OPEN/CLOSED로 이어지지 않았는데 이후 오른 코인을 봅니다.',f'- 확인 후보 {watched}개 / 현재가 비교 가능 상승후보 {len(missed)}개','','[놓친 이유 추정 TOP]']
    if counter:
        for k,v in counter.most_common(10):
            icon='⚠️' if k in {'paper미병합','handoff만료','후보오래됨','micro미확인'} else '❔'
            lines.append(f'- {icon} {k}: {v}개')
    else:
        lines.append('- 아직 분류할 상승후보 없음')
    lines += ['', '[이후 오른 후보 TOP]']
    if missed:
        for m in missed[:10]:
            rs=m.get('reasons') if isinstance(m.get('reasons'),list) else []
            lines.append(f"- {'⚠️' if m['gain']>=1.5 else '❔'} {m['ticker']} / +{m['gain']:.2f}% / {m.get('strategy','-')} / 점수 {m.get('score','-')} / 놓친이유 {m.get('missed_reason','-')} / 근거 {', '.join(map(str, rs[:3]))}")
    else:
        lines.append('- 아직 뚜렷한 놓친 상승후보 없음')
    lines += ['', '[판독]', '- 자주 오르는 패턴은 조건에서 죽이면 안 됨', '- paper미병합/만료/오래됨이 많으면 전략조건보다 handoff·진입타이밍 문제를 먼저 봅니다', '- 손실필터는 /ploss_review와 같이 봐야 합니다']
    return '\n'.join(lines)

def preview_text() -> str:
    # 단일 canonical preview: loss + missed를 각각 보호 실행해 한쪽 오류가 전체를 죽이지 않게 한다.
    parts=[]
    for title, fn in [('ploss_review', ploss_review_text), ('pmissed_review', pmissed_review_text)]:
        try:
            parts.append(fn())
        except Exception as exc:
            log_error(f'preview_{title}', exc)
            parts.append(f'❌ {title} 생성 오류: {exc.__class__.__name__}: {exc}')
    return '\n\n'.join(parts)



# =============================================================================
# v348: missed trace / handoff canonical review
# - paper_bot_v0.91의 candidate_handoff_trace를 우선 사용한다.
# - 같은 ticker/전략의 중복 놓친 후보는 1개로 합친다.
# - 조건 판단 전, 왜 paper OPEN으로 이어지지 않았는지 추적한다.
# =============================================================================

def _v348_trace_rows() -> List[Dict[str, Any]]:
    obj = load_json(FILES.get('candidate_handoff_trace', BASE_DIR/'paper_bot_candidate_handoff_trace.json'), {}) or {}
    rows = obj.get('rows') if isinstance(obj, dict) else []
    return [r for r in rows if isinstance(r, dict)] if isinstance(rows, list) else []


def _v348_trace_map() -> Dict[str, Dict[str, Any]]:
    out: Dict[str, Dict[str, Any]] = {}
    for r in _v348_trace_rows():
        t = norm_ticker(r.get('ticker') or r.get('market') or r.get('symbol'))
        sk = _primary_strategy_key(r) or str(r.get('strategy_key') or r.get('strategy') or '')
        for k in [str(r.get('event_id') or ''), str(r.get('event_key') or ''), str(r.get('trace_id') or ''), str(r.get('handoff_id') or ''), f'{t}:{sk}']:
            if k and k != '-':
                out[k] = r
    return out


def _v348_trace_for_candidate(ev: Dict[str, Any], trace_map: Optional[Dict[str, Dict[str, Any]]] = None) -> Dict[str, Any]:
    trace_map = trace_map or _v348_trace_map()
    t = norm_ticker(ev.get('ticker') or ev.get('market') or ev.get('symbol'))
    sk = _primary_strategy_key(ev) or str(ev.get('strategy_key') or ev.get('strategy') or '')
    keys = [str(ev.get('event_id') or ''), str(ev.get('event_key') or ''), str(ev.get('trace_id') or ''), str(ev.get('handoff_id') or ''), str(ev.get('candidate_uid') or ''), f'{t}:{sk}']
    for k in keys:
        if k and k in trace_map:
            return trace_map[k]
    return {}


def _v348_reason_from_trace(ev: Dict[str, Any], trace: Dict[str, Any], fallback: str = '') -> str:
    vals: List[str] = []
    for src in (trace, ev):
        for key in ('reason', 'missed_reason', 'status_reason'):
            v = src.get(key) if isinstance(src, dict) else None
            if isinstance(v, list):
                vals += [str(x) for x in v if str(x)]
            elif v not in (None, '', '-'):
                vals += [x.strip() for x in str(v).split(',') if x.strip()]
    if fallback:
        vals += [x.strip() for x in str(fallback).split(',') if x.strip()]
    if trace:
        st = str(trace.get('status') or '')
        if st and st not in {'candidate','unknown'}:
            vals.append(st)
    out=[]
    for v in vals:
        if v and v not in out:
            out.append(v)
    return ','.join(out[:6]) if out else 'paper미병합/만료확인'


def missed_trace_text() -> str:
    obj = load_json(FILES.get('candidate_handoff_trace', BASE_DIR/'paper_bot_candidate_handoff_trace.json'), {}) or {}
    rows = _v348_trace_rows()
    by_status = Counter(str(r.get('status') or 'unknown') for r in rows)
    reasons = Counter()
    for r in rows:
        for x in str(r.get('reason') or '').split(','):
            x=x.strip()
            if x: reasons[x]+=1
    lines = [
        '🧭 놓친 후보 추적 /missed_trace',
        '- strategy 후보 → handoff → paper 병합/OPEN/CLOSED 흐름을 추적합니다.',
        f"- trace age {age(FILES.get('candidate_handoff_trace', BASE_DIR/'paper_bot_candidate_handoff_trace.json')):.1f}s / rows {len(rows)} / version {obj.get('version','-') if isinstance(obj,dict) else '-'}",
        '', '[상태 TOP]'
    ]
    if by_status:
        for k,v in by_status.most_common(8):
            icon = '✅' if k in {'open','closed'} else '⚠️' if k in {'expired','not_merged','merged_waiting_open'} else '❔'
            lines.append(f'- {icon} {k}: {v}개')
    else:
        lines.append('- trace 없음')
    lines += ['', '[이유 TOP]']
    if reasons:
        for k,v in reasons.most_common(10):
            icon = '⚠️' if k in {'paper미병합','handoff만료','후보오래됨','micro미확인','picked_not_opened'} else '❔'
            lines.append(f'- {icon} {k}: {v}개')
    else:
        lines.append('- 이유 없음')
    lines += ['', '[주의 후보 TOP]']
    risky = [r for r in rows if str(r.get('status') or '') not in {'open','closed'}]
    risky.sort(key=lambda r: (float(first_value(r.get('score'),0) or 0), float(first_value(r.get('created_at'),0) or 0)), reverse=True)
    seen_risky=set(); shown=0
    for r in risky:
        t = norm_ticker(r.get('ticker'))
        sk = str(r.get('strategy_key') or r.get('strategy') or '-')
        key = f'{t}:{sk}:{r.get("status","-")}:{r.get("reason","-")}'
        if key in seen_risky:
            continue
        seen_risky.add(key); shown += 1
        lines.append(f"- ⚠️ {t} / {r.get('strategy') or r.get('strategy_key','-')} / score {r.get('score','-')} / status {r.get('status','-')} / 이유 {r.get('reason','-')}")
        if shown >= 10:
            break
    if not risky:
        lines.append('- 현재 주의 후보 없음')
    elif len(seen_risky) < len(risky):
        lines.append(f'- 중복 후보 {len(risky)-len(seen_risky)}개는 묶어서 숨김')
    return '\n'.join(lines)


def pmissed_review_text() -> str:  # type: ignore[override]
    anchor_ts = _paper_anchor_ts()
    events=[]
    for name,maxn in [('paper_candidates.jsonl',1200),('paper_candidates_latest.jsonl',300)]:
        events += read_jsonl(BASE_DIR/name, max_lines=maxn)
    market = _market_price_map()
    open_ids, closed_ids, open_tickers = _open_closed_keys()
    trace_map = _v348_trace_map()
    nowv=now_ts(); watched=0; by_key: Dict[str, Dict[str, Any]] = {}; reason_counter=Counter()
    for raw in events:
        if not isinstance(raw, dict):
            continue
        ev = ensure_event_id(raw)
        ts = float(first_value(ev.get('created_at'), ev.get('candidate_created_at'), ev.get('detected_ts'), ev.get('event_ts'), 0) or 0)
        if anchor_ts and ts and ts < anchor_ts:
            continue
        t=norm_ticker(ev.get('ticker') or ev.get('market') or ev.get('symbol'))
        if not t:
            continue
        watched += 1
        keys=_candidate_keys(ev)
        if (keys & open_ids) or (keys & closed_ids) or t in open_tickers:
            continue
        cur = market.get(t, {})
        cur_price = price_from_any(cur)
        entry = float(first_value(ev.get('entry_price'), ev.get('current_price'), ev.get('detected_price'), ev.get('price'), 0) or 0)
        if cur_price <= 0 or entry <= 0:
            continue
        gain = (cur_price-entry)/entry*100.0
        if gain < 0.70:
            continue
        trace = _v348_trace_for_candidate(ev, trace_map)
        why = _v348_reason_from_trace(ev, trace, _missed_reason(ev, set()))
        for x in why.split(','):
            if x: reason_counter[x]+=1
        sk = _primary_strategy_key(ev) or str(ev.get('strategy_key') or ev.get('strategy') or '')
        dedupe = f'{t}:{sk}'
        item = {'ticker':t,'gain':gain,'strategy':ev.get('strategy_bucket_primary_label') or ev.get('strategy_name') or ev.get('strategy') or trace.get('strategy'), 'score':ev.get('score') or trace.get('score'), 'reasons':ev.get('reasons') or ev.get('final_entry_reasons') or [], 'missed_reason':why, 'trace_status':trace.get('status','-') if trace else '-'}
        old = by_key.get(dedupe)
        if old is None or gain > float(old.get('gain',0)):
            by_key[dedupe]=item
    missed=list(by_key.values()); missed.sort(key=lambda x:x.get('gain',0), reverse=True)
    lines=['🔎 놓친 후보 복기 /pmissed_review · 메인봇 캐시전용', '- 후보 archive/latest 중 OPEN/CLOSED로 이어지지 않았는데 이후 오른 코인을 봅니다.', f'- 확인 후보 {watched}개 / 중복제거 상승후보 {len(missed)}개', '', '[놓친 이유 추정 TOP]']
    if reason_counter:
        for k,v in reason_counter.most_common(10):
            icon='⚠️' if k in {'paper미병합','handoff만료','후보오래됨','micro미확인','picked_not_opened'} else '❔'
            lines.append(f'- {icon} {k}: {v}개')
    else:
        lines.append('- 아직 분류할 상승후보 없음')
    lines += ['', '[이후 오른 후보 TOP]']
    if missed:
        for m in missed[:10]:
            rs=m.get('reasons') if isinstance(m.get('reasons'), list) else []
            lines.append(f"- {'⚠️' if m['gain']>=1.5 else '❔'} {m['ticker']} / +{m['gain']:.2f}% / {m.get('strategy','-')} / 점수 {m.get('score','-')} / 상태 {m.get('trace_status','-')} / 놓친이유 {m.get('missed_reason','-')} / 근거 {', '.join(map(str, rs[:3]))}")
    else:
        lines.append('- 아직 뚜렷한 놓친 상승후보 없음')
    lines += ['', '[판독]', '- 자주 오르는 패턴은 조건에서 죽이면 안 됨', '- paper미병합/만료/오래됨이 많으면 전략조건보다 handoff·진입타이밍 문제를 먼저 봅니다', '- 손실필터는 /ploss_review와 같이 봐야 합니다']
    return '\n'.join(lines)


def preview_text() -> str:  # type: ignore[override]
    parts=[]
    for title, fn in [('ploss_review', ploss_review_text), ('pmissed_review', pmissed_review_text)]:
        try:
            parts.append(fn())
        except Exception as exc:
            log_error(f'preview_{title}', exc)
            parts.append(f'⚠️ {title} 출력 오류: {type(exc).__name__}: {exc}')
    return '\n\n'.join(parts)



# =============================================================================
# v354: main review canonical final layer
# v355: score cache version gate는 목록식 whitelist 대신 paper_bot_v0.86+ 숫자 판정으로 단일화
# - preview/missed_trace에서 이름 누락/중복 override가 다시 타지 않도록 최종 단일 함수를 둔다.
# - 전략/청산/자동매수에는 관여하지 않고, paper_bot_v0.92 trace/cache를 읽는 조회 전용이다.
# =============================================================================

def _v354_trace_rows() -> List[Dict[str, Any]]:
    obj = load_json(FILES.get('candidate_handoff_trace', BASE_DIR/'paper_bot_candidate_handoff_trace.json'), {}) or {}
    rows = obj.get('rows') if isinstance(obj, dict) else []
    return [r for r in rows if isinstance(r, dict)] if isinstance(rows, list) else []

def _v354_trace_map() -> Dict[str, Dict[str, Any]]:
    out: Dict[str, Dict[str, Any]] = {}
    priority = {'closed': 60, 'open': 55, 'picked': 50, 'merged_waiting_pick': 40, 'micro_wait': 35, 'not_merged': 25, 'expired': 10, 'skipped': 5}
    for r in _v354_trace_rows():
        t = norm_ticker(r.get('ticker') or r.get('market') or r.get('symbol'))
        sk = _primary_strategy_key(r) or str(r.get('strategy_key') or r.get('strategy') or '')
        ts = fnum(r.get('created_at') or r.get('updated_at'), default=0.0)
        keys = [r.get('event_id'), r.get('event_key'), r.get('trace_id'), r.get('handoff_id'), r.get('candidate_uid'), f'{t}:{sk}']
        for k in keys:
            k=str(k or '')
            if not k or k == '-':
                continue
            old = out.get(k)
            if old is None:
                out[k] = r
                continue
            old_score = priority.get(str(old.get('status') or ''), 0)
            new_score = priority.get(str(r.get('status') or ''), 0)
            old_ts = fnum(old.get('created_at') or old.get('updated_at'), default=0.0)
            # 같은 ticker:strategy 키에서 과거 expired가 최신 open/closed/picked를 덮지 못하게 한다.
            if (new_score, ts) > (old_score, old_ts):
                out[k] = r
    return out

def _v354_trace_for_candidate(ev: Dict[str, Any], trace_map: Optional[Dict[str, Dict[str, Any]]] = None) -> Dict[str, Any]:
    trace_map = trace_map or _v354_trace_map()
    row = _candidate_norm(ev)
    t = norm_ticker(row.get('ticker') or row.get('market') or row.get('symbol'))
    sk = _primary_strategy_key(row) or str(row.get('strategy_key') or row.get('strategy') or '')
    keys = [row.get('event_id'), row.get('event_key'), row.get('trace_id'), row.get('handoff_id'), row.get('candidate_uid'), f'{t}:{sk}']
    for k in keys:
        k=str(k or '')
        if k and k in trace_map:
            return trace_map[k]
    return {}

def _v354_reason_from_trace(ev: Dict[str, Any], trace: Dict[str, Any], fallback: str = '') -> str:
    vals: List[str] = []
    for src in (trace, ev):
        if not isinstance(src, dict):
            continue
        for key in ('reason', 'missed_reason', 'status_reason'):
            v = src.get(key)
            if isinstance(v, list):
                vals += [str(x).strip() for x in v if str(x).strip()]
            elif v not in (None, '', '-'):
                vals += [x.strip() for x in str(v).split(',') if x.strip()]
    if fallback:
        vals += [x.strip() for x in str(fallback).split(',') if x.strip()]
    if trace:
        st=str(trace.get('status') or '')
        if st and st not in {'candidate','unknown'}:
            vals.append(st)
    out=[]
    for v in vals:
        if v and v not in out:
            out.append(v)
    return ','.join(out[:6]) if out else 'paper미병합/만료확인'

def missed_trace_text() -> str:  # type: ignore[override]
    obj = load_json(FILES.get('candidate_handoff_trace', BASE_DIR/'paper_bot_candidate_handoff_trace.json'), {}) or {}
    rows = _v354_trace_rows()
    by_status = Counter(str(r.get('status') or 'unknown') for r in rows)
    reasons = Counter()
    for r in rows:
        for x in str(r.get('reason') or '').split(','):
            x=x.strip()
            if x: reasons[x]+=1
    lines = [
        '🧭 놓친 후보 추적 /missed_trace',
        '- strategy 후보 → handoff → paper 병합/OPEN/CLOSED 흐름을 추적합니다.',
        f"- trace age {age(FILES.get('candidate_handoff_trace', BASE_DIR/'paper_bot_candidate_handoff_trace.json')):.1f}s / rows {len(rows)} / version {obj.get('version','-') if isinstance(obj,dict) else '-'}",
        '', '[상태 TOP]'
    ]
    if by_status:
        for k,v in by_status.most_common(10):
            icon = '✅' if k in {'open','closed','picked'} else '⚠️' if k in {'expired','not_merged','merged_waiting_pick','micro_wait','skipped'} else '❔'
            lines.append(f'- {icon} {k}: {v}개')
    else:
        lines.append('- trace 없음')
    lines += ['', '[이유 TOP]']
    if reasons:
        for k,v in reasons.most_common(10):
            icon = '⚠️' if k in {'paper미병합','handoff만료','후보오래됨','micro미확인','picked_not_opened'} else '❔'
            lines.append(f'- {icon} {k}: {v}개')
    else:
        lines.append('- 이유 없음')
    lines += ['', '[주의 후보 TOP]']
    risky = [r for r in rows if str(r.get('status') or '') not in {'open','closed'}]
    risky.sort(key=lambda r: (float(first_value(r.get('score'),0) or 0), float(first_value(r.get('created_at'),0) or 0)), reverse=True)
    for r in risky[:10]:
        lines.append(f"- ⚠️ {norm_ticker(r.get('ticker'))} / {r.get('strategy') or r.get('strategy_key','-')} / score {r.get('score','-')} / status {r.get('status','-')} / 이유 {r.get('reason','-')}")
    if not risky:
        lines.append('- 현재 주의 후보 없음')
    return '\n'.join(lines)

def _v358_recent_review_events() -> List[Dict[str, Any]]:
    """v358: /pmissed_review 기본판은 오래된 archive 전체를 다시 훑지 않는다.

    trace 수술 이후 기본 복기는 latest/handoff/actual trace 중심으로만 본다.
    archive 전체 재검사는 나중에 full 명령으로 분리할 대상이며, 기본 명령에서
    handoff만료/paper미병합을 과대표시하지 않게 한다.
    """
    events: List[Dict[str, Any]] = []
    seen: set[str] = set()
    for name, maxn in [('paper_candidates_latest.jsonl', 250), ('paper_candidates_handoff_merged.jsonl', 300)]:
        for ev in read_jsonl(BASE_DIR/name, max_lines=maxn):
            if not isinstance(ev, dict):
                continue
            key = str(ev.get('event_id') or ev.get('event_key') or ev.get('candidate_uid') or '')
            t = norm_ticker(ev.get('ticker') or ev.get('market') or ev.get('symbol'))
            ts = str(first_value(ev.get('created_at'), ev.get('candidate_created_at'), ev.get('event_ts'), ''))
            sk = str(_primary_strategy_key(ev) or ev.get('strategy_key') or ev.get('strategy') or '')
            dk = key or f'{t}:{sk}:{ts}'
            if dk in seen:
                continue
            seen.add(dk)
            events.append(ev)
    # actual trace도 후보 추적 기준으로만 보강한다. 오래된 source/archive trace fallback은 쓰지 않는다.
    obj = load_json(FILES.get('candidate_handoff_trace', BASE_DIR/'paper_bot_candidate_handoff_trace.json'), {}) or {}
    rows = obj.get('rows') if isinstance(obj, dict) else []
    if isinstance(rows, list):
        for r in rows[:300]:
            if not isinstance(r, dict):
                continue
            key = str(r.get('event_id') or r.get('event_key') or r.get('candidate_uid') or r.get('trace_id') or '')
            t = norm_ticker(r.get('ticker') or r.get('market') or r.get('symbol'))
            ts = str(first_value(r.get('created_at'), r.get('candidate_created_at'), r.get('event_ts'), ''))
            sk = str(_primary_strategy_key(r) or r.get('strategy_key') or r.get('strategy') or '')
            dk = key or f'trace:{t}:{sk}:{ts}'
            if dk in seen:
                continue
            seen.add(dk)
            events.append(r)
    return events


def pmissed_review_text() -> str:  # type: ignore[override]
    """v358 기본 missed 복기.

    기본 명령은 latest/handoff/actual trace만 본다. archive 전체 재검사는 렉과
    과대표시를 만들 수 있으므로 기본 경로에서 제외한다.
    """
    anchor_ts = _paper_anchor_ts()
    events = _v358_recent_review_events()
    market = _market_price_map()
    open_ids, closed_ids, open_tickers = _open_closed_keys()
    trace_map = _v354_trace_map()
    watched=0; by_key: Dict[str, Dict[str, Any]] = {}; reason_counter=Counter()
    for raw in events:
        if not isinstance(raw, dict):
            continue
        ev = _candidate_norm(raw)
        ts = float(first_value(ev.get('created_at'), ev.get('candidate_created_at'), ev.get('detected_ts'), ev.get('event_ts'), 0) or 0)
        if anchor_ts and ts and ts < anchor_ts:
            continue
        t=norm_ticker(ev.get('ticker') or ev.get('market') or ev.get('symbol'))
        if not t:
            continue
        watched += 1
        keys=_candidate_keys(ev)
        if (keys & open_ids) or (keys & closed_ids) or t in open_tickers:
            continue
        cur_price = price_from_any(market.get(t, {}))
        entry = float(first_value(ev.get('entry_price'), ev.get('current_price'), ev.get('detected_price'), ev.get('price'), 0) or 0)
        if cur_price <= 0 or entry <= 0:
            continue
        gain = (cur_price-entry)/entry*100.0
        if gain < 0.70:
            continue
        trace = _v354_trace_for_candidate(ev, trace_map)
        why = _v354_reason_from_trace(ev, trace, _missed_reason(ev, set()))
        for x in why.split(','):
            if x: reason_counter[x]+=1
        sk = _primary_strategy_key(ev) or str(ev.get('strategy_key') or ev.get('strategy') or '')
        dedupe = f'{t}:{sk}'
        item = {'ticker':t,'gain':gain,'strategy':ev.get('strategy_bucket_primary_label') or ev.get('strategy_name') or ev.get('strategy') or trace.get('strategy'), 'score':ev.get('score') or trace.get('score'), 'reasons':ev.get('reasons') or ev.get('final_entry_reasons') or [], 'missed_reason':why, 'trace_status':trace.get('status','-') if trace else '-'}
        old=by_key.get(dedupe)
        if old is None or gain > float(old.get('gain',0)):
            by_key[dedupe]=item
    missed=list(by_key.values()); missed.sort(key=lambda x:x.get('gain',0), reverse=True)
    lines=['🔎 놓친 후보 복기 /pmissed_review · 메인봇 캐시전용', '- 기본 범위: latest/handoff/actual trace 중심. archive 전체 재검사는 기본에서 제외.', f'- 확인 후보 {watched}개 / 중복제거 상승후보 {len(missed)}개', '', '[놓친 이유 추정 TOP]']
    if reason_counter:
        for k,v in reason_counter.most_common(8):
            icon='⚠️' if k in {'paper미병합','handoff만료','후보오래됨','micro미확인','picked_not_opened'} else '❔'
            lines.append(f'- {icon} {k}: {v}개')
    else:
        lines.append('- 아직 분류할 상승후보 없음')
    lines += ['', '[이후 오른 후보 TOP]']
    if missed:
        for m in missed[:5]:
            rs=m.get('reasons') if isinstance(m.get('reasons'), list) else []
            lines.append(f"- {'⚠️' if m['gain']>=1.5 else '❔'} {m['ticker']} / +{m['gain']:.2f}% / {m.get('strategy','-')} / 점수 {m.get('score','-')} / 상태 {m.get('trace_status','-')} / 놓친이유 {m.get('missed_reason','-')} / 근거 {', '.join(map(str, rs[:3]))}")
    else:
        lines.append('- 아직 뚜렷한 놓친 상승후보 없음')
    lines += ['', '[판독]', '- 기본판에서 paper미병합/만료가 많으면 handoff·paper 병합 타이밍을 봅니다', '- 전략조건 수정은 score/trace가 정상 출력된 뒤 판단합니다']
    return '\n'.join(lines)


def _v358_trim_loss_preview(txt: str) -> str:
    lines = txt.splitlines()
    out: List[str] = []
    keep = True
    for ln in lines:
        if ln.startswith('[전략별 손실 원인'):
            keep = False
            continue
        if ln.startswith('[조건 설계 힌트]'):
            keep = True
        if keep:
            out.append(ln)
        if len(out) >= 18:
            break
    if '[전략별 손실 원인 · 대표전략 기준]' in txt:
        out += ['', '- 전략별 상세 손실은 /ploss_review에서 확인']
    return '\n'.join(out)


def preview_text() -> str:  # type: ignore[override]
    """v358 기본 preview 경량화.

    전체 상세를 반복 출력하지 않고 손실 TOP + missed 기본판만 묶는다.
    """
    parts=[]
    try:
        parts.append(_v358_trim_loss_preview(ploss_review_text()))
    except Exception as exc:
        log_error('preview_ploss_review', exc)
        parts.append(f'⚠️ ploss_review 출력 오류: {type(exc).__name__}: {exc}')
    try:
        parts.append(pmissed_review_text())
    except Exception as exc:
        log_error('preview_pmissed_review', exc)
        parts.append(f'⚠️ pmissed_review 출력 오류: {type(exc).__name__}: {exc}')
    return '\n\n'.join(parts)




# =============================================================================
# v365: 버전별 성과판 복구
# - v349~v364 결과가 한 장부에 섞이면 현재 수정 효과를 판단하기 어렵다.
# - /version_score는 paper CLOSED를 직접 읽어 brain version별 승률/손익/손실패턴을 분리한다.
# - score cache fallback을 만들지 않고, 조회 전용으로만 계산한다.
# =============================================================================

def _v365_norm_version_from_row(row: Dict[str, Any]) -> str:
    row = as_dict(row)
    ctx = as_dict(row.get('entry_context'))
    raw = as_dict(row.get('raw'))
    vals = [
        row.get('opened_brain_version'), row.get('brain_version'), row.get('main_version'), row.get('bot_version'),
        ctx.get('opened_brain_version'), ctx.get('brain_version'), ctx.get('main_version'), ctx.get('bot_version'),
        raw.get('opened_brain_version'), raw.get('brain_version'), raw.get('main_version'), raw.get('bot_version'),
    ]
    for v in vals:
        s = str(v or '').strip()
        if not s:
            continue
        m = re.search(r'v?2[._]13[._](\d+)', s)
        if m:
            return f"v2.13.{int(m.group(1))}"
        m = re.search(r'v(\d{3,})', s)
        if m:
            return f"v2.13.{int(m.group(1))}"
        return s[:32]
    return '버전 미기록'


def _v365_closed_ts(row: Dict[str, Any]) -> float:
    return fnum(row.get('closed_at'), row.get('closed_ts'), row.get('close_ts'), row.get('exit_ts'), row.get('timestamp'), row.get('updated_at'), default=0.0)


def _v365_pnl(row: Dict[str, Any]) -> float:
    return fnum(row.get('pnl_pct'), row.get('profit_pct'), row.get('return_pct'), row.get('profit_rate_pct'), default=0.0)


def _v365_strategy_key(row: Dict[str, Any]) -> str:
    key = _strategy_key_from_row(row) if '_strategy_key_from_row' in globals() else str(row.get('strategy_key') or row.get('strategy') or 'unknown')
    return key or 'unknown'


def _v365_stat(rows: List[Dict[str, Any]]) -> Dict[str, Any]:
    n=len(rows)
    wins=sum(1 for r in rows if _v365_pnl(r)>0)
    losses=sum(1 for r in rows if _v365_pnl(r)<0)
    total=sum(_v365_pnl(r) for r in rows)
    avg=total/n if n else 0.0
    fast=sum(1 for r in rows if _v365_pnl(r)<0 and fnum(r.get('hold_sec'), r.get('duration_sec'), default=999999) <= 300)
    hard=sum(1 for r in rows if '하드' in str(r.get('exit_reason') or r.get('exit_label') or r.get('close_reason') or '') or _v365_pnl(r) <= -0.95)
    no_react=sum(1 for r in rows if _v365_pnl(r)<0 and fnum(r.get('peak_pct'), r.get('max_profit_pct'), r.get('max_pnl_pct'), default=0.0) <= 0.10)
    hold_avg=sum(fnum(r.get('hold_sec'), r.get('duration_sec'), default=0.0) for r in rows)/n if n else 0.0
    return {'n':n,'wins':wins,'losses':losses,'win_rate':(wins/n*100.0 if n else 0.0),'total':total,'avg':avg,'fast':fast,'hard':hard,'no_react':no_react,'hold_avg':hold_avg}


def _v365_stat_line(label: str, rows: List[Dict[str, Any]]) -> str:
    st=_v365_stat(rows)
    sample = ' ⚠️표본적음' if 0 < st['n'] < 10 else ''
    return f"- {label}: {st['n']}전 {st['wins']}승 {st['losses']}패 / 승률 {st['win_rate']:.1f}% / 합산 {st['total']:+.2f}% / 평균 {st['avg']:+.2f}%{sample} / 5분내손실 {st['fast']} / 하드손실 {st['hard']} / 무반응손실 {st['no_react']}"


def version_score_text() -> str:
    rows = [r for r in read_jsonl(FILES.get('paper_closed', BASE_DIR/'paper_bot_closed.jsonl'), max_lines=30000) if isinstance(r, dict)]
    groups: Dict[str, List[Dict[str, Any]]] = {}
    for r in rows:
        groups.setdefault(_v365_norm_version_from_row(r), []).append(r)
    items=[]
    for ver, arr in groups.items():
        latest=max((_v365_closed_ts(r) for r in arr), default=0.0)
        # 버전 미기록은 아래로 보낸다.
        if ver == '버전 미기록': latest = -1
        items.append((latest, ver, arr))
    items.sort(reverse=True)
    lines=[
        '📊 버전별 성과 /version_score',
        '- 목적: v349~현재 결과가 섞이지 않게 버전별 승률·손익을 따로 봅니다.',
        '- 기준: paper CLOSED 전체 장부 직접 조회 / 기본 score cache와 별도',
        '',
        '[최근 버전별 요약]'
    ]
    if not items:
        lines.append('- 아직 CLOSED 장부 없음')
        return '\n'.join(lines)
    for _, ver, arr in items[:12]:
        icon='✅' if _v365_stat(arr).get('total',0)>0 else ('⚠️' if len(arr)<10 else '❌')
        lines.append(_v365_stat_line(f'{icon} {ver}', arr))
    latest_ver = items[0][1]
    latest_rows = items[0][2]
    strat_groups: Dict[str, List[Dict[str, Any]]] = {}
    for r in latest_rows:
        strat_groups.setdefault(_v365_strategy_key(r), []).append(r)
    label_map={'money_reaccel_s':'돈흐름 재가속','leader_momentum_s':'주도추세 지속','breakout_early_s':'돌파 초입','sweep_vwap_recovery_s':'저점 VWAP 회복','surge_rebreak_s':'급등 후 재돌파','leader_flow_adaptive_hold_s':'주도흐름 유동보유','unknown':'대표전략 미확인'}
    lines += ['', f'[최근 버전 전략별 · {latest_ver}]']
    for k, arr in sorted(strat_groups.items(), key=lambda kv: len(kv[1]), reverse=True)[:8]:
        lines.append(_v365_stat_line(label_map.get(k,k), arr))
    lines += ['', '[판독]', '- 현재 /score는 현재판 anchor 기준이고, /version_score는 버전별 장부 기준입니다.', '- 새 조건 효과는 최신 버전 줄만 보고, 예전 손실은 참고로만 봅니다.']
    return '\n'.join(lines)

COMMANDS={'health':health_text,'core':health_text,'workers':workers_text,'score':score_text,'version_score':version_score_text,'vscore':version_score_text,'quality':quality_text,'strategy_watch':strategy_watch_text,'pipe_check':pipe_check_text,'pstatus':pstatus_text,'pscore':pscore_text,'popen':popen_text,'ploss_review':ploss_review_text,'pmissed_review':pmissed_review_text,'preview':preview_text,'loss_review':ploss_review_text,'missed_review':pmissed_review_text,'missed_trace':missed_trace_text,'trace_missed':missed_trace_text,'errorlog':errorlog_text,'popen_short':open_text}

def send(update, text:str)->None:
    try:
        # Telegram hard limit 보호
        if len(text)>3900: text=text[:3850]+"\n…(길어 일부만 표시)"
        update.message.reply_text(text)
    except Exception as exc: log_error('telegram_send',exc)

def make_handler(name:str):
    def h(update, context):
        try:
            txt = getattr(update.message, 'text', '') or ''
            lines = [x.strip().lstrip('/') for x in txt.splitlines() if x.strip().startswith('/')]
            if len(lines) >= 2:
                context.args = lines[:12]
                return batch_handler(update, context)
            send(update, COMMANDS[name]())
        except Exception as exc:
            log_error(f'cmd_{name}',exc); send(update, f"❌ /{name} 오류: {exc.__class__.__name__}: {exc}")
    return h

def batch_handler(update, context):
    cmds=context.args or ['health','score','quality','strategy_watch','errorlog']
    cmds=[str(x).strip().lstrip('/') for x in cmds[:12] if str(x).strip()]
    st=time.time(); sent=0; timings=[]
    try:
        send(update, f"📦 자동 묶음 명령 접수\n- 실행 {len(cmds)}개\n- v369: S2/S3 관찰·trace·최근3버전 성과 수술")
    except Exception:
        pass
    total=len(cmds)
    for raw in cmds:
        name=raw.strip().lstrip('/')
        fn=COMMANDS.get(name)
        if not fn:
            continue
        t=time.time()
        try:
            body=fn()
            ok="OK"
        except Exception as exc:
            body=f"❌ /{name} 오류 {exc.__class__.__name__}: {exc}"
            ok="ERR"
            log_error(f'batch_{name}', exc)
        sec=time.time()-t
        sent += 1
        timings.append(f"- {'✅' if ok=='OK' else '❌'} /{name}: {sec:.2f}s / {ok}")
        send(update, f"[{sent}/{total}] /{name} ({sec:.2f}s / {ok})\n{body}")
    send(update, "🧾 자동 묶음 시간표 · v369 명령별 전송\n"+"\n".join(timings)+f"\n- 합계 {time.time()-st:.2f}s")

def text_router(update, context):
    try:
        txt=update.message.text or ''
        lines=[x.strip().lstrip('/') for x in txt.splitlines() if x.strip().startswith('/')]
        if len(lines)>=2:
            context.args=lines[:12]; return batch_handler(update, context)
    except Exception as exc: log_error('text_router',exc)

def set_commands(updater):
    try:
        updater.bot.set_my_commands([BotCommand('health','메인/worker/paper 빠른상태'),BotCommand('workers','worker 상세 상태'),BotCommand('score','S1/S2/S3 성과'),BotCommand('version_score','버전별/진입유형 성과'),BotCommand('quality','S1/S2/S3 후보와 탈락사유'),BotCommand('pstatus','paper 상태'),BotCommand('popen','모의매매 진행중'),BotCommand('preview','손실+놓친후보 복기'),BotCommand('missed_trace','후보 handoff 추적'),BotCommand('errorlog','오류로그'),BotCommand('batch','묶음 확인')])
    except Exception as exc: log_error('set_commands',exc)

def startup_notify(updater):
    try:
        if not CHAT_ID:
            return
        text=(
            f"✅ 메인봇 시작 완료\n"
            f"- 버전: {BOT_VERSION}\n"
            f"- 구조: clean worker hub v369\n"
            f"- 명령: /health /score /quality /pstatus /popen /preview /errorlog"
        )
        updater.bot.send_message(chat_id=CHAT_ID, text=text)
    except Exception as exc:
        log_error('startup_notify', exc)

def heartbeat_loop():
    while True:
        try:
            update_brain_status('running')
        except Exception as exc:
            log_error('heartbeat', exc)
        time.sleep(10)

def main():
    log_runtime(f"telegram_state=initializing version={BOT_VERSION}")
    update_brain_status('initializing')
    if not TELEGRAM_TOKEN:
        print('TELEGRAM_TOKEN missing; worker hub status only')
        while True:
            update_brain_status('running_no_telegram'); time.sleep(5)
    updater=Updater(token=TELEGRAM_TOKEN, use_context=True)
    dp=updater.dispatcher
    for name in COMMANDS: dp.add_handler(CommandHandler(name, make_handler(name)))
    dp.add_handler(CommandHandler('batch', batch_handler))
    if MessageHandler is not None and Filters is not None: dp.add_handler(MessageHandler(Filters.text & (~Filters.command), text_router))
    set_commands(updater)
    log_runtime(f"telegram_state=commands_installed version={BOT_VERSION}")
    update_brain_status('running')
    threading.Thread(target=heartbeat_loop, daemon=True).start()
    updater.start_polling(drop_pending_updates=True)
    startup_notify(updater)
    log_runtime(f"{BOT_VERSION} telegram polling_started")
    log_runtime("telegram_state=running error=-")
    updater.idle()






# =============================================================================
# v366: 버전표시 단일화 - tail override도 현재 버전으로 고정
# v358: S 단일 등급을 S1/S2/S3로 분리해 표시/성과판 단일화
# - S1: 즉시 paper OPEN 대상
# - S2: 재확인 대기 후보
# - S3: 관찰/복기 후보
# - 기존 A/B/C 기본 출력은 제거하고, 과거 S/A는 S1로, B/C는 S3로만 호환 표시한다.
# =============================================================================
BOT_VERSION = "수익형 v2.13.389"
CLEAN_WORKER_HUB_LABEL = "clean worker hub v369"

def _v358_stage_from_row(row: Dict[str, Any]) -> str:
    ctx = row.get('entry_context') if isinstance(row.get('entry_context'), dict) else {}
    g = str(row.get('s_stage') or row.get('candidate_grade') or row.get('grade') or row.get('entry_grade') or row.get('signal_grade') or ctx.get('s_stage') or ctx.get('candidate_grade') or '').upper().strip()
    if g in {'S1','S2','S3','X'}:
        return g
    if g in {'S','A'}:
        return 'S1'
    if g in {'B','C'}:
        return 'S3'
    label = str(row.get('candidate_grade_label') or ctx.get('candidate_grade_label') or '')
    if 'S1' in label or '즉시' in label:
        return 'S1'
    if 'S2' in label or '재확인' in label:
        return 'S2'
    if 'S3' in label or '관찰' in label or '복기' in label:
        return 'S3'
    if '제외' in label or '차단' in label or '금지' in label:
        return 'X'
    return 'S1'

def _v358_stage_label(stage: str) -> str:
    return {
        'S1': '✅ S1 즉시진입',
        'S2': '⚠️ S2 재확인',
        'S3': '❔ S3 관찰복기',
        'X': '❌ 제외',
    }.get(str(stage or '').upper(), str(stage or '-'))

def _v358_stage_counts_from_latest(max_lines: int = 300) -> Counter:
    c = Counter()
    try:
        for r in read_jsonl(FILES['paper_latest'], max_lines=max_lines):
            if isinstance(r, dict): c[_v358_stage_from_row(r)] += 1
    except Exception:
        pass
    return c

def _paper_grade(row: Dict[str, Any]) -> str:  # type: ignore[override]
    return _v358_stage_from_row(row)



def _v401_closed_rows(max_lines: int = 2600) -> List[Dict[str, Any]]:
    rows = read_jsonl(FILES.get('paper_closed', BASE_DIR/'paper_bot_closed.jsonl'), max_lines=max_lines)
    return [r for r in rows if isinstance(r, dict) and str(r.get('closed_paper_version') or r.get('paper_version') or r.get('opened_paper_version') or '') == 'paper_bot_v0.125']


def _v401_stat(rows: List[Dict[str, Any]]) -> Dict[str, Any]:
    n = len(rows)
    wins = sum(1 for r in rows if fnum(r.get('pnl_pct'), r.get('profit_pct'), default=0.0) > 0)
    total = sum(fnum(r.get('pnl_pct'), r.get('profit_pct'), default=0.0) for r in rows)
    return {'n': n, 'wins': wins, 'losses': n - wins, 'win_rate': (wins / n * 100.0) if n else 0.0, 'total': total, 'avg': (total / n) if n else 0.0}


def _v401_grade(row: Dict[str, Any]) -> str:
    g = str(row.get('candidate_grade') or row.get('entry_grade') or row.get('s_stage') or row.get('grade') or 'S1').upper()
    return 'S1' if g in {'S', 'STRICT'} else (g if g in {'S1','S2','S3','X'} else 'S1')


def _v401_strategy_key(row: Dict[str, Any]) -> str:
    try:
        k = _primary_strategy_key(row)
        if k and k != 'unknown': return k
    except Exception: pass
    text = str(row.get('strategy_key') or row.get('strategy') or row.get('strategy_label') or '')
    for k, label in STRATEGY_LABELS.items():
        if k in text or label in text: return k
    return 'unknown'


def _v401_recent_closed(rows: List[Dict[str, Any]], limit: int = 5) -> List[str]:
    if not rows: return ['- 아직 v0.125 CLOSED 없음']
    out=[]
    for r in sorted(rows, key=lambda x: fnum(x.get('closed_at'), x.get('closed_ts'), default=0.0), reverse=True)[:limit]:
        out.append(f"- {norm_ticker(r.get('ticker'))} / {fnum(r.get('pnl_pct'), r.get('profit_pct'), default=0.0):+.2f}% / {r.get('exit_rule_label') or r.get('exit_reason') or '-'} / 보유 {fnum(r.get('age_min'), default=0.0):.1f}분")
    return out

def score_text()->str:  # type: ignore[override]
    rows = _v401_closed_rows()
    by_grade = {'S1': [], 'S2': [], 'S3': [], 'X': []}
    by_strategy: Dict[str, List[Dict[str, Any]]] = {}
    for r in rows:
        by_grade.setdefault(_v401_grade(r), []).append(r)
        by_strategy.setdefault(_v401_strategy_key(r), []).append(r)
    label_map = {'money_reaccel_s':'돈흐름 재가속','leader_momentum_s':'주도추세 지속','breakout_early_s':'돌파 초입','sweep_vwap_recovery_s':'저점 VWAP 회복','surge_rebreak_s':'급등 후 재돌파','leader_flow_adaptive_hold_s':'주도흐름 유동보유'}
    lines=[
        '📊 S1/S2/S3 스코어 /score',
        '- 기준: paper_bot_v0.125 CLOSED 장부 직접조회. 구 score cache는 기본 성과판에서 사용하지 않습니다.',
        f"- 장부 age {age(FILES.get('paper_closed', BASE_DIR/'paper_bot_closed.jsonl')):.1f}s / v0.125 CLOSED {len(rows)}개 / 대표전략 집계 {len(rows)}개",
        _score_stat_line('✅ S1 즉시진입', _v401_stat(by_grade.get('S1', []))),
        _score_stat_line('⚠️ S2 재확인', _v401_stat(by_grade.get('S2', []))),
        _score_stat_line('❔ S3 관찰복기', _v401_stat(by_grade.get('S3', []))),
        _score_stat_line('현재판 전체', _v401_stat(rows)),
        '', '[대표전략 기준 · 실제 거래수와 맞는 성과]'
    ]
    for key,label in label_map.items(): lines.append(_score_stat_line(label, _v401_stat(by_strategy.get(key, []))))
    if by_strategy.get('unknown'): lines.append(_score_stat_line('전략키 미기록', _v401_stat(by_strategy.get('unknown', []))))
    lines += ['', '[최근 CLOSED]'] + _v401_recent_closed(rows)
    strat=_v398_load_json_small(FILES.get('strategy_summary', BASE_DIR/'clean_strategy_s_summary.json'), {}) or {}
    pbh=_v398_load_json_small(FILES.get('paperbot_handoff', BASE_DIR/'paper_bot_candidate_handoff_status.json'), {}) or {}
    router=_v398_load_json_small(FILES.get('target_router', BASE_DIR/'clean_target_router_queue.json'), {}) or {}
    sc=_v398_stage_counts_from_latest_fast()
    if isinstance(strat,dict):
        lines += ['', '[현재 후보/정보 흐름]']
        lines.append(f"- 현재 S1 {sc.get('S1',0)} / S2 {sc.get('S2',0)} / S3 {sc.get('S3',0)} / latest {strat.get('paper_latest_count','-')} / paper 병합 {pbh.get('merged_fresh','-') if isinstance(pbh,dict) else '-'} / archive {pbh.get('archive_window','-') if isinstance(pbh,dict) else '-'}")
        lines.append(f"- 정보: 전체 {strat.get('evaluated','-')}개 / 시세 {strat.get('quote_ready_count','-')} / micro {strat.get('micro_ready_count','-')} / 둘다 {strat.get('full_info_ready_count','-')}")
        lines.append(f"- 배차: 전체 {router.get('queue_count','-') if isinstance(router,dict) else '-'} / 내보냄 {router.get('export_count', router.get('active_target_count','-')) if isinstance(router,dict) else '-'} / 대기 {router.get('rotation_wait_count','-') if isinstance(router,dict) else '-'} / 버림 {router.get('dropped_count',0) if isinstance(router,dict) else 0}")
    return "\n".join(lines)

def pscore_text() -> str:  # type: ignore[override]
    return score_text().replace('📊 S1/S2/S3 스코어 /score', '📊 paper S1/S2/S3 스코어 /pscore · v0.125 장부직접조회', 1)

def quality_text()->str:  # type: ignore[override]
    reject=load_json(FILES['strategy_reject'],{}) or {}; strat=load_json(FILES['strategy_summary'],{}) or {}
    hand=load_json(FILES['paper_handoff'],{}) or {}; pbh=load_json(FILES['paperbot_handoff'],{}) or {}
    latest_lines=line_count(FILES['paper_latest']); archive_lines=line_count(FILES['paper_archive'])
    router=load_json(FILES.get('target_router', BASE_DIR/'clean_target_router_queue.json'),{}) or {}
    evaluated=int(fnum(reject.get('evaluated') or strat.get('evaluated') or 0,0))
    quote=int(fnum(reject.get('quote_ready_count') or strat.get('quote_ready_count') or evaluated,0))
    micro=int(fnum(reject.get('micro_ready_count') or strat.get('micro_ready_count') or 0,0))
    both=int(fnum(reject.get('full_info_ready_count') or strat.get('full_info_ready_count') or min(quote,micro),0))
    sc=_v358_stage_counts_from_latest(); not_micro=max(0,evaluated-micro) if evaluated else 0
    lines=[
        '🔍 후보품질 /quality',
        f"✅ 전체 {evaluated}개 평가 / S1 {sc.get('S1',0)} / S2 {sc.get('S2',0)} / S3 {sc.get('S3',0)} / latest {latest_lines}줄 / 병합 {pbh.get('merged_fresh','-')}",
        '', '[S1/S2/S3 의미]',
        '- S1: 즉시 paper OPEN / S2: 재확인 후 승격 후보 / S3: 관찰·복기 후보',
        '- 유동보유: 0~5분 검증 → 5~30분 확인 → 30~120분 확장 관찰',
        '', '[정보가 얼마나 채워졌나]',
        f"- 시세: {quote}/{evaluated}개 / 호가·체결: {micro}/{evaluated}개 / 둘다: {both}/{evaluated}개",
        f"- 아직 micro 미신선: {not_micro}개 / 지금 꼭 필요한 micro: {router.get('need_micro') or reject.get('info_pending_count') or 0}개",
        '', '[안 넣은 게 아니라 단계 분리]',
        f"- 전체배차 {router.get('queue_count','-')}개 → 이번내보냄 {router.get('export_count', router.get('active_target_count','-'))}",
        f"- 순환대기 {router.get('rotation_wait_count','-')}개 / 버림 {router.get('dropped_count',0)}개 / safety초과 {router.get('safety_overflow',0)}개",
        '', '[탈락/보류 사유 TOP]'
    ]
    top=reject.get('reason_top') if isinstance(reject.get('reason_top'),list) else []
    if top:
        for r in top[:12]:
            lines.append(f"- ❔ {r.get('reason')}: {r.get('count')}")
    else:
        lines.append('- 아직 집계 없음')
    return '\n'.join(lines)

def popen_text() -> str:  # type: ignore[override]
    rows = _v538_open_rows()
    lines = ['📂 모의매매 진행중 /popen · 메인봇 캐시 전용']
    if not rows:
        return '\n'.join(lines + ['진행 중 없음'])
    by_stage = Counter(_paper_grade(p) for p in rows)
    by_strategy = Counter(_paper_strategy_label(p) for p in rows)
    lines.append('등급별 진행중: ' + ' / '.join(f'{_v358_stage_label(k)} {v}' for k, v in by_stage.items()))
    lines.append('전략별 진행중: ' + ' / '.join(f'{k} {v}' for k, v in by_strategy.items()))
    lines.append('- 판독: 여기는 이미 paper가 받은 OPEN 장부입니다. latest 후보판정 S1 0과 별개로 봅니다.')
    for p in rows[:10]:
        t = _short_ticker(p.get('ticker') or p.get('symbol'))
        pnl = _pos_profit_pct(p)
        hold = _pos_hold_sec(p)
        vals = _pos_snapshot_flat(p)
        buy = vals.get('buy_ratio') or vals.get('micro_trade_buy_ratio_30') or '-'
        reason = p.get('reason') or p.get('entry_reason') or p.get('watch_note') or '진행 감시'
        try:
            buy_txt = f"{float(buy):.2f}"
        except Exception:
            buy_txt = str(buy)
        lines.append(f"- {_v358_stage_label(_paper_grade(p))} {t} / {_paper_strategy_label(p)} / 진입 {_pos_entry_price(p)} / 현재 {_pos_current_price(p)} / {pnl:+.2f}% / 보유 {int(hold//60)}분 {int(hold%60)}초 / 감시 {reason}")
        lines.append(f"  · 근거: 매수체결 {buy_txt} / 주의: {_v538_risk_text(p.get('risk_label') or p.get('risk_tags'))}")
    if len(rows) > 10:
        lines.append(f"- 나머지 {len(rows)-10}개는 이후 full에서 확인")
    return '\n'.join(lines)

def set_commands(updater):  # type: ignore[override]
    try:
        updater.bot.set_my_commands([BotCommand('health','메인/worker/paper 빠른상태'),BotCommand('workers','worker 상세 상태'),BotCommand('score','S1/S2/S3 성과'),BotCommand('version_score','버전별/진입유형 성과'),BotCommand('quality','S1/S2/S3 후보품질'),BotCommand('pstatus','paper 상태'),BotCommand('popen','모의매매 진행중'),BotCommand('preview','손실+놓친후보 복기'),BotCommand('missed_trace','후보 handoff 추적'),BotCommand('errorlog','오류로그'),BotCommand('batch','묶음 확인')])
    except Exception as exc: log_error('set_commands',exc)

def startup_notify(updater):  # type: ignore[override]
    try:
        if not CHAT_ID:
            return
        text=(f"✅ 메인봇 시작 완료\n- 버전: {BOT_VERSION}\n- 구조: {CLEAN_WORKER_HUB_LABEL}\n- 등급: S1 즉시진입 / S2 재확인 / S3 관찰복기\n- 새 전략: 주도흐름 유동보유\n- 명령: /health /score /quality /pstatus /popen /preview /errorlog")
        updater.bot.send_message(chat_id=CHAT_ID, text=text)
    except Exception as exc:
        log_error('startup_notify', exc)


# =============================================================================
# v360: COMMANDS 재바인딩 + S1/S2/S3 기본 출력 고정
# - v358에서 /score, /pstatus가 COMMANDS 초기 참조 때문에 구 함수로 남는 문제를 제거한다.
# - 새 기준은 S1 즉시진입 / S2 재확인 / S3 관찰복기만 기본 출력한다.
# =============================================================================
try:
    COMMANDS.update({
        'health': health_text,
        'core': health_text,
        'workers': workers_text,
        'score': score_text,
        'quality': quality_text,
        'strategy_watch': strategy_watch_text,
        'pipe_check': pipe_check_text,
        'pstatus': pstatus_text,
        'pscore': pscore_text,
        'popen': popen_text,
        'ploss_review': ploss_review_text,
        'pmissed_review': pmissed_review_text,
        'preview': preview_text,
        'loss_review': ploss_review_text,
        'missed_review': pmissed_review_text,
        'missed_trace': missed_trace_text,
        'trace_missed': missed_trace_text,
        'errorlog': errorlog_text,
        'popen_short': open_text,
    })
except Exception:
    pass


# =============================================================================
# v367: /version_score 최근 3개 적용버전 + S2/S3 관찰 배관 표시 단일화
# - 구 worker 버전명 나열을 기본 출력에서 끊고, 최근 3개 적용 버전만 본다.
# - 새 CLOSED는 main/deploy version 필드를 우선 사용한다.
# - S2/S3는 CLOSED가 적을 수 있으므로 /quality 현재 후보와 /missed_trace 중심으로 판단한다.
# =============================================================================
BOT_VERSION = "수익형 v2.13.389"
CLEAN_WORKER_HUB_LABEL = "clean worker hub v369"

_VERSION_SCORE_LIMIT = 3

def _v367_version_key(row: Dict[str, Any]) -> str:
    row = as_dict(row)
    ctx = as_dict(row.get('entry_context'))
    raw = as_dict(row.get('raw'))
    snap = as_dict(row.get('entry_snapshot'))
    flat = as_dict(snap.get('flat'))
    vals = [
        row.get('main_version'), row.get('main_bot_version'), row.get('deploy_version'), row.get('deployed_version'), row.get('bot_version'),
        ctx.get('main_version'), ctx.get('main_bot_version'), ctx.get('deploy_version'), ctx.get('deployed_version'), ctx.get('bot_version'),
        raw.get('main_version'), raw.get('main_bot_version'), raw.get('deploy_version'), raw.get('deployed_version'), raw.get('bot_version'),
        flat.get('main_version'), flat.get('main_bot_version'), flat.get('deploy_version'), flat.get('deployed_version'), flat.get('bot_version'),
    ]
    vals_fallback = [row.get('opened_brain_version'), row.get('brain_version'), ctx.get('opened_brain_version'), ctx.get('brain_version'), raw.get('brain_version')]
    for seq in (vals, vals_fallback):
        for v in seq:
            s = str(v or '').strip()
            if not s:
                continue
            m = re.search(r'v?2[._]13[._](\d+)', s)
            if m:
                return f"v2.13.{int(m.group(1))}"
            m = re.search(r'v(\d{3,})', s)
            if m:
                return f"v2.13.{int(m.group(1))}"
            if 'strategy_worker' in s:
                return s[:32]
    return '버전 미기록'

def _v367_version_sort(ver: str, arr: List[Dict[str, Any]]) -> Tuple[int, float]:
    m = re.search(r'v2\.13\.(\d+)', str(ver))
    n = int(m.group(1)) if m else -1
    latest = max((_v365_closed_ts(r) for r in arr), default=0.0)
    return (n, latest)

def version_score_text() -> str:  # type: ignore[override]
    rows = [r for r in read_jsonl(FILES.get('paper_closed', BASE_DIR/'paper_bot_closed.jsonl'), max_lines=30000) if isinstance(r, dict)]
    groups: Dict[str, List[Dict[str, Any]]] = {}
    for r in rows:
        groups.setdefault(_v367_version_key(r), []).append(r)
    items = []
    for ver, arr in groups.items():
        if ver == '버전 미기록':
            continue
        items.append((_v367_version_sort(ver, arr), ver, arr))
    items.sort(key=lambda x: x[0], reverse=True)
    items = items[:_VERSION_SCORE_LIMIT]
    lines = [
        '📊 버전별 성과 /version_score',
        f'- 기본 출력: 최근 적용 버전 {_VERSION_SCORE_LIMIT}개만 표시합니다.',
        '- 기준: paper CLOSED 장부 직접 조회 / 메인 적용버전 우선 / worker 버전은 보조값',
        '',
        '[최근 3개 버전 요약]'
    ]
    if not items:
        lines.append('- 아직 버전이 기록된 CLOSED 장부 없음')
        return '\n'.join(lines)
    for _, ver, arr in items:
        st = _v365_stat(arr)
        icon = '✅' if st.get('total',0) > 0 else ('⚠️' if st.get('n',0) < 10 else '❌')
        lines.append(_v365_stat_line(f'{icon} {ver}', arr))
    latest_ver = items[0][1]
    latest_rows = items[0][2]
    strat_groups: Dict[str, List[Dict[str, Any]]] = {}
    for r in latest_rows:
        strat_groups.setdefault(_v365_strategy_key(r), []).append(r)
    label_map={'money_reaccel_s':'돈흐름 재가속','leader_momentum_s':'주도추세 지속','breakout_early_s':'돌파 초입','sweep_vwap_recovery_s':'저점 VWAP 회복','surge_rebreak_s':'급등 후 재돌파','leader_flow_adaptive_hold_s':'주도흐름 유동보유','unknown':'대표전략 미확인'}
    lines += ['', f'[최신 버전 전략별 · {latest_ver}]']
    if strat_groups:
        for k, arr in sorted(strat_groups.items(), key=lambda kv: len(kv[1]), reverse=True)[:8]:
            lines.append(_v365_stat_line(label_map.get(k,k), arr))
    else:
        lines.append('- 아직 최신 버전 CLOSED 없음')
    lines += ['', '[판독]', '- /score는 현재판 anchor 성과, /version_score는 최근 3개 적용버전 비교입니다.', '- 오래된 worker 버전 나열은 기본 출력에서 제외했습니다.']
    return '\n'.join(lines)

try:
    COMMANDS.update({'version_score': version_score_text, 'vscore': version_score_text})
except Exception:
    pass



# =============================================================================
# main v2.13.369: 최근 3개 적용버전 고정 + trace/quality 표시 정리
# =============================================================================
BOT_VERSION = "수익형 v2.13.389"
CLEAN_WORKER_HUB_LABEL = "clean worker hub v369"
_VERSION_SCORE_LIMIT = 3
_CURRENT_MAIN_VER = "v2.13.371"


def _v369_ver_num(ver: str) -> int:
    m=re.search(r'v?2[._]13[._](\d+)', str(ver or ''))
    return int(m.group(1)) if m else -1


def _v369_recent_main_versions(n: int = 3) -> List[str]:
    cur=_v369_ver_num(_CURRENT_MAIN_VER)
    if cur <= 0:
        return [_CURRENT_MAIN_VER]
    return [f"v2.13.{cur-i}" for i in range(n)]


def _v369_main_version_key(row: Dict[str, Any]) -> str:
    row=as_dict(row); ctx=as_dict(row.get('entry_context')); raw=as_dict(row.get('raw')); snap=as_dict(row.get('entry_snapshot')); flat=as_dict(snap.get('flat'))
    vals=[row.get('main_version'),row.get('main_bot_version'),row.get('deploy_version'),row.get('deployed_version'),row.get('bot_version'),ctx.get('main_version'),ctx.get('main_bot_version'),ctx.get('deploy_version'),ctx.get('deployed_version'),ctx.get('bot_version'),raw.get('main_version'),raw.get('deploy_version'),flat.get('main_version'),flat.get('deploy_version')]
    for v in vals:
        s=str(v or '').strip()
        if not s or 'strategy_worker' in s or 'paper_bot' in s:
            continue
        m=re.search(r'v?2[._]13[._](\d+)', s)
        if m:
            return f"v2.13.{int(m.group(1))}"
        m=re.search(r'v(\d{3,})', s)
        if m:
            num=int(m.group(1))
            if num >= 340:
                return f"v2.13.{num}"
    return '버전 미기록'


def version_score_text() -> str:  # type: ignore[override]
    rows=[r for r in read_jsonl(FILES.get('paper_closed', BASE_DIR/'paper_bot_closed.jsonl'), max_lines=30000) if isinstance(r, dict)]
    wanted=_v369_recent_main_versions(_VERSION_SCORE_LIMIT)
    groups={v: [] for v in wanted}
    missing=0
    for r in rows:
        k=_v369_main_version_key(r)
        if k in groups:
            groups[k].append(r)
        elif k == '버전 미기록':
            missing += 1
    lines=['📊 버전별 성과 /version_score', f'- 기본 출력: 최근 적용 버전 {_VERSION_SCORE_LIMIT}개만 표시합니다.', '- 기준: main_version/deploy_version 기록만 사용합니다. worker 버전 줄세우기는 기본에서 제외합니다.', '', '[최근 3개 버전 요약]']
    for ver in wanted:
        arr=groups.get(ver, [])
        if arr:
            lines.append(_v365_stat_line(('✅ ' if _v365_stat(arr).get('total',0)>0 else '❌ ') + ver, arr))
        else:
            lines.append(f'- ❔ {ver}: CLOSED 0건 / 아직 이 버전으로 닫힌 결과 없음')
    latest_ver=wanted[0]
    latest_rows=groups.get(latest_ver, [])
    label_map={'money_reaccel_s':'돈흐름 재가속','leader_momentum_s':'주도추세 지속','breakout_early_s':'돌파 초입','sweep_vwap_recovery_s':'저점 VWAP 회복','surge_rebreak_s':'급등 후 재돌파','leader_flow_adaptive_hold_s':'주도흐름 유동보유','unknown':'대표전략 미확인'}
    lines += ['', f'[최신 버전 전략별 · {latest_ver}]']
    if latest_rows:
        strat_groups={}
        for r in latest_rows:
            strat_groups.setdefault(_v365_strategy_key(r), []).append(r)
        for k, arr in sorted(strat_groups.items(), key=lambda kv: len(kv[1]), reverse=True)[:8]:
            lines.append(_v365_stat_line(label_map.get(k,k), arr))
    else:
        lines.append('- 아직 최신 버전 CLOSED 없음')
    if missing:
        lines += ['', f'- 참고: main_version 없는 과거 CLOSED {missing}건은 기본 비교에서 제외했습니다.']
    lines += ['', '[판독]', '- /score는 현재판 anchor 성과, /version_score는 최근 3개 적용버전만 비교합니다.', '- 새 조건 효과는 최신 버전 줄만 보고, 예전 손실은 참고에서 제외합니다.']
    return '\n'.join(lines)


def batch_handler(update, context):  # type: ignore[override]
    cmds=context.args or ['health','version_score','score','quality','missed_trace','errorlog']
    cmds=[str(x).strip().lstrip('/') for x in cmds[:12] if str(x).strip()]
    st=time.time(); sent=0; timings=[]
    try:
        send(update, f"📦 자동 묶음 명령 접수\n- 실행 {len(cmds)}개\n- v369: 최근3버전 성과 + S2/S3 관찰배관 + actual trace 단일화")
    except Exception:
        pass
    total=len(cmds)
    for raw in cmds:
        name=raw.strip().lstrip('/')
        fn=COMMANDS.get(name)
        if not fn:
            continue
        t=time.time()
        try:
            body=fn(); ok='OK'
        except Exception as exc:
            body=f"❌ /{name} 오류 {exc.__class__.__name__}: {exc}"; ok='ERR'; log_error(f'batch_{name}', exc)
        sec=time.time()-t; sent+=1
        timings.append(f"- {'✅' if ok=='OK' else '❌'} /{name}: {sec:.2f}s / {ok}")
        send(update, f"[{sent}/{total}] /{name} ({sec:.2f}s / {ok})\n{body}")
    send(update, "🧾 자동 묶음 시간표 · v369 명령별 전송\n"+"\n".join(timings)+f"\n- 합계 {time.time()-st:.2f}s")

try:
    COMMANDS.update({'version_score': version_score_text, 'vscore': version_score_text})
except Exception:
    pass


# =============================================================================
# v398 복구 안정판: 상태판/생애주기 표시만 경량 이식
# - v369 첫 묶음 기준을 유지한다.
# - /health, /pstatus, /missed_trace는 캐시 파일만 읽고 복구/재검사/worker 실행을 하지 않는다.
# - stale paper/trace면 판단보류 문구만 표시한다.
# =============================================================================
RESTORE_BUILD = "v425_v389_disable_main_auto_retention_2026-05-25"


def _v398_file_age(path: Path) -> float:
    try:
        return max(0.0, now_ts() - path.stat().st_mtime) if path.exists() else 999999.0
    except Exception:
        return 999999.0


def _v398_load_json_small(path: Path, default: Any = None, max_bytes: int = 700_000) -> Any:
    try:
        if not path.exists():
            return default
        if path.stat().st_size > max_bytes:
            return {"_too_large": True, "_size": path.stat().st_size}
        return json.loads(path.read_text(encoding="utf-8", errors="ignore"))
    except Exception:
        return default


def _v398_paper_versions() -> Dict[str, Any]:
    st_path = FILES.get('paper_status', BASE_DIR/'paper_bot_status.json')
    tr_path = FILES.get('candidate_handoff_trace', BASE_DIR/'paper_bot_candidate_handoff_trace.json')
    st = _v398_load_json_small(st_path, {}) or {}
    tr = _v398_load_json_small(tr_path, {}) or {}
    pv = str(st.get('version') or st.get('active_reader_version') or '-') if isinstance(st, dict) else '-'
    tv = str(tr.get('version') or tr.get('trace_version') or '-') if isinstance(tr, dict) else '-'
    pa = _v398_file_age(st_path)
    ta = _v398_file_age(tr_path)
    ok = bool(pv != '-' and tv != '-' and pv == tv and pa < 90 and ta < 120)
    return {'paper_version': pv, 'trace_version': tv, 'paper_age': pa, 'trace_age': ta, 'ok': ok, 'status': st, 'trace': tr}


def _v398_state_icon(ok: bool, warn: bool = False) -> str:
    return '✅' if ok else ('⚠️' if warn else '❌')


def _v398_stage_counts_from_latest_fast() -> Dict[str, int]:
    try:
        strat = _v398_load_json_small(FILES.get('strategy_summary', BASE_DIR/'clean_strategy_s_summary.json'), {}) or {}
        sc = strat.get('s_stage_counts') if isinstance(strat.get('s_stage_counts'), dict) else {}
        if sc:
            return {k:int(fnum(v,0)) for k,v in sc.items()}
    except Exception:
        pass
    try:
        c = Counter()
        for r in read_jsonl(FILES.get('paper_latest', BASE_DIR/'paper_candidates_latest.jsonl'), max_lines=300):
            g = str(r.get('s_stage') or r.get('candidate_grade') or r.get('grade') or '').upper()
            if g in {'S1','S2','S3'}:
                c[g] += 1
        return dict(c)
    except Exception:
        return {}


def _v398_lifecycle_lines() -> List[str]:
    strat = _v398_load_json_small(FILES.get('strategy_summary', BASE_DIR/'clean_strategy_s_summary.json'), {}) or {}
    life = strat.get('lifecycle_stats') if isinstance(strat.get('lifecycle_stats'), dict) else {}
    if not life:
        return ['[후보 생애주기 · 승패 아님]', '- 생애주기 cache 준비중']
    stage_counts = life.get('active_stage_counts') if isinstance(life.get('active_stage_counts'), dict) else life.get('stage_counts') if isinstance(life.get('stage_counts'), dict) else {}
    transitions = life.get('transitions') if isinstance(life.get('transitions'), dict) else {}
    missed = life.get('missed_rise_counts') if isinstance(life.get('missed_rise_counts'), dict) else {}
    lines = ['[후보 생애주기 · 승패 아님]']
    lines.append(f"- S3 관찰포착: {int(fnum(stage_counts.get('S3'),0))}개 / 새 관찰 {int(fnum(transitions.get('new_s3'),0))} / S3→S2 {int(fnum(transitions.get('s3_to_s2'),0))}")
    lines.append(f"- S2 재확인: {int(fnum(stage_counts.get('S2'),0))}개 / S2유지 {int(fnum(transitions.get('s2_hold'),0))} / S2→S1 {int(fnum(transitions.get('s2_to_s1'),0))} / S1보류 {int(fnum(transitions.get('blocked_s1_signal'),0))}")
    for key, title in [('s3_to_s2_fail_reasons','S3→S2 미승격 TOP'), ('s2_to_s1_fail_reasons','S2→S1 미승격 TOP')]:
        fails = life.get(key) if isinstance(life.get(key), dict) else {}
        if fails:
            top = sorted(fails.items(), key=lambda kv: int(fnum(kv[1],0)), reverse=True)[:5]
            lines.append(f"- {title}: " + ' / '.join(f"{k} {int(fnum(v,0))}" for k,v in top))
    lines.append(f"- S1 실제진입 대기: {int(fnum(stage_counts.get('S1'),0))}개")
    if missed:
        lines.append(f"- 놓친상승 참고: S2 +0.7%↑ {int(fnum(missed.get('S2_up_07'),0))}개 / S3 +0.7%↑ {int(fnum(missed.get('S3_up_07'),0))}개")
    lines.append('- 판독: S2/S3는 승패가 아니라 S1로 올라가기 전 재료·승격 흐름입니다.')
    return lines



def _v436_list_top(items: Any, limit: int = 3) -> str:
    rows: List[str] = []
    if isinstance(items, dict):
        pairs = [{"reason": str(k), "count": v} for k, v in items.items()]
    elif isinstance(items, list):
        pairs = [x for x in items if isinstance(x, dict)]
    else:
        pairs = []
    def _cnt(x: Dict[str, Any]) -> int:
        try:
            return int(float(x.get('count', x.get('n', 0))))
        except Exception:
            return 0
    for x in sorted(pairs, key=_cnt, reverse=True)[:limit]:
        r = str(x.get('reason') or x.get('name') or x.get('key') or x.get('label') or '').strip()
        c = _cnt(x)
        if r:
            rows.append(f"{r} {c}")
    return ' / '.join(rows) if rows else '-'


def _v436_simple_panel_from_strategy(strat: Dict[str, Any]) -> Dict[str, Any]:
    panel = strat.get('s123_simple_panel') if isinstance(strat.get('s123_simple_panel'), dict) else {}
    if panel:
        return panel
    audit = strat.get('s1_block_audit') if isinstance(strat.get('s1_block_audit'), dict) else {}
    if audit:
        return {
            'schema': 's123_simple_panel_fallback_from_audit',
            'stage_counts': audit.get('stage_counts', strat.get('s_stage_counts', {})),
            'verdict': 'S1/S2/S3 사유 cache 표시',
            'reason_top': audit.get('reason_top', []),
            'missing_info_top': audit.get('missing_info_top', []),
            'decision_top': audit.get('decision_top', []),
        }
    return {'stage_counts': strat.get('s_stage_counts', {}), 'verdict': 'S1/S2/S3 사유 cache 준비중'}


def candidate_reason_text() -> str:
    strat = _v427_strategy_summary()
    audit = _v427_read_small(BASE_DIR / 'clean_strategy_s1_block_audit.json', {}) or {}
    if isinstance(audit, dict) and audit:
        panel = audit.get('s123_simple_panel') if isinstance(audit.get('s123_simple_panel'), dict) else _v436_simple_panel_from_strategy({'s1_block_audit': audit, 's_stage_counts': audit.get('stage_counts', {})})
    else:
        panel = _v436_simple_panel_from_strategy(strat)
    sc = panel.get('stage_counts') if isinstance(panel.get('stage_counts'), dict) else strat.get('s_stage_counts', {}) if isinstance(strat, dict) else {}
    lines = [
        '🧭 후보판정 이유 /candidate_reason · cache-only',
        '- 기준: S1/S2/S3만 봅니다. S/A/B 추가 등급은 쓰지 않습니다.',
        f"- 전체평가: {strat.get('evaluated','-') if isinstance(strat,dict) else '-'} / 후보파일 {strat.get('paper_latest_count','-') if isinstance(strat,dict) else '-'} / 고정 40개 제한 아님",
        f"- 현재 단계: S1 {_v427_int(sc.get('S1',0))} / S2 {_v427_int(sc.get('S2',0))} / S3 {_v427_int(sc.get('S3',0))}",
        f"- 판정: {panel.get('verdict','-')}",
        f"- S1 막힘 상위: {_v436_list_top(panel.get('reason_top'), 5)}",
        f"- 부족정보 상위: {_v436_list_top(panel.get('missing_info_top'), 5)}",
        f"- 복기판정 상위: {_v436_list_top(panel.get('decision_top'), 5)}",
        '',
        '[다음 판단]',
        '- S2가 많고 S1이 없으면 S2→S1 막힘 사유를 봅니다.',
        '- 부족정보가 많으면 조건 문제가 아니라 정보배관/긴급보강 문제입니다.',
        '- 가격반응·매수지속·스프레드가 대부분이면 S1 안전문 조정 후보입니다.',
    ]
    return '\n'.join(lines)

def health_text() -> str:  # type: ignore[override]
    workers = [worker_status(k) for k in WORKERS]
    res = resource_snapshot()
    paper = _v398_load_json_small(FILES['paper_status'], {}) or {}
    strat = _v398_load_json_small(FILES['strategy_summary'], {}) or {}
    reject = _v398_load_json_small(FILES['strategy_reject'], {}) or {}
    oflow = _v398_load_json_small(FILES['orderflow'], {}) or {}
    router = _v398_load_json_small(FILES['target_router'], {}) or {}
    vers = _v398_paper_versions()
    good = sum(1 for w in workers if worker_ok(w) == '✅')
    warn = sum(1 for w in workers if worker_ok(w) == '⚠️')
    bad = sum(1 for w in workers if worker_ok(w) == '❌')
    evaluated = int(fnum(reject.get('evaluated') or strat.get('evaluated') or 0, 0)) if isinstance(reject, dict) and isinstance(strat, dict) else 0
    quote_ready = int(fnum(strat.get('quote_ready_count') or reject.get('quote_ready_count') or oflow.get('quote_fresh') or 0, 0)) if isinstance(strat, dict) and isinstance(reject, dict) and isinstance(oflow, dict) else 0
    micro_ready = int(fnum(strat.get('micro_ready_count') or reject.get('micro_ready_count') or oflow.get('fresh_micro') or 0, 0)) if isinstance(strat, dict) and isinstance(reject, dict) and isinstance(oflow, dict) else 0
    full_ready = int(fnum(strat.get('full_info_ready_count') or reject.get('full_info_ready_count') or oflow.get('info_ready') or 0, 0)) if isinstance(strat, dict) and isinstance(reject, dict) and isinstance(oflow, dict) else 0
    sc = _v398_stage_counts_from_latest_fast()
    res_warn = float(fnum(res.get('mem_used_pct'), 0)) >= 80 or float(fnum(res.get('disk_used_pct'), 0)) >= 85
    paper_ok = bool(vers.get('ok'))
    lines = [
        '🧭 건강상태 /health',
        f"{_v398_state_icon(bad == 0 and paper_ok and not res_warn, warn or res_warn or not paper_ok)} 전체판독: worker {good}/9 정상 · paper/trace {'정상' if paper_ok else '확인필요'} · 자원 {'주의' if res_warn else '정상'}",
        f"- 메인봇 {BOT_VERSION} / clean worker hub v369 / {RESTORE_BUILD} / uptime {int(now_ts()-START_TS)}s",
        f"- 정보: 평가 {evaluated or '-'} / 시세 {quote_ready}/{evaluated or '-'} / micro {micro_ready}/{evaluated or '-'} / 둘다 {full_ready}/{evaluated or '-'}",
        f"- 후보 생애주기: S1 {sc.get('S1',0)} / S2 {sc.get('S2',0)} / S3 {sc.get('S3',0)} / latest {strat.get('paper_latest_count', '-') if isinstance(strat,dict) else '-'}",
        f"- paper: {vers.get('paper_version')} / trace {vers.get('trace_version')} / status age {vers.get('paper_age',0):.1f}s / trace age {vers.get('trace_age',0):.1f}s / OPEN {paper.get('open_count', paper.get('open_total','-')) if isinstance(paper,dict) else '-'}",
        f"- 배차: 전체 {router.get('queue_count','-') if isinstance(router,dict) else '-'} → 내보냄 {router.get('export_count', router.get('active_target_count','-')) if isinstance(router,dict) else '-'} / 대기 {router.get('rotation_wait_count','-') if isinstance(router,dict) else '-'} / 버림 {router.get('dropped_count',0) if isinstance(router,dict) else 0}",
        f"- 자원: 디스크 {res.get('disk_used_pct','-')}% / 남음 {res.get('disk_free_gb','-')}GB / 메모리 {res.get('mem_used_pct','-')}% / load {res.get('load','-')}",
    ]
    if not paper_ok:
        lines.append('- ⚠️ paper/trace가 최신/동일하지 않으면 OPEN/trace 판단은 보류합니다. 복구 시도는 하지 않습니다.')
    lines += ['', '[worker 요약]']
    lines += [line_worker(w, detail=False) for w in workers]
    return '\n'.join(lines)


def _v401_lifecycle_lines() -> List[str]:
    life = (_v398_load_json_small(FILES.get('strategy_summary', BASE_DIR/'clean_strategy_s_summary.json'), {}) or {}).get('lifecycle_stats')
    if isinstance(life, dict) and life: return _v398_lifecycle_lines()
    sc = _v398_stage_counts_from_latest_fast(); vers = _v398_paper_versions()
    obj = vers.get('trace') if isinstance(vers.get('trace'), dict) else {}
    rows = obj.get('rows') if isinstance(obj, dict) and isinstance(obj.get('rows'), list) else []
    by = Counter(str(r.get('status') or 'unknown') for r in rows if isinstance(r, dict))
    lines=['[후보 생애주기 · 승패 아님]', f"- 현재 latest 기준: S1 {sc.get('S1',0)} / S2 {sc.get('S2',0)} / S3 {sc.get('S3',0)}"]
    lines.append('- paper trace 기준: ' + (' / '.join(f"{k} {v}" for k,v in by.most_common(6)) if by else '아직 rows 없음'))
    lines.append('- 판독: S2/S3는 승패가 아니라 S1로 올라가기 전 재료·승격 흐름입니다.')
    return lines


def pstatus_text() -> str:  # type: ignore[override]
    # v422에서 다시 최종 fast path로 덮는다. 구 v401 CLOSED 직접조회 pstatus는 삭제됨.
    status = _v398_load_json_small(FILES.get('paper_status', BASE_DIR/'paper_bot_status.json'), {}) or {}
    return f"🧪 paper 상태 /pstatus · fast stub\n- paper {status.get('version','-')} / status age {age(FILES.get('paper_status', BASE_DIR/'paper_bot_status.json')):.1f}s / CLOSED누적 {status.get('closed_total', status.get('closed_count','-'))}"

def missed_trace_text() -> str:  # type: ignore[override]
    vers=_v398_paper_versions(); obj=vers.get('trace') if isinstance(vers.get('trace'),dict) else {}
    rows=obj.get('rows') if isinstance(obj,dict) and isinstance(obj.get('rows'),list) else []; rows=[r for r in rows if isinstance(r,dict)][:300]
    labels={'open':'OPEN됨','closed':'CLOSED됨','selected_for_open':'S1선택됨','not_s1':'S1미달(정상대기)','micro_wait':'micro 재확인대기','merged_waiting_pick':'병합후 선별대기','expired':'후보만료','skipped':'스킵','not_merged':'미병합'}
    by=Counter(str(r.get('status') or 'unknown') for r in rows); reasons=Counter()
    for r in rows:
        for x in str(r.get('reason') or '').split(','):
            if x.strip(): reasons[x.strip()]+=1
    lines=['🧭 후보 handoff 추적 /missed_trace','- 기준: strategy 후보 → paper 병합 → S1선별 → OPEN/CLOSED 흐름. not_s1은 손실/놓친확정이 아니라 S1 미달 상태입니다.',f"- paper {vers.get('paper_version')} / trace {vers.get('trace_version')} / trace age {vers.get('trace_age',0):.1f}s / rows {len(rows)}",'', '[상태 TOP]']
    if by:
        for k,v in by.most_common(10):
            icon='✅' if k in {'open','closed','selected_for_open'} else '⚠️' if k in {'expired','not_merged','micro_wait','skipped'} else '❔'
            lines.append(f"- {icon} {labels.get(k,k)}: {v}개")
    else: lines.append('- trace 없음')
    lines += ['', '[이유 TOP]']
    if reasons:
        for k,v in reasons.most_common(10): lines.append(f"- ❔ {'S1미달' if k == 'S1아님' else k}: {v}개")
    else: lines.append('- 이유 없음')
    lines += ['', '[재확인 후보 TOP]']
    risky=[r for r in rows if str(r.get('status') or '') not in {'open','closed','selected_for_open'}]
    for r in risky[:10]:
        st=str(r.get('status') or '-')
        lines.append(f"- ⚠️ {norm_ticker(r.get('ticker'))} / {r.get('strategy') or r.get('strategy_key','-')} / score {r.get('score','-')} / 상태 {labels.get(st,st)} / 이유 {r.get('reason','-')}")
    if not risky: lines.append('- 현재 재확인 후보 없음')
    return '\n'.join(lines)


def batch_handler(update, context):  # type: ignore[override]
    cmds = context.args or ['health','pstatus','score','s1_review','missed_trace','errorlog']
    cmds = [str(x).strip().lstrip('/') for x in cmds[:10] if str(x).strip()]
    st = time.time(); sent = 0; timings = []
    try:
        send(update, f"📦 자동 묶음 명령 접수\n- 실행 {len(cmds)}개\n- v402: S1 손실 정밀판 단일화")
    except Exception:
        pass
    total = len(cmds)
    for raw in cmds:
        name = raw.strip().lstrip('/')
        fn = COMMANDS.get(name)
        if not fn:
            continue
        t = time.time()
        try:
            body = fn(); ok = 'OK'
        except Exception as exc:
            body = f"❌ /{name} 오류 {exc.__class__.__name__}: {exc}"; ok = 'ERR'; log_error(f'batch_{name}', exc)
        sec = time.time() - t; sent += 1
        timings.append(f"- {'✅' if ok=='OK' else '❌'} /{name}: {sec:.2f}s / {ok}")
        send(update, f"[{sent}/{total}] /{name} ({sec:.2f}s / {ok})\n{body}")
    send(update, "🧾 자동 묶음 시간표 · v402 명령별 전송\n" + "\n".join(timings) + f"\n- 합계 {time.time()-st:.2f}s")

try:
    COMMANDS.update({'health': health_text, 'core': health_text, 'score': score_text, 'pscore': pscore_text, 'pstatus': pstatus_text, 'missed_trace': missed_trace_text, 'trace_missed': missed_trace_text})
except Exception:
    pass


# =============================================================================
# v402: S1 손실 정밀판 단일화
# - 원인표를 여러 개 늘리지 않고 /s1_review 한 장으로 모은다.
# - 조건/전략/청산을 여기서 바꾸지 않는다. 현재 장부를 읽어 원인 묶음과 다음 확인 후보만 보여준다.
# - 기본 명령은 캐시/장부 조회 전용이며, paper 실행/장부 삭제/복구를 하지 않는다.
# =============================================================================

def _v402_closed_ts(row: Dict[str, Any]) -> float:
    return fnum(row.get('closed_at'), row.get('closed_ts'), row.get('close_ts'), row.get('exit_ts'), row.get('timestamp'), row.get('updated_at'), default=0.0)


def _v402_hold_min(row: Dict[str, Any]) -> float:
    direct = fnum(row.get('age_min'), row.get('hold_min'), row.get('duration_min'), default=-1.0)
    if direct >= 0:
        return direct
    sec = fnum(row.get('hold_sec'), row.get('duration_sec'), default=-1.0)
    return sec / 60.0 if sec >= 0 else 0.0


def _v402_flat(row: Dict[str, Any]) -> Dict[str, Any]:
    try:
        return _snapshot_flat(row)
    except Exception:
        row = as_dict(row)
        ctx = as_dict(row.get('entry_context'))
        out = dict(ctx)
        out.update({k:v for k,v in row.items() if k not in {'entry_context','entry_snapshot'}})
        return out


def _v402_strategy_label(row: Dict[str, Any]) -> str:
    key = _v401_strategy_key(row)
    return STRATEGY_LABELS.get(key, key if key != 'unknown' else '전략키 미기록')


def _v402_exit_label(row: Dict[str, Any]) -> str:
    return str(row.get('exit_rule_label') or row.get('exit_reason') or row.get('close_reason') or row.get('reason') or '-')


def _v402_peak_pct(row: Dict[str, Any]) -> float:
    ctx = _v402_flat(row)
    return fnum(row.get('peak_pct'), row.get('max_profit_pct'), row.get('max_pnl_pct'), row.get('max_unrealized_pct'), ctx.get('peak_pct'), ctx.get('max_profit_pct'), default=0.0)


def _v402_trough_pct(row: Dict[str, Any]) -> float:
    ctx = _v402_flat(row)
    return fnum(row.get('trough_pct'), row.get('min_profit_pct'), row.get('min_pnl_pct'), row.get('min_unrealized_pct'), ctx.get('trough_pct'), ctx.get('min_profit_pct'), default=0.0)


def _v402_ctx_metric(row: Dict[str, Any], *keys: str, default: float = -1.0) -> float:
    ctx = _v402_flat(row)
    return fnum(*(ctx.get(k) for k in keys), default=default)


def _v402_entry_reason(row: Dict[str, Any]) -> str:
    ctx = _v402_flat(row)
    vals = [
        row.get('entry_reason'), row.get('reason'), row.get('watch_note'), row.get('signal_reason'), row.get('decision_reason'),
        ctx.get('entry_reason'), ctx.get('reason'), ctx.get('watch_note'), ctx.get('signal_reason'), ctx.get('decision_reason'),
        row.get('strategy_label'), row.get('strategy'), row.get('strategy_key'), ctx.get('strategy_label'), ctx.get('strategy_key'),
    ]
    for v in vals:
        s = str(v or '').strip()
        if s and s not in {'-', 'None', 'unknown'}:
            return s[:80]
    return _v402_strategy_label(row)


def _v402_loss_causes(row: Dict[str, Any]) -> List[str]:
    pnl = fnum(row.get('pnl_pct'), row.get('profit_pct'), row.get('return_pct'), default=0.0)
    peak = _v402_peak_pct(row)
    trough = _v402_trough_pct(row)
    hold = _v402_hold_min(row)
    exit_label = _v402_exit_label(row)
    buy = _v402_ctx_metric(row, 'buy_ratio', 'micro_trade_buy_ratio_30', 'buy_trade_ratio', 'buy_ratio_30s')
    buy_s = _v402_ctx_metric(row, 'buy_ratio_1m', 'micro_buy_ratio_sustain_1m', 'buy_ratio_sustain')
    spread = _v402_ctx_metric(row, 'spread_pct', 'orderbook_spread_pct')
    vwap = _v402_ctx_metric(row, 'vwap_gap_pct', 'vwap_gap')
    ema = _v402_ctx_metric(row, 'ema5_gap_pct', 'ema_gap_pct', 'ema_gap')
    ch3 = _v402_ctx_metric(row, 'change_3m', 'price_change_3m', 'chg_3m')
    ch5 = _v402_ctx_metric(row, 'change_5m', 'price_change_5m', 'chg_5m')
    ctx = _v402_flat(row)
    causes: List[str] = []
    if pnl < 0:
        if peak <= 0.05:
            causes.append('진입후무반응')
        elif peak <= 0.20:
            causes.append('초반반응약함')
        if hold and hold <= 3:
            causes.append('초단기역행')
        elif hold and hold <= 8 and '손절' in exit_label:
            causes.append('짧은보유손절')
        if '시간' in exit_label:
            causes.append('시간청산까지회복없음')
        if '손절' in exit_label:
            causes.append('손절선도달')
        if trough <= -0.70 or pnl <= -0.70:
            causes.append('깊은역행')
    if 0 <= buy < 0.62:
        causes.append('매수체결약함')
    if 0 <= buy_s < 0.58:
        causes.append('체결지속약함')
    if spread >= 0.25:
        causes.append('스프레드부담')
    if vwap != -1.0 and vwap < -0.10:
        causes.append('VWAP아래진입')
    if ema != -1.0 and ema < -0.15:
        causes.append('EMA아래진입')
    if ch3 != -1.0 and ch5 != -1.0 and ch3 <= 0.05 and ch5 <= 0.10:
        causes.append('가격반응부족')
    if not any(k in ctx for k in ('buy_ratio','micro_trade_buy_ratio_30','spread_pct','vwap_gap_pct','change_3m','price_change_3m','ema5_gap_pct')):
        causes.append('진입스냅샷부족')
    if not causes and pnl < 0:
        try:
            causes = _loss_causes(row)
        except Exception:
            causes = []
    if not causes:
        causes.append('원인추가확인')
    out: List[str] = []
    for c in causes:
        if c and c not in out:
            out.append(c)
    return out[:5]


def _v402_next_check(causes: List[str]) -> str:
    s = set(causes)
    if '진입후무반응' in s or '초반반응약함' in s:
        return 'S1승격 직후 1~3분 반응/최고수익 기준 확인'
    if '매수체결약함' in s or '체결지속약함' in s:
        return 'micro 체결지속값이 S1 승격 전에 실제 붙었는지 확인'
    if 'VWAP아래진입' in s or 'EMA아래진입' in s:
        return '추세유지 조건이 진입 직전 값으로 들어왔는지 확인'
    if '시간청산까지회복없음' in s:
        return '시간청산 후보의 진입 후 추가상승 실패 조건 확인'
    if '진입스냅샷부족' in s:
        return 'paper CLOSED에 entry_context 저장 누락 경로 확인'
    return '전략쏠림/진입타이밍을 대표전략별로 비교'


def _v402_counter_lines(title: str, counter: Counter, limit: int = 8) -> List[str]:
    lines = [title]
    if not counter:
        return lines + ['- 집계 없음']
    for k, v in counter.most_common(limit):
        lines.append(f"- {k}: {v}건")
    return lines


def s1_review_text() -> str:
    rows = sorted(_v401_closed_rows(2600), key=_v402_closed_ts, reverse=True)
    s1_rows = [r for r in rows if _v401_grade(r) == 'S1']
    target = s1_rows if s1_rows else rows
    wins = [r for r in target if fnum(r.get('pnl_pct'), r.get('profit_pct'), default=0.0) > 0]
    losses = [r for r in target if fnum(r.get('pnl_pct'), r.get('profit_pct'), default=0.0) < 0]
    total = sum(fnum(r.get('pnl_pct'), r.get('profit_pct'), default=0.0) for r in target)
    avg = total / len(target) if target else 0.0
    by_strategy = Counter(_v402_strategy_label(r) for r in target)
    by_exit = Counter(_v402_exit_label(r) for r in target)
    cause_counter: Counter = Counter()
    strategy_cause: Dict[str, Counter] = {}
    for r in losses:
        st = _v402_strategy_label(r)
        strategy_cause.setdefault(st, Counter())
        for c in _v402_loss_causes(r):
            cause_counter[c] += 1
            strategy_cause[st][c] += 1
    verdict = '✅ 표본대기'
    if len(target) >= 10 and not wins:
        verdict = '❌ S1 품질위험: 10건 이상 무승'
    elif len(target) >= 10 and avg < -0.30:
        verdict = '⚠️ S1 손실우세: 평균손익 음수'
    elif len(target) < 10:
        verdict = '❔ 표본적음: CLOSED 10건 미만'
    lines = [
        '🧨 S1 손실 정밀판 /s1_review',
        '- 목적: 원인표를 여러 개 보지 않고, S1 진입이 왜 졌는지 한 화면에서 봅니다.',
        f"- 기준: paper_bot_v0.125 CLOSED 직접조회 / 장부 age {age(FILES.get('paper_closed', BASE_DIR/'paper_bot_closed.jsonl')):.1f}s",
        f"- 판독: {verdict}",
        f"- S1 기준: {len(target)}전 {len(wins)}승 {len(losses)}패 / 승률 {(len(wins)/len(target)*100.0 if target else 0):.1f}% / 합산 {total:+.2f}% / 평균 {avg:+.2f}%",
        '- 실행판정: OPEN→CLOSED→알림→score 반영은 정상. 지금 보는 건 실행오류가 아니라 S1 선별품질입니다.',
        '',
    ]
    lines += _v402_counter_lines('[대표전략 쏠림]', by_strategy, 8)
    lines += [''] + _v402_counter_lines('[종료이유 쏠림]', by_exit, 8)
    lines += [''] + _v402_counter_lines('[손실원인 TOP · 중복집계]', cause_counter, 10)
    lines += ['', '[전략별 핵심 원인]']
    if strategy_cause:
        for st, cc in sorted(strategy_cause.items(), key=lambda kv: sum(kv[1].values()), reverse=True)[:6]:
            tops = ' / '.join(f"{k} {v}" for k,v in cc.most_common(4))
            lines.append(f"- {st}: {tops}")
    else:
        lines.append('- 손실 표본 없음')
    lines += ['', '[최근 S1 CLOSED 상세 · 최근 10건]']
    for r in target[:10]:
        t = norm_ticker(r.get('ticker') or r.get('symbol')) or '-'
        pnl = fnum(r.get('pnl_pct'), r.get('profit_pct'), default=0.0)
        hold = _v402_hold_min(r)
        peak = _v402_peak_pct(r)
        trough = _v402_trough_pct(r)
        buy = _v402_ctx_metric(r, 'buy_ratio', 'micro_trade_buy_ratio_30', 'buy_trade_ratio')
        spread = _v402_ctx_metric(r, 'spread_pct', 'orderbook_spread_pct')
        causes = _v402_loss_causes(r)
        buy_txt = '-' if buy < 0 else f"{buy:.2f}"
        sp_txt = '-' if spread < 0 else f"{spread:.2f}%"
        lines.append(f"- {t} / {pnl:+.2f}% / {_v402_exit_label(r)} / 보유 {hold:.1f}분 / {_v402_strategy_label(r)}")
        lines.append(f"  · 진입근거: {_v402_entry_reason(r)}")
        lines.append(f"  · 흐름: 최고 {peak:+.2f}% / 최저 {trough:+.2f}% / 매수체결 {buy_txt} / 스프레드 {sp_txt} / 원인 {', '.join(causes)}")
        lines.append(f"  · 다음확인: {_v402_next_check(causes)}")
    if len(target) > 10:
        lines.append(f"- 나머지 {len(target)-10}건은 같은 장부 기준으로 집계에 포함됨")
    lines += ['', '[수정 후보 · 아직 조건 변경 아님]']
    if cause_counter:
        top_cause = cause_counter.most_common(1)[0][0]
        lines.append(f"1) 최다 원인 '{top_cause}'가 entry_context 실제값 문제인지 S1 조건 문제인지 분리")
    else:
        lines.append('1) CLOSED가 더 쌓이면 원인 TOP부터 분리')
    if by_strategy:
        top_strategy, top_n = by_strategy.most_common(1)[0]
        lines.append(f"2) 최다 전략 '{top_strategy}' {top_n}건 쏠림 확인: 이 전략만 S1 신규진입 중지/강등할지 검토")
    lines.append('3) 바로 조건 조이기 금지: 먼저 진입스냅샷 누락/체결값 누락이면 배관부터 고침')
    lines.append('4) 실제 수정은 이 판독 결과를 보고 한 번에 묶어서 진행')
    return '\n'.join(lines)


def set_commands(updater):  # type: ignore[override]
    try:
        updater.bot.set_my_commands([
            BotCommand('health','메인/worker/paper 빠른상태'),
            BotCommand('workers','worker 상세 상태'),
            BotCommand('score','S1/S2/S3 성과'),
            BotCommand('s1_review','S1 손실 정밀판'),
            BotCommand('version_score','버전별/진입유형 성과'),
            BotCommand('quality','S1/S2/S3 후보품질'),
            BotCommand('pstatus','paper 상태'),
            BotCommand('popen','모의매매 진행중'),
            BotCommand('missed_trace','후보 handoff 추적'),
            BotCommand('errorlog','오류로그'),
            BotCommand('batch','묶음 확인'),
        ])
    except Exception as exc:
        log_error('set_commands', exc)

try:
    COMMANDS.update({
        'health': health_text,
        'core': health_text,
        'score': score_text,
        'pscore': pscore_text,
        's1_review': s1_review_text,
        's1review': s1_review_text,
        'loss_review': s1_review_text,
        'ploss_review': s1_review_text,
        'pstatus': pstatus_text,
        'missed_trace': missed_trace_text,
        'trace_missed': missed_trace_text,
    })
except Exception:
    pass


# =============================================================================
# v403: 조건지도 + 전략별 S3/S2/S1 단일화 표시
# - 전략 조건 따로, 생애주기 S단계 따로 보이던 구조를 한 화면에 보여준다.
# - 실제 S1 OPEN 경로는 strategy_worker_v0.34의 전략별 단계판정 단일 본선을 기준으로 한다.
# =============================================================================

def _v403_condition_map_fallback() -> Dict[str, Any]:
    return {
        "version": "main_v403_fallback",
        "schema": "strategy_stage_unified_v403",
        "summary": "전략별 조건 안에서 S3/S2/S1을 결정한다. 독립 S2→S1 승격판은 최종 OPEN 경로에서 사용하지 않는다.",
        "common_hard_blocks": [
            "최근 반복손실/하드손실", "이미 OPEN 중", "거래대금 2.5억 미만", "윗꼬리/고점끝물 위험",
            "micro fresh 시 스프레드 과다", "micro fresh 시 매수체결 부족", "매도벽/매도체결압력"
        ],
        "common_s1_safety": [
            "micro fresh + WS/quote fresh", "매수체결비 0.70 이상", "1분 체결지속 0.64 이상",
            "스프레드 0.18% 이하", "슬리피지 확인 0.20% 이하", "매도벽 확인/매도압력 없음",
            "가격반응 0.05 이상", "단기 반응 30초/1분/3분 중 확인", "VWAP -0.03 이상", "EMA5 -0.05 이상"
        ],
        "common_s2_recheck": [
            "micro fresh", "매수체결비 0.62 이상", "스프레드 0.28% 이하", "매도압력 없음",
            "VWAP -0.08 이상", "EMA5 -0.12 이상", "가격반응/단기흐름/거래량 중 재확인 재료"
        ],
        "stage_policy": [
            "S3: 전략별 관찰/복기 후보", "S2: 전략별 재확인/정보보강 후보", "S1: 전략별 S1 추가조건 + 공통 S1 안전문 통과 후보만 paper OPEN",
            "과거 독립 lifecycle S3→S2→S1 가격추적 승격은 최종 OPEN 경로에서 격리"
        ],
        "strategies": {
            "money_reaccel_s": {"label":"돈흐름 재가속", "core":["3분 0.25%↑", "5분 0.35%↑", "VWAP -0.05 이상", "EMA5 -0.08 이상", "거래량 확장"], "s1_extra":["3분 0.35%↑", "5분 0.45%↑", "거래량 확장", "상대강도 0 이상"], "s2_extra":["3분 0.20%↑ 또는 5분 0.35%↑ 또는 거래량 확장"]},
            "leader_momentum_s": {"label":"주도추세 지속", "core":["15분 0.65%↑", "30분 0.65%↑", "상대강도 0.30↑", "VWAP/EMA 양호", "장세 약함 제외"], "s1_extra":["15분 0.75%↑", "30분 0.75%↑", "상대강도 0.40↑", "장세 약함 아님"], "s2_extra":["15분 0.60%↑", "상대강도 0.25↑", "VWAP -0.05 이상", "가격반응 재료"]},
            "breakout_early_s": {"label":"돌파 초입", "core":["돌파캔들", "고점거리 -0.15 이상", "끝물추격 위험 제외"], "s1_extra":["돌파캔들", "거래량 확장", "고점거리 -0.08 이상", "3분 0.15%↑", "고점권 아님"], "s2_extra":["돌파캔들", "고점거리 -0.25 이상", "거래량 또는 3분 0.15%↑"]},
            "sweep_vwap_recovery_s": {"label":"저점 VWAP 회복", "core":["저점쓸림 회복", "VWAP -0.05 이상", "저점반등 0.40%↑"], "s1_extra":["저점회복", "저점반등 0.55%↑", "3분 0.08%↑", "당일위치 88% 미만"], "s2_extra":["저점회복", "VWAP -0.08 이상", "저점반등 0.35%↑", "가격반응 재료"]},
            "surge_rebreak_s": {"label":"급등 후 재돌파", "core":["15분 1.20%↑", "3분 0.15%↑", "고점접근 -0.25 이상", "윗꼬리 제외"], "s1_extra":["15분 1.20%↑", "3분 0.25%↑", "고점접근 -0.15 이상", "과열 아님"], "s2_extra":["15분 1.00%↑", "고점접근 -0.30 이상", "가격반응 재료"]},
            "leader_flow_adaptive_hold_s": {"label":"주도흐름 유동보유", "core":["3분/5분 단기흐름 또는 15/30분 중기흐름", "VWAP -0.10 이상", "EMA5 -0.15 이상", "거래대금 3억 이상", "최소 매수체결/스프레드"], "s1_extra":["15분 0.70%↑", "30분 0.40%↑", "상대강도 0 이상", "VWAP -0.03 이상", "EMA5 -0.05 이상", "3분 0.20%↑ 또는 5분 0.45%↑ 또는 거래량 확장", "고점권 아님"], "s2_extra":["15분 0.55%↑ 또는 5분 0.55%↑", "VWAP -0.08 이상", "EMA5 -0.12 이상"]}
        }
    }


def _v403_condition_map_obj() -> Dict[str, Any]:
    strat = _v398_load_json_small(FILES.get('strategy_summary', BASE_DIR/'clean_strategy_s_summary.json'), {}) or {}
    cmap = strat.get('condition_map') if isinstance(strat, dict) else None
    if isinstance(cmap, dict) and cmap:
        return cmap
    # 별도 파일이 있으면 우선 사용
    try:
        p = BASE_DIR / 'clean_strategy_condition_map.json'
        cmap2 = _v398_load_json_small(p, {}) or {}
        if isinstance(cmap2, dict) and cmap2:
            return cmap2
    except Exception:
        pass
    return _v403_condition_map_fallback()


def condition_map_text() -> str:
    cmap = _v403_condition_map_obj()
    lines = [
        '🧭 조건지도 /condition_map',
        '- 목적: 공통 조건, 전략별 조건, S3/S2/S1 단계가 어디서 갈라지는지 한 화면에서 봅니다.',
        f"- 기준: {cmap.get('schema','-')} / {cmap.get('version','-')}",
        f"- 결론: {cmap.get('summary','전략별 단계판정 단일화')}",
        '', '[공통 차단 조건]'
    ]
    for x in cmap.get('common_hard_blocks', [])[:12]:
        lines.append(f"- {x}")
    lines += ['', '[공통 S1 안전문 · 실제 OPEN 직전]']
    for x in cmap.get('common_s1_safety', [])[:14]:
        lines.append(f"- {x}")
    lines += ['', '[공통 S2 재확인문 · 매수 아님]']
    for x in cmap.get('common_s2_recheck', [])[:12]:
        lines.append(f"- {x}")
    lines += ['', '[S3/S2/S1 정책]']
    for x in cmap.get('stage_policy', [])[:10]:
        lines.append(f"- {x}")
    lines += ['', '[전략별 조건]']
    strategies = cmap.get('strategies') if isinstance(cmap.get('strategies'), dict) else {}
    order = ['money_reaccel_s','leader_momentum_s','breakout_early_s','sweep_vwap_recovery_s','surge_rebreak_s','leader_flow_adaptive_hold_s']
    for key in order:
        obj = strategies.get(key) if isinstance(strategies.get(key), dict) else {}
        if not obj:
            continue
        lines.append(f"\n▶ {obj.get('label', key)}")
        core = ' / '.join(map(str, obj.get('core', [])[:5])) or '-'
        s2 = ' / '.join(map(str, obj.get('s2_extra', [])[:5])) or '-'
        s1 = ' / '.join(map(str, obj.get('s1_extra', [])[:7])) or '-'
        lines.append(f"- core: {core}")
        lines.append(f"- S2: {s2}")
        lines.append(f"- S1: {s1}")
    lines += ['', '[판독]', '- 이제 S1은 독립 lifecycle 가격추적 승격이 아니라, 전략별 S1 조건 + 공통 S1 안전문이 같이 맞아야 합니다.', '- S2/S3는 계속 남기되, S2/S3 자체가 paper OPEN 조건이 되지는 않습니다.']
    return '\n'.join(lines)


# v403 s1_review 하단에 조건지도 기준을 함께 표시한다.
_v403_prev_s1_review_text = s1_review_text

def s1_review_text() -> str:  # type: ignore[override]
    body = _v403_prev_s1_review_text()
    cmap = _v403_condition_map_obj()
    return body + "\n\n[조건 구조 기준 · v403]\n- " + str(cmap.get('summary','전략별 S3/S2/S1 단일화')) + "\n- 상세 조건은 /condition_map 에서 확인"


def batch_handler(update, context):  # type: ignore[override]
    cmds = context.args or ['health','pstatus','score','s1_review','condition_map','missed_trace','errorlog']
    cmds = [str(x).strip().lstrip('/') for x in cmds[:10] if str(x).strip()]
    st = time.time(); sent = 0; timings = []
    try:
        send(update, f"📦 자동 묶음 명령 접수\n- 실행 {len(cmds)}개\n- v403: 조건지도 + 전략별 S3/S2/S1 단일화")
    except Exception:
        pass
    total = len(cmds)
    for raw in cmds:
        name = raw.strip().lstrip('/')
        fn = COMMANDS.get(name)
        if not fn:
            continue
        t = time.time()
        try:
            body = fn(); ok = 'OK'
        except Exception as exc:
            body = f"❌ /{name} 오류 {exc.__class__.__name__}: {exc}"; ok = 'ERR'; log_error(f'batch_{name}', exc)
        sec = time.time() - t; sent += 1
        timings.append(f"- {'✅' if ok=='OK' else '❌'} /{name}: {sec:.2f}s / {ok}")
        send(update, f"[{sent}/{total}] /{name} ({sec:.2f}s / {ok})\n{body}")
    send(update, "🧾 자동 묶음 시간표 · v403 명령별 전송\n" + "\n".join(timings) + f"\n- 합계 {time.time()-st:.2f}s")


def set_commands(updater):  # type: ignore[override]
    try:
        updater.bot.set_my_commands([
            BotCommand('health','메인/worker/paper 빠른상태'),
            BotCommand('workers','worker 상세 상태'),
            BotCommand('score','S1/S2/S3 성과'),
            BotCommand('s1_review','S1 손실 정밀판'),
            BotCommand('condition_map','조건지도'),
            BotCommand('version_score','버전별/진입유형 성과'),
            BotCommand('quality','S1/S2/S3 후보품질'),
            BotCommand('pstatus','paper 상태'),
            BotCommand('popen','모의매매 진행중'),
            BotCommand('missed_trace','후보 handoff 추적'),
            BotCommand('errorlog','오류로그'),
            BotCommand('batch','묶음 확인'),
        ])
    except Exception as exc:
        log_error('set_commands', exc)

try:
    COMMANDS.update({
        'health': health_text,
        'core': health_text,
        'score': score_text,
        'pscore': pscore_text,
        's1_review': s1_review_text,
        's1review': s1_review_text,
        'condition_map': condition_map_text,
        'conditions': condition_map_text,
        'loss_review': s1_review_text,
        'ploss_review': s1_review_text,
        'pstatus': pstatus_text,
        'missed_trace': missed_trace_text,
        'trace_missed': missed_trace_text,
    })
except Exception:
    pass

# v406: early main call disabled so tail command registrations load before polling
# if __name__=='__main__': main()


# =============================================================================
# main v2.13.374 / v406: S1 후보 점검판 + 쉬운 문구
# - 개발자 단어를 줄이고 S1 미달 사유를 사람말로 표시한다.
# - "정보부족"은 가격/WS/micro/체결/스프레드/슬리피지/매도벽 등으로 나눈다.
# - 조건 수치 자체는 바꾸지 않는다.
# =============================================================================
BOT_VERSION = "수익형 v2.13.389"
RESTORE_BUILD = "v425_v389_disable_main_auto_retention_2026-05-25"
S1_BLOCK_AUDIT_FILE = BASE_DIR / "clean_strategy_s1_block_audit.json"

_EASY_STRATEGY = {
    'money_reaccel_s':'돈흐름 재가속', 'leader_momentum_s':'주도추세 지속', 'breakout_early_s':'돌파 초입',
    'sweep_vwap_recovery_s':'저점 VWAP 회복', 'surge_rebreak_s':'급등 후 재돌파', 'leader_flow_adaptive_hold_s':'주도흐름 유동보유'
}

def _v405_load_audit() -> Dict[str, Any]:
    obj = _v398_load_json_small(S1_BLOCK_AUDIT_FILE, {}) or {}
    return obj if isinstance(obj, dict) else {}

def _v405_easy_reason(x: Any) -> str:
    t = str(x or '').strip()
    repl = {
        'S1아님':'S1 실제진입 조건 미달', 'not_s1':'S1 실제진입 조건 미달', 'micro재확인필요':'호가·체결 재확인 필요',
        'WS재확인필요':'실시간 시세 재확인 필요', '가격반응미확인':'가격반응 값 없음', '매수체결지속미확인':'1분 매수지속 값 없음',
        '슬리피지미확인/주의':'예상 미끄러짐 확인 필요', '매도벽미확인':'매도벽 정보 없음', '스프레드주의':'스프레드 부담',
    }
    for k,v in repl.items(): t = t.replace(k,v)
    return t or '-'

def _v405_top_lines(title: str, d: Any, icon: str='⚠️', limit: int=7) -> List[str]:
    lines=[title]
    if not isinstance(d, dict) or not d:
        lines.append('- 없음')
        return lines
    top=sorted(d.items(), key=lambda kv: int(fnum(kv[1], default=0)), reverse=True)[:limit]
    for k,v in top:
        lines.append(f"- {icon} {_v405_easy_reason(k)}: {int(fnum(v, default=0))}개")
    return lines

def _v405_fmt_missing(items: Any, limit: int=4) -> str:
    if not isinstance(items, list) or not items: return '없음'
    vals=[]
    for x in items[:limit]:
        if isinstance(x, dict): vals.append(str(x.get('label') or x.get('key') or '-'))
        else: vals.append(str(x))
    return ', '.join(vals) if vals else '없음'

def _v405_fmt_fail(items: Any, limit: int=3) -> str:
    if not isinstance(items, list) or not items: return '추가확인'
    vals=[]
    for x in items[:limit]:
        if isinstance(x, dict):
            label=str(x.get('label') or x.get('key') or '-')
            val=str(x.get('value') or '')
            vals.append(label + (f"({val})" if val else ''))
        else: vals.append(str(x))
    return ' / '.join(vals)

def s1_candidates_text() -> str:
    audit=_v405_load_audit()
    strat=_v398_load_json_small(FILES['strategy_summary'], {}) or {}
    sc = strat.get('s_stage_counts') if isinstance(strat.get('s_stage_counts'), dict) else {}
    samples = audit.get('samples') if isinstance(audit.get('samples'), list) else []
    age=_v398_file_age(S1_BLOCK_AUDIT_FILE)
    lines=[
        '🔎 S1 후보 점검 /s1_candidates',
        '- 목적: 후보가 왜 실제진입(S1)이 아닌지 쉽게 봅니다.',
        '- 기준: 부족정보를 한 단어로 뭉치지 않고 세부 항목으로 나눕니다.',
        f"- 갱신: {age:.1f}s 전 / 구조 {audit.get('schema', strat.get('stage_policy_schema','-'))}",
        f"- 현재 후보: S1 {sc.get('S1',0)} / S2 {sc.get('S2',0)} / S3 {sc.get('S3',0)} / latest {strat.get('paper_latest_count','-')}",
        '',
    ]
    lines += _v405_top_lines('[왜 S1이 아닌지 TOP]', audit.get('reason_top'), '⚠️', 8)
    lines += [''] + _v405_top_lines('[없는 정보 TOP]', audit.get('missing_info_top'), '❔', 8)
    sm = audit.get('strategy_missing_info') if isinstance(audit.get('strategy_missing_info'), dict) else {}
    lines += ['', '[전략별 부족정보]']
    if sm:
        for name, d in list(sm.items())[:6]:
            if isinstance(d, dict) and d:
                top=sorted(d.items(), key=lambda kv:int(fnum(kv[1],default=0)), reverse=True)[:4]
                lines.append(f"- {name}: " + ' / '.join(f"{_v405_easy_reason(k)} {int(fnum(v,default=0))}" for k,v in top))
    else:
        lines.append('- 아직 집계 없음')
    lines += ['', '[재확인 후보 TOP]']
    if samples:
        for s in samples[:10]:
            if not isinstance(s, dict): continue
            lines.append(f"- ⚠️ {norm_ticker(s.get('ticker'))} / {s.get('strategy','-')} / {s.get('stage','-')} / 점수 {s.get('score','-')}")
            lines.append(f"  · 못 산 이유: {_v405_easy_reason(s.get('summary'))}")
            lines.append(f"  · 없는 정보: {_v405_fmt_missing(s.get('missing'))}")
            lines.append(f"  · 필요정보: {s.get('required_ready','-')}/{s.get('required_total','-')}개 준비")
    else:
        lines.append('- 재확인 후보 샘플 없음')
    outside=audit.get('outside_reference_info') if isinstance(audit.get('outside_reference_info'), list) else []
    lines += ['', '[다른 단타 방식과 비교해 아직 약한 보조정보]', '- 아래 항목은 바로 조건에 넣자는 뜻이 아니라, 나중에 검토할 후보입니다.']
    if outside:
        for x in outside[:6]:
            if isinstance(x, dict): lines.append(f"- ❔ {x.get('name','-')} / 상태 {x.get('status','-')} / {x.get('note','')}")
    else:
        lines.append('- 아직 점검값 없음')
    lines += ['', '[판독]', '- S1이 0이어도 바로 조건을 풀지 않습니다.', '- 먼저 어떤 정보가 없고, 어떤 조건에서 막히는지 보고 한 번에 수정합니다.']
    return '\n'.join(lines)

_old_pstatus_v405 = pstatus_text

def pstatus_text() -> str:  # type: ignore[override]
    body = _old_pstatus_v405()
    body = body.replace('🧪 paper 상태 /pstatus · v0.125 단일장부 연결', '🧪 paper 상태 /pstatus · paper v0.126 호환 장부')
    body = body.replace('[실제 모의매매 성과 · v0.125 CLOSED 직접조회]', '[실제 모의매매 성과 · paper 장부 직접조회]')
    body = body.replace('선별배관:', '후보선별:')
    body = body.replace('S1선택', 'S1 실제진입 선택')
    body = body.replace('micro대기', '호가·체결 대기')
    body = body.replace('이번OPEN', '이번 진입')
    return body

_old_score_v405 = score_text

def score_text() -> str:  # type: ignore[override]
    body = _old_score_v405()
    body = body.replace('paper_bot_v0.125 CLOSED 장부 직접조회. 구 score cache는 기본 성과판에서 사용하지 않습니다.', 'paper v0.126 호환 CLOSED 장부 직접조회. 구 score cache는 기본 성과판에서 사용하지 않습니다.')
    body = body.replace('v0.125 CLOSED', 'paper CLOSED')
    return body

_old_s1_review_v405 = s1_review_text

def s1_review_text() -> str:  # type: ignore[override]
    body = _old_s1_review_v405()
    body = body.replace('paper_bot_v0.125 CLOSED 직접조회', 'paper v0.126 호환 CLOSED 직접조회')
    body = body.replace('entry_context', '진입 당시 기록')
    body = body.replace('micro', '호가·체결')
    body += '\n\n[다음 확인]\n- S1 후보가 안 열리면 /s1_candidates에서 막힌 이유와 부족정보를 먼저 봅니다.\n- 조건 수정은 /s1_candidates 결과를 본 뒤 한 번에 묶어서 진행합니다.'
    return body

def missed_trace_text() -> str:  # type: ignore[override]
    vers=_v398_paper_versions(); obj=vers.get('trace') if isinstance(vers.get('trace'),dict) else {}
    rows=obj.get('rows') if isinstance(obj,dict) and isinstance(obj.get('rows'),list) else []
    rows=[r for r in rows if isinstance(r,dict)][:300]
    audit=_v405_load_audit(); samples=audit.get('samples') if isinstance(audit.get('samples'),list) else []
    labels={'open':'OPEN됨','closed':'CLOSED됨','selected_for_open':'S1 선택됨','not_s1':'S1 실제진입 조건 미달','micro_wait':'호가·체결 재확인대기','merged_waiting_pick':'선별대기','expired':'후보만료','skipped':'스킵','not_merged':'미병합'}
    by=Counter(str(r.get('status') or 'unknown') for r in rows)
    lines=['🧭 후보 추적 /missed_trace', '- 기준: 후보가 paper까지 왔는지, S1 실제진입까지 갔는지 봅니다.', f"- paper {vers.get('paper_version')} / trace {vers.get('trace_version')} / trace age {vers.get('trace_age',0):.1f}s / rows {len(rows)}", '', '[상태]']
    if by:
        for k,v in by.most_common(8):
            icon='✅' if k in {'open','closed','selected_for_open'} else '⚠️' if k in {'expired','not_merged','micro_wait','skipped'} else '❔'
            lines.append(f"- {icon} {labels.get(k,k)}: {v}개")
    else: lines.append('- trace 없음')
    lines += [''] + _v405_top_lines('[S1 미달 이유]', audit.get('reason_top'), '⚠️', 6)
    lines += [''] + _v405_top_lines('[부족정보]', audit.get('missing_info_top'), '❔', 6)
    lines += ['', '[재확인 후보 TOP]']
    if samples:
        for s in samples[:10]:
            if not isinstance(s, dict): continue
            lines.append(f"- ⚠️ {norm_ticker(s.get('ticker'))} / {s.get('strategy','-')} / {s.get('stage','-')} / 점수 {s.get('score','-')}")
            lines.append(f"  · 이유: {_v405_easy_reason(s.get('summary'))}")
            lines.append(f"  · 부족: {_v405_fmt_missing(s.get('missing'))}")
    else:
        risky=[r for r in rows if str(r.get('status') or '') not in {'open','closed','selected_for_open'}]
        for r in risky[:10]:
            st=str(r.get('status') or '-')
            lines.append(f"- ⚠️ {norm_ticker(r.get('ticker'))} / {r.get('strategy') or r.get('strategy_key','-')} / 점수 {r.get('score','-')} / 상태 {labels.get(st,st)} / 이유 {_v405_easy_reason(r.get('reason','-'))}")
        if not risky: lines.append('- 현재 재확인 후보 없음')
    return '\n'.join(lines)

_old_condition_map_v405 = condition_map_text

def condition_map_text() -> str:  # type: ignore[override]
    body = _old_condition_map_v405()
    audit=_v405_load_audit(); cmap = (_v398_load_json_small(BASE_DIR/'clean_strategy_condition_map.json', {}) or {})
    req = cmap.get('strategy_required_info') if isinstance(cmap.get('strategy_required_info'), dict) else {}
    outside = cmap.get('outside_reference_info') if isinstance(cmap.get('outside_reference_info'), list) else []
    lines=[body, '', '[전략별 필요한 정보 · 쉬운 이름]']
    if req:
        for name, vals in req.items():
            if isinstance(vals, list): lines.append(f"- {name}: " + ', '.join(map(str, vals[:8])))
    else:
        lines.append('- 아직 조건지도 갱신 대기')
    lines += ['', '[다른 단타 방식 대비 보조정보 점검]', '- 바로 추가 조건이 아니라, 나중에 검토할 참고 목록입니다.']
    for x in outside[:6] if isinstance(outside, list) else []:
        if isinstance(x, dict): lines.append(f"- ❔ {x.get('name','-')} / {x.get('status','-')} / {x.get('note','')}")
    return '\n'.join(lines)

def batch_handler(update, context):  # type: ignore[override]
    cmds = context.args or ['health','pstatus','s1_candidates','missed_trace','errorlog']
    cmds = [str(x).strip().lstrip('/') for x in cmds[:10] if str(x).strip()]
    st = time.time(); sent = 0; timings = []
    try:
        send(update, f"📦 자동 묶음 명령 접수\n- 실행 {len(cmds)}개\n- v408: S1 후보 결론판 + 보조정보 완성")
    except Exception:
        pass
    total = len(cmds)
    for raw in cmds:
        name = raw.strip().lstrip('/')
        fn = COMMANDS.get(name)
        if not fn:
            sent += 1
            body = f"❌ /{name} 명령이 메인봇에 연결되지 않았습니다.\n- 이 줄이 보이면 명령 등록 누락입니다.\n- 그냥 건너뛰지 않고 표시하도록 바꿨습니다."
            timings.append(f"- ❌ /{name}: 미등록")
            send(update, f"[{sent}/{total}] /{name} (미등록)\n{body}")
            continue
        t = time.time()
        try:
            body = fn(); ok = 'OK'
        except Exception as exc:
            body = f"❌ /{name} 오류 {exc.__class__.__name__}: {exc}"; ok = 'ERR'; log_error(f'batch_{name}', exc)
        sec = time.time() - t; sent += 1
        timings.append(f"- {'✅' if ok=='OK' else '❌'} /{name}: {sec:.2f}s / {ok}")
        send(update, f"[{sent}/{total}] /{name} ({sec:.2f}s / {ok})\n{body}")
    send(update, "🧾 자동 묶음 시간표 · v407 명령별 전송\n" + "\n".join(timings) + f"\n- 합계 {time.time()-st:.2f}s")

try:
    if 'COMMANDS' in globals():
        COMMANDS.update({
            'health': health_text,
            'core': health_text,
            'pstatus': pstatus_text,
            'score': score_text,
            'pscore': score_text,
            's1_review': s1_review_text,
            's1review': s1_review_text,
            's1_candidates': s1_candidates_text,
            's1': s1_candidates_text,
            'condition_map': condition_map_text,
            'conditions': condition_map_text,
            'missed_trace': missed_trace_text,
            'trace_missed': missed_trace_text,
        })
except Exception:
    pass


def set_commands(updater):  # type: ignore[override]
    try:
        updater.bot.set_my_commands([
            BotCommand('health','전체 상태'),
            BotCommand('pstatus','paper 상태'),
            BotCommand('s1_candidates','S1 후보 점검'),
            BotCommand('missed_trace','후보 추적'),
            BotCommand('condition_map','조건지도'),
            BotCommand('score','성과표'),
            BotCommand('s1_review','S1 손익 점검'),
            BotCommand('errorlog','오류로그'),
            BotCommand('batch','묶음 확인'),
        ])
    except Exception as exc:
        log_error('set_commands', exc)


# =============================================================================
# main v2.13.375 / v407: 가격반응 배관수리 결과 표시 + 보조정보 쉬운 점검
# - strategy_worker v0.32가 만든 가격반응 계산방식과 보조정보 상태를 사람말로 보여준다.
# - 조건 수치 변경 없음. S1 후보 판단 보조판만 개선.
# =============================================================================

V407_WORDS = {
    'core': '기본 포착',
    'relative': '시장보다 강한 정도',
    'relative_strength': '시장보다 강한 정도',
    'breakout_hint': '돌파 신호',
    'recent_high_gap': '고점과의 거리',
    'volume_expanding': '거래량 증가',
    'price_alive_s2': '가격 반응 살아있음',
    'leader_flow_adaptive_hold_s': '주도흐름 유동보유',
    'money_reaccel_s': '돈흐름 재가속',
    'leader_momentum_s': '주도추세 지속',
    'breakout_early_s': '돌파 초입',
    'sweep_vwap_recovery_s': '저점 VWAP 회복',
    'surge_rebreak_s': '급등 후 재돌파',
    'market!=약함': '장이 너무 약하면 제외',
    'not high_end': '고점 끝물은 제외',
    'not overheat': '급등 과열은 제외',
    'no long_upper_wick': '윗꼬리 과하면 제외',
    'turnover': '거래대금',
    'min buy/spread': '최소 매수체결·스프레드 확인',
}

def _v407_easy_text(s: Any) -> str:
    text = str(s)
    for a,b in V407_WORDS.items():
        text = text.replace(a,b)
    text = text.replace('>=', ' ≥ ').replace('<=', ' ≤ ')
    text = text.replace('3m', '3분').replace('5m', '5분').replace('15m', '15분').replace('30m', '30분')
    text = text.replace('VWAP', 'VWAP').replace('EMA5', 'EMA5')
    return text

def _v407_top_plain(d: Any, icon: str='✅', limit: int=6) -> List[str]:
    if not isinstance(d, dict) or not d:
        return ['- 아직 없음']
    out=[]
    for k,v in sorted(d.items(), key=lambda kv:int(fnum(kv[1],default=0)), reverse=True)[:limit]:
        out.append(f"- {icon} {_v405_easy_reason(k)}: {int(fnum(v, default=0))}개")
    return out

_old_s1_candidates_v407 = s1_candidates_text

def s1_candidates_text() -> str:  # type: ignore[override]
    body = _old_s1_candidates_v407()
    audit = _v405_load_audit()
    lines = [body]
    prs = audit.get('price_reaction_sources') if isinstance(audit.get('price_reaction_sources'), dict) else {}
    lines += ['', '[가격반응 계산상태]', '- 조건을 푼 게 아니라, 비어 있던 가격반응을 계산 가능한 값으로 채웁니다.']
    if prs:
        for k,v in sorted(prs.items(), key=lambda kv:int(fnum(kv[1],default=0)), reverse=True)[:6]:
            icon = '✅' if k != '계산불가' else '❌'
            lines.append(f"- {icon} {_v405_easy_reason(k)}: {int(fnum(v,default=0))}개")
    else:
        lines.append('- 아직 가격반응 계산 집계 없음')
    samples = audit.get('samples') if isinstance(audit.get('samples'), list) else []
    if samples:
        lines += ['', '[후보별 가격반응 예시]']
        for s in samples[:5]:
            if not isinstance(s, dict): continue
            pr = s.get('price_reaction') if isinstance(s.get('price_reaction'), dict) else {}
            val = pr.get('value')
            src = pr.get('source') or '-'
            note = pr.get('note') or ''
            valtxt = '-' if val in (None, '') else f"{fnum(val, default=0):+.2f}%"
            lines.append(f"- {norm_ticker(s.get('ticker'))}: {valtxt} / {src} {('· '+str(note)) if note else ''}")
    aux_ready = audit.get('aux_ready_top') if isinstance(audit.get('aux_ready_top'), dict) else {}
    aux_missing = audit.get('aux_missing_top') if isinstance(audit.get('aux_missing_top'), dict) else {}
    lines += ['', '[보조정보 수집상태 · 조건 아님]', '- 아래 정보는 바로 매수조건으로 쓰지 않고, 이긴 후보/진 후보 비교용으로 저장합니다.']
    lines.append('✅ 들어오는 정보')
    lines += _v407_top_plain(aux_ready, '✅', 8)
    lines.append('❔ 아직 약한 정보')
    lines += _v407_top_plain(aux_missing, '❔', 8)
    lines += ['', '[판독 순서]', '1) 가격반응이 계산되는데도 S1이 0이면 → 조건이 센지 봅니다.', '2) 가격반응이 아직 계산불가면 → 배관부터 더 봅니다.', '3) 스프레드/미끄러짐이 큰 후보는 살리면 안 됩니다.']
    return '\n'.join(lines)

_old_condition_map_v407 = condition_map_text

def condition_map_text() -> str:  # type: ignore[override]
    body = _old_condition_map_v407()
    body = _v407_easy_text(body)
    audit = _v405_load_audit()
    pol = audit.get('price_reaction_policy') if isinstance(audit.get('price_reaction_policy'), list) else []
    lines = [body, '', '[가격반응 계산 기준 · v407]']
    if pol:
        for x in pol: lines.append(f"- {_v407_easy_text(x)}")
    else:
        lines += ['- 1순위: 전용 가격반응값', '- 2순위: 포착가 대비 현재가', '- 3순위: 30초/1분/3분 흐름으로 보조계산', '- 조건 수치 +0.05는 변경하지 않음']
    lines += ['', '[보기 쉽게 바꾼 말]', '- 기본 포착 = 전략 후보로 처음 잡는 조건', '- S3 = 관찰만, S2 = 재확인, S1 = 실제 모의진입', '- 시장보다 강한 정도 = 다른 코인/전체장보다 더 센지', '- 예상 미끄러짐 = 사자마자 호가 때문에 손해 볼 위험']
    return '\n'.join(lines)

_old_missed_trace_v407 = missed_trace_text

def missed_trace_text() -> str:  # type: ignore[override]
    body = _old_missed_trace_v407()
    audit = _v405_load_audit()
    prs = audit.get('price_reaction_sources') if isinstance(audit.get('price_reaction_sources'), dict) else {}
    if prs:
        extra = ['','[가격반응]', '- S1 미달 사유 중 가격반응은 이제 빈값이면 보조계산합니다.']
        for k,v in sorted(prs.items(), key=lambda kv:int(fnum(kv[1],default=0)), reverse=True)[:4]:
            extra.append(f"- {_v405_easy_reason(k)}: {int(fnum(v,default=0))}개")
        body += '\n' + '\n'.join(extra)
    return body

try:
    if 'COMMANDS' in globals():
        COMMANDS.update({
            's1_candidates': s1_candidates_text,
            's1': s1_candidates_text,
            'condition_map': condition_map_text,
            'conditions': condition_map_text,
            'missed_trace': missed_trace_text,
            'trace_missed': missed_trace_text,
        })
except Exception:
    pass

# batch 기본 구성만 v407 기준으로 한 번 더 고정
_old_batch_v407 = batch_handler

def batch_handler(update, context):  # type: ignore[override]
    if not getattr(context, 'args', None):
        context.args = ['health','pstatus','s1_candidates','missed_trace','condition_map','errorlog']
    return _old_batch_v407(update, context)





# =============================================================================
# main v2.13.376 / v408: S1 후보 결론판 + 보조정보 완성 표시
# - S1/S2/S3를 더 쪼개지 않고, S1 미달 후보를 사람이 보기 쉽게 판독한다.
# - 아까운 후보 / 재확인 후보 / 안 산 게 맞는 후보는 새 등급이 아니라 화면 해석이다.
# =============================================================================
RESTORE_BUILD = "v425_v389_disable_main_auto_retention_2026-05-25"

_DECISION_ORDER = ["✅ 아까운 후보", "⚠️ 재확인 후보", "❌ 안 산 게 맞음", "❔ 판독대기"]

def _v408_bucket_icon(text: Any) -> str:
    t=str(text or '')
    if '아까운' in t: return '✅'
    if '안 산 게 맞' in t or '버린' in t: return '❌'
    if '재확인' in t: return '⚠️'
    return '❔'

def _v408_short_reason(s: Dict[str, Any]) -> str:
    for k in ('review_decision_reason','decision_reason','why_decision'):
        v=s.get(k)
        if v: return str(v)
    return _v405_easy_reason(s.get('summary'))

_old_s1_candidates_v408_base = s1_candidates_text

def s1_candidates_text() -> str:  # type: ignore[override]
    audit=_v405_load_audit()
    body=_old_s1_candidates_v408_base()
    decision_top = audit.get('decision_top') if isinstance(audit.get('decision_top'), dict) else {}
    samples = audit.get('samples') if isinstance(audit.get('samples'), list) else []
    aux_ready = audit.get('aux_ready_top') if isinstance(audit.get('aux_ready_top'), dict) else {}
    aux_missing = audit.get('aux_missing_top') if isinstance(audit.get('aux_missing_top'), dict) else {}
    lines=[body]
    lines += ['', '━━━━━━━━━━━━━━━━━━━━', '🧭 최종 판독 · 새 등급 아님', '- S1/S2/S3 구조는 그대로입니다.', '- 아래 구분은 “왜 안 샀는지”를 사람이 빨리 보려고 붙인 해석입니다.', '']
    lines.append('[후보 판독 요약]')
    if decision_top:
        # display in stable user-friendly order first
        used=set()
        for name in _DECISION_ORDER:
            if name in decision_top:
                used.add(name); lines.append(f"- {name}: {int(fnum(decision_top.get(name), default=0))}개")
        for k,v in sorted(decision_top.items(), key=lambda kv:int(fnum(kv[1], default=0)), reverse=True):
            if k not in used:
                lines.append(f"- {_v408_bucket_icon(k)} {k}: {int(fnum(v, default=0))}개")
    else:
        lines.append('- 아직 판독 집계 없음')
    grouped={}
    for s in samples:
        if not isinstance(s, dict): continue
        d=str(s.get('review_decision') or s.get('decision') or '❔ 판독대기')
        grouped.setdefault(d, []).append(s)
    def one_line(s: Dict[str, Any]) -> str:
        t=norm_ticker(s.get('ticker'))
        strat=s.get('strategy') or s.get('strategy_key') or '-'
        stage=s.get('stage') or '-'
        score=s.get('score','-')
        return f"- {t} / {strat} / {stage} / 점수 {score}\n  · 이유: {_v408_short_reason(s)}\n  · 부족: {_v405_fmt_missing(s.get('missing'))}"
    for name in _DECISION_ORDER:
        arr=grouped.get(name, [])
        if not arr: continue
        lines += ['', f'[{name}]']
        for s in arr[:5]: lines.append(one_line(s))
    # include other groups, if any
    for name, arr in grouped.items():
        if name in _DECISION_ORDER or not arr: continue
        lines += ['', f'[{name}]']
        for s in arr[:3]: lines.append(one_line(s))
    lines += ['', '📌 지금 판단 기준']
    lines += ['- 스프레드·미끄러짐이 큰 후보는 손실 위험이 커서 안 산 게 맞습니다.', '- 정보가 다 있고 가격반응만 아주 살짝 부족한 후보는 “아까운 후보”로 따로 봅니다.', '- 조건 수치는 아직 바꾸지 않았고, 이 판독으로 놓친 후보를 복기합니다.']
    lines += ['', '[보조정보 완성도 · 조건 아님]']
    for label in ['RSI/과열 위치','MACD/추세 전환','볼린저밴드 위치','체결 속도 가속도','호가잔량 변화','BTC/전체장 선행 방향']:
        r=int(fnum(aux_ready.get(label), default=0)) if isinstance(aux_ready, dict) else 0
        m=int(fnum(aux_missing.get(label), default=0)) if isinstance(aux_missing, dict) else 0
        icon='✅' if r>0 and m==0 else '⚠️' if r>0 else '❔'
        lines.append(f"- {icon} {label}: 수집 {r} / 부족 {m}")
    return '\n'.join(lines)

_old_missed_trace_v408_base = missed_trace_text

def missed_trace_text() -> str:  # type: ignore[override]
    body=_old_missed_trace_v408_base()
    audit=_v405_load_audit()
    decision_top = audit.get('decision_top') if isinstance(audit.get('decision_top'), dict) else {}
    if decision_top:
        lines=[body, '', '[후보 판독 요약 · 새 등급 아님]']
        for name in _DECISION_ORDER:
            if name in decision_top:
                lines.append(f"- {name}: {int(fnum(decision_top.get(name), default=0))}개")
        return '\n'.join(lines)
    return body

_old_condition_map_v408_base = condition_map_text

def condition_map_text() -> str:  # type: ignore[override]
    body=_old_condition_map_v408_base()
    extra=['', '[v408 운영 기준]', '- S1/S2/S3 구조는 더 쪼개지 않습니다.', '- “아까운 후보/재확인 후보/안 산 게 맞는 후보”는 새 등급이 아니라 복기용 해석입니다.', '- RSI, MACD, 볼린저밴드, 체결속도, 호가잔량 변화, BTC/전체장 방향은 조건이 아니라 비교용 정보입니다.', '- 조건 수치 변경은 새 CLOSED/놓친 후보 결과를 본 뒤 한 번에 묶어서만 합니다.']
    return body + '\n' + '\n'.join(extra)

def batch_handler(update, context):  # type: ignore[override]
    if not getattr(context, 'args', None):
        context.args = ['health','pstatus','s1_candidates','missed_trace','condition_map','errorlog']
    return _old_batch_v407(update, context)



# =============================================================================
# main v2.13.377 / v409: v408 판독판 실제 명령 연결 수술
# - v408에서 COMMAND_TEXT로 잘못 연결된 경로를 제거하고 실제 COMMANDS에 연결한다.
# - /s1_candidates, /missed_trace, /condition_map은 v409 최종 함수 하나만 보게 한다.
# - S1/S2/S3 구조와 조건 수치는 변경하지 않는다.
# =============================================================================
RESTORE_BUILD = "v425_v389_disable_main_auto_retention_2026-05-25"
BOT_VERSION = "수익형 v2.13.389"

def _v409_force_schema_text(body: str) -> str:
    body = str(body or "")
    body = body.replace("strategy_stage_unified_v407_price_reaction_aux_info", "strategy_stage_unified_v409_decision_route_fix")
    body = body.replace("strategy_stage_unified_v408_s1_decision_aux_complete", "strategy_stage_unified_v409_decision_route_fix")
    body = body.replace("v407 명령별 전송", "v411 명령별 전송")
    body = body.replace("v408: S1 후보 결론판 + 보조정보 완성", "v411: 메인봇 컴파일 오류수정 + S1 후보 판독판 연결")
    return body

def _v409_decision_section(audit: Dict[str, Any]) -> str:
    lines = ["", "━━━━━━━━━━━━━━━━━━━━", "🧭 후보 판독 결론 · 새 등급 아님"]
    lines += ["- S1/S2/S3 구조는 그대로입니다.", "- 아래 구분은 ‘왜 안 샀는지’를 빨리 보기 위한 해석입니다."]
    decision_top = audit.get("decision_top") if isinstance(audit.get("decision_top"), dict) else {}
    samples = audit.get("samples") if isinstance(audit.get("samples"), list) else []
    lines += ["", "[판독 요약]"]
    if decision_top:
        used = set()
        for name in _DECISION_ORDER:
            if name in decision_top:
                used.add(name)
                lines.append(f"- {name}: {int(fnum(decision_top.get(name), default=0))}개")
        for k, v in sorted(decision_top.items(), key=lambda kv: int(fnum(kv[1], default=0)), reverse=True):
            if k not in used:
                lines.append(f"- {_v408_bucket_icon(k)} {k}: {int(fnum(v, default=0))}개")
    else:
        lines.append("- 아직 판독 집계 없음")
    grouped: Dict[str, List[Dict[str, Any]]] = {}
    for s in samples:
        if not isinstance(s, dict):
            continue
        d = str(s.get("review_decision") or s.get("decision") or "❔ 판독대기")
        grouped.setdefault(d, []).append(s)
    def one(s: Dict[str, Any]) -> str:
        t = norm_ticker(s.get("ticker"))
        strat = s.get("strategy") or s.get("strategy_key") or "-"
        stage = s.get("stage") or "-"
        score = s.get("score", "-")
        return f"- {t} / {strat} / {stage} / 점수 {score}\n  · 판단: {_v408_short_reason(s)}\n  · 부족: {_v405_fmt_missing(s.get('missing'))}"
    for name in _DECISION_ORDER:
        arr = grouped.get(name, [])
        if not arr:
            continue
        lines += ["", f"[{name}]"]
        for s in arr[:5]:
            lines.append(one(s))
    for name, arr in grouped.items():
        if name in _DECISION_ORDER or not arr:
            continue
        lines += ["", f"[{name}]"]
        for s in arr[:3]:
            lines.append(one(s))
    lines += ["", "📌 지금 판단 기준"]
    lines += ["- 스프레드·미끄러짐이 큰 후보는 손실 위험이 커서 안 산 게 맞습니다.", "- 정보가 다 있고 가격반응만 아주 살짝 부족한 후보는 ‘아까운 후보’로 따로 봅니다.", "- 조건 수치는 아직 바꾸지 않았고, 이 판독으로 놓친 후보를 복기합니다."]
    aux_ready = audit.get("aux_ready_top") if isinstance(audit.get("aux_ready_top"), dict) else {}
    aux_missing = audit.get("aux_missing_top") if isinstance(audit.get("aux_missing_top"), dict) else {}
    lines += ["", "[보조정보 완성도 · 조건 아님]"]
    for label in ["RSI/과열 위치", "MACD/추세 전환", "볼린저밴드 위치", "체결 속도 가속도", "호가잔량 변화", "BTC/전체장 선행 방향"]:
        r = int(fnum(aux_ready.get(label), default=0)) if isinstance(aux_ready, dict) else 0
        m = int(fnum(aux_missing.get(label), default=0)) if isinstance(aux_missing, dict) else 0
        icon = "✅" if r > 0 and m == 0 else ("⚠️" if r > 0 else "❔")
        lines.append(f"- {icon} {label}: 수집 {r} / 부족 {m}")
    return "\n".join(lines)

_v409_s1_base = _old_s1_candidates_v408_base if "_old_s1_candidates_v408_base" in globals() else s1_candidates_text

def s1_candidates_text() -> str:  # type: ignore[override]
    audit = _v405_load_audit()
    body = _v409_force_schema_text(_v409_s1_base())
    if "후보 판독 결론" not in body and "최종 판독" not in body:
        body += "\n" + _v409_decision_section(audit)
    else:
        body = _v409_force_schema_text(body.replace("🧭 최종 판독 · 새 등급 아님", "🧭 후보 판독 결론 · 새 등급 아님"))
    body += "\n\n[연결 확인 · v409]\n- ✅ /s1_candidates는 v409 최종 판독판으로 연결됨\n- ✅ S1/S2/S3 구조와 조건 수치는 변경하지 않음"
    return body

_v409_missed_base = _old_missed_trace_v408_base if "_old_missed_trace_v408_base" in globals() else missed_trace_text

def missed_trace_text() -> str:  # type: ignore[override]
    audit = _v405_load_audit()
    body = _v409_force_schema_text(_v409_missed_base())
    decision_top = audit.get("decision_top") if isinstance(audit.get("decision_top"), dict) else {}
    if decision_top and "후보 판독 요약" not in body:
        lines = [body, "", "[후보 판독 요약 · 새 등급 아님]"]
        for name in _DECISION_ORDER:
            if name in decision_top:
                lines.append(f"- {name}: {int(fnum(decision_top.get(name), default=0))}개")
        body = "\n".join(lines)
    return body

_v409_condition_base = _old_condition_map_v408_base if "_old_condition_map_v408_base" in globals() else condition_map_text

def condition_map_text() -> str:  # type: ignore[override]
    body = _v409_force_schema_text(_v409_condition_base())
    if "[v409 운영 기준]" not in body:
        body += "\n\n[v409 운영 기준]\n- S1/S2/S3 구조는 더 쪼개지 않습니다.\n- ‘아까운 후보/재확인 후보/안 산 게 맞음’은 새 등급이 아니라 복기용 해석입니다.\n- RSI, MACD, 볼린저밴드, 체결속도, 호가잔량 변화, BTC/전체장 방향은 조건이 아니라 비교용 정보입니다.\n- 조건 수치 변경은 새 CLOSED/놓친 후보 결과를 본 뒤 한 번에 묶어서만 합니다."
    return body

def batch_handler(update, context):  # type: ignore[override]
    cmds = getattr(context, "args", None) or ["health", "pstatus", "s1_candidates", "missed_trace", "condition_map", "errorlog"]
    cmds = [str(x).strip().lstrip("/") for x in cmds[:10] if str(x).strip()]
    st = time.time(); sent = 0; timings = []
    try:
        send(update, f"📦 자동 묶음 명령 접수\n- 실행 {len(cmds)}개\n- v411: 메인봇 컴파일 오류수정 + S1 후보 판독판 연결")
    except Exception:
        pass
    total = len(cmds)
    for raw in cmds:
        name = raw.strip().lstrip("/")
        fn = COMMANDS.get(name)
        if not fn:
            sent += 1
            body = f"❌ /{name} 명령이 메인봇에 연결되지 않았습니다.\n- 명령 등록 누락입니다.\n- 그냥 건너뛰지 않고 표시합니다."
            timings.append(f"- ❌ /{name}: 미등록")
            send(update, f"[{sent}/{total}] /{name} (미등록)\n{body}")
            continue
        t = time.time()
        try:
            body = fn(); ok = "OK"
        except Exception as exc:
            body = f"❌ /{name} 오류 {exc.__class__.__name__}: {exc}"; ok = "ERR"; log_error(f"batch_{name}", exc)
        sec = time.time() - t; sent += 1
        timings.append(f"- {'✅' if ok=='OK' else '❌'} /{name}: {sec:.2f}s / {ok}")
        send(update, f"[{sent}/{total}] /{name} ({sec:.2f}s / {ok})\n{body}")
    send(update, "🧾 자동 묶음 시간표 · v411 명령별 전송\n" + "\n".join(timings) + f"\n- 합계 {time.time()-st:.2f}s")

try:
    COMMANDS.update({
        "health": health_text, "core": health_text, "pstatus": pstatus_text, "score": score_text, "pscore": score_text,
        "s1_review": s1_review_text, "s1review": s1_review_text, "s1_candidates": s1_candidates_text, "s1": s1_candidates_text,
        "missed_trace": missed_trace_text, "trace_missed": missed_trace_text, "condition_map": condition_map_text, "conditions": condition_map_text, "errorlog": errorlog_text,
    })
except Exception:
    pass


# =============================================================================
# v411: main compile-fix bundle marker
# - v409에서 strategy_worker만 v0.34로 바뀌고 main process가 v408로 남는 적용 불일치를 방지하기 위해
#   main 파일명/버전/RESTORE_BUILD를 v411로 컴파일 오류 수정시킨다.
# - 조건 수치/청산/paper/장부는 변경하지 않는다.
# =============================================================================
BOT_VERSION = "수익형 v2.13.389"
RESTORE_BUILD = "v425_v389_disable_main_auto_retention_2026-05-25"

try:
    _old_health_text_v410 = health_text
    def health_text() -> str:  # type: ignore[override]
        body = _old_health_text_v410()
        body = body.replace("수익형 v2.13.376", "수익형 v2.13.379")
        body = body.replace("수익형 v2.13.377", "수익형 v2.13.379")
        body = body.replace("v408_v376_s1_decision_aux_complete_2026-05-24", RESTORE_BUILD)
        body = body.replace("v409_v377_s1_decision_route_fix_2026-05-24", RESTORE_BUILD)
        return body
except Exception:
    pass

try:
    COMMANDS.update({
        "health": health_text, "core": health_text,
        "s1_candidates": s1_candidates_text, "s1": s1_candidates_text,
        "missed_trace": missed_trace_text, "trace_missed": missed_trace_text,
        "condition_map": condition_map_text, "conditions": condition_map_text,
        "pstatus": pstatus_text, "score": score_text, "pscore": score_text, "errorlog": errorlog_text,
    })
except Exception:
    pass



# =============================================================================
# v413/v414 obsolete direct-ledger status blocks removed in v416.
# - latest active status uses v415/v416 fast cache/tail path below.

# v415: 기본 명령 캐시 전용화 + 활성 장부 다이어트 도구
# - /pstatus에서 CLOSED 장부 통계를 제거해 기본 상태판을 즉시 응답하게 한다.
# - /version_score는 최근 적용판 3개만 tail로 확인한다.
# - /data_prune 명령으로 오래된 CLOSED 장부를 압축보관하고 활성 장부는 최근분만 남긴다.
# - 전략 조건/S1/S2/S3/paper 실행/청산 조건은 변경하지 않는다.
# =============================================================================
BOT_VERSION = "수익형 v2.13.389"
RESTORE_BUILD = "v425_v389_disable_main_auto_retention_2026-05-25"

# 큰 JSONL 파일은 기본 명령에서 절대 전체를 읽지 않는다.
def read_jsonl(path: Path, max_lines: int = 1000) -> List[Dict[str, Any]]:  # type: ignore[override]
    if not path.exists():
        return []
    try:
        max_lines = max(1, min(int(max_lines or 1000), 1500))
    except Exception:
        max_lines = 1000
    try:
        size = path.stat().st_size
        # 기본 명령은 512KB까지만 읽는다. 후보/성과 요약에는 충분하고, 오래된 장부가 커져도 명령을 막지 않는다.
        tail_bytes = min(size, max(96_000, min(512_000, max_lines * 2048)))
        with path.open('rb') as f:
            if size > tail_bytes:
                f.seek(-tail_bytes, os.SEEK_END)
                f.readline()
            data = f.read().decode('utf-8', errors='ignore')
        lines = data.splitlines()[-max_lines:]
        out: List[Dict[str, Any]] = []
        for ln in lines:
            if not ln.strip():
                continue
            try:
                obj = json.loads(ln)
                if isinstance(obj, dict):
                    out.append(obj)
            except Exception:
                continue
        return out
    except Exception:
        return []


def _v415_active_closed_rows(max_lines: int = 800) -> List[Dict[str, Any]]:
    return [r for r in read_jsonl(FILES.get('paper_closed', BASE_DIR / 'paper_bot_closed.jsonl'), max_lines=max_lines) if isinstance(r, dict)]


def _v415_stat(rows: List[Dict[str, Any]]) -> Dict[str, Any]:
    n = len(rows)
    wins = 0; total = 0.0
    for r in rows:
        pnl = fnum(r.get('pnl_pct', r.get('profit_pct', r.get('ret_pct', 0))))
        total += pnl
        if pnl > 0:
            wins += 1
    losses = max(0, n - wins)
    return {'n': n, 'wins': wins, 'losses': losses, 'total': total, 'avg': (total / n if n else 0.0), 'wr': (wins / n * 100 if n else 0.0)}


def _v415_score_line(label: str, rows: List[Dict[str, Any]]) -> str:
    st = _v415_stat(rows)
    icon = '✅' if st['total'] > 0 else ('❌' if st['n'] and st['total'] < 0 else '❔')
    if st['n'] == 0:
        return f"- ❔ {label}: 0전 0승 0패 / 아직 이 적용판으로 닫힌 거래 없음"
    return f"- {icon} {label}: {st['n']}전 {st['wins']}승 {st['losses']}패 / 승률 {st['wr']:.1f}% / 합산 {st['total']:+.2f}% / 평균 {st['avg']:+.2f}%"


def _v415_main_version_of(row: Dict[str, Any]) -> str:
    for k in ('main_version', 'deploy_version', 'bot_version', 'version'):
        v = row.get(k)
        if not v:
            continue
        text = str(v)
        m = re.search(r'v?2\.13\.(\d+)', text)
        if m:
            return f"v2.13.{m.group(1)}"
    return ''


_V415_RECENT_VERSIONS = ['v2.13.386', 'v2.13.385', 'v2.13.381']


def version_score_text() -> str:  # type: ignore[override]
    rows = _v415_active_closed_rows(1000)
    by_ver: Dict[str, List[Dict[str, Any]]] = {v: [] for v in _V415_RECENT_VERSIONS}
    old_rows: List[Dict[str, Any]] = []
    for r in rows:
        ver = _v415_main_version_of(r)
        if ver in by_ver:
            by_ver[ver].append(r)
        elif ver:
            old_rows.append(r)
    lines = [
        '📊 최근 3개 적용판 성과 /version_score',
        '- 목적: 예전 손실과 현재 조건판을 섞지 않고 봅니다.',
        '- 기준: 현재 적용판 / 직전판 / 그전판만 고정 표시합니다.',
        '- 큰 장부 전체를 읽지 않고 활성 장부 끝부분만 봅니다.',
        '',
        '[최근 3개 적용판]',
        _v415_score_line('현재 적용판 · v2.13.386', by_ver.get('v2.13.386', [])),
        _v415_score_line('직전판 · v2.13.385', by_ver.get('v2.13.385', [])),
        _v415_score_line('그전판 · v2.13.381', by_ver.get('v2.13.381', [])),
    ]
    cur = by_ver.get('v2.13.386', [])
    lines += ['', '[현재 적용판 전략별 · v2.13.386]']
    if cur:
        groups: Dict[str, List[Dict[str, Any]]] = {}
        for r in cur:
            strat = str(r.get('primary_strategy_kr') or r.get('primary_strategy') or r.get('strategy_name_kr') or r.get('strategy') or '전략 미기록')
            groups.setdefault(strat, []).append(r)
        for name, rs in sorted(groups.items(), key=lambda kv: len(kv[1]), reverse=True)[:8]:
            lines.append(_v415_score_line(name, rs))
    else:
        lines.append('- 아직 현재 적용판 CLOSED 없음')
    if old_rows:
        sample = old_rows[-3:]
        lines += ['', '[과거 참고 · 최근 3개 판단에서 제외]']
        for ver in sorted({_v415_main_version_of(r) for r in sample if _v415_main_version_of(r)}, reverse=True)[:3]:
            rs = [r for r in rows if _v415_main_version_of(r) == ver]
            lines.append(_v415_score_line(f'과거판 · {ver}', rs))
    lines += [
        '',
        '[판독]',
        '- 현재 적용판이 0전이면 “아직 새 기준으로 닫힌 거래가 없음”입니다.',
        '- 오래된 누적 장부는 기본 판단에서 제외합니다.',
        '- 오래된 장부가 계속 느리게 만들면 /data_prune 으로 압축보관 후 활성 장부를 줄입니다.',
    ]
    return '\n'.join(lines)


def pstatus_text() -> str:  # type: ignore[override]
    status = load_json(FILES.get('paper_status', BASE_DIR / 'paper_bot_status.json'), {}) or {}
    hand = load_json(FILES.get('paperbot_handoff', BASE_DIR / 'paper_bot_candidate_handoff_status.json'), {}) or {}
    trace = load_json(FILES.get('candidate_handoff_trace', BASE_DIR / 'paper_bot_candidate_handoff_trace.json'), {}) or {}
    open_obj = load_json(FILES.get('paper_open', BASE_DIR / 'paper_bot_open.json'), {}) or {}
    if isinstance(open_obj, dict):
        positions = open_obj.get('positions') or open_obj.get('open_positions') or open_obj.get('items') or []
    elif isinstance(open_obj, list):
        positions = open_obj
    else:
        positions = []
    if not isinstance(positions, list):
        positions = []
    versions = _v401_paper_versions() if '_v401_paper_versions' in globals() else {}
    life_lines = _v401_lifecycle_lines() if '_v401_lifecycle_lines' in globals() else []
    latest = hand.get('latest_count', hand.get('latest', '-'))
    fresh = hand.get('merged_fresh', hand.get('fresh', '-'))
    selected = hand.get('selected_s1', hand.get('s1_selected', 0))
    micro_wait = hand.get('micro_preopen_wait', hand.get('micro_wait', 0))
    opened = status.get('opened_this_cycle', status.get('open_this_cycle', 0))
    closed = status.get('closed_this_cycle', 0)
    closed_total = status.get('closed_total', status.get('closed_count', status.get('closed_cum', '-')))
    elapsed = status.get('elapsed_sec', status.get('cycle_sec', '-'))
    s1 = sum(1 for p in positions if str((p or {}).get('stage','S1')).upper() == 'S1')
    s2 = sum(1 for p in positions if str((p or {}).get('stage','')).upper() == 'S2')
    s3 = sum(1 for p in positions if str((p or {}).get('stage','')).upper() == 'S3')
    excluded = max(0, len(positions) - s1 - s2 - s3)
    lines = [
        '🧪 paper 상태 /pstatus · 빠른 상태판',
        f"- 상태: {'ON' if status.get('running', True) else '확인필요'} / paper {versions.get('paper_version', status.get('version','-'))} / trace {versions.get('trace_version', trace.get('paper_version','-'))} / status age {versions.get('paper_age', age(FILES.get('paper_status', BASE_DIR/'paper_bot_status.json'))):.1f}s / trace age {versions.get('trace_age', age(FILES.get('candidate_handoff_trace', BASE_DIR/'paper_bot_candidate_handoff_trace.json'))):.1f}s / OPEN {len(positions)} / CLOSED누적 {closed_total}",
        f"- OPEN: S1 {s1} / S2 {s2} / S3 {s3} / 제외 {excluded}",
        f"- 이번 cycle: OPEN {opened} / CLOSED {closed} / elapsed {elapsed}s",
        f"- 후보선별: latest {latest} / fresh {fresh} / S1 실제진입 선택 {selected} / 호가·체결 대기 {micro_wait} / 이번 진입 {opened}",
        '- S2/S3는 실제 진입 전 단계라 승패로 표시하지 않습니다.',
    ]
    if life_lines:
        lines += life_lines
    lines += [
        '',
        '[성과 안내]',
        '- 이 화면은 빠른 상태판이라 오래된 CLOSED 장부를 읽지 않습니다.',
        '- 현재 적용판 성과는 /version_score 에서 봅니다.',
        '- 오래된 6000개 장부는 /data_prune 으로 압축보관하고 활성 장부를 줄일 수 있습니다.',
    ]
    return '\n'.join(lines)


def _v415_archive_and_trim_jsonl(path: Path, keep_lines: int = 800) -> Dict[str, Any]:
    info = {'ok': False, 'path': str(path), 'before': 0, 'after': 0, 'archived': 0, 'archive': ''}
    if not path.exists():
        info['ok'] = True
        return info
    raw = path.read_bytes()
    lines = [ln for ln in raw.splitlines() if ln.strip()]
    info['before'] = len(lines)
    keep_lines = max(100, int(keep_lines or 800))
    if len(lines) <= keep_lines:
        info['ok'] = True; info['after'] = len(lines)
        return info
    old = lines[:-keep_lines]
    new = lines[-keep_lines:]
    arch_dir = BASE_DIR / 'archive'
    arch_dir.mkdir(parents=True, exist_ok=True)
    stamp = time.strftime('%Y%m%d_%H%M%S')
    arch = arch_dir / f'{path.stem}_legacy_before_v415_{stamp}.jsonl.gz'
    import gzip
    with gzip.open(arch, 'wb') as gz:
        gz.write(b'\n'.join(old) + b'\n')
    tmp = path.with_suffix(path.suffix + '.tmp')
    tmp.write_bytes(b'\n'.join(new) + b'\n')
    os.replace(tmp, path)
    info.update({'ok': True, 'after': len(new), 'archived': len(old), 'archive': str(arch.name)})
    return info


def data_prune_text() -> str:
    """오래된 active JSONL 장부를 압축보관하고 현재 파일은 최근분만 남긴다.

    자동 삭제가 아니라 명령 실행 시에만 수행한다. paper 장부를 완전 삭제하지 않고 archive/*.gz로 남긴다.
    """
    targets = [
        (FILES.get('paper_closed', BASE_DIR/'paper_bot_closed.jsonl'), 500, 'paper CLOSED 장부'),
        (BASE_DIR/'paper_bot_trade_log.jsonl', 500, 'paper 거래 로그'),
        (FILES.get('paper_archive', BASE_DIR/'paper_candidates.jsonl'), 800, '후보 archive'),
        (BASE_DIR/'paper_candidates_handoff_merged.jsonl', 600, 'paper 병합 후보'),
        (BASE_DIR/'candidate_events.jsonl', 1000, '후보 이벤트'),
    ]
    lines = ['🧹 오래된 자료 정리 /data_prune', '- 오래된 자료는 삭제가 아니라 압축보관합니다.', '- 활성 파일은 최근분만 남겨 기본 명령이 가볍게 읽도록 합니다.', '- OPEN 장부는 건드리지 않고, 오래된 CLOSED/후보/이벤트성 파일만 압축합니다.', '']
    for path, keep, label in targets:
        try:
            res = _v415_archive_and_trim_jsonl(path, keep)
            if res.get('before', 0) <= keep:
                lines.append(f"- ✅ {label}: 정리 불필요 / {res.get('before',0)}줄")
            else:
                lines.append(f"- ✅ {label}: {res.get('before')}줄 → {res.get('after')}줄 / 압축보관 {res.get('archived')}줄 / {res.get('archive')}")
        except Exception as exc:
            log_error('data_prune', exc)
            lines.append(f"- ❌ {label}: 정리 실패 {exc.__class__.__name__}: {exc}")
    lines += ['', '[주의]', '- OPEN 장부는 건드리지 않습니다.', '- 전략 조건, 청산 조건, 자동매수는 변경하지 않습니다.', '- 정리 후 /health /pstatus /version_score 로 속도를 확인하세요.']
    return '\n'.join(lines)


def batch_handler(update, context):  # type: ignore[override]
    cmds = getattr(context, 'args', None) or ['health', 'pstatus', 'version_score', 's1_candidates', 'missed_trace', 'errorlog']
    cmds = [str(x).strip().lstrip('/') for x in cmds[:10] if str(x).strip()]
    st = time.time(); sent = 0; timings = []
    try:
        send(update, f"📦 자동 묶음 명령 접수\n- 실행 {len(cmds)}개\n- v419: 버전·worker 연결 정합성 수정 · paper 최종 안전문 + 기본 명령 경량화 + 장부 정리")
    except Exception:
        pass
    total = len(cmds)
    for raw in cmds:
        name = raw.strip().lstrip('/')
        fn = COMMANDS.get(name)
        if not fn:
            sent += 1
            body = f"❌ /{name} 명령이 메인봇에 연결되지 않았습니다."
            timings.append(f"- ❌ /{name}: 미등록")
            send(update, f"[{sent}/{total}] /{name} (미등록)\n{body}")
            continue
        t = time.time()
        try:
            body = fn(); ok = 'OK'
        except Exception as exc:
            body = f"❌ /{name} 오류 {exc.__class__.__name__}: {exc}"; ok = 'ERR'; log_error(f'batch_{name}', exc)
        sec = time.time() - t; sent += 1
        timings.append(f"- {'✅' if ok=='OK' else '❌'} /{name}: {sec:.2f}s / {ok}")
        send(update, f"[{sent}/{total}] /{name} ({sec:.2f}s / {ok})\n{body}")
    send(update, "🧾 자동 묶음 시간표 · v419 명령별 전송\n" + "\n".join(timings) + f"\n- 합계 {time.time()-st:.2f}s")

try:
    COMMANDS.update({
        'health': health_text, 'core': health_text,
        'pstatus': pstatus_text,
        'score': score_text, 'pscore': score_text,
        'version_score': version_score_text, 'vscore': version_score_text,
        's1_candidates': s1_candidates_text, 's1': s1_candidates_text,
        'missed_trace': missed_trace_text, 'trace_missed': missed_trace_text,
        'condition_map': condition_map_text, 'conditions': condition_map_text,
        'data_prune': data_prune_text, 'cleanup_data': data_prune_text,
        'errorlog': errorlog_text,
    })
except Exception:
    pass



# =============================================================================
# v421: paper 성과 반영 경로 기본 명령 수술
# - /score, /pscore, /version_score 기본 명령에서 CLOSED 전체 장부 직접조회 경로를 끊는다.
# - paper_bot score cache / status / trace 상태만 읽고, 캐시가 없으면 준비중·오래됨으로 표시한다.
# - /batch 기본 묶음에서 무거운 /score, /condition_map, /s1_review를 제외한다.
# - 전략 조건, S1/S2/S3 기준, 청산조건, 자동매수, paper 장부 원본은 변경하지 않는다.
# =============================================================================
BOT_VERSION = "수익형 v2.13.389"
RESTORE_BUILD = "v425_v389_disable_main_auto_retention_2026-05-25"
_CURRENT_MAIN_VER = "v2.13.386"
_V421_RECENT_VERSIONS = ["v2.13.387", "v2.13.386", "v2.13.385"]


def _v421_read_small(path: Path, default: Any = None, max_bytes: int = 900_000) -> Any:
    try:
        if not path.exists():
            return default
        if path.stat().st_size > max_bytes:
            return {"_too_large": True, "_size": path.stat().st_size}
        return json.loads(path.read_text(encoding="utf-8", errors="ignore"))
    except Exception:
        return default


def _v421_int(v: Any, default: int = 0) -> int:
    try:
        return int(float(str(v).replace(',', '')))
    except Exception:
        return default


def _v421_stat_from_any(obj: Any) -> Dict[str, Any]:
    if not isinstance(obj, dict):
        return {'n': 0, 'wins': 0, 'losses': 0, 'win_rate': 0.0, 'total': 0.0, 'avg': 0.0}
    n = _v421_int(obj.get('n', obj.get('count', obj.get('closed', obj.get('trades', 0)))))
    wins = _v421_int(obj.get('wins', obj.get('win', 0)))
    losses = _v421_int(obj.get('losses', obj.get('loss', max(0, n-wins))))
    total = fnum(obj.get('total'), obj.get('total_pct'), obj.get('profit_sum'), obj.get('pnl_sum'), default=0.0)
    avg = fnum(obj.get('avg'), obj.get('avg_pct'), obj.get('mean'), default=(total/n if n else 0.0))
    wr = fnum(obj.get('win_rate'), obj.get('win_rate_pct'), default=(wins/n*100.0 if n else 0.0))
    return {'n': n, 'wins': wins, 'losses': losses, 'win_rate': wr, 'total': total, 'avg': avg}


def _v421_stat_line(label: str, obj: Any) -> str:
    return _score_stat_line(label, _v421_stat_from_any(obj))


def _v421_cache() -> Dict[str, Any]:
    c = _v421_read_small(FILES.get('paper_score', BASE_DIR/'paper_bot_score_cache.json'), {}) or {}
    return c if isinstance(c, dict) else {}


def _v421_status() -> Dict[str, Any]:
    s = _v421_read_small(FILES.get('paper_status', BASE_DIR/'paper_bot_status.json'), {}) or {}
    return s if isinstance(s, dict) else {}


def _v421_trace() -> Dict[str, Any]:
    t = _v421_read_small(FILES.get('candidate_handoff_trace', BASE_DIR/'paper_bot_candidate_handoff_trace.json'), {}) or {}
    return t if isinstance(t, dict) else {}


def _v421_strategy_stat_map(cache: Dict[str, Any]) -> Dict[str, Any]:
    out: Dict[str, Any] = {}
    for key in ('strategy_primary_stats', 'strategy_s_stats', 'strategy_stats', 'by_strategy'):
        v = cache.get(key)
        if isinstance(v, list):
            for item in v:
                if isinstance(item, dict):
                    k = str(item.get('key') or item.get('strategy_key') or item.get('label') or item.get('name') or '')
                    if k:
                        out[k] = item
        elif isinstance(v, dict):
            for k, item in v.items():
                out[str(k)] = item
    return out


def _v421_grade_stat(cache: Dict[str, Any], key: str) -> Dict[str, Any]:
    for container_key in ('grade_stats', 'by_grade', 'stage_stats'):
        obj = cache.get(container_key)
        if isinstance(obj, dict):
            val = obj.get(key) or obj.get(key.upper()) or obj.get(key.lower())
            if isinstance(val, dict):
                return val
    if key == 'ALL':
        for k in ('global_stats', 'all_stats', 'summary', 'total_stats'):
            val = cache.get(k)
            if isinstance(val, dict):
                return val
    return {}


def score_text() -> str:  # type: ignore[override]
    cache = _v421_cache()
    status = _v421_status()
    trace = _v421_trace()
    cache_age = age(FILES.get('paper_score', BASE_DIR/'paper_bot_score_cache.json'))
    status_age = age(FILES.get('paper_status', BASE_DIR/'paper_bot_status.json'))
    trace_age = age(FILES.get('candidate_handoff_trace', BASE_DIR/'paper_bot_candidate_handoff_trace.json'))
    status_closed = _v421_int(status.get('closed_total', status.get('closed_count', status.get('closed_cum', 0))))
    status_open = _v421_int(status.get('open_count', status.get('open_total', 0)))
    cache_closed = _v421_int(cache.get('current_closed_count', cache.get('closed_count', cache.get('n', 0)))) if cache else 0
    cache_ver = str(cache.get('version') or cache.get('paper_version') or '-') if cache else '-'
    cache_schema = str(cache.get('schema') or '-') if cache else '-'
    lines = [
        '📊 S1/S2/S3 스코어 /score',
        '- 기준: paper_bot score cache + paper status만 읽습니다. 기본 /score에서 CLOSED 전체 장부 직접조회는 차단했습니다.',
        f"- paper status: CLOSED누적 {status_closed} / OPEN {status_open} / age {status_age:.1f}s / version {status.get('version','-')}",
        f"- score cache: CLOSED {cache_closed} / age {cache_age:.1f}s / {cache_ver} / {cache_schema}",
        f"- trace: age {trace_age:.1f}s / version {trace.get('version', trace.get('trace_version','-')) if isinstance(trace,dict) else '-'}",
    ]
    if status_closed > 0 and cache_closed == 0:
        lines.append('- ⚠️ 핵심불일치: paper CLOSED 누적은 있는데 score cache 현재판 성과가 0입니다. 성과판 원천 반영 경로 확인 필요.')
    elif cache_age > 300:
        lines.append('- ⚠️ score cache 오래됨: 최신 CLOSED가 성과판에 늦게 반영될 수 있습니다.')
    else:
        lines.append('- ✅ 기본 성과판은 캐시 원천만 사용 중입니다.')
    lines += ['', '[등급별 성과 · cache 기준]']
    # support both old S and new S1/S2/S3 naming without direct ledger fallback
    for key, label in [('S1','✅ S1 즉시진입'), ('S2','⚠️ S2 재확인'), ('S3','❔ S3 관찰복기'), ('S','S 전체'), ('ALL','현재판 전체')]:
        stat = _v421_grade_stat(cache, key)
        if key in {'S', 'ALL'} or stat:
            lines.append(_v421_stat_line(label, stat))
    label_map={'money_reaccel_s':'돈흐름 재가속','leader_momentum_s':'주도추세 지속','breakout_early_s':'돌파 초입','sweep_vwap_recovery_s':'저점 VWAP 회복','surge_rebreak_s':'급등 후 재돌파','leader_flow_adaptive_hold_s':'주도흐름 유동보유'}
    smap = _v421_strategy_stat_map(cache)
    lines += ['', '[대표전략 기준 · cache 기준]']
    if smap:
        for key, label in label_map.items():
            lines.append(_v421_stat_line(label, smap.get(key, {})))
        extra = [k for k in smap.keys() if k not in label_map][:3]
        for k in extra:
            lines.append(_v421_stat_line(str(k), smap.get(k, {})))
    else:
        lines.append('- 아직 대표전략 cache 없음')
    strat = _v421_read_small(FILES.get('strategy_summary', BASE_DIR/'clean_strategy_s_summary.json'), {}) or {}
    pbh = _v421_read_small(FILES.get('paperbot_handoff', BASE_DIR/'paper_bot_candidate_handoff_status.json'), {}) or {}
    router = _v421_read_small(FILES.get('target_router', BASE_DIR/'clean_target_router_queue.json'), {}) or {}
    sc = _v398_stage_counts_from_latest_fast() if '_v398_stage_counts_from_latest_fast' in globals() else {}
    lines += ['', '[현재 후보/정보 흐름]']
    if isinstance(strat, dict):
        lines.append(f"- 현재 S1 {sc.get('S1',0)} / S2 {sc.get('S2',0)} / S3 {sc.get('S3',0)} / latest {strat.get('paper_latest_count','-')} / paper 병합 {pbh.get('merged_fresh','-') if isinstance(pbh,dict) else '-'} / archive {pbh.get('archive_window','-') if isinstance(pbh,dict) else '-'}")
        lines.append(f"- 정보: 전체 {strat.get('evaluated','-')}개 / 시세 {strat.get('quote_ready_count','-')} / micro {strat.get('micro_ready_count','-')} / 둘다 {strat.get('full_info_ready_count','-')}")
    if isinstance(router, dict):
        lines.append(f"- 배차: 전체 {router.get('queue_count','-')} / 내보냄 {router.get('export_count', router.get('active_target_count','-'))} / 대기 {router.get('rotation_wait_count','-')} / 버림 {router.get('dropped_count',0)}")
    lines += ['', '[판독]', '- 이 화면이 0전인데 paper CLOSED 누적이 있으면 조건 문제가 아니라 성과 cache/trace 반영 경로 문제입니다.', '- 전체 장부 재계산은 기본 명령에서 하지 않습니다.']
    return '\n'.join(lines)


def pscore_text() -> str:  # type: ignore[override]
    return score_text().replace('📊 S1/S2/S3 스코어 /score', '📊 paper 스코어 /pscore · cache 전용', 1)


def version_score_text() -> str:  # type: ignore[override]
    cache = _v421_cache()
    status = _v421_status()
    cache_age = age(FILES.get('paper_score', BASE_DIR/'paper_bot_score_cache.json'))
    lines = [
        '📊 버전별 성과 /version_score',
        '- 기준: score cache/status만 읽습니다. 기본 /version_score에서 CLOSED 전체 장부 직접조회는 차단했습니다.',
        f"- 메인봇: {BOT_VERSION} / build {RESTORE_BUILD}",
        f"- paper: {status.get('version','-')} / status age {age(FILES.get('paper_status', BASE_DIR/'paper_bot_status.json')):.1f}s / CLOSED누적 {status.get('closed_total', status.get('closed_count','-'))}",
        f"- cache age {cache_age:.1f}s / schema {cache.get('schema','-') if isinstance(cache,dict) else '-'}",
        '',
        '[최근 적용판 요약 · cache 기준]'
    ]
    version_stats = None
    for k in ('version_stats', 'by_version', 'main_version_stats'):
        if isinstance(cache.get(k), dict):
            version_stats = cache.get(k); break
        if isinstance(cache.get(k), list):
            version_stats = {str(x.get('key') or x.get('version') or x.get('label')): x for x in cache.get(k) if isinstance(x,dict)}; break
    if isinstance(version_stats, dict) and version_stats:
        for ver in _V421_RECENT_VERSIONS:
            lines.append(_v421_stat_line(ver, version_stats.get(ver, {})))
    else:
        lines.append('- 아직 버전별 cache 없음')
        for ver in _V421_RECENT_VERSIONS:
            lines.append(f'- ❔ {ver}: cache 준비중 / 직접 장부조회 안 함')
    lines += ['', '[판독]', '- KeyError가 나던 구버전 키 직접참조를 끊었습니다.', '- paper CLOSED가 있는데 cache가 비면 paper_bot 성과 cache 생성/저장 경로를 다음에 봐야 합니다.']
    return '\n'.join(lines)


def batch_handler(update, context):  # type: ignore[override]
    # 기본 묶음은 전부 빠른 경로만 사용한다. 사용자가 /score를 직접 넣어도 v421 score_text는 cache 전용이다.
    cmds = getattr(context, 'args', None) or ['health', 'version_score', 'pstatus', 'popen', 's1_candidates', 'missed_trace', 'errorlog']
    cmds = [str(x).strip().lstrip('/') for x in cmds[:10] if str(x).strip()]
    st = time.time(); sent = 0; timings = []
    try:
        send(update, f"📦 자동 묶음 명령 접수\n- 실행 {len(cmds)}개\n- v421: score/version_score 장부직접조회 차단 + paper 성과원천 확인")
    except Exception:
        pass
    total = len(cmds)
    for raw in cmds:
        name = raw.strip().lstrip('/')
        fn = COMMANDS.get(name)
        if not fn:
            sent += 1
            body = f"❌ /{name} 명령이 메인봇에 연결되지 않았습니다."
            timings.append(f"- ❌ /{name}: 미등록")
            send(update, f"[{sent}/{total}] /{name} (미등록)\n{body}")
            continue
        t = time.time()
        try:
            body = fn(); ok = 'OK'
        except Exception as exc:
            body = f"❌ /{name} 오류 {exc.__class__.__name__}: {exc}"; ok = 'ERR'; log_error(f'batch_{name}', exc)
        sec = time.time() - t; sent += 1
        timings.append(f"- {'✅' if ok=='OK' else '❌'} /{name}: {sec:.2f}s / {ok}")
        send(update, f"[{sent}/{total}] /{name} ({sec:.2f}s / {ok})\n{body}")
    send(update, "🧾 자동 묶음 시간표 · v421 명령별 전송\n" + "\n".join(timings) + f"\n- 합계 {time.time()-st:.2f}s")


def set_commands(updater):  # type: ignore[override]
    try:
        updater.bot.set_my_commands([
            BotCommand('health','전체 상태'),
            BotCommand('version_score','버전별/진입유형 성과'),
            BotCommand('pstatus','paper 상태'),
            BotCommand('popen','모의매매 진행중'),
            BotCommand('s1_candidates','S1 후보 점검'),
            BotCommand('missed_trace','후보 추적'),
            BotCommand('score','성과표'),
            BotCommand('errorlog','오류로그'),
            BotCommand('batch','묶음 확인'),
        ])
    except Exception as exc:
        log_error('set_commands', exc)

try:
    COMMANDS.update({
        'health': health_text, 'core': health_text,
        'pstatus': pstatus_text,
        'popen': popen_text,
        'score': score_text, 'pscore': pscore_text,
        'candidate_reason': candidate_reason_text, 'reason': candidate_reason_text, 'why_s1': candidate_reason_text,
        'version_score': version_score_text, 'vscore': version_score_text,
        's1_candidates': s1_candidates_text, 's1': s1_candidates_text,
        'missed_trace': missed_trace_text, 'trace_missed': missed_trace_text,
        'condition_map': condition_map_text, 'conditions': condition_map_text,
        'data_prune': data_prune_text, 'cleanup_data': data_prune_text,
        'errorlog': errorlog_text, 'perror': errorlog_text,
    })
except Exception:
    pass




# =============================================================================
# v427: 메인봇 명령 캐시 단일 본선
# - 메인봇은 자동정리/압축/삭제 작업을 하지 않는다. 정리는 가드봇 담당.
# - /health, /pstatus, /score, /version_score는 작은 JSON cache/status만 읽는다.
# - 기본 /batch에 /score, /pstatus, /quality 같은 느린 명령을 넣지 않는다.
# - 전략조건, S1/S2/S3 기준, 청산조건, 자동매수, BUY_READY는 변경하지 않는다.
# =============================================================================
BOT_VERSION = "수익형 v2.13.397"
RESTORE_BUILD = "v439_v397_review_close_basis_2026-05-25"
_CURRENT_MAIN_VER = "v2.13.397"
_V421_RECENT_VERSIONS = ["v2.13.397", "v2.13.396", "v2.13.395"]


def _v427_read_small(path: Path, default: Any = None, max_bytes: int = 900_000) -> Any:
    try:
        if not path.exists():
            return default
        if path.stat().st_size > max_bytes:
            return {"_too_large": True, "_size": path.stat().st_size, "_path": path.name}
        return json.loads(path.read_text(encoding="utf-8", errors="ignore"))
    except Exception:
        return default


def _v427_int(v: Any, default: int = 0) -> int:
    try:
        return int(float(str(v).replace(',', '')))
    except Exception:
        return default


def _v427_stat(obj: Any) -> Dict[str, Any]:
    if not isinstance(obj, dict):
        return {"n": 0, "wins": 0, "losses": 0, "win_rate": 0.0, "total": 0.0, "avg": 0.0}
    n = _v427_int(obj.get("n", obj.get("count", obj.get("closed", obj.get("trades", 0)))))
    wins = _v427_int(obj.get("wins", obj.get("win", 0)))
    losses = _v427_int(obj.get("losses", obj.get("loss", max(0, n - wins))))
    total = fnum(obj.get("total"), obj.get("total_pct"), obj.get("profit_sum"), obj.get("pnl_sum"), default=0.0)
    avg = fnum(obj.get("avg"), obj.get("avg_pct"), obj.get("mean"), default=(total / n if n else 0.0))
    wr = fnum(obj.get("win_rate"), obj.get("win_rate_pct"), default=(wins / n * 100.0 if n else 0.0))
    return {"n": n, "wins": wins, "losses": losses, "win_rate": wr, "total": total, "avg": avg}


def _v427_stat_line(label: str, obj: Any) -> str:
    st = _v427_stat(obj)
    return f"- {label}: {st['n']}전 {st['wins']}승 {st['losses']}패 / 승률 {st['win_rate']:.1f}% / 합산 {st['total']:+.2f}% / 평균 {st['avg']:+.2f}%"


def _v427_cache() -> Dict[str, Any]:
    obj = _v427_read_small(FILES.get('paper_score', BASE_DIR / 'paper_bot_score_cache.json'), {}) or {}
    return obj if isinstance(obj, dict) else {}


def _v427_status() -> Dict[str, Any]:
    obj = _v427_read_small(FILES.get('paper_status', BASE_DIR / 'paper_bot_status.json'), {}) or {}
    return obj if isinstance(obj, dict) else {}


def _v427_trace() -> Dict[str, Any]:
    obj = _v427_read_small(FILES.get('candidate_handoff_trace', BASE_DIR / 'paper_bot_candidate_handoff_trace.json'), {}) or {}
    return obj if isinstance(obj, dict) else {}


def _v427_strategy_summary() -> Dict[str, Any]:
    obj = _v427_read_small(FILES.get('strategy_summary', BASE_DIR / 'clean_strategy_s_summary.json'), {}) or {}
    return obj if isinstance(obj, dict) else {}


def _v427_router() -> Dict[str, Any]:
    obj = _v427_read_small(FILES.get('target_router', BASE_DIR / 'clean_target_router_queue.json'), {}) or {}
    return obj if isinstance(obj, dict) else {}


def _v427_worker_line(name: str) -> str:
    try:
        spec = WORKERS.get(name, {})
        path = BASE_DIR / str(spec.get('status', ''))
        obj = _v427_read_small(path, {}) or {}
        a = age(path)
        ver = obj.get('version', '-') if isinstance(obj, dict) else '-'
        state = obj.get('state', '-') if isinstance(obj, dict) else '-'
        err = obj.get('err') or obj.get('last_error') or '-' if isinstance(obj, dict) else '-'
        icon = '✅' if a < 45 and str(err) in {'-', '', 'None'} else ('⚠️' if a < 180 else '❌')
        extra = ''
        if name == 'strategy' and isinstance(obj, dict):
            extra = f" / eval {obj.get('evaluated','-')} / target {obj.get('target_count','-')}"
        return f"- {icon} {name}: {ver} / {state} / age {a:.1f}s{extra} / err {err}"
    except Exception as exc:
        return f"- ❌ {name}: 상태 읽기 실패 {exc.__class__.__name__}"


def _v427_open_positions() -> List[Dict[str, Any]]:
    obj = _v427_read_small(FILES.get('paper_open', BASE_DIR / 'paper_bot_open.json'), {}) or {}
    vals: Any = []
    if isinstance(obj, dict):
        vals = obj.get('positions') or obj.get('open_positions') or obj.get('items') or obj
        if isinstance(vals, dict):
            vals = list(vals.values())
    elif isinstance(obj, list):
        vals = obj
    return [x for x in vals if isinstance(x, dict)] if isinstance(vals, list) else []



def _v436_list_top(items: Any, limit: int = 3) -> str:
    rows: List[str] = []
    if isinstance(items, dict):
        pairs = [{"reason": str(k), "count": v} for k, v in items.items()]
    elif isinstance(items, list):
        pairs = [x for x in items if isinstance(x, dict)]
    else:
        pairs = []
    def _cnt(x: Dict[str, Any]) -> int:
        try:
            return int(float(x.get('count', x.get('n', 0))))
        except Exception:
            return 0
    for x in sorted(pairs, key=_cnt, reverse=True)[:limit]:
        r = str(x.get('reason') or x.get('name') or x.get('key') or x.get('label') or '').strip()
        c = _cnt(x)
        if r:
            rows.append(f"{r} {c}")
    return ' / '.join(rows) if rows else '-'


def _v436_simple_panel_from_strategy(strat: Dict[str, Any]) -> Dict[str, Any]:
    panel = strat.get('s123_simple_panel') if isinstance(strat.get('s123_simple_panel'), dict) else {}
    if panel:
        return panel
    audit = strat.get('s1_block_audit') if isinstance(strat.get('s1_block_audit'), dict) else {}
    if audit:
        return {
            'schema': 's123_simple_panel_fallback_from_audit',
            'stage_counts': audit.get('stage_counts', strat.get('s_stage_counts', {})),
            'verdict': 'S1/S2/S3 사유 cache 표시',
            'reason_top': audit.get('reason_top', []),
            'missing_info_top': audit.get('missing_info_top', []),
            'decision_top': audit.get('decision_top', []),
        }
    return {'stage_counts': strat.get('s_stage_counts', {}), 'verdict': 'S1/S2/S3 사유 cache 준비중'}


def candidate_reason_text() -> str:
    strat = _v427_strategy_summary()
    audit = _v427_read_small(BASE_DIR / 'clean_strategy_s1_block_audit.json', {}) or {}
    if isinstance(audit, dict) and audit:
        panel = audit.get('s123_simple_panel') if isinstance(audit.get('s123_simple_panel'), dict) else _v436_simple_panel_from_strategy({'s1_block_audit': audit, 's_stage_counts': audit.get('stage_counts', {})})
    else:
        panel = _v436_simple_panel_from_strategy(strat)
    sc = panel.get('stage_counts') if isinstance(panel.get('stage_counts'), dict) else strat.get('s_stage_counts', {}) if isinstance(strat, dict) else {}

    def _fmt_num(v: Any, suffix: str = '') -> str:
        try:
            if v is None or v == '':
                return '-'
            x = float(str(v).replace('%','').replace(',',''))
            if abs(x) >= 10:
                body = f"{x:.1f}"
            else:
                body = f"{x:.2f}"
            return body + suffix
        except Exception:
            return '-'

    def _join_short(items: Any, limit: int = 3) -> str:
        if not items:
            return '-'
        if isinstance(items, list):
            arr = [str(x).strip() for x in items if str(x).strip()]
            return ' / '.join(arr[:limit]) if arr else '-'
        return str(items)

    def _candidate_lines(items: Any, limit: int = 10) -> List[str]:
        if not isinstance(items, list) or not items:
            return ['- 표시 후보 없음']
        lines: List[str] = []
        for idx, c in enumerate([x for x in items if isinstance(x, dict)][:limit], start=1):
            metrics = c.get('metrics') if isinstance(c.get('metrics'), dict) else {}
            ticker = str(c.get('ticker') or '-').replace('KRW-', '').replace('_KRW', '')
            stage = str(c.get('stage') or '-')
            strategy = str(c.get('strategy') or '-')
            score = _fmt_num(c.get('score'))
            decision = str(c.get('decision') or '-')
            block = _join_short(c.get('block_reasons'), 3)
            missing = _join_short(c.get('missing_info'), 2)
            reaction = _fmt_num(metrics.get('price_reaction_pct'), '%')
            spread = _fmt_num(metrics.get('spread_pct'), '%')
            slip = _fmt_num(metrics.get('slippage_pct'), '%')
            buy = _fmt_num(metrics.get('buy_ratio'))
            sustain = _fmt_num(metrics.get('buy_sustain_1m'))
            lines.append(f"{idx}) {ticker} · {stage} · {strategy} · 점수 {score}")
            lines.append(f"   막힘: {block} / 부족: {missing}")
            lines.append(f"   수치: 반응 {reaction} · 스프 {spread} · 미끄 {slip} · 매수 {buy} · 지속 {sustain} · 판정 {decision}")
        return lines

    top_candidates = panel.get('top_candidates') if isinstance(panel.get('top_candidates'), list) else []
    lines = [
        '🧭 후보판정 이유 /candidate_reason · cache-only',
        '- 기준: S1/S2/S3만 봅니다. S/A/B 추가 등급은 쓰지 않습니다.',
        '- 후보 생성/저장은 제한하지 않고, 화면 표시만 좋은순 상위 10개입니다.',
        f"- 전체평가: {strat.get('evaluated','-') if isinstance(strat,dict) else '-'} / 후보파일 {strat.get('paper_latest_count','-') if isinstance(strat,dict) else '-'} / 고정 40개 제한 아님",
        f"- 현재 단계: S1 {_v427_int(sc.get('S1',0))} / S2 {_v427_int(sc.get('S2',0))} / S3 {_v427_int(sc.get('S3',0))}",
        f"- 판정: {panel.get('verdict','-')}",
        f"- S1 막힘 상위: {_v436_list_top(panel.get('reason_top'), 5)}",
        f"- 부족정보 상위: {_v436_list_top(panel.get('missing_info_top'), 5)}",
        f"- 복기판정 상위: {_v436_list_top(panel.get('decision_top'), 5)}",
        '',
        '[상위 후보 10개 · 표시만 제한]',
        *_candidate_lines(top_candidates, 10),
        '',
        '[다음 판단]',
        '- S2 후보가 상위권에 반복되면 S2→S1 막힘 사유를 봅니다.',
        '- 상위권이 전부 스프레드·미끄러짐·매도압력이면 조건 완화보다 진입 보류가 맞습니다.',
        '- 좋은 후보가 실제로 오른 뒤 S2/S3에 남으면 그때 S1 안전문 한 묶음만 조정합니다.',
    ]
    return '\n'.join(lines)

def health_text() -> str:  # type: ignore[override]
    res = resource_snapshot()
    paper = _v427_status()
    trace = _v427_trace()
    strat = _v427_strategy_summary()
    router = _v427_router()
    oflow = _v427_read_small(FILES.get('orderflow', BASE_DIR / 'clean_orderflow_summary_cache.json'), {}) or {}
    p_age = age(FILES.get('paper_status', BASE_DIR / 'paper_bot_status.json'))
    t_age = age(FILES.get('candidate_handoff_trace', BASE_DIR / 'paper_bot_candidate_handoff_trace.json'))
    pver = paper.get('version', '-') if isinstance(paper, dict) else '-'
    tver = trace.get('version', trace.get('trace_version', '-')) if isinstance(trace, dict) else '-'
    sc = strat.get('s_stage_counts') if isinstance(strat.get('s_stage_counts'), dict) else {}
    lines_worker = [_v427_worker_line(k) for k in WORKERS]
    good = sum(1 for x in lines_worker if x.startswith('- ✅'))
    evaluated = _v427_int(strat.get('evaluated', 0)) if isinstance(strat, dict) else 0
    qready = _v427_int(strat.get('quote_ready_count', 0)) if isinstance(strat, dict) else 0
    mready = _v427_int(strat.get('micro_ready_count', 0)) if isinstance(strat, dict) else 0
    full = _v427_int(strat.get('full_info_ready_count', 0)) if isinstance(strat, dict) else 0
    verdict = '정상' if p_age < 90 and t_age < 120 else '확인필요'
    return '\n'.join([
        '🧭 건강상태 /health · v438 cache-only',
        f"⚠️ 전체판독: worker {good}/9 정상 · paper/trace {verdict} · 자원 {'주의' if fnum(res.get('disk_used_pct'),0) >= 85 or fnum(res.get('mem_used_pct'),0) >= 80 else '정상'}",
        f"- 메인봇 {BOT_VERSION} / {RESTORE_BUILD} / uptime {int(now_ts()-START_TS)}s",
        f"- 정보: 평가 {evaluated or '-'} / 시세 {qready}/{evaluated or '-'} / micro {mready}/{evaluated or '-'} / 둘다 {full}/{evaluated or '-'}",
        f"- 후보 생애주기: S1 {_v427_int(sc.get('S1',0))} / S2 {_v427_int(sc.get('S2',0))} / S3 {_v427_int(sc.get('S3',0))}",
        f"- 후보파일: active latest {strat.get('paper_latest_count','-') if isinstance(strat,dict) else '-'}개 / 고정 40개 제한 아님 / 전체평가 {evaluated or '-'}개",
        f"- S1 판정: {_v436_simple_panel_from_strategy(strat).get('verdict','-') if isinstance(strat,dict) else '-'}",
        f"- S1 막힘 상위: {_v436_list_top(_v436_simple_panel_from_strategy(strat).get('reason_top'), 3) if isinstance(strat,dict) else '-'}",
        f"- paper: {pver} / trace {tver} / status age {p_age:.1f}s / trace age {t_age:.1f}s / OPEN {paper.get('open_count', paper.get('open_total','-')) if isinstance(paper,dict) else '-'} / CLOSED누적 {paper.get('closed_total', paper.get('closed_count','-')) if isinstance(paper,dict) else '-'}",
        f"- 현재 paper 상태: {'OPEN 없음' if isinstance(paper,dict) and _v427_int(paper.get('open_count', paper.get('open_total',0))) == 0 else 'OPEN 진행 중'}",
        f"- 배차: 전체 {router.get('queue_count','-') if isinstance(router,dict) else '-'} → 내보냄 {router.get('export_count', router.get('active_target_count','-')) if isinstance(router,dict) else '-'} / micro fresh {oflow.get('fresh_micro','-') if isinstance(oflow,dict) else '-'}",
        f"- 자원: 디스크 {res.get('disk_used_pct','-')}% / 남음 {res.get('disk_free_gb','-')}GB / 메모리 {res.get('mem_used_pct','-')}% / load {res.get('load','-')}",
        '', '[worker 요약 · 캐시만]', *lines_worker,
        '', '[고정]', '- 메인봇은 장부 정리/압축/삭제를 하지 않습니다. 정리는 가드봇 /gcleanup 담당입니다.', '- 기본 명령은 CLOSED 전체장부 직접조회로 돌아가지 않습니다.'
    ])


def pstatus_text() -> str:  # type: ignore[override]
    status = _v427_status()
    hand = _v427_read_small(FILES.get('paperbot_handoff', BASE_DIR / 'paper_bot_candidate_handoff_status.json'), {}) or {}
    trace = _v427_trace()
    pos = _v427_open_positions()
    grades = Counter(str((p.get('stage') or p.get('s_stage') or p.get('candidate_grade') or p.get('grade') or 'S1')).upper() for p in pos)
    pick = status.get('pick_stats') if isinstance(status.get('pick_stats'), dict) else {}
    p_age = age(FILES.get('paper_status', BASE_DIR / 'paper_bot_status.json'))
    t_age = age(FILES.get('candidate_handoff_trace', BASE_DIR / 'paper_bot_candidate_handoff_trace.json'))
    return '\n'.join([
        '🧪 paper 상태 /pstatus · v427 cache-only',
        f"- 상태: {'ON' if status.get('running', True) else '확인필요'} / paper {status.get('version','-')} / trace {trace.get('version', trace.get('trace_version','-')) if isinstance(trace,dict) else '-'} / status age {p_age:.1f}s / trace age {t_age:.1f}s / OPEN {len(pos)} / CLOSED누적 {status.get('closed_total', status.get('closed_count','-'))}",
        f"- OPEN: S1 {grades.get('S1',0)} / S2 {grades.get('S2',0)} / S3 {grades.get('S3',0)} / 제외 {grades.get('X',0)}",
        f"- 이번 cycle: OPEN {status.get('opened_this_cycle',0)} / CLOSED {status.get('closed_this_cycle',0)} / elapsed {status.get('elapsed_sec','-')}s",
        f"- 후보선별: active latest {pick.get('latest_count', hand.get('latest_count', hand.get('latest_lines','-')) if isinstance(hand,dict) else '-')}개 / 고정 40개 제한 아님 / fresh {pick.get('merged_fresh', hand.get('merged_fresh','-') if isinstance(hand,dict) else '-')} / S1선택 {pick.get('selected_s1',0)} / micro대기 {pick.get('micro_preopen_wait',0)}",
        '', '[판독]', '- 이 화면은 paper status/open/handoff cache만 읽습니다.', '- 느리면 paper_bot 상태 저장 또는 Telegram 처리 흐름 문제입니다.'
    ])


def score_text() -> str:  # type: ignore[override]
    cache = _v427_cache()
    status = _v427_status()
    cache_age = age(FILES.get('paper_score', BASE_DIR / 'paper_bot_score_cache.json'))
    status_age = age(FILES.get('paper_status', BASE_DIR / 'paper_bot_status.json'))
    status_closed = _v427_int(status.get('closed_total', status.get('closed_count', 0)))
    cache_closed = _v427_int(cache.get('current_closed_count', cache.get('closed_count', cache.get('n', 0)))) if cache else 0
    lines = [
        '📊 S1/S2/S3 스코어 /score · v427 cache-only',
        '- 기준: paper_bot_score_cache.json + paper_bot_status.json만 읽습니다.',
        f"- paper status: CLOSED누적 {status_closed} / OPEN {status.get('open_count', status.get('open_total','-'))} / age {status_age:.1f}s / version {status.get('version','-')}",
        f"- score cache: CLOSED {cache_closed} / age {cache_age:.1f}s / {cache.get('version','-') if isinstance(cache,dict) else '-'} / {cache.get('schema','-') if isinstance(cache,dict) else '-'}",
    ]
    if status_closed and not cache_closed:
        lines.append('- ⚠️ CLOSED는 있는데 score cache가 비었습니다. paper_bot score cache 저장 경로 확인이 필요합니다.')
    grade = cache.get('grade_stats') if isinstance(cache.get('grade_stats'), dict) else {}
    lines += ['', '[등급별 성과 · cache]']
    for key, label in [('S1','✅ S1 즉시진입'), ('S2','⚠️ S2 재확인'), ('S3','❔ S3 관찰복기'), ('S','S 전체'), ('ALL','전체')]:
        if key in {'S','ALL'} or grade.get(key):
            lines.append(_v427_stat_line(label, grade.get(key) or (cache.get('global_stats') if key == 'ALL' else {})))
    smap = cache.get('strategy_primary_stats') or cache.get('strategy_stats') or cache.get('by_strategy')
    lines += ['', '[대표전략 · cache]']
    if isinstance(smap, dict) and smap:
        for k, v in list(smap.items())[:8]:
            lines.append(_v427_stat_line(str(k), v))
    else:
        lines.append('- 아직 대표전략 cache 없음')
    return '\n'.join(lines)


def pscore_text() -> str:  # type: ignore[override]
    return score_text().replace('📊 S1/S2/S3 스코어 /score', '📊 paper 스코어 /pscore', 1)


def _v433_norm_version_key(v: Any, field: str = "") -> str:
    """paper score cache의 version_summary key를 v2.13.xxx로만 읽는다.

    v433부터 /version_score는 장부를 직접 읽지 않고, paper_bot이 만든
    version_summary 단일 schema만 소비한다. v390/v391 단축 표기는 main/deploy
    단서가 있을 때만 v2.13.xxx로 정규화한다.
    """
    if v is None:
        return ""
    s = str(v).strip()
    if not s:
        return ""
    m = re.search(r"(?:^|[^0-9])2[_.]13[_.](\d{1,4})(?:[^0-9]|$)", s)
    if m:
        return f"v2.13.{int(m.group(1))}"
    m = re.search(r"v2\.13\.(\d{1,4})", s)
    if m:
        return f"v2.13.{int(m.group(1))}"
    field_l = str(field or "").lower()
    value_l = s.lower()
    mainish = any(x in field_l for x in ("main", "deploy", "target", "brain", "version")) or any(
        x in value_l for x in ("main", "deploy", "target", "수익형", "coinbot_main")
    )
    if mainish:
        hits = re.findall(r"(?:^|[^0-9])v(\d{3,4})(?:[^0-9]|$)", s)
        if hits:
            n = int(hits[-1])
            if 300 <= n <= 9999:
                return f"v2.13.{n}"
    return s


def _v433_version_summary_from_cache(cache: Dict[str, Any]) -> Tuple[Dict[str, Any], bool]:
    """v433 단일 본선: paper_score_cache.version_summary만 읽는다."""
    raw = cache.get('version_summary') if isinstance(cache, dict) else None
    if not isinstance(raw, dict):
        return {}, False
    out: Dict[str, Any] = {}
    for k, v in raw.items():
        nk = _v433_norm_version_key(k, 'version_summary') or 'unknown'
        out[nk] = _v427_merge_stat(out.get(nk, {}), v)
    return out, True


def _v427_merge_stat(a: Any, b: Any) -> Dict[str, Any]:
    sa = _v427_stat(a)
    sb = _v427_stat(b)
    n = sa['n'] + sb['n']
    wins = sa['wins'] + sb['wins']
    losses = sa['losses'] + sb['losses']
    total = sa['total'] + sb['total']
    return {
        'n': n,
        'wins': wins,
        'losses': losses,
        'win_rate': (wins / n * 100.0 if n else 0.0),
        'total': total,
        'avg': (total / n if n else 0.0),
    }


def version_score_text() -> str:  # type: ignore[override]
    cache = _v427_cache()
    status = _v427_status()
    byv, has_summary = _v433_version_summary_from_cache(cache)
    schema = cache.get('schema','-') if isinstance(cache,dict) else '-'
    keys = cache.get('version_summary_keys') if isinstance(cache.get('version_summary_keys'), list) else sorted(byv.keys())
    lines = [
        '📊 버전별 성과 /version_score · v438 cache-only',
        '- 기준: score cache의 version_summary만 읽습니다. CLOSED 전체 장부 직접조회는 하지 않습니다.',
        '- 변경: version_summary cache + S1/S2/S3 단순판독 + 후보 표시 상위 10개를 유지합니다.',
        f"- 메인봇: {BOT_VERSION} / {RESTORE_BUILD}",
        f"- paper: {status.get('version','-')} / status age {age(FILES.get('paper_status', BASE_DIR/'paper_bot_status.json')):.1f}s / CLOSED누적 {status.get('closed_total', status.get('closed_count','-'))}",
        f"- cache age {age(FILES.get('paper_score', BASE_DIR/'paper_bot_score_cache.json')):.1f}s / schema {schema} / version_summary {'있음' if has_summary else '없음'}",
        '', '[최근 적용판 요약 · cache]'
    ]
    if not has_summary:
        lines.append('- ❌ score cache에 version_summary가 없습니다. paper_bot_v0.132 score cache 생성부 확인 필요')
        return '\n'.join(lines)
    for ver in _V421_RECENT_VERSIONS:
        lines.append(_v427_stat_line(ver, byv.get(ver, {})))
    other_items = []
    for k, v in byv.items():
        if k not in set(_V421_RECENT_VERSIONS):
            st = _v427_stat(v)
            if st['n']:
                other_items.append((k, st))
    if other_items:
        lines += ['', '[다른 버전 bucket · cache]']
        for k, st in sorted(other_items, key=lambda x: x[0], reverse=True)[:5]:
            lines.append(f"- {k}: {st['n']}전 {st['wins']}승 {st['losses']}패 / 합산 {st['total']:+.2f}%")
    if keys:
        lines.append(f"- cache keys: {', '.join(str(x) for x in list(keys)[:8])}")
    return '\n'.join(lines)


def retention_status_text() -> str:
    st = _v427_read_small(BASE_DIR / 'clean_retention_state.json', {}) or {}
    if not isinstance(st, dict) or not st:
        return '🧹 정리상태 /retention\n- 아직 가드봇 정리 기록 없음\n- 가드봇방 /gcleanup 또는 다음 /gupgrade_bundle 때 정리됩니다.'
    ts = fnum(st.get('ts'), default=0.0)
    age_sec = now_ts() - ts if ts else -1
    pol = st.get('policy') if isinstance(st.get('policy'), dict) else {}
    return '\n'.join([
        '🧹 정리상태 /retention · guard-owned',
        f"- 마지막 실행: {st.get('time','-')} / age {age_sec:.0f}s / version {st.get('version','-')}",
        f"- 처리: 삭제 {st.get('deleted',0)} / 축소 {st.get('truncated',0)} / 압축 {st.get('compressed',0)} / 오류 {st.get('errors',0)}",
        f"- 정책: OPEN삭제 {pol.get('open_deleted', False)} / CLOSED 최근 {pol.get('closed_keep_lines',300)}줄 / update zip 최신 {pol.get('update_zip_keep',3)}개",
        '- 메인봇은 정리 작업을 직접 실행하지 않습니다.',
    ])


def data_prune_text() -> str:  # type: ignore[override]
    return '🧹 /data_prune 안내\n- 메인봇에서는 장부 정리/압축/삭제를 실행하지 않습니다.\n- 가드봇방 /gcleanup 이 정리 본선입니다.\n- OPEN 장부는 정리 대상이 아닙니다.'


def batch_handler(update, context):  # type: ignore[override]
    cmds = getattr(context, 'args', None) or ['health', 'version_score', 'popen', 'retention', 'errorlog']
    cmds = [str(x).strip().lstrip('/') for x in cmds[:8] if str(x).strip()]
    st = time.time(); sent = 0; timings = []
    try:
        send(update, f"📦 자동 묶음 명령 접수\n- 실행 {len(cmds)}개\n- v427: 메인 cache-only / 정리는 가드봇")
    except Exception:
        pass
    total = len(cmds)
    for raw in cmds:
        name = raw.strip().lstrip('/')
        fn = COMMANDS.get(name)
        if not fn:
            sent += 1
            body = f"❌ /{name} 명령이 메인봇에 연결되지 않았습니다."
            timings.append(f"- ❌ /{name}: 미등록")
            send(update, f"[{sent}/{total}] /{name} (미등록)\n{body}")
            continue
        t = time.time()
        try:
            body = fn(); ok = 'OK'
        except Exception as exc:
            body = f"❌ /{name} 오류 {exc.__class__.__name__}: {exc}"; ok = 'ERR'; log_error(f'batch_{name}', exc)
        sec = time.time() - t; sent += 1
        timings.append(f"- {'✅' if ok=='OK' else '❌'} /{name}: {sec:.2f}s / {ok}")
        send(update, f"[{sent}/{total}] /{name} ({sec:.2f}s / {ok})\n{body}")
    send(update, "🧾 자동 묶음 시간표 · v427\n" + "\n".join(timings) + f"\n- 합계 {time.time()-st:.2f}s")


def set_commands(updater):  # type: ignore[override]
    try:
        updater.bot.set_my_commands([
            BotCommand('health','전체 상태'),
            BotCommand('version_score','버전별/진입유형 성과'),
            BotCommand('popen','모의매매 진행중'),
            BotCommand('pstatus','paper 상태'),
            BotCommand('score','성과표'),
            BotCommand('candidate_reason','후보판정 이유'),
            BotCommand('retention','정리상태'),
            BotCommand('errorlog','오류로그'),
            BotCommand('batch','묶음 확인'),
        ])
    except Exception as exc:
        log_error('set_commands_v427', exc)

try:
    COMMANDS.update({
        'health': health_text, 'core': health_text,
        'pstatus': pstatus_text,
        'popen': popen_text,
        'score': score_text, 'pscore': pscore_text,
        'candidate_reason': candidate_reason_text, 'reason': candidate_reason_text, 'why_s1': candidate_reason_text,
        'version_score': version_score_text, 'vscore': version_score_text,
        'retention': retention_status_text, 'retention_status': retention_status_text,
        'data_prune': data_prune_text, 'cleanup_data': data_prune_text,
        'errorlog': errorlog_text, 'perror': errorlog_text,
    })
    for _old in ('s1_review', 's1review', 'condition_map'):
        COMMANDS.pop(_old, None)
    log_runtime('v427_main_cache_only_loaded guard_retention_owner')
except Exception:
    pass


# v438: 자동 놓친후보 복기 명령 + 명령어 탭 정리
BOT_VERSION = "수익형 v2.13.397"
RESTORE_BUILD = "v439_v397_review_close_basis_2026-05-25"
MISSED_REVIEW_SUMMARY = BASE_DIR / "clean_missed_review_summary.json"

def _v438_fmt_pct(v: Any) -> str:
    try:
        return f"{float(v):+.2f}%"
    except Exception:
        return "-"

def _v438_review_item_lines(rows: Any, limit: int = 5) -> List[str]:
    if not isinstance(rows, list) or not rows:
        return ["- 없음"]
    out: List[str] = []
    for i, r in enumerate([x for x in rows if isinstance(x, dict)][:limit], 1):
        out.append(
            f"{i}) {r.get('ticker','-')} · {r.get('stage','-')} · {r.get('strategy','-')} · 최고 {_v438_fmt_pct(r.get('max_pct'))} / 현재 {_v438_fmt_pct(r.get('current_pct'))}"
        )
        out.append(f"   막힘: {r.get('reasons','-')}")
    return out

def _v438_reason_top(rows: Any) -> str:
    if not isinstance(rows, list) or not rows:
        return "-"
    parts=[]
    for r in rows[:5]:
        if isinstance(r, dict):
            parts.append(f"{r.get('reason','-')} {r.get('count',0)}")
    return " / ".join(parts) if parts else "-"

def review_text() -> str:
    s = _v427_read_small(MISSED_REVIEW_SUMMARY, {}) or {}
    if not isinstance(s, dict) or not s:
        return "🧾 놓친 후보 자동복기 /review\n- 아직 review cache가 준비되지 않았습니다.\n- S2/S3 후보가 생긴 뒤 review_worker가 5분/10분/20분 결과를 자동 추적합니다."
    age_sec = max(0.0, time.time() - float(s.get('updated_ts') or time.time()))
    lines = [
        '🧾 놓친 후보 자동복기 /review · cache-only',
        '- 기준: S2/S3 상위 후보를 5분/10분/20분 뒤 자동 추적합니다. 사용자가 직접 제보하지 않아도 됩니다.',
        f"- cache age {age_sec:.1f}s / schema {s.get('schema','-')}",
        f"- 추적 {s.get('tracking_total',0)}개 / queue {s.get('queue_candidates',0)}개",
        f"- ❌ 놓친 후보 {s.get('missed_count',0)} / ⚠️ 아까운 후보 {s.get('regret_count',0)} / ✅ 안 산 게 맞음 {s.get('correct_count',0)} / ❔ 추적중 {s.get('pending_count',0)}",
        f"- 놓침·아까움 사유 TOP: {_v438_reason_top(s.get('missed_reason_top'))}",
        '',
        '[❌ 놓친 후보]',
        *_v438_review_item_lines(s.get('missed'), 5),
        '',
        '[⚠️ 아까운 후보]',
        *_v438_review_item_lines(s.get('regret'), 5),
        '',
        '[❔ 추적중 상위]',
        *_v438_review_item_lines(s.get('pending'), 5),
        '',
        '[판정]',
        '- 놓친 후보/아까운 후보가 반복될 때만 S1 문턱을 한 묶음으로 조정합니다.',
        '- 스프레드·미끄러짐·매도압력으로 막힌 후보가 대부분 안 오르면 조건은 유지합니다.',
    ]
    return '\n'.join(lines)

def batch_handler(update, context):  # type: ignore[override]
    cmds = getattr(context, 'args', None) or ['health', 'candidate_reason', 'review', 'version_score', 'popen', 'errorlog']
    cmds = [str(x).strip().lstrip('/') for x in cmds[:8] if str(x).strip()]
    st = time.time(); sent = 0; timings = []
    try:
        send(update, f"📦 자동 묶음 명령 접수\n- 실행 {len(cmds)}개\n- v438: 상태+후보판정+자동복기 cache-only")
    except Exception:
        pass
    total = len(cmds)
    for raw in cmds:
        name = raw.strip().lstrip('/')
        fn = COMMANDS.get(name)
        if not fn:
            sent += 1
            body = f"❌ /{name} 명령이 메인봇에 연결되지 않았습니다."
            timings.append(f"- ❌ /{name}: 미등록")
            send(update, f"[{sent}/{total}] /{name} (미등록)\n{body}")
            continue
        t = time.time()
        try:
            body = fn(); ok = 'OK'
        except Exception as exc:
            body = f"❌ /{name} 오류 {exc.__class__.__name__}: {exc}"; ok = 'ERR'; log_error(f'batch_{name}', exc)
        sec = time.time() - t; sent += 1
        timings.append(f"- {'✅' if ok=='OK' else '❌'} /{name}: {sec:.2f}s / {ok}")
        send(update, f"[{sent}/{total}] /{name} ({sec:.2f}s / {ok})\n{body}")
    send(update, "🧾 자동 묶음 시간표 · v438\n" + "\n".join(timings) + f"\n- 합계 {time.time()-st:.2f}s")

def set_commands(updater):  # type: ignore[override]
    try:
        updater.bot.set_my_commands([
            BotCommand('health','상태·worker·paper'),
            BotCommand('candidate_reason','현재 후보 S1/S2/S3'),
            BotCommand('review','놓친후보 자동복기'),
            BotCommand('version_score','버전별/진입유형 성과'),
            BotCommand('popen','모의매매 진행중'),
            BotCommand('errorlog','오류로그'),
            BotCommand('batch','기본 묶음'),
        ])
    except Exception as exc:
        log_error('set_commands_v438', exc)

try:
    COMMANDS.update({
        'health': health_text, 'core': health_text,
        'candidate_reason': candidate_reason_text, 'reason': candidate_reason_text, 'why_s1': candidate_reason_text,
        'review': review_text, 'missed_review': review_text, 'pmissed_review': review_text,
        'version_score': version_score_text, 'vscore': version_score_text,
        'popen': popen_text,
        'errorlog': errorlog_text, 'perror': errorlog_text,
        'batch': lambda: 'batch는 텔레그램 handler로 실행됩니다.',
    })
    log_runtime('v438_auto_missed_review_command_group_loaded')
except Exception:
    pass

# v440: 구 시작 경로 제거. 최종 tail 아래에서만 main() 실행.
# if __name__ == "__main__": main()


# v439: 복기/청산 근거 표시 + 현재판 version_score 위치 정리
BOT_VERSION = "수익형 v2.13.397"
RESTORE_BUILD = "v439_v397_review_close_basis_2026-05-25"
_CURRENT_MAIN_VER = "v2.13.397"
_V421_RECENT_VERSIONS = ["v2.13.397", "v2.13.396", "v2.13.395"]

def _v439_fmt_pct(v: Any) -> str:
    try:
        return f"{float(v):+.2f}%"
    except Exception:
        return "-"

def _v439_fmt_num(v: Any, suffix: str = '') -> str:
    try:
        if v is None or v == '':
            return '-'
        return f"{float(str(v).replace('%','').replace(',','')):.2f}" + suffix
    except Exception:
        return '-'

def _v439_reason_top(rows: Any) -> str:
    if not isinstance(rows, list) or not rows:
        return '-'
    parts=[]
    for r in rows[:5]:
        if isinstance(r, dict):
            parts.append(f"{r.get('reason','-')} {r.get('count',0)}")
    return ' / '.join(parts) if parts else '-'

def _v439_review_item_lines(rows: Any, limit: int = 5) -> List[str]:
    if not isinstance(rows, list) or not rows:
        return ['- 없음']
    out=[]
    for i,r in enumerate([x for x in rows if isinstance(x,dict)][:limit],1):
        out.append(f"{i}) {r.get('ticker','-')} · {r.get('stage','-')} · {r.get('strategy','-')} · 최고 {_v439_fmt_pct(r.get('max_pct'))} / 현재 {_v439_fmt_pct(r.get('current_pct'))}")
        out.append(f"   막힘: {r.get('reasons','-')}")
        if r.get('review_hint'):
            out.append(f"   재확인: {r.get('review_hint')}")
    return out

def _v439_close_lines(items: Any, limit: int = 5) -> List[str]:
    if not isinstance(items, list) or not items:
        return ['- 없음']
    out=[]
    for i,r in enumerate([x for x in items if isinstance(x,dict)][:limit],1):
        out.append(f"{i}) {r.get('ticker','-')} · 최고 {_v439_fmt_pct(r.get('peak_pct'))} → 최종 {_v439_fmt_pct(r.get('pnl_pct'))} / 놓친수익 {_v439_fmt_pct(r.get('giveback_pct'))}")
        out.append(f"   이유: {r.get('reason','-')} / {r.get('tag','-')}")
    return out

def review_text() -> str:  # type: ignore[override]
    s=_v427_read_small(MISSED_REVIEW_SUMMARY,{}) or {}
    if not isinstance(s,dict) or not s:
        return '🧾 놓친 후보 자동복기 /review\n- 아직 review cache가 준비되지 않았습니다.'
    age_sec=max(0.0,time.time()-float(s.get('updated_ts') or time.time()))
    cr=s.get('close_review') if isinstance(s.get('close_review'),dict) else {}
    lines=[
        '🧾 놓친 후보·청산 자동복기 /review · cache-only',
        '- 기준: S2/S3 상위 후보 추적 + paper CLOSED 최고수익 대비 최종손익을 같이 봅니다.',
        f"- cache age {age_sec:.1f}s / schema {s.get('schema','-')}",
        f"- 추적 {s.get('tracking_total',0)}개 / queue {s.get('queue_candidates',0)}개",
        f"- ❌ 놓친 후보 {s.get('missed_count',0)} / ⚠️ 아까운 후보 {s.get('regret_count',0)} / ✅ 안 산 게 맞음 {s.get('correct_count',0)} / ❔ 추적중 {s.get('pending_count',0)}",
        f"- 놓침·아까움 사유 TOP: {_v439_reason_top(s.get('missed_reason_top'))}",
        '', '[❌ 놓친 후보]', *_v439_review_item_lines(s.get('missed'),5),
        '', '[⚠️ 아까운 후보]', *_v439_review_item_lines(s.get('regret'),5),
        '', '[❔ 추적중 상위]', *_v439_review_item_lines(s.get('pending'),5),
        '', '[청산 복기 · 최고수익 대비 최종손익]',
        f"- 보호익절 필요 후보 {cr.get('protect_needed_count',0)} / 빠른실패 정리 후보 {cr.get('fast_fail_count',0)} / 수익 보존 양호 {cr.get('good_keep_count',0)}",
        '[보호익절 필요 후보]', *_v439_close_lines(cr.get('protect_needed'),5),
        '[빠른실패 정리 후보]', *_v439_close_lines(cr.get('fast_fail'),5),
        '', '[판정]',
        '- 놓친 후보/아까운 후보가 반복될 때만 S1 문턱을 한 묶음으로 조정합니다.',
        '- 최고수익 후 음전/큰 되돌림이 반복될 때만 보호익절·빠른실패 청산을 설계합니다.',
    ]
    return '\n'.join(lines)

def candidate_reason_text() -> str:  # type: ignore[override]
    strat=_v427_strategy_summary(); audit=_v427_read_small(BASE_DIR/'clean_strategy_s1_block_audit.json',{}) or {}
    panel=audit.get('s123_simple_panel') if isinstance(audit,dict) and isinstance(audit.get('s123_simple_panel'),dict) else _v436_simple_panel_from_strategy(strat)
    sc=panel.get('stage_counts') if isinstance(panel.get('stage_counts'),dict) else {}
    def join_short(items,limit=3):
        if not items: return '-'
        if isinstance(items,list):
            arr=[str(x).strip() for x in items if str(x).strip()]
            return ' / '.join(arr[:limit]) if arr else '-'
        return str(items)
    def cand_lines(items,limit=10):
        if not isinstance(items,list) or not items:
            return ['- 표시 후보 없음']
        lines=[]
        for idx,c in enumerate([x for x in items if isinstance(x,dict)][:limit],1):
            m=c.get('metrics') if isinstance(c.get('metrics'),dict) else {}
            lines.append(f"{idx}) {str(c.get('ticker') or '-').replace('KRW-','').replace('_KRW','')} · {c.get('stage','-')} · {c.get('strategy','-')} · 점수 {_v439_fmt_num(c.get('score'))}")
            lines.append(f"   막힘: {join_short(c.get('block_reasons'),3)} / 부족: {join_short(c.get('missing_info'),2)}")
            lines.append(f"   수치: 반응 {_v439_fmt_num(m.get('price_reaction_pct'),'%')} · 스프 {_v439_fmt_num(m.get('spread_pct'),'%')} · 미끄 {_v439_fmt_num(m.get('slippage_pct'),'%')} · 매수 {_v439_fmt_num(m.get('buy_ratio'))} · 지속 {_v439_fmt_num(m.get('buy_sustain_1m'))} · 판정 {c.get('decision','-')}")
            if c.get('review_hint'):
                lines.append(f"   재확인: {c.get('review_hint')}")
        return lines
    top=panel.get('top_candidates') if isinstance(panel.get('top_candidates'),list) else []
    return '\n'.join([
        '🧭 후보판정 이유 /candidate_reason · cache-only',
        '- 기준: S1/S2/S3만 봅니다. 조건 수치는 바꾸지 않았습니다.',
        '- 후보 생성/저장은 제한하지 않고, 화면 표시만 좋은순 상위 10개입니다.',
        f"- 전체평가: {strat.get('evaluated','-') if isinstance(strat,dict) else '-'} / 후보파일 {strat.get('paper_latest_count','-') if isinstance(strat,dict) else '-'} / 고정 40개 제한 아님",
        f"- 현재 단계: S1 {_v427_int(sc.get('S1',0))} / S2 {_v427_int(sc.get('S2',0))} / S3 {_v427_int(sc.get('S3',0))}",
        f"- 판정: {panel.get('verdict','-')}",
        f"- S1 막힘 상위: {_v436_list_top(panel.get('reason_top'),5)}",
        f"- 부족정보 상위: {_v436_list_top(panel.get('missing_info_top'),5)}",
        f"- 복기판정 상위: {_v436_list_top(panel.get('decision_top'),5)}",
        '', '[상위 후보 10개 · 표시만 제한]', *cand_lines(top,10),
        '', '[다음 판단]',
        '- 재확인 승격 후보가 반복되면 그 조건만 S1 문턱 조정 후보로 봅니다.',
        '- 스프레드·미끄러짐·매도압력이 큰 후보는 계속 보류합니다.',
    ])

def version_score_text() -> str:  # type: ignore[override]
    cache=_v427_cache(); status=_v427_status(); byv=cache.get('version_summary') if isinstance(cache.get('version_summary'),dict) else {}; schema=cache.get('schema','-'); has=isinstance(byv,dict); keys=list(byv.keys()) if has else []
    recent=[]
    if _CURRENT_MAIN_VER: recent.append(_CURRENT_MAIN_VER)
    for v in _V421_RECENT_VERSIONS:
        if v not in recent: recent.append(v)
    if has:
        for k in sorted(keys,reverse=True):
            if k not in recent and len(recent)<3: recent.append(k)
    recent=recent[:3]
    lines=['📊 버전별 성과 /version_score · v439 cache-only','- 기준: score cache의 version_summary만 읽습니다. CLOSED 전체 장부 직접조회는 하지 않습니다.','- 변경: 현재 실행판을 최근 적용판 요약에 우선 표시합니다.',f"- 메인봇: {BOT_VERSION} / {RESTORE_BUILD}",f"- paper: {status.get('version','-')} / status age {age(FILES.get('paper_status', BASE_DIR/'paper_bot_status.json')):.1f}s / CLOSED누적 {status.get('closed_total', status.get('closed_count','-'))}",f"- cache age {age(FILES.get('paper_score', BASE_DIR/'paper_bot_score_cache.json')):.1f}s / schema {schema} / version_summary {'있음' if has else '없음'}",'','[최근 적용판 요약 · cache]']
    if not has:
        lines.append('- ❌ score cache에 version_summary가 없습니다.')
        return '\n'.join(lines)
    for ver in recent: lines.append(_v427_stat_line(ver, byv.get(ver,{})))
    other=[]
    for k,v in byv.items():
        if k not in set(recent):
            st=_v427_stat(v)
            if st['n']: other.append((k,st))
    if other:
        lines+=['','[다른 버전 bucket · cache]']
        for k,st in sorted(other,key=lambda x:x[0],reverse=True)[:5]: lines.append(f"- {k}: {st['n']}전 {st['wins']}승 {st['losses']}패 / 합산 {st['total']:+.2f}%")
    if keys: lines.append(f"- cache keys: {', '.join(str(x) for x in list(keys)[:8])}")
    return '\n'.join(lines)

def batch_handler(update, context):  # type: ignore[override]
    cmds=getattr(context,'args',None) or ['health','candidate_reason','review','version_score','popen','errorlog']
    cmds=[str(x).strip().lstrip('/') for x in cmds[:8] if str(x).strip()]; st=time.time(); sent=0; timings=[]
    try: send(update,f"📦 자동 묶음 명령 접수\n- 실행 {len(cmds)}개\n- v439: 후보복기+청산복기 cache-only")
    except Exception: pass
    for raw in cmds:
        name=raw.strip().lstrip('/'); fn=COMMANDS.get(name); sent+=1; t=time.time()
        if not fn: body=f"❌ /{name} 명령이 메인봇에 연결되지 않았습니다."; ok='ERR'
        else:
            try: body=fn(); ok='OK'
            except Exception as exc: body=f"❌ /{name} 오류 {exc.__class__.__name__}: {exc}"; ok='ERR'; log_error(f'batch_{name}',exc)
        sec=time.time()-t; timings.append(f"- {'✅' if ok=='OK' else '❌'} /{name}: {sec:.2f}s / {ok}"); send(update,f"[{sent}/{len(cmds)}] /{name} ({sec:.2f}s / {ok})\n{body}")
    send(update,"🧾 자동 묶음 시간표 · v439\n"+"\n".join(timings)+f"\n- 합계 {time.time()-st:.2f}s")
try:
    COMMANDS.update({'candidate_reason':candidate_reason_text,'reason':candidate_reason_text,'why_s1':candidate_reason_text,'review':review_text,'missed_review':review_text,'pmissed_review':review_text,'version_score':version_score_text,'vscore':version_score_text,'batch':lambda:'batch는 텔레그램 handler로 실행됩니다.'})
    log_runtime('v439_review_close_basis_loaded')
except Exception: pass


# =============================================================================
# v440: review/candidate display route final seal
# - v439 코드가 __main__ 이후에 붙어 실행되지 않던 구 시작 경로를 제거하고 여기서 최종 시작한다.
# - 조건/S1/S2/S3/청산숫자는 바꾸지 않는다.
# - review는 진짜 놓친 후보와 결과만 오른 위험 후보를 분리해서 표시한다.
# - candidate_reason은 top_candidates가 비었을 때 review queue/paper_latest에서 표시 후보를 재구성한다.
# =============================================================================
BOT_VERSION = "수익형 v2.13.399"
RESTORE_BUILD = "v441_v399_review_output_consistency_2026-05-25"
_CURRENT_MAIN_VER = "v2.13.399"
_V421_RECENT_VERSIONS = ["v2.13.399", "v2.13.398", "v2.13.397"]


def _v440_pct(v: Any) -> str:
    try:
        return f"{float(v):+.2f}%"
    except Exception:
        return "-"


def _v440_num(v: Any, suffix: str = "") -> str:
    try:
        if v is None or v == "":
            return "-"
        return f"{float(str(v).replace('%','').replace(',','')):.2f}" + suffix
    except Exception:
        return "-"


def _v440_reason_top(rows: Any) -> str:
    if not isinstance(rows, list) or not rows:
        return "-"
    out = []
    for r in rows[:5]:
        if isinstance(r, dict):
            out.append(f"{r.get('reason','-')} {r.get('count',0)}")
    return " / ".join(out) if out else "-"


def _v440_review_item_lines(rows: Any, limit: int = 5) -> List[str]:
    if not isinstance(rows, list) or not rows:
        return ["- 없음"]
    out: List[str] = []
    for i, r in enumerate([x for x in rows if isinstance(x, dict)][:limit], 1):
        out.append(f"{i}) {r.get('ticker','-')} · {r.get('stage','-')} · {r.get('strategy','-')} · 최고 {_v440_pct(r.get('max_pct'))} / 현재 {_v440_pct(r.get('current_pct'))}")
        out.append(f"   막힘: {r.get('reasons','-')}")
        risk = r.get('risk_note') or r.get('risk_reasons') or ''
        if risk:
            out.append(f"   위험판정: {risk}")
        hint = r.get('review_hint') or r.get('review_class') or ''
        if hint:
            out.append(f"   재확인: {hint}")
    return out


def _v440_close_lines(items: Any, limit: int = 5) -> List[str]:
    if not isinstance(items, list) or not items:
        return ["- 없음"]
    out: List[str] = []
    for i, r in enumerate([x for x in items if isinstance(x, dict)][:limit], 1):
        out.append(f"{i}) {r.get('ticker','-')} · 최고 {_v440_pct(r.get('peak_pct'))} → 최종 {_v440_pct(r.get('pnl_pct'))} / 놓친수익 {_v440_pct(r.get('giveback_pct'))}")
        out.append(f"   이유: {r.get('reason','-')} / {r.get('tag','-')}")
    return out


def review_text() -> str:  # type: ignore[override]
    s = _v427_read_small(MISSED_REVIEW_SUMMARY, {}) or {}
    if not isinstance(s, dict) or not s:
        return "🧾 놓친 후보·청산 자동복기 /review\n- 아직 review cache가 준비되지 않았습니다."
    age_sec = max(0.0, time.time() - float(s.get('updated_ts') or time.time()))
    cr = s.get('close_review') if isinstance(s.get('close_review'), dict) else {}
    lines = [
        '🧾 놓친 후보·청산 자동복기 /review · v440 cache-only',
        '- 기준: S2/S3 상위 후보 추적 + paper CLOSED 최고수익 대비 최종손익을 같이 봅니다.',
        '- 변경: 결과만 오른 위험 후보는 진짜 놓친 후보와 분리합니다.',
        f"- cache age {age_sec:.1f}s / schema {s.get('schema','-')}",
        f"- 추적 {s.get('tracking_total',0)}개 / queue {s.get('queue_candidates',0)}개",
        f"- ❌ 진짜 놓친 후보 {s.get('missed_count',0)} / ⚠️ 아까운 후보 {s.get('regret_count',0)} / 🔥 결과만 오른 위험 후보 {s.get('risk_rise_count',0)} / ✅ 안 산 게 맞음 {s.get('correct_count',0)} / ❔ 추적중 {s.get('pending_count',0)}",
        f"- 놓침·아까움 사유 TOP: {_v440_reason_top(s.get('missed_reason_top'))}",
        '', '[❌ 진짜 놓친 후보]', *_v440_review_item_lines(s.get('missed'), 5),
        '', '[⚠️ 아까운 후보]', *_v440_review_item_lines(s.get('regret'), 5),
        '', '[🔥 결과만 오른 위험 후보]', *_v440_review_item_lines(s.get('risk_rise'), 5),
        '', '[❔ 추적중 상위]', *_v440_review_item_lines(s.get('pending'), 5),
        '', '[청산 복기 · 최고수익 대비 최종손익]',
        f"- 보호익절 필요 후보 {cr.get('protect_needed_count',0)} / 빠른실패 정리 후보 {cr.get('fast_fail_count',0)} / 수익 보존 양호 {cr.get('good_keep_count',0)}",
        '[보호익절 필요 후보]', *_v440_close_lines(cr.get('protect_needed'), 5),
        '[빠른실패 정리 후보]', *_v440_close_lines(cr.get('fast_fail'), 5),
        '', '[판정]',
        '- 진짜 놓친 후보가 반복될 때만 S1 문턱을 한 묶음으로 조정합니다.',
        '- 스프레드·미끄러짐·매도압력·급락 되돌림이 큰 후보는 조건 완화 근거에서 제외합니다.',
        '- 최고수익 후 음전/큰 되돌림이 반복될 때만 보호익절·빠른실패 청산을 설계합니다.',
    ]
    return '\n'.join(lines)


def _v440_short_reasons(items: Any, limit: int = 3) -> str:
    if isinstance(items, list):
        arr = [str(x).strip() for x in items if str(x).strip()]
        return ' / '.join(arr[:limit]) if arr else '-'
    if isinstance(items, str) and items.strip():
        return items.strip()
    return '-'


def _v440_metric_from_reason(row: Dict[str, Any], metric: str, default: Any = None) -> Any:
    labels = {
        'spread_pct': ['스프레드'],
        'slippage_pct': ['미끄러짐', '슬리피지', '예상'],
        'price_reaction_pct': ['가격반응'],
        'buy_ratio': ['매수체결비'],
        'buy_sustain_1m': ['1분 매수지속'],
    }.get(metric, [])
    reasons: List[str] = []
    for src in (row.get('block_reasons'), row.get('s1_block_reasons_detail'), row.get('fail')):
        if isinstance(src, list): reasons += [str(x) for x in src]
    for reason in reasons:
        if any(lbl in reason for lbl in labels):
            m = re.search(r"([-+]?\d+(?:\.\d+)?)\s*%?\s*[><]", reason)
            if m:
                try: return float(m.group(1))
                except Exception: pass
    return default


def _v440_candidate_from_queue_or_row(row: Dict[str, Any]) -> Dict[str, Any]:
    m = row.get('metrics') if isinstance(row.get('metrics'), dict) else {}
    metrics = {
        'price_reaction_pct': m.get('price_reaction_pct'),
        'spread_pct': m.get('spread_pct'),
        'slippage_pct': m.get('slippage_pct'),
        'buy_ratio': m.get('buy_ratio'),
        'buy_sustain_1m': m.get('buy_sustain_1m'),
    }
    for k in list(metrics.keys()):
        rv = _v440_metric_from_reason(row, k, metrics.get(k))
        if rv is not None: metrics[k] = rv
    return {
        'ticker': str(row.get('ticker') or row.get('market') or row.get('symbol') or '-').replace('KRW-','').replace('_KRW',''),
        'stage': str(row.get('stage') or row.get('s_stage') or row.get('candidate_grade') or '-').upper(),
        'strategy': row.get('strategy') or row.get('strategy_label_easy') or row.get('strategy_key') or '-',
        'score': row.get('score') or row.get('s1_score') or row.get('trade_ready_score'),
        'block_reasons': row.get('block_reasons') or row.get('s1_block_reasons_detail') or row.get('fail') or [],
        'missing_info': row.get('missing_info') or row.get('s1_missing_info_detail') or row.get('missing') or [],
        'decision': row.get('decision') or row.get('review_decision') or row.get('review_decision_reason') or '-',
        'review_hint': row.get('review_hint') or row.get('review_class') or '',
        'metrics': metrics,
    }


def _v440_fallback_top_candidates(panel: Dict[str, Any]) -> List[Dict[str, Any]]:
    top = panel.get('top_candidates') if isinstance(panel.get('top_candidates'), list) else []
    if top:
        return [x for x in top if isinstance(x, dict)][:10]
    # 1순위: strategy가 review_worker로 넘긴 queue
    q = _v427_read_small(BASE_DIR / 'clean_missed_review_queue.json', {}) or {}
    qr = q.get('review_candidates') if isinstance(q, dict) and isinstance(q.get('review_candidates'), list) else []
    if qr:
        return [_v440_candidate_from_queue_or_row(x) for x in qr if isinstance(x, dict)][:10]
    # 2순위: 최신 후보파일. 생성/저장은 제한하지 않고 화면만 10개.
    rows = read_jsonl(FILES.get('paper_latest', BASE_DIR/'paper_candidates_latest.jsonl'), max_lines=300)
    rows = [r for r in rows if isinstance(r, dict)]
    def rank(r: Dict[str, Any]) -> tuple:
        st = str(r.get('s_stage') or r.get('stage') or '').upper()
        sr = {'S1': 3, 'S2': 2, 'S3': 1}.get(st, 0)
        return (sr, fnum(r.get('score'), r.get('s1_score'), r.get('trade_ready_score'), default=0.0), fnum(r.get('updated_ts'), r.get('ts'), r.get('created_at'), default=0.0))
    rows.sort(key=rank, reverse=True)
    return [_v440_candidate_from_queue_or_row(r) for r in rows[:10]]


def candidate_reason_text() -> str:  # type: ignore[override]
    strat = _v427_strategy_summary(); audit = _v427_read_small(BASE_DIR/'clean_strategy_s1_block_audit.json', {}) or {}
    panel = audit.get('s123_simple_panel') if isinstance(audit, dict) and isinstance(audit.get('s123_simple_panel'), dict) else _v436_simple_panel_from_strategy(strat)
    sc = panel.get('stage_counts') if isinstance(panel.get('stage_counts'), dict) else {}
    top = _v440_fallback_top_candidates(panel)
    def cand_lines(items: Any, limit: int = 10) -> List[str]:
        if not isinstance(items, list) or not items:
            return ['- 표시 후보 없음']
        out: List[str] = []
        for idx, c in enumerate([x for x in items if isinstance(x, dict)][:limit], 1):
            m = c.get('metrics') if isinstance(c.get('metrics'), dict) else {}
            out.append(f"{idx}) {str(c.get('ticker') or '-').replace('KRW-','').replace('_KRW','')} · {c.get('stage','-')} · {c.get('strategy','-')} · 점수 {_v440_num(c.get('score'))}")
            out.append(f"   막힘: {_v440_short_reasons(c.get('block_reasons'),3)} / 부족: {_v440_short_reasons(c.get('missing_info'),2)}")
            out.append(f"   수치: 반응 {_v440_num(m.get('price_reaction_pct'),'%')} · 스프 {_v440_num(m.get('spread_pct'),'%')} · 미끄 {_v440_num(m.get('slippage_pct'),'%')} · 매수 {_v440_num(m.get('buy_ratio'))} · 지속 {_v440_num(m.get('buy_sustain_1m'))} · 판정 {c.get('decision','-')}")
            if c.get('review_hint'):
                out.append(f"   재확인: {c.get('review_hint')}")
        return out
    return '\n'.join([
        '🧭 후보판정 이유 /candidate_reason · v440 cache-only',
        '- 기준: S1/S2/S3만 봅니다. 조건 수치는 바꾸지 않았습니다.',
        '- 후보 생성/저장은 제한하지 않고, 화면 표시만 좋은순 상위 10개입니다.',
        f"- 전체평가: {strat.get('evaluated','-') if isinstance(strat,dict) else '-'} / 후보파일 {strat.get('paper_latest_count','-') if isinstance(strat,dict) else '-'} / 고정 40개 제한 아님",
        f"- 현재 단계: S1 {_v427_int(sc.get('S1',0))} / S2 {_v427_int(sc.get('S2',0))} / S3 {_v427_int(sc.get('S3',0))}",
        f"- 판정: {panel.get('verdict','-')}",
        f"- S1 막힘 상위: {_v436_list_top(panel.get('reason_top'),5)}",
        f"- 부족정보 상위: {_v436_list_top(panel.get('missing_info_top'),5)}",
        f"- 복기판정 상위: {_v436_list_top(panel.get('decision_top'),5)}",
        '', '[상위 후보 10개 · 표시만 제한]', *cand_lines(top,10),
        '', '[다음 판단]',
        '- 진짜 놓친 후보가 반복되면 그 조건만 S1 문턱 조정 후보로 봅니다.',
        '- 결과만 오른 위험 후보는 조건 완화 근거에서 제외합니다.',
    ])


def version_score_text() -> str:  # type: ignore[override]
    cache = _v427_cache(); status = _v427_status(); byv = cache.get('version_summary') if isinstance(cache.get('version_summary'), dict) else {}; schema = cache.get('schema','-'); has = isinstance(byv, dict); keys = list(byv.keys()) if has else []
    recent = []
    if _CURRENT_MAIN_VER: recent.append(_CURRENT_MAIN_VER)
    for v in _V421_RECENT_VERSIONS:
        if v not in recent: recent.append(v)
    if has:
        for k in sorted(keys, reverse=True):
            if k not in recent and len(recent) < 3: recent.append(k)
    recent = recent[:3]
    lines = ['📊 버전별 성과 /version_score · v440 cache-only','- 기준: score cache의 version_summary만 읽습니다. CLOSED 전체 장부 직접조회는 하지 않습니다.','- 변경: 현재 실행판을 최근 적용판 요약에 우선 표시합니다.',f"- 메인봇: {BOT_VERSION} / {RESTORE_BUILD}",f"- paper: {status.get('version','-')} / status age {age(FILES.get('paper_status', BASE_DIR/'paper_bot_status.json')):.1f}s / CLOSED누적 {status.get('closed_total', status.get('closed_count','-'))}",f"- cache age {age(FILES.get('paper_score', BASE_DIR/'paper_bot_score_cache.json')):.1f}s / schema {schema} / version_summary {'있음' if has else '없음'}",'','[최근 적용판 요약 · cache]']
    if not has:
        lines.append('- ❌ score cache에 version_summary가 없습니다.')
        return '\n'.join(lines)
    for ver in recent: lines.append(_v427_stat_line(ver, byv.get(ver, {})))
    other = []
    for k,v in byv.items():
        if k not in set(recent):
            st = _v427_stat(v)
            if st['n']: other.append((k, st))
    if other:
        lines += ['', '[다른 버전 bucket · cache]']
        for k,st in sorted(other, key=lambda x:x[0], reverse=True)[:5]: lines.append(f"- {k}: {st['n']}전 {st['wins']}승 {st['losses']}패 / 합산 {st['total']:+.2f}%")
    if keys: lines.append(f"- cache keys: {', '.join(str(x) for x in list(keys)[:8])}")
    return '\n'.join(lines)


def batch_handler(update, context):  # type: ignore[override]
    cmds = getattr(context, 'args', None) or ['health','candidate_reason','review','version_score','popen','errorlog']
    cmds = [str(x).strip().lstrip('/') for x in cmds[:8] if str(x).strip()]
    st = time.time(); sent = 0; timings = []
    try: send(update, f"📦 자동 묶음 명령 접수\n- 실행 {len(cmds)}개\n- v440: 후보복기 정확도+청산복기 출력 cache-only")
    except Exception: pass
    for raw in cmds:
        name = raw.strip().lstrip('/'); fn = COMMANDS.get(name); sent += 1; t = time.time()
        if not fn:
            body = f"❌ /{name} 명령이 메인봇에 연결되지 않았습니다."; ok = 'ERR'
        else:
            try: body = fn(); ok = 'OK'
            except Exception as exc: body = f"❌ /{name} 오류 {exc.__class__.__name__}: {exc}"; ok = 'ERR'; log_error(f'batch_{name}', exc)
        sec = time.time() - t; timings.append(f"- {'✅' if ok=='OK' else '❌'} /{name}: {sec:.2f}s / {ok}"); send(update, f"[{sent}/{len(cmds)}] /{name} ({sec:.2f}s / {ok})\n{body}")
    send(update, "🧾 자동 묶음 시간표 · v440\n" + "\n".join(timings) + f"\n- 합계 {time.time()-st:.2f}s")

try:
    COMMANDS.update({'candidate_reason':candidate_reason_text,'reason':candidate_reason_text,'why_s1':candidate_reason_text,'review':review_text,'missed_review':review_text,'pmissed_review':review_text,'version_score':version_score_text,'vscore':version_score_text,'batch':lambda:'batch는 텔레그램 handler로 실행됩니다.'})
    log_runtime('v440_review_candidate_display_seal_loaded')
except Exception:
    pass



# =============================================================================
# v441: review/candidate output consistency seal
# - 조건/S1/S2/S3/청산숫자는 바꾸지 않는다.
# - candidate_reason raw dict 출력 제거.
# - review pending/section 분류 문구를 같은 기준으로 표시.
# - health/version/batch 구문구를 v441로 정리.
# =============================================================================
BOT_VERSION = "수익형 v2.13.399"
RESTORE_BUILD = "v441_v399_review_output_consistency_2026-05-25"
_CURRENT_MAIN_VER = "v2.13.399"
_V421_RECENT_VERSIONS = ["v2.13.399", "v2.13.398", "v2.13.397"]


def _v441_clean_text(x: Any) -> str:
    """raw dict/list reason을 사용자용 한글 한 줄로 변환."""
    try:
        if x is None:
            return ""
        if isinstance(x, dict):
            label = str(x.get('label') or x.get('reason') or x.get('key') or '').strip()
            value = str(x.get('value') or '').strip()
            why = str(x.get('why') or '').strip()
            if label and value:
                return f"{label} {value}"
            if label and why:
                return f"{label}: {why}"
            return label or value or why
        if isinstance(x, (list, tuple)):
            arr = [_v441_clean_text(v) for v in x]
            return ' / '.join([v for v in arr if v])
        txt = str(x).strip()
        if txt.startswith('{') and txt.endswith('}'):
            # 문자열로 저장된 dict 흔적은 그대로 노출하지 않고 핵심 label/value만 약식 추출
            lab = re.search(r"['\"]label['\"]\s*:\s*['\"]([^'\"]+)['\"]", txt)
            val = re.search(r"['\"]value['\"]\s*:\s*['\"]([^'\"]*)['\"]", txt)
            if lab:
                return (lab.group(1) + (f" {val.group(1)}" if val and val.group(1) else '')).strip()
        return txt
    except Exception:
        return str(x or '').strip()


def _v441_short_reasons(items: Any, limit: int = 3) -> str:
    if isinstance(items, list):
        arr = [_v441_clean_text(x) for x in items]
        arr = [x for x in arr if x]
        return ' / '.join(arr[:limit]) if arr else '-'
    txt = _v441_clean_text(items)
    return txt if txt else '-'


def _v441_review_label(row: Dict[str, Any], section: str = '') -> str:
    # summary의 섹션 기준을 우선한다. 구 review_class/review_hint가 남아도 그대로 보여주지 않는다.
    if section == 'missed': return '❌ 진짜 놓친 후보'
    if section == 'regret': return '⚠️ 아까운 후보'
    if section == 'risk_rise': return '🔥 결과만 오른 위험 후보'
    if section == 'correct': return '✅ 안 산 게 맞음'
    cls = str(row.get('review_class') or row.get('decision') or row.get('review_hint') or '').strip()
    if cls in ('❌ 진짜 놓친 후보','⚠️ 아까운 후보','🔥 결과만 오른 위험 후보','✅ 안 산 게 맞음','❔ 추적중'):
        return cls
    if '결과만' in cls or '위험' in cls: return '🔥 결과만 오른 위험 후보'
    if '아까' in cls: return '⚠️ 아까운 후보'
    if '진짜' in cls and '놓친' in cls: return '❌ 진짜 놓친 후보'
    if '안 산' in cls: return '✅ 안 산 게 맞음'
    return '❔ 추적중'


def _v441_review_item_lines(rows: Any, limit: int = 5, section: str = '') -> List[str]:
    if not isinstance(rows, list) or not rows:
        return ['- 없음']
    out: List[str] = []
    for i, r in enumerate([x for x in rows if isinstance(x, dict)][:limit], 1):
        label = _v441_review_label(r, section)
        out.append(f"{i}) {r.get('ticker','-')} · {r.get('stage','-')} · {r.get('strategy','-')} · 최고 {_v440_pct(r.get('max_pct'))} / 현재 {_v440_pct(r.get('current_pct'))}")
        out.append(f"   막힘: {_v441_short_reasons(r.get('reasons'), 3)}")
        risk = r.get('risk_note') or r.get('risk_reasons') or ''
        if risk:
            out.append(f"   위험판정: {_v441_short_reasons(risk, 4)}")
        out.append(f"   복기판정: {label}")
    return out


def review_text() -> str:  # type: ignore[override]
    s = _v427_read_small(MISSED_REVIEW_SUMMARY, {}) or {}
    if not isinstance(s, dict) or not s:
        return "🧾 놓친 후보·청산 자동복기 /review\n- 아직 review cache가 준비되지 않았습니다."
    age_sec = max(0.0, time.time() - float(s.get('updated_ts') or time.time()))
    cr = s.get('close_review') if isinstance(s.get('close_review'), dict) else {}
    lines = [
        '🧾 놓친 후보·청산 자동복기 /review · v441 cache-only',
        '- 기준: S2/S3 추적 + paper CLOSED 최고수익 대비 최종손익을 같이 봅니다.',
        '- 변경: 추적중/결과만 오른 위험 후보/진짜 놓친 후보 분류 문구를 같은 기준으로 표시합니다.',
        f"- cache age {age_sec:.1f}s / schema {s.get('schema','-')} / worker {s.get('version','-')}",
        f"- 추적 {s.get('tracking_total',0)}개 / queue {s.get('queue_candidates',0)}개",
        f"- ❌ 진짜 놓친 후보 {s.get('missed_count',0)} / ⚠️ 아까운 후보 {s.get('regret_count',0)} / 🔥 결과만 오른 위험 후보 {s.get('risk_rise_count',0)} / ✅ 안 산 게 맞음 {s.get('correct_count',0)} / ❔ 추적중 {s.get('pending_count',0)}",
        f"- 놓침·아까움 사유 TOP: {_v440_reason_top(s.get('missed_reason_top'))}",
        '', '[❌ 진짜 놓친 후보]', *_v441_review_item_lines(s.get('missed'), 5, 'missed'),
        '', '[⚠️ 아까운 후보]', *_v441_review_item_lines(s.get('regret'), 5, 'regret'),
        '', '[🔥 결과만 오른 위험 후보]', *_v441_review_item_lines(s.get('risk_rise'), 5, 'risk_rise'),
        '', '[❔ 추적중 상위]', *_v441_review_item_lines(s.get('pending'), 5, 'pending'),
        '', '[청산 복기 · 최고수익 대비 최종손익]',
        f"- 보호익절 필요 후보 {cr.get('protect_needed_count',0)} / 빠른실패 정리 후보 {cr.get('fast_fail_count',0)} / 수익 보존 양호 {cr.get('good_keep_count',0)}",
        '[보호익절 필요 후보]', *_v440_close_lines(cr.get('protect_needed'), 5),
        '[빠른실패 정리 후보]', *_v440_close_lines(cr.get('fast_fail'), 5),
        '', '[판정]',
        '- 진짜 놓친 후보가 반복될 때만 S1 문턱을 한 묶음으로 조정합니다.',
        '- 결과만 오른 위험 후보는 조건 완화 근거에서 제외합니다.',
        '- 보호익절/빠른실패 후보가 반복될 때만 청산 설계를 별도로 만집니다.',
    ]
    return '\n'.join(lines)


def candidate_reason_text() -> str:  # type: ignore[override]
    strat = _v427_strategy_summary(); audit = _v427_read_small(BASE_DIR/'clean_strategy_s1_block_audit.json', {}) or {}
    panel = audit.get('s123_simple_panel') if isinstance(audit, dict) and isinstance(audit.get('s123_simple_panel'), dict) else _v436_simple_panel_from_strategy(strat)
    sc = panel.get('stage_counts') if isinstance(panel.get('stage_counts'), dict) else {}
    top = _v440_fallback_top_candidates(panel)
    def cand_lines(items: Any, limit: int = 10) -> List[str]:
        if not isinstance(items, list) or not items:
            return ['- 표시 후보 없음']
        out: List[str] = []
        for idx, c in enumerate([x for x in items if isinstance(x, dict)][:limit], 1):
            m = c.get('metrics') if isinstance(c.get('metrics'), dict) else {}
            out.append(f"{idx}) {str(c.get('ticker') or '-').replace('KRW-','').replace('_KRW','')} · {c.get('stage','-')} · {c.get('strategy','-')} · 점수 {_v440_num(c.get('score'))}")
            out.append(f"   막힘: {_v441_short_reasons(c.get('block_reasons'),3)} / 부족: {_v441_short_reasons(c.get('missing_info'),2)}")
            out.append(f"   수치: 반응 {_v440_num(m.get('price_reaction_pct'),'%')} · 스프 {_v440_num(m.get('spread_pct'),'%')} · 미끄 {_v440_num(m.get('slippage_pct'),'%')} · 매수 {_v440_num(m.get('buy_ratio'))} · 지속 {_v440_num(m.get('buy_sustain_1m'))} · 판정 {_v441_clean_text(c.get('decision')) or '-'}")
            if c.get('review_hint'):
                out.append(f"   재확인: {_v441_clean_text(c.get('review_hint'))}")
        return out
    return '\n'.join([
        '🧭 후보판정 이유 /candidate_reason · v441 cache-only',
        '- 기준: S1/S2/S3만 봅니다. 조건 수치는 바꾸지 않았습니다.',
        '- 후보 생성/저장은 제한하지 않고, 화면 표시만 좋은순 상위 10개입니다.',
        f"- 전체평가: {strat.get('evaluated','-') if isinstance(strat,dict) else '-'} / 후보파일 {strat.get('paper_latest_count','-') if isinstance(strat,dict) else '-'} / 고정 40개 제한 아님",
        f"- 현재 단계: S1 {_v427_int(sc.get('S1',0))} / S2 {_v427_int(sc.get('S2',0))} / S3 {_v427_int(sc.get('S3',0))}",
        f"- 판정: {panel.get('verdict','-')}",
        f"- S1 막힘 상위: {_v436_list_top(panel.get('reason_top'),5)}",
        f"- 부족정보 상위: {_v436_list_top(panel.get('missing_info_top'),5)}",
        f"- 복기판정 상위: {_v436_list_top(panel.get('decision_top'),5)}",
        '', '[상위 후보 10개 · 표시만 제한]', *cand_lines(top,10),
        '', '[다음 판단]',
        '- 진짜 놓친 후보가 반복되면 그 조건만 S1 문턱 조정 후보로 봅니다.',
        '- 결과만 오른 위험 후보는 조건 완화 근거에서 제외합니다.',
    ])


def health_text() -> str:  # type: ignore[override]
    res = resource_snapshot(); paper = _v427_status(); trace = _v427_trace(); strat = _v427_strategy_summary(); router = _v427_router(); oflow = _v427_read_small(FILES.get('orderflow', BASE_DIR / 'clean_orderflow_summary_cache.json'), {}) or {}
    p_age = age(FILES.get('paper_status', BASE_DIR / 'paper_bot_status.json')); t_age = age(FILES.get('candidate_handoff_trace', BASE_DIR / 'paper_bot_candidate_handoff_trace.json'))
    pver = paper.get('version', '-') if isinstance(paper, dict) else '-'; tver = trace.get('version', trace.get('trace_version', '-')) if isinstance(trace, dict) else '-'
    sc = strat.get('s_stage_counts') if isinstance(strat.get('s_stage_counts'), dict) else {}
    lines_worker = [_v427_worker_line(k) for k in WORKERS]; good = sum(1 for x in lines_worker if x.startswith('- ✅'))
    evaluated = _v427_int(strat.get('evaluated', 0)) if isinstance(strat, dict) else 0
    qready = _v427_int(strat.get('quote_ready_count', 0)) if isinstance(strat, dict) else 0
    mready = _v427_int(strat.get('micro_ready_count', 0)) if isinstance(strat, dict) else 0
    full = _v427_int(strat.get('full_info_ready_count', 0)) if isinstance(strat, dict) else 0
    verdict = '정상' if p_age < 90 and t_age < 120 else '확인필요'
    panel = _v436_simple_panel_from_strategy(strat) if isinstance(strat, dict) else {}
    return '\n'.join([
        '🧭 건강상태 /health · v441 cache-only',
        f"⚠️ 전체판독: worker {good}/9 정상 · paper/trace {verdict} · 자원 {'주의' if fnum(res.get('disk_used_pct'),0) >= 85 or fnum(res.get('mem_used_pct'),0) >= 80 else '정상'}",
        f"- 메인봇 {BOT_VERSION} / {RESTORE_BUILD} / uptime {int(now_ts()-START_TS)}s",
        f"- 정보: 평가 {evaluated or '-'} / 시세 {qready}/{evaluated or '-'} / micro {mready}/{evaluated or '-'} / 둘다 {full}/{evaluated or '-'}",
        f"- 후보 생애주기: S1 {_v427_int(sc.get('S1',0))} / S2 {_v427_int(sc.get('S2',0))} / S3 {_v427_int(sc.get('S3',0))}",
        f"- 후보파일: active latest {strat.get('paper_latest_count','-') if isinstance(strat,dict) else '-'}개 / 고정 40개 제한 아님 / 전체평가 {evaluated or '-'}개",
        f"- S1 판정: {panel.get('verdict','-')}",
        f"- S1 막힘 상위: {_v436_list_top(panel.get('reason_top'), 3)}",
        f"- paper: {pver} / trace {tver} / status age {p_age:.1f}s / trace age {t_age:.1f}s / OPEN {paper.get('open_count', paper.get('open_total','-')) if isinstance(paper,dict) else '-'} / CLOSED누적 {paper.get('closed_total', paper.get('closed_count','-')) if isinstance(paper,dict) else '-'}",
        f"- 현재 paper 상태: {'OPEN 없음' if isinstance(paper,dict) and _v427_int(paper.get('open_count', paper.get('open_total',0))) == 0 else 'OPEN 진행 중'}",
        f"- 배차: 전체 {router.get('queue_count','-') if isinstance(router,dict) else '-'} → 내보냄 {router.get('export_count', router.get('active_target_count','-')) if isinstance(router,dict) else '-'} / micro fresh {oflow.get('fresh_micro','-') if isinstance(oflow,dict) else '-'}",
        f"- 자원: 디스크 {res.get('disk_used_pct','-')}% / 남음 {res.get('disk_free_gb','-')}GB / 메모리 {res.get('mem_used_pct','-')}% / load {res.get('load','-')}",
        '', '[worker 요약 · 캐시만]', *lines_worker,
        '', '[고정]', '- 메인봇은 장부 정리/압축/삭제를 하지 않습니다. 정리는 가드봇 /gcleanup 담당입니다.', '- 기본 명령은 CLOSED 전체장부 직접조회로 돌아가지 않습니다.'
    ])


def version_score_text() -> str:  # type: ignore[override]
    cache = _v427_cache(); status = _v427_status(); byv = cache.get('version_summary') if isinstance(cache.get('version_summary'), dict) else {}; schema = cache.get('schema','-'); has = isinstance(byv, dict); keys = list(byv.keys()) if has else []
    recent = []
    if _CURRENT_MAIN_VER: recent.append(_CURRENT_MAIN_VER)
    for v in _V421_RECENT_VERSIONS:
        if v not in recent: recent.append(v)
    if has:
        for k in sorted(keys, reverse=True):
            if k not in recent and len(recent) < 3: recent.append(k)
    recent = recent[:3]
    lines = ['📊 버전별 성과 /version_score · v441 cache-only','- 기준: score cache의 version_summary만 읽습니다. CLOSED 전체 장부 직접조회는 하지 않습니다.','- 변경: 현재 실행판을 최근 적용판 요약에 우선 표시합니다.',f"- 메인봇: {BOT_VERSION} / {RESTORE_BUILD}",f"- paper: {status.get('version','-')} / status age {age(FILES.get('paper_status', BASE_DIR/'paper_bot_status.json')):.1f}s / CLOSED누적 {status.get('closed_total', status.get('closed_count','-'))}",f"- cache age {age(FILES.get('paper_score', BASE_DIR/'paper_bot_score_cache.json')):.1f}s / schema {schema} / version_summary {'있음' if has else '없음'}",'','[최근 적용판 요약 · cache]']
    if not has:
        lines.append('- ❌ score cache에 version_summary가 없습니다.'); return '\n'.join(lines)
    for ver in recent: lines.append(_v427_stat_line(ver, byv.get(ver, {})))
    other = []
    for k,v in byv.items():
        if k not in set(recent):
            st = _v427_stat(v)
            if st['n']: other.append((k, st))
    if other:
        lines += ['', '[다른 버전 bucket · cache]']
        for k,st in sorted(other, key=lambda x:x[0], reverse=True)[:5]: lines.append(f"- {k}: {st['n']}전 {st['wins']}승 {st['losses']}패 / 합산 {st['total']:+.2f}%")
    if keys: lines.append(f"- cache keys: {', '.join(str(x) for x in list(keys)[:8])}")
    return '\n'.join(lines)


def batch_handler(update, context):  # type: ignore[override]
    cmds = getattr(context, 'args', None) or ['health','candidate_reason','review','version_score','popen','errorlog']
    cmds = [str(x).strip().lstrip('/') for x in cmds[:8] if str(x).strip()]
    st = time.time(); sent = 0; timings = []
    try: send(update, f"📦 자동 묶음 명령 접수\n- 실행 {len(cmds)}개\n- v441: 복기판 출력모순 제거 cache-only")
    except Exception: pass
    for raw in cmds:
        name = raw.strip().lstrip('/'); fn = COMMANDS.get(name); sent += 1; t = time.time()
        if not fn:
            body = f"❌ /{name} 명령이 메인봇에 연결되지 않았습니다."; ok = 'ERR'
        else:
            try: body = fn(); ok = 'OK'
            except Exception as exc: body = f"❌ /{name} 오류 {exc.__class__.__name__}: {exc}"; ok = 'ERR'; log_error(f'batch_{name}', exc)
        sec = time.time() - t; timings.append(f"- {'✅' if ok=='OK' else '❌'} /{name}: {sec:.2f}s / {ok}"); send(update, f"[{sent}/{len(cmds)}] /{name} ({sec:.2f}s / {ok})\n{body}")
    send(update, "🧾 자동 묶음 시간표 · v441\n" + "\n".join(timings) + f"\n- 합계 {time.time()-st:.2f}s")

try:
    COMMANDS.update({'candidate_reason':candidate_reason_text,'reason':candidate_reason_text,'why_s1':candidate_reason_text,'review':review_text,'missed_review':review_text,'pmissed_review':review_text,'version_score':version_score_text,'vscore':version_score_text,'batch':lambda:'batch는 텔레그램 handler로 실행됩니다.'})
    log_runtime('v441_review_output_consistency_loaded')
except Exception:
    pass


# =============================================================================
# v444: candidate/review display consistency seal
# - 후보판정 출력은 active paper_latest 한 기준으로 집계/목록을 맞춘다.
# - 수치/막힘 값이 없는 후보는 정상 후보처럼 숨기지 않고 표시값 누락으로 표시한다.
# - /review_full_full 중복 제목과 잘못된 full 안내 문구를 제거한다.
# - 전략/S1/S2/S3/청산 기준은 변경하지 않는다.
# =============================================================================
BOT_VERSION = "수익형 v2.13.405"
RESTORE_BUILD = "v448_v405_candidate_fast_regime_close_display_2026-05-25"
_CURRENT_MAIN_VER = "v2.13.405"
_V421_RECENT_VERSIONS = ["v2.13.405", "v2.13.404", "v2.13.403"]

_v444_prev_health_text = health_text
_v444_prev_version_score_text = version_score_text


def _v444_pick(*vals: Any) -> Any:
    for v in vals:
        if v is not None and v != "":
            return v
    return None


def _v444_stage(row: Dict[str, Any]) -> str:
    st = str(_v444_pick(row.get('s_stage'), row.get('stage'), row.get('candidate_grade'), row.get('grade'), '') or '').upper().strip()
    return st if st else '-'


def _v444_active_candidate_rows(max_lines: int = 800) -> List[Dict[str, Any]]:
    rows = read_jsonl(FILES.get('paper_latest', BASE_DIR / 'paper_candidates_latest.jsonl'), max_lines=max_lines)
    return [r for r in rows if isinstance(r, dict)]


def _v444_score(row: Dict[str, Any]) -> float:
    return fnum(row.get('score'), row.get('s1_score'), row.get('trade_ready_score'), default=0.0)


def _v444_ts(row: Dict[str, Any]) -> float:
    return fnum(row.get('updated_ts'), row.get('ts'), row.get('created_at'), row.get('created_ts'), default=0.0)


def _v444_rank(row: Dict[str, Any]) -> tuple:
    return ({'S1': 3, 'S2': 2, 'S3': 1}.get(_v444_stage(row), 0), _v444_score(row), _v444_ts(row))


def _v444_stage_counts(rows: List[Dict[str, Any]]) -> Dict[str, int]:
    out = {'S1': 0, 'S2': 0, 'S3': 0}
    for r in rows:
        st = _v444_stage(r)
        if st in out:
            out[st] += 1
    return out


def _v444_metric(row: Dict[str, Any], key: str) -> Any:
    m = row.get('metrics') if isinstance(row.get('metrics'), dict) else {}
    aliases = {
        'price_reaction_pct': ('price_reaction_pct', 'reaction_pct', 'reaction_30s_pct', 'entry_reaction_pct', 'price_reaction'),
        'spread_pct': ('spread_pct', 'orderbook_spread_pct', 'ask_bid_spread_pct', 'spread'),
        'slippage_pct': ('slippage_pct', 'expected_slippage_pct', 'slip_pct', 'expected_slip_pct'),
        'buy_ratio': ('buy_ratio', 'buy_trade_ratio', 'bid_trade_ratio', 'buying_ratio'),
        'buy_sustain_1m': ('buy_sustain_1m', 'buy_sustain', 'buy_sustain_ratio', 'buy_sustain_60s'),
    }.get(key, (key,))
    for a in aliases:
        v = _v444_pick(m.get(a) if isinstance(m, dict) else None, row.get(a))
        if v is not None:
            return v
    return _v440_metric_from_reason(row, key, None)


def _v444_reasons(row: Dict[str, Any]) -> Any:
    return _v444_pick(row.get('block_reasons'), row.get('s1_block_reasons_detail'), row.get('block_reason'), row.get('fail'), row.get('reasons'), []) or []


def _v444_missing(row: Dict[str, Any]) -> Any:
    return _v444_pick(row.get('missing_info'), row.get('s1_missing_info_detail'), row.get('missing'), []) or []


def _v445_structure_info(row: Dict[str, Any]) -> Dict[str, Any]:
    ctx = row.get('entry_context') if isinstance(row.get('entry_context'), dict) else {}
    st = _v444_pick(row.get('chart_structure'), ctx.get('chart_structure'), {}) or {}
    tags = _v444_pick(row.get('structure_tags'), ctx.get('structure_tags'), st.get('tags') if isinstance(st, dict) else [], []) or []
    risk = _v444_pick(row.get('structure_risk_tags'), ctx.get('structure_risk_tags'), st.get('risk_tags') if isinstance(st, dict) else [], []) or []
    fit = _v444_pick(row.get('structure_fit'), ctx.get('structure_fit'), st.get('strategy_fit') if isinstance(st, dict) else '', '') or ''
    summary = _v444_pick(row.get('structure_summary'), ctx.get('structure_summary'), st.get('summary') if isinstance(st, dict) else '', '') or ''
    return {'tags': tags if isinstance(tags, list) else [], 'risk_tags': risk if isinstance(risk, list) else [], 'fit': str(fit), 'summary': str(summary)}



def _v447_market_info(row: Dict[str, Any]) -> Dict[str, Any]:
    ctx = row.get('entry_context') if isinstance(row.get('entry_context'), dict) else {}
    mr = _v444_pick(row.get('market_regime'), ctx.get('market_regime'), {}) or {}
    tags = _v444_pick(row.get('market_regime_tags'), ctx.get('market_regime_tags'), mr.get('tags') if isinstance(mr, dict) else [], []) or []
    risk = _v444_pick(row.get('market_risk_tags'), ctx.get('market_risk_tags'), mr.get('risk_tags') if isinstance(mr, dict) else [], []) or []
    summary = _v444_pick(row.get('market_regime_summary'), ctx.get('market_regime_summary'), mr.get('summary') if isinstance(mr, dict) else '', '') or ''
    return {'tags': tags if isinstance(tags, list) else [], 'risk_tags': risk if isinstance(risk, list) else [], 'summary': str(summary)}

def _v447_fit_label(fit: Any, risks: Any=None) -> str:
    f = str(fit or '').strip()
    rlist = risks if isinstance(risks, list) else []
    severe = any(str(x) in {'스프레드부담','미끄러짐부담','매도압력부담','되돌림위험','매수체결약함','가짜돌파위험','고점유동성쓸림','돌파후재이탈','채널하단이탈','추세끝물','시장급락위험','시장과열'} for x in rlist)
    if not f or f in {'보통', '-'}:
        return '구조관찰'
    if '위험동반' in f or '위험확인' in f:
        return '구조좋음 · 위험동반' if severe else '구조관찰'
    if '구조좋음' in f and severe:
        return '구조좋음 · 위험동반'
    return f.replace('구조좋음+위험확인','구조좋음 · 위험동반')

def _v445_short_tags(items: Any, limit: int = 4) -> str:
    if not isinstance(items, list) or not items:
        return '-'
    out=[]
    for x in items:
        t=str(x).strip()
        if t and t not in out:
            out.append(t)
        if len(out) >= limit:
            break
    return ', '.join(out) if out else '-'


def _v444_candidate_from_row(row: Dict[str, Any]) -> Dict[str, Any]:
    metrics = {
        'price_reaction_pct': _v444_metric(row, 'price_reaction_pct'),
        'spread_pct': _v444_metric(row, 'spread_pct'),
        'slippage_pct': _v444_metric(row, 'slippage_pct'),
        'buy_ratio': _v444_metric(row, 'buy_ratio'),
        'buy_sustain_1m': _v444_metric(row, 'buy_sustain_1m'),
    }
    structure = _v445_structure_info(row)
    return {
        'ticker': str(_v444_pick(row.get('ticker'), row.get('market'), row.get('symbol'), '-') or '-').replace('KRW-', '').replace('_KRW', ''),
        'stage': _v444_stage(row),
        'strategy': _v444_pick(row.get('strategy_label_easy'), row.get('strategy'), row.get('strategy_key'), '-') or '-',
        'score': _v444_pick(row.get('score'), row.get('s1_score'), row.get('trade_ready_score')),
        'block_reasons': _v444_reasons(row),
        'missing_info': _v444_missing(row),
        'decision': _v444_pick(row.get('decision'), row.get('review_decision'), row.get('review_class'), row.get('review_decision_reason'), '-'),
        'review_hint': _v444_pick(row.get('review_hint'), row.get('review_class'), ''),
        'structure_tags': structure.get('tags', []),
        'structure_risk_tags': structure.get('risk_tags', []),
        'structure_fit': structure.get('fit', ''),
        'structure_summary': structure.get('summary', ''),
        'market_regime_tags': _v447_market_info(row).get('tags', []),
        'market_risk_tags': _v447_market_info(row).get('risk_tags', []),
        'market_regime_summary': _v447_market_info(row).get('summary', ''),
        'metrics': metrics,
    }


def _v444_has_display_values(c: Dict[str, Any]) -> bool:
    m = c.get('metrics') if isinstance(c.get('metrics'), dict) else {}
    has_metric = any(v is not None and v != '' for v in m.values())
    has_reason = _v441_short_reasons(c.get('block_reasons'), 1) != '-'
    return has_metric or has_reason


def _v444_collect_candidate_items(limit: int = 30) -> tuple[List[Dict[str, Any]], List[Dict[str, Any]]]:
    rows = _v444_active_candidate_rows()
    rows.sort(key=_v444_rank, reverse=True)
    return [_v444_candidate_from_row(r) for r in rows[:limit]], rows


def _v444_missing_display_count(items: List[Dict[str, Any]]) -> int:
    return sum(1 for c in items if isinstance(c, dict) and not _v444_has_display_values(c))


def _v447_structure_line(c: Dict[str, Any], tag_limit: int = 3, risk_limit: int = 2) -> str:
    tags = _v445_short_tags(c.get('structure_tags'), tag_limit)
    risks = _v445_short_tags(c.get('structure_risk_tags'), risk_limit)
    fit = _v447_fit_label(c.get('structure_fit'), c.get('structure_risk_tags'))
    if tags == '-' and risks == '-' and fit == '구조관찰':
        return ''
    return f"   구조: {fit} · 태그 {tags} · 위험 {risks}"

def _v448_market_parts(tags: Any, risks: Any=None) -> str:
    if not isinstance(tags, list):
        tags = []
    if not isinstance(risks, list):
        risks = []
    strength = '-'
    flow = '-'
    money = '-'
    vol = '-'
    for raw in tags:
        t = str(raw).strip()
        if t in {'시장강함','시장보통','시장약함'}:
            strength = t.replace('시장','')
        elif t in {'시장횡보','시장과열','시장급락위험'}:
            flow = t.replace('시장','')
        elif t in {'전체거래대금증가','소수코인쏠림','거래대금분산','대형코인주도','잡코인순환'}:
            money = {'전체거래대금증가':'거래대금증가','소수코인쏠림':'소수쏠림'}.get(t, t)
        elif t in {'변동성확대','변동성축소','급등락장','잔잔한장'}:
            vol = t
    parts = []
    if strength != '-': parts.append(f"강도 {strength}")
    if flow != '-': parts.append(f"흐름 {flow}")
    if money != '-': parts.append(f"자금 {money}")
    if vol != '-': parts.append(vol)
    risk_txt = _v445_short_tags(risks, 2)
    base = ' · '.join(parts) if parts else '-'
    if risk_txt != '-':
        base += f" · 위험 {risk_txt}"
    return base

def _v447_market_line(c: Dict[str, Any], tag_limit: int = 2, risk_limit: int = 1) -> str:
    txt = _v448_market_parts(c.get('market_regime_tags'), c.get('market_risk_tags'))
    if txt == '-':
        return ''
    return f"   장세: {txt}"

def _v447_candidate_lines_compact(items: Any, limit: int = 5) -> List[str]:
    if not isinstance(items, list) or not items:
        return ['- 표시 후보 없음']
    out: List[str] = []
    for idx, c in enumerate([x for x in items if isinstance(x, dict)][:limit], 1):
        m = c.get('metrics') if isinstance(c.get('metrics'), dict) else {}
        out.append(f"{idx}) {str(c.get('ticker') or '-').replace('KRW-','').replace('_KRW','')} · {c.get('stage','-')} · {c.get('strategy','-')} · 점수 {_v440_num(c.get('score'))}")
        if not _v444_has_display_values(c):
            out.append("   표시: ⚠️ 후보파일에는 있으나 막힘/수치 표시값 없음")
        else:
            out.append(f"   막힘: {_v441_short_reasons(c.get('block_reasons'),2)} / 부족: {_v441_short_reasons(c.get('missing_info'),1)}")
            out.append(f"   수치: 반응 {_v440_num(m.get('price_reaction_pct'),'%')} · 스프 {_v440_num(m.get('spread_pct'),'%')} · 매수 {_v440_num(m.get('buy_ratio'))}")
        sl = _v447_structure_line(c, 3, 2)
        if sl: out.append(sl)
        ml = _v447_market_line(c, 2, 1)
        if ml: out.append(ml)
    return out

def _v444_candidate_lines(items: Any, limit: int = 30) -> List[str]:
    if not isinstance(items, list) or not items:
        return ['- 표시 후보 없음']
    out: List[str] = []
    for idx, c in enumerate([x for x in items if isinstance(x, dict)][:limit], 1):
        m = c.get('metrics') if isinstance(c.get('metrics'), dict) else {}
        out.append(f"{idx}) {str(c.get('ticker') or '-').replace('KRW-','').replace('_KRW','')} · {c.get('stage','-')} · {c.get('strategy','-')} · 점수 {_v440_num(c.get('score'))}")
        if not _v444_has_display_values(c):
            out.append("   표시: ⚠️ 후보파일에는 있으나 막힘/수치 표시값 없음(row schema 확인 필요)")
        else:
            out.append(f"   막힘: {_v441_short_reasons(c.get('block_reasons'),4)} / 부족: {_v441_short_reasons(c.get('missing_info'),3)}")
            out.append(f"   수치: 반응 {_v440_num(m.get('price_reaction_pct'),'%')} · 스프 {_v440_num(m.get('spread_pct'),'%')} · 미끄 {_v440_num(m.get('slippage_pct'),'%')} · 매수 {_v440_num(m.get('buy_ratio'))} · 지속 {_v440_num(m.get('buy_sustain_1m'))} · 판정 {_v441_clean_text(c.get('decision')) or '-'}")
        sl = _v447_structure_line(c, 4, 3)
        if sl: out.append(sl)
        ml = _v447_market_line(c, 3, 2)
        if ml: out.append(ml)
        if c.get('review_hint'):
            out.append(f"   재확인: {_v441_clean_text(c.get('review_hint'))}")
    return out


def _v444_panel() -> Dict[str, Any]:
    strat = _v427_strategy_summary()
    audit = _v427_read_small(BASE_DIR / 'clean_strategy_s1_block_audit.json', {}) or {}
    if isinstance(audit, dict) and isinstance(audit.get('s123_simple_panel'), dict):
        return audit.get('s123_simple_panel') or {}
    return _v436_simple_panel_from_strategy(strat if isinstance(strat, dict) else {})


def candidate_reason_full_text() -> str:
    strat = _v427_strategy_summary(); panel = _v444_panel(); items, rows = _v444_collect_candidate_items(30)
    sc = _v444_stage_counts(rows); missing_display = _v444_missing_display_count(items)
    lines = [
        '🧭 후보판정 이유 /candidate_reason_full · v448 상세',
        '- 기준: active 후보파일 한 기준 + 구조/장세태그 표시 전용입니다.',
        f"- 전체평가: {strat.get('evaluated','-') if isinstance(strat,dict) else '-'} / 후보파일 {len(rows)} / 고정 40개 제한 아님",
        f"- 현재 단계: S1 {sc.get('S1',0)} / S2 {sc.get('S2',0)} / S3 {sc.get('S3',0)}",
        f"- 표시값 누락: {missing_display}개" + (" / 후보파일 row에 metrics·reasons가 비어 있음" if missing_display else ""),
        f"- S1 막힘 상위: {_v436_list_top(panel.get('reason_top'),10)}",
        f"- 부족정보 상위: {_v436_list_top(panel.get('missing_info_top'),10)}",
        f"- 복기판정 상위: {_v436_list_top(panel.get('decision_top'),10)}",
        '', '[상위 후보 상세 · 표시만 제한]', *_v444_candidate_lines(items, 30),
        '', '[안내]', '- 표시값 누락은 조건 문제가 아니라 후보파일 schema/저장값 확인 대상입니다.'
    ]
    return '\n'.join(lines)


def candidate_reason_text() -> str:  # type: ignore[override]
    strat = _v427_strategy_summary(); panel = _v444_panel(); items, rows = _v444_collect_candidate_items(5)
    sc = _v444_stage_counts(rows); missing_display = _v444_missing_display_count(items)
    return '\n'.join([
        '🧭 후보판정 이유 /candidate_reason · v448 요약',
        '- 기본판은 TOP 5만 표시합니다. 전체 상세는 /candidate_reason_full',
        f"- 전체평가: {strat.get('evaluated','-') if isinstance(strat,dict) else '-'} / 후보파일 {len(rows)} / 고정 40개 제한 아님",
        f"- 현재 단계: S1 {sc.get('S1',0)} / S2 {sc.get('S2',0)} / S3 {sc.get('S3',0)}",
        f"- S1 막힘 상위: {_v436_list_top(panel.get('reason_top'),3)}",
        f"- 부족정보 상위: {_v436_list_top(panel.get('missing_info_top'),3)}",
        f"- 표시값 누락: {missing_display}개" + (" / schema 확인 필요" if missing_display else ""),
        '', '[상위 후보 5개 · 요약]', *_v447_candidate_lines_compact(items, 5),
        '', '[상세]', '- 전체 후보 상세는 /candidate_reason_full'
    ])


def _v444_review_lines(rows: Any, limit: int = 5, section: str = '') -> List[str]:
    if not isinstance(rows, list) or not rows:
        return ['- 없음']
    out: List[str] = []
    for i, r in enumerate([x for x in rows if isinstance(x, dict)][:limit], 1):
        label = _v441_review_label(r, section)
        out.append(f"{i}) {r.get('ticker','-')} · {r.get('stage','-')} · {r.get('strategy','-')} · 최고 {_v440_pct(r.get('max_pct'))} / 현재 {_v440_pct(r.get('current_pct'))} · {label}")
        out.append(f"   막힘: {_v441_short_reasons(r.get('reasons'), 3)}")
        risk = r.get('risk_note') or r.get('risk_reasons') or ''
        if risk:
            out.append(f"   위험: {_v441_short_reasons(risk, 2)}")
        tags = _v445_short_tags(r.get('structure_tags'), 3)
        risks = _v445_short_tags(r.get('structure_risk_tags'), 2)
        fit = str(r.get('structure_fit') or '').strip()
        if tags != '-' or risks != '-' or fit:
            out.append(f"   구조: {_v447_fit_label(fit, r.get('structure_risk_tags'))} · 태그 {tags} · 위험 {risks}")
        mtxt = _v448_market_parts(r.get('market_regime_tags'), r.get('market_risk_tags'))
        if mtxt != '-':
            out.append(f"   장세: {mtxt}")
    return out


def _v444_close_lines(items: Any, limit: int = 3) -> List[str]:
    if not isinstance(items, list) or not items:
        return ['- 없음']
    out: List[str] = []
    for i, r in enumerate([x for x in items if isinstance(x, dict)][:limit], 1):
        out.append(f"{i}) {r.get('ticker','-')} · 최고 {_v440_pct(r.get('peak_pct'))} → 최종 {_v440_pct(r.get('pnl_pct'))} / 놓친 {_v440_pct(r.get('giveback_pct'))}")
        out.append(f"   이유: {r.get('reason','-')} / {r.get('tag','-')}")
        tags = _v445_short_tags(r.get('structure_tags'), 3); risks = _v445_short_tags(r.get('structure_risk_tags'), 2); fit = str(r.get('structure_fit') or '').strip()
        if tags != '-' or risks != '-' or fit:
            out.append(f"   진입구조: {_v447_fit_label(fit, r.get('structure_risk_tags'))} · 태그 {tags} · 위험 {risks}")
        mtxt = _v448_market_parts(r.get('market_regime_tags'), r.get('market_risk_tags'))
        if mtxt != '-':
            out.append(f"   진입장세: {mtxt}")
    return out


def review_text() -> str:  # type: ignore[override]
    s = _v427_read_small(MISSED_REVIEW_SUMMARY, {}) or {}
    if not isinstance(s, dict) or not s:
        return "🧾 놓친 후보·청산 자동복기 /review\n- 아직 review cache가 준비되지 않았습니다."
    age_sec = max(0.0, time.time() - float(s.get('updated_ts') or time.time()))
    cr = s.get('close_review') if isinstance(s.get('close_review'), dict) else {}
    lines = [
        '🧾 놓친 후보·청산 자동복기 /review · v448 요약',
        '- 기본판은 TOP 3만 표시합니다. 상세는 /review_full',
        f"- cache age {age_sec:.1f}s / schema {s.get('schema','-')} / worker {s.get('version','-')}",
        f"- 추적 {s.get('tracking_total',0)} / queue {s.get('queue_candidates',0)}",
        f"- ❌진짜놓침 {s.get('missed_count',0)} / ⚠️아까움 {s.get('regret_count',0)} / 🔥위험상승 {s.get('risk_rise_count',0)} / ✅안산게맞음 {s.get('correct_count',0)} / ❔추적중 {s.get('pending_count',0)}",
        f"- 놓침·아까움 사유 TOP: {_v440_reason_top(s.get('missed_reason_top'))}",
        '', '[❌ 진짜 놓친 TOP 3]', *_v444_review_lines(s.get('missed'), 3, 'missed'),
        '', '[⚠️ 아까운 TOP 3]', *_v444_review_lines(s.get('regret'), 3, 'regret'),
        '', '[🔥 위험상승 TOP 3]', *_v444_review_lines(s.get('risk_rise'), 3, 'risk_rise'),
        '', '[청산 복기 요약]',
        f"- 보호익절 필요 {cr.get('protect_needed_count',0)} / 빠른실패 {cr.get('fast_fail_count',0)} / 수익보존 양호 {cr.get('good_keep_count',0)}",
    ]
    return '\n'.join(lines)


def review_full_text() -> str:
    s = _v427_read_small(MISSED_REVIEW_SUMMARY, {}) or {}
    if not isinstance(s, dict) or not s:
        return "🧾 놓친 후보·청산 자동복기 /review_full\n- 아직 review cache가 준비되지 않았습니다."
    age_sec = max(0.0, time.time() - float(s.get('updated_ts') or time.time()))
    cr = s.get('close_review') if isinstance(s.get('close_review'), dict) else {}
    lines = [
        '🧾 놓친 후보·청산 자동복기 /review_full · v448 상세',
        f"- cache age {age_sec:.1f}s / schema {s.get('schema','-')} / worker {s.get('version','-')}",
        f"- ❌진짜놓침 {s.get('missed_count',0)} / ⚠️아까움 {s.get('regret_count',0)} / 🔥위험상승 {s.get('risk_rise_count',0)} / ✅안산게맞음 {s.get('correct_count',0)} / ❔추적중 {s.get('pending_count',0)}",
        f"- 놓침·아까움 사유 TOP: {_v440_reason_top(s.get('missed_reason_top'))}",
        '', '[청산 복기 · 구조/장세 우선표시]',
        f"- 보호익절 필요 {cr.get('protect_needed_count',0)} / 빠른실패 {cr.get('fast_fail_count',0)} / 수익보존 양호 {cr.get('good_keep_count',0)}",
        '[보호익절 필요 TOP 3]', *_v444_close_lines(cr.get('protect_needed'), 3),
        '[빠른실패 TOP 3]', *_v444_close_lines(cr.get('fast_fail'), 3),
        '', '[❌ 진짜 놓친 후보]', *_v444_review_lines(s.get('missed'), 5, 'missed'),
        '', '[⚠️ 아까운 후보]', *_v444_review_lines(s.get('regret'), 2, 'regret'),
        '', '[🔥 결과만 오른 위험 후보]', *_v444_review_lines(s.get('risk_rise'), 3, 'risk_rise'),
        '', '[판정]',
        '- 진짜 놓친 후보가 반복될 때만 S1 문턱 검토.',
        '- 위험상승 후보는 조건 완화 근거에서 제외.',
    ]
    return '\n'.join(lines)


def health_text() -> str:  # type: ignore[override]
    body = _v444_prev_health_text()
    for old in ('/health · v438 cache-only', '/health · v441 cache-only', '/health · v443 cache-only', '/health · v444 cache-only', '/health · v445 cache-only', '/health · v446 cache-only', '/health · v447 cache-only'):
        body = body.replace(old, '/health · v448 cache-only')
    return body


def health_full_text() -> str:
    return health_text() + '\n\n[상세]\n- worker 상세는 가드봇 /gworker_state 또는 /gexternal_state에서 확인합니다.'


def version_score_text() -> str:  # type: ignore[override]
    body = _v444_prev_version_score_text()
    for old in ('/version_score · v440 cache-only', '/version_score · v441 cache-only', '/version_score · v443 cache-only', '/version_score · v444 cache-only', '/version_score · v446 cache-only', '/version_score · v447 cache-only'):
        body = body.replace(old, '/version_score · v448 cache-only')
    return body


def errorlog_full_text() -> str:
    return errorlog_text()


def batch_handler(update, context):  # type: ignore[override]
    cmds = getattr(context, 'args', None) or ['health','candidate_reason','review','version_score','popen','errorlog']
    cmds = [str(x).strip().lstrip('/') for x in cmds[:8] if str(x).strip()]
    st = time.time(); sent = 0; timings = []
    try: send(update, f"📦 자동 묶음 명령 접수\n- 실행 {len(cmds)}개\n- v448: candidate_reason TOP5 경량화 + 장세표현/청산복기 위치 정리")
    except Exception: pass
    for raw in cmds:
        name = raw.strip().lstrip('/'); fn = COMMANDS.get(name); sent += 1; t = time.time()
        if not fn:
            body = f"❌ /{name} 명령이 메인봇에 연결되지 않았습니다."; ok = 'ERR'
        else:
            try: body = fn(); ok = 'OK'
            except Exception as exc: body = f"❌ /{name} 오류 {exc.__class__.__name__}: {exc}"; ok = 'ERR'; log_error(f'batch_{name}', exc)
        sec = time.time() - t; timings.append(f"- {'✅' if ok=='OK' else '❌'} /{name}: {sec:.2f}s / {ok}"); send(update, f"[{sent}/{len(cmds)}] /{name} ({sec:.2f}s / {ok})\n{body}")
    send(update, "🧾 자동 묶음 시간표 · v448\n" + "\n".join(timings) + f"\n- 합계 {time.time()-st:.2f}s")


def set_commands(updater):  # type: ignore[override]
    try:
        updater.bot.set_my_commands([
            BotCommand('health','전체 상태'),
            BotCommand('candidate_reason','현재 후보 판단'),
            BotCommand('review','놓친후보·청산 요약'),
            BotCommand('version_score','버전별/진입유형 성과'),
            BotCommand('popen','모의매매 진행중'),
            BotCommand('errorlog','오류로그'),
            BotCommand('batch','기본 묶음 확인'),
        ])
    except Exception as exc:
        log_error('set_commands_v446', exc)

try:
    COMMANDS.update({
        'health': health_text,
        'health_full': health_full_text,
        'candidate_reason': candidate_reason_text,
        'candidate_reason_full': candidate_reason_full_text,
        'reason': candidate_reason_text,
        'why_s1': candidate_reason_text,
        'review': review_text,
        'review_full': review_full_text,
        'missed_review': review_text,
        'pmissed_review': review_text,
        'version_score': version_score_text,
        'vscore': version_score_text,
        'errorlog_full': errorlog_full_text,
        'batch': lambda: 'batch는 텔레그램 handler로 실행됩니다.',
    })
    log_runtime('v447_candidate_light_regime_exit_review_loaded')
except Exception:
    pass



# v449: 기본 후보판 완전 캐시 전용화 + review age 표시
# - /candidate_reason, /candidate_reason_full은 worker가 S1_BLOCK_AUDIT에 미리 저장한 s123_simple_panel.top_candidates만 읽는다.
# - active 후보파일 직접 tail/read/병합을 기본 명령에서 타지 않는다.
# - review 후보에는 발견/최고/마지막 갱신 경과 시간을 표시한다.
V449_LABEL = 'v449_v406_candidate_cache_only_review_age_2026-05-26'

def _v449_safe_age(path_or_ts: Any=None, ts: Any=None) -> float:
    try:
        if ts is None:
            ts = path_or_ts
        return max(0.0, time.time() - float(ts or time.time()))
    except Exception:
        return 0.0

def _v449_panel_with_age() -> tuple[Dict[str, Any], float]:
    audit = _v427_read_small(BASE_DIR / 'clean_strategy_s1_block_audit.json', {}) or {}
    panel = {}
    if isinstance(audit, dict) and isinstance(audit.get('s123_simple_panel'), dict):
        panel = audit.get('s123_simple_panel') or {}
    elif isinstance(audit, dict):
        panel = _v444_panel()
    age_sec = _v449_safe_age(audit.get('updated_ts') if isinstance(audit, dict) else None)
    return (panel if isinstance(panel, dict) else {}, age_sec)

def _v449_cached_candidate_items(limit: int = 5) -> tuple[List[Dict[str, Any]], Dict[str, Any], float]:
    panel, age_sec = _v449_panel_with_age()
    raw = panel.get('top_candidates') if isinstance(panel.get('top_candidates'), list) else []
    items: List[Dict[str, Any]] = []
    for r in raw[:max(0, int(limit))]:
        if isinstance(r, dict):
            # panel top_candidates는 이미 compact row지만, 표시 schema를 통일하기 위해 변환한다.
            try:
                items.append(_v444_candidate_from_row(r))
            except Exception:
                items.append(dict(r))
    return items, panel, age_sec

def _v449_stage_counts_from_panel(panel: Dict[str, Any], items: List[Dict[str, Any]]) -> Dict[str, int]:
    sc = panel.get('stage_counts') if isinstance(panel.get('stage_counts'), dict) else {}
    out = {'S1': 0, 'S2': 0, 'S3': 0}
    if sc:
        for k in out:
            try: out[k] = int(float(sc.get(k, 0) or 0))
            except Exception: out[k] = 0
        return out
    return _v444_stage_counts(items)

def candidate_reason_text() -> str:  # type: ignore[override]
    strat = _v427_strategy_summary(); items, panel, page = _v449_cached_candidate_items(5)
    sc = _v449_stage_counts_from_panel(panel, items)
    missing_display = _v444_missing_display_count(items)
    if not items:
        return '\n'.join([
            '🧭 후보판정 이유 /candidate_reason · v449 cache-only',
            '- worker compact cache만 읽습니다. 후보파일 직접조회/재계산은 하지 않습니다.',
            f'- cache age {page:.1f}s',
            '- 표시 후보 없음: worker cache 준비중 또는 현재 후보 없음',
            '', '[상세]', '- 상세 후보파일 직접확인은 /candidate_reason_full이 아니라 worker cache 갱신 후 확인합니다.'
        ])
    return '\n'.join([
        '🧭 후보판정 이유 /candidate_reason · v449 cache-only',
        '- 기본판은 worker compact cache TOP 5만 읽습니다. 후보파일 직접조회/재계산 없음.',
        f"- cache age {page:.1f}s / 전체평가 {strat.get('evaluated','-') if isinstance(strat,dict) else '-'} / 표시후보 {len(items)} / 고정 40개 제한 아님",
        f"- 현재 단계: S1 {sc.get('S1',0)} / S2 {sc.get('S2',0)} / S3 {sc.get('S3',0)}",
        f"- S1 막힘 상위: {_v436_list_top(panel.get('reason_top'),3)}",
        f"- 부족정보 상위: {_v436_list_top(panel.get('missing_info_top'),3)}",
        f"- 표시값 누락: {missing_display}개" + (" / schema 확인 필요" if missing_display else ""),
        '', '[상위 후보 5개 · 캐시요약]', *_v447_candidate_lines_compact(items, 5),
        '', '[상세]', '- 후보 전체 파일 직접조회는 기본 명령에서 하지 않습니다. 필요 시 worker cache 갱신 후 확인합니다.'
    ])

def candidate_reason_full_text() -> str:  # type: ignore[override]
    strat = _v427_strategy_summary(); items, panel, page = _v449_cached_candidate_items(10)
    sc = _v449_stage_counts_from_panel(panel, items)
    missing_display = _v444_missing_display_count(items)
    lines = [
        '🧭 후보판정 이유 /candidate_reason_full · v449 cache-only',
        '- full도 worker compact cache만 읽습니다. CLOSED/후보파일 전체 직접조회는 하지 않습니다.',
        f"- cache age {page:.1f}s / 전체평가 {strat.get('evaluated','-') if isinstance(strat,dict) else '-'} / 표시후보 {len(items)} / 고정 40개 제한 아님",
        f"- 현재 단계: S1 {sc.get('S1',0)} / S2 {sc.get('S2',0)} / S3 {sc.get('S3',0)}",
        f"- 표시값 누락: {missing_display}개" + (" / worker row schema 확인 필요" if missing_display else ""),
        f"- S1 막힘 상위: {_v436_list_top(panel.get('reason_top'),10)}",
        f"- 부족정보 상위: {_v436_list_top(panel.get('missing_info_top'),10)}",
        f"- 복기판정 상위: {_v436_list_top(panel.get('decision_top'),10)}",
        '', '[상위 후보 상세 · cache TOP 10]', *_v444_candidate_lines(items, 10),
        '', '[안내]', '- v449부터 candidate_reason 계열은 기본적으로 compact cache만 읽습니다.', '- 후보파일 직접 병합/재계산은 worker 책임입니다.'
    ]
    return '\n'.join(lines)

def _v449_min_text(sec: Any) -> str:
    try:
        s = max(0.0, float(sec))
    except Exception:
        return '-'
    if s < 90: return f'{int(s)}초 전'
    if s < 3600: return f'{int(s//60)}분 전'
    if s < 86400: return f'{int(s//3600)}시간 전'
    return f'{int(s//86400)}일 전'

def _v449_review_age_line(r: Dict[str, Any]) -> str:
    nowv = time.time()
    first = r.get('first_seen_ts') or r.get('detected_ts') or r.get('queued_ts') or r.get('snapshot_ts')
    peak = r.get('max_seen_ts') or r.get('peak_seen_ts')
    last = r.get('last_seen_ts') or r.get('updated_ts')
    parts = []
    if first: parts.append(f"발견 {_v449_min_text(nowv - float(first))}")
    if peak: parts.append(f"최고 {_v449_min_text(nowv - float(peak))}")
    if last: parts.append(f"갱신 {_v449_min_text(nowv - float(last))}")
    if not parts:
        return ''
    return '   시간: ' + ' / '.join(parts)

def _v444_review_lines(rows: Any, limit: int = 5, section: str = '') -> List[str]:  # type: ignore[override]
    if not isinstance(rows, list) or not rows:
        return ['- 없음']
    out: List[str] = []
    for i, r in enumerate([x for x in rows if isinstance(x, dict)][:limit], 1):
        label = _v441_review_label(r, section)
        out.append(f"{i}) {r.get('ticker','-')} · {r.get('stage','-')} · {r.get('strategy','-')} · 최고 {_v440_pct(r.get('max_pct'))} / 현재 {_v440_pct(r.get('current_pct'))} · {label}")
        age_line = _v449_review_age_line(r)
        if age_line: out.append(age_line)
        out.append(f"   막힘: {_v441_short_reasons(r.get('reasons'), 3)}")
        risk = r.get('risk_note') or r.get('risk_reasons') or ''
        if risk:
            out.append(f"   위험: {_v441_short_reasons(risk, 2)}")
        tags = _v445_short_tags(r.get('structure_tags'), 3)
        risks = _v445_short_tags(r.get('structure_risk_tags'), 2)
        fit = str(r.get('structure_fit') or '').strip()
        if tags != '-' or risks != '-' or fit:
            out.append(f"   구조: {_v447_fit_label(fit, r.get('structure_risk_tags'))} · 태그 {tags} · 위험 {risks}")
        mtxt = _v448_market_parts(r.get('market_regime_tags'), r.get('market_risk_tags'))
        if mtxt != '-':
            out.append(f"   장세: {mtxt}")
    return out

_v449_prev_review_text = review_text
_v449_prev_review_full_text = review_full_text

def review_text() -> str:  # type: ignore[override]
    body = _v449_prev_review_text()
    body = body.replace('/review · v448 요약', '/review · v449 요약')
    body = body.replace('상세는 /review_full', '상세는 /review_full · 시간 기준 포함')
    return body

def review_full_text() -> str:  # type: ignore[override]
    body = _v449_prev_review_full_text()
    body = body.replace('/review_full · v448 상세', '/review_full · v449 상세')
    if '[판정]' in body and '시간 기준' not in body:
        body = body.replace('[판정]', '[시간 기준]\n- 발견/최고/갱신 시간이 오래된 후보는 현재 진입 판단이 아니라 복기용으로 봅니다.\n\n[판정]')
    return body

_v449_prev_health_text = health_text

def health_text() -> str:  # type: ignore[override]
    body = _v449_prev_health_text()
    for old in ('/health · v448 cache-only','/health · v447 cache-only'):
        body = body.replace(old, '/health · v533 canonical')
    body = body.replace('v448_v405_candidate_fast_regime_close_display_2026-05-25', V449_LABEL)
    body = body.replace('수익형 v2.13.405', '수익형 v2.13.406')
    return body

def health_full_text() -> str:  # type: ignore[override]
    return health_text() + '\n\n[상세]\n- worker 상세는 가드봇 /gworker_state 또는 /gexternal_state에서 확인합니다.'

_v449_prev_version_score_text = version_score_text

def version_score_text() -> str:  # type: ignore[override]
    body = _v449_prev_version_score_text()
    body = body.replace('/version_score · v448 cache-only', '/version_score · v449 cache-only')
    body = body.replace('v448_v405_candidate_fast_regime_close_display_2026-05-25', V449_LABEL)
    body = body.replace('수익형 v2.13.405', '수익형 v2.13.406')
    return body

def batch_handler(update, context):  # type: ignore[override]
    cmds = getattr(context, 'args', None) or ['health','candidate_reason','review','version_score','popen','errorlog']
    cmds = [str(x).strip().lstrip('/') for x in cmds[:8] if str(x).strip()]
    st = time.time(); sent = 0; timings = []
    try: send(update, f"📦 자동 묶음 명령 접수\n- 실행 {len(cmds)}개\n- v449: candidate_reason 완전 cache-only + review 시간 기준 표시")
    except Exception: pass
    for raw in cmds:
        name = raw.strip().lstrip('/'); fn = COMMANDS.get(name); sent += 1; t = time.time()
        if not fn:
            body = f"❌ /{name} 명령이 메인봇에 연결되지 않았습니다."; ok = 'ERR'
        else:
            try: body = fn(); ok = 'OK'
            except Exception as exc: body = f"❌ /{name} 오류 {exc.__class__.__name__}: {exc}"; ok = 'ERR'; log_error(f'batch_{name}', exc)
        sec = time.time() - t; timings.append(f"- {'✅' if ok=='OK' else '❌'} /{name}: {sec:.2f}s / {ok}"); send(update, f"[{sent}/{len(cmds)}] /{name} ({sec:.2f}s / {ok})\n{body}")
    send(update, "🧾 자동 묶음 시간표 · v449\n" + "\n".join(timings) + f"\n- 합계 {time.time()-st:.2f}s")

try:
    COMMANDS.update({
        'health': health_text,
        'health_full': health_full_text,
        'candidate_reason': candidate_reason_text,
        'candidate_reason_full': candidate_reason_full_text,
        'reason': candidate_reason_text,
        'why_s1': candidate_reason_text,
        'review': review_text,
        'review_full': review_full_text,
        'missed_review': review_text,
        'pmissed_review': review_text,
        'version_score': version_score_text,
        'vscore': version_score_text,
        'batch': lambda: 'batch는 텔레그램 handler로 실행됩니다.',
    })
    log_runtime('v449_candidate_cache_only_review_age_loaded')
except Exception:
    pass


# =============================================================================
# v525 removed: old candidate_reason/recheck/lifecycle cache wrapper blocks v450~v468.
# Final candidate commands below read paper_candidates_latest.jsonl only.
# =============================================================================

# =============================================================================
# v519: v515 정상 메인 리베이스 + 후보창 single latest-spine 최소 수술
# - v516~v518 메인 tail 불안정 구간을 버리고, 응답 확인된 v515 메인 구조를 기준으로 복구.
# - candidate_reason / candidate_summary / s1_lifecycle / recheck가 같은 paper_candidates_latest.jsonl을 읽는다.
# - batch_handler/main 실행부는 v515 정상 경로를 유지한다.
# =============================================================================
BOT_VERSION = "수익형 v2.13.427"
RESTORE_BUILD = "v519_v427_rebase_v515_single_latest_spine_price_seal_2026-05-28"
_CURRENT_MAIN_VER = "v2.13.427"
try:
    _V421_RECENT_VERSIONS = ["v2.13.427", "v2.13.426", "v2.13.423"]
except Exception:
    pass

V519_CANDIDATE_SOURCE = FILES.get('paper_latest', BASE_DIR / 'paper_candidates_latest.jsonl')
V519_HOT_CACHE = BASE_DIR / 'clean_scanner_hot_rank_cache.json'

def _v519_rows(limit=800):
    try:
        return [r for r in read_jsonl(V519_CANDIDATE_SOURCE, max_lines=limit) if isinstance(r, dict)]
    except Exception:
        return []

def _v519_ticker(row):
    return norm_ticker(row.get('ticker') or row.get('market') or row.get('symbol')) or '-'

def _v519_stage(row):
    ctx = row.get('entry_context') if isinstance(row.get('entry_context'), dict) else {}
    st = str(row.get('candidate_grade') or row.get('s_stage') or row.get('stage') or row.get('grade') or ctx.get('candidate_grade') or ctx.get('s_stage') or '-').upper().strip()
    if st in {'S1', 'S2', 'S3', 'X'}:
        return st
    return '-'

def _v519_listify(v):
    out = []
    if isinstance(v, (list, tuple)):
        out = [str(x).strip() for x in v]
    elif isinstance(v, dict):
        out = [f"{k}:{val}" for k, val in list(v.items())[:8]]
    elif v not in (None, '', '-', []):
        out = [x.strip() for x in re.split(r'\s*/\s*|\s*,\s*', str(v)) if x.strip()]
    clean, seen = [], set()
    for x in out:
        if x and x not in {'-', '[]', '{}'} and x not in seen:
            seen.add(x); clean.append(x[:80])
    return clean

def _v519_reasons(row):
    keys = (
        's1_block_reasons', 'block_reasons', 's_stage_reasons', 'final_block_reasons',
        's1_block_reason', 'final_block_reason', 'block_reason', 'reason',
        'risk_tags', 'stale_reasons', 'missing_info', 'missing_reason',
    )
    out = []
    for k in keys:
        out.extend(_v519_listify(row.get(k)))
    return out[:8]

def _v519_reason_text(row, limit=4):
    arr = _v519_reasons(row)
    return ' / '.join(arr[:limit]) if arr else '-'

def _v519_score(row):
    return fnum(row.get('score'), row.get('candidate_score'), row.get('final_score'), default=0.0)

def _v519_metric(row, *keys):
    ctx = row.get('entry_context') if isinstance(row.get('entry_context'), dict) else {}
    m = row.get('metrics') if isinstance(row.get('metrics'), dict) else {}
    em = ctx.get('metrics') if isinstance(ctx.get('metrics'), dict) else {}
    vals = []
    for k in keys:
        vals.extend([row.get(k), m.get(k), em.get(k), ctx.get(k)])
    return fnum(*vals, default=0.0)

def _v519_counts(rows):
    c = Counter()
    for r in rows:
        c[_v519_stage(r)] += 1
    return c

def _v519_reason_top(rows, limit=5):
    c = Counter()
    for r in rows:
        for x in _v519_reasons(r):
            c[x] += 1
    return [f"{k} {v}" for k, v in c.most_common(limit)]

def _v519_missing_top(rows, limit=5):
    c = Counter()
    for r in rows:
        for x in _v519_listify(r.get('missing_info')) + _v519_listify(r.get('missing_reason')):
            c[x] += 1
    return [f"{k} {v}" for k, v in c.most_common(limit)]

def _v519_source_line(rows):
    ag = age(V519_CANDIDATE_SOURCE)
    state = '신선' if ag <= 45 else ('주의' if ag <= 120 else '오래됨')
    return f"- source: paper_candidates_latest.jsonl / rows {len(rows)} / age {ag:.1f}s / {state}"

def _v519_row_line(row, idx=None):
    p = f"{idx}) " if idx is not None else "- "
    return (
        f"{p}{_v519_ticker(row)} · {_v519_stage(row)} · "
        f"{str(row.get('strategy_label') or row.get('strategy_key') or row.get('strategy') or '-')[:28]} · "
        f"반응 {_v519_metric(row, 'price_reaction_pct', 'reaction_pct'):+.2f}% · "
        f"매수 {_v519_metric(row, 'buy_ratio'):.2f} · "
        f"지속 {_v519_metric(row, 'buy_sustain_1m', 'buy_sustain'):.2f} · "
        f"스프 {_v519_metric(row, 'spread_pct'):.2f}% / {_v519_reason_text(row)}"
    )

def candidate_reason_text():  # type: ignore[override]
    rows = _v519_rows(800); counts = _v519_counts(rows)
    show = sorted(rows, key=_v519_score, reverse=True)[:5]
    lines = [
        '🧭 후보판정 이유 /candidate_reason · v519 single-spine',
        '- candidate_summary / s1_lifecycle / recheck와 같은 latest row를 읽습니다.',
        _v519_source_line(rows),
        f"- 현재 단계: S1 {counts.get('S1',0)} / S2 {counts.get('S2',0)} / S3 {counts.get('S3',0)} / 제외 {counts.get('X',0)}",
        f"- S1 못 간 이유 TOP: {' / '.join(_v519_reason_top(rows, 5)) or '-'}",
        f"- 부족정보 TOP: {' / '.join(_v519_missing_top(rows, 5)) or '-'}",
        '',
        '[상위 후보 5개]',
    ]
    if not show:
        lines.append('- 표시 후보 없음')
    else:
        for i, r in enumerate(show, 1):
            lines.append(_v519_row_line(r, i))
    return '\n'.join(lines)

def candidate_reason_full_text():  # type: ignore[override]
    rows = _v519_rows(1000); counts = _v519_counts(rows)
    show = sorted(rows, key=_v519_score, reverse=True)[:20]
    lines = [
        '🧭 후보판정 이유 /candidate_reason_full · v519 single-spine',
        _v519_source_line(rows),
        f"- 현재 단계: S1 {counts.get('S1',0)} / S2 {counts.get('S2',0)} / S3 {counts.get('S3',0)} / 제외 {counts.get('X',0)}",
        f"- S1 못 간 이유 TOP: {' / '.join(_v519_reason_top(rows, 10)) or '-'}",
        '',
        '[상위 후보 20개]',
    ]
    if not show:
        lines.append('- 표시 후보 없음')
    else:
        for i, r in enumerate(show, 1):
            lines.append(_v519_row_line(r, i))
    return '\n'.join(lines)

def candidate_summary_text():  # type: ignore[override]
    rows = _v519_rows(800); counts = _v519_counts(rows)
    show = sorted(rows, key=_v519_score, reverse=True)[:5]
    lines = [
        '🧭 후보요약 /candidate_summary · v519 single-spine',
        _v519_source_line(rows),
        f"- latest {len(rows)} / S1 {counts.get('S1',0)} / S2 {counts.get('S2',0)} / S3 {counts.get('S3',0)} / 제외 {counts.get('X',0)}",
        f"- 못 올라온 이유 TOP: {' / '.join(_v519_reason_top(rows, 5)) or '-'}",
        '',
        '[상위 후보]',
    ]
    if not show:
        lines.append('- 표시 후보 없음')
    else:
        for r in show:
            lines.append(_v519_row_line(r))
    return '\n'.join(lines)

def s1_lifecycle_text():  # type: ignore[override]
    rows = _v519_rows(800); counts = _v519_counts(rows)
    s1 = [r for r in rows if _v519_stage(r) == 'S1']
    s23 = [r for r in rows if _v519_stage(r) in {'S2', 'S3'}]
    lines = [
        '🧬 S1 생애주기 /s1_lifecycle · v519 single-spine',
        '- 별도 lifecycle cache가 아니라 candidate_reason과 같은 latest row 기준입니다.',
        _v519_source_line(rows),
        f"- 현재: S1 {counts.get('S1',0)} / S2 {counts.get('S2',0)} / S3 {counts.get('S3',0)} / raw {len(rows)}",
        f"- paper 전 후보: S1 {len(s1)} / 재확인·관찰 {len(s23)}",
        '',
        '[현재 S1 TOP]',
    ]
    if s1:
        for i, r in enumerate(sorted(s1, key=_v519_score, reverse=True)[:5], 1):
            lines.append(_v519_row_line(r, i))
    else:
        lines.append('- 없음')
    lines.append('')
    lines.append('[S1 직전 후보 TOP]')
    if s23:
        for i, r in enumerate(sorted(s23, key=_v519_score, reverse=True)[:8], 1):
            lines.append(_v519_row_line(r, i))
    else:
        lines.append('- 없음')
    return '\n'.join(lines)

def recheck_text():  # type: ignore[override]
    rows = [r for r in _v519_rows(1000) if _v519_stage(r) in {'S2', 'S3'}]
    counts = _v519_counts(rows)
    lines = [
        '🔎 재확인 후보 /recheck · v519 single-spine',
        '- paper OPEN이 아니라 S2/S3 구조후보 확인창입니다.',
        _v519_source_line(rows),
        f"- 후보 {len(rows)} / S2 {counts.get('S2',0)} / S3 {counts.get('S3',0)}",
        f"- 막힘 TOP: {' / '.join(_v519_reason_top(rows, 8)) or '-'}",
        '',
        '[재확인 후보 TOP 10]',
    ]
    if not rows:
        lines.append('- 없음')
    else:
        for i, r in enumerate(sorted(rows, key=_v519_score, reverse=True)[:10], 1):
            lines.append(_v519_row_line(r, i))
    return '\n'.join(lines)

def _v519_candidate_index():
    out = {}
    for r in _v519_rows(1000):
        t = _v519_ticker(r)
        if t and t != '-':
            out[t] = r
    return out

def _v519_hot_score(row):
    return fnum(row.get('scanner_hot_score'), default=0.0) + max(0.0, fnum(row.get('scanner_change_1m_pct'), default=0.0)) * 2.0 + max(0.0, fnum(row.get('scanner_change_3m_pct'), default=0.0))

def hot_summary_text():  # type: ignore[override]
    hot = load_json(V519_HOT_CACHE, {}) or {}
    rows = hot.get('rows') if isinstance(hot.get('rows'), list) else []
    rows = [r for r in rows if isinstance(r, dict)]
    idx = _v519_candidate_index()
    rows = sorted(rows, key=_v519_hot_score, reverse=True)[:8]
    lines = [
        '🧭 시장 hot-rank 요약 /hot_summary · v519 single-spine',
        f"- cache age {age(V519_HOT_CACHE):.1f}s / row {hot.get('row_count', len(rows))} / known 1m {hot.get('known_1m','-')} · 3m {hot.get('known_3m','-')}",
        '- 매수 알림 아님 · 급등→후보단계 연결 확인용',
    ]
    if not rows:
        lines.append('- 표시할 hot-rank 없음')
        return '\n'.join(lines)
    for r in rows:
        t = _v519_ticker(r); cand = idx.get(t, {})
        st = _v519_stage(cand) if cand else '후보아님'
        reason = _v519_reason_text(cand) if cand else '-'
        lines.append(
            f"- {t}: 1m {fnum(r.get('scanner_change_1m_pct'), default=0.0):+.2f}% #{r.get('scanner_hot_rank_1m','-')} · "
            f"3m {fnum(r.get('scanner_change_3m_pct'), default=0.0):+.2f}% #{r.get('scanner_hot_rank_3m','-')} / {st} / {reason}"
        )
    return '\n'.join(lines)

try:
    _v519_prev_health_text = health_text
    def health_text():  # type: ignore[override]
        body = _v519_prev_health_text()
        body = body.replace('/health · v468 single-cache', '/health · v519 single-spine')
        body = body.replace('v515_v423_main_hot_candidate_summary_2026-05-28', RESTORE_BUILD)
        body = body.replace('수익형 v2.13.423', BOT_VERSION)
        rows = _v519_rows(800); counts = _v519_counts(rows)
        add = f"- 후보판정 spine: latest rows {len(rows)} / S1 {counts.get('S1',0)} / S2 {counts.get('S2',0)} / S3 {counts.get('S3',0)} / age {age(V519_CANDIDATE_SOURCE):.1f}s"
        out, done = [], False
        for line in body.splitlines():
            out.append(line)
            if line.startswith('- 후보파일:') and not done:
                out.append(add); done = True
        if not done:
            out.append(add)
        return '\n'.join(out)
except Exception:
    pass

try:
    COMMANDS.update({
        'health': health_text,
        'candidate_reason': candidate_reason_text,
        'candidate_reason_full': candidate_reason_full_text,
        'reason': candidate_reason_text,
        'why_s1': candidate_reason_text,
        'candidate_summary': candidate_summary_text,
        'hot_summary': hot_summary_text,
        'hot': hot_summary_text,
        's1_lifecycle': s1_lifecycle_text,
        'lifecycle': s1_lifecycle_text,
        'recheck': recheck_text,
        's2_recheck': recheck_text,
        's3_recheck': recheck_text,
    })
    COMMANDS.pop('batch', None)
    log_runtime('v519_rebase_v515_single_latest_spine_loaded')
except Exception as exc:
    log_error('v519_command_register', exc)


# =============================================================================
# v520: 구 cache 표시 경로 차단 + 후보판정창 single-spine 정리
# - compact/recheck/lifecycle cache 없음 문구를 기본 상태/요약에서 끊는다.
# - /candidate_reason, /candidate_summary, /s1_lifecycle, /recheck는 latest row만 본다.
# - /batch 요약도 구 v468 recheck cache를 다시 붙이지 않는다.
# =============================================================================
BOT_VERSION = "수익형 v2.13.449"
RESTORE_BUILD = "v545_v449_multi_strategy_recheck_2026-05-29"
_CURRENT_MAIN_VER = "v2.13.442"
try:
    _V421_RECENT_VERSIONS = ["v2.13.442", "v2.13.441", "v2.13.440"]
except Exception:
    pass

V520_CANDIDATE_SOURCE = FILES.get('paper_latest', BASE_DIR / 'paper_candidates_latest.jsonl')
V520_HOT_CACHE = BASE_DIR / 'clean_scanner_hot_rank_cache.json'

def _v520_rows(limit=1200):
    try:
        return [r for r in read_jsonl(V520_CANDIDATE_SOURCE, max_lines=limit) if isinstance(r, dict)]
    except Exception:
        return []

def _v520_ticker(row):
    return norm_ticker(row.get('ticker') or row.get('market') or row.get('symbol')) or '-'

def _v520_stage(row):
    ctx = row.get('entry_context') if isinstance(row.get('entry_context'), dict) else {}
    st = str(row.get('candidate_grade') or row.get('s_stage') or row.get('stage') or row.get('grade') or ctx.get('candidate_grade') or ctx.get('s_stage') or '-').upper().strip()
    return st if st in {'S1', 'S2', 'S3', 'X'} else '-'

def _v520_listify(v):
    out = []
    if isinstance(v, (list, tuple)):
        out = [str(x).strip() for x in v]
    elif isinstance(v, dict):
        out = [f"{k}:{val}" for k, val in list(v.items())[:8]]
    elif v not in (None, '', '-', []):
        out = [x.strip() for x in re.split(r'\s*/\s*|\s*,\s*', str(v)) if x.strip()]
    clean, seen = [], set()
    for x in out:
        if not x or x in {'-', '[]', '{}'} or x in seen:
            continue
        seen.add(x)
        clean.append(x[:100])
    return clean

def _v520_reasons(row):
    # v520: decision reason only. risk_tags/structure_tags를 막힘 TOP에 섞지 않는다.
    keys = ('s_stage_reasons', 'block_reasons', 'final_block_reasons', 'missing_info', 'missing_reason')
    out = []
    for k in keys:
        out.extend(_v520_listify(row.get(k)))
    # stale은 실제 stale_reasons가 있을 때만 표시
    stale = _v520_listify(row.get('stale_reasons'))
    if stale:
        out.append('신선도재확인:' + '/'.join(stale[:3]))
    clean, seen = [], set()
    for s in out:
        if s.startswith('구조:'):
            continue
        if s == '신선도재확인':
            continue
        if s and s not in seen:
            seen.add(s)
            clean.append(s)
    return clean[:10]

def _v520_risks(row):
    return _v520_listify(row.get('risk_tags'))[:6]

def _v520_structures(row):
    return _v520_listify(row.get('structure_tags'))[:6]

def _v520_reason_text(row, limit=4):
    arr = _v520_reasons(row)
    return ' / '.join(arr[:limit]) if arr else '-'

def _v520_score(row):
    return fnum(row.get('score'), row.get('candidate_score'), row.get('final_score'), default=0.0)

def _v520_metric(row, *keys):
    ctx = row.get('entry_context') if isinstance(row.get('entry_context'), dict) else {}
    m = row.get('metrics') if isinstance(row.get('metrics'), dict) else {}
    em = ctx.get('metrics') if isinstance(ctx.get('metrics'), dict) else {}
    vals = []
    for k in keys:
        vals.extend([row.get(k), m.get(k), em.get(k), ctx.get(k)])
    return fnum(*vals, default=0.0)

def _v520_counts(rows):
    c = Counter()
    for r in rows:
        c[_v520_stage(r)] += 1
    return c

def _v520_top(rows, getter, limit=5):
    c = Counter()
    for r in rows:
        for x in getter(r):
            c[x] += 1
    return [f"{k} {v}" for k, v in c.most_common(limit)]

def _v520_source_line(rows):
    ag = age(V520_CANDIDATE_SOURCE)
    state = '신선' if ag <= 45 else ('주의' if ag <= 120 else '오래됨')
    return f"- source: paper_candidates_latest.jsonl / rows {len(rows)} / age {ag:.1f}s / {state}"

def _v520_row_line(row, idx=None):
    p = f"{idx}) " if idx is not None else "- "
    ticker = _v520_ticker(row)
    stage = _v520_stage(row)
    strategy = str(row.get('strategy_label') or row.get('strategy_key') or row.get('strategy') or '-')[:28]
    reason = _v520_reason_text(row, 5)
    risks = ', '.join(_v520_risks(row)[:4]) or '-'
    structs = ', '.join(_v520_structures(row)[:4]) or '-'
    react = _v520_metric(row, 'price_reaction_pct', 'reaction_pct')
    buy = _v520_metric(row, 'buy_ratio')
    sustain = _v520_metric(row, 'buy_sustain_1m', 'buy_sustain')
    spread = _v520_metric(row, 'spread_pct')
    price = _v520_metric(row, 'current_price', 'entry_price', 'price')
    return (
        f"{p}{ticker} · {stage} · {strategy}\n"
        f"   수치: 반응 {react:+.2f}% / 매수 {buy:.2f} / 지속 {sustain:.2f} / 스프 {spread:.2f}% / 가격 {price:g}\n"
        f"   이유: {reason}\n"
        f"   구조: {structs}\n"
        f"   위험: {risks}"
    )

def candidate_reason_text():  # type: ignore[override]
    rows = _v520_rows(1200)
    counts = _v520_counts(rows)
    show = sorted(rows, key=_v520_score, reverse=True)[:5]
    lines = [
        '🧭 후보판정 이유 /candidate_reason · v533 canonical',
        '- 구 compact/recheck/lifecycle cache를 보지 않고 latest row만 읽습니다.',
        _v520_source_line(rows),
        f"- 현재 단계: S1 {counts.get('S1',0)} / S2 {counts.get('S2',0)} / S3 {counts.get('S3',0)} / 제외 {counts.get('X',0)}",
        f"- S1 못 간 이유 TOP: {' / '.join(_v520_top(rows, _v520_reasons, 6)) or '-'}",
        f"- 위험 TOP: {' / '.join(_v520_top(rows, _v520_risks, 5)) or '-'}",
        '',
        '[상위 후보 5개]',
    ]
    lines += sum(([ _v520_row_line(r, i), '' ] for i, r in enumerate(show, 1)), []) if show else ['- 표시 후보 없음']
    return '\n'.join(lines)

def candidate_reason_full_text():  # type: ignore[override]
    rows = _v520_rows(1500)
    counts = _v520_counts(rows)
    show = sorted(rows, key=_v520_score, reverse=True)[:20]
    lines = [
        '🧭 후보판정 이유 /candidate_reason_full · v520 single-spine',
        _v520_source_line(rows),
        f"- 현재 단계: S1 {counts.get('S1',0)} / S2 {counts.get('S2',0)} / S3 {counts.get('S3',0)} / 제외 {counts.get('X',0)}",
        f"- S1 못 간 이유 TOP: {' / '.join(_v520_top(rows, _v520_reasons, 10)) or '-'}",
        f"- 위험 TOP: {' / '.join(_v520_top(rows, _v520_risks, 8)) or '-'}",
        '',
        '[상위 후보 20개]',
    ]
    lines += sum(([ _v520_row_line(r, i), '' ] for i, r in enumerate(show, 1)), []) if show else ['- 표시 후보 없음']
    return '\n'.join(lines)

def candidate_summary_text():  # type: ignore[override]
    rows = _v520_rows(1200)
    counts = _v520_counts(rows)
    show = sorted(rows, key=_v520_score, reverse=True)[:5]
    lines = [
        '🧭 후보요약 /candidate_summary · v533 canonical',
        _v520_source_line(rows),
        f"- latest {len(rows)} / S1 {counts.get('S1',0)} / S2 {counts.get('S2',0)} / S3 {counts.get('S3',0)} / 제외 {counts.get('X',0)}",
        f"- 못 올라온 이유 TOP: {' / '.join(_v520_top(rows, _v520_reasons, 6)) or '-'}",
        f"- 위험 TOP: {' / '.join(_v520_top(rows, _v520_risks, 5)) or '-'}",
        '',
        '[상위 후보]',
    ]
    lines += sum(([ _v520_row_line(r), '' ] for r in show), []) if show else ['- 표시 후보 없음']
    return '\n'.join(lines)

def s1_lifecycle_text():  # type: ignore[override]
    rows = _v520_rows(1200)
    counts = _v520_counts(rows)
    s1 = [r for r in rows if _v520_stage(r) == 'S1']
    s23 = [r for r in rows if _v520_stage(r) in {'S2', 'S3'}]
    lines = [
        '🧬 S1 생애주기 /s1_lifecycle · v533 canonical',
        '- 구 lifecycle cache를 보지 않고 candidate_reason과 같은 latest row 기준입니다.',
        _v520_source_line(rows),
        f"- 현재: S1 {counts.get('S1',0)} / S2 {counts.get('S2',0)} / S3 {counts.get('S3',0)} / raw {len(rows)}",
        f"- paper 전 후보: S1 {len(s1)} / 재확인·관찰 {len(s23)}",
        '',
        '[현재 S1 TOP]',
    ]
    lines += sum(([ _v520_row_line(r, i), '' ] for i, r in enumerate(sorted(s1, key=_v520_score, reverse=True)[:5], 1)), []) if s1 else ['- 없음']
    lines += ['', '[S1 직전 후보 TOP]']
    lines += sum(([ _v520_row_line(r, i), '' ] for i, r in enumerate(sorted(s23, key=_v520_score, reverse=True)[:8], 1)), []) if s23 else ['- 없음']
    return '\n'.join(lines)

def recheck_text():  # type: ignore[override]
    rows = [r for r in _v520_rows(1500) if _v520_stage(r) in {'S2', 'S3'}]
    counts = _v520_counts(rows)
    show = sorted(rows, key=_v520_score, reverse=True)[:10]
    lines = [
        '🔎 재확인 후보 /recheck · v533 canonical',
        '- 구 recheck cache를 보지 않고 S2/S3 latest row를 읽습니다.',
        _v520_source_line(rows),
        f"- 후보 {len(rows)} / S2 {counts.get('S2',0)} / S3 {counts.get('S3',0)}",
        f"- 막힘 TOP: {' / '.join(_v520_top(rows, _v520_reasons, 8)) or '-'}",
        '',
        '[재확인 후보 TOP 10]',
    ]
    lines += sum(([ _v520_row_line(r, i), '' ] for i, r in enumerate(show, 1)), []) if show else ['- 없음']
    return '\n'.join(lines)

def _v520_candidate_index():
    out = {}
    for r in _v520_rows(1500):
        t = _v520_ticker(r)
        if t and t != '-':
            out[t] = r
    return out

def _v520_hot_score(row):
    return fnum(row.get('scanner_hot_score'), default=0.0) + max(0.0, fnum(row.get('scanner_change_1m_pct'), default=0.0))*2.0 + max(0.0, fnum(row.get('scanner_change_3m_pct'), default=0.0))

def hot_summary_text():  # type: ignore[override]
    hot = load_json(V520_HOT_CACHE, {}) or {}
    rows = hot.get('rows') if isinstance(hot.get('rows'), list) else []
    rows = [r for r in rows if isinstance(r, dict)]
    idx = _v520_candidate_index()
    rows = sorted(rows, key=_v520_hot_score, reverse=True)[:8]
    lines = [
        '🧭 시장 hot-rank 요약 /hot_summary · v533 canonical',
        f"- cache age {age(V520_HOT_CACHE):.1f}s / row {hot.get('row_count', len(rows))} / known 1m {hot.get('known_1m','-')} · 3m {hot.get('known_3m','-')}",
        '- 매수 알림 아님 · 급등→후보단계 연결 확인용',
    ]
    if not rows:
        return '\n'.join(lines + ['- 표시할 hot-rank 없음'])
    for r in rows:
        t = _v520_ticker(r)
        cand = idx.get(t, {})
        st = _v520_stage(cand) if cand else '후보아님'
        reason = _v520_reason_text(cand) if cand else '-'
        lines.append(
            f"- {t}: 1m {fnum(r.get('scanner_change_1m_pct'), default=0.0):+.2f}% #{r.get('scanner_hot_rank_1m','-')} · "
            f"3m {fnum(r.get('scanner_change_3m_pct'), default=0.0):+.2f}% #{r.get('scanner_hot_rank_3m','-')} / {st} / {reason}"
        )
    return '\n'.join(lines)

def _v520_filter_old_cache_lines(text):
    drop_prefixes = (
        '- 후보판정 cache:',
        '- 재확인 후보:',
        '[v468 재확인 S1승격/정보부족]',
        '[S1승격 차단 TOP]',
        '[정보부족 TOP]',
        '[실측부족 TOP]',
    )
    out = []
    skip_v468 = False
    for line in str(text or '').splitlines():
        if any(line.startswith(p) for p in drop_prefixes):
            skip_v468 = line.startswith('[v468 재확인 S1승격/정보부족]')
            continue
        if skip_v468:
            if line.startswith('[v') or line.startswith('[/') or line.startswith('🧭') or line.startswith('🧬') or line.startswith('🧯'):
                skip_v468 = False
            else:
                continue
        if 'cache 없음' in line and ('recheck' in line.lower() or '재확인' in line or '후보판정 cache' in line):
            continue
        out.append(line)
    return '\n'.join(out)

_v520_prev_health_text = health_text

def health_text():  # type: ignore[override]
    body = _v520_filter_old_cache_lines(_v520_prev_health_text())
    body = body.replace('/health · v519 single-spine', '/health · v529 latest-spine')
    body = body.replace('v519_v427_rebase_v515_single_latest_spine_price_seal_2026-05-28', RESTORE_BUILD)
    body = body.replace('수익형 v2.13.427', BOT_VERSION)
    rows = _v520_rows(1200)
    counts = _v520_counts(rows)
    spine = f"- 후보판정 spine: latest rows {len(rows)} / S1 {counts.get('S1',0)} / S2 {counts.get('S2',0)} / S3 {counts.get('S3',0)} / age {age(V520_CANDIDATE_SOURCE):.1f}s"
    if '후보판정 spine:' not in body:
        body += '\n' + spine
    else:
        body = re.sub(r'- 후보판정 spine:.*', spine, body)
    return body

def _v453_batch_summary_text(cmds, outputs, timings, recv_delay, total_sec):  # type: ignore[override]
    rows = _v520_rows(1200)
    counts = _v520_counts(rows)
    lines = [
        '코인봇 최신 묶음 요약집',
        f'- 생성: {now_text()}',
        f'- 메인봇: {BOT_VERSION} / {RESTORE_BUILD}',
        f'- batch 접수지연: {recv_delay:.2f}s / 처리합계: {total_sec:.2f}s',
        '',
        '[명령 시간표]',
        *[f'- {x}' for x in timings],
        '',
        '[현재 상태]',
        f"- 후보 spine: latest {len(rows)} / S1 {counts.get('S1',0)} / S2 {counts.get('S2',0)} / S3 {counts.get('S3',0)} / age {age(V520_CANDIDATE_SOURCE):.1f}s",
        f"- S1 못 간 이유 TOP: {' / '.join(_v520_top(rows, _v520_reasons, 6)) or '-'}",
        f"- 위험 TOP: {' / '.join(_v520_top(rows, _v520_risks, 5)) or '-'}",
        '',
        '[판단 원칙]',
        '- 청산/자동매수/BUY_READY 변경 없음. S1 조건은 canonical_entry_decision 한곳에서 계산하고 전략은 성과태그로 봅니다.',
        '- 구 compact/recheck/lifecycle cache는 기본 요약에서 사용하지 않음.',
    ]
    for cmd in cmds:
        key = '/' + str(cmd).lstrip('/')
        body = _v520_filter_old_cache_lines(outputs.get(str(cmd).lstrip('/'), ''))
        if not body:
            continue
        if len(body) > 2600:
            body = body[:2600] + '\n…(요약집에서 일부 절단)'
        lines += ['', f'[{key} 출력 요약]', body]
    return '\n'.join(lines) + '\n'

try:
    COMMANDS.update({
        'health': health_text,
        'candidate_reason': candidate_reason_text,
        'candidate_reason_full': candidate_reason_full_text,
        'reason': candidate_reason_text,
        'why_s1': candidate_reason_text,
        'candidate_summary': candidate_summary_text,
        'hot_summary': hot_summary_text,
        'hot': hot_summary_text,
        's1_lifecycle': s1_lifecycle_text,
        'lifecycle': s1_lifecycle_text,
        'recheck': recheck_text,
        's2_recheck': recheck_text,
        's3_recheck': recheck_text,
    })
    COMMANDS.pop('batch', None)
    log_runtime('v525_cut_old_candidate_wrappers_gate_schema_loaded')
except Exception as exc:
    log_error('v537_command_register', exc)


# =============================================================================
# v524: 전략 lane / 1분 매수지속 출처 / health spine 표시 정리
# =============================================================================

def _v524_join(xs, limit=5):
    if not xs:
        return '-'
    out = []
    seen = set()
    for x in xs[:limit]:
        s = str(x or '').strip()
        if s and s not in seen:
            seen.add(s)
            out.append(s)
    return ', '.join(out) if out else '-'


def _v520_row_line(row, idx=None):  # type: ignore[override]
    p = f"{idx}) " if idx is not None else "- "
    ticker = _v520_ticker(row)
    stage = _v520_stage(row)
    strategy = str(row.get('strategy_label') or row.get('strategy_key') or row.get('strategy') or '-')[:32]
    matched = row.get('matched_strategy_labels') if isinstance(row.get('matched_strategy_labels'), list) else []
    reason = _v520_reason_text(row, 5)
    risks = _v524_join(_v520_risks(row), 4)
    structs = _v524_join(_v520_structures(row), 4)
    react = _v520_metric(row, 'price_reaction_pct', 'reaction_pct')
    buy = _v520_metric(row, 'buy_ratio')
    sustain = _v520_metric(row, 'buy_sustain_1m', 'buy_sustain')
    spread = _v520_metric(row, 'spread_pct')
    price = _v520_metric(row, 'current_price', 'entry_price', 'price')
    sustain_src = str(row.get('buy_sustain_1m_source') or row.get('sustain_source') or '-')
    sustain_mark = '실측' if bool(row.get('buy_sustain_1m_real')) else ('대체값' if sustain_src != '-' else '-')
    lane = str(row.get('canonical_lane') or '-')
    passed = row.get('s1_passed_conditions') if isinstance(row.get('s1_passed_conditions'), list) else []
    missing = row.get('s1_missing_conditions') if isinstance(row.get('s1_missing_conditions'), list) else []
    distance = row.get('s1_distance', '-')
    near = 'S1근접' if bool(row.get('s1_near_miss')) else f"S1거리 {distance}"
    return (
        f"{p}{ticker} · {stage} · {strategy} · {near}\n"
        f"   전략: {_v524_join(matched, 4)} / lane {lane}\n"
        f"   수치: 반응 {react:+.2f}% / 매수 {buy:.2f} / 1분지속 {sustain:.2f}({sustain_mark}:{sustain_src}) / 스프 {spread:.2f}% / 가격 {price:g}\n"
        f"   S1통과: {_v524_join(passed, 7)}\n"
        f"   S1부족: {_v524_join(missing, 5)}\n"
        f"   이유: {reason}\n"
        f"   구조: {structs}\n"
        f"   위험: {risks}"
    )


_v524_prev_health_text = health_text

def health_text():  # type: ignore[override]
    body = _v520_filter_old_cache_lines(_v524_prev_health_text())
    body = body.replace('/health · v533 canonical', '/health · v529 latest-spine')
    body = body.replace('v522_v430_freshness_single_gate_readable_output_2026-05-28', RESTORE_BUILD)
    body = body.replace('수익형 v2.13.430', BOT_VERSION)
    body = body.replace('- S1 판정: S1/S2/S3 사유 cache 표시', '- S1 판정: latest spine 기준 표시')
    rows = _v520_rows(1200)
    counts = _v520_counts(rows)
    reason_top = ' / '.join(_v520_top(rows, _v520_reasons, 6)) or '-'
    risk_top = ' / '.join(_v520_top(rows, _v520_risks, 5)) or '-'
    sustain_fb = sum(1 for r in rows if not bool(r.get('buy_sustain_1m_real')) and str(r.get('buy_sustain_1m_source') or '') in {'buy_ratio_fallback', 'buy_ratio', 'micro_buy_ratio'})
    lane_counts = {}
    for r in rows:
        lane = str(r.get('canonical_lane') or '-')
        lane_counts[lane] = lane_counts.get(lane, 0) + 1
    lane_line = ' / '.join(f'{k} {v}' for k, v in sorted(lane_counts.items(), key=lambda kv: kv[0])) or '-'
    spine = f"- 후보판정 spine: latest rows {len(rows)} / S1 {counts.get('S1',0)} / S2 {counts.get('S2',0)} / S3 {counts.get('S3',0)} / age {age(V520_CANDIDATE_SOURCE):.1f}s"
    sustain_line = f"- 1분지속 출처: 대체값 {sustain_fb} / 실측 {max(0, len(rows)-sustain_fb)}"
    lane_status = f"- 전략 lane: {lane_line}"
    block_line = f"- S1 막힘 상위: {reason_top}"
    risk_line = f"- 위험 상위: {risk_top}"
    body = re.sub(r'- 후보판정 spine:.*', spine, body)
    body = re.sub(r'- S1 막힘 상위:.*', block_line, body)
    if '1분지속 출처:' not in body:
        body = body.replace(spine, spine + '\n' + sustain_line + '\n' + lane_status)
    else:
        body = re.sub(r'- 1분지속 출처:.*', sustain_line, body)
    if '위험 상위:' not in body:
        body = body.replace(block_line, block_line + '\n' + risk_line)
    near = sum(1 for r in rows if bool(r.get('s1_near_miss')))
    miss = Counter()
    for r in rows:
        for x in (r.get('s1_missing_names') or []):
            miss[str(x)] += 1
    near_line = f"- S1 근접후보: {near} / 부족TOP: {' / '.join(f'{k} {v}' for k, v in miss.most_common(6)) or '-'}"
    body = body.replace('- S1 판정: S1/S2/S3 사유 cache 준비중', '- S1 판정: canonical_entry_decision 단일 원천 / profile 3개 단순화')
    if 'S1 근접후보:' not in body:
        body = body.replace(spine, spine + '\n' + near_line)
    return body


def _v453_batch_summary_text(cmds, outputs, timings, recv_delay, total_sec):  # type: ignore[override]
    rows = _v520_rows(1200)
    counts = _v520_counts(rows)
    sustain_fb = sum(1 for r in rows if not bool(r.get('buy_sustain_1m_real')) and str(r.get('buy_sustain_1m_source') or '') in {'buy_ratio_fallback', 'buy_ratio', 'micro_buy_ratio'})
    lane_counts = {}
    for r in rows:
        lane = str(r.get('canonical_lane') or '-')
        lane_counts[lane] = lane_counts.get(lane, 0) + 1
    lane_line = ' / '.join(f'{k} {v}' for k, v in sorted(lane_counts.items(), key=lambda kv: kv[0])) or '-'
    lines = [
        '코인봇 최신 묶음 요약집',
        f'- 생성: {now_text()}',
        f'- 메인봇: {BOT_VERSION} / {RESTORE_BUILD}',
        f'- batch 접수지연: {recv_delay:.2f}s / 처리합계: {total_sec:.2f}s',
        '',
        '[명령 시간표]',
        *[f'- {x}' for x in timings],
        '',
        '[현재 상태]',
        f"- 후보 spine: latest {len(rows)} / S1 {counts.get('S1',0)} / S2 {counts.get('S2',0)} / S3 {counts.get('S3',0)} / age {age(V520_CANDIDATE_SOURCE):.1f}s",
        f"- 전략 lane: {lane_line}",
        f"- 1분지속 출처: 대체값 {sustain_fb} / 실측 {max(0, len(rows)-sustain_fb)}",
        f"- S1 근접후보: {sum(1 for r in rows if bool(r.get('s1_near_miss')))} / 부족TOP: {' / '.join(f'{k} {v}' for k, v in Counter(x for r in rows for x in (r.get('s1_missing_names') or [])).most_common(6)) or '-'}",
        f"- S1 못 간 이유 TOP: {' / '.join(_v520_top(rows, _v520_reasons, 6)) or '-'}",
        f"- 위험 TOP: {' / '.join(_v520_top(rows, _v520_risks, 5)) or '-'}",
        '',
        '[판단 원칙]',
        '- 청산/자동매수/BUY_READY 변경 없음. S1 조건은 canonical_entry_decision 한곳에서 계산하고 전략은 성과태그로 봅니다.',
        '- 전략 lane과 1분지속 출처를 latest row에 봉인해 표시.',
    ]
    for cmd in cmds:
        key = '/' + str(cmd).lstrip('/')
        body = _v520_filter_old_cache_lines(outputs.get(str(cmd).lstrip('/'), ''))
        if not body:
            continue
        if len(body) > 3200:
            body = body[:3200] + '\n…(요약집에서 일부 절단)'
        lines += ['', f'[{key} 출력 요약]', body]
    return '\n'.join(lines) + '\n'

try:
    COMMANDS.update({
        'health': health_text,
        'candidate_reason': candidate_reason_text,
        'candidate_reason_full': candidate_reason_full_text,
        'candidate_summary': candidate_summary_text,
        'hot_summary': hot_summary_text,
        's1_lifecycle': s1_lifecycle_text,
        'recheck': recheck_text,
    })
    COMMANDS.pop('batch', None)
    log_runtime('v525_cut_old_candidate_wrappers_gate_schema_loaded')
except Exception as exc:
    log_error('v537_command_register', exc)


# =============================================================================
# v526: /batch 요약 txt 파일 전송 복구
# - v525에서 구 wrapper 절단 중 사라진 txt 파일 생성/전송만 복구한다.
# - 구 candidate_reason/recheck/lifecycle cache는 다시 연결하지 않는다.
# - summary text는 latest spine / COMMANDS 실행 결과만 사용한다.
# =============================================================================

def _v526_update_delay_sec(update: Any) -> float:
    try:
        dt = getattr(getattr(update, 'message', None), 'date', None)
        if dt is not None:
            try:
                return max(0.0, time.time() - dt.timestamp())
            except Exception:
                pass
    except Exception:
        pass
    return 0.0


def _v526_limit_text(text: Any, max_chars: int = 3600) -> str:
    s = str(text or '')
    return s if len(s) <= max_chars else s[:max_chars] + '\n…(요약집에서 일부 절단)'


def _v526_batch_summary_text(cmds: List[str], outputs: Dict[str, str], timings: List[str], recv_delay: float, total_sec: float) -> str:
    rows = _v520_rows(1200)
    counts = _v520_counts(rows)
    sustain_fb = sum(1 for r in rows if not bool(r.get('buy_sustain_1m_real')) and str(r.get('buy_sustain_1m_source') or '') in {'buy_ratio_fallback', 'buy_ratio', 'micro_buy_ratio'})
    lane_counts: Dict[str, int] = {}
    for r in rows:
        lane = str(r.get('canonical_lane') or '-')
        lane_counts[lane] = lane_counts.get(lane, 0) + 1
    lane_line = ' / '.join(f'{k} {v}' for k, v in sorted(lane_counts.items(), key=lambda kv: kv[0])) or '-'
    lines = [
        '코인봇 최신 묶음 요약집',
        f'- 생성: {now_text()}',
        f'- 메인봇: {BOT_VERSION} / {RESTORE_BUILD}',
        f'- batch 접수지연: {recv_delay:.2f}s / 처리합계: {total_sec:.2f}s',
        '',
        '[명령 시간표]',
        *timings,
        '',
        '[현재 상태]',
        f"- 후보 spine: latest {len(rows)} / S1 {counts.get('S1',0)} / S2 {counts.get('S2',0)} / S3 {counts.get('S3',0)} / age {age(V520_CANDIDATE_SOURCE):.1f}s",
        f"- 전략 lane: {lane_line}",
        f"- 1분지속 출처: 대체값 {sustain_fb} / 실측 {max(0, len(rows)-sustain_fb)}",
        f"- S1 못 간 이유 TOP: {' / '.join(_v520_top(rows, _v520_reasons, 6)) or '-'}",
        f"- 위험 TOP: {' / '.join(_v520_top(rows, _v520_risks, 5)) or '-'}",
        '',
        '[판단 원칙]',
        '- 청산/자동매수/BUY_READY 변경 없음. S1 조건은 canonical_entry_decision 한곳에서 계산하고 전략은 성과태그로 봅니다.',
        '- 요약집은 paper_candidates_latest.jsonl latest spine과 이번 batch 출력만 사용합니다.',
        '- 구 candidate_reason/recheck/lifecycle cache는 다시 읽지 않습니다.',
    ]
    for name in cmds:
        body = outputs.get(name)
        if not body:
            continue
        lines += ['', f'[/{name} 출력 요약]', _v526_limit_text(body, 4200)]
    return '\n'.join(lines) + '\n'


def _v526_safe_chat_id(update: Any) -> Any:
    try:
        if getattr(update, 'effective_chat', None) is not None:
            return update.effective_chat.id
    except Exception:
        pass
    try:
        return update.message.chat_id
    except Exception:
        return CHAT_ID or None


def _v526_send_batch_summary_file(update: Any, context: Any, text: str) -> str:
    path = BASE_DIR / 'coinbot_latest_batch_summary.txt'
    filename = f"coinbot_batch_summary_{time.strftime('%Y%m%d_%H%M%S')}.txt"
    sent = False
    try:
        path.write_text(text, encoding='utf-8')
        bot = getattr(context, 'bot', None)
        chat_id = _v526_safe_chat_id(update)
        if bot is not None and chat_id:
            with path.open('rb') as fh:
                try:
                    bot.send_document(chat_id=chat_id, document=fh, filename=filename, timeout=15)
                except TypeError:
                    fh.seek(0)
                    bot.send_document(chat_id=chat_id, document=fh, filename=filename)
            sent = True
            return 'txt 전송완료 후 서버삭제'
        with path.open('rb') as fh:
            update.message.reply_document(document=fh, filename=filename)
        sent = True
        return 'txt 전송완료 후 서버삭제'
    except Exception as exc:
        log_error('v526_batch_summary_send', exc)
        try:
            send(update, f'⚠️ batch 요약 txt 전송 실패: {exc.__class__.__name__} / 서버 latest txt 1개만 보관')
        except Exception:
            pass
        return f'txt 전송실패 {exc.__class__.__name__} · latest 보관'
    finally:
        if sent:
            try:
                path.unlink(missing_ok=True)
            except Exception as exc:
                log_error('v526_batch_summary_delete', exc)


def batch_handler(update, context):  # type: ignore[override]
    recv_delay = _v526_update_delay_sec(update)
    default_cmds = ['health','candidate_reason','candidate_summary','s1_lifecycle','recheck','errorlog']
    cmds = getattr(context, 'args', None) or default_cmds
    cmds = [str(x).strip().lstrip('/') for x in cmds[:8] if str(x).strip()]
    st = time.time()
    timings: List[str] = []
    outputs: Dict[str, str] = {}
    try:
        send(update, f"📦 자동 묶음 명령 접수\n- 실행 {len(cmds)}개\n- v529: S1 체크리스트 + latest-spine txt\n- 접수지연 {recv_delay:.2f}s")
    except Exception:
        pass
    for i, raw in enumerate(cmds, 1):
        name = raw.strip().lstrip('/')
        fn = COMMANDS.get(name)
        t = time.time()
        if not fn:
            body = f"❌ /{name} 명령이 메인봇에 연결되지 않았습니다."
            ok = 'ERR'
        else:
            try:
                body = fn()
                ok = 'OK'
            except Exception as exc:
                body = f"❌ /{name} 오류 {exc.__class__.__name__}: {exc}"
                ok = 'ERR'
                log_error(f'v526_batch_{name}', exc)
        sec = time.time() - t
        outputs[name] = body
        timings.append(f"- {'✅' if ok=='OK' else '❌'} /{name}: {sec:.2f}s / {ok}")
        try:
            send(update, f"[{i}/{len(cmds)}] /{name} ({sec:.2f}s / {ok})\n{body}")
        except Exception as exc:
            log_error('v526_batch_send_step', exc)
    total = time.time() - st
    summary_status = '생성안함'
    try:
        summary_txt = _v526_batch_summary_text(cmds, outputs, timings, recv_delay, total)
        summary_status = _v526_send_batch_summary_file(update, context, summary_txt)
    except Exception as exc:
        log_error('v526_batch_summary_build', exc)
        summary_status = f'요약txt 오류 {exc.__class__.__name__}'
    try:
        send(update, "🧾 자동 묶음 시간표 · v529\n" + "\n".join(timings) + f"\n- 합계 {total:.2f}s\n- 요약 txt: {summary_status}")
    except Exception:
        pass


try:
    COMMANDS.pop('batch', None)
    log_runtime('v529_s1_checklist_inline_display_loaded')
except Exception as exc:
    log_error('v526_register', exc)


# =============================================================================
# v534: main display canonical-only cleanup
# - strategy/paper 조건은 건드리지 않는다.
# - main 출력/집계만 canonical_entry_decision 기준으로 맞춘다.
# - hot-rank는 "못 간 이유"가 아니라 전략/발견 태그로 분리한다.
# =============================================================================

def _v534_decision(row: Dict[str, Any]) -> Dict[str, Any]:
    if not isinstance(row, dict):
        return {}
    ctx = row.get("entry_context") if isinstance(row.get("entry_context"), dict) else {}
    dec = row.get("canonical_entry_decision") or ctx.get("canonical_entry_decision") or row.get("common_entry_decision") or ctx.get("common_entry_decision")
    return dec if isinstance(dec, dict) else {}


def _v534_missing_conditions(row: Dict[str, Any]) -> List[str]:
    dec = _v534_decision(row)
    xs = dec.get("missing_conditions") or dec.get("display_reasons") or row.get("s1_missing_conditions") or []
    out: List[str] = []
    if isinstance(xs, list):
        for x in xs:
            s = str(x or "").strip()
            if not s or s == "태그":
                continue
            if "hot-rank" in s or "급등 재확인" in s or "전략태그" in s:
                continue
            out.append(s)
    return out


def _v534_missing_names(row: Dict[str, Any]) -> List[str]:
    dec = _v534_decision(row)
    xs = dec.get("missing_names") or row.get("s1_missing_names") or []
    out: List[str] = []
    if isinstance(xs, list):
        for x in xs:
            s = str(x or "").strip()
            if not s or s in {"전략태그", "전략구조"}:
                continue
            out.append(s)
    return out


def _v534_reason_top(rows: List[Dict[str, Any]], n: int = 8) -> List[str]:
    c: Counter = Counter()
    for r in rows:
        for x in _v534_missing_conditions(r):
            c[x] += 1
    return [f"{k} {v}" for k, v in c.most_common(n)]


def _v534_missing_name_top(rows: List[Dict[str, Any]], n: int = 8) -> List[str]:
    c: Counter = Counter()
    for r in rows:
        for x in _v534_missing_names(r):
            c[x] += 1
    return [f"{k} {v}" for k, v in c.most_common(n)]


def _v534_tag_top(rows: List[Dict[str, Any]], n: int = 6) -> List[str]:
    c: Counter = Counter()
    for r in rows:
        dec = _v534_decision(r)
        vals = dec.get("matched_strategy_labels") or r.get("matched_strategy_labels") or []
        if not isinstance(vals, list):
            vals = [vals]
        for v in vals:
            s = str(v or "").strip()
            if s:
                c[s] += 1
    return [f"{k} {v}" for k, v in c.most_common(n)]


def _v534_counts(rows: List[Dict[str, Any]]) -> Dict[str, int]:
    c = {"S1": 0, "S2": 0, "S3": 0, "X": 0}
    for r in rows:
        s = _v520_stage(r)
        if s in c:
            c[s] += 1
        else:
            c["X"] += 1
    return c


def _v534_lane_line(rows: List[Dict[str, Any]]) -> str:
    c: Counter = Counter()
    for r in rows:
        c[str(r.get("canonical_lane") or "-")] += 1
    return " / ".join(f"{k} {v}" for k, v in sorted(c.items(), key=lambda kv: kv[0])) or "-"


def _v534_sustain_line(rows: List[Dict[str, Any]]) -> str:
    real = sum(1 for r in rows if bool(r.get("buy_sustain_1m_real")))
    fb = max(0, len(rows) - real)
    return f"대체값 {fb} / 실측 {real}"


def _v534_resource_line() -> str:
    try:
        import shutil as _shutil
        import os as _os
        total, used, free = _shutil.disk_usage(str(BASE_DIR))
        disk_used = used / total * 100 if total else 0.0
        mem = "-"
        try:
            with open("/proc/meminfo", "r", encoding="utf-8", errors="ignore") as f:
                info = {}
                for line in f:
                    parts = line.split()
                    if len(parts) >= 2:
                        info[parts[0].rstrip(":")] = float(parts[1])
                mt = info.get("MemTotal", 0.0)
                ma = info.get("MemAvailable", 0.0)
                mem = f"{(mt-ma)/mt*100:.1f}%" if mt else "-"
        except Exception:
            pass
        load = "-"
        try:
            load = str([round(x, 2) for x in _os.getloadavg()])
        except Exception:
            pass
        return f"디스크 {disk_used:.1f}% / 남음 {free/1024/1024/1024:.2f}GB / 메모리 {mem} / load {load}"
    except Exception:
        return "-"


def _v534_worker_summary_lines() -> List[str]:
    # Keep cache-only. If prior helper exists and is reliable, use its output.
    try:
        body = _v529_worker_summary_text() if "_v529_worker_summary_text" in globals() else ""
        if body:
            return str(body).splitlines()
    except Exception:
        pass
    lines: List[str] = []
    status_files = [
        ("scanner", BASE_DIR / "clean_scanner_status.json"),
        ("candle", BASE_DIR / "clean_candle_status.json"),
        ("market", BASE_DIR / "clean_market_regime_status.json"),
        ("feature", BASE_DIR / "clean_feature_status.json"),
        ("orderflow", BASE_DIR / "clean_orderflow_status.json"),
        ("risk", BASE_DIR / "clean_risk_status.json"),
        ("strategy", BASE_DIR / "clean_strategy_worker_status.json"),
        ("target_router", BASE_DIR / "clean_target_router_status.json"),
        ("review", BASE_DIR / "clean_review_worker_status.json"),
    ]
    for name, path in status_files:
        try:
            obj = load_json(path, {}) or {}
            ver = obj.get("version") or obj.get("worker_version") or "-"
            state = obj.get("state") or obj.get("status") or "-"
            err = obj.get("error") or obj.get("last_error") or "-"
            lines.append(f"- {'✅' if state == 'running' or err in ('-', '', None) else '⚠️'} {name}: {ver} / {state} / age {age(path):.1f}s / err {err or '-'}")
        except Exception:
            lines.append(f"- ❔ {name}: status 확인불가")
    return lines


def _v534_paper_line() -> str:
    try:
        status_path = BASE_DIR / "paper_bot_status.json"
        trace_path = BASE_DIR / "paper_bot_candidate_handoff_trace.json"
        pstat = load_json(status_path, {}) or {}
        ptrace = load_json(trace_path, {}) or {}
        if not pstat:
            status_path = BASE_DIR / "clean_paper_status.json"
            pstat = load_json(status_path, {}) or {}
        if not ptrace:
            trace_path = BASE_DIR / "clean_paper_trace.json"
            ptrace = load_json(trace_path, {}) or {}
        ver = pstat.get("version") or pstat.get("paper_version") or ptrace.get("version") or "-"
        open_n = pstat.get("open_count", pstat.get("OPEN", "-"))
        closed_n = pstat.get("closed_total", pstat.get("closed_count", pstat.get("CLOSED", "-")))
        return f"paper: {ver} / status age {age(status_path):.1f}s / trace age {age(trace_path):.1f}s / OPEN {open_n} / CLOSED누적 {closed_n}"
    except Exception:
        return "paper: 확인필요"



# v538: 출력 한글 라벨 + score cache total/avg 소비자 단일화 helper
# 내부 key는 유지하고 텔레그램 표시만 변환한다.
def _v538_num_from(stat: Dict[str, Any], keys: Iterable[str], default: float = 0.0) -> float:
    if not isinstance(stat, dict):
        return default
    for k in keys:
        if k in stat and stat.get(k) not in (None, ""):
            return fnum(stat.get(k), default=default)
    return default


def _v538_int_from(stat: Dict[str, Any], keys: Iterable[str], default: int = 0) -> int:
    try:
        return int(round(_v538_num_from(stat, keys, float(default))))
    except Exception:
        return default


def _v538_profile_key(raw: Any) -> str:
    p = str(raw or "unknown").strip()
    if p in {"spike_fast_early", "spike_runner"}:
        return "spike"
    if p in {"spike_fast_watch", "normal_watch"}:
        return "watch"
    return p or "unknown"


def _v538_profile_label(raw: Any) -> str:
    p = _v538_profile_key(raw)
    return {
        "normal_common": "일반 공통 진입",
        "spike": "급등 재확인 진입",
        "watch": "관찰 후보",
        "unknown": "구버전/미분류",
        "-": "미분류",
    }.get(p, p)


def _v538_exit_label(raw: Any) -> str:
    x = str(raw or "-").strip()
    return {
        "take_profit": "익절",
        "stop_loss": "손절",
        "fast_fail_stop": "빠른 실패 정리",
        "protect_stop_after_tp": "보호익절",
        "hard_loss_guard": "하드 손실 방어",
        "slow_no_progress": "진행 없음 정리",
        "bounce_fail": "반등 실패",
        "time_exit": "시간청산",
        "normal_exit": "일반 청산관리",
        "spike_fast_fail_protect": "급등 빠른실패 보호",
        "-": "미분류",
        "unknown": "미분류",
    }.get(x, x)


def _v538_format_stat(stat: Dict[str, Any]) -> str:
    n = _v538_int_from(stat, ("n", "count", "trades"), 0)
    wins = _v538_int_from(stat, ("wins", "win"), 0)
    losses = _v538_int_from(stat, ("losses", "loss"), max(0, n - wins))
    win_rate = _v538_num_from(stat, ("win_rate", "win_rate_pct"), (wins / n * 100.0 if n else 0.0))
    total = _v538_num_from(stat, ("sum_pct", "total_pct", "pnl_sum_pct", "pnl_total_pct", "total"), 0.0)
    avg = _v538_num_from(stat, ("avg_pct", "mean_pct", "pnl_avg_pct", "avg"), (total / n if n else 0.0))
    return f"{n}전 {wins}승 {losses}패 / 승률 {win_rate:.1f}% / 합산 {total:+.2f}% / 평균 {avg:+.2f}%"


def _v538_profile_exit_parts(raw: Any) -> Tuple[str, str]:
    s = str(raw or "unknown:-")
    if ":" in s:
        p, e = s.split(":", 1)
    else:
        p, e = "unknown", s
    return _v538_profile_label(p), _v538_exit_label(e)


def _v538_open_rows() -> List[Dict[str, Any]]:
    try:
        obj = _paper_open_positions()
        rows = [p for p in obj.values() if isinstance(p, dict)] if isinstance(obj, dict) else []
        rows.sort(key=lambda p: fnum(p.get("opened_at") or p.get("entry_ts") or 0, default=0.0), reverse=True)
        return rows
    except Exception:
        return []


def _v538_open_stage_line() -> str:
    rows = _v538_open_rows()
    if not rows:
        return "진행 중 없음"
    c = Counter(_paper_grade(p) for p in rows)
    return " / ".join(f"{_v358_stage_label(k)} {v}" for k, v in c.items())


def _v538_risk_text(v: Any) -> str:
    if isinstance(v, (list, tuple)):
        return ", ".join(str(x) for x in v if str(x).strip()) or "특이사항 없음"
    s = str(v or "").strip()
    return s if s and s not in {"[]", "None"} else "특이사항 없음"


def _v538_koreanize_output(text: Any) -> str:
    s = str(text or "")
    repl = {
        "cache-onlynly": "캐시 전용",
        "cache-only": "캐시 전용",
        "v537 profiles": "v540 한글표시",
        "score cache 준비중": "성과 캐시 준비 중",
        "entry_profile TOP": "진입유형 TOP",
        "entry_profile 성과": "진입유형별 성과",
        "entry_profile × exit_reason 성과": "진입유형 × 청산 이유별 성과",
        "exit_reason": "청산 이유",
        "profile:": "진입유형:",
        " / exit ": " / 청산관리 ",
        "paper OPEN": "모의매매 진행중",
        "OPEN 없음": "진행 중 없음",
        "등급별 OPEN": "등급별 진행중",
        "전략별 OPEN": "전략별 진행중",
        "normal_common": "일반 공통 진입",
        "spike_fast_early": "급등 재확인 진입",
        "spike_runner": "급등 재확인 진입",
        "spike_fast_watch": "관찰 후보",
        "normal_watch": "관찰 후보",
        "spike": "급등 재확인 진입",
        "watch": "관찰 후보",
        "unknown": "구버전/미분류",
        "take_profit": "익절",
        "stop_loss": "손절",
        "fast_fail_stop": "빠른 실패 정리",
        "protect_stop_after_tp": "보호익절",
        "hard_loss_guard": "하드 손실 방어",
        "slow_no_progress": "진행 없음 정리",
        "bounce_fail": "반등 실패",
        "normal_exit": "일반 청산관리",
        "spike_fast_fail_protect": "급등 빠른실패 보호",
        " / lane 급등 재확인 진입": " / lane 급등 재확인",
    }
    for a, b in repl.items():
        s = s.replace(a, b)
    return s


def health_text():  # type: ignore[override]
    rows = _v520_rows(1200)
    counts = _v534_counts(rows)
    near = sum(1 for r in rows if bool((_v534_decision(r).get("s1_near_miss")) or r.get("s1_near_miss")))
    lines = [
        "🧭 건강상태 /health · v540 한글표시",
        "✅ 전체판독: worker/paper/cache 기준 표시 · 조건계산 없음",
        f"- 메인봇 {BOT_VERSION} / {RESTORE_BUILD} / uptime {int(time.time()-START_TS)}s",
        f"- 후보판정 spine: latest rows {len(rows)} / S1 {counts.get('S1',0)} / S2 {counts.get('S2',0)} / S3 {counts.get('S3',0)} / age {age(V520_CANDIDATE_SOURCE):.1f}s",
        f"- S1 근접후보: {near} / 부족TOP: {' / '.join(_v534_missing_name_top(rows, 6)) or '-'}",
        f"- 1분지속 출처: {_v534_sustain_line(rows)}",
        f"- 전략 lane: {_v534_lane_line(rows)}",
        f"- 전략/발견 태그 TOP: {' / '.join(_v534_tag_top(rows, 6)) or '-'}",
        f"- 진입유형 TOP: {' / '.join(_v535_profile_top(rows, 6)) or '-'}",
        f"- S1 판정: canonical_entry_decision 단일 원천 / profile 3개 단순화",
        f"- S1 부족조건 TOP: {' / '.join(_v534_reason_top(rows, 6)) or '-'}",
        f"- 위험 상위: {' / '.join(_v520_top(rows, _v520_risks, 5)) or '-'}",
        f"- {_v534_paper_line()}",
        f"- paper 진행중 등급: {_v538_open_stage_line()}",
        "- 판독: latest S1은 현재 스냅샷, paper 진행중은 이미 handoff된 실제 OPEN입니다.",
        f"- 자원: {_v534_resource_line()}",
        "",
        "[worker 요약 · 캐시만]",
        *_v534_worker_summary_lines(),
        "",
        "[고정]",
        "- 메인봇은 장부 정리/압축/삭제를 하지 않습니다. 정리는 가드봇 /gcleanup 담당입니다.",
        "- 기본 명령은 CLOSED 전체장부 직접조회로 돌아가지 않습니다.",
    ]
    return "\n".join(lines)


def candidate_reason_text():  # type: ignore[override]
    rows = _v520_rows(400)
    counts = _v534_counts(rows)
    lines = [
        "🧭 후보판정 이유 /candidate_reason · v540 한글표시",
        "- source: paper_candidates_latest.jsonl / canonical_entry_decision 기준",
        f"- rows {len(rows)} / age {age(V520_CANDIDATE_SOURCE):.1f}s / {'신선' if age(V520_CANDIDATE_SOURCE) < 30 else '오래됨'}",
        f"- 현재 단계: S1 {counts.get('S1',0)} / S2 {counts.get('S2',0)} / S3 {counts.get('S3',0)} / 제외 {counts.get('X',0)}",
        f"- S1 부족조건 TOP: {' / '.join(_v534_reason_top(rows, 6)) or '-'}",
        f"- 전략/발견 태그 TOP: {' / '.join(_v534_tag_top(rows, 5)) or '-'}",
        f"- 진입유형 TOP: {' / '.join(_v535_profile_top(rows, 5)) or '-'}",
        f"- 위험 TOP: {' / '.join(_v520_top(rows, _v520_risks, 5)) or '-'}",
        "",
        "[상위 후보 5개]",
    ]
    if not rows:
        lines.append("- 후보 없음")
    else:
        for i, r in enumerate(rows[:5], 1):
            lines.append(_v520_row_line(r, i))
            lines.append("")
    return "\n".join(lines).rstrip()


def candidate_reason_full_text():  # type: ignore[override]
    rows = _v520_rows(1200)
    lines = [
        "🧭 후보판정 이유 상세 /candidate_reason_full · v540 한글표시",
        f"- source: paper_candidates_latest.jsonl / rows {len(rows)} / age {age(V520_CANDIDATE_SOURCE):.1f}s",
        f"- S1 부족조건 TOP: {' / '.join(_v534_reason_top(rows, 10)) or '-'}",
        f"- 전략/발견 태그 TOP: {' / '.join(_v534_tag_top(rows, 10)) or '-'}",
        "",
        "[후보 TOP 20]",
    ]
    for i, r in enumerate(rows[:20], 1):
        lines.append(_v520_row_line(r, i))
        lines.append("")
    return "\n".join(lines).rstrip()


def candidate_summary_text():  # type: ignore[override]
    rows = _v520_rows(400)
    counts = _v534_counts(rows)
    lines = [
        "🧭 후보요약 /candidate_summary · v540 한글표시",
        f"- source: paper_candidates_latest.jsonl / rows {len(rows)} / age {age(V520_CANDIDATE_SOURCE):.1f}s",
        f"- latest {len(rows)} / S1 {counts.get('S1',0)} / S2 {counts.get('S2',0)} / S3 {counts.get('S3',0)} / 제외 {counts.get('X',0)}",
        f"- S1 부족조건 TOP: {' / '.join(_v534_reason_top(rows, 6)) or '-'}",
        f"- 전략/발견 태그 TOP: {' / '.join(_v534_tag_top(rows, 5)) or '-'}",
        f"- 진입유형 TOP: {' / '.join(_v535_profile_top(rows, 5)) or '-'}",
        f"- 위험 TOP: {' / '.join(_v520_top(rows, _v520_risks, 5)) or '-'}",
        "",
        "[상위 후보]",
    ]
    for r in rows[:5]:
        lines.append(_v520_row_line(r))
        lines.append("")
    return "\n".join(lines).rstrip()


def s1_lifecycle_text():  # type: ignore[override]
    rows = _v520_rows(600)
    s1 = [r for r in rows if _v520_stage(r) == "S1"]
    near = sorted([r for r in rows if bool((_v534_decision(r).get("s1_near_miss")) or r.get("s1_near_miss"))], key=lambda r: int((_v534_decision(r).get("s1_distance") if _v534_decision(r) else r.get("s1_distance")) or 999))
    counts = _v534_counts(rows)
    lines = [
        "🧬 S1 생애주기 /s1_lifecycle · v540 한글표시",
        "- candidate_reason과 같은 latest row / canonical_entry_decision 기준입니다.",
        f"- source: paper_candidates_latest.jsonl / rows {len(rows)} / age {age(V520_CANDIDATE_SOURCE):.1f}s",
        f"- 현재: S1 {counts.get('S1',0)} / S2 {counts.get('S2',0)} / S3 {counts.get('S3',0)} / raw {len(rows)}",
        "",
        "[현재 S1 TOP]",
    ]
    if not s1:
        lines.append("- 없음")
    else:
        for i, r in enumerate(s1[:8], 1):
            lines.append(_v520_row_line(r, i))
            lines.append("")
    lines += ["", "[S1 직전 후보 TOP]"]
    if not near:
        lines.append("- 없음")
    else:
        for i, r in enumerate(near[:8], 1):
            lines.append(_v520_row_line(r, i))
            lines.append("")
    return "\n".join(lines).rstrip()


def recheck_text():  # type: ignore[override]
    rows = [r for r in _v520_rows(600) if _v520_stage(r) in ("S2", "S3")]
    counts = _v534_counts(rows)
    lines = [
        "🔎 재확인 후보 /recheck · v540 한글표시",
        "- 구 recheck cache를 보지 않고 S2/S3 latest row를 읽습니다.",
        f"- source: paper_candidates_latest.jsonl / rows {len(rows)} / age {age(V520_CANDIDATE_SOURCE):.1f}s",
        f"- 후보 {len(rows)} / S2 {counts.get('S2',0)} / S3 {counts.get('S3',0)}",
        f"- 막힘 TOP: {' / '.join(_v534_reason_top(rows, 8)) or '-'}",
        f"- 전략/발견 태그 TOP: {' / '.join(_v534_tag_top(rows, 5)) or '-'}",
        f"- 진입유형 TOP: {' / '.join(_v535_profile_top(rows, 5)) or '-'}",
        "",
        "[재확인 후보 TOP 10]",
    ]
    for i, r in enumerate(rows[:10], 1):
        lines.append(_v520_row_line(r, i))
        lines.append("")
    return "\n".join(lines).rstrip()


def version_score_text():  # type: ignore[override]
    score_path = BASE_DIR / "paper_bot_score_cache.json"
    status_path = BASE_DIR / "paper_bot_status.json"
    sc = load_json(score_path, {}) or {}
    status = load_json(status_path, {}) or {}
    lines = [
        "📊 버전별 성과 /version_score · v538 캐시 전용",
        "- 기준: paper score cache만 읽습니다. CLOSED 전체장부 직접조회는 하지 않습니다.",
        "- 수정: profile 손익은 paper cache의 total/avg 키를 직접 읽습니다.",
        f"- 메인봇: {BOT_VERSION} / {RESTORE_BUILD}",
        f"- paper: {status.get('version','-')} / status age {age(status_path):.1f}s / CLOSED누적 {status.get('closed_total', status.get('closed_count','-'))}",
        f"- 성과 캐시: age {age(score_path):.1f}s / schema {sc.get('schema','-') if isinstance(sc,dict) else '-'} / updated {sc.get('updated_at_text','-') if isinstance(sc,dict) else '-'}",
    ]
    if not isinstance(sc, dict) or not sc:
        lines.append("- ⚠️ 성과 캐시 준비 중")
        return "\n".join(lines)

    version_summary = sc.get("version_summary") if isinstance(sc.get("version_summary"), dict) else {}
    if version_summary:
        active = str(sc.get("active_main_version") or "")
        items = list(version_summary.items())
        items.sort(key=lambda kv: (0 if str(kv[0]) == active else 1, str(kv[0])))
        lines += ["", "[최근 적용판 요약 · 캐시]"]
        for k, v in items[:5]:
            if isinstance(v, dict):
                mark = "현재 " if active and str(k) == active else ""
                lines.append(f"- {mark}{k}: {_v538_format_stat(v)}")
    else:
        lines += ["", "[최근 적용판 요약 · 캐시]", "- ⚠️ version_summary 없음: paper score cache 생성부 확인 필요"]

    prof = sc.get("entry_profile_stats") if isinstance(sc.get("entry_profile_stats"), dict) else {}
    lines += ["", "[진입유형별 성과 · 캐시]"]
    if not prof:
        lines.append("- 준비 중")
    else:
        for k, v in sorted(prof.items(), key=lambda kv: _v538_profile_label(kv[0])):
            if isinstance(v, dict):
                lines.append(f"- {_v538_profile_label(k)}: {_v538_format_stat(v)}")

    pe = sc.get("profile_exit_stats") if isinstance(sc.get("profile_exit_stats"), dict) else {}
    lines += ["", "[진입유형 × 청산 이유별 성과 · 캐시]"]
    if not pe:
        lines.append("- 준비 중")
    else:
        shown = 0
        for k, v in sorted(pe.items(), key=lambda kv: str(kv[0])):
            if not isinstance(v, dict):
                continue
            p_label, e_label = _v538_profile_exit_parts(k)
            lines.append(f"- {p_label} / {e_label}: {_v538_format_stat(v)}")
            shown += 1
            if shown >= 16:
                break
        if len(pe) > shown:
            lines.append(f"- 나머지 {len(pe)-shown}개는 이후 full/상세에서 확인")

    lines += [
        "",
        "[판독]",
        "- latest S1 0이어도 /popen에 S1 진행중이 있으면 paper handoff는 살아있는 상태입니다.",
        "- 여기서 손익이 다시 0.00%만 나오면 producer 쪽 CLOSED 손익 저장을 확인해야 합니다.",
    ]
    return "\n".join(lines)

def _v526_batch_summary_text(cmds: List[str], outputs: Dict[str, str], timings: List[str], recv_delay: float, total_sec: float) -> str:  # type: ignore[override]
    rows = _v520_rows(1200)
    counts = _v534_counts(rows)
    near = sum(1 for r in rows if bool((_v534_decision(r).get("s1_near_miss")) or r.get("s1_near_miss")))
    lines = [
        "코인봇 최신 묶음 요약집",
        f"- 생성: {now_text()}",
        f"- 메인봇: {BOT_VERSION} / {RESTORE_BUILD}",
        f"- batch 접수지연: {recv_delay:.2f}s / 처리합계: {total_sec:.2f}s",
        "",
        "[명령 시간표]",
        *timings,
        "",
        "[현재 상태]",
        f"- 후보 spine: latest {len(rows)} / S1 {counts.get('S1',0)} / S2 {counts.get('S2',0)} / S3 {counts.get('S3',0)} / age {age(V520_CANDIDATE_SOURCE):.1f}s",
        f"- paper 진행중 등급: {_v538_open_stage_line()}",
        f"- 전략 lane: {_v534_lane_line(rows)}",
        f"- 1분지속 출처: {_v534_sustain_line(rows)}",
        f"- S1 근접후보: {near} / 부족TOP: {' / '.join(_v534_missing_name_top(rows, 6)) or '-'}",
        f"- S1 부족조건 TOP: {' / '.join(_v534_reason_top(rows, 6)) or '-'}",
        f"- 전략/발견 태그 TOP: {' / '.join(_v534_tag_top(rows, 6)) or '-'}",
        f"- 진입유형 TOP: {' / '.join(_v535_profile_top(rows, 6)) or '-'}",
        f"- 위험 TOP: {' / '.join(_v520_top(rows, _v520_risks, 5)) or '-'}",
        "",
        "[판단 원칙]",
        "- 청산/자동매수/BUY_READY 변경 없음.",
        "- S1 조건/부족조건은 canonical_entry_decision 한곳에서 계산합니다.",
        "- latest S1은 현재 스냅샷이고, paper 진행중은 이미 handoff된 OPEN 장부입니다.",
        "- hot-rank는 못 간 이유가 아니라 전략/발견 태그로 표시합니다.",
    ]
    for name in cmds:
        body = outputs.get(name)
        if not body:
            continue
        lines += ["", f"[/{name} 출력 요약]", _v526_limit_text(_v538_koreanize_output(body), 4600)]
    return "\n".join(lines) + "\n"



# v536 profile display helpers
def _v535_profile_top(rows: List[Dict[str, Any]], n: int = 6) -> List[str]:
    c: Counter = Counter()
    for r in rows:
        dec = _v534_decision(r) if "_v534_decision" in globals() else {}
        p = _v538_profile_key(r.get("entry_profile") or dec.get("entry_profile") or "unknown")
        c[p] += 1
    return [f"{_v538_profile_label(k)} {v}" for k, v in c.most_common(n)]

def _v535_profile_line(row: Dict[str, Any]) -> str:
    dec = _v534_decision(row) if "_v534_decision" in globals() else {}
    p = _v538_profile_label(row.get("entry_profile") or dec.get("entry_profile") or "-")
    e = _v538_exit_label(row.get("exit_profile") or dec.get("exit_profile") or "-")
    return f"   진입유형: {p} / 청산관리 {e}"


_v535_prev_row_line = _v520_row_line
def _v520_row_line(row, idx=None):  # type: ignore[override]
    txt = _v535_prev_row_line(row, idx)
    prof = _v535_profile_line(row)
    parts = txt.split("\n")
    if len(parts) >= 2 and "profile:" not in txt:
        parts.insert(2, prof)
        return "\n".join(parts)
    return txt

try:
    COMMANDS.update({
        "health": health_text,
        "candidate_reason": candidate_reason_text,
        "candidate_reason_full": candidate_reason_full_text,
        "candidate_summary": candidate_summary_text,
        "s1_lifecycle": s1_lifecycle_text,
        "recheck": recheck_text,
        "version_score": version_score_text,
        "popen": popen_text,
        "vscore": version_score_text,
    })
    COMMANDS.pop("batch", None)
    log_runtime("v538_profile_score_korean_lifecycle_loaded")
except Exception as exc:
    log_error("v538_command_register", exc)


# =============================================================================
# v539: 전략별 성과판 상단화 + 전략/구조 누락 오판 표시 정리
# - 조건/청산/자동매수/BUY_READY 변경 없음.
# - /version_score는 paper score cache만 읽고 CLOSED 전체장부 직접조회로 돌아가지 않는다.
# - 구조/전략 태그가 실제 row에 있으면 "없음/부족" 표시가 TOP 사유로 새지 않게 출력 원천을 정리한다.
# =============================================================================
V539_BUILD_LABEL = "v539_strategy_score_structure_guard"


def _v539_strategy_label(raw: Any) -> str:
    k = str(raw or "").strip()
    if not k or k in {"-", "unknown", "None", "null"}:
        return "구버전/미분류"
    norm = k.replace(" S", "").strip()
    label_map = {
        "money_reaccel_s": "돈흐름 재가속",
        "leader_momentum_s": "주도추세 지속",
        "breakout_early_s": "돌파 초입",
        "sweep_vwap_recovery_s": "저점 VWAP 회복",
        "surge_rebreak_s": "급등 후 재돌파",
        "leader_flow_adaptive_hold_s": "주도흐름 유동보유",
        "hot_rank_spike_recheck": "hot-rank 급등 재확인",
        "hot_rank_recheck": "hot-rank 급등 재확인",
        "hot-rank 급등 재확인": "hot-rank 급등 재확인",
        "공통상승조건": "공통상승조건",
        "구버전/미분류": "구버전/미분류",
    }
    if norm in label_map:
        return label_map[norm]
    # paper cache가 라벨 자체를 key로 저장한 경우는 그대로 쓰되 내부 영문/unknown만 숨긴다.
    if any(ch in norm for ch in "가-힣"):
        return norm.replace(" S", "").strip()
    return label_map.get(k, k)


def _v539_score_map(sc: Dict[str, Any], keys: Iterable[str]) -> Dict[str, Dict[str, Any]]:
    if not isinstance(sc, dict):
        return {}
    for key in keys:
        obj = sc.get(key)
        if isinstance(obj, dict) and obj:
            return {str(k): v for k, v in obj.items() if isinstance(v, dict)}
    return {}


def _v539_stat_n(item: Dict[str, Any]) -> int:
    return _v538_int_from(item, ("n", "count", "trades"), 0)


def _v539_strategy_exit_parts(raw: Any) -> Tuple[str, str]:
    s = str(raw or "unknown:-")
    if ":" in s:
        st, ex = s.split(":", 1)
    else:
        st, ex = "unknown", s
    return _v539_strategy_label(st), _v538_exit_label(ex)


def _v539_src_dicts(row: Dict[str, Any]) -> List[Dict[str, Any]]:
    out: List[Dict[str, Any]] = []
    if isinstance(row, dict):
        out.append(row)
        for key in ("entry_context", "canonical_entry_decision", "common_entry_decision", "raw", "entry_snapshot"):
            obj = row.get(key)
            if isinstance(obj, dict):
                out.append(obj)
                dec = obj.get("canonical_entry_decision") or obj.get("common_entry_decision")
                if isinstance(dec, dict):
                    out.append(dec)
    seen: set = set()
    clean: List[Dict[str, Any]] = []
    for d in out:
        ident = id(d)
        if ident not in seen:
            seen.add(ident)
            clean.append(d)
    return clean


def _v539_as_list(v: Any) -> List[str]:
    if isinstance(v, list):
        return [str(x).strip() for x in v if str(x).strip()]
    if isinstance(v, tuple):
        return [str(x).strip() for x in v if str(x).strip()]
    if isinstance(v, str) and v.strip():
        return [x.strip() for x in re.split(r"[,/|]", v) if x.strip()] or [v.strip()]
    return []


def _v539_has_strategy(row: Dict[str, Any]) -> bool:
    bad = {"", "-", "unknown", "None", "null", "구버전/미분류", "미분류"}
    keys = (
        "matched_strategy_labels", "matched_strategy_keys", "strategy_bucket_keys", "strategy_tags",
        "strategy_label", "strategy_name", "strategy", "strategy_key", "primary_strategy_key",
        "strategy_bucket_primary_label", "representative_strategy_key", "paper_strategy_key",
    )
    for src in _v539_src_dicts(row):
        for key in keys:
            val = src.get(key)
            vals = _v539_as_list(val) if isinstance(val, (list, tuple, str)) else ([str(val).strip()] if val not in (None, {}, []) else [])
            for x in vals:
                if x and x not in bad and x != "태그":
                    return True
    return False


def _v539_has_structure(row: Dict[str, Any]) -> bool:
    keys = (
        "structure_tags", "structure_good_tags", "structure", "structure_fit", "structure_summary",
        "chart_structure_tags", "matched_structure_tags",
    )
    for src in _v539_src_dicts(row):
        for key in keys:
            vals = _v539_as_list(src.get(key))
            for x in vals:
                if x and x not in {"-", "unknown", "구조없음", "없음", "None"}:
                    return True
        checks = src.get("checks")
        if isinstance(checks, list):
            for c in checks:
                if isinstance(c, dict) and str(c.get("name") or "") == "구조" and c.get("value") not in (None, "", [], {}, "-"):
                    return True
    return False


def _v539_is_strategy_or_structure_noise(text: str, has_strategy: bool, has_structure: bool) -> bool:
    s = str(text or "").strip()
    if not s:
        return True
    if "hot-rank" in s or "급등 재확인" in s or s in {"태그", "전략태그"}:
        return True
    if has_strategy and any(w in s for w in ("전략 없음", "전략없음", "전략 부족", "전략근거 부족", "전략태그", "전략 구조", "전략/구조")):
        return True
    if has_structure and any(w in s for w in ("구조 없음", "구조없음", "구조 부족", "전략구조", "runner 구조 부족", "전략/구조")):
        return True
    return False


def _v534_missing_conditions(row: Dict[str, Any]) -> List[str]:  # type: ignore[override]
    dec = _v534_decision(row)
    xs = dec.get("missing_conditions") or dec.get("display_reasons") or row.get("s1_missing_conditions") or []
    has_strategy = _v539_has_strategy(row)
    has_structure = _v539_has_structure(row)
    out: List[str] = []
    if isinstance(xs, list):
        for x in xs:
            s = str(x or "").strip()
            if _v539_is_strategy_or_structure_noise(s, has_strategy, has_structure):
                continue
            out.append(s)
    return out


def _v534_missing_names(row: Dict[str, Any]) -> List[str]:  # type: ignore[override]
    dec = _v534_decision(row)
    xs = dec.get("missing_names") or row.get("s1_missing_names") or []
    has_strategy = _v539_has_strategy(row)
    has_structure = _v539_has_structure(row)
    out: List[str] = []
    if isinstance(xs, list):
        for x in xs:
            s = str(x or "").strip()
            if not s:
                continue
            if has_strategy and "전략" in s:
                continue
            if has_structure and "구조" in s:
                continue
            out.append(s)
    return out


def version_score_text():  # type: ignore[override]
    score_path = BASE_DIR / "paper_bot_score_cache.json"
    status_path = BASE_DIR / "paper_bot_status.json"
    sc = load_json(score_path, {}) or {}
    status = load_json(status_path, {}) or {}
    lines = [
        "📊 전략별 성과 /version_score · v540 캐시 전용",
        "- 기준: paper score cache만 읽습니다. CLOSED 전체장부 직접조회는 하지 않습니다.",
        "- 순서: 전략별 성과 → 전략별 청산 이유 → 최근 적용판 → 진입유형 보조.",
        f"- 메인봇: {BOT_VERSION} / {RESTORE_BUILD}",
        f"- paper: {status.get('version','-')} / status age {age(status_path):.1f}s / CLOSED누적 {status.get('closed_total', status.get('closed_count','-'))}",
        f"- 성과 캐시: age {age(score_path):.1f}s / schema {sc.get('schema','-') if isinstance(sc,dict) else '-'} / updated {sc.get('updated_at_text','-') if isinstance(sc,dict) else '-'}",
    ]
    if not isinstance(sc, dict) or not sc:
        lines.append("- ⚠️ 성과 캐시 준비 중")
        return "\n".join(lines)

    strategy_stats = _v539_score_map(sc, ("strategy_primary_stats", "strategy_stats", "by_strategy"))
    lines += ["", "[전략별 성과 · 캐시]"]
    if not strategy_stats:
        lines.append("- ⚠️ strategy_stats 없음: paper score cache producer 확인 필요")
    else:
        shown = 0
        for k, v in sorted(strategy_stats.items(), key=lambda kv: (_v539_stat_n(kv[1]) * -1, _v539_strategy_label(kv[0]))):
            lines.append(f"- {_v539_strategy_label(k)}: {_v538_format_stat(v)}")
            shown += 1
            if shown >= 10:
                break

    strategy_exit = _v539_score_map(sc, ("strategy_exit_stats", "strategy_primary_exit_stats"))
    lines += ["", "[전략별 × 청산 이유별 성과 · 캐시]"]
    if not strategy_exit:
        lines.append("- ⚠️ 전략×청산 캐시 준비 중: paper_bot v0.175 score cache가 생성되면 표시됩니다.")
    else:
        shown = 0
        for k, v in sorted(strategy_exit.items(), key=lambda kv: (_v539_strategy_label(str(kv[0]).split(':',1)[0]), str(kv[0]))):
            st_label, ex_label = _v539_strategy_exit_parts(k)
            lines.append(f"- {st_label} / {ex_label}: {_v538_format_stat(v)}")
            shown += 1
            if shown >= 18:
                break
        if len(strategy_exit) > shown:
            lines.append(f"- 나머지 {len(strategy_exit)-shown}개는 이후 full/상세에서 확인")

    version_summary = sc.get("version_summary") if isinstance(sc.get("version_summary"), dict) else {}
    lines += ["", "[최근 적용판 요약 · 캐시]"]
    if version_summary:
        active = str(sc.get("active_main_version") or "")
        items = list(version_summary.items())
        items.sort(key=lambda kv: (0 if str(kv[0]) == active else 1, str(kv[0])))
        for k, v in items[:5]:
            if isinstance(v, dict):
                mark = "현재 " if active and str(k) == active else ""
                lines.append(f"- {mark}{k}: {_v538_format_stat(v)}")
    else:
        lines.append("- ⚠️ version_summary 없음: paper score cache 생성부 확인 필요")

    prof = sc.get("entry_profile_stats") if isinstance(sc.get("entry_profile_stats"), dict) else {}
    lines += ["", "[진입유형별 성과 · 보조]"]
    if not prof:
        lines.append("- 준비 중")
    else:
        for k, v in sorted(prof.items(), key=lambda kv: _v538_profile_label(kv[0])):
            if isinstance(v, dict):
                lines.append(f"- {_v538_profile_label(k)}: {_v538_format_stat(v)}")

    pe = sc.get("profile_exit_stats") if isinstance(sc.get("profile_exit_stats"), dict) else {}
    lines += ["", "[진입유형 × 청산 이유별 성과 · 보조]"]
    if not pe:
        lines.append("- 준비 중")
    else:
        shown = 0
        for k, v in sorted(pe.items(), key=lambda kv: str(kv[0])):
            if not isinstance(v, dict):
                continue
            p_label, e_label = _v538_profile_exit_parts(k)
            lines.append(f"- {p_label} / {e_label}: {_v538_format_stat(v)}")
            shown += 1
            if shown >= 10:
                break
        if len(pe) > shown:
            lines.append(f"- 나머지 {len(pe)-shown}개는 이후 full/상세에서 확인")

    lines += [
        "",
        "[판독]",
        "- 전략별 성과가 1순위입니다. 익절/손절은 각 전략 안에서 원인을 볼 때 사용합니다.",
        "- 구조/전략 태그가 있는 후보는 '구조 없음/전략 없음'으로 표시하지 않습니다. 그런 문구가 다시 나오면 producer 쪽 canonical row를 확인해야 합니다.",
        "- latest S1 0이어도 /popen에 S1 진행중이 있으면 paper handoff는 살아있는 상태입니다.",
    ]
    return "\n".join(lines)


# v540 batch 요약 문구만 최신화. 기존 v526 구조를 유지한다.
def _v526_batch_summary_text(cmds: List[str], outputs: Dict[str, str], timings: List[str], recv_delay: float, total_sec: float) -> str:  # type: ignore[override]
    rows = _v520_rows(1200)
    counts = _v534_counts(rows)
    near = sum(1 for r in rows if bool((_v534_decision(r).get("s1_near_miss")) or r.get("s1_near_miss")))
    lines = [
        "코인봇 최신 묶음 요약집",
        f"- 생성: {now_text()}",
        f"- 메인봇: {BOT_VERSION} / {RESTORE_BUILD}",
        f"- batch 접수지연: {recv_delay:.2f}s / 처리합계: {total_sec:.2f}s",
        "",
        "[명령 시간표]",
        *timings,
        "",
        "[현재 상태]",
        f"- 후보 spine: latest {len(rows)} / S1 {counts.get('S1',0)} / S2 {counts.get('S2',0)} / S3 {counts.get('S3',0)} / age {age(V520_CANDIDATE_SOURCE):.1f}s",
        f"- paper 진행중 등급: {_v538_open_stage_line()}",
        f"- 전략 lane: {_v534_lane_line(rows)}",
        f"- 1분지속 출처: {_v534_sustain_line(rows)}",
        f"- S1 근접후보: {near} / 부족TOP: {' / '.join(_v534_missing_name_top(rows, 6)) or '-'}",
        f"- S1 부족조건 TOP: {' / '.join(_v534_reason_top(rows, 6)) or '-'}",
        f"- 전략/발견 태그 TOP: {' / '.join(_v534_tag_top(rows, 6)) or '-'}",
        f"- 진입유형 TOP: {' / '.join(_v535_profile_top(rows, 6)) or '-'}",
        f"- 위험 TOP: {' / '.join(_v520_top(rows, _v520_risks, 5)) or '-'}",
        "",
        "[판단 원칙]",
        "- 청산/자동매수/BUY_READY 변경 없음.",
        "- S1 조건/부족조건은 canonical_entry_decision 한곳에서 계산합니다.",
        "- 전략/구조 태그가 있으면 '없음/부족' 오판 문구는 숨기고 실제 수치 부족만 봅니다.",
        "- latest S1은 현재 스냅샷이고, paper 진행중은 이미 handoff된 OPEN 장부입니다.",
        "- 성과판은 전략별을 먼저 보고, 청산 이유는 전략 내부 원인 분석에 씁니다.",
    ]
    for name in cmds:
        body = outputs.get(name)
        if not body:
            continue
        lines += ["", f"[/{name} 출력 요약]", _v526_limit_text(_v538_koreanize_output(body), 4600)]
    return "\n".join(lines) + "\n"

try:
    COMMANDS.update({
        "version_score": version_score_text,
        "vscore": version_score_text,
        "health": health_text,
        "candidate_reason": candidate_reason_text,
        "candidate_reason_full": candidate_reason_full_text,
        "candidate_summary": candidate_summary_text,
        "recheck": recheck_text,
        "s1_lifecycle": s1_lifecycle_text,
    })
    log_runtime("v539_strategy_score_structure_guard_loaded")
except Exception as exc:
    log_error("v539_command_register", exc)


# =============================================================================
# v540: 전략명 canonical 합산 + 구전략명/영문키 표시 정리
# - 조건/청산/자동매수/BUY_READY 변경 없음.
# - paper score cache에 같은 전략이 한글명/구영문키/S suffix로 갈라져도
#   /version_score와 /popen은 canonical 한글 전략명으로 합쳐서 표시한다.
# - producer(paper_bot v0.176)도 같은 canonical key로 score cache를 만든다.
# =============================================================================
V540_BUILD_LABEL = "v540_strategy_name_canonical"


def _v540_clean_strategy_raw(raw: Any) -> str:
    s = str(raw or "").strip()
    if not s or s in {"-", "None", "null", "unknown"}:
        return ""
    s = s.replace("_KRW", "").replace("KRW-", "")
    s = re.sub(r"\s+", " ", s).strip()
    # 성과 cache/OPEN 표시에서 붙는 등급 suffix만 제거한다. 전략 본문은 건드리지 않는다.
    s = re.sub(r"\s+[SABCX]$", "", s).strip()
    return s


def _v540_strategy_label(raw: Any) -> str:
    s = _v540_clean_strategy_raw(raw)
    if not s:
        return "구버전/미분류"
    low = s.lower()
    # 내부키/구전략명/라벨 변형을 같은 한글 전략명으로만 묶는다.
    if "hot-rank" in low or "hot_rank" in low or "hot rank" in low:
        return "hot-rank 급등 재확인"
    if "surge_rebreak" in low or "급등 후 재돌파" in s:
        return "급등 후 재돌파"
    if "breakout_early" in low or "돌파 초입" in s:
        return "돌파 초입"
    if "leader_flow_adaptive_hold" in low or "주도흐름 유동보유" in s:
        return "주도흐름 유동보유"
    if "leader_momentum" in low or "leader_momentum_continuation" in low or "주도추세" in s or "주도 추세" in s:
        return "주도추세 지속"
    if "sweep_vwap" in low or "저점 vwap" in low or "저점 VWAP" in s:
        return "저점 VWAP 회복"
    if "money_reaccel" in low or "money_flow_reaccel" in low or "pullback_reaccel" in low or "돈흐름 재가속" in s:
        return "돈흐름 재가속"
    if "공통상승조건" in s:
        return "공통상승조건"
    if s in {"구버전/미분류", "미분류"}:
        return "구버전/미분류"
    # 한글명은 그대로 살리되, 영문 내부키는 그대로 상단에 노출하지 않는다.
    if any("가" <= ch <= "힣" for ch in s):
        return s
    return "구버전/미분류"


def _v539_strategy_label(raw: Any) -> str:  # type: ignore[override]
    return _v540_strategy_label(raw)


def _paper_strategy_label(row_or_key: Any) -> str:  # type: ignore[override]
    if isinstance(row_or_key, dict):
        candidates = []
        for key in (
            "strategy_bucket_primary_label", "strategy_label", "strategy_name", "strategy",
            "strategy_key", "primary_strategy_key", "representative_strategy_key",
            "strategy_bucket_primary", "paper_strategy_key",
        ):
            v = row_or_key.get(key)
            if v not in (None, "", [], {}):
                candidates.append(v)
        ctx = row_or_key.get("entry_context") if isinstance(row_or_key.get("entry_context"), dict) else {}
        for key in (
            "strategy_bucket_primary_label", "strategy_label", "strategy_name", "strategy",
            "strategy_key", "primary_strategy_key", "representative_strategy_key",
            "strategy_bucket_primary", "paper_strategy_key",
        ):
            v = ctx.get(key)
            if v not in (None, "", [], {}):
                candidates.append(v)
        for v in candidates:
            lab = _v540_strategy_label(v)
            if lab != "구버전/미분류":
                return lab
        return "구버전/미분류"
    return _v540_strategy_label(row_or_key)


def _v540_empty_stat() -> Dict[str, Any]:
    return {"n": 0, "wins": 0, "losses": 0, "win_rate": 0.0, "total": 0.0, "avg": 0.0}


def _v540_merge_stat(dst: Dict[str, Any], src: Dict[str, Any]) -> Dict[str, Any]:
    if not isinstance(src, dict):
        return dst
    n = _v538_int_from(src, ("n", "count", "trades"), 0)
    wins = _v538_int_from(src, ("wins", "win", "win_count"), 0)
    losses = _v538_int_from(src, ("losses", "loss", "loss_count"), 0)
    total = _v538_num_from(src, ("total", "total_pct", "sum_pct", "profit_sum", "pnl_sum"), 0.0)
    dst["n"] = int(dst.get("n", 0)) + n
    dst["wins"] = int(dst.get("wins", 0)) + wins
    dst["losses"] = int(dst.get("losses", 0)) + losses
    dst["total"] = float(dst.get("total", 0.0)) + total
    if int(dst.get("n", 0)) > 0:
        dst["avg"] = float(dst.get("total", 0.0)) / int(dst.get("n", 0))
        dst["win_rate"] = int(dst.get("wins", 0)) * 100.0 / int(dst.get("n", 0))
    else:
        dst["avg"] = 0.0
        dst["win_rate"] = 0.0
    return dst


def _v540_merge_strategy_stats(raw_map: Dict[str, Dict[str, Any]]) -> Dict[str, Dict[str, Any]]:
    merged: Dict[str, Dict[str, Any]] = {}
    if not isinstance(raw_map, dict):
        return merged
    for k, v in raw_map.items():
        label = _v540_strategy_label(k)
        merged.setdefault(label, _v540_empty_stat())
        _v540_merge_stat(merged[label], v)
    return merged


def _v540_merge_strategy_exit_stats(raw_map: Dict[str, Dict[str, Any]]) -> Dict[str, Dict[str, Any]]:
    merged: Dict[str, Dict[str, Any]] = {}
    if not isinstance(raw_map, dict):
        return merged
    for k, v in raw_map.items():
        raw = str(k or "")
        if ":" in raw:
            st, ex = raw.split(":", 1)
        else:
            st, ex = raw, "-"
        label_key = f"{_v540_strategy_label(st)}:{ex}"
        merged.setdefault(label_key, _v540_empty_stat())
        _v540_merge_stat(merged[label_key], v)
    return merged


def _v539_strategy_exit_parts(raw: Any) -> Tuple[str, str]:  # type: ignore[override]
    s = str(raw or "구버전/미분류:-")
    if ":" in s:
        st, ex = s.split(":", 1)
    else:
        st, ex = s, "-"
    return _v540_strategy_label(st), _v538_exit_label(ex)


def version_score_text():  # type: ignore[override]
    score_path = BASE_DIR / "paper_bot_score_cache.json"
    status_path = BASE_DIR / "paper_bot_status.json"
    sc = load_json(score_path, {}) or {}
    status = load_json(status_path, {}) or {}
    lines = [
        "📊 전략별 성과 /version_score · v540 캐시 전용",
        "- 기준: paper score cache만 읽습니다. CLOSED 전체장부 직접조회는 하지 않습니다.",
        "- 순서: 전략별 성과 → 전략별 청산 이유 → 최근 적용판 → 진입유형 보조.",
        "- 전략명: 구영문키/S suffix/한글 변형은 canonical 한글명으로 합산합니다.",
        f"- 메인봇: {BOT_VERSION} / {RESTORE_BUILD}",
        f"- paper: {status.get('version','-')} / status age {age(status_path):.1f}s / CLOSED누적 {status.get('closed_total', status.get('closed_count','-'))}",
        f"- 성과 캐시: age {age(score_path):.1f}s / schema {sc.get('schema','-') if isinstance(sc,dict) else '-'} / updated {sc.get('updated_at_text','-') if isinstance(sc,dict) else '-'}",
    ]
    if not isinstance(sc, dict) or not sc:
        lines.append("- ⚠️ 성과 캐시 준비 중")
        return "\n".join(lines)

    strategy_stats_raw = _v539_score_map(sc, ("strategy_primary_stats", "strategy_stats", "by_strategy"))
    strategy_stats = _v540_merge_strategy_stats(strategy_stats_raw)
    lines += ["", "[전략별 성과 · 캐시]"]
    if not strategy_stats:
        lines.append("- ⚠️ strategy_stats 없음: paper score cache producer 확인 필요")
    else:
        shown = 0
        for k, v in sorted(strategy_stats.items(), key=lambda kv: (_v539_stat_n(kv[1]) * -1, kv[0])):
            lines.append(f"- {k}: {_v538_format_stat(v)}")
            shown += 1
            if shown >= 10:
                break

    strategy_exit_raw = _v539_score_map(sc, ("strategy_exit_stats", "strategy_primary_exit_stats"))
    strategy_exit = _v540_merge_strategy_exit_stats(strategy_exit_raw)
    lines += ["", "[전략별 × 청산 이유별 성과 · 캐시]"]
    if not strategy_exit:
        lines.append("- ⚠️ 전략×청산 캐시 준비 중: paper_bot score cache가 생성되면 표시됩니다.")
    else:
        shown = 0
        for k, v in sorted(strategy_exit.items(), key=lambda kv: (_v540_strategy_label(str(kv[0]).split(':',1)[0]), str(kv[0]))):
            st_label, ex_label = _v539_strategy_exit_parts(k)
            lines.append(f"- {st_label} / {ex_label}: {_v538_format_stat(v)}")
            shown += 1
            if shown >= 18:
                break
        if len(strategy_exit) > shown:
            lines.append(f"- 나머지 {len(strategy_exit)-shown}개는 이후 full/상세에서 확인")

    version_summary = sc.get("version_summary") if isinstance(sc.get("version_summary"), dict) else {}
    lines += ["", "[최근 적용판 요약 · 캐시]"]
    if version_summary:
        active = str(sc.get("active_main_version") or "")
        items = list(version_summary.items())
        items.sort(key=lambda kv: (0 if str(kv[0]) == active else 1, str(kv[0])))
        for k, v in items[:5]:
            if isinstance(v, dict):
                mark = "현재 " if active and str(k) == active else ""
                lines.append(f"- {mark}{k}: {_v538_format_stat(v)}")
    else:
        lines.append("- ⚠️ version_summary 없음: paper score cache 생성부 확인 필요")

    prof = sc.get("entry_profile_stats") if isinstance(sc.get("entry_profile_stats"), dict) else {}
    lines += ["", "[진입유형별 성과 · 보조]"]
    if not prof:
        lines.append("- 준비 중")
    else:
        for k, v in sorted(prof.items(), key=lambda kv: _v538_profile_label(kv[0])):
            if isinstance(v, dict):
                lines.append(f"- {_v538_profile_label(k)}: {_v538_format_stat(v)}")

    pe = sc.get("profile_exit_stats") if isinstance(sc.get("profile_exit_stats"), dict) else {}
    lines += ["", "[진입유형 × 청산 이유별 성과 · 보조]"]
    if not pe:
        lines.append("- 준비 중")
    else:
        shown = 0
        for k, v in sorted(pe.items(), key=lambda kv: str(kv[0])):
            if not isinstance(v, dict):
                continue
            p_label, e_label = _v538_profile_exit_parts(k)
            lines.append(f"- {p_label} / {e_label}: {_v538_format_stat(v)}")
            shown += 1
            if shown >= 10:
                break
        if len(pe) > shown:
            lines.append(f"- 나머지 {len(pe)-shown}개는 이후 full/상세에서 확인")

    lines += [
        "",
        "[판독]",
        "- 전략별 성과가 1순위입니다. 같은 전략명이 갈라져 보이면 producer와 reader의 canonical mapping을 먼저 확인합니다.",
        "- 구조/전략 태그가 있는 후보는 '구조 없음/전략 없음'으로 표시하지 않습니다.",
        "- latest S1 0이어도 /popen에 S1 진행중이 있으면 paper handoff는 살아있는 상태입니다.",
    ]
    return "\n".join(lines)


# v540: OPEN 표시도 canonical 전략명으로 합산한다.
def popen_text() -> str:  # type: ignore[override]
    rows = _v538_open_rows()
    lines = ["📂 모의매매 진행중 /popen · 메인봇 캐시 전용"]
    if not rows:
        return "\n".join(lines + ["진행 중 없음"])
    by_stage = Counter(_paper_grade(p) for p in rows)
    by_strategy = Counter(_paper_strategy_label(p) for p in rows)
    lines.append("등급별 진행중: " + " / ".join(f"{_v358_stage_label(k)} {v}" for k, v in by_stage.items()))
    lines.append("전략별 진행중: " + " / ".join(f"{k} {v}" for k, v in by_strategy.items()))
    lines.append("- 판독: 여기는 이미 paper가 받은 OPEN 장부입니다. latest 후보판정 S1 0과 별개로 봅니다.")
    for p in rows[:10]:
        t = _short_ticker(p.get("ticker") or p.get("symbol"))
        pnl = _pos_profit_pct(p)
        hold = _pos_hold_sec(p)
        vals = _pos_snapshot_flat(p)
        buy = vals.get("buy_ratio") or vals.get("micro_trade_buy_ratio_30") or "-"
        reason = p.get("reason") or p.get("entry_reason") or p.get("watch_note") or "진행 감시"
        try:
            buy_txt = f"{float(buy):.2f}"
        except Exception:
            buy_txt = str(buy)
        lines.append(f"- {_v358_stage_label(_paper_grade(p))} {t} / {_paper_strategy_label(p)} / 진입 {_pos_entry_price(p)} / 현재 {_pos_current_price(p)} / {pnl:+.2f}% / 보유 {int(hold//60)}분 {int(hold%60)}초 / 감시 {reason}")
        lines.append(f"  · 근거: 매수체결 {buy_txt} / 주의: {_v538_risk_text(p.get('risk_label') or p.get('risk_tags'))}")
    if len(rows) > 10:
        lines.append(f"- 나머지 {len(rows)-10}개는 이후 full에서 확인")
    return "\n".join(lines)


# v540 batch 요약 문구만 최신화. 기존 cache-only 구조 유지.
def _v526_batch_summary_text(cmds: List[str], outputs: Dict[str, str], timings: List[str], recv_delay: float, total_sec: float) -> str:  # type: ignore[override]
    rows = _v520_rows(1200)
    counts = _v534_counts(rows)
    near = sum(1 for r in rows if bool((_v534_decision(r).get("s1_near_miss")) or r.get("s1_near_miss")))
    lines = [
        "코인봇 최신 묶음 요약집",
        f"- 생성: {now_text()}",
        f"- 메인봇: {BOT_VERSION} / {RESTORE_BUILD}",
        f"- batch 접수지연: {recv_delay:.2f}s / 처리합계: {total_sec:.2f}s",
        "",
        "[명령 시간표]",
        *timings,
        "",
        "[현재 상태]",
        f"- 후보 spine: latest {len(rows)} / S1 {counts.get('S1',0)} / S2 {counts.get('S2',0)} / S3 {counts.get('S3',0)} / age {age(V520_CANDIDATE_SOURCE):.1f}s",
        f"- paper 진행중 등급: {_v538_open_stage_line()}",
        f"- 전략 lane: {_v534_lane_line(rows)}",
        f"- 1분지속 출처: {_v534_sustain_line(rows)}",
        f"- S1 근접후보: {near} / 부족TOP: {' / '.join(_v534_missing_name_top(rows, 6)) or '-'}",
        f"- S1 부족조건 TOP: {' / '.join(_v534_reason_top(rows, 6)) or '-'}",
        f"- 전략/발견 태그 TOP: {' / '.join(_v534_tag_top(rows, 6)) or '-'}",
        f"- 진입유형 TOP: {' / '.join(_v535_profile_top(rows, 6)) or '-'}",
        f"- 위험 TOP: {' / '.join(_v520_top(rows, _v520_risks, 5)) or '-'}",
        "",
        "[판단 원칙]",
        "- 청산/자동매수/BUY_READY 변경 없음.",
        "- S1 조건/부족조건은 canonical_entry_decision 한곳에서 계산합니다.",
        "- 전략명은 canonical 한글명으로 합산해 보고, 조건값은 바꾸지 않습니다.",
        "- 전략/구조 태그가 있으면 '없음/부족' 오판 문구는 숨기고 실제 수치 부족만 봅니다.",
        "- latest S1은 현재 스냅샷이고, paper 진행중은 이미 handoff된 OPEN 장부입니다.",
        "- 성과판은 전략별을 먼저 보고, 청산 이유는 전략 내부 원인 분석에 씁니다.",
    ]
    for name in cmds:
        body = outputs.get(name)
        if not body:
            continue
        lines += ["", f"[/{name} 출력 요약]", _v526_limit_text(_v538_koreanize_output(body), 4600)]
    return "\n".join(lines) + "\n"

try:
    COMMANDS.update({
        "version_score": version_score_text,
        "vscore": version_score_text,
        "popen": popen_text,
        "health": health_text,
        "candidate_reason": candidate_reason_text,
        "candidate_reason_full": candidate_reason_full_text,
        "candidate_summary": candidate_summary_text,
        "recheck": recheck_text,
        "s1_lifecycle": s1_lifecycle_text,
    })
    log_runtime("v540_strategy_name_canonical_loaded")
except Exception as exc:
    log_error("v540_command_register", exc)


# =============================================================================
# v541: 승률/수익률 핵심판정 + 후보 이유 canonical 정리 + 신선도 중복 묶음
# - 조건/청산/자동매수/BUY_READY/paper 장부 변경 없음.
# - /version_score는 전략별 승률·수익률 핵심판정을 먼저 보여준다.
# - /candidate_reason은 canonical missing_conditions 기준으로 이유를 맞춘다.
# =============================================================================

V541_BUILD_LABEL = "v541_score_summary_reason_cleanup"


def _v541_stat_value(stat: Dict[str, Any], keys: tuple, default: float = 0.0) -> float:
    return _v538_num_from(stat, keys, default) if isinstance(stat, dict) else default


def _v541_stat_n(stat: Dict[str, Any]) -> int:
    return _v538_int_from(stat, ("n", "count", "trades"), 0) if isinstance(stat, dict) else 0


def _v541_stat_summary(stat: Dict[str, Any]) -> tuple:
    n = _v541_stat_n(stat)
    wins = _v538_int_from(stat, ("wins", "win"), 0) if isinstance(stat, dict) else 0
    losses = _v538_int_from(stat, ("losses", "loss"), max(0, n - wins)) if isinstance(stat, dict) else 0
    win_rate = _v541_stat_value(stat, ("win_rate", "win_rate_pct"), (wins / n * 100.0 if n else 0.0))
    total = _v541_stat_value(stat, ("sum_pct", "total_pct", "pnl_sum_pct", "pnl_total_pct", "total"), 0.0)
    avg = _v541_stat_value(stat, ("avg_pct", "mean_pct", "pnl_avg_pct", "avg"), (total / n if n else 0.0))
    return n, wins, losses, win_rate, total, avg


def _v541_strategy_eval(stat: Dict[str, Any]) -> str:
    n, wins, losses, win_rate, total, avg = _v541_stat_summary(stat)
    if n < 10:
        return "표본부족"
    if total > 0 and avg > 0:
        return "수익권"
    if avg >= -0.03:
        return "본전권"
    if win_rate >= 35 and avg > -0.15:
        return "개선여지"
    return "손실우세"


def _v541_key_judgement_line(name: str, stat: Dict[str, Any]) -> str:
    n, wins, losses, win_rate, total, avg = _v541_stat_summary(stat)
    return f"- {name}: {n}전 / 승률 {win_rate:.1f}% / 합산 {total:+.2f}% / 평균 {avg:+.2f}% / {_v541_strategy_eval(stat)}"


def _v541_norm_condition(x: Any) -> str:
    s = str(x or "").strip()
    if not s or s in {"-", "[]", "{}", "None"}:
        return ""
    s = s.replace("신선도재확인", "신선도 재확인")
    s = re.sub(r"신선도\s*재확인\s*:?\s*micro\s*[0-9.]+s", "신선도 재확인: micro", s, flags=re.I)
    s = re.sub(r"신선도\s*재확인\s*:?\s*ws\s*[0-9.]+s", "신선도 재확인: WS", s, flags=re.I)
    s = re.sub(r"신선도\s*재확인\s*:?\s*quote\s*[0-9.]+s", "신선도 재확인: WS", s, flags=re.I)
    s = s.replace("신선도 재확인:micro", "신선도 재확인: micro")
    s = s.replace("신선도 재확인:ws", "신선도 재확인: WS")
    s = s.replace("신선도 재확인:quote", "신선도 재확인: WS")
    s = re.sub(r"\s+", " ", s).strip()
    return s


def _v541_has_strategy_or_structure(row: Dict[str, Any]) -> bool:
    dec = _v534_decision(row)
    vals = []
    for key in ("matched_strategy_labels", "structure_tags", "strategy_label", "strategy", "strategy_key"):
        v = dec.get(key) if key in dec else row.get(key)
        vals.extend(_v520_listify(v))
    return any(str(v).strip() for v in vals)


def _v541_filter_condition(row: Dict[str, Any], s: str) -> bool:
    if not s:
        return False
    low = s.lower()
    if "hot-rank" in low or "급등 재확인" in s or "전략태그" in s:
        return False
    if _v541_has_strategy_or_structure(row) and any(k in s for k in ("구조 없음", "전략 없음", "전략근거 부족", "구조 부족", "전략/구조 부족", "runner 구조 부족")):
        return False
    return True


def _v534_missing_conditions(row: Dict[str, Any]) -> List[str]:  # type: ignore[override]
    dec = _v534_decision(row)
    xs = dec.get("missing_conditions") or dec.get("display_reasons") or row.get("s1_missing_conditions") or []
    out: List[str] = []
    if isinstance(xs, list):
        seen = set()
        for x in xs:
            s = _v541_norm_condition(x)
            if not _v541_filter_condition(row, s):
                continue
            if s not in seen:
                seen.add(s)
                out.append(s)
    return out


def _v534_reason_top(rows: List[Dict[str, Any]], n: int = 8) -> List[str]:  # type: ignore[override]
    c: Counter = Counter()
    for r in rows:
        for x in _v534_missing_conditions(r):
            c[x] += 1
    return [f"{k} {v}" for k, v in c.most_common(n)]


def _v541_row_missing(row: Dict[str, Any], limit: int = 6) -> str:
    xs = _v534_missing_conditions(row)
    return _v524_join(xs, limit) if xs else "-"


def _v541_row_passed(row: Dict[str, Any], limit: int = 7) -> str:
    dec = _v534_decision(row)
    xs = dec.get("passed_conditions") or row.get("s1_passed_conditions") or []
    if not isinstance(xs, list):
        xs = _v520_listify(xs)
    out = []
    seen = set()
    for x in xs:
        s = _v541_norm_condition(x)
        if not s or s in seen:
            continue
        seen.add(s)
        out.append(s)
    return _v524_join(out, limit)


def _v541_candidate_reason_text(row: Dict[str, Any]) -> str:
    # 후보별 이유는 canonical 부족조건을 기준으로 맞춘다. 구 reason/watch_note와 섞지 않는다.
    missing = _v534_missing_conditions(row)
    if missing:
        return _v524_join(missing, 5)
    if _v520_stage(row) == "S1":
        return "S1 통과"
    return "부족조건 없음/재확인"


def _v520_row_line(row, idx=None):  # type: ignore[override]
    p = f"{idx}) " if idx is not None else "- "
    ticker = _v520_ticker(row)
    stage = _v520_stage(row)
    dec = _v534_decision(row)
    raw_strategy = row.get("strategy_label") or row.get("strategy_name") or row.get("strategy") or row.get("strategy_key") or "-"
    strategy = _v540_strategy_label(raw_strategy) if "_v540_strategy_label" in globals() else str(raw_strategy)
    matched = dec.get("matched_strategy_labels") or row.get("matched_strategy_labels") or []
    if not isinstance(matched, list):
        matched = [matched]
    risks = _v524_join(_v520_risks(row), 4)
    structs = _v524_join(_v520_structures(row), 4)
    react = _v520_metric(row, "price_reaction_pct", "reaction_pct")
    buy = _v520_metric(row, "buy_ratio")
    sustain = _v520_metric(row, "buy_sustain_1m", "buy_sustain")
    spread = _v520_metric(row, "spread_pct")
    price = _v520_metric(row, "current_price", "entry_price", "price")
    sustain_src = str(row.get("buy_sustain_1m_source") or row.get("sustain_source") or "-")
    sustain_mark = "실측" if bool(row.get("buy_sustain_1m_real")) else ("대체값" if sustain_src != "-" else "-")
    lane = str(row.get("canonical_lane") or dec.get("lane") or "-")
    lane = {"spike": "급등 재확인", "base": "base", "watch": "관찰"}.get(lane, lane)
    distance = dec.get("s1_distance", row.get("s1_distance", "-"))
    near = "S1근접" if bool(dec.get("s1_near_miss") or row.get("s1_near_miss")) else f"S1거리 {distance}"
    return (
        f"{p}{ticker} · {stage} · {strategy} · {near}\n"
        f"   전략: {_v524_join(matched, 4)} / lane {lane}\n"
        f"   {_v535_profile_line(row).strip()}\n"
        f"   수치: 반응 {react:+.2f}% / 매수 {buy:.2f} / 1분지속 {sustain:.2f}({sustain_mark}:{sustain_src}) / 스프 {spread:.2f}% / 가격 {price:g}\n"
        f"   S1통과: {_v541_row_passed(row, 7)}\n"
        f"   S1부족: {_v541_row_missing(row, 6)}\n"
        f"   이유: {_v541_candidate_reason_text(row)}\n"
        f"   구조: {structs}\n"
        f"   위험: {risks}"
    )


def _v541_current_version_lines(sc: Dict[str, Any], limit: int = 3) -> List[str]:
    version_summary = sc.get("version_summary") if isinstance(sc.get("version_summary"), dict) else {}
    active = str(sc.get("active_main_version") or BOT_VERSION.replace("수익형 ", "") or "")
    lines: List[str] = []
    if not version_summary:
        return ["- 현재판 CLOSED 요약 준비 중"]
    # active가 정확히 안 맞아도 최신 BOT_VERSION 또는 현재 문자열 우선
    preferred = []
    for k, v in version_summary.items():
        ks = str(k)
        if active and (ks == active or active in ks or ks in active):
            preferred.append((k, v))
    if not preferred:
        for k, v in version_summary.items():
            if "446" in str(k) or "445" in str(k):
                preferred.append((k, v))
    if preferred:
        for k, v in preferred[:limit]:
            if isinstance(v, dict):
                lines.append(f"- 현재 {k}: {_v538_format_stat(v)}")
    else:
        # 없으면 최근 적용판 첫 줄만 보조 표시
        for k, v in list(version_summary.items())[:1]:
            if isinstance(v, dict):
                lines.append(f"- 최근 {k}: {_v538_format_stat(v)}")
    return lines or ["- 현재판 CLOSED 요약 준비 중"]


def version_score_text():  # type: ignore[override]
    score_path = BASE_DIR / "paper_bot_score_cache.json"
    status_path = BASE_DIR / "paper_bot_status.json"
    sc = load_json(score_path, {}) or {}
    status = load_json(status_path, {}) or {}
    lines = [
        "📊 전략별 성과 /version_score · v541 핵심판정",
        "- 기준: paper score cache만 읽습니다. CLOSED 전체장부 직접조회는 하지 않습니다.",
        "- 순서: 핵심판정 → 전략별 승률·수익률 → 전략별 청산 이유 → 현재 적용판 → 진입유형 보조.",
        "- 전적 수는 누적 CLOSED 기준입니다. 최신판 판단은 [현재 적용판]을 따로 봅니다.",
        f"- 메인봇: {BOT_VERSION} / {RESTORE_BUILD}",
        f"- paper: {status.get('version','-')} / status age {age(status_path):.1f}s / CLOSED누적 {status.get('closed_total', status.get('closed_count','-'))}",
        f"- 성과 캐시: age {age(score_path):.1f}s / schema {sc.get('schema','-') if isinstance(sc,dict) else '-'} / updated {sc.get('updated_at_text','-') if isinstance(sc,dict) else '-'}",
    ]
    if not isinstance(sc, dict) or not sc:
        lines.append("- ⚠️ 성과 캐시 준비 중")
        return "\n".join(lines)

    strategy_stats_raw = _v539_score_map(sc, ("strategy_primary_stats", "strategy_stats", "by_strategy"))
    strategy_stats = _v540_merge_strategy_stats(strategy_stats_raw)
    ranked = sorted(strategy_stats.items(), key=lambda kv: (_v539_stat_n(kv[1]) * -1, kv[0]))

    lines += ["", "[전략별 핵심판정 · 승률+수익률]"]
    if not ranked:
        lines.append("- ⚠️ strategy_stats 없음: paper score cache producer 확인 필요")
    else:
        for k, v in ranked[:7]:
            lines.append(_v541_key_judgement_line(k, v))

    lines += ["", "[전략별 성과 · 캐시]"]
    if not ranked:
        lines.append("- ⚠️ strategy_stats 없음")
    else:
        for k, v in ranked[:10]:
            lines.append(f"- {k}: {_v538_format_stat(v)}")

    strategy_exit_raw = _v539_score_map(sc, ("strategy_exit_stats", "strategy_primary_exit_stats"))
    strategy_exit = _v540_merge_strategy_exit_stats(strategy_exit_raw)
    lines += ["", "[전략별 × 청산 이유별 성과 · 캐시]"]
    if not strategy_exit:
        lines.append("- ⚠️ 전략×청산 캐시 준비 중")
    else:
        shown = 0
        for k, v in sorted(strategy_exit.items(), key=lambda kv: (_v540_strategy_label(str(kv[0]).split(':',1)[0]), str(kv[0]))):
            st_label, ex_label = _v539_strategy_exit_parts(k)
            lines.append(f"- {st_label} / {ex_label}: {_v538_format_stat(v)}")
            shown += 1
            if shown >= 18:
                break
        if len(strategy_exit) > shown:
            lines.append(f"- 나머지 {len(strategy_exit)-shown}개는 이후 full/상세에서 확인")

    lines += ["", "[현재 적용판 요약 · 캐시]"]
    lines.extend(_v541_current_version_lines(sc))

    version_summary = sc.get("version_summary") if isinstance(sc.get("version_summary"), dict) else {}
    lines += ["", "[최근 적용판 요약 · 캐시]"]
    if version_summary:
        active = str(sc.get("active_main_version") or "")
        items = list(version_summary.items())
        items.sort(key=lambda kv: (0 if str(kv[0]) == active else 1, str(kv[0])))
        for k, v in items[:5]:
            if isinstance(v, dict):
                mark = "현재 " if active and str(k) == active else ""
                lines.append(f"- {mark}{k}: {_v538_format_stat(v)}")
    else:
        lines.append("- ⚠️ version_summary 없음")

    prof = sc.get("entry_profile_stats") if isinstance(sc.get("entry_profile_stats"), dict) else {}
    lines += ["", "[진입유형별 성과 · 보조]"]
    if not prof:
        lines.append("- 준비 중")
    else:
        for k, v in sorted(prof.items(), key=lambda kv: _v538_profile_label(kv[0])):
            if isinstance(v, dict):
                lines.append(f"- {_v538_profile_label(k)}: {_v538_format_stat(v)}")

    pe = sc.get("profile_exit_stats") if isinstance(sc.get("profile_exit_stats"), dict) else {}
    lines += ["", "[진입유형 × 청산 이유별 성과 · 보조]"]
    if not pe:
        lines.append("- 준비 중")
    else:
        shown = 0
        for k, v in sorted(pe.items(), key=lambda kv: str(kv[0])):
            if not isinstance(v, dict):
                continue
            p_label, e_label = _v538_profile_exit_parts(k)
            lines.append(f"- {p_label} / {e_label}: {_v538_format_stat(v)}")
            shown += 1
            if shown >= 10:
                break
        if len(pe) > shown:
            lines.append(f"- 나머지 {len(pe)-shown}개는 이후 full/상세에서 확인")

    lines += [
        "",
        "[판독]",
        "- 전략별 성과가 1순위입니다. 승률과 평균/합산 수익률을 같이 봅니다.",
        "- 누적 전적이 많아 보여도 조건판단은 현재 적용판과 최근 CLOSED를 따로 봐야 합니다.",
        "- 구조/전략 태그가 있는 후보는 '구조 없음/전략 없음'으로 표시하지 않습니다.",
        "- latest S1 0이어도 /popen에 S1 진행중이 있으면 paper handoff는 살아있는 상태입니다.",
    ]
    return "\n".join(lines)


def health_text():  # type: ignore[override]
    rows = _v520_rows(1200)
    counts = _v534_counts(rows)
    near = sum(1 for r in rows if bool((_v534_decision(r).get("s1_near_miss")) or r.get("s1_near_miss")))
    lines = [
        "🧭 건강상태 /health · v541 정리표시",
        "✅ 전체판독: worker/paper/cache 기준 표시 · 조건계산 없음",
        f"- 메인봇 {BOT_VERSION} / {RESTORE_BUILD} / uptime {int(time.time()-START_TS)}s",
        f"- 후보판정 spine: latest rows {len(rows)} / S1 {counts.get('S1',0)} / S2 {counts.get('S2',0)} / S3 {counts.get('S3',0)} / age {age(V520_CANDIDATE_SOURCE):.1f}s",
        f"- S1 근접후보: {near} / 부족TOP: {' / '.join(_v534_missing_name_top(rows, 6)) or '-'}",
        f"- 1분지속 출처: {_v534_sustain_line(rows)}",
        f"- 전략 lane: {_v534_lane_line(rows)}",
        f"- 전략/발견 태그 TOP: {' / '.join(_v534_tag_top(rows, 6)) or '-'}",
        f"- 진입유형 TOP: {' / '.join(_v535_profile_top(rows, 6)) or '-'}",
        f"- S1 판정: canonical_entry_decision 단일 원천 / 조건값 변경 없음",
        f"- S1 부족조건 TOP: {' / '.join(_v534_reason_top(rows, 6)) or '-'}",
        f"- 위험 상위: {' / '.join(_v520_top(rows, _v520_risks, 5)) or '-'}",
        f"- {_v534_paper_line()}",
        f"- paper 진행중 등급: {_v538_open_stage_line()}",
        "- 판독: latest S1은 현재 스냅샷, paper 진행중은 이미 handoff된 실제 OPEN입니다.",
        f"- 자원: {_v534_resource_line()}",
        "",
        "[worker 요약 · 캐시만]",
        *_v534_worker_summary_lines(),
        "",
        "[고정]",
        "- 메인봇은 장부 정리/압축/삭제를 하지 않습니다. 정리는 가드봇 /gcleanup 담당입니다.",
        "- 기본 명령은 CLOSED 전체장부 직접조회로 돌아가지 않습니다.",
    ]
    return "\n".join(lines)


def candidate_reason_text():  # type: ignore[override]
    rows = _v520_rows(400)
    counts = _v534_counts(rows)
    lines = [
        "🧭 후보판정 이유 /candidate_reason · v541 정리표시",
        "- source: paper_candidates_latest.jsonl / canonical_entry_decision 기준",
        f"- rows {len(rows)} / age {age(V520_CANDIDATE_SOURCE):.1f}s / {'신선' if age(V520_CANDIDATE_SOURCE) < 30 else '오래됨'}",
        f"- 현재 단계: S1 {counts.get('S1',0)} / S2 {counts.get('S2',0)} / S3 {counts.get('S3',0)} / 제외 {counts.get('X',0)}",
        f"- S1 부족조건 TOP: {' / '.join(_v534_reason_top(rows, 6)) or '-'}",
        f"- 전략/발견 태그 TOP: {' / '.join(_v534_tag_top(rows, 5)) or '-'}",
        f"- 진입유형 TOP: {' / '.join(_v535_profile_top(rows, 5)) or '-'}",
        f"- 위험 TOP: {' / '.join(_v520_top(rows, _v520_risks, 5)) or '-'}",
        "",
        "[상위 후보 5개]",
    ]
    if not rows:
        lines.append("- 후보 없음")
    else:
        for i, r in enumerate(rows[:5], 1):
            lines.append(_v520_row_line(r, i))
            lines.append("")
    return "\n".join(lines).rstrip()


def candidate_reason_full_text():  # type: ignore[override]
    rows = _v520_rows(1200)
    lines = [
        "🧭 후보판정 이유 상세 /candidate_reason_full · v541 정리표시",
        f"- source: paper_candidates_latest.jsonl / rows {len(rows)} / age {age(V520_CANDIDATE_SOURCE):.1f}s",
        f"- S1 부족조건 TOP: {' / '.join(_v534_reason_top(rows, 10)) or '-'}",
        f"- 전략/발견 태그 TOP: {' / '.join(_v534_tag_top(rows, 10)) or '-'}",
        "",
        "[후보 TOP 20]",
    ]
    for i, r in enumerate(rows[:20], 1):
        lines.append(_v520_row_line(r, i))
        lines.append("")
    return "\n".join(lines).rstrip()


def _v526_batch_summary_text(cmds: List[str], outputs: Dict[str, str], timings: List[str], recv_delay: float, total_sec: float) -> str:  # type: ignore[override]
    rows = _v520_rows(1200)
    counts = _v534_counts(rows)
    near = sum(1 for r in rows if bool((_v534_decision(r).get("s1_near_miss")) or r.get("s1_near_miss")))
    lines = [
        "코인봇 최신 묶음 요약집",
        f"- 생성: {now_text()}",
        f"- 메인봇: {BOT_VERSION} / {RESTORE_BUILD}",
        f"- batch 접수지연: {recv_delay:.2f}s / 처리합계: {total_sec:.2f}s",
        "",
        "[명령 시간표]",
        *timings,
        "",
        "[현재 상태]",
        f"- 후보 spine: latest {len(rows)} / S1 {counts.get('S1',0)} / S2 {counts.get('S2',0)} / S3 {counts.get('S3',0)} / age {age(V520_CANDIDATE_SOURCE):.1f}s",
        f"- paper 진행중 등급: {_v538_open_stage_line()}",
        f"- 전략 lane: {_v534_lane_line(rows)}",
        f"- 1분지속 출처: {_v534_sustain_line(rows)}",
        f"- S1 근접후보: {near} / 부족TOP: {' / '.join(_v534_missing_name_top(rows, 6)) or '-'}",
        f"- S1 부족조건 TOP: {' / '.join(_v534_reason_top(rows, 6)) or '-'}",
        f"- 전략/발견 태그 TOP: {' / '.join(_v534_tag_top(rows, 6)) or '-'}",
        f"- 진입유형 TOP: {' / '.join(_v535_profile_top(rows, 6)) or '-'}",
        f"- 위험 TOP: {' / '.join(_v520_top(rows, _v520_risks, 5)) or '-'}",
        "",
        "[판단 원칙]",
        "- 청산/자동매수/BUY_READY 변경 없음.",
        "- S1 조건/부족조건은 canonical_entry_decision 한곳에서 계산합니다.",
        "- 성과판은 승률과 수익률을 같이 보고, 누적 전적과 현재 적용판을 분리해서 봅니다.",
        "- 후보별 이유는 canonical S1부족 기준으로 표시합니다. 구 reason 문구와 섞지 않습니다.",
        "- latest S1은 현재 스냅샷이고, paper 진행중은 이미 handoff된 OPEN 장부입니다.",
    ]
    for name in cmds:
        body = outputs.get(name)
        if not body:
            continue
        lines += ["", f"[/{name} 출력 요약]", _v526_limit_text(_v538_koreanize_output(body), 4600)]
    return "\n".join(lines) + "\n"

try:
    COMMANDS.update({
        "version_score": version_score_text,
        "vscore": version_score_text,
        "health": health_text,
        "candidate_reason": candidate_reason_text,
        "candidate_reason_full": candidate_reason_full_text,
        "reason": candidate_reason_text,
        "why_s1": candidate_reason_text,
    })
    log_runtime("v541_score_summary_reason_cleanup_loaded")
except Exception as exc:
    log_error("v541_command_register", exc)



# =============================================================================
# v543: 전략별 승리군/손실군 비교 분석판
# - v542 감 조건판은 폐기. 조건/청산/자동매수/BUY_READY/paper 장부 변경 없음.
# - paper score cache의 strategy_outcome_analysis만 읽어 전략별 승리군/손실군 차이를 보여준다.
# =============================================================================
V543_BUILD_LABEL = "v545_multi_strategy_recheck"


def _v543_stat_obj(obj: Dict[str, Any], key: str) -> Dict[str, Any]:
    val = obj.get(key) if isinstance(obj, dict) else {}
    return val if isinstance(val, dict) else {}


def _v543_metric_obj(analysis: Dict[str, Any], metric: str) -> Dict[str, Any]:
    metrics = analysis.get("metrics") if isinstance(analysis.get("metrics"), dict) else {}
    obj = metrics.get(metric) if isinstance(metrics.get(metric), dict) else {}
    return obj


def _v543_metric_pair_text(analysis: Dict[str, Any], metric: str, label: str, suffix: str = "") -> str:
    obj = _v543_metric_obj(analysis, metric)
    win = obj.get("win") if isinstance(obj.get("win"), dict) else {}
    loss = obj.get("loss") if isinstance(obj.get("loss"), dict) else {}
    w = fnum(win.get("avg"), default=0.0)
    l = fnum(loss.get("avg"), default=0.0)
    wn = int(win.get("n") or 0)
    ln = int(loss.get("n") or 0)
    if not wn and not ln:
        return f"{label} -"
    return f"{label} 승 {w:.2f}{suffix} / 패 {l:.2f}{suffix}"


def _v543_top_dict_text(obj: Any, limit: int = 3) -> str:
    if not isinstance(obj, dict) or not obj:
        return "-"
    parts = []
    for k, v in list(obj.items())[:limit]:
        if isinstance(v, dict):
            parts.append(f"{k} {int(v.get('count') or 0)}건/{float(v.get('rate') or 0.0):.1f}%")
        else:
            parts.append(f"{k} {v}")
    return ", ".join(parts) if parts else "-"


def _v544_combo_text(obj: Any, limit: int = 3) -> str:
    if not isinstance(obj, dict) or not obj:
        return "-"
    return ", ".join(f"{k} {v}건" for k, v in list(obj.items())[:limit])


def _v544_peak_text(analysis: Dict[str, Any]) -> str:
    win = analysis.get("win_peak_summary") if isinstance(analysis.get("win_peak_summary"), dict) else {}
    loss = analysis.get("loss_peak_summary") if isinstance(analysis.get("loss_peak_summary"), dict) else {}
    if not win and not loss:
        return "최고수익/되돌림 -"
    return (
        f"최고수익 승 {fnum(win.get('peak_avg'), default=0.0):+.2f}% / 패 {fnum(loss.get('peak_avg'), default=0.0):+.2f}%"
        f" · 되돌림 패 {fnum(loss.get('giveback_avg'), default=0.0):+.2f}%"
    )


def _v544_metric_pair_text(analysis: Dict[str, Any], metric: str, label: str, suffix: str = "") -> str:
    obj = _v543_metric_obj(analysis, metric)
    win = obj.get("win") if isinstance(obj.get("win"), dict) else {}
    loss = obj.get("loss") if isinstance(obj.get("loss"), dict) else {}
    wn = int(win.get("n") or 0)
    ln = int(loss.get("n") or 0)
    if not wn and not ln:
        return f"{label} -"
    wa = fnum(win.get("avg"), default=0.0); wm = fnum(win.get("median"), default=0.0)
    la = fnum(loss.get("avg"), default=0.0); lm = fnum(loss.get("median"), default=0.0)
    return f"{label} 승 {wa:.2f}/{wm:.2f}{suffix} · 패 {la:.2f}/{lm:.2f}{suffix}"


def _v543_profit_text(analysis: Dict[str, Any]) -> str:
    avg_win = fnum(analysis.get("avg_win_pct"), default=0.0)
    avg_loss = fnum(analysis.get("avg_loss_pct"), default=0.0)
    payoff = fnum(analysis.get("payoff_ratio"), default=0.0)
    pf = fnum(analysis.get("profit_factor"), default=0.0)
    expect = fnum(analysis.get("expectancy_pct"), default=0.0)
    return f"평균익절 {avg_win:+.2f}% / 평균손절 {avg_loss:+.2f}% / 손익비 {payoff:.2f} / PF {pf:.2f} / 기대값 {expect:+.2f}%"


def _v543_auto_eval(analysis: Dict[str, Any]) -> str:
    expect = fnum(analysis.get("expectancy_pct"), default=0.0)
    payoff = fnum(analysis.get("payoff_ratio"), default=0.0)
    all_stat = _v543_stat_obj(analysis, "all")
    n = _v541_stat_n(all_stat)
    win_rate = _v541_stat_summary(all_stat)[3] if all_stat else 0.0
    if n < 20:
        return "표본부족"
    if expect >= 0.20 and payoff >= 1.2 and win_rate >= 40:
        return "자동매매 후보권"
    if expect >= 0.05 and payoff >= 1.0:
        return "개선 후보"
    if expect >= -0.05:
        return "본전권/관찰"
    return "손실군 우선분석"


def _v543_outcome_lines(sc: Dict[str, Any], limit: int = 7) -> List[str]:
    raw = sc.get("strategy_outcome_analysis") if isinstance(sc.get("strategy_outcome_analysis"), dict) else {}
    if not raw:
        return ["- ⚠️ 분석 캐시 준비 중: paper_bot_v0.179 score cache가 갱신되면 표시됩니다."]
    items = []
    for k, v in raw.items():
        if not isinstance(v, dict):
            continue
        label = _v540_strategy_label(k) if "_v540_strategy_label" in globals() else str(k)
        all_stat = _v543_stat_obj(v, "all")
        n = _v541_stat_n(all_stat)
        expect = fnum(v.get("expectancy_pct"), default=0.0)
        items.append((n, expect, label, v))
    items.sort(key=lambda x: (-x[0], x[2]))
    lines: List[str] = []
    for n, expect, label, a in items[:limit]:
        all_stat = _v543_stat_obj(a, "all")
        wins = _v543_stat_obj(a, "wins")
        losses = _v543_stat_obj(a, "losses")
        lines.append(f"- {label}: {_v538_format_stat(all_stat)} / {_v543_auto_eval(a)}")
        lines.append(f"  · 승리군 { _v541_stat_n(wins) }건 / 손실군 { _v541_stat_n(losses) }건 / {_v543_profit_text(a)}")
        lines.append("  · 진입값: " + " / ".join([
            _v544_metric_pair_text(a, "price_reaction_pct", "가격반응", "%"),
            _v544_metric_pair_text(a, "buy_ratio", "매수체결"),
            _v544_metric_pair_text(a, "buy_sustain_1m", "1분지속"),
            _v544_metric_pair_text(a, "spread_pct", "스프레드", "%"),
            _v544_metric_pair_text(a, "slippage_pct", "미끄러짐", "%"),
        ]))
        risk_obj = a.get('loss_top_risk_rates') if isinstance(a.get('loss_top_risk_rates'), dict) else a.get('loss_top_risks')
        lines.append(f"  · 손실군 위험TOP: {_v543_top_dict_text(risk_obj)} / 반복조합: {_v544_combo_text(a.get('loss_pattern_combos'))}")
        lines.append(f"  · {_v544_peak_text(a)} / 승리군 구조TOP: {_v543_top_dict_text(a.get('win_top_structures'))}")
    return lines or ["- 분석할 전략 없음"]


def _v543_goal_summary_lines(sc: Dict[str, Any]) -> List[str]:
    raw = sc.get("strategy_outcome_analysis") if isinstance(sc.get("strategy_outcome_analysis"), dict) else {}
    lines = [
        "- 목표: 하루 +7~13%, 하루 50전 이하 단타 자동매매 후보 선별.",
        "- 50전 기준 필요 평균: +0.14~0.26%/전, 수수료·슬리피지 감안 목표 +0.20~0.35%/전.",
        "- v545는 분석 보강과 여러 전략의 1차 반영을 함께 합니다. 손실유사 S1은 차단이 아니라 S2 재확인/S3 관찰로 보냅니다.",
    ]
    if raw:
        good = []
        watch = []
        for k, a in raw.items():
            if not isinstance(a, dict):
                continue
            label = _v540_strategy_label(k) if "_v540_strategy_label" in globals() else str(k)
            ev = _v543_auto_eval(a)
            if ev == "자동매매 후보권":
                good.append(label)
            elif ev in {"개선 후보", "본전권/관찰"}:
                watch.append(label)
        if good:
            lines.append("- 자동매매 후보권: " + ", ".join(good[:5]))
        if watch:
            lines.append("- 개선/관찰 후보: " + ", ".join(watch[:5]))
    return lines


_v543_prev_version_score_text = version_score_text

def version_score_text() -> str:  # type: ignore[override]
    score_path = BASE_DIR / "paper_bot_score_cache.json"
    status_path = BASE_DIR / "paper_bot_status.json"
    sc = load_json(score_path, {}) or {}
    status = load_json(status_path, {}) or {}
    lines = [
        "📊 전략별 성과 /version_score · v545 다전략 분석+반영",
        "- 기준: paper score cache만 읽습니다. CLOSED 전체장부 직접조회는 하지 않습니다.",
        "- 순서: 자동매매 목표 → 전략별 승률·수익률 → 승리군/손실군 비교 → 청산 이유 → 현재 적용판.",
        "- 조건값 전체 일괄 변경은 없습니다. v543 분석에서 근거가 나온 전략별 손실유사 조합을 S2 재확인/S3 관찰로 1차 반영했습니다.",
        f"- 메인봇: {BOT_VERSION} / {RESTORE_BUILD}",
        f"- paper: {status.get('version','-')} / status age {age(status_path):.1f}s / CLOSED누적 {status.get('closed_total', status.get('closed_count','-'))}",
        f"- 성과 캐시: age {age(score_path):.1f}s / schema {sc.get('schema','-') if isinstance(sc,dict) else '-'} / updated {sc.get('updated_at_text','-') if isinstance(sc,dict) else '-'}",
    ]
    if not isinstance(sc, dict) or not sc:
        lines.append("- ⚠️ 성과 캐시 준비 중")
        return "\n".join(lines)

    lines += ["", "[자동매매 목표 기준]"]
    lines.extend(_v543_goal_summary_lines(sc))

    strategy_stats_raw = _v539_score_map(sc, ("strategy_primary_stats", "strategy_stats", "by_strategy"))
    strategy_stats = _v540_merge_strategy_stats(strategy_stats_raw)
    ranked = sorted(strategy_stats.items(), key=lambda kv: (_v539_stat_n(kv[1]) * -1, kv[0]))
    lines += ["", "[전략별 핵심판정 · 승률+수익률]"]
    if not ranked:
        lines.append("- ⚠️ strategy_stats 없음: paper score cache producer 확인 필요")
    else:
        for k, v in ranked[:7]:
            lines.append(_v541_key_judgement_line(k, v))

    lines += ["", "[전략별 승리군/손실군 비교 · 조건수정 근거]"]
    lines.extend(_v543_outcome_lines(sc, 7))

    strategy_exit_raw = _v539_score_map(sc, ("strategy_exit_stats", "strategy_primary_exit_stats"))
    strategy_exit = _v540_merge_strategy_exit_stats(strategy_exit_raw)
    lines += ["", "[전략별 × 청산 이유별 성과 · 캐시]"]
    if not strategy_exit:
        lines.append("- ⚠️ 전략×청산 캐시 준비 중")
    else:
        shown = 0
        for k, v in sorted(strategy_exit.items(), key=lambda kv: (_v540_strategy_label(str(kv[0]).split(':',1)[0]), str(kv[0]))):
            st_label, ex_label = _v539_strategy_exit_parts(k)
            lines.append(f"- {st_label} / {ex_label}: {_v538_format_stat(v)}")
            shown += 1
            if shown >= 14:
                break
        if len(strategy_exit) > shown:
            lines.append(f"- 나머지 {len(strategy_exit)-shown}개는 이후 full/상세에서 확인")

    lines += ["", "[현재 적용판 요약 · 캐시]"]
    lines.extend(_v541_current_version_lines(sc))

    lines += [
        "",
        "[판독]",
        "- 승률 50% 근처보다 중요한 것은 평균수익률과 손익비입니다.",
        "- 손실군 반복 조합이 확인되면 차단이 아니라 S2 재확인/S3 관찰로 설계합니다.",
        "- 이번 판은 분석을 다전략으로 반영했습니다. 효과는 현재 적용판 CLOSED 30~50건에서 확인합니다.",
    ]
    return "\n".join(lines)


_v543_prev_health_text = health_text

def health_text() -> str:  # type: ignore[override]
    return _v543_prev_health_text().replace("/health · v541 정리표시", "/health · v545 다전략 분석+반영")


_v543_prev_candidate_reason_text = candidate_reason_text

def candidate_reason_text() -> str:  # type: ignore[override]
    return _v543_prev_candidate_reason_text().replace("/candidate_reason · v541 정리표시", "/candidate_reason · v545 다전략 분석+반영")


def _v526_batch_summary_text(cmds: List[str], outputs: Dict[str, str], timings: List[str], recv_delay: float, total_sec: float) -> str:  # type: ignore[override]
    rows = _v520_rows(1200)
    counts = _v534_counts(rows)
    near = sum(1 for r in rows if bool((_v534_decision(r).get("s1_near_miss")) or r.get("s1_near_miss")))
    lines = [
        "코인봇 최신 묶음 요약집",
        f"- 생성: {now_text()}",
        f"- 메인봇: {BOT_VERSION} / {RESTORE_BUILD}",
        f"- batch 접수지연: {recv_delay:.2f}s / 처리합계: {total_sec:.2f}s",
        "",
        "[명령 시간표]",
        *timings,
        "",
        "[현재 상태]",
        f"- 후보 spine: latest {len(rows)} / S1 {counts.get('S1',0)} / S2 {counts.get('S2',0)} / S3 {counts.get('S3',0)} / age {age(V520_CANDIDATE_SOURCE):.1f}s",
        f"- paper 진행중 등급: {_v538_open_stage_line()}",
        f"- 전략 lane: {_v534_lane_line(rows)}",
        f"- 1분지속 출처: {_v534_sustain_line(rows)}",
        f"- S1 근접후보: {near} / 부족TOP: {' / '.join(_v534_missing_name_top(rows, 6)) or '-'}",
        f"- S1 부족조건 TOP: {' / '.join(_v534_reason_top(rows, 6)) or '-'}",
        f"- 전략/발견 태그 TOP: {' / '.join(_v534_tag_top(rows, 6)) or '-'}",
        f"- 진입유형 TOP: {' / '.join(_v535_profile_top(rows, 6)) or '-'}",
        f"- 위험 TOP: {' / '.join(_v520_top(rows, _v520_risks, 5)) or '-'}",
        "",
        "[판단 원칙]",
        "- 청산/자동매수/BUY_READY 변경 없음.",
        "- v545는 분석 보강 + 다전략 손실유사 S1의 S2 재확인/S3 관찰 반영판입니다.",
        "- 목표는 하루 +7~13%, 50전 이하. 승률과 수익률·손익비를 같이 봅니다.",
        "- 손실군 반복 조합은 차단이 아니라 S2 재확인/S3 관찰로 반영합니다.",
        "- latest S1은 현재 스냅샷이고, paper 진행중은 이미 handoff된 OPEN 장부입니다.",
    ]
    for name in cmds:
        body = outputs.get(name)
        if not body:
            continue
        lines += ["", f"[/{name} 출력 요약]", _v526_limit_text(_v538_koreanize_output(body), 5200)]
    return "\n".join(lines) + "\n"

try:
    COMMANDS.update({
        "version_score": version_score_text,
        "vscore": version_score_text,
        "health": health_text,
        "candidate_reason": candidate_reason_text,
        "reason": candidate_reason_text,
        "why_s1": candidate_reason_text,
    })
    log_runtime("v545_multi_strategy_recheck_loaded")
except Exception as exc:
    log_error("v545_command_register", exc)

if __name__ == "__main__":
    main()
