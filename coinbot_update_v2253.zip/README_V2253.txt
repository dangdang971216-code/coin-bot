코인봇 v2253 오류 우선 통합·배포 고정판

[핵심]
- v2249~v2252에서 누적된 배포 wrapper와 서비스별 stop/drain/start 갈래를 active path에서 제거.
- 기존 안정판 v1111 원칙으로 고정: manifest → compile → alias 원자교체 → systemctl restart 1회 → fresh PID/status/writer 검수.
- Review 버전은 DEPLOY_BUNDLE workers.review에서 매번 자동 선택. 특정 버전 고정 없음.
- 계획된 Main 재시작 중 deactivating/active 상태변경 알림은 숨기고 최종판에서만 판정.
- 배포 중 디스크 정리, 파생 cache 정리, 전체 원장 scan, deep verify, 별도 stop/start, SIGKILL 복구를 실행하지 않음.

[함께 재적용]
- Main v2.13.2191: OPEN 원본·진행 중 cycle·runtime 버전 표시 수리.
- Paper v2.124: 실제 OPEN·-2% 손실방어 scope를 heartbeat에 합쳐 저장.
- Review v2.106: 최근 exact/후보품질 최대 500, 완료봉 전체 재파싱 제거.
- Guard v2.6.71: 단일 배포 owner.

[변경하지 않음]
- 상승예측 식·가중치·양수선
- 후보 기준·trigger·invalid·target·RR
- 진입·청산 계약
- OPEN/CLOSED/decision/exact 및 기존 Shadow
- 자동매수 OFF

서버 적용 전: CHECK
