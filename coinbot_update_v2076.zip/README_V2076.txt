v2076: /version_score reset-after board cleanup. No strategy/ledger/auto-buy changes. Includes v2074/v2075.
