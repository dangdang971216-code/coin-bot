코인봇 v1336 OLD_STYLE_SHADOW_COMPARE_SERVER_CHECK

목적:
- 예전 고승률 느낌의 S1/recheck 기준을 현재 CLOSED 표본에 shadow로 비교한다.
- /old_style_compare 추가.
- /score_reason_audit 안에 예전식 비교 섹션 추가.

중요:
- 예전 코드를 정확히 재실행하는 것이 아니라, v1051 계열의 buy/persist/spread/slippage/recheck 원칙을 현재 저장필드로 복원한 비교판이다.
- 후보식, trigger, invalid, target, RR, Paper selector, 청산, 자동매수 변경 없음.
- 자동매수 OFF.
- 서버 적용 전 CHECK.
