v2151: display and candidate-pipe truth only. Trading formulas, current generation, OPEN/CLOSED ledgers and auto-buy OFF are unchanged.
