코인봇 업데이트 v1228

목적:
1) v1227에서 후보 431개 저장·Paper 전달 뒤 마지막 상태기록이 auto_buy 중복으로 오류 난 문제 수리
2) 불필요한 파일 1회 안전정리 + 이후 자동정리 + 용량 단계별 경고를 Guard 본선에 연결

Strategy 수정:
- final write_status가 직접 쓰는 auto_buy 등 runtime 키는 진단 payload에서 제거 후 전달
- 후보계약·Target 개선·RR·진입·청산 변경 없음

디스크 수정:
- 1시간 지난 고아 임시파일 삭제, fresh temp와 핵심 원장 보호
- 첫 v1228 적용 시 자동정리 1회
- 평상시 6시간 / 4GB 미만 최대 1시간 간격 정리
- 4GB 미만 또는 24시간 주기 시스템 로그 정리
- 4GB 주의 / 2GB 위험 / 1GB 긴급 알림
- /gdeep_audit에서 자동정리 활성 상태 확인

절대 보존:
- OPEN/CLOSED/trade_log/decision/exact/change_verify/issue/good-S2
- 자동매수 OFF

상태:
- 로컬 7/7 PASS
- 서버 미적용 CHECK
