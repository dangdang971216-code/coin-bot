#!/usr/bin/env python3
from __future__ import annotations
import importlib.util
import json
import pathlib
import sys
import tempfile

ROOT = pathlib.Path(__file__).resolve().parent
PACKAGE_ROOT = ROOT.parent
if str(PACKAGE_ROOT) not in sys.path:
    sys.path.insert(0, str(PACKAGE_ROOT))

def load(name: str, path: pathlib.Path):
    spec = importlib.util.spec_from_file_location(name, path)
    mod = importlib.util.module_from_spec(spec)
    sys.modules[name] = mod
    assert spec and spec.loader
    spec.loader.exec_module(mod)
    return mod

def main() -> None:
    old_text = (PACKAGE_ROOT / 'baselines' / 'strategy_worker_v1.054_v1227_status_kwarg_failure.py').read_text(encoding='utf-8')
    new_text = (PACKAGE_ROOT / 'strategy_worker_v1.055.py').read_text(encoding='utf-8')
    assert "auto_buy=False,\n        **info_quality" in old_text
    assert "auto_buy=False,\n        **_v1228_final_status_extra" in new_text

    mod = load('strategy_v1228_status', PACKAGE_ROOT / 'strategy_worker_v1.055.py')
    payload = {
        'auto_buy': False,
        'evaluated': 431,
        'row_count': 431,
        'target_count': 1269,
        'diagnostic_only_v1228': 'kept',
    }
    filtered = mod._v1228_status_extra_without_explicit(payload)
    assert 'auto_buy' not in filtered
    assert 'evaluated' not in filtered
    assert filtered['diagnostic_only_v1228'] == 'kept'

    with tempfile.TemporaryDirectory() as td:
        mod.STATUS = pathlib.Path(td) / 'clean_strategy_worker_status.json'
        mod._STATUS_LAST_OBJ_V1022 = {}
        mod._STATUS_CANONICAL_PAYLOAD_V1023 = {}
        mod._LATEST_PUBLISH_STATUS_V1008 = {}
        mod._ROLE_SOURCE_STATUS_V1008 = {}
        mod.write_status(
            'running', phase='cycle_done_v1181', evaluated=431,
            row_count=431, target_count=1269, auto_buy=False, **filtered
        )
        data = json.loads(mod.STATUS.read_text(encoding='utf-8'))
        assert data['state'] == 'running'
        assert data['auto_buy'] is False
        assert data['evaluated'] == 431
        assert data['diagnostic_only_v1228'] == 'kept'
        assert not data.get('last_error')

    assert mod.VERSION == 'strategy_worker_v1.055'
    assert mod.BUILD_LABEL == 'v1228_status_kwarg_and_storage_runtime_repair_2026-07-05'
    print('PASS v1228 final cycle status: duplicate auto_buy removed, diagnostics preserved, status write succeeds')

if __name__ == '__main__':
    main()
