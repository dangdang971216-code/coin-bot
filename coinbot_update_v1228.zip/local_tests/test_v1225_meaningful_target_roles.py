#!/usr/bin/env python3
from __future__ import annotations
import importlib.util
import pathlib
import sys

ROOT = pathlib.Path(__file__).resolve().parent
PACKAGE_ROOT = ROOT.parent
if str(PACKAGE_ROOT) not in sys.path:
    sys.path.insert(0, str(PACKAGE_ROOT))


def load(name: str, path: pathlib.Path):
    spec = importlib.util.spec_from_file_location(name, path)
    mod = importlib.util.module_from_spec(spec)
    sys.modules[name] = mod
    assert spec and spec.loader
    spec.loader.exec_module(mod)
    return mod


def zone(tf: str, low: float, high: float | None = None, score: float = 70.0, touches: int = 2):
    center = (low + (high if high is not None else low)) / 2.0
    return {
        'tf': tf, 'side': 'resistance', 'price': center,
        'zone_low': low, 'zone_high': high if high is not None else low,
        'score': score, 'touch_count': touches, 'source': f'candle.{tf}',
        'atr_pct': 1.0, 'gap_pct': 0.0,
    }


def support(tf: str, low: float, high: float, score: float = 75.0):
    return {
        'tf': tf, 'side': 'support', 'price': (low + high) / 2.0,
        'zone_low': low, 'zone_high': high,
        'score': score, 'touch_count': 2, 'source': f'candle.{tf}',
        'atr_pct': 1.0, 'gap_pct': 0.0,
    }


def install_material(mod, target_case: str) -> None:
    def frame_rows(_row, tf):
        return [{'tf': tf}] * 10

    def atr(rows):
        tf = rows[0]['tf'] if rows else ''
        return {'m5': 0.7, 'm15': 1.0, 'm30': 1.0, 'h1': 1.2, 'h2': 2.0, 'h4': 5.0}.get(tf, 1.0)

    def candidates(_rows, tf, side, _price):
        if side == 'support':
            return [support(tf, 97.0, 97.2)] if tf == 'h1' else []
        if tf == 'm15':
            return [zone(tf, 100.4, 100.5)]
        if tf == 'm30':
            return [zone(tf, 100.9, 101.0, 85.0, 3)]
        if tf == 'h1':
            return [zone(tf, 103.0, 103.2, 82.0, 3)]
        if tf == 'h2':
            return [zone(tf, 106.0 if target_case == 'major' else 120.0, 106.2 if target_case == 'major' else 120.2, 78.0, 2)]
        if tf == 'h4':
            return [zone(tf, 109.0 if target_case == 'major' else 125.0, 109.2 if target_case == 'major' else 125.2, 88.0, 2)]
        return []

    mod._v1212_frame_rows = frame_rows
    mod._v1212_atr_pct = atr
    mod._v1212_zone_candidates = candidates
    mod._v1212_cost_inputs = lambda _row: {
        'spread_pct': 0.1, 'slippage_pct': 0.1, 'slippage_source': 'test',
        'fee_pct': 0.2, 'estimated_roundtrip_cost_pct': 0.5, 'complete': True,
    }
    mod._v1212_strength_factor = lambda _row: 1.0


def main() -> None:
    old = load('strategy_v1224_baseline_test', PACKAGE_ROOT / 'baselines' / 'strategy_worker_v1.051_v1224_before_target_role_fix.py')
    new = load('strategy_v1225_test', PACKAGE_ROOT / 'strategy_worker_v1.055.py')

    direct = new._v1225_select_meaningful_target([
        (0.3, zone('m30', 100.3)),
        (2.0, zone('h1', 102.0)),
        (5.0, zone('h2', 105.0)),
        (8.0, zone('h4', 108.0)),
    ], reach_limit=10.0, minimum_final_room_pct=1.2)
    assert direct['selection_mode'] == 'meaningful_major_resistance'
    assert direct['selected_zone']['tf'] == 'h2'
    assert direct['intermediate_count'] == 2
    assert direct['nearest_intermediate_zone']['tf'] == 'm30'

    fallback = new._v1225_select_meaningful_target([
        (0.4, zone('m30', 100.4)),
        (3.0, zone('h1', 103.0)),
        (15.0, zone('h2', 115.0)),
    ], reach_limit=10.0, minimum_final_room_pct=1.2)
    assert fallback['selection_mode'] == 'meaningful_setup_resistance_fallback'
    assert fallback['selected_zone']['tf'] == 'h1'

    empty = new._v1225_select_meaningful_target([
        (0.4, zone('m30', 100.4)),
        (15.0, zone('h2', 115.0)),
    ], reach_limit=10.0, minimum_final_room_pct=1.2)
    assert empty['selected_zone'] == {}
    assert empty['only_intermediate_resistance'] is True

    row = {'ticker': 'TEST', 'current_price': 100.0}
    install_material(old, 'major')
    install_material(new, 'major')
    old_plan = old._v925_current_actual_plan(dict(row))
    new_plan = new._v925_current_actual_plan(dict(row))
    assert old_plan['trigger'] == new_plan['trigger']
    assert old_plan['invalid'] == new_plan['invalid']
    assert old_plan['target']['tf'] == 'm30'
    assert new_plan['target']['tf'] == 'h2'
    assert new_plan['target_mode_v1225'] == 'meaningful_major_resistance'
    assert new_plan['intermediate_resistance_v1225']['tf'] == 'm30'
    assert new_plan['intermediate_resistance_v1225']['contract_role_v1225'] == 'obstacle_not_final_target'
    assert new_plan['structure_contract_version'] == 'structure_contract_v1225_meaningful_target_roles'
    assert new_plan['selection_diagnostics_v1216']['target']['synthetic_projection_used_v1225'] is False
    assert new_plan['entry_flow_baseline_v1221'] == old_plan['entry_flow_baseline_v1221']

    install_material(new, 'fallback')
    fallback_plan = new._v925_current_actual_plan(dict(row))
    assert fallback_plan['target']['tf'] == 'h1'
    assert fallback_plan['target_mode_v1225'] == 'meaningful_setup_resistance_fallback'

    # Remove setup fallback too: nearby m30 is only an obstacle and distant
    # major resistance must not be replaced by a synthetic ATR target.
    original_candidates = new._v1212_zone_candidates
    def only_near_and_distant(rows, tf, side, price):
        values = original_candidates(rows, tf, side, price)
        if side == 'resistance' and tf == 'h1':
            return []
        return values
    new._v1212_zone_candidates = only_near_and_distant
    no_target_plan = new._v925_current_actual_plan(dict(row))
    assert no_target_plan['target'] == {}
    reasons = no_target_plan['selection_diagnostics_v1216']['missing_reason_codes']
    assert 'target_only_intermediate_resistance_v1225' in reasons
    assert no_target_plan['selection_diagnostics_v1216']['target']['synthetic_projection_used_v1225'] is False

    compact = new._v1218_contract_summary(new_plan)
    assert compact['structure_contract_version'] == 'structure_contract_v1225_meaningful_target_roles'
    assert 'intermediate_resistance_v1225' not in compact  # v1226: full plan owns this evidence once

    text = (PACKAGE_ROOT / 'strategy_worker_v1.055.py').read_text(encoding='utf-8')
    assert 'dynamic_atr_extension_before_distant_resistance' not in text
    assert "V925_MIN_RR = 1.50" in text
    assert "V925_MIN_TARGET_ROOM_PCT = 1.20" in text
    assert "apply_swing_entry_gate = apply_swing_entry_gate__v1177_current_cycle" in text
    print('PASS v1225 near resistance role split, major target first, setup fallback, no synthetic target, trigger/invalid unchanged')


if __name__ == '__main__':
    main()
