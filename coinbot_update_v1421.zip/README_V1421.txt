v1421: Strategy S1 block root-cause audit + Main visible board. No trading rule changes. Auto-buy OFF.
