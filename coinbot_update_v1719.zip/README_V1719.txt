v1719 S1 synthesis single-writer active snapshot

목적:
- /s1_synthesis_map이 heavy display path에 의존해 snapshot 없음으로 뜨던 문제 수리.
- Strategy active fast path에서 매 cycle 단일 writer가 strategy_s1_synthesis_root_map_v1719.json을 작성.
- 후보가 0이어도 원인 snapshot을 남김.
- READY는 본선, WAIT은 안전장치라는 판독 원칙 명시.

변경 없음:
- 자동매수 OFF
- BUY_READY 강제 없음
- 조건 완화 없음
- TTL/RR/trigger/invalid/target/청산 계약 변경 없음
- 핵심 원장 재작성 없음
