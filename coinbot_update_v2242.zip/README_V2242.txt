현재 실행 중인 Guard는 같은 명령 중 새 코드를 사용할 수 없으므로
v2242 적용 뒤 /gguard_restart 1회만 필요합니다.
그 뒤부터는 /gupgrade_bundle 한 번으로 Guard 자동 재시작과 같은 ZIP 나머지 적용까지 완료합니다.
v2240·v2241은 다시 실행하지 않습니다.
