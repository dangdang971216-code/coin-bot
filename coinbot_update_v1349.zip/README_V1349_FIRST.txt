v1349 MATERIAL_FACTORY_RESTORE: restore material calculation/transport for missing materials. No selector/entry/exit/autobuy changes.
