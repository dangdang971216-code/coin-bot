import copy
import hashlib
import importlib.util
import inspect
import json
import math
import os
import tempfile
from pathlib import Path

ROOT = Path(__file__).resolve().parent
SRC = ROOT / 'strategy_worker_v1.006.py'


def load_module(base_dir: str):
    os.environ['TRADING_BOT_DIR'] = base_dir
    spec = importlib.util.spec_from_file_location('strategy_v1114', SRC)
    module = importlib.util.module_from_spec(spec)
    assert spec.loader
    spec.loader.exec_module(module)
    return module


def source_hash(func) -> str:
    return hashlib.sha256(inspect.getsource(func).encode('utf-8')).hexdigest()


with tempfile.TemporaryDirectory() as td:
    strategy = load_module(td)
    assert strategy.VERSION == 'strategy_worker_v1.006'
    assert strategy.BUILD_LABEL == 'v1114_strategy_cycle_io_and_structure_reuse_2026-06-28'

    # Trading decision owners must remain byte-identical to v1113.
    expected_hashes = {
        'apply_swing_entry_gate': '4bbc05949586c054b58e4bc1935d2d0854235fe6b5837cea2faa70707875fe17',
        '_v812_build_structure_board': '4f4f0bde7f2bae745ce9569f1dc1c8a58aef64186922032e80a1e6f4a454e430',
        'seal_canonical_candidate_keys': '29a7c21f4b89e129a5d510564eb5a38de3819d5ab8e9f0428d5637eec706fbad',
        'build_structure_lab': '1e43ac44463796de60a11659a9a77f390a731371376f29ed02e99138830578d6',
        '_v925_row_price': 'cb5eb2ebbbf3696fc07ce9b0823ed068f1bee8629a22c3cf17020daae1018055',
        '_V1114_PREV_ENTRY_PLAN_STATE': '012631f6880db44e832cd554f7693b312a71c7e57f3ab7a5679808ecef55b460',
    }
    for name, expected in expected_hashes.items():
        assert source_hash(getattr(strategy, name)) == expected, name

    nowv = 1782654000.0
    base = {
        'ticker': 'AAA', 'market': 'KRW-AAA', 'symbol': 'AAA',
        'price': 100.0, 'current_price': 100.0, 'last_price': 100.0,
        's_stage': 'S2', 'stage': 'S2', 'candidate_stage': 'S2',
        'grade': 'S2', 'candidate_grade': 'S2', 'updated_ts': nowv,
        'candidate_input_fresh_ok_v908': True, 'open_eligible': False,
        'trigger': 101.0, 'invalid': 97.0, 'target': 110.0, 'target1': 110.0,
        'entry_context': {}, 'canonical_metric_row': {},
        'structure_levels': {}, 'block_reasons': [],
        'relative_strength': 1.2, 'money_flow_score': 1.1,
        'buy_ratio': 0.55, 'price_reaction_score': 0.2,
    }
    rows = []
    for idx in range(16):
        row = copy.deepcopy(base)
        row['ticker'] = f'T{idx:03d}'
        row['market'] = 'KRW-' + row['ticker']
        row['symbol'] = row['ticker']
        rows.append(row)

    planned = strategy._v554_apply_entry_plan_state(copy.deepcopy(rows), nowv)
    resealed, _ = strategy._v732_reseal_common_uprising_promotions(planned, nowv)
    assert len(resealed) == len(rows)
    tx = strategy._V1114_STRUCTURE_TX_LAST
    assert tx['buffered_writes'] == 4
    assert tx['physical_writes'] == 1
    assert tx['writes_avoided'] == 3
    assert tx['flush_reason'] == 'promotion_reseal_complete'
    assert (Path(td) / 'clean_structure_snapshot_cache.json').exists()

    # Stable completed-candle identity must reuse the large Review detail.
    frames = {}
    for tf_index, tf in enumerate(strategy.STRUCTURE_LAB_TFS):
        frame = []
        for idx in range(36):
            price = 100 + math.sin(idx / 4) * 2 + idx * 0.03 + tf_index * 0.1
            frame.append([nowv - (36 - idx) * 60, price, price + 0.05, price + 0.4, price - 0.4, 1000 + idx])
        frames[tf] = frame
    lab_source = {
        'frames': frames,
        'frame_counts': {key: len(value) for key, value in frames.items()},
        'history_sufficient': {key: True for key in strategy.LAB_SOURCE_REQUIRED_TFS},
        'completed_candles_only': True,
        'forming_candle_excluded': True,
    }
    lab_rows = []
    candle_map = {}
    for idx in range(12):
        ticker = f'L{idx:03d}'
        lab_rows.append({
            'ticker': ticker, 'market': 'KRW-' + ticker, 'symbol': ticker,
            'price': 100.0, 'current_price': 100.0,
            's_stage': 'S2', 'stage': 'S2', 'candidate_stage': 'S2', 'grade': 'S2',
            'candidate_input_fresh_ok_v908': True, 'entry_build_key': f'key-{idx}',
            'quote_age_sec': 1.0, 'micro_age_sec': 1.0, 'orderflow_age_sec': 1.0,
        })
        candle_map[ticker] = {'structure_lab_candles': lab_source}

    _, first = strategy.attach_structure_lab(copy.deepcopy(lab_rows), nowv, candle_map_override=copy.deepcopy(candle_map), profile={})
    _, second = strategy.attach_structure_lab(copy.deepcopy(lab_rows), nowv + 1, candle_map_override=copy.deepcopy(candle_map), profile={})
    assert first['structure_lab_detail_commit_v1114']['detail_write_this_cycle'] is True
    assert second['structure_lab_detail_commit_v1114']['detail_write_this_cycle'] is False
    assert second['structure_lab_detail_commit_v1114']['detail_reused_same_snapshot'] is True
    assert second['precomputed_frame_timestamp_reuse_v1114']['strategy_contract_changed'] is False
    assert second['immutable_map_cache_no_deepcopy_v1114'] is True

print('PASS v1114 bundle')
