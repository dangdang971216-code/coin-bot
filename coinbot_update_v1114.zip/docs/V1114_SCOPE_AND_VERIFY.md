# v1114 Strategy cycle I/O and Structure Lab reuse surgery

## Included
1. Structure snapshot cache single commit
   - The active entry-plan/promotion chain historically updated `clean_structure_snapshot_cache.json` four times in one Strategy cycle.
   - v1114 keeps the same sequential read/update semantics in a thread-local transaction and performs one final atomic write/fsync after promotion reseal.
   - Expected proof: buffered_writes=4, physical_writes=1, writes_avoided=3.
2. Structure Lab detail event-driven commit
   - `clean_structure_lab_candidates_v956.json` is the large Review detail joined by `snapshot_key`.
   - When the semantic snapshot key is unchanged, v1114 reuses the existing detail and writes only the compact per-cycle status.
   - A changed snapshot is still written atomically immediately.
3. Structure Lab completed-frame reuse
   - Current last-closed timestamps already calculated during context build are reused by live freshness and event-gate checks.
   - Removes duplicate 8-timeframe cache walks without changing event state.
4. Immutable map cache copy removal
   - A newly built immutable Structure Lab map is stored directly; live refresh already makes top-level and method copies before mutation.
   - Removes an unnecessary full nested deepcopy.

## Explicitly unchanged
- Strategy mode ALT_SWING.
- Quality thresholds and rank formulas.
- Trigger, invalid, target and exit contracts.
- Actual-entry RR, target room, chase, spread, slippage and cost gates.
- OPEN 30 and cycle new OPEN 3.
- Paper v1.015 CLOSED colour fix remains as applied in v1113.
- Auto-buy remains OFF.
- OPEN/CLOSED/trade_log/decision/performance/change/issue ledgers are not included or rewritten.

## Local proof
- `strategy_worker_v1.006.py` py_compile PASS.
- Bundle test PASS.
- v1113 decision-owner source hashes unchanged:
  - apply_swing_entry_gate
  - _v812_build_structure_board
  - seal_canonical_candidate_keys
  - build_structure_lab
  - _v925_row_price
  - underlying active entry-plan function
- Synthetic equivalence:
  - entry-plan and promotion-reseal row outputs equal after version/time normalization
  - final structure snapshot cache equal
  - Structure Lab candidate views and key counters equal
  - normalized frame lookups 1320 -> 900 in the representative sample
  - same Structure Lab snapshot second large-detail write skipped

## Server proof
1. Run `/gupgrade_bundle` alone.
2. After upgrade/restart completes, Guard: `/gops_refresh` once.
3. Main in one message: `/flow_map` and `/errorlog`.
4. Expected:
   - Strategy `strategy_worker_v1.006` and one PID.
   - runtime mismatch 0 / WORKER_MULTI_INSTANCE 0.
   - no new execution error.
   - Strategy cycle and `publish_prepare_and_gate`/`structure_lab` times lower than v1113 evidence (35.49s / 11.58s / 6.33s baseline).
   - If still >=20s, do not change strategy values; use the new phase evidence for the next exact owner only.

Server status remains CHECK until fresh cycles prove the result.
