코인봇 v2196

- v2195의 Paper 알림↔성과 연결은 유지
- 실제 v2189 /pzero_reset DONE 완료시각을 현재 성과 시작점으로 고정
- 그 시각 이전 CLOSED 174건 재혼입 차단
- 초기화 이후 exact OPEN과 같은 direct decision key CLOSED만 표시
- /version_score 기존 이모지·시간구간·TOP 형식 유지
- snapshot 오류를 정상 0전으로 표시하지 않음
- 가드 v2.6.44 업그레이드 단축 유지
- 초기화 재실행 없음
- 상승예측/구조/진입/청산 변경 없음
- 자동매수 OFF

LOCAL PASS / SERVER CHECK
