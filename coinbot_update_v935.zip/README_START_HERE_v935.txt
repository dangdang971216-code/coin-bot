v935 적용본
- v934 ZIP 적용 실패를 새 버전으로 승격
- 정식 full DEPLOY_BUNDLE + exact DEPLOY_TARGET
- 적용: 가드봇 /gupgrade_bundle
- 검수: 메인봇 /batch
