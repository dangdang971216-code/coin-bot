#!/usr/bin/env python3
from __future__ import annotations
import importlib.util, json, sys, tempfile
from pathlib import Path

BASE=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(BASE))

def load(name,path):
    spec=importlib.util.spec_from_file_location(name,path)
    mod=importlib.util.module_from_spec(spec); assert spec and spec.loader
    sys.modules[name]=mod; spec.loader.exec_module(mod); return mod

review=load('review_v1247_test',BASE/'review_worker_v1.034.py')

def wj(path,obj): path.write_text(json.dumps(obj,ensure_ascii=False),encoding='utf-8')
def wr(path,rows): path.write_text(''.join(json.dumps(x,ensure_ascii=False)+'\n' for x in rows),encoding='utf-8')
def row(ticker,cycle,stage='S1'):
    return {
      'ticker':ticker,'s_stage':stage,'candidate_grade':stage,
      'candidate_pipeline_cycle_id_v1150':cycle,'current_price':100.0,'entry_price':100.0,
      'rank_score':50.0,'candidate_decision_key':f'd-{ticker}','candidate_key':f'c-{ticker}',
      'dynamic_structure_plan_v1212':{'trigger':{'price':100,'source':'cur'},'invalid':{'price':98,'source':'cur'},'target':{'price':103,'source':'cur'}},
      'v1211_structure_shadow_v1222':{'source_exact':True,'trigger':{'price':100,'source':'old'},'invalid':{'price':98.5,'source':'old'},'target':{'price':104,'source':'old'}},
    }

def request(cycle,commit):
    return {'pipeline_cycle_id':cycle,'candidate_commit_id':commit,'candidate_rows':1,'s1_count':1,'s2_count':0,'s3_count':0,
            'committed_handoff_id':'handoff-A','committed_handoff_digest':'digest-A','created_ts':1,'committed_handoff_completed_ts':1}

def last_complete(cycle,commit):
    return {'cycle_id':cycle,'candidate_commit_id':commit,'state':'NORMAL','all_required_commits':True,
            'committed_handoff_id_v1158':'handoff-A','committed_handoff_digest_v1158':'digest-A'}

with tempfile.TemporaryDirectory() as td:
    base=Path(td)
    req=request('cycle-A','commit-A')
    wr(base/'paper_candidates_latest.jsonl',[row('AAA','cycle-A')])
    wj(base/'review_observation_request_v1181.json',req)
    # Real failing server state: Strategy already started B; A remains last completed proof.
    wj(base/'clean_strategy_candidate_pipeline_status_v1150.json',{
      'state':'RUNNING','complete':False,'cycle_id':'cycle-B','candidate_commit_id':'commit-B',
      'all_required_commits_v1150':False,'last_complete_cycle_v1152':last_complete('cycle-A','commit-A')})
    rows,proof=review._v1241_stable_committed_rows(base,req,True)
    assert len(rows)==1 and proof['pipeline_proof_source_v1247']=='LAST_COMPLETE_NORMAL',proof

    review.update_version_score_review=lambda *a,**k:{'paired_matchup_v1241':{'entry_ready_pairs':1},'paper_exact_exit_replay_v1242':{}}
    result=review.process_once(base,force=True)
    assert result.get('processed') is True,result
    snap=json.loads((base/'canonical_review_snapshot_v1181.json').read_text())
    assert snap['source']['pipeline_cycle_id']=='cycle-A',snap['source']

    # Current NORMAL proof remains valid too.
    wj(base/'clean_strategy_candidate_pipeline_status_v1150.json',{
      'state':'NORMAL','complete':True,'cycle_id':'cycle-A','candidate_commit_id':'commit-A',
      'all_required_commits_v1150':True,'committed_handoff_id_v1158':'handoff-A','committed_handoff_digest_v1158':'digest-A'})
    _,proof2=review._v1241_stable_committed_rows(base,req,True)
    assert proof2['pipeline_proof_source_v1247']=='CURRENT_NORMAL',proof2

    # A different last complete generation must fail closed.
    wj(base/'clean_strategy_candidate_pipeline_status_v1150.json',{
      'state':'RUNNING','complete':False,'cycle_id':'cycle-B','candidate_commit_id':'commit-B',
      'last_complete_cycle_v1152':last_complete('cycle-X','commit-X')})
    try:
      review._v1241_stable_committed_rows(base,req,True)
      raise AssertionError('mismatched last complete accepted')
    except RuntimeError as exc:
      assert 'no completed pipeline proof' in str(exc)

    # Candidate file identity mismatch remains fail closed.
    wr(base/'paper_candidates_latest.jsonl',[row('BBB','cycle-B')])
    wj(base/'clean_strategy_candidate_pipeline_status_v1150.json',{
      'state':'RUNNING','complete':False,'cycle_id':'cycle-B','candidate_commit_id':'commit-B',
      'last_complete_cycle_v1152':last_complete('cycle-A','commit-A')})
    try:
      review._v1241_stable_committed_rows(base,req,True)
      raise AssertionError('candidate cycle mismatch accepted')
    except RuntimeError as exc:
      assert 'candidate cycle mismatch' in str(exc)

src=(BASE/'review_worker_v1.034.py').read_text()
assert review.VERSION=='review_worker_v1.034'
assert "pipeline_proof_source='LAST_COMPLETE_NORMAL'" in src
assert "last_complete_cycle_v1152" in src
assert review.AUTO_BUY is False
print('PASS 10/10')
