#!/usr/bin/env python3
from __future__ import annotations
import importlib.util
import json
import sys
import tempfile
from pathlib import Path

BASE = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(BASE))

def load(name: str, path: Path):
    spec = importlib.util.spec_from_file_location(name, path)
    mod = importlib.util.module_from_spec(spec)
    assert spec and spec.loader
    sys.modules[name] = mod
    spec.loader.exec_module(mod)
    return mod

review = load('review_v1247_fulltest', BASE/'review_worker_v1.034.py')

def row(ticker: str, cycle: str, stage: str='S1', price: float=100.0):
    return {
        'ticker': ticker,
        's_stage': stage,
        'candidate_grade': stage,
        'candidate_pipeline_cycle_id_v1150': cycle,
        'current_price': price,
        'entry_price': price,
        'rank_score': 50.0,
        'candidate_decision_key': f'd-{ticker}',
        'candidate_key': f'c-{ticker}',
        'dynamic_structure_plan_v1212': {
            'trigger': {'price': price, 'source': 'cur'},
            'invalid': {'price': price * 0.98, 'source': 'cur'},
            'target': {'price': price * 1.03, 'source': 'cur'},
        },
        'v1211_structure_shadow_v1222': {
            'source_exact': True,
            'trigger': {'price': price, 'source': 'old'},
            'invalid': {'price': price * 0.985, 'source': 'old'},
            'target': {'price': price * 1.04, 'source': 'old'},
        },
    }

def write_json(path: Path, obj):
    path.write_text(json.dumps(obj, ensure_ascii=False), encoding='utf-8')

def write_rows(path: Path, rows):
    path.write_text(''.join(json.dumps(x, ensure_ascii=False) + '\n' for x in rows), encoding='utf-8')

def set_generation(base: Path, cycle: str, commit: str, ticker: str, stage: str='S1'):
    rows = [row(ticker, cycle, stage)]
    write_rows(base/'paper_candidates_latest.jsonl', rows)
    req = {
        'pipeline_cycle_id': cycle,
        'candidate_commit_id': commit,
        'candidate_rows': 1,
        's1_count': 1 if stage == 'S1' else 0,
        's2_count': 0,
        's3_count': 1 if stage == 'S3' else 0,
        'created_ts': 1,
        'committed_handoff_completed_ts': 1,
    }
    write_json(base/'review_observation_request_v1181.json', req)
    write_json(base/'clean_strategy_candidate_pipeline_status_v1150.json', {
        'state': 'NORMAL',
        'complete': True,
        'cycle_id': cycle,
        'candidate_commit_id': commit,
        'all_required_commits_v1150': True,
    })
    return req

with tempfile.TemporaryDirectory() as td:
    base = Path(td)
    write_json(base/'canonical_review_snapshot_v1181.json', {})
    req_a = set_generation(base, 'cycle-A', 'commit-A', 'AAA', 'S1')

    # Isolate the generation-commit contract from unrelated historical review work.
    review.update_version_score_review = lambda *a, **k: {
        'paired_matchup_v1241': {'entry_ready_pairs': 1},
        'paper_exact_exit_replay_v1242': {},
    }

    original_builder = review.build_review_snapshot
    def mutate_during_build(basep, request=None, candidate_rows=None):
        # Strategy advances while Review is calculating generation A.
        write_rows(Path(basep)/'paper_candidates_latest.jsonl', [row('BBB', 'cycle-B', 'S3', 99.0)])
        return original_builder(basep, request=request, candidate_rows=candidate_rows)
    review.build_review_snapshot = mutate_during_build

    result_a = review.process_once(base, force=True)
    assert result_a.get('processed') is True, result_a
    snap_a = json.loads((base/'canonical_review_snapshot_v1181.json').read_text(encoding='utf-8'))
    assert snap_a['source']['pipeline_cycle_id'] == 'cycle-A', snap_a['source']
    assert snap_a['source']['candidate_commit_id'] == 'commit-A', snap_a['source']
    assert snap_a['candidate']['stage_counts'].get('S1') == 1, snap_a['candidate']

    # Next completed generation must also commit, proving there is no starvation.
    review.build_review_snapshot = original_builder
    set_generation(base, 'cycle-B', 'commit-B', 'BBB', 'S1')
    result_b = review.process_once(base, force=True)
    assert result_b.get('processed') is True, result_b
    snap_b = json.loads((base/'canonical_review_snapshot_v1181.json').read_text(encoding='utf-8'))
    assert snap_b['source']['pipeline_cycle_id'] == 'cycle-B', snap_b['source']
    assert snap_b['source']['candidate_commit_id'] == 'commit-B', snap_b['source']

src = (BASE/'review_worker_v1.034.py').read_text(encoding='utf-8')
spine = (BASE/'canonical_spine_v1187.py').read_text(encoding='utf-8')
assert 'candidate_rows=committed_rows' in src
assert 'candidate_generation_changed_during_build_v1241' not in src
assert 'candidate_rows: Optional[Sequence[Mapping[str, Any]]]' in spine
assert review.VERSION == 'review_worker_v1.034'
assert review.AUTO_BUY is False
print('PASS 12/12')
