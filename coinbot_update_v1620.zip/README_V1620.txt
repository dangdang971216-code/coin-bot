v1620 ACTIVE_EXECUTABLE / WAIT_REBREAK 분리판
- 오래된 trigger complete event는 WAIT_REBREAK로 보존하고 Paper selected 후보로 올리지 않음
- 새 reset→rebreak가 생긴 event만 ACTIVE_EXECUTABLE
- 기준/Gate/RR/TTL/청산/OPEN 제한/자동매수 OFF 변경 없음
