# v1118 범위

- Paper 재시작 직후 첫 full cycle 전 상태를 `STARTUP_WAIT`로 명시
- 첫 cycle 완료 후에만 funnel 상태를 `EVALUATED`로 전환
- Guard는 startup 후보를 `pending`으로 보존하고 미분류 오류로 계산하지 않음
- cycle 완료 후 실제 accounting 불일치는 기존대로 CHECK
- 후보품질·rank·진입·청산·OPEN 30/cycle 3 변경 없음

## 서버 검수

1. 재시작 직후 snapshot이면 `startup pending`으로 표시되고 `PAPER_FUNNEL_UNCLASSIFIED`가 없어야 함
2. 첫 full cycle 후 `funnel_ready=true`, `accounted=S1`, `unclassified=0`
3. FLOW-11/12/13 NORMAL
4. runtime mismatch 0 / 새 실행 오류 0
