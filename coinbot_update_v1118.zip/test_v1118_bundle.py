#!/usr/bin/env python3
from pathlib import Path
import ast, importlib.util, tempfile, os, json, hashlib
os.environ.setdefault('GUARD_BOT_TOKEN','test-token')
os.environ.setdefault('GUARD_CHAT_ID','1')
os.environ.setdefault('BOT_DIR',str(Path(tempfile.gettempdir())/'coinbot_v1118_guard_test'))
ROOT=Path(__file__).resolve().parent
PAPER=ROOT/'paper_bot_v1.018.py'
GUARD=ROOT/'backga_guard_bot_v2_5_167.py'
PREV_PAPER=ROOT/'paper_bot_v1.017.py'
PREV_GUARD=ROOT/'backga_guard_bot_v2_5_166.py'

def load(path,name):
    spec=importlib.util.spec_from_file_location(name,path)
    mod=importlib.util.module_from_spec(spec); spec.loader.exec_module(mod); return mod

def fn_dumps(path,names):
    tree=ast.parse(path.read_text(encoding='utf-8'))
    out={name:[] for name in names}
    for node in tree.body:
        if isinstance(node,(ast.FunctionDef,ast.AsyncFunctionDef)) and node.name in out:
            out[node.name].append(ast.dump(node,include_attributes=False))
    return out

for path in (PAPER,GUARD):
    compile(path.read_text(encoding='utf-8'),str(path),'exec')
p=load(PAPER,'paper_v1118_test')
g=load(GUARD,'guard_v1118_test')
assert p.VERSION=='paper_bot_v1.018'
assert 'v2.5.167' in g.VERSION and 'v1118' in g.VERSION

# The exact incident: startup status can expose 7 current S1 rows before the first
# select_candidates cycle. They must be pending, never unclassified/error.
startup_status={
    'startup_status':True,
    'paper_cycle_completed_v1118':False,
    'paper_funnel_ready_v1118':False,
    'paper_funnel_state_v1118':'STARTUP_WAIT',
    'runtime_instance_id':'paper-test-runtime',
}
startup_pick={'s1_seen':7,'paper_funnel_accounted_v1102':0}
r=g._ops_paper_funnel_readiness_v1118(startup_status,startup_pick)
assert r=={
    'ready':False,'s1_seen':7,'accounted':0,'unclassified':0,'balance_ok':True,
    'startup_pending_s1':7,'state':'STARTUP_WAIT','cycle_completed':False,
    'cycle_completed_at':None,'runtime_instance_id':'paper-test-runtime',
}

# Once a full cycle is complete, strict terminal accounting is active again.
evaluated_status={
    'startup_status':False,'paper_cycle_completed_v1118':True,
    'paper_funnel_ready_v1118':True,'paper_funnel_state_v1118':'EVALUATED',
    'paper_cycle_completed_at_v1118':123.0,'paper_cycle_runtime_instance_id_v1118':'paper-test-runtime',
}
ok_pick={'s1_seen':7,'paper_funnel_accounted_v1102':7,'paper_funnel_unclassified_v1102':0,'paper_funnel_balance_ok_v1102':True}
r2=g._ops_paper_funnel_readiness_v1118(evaluated_status,ok_pick)
assert r2['ready'] is True and r2['balance_ok'] is True and r2['unclassified']==0 and r2['startup_pending_s1']==0
bad_pick={'s1_seen':7,'paper_funnel_accounted_v1102':5,'paper_funnel_unclassified_v1102':2,'paper_funnel_balance_ok_v1102':False}
r3=g._ops_paper_funnel_readiness_v1118(evaluated_status,bad_pick)
assert r3['ready'] is True and r3['balance_ok'] is False and r3['unclassified']==2

# Paper lifecycle fields exist at both startup and completed-cycle status owners.
psrc=PAPER.read_text(encoding='utf-8')
assert "'paper_funnel_ready_v1118': False" in psrc
assert "'paper_funnel_state_v1118': 'STARTUP_WAIT'" in psrc
assert "'paper_funnel_ready_v1118': True" in psrc
assert "'paper_funnel_state_v1118': 'EVALUATED'" in psrc
assert "'startup_status': False" in psrc

# Guard must gate accounting errors on readiness and preserve pending candidates.
gsrc=GUARD.read_text(encoding='utf-8')
assert "funnel_ready and not balance_ok" in gsrc
assert "if funnel_ready and unclassified" in gsrc
assert "pending_count=(startup_pending_s1 if not funnel_ready else 0)" in gsrc
assert "첫 Paper cycle 완료 대기" in gsrc

# Trading/ledger owners are byte-for-byte AST equivalent to v1117.
trade_names={
    'process_open_positions_for_exit','open_position__L14174','commit_closed_position_exact',
    'paper_final_safety','_v926_mark_decision','select_candidates__L22385',
    'select_candidates__L23042','open_position__L23309','_v988_closed_emoji',
}
old=fn_dumps(PREV_PAPER,trade_names)
new=fn_dumps(PAPER,trade_names)
assert old==new, {k:(len(old[k]),len(new[k])) for k in trade_names if old[k]!=new[k]}

# Performance semantic heartbeat from v1117 remains present and unchanged in intent.
assert 'paper_performance_semantic_heartbeat_v1117' in psrc
assert '_ops_performance_root_cause_v1117' in gsrc

# No top-level duplicate definitions newly introduced relative to v1117.
def dupes(path):
    tree=ast.parse(path.read_text(encoding='utf-8')); counts={}
    for node in tree.body:
        if isinstance(node,(ast.FunctionDef,ast.AsyncFunctionDef)):
            counts[node.name]=counts.get(node.name,0)+1
    return {k:v for k,v in counts.items() if v>1}
# Legacy file intentionally contains versioned overrides; exact duplicate set must only add the new unique helper.
assert dupes(PAPER)==dupes(PREV_PAPER)
assert set(dupes(GUARD)).issubset(set(dupes(PREV_GUARD)))

print(json.dumps({
    'ok':True,'paper_version':p.VERSION,'guard_version':g.VERSION,
    'startup_pending':r,'evaluated_ok':r2,'evaluated_gap':r3,
    'trade_ast_digest':hashlib.sha256(json.dumps(new,sort_keys=True).encode()).hexdigest(),
},ensure_ascii=False))
