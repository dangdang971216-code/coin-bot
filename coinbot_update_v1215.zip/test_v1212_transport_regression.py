import importlib.util
import json
import sys
import tempfile
import time
import unittest
from pathlib import Path

ROOT=Path(__file__).resolve().parent
sys.path.insert(0,str(ROOT))

def load(name, filename):
    spec=importlib.util.spec_from_file_location(name,ROOT/filename)
    mod=importlib.util.module_from_spec(spec); assert spec and spec.loader
    sys.modules[name]=mod
    spec.loader.exec_module(mod)
    return mod

paper=load('paper_v1212_transport_test','paper_bot_v1.064.py')
strategy=load('strategy_v1212_transport_test','strategy_worker_v1.045.py')


class TransportRegressionTests(unittest.TestCase):
    def test_compact_candidate_preserves_v1212_contract_and_scores(self):
        row={
            'ticker':'KRW-X','stage':'S1','current_price':100.0,
            'dynamic_structure_plan_v1212':{'schema':'dynamic_structure_plan_v1212','trigger':{'rounded_price':100.1}},
            'structure_contract_v1212':{'schema':'dynamic_structure_contract_v1212'},
            'structure_contract_version':'structure_contract_v1212_dynamic_zones',
            'structure_contract_hash':'abc123',
            'structure_quality_score_v1212':74.5,
            'target_reachability_score_v1212':68.0,
            'global_entry_score_v1212':71.2,
            'global_entry_score_components_v1212':{'structure_usability':25.0},
            'dynamic_chase_limit_pct_v1212':0.42,
            'ranking_contract_version':'ranking_contract_v1212_global_dynamic_score',
            'selection_contract_version':'selection_contract_v1212_global_top_score',
        }
        out=strategy._v861_compact_row_for_latest__L24516(row)
        for key in (
            'dynamic_structure_plan_v1212','structure_contract_v1212','structure_contract_version',
            'structure_contract_hash','structure_quality_score_v1212','target_reachability_score_v1212',
            'global_entry_score_v1212','global_entry_score_components_v1212','dynamic_chase_limit_pct_v1212',
            'ranking_contract_version','selection_contract_version',
        ):
            self.assertIn(key,out)
        self.assertEqual(out['structure_contract_hash'],'abc123')

    def test_terminal_feedback_snapshot_is_loaded_once_per_selector_cycle(self):
        with tempfile.TemporaryDirectory() as td:
            root=Path(td); now=time.time()
            records={}; events=[]
            for i in range(12):
                decision=f'decision-{i}'
                events.append({
                    'ticker':f'T{i}','event_id':f'event-{i}','s_stage':'S1','candidate_grade':'S1',
                    'strategy_mode':'ALT_SWING_V977','swing_gate_decision_key_v977':decision,
                    'swing_entry_gate_v977':{
                        'schema':'swing_entry_gate_v977_single_owner','strategy_mode':'ALT_SWING_V977',
                        'hard_pass':True,'final_trade_state':'S1_PASS','decision_key':decision,
                        'risk_reward':3.0,'target_room_pct':5.0,'source_fresh':True,
                        'trigger_occurrence':{'decision_key':decision,'event_ts':now-1.0,'candidate_key':f'candidate-{i}'},
                    },
                    'candidate_created_at':now,'source_created_at':now,'current_price':100.0,'entry_context':{},
                    'paper_consumed_handoff_id_v1158':'handoff-current','candidate_pipeline_cycle_id_v1150':'cycle-current',
                })
                records[decision]={
                    'terminal_code':'STALE_TRIGGER_OCCURRENCE','trigger_event_ts':now-1.0,
                    'first_handoff_id_v1160':'handoff-current','first_pipeline_cycle_id_v1160':'cycle-current',
                    'event_uid':f'uid-{i}','first_seen_ts':now-2.0,
                }
            state_path=root/'terminal.json'
            state_path.write_text(json.dumps({'records':records}),encoding='utf-8')

            saved={name:getattr(paper,name) for name in (
                'V1159_TRIGGER_TERMINAL_FEEDBACK_STATE','V1153_PAPER_PATH_STATE','V1153_PAPER_PATH_LEDGER',
                'BOOK_RESET_CONTROL_V1044','_v1158_resolve_completed_handoff_v1158','latest_scan_filter',
                'closed_recent_ids','_v926_seed_decision_state','_v926_save_decision_state',
                '_v938_load_trigger_reach_state','_v938_save_trigger_reach_state','write_paper_timing_spine_status','load_json'
            )}
            saved_batch=paper._V1192_PAPER_PATH_BATCH
            saved_batch_last=paper._V1192_PAPER_PATH_BATCH_LAST
            counts={'terminal':0}
            try:
                paper.V1159_TRIGGER_TERMINAL_FEEDBACK_STATE=state_path
                paper.V1153_PAPER_PATH_STATE=root/'path_state.json'
                paper.V1153_PAPER_PATH_LEDGER=root/'path_events.jsonl'
                paper.BOOK_RESET_CONTROL_V1044=root/'reset.json'
                paper._V1192_PAPER_PATH_BATCH=None
                paper._V1192_PAPER_PATH_BATCH_LAST={'schema':'paper_candidate_path_batch_v1192','state':'NOT_RUN','active':False}
                handoff={'s1_rows':events,'cycle_id':'cycle-current','handoff_id_v1158':'handoff-current','completed_ts':now}
                paper._v1158_resolve_completed_handoff_v1158=lambda ctrl: ({'ready':True,'cycle_id':'cycle-current','effective_generation_source_v1158':'CURRENT_COMPLETE','committed_handoff_id_v1158':'handoff-current'},handoff)
                paper.latest_scan_filter=lambda rows,ctrl: rows
                paper.closed_recent_ids=lambda limit=2000:set()
                paper._v926_seed_decision_state=lambda open_pos:{'records':{f'decision-{i}':{'status':'OPEN'} for i in range(12)}}
                paper._v926_save_decision_state=lambda state:True
                paper._v938_load_trigger_reach_state=lambda:{}
                paper._v938_save_trigger_reach_state=lambda state:None
                paper.write_paper_timing_spine_status=lambda stats,picked:None
                original_load=saved['load_json']
                def counted_load(path,default=None):
                    if Path(path)==state_path:
                        counts['terminal']+=1
                        return original_load(path,default)
                    return default
                paper.load_json=counted_load
                picked,stats,latest=paper.select_candidates({}, {})
                self.assertEqual(len(picked),0)
                self.assertEqual(len(latest),12)
                self.assertEqual(counts['terminal'],1)
                self.assertEqual(stats['terminal_feedback_state_load_count_v1202'],1)
                self.assertEqual(stats['terminal_feedback_lookup_count_v1202'],12)
            finally:
                for name,value in saved.items(): setattr(paper,name,value)
                paper._V1192_PAPER_PATH_BATCH=saved_batch
                paper._V1192_PAPER_PATH_BATCH_LAST=saved_batch_last


if __name__=='__main__':
    unittest.main(verbosity=2)
