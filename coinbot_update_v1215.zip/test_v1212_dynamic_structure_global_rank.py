import importlib.util
import math
import pathlib
import sys
import time
import unittest
from unittest import mock

ROOT = pathlib.Path(__file__).resolve().parent


def load(name, filename):
    spec = importlib.util.spec_from_file_location(name, ROOT / filename)
    mod = importlib.util.module_from_spec(spec)
    assert spec and spec.loader
    sys.modules[name] = mod
    spec.loader.exec_module(mod)
    return mod


PAPER = load('paper_v1212_tests', 'paper_bot_v1.064.py')
STRATEGY = load('strategy_v1212_tests', 'strategy_worker_v1.045.py')
MAIN = load('main_v1212_tests', 'coinbot_main_v2_13_1143.py')


def frame(n, center, amp, step, volume=1000.0):
    now = time.time()
    out = []
    for i in range(n):
        base = center + amp * math.sin(i * math.pi / 3.0)
        out.append([
            now - (n - i) * step,
            base - amp * 0.08,
            base + amp * 0.08,
            base + amp * 0.30,
            base - amp * 0.30,
            volume * (1.7 if i % 6 == 1 else 1.0),
        ])
    return out


def structure_row(price=101.0, amp=2.0, target_above=True):
    major_center = 101.0 if target_above else 98.0
    return {
        'ticker': 'TEST',
        'current_price': price,
        'structure_lab_candles': {'frames': {
            'm5': frame(120, 100.7, max(0.7, amp * 0.35), 300),
            'm15': frame(40, 100.7, max(0.7, amp * 0.35), 900),
            'm30': frame(160, major_center, amp, 1800),
            'h1': frame(192, major_center, amp, 3600),
            'h2': frame(96, major_center, amp * 1.2, 7200),
            'h4': frame(48, major_center, amp * 1.2, 14400),
        }},
        'spread_pct': 0.08,
        'entry_slippage_confirmed': True,
        'entry_slippage_owner': 'orderflow_worker',
        'entry_slippage_source': 'best_ask_reference_orderflow_v1100',
        'entry_slippage_est_pct': 0.05,
        'fee_pct_roundtrip': 0.08,
        'relative_strength_rank_pct_v1095': 70,
        'relative_strength_pct': 1.0,
        'money_flow_score': 65,
        'market_regime_score': 60,
    }


def candidate(i, strategy, score, runner=False, rr=3.0):
    return (f'p{i}', {
        'ticker': f'T{i}',
        'paper_decision_key_v926': f'd{i}',
        'strategy_key': strategy,
        'global_entry_score_v1212': score,
        'swing_quality_rank_score': score,
        'target_room_pct': 5.0,
        'risk_reward_ratio': rr,
        'entry_price': 100.0,
        'trigger_gate': {'profile_decisions': {'spike': {'runner_pass': runner}}},
    })


class DynamicStructureTests(unittest.TestCase):
    def test_release_identity_and_legacy_writer_removed(self):
        self.assertEqual(STRATEGY.VERSION, 'strategy_worker_v1.045')
        self.assertIn('v1215_dynamic_structure_material_reconnect', STRATEGY.BUILD_LABEL)
        self.assertFalse(hasattr(STRATEGY, '_v925_legacy_audit'))

    def test_per_coin_volatility_changes_noise_and_chase(self):
        calm = STRATEGY._v925_current_actual_plan(structure_row(101.0, 1.2, True))
        volatile = STRATEGY._v925_current_actual_plan(structure_row(101.0, 4.0, True))
        self.assertEqual(calm['structure_contract_version'], 'structure_contract_v1212_dynamic_zones')
        self.assertGreater(volatile['normal_noise_pct'], calm['normal_noise_pct'])
        self.assertGreaterEqual(volatile['dynamic_chase_limit_pct'], calm['dynamic_chase_limit_pct'])
        self.assertNotEqual(volatile['structure_contract_hash'], '')

    def test_nearest_reachable_target_or_dynamic_price_discovery_target(self):
        normal = STRATEGY._v925_current_actual_plan(structure_row(101.0, 4.0, True))
        self.assertIn(normal['target_mode_v1212'], {
            'nearest_actual_resistance',
            'dynamic_atr_extension_before_distant_resistance',
        })
        self.assertGreater(normal['target']['rounded_price'], normal['trigger']['rounded_price'])
        discovery = STRATEGY._v925_current_actual_plan(structure_row(102.0, 2.0, False))
        if discovery.get('trigger') and discovery.get('invalid'):
            self.assertIn(discovery['target_mode_v1212'], {
                'dynamic_atr_price_discovery_extension',
                'dynamic_atr_extension_before_distant_resistance',
                'nearest_actual_resistance',
            })
            self.assertLessEqual(discovery['target_room_pct'], discovery['target_reach_limit_pct'] + 0.2)

    def test_exit_contract_is_explicitly_unchanged(self):
        src = (ROOT / 'strategy_worker_v1.045.py').read_text(encoding='utf-8')
        self.assertIn("row['exit_changed_v925']=False", src)
        self.assertNotIn("row['exit_changed_v925']=True", src)


class GlobalRankingTests(unittest.TestCase):
    def test_same_strategy_top_two_beat_lower_other_strategy(self):
        selected, evidence = PAPER.rank_executable_candidates_for_open([
            candidate(0, 'A', 95), candidate(1, 'A', 90),
            candidate(2, 'B', 80), candidate(3, 'C', 30),
        ], {}, 2)
        self.assertEqual([row['ticker'] for _, row in selected], ['T0', 'T1'])
        self.assertEqual(evidence['runner_reserved_slots'], 0)
        self.assertIn('all strategies compete', evidence['selection_policy'])

    def test_runner_does_not_reserve_or_displace(self):
        selected, evidence = PAPER.rank_executable_candidates_for_open([
            candidate(0, 'A', 95, False), candidate(1, 'A', 90, False),
            candidate(2, 'B', 70, True),
        ], {}, 2)
        self.assertEqual([row['ticker'] for _, row in selected], ['T0', 'T1'])
        self.assertEqual(evidence['selected_runner_count'], 0)
        self.assertEqual(evidence['selected_total'], 2)

    def test_no_forced_entry_when_all_scores_unsafe(self):
        selected, evidence = PAPER.rank_executable_candidates_for_open([
            candidate(0, 'A', 39), candidate(1, 'B', 35),
        ], {}, 2)
        self.assertEqual(selected, [])
        self.assertEqual(evidence['selected_total'], 0)
        self.assertEqual(evidence['global_score_absolute_floor'], 40.0)

    def test_two_reasonable_candidates_are_not_killed_by_percentile(self):
        selected, evidence = PAPER.rank_executable_candidates_for_open([
            candidate(0, 'A', 55), candidate(1, 'A', 54),
        ], {}, 2)
        self.assertEqual(len(selected), 2)
        self.assertLessEqual(evidence['global_score_dynamic_floor'], 54.0)


class PaperExactSafetyTests(unittest.TestCase):
    def test_cost_adjusted_rr_blocks_expensive_entry(self):
        now = time.time()
        gate = {
            'schema': 'swing_entry_gate_v977_single_owner',
            'decision_key': 'd1', 'hard_pass': True, 'final_trade_state': 'S1_PASS',
            'risk_reward': 4.0, 'target_room_pct': 4.0, 'source_fresh': True,
            'invalid_price': 99.0, 'target_price': 104.0,
            'maximum_trigger_overshoot_pct_dynamic_v1212': 0.8,
        }
        ev = {
            'strategy_mode': 'ALT_SWING_V977', 'spread_pct': 0.50,
            'entry_slippage_ts': now, 'entry_slippage_age_sec': 0.0,
            'configured_roundtrip_fee_pct': 0.08,
        }
        with mock.patch.object(PAPER, '_v988_is_s3_observation_only', return_value=False), \
             mock.patch.object(PAPER, 'copy_entry_context', return_value={}), \
             mock.patch.object(PAPER, 'build_entry_diagnostics', return_value={}), \
             mock.patch.object(PAPER, 'build_open_alert_freshness_snapshot', return_value={}), \
             mock.patch.object(PAPER, 'read_strategy_entry_gate', return_value=gate), \
             mock.patch.object(PAPER, 'read_strategy_decision_key', return_value='d1'), \
             mock.patch.object(PAPER, 'trigger_occurrence_freshness', return_value={'fresh': True}), \
             mock.patch.object(PAPER, 'evaluate_frozen_trigger', return_value={'trigger_reached': True, 'entry_price': 100.0, 'trigger_price': 100.0, 'trigger_gap_pct': 0.0}), \
             mock.patch.object(PAPER, 'micro_fresh', return_value=True), \
             mock.patch.object(PAPER, '_v925_confirmed_slippage', return_value=(0.50, 'best_ask_reference_orderflow_v1100')), \
             mock.patch.object(PAPER, '_paper_v144_reaction_proof_block', return_value=''):
            ok, reasons, diag = PAPER.paper_final_safety(ev, {})
        self.assertFalse(ok)
        self.assertIn('ACTUAL_COST_RR_LOW', diag['paper_final_safety_block_codes_v1212'])
        self.assertIn('COST_SHARE_TOO_HIGH', diag['paper_final_safety_block_codes_v1212'])

    def test_dynamic_chase_limit_is_read_from_sealed_gate(self):
        src = (ROOT / 'paper_bot_v1.064.py').read_text(encoding='utf-8')
        self.assertIn('maximum_trigger_overshoot_pct_dynamic_v1212', src)
        self.assertIn("diag['dynamic_trigger_chase_limit_pct_v1212']", src)


class ContractComparisonTests(unittest.TestCase):
    def test_contract_stats_separate_legacy_and_new_by_open_contract(self):
        now = time.time()
        rows = [
            {'structure_contract_version': 'structure_contract_v1211_legacy', 'ranking_contract_version': 'old', 'selection_contract_version': 'old', 'opened_at': now-3600, 'closed_at': now-1000, 'pnl_pct': 1.0, 'mfe_pct': 1.5, 'mae_pct': -0.3, 'giveback_pct': 0.5, 'hold_sec': 1800},
            {'structure_contract_version': 'structure_contract_v1212_dynamic_zones', 'ranking_contract_version': 'new', 'selection_contract_version': 'new', 'opened_at': now-7200, 'closed_at': now-500, 'pnl_pct': -0.5, 'mfe_pct': 0.2, 'mae_pct': -0.8, 'giveback_pct': 0.7, 'hold_sec': 900},
        ]
        root = PAPER._v1212_contract_stats(rows, now)
        contracts = root['contracts']
        self.assertEqual(contracts['structure_contract_v1211_legacy']['windows']['all']['n'], 1)
        self.assertEqual(contracts['structure_contract_v1212_dynamic_zones']['windows']['all']['n'], 1)
        self.assertEqual(len(contracts['structure_contract_v1211_legacy']['entry_time_buckets_kst']), 6)
        self.assertEqual(len(contracts['structure_contract_v1212_dynamic_zones']['entry_time_buckets_kst']), 6)

    def test_version_score_renders_both_time_windows_and_time_buckets(self):
        now = time.time()
        rows = [
            {'structure_contract_version': 'structure_contract_v1211_legacy', 'opened_at': now-3600, 'closed_at': now-1000, 'pnl_pct': 1.0, 'mfe_pct': 1.5, 'mae_pct': -0.3, 'giveback_pct': 0.5, 'hold_sec': 1800},
            {'structure_contract_version': 'structure_contract_v1212_dynamic_zones', 'opened_at': now-7200, 'closed_at': now-500, 'pnl_pct': -0.5, 'mfe_pct': 0.2, 'mae_pct': -0.8, 'giveback_pct': 0.7, 'hold_sec': 900},
        ]
        snapshot = {
            'snapshot_id': 'test', 'contract_performance_v1212': PAPER._v1212_contract_stats(rows, now),
            'windows': {}, 'counts': {}, 'performance_epoch_v1045': {'current_open_count': 0},
        }
        with mock.patch.object(MAIN, '_performance_snapshot', return_value=snapshot), \
             mock.patch.object(MAIN, 'file_age', return_value=1.0):
            text = MAIN.render_version_score_compact(())
        self.assertIn('구조선 변경 후', text)
        self.assertIn('이전 구조선', text)
        self.assertIn('최근 3시간', text)
        self.assertIn('시간대별 진입 성과', text)
        self.assertIn('20-23시', text)


class ReleaseIdentityTests(unittest.TestCase):
    def test_all_release_identities(self):
        self.assertEqual(PAPER.VERSION, 'paper_bot_v1.064')
        self.assertEqual(STRATEGY.VERSION, 'strategy_worker_v1.045')
        self.assertEqual(MAIN.BOT_VERSION, '수익형 v2.13.1143')
        self.assertIn('v1213', PAPER.BUILD_LABEL)
        self.assertIn('v1215', STRATEGY.BUILD_LABEL)
        self.assertIn('v1215', MAIN.BUILD_LABEL)


if __name__ == '__main__':
    unittest.main(verbosity=2)
