v1332 SCORE CAP MORTALITY READONLY
- Apply with /gupgrade_bundle first.
- Then run /grelease_verify and main /score_reason_audit.
- Audit only: no Strategy/Paper scoring, entry, exit, trigger, invalid, target, RR, or auto-buy changes.
