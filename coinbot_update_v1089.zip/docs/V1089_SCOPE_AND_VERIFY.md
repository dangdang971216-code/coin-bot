# v1089 운영 지도 완성판

- Guard v2.5.143 / Main v2.13.1077
- canonical collector 1개, current snapshot 1개, append-only history 1개
- 함수·caller·wrapper/fallback 상세, 값 owner, 명령 계약, 데이터 계보, phase/queue/network, 자원 시간축, 장부 writer/reader 누적증거, diff/anomaly/history/Paper focus 포함
- 기존 v1087 snapshot reader/writer 중단. 구 파일 fallback 없음.
- Paper/Strategy/Risk/Review/worker/전략/진입/청산/OPEN 한도/핵심 장부 형식 변경 없음
- 자동수정·삭제·재시작 없음, 자동매수 OFF
