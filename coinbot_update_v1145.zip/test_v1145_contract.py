import importlib.util
import json
import os
import tempfile
from pathlib import Path

ROOT=Path(__file__).resolve().parent


def load_guard(bot_dir: Path):
    os.environ['BOT_DIR']=str(bot_dir)
    os.environ.setdefault('GUARD_BOT_TOKEN','dummy-token')
    os.environ.setdefault('GUARD_CHAT_ID','1')
    spec=importlib.util.spec_from_file_location('guard_v1145',ROOT/'backga_guard_bot_v2_5_186.py')
    mod=importlib.util.module_from_spec(spec)
    spec.loader.exec_module(mod)
    return mod


with tempfile.TemporaryDirectory() as td:
    td=Path(td)
    guard=load_guard(td)
    raw=[
        {'from':'risk','to':'strategy','artifact':{
            'name':'clean_risk_filter_cache.json','status':'CHECK','freshness_policy':'MAX_AGE',
            'event_driven_contract':{
                'applicable':True,'state':'CHECK_OUTPUT_NOT_REFRESHED_AFTER_SOURCE_CHANGE',
                'source_changed_after_output':True,'heartbeat_fresh':True,'output_mtime':1.0,'status_ts':2.0,
                'sources':[{'name':'paper_bot_open.json','newer_than_output':True}],
            },
        }},
        {'from':'risk','to':'paper','artifact':{
            'name':'clean_risk_filter_cache.json','status':'CHECK','freshness_policy':'MAX_AGE',
            'event_driven_contract':{
                'applicable':True,'state':'CHECK_OUTPUT_NOT_REFRESHED_AFTER_SOURCE_CHANGE',
                'source_changed_after_output':True,'heartbeat_fresh':True,
            },
        }},
        {'from':'performance','to':'main','artifact':{
            'name':'canonical_performance_snapshot_v987.json','status':'NORMAL','freshness_policy':'MAX_AGE',
            'event_driven_contract':{
                'applicable':True,'state':'CHECK_OWNER_HEARTBEAT_STALE',
                'source_changed_after_output':True,'heartbeat_fresh':False,
            },
        }},
    ]
    proven_root={
        'diagnosis_state':'PROVEN_EVENT_DRIVEN_IDLE','certainty':'PROVEN','owner':'semantic-owner',
        'root_cause':'semantic current','artifact_policy':'SEMANTIC_SIGNATURE_EVENT_DRIVEN',
    }
    roots={'risk':dict(proven_root,owner='risk_worker'),'performance':dict(proven_root,owner='paper_writer')}
    final=guard._ops_finalize_semantic_lineage_v1145(raw,roots)
    assert len(final)==3
    assert guard._ops_final_semantic_edge_checks_v1145(final)==[]
    for row in final:
        art=row['artifact']
        final_owner=art['final_semantic_edge_v1145']
        assert art['status']=='NORMAL'
        assert art['semantic_status']=='EVENT_DRIVEN_IDLE'
        assert art['event_driven_contract']['state']=='PROVEN_EVENT_DRIVEN_IDLE'
        assert art['event_driven_contract']['raw_evidence_reference_v1145']['judgement_owner']=='REFERENCE_ONLY_NOT_A_VERDICT'
        assert row['final_edge_digest_v1145']==final_owner['digest']
        assert row['final_semantic_owner_v1145']['digest']==final_owner['digest']

    failed_roots={
        'risk':{'diagnosis_state':'CHECK_RISK_WRITER','owner':'risk_worker','root_cause':'heartbeat stale','artifact_policy':'SEMANTIC_FINGERPRINT_EVENT_DRIVEN'},
        'performance':{'diagnosis_state':'CHECK_PERFORMANCE_WRITER','owner':'paper_writer','root_cause':'signature stale','artifact_policy':'SEMANTIC_SIGNATURE_EVENT_DRIVEN'},
    }
    failed=guard._ops_finalize_semantic_lineage_v1145(raw,failed_roots)
    checks=guard._ops_final_semantic_edge_checks_v1145(failed)
    assert len(checks)==3
    for row in checks:
        art=row['artifact']
        assert art['status']=='CHECK'
        assert art['semantic_status']=='SEMANTIC_OWNER_NOT_PROVEN'
        assert art['event_driven_contract']['state'].startswith('CHECK_')
        assert row is next(x for x in failed if x['from']==row['from'] and x['to']==row['to'])

    # Build the public flow map from exactly the same final rows.  The edge list
    # and problem-group evidence must carry the same final digest.
    names=('scanner','feature','candle','market','orderflow','target_router','strategy','risk','paper','review','main','guard','ws','micro')
    components={name:{'name':name,'runtime_state':'NORMAL','status_age_sec':0.0,'last_sec':0.1,'process':{},'phase_profile':{},'flow_metrics':{}} for name in names}
    anomalies=[]
    for edge in checks:
        pair=f"{edge['from']}→{edge['to']}"
        anomalies.append({'id':f'EVENT_DRIVEN_EDGE_CONTRACT_CHECK:{pair}','severity':'CHECK','kind':'EVENT_DRIVEN_EDGE_CONTRACT_CHECK','component':pair,'actual':edge,'threshold':'final semantic owner proof is current','evidence':edge,'next_command':'/flow_map_full'})
    guard.BOT_DIR=td
    flow=guard._ops_build_flow_map_v1103(
        components,failed,{'exact_ok':True,'duplicate':0,'key_missing':0,'unlinked':0,'source':'fixture'},
        [],[],anomalies,{'total_bytes':1000,'available_bytes':900},{'total_bytes':1000,'available_bytes':900},
        100.0,failed_roots,{},
    )
    edge_by_pair={(x['from'],x['to']):x for x in flow['edges']}
    for row in checks:
        pair=(row['from'],row['to'])
        digest=row['final_edge_digest_v1145']
        assert edge_by_pair[pair]['final_edge_digest_v1145']==digest
        assert edge_by_pair[pair]['artifact']['final_semantic_edge_v1145']['digest']==digest
    event_groups=[x for x in flow['problem_groups'] if x.get('code')=='EVENT_DRIVEN_EDGE_CONTRACT_CHECK']
    assert event_groups
    evidence_rows=[e for g in event_groups for e in g.get('evidence',[]) if isinstance(e,dict)]
    assert {e.get('final_edge_digest_v1145') for e in evidence_rows}=={r['final_edge_digest_v1145'] for r in checks}

source=(ROOT/'backga_guard_bot_v2_5_186.py').read_text(encoding='utf-8')
assert '_ops_normalize_semantic_lineage_v1144' not in source
assert "semantic_edge_checks_v1140=[]" not in source
assert "if src=='risk' and dst in ('strategy','paper') and risk_root_v1106.get('diagnosis_state')=='PROVEN_EVENT_DRIVEN_IDLE':\n                continue" not in source
assert 'raw_lineage_v1145' in source
assert 'semantic_owner_roots_v1145' in source
assert 'GUARD-SEMANTIC-EDGE-1145' in source

print(json.dumps({
    'ok':True,
    'proven_edge_errors':0,
    'failed_edge_errors':3,
    'same_final_digest_across_readers':True,
    'old_raw_direct_paths_removed':True,
},ensure_ascii=False))
