# v1145 Guard semantic edge final owner

## Locked scope

- Only `backga_guard_bot.py` changes at runtime.
- Strategy, Paper and Risk trading sources are unchanged.
- Gate, rank, TTL, trigger, invalid, target, RR, spread/slippage formula, trailing, OPEN 30 and cycle 3 are unchanged.
- Auto-buy remains OFF.

## Proven root cause

The collector produced raw event-driven mtime evidence first. Before semantic normalization, the v1140 visibility path appended `EVENT_DRIVEN_EDGE_CONTRACT_CHECK` anomalies. Later `_ops_build_flow_map_v1103` independently read Risk/Paper semantic heartbeats and normalized the same edges to `PROVEN_EVENT_DRIVEN_IDLE/NORMAL`. The top-level anomaly and the connection list therefore consumed different edge states in one snapshot.

## Removed paths

1. Pre-normalized raw edge direct anomaly append.
2. Semantic normalization inside the flow-map builder.
3. Builder-level semantic NORMAL overwrite.
4. DATA_STALE semantic skip branches.
5. `_ops_normalize_semantic_lineage_v1144` duplicate reader.

## New single mainline

`raw artifact evidence -> semantic owner roots once -> final edge object/digest once -> lineage / flow edges / error groups / problem location / root cause`

Raw mtime evidence remains visible inside `raw_evidence_reference_v1145`, but its owner is explicitly `REFERENCE_ONLY_NOT_A_VERDICT`.

## Local proof

- Proven Risk and Performance semantic owners convert raw CHECK evidence to final `NORMAL / EVENT_DRIVEN_IDLE / PROVEN_EVENT_DRIVEN_IDLE`.
- Missing/stale semantic owner proof remains final CHECK.
- Final lineage row, flow edge and problem-group evidence use the same final digest.
- Old normalization and raw-direct append paths are absent.
- Guard py_compile PASS.
- Strategy/Paper/Risk hashes are unchanged from v1144.

## Server DONE proof

- Risk `CURRENT_EVENT_IDLE` or `CURRENT_AFTER_COMMIT`: `risk->strategy` and `risk->paper` event-edge error groups 0.
- Performance semantic `EVENT_DRIVEN_IDLE`: `performance->main` event-edge error group 0.
- Final edge state/digest is identical in connection detail, problem group and root-cause evidence.
- A real stale/missing semantic heartbeat still produces CHECK.
- New Guard runtime/hash is exact and runtime errors are 0.
