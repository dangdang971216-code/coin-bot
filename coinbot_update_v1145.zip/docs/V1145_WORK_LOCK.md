# v1145 작업 잠금 — Guard semantic edge final owner 단일화

- issue: GUARD-SEMANTIC-EDGE-1145 / OPEN
- 기준: v1144 Guard v2.5.185
- 수정 파일: backga_guard_bot.py → backga_guard_bot_v2_5_186.py
- 전략 영향: 없음 / visibility·reader-owner cleanup only
- 자동매수: OFF 유지

## 증상
- raw mtime event contract는 risk→strategy, risk→paper, performance→main을 CHECK로 생성한다.
- 이후 flow-map builder가 semantic heartbeat root를 다시 읽어 동일 edge를 NORMAL/EVENT_DRIVEN_IDLE로 덮는다.
- collector의 top-level anomaly는 builder 전 raw lineage를 읽으므로 같은 snapshot에 CHECK와 NORMAL이 공존한다.

## owner / caller / writer / reader
- owner: Guard single ops collector
- caller: collect_ops_map_snapshot
- writer: ops_map_snapshot atomic writer
- readers: Main /flow_map_full, problem_groups, problem_location_index, root_cause_diagnostics

## 삭제할 구경로
1. collector raw lineage에서 top-level EVENT_DRIVEN_EDGE_CONTRACT_CHECK 직접 append
2. _ops_build_flow_map_v1103 내부 semantic 재정규화
3. edge builder의 semantic NORMAL 재덮기
4. DATA_STALE loop의 별도 semantic skip 분기
5. v1144 normalize helper

## 새 본선
raw artifact evidence → semantic owner roots 1회 계산 → final lineage/edge object 1회 생성 → top-level anomaly·flow edges·problem groups·location index·root cause가 같은 final state/digest 사용

## 검수
- semantic proven risk/performance: final NORMAL, event PROVEN_EVENT_DRIVEN_IDLE, EVENT_DRIVEN_EDGE_CONTRACT_CHECK 0
- semantic proof missing/stale: final CHECK 유지
- final lineage / flow edge / problem evidence digest 일치
- py_compile, AST, contract test, runtime-smoke fixture
- Strategy/Paper/Risk source hash 무변경
- Gate/rank/TTL/trigger/invalid/target/RR/trailing/OPEN30/cycle3 무변경
