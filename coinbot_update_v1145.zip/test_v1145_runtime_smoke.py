import hashlib
import json
import os
import py_compile
from pathlib import Path

ROOT=Path(__file__).resolve().parent
BASE=Path(os.environ.get('BOT_DIR',str(ROOT)))
files=['backga_guard_bot_v2_5_186.py']
for name in files:
    py_compile.compile(str(ROOT/name),doraise=True)

unchanged=['strategy_worker_v1.014.py','paper_bot_v1.026.py','risk_worker_v0.13.py']
hashes={name:hashlib.sha256((BASE/name).read_bytes()).hexdigest() for name in unchanged}
expected={
    'strategy_worker_v1.014.py':'26a676ca08715c6b',
    'paper_bot_v1.026.py':'ff7ff008a168cd00',
    'risk_worker_v0.13.py':'b921d0e8d9cae1a5',
}
for name,prefix in expected.items():
    assert hashes[name].startswith(prefix),(name,hashes[name])

source=(ROOT/'backga_guard_bot_v2_5_186.py').read_text(encoding='utf-8')
for token in ('OPEN 30','cycle 3','auto-buy OFF'):
    assert token in source
assert 'guard_v2.5.186_semantic_edge_final_owner_v1145_2026-06-29' in source
print(json.dumps({'ok':True,'compile':True,'unchanged_hashes':hashes,'auto_buy':False},ensure_ascii=False))
