# v1095 범위와 서버 검수

## 변경 범위
- Feature: 상대강도·거래대금/거래량/단기흐름 기반 money-flow owner
- Strategy: 구조·실행 계약 뒤 4개 품질축 중 3개 이상 known, 2개 이상 pass; 통과 후보 최종 순위 owner
- Paper: 실제 진입 예정가 RR·목표공간 재검증, slippage missing 차단, reaction proof 재연결, 품질순위 후 OPEN 30/cycle 3
- Reset: 배포 후 기존 PAPER OPEN 세트 봉인, exact CLOSED 정리, 별도 성과군, OPEN 0 증명 후 새 epoch 활성화

## 변경하지 않음
- 자동매수 OFF
- 핵심 장부 삭제/축소/재작성 없음
- 과거 entry version/contract 재계산 또는 현재값 덮어쓰기 없음
- target/invalid/exit 계산식 변경 없음

## 서버 DONE
- Paper v1.009 / Strategy v0.997 / Feature v0.6 / Guard v2.5.149
- reset target > 0, remaining 0, unresolved 0, exact_closed >= target, failed 0
- canonical performance reset_transition rows >= reset target and strategy windows excluded
- epoch ACTIVE, 현재 OPEN <= 30, cycle 신규 상한 3
- Feature money-flow known > 0, Strategy rank owner 확인
- exact duplicate/key_missing/unlinked 0/0/0, 신규 오류 0, 자동매수 OFF
