v1611 root timing trace: find why blocking conditions fire. No trading rule changes. Auto-buy OFF.
