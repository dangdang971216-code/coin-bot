코인봇 v1204 · 사용자 승인 기존 OPEN 전체정리

1. /gupgrade_bundle 단독 실행
2. 적용 후 가드 검수 실행
3. Paper봇에서 /preset_all 실행
4. /preset_status와 /pstatus로 OPEN 0·신규진입 잠금 확인

주의:
- 적용만으로 자동 청산하지 않습니다.
- /preset_all 실행 시 기존 OPEN은 삭제가 아니라 exact CLOSED로 기록됩니다.
- 정리 완료 후 TOP10 본선이 배포될 때까지 신규 진입은 잠깁니다.
- 자동매수 OFF입니다.
