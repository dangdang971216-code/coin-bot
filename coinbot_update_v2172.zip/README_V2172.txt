v2172는 전략수치 변경판이 아니다. 반복 wrapper로 갈라진 현재 실행주인을 하나로 합치고, Candle frames/close 파싱·1시간 이력·판단원인·Trigger 사건시간을 원천 수리한다. Core와 모델은 v2171/FULL_INPUT_V2171을 유지한다. 자동매수 OFF.
