v1614 refresh request writer repair. No trading threshold change. Auto-buy OFF.
