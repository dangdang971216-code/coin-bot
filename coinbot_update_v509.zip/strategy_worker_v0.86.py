#!/usr/bin/env python3
# -*- coding: utf-8 -*-

from __future__ import annotations
import json, os, time, math, traceback, urllib.request
from pathlib import Path
from typing import Any, Dict, List, Tuple, Optional
BASE_DIR = Path(os.getenv("TRADING_BOT_DIR", "/home/dangdang971216/trading_bot"))
def now_ts() -> float: return time.time()
def now_text(ts: Optional[float]=None) -> str: return time.strftime("%Y-%m-%d %H:%M:%S", time.localtime(ts or now_ts()))
def fnum(*vals: Any, default: float=0.0) -> float:
    for v in vals:
        try:
            if v is None or v == "": continue
            return float(str(v).replace(",", "").replace("%", ""))
        except Exception: continue
    return default
def load_json(path: Path, default: Any=None) -> Any:
    try:
        if not path.exists(): return default
        return json.loads(path.read_text(encoding="utf-8", errors="ignore"))
    except Exception: return default
def save_json(path: Path, obj: Any) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    tmp = path.with_suffix(path.suffix + ".tmp")
    tmp.write_text(json.dumps(obj, ensure_ascii=False, separators=(",", ":"), default=str), encoding="utf-8")
    os.replace(tmp, path)
def append_jsonl(path: Path, obj: Dict[str, Any]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("a", encoding="utf-8") as f:
        f.write(json.dumps(obj, ensure_ascii=False, separators=(",", ":"), default=str)+"\n")
def write_jsonl_atomic(path: Path, rows: List[Dict[str, Any]]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    tmp = path.with_suffix(path.suffix + ".tmp")
    with tmp.open("w", encoding="utf-8") as f:
        for r in rows:
            f.write(json.dumps(r, ensure_ascii=False, separators=(",", ":"), default=str)+"\n")
    os.replace(tmp, path)
def read_jsonl(path: Path, max_lines: int=1000) -> List[Dict[str, Any]]:
    if not path.exists(): return []
    try:
        lines = path.read_text(encoding="utf-8", errors="ignore").splitlines()
        if max_lines and len(lines) > max_lines: lines = lines[-max_lines:]
        out=[]
        for ln in lines:
            try:
                if ln.strip():
                    o=json.loads(ln)
                    if isinstance(o,dict): out.append(o)
            except Exception: pass
        return out
    except Exception: return []
def read_fresh_jsonl_by_ttl(path: Path, ttl_sec: float) -> List[Dict[str, Any]]:
    """TTL 기준으로 fresh 후보만 읽는다. 개수 제한으로 후보를 자르지 않는다.

    기존 latest/후보 복구 경로의 max_lines=120/500 및 [:40] 고정 상한을
    제거하기 위한 단일 읽기 경로다. 서버 보호는 후보 수 제한이 아니라 TTL로 처리한다.
    """
    if not path.exists():
        return []
    try:
        nowv = now_ts()
        lines = path.read_text(encoding="utf-8", errors="ignore").splitlines()
        out: List[Dict[str, Any]] = []
        for ln in reversed(lines):
            try:
                if not ln.strip():
                    continue
                o = json.loads(ln)
                if not isinstance(o, dict):
                    continue
                exp = fnum(o.get("expires_at"), default=0.0)
                ts = _event_created_ts(o)
                fresh = (exp >= nowv) if exp > 0 else (ts > 0 and (nowv - ts) <= ttl_sec)
                if fresh:
                    out.append(o)
                    continue
                # 파일은 시간순 append라, TTL의 여유구간보다 오래된 항목을 만나면 더 과거는 볼 필요 없다.
                if ts > 0 and (nowv - ts) > max(ttl_sec * 3.0, ttl_sec + 60.0):
                    break
            except Exception:
                continue
        out.reverse()
        return out
    except Exception:
        return []

def append_error(path: Path, where: str, exc: BaseException) -> None:
    try:
        path.parent.mkdir(parents=True, exist_ok=True)
        with path.open("a", encoding="utf-8") as f:
            f.write(f"[{now_text()}] {where}: {exc.__class__.__name__}: {exc}\n")
            f.write(traceback.format_exc()[-1500:]+"\n")
    except Exception: pass
def ticker_norm(x: Any) -> str:
    t = str(x or "").strip().upper().replace("/", "-").replace("_", "-")
    parts=[p for p in t.split("-") if p]
    if len(parts)>=2:
        non=[p for p in parts if p != "KRW"]
        t = non[-1] if non else parts[-1]
    if t.endswith("KRW") and len(t)>3: t=t[:-3]
    return t.strip().upper()
def pct(a: float, b: float) -> float: return ((a-b)/b*100.0) if b else 0.0
def age_sec(path: Path) -> float:
    try: return max(0.0, now_ts()-path.stat().st_mtime)
    except Exception: return 999999.0
def map_rows(obj: Any) -> Dict[str, Dict[str, Any]]:
    if isinstance(obj, dict) and isinstance(obj.get("rows"), list): obj = obj.get("rows")
    elif isinstance(obj, dict) and isinstance(obj.get("rows"), dict): obj = obj.get("rows")
    elif isinstance(obj, dict) and isinstance(obj.get("cache"), dict): obj = obj.get("cache")
    out: Dict[str, Dict[str, Any]] = {}
    if isinstance(obj, list):
        for r in obj:
            if isinstance(r, dict):
                t=ticker_norm(r.get("ticker") or r.get("symbol") or r.get("market"))
                if t: out[t]=r
    elif isinstance(obj, dict):
        for k,v in obj.items():
            t=ticker_norm(k)
            if t and isinstance(v, dict):
                vv=dict(v); vv.setdefault("ticker", t); out[t]=vv
    return out

def feature_rows(obj: Any) -> List[Dict[str, Any]]:
    """feature_worker cache를 한 본선으로 읽는다.
    rows/list/cache/dict 형태를 모두 map_rows로 표준화한다.
    전략 조건 수치는 변경하지 않는다.
    """
    return list(map_rows(obj).values())

VERSION = "strategy_worker_v0.40"
INTERVAL_SEC=float(os.getenv("STRATEGY_WORKER_INTERVAL_SEC","2.0"))
STATUS=BASE_DIR/"clean_strategy_worker_status.json"; ERROR=BASE_DIR/"clean_strategy_worker_error.log"
FEATURE=BASE_DIR/"clean_feature_cache.json"; ORDERFLOW=BASE_DIR/"clean_orderflow_summary_cache.json"; REGIME=BASE_DIR/"clean_market_regime_cache.json"; RISK=BASE_DIR/"clean_risk_filter_cache.json"
PAPER=BASE_DIR/"paper_candidates.jsonl"; PAPER_LATEST=BASE_DIR/"paper_candidates_latest.jsonl"; SUMMARY=BASE_DIR/"clean_strategy_s_summary.json"; REJECT=BASE_DIR/"clean_strategy_s_reject_summary.json"; HANDOFF=BASE_DIR/"clean_strategy_paper_handoff_status.json"; WS_TARGETS=BASE_DIR/"clean_ws_targets.json"; MICRO_TARGETS=BASE_DIR/"clean_micro_targets.json"; MICRO_URGENT=BASE_DIR/"clean_micro_urgent_targets.json"; PRIORITY_REQ=BASE_DIR/"clean_strategy_priority_requests.json"; TARGET_ROUTER_QUEUE=BASE_DIR/"clean_target_router_queue.json"; MISSED_REVIEW_QUEUE=BASE_DIR/"clean_missed_review_queue.json"
CANDIDATE_TTL_SEC=float(os.getenv("STRATEGY_PAPER_CANDIDATE_TTL_SEC","120"))
STRATEGIES={"money_reaccel_s":"돈흐름 재가속 S","leader_momentum_s":"주도추세 지속 S","breakout_early_s":"돌파 초입 S","sweep_vwap_recovery_s":"저점 VWAP 회복 S","surge_rebreak_s":"급등 후 재돌파 S","leader_flow_adaptive_hold_s":"주도흐름 유동보유 S"}
MAIN_DEPLOY_VERSION = "v2.13.394"
MAIN_BOT_VERSION = "수익형 v2.13.394"
def write_status(state:str, **extra:Any)->None:
    # v434: cycle 시작부의 evaluated=0/target=0 상태가 마지막 정상값을 지우지 않게
    # 중앙 status 저장부에서 구 0 초기화 경로를 제거한다.
    prev: Dict[str, Any] = {}
    phase = str(extra.get("phase") or "")
    is_cycle_start_zero = (
        state == "running"
        and phase.startswith("evaluating")
        and int(float(extra.get("evaluated") or 0)) <= 0
        and int(float(extra.get("target_count") or 0)) <= 0
    )
    if is_cycle_start_zero:
        try:
            prev = load_json(STATUS, {}) or {}
        except Exception:
            prev = {}
    obj={"version":VERSION,"state":state,"pid":os.getpid(),"updated_ts":now_ts(),"updated_text":now_text(),"last_error":""}
    obj.update(extra)
    if is_cycle_start_zero and prev:
        for key in ("evaluated", "target_count", "s_count", "paper_latest_count", "s1_count", "s2_count", "s3_count", "router_target_count", "router_queue_count", "router_backlog_count", "last_sec"):
            if key in prev and (obj.get(key) in (None, "", 0, "0", "-")):
                obj[key] = prev.get(key)
        obj["status_route_schema"] = "strategy_status_v435_no_zero_cycle_start_no_40_cap"
        obj["status_route_note"] = "v436: S1/S2/S3 단순화 + cycle 시작 0 초기화 방지 + 후보 latest 고정 40개 제한 제거"
    if state == "error" and "error" in extra:
        obj["last_error"] = str(extra.get("error") or "")[:240]
    save_json(STATUS,obj)

def _event_created_ts(ev: Dict[str, Any]) -> float:
    return fnum(ev.get("created_at"), ev.get("candidate_created_at"), ev.get("source_created_at"), ev.get("detected_ts"), ev.get("event_ts"), ev.get("ts"), ev.get("timestamp"), default=0.0)

def _normalize_paper_event(ev: Dict[str, Any], ttl_sec: float = CANDIDATE_TTL_SEC) -> Dict[str, Any]:
    row = dict(ev or {})
    ts = _event_created_ts(row) or now_ts()
    ticker = ticker_norm(row.get("ticker") or row.get("market") or row.get("symbol"))
    skey = str(row.get("strategy_key") or row.get("strategy_bucket_primary") or "strategy_s")
    scan_id = row.get("scan_id") or row.get("source_scan_id") or f"strategy_s_{int(ts // 60)}"
    eid = row.get("event_id") or row.get("id") or row.get("event_key") or f"{ticker}:{skey}:{int(ts // 60)}"
    row.update({
        "ticker": ticker,
        "market": f"KRW-{ticker}" if ticker else row.get("market"),
        "symbol": f"{ticker}_KRW" if ticker else row.get("symbol"),
        "created_at": ts,
        "candidate_created_at": ts,
        "source_created_at": ts,
        "detected_ts": ts,
        "event_ts": ts,
        "created_at_text": row.get("created_at_text") or now_text(ts),
        "detected_at_text": row.get("detected_at_text") or now_text(ts),
        "updated_ts": now_ts(),
        "expires_at": row.get("expires_at") or (ts + ttl_sec),
        "event_id": eid,
        "event_key": eid,
        "scan_id": scan_id,
        "lane": "strict",
        "paper_bot_open": True,
        "open_eligible": True,
        "trade_ready": True,
        "candidate_grade": "S",
        "grade": "S",
    })
    ctx = row.get("entry_context") if isinstance(row.get("entry_context"), dict) else {}
    # paper_bot의 pre-open check가 top-level 또는 entry_context를 모두 볼 수 있게 복제한다.
    for k in ("ws_fresh", "micro_fresh", "spread_pct", "buy_ratio", "sell_pressure", "orderflow_score"):
        if k in ctx and row.get(k) in (None, ""):
            row[k] = ctx.get(k)
    return row

def _paper_event_fresh(ev: Dict[str, Any], nowv: Optional[float] = None) -> bool:
    nowv = nowv or now_ts()
    exp = fnum(ev.get("expires_at"), default=0.0)
    ts = _event_created_ts(ev)
    if exp > 0:
        return exp >= nowv
    return ts > 0 and (nowv - ts) <= CANDIDATE_TTL_SEC

def _paper_dedupe_key(ev: Dict[str, Any]) -> str:
    t = ticker_norm(ev.get("ticker") or ev.get("market") or ev.get("symbol"))
    sk = str(ev.get("strategy_key") or ev.get("strategy_bucket_primary") or "strategy_s")
    return f"{t}:{sk}"

def persist_paper_handoff(events: List[Dict[str, Any]], evaluated: int = 0) -> Tuple[List[Dict[str, Any]], int]:
    """S 후보 handoff를 휘발성 latest 한 번으로 날리지 않는다.
    - 새 S 후보에는 created_at/detected_ts/expires_at/event_id를 고정한다.
    - 새 루프에서 S가 0이어도 TTL 내 기존 S 후보는 latest에 유지한다.
    - archive paper_candidates.jsonl에는 신규 event_id만 append한다.
    """
    nowv = now_ts()
    new_rows = [_normalize_paper_event(e) for e in (events or [])]
    old_latest = [_normalize_paper_event(e) for e in read_jsonl(PAPER_LATEST, max_lines=0)]
    old_archive = [_normalize_paper_event(e) for e in read_fresh_jsonl_by_ttl(PAPER, CANDIDATE_TTL_SEC)]
    merged: Dict[str, Dict[str, Any]] = {}
    # 오래된 후보가 새 후보를 덮지 않게 old 먼저, new 나중에 넣는다.
    for ev in old_archive + old_latest + new_rows:
        if not _paper_event_fresh(ev, nowv):
            continue
        key = _paper_dedupe_key(ev)
        if not key:
            continue
        prev = merged.get(key)
        if (prev is None) or fnum(ev.get("score"), default=0.0) >= fnum(prev.get("score"), default=0.0) or _event_created_ts(ev) >= _event_created_ts(prev):
            merged[key] = ev
    latest = sorted(merged.values(), key=lambda e: (fnum(e.get("score"), default=0.0), _event_created_ts(e)), reverse=True)
    write_jsonl_atomic(PAPER_LATEST, latest)
    recent_ids = {str(r.get("event_id") or r.get("event_key") or "") for r in read_jsonl(PAPER, max_lines=800)}
    appended = 0
    for ev in new_rows:
        eid = str(ev.get("event_id") or ev.get("event_key") or "")
        if eid and eid not in recent_ids:
            append_jsonl(PAPER, ev)
            recent_ids.add(eid)
            appended += 1
    save_json(HANDOFF, {
        "version": VERSION,
        "updated_ts": nowv,
        "updated_text": now_text(nowv),
        "evaluated": evaluated,
        "new_s_count": len(new_rows),
        "paper_latest_count": len(latest),
        "archive_appended": appended,
        "latest_tickers": [e.get("ticker") for e in latest[:20]],
        "ttl_sec": CANDIDATE_TTL_SEC,
        "candidate_limit_policy": "no_fixed_count_limit_ttl_only",
        "candidate_limit_note": "v436: 후보 latest는 개수로 자르지 않고 TTL fresh 기준으로만 유지",
        "note": "v436: 후보 latest 고정 40개 제한 유지 제거. S1/S2/S3 외 추가 등급 없이 target_router 정보요청과 TTL 후보 보존만 유지.",
    })
    return latest, appended

def risk_bad(t:str)->List[str]:
    r=load_json(RISK,{}) or {}; cd=(r.get("cooldown") or {}) if isinstance(r,dict) else {}
    out=[]
    if t in cd: out.append("최근반복손실/하드손실")
    if t in set(r.get("open_tickers",[]) if isinstance(r,dict) else []): out.append("이미OPEN중")
    return out
def common_hard(row:Dict[str,Any], of:Dict[str,Any])->List[str]:
    """cheap/기본 차단만 본다.
    WS/micro 부족은 여기서 붙이지 않는다.
    v0.8: 붙일 필요도 없는 후보까지 정보부족으로 보이는 문제를 막기 위해
    정보부족은 cheap gate 통과 후보에게만 별도 부여한다.
    """
    hard=[]; t=ticker_norm(row.get("ticker")); hard+=risk_bad(t)
    if row.get("major_watch"): hard.append("대형주는시장참고")
    if bool(of.get("micro_fresh")):
        spread=fnum(of.get("spread_pct"),default=0)
        buy=fnum(of.get("buy_ratio"),default=0)
        if spread>0.28: hard.append(f"스프레드넓음 {spread:.2f}%")
        if buy and buy<0.58: hard.append(f"매수체결약함 {buy:.2f}")
        if of.get("sell_pressure"): hard.append("매도벽/매도체결압력")
    if fnum(row.get("turnover_24h"))<250_000_000: hard.append("거래대금부족")
    if row.get("long_upper_wick"): hard.append("윗꼬리위험")
    if fnum(row.get("day_pos_pct"),default=50)>94 and fnum(row.get("change_5m"))<0.2: hard.append("고점끝물위험")
    return hard[:8]

def orderflow_info_bad(of:Dict[str,Any])->List[str]:
    """v0.9: strategy는 WS 단독 fresh가 아니라 표준 시세(quote_fresh)를 본다.
    quote_fresh는 orderflow_worker가 WS 또는 scanner/feature REST 현재가로 만든 canonical 시세다.
    micro는 호가·체결 판단 재료라 별도로 필요하다.
    """
    info=[]
    if not bool(of.get("quote_fresh") or of.get("ws_fresh")):
        info.append("시세정보보강대기")
    if not bool(of.get("micro_fresh")):
        info.append("micro정보보강대기")
    return info[:4]
def eval_money(r,o):
    no=[]
    if fnum(r.get("change_3m"))<0.25 or fnum(r.get("change_5m"))<0.35: no.append("3/5분재가속부족")
    if fnum(r.get("vwap_gap_pct"))<-0.05 or fnum(r.get("ema5_gap_pct"))<-0.08: no.append("VWAP/EMA유지부족")
    if not r.get("volume_expanding"): no.append("캔들거래량확장부족")
    # micro가 fresh일 때만 매수체결비를 전략 실패로 본다. fresh가 없으면 정보보강대기로 분리한다.
    if o.get("micro_fresh") and fnum(o.get("buy_ratio"))<0.65: no.append("매수체결우세부족")
    return (not no, ["돈흐름재가속","3/5분재가속","VWAP/EMA유지","체결우세"], no)
def eval_leader(r,o):
    no=[]
    if fnum(r.get("change_15m"))<0.65 or fnum(r.get("change_30m"))<0.65: no.append("15/30분주도부족")
    if fnum(r.get("relative_strength_pct"))<0.3: no.append("시장대비강도부족")
    if fnum(r.get("vwap_gap_pct"))<0 or fnum(r.get("ema5_gap_pct"))<0: no.append("VWAP/EMA위치부족")
    if r.get("market_mode") == "약함": no.append("장세약함")
    return (not no, ["15/30분주도","시장대비강함","VWAP/EMA위"], no)
def eval_breakout(r,o):
    no=[]
    if not r.get("breakout_hint"): no.append("돌파캔들미확인")
    if fnum(r.get("recent_high_gap_pct"))<-0.15: no.append("돌파후유지부족")
    if fnum(r.get("change_15m"))>5.0 and not r.get("volume_expanding"): no.append("끝물추격위험")
    return (not no, ["돌파초입","거래량확장","고점돌파유지"], no)
def eval_sweep(r,o):
    no=[]
    if not r.get("sweep_reclaim_hint"): no.append("저점쓸림회복미확인")
    if fnum(r.get("vwap_gap_pct"))<-0.05: no.append("VWAP회복부족")
    if fnum(r.get("recent_low_rebound_pct"))<0.4: no.append("저점방어반등부족")
    return (not no, ["저점이탈실패","VWAP회복","매수회복"], no)
def eval_surge(r,o):
    no=[]
    if fnum(r.get("change_15m"))<1.2: no.append("1차상승부족")
    if fnum(r.get("change_3m"))<0.15: no.append("재돌파시도부족")
    if fnum(r.get("recent_high_gap_pct"))<-0.25: no.append("고점재접근부족")
    if r.get("long_upper_wick"): no.append("윗꼬리반락위험")
    return (not no, ["급등후재돌파","얕은눌림","체결재상승"], no)


def eval_adaptive_hold(r,o):
    """v0.19/v367 주도흐름 유동보유 전략.
    시간 고정이 아니라 0~5분 검증, 5~30분 확인, 30~120분 확장으로 나눠 본다.
    """
    no=[]
    ch1=fnum(r.get("change_1m"), r.get("price_change_1m"), default=0.0)
    ch3=fnum(r.get("change_3m"), r.get("price_change_3m"), default=0.0)
    ch5=fnum(r.get("change_5m"), r.get("price_change_5m"), default=0.0)
    ch15=fnum(r.get("change_15m"), r.get("price_change_15m"), default=0.0)
    ch30=fnum(r.get("change_30m"), r.get("price_change_30m"), default=0.0)
    vwap=fnum(r.get("vwap_gap_pct"), default=-9.0)
    ema=fnum(r.get("ema5_gap_pct"), r.get("ma5_gap_pct"), default=-9.0)
    rel=fnum(r.get("relative_strength_pct"), r.get("relative_strength"), default=0.0)
    day=fnum(r.get("day_pos_pct"), r.get("current_close_pos_ratio"), default=50.0)
    high_gap=fnum(r.get("recent_high_gap_pct"), r.get("below_high_pct"), default=-9.0)
    money=fnum(r.get("turnover_24h"), default=0.0)
    buy=fnum(o.get("buy_ratio"), o.get("micro_trade_buy_ratio_30"), default=0.0)
    spread=fnum(o.get("spread_pct"), default=99.0)
    if not ((ch3 >= 0.20 and ch5 >= 0.25) or (ch15 >= 0.70 and ch30 >= 0.40) or (ch5 >= 0.80 and ch15 >= 0.40)):
        no.append("흐름유지부족")
    if vwap < -0.10 or ema < -0.15:
        no.append("VWAP/EMA유지부족")
    if rel < -1.0 and ch5 < 1.0:
        no.append("시장대비약함")
    if money < 300_000_000:
        no.append("거래대금부족")
    if o.get("micro_fresh") and buy < 0.58:
        no.append("매수체결최소부족")
    if o.get("micro_fresh") and spread > 0.30:
        no.append("스프레드과다")
    if day >= 97.0 and high_gap >= -0.05 and ch1 <= 0.05:
        no.append("고점끝물재확인필요")
    if ch5 >= 12.0 and ema >= 6.0:
        no.append("급등과열재확인필요")
    return (not no, ["주도흐름유지","유동보유","VWAP/EMA방어","시간확장후보"], no)

def _pickv(src: Dict[str, Any], *keys: str, default: Any = None) -> Any:
    for k in keys:
        if isinstance(src, dict) and src.get(k) not in (None, "", "-"):
            return src.get(k)
    return default

def _boolv(v: Any) -> bool:
    if isinstance(v, bool): return v
    return str(v).lower() in {"1", "true", "yes", "ok", "fresh", "신선"}

def _entry_snapshot(row: Dict[str, Any], of: Dict[str, Any], skey: str, reasons: List[str], ts: float, eid: str) -> Dict[str, Any]:
    """v0.11: 진입 당시 전략 판단/복기용 표준 스냅샷.
    조건을 바로 조이는 용도가 아니라, OPEN/CLOSED/score/review가 같은 근거를 보게 하는 저장 schema다.
    """
    t = ticker_norm(row.get("ticker") or row.get("market") or row.get("symbol"))
    snap = {
        "schema": "entry_snapshot_v1",
        "version": VERSION,
        "captured_ts": ts,
        "captured_text": now_text(ts),
        "event_id": eid,
        "ticker": t,
        "price": fnum(row.get("current_price"), row.get("price"), of.get("quote_price"), default=0.0),
        "strategy": {
            "primary_key": skey,
            "primary_label": STRATEGIES.get(skey, skey),
            "reasons": list(reasons or [])[:8],
            "decision_stage": "S1_immediate_candidate",
            "decision_note": "v0.11 정보스냅샷: 조건 변경 없이 S 진입 당시 재료를 보존",
        },
        "price_flow": {
            "change_30s": _pickv(row, "change_30s", "price_change_30s"),
            "change_1m": _pickv(row, "change_1m", "price_change_1m", "change_1"),
            "change_3m": _pickv(row, "change_3m", "price_change_3m", "change_3"),
            "change_5m": _pickv(row, "change_5m", "price_change_5m", "change_5"),
            "change_15m": _pickv(row, "change_15m", "price_change_15m", "change_15"),
            "change_30m": _pickv(row, "change_30m", "price_change_30m", "change_30"),
            "price_reaction_score": _pickv(row, "price_reaction_score", "price_recheck_pct"),
        },
        "position": {
            "vwap_gap_pct": _pickv(row, "vwap_gap_pct"),
            "ema5_gap_pct": _pickv(row, "ema5_gap_pct", "ma5_gap_pct"),
            "ema12_gap_pct": _pickv(row, "ema12_gap_pct"),
            "ema21_gap_pct": _pickv(row, "ema21_gap_pct"),
            "recent_high_gap_pct": _pickv(row, "recent_high_gap_pct", "below_high_pct", "below_30m_high_pct"),
            "recent_low_gap_pct": _pickv(row, "recent_low_gap_pct", "from_low_pct", "from_30m_low_pct"),
            "day_pos_pct": _pickv(row, "day_pos_pct", "current_close_pos_ratio"),
            "recent_low_rebound_pct": _pickv(row, "recent_low_rebound_pct", "low_defense_pct"),
            "breakout_hint": bool(row.get("breakout_hint")),
            "breakout_hold_hint": _pickv(row, "breakout_hold_hint", "breakout_retain_hint"),
            "sweep_reclaim_hint": bool(row.get("sweep_reclaim_hint")),
            "long_upper_wick": bool(row.get("long_upper_wick")),
            "upper_wick_pct": _pickv(row, "upper_wick_pct", "current_upper_wick_pct"),
        },
        "money_flow": {
            "turnover_24h": _pickv(row, "turnover_24h"),
            "turnover_1m": _pickv(row, "turnover_1m", "money_flow_1m"),
            "turnover_3m": _pickv(row, "turnover_3m", "money_flow_3m"),
            "turnover_5m": _pickv(row, "turnover_5m", "money_flow_5m"),
            "volume_expanding": bool(row.get("volume_expanding")),
            "volume_expansion_ratio": _pickv(row, "volume_expansion_ratio", "vol_ratio"),
            "relative_strength_pct": _pickv(row, "relative_strength_pct", "relative_strength"),
            "market_mode": _pickv(row, "market_mode"),
            "market_pressure": _pickv(row, "market_pressure"),
        },
        "orderflow": {
            "quote_fresh": _boolv(of.get("quote_fresh") or of.get("ws_fresh")),
            "quote_source": _pickv(of, "quote_source"),
            "quote_price": _pickv(of, "quote_price"),
            "quote_age_sec": _pickv(of, "quote_age_sec"),
            "ws_fresh": _boolv(of.get("ws_fresh")),
            "ws_age_sec": _pickv(of, "ws_age_sec"),
            "ws_gap_pct": _pickv(of, "ws_gap_pct", "quote_gap_pct", "current_price_ws_gap_pct"),
            "micro_fresh": _boolv(of.get("micro_fresh")),
            "micro_age_sec": _pickv(of, "micro_age_sec"),
            "spread_pct": _pickv(of, "spread_pct"),
            "buy_ratio": _pickv(of, "buy_ratio", "micro_trade_buy_ratio_30"),
            "buy_ratio_30s": _pickv(of, "buy_ratio_30s", "buy_ratio_30", "micro_trade_buy_ratio_30"),
            "buy_ratio_1m": _pickv(of, "buy_ratio_1m", "buy_ratio_60"),
            "bid_wall_ratio": _pickv(of, "bid_wall_ratio", "micro_bid_ask_wall_ratio"),
            "ask_wall_ratio": _pickv(of, "ask_wall_ratio"),
            "sell_pressure": bool(of.get("sell_pressure") or of.get("ask_wall_pressure") or of.get("sell_trade_pressure")),
            "ask_wall_pressure": bool(of.get("ask_wall_pressure")),
            "sell_trade_pressure": bool(of.get("sell_trade_pressure")),
            "slippage_est_pct": _pickv(of, "slippage_est_pct", "tick_pct_est"),
            "orderflow_score": _pickv(of, "orderflow_score"),
        },
        "risk": {
            "major_watch": bool(row.get("major_watch")),
            "quality_risk_tags": row.get("quality_risk_tags") if isinstance(row.get("quality_risk_tags"), list) else [],
            "hard_flags": common_hard(row, of),
            "recent_loss_or_hard": "최근반복손실/하드손실" in common_hard(row, of),
            "high_end_risk": bool(fnum(row.get("day_pos_pct"), default=50)>94 and fnum(row.get("change_5m"))<0.2),
            "sell_pressure": bool(of.get("sell_pressure") or of.get("ask_wall_pressure") or of.get("sell_trade_pressure")),
        },
        "review_after_entry": {
            "track_30s_peak_pct": None,
            "track_1m_peak_pct": None,
            "track_3m_peak_pct": None,
            "peak_reach_sec": None,
            "note": "paper_bot 청산감시가 진입 후 반응/최고수익 도달시간을 보강할 수 있는 자리",
        },
    }
    # 자주 쓰는 값은 flat alias도 같이 보존해 paper_bot 구/신 경로가 모두 읽게 한다.
    flat = {
        "entry_snapshot_schema": snap["schema"],
        "entry_snapshot_version": snap["version"],
                "change_30s": snap["price_flow"].get("change_30s"),
        "change_1m": snap["price_flow"].get("change_1m"),
        "change_3m": snap["price_flow"].get("change_3m"),
        "change_5m": snap["price_flow"].get("change_5m"),
        "change_15m": snap["price_flow"].get("change_15m"),
        "change_30m": snap["price_flow"].get("change_30m"),
        "price_change_3m": snap["price_flow"].get("change_3m"),
        "price_change_5m": snap["price_flow"].get("change_5m"),
        "vwap_gap_pct": snap["position"].get("vwap_gap_pct"),
        "ema5_gap_pct": snap["position"].get("ema5_gap_pct"),
        "recent_high_gap_pct": snap["position"].get("recent_high_gap_pct"),
        "recent_low_gap_pct": snap["position"].get("recent_low_gap_pct"),
        "day_pos_pct": snap["position"].get("day_pos_pct"),
        "relative_strength_pct": snap["money_flow"].get("relative_strength_pct"),
        "relative_strength": snap["money_flow"].get("relative_strength_pct"),
        "turnover_24h": snap["money_flow"].get("turnover_24h"),
        "money_flow_1m": snap["money_flow"].get("turnover_1m"),
        "money_flow_3m": snap["money_flow"].get("turnover_3m"),
        "money_flow_5m": snap["money_flow"].get("turnover_5m"),
        "volume_expanding": snap["money_flow"].get("volume_expanding"),
        "quote_fresh": snap["orderflow"].get("quote_fresh"),
        "quote_source": snap["orderflow"].get("quote_source"),
        "quote_price": snap["orderflow"].get("quote_price"),
        "quote_age_sec": snap["orderflow"].get("quote_age_sec"),
        "ws_fresh": snap["orderflow"].get("ws_fresh"),
        "ws_age_sec": snap["orderflow"].get("ws_age_sec"),
        "ws_gap_pct": snap["orderflow"].get("ws_gap_pct"),
        "current_price_ws_gap_pct": snap["orderflow"].get("ws_gap_pct"),
        "micro_fresh": snap["orderflow"].get("micro_fresh"),
        "micro_age_sec": snap["orderflow"].get("micro_age_sec"),
        "spread_pct": snap["orderflow"].get("spread_pct"),
        "micro_spread_pct": snap["orderflow"].get("spread_pct"),
        "buy_ratio": snap["orderflow"].get("buy_ratio"),
        "micro_trade_buy_ratio_30": snap["orderflow"].get("buy_ratio"),
        "micro_buy_ratio_sustain_1m": snap["orderflow"].get("buy_ratio_1m"),
        "bid_wall_ratio": snap["orderflow"].get("bid_wall_ratio"),
        "micro_bid_ask_wall_ratio": snap["orderflow"].get("bid_wall_ratio"),
        "ask_wall_ratio": snap["orderflow"].get("ask_wall_ratio"),
        "sell_pressure": snap["orderflow"].get("sell_pressure"),
        "micro_ask_wall_pressure": snap["orderflow"].get("ask_wall_pressure"),
        "micro_sell_trade_pressure": snap["orderflow"].get("sell_trade_pressure"),
        "slippage_est_pct": snap["orderflow"].get("slippage_est_pct"),
        "orderflow_score": snap["orderflow"].get("orderflow_score"),
        "quality_risk_tags": snap["risk"].get("quality_risk_tags"),
    }
    snap["flat"] = flat
    return snap

def _snapshot_flat_aliases(snap: Dict[str, Any]) -> Dict[str, Any]:
    if isinstance(snap, dict) and isinstance(snap.get("flat"), dict):
        # v0.13: flat alias 안에는 snapshot 본체를 넣지 않는다.
        # flat -> entry_snapshot -> flat 순환참조가 생기면 json 저장에서 Circular reference로 worker가 error 상태가 된다.
        out = dict(snap.get("flat") or {})
        out.pop("entry_snapshot", None)
        return out
    return {}

def _minimal_entry_snapshot(row: Dict[str, Any], of: Dict[str, Any], skey: str, reasons: List[str], ts: float, eid: str, err: str = "") -> Dict[str, Any]:
    t = ticker_norm(row.get("ticker") or of.get("ticker"))
    snap = {
        "schema": "entry_snapshot_v1", "version": VERSION, "snapshot_status": "partial",
        "snapshot_error": err[:180], "ticker": t, "event_id": eid, "created_at": ts, "created_at_text": now_text(ts),
        "price_flow": {}, "position": {}, "money_flow": {},
        "orderflow": {
            "quote_fresh": bool(of.get("quote_fresh") or of.get("ws_fresh")),
            "ws_fresh": bool(of.get("ws_fresh")), "micro_fresh": bool(of.get("micro_fresh")),
            "spread_pct": of.get("spread_pct"), "buy_ratio": of.get("buy_ratio"),
            "bid_wall_ratio": of.get("bid_wall_ratio"), "ask_wall_ratio": of.get("ask_wall_ratio"),
        },
        "risk": {"hard_flags": common_hard(row, of)},
        "strategy": {"primary_key": skey, "primary_label": STRATEGIES.get(skey, skey), "reasons": reasons[:8]},
        "review_after_entry": {},
    }
    snap["flat"] = {
        "entry_snapshot_schema": snap["schema"], "entry_snapshot_version": snap["version"],         "quote_fresh": snap["orderflow"].get("quote_fresh"), "ws_fresh": snap["orderflow"].get("ws_fresh"),
        "micro_fresh": snap["orderflow"].get("micro_fresh"), "spread_pct": snap["orderflow"].get("spread_pct"),
        "buy_ratio": snap["orderflow"].get("buy_ratio"), "bid_wall_ratio": snap["orderflow"].get("bid_wall_ratio"),
        "ask_wall_ratio": snap["orderflow"].get("ask_wall_ratio"),
        "snapshot_status": snap["snapshot_status"], "snapshot_error": snap["snapshot_error"],
    }
    return snap


def _v361_adaptive_hold_profile(row: Dict[str, Any], of: Dict[str, Any], skey: str) -> Dict[str, Any]:
    """유동 보유형 후보별 청산/복기 프로필."""
    ch5=fnum(row.get('change_5m'), row.get('price_change_5m'), default=0.0)
    ch15=fnum(row.get('change_15m'), row.get('price_change_15m'), default=0.0)
    ch30=fnum(row.get('change_30m'), row.get('price_change_30m'), default=0.0)
    rel=fnum(row.get('relative_strength_pct'), row.get('relative_strength'), default=0.0)
    vwap=fnum(row.get('vwap_gap_pct'), default=0.0)
    ema=fnum(row.get('ema5_gap_pct'), row.get('ma5_gap_pct'), default=0.0)
    strong = (ch15 >= 1.2 and ch30 >= 0.8 and rel >= 0.3) or (ch5 >= 1.2 and ch15 >= 0.8 and vwap >= 0 and ema >= 0)
    ext_tp = 2.20 if strong else 1.80
    max_min = 120 if strong else 75
    return {
        'strategy_family': 'adaptive_hold',
        'strategy_family_label': '주도흐름 유동보유',
        'hold_model': 'adaptive_0_5_30_120',
        'phase_1': '0~5분 진입검증: 가격반응/체결지속/VWAP 방어 없으면 빠른정리',
        'phase_2': '5~30분 수익확인: +0.5~1.2% 도달·VWAP/EMA 유지 시 보유',
        'phase_3': '30~120분 확장: +1.2% 이상 도달 후 추세 유지 시 보호익절로 연장',
        'take_profit_pct': 1.20,
        'extended_target_pct': ext_tp,
        'extended_take_profit_pct': ext_tp,
        'protect_trigger_pct': 0.70,
        'protect_floor_pct': 0.35,
        'stop_loss_pct': -0.60,
        'hard_loss_guard_pct': -0.90,
        'time_exit_minutes': max_min,
        'time_exit_min': max_min,
        'early_validation_minutes': 5,
        'mid_validation_minutes': 30,
        'adaptive_hold_note': '나쁜 후보는 0~5분 검증 실패로 빨리 정리하고, +1.2% 이상 간 후보만 30~120분 확장 관찰',
    }

def build_event(row, of, skey, reasons):
    ts = now_ts()
    t = ticker_norm(row.get("ticker"))
    price = fnum(row.get("current_price"), row.get("price"), of.get("quote_price"), default=0)
    label = STRATEGIES.get(skey, skey)
    eid = f"{t}:{skey}:{int(ts // 60)}"
    try:
        entry_snapshot = _entry_snapshot(row, of, skey, reasons, ts, eid)
    except Exception as exc:
        append_error(ERROR, "entry_snapshot_build", exc)
        entry_snapshot = _minimal_entry_snapshot(row, of, skey, reasons, ts, eid, f"{exc.__class__.__name__}: {exc}")
    aliases = _snapshot_flat_aliases(entry_snapshot)
    base_ctx = dict(aliases)
    base_ctx.update({
        "candidate_created_at": ts,
        "event_id": eid,
        "strategy_key": skey,
        "strategy_name": label,
        "strategy_bucket_primary": skey,
        "strategy_bucket_primary_label": label,
        "strategy_bucket_labels": [label],
        "final_entry_reasons": reasons[:6],
        "entry_snapshot": entry_snapshot,
        "main_version": MAIN_DEPLOY_VERSION,
        "main_bot_version": MAIN_BOT_VERSION,
        "deploy_version": MAIN_DEPLOY_VERSION,
    })
    ev = {
        "event_id": eid,
        "event_key": eid,
        "created_at": ts,
        "candidate_created_at": ts,
        "source_created_at": ts,
        "detected_ts": ts,
        "event_ts": ts,
        "updated_ts": ts,
        "expires_at": ts + CANDIDATE_TTL_SEC,
        "created_at_text": now_text(ts),
        "detected_at_text": now_text(ts),
        "scan_id": f"strategy_s_{int(ts // 60)}",
        "ticker": t,
        "market": f"KRW-{t}",
        "symbol": f"{t}_KRW",
        "strategy_key": skey,
        "strategy": label,
        "strategy_name": label,
        "paper_strategy_key": skey,
        "paper_strategy_label": label,
        "strategy_bucket_primary": skey,
        "strategy_bucket_primary_label": label,
        "strategy_bucket_labels": [label],
        "candidate_grade": "S",
        "grade": "S",
        "candidate_grade_label": "✅ S급 자동매매 상위",
        "paper_bot_open": True,
        "open_eligible": True,
        "trade_ready": True,
        "lane": "strict",
        "current_price": price,
        "entry_price": price,
        "detected_price": price,
        "score": round(13.0 + len(reasons) * 0.9 + fnum(of.get("orderflow_score")) * 0.15, 2),
        "take_profit_pct": 1.80,
        "extended_take_profit_pct": 2.80,
        "protect_trigger_pct": 1.00,
        "protect_floor_pct": 0.45,
        "stop_loss_pct": -0.45,
        "time_exit_minutes": 60,
        "reasons": reasons[:6],
        "quality_risk_tags": aliases.get("quality_risk_tags") or [],
        "entry_context": base_ctx,
        "entry_snapshot": entry_snapshot,
        "entry_snapshot_schema": "entry_snapshot_v1",
        "strategy_reasons": reasons[:6],
        "final_entry_reasons": reasons[:6],
        "brain_version": VERSION,
        "main_version": MAIN_DEPLOY_VERSION,
        "main_bot_version": MAIN_BOT_VERSION,
        "deploy_version": MAIN_DEPLOY_VERSION,
    }
    profile = _v361_adaptive_hold_profile(row, of, skey) if skey == "leader_flow_adaptive_hold_s" else {}
    if profile:
        ev["profile"] = profile
        ev["strategy_family"] = profile.get("strategy_family")
        ev["strategy_family_label"] = profile.get("strategy_family_label")
        ev["hold_model"] = profile.get("hold_model")
        ev["take_profit_pct"] = profile.get("take_profit_pct", ev.get("take_profit_pct"))
        ev["extended_target_pct"] = profile.get("extended_target_pct")
        ev["extended_take_profit_pct"] = profile.get("extended_take_profit_pct")
        ev["protect_trigger_pct"] = profile.get("protect_trigger_pct", ev.get("protect_trigger_pct"))
        ev["protect_floor_pct"] = profile.get("protect_floor_pct", ev.get("protect_floor_pct"))
        ev["stop_loss_pct"] = profile.get("stop_loss_pct", ev.get("stop_loss_pct"))
        ev["hard_loss_guard_pct"] = profile.get("hard_loss_guard_pct")
        ev["time_exit_minutes"] = profile.get("time_exit_minutes", ev.get("time_exit_minutes"))
        ev["time_exit_min"] = profile.get("time_exit_min")
        base_ctx.update(profile)
        if isinstance(entry_snapshot, dict):
            entry_snapshot.setdefault("adaptive_hold_profile", profile)
            strat = entry_snapshot.get("strategy") if isinstance(entry_snapshot.get("strategy"), dict) else {}
            strat.update({"hold_model": profile.get("hold_model"), "strategy_family": profile.get("strategy_family_label"), "decision_note": "v367 주도흐름 유동보유 후보"})
            entry_snapshot["strategy"] = strat
            ev["entry_snapshot"] = entry_snapshot
    ev.update(aliases)
    return ev
def _priority_score(row: Dict[str, Any], core_hits: List[Tuple[str, List[str]]], info_bad: List[str], hard_bad: List[str]) -> float:
    score = 0.0
    score += fnum(row.get("scanner_priority_score"), default=0.0)
    score += min(30.0, max(0.0, fnum(row.get("change_3m"), default=0.0) * 8))
    score += min(30.0, max(0.0, fnum(row.get("change_5m"), default=0.0) * 6))
    score += min(25.0, max(0.0, fnum(row.get("change_15m"), default=0.0) * 3))
    score += min(20.0, max(0.0, fnum(row.get("turnover_24h"), default=0.0) / 400_000_000))
    score += 25.0 * len(core_hits)
    if info_bad:
        score += 15.0
    if hard_bad:
        score -= 35.0
    return round(score, 3)


def _make_priority_request(t: str, row: Dict[str, Any], bucket: str, priority: float, need: List[str], core_hits: List[Tuple[str, List[str]]], reasons: List[str]) -> Dict[str, Any]:
    return {
        "ticker": t,
        "bucket": bucket,
        "priority": round(priority, 3),
        "need": need,
        "core_strategies": [k for k, _ in core_hits],
        "core_strategy_labels": [STRATEGIES.get(k, k) for k, _ in core_hits],
        "reasons": reasons[:8],
        "score": fnum(row.get("scanner_priority_score"), default=0.0),
        "change_3m": fnum(row.get("change_3m"), default=0.0),
        "change_5m": fnum(row.get("change_5m"), default=0.0),
        "change_15m": fnum(row.get("change_15m"), default=0.0),
        "turnover_24h": fnum(row.get("turnover_24h"), default=0.0),
        "updated_ts": now_ts(),
        "source": "strategy_worker",
    }


def _cheap_gate(row: Dict[str, Any], core_hits: List[Tuple[str, List[str]]], hard_bad: List[str]) -> Tuple[bool, str]:
    """정보를 붙일 가치가 있는 후보인지 cheap 재료만으로 먼저 가른다.
    개수 제한이 아니라 우선순위 gate다.
    - S 코어가 맞는 후보는 정보필요 후보
    - 코어가 아직 안 맞아도 돈/흐름/캔들/VWAP가 좋은 후보는 high 후보
    - 나머지는 WS/micro를 붙일 필요 없는 cheap 탈락 후보
    """
    if hard_bad:
        return False, "hard_block"
    if core_hits:
        return True, "core_hit"
    ch3=fnum(row.get("change_3m"), default=0.0)
    ch5=fnum(row.get("change_5m"), default=0.0)
    ch15=fnum(row.get("change_15m"), default=0.0)
    money=fnum(row.get("turnover_24h"), default=0.0)
    score=fnum(row.get("scanner_priority_score"), default=0.0)
    good_flow = (ch3 >= 0.35 and ch5 >= 0.45) or (ch5 >= 0.70) or (ch15 >= 1.20)
    good_position = fnum(row.get("vwap_gap_pct"), default=-9.0) >= -0.10 and fnum(row.get("ema5_gap_pct"), default=-9.0) >= -0.12
    good_signal = bool(row.get("volume_expanding") or row.get("breakout_hint") or row.get("sweep_reclaim_hint"))
    good_money = money >= 500_000_000
    if (good_flow and good_position and (good_signal or good_money)) or (score >= 88 and good_flow):
        return True, "high_cheap"
    return False, "cheap_drop"


def run_once()->Dict[str,Any]:
    st=now_ts(); ts=now_ts()
    # v431: cycle 시작 때 성공 status 값을 0으로 지우지 않는다.
    # /health가 평가 중 순간을 잡아도 마지막 성공 평가/target 숫자를 유지한다.
    prev_status = load_json(STATUS, {}) or {}
    write_status(
        "running",
        phase="evaluating",
        evaluated=int(fnum(prev_status.get("evaluated"), prev_status.get("row_count"), default=0.0)),
        s_count=int(fnum(prev_status.get("s_count"), prev_status.get("paper_latest_count"), default=0.0)),
        target_count=int(fnum(prev_status.get("target_count"), prev_status.get("router_target_count"), default=0.0)),
        last_sec=fnum(prev_status.get("last_sec"), default=0.0),
    )
    fobj=load_json(FEATURE,{}) or {}; rows=feature_rows(fobj)
    ofmap=map_rows(load_json(ORDERFLOW,{}) or {})
    evals=[("leader_flow_adaptive_hold_s",eval_adaptive_hold),("money_reaccel_s",eval_money),("leader_momentum_s",eval_leader),("breakout_early_s",eval_breakout),("sweep_vwap_recovery_s",eval_sweep),("surge_rebreak_s",eval_surge)]
    events=[]; rejects=[]; priority_requests=[]; strat_counts={k:0 for k in STRATEGIES}
    info_pending=0; near_s_info_pending=0; hard_blocked=0; info_not_requested=0
    info_needed_count=0; cheap_drop_count=0; fresh_ready_count=0
    orderflow_attached_count=0; quote_ready_count=0; micro_ready_count=0; full_info_ready_count=0
    priority_buckets={}; cheap_buckets={}
    for row in rows:
        t=ticker_norm(row.get("ticker"))
        if not t: continue
        of=ofmap.get(t,{}) or {}
        if of:
            orderflow_attached_count += 1
        quote_ready = bool(of.get("quote_fresh") or of.get("ws_fresh"))
        micro_ready = bool(of.get("micro_fresh"))
        if quote_ready:
            quote_ready_count += 1
        if micro_ready:
            micro_ready_count += 1
        if quote_ready and micro_ready:
            full_info_ready_count += 1
        hard_bad = common_hard(row,of)
        s_hits=[]; reasons=[]; core_hits=[]; core_fail=[]
        for skey,fn in evals:
            ok,why,no=fn(row,of)
            if ok:
                core_hits.append((skey,why))
            else:
                core_fail += [f"{STRATEGIES.get(skey,skey)}:{x}" for x in no[:2]]
        need_info, cheap_bucket = _cheap_gate(row, core_hits, hard_bad)
        cheap_buckets[cheap_bucket]=cheap_buckets.get(cheap_bucket,0)+1
        info_bad = orderflow_info_bad(of) if need_info else []
        need=[]
        if "시세정보보강대기" in info_bad:
            need.append("quote")
        if "WS정보보강대기" in info_bad:
            need.append("ws")
        if "micro정보보강대기" in info_bad:
            need.append("micro")
        if need_info:
            info_needed_count += 1
        if need_info and not info_bad:
            fresh_ready_count += 1
        pscore=_priority_score(row, core_hits, info_bad, hard_bad)
        if info_bad:
            info_pending += 1
        for skey, why in core_hits:
            if not hard_bad and not info_bad:
                s_hits.append((skey,why)); strat_counts[skey]+=1
        if s_hits:
            ev=build_event(row,of,s_hits[0][0],s_hits[0][1])
            if len(s_hits)>1:
                ev["multi_strategy_s"]=[k for k,_ in s_hits]; ev["strategy_bucket_labels"]=[STRATEGIES.get(k,k) for k,_ in s_hits]
            events.append(ev)
            priority_requests.append(_make_priority_request(t,row,"s_candidate",130+pscore, ["quote","micro"], s_hits, ["S후보유지"]))
            priority_buckets["s_candidate"]=priority_buckets.get("s_candidate",0)+1
        elif core_hits and info_bad and not hard_bad:
            near_s_info_pending += 1
            reasons += [f"정보보강대기:{x}" for x in info_bad[:3]] + [f"S근접:{STRATEGIES.get(k,k)}" for k,_ in core_hits[:2]]
            priority_requests.append(_make_priority_request(t,row,"near_s_info_wait",110+pscore, need, core_hits, reasons))
            priority_buckets["near_s_info_wait"]=priority_buckets.get("near_s_info_wait",0)+1
        elif core_hits and hard_bad:
            hard_blocked += 1
            reasons += hard_bad[:4] + [f"S근접차단:{STRATEGIES.get(k,k)}" for k,_ in core_hits[:2]]
            if info_bad:
                info_not_requested += 1
                priority_buckets["hard_blocked_not_requested"]=priority_buckets.get("hard_blocked_not_requested",0)+1
        else:
            if info_bad:
                reasons += [f"정보보강대기:{x}" for x in info_bad[:2]]
            reasons += hard_bad[:2] + core_fail[:4]
            if info_bad:
                # cheap gate를 통과한 high 후보만 정보요청한다. cheap 탈락 후보에는 정보부족을 붙이지 않는다.
                bucket = "info_wait_high"
                priority_requests.append(_make_priority_request(t,row,bucket, 70+pscore, need, core_hits, reasons))
                priority_buckets[bucket]=priority_buckets.get(bucket,0)+1
            else:
                if cheap_bucket == "cheap_drop":
                    cheap_drop_count += 1
                elif not need_info:
                    info_not_requested += 1
        if not s_hits:
            rejects.append({"ticker":t,"score":fnum(row.get("scanner_priority_score")),"priority":pscore,"reasons":reasons[:8],"price":row.get("current_price"),"updated_ts":ts,"info_pending":bool(info_bad),"info_needed":bool(need_info),"near_s_info_pending":bool(core_hits and info_bad and not hard_bad),"cheap_bucket":cheap_bucket})
    events.sort(key=lambda e:fnum(e.get("score")), reverse=True)
    latest, appended = persist_paper_handoff(events, evaluated=len(rows))
    ctr={}
    for r in rejects:
        for reason in r.get("reasons",[])[:5]: ctr[reason]=ctr.get(reason,0)+1
    top=sorted(ctr.items(), key=lambda x:x[1], reverse=True)[:20]
    priority_requests = sorted(priority_requests, key=lambda x: fnum(x.get("priority"), default=0), reverse=True)
    target = list(dict.fromkeys([r.get("ticker") for r in priority_requests if r.get("ticker")]))
    save_json(PRIORITY_REQ,{"version":VERSION,"updated_ts":ts,"updated_text":now_text(ts),"request_count":len(priority_requests),"targets":target,"requests":priority_requests,"buckets":priority_buckets,"cheap_buckets":cheap_buckets,"note":"v0.13: entry_snapshot 순환참조 제거 + cheap gate/orderflow canonical 유지."})
    tq=load_json(TARGET_ROUTER_QUEUE,{}) or {}
    active_set=set(tq.get("active_targets",[]) if isinstance(tq,dict) and isinstance(tq.get("active_targets"),list) else [])
    priority_wait_sample=[]
    for pr in priority_requests[:12]:
        tt=ticker_norm(pr.get("ticker"))
        of=ofmap.get(tt,{}) or {}
        priority_wait_sample.append({
            "ticker": tt,
            "bucket": pr.get("bucket"),
            "need": pr.get("need"),
            "priority": pr.get("priority"),
            "quote_ready": bool(of.get("quote_fresh") or of.get("ws_fresh")),
            "micro_ready": bool(of.get("micro_fresh")),
            "info_ready": bool((of.get("quote_fresh") or of.get("ws_fresh")) and of.get("micro_fresh")),
            "router_active": tt in active_set or bool(of.get("router_active")),
            "micro_age_sec": of.get("micro_age_sec"),
            "quote_age_sec": of.get("quote_age_sec"),
            "reasons": pr.get("reasons",[])[:4],
        })
    common_summary={"version":VERSION,"updated_ts":ts,"updated_text":now_text(ts),"s_count":len(events),"paper_latest_count":len(latest),"archive_appended":appended,"strategies":strat_counts,"events":latest[:12],"evaluated":len(rows),"info_needed_count":info_needed_count,"info_pending_count":info_pending,"near_s_info_pending":near_s_info_pending,"fresh_ready_count":fresh_ready_count,"cheap_reject_count":cheap_drop_count,"hard_blocked_near_s":hard_blocked,"priority_request_count":len(priority_requests),"priority_buckets":priority_buckets,"cheap_buckets":cheap_buckets,"target_count":len(target),"info_not_requested":info_not_requested,"orderflow_attached_count":orderflow_attached_count,"quote_ready_count":quote_ready_count,"micro_ready_count":micro_ready_count,"full_info_ready_count":full_info_ready_count,"router_target_count":tq.get("active_target_count", tq.get("target_count","-")),"router_queue_count":tq.get("queue_count","-"),"router_backlog_count":tq.get("backlog_count","-"),"router_fresh_recovered":tq.get("fresh_recovered","-"),"router_need_ws":tq.get("need_ws","-"),"router_need_micro":tq.get("need_micro","-"),"router_micro_priority_target_count":tq.get("micro_priority_target_count","-"),"router_strategy_req_info_ready":tq.get("strategy_req_info_ready","-"),"priority_wait_sample":priority_wait_sample}
    save_json(SUMMARY,common_summary)
    save_json(REJECT,{**common_summary,"reject_count":len(rejects),"reason_top":[{"reason":k,"count":v} for k,v in top],"sample":rejects[:30],"note":"v0.13: 전체평가 후보에 정보부족을 찍지 않고 cheap gate 통과 후보만 정보요청. entry_snapshot 순환참조 제거."})
    sec=now_ts()-st; write_status("running", evaluated=len(rows), s_count=len(events), paper_latest_count=len(latest), info_needed_count=info_needed_count, info_pending_count=info_pending, near_s_info_pending=near_s_info_pending, cheap_reject_count=cheap_drop_count, fresh_ready_count=fresh_ready_count, info_not_requested=info_not_requested, orderflow_attached_count=orderflow_attached_count, quote_ready_count=quote_ready_count, micro_ready_count=micro_ready_count, full_info_ready_count=full_info_ready_count, priority_request_count=len(priority_requests), target_count=len(target), router_target_count=tq.get("active_target_count", tq.get("target_count","-")), router_queue_count=tq.get("queue_count","-"), router_backlog_count=tq.get("backlog_count","-"), last_sec=round(sec,3)); return {"eval":len(rows),"s":len(events),"paper_latest":len(latest),"priority_requests":len(priority_requests),"info_needed":info_needed_count,"info_pending":info_pending,"cheap_drop":cheap_drop_count}
def main()->None:
    write_status("running", phase="boot", evaluated=0, s_count=0, target_count=0, last_sec=0)
    while True:
        try: run_once()
        except KeyboardInterrupt: write_status("stopping"); raise
        except Exception as exc: append_error(ERROR,"loop",exc); write_status("error", error=f"{exc.__class__.__name__}: {exc}")
        time.sleep(max(0.5,INTERVAL_SEC))


# =============================================================================
# strategy_worker v0.15: 후보 event_id/trace_id 단일화
# - 전략 후보가 archive/latest/paper OPEN/CLOSED까지 같은 ID로 이어지도록 보강한다.
# - 조건/S통과/청산 변경 없음. handoff 추적용 메타만 추가한다.
# =============================================================================
VERSION = "strategy_worker_v0.40"


def _v014_stable_event_id(row: Dict[str, Any], skey: str, ts: Optional[float] = None) -> str:
    t = ticker_norm((row or {}).get("ticker") or (row or {}).get("market") or (row or {}).get("symbol")) or "UNKNOWN"
    sk = str(skey or (row or {}).get("strategy_key") or (row or {}).get("strategy_bucket_primary") or "strategy_s")
    base_ts = fnum((row or {}).get("candidate_created_at"), (row or {}).get("source_created_at"), (row or {}).get("detected_ts"), (row or {}).get("event_ts"), (row or {}).get("created_at"), default=0.0)
    if base_ts <= 0:
        base_ts = ts or now_ts()
    # 30초 버킷: 같은 S 후보가 너무 자주 새 ID로 갈라지지 않게 하되, 너무 오래 같은 후보로 묶이지 않게 한다.
    return f"ev:{t}:{sk}:{int(base_ts // 30)}"


def _v014_attach_trace_fields(row: Dict[str, Any], skey: Optional[str] = None) -> Dict[str, Any]:
    out = dict(row or {})
    sk = str(skey or out.get("strategy_key") or out.get("strategy_bucket_primary") or "strategy_s")
    eid = str(out.get("event_id") or out.get("event_key") or out.get("id") or "")
    if not eid:
        eid = _v014_stable_event_id(out, sk)
        out["event_id_origin"] = "v014_fallback"
    else:
        out.setdefault("event_id_origin", "strategy")
    out["event_id"] = eid
    out["event_key"] = eid
    out["trace_id"] = eid
    out["handoff_id"] = eid
    out["candidate_uid"] = eid
    out["source_event_id"] = eid
    out["handoff_stage"] = "strategy_handoff"
    out["handoff_status"] = "candidate_created"
    ctx = out.get("entry_context") if isinstance(out.get("entry_context"), dict) else {}
    ctx.update({"event_id": eid, "event_key": eid, "trace_id": eid, "handoff_id": eid, "candidate_uid": eid})
    out["entry_context"] = ctx
    snap = out.get("entry_snapshot") if isinstance(out.get("entry_snapshot"), dict) else None
    if snap is not None:
        snap["event_id"] = eid
        snap["trace_id"] = eid
        snap["handoff_id"] = eid
        flat = snap.get("flat") if isinstance(snap.get("flat"), dict) else {}
        flat.update({"event_id": eid, "trace_id": eid, "handoff_id": eid})
        snap["flat"] = flat
        out["entry_snapshot"] = snap
    return out

_v014_prev_build_event = build_event

def build_event(row, of, skey, reasons):  # type: ignore[override]
    ev = _v014_prev_build_event(row, of, skey, reasons)
    return _v014_attach_trace_fields(ev, skey)

_v014_prev_normalize_paper_event = _normalize_paper_event

def _normalize_paper_event(ev: Dict[str, Any], ttl_sec: float = CANDIDATE_TTL_SEC) -> Dict[str, Any]:  # type: ignore[override]
    row = _v014_prev_normalize_paper_event(ev, ttl_sec)
    return _v014_attach_trace_fields(row, row.get("strategy_key") or row.get("strategy_bucket_primary"))



# =============================================================================
# strategy_worker v0.15: S 단일 OPEN을 S1/S2/S3 단계로 분리
# - S1만 즉시 paper OPEN 대상이다.
# - S2는 재확인 후보로 handoff/trace에는 남기되 즉시 OPEN하지 않는다.
# - S3는 관찰/복기 후보로 남긴다.
# - ABC 등급은 새 후보에서 사용하지 않는다.
# =============================================================================
VERSION = "strategy_worker_v0.40"

_v015_prev_build_event = build_event

def _v015_bool(v: Any) -> bool:
    if isinstance(v, bool): return v
    return str(v).strip().lower() in {"1","true","yes","ok","fresh","신선"}

def _v015_stage_decision(row: Dict[str, Any], of: Dict[str, Any], skey: str) -> Tuple[str, List[str]]:
    """v0.16/v359 S1 안전문.
    점수만 높고 가격반응/체결지속/호가 검증이 비어 있던 후보가 S1로 즉시 OPEN되던 구멍을 막는다.
    결측값은 통과가 아니라 S2/S3 강등 사유로 본다.
    """
    def _known(*keys: str, src: Optional[Dict[str, Any]] = None) -> bool:
        d = src if isinstance(src, dict) else row
        for k in keys:
            v = d.get(k)
            if v is not None and str(v).strip() not in {'', '-', 'None', 'nan'}:
                return True
        return False

    ch30s=fnum(row.get('change_30s'), row.get('price_change_30s'), default=0.0)
    ch1=fnum(row.get('change_1m'), row.get('price_change_1m'), default=0.0)
    ch3=fnum(row.get('change_3m'), row.get('price_change_3m'), default=0.0)
    ch5=fnum(row.get('change_5m'), row.get('price_change_5m'), default=0.0)
    ch15=fnum(row.get('change_15m'), row.get('price_change_15m'), default=0.0)
    ch30=fnum(row.get('change_30m'), row.get('price_change_30m'), default=0.0)
    price_react_known=_known('price_reaction_score','price_recheck_pct','price_reaction_pct')
    price_react=fnum(row.get('price_reaction_score'), row.get('price_recheck_pct'), row.get('price_reaction_pct'), default=-999.0)
    vwap=fnum(row.get('vwap_gap_pct'), default=-9.0)
    ema=fnum(row.get('ema5_gap_pct'), row.get('ma5_gap_pct'), default=-9.0)
    high_gap=fnum(row.get('recent_high_gap_pct'), row.get('below_high_pct'), default=0.0)
    low_reb=fnum(row.get('recent_low_rebound_pct'), row.get('low_defense_pct'), default=0.0)
    day=fnum(row.get('day_pos_pct'), row.get('current_close_pos_ratio'), default=50.0)
    rel=fnum(row.get('relative_strength_pct'), row.get('relative_strength'), default=0.0)
    buy=fnum(of.get('buy_ratio'), of.get('buy_ratio_30s'), of.get('micro_trade_buy_ratio_30'), default=0.0)
    buy1_known=_known('buy_ratio_1m','buy_ratio_60','micro_buy_ratio_sustain_1m','buy_ratio_sustain', src=of)
    buy1=fnum(of.get('buy_ratio_1m'), of.get('buy_ratio_60'), of.get('micro_buy_ratio_sustain_1m'), of.get('buy_ratio_sustain'), default=-1.0)
    spread=fnum(of.get('spread_pct'), of.get('micro_spread_pct'), default=99.0)
    slip_known=_known('slippage_est_pct','tick_pct_est','expected_slippage_pct', src=of)
    slip=fnum(of.get('slippage_est_pct'), of.get('tick_pct_est'), of.get('expected_slippage_pct'), default=99.0)
    ask_known=_known('ask_wall_ratio','ask_wall','micro_ask_wall_ratio', src=of)
    ask_wall=fnum(of.get('ask_wall_ratio'), of.get('ask_wall'), of.get('micro_ask_wall_ratio'), default=-1.0)
    bid_wall=fnum(of.get('bid_wall_ratio'), of.get('micro_bid_ask_wall_ratio'), default=0.0)
    micro=_v015_bool(of.get('micro_fresh'))
    ws=_v015_bool(of.get('ws_fresh') or of.get('quote_fresh'))
    vol=bool(row.get('volume_expanding'))
    breakout=bool(row.get('breakout_hint'))
    sweep=bool(row.get('sweep_reclaim_hint'))
    sell=bool(of.get('sell_pressure') or of.get('ask_wall_pressure') or of.get('sell_trade_pressure'))
    hard=common_hard(row, of)
    recent_loss = any('최근반복손실' in str(x) or '하드손실' in str(x) for x in hard)

    tags: List[str]=[]
    if not micro: tags.append('micro재확인필요')
    if not ws: tags.append('WS재확인필요')
    if not price_react_known: tags.append('가격반응미확인')
    elif price_react < 0.05: tags.append('가격반응부족')
    if not buy1_known: tags.append('매수체결지속미확인')
    elif buy1 < 0.64: tags.append('매수체결지속부족')
    if buy and buy < 0.68: tags.append('매수체결우세부족')
    if spread > 0.18: tags.append('스프레드주의')
    if not slip_known or slip > 0.20: tags.append('슬리피지미확인/주의')
    if not ask_known: tags.append('매도벽미확인')
    if sell or (ask_known and ask_wall >= 1.15 and bid_wall < ask_wall): tags.append('매도압력주의')
    if recent_loss: tags.append('최근반복손실주의')

    high_end = day >= 90.0 and high_gap >= -0.20
    overheat = (ch5 >= 6.0 and (ema >= 3.0 or vwap >= 0.80)) or ch15 >= 12.0 or ema >= 8.0
    top_without_react = high_end and (not price_react_known or price_react < 0.08)
    weak_relative_money = skey == 'money_reaccel_s' and rel < 0 and ch5 < 5.0
    if high_end: tags.append('고점권')
    if overheat: tags.append('급등과열/과이격')
    if weak_relative_money: tags.append('상대강도음수')

    # S1은 결측값 대체 금지. 실제 가격반응+체결지속+호가안정이 모두 있어야 한다.
    price_alive_s1 = price_react_known and price_react >= 0.05 and (ch30s >= 0.02 or ch1 >= 0.08 or ch3 >= 0.25)
    flow_alive = (ch3 >= 0.20 or ch5 >= 0.35)
    order_ok_s1 = micro and ws and buy >= 0.70 and buy1_known and buy1 >= 0.64 and spread <= 0.18 and slip_known and slip <= 0.20 and ask_known and not sell
    position_ok_s1 = not recent_loss and not top_without_react and not overheat and not weak_relative_money and vwap >= -0.03 and ema >= -0.05
    base_s1 = order_ok_s1 and position_ok_s1 and price_alive_s1 and flow_alive

    # S2는 살려야 할 후보: 점수/흐름은 있는데 즉시진입 안전문이 부족한 경우.
    # 결측/고점/과열 후보도 버리지 않고 재확인으로 보낸다.
    price_alive_s2 = (price_react_known and price_react >= 0.00) or ch1 >= 0.05 or ch3 >= 0.18 or ch5 >= 0.30 or vol
    order_ok_s2 = micro and buy >= 0.62 and spread <= 0.28 and not sell
    position_ok_s2 = not recent_loss and vwap >= -0.08 and ema >= -0.12

    if skey == 'money_reaccel_s':
        s1 = base_s1 and ch3 >= 0.35 and ch5 >= 0.45 and vol and rel >= 0.0
        s2 = order_ok_s2 and position_ok_s2 and (ch3 >= 0.20 or ch5 >= 0.35 or vol) and not (overheat and not price_react_known)
    elif skey == 'breakout_early_s':
        s1 = base_s1 and breakout and vol and high_gap >= -0.08 and ch3 >= 0.15 and not high_end
        s2 = order_ok_s2 and breakout and high_gap >= -0.25 and (vol or ch3 >= 0.15)
    elif skey == 'sweep_vwap_recovery_s':
        s1 = base_s1 and sweep and low_reb >= 0.55 and ch3 >= 0.08 and day < 88
        s2 = order_ok_s2 and sweep and vwap >= -0.08 and low_reb >= 0.35 and price_alive_s2
    elif skey == 'surge_rebreak_s':
        s1 = base_s1 and ch15 >= 1.20 and ch3 >= 0.25 and high_gap >= -0.15 and not overheat
        s2 = order_ok_s2 and ch15 >= 1.00 and high_gap >= -0.30 and price_alive_s2
    elif skey == 'leader_flow_adaptive_hold_s':
        mid_trend = ch15 >= 0.70 and ch30 >= 0.40 and rel >= 0.0 and vwap >= -0.03 and ema >= -0.05
        early_alive = ch3 >= 0.20 or ch5 >= 0.45 or vol
        s1 = base_s1 and mid_trend and early_alive and not high_end
        s2 = order_ok_s2 and position_ok_s2 and (ch15 >= 0.55 or ch5 >= 0.55) and vwap >= -0.08 and ema >= -0.12 and not recent_loss
    elif skey == 'leader_momentum_s':
        s1 = base_s1 and ch15 >= 0.75 and ch30 >= 0.75 and rel >= 0.40 and row.get('market_mode') != '약함'
        s2 = order_ok_s2 and ch15 >= 0.60 and rel >= 0.25 and vwap >= -0.05 and price_alive_s2
    else:
        s1 = base_s1
        s2 = order_ok_s2 and position_ok_s2 and price_alive_s2

    if s1:
        return 'S1', ['즉시진입안전문통과'] + tags[:7]
    if s2:
        return 'S2', ['재확인후진입후보'] + tags[:7]
    return 'S3', ['관찰복기후보'] + tags[:7]

def _v015_apply_stage(ev: Dict[str, Any], row: Dict[str, Any], of: Dict[str, Any], skey: str) -> Dict[str, Any]:
    stage, why = _v015_stage_decision(row, of, skey)
    out = dict(ev or {})
    label = {'S1':'✅ S1 즉시진입','S2':'⚠️ S2 재확인','S3':'❔ S3 관찰복기'}[stage]
    out['s_stage'] = stage
    out['candidate_grade'] = stage
    out['grade'] = stage
    out['entry_grade'] = stage
    out['signal_grade'] = stage
    out['candidate_grade_label'] = label
    out['s_stage_reasons'] = why[:8]
    out['paper_bot_open'] = stage == 'S1'
    out['open_eligible'] = stage == 'S1'
    out['trade_ready'] = stage == 'S1'
    out['recheck_required'] = stage == 'S2'
    out['observe_only'] = stage == 'S3'
    out['decision_stage'] = stage
    ctx = out.get('entry_context') if isinstance(out.get('entry_context'), dict) else {}
    ctx.update({'s_stage': stage, 'candidate_grade': stage, 'candidate_grade_label': label, 'paper_bot_open': stage == 'S1', 'open_eligible': stage == 'S1', 'trade_ready': stage == 'S1', 's_stage_reasons': why[:8]})
    out['entry_context'] = ctx
    snap = out.get('entry_snapshot') if isinstance(out.get('entry_snapshot'), dict) else None
    if snap is not None:
        strat = snap.get('strategy') if isinstance(snap.get('strategy'), dict) else {}
        strat.update({'decision_stage': stage, 'decision_note': label, 's_stage_reasons': why[:8]})
        snap['strategy'] = strat
        flat = snap.get('flat') if isinstance(snap.get('flat'), dict) else {}
        flat.update({'s_stage': stage, 'candidate_grade': stage, 'candidate_grade_label': label})
        snap['flat'] = flat
        out['entry_snapshot'] = snap
    return out

def build_event(row, of, skey, reasons):  # type: ignore[override]
    ev = _v015_prev_build_event(row, of, skey, reasons)
    return _v015_apply_stage(ev, row, of, skey)

def _normalize_paper_event(ev: Dict[str, Any], ttl_sec: float = CANDIDATE_TTL_SEC) -> Dict[str, Any]:  # type: ignore[override]
    row = dict(ev or {})
    ts = _event_created_ts(row) or now_ts()
    ticker = ticker_norm(row.get('ticker') or row.get('market') or row.get('symbol'))
    skey = str(row.get('strategy_key') or row.get('strategy_bucket_primary') or 'strategy_s')
    scan_id = row.get('scan_id') or row.get('source_scan_id') or f"strategy_s_{int(ts // 60)}"
    eid = row.get('event_id') or row.get('id') or row.get('event_key') or f"{ticker}:{skey}:{int(ts // 60)}"
    stage = str(row.get('s_stage') or row.get('candidate_grade') or row.get('grade') or 'S3').upper()
    if stage == 'S': stage = 'S1'
    if stage not in {'S1','S2','S3'}: stage = 'S3'
    row.update({
        'ticker': ticker, 'market': f'KRW-{ticker}' if ticker else row.get('market'), 'symbol': f'{ticker}_KRW' if ticker else row.get('symbol'),
        'created_at': ts, 'candidate_created_at': ts, 'source_created_at': ts, 'detected_ts': ts, 'event_ts': ts,
        'created_at_text': row.get('created_at_text') or now_text(ts), 'detected_at_text': row.get('detected_at_text') or now_text(ts),
        'updated_ts': now_ts(), 'expires_at': row.get('expires_at') or (ts + ttl_sec), 'event_id': eid, 'event_key': eid,
        'scan_id': scan_id, 'lane': 'strict', 's_stage': stage, 'candidate_grade': stage, 'grade': stage,
        'entry_grade': stage, 'signal_grade': stage,
        'candidate_grade_label': row.get('candidate_grade_label') or {'S1':'✅ S1 즉시진입','S2':'⚠️ S2 재확인','S3':'❔ S3 관찰복기'}[stage],
        'paper_bot_open': stage == 'S1', 'open_eligible': stage == 'S1', 'trade_ready': stage == 'S1',
        'recheck_required': stage == 'S2', 'observe_only': stage == 'S3',
    })
    ctx = row.get('entry_context') if isinstance(row.get('entry_context'), dict) else {}
    for k in ('ws_fresh','micro_fresh','spread_pct','buy_ratio','sell_pressure','orderflow_score'):
        if k in ctx and row.get(k) in (None, ''):
            row[k] = ctx.get(k)
    ctx.update({'s_stage': stage, 'candidate_grade': stage, 'candidate_grade_label': row.get('candidate_grade_label'), 'paper_bot_open': stage == 'S1', 'open_eligible': stage == 'S1', 'trade_ready': stage == 'S1'})
    row['entry_context'] = ctx
    return _v014_attach_trace_fields(row, skey) if '_v014_attach_trace_fields' in globals() else row

_v015_prev_persist_paper_handoff = persist_paper_handoff

def persist_paper_handoff(events: List[Dict[str, Any]], evaluated: int = 0) -> Tuple[List[Dict[str, Any]], int]:  # type: ignore[override]
    latest, appended = _v015_prev_persist_paper_handoff(events, evaluated=evaluated)
    try:
        counts = {'S1':0,'S2':0,'S3':0}
        for r in latest:
            g = str(r.get('s_stage') or r.get('candidate_grade') or r.get('grade') or 'S3').upper()
            if g == 'S': g = 'S1'
            if g in counts: counts[g] += 1
        h = load_json(HANDOFF, {}) or {}
        h.update({'s_stage_counts': counts, 's1_count': counts.get('S1',0), 's2_count': counts.get('S2',0), 's3_count': counts.get('S3',0), 'stage_note': 'v0.15: S1만 즉시 OPEN, S2 재확인, S3 관찰복기'})
        save_json(HANDOFF, h)
    except Exception as exc:
        append_error(ERROR, 'v015_persist_stage_counts', exc)
    return latest, appended


# =============================================================================
# strategy_worker v0.17 / v360: S2/S3 관찰·재확인 배관 복구
# - v359는 S1 안전문으로 손실 폭탄은 막았지만, S 후보를 통과한 뒤에만 S2/S3를 만들었다.
# - 그래서 S1이 0이면 S2/S3도 0이 되어 복기 재료가 사라졌다.
# - v360은 S1 안전문은 유지하고, core_hit 정보대기/차단/근접 후보를 S2/S3로 저장한다.
# - S2/S3는 paper_bot_open=False라 즉시 OPEN하지 않고, 1시간 요약/복기/trace용으로만 남긴다.
# =============================================================================

def _v360_force_stage(ev: Dict[str, Any], stage: str, extra_reasons: List[str]) -> Dict[str, Any]:
    stage = str(stage or 'S3').upper()
    if stage not in {'S1','S2','S3'}:
        stage = 'S3'
    out = dict(ev or {})
    label = {'S1':'✅ S1 즉시진입','S2':'⚠️ S2 재확인','S3':'❔ S3 관찰복기'}[stage]
    reasons = list(out.get('s_stage_reasons') if isinstance(out.get('s_stage_reasons'), list) else [])
    for r in extra_reasons or []:
        if r and r not in reasons:
            reasons.append(str(r))
    out.update({
        's_stage': stage,
        'candidate_grade': stage,
        'grade': stage,
        'entry_grade': stage,
        'signal_grade': stage,
        'candidate_grade_label': label,
        's_stage_reasons': reasons[:10],
        'paper_bot_open': stage == 'S1',
        'open_eligible': stage == 'S1',
        'trade_ready': stage == 'S1',
        'recheck_required': stage == 'S2',
        'observe_only': stage == 'S3',
        'decision_stage': stage,
        'final_entry_action': 'paper_open' if stage == 'S1' else ('recheck_wait' if stage == 'S2' else 'observe'),
        'final_entry_label': label,
        'trade_ready_label': label,
        'summary_reason': ','.join(reasons[:5]) or label,
    })
    ctx = out.get('entry_context') if isinstance(out.get('entry_context'), dict) else {}
    ctx.update({
        's_stage': stage,
        'candidate_grade': stage,
        'candidate_grade_label': label,
        'paper_bot_open': stage == 'S1',
        'open_eligible': stage == 'S1',
        'trade_ready': stage == 'S1',
        'recheck_required': stage == 'S2',
        'observe_only': stage == 'S3',
        's_stage_reasons': reasons[:10],
        'final_entry_action': out.get('final_entry_action'),
        'final_entry_label': label,
    })
    out['entry_context'] = ctx
    snap = out.get('entry_snapshot') if isinstance(out.get('entry_snapshot'), dict) else None
    if snap is not None:
        strat = snap.get('strategy') if isinstance(snap.get('strategy'), dict) else {}
        strat.update({'decision_stage': stage, 'decision_note': label, 's_stage_reasons': reasons[:10]})
        snap['strategy'] = strat
        flat = snap.get('flat') if isinstance(snap.get('flat'), dict) else {}
        flat.update({'s_stage': stage, 'candidate_grade': stage, 'candidate_grade_label': label, 'paper_bot_open': stage == 'S1'})
        snap['flat'] = flat
        out['entry_snapshot'] = snap
    return out

def _v360_near_strategy_hits(row: Dict[str, Any], of: Dict[str, Any], evals: List[Tuple[str, Any]]) -> List[Tuple[str, List[str], List[str]]]:
    """S1/S strict 통과 전 단계의 근접 후보를 찾는다.
    조건을 통과하지 못한 후보를 전부 살리는 게 아니라, 한두 개 부족한 후보만 S3 관찰로 남긴다.
    """
    near: List[Tuple[str, List[str], List[str]]] = []
    for skey, fn in evals:
        try:
            ok, why, no = fn(row, of)
            if ok:
                continue
            no = list(no or [])
            # v367: S2/S3 관찰은 strict 통과 직전만 보지 않는다.
            # 거래대금 자체가 부족한 후보는 버리되, 흐름/위치/체결 중 3~4개 부족한 근접 후보는 S3 복기로 남긴다.
            no_text = ','.join(map(str, no))
            hard_missing = ('거래대금부족' in no_text) or ('흐름유지부족' in no_text and 'VWAP/EMA유지부족' in no_text and len(no) >= 5)
            limit = 4 if skey == 'leader_flow_adaptive_hold_s' else 3
            if (not hard_missing) and len(no) <= limit:
                near.append((skey, list(why or []), no))
        except Exception:
            continue
    def score(item: Tuple[str, List[str], List[str]]) -> float:
        skey, _why, no = item
        pri = _priority_score(row, [(skey, _why)], [], [])
        return pri - len(no) * 3.0
    near.sort(key=score, reverse=True)
    return near[:3]

def run_once()->Dict[str,Any]:  # type: ignore[override]
    st=now_ts(); ts=now_ts(); write_status("running", phase="evaluating_v367", evaluated=0, s_count=0, target_count=0, last_sec=0)
    fobj=load_json(FEATURE,{}) or {}; rows=feature_rows(fobj)
    ofmap=map_rows(load_json(ORDERFLOW,{}) or {})
    evals=[("leader_flow_adaptive_hold_s",eval_adaptive_hold),("money_reaccel_s",eval_money),("leader_momentum_s",eval_leader),("breakout_early_s",eval_breakout),("sweep_vwap_recovery_s",eval_sweep),("surge_rebreak_s",eval_surge)]
    events=[]; rejects=[]; priority_requests=[]; strat_counts={k:0 for k in STRATEGIES}
    info_pending=0; near_s_info_pending=0; hard_blocked=0; info_not_requested=0
    info_needed_count=0; cheap_drop_count=0; fresh_ready_count=0
    orderflow_attached_count=0; quote_ready_count=0; micro_ready_count=0; full_info_ready_count=0
    priority_buckets={}; cheap_buckets={}; stage_source_counts={"S1":0,"S2":0,"S3":0,"core_ready":0,"core_info_wait":0,"core_hard_block":0,"near_observe":0}
    for row in rows:
        t=ticker_norm(row.get("ticker"))
        if not t: continue
        of=ofmap.get(t,{}) or {}
        if of: orderflow_attached_count += 1
        quote_ready = bool(of.get("quote_fresh") or of.get("ws_fresh"))
        micro_ready = bool(of.get("micro_fresh"))
        if quote_ready: quote_ready_count += 1
        if micro_ready: micro_ready_count += 1
        if quote_ready and micro_ready: full_info_ready_count += 1
        hard_bad = common_hard(row,of)
        reasons=[]; core_hits=[]; core_fail=[]
        for skey,fn in evals:
            ok,why,no=fn(row,of)
            if ok:
                core_hits.append((skey,why))
            else:
                core_fail += [f"{STRATEGIES.get(skey,skey)}:{x}" for x in no[:2]]
        need_info, cheap_bucket = _cheap_gate(row, core_hits, hard_bad)
        cheap_buckets[cheap_bucket]=cheap_buckets.get(cheap_bucket,0)+1
        info_bad = orderflow_info_bad(of) if need_info else []
        need=[]
        if "시세정보보강대기" in info_bad: need.append("quote")
        if "WS정보보강대기" in info_bad: need.append("ws")
        if "micro정보보강대기" in info_bad: need.append("micro")
        if need_info: info_needed_count += 1
        if need_info and not info_bad: fresh_ready_count += 1
        pscore=_priority_score(row, core_hits, info_bad, hard_bad)
        if info_bad: info_pending += 1

        # 1) core strategy가 맞고 정보/하드 문제가 없으면 기존처럼 이벤트 생성. v359 안전문이 S1/S2/S3를 최종 결정한다.
        if core_hits and not hard_bad and not info_bad:
            ev=build_event(row,of,core_hits[0][0],core_hits[0][1])
            if len(core_hits)>1:
                ev["multi_strategy_s"]=[k for k,_ in core_hits]; ev["strategy_bucket_labels"]=[STRATEGIES.get(k,k) for k,_ in core_hits]
            events.append(ev)
            g=str(ev.get('s_stage') or ev.get('candidate_grade') or 'S3').upper(); stage_source_counts[g if g in stage_source_counts else 'S3']+=1; stage_source_counts['core_ready']+=1
            strat_counts[core_hits[0][0]]+=1
            priority_requests.append(_make_priority_request(t,row,"s_candidate",130+pscore, ["quote","micro"], core_hits, ["S후보유지"]))
            priority_buckets["s_candidate"]=priority_buckets.get("s_candidate",0)+1
        # 2) core는 맞지만 정보가 모자라면 S2 재확인으로 남긴다. 즉시 OPEN은 절대 안 한다.
        elif core_hits and info_bad and not hard_bad:
            near_s_info_pending += 1
            reasons += [f"정보보강대기:{x}" for x in info_bad[:3]] + [f"S2재확인:{STRATEGIES.get(k,k)}" for k,_ in core_hits[:2]]
            ev=build_event(row,of,core_hits[0][0],core_hits[0][1])
            ev=_v360_force_stage(ev,'S2',reasons[:8])
            events.append(ev); stage_source_counts['S2']+=1; stage_source_counts['core_info_wait']+=1
            priority_requests.append(_make_priority_request(t,row,"s2_recheck_info_wait",115+pscore, need or ["quote","micro"], core_hits, reasons))
            priority_buckets["s2_recheck_info_wait"]=priority_buckets.get("s2_recheck_info_wait",0)+1
        # 3) core는 맞지만 최근손실/고점/스프레드 등 hard가 있으면 S3 관찰로 남긴다.
        elif core_hits and hard_bad:
            hard_blocked += 1
            reasons += hard_bad[:4] + [f"S3관찰:{STRATEGIES.get(k,k)}" for k,_ in core_hits[:2]]
            ev=build_event(row,of,core_hits[0][0],core_hits[0][1])
            ev=_v360_force_stage(ev,'S3',reasons[:8])
            events.append(ev); stage_source_counts['S3']+=1; stage_source_counts['core_hard_block']+=1
            if info_bad:
                info_not_requested += 1
                priority_buckets["hard_blocked_not_requested"]=priority_buckets.get("hard_blocked_not_requested",0)+1
        else:
            # 4) strict S는 아니지만 한두 조건만 부족한 후보는 S3 관찰복기로 살린다.
            near_hits = _v360_near_strategy_hits(row, of, evals)
            if near_hits and not any('거래대금부족' in str(x) for x in hard_bad):
                skey, why, missing = near_hits[0]
                reasons += [f"근접부족:{x}" for x in missing[:3]] + [f"S3관찰:{STRATEGIES.get(skey,skey)}"]
                if info_bad:
                    reasons += [f"정보보강대기:{x}" for x in info_bad[:2]]
                ev=build_event(row,of,skey,why)
                ev=_v360_force_stage(ev,'S3',reasons[:8])
                events.append(ev); stage_source_counts['S3']+=1; stage_source_counts['near_observe']+=1
                if info_bad:
                    bucket="s3_observe_info_wait"
                    priority_requests.append(_make_priority_request(t,row,bucket, 75+pscore, need, [(skey,why)], reasons))
                    priority_buckets[bucket]=priority_buckets.get(bucket,0)+1
            else:
                if info_bad:
                    reasons += [f"정보보강대기:{x}" for x in info_bad[:2]]
                reasons += hard_bad[:2] + core_fail[:4]
                if info_bad:
                    bucket = "info_wait_high"
                    priority_requests.append(_make_priority_request(t,row,bucket, 70+pscore, need, core_hits, reasons))
                    priority_buckets[bucket]=priority_buckets.get(bucket,0)+1
                else:
                    if cheap_bucket == "cheap_drop": cheap_drop_count += 1
                    elif not need_info: info_not_requested += 1
        if not core_hits:
            rejects.append({"ticker":t,"score":fnum(row.get("scanner_priority_score")),"priority":pscore,"reasons":reasons[:8] if reasons else core_fail[:8],"price":row.get("current_price"),"updated_ts":ts,"info_pending":bool(info_bad),"info_needed":bool(need_info),"near_s_info_pending":False,"cheap_bucket":cheap_bucket})
        elif not (not hard_bad and not info_bad):
            rejects.append({"ticker":t,"score":fnum(row.get("scanner_priority_score")),"priority":pscore,"reasons":reasons[:8],"price":row.get("current_price"),"updated_ts":ts,"info_pending":bool(info_bad),"info_needed":bool(need_info),"near_s_info_pending":bool(core_hits and info_bad and not hard_bad),"cheap_bucket":cheap_bucket})
    events.sort(key=lambda e:(0 if str(e.get('s_stage') or e.get('candidate_grade')).upper()=='S1' else -1, fnum(e.get("score")), _event_created_ts(e)), reverse=True)
    latest, appended = persist_paper_handoff(events, evaluated=len(rows))
    ctr={}
    for r in rejects:
        for reason in r.get("reasons",[])[:5]: ctr[reason]=ctr.get(reason,0)+1
    top=sorted(ctr.items(), key=lambda x:x[1], reverse=True)[:20]
    priority_requests = sorted(priority_requests, key=lambda x: fnum(x.get("priority"), default=0), reverse=True)
    target = list(dict.fromkeys([r.get("ticker") for r in priority_requests if r.get("ticker")]))
    save_json(PRIORITY_REQ,{"version":VERSION,"updated_ts":ts,"updated_text":now_text(ts),"request_count":len(priority_requests),"targets":target,"requests":priority_requests,"buckets":priority_buckets,"cheap_buckets":cheap_buckets,"stage_source_counts":stage_source_counts,"note":"v0.19/v367: S1 안전문 유지 + S2/S3 관찰배관 복구. core 정보대기/차단/근접 후보를 OPEN 없이 복기용으로 저장."})
    tq=load_json(TARGET_ROUTER_QUEUE,{}) or {}
    active_set=set(tq.get("active_targets",[]) if isinstance(tq,dict) and isinstance(tq.get("active_targets"),list) else [])
    priority_wait_sample=[]
    for pr in priority_requests[:12]:
        tt=ticker_norm(pr.get("ticker")); of=ofmap.get(tt,{}) or {}
        priority_wait_sample.append({"ticker": tt,"bucket": pr.get("bucket"),"need": pr.get("need"),"priority": pr.get("priority"),"quote_ready": bool(of.get("quote_fresh") or of.get("ws_fresh")),"micro_ready": bool(of.get("micro_fresh")),"info_ready": bool((of.get("quote_fresh") or of.get("ws_fresh")) and of.get("micro_fresh")),"router_active": tt in active_set or bool(of.get("router_active")),"micro_age_sec": of.get("micro_age_sec"),"quote_age_sec": of.get("quote_age_sec"),"reasons": pr.get("reasons",[])[:4]})
    stage_counts={"S1":0,"S2":0,"S3":0}
    for ev in latest:
        g=str(ev.get('s_stage') or ev.get('candidate_grade') or ev.get('grade') or 'S3').upper()
        if g == 'S': g='S1'
        if g in stage_counts: stage_counts[g]+=1
    common_summary={"version":VERSION,"updated_ts":ts,"updated_text":now_text(ts),"s_count":len(events),"paper_latest_count":len(latest),"archive_appended":appended,"strategies":strat_counts,"events":latest[:12],"evaluated":len(rows),"s_stage_counts":stage_counts,"stage_source_counts":stage_source_counts,"info_needed_count":info_needed_count,"info_pending_count":info_pending,"near_s_info_pending":near_s_info_pending,"fresh_ready_count":fresh_ready_count,"cheap_reject_count":cheap_drop_count,"hard_blocked_near_s":hard_blocked,"priority_request_count":len(priority_requests),"priority_buckets":priority_buckets,"cheap_buckets":cheap_buckets,"target_count":len(target),"info_not_requested":info_not_requested,"orderflow_attached_count":orderflow_attached_count,"quote_ready_count":quote_ready_count,"micro_ready_count":micro_ready_count,"full_info_ready_count":full_info_ready_count,"router_target_count":tq.get("active_target_count", tq.get("target_count","-")),"router_queue_count":tq.get("queue_count","-"),"router_backlog_count":tq.get("backlog_count","-"),"router_fresh_recovered":tq.get("fresh_recovered","-"),"router_need_ws":tq.get("need_ws","-"),"router_need_micro":tq.get("need_micro","-"),"router_micro_priority_target_count":tq.get("micro_priority_target_count","-"),"router_strategy_req_info_ready":tq.get("strategy_req_info_ready","-"),"priority_wait_sample":priority_wait_sample,"note":"v0.19/v367: S1은 엄격, S2/S3는 OPEN 없이 관찰·복기용으로 저장"}
    save_json(SUMMARY,common_summary)
    save_json(REJECT,{**common_summary,"reject_count":len(rejects),"reason_top":[{"reason":k,"count":v} for k,v in top],"sample":rejects[:30],"note":"v0.19/v367: S2/S3 관찰 후보를 살리되 S1 즉시진입은 안전문 유지."})
    sec=now_ts()-st; write_status("running", evaluated=len(rows), s_count=len(events), paper_latest_count=len(latest), s1_count=stage_counts.get('S1',0), s2_count=stage_counts.get('S2',0), s3_count=stage_counts.get('S3',0), info_needed_count=info_needed_count, info_pending_count=info_pending, near_s_info_pending=near_s_info_pending, cheap_reject_count=cheap_drop_count, fresh_ready_count=fresh_ready_count, info_not_requested=info_not_requested, orderflow_attached_count=orderflow_attached_count, quote_ready_count=quote_ready_count, micro_ready_count=micro_ready_count, full_info_ready_count=full_info_ready_count, priority_request_count=len(priority_requests), target_count=len(target), router_target_count=tq.get("active_target_count", tq.get("target_count","-")), router_queue_count=tq.get("queue_count","-"), router_backlog_count=tq.get("backlog_count","-"), last_sec=round(sec,3)); return {"eval":len(rows),"s":len(events),"paper_latest":len(latest),"s_stage_counts":stage_counts,"priority_requests":len(priority_requests),"info_needed":info_needed_count,"info_pending":info_pending,"cheap_drop":cheap_drop_count}



# =============================================================================
# strategy_worker v0.22 / v370: 끊긴 main_version stamping 본선 재연결
# - v367은 near 조건이 strict eval 실패 개수에 묶여 S2/S3가 0으로 죽었다.
# - v368은 strict S1 안전문은 유지하되, 거래대금·흐름·위치·주도성 기반 관찰 후보를 S2/S3로 별도 저장한다.
# - S2/S3는 paper OPEN 대상이 아니며 복기/1시간요약/정보보강 대상이다.
# =============================================================================
VERSION = "strategy_worker_v0.40"
MAIN_VERSION = "v2.13.394"


def _v370_apply_main_version(ev: Dict[str, Any]) -> Dict[str, Any]:
    """v370 worker-only surgery.
    v369 tail called a removed _v368_apply_main_version() helper and strategy worker
    stopped before writing paper/S2/S3 handoff files. This is not a fallback; it is
    the single metadata stamping path used right before S1/S2/S3 persistence.
    """
    out = dict(ev or {})
    main_version = MAIN_VERSION
    main_bot_version = globals().get("MAIN_BOT_VERSION", f"수익형 {main_version}")
    out["main_version"] = main_version
    out["deploy_version"] = main_version
    out["main_bot_version"] = main_bot_version
    out["strategy_worker_version"] = VERSION
    out["worker_patch"] = "v370_strategy_main_version_stamping"
    ctx = out.get("entry_context") if isinstance(out.get("entry_context"), dict) else {}
    ctx.update({
        "main_version": main_version,
        "deploy_version": main_version,
        "main_bot_version": main_bot_version,
        "strategy_worker_version": VERSION,
    })
    out["entry_context"] = ctx
    snap = out.get("entry_snapshot") if isinstance(out.get("entry_snapshot"), dict) else None
    if snap is not None:
        snap["main_version"] = main_version
        snap["deploy_version"] = main_version
        snap["strategy_worker_version"] = VERSION
        flat = snap.get("flat") if isinstance(snap.get("flat"), dict) else {}
        flat.update({
            "main_version": main_version,
            "deploy_version": main_version,
            "main_bot_version": main_bot_version,
            "strategy_worker_version": VERSION,
        })
        snap["flat"] = flat
        out["entry_snapshot"] = snap
    return out


def _v368_soft_signal(row: Dict[str, Any], of: Dict[str, Any]) -> Tuple[str, str, List[str], float]:
    """v369: strict S1은 아니어도 복기할 가치가 있는 후보를 S2/S3로 남긴다.
    쓰레기 후보(거래대금 부족/강한 매도압력)는 제외한다.
    """
    ch1=fnum(row.get('change_1m'), row.get('price_change_1m'), default=0.0)
    ch3=fnum(row.get('change_3m'), row.get('price_change_3m'), default=0.0)
    ch5=fnum(row.get('change_5m'), row.get('price_change_5m'), default=0.0)
    ch15=fnum(row.get('change_15m'), row.get('price_change_15m'), default=0.0)
    ch30=fnum(row.get('change_30m'), row.get('price_change_30m'), default=0.0)
    money=fnum(row.get('turnover_24h'), row.get('acc_trade_price_24h'), default=0.0)
    vwap=fnum(row.get('vwap_gap_pct'), default=-9.0)
    ema=fnum(row.get('ema5_gap_pct'), row.get('ma5_gap_pct'), default=-9.0)
    rel=fnum(row.get('relative_strength_pct'), row.get('relative_strength'), default=0.0)
    day=fnum(row.get('day_pos_pct'), row.get('current_close_pos_ratio'), default=50.0)
    score=fnum(row.get('scanner_priority_score'), default=0.0)
    buy=fnum(of.get('buy_ratio'), of.get('buy_ratio_30s'), of.get('micro_trade_buy_ratio_30'), default=0.0)
    spread=fnum(of.get('spread_pct'), of.get('micro_spread_pct'), default=99.0)
    micro=bool(of.get('micro_fresh'))
    quote=bool(of.get('quote_fresh') or of.get('ws_fresh'))
    vol=bool(row.get('volume_expanding'))
    hard=common_hard(row, of)
    hard_text=','.join(map(str, hard))
    if money < 250_000_000:
        return '', '', ['거래대금부족'], 0.0
    if '매도벽/매도체결압력' in hard_text and buy < 0.68:
        return '', '', ['매도압력+매수부족'], 0.0
    info_missing = not (micro and quote) or spread > 0.18
    position_ok = (vwap >= -0.45 and ema >= -0.35)
    not_extreme_hot = not (day >= 98.5 and ch5 >= 5.0 and rel < 3.0)
    # 유동보유: 5/15/30분 흐름, 상대강도, 위치 중 2개 이상 살아있으면 관찰
    trend_score = 0
    if ch5 >= 0.35: trend_score += 1
    if ch15 >= 0.35: trend_score += 1
    if ch30 >= 0.10: trend_score += 1
    if rel >= 1.2: trend_score += 1
    if vol: trend_score += 1
    if position_ok: trend_score += 1
    if trend_score >= 4 and not_extreme_hot:
        reasons=['유동보유근접', f'흐름점수{trend_score}', f'5m{ch5:.2f}', f'15m{ch15:.2f}', f'상대{rel:.2f}']
        return ('S3' if info_missing else 'S2'), 'leader_flow_adaptive_hold_s', reasons, 105.0 + score + trend_score
    # 돈흐름/돌파 근접: 한두 재료만 있어도 완전 폐기하지 않고 S3 복기
    if (ch3 >= 0.45 and ch5 >= 0.45 and position_ok) or (rel >= 2.0 and ch5 >= 0.20):
        reasons=['S근접관찰', f'3m{ch3:.2f}', f'5m{ch5:.2f}', f'상대{rel:.2f}']
        return ('S3' if info_missing else 'S2'), 'money_reaccel_s', reasons, 95.0 + score
    return '', '', [], 0.0

def _v370_build_stage_event(row: Dict[str, Any], of: Dict[str, Any], skey: str, why: List[str], stage: str, reasons: List[str]) -> Dict[str, Any]:
    ev=build_event(row, of, skey, why or reasons)
    ev=_v360_force_stage(ev, stage, reasons[:10])
    ev=_v370_apply_main_version(ev)
    return ev


def run_once()->Dict[str,Any]:  # type: ignore[override]
    st=now_ts(); ts=now_ts(); write_status("running", phase="evaluating_v370", evaluated=0, s_count=0, target_count=0, last_sec=0)
    fobj=load_json(FEATURE,{}) or {}; rows=feature_rows(fobj)
    ofmap=map_rows(load_json(ORDERFLOW,{}) or {})
    evals=[("leader_flow_adaptive_hold_s",eval_adaptive_hold),("money_reaccel_s",eval_money),("leader_momentum_s",eval_leader),("breakout_early_s",eval_breakout),("sweep_vwap_recovery_s",eval_sweep),("surge_rebreak_s",eval_surge)]
    events=[]; rejects=[]; priority_requests=[]; strat_counts={k:0 for k in STRATEGIES}
    info_pending=0; near_s_info_pending=0; hard_blocked=0; info_not_requested=0
    info_needed_count=0; cheap_drop_count=0; fresh_ready_count=0
    orderflow_attached_count=0; quote_ready_count=0; micro_ready_count=0; full_info_ready_count=0
    priority_buckets={}; cheap_buckets={}; stage_source_counts={"S1":0,"S2":0,"S3":0,"core_ready":0,"core_info_wait":0,"core_hard_block":0,"soft_observe":0}
    for row in rows:
        t=ticker_norm(row.get("ticker"))
        if not t: continue
        of=ofmap.get(t,{}) or {}
        if of: orderflow_attached_count += 1
        quote_ready=bool(of.get("quote_fresh") or of.get("ws_fresh")); micro_ready=bool(of.get("micro_fresh"))
        if quote_ready: quote_ready_count += 1
        if micro_ready: micro_ready_count += 1
        if quote_ready and micro_ready: full_info_ready_count += 1
        hard_bad=common_hard(row,of)
        reasons=[]; core_hits=[]; core_fail=[]
        for skey,fn in evals:
            try:
                ok,why,no=fn(row,of)
            except Exception as exc:
                ok=False; why=[]; no=[f"eval오류:{skey}"]
            if ok: core_hits.append((skey,why))
            else: core_fail += [f"{STRATEGIES.get(skey,skey)}:{x}" for x in list(no or [])[:2]]
        need_info, cheap_bucket=_cheap_gate(row, core_hits, hard_bad)
        cheap_buckets[cheap_bucket]=cheap_buckets.get(cheap_bucket,0)+1
        info_bad=orderflow_info_bad(of) if need_info else []
        need=[]
        if "시세정보보강대기" in info_bad: need.append("quote")
        if "WS정보보강대기" in info_bad: need.append("ws")
        if "micro정보보강대기" in info_bad: need.append("micro")
        if need_info: info_needed_count += 1
        if need_info and not info_bad: fresh_ready_count += 1
        pscore=_priority_score(row, core_hits, info_bad, hard_bad)
        if info_bad: info_pending += 1
        made=False
        if core_hits and not hard_bad and not info_bad:
            ev=_v370_build_stage_event(row,of,core_hits[0][0],core_hits[0][1],'S1', ['core_ready'])
            if len(core_hits)>1:
                ev["multi_strategy_s"]=[k for k,_ in core_hits]; ev["strategy_bucket_labels"]=[STRATEGIES.get(k,k) for k,_ in core_hits]
            events.append(ev); made=True
            g=str(ev.get('s_stage') or 'S3').upper(); stage_source_counts[g if g in stage_source_counts else 'S3']+=1; stage_source_counts['core_ready']+=1
            strat_counts[core_hits[0][0]]+=1
            priority_requests.append(_make_priority_request(t,row,"s1_candidate",130+pscore,["quote","micro"],core_hits,["S1후보"]))
            priority_buckets["s1_candidate"]=priority_buckets.get("s1_candidate",0)+1
        elif core_hits and info_bad and not hard_bad:
            near_s_info_pending += 1
            reasons += [f"정보보강대기:{x}" for x in info_bad[:3]] + [f"S2재확인:{STRATEGIES.get(k,k)}" for k,_ in core_hits[:2]]
            ev=_v370_build_stage_event(row,of,core_hits[0][0],core_hits[0][1],'S2',reasons)
            events.append(ev); made=True; stage_source_counts['S2']+=1; stage_source_counts['core_info_wait']+=1
            priority_requests.append(_make_priority_request(t,row,"s2_recheck_info_wait",115+pscore,need or ["quote","micro"],core_hits,reasons))
            priority_buckets["s2_recheck_info_wait"]=priority_buckets.get("s2_recheck_info_wait",0)+1
        elif core_hits and hard_bad:
            hard_blocked += 1
            reasons += hard_bad[:4] + [f"S3관찰:{STRATEGIES.get(k,k)}" for k,_ in core_hits[:2]]
            ev=_v370_build_stage_event(row,of,core_hits[0][0],core_hits[0][1],'S3',reasons)
            events.append(ev); made=True; stage_source_counts['S3']+=1; stage_source_counts['core_hard_block']+=1
        else:
            stage, skey, soft_reasons, bonus = _v368_soft_signal(row, of)
            if stage:
                ev=_v370_build_stage_event(row,of,skey,soft_reasons,stage,soft_reasons)
                events.append(ev); made=True; stage_source_counts[stage]+=1; stage_source_counts['soft_observe']+=1
                priority = bonus + (15 if stage=='S2' else 0)
                if stage=='S2': near_s_info_pending += 1
                bucket='s2_recheck_soft' if stage=='S2' else 's3_observe_soft'
                priority_requests.append(_make_priority_request(t,row,bucket,priority,need or ["quote","micro"],[(skey,soft_reasons)],soft_reasons))
                priority_buckets[bucket]=priority_buckets.get(bucket,0)+1
        if not made:
            if info_bad:
                reasons += [f"정보보강대기:{x}" for x in info_bad[:2]]
            reasons += hard_bad[:2] + core_fail[:4]
            if info_bad:
                bucket="info_wait_high"; priority_requests.append(_make_priority_request(t,row,bucket,70+pscore,need,core_hits,reasons)); priority_buckets[bucket]=priority_buckets.get(bucket,0)+1
            else:
                if cheap_bucket == "cheap_drop": cheap_drop_count += 1
                elif not need_info: info_not_requested += 1
            rejects.append({"ticker":t,"score":fnum(row.get("scanner_priority_score")),"priority":pscore,"reasons":reasons[:8] if reasons else core_fail[:8],"price":row.get("current_price"),"updated_ts":ts,"info_pending":bool(info_bad),"info_needed":bool(need_info),"near_s_info_pending":False,"cheap_bucket":cheap_bucket})
    events.sort(key=lambda e:(0 if str(e.get('s_stage') or e.get('candidate_grade')).upper()=='S1' else (-1 if str(e.get('s_stage') or e.get('candidate_grade')).upper()=='S2' else -2), fnum(e.get("score")), _event_created_ts(e)), reverse=True)
    latest, appended = persist_paper_handoff(events, evaluated=len(rows))
    ctr={}
    for r in rejects:
        for reason in r.get("reasons",[])[:5]: ctr[reason]=ctr.get(reason,0)+1
    top=sorted(ctr.items(), key=lambda x:x[1], reverse=True)[:20]
    priority_requests=sorted(priority_requests, key=lambda x:fnum(x.get("priority"), default=0), reverse=True)
    target=list(dict.fromkeys([r.get("ticker") for r in priority_requests if r.get("ticker")]))
    save_json(PRIORITY_REQ,{"version":VERSION,"main_version":MAIN_VERSION,"updated_ts":ts,"updated_text":now_text(ts),"request_count":len(priority_requests),"targets":target,"requests":priority_requests,"buckets":priority_buckets,"cheap_buckets":cheap_buckets,"stage_source_counts":stage_source_counts,"note":"v0.24/v378: S3→S2→S1 재평가 흐름. feature/orderflow canonical 판단값을 사용하고, 정보미생성은 진짜 정보부족으로만 남긴다."})
    tq=load_json(TARGET_ROUTER_QUEUE,{}) or {}
    active_set=set(tq.get("active_targets",[]) if isinstance(tq,dict) and isinstance(tq.get("active_targets"),list) else [])
    priority_wait_sample=[]
    for pr in priority_requests[:12]:
        tt=ticker_norm(pr.get("ticker")); of=ofmap.get(tt,{}) or {}
        priority_wait_sample.append({"ticker":tt,"bucket":pr.get("bucket"),"need":pr.get("need"),"priority":pr.get("priority"),"quote_ready":bool(of.get("quote_fresh") or of.get("ws_fresh")),"micro_ready":bool(of.get("micro_fresh")),"info_ready":bool((of.get("quote_fresh") or of.get("ws_fresh")) and of.get("micro_fresh")),"router_active":tt in active_set or bool(of.get("router_active")),"micro_age_sec":of.get("micro_age_sec"),"quote_age_sec":of.get("quote_age_sec"),"reasons":pr.get("reasons",[])[:4]})
    stage_counts={"S1":0,"S2":0,"S3":0}
    for ev in latest:
        g=str(ev.get('s_stage') or ev.get('candidate_grade') or ev.get('grade') or 'S3').upper()
        if g == 'S': g='S1'
        if g in stage_counts: stage_counts[g]+=1
    common_summary={"version":VERSION,"main_version":MAIN_VERSION,"updated_ts":ts,"updated_text":now_text(ts),"s_count":len(events),"paper_latest_count":len(latest),"archive_appended":appended,"strategies":strat_counts,"events":latest[:12],"evaluated":len(rows),"s_stage_counts":stage_counts,"stage_source_counts":stage_source_counts,"info_needed_count":info_needed_count,"info_pending_count":info_pending,"near_s_info_pending":near_s_info_pending,"fresh_ready_count":fresh_ready_count,"cheap_reject_count":cheap_drop_count,"hard_blocked_near_s":hard_blocked,"priority_request_count":len(priority_requests),"priority_buckets":priority_buckets,"cheap_buckets":cheap_buckets,"target_count":len(target),"info_not_requested":info_not_requested,"orderflow_attached_count":orderflow_attached_count,"quote_ready_count":quote_ready_count,"micro_ready_count":micro_ready_count,"full_info_ready_count":full_info_ready_count,"router_target_count":tq.get("active_target_count",tq.get("target_count","-")),"router_queue_count":tq.get("queue_count","-"),"router_backlog_count":tq.get("backlog_count","-"),"priority_wait_sample":priority_wait_sample,"note":"v0.24/v378: S3 관찰→S2 재확인→S1 즉시진입 흐름. micro/WS fresh에서 판단값 누락이 생기지 않도록 canonical schema 기준으로 재평가."}
    save_json(SUMMARY,common_summary)
    save_json(REJECT,{**common_summary,"reject_count":len(rejects),"reason_top":[{"reason":k,"count":v} for k,v in top],"sample":rejects[:30],"note":"v0.23/v374: 실제 쓰레기 후보만 탈락. 정보부족 근접 후보는 S2 정보보강/긴급재확인으로 저장."})
    sec=now_ts()-st
    write_status("running", evaluated=len(rows), s_count=len(events), paper_latest_count=len(latest), s1_count=stage_counts.get('S1',0), s2_count=stage_counts.get('S2',0), s3_count=stage_counts.get('S3',0), info_needed_count=info_needed_count, info_pending_count=info_pending, near_s_info_pending=near_s_info_pending, cheap_reject_count=cheap_drop_count, fresh_ready_count=fresh_ready_count, info_not_requested=info_not_requested, orderflow_attached_count=orderflow_attached_count, quote_ready_count=quote_ready_count, micro_ready_count=micro_ready_count, full_info_ready_count=full_info_ready_count, priority_request_count=len(priority_requests), target_count=len(target), router_target_count=tq.get("active_target_count",tq.get("target_count","-")), router_queue_count=tq.get("queue_count","-"), router_backlog_count=tq.get("backlog_count","-"), last_sec=round(sec,3))
    return {"eval":len(rows),"s":len(events),"paper_latest":len(latest),"s_stage_counts":stage_counts,"priority_requests":len(priority_requests),"info_needed":info_needed_count,"info_pending":info_pending,"cheap_drop":cheap_drop_count}


# =============================================================================
# strategy_worker v0.23: S1 근접 정보부족 긴급보강
# - core_ready라고 무조건 S1로 강제하지 않는다.
# - 가격반응/체결지속/슬리피지/호가 세부값이 미확인인 S1 근접 후보는
#   S2 정보보강대기로 남기고 target_router 우선요청에 태운다.
# - 정보부족 문구를 s_stage_reasons/entry_context에 명확히 남긴다.
# =============================================================================

def _v374_is_info_shortage_reason(x: Any) -> bool:
    t = str(x or '')
    return any(k in t for k in ('미확인', '정보보강', '재확인필요', '슬리피지미확인', 'micro재확인', 'WS재확인'))

def _v374_s1_info_need(row: Dict[str, Any], of: Dict[str, Any], stage_reasons: List[str]) -> Tuple[bool, List[str], List[str]]:
    reasons = [str(x) for x in (stage_reasons or []) if str(x or '').strip()]
    info_tags = [x for x in reasons if _v374_is_info_shortage_reason(x)]
    need: List[str] = []
    txt = ','.join(info_tags)
    if 'micro' in txt or '매수체결' in txt or '스프레드' in txt or '슬리피지' in txt or '매도벽' in txt:
        need.append('micro')
    if 'WS' in txt or '가격반응' in txt or '시세' in txt:
        need.append('quote'); need.append('ws')
    # orderflow_info_bad는 quote/micro fresh만 보므로, 세부 미확인값도 여기서 보강 대상으로 승격한다.
    if not need and info_tags:
        need = ['quote', 'micro']
    return (bool(info_tags), list(dict.fromkeys(need)), info_tags[:8])

_v374_prev_build_stage_event = _v370_build_stage_event

def _v370_build_stage_event(row: Dict[str, Any], of: Dict[str, Any], skey: str, why: List[str], stage: str, reasons: List[str]) -> Dict[str, Any]:  # type: ignore[override]
    ev = build_event(row, of, skey, why or reasons)
    # build_event 안의 S1/S2/S3 실제 안전문 판단을 먼저 존중한다.
    pre_stage = str(ev.get('s_stage') or ev.get('candidate_grade') or '').upper()
    pre_reasons = list(ev.get('s_stage_reasons') if isinstance(ev.get('s_stage_reasons'), list) else [])
    requested_stage = str(stage or 'S3').upper()
    info_wait, need, info_tags = _v374_s1_info_need(row, of, pre_reasons)
    final_stage = requested_stage
    final_reasons = list(reasons or [])
    if requested_stage == 'S1' and (pre_stage != 'S1' or info_wait):
        # 전략 core는 맞지만 S1 직전 정보가 비어 있으면 탈락/무시가 아니라 S2 정보보강대기로 둔다.
        final_stage = 'S2'
        final_reasons = ['S1정보부족재확인'] + info_tags + final_reasons
    ev = _v360_force_stage(ev, final_stage, final_reasons[:10])
    if final_stage == 'S2' and (info_wait or any(_v374_is_info_shortage_reason(x) for x in final_reasons)):
        ev['info_shortage_pending'] = True
        ev['urgent_recheck_needed'] = True
        ev['info_shortage_reasons'] = info_tags or [x for x in final_reasons if _v374_is_info_shortage_reason(x)][:8]
        ev['info_shortage_need'] = need or ['quote', 'micro']
        ev['recheck_required'] = True
        ev['recheck_reason'] = 'S1정보부족재확인'
        ev['summary_reason'] = ','.join((['S1정보부족재확인'] + (info_tags or []))[:5])
        ctx = ev.get('entry_context') if isinstance(ev.get('entry_context'), dict) else {}
        ctx.update({
            'info_shortage_pending': True,
            'urgent_recheck_needed': True,
            'info_shortage_reasons': ev.get('info_shortage_reasons'),
            'info_shortage_need': ev.get('info_shortage_need'),
            'recheck_reason': 'S1정보부족재확인',
        })
        ev['entry_context'] = ctx
    ev = _v370_apply_main_version(ev)
    ev['worker_patch'] = 'v378_canonical_s123_promotion'
    return ev



# =============================================================================
# strategy_worker v0.25 / v379: S1/S2/S3 생애주기 상태머신 본선
# - S1/S2/S3는 점수 등급이 아니라 후보 흐름이다.
# - S3 관찰포착 -> S2 재확인 -> S1 최종진입 순서로만 승격한다.
# - S2/S3는 승패 대상이 아니며 승격률/놓친상승률/정보보강 상태만 추적한다.
# - 기존 전략 조건/청산/자동매수는 변경하지 않는다.
# =============================================================================
VERSION = "strategy_worker_v0.40"
LIFECYCLE = BASE_DIR / "clean_strategy_s123_lifecycle.json"
_v379_base_run_once = run_once

_STAGE_RANK = {"S3": 1, "S2": 2, "S1": 3}
_STAGE_LABEL = {"S1": "✅ S1 최종진입", "S2": "⚠️ S2 재확인", "S3": "❔ S3 관찰포착"}

def _v379_stage_norm(v: Any) -> str:
    g = str(v or "").upper().strip()
    if g == "S":
        return "S1"
    if g in {"S1", "S2", "S3"}:
        return g
    return "S3"

def _v379_life_key(ev: Dict[str, Any]) -> str:
    t = ticker_norm(ev.get("ticker") or ev.get("market") or ev.get("symbol")) or "UNKNOWN"
    # S3/S2/S1은 같은 코인의 생애주기이므로 전략별로 쪼개지 않는다.
    # 대표 전략은 별도 필드로만 보존한다.
    return t

def _v379_price(ev: Dict[str, Any]) -> float:
    ctx = ev.get("entry_context") if isinstance(ev.get("entry_context"), dict) else {}
    snap = ev.get("entry_snapshot") if isinstance(ev.get("entry_snapshot"), dict) else {}
    flat = snap.get("flat") if isinstance(snap.get("flat"), dict) else {}
    return fnum(ev.get("current_price"), ev.get("entry_price"), ev.get("price"), ev.get("detected_price"), ctx.get("current_price"), ctx.get("entry_price"), flat.get("current_price"), flat.get("entry_price"), default=0.0)

def _v379_load_lifecycle() -> Dict[str, Any]:
    obj = load_json(LIFECYCLE, {}) or {}
    if not isinstance(obj, dict):
        obj = {}
    items = obj.get("items") if isinstance(obj.get("items"), dict) else {}
    return {"version": VERSION, "updated_ts": now_ts(), "items": dict(items)}

def _v379_save_lifecycle(life: Dict[str, Any], stats: Dict[str, Any]) -> None:
    nowv = now_ts()
    items = life.get("items") if isinstance(life.get("items"), dict) else {}
    # 2시간 이상 안 보인 후보는 순환 제거. 장부/체결 기록은 건드리지 않는다.
    keep = {}
    for k, v in items.items():
        if not isinstance(v, dict):
            continue
        last = fnum(v.get("last_seen_ts"), default=0.0)
        if last and nowv - last <= 7200:
            keep[k] = v
    out = {
        "version": VERSION,
        "schema": "s123_lifecycle_v379",
        "updated_ts": nowv,
        "updated_text": now_text(nowv),
        "items": keep,
        "stats": stats,
        "note": "S3/S2/S1은 점수 등급이 아니라 생애주기다. S2/S3 승패 대신 승격/정보보강/놓친상승을 본다.",
    }
    save_json(LIFECYCLE, out)

def _v379_signal_ready(ev: Dict[str, Any]) -> Tuple[bool, List[str]]:
    """S2 -> S1 승격 전에 필요한 판단값이 실제로 채워졌는지 본다.
    조건을 새로 풀지 않고, v378 canonical 값 존재 여부와 S1 판단 결과를 함께 확인한다.
    """
    ctx = ev.get("entry_context") if isinstance(ev.get("entry_context"), dict) else {}
    snap = ev.get("entry_snapshot") if isinstance(ev.get("entry_snapshot"), dict) else {}
    flat = snap.get("flat") if isinstance(snap.get("flat"), dict) else {}
    def val(*keys: str, default: float = -999.0) -> float:
        vals = []
        for src in (ev, ctx, flat):
            if isinstance(src, dict):
                vals += [src.get(k) for k in keys]
        return fnum(*vals, default=default)
    def known(*keys: str) -> bool:
        for src in (ev, ctx, flat):
            if not isinstance(src, dict):
                continue
            for k in keys:
                v = src.get(k)
                if v is not None and str(v).strip() not in {"", "-", "None", "nan"}:
                    return True
        return False
    miss: List[str] = []
    pr_known = known("price_reaction_score", "price_reaction_pct", "price_recheck_pct", "change_1m", "change_3m")
    br_known = known("buy_ratio_1m", "micro_buy_ratio_sustain_1m", "buy_ratio", "buy_ratio_30s")
    sl_known = known("slippage_est_pct", "tick_pct_est", "spread_pct")
    if not pr_known: miss.append("가격반응판단값없음")
    if not br_known: miss.append("체결지속판단값없음")
    if not sl_known: miss.append("슬리피지판단값없음")
    spread = val("spread_pct", "micro_spread_pct", default=99.0)
    buy = val("buy_ratio_1m", "micro_buy_ratio_sustain_1m", "buy_ratio", "buy_ratio_30s", default=0.0)
    ch1 = val("price_reaction_pct", "price_recheck_pct", "change_1m", "price_change_1m", default=0.0)
    ch3 = val("money_flow_3m_pct", "three_min_flow_pct", "change_3m", "price_change_3m", default=0.0)
    # 이 기준은 신규 전략 조건이 아니라 S1 진입 가능 신호가 계산됐는지/무너졌는지 보는 최소 검문소다.
    if spread > 0.28: miss.append("스프레드과다")
    if buy and buy < 0.58: miss.append("매수체결약함")
    if ch1 < -0.40 and ch3 < -0.40: miss.append("가격반응역행")
    return (not miss), miss[:8]

def _v379_apply_lifecycle_to_event(ev: Dict[str, Any], rec: Dict[str, Any], new_stage: str, reasons: List[str], nowv: float) -> Dict[str, Any]:
    out = dict(ev or {})
    old = str(rec.get("stage") or "")
    label = _STAGE_LABEL.get(new_stage, new_stage)
    life_age = max(0.0, nowv - fnum(rec.get("first_seen_ts"), default=nowv))
    recheck_count = int(fnum(rec.get("recheck_count"), default=0))
    out.update({
        "s_stage": new_stage,
        "candidate_grade": new_stage,
        "grade": new_stage,
        "entry_grade": new_stage,
        "signal_grade": new_stage,
        "candidate_grade_label": label,
        "paper_bot_open": new_stage == "S1",
        "open_eligible": new_stage == "S1",
        "trade_ready": new_stage == "S1",
        "observe_only": new_stage == "S3",
        "recheck_required": new_stage == "S2",
        "lifecycle_schema": "s123_lifecycle_v379",
        "lifecycle_stage": new_stage,
        "previous_lifecycle_stage": old or None,
        "lifecycle_age_sec": round(life_age, 2),
        "recheck_count": recheck_count,
        "first_seen_price": rec.get("first_seen_price"),
        "highest_after_seen": rec.get("highest_price"),
        "highest_after_seen_pct": rec.get("highest_pct"),
        "stage_transition": f"{old or 'NEW'}->{new_stage}",
        "promote_reason": reasons[:8],
        "s_stage_reasons": reasons[:8] or list(out.get("s_stage_reasons") if isinstance(out.get("s_stage_reasons"), list) else [])[:8],
        "final_entry_action": "paper_open" if new_stage == "S1" else ("recheck_wait" if new_stage == "S2" else "observe"),
        "summary_reason": ",".join((reasons or [label])[:5]),
        "worker_patch": "v379_s123_lifecycle_state_machine",
    })
    ctx = out.get("entry_context") if isinstance(out.get("entry_context"), dict) else {}
    ctx.update({k: out.get(k) for k in ("lifecycle_schema", "lifecycle_stage", "previous_lifecycle_stage", "lifecycle_age_sec", "recheck_count", "first_seen_price", "highest_after_seen", "highest_after_seen_pct", "stage_transition", "promote_reason", "s_stage", "candidate_grade", "paper_bot_open", "open_eligible", "trade_ready")})
    out["entry_context"] = ctx
    snap = out.get("entry_snapshot") if isinstance(out.get("entry_snapshot"), dict) else None
    if snap is not None:
        strat = snap.get("strategy") if isinstance(snap.get("strategy"), dict) else {}
        strat.update({"decision_stage": new_stage, "decision_note": label, "lifecycle_stage": new_stage, "stage_transition": out.get("stage_transition"), "promote_reason": reasons[:8]})
        snap["strategy"] = strat
        flat = snap.get("flat") if isinstance(snap.get("flat"), dict) else {}
        flat.update({"s_stage": new_stage, "candidate_grade": new_stage, "lifecycle_stage": new_stage, "stage_transition": out.get("stage_transition")})
        snap["flat"] = flat
        out["entry_snapshot"] = snap
    return out

def _v379_finalize_lifecycle(base_result: Dict[str, Any]) -> Dict[str, Any]:
    nowv = now_ts()
    rows = [r for r in read_jsonl(PAPER_LATEST, max_lines=160) if isinstance(r, dict)]
    life = _v379_load_lifecycle()
    items = life.get("items") if isinstance(life.get("items"), dict) else {}
    revised: List[Dict[str, Any]] = []
    transitions = {"new_s3": 0, "s3_to_s2": 0, "s2_to_s1": 0, "s2_hold": 0, "s3_hold": 0, "demoted_or_reset": 0, "blocked_s1_signal": 0}
    stage_counts = {"S1": 0, "S2": 0, "S3": 0}
    for ev in rows:
        key = _v379_life_key(ev)
        obs = _v379_stage_norm(ev.get("s_stage") or ev.get("candidate_grade") or ev.get("grade"))
        price = _v379_price(ev)
        rec = items.get(key) if isinstance(items.get(key), dict) else {}
        if not rec:
            rec = {"ticker": key, "first_seen_ts": nowv, "first_seen_text": now_text(nowv), "first_seen_price": price, "stage": "S3", "recheck_count": 0, "highest_price": price, "highest_pct": 0.0, "strategy_keys": []}
            new_stage = "S3"
            reasons = ["S3관찰포착", f"관측단계:{obs}"]
            transitions["new_s3"] += 1
        else:
            old_stage = _v379_stage_norm(rec.get("stage"))
            first_price = fnum(rec.get("first_seen_price"), default=price)
            high = max(fnum(rec.get("highest_price"), default=0.0), price)
            rec["highest_price"] = high
            rec["highest_pct"] = round(((high - first_price) / first_price * 100.0), 3) if first_price else 0.0
            # 새 관측값이 S1이라도 생애주기는 S3->S2->S1 순서로만 올린다.
            if old_stage == "S3":
                if _STAGE_RANK.get(obs, 1) >= 2:
                    new_stage = "S2"; transitions["s3_to_s2"] += 1
                    reasons = ["S3→S2승격", f"관측단계:{obs}"]
                else:
                    new_stage = "S3"; transitions["s3_hold"] += 1
                    reasons = ["S3관찰유지", f"관측단계:{obs}"]
            elif old_stage == "S2":
                signal_ok, signal_miss = _v379_signal_ready(ev)
                if obs == "S1" and signal_ok:
                    new_stage = "S1"; transitions["s2_to_s1"] += 1
                    reasons = ["S2→S1승격", "최종진입판단값확인"]
                elif obs == "S1" and not signal_ok:
                    new_stage = "S2"; transitions["blocked_s1_signal"] += 1
                    reasons = ["S1승격보류"] + signal_miss
                elif obs == "S2":
                    new_stage = "S2"; transitions["s2_hold"] += 1
                    reasons = ["S2재확인유지"]
                else:
                    new_stage = "S3"; transitions["demoted_or_reset"] += 1
                    reasons = ["S2→S3강등", f"관측단계:{obs}"]
            else:  # old S1은 paper가 읽을 수 있게 한 사이클 유지하되, 다음 관측이 내려가면 강등
                if obs == "S1":
                    new_stage = "S1"; reasons = ["S1진입유지"]
                elif obs == "S2":
                    new_stage = "S2"; transitions["demoted_or_reset"] += 1; reasons = ["S1→S2강등"]
                else:
                    new_stage = "S3"; transitions["demoted_or_reset"] += 1; reasons = ["S1→S3강등"]
        rec["stage"] = new_stage
        rec["last_observed_stage"] = obs
        rec["last_seen_ts"] = nowv
        rec["last_seen_text"] = now_text(nowv)
        rec["last_price"] = price
        if not fnum(rec.get("first_seen_price"), default=0.0) and price:
            rec["first_seen_price"] = price
        first_price = fnum(rec.get("first_seen_price"), default=price)
        rec["highest_price"] = max(fnum(rec.get("highest_price"), default=0.0), price)
        rec["highest_pct"] = round(((fnum(rec.get("highest_price"), default=0.0) - first_price) / first_price * 100.0), 3) if first_price else 0.0
        rec["recheck_count"] = int(fnum(rec.get("recheck_count"), default=0)) + (1 if new_stage == "S2" else 0)
        sk = str(ev.get("strategy_key") or ev.get("strategy_bucket_primary") or "")
        if sk:
            keys = list(rec.get("strategy_keys") if isinstance(rec.get("strategy_keys"), list) else [])
            if sk not in keys:
                keys.append(sk)
            rec["strategy_keys"] = keys[:8]
        items[key] = rec
        stage_counts[new_stage] += 1
        revised.append(_v379_apply_lifecycle_to_event(ev, rec, new_stage, reasons, nowv))
    # 생애주기에서 S1/S2/S3 순서가 반영된 latest를 다시 쓴다.
    latest, appended = persist_paper_handoff(revised, evaluated=int((load_json(SUMMARY, {}) or {}).get("evaluated") or 0))
    stats = {"stage_counts": stage_counts, "transitions": transitions, "active_count": len(items), "latest_count": len(latest), "archive_appended": appended}
    _v379_save_lifecycle({"items": items}, stats)
    # strategy summary에도 생애주기 통계를 실어 main /score, /quality에서 볼 수 있게 한다.
    try:
        sm = load_json(SUMMARY, {}) or {}
        sm.update({
            "version": VERSION,
            "lifecycle_schema": "s123_lifecycle_v379",
            "lifecycle_stats": stats,
            "s_stage_counts": stage_counts,
            "paper_latest_count": len(latest),
            "s_count": len(latest),
            "note": "v0.25/v379: S1/S2/S3는 등급이 아니라 S3→S2→S1 생애주기. S2/S3는 승패가 아니라 승격/복기 지표다.",
        })
        save_json(SUMMARY, sm)
    except Exception as exc:
        append_error(ERROR, "v379_summary_update", exc)
    try:
        pr = load_json(PRIORITY_REQ, {}) or {}
        if isinstance(pr, dict):
            pr["version"] = VERSION
            pr["lifecycle_schema"] = "s123_lifecycle_v379"
            pr["lifecycle_stats"] = stats
            pr["note"] = "v379: target_router 요청은 생애주기 S2/S3 정보보강을 우선한다. S2/S3는 OPEN 승패 대상이 아니다."
            save_json(PRIORITY_REQ, pr)
    except Exception as exc:
        append_error(ERROR, "v379_priority_update", exc)
    try:
        write_status("running", evaluated=int((load_json(SUMMARY, {}) or {}).get("evaluated") or 0), s_count=len(latest), paper_latest_count=len(latest), s1_count=stage_counts.get("S1", 0), s2_count=stage_counts.get("S2", 0), s3_count=stage_counts.get("S3", 0), lifecycle_schema="s123_lifecycle_v379", lifecycle_active=len(items), lifecycle_transitions=transitions, last_sec=fnum((base_result or {}).get("last_sec"), default=0.0))
    except Exception:
        pass
    out = dict(base_result or {})
    out.update({"s_stage_counts": stage_counts, "lifecycle_stats": stats, "paper_latest": len(latest), "s": len(latest)})
    return out

def run_once() -> Dict[str, Any]:  # type: ignore[override]
    base = _v379_base_run_once()
    return _v379_finalize_lifecycle(base)


# =============================================================================
# strategy_worker v0.26 / v383: 생애주기 승격 로직 수술
# - S3에서 실제로 오른 후보(+0.7% 이상)는 단순 관찰에 묶지 않고 S2 재확인으로 올린다.
# - S2는 관측값이 S1로 직접 올라오지 않아도, 가격추적 상승 + canonical 판단값 통과 시 S1로 올린다.
# - S2/S3는 여전히 OPEN하지 않는다. S1만 paper OPEN 대상이다.
# - 조건을 풀어 무조건 매수하는 수정이 아니라, 추적값/판단값을 승격에 실제 반영하는 배관 수술이다.
# =============================================================================
VERSION = "strategy_worker_v0.40"
_v383_base_run_once = run_once


def _v383_ev_val(ev: Dict[str, Any], *keys: str, default: float = 0.0) -> float:
    ctx = ev.get("entry_context") if isinstance(ev.get("entry_context"), dict) else {}
    snap = ev.get("entry_snapshot") if isinstance(ev.get("entry_snapshot"), dict) else {}
    flat = snap.get("flat") if isinstance(snap.get("flat"), dict) else {}
    strat = snap.get("strategy") if isinstance(snap.get("strategy"), dict) else {}
    for src in (ev, ctx, flat, strat):
        if not isinstance(src, dict):
            continue
        for k in keys:
            v = src.get(k)
            if v is not None and str(v).strip() not in {"", "-", "None", "nan"}:
                return fnum(v, default=default)
    return default


def _v383_gain_now(ev: Dict[str, Any], rec: Dict[str, Any]) -> float:
    price = _v379_price(ev)
    first = fnum(rec.get("first_seen_price"), default=0.0) or price
    if not first or not price:
        return 0.0
    return round((price - first) / first * 100.0, 3)


def _v383_promote_s3_to_s2(ev: Dict[str, Any], rec: Dict[str, Any], obs: str) -> Tuple[bool, List[str]]:
    """관찰 후보가 실제로 움직였으면 재확인 단계로 올린다.
    S2는 매수 단계가 아니라 재확인/정보보강 단계라서, +0.7% 이상 놓친 상승 후보는 S2로 올리는 게 맞다.
    """
    if _STAGE_RANK.get(obs, 1) >= 2:
        return True, ["S3→S2승격", f"관측단계:{obs}"]
    hp = fnum(rec.get("highest_pct"), default=0.0)
    gn = _v383_gain_now(ev, rec)
    flow5 = _v383_ev_val(ev, "change_5m", "five_min_flow_pct", "price_change_5m", default=0.0)
    flow3 = _v383_ev_val(ev, "money_flow_3m_pct", "three_min_flow_pct", "change_3m", "price_change_3m", default=0.0)
    spread = _v383_ev_val(ev, "spread_pct", "micro_spread_pct", default=0.0)
    # 관찰 후 이미 오른 후보는 S2에서 재확인해야 한다. 스프레드가 매우 넓으면 관찰 유지.
    if hp >= 0.70 and (spread <= 0 or spread <= 0.45):
        return True, ["S3→S2승격:관찰후상승", f"최고+{hp:.2f}%", f"현재+{gn:.2f}%"]
    # 아직 +0.7% 전이라도 5분 흐름이 강하면 S2로 올려 재확인한다.
    if gn >= 0.35 and (flow5 >= 0.50 or flow3 >= 0.25) and (spread <= 0 or spread <= 0.35):
        return True, ["S3→S2승격:흐름재확인", f"현재+{gn:.2f}%", f"5m{flow5:+.2f}", f"3m{flow3:+.2f}"]
    return False, []


def _v383_promote_s2_to_s1(ev: Dict[str, Any], rec: Dict[str, Any], obs: str) -> Tuple[bool, List[str], List[str]]:
    signal_ok, miss = _v379_signal_ready(ev)
    hp = fnum(rec.get("highest_pct"), default=0.0)
    gn = _v383_gain_now(ev, rec)
    pr = _v383_ev_val(ev, "price_reaction_pct", "price_recheck_pct", "change_1m", "price_change_1m", default=0.0)
    buy = _v383_ev_val(ev, "buy_ratio_1m", "micro_buy_ratio_sustain_1m", "buy_ratio", "buy_ratio_30s", default=0.0)
    spread = _v383_ev_val(ev, "spread_pct", "micro_spread_pct", default=0.0)
    # 기존 obs S1은 그대로 존중하되 canonical 안전값이 있어야 실제 S1로 올린다.
    if obs == "S1" and signal_ok:
        return True, ["S2→S1승격", "관측S1+최종판단값확인"], []
    # S2가 이미 관찰 후 충분히 움직이고, 가격반응/체결/스프레드가 통과하면 S1로 올린다.
    strong_follow = (hp >= 0.70 and gn >= 0.10 and pr >= -0.10 and (not buy or buy >= 0.58) and (not spread or spread <= 0.28))
    if signal_ok and strong_follow:
        return True, ["S2→S1승격:재확인통과", f"최고+{hp:.2f}%", f"현재+{gn:.2f}%", f"가격반응{pr:+.2f}", f"매수비율{buy:.2f}"], []
    fail = list(miss or [])
    if not signal_ok:
        return False, [], fail[:8]
    if not strong_follow:
        if hp < 0.70: fail.append("관찰상승부족")
        if gn < 0.10: fail.append("현재반응부족")
        if pr < -0.10: fail.append("가격반응약함")
        if buy and buy < 0.58: fail.append("매수체결약함")
        if spread and spread > 0.28: fail.append("스프레드과다")
    return False, [], fail[:8]


def _v383_finalize_lifecycle(base_result: Dict[str, Any]) -> Dict[str, Any]:
    nowv = now_ts()
    rows = [r for r in read_jsonl(PAPER_LATEST, max_lines=160) if isinstance(r, dict)]
    life = _v379_load_lifecycle()
    items = life.get("items") if isinstance(life.get("items"), dict) else {}
    revised: List[Dict[str, Any]] = []
    transitions = {"new_s3": 0, "s3_to_s2": 0, "s3_to_s2_by_rise": 0, "s2_to_s1": 0, "s2_hold": 0, "s3_hold": 0, "demoted_or_reset": 0, "blocked_s1_signal": 0}
    fail_reasons: Dict[str, int] = {}
    stage_counts = {"S1": 0, "S2": 0, "S3": 0}
    for ev in rows:
        key = _v379_life_key(ev)
        obs = _v379_stage_norm(ev.get("s_stage") or ev.get("candidate_grade") or ev.get("grade"))
        price = _v379_price(ev)
        rec = items.get(key) if isinstance(items.get(key), dict) else {}
        if not rec:
            rec = {"ticker": key, "first_seen_ts": nowv, "first_seen_text": now_text(nowv), "first_seen_price": price, "stage": "S3", "recheck_count": 0, "highest_price": price, "highest_pct": 0.0, "strategy_keys": []}
            new_stage = "S3"
            reasons = ["S3관찰포착", f"관측단계:{obs}"]
            transitions["new_s3"] += 1
        else:
            old_stage = _v379_stage_norm(rec.get("stage"))
            first_price = fnum(rec.get("first_seen_price"), default=price)
            high = max(fnum(rec.get("highest_price"), default=0.0), price)
            rec["highest_price"] = high
            rec["highest_pct"] = round(((high - first_price) / first_price * 100.0), 3) if first_price else 0.0
            if old_stage == "S3":
                promote, preasons = _v383_promote_s3_to_s2(ev, rec, obs)
                if promote:
                    new_stage = "S2"
                    transitions["s3_to_s2"] += 1
                    if any("관찰후상승" in str(x) for x in preasons):
                        transitions["s3_to_s2_by_rise"] += 1
                    reasons = preasons
                else:
                    new_stage = "S3"
                    transitions["s3_hold"] += 1
                    reasons = ["S3관찰유지", f"관측단계:{obs}"]
            elif old_stage == "S2":
                ok, preasons, fail = _v383_promote_s2_to_s1(ev, rec, obs)
                if ok:
                    new_stage = "S1"
                    transitions["s2_to_s1"] += 1
                    reasons = preasons
                else:
                    new_stage = "S2"
                    transitions["s2_hold"] += 1
                    transitions["blocked_s1_signal"] += 1
                    reasons = ["S2→S1보류"] + (fail or [f"관측단계:{obs}"])
                    for r in (fail or ["미상"]):
                        fail_reasons[str(r)] = fail_reasons.get(str(r), 0) + 1
            else:
                if obs == "S1":
                    new_stage = "S1"; reasons = ["S1진입유지"]
                elif obs == "S2":
                    new_stage = "S2"; transitions["demoted_or_reset"] += 1; reasons = ["S1→S2강등"]
                else:
                    new_stage = "S3"; transitions["demoted_or_reset"] += 1; reasons = ["S1→S3강등"]
        rec["stage"] = new_stage
        rec["last_observed_stage"] = obs
        rec["last_seen_ts"] = nowv
        rec["last_seen_text"] = now_text(nowv)
        rec["last_price"] = price
        if not fnum(rec.get("first_seen_price"), default=0.0) and price:
            rec["first_seen_price"] = price
        first_price = fnum(rec.get("first_seen_price"), default=price)
        rec["highest_price"] = max(fnum(rec.get("highest_price"), default=0.0), price)
        rec["highest_pct"] = round(((fnum(rec.get("highest_price"), default=0.0) - first_price) / first_price * 100.0), 3) if first_price else 0.0
        rec["last_gain_pct"] = _v383_gain_now(ev, rec)
        rec["last_promote_reasons"] = reasons[:8]
        rec["s2_to_s1_fail_reasons"] = reasons[1:8] if new_stage == "S2" and reasons and str(reasons[0]).startswith("S2") else []
        rec["recheck_count"] = int(fnum(rec.get("recheck_count"), default=0)) + (1 if new_stage == "S2" else 0)
        sk = str(ev.get("strategy_key") or ev.get("strategy_bucket_primary") or "")
        if sk:
            keys = list(rec.get("strategy_keys") if isinstance(rec.get("strategy_keys"), list) else [])
            if sk not in keys:
                keys.append(sk)
            rec["strategy_keys"] = keys[:8]
        items[key] = rec
        stage_counts[new_stage] += 1
        revised.append(_v379_apply_lifecycle_to_event(ev, rec, new_stage, reasons, nowv))
    latest, appended = persist_paper_handoff(revised, evaluated=int((load_json(SUMMARY, {}) or {}).get("evaluated") or 0))
    stats = {"schema": "s123_lifecycle_v383", "stage_counts": stage_counts, "transitions": transitions, "s2_to_s1_fail_reasons": fail_reasons, "active_count": len(items), "latest_count": len(latest), "archive_appended": appended}
    _v379_save_lifecycle({"items": items}, stats)
    try:
        sm = load_json(SUMMARY, {}) or {}
        sm.update({"version": VERSION, "lifecycle_schema": "s123_lifecycle_v383", "lifecycle_stats": stats, "s_stage_counts": stage_counts, "paper_latest_count": len(latest), "s_count": len(latest), "note": "v0.26/v383: S3 상승후보를 S2 재확인으로 올리고, S2 최종판단값 통과 시 S1로 승격한다."})
        save_json(SUMMARY, sm)
    except Exception as exc:
        append_error(ERROR, "v383_summary_update", exc)
    try:
        pr = load_json(PRIORITY_REQ, {}) or {}
        if isinstance(pr, dict):
            pr["version"] = VERSION
            pr["lifecycle_schema"] = "s123_lifecycle_v383"
            pr["lifecycle_stats"] = stats
            pr["note"] = "v383: S3/S2 승격 실패 원인을 target_router·상태판에 전달한다."
            save_json(PRIORITY_REQ, pr)
    except Exception as exc:
        append_error(ERROR, "v383_priority_update", exc)
    try:
        write_status("running", evaluated=int((load_json(SUMMARY, {}) or {}).get("evaluated") or 0), s_count=len(latest), paper_latest_count=len(latest), s1_count=stage_counts.get("S1", 0), s2_count=stage_counts.get("S2", 0), s3_count=stage_counts.get("S3", 0), lifecycle_schema="s123_lifecycle_v383", lifecycle_active=len(items), lifecycle_transitions=transitions, s2_to_s1_fail_reasons=fail_reasons, last_sec=fnum((base_result or {}).get("last_sec"), default=0.0))
    except Exception:
        pass
    out = dict(base_result or {})
    out.update({"s_stage_counts": stage_counts, "lifecycle_stats": stats, "paper_latest": len(latest), "s": len(latest)})
    return out


def run_once() -> Dict[str, Any]:  # type: ignore[override]
    base = _v383_base_run_once()
    return _v383_finalize_lifecycle(base)


# v385: early main disabled. Final __main__ is at file end after all lifecycle tails load.
# if __name__=="__main__": main()


# =============================================================================
# v384 / 2026-05-23
# - S2/S3가 못 올라간 이유를 단계별로 남긴다.
# - 정보부족은 "정보부족"으로만 끝내지 않고, 왜 없는지(root cause)를 나눈다.
# - 전략 조건/청산/자동매수는 변경하지 않고 생애주기 진단과 승격 실패 원인만 정밀화한다.
# =============================================================================
VERSION = "strategy_worker_v0.40"

def _v384_ev_sources(ev: Dict[str, Any]) -> List[Dict[str, Any]]:
    srcs: List[Dict[str, Any]] = []
    for obj in (ev, ev.get("entry_context"), ev.get("entry_snapshot")):
        if isinstance(obj, dict):
            srcs.append(obj)
            for k in ("flat", "strategy", "orderflow", "feature"):
                v = obj.get(k)
                if isinstance(v, dict):
                    srcs.append(v)
    return srcs

def _v384_known(ev: Dict[str, Any], *keys: str) -> bool:
    for src in _v384_ev_sources(ev):
        for k in keys:
            v = src.get(k)
            if v is not None and str(v).strip() not in {"", "-", "None", "nan", "NaN"}:
                return True
    return False

def _v384_bool(ev: Dict[str, Any], *keys: str) -> bool:
    for src in _v384_ev_sources(ev):
        for k in keys:
            v = src.get(k)
            if isinstance(v, bool):
                return v
            if str(v).strip().lower() in {"1", "true", "yes", "ok", "fresh", "신선"}:
                return True
    return False

def _v384_val(ev: Dict[str, Any], *keys: str, default: float = 0.0) -> float:
    vals: List[Any] = []
    for src in _v384_ev_sources(ev):
        vals.extend(src.get(k) for k in keys)
    return fnum(*vals, default=default)

def _v384_info_root_causes(ev: Dict[str, Any]) -> List[str]:
    """S1/S2/S3 판단값이 없을 때 원천 원인을 분리한다.
    - 수집 미신선: WS/micro/candle 자체가 안 들어옴
    - 판단값 미생성: 수집은 신선한데 feature/orderflow canonical key가 안 붙음
    """
    quote_fresh = _v384_bool(ev, "quote_fresh", "ws_fresh", "rest_fresh")
    micro_fresh = _v384_bool(ev, "micro_fresh")
    candle_ready = _v384_bool(ev, "candle_ready", "candle_ok") or _v384_known(ev, "change_3m", "change_5m")
    causes: List[str] = []
    if not _v384_known(ev, "price_reaction_score", "price_reaction_pct", "price_recheck_pct", "change_1m", "price_change_1m"):
        causes.append("가격반응:시세미신선" if not quote_fresh else "가격반응:판단값미생성")
    if not _v384_known(ev, "money_flow_3m_pct", "three_min_flow_pct", "change_3m", "price_change_3m"):
        causes.append("3분흐름:candle미신선" if not candle_ready else "3분흐름:판단값미생성")
    if not _v384_known(ev, "buy_ratio_1m", "micro_buy_ratio_sustain_1m", "buy_ratio", "buy_ratio_30s"):
        causes.append("체결지속:micro미신선" if not micro_fresh else "체결지속:판단값미생성")
    if not _v384_known(ev, "slippage_est_pct", "tick_pct_est", "spread_pct", "micro_spread_pct"):
        causes.append("슬리피지:micro미신선" if not micro_fresh else "슬리피지:판단값미생성")
    if not _v384_known(ev, "ask_wall_ratio", "sell_wall_ratio", "ask_size_ratio"):
        causes.append("매도벽:micro미신선" if not micro_fresh else "매도벽:판단값미생성")
    return list(dict.fromkeys(causes))[:10]

def _v384_s3_fail_reasons(ev: Dict[str, Any], rec: Dict[str, Any], obs: str) -> List[str]:
    hp = fnum(rec.get("highest_pct"), default=0.0)
    gn = _v383_gain_now(ev, rec)
    flow5 = _v384_val(ev, "change_5m", "five_min_flow_pct", "price_change_5m", default=0.0)
    flow3 = _v384_val(ev, "money_flow_3m_pct", "three_min_flow_pct", "change_3m", "price_change_3m", default=0.0)
    spread = _v384_val(ev, "spread_pct", "micro_spread_pct", default=0.0)
    reasons: List[str] = []
    info = _v384_info_root_causes(ev)
    if info:
        reasons += ["정보부족:" + x for x in info[:5]]
    if hp < 0.70 and gn < 0.35:
        reasons.append(f"상승반응부족:최고{hp:+.2f}/현재{gn:+.2f}")
    if flow5 < 0.50 and flow3 < 0.25:
        reasons.append(f"흐름재확인부족:5m{flow5:+.2f}/3m{flow3:+.2f}")
    if spread and spread > 0.45:
        reasons.append(f"스프레드과다:{spread:.2f}%")
    if not reasons:
        reasons.append(f"관측단계유지:{obs or 'S3'}")
    return reasons[:8]

def _v384_promote_s3_to_s2(ev: Dict[str, Any], rec: Dict[str, Any], obs: str) -> Tuple[bool, List[str], List[str]]:
    promote, reasons = _v383_promote_s3_to_s2(ev, rec, obs)
    if promote:
        return True, reasons, []
    return False, [], _v384_s3_fail_reasons(ev, rec, obs)

def _v384_s2_fail_detail(ev: Dict[str, Any], rec: Dict[str, Any], fail: List[str]) -> Dict[str, Any]:
    return {
        "ticker": _v379_life_key(ev),
        "score": _v384_val(ev, "score", "trade_ready", default=0.0),
        "highest_pct": round(fnum(rec.get("highest_pct"), default=0.0), 3),
        "gain_now_pct": _v383_gain_now(ev, rec),
        "price_reaction_pct": _v384_val(ev, "price_reaction_pct", "price_recheck_pct", "change_1m", default=0.0),
        "buy_ratio": _v384_val(ev, "buy_ratio_1m", "micro_buy_ratio_sustain_1m", "buy_ratio", default=0.0),
        "spread_pct": _v384_val(ev, "spread_pct", "micro_spread_pct", default=0.0),
        "fail_reasons": list(fail or [])[:8],
        "info_root_causes": _v384_info_root_causes(ev),
    }

def _v384_finalize_lifecycle(base_result: Dict[str, Any]) -> Dict[str, Any]:
    nowv = now_ts()
    rows = [r for r in read_jsonl(PAPER_LATEST, max_lines=160) if isinstance(r, dict)]
    life = _v379_load_lifecycle()
    items = life.get("items") if isinstance(life.get("items"), dict) else {}
    revised: List[Dict[str, Any]] = []
    transitions = {"new_s3": 0, "s3_to_s2": 0, "s3_to_s2_by_rise": 0, "s2_to_s1": 0, "s2_hold": 0, "s3_hold": 0, "demoted_or_reset": 0, "blocked_s1_signal": 0}
    fail_reasons: Dict[str, int] = {}
    s3_fail_reasons: Dict[str, int] = {}
    info_root_causes: Dict[str, int] = {}
    s2_fail_samples: List[Dict[str, Any]] = []
    s3_fail_samples: List[Dict[str, Any]] = []
    stage_counts = {"S1": 0, "S2": 0, "S3": 0}
    for ev in rows:
        key = _v379_life_key(ev)
        obs = _v379_stage_norm(ev.get("s_stage") or ev.get("candidate_grade") or ev.get("grade"))
        price = _v379_price(ev)
        rec = items.get(key) if isinstance(items.get(key), dict) else {}
        if not rec:
            rec = {"ticker": key, "first_seen_ts": nowv, "first_seen_text": now_text(nowv), "first_seen_price": price, "stage": "S3", "recheck_count": 0, "highest_price": price, "highest_pct": 0.0, "strategy_keys": []}
            new_stage = "S3"
            reasons = ["S3관찰포착", f"관측단계:{obs}"]
            transitions["new_s3"] += 1
        else:
            old_stage = _v379_stage_norm(rec.get("stage"))
            first_price = fnum(rec.get("first_seen_price"), default=price)
            high = max(fnum(rec.get("highest_price"), default=0.0), price)
            rec["highest_price"] = high
            rec["highest_pct"] = round(((high - first_price) / first_price * 100.0), 3) if first_price else 0.0
            if old_stage == "S3":
                promote, preasons, fail = _v384_promote_s3_to_s2(ev, rec, obs)
                if promote:
                    new_stage = "S2"
                    transitions["s3_to_s2"] += 1
                    if any("관찰후상승" in str(x) for x in preasons):
                        transitions["s3_to_s2_by_rise"] += 1
                    reasons = preasons
                else:
                    new_stage = "S3"
                    transitions["s3_hold"] += 1
                    reasons = ["S3관찰유지", f"관측단계:{obs}"] + fail[:6]
                    for r in fail or ["미상"]:
                        s3_fail_reasons[str(r)] = s3_fail_reasons.get(str(r), 0) + 1
                        if str(r).startswith("정보부족:"):
                            k = str(r).replace("정보부족:", "", 1)
                            info_root_causes[k] = info_root_causes.get(k, 0) + 1
                    if len(s3_fail_samples) < 8:
                        s3_fail_samples.append(_v384_s2_fail_detail(ev, rec, fail))
            elif old_stage == "S2":
                ok, preasons, fail = _v383_promote_s2_to_s1(ev, rec, obs)
                if ok:
                    new_stage = "S1"
                    transitions["s2_to_s1"] += 1
                    reasons = preasons
                else:
                    new_stage = "S2"
                    transitions["s2_hold"] += 1
                    transitions["blocked_s1_signal"] += 1
                    root = _v384_info_root_causes(ev)
                    reasons = ["S2→S1보류"] + (fail or [f"관측단계:{obs}"]) + (["정보원인:" + x for x in root[:4]] if root else [])
                    for r in (fail or ["미상"]):
                        fail_reasons[str(r)] = fail_reasons.get(str(r), 0) + 1
                    for r in root:
                        info_root_causes[str(r)] = info_root_causes.get(str(r), 0) + 1
                    if len(s2_fail_samples) < 8:
                        s2_fail_samples.append(_v384_s2_fail_detail(ev, rec, fail))
            else:
                if obs == "S1":
                    new_stage = "S1"; reasons = ["S1진입유지"]
                elif obs == "S2":
                    new_stage = "S2"; transitions["demoted_or_reset"] += 1; reasons = ["S1→S2강등"]
                else:
                    new_stage = "S3"; transitions["demoted_or_reset"] += 1; reasons = ["S1→S3강등"]
        rec["stage"] = new_stage
        rec["last_observed_stage"] = obs
        rec["last_seen_ts"] = nowv
        rec["last_seen_text"] = now_text(nowv)
        rec["last_price"] = price
        if not fnum(rec.get("first_seen_price"), default=0.0) and price:
            rec["first_seen_price"] = price
        first_price = fnum(rec.get("first_seen_price"), default=price)
        rec["highest_price"] = max(fnum(rec.get("highest_price"), default=0.0), price)
        rec["highest_pct"] = round(((fnum(rec.get("highest_price"), default=0.0) - first_price) / first_price * 100.0), 3) if first_price else 0.0
        rec["last_gain_pct"] = _v383_gain_now(ev, rec)
        rec["last_promote_reasons"] = reasons[:10]
        rec["last_info_root_causes"] = _v384_info_root_causes(ev)
        if new_stage == "S3" and reasons and str(reasons[0]).startswith("S3"):
            rec["s3_to_s2_fail_reasons"] = reasons[2:10]
        if new_stage == "S2" and reasons and str(reasons[0]).startswith("S2"):
            rec["s2_to_s1_fail_reasons"] = reasons[1:10]
        rec["recheck_count"] = int(fnum(rec.get("recheck_count"), default=0)) + (1 if new_stage == "S2" else 0)
        sk = str(ev.get("strategy_key") or ev.get("strategy_bucket_primary") or "")
        if sk:
            keys = list(rec.get("strategy_keys") if isinstance(rec.get("strategy_keys"), list) else [])
            if sk not in keys:
                keys.append(sk)
            rec["strategy_keys"] = keys[:8]
        items[key] = rec
        stage_counts[new_stage] += 1
        revised.append(_v379_apply_lifecycle_to_event(ev, rec, new_stage, reasons, nowv))
    latest, appended = persist_paper_handoff(revised, evaluated=int((load_json(SUMMARY, {}) or {}).get("evaluated") or 0))
    stats = {
        "schema": "s123_lifecycle_v384",
        "stage_counts": stage_counts,
        "transitions": transitions,
        "s2_to_s1_fail_reasons": fail_reasons,
        "s3_to_s2_fail_reasons": s3_fail_reasons,
        "info_missing_root_causes": info_root_causes,
        "s2_to_s1_fail_samples": s2_fail_samples,
        "s3_to_s2_fail_samples": s3_fail_samples,
        "active_count": len(items),
        "latest_count": len(latest),
        "archive_appended": appended,
        "note": "v384: S2/S3가 못 올라간 이유와 정보부족 원천 원인을 단계별로 남긴다.",
    }
    _v379_save_lifecycle({"items": items}, stats)
    try:
        sm = load_json(SUMMARY, {}) or {}
        sm.update({"version": VERSION, "lifecycle_schema": "s123_lifecycle_v384", "lifecycle_stats": stats, "s_stage_counts": stage_counts, "paper_latest_count": len(latest), "s_count": len(latest), "note": "v0.27/v384: S3→S2, S2→S1 미승격 이유와 정보부족 root cause를 분리한다."})
        save_json(SUMMARY, sm)
    except Exception as exc:
        append_error(ERROR, "v384_summary_update", exc)
    try:
        write_status("running", evaluated=int((load_json(SUMMARY, {}) or {}).get("evaluated") or 0), s_count=len(latest), paper_latest_count=len(latest), s1_count=stage_counts.get("S1", 0), s2_count=stage_counts.get("S2", 0), s3_count=stage_counts.get("S3", 0), lifecycle_schema="s123_lifecycle_v384", lifecycle_active=len(items), lifecycle_transitions=transitions, s2_to_s1_fail_reasons=fail_reasons, s3_to_s2_fail_reasons=s3_fail_reasons, info_missing_root_causes=info_root_causes, last_sec=fnum((base_result or {}).get("last_sec"), default=0.0))
    except Exception:
        pass
    out = dict(base_result or {})
    out.update({"s_stage_counts": stage_counts, "lifecycle_stats": stats, "paper_latest": len(latest), "s": len(latest)})
    return out

def run_once() -> Dict[str, Any]:  # type: ignore[override]
    base = _v383_base_run_once()
    return _v384_finalize_lifecycle(base)


# =============================================================================
# strategy_worker v0.28 / v385: final main order fix
# - v384 code existed after an earlier if __main__: main(), so runtime started before v384 loaded.
# - Do not add another strategy condition. Ensure final loaded run_once(v384) is the one executed.
# - Paper/open problems must be diagnosed after this runtime-order fix.
# =============================================================================
VERSION = "strategy_worker_v0.40"
_v385_base_run_once = run_once

def run_once() -> Dict[str, Any]:  # type: ignore[override]
    return _v385_base_run_once()



# =============================================================================
# strategy_worker v0.29 / v386: S1 lifecycle -> paper handoff single factory seal
# - Root cause: lifecycle summary could report S1, but paper handoff merge could still expose
#   the older S2/S3 row, so paper saw S1 handoff 입구 0.
# - This is not a condition change. It seals the factory output: a lifecycle S1 row must carry
#   paper_bot_open/open_eligible/trade_ready/open_source and remain S1 in latest handoff.
# =============================================================================
VERSION = "strategy_worker_v0.40"
_v386_base_run_once = run_once

def _v386_stage_of(row: Dict[str, Any]) -> str:
    srcs: List[Dict[str, Any]] = []
    if isinstance(row, dict):
        srcs.append(row)
        for k in ("entry_context", "entry_snapshot"):
            v = row.get(k)
            if isinstance(v, dict):
                srcs.append(v)
                for kk in ("flat", "strategy", "orderflow", "feature"):
                    vv = v.get(kk)
                    if isinstance(vv, dict):
                        srcs.append(vv)
    for src in srcs:
        g = str(src.get("lifecycle_stage") or src.get("s_stage") or src.get("candidate_stage") or src.get("candidate_grade") or src.get("grade") or "").upper().strip()
        if g == "S":
            return "S1"
        if g in {"S1", "S2", "S3"}:
            return g
    return "S3"

def _v386_force_stage_fields(row: Dict[str, Any], stage: str) -> Dict[str, Any]:
    out = dict(row or {})
    stage = stage if stage in {"S1", "S2", "S3"} else "S3"
    out.update({
        "s_stage": stage,
        "candidate_grade": stage,
        "grade": stage,
        "entry_grade": stage,
        "signal_grade": stage,
        "lifecycle_stage": stage,
        "candidate_grade_label": _STAGE_LABEL.get(stage, stage) if '_STAGE_LABEL' in globals() else stage,
        "paper_bot_open": stage == "S1",
        "open_eligible": stage == "S1",
        "trade_ready": stage == "S1",
        "recheck_required": stage == "S2",
        "observe_only": stage == "S3",
    })
    if stage == "S1":
        out["open_source"] = "s1_lifecycle"
        out["paper_handoff_ready"] = True
        out["final_entry_action"] = "paper_open"
    ctx = out.get("entry_context") if isinstance(out.get("entry_context"), dict) else {}
    ctx.update({
        "s_stage": stage,
        "candidate_grade": stage,
        "grade": stage,
        "lifecycle_stage": stage,
        "paper_bot_open": stage == "S1",
        "open_eligible": stage == "S1",
        "trade_ready": stage == "S1",
    })
    if stage == "S1":
        ctx["open_source"] = "s1_lifecycle"
        ctx["paper_handoff_ready"] = True
    out["entry_context"] = ctx
    snap = out.get("entry_snapshot") if isinstance(out.get("entry_snapshot"), dict) else None
    if isinstance(snap, dict):
        flat = snap.get("flat") if isinstance(snap.get("flat"), dict) else {}
        flat.update({"s_stage": stage, "candidate_grade": stage, "grade": stage, "lifecycle_stage": stage})
        snap["flat"] = flat
        strat = snap.get("strategy") if isinstance(snap.get("strategy"), dict) else {}
        strat.update({"decision_stage": stage, "lifecycle_stage": stage, "paper_bot_open": stage == "S1"})
        snap["strategy"] = strat
        out["entry_snapshot"] = snap
    return out

def _v386_rewrite_latest_stage_priority() -> Dict[str, Any]:
    rows = [r for r in read_jsonl(PAPER_LATEST, max_lines=240) if isinstance(r, dict)]
    fixed: List[Dict[str, Any]] = []
    counts = {"S1": 0, "S2": 0, "S3": 0}
    for r in rows:
        st = _v386_stage_of(r)
        counts[st] = counts.get(st, 0) + 1
        fixed.append(_v386_force_stage_fields(r, st))
    # keep S1 first so paper's merge/picker cannot lose it behind an older S3 row
    fixed.sort(key=lambda x: ({"S1": 3, "S2": 2, "S3": 1}.get(_v386_stage_of(x), 0), fnum(x.get("updated_ts"), x.get("created_at"), default=0.0), fnum(x.get("score"), default=0.0)), reverse=True)
    if fixed:
        write_jsonl_atomic(PAPER_LATEST, fixed)
    try:
        h = load_json(HANDOFF, {}) or {}
        h.update({
            "version": VERSION,
            "v386_factory_sealed": True,
            "v386_latest_stage_counts": counts,
            "s1_count": counts.get("S1", 0),
            "s2_count": counts.get("S2", 0),
            "s3_count": counts.get("S3", 0),
            "note": "v386: lifecycle S1 rows are forced into paper handoff with open_eligible/trade_ready before paper reads them.",
        })
        save_json(HANDOFF, h)
    except Exception as exc:
        append_error(ERROR, "v386_handoff_status", exc)
    return counts

def run_once() -> Dict[str, Any]:  # type: ignore[override]
    out = _v386_base_run_once()
    try:
        counts = _v386_rewrite_latest_stage_priority()
        try:
            write_status("running", evaluated=int((load_json(SUMMARY, {}) or {}).get("evaluated") or 0), s_count=sum(counts.values()), paper_latest_count=sum(counts.values()), s1_count=counts.get("S1",0), s2_count=counts.get("S2",0), s3_count=counts.get("S3",0), lifecycle_schema="s123_lifecycle_v386_factory_sealed", v386_factory_sealed=True, last_sec=fnum((out or {}).get("last_sec"), default=0.0))
        except Exception:
            pass
        if isinstance(out, dict):
            out["s_stage_counts"] = counts
            out["v386_factory_sealed"] = True
    except Exception as exc:
        append_error(ERROR, "v386_factory_seal", exc)
    return out


# =============================================================================
# strategy_worker v0.30 / v403: 전략별 S3/S2/S1 단일 본선 + 조건지도
# - 기존 독립 lifecycle S3→S2→S1 가격추적 승격판을 최종 OPEN 경로에서 격리한다.
# - 각 전략의 core/S2/S1 조건과 공통 안전문을 한 번에 적용한다.
# - S2/S3는 계속 관찰/재확인으로 남기지만, paper OPEN은 전략별 S1 + 공통 S1 안전문만 허용한다.
# =============================================================================
VERSION = "strategy_worker_v0.40"

V403_CONDITION_MAP = {
    "version": VERSION,
    "main_version": MAIN_VERSION if 'MAIN_VERSION' in globals() else MAIN_DEPLOY_VERSION,
    "schema": "strategy_stage_unified_v403",
    "summary": "전략 조건과 S3/S2/S1 단계를 하나로 합침. 독립 lifecycle 가격추적 S2→S1 승격은 최종 OPEN 경로에서 격리.",
    "common_hard_blocks": [
        "최근 반복손실/하드손실", "이미 OPEN 중", "거래대금 2.5억 미만", "윗꼬리/고점끝물 위험",
        "micro fresh 시 스프레드 과다", "micro fresh 시 매수체결 부족", "매도벽/매도체결압력"
    ],
    "common_s1_safety": [
        "micro fresh + WS/quote fresh", "매수체결비 >= 0.70", "1분 체결지속 >= 0.64",
        "스프레드 <= 0.18%", "슬리피지 확인 <= 0.20%", "매도벽 확인 + 매도압력 없음",
        "가격반응 >= 0.05", "30초/1분/3분 중 단기반응", "VWAP >= -0.03", "EMA5 >= -0.05",
        "최근반복손실/고점무반응/과열 제외"
    ],
    "common_s2_recheck": [
        "micro fresh", "매수체결비 >= 0.62", "스프레드 <= 0.28%", "매도압력 없음",
        "VWAP >= -0.08", "EMA5 >= -0.12", "가격반응/단기흐름/거래량 중 재확인 재료"
    ],
    "stage_policy": [
        "S3=전략별 관찰/복기", "S2=전략별 재확인/정보보강", "S1=전략별 S1 추가조건 + 공통 S1 안전문 통과만 paper OPEN",
        "기존 lifecycle S3→S2→S1 가격추적 승격은 최신 handoff에서 재계산/격리"
    ],
    "strategies": {
        "money_reaccel_s": {"label":"돈흐름 재가속", "core":["3m>=0.25", "5m>=0.35", "VWAP>=-0.05", "EMA5>=-0.08", "volume_expanding"], "s1_extra":["3m>=0.35", "5m>=0.45", "volume_expanding", "relative>=0"], "s2_extra":["3m>=0.20 or 5m>=0.35 or volume_expanding"]},
        "leader_momentum_s": {"label":"주도추세 지속", "core":["15m>=0.65", "30m>=0.65", "relative>=0.30", "VWAP/EMA>=0", "market!=약함"], "s1_extra":["15m>=0.75", "30m>=0.75", "relative>=0.40", "market!=약함"], "s2_extra":["15m>=0.60", "relative>=0.25", "VWAP>=-0.05", "price_alive_s2"]},
        "breakout_early_s": {"label":"돌파 초입", "core":["breakout_hint", "recent_high_gap>=-0.15", "끝물추격 제외"], "s1_extra":["breakout_hint", "volume_expanding", "recent_high_gap>=-0.08", "3m>=0.15", "not high_end"], "s2_extra":["breakout_hint", "recent_high_gap>=-0.25", "volume or 3m>=0.15"]},
        "sweep_vwap_recovery_s": {"label":"저점 VWAP 회복", "core":["sweep_reclaim_hint", "VWAP>=-0.05", "low_rebound>=0.40"], "s1_extra":["sweep", "low_rebound>=0.55", "3m>=0.08", "day_pos<88"], "s2_extra":["sweep", "VWAP>=-0.08", "low_rebound>=0.35", "price_alive_s2"]},
        "surge_rebreak_s": {"label":"급등 후 재돌파", "core":["15m>=1.20", "3m>=0.15", "recent_high_gap>=-0.25", "no long_upper_wick"], "s1_extra":["15m>=1.20", "3m>=0.25", "recent_high_gap>=-0.15", "not overheat"], "s2_extra":["15m>=1.00", "recent_high_gap>=-0.30", "price_alive_s2"]},
        "leader_flow_adaptive_hold_s": {"label":"주도흐름 유동보유", "core":["3m/5m or 15m/30m trend", "VWAP>=-0.10", "EMA5>=-0.15", "turnover>=3억", "min buy/spread"], "s1_extra":["15m>=0.70", "30m>=0.40", "relative>=0", "VWAP>=-0.03", "EMA5>=-0.05", "3m>=0.20 or 5m>=0.45 or volume", "not high_end"], "s2_extra":["15m>=0.55 or 5m>=0.55", "VWAP>=-0.08", "EMA5>=-0.12"]}
    }
}

CONDITION_MAP_FILE = BASE_DIR / "clean_strategy_condition_map.json"


def _v403_event_sources(ev: Dict[str, Any]) -> List[Dict[str, Any]]:
    srcs: List[Dict[str, Any]] = []
    if isinstance(ev, dict):
        srcs.append(ev)
        for k in ("entry_context", "entry_snapshot", "profile"):
            v = ev.get(k)
            if isinstance(v, dict):
                srcs.append(v)
                for kk in ("flat", "strategy", "orderflow", "feature", "price_flow", "position", "money_flow", "risk"):
                    vv = v.get(kk)
                    if isinstance(vv, dict):
                        srcs.append(vv)
    return srcs


def _v403_merge_from_event(ev: Dict[str, Any], current_row: Dict[str, Any], current_of: Dict[str, Any]) -> Tuple[Dict[str, Any], Dict[str, Any]]:
    row = dict(current_row or {})
    of = dict(current_of or {})
    for src in _v403_event_sources(ev):
        for k, v in src.items():
            if k in {"buy_ratio", "buy_ratio_30s", "buy_ratio_1m", "micro_buy_ratio_sustain_1m", "spread_pct", "micro_spread_pct", "slippage_est_pct", "expected_slippage_pct", "ask_wall_ratio", "bid_wall_ratio", "sell_pressure", "ask_wall_pressure", "sell_trade_pressure", "micro_fresh", "ws_fresh", "quote_fresh"}:
                of.setdefault(k, v)
            else:
                row.setdefault(k, v)
    t = ticker_norm(ev.get("ticker") or row.get("ticker") or row.get("market") or row.get("symbol"))
    if t:
        row.setdefault("ticker", t)
    return row, of


def _v403_stage_policy(ev: Dict[str, Any], feature_map: Dict[str, Dict[str, Any]], ofmap: Dict[str, Dict[str, Any]]) -> Tuple[str, List[str], Dict[str, Any], Dict[str, Any]]:
    t = ticker_norm(ev.get("ticker") or ev.get("market") or ev.get("symbol"))
    row, of = _v403_merge_from_event(ev, feature_map.get(t, {}) if t else {}, ofmap.get(t, {}) if t else {})
    skey = str(ev.get("strategy_key") or ev.get("strategy_bucket_primary") or row.get("strategy_key") or "strategy_s")
    stage, why = _v015_stage_decision(row, of, skey)
    why = ["전략별단계판정"] + [str(x) for x in why[:8]]
    return stage, why, row, of


def _v403_force_policy_fields(row: Dict[str, Any], stage: str, reasons: List[str]) -> Dict[str, Any]:
    out = _v386_force_stage_fields(row, stage) if '_v386_force_stage_fields' in globals() else dict(row or {})
    stage = stage if stage in {"S1", "S2", "S3"} else "S3"
    out["s_stage"] = stage
    out["candidate_grade"] = stage
    out["grade"] = stage
    out["entry_grade"] = stage
    out["signal_grade"] = stage
    out["lifecycle_stage"] = stage
    out["stage_policy_schema"] = "strategy_stage_unified_v403"
    out["stage_policy_note"] = "전략별 조건 안에서 S3/S2/S1 결정; 독립 lifecycle 승격 격리"
    out["s_stage_reasons"] = reasons[:10]
    out["stage_transition"] = f"strategy_direct->{stage}"
    out["paper_bot_open"] = stage == "S1"
    out["open_eligible"] = stage == "S1"
    out["trade_ready"] = stage == "S1"
    out["recheck_required"] = stage == "S2"
    out["observe_only"] = stage == "S3"
    if stage == "S1":
        out["open_source"] = "strategy_stage_unified_v403"
        out["paper_handoff_ready"] = True
        out["final_entry_action"] = "paper_open"
    else:
        out.pop("open_source", None)
        out["paper_handoff_ready"] = False
        out["final_entry_action"] = "recheck" if stage == "S2" else "observe"
    ctx = out.get("entry_context") if isinstance(out.get("entry_context"), dict) else {}
    ctx.update({"s_stage": stage, "candidate_grade": stage, "stage_policy_schema": "strategy_stage_unified_v403", "paper_bot_open": stage == "S1", "open_eligible": stage == "S1", "trade_ready": stage == "S1", "s_stage_reasons": reasons[:10]})
    out["entry_context"] = ctx
    snap = out.get("entry_snapshot") if isinstance(out.get("entry_snapshot"), dict) else None
    if isinstance(snap, dict):
        flat = snap.get("flat") if isinstance(snap.get("flat"), dict) else {}
        flat.update({"s_stage": stage, "candidate_grade": stage, "stage_policy_schema": "strategy_stage_unified_v403"})
        snap["flat"] = flat
        strat = snap.get("strategy") if isinstance(snap.get("strategy"), dict) else {}
        strat.update({"decision_stage": stage, "lifecycle_stage": stage, "stage_policy_schema": "strategy_stage_unified_v403", "decision_note": "v403 전략별 S3/S2/S1 단일판정", "s_stage_reasons": reasons[:10], "paper_bot_open": stage == "S1"})
        snap["strategy"] = strat
        out["entry_snapshot"] = snap
    return out


def _v403_reseal_strategy_stage() -> Dict[str, Any]:
    feature_obj = load_json(FEATURE, {}) or {}
    feature_map = map_rows(feature_obj)
    ofmap = map_rows(load_json(ORDERFLOW, {}) or {})
    rows = [r for r in read_jsonl(PAPER_LATEST, max_lines=240) if isinstance(r, dict)]
    fixed: List[Dict[str, Any]] = []
    counts = {"S1": 0, "S2": 0, "S3": 0}
    reason_top: Dict[str, int] = {}
    transitions: Dict[str, int] = {}
    for ev in rows:
        before = _v386_stage_of(ev) if '_v386_stage_of' in globals() else str(ev.get('s_stage') or 'S3')
        stage, why, row, of = _v403_stage_policy(ev, feature_map, ofmap)
        after = stage if stage in counts else "S3"
        transitions[f"{before}->{after}"] = transitions.get(f"{before}->{after}", 0) + 1
        counts[after] += 1
        for r in why[:5]:
            reason_top[str(r)] = reason_top.get(str(r), 0) + 1
        fixed.append(_v403_force_policy_fields(ev, after, why))
    fixed.sort(key=lambda x: ({"S1": 3, "S2": 2, "S3": 1}.get(str(x.get('s_stage')), 0), fnum(x.get("updated_ts"), x.get("created_at"), default=0.0), fnum(x.get("score"), default=0.0)), reverse=True)
    write_jsonl_atomic(PAPER_LATEST, fixed)
    stats = {"schema": "strategy_stage_unified_v403", "stage_counts": counts, "transitions": transitions, "reason_top": reason_top, "latest_count": len(fixed), "policy": "strategy_direct_only"}
    save_json(CONDITION_MAP_FILE, V403_CONDITION_MAP)
    try:
        h = load_json(HANDOFF, {}) or {}
        h.update({"version": VERSION, "stage_policy_schema": "strategy_stage_unified_v403", "v403_stage_counts": counts, "s1_count": counts.get("S1",0), "s2_count": counts.get("S2",0), "s3_count": counts.get("S3",0), "note": "v403: paper handoff S1 is sealed by strategy-specific S1 + common S1 safety only."})
        save_json(HANDOFF, h)
    except Exception as exc:
        append_error(ERROR, "v403_handoff_status", exc)
    try:
        sm = load_json(SUMMARY, {}) or {}
        sm.update({"version": VERSION, "main_version": MAIN_VERSION if 'MAIN_VERSION' in globals() else MAIN_DEPLOY_VERSION, "condition_map": V403_CONDITION_MAP, "stage_policy_schema": "strategy_stage_unified_v403", "lifecycle_schema": "strategy_stage_unified_v403", "lifecycle_stats": stats, "s_stage_counts": counts, "paper_latest_count": len(fixed), "s_count": len(fixed), "note": "v403: 전략 조건과 S3/S2/S1 단계를 합치고, 독립 lifecycle 가격추적 S2→S1 승격은 최종 OPEN에서 격리."})
        save_json(SUMMARY, sm)
    except Exception as exc:
        append_error(ERROR, "v403_summary_update", exc)
    try:
        pr = load_json(PRIORITY_REQ, {}) or {}
        if isinstance(pr, dict):
            pr["version"] = VERSION
            pr["stage_policy_schema"] = "strategy_stage_unified_v403"
            pr["condition_map"] = V403_CONDITION_MAP
            save_json(PRIORITY_REQ, pr)
    except Exception as exc:
        append_error(ERROR, "v403_priority_update", exc)
    return stats


def run_once() -> Dict[str, Any]:  # type: ignore[override]
    # v403 final path: pre-lifecycle strategy evaluation -> strategy-specific stage reseal.
    base = _v379_base_run_once()
    stats = _v403_reseal_strategy_stage()
    try:
        c = stats.get("stage_counts", {}) if isinstance(stats, dict) else {}
        write_status("running", evaluated=int((load_json(SUMMARY, {}) or {}).get("evaluated") or 0), s_count=sum(int(v) for v in c.values()), paper_latest_count=int(stats.get("latest_count", 0) if isinstance(stats, dict) else 0), s1_count=c.get("S1",0), s2_count=c.get("S2",0), s3_count=c.get("S3",0), lifecycle_schema="strategy_stage_unified_v403", stage_policy_schema="strategy_stage_unified_v403", condition_map_version=VERSION, last_sec=fnum((base or {}).get("last_sec"), default=0.0))
    except Exception:
        pass
    out = dict(base or {})
    out.update({"s_stage_counts": stats.get("stage_counts", {}) if isinstance(stats, dict) else {}, "lifecycle_stats": stats, "stage_policy_schema": "strategy_stage_unified_v403", "condition_map_version": VERSION})
    return out



# =============================================================================
# strategy_worker v0.31 / v405: S1 후보 탈락 사유 세분화 + 전략별 필요정보 점검
# - 조건 수치를 새로 풀거나 조이지 않는다.
# - v403의 전략별 S3/S2/S1 단일 구조를 유지한다.
# - 후보마다 "왜 S1이 아닌지"를 사람말로 남긴다.
# - 정보부족은 한 단어로 뭉치지 않고 가격/WS/micro/체결/스프레드/슬리피지/매도벽 등으로 나눈다.
# =============================================================================
VERSION = "strategy_worker_v0.40"
S1_BLOCK_AUDIT = BASE_DIR / "clean_strategy_s1_block_audit.json"

V405_STRATEGY_LABELS = {
    "money_reaccel_s": "돈흐름 재가속",
    "leader_momentum_s": "주도추세 지속",
    "breakout_early_s": "돌파 초입",
    "sweep_vwap_recovery_s": "저점 VWAP 회복",
    "surge_rebreak_s": "급등 후 재돌파",
    "leader_flow_adaptive_hold_s": "주도흐름 유동보유",
}

V405_INFO_LABELS = {
    "price": "현재가",
    "quote_fresh": "실시간 시세",
    "ws_fresh": "웹소켓 시세",
    "micro_fresh": "호가·체결",
    "buy_ratio": "매수체결비",
    "buy_sustain_1m": "1분 매수지속",
    "spread": "스프레드",
    "slippage": "예상 미끄러짐",
    "ask_wall": "매도벽",
    "sell_pressure": "매도압력",
    "price_reaction": "가격반응",
    "short_flow": "30초~3분 흐름",
    "mid_flow": "5~30분 흐름",
    "vwap": "VWAP 위치",
    "ema5": "EMA5 위치",
    "relative_strength": "시장대비 힘",
    "volume_expanding": "거래량 확장",
    "recent_high_gap": "고점 거리",
    "low_rebound": "저점 반등",
    "day_position": "당일 위치",
    "breakout_hint": "돌파 신호",
    "sweep_hint": "저점 회복 신호",
    "market_mode": "장세 모드",
}

V405_COMMON_REQUIRED = [
    "price", "quote_fresh", "micro_fresh", "buy_ratio", "buy_sustain_1m", "spread", "slippage",
    "ask_wall", "sell_pressure", "price_reaction", "short_flow", "vwap", "ema5",
]

V405_STRATEGY_REQUIRED = {
    "money_reaccel_s": ["short_flow", "mid_flow", "vwap", "ema5", "volume_expanding", "relative_strength", "buy_ratio", "spread"],
    "leader_momentum_s": ["mid_flow", "relative_strength", "vwap", "ema5", "market_mode", "buy_ratio", "spread"],
    "breakout_early_s": ["breakout_hint", "recent_high_gap", "short_flow", "volume_expanding", "buy_ratio", "spread"],
    "sweep_vwap_recovery_s": ["sweep_hint", "low_rebound", "vwap", "short_flow", "day_position", "buy_ratio", "spread"],
    "surge_rebreak_s": ["mid_flow", "short_flow", "recent_high_gap", "vwap", "ema5", "buy_ratio", "spread"],
    "leader_flow_adaptive_hold_s": ["mid_flow", "short_flow", "relative_strength", "vwap", "ema5", "volume_expanding", "buy_ratio", "spread"],
}

V405_OUTSIDE_REFERENCE_INFO = [
    {"name":"RSI/과매수·과매도", "status":"미사용", "note":"전략 필수값은 아님. 나중에 과열/저점 회복 보조지표로 검토 가능."},
    {"name":"MACD/이동평균 교차", "status":"미사용", "note":"현재는 EMA/VWAP/흐름으로 대체 중. 추세 지속 전략 보조로만 검토."},
    {"name":"볼린저밴드/변동성 밴드", "status":"미사용", "note":"돌파·저점회복의 위치 판단 보조 후보. 지금 바로 조건 추가 금지."},
    {"name":"체결 속도 가속도", "status":"부분", "note":"매수체결비는 있으나 초당 체결속도 변화는 별도 지표가 약함."},
    {"name":"호가잔량 변화율", "status":"부분", "note":"매도벽/스프레드는 있으나 벽이 빠지는 속도는 아직 약함."},
    {"name":"BTC/전체장 선행 방향", "status":"부분", "note":"장세 모드는 있으나 특정 대장 흐름 선행성은 추가 검토 영역."},
]

def _v405_sources(row: Dict[str, Any], of: Dict[str, Any]) -> List[Dict[str, Any]]:
    srcs: List[Dict[str, Any]] = []
    for obj in (row, of, row.get("entry_context"), row.get("entry_snapshot")):
        if isinstance(obj, dict):
            srcs.append(obj)
            for k in ("flat", "strategy", "orderflow", "feature", "price_flow", "position", "money_flow", "risk", "profile"):
                v = obj.get(k)
                if isinstance(v, dict):
                    srcs.append(v)
    return srcs

def _v405_first(row: Dict[str, Any], of: Dict[str, Any], *keys: str) -> Any:
    for src in _v405_sources(row, of):
        for k in keys:
            if k in src:
                v = src.get(k)
                if v is not None and str(v).strip() not in {"", "-", "None", "nan", "NaN"}:
                    return v
    return None

def _v405_known(row: Dict[str, Any], of: Dict[str, Any], *keys: str) -> bool:
    return _v405_first(row, of, *keys) is not None

def _v405_bool_val(v: Any) -> bool:
    if isinstance(v, bool): return v
    return str(v).strip().lower() in {"1", "true", "yes", "ok", "fresh", "신선", "ready"}

def _v405_num(row: Dict[str, Any], of: Dict[str, Any], *keys: str, default: float = 0.0) -> float:
    vals = []
    for src in _v405_sources(row, of):
        vals += [src.get(k) for k in keys]
    return fnum(*vals, default=default)

def _v405_info_ready(row: Dict[str, Any], of: Dict[str, Any]) -> Dict[str, Dict[str, Any]]:
    ch30s = _v405_num(row, of, "change_30s", "price_change_30s", default=0.0)
    ch1 = _v405_num(row, of, "change_1m", "price_change_1m", default=0.0)
    ch3 = _v405_num(row, of, "change_3m", "price_change_3m", "money_flow_3m_pct", "three_min_flow_pct", default=0.0)
    ch5 = _v405_num(row, of, "change_5m", "price_change_5m", "five_min_flow_pct", default=0.0)
    ch15 = _v405_num(row, of, "change_15m", "price_change_15m", default=0.0)
    ch30 = _v405_num(row, of, "change_30m", "price_change_30m", default=0.0)
    def item(key: str, ready: bool, value: Any = None, note: str = "") -> Dict[str, Any]:
        return {"key": key, "label": V405_INFO_LABELS.get(key, key), "ready": bool(ready), "value": value, "note": note}
    price = _v405_first(row, of, "current_price", "entry_price", "price", "detected_price", "close")
    quote_fresh = _v405_bool_val(_v405_first(row, of, "quote_fresh", "ws_fresh"))
    ws_fresh = _v405_bool_val(_v405_first(row, of, "ws_fresh", "quote_fresh"))
    micro_fresh = _v405_bool_val(_v405_first(row, of, "micro_fresh"))
    buy = _v405_num(row, of, "buy_ratio", "buy_ratio_30s", "micro_trade_buy_ratio_30", default=-1.0)
    buy1 = _v405_num(row, of, "buy_ratio_1m", "buy_ratio_60", "micro_buy_ratio_sustain_1m", "buy_ratio_sustain", default=-1.0)
    spread = _v405_num(row, of, "spread_pct", "micro_spread_pct", default=99.0)
    slip = _v405_num(row, of, "slippage_est_pct", "tick_pct_est", "expected_slippage_pct", default=99.0)
    ask = _v405_num(row, of, "ask_wall_ratio", "ask_wall", "micro_ask_wall_ratio", default=-1.0)
    sell_known = _v405_known(row, of, "sell_pressure", "ask_wall_pressure", "sell_trade_pressure")
    sell = _v405_bool_val(_v405_first(row, of, "sell_pressure", "ask_wall_pressure", "sell_trade_pressure"))
    pr = _v405_num(row, of, "price_reaction_score", "price_recheck_pct", "price_reaction_pct", default=-999.0)
    vwap = _v405_num(row, of, "vwap_gap_pct", default=-999.0)
    ema = _v405_num(row, of, "ema5_gap_pct", "ma5_gap_pct", default=-999.0)
    rel = _v405_num(row, of, "relative_strength_pct", "relative_strength", default=-999.0)
    high_gap = _v405_num(row, of, "recent_high_gap_pct", "below_high_pct", default=-999.0)
    low_reb = _v405_num(row, of, "recent_low_rebound_pct", "low_defense_pct", default=-999.0)
    day_pos = _v405_num(row, of, "day_pos_pct", "current_close_pos_ratio", default=-999.0)
    vol = _v405_first(row, of, "volume_expanding")
    breakout = _v405_first(row, of, "breakout_hint")
    sweep = _v405_first(row, of, "sweep_reclaim_hint")
    market = _v405_first(row, of, "market_mode")
    return {
        "price": item("price", price is not None, price),
        "quote_fresh": item("quote_fresh", quote_fresh, quote_fresh),
        "ws_fresh": item("ws_fresh", ws_fresh, ws_fresh),
        "micro_fresh": item("micro_fresh", micro_fresh, micro_fresh),
        "buy_ratio": item("buy_ratio", buy >= 0, buy),
        "buy_sustain_1m": item("buy_sustain_1m", buy1 >= 0, buy1),
        "spread": item("spread", spread < 90, spread),
        "slippage": item("slippage", slip < 90, slip),
        "ask_wall": item("ask_wall", ask >= 0, ask),
        "sell_pressure": item("sell_pressure", sell_known, sell),
        "price_reaction": item("price_reaction", pr > -900, pr),
        "short_flow": item("short_flow", _v405_known(row, of, "change_30s", "price_change_30s", "change_1m", "price_change_1m", "change_3m", "price_change_3m"), {"30s": ch30s, "1m": ch1, "3m": ch3}),
        "mid_flow": item("mid_flow", _v405_known(row, of, "change_5m", "price_change_5m", "change_15m", "price_change_15m", "change_30m", "price_change_30m"), {"5m": ch5, "15m": ch15, "30m": ch30}),
        "vwap": item("vwap", vwap > -900, vwap),
        "ema5": item("ema5", ema > -900, ema),
        "relative_strength": item("relative_strength", rel > -900, rel),
        "volume_expanding": item("volume_expanding", vol is not None, bool(vol) if vol is not None else None),
        "recent_high_gap": item("recent_high_gap", high_gap > -900, high_gap),
        "low_rebound": item("low_rebound", low_reb > -900, low_reb),
        "day_position": item("day_position", day_pos > -900, day_pos),
        "breakout_hint": item("breakout_hint", breakout is not None, bool(breakout) if breakout is not None else None),
        "sweep_hint": item("sweep_hint", sweep is not None, bool(sweep) if sweep is not None else None),
        "market_mode": item("market_mode", market is not None, market),
    }

def _v405_fail_details(row: Dict[str, Any], of: Dict[str, Any], skey: str, stage: str) -> Tuple[List[Dict[str, str]], List[Dict[str, str]], List[Dict[str, Any]]]:
    info = _v405_info_ready(row, of)
    fail: List[Dict[str, str]] = []
    missing: List[Dict[str, str]] = []
    def add(cat: str, key: str, text: str, value: Any = "") -> None:
        fail.append({"category": cat, "key": key, "label": text, "value": str(value)})
    def miss(key: str, why: str = "값 없음") -> None:
        label = V405_INFO_LABELS.get(key, key)
        missing.append({"key": key, "label": label, "why": why})
        add("정보부족", key, f"{label} 없음", why)
    def req_missing(keys: List[str]) -> None:
        for k in keys:
            if not info.get(k, {}).get("ready"):
                miss(k)
    req_missing(V405_COMMON_REQUIRED + V405_STRATEGY_REQUIRED.get(skey, []))
    buy = _v405_num(row, of, "buy_ratio", "buy_ratio_30s", "micro_trade_buy_ratio_30", default=-1.0)
    buy1 = _v405_num(row, of, "buy_ratio_1m", "buy_ratio_60", "micro_buy_ratio_sustain_1m", "buy_ratio_sustain", default=-1.0)
    spread = _v405_num(row, of, "spread_pct", "micro_spread_pct", default=99.0)
    slip = _v405_num(row, of, "slippage_est_pct", "tick_pct_est", "expected_slippage_pct", default=99.0)
    ask = _v405_num(row, of, "ask_wall_ratio", "ask_wall", "micro_ask_wall_ratio", default=-1.0)
    bid = _v405_num(row, of, "bid_wall_ratio", "micro_bid_ask_wall_ratio", default=0.0)
    sell = _v405_bool_val(_v405_first(row, of, "sell_pressure", "ask_wall_pressure", "sell_trade_pressure"))
    pr = _v405_num(row, of, "price_reaction_score", "price_recheck_pct", "price_reaction_pct", default=-999.0)
    ch30s = _v405_num(row, of, "change_30s", "price_change_30s", default=0.0)
    ch1 = _v405_num(row, of, "change_1m", "price_change_1m", default=0.0)
    ch3 = _v405_num(row, of, "change_3m", "price_change_3m", "money_flow_3m_pct", "three_min_flow_pct", default=0.0)
    ch5 = _v405_num(row, of, "change_5m", "price_change_5m", default=0.0)
    ch15 = _v405_num(row, of, "change_15m", "price_change_15m", default=0.0)
    ch30 = _v405_num(row, of, "change_30m", "price_change_30m", default=0.0)
    vwap = _v405_num(row, of, "vwap_gap_pct", default=-999.0)
    ema = _v405_num(row, of, "ema5_gap_pct", "ma5_gap_pct", default=-999.0)
    rel = _v405_num(row, of, "relative_strength_pct", "relative_strength", default=0.0)
    high_gap = _v405_num(row, of, "recent_high_gap_pct", "below_high_pct", default=0.0)
    low_reb = _v405_num(row, of, "recent_low_rebound_pct", "low_defense_pct", default=0.0)
    day = _v405_num(row, of, "day_pos_pct", "current_close_pos_ratio", default=50.0)
    vol = bool(_v405_first(row, of, "volume_expanding"))
    breakout = bool(_v405_first(row, of, "breakout_hint"))
    sweep = bool(_v405_first(row, of, "sweep_reclaim_hint"))
    market = str(_v405_first(row, of, "market_mode") or "")
    quote_fresh = _v405_bool_val(_v405_first(row, of, "quote_fresh", "ws_fresh"))
    micro_fresh = _v405_bool_val(_v405_first(row, of, "micro_fresh"))
    if not quote_fresh: add("공통S1", "quote_fresh", "실시간 시세가 오래됐거나 없음")
    if not micro_fresh: add("공통S1", "micro_fresh", "호가·체결 정보가 오래됐거나 없음")
    if buy >= 0 and buy < 0.70: add("공통S1", "buy_ratio", "매수체결비 부족", f"{buy:.2f} < 0.70")
    if buy1 >= 0 and buy1 < 0.64: add("공통S1", "buy_sustain_1m", "1분 매수지속 부족", f"{buy1:.2f} < 0.64")
    if spread < 90 and spread > 0.18: add("공통S1", "spread", "스프레드 부담", f"{spread:.2f}% > 0.18%")
    if slip < 90 and slip > 0.20: add("공통S1", "slippage", "예상 미끄러짐 부담", f"{slip:.2f}% > 0.20%")
    if sell or (ask >= 0 and ask >= 1.15 and bid < ask): add("공통S1", "sell_pressure", "매도벽/매도압력 부담")
    if pr > -900 and pr < 0.05: add("공통S1", "price_reaction", "가격반응 부족", f"{pr:+.2f} < +0.05")
    if not (ch30s >= 0.02 or ch1 >= 0.08 or ch3 >= 0.25): add("공통S1", "short_flow", "진입 직전 단기반응 부족", f"30s {ch30s:+.2f} / 1m {ch1:+.2f} / 3m {ch3:+.2f}")
    if vwap > -900 and vwap < -0.03: add("공통S1", "vwap", "VWAP 아래라 위치 부담", f"{vwap:+.2f}%")
    if ema > -900 and ema < -0.05: add("공통S1", "ema5", "EMA5 아래라 추세 부담", f"{ema:+.2f}%")
    high_end = day >= 90.0 and high_gap >= -0.20
    overheat = (ch5 >= 6.0 and (ema >= 3.0 or vwap >= 0.80)) or ch15 >= 12.0 or ema >= 8.0
    if high_end and (pr < 0.08): add("공통S1", "high_end", "고점권인데 가격반응 약함")
    if overheat: add("공통S1", "overheat", "급등 과열/이격 부담")
    # strategy-specific S1 reasons
    if skey == "money_reaccel_s":
        if ch3 < 0.35: add("전략S1", "ch3", "돈흐름 3분 부족", f"{ch3:+.2f} < +0.35")
        if ch5 < 0.45: add("전략S1", "ch5", "돈흐름 5분 부족", f"{ch5:+.2f} < +0.45")
        if not vol: add("전략S1", "volume", "거래량 확장 부족")
        if rel < 0: add("전략S1", "relative", "시장대비 힘 부족", f"{rel:+.2f}")
    elif skey == "leader_momentum_s":
        if ch15 < 0.75: add("전략S1", "ch15", "15분 주도흐름 부족", f"{ch15:+.2f} < +0.75")
        if ch30 < 0.75: add("전략S1", "ch30", "30분 주도흐름 부족", f"{ch30:+.2f} < +0.75")
        if rel < 0.40: add("전략S1", "relative", "시장대비 힘 부족", f"{rel:+.2f} < +0.40")
        if market == "약함": add("전략S1", "market", "장이 약한 모드")
    elif skey == "breakout_early_s":
        if not breakout: add("전략S1", "breakout", "돌파 신호 부족")
        if not vol: add("전략S1", "volume", "돌파 거래량 부족")
        if high_gap < -0.08: add("전략S1", "high_gap", "돌파선과 거리 부족", f"{high_gap:+.2f} < -0.08")
        if ch3 < 0.15: add("전략S1", "ch3", "돌파 후 3분 흐름 부족", f"{ch3:+.2f} < +0.15")
    elif skey == "sweep_vwap_recovery_s":
        if not sweep: add("전략S1", "sweep", "저점 회복 신호 부족")
        if low_reb < 0.55: add("전략S1", "low_rebound", "저점 반등폭 부족", f"{low_reb:+.2f} < +0.55")
        if ch3 < 0.08: add("전략S1", "ch3", "회복 후 3분 흐름 부족", f"{ch3:+.2f} < +0.08")
        if day >= 88: add("전략S1", "day_position", "당일 위치가 높음", f"{day:.1f} >= 88")
    elif skey == "surge_rebreak_s":
        if ch15 < 1.20: add("전략S1", "ch15", "급등 후 힘 부족", f"{ch15:+.2f} < +1.20")
        if ch3 < 0.25: add("전략S1", "ch3", "재돌파 3분 힘 부족", f"{ch3:+.2f} < +0.25")
        if high_gap < -0.15: add("전략S1", "high_gap", "고점 재접근 부족", f"{high_gap:+.2f} < -0.15")
    elif skey == "leader_flow_adaptive_hold_s":
        if ch15 < 0.70: add("전략S1", "ch15", "15분 주도흐름 부족", f"{ch15:+.2f} < +0.70")
        if ch30 < 0.40: add("전략S1", "ch30", "30분 유지흐름 부족", f"{ch30:+.2f} < +0.40")
        if rel < 0.0: add("전략S1", "relative", "시장대비 힘 부족", f"{rel:+.2f} < 0")
        if not (ch3 >= 0.20 or ch5 >= 0.45 or vol): add("전략S1", "early_alive", "초입 반응/거래량 부족", f"3m {ch3:+.2f} / 5m {ch5:+.2f}")
    # 중복 제거
    seen=set(); out_fail=[]
    for x in fail:
        sig=(x.get('category'),x.get('key'),x.get('label'))
        if sig in seen: continue
        seen.add(sig); out_fail.append(x)
    seen=set(); out_miss=[]
    for x in missing:
        sig=x.get('key')
        if sig in seen: continue
        seen.add(sig); out_miss.append(x)
    required = []
    for k in list(dict.fromkeys(V405_COMMON_REQUIRED + V405_STRATEGY_REQUIRED.get(skey, []))):
        d = dict(info.get(k, {"key": k, "label": V405_INFO_LABELS.get(k,k), "ready": False}))
        required.append(d)
    return out_fail[:20], out_miss[:20], required

def _v405_human_summary(fail: List[Dict[str, str]], missing: List[Dict[str, str]]) -> str:
    if fail:
        top = []
        for x in fail[:4]:
            val = x.get('value')
            top.append(x.get('label','-') + (f"({val})" if val else ""))
        return " / ".join(top)
    if missing:
        return "부족정보: " + ", ".join(x.get('label','-') for x in missing[:4])
    return "S1 조건 거의 충족 · 추가확인 필요"

def _v405_reseal_strategy_stage() -> Dict[str, Any]:
    feature_obj = load_json(FEATURE, {}) or {}
    feature_map = map_rows(feature_obj)
    ofmap = map_rows(load_json(ORDERFLOW, {}) or {})
    rows = [r for r in read_jsonl(PAPER_LATEST, max_lines=240) if isinstance(r, dict)]
    fixed: List[Dict[str, Any]] = []
    counts = {"S1": 0, "S2": 0, "S3": 0}
    reason_top: Dict[str, int] = {}
    missing_top: Dict[str, int] = {}
    strategy_missing: Dict[str, Dict[str, int]] = {}
    samples: List[Dict[str, Any]] = []
    for ev in rows:
        stage, why, row, of = _v403_stage_policy(ev, feature_map, ofmap)
        skey = str(ev.get("strategy_key") or ev.get("strategy_bucket_primary") or row.get("strategy_key") or "strategy_s")
        fail, missing, required = _v405_fail_details(row, of, skey, stage)
        after = stage if stage in counts else "S3"
        counts[after] += 1
        out = _v403_force_policy_fields(ev, after, why)
        out["stage_policy_schema"] = "strategy_stage_unified_v405"
        out["stage_policy_note"] = "전략별 S3/S2/S1 단일판정 + S1 탈락이유 세분화"
        out["s1_block_reasons_detail"] = fail
        out["s1_missing_info_detail"] = missing
        out["strategy_required_info"] = required
        out["s1_block_summary"] = _v405_human_summary(fail, missing)
        out["easy_status_label"] = "✅ 실제진입" if after == "S1" else ("⚠️ 재확인" if after == "S2" else "❔ 관찰")
        out["strategy_label_easy"] = V405_STRATEGY_LABELS.get(skey, skey)
        ctx = out.get("entry_context") if isinstance(out.get("entry_context"), dict) else {}
        ctx.update({"s1_block_reasons_detail": fail, "s1_missing_info_detail": missing, "strategy_required_info": required, "s1_block_summary": out["s1_block_summary"], "stage_policy_schema":"strategy_stage_unified_v405"})
        out["entry_context"] = ctx
        snap = out.get("entry_snapshot") if isinstance(out.get("entry_snapshot"), dict) else None
        if isinstance(snap, dict):
            strat = snap.get("strategy") if isinstance(snap.get("strategy"), dict) else {}
            strat.update({"stage_policy_schema":"strategy_stage_unified_v405", "s1_block_reasons_detail": fail, "s1_missing_info_detail": missing, "strategy_required_info": required, "s1_block_summary": out["s1_block_summary"]})
            snap["strategy"] = strat
            flat = snap.get("flat") if isinstance(snap.get("flat"), dict) else {}
            flat.update({"stage_policy_schema":"strategy_stage_unified_v405", "s1_block_summary": out["s1_block_summary"]})
            snap["flat"] = flat
            out["entry_snapshot"] = snap
        for x in fail:
            label = str(x.get("label") or x.get("key") or "기타")
            reason_top[label] = reason_top.get(label, 0) + 1
        for x in missing:
            label = str(x.get("label") or x.get("key") or "기타")
            missing_top[label] = missing_top.get(label, 0) + 1
            sm = strategy_missing.setdefault(V405_STRATEGY_LABELS.get(skey, skey), {})
            sm[label] = sm.get(label, 0) + 1
        if after != "S1" and len(samples) < 20:
            samples.append({
                "ticker": ticker_norm(out.get("ticker") or out.get("market") or out.get("symbol")),
                "strategy": V405_STRATEGY_LABELS.get(skey, skey),
                "strategy_key": skey,
                "stage": after,
                "score": out.get("score"),
                "summary": out.get("s1_block_summary"),
                "missing": missing[:6],
                "fail": fail[:8],
                "required_ready": sum(1 for d in required if d.get("ready")),
                "required_total": len(required),
            })
        fixed.append(out)
    fixed.sort(key=lambda x: ({"S1": 3, "S2": 2, "S3": 1}.get(str(x.get('s_stage')), 0), fnum(x.get("score"), default=0.0), fnum(x.get("updated_ts"), x.get("created_at"), default=0.0)), reverse=True)
    write_jsonl_atomic(PAPER_LATEST, fixed)
    stats = {"schema": "strategy_stage_unified_v405", "stage_counts": counts, "reason_top": reason_top, "missing_info_top": missing_top, "strategy_missing_info": strategy_missing, "samples": samples, "latest_count": len(fixed), "policy": "strategy_direct_only_with_s1_block_detail"}
    cmap = dict(V403_CONDITION_MAP)
    cmap["version"] = VERSION
    cmap["schema"] = "strategy_stage_unified_v405"
    cmap["summary"] = "전략별 S3/S2/S1 단일 구조 유지 + S1 탈락 이유와 부족정보를 세분화"
    cmap["info_labels"] = V405_INFO_LABELS
    cmap["strategy_required_info"] = {V405_STRATEGY_LABELS.get(k,k): [V405_INFO_LABELS.get(x,x) for x in v] for k,v in V405_STRATEGY_REQUIRED.items()}
    cmap["outside_reference_info"] = V405_OUTSIDE_REFERENCE_INFO
    save_json(CONDITION_MAP_FILE, cmap)
    save_json(S1_BLOCK_AUDIT, {"version": VERSION, "updated_ts": now_ts(), "updated_text": now_text(), **stats, "outside_reference_info": V405_OUTSIDE_REFERENCE_INFO})
    try:
        h = load_json(HANDOFF, {}) or {}
        h.update({"version": VERSION, "stage_policy_schema": "strategy_stage_unified_v405", "v405_stage_counts": counts, "s1_count": counts.get("S1",0), "s2_count": counts.get("S2",0), "s3_count": counts.get("S3",0), "s1_block_audit": stats, "note":"v405: S1 미달 이유를 공통S1/전략S1/부족정보로 나눠 handoff에 저장."})
        save_json(HANDOFF, h)
    except Exception as exc:
        append_error(ERROR, "v405_handoff_status", exc)
    try:
        sm = load_json(SUMMARY, {}) or {}
        sm.update({"version": VERSION, "main_version": "v2.13.393", "condition_map": cmap, "stage_policy_schema": "strategy_stage_unified_v405", "lifecycle_schema": "strategy_stage_unified_v405", "lifecycle_stats": stats, "s_stage_counts": counts, "paper_latest_count": len(fixed), "s_count": len(fixed), "s1_block_audit": stats, "note":"v405: S1 후보가 왜 실제진입이 아닌지 쉬운 사유와 부족정보 세부항목을 남긴다."})
        save_json(SUMMARY, sm)
    except Exception as exc:
        append_error(ERROR, "v405_summary_update", exc)
    try:
        pr = load_json(PRIORITY_REQ, {}) or {}
        if isinstance(pr, dict):
            pr["version"] = VERSION
            pr["stage_policy_schema"] = "strategy_stage_unified_v405"
            pr["s1_block_audit"] = stats
            save_json(PRIORITY_REQ, pr)
    except Exception as exc:
        append_error(ERROR, "v405_priority_update", exc)
    return stats

def run_once() -> Dict[str, Any]:  # type: ignore[override]
    base = _v379_base_run_once()
    stats = _v405_reseal_strategy_stage()
    try:
        c = stats.get("stage_counts", {}) if isinstance(stats, dict) else {}
        write_status("running", evaluated=int((load_json(SUMMARY, {}) or {}).get("evaluated") or 0), s_count=sum(int(v) for v in c.values()), paper_latest_count=int(stats.get("latest_count", 0) if isinstance(stats, dict) else 0), s1_count=c.get("S1",0), s2_count=c.get("S2",0), s3_count=c.get("S3",0), lifecycle_schema="strategy_stage_unified_v405", stage_policy_schema="strategy_stage_unified_v405", condition_map_version=VERSION, s1_block_audit=stats, last_sec=fnum((base or {}).get("last_sec"), default=0.0))
    except Exception:
        pass
    out = dict(base or {})
    out.update({"s_stage_counts": stats.get("stage_counts", {}) if isinstance(stats, dict) else {}, "lifecycle_stats": stats, "stage_policy_schema": "strategy_stage_unified_v405", "condition_map_version": VERSION})
    return out


# =============================================================================
# strategy_worker v0.32 / v407: 가격반응 배관 수리 + 보조정보 수집/표시
# - 조건 수치를 풀거나 조이지 않는다.
# - 가격반응 값이 비었을 때 30초/1분/3분 흐름, 포착가 대비 현재가로 계산 가능한 대체값을 만든다.
# - RSI/MACD/볼린저/BTC방향 같은 보조정보는 조건이 아니라 수집·표시용으로만 남긴다.
# =============================================================================
VERSION = "strategy_worker_v0.40"

V407_SCHEMA = "strategy_stage_unified_v407_price_reaction_aux_info"

V407_AUX_INFO = {
    "rsi": {"label": "RSI/과열 위치", "keys": ["rsi", "rsi14", "rsi_14"], "note": "아직 매수조건 아님. 과열/저점회복 참고용."},
    "macd": {"label": "MACD/추세 전환", "keys": ["macd", "macd_hist", "macd_signal", "macd_histogram"], "note": "아직 매수조건 아님. 추세 지속 참고용."},
    "bollinger": {"label": "볼린저밴드 위치", "keys": ["bb_pos", "bollinger_pos", "bb_width", "bollinger_width"], "note": "아직 매수조건 아님. 돌파/저점 위치 참고용."},
    "trade_speed_accel": {"label": "체결 속도 가속도", "keys": ["trade_speed_accel", "buy_trade_speed_accel", "trade_count_accel"], "note": "30초 매수비와 1분 매수지속 차이로 보조 계산 가능."},
    "orderbook_wall_change": {"label": "호가잔량 변화", "keys": ["ask_wall_change", "bid_wall_change", "orderbook_wall_change", "ask_wall_delta"], "note": "매도벽이 빠지는 속도 확인용. 아직 조건 아님."},
    "btc_market_lead": {"label": "BTC/전체장 선행 방향", "keys": ["btc_1m", "btc_3m", "btc_5m", "btc_trend", "market_lead_direction", "market_mode"], "note": "장세 모드는 있으나 BTC 선행성은 추가 보강 후보."},
}


def _v407_num_any(row: Dict[str, Any], of: Dict[str, Any], *keys: str, default: float = -999.0) -> float:
    return _v405_num(row, of, *keys, default=default) if '_v405_num' in globals() else fnum(*[row.get(k) for k in keys], *[of.get(k) for k in keys], default=default)


def _v407_known_any(row: Dict[str, Any], of: Dict[str, Any], *keys: str) -> bool:
    if '_v405_known' in globals():
        return _v405_known(row, of, *keys)
    for src in (row, of):
        if isinstance(src, dict):
            for k in keys:
                v = src.get(k)
                if v is not None and str(v).strip() not in {'', '-', 'None', 'nan', 'NaN'}:
                    return True
    return False


def _v407_find_price(row: Dict[str, Any], of: Dict[str, Any], *keys: str) -> float:
    return _v407_num_any(row, of, *keys, default=-999.0)


def _v407_price_reaction(row: Dict[str, Any], of: Dict[str, Any]) -> Dict[str, Any]:
    """가격반응을 비워두지 않는다. 명시값이 있으면 그것을 쓰고, 없으면 계산 가능한 안전 대체값을 만든다."""
    explicit = _v407_num_any(row, of, "price_reaction_score", "price_recheck_pct", "price_reaction_pct", default=-999.0)
    if explicit > -900:
        return {"ready": True, "value": explicit, "source": "전용 가격반응값", "note": f"기존값 {explicit:+.2f}%"}

    # 1순위: 후보 포착가/재확인가 대비 현재가
    current = _v407_find_price(row, of, "current_price", "price", "last_price", "close", "trade_price")
    ref = _v407_find_price(row, of, "detected_price", "watch_price", "first_seen_price", "s3_price", "s2_price", "candidate_price", "base_price", "entry_signal_price")
    if current > 0 and ref > 0:
        pct = (current - ref) / ref * 100.0
        return {"ready": True, "value": pct, "source": "포착가 대비 현재가", "note": f"현재 {current:.6g} / 기준 {ref:.6g}"}

    # 2순위: 단기 흐름. 이미 S1 안전문에 같이 쓰는 값이라 새 조건이 아니라 빈 값 보정이다.
    ch30s = _v407_num_any(row, of, "change_30s", "price_change_30s", default=-999.0)
    ch1 = _v407_num_any(row, of, "change_1m", "price_change_1m", default=-999.0)
    ch3 = _v407_num_any(row, of, "change_3m", "price_change_3m", "money_flow_3m_pct", "three_min_flow_pct", default=-999.0)
    candidates = [("30초 흐름", ch30s), ("1분 흐름", ch1), ("3분 흐름", ch3)]
    known = [(name, val) for name, val in candidates if val > -900]
    if known:
        # 진입 직전 반응 확인용이므로 가장 좋은 값이 아니라, 30초/1분을 우선하고 없을 때 3분을 쓴다.
        for name, val in known:
            if name in {"30초 흐름", "1분 흐름"}:
                return {"ready": True, "value": val, "source": f"{name} 대체", "note": "전용 가격반응값이 없어 단기흐름으로 계산"}
        name, val = known[-1]
        return {"ready": True, "value": val, "source": f"{name} 대체", "note": "전용 가격반응값이 없어 3분 흐름으로 계산"}

    return {"ready": False, "value": -999.0, "source": "계산불가", "note": "가격반응 전용값·포착가·단기흐름 모두 없음"}


def _v407_hydrate_row(row: Dict[str, Any], of: Dict[str, Any]) -> Tuple[Dict[str, Any], Dict[str, Any]]:
    r = dict(row or {})
    o = dict(of or {})
    pr = _v407_price_reaction(r, o)
    if pr.get("ready"):
        val = fnum(pr.get("value"), default=0.0)
        r.setdefault("price_reaction_pct", val)
        r.setdefault("price_recheck_pct", val)
        r["price_reaction_source"] = pr.get("source")
        r["price_reaction_note"] = pr.get("note")
        ctx = r.get("entry_context") if isinstance(r.get("entry_context"), dict) else {}
        ctx.update({"price_reaction_pct": val, "price_reaction_source": pr.get("source"), "price_reaction_note": pr.get("note")})
        r["entry_context"] = ctx
    return r, o


def _v407_aux_info(row: Dict[str, Any], of: Dict[str, Any]) -> Dict[str, Dict[str, Any]]:
    out: Dict[str, Dict[str, Any]] = {}
    buy30 = _v407_num_any(row, of, "buy_ratio", "buy_ratio_30s", "micro_trade_buy_ratio_30", default=-999.0)
    buy1 = _v407_num_any(row, of, "buy_ratio_1m", "buy_ratio_60", "micro_buy_ratio_sustain_1m", "buy_ratio_sustain", default=-999.0)
    ask = _v407_num_any(row, of, "ask_wall_ratio", "ask_wall", "micro_ask_wall_ratio", default=-999.0)
    bid = _v407_num_any(row, of, "bid_wall_ratio", "micro_bid_wall_ratio", default=-999.0)
    market_mode = _v405_first(row, of, "market_mode") if '_v405_first' in globals() else row.get("market_mode")
    for key, spec in V407_AUX_INFO.items():
        keys = spec.get("keys", [])
        ready = _v407_known_any(row, of, *keys)
        value: Any = None
        status = "수집됨" if ready else "없음"
        if key == "trade_speed_accel" and buy30 > -900 and buy1 > -900:
            ready = True; value = round(buy30 - buy1, 4); status = "보조계산"
        elif key == "orderbook_wall_change" and ask > -900 and bid > -900:
            ready = True; value = {"매도벽": ask, "매수벽": bid}; status = "현재벽만 있음"
        elif key == "btc_market_lead" and market_mode is not None:
            ready = True; value = market_mode; status = "장세모드 있음"
        else:
            if ready:
                value = _v405_first(row, of, *keys) if '_v405_first' in globals() else None
        out[key] = {"key": key, "label": spec.get("label", key), "ready": bool(ready), "status": status, "value": value, "note": spec.get("note", "")}
    return out


def _v407_stage_policy(ev: Dict[str, Any], feature_map: Dict[str, Dict[str, Any]], ofmap: Dict[str, Dict[str, Any]]) -> Tuple[str, List[str], Dict[str, Any], Dict[str, Any]]:
    t = ticker_norm(ev.get("ticker") or ev.get("market") or ev.get("symbol"))
    row, of = _v403_merge_from_event(ev, feature_map.get(t, {}) if t else {}, ofmap.get(t, {}) if t else {})
    row, of = _v407_hydrate_row(row, of)
    skey = str(ev.get("strategy_key") or ev.get("strategy_bucket_primary") or row.get("strategy_key") or "strategy_s")
    stage, why = _v015_stage_decision(row, of, skey)
    pr = _v407_price_reaction(row, of)
    if pr.get("ready"):
        why = [f"가격반응:{pr.get('source')} {fnum(pr.get('value'), default=0.0):+.2f}%"] + list(why)
    why = ["전략별단계판정"] + [str(x) for x in why[:8]]
    return stage, why, row, of


_v407_prev_fail_details = _v405_fail_details


def _v405_fail_details(row: Dict[str, Any], of: Dict[str, Any], skey: str, stage: str):  # type: ignore[override]
    row2, of2 = _v407_hydrate_row(row, of)
    fail, missing, required = _v407_prev_fail_details(row2, of2, skey, stage)
    aux = _v407_aux_info(row2, of2)
    for d in required:
        if isinstance(d, dict) and d.get("key") == "price_reaction":
            pr = _v407_price_reaction(row2, of2)
            if pr.get("ready"):
                d["ready"] = True
                d["value"] = fnum(pr.get("value"), default=0.0)
                d["note"] = f"{pr.get('source')} · {pr.get('note')}"
    # v405에서 이미 만들어진 '가격반응 없음'은 보조계산이 되면 제거한다.
    pr = _v407_price_reaction(row2, of2)
    if pr.get("ready"):
        missing = [x for x in missing if not (isinstance(x, dict) and x.get("key") == "price_reaction")]
        fail = [x for x in fail if not (isinstance(x, dict) and x.get("key") == "price_reaction" and "없음" in str(x.get("label")))]
    return fail, missing, required


def _v407_reseal_strategy_stage() -> Dict[str, Any]:
    feature_obj = load_json(FEATURE, {}) or {}
    feature_map = map_rows(feature_obj)
    ofmap = map_rows(load_json(ORDERFLOW, {}) or {})
    rows = [r for r in read_jsonl(PAPER_LATEST, max_lines=240) if isinstance(r, dict)]
    fixed: List[Dict[str, Any]] = []
    counts = {"S1": 0, "S2": 0, "S3": 0}
    reason_top: Dict[str, int] = {}
    missing_top: Dict[str, int] = {}
    strategy_missing: Dict[str, Dict[str, int]] = {}
    samples: List[Dict[str, Any]] = []
    pr_sources: Dict[str, int] = {}
    aux_ready_top: Dict[str, int] = {}
    aux_missing_top: Dict[str, int] = {}
    for ev in rows:
        stage, why, row, of = _v407_stage_policy(ev, feature_map, ofmap)
        skey = str(ev.get("strategy_key") or ev.get("strategy_bucket_primary") or row.get("strategy_key") or "strategy_s")
        fail, missing, required = _v405_fail_details(row, of, skey, stage)
        aux = _v407_aux_info(row, of)
        pr = _v407_price_reaction(row, of)
        pr_sources[str(pr.get("source") or "계산불가")] = pr_sources.get(str(pr.get("source") or "계산불가"), 0) + 1
        for av in aux.values():
            label = str(av.get("label") or av.get("key") or "보조정보")
            if av.get("ready"):
                aux_ready_top[label] = aux_ready_top.get(label, 0) + 1
            else:
                aux_missing_top[label] = aux_missing_top.get(label, 0) + 1
        after = stage if stage in counts else "S3"
        counts[after] += 1
        out = _v403_force_policy_fields(ev, after, why)
        out["stage_policy_schema"] = V407_SCHEMA
        out["stage_policy_note"] = "전략별 S3/S2/S1 단일판정 + 가격반응 보조계산 + 보조정보 표시"
        out["price_reaction_pct"] = row.get("price_reaction_pct")
        out["price_reaction_source"] = row.get("price_reaction_source")
        out["price_reaction_note"] = row.get("price_reaction_note")
        out["s1_block_reasons_detail"] = fail
        out["s1_missing_info_detail"] = missing
        out["strategy_required_info"] = required
        out["s1_block_summary"] = _v405_human_summary(fail, missing)
        out["auxiliary_info_status"] = aux
        out["easy_status_label"] = "✅ 실제진입" if after == "S1" else ("⚠️ 재확인" if after == "S2" else "❔ 관찰")
        out["strategy_label_easy"] = V405_STRATEGY_LABELS.get(skey, skey)
        ctx = out.get("entry_context") if isinstance(out.get("entry_context"), dict) else {}
        ctx.update({"price_reaction_pct": row.get("price_reaction_pct"), "price_reaction_source": row.get("price_reaction_source"), "price_reaction_note": row.get("price_reaction_note"), "s1_block_reasons_detail": fail, "s1_missing_info_detail": missing, "strategy_required_info": required, "auxiliary_info_status": aux, "s1_block_summary": out["s1_block_summary"], "stage_policy_schema": V407_SCHEMA})
        out["entry_context"] = ctx
        snap = out.get("entry_snapshot") if isinstance(out.get("entry_snapshot"), dict) else None
        if isinstance(snap, dict):
            strat = snap.get("strategy") if isinstance(snap.get("strategy"), dict) else {}
            strat.update({"stage_policy_schema": V407_SCHEMA, "price_reaction_pct": row.get("price_reaction_pct"), "price_reaction_source": row.get("price_reaction_source"), "s1_block_reasons_detail": fail, "s1_missing_info_detail": missing, "strategy_required_info": required, "auxiliary_info_status": aux, "s1_block_summary": out["s1_block_summary"]})
            snap["strategy"] = strat
            flat = snap.get("flat") if isinstance(snap.get("flat"), dict) else {}
            flat.update({"stage_policy_schema": V407_SCHEMA, "price_reaction_pct": row.get("price_reaction_pct"), "price_reaction_source": row.get("price_reaction_source"), "s1_block_summary": out["s1_block_summary"]})
            snap["flat"] = flat
            out["entry_snapshot"] = snap
        for x in fail:
            label = str(x.get("label") or x.get("key") or "기타")
            reason_top[label] = reason_top.get(label, 0) + 1
        for x in missing:
            label = str(x.get("label") or x.get("key") or "기타")
            missing_top[label] = missing_top.get(label, 0) + 1
            sm = strategy_missing.setdefault(V405_STRATEGY_LABELS.get(skey, skey), {})
            sm[label] = sm.get(label, 0) + 1
        if after != "S1" and len(samples) < 20:
            samples.append({
                "ticker": ticker_norm(out.get("ticker") or out.get("market") or out.get("symbol")),
                "strategy": V405_STRATEGY_LABELS.get(skey, skey),
                "strategy_key": skey,
                "stage": after,
                "score": out.get("score"),
                "summary": out.get("s1_block_summary"),
                "missing": missing[:6],
                "fail": fail[:8],
                "required_ready": sum(1 for d in required if d.get("ready")),
                "required_total": len(required),
                "price_reaction": {"value": row.get("price_reaction_pct"), "source": row.get("price_reaction_source"), "note": row.get("price_reaction_note")},
                "auxiliary_info_status": aux,
            })
        fixed.append(out)
    fixed.sort(key=lambda x: ({"S1": 3, "S2": 2, "S3": 1}.get(str(x.get('s_stage')), 0), fnum(x.get("score"), default=0.0), fnum(x.get("updated_ts"), x.get("created_at"), default=0.0)), reverse=True)
    write_jsonl_atomic(PAPER_LATEST, fixed)
    stats = {"schema": V407_SCHEMA, "stage_counts": counts, "reason_top": reason_top, "missing_info_top": missing_top, "strategy_missing_info": strategy_missing, "samples": samples, "latest_count": len(fixed), "policy": "strategy_direct_only_with_price_reaction_hydration", "price_reaction_sources": pr_sources, "aux_ready_top": aux_ready_top, "aux_missing_top": aux_missing_top}
    cmap = dict(V403_CONDITION_MAP)
    cmap["version"] = VERSION
    cmap["schema"] = V407_SCHEMA
    cmap["summary"] = "전략별 S3/S2/S1 단일 구조 유지 + 가격반응 빈값 보정 + 보조정보 수집/표시. 조건 수치는 변경하지 않음."
    cmap["info_labels"] = V405_INFO_LABELS
    cmap["strategy_required_info"] = {V405_STRATEGY_LABELS.get(k,k): [V405_INFO_LABELS.get(x,x) for x in v] for k,v in V405_STRATEGY_REQUIRED.items()}
    cmap["outside_reference_info"] = [{"name": v.get("label"), "status": "수집/표시 대상", "note": v.get("note")} for v in V407_AUX_INFO.values()]
    cmap["price_reaction_policy"] = ["1순위: 전용 가격반응값", "2순위: 포착가 대비 현재가", "3순위: 30초/1분/3분 흐름으로 보조계산", "조건 수치 +0.05는 변경하지 않음"]
    save_json(CONDITION_MAP_FILE, cmap)
    save_json(S1_BLOCK_AUDIT, {"version": VERSION, "updated_ts": now_ts(), "updated_text": now_text(), **stats, "outside_reference_info": cmap["outside_reference_info"], "price_reaction_policy": cmap["price_reaction_policy"]})
    try:
        h = load_json(HANDOFF, {}) or {}
        h.update({"version": VERSION, "stage_policy_schema": V407_SCHEMA, "v407_stage_counts": counts, "s1_count": counts.get("S1",0), "s2_count": counts.get("S2",0), "s3_count": counts.get("S3",0), "s1_block_audit": stats, "note":"v407: 가격반응 빈값을 실제 값/포착가/단기흐름으로 보조계산하고 보조정보 상태를 handoff에 저장."})
        save_json(HANDOFF, h)
    except Exception as exc:
        append_error(ERROR, "v407_handoff_status", exc)
    try:
        sm = load_json(SUMMARY, {}) or {}
        sm.update({"version": VERSION, "main_version": "v2.13.393", "condition_map": cmap, "stage_policy_schema": V407_SCHEMA, "lifecycle_schema": V407_SCHEMA, "lifecycle_stats": stats, "s_stage_counts": counts, "paper_latest_count": len(fixed), "s_count": len(fixed), "s1_block_audit": stats, "price_reaction_sources": pr_sources, "aux_info_status": {"ready": aux_ready_top, "missing": aux_missing_top}, "note":"v407: 가격반응 배관 수리 + 보조정보 수집/표시. 조건 수치는 변경하지 않음."})
        save_json(SUMMARY, sm)
    except Exception as exc:
        append_error(ERROR, "v407_summary_update", exc)
    return stats


def run_once() -> Dict[str, Any]:  # type: ignore[override]
    base = _v379_base_run_once()
    stats = _v407_reseal_strategy_stage()
    try:
        c = stats.get("stage_counts", {}) if isinstance(stats, dict) else {}
        write_status("running", evaluated=int((load_json(SUMMARY, {}) or {}).get("evaluated") or 0), s_count=sum(int(v) for v in c.values()), paper_latest_count=int(stats.get("latest_count", 0) if isinstance(stats, dict) else 0), s1_count=c.get("S1",0), s2_count=c.get("S2",0), s3_count=c.get("S3",0), lifecycle_schema=V407_SCHEMA, stage_policy_schema=V407_SCHEMA, condition_map_version=VERSION, s1_block_audit=stats, last_sec=fnum((base or {}).get("last_sec"), default=0.0))
    except Exception:
        pass
    out = dict(base or {})
    out.update({"s_stage_counts": stats.get("stage_counts", {}) if isinstance(stats, dict) else {}, "lifecycle_stats": stats, "stage_policy_schema": V407_SCHEMA, "condition_map_version": VERSION})
    return out





# =============================================================================
# strategy_worker v0.33 / v408: 후보 판독 결론 + 보조지표 완성
# - S1/S2/S3를 더 쪼개지 않는다.
# - S1 미달 후보에 복기용 판독(아까움/재확인/안 산 게 맞음)을 붙인다.
# - RSI/MACD/볼린저는 조건이 아니라 수집/표시/비교용이다.
# =============================================================================
VERSION = "strategy_worker_v0.40"
V408_SCHEMA = "strategy_stage_unified_v408_s1_decision_aux_complete"


def _v408_extract_closes(row: Dict[str, Any], of: Dict[str, Any], limit: int = 80) -> List[float]:
    vals: Any = None
    for src in (row, of, row.get('entry_context') if isinstance(row.get('entry_context'), dict) else {}, row.get('entry_snapshot') if isinstance(row.get('entry_snapshot'), dict) else {}):
        if not isinstance(src, dict): continue
        for k in ('closes','close_history','candle_closes','ohlcv_closes','recent_closes','close_list'):
            if isinstance(src.get(k), list) and len(src.get(k)) >= 5:
                vals = src.get(k); break
        if vals is not None: break
        for k in ('candles','ohlcv','kline','klines','candle_rows'):
            arr = src.get(k)
            if isinstance(arr, list) and len(arr) >= 5:
                tmp=[]
                for x in arr:
                    if isinstance(x, dict):
                        tmp.append(fnum(x.get('close'), x.get('c'), x.get('trade_price'), default=0.0))
                    elif isinstance(x, (list, tuple)) and len(x) >= 5:
                        tmp.append(fnum(x[4], default=0.0))
                tmp=[v for v in tmp if v>0]
                if len(tmp)>=5: vals=tmp; break
        if vals is not None: break
    if not isinstance(vals, list): return []
    out=[]
    for v in vals[-limit:]:
        fv=fnum(v, default=0.0)
        if fv>0: out.append(fv)
    return out


def _v408_rsi(closes: List[float], period: int=14) -> Optional[float]:
    if len(closes) < period + 1: return None
    gains=[]; losses=[]
    for a,b in zip(closes[-period-1:-1], closes[-period:]):
        d=b-a
        gains.append(max(d,0.0)); losses.append(max(-d,0.0))
    ag=sum(gains)/period; al=sum(losses)/period
    if al <= 0 and ag <= 0: return 50.0
    if al <= 0: return 100.0
    rs=ag/al
    return 100.0 - (100.0/(1.0+rs))


def _v408_ema(vals: List[float], period: int) -> Optional[float]:
    if len(vals) < period: return None
    k=2.0/(period+1.0)
    ema=sum(vals[:period])/period
    for v in vals[period:]: ema = v*k + ema*(1-k)
    return ema


def _v408_macd(closes: List[float]) -> Dict[str, Any]:
    if len(closes) < 35: return {"ready": False, "value": None, "status": "캔들 부족"}
    # Compute EMA series for MACD signal roughly by rolling from available closes.
    macd_line=[]
    for i in range(26, len(closes)+1):
        sub=closes[:i]
        e12=_v408_ema(sub, 12); e26=_v408_ema(sub, 26)
        if e12 is not None and e26 is not None: macd_line.append(e12-e26)
    if len(macd_line) < 9: return {"ready": False, "value": None, "status": "신호선 부족"}
    signal=_v408_ema(macd_line, 9)
    if signal is None: return {"ready": False, "value": None, "status": "신호선 부족"}
    hist=macd_line[-1]-signal
    return {"ready": True, "value": round(hist, 6), "status": "양호" if hist>=0 else "약함", "macd": round(macd_line[-1],6), "signal": round(signal,6)}


def _v408_bollinger(closes: List[float], period: int=20) -> Dict[str, Any]:
    if len(closes) < period: return {"ready": False, "value": None, "status": "캔들 부족"}
    arr=closes[-period:]
    ma=sum(arr)/period
    var=sum((x-ma)*(x-ma) for x in arr)/period
    sd=math.sqrt(var)
    upper=ma+2*sd; lower=ma-2*sd
    cur=arr[-1]
    if upper == lower: pos=50.0
    else: pos=(cur-lower)/(upper-lower)*100.0
    return {"ready": True, "value": round(pos,2), "status": "상단부근" if pos>=80 else "하단부근" if pos<=20 else "중간", "ma": round(ma,6), "upper": round(upper,6), "lower": round(lower,6)}


def _v408_enhanced_aux_info(row: Dict[str, Any], of: Dict[str, Any]) -> Dict[str, Dict[str, Any]]:
    aux=_v407_aux_info(row, of)
    closes=_v408_extract_closes(row, of)
    # RSI: prefer supplied values, then compute from closes.
    rsi_val=_v407_num_any(row, of, 'rsi', 'rsi14', 'rsi_14', default=-999.0)
    if rsi_val <= -900:
        calc=_v408_rsi(closes)
        if calc is not None: rsi_val=calc
    aux['rsi']={"key":"rsi","label":"RSI/과열 위치","ready": rsi_val>-900,"status": "과열" if rsi_val>=70 else "침체" if rsi_val<=30 and rsi_val>-900 else "중간" if rsi_val>-900 else "캔들 부족","value": None if rsi_val<=-900 else round(rsi_val,2),"note":"조건 아님. 과열/저점회복 비교용."}
    # MACD: prefer supplied histogram/value, then compute.
    mh=_v407_num_any(row, of, 'macd_hist', 'macd_histogram', 'macd', default=-999.0)
    if mh>-900:
        aux['macd']={"key":"macd","label":"MACD/추세 전환","ready":True,"status":"양호" if mh>=0 else "약함","value":round(mh,6),"note":"조건 아님. 추세 비교용."}
    else:
        m=_v408_macd(closes)
        aux['macd']={"key":"macd","label":"MACD/추세 전환","ready":bool(m.get('ready')),"status":m.get('status'),"value":m.get('value'),"note":"조건 아님. 추세 비교용."}
    # Bollinger
    bb=_v407_num_any(row, of, 'bb_pos', 'bollinger_pos', default=-999.0)
    if bb>-900:
        aux['bollinger']={"key":"bollinger","label":"볼린저밴드 위치","ready":True,"status":"상단부근" if bb>=80 else "하단부근" if bb<=20 else "중간","value":round(bb,2),"note":"조건 아님. 위치 비교용."}
    else:
        b=_v408_bollinger(closes)
        aux['bollinger']={"key":"bollinger","label":"볼린저밴드 위치","ready":bool(b.get('ready')),"status":b.get('status'),"value":b.get('value'),"note":"조건 아님. 위치 비교용."}
    return aux


def _v408_fail_labels(fail: List[Dict[str, Any]]) -> List[str]:
    out=[]
    for x in fail or []:
        if isinstance(x, dict): out.append(str(x.get('label') or x.get('key') or ''))
        else: out.append(str(x))
    return out


def _v408_review_decision(stage: str, fail: List[Dict[str, Any]], missing: List[Dict[str, Any]], required: List[Dict[str, Any]], row: Dict[str, Any], of: Dict[str, Any]) -> Dict[str, str]:
    labels=_v408_fail_labels(fail)
    text=' / '.join(labels)
    pr=_v407_price_reaction(row, of)
    pr_val=fnum(pr.get('value'), default=-999.0) if pr.get('ready') else -999.0
    spread=_v407_num_any(row, of, 'spread_pct', 'micro_spread_pct', 'orderbook_spread_pct', default=-999.0)
    slip=_v407_num_any(row, of, 'slippage_pct', 'expected_slippage_pct', 'estimated_slippage_pct', default=-999.0)
    buy=_v407_num_any(row, of, 'buy_ratio', 'buy_ratio_30s', 'micro_trade_buy_ratio_30', default=-999.0)
    short_bad = any(k in text for k in ['진입 직전 단기반응 부족','단기반응 부족'])
    wall_bad = any(k in text for k in ['매도벽','매도압력'])
    spread_bad = (spread > 0.28) or (slip > 0.28) or any(k in text for k in ['스프레드 부담','예상 미끄러짐 부담'])
    buy_bad = (buy > -900 and buy < 0.62) or any(k in text for k in ['매수체결비 부족','1분 매수지속 부족'])
    major_bad = spread_bad or wall_bad or (buy > -900 and buy < 0.58) or short_bad
    ready = sum(1 for d in required if isinstance(d, dict) and d.get('ready'))
    total = max(1, len(required))
    missing_count = len(missing or [])
    # 아까움: 정보는 거의 다 있고, 위험비용은 낮고, 가격반응만 아주 조금 부족한 쪽.
    if stage != 'S1' and missing_count == 0 and ready >= total-1 and not major_bad and pr_val > -900 and -0.03 <= pr_val < 0.05 and (spread <= 0.22 or spread <= -900) and (slip <= 0.22 or slip <= -900) and (buy >= 0.66 or buy <= -900):
        return {"decision":"✅ 아까운 후보", "reason":"정보는 거의 준비됨 · 비용/체결은 양호 · 가격반응만 조금 부족"}
    if stage != 'S1' and major_bad:
        reasons=[]
        if spread_bad: reasons.append('스프레드/미끄러짐 부담')
        if buy_bad: reasons.append('매수체결 약함')
        if wall_bad: reasons.append('매도벽/매도압력 부담')
        if short_bad: reasons.append('진입 직전 반응 약함')
        return {"decision":"❌ 안 산 게 맞음", "reason":' · '.join(reasons[:3]) or '손실위험이 큼'}
    if stage != 'S1' and missing_count > 0:
        return {"decision":"⚠️ 재확인 후보", "reason":"필요정보 일부가 아직 비어 있음"}
    if stage != 'S1':
        return {"decision":"⚠️ 재확인 후보", "reason":"정보는 있으나 S1 조건에 아직 못 미침"}
    return {"decision":"✅ 실제진입 후보", "reason":"S1 조건 통과"}


def _v408_reseal_strategy_stage() -> Dict[str, Any]:
    feature_obj = load_json(FEATURE, {}) or {}
    feature_map = map_rows(feature_obj)
    ofmap = map_rows(load_json(ORDERFLOW, {}) or {})
    rows = [r for r in read_jsonl(PAPER_LATEST, max_lines=240) if isinstance(r, dict)]
    fixed: List[Dict[str, Any]] = []
    counts = {"S1": 0, "S2": 0, "S3": 0}
    reason_top: Dict[str, int] = {}
    missing_top: Dict[str, int] = {}
    strategy_missing: Dict[str, Dict[str, int]] = {}
    samples: List[Dict[str, Any]] = []
    pr_sources: Dict[str, int] = {}
    aux_ready_top: Dict[str, int] = {}
    aux_missing_top: Dict[str, int] = {}
    decision_top: Dict[str, int] = {}
    decision_by_strategy: Dict[str, Dict[str, int]] = {}
    for ev in rows:
        stage, why, row, of = _v407_stage_policy(ev, feature_map, ofmap)
        skey = str(ev.get("strategy_key") or ev.get("strategy_bucket_primary") or row.get("strategy_key") or "strategy_s")
        fail, missing, required = _v405_fail_details(row, of, skey, stage)
        aux = _v408_enhanced_aux_info(row, of)
        pr = _v407_price_reaction(row, of)
        dec = _v408_review_decision(stage, fail, missing, required, row, of)
        dname = dec.get('decision','❔ 판독대기')
        decision_top[dname] = decision_top.get(dname, 0) + 1
        s_label = V405_STRATEGY_LABELS.get(skey, skey)
        decision_by_strategy.setdefault(s_label, {})[dname] = decision_by_strategy.setdefault(s_label, {}).get(dname, 0) + 1
        pr_sources[str(pr.get("source") or "계산불가")] = pr_sources.get(str(pr.get("source") or "계산불가"), 0) + 1
        for av in aux.values():
            label = str(av.get("label") or av.get("key") or "보조정보")
            if av.get("ready"):
                aux_ready_top[label] = aux_ready_top.get(label, 0) + 1
            else:
                aux_missing_top[label] = aux_missing_top.get(label, 0) + 1
        after = stage if stage in counts else "S3"
        counts[after] += 1
        out = _v403_force_policy_fields(ev, after, why)
        out["stage_policy_schema"] = V408_SCHEMA
        out["stage_policy_note"] = "전략별 S3/S2/S1 단일판정 + 가격반응 보조계산 + 후보 판독 결론 + 보조지표 표시"
        out["price_reaction_pct"] = row.get("price_reaction_pct")
        out["price_reaction_source"] = row.get("price_reaction_source")
        out["price_reaction_note"] = row.get("price_reaction_note")
        out["s1_block_reasons_detail"] = fail
        out["s1_missing_info_detail"] = missing
        out["strategy_required_info"] = required
        out["s1_block_summary"] = _v405_human_summary(fail, missing)
        out["auxiliary_info_status"] = aux
        out["review_decision"] = dname
        out["review_decision_reason"] = dec.get('reason')
        out["easy_status_label"] = "✅ 실제진입" if after == "S1" else ("⚠️ 재확인" if after == "S2" else "❔ 관찰")
        out["strategy_label_easy"] = s_label
        ctx = out.get("entry_context") if isinstance(out.get("entry_context"), dict) else {}
        ctx.update({"price_reaction_pct": row.get("price_reaction_pct"), "price_reaction_source": row.get("price_reaction_source"), "price_reaction_note": row.get("price_reaction_note"), "s1_block_reasons_detail": fail, "s1_missing_info_detail": missing, "strategy_required_info": required, "auxiliary_info_status": aux, "s1_block_summary": out["s1_block_summary"], "stage_policy_schema": V408_SCHEMA, "review_decision": dname, "review_decision_reason": dec.get('reason')})
        out["entry_context"] = ctx
        for x in fail:
            label = str(x.get("label") or x.get("key") or "기타")
            reason_top[label] = reason_top.get(label, 0) + 1
        for x in missing:
            label = str(x.get("label") or x.get("key") or "기타")
            missing_top[label] = missing_top.get(label, 0) + 1
            sm = strategy_missing.setdefault(s_label, {})
            sm[label] = sm.get(label, 0) + 1
        if after != "S1" and len(samples) < 24:
            samples.append({
                "ticker": ticker_norm(out.get("ticker") or out.get("market") or out.get("symbol")),
                "strategy": s_label,
                "strategy_key": skey,
                "stage": after,
                "score": out.get("score"),
                "summary": out.get("s1_block_summary"),
                "missing": missing[:6],
                "fail": fail[:8],
                "required_ready": sum(1 for d in required if d.get("ready")),
                "required_total": len(required),
                "price_reaction": {"value": row.get("price_reaction_pct"), "source": row.get("price_reaction_source"), "note": row.get("price_reaction_note")},
                "auxiliary_info_status": aux,
                "review_decision": dname,
                "review_decision_reason": dec.get('reason'),
            })
        fixed.append(out)
    fixed.sort(key=lambda x: ({"S1": 3, "S2": 2, "S3": 1}.get(str(x.get('s_stage')), 0), fnum(x.get("score"), default=0.0), fnum(x.get("updated_ts"), x.get("created_at"), default=0.0)), reverse=True)
    write_jsonl_atomic(PAPER_LATEST, fixed)
    stats = {"schema": V408_SCHEMA, "stage_counts": counts, "reason_top": reason_top, "missing_info_top": missing_top, "strategy_missing_info": strategy_missing, "samples": samples, "latest_count": len(fixed), "policy": "strategy_direct_only_with_price_reaction_and_decision", "price_reaction_sources": pr_sources, "aux_ready_top": aux_ready_top, "aux_missing_top": aux_missing_top, "decision_top": decision_top, "decision_by_strategy": decision_by_strategy}
    cmap = dict(V403_CONDITION_MAP)
    cmap["version"] = VERSION
    cmap["schema"] = V408_SCHEMA
    cmap["summary"] = "전략별 S3/S2/S1 구조 유지 + 가격반응 보정 + 후보 판독 결론 + 보조지표 표시. 조건 수치는 변경하지 않음."
    cmap["info_labels"] = V405_INFO_LABELS
    cmap["strategy_required_info"] = {V405_STRATEGY_LABELS.get(k,k): [V405_INFO_LABELS.get(x,x) for x in v] for k,v in V405_STRATEGY_REQUIRED.items()}
    cmap["outside_reference_info"] = [{"name": "RSI/과열 위치", "status":"수집/표시", "note":"조건 아님. 과열/저점회복 비교용."}, {"name":"MACD/추세 전환", "status":"수집/표시", "note":"조건 아님. 추세 전환 비교용."}, {"name":"볼린저밴드 위치", "status":"수집/표시", "note":"조건 아님. 위치 비교용."}, {"name":"체결 속도 가속도", "status":"수집/표시", "note":"조건 아님. 매수세 변화 비교용."}, {"name":"호가잔량 변화", "status":"수집/표시", "note":"조건 아님. 벽 변화 비교용."}, {"name":"BTC/전체장 선행 방향", "status":"수집/표시", "note":"조건 아님. 장세 비교용."}]
    cmap["review_decision_policy"] = ["새 S단계가 아님", "아까운 후보=정보/비용은 양호하나 가격반응만 조금 부족", "재확인 후보=정보 일부 또는 조건 일부 재확인 필요", "안 산 게 맞음=스프레드/미끄러짐/체결/매도벽/단기역행 부담"]
    save_json(CONDITION_MAP_FILE, cmap)
    save_json(S1_BLOCK_AUDIT, {"version": VERSION, "updated_ts": now_ts(), "updated_text": now_text(), **stats, "outside_reference_info": cmap["outside_reference_info"], "review_decision_policy": cmap["review_decision_policy"]})
    try:
        h = load_json(HANDOFF, {}) or {}
        h.update({"version": VERSION, "stage_policy_schema": V408_SCHEMA, "v408_stage_counts": counts, "s1_count": counts.get("S1",0), "s2_count": counts.get("S2",0), "s3_count": counts.get("S3",0), "s1_block_audit": stats, "note":"v408: S1/S2/S3는 유지하고, S1 미달 후보에 복기용 판독 결론과 보조지표 상태를 저장."})
        save_json(HANDOFF, h)
    except Exception as exc:
        append_error(ERROR, "v408_handoff_status", exc)
    try:
        sm = load_json(SUMMARY, {}) or {}
        sm.update({"version": VERSION, "main_version": "v2.13.393", "condition_map": cmap, "stage_policy_schema": V408_SCHEMA, "lifecycle_schema": V408_SCHEMA, "lifecycle_stats": stats, "s_stage_counts": counts, "paper_latest_count": len(fixed), "s_count": len(fixed), "s1_block_audit": stats, "price_reaction_sources": pr_sources, "aux_info_status": {"ready": aux_ready_top, "missing": aux_missing_top}, "decision_top": decision_top, "note":"v408: 후보 판독 결론 + 보조지표 표시. 조건 수치는 변경하지 않음."})
        save_json(SUMMARY, sm)
    except Exception as exc:
        append_error(ERROR, "v408_summary_update", exc)
    return stats


def run_once() -> Dict[str, Any]:  # type: ignore[override]
    base = _v379_base_run_once()
    stats = _v408_reseal_strategy_stage()
    try:
        c = stats.get("stage_counts", {}) if isinstance(stats, dict) else {}
        write_status("running", evaluated=int((load_json(SUMMARY, {}) or {}).get("evaluated") or 0), s_count=sum(int(v) for v in c.values()), paper_latest_count=int(stats.get("latest_count", 0) if isinstance(stats, dict) else 0), s1_count=c.get("S1",0), s2_count=c.get("S2",0), s3_count=c.get("S3",0), lifecycle_schema=V408_SCHEMA, stage_policy_schema=V408_SCHEMA, condition_map_version=VERSION, s1_block_audit=stats, last_sec=fnum((base or {}).get("last_sec"), default=0.0))
    except Exception:
        pass
    out = dict(base or {})
    out.update({"s_stage_counts": stats.get("stage_counts", {}) if isinstance(stats, dict) else {}, "lifecycle_stats": stats, "stage_policy_schema": V408_SCHEMA, "condition_map_version": VERSION})
    return out



# =============================================================================
# strategy_worker v0.36 / v431: final status/version route seal
# - 조건 수치/S1/S2/S3 판정은 바꾸지 않는다.
# - 마지막 tail이 SUMMARY의 낡은 evaluated=0으로 상태파일을 덮어쓰던 경로를 제거한다.
# - 실제 run_once 결과와 SUMMARY를 한 번만 동기화해 메인 /health가 eval/target을 같은 원천으로 보게 한다.
# =============================================================================
VERSION = "strategy_worker_v0.46"
MAIN_VERSION = "v2.13.404"
MAIN_DEPLOY_VERSION = "v2.13.404"
MAIN_BOT_VERSION = "수익형 v2.13.404"
V431_SCHEMA = "s123_simple_v440_review_display_seal"

_v431_base_run_once = run_once


def _v431_int(value: Any, default: int = 0) -> int:
    try:
        if value is None or value == "":
            return default
        return int(float(value))
    except Exception:
        return default


def _v431_dict(value: Any) -> Dict[str, Any]:
    return value if isinstance(value, dict) else {}


def _v431_stage_counts(stats: Dict[str, Any], base: Dict[str, Any], summary: Dict[str, Any]) -> Dict[str, int]:
    for src in (stats.get("stage_counts"), base.get("s_stage_counts"), summary.get("s_stage_counts")):
        if isinstance(src, dict):
            return {
                "S1": _v431_int(src.get("S1"), 0),
                "S2": _v431_int(src.get("S2"), 0),
                "S3": _v431_int(src.get("S3"), 0),
            }
    return {"S1": 0, "S2": 0, "S3": 0}



def _v436_top_list(src: Any, limit: int = 5) -> List[Dict[str, Any]]:
    """reason_top/missing_info_top을 단순 리스트로 표준화한다.
    조건 수치는 바꾸지 않고, S1이 안 나오는 이유를 보기 좋게 저장하기 위한 출력 전용 helper다.
    """
    out: List[Dict[str, Any]] = []
    if isinstance(src, dict):
        items = src.items()
        for k, v in items:
            try:
                cnt = int(float(v))
            except Exception:
                cnt = 0
            if str(k):
                out.append({"reason": str(k), "count": cnt})
    elif isinstance(src, list):
        for x in src:
            if isinstance(x, dict):
                r = str(x.get("reason") or x.get("name") or x.get("key") or x.get("label") or "").strip()
                try:
                    cnt = int(float(x.get("count", x.get("n", 0))))
                except Exception:
                    cnt = 0
                if r:
                    out.append({"reason": r, "count": cnt})
    out.sort(key=lambda x: int(x.get("count") or 0), reverse=True)
    return out[:limit]



def _v437_pick_num(row: Dict[str, Any], keys: List[str], default: float = 0.0) -> float:
    ctx = row.get("entry_context") if isinstance(row.get("entry_context"), dict) else {}
    aux = row.get("auxiliary_info_status") if isinstance(row.get("auxiliary_info_status"), dict) else {}
    for k in keys:
        for src in (row, ctx):
            try:
                v = src.get(k)
                if v is not None and v != "":
                    return float(str(v).replace("%", "").replace(",", ""))
            except Exception:
                pass
        av = aux.get(k) if isinstance(aux, dict) else None
        if isinstance(av, dict):
            for vk in ("value", "pct", "ratio", "score"):
                try:
                    v = av.get(vk)
                    if v is not None and v != "":
                        return float(str(v).replace("%", "").replace(",", ""))
                except Exception:
                    pass
    return default


def _v437_short_reason(items: Any, limit: int = 3) -> List[str]:
    out: List[str] = []
    if isinstance(items, list):
        for x in items[:limit]:
            if isinstance(x, dict):
                label = str(x.get("label") or x.get("reason") or x.get("key") or x.get("name") or "").strip()
                val = x.get("value", x.get("pct", x.get("ratio", None)))
                if label and val not in (None, ""):
                    out.append(f"{label} {val}")
                elif label:
                    out.append(label)
            elif x:
                out.append(str(x))
    elif isinstance(items, dict):
        for k, v in list(items.items())[:limit]:
            out.append(f"{k} {v}")
    elif items:
        out.append(str(items))
    return out[:limit]


def _v437_candidate_rank(row: Dict[str, Any]) -> Tuple[int, float, float, float, float]:
    stage = str(row.get("s_stage") or row.get("stage") or "S3").upper()
    stage_rank = {"S1": 3, "S2": 2, "S3": 1}.get(stage, 0)
    decision = str(row.get("review_decision") or row.get("review_decision_reason") or row.get("review") or "")
    decision_bonus = 0.0
    if "재확인" in decision:
        decision_bonus += 0.30
    if "아까운" in decision or "근접" in decision:
        decision_bonus += 0.20
    if "안 산" in decision:
        decision_bonus -= 0.10
    score = _v437_pick_num(row, ["score", "s1_score", "trade_ready_score"], 0.0)
    fail_count = 0.0
    fail = row.get("s1_block_reasons_detail") or row.get("fail") or []
    if isinstance(fail, list):
        fail_count = float(len(fail))
    missing = row.get("s1_missing_info_detail") or row.get("missing") or []
    if isinstance(missing, list):
        fail_count += float(len(missing)) * 0.25
    return (stage_rank, decision_bonus, score, -fail_count, _v437_pick_num(row, ["updated_ts", "created_at", "ts"], 0.0))



def _v439_reason_number(row: Dict[str, Any], labels: List[str], default: float = 0.0) -> float:
    ctx = row.get("entry_context") if isinstance(row.get("entry_context"), dict) else {}
    all_reasons: List[str] = []
    for src in (row.get("s1_block_reasons_detail"), ctx.get("s1_block_reasons_detail"), row.get("fail"), row.get("block_reasons")):
        if isinstance(src, list):
            all_reasons += [str(x) for x in src]
    for reason in all_reasons:
        for label in labels:
            if label in reason:
                m = re.search(r"([-+]?\d+(?:\.\d+)?)\s*%?\s*[><]", reason)
                if m:
                    try: return float(m.group(1))
                    except Exception: pass
    return default

def _v439_has_bad_reason(row: Dict[str, Any], words: List[str]) -> bool:
    ctx = row.get("entry_context") if isinstance(row.get("entry_context"), dict) else {}
    arr: List[str] = []
    for src in (row.get("s1_block_reasons_detail"), ctx.get("s1_block_reasons_detail"), row.get("fail"), row.get("block_reasons")):
        if isinstance(src, list): arr += [str(x) for x in src]
    text = " / ".join(arr)
    return any(w in text for w in words)

def _v439_recheck_hint(row: Dict[str, Any], metrics: Dict[str, float]) -> str:
    stage = str(row.get("s_stage") or row.get("stage") or "").upper()
    strat = str(row.get("strategy_label_easy") or row.get("strategy") or row.get("strategy_key") or "")
    if stage not in ("S2", "S3") or "주도흐름" not in strat:
        return ""
    spread = float(metrics.get("spread_pct") or 0.0); slip = float(metrics.get("slippage_pct") or 0.0)
    buy = float(metrics.get("buy_ratio") or 0.0); react = float(metrics.get("price_reaction_pct") or 0.0)
    if _v439_has_bad_reason(row, ["매도벽", "매도압력", "EMA5 아래", "스프레드 부담 0.30", "미끄러짐 부담 0.30"]):
        return "위험요인 우선 확인"
    if spread <= 0.22 and slip <= 0.22 and (buy >= 0.62 or react >= 0.05):
        return "재확인 승격 후보"
    if spread <= 0.20 and slip <= 0.20:
        return "재확인 관찰 후보"
    return ""


# =============================================================================
# strategy_worker v0.45 / v445: 전략별 차트 구조태그 저장
# - 조건/S1/S2/S3/청산은 변경하지 않는다.
# - 구조태그는 예상·복기·표시용 재료이며, S1 OPEN 차단/승격 조건으로 쓰지 않는다.
# - 구조태그 = 예상, 체결/가격반응 = 확인, 스프레드/미끄러짐/매도압력 = 위험차단.
# =============================================================================
V445_STRUCTURE_SCHEMA = "chart_structure_tags_v447_regime_exit_review"
V445_STRUCTURE_POLICY = {
    "schema": V445_STRUCTURE_SCHEMA,
    "policy": "구조태그와 장세태그는 review/candidate_reason/청산복기 표시와 복기용이다. S1/S2/S3 조건과 청산숫자는 변경하지 않는다.",
    "principle": ["구조태그=예상", "체결/가격반응=확인", "스프레드/미끄러짐/매도압력=위험차단"],
    "groups": {
        "support_resistance": ["저항돌파", "저항돌파후재테스트", "지지전환확인", "돌파후재이탈"],
        "liquidity": ["저점유동성쓸림", "고점유동성쓸림", "쓸림후빠른회복", "쓸림후회복실패", "스탑헌팅의심"],
        "pullback_reaccel": ["얕은눌림", "깊은눌림", "눌림후재가속", "거래량감소후재증가", "돈흐름재유입"],
        "vwap_ema": ["VWAP방어", "VWAP재회복", "VWAP이탈", "EMA방어", "EMA하방이탈", "EMA상단유지"],
        "trend_channel": ["고점저점상승", "추세지속", "채널하단방어", "채널하단이탈", "채널상단과열", "추세끝물"],
        "risk": ["가짜돌파위험", "고점권가격반응약함", "거래량없는돌파", "매도압력부담", "되돌림위험"],
        "risk_reward": ["손익비양호", "손익비보통", "손익비불량", "손절거리과다", "목표거리부족"],
    },
    "strategy_map": {
        "money_reaccel_s": {"good": ["눌림후재가속", "돈흐름재유입", "VWAP방어", "EMA방어"], "risk": ["추세끝물", "거래량없는돌파", "매도압력부담"]},
        "breakout_early_s": {"good": ["저항돌파", "저항돌파후재테스트", "돌파선방어", "거래량감소후재증가"], "risk": ["가짜돌파위험", "고점유동성쓸림", "돌파후재이탈", "거래량없는돌파"]},
        "leader_flow_adaptive_hold_s": {"good": ["얕은눌림", "VWAP방어", "EMA상단유지", "추세지속"], "risk": ["EMA하방이탈", "고점권가격반응약함", "되돌림위험"]},
        "leader_momentum_s": {"good": ["고점저점상승", "추세지속", "채널하단방어"], "risk": ["추세끝물", "채널상단과열", "채널하단이탈"]},
        "sweep_vwap_recovery_s": {"good": ["저점유동성쓸림", "쓸림후빠른회복", "VWAP재회복", "EMA방어"], "risk": ["쓸림후회복실패", "VWAP이탈", "채널하단이탈"]},
        "surge_rebreak_s": {"good": ["급등후눌림", "고점재돌파", "돈흐름재유입"], "risk": ["급등끝물", "설거지의심", "재돌파실패", "고점유동성쓸림"]},
    },
}


def _v445_known_bool(*vals: Any) -> bool:
    for v in vals:
        if isinstance(v, bool):
            if v: return True
        elif isinstance(v, (int, float)):
            if float(v) != 0.0: return True
        elif isinstance(v, str):
            if v.strip().lower() in {"1", "true", "yes", "y", "on", "ok", "확장", "있음"}:
                return True
    return False


def _v445_first(row: Dict[str, Any], of: Dict[str, Any], *keys: str, default: Any=None) -> Any:
    for src in (row, of):
        if not isinstance(src, dict):
            continue
        for k in keys:
            v = src.get(k)
            if v is not None and str(v).strip() not in {"", "-", "None", "nan", "NaN"}:
                return v
    ctx = row.get("entry_context") if isinstance(row.get("entry_context"), dict) else {}
    snap = row.get("entry_snapshot") if isinstance(row.get("entry_snapshot"), dict) else {}
    flat = snap.get("flat") if isinstance(snap.get("flat"), dict) else {}
    for src in (ctx, flat):
        for k in keys:
            v = src.get(k)
            if v is not None and str(v).strip() not in {"", "-", "None", "nan", "NaN"}:
                return v
    return default


def _v445_num(row: Dict[str, Any], of: Dict[str, Any], *keys: str, default: float=0.0) -> float:
    vals = []
    for k in keys:
        vals.append(_v445_first(row, of, k, default=None))
    return fnum(*vals, default=default)


def _v445_add_tag(bucket: Dict[str, List[str]], group: str, tag: str) -> None:
    arr = bucket.setdefault(group, [])
    if tag not in arr:
        arr.append(tag)


def _v445_structure_tags(row: Dict[str, Any], of: Dict[str, Any], skey: str="") -> Dict[str, Any]:
    """차트 구조태그 계산. 표시/복기 전용이며 stage/조건 값을 바꾸지 않는다."""
    r = row if isinstance(row, dict) else {}
    o = of if isinstance(of, dict) else {}
    tags: Dict[str, List[str]] = {}
    risk_tags: List[str] = []
    good_tags: List[str] = []

    ch1_known = _v445_first(r, o, "change_1m", "price_change_1m", default=None) is not None
    ch3_known = _v445_first(r, o, "change_3m", "price_change_3m", "money_flow_3m_pct", "three_min_flow_pct", default=None) is not None
    ch30s = _v445_num(r, o, "change_30s", "price_change_30s", default=0.0)
    ch1 = _v445_num(r, o, "change_1m", "price_change_1m", default=0.0)
    ch3 = _v445_num(r, o, "change_3m", "price_change_3m", "money_flow_3m_pct", "three_min_flow_pct", default=0.0)
    ch5 = _v445_num(r, o, "change_5m", "price_change_5m", "money_flow_5m_pct", "five_min_flow_pct", default=0.0)
    ch15 = _v445_num(r, o, "change_15m", "price_change_15m", default=0.0)
    ch30 = _v445_num(r, o, "change_30m", "price_change_30m", default=0.0)
    vwap = _v445_num(r, o, "vwap_gap_pct", "vwap_gap", "vwap_distance_pct", default=-9.0)
    ema5 = _v445_num(r, o, "ema5_gap_pct", "ema_gap_pct", "ma5_gap_pct", default=-9.0)
    rel = _v445_num(r, o, "relative_strength_pct", "relative_strength", default=0.0)
    day = _v445_num(r, o, "day_pos_pct", "current_close_pos_ratio", "day_position_pct", default=50.0)
    high_gap = _v445_num(r, o, "recent_high_gap_pct", "recent_high_gap", "high_gap_pct", default=-9.0)
    low_reb = _v445_num(r, o, "low_rebound_pct", "low_rebound", "rebound_from_low_pct", default=0.0)
    react = _v445_num(r, o, "price_reaction_pct", "price_recheck_pct", "reaction_pct", default=0.0)
    spread = _v445_num(r, o, "spread_pct", "micro_spread_pct", "orderbook_spread_pct", default=0.0)
    slip = _v445_num(r, o, "expected_slippage_pct", "slippage_pct", "slippage_est_pct", default=0.0)
    buy = _v445_num(r, o, "buy_ratio", "buy_ratio_30s", "micro_trade_buy_ratio_30", default=0.0)
    sustain = _v445_num(r, o, "buy_sustain_1m", "buy_ratio_1m", "micro_buy_ratio_sustain_1m", default=0.0)
    vol = _v445_known_bool(
        _v445_first(r, o, "volume_expanding", default=None),
        _v445_first(r, o, "trade_value_expanding", default=None),
        _v445_first(r, o, "volume_reaccel", default=None),
    )
    breakout = _v445_known_bool(_v445_first(r, o, "breakout_hint", "is_breakout", "box_breakout", default=None)) or (high_gap >= -0.08 and ch3 >= 0.10)
    sweep = _v445_known_bool(_v445_first(r, o, "sweep_reclaim_hint", "low_sweep", "liquidity_sweep", default=None)) or (low_reb >= 0.35 and day <= 55 and vwap >= -0.25)
    sell_pressure = _v445_known_bool(_v445_first(r, o, "sell_pressure", "ask_wall_pressure", "sell_trade_pressure", default=None))

    # 지지/저항
    if breakout:
        _v445_add_tag(tags, "support_resistance", "저항돌파")
    if breakout and -0.25 <= high_gap <= 0.10 and vwap >= -0.12 and ema5 >= -0.18:
        _v445_add_tag(tags, "support_resistance", "저항돌파후재테스트")
    if vwap >= -0.05 and ema5 >= -0.10 and ch3 >= 0.0:
        _v445_add_tag(tags, "support_resistance", "지지전환확인")
    if breakout and (ch3 <= -0.20 or vwap < -0.20):
        _v445_add_tag(tags, "support_resistance", "돌파후재이탈")

    # 유동성 쓸림
    if sweep:
        _v445_add_tag(tags, "liquidity", "저점유동성쓸림")
    if sweep and vwap >= -0.08 and ch3 >= 0.0:
        _v445_add_tag(tags, "liquidity", "쓸림후빠른회복")
    if sweep and (vwap < -0.20 or ch3 <= -0.25):
        _v445_add_tag(tags, "liquidity", "쓸림후회복실패")
    if day >= 90 and high_gap >= -0.08 and (ch1 < 0 or ch3 < 0):
        _v445_add_tag(tags, "liquidity", "고점유동성쓸림")
        _v445_add_tag(tags, "liquidity", "스탑헌팅의심")

    # 눌림/재가속
    if ch15 >= 0.45 and ch30 >= 0.20 and -0.45 <= ch3 <= 0.25 and vwap >= -0.12:
        _v445_add_tag(tags, "pullback_reaccel", "얕은눌림")
    if ch3 <= -0.60 or vwap < -0.35:
        _v445_add_tag(tags, "pullback_reaccel", "깊은눌림")
    if ch3 >= 0.15 and ch5 >= 0.25 and vwap >= -0.10 and ema5 >= -0.15:
        _v445_add_tag(tags, "pullback_reaccel", "눌림후재가속")
    if vol:
        _v445_add_tag(tags, "pullback_reaccel", "거래량감소후재증가")
    if (ch3 >= 0.20 and (vol or ch5 >= 0.35)):
        _v445_add_tag(tags, "pullback_reaccel", "돈흐름재유입")

    # VWAP/EMA
    if vwap >= -0.05:
        _v445_add_tag(tags, "vwap_ema", "VWAP방어")
    if vwap >= 0.0 and (sweep or ch3 >= 0.0):
        _v445_add_tag(tags, "vwap_ema", "VWAP재회복")
    if vwap < -0.25:
        _v445_add_tag(tags, "vwap_ema", "VWAP이탈")
    if ema5 >= -0.08:
        _v445_add_tag(tags, "vwap_ema", "EMA방어")
    if ema5 >= 0.0:
        _v445_add_tag(tags, "vwap_ema", "EMA상단유지")
    if ema5 < -0.30:
        _v445_add_tag(tags, "vwap_ema", "EMA하방이탈")

    # 추세/채널
    if ch15 >= 0.60 and ch30 >= 0.40 and rel >= 0.0:
        _v445_add_tag(tags, "trend_channel", "고점저점상승")
    if ch5 >= 0.35 and ch15 >= 0.60:
        _v445_add_tag(tags, "trend_channel", "추세지속")
    if ch15 >= 0.45 and ch30 >= 0.20 and vwap >= -0.12 and ema5 >= -0.15:
        _v445_add_tag(tags, "trend_channel", "채널하단방어")
    if ch5 < -0.30 and vwap < -0.25 and ema5 < -0.25:
        _v445_add_tag(tags, "trend_channel", "채널하단이탈")
    if day >= 95 and ch15 >= 1.50:
        _v445_add_tag(tags, "trend_channel", "채널상단과열")
    if day >= 98 and ch5 >= 4.0 and rel < 3.0:
        _v445_add_tag(tags, "trend_channel", "추세끝물")

    # 위험 구조
    if breakout and ((ch1_known and ch1 <= 0.0) or (ch3_known and ch3 < 0.0)) and high_gap >= -0.12:
        _v445_add_tag(tags, "risk", "가짜돌파위험")
    if day >= 88 and react < 0.05:
        _v445_add_tag(tags, "risk", "고점권가격반응약함")
    if breakout and not vol and ch3 < 0.15:
        _v445_add_tag(tags, "risk", "거래량없는돌파")
    if sell_pressure:
        _v445_add_tag(tags, "risk", "매도압력부담")
    if ch5 <= -0.60 or ch3 <= -0.50:
        _v445_add_tag(tags, "risk", "되돌림위험")
    if spread >= 0.30:
        _v445_add_tag(tags, "risk", "스프레드부담")
    if slip >= 0.30:
        _v445_add_tag(tags, "risk", "미끄러짐부담")

    # 손익비 표시용. 실제 목표/손절 계산이 아니라 구조·비용 기반 참고 태그다.
    if spread <= 0.18 and slip <= 0.20 and vwap >= -0.12 and ema5 >= -0.15 and day < 95:
        _v445_add_tag(tags, "risk_reward", "손익비양호")
    elif spread >= 0.35 or slip >= 0.35 or day >= 98:
        _v445_add_tag(tags, "risk_reward", "손익비불량")
    else:
        _v445_add_tag(tags, "risk_reward", "손익비보통")

    flat_tags: List[str] = []
    for group in ("support_resistance", "liquidity", "pullback_reaccel", "vwap_ema", "trend_channel", "risk_reward"):
        for tag in tags.get(group, []):
            if tag not in flat_tags:
                flat_tags.append(tag)
    for tag in tags.get("risk", []) + tags.get("liquidity", []) + tags.get("support_resistance", []) + tags.get("trend_channel", []):
        if tag in {"가짜돌파위험", "고점유동성쓸림", "돌파후재이탈", "거래량없는돌파", "매도압력부담", "되돌림위험", "스프레드부담", "미끄러짐부담", "쓸림후회복실패", "VWAP이탈", "EMA하방이탈", "채널하단이탈", "채널상단과열", "추세끝물", "고점권가격반응약함"} and tag not in risk_tags:
            risk_tags.append(tag)
    for tag in flat_tags:
        if tag not in risk_tags and tag not in good_tags:
            good_tags.append(tag)

    smap = V445_STRUCTURE_POLICY["strategy_map"].get(str(skey or ""), {})
    preferred = [t for t in smap.get("good", []) if t in flat_tags]
    strat_risk = [t for t in smap.get("risk", []) if t in risk_tags or t in flat_tags]
    severe_risk = any(t in risk_tags for t in ["스프레드부담", "미끄러짐부담", "매도압력부담", "되돌림위험", "매수체결약함", "가짜돌파위험", "고점유동성쓸림", "돌파후재이탈", "채널하단이탈", "추세끝물"])
    if buy and buy < 0.55 and "매수체결약함" not in risk_tags:
        risk_tags.append("매수체결약함"); severe_risk = True
    if not preferred and not good_tags and not risk_tags:
        fit = "구조관찰"
    elif preferred and not severe_risk and not strat_risk:
        fit = "구조좋음"
    elif preferred and (severe_risk or strat_risk):
        fit = "구조좋음 · 위험동반"
    elif severe_risk or strat_risk:
        fit = "구조위험"
    else:
        fit = "구조관찰"

    summary_good = ", ".join(preferred[:3] or good_tags[:3]) or "-"
    summary_risk = ", ".join(strat_risk[:3] or risk_tags[:3]) or "-"
    return {
        "schema": V445_STRUCTURE_SCHEMA,
        "policy": "review_only_no_stage_change",
        "tags": flat_tags[:16],
        "good_tags": good_tags[:12],
        "risk_tags": risk_tags[:12],
        "groups": tags,
        "strategy_fit": fit,
        "strategy_good_tags": preferred[:8],
        "strategy_risk_tags": strat_risk[:8],
        "summary": f"{fit} · 좋음 {summary_good} / 위험 {summary_risk}",
        "metrics_basis": {"ch1": ch1, "ch3": ch3, "ch5": ch5, "ch15": ch15, "ch30": ch30, "vwap": vwap, "ema5": ema5, "rel": rel, "day": day, "high_gap": high_gap, "low_rebound": low_reb, "spread": spread, "slip": slip, "buy": buy, "sustain": sustain},
    }



def _v447_market_tags(row: Dict[str, Any], of: Dict[str, Any]) -> Dict[str, Any]:
    """장세 태그 계산. 표시/복기 전용이며 stage/조건 값을 바꾸지 않는다."""
    r = row if isinstance(row, dict) else {}
    o = of if isinstance(of, dict) else {}
    tags: List[str] = []
    risks: List[str] = []
    mode_raw = str(_v445_first(r, o, "market_mode", "regime_mode", "market_regime", "market_strength", default="") or "")
    pressure_raw = str(_v445_first(r, o, "market_pressure", "regime_pressure", "market_flow", default="") or "")
    btc3 = _v445_num(r, o, "btc_3m", "btc_change_3m", "btc_5m", default=0.0)
    m3 = _v445_num(r, o, "market_3m", "market_change_3m", "market_avg_3m", default=0.0)
    vol = _v445_num(r, o, "market_volatility", "volatility_pct", "avg_abs_change_3m", default=0.0)
    tv = _v445_num(r, o, "market_trade_value_change_pct", "trade_value_change_pct", "market_money_flow_pct", default=0.0)
    rel = _v445_num(r, o, "relative_strength_pct", "relative_strength", default=0.0)
    text = (mode_raw + " " + pressure_raw).lower()
    def add(arr: List[str], x: str) -> None:
        if x and x not in arr:
            arr.append(x)
    if "강" in mode_raw or "bull" in text or m3 >= 0.25:
        add(tags, "시장강함")
    elif "약" in mode_raw or "bear" in text or m3 <= -0.25 or btc3 <= -0.35:
        add(tags, "시장약함")
    else:
        add(tags, "시장보통")
    if "급락" in mode_raw or "crash" in text or btc3 <= -0.70 or m3 <= -0.60:
        add(risks, "시장급락위험")
    if "과열" in mode_raw or "overheat" in text or (m3 >= 0.70 and vol >= 1.0):
        add(risks, "시장과열")
    if "횡보" in mode_raw or abs(m3) < 0.08:
        add(tags, "시장횡보")
    if tv >= 0.30 or "거래대금증가" in mode_raw or "money" in text:
        add(tags, "전체거래대금증가")
    if "쏠림" in mode_raw or "집중" in mode_raw or rel >= 5.0:
        add(tags, "소수코인쏠림")
    if vol >= 1.0:
        add(tags, "변동성확대")
    elif 0 < vol <= 0.25:
        add(tags, "변동성축소")
    if not tags:
        add(tags, "장세정보부족")
    return {"schema": "market_regime_tags_v447_review_only", "tags": tags[:8], "risk_tags": risks[:6], "summary": (", ".join(tags[:3]) if tags else "-") + (" / 위험 " + ", ".join(risks[:2]) if risks else "")}

def _v445_apply_structure_to_event(ev: Dict[str, Any], feature_map: Dict[str, Dict[str, Any]], ofmap: Dict[str, Dict[str, Any]]) -> Dict[str, Any]:
    out = dict(ev or {})
    t = ticker_norm(out.get("ticker") or out.get("market") or out.get("symbol"))
    try:
        row, of = _v403_merge_from_event(out, feature_map.get(t, {}) if t else {}, ofmap.get(t, {}) if t else {}) if '_v403_merge_from_event' in globals() else (out, ofmap.get(t, {}) if t else {})
        skey = str(out.get("strategy_key") or out.get("strategy_bucket_primary") or row.get("strategy_key") or "")
        st = _v445_structure_tags(row, of, skey)
        mt = _v447_market_tags(row, of)
        out["chart_structure"] = st
        out["structure_tags"] = st.get("tags", [])
        out["structure_good_tags"] = st.get("good_tags", [])
        out["structure_risk_tags"] = st.get("risk_tags", [])
        out["structure_fit"] = st.get("strategy_fit", "구조관찰")
        out["structure_summary"] = st.get("summary", "")
        out["market_regime_tags"] = mt.get("tags", [])
        out["market_risk_tags"] = mt.get("risk_tags", [])
        out["market_regime_summary"] = mt.get("summary", "")
        out["market_regime"] = mt
        ctx = out.get("entry_context") if isinstance(out.get("entry_context"), dict) else {}
        ctx.update({"chart_structure": st, "structure_tags": out["structure_tags"], "structure_risk_tags": out["structure_risk_tags"], "structure_fit": out["structure_fit"], "structure_summary": out["structure_summary"], "market_regime": mt, "market_regime_tags": out["market_regime_tags"], "market_risk_tags": out["market_risk_tags"], "market_regime_summary": out["market_regime_summary"]})
        out["entry_context"] = ctx
        snap = out.get("entry_snapshot") if isinstance(out.get("entry_snapshot"), dict) else None
        if isinstance(snap, dict):
            strat = snap.get("strategy") if isinstance(snap.get("strategy"), dict) else {}
            strat.update({"chart_structure": st, "structure_tags": out["structure_tags"], "structure_risk_tags": out["structure_risk_tags"], "structure_fit": out["structure_fit"]})
            snap["strategy"] = strat
            flat = snap.get("flat") if isinstance(snap.get("flat"), dict) else {}
            flat.update({"structure_tags": out["structure_tags"], "structure_risk_tags": out["structure_risk_tags"], "structure_fit": out["structure_fit"]})
            snap["flat"] = flat
            out["entry_snapshot"] = snap
    except Exception as exc:
        append_error(ERROR, "v445_apply_structure", exc)
    return out


def _v445_stamp_structure_tags() -> Dict[str, Any]:
    feature_map = map_rows(load_json(FEATURE, {}) or {})
    ofmap = map_rows(load_json(ORDERFLOW, {}) or {})
    rows = [r for r in read_jsonl(PAPER_LATEST, max_lines=0) if isinstance(r, dict)]
    fixed: List[Dict[str, Any]] = []
    tag_top: Dict[str, int] = {}
    risk_top: Dict[str, int] = {}
    fit_top: Dict[str, int] = {}
    for ev in rows:
        out = _v445_apply_structure_to_event(ev, feature_map, ofmap)
        fixed.append(out)
        for tag in out.get("structure_tags", []) if isinstance(out.get("structure_tags"), list) else []:
            tag_top[str(tag)] = tag_top.get(str(tag), 0) + 1
        for tag in out.get("structure_risk_tags", []) if isinstance(out.get("structure_risk_tags"), list) else []:
            risk_top[str(tag)] = risk_top.get(str(tag), 0) + 1
        fit = str(out.get("structure_fit") or "보통")
        fit_top[fit] = fit_top.get(fit, 0) + 1
    if fixed:
        write_jsonl_atomic(PAPER_LATEST, fixed)
    stats = {"schema": V445_STRUCTURE_SCHEMA, "latest_count": len(fixed), "tag_top": tag_top, "risk_tag_top": risk_top, "fit_top": fit_top, "policy": "review_only_no_stage_change"}
    try:
        sm = load_json(SUMMARY, {}) or {}
        if isinstance(sm, dict):
            sm["chart_structure_policy"] = V445_STRUCTURE_POLICY
            sm["chart_structure_stats"] = stats
            sm["structure_tag_schema"] = V445_STRUCTURE_SCHEMA
            sm["note"] = str(sm.get("note") or "") + " / v445: 구조태그를 복기·표시 전용으로 저장. 조건/S1/S2/S3/청산 변경 없음."
            save_json(SUMMARY, sm)
    except Exception as exc:
        append_error(ERROR, "v445_summary_structure", exc)
    try:
        cmap = load_json(CONDITION_MAP_FILE, {}) or {}
        if isinstance(cmap, dict):
            cmap["chart_structure_policy"] = V445_STRUCTURE_POLICY
            cmap["structure_tag_schema"] = V445_STRUCTURE_SCHEMA
            cmap["structure_tag_note"] = "구조태그는 예상/복기용이며 S1 조건이 아니다."
            save_json(CONDITION_MAP_FILE, cmap)
    except Exception as exc:
        append_error(ERROR, "v445_condition_map_structure", exc)
    return stats


def _v437_top_candidates(limit: int = 10) -> List[Dict[str, Any]]:
    """후보 생성/저장은 그대로 두고, 화면 표시용 후보만 좋은순 상위 N개로 고른다."""
    rows = [r for r in read_jsonl(PAPER_LATEST, max_lines=0) if isinstance(r, dict)]
    rows.sort(key=_v437_candidate_rank, reverse=True)
    out: List[Dict[str, Any]] = []
    for row in rows[:limit]:
        ctx = row.get("entry_context") if isinstance(row.get("entry_context"), dict) else {}
        stage = str(row.get("s_stage") or row.get("stage") or "S3").upper()
        fail = row.get("s1_block_reasons_detail") or ctx.get("s1_block_reasons_detail") or row.get("fail") or []
        missing = row.get("s1_missing_info_detail") or ctx.get("s1_missing_info_detail") or row.get("missing") or []
        ticker = ticker_norm(row.get("ticker") or row.get("market") or row.get("symbol"))
        price = _v379_price(row) if "_v379_price" in globals() else _v437_pick_num(row, ["current_price", "entry_price", "price", "detected_price"], 0.0)
        metrics = {
            "price_reaction_pct": _v437_pick_num(row, ["price_reaction_pct", "reaction_pct", "price_response_pct"], 0.0),
            "spread_pct": _v437_pick_num(row, ["spread_pct", "orderbook_spread_pct", "micro_spread_pct"], 0.0),
            "slippage_pct": _v437_pick_num(row, ["expected_slippage_pct", "slippage_pct", "est_slippage_pct"], 0.0),
            "buy_ratio": _v437_pick_num(row, ["buy_ratio", "buy_trade_ratio", "micro_buy_ratio"], 0.0),
            "buy_sustain_1m": _v437_pick_num(row, ["buy_sustain_1m", "buy_persist_1m", "buy_continuation_1m"], 0.0),
        }
        rs = _v439_reason_number(row, ["스프레드"], metrics["spread_pct"])
        rsl = _v439_reason_number(row, ["미끄러짐", "슬리피지", "예상"], metrics["slippage_pct"])
        if rs: metrics["spread_pct"] = rs
        if rsl: metrics["slippage_pct"] = rsl
        review_hint = _v439_recheck_hint(row, metrics)
        out.append({
            "ticker": ticker,
            "stage": stage,
            "strategy": str(row.get("strategy_label_easy") or row.get("strategy") or row.get("strategy_key") or "-"),
            "strategy_key": str(row.get("strategy_key") or row.get("strategy") or "-"),
            "score": round(_v437_pick_num(row, ["score", "s1_score", "trade_ready_score"], 0.0), 2),
            "decision": str(row.get("review_decision") or row.get("review_decision_reason") or "-"),
            "review_hint": review_hint,
            "block_reasons": _v437_short_reason(fail, 3),
            "missing_info": _v437_short_reason(missing, 2),
            "snapshot_ts": now_ts(),
            "snapshot_text": now_text(),
            "snapshot_price": price,
            "price": price,
            "metrics": metrics,
            "chart_structure": row.get("chart_structure") or {},
            "structure_tags": row.get("structure_tags") or [],
            "structure_good_tags": row.get("structure_good_tags") or [],
            "structure_risk_tags": row.get("structure_risk_tags") or [],
            "structure_fit": row.get("structure_fit") or "-",
            "structure_summary": row.get("structure_summary") or "",
            "market_regime_tags": row.get("market_regime_tags") or [],
            "market_risk_tags": row.get("market_risk_tags") or [],
            "market_regime_summary": row.get("market_regime_summary") or "",
        })
    return out

def _v436_simple_s123_panel(stats: Dict[str, Any], summary: Dict[str, Any]) -> Dict[str, Any]:
    """S1/S2/S3만 남기고 S1 미발생 원인을 한 화면용으로 요약한다."""
    sc = _v431_stage_counts(stats, {}, summary)
    reason_top = _v436_top_list(stats.get("reason_top"), 5)
    missing_top = _v436_top_list(stats.get("missing_info_top"), 5)
    decision_top = _v436_top_list(stats.get("decision_top"), 5)
    if sc.get("S1", 0) > 0:
        verdict = "S1 있음: paper OPEN 후보가 발생 중"
    elif sc.get("S2", 0) > 0:
        verdict = "S1 없음: S2 재확인 후보는 있으니 S2→S1 막힘 사유 확인"
    elif sc.get("S3", 0) > 0:
        verdict = "S1 없음: S3 관찰 후보만 있음"
    else:
        verdict = "S1/S2/S3 모두 없음: 후보 생성/정보 배관 확인"
    return {
        "schema": "s123_simple_panel_v440",
        "stage_counts": sc,
        "verdict": verdict,
        "reason_top": reason_top,
        "missing_info_top": missing_top,
        "decision_top": decision_top,
        "top_candidates": _v437_top_candidates(10),
        "top_candidate_policy": "후보 생성/저장은 제한하지 않고 /candidate_reason 표시만 좋은순 상위 10개 + /review 자동복기 대상",
        "policy": "S1/S2/S3만 사용. S/A/B 추가 등급 없음. 조건 수치 변경 없음.",
    }

def _v431_sync_outputs(base_result: Dict[str, Any]) -> Tuple[Dict[str, Any], Dict[str, Any]]:
    base = _v431_dict(base_result)
    summary = _v431_dict(load_json(SUMMARY, {}))
    stats = _v431_dict(load_json(S1_BLOCK_AUDIT, {}))
    router = _v431_dict(load_json(TARGET_ROUTER_QUEUE, {}))
    feature_count = len(feature_rows(load_json(FEATURE, {}) or {}))
    router_count = _v431_int(
        router.get("active_target_count"),
        _v431_int(router.get("export_count"), _v431_int(router.get("target_count"), 0)),
    )

    evaluated = _v431_int(base.get("eval"), _v431_int(summary.get("evaluated"), feature_count))
    if evaluated <= 0 and feature_count > 0:
        evaluated = feature_count
    target_count = _v431_int(summary.get("target_count"), _v431_int(base.get("target_count"), router_count))
    if target_count <= 0 and router_count > 0:
        target_count = router_count
    priority_count = _v431_int(base.get("priority_requests"), _v431_int(summary.get("priority_request_count"), 0))
    latest_count = _v431_int(summary.get("paper_latest_count"), _v431_int(base.get("paper_latest"), 0))
    stage_counts = _v431_stage_counts(stats, base, summary)
    simple_panel = _v436_simple_s123_panel(stats, summary)

    if stats:
        stats["version"] = VERSION
        stats["schema"] = V431_SCHEMA
        stats["stage_policy_schema"] = V431_SCHEMA
        stats["main_version"] = MAIN_VERSION
        stats["note"] = "v437: S1/S2/S3만 유지하고 후보 생성은 자르지 않으며 /candidate_reason 표시용 상위 10개 후보만 정렬 저장. 조건/청산숫자 변경 없음."
        stats["s123_simple_panel"] = simple_panel
        save_json(S1_BLOCK_AUDIT, stats)

    summary.update({
        "version": VERSION,
        "main_version": MAIN_VERSION,
        "deploy_version": MAIN_DEPLOY_VERSION,
        "main_bot_version": MAIN_BOT_VERSION,
        "strategy_worker_version": VERSION,
        "stage_policy_schema": V431_SCHEMA,
        "lifecycle_schema": V431_SCHEMA,
        "condition_map_version": VERSION,
        "evaluated": evaluated,
        "target_count": target_count,
        "priority_request_count": priority_count,
        "paper_latest_count": latest_count,
        "s_stage_counts": stage_counts,
        "status_route_schema": V431_SCHEMA,
        "s123_simple_panel": simple_panel,
        "note": "v437: S1/S2/S3만 유지하고 표시용 상위 10개 후보를 저장. 후보 생성/저장 제한과 조건/청산숫자 변경 없음.",
    })
    save_json(SUMMARY, summary)

    try:
        h = _v431_dict(load_json(HANDOFF, {}))
        h.update({
            "version": VERSION,
            "main_version": MAIN_VERSION,
            "deploy_version": MAIN_DEPLOY_VERSION,
            "strategy_worker_version": VERSION,
            "stage_policy_schema": V431_SCHEMA,
            "s1_count": stage_counts.get("S1", 0),
            "s2_count": stage_counts.get("S2", 0),
            "s3_count": stage_counts.get("S3", 0),
            "evaluated": evaluated,
            "target_count": target_count,
            "s123_simple_panel": simple_panel,
            "note": "v437: S1/S2/S3만 유지. 후보 생성은 전체 유지하고 /candidate_reason 표시만 좋은순 상위 10개로 제한하며 S2/S3 자동복기 queue를 저장. 조건/청산숫자 변경 없음.",
        })
        save_json(HANDOFF, h)
    except Exception as exc:
        append_error(ERROR, "v431_handoff_sync", exc)

    try:
        cmap = _v431_dict(load_json(CONDITION_MAP_FILE, {}))
        if cmap:
            cmap["version"] = VERSION
            cmap["main_version"] = MAIN_VERSION
            cmap["schema"] = V431_SCHEMA
            cmap["summary"] = "v439: 후보 판정 조건 유지 + S1/S2/S3 단순판독 + 표시용 상위 후보 10개 + 자동복기 queue"
            save_json(CONDITION_MAP_FILE, cmap)
    except Exception as exc:
        append_error(ERROR, "v431_condition_map_sync", exc)

    return summary, stats


def run_once() -> Dict[str, Any]:  # type: ignore[override]
    base = _v431_base_run_once()
    base_dict = _v431_dict(base)
    structure_stats: Dict[str, Any] = {}
    try:
        structure_stats = _v445_stamp_structure_tags()
    except Exception as exc:
        append_error(ERROR, "v445_stamp_structure_tags", exc)
    try:
        summary, stats = _v431_sync_outputs(base_dict)
        if isinstance(summary, dict):
            summary["chart_structure_stats"] = structure_stats
            summary["structure_tag_schema"] = V445_STRUCTURE_SCHEMA
            save_json(SUMMARY, summary)
        stage_counts = _v431_stage_counts(stats, base_dict, summary)
        evaluated = _v431_int(summary.get("evaluated"), _v431_int(base_dict.get("eval"), 0))
        target_count = _v431_int(summary.get("target_count"), _v431_int(base_dict.get("target_count"), 0))
        latest_count = _v431_int(summary.get("paper_latest_count"), _v431_int(base_dict.get("paper_latest"), 0))
        write_status(
            "running",
            evaluated=evaluated,
            s_count=sum(stage_counts.values()),
            paper_latest_count=latest_count,
            s1_count=stage_counts.get("S1", 0),
            s2_count=stage_counts.get("S2", 0),
            s3_count=stage_counts.get("S3", 0),
            target_count=target_count,
            priority_request_count=_v431_int(summary.get("priority_request_count"), 0),
            router_target_count=summary.get("router_target_count", "-"),
            router_queue_count=summary.get("router_queue_count", "-"),
            router_backlog_count=summary.get("router_backlog_count", "-"),
            lifecycle_schema=V431_SCHEMA,
            stage_policy_schema=V431_SCHEMA,
            condition_map_version=VERSION,
            main_version=MAIN_VERSION,
            deploy_version=MAIN_DEPLOY_VERSION,
            status_route_schema=V431_SCHEMA,
            s123_simple_panel=(summary.get("s123_simple_panel") if isinstance(summary, dict) else {}),
            last_sec=fnum(base_dict.get("last_sec"), default=0.0),
        )
        out = dict(base_dict)
        out.update({
            "eval": evaluated,
            "target_count": target_count,
            "paper_latest": latest_count,
            "s_stage_counts": stage_counts,
            "stage_policy_schema": V431_SCHEMA,
            "condition_map_version": VERSION,
            "lifecycle_stats": stats,
            "structure_tag_schema": V445_STRUCTURE_SCHEMA,
            "market_regime_tag_schema": "market_regime_tags_v447_review_only",
            "chart_structure_stats": structure_stats,
        })
        return out
    except Exception as exc:
        append_error(ERROR, "v431_final_status", exc)
        return base_dict



# v439: 자동 놓친후보 복기 queue 저장
# - 후보 생성/저장 수량은 제한하지 않는다.
# - /candidate_reason에 표시하는 상위 10개 중 S2/S3를 review_worker가 추적할 수 있게 cache로 넘긴다.
def _v438_write_missed_review_queue(summary: Dict[str, Any]) -> None:
    try:
        panel = summary.get("s123_simple_panel") if isinstance(summary.get("s123_simple_panel"), dict) else {}
        candidates = panel.get("top_candidates") if isinstance(panel.get("top_candidates"), list) else []
        if not candidates:
            # v440: 표시 후보가 비면 review queue도 비는 구경로를 막는다.
            # 후보 생성/저장은 건드리지 않고 화면/복기 전달 후보만 paper_latest에서 재구성한다.
            candidates = _v437_top_candidates(10)
        review_candidates: List[Dict[str, Any]] = []
        for c in candidates:
            if not isinstance(c, dict):
                continue
            stage = str(c.get("stage") or "").upper()
            if stage not in ("S2", "S3"):
                continue
            t = ticker_norm(c.get("ticker"))
            if not t:
                continue
            item = dict(c)
            item["ticker"] = t
            item["review_queue_schema"] = "missed_review_queue_v440"
            item["queued_ts"] = now_ts()
            item["queued_text"] = now_text()
            review_candidates.append(item)
        save_json(MISSED_REVIEW_QUEUE, {
            "schema": "missed_review_queue_v440",
            "version": VERSION,
            "main_version": MAIN_VERSION,
            "updated_ts": now_ts(),
            "updated_text": now_text(),
            "policy": "S2/S3 상위 후보 표시분만 review_worker가 추적한다. 후보 생성/저장/전략조건은 변경하지 않는다.",
            "total_display_candidates": len(candidates),
            "review_candidates": review_candidates,
        })
    except Exception as exc:
        append_error(ERROR, "v438_write_missed_review_queue", exc)

_v438_prev_run_once = run_once

def run_once() -> Dict[str, Any]:  # type: ignore[override]
    out = _v438_prev_run_once()
    try:
        sm = load_json(SUMMARY, {}) or {}
        if isinstance(sm, dict):
            sm["review_queue_schema"] = "missed_review_queue_v440"
            sm["review_queue_note"] = "v440: S2/S3 상위 후보를 review_worker 자동복기 queue로 전달. 표시 후보가 비면 paper_latest에서 재구성. 조건/청산숫자 변경 없음."
            _v438_write_missed_review_queue(sm)
            save_json(SUMMARY, sm)
    except Exception as exc:
        append_error(ERROR, "v438_run_once_queue_sync", exc)
    return out



# v450: candidate_reason compact cache 생산 + strategy stale 완화
# - 기본 명령이 후보파일을 직접 뒤지지 않도록 worker가 compact cache를 미리 저장한다.
# - 구조태그 stamping은 최신 후보 파일의 표시/복기 범위만 처리해 strategy worker age가 크게 밀리지 않게 한다.
# - S1/S2/S3 기준, 전략 조건, 청산 조건은 변경하지 않는다.
VERSION = "strategy_worker_v0.47"
CANDIDATE_REASON_COMPACT_CACHE = BASE_DIR / "clean_candidate_reason_compact_cache.json"


def _v450_latest_display_rows(max_rows: int = 240) -> List[Dict[str, Any]]:
    """paper_candidates_latest 표시/복기용 현재 후보를 읽는 worker 전용 경량 경로.
    명령어 handler에서는 이 경로를 타지 않는다.
    """
    try:
        rows = [r for r in read_jsonl(PAPER_LATEST, max_lines=max_rows) if isinstance(r, dict)]
        return rows
    except Exception:
        return []


def _v445_stamp_structure_tags() -> Dict[str, Any]:  # type: ignore[override]
    """v450 override: 최신 후보 표시 범위만 구조태그 보강한다.
    구버전 max_lines=0 전체 파일 순회를 제거해 strategy stale을 줄인다.
    """
    feature_map = map_rows(load_json(FEATURE, {}) or {})
    ofmap = map_rows(load_json(ORDERFLOW, {}) or {})
    rows = _v450_latest_display_rows(240)
    fixed: List[Dict[str, Any]] = []
    tag_top: Dict[str, int] = {}
    risk_top: Dict[str, int] = {}
    fit_top: Dict[str, int] = {}
    for ev in rows:
        out = _v445_apply_structure_to_event(ev, feature_map, ofmap)
        fixed.append(out)
        for tag in out.get("structure_tags", []) if isinstance(out.get("structure_tags"), list) else []:
            tag_top[str(tag)] = tag_top.get(str(tag), 0) + 1
        for tag in out.get("structure_risk_tags", []) if isinstance(out.get("structure_risk_tags"), list) else []:
            risk_top[str(tag)] = risk_top.get(str(tag), 0) + 1
        fit = str(out.get("structure_fit") or "보통")
        fit_top[fit] = fit_top.get(fit, 0) + 1
    if fixed:
        write_jsonl_atomic(PAPER_LATEST, fixed)
    stats = {
        "schema": "chart_structure_tags_v450_display_scope",
        "latest_count": len(fixed),
        "tag_top": tag_top,
        "risk_tag_top": risk_top,
        "fit_top": fit_top,
        "policy": "review_display_only_no_stage_change",
        "read_scope": "paper_candidates_latest max_lines=240 worker-side only",
        "updated_ts": now_ts(),
        "updated_text": now_text(),
    }
    try:
        sm = load_json(SUMMARY, {}) or {}
        if isinstance(sm, dict):
            sm["chart_structure_policy"] = V445_STRUCTURE_POLICY
            sm["chart_structure_stats"] = stats
            sm["structure_tag_schema"] = stats["schema"]
            save_json(SUMMARY, sm)
    except Exception as exc:
        append_error(ERROR, "v450_summary_structure", exc)
    return stats


def _v437_top_candidates(limit: int = 10) -> List[Dict[str, Any]]:  # type: ignore[override]
    """v450 override: candidate_reason용 compact 후보를 worker가 만든다.
    표시용 상위 N개만 저장하며 후보 생성/저장은 자르지 않는다.
    """
    rows = _v450_latest_display_rows(240)
    rows.sort(key=_v437_candidate_rank, reverse=True)
    out: List[Dict[str, Any]] = []
    for row in rows[:max(0, int(limit))]:
        ctx = row.get("entry_context") if isinstance(row.get("entry_context"), dict) else {}
        stage = str(row.get("s_stage") or row.get("stage") or "S3").upper()
        fail = row.get("s1_block_reasons_detail") or ctx.get("s1_block_reasons_detail") or row.get("fail") or []
        missing = row.get("s1_missing_info_detail") or ctx.get("s1_missing_info_detail") or row.get("missing") or []
        ticker = ticker_norm(row.get("ticker") or row.get("market") or row.get("symbol"))
        price = _v379_price(row) if "_v379_price" in globals() else _v437_pick_num(row, ["current_price", "entry_price", "price", "detected_price"], 0.0)
        metrics = {
            "price_reaction_pct": _v437_pick_num(row, ["price_reaction_pct", "reaction_pct", "price_response_pct"], 0.0),
            "spread_pct": _v437_pick_num(row, ["spread_pct", "orderbook_spread_pct", "micro_spread_pct"], 0.0),
            "slippage_pct": _v437_pick_num(row, ["expected_slippage_pct", "slippage_pct", "est_slippage_pct"], 0.0),
            "buy_ratio": _v437_pick_num(row, ["buy_ratio", "buy_trade_ratio", "micro_buy_ratio"], 0.0),
            "buy_sustain_1m": _v437_pick_num(row, ["buy_sustain_1m", "buy_persist_1m", "buy_continuation_1m"], 0.0),
        }
        rs = _v439_reason_number(row, ["스프레드"], metrics["spread_pct"])
        rsl = _v439_reason_number(row, ["미끄러짐", "슬리피지", "예상"], metrics["slippage_pct"])
        if rs: metrics["spread_pct"] = rs
        if rsl: metrics["slippage_pct"] = rsl
        review_hint = _v439_recheck_hint(row, metrics)
        out.append({
            "ticker": ticker,
            "stage": stage,
            "strategy": str(row.get("strategy_label_easy") or row.get("strategy") or row.get("strategy_key") or "-"),
            "strategy_key": str(row.get("strategy_key") or row.get("strategy") or "-"),
            "score": round(_v437_pick_num(row, ["score", "s1_score", "trade_ready_score"], 0.0), 2),
            "decision": str(row.get("review_decision") or row.get("review_decision_reason") or "-"),
            "review_hint": review_hint,
            "block_reasons": _v437_short_reason(fail, 3),
            "missing_info": _v437_short_reason(missing, 2),
            "snapshot_ts": now_ts(),
            "snapshot_text": now_text(),
            "snapshot_price": price,
            "price": price,
            "metrics": metrics,
            "chart_structure": row.get("chart_structure") or {},
            "structure_tags": row.get("structure_tags") or [],
            "structure_good_tags": row.get("structure_good_tags") or [],
            "structure_risk_tags": row.get("structure_risk_tags") or [],
            "structure_fit": row.get("structure_fit") or "-",
            "structure_summary": row.get("structure_summary") or "",
            "market_regime_tags": row.get("market_regime_tags") or [],
            "market_risk_tags": row.get("market_risk_tags") or [],
            "market_regime_summary": row.get("market_regime_summary") or "",
        })
    return out


def _v450_write_candidate_reason_compact(summary: Dict[str, Any], stats: Dict[str, Any]) -> Dict[str, Any]:
    panel = {}
    if isinstance(stats, dict) and isinstance(stats.get("s123_simple_panel"), dict):
        panel = stats.get("s123_simple_panel") or {}
    elif isinstance(summary, dict) and isinstance(summary.get("s123_simple_panel"), dict):
        panel = summary.get("s123_simple_panel") or {}
    rows = panel.get("top_candidates") if isinstance(panel.get("top_candidates"), list) else []
    if not rows:
        rows = _v437_top_candidates(10)
    sc = panel.get("stage_counts") if isinstance(panel.get("stage_counts"), dict) else {}
    if not sc:
        try:
            sc = _v431_stage_counts(stats, {}, summary)
        except Exception:
            sc = {"S1": 0, "S2": 0, "S3": 0}
    obj = {
        "schema": "candidate_reason_compact_cache_v450",
        "version": VERSION,
        "main_version": MAIN_VERSION if "MAIN_VERSION" in globals() else MAIN_DEPLOY_VERSION,
        "updated_ts": now_ts(),
        "updated_text": now_text(),
        "evaluated": summary.get("evaluated") if isinstance(summary, dict) else "-",
        "candidate_count": summary.get("paper_latest_count") if isinstance(summary, dict) else len(rows),
        "stage_counts": sc,
        "reason_top": panel.get("reason_top") if isinstance(panel, dict) else [],
        "missing_info_top": panel.get("missing_info_top") if isinstance(panel, dict) else [],
        "decision_top": panel.get("decision_top") if isinstance(panel, dict) else [],
        "top_candidates": rows[:10],
        "policy": "main /candidate_reason reads this compact cache only. No direct candidate file scan in command handler.",
    }
    save_json(CANDIDATE_REASON_COMPACT_CACHE, obj)
    return obj


_v450_prev_run_once = run_once

def run_once() -> Dict[str, Any]:  # type: ignore[override]
    out = _v450_prev_run_once()
    try:
        summary = load_json(SUMMARY, {}) or {}
        stats = load_json(S1_BLOCK_AUDIT, {}) or {}
        if isinstance(summary, dict) and isinstance(stats, dict):
            cache = _v450_write_candidate_reason_compact(summary, stats)
            summary["candidate_reason_compact_cache_schema"] = cache.get("schema")
            summary["candidate_reason_compact_cache_ts"] = cache.get("updated_ts")
            save_json(SUMMARY, summary)
    except Exception as exc:
        append_error(ERROR, "v450_candidate_reason_compact", exc)
    return out




# =============================================================================
# strategy_worker v0.49: candidate_reason compact producer 단일화
# - v451의 별도 12초 daemon을 제거한다. strategy status/IO와 명령응답에 간섭하지 않게 한다.
# - compact cache는 run_once 본선의 시작/종료 시점에만, 최소 간격을 두고 저장한다.
# - 후보 생성/전략 조건/S1/S2/S3/청산 변경 없음. 명령어 표시용 cache만 생산한다.
# =============================================================================
VERSION = "strategy_worker_v0.49"
CANDIDATE_REASON_COMPACT_CACHE = BASE_DIR / "clean_candidate_reason_compact_cache.json"
_V452_COMPACT_LAST_WRITE_TS = 0.0
_V452_COMPACT_MIN_INTERVAL_SEC = 25.0


def _v452_short_text_list(x: Any, limit: int = 3) -> List[str]:
    out: List[str] = []
    if isinstance(x, list):
        src = x
    elif isinstance(x, str) and x:
        src = [x]
    else:
        src = []
    for item in src:
        if isinstance(item, dict):
            txt = item.get('reason') or item.get('text') or item.get('name') or item.get('label') or ''
        else:
            txt = str(item)
        txt = txt.strip()
        if txt and txt not in out:
            out.append(txt)
        if len(out) >= limit:
            break
    return out


def _v452_pick_num(row: Dict[str, Any], keys: List[str], default: float = 0.0) -> float:
    for k in keys:
        try:
            v = row.get(k)
            if v is not None and v != '':
                return float(v)
        except Exception:
            pass
    ctx = row.get('entry_context') if isinstance(row.get('entry_context'), dict) else {}
    for k in keys:
        try:
            v = ctx.get(k)
            if v is not None and v != '':
                return float(v)
        except Exception:
            pass
    return default


def _v452_candidate_rank(row: Dict[str, Any]) -> float:
    score = _v452_pick_num(row, ['score', 's1_score', 'trade_ready_score'], 0.0)
    stage = str(row.get('s_stage') or row.get('stage') or '').upper()
    return {'S1': 1000.0, 'S2': 500.0, 'S3': 0.0}.get(stage, 0.0) + score


def _v452_list_top(counter: Dict[str, int], limit: int = 8) -> List[Dict[str, Any]]:
    return [{"reason": k, "count": v} for k, v in sorted(counter.items(), key=lambda x: x[1], reverse=True)[:limit]]


def _v452_build_candidate_reason_compact(limit: int = 10, max_rows: int = 160) -> Dict[str, Any]:
    rows = _v450_latest_display_rows(max_rows) if '_v450_latest_display_rows' in globals() else []
    rows = [r for r in rows if isinstance(r, dict)]
    rows.sort(key=_v452_candidate_rank, reverse=True)
    stage_counts = {'S1': 0, 'S2': 0, 'S3': 0}
    reason_ctr: Dict[str, int] = {}
    missing_ctr: Dict[str, int] = {}
    decision_ctr: Dict[str, int] = {}
    top: List[Dict[str, Any]] = []
    for row in rows:
        ctx = row.get('entry_context') if isinstance(row.get('entry_context'), dict) else {}
        stage = str(row.get('s_stage') or row.get('stage') or 'S3').upper()
        if stage not in stage_counts:
            stage = 'S3'
        stage_counts[stage] += 1
        fail = row.get('s1_block_reasons_detail') or ctx.get('s1_block_reasons_detail') or row.get('fail') or row.get('reasons') or []
        miss = row.get('s1_missing_info_detail') or ctx.get('s1_missing_info_detail') or row.get('missing') or []
        decision = str(row.get('review_decision') or row.get('review_decision_reason') or row.get('review_result') or '-')
        if decision and decision != '-':
            decision_ctr[decision] = decision_ctr.get(decision, 0) + 1
        for txt in _v452_short_text_list(fail, 8):
            key = txt.split(' ')[0] if txt else txt
            reason_ctr[key] = reason_ctr.get(key, 0) + 1
        for txt in _v452_short_text_list(miss, 8):
            key = txt.split(':')[0] if txt else txt
            missing_ctr[key] = missing_ctr.get(key, 0) + 1
        if len(top) < limit:
            ticker = ticker_norm(row.get('ticker') or row.get('market') or row.get('symbol'))
            top.append({
                'ticker': ticker,
                'stage': stage,
                'strategy': str(row.get('strategy_label_easy') or row.get('strategy') or row.get('strategy_key') or '-'),
                'strategy_key': str(row.get('strategy_key') or row.get('strategy') or '-'),
                'score': round(_v452_pick_num(row, ['score', 's1_score', 'trade_ready_score'], 0.0), 2),
                'decision': decision,
                'block_reasons': _v452_short_text_list(fail, 3),
                'missing_info': _v452_short_text_list(miss, 2),
                'metrics': {
                    'price_reaction_pct': _v452_pick_num(row, ['price_reaction_pct', 'reaction_pct', 'price_response_pct'], 0.0),
                    'spread_pct': _v452_pick_num(row, ['spread_pct', 'orderbook_spread_pct', 'micro_spread_pct'], 0.0),
                    'slippage_pct': _v452_pick_num(row, ['expected_slippage_pct', 'slippage_pct', 'est_slippage_pct'], 0.0),
                    'buy_ratio': _v452_pick_num(row, ['buy_ratio', 'buy_trade_ratio', 'micro_buy_ratio'], 0.0),
                    'buy_sustain_1m': _v452_pick_num(row, ['buy_sustain_1m', 'buy_persist_1m', 'buy_continuation_1m'], 0.0),
                },
                'structure_tags': row.get('structure_tags') or [],
                'structure_good_tags': row.get('structure_good_tags') or [],
                'structure_risk_tags': row.get('structure_risk_tags') or [],
                'structure_fit': row.get('structure_fit') or row.get('structure_summary') or '-',
                'structure_summary': row.get('structure_summary') or '',
                'market_regime_tags': row.get('market_regime_tags') or [],
                'market_risk_tags': row.get('market_risk_tags') or [],
                'market_regime_summary': row.get('market_regime_summary') or '',
                'snapshot_ts': now_ts(),
                'snapshot_text': now_text(),
            })
    summary = load_json(SUMMARY, {}) or {}
    return {
        'schema': 'candidate_reason_compact_cache_v452',
        'version': VERSION,
        'updated_ts': now_ts(),
        'updated_text': now_text(),
        'evaluated': summary.get('evaluated', '-') if isinstance(summary, dict) else '-',
        'candidate_count': len(rows),
        'stage_counts': stage_counts,
        'reason_top': _v452_list_top(reason_ctr, 10),
        'missing_info_top': _v452_list_top(missing_ctr, 10),
        'decision_top': _v452_list_top(decision_ctr, 10),
        'top_candidates': top,
        'policy': 'v452: compact cache is written only on strategy run_once path. The v451 12s daemon is removed.',
    }


def _v452_write_candidate_reason_compact(reason: str = 'producer', force: bool = False) -> Dict[str, Any]:
    global _V452_COMPACT_LAST_WRITE_TS
    nowv = now_ts()
    if not force and (nowv - _V452_COMPACT_LAST_WRITE_TS) < _V452_COMPACT_MIN_INTERVAL_SEC:
        return load_json(CANDIDATE_REASON_COMPACT_CACHE, {}) or {}
    obj = _v452_build_candidate_reason_compact(10, 160)
    obj['write_reason'] = reason
    save_json(CANDIDATE_REASON_COMPACT_CACHE, obj)
    _V452_COMPACT_LAST_WRITE_TS = nowv
    return obj


_v452_prev_run_once = run_once


def run_once() -> Dict[str, Any]:  # type: ignore[override]
    try:
        _v452_write_candidate_reason_compact('pre_run', force=False)
    except Exception as exc:
        append_error(ERROR, 'v452_compact_pre_run', exc)
    try:
        out = _v452_prev_run_once()
        return out
    finally:
        try:
            _v452_write_candidate_reason_compact('post_run', force=True)
        except Exception as exc:
            append_error(ERROR, 'v452_compact_post_run', exc)


_v452_prev_main = main


def main() -> None:  # type: ignore[override]
    try:
        _v452_write_candidate_reason_compact('boot', force=True)
    except Exception as exc:
        append_error(ERROR, 'v452_compact_boot', exc)
    _v452_prev_main()


# =============================================================================
# strategy_worker v0.50: stale phase/status 단일 표시
# - v0.49의 조건/후보판정/compact cache 생산 방식은 유지한다.
# - strategy age가 밀릴 때 어느 단계에서 멈췄는지 status phase로 남긴다.
# - S1/S2/S3 기준, 전략 조건, 청산 조건, 후보 저장 수량은 변경하지 않는다.
# =============================================================================
VERSION = "strategy_worker_v0.50"
MAIN_VERSION = "v2.13.411"
MAIN_DEPLOY_VERSION = "v2.13.411"
MAIN_BOT_VERSION = "수익형 v2.13.411"


def _v454_stage_counts_for_status(summary: Dict[str, Any], status: Dict[str, Any]) -> Dict[str, int]:
    try:
        sc = summary.get('s_stage_counts') if isinstance(summary.get('s_stage_counts'), dict) else {}
        if not sc and isinstance(summary.get('s123_simple_panel'), dict):
            sc = summary.get('s123_simple_panel', {}).get('stage_counts') or {}
        return {
            'S1': int(fnum(sc.get('S1'), status.get('s1_count'), default=0.0)),
            'S2': int(fnum(sc.get('S2'), status.get('s2_count'), default=0.0)),
            'S3': int(fnum(sc.get('S3'), status.get('s3_count'), default=0.0)),
        }
    except Exception:
        return {'S1': 0, 'S2': 0, 'S3': 0}


def _v454_write_phase(phase: str, note: str = '', started_ts: Optional[float] = None, **extra: Any) -> None:
    try:
        st = load_json(STATUS, {}) or {}
        sm = load_json(SUMMARY, {}) or {}
        if not isinstance(st, dict): st = {}
        if not isinstance(sm, dict): sm = {}
        sc = _v454_stage_counts_for_status(sm, st)
        evaluated = int(fnum(sm.get('evaluated'), st.get('evaluated'), st.get('row_count'), default=0.0))
        latest = int(fnum(sm.get('paper_latest_count'), st.get('paper_latest_count'), st.get('s_count'), default=float(sum(sc.values()))))
        target_count = int(fnum(sm.get('target_count'), st.get('target_count'), default=0.0))
        phase_ts = started_ts or now_ts()
        payload = {
            'phase': phase,
            'last_phase': phase,
            'phase_started_ts': phase_ts,
            'phase_text': now_text(phase_ts),
            'phase_note': note,
            'evaluated': evaluated,
            's_count': sum(sc.values()) or latest,
            'paper_latest_count': latest,
            's1_count': sc.get('S1',0),
            's2_count': sc.get('S2',0),
            's3_count': sc.get('S3',0),
            'target_count': target_count,
            'main_version': MAIN_VERSION,
            'deploy_version': MAIN_DEPLOY_VERSION,
            'status_route_schema': 'strategy_status_v454_phase_trace',
        }
        payload.update(extra)
        write_status('running', **payload)
    except Exception as exc:
        append_error(ERROR, 'v454_write_phase', exc)


_v454_prev_run_once = run_once


def run_once() -> Dict[str, Any]:  # type: ignore[override]
    cycle_ts = now_ts()
    _v454_write_phase('base_run_once', '기존 strategy 본선 실행 중. stale이면 이 구간 병목 확인.', started_ts=cycle_ts)
    try:
        out = _v454_prev_run_once()
    except Exception as exc:
        append_error(ERROR, 'v454_base_run_once', exc)
        _v454_write_phase('error', f'{exc.__class__.__name__}: {exc}', started_ts=cycle_ts)
        raise
    _v454_write_phase('cycle_done', 'strategy 본선 완료', started_ts=cycle_ts, last_sec=round(now_ts()-cycle_ts,3))
    try:
        if isinstance(out, dict):
            out['strategy_phase_schema'] = 'strategy_status_v454_phase_trace'
            out['strategy_worker_version'] = VERSION
    except Exception:
        pass
    return out


_v454_prev_main = main


def main() -> None:  # type: ignore[override]
    _v454_write_phase('boot', 'strategy worker v0.50 boot')
    _v454_prev_main()


# =============================================================================
# strategy_worker v0.51: v370 평가구간 full-read 병목 수술
# - S1/S2/S3 조건값과 전략 판단식은 바꾸지 않는다.
# - v370 본선이 호출하던 paper archive/latest 전체 읽기 경로를 TTL tail 단일 경로로 교체한다.
# - phase는 evaluating_v370 같은 구 표시 대신 strategy_core_s123로 표준화한다.
# =============================================================================
VERSION = "strategy_worker_v0.51"
MAIN_VERSION = "v2.13.412"
MAIN_DEPLOY_VERSION = "v2.13.412"
MAIN_BOT_VERSION = "수익형 v2.13.412"

V455_TAIL_BYTES = int(float(os.getenv("STRATEGY_WORKER_TAIL_BYTES", "2097152")))
V455_LATEST_TAIL_LINES = int(float(os.getenv("STRATEGY_WORKER_LATEST_TAIL_LINES", "800")))


def _v455_tail_lines(path: Path, max_bytes: int = V455_TAIL_BYTES) -> List[str]:
    """큰 jsonl 파일을 전체 read_text 하지 않고 뒤쪽만 읽는다.
    후보 판단 조건이 아니라 archive/TTL 병목 제거용 파일 IO 본선이다.
    """
    try:
        if not path.exists():
            return []
        with path.open('rb') as f:
            f.seek(0, os.SEEK_END)
            size = f.tell()
            start = max(0, size - max_bytes)
            f.seek(start)
            data = f.read()
        text = data.decode('utf-8', errors='ignore')
        lines = text.splitlines()
        if start > 0 and lines:
            # tail 중간에서 시작한 첫 줄은 잘린 json일 수 있으니 버린다.
            lines = lines[1:]
        return lines
    except Exception:
        return []


def _v455_read_jsonl_tail(path: Path, max_lines: int = V455_LATEST_TAIL_LINES, max_bytes: int = V455_TAIL_BYTES) -> List[Dict[str, Any]]:
    lines = _v455_tail_lines(path, max_bytes=max_bytes)
    if max_lines and len(lines) > max_lines:
        lines = lines[-max_lines:]
    out: List[Dict[str, Any]] = []
    for ln in lines:
        try:
            if not ln.strip():
                continue
            o = json.loads(ln)
            if isinstance(o, dict):
                out.append(o)
        except Exception:
            continue
    return out


def _v455_read_fresh_jsonl_by_ttl(path: Path, ttl_sec: float) -> List[Dict[str, Any]]:
    """TTL 후보만 tail에서 읽는다. 구 read_fresh_jsonl_by_ttl의 전체 파일 read_text를 대체한다."""
    nowv = now_ts()
    rows: List[Dict[str, Any]] = []
    for ln in reversed(_v455_tail_lines(path, max_bytes=V455_TAIL_BYTES)):
        try:
            if not ln.strip():
                continue
            o = json.loads(ln)
            if not isinstance(o, dict):
                continue
            exp = fnum(o.get('expires_at'), default=0.0)
            ts = _event_created_ts(o)
            fresh = (exp >= nowv) if exp > 0 else (ts > 0 and (nowv - ts) <= ttl_sec)
            if fresh:
                rows.append(o)
                continue
            if ts > 0 and (nowv - ts) > max(ttl_sec * 3.0, ttl_sec + 60.0):
                break
        except Exception:
            continue
    rows.reverse()
    return rows


# 구 archive TTL reader를 단일 tail reader로 교체한다. 조건/점수 계산에는 영향 없음.
read_fresh_jsonl_by_ttl = _v455_read_fresh_jsonl_by_ttl  # type: ignore[assignment]


def persist_paper_handoff(events: List[Dict[str, Any]], evaluated: int = 0) -> Tuple[List[Dict[str, Any]], int]:  # type: ignore[override]
    """v455: paper_candidates 전체파일 읽기 제거.
    - latest는 최근 tail만 읽고 TTL로 유지한다.
    - archive도 TTL tail만 읽는다.
    - 새 후보/TTL/중복제거/append 정책은 기존과 동일하게 유지한다.
    """
    nowv = now_ts()
    new_rows = [_normalize_paper_event(e) for e in (events or [])]
    old_latest = [_normalize_paper_event(e) for e in _v455_read_jsonl_tail(PAPER_LATEST, max_lines=V455_LATEST_TAIL_LINES)]
    old_archive = [_normalize_paper_event(e) for e in _v455_read_fresh_jsonl_by_ttl(PAPER, CANDIDATE_TTL_SEC)]
    merged: Dict[str, Dict[str, Any]] = {}
    for ev in old_archive + old_latest + new_rows:
        if not _paper_event_fresh(ev, nowv):
            continue
        key = _paper_dedupe_key(ev)
        if not key:
            continue
        prev = merged.get(key)
        if (prev is None) or fnum(ev.get('score'), default=0.0) >= fnum(prev.get('score'), default=0.0) or _event_created_ts(ev) >= _event_created_ts(prev):
            merged[key] = ev
    latest = sorted(merged.values(), key=lambda e: (fnum(e.get('score'), default=0.0), _event_created_ts(e)), reverse=True)
    write_jsonl_atomic(PAPER_LATEST, latest)
    recent_ids = {str(r.get('event_id') or r.get('event_key') or '') for r in _v455_read_jsonl_tail(PAPER, max_lines=800)}
    appended = 0
    for ev in new_rows:
        eid = str(ev.get('event_id') or ev.get('event_key') or '')
        if eid and eid not in recent_ids:
            append_jsonl(PAPER, ev)
            recent_ids.add(eid)
            appended += 1
    save_json(HANDOFF, {
        'version': VERSION,
        'updated_ts': nowv,
        'updated_text': now_text(nowv),
        'evaluated': evaluated,
        'new_s_count': len(new_rows),
        'paper_latest_count': len(latest),
        'archive_appended': appended,
        'latest_tickers': [e.get('ticker') for e in latest[:20]],
        'note': 'v455: archive/latest 전체읽기 제거. TTL tail 단일 경로로 S1/S2/S3 후보 handoff 유지.',
    })
    return latest, appended


def _v437_top_candidates(limit: int = 10) -> List[Dict[str, Any]]:  # type: ignore[override]
    """v455: 표시용 후보도 latest 전체읽기 대신 bounded tail만 사용한다."""
    try:
        rows = _v450_latest_display_rows(240) if '_v450_latest_display_rows' in globals() else _v455_read_jsonl_tail(PAPER_LATEST, max_lines=240)
    except Exception:
        rows = []
    rows = [r for r in rows if isinstance(r, dict)]
    rows.sort(key=_v437_candidate_rank, reverse=True)
    out: List[Dict[str, Any]] = []
    for row in rows[:limit]:
        ctx = row.get('entry_context') if isinstance(row.get('entry_context'), dict) else {}
        stage = str(row.get('s_stage') or row.get('stage') or 'S3').upper()
        fail = row.get('s1_block_reasons_detail') or ctx.get('s1_block_reasons_detail') or row.get('fail') or []
        missing = row.get('s1_missing_info_detail') or ctx.get('s1_missing_info_detail') or row.get('missing') or []
        ticker = ticker_norm(row.get('ticker') or row.get('market') or row.get('symbol'))
        price = _v379_price(row) if '_v379_price' in globals() else _v437_pick_num(row, ['current_price', 'entry_price', 'price', 'detected_price'], 0.0)
        metrics = {
            'price_reaction_pct': _v437_pick_num(row, ['price_reaction_pct', 'reaction_pct', 'price_response_pct'], 0.0),
            'spread_pct': _v437_pick_num(row, ['spread_pct', 'orderbook_spread_pct', 'micro_spread_pct'], 0.0),
            'slippage_pct': _v437_pick_num(row, ['expected_slippage_pct', 'slippage_pct', 'est_slippage_pct'], 0.0),
            'buy_ratio': _v437_pick_num(row, ['buy_ratio', 'buy_trade_ratio', 'micro_buy_ratio'], 0.0),
            'buy_sustain_1m': _v437_pick_num(row, ['buy_sustain_1m', 'buy_persist_1m', 'buy_continuation_1m'], 0.0),
        }
        rs = _v439_reason_number(row, ['스프레드'], metrics['spread_pct'])
        rsl = _v439_reason_number(row, ['미끄러짐', '슬리피지', '예상'], metrics['slippage_pct'])
        if rs: metrics['spread_pct'] = rs
        if rsl: metrics['slippage_pct'] = rsl
        review_hint = _v439_recheck_hint(row, metrics)
        out.append({
            'ticker': ticker,
            'stage': stage,
            'strategy': str(row.get('strategy_label_easy') or row.get('strategy') or row.get('strategy_key') or '-'),
            'strategy_key': str(row.get('strategy_key') or row.get('strategy') or '-'),
            'score': round(_v437_pick_num(row, ['score', 's1_score', 'trade_ready_score'], 0.0), 2),
            'decision': str(row.get('review_decision') or row.get('review_decision_reason') or '-'),
            'review_hint': review_hint,
            'block_reasons': _v437_short_reason(fail, 3),
            'missing_info': _v437_short_reason(missing, 2),
            'snapshot_ts': now_ts(),
            'snapshot_text': now_text(),
            'snapshot_price': price,
            'price': price,
            'metrics': metrics,
            'chart_structure': row.get('chart_structure') or {},
            'structure_tags': row.get('structure_tags') or [],
            'structure_good_tags': row.get('structure_good_tags') or [],
            'structure_risk_tags': row.get('structure_risk_tags') or [],
            'structure_fit': row.get('structure_fit') or '-',
            'structure_summary': row.get('structure_summary') or '',
            'market_regime_tags': row.get('market_regime_tags') or [],
            'market_risk_tags': row.get('market_risk_tags') or [],
            'market_regime_summary': row.get('market_regime_summary') or '',
        })
    return out


_v455_prev_write_status = write_status


def write_status(state: str, **extra: Any) -> None:  # type: ignore[override]
    phase = str(extra.get('phase') or '')
    if phase in ('evaluating', 'evaluating_v367', 'evaluating_v370'):
        extra['legacy_phase'] = phase
        extra['phase'] = 'strategy_core_s123'
        extra.setdefault('phase_note', 'v455: S1/S2/S3 core evaluation. archive full-read path removed.')
        extra.setdefault('phase_started_ts', now_ts())
        extra['status_route_schema'] = 'strategy_status_v455_ttl_tail_surgery'
    return _v455_prev_write_status(state, **extra)


_v455_prev_run_once = _v454_prev_run_once if '_v454_prev_run_once' in globals() else run_once


def run_once() -> Dict[str, Any]:  # type: ignore[override]
    cycle_ts = now_ts()
    _v454_write_phase('strategy_core_s123', 'v455: archive/latest 전체읽기 제거 후 S1/S2/S3 본선 평가', started_ts=cycle_ts)
    try:
        out = _v455_prev_run_once()
    except Exception as exc:
        append_error(ERROR, 'v455_strategy_core_s123', exc)
        _v454_write_phase('error', f'{exc.__class__.__name__}: {exc}', started_ts=cycle_ts)
        raise
    sec = round(now_ts() - cycle_ts, 3)
    _v454_write_phase('cycle_done', 'v455 strategy cycle 완료', started_ts=cycle_ts, last_sec=sec, strategy_worker_version=VERSION)
    try:
        if isinstance(out, dict):
            out['strategy_worker_version'] = VERSION
            out['strategy_io_schema'] = 'strategy_status_v455_ttl_tail_surgery'
            out['last_sec'] = sec
    except Exception:
        pass
    return out


_v455_prev_main = main


def main() -> None:  # type: ignore[override]
    _v454_write_phase('boot', 'strategy worker v0.51 boot / archive full-read path removed')
    _v455_prev_main()


# =============================================================================
# strategy_worker v0.52: S1 생애주기 추적 전용
# - S1/S2/S3 기준, 전략 조건, paper OPEN 조건은 변경하지 않는다.
# - S1이 언제 생겼고, 몇 초 유지됐고, paper가 읽었는지/최종차단됐는지/다음 scan에서 강등됐는지만 기록한다.
# - 후보품질 수정 전 원인 흐름 확인용 cache를 만든다.
# =============================================================================
VERSION = "strategy_worker_v0.52"
MAIN_VERSION = "v2.13.413"
MAIN_DEPLOY_VERSION = "v2.13.413"
MAIN_BOT_VERSION = "수익형 v2.13.413"

S1_LIFECYCLE_TRACE = BASE_DIR / "clean_s1_lifecycle_trace.json"
S1_LIFECYCLE_STATE = BASE_DIR / "clean_s1_lifecycle_state.json"
PAPER_TRACE = BASE_DIR / "paper_bot_candidate_handoff_trace.json"
PAPER_STATUS = BASE_DIR / "paper_bot_status.json"


def _v457_stage_of(ev: Dict[str, Any]) -> str:
    g = str(ev.get('s_stage') or ev.get('candidate_stage') or ev.get('candidate_grade') or ev.get('grade') or ev.get('stage') or '').upper().strip()
    if g == 'S':
        g = 'S1'
    return g if g in {'S1', 'S2', 'S3'} else 'S3'


def _v457_candidate_key(ev: Dict[str, Any]) -> str:
    for k in ('event_id', 'event_key', 'trace_id', 'handoff_id', 'candidate_uid'):
        v = str(ev.get(k) or '').strip()
        if v:
            return v
    t = ticker_norm(ev.get('ticker') or ev.get('market') or ev.get('symbol')) if 'ticker_norm' in globals() else str(ev.get('ticker') or ev.get('market') or ev.get('symbol') or '').upper()
    sk = str(ev.get('strategy_key') or ev.get('strategy') or ev.get('route') or '').strip()
    scan = str(ev.get('scan_id') or ev.get('source_scan_id') or '').strip()
    return '|'.join([t or 'UNKNOWN', sk or '-', scan[-18:] or '-'])


def _v457_short_reasons(ev: Dict[str, Any], limit: int = 6) -> List[str]:
    out: List[str] = []
    ctx = ev.get('entry_context') if isinstance(ev.get('entry_context'), dict) else {}
    for src in (ev, ctx):
        for k in ('s1_block_reasons_detail', 's_stage_reasons', 'block_reasons', 'missing_info', 's1_missing_info_detail', 'paper_final_block_reasons'):
            v = src.get(k) if isinstance(src, dict) else None
            vals = v if isinstance(v, list) else ([v] if v not in (None, '', [], {}) else [])
            for item in vals:
                txt = str(item).strip()
                if txt and txt not in out:
                    out.append(txt)
                    if len(out) >= limit:
                        return out
    return out


def _v457_metrics(ev: Dict[str, Any]) -> Dict[str, Any]:
    ctx = ev.get('entry_context') if isinstance(ev.get('entry_context'), dict) else {}
    def pick(keys: List[str], default: float = 0.0) -> float:
        for src in (ev, ctx):
            if not isinstance(src, dict):
                continue
            for k in keys:
                if k in src and src.get(k) not in (None, ''):
                    return fnum(src.get(k), default=default)
        return default
    return {
        'price_reaction_pct': pick(['price_reaction_pct', 'reaction_pct', 'price_response_pct'], 0.0),
        'spread_pct': pick(['spread_pct', 'orderbook_spread_pct', 'micro_spread_pct'], 0.0),
        'slippage_pct': pick(['expected_slippage_pct', 'slippage_pct', 'est_slippage_pct'], 0.0),
        'buy_ratio': pick(['buy_ratio', 'buy_trade_ratio', 'micro_buy_ratio'], 0.0),
        'buy_sustain_1m': pick(['buy_sustain_1m', 'buy_persist_1m', 'micro_buy_ratio_sustain_1m'], 0.0),
    }


def _v457_paper_trace_index() -> Dict[str, Dict[str, Any]]:
    idx: Dict[str, Dict[str, Any]] = {}
    obj = load_json(PAPER_TRACE, {}) or {}
    rows = obj.get('rows') if isinstance(obj, dict) and isinstance(obj.get('rows'), list) else []
    for r in rows:
        if not isinstance(r, dict):
            continue
        eid = str(r.get('event_id') or r.get('trace_id') or r.get('handoff_id') or '').strip()
        t = ticker_norm(r.get('ticker')) if 'ticker_norm' in globals() else str(r.get('ticker') or '').upper()
        if eid:
            idx[eid] = r
        if t:
            idx['ticker:' + t] = r
    return idx


def _v457_load_s1_state() -> Dict[str, Any]:
    obj = load_json(S1_LIFECYCLE_STATE, {}) or {}
    return obj if isinstance(obj, dict) else {}


def _v457_paper_status_for(ev: Dict[str, Any], idx: Dict[str, Dict[str, Any]]) -> Tuple[str, str, Dict[str, Any]]:
    key = _v457_candidate_key(ev)
    t = ticker_norm(ev.get('ticker') or ev.get('market') or ev.get('symbol')) if 'ticker_norm' in globals() else str(ev.get('ticker') or '').upper()
    r = idx.get(key) or idx.get('ticker:' + t) or {}
    if not isinstance(r, dict) or not r:
        return 'paper_not_seen', '-', {}
    status = str(r.get('status') or '-').strip() or '-'
    reason = str(r.get('reason') or r.get('missing_info') or '-').strip()
    return status, reason, r


def _v457_update_s1_lifecycle_trace() -> Dict[str, Any]:
    nowv = now_ts()
    rows = _v455_read_jsonl_tail(PAPER_LATEST, max_lines=360) if '_v455_read_jsonl_tail' in globals() else read_jsonl(PAPER_LATEST, max_lines=360)
    rows = [r for r in rows if isinstance(r, dict) and _paper_event_fresh(r, nowv)]
    prev_obj = _v457_load_s1_state()
    active = prev_obj.get('active') if isinstance(prev_obj.get('active'), dict) else {}
    paper_idx = _v457_paper_trace_index()
    seen_keys: set[str] = set()
    counts = {'S1': 0, 'S2': 0, 'S3': 0}
    transitions: Dict[str, int] = {}
    recent: List[Dict[str, Any]] = []
    current_s1: List[Dict[str, Any]] = []
    demoted_before_paper: List[Dict[str, Any]] = []
    paper_blocks: List[Dict[str, Any]] = []

    for ev in rows:
        key = _v457_candidate_key(ev)
        seen_keys.add(key)
        t = ticker_norm(ev.get('ticker') or ev.get('market') or ev.get('symbol')) if 'ticker_norm' in globals() else str(ev.get('ticker') or '').upper()
        stage = _v457_stage_of(ev)
        counts[stage] = counts.get(stage, 0) + 1
        rec = active.get(key) if isinstance(active.get(key), dict) else {'candidate_key': key, 'ticker': t, 'first_seen_ts': nowv, 'first_seen_text': now_text(nowv), 's1_seen_count': 0}
        prev_stage = str(rec.get('current_stage') or '').upper()
        if prev_stage and prev_stage != stage:
            tr = f'{prev_stage}->{stage}'
            transitions[tr] = transitions.get(tr, 0) + 1
            rec['last_transition'] = tr
            rec['last_transition_ts'] = nowv
            rec['last_transition_text'] = now_text(nowv)
            if prev_stage == 'S1' and stage != 'S1':
                rec['s1_left_ts'] = nowv
                rec['s1_left_text'] = now_text(nowv)
                rec['s1_left_to'] = stage
                rec['s1_left_reasons'] = _v457_short_reasons(ev, 6)
        rec['ticker'] = t
        rec['previous_stage'] = prev_stage or None
        rec['current_stage'] = stage
        rec['last_seen_ts'] = nowv
        rec['last_seen_text'] = now_text(nowv)
        rec['event_id'] = str(ev.get('event_id') or ev.get('event_key') or '')
        rec['strategy'] = str(ev.get('strategy_label') or ev.get('strategy') or ev.get('strategy_key') or '-')
        rec['score'] = fnum(ev.get('score'), ev.get('leader_score'), default=0.0)
        rec['metrics'] = _v457_metrics(ev)
        rec['block_reasons'] = _v457_short_reasons(ev, 8)
        rec['structure_tags'] = ev.get('structure_tags') if isinstance(ev.get('structure_tags'), list) else []
        rec['structure_risk_tags'] = ev.get('structure_risk_tags') if isinstance(ev.get('structure_risk_tags'), list) else []
        if stage == 'S1':
            if not rec.get('first_s1_ts'):
                rec['first_s1_ts'] = nowv
                rec['first_s1_text'] = now_text(nowv)
                rec['s1_seen_count'] = int(rec.get('s1_seen_count') or 0) + 1
            rec['last_s1_ts'] = nowv
            rec['last_s1_text'] = now_text(nowv)
        first_s1 = fnum(rec.get('first_s1_ts'), default=0.0)
        last_s1 = fnum(rec.get('last_s1_ts'), default=0.0)
        rec['s1_hold_sec'] = round(max(0.0, (nowv if stage == 'S1' else last_s1) - first_s1), 1) if first_s1 else 0.0
        p_status, p_reason, p_row = _v457_paper_status_for(ev, paper_idx)
        rec['paper_status'] = p_status
        rec['paper_reason'] = p_reason
        rec['paper_trace_row'] = {k: p_row.get(k) for k in ('status','reason','updated_at','s_stage','score') if isinstance(p_row, dict) and k in p_row}
        active[key] = rec
        item = {k: rec.get(k) for k in ('candidate_key','ticker','current_stage','previous_stage','last_transition','first_s1_text','last_s1_text','s1_hold_sec','paper_status','paper_reason','strategy','score','block_reasons','metrics')}
        recent.append(item)
        if stage == 'S1':
            current_s1.append(item)
        if rec.get('s1_left_to') and rec.get('paper_status') in ('paper_not_seen', '-', ''):
            demoted_before_paper.append(item)
        if str(rec.get('paper_status') or '') == 'paper_final_block':
            paper_blocks.append(item)

    # Retain only recent lifecycle state. This is candidate trace cache only; paper ledger is untouched.
    ttl = 2 * 86400.0
    active = {k:v for k,v in active.items() if isinstance(v, dict) and (nowv - fnum(v.get('last_seen_ts'), v.get('first_seen_ts'), default=nowv)) <= ttl}
    recent.sort(key=lambda x: (1 if x.get('current_stage') == 'S1' else 0, fnum(active.get(x.get('candidate_key',''), {}).get('last_seen_ts'), default=nowv)), reverse=True)
    out = {
        'schema': 's1_lifecycle_trace_v457',
        'version': VERSION,
        'updated_ts': nowv,
        'updated_text': now_text(nowv),
        'counts': counts,
        'active_count': len(active),
        'current_s1_count': len(current_s1),
        'recent_s1_count': sum(1 for v in active.values() if isinstance(v, dict) and fnum(v.get('last_s1_ts'), default=0.0) > 0 and nowv - fnum(v.get('last_s1_ts'), default=0.0) <= 600),
        'demoted_before_paper_count': len(demoted_before_paper),
        'paper_block_count': len(paper_blocks),
        'transitions': transitions,
        'current_s1': current_s1[:10],
        'demoted_before_paper': demoted_before_paper[:10],
        'paper_blocks': paper_blocks[:10],
        'recent': recent[:30],
        'policy': 'v457: S1/S2/S3 기준 변경 없이 S1 발생/유지/paper읽힘/강등/차단 사유만 추적한다.',
    }
    save_json(S1_LIFECYCLE_STATE, {'schema':'s1_lifecycle_state_v457', 'version':VERSION, 'updated_ts':nowv, 'active':active})
    save_json(S1_LIFECYCLE_TRACE, out)
    try:
        sm = load_json(SUMMARY, {}) or {}
        if isinstance(sm, dict):
            sm['s1_lifecycle_trace'] = {'schema': out['schema'], 'updated_ts': nowv, 'counts': counts, 'current_s1_count': out['current_s1_count'], 'recent_s1_count': out['recent_s1_count'], 'demoted_before_paper_count': out['demoted_before_paper_count'], 'paper_block_count': out['paper_block_count']}
            save_json(SUMMARY, sm)
    except Exception:
        pass
    return out


_v457_prev_run_once = run_once


def run_once() -> Dict[str, Any]:  # type: ignore[override]
    cycle_ts = now_ts()
    _v454_write_phase('strategy_core_s123', 'v457: S1 생애주기 추적 포함, 조건 변경 없음', started_ts=cycle_ts)
    out = _v457_prev_run_once()
    try:
        trace = _v457_update_s1_lifecycle_trace()
        if isinstance(out, dict):
            out['s1_lifecycle_trace'] = {k: trace.get(k) for k in ('schema','counts','current_s1_count','recent_s1_count','demoted_before_paper_count','paper_block_count')}
        _v454_write_phase('cycle_done', 'v457 strategy cycle 완료 · S1 생애주기 추적 저장', started_ts=cycle_ts, last_sec=round(now_ts()-cycle_ts,3), strategy_worker_version=VERSION)
    except Exception as exc:
        append_error(ERROR, 'v457_s1_lifecycle_trace', exc)
    return out


_v457_prev_main = main


def main() -> None:  # type: ignore[override]
    _v454_write_phase('boot', 'strategy worker v0.52 boot / S1 lifecycle trace enabled')
    _v457_prev_main()



# =============================================================================
# strategy_worker v0.53: candidate_reason/S1 lifecycle fresh-source single spine
# - 조건/S1/S2/S3 판정값은 변경하지 않는다.
# - candidate_reason과 S1 lifecycle이 서로 다른 시점/만료 후보를 읽어 S1 수가 불일치하던 문제를 정리한다.
# - 두 출력 모두 paper가 실제로 소비 가능한 fresh handoff 후보만 현재 카운트로 본다.
# - 만료된 S1은 별도 stale_s1_ignored로 표시하고 현재 S1로 세지 않는다.
# =============================================================================
VERSION = "strategy_worker_v0.53"
MAIN_VERSION = "v2.13.415"
MAIN_DEPLOY_VERSION = "v2.13.415"
MAIN_BOT_VERSION = "수익형 v2.13.415"


def _v461_latest_rows_split(max_rows: int = 360) -> Tuple[List[Dict[str, Any]], List[Dict[str, Any]], List[Dict[str, Any]]]:
    """v461 단일 입력 경로.

    candidate_reason과 s1_lifecycle이 같은 fresh 후보집합을 보게 한다.
    원본 handoff 파일은 건드리지 않고 읽기 기준만 통일한다.
    """
    nowv = now_ts()
    try:
        rows = _v450_latest_display_rows(max_rows) if '_v450_latest_display_rows' in globals() else read_jsonl(PAPER_LATEST, max_lines=max_rows)
    except Exception:
        rows = []
    rows = [r for r in rows if isinstance(r, dict)]
    fresh: List[Dict[str, Any]] = []
    stale: List[Dict[str, Any]] = []
    for r in rows:
        try:
            if _paper_event_fresh(r, nowv):
                fresh.append(r)
            else:
                stale.append(r)
        except Exception:
            stale.append(r)
    stale_s1 = [r for r in stale if _v457_stage_of(r) == 'S1'] if '_v457_stage_of' in globals() else []
    return fresh, stale, stale_s1


def _v473_metric_from_row_context(row: Dict[str, Any], ctx: Dict[str, Any], keys: List[str], default: float = 0.0) -> float:
    """v473: candidate_reason도 recheck와 같은 nested/canonical row를 읽는다."""
    try:
        v = _v464_first_num(row, ctx, keys) if '_v464_first_num' in globals() else None
        if v is not None:
            return float(v)
    except Exception:
        pass
    try:
        return _v452_pick_num(row, keys, default)
    except Exception:
        return default


def _v473_candidate_reason_spine(row: Dict[str, Any], nowv: float) -> Dict[str, Any]:
    """v473: /candidate_reason compact가 /recheck와 같은 canonical metric spine을 보게 한다.

    조건을 새로 완화하지 않는다. S2/S3는 가능하면 _v462_recheck_row가 만든
    promotion_block_reasons/metrics를 그대로 쓰고, recheck 관찰 대상에서 빠진 행만
    같은 price/orderflow spine으로 최소 표시값을 계산한다.
    """
    ctx0 = row.get('entry_context') if isinstance(row.get('entry_context'), dict) else {}
    stage = str(row.get('s_stage') or row.get('stage') or 'S3').upper()
    if stage == 'S':
        stage = 'S1'
    if stage not in {'S1', 'S2', 'S3'}:
        stage = 'S3'
    item: Optional[Dict[str, Any]] = None
    if stage in {'S2', 'S3'} and '_v462_recheck_row' in globals():
        try:
            item = _v462_recheck_row(dict(row), nowv)
        except Exception as exc:
            try:
                append_error(ERROR, 'v473_candidate_reason_recheck_spine', exc)
            except Exception:
                pass
            item = None
    if isinstance(item, dict):
        metrics = item.get('metrics') if isinstance(item.get('metrics'), dict) else {}
        info = item.get('info_diagnostics') if isinstance(item.get('info_diagnostics'), dict) else {}
        pr_info = info.get('price_reaction_v470') if isinstance(info.get('price_reaction_v470'), dict) else {}
        return {
            'source': 'recheck_metric_spine_v473',
            'item': item,
            'metrics': {
                'price_reaction_pct': fnum(metrics.get('price_reaction_pct'), default=0.0),
                'price_reaction_source': metrics.get('price_reaction_source') or pr_info.get('source'),
                'price_reaction_method': metrics.get('price_reaction_method') or pr_info.get('method'),
                'spread_pct': fnum(metrics.get('spread_pct'), default=0.0),
                'slippage_pct': fnum(metrics.get('slippage_pct'), default=0.0),
                'buy_ratio': fnum(metrics.get('buy_ratio'), default=0.0),
                'buy_sustain_1m': fnum(metrics.get('buy_sustain_1m'), default=0.0),
            },
            'block_reasons': item.get('promotion_block_reasons') or item.get('measured_deficits') or [],
            'missing_info': item.get('information_deficits') or [],
            'structure_tags': item.get('structure_signal') or row.get('structure_tags') or [],
            'structure_good_tags': item.get('structure_signal') or row.get('structure_good_tags') or [],
            'structure_risk_tags': item.get('risk_tags') or row.get('structure_risk_tags') or [],
            'structure_fit': item.get('structure_fit') or row.get('structure_fit') or row.get('structure_summary') or '-',
            'needed_recovery': item.get('needed_recovery') or [],
            'relative_context': item.get('relative_context') or {},
        }

    # Fallback도 구 0.00 우선 경로로 돌아가지 않고, recheck와 같은 price/orderflow spine만 쓴다.
    ticker = ticker_norm(row.get('ticker') or row.get('market') or row.get('symbol')) if 'ticker_norm' in globals() else str(row.get('ticker') or '').upper()
    try:
        row2, ctx, live_orderflow = _v469_overlay_recheck_orderflow(dict(row), dict(ctx0), ticker)
    except Exception:
        row2, ctx, live_orderflow = dict(row), dict(ctx0), {}
    try:
        pr_info = _v470_recheck_price_reaction(row2, ctx, live_orderflow) if '_v470_recheck_price_reaction' in globals() else {}
    except Exception:
        pr_info = {}
    reaction = fnum(pr_info.get('value'), default=_v473_metric_from_row_context(row2, ctx, ['price_reaction_pct', 'reaction_pct', 'price_response_pct'], 0.0)) if isinstance(pr_info, dict) and pr_info.get('known') else _v473_metric_from_row_context(row2, ctx, ['price_reaction_pct', 'reaction_pct', 'price_response_pct'], 0.0)
    spread = _v473_metric_from_row_context(row2, ctx, ['spread_pct', 'orderbook_spread_pct', 'micro_spread_pct'], 0.0)
    slip = _v473_metric_from_row_context(row2, ctx, ['expected_slippage_pct', 'slippage_pct', 'est_slippage_pct'], 0.0)
    buy = _v473_metric_from_row_context(row2, ctx, ['buy_ratio', 'buy_trade_ratio', 'micro_buy_ratio'], 0.0)
    sustain = _v473_metric_from_row_context(row2, ctx, ['buy_sustain_1m', 'buy_persist_1m', 'buy_continuation_1m', 'buy_ratio_1m'], 0.0)
    fail = row.get('s1_block_reasons_detail') or ctx0.get('s1_block_reasons_detail') or row.get('fail') or row.get('reasons') or []
    miss = row.get('s1_missing_info_detail') or ctx0.get('s1_missing_info_detail') or row.get('missing') or []
    # 표시 착시 방지: canonical 반응이 통과인데 구 block_reason만 남아 있으면 compact 표시에서는 제거한다.
    if reaction >= 0.05:
        fail = [x for x in _v452_short_text_list(fail, 8) if '가격반응' not in str(x) and '단기반응' not in str(x)]
    return {
        'source': 'candidate_reason_price_orderflow_spine_v473',
        'metrics': {
            'price_reaction_pct': reaction,
            'price_reaction_source': pr_info.get('source') if isinstance(pr_info, dict) else None,
            'price_reaction_method': pr_info.get('method') if isinstance(pr_info, dict) else None,
            'spread_pct': spread,
            'slippage_pct': slip,
            'buy_ratio': buy,
            'buy_sustain_1m': sustain,
        },
        'block_reasons': fail,
        'missing_info': miss,
        'structure_tags': row.get('structure_tags') or [],
        'structure_good_tags': row.get('structure_good_tags') or [],
        'structure_risk_tags': row.get('structure_risk_tags') or [],
        'structure_fit': row.get('structure_fit') or row.get('structure_summary') or '-',
        'needed_recovery': [],
        'relative_context': {},
    }


def _v461_build_candidate_reason_compact(limit: int = 10, max_rows: int = 360) -> Dict[str, Any]:
    fresh_rows, stale_rows, stale_s1 = _v461_latest_rows_split(max_rows)
    rows = [r for r in fresh_rows if isinstance(r, dict)]
    rows.sort(key=_v452_candidate_rank, reverse=True)
    nowv = now_ts()
    stage_counts = {'S1': 0, 'S2': 0, 'S3': 0}
    reason_ctr: Dict[str, int] = {}
    missing_ctr: Dict[str, int] = {}
    decision_ctr: Dict[str, int] = {}
    top: List[Dict[str, Any]] = []
    spine_source_ctr: Dict[str, int] = {}
    for row in rows:
        ctx = row.get('entry_context') if isinstance(row.get('entry_context'), dict) else {}
        stage = str(row.get('s_stage') or row.get('stage') or 'S3').upper()
        if stage == 'S':
            stage = 'S1'
        if stage not in stage_counts:
            stage = 'S3'
        stage_counts[stage] += 1
        spine = _v473_candidate_reason_spine(row, nowv)
        spine_src = str(spine.get('source') or '-')
        spine_source_ctr[spine_src] = spine_source_ctr.get(spine_src, 0) + 1
        fail = spine.get('block_reasons') or []
        miss = spine.get('missing_info') or []
        decision = str(row.get('review_decision') or row.get('review_decision_reason') or row.get('review_result') or '-')
        if decision and decision != '-':
            decision_ctr[decision] = decision_ctr.get(decision, 0) + 1
        for txt in _v452_short_text_list(fail, 8):
            key = txt.split(' ')[0] if txt else txt
            reason_ctr[key] = reason_ctr.get(key, 0) + 1
        for txt in _v452_short_text_list(miss, 8):
            key = txt.split(':')[0] if txt else txt
            missing_ctr[key] = missing_ctr.get(key, 0) + 1
        if len(top) < limit:
            ticker = ticker_norm(row.get('ticker') or row.get('market') or row.get('symbol'))
            metrics = spine.get('metrics') if isinstance(spine.get('metrics'), dict) else {}
            top.append({
                'ticker': ticker,
                'stage': stage,
                'strategy': str(row.get('strategy_label_easy') or row.get('strategy') or row.get('strategy_key') or '-'),
                'strategy_key': str(row.get('strategy_key') or row.get('strategy') or '-'),
                'score': round(_v452_pick_num(row, ['score', 's1_score', 'trade_ready_score'], 0.0), 2),
                'decision': decision,
                'block_reasons': _v452_short_text_list(fail, 3),
                'missing_info': _v452_short_text_list(miss, 2),
                'metrics': {
                    'price_reaction_pct': fnum(metrics.get('price_reaction_pct'), default=0.0),
                    'price_reaction_source': metrics.get('price_reaction_source'),
                    'price_reaction_method': metrics.get('price_reaction_method'),
                    'spread_pct': fnum(metrics.get('spread_pct'), default=0.0),
                    'slippage_pct': fnum(metrics.get('slippage_pct'), default=0.0),
                    'buy_ratio': fnum(metrics.get('buy_ratio'), default=0.0),
                    'buy_sustain_1m': fnum(metrics.get('buy_sustain_1m'), default=0.0),
                },
                'metric_spine_source': spine_src,
                'needed_recovery': spine.get('needed_recovery') or [],
                'relative_context': spine.get('relative_context') or {},
                'structure_tags': spine.get('structure_tags') or row.get('structure_tags') or [],
                'structure_good_tags': spine.get('structure_good_tags') or row.get('structure_good_tags') or [],
                'structure_risk_tags': spine.get('structure_risk_tags') or row.get('structure_risk_tags') or [],
                'structure_fit': spine.get('structure_fit') or row.get('structure_fit') or row.get('structure_summary') or '-',
                'structure_summary': row.get('structure_summary') or '',
                'market_regime_tags': row.get('market_regime_tags') or [],
                'market_risk_tags': row.get('market_risk_tags') or [],
                'market_regime_summary': row.get('market_regime_summary') or '',
                'snapshot_ts': nowv,
                'snapshot_text': now_text(nowv),
                'fresh_for_paper': True,
            })
    summary = load_json(SUMMARY, {}) or {}
    return {
        'schema': 'candidate_reason_compact_cache_v473_metric_spine',
        'version': VERSION,
        'updated_ts': now_ts(),
        'updated_text': now_text(),
        'evaluated': summary.get('evaluated', '-') if isinstance(summary, dict) else '-',
        'candidate_count': len(rows),
        'raw_candidate_count': len(fresh_rows) + len(stale_rows),
        'stale_candidate_count': len(stale_rows),
        'stale_s1_ignored_count': len(stale_s1),
        'stage_counts': stage_counts,
        'reason_top': _v452_list_top(reason_ctr, 10),
        'missing_info_top': _v452_list_top(missing_ctr, 10),
        'decision_top': _v452_list_top(decision_ctr, 10),
        'metric_spine_source_top': _v452_list_top(spine_source_ctr, 6),
        'top_candidates': top,
        'policy': 'v473: candidate_reason compact reads the same recheck/canonical metric spine before showing metrics and block reasons. No threshold/exit/auto-buy change.',
    }


def _v452_build_candidate_reason_compact(limit: int = 10, max_rows: int = 160) -> Dict[str, Any]:  # type: ignore[override]
    return _v461_build_candidate_reason_compact(limit=limit, max_rows=max(360, max_rows))


def _v461_decision_index_from_status() -> Dict[str, Dict[str, Any]]:
    idx: Dict[str, Dict[str, Any]] = {}
    st = load_json(PAPER_STATUS, {}) or {}
    if not isinstance(st, dict):
        return idx
    pick = st.get('pick_stats') if isinstance(st.get('pick_stats'), dict) else {}
    rows: List[Dict[str, Any]] = []
    if isinstance(pick.get('recent_s1_decisions'), list):
        rows.extend([r for r in pick.get('recent_s1_decisions') if isinstance(r, dict)])
    for k in ('last_s1_seen', 'last_open_try', 'last_paper_final_block', 'last_skip'):
        if isinstance(pick.get(k), dict):
            rows.append(pick[k])
    updated = fnum(st.get('updated_at'), default=now_ts())
    for r in rows:
        eid = str(r.get('event_id') or r.get('trace_id') or '').strip()
        t = ticker_norm(r.get('ticker')) if 'ticker_norm' in globals() else str(r.get('ticker') or '').upper()
        rr = dict(r)
        rr.setdefault('updated_at', updated)
        rr.setdefault('reason', r.get('reason') or '-')
        rr.setdefault('status', r.get('status') or 'paper_status_decision')
        if eid:
            idx[eid] = rr
        if t:
            idx['ticker:' + t] = rr
    return idx


def _v457_paper_trace_index() -> Dict[str, Dict[str, Any]]:  # type: ignore[override]
    idx: Dict[str, Dict[str, Any]] = {}
    obj = load_json(PAPER_TRACE, {}) or {}
    rows = obj.get('rows') if isinstance(obj, dict) and isinstance(obj.get('rows'), list) else []
    for r in rows:
        if not isinstance(r, dict):
            continue
        eid = str(r.get('event_id') or r.get('trace_id') or r.get('handoff_id') or '').strip()
        t = ticker_norm(r.get('ticker')) if 'ticker_norm' in globals() else str(r.get('ticker') or '').upper()
        if eid:
            idx[eid] = r
        if t:
            idx['ticker:' + t] = r
    # paper_bot v0.137+ status pick_stats has fresher S1/open/final_block decisions than trace rows in short races.
    idx.update(_v461_decision_index_from_status())
    return idx


def _v461_paper_status_for_event(ev: Dict[str, Any], idx: Dict[str, Dict[str, Any]]) -> Tuple[str, str, Dict[str, Any]]:
    key = _v457_candidate_key(ev)
    t = ticker_norm(ev.get('ticker') or ev.get('market') or ev.get('symbol')) if 'ticker_norm' in globals() else str(ev.get('ticker') or '').upper()
    r = idx.get(key) or idx.get('ticker:' + t) or {}
    if isinstance(r, dict) and r:
        status = str(r.get('status') or '-').strip() or '-'
        reason = str(r.get('reason') or r.get('missing_info') or '-').strip()
        return status, reason, r
    st = load_json(PAPER_STATUS, {}) or {}
    p_updated = fnum(st.get('updated_at'), default=0.0) if isinstance(st, dict) else 0.0
    ev_created = event_created_ts(ev) if 'event_created_ts' in globals() else 0.0
    if p_updated and ev_created and p_updated < ev_created:
        return 'paper_waiting_next_cycle', 'paper가 후보 생성 뒤 아직 cycle 안 돎', {}
    return 'paper_not_seen', 'paper trace/status에 후보 없음', {}


def _v457_paper_status_for(ev: Dict[str, Any], idx: Dict[str, Dict[str, Any]]) -> Tuple[str, str, Dict[str, Any]]:  # type: ignore[override]
    return _v461_paper_status_for_event(ev, idx)


def _v457_update_s1_lifecycle_trace() -> Dict[str, Any]:  # type: ignore[override]
    nowv = now_ts()
    fresh_rows, stale_rows, stale_s1 = _v461_latest_rows_split(420)
    rows = [r for r in fresh_rows if isinstance(r, dict)]
    prev_obj = _v457_load_s1_state()
    active = prev_obj.get('active') if isinstance(prev_obj.get('active'), dict) else {}
    paper_idx = _v457_paper_trace_index()
    seen_keys: set[str] = set()
    counts = {'S1': 0, 'S2': 0, 'S3': 0}
    transitions: Dict[str, int] = {}
    recent: List[Dict[str, Any]] = []
    current_s1: List[Dict[str, Any]] = []
    demoted_before_paper: List[Dict[str, Any]] = []
    paper_blocks: List[Dict[str, Any]] = []
    paper_waiting: List[Dict[str, Any]] = []

    for ev in rows:
        key = _v457_candidate_key(ev)
        seen_keys.add(key)
        t = ticker_norm(ev.get('ticker') or ev.get('market') or ev.get('symbol')) if 'ticker_norm' in globals() else str(ev.get('ticker') or '').upper()
        stage = _v457_stage_of(ev)
        counts[stage] = counts.get(stage, 0) + 1
        rec = active.get(key) if isinstance(active.get(key), dict) else {'candidate_key': key, 'ticker': t, 'first_seen_ts': nowv, 'first_seen_text': now_text(nowv), 's1_seen_count': 0}
        prev_stage = str(rec.get('current_stage') or '').upper()
        if prev_stage and prev_stage != stage:
            tr = f'{prev_stage}->{stage}'
            transitions[tr] = transitions.get(tr, 0) + 1
            rec['last_transition'] = tr
            rec['last_transition_ts'] = nowv
            rec['last_transition_text'] = now_text(nowv)
            if prev_stage == 'S1' and stage != 'S1':
                rec['s1_left_ts'] = nowv
                rec['s1_left_text'] = now_text(nowv)
                rec['s1_left_to'] = stage
                rec['s1_left_reasons'] = _v457_short_reasons(ev, 6)
        rec['ticker'] = t
        rec['previous_stage'] = prev_stage or None
        rec['current_stage'] = stage
        rec['last_seen_ts'] = nowv
        rec['last_seen_text'] = now_text(nowv)
        rec['event_id'] = str(ev.get('event_id') or ev.get('event_key') or '')
        rec['strategy'] = str(ev.get('strategy_label') or ev.get('strategy') or ev.get('strategy_key') or '-')
        rec['score'] = fnum(ev.get('score'), ev.get('leader_score'), default=0.0)
        rec['metrics'] = _v457_metrics(ev)
        rec['block_reasons'] = _v457_short_reasons(ev, 8)
        rec['structure_tags'] = ev.get('structure_tags') if isinstance(ev.get('structure_tags'), list) else []
        rec['structure_risk_tags'] = ev.get('structure_risk_tags') if isinstance(ev.get('structure_risk_tags'), list) else []
        if stage == 'S1':
            if not rec.get('first_s1_ts'):
                rec['first_s1_ts'] = nowv
            rec['first_s1_text'] = rec.get('first_s1_text') or now_text(nowv)
            rec['s1_seen_count'] = int(rec.get('s1_seen_count') or 0) + 1
            rec['last_s1_ts'] = nowv
            rec['last_s1_text'] = now_text(nowv)
        first_s1 = fnum(rec.get('first_s1_ts'), default=0.0)
        last_s1 = fnum(rec.get('last_s1_ts'), default=0.0)
        rec['s1_hold_sec'] = round(max(0.0, (nowv if stage == 'S1' else last_s1) - first_s1), 1) if first_s1 else 0.0
        p_status, p_reason, p_row = _v457_paper_status_for(ev, paper_idx)
        rec['paper_status'] = p_status
        rec['paper_reason'] = p_reason
        rec['paper_trace_row'] = {k: p_row.get(k) for k in ('status','reason','updated_at','s_stage','score') if isinstance(p_row, dict) and k in p_row}
        active[key] = rec
        item = {k: rec.get(k) for k in ('candidate_key','ticker','current_stage','previous_stage','last_transition','first_s1_text','last_s1_text','s1_hold_sec','paper_status','paper_reason','strategy','score','block_reasons','metrics')}
        recent.append(item)
        if stage == 'S1':
            current_s1.append(item)
            if p_status == 'paper_waiting_next_cycle':
                paper_waiting.append(item)
        if rec.get('s1_left_to') and rec.get('paper_status') in ('paper_not_seen', 'paper_waiting_next_cycle', '-', ''):
            demoted_before_paper.append(item)
        if str(rec.get('paper_status') or '') == 'paper_final_block':
            paper_blocks.append(item)

    ttl = 2 * 86400.0
    active = {k:v for k,v in active.items() if isinstance(v, dict) and (nowv - fnum(v.get('last_seen_ts'), v.get('first_seen_ts'), default=nowv)) <= ttl}
    recent.sort(key=lambda x: (1 if x.get('current_stage') == 'S1' else 0, fnum(active.get(x.get('candidate_key',''), {}).get('last_seen_ts'), default=nowv)), reverse=True)
    out = {
        'schema': 's1_lifecycle_trace_v461_fresh_spine',
        'version': VERSION,
        'updated_ts': nowv,
        'updated_text': now_text(nowv),
        'source_policy': 'fresh paper-eligible handoff rows only; same source as candidate_reason compact cache',
        'counts': counts,
        'raw_candidate_count': len(fresh_rows) + len(stale_rows),
        'fresh_candidate_count': len(fresh_rows),
        'stale_candidate_count': len(stale_rows),
        'stale_s1_ignored_count': len(stale_s1),
        'active_count': len(active),
        'current_s1_count': len(current_s1),
        'recent_s1_count': sum(1 for v in active.values() if isinstance(v, dict) and fnum(v.get('last_s1_ts'), default=0.0) > 0 and nowv - fnum(v.get('last_s1_ts'), default=0.0) <= 600),
        'demoted_before_paper_count': len(demoted_before_paper),
        'paper_block_count': len(paper_blocks),
        'paper_waiting_count': len(paper_waiting),
        'transitions': transitions,
        'current_s1': current_s1[:10],
        'demoted_before_paper': demoted_before_paper[:10],
        'paper_blocks': paper_blocks[:10],
        'paper_waiting': paper_waiting[:10],
        'stale_s1_ignored': [candidate_brief(r, status='stale_s1_ignored') if 'candidate_brief' in globals() else {'ticker': ticker_norm(r.get('ticker')) if 'ticker_norm' in globals() else r.get('ticker')} for r in stale_s1[:10]],
        'recent': recent[:30],
        'policy': 'v461: 후보 조건 변경 없이 candidate_reason/S1 lifecycle 현재 집계를 fresh paper-eligible 후보로 단일화한다.',
    }
    save_json(S1_LIFECYCLE_STATE, {'schema':'s1_lifecycle_state_v461', 'version':VERSION, 'updated_ts':nowv, 'active':active})
    save_json(S1_LIFECYCLE_TRACE, out)
    try:
        sm = load_json(SUMMARY, {}) or {}
        if isinstance(sm, dict):
            sm['s1_lifecycle_trace'] = {'schema': out['schema'], 'updated_ts': nowv, 'counts': counts, 'current_s1_count': out['current_s1_count'], 'recent_s1_count': out['recent_s1_count'], 'demoted_before_paper_count': out['demoted_before_paper_count'], 'paper_block_count': out['paper_block_count'], 'stale_s1_ignored_count': out['stale_s1_ignored_count']}
            save_json(SUMMARY, sm)
    except Exception:
        pass
    return out

# v461: keep existing run_once chain, but new compact/lifecycle functions are used by that chain.


# =============================================================================
# strategy_worker v0.63 / main v471: recheck price reaction diagnostic spine + S1 lifecycle closed-reference
# - S1/S2/S3 기준값, 전략조건, 청산조건을 변경하지 않는다.
# - S2/S3를 paper OPEN으로 보내지 않는다.
# - 좋은 구조를 가진 S2/S3를 "재확인 후보"로만 추적한다.
# - 구조 태그는 예상/준비 신호, 가격반응/체결은 확인 신호, 스프레드/압력은 위험 차단으로 분리한다.
# =============================================================================
VERSION = "strategy_worker_v0.70"
MAIN_VERSION = "v2.13.422"
MAIN_DEPLOY_VERSION = "v2.13.422"
MAIN_BOT_VERSION = "수익형 v2.13.422"
RECHECK_CACHE = BASE_DIR / "clean_recheck_candidates_cache.json"
RECHECK_STATE = BASE_DIR / "clean_recheck_candidates_state.json"

_RECHECK_GOOD_STRUCTURE_TAGS = {
    "저점유동성쓸림", "쓸림후빠른회복", "저항돌파후재테스트", "지지전환확인", "박스상단돌파",
    "VWAP재회복", "VWAP방어", "EMA방어", "EMA상단유지", "얕은눌림", "깊은눌림",
    "눌림후재가속", "돈흐름재유입", "거래량감소후재증가", "손익비양호", "손익비보통",
}
_RECHECK_HARD_RISK_TAGS = {
    "가짜돌파위험", "스프레드부담", "미끄러짐부담", "매도압력부담", "매수체결약함", "되돌림위험", "채널상단과열",
}


def _v462_as_list(v: Any) -> List[str]:
    if isinstance(v, list):
        return [str(x).strip() for x in v if str(x).strip()]
    if isinstance(v, tuple):
        return [str(x).strip() for x in v if str(x).strip()]
    if isinstance(v, str) and v.strip():
        # comma/slash separated strings appear in some legacy rows.
        raw = v.replace("/", ",").split(",")
        return [x.strip() for x in raw if x.strip()]
    return []




# v468: 정보부족과 실측부족을 분리하기 위한 진단 캐시.
# - 정보가 없을 때 0으로 보정하지 않는다.
# - target 포함/미포함, micro stale, orderflow key 누락, baseline 히스토리 부족을 분리 표시한다.
_V468_DIAG_CACHE: Dict[str, Any] = {"ts": 0.0, "orderflow": {}, "queue": {}, "micro_targets": set(), "active_targets": set(), "urgent_targets": set()}

def _v468_diag_sources() -> Dict[str, Any]:
    global _V468_DIAG_CACHE
    ts = now_ts()
    try:
        if ts - float(_V468_DIAG_CACHE.get("ts") or 0.0) <= 1.0:
            return _V468_DIAG_CACHE
    except Exception:
        pass
    try:
        ofmap = map_rows(load_json(ORDERFLOW, {}) or {})
    except Exception:
        ofmap = {}
    try:
        q = load_json(TARGET_ROUTER_QUEUE, {}) or {}
    except Exception:
        q = {}
    try:
        mt = load_json(MICRO_TARGETS, {}) or {}
    except Exception:
        mt = {}
    try:
        mu = load_json(MICRO_URGENT, {}) or {}
    except Exception:
        mu = {}
    active_targets = set(str(x).upper() for x in (q.get("active_targets") or q.get("targets") or []) if str(x).strip()) if isinstance(q, dict) else set()
    micro_targets = set(str(x).upper() for x in (mt.get("targets") or []) if str(x).strip()) if isinstance(mt, dict) else set()
    urgent_targets = set(str(x).upper() for x in (mu.get("targets") or []) if str(x).strip()) if isinstance(mu, dict) else set()
    _V468_DIAG_CACHE = {"ts": ts, "orderflow": ofmap, "queue": q if isinstance(q, dict) else {}, "micro_targets": micro_targets, "active_targets": active_targets, "urgent_targets": urgent_targets}
    return _V468_DIAG_CACHE

def _v468_metric_known(row: Dict[str, Any], ctx: Dict[str, Any], keys: List[str]) -> bool:
    try:
        return _v464_first_num(row, ctx, keys) is not None
    except Exception:
        for obj in (row, ctx):
            if not isinstance(obj, dict):
                continue
            for k in keys:
                if obj.get(k) not in (None, ""):
                    return True
    return False

def _v468_orderflow_diag(ticker: str) -> Dict[str, Any]:
    src = _v468_diag_sources()
    t = str(ticker or "").upper()
    ofmap = src.get("orderflow") if isinstance(src.get("orderflow"), dict) else {}
    of = ofmap.get(t) if isinstance(ofmap, dict) else None
    active = t in (src.get("active_targets") or set())
    micro_target = t in (src.get("micro_targets") or set())
    urgent = t in (src.get("urgent_targets") or set())
    missing: List[str] = []
    if not active:
        missing.append("target 미포함")
    if not micro_target:
        missing.append("micro target 미포함")
    if not isinstance(of, dict):
        missing.append("orderflow key 없음")
        return {"target_active": active, "micro_target": micro_target, "urgent_target": urgent, "orderflow_key": False, "micro_fresh": False, "quote_fresh": False, "micro_age_sec": None, "quote_age_sec": None, "missing": missing}
    micro_fresh = bool(of.get("micro_fresh"))
    quote_fresh = bool(of.get("quote_fresh") or of.get("ws_fresh"))
    if not micro_fresh:
        missing.append("micro stale")
    if not quote_fresh:
        missing.append("quote/ws stale")
    return {"target_active": active, "micro_target": micro_target, "urgent_target": urgent, "orderflow_key": True, "micro_fresh": micro_fresh, "quote_fresh": quote_fresh, "micro_age_sec": of.get("micro_age_sec"), "quote_age_sec": of.get("quote_age_sec"), "missing": missing[:8]}


# v469: recheck 판단 직전 최신 orderflow canonical row를 같은 row/context에 붙인다.
# - 값이 없으면 0으로 꾸미지 않는다.
# - fresh orderflow가 만든 canonical key만 사용한다.
# - 기존 후보 row의 실측값은 우선 보존하고, 비어 있는 key만 채운다.
def _v469_live_orderflow_row(ticker: str) -> Dict[str, Any]:
    try:
        src = _v468_diag_sources()
        ofmap = src.get("orderflow") if isinstance(src.get("orderflow"), dict) else {}
        of = ofmap.get(str(ticker or "").upper()) if isinstance(ofmap, dict) else None
        return dict(of) if isinstance(of, dict) else {}
    except Exception:
        return {}

def _v469_has_value(obj: Any, key: str) -> bool:
    return isinstance(obj, dict) and obj.get(key) not in (None, "")

def _v469_first_from_orderflow(of: Dict[str, Any], keys: List[str]) -> Optional[float]:
    if not isinstance(of, dict):
        return None
    for k in keys:
        v = of.get(k)
        if v in (None, ""):
            continue
        try:
            return float(str(v).replace(",", "").replace("%", ""))
        except Exception:
            continue
    return None

def _v469_overlay_recheck_orderflow(row: Dict[str, Any], ctx: Dict[str, Any], ticker: str) -> tuple[Dict[str, Any], Dict[str, Any], Dict[str, Any]]:
    of = _v469_live_orderflow_row(ticker)
    if not of:
        return row, ctx, {}
    row2 = dict(row)
    ctx2 = dict(ctx) if isinstance(ctx, dict) else {}
    # nested context에도 남겨 _v464_first_num/상대기준이 같은 canonical source를 읽게 한다.
    ctx2["orderflow"] = dict(of)
    ctx2["orderflow_summary"] = dict(of)
    ctx2["micro_summary"] = dict(of)
    # micro fresh일 때만 micro 실측 canonical 값을 overlay한다. stale 값을 실측처럼 쓰지 않는다.
    if bool(of.get("micro_fresh")):
        canonical = {
            "buy_ratio": ["buy_ratio", "buy_trade_ratio", "micro_buy_ratio"],
            "buy_sustain_1m": ["buy_sustain_1m", "buy_ratio_1m", "buy_ratio_60", "micro_buy_ratio_sustain_1m", "buy_ratio_sustain"],
            "spread_pct": ["spread_pct", "orderbook_spread_pct", "micro_spread_pct"],
            "expected_slippage_pct": ["expected_slippage_pct", "slippage_est_pct", "slippage_pct", "tick_pct_est"],
            "ask_wall_ratio": ["ask_wall_ratio", "micro_ask_wall_ratio"],
        }
        for target_key, source_keys in canonical.items():
            if not _v469_has_value(row2, target_key) and not _v469_has_value(ctx2, target_key):
                val = _v469_first_from_orderflow(of, source_keys)
                if val is not None:
                    row2[target_key] = val
                    ctx2[target_key] = val
    # quote fresh 값은 가격반응 계산에는 쓰지 않고, 신선도/진단 근거로만 남긴다.
    row2["orderflow_overlay_v469"] = {
        "applied": True,
        "micro_fresh": bool(of.get("micro_fresh")),
        "quote_fresh": bool(of.get("quote_fresh") or of.get("ws_fresh")),
        "micro_age_sec": of.get("micro_age_sec"),
        "quote_age_sec": of.get("quote_age_sec"),
        "source_schema": of.get("schema"),
    }
    return row2, ctx2, of

def _v469_recheck_tracking_key(row: Dict[str, Any], item: Dict[str, Any]) -> str:
    # v469: baseline/state 샘플은 event_id가 아니라 ticker+strategy 기준으로 이어 붙인다.
    # candidate_key는 paper_latest 매칭용으로 그대로 보존한다.
    t = str(item.get("ticker") or row.get("ticker") or row.get("symbol") or "").upper().strip()
    sk = str(item.get("strategy_key") or row.get("strategy_key") or row.get("strategy") or "-").strip()
    if not t:
        return str(item.get("candidate_key") or "")
    return f"recheck:{t}:{sk}"


# v470: recheck 가격반응은 한 좁은 key만 보지 않는다.
# - 명시 price_reaction 계열이 있으면 우선 사용한다.
# - 없으면 기존 strategy 본선에서 이미 쓰던 price_recheck/change/flow 단기값을 같은 기준으로 읽는다.
# - 그래도 없을 때만 현재가/포착가가 둘 다 명확하면 관측 가격변화율을 계산한다.
# - 없는 값을 +값으로 꾸미거나 S1 기준을 낮추지 않는다.
def _v470_num_if_present(obj: Any, key: str) -> Optional[float]:
    if not isinstance(obj, dict) or obj.get(key) in (None, ""):
        return None
    try:
        return float(str(obj.get(key)).replace(",", "").replace("%", ""))
    except Exception:
        return None


def _v471_reaction_objs(row: Dict[str, Any], ctx: Dict[str, Any], of: Dict[str, Any]) -> List[Dict[str, Any]]:
    # v471: recheck 가격반응 진단은 row/entry_context/orderflow의 1단계 nested dict까지 본다.
    # 없는 값을 만들지 않고, 실제 존재하는 숫자 key만 후보로 올린다.
    objs: List[Dict[str, Any]] = []
    seen: set[int] = set()
    def add(obj: Any) -> None:
        if isinstance(obj, dict) and id(obj) not in seen:
            seen.add(id(obj))
            objs.append(obj)
            for nk in (
                'metrics', 'feature', 'features', 'orderflow', 'orderflow_summary', 'micro', 'micro_summary',
                'market', 'market_context', 'standard_values', 'candidate_values', 'entry_metrics', 'score_context',
                'recheck_metrics', 'price_context', 'quote', 'ticker_state',
            ):
                v = obj.get(nk)
                if isinstance(v, dict):
                    add(v)
    add(row)
    add(ctx)
    add(of if isinstance(of, dict) else {})
    return objs


def _v470_first_present(objs: List[Dict[str, Any]], keys: List[str]) -> tuple[Optional[float], str]:
    for obj in objs:
        if not isinstance(obj, dict):
            continue
        for k in keys:
            v = _v470_num_if_present(obj, k)
            if v is not None:
                return v, k
    return None, ""


def _v471_all_present(objs: List[Dict[str, Any]], keys: List[str], group: str) -> List[Dict[str, Any]]:
    out: List[Dict[str, Any]] = []
    for obj in objs:
        if not isinstance(obj, dict):
            continue
        for k in keys:
            v = _v470_num_if_present(obj, k)
            if v is not None:
                out.append({'group': group, 'source': k, 'value': round(float(v), 4)})
    return out


def _v471_price_delta_candidate(objs: List[Dict[str, Any]]) -> Dict[str, Any]:
    cur, cur_src = _v470_first_present(objs, [
        'current_price', 'price', 'last_price', 'close', 'trade_price', 'quote_price', 'ws_price', 'micro_price'
    ])
    ref, ref_src = _v470_first_present(objs, [
        'detected_price', 'watch_price', 'first_seen_price', 's3_price', 's2_price',
        'candidate_price', 'base_price', 'entry_signal_price', 'signal_price', 'recheck_start_price'
    ])
    if cur is not None and ref is not None and cur > 0 and ref > 0:
        return {'group': 'price_delta', 'source': f'{cur_src}/{ref_src}', 'value': round((cur - ref) / ref * 100.0, 4)}
    return {}


def _v471_pick_reaction(candidates: List[Dict[str, Any]]) -> Dict[str, Any]:
    # 우선순위: 명시값이 0이 아닌 경우 → 0 명시값보다 다른 실제 단기/가격변화값이 있으면 그 값 → 명시 0 → 정보부족.
    # 이것은 기준 완화가 아니라 default 0이 다른 실측값을 가리는 문제를 없애는 것이다.
    explicit = [c for c in candidates if c.get('group') == 'explicit']
    nonzero_explicit = [c for c in explicit if abs(float(c.get('value') or 0.0)) >= 0.001]
    if nonzero_explicit:
        c = nonzero_explicit[0]
        return {'known': True, 'value': float(c['value']), 'source': c.get('source'), 'method': 'explicit', 'candidates': candidates[:8]}
    nonzero_alt = [c for c in candidates if c.get('group') in ('short_flow', 'price_delta') and abs(float(c.get('value') or 0.0)) >= 0.001]
    if nonzero_alt:
        c = nonzero_alt[0]
        zero_src = explicit[0].get('source') if explicit else ''
        method = 'explicit_zero_overridden' if explicit else str(c.get('group') or 'alternate')
        return {'known': True, 'value': float(c['value']), 'source': f"{c.get('source')}" + (f"; explicit0={zero_src}" if zero_src else ''), 'method': method, 'candidates': candidates[:8]}
    if explicit:
        c = explicit[0]
        return {'known': True, 'value': float(c.get('value') or 0.0), 'source': c.get('source'), 'method': 'explicit_zero', 'candidates': candidates[:8]}
    if candidates:
        c = candidates[0]
        return {'known': True, 'value': float(c.get('value') or 0.0), 'source': c.get('source'), 'method': str(c.get('group') or 'candidate'), 'candidates': candidates[:8]}
    return {'known': False, 'value': 0.0, 'source': 'missing', 'method': 'missing', 'candidates': []}


def _v470_recheck_price_reaction(row: Dict[str, Any], ctx: Dict[str, Any], of: Dict[str, Any]) -> Dict[str, Any]:
    objs = _v471_reaction_objs(row, ctx, of)
    explicit_keys = [
        'price_reaction_pct', 'reaction_pct', 'price_response_pct', 'price_recheck_pct',
    ]
    flow_keys = [
        'flow_1m_pct', 'change_1m', 'chg_1m', 'ret_1m_pct', 'price_change_1m',
        'flow_3m_pct', 'change_3m', 'chg_3m', 'ret_3m_pct',
    ]
    candidates: List[Dict[str, Any]] = []
    candidates.extend(_v471_all_present(objs, explicit_keys, 'explicit'))
    candidates.extend(_v471_all_present(objs, flow_keys, 'short_flow'))
    pd = _v471_price_delta_candidate(objs)
    if pd:
        candidates.append(pd)
    picked = _v471_pick_reaction(candidates)
    picked['schema'] = 'price_reaction_spine_v471'
    picked['diagnostic_note'] = 'explicit 0 can be overridden only when a real non-zero short-flow/price-delta value exists; no threshold relaxation'
    return picked


def _v471_recent_paper_closed_snapshot(limit: int = 5) -> Dict[str, Any]:
    try:
        cache = load_json(PAPER_SCORE_CACHE, {}) or {}
    except Exception:
        cache = {}
    recent = []
    if isinstance(cache, dict):
        recent = (((cache.get('recent_12h') or {}) if isinstance(cache.get('recent_12h'), dict) else {}).get('recent_closed') or [])
    if not isinstance(recent, list):
        recent = []
    out_rows: List[Dict[str, Any]] = []
    for r in recent[-limit:]:
        if not isinstance(r, dict):
            continue
        ent = r.get('entry_summary') if isinstance(r.get('entry_summary'), dict) else {}
        m = ent.get('metrics') if isinstance(ent.get('metrics'), dict) else {}
        out_rows.append({
            'ticker': r.get('ticker') or r.get('symbol'),
            'pnl_pct': r.get('pnl_pct'),
            'max_profit_pct': r.get('max_profit_pct') or r.get('max_pnl_pct'),
            'reason': r.get('close_reason') or r.get('reason'),
            'version': r.get('version') or r.get('main_version'),
            'entry_reaction_pct': m.get('price_reaction_pct'),
            'entry_buy_ratio': m.get('buy_ratio'),
            'entry_sustain_1m': m.get('buy_sustain_1m') or m.get('buy_sustain'),
            'entry_spread_pct': m.get('spread_pct'),
        })
    return {
        'schema': 'paper_closed_reference_v471',
        'source': 'paper_score_cache.recent_12h.recent_closed',
        'count_recent_12h': len(recent),
        'rows': out_rows,
        'note': 'S1 lifecycle current/recent counts are fresh candidate-trace only; this closed snapshot prevents false impression that no paper entry happened.',
    }


def _v468_count_dict(rows: List[Dict[str, Any]], key: str) -> Dict[str, int]:
    out: Dict[str, int] = {}
    for r in rows:
        arr = r.get(key) if isinstance(r.get(key), list) else []
        for x in arr:
            sx = str(x).strip()
            if sx:
                out[sx] = out.get(sx, 0) + 1
    return out


def _v462_stage(row: Dict[str, Any]) -> str:
    try:
        s = _v457_stage_of(row)
    except Exception:
        s = str(row.get('s_stage') or row.get('candidate_stage') or row.get('stage') or row.get('grade') or 'S3').upper()
    return s if s in {'S1','S2','S3'} else 'S3'


def _v462_metric(row: Dict[str, Any], keys: List[str], default: float = 0.0) -> float:
    try:
        return _v452_pick_num(row, keys, default)
    except Exception:
        for k in keys:
            try:
                return fnum(row.get(k), default=default)
            except Exception:
                continue
    return default


PAPER_SCORE_CACHE = BASE_DIR / "paper_bot_score_cache.json"


def _v464_first_num(row: Dict[str, Any], ctx: Dict[str, Any], keys: List[str]) -> Optional[float]:
    """v465: row/entry_context/nested feature/orderflow dicts에서 첫 숫자를 찾는다.
    값이 없으면 None을 돌려서 상대기준 미확정으로 남긴다. 조작/보정값을 만들지 않는다.
    """
    objs: List[Any] = [row, ctx]
    for base in (row, ctx):
        if isinstance(base, dict):
            for nk in (
                'metrics', 'feature', 'features', 'orderflow', 'orderflow_summary', 'micro', 'micro_summary',
                'market', 'market_context', 'standard_values', 'candidate_values', 'entry_metrics', 'score_context',
            ):
                v = base.get(nk)
                if isinstance(v, dict):
                    objs.append(v)
    for obj in objs:
        if not isinstance(obj, dict):
            continue
        for k in keys:
            v = obj.get(k)
            if v is None or v == "":
                continue
            try:
                return float(str(v).replace(",", "").replace("%", ""))
            except Exception:
                continue
    return None


def _v464_ratio(cur: Optional[float], base: Optional[float]) -> Optional[float]:
    try:
        if cur is None or base is None or base <= 0:
            return None
        return cur / base
    except Exception:
        return None


def _v464_label_ratio(name: str, ratio: Optional[float], *, good_hi: float = 1.2, warn_hi: float = 1.8, higher_better: bool = False) -> str:
    if ratio is None:
        return f"{name} 상대기준 미확정"
    if higher_better:
        if ratio >= 2.0:
            return f"{name} 평소대비 강함({ratio:.1f}배)"
        if ratio >= 1.2:
            return f"{name} 평소대비 양호({ratio:.1f}배)"
        return f"{name} 평소대비 약함({ratio:.1f}배)"
    if ratio <= good_hi:
        return f"{name} 평소대비 정상({ratio:.1f}배)"
    if ratio <= warn_hi:
        return f"{name} 평소대비 약간넓음({ratio:.1f}배)"
    return f"{name} 평소대비 과확대({ratio:.1f}배)"


def _v465_first_available_money(row: Dict[str, Any], ctx: Dict[str, Any]) -> tuple[Optional[float], str]:
    # 1분이 있으면 1분 기준, 없으면 3/5분 값을 분당으로 환산한다. 없으면 None.
    candidates = [
        (['trade_amount_1m', 'quote_volume_1m', 'amount_1m', 'money_1m', 'turnover_1m', 'money_flow_1m', 'trade_value_1m', 'recent_trade_amount_1m'], 1, '1m'),
        (['trade_amount_3m', 'quote_volume_3m', 'amount_3m', 'money_3m', 'turnover_3m', 'money_flow_3m', 'trade_value_3m'], 3, '3m분당'),
        (['trade_amount_5m', 'quote_volume_5m', 'amount_5m', 'money_5m', 'turnover_5m', 'money_flow_5m', 'trade_value_5m'], 5, '5m분당'),
    ]
    for keys, div, src in candidates:
        v = _v464_first_num(row, ctx, keys)
        if v is not None and v > 0:
            return (v / div, src)
    return None, '-'


def _v465_money_baseline(row: Dict[str, Any], ctx: Dict[str, Any]) -> tuple[Optional[float], str]:
    base = _v464_first_num(row, ctx, [
        'avg_trade_amount_1m', 'avg_quote_volume_1m', 'avg_amount_1m', 'money_1m_avg',
        'turnover_1m_avg', 'median_trade_amount_1m', 'baseline_trade_amount_1m', 'avg_money_flow_1m',
    ])
    if base is not None and base > 0:
        return base, '평균1m'
    day = _v464_first_num(row, ctx, ['turnover_24h', 'acc_trade_price_24h', 'quote_volume_24h', 'money_24h'])
    if day is not None and day > 0:
        return day / 1440.0, '24h분산'
    return None, '-'


def _v465_estimated_reaction_base(row: Dict[str, Any], ctx: Dict[str, Any], metrics: Dict[str, float]) -> tuple[Optional[float], str]:
    base = _v464_first_num(row, ctx, [
        'volatility_3m_pct', 'avg_abs_1m_pct', 'volatility_pct', 'atr_pct', 'range_5m_pct',
        'median_move_3m_pct', 'baseline_reaction_pct', 'avg_reaction_pct', 'median_reaction_pct'
    ])
    if base is not None and base > 0:
        return base, '변동성기준'
    vals = []
    for k, div in [('flow_1m_pct', 1.0), ('flow_3m_pct', 3.0), ('flow_15m_pct', 15.0)]:
        try:
            v = abs(float(metrics.get(k) or 0.0)) / div
            if v > 0:
                vals.append(v)
        except Exception:
            pass
    if vals:
        return max(vals), '최근흐름추정'
    return None, '-'


def _v464_build_relative_context(row: Dict[str, Any], ctx: Dict[str, Any], metrics: Dict[str, float]) -> Dict[str, Any]:
    spread = fnum(metrics.get('spread_pct'), default=0.0)
    reaction = fnum(metrics.get('price_reaction_pct'), default=0.0)
    buy = fnum(metrics.get('buy_ratio'), default=0.0)
    spread_base = _v464_first_num(row, ctx, [
        'avg_spread_pct', 'spread_avg_pct', 'median_spread_pct', 'spread_pct_avg',
        'symbol_spread_median_pct', 'spread_baseline_pct', 'micro_spread_avg_pct', 'orderbook_spread_avg_pct'
    ])
    money_now, money_src = _v465_first_available_money(row, ctx)
    money_base, money_base_src = _v465_money_baseline(row, ctx)
    vol_base, vol_src = _v465_estimated_reaction_base(row, ctx, metrics)
    rel_strength = _v464_first_num(row, ctx, [
        'relative_strength_pct', 'market_relative_strength', 'rel_strength', 'rs_pct',
        'vs_market_15m_pct', 'market_alpha_15m_pct', 'relative_strength'
    ])
    buy_base = _v464_first_num(row, ctx, [
        'avg_buy_ratio', 'buy_ratio_avg', 'median_buy_ratio', 'baseline_buy_ratio', 'micro_buy_ratio_avg'
    ])
    spread_ratio = _v464_ratio(spread, spread_base)
    money_ratio = _v464_ratio(money_now, money_base)
    vol_response_ratio = _v464_ratio(abs(reaction), vol_base)
    buy_recovery = (buy - buy_base) if buy_base is not None else None

    labels: List[str] = []
    missing: List[str] = []
    score = 0.0
    confidence = 0

    if spread_ratio is None:
        missing.append('스프레드 평소값')
        # 상대평가 가점은 주지 않는다. 현재값 안전권만 참고표시.
        if 0 < spread <= 0.18:
            labels.append(f'스프레드 상대 미확정·현재 안전권({spread:.2f}%)')
        elif spread > 0.18:
            labels.append(f'스프레드 상대 미확정·현재 주의({spread:.2f}%)')
        else:
            labels.append('스프레드 상대 미확정')
    else:
        confidence += 1
        labels.append(_v464_label_ratio('스프레드', spread_ratio, good_hi=1.2, warn_hi=1.8, higher_better=False))
        score += 0.8 if spread_ratio <= 1.2 else (-0.7 if spread_ratio >= 1.8 else 0.0)

    if money_ratio is None:
        missing.append('거래대금 평소값')
        labels.append('거래대금 상대 미확정')
    else:
        confidence += 1
        labels.append(_v464_label_ratio('거래대금', money_ratio, higher_better=True) + f'/{money_src} vs {money_base_src}')
        score += 0.8 if money_ratio >= 1.5 else (0.3 if money_ratio >= 1.1 else -0.3)

    if vol_response_ratio is None:
        missing.append('변동성 기준')
        labels.append('반응 변동성대비 미확정')
    else:
        confidence += 1
        src_txt = '추정' if vol_src == '최근흐름추정' else '기준'
        if vol_response_ratio >= 0.8:
            labels.append(f'반응 변동성대비 강함({vol_response_ratio:.1f}배/{src_txt})')
            score += 0.6 if vol_src == '최근흐름추정' else 0.8
        elif vol_response_ratio >= 0.35:
            labels.append(f'반응 변동성대비 보통({vol_response_ratio:.1f}배/{src_txt})')
            score += 0.2 if vol_src == '최근흐름추정' else 0.3
        else:
            labels.append(f'반응 변동성대비 약함({vol_response_ratio:.1f}배/{src_txt})')
            score -= 0.2

    if rel_strength is None:
        missing.append('시장대비강도')
        labels.append('시장대비강도 미확정')
    else:
        confidence += 1
        labels.append(f"시장대비 {'강함' if rel_strength > 0 else '약함'}({rel_strength:+.2f})")
        score += 0.5 if rel_strength > 0 else -0.3

    if buy_recovery is None:
        missing.append('매수체결 평소값')
        labels.append('매수체결 회복 미확정')
    else:
        confidence += 1
        labels.append(f"매수체결 {'회복' if buy_recovery >= 0.05 else '미확인'}({buy_recovery:+.2f})")
        score += 0.4 if buy_recovery >= 0.05 else 0.0

    status = '충분' if confidence >= 3 else ('부분' if confidence >= 2 else '미확정')
    return {
        'labels': labels[:7],
        'missing': missing[:6],
        'score': round(score, 2),
        'data_confidence': int(confidence),
        'relative_status': status,
        'spread_ratio': None if spread_ratio is None else round(spread_ratio, 3),
        'money_ratio': None if money_ratio is None else round(money_ratio, 3),
        'money_src': money_src,
        'money_base_src': money_base_src,
        'vol_response_ratio': None if vol_response_ratio is None else round(vol_response_ratio, 3),
        'vol_src': vol_src,
        'relative_strength': None if rel_strength is None else round(rel_strength, 4),
        'buy_recovery': None if buy_recovery is None else round(buy_recovery, 4),
    }


# v480: hard block / flexible recheck / pipeline-baseline diagnostics
# - 목표는 S1 기준을 낮추는 것이 아니라, 숫자 문턱/상대기준 미확정 후보를 무조건 폐기하지 않고
#   구조 좋음 + 위험 낮음이면 S2 재확인에 남기는 것이다.
# - 상대기준 부족은 "그냥 채운다"가 아니라 어느 baseline/source가 비었는지 기록한다.
def _v480_reason_has_any(items: Any, needles: List[str]) -> bool:
    arr = items if isinstance(items, list) else []
    text = " / ".join(str(x) for x in arr)
    return any(n in text for n in needles)


def _v480_relative_pipeline_diagnostics(relative_ctx: Dict[str, Any]) -> Dict[str, Any]:
    rel = relative_ctx if isinstance(relative_ctx, dict) else {}
    missing = [str(x) for x in (rel.get('missing') if isinstance(rel.get('missing'), list) else []) if str(x).strip()]
    labels = [str(x) for x in (rel.get('labels') if isinstance(rel.get('labels'), list) else []) if str(x).strip()]
    baseline_source = str(rel.get('baseline_source') or rel.get('money_base_src') or '-')
    baseline_reason = str(rel.get('baseline_reason') or '-')
    reasons: List[str] = []
    for name in missing:
        if '거래대금' in name:
            reasons.append('거래대금 평소값 미확정: row/cache/state sample baseline 확인 필요')
        elif '변동성' in name or '반응' in name:
            reasons.append('반응 변동성 기준 미확정: feature/flow baseline 확인 필요')
        elif '스프레드' in name:
            reasons.append('스프레드 평소값 미확정: orderflow spread baseline 확인 필요')
        elif '매수체결' in name:
            reasons.append('매수체결 평소값 미확정: orderflow buy-ratio baseline 확인 필요')
        elif '시장대비' in name:
            reasons.append('시장대비강도 미확정: market/relative strength key 확인 필요')
        else:
            reasons.append(f'{name} 미확정: source/key 확인 필요')
    if baseline_source and baseline_source != '-':
        reasons.append(f'baseline_source={baseline_source} / {baseline_reason}')
    seen=set(); reasons=[x for x in reasons if not (x in seen or seen.add(x))]
    return {
        'missing': missing[:8],
        'labels': labels[:8],
        'baseline_source': baseline_source,
        'baseline_reason': baseline_reason,
        'pipeline_reasons': reasons[:10],
    }


def _v480_condition_policy(item: Dict[str, Any]) -> Dict[str, Any]:
    m = item.get('metrics') if isinstance(item.get('metrics'), dict) else {}
    rel = item.get('relative_context') if isinstance(item.get('relative_context'), dict) else {}
    sim = item.get('recent_similarity') if isinstance(item.get('recent_similarity'), dict) else {}
    score_parts = item.get('score_parts') if isinstance(item.get('score_parts'), dict) else {}
    risk_notes = [str(x) for x in (item.get('risk_notes') if isinstance(item.get('risk_notes'), list) else []) if str(x).strip()]
    risk_tags = [str(x) for x in (item.get('risk_tags') if isinstance(item.get('risk_tags'), list) else []) if str(x).strip()]
    structure_signal = [str(x) for x in (item.get('structure_signal') if isinstance(item.get('structure_signal'), list) else []) if str(x).strip()]
    structure_fit = str(item.get('structure_fit') or '')
    reaction = fnum(m.get('price_reaction_pct'), default=0.0)
    buy = fnum(m.get('buy_ratio'), default=0.0)
    sustain = fnum(m.get('buy_sustain_1m'), default=0.0)
    spread = fnum(m.get('spread_pct'), default=0.0)
    slip = fnum(m.get('slippage_pct'), default=0.0)
    rel_conf = int(fnum(score_parts.get('relative_confidence'), default=fnum(rel.get('data_confidence'), default=0)))
    core_good = 0
    if reaction >= 0.05: core_good += 1
    if buy >= 0.70: core_good += 1
    if sustain >= 0.64: core_good += 1
    if 0 < spread <= 0.18: core_good += 1
    good_structure = bool(structure_signal) or ('구조좋음' in structure_fit)
    hard: List[str] = []
    flexible: List[str] = []
    pipeline = _v480_relative_pipeline_diagnostics(rel)
    if spread >= 0.35:
        hard.append(f'스프레드 과다({spread:.2f}%)')
    elif 0.18 < spread < 0.35:
        flexible.append(f'스프레드 경계값({spread:.2f}%)→재확인')
    if slip > 0.20:
        hard.append(f'미끄러짐 부담({slip:.2f}%)')
    if _v480_reason_has_any(risk_notes + risk_tags, ['매도압력부담', '가짜돌파위험', '되돌림위험', '스프레드부담', '미끄러짐부담']):
        hard.append('위험태그 존재: ' + ', '.join((risk_notes + risk_tags)[:3]))
    if bool(sim.get('loss_dominant')):
        hard.append('손실군 유사 우세')
    if buy < 0.60:
        hard.append(f'매수체결 약함({buy:.2f})')
    elif 0.60 <= buy < 0.70:
        flexible.append(f'매수체결 기준근접({buy:.2f}→0.70)')
    if sustain < 0.50:
        hard.append(f'1분지속 약함({sustain:.2f})')
    elif 0.50 <= sustain < 0.64:
        flexible.append(f'1분지속 기준근접({sustain:.2f}→0.64)')
    if reaction < 0:
        flexible.append(f'가격반응 음전({reaction:+.2f}%)→재확인')
    elif 0 <= reaction < 0.05:
        flexible.append(f'가격반응 기준근접({reaction:+.2f}%→+0.05%)')
    if rel_conf < 2:
        if good_structure and core_good >= 2 and not hard:
            flexible.append(f'상대기준 일부 미확정({rel_conf}개 확인)→baseline 재확인')
        else:
            pipeline['pipeline_reasons'] = (pipeline.get('pipeline_reasons') or []) + [f'상대기준 신뢰도 부족({rel_conf}개): 구조/확인신호 부족 시 S1 보류']
    if good_structure and flexible and not hard:
        lane = 'flexible_recheck'
        action = 'S2 재확인 유지: 구조/확인신호는 있으나 일부 조건·상대기준 재확인 필요'
    elif hard:
        lane = 'hard_block'
        action = '위험 차단/관찰: 구조가 좋아도 바로 진입 금지'
    elif pipeline.get('pipeline_reasons'):
        lane = 'pipeline_pending'
        action = '배관/기준 확인: source/key/baseline 원인 확인 필요'
    else:
        lane = 'strict_recheck'
        action = '기존 엄격 재확인 기준 유지'
    def uniq(xs: List[str], n: int) -> List[str]:
        seen=set(); return [x for x in xs if str(x).strip() and not (x in seen or seen.add(x))][:n]
    return {
        'schema': 'condition_lane_v480_hard_flexible_pipeline',
        'lane': lane,
        'action': action,
        'hard_block_reasons': uniq(hard, 8),
        'flexible_recheck_reasons': uniq(flexible, 8),
        'pipeline_baseline_reasons': uniq(pipeline.get('pipeline_reasons') or [], 10),
        'relative_pipeline': pipeline,
        'core_confirm_count': int(core_good),
        'good_structure': bool(good_structure),
        'policy': 'Hard risk blocks remain hard. Near-threshold/partial-relative candidates stay in recheck when structure is good and risk is low. No S1 threshold/exit/auto-buy/BUY_READY change.',
    }


def _v464_closed_similarity(ticker: str, structure_tags: List[str], metrics: Dict[str, float]) -> Dict[str, Any]:
    cache = load_json(PAPER_SCORE_CACHE, {}) or {}
    rc = (((cache.get('recent_12h') or {}) if isinstance(cache, dict) else {}).get('recent_closed') or [])
    if not isinstance(rc, list):
        rc = []
    sig_tags = set([str(x) for x in structure_tags if str(x).strip()])
    win_best = 0.0
    loss_best = 0.0
    win_name = '-'
    loss_name = '-'
    reaction = fnum(metrics.get('price_reaction_pct'), default=0.0)
    buy = fnum(metrics.get('buy_ratio'), default=0.0)
    spread = fnum(metrics.get('spread_pct'), default=0.0)
    for r in rc[-12:]:
        if not isinstance(r, dict):
            continue
        ent = r.get('entry_summary') if isinstance(r.get('entry_summary'), dict) else {}
        ent_tags = set([str(x) for x in (ent.get('structure_tags') or []) if str(x).strip()])
        overlap = (len(sig_tags & ent_tags) / max(1, min(len(sig_tags), len(ent_tags)))) if ent_tags and sig_tags else 0.0
        m = ent.get('metrics') if isinstance(ent.get('metrics'), dict) else {}
        mr = fnum(m.get('price_reaction_pct'), default=0.0)
        mb = fnum(m.get('buy_ratio'), default=0.0)
        ms = fnum(m.get('spread_pct'), default=0.0)
        metric_sim = 1.0
        metric_sim -= min(0.35, abs(reaction - mr) / 0.8)
        metric_sim -= min(0.35, abs(buy - mb) / 1.2)
        metric_sim -= min(0.30, abs(spread - ms) / 0.8)
        metric_sim = max(0.0, metric_sim)
        sim = max(0.0, min(1.0, 0.55 * overlap + 0.45 * metric_sim))
        name = str(r.get('ticker') or '-')
        pnl = fnum(r.get('pnl_pct'), default=0.0)
        if pnl > 0 and sim > win_best:
            win_best = sim; win_name = name
        elif pnl <= 0 and sim > loss_best:
            loss_best = sim; loss_name = name
    has_data = bool(rc)
    loss_dominant = bool(has_data and loss_best >= max(0.60, win_best + 0.05))
    win_dominant = bool(has_data and win_best >= max(0.60, loss_best + 0.10))
    if not has_data:
        label = '최근유사 데이터없음'
        score = 0.0
        warning = ''
    elif loss_dominant:
        label = f"⚠️ 손실군 유사 우세 · 승리군 {win_best*100:.0f}%({win_name}) / 손실군 {loss_best*100:.0f}%({loss_name})"
        score = (win_best - loss_best) * 1.8 - 0.45
        warning = '손실군 유사 우세'
    elif win_dominant:
        label = f"✅ 승리군 유사 우세 · 승리군 {win_best*100:.0f}%({win_name}) / 손실군 {loss_best*100:.0f}%({loss_name})"
        score = (win_best - loss_best) * 1.5 + 0.15
        warning = ''
    else:
        label = f"혼합 · 승리군 {win_best*100:.0f}%({win_name}) / 손실군 {loss_best*100:.0f}%({loss_name})"
        score = (win_best - loss_best) * 1.2
        warning = '승패유사 혼합'
    score = max(-1.8, min(1.4, score))
    return {
        'label': label,
        'win_similarity': round(win_best, 3),
        'loss_similarity': round(loss_best, 3),
        'loss_dominant': loss_dominant,
        'win_dominant': win_dominant,
        'warning': warning,
        'score': round(score, 2),
    }


def _v462_recheck_row(row: Dict[str, Any], nowv: float) -> Optional[Dict[str, Any]]:
    stage = _v462_stage(row)
    if stage not in {'S2', 'S3'}:
        return None
    ticker = ticker_norm(row.get('ticker') or row.get('market') or row.get('symbol')) if 'ticker_norm' in globals() else str(row.get('ticker') or '').upper()
    if not ticker:
        return None
    ctx = row.get('entry_context') if isinstance(row.get('entry_context'), dict) else {}
    # v469: recheck는 paper_latest row만 보지 말고, 같은 cycle의 최신 orderflow canonical 값을
    # 판단 직전에 overlay한다. 이것은 조건 완화가 아니라 끊긴 정보배관 재연결이다.
    row, ctx, live_orderflow = _v469_overlay_recheck_orderflow(row, ctx, ticker)
    tags = []
    for key in ('structure_tags', 'structure_good_tags'):
        tags.extend(_v462_as_list(row.get(key)))
        tags.extend(_v462_as_list(ctx.get(key)))
    # preserve order/deduplicate
    seen = set(); tags = [x for x in tags if not (x in seen or seen.add(x))]
    risk_tags = []
    for key in ('structure_risk_tags', 'risk_tags'):
        risk_tags.extend(_v462_as_list(row.get(key)))
        risk_tags.extend(_v462_as_list(ctx.get(key)))
    seen = set(); risk_tags = [x for x in risk_tags if not (x in seen or seen.add(x))]
    structure_fit = str(row.get('structure_fit') or row.get('structure_summary') or ctx.get('structure_fit') or ctx.get('structure_summary') or '')
    decision = str(row.get('review_decision') or row.get('review_decision_reason') or row.get('review_result') or '-')
    block_reasons = []
    for obj in (row, ctx):
        for key in ('s1_block_reasons_detail', 'fail', 'reasons', 'block_reasons', 'unmet_conditions'):
            block_reasons.extend(_v462_as_list(obj.get(key)))
    seen = set(); block_reasons = [x for x in block_reasons if not (x in seen or seen.add(x))]

    reaction_info = _v470_recheck_price_reaction(row, ctx, live_orderflow)
    reaction = float(reaction_info.get('value') or 0.0) if reaction_info.get('known') else 0.0
    if reaction_info.get('known'):
        # 아래 상대기준/표시/게이트가 모두 같은 canonical 값을 보게 통일한다.
        row['price_reaction_pct'] = reaction
        ctx['price_reaction_pct'] = reaction
        row['price_reaction_source_v470'] = reaction_info.get('source')
        row['price_reaction_method_v470'] = reaction_info.get('method')
    spread = _v462_metric(row, ['spread_pct', 'orderbook_spread_pct', 'micro_spread_pct'], 0.0)
    slip = _v462_metric(row, ['expected_slippage_pct', 'slippage_pct', 'est_slippage_pct'], 0.0)
    buy = _v462_metric(row, ['buy_ratio', 'buy_trade_ratio', 'micro_buy_ratio'], 0.0)
    sustain = _v462_metric(row, ['buy_sustain_1m', 'buy_persist_1m', 'buy_continuation_1m'], 0.0)
    flow1 = _v462_metric(row, ['flow_1m_pct', 'change_1m', 'price_change_1m', 'chg_1m', 'ret_1m_pct'], 0.0)
    flow3 = _v462_metric(row, ['flow_3m_pct', 'change_3m', 'price_change_3m', 'chg_3m', 'ret_3m_pct'], 0.0)
    flow15 = _v462_metric(row, ['flow_15m_pct', 'change_15m', 'price_change_15m', 'chg_15m', 'ret_15m_pct'], 0.0)

    price_reaction_known = bool(reaction_info.get('known'))
    spread_known = _v468_metric_known(row, ctx, ['spread_pct', 'orderbook_spread_pct', 'micro_spread_pct'])
    buy_known = _v468_metric_known(row, ctx, ['buy_ratio', 'buy_trade_ratio', 'micro_buy_ratio'])
    sustain_known = _v468_metric_known(row, ctx, ['buy_sustain_1m', 'buy_persist_1m', 'buy_continuation_1m'])
    info_diag = _v468_orderflow_diag(ticker)

    good_tags = [t for t in tags if t in _RECHECK_GOOD_STRUCTURE_TAGS]
    hard_risks = [t for t in risk_tags if t in _RECHECK_HARD_RISK_TAGS]
    structure_score = len(good_tags)
    if '구조좋음' in structure_fit:
        structure_score += 2
    elif '구조관찰' in structure_fit:
        structure_score += 1
    if any(x in decision for x in ('재확인', '아까운')):
        structure_score += 2
    if any(x in decision for x in ('위험상승', '안 산 게 맞음')):
        structure_score -= 1

    # v464: 구조해석은 예상/준비 신호이고, 코인별 상대기준은 재확인 점수 보강용이다.
    # 여기서도 paper OPEN/S1 기준은 바꾸지 않는다.

    # observation filter only. This is not an OPEN/strategy threshold change.
    too_risky = (spread >= 0.75) or (len(hard_risks) >= 3 and buy < 0.60)
    no_structure = structure_score < 2 and not good_tags
    if too_risky or no_structure:
        return None

    need: List[str] = []
    positive: List[str] = []
    risk_notes: List[str] = []
    if reaction >= 0.05:
        positive.append(f"가격반응 {reaction:+.2f}%")
    else:
        need.append("가격반응 +0.05% 이상 확인")
    if buy >= 0.70:
        positive.append(f"매수체결 {buy:.2f}")
    elif buy >= 0.60:
        need.append(f"매수체결 회복 확인({buy:.2f}→0.70 근접)")
    else:
        need.append(f"매수체결 약함({buy:.2f})")
    if sustain >= 0.64:
        positive.append(f"1분지속 {sustain:.2f}")
    else:
        need.append("1분 매수지속 회복")
    if 0 < spread <= 0.18:
        positive.append(f"스프레드 {spread:.2f}%")
    elif spread > 0.18:
        need.append(f"스프레드 안정 필요({spread:.2f}%)")
        if spread >= 0.35:
            risk_notes.append("스프레드 부담")
    if slip > 0.20:
        need.append(f"미끄러짐 안정 필요({slip:.2f}%)")
        risk_notes.append("미끄러짐 부담")
    if flow1 > 0 or flow3 > 0:
        positive.append(f"단기흐름 1m {flow1:+.2f}% / 3m {flow3:+.2f}%")
    if flow15 > 0:
        positive.append(f"15분흐름 {flow15:+.2f}%")
    for r in hard_risks[:4]:
        if r not in risk_notes:
            risk_notes.append(r)

    money_now_est, money_now_src = _v465_first_available_money(row, ctx)
    metrics_for_relative = {
        'price_reaction_pct': reaction,
        'spread_pct': spread,
        'slippage_pct': slip,
        'buy_ratio': buy,
        'buy_sustain_1m': sustain,
        'flow_1m_pct': flow1,
        'flow_3m_pct': flow3,
        'flow_15m_pct': flow15,
        'money_1m_est': money_now_est or 0.0,
        'money_1m_src': money_now_src,
    }
    relative_ctx = _v464_build_relative_context(row, ctx, metrics_for_relative)
    similarity = _v464_closed_similarity(ticker, good_tags[:6] or tags[:6], metrics_for_relative)
    relative_conf = int(fnum(relative_ctx.get('data_confidence'), default=0))
    loss_dominant = bool(similarity.get('loss_dominant'))

    confirm_part = 0.0
    core_confirm = 0
    if reaction >= 0.05:
        confirm_part += 1.0; core_confirm += 1
    elif reaction > 0:
        confirm_part += 0.4
    if buy >= 0.70:
        confirm_part += 1.0; core_confirm += 1
    elif buy >= 0.60:
        confirm_part += 0.5
    if sustain >= 0.64:
        confirm_part += 0.9; core_confirm += 1
    if 0 < spread <= 0.18:
        confirm_part += 0.7; core_confirm += 1
    elif spread >= 0.35:
        confirm_part -= 0.4

    # v465: 구조는 예상 신호다. 확인/상대기준이 부족하면 구조점수 상한을 낮춰 착시를 줄인다.
    raw_structure_part = max(0.0, structure_score * 1.05)
    structure_cap_reason = ''
    structure_cap = 5.5
    if core_confirm < 2:
        structure_cap = min(structure_cap, 3.8)
        structure_cap_reason = '확인신호 부족'
    if relative_conf < 2:
        structure_cap = min(structure_cap, 3.6)
        structure_cap_reason = (structure_cap_reason + '/상대기준 미확정').strip('/')
    if loss_dominant:
        structure_cap = min(structure_cap, 3.4)
        structure_cap_reason = (structure_cap_reason + '/손실군 유사 우세').strip('/')
    structure_part = min(structure_cap, raw_structure_part)

    relative_part = fnum(relative_ctx.get('score'), default=0.0) if relative_conf > 0 else 0.0
    risk_penalty = min(2.8, len(hard_risks) * 0.55 + (0.6 if spread >= 0.35 else 0.0) + (0.4 if slip > 0.20 else 0.0) + (0.35 if loss_dominant else 0.0))
    similarity_part = fnum(similarity.get('score'), default=0.0)
    recheck_score = structure_part + confirm_part + relative_part + similarity_part - risk_penalty
    score_parts = {
        'structure_score': round(structure_part, 2),
        'structure_raw': round(raw_structure_part, 2),
        'structure_cap': round(structure_cap, 2),
        'structure_cap_reason': structure_cap_reason,
        'relative_score': round(relative_part, 2),
        'relative_confidence': relative_conf,
        'confirm_score': round(confirm_part, 2),
        'core_confirm_count': int(core_confirm),
        'similarity_score': round(similarity_part, 2),
        'risk_penalty': round(risk_penalty, 2),
    }

    promotion_block_reasons: List[str] = []
    if reaction < 0.05:
        promotion_block_reasons.append('가격반응 부족')
    if buy < 0.70:
        promotion_block_reasons.append('매수체결 0.70 미만')
    if sustain < 0.64:
        promotion_block_reasons.append('1분 매수지속 부족')
    if not (0 < spread <= 0.18):
        promotion_block_reasons.append('스프레드 안정 미확인')
    if risk_notes:
        promotion_block_reasons.append('위험요소 존재')
    if relative_conf < 2:
        promotion_block_reasons.append('상대기준 미확정')
    if loss_dominant:
        promotion_block_reasons.append('손실군 유사 우세')
    if structure_cap_reason:
        promotion_block_reasons.append(f'구조점수 상한:{structure_cap_reason}')

    information_deficits: List[str] = []
    measured_deficits: List[str] = []
    # 정보부족: 판단값 자체가 없거나 stale/key/target 문제로 신뢰할 수 없는 경우.
    # 실측부족: 정보는 있으나 조건 기준에 못 미치는 경우.
    if not price_reaction_known:
        information_deficits.append('가격반응 정보부족')
    elif reaction < 0.05:
        measured_deficits.append('가격반응 부족')
    if not sustain_known or (not bool(info_diag.get('micro_fresh')) and sustain <= 0):
        information_deficits.append('1분 매수지속 정보부족')
    elif sustain < 0.64:
        measured_deficits.append('1분 매수지속 부족')
    if not buy_known or not bool(info_diag.get('micro_fresh')):
        information_deficits.append('매수체결 정보부족')
    elif buy < 0.70:
        measured_deficits.append('매수체결 0.70 미만')
    if not spread_known or not bool(info_diag.get('orderflow_key')):
        information_deficits.append('스프레드 정보부족')
    elif not (0 < spread <= 0.18):
        measured_deficits.append('스프레드 안정 미확인')
    rel_missing = relative_ctx.get('missing') if isinstance(relative_ctx.get('missing'), list) else []
    if rel_missing or int(fnum(relative_ctx.get('data_confidence'), default=0)) < 2:
        information_deficits.append('상대기준 핵심 미확정')
    for x in info_diag.get('missing') or []:
        sx = str(x).strip()
        if sx and sx not in information_deficits:
            information_deficits.append(sx)

    key = _v457_candidate_key(row) if '_v457_candidate_key' in globals() else f"{ticker}:{int(event_created_ts(row) or nowv)}"
    # v480: 하드차단/유연재확인/배관우선 분류를 같은 canonical row에 남긴다.
    # S1 승격 기준은 여기서 낮추지 않는다. 좋은 구조+위험낮음+근접조건 후보는 재확인 상태에서 사라지지 않도록 분리한다.
    _v480_seed_item = {
        'metrics': {'price_reaction_pct': reaction, 'spread_pct': spread, 'slippage_pct': slip, 'buy_ratio': buy, 'buy_sustain_1m': sustain},
        'relative_context': relative_ctx,
        'recent_similarity': similarity,
        'score_parts': score_parts,
        'risk_notes': risk_notes[:7],
        'risk_tags': risk_tags[:7],
        'structure_signal': good_tags[:6] or tags[:6],
        'structure_fit': structure_fit or ('구조좋음' if good_tags else '구조관찰'),
    }
    condition_policy = _v480_condition_policy(_v480_seed_item) if '_v480_condition_policy' in globals() else {}
    return {
        'candidate_key': key,
        'tracking_key': _v469_recheck_tracking_key(row, {'candidate_key': key, 'ticker': ticker, 'strategy_key': str(row.get('strategy_key') or row.get('strategy') or '-')}),
        'event_id': str(row.get('event_id') or row.get('event_key') or key),
        'ticker': ticker,
        'stage': stage,
        'strategy': str(row.get('strategy_label') or row.get('strategy') or row.get('strategy_key') or '-'),
        'strategy_key': str(row.get('strategy_key') or row.get('strategy') or '-'),
        'score': round(_v462_metric(row, ['score', 'leader_score'], 0.0), 2),
        'recheck_score': round(recheck_score, 2),
        'score_parts': score_parts,
        'relative_context': relative_ctx,
        'information_deficits': information_deficits[:10],
        'measured_deficits': measured_deficits[:10],
        'info_diagnostics': {**info_diag, 'orderflow_overlay': row.get('orderflow_overlay_v469') or {}, 'price_reaction_v470': reaction_info, 'hot_flow_v481': {'change_1m_source': row.get('change_1m_source'), 'change_3m_source': row.get('change_3m_source'), 'hot_rank_1m': row.get('hot_rank_1m') or row.get('scanner_hot_rank_1m'), 'hot_rank_3m': row.get('hot_rank_3m') or row.get('scanner_hot_rank_3m'), 'change_1m_known': row.get('change_1m_known'), 'change_3m_known': row.get('change_3m_known')}},
        'recent_similarity': similarity,
        'promotion_block_reasons': promotion_block_reasons[:8],
        'relative_status': relative_ctx.get('relative_status'),
        'condition_policy_v480': condition_policy,
        'condition_lane': condition_policy.get('lane') if isinstance(condition_policy, dict) else None,
        'hard_block_reasons': condition_policy.get('hard_block_reasons') if isinstance(condition_policy, dict) else [],
        'flexible_recheck_reasons': condition_policy.get('flexible_recheck_reasons') if isinstance(condition_policy, dict) else [],
        'pipeline_baseline_reasons': condition_policy.get('pipeline_baseline_reasons') if isinstance(condition_policy, dict) else [],
        'decision': decision,
        'structure_signal': good_tags[:6] or tags[:6],
        'structure_fit': structure_fit or ('구조좋음' if good_tags else '구조관찰'),
        'confirm_signal': positive[:6],
        'needed_recovery': need[:7],
        'risk_notes': risk_notes[:7],
        'risk_tags': risk_tags[:7],
        'block_reasons': block_reasons[:7],
        'metrics': {
            'price_reaction_pct': reaction,
            'price_reaction_source': reaction_info.get('source'),
            'price_reaction_method': reaction_info.get('method'),
            'spread_pct': spread,
            'slippage_pct': slip,
            'buy_ratio': buy,
            'buy_sustain_1m': sustain,
            'flow_1m_pct': flow1,
            'flow_3m_pct': flow3,
            'flow_15m_pct': flow15,
            'change_1m_source': row.get('change_1m_source'),
            'change_3m_source': row.get('change_3m_source'),
            'hot_rank_1m': row.get('hot_rank_1m') or row.get('scanner_hot_rank_1m'),
            'hot_rank_3m': row.get('hot_rank_3m') or row.get('scanner_hot_rank_3m'),
            'change_1m_known': row.get('change_1m_known'),
            'change_3m_known': row.get('change_3m_known'),
            'money_1m_est': money_now_est or 0.0,
            'money_1m_src': money_now_src,
        },
        'created_at': event_created_ts(row) if 'event_created_ts' in globals() else 0.0,
        'snapshot_ts': nowv,
        'snapshot_text': now_text(nowv),
    }




# v467: recheck 상대기준 baseline spine
# - 없는 값을 fallback으로 꾸미지 않는다.
# - row/feature/orderflow 값이 없으면 recheck state의 최근 샘플에서만 baseline을 만든다.
# - 히스토리가 부족하면 "히스토리부족"으로 표시하고 가점하지 않는다.
def _v467_sample_values(samples: Any, key: str, *, exclude_last: bool = True) -> List[float]:
    vals: List[float] = []
    arr = samples if isinstance(samples, list) else []
    use = arr[:-1] if exclude_last and len(arr) >= 2 else arr
    for sm in use:
        if not isinstance(sm, dict):
            continue
        m = sm.get('metrics') if isinstance(sm.get('metrics'), dict) else {}
        try:
            v = float(m.get(key))
            if v == v:
                vals.append(v)
        except Exception:
            pass
    return vals


def _v467_avg(vals: List[float]) -> Optional[float]:
    vals = [v for v in vals if v == v]
    if not vals:
        return None
    return sum(vals) / len(vals)


def _v467_span_sec(samples: Any) -> float:
    arr = [x for x in (samples if isinstance(samples, list) else []) if isinstance(x, dict)]
    if len(arr) < 2:
        return 0.0
    ts = []
    for x in arr:
        try:
            ts.append(float(x.get('ts') or 0))
        except Exception:
            pass
    return max(ts) - min(ts) if ts else 0.0


def _v467_set_rel_status(rel: Dict[str, Any]) -> None:
    conf = int(fnum(rel.get('data_confidence'), default=0))
    rel['relative_status'] = '충분' if conf >= 3 else ('부분' if conf >= 2 else '미확정')


def _v467_update_rel_label(rel: Dict[str, Any], starts: str, new_label: str) -> None:
    labels = rel.get('labels') if isinstance(rel.get('labels'), list) else []
    labels = [x for x in labels if not str(x).startswith(starts)]
    labels.append(new_label)
    rel['labels'] = labels[:8]


def _v467_remove_missing(rel: Dict[str, Any], name: str) -> None:
    miss = rel.get('missing') if isinstance(rel.get('missing'), list) else []
    rel['missing'] = [x for x in miss if x != name]


def _v467_apply_state_baseline(item: Dict[str, Any], rec: Dict[str, Any]) -> None:
    """recheck state 샘플로만 상대기준 미확정 일부를 해소한다.
    이 함수는 전략 조건을 바꾸지 않고, S1 gate의 상대기준 판정 근거만 채운다.
    """
    if not isinstance(item, dict) or not isinstance(rec, dict):
        return
    rel = item.get('relative_context') if isinstance(item.get('relative_context'), dict) else {}
    if not rel:
        return
    samples = rec.get('samples') if isinstance(rec.get('samples'), list) else []
    span = _v467_span_sec(samples)
    if len(samples) < 3 or span < 45:
        rel['baseline_source'] = '히스토리부족'
        rel['baseline_reason'] = f'샘플 {len(samples)}개 / {span:.0f}s'
        # 기존 데이터없음 문구를 더 정확하게 바꿔준다. 가점은 하지 않는다.
        labels = rel.get('labels') if isinstance(rel.get('labels'), list) else []
        rel['labels'] = [str(x).replace('상대 미확정', '히스토리부족') for x in labels][:8]
        item['relative_context'] = rel
        return

    m = item.get('metrics') if isinstance(item.get('metrics'), dict) else {}
    score_add = 0.0
    conf_add = 0

    # spread baseline from previous samples
    if rel.get('spread_ratio') is None:
        cur = fnum(m.get('spread_pct'), default=0.0)
        base = _v467_avg(_v467_sample_values(samples, 'spread_pct'))
        ratio = _v464_ratio(cur, base)
        if ratio is not None:
            rel['spread_ratio'] = round(ratio, 3)
            _v467_remove_missing(rel, '스프레드 평소값')
            _v467_update_rel_label(rel, '스프레드', _v464_label_ratio('스프레드', ratio, good_hi=1.2, warn_hi=1.8, higher_better=False) + '/최근샘플')
            score_add += 0.5 if ratio <= 1.2 else (-0.5 if ratio >= 1.8 else 0.0)
            conf_add += 1

    # volatility/reaction baseline from recent reaction/flow samples
    if rel.get('vol_response_ratio') is None:
        reaction = abs(fnum(m.get('price_reaction_pct'), default=0.0))
        vals = [abs(x) for x in _v467_sample_values(samples, 'price_reaction_pct')]
        vals += [abs(x)/3.0 for x in _v467_sample_values(samples, 'flow_3m_pct') if abs(x) > 0]
        base = _v467_avg(vals)
        ratio = _v464_ratio(reaction, base)
        if ratio is not None:
            rel['vol_response_ratio'] = round(ratio, 3)
            rel['vol_src'] = '최근샘플'
            _v467_remove_missing(rel, '변동성 기준')
            if ratio >= 0.8:
                lab = f'반응 변동성대비 강함({ratio:.1f}배/최근샘플)'; score_add += 0.45
            elif ratio >= 0.35:
                lab = f'반응 변동성대비 보통({ratio:.1f}배/최근샘플)'; score_add += 0.15
            else:
                lab = f'반응 변동성대비 약함({ratio:.1f}배/최근샘플)'; score_add -= 0.15
            _v467_update_rel_label(rel, '반응', lab)
            conf_add += 1

    # buy recovery baseline from recent samples
    if rel.get('buy_recovery') is None:
        cur = fnum(m.get('buy_ratio'), default=0.0)
        base = _v467_avg(_v467_sample_values(samples, 'buy_ratio'))
        if base is not None:
            recov = cur - base
            rel['buy_recovery'] = round(recov, 4)
            _v467_remove_missing(rel, '매수체결 평소값')
            _v467_update_rel_label(rel, '매수체결', f"매수체결 {'회복' if recov >= 0.05 else '미확인'}({recov:+.2f}/최근샘플)")
            score_add += 0.25 if recov >= 0.05 else 0.0
            conf_add += 1

    # money baseline only if sample metrics contain money_1m_est after v467 accumulates data.
    if rel.get('money_ratio') is None:
        cur = fnum(m.get('money_1m_est'), default=0.0)
        base = _v467_avg(_v467_sample_values(samples, 'money_1m_est'))
        ratio = _v464_ratio(cur, base)
        if ratio is not None:
            rel['money_ratio'] = round(ratio, 3)
            rel['money_src'] = '샘플현재'
            rel['money_base_src'] = '최근샘플'
            _v467_remove_missing(rel, '거래대금 평소값')
            _v467_update_rel_label(rel, '거래대금', _v464_label_ratio('거래대금', ratio, higher_better=True) + '/최근샘플')
            score_add += 0.45 if ratio >= 1.5 else (0.15 if ratio >= 1.1 else -0.2)
            conf_add += 1

    old_conf = int(fnum(rel.get('data_confidence'), default=0))
    old_score = fnum(rel.get('score'), default=0.0)
    if conf_add:
        rel['data_confidence'] = min(5, old_conf + conf_add)
        rel['score'] = round(max(-2.0, min(2.5, old_score + score_add)), 2)
        rel['baseline_source'] = 'row+state_samples'
        rel['baseline_reason'] = f'샘플 {len(samples)}개 / {span:.0f}s'
        _v467_set_rel_status(rel)
        item['relative_context'] = rel
        parts = item.get('score_parts') if isinstance(item.get('score_parts'), dict) else {}
        parts['relative_confidence'] = int(rel.get('data_confidence') or 0)
        parts['relative_score'] = round(fnum(rel.get('score'), default=0.0), 2)
        item['score_parts'] = parts
        item['relative_status'] = rel.get('relative_status')


def _v462_update_recheck_candidates_cache() -> Dict[str, Any]:
    nowv = now_ts()
    fresh_rows, stale_rows, stale_s1 = _v461_latest_rows_split(420)
    state = load_json(RECHECK_STATE, {}) or {}
    active = state.get('active') if isinstance(state, dict) and isinstance(state.get('active'), dict) else {}
    rows: List[Dict[str, Any]] = []
    for row in fresh_rows:
        if not isinstance(row, dict):
            continue
        item = _v462_recheck_row(row, nowv)
        if not item:
            continue
        key = item['candidate_key']
        state_key = str(item.get('tracking_key') or key)
        # v469: event_id/candidate_key는 scan마다 바뀔 수 있으므로 recheck baseline state는
        # ticker+strategy tracking_key로 유지한다. 기존 candidate_key state는 1회 migration만 허용한다.
        rec = active.get(state_key) if isinstance(active.get(state_key), dict) else {}
        if not rec:
            rec = active.get(key) if isinstance(active.get(key), dict) else {}
        if not rec:
            rec = {
                'tracking_key': state_key,
                'candidate_key': key,
                'first_candidate_key': key,
                'ticker': item.get('ticker'),
                'first_seen_ts': nowv,
                'first_seen_text': now_text(nowv),
                'first_metrics': item.get('metrics') or {},
                'samples': [],
            }
        rec['tracking_key'] = state_key
        rec['candidate_key'] = key
        rec['last_candidate_key'] = key
        item['tracking_key'] = state_key
        rec['ticker'] = item.get('ticker')
        rec['stage'] = item.get('stage')
        rec['strategy'] = item.get('strategy')
        rec['last_seen_ts'] = nowv
        rec['last_seen_text'] = now_text(nowv)
        rec['last_metrics'] = item.get('metrics') or {}
        rec['last_recheck_score'] = item.get('recheck_score')
        rec['last_needed_recovery'] = item.get('needed_recovery') or []
        rec['last_risk_notes'] = item.get('risk_notes') or []
        samples = rec.get('samples') if isinstance(rec.get('samples'), list) else []
        samples.append({'ts': nowv, 'metrics': item.get('metrics') or {}, 'score': item.get('recheck_score')})
        rec['samples'] = samples[-10:]
        # v467: 기존 row에 baseline이 없으면 recheck state 샘플로만 상대기준을 보강한다.
        # 값이 없으면 히스토리부족으로 남기며, 임의 fallback 가점은 하지 않는다.
        try:
            _v467_apply_state_baseline(item, rec)
        except Exception as exc:
            append_error(ERROR, 'v467_state_relative_baseline', exc)
        age_sec = max(0.0, nowv - fnum(rec.get('first_seen_ts'), default=nowv))
        first_m = rec.get('first_metrics') if isinstance(rec.get('first_metrics'), dict) else {}
        cur_m = item.get('metrics') if isinstance(item.get('metrics'), dict) else {}
        item['recheck_age_sec'] = round(age_sec, 1)
        item['recheck_started_text'] = rec.get('first_seen_text') or '-'
        item['delta_reaction_pct'] = round(fnum(cur_m.get('price_reaction_pct'), default=0.0) - fnum(first_m.get('price_reaction_pct'), default=0.0), 3)
        item['delta_buy_ratio'] = round(fnum(cur_m.get('buy_ratio'), default=0.0) - fnum(first_m.get('buy_ratio'), default=0.0), 3)
        cur_m = item.get('metrics') if isinstance(item.get('metrics'), dict) else {}
        reaction = fnum(cur_m.get('price_reaction_pct'), default=0.0)
        buy = fnum(cur_m.get('buy_ratio'), default=0.0)
        sustain = fnum(cur_m.get('buy_sustain_1m'), default=0.0)
        spread = fnum(cur_m.get('spread_pct'), default=0.0)
        risk_notes = item.get('risk_notes') if isinstance(item.get('risk_notes'), list) else []
        confirm_count = len(item.get('confirm_signal') or [])
        # v463: 상태명은 S1 승격 가능성과 착시가 없도록 분리한다.
        # 승격대기는 모든 핵심 확인값이 맞은 경우만 표시한다. 여전히 paper OPEN/S1 승격은 하지 않는다.
        rel_conf = int(fnum((item.get('score_parts') or {}).get('relative_confidence'), default=0)) if isinstance(item.get('score_parts'), dict) else 0
        sim_obj = item.get('recent_similarity') if isinstance(item.get('recent_similarity'), dict) else {}
        promotion_ready = (reaction >= 0.05 and buy >= 0.70 and sustain >= 0.64 and 0 < spread <= 0.18 and not risk_notes and rel_conf >= 2 and not sim_obj.get('loss_dominant'))
        policy = item.get('condition_policy_v480') if isinstance(item.get('condition_policy_v480'), dict) else {}
        lane = str(policy.get('lane') or '')
        if promotion_ready:
            item['recheck_state'] = '승격대기'
        elif lane == 'hard_block' or (risk_notes and (spread >= 0.35 or buy < 0.60 or len(risk_notes) >= 2)):
            item['recheck_state'] = '위험우선'
        elif lane == 'flexible_recheck':
            item['recheck_state'] = '유연재확인'
        elif lane == 'pipeline_pending':
            item['recheck_state'] = '배관확인'
        elif confirm_count > 0:
            item['recheck_state'] = '부분확인'
        else:
            item['recheck_state'] = '재확인중'
        item['promotion_ready'] = bool(promotion_ready)
        item['confirm_count'] = int(confirm_count)
        active[state_key] = rec
        rows.append(item)
    # keep state short; this is trace cache only.
    active = {k:v for k,v in active.items() if isinstance(v, dict) and nowv - fnum(v.get('last_seen_ts'), v.get('first_seen_ts'), default=nowv) <= 6*3600}
    rows.sort(key=lambda x: (fnum(x.get('recheck_score'), default=0.0), fnum(x.get('score'), default=0.0)), reverse=True)
    counts: Dict[str, int] = {}
    for r in rows:
        st = str(r.get('recheck_state') or '재확인중')
        counts[st] = counts.get(st, 0) + 1
    info_deficit_counts = _v468_count_dict(rows, 'information_deficits')
    measured_deficit_counts = _v468_count_dict(rows, 'measured_deficits')
    lane_counts: Dict[str, int] = {}
    hard_reason_counts: Dict[str, int] = {}
    flexible_reason_counts: Dict[str, int] = {}
    pipeline_reason_counts: Dict[str, int] = {}
    for _r in rows:
        pol = _r.get('condition_policy_v480') if isinstance(_r.get('condition_policy_v480'), dict) else {}
        lane = str(pol.get('lane') or 'unknown')
        lane_counts[lane] = lane_counts.get(lane, 0) + 1
        for _x in pol.get('hard_block_reasons') or []:
            sx = str(_x); hard_reason_counts[sx] = hard_reason_counts.get(sx, 0) + 1
        for _x in pol.get('flexible_recheck_reasons') or []:
            sx = str(_x); flexible_reason_counts[sx] = flexible_reason_counts.get(sx, 0) + 1
        for _x in pol.get('pipeline_baseline_reasons') or []:
            sx = str(_x); pipeline_reason_counts[sx] = pipeline_reason_counts.get(sx, 0) + 1
    out = {
        'schema': 'recheck_candidates_cache_v481_hot_rank_spine',
        'version': VERSION,
        'updated_ts': nowv,
        'updated_text': now_text(nowv),
        'source_policy': 'fresh S2/S3 only; observation/recheck cache; not paper OPEN and not S1 promotion',
        'candidate_count': len(rows),
        'state_counts': counts,
        'info_deficit_counts': info_deficit_counts,
        'measured_deficit_counts': measured_deficit_counts,
        'condition_lane_counts_v480': lane_counts,
        'hard_block_reason_counts_v480': hard_reason_counts,
        'flexible_recheck_reason_counts_v480': flexible_reason_counts,
        'pipeline_baseline_reason_counts_v480': pipeline_reason_counts,
        'top': rows[:15],
        'policy': 'v480: strict S1 gate stays. Hard-risk remains blocked; near-threshold/partial-relative good-structure candidates stay in flexible recheck; baseline shortages are diagnosed by source/key. No auto-buy/BUY_READY/exit change.',
    }
    save_json(RECHECK_STATE, {'schema': 'recheck_candidates_state_v469_stable_tracking_key', 'version': VERSION, 'updated_ts': nowv, 'active': active})
    save_json(RECHECK_CACHE, out)
    try:
        sm = load_json(SUMMARY, {}) or {}
        if isinstance(sm, dict):
            sm['recheck_candidates'] = {'schema': out['schema'], 'updated_ts': nowv, 'candidate_count': len(rows), 'state_counts': counts, 'info_deficit_counts': info_deficit_counts, 'measured_deficit_counts': measured_deficit_counts}
            save_json(SUMMARY, sm)
    except Exception:
        pass
    return out


_v462_prev_update_s1_lifecycle_trace = _v457_update_s1_lifecycle_trace

def _v457_update_s1_lifecycle_trace() -> Dict[str, Any]:  # type: ignore[override]
    out = _v462_prev_update_s1_lifecycle_trace()
    try:
        _v462_update_recheck_candidates_cache()
    except Exception as exc:
        append_error(ERROR, 'v467_recheck_candidates_cache', exc)
    return out


# v466: recheck promotion gate -> S1 paper handoff
# - S2/S3를 바로 paper OPEN하지 않는다. recheck의 엄격한 promotion_ready만 S1으로 승격한다.
# - 구조좋음만으로 승격하지 않는다. 가격반응/체결/1분지속/스프레드/상대기준/손실유사/반복손실 gate가 모두 맞아야 한다.
# - paper 장부, 청산조건, 자동매수, BUY_READY는 건드리지 않는다.

_V466_LAST_PROMOTION: Dict[str, Any] = {"promoted": 0, "blocked": 0, "promoted_keys": []}


def _v466_recent_symbol_loss_count(ticker: str) -> int:
    """최근 12시간 CLOSED에서 같은 심볼 손실 횟수. 장부를 수정하지 않고 score cache만 읽는다."""
    t = str(ticker or '').upper().strip()
    if not t:
        return 0
    cache = load_json(PAPER_SCORE_CACHE, {}) or {}
    recent = (((cache.get('recent_12h') or {}) if isinstance(cache, dict) else {}).get('recent_closed') or [])
    if not isinstance(recent, list):
        return 0
    cnt = 0
    for r in recent:
        if not isinstance(r, dict):
            continue
        rt = str(r.get('ticker') or r.get('symbol') or '').upper().strip()
        if rt != t:
            continue
        if fnum(r.get('pnl_pct'), default=0.0) <= 0:
            cnt += 1
    return cnt


def _v466_gate_item(item: Dict[str, Any]) -> Tuple[bool, List[str], List[str]]:
    """S1 재확인 승격 gate. return pass, pass_reasons, block_reasons."""
    m = item.get('metrics') if isinstance(item.get('metrics'), dict) else {}
    parts = item.get('score_parts') if isinstance(item.get('score_parts'), dict) else {}
    sim = item.get('recent_similarity') if isinstance(item.get('recent_similarity'), dict) else {}
    rel = item.get('relative_context') if isinstance(item.get('relative_context'), dict) else {}
    ticker = str(item.get('ticker') or '').upper().strip()
    reaction = fnum(m.get('price_reaction_pct'), default=0.0)
    buy = fnum(m.get('buy_ratio'), default=0.0)
    sustain = fnum(m.get('buy_sustain_1m'), default=0.0)
    spread = fnum(m.get('spread_pct'), default=0.0)
    rel_conf = int(fnum(parts.get('relative_confidence'), default=0))
    risk_notes = item.get('risk_notes') if isinstance(item.get('risk_notes'), list) else []
    loss_cnt = _v466_recent_symbol_loss_count(ticker)
    pass_reasons: List[str] = []
    block: List[str] = []
    info_def = item.get('information_deficits') if isinstance(item.get('information_deficits'), list) else []
    meas_def = item.get('measured_deficits') if isinstance(item.get('measured_deficits'), list) else []
    def has_info(name: str) -> bool:
        return any(name in str(x) for x in info_def)
    policy = item.get('condition_policy_v480') if isinstance(item.get('condition_policy_v480'), dict) else {}
    flex_txt = ' / '.join(str(x) for x in (policy.get('flexible_recheck_reasons') or [])) if isinstance(policy, dict) else ''
    if reaction >= 0.05:
        pass_reasons.append(f'가격반응 {reaction:+.2f}%')
    else:
        block.append('가격반응 기준근접→재확인 보류' if '가격반응' in flex_txt else ('가격반응 정보부족' if has_info('가격반응') else '가격반응 부족'))
    if buy >= 0.70:
        pass_reasons.append(f'매수체결 {buy:.2f}')
    else:
        block.append('매수체결 기준근접→재확인 보류' if '매수체결 기준근접' in flex_txt else ('매수체결 정보부족' if has_info('매수체결') else '매수체결 0.70 미만'))
    if sustain >= 0.64:
        pass_reasons.append(f'1분지속 {sustain:.2f}')
    else:
        block.append('1분지속 기준근접→재확인 보류' if '1분지속 기준근접' in flex_txt else ('1분 매수지속 정보부족' if has_info('1분 매수지속') else '1분 매수지속 부족'))
    if 0 < spread <= 0.18:
        pass_reasons.append(f'스프레드 {spread:.2f}%')
    else:
        block.append('스프레드 경계값→재확인 보류' if '스프레드 경계값' in flex_txt else ('스프레드 정보부족' if has_info('스프레드') else '스프레드 안정 미확인'))
    if rel_conf >= 2:
        pass_reasons.append(f'상대기준 {rel_conf}개 확인')
    else:
        block.append('상대기준 일부 미확정→재확인 보류' if '상대기준' in flex_txt else '상대기준 핵심 미확정')
    if sim.get('loss_dominant'):
        block.append('손실군 유사 우세')
    elif sim.get('win_dominant'):
        pass_reasons.append('승리군 유사 우세')
    if risk_notes:
        block.append('위험요소 존재')
    if loss_cnt >= 2:
        block.append(f'최근 반복손실 {loss_cnt}회')
    elif loss_cnt == 1:
        # 1회 손실은 차단까지는 아니지만 이유를 남겨 추적한다.
        pass_reasons.append('최근 손실 1회 주의')
    if item.get('recheck_state') == '위험우선':
        block.append('위험우선 후보')
    ok = len(block) == 0
    return ok, pass_reasons[:8], block[:10]


def _v466_stage_counts(rows: List[Dict[str, Any]]) -> Dict[str, int]:
    counts = {'S1': 0, 'S2': 0, 'S3': 0}
    for r in rows:
        try:
            st = _v457_stage_of(r)
        except Exception:
            st = str(r.get('s_stage') or r.get('candidate_grade') or 'S3').upper()
        if st == 'S':
            st = 'S1'
        if st not in counts:
            st = 'S3'
        counts[st] += 1
    return counts



def _v472_apply_recheck_handoff_metrics(row: Dict[str, Any], item: Dict[str, Any]) -> None:
    """v472: recheck가 확정한 canonical 실측값을 S1 승격 row와 entry_context에 봉인한다.

    paper final safety가 구 price_reaction_pct=0.00만 다시 보지 않도록,
    recheck gate가 실제로 통과시킨 metrics/source/method를 paper handoff row의 단일 원천으로 남긴다.
    조건 수치나 승격 기준은 바꾸지 않는다.
    """
    if not isinstance(row, dict) or not isinstance(item, dict):
        return
    metrics = item.get('metrics') if isinstance(item.get('metrics'), dict) else {}
    if not metrics:
        return
    info = item.get('info_diagnostics') if isinstance(item.get('info_diagnostics'), dict) else {}
    pr_info = info.get('price_reaction_v470') if isinstance(info.get('price_reaction_v470'), dict) else {}
    ctx = row.get('entry_context') if isinstance(row.get('entry_context'), dict) else {}
    ctx = dict(ctx)
    strat = row.get('strategy_context') if isinstance(row.get('strategy_context'), dict) else {}
    strat = dict(strat)
    entry_metrics = row.get('entry_metrics') if isinstance(row.get('entry_metrics'), dict) else {}
    entry_metrics = dict(entry_metrics)
    recheck_metrics = {
        'price_reaction_pct': metrics.get('price_reaction_pct'),
        'price_reaction_source': metrics.get('price_reaction_source') or pr_info.get('source'),
        'price_reaction_method': metrics.get('price_reaction_method') or pr_info.get('method'),
        'spread_pct': metrics.get('spread_pct'),
        'slippage_pct': metrics.get('slippage_pct'),
        'buy_ratio': metrics.get('buy_ratio'),
        'buy_sustain_1m': metrics.get('buy_sustain_1m'),
        'flow_1m_pct': metrics.get('flow_1m_pct'),
        'flow_3m_pct': metrics.get('flow_3m_pct'),
        'flow_15m_pct': metrics.get('flow_15m_pct'),
        'money_1m_est': metrics.get('money_1m_est'),
        'money_1m_src': metrics.get('money_1m_src'),
        'schema': 'recheck_to_paper_metric_spine_v472',
    }
    # None/빈값은 덮지 않는다. recheck가 확정한 실측값만 단일 원천으로 봉인한다.
    for k, v in list(recheck_metrics.items()):
        if v in (None, ''):
            continue
        row[k] = v
        ctx[k] = v
        strat[k] = v
        entry_metrics[k] = v
    # paper_bot v0.143 final safety가 short-flow를 같은 이름으로 읽게 별칭도 같이 남긴다.
    if recheck_metrics.get('flow_1m_pct') not in (None, ''):
        row['change_1m'] = recheck_metrics.get('flow_1m_pct')
        ctx['change_1m'] = recheck_metrics.get('flow_1m_pct')
        entry_metrics['change_1m'] = recheck_metrics.get('flow_1m_pct')
    if recheck_metrics.get('flow_3m_pct') not in (None, ''):
        row['change_3m'] = recheck_metrics.get('flow_3m_pct')
        ctx['change_3m'] = recheck_metrics.get('flow_3m_pct')
        entry_metrics['change_3m'] = recheck_metrics.get('flow_3m_pct')
    row['entry_context'] = ctx
    row['strategy_context'] = strat
    row['entry_metrics'] = entry_metrics
    row['recheck_promotion_metrics'] = dict(metrics)
    row['recheck_price_reaction_info'] = dict(pr_info)
    row['paper_final_metric_spine'] = 'recheck_to_paper_metric_spine_v472'
    ctx['paper_final_metric_spine'] = 'recheck_to_paper_metric_spine_v472'

def _v466_apply_recheck_promotions(cache_obj: Dict[str, Any]) -> Dict[str, Any]:
    """promotion gate 통과 item을 PAPER_LATEST의 같은 후보 row에 S1로 봉인한다."""
    top = cache_obj.get('top') if isinstance(cache_obj.get('top'), list) else []
    if not top:
        return {'promoted': 0, 'blocked': 0, 'promoted_keys': [], 'blocked_sample': []}
    pass_map: Dict[str, Dict[str, Any]] = {}
    blocked_sample: List[Dict[str, Any]] = []
    block_reason_counts: Dict[str, int] = {}
    for item in top:
        if not isinstance(item, dict):
            continue
        ok, pass_reasons, block = _v466_gate_item(item)
        item['s1_promotion_gate'] = {'pass': bool(ok), 'pass_reasons': pass_reasons, 'block_reasons': block}
        item['promotion_block_reasons'] = block or item.get('promotion_block_reasons') or []
        if ok:
            item['recheck_state'] = 'S1승격'
            item['promotion_result'] = 'promote_to_s1'
            item['promotion_reasons'] = pass_reasons
            key = str(item.get('candidate_key') or '')
            if key:
                pass_map[key] = item
        else:
            item['promotion_result'] = 'blocked'
            for br in block[:8]:
                block_reason_counts[str(br)] = block_reason_counts.get(str(br), 0) + 1
            if len(blocked_sample) < 8:
                blocked_sample.append({'ticker': item.get('ticker'), 'stage': item.get('stage'), 'reason': block[:5]})
    if not pass_map:
        return {'promoted': 0, 'blocked': len(blocked_sample), 'promoted_keys': [], 'blocked_sample': blocked_sample, 'block_reason_counts': block_reason_counts}
    latest = _v455_read_jsonl_tail(PAPER_LATEST, max_lines=V455_LATEST_TAIL_LINES) if '_v455_read_jsonl_tail' in globals() else read_jsonl(PAPER_LATEST, max_lines=0)
    fixed: List[Dict[str, Any]] = []
    promoted_keys: List[str] = []
    promoted_rows: List[Dict[str, Any]] = []
    nowv = now_ts()
    for row in latest:
        if not isinstance(row, dict):
            continue
        try:
            key = _v457_candidate_key(row)
        except Exception:
            key = str(row.get('candidate_key') or row.get('event_id') or '')
        item = pass_map.get(key)
        if item:
            reason = item.get('promotion_reasons') or []
            row = dict(row)
            row.update({
                's_stage': 'S1',
                'candidate_grade': 'S1',
                'stage': 'S1',
                'decision_stage': 'S1',
                'candidate_grade_label': '✅ S1 재확인승격',
                'paper_bot_open': True,
                'open_eligible': True,
                'trade_ready': True,
                'recheck_required': False,
                'final_entry_action': 'paper_open',
                'open_source': 'recheck_s1_promotion_v472',
                's1_promotion_source': 'recheck_gate_v472',
                's1_promotion_ts': nowv,
                's1_promotion_text': now_text(nowv),
                's1_promotion_reasons': reason,
                's1_promotion_gate': item.get('s1_promotion_gate') or {},
                'recheck_score': item.get('recheck_score'),
                'recheck_state': 'S1승격',
                'recheck_score_parts': item.get('score_parts') or {},
                'recheck_relative_context': item.get('relative_context') or {},
                'recheck_recent_similarity': item.get('recent_similarity') or {},
            })
            # strategy/entry_context에도 같은 봉인을 남긴다.
            ctx = row.get('entry_context') if isinstance(row.get('entry_context'), dict) else {}
            ctx = dict(ctx)
            ctx.update({'s_stage': 'S1', 'candidate_grade': 'S1', 'paper_bot_open': True, 'open_eligible': True, 'trade_ready': True, 's1_promotion_source': 'recheck_gate_v472', 's1_promotion_reasons': reason})
            row['entry_context'] = ctx
            strat = row.get('strategy_context') if isinstance(row.get('strategy_context'), dict) else {}
            strat = dict(strat)
            strat.update({'decision_stage': 'S1', 'lifecycle_stage': 'S1', 'paper_bot_open': True, 's1_promotion_source': 'recheck_gate_v472'})
            row['strategy_context'] = strat
            try:
                _v472_apply_recheck_handoff_metrics(row, item)
            except Exception as exc:
                append_error(ERROR, 'v472_recheck_handoff_metrics', exc)
            reasons = row.get('s_stage_reasons') if isinstance(row.get('s_stage_reasons'), list) else []
            row['s_stage_reasons'] = (['S2/S3→S1재확인승격'] + [str(x) for x in reason] + [str(x) for x in reasons])[:12]
            promoted_keys.append(key)
            promoted_rows.append(row)
        fixed.append(row)
    if promoted_rows:
        fixed.sort(key=lambda x: ({'S1': 3, 'S2': 2, 'S3': 1}.get(str(x.get('s_stage') or x.get('candidate_grade') or '').upper(), 0), fnum(x.get('s1_promotion_ts'), x.get('updated_ts'), x.get('created_at'), default=0.0), fnum(x.get('score'), default=0.0)), reverse=True)
        write_jsonl_atomic(PAPER_LATEST, fixed)
        for r in promoted_rows[:20]:
            try:
                append_jsonl(PAPER, r)
            except Exception:
                pass
        counts = _v466_stage_counts(fixed)
        try:
            sm = load_json(SUMMARY, {}) or {}
            if isinstance(sm, dict):
                sm.update({'s_stage_counts': counts, 's1_count': counts.get('S1', 0), 's2_count': counts.get('S2', 0), 's3_count': counts.get('S3', 0), 'paper_latest_count': len(fixed), 's_count': len(fixed), 'recheck_promotion': {'schema': 'recheck_s1_promotion_v472', 'updated_ts': nowv, 'promoted': len(promoted_rows), 'promoted_tickers': [r.get('ticker') for r in promoted_rows[:10]], 'policy': 'Only strict recheck promotion gate can lift S2/S3 to S1. No auto-buy/BUY_READY/exit change.'}})
                save_json(SUMMARY, sm)
        except Exception as exc:
            append_error(ERROR, 'v466_promotion_summary_update', exc)
    return {'promoted': len(promoted_rows), 'blocked': max(0, len(top) - len(promoted_rows)), 'promoted_keys': promoted_keys, 'blocked_sample': blocked_sample, 'block_reason_counts': block_reason_counts}


_v466_prev_recheck_update = _v462_update_recheck_candidates_cache



def _v462_update_recheck_candidates_cache() -> Dict[str, Any]:  # type: ignore[override]
    global _V466_LAST_PROMOTION
    out = _v466_prev_recheck_update()
    try:
        promo = _v466_apply_recheck_promotions(out)
        _V466_LAST_PROMOTION = promo
        out['schema'] = 'recheck_candidates_cache_v480_condition_lanes'
        out['version'] = VERSION
        out['promotion_summary'] = promo
        out['source_policy'] = 'fresh S2/S3 recheck cache; v480 separates hard-block/flexible-recheck/pipeline-baseline lanes; strict promotion gate still seals only fully qualifying rows as S1; no auto-buy/BUY_READY/exit change'
        counts = out.get('state_counts') if isinstance(out.get('state_counts'), dict) else {}
        if promo.get('promoted'):
            counts = dict(counts)
            counts['S1승격'] = int(promo.get('promoted') or 0)
            out['state_counts'] = counts
        save_json(RECHECK_CACHE, out)
    except Exception as exc:
        append_error(ERROR, 'v469_apply_recheck_promotions', exc)
    return out


_v466_prev_update_s1_lifecycle_trace = _v457_update_s1_lifecycle_trace

def _v457_update_s1_lifecycle_trace() -> Dict[str, Any]:  # type: ignore[override]
    out = _v466_prev_update_s1_lifecycle_trace()
    try:
        if int((_V466_LAST_PROMOTION or {}).get('promoted') or 0) > 0 and '_v462_prev_update_s1_lifecycle_trace' in globals():
            # promotion으로 PAPER_LATEST가 갱신됐으므로 S1 생애주기를 한 번 더 fresh spine 기준으로 갱신한다.
            out = _v462_prev_update_s1_lifecycle_trace()
        closed_ref = _v471_recent_paper_closed_snapshot(5)
        if isinstance(out, dict):
            out['schema'] = 's1_lifecycle_trace_v471_with_closed_reference'
            out['paper_recent_closed_reference'] = closed_ref
            save_json(S1_LIFECYCLE_TRACE, out)
        try:
            sm = load_json(SUMMARY, {}) or {}
            if isinstance(sm, dict):
                sm['recheck_promotion_trace'] = _V466_LAST_PROMOTION
                sm['s1_lifecycle_closed_reference'] = {k: closed_ref.get(k) for k in ('schema','count_recent_12h','note')}
                save_json(SUMMARY, sm)
        except Exception:
            pass
    except Exception as exc:
        append_error(ERROR, 'v471_refresh_s1_lifecycle_closed_reference', exc)
    return out

# v466 keeps the run_once chain. Recheck promotion happens on the same strategy cycle,
# and only strict promotion_gate candidates become S1 paper handoff rows.


# =============================================================================
# strategy_worker v0.66 / v474: S1 lifecycle also reads canonical metric spine
# - Root cause: /recheck and /candidate_reason used canonical price/orderflow values,
#   but /s1_lifecycle could still show legacy block reasons such as price_reaction +0.00.
# - This is not a condition change. It only reseals the lifecycle display cache so
#   lifecycle/current S1/recent flow read the same canonical row used by candidate_reason.
# =============================================================================


def _v474_lifecycle_row_index(max_rows: int = 520) -> Dict[str, Dict[str, Any]]:
    """Build the same fresh handoff row index used by candidate_reason/lifecycle."""
    idx: Dict[str, Dict[str, Any]] = {}
    try:
        fresh_rows, _stale, _stale_s1 = _v461_latest_rows_split(max_rows)
    except Exception:
        fresh_rows = []
    for r in fresh_rows:
        if not isinstance(r, dict):
            continue
        try:
            key = _v457_candidate_key(r)
        except Exception:
            key = str(r.get('candidate_key') or r.get('event_id') or r.get('event_key') or '')
        if key:
            idx[key] = r
        try:
            t = ticker_norm(r.get('ticker') or r.get('market') or r.get('symbol')) if 'ticker_norm' in globals() else str(r.get('ticker') or r.get('market') or r.get('symbol') or '').upper()
        except Exception:
            t = str(r.get('ticker') or '').upper()
        sk = str(r.get('strategy_key') or r.get('strategy') or '').strip()
        if t:
            idx['ticker:' + t] = r
            if sk:
                idx['ticker_strategy:' + t + '|' + sk] = r
    return idx


def _v474_lifecycle_spine_for_item(item: Dict[str, Any], row_idx: Dict[str, Dict[str, Any]]) -> Dict[str, Any]:
    """Return candidate_reason's canonical metric spine for a lifecycle item."""
    if not isinstance(item, dict):
        return {}
    key = str(item.get('candidate_key') or '').strip()
    t = str(item.get('ticker') or '').upper().strip()
    row = row_idx.get(key) if key else None
    if not isinstance(row, dict) and t:
        row = row_idx.get('ticker:' + t)
    if not isinstance(row, dict):
        return {}
    try:
        return _v473_candidate_reason_spine(row, now_ts()) if '_v473_candidate_reason_spine' in globals() else {}
    except Exception as exc:
        try:
            append_error(ERROR, 'v474_lifecycle_candidate_spine', exc)
        except Exception:
            pass
        return {}


def _v474_lifecycle_apply_spine(item: Dict[str, Any], row_idx: Dict[str, Dict[str, Any]]) -> Dict[str, Any]:
    """Reseal lifecycle display item with canonical metrics/reasons.

    The original stage/paper status is preserved. Only display metrics and reasons
    are replaced by the same source used by candidate_reason compact cache.
    """
    if not isinstance(item, dict):
        return item
    spine = _v474_lifecycle_spine_for_item(item, row_idx)
    if not isinstance(spine, dict) or not spine:
        return item
    metrics = spine.get('metrics') if isinstance(spine.get('metrics'), dict) else {}
    block = spine.get('block_reasons') if isinstance(spine.get('block_reasons'), list) else []
    missing = spine.get('missing_info') if isinstance(spine.get('missing_info'), list) else []
    out = dict(item)
    if metrics:
        out['metrics'] = {
            'price_reaction_pct': fnum(metrics.get('price_reaction_pct'), default=0.0),
            'spread_pct': fnum(metrics.get('spread_pct'), default=0.0),
            'slippage_pct': fnum(metrics.get('slippage_pct'), default=0.0),
            'buy_ratio': fnum(metrics.get('buy_ratio'), default=0.0),
            'buy_sustain_1m': fnum(metrics.get('buy_sustain_1m'), default=0.0),
            'price_reaction_source': metrics.get('price_reaction_source'),
            'price_reaction_method': metrics.get('price_reaction_method'),
        }
    # candidate_reason과 같은 정리된 reason을 표시한다. 비어 있으면 기존 이유를 억지로 되살리지 않는다.
    out['block_reasons'] = _v452_short_text_list(block, 8) if '_v452_short_text_list' in globals() else [str(x) for x in block[:8]]
    out['missing_info'] = _v452_short_text_list(missing, 6) if '_v452_short_text_list' in globals() else [str(x) for x in missing[:6]]
    out['lifecycle_metric_spine_source'] = spine.get('source') or 'candidate_reason_metric_spine_v474'
    if spine.get('needed_recovery'):
        out['needed_recovery'] = spine.get('needed_recovery')
    return out


def _v474_lifecycle_reseal_out(out: Dict[str, Any]) -> Dict[str, Any]:
    if not isinstance(out, dict):
        return out
    row_idx = _v474_lifecycle_row_index()
    if not row_idx:
        return out
    changed = 0
    for list_key in ('current_s1', 'recent', 'demoted_before_paper', 'paper_blocks', 'paper_waiting'):
        rows = out.get(list_key)
        if not isinstance(rows, list):
            continue
        fixed = []
        for item in rows:
            if not isinstance(item, dict):
                fixed.append(item)
                continue
            before = str(item.get('block_reasons') or '') + str(item.get('metrics') or '')
            ni = _v474_lifecycle_apply_spine(item, row_idx)
            after = str(ni.get('block_reasons') or '') + str(ni.get('metrics') or '')
            if after != before:
                changed += 1
            fixed.append(ni)
        out[list_key] = fixed
    out['schema'] = 's1_lifecycle_trace_v474_metric_spine'
    out['lifecycle_metric_spine'] = {
        'schema': 'lifecycle_metric_spine_v474',
        'source': 'candidate_reason/recheck canonical row',
        'resealed_items': changed,
        'policy': 'Lifecycle display reads the same canonical metrics/reasons as candidate_reason. No threshold/exit/auto-buy/BUY_READY change.',
    }
    return out


_v474_prev_update_s1_lifecycle_trace = _v457_update_s1_lifecycle_trace


def _v457_update_s1_lifecycle_trace() -> Dict[str, Any]:  # type: ignore[override]
    out = _v474_prev_update_s1_lifecycle_trace()
    try:
        if isinstance(out, dict):
            out = _v474_lifecycle_reseal_out(out)
            save_json(S1_LIFECYCLE_TRACE, out)
            try:
                state = load_json(S1_LIFECYCLE_STATE, {}) or {}
                active = state.get('active') if isinstance(state.get('active'), dict) else {}
                row_idx = _v474_lifecycle_row_index()
                for k, rec in list(active.items()):
                    if not isinstance(rec, dict):
                        continue
                    tmp = {'candidate_key': k, 'ticker': rec.get('ticker'), 'block_reasons': rec.get('block_reasons'), 'metrics': rec.get('metrics')}
                    fixed = _v474_lifecycle_apply_spine(tmp, row_idx)
                    rec['metrics'] = fixed.get('metrics', rec.get('metrics'))
                    rec['block_reasons'] = fixed.get('block_reasons', rec.get('block_reasons'))
                    rec['lifecycle_metric_spine_source'] = fixed.get('lifecycle_metric_spine_source')
                if isinstance(state, dict):
                    state['schema'] = 's1_lifecycle_state_v474_metric_spine'
                    state['version'] = VERSION
                    state['active'] = active
                    save_json(S1_LIFECYCLE_STATE, state)
            except Exception as exc:
                append_error(ERROR, 'v474_lifecycle_state_reseal', exc)
            try:
                sm = load_json(SUMMARY, {}) or {}
                if isinstance(sm, dict):
                    sm['s1_lifecycle_trace'] = {
                        'schema': out.get('schema'),
                        'updated_ts': out.get('updated_ts'),
                        'counts': out.get('counts'),
                        'current_s1_count': out.get('current_s1_count'),
                        'recent_s1_count': out.get('recent_s1_count'),
                        'demoted_before_paper_count': out.get('demoted_before_paper_count'),
                        'paper_block_count': out.get('paper_block_count'),
                        'lifecycle_metric_spine': out.get('lifecycle_metric_spine'),
                    }
                    save_json(SUMMARY, sm)
            except Exception:
                pass
    except Exception as exc:
        append_error(ERROR, 'v474_lifecycle_metric_spine', exc)
    return out

# v474 keeps the existing run_once chain. Only S1 lifecycle display cache is resealed
# to the same canonical metric spine used by recheck/candidate_reason/paper handoff.



# =============================================================================
# strategy_worker v0.70 / v488: canonical entry decision spine cleanup
# - 조건을 추가로 조이지 않는다. 흩어진 차단/보류 이유를 한곳에서 분류한다.
# - S1 승격 gate, recheck, candidate_reason, lifecycle/paper handoff가 같은
#   canonical_entry_decision_v484를 읽도록 봉인한다.
# =============================================================================

VERSION = "strategy_worker_v0.73"
V484_ENTRY_DECISION_SCHEMA = "canonical_entry_decision_v498"


def _v484_uniq_text(xs: Any, limit: int = 12) -> List[str]:
    out: List[str] = []
    seen = set()
    arr = xs if isinstance(xs, list) else ([] if xs is None else [xs])
    for x in arr:
        sx = str(x).strip()
        if not sx or sx in seen:
            continue
        seen.add(sx)
        out.append(sx)
        if len(out) >= limit:
            break
    return out


def _v484_metric(m: Dict[str, Any], key: str, default: float = 0.0) -> float:
    try:
        return fnum(m.get(key), default=default)
    except Exception:
        return default


def _v488_reason_kind(text: Any) -> Tuple[str, str, str]:
    """Return (bucket, canonical_key, display_text) for entry decision reasons.

    v488 goal: a condition should appear once. Spread/slippage/sell-pressure/fake-break
    reasons used to be generated by policy, risk tags, recheck text, and paper text with
    slightly different labels. This normalizes them before deciding/displaying.
    """
    raw = str(text or '').strip()
    compact = raw.replace(' ', '').replace('_', '').replace('-', '').lower()
    if not raw:
        return ('ignore', '', '')
    if any(k in raw for k in ('스프레드 과다', '스프레드과다')):
        return ('hard', 'spread', raw)
    if any(k in raw for k in ('스프레드 부담', '스프레드부담', '스프레드 안정', '스프레드 경계', '진입 직전 스프레드')):
        # Exact hard/soft severity is decided by current numeric spread in _v484_entry_decision.
        return ('spread_ref', 'spread', raw)
    if any(k in raw for k in ('미끄러짐', '슬리피지')):
        return ('hard', 'slippage', raw)
    if any(k in raw for k in ('매도압력', '매도벽')):
        return ('hard', 'sell_pressure', '매도압력부담')
    if '손실군 유사 우세' in raw:
        return ('hard', 'loss_similarity', '손실군 유사 우세')
    if '반복손실' in raw:
        return ('hard', 'recent_loss', raw)
    if '가짜돌파' in raw:
        return ('caution', 'fake_breakout', '가짜돌파위험')
    if '되돌림' in raw:
        return ('caution', 'pullback_risk', '되돌림위험')
    if '고점권가격반응약함' in raw or '고점권' in raw:
        return ('caution', 'high_zone_weak_reaction', '고점권가격반응약함')
    if '매수체결' in raw and ('약함' in raw or '부족' in raw or '미만' in raw):
        return ('confirm', 'buy_ratio', raw)
    if '1분' in raw and ('약함' in raw or '부족' in raw or '미만' in raw or '회복' in raw):
        return ('confirm', 'buy_sustain_1m', raw)
    if '가격반응' in raw:
        return ('confirm', 'price_reaction', raw)
    # v489: critical quote/orderflow freshness is still a real execution risk,
    # but relative-baseline shortages are only pipeline notes and must not become an S1 hard gate.
    if any(k in raw for k in ('호가·체결', '호가/체결', 'micro stale', 'micro 오래', 'WS stale', 'WS 오래', '체결 정보부족', '호가 정보부족')):
        return ('hard', 'core_freshness', '호가·체결 신선도 부족')
    if any(k in compact for k in ('baseline', 'source', 'key', 'stale')) or any(k in raw for k in ('상대기준', '평소값', '미확정', '정보부족', '히스토리부족')):
        return ('pipeline', 'pipeline', raw)
    if '위험우선' in raw:
        return ('meta', 'risk_priority', '위험우선 후보')
    return ('other', raw, raw)


def _v488_add_reason(dst: List[str], seen: set, text: Any, fallback: str = '') -> None:
    bucket, key, disp = _v488_reason_kind(text)
    if not key or bucket == 'ignore':
        return
    val = str(disp or fallback or text or '').strip()
    if not val:
        return
    if key in seen:
        return
    seen.add(key)
    dst.append(val)


def _v488_sort_display_reasons(xs: List[str], limit: int = 10) -> List[str]:
    order = {'hard': 0, 'spread_ref': 1, 'caution': 2, 'confirm': 3, 'pipeline': 4, 'meta': 5, 'other': 6}
    buf = []
    seen = set()
    for x in xs or []:
        b, k, d = _v488_reason_kind(x)
        if not k or k in seen:
            continue
        seen.add(k)
        buf.append((order.get(b, 9), str(d or x)))
    return [x for _o, x in sorted(buf, key=lambda p: p[0])[:limit]]


def _v484_entry_decision(item: Dict[str, Any]) -> Dict[str, Any]:
    """Central entry decision classifier.

    This is the single display/gate spine for entry reasons. It intentionally keeps
    the existing strict thresholds. It does not add a new strategy, grade, exit,
    BUY_READY, or auto-buy behavior.
    """
    item = item if isinstance(item, dict) else {}
    m = item.get('metrics') if isinstance(item.get('metrics'), dict) else {}
    parts = item.get('score_parts') if isinstance(item.get('score_parts'), dict) else {}
    sim = item.get('recent_similarity') if isinstance(item.get('recent_similarity'), dict) else {}
    policy = item.get('condition_policy_v480') if isinstance(item.get('condition_policy_v480'), dict) else {}
    rel = item.get('relative_context') if isinstance(item.get('relative_context'), dict) else {}
    info_def = _v484_uniq_text(item.get('information_deficits') or item.get('missing_info') or [], 20)
    measured = _v484_uniq_text(item.get('measured_deficits') or [], 20)
    risk_notes = _v484_uniq_text(item.get('risk_notes') or [], 20)
    hard_from_policy = _v484_uniq_text(policy.get('hard_block_reasons') or [], 20)
    flex_from_policy = _v484_uniq_text(policy.get('flexible_recheck_reasons') or [], 20)
    pipe_from_policy = _v484_uniq_text(policy.get('pipeline_baseline_reasons') or [], 20)
    ticker = str(item.get('ticker') or '').upper().strip()

    reaction = _v484_metric(m, 'price_reaction_pct', 0.0)
    buy = _v484_metric(m, 'buy_ratio', 0.0)
    sustain = _v484_metric(m, 'buy_sustain_1m', 0.0)
    spread = _v484_metric(m, 'spread_pct', 0.0)
    slip = _v484_metric(m, 'slippage_pct', spread if spread > 0 else 0.0)
    rel_conf = int(fnum(parts.get('relative_confidence'), rel.get('data_confidence'), default=0))

    pass_reasons: List[str] = []
    confirm_recheck: List[str] = []
    hard_risk: List[str] = []
    flexible_recheck: List[str] = []
    pipeline_check: List[str] = []

    # v498: recent CLOSED comparison showed winning entries had much stronger
    # immediate price reaction than loss/fast-fail entries.  Keep S2/S3 alive, but
    # do not promote to S1 on buy-ratio alone when price has not actually moved.
    s1_reaction_floor = 0.35
    if reaction >= s1_reaction_floor:
        pass_reasons.append(f'가격반응 {reaction:+.2f}%')
    elif reaction >= 0.05:
        flexible_recheck.append(f'가격반응 약함({reaction:+.2f}%→+{s1_reaction_floor:.2f}%)')
        confirm_recheck.append('가격반응 추가확인')
    elif any('가격반응' in x for x in flex_from_policy) or reaction >= 0:
        flexible_recheck.append(f'가격반응 기준근접({reaction:+.2f}%→+0.05%)')
        confirm_recheck.append('가격반응 확인 필요')
    else:
        confirm_recheck.append('가격반응 부족')

    if buy >= 0.70:
        pass_reasons.append(f'매수체결 {buy:.2f}')
    elif buy < 0.60:
        hard_risk.append(f'매수체결 크게 약함({buy:.2f})')
    else:
        flexible_recheck.append(next((x for x in flex_from_policy if '매수체결' in x), f'매수체결 기준근접({buy:.2f}→0.70)'))
        confirm_recheck.append('매수체결 회복 확인')

    if sustain >= 0.64:
        pass_reasons.append(f'1분지속 {sustain:.2f}')
    elif sustain < 0.50:
        hard_risk.append(f'1분지속 크게 약함({sustain:.2f})')
    else:
        flexible_recheck.append(next((x for x in flex_from_policy if '1분지속' in x), f'1분지속 기준근접({sustain:.2f}→0.64)'))
        confirm_recheck.append('1분 매수지속 회복 확인')

    if 0 < spread <= 0.18:
        pass_reasons.append(f'스프레드 {spread:.2f}%')
    elif spread >= 0.35:
        hard_risk.append(f'스프레드 과다({spread:.2f}%)')
    else:
        flexible_recheck.append(next((x for x in flex_from_policy if '스프레드' in x), f'스프레드 경계값({spread:.2f}%)→재확인'))
        confirm_recheck.append('스프레드 안정 확인')

    if slip > 0.20:
        hard_risk.append(f'미끄러짐 부담({slip:.2f}%)')

    if rel_conf >= 2:
        pass_reasons.append(f'상대기준 {rel_conf}개 확인')
    else:
        # 상대기준 부족은 조건 차단이 아니라 배관/기준 확인 레인이다.
        pipeline_check.append('상대기준 핵심 미확정')
        pipeline_check.extend(pipe_from_policy)

    caution_risk: List[str] = []
    if bool(sim.get('loss_dominant')):
        hard_risk.append('손실군 유사 우세')
    elif bool(sim.get('win_dominant')):
        pass_reasons.append('승리군 유사 우세')

    # v488: policy/risk_notes/measured/info are normalized here only. Do not let the
    # same spread/slippage/fake-break text become multiple gates.
    hard_seen = { _v488_reason_kind(x)[1] for x in hard_risk if _v488_reason_kind(x)[1] }
    flex_seen = { _v488_reason_kind(x)[1] for x in flexible_recheck if _v488_reason_kind(x)[1] }
    pipe_seen = { _v488_reason_kind(x)[1] for x in pipeline_check if _v488_reason_kind(x)[1] }
    confirm_seen = { _v488_reason_kind(x)[1] for x in confirm_recheck if _v488_reason_kind(x)[1] }
    caution_seen: set = set()

    for x in list(hard_from_policy or []) + list(risk_notes or []):
        bucket, key, disp = _v488_reason_kind(x)
        if bucket == 'hard':
            _v488_add_reason(hard_risk, hard_seen, disp or x)
        elif bucket in ('spread_ref',):
            # Numeric spread above already decides hard/flex. Keep only as detail if not already present.
            if spread >= 0.35:
                _v488_add_reason(hard_risk, hard_seen, f'스프레드 과다({spread:.2f}%)')
            elif spread > 0.18:
                _v488_add_reason(flexible_recheck, flex_seen, f'스프레드 경계값({spread:.2f}%)→재확인')
        elif bucket == 'caution':
            _v488_add_reason(caution_risk, caution_seen, disp or x)
        elif bucket == 'confirm':
            _v488_add_reason(confirm_recheck, confirm_seen, disp or x)
        elif bucket == 'pipeline':
            _v488_add_reason(pipeline_check, pipe_seen, disp or x)
        # '위험우선 후보' is a label, not an additional gate. Concrete risk reasons above decide the lane.

    for x in info_def:
        bucket, key, disp = _v488_reason_kind(x)
        if bucket == 'pipeline':
            _v488_add_reason(pipeline_check, pipe_seen, disp or x)
    # measured deficits are represented in confirm/flexible/hard groups above. Keep
    # only unmapped texts as secondary details, not separate new gates.
    for x in measured:
        bucket, key, disp = _v488_reason_kind(x)
        if bucket == 'other':
            _v488_add_reason(confirm_recheck, confirm_seen, disp or x)

    hard_risk = _v488_sort_display_reasons(hard_risk, 8)
    caution_risk = _v488_sort_display_reasons(caution_risk, 8)
    flexible_recheck = _v488_sort_display_reasons(flexible_recheck, 8)
    pipeline_check = _v488_sort_display_reasons(pipeline_check, 8)
    confirm_recheck = _v488_sort_display_reasons(confirm_recheck, 8)
    pass_reasons = _v484_uniq_text(pass_reasons, 10)

    loss_cnt = _v466_recent_symbol_loss_count(ticker) if ticker and '_v466_recent_symbol_loss_count' in globals() else 0
    if loss_cnt >= 2:
        hard_seen = { _v488_reason_kind(x)[1] for x in hard_risk if _v488_reason_kind(x)[1] }
        _v488_add_reason(hard_risk, hard_seen, f'최근 반복손실 {loss_cnt}회')
    elif loss_cnt == 1:
        pass_reasons = _v484_uniq_text(pass_reasons + ['최근 손실 1회 주의'], 10)

    # recheck_state=위험우선 is not an extra condition in v488. It is kept as a label
    # only when concrete hard/caution risks already exist.
    risk_priority_label = str(item.get('recheck_state') or '') == '위험우선'

    # v489: pipeline_check is diagnostic/non-gating.
    # Relative-baseline / source notes must be visible, but they must not be an extra S1 gate.
    strict_pass = not hard_risk and not caution_risk and not flexible_recheck and not confirm_recheck
    if strict_pass:
        action = 'paper_open_candidate'
        primary = 'S1 가능'
        display = pass_reasons
    elif hard_risk:
        action = 'risk_block'
        primary = hard_risk[0]
        display = hard_risk + caution_risk + flexible_recheck + confirm_recheck
    elif caution_risk:
        action = 'caution_recheck'
        primary = caution_risk[0]
        display = caution_risk + flexible_recheck + confirm_recheck
    elif flexible_recheck:
        action = 'recheck_hold'
        primary = flexible_recheck[0]
        display = flexible_recheck + confirm_recheck
    else:
        action = 'confirm_recheck'
        primary = (confirm_recheck[0] if confirm_recheck else '확인신호 재확인')
        display = confirm_recheck

    return {
        'schema': V484_ENTRY_DECISION_SCHEMA,
        'action': action,
        'primary_reason': primary,
        'pass_reasons': pass_reasons[:8],
        'display_reasons': _v488_sort_display_reasons(display, 10),
        'risk_hard': hard_risk,
        'risk_caution': caution_risk,
        'flexible_recheck': flexible_recheck,
        'pipeline_check': pipeline_check,
        'pipeline_notes': pipeline_check,
        'confirm_recheck': confirm_recheck,
        'gate_pass': bool(strict_pass),
        'pipeline_is_gate': False,
        'metrics_snapshot': {
            'price_reaction_pct': round(reaction, 4),
            'buy_ratio': round(buy, 4),
            'buy_sustain_1m': round(sustain, 4),
            'spread_pct': round(spread, 4),
            'slippage_pct': round(slip, 4),
            'relative_confidence': int(rel_conf),
            's1_price_reaction_floor_pct_v498': 0.35,
        },
        'policy': 'v498: duplicated reasons stay deduped; pipeline/relative-baseline shortages are notes, not standalone S1 gates. S1 promotion now requires stronger price reaction so high buy-ratio but no-price-move fast-fail entries stay in recheck. Conditions are decided in this single spine.',
    }


_v484_prev_gate_item = _v466_gate_item if '_v466_gate_item' in globals() else None

def _v466_gate_item(item: Dict[str, Any]) -> Tuple[bool, List[str], List[str]]:  # type: ignore[override]
    dec = _v484_entry_decision(item)
    try:
        item['canonical_entry_decision'] = dec
        item['entry_decision_schema'] = dec.get('schema')
    except Exception:
        pass
    if dec.get('gate_pass'):
        return True, _v484_uniq_text(dec.get('pass_reasons') or [], 8), []
    return False, _v484_uniq_text(dec.get('pass_reasons') or [], 8), _v484_uniq_text(dec.get('display_reasons') or [], 10)


_v484_prev_handoff_metrics = _v472_apply_recheck_handoff_metrics if '_v472_apply_recheck_handoff_metrics' in globals() else None

def _v472_apply_recheck_handoff_metrics(row: Dict[str, Any], item: Dict[str, Any]) -> None:  # type: ignore[override]
    if callable(_v484_prev_handoff_metrics):
        _v484_prev_handoff_metrics(row, item)
    dec = item.get('canonical_entry_decision') if isinstance(item.get('canonical_entry_decision'), dict) else _v484_entry_decision(item)
    row['canonical_entry_decision'] = dec
    row['entry_decision_schema'] = dec.get('schema')
    ctx = row.get('entry_context') if isinstance(row.get('entry_context'), dict) else {}
    ctx = dict(ctx)
    ctx['canonical_entry_decision'] = dec
    ctx['entry_decision_schema'] = dec.get('schema')
    row['entry_context'] = ctx
    strat = row.get('strategy_context') if isinstance(row.get('strategy_context'), dict) else {}
    strat = dict(strat)
    strat['canonical_entry_decision'] = dec
    strat['entry_decision_schema'] = dec.get('schema')
    row['strategy_context'] = strat


_v484_prev_candidate_reason_spine = _v473_candidate_reason_spine if '_v473_candidate_reason_spine' in globals() else None

def _v473_candidate_reason_spine(row: Dict[str, Any], nowv: float) -> Dict[str, Any]:  # type: ignore[override]
    sp = _v484_prev_candidate_reason_spine(row, nowv) if callable(_v484_prev_candidate_reason_spine) else {}
    if not isinstance(sp, dict):
        sp = {}
    item = sp.get('item') if isinstance(sp.get('item'), dict) else {}
    if not item:
        item = {
            'ticker': row.get('ticker'),
            'metrics': sp.get('metrics') if isinstance(sp.get('metrics'), dict) else {},
            'relative_context': sp.get('relative_context') if isinstance(sp.get('relative_context'), dict) else {},
            'information_deficits': sp.get('missing_info') if isinstance(sp.get('missing_info'), list) else [],
            'measured_deficits': [],
            'risk_notes': sp.get('structure_risk_tags') if isinstance(sp.get('structure_risk_tags'), list) else [],
            'condition_policy_v480': row.get('condition_policy_v480') if isinstance(row.get('condition_policy_v480'), dict) else {},
        }
    row_ctx = row.get('entry_context') if isinstance(row.get('entry_context'), dict) else {}
    dec = row.get('canonical_entry_decision') if isinstance(row.get('canonical_entry_decision'), dict) else {}
    if not dec and isinstance(row_ctx.get('canonical_entry_decision'), dict):
        dec = row_ctx.get('canonical_entry_decision')
    if not dec:
        dec = _v484_entry_decision(item)
    sp['canonical_entry_decision'] = dec
    sp['entry_decision_schema'] = dec.get('schema')
    sp['block_reasons'] = dec.get('display_reasons') or sp.get('block_reasons') or []
    sp['source'] = str(sp.get('source') or 'candidate_reason_spine') + '+entry_decision_v484'
    return sp


_v484_prev_recheck_update = _v462_update_recheck_candidates_cache if '_v462_update_recheck_candidates_cache' in globals() else None

def _v462_update_recheck_candidates_cache() -> Dict[str, Any]:  # type: ignore[override]
    out = _v484_prev_recheck_update() if callable(_v484_prev_recheck_update) else {}
    try:
        top = out.get('top') if isinstance(out.get('top'), list) else []
        action_counts: Dict[str, int] = {}
        primary_counts: Dict[str, int] = {}
        for item in top:
            if not isinstance(item, dict):
                continue
            dec = item.get('canonical_entry_decision') if isinstance(item.get('canonical_entry_decision'), dict) else _v484_entry_decision(item)
            item['canonical_entry_decision'] = dec
            item['entry_decision_schema'] = dec.get('schema')
            act = str(dec.get('action') or '-')
            action_counts[act] = action_counts.get(act, 0) + 1
            pr = str(dec.get('primary_reason') or '-')
            primary_counts[pr] = primary_counts.get(pr, 0) + 1
        out['schema'] = 'recheck_candidates_cache_v489_entry_decision_spine'
        out['version'] = VERSION
        out['entry_decision_schema'] = V484_ENTRY_DECISION_SCHEMA
        out['entry_decision_action_counts_v484'] = action_counts
        out['entry_decision_primary_reason_counts_v484'] = dict(sorted(primary_counts.items(), key=lambda kv: kv[1], reverse=True)[:20])
        out['source_policy'] = 'v489: duplicate reasons are deduped. Pipeline/relative-baseline notes do not act as standalone S1 gates; paper only has execution gate.'
        save_json(RECHECK_CACHE, out)
        try:
            sm = load_json(SUMMARY, {}) or {}
            if isinstance(sm, dict):
                sm['entry_decision_v484'] = {
                    'schema': V484_ENTRY_DECISION_SCHEMA,
                    'action_counts': action_counts,
                    'primary_reason_counts': out.get('entry_decision_primary_reason_counts_v484'),
                    'policy': '조건 추가가 아니라 중복 reason 삭제/통합. paper/recheck/candidate_reason은 같은 decision을 봄.',
                }
                save_json(SUMMARY, sm)
        except Exception:
            pass
    except Exception as exc:
        append_error(ERROR, 'v489_recheck_entry_decision_spine', exc)
    return out

# v489 keeps the two-gate structure. It fixes v488 where pipeline_check behaved like a hidden S1 gate,
# and forces lightweight cache publish at the start/end of each strategy cycle so status panels do not show stale reason caches.

# =============================================================================
# strategy_worker v0.76: restore lightweight post-cycle publish, remove v495 heavy trace
# - v493 내용 포함: pre-run에서는 recheck/S1 승격을 만들지 않는다.
# - 본선 run_once 완료 후 최신 paper_latest/candidate_reason/recheck/lifecycle을 갱신한다.
# - health/candidate_reason/recheck/s1_lifecycle이 갈라져 보이는 원인을 줄이기 위해
#   strategy cycle 종료 시 canonical summary row를 1개 저장한다.
# - S1/S2/S3 기준값, 청산조건, 자동매수, BUY_READY, 장부는 변경하지 않는다.
# =============================================================================
VERSION = "strategy_worker_v0.77"

CANONICAL_STRATEGY_SUMMARY = BASE_DIR / "clean_strategy_canonical_summary.json"
_V496_PUBLISH_LAST_TS = 0.0


def _v496_stage_of_row(row: Dict[str, Any]) -> str:
    st = str(row.get('s_stage') or row.get('candidate_stage') or row.get('candidate_grade') or row.get('stage') or row.get('grade') or '').upper()
    if st in ('S1', 'S2', 'S3'):
        return st
    return 'S3'


def _v496_count_latest_rows(rows: List[Dict[str, Any]]) -> Dict[str, int]:
    counts = {'S1': 0, 'S2': 0, 'S3': 0}
    for r in rows:
        if not isinstance(r, dict):
            continue
        st = _v496_stage_of_row(r)
        counts[st] = counts.get(st, 0) + 1
    return counts


def _v496_age_from(obj: Any, nowv: float) -> float:
    if not isinstance(obj, dict):
        return 999999.0
    ts = fnum(obj.get('updated_ts'), obj.get('updated_at'), obj.get('ts'), default=0.0)
    return round(max(0.0, nowv - ts), 1) if ts > 0 else 999999.0


def _v496_read_latest_rows() -> List[Dict[str, Any]]:
    try:
        if '_v455_read_jsonl_tail' in globals():
            return [r for r in _v455_read_jsonl_tail(PAPER_LATEST, max_lines=V455_LATEST_TAIL_LINES) if isinstance(r, dict)]
        return [r for r in read_jsonl(PAPER_LATEST, max_lines=0) if isinstance(r, dict)]
    except Exception:
        return []


def _v496_compact_meta() -> Dict[str, Any]:
    try:
        path = BASE_DIR / 'clean_candidate_reason_compact_cache.json'
        return load_json(path, {}) or {}
    except Exception:
        return {}


def _v496_build_canonical_summary(cycle_ts: float, reason: str = 'post_run') -> Dict[str, Any]:
    nowv = now_ts()
    rows = _v496_read_latest_rows()
    latest_counts = _v496_count_latest_rows(rows)
    strat = load_json(SUMMARY, {}) or {}
    recheck = load_json(RECHECK_CACHE, {}) or {}
    life = load_json(S1_LIFECYCLE_TRACE, {}) or {}
    compact = _v496_compact_meta()
    if not isinstance(strat, dict): strat = {}
    if not isinstance(recheck, dict): recheck = {}
    if not isinstance(life, dict): life = {}
    if not isinstance(compact, dict): compact = {}
    s_counts = strat.get('s_stage_counts') if isinstance(strat.get('s_stage_counts'), dict) else latest_counts
    if not isinstance(s_counts, dict):
        s_counts = latest_counts
    cycle_id = f"strategy_v498_{int(cycle_ts)}"
    out = {
        'schema': 'strategy_canonical_summary_v498',
        'version': VERSION,
        'cycle_id': cycle_id,
        'updated_ts': nowv,
        'updated_text': now_text(nowv),
        'cycle_started_ts': cycle_ts,
        'cycle_elapsed_sec': round(max(0.0, nowv - cycle_ts), 3),
        'publish_reason': reason,
        'evaluated': strat.get('evaluated'),
        'paper_latest_count': len(rows),
        's_stage_counts': {'S1': int(s_counts.get('S1', latest_counts.get('S1', 0)) or 0), 'S2': int(s_counts.get('S2', latest_counts.get('S2', 0)) or 0), 'S3': int(s_counts.get('S3', latest_counts.get('S3', 0)) or 0)},
        'latest_row_counts': latest_counts,
        'candidate_reason': {
            'schema': compact.get('schema'),
            'updated_ts': compact.get('updated_ts') or compact.get('updated_at'),
            'age_sec': _v496_age_from(compact, nowv),
            'candidate_count': compact.get('candidate_count') or compact.get('display_count') or compact.get('paper_latest_count'),
        },
        'recheck': {
            'schema': recheck.get('schema'),
            'updated_ts': recheck.get('updated_ts') or recheck.get('updated_at'),
            'age_sec': _v496_age_from(recheck, nowv),
            'candidate_count': recheck.get('candidate_count'),
            'state_counts': recheck.get('state_counts') if isinstance(recheck.get('state_counts'), dict) else {},
            'promotion_summary': recheck.get('promotion_summary') if isinstance(recheck.get('promotion_summary'), dict) else {},
        },
        's1_lifecycle': {
            'schema': life.get('schema'),
            'updated_ts': life.get('updated_ts') or life.get('updated_at'),
            'age_sec': _v496_age_from(life, nowv),
            'current_s1_count': life.get('current_s1_count'),
            'recent_s1_count': life.get('recent_s1_count'),
            'paper_waiting_count': life.get('paper_waiting_count'),
            'paper_block_count': life.get('paper_block_count'),
            'counts': life.get('counts') if isinstance(life.get('counts'), dict) else {},
        },
        'entry_decision': {
            'schema': V484_ENTRY_DECISION_SCHEMA,
            'pipeline_is_gate': False,
            'policy': '조건판정은 canonical_entry_decision 한곳, paper는 실행안전문 한곳만 사용한다. 상대기준/배관확인은 표시 note이며 단독 S1 차단문이 아니다. v498: S1은 가격반응 +0.35% 이상 확인.',
        },
        'source_policy': 'v498: v495 heavy trace is removed; S1 promotion now requires stronger price reaction to avoid high-buy/no-price fast-fail entries.',
    }
    save_json(CANONICAL_STRATEGY_SUMMARY, out)
    try:
        sm = load_json(SUMMARY, {}) or {}
        if not isinstance(sm, dict): sm = {}
        sm['canonical_summary_v496'] = {
            'schema': out['schema'],
            'version': VERSION,
            'cycle_id': cycle_id,
            'updated_ts': nowv,
            's_stage_counts': out['s_stage_counts'],
            'candidate_reason_age_sec': out['candidate_reason']['age_sec'],
            'recheck_age_sec': out['recheck']['age_sec'],
            's1_lifecycle_age_sec': out['s1_lifecycle']['age_sec'],
            'paper_latest_count': out['paper_latest_count'],
            'pipeline_is_gate': False,
            'row_source': str(CANONICAL_STRATEGY_SUMMARY.name),
        }
        sm['entry_decision_v489'] = {
            'schema': V484_ENTRY_DECISION_SCHEMA,
            'updated_ts': nowv,
            'updated_text': now_text(nowv),
            'pipeline_is_gate': False,
            'publish_reason': reason,
            'policy': '상대기준/배관확인은 표시 note이며 단독 S1 차단문이 아니다. 조건판정은 canonical_entry_decision 한곳, paper는 실행안전문 한곳만 사용.',
        }
        sm['strategy_cache_publish_policy_v498'] = {
            'schema': 'strategy_cache_publish_policy_v498',
            'updated_ts': nowv,
            'pre_run_recheck_promotion': False,
            'post_run_recheck_promotion': True,
            'canonical_summary_row': str(CANONICAL_STRATEGY_SUMMARY.name),
            'reason': 'pre-run은 heartbeat만 남기고, 최신 본선 cycle 완료 후 cache와 canonical summary를 봉인한다.',
        }
        save_json(SUMMARY, sm)
    except Exception as exc:
        append_error(ERROR, 'v496_summary_attach', exc)
    return out


def _v496_publish_decision_caches(cycle_ts: float, reason: str = 'post_run') -> Dict[str, Any]:
    """Post-cycle publisher. Recheck promotion can create S1, so it only runs after fresh strategy rows."""
    try:
        if '_v452_write_candidate_reason_compact' in globals():
            _v452_write_candidate_reason_compact(f'{reason}_candidate_reason_v496', force=True)
    except Exception as exc:
        append_error(ERROR, 'v496_candidate_reason_publish', exc)
    try:
        if '_v462_update_recheck_candidates_cache' in globals():
            _v462_update_recheck_candidates_cache()
    except Exception as exc:
        append_error(ERROR, 'v496_recheck_publish_post_only', exc)
    try:
        if '_v457_update_s1_lifecycle_trace' in globals():
            _v457_update_s1_lifecycle_trace()
    except Exception as exc:
        append_error(ERROR, 'v496_s1_lifecycle_publish', exc)
    try:
        return _v496_build_canonical_summary(cycle_ts, reason=reason)
    except Exception as exc:
        append_error(ERROR, 'v496_canonical_summary_publish', exc)
        return {}


_v496_prev_run_once = run_once


def run_once() -> Dict[str, Any]:  # type: ignore[override]
    cycle_ts = now_ts()
    _v454_write_phase('v498_cycle_start', 'v498: 가격반응 약한 S1 승격 방지 + post-run cache 봉인 / v495 heavy trace 제거', started_ts=cycle_ts, strategy_worker_version=VERSION)
    try:
        out = _v496_prev_run_once()
        return out
    finally:
        try:
            canonical = _v496_publish_decision_caches(cycle_ts, 'post_run_after_fresh_rows')
        finally:
            try:
                sec = round(now_ts() - cycle_ts, 3)
                extra = {'strategy_worker_version': VERSION, 'last_sec': sec}
                try:
                    if isinstance(canonical, dict) and canonical:
                        extra.update({
                            'canonical_cycle_id': canonical.get('cycle_id'),
                            'canonical_summary_schema': canonical.get('schema'),
                            'canonical_updated_ts': canonical.get('updated_ts'),
                            'candidate_reason_age_sec': (canonical.get('candidate_reason') or {}).get('age_sec') if isinstance(canonical.get('candidate_reason'), dict) else None,
                            'recheck_age_sec': (canonical.get('recheck') or {}).get('age_sec') if isinstance(canonical.get('recheck'), dict) else None,
                            's1_lifecycle_age_sec': (canonical.get('s1_lifecycle') or {}).get('age_sec') if isinstance(canonical.get('s1_lifecycle'), dict) else None,
                        })
                except Exception:
                    pass
                _v454_write_phase('cycle_done_v498', 'v498 strategy cycle 완료 / S1 가격반응 floor + lightweight cache 봉인', started_ts=cycle_ts, **extra)
            except Exception:
                pass



# =============================================================================
# strategy_worker v0.86 / v509: lane-separated canonical merge once
# - 급등 전략은 OFF하지 않는다.
# - base / spike / recheck lanes are kept separate, then merged once into one
#   canonical paper_candidates_latest source.
# - No old_latest + events re-mixing, no archive append for runtime OPEN.
# - All S1 rows pass one final_entry_gate immediately before latest write.
# =============================================================================
VERSION = "strategy_worker_v0.86"
V509_SCHEMA = "canonical_lane_merge_once_v509"
V509_TRACE = BASE_DIR / "clean_strategy_v509_lane_merge_trace.json"

_V509_CAPTURED_BASE_ROWS: List[Dict[str, Any]] = []
_V509_CAPTURED_EVALUATED: int = 0


def _v509_num(*vals: Any, default: float = 999999.0) -> float:
    for v in vals:
        try:
            if v is None or v == "" or v == [] or v == {}:
                continue
            return float(v)
        except Exception:
            continue
    return default


def _v509_stage(row: Dict[str, Any]) -> str:
    st = str((row or {}).get("s_stage") or (row or {}).get("candidate_grade") or (row or {}).get("candidate_stage") or (row or {}).get("stage") or "S3").upper()
    return st if st in {"S1", "S2", "S3"} else "S3"


def _v509_set_stage(row: Dict[str, Any], stage: str) -> Dict[str, Any]:
    out = dict(row or {})
    stage = stage if stage in {"S1", "S2", "S3"} else "S3"
    out["s_stage"] = stage
    out["candidate_grade"] = stage
    out["stage"] = stage
    out["grade"] = stage
    is_s1 = stage == "S1"
    out["paper_bot_open"] = bool(is_s1)
    out["open_eligible"] = bool(is_s1)
    out["trade_ready"] = bool(is_s1)
    out["recheck_required"] = not is_s1
    return out


def _v509_strategy_key(row: Dict[str, Any]) -> str:
    return str((row or {}).get("strategy_key") or (row or {}).get("paper_strategy_key") or (row or {}).get("strategy") or (row or {}).get("route") or "strategy_s")


def _v509_is_spike(row: Dict[str, Any]) -> bool:
    sk = _v509_strategy_key(row)
    label = str((row or {}).get("strategy_label") or (row or {}).get("strategy") or "")
    section = str((row or {}).get("section") or (row or {}).get("source") or "")
    return sk in {"spike_momentum_ride", "spike_pullback_reaccel"} or "급등" in label or section.startswith("spike")


def _v509_created(row: Dict[str, Any], default: Optional[float] = None) -> float:
    return _v509_num((row or {}).get("created_at"), (row or {}).get("candidate_created_at"), (row or {}).get("source_created_at"), (row or {}).get("detected_ts"), default=(now_ts() if default is None else default))


def _v509_srcs(row: Dict[str, Any]) -> List[Dict[str, Any]]:
    out: List[Dict[str, Any]] = []
    def add(v: Any) -> None:
        if isinstance(v, dict):
            out.append(v)
    add(row)
    for k in ("entry_context", "canonical_entry_decision", "entry_snapshot", "metrics", "entry_metrics", "orderflow", "micro", "feature", "features", "quote", "ws", "urgent_timing_trace_v509", "urgent_timing_trace_v508", "urgent_timing_trace_v504", "entry_timing_trace", "v509_final_entry_gate", "v508_final_entry_gate"):
        add((row or {}).get(k))
    for src in list(out):
        add(src.get("age_values"))
    seen=set(); clean=[]
    for d in out:
        if id(d) not in seen:
            seen.add(id(d)); clean.append(d)
    return clean


def _v509_first(row: Dict[str, Any], keys: Tuple[str, ...], default: float = 999999.0) -> float:
    for src in _v509_srcs(row):
        for k in keys:
            if isinstance(src, dict) and k in src and src.get(k) not in (None, "", [], {}):
                v = _v509_num(src.get(k), default=default)
                if v != default:
                    return v
    return default


def _v509_age_pack(row: Dict[str, Any], nowv: Optional[float] = None) -> Dict[str, float]:
    nowv = nowv or now_ts()
    hot = _v509_first(row, ("hot_signal_age_sec", "signal_age_sec", "scanner_hot_age_sec"))
    micro = _v509_first(row, ("micro_age_sec", "trade_age_sec", "micro", "trade"))
    orderflow = _v509_first(row, ("orderflow_age_sec", "orderflow", "trade_age_sec", "micro_age_sec"), default=micro)
    price = _v509_first(row, ("price_reaction_age_sec", "price_age_sec", "feature_age_sec", "reaction_age_sec", "price"))
    quote = _v509_first(row, ("quote_age_sec", "ws_age_sec", "quote", "ws"))
    paper_ts = _v509_created(row, default=0.0)
    paper_delay = max(0.0, nowv - paper_ts) if paper_ts > 1000000000 else 999999.0
    # Infer missing ages from timestamps. Do not infer missing price age to zero; missing price age is unsafe for S1.
    if hot >= 999998.0:
        ts = _v509_first(row, ("hot_signal_ts", "scanner_hot_ts", "detected_ts", "source_created_at", "created_at"), default=0.0)
        if ts > 1000000000:
            hot = max(0.0, nowv - ts)
    if micro >= 999998.0:
        ts = _v509_first(row, ("micro_updated_ts", "trade_updated_ts", "orderflow_updated_ts", "updated_ts"), default=0.0)
        if ts > 1000000000:
            micro = max(0.0, nowv - ts)
    if orderflow >= 999998.0:
        orderflow = micro
    if quote >= 999998.0:
        ts = _v509_first(row, ("quote_updated_ts", "ws_updated_ts", "updated_ts"), default=0.0)
        if ts > 1000000000:
            quote = max(0.0, nowv - ts)
    return {"hot": float(hot), "micro": float(micro), "orderflow": float(orderflow), "price": float(price), "quote": float(quote), "paper": float(paper_delay)}


def _v509_gate(row: Dict[str, Any], nowv: Optional[float] = None) -> Tuple[bool, List[str], Dict[str, float]]:
    nowv = nowv or now_ts()
    ages = _v509_age_pack(row, nowv)
    stale: List[str] = []
    if _v509_is_spike(row):
        if ages["hot"] > 45.0: stale.append(f"hot {ages['hot']:.1f}s")
        if ages["micro"] > 5.0: stale.append(f"micro {ages['micro']:.1f}s")
        if ages["orderflow"] > 5.0: stale.append(f"orderflow {ages['orderflow']:.1f}s")
        if ages["price"] > 10.0: stale.append(f"price {ages['price']:.1f}s")
        if ages["quote"] > 5.0: stale.append(f"quote {ages['quote']:.1f}s")
        if ages["paper"] > 20.0: stale.append(f"paper {ages['paper']:.1f}s")
    else:
        if ages["price"] >= 999998.0: stale.append("price_age_missing")
        elif ages["price"] > 30.0: stale.append(f"price {ages['price']:.1f}s")
        if ages["micro"] >= 999998.0: stale.append("micro_age_missing")
        elif ages["micro"] > 20.0: stale.append(f"micro {ages['micro']:.1f}s")
        if ages["quote"] >= 999998.0: stale.append("quote_age_missing")
        elif ages["quote"] > 20.0: stale.append(f"quote {ages['quote']:.1f}s")
        if ages["paper"] > 45.0: stale.append(f"paper {ages['paper']:.1f}s")
    return len(stale) == 0, stale, ages


def _v509_normalize(row: Dict[str, Any], nowv: float, lane: str) -> Dict[str, Any]:
    out = dict(row or {})
    created = _v509_created(out, default=nowv)
    if created <= 0 or created > nowv + 60:
        created = nowv
    out.setdefault("created_at", created)
    out.setdefault("candidate_created_at", created)
    out.setdefault("source_created_at", created)
    stage = _v509_stage(out)
    out = _v509_set_stage(out, stage)
    out["strategy_key"] = _v509_strategy_key(out)
    out["paper_strategy_key"] = str(out.get("paper_strategy_key") or out["strategy_key"])
    out["canonical_lane"] = lane
    out["canonical_paper_row_schema"] = V509_SCHEMA
    ttl = 55.0 if out["strategy_key"] == "spike_momentum_ride" else (180.0 if _v509_is_spike(out) else CANDIDATE_TTL_SEC)
    exp = _v509_num(out.get("expires_at"), out.get("candidate_expires_at"), default=0.0)
    if exp <= nowv:
        out["expires_at"] = nowv + ttl
    ok, stale, ages = _v509_gate(out, nowv)
    gate = {"schema": V509_SCHEMA, "version": VERSION, "lane": lane, "checked_ts": nowv, "checked_text": now_text(nowv), "age_values": ages, "stale_reasons": stale, "s1_allowed": bool(stage == "S1" and ok), "policy": "lane 분리 후 마지막 canonical merge 1회. stale S1은 S2 재확인으로 강등."}
    out["v509_final_entry_gate"] = gate
    # v508 paper_bot compatibility: paper_bot_v0.161 reads v508_final_entry_gate.
    out["v508_final_entry_gate"] = gate
    ctx = out.get("entry_context") if isinstance(out.get("entry_context"), dict) else {}
    ctx.update({"v509_final_entry_gate": gate, "v508_final_entry_gate": gate, "strategy_key": out["strategy_key"], "strategy_label": out.get("strategy_label") or out.get("strategy")})
    out["entry_context"] = ctx
    if stage == "S1" and not ok:
        out = _v509_set_stage(out, "S2")
        out["v509_downgraded_from_s1"] = True
        out["v509_stale_reasons"] = stale[:8]
        reason = "최종 신선도 gate→S2 재확인: " + " / ".join(stale[:5])
        reasons = out.get("s_stage_reasons") if isinstance(out.get("s_stage_reasons"), list) else []
        out["s_stage_reasons"] = [reason] + [str(r) for r in reasons if str(r) != reason][:8]
        out["reason"] = reason + ((" / " + str(out.get("reason"))) if out.get("reason") else "")
    elif stage != "S1":
        out = _v509_set_stage(out, stage)
    else:
        out["fresh_gate_ok"] = True
    if stage != "S1" or out.get("v509_downgraded_from_s1"):
        out["fresh_gate_ok"] = False
    return out


def _v509_key(row: Dict[str, Any]) -> str:
    t = ticker_norm((row or {}).get("ticker") or (row or {}).get("market") or (row or {}).get("symbol"))
    sk = _v509_strategy_key(row)
    eid = str((row or {}).get("event_id") or (row or {}).get("event_key") or (row or {}).get("trace_id") or (row or {}).get("candidate_uid") or "").strip()
    if eid:
        return f"{t}:{sk}:{eid}"
    created = _v509_created(row, default=now_ts())
    return f"{t}:{sk}:{int(created // 30)}"


def _v509_row_fresh(row: Dict[str, Any], nowv: float) -> bool:
    exp = _v509_num((row or {}).get("expires_at"), (row or {}).get("candidate_expires_at"), default=0.0)
    if exp > 0:
        return exp >= nowv
    cr = _v509_created(row, default=0.0)
    return cr > 0 and nowv - cr <= CANDIDATE_TTL_SEC


def _v509_write_latest_once(rows: List[Dict[str, Any]], nowv: float) -> List[Dict[str, Any]]:
    merged: Dict[str, Dict[str, Any]] = {}
    rank = {"S1": 3, "S2": 2, "S3": 1}
    for r in rows:
        if not isinstance(r, dict):
            continue
        nr = _v509_normalize(r, nowv, str(r.get("canonical_lane") or r.get("lane") or "base"))
        if not _v509_row_fresh(nr, nowv):
            continue
        k = _v509_key(nr)
        prev = merged.get(k)
        if prev is None:
            merged[k] = nr
            continue
        cur_score = (rank.get(_v509_stage(nr), 1), _v509_num(nr.get("score"), default=0.0), _v509_created(nr, default=0.0))
        prev_score = (rank.get(_v509_stage(prev), 1), _v509_num(prev.get("score"), default=0.0), _v509_created(prev, default=0.0))
        if cur_score >= prev_score:
            # Preserve alternate strategy labels for review without overwriting the winning row.
            alts = list(prev.get("alternate_strategy_rows") or []) if isinstance(prev.get("alternate_strategy_rows"), list) else []
            alts.append({"strategy_key": _v509_strategy_key(prev), "stage": _v509_stage(prev), "score": prev.get("score"), "reason": prev.get("reason")})
            nr["alternate_strategy_rows"] = alts[:8]
            merged[k] = nr
        else:
            alts = list(prev.get("alternate_strategy_rows") or []) if isinstance(prev.get("alternate_strategy_rows"), list) else []
            alts.append({"strategy_key": _v509_strategy_key(nr), "stage": _v509_stage(nr), "score": nr.get("score"), "reason": nr.get("reason")})
            prev["alternate_strategy_rows"] = alts[:8]
    out = sorted(merged.values(), key=lambda r: (rank.get(_v509_stage(r), 1), _v509_num(r.get("score"), default=0.0), _v509_created(r, default=0.0)), reverse=True)
    write_jsonl_atomic(PAPER_LATEST, out)
    return out


# Capture base lane events from the old run_once chain. Do not mix old latest/archive.
def persist_paper_handoff(events: List[Dict[str, Any]], evaluated: int = 0) -> Tuple[List[Dict[str, Any]], int]:  # type: ignore[override]
    global _V509_CAPTURED_BASE_ROWS, _V509_CAPTURED_EVALUATED
    nowv = now_ts()
    base_rows = [_v509_normalize(dict(e), nowv, "base") for e in (events or []) if isinstance(e, dict)]
    _V509_CAPTURED_BASE_ROWS = base_rows
    _V509_CAPTURED_EVALUATED = int(evaluated or 0)
    # Return the base rows to the old caller, but do not write runtime latest here.
    # The only write is done after all lanes are built in v509 run_once.
    save_json(HANDOFF, {"schema": V509_SCHEMA, "version": VERSION, "updated_ts": nowv, "updated_text": now_text(nowv), "captured_base_rows": len(base_rows), "evaluated": evaluated, "note": "v509: base lane captured. Runtime latest is written once after base/spike/recheck canonical merge."})
    return base_rows, 0


def _v509_rows_from_obj(obj: Any) -> Dict[str, Dict[str, Any]]:
    try:
        if isinstance(obj, dict):
            rows = obj.get("rows") or obj.get("items") or obj.get("markets") or obj.get("data") or obj.get("tickers") or []
        else:
            rows = obj
        out: Dict[str, Dict[str, Any]] = {}
        if isinstance(rows, dict):
            rows = list(rows.values())
        for r in rows or []:
            if not isinstance(r, dict):
                continue
            t = ticker_norm(r.get("ticker") or r.get("market") or r.get("symbol"))
            if t:
                out[t] = r
        return out
    except Exception:
        return {}


def _v509_age_from_ts(row: Dict[str, Any], nowv: float) -> float:
    ts = _v509_num(row.get("updated_ts"), row.get("ts"), row.get("timestamp"), row.get("created_at"), default=0.0)
    return max(0.0, nowv - ts) if ts > 1000000000 else 999999.0


def _v509_build_spike_lane(nowv: float) -> List[Dict[str, Any]]:
    feat_map = map_rows(load_json(FEATURE, {}) or {})
    of_map = map_rows(load_json(ORDERFLOW, {}) or {})
    rows: List[Dict[str, Any]] = []
    for t, feat in feat_map.items():
        of = of_map.get(t, {}) or {}
        ch1 = _v509_num(feat.get("change_1m_pct"), feat.get("change_1m"), feat.get("price_change_1m"), of.get("change_1m_pct"), default=0.0)
        ch3 = _v509_num(feat.get("change_3m_pct"), feat.get("change_3m"), feat.get("price_change_3m"), of.get("change_3m_pct"), default=0.0)
        react = _v509_num(of.get("price_reaction_pct"), of.get("price_recheck_pct"), feat.get("price_reaction_pct"), default=max(ch1, ch3))
        spread = _v509_num(of.get("spread_pct"), of.get("micro_spread_pct"), of.get("orderbook_spread_pct"), default=0.0)
        buy = _v509_num(of.get("buy_ratio"), of.get("buy_trade_ratio"), of.get("buy_sustain_1m"), default=0.0)
        hot_age = _v509_num(feat.get("hot_signal_age_sec"), feat.get("signal_age_sec"), default=_v509_age_from_ts(feat, nowv))
        micro_age = _v509_num(of.get("micro_age_sec"), of.get("trade_age_sec"), default=_v509_age_from_ts(of, nowv))
        order_age = _v509_num(of.get("orderflow_age_sec"), default=micro_age)
        price_age = _v509_num(of.get("price_reaction_age_sec"), feat.get("price_reaction_age_sec"), feat.get("feature_age_sec"), default=_v509_age_from_ts(feat, nowv))
        quote_age = _v509_num(of.get("quote_age_sec"), of.get("ws_age_sec"), default=micro_age)
        # Wide, non-fixed-count prefilter. It decides whether to create a spike observation row, not whether the market is scanned.
        if max(ch1, ch3, react) < 0.35:
            continue
        fresh = hot_age <= 35 and micro_age <= 5 and order_age <= 5 and price_age <= 10 and quote_age <= 5
        strong = (react >= 0.80 or ch1 >= 0.70 or ch3 >= 1.20) and buy >= 0.78 and spread <= 0.18
        stage = "S1" if fresh and strong else ("S2" if react >= 0.35 and spread <= 0.50 else "S3")
        skey = "spike_momentum_ride" if stage == "S1" and ch1 >= 0.70 else "spike_pullback_reaccel"
        label = "급등 진행형 탑승" if skey == "spike_momentum_ride" else "급등 후 눌림 재가속"
        reasons = []
        if stage == "S1":
            reasons.append("fresh urgent 급등 확인")
        elif not fresh:
            reasons.append("급등 age 재확인")
        else:
            reasons.append("눌림 재가속 재확인")
        if spread > 0.18:
            reasons.append(f"스프레드 안정 미확인({spread:.2f}%)")
        if buy < 0.70:
            reasons.append(f"매수체결 0.70 미만({buy:.2f})")
        row = {
            "schema": "paper_candidate_v509_spike_lane",
            "version": VERSION,
            "ticker": t,
            "event_id": f"{t}:{skey}:{int(nowv//10)}",
            "created_at": nowv,
            "candidate_created_at": nowv,
            "source_created_at": nowv,
            "expires_at": nowv + (55 if skey == "spike_momentum_ride" else 180),
            "strategy_key": skey,
            "paper_strategy_key": skey,
            "strategy_label": label,
            "strategy": label,
            "s_stage": stage,
            "candidate_grade": stage,
            "stage": stage,
            "score": round(100 + max(0.0, react)*10 + max(0.0, ch1)*4 + max(0.0, ch3)*3 + max(0.0, buy)*2, 3),
            "price_reaction_pct": react,
            "spread_pct": spread,
            "slippage_pct": spread,
            "buy_ratio": buy,
            "buy_sustain_1m": buy,
            "change_1m_pct": ch1,
            "change_3m_pct": ch3,
            "hot_signal_age_sec": hot_age,
            "micro_age_sec": micro_age,
            "orderflow_age_sec": order_age,
            "price_reaction_age_sec": price_age,
            "quote_age_sec": quote_age,
            "structure_tags": ["VWAP방어", "재가속확인"] if stage != "S3" else ["구조관찰"],
            "risk_tags": [] if fresh else ["신선도재확인"],
            "reason": " / ".join(reasons),
            "s_stage_reasons": reasons,
            "canonical_lane": "spike",
            "entry_context": {"strategy_key": skey, "strategy_label": label, "hot_signal_age_sec": hot_age, "micro_age_sec": micro_age, "orderflow_age_sec": order_age, "price_reaction_age_sec": price_age, "quote_age_sec": quote_age, "v509_lane": "spike", "reasons": reasons},
        }
        rows.append(_v509_normalize(row, nowv, "spike"))
    return rows


_v509_base_run_once = run_once


def run_once() -> Dict[str, Any]:  # type: ignore[override]
    global _V509_CAPTURED_BASE_ROWS
    cycle_ts = now_ts()
    _V509_CAPTURED_BASE_ROWS = []
    try:
        _v454_write_phase("v509_cycle_start", "v509: lane 분리 + canonical merge 1회 시작", started_ts=cycle_ts, strategy_worker_version=VERSION)
    except Exception:
        pass
    out: Dict[str, Any] = {}
    try:
        out = _v509_base_run_once()
    except Exception as exc:
        append_error(ERROR, "v509_base_run_once", exc)
        out = {"version": VERSION, "error": str(exc)}
    nowv = now_ts()
    base_rows = [dict(r, canonical_lane="base") for r in _V509_CAPTURED_BASE_ROWS if isinstance(r, dict)]
    spike_rows: List[Dict[str, Any]] = []
    try:
        spike_rows = _v509_build_spike_lane(nowv)
    except Exception as exc:
        append_error(ERROR, "v509_spike_lane", exc)
    final_rows = _v509_write_latest_once(base_rows + spike_rows, nowv)
    counts = {"S1": 0, "S2": 0, "S3": 0}
    lane_counts: Dict[str, int] = {}
    stale_demoted = 0
    for r in final_rows:
        counts[_v509_stage(r)] = counts.get(_v509_stage(r), 0) + 1
        lane = str(r.get("canonical_lane") or "base")
        lane_counts[lane] = lane_counts.get(lane, 0) + 1
        if r.get("v509_downgraded_from_s1"):
            stale_demoted += 1
    trace = {"schema": V509_SCHEMA, "version": VERSION, "updated_ts": nowv, "updated_text": now_text(nowv), "evaluated": _V509_CAPTURED_EVALUATED, "base_rows": len(base_rows), "spike_rows": len(spike_rows), "latest_count": len(final_rows), "stage_counts": counts, "lane_counts": lane_counts, "stale_demoted": stale_demoted, "elapsed_sec": round(now_ts() - cycle_ts, 3), "sample": final_rows[:12], "policy": "base/spike/recheck lane을 분리하고 마지막에 canonical latest를 1회 저장. old_latest 재혼합/archive append 없음."}
    save_json(V509_TRACE, trace)
    save_json(HANDOFF, {"schema": V509_SCHEMA, "version": VERSION, "updated_ts": nowv, "updated_text": now_text(nowv), "latest_count": len(final_rows), "evaluated": _V509_CAPTURED_EVALUATED, "stage_counts": counts, "lane_counts": lane_counts, "stale_demoted": stale_demoted, "note": "v509: runtime paper handoff is paper_candidates_latest only; no old_latest re-mix, no archive append."})
    try:
        sm = load_json(SUMMARY, {}) or {}
        if isinstance(sm, dict):
            sm.update({"version": VERSION, "paper_latest_count": len(final_rows), "s_stage_counts": counts, "s1_count": counts.get("S1", 0), "s2_count": counts.get("S2", 0), "s3_count": counts.get("S3", 0), "v509_lane_merge": {k: trace.get(k) for k in ("schema", "version", "evaluated", "base_rows", "spike_rows", "latest_count", "stage_counts", "lane_counts", "stale_demoted", "elapsed_sec", "policy")}})
            save_json(SUMMARY, sm)
    except Exception as exc:
        append_error(ERROR, "v509_summary", exc)
    try:
        if '_v496_publish_decision_caches' in globals():
            _v496_publish_decision_caches(cycle_ts, "v509_after_single_canonical_merge")
    except Exception as exc:
        append_error(ERROR, "v509_publish_decision_caches", exc)
    try:
        _v454_write_phase("cycle_done_v509", "v509 strategy cycle 완료 / lane 분리 + canonical merge 1회", started_ts=cycle_ts, strategy_worker_version=VERSION, last_sec=round(now_ts()-cycle_ts,3), latest_count=len(final_rows), s1_count=counts.get("S1",0), s2_count=counts.get("S2",0), s3_count=counts.get("S3",0))
    except Exception:
        pass
    if isinstance(out, dict):
        out.update({"version": VERSION, "v509_lane_merge": trace})
    return out


# v509 final entrypoint: loaded after lane merge surgery.
if __name__ == "__main__":
    main()
