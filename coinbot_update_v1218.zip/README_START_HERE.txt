코인봇 업데이트 v1218
======================
목적: v1217 후보 증거 저장 중 structure_contract_v1212 hard ceiling로 Strategy가 매 cycle 실패한 오류 수리.

적용 순서
1) 가드봇에서 /gupgrade_bundle 단독 실행
2) 가드 재시작·자동 적용 완료 후 새 Strategy 완료 cycle 대기
3) 아래 명령 실행
   /gstructure_missing_audit
   /gs1_zero_audit
   /gdeploy

정상 기준
- Strategy: strategy_worker_v1.048 / err - / evaluated 약 463
- Guard: guard_v2.5.215_v1218_candidate_ceiling_repair_audit_2026-07-04
- writer exact True
- diag expected=compact=encoded 같은 수
- rows·cycle·누락건수 일치 True
- ValueError hard ceiling 재발 0

주의
- 자동매수 OFF
- 전략 기준·ATR·RR·청산·기존 OPEN 변경 없음
- 서버 증거 전 상태는 CHECK
