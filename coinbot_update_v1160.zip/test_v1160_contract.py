#!/usr/bin/env python3
from pathlib import Path
import ast, hashlib, json, os, tempfile, threading
from typing import Any, Dict, Optional, Tuple, List
ROOT=Path(__file__).resolve().parent
P=ROOT/'paper_bot_v1.034.py'; M=ROOT/'coinbot_main_v2_13_1120.py'
for x in (P,M): compile(x.read_text(),str(x),'exec')

def funcs(path: Path):
    mod=ast.parse(path.read_text())
    return {n.name:n for n in mod.body if isinstance(n,ast.FunctionDef)}

def run_fn_nodes(nodes, ns, filename):
    exec(compile(ast.Module(body=nodes,type_ignores=[]),filename,'exec'),ns)

def num(*vals,default=0.0):
    for v in vals:
        try:
            if v not in (None,''): return float(v)
        except Exception: pass
    return default

pf=funcs(P)
# Trading/safety contracts unrelated to same-handoff consumption remain AST-identical to v1159.
fixture=json.loads((ROOT/'tests/fixtures/V1160_UNCHANGED_TRADING_AST_SHA256.json').read_text())
for name,digest in fixture['paper'].items():
    actual=hashlib.sha256(ast.dump(pf[name],include_attributes=False).encode()).hexdigest()
    assert actual==digest,(name,actual,digest)

with tempfile.TemporaryDirectory() as td:
    td=Path(td); state=td/'state.json'; ledger=td/'events.jsonl'; clock=[100.0]
    def now_ts(): clock[0]+=1.0; return clock[0]
    def load_json(path,default=None):
        try:return json.loads(Path(path).read_text())
        except Exception:return default
    def atomic(path,obj):
        path=Path(path); path.parent.mkdir(parents=True,exist_ok=True); tmp=path.with_suffix('.tmp')
        with tmp.open('w',encoding='utf-8') as h:
            json.dump(obj,h,separators=(',',':')); h.flush(); os.fsync(h.fileno())
        os.replace(tmp,path)
    def tail_lines(path,max_lines):
        try:return Path(path).read_text().splitlines()[-max_lines:]
        except Exception:return []
    def gate(row): return row.get('gate',{}) if isinstance(row,dict) else {}
    def decision_key(row,g): return str(g.get('swing_gate_decision_key_v977') or row.get('decision_key') or '')
    ns={'Dict':Dict,'Any':Any,'Path':Path,'threading':threading,'hashlib':hashlib,'json':json,'os':os,
        'V1159_TRIGGER_TERMINAL_FEEDBACK_STATE':state,'V1159_TRIGGER_TERMINAL_FEEDBACK_LEDGER':ledger,
        '_V1159_TRIGGER_TERMINAL_FEEDBACK_LOCK':threading.RLock(),'V1159_TRIGGER_TERMINAL_FEEDBACK_MAX_RECORDS':5000,
        'read_strategy_entry_gate':gate,'read_strategy_decision_key':decision_key,'fnum':num,
        'normalize_ticker':lambda x:str(x or '').replace('KRW-','').upper(),'now_ts':now_ts,'iso_ts':lambda ts:f'T{ts}',
        'tail_lines':tail_lines,'log_error':lambda *a,**k:None,'_atomic_write_small_json_v994':atomic,'load_json':load_json,
        'VERSION':'paper_bot_v1.034','BUILD_LABEL':'v1160'}
    run_fn_nodes([
        pf['_v1159_trigger_terminal_identity'],pf['_v1159_feedback_event_exists'],pf['_v1159_append_feedback_event_once'],
        pf['_v1159_save_feedback_state'],pf['_v1160_existing_terminal_feedback'],pf['_v1159_record_trigger_terminal_feedback']
    ],ns,str(P))
    proof={'code':'STALE_TRIGGER_OCCURRENCE','event_ts':10.0,'decision_key':'D1','ttl_sec':120,'age_sec':500}
    ev1={'ticker':'KRW-AAA','candidate_pipeline_cycle_id_v1150':'CYCLE-1','paper_consumed_handoff_id_v1158':'H1',
         'gate':{'swing_gate_decision_key_v977':'D1','trigger_occurrence_v1037':{'decision_key':'D1','event_ts':10.0,'candidate_key':'C1'}}}
    first=ns['_v1159_record_trigger_terminal_feedback'](ev1,proof)
    assert first['recorded'] and first['exposure_count']==1 and first['distinct_handoff_count_v1160']==1
    same=ns['_v1160_existing_terminal_feedback'](ev1)
    assert same['suppress'] is True and same['state']=='SAME_COMPLETED_HANDOFF_ALREADY_TERMINAL'
    # Same completed handoff is never written/evaluated again.
    assert len(ledger.read_text().splitlines())==1
    # Different handoff carrying the same exact event is a true Strategy republish, not hidden.
    ev2=dict(ev1); ev2['candidate_pipeline_cycle_id_v1150']='CYCLE-2'; ev2['paper_consumed_handoff_id_v1158']='H2'
    rep=ns['_v1160_existing_terminal_feedback'](ev2)
    assert rep['suppress'] is False and rep['state']=='NEW_HANDOFF_SAME_EVENT_REPUBLISH'
    second=ns['_v1159_record_trigger_terminal_feedback'](ev2,proof)
    assert second['true_new_handoff_republish_v1160'] is True and second['exposure_count']==2 and second['distinct_handoff_count_v1160']==2
    # Append-only event ledger still has one exact terminal event row.
    assert len(ledger.read_text().splitlines())==1
    # v1159 migration fallback: old state with only pipeline_cycle_id can suppress the same generation.
    old=json.loads(state.read_text()); r=old['records']['D1']; r.pop('first_handoff_id_v1160',None); r.pop('paper_consumed_handoff_id_v1158',None); r.pop('first_pipeline_cycle_id_v1160',None); r['pipeline_cycle_id']='CYCLE-2'; old['records']['D1']=r; atomic(state,old)
    ev3=dict(ev2); ev3.pop('paper_consumed_handoff_id_v1158',None)
    mig=ns['_v1160_existing_terminal_feedback'](ev3)
    assert mig['suppress'] is True

pt=P.read_text(); mt=M.read_text()
# Suppression must occur before PAPER_RECEIVED/s1 accounting.
pos_check=pt.index("terminal_consumption_v1160 = _v1160_existing_terminal_feedback(ev)")
pos_seen=pt.index("stats['s1_seen'] = int(stats.get('s1_seen', 0)) + 1",pos_check)
pos_recv=pt.index("_v1153_paper_event_once('PAPER_RECEIVED'",pos_check)
assert pos_check < pos_seen < pos_recv
assert "VERSION = 'paper_bot_v1.034'" in pt and 'v1160_terminal_handoff_dedup_and_ledger_board' in pt
assert "BOT_VERSION = '수익형 v2.13.1120'" in mt and "EXPECTED_PAPER_VERSION = 'paper_bot_v1.034'" in mt
assert 'guard_v2.5.193_stale_occurrence_lifecycle_map_v1159_2026-06-30' in mt
assert 'strategy_worker_v1.022' in mt
assert 'V1160_ROADMAP_ISSUES' in mt and 'render_readiness_board_text' in mt
for text in ('Strategy 계산 60초 지연','놓친 큰 상승률 exact 추적','후보 기준판 원천 7개 연결','큰 수익 1건 제외 기대값 검증','실매매 시작 관문'):
    assert text in mt
# Unchanged Guard/Strategy are expected by Main and omitted from the deploy sources.
assert "EXPECTED_GUARD_VERSION = 'guard_v2.5.193_stale_occurrence_lifecycle_map_v1159_2026-06-30'" in mt
assert "EXPECTED_STRATEGY_VERSION = 'strategy_worker_v1.022'" in mt
print('PASS v1160 contract')
