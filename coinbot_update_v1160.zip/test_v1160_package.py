#!/usr/bin/env python3
from pathlib import Path
import json, zipfile, hashlib, sys
zip_path=Path(sys.argv[1]) if len(sys.argv)>1 else Path(__file__).resolve().parent/'coinbot_update_v1160.zip'
assert zip_path.exists(),zip_path
with zipfile.ZipFile(zip_path) as z:
    names=z.namelist()
    assert 'coinbot_main_v2_13_1120.py' in names
    assert 'paper_bot_v1.034.py' in names
    assert not any('backga_guard_bot' in n for n in names)
    assert not any('strategy_worker' in n and n.endswith('.py') for n in names)
    forbidden=('paper_bot_open.json','paper_bot_closed.jsonl','trade_log','decision','exact','change_verify_ledger','issue_ledger','.pyc','__pycache__')
    for n in names:
        assert not any(x in n for x in forbidden),(n,forbidden)
    manifest=json.loads(z.read('DEPLOY_BUNDLE.json'))
    assert manifest['main']=='coinbot_main_v2_13_1120.py'
    assert manifest['paper']=='paper_bot_v1.034.py'
    assert manifest.get('guard') is None and manifest.get('workers')=={}
    assert manifest['guard_restart_required'] is False and manifest['strategy_restart_required'] is False
    assert manifest['auto_buy'] is False and manifest['live_ledger_included'] is False
    assert manifest['quality_formula_change'] is False and manifest['candidate_ttl_change'] is False
    rows=z.read('FILES_SHA256_v1160.tsv').decode().splitlines()
    expected={line.split('\t',1)[1]:line.split('\t',1)[0] for line in rows if '\t' in line}
    for n,d in expected.items():
        assert hashlib.sha256(z.read(n)).hexdigest()==d,n
print('PASS v1160 package')
