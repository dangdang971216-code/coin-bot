# v1160 원인과 수정

## 확정 원인
v1158 이후 Paper는 Strategy가 다음 generation을 만드는 동안 직전 completed handoff를 계속 읽는다.
Paper cycle은 약 1초, Strategy cycle은 최대 60초였으므로 같은 ADA stale 사건을 같은 handoff에서 다시 평가했다.
이 반복은 Strategy가 새로 재게시한 것이 아니지만 v1159 exposure_count에는 반복으로 잡혔다.

## 수정
- decision key + trigger event time + completed handoff ID를 함께 비교한다.
- 같은 handoff의 이미 terminal 처리된 exact 사건은 Paper receive·freshness·funnel·terminal 계산 전에 건너뛴다.
- 다른 handoff가 같은 exact 사건을 다시 싣는 경우는 숨기지 않고 실제 Strategy 재게시로 기록한다.
- Strategy 코드는 이번 버전에서 변경하지 않았다.

## 매매 영향
- 오래된 사건의 중복 평가만 제거한다.
- Gate, TTL, RR, 구조선, 진입, 청산, OPEN 제한은 그대로다.
- 자동매수 OFF다.
