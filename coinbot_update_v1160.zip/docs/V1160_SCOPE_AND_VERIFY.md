# v1160 범위와 서버 검수

## 변경 범위
- Paper: 같은 completed handoff exact terminal 재소비 억제
- Main: 로드맵 issue seed, 한글 우선순위 장부, 자동매매 준비판

## 변경하지 않음
- Guard v2.5.193
- Strategy v1.022
- 모든 전략 수치와 청산 계약

## 서버 DONE 기준
1. Paper v1.034, Main v2.13.1120 exact runtime/hash.
2. 같은 handoff stale 사건은 Paper 반복 노출 0.
3. 새 handoff가 같은 사건을 다시 싣는 경우만 실제 재게시 1 이상.
4. /issue_ledger가 빨강·노랑·초록 한글 한 줄판으로 표시.
5. /readiness_board가 자동매매 단계별 남은 일을 표시.
6. 신규 오류 0, 자동매수 OFF.
