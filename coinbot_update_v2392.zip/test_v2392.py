import ast
import hashlib
import importlib.util
import json
import os
import pathlib
import py_compile
import shutil
import tempfile
import time

ROOT=pathlib.Path(__file__).resolve().parent
MAIN=ROOT/'coinbot_main_v2_13_2237.py'
py_compile.compile(str(MAIN),doraise=True)
ast.parse(MAIN.read_text(encoding='utf-8'))

def load_temp_main():
    base=pathlib.Path(tempfile.mkdtemp(prefix='main_v2392_'))
    target=base/'coinbot_main_v2_13_2237.py'
    shutil.copy2(MAIN,target)
    spec=importlib.util.spec_from_file_location('main_v2392',target)
    mod=importlib.util.module_from_spec(spec)
    spec.loader.exec_module(mod)
    mod.BASE_DIR=base
    return mod,base

main,base=load_temp_main()

paper={
  'version':'paper_bot_v2.142','build':'paper-build','running':True,
  'telegram_command':{'state':'READY'},
  'clean_v2_status':{
    'performance':{'open_count':3,'closed_count':4},
    'last_nonzero_s1_attempt_v2158':{
      'paper_processed_candidate_commit_id_v2176':'commit-v2392',
      'paper_processed_s1_generation_id_v2176':'generation-v2392',
      'strategy_s1_received_v2158':2,
      's1_terminal_accounted_v2158':2,
      'enrolled':1,
      's1_terminal_counts_v2158':{'OPENED':1,'EXECUTION_WAIT':1},
      's1_terminal_rows_v2158':[
        {'ticker':'AAA','terminal':'OPENED','reasons':[]},
        {'ticker':'BBB','terminal':'EXECUTION_WAIT','reasons':['TTL_WAIT']},
      ],
    },
  },
}
(base/'paper_bot_status.json').write_text(json.dumps(paper,ensure_ascii=False),encoding='utf-8')
read=main.read_paper_status()
assert read['paper_status_owner']=='paper_bot_status.json:clean_v2_status'
assert read['last_nonzero_s1_attempt_v2158']['s1_terminal_accounted_v2158']==2
truth={'commit':'commit-v2392','generation':'generation-v2392','receipt_count':2,'paper_match':True}
s1=main._current_paper_s1_truth(truth)
assert s1['state']=='PASS'
assert s1['received']==2 and s1['accounted']==2 and s1['enrolled']==1
assert len(s1['rows'])==2

now=time.time()
candle={
  'version':'candle_worker_v2.031','updated_ts':now,
  'collection_proof':{
    'proof_updated_ts':now,'runtime_version':'candle_worker_v2.031',
    'selected_count':422,'ticker_full_success':420,'ticker_partial_success':0,'ticker_no_success':2,
    'thread_exception_count':0,
    'planned_due_frame_count_v2389':146,'planned_due_attempted_count_v2389':146,
    'planned_due_unattempted_count_v2389':0,
    'failure_samples':[{'ticker':'ES','failed':['m30','h1']}],
  },
}
(base/'clean_candle_status.json').write_text(json.dumps(candle,ensure_ascii=False),encoding='utf-8')
current=main.read_candle_collection_truth()
assert current['state']=='PASS' and current['unattempted']==0
lines='\n'.join(main._candle_collection_lines({'price_acceleration_30m:REFRESH_DUE_NOT_ATTEMPTED':34,'price_acceleration_1h:REFRESH_DUE_NOT_ATTEMPTED':14}))
assert '현재 Candle은 계획분 전부 시도 PASS' in lines
assert 'Strategy 봉인 당시 미시도 표기 48건' in lines
assert '값 재계산 0' in lines

assert hashlib.sha256((ROOT/'bot.py').read_bytes()).hexdigest()==hashlib.sha256(MAIN.read_bytes()).hexdigest()
source=MAIN.read_text(encoding='utf-8')
assert "MAIN_VERSION='수익형 v2.13.2237'" in source
assert "BUILD='paper_terminal_and_candle_collection_truth_2026-08-02'" in source

print(json.dumps({
  'compile_ast':'PASS',
  'paper_nested_terminal_reader':'PASS',
  'paper_s1_terminal_state':s1['state'],
  'paper_s1_accounted':s1['accounted'],
  'candle_current_collection_state':current['state'],
  'candle_planned':current['planned'],
  'candle_attempted':current['attempted'],
  'candle_unattempted':current['unattempted'],
  'strategy_snapshot_and_current_candle_split':'PASS',
  'main_alias':'PASS',
  'auto_buy':False,
},ensure_ascii=False))
