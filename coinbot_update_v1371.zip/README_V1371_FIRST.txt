v1371 is diagnostic only. It adds /gpaper_ttl_audit to Guard to inspect Strategy→paper_s1_hold_cache→Paper TTL evidence. No strategy thresholds, exits, Paper execution, or ledgers are changed.
