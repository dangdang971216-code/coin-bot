v1463_TRIGGER_SELECTOR_S2_RECHECK_PROTECTION_AUDIT_AUTOBUY_OFF_2026-07-11

목적:
- v1462 trigger selector 본체 적용을 유지한다.
- trigger 통과 후 RR/비용/목표공간 부족 후보는 폐기하지 않고 S2_RECHECK/WATCH로 보존한다.
- PEAQ 같은 큰 손실은 새 청산보호가 적용됐는지 감사만 한다.

변경하지 않음:
- 자동매수 OFF
- trigger 공식 변경 없음
- RR 기준 변경 없음
- target/invalid 공식 변경 없음
- 후보 기준 완화 없음
- S1/BUY_READY/OPEN 강제 없음
- stale TTL 완화 없음
- 청산계약 변경 없음
- 기존 OPEN/과거 CLOSED 재계산 없음

검수:
- /trigger_selector
- /s2_recheck
- /protection_audit
- /trigger_sync
- /snapshot_restore
- /contract_restore
- /candidate_flow
- /version_score
- /errorlog
