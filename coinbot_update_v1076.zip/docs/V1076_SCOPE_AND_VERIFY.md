# v1076 자원 owner·병목 원인 감사

## 상태

- 기준: v1075 CORE V2 DONE
- 신규 버전: v1076
- 로컬 상태: **CHECK** — 서버 runtime 표본 전에는 원인 확정 및 DONE 금지
- 전략모드: ALT_SWING
- 자동매수: OFF

## 증상

- Paper canonical RSS와 Paper self-sample 사이에 큰 차이가 보고됨.
- Strategy cycle 약 27초, CPU 약 90% 이상.
- Review·Candle RSS가 높고 대형 trace가 계속 증가함.

## 코드에서 확인한 측정 공백

1. Strategy는 이미 단계별 wall/CPU profile을 기록한다.
2. Review는 단계별 시간·RSS·I/O·메모리 회수 정보를 기록한다.
3. Paper는 기존에는 cycle/exit 전체 시간 중심이라 세부 phase별 RSS·I/O owner를 구분하기 부족했다.
4. Guard는 process RSS를 canonical 값으로 읽었지만 cgroup page cache, 같은 서비스의 추가 PID, anon/file RSS를 한 번에 분해하지 않았다.

## v1076 수정

### Paper v1.001

기존 phase 전환을 관찰하여 다음만 상태에 추가한다.

- phase별 wall/CPU
- phase 시작·종료 RSS와 증감
- read/write bytes, rchar/wchar
- RssAnon/RssFile/RssShmem
- smaps_rollup의 PSS/Anonymous/File 계열

기존 진입·청산·원장 commit 함수 본문은 수정하지 않았다.

### Guard v2.5.131

`/gresource_owner 20` 명령을 추가했다.

- Paper·Strategy·Review·Candle MainPID와 cgroup 비교
- process RSS를 anon/file로 분리
- cgroup file page와 추가 process RSS 확인
- `/proc/<pid>/io`, fd, 삭제 후 열린 파일 확인
- 기존 Strategy·Review profile을 같은 보고서에서 읽기
- 알려진 대형 trace 20초 증감 측정
- 서버에서 명령 실행 시 issue OPEN / change CHECK를 append-once로 기록

## 변경하지 않은 것

- RR·trigger·invalid·target·spread·slippage
- trailing·시간청산
- 전체 OPEN 한도·cycle 신규 OPEN 한도
- 후보/S1/S2/S3·진입방식 차단
- OPEN/CLOSED/decision/exact 원장
- Risk·Strategy·Review·Main 소스
- 자동매수 OFF

## 판정 기준

v1076은 원인을 자동으로 고치는 버전이 아니다. 서버 표본에서 가장 큰 실제 owner를 확정한 뒤 v1077에서 원인 1개만 수정한다.

- 서버 미검증: CHECK
- 일부 runtime만 확인: PARTIAL
- 적용 실패: FAIL
- 실제 runtime·다음 cycle·원장·오류까지 증명: DONE
