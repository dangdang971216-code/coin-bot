v2140은 /version_score 표시만 수정합니다. 새 전략 exact 현재 성과를 핵심판의 주 성과로 사용하고, 구조·예측 문제는 짧게 표시합니다. Main만 변경하며 Paper·Guard·worker·전략수치·진입·청산·원장을 변경하지 않습니다. 자동매수 OFF입니다.
