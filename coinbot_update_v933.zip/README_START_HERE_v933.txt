v933 적용: /gupgrade_bundle
메인 검수: /batch
가드 성능감사 필요 시 별도: /gdeep_audit 20
