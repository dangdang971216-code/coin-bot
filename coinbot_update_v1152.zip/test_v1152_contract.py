#!/usr/bin/env python3
from __future__ import annotations
import ast, importlib.util, json, tempfile, time
from pathlib import Path

ROOT=Path(__file__).resolve().parent

def load(name,path):
    spec=importlib.util.spec_from_file_location(name,str(path)); mod=importlib.util.module_from_spec(spec); assert spec.loader; spec.loader.exec_module(mod); return mod

def fn_ast(path,name):
    tree=ast.parse(Path(path).read_text(encoding='utf-8'))
    for node in tree.body:
        if isinstance(node,(ast.FunctionDef,ast.AsyncFunctionDef)) and node.name==name:
            return ast.dump(node,include_attributes=False)
    raise AssertionError(f'missing {name}')

def final_assign(path,name):
    tree=ast.parse(Path(path).read_text(encoding='utf-8')); val=None
    for node in tree.body:
        if isinstance(node,ast.Assign):
            for target in node.targets:
                if isinstance(target,ast.Name) and target.id==name:
                    try: val=ast.literal_eval(node.value)
                    except Exception: pass
    return val

strategy=load('strategy_v1152',ROOT/'strategy_worker_v1.019.py')
paper=load('paper_v1152',ROOT/'paper_bot_v1.028.py')
main=load('main_v1152',ROOT/'coinbot_main_v2_13_1113.py')

# 1) current progress preserves last completed proof.
with tempfile.TemporaryDirectory() as td:
    strategy.STRATEGY_PIPELINE_COMMIT_V1150=Path(td)/'commit.json'
    done=strategy._v1150_write_pipeline_status('cycle-old','NORMAL',candidate_commit_id='commit-old',s1_hold_count=3,candidate_rows=460,priority_request_count=20,all_required_commits_v1150=True,completed_ts_v1152=1000.0)
    progress=strategy._v1150_write_pipeline_status('cycle-new','STARTED',cycle_started_ts=1010.0,last_completed_step='KEYS_AND_OBSERVATION_DONE')
    assert progress['progress_state_v1152']=='IN_PROGRESS'
    assert progress['last_complete_cycle_v1152']['cycle_id']=='cycle-old'
    assert progress['last_complete_cycle_v1152']['candidate_commit_id']=='commit-old'

# 2) timing path exact segment math.
ev={
    'ticker':'KRW-TEST','candidate_pipeline_cycle_id_v1150':'cycle-1','candidate_pipeline_cycle_started_ts_v1152':110.0,
    'swing_entry_gate_v977':{'trigger_occurrence_v1037':{'event_ts':100.0,'rebreak_ts':100.0,'decision_key':'d1','qualification_state':'QUALIFIED_EVENT','contract_ready_at_cross':True}},
}
pipe={'cycle_id':'cycle-1','candidate_commit_id':'c1','cycle_started_ts':110.0,'s1_hold_completed_ts_v1152':115.0,'candidate_snapshot_completed_ts_v1152':118.0,'priority_requests_completed_ts_v1152':120.0}
path=paper.candidate_delay_path_v1152(ev,pipe,{'candidate_ttl_sec':15.0},paper_ts=130.0)
assert path['segments']['trigger_to_strategy_start_sec']==10.0
assert path['segments']['strategy_start_to_s1_sec']==5.0
assert path['segments']['s1_to_candidate_snapshot_sec']==3.0
assert path['segments']['candidate_snapshot_to_priority_sec']==2.0
assert path['segments']['priority_to_paper_sec']==10.0
assert path['total_trigger_to_paper_sec']==30.0 and path['expired_by_sec']==15.0
stats={}; paper._v1152_record_delay_summary(stats,path,'STALE_TRIGGER_OCCURRENCE')
assert stats['trigger_delay_path_summary_v1152']['stale_count']==1

# 3) Main must not let Paper previous ready override Guard in-progress.
orig=main.load_json
def fake_load(path,default=None):
    name=Path(path).name
    if name=='ops_map_snapshot.json':
        return {'reader_owner_contracts_v1150':{'candidate_pipeline':{
            'state':'CHECK','progress_state_v1152':'IN_PROGRESS','cycle_id':'cycle-new','age_sec':2.0,
            'last_completed_step':'S1_HOLD','failed_step':None,'s1_hold_count':3,'candidate_rows':None,'priority_request_count':None,
            'last_complete_cycle_v1152':{'cycle_id':'cycle-old','state':'NORMAL','s1_hold_count':4},'last_complete_age_sec_v1152':15.0,
        }}}
    if name=='paper_bot_status.json':
        return {'strategy_candidate_pipeline_v1150':{'ready':True,'state':'NORMAL','cycle_id':'cycle-old'}}
    return default
main.load_json=fake_load
text='\n'.join(main._v1151_plain_pipeline_lines())
main.load_json=orig
assert '🟡 현재 cycle 진행 중' in text
assert '✅ 정상' not in text
assert '직전 정상 cycle: cycle-old' in text

# 4) Version/build identity.
assert final_assign(ROOT/'strategy_worker_v1.019.py','VERSION')=='strategy_worker_v1.019'
assert final_assign(ROOT/'paper_bot_v1.028.py','VERSION')=='paper_bot_v1.028'
assert final_assign(ROOT/'coinbot_main_v2_13_1113.py','BOT_VERSION')=='수익형 v2.13.1113'
assert 'guard_v2.5.189' in (final_assign(ROOT/'backga_guard_bot_v2_5_189.py','VERSION') or '')

# 5) Trading formulas remain AST-identical where diagnostics are not intended to change behavior.
old_strategy=ROOT.parent/'v1150'/'strategy_worker_v1.018.py'
old_paper=ROOT.parent/'v1150'/'paper_bot_v1.027.py'
for fn in ('apply_swing_entry_gate','_v925_current_actual_plan'):
    assert fn_ast(old_strategy,fn)==fn_ast(ROOT/'strategy_worker_v1.019.py',fn), fn
for fn in ('trigger_occurrence_freshness_v1133','paper_final_safety','open_position__L23309'):
    assert fn_ast(old_paper,fn)==fn_ast(ROOT/'paper_bot_v1.028.py',fn), fn

# 6) No forbidden behavior switches.
all_text='\n'.join((ROOT/f).read_text(encoding='utf-8') for f in ('strategy_worker_v1.019.py','paper_bot_v1.028.py','backga_guard_bot_v2_5_189.py','coinbot_main_v2_13_1113.py'))
assert 'auto_buy\': True' not in all_text and '"auto_buy": true' not in all_text.lower()
print(json.dumps({'status':'PASS','progress_truth':True,'delay_path':True,'main_no_ready_override':True,'trading_formula_ast_same':True,'auto_buy':False},ensure_ascii=False))
