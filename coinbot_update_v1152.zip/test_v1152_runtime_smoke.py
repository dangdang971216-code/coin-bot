#!/usr/bin/env python3
from __future__ import annotations
import importlib.util, json, tempfile
from pathlib import Path
ROOT=Path(__file__).resolve().parent

def load(name,path):
    spec=importlib.util.spec_from_file_location(name,str(path)); mod=importlib.util.module_from_spec(spec); assert spec.loader; spec.loader.exec_module(mod); return mod

strategy=load('strategy_smoke_v1152',ROOT/'strategy_worker_v1.019.py')
paper=load('paper_smoke_v1152',ROOT/'paper_bot_v1.028.py')
main=load('main_smoke_v1152',ROOT/'coinbot_main_v2_13_1113.py')

with tempfile.TemporaryDirectory() as td:
    td=Path(td)
    # Strategy progress truth sequence.
    strategy.STRATEGY_PIPELINE_COMMIT_V1150=td/'strategy_candidate_pipeline_commit_v1150.json'
    strategy._v1150_write_pipeline_status('old','NORMAL',candidate_commit_id='old-c',s1_hold_count=2,candidate_rows=10,priority_request_count=5,all_required_commits_v1150=True,completed_ts_v1152=100.0)
    a=strategy._v1150_write_pipeline_status('new','STARTED',cycle_started_ts=110.0,candidate_rows=10,priority_request_count=5,last_completed_step='KEYS_AND_OBSERVATION_DONE')
    b=strategy._v1150_write_pipeline_status('new','S1_HOLD_COMMITTED',s1_hold_count=3,s1_hold_completed_ts_v1152=115.0,last_completed_step='S1_HOLD')
    c=strategy._v1150_write_pipeline_status('new','CANDIDATE_COMMITTED',candidate_rows=10,candidate_commit_id='new-c',candidate_snapshot_completed_ts_v1152=118.0,last_completed_step='CANDIDATE_SNAPSHOT')
    d=strategy._v1150_write_pipeline_status('new','NORMAL',priority_request_count=5,priority_requests_completed_ts_v1152=120.0,completed_ts_v1152=120.0,all_required_commits_v1150=True,last_completed_step='PRIORITY_REQUESTS')
    assert a['last_complete_cycle_v1152']['cycle_id']=='old'
    assert b['cycle_started_ts']==110.0 and b['last_complete_cycle_v1152']['cycle_id']=='old'
    assert c['s1_hold_completed_ts_v1152']==115.0
    assert d['last_complete_cycle_v1152']['cycle_id']=='new' and d['progress_state_v1152']=='COMPLETE'

    # Paper same-cycle gate + timing evidence.
    paper.STRATEGY_PIPELINE_COMMIT_V1150=td/'strategy_candidate_pipeline_commit_v1150.json'
    paper.FILES['s1_hold']=td/'paper_s1_hold_cache.json'
    (td/'paper_s1_hold_cache.json').write_text(json.dumps({'candidate_pipeline_cycle_id_v1150':'new','rows':[]}),encoding='utf-8')
    (td/'clean_strategy_paper_latest_writer_status.json').write_text(json.dumps({'candidate_snapshot_scope':{'pipeline_cycle_id_v1150':'new'}}),encoding='utf-8')
    (td/'clean_strategy_priority_requests.json').write_text(json.dumps({'candidate_pipeline_cycle_id_v1150':'new','candidate_commit_id_v1150':'new-c'}),encoding='utf-8')
    # Repoint BASE_DIR-derived reads by monkeypatching load_json paths through files in temp.
    old_base=paper.BASE_DIR; paper.BASE_DIR=td
    gate=paper.strategy_candidate_pipeline_ready_v1150({'candidate_ttl_sec':120})
    paper.BASE_DIR=old_base
    assert gate['ready'] is True and gate['cycle_id']=='new'
    ev={'ticker':'KRW-X','candidate_pipeline_cycle_id_v1150':'new','candidate_pipeline_cycle_started_ts_v1152':110.0,
        'swing_entry_gate_v977':{'trigger_occurrence_v1037':{'event_ts':80.0,'rebreak_ts':80.0,'decision_key':'d','qualification_state':'QUALIFIED_EVENT','contract_ready_at_cross':True}}}
    path=paper.candidate_delay_path_v1152(ev,gate,{'candidate_ttl_sec':20},paper_ts=130.0)
    assert path['total_trigger_to_paper_sec']==50.0 and path['largest_segment']=='trigger_to_strategy_start_sec'

# Main complete/in-progress labels.
orig=main.load_json
def make_loader(progress):
    def loader(path,default=None):
        if Path(path).name=='ops_map_snapshot.json':
            return {'reader_owner_contracts_v1150':{'candidate_pipeline':progress}}
        if Path(path).name=='paper_bot_status.json': return {'strategy_candidate_pipeline_v1150':{'ready':True}}
        return default
    return loader
main.load_json=make_loader({'state':'CHECK','progress_state_v1152':'IN_PROGRESS','cycle_id':'new','age_sec':3,'last_completed_step':'S1_HOLD','s1_hold_count':3,'candidate_rows':10,'priority_request_count':5,'last_complete_cycle_v1152':{'cycle_id':'old','s1_hold_count':2},'last_complete_age_sec_v1152':20})
progress_text='\n'.join(main._v1151_plain_pipeline_lines())
assert '🟡 현재 cycle 진행 중' in progress_text and '전체 후보목록 저장' in progress_text and '✅ 정상' not in progress_text
main.load_json=make_loader({'state':'NORMAL','progress_state_v1152':'COMPLETE','cycle_id':'new','age_sec':1,'last_completed_step':'PRIORITY_REQUESTS','s1_hold_count':3,'candidate_rows':10,'priority_request_count':5,'last_complete_cycle_v1152':{'cycle_id':'new','s1_hold_count':3},'last_complete_age_sec_v1152':1})
normal_text='\n'.join(main._v1151_plain_pipeline_lines())
main.load_json=orig
assert '✅ 정상' in normal_text and '남은 작업: 없음' in normal_text

guard_text=(ROOT/'backga_guard_bot_v2_5_189.py').read_text(encoding='utf-8')
assert 'guard_v2.5.189_pipeline_progress_truth_and_delay_map_v1152_2026-06-30' in guard_text
print(json.dumps({'status':'PASS','strategy_progress_sequence':True,'paper_same_cycle_gate':True,'delay_segments':True,'main_truth_labels':True,'guard_source_checked':True},ensure_ascii=False))
