# v1152 작업 잠금

- 증상: 쉬운 화면은 현재 pipeline CHECK를 Paper 이전 ready로 정상 표시했다. stale 후보는 총 지연만 있고 병목 구간이 없었다.
- 실제 원인: Main 다중 판정 owner, Strategy 진행상태가 직전 완료증거를 덮는 단일 파일, Paper 구간별 timestamp 연결 부재.
- owner: Strategy 진행/완료 시각 → Paper 후보별 지연 → Guard canonical 판정 → Main 읽기 전용 출력.
- 수정 파일: Strategy, Paper, Guard, Main 각 1개.
- 삭제 경로: Paper ready가 Guard current state를 덮는 표시, fresh IN_PROGRESS false anomaly.
- 새 본선: 현재 진행과 직전 완료 분리 + 같은 cycle/commit의 5구간 지연.
- 전략 영향: 없음. TTL 수치와 매매 계약 불변.
