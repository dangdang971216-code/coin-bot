This directory contains release evidence only. It does not contain live OPEN/CLOSED/trade_log/decision/exact/change_verify/issue ledger files. Deployment must not overwrite or delete live ledgers.
