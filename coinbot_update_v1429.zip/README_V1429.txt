v1429 Paper-owned exit shadow contract ledger.
- Adds paper_exit_shadow_contract_status_v1429.json and paper_exit_shadow_contract_ledger_v1429.jsonl.
- Shadow contracts only: MVC +1% weak lock, wide-invalid middle defense, no-progress early trim, fixed-stop veto/damage watch.
- Main reads the Paper-owned shadow status with /exit_shadow_contracts.
- No real exit contract, candidate flow, Gate, TTL, RR, trigger, invalid, target, OPEN limit, S1/S2/S3, OPEN/CLOSED/trade_log/decision/exact rewrite, or auto-buy changes.
