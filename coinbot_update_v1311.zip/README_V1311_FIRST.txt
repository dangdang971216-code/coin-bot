코인봇 v1311 적용 안내

목적:
- /version_score에 예전처럼 현재 OPEN 합계/평가손익을 다시 표시
- Strategy S1과 Paper S1 판독을 분리해서 Paper 수집중/지연을 숨기지 않음
- /gdisk_full 접수만 오고 결과가 안 오는 문제를 빠른 결과판으로 수리
- no-limit shadow 폭주를 막고 v1309/v1310 폭주분은 성과판에서 제외

변경금지:
- 후보식/trigger/invalid/target/RR/청산계약 변경 없음
- 자동매수 OFF
- 기존 OPEN/CLOSED/trade_log/decision/exact/change/issue 원장 삭제·축소·재작성 없음
