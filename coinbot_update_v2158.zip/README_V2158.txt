코인봇 v2158 · Paper S1 종목별 최종이유 연결

현재 문제
- Strategy에는 S1이 보이지만 /paper_v2_exact에는 종목명과 탈락 이유가 나오지 않았습니다.
- Paper가 전체 후보 462개를 검사하면서 앞쪽 일반 보류 15개만 남겨 S1 결과가 가려졌습니다.
- 다음 cycle에서 S1이 0이 되면 직전 S1 commit도 화면에서 사라졌습니다.

수정 내용
- 기존 Paper 실행 loop 안에서 S1/ENTRY_READY 종목만 별도로 회계 처리합니다.
- 각 종목은 이미 처리됨, 동일 종목 OPEN, 실행검사 탈락, 실행검사 통과, OPEN 완료, 저장 오류 중 하나로 반드시 끝납니다.
- 실행검사 탈락 종목은 실제 진입가, Trigger, Invalid, T1, 비용 후 RR, 목표공간, T1 경로소비, spread, slippage와 정확한 이유를 표시합니다.
- 직전 S1 발생 commit을 기존 Paper status 안에 보존합니다.
- /paper_v2_exact가 현재 commit과 직전 S1 commit을 함께 보여줍니다.

잠금
- Strategy·예측식·가중치·Trigger·Invalid·T1 변경 없음
- Paper 진입·청산 조건 변경 없음
- 새 명령·Shadow·원장·잠금 없음
- 기존 OPEN/CLOSED/decision/exact 보존
- 자동매수 OFF
