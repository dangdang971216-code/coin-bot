# v1080 범위와 검수

## 증상

- 디스크 남음 약 3.4GB.
- 이전 감사 대비 183.9분 동안 약 120.2MB 증가.
- 비핵심 JSONL trace가 1.2GB 이상이며, gzip archive가 11,211개까지 누적.
- 기존 순환은 활성 파일 일부만 줄였고 압축본 개수·총용량을 제한하지 않아 전체 디스크가 계속 증가함.

## 실제 원인

1. `structure_lab_horizon_result_ledger_v956.jsonl`, `structure_lab_event_detail_ledger_v956.jsonl`, `clean_hot_watch_strategy_events.jsonl`, `good_s2_result_ledger.jsonl`에 전체 고정상한이 없었음.
2. quality shadow와 good-S2 observation은 압축본을 계속 만들지만 오래된 gzip 보존 개수·총용량 제한이 없었음.
3. 일부 active tail 정책은 보존 행 수가 커서 회전 직후에도 파일이 상한에 가깝게 남아 짧은 주기로 다시 압축본을 생성함.
4. 압축 도중 재시작 시 `.rotate_pending_v1080.*`가 남을 수 있었고 자동 복구 계약이 없었음.
5. Review dedup SQLite source signature가 append 뒤 즉시 동기화되지 않아 재시작 시 불필요한 전체 재구축 가능성이 있었음.
6. quality atomic state write 실패·중단 때 남은 대형 `.tmp` 파일을 회수하는 owner가 없었음.

## 변경

### Strategy v0.996

- hot-watch active trace: 16MB 상한.
- hot-watch gzip: 최대 2개 / 합계 48MB.
- good-S2 observation: 회전 후 active tail 약 12MB.
- good-S2 observation gzip: 최대 2개 / 합계 64MB.
- 오래된 gzip은 매 cycle producer가 직접 정리.
- 중단된 pending segment는 다음 cycle에 압축 복구.

### Review v0.997

- structure detail/horizon active: 각각 32MB.
- structure final active: 16MB.
- good-S2 result active: 16MB.
- quality shadow active: 기존 50MB 상한 유지.
- 각 archive 세트 최대 2개, 총용량 상한 적용.
- horizon 누적 summary와 good-S2 누적 aggregate는 active segment 회전 뒤에도 보존.
- dedup DB가 정상이면 재사용하고 source signature만 동기화.
- horizon/final batch append key를 즉시 SQLite에 commit.
- 30분 이상 지난 quality state 임시파일 중 owner PID가 없는 파일만 시작 시 정리.
- 중단된 pending segment 자동 복구.

### Guard v2.5.135

- `/gdisk_bound_v1080 180` 추가.
- runtime/hash, active 크기, archive 개수·총용량, pending, stale quality tmp, candidate 계약, exact 0/0/0, 자동매수 OFF를 한 번에 검수.
- 결과를 `disk_bound_verify_v1080.json`에 저장하고 issue/change 원장에 append-once 기록.

## 변경하지 않은 영역

- 전략 점수·threshold·RR·trigger·invalid·target.
- spread·slippage·trailing·시간청산.
- 전체 OPEN 한도·cycle 신규 OPEN 한도.
- OPEN/CLOSED/trade_log/decision/exact/performance/change/issue 원장.
- 자동매수 상태.

## 적용 후 검수

Guard봇에서 `/gupgrade_bundle`을 단독 실행한 뒤 Guard 재시작 후:

```text
/gdisk_bound_v1080 180
/gworker_state
```

Main봇:

```text
/health
/change_verify
/issue_ledger
/errorlog
```

Paper봇:

```text
/pstatus
/perror
```

서버 runtime 검수 전 상태는 CHECK이며, `/gdisk_bound_v1080`의 DONE만 서버 완료 증명으로 사용한다.
