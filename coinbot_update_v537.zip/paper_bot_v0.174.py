#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
paper_bot_v0.156_hot_alert_quiet_trace_2026-05-27

목적:
- v0.50/v389/v397 계열의 무거운 paper runtime을 더 이상 타지 않는다.
- paper 실행기는 S1 후보 읽기 → OPEN → 기존 OPEN 청산 → 장부 저장 → 알림만 담당한다.
- OPEN/CLOSED/trade_log 장부는 보존하고, 전체 CLOSED 재계산/복기/score full 계산은 실행 루프에서 제외한다.
- v416/v0.127: paper OPEN 직전 최종 안전문을 직접 확인하고, 약한 체결/넓은 스프레드/미끄러짐 후보를 장부 OPEN 전에 보류한다.
- v479: 무반응 S1은 폐기/차단이 아니라 paper OPEN만 보류하고 다음 recheck cycle에 맡긴다.
"""

from __future__ import annotations

import json
import os
import signal
import sys
import time
import traceback
import re
import urllib.parse
import urllib.request
from collections import Counter, deque
from pathlib import Path
from typing import Any, Dict, Iterable, List, Optional, Tuple

VERSION = "paper_bot_v0.174"
BUILD_LABEL = "v537_profile_final_gate_aligned"
BASE_DIR = Path(__file__).resolve().parent

FILES: Dict[str, Path] = {
    "paper_latest": BASE_DIR / "paper_candidates_latest.jsonl",
    "open": BASE_DIR / "paper_bot_open.json",
    "closed": BASE_DIR / "paper_bot_closed.jsonl",
    "status": BASE_DIR / "paper_bot_status.json",
    "control": BASE_DIR / "paper_bot_control.json",
    "pid": BASE_DIR / "paper_bot.pid",
    "trace": BASE_DIR / "paper_bot_candidate_handoff_trace.json",
    "handoff_status": BASE_DIR / "paper_bot_candidate_handoff_status.json",
    "score": BASE_DIR / "paper_bot_score_cache.json",
    "hot_rank": BASE_DIR / "clean_scanner_hot_rank_cache.json",
    "error": BASE_DIR / "paper_bot_error.log",
    "log": BASE_DIR / "paper_bot.log",
}

DEFAULT_CONTROL: Dict[str, Any] = {
    "running": True,
    "loop_seconds": 8,
    "open_monitor_interval_sec": 2.0,
    "max_open_strict": 0,
    "max_new_per_cycle": 0,
    "new_open_paused": False,
    "open_trade_ready_only": True,
    "notify_on_strict_open": True,
    "notify_on_strict_close": True,
    "notify_on_s1_decision_summary": True,
    "notify_s1_decision_summary_interval_sec": 3600,
    "notify_s1_decision_summary_min_interval_sec": 3600,  # backward compat
    "notify_open_min_score": 4.45,
    "notify_open_require_micro_fresh": True,
    "notify_open_require_ws_fresh": False,
    "preopen_micro_recheck": True,
    "preopen_micro_urgent_ttl_sec": 35,
    "paper_final_reaction_proof_enabled": True,
    "paper_final_reaction_proof_mode": "recheck_hold",
    "paper_final_reaction_proof_min_windows": 2,
    "paper_final_reaction_proof_min_flow_pct": 0.01,
    "block_same_ticker_open": True,
    "candidate_ttl_sec": 120,
    "candidate_read_max_lines": 800,
    "consume_latest_scan_only": True,
    "write_score_cache": True,
    "latest_scan_window_sec": 8,
    "fee_pct_roundtrip": 0.10,
    "take_profit_pct": 1.20,
    "protect_trigger_pct": 0.70,
    "protect_floor_pct": 0.35,
    "protect_strong_trigger_pct": 1.00,
    "protect_strong_floor_pct": 0.50,
    "protect_big_trigger_pct": 1.40,
    "protect_big_floor_pct": 0.75,
    "protect_giveback_pct": 0.55,
    "stop_loss_pct": -0.55,
    "fast_fail_after_min": 2.5,
    "fast_fail_peak_under_pct": 0.20,
    "fast_fail_loss_pct": -0.35,
    "fast_fail_after_min_late": 5.0,
    "fast_fail_loss_pct_late": -0.25,
    "slow_minutes": 20,
    "slow_peak_under_pct": 0.25,
    "time_exit_minutes": 15,
    # v486: 손실은 빠르게, 수익권은 조건부로 길게 본다.
    "profit_soft_protect_trigger_pct": 0.45,
    "profit_soft_protect_floor_pct": 0.10,
    "profit_soft_protect_giveback_pct": 0.45,
    "profit_run_extend_enabled": True,
    "profit_run_extend_minutes": 15,
    "profit_run_extend_max_count": 1,
    "profit_run_extend_min_net_pct": 0.20,
    "profit_run_extend_min_peak_pct": 0.25,
    "profit_run_extend_max_giveback_pct": 0.25,
    "profit_run_strategy_keywords": ["주도", "유동보유", "leader", "momentum"],
    "notify_market_hot_alert": True,
    "notify_market_hot_immediate_enabled": False,
    "notify_market_hot_summary_interval_sec": 3600,
    "notify_market_hot_immediate_min_interval_sec": 3600,  # backward compat
    "notify_market_hot_global_min_interval_sec": 3600,
    "notify_market_hot_ticker_cooldown_sec": 3600,
    "notify_market_hot_1m_pct": 0.80,
    "notify_market_hot_3m_pct": 1.50,
    "notify_market_hot_immediate_1m_pct": 1.50,
    "notify_market_hot_immediate_3m_pct": 2.50,
    "notify_market_hot_rank_top_n": 5,
    "notify_market_hot_max_items": 4,
    "notify_market_hot_cache_ttl_sec": 90,
    "notify_entry_timing_trace": True,
}

TOKEN = os.getenv("PAPER_BOT_TOKEN", os.getenv("TELEGRAM_TOKEN", "")).strip()
ALLOWED_CHAT_ID = (
    os.getenv("PAPER_BOT_ALLOWED_CHAT_ID", "").strip()
    or os.getenv("PAPER_BOT_CHAT_ID", "").strip()
    or os.getenv("CHAT_ID", "").strip()
    or os.getenv("GUARD_CHAT_ID", "").strip()
)
NOTIFY_CHAT_ID = os.getenv("PAPER_BOT_NOTIFY_CHAT_ID", "").strip() or ALLOWED_CHAT_ID

_STOP = False
_STOP_REASON = "running"
_STARTED_TS = time.time()
_LAST_PRICE_CACHE: Dict[str, Any] = {"ts": 0.0, "prices": {}}
_LAST_STATUS: Dict[str, Any] = {}
_LAST_CLOSED_COUNT_CACHE: Dict[str, Any] = {"ts": 0.0, "count": 0}
_TG_OFFSET = 0
_LAST_S1_DECISION_NOTIFY: Dict[str, Any] = {"ts": 0.0, "key": ""}
_S1_DECISION_SUMMARY_BUCKET: Dict[str, Any] = {}
_HOT_MARKET_NOTIFY_BUCKET: Dict[str, Any] = {}


def now_ts() -> float:
    return time.time()


def iso_ts(ts: Optional[float] = None) -> str:
    import datetime as _dt
    return _dt.datetime.fromtimestamp(ts or now_ts()).strftime("%Y-%m-%d %H:%M:%S")


def fnum(*vals: Any, default: float = 0.0) -> float:
    for v in vals:
        try:
            if v is None or v == "":
                continue
            if isinstance(v, str):
                v = v.replace(",", "").replace("%", "").strip()
            return float(v)
        except Exception:
            continue
    return default


def log(msg: str) -> None:
    try:
        with FILES["log"].open("a", encoding="utf-8") as f:
            f.write(f"[{iso_ts()}] {msg}\n")
    except Exception:
        pass


def log_error(where: str, exc: BaseException) -> None:
    try:
        with FILES["error"].open("a", encoding="utf-8") as f:
            f.write(f"[{iso_ts()}] {where}: {type(exc).__name__}: {exc}\n")
            f.write(traceback.format_exc() + "\n")
    except Exception:
        pass


def atomic_write_text(path: Path, text: str) -> None:
    tmp = path.with_suffix(path.suffix + ".tmp")
    tmp.write_text(text, encoding="utf-8")
    os.replace(tmp, path)


def save_json(path: Path, obj: Any) -> None:
    try:
        atomic_write_text(path, json.dumps(obj, ensure_ascii=False, separators=(",", ":")))
    except Exception as exc:
        log_error(f"save_json:{path.name}", exc)


def load_json(path: Path, default: Any = None) -> Any:
    try:
        if not path.exists():
            return default
        return json.loads(path.read_text(encoding="utf-8", errors="ignore"))
    except Exception as exc:
        log_error(f"load_json:{path.name}", exc)
        return default


def append_jsonl(path: Path, obj: Dict[str, Any]) -> None:
    try:
        with path.open("a", encoding="utf-8") as f:
            f.write(json.dumps(obj, ensure_ascii=False, separators=(",", ":")) + "\n")
    except Exception as exc:
        log_error(f"append_jsonl:{path.name}", exc)


def tail_lines(path: Path, max_lines: int) -> List[str]:
    if not path.exists():
        return []
    dq: deque[str] = deque(maxlen=max_lines)
    try:
        with path.open("r", encoding="utf-8", errors="ignore") as f:
            for line in f:
                if line.strip():
                    dq.append(line.rstrip("\n"))
    except Exception as exc:
        log_error(f"tail_lines:{path.name}", exc)
    return list(dq)


def read_jsonl_tail(path: Path, max_lines: int) -> List[Dict[str, Any]]:
    out: List[Dict[str, Any]] = []
    for line in tail_lines(path, max_lines):
        try:
            row = json.loads(line)
            if isinstance(row, dict):
                out.append(row)
        except Exception:
            continue
    return out


def line_count_cached(path: Path, ttl: float = 60.0) -> int:
    ts = now_ts()
    if ts - float(_LAST_CLOSED_COUNT_CACHE.get("ts") or 0.0) < ttl:
        return int(_LAST_CLOSED_COUNT_CACHE.get("count") or 0)
    try:
        if not path.exists():
            cnt = 0
        else:
            with path.open("rb") as f:
                cnt = sum(1 for _ in f)
        _LAST_CLOSED_COUNT_CACHE.update({"ts": ts, "count": cnt})
        return cnt
    except Exception:
        return int(_LAST_CLOSED_COUNT_CACHE.get("count") or 0)


def normalize_ticker(v: Any) -> str:
    if v is None:
        return ""
    t = str(v).strip().upper().replace("/", "-").replace("_", "-")
    if not t:
        return ""
    parts = [p for p in t.split("-") if p]
    if len(parts) >= 2:
        non = [p for p in parts if p != "KRW"]
        return (non[-1] if non else parts[-1]).strip().upper()
    if t.endswith("KRW") and len(t) > 3:
        return t[:-3].strip().upper()
    return t


def row_ts(row: Dict[str, Any], *keys: str) -> float:
    for k in keys:
        v = row.get(k)
        x = fnum(v, default=0.0)
        if x > 1000000000:
            return x
        if isinstance(v, str) and v:
            try:
                import datetime as _dt
                return _dt.datetime.fromisoformat(v.replace("Z", "+00:00")).timestamp()
            except Exception:
                pass
    return 0.0


def event_time(row: Dict[str, Any]) -> float:
    return row_ts(row, "expires_at", "candidate_expires_at", "created_at", "candidate_created_at", "source_created_at", "detected_ts", "event_ts", "ts", "timestamp")


def event_created_ts(row: Dict[str, Any]) -> float:
    return row_ts(row, "created_at", "candidate_created_at", "source_created_at", "detected_ts", "event_ts", "ts", "timestamp")


def load_control() -> Dict[str, Any]:
    saved = load_json(FILES["control"], {})
    ctrl = dict(DEFAULT_CONTROL)
    if isinstance(saved, dict):
        ctrl.update(saved)
    # v400: paper 실행기는 기본 ON. 사용자가 명시적으로 running=false로 저장한 경우만 정지한다.
    if "running" not in ctrl:
        ctrl["running"] = True
    return ctrl


def write_pid() -> None:
    try:
        FILES["pid"].write_text(str(os.getpid()), encoding="utf-8")
    except Exception:
        pass


def load_open() -> Dict[str, Dict[str, Any]]:
    obj = load_json(FILES["open"], {})
    return obj if isinstance(obj, dict) else {}


def save_open(open_pos: Dict[str, Dict[str, Any]]) -> None:
    save_json(FILES["open"], open_pos if isinstance(open_pos, dict) else {})


def open_tickers(open_pos: Dict[str, Dict[str, Any]]) -> set[str]:
    return {normalize_ticker(p.get("ticker")) for p in open_pos.values() if isinstance(p, dict) and normalize_ticker(p.get("ticker"))}


def closed_recent_ids(limit: int = 2000) -> set[str]:
    ids: set[str] = set()
    for r in read_jsonl_tail(FILES["closed"], limit):
        for k in ("pos_id", "event_id", "trace_id", "handoff_id", "candidate_uid"):
            v = str(r.get(k) or "").strip()
            if v:
                ids.add(v)
    return ids


def event_id(ev: Dict[str, Any], lane: str = "strict") -> str:
    for k in ("event_id", "event_key", "trace_id", "handoff_id", "candidate_uid", "id"):
        v = str(ev.get(k) or "").strip()
        if v:
            return v
    t = normalize_ticker(ev.get("ticker") or ev.get("market") or ev.get("symbol")) or "UNKNOWN"
    scan = str(ev.get("scan_id") or ev.get("source_scan_id") or ev.get("strategy_scan_id") or "")[:40]
    created = int(event_created_ts(ev) or now_ts())
    score = fnum(ev.get("score"), ev.get("leader_score"), default=0.0)
    return f"{lane}:{t}:{scan}:{created}:{score:.3f}"




def candidate_brief(ev: Dict[str, Any], status: str = "", reason: str = "") -> Dict[str, Any]:
    """paper handoff 상태판용 짧은 후보 요약.

    OPEN 여부를 바꾸지 않고, S1이 paper까지 왔는지/왜 막혔는지만 남긴다.
    """
    try:
        ctx = ev.get("entry_context") if isinstance(ev.get("entry_context"), dict) else {}
        diag = ev.get("paper_final_safety_diagnostics") if isinstance(ev.get("paper_final_safety_diagnostics"), dict) else build_entry_diagnostics(ev, ctx)
    except Exception:
        diag = {}
    return {
        "ticker": normalize_ticker(ev.get("ticker") or ev.get("market") or ev.get("symbol")),
        "event_id": event_id(ev, "strict"),
        "stage": ev.get("s_stage") or ev.get("candidate_stage") or ev.get("stage") or ev.get("candidate_grade") or ev.get("grade"),
        "strategy": ev.get("strategy_label") or ev.get("strategy_key") or ev.get("strategy") or ev.get("route"),
        "score": fnum(ev.get("score"), ev.get("leader_score"), default=0.0),
        "status": status or "seen",
        "reason": reason or "-",
        "created_at": ev.get("created_at") or ev.get("candidate_created_at") or ev.get("source_created_at"),
        "seen_at": now_ts(),
        "seen_at_text": iso_ts(),
        "price_reaction_pct": fnum(diag.get("price_reaction_pct"), default=0.0) if isinstance(diag, dict) else 0.0,
        "spread_pct": fnum(diag.get("spread_pct"), default=-1.0) if isinstance(diag, dict) else -1.0,
        "buy_ratio": fnum(diag.get("buy_ratio"), default=-1.0) if isinstance(diag, dict) else -1.0,
        "buy_sustain_1m": fnum(diag.get("buy_sustain_1m"), default=-1.0) if isinstance(diag, dict) else -1.0,
        "block_reasons": list(ev.get("paper_entry_hold_reasons") or ev.get("paper_final_block_reasons") or [])[:8] if isinstance((ev.get("paper_entry_hold_reasons") or ev.get("paper_final_block_reasons")), list) else [],
    }


def _record_decision(stats: Dict[str, Any], key: str, ev: Dict[str, Any], status: str, reason: str = "") -> None:
    brief = candidate_brief(ev, status=status, reason=reason)
    stats[key] = brief
    rows = stats.get("recent_s1_decisions")
    if not isinstance(rows, list):
        rows = []
    rows.append(brief)
    stats["recent_s1_decisions"] = rows[-12:]

def get_event_price(ev: Dict[str, Any]) -> float:
    for k in ("live_price", "current_price", "price", "trade_price", "close", "last_price", "entry_price", "detected_price"):
        x = fnum(ev.get(k), default=0.0)
        if x > 0:
            return x
    ctx = ev.get("entry_context") if isinstance(ev.get("entry_context"), dict) else {}
    for k in ("live_price", "current_price", "price", "close"):
        x = fnum(ctx.get(k), default=0.0)
        if x > 0:
            return x
    return 0.0


def fetch_all_prices_cached(ttl: float = 4.0) -> Dict[str, float]:
    ts = now_ts()
    if ts - float(_LAST_PRICE_CACHE.get("ts") or 0.0) < ttl:
        return dict(_LAST_PRICE_CACHE.get("prices") or {})
    prices: Dict[str, float] = {}
    try:
        req = urllib.request.Request(
            "https://api.bithumb.com/public/ticker/ALL_KRW",
            headers={"Accept": "application/json", "User-Agent": VERSION},
        )
        with urllib.request.urlopen(req, timeout=4) as resp:
            data = json.loads(resp.read().decode("utf-8", errors="ignore"))
        raw = data.get("data") if isinstance(data, dict) else {}
        if isinstance(raw, dict):
            for k, v in raw.items():
                if not isinstance(v, dict):
                    continue
                t = normalize_ticker(k)
                p = fnum(v.get("closing_price"), v.get("close"), default=0.0)
                if t and p > 0:
                    prices[t] = p
    except Exception as exc:
        log_error("fetch_all_prices", exc)
    if prices:
        _LAST_PRICE_CACHE.update({"ts": ts, "prices": prices})
    return prices


def live_price(ticker: str, fallback: float = 0.0) -> float:
    t = normalize_ticker(ticker)
    prices = fetch_all_prices_cached()
    return float(prices.get(t) or fallback or 0.0)


def candidate_is_fresh(ev: Dict[str, Any], ctrl: Dict[str, Any]) -> bool:
    nowv = now_ts()
    exp = row_ts(ev, "expires_at", "candidate_expires_at")
    if exp > 0:
        return exp >= nowv
    created = event_created_ts(ev)
    if created > 0:
        return (nowv - created) <= fnum(ctrl.get("candidate_ttl_sec"), default=120.0)
    # latest 파일 자체가 방금 갱신된 경우에만 timestamp 없는 후보를 관찰 대상으로 둔다. OPEN은 하지 않는다.
    return False


def micro_fresh(ev: Dict[str, Any], ctrl: Dict[str, Any]) -> bool:
    ctx = ev.get("entry_context") if isinstance(ev.get("entry_context"), dict) else {}
    vals = [ev, ctx]
    for obj in vals:
        if bool(obj.get("micro_fresh")):
            return True
        if str(obj.get("micro_row_status") or "").lower() in {"fresh", "ok", "true", "1"}:
            return True
        age = fnum(obj.get("micro_age_sec"), default=999999.0)
        if age <= fnum(ctrl.get("preopen_micro_urgent_ttl_sec"), default=35.0):
            return True
    return False


def ws_fresh(ev: Dict[str, Any]) -> bool:
    ctx = ev.get("entry_context") if isinstance(ev.get("entry_context"), dict) else {}
    for obj in (ev, ctx):
        if bool(obj.get("ws_fresh")):
            return True
        if str(obj.get("ws_row_status") or "").lower() in {"fresh", "ok", "true", "1"}:
            return True
        if fnum(obj.get("ws_age_sec"), default=999999.0) <= 30:
            return True
    return False


def _pressure_is_bad(v: Any) -> bool:
    if v in (None, ""):
        return False
    if isinstance(v, bool):
        return bool(v)
    try:
        # 숫자형 압력값은 보수적으로 0.60 이상이면 부담으로 본다.
        return float(v) >= 0.60
    except Exception:
        s = str(v).strip().lower()
        if s in {"false", "0", "none", "no", "ok", "good", "low", "정상", "없음"}:
            return False
        return any(x in s for x in ("bad", "high", "pressure", "wall", "부담", "압력", "매도"))


def _version_from_text(txt: Any) -> str:
    s = str(txt or "").strip()
    if not s:
        return ""
    m = re.search(r"(?:^|[^0-9])2[_\.]13[_\.](\d{1,4})(?:[^0-9]|$)", s)
    if m:
        return f"v2.13.{int(m.group(1))}"
    m = re.search(r"v2\.13\.(\d{1,4})", s)
    if m:
        return f"v2.13.{int(m.group(1))}"
    return ""


_ACTIVE_MAIN_VERSION_CACHE: Dict[str, Any] = {"ts": 0.0, "version": "", "source": ""}


def _deployed_main_version_detail() -> Tuple[str, str]:
    """실제 적용된 메인봇 버전과 출처.

    v460 단일 본선:
    - DEPLOY_TARGET.txt는 구값(v2.13.320)이 남는 경우가 있어 마지막 fallback으로만 쓴다.
    - paper 성과판은 현재 실행 중인 메인봇 상태파일/실제 배포파일을 우선한다.
    - CLOSED 장부 원본은 수정하지 않고, score cache 집계 시점에만 보정한다.
    """
    candidates: List[Tuple[str, str]] = []

    # 1) 메인봇 heartbeat/status. 실제 실행 중인 BOT_VERSION이 가장 안전하다.
    for name in ("clean_brain_status.json", "clean_resource_status.json"):
        try:
            obj = json.loads((BASE_DIR / name).read_text(encoding="utf-8", errors="ignore"))
            if isinstance(obj, dict):
                for key in ("version", "bot_version", "main_version", "BOT_VERSION"):
                    v = _version_from_text(obj.get(key))
                    if v:
                        candidates.append((v, f"{name}:{key}"))
        except Exception:
            pass

    # 2) guard가 실제 배포 완료 후 남기는 단일 진실값 후보들.
    for name in (".deployed_target", ".deployed_main_target", ".active_main_target", "deployed_target.txt"):
        try:
            txt = (BASE_DIR / name).read_text(encoding="utf-8", errors="ignore").strip()
            v = _version_from_text(txt)
            if v:
                candidates.append((v, name))
        except Exception:
            pass

    # 3) 현재 bundle main 항목. paper-only bundle이면 main이 없을 수 있으므로 보조로만 사용.
    try:
        obj = json.loads((BASE_DIR / "DEPLOY_BUNDLE.json").read_text(encoding="utf-8", errors="ignore"))
        if isinstance(obj, dict):
            for key in ("main", "target", "deploy_target", "main_file"):
                v = _version_from_text(obj.get(key))
                if v:
                    candidates.append((v, f"DEPLOY_BUNDLE.json:{key}"))
    except Exception:
        pass

    # 4) bot.py/메인 파일 내부 BOT_VERSION. 짧은 앞부분만 읽어서 무거운 경로를 피한다.
    for name in ("bot.py",):
        try:
            path = BASE_DIR / name
            if path.exists():
                txt = path.read_text(encoding="utf-8", errors="ignore")[:20000]
                v = _version_from_text(txt)
                if v:
                    candidates.append((v, f"{name}:BOT_VERSION"))
        except Exception:
            pass

    # 5) 서버에 놓인 최신 coinbot_main 파일명.
    try:
        best = 0
        for f in BASE_DIR.glob("coinbot_main_v2_13_*.py"):
            m = re.search(r"coinbot_main_v2_13_(\d+)\.py$", f.name)
            if m:
                best = max(best, int(m.group(1)))
        if best:
            candidates.append((f"v2.13.{best}", "latest_coinbot_main_file"))
    except Exception:
        pass

    # 6) 마지막 fallback: 구 DEPLOY_TARGET. 단독으로만 쓴다.
    legacy = _legacy_deploy_target_version()
    if candidates:
        # paper-only bundle/구파일 혼재 시 가장 높은 v2.13.xxx를 실제 적용 후보로 본다.
        def _n(item: Tuple[str, str]) -> int:
            m = re.search(r"v2\.13\.(\d+)", item[0])
            return int(m.group(1)) if m else 0
        best = max(candidates, key=_n)
        return best
    if legacy:
        return legacy, "DEPLOY_TARGET.txt:fallback"
    return "", ""


def _deployed_main_version() -> str:
    v, _src = _deployed_main_version_detail()
    return v


def _legacy_deploy_target_version() -> str:
    try:
        txt = (BASE_DIR / "DEPLOY_TARGET.txt").read_text(encoding="utf-8", errors="ignore").strip()
        return _version_from_text(txt)
    except Exception:
        return ""


def active_main_version_detail(ttl: float = 3.0) -> Tuple[str, str]:
    ts = now_ts()
    if ts - float(_ACTIVE_MAIN_VERSION_CACHE.get("ts") or 0.0) < ttl:
        return str(_ACTIVE_MAIN_VERSION_CACHE.get("version") or ""), str(_ACTIVE_MAIN_VERSION_CACHE.get("source") or "")
    v, src = _deployed_main_version_detail()
    _ACTIVE_MAIN_VERSION_CACHE.update({"ts": ts, "version": v, "source": src})
    return v, src


def active_main_version() -> str:
    """성과판용 현재 메인봇 버전.

    실제 실행/배포값을 우선하고, 오래된 DEPLOY_TARGET.txt는 마지막 fallback으로만 사용한다.
    """
    v, _src = active_main_version_detail()
    return v




def _paper_v488_reason_kind(text: Any) -> Tuple[str, str, str]:
    raw = str(text or '').strip()
    compact = raw.replace(' ', '').replace('_', '').replace('-', '').lower()
    if not raw:
        return ('ignore', '', '')
    if '전략조건 재확인 보류' in raw:
        return ('entry_decision', 'entry_decision', raw)
    if any(k in raw for k in ('스프레드 과다', '스프레드과다', '스프레드 부담', '스프레드부담', '진입 직전 스프레드')):
        return ('exec', 'spread', raw)
    if any(k in raw for k in ('미끄러짐', '슬리피지')):
        return ('exec', 'slippage', raw)
    if any(k in raw for k in ('매도압력', '매도벽')):
        return ('exec', 'sell_pressure', '진입 직전 매도벽/매도압력 부담')
    if '무반응' in raw:
        return ('exec', 'no_reaction', raw)
    if '호가·체결' in raw or 'micro' in compact:
        return ('fresh', 'micro_fresh', raw)
    if '실시간 시세' in raw or 'ws' in compact:
        return ('fresh', 'ws_fresh', raw)
    if '매수체결' in raw:
        return ('legacy', 'buy_ratio', raw)
    if '1분' in raw:
        return ('legacy', 'buy_sustain_1m', raw)
    if '가격반응' in raw:
        return ('legacy', 'price_reaction', raw)
    return ('other', raw, raw)


def _paper_v488_dedupe_reasons(reasons: Any, limit: int = 10) -> List[str]:
    arr = reasons if isinstance(reasons, list) else ([] if reasons is None else [reasons])
    order = {'entry_decision': 0, 'fresh': 1, 'exec': 2, 'legacy': 3, 'other': 4}
    buf: List[Tuple[int, str, str]] = []
    seen = set()
    for x in arr:
        b, k, disp = _paper_v488_reason_kind(x)
        if not k or b == 'ignore' or k in seen:
            continue
        seen.add(k)
        buf.append((order.get(b, 9), k, str(disp or x).strip()))
    return [txt for _o, _k, txt in sorted(buf, key=lambda z: z[0])[:limit]]


def _paper_v484_canonical_entry_decision(ev: Dict[str, Any], ctx: Dict[str, Any]) -> Dict[str, Any]:
    # v533: paper OPEN gate reads only the strategy canonical decision.
    dec = ev.get("canonical_entry_decision") or ctx.get("canonical_entry_decision") or ev.get("common_entry_decision") or ctx.get("common_entry_decision")
    return dec if isinstance(dec, dict) else {}

def _paper_v537_profile_from_diag(diag: Dict[str, Any]) -> str:
    dec = diag.get("canonical_entry_decision") if isinstance(diag.get("canonical_entry_decision"), dict) else {}
    p = str(diag.get("entry_profile") or dec.get("entry_profile") or "").strip()
    if p in {"spike_fast_early", "spike_runner"}:
        return "spike"
    if p in {"spike_fast_watch", "normal_watch"}:
        return "watch"
    return p or "normal_common"


def _paper_v484_exec_safety_reasons(diag: Dict[str, Any], ctrl: Dict[str, Any]) -> List[str]:
    """v537 profile-aware last-mile safety.
    Strategy canonical_entry_decision is the entry source. Paper only checks last-mile execution,
    and uses the same profile family so spike is not re-blocked by normal spread/slippage defaults.
    """
    reasons: List[str] = []
    profile = _paper_v537_profile_from_diag(diag)
    if profile == "spike":
        max_spread = fnum(ctrl.get("paper_final_spike_max_spread_pct"), default=0.85)
        max_slip = fnum(ctrl.get("paper_final_spike_max_slippage_pct"), default=0.85)
        reaction_proof_enabled = bool(ctrl.get("paper_final_spike_reaction_proof_enabled", False))
    else:
        max_spread = fnum(ctrl.get("paper_final_max_spread_pct"), default=0.18)
        max_slip = fnum(ctrl.get("paper_final_max_slippage_pct"), default=0.20)
        reaction_proof_enabled = bool(ctrl.get("paper_final_reaction_proof_enabled", True))
    spread = fnum(diag.get("spread_pct"), default=-1.0)
    slip_raw = fnum(diag.get("slippage_pct"), default=-1.0)
    slip = slip_raw if slip_raw >= 0 else spread
    diag["paper_final_profile"] = profile
    diag["paper_final_max_spread_pct_used"] = max_spread
    diag["paper_final_max_slippage_pct_used"] = max_slip
    if spread >= 0 and spread > max_spread:
        reasons.append(f"진입 직전 스프레드 부담({spread:.2f}% > {max_spread:.2f}%)")
    if slip >= 0 and slip > max_slip:
        reasons.append(f"진입 직전 미끄러짐 부담({slip:.2f}% > {max_slip:.2f}%)")
    if reaction_proof_enabled:
        no_reaction_reason = _paper_v144_reaction_proof_block(diag, ctrl)
        if no_reaction_reason:
            reasons.append(no_reaction_reason)
    if _pressure_is_bad(diag.get("sell_pressure")):
        reasons.append("진입 직전 매도벽/매도압력 부담")
    return reasons[:10]


def paper_final_safety(ev: Dict[str, Any], ctrl: Dict[str, Any]) -> Tuple[bool, List[str], Dict[str, Any]]:
    """v532: paper는 strategy canonical_entry_decision만 읽는다.
    조건 수치 재계산 fallback은 제거한다. dict가 없으면 OPEN 보류다.
    """
    ctx = copy_entry_context(ev)
    diag = build_entry_diagnostics(ev, ctx)
    dec = _paper_v484_canonical_entry_decision(ev, ctx)
    reasons: List[str] = []

    if not isinstance(dec, dict) or not dec:
        diag["entry_decision_schema"] = "missing_canonical_entry_decision_v533"
        reasons.append("전략판단 원천 없음: canonical_entry_decision 누락")
    else:
        diag["canonical_entry_decision"] = dec
        diag["entry_decision_schema"] = dec.get("schema")
        diag["entry_profile"] = ev.get("entry_profile") or ctx.get("entry_profile") or dec.get("entry_profile")
        diag["exit_profile"] = ev.get("exit_profile") or ctx.get("exit_profile") or dec.get("exit_profile")
        diag["profile_family"] = ev.get("profile_family") or ctx.get("profile_family") or dec.get("profile_family")
        if not bool(dec.get("gate_pass") or dec.get("s1_allowed")):
            rs = dec.get("display_reasons") if isinstance(dec.get("display_reasons"), list) else []
            reasons.append("전략조건 재확인 보류: " + " / ".join(str(x) for x in rs[:4]))
        # last-mile execution safety only; do not duplicate strategy buy/sustain/reaction gates.
        reasons.extend(_paper_v484_exec_safety_reasons(diag, ctrl))

    if not micro_fresh(ev, ctrl):
        reasons.append("호가·체결 신선정보 없음")
    if bool(ctrl.get("paper_final_require_ws_fresh", False)) and not ws_fresh(ev):
        reasons.append("실시간 시세 신선정보 없음")

    try:
        age_ok, stale, ages = _v508_age_reasons(ev)
        diag["paper_preopen_age_values_v533"] = ages
        diag["paper_preopen_stale_reasons_v533"] = stale
        if not age_ok:
            reasons.append("preopen 신선도 실패: " + " / ".join(stale[:5]))
    except Exception as exc:
        diag["paper_preopen_age_error"] = exc.__class__.__name__

    for k in ("s1_missing_conditions", "s1_passed_conditions", "s1_distance", "s1_near_miss", "s1_short_reason", "canonical_lane", "matched_strategy_labels", "common_entry_pass", "common_entry_schema", "strategy_role", "entry_profile", "exit_profile", "profile_family", "profile_decisions"):
        val = ev.get(k) if ev.get(k) not in (None, "", [], {}) else ctx.get(k)
        if val not in (None, "", [], {}):
            diag[k] = val

    reasons = _paper_v488_dedupe_reasons(reasons, 10)
    diag["paper_final_safety_reasons"] = reasons
    diag["paper_final_safety_schema"] = "paper_final_safety_v537_profile_aligned"
    return (len(reasons) == 0), reasons, diag

def is_s1_candidate(ev: Dict[str, Any]) -> bool:
    ctx = ev.get("entry_context") if isinstance(ev.get("entry_context"), dict) else {}
    dec = ev.get("canonical_entry_decision") or ctx.get("canonical_entry_decision") or ev.get("common_entry_decision") or ctx.get("common_entry_decision")
    if not isinstance(dec, dict) or not dec:
        return False
    if not bool(dec.get("s1_allowed") or dec.get("gate_pass")):
        return False
    if ev.get("fresh_gate_ok") is False:
        return False
    if ev.get("paper_bot_open") is False or ev.get("open_eligible") is False:
        return False
    stage = str(ev.get("s_stage") or ev.get("candidate_stage") or ev.get("stage") or ev.get("candidate_grade") or ev.get("grade") or "").upper()
    return bool(stage == "S1" or ev.get("paper_bot_open") or ev.get("open_eligible") or ev.get("trade_ready"))


def candidate_sources(ctrl: Dict[str, Any]) -> List[Tuple[str, Path, List[Dict[str, Any]]]]:
    """v512 runtime OPEN source: canonical latest only.

    Legacy merged/archive files are not read here. They may exist on disk as history/debug files,
    but they are not candidate sources for OPEN, preventing old schema rows from causing ticker/price skips.
    """
    maxn = max(50, min(2000, int(fnum(ctrl.get("candidate_read_max_lines"), default=800))))
    rows = read_jsonl_tail(FILES["paper_latest"], maxn)
    return [("paper_latest", FILES["paper_latest"], rows)]


def latest_scan_filter(rows: List[Dict[str, Any]], ctrl: Dict[str, Any]) -> List[Dict[str, Any]]:
    if not rows or not bool(ctrl.get("consume_latest_scan_only", True)):
        return rows
    scan_ids = [str(r.get("scan_id") or r.get("source_scan_id") or "").strip() for r in rows if str(r.get("scan_id") or r.get("source_scan_id") or "").strip()]
    if scan_ids:
        latest = scan_ids[-1]
        same = [r for r in rows if str(r.get("scan_id") or r.get("source_scan_id") or "").strip() == latest]
        if same:
            return same
    latest_ts = max((event_created_ts(r) for r in rows), default=0.0)
    if latest_ts > 0:
        win = fnum(ctrl.get("latest_scan_window_sec"), default=8.0)
        return [r for r in rows if event_created_ts(r) >= latest_ts - win]
    return rows


def build_trace(rows: List[Dict[str, Any]], ctrl: Dict[str, Any], open_pos: Dict[str, Dict[str, Any]], picked_ids: set[str], opened_ids: set[str]) -> Dict[str, Any]:
    out: List[Dict[str, Any]] = []
    open_ids = set(open_pos.keys())
    open_ticks = open_tickers(open_pos)
    for ev in rows[-160:]:
        if not isinstance(ev, dict):
            continue
        t = normalize_ticker(ev.get("ticker") or ev.get("market") or ev.get("symbol"))
        eid = event_id(ev, "strict")
        reason: List[str] = []
        status = "observed"
        if eid in opened_ids:
            status = "open"
        elif eid in picked_ids:
            status = "selected_for_open"
        elif eid in open_ids or t in open_ticks:
            status = "already_open"
        elif not candidate_is_fresh(ev, ctrl):
            status = "expired"
            reason.append("후보오래됨")
        elif not is_s1_candidate(ev):
            status = "not_s1"
            reason.append("S1아님")
        elif ctrl.get("preopen_micro_recheck", True) and not micro_fresh(ev, ctrl):
            status = "micro_wait"
            reason.append("micro미확인")
        elif ev.get("paper_entry_hold_reasons"):
            status = "paper_entry_hold"
            reason.extend([str(x) for x in (ev.get("paper_entry_hold_reasons") or [])[:4]])
        elif ev.get("paper_final_block_reasons"):
            status = "paper_entry_hold"
            reason.extend([str(x) for x in (ev.get("paper_final_block_reasons") or [])[:4]])
        else:
            status = "merged_waiting_pick"
        out.append({
            "event_id": eid,
            "trace_id": eid,
            "ticker": t,
            "status": status,
            "reason": ",".join(reason) if reason else "-",
            "s_stage": ev.get("s_stage") or ev.get("candidate_stage") or ev.get("candidate_grade") or ev.get("grade"),
            "score": ev.get("score") or ev.get("leader_score"),
            "strategy": ev.get("strategy_label") or ev.get("strategy_key") or ev.get("strategy") or ev.get("route"),
            "stage_policy_schema": _diag_first(ev, ("stage_policy_schema", "lifecycle_schema")),
            "entry_reasons": _diag_list(ev, ("final_entry_reasons", "trade_ready_reasons", "s_stage_reasons", "entry_reasons", "why", "reason"), limit=6),
            "missing_info": (list(ev.get("paper_entry_hold_reasons") or ev.get("paper_final_block_reasons") or [])[:6] or _diag_list(ev, ("missing_info", "missing_fields", "info_missing", "info_needed", "s1_missing", "unmet_conditions", "block_reasons"), limit=6)),
            "created_at": ev.get("created_at") or ev.get("candidate_created_at") or ev.get("source_created_at"),
            "updated_at": now_ts(),
        })
    obj = {"version": VERSION, "trace_version": VERSION, "build": BUILD_LABEL, "updated_at": now_ts(), "updated_at_text": iso_ts(), "rows": out}
    save_json(FILES["trace"], obj)
    return obj


def write_handoff_status(latest_count: int, merged_fresh: int, pick_stats: Dict[str, Any]) -> None:
    save_json(FILES["handoff_status"], {
        "version": VERSION,
        "updated_at": now_ts(),
        "updated_at_text": iso_ts(),
        "latest_count": latest_count,
        "paper_latest_count": latest_count,
        "latest_lines": latest_count,
        "merged_fresh": merged_fresh,
        "archive_window": int(fnum(load_control().get("candidate_read_max_lines"), default=800)),
        "pick_stats": pick_stats,
        "note": "v513: runtime OPEN source is paper_candidates_latest only; ticker/price skip split; hot/S1 summaries hourly",
    })


def select_candidates(ctrl: Dict[str, Any], open_pos: Dict[str, Dict[str, Any]]) -> Tuple[List[Tuple[str, Dict[str, Any]]], Dict[str, Any], List[Dict[str, Any]]]:
    stats: Dict[str, Any] = Counter()
    all_rows: List[Dict[str, Any]] = []
    latest_count = 0
    for name, _path, rows in candidate_sources(ctrl):
        stats[f"{name}_read"] = int(stats.get(f"{name}_read", 0)) + len(rows)
        if name == "paper_latest":
            latest_count = len(rows)
        for r in rows:
            if isinstance(r, dict):
                rr = dict(r)
                rr.setdefault("_source_file", name)
                all_rows.append(rr)
    filtered = latest_scan_filter(all_rows, ctrl)
    stats["latest_scan_before"] = len(all_rows)
    stats["latest_scan_after"] = len(filtered)
    existing_ids = set(open_pos.keys()) | closed_recent_ids()
    blocked_tickers = open_tickers(open_pos) if ctrl.get("block_same_ticker_open", True) else set()
    picked: List[Tuple[str, Dict[str, Any]]] = []
    max_new = int(fnum(ctrl.get("max_new_per_cycle"), default=0))
    max_open = int(fnum(ctrl.get("max_open_strict"), default=0))
    for ev in filtered:
        if not isinstance(ev, dict):
            continue
        stats["last_seen_candidate"] = candidate_brief(ev, status="seen")
        is_s1 = is_s1_candidate(ev)
        if is_s1:
            stats["s1_seen"] = int(stats.get("s1_seen", 0)) + 1
            _record_decision(stats, "last_s1_seen", ev, "s1_seen")
        if max_new > 0 and len(picked) >= max_new:
            stats["limit_skip"] = int(stats.get("limit_skip", 0)) + 1
            if is_s1:
                _record_decision(stats, "last_skip", ev, "limit_skip", "cycle 신규 OPEN 상한")
            continue
        if max_open > 0 and len(open_pos) + len(picked) >= max_open:
            stats["limit_skip"] = int(stats.get("limit_skip", 0)) + 1
            if is_s1:
                _record_decision(stats, "last_skip", ev, "limit_skip", "OPEN 상한")
            continue
        if ctrl.get("new_open_paused", False):
            stats["new_open_paused"] = int(stats.get("new_open_paused", 0)) + 1
            if is_s1:
                _record_decision(stats, "last_skip", ev, "new_open_paused", "신규 OPEN 일시정지")
            continue
        if not candidate_is_fresh(ev, ctrl):
            stats["stale_skip"] = int(stats.get("stale_skip", 0)) + 1
            if is_s1:
                _record_decision(stats, "last_skip", ev, "stale_skip", "후보 TTL 만료")
            continue
        if ctrl.get("open_trade_ready_only", True) and not is_s1:
            stats["not_s1_skip"] = int(stats.get("not_s1_skip", 0)) + 1
            continue
        if ctrl.get("preopen_micro_recheck", True) and ctrl.get("notify_open_require_micro_fresh", True) and not micro_fresh(ev, ctrl):
            stats["micro_preopen_wait"] = int(stats.get("micro_preopen_wait", 0)) + 1
            if is_s1:
                _record_decision(stats, "last_skip", ev, "micro_preopen_wait", "OPEN 직전 micro 신선정보 없음")
            continue
        if ctrl.get("notify_open_require_ws_fresh", False) and not ws_fresh(ev):
            stats["ws_preopen_wait"] = int(stats.get("ws_preopen_wait", 0)) + 1
            if is_s1:
                _record_decision(stats, "last_skip", ev, "ws_preopen_wait", "OPEN 직전 WS 신선정보 없음")
            continue
        t = normalize_ticker(ev.get("ticker") or ev.get("market") or ev.get("symbol"))
        price = get_event_price(ev)
        if not t:
            stats["ticker_missing_skip"] = int(stats.get("ticker_missing_skip", 0)) + 1
            stats["bad_skip"] = int(stats.get("bad_skip", 0)) + 1  # legacy aggregate
            if is_s1:
                _record_decision(stats, "last_skip", ev, "ticker_missing_skip", "ticker 필수값 없음")
            continue
        if price <= 0:
            stats["price_missing_skip"] = int(stats.get("price_missing_skip", 0)) + 1
            stats["bad_skip"] = int(stats.get("bad_skip", 0)) + 1  # legacy aggregate
            if is_s1:
                _record_decision(stats, "last_skip", ev, "price_missing_skip", "가격 필수값 없음")
            continue
        eid = event_id(ev, "strict")
        if eid in existing_ids:
            stats["dup_skip"] = int(stats.get("dup_skip", 0)) + 1
            if is_s1:
                _record_decision(stats, "last_skip", ev, "dup_skip", "이미 OPEN/CLOSED 처리한 후보")
            continue
        if ctrl.get("block_same_ticker_open", True) and t in blocked_tickers:
            stats["same_ticker_skip"] = int(stats.get("same_ticker_skip", 0)) + 1
            if is_s1:
                _record_decision(stats, "last_skip", ev, "same_ticker_skip", "동일 종목 OPEN 보유중")
            continue
        ok_final, final_reasons, final_diag = paper_final_safety(ev, ctrl)
        if not ok_final:
            ev["paper_entry_hold_reasons"] = final_reasons
            # Keep the legacy field for main-bot compatibility, but user-facing wording is now 보류/recheck.
            ev["paper_final_block_reasons"] = final_reasons
            ev["paper_final_safety_diagnostics"] = final_diag
            ev["paper_entry_action"] = "recheck_hold"
            stats["paper_entry_hold"] = int(stats.get("paper_entry_hold", 0)) + 1
            stats["paper_final_block"] = int(stats.get("paper_final_block", 0)) + 1  # legacy counter
            if is_s1:
                _record_decision(stats, "last_paper_entry_hold", ev, "paper_entry_hold", " / ".join(final_reasons[:5]))
                _record_decision(stats, "last_paper_final_block", ev, "paper_entry_hold", " / ".join(final_reasons[:5]))
            continue
        ev = dict(ev)
        ev["lane"] = "strict"
        ev["paper_final_safety_passed"] = True
        ev["paper_final_safety_diagnostics"] = final_diag
        _record_decision(stats, "last_open_try", ev, "selected_for_open", "paper 최종안전문 통과")
        picked.append((eid, ev))
        existing_ids.add(eid)
        blocked_tickers.add(t)
        stats["selected_s1"] = int(stats.get("selected_s1", 0)) + 1
    stats["latest_count"] = latest_count
    stats["merged_fresh"] = sum(1 for r in filtered if candidate_is_fresh(r, ctrl))
    return picked, dict(stats), filtered

def copy_entry_context(ev: Dict[str, Any]) -> Dict[str, Any]:
    ctx: Dict[str, Any] = {}
    if isinstance(ev.get("entry_context"), dict):
        ctx.update(ev["entry_context"])
    for k, v in ev.items():
        if k.startswith("_"):
            continue
        if k not in ctx and k not in {"raw"}:
            ctx[k] = v
    return ctx


def _diag_sources(ev: Dict[str, Any], ctx: Optional[Dict[str, Any]] = None) -> List[Dict[str, Any]]:
    srcs: List[Dict[str, Any]] = []
    for obj in (ev, ctx, ev.get("entry_context"), ev.get("entry_snapshot"), ev.get("profile"), ev.get("raw")):
        if isinstance(obj, dict):
            srcs.append(obj)
            for kk in (
                "flat", "strategy", "strategy_context", "metrics", "entry_metrics", "recheck_metrics",
                "orderflow", "orderflow_summary", "feature", "features", "price_flow", "price_context",
                "money_flow", "position", "risk", "micro", "micro_summary", "ws", "quote",
                "market", "market_context", "standard_values", "candidate_values", "score_context", "ticker_state",
            ):
                vv = obj.get(kk)
                if isinstance(vv, dict):
                    srcs.append(vv)
    return srcs


def _diag_first(ev: Dict[str, Any], keys: Iterable[str], default: Any = None, ctx: Optional[Dict[str, Any]] = None) -> Any:
    for src in _diag_sources(ev, ctx):
        for k in keys:
            if k in src and src.get(k) not in (None, "", [], {}):
                return src.get(k)
    return default


def _diag_list(ev: Dict[str, Any], keys: Iterable[str], ctx: Optional[Dict[str, Any]] = None, limit: int = 8) -> List[str]:
    out: List[str] = []
    for src in _diag_sources(ev, ctx):
        for k in keys:
            v = src.get(k)
            if v in (None, "", [], {}):
                continue
            vals: List[Any]
            if isinstance(v, list):
                vals = v
            elif isinstance(v, dict):
                vals = [f"{kk}:{vv}" for kk, vv in list(v.items())[:limit]]
            else:
                vals = [v]
            for item in vals:
                txt = str(item).strip()
                if txt and txt not in out:
                    out.append(txt)
                    if len(out) >= limit:
                        return out
    return out


def _fmt_bool(v: Any) -> str:
    if isinstance(v, str):
        if v.lower() in {"fresh", "ok", "true", "1", "yes"}:
            return "OK"
        if v.lower() in {"stale", "old", "false", "0", "no"}:
            return "부족"
    if v is True:
        return "OK"
    if v is False:
        return "부족"
    return "-" if v in (None, "") else str(v)


def _fmt_pct_value(v: Any, suffix: str = "%") -> str:
    if v in (None, ""):
        return "-"
    try:
        return f"{fnum(v):.2f}{suffix}"
    except Exception:
        return str(v)



def _paper_v143_num_if_present(obj: Any, key: str) -> Optional[float]:
    if not isinstance(obj, dict) or obj.get(key) in (None, ""):
        return None
    try:
        return float(str(obj.get(key)).replace(",", "").replace("%", "").strip())
    except Exception:
        return None


def _paper_v143_all_present(srcs: List[Dict[str, Any]], keys: List[str], group: str) -> List[Dict[str, Any]]:
    out: List[Dict[str, Any]] = []
    for src in srcs:
        if not isinstance(src, dict):
            continue
        for k in keys:
            v = _paper_v143_num_if_present(src, k)
            if v is not None:
                out.append({"group": group, "source": k, "value": round(float(v), 4)})
    return out


def _paper_v143_first_present(srcs: List[Dict[str, Any]], keys: List[str]) -> Tuple[Optional[float], str]:
    for src in srcs:
        if not isinstance(src, dict):
            continue
        for k in keys:
            v = _paper_v143_num_if_present(src, k)
            if v is not None:
                return v, k
    return None, ""


def _paper_v143_price_delta_candidate(srcs: List[Dict[str, Any]]) -> Dict[str, Any]:
    cur, cur_src = _paper_v143_first_present(srcs, [
        "current_price", "price", "last_price", "close", "trade_price", "quote_price", "ws_price", "micro_price"
    ])
    ref, ref_src = _paper_v143_first_present(srcs, [
        "detected_price", "watch_price", "first_seen_price", "s3_price", "s2_price",
        "candidate_price", "base_price", "entry_signal_price", "signal_price", "recheck_start_price"
    ])
    if cur is not None and ref is not None and cur > 0 and ref > 0:
        return {"group": "price_delta", "source": f"{cur_src}/{ref_src}", "value": round((cur - ref) / ref * 100.0, 4)}
    return {}




def _paper_v144_flow_window_candidates(ev: Dict[str, Any], ctx: Optional[Dict[str, Any]] = None) -> List[Dict[str, Any]]:
    """Return actually-present short-flow windows for the final no-reaction proof.

    This deliberately does not treat missing values as 0. Missing information is not
    silently converted into a block signal; only explicit 0/negative short-flow rows
    are used to prevent VIRTUAL-style no-reaction entries.
    """
    ctx = ctx if isinstance(ctx, dict) else {}
    srcs = _diag_sources(ev, ctx)
    groups = [
        ("1m", ["flow_1m_pct", "change_1m", "chg_1m", "flow_1m", "change_1m_pct", "ret_1m_pct", "price_change_1m"]),
        ("3m", ["flow_3m_pct", "change_3m", "chg_3m", "flow_3m", "change_3m_pct", "ret_3m_pct", "price_change_3m"]),
        ("5m", ["flow_5m_pct", "change_5m", "chg_5m", "flow_5m", "change_5m_pct", "ret_5m_pct", "price_change_5m"]),
        ("15m", ["flow_15m_pct", "change_15m", "chg_15m", "flow_15m", "change_15m_pct", "ret_15m_pct", "price_change_15m"]),
    ]
    out: List[Dict[str, Any]] = []
    for label, keys in groups:
        val, src = _paper_v143_first_present(srcs, keys)
        if val is not None:
            out.append({"window": label, "value": round(float(val), 4), "source": src})
    return out


def _paper_v144_reaction_proof_block(diag: Dict[str, Any], ctrl: Dict[str, Any]) -> str:
    """Hold confirmed no-reaction S1 entries right before OPEN.

    This is not an S1/S2/S3 threshold change and not a discard rule. If enough
    short-flow windows are present and all are flat/negative below the tiny proof
    threshold, paper only skips this OPEN attempt and leaves the candidate to the
    next recheck/strategy cycle.
    """
    if not bool(ctrl.get("paper_final_reaction_proof_enabled", True)):
        return ""
    flows = diag.get("flow_window_candidates") if isinstance(diag.get("flow_window_candidates"), list) else []
    min_windows = int(fnum(ctrl.get("paper_final_reaction_proof_min_windows"), default=2.0))
    min_flow = fnum(ctrl.get("paper_final_reaction_proof_min_flow_pct"), default=0.01)
    usable = []
    for x in flows:
        if isinstance(x, dict) and x.get("value") is not None:
            try:
                usable.append((str(x.get("window") or "?"), float(x.get("value") or 0.0)))
            except Exception:
                pass
    if len(usable) < max(1, min_windows):
        return ""
    best = max(v for _w, v in usable)
    if best < min_flow:
        flow_txt = " / ".join(f"{w} {v:+.2f}%" for w, v in usable[:4])
        return f"진입 직전 무반응 재확인 보류({flow_txt} / 최고흐름 {best:+.2f}% < +{min_flow:.2f}%)"
    return ""

def paper_price_reaction_spine(ev: Dict[str, Any], ctx: Optional[Dict[str, Any]] = None) -> Dict[str, Any]:
    """paper final safety가 strategy recheck와 같은 가격반응 spine을 보게 한다.

    명시 0값이 있더라도 실제 non-zero short-flow/price-delta가 있으면 그 값을 사용한다.
    이것은 최종 안전문 기준 완화가 아니라 구 0.00 경로 제거다.
    """
    ctx = ctx if isinstance(ctx, dict) else {}
    srcs = _diag_sources(ev, ctx)
    explicit_keys = ["price_reaction_pct", "reaction_pct", "price_response_pct", "price_recheck_pct"]
    flow_keys = [
        "flow_1m_pct", "change_1m", "chg_1m", "change_1m_pct", "ret_1m_pct", "price_change_1m",
        "flow_3m_pct", "change_3m", "chg_3m", "change_3m_pct", "ret_3m_pct", "price_change_3m",
    ]
    candidates: List[Dict[str, Any]] = []
    candidates.extend(_paper_v143_all_present(srcs, explicit_keys, "explicit"))
    candidates.extend(_paper_v143_all_present(srcs, flow_keys, "short_flow"))
    pd = _paper_v143_price_delta_candidate(srcs)
    if pd:
        candidates.append(pd)
    explicit = [c for c in candidates if c.get("group") == "explicit"]
    nonzero_explicit = [c for c in explicit if abs(float(c.get("value") or 0.0)) >= 0.001]
    if nonzero_explicit:
        c = nonzero_explicit[0]
        return {"known": True, "value": float(c["value"]), "source": c.get("source"), "method": "explicit", "candidates": candidates[:8], "schema": "paper_price_reaction_spine_v143"}
    nonzero_alt = [c for c in candidates if c.get("group") in ("short_flow", "price_delta") and abs(float(c.get("value") or 0.0)) >= 0.001]
    if nonzero_alt:
        c = nonzero_alt[0]
        zero_src = explicit[0].get("source") if explicit else ""
        method = "explicit_zero_overridden" if explicit else str(c.get("group") or "alternate")
        return {"known": True, "value": float(c["value"]), "source": f"{c.get('source')}" + (f"; explicit0={zero_src}" if zero_src else ""), "method": method, "candidates": candidates[:8], "schema": "paper_price_reaction_spine_v143"}
    if explicit:
        c = explicit[0]
        return {"known": True, "value": float(c.get("value") or 0.0), "source": c.get("source"), "method": "explicit_zero", "candidates": candidates[:8], "schema": "paper_price_reaction_spine_v143"}
    if candidates:
        c = candidates[0]
        return {"known": True, "value": float(c.get("value") or 0.0), "source": c.get("source"), "method": str(c.get("group") or "candidate"), "candidates": candidates[:8], "schema": "paper_price_reaction_spine_v143"}
    return {"known": False, "value": 0.0, "source": "missing", "method": "missing", "candidates": [], "schema": "paper_price_reaction_spine_v143"}

def build_entry_diagnostics(ev: Dict[str, Any], ctx: Optional[Dict[str, Any]] = None) -> Dict[str, Any]:
    ctx = ctx if isinstance(ctx, dict) else {}
    reasons = _diag_list(ev, ("final_entry_reasons", "trade_ready_reasons", "s_stage_reasons", "entry_reasons", "why", "reason"), ctx, 10)
    missing = _diag_list(ev, ("missing_info", "missing_fields", "info_missing", "info_needed", "need_info", "entry_missing_info", "s1_missing", "s1_missing_conditions", "unmet_conditions", "block_reasons"), ctx, 10)
    matched = _diag_list(ev, ("matched_strategies", "strategy_matches", "strategy_tags", "tags"), ctx, 8)
    diag = {
        "stage_policy_schema": _diag_first(ev, ("stage_policy_schema", "lifecycle_schema"), ctx=ctx),
        "stage": _diag_first(ev, ("s_stage", "candidate_stage", "candidate_grade", "grade"), ctx=ctx),
        "strategy_key": _diag_first(ev, ("strategy_key", "paper_strategy_key", "strategy", "route", "section"), ctx=ctx),
        "strategy_label": _diag_first(ev, ("strategy_label", "paper_strategy_label", "final_entry_label"), ctx=ctx),
        "entry_reasons": reasons,
        "missing_info": missing,
        "matched_strategies": matched,
        "micro_fresh": _fmt_bool(_diag_first(ev, ("micro_fresh", "micro_row_status", "micro_status"), ctx=ctx)),
        "ws_fresh": _fmt_bool(_diag_first(ev, ("ws_fresh", "ws_row_status", "quote_fresh", "quote_status"), ctx=ctx)),
        "buy_ratio": fnum(_diag_first(ev, ("buy_ratio", "buy_ratio_30s", "buy_trade_ratio", "micro_buy_ratio"), ctx=ctx), default=-1.0),
        "buy_sustain_1m": fnum(_diag_first(ev, ("micro_buy_ratio_sustain_1m", "buy_ratio_1m", "buy_sustain_1m"), ctx=ctx), default=-1.0),
        "spread_pct": fnum(_diag_first(ev, ("spread_pct", "micro_spread_pct", "orderbook_spread_pct"), ctx=ctx), default=-1.0),
        "slippage_pct": fnum(_diag_first(ev, ("slippage_est_pct", "expected_slippage_pct", "slippage_pct"), ctx=ctx), default=-1.0),
        "price_reaction_pct": fnum(_diag_first(ev, ("price_reaction_pct", "price_reaction", "reaction_pct", "price_recheck_pct"), ctx=ctx), default=0.0),
        "flow_1m_pct": fnum(_diag_first(ev, ("flow_1m_pct", "change_1m", "chg_1m", "flow_1m", "change_1m_pct", "ret_1m_pct", "price_change_1m"), ctx=ctx), default=0.0),
        "flow_3m_pct": fnum(_diag_first(ev, ("flow_3m_pct", "change_3m", "chg_3m", "flow_3m", "change_3m_pct", "ret_3m_pct", "price_change_3m"), ctx=ctx), default=0.0),
        "flow_5m_pct": fnum(_diag_first(ev, ("chg_5m", "flow_5m", "change_5m_pct", "ret_5m_pct"), ctx=ctx), default=0.0),
        "flow_15m_pct": fnum(_diag_first(ev, ("chg_15m", "flow_15m", "change_15m_pct", "ret_15m_pct"), ctx=ctx), default=0.0),
        "flow_30m_pct": fnum(_diag_first(ev, ("chg_30m", "flow_30m", "change_30m_pct", "ret_30m_pct"), ctx=ctx), default=0.0),
        "vwap_pos_pct": fnum(_diag_first(ev, ("vwap_pos_pct", "vwap_gap_pct", "vwap_position_pct", "vwap"), ctx=ctx), default=0.0),
        "ema5_pos_pct": fnum(_diag_first(ev, ("ema5_pos_pct", "ema5_gap_pct", "ema5_position_pct", "ema5"), ctx=ctx), default=0.0),
        "relative_strength": fnum(_diag_first(ev, ("relative_strength", "relative", "market_relative_strength"), ctx=ctx), default=0.0),
        "turnover_krw": fnum(_diag_first(ev, ("turnover_krw", "trade_amount_krw", "value_krw", "acc_trade_price_24h"), ctx=ctx), default=0.0),
        "sell_pressure": _diag_first(ev, ("sell_pressure", "ask_wall_pressure", "sell_trade_pressure"), ctx=ctx),
    }
    diag["flow_window_candidates"] = _paper_v144_flow_window_candidates(ev, ctx)
    diag["flow_window_source_schema"] = "paper_final_reaction_proof_v479_recheck_hold"
    diag["flow_window_map"] = {str(x.get("window")): x for x in diag["flow_window_candidates"] if isinstance(x, dict) and x.get("window")}
    pr_spine = paper_price_reaction_spine(ev, ctx)
    diag["price_reaction_pct"] = fnum(pr_spine.get("value"), default=0.0)
    diag["price_reaction_source"] = pr_spine.get("source")
    diag["price_reaction_method"] = pr_spine.get("method")
    diag["price_reaction_spine_schema"] = pr_spine.get("schema")
    diag["price_reaction_candidates"] = pr_spine.get("candidates") or []
    passed: List[str] = []
    if diag["micro_fresh"] == "OK": passed.append("micro신선")
    if diag["ws_fresh"] == "OK": passed.append("WS신선")
    if diag["buy_ratio"] >= 0: passed.append(f"매수체결 {diag['buy_ratio']:.2f}")
    if diag["buy_sustain_1m"] >= 0: passed.append(f"1분지속 {diag['buy_sustain_1m']:.2f}")
    if diag["spread_pct"] >= 0: passed.append(f"스프레드 {diag['spread_pct']:.2f}%")
    if diag["slippage_pct"] >= 0: passed.append(f"슬리피지 {diag['slippage_pct']:.2f}%")
    if diag["price_reaction_pct"]: passed.append(f"가격반응 {diag['price_reaction_pct']:+.2f}%")
    diag["condition_pass_summary"] = passed[:8]
    return diag


def _v494_first_ts_from_sources(ev: Dict[str, Any], ctx: Optional[Dict[str, Any]], keys: Iterable[str]) -> Tuple[float, str]:
    """Trace helper only. It must not change entry/exit decisions."""
    ctx = ctx if isinstance(ctx, dict) else {}
    for src in _diag_sources(ev, ctx):
        if not isinstance(src, dict):
            continue
        for k in keys:
            if k in src:
                ts = row_ts(src, k)
                if ts > 0:
                    return ts, k
    return 0.0, ""


def build_entry_timing_trace(ev: Dict[str, Any], diag: Optional[Dict[str, Any]] = None) -> Dict[str, Any]:
    """진입이 늦었는지 확인하기 위한 trace. 조건/청산 변경에 쓰지 않는다."""
    ctx = copy_entry_context(ev)
    diag = diag if isinstance(diag, dict) else build_entry_diagnostics(ev, ctx)
    source_ts, src_key = _v494_first_ts_from_sources(ev, ctx, (
        "first_detected_ts", "first_seen_ts", "detected_ts", "candidate_created_at",
        "source_created_at", "created_at", "event_ts", "ts", "timestamp",
    ))
    promotion_ts, promotion_key = _v494_first_ts_from_sources(ev, ctx, (
        "s1_promotion_ts", "recheck_promotion_ts", "promoted_ts", "paper_handoff_ts",
        "handoff_ts", "updated_ts", "updated_at",
    ))
    nowv = now_ts()
    source_age_sec = max(0.0, nowv - source_ts) if source_ts > 0 else 0.0
    promotion_age_sec = max(0.0, nowv - promotion_ts) if promotion_ts > 0 else 0.0
    source_to_promotion_sec = max(0.0, promotion_ts - source_ts) if source_ts > 0 and promotion_ts > 0 else 0.0
    hot1 = _diag_first(ev, ("hot_rank_1m", "scanner_hot_rank_1m"), ctx=ctx)
    hot3 = _diag_first(ev, ("hot_rank_3m", "scanner_hot_rank_3m"), ctx=ctx)
    change_1m_source = _diag_first(ev, ("change_1m_source", "scanner_change_1m_source"), ctx=ctx)
    change_3m_source = _diag_first(ev, ("change_3m_source", "scanner_change_3m_source"), ctx=ctx)
    flags: List[str] = []
    f1 = fnum(diag.get("flow_1m_pct"), default=0.0)
    f3 = fnum(diag.get("flow_3m_pct"), default=0.0)
    react = fnum(diag.get("price_reaction_pct"), default=0.0)
    pr_src = str(diag.get("price_reaction_source") or "")
    if source_age_sec >= 120:
        flags.append(f"후보오래됨({source_age_sec/60.0:.1f}분)")
    if source_to_promotion_sec >= 60:
        flags.append(f"S1승격지연({source_to_promotion_sec:.0f}초)")
    if promotion_age_sec >= 45:
        flags.append(f"paper읽기지연({promotion_age_sec:.0f}초)")
    if f1 <= 0.01 and max(react, f3) >= 0.15:
        flags.append("현재1m약함/과거반응주의")
    if pr_src and ("3m" in pr_src or "5m" in pr_src or "15m" in pr_src) and f1 <= 0.01:
        flags.append("반응원천이현재1m아님")
    return {
        "schema": "entry_timing_trace_v494",
        "source_ts": source_ts, "source_key": src_key or "-",
        "s1_promotion_ts": promotion_ts, "s1_promotion_key": promotion_key or "-",
        "source_age_sec": round(source_age_sec, 1), "source_age_min": round(source_age_sec / 60.0, 2),
        "source_to_promotion_sec": round(source_to_promotion_sec, 1),
        "paper_read_delay_sec": round(promotion_age_sec, 1),
        "price_reaction_pct": round(react, 4),
        "price_reaction_source": diag.get("price_reaction_source") or "-",
        "price_reaction_method": diag.get("price_reaction_method") or "-",
        "flow_1m_pct": round(f1, 4), "flow_3m_pct": round(f3, 4),
        "hot_rank_1m": hot1, "hot_rank_3m": hot3,
        "change_1m_source": change_1m_source or "-", "change_3m_source": change_3m_source or "-",
        "flags": flags,
    }


def format_entry_timing_line(trace: Any, prefix: str = "- ") -> str:
    if not isinstance(trace, dict) or not trace:
        return prefix + "진입시점: trace 없음"
    age = fnum(trace.get("source_age_min"), default=0.0)
    promo_delay = fnum(trace.get("source_to_promotion_sec"), default=0.0)
    paper_delay = fnum(trace.get("paper_read_delay_sec"), default=0.0)
    f1 = fnum(trace.get("flow_1m_pct"), default=0.0)
    f3 = fnum(trace.get("flow_3m_pct"), default=0.0)
    hot1 = trace.get("hot_rank_1m") or "-"
    hot3 = trace.get("hot_rank_3m") or "-"
    flags = trace.get("flags") if isinstance(trace.get("flags"), list) else []
    tail = (" / 주의 " + ", ".join(str(x) for x in flags[:2])) if flags else ""
    delay_part = f" / S1까지 {promo_delay:.0f}s / paper {paper_delay:.0f}s" if promo_delay or paper_delay else ""
    return prefix + f"진입시점: 감지후 {age:.1f}분{delay_part} / 1m {f1:+.2f}% · 3m {f3:+.2f}% / hot {hot1}/{hot3}{tail}"


def _paper_v479_flow_display(diag: Dict[str, Any], window: str) -> str:
    """Display only canonical/present short-flow values.

    Missing short-flow information is shown as '-' rather than being displayed as
    +0.00%. This is display hygiene, not a stricter entry condition.
    """
    fmap = diag.get("flow_window_map") if isinstance(diag.get("flow_window_map"), dict) else {}
    item = fmap.get(window) if isinstance(fmap, dict) else None
    if isinstance(item, dict) and item.get("value") is not None:
        try:
            return f"{float(item.get('value')):+.2f}%"
        except Exception:
            return "-"
    return "-"


def format_entry_diag_lines(diag: Dict[str, Any], prefix: str = "- ") -> List[str]:
    lines: List[str] = []
    reasons = diag.get("entry_reasons") if isinstance(diag.get("entry_reasons"), list) else []
    missing = diag.get("missing_info") if isinstance(diag.get("missing_info"), list) else []
    passed = diag.get("condition_pass_summary") if isinstance(diag.get("condition_pass_summary"), list) else []
    if reasons:
        lines.append(prefix + "진입근거: " + " / ".join(str(x) for x in reasons[:4]))
    if passed:
        lines.append(prefix + "통과정보: " + " / ".join(str(x) for x in passed[:5]))
    flow = (
        f"1m {_paper_v479_flow_display(diag, '1m')} · "
        f"3m {_paper_v479_flow_display(diag, '3m')} · "
        f"5m {_paper_v479_flow_display(diag, '5m')} · "
        f"15m {_paper_v479_flow_display(diag, '15m')}"
    )
    lines.append(prefix + "흐름: " + flow)
    pos = f"VWAP {diag.get('vwap_pos_pct',0):+.2f}% · EMA5 {diag.get('ema5_pos_pct',0):+.2f}% · 상대강도 {diag.get('relative_strength',0):+.2f}"
    lines.append(prefix + "위치: " + pos)
    if missing:
        lines.append(prefix + "부족/주의: " + " / ".join(str(x) for x in missing[:5]))
    else:
        lines.append(prefix + "부족/주의: 최종안전문 통과")
    return lines


def open_position(pos_id: str, ev: Dict[str, Any]) -> Dict[str, Any]:
    ticker = normalize_ticker(ev.get("ticker") or ev.get("market") or ev.get("symbol"))
    detected = get_event_price(ev)
    price = live_price(ticker, detected) or detected
    ts = now_ts()
    ctx = copy_entry_context(ev)
    diag = ev.get("paper_final_safety_diagnostics") if isinstance(ev.get("paper_final_safety_diagnostics"), dict) else build_entry_diagnostics(ev, ctx)
    timing_trace = build_entry_timing_trace(ev, diag)
    diag["entry_timing_trace"] = timing_trace
    grade = str(ev.get("s_stage") or ev.get("candidate_stage") or ev.get("candidate_grade") or ev.get("grade") or "S1").upper()
    current_main_version = active_main_version()
    event_main_version = ev.get("main_version") or ev.get("deploy_version") or ev.get("opened_main_version") or ""
    stamped_main_version = current_main_version if current_main_version else event_main_version
    raw_main_version = str(event_main_version or "").strip()
    return {
        "pos_id": pos_id,
        "event_id": pos_id,
        "ticker": ticker,
        "lane": "strict",
        "opened_at": ts,
        "opened_at_text": iso_ts(ts),
        "opened_paper_version": VERSION,
        # 성과판용 버전은 현재 DEPLOY_TARGET 기준으로 단일화한다.
        # 후보/worker 원본의 구버전 표기는 추적용 raw 필드에만 남긴다.
        "score_main_version": stamped_main_version,
        "opened_main_version": stamped_main_version,
        "main_version": stamped_main_version,
        "deploy_version": stamped_main_version,
        "source_main_version_raw": raw_main_version,
        "strategy_worker_version": ev.get("strategy_worker_version") or ev.get("source_version") or ev.get("brain_version") or "",
        "paper_final_safety_passed": bool(ev.get("paper_final_safety_passed")),
        "entry_price": price,
        "detected_price": detected,
        "current_price": price,
        "peak_pct": 0.0,
        "trough_pct": 0.0,
        "last_pnl_pct": -fnum(DEFAULT_CONTROL.get("fee_pct_roundtrip"), default=0.10),
        "last_update": ts,
        "strategy": ev.get("strategy") or ev.get("strategy_key") or ev.get("route") or ev.get("section") or "unknown",
        "strategy_key": ev.get("strategy_key") or ev.get("paper_strategy_key") or ev.get("route") or ev.get("strategy"),
        "strategy_label": ev.get("strategy_label") or ev.get("paper_strategy_label") or ev.get("final_entry_label"),
        "candidate_grade": grade,
        "candidate_grade_label": ev.get("candidate_grade_label") or ev.get("s_stage_label") or "✅ S1 최종 paper OPEN",
        "trade_ready": bool(ev.get("trade_ready") or ev.get("paper_bot_open") or ev.get("open_eligible") or grade == "S1"),
        "trade_ready_label": ev.get("trade_ready_label") or ev.get("final_entry_label") or "S1 paper open",
        "final_entry_action": ev.get("final_entry_action") or "paper_open",
        "final_entry_label": ev.get("final_entry_label") or ev.get("trade_ready_label") or "S1 paper open",
        "final_entry_reasons": ev.get("final_entry_reasons") or ev.get("trade_ready_reasons") or [],
        "scan_id": ev.get("scan_id") or ev.get("source_scan_id") or "",
        "brain_version": ev.get("brain_version") or ev.get("source_version") or "",
        "score": fnum(ev.get("score"), ev.get("leader_score"), default=0.0),
        "edge": fnum(ev.get("edge"), ev.get("edge_score"), default=0.0),
        "reason": ev.get("reason") or ev.get("why") or ev.get("hold_reason") or "",
        "source_created_at": event_created_ts(ev),
        "source_created_at_text": ev.get("created_at_text") or ev.get("source_created_at_text") or "",
        "entry_context": ctx,
        "entry_diagnostics": diag,
        "entry_timing_trace": timing_trace,
        "entry_condition_reasons": diag.get("entry_reasons") or [],
        "entry_missing_info": diag.get("missing_info") or [],
        "entry_condition_pass_summary": diag.get("condition_pass_summary") or [],
        "raw": ev,
    }


EXIT_ICONS = {
    "take_profit": "✅",
    "stop_loss": "❌",
    "protect_stop_after_tp": "🛡️",
    "slow_no_progress": "⚠️",
    "fast_fail_stop": "📉",
    "time_exit": "⏱️",
    "spike_fast_fail_stop": "⚡",
    "spike_runner_trailing": "🏃",
    "spike_time_exit": "⏱️",
}

EXIT_LABELS = {
    "take_profit": "✅ 익절 종료",
    "stop_loss": "❌ 손절 종료",
    "protect_stop_after_tp": "🛡️ 익절 후 보호청산",
    "slow_no_progress": "⚠️ 지지부진 종료",
    "fast_fail_stop": "📉 빠른실패 정리",
    "time_exit": "⏱️ 시간 종료",
    "spike_fast_fail_stop": "⚡ 급등형 빠른실패",
    "spike_runner_trailing": "🏃 급등형 추적청산",
    "spike_time_exit": "⏱️ 급등형 시간청산",
}

EXIT_TITLES = {
    "take_profit": "✅ paper 익절 CLOSED",
    "stop_loss": "❌ paper 손절 CLOSED",
    "protect_stop_after_tp": "🛡️ paper 보호익절 CLOSED",
    "slow_no_progress": "⚠️ paper 지지부진 CLOSED",
    "fast_fail_stop": "📉 paper 빠른실패 CLOSED",
    "time_exit": "⏱️ paper 시간청산 CLOSED",
    "spike_fast_fail_stop": "⚡ paper 급등형 빠른실패 CLOSED",
    "spike_runner_trailing": "🏃 paper 급등형 추적청산 CLOSED",
    "spike_time_exit": "⏱️ paper 급등형 시간청산 CLOSED",
}


def closed_title(row: Dict[str, Any]) -> str:
    reason = str(row.get("exit_reason") or row.get("exit_rule") or "").strip()
    return EXIT_TITLES.get(reason, "🔴 paper CLOSED")



def adaptive_protect_floor(peak: float, ctrl: Dict[str, Any]) -> float:
    """수익권 진입 후 되돌림 방어선.

    숫자 하나로 고정하지 않고 최고수익 구간에 따라 최소 보존선을 올린다.
    잘 가는 후보는 take_profit/추가보유 여지를 남기되, +0.7~1.0% 갔다가
    음전까지 방치되는 흐름을 먼저 막는 목적이다.
    """
    base = fnum(ctrl.get("protect_floor_pct"), default=0.35)
    if peak >= fnum(ctrl.get("protect_big_trigger_pct"), default=1.40):
        return max(base, fnum(ctrl.get("protect_big_floor_pct"), default=0.75))
    if peak >= fnum(ctrl.get("protect_strong_trigger_pct"), default=1.00):
        return max(base, fnum(ctrl.get("protect_strong_floor_pct"), default=0.50))
    return base


def should_fast_fail(age_min: float, peak: float, net: float, ctrl: Dict[str, Any]) -> bool:
    """진입 후 반응이 없으면 기본 손절선까지 기다리지 않고 정리한다."""
    peak_limit = fnum(ctrl.get("fast_fail_peak_under_pct"), default=0.20)
    if peak >= peak_limit:
        return False
    early_min = fnum(ctrl.get("fast_fail_after_min"), default=2.5)
    early_loss = fnum(ctrl.get("fast_fail_loss_pct"), default=-0.35)
    late_min = fnum(ctrl.get("fast_fail_after_min_late"), default=5.0)
    late_loss = fnum(ctrl.get("fast_fail_loss_pct_late"), default=-0.25)
    return (age_min >= early_min and net <= early_loss) or (age_min >= late_min and net <= late_loss)


def _strategy_text_for_exit(pos: Dict[str, Any]) -> str:
    parts: List[str] = []
    for k in ("strategy", "strategy_key", "strategy_label", "final_entry_label", "candidate_grade_label"):
        v = pos.get(k)
        if v:
            parts.append(str(v))
    raw = pos.get("raw") if isinstance(pos.get("raw"), dict) else {}
    ctx = pos.get("entry_context") if isinstance(pos.get("entry_context"), dict) else {}
    diag = pos.get("entry_diagnostics") if isinstance(pos.get("entry_diagnostics"), dict) else {}
    for obj in (raw, ctx, diag):
        for k in ("strategy", "strategy_key", "strategy_label", "paper_strategy_label", "final_entry_label"):
            v = obj.get(k) if isinstance(obj, dict) else None
            if v:
                parts.append(str(v))
    return " ".join(parts)


def _is_profit_run_strategy(pos: Dict[str, Any], ctrl: Dict[str, Any]) -> bool:
    text = _strategy_text_for_exit(pos).lower()
    keys = ctrl.get("profit_run_strategy_keywords")
    if not isinstance(keys, list) or not keys:
        keys = ["주도", "유동보유", "leader", "momentum"]
    return any(str(k).lower() in text for k in keys if str(k).strip())


def _should_extend_profit_run(pos: Dict[str, Any], age_min: float, peak: float, net: float, ctrl: Dict[str, Any]) -> Tuple[bool, str]:
    """v486: 수익권에서 살아있는 주도흐름은 15분 고정 종료하지 않고 1회 연장한다.

    조건을 새로 조이는 용도가 아니라 time_exit 직전의 청산 판단을 한곳에서 정리한다.
    무반응/손실 후보는 fast_fail/stop_loss가 먼저 처리한다.
    """
    if not bool(ctrl.get("profit_run_extend_enabled", True)):
        return False, "연장 비활성"
    max_count = int(fnum(ctrl.get("profit_run_extend_max_count"), default=1))
    done = int(fnum(pos.get("time_exit_extension_count"), default=0))
    if done >= max_count:
        return False, "연장횟수 소진"
    if not _is_profit_run_strategy(pos, ctrl):
        return False, "연장대상 전략 아님"
    min_net = fnum(ctrl.get("profit_run_extend_min_net_pct"), default=0.20)
    min_peak = fnum(ctrl.get("profit_run_extend_min_peak_pct"), default=0.25)
    max_giveback = fnum(ctrl.get("profit_run_extend_max_giveback_pct"), default=0.25)
    giveback = max(0.0, peak - net)
    if net < min_net:
        return False, f"현재수익 부족 {net:+.2f}% < {min_net:+.2f}%"
    if peak < min_peak:
        return False, f"최고수익 부족 {peak:+.2f}% < {min_peak:+.2f}%"
    if giveback > max_giveback:
        return False, f"반납 큼 {giveback:+.2f}% > {max_giveback:+.2f}%"
    return True, f"수익권 유동보유 연장: 현재 {net:+.2f}% / 최고 {peak:+.2f}% / 반납 {giveback:+.2f}%"


def _exit_decision_spine(pos: Dict[str, Any], age_min: float, peak: float, net: float, ctrl: Dict[str, Any]) -> Dict[str, Any]:
    """v486 exit decision spine.

    청산 조건을 여러 if에 흩뜨리지 않고 우선순위별로 한곳에서 결정한다.
    우선순위: 하드손절 → 빠른실패 → 익절선 → 보호익절 → 수익권 연장 → 지지부진 → 시간종료.
    """
    protect_trigger = fnum(ctrl.get("protect_trigger_pct"), default=0.70)
    protect_floor = adaptive_protect_floor(peak, ctrl)
    protect_giveback = fnum(ctrl.get("protect_giveback_pct"), default=0.55)
    giveback = max(0.0, peak - net)
    entry_profile = str(pos.get("entry_profile") or (pos.get("canonical_entry_decision") if isinstance(pos.get("canonical_entry_decision"), dict) else {}).get("entry_profile") or "normal_common")
    exit_profile = str(pos.get("exit_profile") or (pos.get("canonical_entry_decision") if isinstance(pos.get("canonical_entry_decision"), dict) else {}).get("exit_profile") or "normal_exit")
    d: Dict[str, Any] = {
        "schema": "exit_decision_spine_v535_profiles",
        "action": "hold",
        "reason": "",
        "detail": "보유",
        "age_min": round(age_min, 4),
        "net_pct": round(net, 4),
        "peak_pct": round(peak, 4),
        "giveback_pct": round(giveback, 4),
        "protect_floor_pct": round(protect_floor, 4),
        "entry_profile": entry_profile,
        "exit_profile": exit_profile,
    }

    # v535) 급등형 paper-test 전용 빠른실패/보호/추적. 일반 후보는 기존 청산 유지.
    if entry_profile == "spike":
        spike_stop = fnum(ctrl.get("spike_stop_loss_pct"), default=-0.60)
        if net <= spike_stop:
            d.update({"action": "close", "reason": "stop_loss", "detail": f"급등형 손절선 도달: 현재 {net:+.2f}%"})
            return d
        # 60~90초 안에 +0.20~0.30도 못 찍으면 빠른 실패.
        if entry_profile == "spike" and age_min >= fnum(ctrl.get("spike_fast_fail_after_min"), default=1.5) and peak < fnum(ctrl.get("spike_fast_fail_peak_under_pct"), default=0.25) and net <= fnum(ctrl.get("spike_fast_fail_net_under_pct"), default=0.05):
            d.update({"action": "close", "reason": "spike_fast_fail_stop", "detail": f"급등형 빠른실패: 보유 {age_min:.1f}분 / 최고 {peak:+.2f}% / 현재 {net:+.2f}%"})
            return d
        # 수익권 진입 후 보호익절.
        if peak >= fnum(ctrl.get("spike_protect_trigger_pct"), default=0.70):
            spike_floor = fnum(ctrl.get("spike_protect_floor_pct"), default=0.30)
            spike_giveback = fnum(ctrl.get("spike_protect_giveback_pct"), default=0.55)
            if net <= spike_floor or giveback >= spike_giveback:
                d.update({"action": "close", "reason": "protect_stop_after_tp", "detail": f"급등형 보호익절: 최고 {peak:+.2f}% / 현재 {net:+.2f}% / 보호 {spike_floor:+.2f}% / 반납 {giveback:+.2f}%"})
                return d
        # 더 가는 놈은 고정익절보다 최고수익 trailing 우선.
        if peak >= 3.00 and giveback >= 0.95:
            d.update({"action": "close", "reason": "spike_runner_trailing", "detail": f"급등형 러너 추적청산: 최고 {peak:+.2f}% / 현재 {net:+.2f}% / 반납 {giveback:+.2f}%"})
            return d
        if peak >= 2.00 and giveback >= 0.70:
            d.update({"action": "close", "reason": "spike_runner_trailing", "detail": f"급등형 러너 추적청산: 최고 {peak:+.2f}% / 현재 {net:+.2f}% / 반납 {giveback:+.2f}%"})
            return d
        if peak >= 1.20 and giveback >= 0.45:
            d.update({"action": "close", "reason": "spike_runner_trailing", "detail": f"급등형 러너 추적청산: 최고 {peak:+.2f}% / 현재 {net:+.2f}% / 반납 {giveback:+.2f}%"})
            return d
        if entry_profile == "spike" and age_min >= fnum(ctrl.get("spike_fast_time_exit_min"), default=8.0) and peak < 0.70:
            d.update({"action": "close", "reason": "spike_time_exit", "detail": f"급등형 시간청산: 보유 {age_min:.1f}분 / 최고 {peak:+.2f}% / 현재 {net:+.2f}%"})
            return d

    # 1) 하드 손절은 최우선이다.
    stop_loss = fnum(ctrl.get("stop_loss_pct"), default=-0.55)
    if net <= stop_loss:
        d.update({"action": "close", "reason": "stop_loss", "detail": f"손절선 도달: 현재 {net:+.2f}%"})
        return d

    # 2) 진입 후 반응 없는 후보는 빨리 정리한다.
    if should_fast_fail(age_min, peak, net, ctrl):
        d.update({"action": "close", "reason": "fast_fail_stop", "detail": f"빠른실패 정리: 보유 {age_min:.1f}분 / 최고 {peak:+.2f}% / 현재 {net:+.2f}%"})
        return d

    # 3) 명시 익절선 도달.
    take_profit = fnum(ctrl.get("take_profit_pct"), default=1.20)
    if net >= take_profit:
        d.update({"action": "close", "reason": "take_profit", "detail": f"익절선 도달: 현재 {net:+.2f}%"})
        return d

    # 4) 수익권 보호. +0.70% 이상은 기존 보호익절보다 더 먼저 본다.
    if peak >= protect_trigger and (net <= protect_floor or giveback >= protect_giveback):
        d.update({"action": "close", "reason": "protect_stop_after_tp", "detail": f"수익권 보호: 최고 {peak:+.2f}% / 현재 {net:+.2f}% / 보호선 {protect_floor:+.2f}% / 반납 {giveback:+.2f}%"})
        return d

    # 4-1) +0.45~0.70% 갔다가 거의 본전까지 반납하는 케이스 방지.
    soft_trigger = fnum(ctrl.get("profit_soft_protect_trigger_pct"), default=0.45)
    soft_floor = fnum(ctrl.get("profit_soft_protect_floor_pct"), default=0.10)
    soft_giveback = fnum(ctrl.get("profit_soft_protect_giveback_pct"), default=0.45)
    if peak >= soft_trigger and (net <= soft_floor or giveback >= soft_giveback):
        d.update({"action": "close", "reason": "protect_stop_after_tp", "detail": f"수익권 소프트 보호: 최고 {peak:+.2f}% / 현재 {net:+.2f}% / 보호선 {soft_floor:+.2f}% / 반납 {giveback:+.2f}%"})
        return d

    # 5) 15분 time_exit 직전, 살아있는 수익권 주도흐름은 1회 연장한다.
    time_exit_min = fnum(ctrl.get("time_exit_minutes"), default=15.0)
    if age_min >= time_exit_min:
        ok_extend, why = _should_extend_profit_run(pos, age_min, peak, net, ctrl)
        if ok_extend:
            d.update({"action": "extend", "reason": "time_exit_extend", "detail": why})
            return d

    # 6) 지지부진.
    if age_min >= fnum(ctrl.get("slow_minutes"), default=20.0) and peak < fnum(ctrl.get("slow_peak_under_pct"), default=0.25) and net <= 0.10:
        d.update({"action": "close", "reason": "slow_no_progress", "detail": f"지지부진: 보유 {age_min:.1f}분 / 최고 {peak:+.2f}% / 현재 {net:+.2f}%"})
        return d

    # 7) 일반 time_exit.
    if age_min >= time_exit_min:
        d.update({"action": "close", "reason": "time_exit", "detail": f"시간종료: 보유 {age_min:.1f}분"})
        return d
    return d




def _v494_fast_fail_cause(row: Dict[str, Any]) -> Dict[str, Any]:
    """fast_fail 원인 표시용. 청산조건은 변경하지 않는다."""
    diag = row.get("entry_diagnostics") if isinstance(row.get("entry_diagnostics"), dict) else {}
    trace = row.get("entry_timing_trace") if isinstance(row.get("entry_timing_trace"), dict) else {}
    if not trace and isinstance(diag, dict) and isinstance(diag.get("entry_timing_trace"), dict):
        trace = diag.get("entry_timing_trace")
    peak = fnum(row.get("peak_pct"), default=0.0)
    pnl = fnum(row.get("pnl_pct"), default=fnum(row.get("last_pnl_pct"), default=0.0))
    age_min = fnum(row.get("age_min"), default=0.0)
    source_age = fnum(trace.get("source_age_sec"), default=0.0) if isinstance(trace, dict) else 0.0
    source_to_promo = fnum(trace.get("source_to_promotion_sec"), default=0.0) if isinstance(trace, dict) else 0.0
    paper_delay = fnum(trace.get("paper_read_delay_sec"), default=0.0) if isinstance(trace, dict) else 0.0
    react = fnum(diag.get("price_reaction_pct"), default=0.0) if isinstance(diag, dict) else 0.0
    buy = fnum(diag.get("buy_ratio"), default=-1.0) if isinstance(diag, dict) else -1.0
    sustain = fnum(diag.get("buy_sustain_1m"), default=-1.0) if isinstance(diag, dict) else -1.0
    spread = fnum(diag.get("spread_pct"), default=-1.0) if isinstance(diag, dict) else -1.0
    slip = fnum(diag.get("slippage_pct"), default=-1.0) if isinstance(diag, dict) else -1.0
    reasons: List[str] = []
    label = "진입후반응없음"
    if source_to_promo >= 60 or source_age >= 120 or paper_delay >= 45:
        label = "늦은진입 의심"
        if source_age >= 120: reasons.append(f"감지후 {source_age/60.0:.1f}분")
        if source_to_promo >= 60: reasons.append(f"S1승격까지 {source_to_promo:.0f}초")
        if paper_delay >= 45: reasons.append(f"paper읽기 {paper_delay:.0f}초")
    elif react < 0.10:
        label = "진입반응 약함"
        reasons.append(f"가격반응 {react:+.2f}%")
    elif buy >= 0.70 and sustain >= 0.70 and peak <= 0.02:
        label = "체결은 좋지만 가격 안 감"
        reasons.append(f"매수 {buy:.2f} / 지속 {sustain:.2f} / 최고 {peak:+.2f}%")
    elif spread >= 0.20 or slip >= 0.20:
        label = "스프레드·미끄러짐 부담"
        if spread >= 0: reasons.append(f"스프 {spread:.2f}%")
        if slip >= 0: reasons.append(f"미끄러짐 {slip:.2f}%")
    else:
        reasons.append(f"최고 {peak:+.2f}% / 최종 {pnl:+.2f}% / 보유 {age_min:.1f}분")
    return {
        "schema": "fast_fail_cause_v494",
        "label": label,
        "reasons": reasons[:5],
        "source_age_sec": round(source_age, 1),
        "source_to_promotion_sec": round(source_to_promo, 1),
        "paper_read_delay_sec": round(paper_delay, 1),
        "price_reaction_pct": round(react, 4),
        "buy_ratio": round(buy, 4) if buy >= 0 else None,
        "buy_sustain_1m": round(sustain, 4) if sustain >= 0 else None,
        "spread_pct": round(spread, 4) if spread >= 0 else None,
        "slippage_pct": round(slip, 4) if slip >= 0 else None,
    }


def _v494_fast_fail_cause_line(row: Dict[str, Any]) -> str:
    obj = row.get("fast_fail_cause") if isinstance(row.get("fast_fail_cause"), dict) else {}
    if not obj:
        return ""
    rs = obj.get("reasons") if isinstance(obj.get("reasons"), list) else []
    tail = " / " + " / ".join(str(x) for x in rs[:3]) if rs else ""
    return f"- 빠른실패원인: {obj.get('label','-')}{tail}"

def close_review_tag(peak: float, pnl: float, reason: str) -> str:
    giveback = peak - pnl
    if peak >= 0.70 and pnl < 0:
        return "보호익절 필요 후보"
    if peak >= 0.70 and giveback >= 0.55:
        return "수익 되돌림 큼"
    if reason == "fast_fail_stop":
        return "빠른실패 정리 작동"
    if pnl <= -0.60 and peak < 0.25:
        return "빠른실패 정리 후보"
    if reason == "protect_stop_after_tp":
        return "보호익절 작동"
    if pnl > 0 and peak - pnl <= 0.35:
        return "수익 보존 양호"
    return "관찰"

def update_position(pos: Dict[str, Any], ctrl: Dict[str, Any]) -> Tuple[Dict[str, Any], Optional[Dict[str, Any]]]:
    ticker = normalize_ticker(pos.get("ticker"))
    entry = fnum(pos.get("entry_price"), default=0.0)
    if not ticker or entry <= 0:
        return pos, None
    price = live_price(ticker, fnum(pos.get("current_price"), default=entry))
    gross = ((price / entry) - 1.0) * 100.0 if entry else 0.0
    net = gross - fnum(ctrl.get("fee_pct_roundtrip"), default=0.10)
    pos["current_price"] = price
    pos["last_pnl_pct"] = round(net, 4)
    pos["peak_pct"] = max(fnum(pos.get("peak_pct"), default=0.0), net)
    pos["trough_pct"] = min(fnum(pos.get("trough_pct"), default=0.0), net)
    pos["last_update"] = now_ts()
    opened_at = fnum(pos.get("opened_at"), default=now_ts())
    age_min = (now_ts() - opened_at) / 60.0
    peak = fnum(pos.get("peak_pct"), default=0.0)
    decision = _exit_decision_spine(pos, age_min, peak, net, ctrl)
    pos["exit_decision_spine"] = decision
    pos["last_exit_decision"] = decision.get("action")
    pos["last_exit_decision_reason"] = decision.get("reason") or "hold"
    pos["last_exit_decision_detail"] = decision.get("detail") or "보유"
    if decision.get("action") == "extend":
        ext_count = int(fnum(pos.get("time_exit_extension_count"), default=0)) + 1
        extend_min = fnum(ctrl.get("profit_run_extend_minutes"), default=15.0)
        pos["time_exit_extension_count"] = ext_count
        pos["time_exit_extended_at"] = now_ts()
        pos["time_exit_extended_until_age_min"] = round(age_min + extend_min, 4)
        pos["time_exit_extension_reason"] = decision.get("detail") or "수익권 유동보유 연장"
        return pos, None
    if decision.get("action") != "close":
        return pos, None
    reason = str(decision.get("reason") or "").strip()
    detail = str(decision.get("detail") or reason).strip()
    if not reason:
        return pos, None
    closed_ts = now_ts()
    hold_sec = max(0, int(closed_ts - opened_at))
    closed = dict(pos)
    current_main_version = active_main_version()
    if current_main_version:
        # v434: 성과판용 버전은 후보/OPEN에서 넘어온 구버전(v2.13.385 등)을
        # 더 이상 우선하지 않는다. 원본값은 raw로 보관하고 집계용 key만 현재 본선으로 재연결한다.
        raw_version_before_close = closed.get("score_main_version") or closed.get("closed_main_version") or closed.get("main_version") or closed.get("deploy_version") or closed.get("opened_main_version")
        if raw_version_before_close and not closed.get("source_main_version_raw"):
            closed["source_main_version_raw"] = raw_version_before_close
        for key in ("score_main_version", "closed_main_version", "opened_main_version", "main_version", "deploy_version"):
            closed[key] = current_main_version
    closed.update({
        "closed_at": closed_ts,
        "closed_at_text": iso_ts(closed_ts),
        "exit_price": price,
        "pnl_pct": round(net, 4),
        "peak_pct": round(peak, 4),
        "trough_pct": round(fnum(pos.get("trough_pct"), default=0.0), 4),
        "missed_profit_pct": round(max(0.0, peak - net), 4),
        "giveback_pct": round(max(0.0, peak - net), 4),
        "went_negative_after_profit": bool(peak >= 0.70 and net < 0),
        "close_review_tag": close_review_tag(peak, net, reason),
        "age_min": round(age_min, 2),
        "hold_sec": hold_sec,
        "exit_reason": reason,
        "exit_rule": reason,
        "exit_rule_label": EXIT_LABELS.get(reason, reason),
        "exit_rule_reason": detail,
        "exit_decision_schema": "exit_decision_spine_v486",
        "exit_decision_spine": decision,
        "time_exit_extension_count": int(fnum(pos.get("time_exit_extension_count"), default=0)),
        "time_exit_extension_reason": pos.get("time_exit_extension_reason") or "",
        "closed_paper_version": VERSION,
        "close_source": "paper_bot_v0.174_profile_final_gate_aligned",
    })
    if reason == "fast_fail_stop":
        try:
            cause = _v494_fast_fail_cause(closed)
            closed["fast_fail_cause"] = cause
            closed["fast_fail_cause_label"] = cause.get("label")
            closed["fast_fail_cause_reasons"] = cause.get("reasons") or []
        except Exception as exc:
            log_error("v494_fast_fail_cause", exc)
    return pos, closed


def fmt_price(v: Any) -> str:
    x = fnum(v, default=0.0)
    if x >= 1000:
        return f"{x:,.0f}"
    if x >= 1:
        return f"{x:,.4f}"
    return f"{x:,.8f}"


def send_message(text: str) -> None:
    if not TOKEN or not NOTIFY_CHAT_ID:
        return
    try:
        data = urllib.parse.urlencode({"chat_id": NOTIFY_CHAT_ID, "text": text[:3900], "disable_web_page_preview": "true"}).encode("utf-8")
        req = urllib.request.Request(f"https://api.telegram.org/bot{TOKEN}/sendMessage", data=data)
        urllib.request.urlopen(req, timeout=5).read()
    except Exception as exc:
        log_error("send_message", exc)


def notify_opened(pos: Dict[str, Any]) -> None:
    t = normalize_ticker(pos.get("ticker"))
    link = f"https://www.bithumb.com/trade/order/{t}_KRW" if t else ""
    diag = pos.get("entry_diagnostics") if isinstance(pos.get("entry_diagnostics"), dict) else {}
    extra = "\n".join(format_entry_diag_lines(diag)) if diag else "- 진입근거: strategy 상세값 미전달"
    timing_line = format_entry_timing_line(pos.get("entry_timing_trace") or (diag.get("entry_timing_trace") if isinstance(diag, dict) else {})) if bool(load_control().get("notify_entry_timing_trace", True)) else ""
    if timing_line:
        extra = extra + "\n" + timing_line
    send_message(
        "🟢 paper OPEN\n"
        f"- 종목: {t}\n"
        f"- 진입가: {fmt_price(pos.get('entry_price'))}\n"
        f"- 등급: {pos.get('candidate_grade','S1')} / 점수 {fnum(pos.get('score'), default=0.0):.2f}\n"
        f"- 전략: {pos.get('strategy_label') or pos.get('strategy') or '-'}\n"
        f"- profile: {pos.get('entry_profile', '-')} / exit {pos.get('exit_profile', '-')}\n"
        f"{extra}\n"
        f"- 바로보기: {link}\n"
        f"- paper: {VERSION}"
    )


def notify_closed(row: Dict[str, Any]) -> None:
    t = normalize_ticker(row.get("ticker"))
    diag = row.get("entry_diagnostics") if isinstance(row.get("entry_diagnostics"), dict) else {}
    extra = "\n".join(format_entry_diag_lines(diag)) if diag else "- 진입근거: strategy 상세값 미전달"
    timing_line = format_entry_timing_line(row.get("entry_timing_trace") or (diag.get("entry_timing_trace") if isinstance(diag, dict) else {})) if bool(load_control().get("notify_entry_timing_trace", True)) else ""
    if timing_line:
        extra = extra + "\n" + timing_line
    send_message(
        f"{closed_title(row)}\n"
        f"- 종목: {t}\n"
        f"- 손익: {fnum(row.get('pnl_pct'), default=0.0):+.2f}%\n"
        f"- 이유: {row.get('exit_rule_label') or row.get('exit_reason')}\n"
        f"- 진입/청산: {fmt_price(row.get('entry_price'))} → {fmt_price(row.get('exit_price'))}\n"
        f"- 최고/최저: {fnum(row.get('peak_pct'), default=0.0):+.2f}% / {fnum(row.get('trough_pct'), default=0.0):+.2f}%\n"
        f"- 청산복기: 최고 {fnum(row.get('peak_pct'), default=0.0):+.2f}% → 최종 {fnum(row.get('pnl_pct'), default=0.0):+.2f}% / 놓친수익 {fnum(row.get('missed_profit_pct'), default=0.0):+.2f}% / {row.get('close_review_tag','관찰')}\n"
        f"{(_v494_fast_fail_cause_line(row) + chr(10)) if str(row.get('exit_reason') or row.get('exit_rule') or '') == 'fast_fail_stop' else ''}"
        f"- 보유: {row.get('age_min','-')}분\n"
        f"- 전략: {row.get('strategy_label') or row.get('strategy') or '-'}\n"
        f"- profile: {row.get('entry_profile', '-')} / exit {row.get('exit_profile', '-')}\n"
        f"{extra}\n"
        f"- paper: {VERSION}"
    )




def _decision_line(obj: Any, label: str) -> str:
    if not isinstance(obj, dict):
        return f"- {label}: -"
    t = obj.get("ticker") or "-"
    status = obj.get("status") or "-"
    reason = str(obj.get("reason") or "-")
    react = fnum(obj.get("price_reaction_pct"), default=0.0)
    buy = fnum(obj.get("buy_ratio"), default=-1.0)
    sustain = fnum(obj.get("buy_sustain_1m"), default=-1.0)
    spread = fnum(obj.get("spread_pct"), default=-1.0)
    nums = []
    nums.append(f"반응 {react:+.2f}%")
    if buy >= 0:
        nums.append(f"매수 {buy:.2f}")
    if sustain >= 0:
        nums.append(f"지속 {sustain:.2f}")
    if spread >= 0:
        nums.append(f"스프 {spread:.2f}%")
    return f"- {label}: {t} / {status} / {' · '.join(nums)} / {reason[:180]}"


def _summary_reason_text(obj: Any) -> str:
    if not isinstance(obj, dict):
        return "-"
    reason = str(obj.get("reason") or "").strip()
    if not reason:
        reasons = obj.get("block_reasons") or obj.get("missing_info") or []
        if isinstance(reasons, list) and reasons:
            reason = str(reasons[0]).strip()
    return reason[:160] if reason else "-"


def _summary_counter_add(counter: Counter, text: str, amount: int = 1) -> None:
    text = str(text or "").strip()
    if not text or text == "-":
        return
    # 너무 긴 종목별 수치가 TOP을 어지럽히지 않도록 앞부분만 묶는다.
    key = text.split("/")[0].strip()[:90]
    if key:
        counter[key] += max(1, int(amount))


def _summary_top(counter: Counter, limit: int = 5) -> str:
    if not isinstance(counter, Counter) or not counter:
        return "-"
    return " / ".join(f"{k} {v}" for k, v in counter.most_common(limit))


def _reset_s1_summary_bucket(now: Optional[float] = None) -> Dict[str, Any]:
    ts = fnum(now, default=now_ts())
    bucket = {
        "start_ts": ts,
        "cycles": 0,
        "s1_seen": 0,
        "selected_s1": 0,
        "paper_final_block": 0,  # legacy counter name
        "paper_entry_hold": 0,
        "micro_preopen_wait": 0,
        "opened": 0,
        "closed": 0,
        "latest_count_max": 0,
        "fresh_count_max": 0,
        "final_block_reasons": Counter(),
        "skip_reasons": Counter(),
        "last_paper_final_block": None,
        "last_skip": None,
        "last_open_try": None,
        "last_s1_seen": None,
    }
    _S1_DECISION_SUMMARY_BUCKET.clear()
    _S1_DECISION_SUMMARY_BUCKET.update(bucket)
    return _S1_DECISION_SUMMARY_BUCKET


def _ensure_s1_summary_bucket() -> Dict[str, Any]:
    if not isinstance(_S1_DECISION_SUMMARY_BUCKET, dict) or not _S1_DECISION_SUMMARY_BUCKET.get("start_ts"):
        return _reset_s1_summary_bucket(now_ts())
    if not isinstance(_S1_DECISION_SUMMARY_BUCKET.get("final_block_reasons"), Counter):
        _S1_DECISION_SUMMARY_BUCKET["final_block_reasons"] = Counter()
    if not isinstance(_S1_DECISION_SUMMARY_BUCKET.get("skip_reasons"), Counter):
        _S1_DECISION_SUMMARY_BUCKET["skip_reasons"] = Counter()
    return _S1_DECISION_SUMMARY_BUCKET


def notify_s1_decision_summary(pick_stats: Dict[str, Any], opened_count: int = 0, closed_count: int = 0, ctrl: Optional[Dict[str, Any]] = None) -> None:
    """S1/final block 흐름은 30분 단위로 묶어 보낸다.

    OPEN/CLOSED 즉시 알림은 유지한다. 후보/OPEN보류/무반응 재확인은 매 cycle마다
    보내지 않고, 1시간 동안 누적해서 가장 많은 보류 사유와 마지막 사례만 보여준다.
    조건/전략/장부는 건드리지 않는 알림 안정화 계층이다.
    """
    if not isinstance(pick_stats, dict):
        return
    ctrl = ctrl if isinstance(ctrl, dict) else {}
    if not bool(ctrl.get("notify_on_s1_decision_summary", True)):
        return

    now = now_ts()
    interval = fnum(
        ctrl.get("notify_s1_decision_summary_interval_sec", ctrl.get("notify_s1_decision_summary_min_interval_sec", 3600)),
        default=3600.0,
    )
    interval = max(3600.0, interval)  # v513: 후보요약은 최소 1시간. 조건/전략 판단은 유지.
    bucket = _ensure_s1_summary_bucket()

    s1_seen = int(fnum(pick_stats.get("s1_seen"), default=0.0))
    selected = int(fnum(pick_stats.get("selected_s1"), default=0.0))
    final_block = int(fnum(pick_stats.get("paper_final_block"), default=0.0))
    entry_hold = int(fnum(pick_stats.get("paper_entry_hold"), default=final_block))
    micro_wait = int(fnum(pick_stats.get("micro_preopen_wait"), default=0.0))

    bucket["cycles"] = int(bucket.get("cycles", 0)) + 1
    bucket["s1_seen"] = int(bucket.get("s1_seen", 0)) + s1_seen
    bucket["selected_s1"] = int(bucket.get("selected_s1", 0)) + selected
    bucket["paper_final_block"] = int(bucket.get("paper_final_block", 0)) + final_block
    bucket["paper_entry_hold"] = int(bucket.get("paper_entry_hold", 0)) + entry_hold
    bucket["micro_preopen_wait"] = int(bucket.get("micro_preopen_wait", 0)) + micro_wait
    bucket["opened"] = int(bucket.get("opened", 0)) + int(opened_count or 0)
    bucket["closed"] = int(bucket.get("closed", 0)) + int(closed_count or 0)
    bucket["latest_count_max"] = max(int(bucket.get("latest_count_max", 0)), int(fnum(pick_stats.get("latest_count"), default=0.0)))
    bucket["fresh_count_max"] = max(int(bucket.get("fresh_count_max", 0)), int(fnum(pick_stats.get("merged_fresh"), default=0.0)))

    last_block = pick_stats.get("last_paper_entry_hold") or pick_stats.get("last_paper_final_block")
    last_skip = pick_stats.get("last_skip")
    last_open = pick_stats.get("last_open_try")
    last_seen = pick_stats.get("last_s1_seen")

    if isinstance(last_block, dict):
        bucket["last_paper_final_block"] = last_block
        _summary_counter_add(bucket["final_block_reasons"], _summary_reason_text(last_block), amount=max(1, final_block))
    if isinstance(last_skip, dict):
        bucket["last_skip"] = last_skip
        _summary_counter_add(bucket["skip_reasons"], _summary_reason_text(last_skip), amount=1)
    if isinstance(last_open, dict):
        bucket["last_open_try"] = last_open
    if isinstance(last_seen, dict):
        bucket["last_s1_seen"] = last_seen

    elapsed = now - fnum(bucket.get("start_ts"), default=now)
    if elapsed < interval:
        return

    meaningful = (
        int(bucket.get("s1_seen", 0))
        + int(bucket.get("selected_s1", 0))
        + int(bucket.get("paper_entry_hold", bucket.get("paper_final_block", 0)))
        + int(bucket.get("opened", 0))
        + int(bucket.get("closed", 0))
    )
    if meaningful <= 0:
        _reset_s1_summary_bucket(now)
        return

    final_top = _summary_top(bucket.get("final_block_reasons"), limit=5)
    skip_top = _summary_top(bucket.get("skip_reasons"), limit=5)
    title = "🧭 paper S1 1시간 재확인/보류 요약"
    if "무반응" in final_top:
        title = "🧭 paper 1시간 무반응 재확인 보류 요약"

    minutes = max(1, int(round(elapsed / 60.0)))
    lines = [
        title,
        f"- 기간: 약 {minutes}분 / cycle {bucket.get('cycles', 0)}회",
        f"- S1감지 {bucket.get('s1_seen', 0)} / OPEN선택 {bucket.get('selected_s1', 0)} / OPEN보류 {bucket.get('paper_entry_hold', bucket.get('paper_final_block', 0))}",
        f"- OPEN {bucket.get('opened', 0)} / CLOSED {bucket.get('closed', 0)} / micro대기 {bucket.get('micro_preopen_wait', 0)}",
        f"- 후보 max latest {bucket.get('latest_count_max', 0)} / fresh {bucket.get('fresh_count_max', 0)}",
        f"- 보류 TOP: {final_top}",
        f"- 스킵 TOP: {skip_top}",
        _decision_line(bucket.get("last_paper_final_block"), "마지막 OPEN보류"),
        _decision_line(bucket.get("last_open_try"), "마지막 OPEN시도"),
        _decision_line(bucket.get("last_s1_seen"), "마지막 S1감지"),
        f"- paper: {VERSION}",
    ]
    send_message("\n".join(lines))
    _reset_s1_summary_bucket(now)


def _reset_hot_market_bucket(now: Optional[float] = None) -> Dict[str, Any]:
    ts = fnum(now, default=now_ts())
    bucket = {
        "start_ts": ts,
        "last_immediate_ts": 0.0,
        "cycles": 0,
        "hot_seen": 0,
        "best_by_ticker": {},
        "last_cache_age": None,
        "last_by_ticker": {},
    }
    _HOT_MARKET_NOTIFY_BUCKET.clear(); _HOT_MARKET_NOTIFY_BUCKET.update(bucket); return _HOT_MARKET_NOTIFY_BUCKET


def _ensure_hot_market_bucket() -> Dict[str, Any]:
    if not isinstance(_HOT_MARKET_NOTIFY_BUCKET, dict) or not _HOT_MARKET_NOTIFY_BUCKET.get("start_ts"):
        return _reset_hot_market_bucket(now_ts())
    if not isinstance(_HOT_MARKET_NOTIFY_BUCKET.get("best_by_ticker"), dict):
        _HOT_MARKET_NOTIFY_BUCKET["best_by_ticker"] = {}
    if not isinstance(_HOT_MARKET_NOTIFY_BUCKET.get("last_by_ticker"), dict):
        _HOT_MARKET_NOTIFY_BUCKET["last_by_ticker"] = {}
    return _HOT_MARKET_NOTIFY_BUCKET


def _load_hot_rank_rows(ctrl: Dict[str, Any]) -> Tuple[List[Dict[str, Any]], float, Dict[str, Any]]:
    obj = load_json(FILES.get("hot_rank", BASE_DIR / "clean_scanner_hot_rank_cache.json"), {}) or {}
    if not isinstance(obj, dict): return [], 999999.0, {}
    updated = fnum(obj.get("updated_ts"), default=0.0)
    age = now_ts() - updated if updated > 0 else 999999.0
    rows = obj.get("rows") if isinstance(obj.get("rows"), list) else []
    ttl = fnum(ctrl.get("notify_market_hot_cache_ttl_sec"), default=90.0)
    if age > max(10.0, ttl): return [], age, obj
    return [r for r in rows if isinstance(r, dict)], age, obj


def _hot_row_score(row: Dict[str, Any]) -> float:
    c1=fnum(row.get("scanner_change_1m_pct"),default=0.0); c3=fnum(row.get("scanner_change_3m_pct"),default=0.0)
    r1=fnum(row.get("scanner_hot_rank_1m"),default=9999.0); r3=fnum(row.get("scanner_hot_rank_3m"),default=9999.0)
    return max(0.0,c1)*4.0 + max(0.0,c3)*2.0 + max(0.0,12.0-min(r1,r3))


def _hot_candidate_stage_index() -> Dict[str, Dict[str, Any]]:
    """hot-rank 알림에 후보판정 단계만 붙인다. OPEN/조건 판단은 바꾸지 않는다."""
    idx: Dict[str, Dict[str, Any]] = {}
    try:
        for r in read_jsonl_tail(FILES.get("paper_latest", BASE_DIR / "paper_candidates_latest.jsonl"), 300):
            if not isinstance(r, dict):
                continue
            t = normalize_ticker(r.get("ticker") or r.get("market") or r.get("symbol"))
            if not t:
                continue
            idx[t] = r
    except Exception:
        pass
    return idx


def _candidate_stage_label_for_hot(ticker: str, idx: Optional[Dict[str, Dict[str, Any]]] = None) -> str:
    if not ticker or not isinstance(idx, dict):
        return "후보 -"
    r = idx.get(ticker)
    if not isinstance(r, dict):
        return "후보없음"
    st = str(r.get("candidate_grade") or r.get("s_stage") or r.get("stage") or r.get("grade") or "-").upper()
    if st not in {"S1", "S2", "S3", "X"}:
        st = "-"
    return f"후보 {st}"




def _v514_short_text(value: Any, limit: int = 38) -> str:
    if value is None:
        return ""
    if isinstance(value, (list, tuple)):
        parts = [str(x).strip() for x in value if str(x).strip()]
        txt = " / ".join(parts[:3])
    elif isinstance(value, dict):
        parts = []
        for k, v in value.items():
            if v in (None, "", [], {}):
                continue
            parts.append(f"{k}:{v}")
        txt = " / ".join(parts[:3])
    else:
        txt = str(value).strip()
    txt = re.sub(r"\s+", " ", txt)
    if len(txt) > limit:
        txt = txt[:limit-1] + "…"
    return txt

def _v514_first_text(row: Dict[str, Any], keys: Iterable[str], limit: int = 38) -> str:
    if not isinstance(row, dict):
        return ""
    for k in keys:
        if k in row and row.get(k) not in (None, "", [], {}):
            txt = _v514_short_text(row.get(k), limit=limit)
            if txt:
                return txt
    return ""

def _v514_candidate_stage_detail_for_hot(ticker: str, idx: Optional[Dict[str, Dict[str, Any]]] = None) -> Tuple[str, str, str, str]:
    """hot-rank 1시간 요약용. 후보단계/막힘/부족/paper상태를 canonical latest row에서만 읽는다."""
    if not ticker or not isinstance(idx, dict):
        return "후보 -", "", "", "paper -"
    r = idx.get(ticker)
    if not isinstance(r, dict):
        return "후보없음", "", "", "paper not_seen"
    st = str(r.get("candidate_grade") or r.get("s_stage") or r.get("stage") or r.get("grade") or "-").upper()
    if st not in {"S1", "S2", "S3", "X"}:
        st = "-"
    block = _v514_first_text(r, (
        "s1_block_reason", "final_block_reason", "block_reason", "main_block_reason",
        "reject_reason", "entry_block_reason", "reason", "candidate_reason",
        "막힘", "block_reasons", "reasons"
    ), limit=44)
    missing = _v514_first_text(r, (
        "missing_reason", "missing_info", "missing_tags", "lack_reason", "info_missing", "부족",
    ), limit=34)
    risk = _v514_first_text(r, (
        "risk_tags", "risk_reason", "structure_risk_tags", "spike_guard_reasons", "stale_reasons", "위험"
    ), limit=34)
    reason_parts = []
    if block: reason_parts.append(block)
    if risk: reason_parts.append("위험 " + risk)
    if missing: reason_parts.append("부족 " + missing)
    reason = " / ".join(reason_parts[:3])
    # paper 상태는 OPEN 판단이 아니라, paper가 볼 수 있는 후보인지 확인하기 위한 표시만 한다.
    if st == "S1":
        pstate = "paper open대상"
    elif st in {"S2", "S3"}:
        pstate = "paper not_s1"
    elif st == "X":
        pstate = "paper 제외"
    else:
        pstate = "paper not_seen"
    seen = _v514_first_text(r, ("paper_state", "paper_status", "handoff_status", "paper_trace_status"), limit=24)
    if seen:
        pstate = "paper " + seen
    return f"후보 {st}", reason, pstate, str(r.get("strategy_label") or r.get("strategy_key") or r.get("strategy") or "")

def _v514_time_label_from_row(row: Dict[str, Any]) -> str:
    ts = fnum(row.get("detected_ts"), row.get("first_seen_ts"), row.get("created_at"), row.get("updated_ts"), row.get("ts"), default=0.0)
    if ts <= 0:
        return "포착 -"
    try:
        return "포착 " + time.strftime("%H:%M:%S", time.localtime(ts))
    except Exception:
        return "포착 -"

def _format_hot_row(row: Dict[str, Any], stage_idx: Optional[Dict[str, Dict[str, Any]]] = None) -> str:
    t=normalize_ticker(row.get("ticker") or row.get("market") or row.get("symbol")) or "-"
    c1=fnum(row.get("scanner_change_1m_pct"),default=0.0); c3=fnum(row.get("scanner_change_3m_pct"),default=0.0)
    r1=row.get("scanner_hot_rank_1m") or "-"; r3=row.get("scanner_hot_rank_3m") or "-"
    price=row.get("current_price") or row.get("price") or row.get("trade_price")
    stage, reason, pstate, strat = _v514_candidate_stage_detail_for_hot(t, stage_idx)
    base = f"{t} {fmt_price(price)} / 1m {c1:+.2f}% #{r1} · 3m {c3:+.2f}% #{r3} / {stage}"
    extras = []
    tl = _v514_time_label_from_row(row)
    if tl != "포착 -":
        extras.append(tl)
    if strat:
        extras.append(strat)
    if reason:
        extras.append("이유 " + reason)
    if pstate:
        extras.append(pstate)
    if extras:
        return base + " / " + " / ".join(extras[:4])
    return base


def notify_market_hot_summary(ctrl: Optional[Dict[str, Any]] = None) -> None:
    # 시장 급등 관찰 알림. 매수/진입 조건은 바꾸지 않고, 실시간 알림만 강한 급등 중심으로 줄인다.
    ctrl = ctrl if isinstance(ctrl, dict) else load_control()
    if not bool(ctrl.get("notify_market_hot_alert", True)): return
    bucket=_ensure_hot_market_bucket(); rows, age, meta=_load_hot_rank_rows(ctrl); now=now_ts()
    interval=max(3600.0,fnum(ctrl.get("notify_market_hot_summary_interval_sec"),default=3600.0))
    immediate_interval=max(3600.0,fnum(ctrl.get("notify_market_hot_global_min_interval_sec"),default=3600.0))
    ticker_cooldown=max(3600.0,fnum(ctrl.get("notify_market_hot_ticker_cooldown_sec", ctrl.get("notify_market_hot_immediate_min_interval_sec")),default=3600.0))
    max_items=max(1,int(fnum(ctrl.get("notify_market_hot_max_items"),default=4)))
    top_n=max(1,int(fnum(ctrl.get("notify_market_hot_rank_top_n"),default=5)))
    weak_th1=fnum(ctrl.get("notify_market_hot_1m_pct"),default=0.80); weak_th3=fnum(ctrl.get("notify_market_hot_3m_pct"),default=1.50)
    strong_th1=fnum(ctrl.get("notify_market_hot_immediate_1m_pct"),default=1.50); strong_th3=fnum(ctrl.get("notify_market_hot_immediate_3m_pct"),default=2.50)
    stage_idx = _hot_candidate_stage_index()
    good=[]
    strong=[]
    for r in rows:
        c1=fnum(r.get("scanner_change_1m_pct"),default=0.0); c3=fnum(r.get("scanner_change_3m_pct"),default=0.0)
        r1=fnum(r.get("scanner_hot_rank_1m"),default=9999.0); r3=fnum(r.get("scanner_hot_rank_3m"),default=9999.0)
        is_good = c1>=weak_th1 or c3>=weak_th3 or (r1<=top_n and c1>=0.20) or (r3<=top_n and c3>=0.40)
        is_strong = c1>=strong_th1 or c3>=strong_th3 or (r1<=3 and c1>=weak_th1) or (r3<=3 and c3>=weak_th3)
        if is_good:
            rr=dict(r); rr["_hot_score"]=_hot_row_score(rr); good.append(rr)
            if is_strong:
                strong.append(rr)
    good.sort(key=lambda x:fnum(x.get("_hot_score"),default=0.0), reverse=True)
    strong.sort(key=lambda x:fnum(x.get("_hot_score"),default=0.0), reverse=True)
    bucket["cycles"]=int(bucket.get("cycles",0))+1
    bucket["hot_seen"]=int(bucket.get("hot_seen",0))+len(good)
    bucket["strong_seen"]=int(bucket.get("strong_seen",0))+len(strong)
    bucket["last_cache_age"]=round(age,1) if age<999999 else None
    best=bucket.get("best_by_ticker") if isinstance(bucket.get("best_by_ticker"),dict) else {}
    for r in good[:max_items*3]:
        t=normalize_ticker(r.get("ticker") or r.get("market") or r.get("symbol"))
        if t and (t not in best or _hot_row_score(r)>_hot_row_score(best[t])):
            best[t]=r
    bucket["best_by_ticker"]=best

    last_by_ticker=bucket.get("last_by_ticker") if isinstance(bucket.get("last_by_ticker"),dict) else {}
    fresh_strong=[]
    for r in strong:
        t=normalize_ticker(r.get("ticker") or r.get("market") or r.get("symbol"))
        if not t:
            continue
        if now-fnum(last_by_ticker.get(t),default=0.0) >= ticker_cooldown:
            fresh_strong.append(r)
    if bool(ctrl.get("notify_market_hot_immediate_enabled", False)) and fresh_strong and now-fnum(bucket.get("last_immediate_ts"),default=0.0)>=immediate_interval:
        lines=[
            "⚡ 강한 급등 감지 / hot-rank",
            f"- 즉시 기준 1m +{strong_th1:.2f}% 또는 3m +{strong_th3:.2f}% / 약한 급등은 1시간 요약",
            f"- 신규/쿨다운 통과 {min(len(fresh_strong), max_items)}개 · 같은 종목 {int(round(ticker_cooldown/60.0))}분 쿨다운 · 전체 {int(round(immediate_interval/60.0))}분 묶음",
            "- 매수 알림 아님 · S1/OPEN 여부는 별도 판단",
        ]
        for r in fresh_strong[:max_items]:
            lines.append("- "+_format_hot_row(r, stage_idx))
            t=normalize_ticker(r.get("ticker") or r.get("market") or r.get("symbol"))
            if t:
                last_by_ticker[t]=now
        bucket["last_by_ticker"]=last_by_ticker
        lines.append(f"- paper: {VERSION}")
        send_message("\n".join(lines))
        bucket["last_immediate_ts"]=now
    elapsed=now-fnum(bucket.get("start_ts"),default=now)
    if elapsed<interval:
        return
    best_rows=list(best.values()); best_rows.sort(key=lambda x:_hot_row_score(x), reverse=True)
    if not best_rows:
        _reset_hot_market_bucket(now); return
    minutes=max(1,int(round(elapsed/60.0)))
    lines=["🧭 시장 hot-rank 1시간 요약", f"- 기간 약 {minutes}분 / cycle {bucket.get('cycles',0)}회 / 감지누적 {bucket.get('hot_seen',0)} / 강한급등 {bucket.get('strong_seen',0)}", f"- cache age {bucket.get('last_cache_age','-')}s / row {meta.get('row_count','-') if isinstance(meta,dict) else '-'}", "- 매수 알림 아님 · 많이 오른 종목/포착시간/후보단계 연결 확인용"]
    for r in best_rows[:max_items]:
        lines.append("- "+_format_hot_row(r, stage_idx))
    lines.append(f"- paper: {VERSION}")
    send_message("\n".join(lines))
    _reset_hot_market_bucket(now)


def _score_stat(rows: List[Dict[str, Any]]) -> Dict[str, Any]:
    n = len(rows)
    wins = sum(1 for r in rows if fnum(r.get("pnl_pct"), r.get("profit_pct"), default=0.0) > 0)
    losses = max(0, n - wins)
    total = sum(fnum(r.get("pnl_pct"), r.get("profit_pct"), default=0.0) for r in rows)
    return {"n": n, "wins": wins, "losses": losses, "win_rate": (wins / n * 100.0 if n else 0.0), "total": total, "avg": (total / n if n else 0.0)}


def _score_bucket(row: Dict[str, Any]) -> str:
    stage = str(row.get("candidate_grade") or row.get("s_stage") or row.get("stage") or row.get("grade") or "S1").upper()
    if stage in {"S", "STRICT", "OPEN"}:
        return "S1"
    if stage not in {"S1", "S2", "S3", "X"}:
        return "S1"
    return stage


def _strategy_key(row: Dict[str, Any]) -> str:
    for k in ("strategy_primary", "strategy_bucket_primary", "strategy_key", "strategy", "strategy_name"):
        v = row.get(k)
        if v:
            return str(v)
    return "unknown"


# v434: 성과판 집계용 key는 score_main_version → closed_main_version만 우선한다.
# 후보/worker의 source_version/brain_version은 실제 실행 메인버전이 아니므로
# version_summary 집계 원천에서 제거한다. 필요 시 raw 필드로만 추적한다.
_MAIN_VERSION_FIELDS = (
    "score_main_version", "closed_main_version",
    "main_version", "deploy_version", "opened_main_version",
    "entry_main_version", "source_main_version", "main_bot_version", "main_file",
    "deploy_target", "target", "source_file", "restore_build", "main_build",
    "deploy_build", "source_build",
)
_RAW_VERSION_TRACE_FIELDS = ("source_version", "brain_version", "source_main_version_raw")


def _normalize_main_version_key(v: Any, field: str = "") -> str:
    """main/deploy version 표기를 v2.13.xxx 단일 key로 맞춘다.

    v432에서 단순 v2.13.xxx만 정규화해도 score가 0전으로 남았다.
    원인은 과거 CLOSED가 v390, v427_v390_main..., coinbot_main_v2_13_390.py
    같은 단축/빌드 표기를 갖고 있을 수 있기 때문이다.

    단, paper_bot_v0.132 같은 paper/worker 버전을 main 버전으로 오인하지 않도록
    vNNN 단축 표기는 field 이름이나 값에 main/deploy/수익형 단서가 있을 때만 허용한다.
    """
    if v is None:
        return ""
    s = str(v).strip()
    if not s:
        return ""
    m = re.search(r"(?:^|[^0-9])2[_.]13[_.](\d{1,4})(?:[^0-9]|$)", s)
    if m:
        return f"v2.13.{int(m.group(1))}"
    m = re.search(r"v2\.13\.(\d{1,4})", s)
    if m:
        return f"v2.13.{int(m.group(1))}"
    field_l = str(field or "").lower()
    value_l = s.lower()
    mainish = any(x in field_l for x in ("main", "deploy", "target", "brain")) or any(
        x in value_l for x in ("main", "deploy", "target", "수익형", "coinbot_main")
    )
    if mainish:
        hits = re.findall(r"(?:^|[^0-9])v(\d{3,4})(?:[^0-9]|$)", s)
        # v390/v391 같은 main shorthand만 허용한다. v0.132/paper version은 여기 걸리지 않는다.
        if hits:
            n = int(hits[-1])
            if 300 <= n <= 9999:
                return f"v2.13.{n}"
    return ""


def _iter_version_source_values(row: Dict[str, Any]) -> Iterable[Tuple[str, Any]]:
    for k in _MAIN_VERSION_FIELDS:
        if k in row:
            yield k, row.get(k)
    # 과거 CLOSED는 원본 후보(raw)나 entry_context 안에 main/deploy 표기가 남는 경우가 있다.
    # 장부를 다시 계산하지 않고, 이미 CLOSED row 안에 들어 있는 값만 살핀다.
    for parent_key in ("raw", "entry_context", "entry_diagnostics", "source_event", "meta", "metadata"):
        obj = row.get(parent_key)
        if isinstance(obj, dict):
            for k in _MAIN_VERSION_FIELDS:
                if k in obj:
                    yield f"{parent_key}.{k}", obj.get(k)
            nested = obj.get("entry_context")
            if isinstance(nested, dict):
                for k in _MAIN_VERSION_FIELDS:
                    if k in nested:
                        yield f"{parent_key}.entry_context.{k}", nested.get(k)


def _paper_version_num(v: Any) -> int:
    m = re.search(r"paper_bot_v0\.(\d+)", str(v or ""))
    return int(m.group(1)) if m else 0


def _version_num_from_key(key: str) -> int:
    m = re.search(r"v2\.13\.(\d+)", str(key or ""))
    return int(m.group(1)) if m else 0


def _is_stale_main_key(key: str, active: str, legacy: str, recent_paper: bool) -> bool:
    if not key or not active or not recent_paper:
        return False
    if legacy and key == legacy and key != active:
        return True
    # 현재 실행 메인보다 현저히 오래된 key는 후보 raw/구 DEPLOY_TARGET 오염으로 본다.
    # 장부 원본은 그대로 두고 성과 cache 집계에서만 보정한다.
    kn = _version_num_from_key(key)
    an = _version_num_from_key(active)
    return bool(kn and an and kn < an - 20)


def _main_version_key(row: Dict[str, Any]) -> str:
    active = active_main_version()
    legacy = _legacy_deploy_target_version()
    recent_paper = _paper_version_num(row.get("closed_paper_version") or row.get("opened_paper_version")) >= 128

    # 1순위: v434 이후 CLOSED가 명시적으로 찍는 성과판용 버전.
    # 단, 구 DEPLOY_TARGET/raw 오염 key는 score cache 집계에서만 active로 보정한다.
    candidate_keys: List[str] = []
    for field in ("score_main_version", "closed_main_version"):
        key = _normalize_main_version_key(row.get(field), field)
        if key:
            candidate_keys.append(key)
            if _is_stale_main_key(key, active, legacy, recent_paper):
                continue
            return key

    # 2순위: row 안에 남은 다른 main/deploy 계열 필드.
    for field, val in _iter_version_source_values(row):
        if field in {"score_main_version", "closed_main_version"}:
            continue
        key = _normalize_main_version_key(val, field)
        if not key:
            continue
        candidate_keys.append(key)
        if _is_stale_main_key(key, active, legacy, recent_paper):
            continue
        return key

    # 3순위: 최근 paper가 닫은 행이라도 명시 key가 없으면 active로 덮지 않는다.
    # 이유: paper-only 업그레이드 직후 active main을 무조건 쓰면 과거 CLOSED가 현재판으로 빨려 들어간다.
    # 실제 stale key 보정은 위 _is_stale_main_key()에서만 처리한다.
    if candidate_keys:
        return candidate_keys[0]
    return "unknown"





def _v463_as_list(v: Any) -> List[str]:
    if isinstance(v, list):
        return [str(x).strip() for x in v if str(x).strip()]
    if isinstance(v, tuple):
        return [str(x).strip() for x in v if str(x).strip()]
    if isinstance(v, dict):
        return [f"{k}:{val}" for k, val in list(v.items())[:6]]
    if isinstance(v, str) and v.strip():
        parts = [p.strip() for p in re.split(r"[/,|]", v) if p.strip()]
        return parts or [v.strip()]
    return []


def _v463_entry_source(row: Dict[str, Any]) -> List[Dict[str, Any]]:
    out: List[Dict[str, Any]] = []
    for key in ("entry_diagnostics", "entry_context", "raw"):
        obj = row.get(key)
        if isinstance(obj, dict):
            out.append(obj)
            for sub in ("entry_diagnostics", "entry_context", "structure", "orderflow", "micro", "feature"):
                vv = obj.get(sub)
                if isinstance(vv, dict):
                    out.append(vv)
    out.append(row)
    return out


def _v463_first(row: Dict[str, Any], keys: Iterable[str], default: Any = None) -> Any:
    for src in _v463_entry_source(row):
        for k in keys:
            if k in src and src.get(k) not in (None, "", [], {}):
                return src.get(k)
    return default


def _v463_entry_summary(row: Dict[str, Any]) -> Dict[str, Any]:
    tags: List[str] = []
    risks: List[str] = []
    for src in _v463_entry_source(row):
        for k in ("structure_tags", "structure_good_tags", "matched_strategies", "strategy_tags"):
            tags.extend(_v463_as_list(src.get(k)))
        for k in ("structure_risk_tags", "risk_tags", "entry_missing_info", "missing_info"):
            risks.extend(_v463_as_list(src.get(k)))
    seen: set[str] = set()
    tags = [x for x in tags if not (x in seen or seen.add(x))][:5]
    seen = set()
    risks = [x for x in risks if not (x in seen or seen.add(x))][:5]
    reaction = fnum(_v463_first(row, ("price_reaction_pct", "price_reaction", "reaction_pct")), default=0.0)
    buy = fnum(_v463_first(row, ("buy_ratio", "buy_trade_ratio", "micro_buy_ratio")), default=-1.0)
    sustain = fnum(_v463_first(row, ("buy_sustain_1m", "micro_buy_ratio_sustain_1m", "buy_ratio_1m")), default=-1.0)
    spread = fnum(_v463_first(row, ("spread_pct", "micro_spread_pct", "orderbook_spread_pct")), default=-1.0)
    metrics_parts = [f"반응 {reaction:+.2f}%"]
    if buy >= 0:
        metrics_parts.append(f"매수 {buy:.2f}")
    if sustain >= 0:
        metrics_parts.append(f"지속 {sustain:.2f}")
    if spread >= 0:
        metrics_parts.append(f"스프 {spread:.2f}%")
    return {
        "structure_tags": tags,
        "risk_tags": risks,
        "metrics": {"price_reaction_pct": reaction, "buy_ratio": buy, "buy_sustain_1m": sustain, "spread_pct": spread},
        "metrics_text": " · ".join(metrics_parts),
    }


def _recent_closed_summary(row: Dict[str, Any]) -> Dict[str, Any]:
    return {
        "ticker": normalize_ticker(row.get("ticker")),
        "pnl_pct": round(fnum(row.get("pnl_pct"), row.get("profit_pct"), default=0.0), 4),
        "peak_pct": round(fnum(row.get("peak_pct"), default=0.0), 4),
        "trough_pct": round(fnum(row.get("trough_pct"), default=0.0), 4),
        "exit_reason": row.get("exit_reason") or row.get("exit_rule") or "-",
        "exit_rule_label": row.get("exit_rule_label") or row.get("exit_reason") or "-",
        "age_min": row.get("age_min"),
        "hold_sec": row.get("hold_sec"),
        "closed_at": fnum(row.get("closed_at"), default=0.0),
        "closed_at_text": row.get("closed_at_text") or "",
        "opened_at_text": row.get("opened_at_text") or "",
        "close_review_tag": row.get("close_review_tag") or "-",
        "strategy": row.get("strategy_label") or row.get("strategy") or row.get("strategy_key") or "-",
        "version": _main_version_key(row),
        "score_main_version_raw": row.get("score_main_version") or "",
        "closed_main_version_raw": row.get("closed_main_version") or "",
        "source_main_version_raw": row.get("source_main_version_raw") or "",
        "entry_summary": _v463_entry_summary(row),
    }


def _build_recent_12h(rows: List[Dict[str, Any]], hours: float = 12.0) -> Dict[str, Any]:
    cutoff = now_ts() - hours * 3600.0
    recent = [r for r in rows if fnum(r.get("closed_at"), default=0.0) >= cutoff]
    by_version: Dict[str, List[Dict[str, Any]]] = {}
    by_reason = Counter()
    for r in recent:
        by_version.setdefault(_main_version_key(r), []).append(r)
        by_reason[str(r.get("exit_reason") or r.get("exit_rule") or "unknown")] += 1
    return {
        "schema": "paper_recent_12h_v467_score_key_strict",
        "window_hours": hours,
        "since_ts": cutoff,
        "since_text": iso_ts(cutoff),
        "updated_at": now_ts(),
        "updated_at_text": iso_ts(),
        "global": _score_stat(recent),
        "by_version": {k: _score_stat(v) for k, v in by_version.items()},
        "version_keys": sorted(by_version.keys()),
        "exit_reason_counts": dict(by_reason.most_common(8)),
        "recent_closed": [_recent_closed_summary(r) for r in recent[-10:]],
        "active_main_version": active_main_version(),
        "active_main_version_source": active_main_version_detail()[1],
        "legacy_deploy_target_version": _legacy_deploy_target_version(),
    }

def write_score_cache(status: Optional[Dict[str, Any]] = None) -> None:
    """현재 활성 CLOSED tail만 읽어 메인봇 cache 성과판을 만든다.

    전체 장부 재계산은 하지 않는다. 가드봇이 활성 CLOSED를 최근분으로 줄이는 정책과 맞춘다.
    """
    try:
        rows = read_jsonl_tail(FILES["closed"], 300)
        by_grade: Dict[str, List[Dict[str, Any]]] = {}
        by_strategy: Dict[str, List[Dict[str, Any]]] = {}
        by_version: Dict[str, List[Dict[str, Any]]] = {}
        by_profile: Dict[str, List[Dict[str, Any]]] = {}
        by_profile_exit: Dict[str, List[Dict[str, Any]]] = {}
        for r in rows:
            by_grade.setdefault(_score_bucket(r), []).append(r)
            by_strategy.setdefault(_strategy_key(r), []).append(r)
            by_version.setdefault(_main_version_key(r), []).append(r)
            prof = str(r.get("entry_profile") or "unknown")
            if prof in {"spike_fast_early", "spike_runner"}:
                prof = "spike"
            elif prof in {"spike_fast_watch", "normal_watch"}:
                prof = "watch"
            by_profile.setdefault(prof, []).append(r)
            ex = str(r.get("exit_reason") or r.get("exit_rule") or "-")
            by_profile_exit.setdefault(f"{prof}:{ex}", []).append(r)
        grade_stats = {k: _score_stat(v) for k, v in by_grade.items()}
        grade_stats["ALL"] = _score_stat(rows)
        strategy_stats = {k: _score_stat(v) for k, v in by_strategy.items()}
        version_summary = {k: _score_stat(v) for k, v in by_version.items()}
        entry_profile_stats = {k: _score_stat(v) for k, v in by_profile.items()}
        profile_exit_stats = {k: _score_stat(v) for k, v in by_profile_exit.items()}
        obj = {
            "schema": "paper_score_cache_v090_profile_stats",
            "version": VERSION,
            "paper_version": VERSION,
            "build": BUILD_LABEL,
            "score_scope": "active_closed_tail_cache_only",
            "updated_at": now_ts(),
            "updated_at_text": iso_ts(),
            "current_closed_count": len(rows),
            "closed_count": len(rows),
            "source": "paper_bot_active_closed_tail",
            "global_stats": _score_stat(rows),
            "grade_stats": grade_stats,
            "strategy_primary_stats": strategy_stats,
            "strategy_stats": strategy_stats,
            "entry_profile_stats": entry_profile_stats,
            "profile_exit_stats": profile_exit_stats,
            # v433 단일 본선: 메인 /version_score는 이 key만 읽는다.
            "version_summary": version_summary,
            "version_summary_schema": "v467_strict_score_main_version_key",
            "version_summary_keys": sorted(version_summary.keys()),
            "recent_12h": _build_recent_12h(rows, 12.0),
            "active_main_version": active_main_version(),
            "active_main_version_source": active_main_version_detail()[1],
            "legacy_deploy_target_version": _legacy_deploy_target_version(),
            # 아래 두 key는 full/구독자가 남아 있을 수 있어 같은 내용을 복제하지만,
            # /version_score 기본 명령은 version_summary만 읽는다.
            "version_stats": version_summary,
            "main_version_stats": version_summary,
            "status_open_count": (status or {}).get("open_count") if isinstance(status, dict) else None,
        }
        save_json(FILES["score"], obj)
    except Exception as exc:
        log_error("write_score_cache", exc)

def write_status(status: Dict[str, Any]) -> None:
    global _LAST_STATUS
    base = {
        "version": VERSION,
        "active_reader_version": VERSION,
        "build": BUILD_LABEL,
        "pid": os.getpid(),
        "self_pid": os.getpid(),
        "process_pid": os.getpid(),
        "process_alive": True,
        "updated_at": now_ts(),
        "updated_at_text": iso_ts(),
        "running": True,
        "stop_reason": "running",
    }
    base.update(status)
    _LAST_STATUS = base
    write_pid()
    save_json(FILES["status"], base)


def run_cycle() -> Dict[str, Any]:
    started = now_ts()
    ctrl = load_control()
    open_pos = load_open()
    opened_items: List[Dict[str, Any]] = []
    closed_items: List[Dict[str, Any]] = []
    picked_ids: set[str] = set()
    opened_ids: set[str] = set()
    pick_stats: Dict[str, Any] = {}
    latest_rows: List[Dict[str, Any]] = []
    if ctrl.get("running", True):
        picked, pick_stats, latest_rows = select_candidates(ctrl, open_pos)
        for pid, ev in picked:
            picked_ids.add(pid)
            if pid in open_pos:
                continue
            try:
                pos = open_position(pid, ev)
                open_pos[pid] = pos
                opened_items.append(pos)
                opened_ids.add(pid)
            except Exception as exc:
                log_error("open_position", exc)
        for pid, pos in list(open_pos.items()):
            try:
                updated, closed = update_position(pos, ctrl)
                if closed:
                    closed_items.append(closed)
                    open_pos.pop(pid, None)
                    append_jsonl(FILES["closed"], closed)
                    _LAST_CLOSED_COUNT_CACHE.update({"ts": 0.0, "count": 0})
                else:
                    open_pos[pid] = updated
            except Exception as exc:
                log_error("update_position", exc)
        save_open(open_pos)
    else:
        _, pick_stats, latest_rows = select_candidates(ctrl, open_pos)
        pick_stats["paused"] = 1
    trace_obj = build_trace(latest_rows, ctrl, open_pos, picked_ids, opened_ids)
    write_handoff_status(int(pick_stats.get("latest_count", 0)), int(pick_stats.get("merged_fresh", 0)), pick_stats)
    status = {
        "running": bool(ctrl.get("running", True)),
        "loop_seconds": ctrl.get("loop_seconds"),
        "opened_this_cycle": len(opened_items),
        "closed_this_cycle": len(closed_items),
        "open_total": len(open_pos),
        "open_count": len(open_pos),
        "open_strict": len(open_pos),
        "closed_total": line_count_cached(FILES["closed"], ttl=0 if closed_items else 60.0),
        "pick_stats": pick_stats,
        "trace_rows": len(trace_obj.get("rows") or []),
        "elapsed_sec": round(now_ts() - started, 3),
        "engine": "light_runner",
        "legacy_loop": False,
    }
    if ctrl.get("write_score_cache", True):
        write_score_cache(status)
    write_status(status)
    # v431: 알림은 장부/status/score cache 갱신 뒤에 보낸다.
    # 사용자가 CLOSED 알림을 보는 시점에는 전적 반영 경로가 먼저 끝나 있어야 한다.
    for pos in opened_items:
        if ctrl.get("notify_on_strict_open", True):
            notify_opened(pos)
    for row in closed_items:
        if ctrl.get("notify_on_strict_close", True):
            notify_closed(row)
    notify_s1_decision_summary(pick_stats, opened_count=len(opened_items), closed_count=len(closed_items), ctrl=ctrl)
    notify_market_hot_summary(ctrl)
    last_block = pick_stats.get("last_paper_entry_hold") or pick_stats.get("last_paper_final_block") if isinstance(pick_stats, dict) else None
    last_open_try = pick_stats.get("last_open_try") if isinstance(pick_stats, dict) else None
    def _brief_log(obj: Any) -> str:
        if not isinstance(obj, dict):
            return "-"
        return f"{obj.get('ticker','-')}/{obj.get('status','-')}/{str(obj.get('reason','-'))[:90]}"
    log(f"cycle opened={len(opened_items)} closed={len(closed_items)} open={len(open_pos)} elapsed={status['elapsed_sec']}s trace={status['trace_rows']} s1_seen={pick_stats.get('s1_seen',0) if isinstance(pick_stats, dict) else 0} selected={pick_stats.get('selected_s1',0) if isinstance(pick_stats, dict) else 0} entry_hold={pick_stats.get('paper_entry_hold', pick_stats.get('paper_final_block',0)) if isinstance(pick_stats, dict) else 0} last_open={_brief_log(last_open_try)} last_hold={_brief_log(last_block)}")
    return status



def _format_last_pick_line(key: str, pick: Dict[str, Any]) -> str:
    obj = pick.get(key) if isinstance(pick, dict) else None
    if not isinstance(obj, dict):
        label = {
            "last_s1_seen": "마지막 S1감지",
            "last_open_try": "마지막 OPEN시도",
            "last_paper_final_block": "마지막 OPEN보류",
            "last_skip": "마지막 스킵",
        }.get(key, key)
        return f"- {label}: -"
    label = {
        "last_s1_seen": "마지막 S1감지",
        "last_open_try": "마지막 OPEN시도",
        "last_paper_final_block": "마지막 OPEN보류",
        "last_skip": "마지막 스킵",
    }.get(key, key)
    t = obj.get("ticker") or "-"
    status = obj.get("status") or "-"
    reason = obj.get("reason") or "-"
    return f"- {label}: {t} / {status} / {reason}"


def pstatus_text() -> str:
    st = dict(_LAST_STATUS) if _LAST_STATUS else load_json(FILES["status"], {}) or {}
    op = load_open()
    pick = st.get("pick_stats") if isinstance(st.get("pick_stats"), dict) else {}
    return "\n".join([
        f"🧪 paper 상태 /pstatus ({VERSION})",
        f"- running: {st.get('running', '-')} / open {len(op)} / status age {max(0.0, now_ts()-fnum(st.get('updated_at'), default=now_ts())):.1f}s",
        f"- 이번 cycle: OPEN {st.get('opened_this_cycle',0)} / CLOSED {st.get('closed_this_cycle',0)} / elapsed {st.get('elapsed_sec','-')}s",
        f"- 후보: latest {pick.get('latest_count','-')} / fresh {pick.get('merged_fresh','-')} / S1감지 {pick.get('s1_seen',0)} / S1선택 {pick.get('selected_s1',0)} / OPEN보류 {pick.get('paper_entry_hold', pick.get('paper_final_block',0))} / micro대기 {pick.get('micro_preopen_wait',0)}",
        f"- 시장hot: 알림 {'ON' if load_control().get('notify_market_hot_alert', True) else 'OFF'} / cache age {max(0.0, now_ts()-fnum((load_json(FILES.get('hot_rank', BASE_DIR/'clean_scanner_hot_rank_cache.json'), {}) or {}).get('updated_ts'), default=now_ts())):.1f}s",
        _format_last_pick_line("last_s1_seen", pick),
        _format_last_pick_line("last_open_try", pick),
        _format_last_pick_line("last_paper_final_block", pick),
        _format_last_pick_line("last_skip", pick),
        "- 엔진: light_runner / legacy loop 사용 안 함",
    ])


def popen_text() -> str:
    op = load_open()
    lines = [f"📂 paper OPEN /popen ({VERSION})", f"- OPEN {len(op)}개"]
    for p in list(op.values())[:20]:
        if not isinstance(p, dict):
            continue
        diag = p.get("entry_diagnostics") if isinstance(p.get("entry_diagnostics"), dict) else {}
        rs = diag.get("entry_reasons") if isinstance(diag.get("entry_reasons"), list) else []
        lines.append(f"- {normalize_ticker(p.get('ticker'))} / {fnum(p.get('last_pnl_pct'), default=0):+.2f}% / 진입 {fmt_price(p.get('entry_price'))} / 최고 {fnum(p.get('peak_pct'), default=0):+.2f}% / {p.get('strategy_label') or p.get('strategy') or '-'}")
        if rs:
            lines.append("  · 근거: " + " / ".join(str(x) for x in rs[:3]))
    return "\n".join(lines)


def perror_text() -> str:
    lines = tail_lines(FILES["error"], 40)
    recent = "\n".join(lines[-40:])[-3500:]
    return "🧯 paper 오류 /perror\n\n" + (recent if recent else "✅ 오류로그 없음")


def plog_text() -> str:
    return "🧾 paper 로그 /plog\n\n" + ("\n".join(tail_lines(FILES["log"], 50))[-3500:] or "로그 없음")




def hot_summary_text() -> str:
    ctrl = load_control()
    rows, age, meta = _load_hot_rank_rows(ctrl)
    stage_idx = _hot_candidate_stage_index()
    max_items = max(5, int(fnum(ctrl.get("notify_market_hot_max_items"), default=4)))
    top_n = max(5, int(fnum(ctrl.get("notify_market_hot_rank_top_n"), default=5)))
    weak_th1=fnum(ctrl.get("notify_market_hot_1m_pct"),default=0.80); weak_th3=fnum(ctrl.get("notify_market_hot_3m_pct"),default=1.50)
    good=[]
    for r in rows:
        c1=fnum(r.get("scanner_change_1m_pct"),default=0.0); c3=fnum(r.get("scanner_change_3m_pct"),default=0.0)
        r1=fnum(r.get("scanner_hot_rank_1m"),default=9999.0); r3=fnum(r.get("scanner_hot_rank_3m"),default=9999.0)
        if c1>=weak_th1 or c3>=weak_th3 or (r1<=top_n and c1>=0.20) or (r3<=top_n and c3>=0.40):
            rr=dict(r); rr["_hot_score"]=_hot_row_score(rr); good.append(rr)
    good.sort(key=lambda x:fnum(x.get("_hot_score"),default=0.0), reverse=True)
    lines=["🧭 시장 hot-rank 현재 요약 /hot_summary", f"- cache age {age:.1f}s / row {meta.get('row_count','-') if isinstance(meta,dict) else '-'}", "- 매수 알림 아님 · 많이 오른 종목/포착시간/후보단계/못 올라온 이유 확인용"]
    if not good:
        lines.append("- 표시할 급등 후보 없음")
    for r in good[:max_items]:
        lines.append("- "+_format_hot_row(r, stage_idx))
    lines.append(f"- paper: {VERSION}")
    return "\n".join(lines)

def candidate_summary_text() -> str:
    rows = read_jsonl_tail(FILES.get("paper_latest", BASE_DIR / "paper_candidates_latest.jsonl"), 300)
    fresh = [r for r in rows if isinstance(r, dict) and candidate_is_fresh(r, load_control())]
    cnt=Counter()
    reasons=Counter()
    for r in fresh:
        st=str(r.get("candidate_grade") or r.get("s_stage") or r.get("stage") or r.get("grade") or "-").upper()
        if st not in {"S1","S2","S3","X"}: st="-"
        cnt[st]+=1
        reason = _v514_first_text(r, ("s1_block_reason","final_block_reason","block_reason","reason","risk_tags","stale_reasons","missing_reason","missing_info"), limit=40)
        if reason:
            reasons[reason]+=1
    lines=["🧭 후보요약 현재 보기 /candidate_summary", f"- latest {len(rows)} / fresh {len(fresh)} / S1 {cnt.get('S1',0)} / S2 {cnt.get('S2',0)} / S3 {cnt.get('S3',0)} / 제외 {cnt.get('X',0)}"]
    if reasons:
        top = " / ".join(f"{k} {v}" for k,v in reasons.most_common(5))
        lines.append("- 못 올라온 이유 TOP: "+top)
    show=sorted(fresh, key=lambda r:fnum(r.get("score"), r.get("candidate_score"), default=0.0), reverse=True)[:5]
    if show:
        lines.append("[상위 후보]")
    for r in show:
        t=normalize_ticker(r.get("ticker") or r.get("market") or r.get("symbol")) or "-"
        st=str(r.get("candidate_grade") or r.get("s_stage") or r.get("stage") or r.get("grade") or "-").upper()
        strat=str(r.get("strategy_label") or r.get("strategy_key") or r.get("strategy") or "-")
        reason=_v514_first_text(r, ("s1_block_reason","final_block_reason","block_reason","reason","risk_tags","stale_reasons","missing_reason","missing_info"), limit=46) or "-"
        lines.append(f"- {t} · {st} · {strat} · 이유 {reason}")
    return "\n".join(lines)

def paper_hourly_text() -> str:
    return "\n\n".join([pstatus_text(), hot_summary_text(), candidate_summary_text()])

def handle_command(cmd: str) -> str:
    c = cmd.strip().split()[0].lower()
    if c in {"/pstatus", "/status"}:
        return pstatus_text()
    if c in {"/popen", "/open"}:
        return popen_text()
    if c in {"/perror", "/error"}:
        return perror_text()
    if c in {"/plog", "/log"}:
        return plog_text()
    if c in {"/pbatch", "/batch"}:
        return "\n\n".join([pstatus_text(), popen_text(), perror_text()])
    if c in {"/hot_summary", "/hot", "/phot"}:
        return hot_summary_text()
    if c in {"/candidate_summary", "/candidate", "/pcandidate"}:
        return candidate_summary_text()
    if c in {"/paper_hourly", "/hourly", "/phourly"}:
        return paper_hourly_text()
    if c in {"/pversion", "/version"}:
        return f"{VERSION} / {BUILD_LABEL}"
    if c in {"/ponce"}:
        st = run_cycle()
        return f"✅ run once: opened {st.get('opened_this_cycle')} closed {st.get('closed_this_cycle')} elapsed {st.get('elapsed_sec')}s"
    return "명령: /pstatus /popen /hot_summary /candidate_summary /paper_hourly /perror /plog /pbatch /pversion /ponce"


def poll_telegram_once() -> None:
    global _TG_OFFSET
    if not TOKEN or not ALLOWED_CHAT_ID:
        return
    try:
        params = urllib.parse.urlencode({"timeout": 0, "offset": _TG_OFFSET + 1})
        req = urllib.request.Request(f"https://api.telegram.org/bot{TOKEN}/getUpdates?{params}")
        with urllib.request.urlopen(req, timeout=3) as resp:
            data = json.loads(resp.read().decode("utf-8", errors="ignore"))
        for upd in data.get("result", []) if isinstance(data, dict) else []:
            _TG_OFFSET = max(_TG_OFFSET, int(upd.get("update_id") or 0))
            msg = upd.get("message") or upd.get("edited_message") or {}
            chat = msg.get("chat") or {}
            chat_id = str(chat.get("id") or "")
            text = str(msg.get("text") or "")
            if not text.startswith("/"):
                continue
            if ALLOWED_CHAT_ID and chat_id != str(ALLOWED_CHAT_ID):
                continue
            ans = handle_command(text)
            old_notify = globals().get("NOTIFY_CHAT_ID")
            try:
                globals()["NOTIFY_CHAT_ID"] = chat_id
                send_message(ans)
            finally:
                globals()["NOTIFY_CHAT_ID"] = old_notify
    except Exception as exc:
        log_error("poll_telegram_once", exc)


def signal_handler(signum: int, _frame: Any) -> None:
    global _STOP, _STOP_REASON
    _STOP = True
    _STOP_REASON = f"signal_{signum}"
    try:
        st = dict(_LAST_STATUS) if _LAST_STATUS else {}
        st.update({
            "version": VERSION,
            "running": False,
            "process_alive": False,
            "stop_reason": _STOP_REASON,
            "updated_at": now_ts(),
            "updated_at_text": iso_ts(),
            "open_count": len(load_open()),
        })
        save_json(FILES["status"], st)
        log(f"stop requested: {_STOP_REASON}")
    except Exception:
        pass


def main() -> None:
    signal.signal(signal.SIGTERM, signal_handler)
    signal.signal(signal.SIGINT, signal_handler)
    startup_status = {
        "running": True,
        "startup_status": True,
        "open_count": len(load_open()),
        "open_total": len(load_open()),
        "closed_total": line_count_cached(FILES["closed"], ttl=0),
        "engine": "light_runner",
        "legacy_loop": False,
    }
    write_score_cache(startup_status)
    write_status(startup_status)
    log(f"{VERSION} started pid={os.getpid()} build={BUILD_LABEL} token={'yes' if TOKEN else 'no'} chat={'yes' if ALLOWED_CHAT_ID else 'no'}")
    last_cycle = 0.0
    last_poll = 0.0
    while not _STOP:
        try:
            ctrl = load_control()
            loop_sec = max(2.0, fnum(ctrl.get("loop_seconds"), default=8.0))
            if now_ts() - last_cycle >= loop_sec:
                run_cycle()
                last_cycle = now_ts()
            elif now_ts() - fnum(_LAST_STATUS.get("updated_at"), default=0.0) >= 10:
                hb = dict(_LAST_STATUS)
                hb.update({"heartbeat": True})
                write_status(hb)
            if now_ts() - last_poll >= 3.0:
                poll_telegram_once()
                last_poll = now_ts()
        except Exception as exc:
            log_error("main_loop", exc)
            write_status({"running": True, "last_error": f"{type(exc).__name__}: {exc}", "engine": "light_runner"})
        time.sleep(0.5)
    log(f"{VERSION} stopped reason={_STOP_REASON}")


# =============================================================================
# paper_bot v0.157 / v500: OPEN exit_plan 봉인 + 전략별 표시
# - 청산조건 숫자를 바꾸지 않고, 현재 control 기준을 entry_price 기준 가격표로 저장/알림한다.
# - 급등 진행형/눌림 재가속도 같은 paper 장부를 쓰고 strategy_key로만 분리한다.
# =============================================================================
BUILD_LABEL = "v503_exit_plan_context_spike_guard_2026-05-28"


def _v500_price_by_pct(entry: float, pct: float) -> float:
    try:
        return float(entry) * (1.0 + float(pct) / 100.0)
    except Exception:
        return 0.0


def _v500_build_exit_plan(pos: Dict[str, Any], ctrl: Optional[Dict[str, Any]] = None) -> Dict[str, Any]:
    ctrl = ctrl if isinstance(ctrl, dict) else load_control()
    entry = fnum(pos.get('entry_price'), default=0.0)
    tp = fnum(ctrl.get('take_profit_pct'), default=1.20)
    strong_tp = max(tp, fnum(ctrl.get('protect_big_trigger_pct'), default=1.40))
    stop = fnum(ctrl.get('stop_loss_pct'), default=-0.55)
    protect_tr = fnum(ctrl.get('protect_trigger_pct'), default=0.70)
    protect_floor = fnum(ctrl.get('protect_floor_pct'), default=0.35)
    fast_min = fnum(ctrl.get('fast_fail_after_min'), default=2.5)
    fast_peak = fnum(ctrl.get('fast_fail_peak_under_pct'), default=0.20)
    fast_loss = fnum(ctrl.get('fast_fail_loss_pct'), default=-0.35)
    time_exit = fnum(ctrl.get('time_exit_minutes'), default=15.0)
    strat = str(pos.get('strategy_key') or pos.get('strategy') or '')
    # 급등 진행형은 기존 청산조건을 바꾸지 않는다. 다만 plan 설명에서 빠른 증명 필요를 표시한다.
    style = '급등 진행형: 초반 증명 필수' if 'spike_momentum_ride' in strat else ('급등 눌림재가속: 재가속 유지 확인' if 'spike_pullback_reaccel' in strat else '기존 paper 청산 기준')
    return {
        'schema': 'paper_exit_plan_v500', 'paper_version': VERSION, 'created_at': now_ts(), 'created_at_text': iso_ts(),
        'strategy_key': strat, 'strategy_label': pos.get('strategy_label') or pos.get('strategy') or '-', 'plan_style': style,
        'entry_price': entry,
        'take_profit_pct': tp, 'take_profit_price': _v500_price_by_pct(entry, tp),
        'strong_target_pct': strong_tp, 'strong_target_price': _v500_price_by_pct(entry, strong_tp),
        'stop_loss_pct': stop, 'stop_loss_price': _v500_price_by_pct(entry, stop),
        'protect_trigger_pct': protect_tr, 'protect_trigger_price': _v500_price_by_pct(entry, protect_tr),
        'protect_floor_pct': protect_floor, 'protect_floor_price': _v500_price_by_pct(entry, protect_floor),
        'fast_fail_after_min': fast_min, 'fast_fail_peak_under_pct': fast_peak, 'fast_fail_loss_pct': fast_loss,
        'time_exit_minutes': time_exit,
        'fee_pct_roundtrip': fnum(ctrl.get('fee_pct_roundtrip'), default=0.10),
        'note': '청산조건 변경 아님. OPEN 시점에 기존 기준을 가격표로 봉인한 복기용 계획.',
    }


def _v500_exit_plan_open_lines(plan: Any, prefix: str='- ') -> List[str]:
    if not isinstance(plan, dict) or not plan:
        return [prefix + '진입계획: exit_plan 없음']
    return [
        prefix + '진입계획: ' + str(plan.get('plan_style') or '-'),
        prefix + f"목표가: 1차 {fmt_price(plan.get('take_profit_price'))}({fnum(plan.get('take_profit_pct'), default=0.0):+.2f}%) / 강한흐름 {fmt_price(plan.get('strong_target_price'))}({fnum(plan.get('strong_target_pct'), default=0.0):+.2f}%)",
        prefix + f"손절가: {fmt_price(plan.get('stop_loss_price'))}({fnum(plan.get('stop_loss_pct'), default=0.0):+.2f}%)",
        prefix + f"보호익절: 발동 {fmt_price(plan.get('protect_trigger_price'))}({fnum(plan.get('protect_trigger_pct'), default=0.0):+.2f}%) → 방어 {fmt_price(plan.get('protect_floor_price'))}({fnum(plan.get('protect_floor_pct'), default=0.0):+.2f}%)",
        prefix + f"빠른실패: {fnum(plan.get('fast_fail_after_min'), default=0.0):.1f}분 뒤 최고<{fnum(plan.get('fast_fail_peak_under_pct'), default=0.0):+.2f}% & 현재≤{fnum(plan.get('fast_fail_loss_pct'), default=0.0):+.2f}%",
        prefix + f"시간청산: {fnum(plan.get('time_exit_minutes'), default=0.0):.0f}분 / 수수료왕복 {fnum(plan.get('fee_pct_roundtrip'), default=0.0):.2f}% 반영",
    ]


def _v500_exit_plan_result_lines(row: Dict[str, Any], prefix: str='- ') -> List[str]:
    plan = row.get('exit_plan') if isinstance(row.get('exit_plan'), dict) else {}
    if not plan:
        return [prefix + '계획대비: exit_plan 없음']
    peak = fnum(row.get('peak_pct'), default=0.0); pnl = fnum(row.get('pnl_pct'), default=0.0)
    tp = fnum(plan.get('take_profit_pct'), default=0.0); ptr = fnum(plan.get('protect_trigger_pct'), default=0.0)
    stop = fnum(plan.get('stop_loss_pct'), default=0.0)
    res = []
    res.append(prefix + f"계획대비: 목표 {'도달' if peak >= tp else '미도달'} / 보호익절 {'발동권' if peak >= ptr else '미발동'} / 손절선 {'도달' if pnl <= stop else '전 종료'}")
    res.append(prefix + f"계획가격: 목표 {fmt_price(plan.get('take_profit_price'))} / 손절 {fmt_price(plan.get('stop_loss_price'))} / 보호 {fmt_price(plan.get('protect_trigger_price'))}→{fmt_price(plan.get('protect_floor_price'))}")
    return res


_v500_prev_open_position = open_position

def open_position(pos_id: str, ev: Dict[str, Any]) -> Dict[str, Any]:  # type: ignore[override]
    pos = _v500_prev_open_position(pos_id, ev)
    try:
        plan = _v500_build_exit_plan(pos, load_control())
        pos['exit_plan'] = plan
        pos['exit_plan_schema'] = plan.get('schema')
        # strategy_key가 비어 있는 구 row도 알림/성과 구분 가능하게 보강한다.
        if not pos.get('strategy_key'):
            pos['strategy_key'] = pos.get('strategy') or (ev.get('strategy_key') if isinstance(ev, dict) else '') or 'unknown'
        if not pos.get('strategy_label'):
            pos['strategy_label'] = ev.get('strategy_label') if isinstance(ev, dict) else pos.get('strategy_key')
    except Exception as exc:
        log_error('v500_exit_plan_open_position', exc)
    return pos


def notify_opened(pos: Dict[str, Any]) -> None:  # type: ignore[override]
    t = normalize_ticker(pos.get('ticker'))
    link = f"https://www.bithumb.com/trade/order/{t}_KRW" if t else ""
    diag = pos.get('entry_diagnostics') if isinstance(pos.get('entry_diagnostics'), dict) else {}
    extra = "\n".join(format_entry_diag_lines(diag)) if diag else "- 진입근거: strategy 상세값 미전달"
    timing_line = format_entry_timing_line(pos.get('entry_timing_trace') or (diag.get('entry_timing_trace') if isinstance(diag, dict) else {})) if bool(load_control().get('notify_entry_timing_trace', True)) else ""
    if timing_line:
        extra = extra + "\n" + timing_line
    plan_lines = "\n".join(_v500_exit_plan_open_lines(pos.get('exit_plan')))
    send_message(
        "🟢 paper OPEN\n"
        f"- 종목: {t}\n"
        f"- 진입가: {fmt_price(pos.get('entry_price'))}\n"
        f"- 등급: {pos.get('candidate_grade','S1')} / 점수 {fnum(pos.get('score'), default=0.0):.2f}\n"
        f"- 전략: {pos.get('strategy_label') or pos.get('strategy_key') or pos.get('strategy') or '-'}\n"
        f"{plan_lines}\n"
        f"{extra}\n"
        f"- 바로보기: {link}\n"
        f"- paper: {VERSION}"
    )


def notify_closed(row: Dict[str, Any]) -> None:  # type: ignore[override]
    t = normalize_ticker(row.get('ticker'))
    diag = row.get('entry_diagnostics') if isinstance(row.get('entry_diagnostics'), dict) else {}
    extra = "\n".join(format_entry_diag_lines(diag)) if diag else "- 진입근거: strategy 상세값 미전달"
    timing_line = format_entry_timing_line(row.get('entry_timing_trace') or (diag.get('entry_timing_trace') if isinstance(diag, dict) else {})) if bool(load_control().get('notify_entry_timing_trace', True)) else ""
    if timing_line:
        extra = extra + "\n" + timing_line
    result_lines = "\n".join(_v500_exit_plan_result_lines(row))
    send_message(
        f"{closed_title(row)}\n"
        f"- 종목: {t}\n"
        f"- 손익: {fnum(row.get('pnl_pct'), default=0.0):+.2f}%\n"
        f"- 이유: {row.get('exit_rule_label') or row.get('exit_reason')}\n"
        f"- 진입/청산: {fmt_price(row.get('entry_price'))} → {fmt_price(row.get('exit_price'))}\n"
        f"- 최고/최저: {fnum(row.get('peak_pct'), default=0.0):+.2f}% / {fnum(row.get('trough_pct'), default=0.0):+.2f}%\n"
        f"- 청산복기: 최고 {fnum(row.get('peak_pct'), default=0.0):+.2f}% → 최종 {fnum(row.get('pnl_pct'), default=0.0):+.2f}% / 놓친수익 {fnum(row.get('missed_profit_pct'), default=0.0):+.2f}% / {row.get('close_review_tag','관찰')}\n"
        f"{result_lines}\n"
        f"{(_v494_fast_fail_cause_line(row) + chr(10)) if str(row.get('exit_reason') or row.get('exit_rule') or '') == 'fast_fail_stop' else ''}"
        f"- 보유: {row.get('age_min','-')}분\n"
        f"- 전략: {row.get('strategy_label') or row.get('strategy_key') or row.get('strategy') or '-'}\n"
        f"{extra}\n"
        f"- paper: {VERSION}"
    )



# =============================================================================
# paper_bot v0.158 / v503: OPEN→CLOSED context 봉인 보강
# - 청산조건/장부 삭제 없음.
# - strategy_key, structure/risk tags, spike late-entry guard, timing trace를 OPEN row에 고정해
#   CLOSED/version_score에서 구조 '-' 또는 위험 '-'로 빠지는 문제를 줄인다.
# =============================================================================
BUILD_LABEL = "v503_exit_plan_context_spike_guard_2026-05-28"


def _v503_list_any(v: Any) -> List[str]:
    if isinstance(v, list):
        return [str(x).strip() for x in v if str(x).strip()]
    if isinstance(v, tuple):
        return [str(x).strip() for x in v if str(x).strip()]
    if isinstance(v, dict):
        return [f"{k}:{val}" for k, val in list(v.items())[:8]]
    if isinstance(v, str) and v.strip():
        return [x.strip() for x in re.split(r"[/,|]", v) if x.strip()] or [v.strip()]
    return []


def _v503_sources(ev: Dict[str, Any], pos: Optional[Dict[str, Any]] = None) -> List[Dict[str, Any]]:
    out: List[Dict[str, Any]] = []
    for obj in (ev, pos, ev.get('entry_context') if isinstance(ev, dict) else None, ev.get('strategy_context') if isinstance(ev, dict) else None, ev.get('canonical_entry_decision') if isinstance(ev, dict) else None, ev.get('metrics') if isinstance(ev, dict) else None, ev.get('raw') if isinstance(ev, dict) else None):
        if isinstance(obj, dict):
            out.append(obj)
            for sub in ('entry_context','strategy_context','metrics','structure','feature','orderflow','micro','canonical_entry_decision','spike_late_entry_guard','late_entry_guard'):
                vv = obj.get(sub)
                if isinstance(vv, dict):
                    out.append(vv)
    return out


def _v503_first_from_sources(sources: List[Dict[str, Any]], keys: Iterable[str], default: Any = None) -> Any:
    for src in sources:
        for k in keys:
            if k in src and src.get(k) not in (None, '', [], {}):
                return src.get(k)
    return default


def _v503_collect_context(ev: Dict[str, Any], pos: Dict[str, Any]) -> Dict[str, Any]:
    srcs = _v503_sources(ev, pos)
    tags: List[str] = []
    risks: List[str] = []
    for src in srcs:
        for k in ('structure_tags','structure_good_tags','matched_strategies','strategy_tags','tags'):
            tags.extend(_v503_list_any(src.get(k)))
        for k in ('structure_risk_tags','risk_tags','entry_missing_info','missing_info','spike_guard_reasons'):
            risks.extend(_v503_list_any(src.get(k)))
    seen=set(); tags=[x for x in tags if not (x in seen or seen.add(x))][:8]
    seen=set(); risks=[x for x in risks if not (x in seen or seen.add(x))][:8]
    guard = _v503_first_from_sources(srcs, ('spike_late_entry_guard','late_entry_guard'), {})
    if not isinstance(guard, dict):
        guard = {}
    strat_key = _v503_first_from_sources(srcs, ('strategy_key','paper_strategy_key','strategy','route','section'), pos.get('strategy_key') or 'unknown')
    strat_label = _v503_first_from_sources(srcs, ('strategy_label','paper_strategy_label','final_entry_label'), pos.get('strategy_label') or strat_key)
    ctx = {
        'schema': 'paper_entry_context_v503',
        'strategy_key': strat_key,
        'strategy_label': strat_label,
        'structure_tags': tags,
        'structure_risk_tags': risks,
        'risk_tags': risks,
        'spike_late_entry_guard': guard,
        'spike_guard_reasons': guard.get('reasons') or [],
        'drawdown_from_high_pct': _v503_first_from_sources(srcs, ('drawdown_from_high_pct','pullback_from_high_pct'), None),
        'recent_high_price': _v503_first_from_sources(srcs, ('recent_high_price','high_price'), None),
        'hot_signal_age_sec': _v503_first_from_sources(srcs, ('hot_signal_age_sec','spike_signal_age_sec','signal_age_sec'), None),
        'price_reaction_pct': _v503_first_from_sources(srcs, ('price_reaction_pct','reaction_pct','price_recheck_pct'), None),
        'buy_ratio': _v503_first_from_sources(srcs, ('buy_ratio','buy_trade_ratio','micro_buy_ratio'), None),
        'buy_sustain_1m': _v503_first_from_sources(srcs, ('buy_sustain_1m','buy_ratio_1m','micro_buy_ratio_sustain_1m'), None),
        'spread_pct': _v503_first_from_sources(srcs, ('spread_pct','micro_spread_pct','orderbook_spread_pct'), None),
        'slippage_pct': _v503_first_from_sources(srcs, ('slippage_pct','expected_slippage_pct','slippage_est_pct'), None),
    }
    return ctx


_v503_prev_open_position = open_position

def open_position(pos_id: str, ev: Dict[str, Any]) -> Dict[str, Any]:  # type: ignore[override]
    pos = _v503_prev_open_position(pos_id, ev)
    try:
        ctx = _v503_collect_context(ev, pos)
        pos['paper_entry_context_v503'] = ctx
        pos['strategy_key'] = ctx.get('strategy_key') or pos.get('strategy_key') or 'unknown'
        pos['strategy_label'] = ctx.get('strategy_label') or pos.get('strategy_label') or pos.get('strategy_key')
        for key in ('structure_tags','structure_risk_tags','risk_tags','spike_late_entry_guard','spike_guard_reasons','drawdown_from_high_pct','recent_high_price','hot_signal_age_sec'):
            if ctx.get(key) not in (None, '', [], {}):
                pos[key] = ctx.get(key)
        # 기존 entry_context/diagnostics에도 복기 key를 병합해 version_score 요약에서 '-'로 빠지지 않게 한다.
        ec = pos.get('entry_context') if isinstance(pos.get('entry_context'), dict) else {}
        ec.update({k: v for k, v in ctx.items() if v not in (None, '', [], {})})
        pos['entry_context'] = ec
        diag = pos.get('entry_diagnostics') if isinstance(pos.get('entry_diagnostics'), dict) else {}
        diag.setdefault('strategy_key', ctx.get('strategy_key'))
        diag.setdefault('strategy_label', ctx.get('strategy_label'))
        diag.setdefault('matched_strategies', ctx.get('structure_tags') or [])
        diag.setdefault('missing_info', ctx.get('risk_tags') or [])
        for k in ('price_reaction_pct','buy_ratio','buy_sustain_1m','spread_pct','slippage_pct'):
            if ctx.get(k) is not None:
                diag[k] = ctx.get(k)
        if ctx.get('spike_guard_reasons'):
            diag['spike_guard_reasons'] = ctx.get('spike_guard_reasons')
        pos['entry_diagnostics'] = diag
        if isinstance(pos.get('exit_plan'), dict):
            pos['exit_plan']['strategy_key'] = pos.get('strategy_key')
            pos['exit_plan']['strategy_label'] = pos.get('strategy_label')
            pos['exit_plan']['hot_signal_age_sec'] = ctx.get('hot_signal_age_sec')
            pos['exit_plan']['spike_guard_reasons'] = ctx.get('spike_guard_reasons') or []
    except Exception as exc:
        log_error('v503_entry_context_seal', exc)
    return pos


def _v503_context_lines(row: Dict[str, Any], prefix: str='- ') -> List[str]:
    ctx = row.get('paper_entry_context_v503') if isinstance(row.get('paper_entry_context_v503'), dict) else {}
    if not ctx:
        ctx = row.get('entry_context') if isinstance(row.get('entry_context'), dict) else {}
    out: List[str] = []
    tags = _v503_list_any(row.get('structure_tags') or ctx.get('structure_tags'))
    risks = _v503_list_any(row.get('risk_tags') or row.get('structure_risk_tags') or ctx.get('risk_tags') or ctx.get('structure_risk_tags'))
    if tags:
        out.append(prefix + '구조태그: ' + ' / '.join(tags[:5]))
    if risks:
        out.append(prefix + '위험태그: ' + ' / '.join(risks[:5]))
    guard = row.get('spike_late_entry_guard') if isinstance(row.get('spike_late_entry_guard'), dict) else ctx.get('spike_late_entry_guard') if isinstance(ctx.get('spike_late_entry_guard'), dict) else {}
    if isinstance(guard, dict) and guard:
        rs = guard.get('reasons') or []
        dd = guard.get('drawdown_from_high_pct')
        if rs or dd not in (None, ''):
            out.append(prefix + '급등진입검사: ' + (' / '.join(str(x) for x in rs[:3]) if rs else f'고점대비 {fnum(dd, default=0.0):+.2f}%'))
    return out[:4]


_v503_prev_notify_opened = notify_opened

def notify_opened(pos: Dict[str, Any]) -> None:  # type: ignore[override]
    # v500 알림을 유지하되 context가 비면 아래 줄은 생략된다.
    _v503_prev_notify_opened(pos)


_v503_prev_notify_closed = notify_closed

def notify_closed(row: Dict[str, Any]) -> None:  # type: ignore[override]
    # v500 CLOSED 알림은 유지. context는 row/score cache에 봉인되어 /version_score에서도 확인 가능.
    _v503_prev_notify_closed(row)


# =============================================================================
# paper_bot v0.159 / v504: 급등 urgent timing 봉인
# - OPEN row에 hot/micro/orderflow/price age와 paper_read_delay를 보존한다.
# - 알림 포맷은 v500 exit_plan을 그대로 쓰고, entry_timing_trace에 값이 들어가게 한다.
# =============================================================================
VERSION = "paper_bot_v0.159"


def _v504_first(src: Dict[str, Any], keys: tuple, default=None):
    if not isinstance(src, dict):
        return default
    for k in keys:
        v = src.get(k)
        if v not in (None, '', [], {}):
            return v
    return default


def _v504_build_timing_from_event(ev: Dict[str, Any], pos: Dict[str, Any]) -> Dict[str, Any]:
    ec = ev.get('entry_context') if isinstance(ev.get('entry_context'), dict) else {}
    timing = ev.get('entry_timing_trace') if isinstance(ev.get('entry_timing_trace'), dict) else ec.get('entry_timing_trace') if isinstance(ec.get('entry_timing_trace'), dict) else {}
    urgent = ev.get('urgent_timing_trace_v504') if isinstance(ev.get('urgent_timing_trace_v504'), dict) else ec.get('urgent_timing_trace_v504') if isinstance(ec.get('urgent_timing_trace_v504'), dict) else {}
    out = dict(timing) if isinstance(timing, dict) else {}
    out.setdefault('schema', 'paper_entry_timing_trace_v504')
    for k in ('hot_signal_age_sec','micro_age_sec','orderflow_age_sec','price_reaction_age_sec','quote_age_sec'):
        v = _v504_first(urgent, (k,), _v504_first(ev, (k,), _v504_first(ec, (k,), None)))
        if v not in (None, ''):
            out[k] = v
    nowv = now_ts()
    source_ts = fnum(ev.get('created_at'), ev.get('candidate_created_at'), ev.get('source_created_at'), ec.get('strategy_decision_ts'), default=0.0)
    if source_ts > 1000000000:
        out['paper_read_delay_sec'] = round(max(0.0, nowv - source_ts), 3)
    dec_ts = fnum(ec.get('strategy_decision_ts'), out.get('strategy_decision_ts'), default=0.0)
    if dec_ts > 1000000000:
        out['strategy_to_paper_delay_sec'] = round(max(0.0, nowv - dec_ts), 3)
    stale = []
    for k, label, lim in (('hot_signal_age_sec','hot',45),('micro_age_sec','micro',5),('orderflow_age_sec','orderflow',5),('price_reaction_age_sec','price',10),('paper_read_delay_sec','paper',5)):
        vv = fnum(out.get(k), default=-1.0)
        if vv >= 0 and vv > lim:
            stale.append(f'{label} {vv:.1f}s')
    out['stale_reasons'] = stale[:8]
    out['fresh_for_spike_momentum'] = len(stale) == 0
    return out


def _v529_copy_s1_context(ev: Dict[str, Any], pos: Dict[str, Any]) -> Dict[str, Any]:
    if not isinstance(ev, dict) or not isinstance(pos, dict):
        return pos
    ctx = ev.get('entry_context') if isinstance(ev.get('entry_context'), dict) else {}
    keys = (
        'canonical_lane','matched_strategy_keys','matched_strategy_labels',
        's1_checklist','s1_passed_conditions','s1_missing_conditions','s1_missing_names',
        's1_block_count','s1_block_score','s1_distance','s1_near_miss','s1_near_miss_level','s1_short_reason','common_entry_pass','common_entry_schema','strategy_role','entry_profile','exit_profile','profile_family','profile_decisions','canonical_entry_decision','common_entry_decision',
        'price_chg_10s','price_chg_20s','price_chg_30s','price_chg_60s','price_accel_10s','buy_ratio_10s','buy_sustain_20s','spread_widening_10s',
        'buy_sustain_1m_source','buy_sustain_1m_real','buy_sustain_1m_is_fallback','fresh_gate_ok'
    )
    diag = pos.get('entry_diagnostics') if isinstance(pos.get('entry_diagnostics'), dict) else {}
    for k in keys:
        val = ev.get(k) if ev.get(k) not in (None, '', [], {}) else ctx.get(k)
        if val not in (None, '', [], {}):
            pos[k] = val
            diag[k] = val
    gate = ev.get('v510_final_entry_gate') or ctx.get('v510_final_entry_gate') or ev.get('v508_final_entry_gate') or ctx.get('v508_final_entry_gate')
    if isinstance(gate, dict):
        pos['v510_final_entry_gate'] = gate
        diag['v510_final_entry_gate'] = gate
        pos['paper_entry_gate_schema'] = 'v529_v510_final_entry_gate'
    pos['entry_diagnostics'] = diag
    pos['paper_s1_diagnostic_schema'] = 'paper_s1_context_v529_inline'
    return pos

_v504_prev_open_position = open_position

def open_position(pos_id: str, ev: Dict[str, Any]) -> Dict[str, Any]:  # type: ignore[override]
    pos = _v504_prev_open_position(pos_id, ev)
    try:
        timing = _v504_build_timing_from_event(ev, pos)
        pos['entry_timing_trace'] = timing
        pos['urgent_timing_trace_v504'] = timing
        diag = pos.get('entry_diagnostics') if isinstance(pos.get('entry_diagnostics'), dict) else {}
        diag['entry_timing_trace'] = timing
        for k in ('hot_signal_age_sec','micro_age_sec','orderflow_age_sec','price_reaction_age_sec','quote_age_sec','paper_read_delay_sec','strategy_to_paper_delay_sec'):
            if timing.get(k) not in (None, ''):
                pos[k] = timing.get(k)
                diag[k] = timing.get(k)
        if timing.get('stale_reasons'):
            diag['urgent_stale_reasons_v504'] = timing.get('stale_reasons')
            pos['urgent_stale_reasons_v504'] = timing.get('stale_reasons')
        pos['entry_diagnostics'] = diag
        if isinstance(pos.get('exit_plan'), dict):
            pos['exit_plan']['entry_timing_trace'] = timing
            pos['exit_plan']['paper_read_delay_sec'] = timing.get('paper_read_delay_sec')
    except Exception as exc:
        log_error('v504_entry_timing_seal', exc)
    try:
        pos = _v529_copy_s1_context(ev, pos)
    except Exception as exc:
        log_error('v529_s1_context_seal', exc)
    return pos

# v504: notify_opened/closed는 v500/v503 포맷을 그대로 사용한다. entry_timing_trace에 값만 보강한다.

# =============================================================================
# paper_bot v0.160 / v505: CLOSED score context source widening
# - OPEN/CLOSED already works. This only makes version_score/recent CLOSED summaries
#   read the sealed paper_entry_context/exit_plan/timing fields so structure/risk
#   does not fall back to '-'.
# =============================================================================
BUILD_LABEL = "v505_closed_context_source_widen_2026-05-28"

_v505_prev_entry_source = _v463_entry_source

def _v463_entry_source(row: Dict[str, Any]) -> List[Dict[str, Any]]:  # type: ignore[override]
    out: List[Dict[str, Any]] = []
    try:
        for key in (
            'paper_entry_context_v503', 'entry_context', 'entry_diagnostics', 'entry_timing_trace',
            'exit_plan', 'raw', 'source_event', 'meta', 'metadata'
        ):
            obj = row.get(key)
            if isinstance(obj, dict):
                out.append(obj)
                for sub in ('paper_entry_context_v503','entry_context','entry_diagnostics','canonical_entry_decision','metrics','structure','feature','orderflow','micro','spike_late_entry_guard','urgent_timing_trace_v504'):
                    vv = obj.get(sub)
                    if isinstance(vv, dict):
                        out.append(vv)
        out.extend(_v505_prev_entry_source(row))
    except Exception:
        try:
            out.extend(_v505_prev_entry_source(row))
        except Exception:
            pass
    dedup: List[Dict[str, Any]] = []
    seen: set[int] = set()
    for obj in out:
        if isinstance(obj, dict) and id(obj) not in seen:
            seen.add(id(obj)); dedup.append(obj)
    return dedup

_v505_prev_entry_summary = _v463_entry_summary

def _v463_entry_summary(row: Dict[str, Any]) -> Dict[str, Any]:  # type: ignore[override]
    sm = _v505_prev_entry_summary(row)
    try:
        tags = list(sm.get('structure_tags') or [])
        risks = list(sm.get('risk_tags') or [])
        srcs = _v463_entry_source(row)
        for src in srcs:
            for k in ('structure_tags','structure_good_tags','matched_strategies','strategy_tags','tags'):
                tags.extend(_v463_as_list(src.get(k)))
            for k in ('structure_risk_tags','risk_tags','spike_guard_reasons','urgent_stale_reasons_v504','entry_missing_info','missing_info'):
                risks.extend(_v463_as_list(src.get(k)))
        if not tags:
            label = row.get('strategy_label') or row.get('paper_strategy_label') or row.get('strategy') or row.get('strategy_key')
            sk = str(row.get('strategy_key') or row.get('strategy') or '')
            if label and ('spike' in sk or '급등' in str(label)):
                tags.append(str(label))
        seen=set(); tags=[x for x in tags if str(x).strip() and not (x in seen or seen.add(x))][:5]
        seen=set(); risks=[x for x in risks if str(x).strip() and not (x in seen or seen.add(x))][:5]
        sm['structure_tags'] = tags
        sm['risk_tags'] = risks
    except Exception:
        pass
    return sm



# =============================================================================
# paper_bot v0.162 / v509: canonical latest only + hard pre-open freshness gate
# - Deletes legacy consumer sources from the runtime OPEN path.
#   Runtime OPEN reads only paper_candidates_latest.jsonl.
# - Paper opens only rows from paper_candidates_latest.jsonl that carry the canonical
#   final gate and pass fresh/open_eligible checks.
# =============================================================================
VERSION = "paper_bot_v0.174"
BUILD_LABEL = "v537_profile_final_gate_aligned"


def _v508_num(*vals: Any, default: float = 999999.0) -> float:
    for v in vals:
        try:
            if v is None or v == "" or v == [] or v == {}:
                continue
            return float(v)
        except Exception:
            continue
    return default


def _v508_srcs(ev: Dict[str, Any]) -> List[Dict[str, Any]]:
    out: List[Dict[str, Any]] = []
    def add(v: Any):
        if isinstance(v, dict): out.append(v)
    add(ev)
    for k in ("entry_context", "canonical_entry_decision", "entry_snapshot", "entry_timing_trace", "urgent_timing_trace_v508", "urgent_timing_trace_v504", "v510_final_entry_gate", "v508_final_entry_gate", "v507_final_entry_gate", "paper_final_safety_diagnostics", "raw"):
        add((ev or {}).get(k))
    ctx = (ev or {}).get("entry_context") if isinstance((ev or {}).get("entry_context"), dict) else {}
    for k in ("urgent_timing_trace_v508", "urgent_timing_trace_v504", "entry_timing_trace", "v510_final_entry_gate", "v508_final_entry_gate", "v507_final_entry_gate"):
        add(ctx.get(k))
    for src in list(out):
        add(src.get("age_values"))
    seen=set(); clean=[]
    for d in out:
        if id(d) not in seen:
            seen.add(id(d)); clean.append(d)
    return clean


def _v508_first(ev: Dict[str, Any], keys: Tuple[str, ...], default: float = 999999.0) -> float:
    for src in _v508_srcs(ev):
        for k in keys:
            if k in src and src.get(k) not in (None, "", [], {}):
                v = _v508_num(src.get(k), default=default)
                if v != default:
                    return v
    return default


def _v508_strategy_key(ev: Dict[str, Any]) -> str:
    return str(ev.get("strategy_key") or ev.get("paper_strategy_key") or ev.get("strategy") or ev.get("route") or "")


def _v508_is_spike(ev: Dict[str, Any]) -> bool:
    ctx = ev.get("entry_context") if isinstance(ev.get("entry_context"), dict) else {}
    dec = ev.get("canonical_entry_decision") or ctx.get("canonical_entry_decision") or ev.get("common_entry_decision") or ctx.get("common_entry_decision")
    if not isinstance(dec, dict):
        dec = {}
    p = str(ev.get("entry_profile") or ctx.get("entry_profile") or dec.get("entry_profile") or "").strip()
    if p in {"spike", "spike_fast_early", "spike_runner"}:
        return True
    sk = _v508_strategy_key(ev)
    label = str(ev.get("strategy_label") or ev.get("strategy") or "")
    return sk in {"spike_momentum_ride", "spike_pullback_reaccel"} or "급등" in label or "spike" in sk


def _v508_age_reasons(ev: Dict[str, Any]) -> Tuple[bool, List[str], Dict[str, float]]:
    nowv = now_ts()
    hot = _v508_first(ev, ("hot_signal_age_sec", "signal_age_sec", "hot"))
    micro = _v508_first(ev, ("micro_age_sec", "trade_age_sec", "micro", "trade"))
    orderflow = _v508_first(ev, ("orderflow_age_sec", "orderflow", "trade_age_sec", "micro_age_sec"), default=micro)
    price = _v508_first(ev, ("price_reaction_age_sec", "price_age_sec", "feature_age_sec", "price", "reaction_age_sec"))
    quote = _v508_first(ev, ("quote_age_sec", "ws_age_sec", "quote", "ws"))
    # paper delay is computed from the row creation timestamp.
    src_ts = event_created_ts(ev)
    paper_delay = max(0.0, nowv - src_ts) if src_ts > 0 else 999999.0
    ages = {"hot": hot, "micro": micro, "orderflow": orderflow, "price": price, "quote": quote, "paper": paper_delay}
    stale: List[str] = []
    if _v508_is_spike(ev):
        if hot > 45.0: stale.append(f"hot {hot:.1f}s")
        if micro > 5.0: stale.append(f"micro {micro:.1f}s")
        if orderflow > 5.0: stale.append(f"orderflow {orderflow:.1f}s")
        if price > 10.0: stale.append(f"price {price:.1f}s")
        if quote > 5.0: stale.append(f"quote {quote:.1f}s")
        if paper_delay > 20.0: stale.append(f"paper {paper_delay:.1f}s")
    else:
        if price >= 999998.0: stale.append("price_age_missing")
        elif price > 30.0: stale.append(f"price {price:.1f}s")
        if micro >= 999998.0: stale.append("micro_age_missing")
        elif micro > 20.0: stale.append(f"micro {micro:.1f}s")
        if paper_delay > 45.0: stale.append(f"paper {paper_delay:.1f}s")
    return len(stale) == 0, stale, ages


# v532: is_s1_candidate/paper_final_safety tail overrides removed; main bodies read canonical_entry_decision.


# v508 final entrypoint after canonical latest only source override.
if __name__ == "__main__":
    if len(sys.argv) > 1 and sys.argv[1] == "--once":
        print(json.dumps(run_cycle(), ensure_ascii=False, indent=2))
    else:
        main()
