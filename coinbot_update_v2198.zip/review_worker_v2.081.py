#!/usr/bin/env python3
# -*- coding: utf-8 -*-
from __future__ import annotations
import atexit, fcntl, hashlib, json, math, os, resource, sys, time, traceback
from collections import deque
from collections import Counter
from pathlib import Path
from typing import Any, Dict, Iterable, List, Optional, Tuple

BASE_DIR=Path(os.getenv('TRADING_BOT_DIR','/home/dangdang971216/trading_bot'))
VERSION='review_worker_v2.066'
BUILD_LABEL='v2168_single_identity_actual_owner_2026-07-22'
INTERVAL_SEC=max(5.0,float(os.getenv('REVIEW_WORKER_INTERVAL_SEC','30')))
STATUS=BASE_DIR/'clean_review_worker_status.json'
ERROR=BASE_DIR/'clean_review_worker_error.log'
PAPER_LATEST=BASE_DIR/'paper_candidates_latest.jsonl'
OPEN_PATH=BASE_DIR/'paper_v2_exact_open_v2135.json'
CLOSED_PATH=BASE_DIR/'paper_v2_exact_closed_v2135.jsonl'
OUTCOME_STATE=BASE_DIR/'strategy_v2_outcome_state_v2133.json'
OUTCOME_STATUS=BASE_DIR/'strategy_v2_outcome_status_v2133.json'
OUTCOME_LEDGER=BASE_DIR/'strategy_v2_outcomes_v2133.jsonl'
CHANGE_LEDGER=BASE_DIR/'runtime'/'change_verify_ledger.jsonl'
ISSUE_LEDGER=BASE_DIR/'ledger'/'issue_ledger_events.jsonl'
LOCK_PATH=BASE_DIR/'runtime'/'review_worker_singleton_v1121.lock'
GENERATION='ALT_SWING_V2_COMBINED_V2149_RESET_20260722'
STATE_KEY='v2149_rows'
HORIZONS=(('5m',300.0),('15m',900.0),('30m',1800.0),('1h',3600.0),('3h',10800.0),('6h',21600.0))
MODEL_GENERATION_FALLBACK=''
STATE_CHECKPOINT_SEC=max(60.0,float(os.getenv('REVIEW_STATE_CHECKPOINT_SEC_V2168','120')))
STRATEGY_STATUS=BASE_DIR/'clean_strategy_worker_status.json'
STRATEGY_DECISION_STATUS=BASE_DIR/'strategy_v2_decision_status_v2133.json'
SHADOW_WRITERS_REMOVED=(
    'trigger_shadow_v665','quality_shadow_v1125','smart_structure_shadow_v948',
    'unified_shadow_v2010','entry_survival_shadow_v2014','top10_shadow_v2015_v2019',
    'c_break_retest_performance_shadow','open_limit_shadow'
)
_LOCK_FH=None


def now_ts()->float:return time.time()
def now_text(ts:Optional[float]=None)->str:
    return time.strftime('%Y-%m-%d %H:%M:%S',time.localtime(ts or now_ts()))

def _atomic_json(path:Path,obj:Any)->None:
    path.parent.mkdir(parents=True,exist_ok=True)
    tmp=path.with_name(path.name+f'.tmp.{os.getpid()}')
    tmp.write_text(json.dumps(obj,ensure_ascii=False,separators=(',',':')),encoding='utf-8')
    os.replace(tmp,path)

def load_json(path:Path,default:Any)->Any:
    try:return json.loads(path.read_text(encoding='utf-8'))
    except Exception:return default

def read_jsonl(path:Path,max_lines:int=10000)->List[Dict[str,Any]]:
    if not path.exists():return []
    try:
        with path.open('r',encoding='utf-8',errors='ignore') as f:
            lines=deque(f,maxlen=max_lines)
    except Exception:return []
    out=[]
    for line in lines:
        try:
            row=json.loads(line)
            if isinstance(row,dict):out.append(row)
        except Exception:pass
    return out

def append_jsonl(path:Path,row:Dict[str,Any])->None:
    path.parent.mkdir(parents=True,exist_ok=True)
    with path.open('a',encoding='utf-8') as f:
        f.write(json.dumps(row,ensure_ascii=False,separators=(',',':'))+'\n')
        f.flush();os.fsync(f.fileno())

def append_error(where:str,exc:BaseException)->None:
    ERROR.parent.mkdir(parents=True,exist_ok=True)
    with ERROR.open('a',encoding='utf-8') as f:
        f.write(f'[{now_text()}] {where}: {type(exc).__name__}: {exc}\n')
        f.write(traceback.format_exc()+'\n')

def num(v:Any,default:Optional[float]=None)->Optional[float]:
    try:
        if v in (None,'') or isinstance(v,bool):return default
        x=float(v);return x if math.isfinite(x) else default
    except Exception:return default

def ticker(v:Any)->str:
    s=str(v or '').upper().strip().replace('KRW-','').replace('_KRW','').replace('/KRW','')
    return s

def contract_of(row:Dict[str,Any])->Dict[str,Any]:
    c=row.get('trade_path_contract_v2149')
    return c if isinstance(c,dict) and str(c.get('generation') or '')==GENERATION else {}

def open_contract(row:Dict[str,Any])->Dict[str,Any]:
    c=row.get('trade_path_contract_v2149_at_open')
    return c if isinstance(c,dict) else {}

def row_price(row:Dict[str,Any])->Optional[float]:
    for k in ('current_price','price','last_price','close','trade_price','market_price'):
        x=num(row.get(k))
        if x and x>0:return x
    c=contract_of(row);s=c.get('structure') if isinstance(c.get('structure'),dict) else {}
    x=num(s.get('current_price'))
    return x if x and x>0 else None

def exact_decision_keys(row:Dict[str,Any],contract:Optional[Dict[str,Any]]=None)->List[str]:
    c=contract if isinstance(contract,dict) else {}
    vals=(
        c.get('decision_key'),row.get('direct_decision_key_v2149'),row.get('direct_decision_key'),
        row.get('paper_decision_key_v926'),row.get('swing_gate_decision_key_v977'),
        row.get('source_decision_key'),row.get('decision_key'),
    )
    out=[]
    for v in vals:
        s=str(v or '').strip()
        if s and s not in out:out.append(s)
    return out

def plan_from_decision(decision:str)->str:
    # v2149:<ticker>:<plan_hash>:<trigger_event_ms>
    parts=str(decision or '').split(':')
    return 'v2149-plan:'+parts[-2] if len(parts)>=4 and parts[0]=='v2149' and parts[-2] else ''

def stable_key(row:Dict[str,Any],c:Dict[str,Any])->str:
    t=ticker(row.get('ticker') or c.get('ticker'))
    s=c.get('structure') if isinstance(c.get('structure'),dict) else {}
    inv=num(s.get('execution_invalid'));t1=num(s.get('target_t1'))
    if not t or not inv or not t1 or not t1>inv:return ''
    seed=json.dumps({'ticker':t,'invalid':round(inv,10),'target_t1':round(t1,10)},sort_keys=True,separators=(',',':'))
    return f'{GENERATION}|{t}|v2154-structure:{hashlib.sha256(seed.encode()).hexdigest()[:20]}'

def outcome(rec:Dict[str,Any])->str:
    a=num(rec.get('first_t1_ts'));b=num(rec.get('first_invalid_ts'))
    if a and b:
        if a==b:return 'AMBIGUOUS_SAME_SNAPSHOT'
        return 'T1_FIRST' if a<b else 'INVALID_FIRST'
    if a:return 'T1_FIRST'
    if b:return 'INVALID_FIRST'
    return 'NO_TOUCH'

def touch_order(up:Optional[float],down:Optional[float])->str:
    if up and down:
        if up==down:return 'AMBIGUOUS'
        return 'UP_FIRST' if up<down else 'DOWN_FIRST'
    if up:return 'UP_FIRST'
    if down:return 'DOWN_FIRST'
    return 'NO_TOUCH'

def group_scores(c:Dict[str,Any])->Dict[str,Any]:
    p=c.get('prediction') if isinstance(c.get('prediction'),dict) else {}
    e=c.get('prediction_evidence') if isinstance(c.get('prediction_evidence'),dict) else (p.get('evidence') if isinstance(p.get('evidence'),dict) else {})
    g=e.get('groups') if isinstance(e.get('groups'),dict) else {}
    def gs(name:str):
        v=g.get(name);return num(v.get('score')) if isinstance(v,dict) else None
    return {
        'continuation_score':num(p.get('continuation_score')),
        'participation_score':gs('participation'),
        'trigger_flow_score':gs('trigger_flow'),
        'structure_context_score_v2155':gs('structure_context'),
        'market_context_score_v2155':gs('market_context'),
        'continuation_lower_bound':num(p.get('continuation_lower_bound')),
        'model_confidence_pct':num(p.get('model_confidence_pct')),
    }

def create_record(row:Dict[str,Any],c:Dict[str,Any],price:float,nowv:float,key:str)->Dict[str,Any]:
    s=c.get('structure') if isinstance(c.get('structure'),dict) else {}
    p=c.get('prediction') if isinstance(c.get('prediction'),dict) else {}
    comb=c.get('decision_combiner') if isinstance(c.get('decision_combiner'),dict) else {}
    scores=group_scores(c)
    rec={
        'schema':'strategy_v2_outcome_state_row_v2163','generation':GENERATION,'event_key':key,
        'plan_key':c.get('plan_key'),'decision_key':None,'decision_keys_exact_v2163':[],
        'ticker':ticker(row.get('ticker') or c.get('ticker')),'start_ts':nowv,'start_text':now_text(nowv),
        'last_seen_ts':nowv,'reference_entry':num(s.get('reference_entry'),price),
        'execution_invalid':num(s.get('execution_invalid')),'target_t1':num(s.get('target_t1')),'target_t2':num(s.get('target_t2')),
        'geometry_state':'READY' if (num(s.get('execution_invalid'),0)<num(s.get('reference_entry'),price)<num(s.get('target_t1'),0)) else str(s.get('state') or ''),
        'contract_state':c.get('state'),'structure_state':s.get('state'),'prediction_state':p.get('state'),
        'combiner_state':comb.get('state') or c.get('state'),'combiner_eligible':comb.get('entry_eligible') is True,
        'prediction_model_generation':c.get('prediction_model_generation') or p.get('prediction_model_generation'),
        'probability_is_calibrated':p.get('probability_is_calibrated') is True,
        'max_pct':0.0,'min_pct':0.0,'samples':{},'practical_samples_v2163':{},
        'practical_tracking_started_ts_v2163':nowv,'first_up_pct_ts_v2163':{},'first_down_pct_ts_v2163':{},
        'final_appended':False,'actual_trade_exact_v2163':False,'tracking_version_v2166':VERSION,'auto_buy':False,
    }
    rec.update(scores)
    return rec

def update_identity(rec:Dict[str,Any],row:Dict[str,Any],c:Dict[str,Any],nowv:float)->None:
    keys=list(rec.get('decision_keys_exact_v2163') or [])
    for k in exact_decision_keys(row,c):
        if k not in keys:keys.append(k)
    rec['decision_keys_exact_v2163']=keys
    if keys:
        rec['decision_key']=keys[0];rec['decision_link_state_v2163']='DIRECT_DECISION_KEY_READY'
        if not isinstance(rec.get('decision_snapshot_v2163'),dict):
            snap={'captured_ts':nowv,'captured_text':now_text(nowv),'contract_state':c.get('state')}
            snap.update(group_scores(c));rec['decision_snapshot_v2163']=snap
    # Current lifecycle state can change; sealed initial scores above are never overwritten.
    comb=c.get('decision_combiner') if isinstance(c.get('decision_combiner'),dict) else {}
    rec['last_contract_state_v2163']=c.get('state');rec['last_combiner_state_v2163']=comb.get('state') or c.get('state')
    rec['last_combiner_eligible_v2163']=comb.get('entry_eligible') is True

def update_path(rec:Dict[str,Any],price:float,nowv:float)->None:
    entry=num(rec.get('reference_entry'))
    if not entry or entry<=0:return
    pct=(price/entry-1.0)*100.0
    rec['last_seen_ts']=nowv;rec['last_seen_text']=now_text(nowv);rec['last_price']=price
    rec['max_pct']=max(num(rec.get('max_pct'),pct) or pct,pct);rec['min_pct']=min(num(rec.get('min_pct'),pct) or pct,pct)
    t1=num(rec.get('target_t1'));inv=num(rec.get('execution_invalid'));t2=num(rec.get('target_t2'))
    if t1 and price>=t1 and not rec.get('first_t1_ts'):rec['first_t1_ts']=nowv
    if inv and price<=inv and not rec.get('first_invalid_ts'):rec['first_invalid_ts']=nowv
    if t2 and price>=t2 and not rec.get('first_t2_ts'):rec['first_t2_ts']=nowv
    ups=rec.setdefault('first_up_pct_ts_v2163',{});downs=rec.setdefault('first_down_pct_ts_v2163',{})
    for threshold in (1,2,3):
        k=str(threshold)
        if pct>=threshold and not ups.get(k):ups[k]=nowv
        if pct<=-threshold and not downs.get(k):downs[k]=nowv
    elapsed=max(0.0,nowv-num(rec.get('start_ts'),nowv))
    samples=rec.setdefault('samples',{})
    for label,sec in HORIZONS:
        if label in samples:continue
        if elapsed>=sec:
            lateness=max(0.0,elapsed-sec)
            samples[label]={
                'pct':round(pct,6),'max_pct':round(num(rec.get('max_pct'),0) or 0,6),'min_pct':round(num(rec.get('min_pct'),0) or 0,6),
                'outcome_so_far':outcome(rec),'sampled_ts':nowv,'sampled_text':now_text(nowv),
                'sample_precision_v2163':'FIRST_CYCLE_AFTER_HORIZON',
                'sample_lateness_sec_v2166':round(lateness,3),
                'same_event_cumulative_horizon_v2166':True
            }
    pstart=num(rec.get('practical_tracking_started_ts_v2163'),nowv) or nowv
    pelapsed=max(0.0,nowv-pstart);ps=rec.setdefault('practical_samples_v2163',{})
    for label,sec in HORIZONS:
        if label in ps or pelapsed<sec:continue
        ps[label]={
            'pct':round(pct,6),'max_pct':round(num(rec.get('max_pct'),0) or 0,6),'min_pct':round(num(rec.get('min_pct'),0) or 0,6),
            'up1_vs_down1':touch_order(num(ups.get('1')),num(downs.get('1'))),
            'up2_vs_down1':touch_order(num(ups.get('2')),num(downs.get('1'))),
            'up3_vs_down1':touch_order(num(ups.get('3')),num(downs.get('1'))),
            'up1_reached':bool(ups.get('1')),'up2_reached':bool(ups.get('2')),'up3_reached':bool(ups.get('3')),
            'down1_reached':bool(downs.get('1')),'sampled_ts':nowv,'sampled_text':now_text(nowv),
            'tracking_basis_v2163':'FORWARD_ONLY_FROM_V2163'
        }

def iter_open_rows()->List[Dict[str,Any]]:
    obj=load_json(OPEN_PATH,{})
    if isinstance(obj,list):return [x for x in obj if isinstance(x,dict)]
    if not isinstance(obj,dict):return []
    for k in ('open_positions','positions','rows','open'):
        v=obj.get(k)
        if isinstance(v,list):return [x for x in v if isinstance(x,dict)]
        if isinstance(v,dict):return [x for x in v.values() if isinstance(x,dict)]
    return [x for x in obj.values() if isinstance(x,dict)]

def actual_generation(row:Dict[str,Any],contract:Optional[Dict[str,Any]]=None)->str:
    c=contract if isinstance(contract,dict) else {}
    return str(row.get('paper_v2_generation') or c.get('generation') or '').strip()

def actual_model(row:Dict[str,Any],contract:Optional[Dict[str,Any]]=None)->str:
    c=contract if isinstance(contract,dict) else {}
    p=c.get('prediction') if isinstance(c.get('prediction'),dict) else {}
    return str(c.get('prediction_model_generation') or p.get('prediction_model_generation') or row.get('prediction_model_generation') or '').strip()

def attach_actual_trades(records:Dict[str,Dict[str,Any]],nowv:float,model_generation:str)->Dict[str,int]:
    open_rows=iter_open_rows()
    closed_rows=read_jsonl(CLOSED_PATH,2000)
    actual_rows=[(x,'OPEN') for x in open_rows]+[(x,'CLOSED') for x in closed_rows]
    by_decision:Dict[str,Dict[str,Any]]={}
    by_plan:Dict[str,List[Dict[str,Any]]]={}
    for rec in records.values():
        if not isinstance(rec,dict) or rec.get('superseded_duplicate_v2154'):continue
        for k in rec.get('decision_keys_exact_v2163') or []:by_decision[str(k)]=rec
        p=str(rec.get('plan_key') or '')
        if p:by_plan.setdefault(p,[]).append(rec)
    total=linked=plan_derived=missing=created=0
    open_total=closed_total=0
    for row,kind in actual_rows:
        if not isinstance(row,dict):continue
        c=open_contract(row)
        if actual_generation(row,c)!=GENERATION:continue
        if actual_model(row,c)!=model_generation:continue
        total+=1
        if kind=='OPEN':open_total+=1
        else:closed_total+=1
        keys=exact_decision_keys(row,c)
        if not keys:
            missing+=1;continue
        rec=None;source='DIRECT_DECISION_KEY'
        for k in keys:
            if k in by_decision:rec=by_decision[k];break
        if rec is None:
            plans={str(c.get('plan_key') or '').strip(),str(c.get('candidate_plan_key') or '').strip()}
            plans.update(plan_from_decision(k) for k in keys if plan_from_decision(k));plans.discard('')
            matches=[]
            for plan in plans:matches.extend(by_plan.get(plan,[]))
            unique={id(x):x for x in matches}
            if len(unique)==1:
                rec=next(iter(unique.values()));source='SEALED_PLAN_KEY_EXACT';plan_derived+=1
        if rec is None and c:
            entry=num(row.get('entry_price') or row.get('open_price') or ((c.get('structure') or {}).get('reference_entry') if isinstance(c.get('structure'),dict) else None))
            if entry and entry>0:
                event='actual:'+hashlib.sha256(keys[0].encode()).hexdigest()[:24]
                rec=create_record(row,c,entry,nowv,event)
                opened=num(row.get('paper_v2_exact_opened_ts') or row.get('opened_at') or row.get('open_ts') or row.get('entry_ts'))
                rec['start_ts']=opened or nowv;rec['start_text']=now_text(rec['start_ts'])
                rec['reference_entry']=entry;rec['practical_tracking_started_ts_v2163']=nowv
                rec['actual_record_created_from_sealed_contract_v2165']=True
                records[event]=rec;created+=1;source='SEALED_EXACT_BOOK_CONTRACT'
                plan=str(c.get('plan_key') or '')
                if plan:rec['plan_key']=plan;by_plan.setdefault(plan,[]).append(rec)
        if rec is None:
            missing+=1;continue
        arr=list(rec.get('decision_keys_exact_v2163') or [])
        for k in keys:
            if k not in arr:arr.append(k)
            by_decision[k]=rec
        rec['decision_keys_exact_v2163']=arr;rec['decision_key']=arr[0]
        rec['actual_trade_exact_v2163']=True;rec['actual_link_source_v2163']=source
        rec['actual_trade_open_v2164']=kind=='OPEN';rec['actual_trade_closed_v2164']=kind=='CLOSED'
        pos=str(row.get('pos_id') or row.get('position_id') or '').strip()
        if pos:
            ids=list(rec.get('actual_pos_ids_v2163') or [])
            if pos not in ids:ids.append(pos)
            rec['actual_pos_ids_v2163']=ids
        if not isinstance(rec.get('actual_entry_snapshot_v2163'),dict):
            rec['actual_entry_snapshot_v2163']={
                'opened_at':num(row.get('paper_v2_exact_opened_ts') or row.get('opened_at') or row.get('open_ts') or row.get('entry_ts')),
                'entry_price':num(row.get('entry_price') or row.get('open_price')),
                'decision_key':arr[0],'pos_id':pos or None,'captured_ts':nowv,
                'sealed_contract_present':bool(c),'paper_v2_generation':actual_generation(row,c)
            }
        live=row_price(row)
        if live and live>0:update_path(rec,live,nowv)
        linked+=1
    return {
        'actual_exact_total':total,'actual_exact_linked':linked,'actual_plan_derived_exact':plan_derived,
        'actual_exact_missing':missing,'actual_created_from_sealed_contract_v2164':created,
        'actual_created_from_sealed_contract_v2165':created,'actual_exact_open_total_v2165':open_total,
        'actual_exact_closed_total_v2165':closed_total,'actual_exact_source_v2165':'paper_v2_exact_open/closed_v2135'
    }


def _runtime_identity_from_strategy(source_rows:List[Dict[str,Any]])->Dict[str,Any]:
    st=load_json(STRATEGY_STATUS,{}) or {}
    ds=load_json(STRATEGY_DECISION_STATUS,{}) or {}
    ident=st.get('runtime_identity_v2168') if isinstance(st.get('runtime_identity_v2168'),dict) else {}
    if not ident and isinstance(ds.get('runtime_identity_v2168'),dict): ident=ds.get('runtime_identity_v2168')
    worker=str(ident.get('worker_version') or st.get('strategy_worker_version') or st.get('version') or '')
    build=str(ident.get('worker_build') or st.get('deploy_version') or st.get('build') or '')
    core=str(ident.get('core_version') or ds.get('active_prediction_owner') or '')
    model=str(ident.get('model_generation') or st.get('prediction_model_generation_v2168') or ds.get('prediction_model_generation_v2168') or '')
    candidate_models=Counter()
    candidate_cores=Counter()
    for row in source_rows:
        if not isinstance(row,dict): continue
        c=contract_of(row)
        m=actual_model(row,c)
        if m: candidate_models[m]+=1
        rid=c.get('runtime_identity_v2168') if isinstance(c.get('runtime_identity_v2168'),dict) else {}
        cv=str(rid.get('core_version') or c.get('version') or '')
        if cv: candidate_cores[cv]+=1
    candidate_model_ok=bool(not candidate_models or (len(candidate_models)==1 and model in candidate_models))
    candidate_core_ok=bool(not candidate_cores or (len(candidate_cores)==1 and core in candidate_cores))
    ready=bool(
        ident.get('ready') is True
        and worker=='strategy_worker_v2.062'
        and build=='v2168_single_identity_event_spine_2026-07-22'
        and core=='strategy_v2_core_v2168'
        and model=='FULL_INPUT_V2171'
        and candidate_model_ok and candidate_core_ok
    )
    return {
        'schema':'review_strategy_runtime_identity_v2168','ready':ready,
        'worker_version':worker,'worker_build':build,'core_version':core,'model_generation':model,
        'candidate_model_counts':dict(candidate_models),'candidate_core_counts':dict(candidate_cores),
        'candidate_model_ok':candidate_model_ok,'candidate_core_ok':candidate_core_ok,
        'source':'clean_strategy_worker_status + strategy_v2_decision_status + candidate contract',
        'auto_buy':False,
    }

def rss_mb()->float:
    try:
        for line in Path('/proc/self/status').read_text().splitlines():
            if line.startswith('VmRSS:'):return round(float(line.split()[1])/1024,2)
    except Exception:pass
    return 0.0

def run_once()->Dict[str,Any]:
    started=time.monotonic();nowv=now_ts();phase0=time.monotonic()
    source=[r for r in read_jsonl(PAPER_LATEST,1400) if str(r.get('strategy_generation_v2149') or '')==GENERATION]
    source_read_sec=round(time.monotonic()-phase0,4)
    runtime=_runtime_identity_from_strategy(source)
    active_model=str(runtime.get('model_generation') or '')
    phase1=time.monotonic()
    state=load_json(OUTCOME_STATE,{}) or {};state=dict(state) if isinstance(state,dict) else {}
    records=state.get(STATE_KEY) if isinstance(state.get(STATE_KEY),dict) else {}
    records={str(k):v for k,v in records.items() if isinstance(v,dict)}
    state_load_sec=round(time.monotonic()-phase1,4)
    new=0;current=0;model_counts=Counter();contract_counts=Counter();input_failures=Counter();connection_states=Counter()
    if runtime.get('ready'):
        for row in source:
            c=contract_of(row);price=row_price(row);key=stable_key(row,c) if c else ''
            if not c or not key or not price or price<=0:continue
            model=actual_model(row,c) or 'UNKNOWN';model_counts[model]+=1
            if model!=active_model:continue
            current+=1;contract_counts[str(c.get('state') or 'UNKNOWN')]+=1
            pred=c.get('prediction') if isinstance(c.get('prediction'),dict) else {}
            evidence=c.get('prediction_evidence') if isinstance(c.get('prediction_evidence'),dict) else (pred.get('evidence') if isinstance(pred.get('evidence'),dict) else {})
            for failure in (evidence.get('required_input_failures_v2155') or pred.get('required_input_failures_v2155') or []):input_failures[str(failure)]+=1
            conns=evidence.get('input_connections_v2155') if isinstance(evidence.get('input_connections_v2155'),dict) else {}
            for meta in conns.values():
                if isinstance(meta,dict):connection_states[str(meta.get('state') or 'MISSING')]+=1
            rec=records.get(key)
            if not isinstance(rec,dict):rec=create_record(row,c,price,nowv,key);records[key]=rec;new+=1
            update_identity(rec,row,c,nowv);update_path(rec,price,nowv)
    else:
        for row in source:
            c=contract_of(row);m=actual_model(row,c) if c else ''
            if m:model_counts[m]+=1
    phase2=time.monotonic()
    link=attach_actual_trades(records,nowv,active_model) if runtime.get('ready') else {
        'actual_exact_total':0,'actual_exact_linked':0,'actual_plan_derived_exact':0,'actual_exact_missing':0,
        'actual_created_from_sealed_contract_v2164':0,'actual_created_from_sealed_contract_v2165':0,
        'actual_exact_open_total_v2165':0,'actual_exact_closed_total_v2165':0,
        'actual_exact_source_v2165':'WAIT_RUNTIME_IDENTITY_V2167'
    }
    actual_link_sec=round(time.monotonic()-phase2,4)
    finalized=0;prune_keys=[]
    for rec_key,rec in records.items():
        if not isinstance(rec,dict) or rec.get('superseded_duplicate_v2154'):continue
        age=max(0.0,nowv-num(rec.get('start_ts'),nowv))
        if age>=21600 and not rec.get('final_appended'):
            final=dict(rec);final.update({'schema':'strategy_v2_outcome_v2163','generation':GENERATION,'outcome_6h':outcome(rec),'finalized_ts':nowv,'finalized_text':now_text(nowv),'historical_ledger_rewritten':False,'auto_buy':False})
            append_jsonl(OUTCOME_LEDGER,final);rec['final_appended']=True;finalized+=1
        if rec.get('final_appended') and (not rec.get('actual_trade_exact_v2163') or rec.get('actual_trade_closed_v2164')):prune_keys.append(str(rec_key))
    for rec_key in prune_keys:records.pop(rec_key,None)
    snapshot=int(state.get('v2149_snapshot_count') or 0)+1
    active=[r for r in records.values() if isinstance(r,dict) and not r.get('superseded_duplicate_v2154')]
    active_model_rows=[r for r in active if active_model and str(r.get('prediction_model_generation') or '')==active_model]
    horizon_counts={}
    for label,_ in HORIZONS:
        horizon_counts[label]={
            'contract_samples':sum(1 for r in active_model_rows if isinstance((r.get('samples') or {}).get(label),dict)),
            'practical_forward_samples':sum(1 for r in active_model_rows if isinstance((r.get('practical_samples_v2163') or {}).get(label),dict)),
        }
    active_ages=[max(0.0,nowv-(num(r.get('start_ts'),nowv) or nowv)) for r in active_model_rows]
    oldest=max(active_ages) if active_ages else 0.0
    finals=[r for r in read_jsonl(OUTCOME_LEDGER,12000) if str(r.get('generation') or '')==GENERATION]
    state_name='ACTIVE' if runtime.get('ready') and current else ('WAITING_ACTIVE_MODEL_CANDIDATES' if runtime.get('ready') else 'RUNTIME_IDENTITY_CHECK')
    status={
        'schema':'strategy_v2_outcome_status_v2167','version':VERSION,'build':BUILD_LABEL,'generation':GENERATION,
        'updated_ts':nowv,'updated_text':now_text(nowv),'state':state_name,
        'snapshot_count':snapshot,'candidate_rows':current,'active_records':len(active_model_rows),'new_records_cycle':new,'finalized_cycle':finalized,
        'pruned_derived_state_cycle_v2163':len(prune_keys),'pruned_derived_state_cycle_v2164':len(prune_keys),
        'prediction_model_counts_v2163':dict(model_counts),'prediction_model_counts_v2155':dict(model_counts),'contract_state_counts':dict(contract_counts),
        'required_input_failure_counts_v2155':dict(input_failures),'input_connection_state_counts_v2155':dict(connection_states),
        'full_input_active_records_v2155':len(active_model_rows),'full_input_finalized_records_v2155':sum(1 for r in finals if str(r.get('prediction_model_generation') or '').startswith('FULL_INPUT_')),
        'review_6h_state_v2154':'COMPLETE_AVAILABLE' if finals else ('WAITING_FIRST_6H' if active_model_rows else 'WAITING_CANDIDATES'),
        'oldest_active_age_sec_v2154':round(oldest,3),'first_6h_due_in_sec_v2154':round(max(0.0,21600-oldest),3) if active_model_rows and not finals else 0.0,
        'horizon_counts_v2163':horizon_counts,**link,
        'runtime_identity_v2168':runtime,'runtime_identity_ready_v2168':bool(runtime.get('ready')),
        'active_model_generation_v2168':active_model or None,
        'exact_link_policy_v2163':'direct decision key; deterministic plan hash derived from the same direct decision key only; no ticker/time proximity',
        'primary_horizons_v2163':['1h','3h'],'support_horizons_v2163':['30m','6h'],
        'same_event_horizon_contract_v2167':'30m -> 1h -> 3h -> 6h cumulative',
        'shadow_active_writers_v2163':0,'shadow_removed_active_paths_v2163':list(SHADOW_WRITERS_REMOVED),'shadow_historical_files_deleted_v2163':False,
        'historical_ledgers_rewritten':False,'probability_calibrated':False,'prediction_used_in_final_decision':True,'decision_combiner_active':True,
        'paper_prediction_recompute_calls':0,'actual_entry_changed':False,'actual_exit_changed':False,'strategy_numbers_changed':False,'auto_buy':False,
    }
    state.update({'schema':'strategy_v2_outcome_state_v2167','version':VERSION,'build':BUILD_LABEL,'updated_ts':nowv,'v2149_snapshot_count':snapshot,STATE_KEY:records,'active_generation':GENERATION,'active_model_generation_v2168':active_model or None,'prior_keys_preserved':True,'auto_buy':False})
    phase3=time.monotonic();last_state_mtime=OUTCOME_STATE.stat().st_mtime if OUTCOME_STATE.exists() else 0.0
    checkpoint_due=bool(nowv-last_state_mtime>=STATE_CHECKPOINT_SEC or finalized or link.get('actual_created_from_sealed_contract_v2165'))
    status['state_checkpoint_written_v2168']=checkpoint_due;status['state_checkpoint_interval_sec_v2168']=STATE_CHECKPOINT_SEC
    if checkpoint_due:_atomic_json(OUTCOME_STATE,state)
    _atomic_json(OUTCOME_STATUS,status)
    state_write_sec=round(time.monotonic()-phase3,4);sec=round(time.monotonic()-started,3)
    worker_status={
        'schema':'clean_review_worker_status_v2167','version':VERSION,'build':BUILD_LABEL,'state':state_name,'pid':os.getpid(),
        'active_owner':'review_worker_v2.066_canonical_identity_actual_owner','writer_count':1,'updated_ts':nowv,'updated_text':now_text(nowv),
        'last_sec':sec,'rss_mb':rss_mb(),'proc_rss_mb':rss_mb(),'phase':'current_outcome_single_runtime_owner',
        'phase_sec_v2168':{'source_read':source_read_sec,'state_load':state_load_sec,'actual_link':actual_link_sec,'state_write':state_write_sec},
        'runtime_identity_v2168':runtime,'runtime_identity_ready_v2168':bool(runtime.get('ready')),
        'model_generation_v2168':active_model or None,'state_checkpoint_written_v2168':checkpoint_due,'state_checkpoint_interval_sec_v2168':STATE_CHECKPOINT_SEC,
        'candidate_rows':current,'active_records':len(active_model_rows),'horizon_counts_v2163':horizon_counts,**link,
        'shadow_active_writers_v2163':0,'shadow_historical_files_deleted_v2163':False,'cycle_complete_v2168':True,'auto_buy':False,
    }
    _atomic_json(STATUS,worker_status);return worker_status

def ledger_once()->None:
    marker=BASE_DIR/'runtime'/'review_v2163_dense_horizon_exact_link.seeded'
    if marker.exists():return
    ts=now_ts();txt=now_text(ts)
    append_jsonl(CHANGE_LEDGER,{
        'schema':'change_verify_ledger_v870','change_id':'V2163-DENSE-HORIZON-EXACT-LINK-SHADOW-CLEANUP','issue_id':'OPEN-OUTCOME-EXACT-LINK-AND-HORIZON-GAP-2163','version':'v2163','verify_result':'LOCAL_PASS_SERVER_CHECK',
        'created_ts':ts,'created_at':txt,'writer':'review_worker_v2.061','cause':'Review created candidate rows before ENTRY_READY and did not attach the later direct decision key. Actual trades therefore failed exact linkage. The current comparison also skipped 1h and retained obsolete shadow code paths.',
        'fix':'Current-only Review owner updates direct decision aliases at ENTRY_READY, links actual trades only by direct key or its deterministic plan hash, records 30m/1h/3h/6h plus forward practical +1/+2/+3 paths, and removes all shadow writers from the active worker.',
        'not_touched':['Strategy/Trigger/Paper formulas','OPEN/CLOSED/decision/exact ledgers','sealed exits','historical shadow files','auto-buy OFF'],'auto_buy':False})
    append_jsonl(ISSUE_LEDGER,{
        'schema':'coinbot_single_work_ledger_v870','event_type':'ISSUE','issue_id':'OPEN-OUTCOME-EXACT-LINK-AND-HORIZON-GAP-2163','status':'CHECK','title':'실제매매·놓친상승 시간대별 정확비교','detail':'direct decision key exact 연결과 30분/1시간/3시간/6시간 비교. 구 Shadow writer 중단, 과거자료 보존.','version':'v2163','created_ts':ts,'created_at':txt,'auto_buy':False})
    marker.parent.mkdir(parents=True,exist_ok=True);marker.write_text(txt,encoding='utf-8')

def ledger_v2164_once()->None:
    marker=BASE_DIR/'runtime'/'review_v2164_runtime_order_review_fast.seeded'
    if marker.exists():return
    ts=now_ts();txt=now_text(ts)
    append_jsonl(CHANGE_LEDGER,{'schema':'change_verify_ledger_v870','change_id':'V2164-RUNTIME-ORDER-REVIEW-FAST-EXACT','issue_id':'MAIN-TAIL-NOT-ACTIVE-AND-REVIEW-LATENCY-2164','version':'v2164','verify_result':'LOCAL_PASS_SERVER_CHECK','created_ts':ts,'created_at':txt,'writer':'review_worker_v2.062','cause':'Review held finalized derived rows for 48h, reread large JSONL files and wrote no boot status until the first long cycle. Existing OPEN rows also needed an exact sealed-contract recovery path.','fix':'Tail-bounded JSONL reads, no shallow whole-state copy, append-ledger-before-derived-state rotation, sealed direct OPEN contract exact records, boot status before first cycle, and acquired_ts lock proof.','not_touched':['Strategy/Trigger/Paper/exit formulas','OPEN/CLOSED/decision/exact ledgers','historical outcome/Shadow files','auto-buy OFF'],'auto_buy':False})
    append_jsonl(ISSUE_LEDGER,{'schema':'coinbot_single_work_ledger_v870','event_type':'ISSUE','issue_id':'MAIN-TAIL-NOT-ACTIVE-AND-REVIEW-LATENCY-2164','status':'CHECK','title':'v2163 화면 미활성·Review 적용 지연','detail':'Main binding order, actual OPEN exact, Review cycle/RSS and Guard boot proof repaired together.','version':'v2164','created_ts':ts,'created_at':txt,'auto_buy':False})
    marker.parent.mkdir(parents=True,exist_ok=True);marker.write_text(txt,encoding='utf-8')

def ledger_v2165_once()->None:
    marker=BASE_DIR/'runtime'/'review_v2165_exact_book_market_compare.seeded'
    if marker.exists():return
    ts=now_ts();txt=now_text(ts)
    append_jsonl(CHANGE_LEDGER,{'schema':'change_verify_ledger_v870','change_id':'V2165-EXACT-BOOK-MARKET-COMPARE-QUALITY-READY','issue_id':'REVIEW-WRONG-ACTUAL-BOOK-AND-MARKET-TOP-BLIND-2165','version':'v2165','verify_result':'LOCAL_PASS_SERVER_CHECK','created_ts':ts,'created_at':txt,'writer':'review_worker_v2.063','cause':'Review read legacy paper_bot_open/closed instead of the active v2149 Paper exact books, so actual key showed 0/0 while Main listed current exact OPEN. The comparison also had no whole-market 15m/30m/1h reference.','fix':'Read paper_v2_exact_open/closed_v2135 only, exact-link their sealed direct contracts, update actual paths from the exact book, expose phase timings, and leave market-top rendering to the existing Main /trade_review using scanner+candle owner data.','not_touched':['Strategy/Trigger/Paper/exit formulas','OPEN/CLOSED/decision/exact ledgers','historical outcome/Shadow files','auto-buy OFF'],'auto_buy':False})
    append_jsonl(ISSUE_LEDGER,{'schema':'coinbot_single_work_ledger_v870','event_type':'ISSUE','issue_id':'REVIEW-WRONG-ACTUAL-BOOK-AND-MARKET-TOP-BLIND-2165','status':'CHECK','title':'실제매매 exact 장부·시장상승 TOP 대조 수리','detail':'Review actual owner를 현재 Paper exact 장부로 바로잡고 15m/30m/1h 전체시장 대조를 기존 /trade_review에 연결한다.','version':'v2165','created_ts':ts,'created_at':txt,'auto_buy':False})
    marker.parent.mkdir(parents=True,exist_ok=True);marker.write_text(txt,encoding='utf-8')


def ledger_v2166_once()->None:
    marker=BASE_DIR/'runtime'/'review_v2166_dense_horizon_owner.seeded'
    if marker.exists():return
    ts=now_ts();txt=now_text(ts)
    append_jsonl(CHANGE_LEDGER,{'schema':'change_verify_ledger_v870','change_id':'V2166-DENSE-HORIZON-OWNER-FAST','issue_id':'LATE-CANDIDATE-ENTRY-AND-DENSE-COMPARE-2166','version':'v2166','verify_result':'LOCAL_PASS_SERVER_CHECK','created_ts':ts,'created_at':txt,'writer':'review_worker_v2.064','cause':'The same event could show a 3h sample while 30m/1h were absent because sampling accepted only a narrow on-time cycle window. Full active state was also atomically rewritten every cycle.','fix':'For new FULL_INPUT_V2166 events, fill every elapsed horizon cumulatively on the first cycle after its boundary, expose sample lateness, checkpoint the same derived state at a bounded 45s cadence, and keep final append-only outcomes unchanged.','not_touched':['Strategy/Trigger/Paper/exit formulas','OPEN/CLOSED/decision/exact ledgers','historical outcome/Shadow files','auto-buy OFF'],'auto_buy':False})
    append_jsonl(ISSUE_LEDGER,{'schema':'coinbot_single_work_ledger_v870','event_type':'ISSUE','issue_id':'LATE-CANDIDATE-ENTRY-AND-DENSE-COMPARE-2166','status':'CHECK','title':'시간대 비교 동일사건 누락·Review 쓰기지연 수리','detail':'같은 신규 사건의 30분·1시간·3시간·6시간을 누적 연결하고 상태 전체쓰기 빈도를 줄인다.','version':'v2166','created_ts':ts,'created_at':txt,'auto_buy':False})
    marker.parent.mkdir(parents=True,exist_ok=True);marker.write_text(txt,encoding='utf-8')

def ledger_v2167_once()->None:
    marker=BASE_DIR/'runtime'/'review_v2167_single_runtime_owner.seeded'
    if marker.exists():return
    ts=now_ts();txt=now_text(ts)
    append_jsonl(CHANGE_LEDGER,{'schema':'change_verify_ledger_v870','change_id':'V2167-REVIEW-DYNAMIC-RUNTIME-OWNER','issue_id':'STRATEGY-RUNTIME-GENERATION-SPLIT-2167','version':'v2167','verify_result':'LOCAL_PASS_SERVER_CHECK','created_ts':ts,'created_at':txt,'writer':'review_worker_v2.065','cause':'Review hard-coded FULL_INPUT_V2166 while live Strategy remained FULL_INPUT_V2161, producing a zero-sample board that looked like missing data.','fix':'Review derives the active model only from the exact Strategy runtime identity and candidate contract. Mismatch is CHECK, never a silently empty model cohort. Historical model rows remain preserved and separate.','not_touched':['Strategy formulas','Paper/exit','historical outcome and trade ledgers','auto-buy OFF'],'auto_buy':False})
    append_jsonl(ISSUE_LEDGER,{'schema':'coinbot_single_work_ledger_v870','event_type':'ISSUE','issue_id':'STRATEGY-RUNTIME-GENERATION-SPLIT-2167','status':'CHECK','title':'Review 고정 모델명으로 표본 0 오판','detail':'현재 Strategy 실행신분을 직접 읽고 같은 모델 후보만 비교한다.','version':'v2167','created_ts':ts,'created_at':txt,'auto_buy':False})
    marker.parent.mkdir(parents=True,exist_ok=True);marker.write_text(txt,encoding='utf-8')


def acquire_lock()->None:
    global _LOCK_FH
    LOCK_PATH.parent.mkdir(parents=True,exist_ok=True)
    fh=LOCK_PATH.open('a+',encoding='utf-8')
    try:fcntl.flock(fh.fileno(),fcntl.LOCK_EX|fcntl.LOCK_NB)
    except BlockingIOError:raise SystemExit(0)
    fh.seek(0);fh.truncate();fh.write(json.dumps({'pid':os.getpid(),'version':VERSION,'build':BUILD_LABEL,'ts':now_ts(),'acquired_ts':now_ts()}));fh.flush()
    _LOCK_FH=fh
    atexit.register(lambda: fh.close() if not fh.closed else None)

def main()->None:
    acquire_lock();ledger_once();ledger_v2164_once();ledger_v2165_once();ledger_v2166_once();ledger_v2167_once()
    boot_ts=now_ts()
    _atomic_json(STATUS,{'schema':'clean_review_worker_status_v2165','version':VERSION,'build':BUILD_LABEL,'state':'ACTIVE','pid':os.getpid(),'active_owner':'review_worker_v2.066_canonical_identity_actual_owner','writer_count':1,'updated_ts':boot_ts,'updated_text':now_text(boot_ts),'phase':'BOOTING_FIRST_CYCLE_V2165','cycle_complete_v2164':False,'shadow_active_writers_v2163':0,'shadow_historical_files_deleted_v2163':False,'auto_buy':False})
    while True:
        try:run_once()
        except Exception as exc:
            append_error('run_once',exc)
            _atomic_json(STATUS,{'schema':'clean_review_worker_status_v2163','version':VERSION,'build':BUILD_LABEL,'state':'ERROR','pid':os.getpid(),'updated_ts':now_ts(),'updated_text':now_text(),'error':f'{type(exc).__name__}: {exc}','shadow_active_writers_v2163':0,'auto_buy':False})
        time.sleep(INTERVAL_SEC)


# =============================================================================
# v2168 canonical identity and exact-actual owner.
# Generation-wide exact counts and active-model exact counts are both explicit;
# no board may label one as the other.
# =============================================================================
VERSION='review_worker_v2.066'
BUILD_LABEL='v2168_single_identity_actual_owner_2026-07-22'
IDENTITY_PATH=BASE_DIR/'runtime'/'strategy_runtime_identity_current.json'
ACTUAL_STATUS_V2168=BASE_DIR/'strategy_v2_actual_exact_status_v2168.json'


def _v2168_identity_from_file(source_rows):
    ident=load_json(IDENTITY_PATH,{}) or {};st=load_json(STRATEGY_STATUS,{}) or {};ds=load_json(STRATEGY_DECISION_STATUS,{}) or {}
    signature=str(ident.get('runtime_signature') or '');candidate_sigs=Counter();candidate_models=Counter();candidate_cycles=Counter()
    for row in source_rows:
        if not isinstance(row,dict):continue
        c=contract_of(row)
        sig=str(c.get('runtime_signature_v2168') or row.get('runtime_signature_v2168') or '')
        if sig:candidate_sigs[sig]+=1
        m=actual_model(row,c)
        if m:candidate_models[m]+=1
        cyc=str(row.get('candidate_pipeline_cycle_id_v1150') or '')
        if cyc:candidate_cycles[cyc]+=1
    hold=load_json(BASE_DIR/'paper_s1_hold_cache.json',{}) or {}
    ready=bool(ident.get('ready') is True and ident.get('worker_version')=='strategy_worker_v2.062' and ident.get('worker_build')=='v2168_single_identity_event_spine_2026-07-22' and ident.get('core_version')=='strategy_v2_core_v2168' and ident.get('model_generation')=='FULL_INPUT_V2171' and signature and set(candidate_sigs or {signature:1})=={signature} and str(hold.get('runtime_signature_v2168') or '')==signature and str(st.get('runtime_signature_v2168') or (st.get('runtime_identity_v2168') or {}).get('runtime_signature') or '')==signature)
    return {'schema':'review_strategy_runtime_identity_v2168','ready':ready,**{k:ident.get(k) for k in ident},
            'candidate_signature_counts':dict(candidate_sigs),'candidate_model_counts':dict(candidate_models),'candidate_cycle_counts':dict(candidate_cycles),
            'hold_signature':hold.get('runtime_signature_v2168'),'status_signature':st.get('runtime_signature_v2168'),
            'source':'runtime/strategy_runtime_identity_current.json only; status/candidate/hold are equality proofs','auto_buy':False}


def attach_actual_trades_v2168(records,nowv,active_model):
    actual_rows=[(x,'OPEN') for x in iter_open_rows()]+[(x,'CLOSED') for x in read_jsonl(CLOSED_PATH,5000)]
    by_decision={};by_plan={}
    for rec in records.values():
        if not isinstance(rec,dict) or rec.get('superseded_duplicate_v2154'):continue
        for k in rec.get('decision_keys_exact_v2163') or []:by_decision[str(k)]=rec
        p=str(rec.get('plan_key') or '')
        if p:by_plan.setdefault(p,[]).append(rec)
    gen_total=gen_linked=gen_missing=0;active_total=active_linked=active_missing=0;created=0;open_total=closed_total=0
    model_totals=Counter();model_linked=Counter();missing_reasons=Counter()
    for row,kind in actual_rows:
        if not isinstance(row,dict):continue
        c=open_contract(row)
        if actual_generation(row,c)!=GENERATION:continue
        gen_total+=1;open_total+=int(kind=='OPEN');closed_total+=int(kind=='CLOSED')
        model=actual_model(row,c) or 'SOURCE_MISSING';model_totals[model]+=1
        is_active=model==active_model
        active_total+=int(is_active)
        keys=exact_decision_keys(row,c)
        if not keys:
            gen_missing+=1;active_missing+=int(is_active);missing_reasons['DIRECT_DECISION_KEY_MISSING']+=1;continue
        rec=None;source='DIRECT_DECISION_KEY'
        for k in keys:
            if k in by_decision:rec=by_decision[k];break
        if rec is None:
            plans={str(c.get('plan_key') or ''),str(c.get('candidate_plan_key') or '')};plans.update(plan_from_decision(k) for k in keys);plans.discard('')
            matches=[]
            for p in plans:matches.extend(by_plan.get(p,[]))
            uniq={id(x):x for x in matches}
            if len(uniq)==1:rec=next(iter(uniq.values()));source='SEALED_PLAN_KEY_EXACT'
        if rec is None and c:
            entry=num(row.get('entry_price') or row.get('open_price') or ((c.get('structure') or {}).get('reference_entry') if isinstance(c.get('structure'),dict) else None))
            if entry and entry>0:
                event='actual:'+hashlib.sha256(keys[0].encode()).hexdigest()[:24];rec=create_record(row,c,entry,nowv,event)
                opened=num(row.get('paper_v2_exact_opened_ts') or row.get('opened_at') or row.get('open_ts') or row.get('entry_ts'))
                rec['start_ts']=opened or nowv;rec['start_text']=now_text(rec['start_ts']);rec['reference_entry']=entry
                rec['prediction_model_generation']=model;rec['actual_record_created_from_sealed_contract_v2168']=True
                records[event]=rec;created+=1;source='SEALED_EXACT_BOOK_CONTRACT'
                p=str(c.get('plan_key') or '')
                if p:rec['plan_key']=p;by_plan.setdefault(p,[]).append(rec)
        if rec is None:
            gen_missing+=1;active_missing+=int(is_active);missing_reasons['NO_EXACT_RECORD_MATCH']+=1;continue
        arr=list(rec.get('decision_keys_exact_v2163') or [])
        for k in keys:
            if k not in arr:arr.append(k)
            by_decision[k]=rec
        rec['decision_keys_exact_v2163']=arr;rec['decision_key']=arr[0];rec['actual_trade_exact_v2163']=True
        rec['actual_link_source_v2168']=source;rec['actual_trade_open_v2164']=kind=='OPEN';rec['actual_trade_closed_v2164']=kind=='CLOSED'
        rec['actual_model_generation_v2168']=model
        live=row_price(row)
        if live and live>0:update_path(rec,live,nowv)
        gen_linked+=1;model_linked[model]+=1
        if is_active:active_linked+=1
    status={'schema':'strategy_v2_actual_exact_status_v2168','updated_ts':nowv,'updated_text':now_text(nowv),'generation':GENERATION,'active_model':active_model,
            'generation_total':gen_total,'generation_linked':gen_linked,'generation_missing':gen_missing,
            'active_model_total':active_total,'active_model_linked':active_linked,'active_model_missing':active_missing,
            'open_total':open_total,'closed_total':closed_total,'model_totals':dict(model_totals),'model_linked':dict(model_linked),
            'missing_reason_counts':dict(missing_reasons),'created_from_sealed_contract':created,
            'policy':'same generation exact books; direct decision key or deterministic sealed plan only; no ticker/time proximity','auto_buy':False}
    _atomic_json(ACTUAL_STATUS_V2168,status)
    return {'actual_exact_total':gen_total,'actual_exact_linked':gen_linked,'actual_exact_missing':gen_missing,
            'actual_exact_generation_total_v2168':gen_total,'actual_exact_generation_linked_v2168':gen_linked,'actual_exact_generation_missing_v2168':gen_missing,
            'actual_exact_active_model_total_v2168':active_total,'actual_exact_active_model_linked_v2168':active_linked,'actual_exact_active_model_missing_v2168':active_missing,
            'actual_exact_open_total_v2165':open_total,'actual_exact_closed_total_v2165':closed_total,'actual_created_from_sealed_contract_v2165':created,
            'actual_exact_source_v2165':'paper_v2_exact_open/closed_v2135 canonical v2168 scope'}


# Replace only the dynamic owner and actual linker used by run_once.
_runtime_identity_from_strategy=_v2168_identity_from_file
attach_actual_trades=attach_actual_trades_v2168


def ledger_v2168_once():
    marker=BASE_DIR/'runtime'/'review_v2168_single_identity_actual.seeded'
    if marker.exists():return
    ts=now_ts();txt=now_text(ts)
    append_jsonl(CHANGE_LEDGER,{'schema':'change_verify_ledger_v870','change_id':'V2168-REVIEW-CANONICAL-IDENTITY-ACTUAL','issue_id':'CURRENT-IDENTITY-ACTUAL-TIMING-CANDIDATE-GAP-2168','version':'v2168','verify_result':'LOCAL_PASS_SERVER_CHECK','created_ts':ts,'created_at':txt,'writer':'review_worker_v2.066','cause':'The board counted actual records once from outcome grouping and once from active-model exact books, so 2 and 0/0 could coexist. Current identity also remained duplicated in status readers.','fix':'Read one identity file and publish explicit generation-wide and active-model exact scopes from the same Paper exact books. Derived state checkpoints no longer rewrite on every new candidate; final append ledger remains first.','not_touched':['strategy thresholds','Paper/exit','historical ledgers','auto-buy OFF'],'auto_buy':False})
    append_jsonl(ISSUE_LEDGER,{'schema':'coinbot_single_work_ledger_v870','event_type':'ISSUE','issue_id':'CURRENT-IDENTITY-ACTUAL-TIMING-CANDIDATE-GAP-2168','status':'CHECK','title':'actual exact 2와 0/0 동시표시','detail':'세대 전체 exact와 현재모델 exact를 같은 장부에서 명시적으로 분리한다.','version':'v2168','created_ts':ts,'created_at':txt,'auto_buy':False})
    marker.parent.mkdir(parents=True,exist_ok=True);marker.write_text(txt,encoding='utf-8')
try:ledger_v2168_once()
except Exception:pass



# =============================================================================
# v2169 canonical candidate continuity.
# Rows without finished invalid/T1 geometry receive a review-only stable key;
# they remain SOURCE_WAIT/STRUCTURE_WAIT and are never promoted or linked by
# ticker/time proximity. This makes source rows == current tracked rows.
# =============================================================================
VERSION='review_worker_v2.067'
BUILD_LABEL='v2169_full_candidate_continuity_2026-07-22'
_V2169_BASE_STABLE_KEY=stable_key
_V2169_BASE_ROW_PRICE=row_price
_V2169_SCANNER_CACHE={'ts':0.0,'rows':{}}


def stable_key(row,c):  # type: ignore[override]
    key=_V2169_BASE_STABLE_KEY(row,c)
    if key:return key
    t=ticker(row.get('ticker') or c.get('ticker'))
    if not t:return ''
    model=actual_model(row,c) or 'SOURCE_MISSING'
    return f'{GENERATION}|{t}|continuity:{model}'


def _v2169_scanner_prices():
    nowv=now_ts()
    if nowv-float(_V2169_SCANNER_CACHE.get('ts') or 0.0)<2.0:return _V2169_SCANNER_CACHE.get('rows') or {}
    obj=load_json(BASE_DIR/'clean_scanner_market_cache.json',{}) or {};raw=obj.get('rows') if isinstance(obj.get('rows'),list) else obj.get('items') if isinstance(obj.get('items'),list) else []
    rows={}
    for r in raw:
        if not isinstance(r,dict):continue
        t=ticker(r.get('ticker') or r.get('market') or r.get('symbol'));p=num(r.get('current_price') or r.get('price') or r.get('trade_price'))
        if t and p and p>0:rows[t]=p
    _V2169_SCANNER_CACHE.update({'ts':nowv,'rows':rows});return rows


def row_price(row):  # type: ignore[override]
    p=_V2169_BASE_ROW_PRICE(row)
    if p:return p
    return _v2169_scanner_prices().get(ticker(row.get('ticker') or row.get('market') or row.get('symbol')))


def _v2169_identity(source_rows):
    ident=load_json(IDENTITY_PATH,{}) or {};st=load_json(STRATEGY_STATUS,{}) or {};hold=load_json(BASE_DIR/'paper_s1_hold_cache.json',{}) or {}
    sig=str(ident.get('runtime_signature') or '');candidate_sigs=Counter();models=Counter()
    for row in source_rows:
        if not isinstance(row,dict):continue
        c=contract_of(row);rs=str(c.get('runtime_signature_v2169') or c.get('runtime_signature_v2168') or row.get('runtime_signature_v2169') or row.get('runtime_signature_v2168') or '')
        if rs:candidate_sigs[rs]+=1
        m=actual_model(row,c)
        if m:models[m]+=1
    hold_sig=str(hold.get('runtime_signature_v2169') or hold.get('runtime_signature_v2168') or '')
    status_sig=str(st.get('runtime_signature_v2169') or st.get('runtime_signature_v2168') or (st.get('runtime_identity_v2169') or st.get('runtime_identity_v2168') or {}).get('runtime_signature') or '')
    ready=bool(ident.get('ready') is True and ident.get('worker_version')=='strategy_worker_v2.063' and ident.get('worker_build')=='v2169_candidate_continuity_fresh_trigger_handoff_2026-07-22' and ident.get('core_version')=='strategy_v2_core_v2168' and ident.get('model_generation')=='FULL_INPUT_V2171' and sig and set(candidate_sigs or {sig:1})=={sig} and hold_sig==sig and status_sig==sig)
    return {'schema':'review_strategy_runtime_identity_v2169','ready':ready,**{k:ident.get(k) for k in ident},
            'candidate_signature_counts':dict(candidate_sigs),'candidate_model_counts':dict(models),'hold_signature':hold_sig,'status_signature':status_sig,
            'source':'runtime identity + exact equality proofs','auto_buy':False}

_runtime_identity_from_strategy=_v2169_identity
_V2169_BASE_RUN=run_once

def run_once__v2169():
    result=_V2169_BASE_RUN();source=[r for r in read_jsonl(PAPER_LATEST,1400) if str(r.get('strategy_generation_v2149') or '')==GENERATION]
    unique={ticker(r.get('ticker') or r.get('market') or r.get('symbol')) for r in source if isinstance(r,dict)};unique.discard('')
    keyed=sum(1 for r in source if isinstance(r,dict) and stable_key(r,contract_of(r)))
    priced=sum(1 for r in source if isinstance(r,dict) and row_price(r))
    status=load_json(STATUS,{}) or {};outcome=load_json(OUTCOME_STATUS,{}) or {};ident=_v2169_identity(source)
    status.update({'version':VERSION,'build':BUILD_LABEL,'runtime_identity_ready_v2169':bool(ident.get('ready')),'runtime_identity_ready_v2168':bool(ident.get('ready')),
                   'model_generation_v2169':ident.get('model_generation'),'model_generation_v2168':ident.get('model_generation'),
                   'candidate_source_rows_v2169':len(source),'candidate_unique_tickers_v2169':len(unique),'candidate_stable_keys_v2169':keyed,
                   'candidate_prices_v2169':priced,'candidate_continuity_pass_v2169':bool(len(source)==len(unique)==keyed and len(source)>0),
                   'candidate_geometry_not_required_for_tracking_v2169':True,'auto_buy':False})
    _atomic_json(STATUS,status)
    outcome.update({'review_candidate_source_rows_v2169':len(source),'review_candidate_unique_tickers_v2169':len(unique),
                    'review_candidate_stable_keys_v2169':keyed,'review_candidate_continuity_pass_v2169':bool(len(source)==len(unique)==keyed and len(source)>0),
                    'runtime_identity_ready_v2169':bool(ident.get('ready')),'model_generation_v2169':ident.get('model_generation'),'auto_buy':False})
    _atomic_json(OUTCOME_STATUS,outcome)
    return result
run_once=run_once__v2169
run_once.__name__='run_once';run_once.__qualname__='run_once'


def ledger_v2169_once():
    marker=BASE_DIR/'runtime'/'review_v2169_full_candidate_continuity.seeded'
    if marker.exists():return
    ts=now_ts();txt=now_text(ts)
    append_jsonl(CHANGE_LEDGER,{'schema':'change_verify_ledger_v870','change_id':'V2169-REVIEW-FULL-CANDIDATE-CONTINUITY','issue_id':'CANDIDATE-462-AND-TRIGGER-LATENCY-2169','version':'v2169','verify_result':'LOCAL_PASS_SERVER_CHECK','created_ts':ts,'created_at':txt,'writer':'review_worker_v2.067','cause':'Review stable keys required completed invalid/T1 geometry, so only 437 of 462 canonical rows were tracked and market winners appeared candidate-missing.','fix':'Use exact structure key when available and a review-only ticker+model continuity key for incomplete geometry. This changes no Strategy/Paper decision and uses no ticker/time actual linkage.','not_touched':['candidate grade','actual exact key rules','Paper/exit','historical ledgers','auto-buy OFF'],'auto_buy':False})
    marker.parent.mkdir(parents=True,exist_ok=True);marker.write_text(txt,encoding='utf-8')
try:ledger_v2169_once()
except Exception:pass


# =============================================================================
# v2170 exact current-signature/cycle Review owner.
# The candidate JSONL is append-only, so current analysis must not accept an
# unsigned row or an older cycle merely because it shares the strategy generation.
# =============================================================================
VERSION='review_worker_v2.069'
BUILD_LABEL='v2170_exact_current_signature_cycle_review_2026-07-23'
MAIN_DEPLOY_VERSION=BUILD_LABEL
V2170_EXPECTED_WORKER='strategy_worker_v2.065'
V2170_EXPECTED_BUILD='v2171_snapshot_receipt_rollback_history_2026-07-23'
V2170_EXPECTED_CORE='strategy_v2_core_v2171'
V2170_EXPECTED_MODEL='FULL_INPUT_V2171'


def _v2170_tail_rows(path,limit=7000):
    try:
        with Path(path).open('rb') as f:
            size=Path(path).stat().st_size;f.seek(max(0,size-128*1024*1024));data=f.read().decode('utf-8',errors='ignore')
        lines=data.splitlines()
        if size>128*1024*1024 and lines:lines=lines[1:]
    except Exception:return []
    out=[]
    for line in lines[-max(1,int(limit)):]:
        try:r=json.loads(line)
        except Exception:continue
        if isinstance(r,dict):out.append(r)
    return out


def _v2170_row_sig(row):
    c=contract_of(row)
    return str(c.get('runtime_signature_v2170') or c.get('runtime_signature_v2169') or c.get('runtime_signature_v2168') or row.get('runtime_signature_v2170') or row.get('runtime_signature_v2169') or row.get('runtime_signature_v2168') or '')


def _v2170_row_cycle(row):
    c=contract_of(row)
    return str(row.get('candidate_pipeline_cycle_id_v1150') or row.get('cycle_id') or c.get('cycle_id') or '')


def _v2170_row_ts(row):
    c=contract_of(row)
    for v in (row.get('candidate_pipeline_cycle_started_ts_v1152'),c.get('evaluated_ts'),row.get('updated_ts'),row.get('source_ts')):
        try:
            if v not in (None,''):return float(v)
        except Exception:pass
    return 0.0


def _v2170_current_rows():
    ident=load_json(IDENTITY_PATH,{}) or {};sig=str(ident.get('runtime_signature') or '');cycle=str(ident.get('cycle_id') or '')
    groups={};rejected=Counter()
    for row in _v2170_tail_rows(PAPER_LATEST,7000):
        if str(row.get('strategy_generation_v2149') or '')!=GENERATION:continue
        rs=_v2170_row_sig(row);rc=_v2170_row_cycle(row)
        if not rs or rs!=sig:rejected['signature']+=1;continue
        if cycle and rc!=cycle:rejected['cycle']+=1;continue
        if not rc:rejected['cycle_missing']+=1;continue
        groups.setdefault(rc,[]).append(row)
    if not groups:return [],dict(rejected)
    selected=cycle if cycle in groups else max(groups,key=lambda k:max([_v2170_row_ts(x) for x in groups[k]] or [0.0]))
    by={}
    for row in groups[selected]:
        t=ticker(row.get('ticker') or row.get('market') or row.get('symbol'))
        if t and (t not in by or _v2170_row_ts(row)>=_v2170_row_ts(by[t])):by[t]=row
    return list(by.values()),dict(rejected)


def _v2170_identity(source_rows):
    ident=load_json(IDENTITY_PATH,{}) or {};st=load_json(STRATEGY_STATUS,{}) or {};hold=load_json(BASE_DIR/'paper_s1_hold_cache.json',{}) or {}
    sig=str(ident.get('runtime_signature') or '');cycle=str(ident.get('cycle_id') or '')
    candidate_sigs=Counter(_v2170_row_sig(r) for r in source_rows if _v2170_row_sig(r));candidate_cycles=Counter(_v2170_row_cycle(r) for r in source_rows if _v2170_row_cycle(r));models=Counter(actual_model(r,contract_of(r)) for r in source_rows if actual_model(r,contract_of(r)))
    hold_sig=str(hold.get('runtime_signature_v2170') or hold.get('runtime_signature_v2169') or hold.get('runtime_signature_v2168') or '')
    hold_commit=str(hold.get('candidate_commit_id') or '');status_sig=str(st.get('runtime_signature_v2170') or st.get('runtime_signature_v2169') or (st.get('runtime_identity_v2170') or st.get('runtime_identity_v2169') or {}).get('runtime_signature') or '')
    ready=bool(ident.get('ready') is True and ident.get('worker_version')==V2170_EXPECTED_WORKER and ident.get('worker_build')==V2170_EXPECTED_BUILD and ident.get('core_version')==V2170_EXPECTED_CORE and ident.get('model_generation')==V2170_EXPECTED_MODEL and sig and set(candidate_sigs)=={sig} and (not cycle or set(candidate_cycles)=={cycle}) and set(models)=={V2170_EXPECTED_MODEL} and hold_sig==sig and status_sig==sig and hold_commit==str(ident.get('candidate_commit_id') or ''))
    return {'schema':'review_strategy_runtime_identity_v2170','ready':ready,**{k:ident.get(k) for k in ident},'candidate_signature_counts':dict(candidate_sigs),'candidate_cycle_counts':dict(candidate_cycles),'candidate_model_counts':dict(models),'hold_signature':hold_sig,'hold_commit':hold_commit,'status_signature':status_sig,'source':'exact current runtime signature + exact current candidate cycle only','auto_buy':False}

_runtime_identity_from_strategy=_v2170_identity
_V2170_BASE_READ_JSONL=read_jsonl
_V2170_BASE_RUN=run_once


def run_once__v2170():
    current,rejected=_v2170_current_rows()
    def scoped_read(path,max_lines=1000):
        try:
            if Path(path).resolve()==Path(PAPER_LATEST).resolve():return [dict(x) for x in current]
        except Exception:pass
        return _V2170_BASE_READ_JSONL(path,max_lines)
    globals()['read_jsonl']=scoped_read
    try:result=_V2170_BASE_RUN()
    finally:globals()['read_jsonl']=_V2170_BASE_READ_JSONL
    result=dict(result) if isinstance(result,dict) else {}
    ident=_v2170_identity(current);unique={ticker(r.get('ticker') or r.get('market') or r.get('symbol')) for r in current if isinstance(r,dict)};unique.discard('')
    keyed=sum(1 for r in current if stable_key(r,contract_of(r)));priced=sum(1 for r in current if row_price(r))
    quality_wait=sum(1 for r in current if str(contract_of(r).get('state') or '')=='QUALITY_STRUCTURE_WAIT')
    status=load_json(STATUS,{}) or {};outcome=load_json(OUTCOME_STATUS,{}) or {}
    fields={'version':VERSION,'build':BUILD_LABEL,'runtime_identity_v2170':ident,'runtime_identity_ready_v2170':bool(ident.get('ready')),'runtime_identity_ready_v2169':bool(ident.get('ready')),
            'model_generation_v2170':ident.get('model_generation'),'candidate_source_rows_v2170':len(current),'candidate_unique_tickers_v2170':len(unique),'candidate_stable_keys_v2170':keyed,'candidate_prices_v2170':priced,
            'candidate_current_signature_cycle_pass_v2170':bool(ident.get('ready') and len(current)==len(unique)==keyed and len(current)>0),'rejected_old_or_unsigned_rows_v2170':rejected,
            'quality_structure_min_v2170':0.341,'quality_structure_wait_count_v2170':quality_wait,'historical_ledgers_rewritten':False,'auto_buy':False}
    status.update(fields);_atomic_json(STATUS,status)
    outcome.update({'review_candidate_source_rows_v2170':len(current),'review_candidate_unique_tickers_v2170':len(unique),'review_candidate_stable_keys_v2170':keyed,
                    'review_candidate_current_signature_cycle_pass_v2170':fields['candidate_current_signature_cycle_pass_v2170'],'runtime_identity_ready_v2170':bool(ident.get('ready')),
                    'model_generation_v2170':ident.get('model_generation'),'quality_structure_wait_count_v2170':quality_wait,'auto_buy':False});_atomic_json(OUTCOME_STATUS,outcome)
    return result

run_once=run_once__v2170
run_once.__name__='run_once';run_once.__qualname__='run_once'


def _v2170_ledger_once():
    marker=BASE_DIR/'runtime'/'review_v2170_current_signature_cycle.seeded'
    if marker.exists():return
    ts=now_ts();txt=now_text(ts)
    try:
        append_jsonl(CHANGE_LEDGER,{'schema':'change_verify_ledger_v870','change_id':'V2170-REVIEW-CURRENT-SIGNATURE-CYCLE','issue_id':'CURRENT-ROW-IDENTITY-PAPER-ZERO-S1-QUALITY-2170','version':'v2170','verify_result':'LOCAL_PASS_SERVER_CHECK','created_ts':ts,'created_at':txt,'writer':'review_worker_v2.068','cause':'The append-only candidate tail accepted unsigned and older-cycle rows, causing current market winners to be labeled runtime identity mismatch.','fix':'Scope every Review read to the exact active runtime signature and candidate cycle, deduplicate by ticker inside that cycle, and expose rejected old/unsigned counts.','not_touched':['actual exact key rules','Strategy/Paper decisions','historical outcome ledgers','auto-buy OFF'],'auto_buy':False})
        marker.parent.mkdir(parents=True,exist_ok=True);marker.write_text(txt,encoding='utf-8')
    except Exception:pass
try:_v2170_ledger_once()
except Exception:pass

# =============================================================================
# v2171: consume Strategy's current snapshot directly. No second current-row
# filter is allowed in Review.
# =============================================================================
VERSION='review_worker_v2.069'
BUILD_LABEL='v2171_current_snapshot_outcome_2026-07-23'
MAIN_DEPLOY_VERSION=BUILD_LABEL
V2171_SNAPSHOT=BASE_DIR/'runtime'/'current_candidate_snapshot_v2171.json'


def _v2171_snapshot():
    obj=load_json(V2171_SNAPSHOT,{}) or {};rows=obj.get('rows') if isinstance(obj.get('rows'),list) else []
    return obj,[dict(r) for r in rows if isinstance(r,dict)]


def _v2170_current_rows():  # type: ignore[override]
    snap,rows=_v2171_snapshot()
    return rows,{} if rows else {'snapshot_missing':1}


def _v2170_identity(source_rows):  # type: ignore[override]
    snap,_=_v2171_snapshot();ident=snap.get('runtime_identity') if isinstance(snap.get('runtime_identity'),dict) else load_json(IDENTITY_PATH,{}) or {}
    hold=load_json(BASE_DIR/'paper_s1_hold_cache.json',{}) or {};sig=str(snap.get('runtime_signature') or ident.get('runtime_signature') or '')
    cycle=str(snap.get('cycle_id') or '');commit=str(snap.get('candidate_commit_id') or '')
    ready=bool(snap.get('row_count') and len(source_rows)==int(snap.get('row_count') or 0)==int(snap.get('unique_tickers') or 0)
               and ident.get('worker_version')=='strategy_worker_v2.065' and ident.get('core_version')=='strategy_v2_core_v2171'
               and ident.get('model_generation')=='FULL_INPUT_V2171' and sig and str(hold.get('runtime_signature_v2171') or '')==sig
               and str(hold.get('candidate_commit_id') or '')==commit and str(hold.get('cycle_id') or '')==cycle)
    return {'schema':'review_strategy_runtime_identity_v2171','ready':ready,**{k:ident.get(k) for k in ident},
            'runtime_signature':sig,'cycle_id':cycle,'candidate_commit_id':commit,'candidate_snapshot_id_v2171':snap.get('snapshot_id'),
            'source':'Strategy current_candidate_snapshot_v2171.json; no Review re-filter','auto_buy':False}


_V2171_BASE_RUN=run_once

def run_once__v2171():
    result=_V2171_BASE_RUN();result=dict(result) if isinstance(result,dict) else {}
    snap,rows=_v2171_snapshot();unique={ticker(r.get('ticker') or r.get('market') or r.get('symbol')) for r in rows};unique.discard('')
    identity=_v2170_identity(rows);status=load_json(STATUS,{}) or {};outcome=load_json(OUTCOME_STATUS,{}) or {}
    fields={'version':VERSION,'build':BUILD_LABEL,'runtime_identity_v2171':identity,'runtime_identity_ready_v2171':bool(identity.get('ready')),
            'candidate_snapshot_id_v2171':snap.get('snapshot_id'),'candidate_source_rows_v2171':len(rows),'candidate_unique_tickers_v2171':len(unique),
            'candidate_snapshot_exact_v2171':bool(identity.get('ready') and len(rows)==len(unique)==int(snap.get('row_count') or 0)),
            'quality_structure_gate_active_v2171':False,'v2170_failed_gate_rolled_back_v2171':True,
            'quality_structure_wait_count_v2171':sum(1 for r in rows if str(contract_of(r).get('state') or '')=='QUALITY_STRUCTURE_WAIT'),
            'historical_ledgers_rewritten':False,'auto_buy':False}
    status.update(fields);_atomic_json(STATUS,status)
    outcome.update({'review_candidate_source_rows_v2171':len(rows),'review_candidate_unique_tickers_v2171':len(unique),
                    'review_candidate_snapshot_exact_v2171':fields['candidate_snapshot_exact_v2171'],'runtime_identity_ready_v2171':bool(identity.get('ready')),
                    'model_generation_v2171':'FULL_INPUT_V2171','quality_structure_gate_active_v2171':False,'auto_buy':False});_atomic_json(OUTCOME_STATUS,outcome)
    result.update(fields)
    return result

run_once=run_once__v2171
run_once.__name__='run_once';run_once.__qualname__='run_once'


def _v2171_ledger_once():
    marker=BASE_DIR/'runtime'/'review_v2171_snapshot_owner.seeded'
    if marker.exists():return
    ts=now_ts();txt=now_text(ts)
    try:
        append_jsonl(CHANGE_LEDGER,{'schema':'change_verify_ledger_v870','change_id':'V2171-REVIEW-CURRENT-SNAPSHOT','issue_id':'V2170-CANDIDATE-REVIEW-PAPER-QUALITY-FAIL','version':'v2171','verify_result':'LOCAL_PASS_SERVER_CHECK','created_ts':ts,'created_at':txt,'writer':VERSION,'cause':'Review independently re-filtered the candidate JSONL and reduced a valid Strategy snapshot to zero.','fix':'Read the exact Strategy current snapshot file with no secondary signature/cycle filtering.','not_touched':['actual exact key rules','Strategy decisions','historical outcome ledgers','auto-buy OFF'],'auto_buy':False})
        marker.parent.mkdir(parents=True,exist_ok=True);marker.write_text(txt,encoding='utf-8')
    except Exception:pass
try:_v2171_ledger_once()
except Exception:pass

# =============================================================================
# v2172 Review consumes the one Strategy snapshot and records no second owner.
# =============================================================================
VERSION='review_worker_v2.070'
BUILD_LABEL='v2172_exact_current_snapshot_owner_2026-07-23'
MAIN_DEPLOY_VERSION=BUILD_LABEL
V2172_SNAPSHOT=BASE_DIR/'runtime'/'current_candidate_snapshot_v2172.json'
V2171_SNAPSHOT=V2172_SNAPSHOT


def _v2171_snapshot():  # type: ignore[override]
    obj=load_json(V2172_SNAPSHOT,{}) or {};rows=obj.get('rows') if isinstance(obj.get('rows'),list) else []
    return obj,[dict(r) for r in rows if isinstance(r,dict)]


def _v2170_current_rows():  # type: ignore[override]
    snap,rows=_v2171_snapshot();return rows,{} if rows else {'snapshot_missing':1}


def _v2170_identity(source_rows):  # type: ignore[override]
    snap,_=_v2171_snapshot();ident=snap.get('runtime_identity') if isinstance(snap.get('runtime_identity'),dict) else load_json(IDENTITY_PATH,{}) or {}
    hold=load_json(BASE_DIR/'paper_s1_hold_cache.json',{}) or {};sig=str(snap.get('runtime_signature') or ident.get('runtime_signature') or '')
    cycle=str(snap.get('cycle_id') or '');commit=str(snap.get('candidate_commit_id') or '')
    ready=bool(snap.get('row_count') and len(source_rows)==int(snap.get('row_count') or 0)==int(snap.get('unique_tickers') or 0)
               and ident.get('worker_version')=='strategy_worker_v2.066' and ident.get('core_version')=='strategy_v2_core_v2171'
               and ident.get('model_generation')=='FULL_INPUT_V2171' and sig and str(hold.get('runtime_signature_v2172') or '')==sig
               and str(hold.get('candidate_commit_id') or '')==commit and str(hold.get('cycle_id') or '')==cycle)
    return {'schema':'review_strategy_runtime_identity_v2172','ready':ready,**{k:ident.get(k) for k in ident},
            'runtime_signature':sig,'cycle_id':cycle,'candidate_commit_id':commit,'candidate_snapshot_id_v2172':snap.get('snapshot_id'),
            'source':'Strategy current_candidate_snapshot_v2172.json; no Review re-filter','auto_buy':False}


_V2172_BASE_RUN=run_once

def run_once__v2172():
    result=_V2172_BASE_RUN();result=dict(result) if isinstance(result,dict) else {}
    snap,rows=_v2171_snapshot();unique={ticker(r.get('ticker') or r.get('market') or r.get('symbol')) for r in rows};unique.discard('')
    identity=_v2170_identity(rows);status=load_json(STATUS,{}) or {};outcome=load_json(OUTCOME_STATUS,{}) or {}
    fields={'version':VERSION,'build':BUILD_LABEL,'runtime_identity_v2172':identity,'runtime_identity_ready_v2172':bool(identity.get('ready')),
            'candidate_snapshot_id_v2172':snap.get('snapshot_id'),'candidate_source_rows_v2172':len(rows),'candidate_unique_tickers_v2172':len(unique),
            'candidate_snapshot_exact_v2172':bool(identity.get('ready') and len(rows)==len(unique)==int(snap.get('row_count') or 0)),
            'current_row_secondary_filter_used_v2172':False,'model_generation_v2172':'FULL_INPUT_V2171',
            'quality_structure_gate_active_v2172':False,'historical_ledgers_rewritten':False,'auto_buy':False}
    status.update(fields);_atomic_json(STATUS,status)
    outcome.update({'review_candidate_source_rows_v2172':len(rows),'review_candidate_unique_tickers_v2172':len(unique),
                    'review_candidate_snapshot_exact_v2172':fields['candidate_snapshot_exact_v2172'],
                    'runtime_identity_ready_v2172':bool(identity.get('ready')),'model_generation_v2172':'FULL_INPUT_V2171',
                    'quality_structure_gate_active_v2172':False,'auto_buy':False});_atomic_json(OUTCOME_STATUS,outcome)
    result.update(fields);return result
run_once=run_once__v2172
run_once.__name__='run_once';run_once.__qualname__='run_once'


# =============================================================================
# v2173 exact Strategy snapshot owner. No secondary current-row filter.
# =============================================================================
VERSION='review_worker_v2.071'
BUILD_LABEL='v2173_exact_snapshot_fast_event_owner_2026-07-23'
MAIN_DEPLOY_VERSION=BUILD_LABEL
V2173_SNAPSHOT=BASE_DIR/'runtime'/'current_candidate_snapshot_v2173.json'
V2172_SNAPSHOT=V2173_SNAPSHOT
V2171_SNAPSHOT=V2173_SNAPSHOT


def _v2171_snapshot():  # type: ignore[override]
    obj=load_json(V2173_SNAPSHOT,{}) or {};rows=obj.get('rows') if isinstance(obj.get('rows'),list) else []
    return obj,[dict(r) for r in rows if isinstance(r,dict)]


def _v2170_current_rows():  # type: ignore[override]
    snap,rows=_v2171_snapshot();return rows,{} if rows else {'snapshot_missing':1}


def _v2170_identity(source_rows):  # type: ignore[override]
    snap,_=_v2171_snapshot();ident=snap.get('runtime_identity') if isinstance(snap.get('runtime_identity'),dict) else load_json(IDENTITY_PATH,{}) or {};hold=load_json(BASE_DIR/'paper_s1_hold_cache.json',{}) or {}
    sig=str(snap.get('runtime_signature') or ident.get('runtime_signature') or '');cycle=str(snap.get('cycle_id') or '');commit=str(snap.get('candidate_commit_id') or '')
    ready=bool(snap.get('row_count') and len(source_rows)==int(snap.get('row_count') or 0)==int(snap.get('unique_tickers') or 0) and ident.get('worker_version')=='strategy_worker_v2.067'
               and ident.get('core_version')=='strategy_v2_core_v2171' and ident.get('model_generation')=='FULL_INPUT_V2171' and sig
               and str(hold.get('runtime_signature_v2173') or '')==sig and str(hold.get('candidate_commit_id') or '')==commit and str(hold.get('cycle_id') or '')==cycle
               and hold.get('publish_ready_v2173') is True)
    return {'schema':'review_strategy_runtime_identity_v2173','ready':ready,**{k:ident.get(k) for k in ident},'runtime_signature':sig,'cycle_id':cycle,'candidate_commit_id':commit,
            'candidate_snapshot_id_v2173':snap.get('snapshot_id'),'source':'Strategy current_candidate_snapshot_v2173.json only','auto_buy':False}

_V2173_BASE_RUN=run_once
def run_once__v2173():
    result=_V2173_BASE_RUN();result=dict(result) if isinstance(result,dict) else {};snap,rows=_v2171_snapshot();unique={ticker(r.get('ticker') or r.get('market') or r.get('symbol')) for r in rows};unique.discard('');identity=_v2170_identity(rows)
    status=load_json(STATUS,{}) or {};outcome=load_json(OUTCOME_STATUS,{}) or {};summary=snap.get('summary') if isinstance(snap.get('summary'),dict) else {}
    fields={'version':VERSION,'build':BUILD_LABEL,'runtime_identity_v2173':identity,'runtime_identity_ready_v2173':bool(identity.get('ready')),'candidate_snapshot_id_v2173':snap.get('snapshot_id'),
            'candidate_source_rows_v2173':len(rows),'candidate_unique_tickers_v2173':len(unique),'candidate_snapshot_exact_v2173':bool(identity.get('ready') and len(rows)==len(unique)==int(snap.get('row_count') or 0)),
            'current_row_secondary_filter_used_v2173':False,'model_generation_v2173':'FULL_INPUT_V2171','fast_direct_rows_merged_v2173':summary.get('fast_direct_rows_merged_v2173'),
            'candidate_quality_numbers_changed_v2173':False,'historical_ledgers_rewritten':False,'auto_buy':False}
    status.update(fields);_atomic_json(STATUS,status);outcome.update({'review_candidate_source_rows_v2173':len(rows),'review_candidate_unique_tickers_v2173':len(unique),'review_candidate_snapshot_exact_v2173':fields['candidate_snapshot_exact_v2173'],
        'runtime_identity_ready_v2173':bool(identity.get('ready')),'model_generation_v2173':'FULL_INPUT_V2171','fast_direct_rows_merged_v2173':summary.get('fast_direct_rows_merged_v2173'),'auto_buy':False});_atomic_json(OUTCOME_STATUS,outcome);result.update(fields);return result
run_once=run_once__v2173
run_once.__name__='run_once';run_once.__qualname__='run_once'



# =============================================================================
# review_worker v2.074 / v2176
# Canonical current snapshot reader. No JSONL re-filter, no prior snapshot
# fallback, and no second decision owner.
# =============================================================================
VERSION='review_worker_v2.075'
BUILD_LABEL='v2187_review_runtime_actual_cycle_repair_2026-07-24'
MAIN_DEPLOY_VERSION=BUILD_LABEL
V2176_SNAPSHOT=BASE_DIR/'runtime'/'current_candidate_snapshot_v2176.json'


def _v2171_snapshot():  # type: ignore[override]
    obj=load_json(V2176_SNAPSHOT,{}) or {}
    rows=obj.get('rows') if isinstance(obj.get('rows'),list) else []
    return obj,[dict(row) for row in rows if isinstance(row,dict)]


def _v2170_identity(source_rows):  # type: ignore[override]
    snap,_=_v2171_snapshot()
    ident=snap.get('runtime_identity') if isinstance(snap.get('runtime_identity'),dict) else load_json(IDENTITY_PATH,{}) or {}
    hold=load_json(BASE_DIR/'paper_s1_hold_cache.json',{}) or {}
    sig=str(snap.get('runtime_signature') or ident.get('runtime_signature') or '')
    cycle=str(snap.get('cycle_id') or '')
    commit=str(snap.get('candidate_commit_id') or '')
    rows=len(source_rows); unique=len({ticker(row.get('ticker') or row.get('market') or row.get('symbol')) for row in source_rows if ticker(row.get('ticker') or row.get('market') or row.get('symbol'))})
    ready=bool(
        rows>0 and rows==unique==int(snap.get('row_count') or 0)==int(snap.get('unique_tickers') or 0)
        and ident.get('worker_version')=='strategy_worker_v2.071'
        and ident.get('worker_build')=='v2182_strategy_final_main_singleton_lifecycle_restore_2026-07-24'
        and ident.get('core_version')=='strategy_v2_core_v2171'
        and ident.get('model_generation')=='FULL_INPUT_V2171'
        and sig and ident.get('single_decision_owner')
        and str(hold.get('runtime_signature_v2176') or '')==sig
        and str(hold.get('candidate_commit_id') or '')==commit
        and str(hold.get('cycle_id') or '')==cycle
        and hold.get('publish_ready_v2176') is True
        and hold.get('single_decision_function_full_and_event_v2176') is True
        and bool(hold.get('s1_generation_id_v2176'))
        and bool(hold.get('hold_hash_v2176'))
        and int(hold.get('row_count') or 0)==len(hold.get('rows') or [])
    )
    return {
        'schema':'review_strategy_runtime_identity_v2176','ready':ready,
        **{key:ident.get(key) for key in ident},
        'runtime_signature':sig,'cycle_id':cycle,'candidate_commit_id':commit,
        'candidate_snapshot_id_v2176':snap.get('snapshot_id'),
        'source':'Strategy current_candidate_snapshot_v2176.json only',
        'current_row_secondary_filter_used_v2176':False,
        'paper_latest_jsonl_used_for_current_v2176':False,
        'single_decision_owner_v2176':True,
        'auto_buy':False,
    }


_V2176_BASE_RUN=run_once

def run_once__v2176():
    result=_V2176_BASE_RUN()
    result=dict(result) if isinstance(result,dict) else {}
    snap,rows=_v2171_snapshot()
    unique={ticker(row.get('ticker') or row.get('market') or row.get('symbol')) for row in rows}; unique.discard('')
    identity=_v2170_identity(rows)
    summary=snap.get('summary') if isinstance(snap.get('summary'),dict) else {}
    event_status=load_json(BASE_DIR/'strategy_completed_bar_event_status_v2176.json',{}) or {}
    hold=load_json(BASE_DIR/'paper_s1_hold_cache.json',{}) or {}
    status=load_json(STATUS,{}) or {}
    outcome=load_json(OUTCOME_STATUS,{}) or {}
    review_state=('ACTIVE' if identity.get('ready') and rows else ('WAITING_ACTIVE_MODEL_CANDIDATES' if identity.get('ready') else 'RUNTIME_IDENTITY_CHECK'))
    fields={
        'version':VERSION,'build':BUILD_LABEL,
        'state':'running','review_state_v2187':review_state,'phase':'cycle_done_v2187',
        'cycle_complete_v2187':True,'error':None,'updated_ts':now_ts(),'updated_text':now_text(),
        'runtime_identity_v2176':identity,
        'runtime_identity_ready_v2176':bool(identity.get('ready')),
        'candidate_snapshot_id_v2176':snap.get('snapshot_id'),
        'candidate_commit_id_v2176':snap.get('candidate_commit_id'),
        's1_generation_id_v2176':hold.get('s1_generation_id_v2176'),
        'hold_hash_v2176':hold.get('hold_hash_v2176'),
        'hold_row_count_v2176':hold.get('row_count'),
        'candidate_source_rows_v2176':len(rows),
        'candidate_unique_tickers_v2176':len(unique),
        'candidate_snapshot_exact_v2176':bool(identity.get('ready') and len(rows)==len(unique)==int(snap.get('row_count') or 0)),
        'current_row_secondary_filter_used_v2176':False,
        'paper_latest_jsonl_used_for_current_v2176':False,
        'model_generation_v2176':'FULL_INPUT_V2171',
        'single_decision_function_full_and_event_v2176':summary.get('single_decision_function_full_and_event_v2176') is True,
        'separate_fast_decision_function_active_v2176':False,
        'completed_bar_event_state_v2176':event_status.get('state'),
        'completed_bar_event_entry_ready_v2176':event_status.get('entry_ready'),
        'completed_bar_event_direct_published_v2176':event_status.get('direct_published'),
        'candidate_quality_numbers_changed_v2176':False,
        'review_hold_local_fixed_v2187':True,
        'review_strategy_identity_aligned_v2187':True,
        'review_worker_state_contract_fixed_v2187':True,
        'historical_ledgers_rewritten':False,
        'auto_buy':False,
    }
    status.update(fields); _atomic_json(STATUS,status)
    outcome.update({
        'review_candidate_source_rows_v2176':len(rows),
        'review_candidate_unique_tickers_v2176':len(unique),
        'review_candidate_snapshot_exact_v2176':fields['candidate_snapshot_exact_v2176'],
        'runtime_identity_ready_v2176':bool(identity.get('ready')),
        'model_generation_v2176':'FULL_INPUT_V2171',
        'current_row_secondary_filter_used_v2176':False,
        'auto_buy':False,
    }); _atomic_json(OUTCOME_STATUS,outcome)
    result.update(fields)
    return result

run_once=run_once__v2176
run_once.__name__='run_once';run_once.__qualname__='run_once'


def _v2176_ledger_once():
    marker=BASE_DIR/'runtime'/'review_v2176_canonical_snapshot.seeded'
    if marker.exists():return
    ts=now_ts(); txt=now_text(ts)
    try:
        append_jsonl(CHANGE_LEDGER,{'schema':'change_verify_ledger_v870','change_id':'V2176-REVIEW-CANONICAL-SNAPSHOT','issue_id':'V2174-CROSSED-EXACT-BUT-DIRECT-ZERO','version':'v2176','verify_result':'LOCAL_PASS_SERVER_CHECK','created_ts':ts,'created_at':txt,'writer':'review_v2176_lifecycle','cause':'Review current candidates could be rebuilt from legacy current/JSONL readers after Strategy had already sealed a canonical snapshot.','fix':'Read only current_candidate_snapshot_v2176.json and use its exact rows/commit/runtime identity without secondary filtering or decision recomputation.','not_touched':['outcome history','prediction formula','candidate quality','Paper/exit','historical ledgers','auto-buy OFF'],'auto_buy':False})
        marker.parent.mkdir(parents=True,exist_ok=True);marker.write_text(txt,encoding='utf-8')
    except Exception as exc:append_error('v2176_ledger',exc)
try:_v2176_ledger_once()
except Exception:pass


def _v2187_ledger_once():
    marker=BASE_DIR/'runtime'/'review_v2187_runtime_actual_cycle_repair.seeded'
    if marker.exists(): return
    ts=now_ts(); txt=now_text(ts)
    try:
        append_jsonl(CHANGE_LEDGER,{'schema':'change_verify_ledger_v870','change_id':'V2187-REVIEW-RUNTIME-ACTUAL-CYCLE-REPAIR','issue_id':'V2186-REVIEW-NAMEERROR-READY-FAIL','version':'v2187','verify_result':'LOCAL_PASS_SERVER_CHECK','created_ts':ts,'created_at':txt,'writer':'review_worker_v2.075','cause':'The active v2176 Review wrapper referenced hold without loading it, so every first cycle ended in NameError and Guard waited 95 seconds before failing. The Review identity still expected Strategy v2.069 while the deployed canonical Strategy is v2.071, and the worker status used analysis states where Guard expects running.','fix':'Load the existing Paper hold in the active wrapper, align the existing identity check to Strategy v2.071, and publish running as the worker health state while preserving the analysis state separately. No new command, Shadow, pipeline or gate.','not_touched':['prediction formula','candidate thresholds','Trigger/Invalid/T1','Paper costs','entry/exit','historical ledgers','auto-buy OFF'],'auto_buy':False})
        append_jsonl(ISSUE_LEDGER,{'schema':'coinbot_single_work_ledger_v870','event_type':'ISSUE','issue_id':'V2186-REVIEW-NAMEERROR-READY-FAIL','status':'DONE','title':'Review 첫 cycle 오류와 95초 배포 실패','detail':'정의되지 않은 hold 참조, Strategy 버전 기대값, worker 상태표시 계약을 기존 경로 안에서 수리.','version':'v2187','created_ts':ts,'created_at':txt,'auto_buy':False})
        marker.parent.mkdir(parents=True,exist_ok=True); marker.write_text(txt,encoding='utf-8')
    except Exception as exc:
        append_error('v2187_ledger',exc)
try:_v2187_ledger_once()
except Exception:pass



# =============================================================================
# v2188 detailed prediction-to-result verification.
# Existing Review state/ledger is reused. Each event seals the detailed scores
# once, then labels every 30m/1h/3h/6h axis as correct/wrong from actual MFE/MAE.
# =============================================================================
VERSION='review_worker_v2.076'
BUILD_LABEL='v2188_prediction_input_outcome_verification_2026-07-24'
MAIN_DEPLOY_VERSION=BUILD_LABEL
V2188_EXPECTED_WORKER='strategy_worker_v2.072'
V2188_EXPECTED_BUILD='v2188_prediction_primary_committed_handoff_2026-07-24'
V2188_EXPECTED_CORE='strategy_v2_core_v2172'
V2188_EXPECTED_MODEL='FULL_INPUT_V2188_PRIMARY'
_V2188_BASE_STABLE_KEY=stable_key
_V2188_BASE_CREATE_RECORD=create_record
_V2188_BASE_UPDATE_PATH=update_path
_V2188_BASE_RUN=run_once


def _v2188_deepcopy(value):
    try:return json.loads(json.dumps(value,ensure_ascii=False,default=str))
    except Exception:return {}


def stable_key(row,c):  # type: ignore[override]
    t=ticker(row.get('ticker') or c.get('ticker'))
    for value in (row.get('candidate_event_id_v2176'),c.get('candidate_event_id_v2176'),c.get('decision_key'),row.get('direct_decision_key_v2149'),c.get('plan_key'),c.get('pretrigger_contract_id_v2176')):
        key=str(value or '').strip()
        if t and key:return f'{GENERATION}|{t}|v2188:{key}'
    return _V2188_BASE_STABLE_KEY(row,c)


def create_record(row,c,price,nowv,key):  # type: ignore[override]
    rec=_V2188_BASE_CREATE_RECORD(row,c,price,nowv,key)
    pred=c.get('prediction') if isinstance(c.get('prediction'),dict) else {};evidence=c.get('prediction_evidence') if isinstance(c.get('prediction_evidence'),dict) else pred.get('evidence') if isinstance(pred.get('evidence'),dict) else {};structure=c.get('structure') if isinstance(c.get('structure'),dict) else {}
    rec['schema']='strategy_v2_outcome_state_row_v2188';rec['prediction_input_seal_v2188']={'sealed_ts':nowv,'model_generation':c.get('prediction_model_generation') or pred.get('prediction_model_generation'),'prediction_state':pred.get('state'),'continuation_score':num(pred.get('continuation_score')),
        'primary_market_score':num(pred.get('primary_market_score_v2188')),'primary_participation_score':num(pred.get('primary_participation_score_v2188')),'primary_trigger_flow_score':num(pred.get('primary_trigger_flow_score_v2188')),
        'axes':_v2188_deepcopy(evidence.get('primary_axes_v2188') if isinstance(evidence.get('primary_axes_v2188'),dict) else evidence.get('axes') if isinstance(evidence.get('axes'),dict) else {}),
        'groups':_v2188_deepcopy(evidence.get('groups_v2188_primary') if isinstance(evidence.get('groups_v2188_primary'),dict) else evidence.get('groups') if isinstance(evidence.get('groups'),dict) else {}),
        'connections':_v2188_deepcopy(evidence.get('input_connections_v2155') if isinstance(evidence.get('input_connections_v2155'),dict) else {}),
        'entry_contract_mode':structure.get('entry_contract_mode_v2188'),'original_structure_state':structure.get('original_structure_state_v2188') or structure.get('state'),'invalid_mode':structure.get('invalid_mode_v2188'),'target_mode':structure.get('target_mode_v2188'),'sealed_from_current_candidate_event':True,'auto_buy':False}
    rec['prediction_factor_results_v2188']={};rec['prediction_details_preserved_v2188']=True
    return rec


def _v2188_horizon_truth(rec,label,sample):
    sampled=num(sample.get('sampled_ts'),0.0) or 0.0;ups=rec.get('first_up_pct_ts_v2163') if isinstance(rec.get('first_up_pct_ts_v2163'),dict) else {};downs=rec.get('first_down_pct_ts_v2163') if isinstance(rec.get('first_down_pct_ts_v2163'),dict) else {}
    up=num(ups.get('1'));down=num(downs.get('1'));up_ok=bool(up and up<=sampled);down_ok=bool(down and down<=sampled)
    if up_ok and down_ok:return 'UP' if up<down else 'DOWN' if down<up else 'MIXED'
    if up_ok:return 'UP'
    if down_ok:return 'DOWN'
    mfe=num(sample.get('max_pct'),0.0) or 0.0;mae=num(sample.get('min_pct'),0.0) or 0.0
    if mfe>=1.0 and mae>-1.0:return 'UP'
    if mae<=-1.0 and mfe<1.0:return 'DOWN'
    return 'MIXED'


def _v2188_factor_result(score,truth):
    value=num(score)
    if value is None or abs(value)<=0.12 or truth=='MIXED':return 'NOT_SCORED'
    predicted='UP' if value>0 else 'DOWN'
    return 'CORRECT' if predicted==truth else 'WRONG'


def update_path(rec,price,nowv):  # type: ignore[override]
    _V2188_BASE_UPDATE_PATH(rec,price,nowv)
    seal=rec.get('prediction_input_seal_v2188') if isinstance(rec.get('prediction_input_seal_v2188'),dict) else {};axes=seal.get('axes') if isinstance(seal.get('axes'),dict) else {};groups=seal.get('groups') if isinstance(seal.get('groups'),dict) else {};results=rec.setdefault('prediction_factor_results_v2188',{})
    samples=rec.get('samples') if isinstance(rec.get('samples'),dict) else {}
    for label in ('30m','1h','3h','6h'):
        sample=samples.get(label) if isinstance(samples.get(label),dict) else None
        if not sample or label in results:continue
        truth=_v2188_horizon_truth(rec,label,sample);axis_result={axis:_v2188_factor_result(score,truth) for axis,score in axes.items()};group_result={name:_v2188_factor_result((meta or {}).get('score') if isinstance(meta,dict) else meta,truth) for name,meta in groups.items()}
        results[label]={'truth':truth,'sampled_ts':sample.get('sampled_ts'),'mfe_pct':sample.get('max_pct'),'mae_pct':sample.get('min_pct'),'close_pct':sample.get('pct'),'axis_results':axis_result,'group_results':group_result,'rule':'existing +1% versus -1% first-touch, then horizon MFE/MAE','auto_buy':False}


def _v2188_identity(source_rows):
    snap,_=_v2171_snapshot();ident=snap.get('runtime_identity') if isinstance(snap.get('runtime_identity'),dict) else load_json(IDENTITY_PATH,{}) or {};hold=load_json(BASE_DIR/'paper_s1_hold_cache.json',{}) or {};sig=str(snap.get('runtime_signature') or ident.get('runtime_signature') or '');cycle=str(snap.get('cycle_id') or '');commit=str(snap.get('candidate_commit_id') or '')
    rows=len(source_rows);unique=len({ticker(row.get('ticker') or row.get('market') or row.get('symbol')) for row in source_rows if ticker(row.get('ticker') or row.get('market') or row.get('symbol'))})
    ready=bool(rows>0 and rows==unique==int(snap.get('row_count') or 0)==int(snap.get('unique_tickers') or 0) and ident.get('worker_version')==V2188_EXPECTED_WORKER and ident.get('worker_build')==V2188_EXPECTED_BUILD and ident.get('core_version')==V2188_EXPECTED_CORE and ident.get('model_generation')==V2188_EXPECTED_MODEL and sig and ident.get('single_decision_owner') and str(hold.get('runtime_signature_v2176') or '')==sig and str(hold.get('candidate_commit_id') or '')==commit and str(hold.get('cycle_id') or '')==cycle and hold.get('publish_ready_v2176') is True and bool(hold.get('s1_generation_id_v2176')) and bool(hold.get('hold_hash_v2176')) and int(hold.get('row_count') or 0)==len(hold.get('rows') or []))
    return {'schema':'review_strategy_runtime_identity_v2188','ready':ready,**{key:ident.get(key) for key in ident},'runtime_signature':sig,'cycle_id':cycle,'candidate_commit_id':commit,'candidate_snapshot_id_v2176':snap.get('snapshot_id'),'source':'Strategy current_candidate_snapshot_v2176.json only','prediction_primary_v2188':True,'auto_buy':False}


def _v2188_validation_summary(records):
    result={}
    for label in ('30m','1h','3h','6h'):
        axis_counts={};group_counts={};truth=Counter();samples=0
        for rec in records:
            if not isinstance(rec,dict):continue
            block=(rec.get('prediction_factor_results_v2188') or {}).get(label) if isinstance(rec.get('prediction_factor_results_v2188'),dict) else None
            if not isinstance(block,dict):continue
            samples+=1;truth[str(block.get('truth') or 'MIXED')]+=1
            for axis,state in (block.get('axis_results') or {}).items():
                if state not in ('CORRECT','WRONG'):continue
                axis_counts.setdefault(axis,Counter())[state]+=1
            for group,state in (block.get('group_results') or {}).items():
                if state not in ('CORRECT','WRONG'):continue
                group_counts.setdefault(group,Counter())[state]+=1
        def ranked(counts,state):
            rows=[]
            for name,c in counts.items():
                total=c['CORRECT']+c['WRONG'];rows.append({'name':name,'correct':c['CORRECT'],'wrong':c['WRONG'],'total':total,'accuracy_pct':round(c['CORRECT']/total*100.0,1) if total else None})
            rows.sort(key=lambda x:(x[state.lower()],x['total']),reverse=True);return rows[:6]
        result[label]={'samples':samples,'truth_counts':dict(truth),'top_correct_axes':ranked(axis_counts,'CORRECT'),'top_wrong_axes':ranked(axis_counts,'WRONG'),'group_results':ranked(group_counts,'WRONG')}
    return result


_runtime_identity_from_strategy=_v2188_identity
_v2170_identity=_v2188_identity

def run_once__v2188():
    result=_V2188_BASE_RUN();result=dict(result) if isinstance(result,dict) else {};state=load_json(OUTCOME_STATE,{}) or {};records=list((state.get(STATE_KEY) or {}).values()) if isinstance(state.get(STATE_KEY),dict) else [];finals=[r for r in read_jsonl(OUTCOME_LEDGER,12000) if str(r.get('generation') or '')==GENERATION and str(r.get('prediction_model_generation') or '')==V2188_EXPECTED_MODEL];validation=_v2188_validation_summary(records+finals)
    status=load_json(STATUS,{}) or {};outcome_status=load_json(OUTCOME_STATUS,{}) or {};snap,rows=_v2171_snapshot();identity=_v2188_identity(rows)
    fields={'version':VERSION,'build':BUILD_LABEL,'state':'running','review_state_v2188':'ACTIVE' if identity.get('ready') else 'RUNTIME_IDENTITY_CHECK','runtime_identity_v2188':identity,'runtime_identity_ready_v2188':bool(identity.get('ready')),'model_generation_v2188':V2188_EXPECTED_MODEL,'prediction_validation_v2188':validation,'prediction_details_preserved_v2188':True,'structure_required_for_review_key_v2188':False,'historical_ledgers_rewritten':False,'auto_buy':False}
    status.update(fields);_atomic_json(STATUS,status);outcome_status.update(fields);_atomic_json(OUTCOME_STATUS,outcome_status);result.update(fields);return result
run_once=run_once__v2188
run_once.__name__='run_once';run_once.__qualname__='run_once'


def _v2188_review_ledger_once():
    marker=BASE_DIR/'runtime'/'review_v2188_prediction_verification.seeded'
    if marker.exists():return
    ts=now_ts();txt=now_text(ts)
    try:
        append_jsonl(CHANGE_LEDGER,{'schema':'change_verify_ledger_v870','change_id':'V2188-REVIEW-PREDICTION-OUTCOME','issue_id':'PREDICTION-DETAIL-DROPPED-2188','version':'v2188','verify_result':'LOCAL_PASS_SERVER_CHECK','created_ts':ts,'created_at':txt,'writer':'review_worker_v2.076','cause':'Review kept only broad group scores, so correct and wrong detailed inputs could not be compared to actual 30m/1h/3h/6h paths.','fix':'Seal detailed axis/group/connection values once per candidate event and label correct/wrong from the existing +1%/-1% first-touch and MFE/MAE outcomes.','not_touched':['historical outcome ledger rows','entry thresholds','auto-buy OFF'],'auto_buy':False})
        marker.parent.mkdir(parents=True,exist_ok=True);marker.write_text(txt,encoding='utf-8')
    except Exception as exc:append_error('v2188_review_ledger',exc)
try:_v2188_review_ledger_once()
except Exception:pass


# =============================================================================
# review_worker v2.077 / v2189: make the model-switch scope explicit.
# active_records remains the current prediction-model scope for compatibility.
# All-generation and prior-model counts prove that the v2188 count drop is a
# reader scope change, not deletion of preserved outcome state.
# =============================================================================
VERSION='review_worker_v2.077'
BUILD_LABEL='v2189_review_model_scope_preservation_2026-07-24'
_V2189_BASE_RUN_ONCE=run_once


def run_once__v2189():
    result=_V2189_BASE_RUN_ONCE();result=dict(result) if isinstance(result,dict) else {}
    state=load_json(OUTCOME_STATE,{}) or {};records=(state.get(STATE_KEY) or {}) if isinstance(state.get(STATE_KEY),dict) else {}
    rows=[r for r in records.values() if isinstance(r,dict) and not r.get('superseded_duplicate_v2154')]
    current_model=str(result.get('active_model_generation_v2168') or result.get('model_generation_v2188') or V2188_EXPECTED_MODEL)
    current=[r for r in rows if str(r.get('prediction_model_generation') or '')==current_model]
    prior=[r for r in rows if str(r.get('prediction_model_generation') or '')!=current_model]
    finals=read_jsonl(OUTCOME_LEDGER,12000)
    fields={'version':VERSION,'build':BUILD_LABEL,'state':'running','active_records':len(current),'active_records_current_model_v2189':len(current),'active_records_all_generation_v2189':len(rows),'active_records_prior_model_v2189':len(prior),'finalized_all_generation_v2189':sum(1 for r in finals if str(r.get('generation') or '')==GENERATION),'review_scope_v2189':'current model active count + preserved prior-model count','prior_model_records_deleted_v2189':False,'historical_ledgers_rewritten':False,'auto_buy':False}
    status=load_json(STATUS,{}) or {};outcome=load_json(OUTCOME_STATUS,{}) or {};status.update(fields);outcome.update(fields);_atomic_json(STATUS,status);_atomic_json(OUTCOME_STATUS,outcome);result.update(fields);return result
run_once=run_once__v2189
run_once.__name__='run_once';run_once.__qualname__='run_once'


def _v2189_review_ledger_once():
    marker=BASE_DIR/'runtime'/'review_v2189_model_scope_preservation.seeded'
    if marker.exists():return
    ts=now_ts();txt=now_text(ts)
    try:
        append_jsonl(CHANGE_LEDGER,{'schema':'change_verify_ledger_v870','change_id':'V2189-REVIEW-MODEL-SCOPE-PRESERVATION','issue_id':'V2189-ZERO-START-AND-REVIEW-SCOPE','version':'v2189','verify_result':'LOCAL_PASS_SERVER_CHECK','created_ts':ts,'created_at':txt,'writer':'review_worker_v2.077','cause':'The public board labelled current-model active_records as cumulative active tracking. After the v2188 model switch, the number therefore appeared to fall from the prior-model scope even though rows were preserved.','fix':'Keep the existing current-model count for compatibility and publish current-model, prior-model and all-generation active counts separately. No outcome row is deleted or rewritten.','not_touched':['prediction thresholds','Paper reset owner','historical outcome ledger','auto-buy OFF'],'auto_buy':False})
        marker.parent.mkdir(parents=True,exist_ok=True);marker.write_text(txt,encoding='utf-8')
    except Exception as exc:append_error('v2189_review_ledger',exc)
try:_v2189_review_ledger_once()
except Exception:pass

# =============================================================================
# review_worker v2.078 / v2191: unique horizon-result truth.
# Active state and finalized JSONL can contain the same event. Public validation
# now deduplicates by sealed event_key, publishes the actual 6h price-result count,
# and keeps finalized-ledger count separate. No score or trading rule changes.
# =============================================================================
VERSION='review_worker_v2.078'
BUILD_LABEL='v2191_unique_horizon_result_truth_2026-07-25'
MAIN_DEPLOY_VERSION=BUILD_LABEL
_V2191_BASE_RUN_ONCE=run_once


def _v2191_unique_validation_rows():
    state=load_json(OUTCOME_STATE,{}) or {};records=(state.get(STATE_KEY) or {}) if isinstance(state.get(STATE_KEY),dict) else {}
    current_model=str(state.get('active_model_generation_v2168') or V2188_EXPECTED_MODEL)
    chosen={}
    for rec in records.values():
        if not isinstance(rec,dict) or rec.get('superseded_duplicate_v2154'):continue
        if str(rec.get('generation') or '')!=GENERATION or str(rec.get('prediction_model_generation') or '')!=current_model:continue
        key=str(rec.get('event_key') or '')
        if key:chosen[key]=dict(rec)
    finals=[]
    for rec in read_jsonl(OUTCOME_LEDGER,20000):
        if not isinstance(rec,dict) or str(rec.get('generation') or '')!=GENERATION or str(rec.get('prediction_model_generation') or '')!=current_model:continue
        finals.append(rec);key=str(rec.get('event_key') or '')
        if key:chosen[key]=dict(rec)  # finalized row wins over active duplicate
    return list(chosen.values()),finals,current_model


def run_once__v2191():
    result=_V2191_BASE_RUN_ONCE();result=dict(result) if isinstance(result,dict) else {}
    rows,finals,current_model=_v2191_unique_validation_rows()
    validation=_v2188_validation_summary(rows)
    six=int(((validation.get('6h') or {}).get('samples') if isinstance(validation.get('6h'),dict) else 0) or 0)
    fields={
        'version':VERSION,'build':BUILD_LABEL,'state':'running',
        'prediction_validation_v2191':validation,'prediction_validation_v2188':validation,
        'unique_validation_records_v2191':len(rows),'six_hour_price_results_v2191':six,
        'finalized_ledger_current_model_v2191':len(finals),
        'six_hour_result_semantics_v2191':'unique candidate events with an actual 6h price sample',
        'finalized_ledger_semantics_v2191':'append-only 6h finalized outcome rows; shown separately',
        'active_final_duplicate_counted_once_v2191':True,
        'prediction_numbers_changed':False,'historical_ledgers_rewritten':False,'auto_buy':False,
    }
    status=load_json(STATUS,{}) or {};outcome=load_json(OUTCOME_STATUS,{}) or {}
    status.update(fields);outcome.update(fields);_atomic_json(STATUS,status);_atomic_json(OUTCOME_STATUS,outcome);result.update(fields);return result
run_once=run_once__v2191
run_once.__name__='run_once';run_once.__qualname__='run_once'


def _v2191_review_ledger_once():
    marker=BASE_DIR/'runtime'/'review_v2191_unique_horizon_truth.seeded'
    if marker.exists():return
    ts=now_ts();txt=now_text(ts)
    try:
        append_jsonl(CHANGE_LEDGER,{'schema':'change_verify_ledger_v870','change_id':'V2191-REVIEW-UNIQUE-HORIZON-TRUTH','issue_id':'V2191-RESET-SCORE-AND-REVIEW-SAMPLE-MISMATCH','version':'v2191','verify_result':'LOCAL_PASS_SERVER_CHECK','created_ts':ts,'created_at':txt,'writer':'review_worker_v2.078','cause':'The Review board compared 6h factor-result samples with the finalized JSONL count as if they were the same measure, and active/final copies could both enter validation.','fix':'Deduplicate by sealed event_key, publish actual horizon-result counts and finalized-ledger counts separately, and keep the same existing factor scoring formula.','not_touched':['prediction scores and thresholds','outcome ledger rows','entry/exit','auto-buy OFF'],'auto_buy':False})
        marker.parent.mkdir(parents=True,exist_ok=True);marker.write_text(txt,encoding='utf-8')
    except Exception as exc:append_error('v2191_review_ledger',exc)
try:_v2191_review_ledger_once()
except Exception:pass

# =============================================================================
# review_worker v2.079 / v2192: one event set and factor-by-factor truth.
# - One current-model candidate event is counted once by sealed event_key.
# - The same unique event set feeds 30m/1h/3h/6h totals and every factor result.
# - Market-shared factors are separated from candidate-specific factors by their
#   actual distinct sealed values, so repeated market counts are not presented as
#   independent candidate signals.
# - Existing scoring and +1%/-1% truth rules are unchanged.
# =============================================================================
VERSION='review_worker_v2.079'
BUILD_LABEL='v2192_unique_event_factor_truth_single_snapshot_2026-07-25'
MAIN_DEPLOY_VERSION=BUILD_LABEL
_V2192_BASE_RUN_ONCE=run_once


def _v2192_validation_snapshot():
    rows,finals,current_model=_v2191_unique_validation_rows()
    by_key={}
    for rec in rows:
        if not isinstance(rec,dict):continue
        key=str(rec.get('event_key') or '').strip()
        if key:by_key[key]=dict(rec)
    unique=list(by_key.values())
    result={}
    for label in ('30m','1h','3h','6h'):
        truth=Counter();factor={};sample_keys=[]
        for rec in unique:
            block=(rec.get('prediction_factor_results_v2188') or {}).get(label) if isinstance(rec.get('prediction_factor_results_v2188'),dict) else None
            if not isinstance(block,dict):continue
            key=str(rec.get('event_key') or '')
            sample_keys.append(key);truth[str(block.get('truth') or 'MIXED')]+=1
            seal=rec.get('prediction_input_seal_v2188') if isinstance(rec.get('prediction_input_seal_v2188'),dict) else {}
            axes=seal.get('axes') if isinstance(seal.get('axes'),dict) else {}
            for name,state in (block.get('axis_results') or {}).items():
                item=factor.setdefault(str(name),{'correct':0,'wrong':0,'not_scored':0,'values':set()})
                if state=='CORRECT':item['correct']+=1
                elif state=='WRONG':item['wrong']+=1
                else:item['not_scored']+=1
                try:item['values'].add(round(float(axes.get(name)),6))
                except Exception:pass
        rows_out=[]
        for name,item in factor.items():
            scored=int(item['correct'])+int(item['wrong']);distinct=len(item['values'])
            scope='MARKET_SHARED' if scored>=10 and distinct<=max(3,int(scored*0.01)) else 'CANDIDATE_SPECIFIC'
            rows_out.append({'name':name,'scope':scope,'correct':int(item['correct']),'wrong':int(item['wrong']),'not_scored':int(item['not_scored']),'scored':scored,'accuracy_pct':round(item['correct']/scored*100.0,2) if scored else None,'distinct_sealed_values':distinct})
        candidate=sorted([r for r in rows_out if r['scope']=='CANDIDATE_SPECIFIC' and r['scored']>0],key=lambda r:(r['accuracy_pct'] if r['accuracy_pct'] is not None else 999.0,-r['scored']))
        market=sorted([r for r in rows_out if r['scope']=='MARKET_SHARED' and r['scored']>0],key=lambda r:(r['accuracy_pct'] if r['accuracy_pct'] is not None else 999.0,-r['scored']))
        result[label]={'samples':len(sample_keys),'unique_event_count':len(set(sample_keys)),'truth_counts':dict(truth),'candidate_factor_rows':candidate,'market_factor_rows':market,'all_factor_rows':rows_out,'event_keys':sorted(set(sample_keys))}
    material={'model':current_model,'events':sorted(by_key),'horizons':{k:{'samples':v['samples'],'keys':v['event_keys']} for k,v in result.items()}}
    snapshot_id=hashlib.sha256(json.dumps(material,sort_keys=True,separators=(',',':'),default=str).encode()).hexdigest()[:16]
    for block in result.values():block.pop('event_keys',None)
    return {'schema':'prediction_validation_single_snapshot_v2192','snapshot_id':snapshot_id,'model_generation':current_model,'unique_events':len(unique),'finalized_rows_read':len(finals),'horizons':result,'same_event_owner_all_horizons':True,'score_formula_changed':False,'truth_rule_changed':False,'auto_buy':False}


def run_once__v2192():
    result=_V2192_BASE_RUN_ONCE();result=dict(result) if isinstance(result,dict) else {}
    validation=_v2192_validation_snapshot()
    fields={'version':VERSION,'build':BUILD_LABEL,'state':'running','prediction_validation_single_snapshot_v2192':validation,'validation_snapshot_id_v2192':validation.get('snapshot_id'),'unique_validation_events_v2192':validation.get('unique_events'),'same_event_owner_all_horizons_v2192':True,'market_shared_factors_separated_v2192':True,'prediction_numbers_changed':False,'historical_ledgers_rewritten':False,'auto_buy':False}
    status=load_json(STATUS,{}) or {};outcome=load_json(OUTCOME_STATUS,{}) or {}
    status.update(fields);outcome.update(fields);_atomic_json(STATUS,status);_atomic_json(OUTCOME_STATUS,outcome);result.update(fields);return result
run_once=run_once__v2192
run_once.__name__='run_once';run_once.__qualname__='run_once'


def _v2192_review_ledger_once():
    marker=BASE_DIR/'runtime'/'review_v2192_single_event_factor_truth.seeded'
    if marker.exists():return
    ts=now_ts();txt=now_text(ts)
    try:
        append_jsonl(CHANGE_LEDGER,{'schema':'change_verify_ledger_v870','change_id':'V2192-REVIEW-SINGLE-EVENT-FACTOR-TRUTH','issue_id':'V2192-PERFORMANCE-S1-REVIEW-SINGLE-TRUTH','version':'v2192','verify_result':'LOCAL_PASS_SERVER_CHECK','created_ts':ts,'created_at':txt,'writer':'review_worker_v2.079','cause':'Public factor results reused large raw counts without proving one event set across horizons, and market-wide factors appeared as if they were independent candidate signals.','fix':'Deduplicate once by sealed event_key, use that same set for all horizons, publish per-factor accuracy, and separate market-shared from candidate-specific factors by distinct sealed values.','not_touched':['factor scores','prediction threshold','truth rule','historical outcome rows','auto-buy OFF'],'auto_buy':False})
        marker.parent.mkdir(parents=True,exist_ok=True);marker.write_text(txt,encoding='utf-8')
    except Exception as exc:append_error('v2192_review_ledger',exc)
try:_v2192_review_ledger_once()
except Exception:pass



# =============================================================================
# review_worker v2.080 / v2193: preserve old samples and replay the corrected
# prediction answer on the same sealed event keys. Performance reset is unrelated.
# Structure factors are excluded from this analysis.
# =============================================================================
VERSION='review_worker_v2.080'
BUILD_LABEL='v2193_preserved_sample_prediction_correction_replay_2026-07-25'
MAIN_DEPLOY_VERSION=BUILD_LABEL
V2188_EXPECTED_WORKER='strategy_worker_v2.074'
V2188_EXPECTED_BUILD='v2193_prediction_answer_correction_runtime_2026-07-25'
V2188_EXPECTED_CORE='strategy_v2_core_v2173'
V2188_EXPECTED_MODEL='FULL_INPUT_V2193_CORRECTED'
V2193_BASELINE_MODEL='FULL_INPUT_V2188_PRIMARY'
V2193_CURRENT_MODEL='FULL_INPUT_V2193_CORRECTED'
_V2193_BASE_RUN_ONCE=run_once

try:
    from strategy_v2_core_v2173 import score_prediction_axes_v2193 as _v2193_shared_score
except Exception:
    _v2193_shared_score=None


def _v2193_rows_for_model(model):
    state=load_json(OUTCOME_STATE,{}) or {};records=(state.get(STATE_KEY) or {}) if isinstance(state.get(STATE_KEY),dict) else {}
    chosen={}
    for rec in records.values():
        if not isinstance(rec,dict) or rec.get('superseded_duplicate_v2154'):continue
        if str(rec.get('generation') or '')!=GENERATION or str(rec.get('prediction_model_generation') or '')!=model:continue
        key=str(rec.get('event_key') or '').strip()
        if key:chosen[key]=dict(rec)
    final_count=0
    for rec in read_jsonl(OUTCOME_LEDGER,30000):
        if not isinstance(rec,dict) or str(rec.get('generation') or '')!=GENERATION or str(rec.get('prediction_model_generation') or '')!=model:continue
        final_count+=1;key=str(rec.get('event_key') or '').strip()
        if key:chosen[key]=dict(rec)
    return list(chosen.values()),final_count


def _v2193_accuracy(correct,wrong):
    total=int(correct)+int(wrong)
    return round(int(correct)/total*100.0,2) if total else None


def _v2193_model_result(score,truth):
    return _v2188_factor_result(score,truth)


def _v2193_replay_baseline(records):
    result={}
    factors=('leader_persistence','market_liquidity_regime','buy_ratio_level')
    for label in ('30m','1h','3h','6h'):
        factor={name:{'before_correct':0,'before_wrong':0,'after_correct':0,'after_wrong':0,'not_scored':0} for name in factors}
        model={'before_correct':0,'before_wrong':0,'after_correct':0,'after_wrong':0,'not_scored':0,'recovered_up':0,'avoided_down':0,'lost_up':0}
        truth_counts=Counter();samples=0
        for rec in records:
            block=(rec.get('prediction_factor_results_v2188') or {}).get(label) if isinstance(rec.get('prediction_factor_results_v2188'),dict) else None
            if not isinstance(block,dict):continue
            truth=str(block.get('truth') or 'MIXED');truth_counts[truth]+=1;samples+=1
            seal=rec.get('prediction_input_seal_v2188') if isinstance(rec.get('prediction_input_seal_v2188'),dict) else {}
            axes=seal.get('axes') if isinstance(seal.get('axes'),dict) else {}
            conns=seal.get('connections') if isinstance(seal.get('connections'),dict) else {}
            scored=_v2193_shared_score(axes,conns) if callable(_v2193_shared_score) else {}
            corrected=scored.get('axes') if isinstance(scored.get('axes'),dict) else {}
            for name in factors:
                before=(block.get('axis_results') or {}).get(name)
                after=_v2193_model_result(corrected.get(name),truth)
                if before=='CORRECT':factor[name]['before_correct']+=1
                elif before=='WRONG':factor[name]['before_wrong']+=1
                if after=='CORRECT':factor[name]['after_correct']+=1
                elif after=='WRONG':factor[name]['after_wrong']+=1
                else:factor[name]['not_scored']+=1
            before_score=num(seal.get('continuation_score'))
            after_score=num(scored.get('continuation_score')) if isinstance(scored,dict) else None
            before_state=_v2193_model_result(before_score,truth);after_state=_v2193_model_result(after_score,truth)
            if before_state=='CORRECT':model['before_correct']+=1
            elif before_state=='WRONG':model['before_wrong']+=1
            if after_state=='CORRECT':model['after_correct']+=1
            elif after_state=='WRONG':model['after_wrong']+=1
            else:model['not_scored']+=1
            if truth=='UP':
                if (before_score is None or before_score<=0.12) and after_score is not None and after_score>0.0:model['recovered_up']+=1
                if before_score is not None and before_score>0.12 and (after_score is None or after_score<=0.0):model['lost_up']+=1
            elif truth=='DOWN':
                if before_score is not None and before_score>0.12 and after_score is not None and after_score<=0.0:model['avoided_down']+=1
        factor_rows=[]
        for name,item in factor.items():
            before_acc=_v2193_accuracy(item['before_correct'],item['before_wrong']);after_acc=_v2193_accuracy(item['after_correct'],item['after_wrong'])
            factor_rows.append({'name':name,**item,'before_accuracy_pct':before_acc,'after_accuracy_pct':after_acc,'delta_accuracy_pct':round(after_acc-before_acc,2) if before_acc is not None and after_acc is not None else None})
        before_acc=_v2193_accuracy(model['before_correct'],model['before_wrong']);after_acc=_v2193_accuracy(model['after_correct'],model['after_wrong'])
        model.update({'before_accuracy_pct':before_acc,'after_accuracy_pct':after_acc,'delta_accuracy_pct':round(after_acc-before_acc,2) if before_acc is not None and after_acc is not None else None})
        result[label]={'samples':samples,'truth_counts':dict(truth_counts),'factor_corrections':factor_rows,'model_replay':model}
    return result


def _v2193_current_validation(records):
    # Reuse the exact event/horizon factor owner for the new model only.
    result={}
    for label in ('30m','1h','3h','6h'):
        truth=Counter();samples=0;counts={}
        for rec in records:
            block=(rec.get('prediction_factor_results_v2188') or {}).get(label) if isinstance(rec.get('prediction_factor_results_v2188'),dict) else None
            if not isinstance(block,dict):continue
            samples+=1;truth[str(block.get('truth') or 'MIXED')]+=1
            for name,state in (block.get('axis_results') or {}).items():
                if name in {'major_trend','setup_trend','location_hold','price_reaction','volatility_fit','entry_timing','trigger_quality','breakout_reaction'}:continue
                if state not in ('CORRECT','WRONG'):continue
                counts.setdefault(str(name),Counter())[state]+=1
        rows=[]
        for name,c in counts.items():
            total=c['CORRECT']+c['WRONG'];rows.append({'name':name,'correct':c['CORRECT'],'wrong':c['WRONG'],'scored':total,'accuracy_pct':round(c['CORRECT']/total*100.0,2) if total else None})
        rows.sort(key=lambda x:(x['accuracy_pct'] if x['accuracy_pct'] is not None else 999.0,-x['scored']))
        result[label]={'samples':samples,'truth_counts':dict(truth),'factor_rows':rows}
    return result


def _v2193_validation_snapshot():
    baseline,baseline_final=_v2193_rows_for_model(V2193_BASELINE_MODEL)
    current,current_final=_v2193_rows_for_model(V2193_CURRENT_MODEL)
    replay=_v2193_replay_baseline(baseline)
    current_validation=_v2193_current_validation(current)
    material={'baseline_model':V2193_BASELINE_MODEL,'baseline_keys':sorted(str(r.get('event_key') or '') for r in baseline),'current_model':V2193_CURRENT_MODEL,'current_keys':sorted(str(r.get('event_key') or '') for r in current),'samples':{k:v.get('samples') for k,v in replay.items()}}
    snapshot_id=hashlib.sha256(json.dumps(material,sort_keys=True,separators=(',',':'),default=str).encode()).hexdigest()[:16]
    return {'schema':'prediction_correction_replay_snapshot_v2193','snapshot_id':snapshot_id,'baseline_model':V2193_BASELINE_MODEL,'baseline_unique_events':len(baseline),'baseline_finalized_rows_read':baseline_final,'baseline_horizons':replay,'current_model':V2193_CURRENT_MODEL,'current_unique_events':len(current),'current_finalized_rows_read':current_final,'current_horizons':current_validation,'performance_epoch_reset_affects_prediction_samples':False,'structure_factors_used':False,'same_sealed_event_keys_replayed':True,'historical_rows_rewritten':False,'auto_buy':False}


def run_once__v2193():
    result=_V2193_BASE_RUN_ONCE();result=dict(result) if isinstance(result,dict) else {}
    validation=_v2193_validation_snapshot()
    fields={'version':VERSION,'build':BUILD_LABEL,'state':'running','prediction_validation_v2193':validation,'validation_snapshot_id_v2193':validation.get('snapshot_id'),'baseline_prediction_samples_preserved_v2193':validation.get('baseline_unique_events'),'current_prediction_samples_v2193':validation.get('current_unique_events'),'prediction_model_generation_v2193':V2193_CURRENT_MODEL,'baseline_model_generation_v2193':V2193_BASELINE_MODEL,'performance_epoch_reset_did_not_reset_prediction_samples_v2193':True,'structure_factors_used_in_analysis_v2193':False,'historical_ledgers_rewritten':False,'auto_buy':False}
    status=load_json(STATUS,{}) or {};outcome=load_json(OUTCOME_STATUS,{}) or {}
    status.update(fields);outcome.update(fields);_atomic_json(STATUS,status);_atomic_json(OUTCOME_STATUS,outcome);result.update(fields);return result
run_once=run_once__v2193
run_once.__name__='run_once';run_once.__qualname__='run_once'


def _v2193_review_ledger_once():
    marker=BASE_DIR/'runtime'/'review_v2193_preserved_sample_replay.seeded'
    if marker.exists():return
    ts=now_ts();txt=now_text(ts)
    try:
        append_jsonl(CHANGE_LEDGER,{'schema':'change_verify_ledger_v870','change_id':'V2193-PRESERVED-PREDICTION-SAMPLE-REPLAY','issue_id':'V2193-REPEATED-WRONG-PREDICTION-FACTORS','version':'v2193','verify_result':'LOCAL_PASS_SERVER_CHECK','created_ts':ts,'created_at':txt,'writer':VERSION,'cause':'v2192 current-model single reader hid the preserved v2188 prediction samples after performance was reset to 0 trades.','fix':'Keep Paper performance at the current zero epoch, separately reload all preserved FULL_INPUT_V2188_PRIMARY event keys, and replay the v2193 correction against the same 30m/1h/3h/6h truths. Structure factors are excluded.','not_touched':['Paper performance epoch','historical outcome rows','structure/entry/exit','auto-buy OFF'],'auto_buy':False})
        marker.parent.mkdir(parents=True,exist_ok=True);marker.write_text(txt,encoding='utf-8')
    except Exception as exc:append_error('v2193_review_ledger',exc)
try:_v2193_review_ledger_once()
except Exception:pass


# =============================================================================
# review_worker v2.081 / v2198: replay v2193 and v2198 on the same preserved
# events. Existing outcome ledger/state only; no new Shadow or new ledger.
# =============================================================================
VERSION='review_worker_v2.081'
BUILD_LABEL='v2198_three_six_hour_prediction_replay_2026-07-25'
MAIN_DEPLOY_VERSION=BUILD_LABEL
V2198_CURRENT_MODEL='FULL_INPUT_V2198_CONTINUATION'
V2198_PREVIOUS_MODEL='FULL_INPUT_V2193_CORRECTED'
V2198_BASELINE_MODEL='FULL_INPUT_V2188_PRIMARY'
V2188_EXPECTED_WORKER='strategy_worker_v2.075'
V2188_EXPECTED_BUILD='v2198_three_six_hour_continuation_runtime_2026-07-25'
V2188_EXPECTED_CORE='strategy_v2_core_v2174'
V2188_EXPECTED_MODEL=V2198_CURRENT_MODEL
_V2198_BASE_RUN_ONCE=run_once
try:
    from strategy_v2_core_v2173 import score_prediction_axes_v2193 as _v2198_score_previous
except Exception:
    _v2198_score_previous=None
try:
    from strategy_v2_core_v2174 import score_prediction_axes_v2198 as _v2198_score_current
except Exception:
    _v2198_score_current=None


def _v2198_acc(c,w):
    total=int(c)+int(w);return round(int(c)/total*100.0,2) if total else None


def _v2198_replay(records):
    out={};factor_names=('leader_persistence','market_liquidity_regime','buy_ratio_level','momentum_level')
    for label in ('30m','1h','3h','6h'):
        prev={'correct':0,'wrong':0,'not_scored':0};cur={'correct':0,'wrong':0,'not_scored':0};factors={n:{'previous_correct':0,'previous_wrong':0,'current_correct':0,'current_wrong':0,'not_scored':0} for n in factor_names}
        truth_counts=Counter();samples=0;recovered_up=avoided_down=lost_up=0;prev_positive=cur_positive=0
        for rec in records:
            block=(rec.get('prediction_factor_results_v2188') or {}).get(label) if isinstance(rec.get('prediction_factor_results_v2188'),dict) else None
            if not isinstance(block,dict):continue
            truth=str(block.get('truth') or 'MIXED');truth_counts[truth]+=1;samples+=1
            seal=rec.get('prediction_input_seal_v2188') if isinstance(rec.get('prediction_input_seal_v2188'),dict) else {};axes=seal.get('axes') if isinstance(seal.get('axes'),dict) else {};conns=seal.get('connections') if isinstance(seal.get('connections'),dict) else {}
            ps=_v2198_score_previous(axes,conns) if callable(_v2198_score_previous) else {};cs=_v2198_score_current(axes,conns) if callable(_v2198_score_current) else {}
            pscore=num(ps.get('continuation_score')) if isinstance(ps,dict) else None;cscore=num(cs.get('continuation_score')) if isinstance(cs,dict) else None
            if pscore is not None and pscore>0:prev_positive+=1
            if cscore is not None and cscore>0:cur_positive+=1
            pr=_v2188_factor_result(pscore,truth);cr=_v2188_factor_result(cscore,truth)
            if pr=='CORRECT':prev['correct']+=1
            elif pr=='WRONG':prev['wrong']+=1
            else:prev['not_scored']+=1
            if cr=='CORRECT':cur['correct']+=1
            elif cr=='WRONG':cur['wrong']+=1
            else:cur['not_scored']+=1
            if truth=='UP':
                if (pscore is None or pscore<=0.12) and cscore is not None and cscore>0.0:recovered_up+=1
                if pscore is not None and pscore>0.12 and (cscore is None or cscore<=0.0):lost_up+=1
            elif truth=='DOWN' and pscore is not None and pscore>0.12 and cscore is not None and cscore<=0.0:avoided_down+=1
            pa=ps.get('axes') if isinstance(ps.get('axes'),dict) else {};ca=cs.get('axes') if isinstance(cs.get('axes'),dict) else {}
            for name in factor_names:
                a=_v2188_factor_result(pa.get(name),truth);b=_v2188_factor_result(ca.get(name),truth);item=factors[name]
                if a=='CORRECT':item['previous_correct']+=1
                elif a=='WRONG':item['previous_wrong']+=1
                if b=='CORRECT':item['current_correct']+=1
                elif b=='WRONG':item['current_wrong']+=1
                else:item['not_scored']+=1
        pacc=_v2198_acc(prev['correct'],prev['wrong']);cacc=_v2198_acc(cur['correct'],cur['wrong'])
        factor_rows=[]
        for name,item in factors.items():
            pa=_v2198_acc(item['previous_correct'],item['previous_wrong']);ca=_v2198_acc(item['current_correct'],item['current_wrong'])
            factor_rows.append({'name':name,**item,'previous_accuracy_pct':pa,'current_accuracy_pct':ca,'delta_accuracy_pct':round(ca-pa,2) if pa is not None and ca is not None else None})
        out[label]={'samples':samples,'truth_counts':dict(truth_counts),'previous_accuracy_pct':pacc,'current_accuracy_pct':cacc,'delta_accuracy_pct':round(cacc-pacc,2) if pacc is not None and cacc is not None else None,
                    'previous_positive_count':prev_positive,'current_positive_count':cur_positive,'candidate_retention_pct':round(cur_positive/max(1,prev_positive)*100.0,2),
                    'recovered_up':recovered_up,'avoided_down':avoided_down,'lost_up':lost_up,'factor_rows':factor_rows}
    vals=[]
    for label,weight in (('3h',0.45),('6h',0.55)):
        b=out.get(label) or {};a=b.get('current_accuracy_pct')
        if a is not None:vals.append((float(a),weight))
    long_acc=sum(v*w for v,w in vals)/sum(w for _,w in vals) if vals else None
    return out,round(long_acc,2) if long_acc is not None else None


def _v2198_current(records):
    return _v2193_current_validation(records)


def _v2198_validation_snapshot():
    baseline,_=_v2193_rows_for_model(V2198_BASELINE_MODEL);previous,_=_v2193_rows_for_model(V2198_PREVIOUS_MODEL);current,current_final=_v2193_rows_for_model(V2198_CURRENT_MODEL)
    replay,long_acc=_v2198_replay(baseline);current_h=_v2198_current(current)
    material={'baseline_keys':sorted(str(r.get('event_key') or '') for r in baseline),'current_keys':sorted(str(r.get('event_key') or '') for r in current),'samples':{k:v.get('samples') for k,v in replay.items()}}
    sid=hashlib.sha256(json.dumps(material,sort_keys=True,separators=(',',':'),default=str).encode()).hexdigest()[:16]
    return {'schema':'prediction_continuation_replay_snapshot_v2198','snapshot_id':sid,'baseline_model':V2198_BASELINE_MODEL,'baseline_unique_events':len(baseline),'previous_model':V2198_PREVIOUS_MODEL,'previous_unique_events':len(previous),'current_model':V2198_CURRENT_MODEL,'current_unique_events':len(current),'current_finalized_rows_read':current_final,
            'horizons':replay,'current_horizons':current_h,'long_objective_accuracy_pct_v2198':long_acc,'objective_horizons':['3h','6h'],'short_horizon_role':'entry_timing_only','structure_factors_used':False,'hard_veto_added':False,'candidate_rows_deleted':0,'historical_rows_rewritten':False,'auto_buy':False}


def run_once__v2198():
    result=_V2198_BASE_RUN_ONCE();result=dict(result) if isinstance(result,dict) else {};validation=_v2198_validation_snapshot()
    fields={'version':VERSION,'build':BUILD_LABEL,'state':'running','prediction_validation_v2198':validation,'validation_snapshot_id_v2198':validation.get('snapshot_id'),'baseline_prediction_samples_preserved_v2198':validation.get('baseline_unique_events'),'current_prediction_samples_v2198':validation.get('current_unique_events'),'prediction_model_generation_v2198':V2198_CURRENT_MODEL,'previous_model_generation_v2198':V2198_PREVIOUS_MODEL,'performance_epoch_reset_did_not_reset_prediction_samples_v2198':True,'structure_factors_used_in_analysis_v2198':False,'hard_veto_added_v2198':False,'historical_ledgers_rewritten':False,'auto_buy':False}
    status=load_json(STATUS,{}) or {};outcome=load_json(OUTCOME_STATUS,{}) or {};status.update(fields);outcome.update(fields);_atomic_json(STATUS,status);_atomic_json(OUTCOME_STATUS,outcome);result.update(fields);return result
run_once=run_once__v2198
run_once.__name__='run_once';run_once.__qualname__='run_once'


def _v2198_review_ledger_once():
    marker=BASE_DIR/'runtime'/'review_v2198_three_six_hour_replay.seeded'
    if marker.exists():return
    ts=now_ts();txt=now_text(ts)
    try:
        append_jsonl(CHANGE_LEDGER,{'schema':'change_verify_ledger_v870','change_id':'V2198-THREE-SIX-HOUR-PREDICTION-REPLAY','issue_id':'V2198-PREDICTION-SHORT-IMPULSE-LONG-CONTINUATION-MISMATCH','version':'v2198','verify_result':'LOCAL_PASS_SERVER_CHECK','created_ts':ts,'created_at':txt,'writer':VERSION,'cause':'Post-reset Paper performance showed low win rate while old prediction accuracy fell sharply at 3h/6h.','fix':'Replay v2193 and v2198 on the same preserved event keys and same 30m/1h/3h/6h MFE/MAE truths. Show candidate retention, recovered UP, avoided DOWN and lost UP.','not_touched':['performance epoch','historical outcome rows','structure/entry/exit','auto-buy OFF'],'auto_buy':False})
        marker.parent.mkdir(parents=True,exist_ok=True);marker.write_text(txt,encoding='utf-8')
    except Exception as exc:append_error('v2198_review_ledger',exc)
try:_v2198_review_ledger_once()
except Exception:pass

if __name__ == '__main__':
    main()
