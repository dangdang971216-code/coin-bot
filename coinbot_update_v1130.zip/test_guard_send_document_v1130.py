#!/usr/bin/env python3
from __future__ import annotations
import importlib.util, json, os, pathlib, tempfile
SOURCE=pathlib.Path(__file__).with_name('backga_guard_bot_v2_5_175.py')

class FakeResponse:
    status=200
    def read(self): return b'{"ok":true,"result":{"document":{"file_id":"x"}}}'
class FakeConn:
    last=None
    def __init__(self,host,timeout=0): self.host=host; self.timeout=timeout; self.headers={}; self.sent=bytearray(); FakeConn.last=self
    def putrequest(self,method,path): self.method=method; self.path=path
    def putheader(self,key,value): self.headers[key]=value
    def endheaders(self): pass
    def send(self,data): self.sent.extend(data)
    def getresponse(self): return FakeResponse()
    def close(self): pass

def main():
    with tempfile.TemporaryDirectory() as td:
        root=pathlib.Path(td); f=root/'sample.zip'; f.write_bytes(b'ZIPDATA'*1000)
        os.environ.update(GUARD_BOT_TOKEN='secret-token',GUARD_CHAT_ID='123',BOT_DIR=td)
        spec=importlib.util.spec_from_file_location('guard_send_v1130',SOURCE)
        mod=importlib.util.module_from_spec(spec); spec.loader.exec_module(mod)
        mod.http.client.HTTPSConnection=FakeConn
        result=mod._telegram_send_document_once_v1129('123',f,'caption')
        conn=FakeConn.last
        assert result['ok'] is True
        assert conn.method=='POST' and conn.path=='/botsecret-token/sendDocument'
        assert int(conn.headers['Content-Length'])==len(conn.sent)
        assert b'ZIPDATA' in bytes(conn.sent)
        assert b'name="chat_id"' in bytes(conn.sent)
        assert b'name="document"' in bytes(conn.sent)
        print(json.dumps({'ok':True,'stream_content_length_exact':True,'multipart_fields':True},sort_keys=True))
if __name__=='__main__':main()
