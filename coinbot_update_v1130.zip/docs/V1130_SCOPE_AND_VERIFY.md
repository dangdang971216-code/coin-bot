# v1130 Guard profitability export single ZIP

## Symptom
v1129 split raw source data before compression, so one profitability export produced 13 Telegram ZIP documents even though repetitive JSON/JSONL compresses heavily.

## Root cause
- `_export_part_plan_v1129` partitioned each raw source at about 28 MiB before ZIP compression.
- The user had to download every part separately.
- `paper_bot_trade_log.jsonl` was absent on the server and no approved fallback was resolved.

## v1130 owner and fix
- owner: Guard `/gexport_profitability`
- runtime: `guard_v2.5.175_profitability_export_single_zip_v1130_2026-06-29`
- Snapshot all approved files read-only first.
- Build one ZIP_LZMA archive containing every available file.
- Measure the compressed archive only after packaging.
- Send exactly one Telegram document when it is within the 49 MiB safety cap.
- Fail closed rather than silently returning many parts when one archive exceeds the cap.
- Resolve the trade-log logical source in this order:
  1. `paper_bot_trade_log.jsonl`
  2. `paper_trade_log.json`
  3. `paper_bot_trade_detail_v798.jsonl`
- Manifest records logical filename, resolved server filename, fallback use, source metadata and SHA256.

## Protected sources
OPEN/CLOSED/decision/performance/control/trade-detail sources are copied read-only. No source is renamed, rewritten, truncated or deleted. Temporary snapshot and ZIP files are removed after delivery.

## Unchanged
Strategy, Gate, rank, trigger, invalid, target, Paper entry/exit, OPEN 30, cycle 3, performance formulas and automatic buying are unchanged. Automatic buying remains OFF.

## Server proof
- `/gexport_profitability` sends `ZIP 1/1`.
- Result shows one archive and original mutation 0.
- Manifest contains all six logical audit entries or an explicit missing entry.
- Trade log reports its resolved fallback when the canonical filename is absent.
