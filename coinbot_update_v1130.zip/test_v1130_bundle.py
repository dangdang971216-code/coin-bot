#!/usr/bin/env python3
from pathlib import Path
import json, py_compile
ROOT=Path(__file__).resolve().parent
manifest=json.loads((ROOT/'DEPLOY_BUNDLE.json').read_text())
assert manifest['version']=='v1130'
assert manifest['guard']=='backga_guard_bot_v2_5_175.py'
assert manifest['auto_buy'] is False
assert manifest['strategy_contract_change'] is False
for rel in [manifest['guard'], *manifest['support_files']]:
    assert (ROOT/rel).exists(), rel
py_compile.compile(str(ROOT/manifest['guard']), doraise=True)
source=(ROOT/manifest['guard']).read_text()
assert 'guard_v2.5.175_profitability_export_single_zip_v1130_2026-06-29' in source
assert 'ZIP_LZMA' in source
assert 'archive_count": 1' in source
assert 'paper_bot_trade_detail_v798.jsonl' in source
print('PASS')
