Apply v1277 after v1276 only. v1277 repairs v1276 S1 overblocking caused by actual_cost missing values.
