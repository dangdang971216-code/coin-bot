v1417 targeted Strategy-only fix.
- Removes duplicate top-level Strategy definitions.
- Keeps one public S1 handoff writer path.
- Blocks stale trigger rows before S1 handoff using the existing 120s Paper TTL.
- No strategy threshold, exit, target, invalid, OPEN limit, or auto-buy change.
