#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Canonical ALT_SWING performance spine v986.

One append-only CLOSED ledger + one decision-state ledger -> one atomic snapshot.
Public score, performance, and trade-review consumers must read only this snapshot.
"""
from __future__ import annotations

import hashlib
import json
import os
import time
from collections import Counter, defaultdict
from datetime import datetime, timedelta, timezone
from pathlib import Path
from typing import Any, Dict, Iterable, List, Optional, Tuple

SCHEMA = "canonical_alt_swing_performance_snapshot_v986"
STRATEGY_MODE = "ALT_SWING_V977"
CUTOVER_TS = 1782093476.0
ALLOWED_EXIT_REASONS = {
    "structure_target",
    "structure_invalid",
    "swing_no_progress",
    "swing_max_weak_hold",
}
KST = timezone(timedelta(hours=9))


def _num(*values: Any, default: Optional[float] = 0.0) -> Optional[float]:
    for value in values:
        try:
            if value in (None, "", [], {}):
                continue
            return float(str(value).replace(",", "").replace("%", ""))
        except Exception:
            continue
    return default


def _sources(row: Dict[str, Any]) -> List[Dict[str, Any]]:
    out: List[Dict[str, Any]] = []
    if not isinstance(row, dict):
        return out
    out.append(row)
    for key in (
        "closed_exact_v926", "closed_evidence_v983", "entry_evidence_v983",
        "canonical_entry_snapshot", "entry_snapshot", "entry_context",
        "entry_diagnostics", "quality_evidence_v938", "quality_evidence_v936", "raw",
    ):
        obj = row.get(key)
        if isinstance(obj, dict):
            out.append(obj)
            for nested_key in (
                "closed_exact_v926", "closed_evidence_v983", "entry_evidence_v983",
                "canonical_entry_snapshot", "entry_context", "entry_diagnostics",
            ):
                nested = obj.get(nested_key)
                if isinstance(nested, dict):
                    out.append(nested)
    return out


def _first(row: Dict[str, Any], keys: Iterable[str]) -> Any:
    for source in _sources(row):
        for key in keys:
            value = source.get(key)
            if value not in (None, "", [], {}):
                return value
    return None


def open_ts(row: Dict[str, Any]) -> float:
    value = _first(row, ("opened_at", "opened_ts", "open_ts", "entry_open_ts"))
    ts = _num(value, default=0.0) or 0.0
    if ts > 10_000_000_000:
        ts /= 1000.0
    return ts if ts > 0 else 0.0


def closed_ts(row: Dict[str, Any]) -> float:
    value = _first(row, ("closed_ts", "exit_ts", "close_ts", "exited_ts", "closed_at", "timestamp", "ts"))
    ts = _num(value, default=0.0) or 0.0
    if ts > 10_000_000_000:
        ts /= 1000.0
    return ts if ts > 0 else 0.0


def strategy_mode(row: Dict[str, Any]) -> str:
    return str(_first(row, ("strategy_mode", "strategy_mode_v977")) or "").strip()


def pos_id(row: Dict[str, Any]) -> str:
    return str(_first(row, ("pos_id", "paper_pos_id_v926", "event_id")) or "").strip()


def decision_key(row: Dict[str, Any]) -> str:
    direct = str(_first(row, (
        "paper_decision_key_v926", "swing_gate_decision_key_v977",
        "minimal_gate_decision_key_v925", "decision_key",
    )) or "").strip()
    if direct.startswith("decision:"):
        direct = direct[len("decision:"):].strip()
    if direct:
        return direct
    pid = pos_id(row)
    if pid.startswith("decision:"):
        return pid[len("decision:"):].strip()
    return ""


def pnl_pct(row: Dict[str, Any]) -> Optional[float]:
    return _num(_first(row, (
        "net_after_configured_fee_pct_v983", "net_pct", "result_pct", "pnl_pct",
        "return_pct", "profit_pct", "final_realized_pnl_pct",
    )), default=None)


def strategy_label(row: Dict[str, Any]) -> str:
    value = _first(row, (
        "strategy_label", "paper_strategy_label", "final_entry_label",
        "strategy", "strategy_key", "route",
    ))
    text = str(value or STRATEGY_MODE).strip()
    return text if text else STRATEGY_MODE


def ticker(row: Dict[str, Any]) -> str:
    text = str(_first(row, ("ticker", "market", "symbol")) or "-").strip().upper()
    for prefix in ("KRW-", "BITHUMB:"):
        if text.startswith(prefix):
            text = text[len(prefix):]
    for suffix in ("_KRW", "-KRW", "/KRW"):
        if text.endswith(suffix):
            text = text[:-len(suffix)]
    return text or "-"


def exit_reason(row: Dict[str, Any]) -> str:
    return str(_first(row, ("exit_reason", "exit_rule", "close_reason")) or "missing").strip() or "missing"


def hold_sec(row: Dict[str, Any]) -> Optional[float]:
    return _num(_first(row, ("hold_sec", "holding_sec", "duration_sec")), default=None)


def peak_pct(row: Dict[str, Any]) -> Optional[float]:
    return _num(_first(row, ("max_net_profit_pct", "net_peak_pct", "peak_pct", "max_profit_pct", "peak_profit_pct")), default=None)


def trough_pct(row: Dict[str, Any]) -> Optional[float]:
    return _num(_first(row, ("max_net_loss_pct", "net_trough_pct", "trough_pct", "min_profit_pct", "max_loss_pct")), default=None)


def giveback_pct(row: Dict[str, Any]) -> Optional[float]:
    explicit = _num(_first(row, ("giveback_pct", "missed_profit_pct")), default=None)
    if explicit is not None:
        return explicit
    peak = peak_pct(row)
    pnl = pnl_pct(row)
    if peak is not None and pnl is not None:
        return max(0.0, peak - pnl)
    return None


def _read_json(path: Path, default: Any) -> Any:
    try:
        return json.loads(path.read_text(encoding="utf-8", errors="ignore")) if path.exists() else default
    except Exception:
        return default


def read_jsonl(path: Path) -> Tuple[List[Dict[str, Any]], int]:
    rows: List[Dict[str, Any]] = []
    bad = 0
    if not path.exists():
        return rows, bad
    try:
        with path.open("r", encoding="utf-8", errors="ignore") as handle:
            for line in handle:
                if not line.strip():
                    continue
                try:
                    obj = json.loads(line)
                    if isinstance(obj, dict):
                        rows.append(obj)
                    else:
                        bad += 1
                except Exception:
                    bad += 1
    except Exception:
        bad += 1
    return rows, bad


def atomic_write_json(path: Path, obj: Dict[str, Any]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    tmp = path.with_suffix(path.suffix + ".tmp")
    payload = json.dumps(obj, ensure_ascii=False, separators=(",", ":"), default=str)
    with tmp.open("w", encoding="utf-8") as handle:
        handle.write(payload)
        handle.flush()
        os.fsync(handle.fileno())
    os.replace(tmp, path)


def _stat(rows: List[Dict[str, Any]]) -> Dict[str, Any]:
    values = [float(r["pnl_pct"]) for r in rows if isinstance(r.get("pnl_pct"), (int, float))]
    wins = [v for v in values if v > 0]
    losses = [v for v in values if v <= 0]
    total = sum(values)
    return {
        "n": len(values),
        "wins": len(wins),
        "losses": len(losses),
        "win_rate": round((len(wins) / len(values) * 100.0), 2) if values else 0.0,
        "total": round(total, 4),
        "avg": round(total / len(values), 4) if values else 0.0,
        "avg_win": round(sum(wins) / len(wins), 4) if wins else None,
        "avg_loss": round(sum(losses) / len(losses), 4) if losses else None,
    }


def _compact_row(row: Dict[str, Any], key: str, match_mode: str) -> Dict[str, Any]:
    return {
        "identity": f"decision:{key}",
        "decision_key": key,
        "pos_id": pos_id(row),
        "match_mode": match_mode,
        "ticker": ticker(row),
        "strategy": strategy_label(row),
        "opened_at": open_ts(row),
        "closed_at": closed_ts(row),
        "pnl_pct": pnl_pct(row),
        "exit_reason": exit_reason(row),
        "contract_ok": exit_reason(row) in ALLOWED_EXIT_REASONS,
        "hold_sec": hold_sec(row),
        "peak_pct": peak_pct(row),
        "trough_pct": trough_pct(row),
        "giveback_pct": giveback_pct(row),
        "entry_build_key": str(_first(row, ("entry_build_key", "open_build_key", "score_patch_version")) or "-").strip(),
        "source": "closed_ledger",
    }


def _digest_json(obj: Any) -> str:
    raw = json.dumps(obj, ensure_ascii=False, sort_keys=True, separators=(",", ":"), default=str).encode("utf-8")
    return hashlib.sha256(raw).hexdigest()


def build_snapshot(
    base_dir: Path,
    paper_version: str,
    build_label: str,
    now_value: Optional[float] = None,
) -> Dict[str, Any]:
    nowv = float(now_value or time.time())
    closed_path = base_dir / "paper_bot_closed.jsonl"
    decision_path = base_dir / "paper_decision_state_v926.json"
    raw_rows, bad_rows = read_jsonl(closed_path)
    decision_obj = _read_json(decision_path, {}) or {}
    records = decision_obj.get("records") if isinstance(decision_obj, dict) and isinstance(decision_obj.get("records"), dict) else {}

    closed_decisions: Dict[str, Dict[str, Any]] = {}
    for key, value in records.items():
        if not isinstance(value, dict):
            continue
        clean_key = str(key or value.get("paper_decision_key_v926") or "").strip()
        if clean_key.startswith("decision:"):
            clean_key = clean_key[len("decision:"):].strip()
        if not clean_key or str(value.get("status") or "").upper() != "CLOSED":
            continue
        closed_decisions[clean_key] = value

    counts = Counter()
    counts["raw_ledger_rows"] = len(raw_rows)
    counts["bad_json_rows"] = bad_rows
    canonical_by_key: Dict[str, Dict[str, Any]] = {}
    duplicate_rows: List[Dict[str, Any]] = []
    excluded_samples: Dict[str, List[Dict[str, Any]]] = defaultdict(list)

    for index, row in enumerate(raw_rows):
        if not isinstance(row, dict):
            counts["non_dict_rows"] += 1
            continue
        opened = open_ts(row)
        if opened <= 0:
            counts["missing_open_ts"] += 1
            if len(excluded_samples["missing_open_ts"]) < 5:
                excluded_samples["missing_open_ts"].append({"index": index, "ticker": ticker(row)})
            continue
        if opened < CUTOVER_TS:
            counts["before_cutover"] += 1
            continue
        if strategy_mode(row) != STRATEGY_MODE:
            counts["wrong_strategy_mode"] += 1
            continue
        counts["alt_swing_ledger_rows"] += 1
        key = decision_key(row)
        match_mode = "decision_key_exact"
        if not key:
            pid = pos_id(row)
            counts["missing_decision_key"] += 1
            if len(excluded_samples["missing_decision_key"]) < 5:
                excluded_samples["missing_decision_key"].append({"index": index, "ticker": ticker(row), "pos_id": pid})
            continue
        decision = closed_decisions.get(key)
        if not isinstance(decision, dict):
            counts["decision_not_closed_or_missing"] += 1
            if len(excluded_samples["decision_not_closed_or_missing"]) < 5:
                excluded_samples["decision_not_closed_or_missing"].append({"index": index, "ticker": ticker(row), "decision_key": key})
            continue
        value = pnl_pct(row)
        if value is None:
            counts["missing_pnl"] += 1
            if len(excluded_samples["missing_pnl"]) < 5:
                excluded_samples["missing_pnl"].append({"index": index, "ticker": ticker(row), "decision_key": key})
            continue
        compact = _compact_row(row, key, match_mode)
        if key in canonical_by_key:
            counts["duplicate_closed_rows"] += 1
            if len(duplicate_rows) < 20:
                duplicate_rows.append({
                    "decision_key": key,
                    "ticker": compact.get("ticker"),
                    "kept_closed_at": canonical_by_key[key].get("closed_at"),
                    "duplicate_closed_at": compact.get("closed_at"),
                    "policy": "first committed exact ledger row kept",
                })
            continue
        canonical_by_key[key] = compact
        counts["exact_unique_closed"] += 1
        counts[match_mode] += 1

    rows = list(canonical_by_key.values())
    rows.sort(key=lambda r: (float(r.get("closed_at") or 0.0), str(r.get("identity") or "")))
    today_key = datetime.fromtimestamp(nowv, KST).date()
    yesterday_key = today_key - timedelta(days=1)
    cutoff_3h = nowv - 3 * 3600.0
    cutoff_6h = nowv - 6 * 3600.0
    cutoff_24h = nowv - 24 * 3600.0

    def day_rows(day: Any) -> List[Dict[str, Any]]:
        return [r for r in rows if float(r.get("closed_at") or 0.0) > 0 and datetime.fromtimestamp(float(r["closed_at"]), KST).date() == day]

    today_rows = day_rows(today_key)
    yesterday_rows = day_rows(yesterday_key)
    rows_3h = [r for r in rows if float(r.get("closed_at") or 0.0) >= cutoff_3h]
    rows_6h = [r for r in rows if float(r.get("closed_at") or 0.0) >= cutoff_6h]
    rows_24h = [r for r in rows if float(r.get("closed_at") or 0.0) >= cutoff_24h]

    contract_rows = [r for r in rows if bool(r.get("contract_ok"))]
    outside_rows = [r for r in rows if not bool(r.get("contract_ok"))]
    outside_reason_counts = Counter(str(r.get("exit_reason") or "missing") for r in outside_rows)

    by_strategy: Dict[str, List[Dict[str, Any]]] = defaultdict(list)
    for row in today_rows:
        by_strategy[str(row.get("strategy") or STRATEGY_MODE)].append(row)
    strategy_stats = {name: _stat(group) for name, group in by_strategy.items()}

    source_stat = closed_path.stat() if closed_path.exists() else None
    source_meta = {
        "closed_path": closed_path.name,
        "closed_size": source_stat.st_size if source_stat else 0,
        "closed_mtime_ns": source_stat.st_mtime_ns if source_stat else 0,
        "decision_path": decision_path.name,
        "decision_records": len(records),
        "closed_decision_records": len(closed_decisions),
    }
    membership_digest = _digest_json([
        (r.get("identity"), r.get("closed_at"), r.get("pnl_pct"), r.get("exit_reason")) for r in rows
    ])
    source_digest = _digest_json({"source": source_meta, "counts": dict(counts), "membership": membership_digest})
    snapshot_id = f"perf-{int(nowv * 1000)}-{source_digest[:12]}"

    return {
        "schema": SCHEMA,
        "version": paper_version,
        "build": build_label,
        "snapshot_id": snapshot_id,
        "generated_at": nowv,
        "generated_at_text": datetime.fromtimestamp(nowv, KST).strftime("%Y-%m-%d %H:%M:%S KST"),
        "source_owner": "paper_bot_single_canonical_performance_writer_v986",
        "source_policy": "paper_bot_closed.jsonl only; decision state CLOSED required; decision-key dedupe; no alert-recovery performance rows; no reader-side recomputation",
        "strategy_mode": STRATEGY_MODE,
        "cutover_ts": CUTOVER_TS,
        "membership_policy": "OPEN-time ALT_SWING_V977 + CLOSED decision exact + first committed unique decision row",
        "source_meta": source_meta,
        "source_digest": source_digest,
        "membership_digest": membership_digest,
        "counts": dict(counts),
        "excluded_samples": dict(excluded_samples),
        "duplicate_samples": duplicate_rows,
        "windows": {
            "all": _stat(rows),
            "today": _stat(today_rows),
            "yesterday": _stat(yesterday_rows),
            "recent_3h": _stat(rows_3h),
            "recent_6h": _stat(rows_6h),
            "recent_24h": _stat(rows_24h),
        },
        "window_counts": {
            "all": len(rows), "today": len(today_rows), "yesterday": len(yesterday_rows),
            "recent_3h": len(rows_3h), "recent_6h": len(rows_6h), "recent_24h": len(rows_24h),
        },
        "current_exit_contract": {
            "analysis_only": True,
            "allowed_exit_reasons": sorted(ALLOWED_EXIT_REASONS),
            "contract_ok_rows": len(contract_rows),
            "contract_outside_rows": len(outside_rows),
            "outside_reason_counts": dict(outside_reason_counts),
            "stats": _stat(contract_rows),
        },
        "today_strategy_stats": strategy_stats,
        "recent_rows": rows[-20:],
        "rows": rows,
        "invariants": {
            "single_source_ledger": True,
            "single_writer": True,
            "decision_closed_required": True,
            "dedupe_by_decision_key": True,
            "public_readers_recompute": False,
            "raw_ledger_preserved": True,
            "window_change_causes": ["new exact CLOSED", "24h/day boundary movement"],
        },
    }


def score_mirror(snapshot: Dict[str, Any]) -> Dict[str, Any]:
    windows = snapshot.get("windows") if isinstance(snapshot.get("windows"), dict) else {}
    counts = snapshot.get("counts") if isinstance(snapshot.get("counts"), dict) else {}
    return {
        "schema": "paper_score_cache_v986_canonical_snapshot_mirror",
        "version": snapshot.get("version"),
        "build": snapshot.get("build"),
        "snapshot_id": snapshot.get("snapshot_id"),
        "source_owner": snapshot.get("source_owner"),
        "source_digest": snapshot.get("source_digest"),
        "updated_at": snapshot.get("generated_at"),
        "updated_at_text": snapshot.get("generated_at_text"),
        "score_scope": "canonical_alt_swing_exact_unique_closed_v986",
        "current_closed_count": counts.get("exact_unique_closed", 0),
        "closed_count": counts.get("exact_unique_closed", 0),
        "raw_closed_count_all": counts.get("raw_ledger_rows", 0),
        "today_closed_count": (snapshot.get("window_counts") or {}).get("today", 0),
        "review_today_closed_count": (snapshot.get("window_counts") or {}).get("today", 0),
        "today_global_stats": windows.get("today", {}),
        "yesterday_global_stats": windows.get("yesterday", {}),
        "recent_3h_stats": windows.get("recent_3h", {}),
        "recent_6h_stats": windows.get("recent_6h", {}),
        "recent_24h_stats": windows.get("recent_24h", {}),
        "today_strategy_stats": snapshot.get("today_strategy_stats", {}),
        "recent_closed_source_trace": snapshot.get("recent_rows", []),
        "canonical_snapshot": snapshot,
        "mirror_only": True,
    }


def review_mirror(snapshot: Dict[str, Any]) -> Dict[str, Any]:
    return {
        "schema": "paper_trade_review_v986_canonical_snapshot_mirror",
        "version": snapshot.get("version"),
        "build": snapshot.get("build"),
        "snapshot_id": snapshot.get("snapshot_id"),
        "source_owner": snapshot.get("source_owner"),
        "updated_at": snapshot.get("generated_at"),
        "updated_at_text": snapshot.get("generated_at_text"),
        "closed_count": (snapshot.get("counts") or {}).get("exact_unique_closed", 0),
        "today_closed_count": (snapshot.get("window_counts") or {}).get("today", 0),
        "canonical_snapshot": snapshot,
        "mirror_only": True,
    }


def build_and_write(base_dir: Path, paper_version: str, build_label: str, now_value: Optional[float] = None) -> Dict[str, Any]:
    snapshot = build_snapshot(base_dir, paper_version, build_label, now_value=now_value)
    atomic_write_json(base_dir / "canonical_performance_snapshot_v986.json", snapshot)
    atomic_write_json(base_dir / "paper_bot_score_cache.json", score_mirror(snapshot))
    atomic_write_json(base_dir / "paper_bot_trade_review_cache.json", review_mirror(snapshot))
    return snapshot
