이 폴더는 release seed만 포함한다. 서버의 live OPEN/CLOSED/trade_log/decision/change_verify/issue ledger를 덮어쓰지 않는다.
