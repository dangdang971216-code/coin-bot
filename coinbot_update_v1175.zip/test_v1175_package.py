import hashlib, json, zipfile
from pathlib import Path
root=Path('.').resolve()
manifest=json.loads((root/'DEPLOY_BUNDLE.json').read_text())
assert manifest['version']=='v1175'
assert manifest['paper']=='paper_bot_v1.042.py'
assert manifest['auto_buy'] is False
assert manifest['strategy_source_change'] is False
src=root/manifest['paper']
assert src.exists()
assert hashlib.sha256(src.read_bytes()).hexdigest()==manifest['source_sha256'][src.name]
text=src.read_text(encoding='utf-8')
assert "VERSION = 'paper_bot_v1.042'" in text
assert 'paper_audit_only_summary_v1175' in text
assert 'audit_would_block_open_limit_v1175' in text
assert 'audit_would_block_cycle_limit_v1175' in text
for forbidden in ['paper_bot_open.json','paper_bot_closed.jsonl','trade_log.jsonl','decision_state.json']:
    assert not (root/forbidden).exists(), forbidden
print('PASS v1175 package tests')
