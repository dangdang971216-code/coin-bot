import importlib.util
import time
from pathlib import Path

SRC=Path('paper_bot_v1.042.py').resolve()
spec=importlib.util.spec_from_file_location('paper1175',SRC)
m=importlib.util.module_from_spec(spec)
spec.loader.exec_module(m)

# 1) Control is forced raw/unlimited even when old saved values would be finite.
m.load_json=lambda path, default=None: {
    'max_open_strict':30,'max_new_per_cycle':3,'candidate_ttl_sec':120,
    'preopen_micro_recheck':True,'notify_open_require_micro_fresh':True,
    'notify_open_require_ws_fresh':True,'paper_final_reaction_proof_enabled':True,
}
ctrl=m.load_control()
assert ctrl['max_open_strict']==0
assert ctrl['max_new_per_cycle']==0
assert ctrl['candidate_ttl_sec']==0
assert ctrl['preopen_micro_recheck'] is False
assert ctrl['paper_raw_intake_v1174'] is True

# 2) Old/missing candidate timestamps are audit-only, never stale-blocked.
old=m.candidate_freshness_evidence_v1039({'created_at':time.time()-9999},ctrl)
missing=m.candidate_freshness_evidence_v1039({},ctrl)
assert old['fresh'] is True and old['would_be_fresh_v1174'] is False
assert missing['fresh'] is True and missing['would_be_fresh_v1174'] is False

# 3) Exact Strategy S1 is recognized even when later readiness flags are false.
decision='market:TEST|plan:1'
gate={
    'schema':'swing_entry_gate_v977_single_owner','strategy_mode':'ALT_SWING_V977',
    'hard_pass':True,'final_trade_state':'S1_PASS','decision_key':decision,
    'risk_reward':0.2,'target_room_pct':0.1,
    'trigger_occurrence':{
        'decision_key':decision,'event_ts':time.time()-5000,'qualification_state':'QUALIFIED_EVENT',
        'kind':'REBREAK','s1_ready_ts_v1173':time.time()-5000,'s1_ready_decision_key_v1173':decision,
    },
}
ev={
    'ticker':'TEST','candidate_stage':'S1','strategy_mode':'ALT_SWING_V977',
    'swing_gate_decision_key_v977':decision,'swing_entry_gate_v977':gate,
    'open_eligible':False,'paper_bot_open':False,'trade_ready':False,
    'price':100.0,'current_price':100.0,
    'swing_trigger_price_v977':101.0,'swing_invalid_price_v977':90.0,'swing_target_price_v977':120.0,
}
assert m.is_strategy_s1_candidate(ev) is True
proof=m.trigger_occurrence_freshness(ev,ctrl,nowv=time.time())
assert proof['fresh'] is True and proof['ttl_enabled'] is False
assert proof['would_be_fresh_v1174'] is False

# 4) Final safety still reports issues, but returns pass=True in raw mode.
m._v1079_entry_confirmation_price=lambda ticker,fallback:(fallback,'test',0.0)
m._paper_v144_reaction_proof_block=lambda diag,ctrl:'reaction would block'
ok,reasons,diag=m.paper_final_safety(dict(ev),ctrl)
assert ok is True
assert reasons, 'expected audit reasons'
assert diag['paper_final_safety_blocking_v1174'] is False
assert diag['paper_final_safety_would_pass_v1174'] is False


# 4b) Legacy reset freeze, epoch gate and bulk-close diversion are disabled.
m.load_json=lambda path, default=None:{'entry_freeze':True,'state':'PREPARED_ENTRY_FREEZE'}
assert m._v1044_entry_freeze_active() is False
assert m._v1045_maybe_resume_entries() is False
assert m._v1045_reset_in_progress() is False
m._V1045_PREV_OPEN_POSITION=lambda pos_id,ev:{'pos_id':pos_id,'ticker':ev.get('ticker')}
m._v1045_epoch=lambda :{}
raw_open=m.open_position('raw:test',{'ticker':'TEST'})
assert raw_open['performance_epoch_role']=='raw_paper_no_active_epoch_v1174'
assert raw_open['performance_epoch_missing_audit_v1174'] is True
bulk=m._v1045_execute_bulk_close()
assert bulk['state']=='DISABLED_RAW_MODE_V1174' and bulk['ledger_mutated'] is False
m._V1045_PREV_RUN_CYCLE=lambda :{'running':True,'opened_this_cycle':7}
cycle=m.run_cycle__L23689()
assert cycle['opened_this_cycle']==7
assert cycle['book_reset_v1045']['state']=='DISABLED_RAW_MODE_V1174'
m._V1045_PREV_RUN_EXACT_EXIT_MONITOR=lambda ctrl=None,owner='x':{'state':'NORMAL_EXIT_OWNER','owner':owner}
exit_status=m.run_exact_exit_monitor__L23671(owner='raw-test')
assert exit_status['state']=='NORMAL_EXIT_OWNER'

# 5) Select more than 30 candidates with 30 existing OPEN rows. TTL/micro/final/reentry failures stay audit-only.
rows=[]
for i in range(35):
    d=f'market:T{i}|plan:1'
    g=dict(gate)
    g['decision_key']=d
    g['trigger_occurrence']={
        'decision_key':d,'event_ts':time.time()-5000,'qualification_state':'QUALIFIED_EVENT',
        'kind':'REBREAK','s1_ready_ts_v1173':time.time()-5000,'s1_ready_decision_key_v1173':d,
    }
    rows.append({
        'ticker':f'T{i}','candidate_stage':'S1','strategy_mode':'ALT_SWING_V977',
        'swing_gate_decision_key_v977':d,'swing_entry_gate_v977':g,
        'open_eligible':False,'paper_bot_open':False,'trade_ready':False,
        'price':100.0,'current_price':100.0,
        'swing_trigger_price_v977':101.0,'swing_invalid_price_v977':90.0,'swing_target_price_v977':120.0,
        'created_at':time.time()-5000,
    })

m._v1158_resolve_completed_handoff_v1158=lambda ctrl: ({'ready':True,'cycle_id':'c1','effective_generation_source_v1158':'TEST'}, {})
m.candidate_sources=lambda ctrl,handoff:[('s1_hold',Path('memory'),rows)]
m.latest_scan_filter=lambda rows,ctrl:list(rows)
m._v926_seed_decision_state=lambda open_pos:{'records':{}}
m._v938_load_trigger_reach_state=lambda :{}
m.load_json=lambda path, default=None:{}
m._v1037_file_signature=lambda path:{}
m._v1057_validate_loss_reentry_source=lambda snap,sig:(False,'missing',{})
m.closed_recent_ids=lambda :set()
m.open_tickers=lambda open_pos:set()
m._v734_strict_open_count=lambda open_pos:len(open_pos)
m._v1160_existing_terminal_feedback=lambda ev:{'suppress':True,'state':'OLD_STALE_TERMINAL'}
m._v1153_paper_event_once=lambda *a,**k:time.time()
m._v1153_set_path_ts=lambda *a,**k:None
m._record_decision=lambda *a,**k:None
m.candidate_delay_path_v1152=lambda *a,**k:{}
m._v1152_record_delay_summary=lambda *a,**k:None
m.micro_fresh=lambda ev,ctrl:False
m.ws_fresh=lambda ev:False
m._v938_note_trigger_reach=lambda *a,**k:None
m._v1037_loss_reentry_gate=lambda *a,**k:{'schema':'loss_reentry_gate_v1037','allowed':False,'state':'WOULD_BLOCK','reason':'test'}
m.mark_paper_selected_for_open=lambda *a,**k:None
m._v1102_record_funnel_terminal=lambda stats,ev,stage,status,reasons,diag=None: stats.__setitem__('paper_funnel_accounted_v1102',int(stats.get('paper_funnel_accounted_v1102',0))+1)
m.write_paper_timing_spine_status=lambda *a,**k:None
m._v926_save_decision_state=lambda *a,**k:True
m._v938_save_trigger_reach_state=lambda *a,**k:True
m._v734_trace_hold=lambda *a,**k:None
m.paper_final_safety=lambda ev,ctrl:(True,['TTL','MICRO','RR','REENTRY'],{'trigger_gate':{'trigger_reached':False},'paper_final_safety_would_pass_v1174':False})

open_pos={f'old:{i}':{'ticker':f'OLD{i}'} for i in range(30)}
picked,stats,filtered=m.select_candidates({
    'max_open_strict':0,'max_new_per_cycle':0,'block_same_ticker_open':True,'new_open_paused':False,
    'quality_rebuild_limit_contract_v1095':{'configured_before_override':{'max_open_strict':30,'max_new_per_cycle':3,'new_open_paused':False}},
},open_pos)
assert len(filtered)==35
assert len(picked)==35, (len(picked),stats)
assert stats['selected_s1']==35
assert stats['open_limit_disabled_v1174'] is True
assert stats['cycle_limit_disabled_v1174'] is True
assert stats['paper_final_safety_audit_issue_v1174']==35
assert stats['loss_reentry_audit_issue_v1174']==35
assert stats['candidate_ttl_audit_issue_v1174']==35
assert stats['audit_would_block_open_limit_v1175']==35
assert stats['audit_would_block_cycle_limit_v1175']==32
assert stats['audit_would_block_any_limit_v1175']==35

print('PASS v1175 raw intake tests')
