import importlib.util
import time
from pathlib import Path

SRC=Path('paper_bot_v1.042.py').resolve()
spec=importlib.util.spec_from_file_location('paper1175audit',SRC)
m=importlib.util.module_from_spec(spec)
spec.loader.exec_module(m)

status={
    'running':True,'pid':123,'opened_this_cycle':35,'closed_this_cycle':0,'elapsed_sec':12.3,
    'pick_stats':{
        's1_seen':35,'selected_s1':35,'late_safety_block_count_v1174':0,
        'candidate_ttl_audit_issue_v1174':35,
        'trigger_occurrence_audit_issue_v1174':35,
        'micro_fresh_audit_issue_v1174':12,
        'ws_fresh_audit_issue_v1174':9,
        'paper_final_safety_audit_issue_v1174':20,
        'loss_reentry_source_audit_issue_v1174':35,
        'loss_reentry_audit_issue_v1174':4,
        'audit_legacy_max_open_configured_v1175':30,
        'audit_legacy_max_new_per_cycle_configured_v1175':3,
        'audit_would_block_open_limit_v1175':35,
        'audit_would_block_cycle_limit_v1175':32,
        'audit_would_block_any_limit_v1175':35,
        'decision_already_consumed_v926':2,
    }
}
now=time.time()
dec='market:TEST|plan:1'
row={
    'ticker':'TEST','candidate_stage':'S1','candidate_grade':'S1','created_at':now-5000,
    'swing_quality_rank':1,
    'swing_entry_gate_v977':{
        'decision_key':dec,
        'trigger_occurrence':{
            'decision_key':dec,'event_ts':now-5000,'qualification_state':'QUALIFIED_EVENT','kind':'REBREAK',
            's1_ready_ts_v1173':now-5000,'s1_ready_decision_key_v1173':dec,
        },
    },
}

def fake_load(path, default=None):
    name=Path(path).name
    if name=='paper_bot_status.json': return status
    if name=='paper_bot_candidate_handoff_status.json': return {}
    if name=='paper_s1_hold_cache.json': return {'rows':[row]}
    if name=='paper_bot_open.json': return {f'p{i}':{'ticker':f'T{i}'} for i in range(30)}
    if name=='paper_bot_control.json': return {'max_open_strict':30,'max_new_per_cycle':3,'candidate_ttl_sec':120}
    return default if default is not None else {}

m.load_json=fake_load
m.load_open=lambda : {f'p{i}':{'ticker':f'T{i}'} for i in range(30)}
m._read_current_candidate_snapshot=lambda : ([row],{'state':'NORMAL'})

p=m.pstatus_text()
assert '실제 후대차단 0' in p
assert '진단 전용 이상' in p
assert '구OPEN제한 35' in p and '구cycle제한 32' in p
assert 'TTL통과' not in p and 'Paper 입력 TTL fresh' not in p
assert 'decision중복 2' in p

c=m.candidate_summary_text()
assert '후대차단 0' in c
assert '차단 아님' in c
assert '실제차단 없음' in c
assert 'TTL fresh' not in c and '최종검사' not in c

out={}
m._V1175_PREV_WRITE_STATUS=lambda obj: out.update(obj)
m.write_status__v1175(status)
summary=out['paper_audit_only_summary_v1175']
assert summary['actual_late_safety_block_count']==0
assert summary['audit_only_counts']['구OPEN제한']==35
assert summary['integrity_block_counts']['decision중복']==2
assert summary['applied']['ttl_enabled'] is False
print('PASS v1175 audit visibility tests')
