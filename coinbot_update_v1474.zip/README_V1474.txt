v1474 MATERIAL_SOURCE_PROOF_CANDIDATE_JOURNEY_MAP_AUTOBUY_OFF

[현재 문제]
- v1473은 재료 누락을 감사했지만 누락 시작점과 후보 전체 경로가 한 화면에 이어지지 않았다.
- 구조선에는 timeframe/lookback_rows가 있었지만 frozen trigger/invalid/target 계약으로 옮길 때 가격만 남고 증거가 빠지는 경로가 확인됐다.

[수정]
- Strategy가 구조선 source/timeframe/actual_rows/expected_rows/owner를 frozen plan과 candidate row에 함께 봉인한다.
- Paper가 후보판(S3→S2→새 평가 S1)과 실행배관(S1→Paper→trigger→안전검사→선택→OPEN)을 분리해 한 status에 저장한다.
- Main /pipeline_map과 /candidate_flow는 같은 Paper status만 읽는다.
- first_break_stage로 가장 먼저 끊긴 위치를 표시한다.

[변경 없음]
- 후보 기준, S1 수치, trigger/invalid/target 가격과 공식, RR 기준, OPEN 규칙, 청산계약 변경 없음
- S2 직접 OPEN 없음
- 자동매수 OFF
- OPEN/CLOSED/decision/exact 원장 재작성 없음
