coinbot_update_v1602

목적:
- v1152 후보흐름 복구본선을 기준으로 유지
- 자료 없음/source_missing/실행자료 미도착을 후보차단이 아니라 DATA_PIPELINE_ERROR로 분리
- owner/source/writer/reader 위치를 보이게 하는 진단 레이어 추가
- Gate/RR/Trigger/Invalid/Target/청산/OPEN 제한/자동매수 변경 없음

검수:
- py_compile PASS
- /data_pipeline 추가
- /candidate_standard, /flow_map_full 하단에 DATA_PIPELINE 분리판 표시
- 자동매수 OFF
