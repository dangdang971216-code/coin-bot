import hashlib
import importlib.util
import json
import os
import sys
import tempfile
import time
from pathlib import Path

ROOT = Path(__file__).resolve().parent
GUARD_SOURCE = ROOT / "backga_guard_bot_v2_5_203.py" if (ROOT / "backga_guard_bot_v2_5_203.py").exists() else ROOT / "backga_guard_bot.py"
SPEC = importlib.util.spec_from_file_location("guard_v1196", GUARD_SOURCE)
mod = importlib.util.module_from_spec(SPEC)
sys.modules[SPEC.name] = mod
SPEC.loader.exec_module(mod)


def write_main(root: Path, name: str, version: str, payload: str = "") -> Path:
    p = root / name
    p.write_text(f'BOT_VERSION = "수익형 {version}"\n{payload}\n', encoding="utf-8")
    return p


def digest(p: Path) -> str:
    return hashlib.sha256(p.read_bytes()).hexdigest()


def age(path: Path, seconds: float) -> None:
    t = time.time() - seconds
    os.utime(path, (t, t))


def test_main_resolver() -> None:
    with tempfile.TemporaryDirectory() as td:
        root = Path(td)
        old_bot_dir = mod.BOT_DIR
        try:
            mod.BOT_DIR = root
            current = write_main(root, "coinbot_main_v2_13_1134.py", "v2.13.1134", "X=1134")
            (root / "bot.py").write_bytes(current.read_bytes())
            (root / ".deployed_target").write_text(current.name + "\n", encoding="utf-8")
            old = write_main(root, "수익형_v2.13.320.py", "v2.13.320", "X=320")
            (root / "DEPLOY_TARGET.txt").write_text(old.name + "\n", encoding="utf-8")

            r = mod.resolve_main_source_v1196()
            assert r["path"].name == current.name, r
            assert r["owner"] == "deployed_hash_exact", r
            assert any(x.get("reason", "").startswith("stale_downgrade") for x in r["rejected"]), r
            assert mod.find_latest_source_file().name == current.name
            assert mod.get_bot_versions()[1] == current.name
            rec = mod.reconcile_main_markers_v1196()
            assert rec["ok"] is True and rec["changed"] is True, rec
            assert (root / "DEPLOY_TARGET.txt").read_text(encoding="utf-8").strip() == current.name

            newer = write_main(root, "coinbot_main_v2_13_1135.py", "v2.13.1135", "X=1135")
            (root / mod.DEPLOY_TARGETS_FILE).write_text(json.dumps({"main": newer.name}), encoding="utf-8")
            r = mod.resolve_main_source_v1196()
            assert r["path"].name == newer.name and r["owner"] == "deploy_targets_json", r

            newest = write_main(root, "coinbot_main_v2_13_1136.py", "v2.13.1136", "X=1136")
            (root / mod.UPGRADE_STATUS_FILE).write_text(json.dumps({"ok": True, "manifest": {"main": newest.name}}), encoding="utf-8")
            r = mod.resolve_main_source_v1196()
            assert r["path"].name == newest.name and r["owner"] == "successful_bundle_manifest", r

            bad = write_main(root, "coinbot_main_v2_13_1200.py", "v2.13.1199", "X=bad")
            (root / mod.UPGRADE_STATUS_FILE).write_text(json.dumps({"ok": True, "manifest": {"main": bad.name}}), encoding="utf-8")
            r = mod.resolve_main_source_v1196()
            assert r["path"].name == newer.name, r
            assert any(x.get("name") == bad.name and "mismatch" in x.get("reason", "") for x in r["rejected"]), r
        finally:
            mod.BOT_DIR = old_bot_dir


def test_bootstrap_excludes_legacy() -> None:
    with tempfile.TemporaryDirectory() as td:
        root = Path(td)
        old_bot_dir = mod.BOT_DIR
        try:
            mod.BOT_DIR = root
            legacy = write_main(root, "수익형_v9.99.9999.py", "v9.99.9999")
            modern = write_main(root, "coinbot_main_v2_13_100.py", "v2.13.100")
            r = mod.resolve_main_source_v1196()
            assert r["path"].name == modern.name, r
            assert r["path"].name != legacy.name
        finally:
            mod.BOT_DIR = old_bot_dir


def test_retention_contract() -> None:
    with tempfile.TemporaryDirectory() as td:
        root = Path(td)
        old_bot_dir = mod.BOT_DIR
        try:
            mod.BOT_DIR = root
            # Core ledgers must remain byte-identical.
            core_names = [
                "paper_bot_open.json", "paper_bot_closed.jsonl", "paper_bot_trade_log.jsonl",
                "paper_decision_events_v926.jsonl", "paper_exact_ledger.jsonl",
                "change_verify_ledger.jsonl", "issue_ledger.jsonl",
            ]
            before = {}
            for name in core_names:
                p = root / name
                p.write_text((name + "\n") * 50, encoding="utf-8")
                before[name] = (p.stat().st_size, digest(p))

            stale = root / ".bundle_unpack_111"
            stale.mkdir()
            (stale / "large.bin").write_bytes(b"x" * 1024 * 1024)
            age(stale, 3 * 3600)
            age(stale / "large.bin", 3 * 3600)
            recent = root / ".bundle_unpack_222"
            recent.mkdir()
            (recent / "keep.bin").write_bytes(b"y" * 100)
            age(recent, 60)

            # Five old backups in one group -> newest three remain.
            backups = []
            for i in range(5):
                p = root / f"bot.py.backup_guard_apply_20260702_0{i}0000"
                p.write_bytes(bytes([i]) * 100)
                age(p, 7200 + (5 - i) * 60)
                backups.append(p)

            diag = root / "candidate_events.jsonl"
            diag.write_text("".join(json.dumps({"i": i}) + "\n" for i in range(1000)), encoding="utf-8")

            result = mod.run_retention_cleanup(dry_run=False)
            assert result["errors"] == 0, result
            assert not stale.exists(), result
            assert recent.exists(), result
            assert sum(p.exists() for p in backups) == 3, [p.name for p in backups if p.exists()]
            lines = [ln for ln in diag.read_text(encoding="utf-8").splitlines() if ln.strip()]
            assert len(lines) == 700, len(lines)
            assert (root / "archive").exists()

            for name, expected in before.items():
                p = root / name
                assert p.exists(), name
                assert (p.stat().st_size, digest(p)) == expected, name

            state = json.loads((root / "clean_retention_state.json").read_text(encoding="utf-8"))
            assert state["policy"]["open_deleted"] is False
            assert state["policy"]["decision_exact_change_issue_truncate"] is False
        finally:
            mod.BOT_DIR = old_bot_dir


def test_auto_retention_throttle() -> None:
    with tempfile.TemporaryDirectory() as td:
        root = Path(td)
        old_bot_dir = mod.BOT_DIR
        old_snapshot = mod.server_resource_snapshot
        old_cleanup = mod.run_retention_cleanup
        try:
            mod.BOT_DIR = root
            snapshots = [
                {"disk_free": 2 * 1024**3, "disk_pct": 80.0},
                {"disk_free": 3 * 1024**3, "disk_pct": 75.0},
            ]
            mod.server_resource_snapshot = lambda: snapshots.pop(0)
            mod.run_retention_cleanup = lambda dry_run=False: {"freed": 123, "deleted": 2, "truncated": 0, "compressed": 0, "errors": 0}
            out = mod.maybe_run_auto_retention_v1196(force=False)
            assert out["ran"] is True and out["state"]["trigger"] == "low_free", out

            # Recent run under low free is throttled to one hour.
            mod.server_resource_snapshot = lambda: {"disk_free": 2 * 1024**3, "disk_pct": 80.0}
            out2 = mod.maybe_run_auto_retention_v1196(force=False)
            assert out2["ran"] is False, out2
        finally:
            mod.BOT_DIR = old_bot_dir
            mod.server_resource_snapshot = old_snapshot
            mod.run_retention_cleanup = old_cleanup


if __name__ == "__main__":
    tests = [test_main_resolver, test_bootstrap_excludes_legacy, test_retention_contract, test_auto_retention_throttle]
    for fn in tests:
        fn()
        print(f"PASS {fn.__name__}")
    print(f"PASS {len(tests)}/{len(tests)}")
