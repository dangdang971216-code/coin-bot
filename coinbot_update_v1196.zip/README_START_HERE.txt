코인봇 v1196 적용 ZIP

목적
- Guard가 구 Main v320을 최신으로 오판하는 target resolver 수리
- 버려진 bundle 작업폴더와 중복 backup을 자동 순환정리

적용
1. 가드봇에서 /gupgrade_bundle 단독 실행
2. 새 Guard가 재시작된 뒤 같은 bundle 나머지를 1회 자동 검수
3. 자동 retention은 release job 종료 후 실행

변경
- Guard v2.5.203

변경하지 않음
- Main/Paper/Strategy/Review 매매코드
- 후보·trigger·invalid·target·RR·청산계약
- 핵심 거래원장
- 자동매수 OFF
