coinbot_update_v1304 · v1211식 버전스코어 가독성 복구 + 통합 디스크 정리

상태: LOCAL_DONE / SERVER_CHECK
자동매수: OFF
전략 변경: 없음

수정 내용:
1. /version_score를 v1211처럼 시간별 2줄 표시로 복구
   - ✅ 수익 플러스 / ❌ 수익 마이너스 / ⚪ 0전·수집중
   - 최근 3h, 6h, 12h, 24h, 오늘, 전체를 줄바꿈 정리
   - 실제 OPEN10/cycle2 제한판과 무제한 비교판 분리
2. 후보품질 원인판을 보기 좋게 정리
   - 좋은 점 / 안 좋은 점 / 탈락 이유 TOP / 수정 전 잠금
   - 후보식·trigger·invalid·target·RR 변경 없음
3. Guard 통합 디스크 정리 명령 추가
   - /gdisk_full_v1304
   - 일반정리 + 3일 비핵심 정리 + exact pause/index 정리 + 핵심원장 gzip 미러 + live append 압축 + 4GB 가드레일
   - 핵심 원장 원본 삭제·축소·재작성 없음

적용 후 확인:
가드봇: /gupgrade_bundle
가드 재시작 후: /grelease_verify
메인봇: /version_score /flow_map_full /candidate_standard
디스크 정리: /gdisk_full_v1304
미리보기: /gdisk_full_v1304 dry
