v1717: Strategy S1 hold early commit before observation/status phases. Auto-buy OFF. No trading contract changes.
