coinbot v1191 focused update bundle

목적
- v1190 서버에서 /flow_map_full이 ValueError: Invalid format specifier로 실패한 Main 표시 오류를 직접 수리
- Paper execution_core / exit_monitor / postprocess의 실제 내부시간 profile을 다시 볼 수 있게 복구

실제 원인
- fmt_sec(value, digits) 함수의 두 번째 인자는 소수 자릿수 정수여야 한다.
- v1190 Main은 scope의 total_sec 값을 두 번째 인자로 넘겼다.
- 서버 표본 95.369가 digits에 들어가 동적 포맷 지정자가 깨졌다.

변경 범위
- Main v2.13.1133 -> v2.13.1134 한 파일
- 최근시간이 없거나 0이면 total_sec를 값으로 선택한 뒤 fmt_sec(value)로 호출
- 후보식, trigger, invalid, target, RR, 청산계약, Paper 실행, worker, 라이브 원장 변경 없음
- 신규 차단 0 / 자동매수 OFF

현재 서버 판정
- 업로드된 운영요약으로 Main v2.13.1133 실행과 Paper core 95.369초는 확인됨
- /flow_map_full 실패 때문에 모든 component exact PID/version/hash와 실제 Paper 상위 함수는 아직 확정 불가
- v1190은 DONE이 아니라 PARTIAL/CHECK 유지
