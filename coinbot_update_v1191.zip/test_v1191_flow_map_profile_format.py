import importlib.util
import os
import sys
import tempfile
import unittest
from pathlib import Path

ROOT = Path(__file__).resolve().parent
sys.path.insert(0, str(ROOT))
os.environ.setdefault("COINBOT_BASE_DIR", tempfile.mkdtemp(prefix="coinbot_v1191_test_"))

spec = importlib.util.spec_from_file_location("coinbot_main_v1191_test", ROOT / "coinbot_main_v2_13_1134.py")
main = importlib.util.module_from_spec(spec)
assert spec.loader is not None
spec.loader.exec_module(main)


def fixture(last_sec=None, total_sec=95.369):
    return {
        "snapshot_id": "ops-test-v1191",
        "state": "CHECK",
        "current_cycle": {
            "state": "NORMAL",
            "candidate_rows": 461,
            "s1_count": 12,
            "paper_received": 461,
            "pipeline_cycle_id": "strategy-test",
            "candidate_commit_id": "candidate-test",
            "pipeline_progress": "complete",
            "source_age_sec": 1.2,
        },
        "last_completed_cycle": {},
        "timing": {
            "strategy_execution_handoff_sec": 12.260,
            "strategy_full_cycle_sec": 20.563,
            "paper_fast_cycle_sec": 95.369,
        },
        "timing_path": {},
        "paper_funnel": {},
        "open_exit_monitor": {},
        "ledger_performance": {},
        "errors": {},
        "runtime_deploy": {},
        "resources": {"server": {}},
        "commands_delivery": {},
        "artifact_chain": {},
        "storage_hygiene": {},
        "invariants": {"auto_buy": False, "new_blockers_added": False},
        "evidence_groups": {},
        "problems": [],
        "stages": [],
        "phase_profiles": {
            "components": [
                {
                    "component": "paper",
                    "state": "CHECK",
                    "pid_match": True,
                    "version_match": True,
                    "scopes": [
                        {
                            "scope": "execution_core",
                            "state": "CHECK",
                            "last_sec": last_sec,
                            "total_sec": total_sec,
                            "window_count": 1,
                            "window_avg_sec": total_sec,
                            "window_max_sec": total_sec,
                            "profiled_this_call": True,
                            "slowest": {
                                "category": "원장 읽기",
                                "function": "read_open_snapshot",
                                "cumulative_sec": 80.0,
                            },
                            "top_functions": [
                                {
                                    "category": "원장 읽기",
                                    "function": "read_open_snapshot",
                                    "cumulative_sec": 80.0,
                                    "self_sec": 70.0,
                                    "calls": 3,
                                }
                            ],
                        }
                    ],
                }
            ]
        },
    }


class FlowMapProfileFormatTests(unittest.TestCase):
    def test_total_sec_is_fallback_value_not_digits_argument(self):
        main._ops_snapshot = lambda: fixture(last_sec=None, total_sec=95.369)
        rendered = main.render_flow_map_full()
        self.assertIn("paper · execution_core 최근 95.369초", rendered)
        self.assertIn("read_open_snapshot", rendered)

    def test_positive_last_sec_has_priority(self):
        main._ops_snapshot = lambda: fixture(last_sec=1.234, total_sec=95.369)
        rendered = main.render_flow_map_full()
        self.assertIn("paper · execution_core 최근 1.234초", rendered)

    def test_zero_last_sec_falls_back_to_total(self):
        main._ops_snapshot = lambda: fixture(last_sec=0.0, total_sec=95.369)
        rendered = main.render_flow_map_full()
        self.assertIn("paper · execution_core 최근 95.369초", rendered)


if __name__ == "__main__":
    unittest.main()
