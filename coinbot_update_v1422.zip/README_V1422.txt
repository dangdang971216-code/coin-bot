v1422 display-only: missed-riser location board. No trading rule, Paper handoff, OPEN, TTL, RR, trigger/invalid/target/exit, or auto-buy change.
