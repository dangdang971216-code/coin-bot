#!/usr/bin/env python3
from __future__ import annotations
import importlib.util
import json
import pathlib
import sys
import tempfile

ROOT = pathlib.Path(__file__).resolve().parent
PACKAGE_ROOT = ROOT.parent
if str(PACKAGE_ROOT) not in sys.path:
    sys.path.insert(0, str(PACKAGE_ROOT))


def load(name: str, path: pathlib.Path):
    spec = importlib.util.spec_from_file_location(name, path)
    mod = importlib.util.module_from_spec(spec)
    sys.modules[name] = mod
    assert spec and spec.loader
    spec.loader.exec_module(mod)
    return mod


def main() -> None:
    s = load('strategy_v1222_test', PACKAGE_ROOT / 'strategy_worker_v1.051.py')
    g = load('guard_v1222_test', PACKAGE_ROOT / 'baselines' / 'backga_guard_bot_v2_5_219.py')

    row = {
        'ticker': 'TEST', 'current_price': 100.0,
        'structure_context_v871': {
            'schema': 'structure_context_v871',
            'execution_resistance': {'price': 103.0, 'tf': '15m', 'source': 'candle.actual', 'source_key': 'execution_resistance'},
            'setup_support': {'price': 98.0, 'tf': '30m', 'source': 'candle.actual', 'source_key': 'setup_support'},
            'major_support': {'price': 95.0, 'tf': '2h', 'source': 'candle.actual', 'source_key': 'major_support'},
            'major_resistance': {'price': 112.0, 'tf': '4h', 'source': 'candle.actual', 'source_key': 'major_resistance'},
            'setup_resistance': {'price': 106.0, 'tf': '1h', 'source': 'candle.actual', 'source_key': 'setup_resistance'},
        },
    }
    shadow = s._v1222_v1211_structure_shadow(row)
    assert shadow['source_exact'] is True
    assert shadow['complete'] is True
    assert shadow['trigger']['rounded_price'] == 103.0
    assert shadow['invalid']['rounded_price'] == 98.0
    assert shadow['target']['rounded_price'] == 112.0
    assert abs(shadow['risk_reward'] - 1.8) < 1e-6
    assert shadow['trading_values_changed'] is False

    plan = {
        'schema': 'alt_swing_dynamic_structure_plan_v1212',
        'structure_contract_version': 'structure_contract_v1212_dynamic_zones',
        'structure_contract_hash': 'abc',
        'current_price': 100.0,
        'trigger': {'rounded_price': 100.5, 'tf': '15m'},
        'invalid': {'rounded_price': 97.0, 'tf': '1h'},
        'target': {'rounded_price': 101.0, 'tf': '30m'},
        'target_mode_v1212': 'nearest_actual_resistance',
        'cost_inputs': {'spread_pct': 0.1, 'slippage_pct': 0.1, 'fee_pct': 0.2, 'estimated_roundtrip_cost_pct': 0.5},
        'selection_diagnostics_v1216': {'schema': 'diag', 'missing_axes': []},
    }
    compact_source = {
        'ticker': 'TEST', 'current_price': 100.0, 's_stage': 'S2',
        'candidate_pipeline_cycle_id_v1150': 'cycle-x',
        'dynamic_structure_plan_v1212': plan, 'structure_contract_v1212': plan,
        'v1211_structure_shadow_v1222': shadow,
        'v1211_structure_shadow_ready_v1222': True,
        'swing_entry_gate_v977': {
            'schema': 'gate', 'stage': 'S2', 'hard_pass': False,
            'trigger_price': 100.5, 'invalid_price': 97.0, 'target_price': 101.0,
            'risk_reward': 0.142857, 'target_room_pct': 0.4975,
            'hard_block_reasons': ['risk_reward_below_minimum'],
        },
    }
    compact = s._v861_compact_row_for_latest(compact_source)
    assert compact['v1211_structure_shadow_v1222']['source_exact'] is True
    assert compact['v1211_structure_shadow_v1222']['target']['rounded_price'] == 112.0
    assert len(json.dumps(compact, ensure_ascii=False).encode('utf-8')) < s.V1020_ROW_HARD_CEILING_BYTES

    with tempfile.TemporaryDirectory() as td:
        d = pathlib.Path(td)
        g.BOT_DIR = d
        rows = []
        for i in range(30):
            rows.append({
                'ticker': f'T{i}', 's_stage': 'S2', 'candidate_pipeline_cycle_id_v1150': 'cycle-x',
                'v1211_structure_shadow_v1222': shadow,
                'dynamic_structure_plan_v1212': plan,
                'swing_entry_gate_v977': {'hard_block_reasons': ['risk_reward_below_minimum']},
            })
        (d / g.S1_ZERO_AUDIT_CANDIDATES_V1214).write_text('\n'.join(json.dumps(x) for x in rows) + '\n', encoding='utf-8')
        (d / g.S1_ZERO_AUDIT_GATE_STATUS_V1214).write_text(json.dumps({'rows': 30, 'pass_s1': 0, 'recheck_s2': 30, 'observe_s3': 0}), encoding='utf-8')
        (d / g.S1_ZERO_AUDIT_WRITER_STATUS_V1214).write_text(json.dumps({'current_scope': {'rows_written': 30, 'pipeline_cycle_id_v1150': 'cycle-x', 'commit_id': 'commit-x'}}), encoding='utf-8')
        report = g.collect_structure_pairing_compare_audit_v1222()
        assert report['verdict'] == 'PROVEN_TARGET_SELECTION_SHRINK'
        assert report['source']['same_rows'] is True
        assert report['source']['same_stage'] is True
        assert report['source']['same_cycle'] is True
        assert report['source']['shadow_exact_rows'] == 30
        assert report['v1211']['risk_reward']['median'] == 1.8
        assert report['current']['risk_reward']['median'] < 0.2
        assert report['contract']['entry_flow_unchanged'] is True
        assert report['contract']['ranking_unchanged'] is True

    strategy_text = (PACKAGE_ROOT / 'strategy_worker_v1.051.py').read_text(encoding='utf-8')
    # Evidence must never be read by pass/fail logic. Its references are limited
    # to helper construction, row attachment and compact transport.
    assert 'v1211_structure_shadow_v1222' in strategy_text
    assert "hard.append('v1211_structure_shadow" not in strategy_text
    assert "passed = bool((not clean)" in strategy_text
    print('PASS v1222 shadow selection, compact persistence, same-cycle compare, no gate mutation')


if __name__ == '__main__':
    main()
