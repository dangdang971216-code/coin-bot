코인봇 v1224 · v1223 배포 ZIP py_compile 경로 수리

"
"- 실제 매매전략 변경 없음.
"
"- Guard source는 2.5.220 그대로 적용.
"
"- 테스트 파일을 배포 루트에서 local_tests/로 분리.
"
"- Micro와 canonical support 파일을 DEPLOY_BUNDLE.json에 명시.
"
"- 후보 기준, Trigger·Invalid·Target, RR 1.5, 목표공간 1.2%, 진입·청산 변경 없음.
"
"- 자동매수 OFF.
"
"- /gupgrade_bundle 단독 실행 후 새 완료 cycle에서 비교감사 실행.
