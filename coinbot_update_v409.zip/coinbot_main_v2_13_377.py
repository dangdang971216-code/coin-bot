#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""수익형_v2.13.352.py

Clean main bot renewal phase v366.
- 메인봇은 무거운 전체시장 스캔/정밀/전략판정을 직접 하지 않는다.
- scanner/feature/orderflow/strategy/review worker가 만든 캐시만 읽는다.
- 실제 paper OPEN은 strategy worker의 S급 후보만 허용한다.
- A/B/C 실시간 후보와 무거운 가상복기는 메인봇 경로에서 제거한다.
"""
from __future__ import annotations
import json, os, sys, time, traceback, re
from pathlib import Path
from typing import Any, Dict, List, Optional
import threading
from collections import Counter

try:
    from telegram import Bot, BotCommand
    from telegram.ext import Updater, CommandHandler, MessageHandler, Filters
except Exception:
    Bot = None; BotCommand = None; Updater = None; CommandHandler = None; MessageHandler = None; Filters = None

BOT_VERSION="수익형 v2.13.376"
BASE_DIR=Path(__file__).resolve().parent
TELEGRAM_TOKEN=os.getenv("TELEGRAM_TOKEN","").strip()
CHAT_ID=os.getenv("CHAT_ID","").strip()
WORKERS={
    "scanner": {"file":"scanner_worker_v0.3.py", "status":"clean_scanner_status.json"},
    "candle": {"file":"candle_worker_v0.2.py", "status":"clean_candle_status.json"},
    "market": {"file":"market_regime_worker_v0.1.py", "status":"clean_market_regime_status.json"},
    "feature": {"file":"feature_worker_v0.2.py", "status":"clean_feature_status.json"},
    "orderflow": {"file":"orderflow_worker_v0.8.py", "status":"clean_orderflow_status.json"},
    "risk": {"file":"risk_worker_v0.2.py", "status":"clean_risk_status.json"},
    "strategy": {"file":"strategy_worker_v0.30.py", "status":"clean_strategy_worker_status.json"},
    "target_router": {"file":"target_router_worker_v0.8.py", "status":"clean_target_router_status.json"},
    "review": {"file":"review_worker_v0.2.py", "status":"clean_review_worker_status.json"},
}
FILES={
    "brain_status":BASE_DIR/"clean_brain_status.json",
    "brain_runtime":BASE_DIR/"clean_brain_runtime.log",
    "brain_error":BASE_DIR/"clean_brain_error.log",
    "resource":BASE_DIR/"clean_resource_status.json",
    "scanner_market":BASE_DIR/"clean_scanner_market_cache.json",
    "feature":BASE_DIR/"clean_feature_cache.json",
    "orderflow":BASE_DIR/"clean_orderflow_summary_cache.json",
    "strategy_summary":BASE_DIR/"clean_strategy_s_summary.json",
    "candle":BASE_DIR/"clean_candle_cache.json",
    "market_regime":BASE_DIR/"clean_market_regime_cache.json",
    "risk":BASE_DIR/"clean_risk_filter_cache.json",
    "strategy_reject":BASE_DIR/"clean_strategy_s_reject_summary.json",
    "review":BASE_DIR/"clean_review_summary.json",
    "paper_status":BASE_DIR/"paper_bot_status.json",
    "paper_open":BASE_DIR/"paper_bot_open.json",
    "paper_score":BASE_DIR/"paper_bot_score_cache.json",
    "paper_latest":BASE_DIR/"paper_candidates_latest.jsonl",
    "paper_archive":BASE_DIR/"paper_candidates.jsonl",
    "paper_handoff":BASE_DIR/"clean_strategy_paper_handoff_status.json",
    "paperbot_handoff":BASE_DIR/"paper_bot_candidate_handoff_status.json",
    "candidate_handoff_trace":BASE_DIR/"paper_bot_candidate_handoff_trace.json",
    "paper_closed":BASE_DIR/"paper_bot_closed.jsonl",
    "score_anchor":BASE_DIR/"paper_bot_current_score_anchor.json",
    "target_router":BASE_DIR/"clean_target_router_queue.json",
    "ws_status":BASE_DIR/"clean_ws_sidecar_status.json",
    "micro_status":BASE_DIR/"clean_bithumb_micro_status.json",
    "micro_targets":BASE_DIR/"clean_micro_targets.json",
}
START_TS=time.time()

def now_ts()->float: return time.time()
def now_text(ts:Optional[float]=None)->str: return time.strftime("%Y-%m-%d %H:%M:%S", time.localtime(ts or now_ts()))
def fnum(v:Any, *more:Any, default:float=0.0)->float:
    """안전 숫자 변환.

    기존 호출(fnum(x, -1.0))은 두 번째 인자를 fallback 값처럼 쓰고,
    v345 preview 쪽 호출(fnum(a,b,c, default=0))은 앞에서부터 숫자값을 고른다.
    """
    for val in (v,) + tuple(more):
        try:
            if val is None or val == "":
                continue
            return float(str(val).replace(",", ""))
        except Exception:
            continue
    return default

def norm_ticker(v: Any) -> str:
    """메인봇 preview 전용 안전 티커 정규화.

    v345에서 paper 추적 로직이 norm_ticker를 참조했지만 메인봇 파일에는
    정의가 없어 /preview NameError가 났다. 여기서는 거래소 접두사/마켓 접미사만
    정리하고, 판단 로직에는 관여하지 않는다.
    """
    try:
        s = str(v or "").strip().upper()
        if not s:
            return ""
        if ":" in s:
            s = s.split(":", 1)[1]
        for suf in ("_KRW", "-KRW", "/KRW", "KRW"):
            if s.endswith(suf):
                s = s[:-len(suf)]
                break
        s = s.replace("_", "").replace("-", "").replace("/", "")
        return s
    except Exception:
        return ""

def load_json(path:Path, default:Any=None)->Any:
    try:
        if not path.exists(): return default
        return json.loads(path.read_text(encoding="utf-8", errors="ignore"))
    except Exception: return default

def save_json(path:Path,obj:Any)->None:
    path.parent.mkdir(parents=True,exist_ok=True)
    tmp=path.with_suffix(path.suffix+".tmp")
    tmp.write_text(json.dumps(obj,ensure_ascii=False,separators=(",",":"),default=str),encoding="utf-8")
    os.replace(tmp,path)

def read_jsonl(path:Path,max_lines:int=1000)->List[Dict[str,Any]]:
    if not path.exists(): return []
    try:
        lines=path.read_text(encoding="utf-8",errors="ignore").splitlines()
        if len(lines)>max_lines: lines=lines[-max_lines:]
        out=[]
        for ln in lines:
            try:
                if ln.strip():
                    o=json.loads(ln)
                    if isinstance(o,dict): out.append(o)
            except Exception: pass
        return out
    except Exception: return []

def line_count(path: Path, max_bytes: int = 2_000_000) -> int:
    try:
        if not path.exists(): return 0
        if path.stat().st_size > max_bytes:
            # 큰 archive는 기본 명령에서 전체를 세지 않는다. tail이 아니라 대략 표시만 한다.
            return -1
        return len(path.read_text(encoding="utf-8", errors="ignore").splitlines())
    except Exception: return 0

def log_runtime(msg:str)->None:
    try:
        with FILES["brain_runtime"].open("a",encoding="utf-8") as f: f.write(f"[{now_text()}] {msg}\n")
    except Exception: pass

def log_error(where:str,exc:BaseException)->None:
    try:
        with FILES["brain_error"].open("a",encoding="utf-8") as f:
            f.write(f"[{now_text()}] {where}: {exc.__class__.__name__}: {exc}\n{traceback.format_exc()[-1500:]}\n")
    except Exception: pass

def age(path:Path)->float:
    try: return max(0.0, now_ts()-path.stat().st_mtime)
    except Exception: return 999999.0

def pid_alive(pid:int)->bool:
    if pid<=0: return False
    try: os.kill(pid,0); return True
    except Exception: return False

def worker_status(name:str)->Dict[str,Any]:
    spec=WORKERS[name]; path=BASE_DIR/spec["status"]
    obj=load_json(path,{}) or {}; pid=int(fnum(obj.get("pid"),default=0)); alive=pid_alive(pid)
    a=age(path)
    state=str(obj.get("state") or "missing") if obj else "missing"
    return {"name":name,"state":state,"pid":pid,"alive":alive,"age":round(a,1),"version":obj.get("version","-"),"last_sec":obj.get("last_sec","-"),"row_count":obj.get("row_count",obj.get("evaluated",obj.get("closed_recent","-"))),"raw":obj}

def ensure_workers()->None:
    # v329: worker 실행/재시작은 가드봇 systemd 전담. 메인봇은 절대 직접 worker를 켜지 않는다.
    return

def resource_snapshot()->Dict[str,Any]:
    try:
        import shutil
        total, used, free = shutil.disk_usage(BASE_DIR)
        mem_total=mem_free=0
        try:
            for ln in Path('/proc/meminfo').read_text().splitlines():
                if ln.startswith('MemTotal:'): mem_total=int(ln.split()[1])*1024
                if ln.startswith('MemAvailable:'): mem_free=int(ln.split()[1])*1024
        except Exception: pass
        load=os.getloadavg() if hasattr(os,'getloadavg') else (0,0,0)
        return {"disk_free_gb":round(free/1024**3,2),"disk_used_pct":round(used/total*100,1),"mem_free_mb":round(mem_free/1024**2,1) if mem_free else 0,"mem_used_pct":round((1-mem_free/mem_total)*100,1) if mem_total and mem_free else 0,"load":[round(x,2) for x in load]}
    except Exception as exc:
        log_error("resource_snapshot",exc); return {}

def update_brain_status(state:str="running")->None:
    """메인봇 heartbeat/status만 저장한다.
    v329 기준 worker 실행/재시작은 가드봇 systemd 전담이다.
    """
    workers={k:worker_status(k) for k in WORKERS}
    save_json(FILES["brain_status"],{
        "version":BOT_VERSION,
        "state":state,
        "telegram_state":state,
        "pid":os.getpid(),
        "updated_ts":now_ts(),
        "updated_text":now_text(),
        "uptime_sec":round(now_ts()-START_TS,1),
        "workers":workers,
        "resource":resource_snapshot(),
        "note":"v330 main is cache-only; worker lifecycle is guard/systemd only",
    })

def worker_ok(st:Dict[str,Any])->str:
    state=str(st.get('state') or '').lower()
    a=fnum(st.get('age'), default=999999)
    if state in {'error','failed','stopped','missing','dead'}:
        return '❌'
    if state in {'running','ready','ok','initializing'}:
        return '✅' if a < 45 else '⚠️'
    return '❔'

def line_worker(st:Dict[str,Any], detail:bool=False)->str:
    icon=worker_ok(st)
    base=f"- {icon} {st['name']}: {st.get('version','-')} / {st.get('state')} / age {st.get('age')}s"
    if detail:
        base += f" / rows {st.get('row_count')} / sec {st.get('last_sec')}"
    return base

def router_flow_summary(router: Dict[str, Any]) -> str:
    """v337: target_router를 개수 제한표가 아니라 전체/우선/순환/대기/버림으로 보여준다."""
    if not isinstance(router, dict) or not router:
        return "- 정보배차: 상태 없음"
    return (
        f"- 정보배차: 전체 {router.get('queue_count','-')} / 최우선 {router.get('priority_protected_count','-')} "
        f"/ 이번내보냄 {router.get('active_target_count', router.get('target_count','-'))} "
        f"/ 순환대기 {router.get('rotation_wait_count', router.get('backlog_count','-'))} "
        f"/ 버림 {router.get('dropped_count',0)}"
    )

def router_flow_detail(router: Dict[str, Any]) -> List[str]:
    if not isinstance(router, dict) or not router:
        return ["- 정보배차 상태 없음"]
    return [
        router_flow_summary(router),
        f"- 채워야할 정보: WS필요 {router.get('need_ws','-')} / micro필요 {router.get('need_micro','-')} / fresh회복 {router.get('fresh_recovered','-')}",
        f"- 순환상태: rotation pool {router.get('rotation_pool_count','-')} / 이번순환 {router.get('rotation_export_count','-')} / 다음커서 {router.get('next_rotation_cursor','-')}",
        f"- 보호슬롯: 전략요청 {router.get('strategy_req_total_count','-')} / 강제보호 {router.get('strategy_req_forced_active_count','-')} / micro요청 {router.get('strategy_req_micro_target_count','-')}",
    ]


def health_text()->str:
    # v340: health는 기본 상태판이므로 v338 형식 유지. worker 시작/재시작/직접계산 금지.
    update_brain_status('running')
    workers=[worker_status(k) for k in WORKERS]
    res=resource_snapshot()
    paper=load_json(FILES['paper_status'],{}) or {}
    ws=load_json(FILES['ws_status'],{}) or {}
    micro=load_json(FILES['micro_status'],{}) or {}
    strat=load_json(FILES['strategy_summary'],{}) or {}
    reject=load_json(FILES['strategy_reject'],{}) or {}
    oflow=load_json(FILES['orderflow'],{}) or {}
    router=load_json(FILES['target_router'],{}) or {}
    good=sum(1 for w in workers if worker_ok(w)=='✅')
    warn=sum(1 for w in workers if worker_ok(w)=='⚠️')
    bad=sum(1 for w in workers if worker_ok(w)=='❌')
    evaluated = int(fnum(reject.get('evaluated') or strat.get('evaluated') or 0, 0))
    quote_ready = int(fnum(strat.get('quote_ready_count') or reject.get('quote_ready_count') or oflow.get('quote_fresh') or 0, 0))
    micro_ready = int(fnum(strat.get('micro_ready_count') or reject.get('micro_ready_count') or oflow.get('fresh_micro') or 0, 0))
    full_ready = int(fnum(strat.get('full_info_ready_count') or reject.get('full_info_ready_count') or oflow.get('info_ready') or 0, 0))
    sent_count = router.get('export_count', router.get('active_target_count', router.get('target_count','-')))
    lines=[
        "🧭 건강상태 /health",
        f"✅ 메인봇 {BOT_VERSION} / clean worker hub v369 / uptime {int(now_ts()-START_TS)}s",
        "",
        "[한눈요약 · 기존 health 값 유지]",
        f"✅ 전체 {evaluated or '-'}개 평가 / 시세 {quote_ready}/{evaluated or '-'} / 호가·체결 {micro_ready}/{evaluated or '-'} / 둘다 {full_ready}/{evaluated or '-'}",
        f"✅ 배차 전체 {router.get('queue_count','-')}개 → 이번내보냄 {sent_count}개 / 순환대기 {router.get('rotation_wait_count','-')}개 / 버림 {router.get('dropped_count',0)}개",
        f"✅ worker 정상 {good}개 / 주의 {warn}개 / 문제 {bad}개",
        f"✅ 오류 없음 기준은 /errorlog / 메모리 {res.get('mem_used_pct','-')}% / load {res.get('load','-')}",
        "",
        f"- worker: ✅ {good} / ⚠️ {warn} / ❌ {bad}",
        f"- paper: {paper.get('version','-')} / OPEN {paper.get('open_count', paper.get('open_total','-'))} / age {age(FILES['paper_status']):.1f}s",
        f"- WS: age {age(FILES['ws_status']):.1f}s / cache {ws.get('cache', ws.get('cache_count','-'))} / fresh {ws.get('fresh','-')}",
        f"- micro: age {age(FILES['micro_status']):.1f}s / targets {micro.get('targets','-')} / batch {micro.get('poll_batch','-')} / cached {micro.get('cached','-')} / fresh {micro.get('fresh','-')}",
        f"- orderflow: quote {oflow.get('quote_fresh','-')} / micro {oflow.get('fresh_micro','-')} / ready {oflow.get('info_ready','-')} / active {oflow.get('active_count','-')}",
        router_flow_summary(router),
        f"- S 후보 {strat.get('s_count',0)} / 평가 {reject.get('evaluated','-')} / 탈락 {reject.get('reject_count','-')}",
        f"- 디스크 {res.get('disk_used_pct','-')}% / 남음 {res.get('disk_free_gb','-')}GB / 메모리 {res.get('mem_used_pct','-')}% / load {res.get('load','-')}",
        "",
        "[worker 요약]",
    ]
    lines += [line_worker(w, detail=False) for w in workers]
    lines += ["", "[원칙] 메인봇은 worker cache만 읽음. worker 실행/재시작은 가드봇 systemd 전담."]
    return "\n".join(lines)

def _worker_metric_int(st: Dict[str, Any], *keys: str) -> Any:
    raw = st.get('raw') if isinstance(st.get('raw'), dict) else {}
    for k in keys:
        v = raw.get(k)
        if v not in (None, '', '-'):
            return v
    return '-'

def workers_text()->str:
    update_brain_status('running')
    workers={k:worker_status(k) for k in WORKERS}
    router=load_json(FILES['target_router'],{}) or {}
    strat=load_json(FILES['strategy_summary'],{}) or {}
    oflow=load_json(FILES['orderflow'],{}) or {}
    scanner=workers.get('scanner',{})
    feature=workers.get('feature',{})
    candle=workers.get('candle',{})
    market=workers.get('market',{})
    orderflow=workers.get('orderflow',{})
    risk=workers.get('risk',{})
    strategy=workers.get('strategy',{})
    target=workers.get('target_router',{})
    review=workers.get('review',{})
    lines=["🧩 worker 상태 /workers", "- 메인봇은 상태파일만 읽고 worker를 직접 실행하지 않음.", "", "[시장/재료]"]
    lines.append(f"- {worker_ok(scanner)} 스캐너: 전체 {_worker_metric_int(scanner,'row_count','pool_count')}개 수집 / {scanner.get('last_sec','-')}초")
    lines.append(f"- {worker_ok(feature)} 특징: {_worker_metric_int(feature,'row_count')}개 표준값 / {feature.get('last_sec','-')}초")
    lines.append(f"- {worker_ok(candle)} 캔들: {_worker_metric_int(candle,'row_count')}개 보강 / target {_worker_metric_int(candle,'target_count')} / {candle.get('last_sec','-')}초")
    lines.append(f"- {worker_ok(market)} 장세: {_worker_metric_int(market,'row_count')}개 확인 / {market.get('last_sec','-')}초")
    lines += ["", "[정보 보강]"]
    lines.append(f"- {worker_ok(orderflow)} 호가요약: 전체 {_worker_metric_int(orderflow,'row_count')}개 / WS {_worker_metric_int(orderflow,'fresh_ws')} / micro {_worker_metric_int(orderflow,'fresh_micro')} / {orderflow.get('last_sec','-')}초")
    lines.append(f"- {worker_ok(target)} 정보배차: 전체 {router.get('queue_count','-')}개 → 내보냄 {router.get('export_count',router.get('active_target_count','-'))}개 / 순환대기 {router.get('rotation_wait_count','-')} / 버림 {router.get('dropped_count',0)}")
    lines += ["", "[판정/복기]"]
    # v346: strategy status가 순간적으로 rows 0으로 보일 때 summary 캐시 기준값으로 보정 표시.
    # 상태 판단은 worker status를 쓰되, 숫자 표시는 clean_strategy_s_summary / reject summary까지 같이 본다.
    reject_sum = load_json(FILES['strategy_reject'], {}) or {}
    st_eval = _worker_metric_int(strategy,'evaluated','row_count')
    if st_eval in ('-', None, '', 0, '0'):
        st_eval = strat.get('evaluated') or reject_sum.get('evaluated') or '-'
    st_s = _worker_metric_int(strategy,'s_count')
    if st_s in ('-', None, ''):
        st_s = strat.get('s_count', 0)
    st_pending = _worker_metric_int(strategy,'info_pending_count')
    if st_pending in ('-', None, ''):
        st_pending = strat.get('info_pending_count') or reject_sum.get('info_pending_count') or 0
    st_sec = strategy.get('last_sec','-')
    if st_sec in ('-', None, '', 0, '0'):
        st_sec = strat.get('last_sec') or reject_sum.get('last_sec') or st_sec
    lines.append(f"- {worker_ok(strategy)} 전략판정: 평가 {st_eval}개 / S {st_s}개 / 정보대기 {st_pending}개 / {st_sec}초")
    lines.append(f"- {worker_ok(risk)} 위험: 최근손실/쿨다운 확인 / {risk.get('last_sec','-')}초")
    lines.append(f"- {worker_ok(review)} 복기: 최근완료 {_worker_metric_int(review,'closed_recent')}개 / 큰손실 {_worker_metric_int(review,'big_loss')} / 좋은승리 {_worker_metric_int(review,'good_win')} / {review.get('last_sec','-')}초")
    lines += ["", "[상세 원본]"]
    lines += [line_worker(workers[k], detail=True) for k in WORKERS]
    return "\n".join(lines)

def _paper_score_cache_version_ok(ver: str) -> bool:
    """v355: paper score cache gate 단일화.

    기존 v354는 허용 버전을 v0.86~v0.92 목록으로 박아두어 paper_bot이 v0.95로
    올라가면 같은 current-version score cache도 구버전으로 오판했다.
    이제 schema/scope는 그대로 엄격히 보되, paper_bot_v0.86 이상은 버전 숫자로 판정한다.
    구 v0.77/v0.80 계열 cache가 섞이지 않게 86 미만은 계속 차단한다.
    """
    m = re.search(r"paper_bot_v0\.(\d+)", str(ver or ""))
    if not m:
        return False
    return int(m.group(1)) >= 86


def _current_paper_score_cache() -> Dict[str, Any]:
    """v355: /score는 현재판 paper score cache만 읽는다.

    오래된 직접계산 fallback은 쓰지 않는다. 다만 paper_bot 버전이 올라갈 때마다
    메인봇 허용목록을 손으로 추가해야 하는 구경로는 제거했다.
    """
    c = load_json(FILES['paper_score'], {}) or {}
    if not isinstance(c, dict):
        return {}
    if not _paper_score_cache_version_ok(str(c.get('version') or '')):
        return {}
    if str(c.get('schema') or '') != 'paper_score_cache_v086':
        return {}
    if str(c.get('score_scope') or '') != 'current_version_anchor':
        return {}
    if c.get('current_closed_count') is None:
        return {}
    return c


def _score_stat_line(label: str, st: Dict[str, Any]) -> str:
    if not isinstance(st, dict):
        st = {}
    n = int(fnum(st.get('n', st.get('count', 0)), default=0))
    wins = int(fnum(st.get('wins', 0), default=0))
    losses = int(fnum(st.get('losses', 0), default=0))
    wr = fnum(st.get('win_rate', st.get('win_rate_pct', 0)), default=0.0)
    total = fnum(st.get('total', st.get('total_pct', st.get('profit_sum', 0))), default=0.0)
    avg = fnum(st.get('avg', st.get('avg_pct', 0)), default=0.0)
    return f"- {label}: {n}전 {wins}승 {losses}패 / 승률 {wr:.1f}% / 합산 {total:+.2f}% / 평균 {avg:+.2f}%"



def score_text()->str:
    cache = _current_paper_score_cache()
    raw = load_json(FILES['paper_score'], {}) or {}
    lines=["📊 전략별 스코어 /score", "- 목적: 닫힌 paper 결과를 대표전략 기준으로 본다. 중복태그 성과는 참고용."]
    label_map={'money_reaccel_s':'돈흐름 재가속','leader_momentum_s':'주도추세 지속','breakout_early_s':'돌파 초입','sweep_vwap_recovery_s':'저점 VWAP 회복','surge_rebreak_s':'급등 후 재돌파','leader_flow_adaptive_hold_s':'주도흐름 유동보유'}
    if cache:
        gs = cache.get('grade_stats') if isinstance(cache.get('grade_stats'), dict) else {}
        current_n=int(fnum(cache.get('current_closed_count') or 0,0))
        primary_stats = cache.get('strategy_primary_stats') if isinstance(cache.get('strategy_primary_stats'), list) else cache.get('strategy_s_stats') if isinstance(cache.get('strategy_s_stats'), list) else []
        overlap_stats = cache.get('strategy_overlap_stats') if isinstance(cache.get('strategy_overlap_stats'), list) else []
        primary_total=int(fnum(cache.get('strategy_primary_total') or sum(int(fnum(x.get('n') or 0,0)) for x in primary_stats if isinstance(x,dict)),0))
        overlap_total=int(fnum(cache.get('strategy_overlap_total') or sum(int(fnum(x.get('n') or 0,0)) for x in overlap_stats if isinstance(x,dict)),0))
        lines.append(f"- 캐시 age {age(FILES['paper_score']):.1f}s / 현재판 CLOSED {current_n}개 / 대표전략 집계 {primary_total}개")
        lines += [
            _score_stat_line('✅ S 전체', gs.get('S', {})),
            _score_stat_line('현재판 전체', gs.get('ALL', {})),
        ]
        lines += ["", "[대표전략 기준 · 실제 거래수와 맞는 성과]"]
        stat_map={str(st.get('key') or st.get('label') or ''):st for st in primary_stats if isinstance(st,dict)}
        for key,label in label_map.items():
            lines.append(_score_stat_line(label, stat_map.get(key, {})))
        if overlap_stats:
            lines += ["", f"[중복태그 포함 · 참고용 / 합계 {overlap_total}개]"]
            over_map={str(st.get('key') or st.get('label') or ''):st for st in overlap_stats if isinstance(st,dict)}
            for key,label in label_map.items():
                lines.append(_score_stat_line(label, over_map.get(key, {})))
            if overlap_total > current_n:
                lines.append(f"- ⚠️ 중복태그 때문에 참고용 합계가 CLOSED보다 {overlap_total-current_n}개 많습니다.")
    else:
        old_ver = raw.get('version','없음') if isinstance(raw,dict) else '없음'
        old_schema = raw.get('schema','-') if isinstance(raw,dict) else '-'
        lines.append(f"- ✅ 구 score cache 차단: {old_ver} / {old_schema}")
        lines.append("- 현재판 paper_bot score cache 준비중입니다. 예전 승률·수익률은 기본 /score에 섞지 않습니다.")
    strat=load_json(FILES['strategy_summary'],{}) or {}
    pbh=load_json(FILES['paperbot_handoff'],{}) or {}
    if strat:
        router=load_json(FILES.get('target_router', BASE_DIR/'clean_target_router_queue.json'),{}) or {}
        lines += ["", "[현재 후보/정보 흐름]"]
        lines.append(f"- 현재 S {strat.get('s_count',0)} / latest {strat.get('paper_latest_count',0)} / paper 병합 {pbh.get('merged_fresh','-')} / archive {pbh.get('archive_window','-')}")
        lines.append(f"- 정보: 전체 {strat.get('evaluated','-')}개 / 시세 {strat.get('quote_ready_count','-')} / micro {strat.get('micro_ready_count','-')} / 둘다 {strat.get('full_info_ready_count','-')}")
        lines.append(f"- 배차: 전체 {router.get('queue_count','-')} / 내보냄 {router.get('export_count', router.get('active_target_count','-'))} / 대기 {router.get('rotation_wait_count','-')} / 버림 {router.get('dropped_count',0)}")
    return "\n".join(lines)



def quality_text()->str:
    reject=load_json(FILES['strategy_reject'],{}) or {}; strat=load_json(FILES['strategy_summary'],{}) or {}
    hand=load_json(FILES['paper_handoff'],{}) or {}
    pbh=load_json(FILES['paperbot_handoff'],{}) or {}
    latest_lines=line_count(FILES['paper_latest'])
    archive_lines=line_count(FILES['paper_archive'])
    router=load_json(FILES.get('target_router', BASE_DIR/'clean_target_router_queue.json'),{}) or {}
    evaluated=int(fnum(reject.get('evaluated') or strat.get('evaluated') or 0,0))
    quote=int(fnum(reject.get('quote_ready_count') or strat.get('quote_ready_count') or evaluated,0))
    micro=int(fnum(reject.get('micro_ready_count') or strat.get('micro_ready_count') or 0,0))
    both=int(fnum(reject.get('full_info_ready_count') or strat.get('full_info_ready_count') or min(quote,micro),0))
    not_micro=max(0,evaluated-micro) if evaluated else 0
    dropped=int(fnum(router.get('dropped_count') or 0,0))
    rot_wait=int(fnum(router.get('rotation_wait_count') or 0,0))
    need_micro=int(fnum(router.get('need_micro') or reject.get('info_pending_count') or 0,0))
    lines=[
        "🔍 후보품질 /quality",
        f"✅ 전체 {evaluated}개 평가 / 최종 S {strat.get('s_count',0)}개 / paper latest {latest_lines}줄 / 병합 {pbh.get('merged_fresh','-')}",
        "",
        "[정보가 얼마나 채워졌나]",
        f"- 시세: {quote}/{evaluated}개 / 호가·체결: {micro}/{evaluated}개 / 둘다: {both}/{evaluated}개",
        f"- 아직 micro 미신선: {not_micro}개 / 지금 꼭 필요한 micro: {need_micro}개",
        "",
        "[안 넣은 게 아니라 순환 상태]",
        f"- 전체배차 {router.get('queue_count','-')}개 → 이번내보냄 {router.get('export_count', router.get('active_target_count','-'))}개",
        f"- 순환대기 {rot_wait}개 / 버림 {dropped}개 / safety초과 {router.get('export_over_budget_count',0)}개",
        f"- 최우선 {router.get('priority_protected_count','-')}개 / 보호슬롯 req {router.get('strategy_req_total_count','-')}개 / req_micro_target {router.get('strategy_req_micro_target_count','-')}개",
        "",
        "[후보 판정]",
        f"- cheap탈락 {reject.get('cheap_reject_count','-')} / 정보대기 {reject.get('info_pending_count','-')} / 정보불필요 {reject.get('info_not_requested','-')} / fresh완료 {reject.get('fresh_ready_count','-')}",
        f"- paper 전달: strategy handoff {hand.get('paper_latest_count','-')} / archive {'대형' if archive_lines<0 else str(archive_lines)+'줄'}",
    ]
    evs=strat.get('events') if isinstance(strat.get('events'),list) else []
    cur_s=int(fnum(strat.get('s_count') or 0,0))
    lines += ["", "[현재 최종 S 후보 TOP]" if cur_s else "[latest/handoff 후보 TOP · 현재 S 0이면 보관 후보]"]
    if evs:
        for e in evs[:8]:
            lines.append(f"- {'✅' if cur_s else '❔'} {e.get('ticker')} / {e.get('strategy_bucket_primary_label', e.get('strategy_name'))} / 점수 {e.get('score')} / 근거 {', '.join(e.get('reasons',[])[:4])}")
    else: lines.append("- 없음")
    wait_sample=reject.get('priority_wait_sample') if isinstance(reject.get('priority_wait_sample'),list) else []
    micro_payload=load_json(FILES.get('micro_targets', BASE_DIR/'clean_micro_targets.json'),{}) or {}
    micro_targets=set(str(x).upper() for x in (micro_payload.get('targets') if isinstance(micro_payload.get('targets'),list) else []))
    active_targets=set(str(x).upper() for x in ((router.get('active_targets') or router.get('targets')) if isinstance((router.get('active_targets') or router.get('targets')),list) else []))
    lines += ["", "[정보대기 TOP · 왜 아직 못 들어갔나]"]
    if wait_sample:
        for x in wait_sample[:6]:
            t=str(x.get('ticker') or '').upper(); mt_bool=bool(x.get('micro_target')) or t in micro_targets; act_bool=bool(x.get('router_active')) or t in active_targets
            q='✅' if x.get('quote_ready') else '❌'; m='✅' if x.get('micro_ready') else '❌'; mt='✅' if mt_bool else '❌'; a='✅' if act_bool else '❌'
            if (not mt_bool): why='target 미반영'
            elif not x.get('micro_ready'): why='micro 수집대기'
            else: why='확인필요'
            lines.append(f"- {t}: 시세 {q} / micro {m} / target {mt} / active {a} / {why}")
    else:
        lines.append("- 없음")
    lines += ["", "[탈락 사유 TOP]"]
    tops=reject.get('reason_top') if isinstance(reject.get('reason_top'),list) else []
    for x in tops[:12]:
        reason=str(x.get('reason') or '-')
        icon='⚠️' if ('고점' in reason or '손실' in reason or '매도' in reason or '윗꼬리' in reason) else '❔'
        lines.append(f"- {icon} {reason}: {x.get('count')}")
    if not tops: lines.append("- 아직 없음")
    return "\n".join(lines)


def strategy_watch_text()->str:
    strat=load_json(FILES['strategy_summary'],{}) or {}
    hand=load_json(FILES['paper_handoff'],{}) or {}
    lines=["👀 전략 감시 /strategy_watch", "- 전략별 S만 감시. A/B/C는 기본화면에서 제외.", f"- handoff: latest {hand.get('paper_latest_count','-')} / 새S {hand.get('new_s_count','-')} / append {hand.get('archive_appended','-')}"]
    for k,v in (strat.get('strategies') or {}).items(): lines.append(f"- {k}: S {v}")
    evs=strat.get('events') if isinstance(strat.get('events'),list) else []
    lines += ["", "[OPEN 전달 후보]"]
    if evs:
        for e in evs[:10]: lines.append(f"- ✅ {e.get('ticker')} / {e.get('strategy_bucket_primary_label')} / {e.get('score')} / {', '.join(e.get('reasons',[])[:3])}")
    else: lines.append("- 없음")
    return "\n".join(lines)

def errorlog_text()->str:
    path=FILES['brain_error']
    header="🧯 오류로그 /errorlog"
    if not path.exists():
        return header+"\n\n✅ 새 실행 중 오류 없음"
    txt=path.read_text(encoding='utf-8',errors='ignore')
    lines=txt.splitlines()
    # 로그 형식: [YYYY-MM-DD HH:MM:SS] where: Error
    new_lines=[]; old_lines=[]
    for ln in lines[-300:]:
        ts=0.0
        m=re.match(r"\[(\d{4}-\d{2}-\d{2} \d{2}:\d{2}:\d{2})\]", ln)
        if m:
            try:
                ts=time.mktime(time.strptime(m.group(1), "%Y-%m-%d %H:%M:%S"))
            except Exception:
                ts=0.0
        if ts and ts >= START_TS:
            new_lines.append(ln)
        elif '[' in ln:
            old_lines.append(ln)
    out=[header]
    if new_lines:
        out += ["", "❌ 새 실행 이후 오류", *new_lines[-10:]]
    else:
        out += ["", "✅ 새 실행 중 오류 없음"]
        if old_lines:
            out.append(f"- 과거 오류 흔적 {len(old_lines)}줄 있음 / 최근 2개만 참고")
            out += old_lines[-2:]
    return "\n".join(out)

def open_text()->str:
    obj=load_json(FILES['paper_open'],{}) or {}
    lines=["📂 OPEN 요약 /popen_short"]
    if not obj: return "\n".join(lines+["- OPEN 없음"])
    for _,p in list(obj.items())[:12]: lines.append(f"- {p.get('ticker')} / {p.get('strategy_name',p.get('strategy_key','-'))} / {p.get('profit_pct',p.get('current_profit_pct','-'))}%")
    return "\n".join(lines)



def _rows_for_pipe(obj:Any)->List[Any]:
    if isinstance(obj,list): return obj
    if isinstance(obj,dict):
        for k in ("rows","items","targets","active","active_rows","queue","data","symbols"):
            if isinstance(obj.get(k),list): return obj.get(k)
    return []

def _sym_for_pipe(x:Any)->str:
    if isinstance(x,str): v=x
    elif isinstance(x,dict): v=x.get("symbol") or x.get("ticker") or x.get("market") or x.get("coin") or x.get("code") or ""
    else: v=""
    return str(v).replace("KRW-","").replace("_KRW","").replace("/KRW","").upper()

def _set_from_file(path:Path)->set:
    return {_sym_for_pipe(r) for r in _rows_for_pipe(load_json(path,{}) or {}) if _sym_for_pipe(r)}

def pipe_check_text()->str:
    update_brain_status('running')
    paths={
        'ws_targets': BASE_DIR/'clean_ws_targets.json',
        'micro_targets': BASE_DIR/'clean_micro_targets.json',
        'router': BASE_DIR/'clean_target_router_queue.json',
        'strategy_req': BASE_DIR/'clean_strategy_priority_requests.json',
        'strategy': BASE_DIR/'clean_strategy_s_reject_summary.json',
        'orderflow': BASE_DIR/'clean_orderflow_summary_cache.json',
        'ws_status': FILES['ws_status'],
        'micro_status': FILES['micro_status'],
    }
    sets={k:_set_from_file(p) for k,p in paths.items()}
    router=load_json(paths['router'],{}) or {}; reject=load_json(paths['strategy'],{}) or {}; req=load_json(paths['strategy_req'],{}) or {}; of=load_json(paths['orderflow'],{}) or {}; ws=load_json(paths['ws_status'],{}) or {}; mi=load_json(paths['micro_status'],{}) or {}
    of_rows=_rows_for_pipe(of)
    quote_ready=sum(1 for r in of_rows if isinstance(r,dict) and (r.get('quote_fresh') or r.get('ws_fresh')))
    micro_ready=sum(1 for r in of_rows if isinstance(r,dict) and r.get('micro_fresh'))
    full_ready=sum(1 for r in of_rows if isinstance(r,dict) and (r.get('info_ready') or ((r.get('quote_fresh') or r.get('ws_fresh')) and r.get('micro_fresh'))))
    active_ready=sum(1 for r in of_rows if isinstance(r,dict) and r.get('router_active') and (r.get('info_ready') or ((r.get('quote_fresh') or r.get('ws_fresh')) and r.get('micro_fresh'))))
    lines=["🧪 정보배관 점검 /pipe_check", "- SSH 없이 target → orderflow → strategy 병합 상태만 봅니다."]
    lines.append(f"- WS 상태: age {age(paths['ws_status']):.1f}s / fresh {ws.get('fresh','-')} / targets {len(sets['ws_targets'])}")
    lines.append(f"- micro 상태: age {age(paths['micro_status']):.1f}s / fresh {mi.get('fresh','-')} / targets {mi.get('targets','-')} / target파일 {len(sets['micro_targets'])}")
    lines.append(f"- orderflow: rows {len(of_rows)} / quote준비 {quote_ready} / micro준비 {micro_ready} / 둘다준비 {full_ready} / active준비 {active_ready}")
    lines.append(router_flow_summary(router))
    lines.append(f"- router 세부: 이번순환 {router.get('rotation_export_count','-')} / 순환대기 {router.get('rotation_wait_count','-')} / 버림 {router.get('dropped_count',0)} / fresh회복 {router.get('fresh_recovered','-')}")
    lines.append(f"- strategy: 평가 {reject.get('evaluated','-')} / cheap탈락 {reject.get('cheap_reject_count','-')} / 정보필요 {reject.get('info_needed_count','-')} / 정보대기 {reject.get('info_pending_count','-')} / fresh완료 {reject.get('fresh_ready_count','-')} / 병합 {reject.get('orderflow_attached_count','-')}")
    lines.append("")
    checks=[('ws_targets','orderflow'),('micro_targets','orderflow'),('router','ws_targets'),('router','micro_targets'),('strategy_req','orderflow')]
    for a,b in checks:
        lines.append(f"- 겹침 {a}↔{b}: {len(sets[a] & sets[b])}")
    lines.append("")
    if len(sets['ws_targets']) and len(sets['ws_targets'] & sets['orderflow']): lines.append("✅ WS target은 orderflow에 심볼 기준 붙음")
    elif len(sets['ws_targets']): lines.append("❌ WS target은 있으나 orderflow에 심볼이 안 붙음")
    else: lines.append("⚠️ WS active target 없음")
    if len(sets['micro_targets']) and len(sets['micro_targets'] & sets['orderflow']): lines.append("✅ micro target은 orderflow에 심볼 기준 붙음")
    elif len(sets['micro_targets']): lines.append("❌ micro target은 있으나 orderflow에 심볼이 안 붙음")
    else: lines.append("⚠️ micro active target 없음")
    # 전략 요청 후보를 개별로 짧게 보여준다. 흐름이 막히면 여기서 quote/micro/target 중 무엇이 빠졌는지 바로 보인다.
    of_map = { _sym_for_pipe(r): r for r in of_rows if isinstance(r, dict) and _sym_for_pipe(r) }
    req_rows = _rows_for_pipe(req)
    if isinstance(req, dict) and isinstance(req.get('requests'), list):
        req_rows = req.get('requests')
    if req_rows:
        lines += ["", "[전략요청 후보 상태]"]
        for r in req_rows[:8]:
            t=_sym_for_pipe(r)
            ofr=of_map.get(t,{})
            q=bool(ofr.get('quote_fresh') or ofr.get('ws_fresh'))
            m=bool(ofr.get('micro_fresh'))
            a=t in sets['micro_targets']
            active=bool(ofr.get('router_active'))
            qicon='✅' if q else '❌'
            micon='✅' if m else '❌'
            ticon='✅' if a else '❌'
            aicon='✅' if active else '❌'
            need = r.get('need') if isinstance(r,dict) and isinstance(r.get('need'),list) else []
            why=''
            if not a:
                why=' / 원인 microTarget 미반영'
            elif not active:
                why=' / 원인 orderflow active 미표시'
            elif not m:
                why=' / 원인 micro 수집대기'
            lines.append(f"- {t}: quote {qicon} / micro {micon} / microTarget {ticon} / active {aicon} / {r.get('bucket','-') if isinstance(r,dict) else '-'} / need {','.join(need)}{why}")
    if full_ready:
        lines.append("✅ orderflow canonical 정보가 준비된 후보 있음")
    else:
        lines.append("⚠️ orderflow canonical 둘다준비 후보 없음: micro/quote 중 하나가 부족")
    lines.append("- 판단: v340 기준: strategy는 quote_fresh(WS 또는 scanner REST)+micro_fresh를 기준으로 보고, S근접 micro 대기는 우선배차로 따로 추적합니다.")
    return "\n".join(lines)


# -----------------------------
# v343: 메인봇에서 paper 복기/성과 명령을 캐시 전용으로 읽는다.
# paper_bot은 실행/장부/알림 담당, 메인봇은 사용자가 한 방에서 볼 수 있게 요약만 읽는다.
# -----------------------------
STRATEGY_LABELS = {
    'money_reaccel_s': '돈흐름 재가속',
    'leader_momentum_s': '주도추세 지속',
    'breakout_early_s': '돌파 초입',
    'sweep_vwap_recovery_s': '저점 VWAP 회복',
    'surge_rebreak_s': '급등 후 재돌파',
    'leader_flow_adaptive_hold_s': '주도흐름 유동보유',
}

def _short_ticker(v: Any) -> str:
    return str(v or '').upper().replace('KRW-', '').replace('_KRW', '').replace('/KRW', '').replace('KRW', '').strip()

def _paper_open_positions() -> Dict[str, Dict[str, Any]]:
    obj = load_json(FILES['paper_open'], {}) or {}
    return obj if isinstance(obj, dict) else {}

def _paper_score_cache_current() -> Dict[str, Any]:
    return _current_paper_score_cache()

def _stat_line(label: str, st: Dict[str, Any]) -> str:
    return _score_stat_line(label, st)

def _paper_strategy_label(row_or_key: Any) -> str:
    if isinstance(row_or_key, dict):
        k = str(row_or_key.get('strategy_key') or row_or_key.get('primary_strategy_key') or row_or_key.get('representative_strategy_key') or '')
        name = str(row_or_key.get('strategy_bucket_primary_label') or row_or_key.get('strategy_name') or row_or_key.get('strategy') or '')
        if k in STRATEGY_LABELS:
            return STRATEGY_LABELS[k]
        for kk, vv in STRATEGY_LABELS.items():
            if vv in name:
                return vv
        return name or '-'
    k = str(row_or_key or '')
    return STRATEGY_LABELS.get(k, k or '-')

def _paper_grade(row: Dict[str, Any]) -> str:
    g = str(row.get('grade') or row.get('entry_grade') or row.get('signal_grade') or 'S').upper()
    return g if g else 'S'

def pstatus_text() -> str:
    status = load_json(FILES['paper_status'], {}) or {}
    open_pos = _paper_open_positions()
    cache = _paper_score_cache_current()
    hand = load_json(FILES['paperbot_handoff'], {}) or {}
    grade_counts = Counter(_paper_grade(p) for p in open_pos.values() if isinstance(p, dict))
    lines = [
        '🧪 paper 상태 /pstatus · 메인봇 캐시전용',
        '- paper_bot 명령을 메인봇방에서 읽는 요약입니다. 실행/장부/알림은 paper_bot 담당.',
        f"- 상태: {'ON' if status.get('running', True) else '확인필요'} / loop {status.get('loop_sec', status.get('loop_interval_sec', '-'))}s / OPEN {len(open_pos)} / age {age(FILES['paper_status']):.1f}s",
        f"- OPEN: S {grade_counts.get('S',0)} / A {grade_counts.get('A',0)} / B {grade_counts.get('B',0)} / C {grade_counts.get('C',0)} / 제외 {grade_counts.get('X',0)}",
        f"- handoff: latest {hand.get('latest_count', hand.get('paper_latest_count','-'))} / archive창 {hand.get('archive_window','-')} / 병합fresh {hand.get('merged_fresh','-')}",
        f"- 선별배관: 읽음 {status.get('pick_stats',{}).get('paper_file','-') if isinstance(status.get('pick_stats'),dict) else '-'} / S1선택 {status.get('pick_stats',{}).get('v369_s1_selected', status.get('pick_stats',{}).get('v368_s1_open','-')) if isinstance(status.get('pick_stats'),dict) else '-'} / S2보류 {status.get('pick_stats',{}).get('v369_s2_trace','-') if isinstance(status.get('pick_stats'),dict) else '-'} / S3관찰 {status.get('pick_stats',{}).get('v369_s3_trace','-') if isinstance(status.get('pick_stats'),dict) else '-'} / 실제OPEN {status.get('opened_this_cycle','-')}",
    ]
    if cache:
        gs = cache.get('grade_stats') if isinstance(cache.get('grade_stats'), dict) else {}
        current_n = int(fnum(cache.get('current_closed_count') or 0, 0))
        primary_total = int(fnum(cache.get('strategy_primary_total') or 0, 0))
        lines += [
            f"- 성과범위: 현재판 앵커 이후 / {cache.get('anchor_text','-')} / CLOSED {current_n}개 / 대표전략 집계 {primary_total}개",
            '[현재판 성과]',
            _stat_line('✅ S', gs.get('S', {})),
            _stat_line('현재판 전체', gs.get('ALL', {})),
            '- 전략별 상세는 /pscore 또는 /score',
        ]
    else:
        raw = load_json(FILES['paper_score'], {}) or {}
        lines += [
            '- 현재판 score cache 준비중',
            f"- 구버전 성과캐시 무시: {raw.get('version','-')} / {raw.get('schema','-')}",
        ]
    return '\n'.join(lines)

def pscore_text() -> str:
    # 메인봇 /score와 같은 현재판 cache를 사용하되 paper 명령 이름으로 보여준다.
    txt = score_text()
    return txt.replace('📊 전략별 스코어 /score', '📊 paper 전략별 스코어 /pscore · 메인봇 캐시전용', 1)

def _pos_profit_pct(pos: Dict[str, Any]) -> float:
    for k in ('pnl_pct','profit_pct','current_profit_pct','unrealized_pct'):
        if pos.get(k) not in (None, ''):
            return fnum(pos.get(k), 0.0)
    entry = fnum(pos.get('entry_price'), 0.0)
    cur = fnum(pos.get('current_price') or pos.get('last_price'), 0.0)
    if entry > 0 and cur > 0:
        return (cur - entry) / entry * 100.0
    return 0.0

def _pos_entry_price(pos: Dict[str, Any]) -> str:
    v = pos.get('entry_price') or pos.get('entry') or '-'
    try:
        fv = float(str(v).replace(',', ''))
        if fv >= 1000:
            return f"{fv:,.0f}"
        return f"{fv:.4f}"
    except Exception:
        return str(v)

def _pos_current_price(pos: Dict[str, Any]) -> str:
    v = pos.get('current_price') or pos.get('last_price') or pos.get('entry_price') or '-'
    try:
        fv = float(str(v).replace(',', ''))
        if fv >= 1000:
            return f"{fv:,.0f}"
        return f"{fv:.4f}"
    except Exception:
        return str(v)

def _pos_snapshot_flat(pos: Dict[str, Any]) -> Dict[str, Any]:
    ctx = pos.get('entry_context') if isinstance(pos.get('entry_context'), dict) else {}
    snap = ctx.get('entry_snapshot') if isinstance(ctx.get('entry_snapshot'), dict) else pos.get('entry_snapshot') if isinstance(pos.get('entry_snapshot'), dict) else {}
    vals: Dict[str, Any] = {}
    if isinstance(snap, dict):
        flat = snap.get('flat')
        if isinstance(flat, dict): vals.update(flat)
        for gname in ('price_flow','position','money_flow','orderflow','risk','strategy'):
            g = snap.get(gname)
            if isinstance(g, dict):
                for k, v in g.items(): vals.setdefault(k, v)
    if isinstance(ctx, dict):
        for k, v in ctx.items(): vals.setdefault(k, v)
    for k, v in pos.items():
        if k not in vals and k not in {'entry_context','entry_snapshot'}:
            vals[k] = v
    return vals

def _pos_hold_sec(pos: Dict[str, Any]) -> float:
    for k in ('hold_sec','age_sec'):
        v = fnum(pos.get(k), default=-1.0)
        if v > 0:
            return v
    for k in ('opened_at','entry_ts','open_ts','opened_ts','created_at','start_ts'):
        v = pos.get(k)
        ts = fnum(v, default=0.0)
        if ts > 10_000_000_000:
            ts = ts / 1000.0
        if ts <= 0 and isinstance(v, str):
            try:
                # ISO/text time fallback. timezone 없는 서버 로컬 기준.
                ts = time.mktime(time.strptime(v[:19].replace('T',' '), '%Y-%m-%d %H:%M:%S'))
            except Exception:
                ts = 0.0
        if ts > 0:
            return max(0.0, now_ts() - ts)
    return 0.0

def popen_text() -> str:
    open_pos = _paper_open_positions()
    lines = ['📂 paper OPEN /popen · 메인봇 캐시전용']
    if not open_pos:
        return '\n'.join(lines + ['OPEN 없음'])
    rows = [p for p in open_pos.values() if isinstance(p, dict)]
    rows.sort(key=lambda p: fnum(p.get('opened_at') or p.get('entry_ts') or 0, 0), reverse=True)
    by_strategy = Counter(_paper_strategy_label(p) for p in rows)
    lines.append('전략별 OPEN: ' + ' / '.join(f'{k} {v}' for k, v in by_strategy.items()))
    for p in rows[:10]:
        t = _short_ticker(p.get('ticker') or p.get('symbol'))
        pnl = _pos_profit_pct(p)
        hold = _pos_hold_sec(p)
        vals = _pos_snapshot_flat(p)
        buy = vals.get('buy_ratio') or vals.get('micro_trade_buy_ratio_30') or '-'
        reason = p.get('reason') or p.get('entry_reason') or p.get('watch_note') or 'time_exit 대기'
        try: buy_txt = f"{float(buy):.2f}"
        except Exception: buy_txt = str(buy)
        lines.append(f"- ✅ {_paper_grade(p)}급 {t} / {_paper_strategy_label(p)} / 진입 {_pos_entry_price(p)} / 현재 {_pos_current_price(p)} / {pnl:+.2f}% / 보유 {int(hold//60)}분 {int(hold%60)}초 / 감시 {reason}")
        lines.append(f"  · 근거: 매수체결 {buy_txt} / 주의: {p.get('risk_label') or p.get('risk_tags') or '특이사항 없음'}")
    if len(rows) > 10:
        lines.append(f"- 나머지 {len(rows)-10}개는 paper_bot /popen 단독 또는 이후 full에서 확인")
    return '\n'.join(lines)


# =============================================================================
# v347: paper review canonical module
# - 기존 v341~v346에서 덧붙은 preview/missed_review override들을 제거하고
#   단일 canonical 경로로 재작성한다.
# - 목적: /preview가 어떤 필드 타입(dict/float/list/None)을 만나도 죽지 않게 하고,
#   놓친 후보 추적/손실 복기 판단을 한 곳에서만 수행한다.
# =============================================================================

def as_dict(v: Any) -> Dict[str, Any]:
    return v if isinstance(v, dict) else {}

def as_list(v: Any) -> List[Any]:
    if isinstance(v, list):
        return v
    if isinstance(v, tuple):
        return list(v)
    return []

def first_value(*vals: Any, default: Any = None) -> Any:
    for v in vals:
        if v is None or v == "":
            continue
        return v
    return default

def price_from_any(v: Any) -> float:
    """dict/float/int/str/list 어떤 형태든 current price 후보를 안전하게 숫자로 변환."""
    if isinstance(v, dict):
        return fnum(v.get('current_price'), v.get('price'), v.get('trade_price'), v.get('close'), v.get('last'), default=0.0)
    if isinstance(v, (int, float, str)):
        return fnum(v, default=0.0)
    return 0.0

def _event_ts(ev: Dict[str, Any]) -> float:
    row = as_dict(ev)
    return fnum(
        row.get('candidate_created_at'), row.get('source_created_at'), row.get('detected_ts'),
        row.get('event_ts'), row.get('created_at'), row.get('timestamp'), default=0.0
    )

def _primary_strategy_key(row: Dict[str, Any]) -> str:
    row = as_dict(row)
    ctx = as_dict(row.get('entry_context'))
    snap = as_dict(row.get('entry_snapshot') or ctx.get('entry_snapshot'))
    strat = as_dict(snap.get('strategy'))
    candidates = [
        row.get('representative_strategy_key'), row.get('primary_strategy_key'), row.get('paper_strategy_key'),
        row.get('strategy_bucket_primary'), row.get('strategy_key'), row.get('strategy'), row.get('strategy_name'),
        row.get('strategy_label'), row.get('strategy_bucket_primary_label'),
        ctx.get('representative_strategy_key'), ctx.get('primary_strategy_key'), ctx.get('paper_strategy_key'),
        ctx.get('strategy_bucket_primary'), ctx.get('strategy_key'), ctx.get('strategy'), ctx.get('strategy_name'),
        ctx.get('strategy_bucket_primary_label'), strat.get('primary_key'), strat.get('primary_label')
    ]
    for v in candidates:
        text = str(v or '')
        if not text:
            continue
        if text in STRATEGY_LABELS:
            return text
        for k, label in STRATEGY_LABELS.items():
            if k in text or label in text or f'{label} S' in text:
                return k
    for vals in (
        row.get('multi_strategy_s'), row.get('strategy_bucket_keys'), ctx.get('multi_strategy_s'),
        ctx.get('strategy_bucket_keys'), strat.get('tags')
    ):
        for x in as_list(vals):
            text = str(x or '')
            if text in STRATEGY_LABELS:
                return text
            for k, label in STRATEGY_LABELS.items():
                if k in text or label in text:
                    return k
    return 'unknown'

def _paper_anchor_ts() -> float:
    c = _paper_score_cache_current()
    if isinstance(c, dict) and c:
        return fnum(c.get('anchor_ts'), c.get('current_anchor_ts'), default=0.0)
    a = load_json(FILES.get('score_anchor', BASE_DIR/'paper_bot_current_score_anchor.json'), {}) or {}
    return fnum(as_dict(a).get('anchor_ts'), default=0.0)

def _paper_current_closed_rows(max_lines:int=2600) -> List[Dict[str, Any]]:
    rows = read_jsonl(FILES.get('paper_closed', BASE_DIR/'paper_bot_closed.jsonl'), max_lines=max_lines)
    anchor = _paper_anchor_ts()
    if not anchor:
        return rows
    out=[]
    for r in rows:
        if not isinstance(r, dict):
            continue
        ts = fnum(r.get('closed_at'), r.get('closed_ts'), r.get('close_ts'), r.get('timestamp'), default=0.0)
        ots = fnum(r.get('opened_at'), r.get('entry_ts'), r.get('open_ts'), default=0.0)
        if max(ts, ots) >= anchor:
            out.append(r)
    return out

def _snapshot_flat(row: Dict[str, Any]) -> Dict[str, Any]:
    """entry_context/entry_snapshot nested group을 안전하게 평탄화한다."""
    row = as_dict(row)
    ctx = as_dict(row.get('entry_context'))
    snap = as_dict(row.get('entry_snapshot') or ctx.get('entry_snapshot'))
    vals: Dict[str, Any] = {}
    for gname in ('price_flow','position','money_flow','orderflow','risk','strategy'):
        g = as_dict(snap.get(gname))
        vals.update({k:v for k,v in g.items() if k not in vals})
    vals.update({k:v for k,v in ctx.items() if k not in vals and k != 'entry_snapshot'})
    vals.update({k:v for k,v in row.items() if k not in vals and k not in {'entry_context','entry_snapshot'}})
    return vals

def _loss_causes(row: Dict[str, Any]) -> List[str]:
    row = as_dict(row); ctx=_snapshot_flat(row)
    causes=[]
    pnl=fnum(row.get('pnl_pct'), row.get('profit_pct'), row.get('return_pct'), default=0.0)
    peak=fnum(row.get('peak_pct'), row.get('max_profit_pct'), row.get('max_pnl_pct'), default=0.0)
    trough=fnum(row.get('trough_pct'), row.get('min_profit_pct'), row.get('min_pnl_pct'), default=0.0)
    hold=fnum(row.get('hold_sec'), row.get('duration_sec'), default=0.0)
    spread=fnum(ctx.get('spread_pct'), default=-1.0)
    buy=fnum(ctx.get('buy_ratio'), ctx.get('micro_trade_buy_ratio_30'), ctx.get('buy_trade_ratio'), default=-1.0)
    buy_s=fnum(ctx.get('buy_ratio_1m'), ctx.get('micro_buy_ratio_sustain_1m'), ctx.get('buy_ratio_sustain'), default=-1.0)
    vwap=fnum(ctx.get('vwap_gap_pct'), default=999.0)
    ema=fnum(ctx.get('ema5_gap_pct'), ctx.get('ema_gap_pct'), default=999.0)
    ch3=fnum(ctx.get('change_3m'), ctx.get('price_change_3m'), default=999.0)
    ch5=fnum(ctx.get('change_5m'), ctx.get('price_change_5m'), default=999.0)
    if pnl < 0:
        if peak <= 0.10: causes.append('진입후반응없음(최고+0.1%이하)')
        elif peak <= 0.30: causes.append('반응약함(최고+0.3%이하)')
        if hold and hold <= 180: causes.append('초반빠른손실(3분이내)')
        if trough <= -0.70: causes.append('깊은역행')
    if spread >= 0.28: causes.append('스프레드넓음')
    if 0 <= buy < 0.65: causes.append('매수체결약함')
    if 0 <= buy_s < 0.60: causes.append('매수체결지속약함')
    if ctx.get('sell_pressure') or ctx.get('ask_wall_pressure') or ctx.get('sell_trade_pressure'):
        causes.append('매도압력')
    if vwap != 999.0 and vwap < -0.15: causes.append('VWAP아래')
    if ema != 999.0 and ema < -0.20: causes.append('EMA아래')
    if ch3 != 999.0 and ch5 != 999.0 and ch3 <= 0.05 and ch5 <= 0.10:
        causes.append('가격반응부족')
    if not any(k in ctx for k in ('change_3m','price_change_3m','vwap_gap_pct','buy_ratio','spread_pct')):
        causes.append('근거스냅샷부족')
    if not causes and pnl < 0:
        causes.append('기타손실')
    # 중복 제거, 순서 유지
    out=[]
    for c in causes:
        if c not in out: out.append(c)
    return out

def ploss_review_text() -> str:
    rows=_paper_current_closed_rows()
    losses=[r for r in rows if fnum(r.get('pnl_pct'), r.get('profit_pct'), default=0.0)<0]
    wins=[r for r in rows if fnum(r.get('pnl_pct'), r.get('profit_pct'), default=0.0)>0]
    cc=Counter(); by={k:[] for k in STRATEGY_LABELS}; sc={k:Counter() for k in STRATEGY_LABELS}; unknown=[]
    for r in losses:
        key=_primary_strategy_key(r)
        if key not in STRATEGY_LABELS:
            unknown.append(r); key='unknown'
        by.setdefault(key,[]).append(r); sc.setdefault(key,Counter())
        for cause in _loss_causes(r):
            cc[cause]+=1; sc[key][cause]+=1
    lines=['🧯 손실 원인 복기 /ploss_review · 메인봇 캐시전용', '- 현재판 CLOSED 손실에서 공통 패배 패턴을 봅니다.', f'- 현재판 CLOSED {len(rows)}개 / 승리 {len(wins)}개 / 손실 {len(losses)}개 / 미분류손실 {len(unknown)}개', '', '[공통 손실 TOP]']
    if cc:
        for k,v in cc.most_common(10): lines.append(f'- ⚠️ {k}: {v}개')
    else:
        lines.append('- 아직 손실 표본 없음')
    lines += ['', '[전략별 손실 원인 · 대표전략 기준]']
    for k,label in STRATEGY_LABELS.items():
        sub=by.get(k,[]); tops=', '.join(f'{a} {b}' for a,b in sc.get(k,Counter()).most_common(3)) or '-'
        lines.append(f'- {label}: 손실 {len(sub)}개 / {tops}')
    if unknown:
        tops=', '.join(f'{a} {b}' for a,b in sc.get('unknown',Counter()).most_common(3)) or '-'
        lines.append(f'- 미분류: 손실 {len(unknown)}개 / {tops}')
    lines += ['', '[조건 설계 힌트]']
    if cc.get('진입후반응없음(최고+0.1%이하)',0) >= max(3, len(losses)*0.25): lines.append('- 진입 전/직후 가격반응 조건을 전략별로 넣을 가치가 큼')
    if cc.get('매수체결약함',0) or cc.get('매수체결지속약함',0): lines.append('- 매수체결 순간값보다 지속성 조건을 봐야 함')
    if cc.get('매도압력',0): lines.append('- 매도벽/매도체결압력은 공통 하드차단이 아니라 전략별 강도 조절 필요')
    if cc.get('근거스냅샷부족',0): lines.append('- 일부 구 OPEN/CLOSED는 snapshot 부족. 신규 snapshot CLOSED를 더 신뢰')
    return '\n'.join(lines)

def _market_price_map() -> Dict[str, Dict[str, Any]]:
    """시장 가격 map을 항상 dict 형태로 반환한다. 기존 float 반환 경로 제거."""
    out: Dict[str, Dict[str, Any]] = {}
    for p in (FILES['scanner_market'], FILES['feature'], FILES['orderflow']):
        obj=load_json(p,{}) or {}; rows=[]
        if isinstance(obj, list):
            rows=obj
        elif isinstance(obj, dict):
            for key in ('rows','items','data'):
                if isinstance(obj.get(key), list):
                    rows=obj.get(key); break
            if not rows and isinstance(obj.get('cache'), dict):
                for k,v in obj.get('cache',{}).items():
                    if isinstance(v,dict):
                        vv=dict(v); vv.setdefault('ticker',k); rows.append(vv)
        for r in rows or []:
            if not isinstance(r,dict):
                continue
            t=norm_ticker(r.get('ticker') or r.get('symbol') or r.get('market'))
            price=price_from_any(r)
            if t and price>0:
                cur=out.setdefault(t, {})
                cur['current_price']=price
                cur.setdefault('source', p.name)
    return out

def _candidate_norm(ev: Dict[str, Any]) -> Dict[str, Any]:
    row=dict(as_dict(ev))
    raw_id = first_value(row.get('event_id'), row.get('event_key'), row.get('trace_id'), row.get('handoff_id'), row.get('candidate_uid'), row.get('id'))
    t=norm_ticker(row.get('ticker') or row.get('market') or row.get('symbol')) or 'UNKNOWN'
    sk=_primary_strategy_key(row) or 'strategy_s'
    ts=_event_ts(row) or now_ts()
    eid=str(raw_id or f"ev:{t}:{sk}:{int(ts//30)}")
    row['event_id']=eid; row['event_key']=eid
    row.setdefault('trace_id', eid); row.setdefault('handoff_id', eid); row.setdefault('candidate_uid', eid)
    if not raw_id:
        row.setdefault('event_id_origin','legacy_fallback')
    return row

def _candidate_keys(ev: Dict[str, Any]) -> set:
    row=_candidate_norm(ev); keys=set()
    for k in ('event_id','event_key','trace_id','handoff_id','candidate_uid','pos_id'):
        v=row.get(k)
        if v not in (None,'','-'): keys.add(str(v))
    t=norm_ticker(row.get('ticker') or row.get('market') or row.get('symbol')) or ''
    sk=_primary_strategy_key(row); ts=_event_ts(row)
    if t and sk and ts:
        keys.add(f'fb:{t}:{sk}:{int(ts//30)}')
        keys.add(f'fbm:{t}:{sk}:{int(ts//60)}')
    if t: keys.add(f'ticker:{t}')
    return keys

def _open_closed_candidate_keys():
    open_rows=[]
    try:
        op=load_json(BASE_DIR/'paper_open_positions.json',{})
        if isinstance(op,dict): open_rows=list(op.values())
    except Exception: pass
    closed_rows = _paper_current_closed_rows(max_lines=2600)
    open_keys=set(); closed_keys=set(); open_tickers=set()
    for p in open_rows:
        if isinstance(p,dict):
            open_keys |= _candidate_keys(p)
            t=norm_ticker(p.get('ticker') or p.get('market') or p.get('symbol')) or ''
            if t: open_tickers.add(t)
    for r in closed_rows:
        if isinstance(r,dict):
            closed_keys |= _candidate_keys(r)
            src=as_dict(r.get('source_event'))
            if src: closed_keys |= _candidate_keys(src)
    return open_keys, closed_keys, open_tickers



# v349: preview/missed_review/open-closed key canonical alias.
# 기존 pmissed_review 계열에서 _open_closed_keys 이름을 쓰는 경로와
# _open_closed_candidate_keys 이름을 쓰는 경로를 하나로 통일한다.
def _open_closed_keys():
    return _open_closed_candidate_keys()

def _merged_candidate_keys():
    rows=[]
    for name in ['paper_candidates_handoff_merged.jsonl','paper_candidates_latest.jsonl']:
        try: rows += read_jsonl(BASE_DIR/name, max_lines=500)
        except Exception: pass
    keys=set()
    for r in rows:
        if isinstance(r,dict): keys |= _candidate_keys(r)
    return keys

def _missed_reason(row: Dict[str,Any], merged_keys=None) -> str:
    row=_candidate_norm(row); nowv=now_ts(); reasons=[]
    keys=_candidate_keys(row); merged_keys=merged_keys if merged_keys is not None else _merged_candidate_keys()
    exp=fnum(row.get('expires_at'), default=0.0); ts=_event_ts(row)
    if exp and exp < nowv: reasons.append('handoff만료')
    if ts and nowv-ts>180: reasons.append('후보오래됨')
    if not (keys & merged_keys): reasons.append('paper미병합')
    ctx=as_dict(row.get('entry_context'))
    if not (row.get('micro_fresh') or ctx.get('micro_fresh')): reasons.append('micro미확인')
    if row.get('stale') or row.get('is_stale'): reasons.append('stale')
    if row.get('open_eligible') is False or row.get('paper_bot_open') is False: reasons.append('open_eligible_false')
    if row.get('event_id_origin') == 'legacy_fallback': reasons.append('구후보ID보정')
    if not reasons: reasons.append('paper미병합/만료확인')
    out=[]
    for r in reasons:
        if r not in out: out.append(r)
    return ','.join(out[:5])

def pmissed_review_text() -> str:
    anchor_ts = _paper_anchor_ts()
    events=[]
    for name,maxn in [('paper_candidates.jsonl',1000),('paper_candidates_latest.jsonl',250)]:
        try: events += read_jsonl(BASE_DIR/name, max_lines=maxn)
        except Exception: pass
    market = _market_price_map()
    open_keys, closed_keys, open_tickers = _open_closed_candidate_keys()
    merged_keys = _merged_candidate_keys()
    seen=set(); missed=[]; watched=0; counter=Counter()
    for raw in events:
        if not isinstance(raw,dict): continue
        ev=_candidate_norm(raw); ts=_event_ts(ev)
        if anchor_ts and ts and ts<anchor_ts: continue
        t=norm_ticker(ev.get('ticker') or ev.get('market') or ev.get('symbol')) or ''
        if not t: continue
        keys=_candidate_keys(ev); dedupe=str(ev.get('event_id') or f'{t}:{_primary_strategy_key(ev)}:{int(ts//30) if ts else 0}')
        if dedupe in seen: continue
        seen.add(dedupe); watched+=1
        if (keys & closed_keys) or (keys & open_keys) or t in open_tickers: continue
        cur=market.get(t,{}) if isinstance(market,dict) else {}
        cur_price=price_from_any(cur)
        entry=fnum(ev.get('entry_price'), ev.get('current_price'), ev.get('detected_price'), default=0.0)
        if cur_price<=0 or entry<=0: continue
        gain=(cur_price-entry)/entry*100.0
        if gain>=0.70:
            why=_missed_reason(ev, merged_keys)
            for r in why.split(','):
                if r: counter[r]+=1
            rs=ev.get('reasons') or ev.get('final_entry_reasons') or []
            missed.append({'ticker':t,'gain':gain,'strategy':ev.get('strategy_bucket_primary_label') or ev.get('strategy_name') or ev.get('strategy'), 'score':ev.get('score'), 'reasons':rs if isinstance(rs,list) else [], 'missed_reason':why})
    missed.sort(key=lambda x:x.get('gain',0), reverse=True)
    lines=['🔎 놓친 후보 복기 /pmissed_review · 메인봇 캐시전용','- 후보 archive/latest 중 OPEN/CLOSED로 이어지지 않았는데 이후 오른 코인을 봅니다.',f'- 확인 후보 {watched}개 / 현재가 비교 가능 상승후보 {len(missed)}개','','[놓친 이유 추정 TOP]']
    if counter:
        for k,v in counter.most_common(10):
            icon='⚠️' if k in {'paper미병합','handoff만료','후보오래됨','micro미확인'} else '❔'
            lines.append(f'- {icon} {k}: {v}개')
    else:
        lines.append('- 아직 분류할 상승후보 없음')
    lines += ['', '[이후 오른 후보 TOP]']
    if missed:
        for m in missed[:10]:
            rs=m.get('reasons') if isinstance(m.get('reasons'),list) else []
            lines.append(f"- {'⚠️' if m['gain']>=1.5 else '❔'} {m['ticker']} / +{m['gain']:.2f}% / {m.get('strategy','-')} / 점수 {m.get('score','-')} / 놓친이유 {m.get('missed_reason','-')} / 근거 {', '.join(map(str, rs[:3]))}")
    else:
        lines.append('- 아직 뚜렷한 놓친 상승후보 없음')
    lines += ['', '[판독]', '- 자주 오르는 패턴은 조건에서 죽이면 안 됨', '- paper미병합/만료/오래됨이 많으면 전략조건보다 handoff·진입타이밍 문제를 먼저 봅니다', '- 손실필터는 /ploss_review와 같이 봐야 합니다']
    return '\n'.join(lines)

def preview_text() -> str:
    # 단일 canonical preview: loss + missed를 각각 보호 실행해 한쪽 오류가 전체를 죽이지 않게 한다.
    parts=[]
    for title, fn in [('ploss_review', ploss_review_text), ('pmissed_review', pmissed_review_text)]:
        try:
            parts.append(fn())
        except Exception as exc:
            log_error(f'preview_{title}', exc)
            parts.append(f'❌ {title} 생성 오류: {exc.__class__.__name__}: {exc}')
    return '\n\n'.join(parts)



# =============================================================================
# v348: missed trace / handoff canonical review
# - paper_bot_v0.91의 candidate_handoff_trace를 우선 사용한다.
# - 같은 ticker/전략의 중복 놓친 후보는 1개로 합친다.
# - 조건 판단 전, 왜 paper OPEN으로 이어지지 않았는지 추적한다.
# =============================================================================

def _v348_trace_rows() -> List[Dict[str, Any]]:
    obj = load_json(FILES.get('candidate_handoff_trace', BASE_DIR/'paper_bot_candidate_handoff_trace.json'), {}) or {}
    rows = obj.get('rows') if isinstance(obj, dict) else []
    return [r for r in rows if isinstance(r, dict)] if isinstance(rows, list) else []


def _v348_trace_map() -> Dict[str, Dict[str, Any]]:
    out: Dict[str, Dict[str, Any]] = {}
    for r in _v348_trace_rows():
        t = norm_ticker(r.get('ticker') or r.get('market') or r.get('symbol'))
        sk = _primary_strategy_key(r) or str(r.get('strategy_key') or r.get('strategy') or '')
        for k in [str(r.get('event_id') or ''), str(r.get('event_key') or ''), str(r.get('trace_id') or ''), str(r.get('handoff_id') or ''), f'{t}:{sk}']:
            if k and k != '-':
                out[k] = r
    return out


def _v348_trace_for_candidate(ev: Dict[str, Any], trace_map: Optional[Dict[str, Dict[str, Any]]] = None) -> Dict[str, Any]:
    trace_map = trace_map or _v348_trace_map()
    t = norm_ticker(ev.get('ticker') or ev.get('market') or ev.get('symbol'))
    sk = _primary_strategy_key(ev) or str(ev.get('strategy_key') or ev.get('strategy') or '')
    keys = [str(ev.get('event_id') or ''), str(ev.get('event_key') or ''), str(ev.get('trace_id') or ''), str(ev.get('handoff_id') or ''), str(ev.get('candidate_uid') or ''), f'{t}:{sk}']
    for k in keys:
        if k and k in trace_map:
            return trace_map[k]
    return {}


def _v348_reason_from_trace(ev: Dict[str, Any], trace: Dict[str, Any], fallback: str = '') -> str:
    vals: List[str] = []
    for src in (trace, ev):
        for key in ('reason', 'missed_reason', 'status_reason'):
            v = src.get(key) if isinstance(src, dict) else None
            if isinstance(v, list):
                vals += [str(x) for x in v if str(x)]
            elif v not in (None, '', '-'):
                vals += [x.strip() for x in str(v).split(',') if x.strip()]
    if fallback:
        vals += [x.strip() for x in str(fallback).split(',') if x.strip()]
    if trace:
        st = str(trace.get('status') or '')
        if st and st not in {'candidate','unknown'}:
            vals.append(st)
    out=[]
    for v in vals:
        if v and v not in out:
            out.append(v)
    return ','.join(out[:6]) if out else 'paper미병합/만료확인'


def missed_trace_text() -> str:
    obj = load_json(FILES.get('candidate_handoff_trace', BASE_DIR/'paper_bot_candidate_handoff_trace.json'), {}) or {}
    rows = _v348_trace_rows()
    by_status = Counter(str(r.get('status') or 'unknown') for r in rows)
    reasons = Counter()
    for r in rows:
        for x in str(r.get('reason') or '').split(','):
            x=x.strip()
            if x: reasons[x]+=1
    lines = [
        '🧭 놓친 후보 추적 /missed_trace',
        '- strategy 후보 → handoff → paper 병합/OPEN/CLOSED 흐름을 추적합니다.',
        f"- trace age {age(FILES.get('candidate_handoff_trace', BASE_DIR/'paper_bot_candidate_handoff_trace.json')):.1f}s / rows {len(rows)} / version {obj.get('version','-') if isinstance(obj,dict) else '-'}",
        '', '[상태 TOP]'
    ]
    if by_status:
        for k,v in by_status.most_common(8):
            icon = '✅' if k in {'open','closed'} else '⚠️' if k in {'expired','not_merged','merged_waiting_open'} else '❔'
            lines.append(f'- {icon} {k}: {v}개')
    else:
        lines.append('- trace 없음')
    lines += ['', '[이유 TOP]']
    if reasons:
        for k,v in reasons.most_common(10):
            icon = '⚠️' if k in {'paper미병합','handoff만료','후보오래됨','micro미확인','picked_not_opened'} else '❔'
            lines.append(f'- {icon} {k}: {v}개')
    else:
        lines.append('- 이유 없음')
    lines += ['', '[주의 후보 TOP]']
    risky = [r for r in rows if str(r.get('status') or '') not in {'open','closed'}]
    risky.sort(key=lambda r: (float(first_value(r.get('score'),0) or 0), float(first_value(r.get('created_at'),0) or 0)), reverse=True)
    seen_risky=set(); shown=0
    for r in risky:
        t = norm_ticker(r.get('ticker'))
        sk = str(r.get('strategy_key') or r.get('strategy') or '-')
        key = f'{t}:{sk}:{r.get("status","-")}:{r.get("reason","-")}'
        if key in seen_risky:
            continue
        seen_risky.add(key); shown += 1
        lines.append(f"- ⚠️ {t} / {r.get('strategy') or r.get('strategy_key','-')} / score {r.get('score','-')} / status {r.get('status','-')} / 이유 {r.get('reason','-')}")
        if shown >= 10:
            break
    if not risky:
        lines.append('- 현재 주의 후보 없음')
    elif len(seen_risky) < len(risky):
        lines.append(f'- 중복 후보 {len(risky)-len(seen_risky)}개는 묶어서 숨김')
    return '\n'.join(lines)


def pmissed_review_text() -> str:  # type: ignore[override]
    anchor_ts = _paper_anchor_ts()
    events=[]
    for name,maxn in [('paper_candidates.jsonl',1200),('paper_candidates_latest.jsonl',300)]:
        events += read_jsonl(BASE_DIR/name, max_lines=maxn)
    market = _market_price_map()
    open_ids, closed_ids, open_tickers = _open_closed_keys()
    trace_map = _v348_trace_map()
    nowv=now_ts(); watched=0; by_key: Dict[str, Dict[str, Any]] = {}; reason_counter=Counter()
    for raw in events:
        if not isinstance(raw, dict):
            continue
        ev = ensure_event_id(raw)
        ts = float(first_value(ev.get('created_at'), ev.get('candidate_created_at'), ev.get('detected_ts'), ev.get('event_ts'), 0) or 0)
        if anchor_ts and ts and ts < anchor_ts:
            continue
        t=norm_ticker(ev.get('ticker') or ev.get('market') or ev.get('symbol'))
        if not t:
            continue
        watched += 1
        keys=_candidate_keys(ev)
        if (keys & open_ids) or (keys & closed_ids) or t in open_tickers:
            continue
        cur = market.get(t, {})
        cur_price = price_from_any(cur)
        entry = float(first_value(ev.get('entry_price'), ev.get('current_price'), ev.get('detected_price'), ev.get('price'), 0) or 0)
        if cur_price <= 0 or entry <= 0:
            continue
        gain = (cur_price-entry)/entry*100.0
        if gain < 0.70:
            continue
        trace = _v348_trace_for_candidate(ev, trace_map)
        why = _v348_reason_from_trace(ev, trace, _missed_reason(ev, set()))
        for x in why.split(','):
            if x: reason_counter[x]+=1
        sk = _primary_strategy_key(ev) or str(ev.get('strategy_key') or ev.get('strategy') or '')
        dedupe = f'{t}:{sk}'
        item = {'ticker':t,'gain':gain,'strategy':ev.get('strategy_bucket_primary_label') or ev.get('strategy_name') or ev.get('strategy') or trace.get('strategy'), 'score':ev.get('score') or trace.get('score'), 'reasons':ev.get('reasons') or ev.get('final_entry_reasons') or [], 'missed_reason':why, 'trace_status':trace.get('status','-') if trace else '-'}
        old = by_key.get(dedupe)
        if old is None or gain > float(old.get('gain',0)):
            by_key[dedupe]=item
    missed=list(by_key.values()); missed.sort(key=lambda x:x.get('gain',0), reverse=True)
    lines=['🔎 놓친 후보 복기 /pmissed_review · 메인봇 캐시전용', '- 후보 archive/latest 중 OPEN/CLOSED로 이어지지 않았는데 이후 오른 코인을 봅니다.', f'- 확인 후보 {watched}개 / 중복제거 상승후보 {len(missed)}개', '', '[놓친 이유 추정 TOP]']
    if reason_counter:
        for k,v in reason_counter.most_common(10):
            icon='⚠️' if k in {'paper미병합','handoff만료','후보오래됨','micro미확인','picked_not_opened'} else '❔'
            lines.append(f'- {icon} {k}: {v}개')
    else:
        lines.append('- 아직 분류할 상승후보 없음')
    lines += ['', '[이후 오른 후보 TOP]']
    if missed:
        for m in missed[:10]:
            rs=m.get('reasons') if isinstance(m.get('reasons'), list) else []
            lines.append(f"- {'⚠️' if m['gain']>=1.5 else '❔'} {m['ticker']} / +{m['gain']:.2f}% / {m.get('strategy','-')} / 점수 {m.get('score','-')} / 상태 {m.get('trace_status','-')} / 놓친이유 {m.get('missed_reason','-')} / 근거 {', '.join(map(str, rs[:3]))}")
    else:
        lines.append('- 아직 뚜렷한 놓친 상승후보 없음')
    lines += ['', '[판독]', '- 자주 오르는 패턴은 조건에서 죽이면 안 됨', '- paper미병합/만료/오래됨이 많으면 전략조건보다 handoff·진입타이밍 문제를 먼저 봅니다', '- 손실필터는 /ploss_review와 같이 봐야 합니다']
    return '\n'.join(lines)


def preview_text() -> str:  # type: ignore[override]
    parts=[]
    for title, fn in [('ploss_review', ploss_review_text), ('pmissed_review', pmissed_review_text)]:
        try:
            parts.append(fn())
        except Exception as exc:
            log_error(f'preview_{title}', exc)
            parts.append(f'⚠️ {title} 출력 오류: {type(exc).__name__}: {exc}')
    return '\n\n'.join(parts)



# =============================================================================
# v354: main review canonical final layer
# v355: score cache version gate는 목록식 whitelist 대신 paper_bot_v0.86+ 숫자 판정으로 단일화
# - preview/missed_trace에서 이름 누락/중복 override가 다시 타지 않도록 최종 단일 함수를 둔다.
# - 전략/청산/자동매수에는 관여하지 않고, paper_bot_v0.92 trace/cache를 읽는 조회 전용이다.
# =============================================================================

def _v354_trace_rows() -> List[Dict[str, Any]]:
    obj = load_json(FILES.get('candidate_handoff_trace', BASE_DIR/'paper_bot_candidate_handoff_trace.json'), {}) or {}
    rows = obj.get('rows') if isinstance(obj, dict) else []
    return [r for r in rows if isinstance(r, dict)] if isinstance(rows, list) else []

def _v354_trace_map() -> Dict[str, Dict[str, Any]]:
    out: Dict[str, Dict[str, Any]] = {}
    priority = {'closed': 60, 'open': 55, 'picked': 50, 'merged_waiting_pick': 40, 'micro_wait': 35, 'not_merged': 25, 'expired': 10, 'skipped': 5}
    for r in _v354_trace_rows():
        t = norm_ticker(r.get('ticker') or r.get('market') or r.get('symbol'))
        sk = _primary_strategy_key(r) or str(r.get('strategy_key') or r.get('strategy') or '')
        ts = fnum(r.get('created_at') or r.get('updated_at'), default=0.0)
        keys = [r.get('event_id'), r.get('event_key'), r.get('trace_id'), r.get('handoff_id'), r.get('candidate_uid'), f'{t}:{sk}']
        for k in keys:
            k=str(k or '')
            if not k or k == '-':
                continue
            old = out.get(k)
            if old is None:
                out[k] = r
                continue
            old_score = priority.get(str(old.get('status') or ''), 0)
            new_score = priority.get(str(r.get('status') or ''), 0)
            old_ts = fnum(old.get('created_at') or old.get('updated_at'), default=0.0)
            # 같은 ticker:strategy 키에서 과거 expired가 최신 open/closed/picked를 덮지 못하게 한다.
            if (new_score, ts) > (old_score, old_ts):
                out[k] = r
    return out

def _v354_trace_for_candidate(ev: Dict[str, Any], trace_map: Optional[Dict[str, Dict[str, Any]]] = None) -> Dict[str, Any]:
    trace_map = trace_map or _v354_trace_map()
    row = _candidate_norm(ev)
    t = norm_ticker(row.get('ticker') or row.get('market') or row.get('symbol'))
    sk = _primary_strategy_key(row) or str(row.get('strategy_key') or row.get('strategy') or '')
    keys = [row.get('event_id'), row.get('event_key'), row.get('trace_id'), row.get('handoff_id'), row.get('candidate_uid'), f'{t}:{sk}']
    for k in keys:
        k=str(k or '')
        if k and k in trace_map:
            return trace_map[k]
    return {}

def _v354_reason_from_trace(ev: Dict[str, Any], trace: Dict[str, Any], fallback: str = '') -> str:
    vals: List[str] = []
    for src in (trace, ev):
        if not isinstance(src, dict):
            continue
        for key in ('reason', 'missed_reason', 'status_reason'):
            v = src.get(key)
            if isinstance(v, list):
                vals += [str(x).strip() for x in v if str(x).strip()]
            elif v not in (None, '', '-'):
                vals += [x.strip() for x in str(v).split(',') if x.strip()]
    if fallback:
        vals += [x.strip() for x in str(fallback).split(',') if x.strip()]
    if trace:
        st=str(trace.get('status') or '')
        if st and st not in {'candidate','unknown'}:
            vals.append(st)
    out=[]
    for v in vals:
        if v and v not in out:
            out.append(v)
    return ','.join(out[:6]) if out else 'paper미병합/만료확인'

def missed_trace_text() -> str:  # type: ignore[override]
    obj = load_json(FILES.get('candidate_handoff_trace', BASE_DIR/'paper_bot_candidate_handoff_trace.json'), {}) or {}
    rows = _v354_trace_rows()
    by_status = Counter(str(r.get('status') or 'unknown') for r in rows)
    reasons = Counter()
    for r in rows:
        for x in str(r.get('reason') or '').split(','):
            x=x.strip()
            if x: reasons[x]+=1
    lines = [
        '🧭 놓친 후보 추적 /missed_trace',
        '- strategy 후보 → handoff → paper 병합/OPEN/CLOSED 흐름을 추적합니다.',
        f"- trace age {age(FILES.get('candidate_handoff_trace', BASE_DIR/'paper_bot_candidate_handoff_trace.json')):.1f}s / rows {len(rows)} / version {obj.get('version','-') if isinstance(obj,dict) else '-'}",
        '', '[상태 TOP]'
    ]
    if by_status:
        for k,v in by_status.most_common(10):
            icon = '✅' if k in {'open','closed','picked'} else '⚠️' if k in {'expired','not_merged','merged_waiting_pick','micro_wait','skipped'} else '❔'
            lines.append(f'- {icon} {k}: {v}개')
    else:
        lines.append('- trace 없음')
    lines += ['', '[이유 TOP]']
    if reasons:
        for k,v in reasons.most_common(10):
            icon = '⚠️' if k in {'paper미병합','handoff만료','후보오래됨','micro미확인','picked_not_opened'} else '❔'
            lines.append(f'- {icon} {k}: {v}개')
    else:
        lines.append('- 이유 없음')
    lines += ['', '[주의 후보 TOP]']
    risky = [r for r in rows if str(r.get('status') or '') not in {'open','closed'}]
    risky.sort(key=lambda r: (float(first_value(r.get('score'),0) or 0), float(first_value(r.get('created_at'),0) or 0)), reverse=True)
    for r in risky[:10]:
        lines.append(f"- ⚠️ {norm_ticker(r.get('ticker'))} / {r.get('strategy') or r.get('strategy_key','-')} / score {r.get('score','-')} / status {r.get('status','-')} / 이유 {r.get('reason','-')}")
    if not risky:
        lines.append('- 현재 주의 후보 없음')
    return '\n'.join(lines)

def _v358_recent_review_events() -> List[Dict[str, Any]]:
    """v358: /pmissed_review 기본판은 오래된 archive 전체를 다시 훑지 않는다.

    trace 수술 이후 기본 복기는 latest/handoff/actual trace 중심으로만 본다.
    archive 전체 재검사는 나중에 full 명령으로 분리할 대상이며, 기본 명령에서
    handoff만료/paper미병합을 과대표시하지 않게 한다.
    """
    events: List[Dict[str, Any]] = []
    seen: set[str] = set()
    for name, maxn in [('paper_candidates_latest.jsonl', 250), ('paper_candidates_handoff_merged.jsonl', 300)]:
        for ev in read_jsonl(BASE_DIR/name, max_lines=maxn):
            if not isinstance(ev, dict):
                continue
            key = str(ev.get('event_id') or ev.get('event_key') or ev.get('candidate_uid') or '')
            t = norm_ticker(ev.get('ticker') or ev.get('market') or ev.get('symbol'))
            ts = str(first_value(ev.get('created_at'), ev.get('candidate_created_at'), ev.get('event_ts'), ''))
            sk = str(_primary_strategy_key(ev) or ev.get('strategy_key') or ev.get('strategy') or '')
            dk = key or f'{t}:{sk}:{ts}'
            if dk in seen:
                continue
            seen.add(dk)
            events.append(ev)
    # actual trace도 후보 추적 기준으로만 보강한다. 오래된 source/archive trace fallback은 쓰지 않는다.
    obj = load_json(FILES.get('candidate_handoff_trace', BASE_DIR/'paper_bot_candidate_handoff_trace.json'), {}) or {}
    rows = obj.get('rows') if isinstance(obj, dict) else []
    if isinstance(rows, list):
        for r in rows[:300]:
            if not isinstance(r, dict):
                continue
            key = str(r.get('event_id') or r.get('event_key') or r.get('candidate_uid') or r.get('trace_id') or '')
            t = norm_ticker(r.get('ticker') or r.get('market') or r.get('symbol'))
            ts = str(first_value(r.get('created_at'), r.get('candidate_created_at'), r.get('event_ts'), ''))
            sk = str(_primary_strategy_key(r) or r.get('strategy_key') or r.get('strategy') or '')
            dk = key or f'trace:{t}:{sk}:{ts}'
            if dk in seen:
                continue
            seen.add(dk)
            events.append(r)
    return events


def pmissed_review_text() -> str:  # type: ignore[override]
    """v358 기본 missed 복기.

    기본 명령은 latest/handoff/actual trace만 본다. archive 전체 재검사는 렉과
    과대표시를 만들 수 있으므로 기본 경로에서 제외한다.
    """
    anchor_ts = _paper_anchor_ts()
    events = _v358_recent_review_events()
    market = _market_price_map()
    open_ids, closed_ids, open_tickers = _open_closed_keys()
    trace_map = _v354_trace_map()
    watched=0; by_key: Dict[str, Dict[str, Any]] = {}; reason_counter=Counter()
    for raw in events:
        if not isinstance(raw, dict):
            continue
        ev = _candidate_norm(raw)
        ts = float(first_value(ev.get('created_at'), ev.get('candidate_created_at'), ev.get('detected_ts'), ev.get('event_ts'), 0) or 0)
        if anchor_ts and ts and ts < anchor_ts:
            continue
        t=norm_ticker(ev.get('ticker') or ev.get('market') or ev.get('symbol'))
        if not t:
            continue
        watched += 1
        keys=_candidate_keys(ev)
        if (keys & open_ids) or (keys & closed_ids) or t in open_tickers:
            continue
        cur_price = price_from_any(market.get(t, {}))
        entry = float(first_value(ev.get('entry_price'), ev.get('current_price'), ev.get('detected_price'), ev.get('price'), 0) or 0)
        if cur_price <= 0 or entry <= 0:
            continue
        gain = (cur_price-entry)/entry*100.0
        if gain < 0.70:
            continue
        trace = _v354_trace_for_candidate(ev, trace_map)
        why = _v354_reason_from_trace(ev, trace, _missed_reason(ev, set()))
        for x in why.split(','):
            if x: reason_counter[x]+=1
        sk = _primary_strategy_key(ev) or str(ev.get('strategy_key') or ev.get('strategy') or '')
        dedupe = f'{t}:{sk}'
        item = {'ticker':t,'gain':gain,'strategy':ev.get('strategy_bucket_primary_label') or ev.get('strategy_name') or ev.get('strategy') or trace.get('strategy'), 'score':ev.get('score') or trace.get('score'), 'reasons':ev.get('reasons') or ev.get('final_entry_reasons') or [], 'missed_reason':why, 'trace_status':trace.get('status','-') if trace else '-'}
        old=by_key.get(dedupe)
        if old is None or gain > float(old.get('gain',0)):
            by_key[dedupe]=item
    missed=list(by_key.values()); missed.sort(key=lambda x:x.get('gain',0), reverse=True)
    lines=['🔎 놓친 후보 복기 /pmissed_review · 메인봇 캐시전용', '- 기본 범위: latest/handoff/actual trace 중심. archive 전체 재검사는 기본에서 제외.', f'- 확인 후보 {watched}개 / 중복제거 상승후보 {len(missed)}개', '', '[놓친 이유 추정 TOP]']
    if reason_counter:
        for k,v in reason_counter.most_common(8):
            icon='⚠️' if k in {'paper미병합','handoff만료','후보오래됨','micro미확인','picked_not_opened'} else '❔'
            lines.append(f'- {icon} {k}: {v}개')
    else:
        lines.append('- 아직 분류할 상승후보 없음')
    lines += ['', '[이후 오른 후보 TOP]']
    if missed:
        for m in missed[:5]:
            rs=m.get('reasons') if isinstance(m.get('reasons'), list) else []
            lines.append(f"- {'⚠️' if m['gain']>=1.5 else '❔'} {m['ticker']} / +{m['gain']:.2f}% / {m.get('strategy','-')} / 점수 {m.get('score','-')} / 상태 {m.get('trace_status','-')} / 놓친이유 {m.get('missed_reason','-')} / 근거 {', '.join(map(str, rs[:3]))}")
    else:
        lines.append('- 아직 뚜렷한 놓친 상승후보 없음')
    lines += ['', '[판독]', '- 기본판에서 paper미병합/만료가 많으면 handoff·paper 병합 타이밍을 봅니다', '- 전략조건 수정은 score/trace가 정상 출력된 뒤 판단합니다']
    return '\n'.join(lines)


def _v358_trim_loss_preview(txt: str) -> str:
    lines = txt.splitlines()
    out: List[str] = []
    keep = True
    for ln in lines:
        if ln.startswith('[전략별 손실 원인'):
            keep = False
            continue
        if ln.startswith('[조건 설계 힌트]'):
            keep = True
        if keep:
            out.append(ln)
        if len(out) >= 18:
            break
    if '[전략별 손실 원인 · 대표전략 기준]' in txt:
        out += ['', '- 전략별 상세 손실은 /ploss_review에서 확인']
    return '\n'.join(out)


def preview_text() -> str:  # type: ignore[override]
    """v358 기본 preview 경량화.

    전체 상세를 반복 출력하지 않고 손실 TOP + missed 기본판만 묶는다.
    """
    parts=[]
    try:
        parts.append(_v358_trim_loss_preview(ploss_review_text()))
    except Exception as exc:
        log_error('preview_ploss_review', exc)
        parts.append(f'⚠️ ploss_review 출력 오류: {type(exc).__name__}: {exc}')
    try:
        parts.append(pmissed_review_text())
    except Exception as exc:
        log_error('preview_pmissed_review', exc)
        parts.append(f'⚠️ pmissed_review 출력 오류: {type(exc).__name__}: {exc}')
    return '\n\n'.join(parts)




# =============================================================================
# v365: 버전별 성과판 복구
# - v349~v364 결과가 한 장부에 섞이면 현재 수정 효과를 판단하기 어렵다.
# - /version_score는 paper CLOSED를 직접 읽어 brain version별 승률/손익/손실패턴을 분리한다.
# - score cache fallback을 만들지 않고, 조회 전용으로만 계산한다.
# =============================================================================

def _v365_norm_version_from_row(row: Dict[str, Any]) -> str:
    row = as_dict(row)
    ctx = as_dict(row.get('entry_context'))
    raw = as_dict(row.get('raw'))
    vals = [
        row.get('opened_brain_version'), row.get('brain_version'), row.get('main_version'), row.get('bot_version'),
        ctx.get('opened_brain_version'), ctx.get('brain_version'), ctx.get('main_version'), ctx.get('bot_version'),
        raw.get('opened_brain_version'), raw.get('brain_version'), raw.get('main_version'), raw.get('bot_version'),
    ]
    for v in vals:
        s = str(v or '').strip()
        if not s:
            continue
        m = re.search(r'v?2[._]13[._](\d+)', s)
        if m:
            return f"v2.13.{int(m.group(1))}"
        m = re.search(r'v(\d{3,})', s)
        if m:
            return f"v2.13.{int(m.group(1))}"
        return s[:32]
    return '버전 미기록'


def _v365_closed_ts(row: Dict[str, Any]) -> float:
    return fnum(row.get('closed_at'), row.get('closed_ts'), row.get('close_ts'), row.get('exit_ts'), row.get('timestamp'), row.get('updated_at'), default=0.0)


def _v365_pnl(row: Dict[str, Any]) -> float:
    return fnum(row.get('pnl_pct'), row.get('profit_pct'), row.get('return_pct'), row.get('profit_rate_pct'), default=0.0)


def _v365_strategy_key(row: Dict[str, Any]) -> str:
    key = _strategy_key_from_row(row) if '_strategy_key_from_row' in globals() else str(row.get('strategy_key') or row.get('strategy') or 'unknown')
    return key or 'unknown'


def _v365_stat(rows: List[Dict[str, Any]]) -> Dict[str, Any]:
    n=len(rows)
    wins=sum(1 for r in rows if _v365_pnl(r)>0)
    losses=sum(1 for r in rows if _v365_pnl(r)<0)
    total=sum(_v365_pnl(r) for r in rows)
    avg=total/n if n else 0.0
    fast=sum(1 for r in rows if _v365_pnl(r)<0 and fnum(r.get('hold_sec'), r.get('duration_sec'), default=999999) <= 300)
    hard=sum(1 for r in rows if '하드' in str(r.get('exit_reason') or r.get('exit_label') or r.get('close_reason') or '') or _v365_pnl(r) <= -0.95)
    no_react=sum(1 for r in rows if _v365_pnl(r)<0 and fnum(r.get('peak_pct'), r.get('max_profit_pct'), r.get('max_pnl_pct'), default=0.0) <= 0.10)
    hold_avg=sum(fnum(r.get('hold_sec'), r.get('duration_sec'), default=0.0) for r in rows)/n if n else 0.0
    return {'n':n,'wins':wins,'losses':losses,'win_rate':(wins/n*100.0 if n else 0.0),'total':total,'avg':avg,'fast':fast,'hard':hard,'no_react':no_react,'hold_avg':hold_avg}


def _v365_stat_line(label: str, rows: List[Dict[str, Any]]) -> str:
    st=_v365_stat(rows)
    sample = ' ⚠️표본적음' if 0 < st['n'] < 10 else ''
    return f"- {label}: {st['n']}전 {st['wins']}승 {st['losses']}패 / 승률 {st['win_rate']:.1f}% / 합산 {st['total']:+.2f}% / 평균 {st['avg']:+.2f}%{sample} / 5분내손실 {st['fast']} / 하드손실 {st['hard']} / 무반응손실 {st['no_react']}"


def version_score_text() -> str:
    rows = [r for r in read_jsonl(FILES.get('paper_closed', BASE_DIR/'paper_bot_closed.jsonl'), max_lines=30000) if isinstance(r, dict)]
    groups: Dict[str, List[Dict[str, Any]]] = {}
    for r in rows:
        groups.setdefault(_v365_norm_version_from_row(r), []).append(r)
    items=[]
    for ver, arr in groups.items():
        latest=max((_v365_closed_ts(r) for r in arr), default=0.0)
        # 버전 미기록은 아래로 보낸다.
        if ver == '버전 미기록': latest = -1
        items.append((latest, ver, arr))
    items.sort(reverse=True)
    lines=[
        '📊 버전별 성과 /version_score',
        '- 목적: v349~현재 결과가 섞이지 않게 버전별 승률·손익을 따로 봅니다.',
        '- 기준: paper CLOSED 전체 장부 직접 조회 / 기본 score cache와 별도',
        '',
        '[최근 버전별 요약]'
    ]
    if not items:
        lines.append('- 아직 CLOSED 장부 없음')
        return '\n'.join(lines)
    for _, ver, arr in items[:12]:
        icon='✅' if _v365_stat(arr).get('total',0)>0 else ('⚠️' if len(arr)<10 else '❌')
        lines.append(_v365_stat_line(f'{icon} {ver}', arr))
    latest_ver = items[0][1]
    latest_rows = items[0][2]
    strat_groups: Dict[str, List[Dict[str, Any]]] = {}
    for r in latest_rows:
        strat_groups.setdefault(_v365_strategy_key(r), []).append(r)
    label_map={'money_reaccel_s':'돈흐름 재가속','leader_momentum_s':'주도추세 지속','breakout_early_s':'돌파 초입','sweep_vwap_recovery_s':'저점 VWAP 회복','surge_rebreak_s':'급등 후 재돌파','leader_flow_adaptive_hold_s':'주도흐름 유동보유','unknown':'대표전략 미확인'}
    lines += ['', f'[최근 버전 전략별 · {latest_ver}]']
    for k, arr in sorted(strat_groups.items(), key=lambda kv: len(kv[1]), reverse=True)[:8]:
        lines.append(_v365_stat_line(label_map.get(k,k), arr))
    lines += ['', '[판독]', '- 현재 /score는 현재판 anchor 기준이고, /version_score는 버전별 장부 기준입니다.', '- 새 조건 효과는 최신 버전 줄만 보고, 예전 손실은 참고로만 봅니다.']
    return '\n'.join(lines)

COMMANDS={'health':health_text,'core':health_text,'workers':workers_text,'score':score_text,'version_score':version_score_text,'vscore':version_score_text,'quality':quality_text,'strategy_watch':strategy_watch_text,'pipe_check':pipe_check_text,'pstatus':pstatus_text,'pscore':pscore_text,'popen':popen_text,'ploss_review':ploss_review_text,'pmissed_review':pmissed_review_text,'preview':preview_text,'loss_review':ploss_review_text,'missed_review':pmissed_review_text,'missed_trace':missed_trace_text,'trace_missed':missed_trace_text,'errorlog':errorlog_text,'popen_short':open_text}

def send(update, text:str)->None:
    try:
        # Telegram hard limit 보호
        if len(text)>3900: text=text[:3850]+"\n…(잘림: full 명령에서 확인)"
        update.message.reply_text(text)
    except Exception as exc: log_error('telegram_send',exc)

def make_handler(name:str):
    def h(update, context):
        try:
            txt = getattr(update.message, 'text', '') or ''
            lines = [x.strip().lstrip('/') for x in txt.splitlines() if x.strip().startswith('/')]
            if len(lines) >= 2:
                context.args = lines[:12]
                return batch_handler(update, context)
            send(update, COMMANDS[name]())
        except Exception as exc:
            log_error(f'cmd_{name}',exc); send(update, f"❌ /{name} 오류: {exc.__class__.__name__}: {exc}")
    return h

def batch_handler(update, context):
    cmds=context.args or ['health','score','quality','strategy_watch','errorlog']
    cmds=[str(x).strip().lstrip('/') for x in cmds[:12] if str(x).strip()]
    st=time.time(); sent=0; timings=[]
    try:
        send(update, f"📦 자동 묶음 명령 접수\n- 실행 {len(cmds)}개\n- v369: S2/S3 관찰·trace·최근3버전 성과 수술")
    except Exception:
        pass
    total=len(cmds)
    for raw in cmds:
        name=raw.strip().lstrip('/')
        fn=COMMANDS.get(name)
        if not fn:
            continue
        t=time.time()
        try:
            body=fn()
            ok="OK"
        except Exception as exc:
            body=f"❌ /{name} 오류 {exc.__class__.__name__}: {exc}"
            ok="ERR"
            log_error(f'batch_{name}', exc)
        sec=time.time()-t
        sent += 1
        timings.append(f"- {'✅' if ok=='OK' else '❌'} /{name}: {sec:.2f}s / {ok}")
        send(update, f"[{sent}/{total}] /{name} ({sec:.2f}s / {ok})\n{body}")
    send(update, "🧾 자동 묶음 시간표 · v369 명령별 전송\n"+"\n".join(timings)+f"\n- 합계 {time.time()-st:.2f}s")

def text_router(update, context):
    try:
        txt=update.message.text or ''
        lines=[x.strip().lstrip('/') for x in txt.splitlines() if x.strip().startswith('/')]
        if len(lines)>=2:
            context.args=lines[:12]; return batch_handler(update, context)
    except Exception as exc: log_error('text_router',exc)

def set_commands(updater):
    try:
        updater.bot.set_my_commands([BotCommand('health','메인/worker/paper 빠른상태'),BotCommand('workers','worker 상세 상태'),BotCommand('score','S1/S2/S3 성과'),BotCommand('version_score','버전별 성과'),BotCommand('quality','S1/S2/S3 후보와 탈락사유'),BotCommand('pstatus','paper 상태'),BotCommand('popen','paper OPEN'),BotCommand('preview','손실+놓친후보 복기'),BotCommand('missed_trace','후보 handoff 추적'),BotCommand('errorlog','오류로그'),BotCommand('batch','묶음 확인')])
    except Exception as exc: log_error('set_commands',exc)

def startup_notify(updater):
    try:
        if not CHAT_ID:
            return
        text=(
            f"✅ 메인봇 시작 완료\n"
            f"- 버전: {BOT_VERSION}\n"
            f"- 구조: clean worker hub v369\n"
            f"- 명령: /health /score /quality /pstatus /popen /preview /errorlog"
        )
        updater.bot.send_message(chat_id=CHAT_ID, text=text)
    except Exception as exc:
        log_error('startup_notify', exc)

def heartbeat_loop():
    while True:
        try:
            update_brain_status('running')
        except Exception as exc:
            log_error('heartbeat', exc)
        time.sleep(10)

def main():
    log_runtime(f"telegram_state=initializing version={BOT_VERSION}")
    update_brain_status('initializing')
    if not TELEGRAM_TOKEN:
        print('TELEGRAM_TOKEN missing; worker hub status only')
        while True:
            update_brain_status('running_no_telegram'); time.sleep(5)
    updater=Updater(token=TELEGRAM_TOKEN, use_context=True)
    dp=updater.dispatcher
    for name in COMMANDS: dp.add_handler(CommandHandler(name, make_handler(name)))
    dp.add_handler(CommandHandler('batch', batch_handler))
    if MessageHandler is not None and Filters is not None: dp.add_handler(MessageHandler(Filters.text & (~Filters.command), text_router))
    set_commands(updater)
    log_runtime(f"telegram_state=commands_installed version={BOT_VERSION}")
    update_brain_status('running')
    threading.Thread(target=heartbeat_loop, daemon=True).start()
    updater.start_polling(drop_pending_updates=True)
    startup_notify(updater)
    log_runtime(f"{BOT_VERSION} telegram polling_started")
    log_runtime("telegram_state=running error=-")
    updater.idle()






# =============================================================================
# v366: 버전표시 단일화 - tail override도 현재 버전으로 고정
# v358: S 단일 등급을 S1/S2/S3로 분리해 표시/성과판 단일화
# - S1: 즉시 paper OPEN 대상
# - S2: 재확인 대기 후보
# - S3: 관찰/복기 후보
# - 기존 A/B/C 기본 출력은 제거하고, 과거 S/A는 S1로, B/C는 S3로만 호환 표시한다.
# =============================================================================
BOT_VERSION = "수익형 v2.13.377"
CLEAN_WORKER_HUB_LABEL = "clean worker hub v369"

def _v358_stage_from_row(row: Dict[str, Any]) -> str:
    ctx = row.get('entry_context') if isinstance(row.get('entry_context'), dict) else {}
    g = str(row.get('s_stage') or row.get('candidate_grade') or row.get('grade') or row.get('entry_grade') or row.get('signal_grade') or ctx.get('s_stage') or ctx.get('candidate_grade') or '').upper().strip()
    if g in {'S1','S2','S3','X'}:
        return g
    if g in {'S','A'}:
        return 'S1'
    if g in {'B','C'}:
        return 'S3'
    label = str(row.get('candidate_grade_label') or ctx.get('candidate_grade_label') or '')
    if 'S1' in label or '즉시' in label:
        return 'S1'
    if 'S2' in label or '재확인' in label:
        return 'S2'
    if 'S3' in label or '관찰' in label or '복기' in label:
        return 'S3'
    if '제외' in label or '차단' in label or '금지' in label:
        return 'X'
    return 'S1'

def _v358_stage_label(stage: str) -> str:
    return {
        'S1': '✅ S1 즉시진입',
        'S2': '⚠️ S2 재확인',
        'S3': '❔ S3 관찰복기',
        'X': '❌ 제외',
    }.get(str(stage or '').upper(), str(stage or '-'))

def _v358_stage_counts_from_latest(max_lines: int = 300) -> Counter:
    c = Counter()
    try:
        for r in read_jsonl(FILES['paper_latest'], max_lines=max_lines):
            if isinstance(r, dict): c[_v358_stage_from_row(r)] += 1
    except Exception:
        pass
    return c

def _paper_grade(row: Dict[str, Any]) -> str:  # type: ignore[override]
    return _v358_stage_from_row(row)



def _v401_closed_rows(max_lines: int = 2600) -> List[Dict[str, Any]]:
    rows = read_jsonl(FILES.get('paper_closed', BASE_DIR/'paper_bot_closed.jsonl'), max_lines=max_lines)
    return [r for r in rows if isinstance(r, dict) and str(r.get('closed_paper_version') or r.get('paper_version') or r.get('opened_paper_version') or '') == 'paper_bot_v0.125']


def _v401_stat(rows: List[Dict[str, Any]]) -> Dict[str, Any]:
    n = len(rows)
    wins = sum(1 for r in rows if fnum(r.get('pnl_pct'), r.get('profit_pct'), default=0.0) > 0)
    total = sum(fnum(r.get('pnl_pct'), r.get('profit_pct'), default=0.0) for r in rows)
    return {'n': n, 'wins': wins, 'losses': n - wins, 'win_rate': (wins / n * 100.0) if n else 0.0, 'total': total, 'avg': (total / n) if n else 0.0}


def _v401_grade(row: Dict[str, Any]) -> str:
    g = str(row.get('candidate_grade') or row.get('entry_grade') or row.get('s_stage') or row.get('grade') or 'S1').upper()
    return 'S1' if g in {'S', 'STRICT'} else (g if g in {'S1','S2','S3','X'} else 'S1')


def _v401_strategy_key(row: Dict[str, Any]) -> str:
    try:
        k = _primary_strategy_key(row)
        if k and k != 'unknown': return k
    except Exception: pass
    text = str(row.get('strategy_key') or row.get('strategy') or row.get('strategy_label') or '')
    for k, label in STRATEGY_LABELS.items():
        if k in text or label in text: return k
    return 'unknown'


def _v401_recent_closed(rows: List[Dict[str, Any]], limit: int = 5) -> List[str]:
    if not rows: return ['- 아직 v0.125 CLOSED 없음']
    out=[]
    for r in sorted(rows, key=lambda x: fnum(x.get('closed_at'), x.get('closed_ts'), default=0.0), reverse=True)[:limit]:
        out.append(f"- {norm_ticker(r.get('ticker'))} / {fnum(r.get('pnl_pct'), r.get('profit_pct'), default=0.0):+.2f}% / {r.get('exit_rule_label') or r.get('exit_reason') or '-'} / 보유 {fnum(r.get('age_min'), default=0.0):.1f}분")
    return out

def score_text()->str:  # type: ignore[override]
    rows = _v401_closed_rows()
    by_grade = {'S1': [], 'S2': [], 'S3': [], 'X': []}
    by_strategy: Dict[str, List[Dict[str, Any]]] = {}
    for r in rows:
        by_grade.setdefault(_v401_grade(r), []).append(r)
        by_strategy.setdefault(_v401_strategy_key(r), []).append(r)
    label_map = {'money_reaccel_s':'돈흐름 재가속','leader_momentum_s':'주도추세 지속','breakout_early_s':'돌파 초입','sweep_vwap_recovery_s':'저점 VWAP 회복','surge_rebreak_s':'급등 후 재돌파','leader_flow_adaptive_hold_s':'주도흐름 유동보유'}
    lines=[
        '📊 S1/S2/S3 스코어 /score',
        '- 기준: paper_bot_v0.125 CLOSED 장부 직접조회. 구 score cache는 기본 성과판에서 사용하지 않습니다.',
        f"- 장부 age {age(FILES.get('paper_closed', BASE_DIR/'paper_bot_closed.jsonl')):.1f}s / v0.125 CLOSED {len(rows)}개 / 대표전략 집계 {len(rows)}개",
        _score_stat_line('✅ S1 즉시진입', _v401_stat(by_grade.get('S1', []))),
        _score_stat_line('⚠️ S2 재확인', _v401_stat(by_grade.get('S2', []))),
        _score_stat_line('❔ S3 관찰복기', _v401_stat(by_grade.get('S3', []))),
        _score_stat_line('현재판 전체', _v401_stat(rows)),
        '', '[대표전략 기준 · 실제 거래수와 맞는 성과]'
    ]
    for key,label in label_map.items(): lines.append(_score_stat_line(label, _v401_stat(by_strategy.get(key, []))))
    if by_strategy.get('unknown'): lines.append(_score_stat_line('전략키 미기록', _v401_stat(by_strategy.get('unknown', []))))
    lines += ['', '[최근 CLOSED]'] + _v401_recent_closed(rows)
    strat=_v398_load_json_small(FILES.get('strategy_summary', BASE_DIR/'clean_strategy_s_summary.json'), {}) or {}
    pbh=_v398_load_json_small(FILES.get('paperbot_handoff', BASE_DIR/'paper_bot_candidate_handoff_status.json'), {}) or {}
    router=_v398_load_json_small(FILES.get('target_router', BASE_DIR/'clean_target_router_queue.json'), {}) or {}
    sc=_v398_stage_counts_from_latest_fast()
    if isinstance(strat,dict):
        lines += ['', '[현재 후보/정보 흐름]']
        lines.append(f"- 현재 S1 {sc.get('S1',0)} / S2 {sc.get('S2',0)} / S3 {sc.get('S3',0)} / latest {strat.get('paper_latest_count','-')} / paper 병합 {pbh.get('merged_fresh','-') if isinstance(pbh,dict) else '-'} / archive {pbh.get('archive_window','-') if isinstance(pbh,dict) else '-'}")
        lines.append(f"- 정보: 전체 {strat.get('evaluated','-')}개 / 시세 {strat.get('quote_ready_count','-')} / micro {strat.get('micro_ready_count','-')} / 둘다 {strat.get('full_info_ready_count','-')}")
        lines.append(f"- 배차: 전체 {router.get('queue_count','-') if isinstance(router,dict) else '-'} / 내보냄 {router.get('export_count', router.get('active_target_count','-')) if isinstance(router,dict) else '-'} / 대기 {router.get('rotation_wait_count','-') if isinstance(router,dict) else '-'} / 버림 {router.get('dropped_count',0) if isinstance(router,dict) else 0}")
    return "\n".join(lines)

def pscore_text() -> str:  # type: ignore[override]
    return score_text().replace('📊 S1/S2/S3 스코어 /score', '📊 paper S1/S2/S3 스코어 /pscore · v0.125 장부직접조회', 1)

def quality_text()->str:  # type: ignore[override]
    reject=load_json(FILES['strategy_reject'],{}) or {}; strat=load_json(FILES['strategy_summary'],{}) or {}
    hand=load_json(FILES['paper_handoff'],{}) or {}; pbh=load_json(FILES['paperbot_handoff'],{}) or {}
    latest_lines=line_count(FILES['paper_latest']); archive_lines=line_count(FILES['paper_archive'])
    router=load_json(FILES.get('target_router', BASE_DIR/'clean_target_router_queue.json'),{}) or {}
    evaluated=int(fnum(reject.get('evaluated') or strat.get('evaluated') or 0,0))
    quote=int(fnum(reject.get('quote_ready_count') or strat.get('quote_ready_count') or evaluated,0))
    micro=int(fnum(reject.get('micro_ready_count') or strat.get('micro_ready_count') or 0,0))
    both=int(fnum(reject.get('full_info_ready_count') or strat.get('full_info_ready_count') or min(quote,micro),0))
    sc=_v358_stage_counts_from_latest(); not_micro=max(0,evaluated-micro) if evaluated else 0
    lines=[
        '🔍 후보품질 /quality',
        f"✅ 전체 {evaluated}개 평가 / S1 {sc.get('S1',0)} / S2 {sc.get('S2',0)} / S3 {sc.get('S3',0)} / latest {latest_lines}줄 / 병합 {pbh.get('merged_fresh','-')}",
        '', '[S1/S2/S3 의미]',
        '- S1: 즉시 paper OPEN / S2: 재확인 후 승격 후보 / S3: 관찰·복기 후보',
        '- 유동보유: 0~5분 검증 → 5~30분 확인 → 30~120분 확장 관찰',
        '', '[정보가 얼마나 채워졌나]',
        f"- 시세: {quote}/{evaluated}개 / 호가·체결: {micro}/{evaluated}개 / 둘다: {both}/{evaluated}개",
        f"- 아직 micro 미신선: {not_micro}개 / 지금 꼭 필요한 micro: {router.get('need_micro') or reject.get('info_pending_count') or 0}개",
        '', '[안 넣은 게 아니라 단계 분리]',
        f"- 전체배차 {router.get('queue_count','-')}개 → 이번내보냄 {router.get('export_count', router.get('active_target_count','-'))}",
        f"- 순환대기 {router.get('rotation_wait_count','-')}개 / 버림 {router.get('dropped_count',0)}개 / safety초과 {router.get('safety_overflow',0)}개",
        '', '[탈락/보류 사유 TOP]'
    ]
    top=reject.get('reason_top') if isinstance(reject.get('reason_top'),list) else []
    if top:
        for r in top[:12]:
            lines.append(f"- ❔ {r.get('reason')}: {r.get('count')}")
    else:
        lines.append('- 아직 집계 없음')
    return '\n'.join(lines)

def popen_text() -> str:  # type: ignore[override]
    open_pos = _paper_open_positions()
    lines = ['📂 paper OPEN /popen · 메인봇 캐시전용']
    if not open_pos:
        return '\n'.join(lines + ['OPEN 없음'])
    rows = [p for p in open_pos.values() if isinstance(p, dict)]
    rows.sort(key=lambda p: fnum(p.get('opened_at') or p.get('entry_ts') or 0, 0), reverse=True)
    by_stage = Counter(_paper_grade(p) for p in rows)
    by_strategy = Counter(_paper_strategy_label(p) for p in rows)
    lines.append('등급별 OPEN: ' + ' / '.join(f'{_v358_stage_label(k)} {v}' for k,v in by_stage.items()))
    lines.append('전략별 OPEN: ' + ' / '.join(f'{k} {v}' for k, v in by_strategy.items()))
    for p in rows[:10]:
        t = _short_ticker(p.get('ticker') or p.get('symbol'))
        pnl = _pos_profit_pct(p); hold = _pos_hold_sec(p); vals = _pos_snapshot_flat(p)
        buy = vals.get('buy_ratio') or vals.get('micro_trade_buy_ratio_30') or '-'
        reason = p.get('reason') or p.get('entry_reason') or p.get('watch_note') or 'time_exit 대기'
        try: buy_txt = f"{float(buy):.2f}"
        except Exception: buy_txt = str(buy)
        lines.append(f"- {_v358_stage_label(_paper_grade(p))} {t} / {_paper_strategy_label(p)} / 진입 {_pos_entry_price(p)} / 현재 {_pos_current_price(p)} / {pnl:+.2f}% / 보유 {int(hold//60)}분 {int(hold%60)}초 / 감시 {reason}")
        lines.append(f"  · 근거: 매수체결 {buy_txt} / 주의: {p.get('risk_label') or p.get('risk_tags') or '특이사항 없음'}")
    if len(rows) > 10:
        lines.append(f"- 나머지 {len(rows)-10}개는 이후 full에서 확인")
    return '\n'.join(lines)

def set_commands(updater):  # type: ignore[override]
    try:
        updater.bot.set_my_commands([BotCommand('health','메인/worker/paper 빠른상태'),BotCommand('workers','worker 상세 상태'),BotCommand('score','S1/S2/S3 성과'),BotCommand('version_score','버전별 성과'),BotCommand('quality','S1/S2/S3 후보품질'),BotCommand('pstatus','paper 상태'),BotCommand('popen','paper OPEN'),BotCommand('preview','손실+놓친후보 복기'),BotCommand('missed_trace','후보 handoff 추적'),BotCommand('errorlog','오류로그'),BotCommand('batch','묶음 확인')])
    except Exception as exc: log_error('set_commands',exc)

def startup_notify(updater):  # type: ignore[override]
    try:
        if not CHAT_ID:
            return
        text=(f"✅ 메인봇 시작 완료\n- 버전: {BOT_VERSION}\n- 구조: {CLEAN_WORKER_HUB_LABEL}\n- 등급: S1 즉시진입 / S2 재확인 / S3 관찰복기\n- 새 전략: 주도흐름 유동보유\n- 명령: /health /score /quality /pstatus /popen /preview /errorlog")
        updater.bot.send_message(chat_id=CHAT_ID, text=text)
    except Exception as exc:
        log_error('startup_notify', exc)


# =============================================================================
# v360: COMMANDS 재바인딩 + S1/S2/S3 기본 출력 고정
# - v358에서 /score, /pstatus가 COMMANDS 초기 참조 때문에 구 함수로 남는 문제를 제거한다.
# - 새 기준은 S1 즉시진입 / S2 재확인 / S3 관찰복기만 기본 출력한다.
# =============================================================================
try:
    COMMANDS.update({
        'health': health_text,
        'core': health_text,
        'workers': workers_text,
        'score': score_text,
        'quality': quality_text,
        'strategy_watch': strategy_watch_text,
        'pipe_check': pipe_check_text,
        'pstatus': pstatus_text,
        'pscore': pscore_text,
        'popen': popen_text,
        'ploss_review': ploss_review_text,
        'pmissed_review': pmissed_review_text,
        'preview': preview_text,
        'loss_review': ploss_review_text,
        'missed_review': pmissed_review_text,
        'missed_trace': missed_trace_text,
        'trace_missed': missed_trace_text,
        'errorlog': errorlog_text,
        'popen_short': open_text,
    })
except Exception:
    pass


# =============================================================================
# v367: /version_score 최근 3개 적용버전 + S2/S3 관찰 배관 표시 단일화
# - 구 worker 버전명 나열을 기본 출력에서 끊고, 최근 3개 적용 버전만 본다.
# - 새 CLOSED는 main/deploy version 필드를 우선 사용한다.
# - S2/S3는 CLOSED가 적을 수 있으므로 /quality 현재 후보와 /missed_trace 중심으로 판단한다.
# =============================================================================
BOT_VERSION = "수익형 v2.13.377"
CLEAN_WORKER_HUB_LABEL = "clean worker hub v369"

_VERSION_SCORE_LIMIT = 3

def _v367_version_key(row: Dict[str, Any]) -> str:
    row = as_dict(row)
    ctx = as_dict(row.get('entry_context'))
    raw = as_dict(row.get('raw'))
    snap = as_dict(row.get('entry_snapshot'))
    flat = as_dict(snap.get('flat'))
    vals = [
        row.get('main_version'), row.get('main_bot_version'), row.get('deploy_version'), row.get('deployed_version'), row.get('bot_version'),
        ctx.get('main_version'), ctx.get('main_bot_version'), ctx.get('deploy_version'), ctx.get('deployed_version'), ctx.get('bot_version'),
        raw.get('main_version'), raw.get('main_bot_version'), raw.get('deploy_version'), raw.get('deployed_version'), raw.get('bot_version'),
        flat.get('main_version'), flat.get('main_bot_version'), flat.get('deploy_version'), flat.get('deployed_version'), flat.get('bot_version'),
    ]
    vals_fallback = [row.get('opened_brain_version'), row.get('brain_version'), ctx.get('opened_brain_version'), ctx.get('brain_version'), raw.get('brain_version')]
    for seq in (vals, vals_fallback):
        for v in seq:
            s = str(v or '').strip()
            if not s:
                continue
            m = re.search(r'v?2[._]13[._](\d+)', s)
            if m:
                return f"v2.13.{int(m.group(1))}"
            m = re.search(r'v(\d{3,})', s)
            if m:
                return f"v2.13.{int(m.group(1))}"
            if 'strategy_worker' in s:
                return s[:32]
    return '버전 미기록'

def _v367_version_sort(ver: str, arr: List[Dict[str, Any]]) -> Tuple[int, float]:
    m = re.search(r'v2\.13\.(\d+)', str(ver))
    n = int(m.group(1)) if m else -1
    latest = max((_v365_closed_ts(r) for r in arr), default=0.0)
    return (n, latest)

def version_score_text() -> str:  # type: ignore[override]
    rows = [r for r in read_jsonl(FILES.get('paper_closed', BASE_DIR/'paper_bot_closed.jsonl'), max_lines=30000) if isinstance(r, dict)]
    groups: Dict[str, List[Dict[str, Any]]] = {}
    for r in rows:
        groups.setdefault(_v367_version_key(r), []).append(r)
    items = []
    for ver, arr in groups.items():
        if ver == '버전 미기록':
            continue
        items.append((_v367_version_sort(ver, arr), ver, arr))
    items.sort(key=lambda x: x[0], reverse=True)
    items = items[:_VERSION_SCORE_LIMIT]
    lines = [
        '📊 버전별 성과 /version_score',
        f'- 기본 출력: 최근 적용 버전 {_VERSION_SCORE_LIMIT}개만 표시합니다.',
        '- 기준: paper CLOSED 장부 직접 조회 / 메인 적용버전 우선 / worker 버전은 보조값',
        '',
        '[최근 3개 버전 요약]'
    ]
    if not items:
        lines.append('- 아직 버전이 기록된 CLOSED 장부 없음')
        return '\n'.join(lines)
    for _, ver, arr in items:
        st = _v365_stat(arr)
        icon = '✅' if st.get('total',0) > 0 else ('⚠️' if st.get('n',0) < 10 else '❌')
        lines.append(_v365_stat_line(f'{icon} {ver}', arr))
    latest_ver = items[0][1]
    latest_rows = items[0][2]
    strat_groups: Dict[str, List[Dict[str, Any]]] = {}
    for r in latest_rows:
        strat_groups.setdefault(_v365_strategy_key(r), []).append(r)
    label_map={'money_reaccel_s':'돈흐름 재가속','leader_momentum_s':'주도추세 지속','breakout_early_s':'돌파 초입','sweep_vwap_recovery_s':'저점 VWAP 회복','surge_rebreak_s':'급등 후 재돌파','leader_flow_adaptive_hold_s':'주도흐름 유동보유','unknown':'대표전략 미확인'}
    lines += ['', f'[최신 버전 전략별 · {latest_ver}]']
    if strat_groups:
        for k, arr in sorted(strat_groups.items(), key=lambda kv: len(kv[1]), reverse=True)[:8]:
            lines.append(_v365_stat_line(label_map.get(k,k), arr))
    else:
        lines.append('- 아직 최신 버전 CLOSED 없음')
    lines += ['', '[판독]', '- /score는 현재판 anchor 성과, /version_score는 최근 3개 적용버전 비교입니다.', '- 오래된 worker 버전 나열은 기본 출력에서 제외했습니다.']
    return '\n'.join(lines)

try:
    COMMANDS.update({'version_score': version_score_text, 'vscore': version_score_text})
except Exception:
    pass



# =============================================================================
# main v2.13.369: 최근 3개 적용버전 고정 + trace/quality 표시 정리
# =============================================================================
BOT_VERSION = "수익형 v2.13.377"
CLEAN_WORKER_HUB_LABEL = "clean worker hub v369"
_VERSION_SCORE_LIMIT = 3
_CURRENT_MAIN_VER = "v2.13.371"


def _v369_ver_num(ver: str) -> int:
    m=re.search(r'v?2[._]13[._](\d+)', str(ver or ''))
    return int(m.group(1)) if m else -1


def _v369_recent_main_versions(n: int = 3) -> List[str]:
    cur=_v369_ver_num(_CURRENT_MAIN_VER)
    if cur <= 0:
        return [_CURRENT_MAIN_VER]
    return [f"v2.13.{cur-i}" for i in range(n)]


def _v369_main_version_key(row: Dict[str, Any]) -> str:
    row=as_dict(row); ctx=as_dict(row.get('entry_context')); raw=as_dict(row.get('raw')); snap=as_dict(row.get('entry_snapshot')); flat=as_dict(snap.get('flat'))
    vals=[row.get('main_version'),row.get('main_bot_version'),row.get('deploy_version'),row.get('deployed_version'),row.get('bot_version'),ctx.get('main_version'),ctx.get('main_bot_version'),ctx.get('deploy_version'),ctx.get('deployed_version'),ctx.get('bot_version'),raw.get('main_version'),raw.get('deploy_version'),flat.get('main_version'),flat.get('deploy_version')]
    for v in vals:
        s=str(v or '').strip()
        if not s or 'strategy_worker' in s or 'paper_bot' in s:
            continue
        m=re.search(r'v?2[._]13[._](\d+)', s)
        if m:
            return f"v2.13.{int(m.group(1))}"
        m=re.search(r'v(\d{3,})', s)
        if m:
            num=int(m.group(1))
            if num >= 340:
                return f"v2.13.{num}"
    return '버전 미기록'


def version_score_text() -> str:  # type: ignore[override]
    rows=[r for r in read_jsonl(FILES.get('paper_closed', BASE_DIR/'paper_bot_closed.jsonl'), max_lines=30000) if isinstance(r, dict)]
    wanted=_v369_recent_main_versions(_VERSION_SCORE_LIMIT)
    groups={v: [] for v in wanted}
    missing=0
    for r in rows:
        k=_v369_main_version_key(r)
        if k in groups:
            groups[k].append(r)
        elif k == '버전 미기록':
            missing += 1
    lines=['📊 버전별 성과 /version_score', f'- 기본 출력: 최근 적용 버전 {_VERSION_SCORE_LIMIT}개만 표시합니다.', '- 기준: main_version/deploy_version 기록만 사용합니다. worker 버전 줄세우기는 기본에서 제외합니다.', '', '[최근 3개 버전 요약]']
    for ver in wanted:
        arr=groups.get(ver, [])
        if arr:
            lines.append(_v365_stat_line(('✅ ' if _v365_stat(arr).get('total',0)>0 else '❌ ') + ver, arr))
        else:
            lines.append(f'- ❔ {ver}: CLOSED 0건 / 아직 이 버전으로 닫힌 결과 없음')
    latest_ver=wanted[0]
    latest_rows=groups.get(latest_ver, [])
    label_map={'money_reaccel_s':'돈흐름 재가속','leader_momentum_s':'주도추세 지속','breakout_early_s':'돌파 초입','sweep_vwap_recovery_s':'저점 VWAP 회복','surge_rebreak_s':'급등 후 재돌파','leader_flow_adaptive_hold_s':'주도흐름 유동보유','unknown':'대표전략 미확인'}
    lines += ['', f'[최신 버전 전략별 · {latest_ver}]']
    if latest_rows:
        strat_groups={}
        for r in latest_rows:
            strat_groups.setdefault(_v365_strategy_key(r), []).append(r)
        for k, arr in sorted(strat_groups.items(), key=lambda kv: len(kv[1]), reverse=True)[:8]:
            lines.append(_v365_stat_line(label_map.get(k,k), arr))
    else:
        lines.append('- 아직 최신 버전 CLOSED 없음')
    if missing:
        lines += ['', f'- 참고: main_version 없는 과거 CLOSED {missing}건은 기본 비교에서 제외했습니다.']
    lines += ['', '[판독]', '- /score는 현재판 anchor 성과, /version_score는 최근 3개 적용버전만 비교합니다.', '- 새 조건 효과는 최신 버전 줄만 보고, 예전 손실은 참고에서 제외합니다.']
    return '\n'.join(lines)


def batch_handler(update, context):  # type: ignore[override]
    cmds=context.args or ['health','version_score','score','quality','missed_trace','errorlog']
    cmds=[str(x).strip().lstrip('/') for x in cmds[:12] if str(x).strip()]
    st=time.time(); sent=0; timings=[]
    try:
        send(update, f"📦 자동 묶음 명령 접수\n- 실행 {len(cmds)}개\n- v369: 최근3버전 성과 + S2/S3 관찰배관 + actual trace 단일화")
    except Exception:
        pass
    total=len(cmds)
    for raw in cmds:
        name=raw.strip().lstrip('/')
        fn=COMMANDS.get(name)
        if not fn:
            continue
        t=time.time()
        try:
            body=fn(); ok='OK'
        except Exception as exc:
            body=f"❌ /{name} 오류 {exc.__class__.__name__}: {exc}"; ok='ERR'; log_error(f'batch_{name}', exc)
        sec=time.time()-t; sent+=1
        timings.append(f"- {'✅' if ok=='OK' else '❌'} /{name}: {sec:.2f}s / {ok}")
        send(update, f"[{sent}/{total}] /{name} ({sec:.2f}s / {ok})\n{body}")
    send(update, "🧾 자동 묶음 시간표 · v369 명령별 전송\n"+"\n".join(timings)+f"\n- 합계 {time.time()-st:.2f}s")

try:
    COMMANDS.update({'version_score': version_score_text, 'vscore': version_score_text})
except Exception:
    pass


# =============================================================================
# v398 복구 안정판: 상태판/생애주기 표시만 경량 이식
# - v369 첫 묶음 기준을 유지한다.
# - /health, /pstatus, /missed_trace는 캐시 파일만 읽고 복구/재검사/worker 실행을 하지 않는다.
# - stale paper/trace면 판단보류 문구만 표시한다.
# =============================================================================
RESTORE_BUILD = "v409_v377_s1_decision_route_fix_2026-05-24"


def _v398_file_age(path: Path) -> float:
    try:
        return max(0.0, now_ts() - path.stat().st_mtime) if path.exists() else 999999.0
    except Exception:
        return 999999.0


def _v398_load_json_small(path: Path, default: Any = None, max_bytes: int = 700_000) -> Any:
    try:
        if not path.exists():
            return default
        if path.stat().st_size > max_bytes:
            return {"_too_large": True, "_size": path.stat().st_size}
        return json.loads(path.read_text(encoding="utf-8", errors="ignore"))
    except Exception:
        return default


def _v398_paper_versions() -> Dict[str, Any]:
    st_path = FILES.get('paper_status', BASE_DIR/'paper_bot_status.json')
    tr_path = FILES.get('candidate_handoff_trace', BASE_DIR/'paper_bot_candidate_handoff_trace.json')
    st = _v398_load_json_small(st_path, {}) or {}
    tr = _v398_load_json_small(tr_path, {}) or {}
    pv = str(st.get('version') or st.get('active_reader_version') or '-') if isinstance(st, dict) else '-'
    tv = str(tr.get('version') or tr.get('trace_version') or '-') if isinstance(tr, dict) else '-'
    pa = _v398_file_age(st_path)
    ta = _v398_file_age(tr_path)
    ok = bool(pv != '-' and tv != '-' and pv == tv and pa < 90 and ta < 120)
    return {'paper_version': pv, 'trace_version': tv, 'paper_age': pa, 'trace_age': ta, 'ok': ok, 'status': st, 'trace': tr}


def _v398_state_icon(ok: bool, warn: bool = False) -> str:
    return '✅' if ok else ('⚠️' if warn else '❌')


def _v398_stage_counts_from_latest_fast() -> Dict[str, int]:
    try:
        strat = _v398_load_json_small(FILES.get('strategy_summary', BASE_DIR/'clean_strategy_s_summary.json'), {}) or {}
        sc = strat.get('s_stage_counts') if isinstance(strat.get('s_stage_counts'), dict) else {}
        if sc:
            return {k:int(fnum(v,0)) for k,v in sc.items()}
    except Exception:
        pass
    try:
        c = Counter()
        for r in read_jsonl(FILES.get('paper_latest', BASE_DIR/'paper_candidates_latest.jsonl'), max_lines=300):
            g = str(r.get('s_stage') or r.get('candidate_grade') or r.get('grade') or '').upper()
            if g in {'S1','S2','S3'}:
                c[g] += 1
        return dict(c)
    except Exception:
        return {}


def _v398_lifecycle_lines() -> List[str]:
    strat = _v398_load_json_small(FILES.get('strategy_summary', BASE_DIR/'clean_strategy_s_summary.json'), {}) or {}
    life = strat.get('lifecycle_stats') if isinstance(strat.get('lifecycle_stats'), dict) else {}
    if not life:
        return ['[후보 생애주기 · 승패 아님]', '- 생애주기 cache 준비중']
    stage_counts = life.get('active_stage_counts') if isinstance(life.get('active_stage_counts'), dict) else life.get('stage_counts') if isinstance(life.get('stage_counts'), dict) else {}
    transitions = life.get('transitions') if isinstance(life.get('transitions'), dict) else {}
    missed = life.get('missed_rise_counts') if isinstance(life.get('missed_rise_counts'), dict) else {}
    lines = ['[후보 생애주기 · 승패 아님]']
    lines.append(f"- S3 관찰포착: {int(fnum(stage_counts.get('S3'),0))}개 / 새 관찰 {int(fnum(transitions.get('new_s3'),0))} / S3→S2 {int(fnum(transitions.get('s3_to_s2'),0))}")
    lines.append(f"- S2 재확인: {int(fnum(stage_counts.get('S2'),0))}개 / S2유지 {int(fnum(transitions.get('s2_hold'),0))} / S2→S1 {int(fnum(transitions.get('s2_to_s1'),0))} / S1보류 {int(fnum(transitions.get('blocked_s1_signal'),0))}")
    for key, title in [('s3_to_s2_fail_reasons','S3→S2 미승격 TOP'), ('s2_to_s1_fail_reasons','S2→S1 미승격 TOP')]:
        fails = life.get(key) if isinstance(life.get(key), dict) else {}
        if fails:
            top = sorted(fails.items(), key=lambda kv: int(fnum(kv[1],0)), reverse=True)[:5]
            lines.append(f"- {title}: " + ' / '.join(f"{k} {int(fnum(v,0))}" for k,v in top))
    lines.append(f"- S1 실제진입 대기: {int(fnum(stage_counts.get('S1'),0))}개")
    if missed:
        lines.append(f"- 놓친상승 참고: S2 +0.7%↑ {int(fnum(missed.get('S2_up_07'),0))}개 / S3 +0.7%↑ {int(fnum(missed.get('S3_up_07'),0))}개")
    lines.append('- 판독: S2/S3는 승패가 아니라 S1로 올라가기 전 재료·승격 흐름입니다.')
    return lines


def health_text() -> str:  # type: ignore[override]
    workers = [worker_status(k) for k in WORKERS]
    res = resource_snapshot()
    paper = _v398_load_json_small(FILES['paper_status'], {}) or {}
    strat = _v398_load_json_small(FILES['strategy_summary'], {}) or {}
    reject = _v398_load_json_small(FILES['strategy_reject'], {}) or {}
    oflow = _v398_load_json_small(FILES['orderflow'], {}) or {}
    router = _v398_load_json_small(FILES['target_router'], {}) or {}
    vers = _v398_paper_versions()
    good = sum(1 for w in workers if worker_ok(w) == '✅')
    warn = sum(1 for w in workers if worker_ok(w) == '⚠️')
    bad = sum(1 for w in workers if worker_ok(w) == '❌')
    evaluated = int(fnum(reject.get('evaluated') or strat.get('evaluated') or 0, 0)) if isinstance(reject, dict) and isinstance(strat, dict) else 0
    quote_ready = int(fnum(strat.get('quote_ready_count') or reject.get('quote_ready_count') or oflow.get('quote_fresh') or 0, 0)) if isinstance(strat, dict) and isinstance(reject, dict) and isinstance(oflow, dict) else 0
    micro_ready = int(fnum(strat.get('micro_ready_count') or reject.get('micro_ready_count') or oflow.get('fresh_micro') or 0, 0)) if isinstance(strat, dict) and isinstance(reject, dict) and isinstance(oflow, dict) else 0
    full_ready = int(fnum(strat.get('full_info_ready_count') or reject.get('full_info_ready_count') or oflow.get('info_ready') or 0, 0)) if isinstance(strat, dict) and isinstance(reject, dict) and isinstance(oflow, dict) else 0
    sc = _v398_stage_counts_from_latest_fast()
    res_warn = float(fnum(res.get('mem_used_pct'), 0)) >= 80 or float(fnum(res.get('disk_used_pct'), 0)) >= 85
    paper_ok = bool(vers.get('ok'))
    lines = [
        '🧭 건강상태 /health',
        f"{_v398_state_icon(bad == 0 and paper_ok and not res_warn, warn or res_warn or not paper_ok)} 전체판독: worker {good}/9 정상 · paper/trace {'정상' if paper_ok else '확인필요'} · 자원 {'주의' if res_warn else '정상'}",
        f"- 메인봇 {BOT_VERSION} / clean worker hub v369 / {RESTORE_BUILD} / uptime {int(now_ts()-START_TS)}s",
        f"- 정보: 평가 {evaluated or '-'} / 시세 {quote_ready}/{evaluated or '-'} / micro {micro_ready}/{evaluated or '-'} / 둘다 {full_ready}/{evaluated or '-'}",
        f"- 후보 생애주기: S1 {sc.get('S1',0)} / S2 {sc.get('S2',0)} / S3 {sc.get('S3',0)} / latest {strat.get('paper_latest_count', '-') if isinstance(strat,dict) else '-'}",
        f"- paper: {vers.get('paper_version')} / trace {vers.get('trace_version')} / status age {vers.get('paper_age',0):.1f}s / trace age {vers.get('trace_age',0):.1f}s / OPEN {paper.get('open_count', paper.get('open_total','-')) if isinstance(paper,dict) else '-'}",
        f"- 배차: 전체 {router.get('queue_count','-') if isinstance(router,dict) else '-'} → 내보냄 {router.get('export_count', router.get('active_target_count','-')) if isinstance(router,dict) else '-'} / 대기 {router.get('rotation_wait_count','-') if isinstance(router,dict) else '-'} / 버림 {router.get('dropped_count',0) if isinstance(router,dict) else 0}",
        f"- 자원: 디스크 {res.get('disk_used_pct','-')}% / 남음 {res.get('disk_free_gb','-')}GB / 메모리 {res.get('mem_used_pct','-')}% / load {res.get('load','-')}",
    ]
    if not paper_ok:
        lines.append('- ⚠️ paper/trace가 최신/동일하지 않으면 OPEN/trace 판단은 보류합니다. 복구 시도는 하지 않습니다.')
    lines += ['', '[worker 요약]']
    lines += [line_worker(w, detail=False) for w in workers]
    return '\n'.join(lines)


def _v401_lifecycle_lines() -> List[str]:
    life = (_v398_load_json_small(FILES.get('strategy_summary', BASE_DIR/'clean_strategy_s_summary.json'), {}) or {}).get('lifecycle_stats')
    if isinstance(life, dict) and life: return _v398_lifecycle_lines()
    sc = _v398_stage_counts_from_latest_fast(); vers = _v398_paper_versions()
    obj = vers.get('trace') if isinstance(vers.get('trace'), dict) else {}
    rows = obj.get('rows') if isinstance(obj, dict) and isinstance(obj.get('rows'), list) else []
    by = Counter(str(r.get('status') or 'unknown') for r in rows if isinstance(r, dict))
    lines=['[후보 생애주기 · 승패 아님]', f"- 현재 latest 기준: S1 {sc.get('S1',0)} / S2 {sc.get('S2',0)} / S3 {sc.get('S3',0)}"]
    lines.append('- paper trace 기준: ' + (' / '.join(f"{k} {v}" for k,v in by.most_common(6)) if by else '아직 rows 없음'))
    lines.append('- 판독: S2/S3는 승패가 아니라 S1로 올라가기 전 재료·승격 흐름입니다.')
    return lines


def pstatus_text() -> str:  # type: ignore[override]
    status=_v398_load_json_small(FILES['paper_status'], {}) or {}; hand=_v398_load_json_small(FILES['paperbot_handoff'], {}) or {}
    vers=_v398_paper_versions(); open_pos=_paper_open_positions(); pick=status.get('pick_stats') if isinstance(status.get('pick_stats'),dict) else {}
    grade_counts=Counter(_v401_grade(p) for p in open_pos.values() if isinstance(p,dict))
    latest_n=pick.get('latest_count', hand.get('latest_count', hand.get('latest_lines','-')) if isinstance(hand,dict) else '-')
    merged=pick.get('merged_fresh', hand.get('merged_fresh','-') if isinstance(hand,dict) else '-')
    opened=int(fnum(status.get('opened_this_cycle'), default=0)); closed=int(fnum(status.get('closed_this_cycle'), default=0))
    closed_total=int(fnum(status.get('closed_total'), default=0))
    lines=['🧪 paper 상태 /pstatus · v0.125 단일장부 연결',
        f"- 상태: {'ON' if status.get('running', True) else '확인필요'} / paper {vers.get('paper_version')} / trace {vers.get('trace_version')} / status age {vers.get('paper_age',0):.1f}s / OPEN {len(open_pos)} / CLOSED누적 {closed_total}",
        f"- OPEN: S1 {grade_counts.get('S1',0)} / S2 {grade_counts.get('S2',0)} / S3 {grade_counts.get('S3',0)} / 제외 {grade_counts.get('X',0)}",
        f"- 이번 cycle: OPEN {opened} / CLOSED {closed} / elapsed {status.get('elapsed_sec','-')}s",
        f"- 선별배관: latest {latest_n} / fresh {merged} / S1선택 {pick.get('selected_s1',0)} / micro대기 {pick.get('micro_preopen_wait',0)} / 이번OPEN {opened}",
        '- S2/S3는 실제 진입 전 단계라 승패로 표시하지 않습니다.']
    if not vers.get('ok'): lines.append('- ⚠️ paper 상태 최신성 확인 필요: 이 상태에서는 OPEN/trace 판단을 보류합니다.')
    rows=_v401_closed_rows(800)
    lines += _v401_lifecycle_lines() + ['', '[실제 모의매매 성과 · v0.125 CLOSED 직접조회]', _score_stat_line('현재판 전체', _v401_stat(rows))]
    lines += _v401_recent_closed(rows, limit=3)
    return '\n'.join(lines)


def missed_trace_text() -> str:  # type: ignore[override]
    vers=_v398_paper_versions(); obj=vers.get('trace') if isinstance(vers.get('trace'),dict) else {}
    rows=obj.get('rows') if isinstance(obj,dict) and isinstance(obj.get('rows'),list) else []; rows=[r for r in rows if isinstance(r,dict)][:300]
    labels={'open':'OPEN됨','closed':'CLOSED됨','selected_for_open':'S1선택됨','not_s1':'S1미달(정상대기)','micro_wait':'micro 재확인대기','merged_waiting_pick':'병합후 선별대기','expired':'후보만료','skipped':'스킵','not_merged':'미병합'}
    by=Counter(str(r.get('status') or 'unknown') for r in rows); reasons=Counter()
    for r in rows:
        for x in str(r.get('reason') or '').split(','):
            if x.strip(): reasons[x.strip()]+=1
    lines=['🧭 후보 handoff 추적 /missed_trace','- 기준: strategy 후보 → paper 병합 → S1선별 → OPEN/CLOSED 흐름. not_s1은 손실/놓친확정이 아니라 S1 미달 상태입니다.',f"- paper {vers.get('paper_version')} / trace {vers.get('trace_version')} / trace age {vers.get('trace_age',0):.1f}s / rows {len(rows)}",'', '[상태 TOP]']
    if by:
        for k,v in by.most_common(10):
            icon='✅' if k in {'open','closed','selected_for_open'} else '⚠️' if k in {'expired','not_merged','micro_wait','skipped'} else '❔'
            lines.append(f"- {icon} {labels.get(k,k)}: {v}개")
    else: lines.append('- trace 없음')
    lines += ['', '[이유 TOP]']
    if reasons:
        for k,v in reasons.most_common(10): lines.append(f"- ❔ {'S1미달' if k == 'S1아님' else k}: {v}개")
    else: lines.append('- 이유 없음')
    lines += ['', '[재확인 후보 TOP]']
    risky=[r for r in rows if str(r.get('status') or '') not in {'open','closed','selected_for_open'}]
    for r in risky[:10]:
        st=str(r.get('status') or '-')
        lines.append(f"- ⚠️ {norm_ticker(r.get('ticker'))} / {r.get('strategy') or r.get('strategy_key','-')} / score {r.get('score','-')} / 상태 {labels.get(st,st)} / 이유 {r.get('reason','-')}")
    if not risky: lines.append('- 현재 재확인 후보 없음')
    return '\n'.join(lines)


def batch_handler(update, context):  # type: ignore[override]
    cmds = context.args or ['health','pstatus','score','s1_review','missed_trace','errorlog']
    cmds = [str(x).strip().lstrip('/') for x in cmds[:10] if str(x).strip()]
    st = time.time(); sent = 0; timings = []
    try:
        send(update, f"📦 자동 묶음 명령 접수\n- 실행 {len(cmds)}개\n- v402: S1 손실 정밀판 단일화")
    except Exception:
        pass
    total = len(cmds)
    for raw in cmds:
        name = raw.strip().lstrip('/')
        fn = COMMANDS.get(name)
        if not fn:
            continue
        t = time.time()
        try:
            body = fn(); ok = 'OK'
        except Exception as exc:
            body = f"❌ /{name} 오류 {exc.__class__.__name__}: {exc}"; ok = 'ERR'; log_error(f'batch_{name}', exc)
        sec = time.time() - t; sent += 1
        timings.append(f"- {'✅' if ok=='OK' else '❌'} /{name}: {sec:.2f}s / {ok}")
        send(update, f"[{sent}/{total}] /{name} ({sec:.2f}s / {ok})\n{body}")
    send(update, "🧾 자동 묶음 시간표 · v402 명령별 전송\n" + "\n".join(timings) + f"\n- 합계 {time.time()-st:.2f}s")

try:
    COMMANDS.update({'health': health_text, 'core': health_text, 'score': score_text, 'pscore': pscore_text, 'pstatus': pstatus_text, 'missed_trace': missed_trace_text, 'trace_missed': missed_trace_text})
except Exception:
    pass


# =============================================================================
# v402: S1 손실 정밀판 단일화
# - 원인표를 여러 개 늘리지 않고 /s1_review 한 장으로 모은다.
# - 조건/전략/청산을 여기서 바꾸지 않는다. 현재 장부를 읽어 원인 묶음과 다음 확인 후보만 보여준다.
# - 기본 명령은 캐시/장부 조회 전용이며, paper 실행/장부 삭제/복구를 하지 않는다.
# =============================================================================

def _v402_closed_ts(row: Dict[str, Any]) -> float:
    return fnum(row.get('closed_at'), row.get('closed_ts'), row.get('close_ts'), row.get('exit_ts'), row.get('timestamp'), row.get('updated_at'), default=0.0)


def _v402_hold_min(row: Dict[str, Any]) -> float:
    direct = fnum(row.get('age_min'), row.get('hold_min'), row.get('duration_min'), default=-1.0)
    if direct >= 0:
        return direct
    sec = fnum(row.get('hold_sec'), row.get('duration_sec'), default=-1.0)
    return sec / 60.0 if sec >= 0 else 0.0


def _v402_flat(row: Dict[str, Any]) -> Dict[str, Any]:
    try:
        return _snapshot_flat(row)
    except Exception:
        row = as_dict(row)
        ctx = as_dict(row.get('entry_context'))
        out = dict(ctx)
        out.update({k:v for k,v in row.items() if k not in {'entry_context','entry_snapshot'}})
        return out


def _v402_strategy_label(row: Dict[str, Any]) -> str:
    key = _v401_strategy_key(row)
    return STRATEGY_LABELS.get(key, key if key != 'unknown' else '전략키 미기록')


def _v402_exit_label(row: Dict[str, Any]) -> str:
    return str(row.get('exit_rule_label') or row.get('exit_reason') or row.get('close_reason') or row.get('reason') or '-')


def _v402_peak_pct(row: Dict[str, Any]) -> float:
    ctx = _v402_flat(row)
    return fnum(row.get('peak_pct'), row.get('max_profit_pct'), row.get('max_pnl_pct'), row.get('max_unrealized_pct'), ctx.get('peak_pct'), ctx.get('max_profit_pct'), default=0.0)


def _v402_trough_pct(row: Dict[str, Any]) -> float:
    ctx = _v402_flat(row)
    return fnum(row.get('trough_pct'), row.get('min_profit_pct'), row.get('min_pnl_pct'), row.get('min_unrealized_pct'), ctx.get('trough_pct'), ctx.get('min_profit_pct'), default=0.0)


def _v402_ctx_metric(row: Dict[str, Any], *keys: str, default: float = -1.0) -> float:
    ctx = _v402_flat(row)
    return fnum(*(ctx.get(k) for k in keys), default=default)


def _v402_entry_reason(row: Dict[str, Any]) -> str:
    ctx = _v402_flat(row)
    vals = [
        row.get('entry_reason'), row.get('reason'), row.get('watch_note'), row.get('signal_reason'), row.get('decision_reason'),
        ctx.get('entry_reason'), ctx.get('reason'), ctx.get('watch_note'), ctx.get('signal_reason'), ctx.get('decision_reason'),
        row.get('strategy_label'), row.get('strategy'), row.get('strategy_key'), ctx.get('strategy_label'), ctx.get('strategy_key'),
    ]
    for v in vals:
        s = str(v or '').strip()
        if s and s not in {'-', 'None', 'unknown'}:
            return s[:80]
    return _v402_strategy_label(row)


def _v402_loss_causes(row: Dict[str, Any]) -> List[str]:
    pnl = fnum(row.get('pnl_pct'), row.get('profit_pct'), row.get('return_pct'), default=0.0)
    peak = _v402_peak_pct(row)
    trough = _v402_trough_pct(row)
    hold = _v402_hold_min(row)
    exit_label = _v402_exit_label(row)
    buy = _v402_ctx_metric(row, 'buy_ratio', 'micro_trade_buy_ratio_30', 'buy_trade_ratio', 'buy_ratio_30s')
    buy_s = _v402_ctx_metric(row, 'buy_ratio_1m', 'micro_buy_ratio_sustain_1m', 'buy_ratio_sustain')
    spread = _v402_ctx_metric(row, 'spread_pct', 'orderbook_spread_pct')
    vwap = _v402_ctx_metric(row, 'vwap_gap_pct', 'vwap_gap')
    ema = _v402_ctx_metric(row, 'ema5_gap_pct', 'ema_gap_pct', 'ema_gap')
    ch3 = _v402_ctx_metric(row, 'change_3m', 'price_change_3m', 'chg_3m')
    ch5 = _v402_ctx_metric(row, 'change_5m', 'price_change_5m', 'chg_5m')
    ctx = _v402_flat(row)
    causes: List[str] = []
    if pnl < 0:
        if peak <= 0.05:
            causes.append('진입후무반응')
        elif peak <= 0.20:
            causes.append('초반반응약함')
        if hold and hold <= 3:
            causes.append('초단기역행')
        elif hold and hold <= 8 and '손절' in exit_label:
            causes.append('짧은보유손절')
        if '시간' in exit_label:
            causes.append('시간청산까지회복없음')
        if '손절' in exit_label:
            causes.append('손절선도달')
        if trough <= -0.70 or pnl <= -0.70:
            causes.append('깊은역행')
    if 0 <= buy < 0.62:
        causes.append('매수체결약함')
    if 0 <= buy_s < 0.58:
        causes.append('체결지속약함')
    if spread >= 0.25:
        causes.append('스프레드부담')
    if vwap != -1.0 and vwap < -0.10:
        causes.append('VWAP아래진입')
    if ema != -1.0 and ema < -0.15:
        causes.append('EMA아래진입')
    if ch3 != -1.0 and ch5 != -1.0 and ch3 <= 0.05 and ch5 <= 0.10:
        causes.append('가격반응부족')
    if not any(k in ctx for k in ('buy_ratio','micro_trade_buy_ratio_30','spread_pct','vwap_gap_pct','change_3m','price_change_3m','ema5_gap_pct')):
        causes.append('진입스냅샷부족')
    if not causes and pnl < 0:
        try:
            causes = _loss_causes(row)
        except Exception:
            causes = []
    if not causes:
        causes.append('원인추가확인')
    out: List[str] = []
    for c in causes:
        if c and c not in out:
            out.append(c)
    return out[:5]


def _v402_next_check(causes: List[str]) -> str:
    s = set(causes)
    if '진입후무반응' in s or '초반반응약함' in s:
        return 'S1승격 직후 1~3분 반응/최고수익 기준 확인'
    if '매수체결약함' in s or '체결지속약함' in s:
        return 'micro 체결지속값이 S1 승격 전에 실제 붙었는지 확인'
    if 'VWAP아래진입' in s or 'EMA아래진입' in s:
        return '추세유지 조건이 진입 직전 값으로 들어왔는지 확인'
    if '시간청산까지회복없음' in s:
        return '시간청산 후보의 진입 후 추가상승 실패 조건 확인'
    if '진입스냅샷부족' in s:
        return 'paper CLOSED에 entry_context 저장 누락 경로 확인'
    return '전략쏠림/진입타이밍을 대표전략별로 비교'


def _v402_counter_lines(title: str, counter: Counter, limit: int = 8) -> List[str]:
    lines = [title]
    if not counter:
        return lines + ['- 집계 없음']
    for k, v in counter.most_common(limit):
        lines.append(f"- {k}: {v}건")
    return lines


def s1_review_text() -> str:
    rows = sorted(_v401_closed_rows(2600), key=_v402_closed_ts, reverse=True)
    s1_rows = [r for r in rows if _v401_grade(r) == 'S1']
    target = s1_rows if s1_rows else rows
    wins = [r for r in target if fnum(r.get('pnl_pct'), r.get('profit_pct'), default=0.0) > 0]
    losses = [r for r in target if fnum(r.get('pnl_pct'), r.get('profit_pct'), default=0.0) < 0]
    total = sum(fnum(r.get('pnl_pct'), r.get('profit_pct'), default=0.0) for r in target)
    avg = total / len(target) if target else 0.0
    by_strategy = Counter(_v402_strategy_label(r) for r in target)
    by_exit = Counter(_v402_exit_label(r) for r in target)
    cause_counter: Counter = Counter()
    strategy_cause: Dict[str, Counter] = {}
    for r in losses:
        st = _v402_strategy_label(r)
        strategy_cause.setdefault(st, Counter())
        for c in _v402_loss_causes(r):
            cause_counter[c] += 1
            strategy_cause[st][c] += 1
    verdict = '✅ 표본대기'
    if len(target) >= 10 and not wins:
        verdict = '❌ S1 품질위험: 10건 이상 무승'
    elif len(target) >= 10 and avg < -0.30:
        verdict = '⚠️ S1 손실우세: 평균손익 음수'
    elif len(target) < 10:
        verdict = '❔ 표본적음: CLOSED 10건 미만'
    lines = [
        '🧨 S1 손실 정밀판 /s1_review',
        '- 목적: 원인표를 여러 개 보지 않고, S1 진입이 왜 졌는지 한 화면에서 봅니다.',
        f"- 기준: paper_bot_v0.125 CLOSED 직접조회 / 장부 age {age(FILES.get('paper_closed', BASE_DIR/'paper_bot_closed.jsonl')):.1f}s",
        f"- 판독: {verdict}",
        f"- S1 기준: {len(target)}전 {len(wins)}승 {len(losses)}패 / 승률 {(len(wins)/len(target)*100.0 if target else 0):.1f}% / 합산 {total:+.2f}% / 평균 {avg:+.2f}%",
        '- 실행판정: OPEN→CLOSED→알림→score 반영은 정상. 지금 보는 건 실행오류가 아니라 S1 선별품질입니다.',
        '',
    ]
    lines += _v402_counter_lines('[대표전략 쏠림]', by_strategy, 8)
    lines += [''] + _v402_counter_lines('[종료이유 쏠림]', by_exit, 8)
    lines += [''] + _v402_counter_lines('[손실원인 TOP · 중복집계]', cause_counter, 10)
    lines += ['', '[전략별 핵심 원인]']
    if strategy_cause:
        for st, cc in sorted(strategy_cause.items(), key=lambda kv: sum(kv[1].values()), reverse=True)[:6]:
            tops = ' / '.join(f"{k} {v}" for k,v in cc.most_common(4))
            lines.append(f"- {st}: {tops}")
    else:
        lines.append('- 손실 표본 없음')
    lines += ['', '[최근 S1 CLOSED 상세 · 최근 10건]']
    for r in target[:10]:
        t = norm_ticker(r.get('ticker') or r.get('symbol')) or '-'
        pnl = fnum(r.get('pnl_pct'), r.get('profit_pct'), default=0.0)
        hold = _v402_hold_min(r)
        peak = _v402_peak_pct(r)
        trough = _v402_trough_pct(r)
        buy = _v402_ctx_metric(r, 'buy_ratio', 'micro_trade_buy_ratio_30', 'buy_trade_ratio')
        spread = _v402_ctx_metric(r, 'spread_pct', 'orderbook_spread_pct')
        causes = _v402_loss_causes(r)
        buy_txt = '-' if buy < 0 else f"{buy:.2f}"
        sp_txt = '-' if spread < 0 else f"{spread:.2f}%"
        lines.append(f"- {t} / {pnl:+.2f}% / {_v402_exit_label(r)} / 보유 {hold:.1f}분 / {_v402_strategy_label(r)}")
        lines.append(f"  · 진입근거: {_v402_entry_reason(r)}")
        lines.append(f"  · 흐름: 최고 {peak:+.2f}% / 최저 {trough:+.2f}% / 매수체결 {buy_txt} / 스프레드 {sp_txt} / 원인 {', '.join(causes)}")
        lines.append(f"  · 다음확인: {_v402_next_check(causes)}")
    if len(target) > 10:
        lines.append(f"- 나머지 {len(target)-10}건은 같은 장부 기준으로 집계에 포함됨")
    lines += ['', '[수정 후보 · 아직 조건 변경 아님]']
    if cause_counter:
        top_cause = cause_counter.most_common(1)[0][0]
        lines.append(f"1) 최다 원인 '{top_cause}'가 entry_context 실제값 문제인지 S1 조건 문제인지 분리")
    else:
        lines.append('1) CLOSED가 더 쌓이면 원인 TOP부터 분리')
    if by_strategy:
        top_strategy, top_n = by_strategy.most_common(1)[0]
        lines.append(f"2) 최다 전략 '{top_strategy}' {top_n}건 쏠림 확인: 이 전략만 S1 신규진입 중지/강등할지 검토")
    lines.append('3) 바로 조건 조이기 금지: 먼저 진입스냅샷 누락/체결값 누락이면 배관부터 고침')
    lines.append('4) 실제 수정은 이 판독 결과를 보고 한 번에 묶어서 진행')
    return '\n'.join(lines)


def set_commands(updater):  # type: ignore[override]
    try:
        updater.bot.set_my_commands([
            BotCommand('health','메인/worker/paper 빠른상태'),
            BotCommand('workers','worker 상세 상태'),
            BotCommand('score','S1/S2/S3 성과'),
            BotCommand('s1_review','S1 손실 정밀판'),
            BotCommand('version_score','버전별 성과'),
            BotCommand('quality','S1/S2/S3 후보품질'),
            BotCommand('pstatus','paper 상태'),
            BotCommand('popen','paper OPEN'),
            BotCommand('missed_trace','후보 handoff 추적'),
            BotCommand('errorlog','오류로그'),
            BotCommand('batch','묶음 확인'),
        ])
    except Exception as exc:
        log_error('set_commands', exc)

try:
    COMMANDS.update({
        'health': health_text,
        'core': health_text,
        'score': score_text,
        'pscore': pscore_text,
        's1_review': s1_review_text,
        's1review': s1_review_text,
        'loss_review': s1_review_text,
        'ploss_review': s1_review_text,
        'pstatus': pstatus_text,
        'missed_trace': missed_trace_text,
        'trace_missed': missed_trace_text,
    })
except Exception:
    pass


# =============================================================================
# v403: 조건지도 + 전략별 S3/S2/S1 단일화 표시
# - 전략 조건 따로, 생애주기 S단계 따로 보이던 구조를 한 화면에 보여준다.
# - 실제 S1 OPEN 경로는 strategy_worker_v0.30의 전략별 단계판정 단일 본선을 기준으로 한다.
# =============================================================================

def _v403_condition_map_fallback() -> Dict[str, Any]:
    return {
        "version": "main_v403_fallback",
        "schema": "strategy_stage_unified_v403",
        "summary": "전략별 조건 안에서 S3/S2/S1을 결정한다. 독립 S2→S1 승격판은 최종 OPEN 경로에서 사용하지 않는다.",
        "common_hard_blocks": [
            "최근 반복손실/하드손실", "이미 OPEN 중", "거래대금 2.5억 미만", "윗꼬리/고점끝물 위험",
            "micro fresh 시 스프레드 과다", "micro fresh 시 매수체결 부족", "매도벽/매도체결압력"
        ],
        "common_s1_safety": [
            "micro fresh + WS/quote fresh", "매수체결비 0.70 이상", "1분 체결지속 0.64 이상",
            "스프레드 0.18% 이하", "슬리피지 확인 0.20% 이하", "매도벽 확인/매도압력 없음",
            "가격반응 0.05 이상", "단기 반응 30초/1분/3분 중 확인", "VWAP -0.03 이상", "EMA5 -0.05 이상"
        ],
        "common_s2_recheck": [
            "micro fresh", "매수체결비 0.62 이상", "스프레드 0.28% 이하", "매도압력 없음",
            "VWAP -0.08 이상", "EMA5 -0.12 이상", "가격반응/단기흐름/거래량 중 재확인 재료"
        ],
        "stage_policy": [
            "S3: 전략별 관찰/복기 후보", "S2: 전략별 재확인/정보보강 후보", "S1: 전략별 S1 추가조건 + 공통 S1 안전문 통과 후보만 paper OPEN",
            "과거 독립 lifecycle S3→S2→S1 가격추적 승격은 최종 OPEN 경로에서 격리"
        ],
        "strategies": {
            "money_reaccel_s": {"label":"돈흐름 재가속", "core":["3분 0.25%↑", "5분 0.35%↑", "VWAP -0.05 이상", "EMA5 -0.08 이상", "거래량 확장"], "s1_extra":["3분 0.35%↑", "5분 0.45%↑", "거래량 확장", "상대강도 0 이상"], "s2_extra":["3분 0.20%↑ 또는 5분 0.35%↑ 또는 거래량 확장"]},
            "leader_momentum_s": {"label":"주도추세 지속", "core":["15분 0.65%↑", "30분 0.65%↑", "상대강도 0.30↑", "VWAP/EMA 양호", "장세 약함 제외"], "s1_extra":["15분 0.75%↑", "30분 0.75%↑", "상대강도 0.40↑", "장세 약함 아님"], "s2_extra":["15분 0.60%↑", "상대강도 0.25↑", "VWAP -0.05 이상", "가격반응 재료"]},
            "breakout_early_s": {"label":"돌파 초입", "core":["돌파캔들", "고점거리 -0.15 이상", "끝물추격 위험 제외"], "s1_extra":["돌파캔들", "거래량 확장", "고점거리 -0.08 이상", "3분 0.15%↑", "고점권 아님"], "s2_extra":["돌파캔들", "고점거리 -0.25 이상", "거래량 또는 3분 0.15%↑"]},
            "sweep_vwap_recovery_s": {"label":"저점 VWAP 회복", "core":["저점쓸림 회복", "VWAP -0.05 이상", "저점반등 0.40%↑"], "s1_extra":["저점회복", "저점반등 0.55%↑", "3분 0.08%↑", "당일위치 88% 미만"], "s2_extra":["저점회복", "VWAP -0.08 이상", "저점반등 0.35%↑", "가격반응 재료"]},
            "surge_rebreak_s": {"label":"급등 후 재돌파", "core":["15분 1.20%↑", "3분 0.15%↑", "고점접근 -0.25 이상", "윗꼬리 제외"], "s1_extra":["15분 1.20%↑", "3분 0.25%↑", "고점접근 -0.15 이상", "과열 아님"], "s2_extra":["15분 1.00%↑", "고점접근 -0.30 이상", "가격반응 재료"]},
            "leader_flow_adaptive_hold_s": {"label":"주도흐름 유동보유", "core":["3분/5분 단기흐름 또는 15/30분 중기흐름", "VWAP -0.10 이상", "EMA5 -0.15 이상", "거래대금 3억 이상", "최소 매수체결/스프레드"], "s1_extra":["15분 0.70%↑", "30분 0.40%↑", "상대강도 0 이상", "VWAP -0.03 이상", "EMA5 -0.05 이상", "3분 0.20%↑ 또는 5분 0.45%↑ 또는 거래량 확장", "고점권 아님"], "s2_extra":["15분 0.55%↑ 또는 5분 0.55%↑", "VWAP -0.08 이상", "EMA5 -0.12 이상"]}
        }
    }


def _v403_condition_map_obj() -> Dict[str, Any]:
    strat = _v398_load_json_small(FILES.get('strategy_summary', BASE_DIR/'clean_strategy_s_summary.json'), {}) or {}
    cmap = strat.get('condition_map') if isinstance(strat, dict) else None
    if isinstance(cmap, dict) and cmap:
        return cmap
    # 별도 파일이 있으면 우선 사용
    try:
        p = BASE_DIR / 'clean_strategy_condition_map.json'
        cmap2 = _v398_load_json_small(p, {}) or {}
        if isinstance(cmap2, dict) and cmap2:
            return cmap2
    except Exception:
        pass
    return _v403_condition_map_fallback()


def condition_map_text() -> str:
    cmap = _v403_condition_map_obj()
    lines = [
        '🧭 조건지도 /condition_map',
        '- 목적: 공통 조건, 전략별 조건, S3/S2/S1 단계가 어디서 갈라지는지 한 화면에서 봅니다.',
        f"- 기준: {cmap.get('schema','-')} / {cmap.get('version','-')}",
        f"- 결론: {cmap.get('summary','전략별 단계판정 단일화')}",
        '', '[공통 차단 조건]'
    ]
    for x in cmap.get('common_hard_blocks', [])[:12]:
        lines.append(f"- {x}")
    lines += ['', '[공통 S1 안전문 · 실제 OPEN 직전]']
    for x in cmap.get('common_s1_safety', [])[:14]:
        lines.append(f"- {x}")
    lines += ['', '[공통 S2 재확인문 · 매수 아님]']
    for x in cmap.get('common_s2_recheck', [])[:12]:
        lines.append(f"- {x}")
    lines += ['', '[S3/S2/S1 정책]']
    for x in cmap.get('stage_policy', [])[:10]:
        lines.append(f"- {x}")
    lines += ['', '[전략별 조건]']
    strategies = cmap.get('strategies') if isinstance(cmap.get('strategies'), dict) else {}
    order = ['money_reaccel_s','leader_momentum_s','breakout_early_s','sweep_vwap_recovery_s','surge_rebreak_s','leader_flow_adaptive_hold_s']
    for key in order:
        obj = strategies.get(key) if isinstance(strategies.get(key), dict) else {}
        if not obj:
            continue
        lines.append(f"\n▶ {obj.get('label', key)}")
        core = ' / '.join(map(str, obj.get('core', [])[:5])) or '-'
        s2 = ' / '.join(map(str, obj.get('s2_extra', [])[:5])) or '-'
        s1 = ' / '.join(map(str, obj.get('s1_extra', [])[:7])) or '-'
        lines.append(f"- core: {core}")
        lines.append(f"- S2: {s2}")
        lines.append(f"- S1: {s1}")
    lines += ['', '[판독]', '- 이제 S1은 독립 lifecycle 가격추적 승격이 아니라, 전략별 S1 조건 + 공통 S1 안전문이 같이 맞아야 합니다.', '- S2/S3는 계속 남기되, S2/S3 자체가 paper OPEN 조건이 되지는 않습니다.']
    return '\n'.join(lines)


# v403 s1_review 하단에 조건지도 기준을 함께 표시한다.
_v403_prev_s1_review_text = s1_review_text

def s1_review_text() -> str:  # type: ignore[override]
    body = _v403_prev_s1_review_text()
    cmap = _v403_condition_map_obj()
    return body + "\n\n[조건 구조 기준 · v403]\n- " + str(cmap.get('summary','전략별 S3/S2/S1 단일화')) + "\n- 상세 조건은 /condition_map 에서 확인"


def batch_handler(update, context):  # type: ignore[override]
    cmds = context.args or ['health','pstatus','score','s1_review','condition_map','missed_trace','errorlog']
    cmds = [str(x).strip().lstrip('/') for x in cmds[:10] if str(x).strip()]
    st = time.time(); sent = 0; timings = []
    try:
        send(update, f"📦 자동 묶음 명령 접수\n- 실행 {len(cmds)}개\n- v403: 조건지도 + 전략별 S3/S2/S1 단일화")
    except Exception:
        pass
    total = len(cmds)
    for raw in cmds:
        name = raw.strip().lstrip('/')
        fn = COMMANDS.get(name)
        if not fn:
            continue
        t = time.time()
        try:
            body = fn(); ok = 'OK'
        except Exception as exc:
            body = f"❌ /{name} 오류 {exc.__class__.__name__}: {exc}"; ok = 'ERR'; log_error(f'batch_{name}', exc)
        sec = time.time() - t; sent += 1
        timings.append(f"- {'✅' if ok=='OK' else '❌'} /{name}: {sec:.2f}s / {ok}")
        send(update, f"[{sent}/{total}] /{name} ({sec:.2f}s / {ok})\n{body}")
    send(update, "🧾 자동 묶음 시간표 · v403 명령별 전송\n" + "\n".join(timings) + f"\n- 합계 {time.time()-st:.2f}s")


def set_commands(updater):  # type: ignore[override]
    try:
        updater.bot.set_my_commands([
            BotCommand('health','메인/worker/paper 빠른상태'),
            BotCommand('workers','worker 상세 상태'),
            BotCommand('score','S1/S2/S3 성과'),
            BotCommand('s1_review','S1 손실 정밀판'),
            BotCommand('condition_map','조건지도'),
            BotCommand('version_score','버전별 성과'),
            BotCommand('quality','S1/S2/S3 후보품질'),
            BotCommand('pstatus','paper 상태'),
            BotCommand('popen','paper OPEN'),
            BotCommand('missed_trace','후보 handoff 추적'),
            BotCommand('errorlog','오류로그'),
            BotCommand('batch','묶음 확인'),
        ])
    except Exception as exc:
        log_error('set_commands', exc)

try:
    COMMANDS.update({
        'health': health_text,
        'core': health_text,
        'score': score_text,
        'pscore': pscore_text,
        's1_review': s1_review_text,
        's1review': s1_review_text,
        'condition_map': condition_map_text,
        'conditions': condition_map_text,
        'loss_review': s1_review_text,
        'ploss_review': s1_review_text,
        'pstatus': pstatus_text,
        'missed_trace': missed_trace_text,
        'trace_missed': missed_trace_text,
    })
except Exception:
    pass

# v406: early main call disabled so tail command registrations load before polling
# if __name__=='__main__': main()


# =============================================================================
# main v2.13.374 / v406: S1 후보 점검판 + 쉬운 문구
# - 개발자 단어를 줄이고 S1 미달 사유를 사람말로 표시한다.
# - "정보부족"은 가격/WS/micro/체결/스프레드/슬리피지/매도벽 등으로 나눈다.
# - 조건 수치 자체는 바꾸지 않는다.
# =============================================================================
BOT_VERSION = "수익형 v2.13.377"
RESTORE_BUILD = "v409_v377_s1_decision_route_fix_2026-05-24"
S1_BLOCK_AUDIT_FILE = BASE_DIR / "clean_strategy_s1_block_audit.json"

_EASY_STRATEGY = {
    'money_reaccel_s':'돈흐름 재가속', 'leader_momentum_s':'주도추세 지속', 'breakout_early_s':'돌파 초입',
    'sweep_vwap_recovery_s':'저점 VWAP 회복', 'surge_rebreak_s':'급등 후 재돌파', 'leader_flow_adaptive_hold_s':'주도흐름 유동보유'
}

def _v405_load_audit() -> Dict[str, Any]:
    obj = _v398_load_json_small(S1_BLOCK_AUDIT_FILE, {}) or {}
    return obj if isinstance(obj, dict) else {}

def _v405_easy_reason(x: Any) -> str:
    t = str(x or '').strip()
    repl = {
        'S1아님':'S1 실제진입 조건 미달', 'not_s1':'S1 실제진입 조건 미달', 'micro재확인필요':'호가·체결 재확인 필요',
        'WS재확인필요':'실시간 시세 재확인 필요', '가격반응미확인':'가격반응 값 없음', '매수체결지속미확인':'1분 매수지속 값 없음',
        '슬리피지미확인/주의':'예상 미끄러짐 확인 필요', '매도벽미확인':'매도벽 정보 없음', '스프레드주의':'스프레드 부담',
    }
    for k,v in repl.items(): t = t.replace(k,v)
    return t or '-'

def _v405_top_lines(title: str, d: Any, icon: str='⚠️', limit: int=7) -> List[str]:
    lines=[title]
    if not isinstance(d, dict) or not d:
        lines.append('- 없음')
        return lines
    top=sorted(d.items(), key=lambda kv: int(fnum(kv[1], default=0)), reverse=True)[:limit]
    for k,v in top:
        lines.append(f"- {icon} {_v405_easy_reason(k)}: {int(fnum(v, default=0))}개")
    return lines

def _v405_fmt_missing(items: Any, limit: int=4) -> str:
    if not isinstance(items, list) or not items: return '없음'
    vals=[]
    for x in items[:limit]:
        if isinstance(x, dict): vals.append(str(x.get('label') or x.get('key') or '-'))
        else: vals.append(str(x))
    return ', '.join(vals) if vals else '없음'

def _v405_fmt_fail(items: Any, limit: int=3) -> str:
    if not isinstance(items, list) or not items: return '추가확인'
    vals=[]
    for x in items[:limit]:
        if isinstance(x, dict):
            label=str(x.get('label') or x.get('key') or '-')
            val=str(x.get('value') or '')
            vals.append(label + (f"({val})" if val else ''))
        else: vals.append(str(x))
    return ' / '.join(vals)

def s1_candidates_text() -> str:
    audit=_v405_load_audit()
    strat=_v398_load_json_small(FILES['strategy_summary'], {}) or {}
    sc = strat.get('s_stage_counts') if isinstance(strat.get('s_stage_counts'), dict) else {}
    samples = audit.get('samples') if isinstance(audit.get('samples'), list) else []
    age=_v398_file_age(S1_BLOCK_AUDIT_FILE)
    lines=[
        '🔎 S1 후보 점검 /s1_candidates',
        '- 목적: 후보가 왜 실제진입(S1)이 아닌지 쉽게 봅니다.',
        '- 기준: 부족정보를 한 단어로 뭉치지 않고 세부 항목으로 나눕니다.',
        f"- 갱신: {age:.1f}s 전 / 구조 {audit.get('schema', strat.get('stage_policy_schema','-'))}",
        f"- 현재 후보: S1 {sc.get('S1',0)} / S2 {sc.get('S2',0)} / S3 {sc.get('S3',0)} / latest {strat.get('paper_latest_count','-')}",
        '',
    ]
    lines += _v405_top_lines('[왜 S1이 아닌지 TOP]', audit.get('reason_top'), '⚠️', 8)
    lines += [''] + _v405_top_lines('[없는 정보 TOP]', audit.get('missing_info_top'), '❔', 8)
    sm = audit.get('strategy_missing_info') if isinstance(audit.get('strategy_missing_info'), dict) else {}
    lines += ['', '[전략별 부족정보]']
    if sm:
        for name, d in list(sm.items())[:6]:
            if isinstance(d, dict) and d:
                top=sorted(d.items(), key=lambda kv:int(fnum(kv[1],default=0)), reverse=True)[:4]
                lines.append(f"- {name}: " + ' / '.join(f"{_v405_easy_reason(k)} {int(fnum(v,default=0))}" for k,v in top))
    else:
        lines.append('- 아직 집계 없음')
    lines += ['', '[재확인 후보 TOP]']
    if samples:
        for s in samples[:10]:
            if not isinstance(s, dict): continue
            lines.append(f"- ⚠️ {norm_ticker(s.get('ticker'))} / {s.get('strategy','-')} / {s.get('stage','-')} / 점수 {s.get('score','-')}")
            lines.append(f"  · 못 산 이유: {_v405_easy_reason(s.get('summary'))}")
            lines.append(f"  · 없는 정보: {_v405_fmt_missing(s.get('missing'))}")
            lines.append(f"  · 필요정보: {s.get('required_ready','-')}/{s.get('required_total','-')}개 준비")
    else:
        lines.append('- 재확인 후보 샘플 없음')
    outside=audit.get('outside_reference_info') if isinstance(audit.get('outside_reference_info'), list) else []
    lines += ['', '[다른 단타 방식과 비교해 아직 약한 보조정보]', '- 아래 항목은 바로 조건에 넣자는 뜻이 아니라, 나중에 검토할 후보입니다.']
    if outside:
        for x in outside[:6]:
            if isinstance(x, dict): lines.append(f"- ❔ {x.get('name','-')} / 상태 {x.get('status','-')} / {x.get('note','')}")
    else:
        lines.append('- 아직 점검값 없음')
    lines += ['', '[판독]', '- S1이 0이어도 바로 조건을 풀지 않습니다.', '- 먼저 어떤 정보가 없고, 어떤 조건에서 막히는지 보고 한 번에 수정합니다.']
    return '\n'.join(lines)

_old_pstatus_v405 = pstatus_text

def pstatus_text() -> str:  # type: ignore[override]
    body = _old_pstatus_v405()
    body = body.replace('🧪 paper 상태 /pstatus · v0.125 단일장부 연결', '🧪 paper 상태 /pstatus · paper v0.126 호환 장부')
    body = body.replace('[실제 모의매매 성과 · v0.125 CLOSED 직접조회]', '[실제 모의매매 성과 · paper 장부 직접조회]')
    body = body.replace('선별배관:', '후보선별:')
    body = body.replace('S1선택', 'S1 실제진입 선택')
    body = body.replace('micro대기', '호가·체결 대기')
    body = body.replace('이번OPEN', '이번 진입')
    return body

_old_score_v405 = score_text

def score_text() -> str:  # type: ignore[override]
    body = _old_score_v405()
    body = body.replace('paper_bot_v0.125 CLOSED 장부 직접조회. 구 score cache는 기본 성과판에서 사용하지 않습니다.', 'paper v0.126 호환 CLOSED 장부 직접조회. 구 score cache는 기본 성과판에서 사용하지 않습니다.')
    body = body.replace('v0.125 CLOSED', 'paper CLOSED')
    return body

_old_s1_review_v405 = s1_review_text

def s1_review_text() -> str:  # type: ignore[override]
    body = _old_s1_review_v405()
    body = body.replace('paper_bot_v0.125 CLOSED 직접조회', 'paper v0.126 호환 CLOSED 직접조회')
    body = body.replace('entry_context', '진입 당시 기록')
    body = body.replace('micro', '호가·체결')
    body += '\n\n[다음 확인]\n- S1 후보가 안 열리면 /s1_candidates에서 막힌 이유와 부족정보를 먼저 봅니다.\n- 조건 수정은 /s1_candidates 결과를 본 뒤 한 번에 묶어서 진행합니다.'
    return body

def missed_trace_text() -> str:  # type: ignore[override]
    vers=_v398_paper_versions(); obj=vers.get('trace') if isinstance(vers.get('trace'),dict) else {}
    rows=obj.get('rows') if isinstance(obj,dict) and isinstance(obj.get('rows'),list) else []
    rows=[r for r in rows if isinstance(r,dict)][:300]
    audit=_v405_load_audit(); samples=audit.get('samples') if isinstance(audit.get('samples'),list) else []
    labels={'open':'OPEN됨','closed':'CLOSED됨','selected_for_open':'S1 선택됨','not_s1':'S1 실제진입 조건 미달','micro_wait':'호가·체결 재확인대기','merged_waiting_pick':'선별대기','expired':'후보만료','skipped':'스킵','not_merged':'미병합'}
    by=Counter(str(r.get('status') or 'unknown') for r in rows)
    lines=['🧭 후보 추적 /missed_trace', '- 기준: 후보가 paper까지 왔는지, S1 실제진입까지 갔는지 봅니다.', f"- paper {vers.get('paper_version')} / trace {vers.get('trace_version')} / trace age {vers.get('trace_age',0):.1f}s / rows {len(rows)}", '', '[상태]']
    if by:
        for k,v in by.most_common(8):
            icon='✅' if k in {'open','closed','selected_for_open'} else '⚠️' if k in {'expired','not_merged','micro_wait','skipped'} else '❔'
            lines.append(f"- {icon} {labels.get(k,k)}: {v}개")
    else: lines.append('- trace 없음')
    lines += [''] + _v405_top_lines('[S1 미달 이유]', audit.get('reason_top'), '⚠️', 6)
    lines += [''] + _v405_top_lines('[부족정보]', audit.get('missing_info_top'), '❔', 6)
    lines += ['', '[재확인 후보 TOP]']
    if samples:
        for s in samples[:10]:
            if not isinstance(s, dict): continue
            lines.append(f"- ⚠️ {norm_ticker(s.get('ticker'))} / {s.get('strategy','-')} / {s.get('stage','-')} / 점수 {s.get('score','-')}")
            lines.append(f"  · 이유: {_v405_easy_reason(s.get('summary'))}")
            lines.append(f"  · 부족: {_v405_fmt_missing(s.get('missing'))}")
    else:
        risky=[r for r in rows if str(r.get('status') or '') not in {'open','closed','selected_for_open'}]
        for r in risky[:10]:
            st=str(r.get('status') or '-')
            lines.append(f"- ⚠️ {norm_ticker(r.get('ticker'))} / {r.get('strategy') or r.get('strategy_key','-')} / 점수 {r.get('score','-')} / 상태 {labels.get(st,st)} / 이유 {_v405_easy_reason(r.get('reason','-'))}")
        if not risky: lines.append('- 현재 재확인 후보 없음')
    return '\n'.join(lines)

_old_condition_map_v405 = condition_map_text

def condition_map_text() -> str:  # type: ignore[override]
    body = _old_condition_map_v405()
    audit=_v405_load_audit(); cmap = (_v398_load_json_small(BASE_DIR/'clean_strategy_condition_map.json', {}) or {})
    req = cmap.get('strategy_required_info') if isinstance(cmap.get('strategy_required_info'), dict) else {}
    outside = cmap.get('outside_reference_info') if isinstance(cmap.get('outside_reference_info'), list) else []
    lines=[body, '', '[전략별 필요한 정보 · 쉬운 이름]']
    if req:
        for name, vals in req.items():
            if isinstance(vals, list): lines.append(f"- {name}: " + ', '.join(map(str, vals[:8])))
    else:
        lines.append('- 아직 조건지도 갱신 대기')
    lines += ['', '[다른 단타 방식 대비 보조정보 점검]', '- 바로 추가 조건이 아니라, 나중에 검토할 참고 목록입니다.']
    for x in outside[:6] if isinstance(outside, list) else []:
        if isinstance(x, dict): lines.append(f"- ❔ {x.get('name','-')} / {x.get('status','-')} / {x.get('note','')}")
    return '\n'.join(lines)

def batch_handler(update, context):  # type: ignore[override]
    cmds = context.args or ['health','pstatus','s1_candidates','missed_trace','errorlog']
    cmds = [str(x).strip().lstrip('/') for x in cmds[:10] if str(x).strip()]
    st = time.time(); sent = 0; timings = []
    try:
        send(update, f"📦 자동 묶음 명령 접수\n- 실행 {len(cmds)}개\n- v408: S1 후보 결론판 + 보조정보 완성")
    except Exception:
        pass
    total = len(cmds)
    for raw in cmds:
        name = raw.strip().lstrip('/')
        fn = COMMANDS.get(name)
        if not fn:
            sent += 1
            body = f"❌ /{name} 명령이 메인봇에 연결되지 않았습니다.\n- 이 줄이 보이면 명령 등록 누락입니다.\n- 그냥 건너뛰지 않고 표시하도록 바꿨습니다."
            timings.append(f"- ❌ /{name}: 미등록")
            send(update, f"[{sent}/{total}] /{name} (미등록)\n{body}")
            continue
        t = time.time()
        try:
            body = fn(); ok = 'OK'
        except Exception as exc:
            body = f"❌ /{name} 오류 {exc.__class__.__name__}: {exc}"; ok = 'ERR'; log_error(f'batch_{name}', exc)
        sec = time.time() - t; sent += 1
        timings.append(f"- {'✅' if ok=='OK' else '❌'} /{name}: {sec:.2f}s / {ok}")
        send(update, f"[{sent}/{total}] /{name} ({sec:.2f}s / {ok})\n{body}")
    send(update, "🧾 자동 묶음 시간표 · v407 명령별 전송\n" + "\n".join(timings) + f"\n- 합계 {time.time()-st:.2f}s")

try:
    if 'COMMANDS' in globals():
        COMMANDS.update({
            'health': health_text,
            'core': health_text,
            'pstatus': pstatus_text,
            'score': score_text,
            'pscore': score_text,
            's1_review': s1_review_text,
            's1review': s1_review_text,
            's1_candidates': s1_candidates_text,
            's1': s1_candidates_text,
            'condition_map': condition_map_text,
            'conditions': condition_map_text,
            'missed_trace': missed_trace_text,
            'trace_missed': missed_trace_text,
        })
except Exception:
    pass


def set_commands(updater):  # type: ignore[override]
    try:
        updater.bot.set_my_commands([
            BotCommand('health','전체 상태'),
            BotCommand('pstatus','paper 상태'),
            BotCommand('s1_candidates','S1 후보 점검'),
            BotCommand('missed_trace','후보 추적'),
            BotCommand('condition_map','조건지도'),
            BotCommand('score','성과표'),
            BotCommand('s1_review','S1 손익 점검'),
            BotCommand('errorlog','오류로그'),
            BotCommand('batch','묶음 확인'),
        ])
    except Exception as exc:
        log_error('set_commands', exc)


# =============================================================================
# main v2.13.375 / v407: 가격반응 배관수리 결과 표시 + 보조정보 쉬운 점검
# - strategy_worker v0.32가 만든 가격반응 계산방식과 보조정보 상태를 사람말로 보여준다.
# - 조건 수치 변경 없음. S1 후보 판단 보조판만 개선.
# =============================================================================

V407_WORDS = {
    'core': '기본 포착',
    'relative': '시장보다 강한 정도',
    'relative_strength': '시장보다 강한 정도',
    'breakout_hint': '돌파 신호',
    'recent_high_gap': '고점과의 거리',
    'volume_expanding': '거래량 증가',
    'price_alive_s2': '가격 반응 살아있음',
    'leader_flow_adaptive_hold_s': '주도흐름 유동보유',
    'money_reaccel_s': '돈흐름 재가속',
    'leader_momentum_s': '주도추세 지속',
    'breakout_early_s': '돌파 초입',
    'sweep_vwap_recovery_s': '저점 VWAP 회복',
    'surge_rebreak_s': '급등 후 재돌파',
    'market!=약함': '장이 너무 약하면 제외',
    'not high_end': '고점 끝물은 제외',
    'not overheat': '급등 과열은 제외',
    'no long_upper_wick': '윗꼬리 과하면 제외',
    'turnover': '거래대금',
    'min buy/spread': '최소 매수체결·스프레드 확인',
}

def _v407_easy_text(s: Any) -> str:
    text = str(s)
    for a,b in V407_WORDS.items():
        text = text.replace(a,b)
    text = text.replace('>=', ' ≥ ').replace('<=', ' ≤ ')
    text = text.replace('3m', '3분').replace('5m', '5분').replace('15m', '15분').replace('30m', '30분')
    text = text.replace('VWAP', 'VWAP').replace('EMA5', 'EMA5')
    return text

def _v407_top_plain(d: Any, icon: str='✅', limit: int=6) -> List[str]:
    if not isinstance(d, dict) or not d:
        return ['- 아직 없음']
    out=[]
    for k,v in sorted(d.items(), key=lambda kv:int(fnum(kv[1],default=0)), reverse=True)[:limit]:
        out.append(f"- {icon} {_v405_easy_reason(k)}: {int(fnum(v, default=0))}개")
    return out

_old_s1_candidates_v407 = s1_candidates_text

def s1_candidates_text() -> str:  # type: ignore[override]
    body = _old_s1_candidates_v407()
    audit = _v405_load_audit()
    lines = [body]
    prs = audit.get('price_reaction_sources') if isinstance(audit.get('price_reaction_sources'), dict) else {}
    lines += ['', '[가격반응 계산상태]', '- 조건을 푼 게 아니라, 비어 있던 가격반응을 계산 가능한 값으로 채웁니다.']
    if prs:
        for k,v in sorted(prs.items(), key=lambda kv:int(fnum(kv[1],default=0)), reverse=True)[:6]:
            icon = '✅' if k != '계산불가' else '❌'
            lines.append(f"- {icon} {_v405_easy_reason(k)}: {int(fnum(v,default=0))}개")
    else:
        lines.append('- 아직 가격반응 계산 집계 없음')
    samples = audit.get('samples') if isinstance(audit.get('samples'), list) else []
    if samples:
        lines += ['', '[후보별 가격반응 예시]']
        for s in samples[:5]:
            if not isinstance(s, dict): continue
            pr = s.get('price_reaction') if isinstance(s.get('price_reaction'), dict) else {}
            val = pr.get('value')
            src = pr.get('source') or '-'
            note = pr.get('note') or ''
            valtxt = '-' if val in (None, '') else f"{fnum(val, default=0):+.2f}%"
            lines.append(f"- {norm_ticker(s.get('ticker'))}: {valtxt} / {src} {('· '+str(note)) if note else ''}")
    aux_ready = audit.get('aux_ready_top') if isinstance(audit.get('aux_ready_top'), dict) else {}
    aux_missing = audit.get('aux_missing_top') if isinstance(audit.get('aux_missing_top'), dict) else {}
    lines += ['', '[보조정보 수집상태 · 조건 아님]', '- 아래 정보는 바로 매수조건으로 쓰지 않고, 이긴 후보/진 후보 비교용으로 저장합니다.']
    lines.append('✅ 들어오는 정보')
    lines += _v407_top_plain(aux_ready, '✅', 8)
    lines.append('❔ 아직 약한 정보')
    lines += _v407_top_plain(aux_missing, '❔', 8)
    lines += ['', '[판독 순서]', '1) 가격반응이 계산되는데도 S1이 0이면 → 조건이 센지 봅니다.', '2) 가격반응이 아직 계산불가면 → 배관부터 더 봅니다.', '3) 스프레드/미끄러짐이 큰 후보는 살리면 안 됩니다.']
    return '\n'.join(lines)

_old_condition_map_v407 = condition_map_text

def condition_map_text() -> str:  # type: ignore[override]
    body = _old_condition_map_v407()
    body = _v407_easy_text(body)
    audit = _v405_load_audit()
    pol = audit.get('price_reaction_policy') if isinstance(audit.get('price_reaction_policy'), list) else []
    lines = [body, '', '[가격반응 계산 기준 · v407]']
    if pol:
        for x in pol: lines.append(f"- {_v407_easy_text(x)}")
    else:
        lines += ['- 1순위: 전용 가격반응값', '- 2순위: 포착가 대비 현재가', '- 3순위: 30초/1분/3분 흐름으로 보조계산', '- 조건 수치 +0.05는 변경하지 않음']
    lines += ['', '[보기 쉽게 바꾼 말]', '- 기본 포착 = 전략 후보로 처음 잡는 조건', '- S3 = 관찰만, S2 = 재확인, S1 = 실제 모의진입', '- 시장보다 강한 정도 = 다른 코인/전체장보다 더 센지', '- 예상 미끄러짐 = 사자마자 호가 때문에 손해 볼 위험']
    return '\n'.join(lines)

_old_missed_trace_v407 = missed_trace_text

def missed_trace_text() -> str:  # type: ignore[override]
    body = _old_missed_trace_v407()
    audit = _v405_load_audit()
    prs = audit.get('price_reaction_sources') if isinstance(audit.get('price_reaction_sources'), dict) else {}
    if prs:
        extra = ['','[가격반응]', '- S1 미달 사유 중 가격반응은 이제 빈값이면 보조계산합니다.']
        for k,v in sorted(prs.items(), key=lambda kv:int(fnum(kv[1],default=0)), reverse=True)[:4]:
            extra.append(f"- {_v405_easy_reason(k)}: {int(fnum(v,default=0))}개")
        body += '\n' + '\n'.join(extra)
    return body

try:
    if 'COMMANDS' in globals():
        COMMANDS.update({
            's1_candidates': s1_candidates_text,
            's1': s1_candidates_text,
            'condition_map': condition_map_text,
            'conditions': condition_map_text,
            'missed_trace': missed_trace_text,
            'trace_missed': missed_trace_text,
        })
except Exception:
    pass

# batch 기본 구성만 v407 기준으로 한 번 더 고정
_old_batch_v407 = batch_handler

def batch_handler(update, context):  # type: ignore[override]
    if not getattr(context, 'args', None):
        context.args = ['health','pstatus','s1_candidates','missed_trace','condition_map','errorlog']
    return _old_batch_v407(update, context)





# =============================================================================
# main v2.13.376 / v408: S1 후보 결론판 + 보조정보 완성 표시
# - S1/S2/S3를 더 쪼개지 않고, S1 미달 후보를 사람이 보기 쉽게 판독한다.
# - 아까운 후보 / 재확인 후보 / 안 산 게 맞는 후보는 새 등급이 아니라 화면 해석이다.
# =============================================================================
RESTORE_BUILD = "v409_v377_s1_decision_route_fix_2026-05-24"

_DECISION_ORDER = ["✅ 아까운 후보", "⚠️ 재확인 후보", "❌ 안 산 게 맞음", "❔ 판독대기"]

def _v408_bucket_icon(text: Any) -> str:
    t=str(text or '')
    if '아까운' in t: return '✅'
    if '안 산 게 맞' in t or '버린' in t: return '❌'
    if '재확인' in t: return '⚠️'
    return '❔'

def _v408_short_reason(s: Dict[str, Any]) -> str:
    for k in ('review_decision_reason','decision_reason','why_decision'):
        v=s.get(k)
        if v: return str(v)
    return _v405_easy_reason(s.get('summary'))

_old_s1_candidates_v408_base = s1_candidates_text

def s1_candidates_text() -> str:  # type: ignore[override]
    audit=_v405_load_audit()
    body=_old_s1_candidates_v408_base()
    decision_top = audit.get('decision_top') if isinstance(audit.get('decision_top'), dict) else {}
    samples = audit.get('samples') if isinstance(audit.get('samples'), list) else []
    aux_ready = audit.get('aux_ready_top') if isinstance(audit.get('aux_ready_top'), dict) else {}
    aux_missing = audit.get('aux_missing_top') if isinstance(audit.get('aux_missing_top'), dict) else {}
    lines=[body]
    lines += ['', '━━━━━━━━━━━━━━━━━━━━', '🧭 최종 판독 · 새 등급 아님', '- S1/S2/S3 구조는 그대로입니다.', '- 아래 구분은 “왜 안 샀는지”를 사람이 빨리 보려고 붙인 해석입니다.', '']
    lines.append('[후보 판독 요약]')
    if decision_top:
        # display in stable user-friendly order first
        used=set()
        for name in _DECISION_ORDER:
            if name in decision_top:
                used.add(name); lines.append(f"- {name}: {int(fnum(decision_top.get(name), default=0))}개")
        for k,v in sorted(decision_top.items(), key=lambda kv:int(fnum(kv[1], default=0)), reverse=True):
            if k not in used:
                lines.append(f"- {_v408_bucket_icon(k)} {k}: {int(fnum(v, default=0))}개")
    else:
        lines.append('- 아직 판독 집계 없음')
    grouped={}
    for s in samples:
        if not isinstance(s, dict): continue
        d=str(s.get('review_decision') or s.get('decision') or '❔ 판독대기')
        grouped.setdefault(d, []).append(s)
    def one_line(s: Dict[str, Any]) -> str:
        t=norm_ticker(s.get('ticker'))
        strat=s.get('strategy') or s.get('strategy_key') or '-'
        stage=s.get('stage') or '-'
        score=s.get('score','-')
        return f"- {t} / {strat} / {stage} / 점수 {score}\n  · 이유: {_v408_short_reason(s)}\n  · 부족: {_v405_fmt_missing(s.get('missing'))}"
    for name in _DECISION_ORDER:
        arr=grouped.get(name, [])
        if not arr: continue
        lines += ['', f'[{name}]']
        for s in arr[:5]: lines.append(one_line(s))
    # include other groups, if any
    for name, arr in grouped.items():
        if name in _DECISION_ORDER or not arr: continue
        lines += ['', f'[{name}]']
        for s in arr[:3]: lines.append(one_line(s))
    lines += ['', '📌 지금 판단 기준']
    lines += ['- 스프레드·미끄러짐이 큰 후보는 손실 위험이 커서 안 산 게 맞습니다.', '- 정보가 다 있고 가격반응만 아주 살짝 부족한 후보는 “아까운 후보”로 따로 봅니다.', '- 조건 수치는 아직 바꾸지 않았고, 이 판독으로 놓친 후보를 복기합니다.']
    lines += ['', '[보조정보 완성도 · 조건 아님]']
    for label in ['RSI/과열 위치','MACD/추세 전환','볼린저밴드 위치','체결 속도 가속도','호가잔량 변화','BTC/전체장 선행 방향']:
        r=int(fnum(aux_ready.get(label), default=0)) if isinstance(aux_ready, dict) else 0
        m=int(fnum(aux_missing.get(label), default=0)) if isinstance(aux_missing, dict) else 0
        icon='✅' if r>0 and m==0 else '⚠️' if r>0 else '❔'
        lines.append(f"- {icon} {label}: 수집 {r} / 부족 {m}")
    return '\n'.join(lines)

_old_missed_trace_v408_base = missed_trace_text

def missed_trace_text() -> str:  # type: ignore[override]
    body=_old_missed_trace_v408_base()
    audit=_v405_load_audit()
    decision_top = audit.get('decision_top') if isinstance(audit.get('decision_top'), dict) else {}
    if decision_top:
        lines=[body, '', '[후보 판독 요약 · 새 등급 아님]']
        for name in _DECISION_ORDER:
            if name in decision_top:
                lines.append(f"- {name}: {int(fnum(decision_top.get(name), default=0))}개")
        return '\n'.join(lines)
    return body

_old_condition_map_v408_base = condition_map_text

def condition_map_text() -> str:  # type: ignore[override]
    body=_old_condition_map_v408_base()
    extra=['', '[v408 운영 기준]', '- S1/S2/S3 구조는 더 쪼개지 않습니다.', '- “아까운 후보/재확인 후보/안 산 게 맞는 후보”는 새 등급이 아니라 복기용 해석입니다.', '- RSI, MACD, 볼린저밴드, 체결속도, 호가잔량 변화, BTC/전체장 방향은 조건이 아니라 비교용 정보입니다.', '- 조건 수치 변경은 새 CLOSED/놓친 후보 결과를 본 뒤 한 번에 묶어서만 합니다.']
    return body + '\n' + '\n'.join(extra)

def batch_handler(update, context):  # type: ignore[override]
    if not getattr(context, 'args', None):
        context.args = ['health','pstatus','s1_candidates','missed_trace','condition_map','errorlog']
    return _old_batch_v407(update, context)



# =============================================================================
# main v2.13.377 / v409: v408 판독판 실제 명령 연결 수술
# - v408에서 COMMAND_TEXT로 잘못 연결된 경로를 제거하고 실제 COMMANDS에 연결한다.
# - /s1_candidates, /missed_trace, /condition_map은 v409 최종 함수 하나만 보게 한다.
# - S1/S2/S3 구조와 조건 수치는 변경하지 않는다.
# =============================================================================
RESTORE_BUILD = "v409_v377_s1_decision_route_fix_2026-05-24"
BOT_VERSION = "수익형 v2.13.377"

def _v409_force_schema_text(body: str) -> str:
    body = str(body or "")
    body = body.replace("strategy_stage_unified_v407_price_reaction_aux_info", "strategy_stage_unified_v409_decision_route_fix")
    body = body.replace("strategy_stage_unified_v408_s1_decision_aux_complete", "strategy_stage_unified_v409_decision_route_fix")
    body = body.replace("v407 명령별 전송", "v409 명령별 전송")
    body = body.replace("v408: S1 후보 결론판 + 보조정보 완성", "v409: S1 후보 판독판 실제 연결")
    return body

def _v409_decision_section(audit: Dict[str, Any]) -> str:
    lines = ["", "━━━━━━━━━━━━━━━━━━━━", "🧭 후보 판독 결론 · 새 등급 아님"]
    lines += ["- S1/S2/S3 구조는 그대로입니다.", "- 아래 구분은 ‘왜 안 샀는지’를 빨리 보기 위한 해석입니다."]
    decision_top = audit.get("decision_top") if isinstance(audit.get("decision_top"), dict) else {}
    samples = audit.get("samples") if isinstance(audit.get("samples"), list) else []
    lines += ["", "[판독 요약]"]
    if decision_top:
        used = set()
        for name in _DECISION_ORDER:
            if name in decision_top:
                used.add(name)
                lines.append(f"- {name}: {int(fnum(decision_top.get(name), default=0))}개")
        for k, v in sorted(decision_top.items(), key=lambda kv: int(fnum(kv[1], default=0)), reverse=True):
            if k not in used:
                lines.append(f"- {_v408_bucket_icon(k)} {k}: {int(fnum(v, default=0))}개")
    else:
        lines.append("- 아직 판독 집계 없음")
    grouped: Dict[str, List[Dict[str, Any]]] = {}
    for s in samples:
        if not isinstance(s, dict):
            continue
        d = str(s.get("review_decision") or s.get("decision") or "❔ 판독대기")
        grouped.setdefault(d, []).append(s)
    def one(s: Dict[str, Any]) -> str:
        t = norm_ticker(s.get("ticker"))
        strat = s.get("strategy") or s.get("strategy_key") or "-"
        stage = s.get("stage") or "-"
        score = s.get("score", "-")
        return f"- {t} / {strat} / {stage} / 점수 {score}\n  · 판단: {_v408_short_reason(s)}\n  · 부족: {_v405_fmt_missing(s.get("missing"))}"
    for name in _DECISION_ORDER:
        arr = grouped.get(name, [])
        if not arr:
            continue
        lines += ["", f"[{name}]"]
        for s in arr[:5]:
            lines.append(one(s))
    for name, arr in grouped.items():
        if name in _DECISION_ORDER or not arr:
            continue
        lines += ["", f"[{name}]"]
        for s in arr[:3]:
            lines.append(one(s))
    lines += ["", "📌 지금 판단 기준"]
    lines += ["- 스프레드·미끄러짐이 큰 후보는 손실 위험이 커서 안 산 게 맞습니다.", "- 정보가 다 있고 가격반응만 아주 살짝 부족한 후보는 ‘아까운 후보’로 따로 봅니다.", "- 조건 수치는 아직 바꾸지 않았고, 이 판독으로 놓친 후보를 복기합니다."]
    aux_ready = audit.get("aux_ready_top") if isinstance(audit.get("aux_ready_top"), dict) else {}
    aux_missing = audit.get("aux_missing_top") if isinstance(audit.get("aux_missing_top"), dict) else {}
    lines += ["", "[보조정보 완성도 · 조건 아님]"]
    for label in ["RSI/과열 위치", "MACD/추세 전환", "볼린저밴드 위치", "체결 속도 가속도", "호가잔량 변화", "BTC/전체장 선행 방향"]:
        r = int(fnum(aux_ready.get(label), default=0)) if isinstance(aux_ready, dict) else 0
        m = int(fnum(aux_missing.get(label), default=0)) if isinstance(aux_missing, dict) else 0
        icon = "✅" if r > 0 and m == 0 else ("⚠️" if r > 0 else "❔")
        lines.append(f"- {icon} {label}: 수집 {r} / 부족 {m}")
    return "\n".join(lines)

_v409_s1_base = _old_s1_candidates_v408_base if "_old_s1_candidates_v408_base" in globals() else s1_candidates_text

def s1_candidates_text() -> str:  # type: ignore[override]
    audit = _v405_load_audit()
    body = _v409_force_schema_text(_v409_s1_base())
    if "후보 판독 결론" not in body and "최종 판독" not in body:
        body += "\n" + _v409_decision_section(audit)
    else:
        body = _v409_force_schema_text(body.replace("🧭 최종 판독 · 새 등급 아님", "🧭 후보 판독 결론 · 새 등급 아님"))
    body += "\n\n[연결 확인 · v409]\n- ✅ /s1_candidates는 v409 최종 판독판으로 연결됨\n- ✅ S1/S2/S3 구조와 조건 수치는 변경하지 않음"
    return body

_v409_missed_base = _old_missed_trace_v408_base if "_old_missed_trace_v408_base" in globals() else missed_trace_text

def missed_trace_text() -> str:  # type: ignore[override]
    audit = _v405_load_audit()
    body = _v409_force_schema_text(_v409_missed_base())
    decision_top = audit.get("decision_top") if isinstance(audit.get("decision_top"), dict) else {}
    if decision_top and "후보 판독 요약" not in body:
        lines = [body, "", "[후보 판독 요약 · 새 등급 아님]"]
        for name in _DECISION_ORDER:
            if name in decision_top:
                lines.append(f"- {name}: {int(fnum(decision_top.get(name), default=0))}개")
        body = "\n".join(lines)
    return body

_v409_condition_base = _old_condition_map_v408_base if "_old_condition_map_v408_base" in globals() else condition_map_text

def condition_map_text() -> str:  # type: ignore[override]
    body = _v409_force_schema_text(_v409_condition_base())
    if "[v409 운영 기준]" not in body:
        body += "\n\n[v409 운영 기준]\n- S1/S2/S3 구조는 더 쪼개지 않습니다.\n- ‘아까운 후보/재확인 후보/안 산 게 맞음’은 새 등급이 아니라 복기용 해석입니다.\n- RSI, MACD, 볼린저밴드, 체결속도, 호가잔량 변화, BTC/전체장 방향은 조건이 아니라 비교용 정보입니다.\n- 조건 수치 변경은 새 CLOSED/놓친 후보 결과를 본 뒤 한 번에 묶어서만 합니다."
    return body

def batch_handler(update, context):  # type: ignore[override]
    cmds = getattr(context, "args", None) or ["health", "pstatus", "s1_candidates", "missed_trace", "condition_map", "errorlog"]
    cmds = [str(x).strip().lstrip("/") for x in cmds[:10] if str(x).strip()]
    st = time.time(); sent = 0; timings = []
    try:
        send(update, f"📦 자동 묶음 명령 접수\n- 실행 {len(cmds)}개\n- v409: S1 후보 판독판 실제 연결")
    except Exception:
        pass
    total = len(cmds)
    for raw in cmds:
        name = raw.strip().lstrip("/")
        fn = COMMANDS.get(name)
        if not fn:
            sent += 1
            body = f"❌ /{name} 명령이 메인봇에 연결되지 않았습니다.\n- 명령 등록 누락입니다.\n- 그냥 건너뛰지 않고 표시합니다."
            timings.append(f"- ❌ /{name}: 미등록")
            send(update, f"[{sent}/{total}] /{name} (미등록)\n{body}")
            continue
        t = time.time()
        try:
            body = fn(); ok = "OK"
        except Exception as exc:
            body = f"❌ /{name} 오류 {exc.__class__.__name__}: {exc}"; ok = "ERR"; log_error(f"batch_{name}", exc)
        sec = time.time() - t; sent += 1
        timings.append(f"- {'✅' if ok=='OK' else '❌'} /{name}: {sec:.2f}s / {ok}")
        send(update, f"[{sent}/{total}] /{name} ({sec:.2f}s / {ok})\n{body}")
    send(update, "🧾 자동 묶음 시간표 · v409 명령별 전송\n" + "\n".join(timings) + f"\n- 합계 {time.time()-st:.2f}s")

try:
    COMMANDS.update({
        "health": health_text, "core": health_text, "pstatus": pstatus_text, "score": score_text, "pscore": score_text,
        "s1_review": s1_review_text, "s1review": s1_review_text, "s1_candidates": s1_candidates_text, "s1": s1_candidates_text,
        "missed_trace": missed_trace_text, "trace_missed": missed_trace_text, "condition_map": condition_map_text, "conditions": condition_map_text, "errorlog": errorlog_text,
    })
except Exception:
    pass
if __name__=="__main__":
    main()
