v2249 오류 우선 통합 적용 ZIP

변경: Main/Paper/Review/Guard만.
오류: OPEN 원본 분리, 손실방어 stale 0, 진행중 cycle CHECK, 버전 고정문구, Review 500/618 분리·전체 candle 재읽기, Guard 시작지연·최종 중복.
미변경: 전략·상승예측 식/가중치·후보 기준·진입·청산·기존 Shadow·원장.
자동매수 OFF. 서버 적용 전 CHECK.
