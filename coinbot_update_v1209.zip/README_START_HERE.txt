코인봇 v1209 적용 묶음

목적
- PAPER OPEN 알림의 `S1→OPEN: 자료 없음`을 실제 Strategy S1 확정시각으로 연결합니다.
- Strategy가 이미 저장한 v1173 S1 시각을 Paper가 읽지 못하던 필드명·중첩경로 불일치를 수리합니다.

변경 범위
- Paper v1.060만 교체·재시작합니다.
- 후보 기준, TOP10, cycle당 2개, trigger/invalid/target/RR, 동적 청산은 변경하지 않습니다.
- 기존 OPEN/CLOSED 원장은 수정하거나 과거 시각을 현재값으로 보정하지 않습니다.
- 자동매수는 OFF입니다.

다음 성능 최적화 버전은 v1210입니다.
