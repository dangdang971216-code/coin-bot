coinbot update v2142

Purpose
- Verify the value/cost of waiting for the completed trigger.
- Extend existing Review v2133 state; do not create a new Shadow or ledger.
- Add /trigger_wait_audit and one compact line in /version_score.

Changed
- Main v2.13.2121
- Review v2.053

Unchanged
- Paper, Guard, Strategy and all other workers
- Trigger/invalid/target/RR/entry/exit numbers
- All OPEN/CLOSED/decision/exact and Shadow data
- Auto-buy OFF
