Coinbot update v2147 - structure + continuation prediction + one Strategy combiner

- Restores the agreed architecture instead of adding another gate: independent structure, independent continuation prediction, one Strategy final decision, Paper execution-only verification, sealed exit and Review calibration.
- The previous prediction formula is not trusted as a calibrated probability. v2147 uses a conservative evidence-interaction model with coverage, contradictions, dispersion and fake-break risk; its probabilities remain explicitly uncalibrated.
- Existing v2145 clean OPENs keep their sealed contracts until closed. Historical ledgers are preserved and excluded from current v2147 performance.
- No Shadow, no extra ledger, no candidate-count manipulation, no BUY_READY forcing. Auto-buy OFF.
- Local verification PASS; server runtime CHECK until deployment.
