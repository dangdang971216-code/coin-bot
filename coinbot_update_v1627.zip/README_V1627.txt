v1627: structure plan rebuild link after v1626 lifecycle split. Candidate selection rules unchanged. Auto-buy OFF.
