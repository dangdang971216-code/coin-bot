코인봇 v2100 · invalid 10%+ -4% 절대 대손실 방어

목적
- MLK처럼 구조 invalid가 10% 이상 멀어 -12%대 손실까지 허용되는 거래를 막는다.
- NEW OPEN뿐 아니라 사용자가 승인한 현재 OPEN에도 같은 overlay를 1회 append한다.
- 기존 trigger·invalid·target과 이전 청산계약은 수정하지 않는다.

본선 규칙
- sealed invalid 거리 10% 이상만 대상
- 비용후 현재손익 -4.0% 이하이면 첫 가용 Paper 청산평가에서 종료
- invalid 10% 미만은 변경 없음
- 이미 -4% 아래인 현재 OPEN은 적용 직후 다음 quote 평가에서 청산 대상

원장
- 현재 OPEN row에 overlay contract를 append하고 검증 저장
- 원래 계약은 그대로 유지
- change_verify_ledger·issue_ledger에 전환 수와 pos_id/ticker/거리/현재손익을 append
- 과거 CLOSED/decision/exact 재작성 없음

변경하지 않음
- Runner·수익보호·target 연장·3h/6h 무반응 정리
- 후보·rank·OPEN 수 제한
- 자동매수 OFF

서버 검수
- Guard: /gupgrade_bundle coinbot_update_v2100.zip 단독 후 /grelease_verify
- Paper: /pstatus, /popen, /perror
- Main: /open_book_audit, /version_score, /errorlog
