#!/usr/bin/env python3
from __future__ import annotations
import importlib.util
import pathlib
import sys

ROOT = pathlib.Path(__file__).resolve().parent
PACKAGE_ROOT = ROOT.parent
if str(PACKAGE_ROOT) not in sys.path:
    sys.path.insert(0, str(PACKAGE_ROOT))

def load(name: str, path: pathlib.Path):
    spec = importlib.util.spec_from_file_location(name, path)
    mod = importlib.util.module_from_spec(spec)
    sys.modules[name] = mod
    assert spec and spec.loader
    spec.loader.exec_module(mod)
    return mod

def support(tf: str, low: float, score: float):
    return {'tf': tf, 'side': 'support', 'price': low, 'zone_low': low,
            'zone_high': low + 0.1, 'score': score, 'touch_count': 3,
            'source': f'candle.{tf}', 'atr_pct': 1.0, 'gap_pct': 0.0}

def resistance(tf: str, low: float, score: float):
    return {'tf': tf, 'side': 'resistance', 'price': low, 'zone_low': low,
            'zone_high': low + 0.1, 'score': score, 'touch_count': 3,
            'source': f'candle.{tf}', 'atr_pct': 1.0, 'gap_pct': 0.0}

def main() -> None:
    s = load('strategy_v1229_pairing', PACKAGE_ROOT / 'strategy_worker_v1.056.py')
    invalid_pool = [
        (2.0, support('h1', 98.0, 60.0)),
        (3.0, support('h2', 97.0, 90.0)),
    ]
    target_pool = [
        (4.0, resistance('h2', 104.0, 90.0)),
        (8.0, resistance('h4', 108.0, 50.0)),
        (6.0, resistance('h1', 106.0, 95.0)),
        (0.5, resistance('m30', 100.5, 99.0)),
    ]
    out = s._v1229_select_coherent_structure_pair(
        invalid_pool, target_pool,
        price=100.0, trigger_price=100.0, invalid_buffer_pct=0.0,
        reach_limit_pct=10.0, minimum_target_room_pct=1.2,
        estimated_roundtrip_cost_pct=0.5,
    )
    # 2 actual stop lines x 3 final-target lines; nearby 0.5% line stays obstacle only.
    assert out['invalid_candidate_count'] == 2
    assert out['target_candidate_count'] == 3
    assert out['combination_count'] == 6
    assert out['passing_count'] == 5
    assert out['major_passing_count'] == 3
    assert out['setup_passing_count'] == 2
    assert out['selection_mode'] == 'coherent_major_pair'
    # Major tier first; within it, choose the strongest pair rather than farthest target.
    assert out['selected_invalid']['rounded_price'] == 98.0
    assert out['selected_target']['rounded_price'] == 104.0
    assert out['selected_raw_rr'] == 2.0
    assert out['nearest_intermediate_zone']['tf'] == 'm30'

    # No major pair passes: setup pair is allowed as fallback.
    fallback = s._v1229_select_coherent_structure_pair(
        [(3.0, support('h2', 97.0, 90.0))],
        [(4.0, resistance('h2', 104.0, 90.0)), (6.0, resistance('h1', 106.0, 95.0))],
        price=100.0, trigger_price=100.0, invalid_buffer_pct=0.0,
        reach_limit_pct=10.0, minimum_target_room_pct=1.2,
        estimated_roundtrip_cost_pct=0.5,
    )
    assert fallback['major_passing_count'] == 0
    assert fallback['setup_passing_count'] == 1
    assert fallback['selection_mode'] == 'coherent_setup_pair_fallback'
    assert fallback['selected_target']['tf'] == 'h1'

    # No pair passes: fail closed instead of tightening the stop or inventing a target.
    none = s._v1229_select_coherent_structure_pair(
        [(4.0, support('h2', 96.0, 90.0))],
        [(4.5, resistance('h2', 104.5, 95.0))],
        price=100.0, trigger_price=100.0, invalid_buffer_pct=0.0,
        reach_limit_pct=10.0, minimum_target_room_pct=1.2,
        estimated_roundtrip_cost_pct=0.5,
    )
    assert none['passing_count'] == 0
    assert none['selected_invalid'] == {}
    assert none['selected_target'] == {}
    assert none['best_failed_rr'] == 1.125

    text = (PACKAGE_ROOT / 'strategy_worker_v1.056.py').read_text(encoding='utf-8')
    assert 'all usable actual support x all reachable actual resistance' in text
    assert "V925_MIN_RR = 1.50" in text
    assert "V925_MIN_TARGET_ROOM_PCT = 1.20" in text
    print('PASS v1229 all usable stop/profit combinations, major-first quality selection, fail-closed no-pair')

if __name__ == '__main__':
    main()
