코인봇 업데이트 v1229

목적:
1) 손절선과 목표선을 따로 하나씩 고르던 방식을 끝내고, 실제 반응선 후보 조합을 전부 비교해 함께 맞는 한 쌍을 고른다.
2) 수수료를 Paper 설정 원본에서 exact로 읽고, 누락을 0으로 처리하지 않는다.
3) 구조 감사가 오래된 Gate 상태가 아니라 같은 완료 후보 commit을 읽도록 고친다.

Strategy 수정:
- 실제 손절선 후보 × 실제 목표선 후보를 전부 교차 비교
- 2h·4h 주요 목표선 조합 우선, 통과 조합이 없을 때만 30m·1h 대체 목표선 사용
- 반응 품질, 시간축, 목표 도달 가능성, 비용 후 RR을 함께 확인
- 기준 통과 조합이 없으면 억지 목표선·손절선을 만들지 않고 진입하지 않음
- 가까운 저항은 중간 장애물로 기록

Paper·Guard 수정:
- Paper가 왕복 수수료 원본 owner를 active contract snapshot에 봉인
- Strategy는 그 봉인값만 읽음. 누락은 SOURCE_MISSING
- /gentry_geometry_audit, /gentry_flow_audit는 같은 완료 후보 원문·행수·단계·cycle·writer commit에 exact 연결
- 후보별 조합 수와 통과 수 표시

변경하지 않음:
- RR 1.5 / 목표공간 1.2%
- Trigger 감시 → 도달 시 S1 → Paper 실제 진입가 최종검증 → 즉시 OPEN
- 전체 점수순 / 전략별 자리 없음 / Runner 예약 없음
- 청산 / 기존 OPEN 계약
- 자동매수 OFF

상태:
- 로컬 py_compile PASS
- 회귀 테스트 10/10 PASS
- 서버 미적용 CHECK
