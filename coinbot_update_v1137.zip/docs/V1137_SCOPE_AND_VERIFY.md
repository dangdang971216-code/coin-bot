# v1137 scope

## Root cause
v1135 created a new reset manifest/control batch but preserved an older active performance epoch and execution status. The reset runner treated any epoch ID as proof that bulk close had already run, so the 30 sealed OPEN positions stayed frozen and unclosed. Main also displayed the old execution counters beside the new manifest.

## Changes
- Paper requires `execution.batch_id == manifest.batch_id` and `epoch.reset_batch_id == manifest.batch_id`.
- A previous epoch cannot resume entries or suppress bulk close for a new reset generation.
- Stale execution counters are ignored and marked explicitly.
- Guard publishes canonical/legacy reset reader-owner mapping and a generation mismatch anomaly.
- Main full flow map displays ACTIVE_CANONICAL and LEGACY_DO_NOT_JUDGE paths.
- Removed the obsolete duplicate v1133 closeout definition.

## Not changed
Strategy v1.011, quality Gate/rank, trigger TTL, invalid, target, trailing, OPEN 30, cycle 3, protected ledgers and auto-buy OFF.

## Server proof
The current 30 sealed OPENs must exact-close through CLOSED append -> decision CLOSED -> OPEN remove. A new epoch with the same reset batch ID must then be written. `/flow_map_full` must show generation mismatch 0 and the legacy files as judgement-prohibited.
