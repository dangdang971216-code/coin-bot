from pathlib import Path
import importlib.util, json, tempfile

BASE=Path(__file__).resolve().parent

def load(name,path):
    spec=importlib.util.spec_from_file_location(name,path)
    mod=importlib.util.module_from_spec(spec)
    assert spec.loader
    spec.loader.exec_module(mod)
    return mod

p=load('paper_v1137',BASE/'paper_bot_v1.023.py')
_trace=BASE/'paper_bot_hourly_summary_trace.json'
if _trace.exists(): _trace.unlink()
assert p.VERSION=='paper_bot_v1.023'
assert p.BUILD_LABEL=='v1137_reset_generation_owner_alignment_2026-06-29'

# generation helper
m={'batch_id':'new-batch'}
e={'epoch_id':'old-epoch','reset_batch_id':'old-batch','state':'ACTIVE','zero_open_proof':True}
x={'batch_id':'old-batch','requested':106,'committed':106,'failed':0}
g=p._v1137_reset_generation_contract(m,e,x)
assert g['epoch_matches_manifest'] is False
assert g['execution_matches_manifest'] is False

# stale execution/epoch cannot populate current status
with tempfile.TemporaryDirectory() as td:
    base=Path(td)
    p.BOOK_RESET_MANIFEST_V1044=base/'manifest.json'
    p.BOOK_RESET_CONTROL_V1044=base/'control.json'
    p.BOOK_RESET_STATUS_V1044=base/'status.json'
    p.BOOK_RESET_EXECUTION_V1045=base/'execution.json'
    p.PERFORMANCE_EPOCH_V1045=base/'epoch.json'
    p._paper_write_json_verified=lambda path,obj: (path.write_text(json.dumps(obj),encoding='utf-8') or True)
    p._v1044_closed_exact_pos_ids=lambda: set()
    p._RUNTIME_INSTANCE_ID='test-runtime'
    p._PROCESS_STARTED_AT=200.0
    p.BOOK_RESET_MANIFEST_V1044.write_text(json.dumps({'batch_id':'new-batch','target_pos_ids':['p1'],'target_digest':'new-digest','next_performance_epoch_id':'post-reset:new-batch'}),encoding='utf-8')
    p.BOOK_RESET_CONTROL_V1044.write_text(json.dumps({'batch_id':'new-batch','state':'PREPARED_ENTRY_FREEZE','entry_freeze':True,'bulk_close_enabled':False}),encoding='utf-8')
    p.BOOK_RESET_EXECUTION_V1045.write_text(json.dumps(x),encoding='utf-8')
    p.PERFORMANCE_EPOCH_V1045.write_text(json.dumps(e),encoding='utf-8')
    status=p._v1045_reset_status({'p1':{'pos_id':'p1'}})
    assert status['last_pass_requested']==0
    assert status['last_pass_committed']==0
    assert status['stale_execution_ignored_v1137'] is True
    assert status['performance_epoch_id'] is None
    assert status['previous_epoch_id_v1137']=='old-epoch'
    assert status['zero_open_proof'] is False

# the reset cycle must execute bulk close when only an old epoch exists
calls=[]
p._v1045_maybe_resume_entries=lambda: False
p._v1045_reset_in_progress=lambda: True
p._v1045_manifest=lambda: {'batch_id':'new-batch'}
p._v1045_epoch=lambda: {'epoch_id':'old-epoch','reset_batch_id':'old-batch'}
p._v1045_execute_bulk_close=lambda: calls.append('bulk') or {'state':'DONE','last_pass_committed':30,'active_open_count':0}
p._v1045_reset_status=lambda *a,**k: (_ for _ in ()).throw(AssertionError('stale epoch must not skip bulk close'))
p.write_status=lambda *a,**k: None
result=p.run_cycle__L23689()
assert calls==['bulk']
assert result['closed_this_cycle']==30

# guard map contract permanently classifies canonical and legacy paths
gmod=load('guard_v1137',BASE/'backga_guard_bot_v2_5_178.py')
assert gmod.VERSION=='guard_v2.5.178_reset_generation_owner_map_v1137_2026-06-29'
with tempfile.TemporaryDirectory() as td:
    base=Path(td); gmod.BOT_DIR=base
    def w(name,obj): (base/name).write_text(json.dumps(obj),encoding='utf-8')
    w('paper_quality_rebuild_status_v1095.json',{'batch_id':'new-batch'})
    w('paper_quality_rebuild_manifest_v1095.json',{'batch_id':'new-batch'})
    w('paper_quality_rebuild_control_v1095.json',{'batch_id':'new-batch'})
    w('paper_quality_rebuild_execution_v1095.json',{'batch_id':'old-batch'})
    w('paper_quality_rebuild_epoch_v1095.json',{'epoch_id':'old-epoch','reset_batch_id':'old-batch'})
    w('paper_book_reset_status_v1044.json',{'batch_id':'legacy'})
    c=gmod._ops_reset_reader_owner_contract_v1137()
    assert c['state']=='CHECK' and c['mismatch_count']==2
    assert c['canonical_class']=='ACTIVE_CANONICAL'
    assert c['legacy_class']=='LEGACY_DO_NOT_JUDGE'
    assert 'paper_book_reset_status_v1044.json' in c['legacy_existing_files']
    w('paper_quality_rebuild_execution_v1095.json',{'batch_id':'new-batch'})
    w('paper_quality_rebuild_epoch_v1095.json',{'epoch_id':'new-epoch','reset_batch_id':'new-batch'})
    c=gmod._ops_reset_reader_owner_contract_v1137()
    assert c['state']=='NORMAL' and c['mismatch_count']==0

# main source contracts
src=(BASE/'coinbot_main_v2_13_1104.py').read_text(encoding='utf-8')
assert "BOT_VERSION = '수익형 v2.13.1104'" in src
assert "EXPECTED_PAPER_VERSION = 'paper_bot_v1.023'" in src
assert src.count('def _v1133_finalize_trigger_regression_server_proof_once()')==1
assert "COMMANDS['flow_map_full']=render_flow_map_full_text" in src
assert 'LEGACY_DO_NOT_JUDGE' in src
print('PASS v1137 contract')
