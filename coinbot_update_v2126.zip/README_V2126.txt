현재 상태
- Paper 명령 응답 1회 복구, S1→Paper→OPEN 경로 정상
- UOS 알림은 후보→OPEN 19.6분, S1→OPEN 28.7초였지만 Paper접수·선택 구간은 측정대기
- Main /version_score는 TXT는 오지만 채팅 핵심판이 조용히 누락될 수 있음

수정
- 기존 Strategy trigger state에 최초 후보·구조완성·정확한 S1 첫시각 봉인
- 기존 Paper v1153 append-once 경로에 Paper접수·실행자료완료·최종검사·선택 시각 연결
- OPEN에 8구간 timing contract와 가장 긴 병목을 봉인
- OPEN 알림에 단계별 시간과 병목 표시
- /version_score는 계산 1회 후 채팅 핵심판 1회 전달을 검증하고 동일 body TXT 첨부

미변경
- 후보등급, 구조선, trigger/invalid/target, RR/목표공간/추격/spread/slippage, 진입·청산, 기존 원장, Shadow, 자동매수 OFF

서버 검수
- 새 OPEN에서 8개 단계 누락 0 및 병목 표시
- /version_score 채팅 1회 + TXT 1개
- Paper running=True, PID=writer PID, 오류0
