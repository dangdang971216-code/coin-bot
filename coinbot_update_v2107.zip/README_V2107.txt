coinbot_update_v2107.zip

실제 본선
- Paper v2.061 고점연동 최소 안전익절
- 현재 OPEN + 신규 OPEN 적용
- 0.7~1 / 1~2 / 2~3 / 3~5 / 5+ 구간별 고점연동 바닥

흔들림 판단
- 기존 v2011 구조+힘 Shadow 재사용
- 정상흔들림 HOLD
- 약세 첫 확인은 한 번 더 관찰
- 지지/VWAP+힘 회복은 가짜흔들림 HOLD
- 지지 이탈 지속+힘 2축 약화 2회는 가상익절
- 실제 흔들림 청산은 아직 미적용

속도
- /entry_failure_audit는 Review snapshot만 읽음
- /entry_failure_audit_full만 전체 정밀 재스캔

명령
- /shake_exit_audit
- /entry_failure_audit
- /entry_failure_audit_full

자동매수 OFF
