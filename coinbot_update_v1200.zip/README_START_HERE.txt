coinbot_update_v1200

목적:
- v1199 ZIP이 package_v1199/ 아래 중첩되어 Guard가 manifest를 못 찾은 패키징 실패 수리
- ZIP 최상단에 DEPLOY_BUNDLE.json과 runtime 파일을 평탄 배치
- 빈 worker manifest 항목을 미변경 대상으로 SKIP하여 expected=? 가짜 CHECK 제거
- v1199의 상태판 오류수리 의도는 그대로 포함
- 후보 수·OPEN 수·cycle 수 변경 없음
- v1198은 폐기 유지

적용은 APPLY_V1200.txt 순서만 사용합니다.
