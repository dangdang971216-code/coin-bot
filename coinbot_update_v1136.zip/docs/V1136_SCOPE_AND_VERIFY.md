# v1136 scope and verification

## Locked cause

`/book_reset_status` in Main read five retired files:

- `paper_book_reset_status_v1044.json`
- `paper_book_reset_manifest_v1044.json`
- `paper_book_reset_control_v1044.json`
- `paper_book_reset_execution_v1045.json`
- `paper_performance_epoch_v1045.json`

Paper v1.022 writes the current reset state to the canonical `paper_quality_rebuild_*_v1095` namespace. The old Main reader therefore displayed an old batch and an old epoch even after v1135.

## v1136 change

- Main only: v2.13.1103.
- Replace all five retired reset readers with Paper canonical files.
- Show the canonical source explicitly in `/book_reset_status`.
- Remove legacy fallback.
- Keep v1133/v1135 closeout compatible with the current Main version.
- Append v1136 issue/change CHECK event; no history rewrite.

## Not changed

- Paper v1.022 and Strategy v1.011.
- Candidate TTL, quality Gate/rank, RR formula, invalid, target or trailing.
- OPEN limit 30 and cycle limit 3.
- OPEN/CLOSED/trade_log/decision/performance ledgers.
- Auto-buy remains OFF.

## Server proof

`/book_reset_status` must show:

- source `paper_quality_rebuild_*_v1095` with no legacy fallback;
- current status age rather than the old 150,758-second value;
- the v1135 reset reason/batch/target result and active epoch from the Paper canonical files.

Paper `/pstatus` and `/candidate_summary` then prove the actual reset state, RR owner, and fresh path. Until that evidence is received, v1135 and v1136 remain CHECK.
