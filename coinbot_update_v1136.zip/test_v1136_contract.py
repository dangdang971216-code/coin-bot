from __future__ import annotations

import ast
from pathlib import Path

ROOT = Path(__file__).resolve().parent
SRC = ROOT / 'coinbot_main_v2_13_1103.py'
text = SRC.read_text(encoding='utf-8')
tree = ast.parse(text)

assignments: dict[str, str] = {}
for node in ast.walk(tree):
    if isinstance(node, ast.Assign) and len(node.targets) == 1 and isinstance(node.targets[0], ast.Name):
        name = node.targets[0].id
        try:
            assignments[name] = ast.unparse(node.value)
        except Exception:
            pass

expected = {
    'PAPER_BOOK_RESET_STATUS_V1044': "BASE_DIR / 'paper_quality_rebuild_status_v1095.json'",
    'PAPER_BOOK_RESET_MANIFEST_V1044': "BASE_DIR / 'paper_quality_rebuild_manifest_v1095.json'",
    'PAPER_BOOK_RESET_CONTROL_V1044': "BASE_DIR / 'paper_quality_rebuild_control_v1095.json'",
    'PAPER_BOOK_RESET_EXECUTION_V1045': "BASE_DIR / 'paper_quality_rebuild_execution_v1095.json'",
    'PAPER_PERFORMANCE_EPOCH_V1045': "BASE_DIR / 'paper_quality_rebuild_epoch_v1095.json'",
}
for name, value in expected.items():
    assert assignments.get(name) == value, (name, assignments.get(name))

for legacy in (
    'paper_book_reset_status_v1044.json',
    'paper_book_reset_manifest_v1044.json',
    'paper_book_reset_control_v1044.json',
    'paper_book_reset_execution_v1045.json',
    'paper_performance_epoch_v1045.json',
):
    # Legacy names may appear only in append-only issue text, never as active path assignments.
    assert f"BASE_DIR / '{legacy}'" not in text, legacy

assert "BOT_VERSION = '수익형 v2.13.1103'" in text
assert "V650_BUILD_LABEL = 'v1136_book_reset_canonical_reader_reconnect_2026-06-29'" in text
assert "Paper canonical paper_quality_rebuild_*_v1095 · legacy fallback 없음" in text
assert "'legacy_fallback': False" in text
assert "'main_version':str(BOT_VERSION)=='수익형 v2.13.1103'" in text
assert "change_id='v1136-book-reset-canonical-reader-reconnect-001'" in text
assert "issue_id='BOOK-RESET-READER-1136'" in text

# Scope lock: this bundle does not contain Paper/Strategy source or live ledgers.
assert not list(ROOT.glob('paper_bot*.py'))
assert not list(ROOT.glob('strategy_worker*.py'))
for pat in ('*open*.json', '*closed*.jsonl', '*trade_log*.jsonl', '*decision*.json*', '*performance_snapshot*.json'):
    assert not list(ROOT.glob(pat)), pat

print('PASS v1136 canonical book-reset reader contract')
