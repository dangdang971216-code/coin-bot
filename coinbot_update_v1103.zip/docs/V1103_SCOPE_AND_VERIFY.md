# v1103 Flow Map Error Cockpit + Full Evidence

## Root cause
v1102 mapped the 1→100 lifecycle but reused a short screen body inside the TXT. It showed counts such as runtime mismatch or unknown ledger owners without enough evidence to identify one root cause. This forced repeated `/system_map`, `/resource_map`, `/ledger_map`, and `/ops_focus` calls.

## New canonical path
Guard single collector → `ops_map_snapshot.json.flow_map_v1103` → Main read-only renderers:

- `/flow_map`: compact Telegram cockpit
- paired TXT: grouped causes/evidence/impact/certainty, normally 50–100 lines
- `/flow_map full` or `/flow_map_full`: all stages, runtime identities, resources, OPEN summaries, ledger rows, lineage and policy evidence

## Included evidence
- 20 lifecycle stages and accounting
- repeated error grouping by root cause
- source/owner/PID/version/hash mismatch axes
- CPU, RSS, HWM, trends, active phase, server RAM/load
- disk remaining, observed file growth and projected days
- ledger writer/owner/growth/multi-writer/UNKNOWN groups
- Paper funnel, block reasons, current OPEN compact rows
- exact duplicate/key_missing/unlinked
- previous snapshot deltas and top next actions

## Not changed
Strategy thresholds, entry/exit contracts, slippage limit, OPEN 30/cycle 3, core ledger schema, automatic buying.

## Server verification
- Guard: `/gops_refresh`
- Main, same message: `/flow_map` and `/errorlog`
- Full mode is diagnostic and not required for routine verification.
