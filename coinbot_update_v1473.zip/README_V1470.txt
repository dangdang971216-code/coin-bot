coinbot_update_v1470.zip
- Material truth audit for target/runner sources.
- Uses only price-like fields as target candidates; excludes gap_pct/pct/room/ratio/time/count numeric fields from target price.
- Shows timeframe, actual_rows, expected_rows, and 4h 30-candle proof status when available.
- Read-only: no target/RR/trigger/invalid/candidate/OPEN/exit/autobuy changes.
