coinbot_update_v1471.zip
- Full material pipeline truth audit, not only 4h target material.
- Audits target/invalid/trigger/volume-money/relative-strength/market/execution-cost/freshness materials.
- Corrects live tuple parsing from select_candidates so live rows can be separated from full snapshot rows.
- Shows source/timeframe/actual_rows/owner/update proof by material category.
- UNKNOWN timeframe or missing actual_rows cannot PASS.
- Read-only: no target/RR/trigger/invalid/candidate/OPEN/exit/autobuy changes.
