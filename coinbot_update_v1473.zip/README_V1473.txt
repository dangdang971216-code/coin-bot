v1473 MATERIAL_SPINE_SINGLE_OWNER_SOURCE_FIX_AUTOBUY_OFF

[번호 보정]
- v1472는 이미 생성/전달된 번호였으므로, 같은 수정 목적을 v1473으로 다시 발행한다.
- Guard /grelease_verify 기준 expected main=수익형 v2.13.1473, paper=paper_bot_v1.452가 되어야 한다.

[현재 작업 이유]
- v1471 /material_pipeline은 live_link가 일부 PASS였지만 재료배관정확도 FAIL이었다.
- target/invalid/trigger/volume/relative_strength/market 재료에서 timeframe·actual_rows 증거가 대량 누락됐다.
- 이전 감사는 숫자를 너무 넓게 긁어 재료 수가 과다했으므로, v1473은 material spine 단일 status와 strict field allow-list로 다시 본다.

[목적]
- paper_material_spine_single_owner_v1473을 단일 재료 spine으로 사용한다.
- snapshot / select_live / picked를 분리한다.
- broad nested 숫자 긁기를 줄이고 핵심 필드만 감사한다.
- 다음 단계에서 생성부 수리 대상(target/invalid/trigger/volume/RS/market actual_rows 저장 누락)을 명확히 분리한다.

[변경 없음]
- 자동매수 OFF
- target/invalid/trigger/RR/후보 기준 변경 없음
- BUY_READY/OPEN 강제 없음
- 청산계약 변경 없음
- 원장 삭제·축소·재작성 없음
