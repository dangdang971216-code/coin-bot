coinbot_update_v1469

목적:
- target2만 보는 좁은 비교가 아니라 1차 회복 target + runner 3%+ + 대수익 5%/10% target을 한 shadow에서 함께 비교한다.
- 현재 target이 너무 가까운지, 상위/old/legacy/구조 target을 쓰면 후보와 대수익 여지가 살아나는지 확인한다.
- 실제 target 변경은 하지 않는다. 기준완화, BUY_READY 강제, OPEN 강제, 자동매수 ON 없음.

검수:
/gupgrade_bundle
/grelease_verify
/gmenu_sync
/source_owner
/candidate_flow
/rr_audit
/target_audit
/target_shadow
/s2_recheck
/protection_audit
/version_score
/errorlog
