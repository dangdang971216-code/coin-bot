coinbot_update_v1468

목적:
- 현재 target이 너무 가까워 후보가 1300대 흐름처럼 마르는지 비교한다.
- current target / 상위 target / old_base·legacy·v1211 target 증거를 같은 entry/invalid 기준으로 shadow 비교한다.
- target 변경은 하지 않는다. 기준완화, BUY_READY 강제, OPEN 강제, 자동매수 ON 없음.

검수:
/gupgrade_bundle
/grelease_verify
/gmenu_sync
/source_owner
/candidate_flow
/rr_audit
/target_audit
/s2_recheck
/protection_audit
/version_score
/errorlog
