v1472 MATERIAL_SPINE_SINGLE_OWNER_SOURCE_FIX_AUTOBUY_OFF

[중요 수정]
- 이전 v1472 zip의 DEPLOY_BUNDLE 상단이 v1471로 남아 Guard /grelease_verify가 expected v1471 / paper v1.450으로 판정했다.
- 이번 파일은 manifest를 v1472로 수정했다. expected main=수익형 v2.13.1472, paper=paper_bot_v1.451.

[목적]
- v1471에서 확인된 재료배관 FAIL을 단일배관으로 다시 검증한다.
- snapshot / select_live / picked를 분리한다.
- broad nested 숫자 긁기를 줄이고 strict field allow-list로 target/invalid/trigger/volume/RS/market/cost/freshness 핵심 필드만 감사한다.

[변경 없음]
- 자동매수 OFF
- target/invalid/trigger/RR 기준 변경 없음
- BUY_READY/OPEN 강제 없음
- 청산계약 변경 없음
- 원장 재작성 없음

[검수]
가드:
/gupgrade_bundle
/grelease_verify

메인:
/source_owner
/candidate_flow
/material_pipeline
/material_audit
/target_audit
/target_shadow
/rr_audit
/s2_recheck
/protection_audit
/version_score
/errorlog
