coinbot_update_v1467

목적:
- RR의 정확한 주인을 하나로 고정한다.
- 최종 RR = (target - entry) / (entry - invalid).
- swing_entry_gate_v977.risk_reward는 참고값으로 강등하고, Paper selector/candidate_flow/rr_audit는 entry/target/invalid 공식 RR만 사용한다.
- 가드봇 텔레그램 명령 메뉴에서 /gupgrade_bundle을 최상위로 올려 오작동 클릭을 줄인다.
- 자동매수 OFF. 기준완화/RR기준변경/trigger/target/invalid/OPEN/청산계약 변경 없음.

검수:
/gupgrade_bundle
/grelease_verify
/gmenu_sync
/source_owner
/candidate_flow
/rr_audit
/s2_recheck
/protection_audit
/version_score
/errorlog
