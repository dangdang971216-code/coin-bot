import importlib.util
from pathlib import Path

SRC=Path('paper_bot_v1.043.py').resolve()
spec=importlib.util.spec_from_file_location('paper1176',SRC)
m=importlib.util.module_from_spec(spec)
spec.loader.exec_module(m)

decision='market:TEST|plan:1'
base={
    'strategy_mode':'ALT_SWING_V977',
    'paper_decision_key_v926':decision,
    'swing_entry_gate_v977':{'schema':'swing_entry_gate_v977_single_owner'},
    'swing_trigger_price_v977':101.0,
    'swing_invalid_price_v977':90.0,
    'swing_target_price_v977':120.0,
    'loss_reentry_gate_v1037':{
        'schema':'loss_reentry_gate_v1037',
        'allowed':False,
        'state':'WOULD_BLOCK_AUDIT_ONLY',
        'reason':'test raw mode audit',
    },
    'entry_evidence_v983':{
        'exit_contract':{
            'schema':'alt_swing_exit_contract_v1038',
            'trailing_exit':True,
        }
    },
    'opened_at':1.0,
}
assert m._v1176_verify_open_seal(dict(base), decision) is True

missing=dict(base)
missing.pop('loss_reentry_gate_v1037')
try:
    m._v1176_verify_open_seal(missing, decision)
except RuntimeError as exc:
    assert 'loss_reentry_audit_v1037' in str(exc)
else:
    raise AssertionError('missing audit evidence must still fail OPEN seal')

text=SRC.read_text(encoding='utf-8')
assert "reentry.get('schema') == 'loss_reentry_gate_v1037'" in text
assert "pos['loss_reentry_gate_v1037'].get('allowed') is True" not in text
print('PASS v1176 OPEN seal audit-only reentry test')
