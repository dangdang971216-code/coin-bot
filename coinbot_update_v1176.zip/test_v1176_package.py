import hashlib, json
from pathlib import Path
root=Path('.').resolve()
manifest=json.loads((root/'DEPLOY_BUNDLE.json').read_text())
assert manifest['version']=='v1176'
assert manifest['paper']=='paper_bot_v1.043.py'
assert manifest['auto_buy'] is False
assert manifest['strategy_source_change'] is False
src=root/manifest['paper']
assert src.exists()
assert hashlib.sha256(src.read_bytes()).hexdigest()==manifest['source_sha256'][src.name]
text=src.read_text(encoding='utf-8')
assert "VERSION = 'paper_bot_v1.043'" in text
assert "BUILD_LABEL = 'v1176_open_seal_reentry_audit_not_block_2026-07-01'" in text
assert '_v1176_verify_open_seal(pos, decision_key)' in text
for forbidden in ['paper_bot_open.json','paper_bot_closed.jsonl','trade_log.jsonl','decision_state.json']:
    assert not (root/forbidden).exists(), forbidden
print('PASS v1176 package tests')
