v937 적용본
- v936 stale handler + swallowed final bind 제거
- atomic final command registry / batch 9개
- 적용: 가드봇 /gupgrade_bundle
- 검수: 메인봇 /batch
