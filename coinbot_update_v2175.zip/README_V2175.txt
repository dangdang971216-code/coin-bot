v2175 scope
- One completed-bar decision owner: full cycle and incremental event both call strategy_worker_v2.069._v2175_evaluate_one -> strategy_v2_core_v2171.build_combined_v2_contract.
- Removed active live-price crossed/exact evaluator and candidate-* pseudo commit generation from the current Strategy path.
- Review reads only runtime/current_candidate_snapshot_v2175.json.
- Paper receives one canonical commit + S1 generation + event set and locks the first receipt.
- Guard removes obsolete versioned Python source files only after exact runtime proof. It never targets OPEN/CLOSED/trade_log/decision/exact/change_verify/issue ledgers.
- Prediction/candidate-quality/Trigger/Invalid/T1/Paper cost/exit numbers are unchanged.
- Auto-buy OFF.
