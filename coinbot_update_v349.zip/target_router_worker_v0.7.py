#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""target_router_worker_v0.7

정보배차 직원 v0.7.
목표:
- 정보부족 전체를 한꺼번에 WS/micro target으로 밀어넣지 않는다.
- 전체 후보 queue는 보존하되, sidecar가 실제 우선수집할 active target은 우선순위 높은 후보 중심으로 분리한다.
- 개수 고정 전략이 아니라, 우선순위/버킷/서버보호 active window를 분리한다.
"""
from __future__ import annotations
import json, os, time, traceback
from pathlib import Path
from typing import Any, Dict, List, Optional

BASE_DIR = Path(os.getenv("TRADING_BOT_DIR", "/home/dangdang971216/trading_bot"))
VERSION = "target_router_worker_v0.7"
INTERVAL_SEC = float(os.getenv("TARGET_ROUTER_INTERVAL_SEC", "1.5"))
# v0.7: 고정 N개 제한을 제거하고, 전체 queue를 보존한 뒤
# sidecar가 감당 가능한 "내보내기 창"만 순환한다.
# 이 값은 전략/후보 제한이 아니라 장애 방지용 export 안전창이다.
# micro sidecar 자체 안전상한(CLEAN_MICRO_TARGET_SAFETY_MAX)과 맞춰 둔다.
EXPORT_SAFETY_WINDOW = int(float(os.getenv("TARGET_ROUTER_EXPORT_SAFETY_WINDOW", os.getenv("CLEAN_MICRO_TARGET_SAFETY_MAX", "180"))))
HIGH_PRIORITY_THRESHOLD = float(os.getenv("TARGET_ROUTER_HIGH_PRIORITY", "85"))
HOT_ROTATION_THRESHOLD = float(os.getenv("TARGET_ROUTER_HOT_ROTATION_PRIORITY", "72"))
STATUS = BASE_DIR / "clean_target_router_status.json"
ERROR = BASE_DIR / "clean_target_router_error.log"
STRATEGY_REQ = BASE_DIR / "clean_strategy_priority_requests.json"
FEATURE = BASE_DIR / "clean_feature_cache.json"
ORDERFLOW = BASE_DIR / "clean_orderflow_summary_cache.json"
PAPER_OPEN = BASE_DIR / "paper_bot_open.json"
QUEUE = BASE_DIR / "clean_target_router_queue.json"
WS_TARGETS = BASE_DIR / "clean_ws_targets.json"
MICRO_TARGETS = BASE_DIR / "clean_micro_targets.json"
MICRO_URGENT = BASE_DIR / "clean_micro_urgent_targets.json"

CRITICAL_BUCKETS = {"open_position", "s_candidate", "paper_handoff", "near_s_info_wait", "s_near_info"}
HIGH_BUCKETS = {"info_wait_high", "high_score_info_wait"}
LOW_BUCKETS = {"market_rotation", "normal_rotation", "normal_info_wait", "hard_blocked_info_wait"}


def now_ts() -> float:
    return time.time()

def now_text(ts: Optional[float] = None) -> str:
    return time.strftime("%Y-%m-%d %H:%M:%S", time.localtime(ts or now_ts()))

def fnum(*vals: Any, default: float = 0.0) -> float:
    for v in vals:
        try:
            if v is None or v == "":
                continue
            return float(str(v).replace(",", "").replace("%", ""))
        except Exception:
            continue
    return default

def ticker_norm(x: Any) -> str:
    t = str(x or "").strip().upper().replace("/", "-").replace("_", "-")
    parts = [p for p in t.split("-") if p]
    if len(parts) >= 2:
        non = [p for p in parts if p != "KRW"]
        t = non[-1] if non else parts[-1]
    if t.endswith("KRW") and len(t) > 3:
        t = t[:-3]
    return t.strip().upper()

def load_json(path: Path, default: Any = None) -> Any:
    try:
        if not path.exists():
            return default
        return json.loads(path.read_text(encoding="utf-8", errors="ignore"))
    except Exception:
        return default

def save_json(path: Path, obj: Any) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    tmp = path.with_suffix(path.suffix + ".tmp")
    tmp.write_text(json.dumps(obj, ensure_ascii=False, separators=(",", ":"), default=str), encoding="utf-8")
    os.replace(tmp, path)

def append_error(where: str, exc: BaseException) -> None:
    try:
        ERROR.parent.mkdir(parents=True, exist_ok=True)
        with ERROR.open("a", encoding="utf-8") as f:
            f.write(f"[{now_text()}] {where}: {exc.__class__.__name__}: {exc}\n")
            f.write(traceback.format_exc()[-1600:] + "\n")
    except Exception:
        pass

def write_status(state: str, **extra: Any) -> None:
    save_json(STATUS, {"version": VERSION, "state": state, "pid": os.getpid(), "updated_ts": now_ts(), "updated_text": now_text(), **extra})

def map_rows(obj: Any) -> Dict[str, Dict[str, Any]]:
    if isinstance(obj, dict) and isinstance(obj.get("rows"), list):
        obj = obj.get("rows")
    elif isinstance(obj, dict) and isinstance(obj.get("rows"), dict):
        obj = obj.get("rows")
    elif isinstance(obj, dict) and isinstance(obj.get("cache"), dict):
        obj = obj.get("cache")
    out: Dict[str, Dict[str, Any]] = {}
    if isinstance(obj, list):
        for r in obj:
            if isinstance(r, dict):
                t = ticker_norm(r.get("ticker") or r.get("symbol") or r.get("market"))
                if t:
                    vv = dict(r); vv.setdefault("ticker", t)
                    out[t] = vv
    elif isinstance(obj, dict):
        for k, v in obj.items():
            if isinstance(v, dict):
                t = ticker_norm(k)
                vv = dict(v); vv.setdefault("ticker", t)
                out[t] = vv
    return out

def _open_tickers() -> List[str]:
    obj = load_json(PAPER_OPEN, {}) or {}
    out: List[str] = []
    if isinstance(obj, dict):
        values = obj.get("positions") if isinstance(obj.get("positions"), list) else obj.values()
        for r in values:
            if isinstance(r, dict):
                t = ticker_norm(r.get("ticker") or r.get("market") or r.get("symbol"))
                if t:
                    out.append(t)
    return out

def _request_rows() -> List[Dict[str, Any]]:
    obj = load_json(STRATEGY_REQ, {}) or {}
    rows = obj.get("requests") if isinstance(obj, dict) else []
    return rows if isinstance(rows, list) else []

def _feature_priority(features: Dict[str, Dict[str, Any]]) -> List[Dict[str, Any]]:
    out = []
    for t, r in features.items():
        score = 6.0
        score += min(28.0, max(0.0, fnum(r.get("change_3m"), default=0.0) * 7))
        score += min(26.0, max(0.0, fnum(r.get("change_5m"), default=0.0) * 5))
        score += min(22.0, max(0.0, fnum(r.get("change_15m"), default=0.0) * 3))
        score += min(18.0, max(0.0, fnum(r.get("turnover_24h"), default=0.0) / 500_000_000))
        if r.get("volume_expanding"):
            score += 8
        if r.get("breakout_hint") or r.get("sweep_reclaim_hint"):
            score += 7
        bucket = "market_hot_rotation" if score >= HOT_ROTATION_THRESHOLD else "market_rotation"
        out.append({"ticker": t, "priority": round(score, 3), "bucket": bucket, "need": [], "source": "feature_rotation"})
    return out

def _bucket_counts(rows: List[Dict[str, Any]]) -> Dict[str, int]:
    d: Dict[str, int] = {}
    for r in rows:
        b = str(r.get("bucket") or "unknown")
        d[b] = d.get(b, 0) + 1
    return d

def build_queue() -> Dict[str, Any]:
    ts = now_ts()
    features = map_rows(load_json(FEATURE, {}) or {})
    orderflow = map_rows(load_json(ORDERFLOW, {}) or {})
    reqs = _request_rows()
    merged: Dict[str, Dict[str, Any]] = {}

    def add(row: Dict[str, Any], bonus: float = 0.0) -> None:
        t = ticker_norm(row.get("ticker") or row.get("market") or row.get("symbol"))
        if not t:
            return
        cur = dict(row)
        cur["ticker"] = t
        cur["priority"] = fnum(cur.get("priority"), default=0.0) + bonus
        cur["priority"] = round(cur["priority"], 3)
        of = orderflow.get(t, {})
        cur["quote_fresh"] = bool(of.get("quote_fresh") or of.get("ws_fresh"))
        cur["ws_fresh"] = bool(of.get("ws_fresh"))
        cur["micro_fresh"] = bool(of.get("micro_fresh"))
        cur["fresh_ready"] = bool(cur["quote_fresh"] and cur["micro_fresh"])
        cur["orderflow_info_ready"] = bool(of.get("info_ready") or cur["fresh_ready"])
        cur["micro_age_sec"] = of.get("micro_age_sec")
        cur["quote_age_sec"] = of.get("quote_age_sec")
        need0 = cur.get("need") if isinstance(cur.get("need"), list) else []
        cur["need_micro"] = "micro" in need0
        cur["need_quote"] = ("quote" in need0) or ("ws" in need0)
        cur["updated_ts"] = ts
        old = merged.get(t)
        if old is None or fnum(cur.get("priority"), default=0) > fnum(old.get("priority"), default=0):
            merged[t] = cur

    # 1. OPEN은 항상 최상단.
    for t in _open_tickers():
        add({"ticker": t, "priority": 600, "bucket": "open_position", "need": ["ws", "micro"], "source": "paper_open"})

    # 2. strategy 요청은 이미 v0.7에서 S/S근접/high만 들어오게 줄인다.
    for r in reqs:
        bucket = str(r.get("bucket") or "strategy_request")
        base = fnum(r.get("priority"), default=50.0)
        if bucket in {"s_candidate", "paper_handoff"}:
            base += 500
        elif bucket in {"near_s_info_wait", "s_near_info"}:
            base += 420
        elif bucket in HIGH_BUCKETS:
            base += 180
        add({**r, "priority": base, "source": r.get("source") or "strategy"})

    # 3. 전체시장 순환은 queue에만 보존한다. active target에는 고점수/hot rotation만 일부 들어간다.
    for r in _feature_priority(features):
        add(r)

    rows = sorted(merged.values(), key=lambda x: (fnum(x.get("priority"), default=0.0), bool(x.get("fresh_ready"))), reverse=True)

    critical: List[Dict[str, Any]] = []
    high: List[Dict[str, Any]] = []
    rotation: List[Dict[str, Any]] = []
    for r in rows:
        b = str(r.get("bucket") or "")
        p = fnum(r.get("priority"), default=0.0)
        if b in CRITICAL_BUCKETS:
            critical.append(r)
        elif b in HIGH_BUCKETS or p >= HIGH_PRIORITY_THRESHOLD:
            high.append(r)
        elif b == "market_hot_rotation" and p >= HOT_ROTATION_THRESHOLD:
            rotation.append(r)

    # v0.7 핵심: 고정 N개 target 제한이 아니라 전체 queue를 보존하고 순환 내보내기한다.
    # - OPEN/S/S근접/정보요청은 최우선 보호
    # - 고우선 후보는 그 다음
    # - 나머지 전체시장은 버리지 않고 rotation cursor로 계속 순환
    # EXPORT_SAFETY_WINDOW는 sidecar 장애 방지용 "한 번에 내보낼 창"일 뿐, 후보 제한 조건이 아니다.
    prev_payload = load_json(QUEUE, {}) or {}
    prev_cursor = int(fnum(prev_payload.get("rotation_cursor"), default=0)) if isinstance(prev_payload, dict) else 0
    export_window = max(1, EXPORT_SAFETY_WINDOW)

    active_rows: List[Dict[str, Any]] = []
    seen = set()
    forced_strategy_rows: List[Dict[str, Any]] = []
    forced_missing_before = 0

    def push_active(row: Dict[str, Any], *, reason: str, force: bool = False) -> None:
        t = str(row.get("ticker") or "")
        if not t or t in seen:
            return
        rr = dict(row)
        rr["active_target"] = True
        rr["target_reason"] = reason
        if force:
            rr["strategy_force_active"] = True
        active_rows.append(rr)
        seen.add(t)

    # OPEN은 항상 맨 앞.
    for r in critical:
        if str(r.get("bucket")) == "open_position":
            push_active(r, reason="open_position", force=True)

    # strategy_worker가 직접 요청한 S/S근접/정보대기 후보는 누락되면 안 된다.
    for req in reqs:
        if not isinstance(req, dict):
            continue
        t = ticker_norm(req.get("ticker") or req.get("market") or req.get("symbol"))
        if not t:
            continue
        bucket = str(req.get("bucket") or "strategy_request")
        need = req.get("need") if isinstance(req.get("need"), list) else []
        must_force = bucket in CRITICAL_BUCKETS or bucket in HIGH_BUCKETS or ("micro" in need) or ("quote" in need) or ("ws" in need)
        if not must_force:
            continue
        base = dict(merged.get(t, req))
        base["ticker"] = t
        base["bucket"] = bucket
        base["need"] = need
        base["source"] = base.get("source") or "strategy_force"
        base["strategy_force_active"] = True
        base["active_target"] = True
        if t not in seen:
            forced_missing_before += 1
            forced_strategy_rows.append(base)
            push_active(base, reason="strategy_request", force=True)

    # 나머지 CRITICAL/HIGH는 우선 보강.
    for r in critical:
        push_active(r, reason="critical", force=True)
    for r in high:
        push_active(r, reason="high_priority", force=False)

    protected_count = len(active_rows)

    # 전체시장 순환 pool. 이미 보호/우선에 들어간 대상은 제외하고, 남은 전체를 버리지 않고 회전한다.
    normal_pool: List[Dict[str, Any]] = []
    for r in rows:
        t = str(r.get("ticker") or "")
        if not t or t in seen:
            continue
        normal_pool.append(r)

    # v0.7 확정: target_router는 전체 queue를 target 파일에 내보낸다.
    # 실제 API/네트워크 보호는 sidecar의 poll batch, TTL, urgent lane, 회전 로직이 담당한다.
    # 여기서 몇 개만 잘라내면 시장 후보가 아예 정보수집 대상에서 사라지므로 금지.
    rotation_export_count = 0
    rotation_wait_count = 0
    rotation_cursor = prev_cursor
    next_rotation_cursor = prev_cursor
    for r in normal_pool:
        push_active(r, reason="market_rotation", force=False)
        rotation_export_count += 1

    export_over_budget_count = 0
    dropped_count = 0
    active_targets = [r.get("ticker") for r in active_rows if r.get("ticker")]
    urgent_rows = [r for r in active_rows if str(r.get("bucket")) in CRITICAL_BUCKETS or bool(r.get("strategy_force_active"))]
    urgent_targets = [r.get("ticker") for r in urgent_rows if r.get("ticker")]

    # v0.5: micro sidecar에는 S/S근접·micro필요 후보를 active 여부와 무관하게 맨 앞에 둔다.
    # active window는 서버보호 처리창일 뿐이고, 전략 후보 제한이 아니다.
    micro_priority_rows: List[Dict[str, Any]] = []
    micro_seen = set()
    def add_micro_row(r: Dict[str, Any]) -> None:
        t = str(r.get("ticker") or "")
        if not t or t in micro_seen:
            return
        rr = dict(r)
        rr["micro_priority"] = True
        rr["micro_urgent"] = str(r.get("bucket")) in CRITICAL_BUCKETS or bool(r.get("need_micro"))
        micro_priority_rows.append(rr)
        micro_seen.add(t)
    strategy_req_rows_for_micro: List[Dict[str, Any]] = []
    for req in reqs:
        if not isinstance(req, dict):
            continue
        t = ticker_norm(req.get("ticker") or req.get("market") or req.get("symbol"))
        if not t:
            continue
        need = req.get("need") if isinstance(req.get("need"), list) else []
        bucket = str(req.get("bucket") or "strategy_request")
        if bucket in CRITICAL_BUCKETS or bucket in HIGH_BUCKETS or "micro" in need:
            rr = dict(merged.get(t, req))
            rr["ticker"] = t
            rr["bucket"] = bucket
            rr["need"] = need
            rr["micro_urgent"] = True
            rr["strategy_force_active"] = True
            strategy_req_rows_for_micro.append(rr)
    for group in (strategy_req_rows_for_micro, urgent_rows, [r for r in active_rows if r.get("need_micro") and not r.get("micro_fresh")], active_rows):
        for r in group:
            add_micro_row(r)
    micro_targets = [r.get("ticker") for r in micro_priority_rows if r.get("ticker")]

    def need_counts(rs: List[Dict[str, Any]]) -> tuple[int, int, int]:
        need_ws = need_micro = fresh_ready = 0
        for r in rs:
            need = r.get("need") if isinstance(r.get("need"), list) else []
            # quote는 WS 구독 또는 scanner/feature REST 시세를 통해 채울 수 있지만,
            # WS sidecar target에도 같이 올려 빠른 실시간 시세를 시도한다.
            if ("ws" in need or "quote" in need) and not r.get("quote_fresh"):
                need_ws += 1
            if "micro" in need and not r.get("micro_fresh"):
                need_micro += 1
            if r.get("fresh_ready"):
                fresh_ready += 1
        return need_ws, need_micro, fresh_ready

    need_ws, need_micro, fresh_recovered = need_counts(active_rows)
    near_s_count = sum(1 for r in active_rows if str(r.get("bucket")) in {"near_s_info_wait", "s_near_info"})
    payload = {
        "version": VERSION,
        "updated_ts": ts,
        "updated_text": now_text(ts),
        "queue_count": len(rows),
        "active_target_count": len(active_targets),
        "target_count": len(active_targets),  # 기존 화면 호환
        "backlog_count": max(0, len(rows) - len(active_rows)),
        "export_safety_window": export_window,
        "targets": active_targets,
        "active_targets": active_targets,
        "urgent_targets": urgent_targets,
        "rows": rows[:700],
        "active_rows": active_rows[:350],
        "urgent_rows": urgent_rows[:120],
        "buckets": _bucket_counts(rows),
        "active_buckets": _bucket_counts(active_rows),
        "fresh_recovered": fresh_recovered,
        "need_ws": need_ws,
        "need_micro": need_micro,
        "near_s_count": near_s_count,
        "micro_priority_target_count": len(micro_targets),
        "micro_need_count": sum(1 for r in active_rows if r.get("need_micro") and not r.get("micro_fresh")),
        "export_safety_window": export_window,
        "priority_protected_count": protected_count,
        "rotation_pool_count": len(normal_pool),
        "rotation_export_count": rotation_export_count,
        "rotation_wait_count": rotation_wait_count,
        "rotation_cursor": rotation_cursor,
        "next_rotation_cursor": next_rotation_cursor,
        "export_over_budget_count": export_over_budget_count,
        "dropped_count": dropped_count,
        "strategy_req_total_count": len(reqs),
        "strategy_req_forced_active_count": len(forced_strategy_rows),
        "strategy_req_missing_before_force": forced_missing_before,
        "strategy_req_micro_target_count": len(strategy_req_rows_for_micro),
        "strategy_req_count": sum(1 for r in active_rows if str(r.get("bucket")) in {"s_candidate", "paper_handoff", "near_s_info_wait", "s_near_info", "info_wait_high"} or bool(r.get("strategy_force_active"))),
        "strategy_req_info_ready": sum(1 for r in active_rows if (str(r.get("bucket")) in {"s_candidate", "paper_handoff", "near_s_info_wait", "s_near_info", "info_wait_high"} or bool(r.get("strategy_force_active"))) and r.get("fresh_ready")),
        "critical_count": len(critical),
        "high_count": len(high),
        "rotation_count": len(rotation),
        "note": "v0.7: 고정 N개 제한 제거. 전체 queue를 target 파일에 내보내고, API 보호는 sidecar poll batch/TTL/urgent lane이 담당. 버림 없음.",
    }
    save_json(QUEUE, payload)

    # WS sidecar가 target 변경을 확실히 감지하도록 meta와 reconnect_seq를 넣는다.
    prev_ws = load_json(WS_TARGETS, {}) or {}
    prev_targets = prev_ws.get("targets") if isinstance(prev_ws, dict) and isinstance(prev_ws.get("targets"), list) else []
    changed = set(map(str, prev_targets)) != set(map(str, active_targets))
    prev_seq = int(fnum(prev_ws.get("reconnect_seq"), default=0)) if isinstance(prev_ws, dict) else 0
    reconnect_seq = prev_seq + 1 if changed else prev_seq
    target_meta = {}
    for r in active_rows:
        t = str(r.get("ticker") or "")
        if not t:
            continue
        target_meta[t] = {
            "priority": r.get("priority"),
            "bucket": r.get("bucket"),
            "need": r.get("need"),
            "source": "current_candidate" if str(r.get("bucket")) in CRITICAL_BUCKETS else "priority_queue",
            "auto_candidate": str(r.get("bucket")) in {"s_candidate", "paper_handoff"},
            "updated_ts": ts,
        }

    active_payload = {
        "version": VERSION,
        "updated_ts": ts,
        "updated_text": now_text(ts),
        "target_count": len(active_targets),
        "targets": active_targets,
        "rows": active_rows[:300],
        "queue_count": len(rows),
        "backlog_count": payload["backlog_count"],
        "active_buckets": payload["active_buckets"],
        "target_meta": target_meta,
        "force_reconnect": bool(changed),
        "reconnect_seq": reconnect_seq,
        "reconnect_reason": "target_router_active_changed" if changed else "unchanged",
        "reason": "target_router_active_priority",
        "note": "full queue target export. 전체 queue를 보존하고 target 파일에도 내보냄. sidecar가 batch/TTL/urgent lane으로 처리.",
    }
    micro_target_meta = {}
    for idx, r in enumerate(micro_priority_rows):
        t = str(r.get("ticker") or "")
        if not t:
            continue
        micro_target_meta[t] = {
            "priority": r.get("priority"),
            "bucket": r.get("bucket"),
            "need": r.get("need"),
            "micro_rank": idx + 1,
            "micro_urgent": bool(r.get("micro_urgent")),
            "source": "micro_priority" if bool(r.get("micro_urgent")) else "active_rotation",
            "updated_ts": ts,
        }
    micro_payload = dict(active_payload)
    micro_payload.update({
        "target_count": len(micro_targets),
        "targets": micro_targets,
        "rows": micro_priority_rows[:350],
        "target_meta": micro_target_meta,
        "micro_priority_target_count": len(micro_targets),
        "note": "v0.7 micro: S/S근접·micro필요 후보 최우선 + 나머지 전체시장도 target에 포함. sidecar가 batch 회전. 버림 없음.",
    })
    urgent_payload = dict(micro_payload)
    urgent_payload.update({"target_count": len(urgent_targets), "targets": urgent_targets, "rows": urgent_rows[:120], "note": "urgent: OPEN/S/S근접 후보 우선"})
    save_json(WS_TARGETS, active_payload)
    save_json(MICRO_TARGETS, micro_payload)
    save_json(MICRO_URGENT, urgent_payload)

    write_status(
        "running",
        queue_count=len(rows), active_target_count=len(active_targets), target_count=len(active_targets),
        backlog_count=payload["backlog_count"], near_s_count=near_s_count, fresh_recovered=fresh_recovered,
        need_ws=need_ws, need_micro=need_micro, micro_priority_target_count=len(micro_targets),
        export_safety_window=export_window, priority_protected_count=protected_count,
        rotation_pool_count=len(normal_pool), rotation_export_count=rotation_export_count, rotation_wait_count=rotation_wait_count,
        rotation_cursor=rotation_cursor, next_rotation_cursor=next_rotation_cursor, export_over_budget_count=export_over_budget_count,
        dropped_count=dropped_count, last_sec=0,
    )
    return payload

def run_once() -> Dict[str, Any]:
    st = now_ts()
    p = build_queue()
    sec = now_ts() - st
    write_status(
        "running", queue_count=p.get("queue_count", 0), active_target_count=p.get("active_target_count", 0),
        target_count=p.get("target_count", 0), backlog_count=p.get("backlog_count", 0),
        near_s_count=p.get("near_s_count", 0), fresh_recovered=p.get("fresh_recovered", 0),
        need_ws=p.get("need_ws", 0), need_micro=p.get("need_micro", 0), micro_priority_target_count=p.get("micro_priority_target_count", 0),
        export_safety_window=p.get("export_safety_window", EXPORT_SAFETY_WINDOW), priority_protected_count=p.get("priority_protected_count", 0),
        rotation_pool_count=p.get("rotation_pool_count", 0), rotation_export_count=p.get("rotation_export_count", 0), rotation_wait_count=p.get("rotation_wait_count", 0),
        rotation_cursor=p.get("rotation_cursor", 0), next_rotation_cursor=p.get("next_rotation_cursor", 0), export_over_budget_count=p.get("export_over_budget_count", 0),
        dropped_count=p.get("dropped_count", 0), last_sec=round(sec, 3),
    )
    return p

def main() -> None:
    write_status("running", phase="boot", target_count=0, queue_count=0, dropped_count=0, last_sec=0)
    while True:
        try:
            run_once()
        except KeyboardInterrupt:
            write_status("stopping")
            raise
        except Exception as exc:
            append_error("loop", exc)
            write_status("error", error=f"{exc.__class__.__name__}: {exc}")
        time.sleep(max(0.5, INTERVAL_SEC))

if __name__ == "__main__":
    main()
