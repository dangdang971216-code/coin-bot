v2087 3중 보류 ↔ 기존 후보품질 Shadow exact 연결

- 새 shadow를 만들지 않습니다.
- v2086이 실제로 보류한 후보의 trigger-occurrence decision key를 append-only 진단 bridge에 저장합니다.
- 기존 quality_shadow_result_v1125의 같은 exact key만 연결합니다. ticker/시간근접 추정은 없습니다.
- 기존 shadow가 보유한 10분·20분·60분 경로로 손실회피 후보, 놓친 양수, MFE, 재확인 통과를 표시합니다.
- 후보 삭제·등급·순위·구조선·trigger/invalid/target·기존 OPEN·청산은 변경하지 않습니다.
- 자동매수 OFF입니다.
- 서버 검수: Main /version_score, /shadow_all, /weak_hold_shadow, /errorlog
