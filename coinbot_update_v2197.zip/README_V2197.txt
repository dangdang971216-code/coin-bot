코인봇 v2197

- v2196 Paper 성과 snapshot은 이미 정상: 초기화 이후 OPEN 52 / CLOSED 25
- Main이 파일 schema 이름만 보고 정상 snapshot을 FAIL 처리한 reader 오류 수정
- 기존 v2189 reset DONE 완료시각과 snapshot epoch_started_at 직접 대조
- 모든 OPEN/CLOSED의 exact OPEN 시각과 direct decision key를 행별 검증
- Paper 재시작 없음 / 0전 초기화 재실행 없음
- /version_score 기존 이모지·시간구간·TOP 형식 유지
- 상승예측/구조/진입/청산 변경 없음
- 자동매수 OFF

LOCAL PASS / SERVER CHECK
