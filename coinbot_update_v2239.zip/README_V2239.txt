v2238은 Review 새 프로세스가 module-level ledger fsync에 막혀 lock/status 전에 검수시간을 넘겼습니다.
v2239은 Review source의 기존 main 순서를 직접 수정합니다.
재적용 대기나 별도 /grelease_verify는 정상 PASS 뒤 필요 없습니다.
