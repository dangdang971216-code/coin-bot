#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Coinbot Main v2.13.1127 / v1181.

A read-only status hub. It never recalculates candidates or performance and
never scans CLOSED for public score. Every command reads one canonical owner
snapshot and reports CHECK when that snapshot is missing/stale.
"""
from __future__ import annotations

import json
import os
import re
import signal
import sys
import threading
import time
import traceback
from pathlib import Path
from typing import Any, Callable, Dict, List, Mapping, Optional, Sequence

from canonical_spine_v1181 import (
    AUTO_BUY,
    STRATEGY_MODE,
    SpinePaths,
    atomic_write_json,
    file_age,
    find_ledger,
    integer,
    mapping,
    now_text,
    now_ts,
    num,
    pct_text,
    read_json,
    read_jsonl_tail,
    safe_error_tail,
    text,
)

try:
    from telegram import BotCommand
    from telegram.ext import CommandHandler, Filters, MessageHandler, Updater
except Exception:
    BotCommand = None
    CommandHandler = None
    Filters = None
    MessageHandler = None
    Updater = None

BOT_VERSION = "수익형 v2.13.1127"
MAIN_BOT_VERSION = BOT_VERSION
BUILD_LABEL = "v1181_snapshot_only_main_canonical_spine_2026-07-02"
V650_BUILD_LABEL = BUILD_LABEL
HEARTBEAT_SEC = 10.0
TELEGRAM_LIMIT = 3900
_STOP = False


def base_dir() -> Path:
    override = os.getenv("COINBOT_BASE_DIR", "").strip()
    return Path(override).expanduser().resolve() if override else Path(__file__).resolve().parent


BASE_DIR = base_dir()
PATHS = SpinePaths(BASE_DIR)
TELEGRAM_TOKEN = os.getenv("TELEGRAM_TOKEN", "").strip()
CHAT_ID = os.getenv("CHAT_ID", "").strip()


def log_error(where: str, exc: BaseException) -> None:
    path = BASE_DIR / "clean_brain_error.log"
    message = (
        f"[{now_text()}] {where}: {type(exc).__name__}: {exc}\n"
        f"{traceback.format_exc()[-4000:]}\n"
    )
    try:
        with path.open("a", encoding="utf-8") as handle:
            handle.write(message)
    except OSError:
        pass


def write_status(state: str = "running", **extra: Any) -> None:
    payload: Dict[str, Any] = {
        "schema": "main_status_v1181",
        "version": BOT_VERSION,
        "build": BUILD_LABEL,
        "running": state not in {"stopped", "error"},
        "state": state,
        "phase": extra.pop("phase", "idle"),
        "updated_ts": now_ts(),
        "updated_text": now_text(),
        "pid": os.getpid(),
        "owner": "main_snapshot_only_renderer_v1181",
        "strategy_mode": STRATEGY_MODE,
        "auto_buy": False,
        "candidate_recalculation": False,
        "performance_recalculation": False,
        "legacy_command_override_chain": False,
    }
    payload.update(extra)
    atomic_write_json(PATHS.main_status, payload)


def icon(state: Any) -> str:
    value = str(state or "CHECK").upper()
    if value in {"NORMAL", "DONE", "PASS", "READY", "RUNNING"}:
        return "🟢"
    if value in {"FAIL", "FAILED", "ERROR", "DOWN"}:
        return "🔴"
    return "🟡"


def fmt_sec(value: Any) -> str:
    parsed = num(value, default=None)
    return "정보없음" if parsed is None else f"{parsed:.3f}초"


def split_text(message: str, limit: int = TELEGRAM_LIMIT) -> List[str]:
    if len(message) <= limit:
        return [message]
    chunks: List[str] = []
    current: List[str] = []
    size = 0
    for line in message.splitlines(True):
        if current and size + len(line) > limit:
            chunks.append("".join(current).rstrip())
            current = []
            size = 0
        if len(line) > limit:
            for start in range(0, len(line), limit):
                part = line[start : start + limit]
                if current:
                    chunks.append("".join(current).rstrip())
                    current = []
                    size = 0
                chunks.append(part.rstrip())
            continue
        current.append(line)
        size += len(line)
    if current:
        chunks.append("".join(current).rstrip())
    return [chunk for chunk in chunks if chunk]


def render_flow_map_full(_args: Sequence[str] = ()) -> str:
    obj = read_json(PATHS.ops_snapshot, {}) or {}
    if not obj:
        return (
            "🗺️ 통합 운영지도 v1181\n"
            "- 판정: 🟡 CHECK_SOURCE\n"
            "- 쉬운 뜻: Guard의 새 운영지도 snapshot이 아직 없음\n"
            "- 영향: 현재 문제 위치를 지도 기준으로 판단하면 안 됨\n"
            "- 자동매수: OFF"
        )
    overall = text(obj.get("overall_state"), default="CHECK")
    current = mapping(obj.get("current_cycle"))
    last = mapping(obj.get("last_completed_cycle"))
    timing = mapping(obj.get("timing"))
    disk = mapping(obj.get("disk"))
    lines = [
        "🗺️ 통합 운영지도 v1181",
        f"- 전체: {icon(overall)} {overall}",
        f"- 현재 cycle: {icon(current.get('state'))} {current.get('state') or 'CHECK'} · {current.get('pipeline_cycle_id') or '-'}",
        f"- 현재 후보: 전체 {integer(current.get('candidate_rows'))} / S1 {integer(current.get('s1_count'))} / Paper 확인 {integer(current.get('paper_received'))}",
        f"- 직전 완료 cycle: {last.get('pipeline_cycle_id') or '-'} · {last.get('state') or 'CHECK'}",
        f"- 속도: Strategy 전달 {fmt_sec(timing.get('strategy_execution_handoff_sec'))} / 전체 {fmt_sec(timing.get('strategy_full_cycle_sec'))} / Paper core {fmt_sec(timing.get('paper_fast_cycle_sec'))}",
        f"- 디스크 남음: {disk.get('free_mb') if disk.get('free_mb') is not None else '정보없음'}MB",
        "- 자동매수: OFF",
        "",
        "[20단계 흐름]",
    ]
    for row in obj.get("stages") or []:
        if not isinstance(row, dict):
            continue
        io = ""
        if row.get("input") is not None or row.get("output") is not None:
            io = f" · 입력 {row.get('input')} → 출력 {row.get('output')}"
        reason = f" · {row.get('reason')}" if row.get("reason") else ""
        lines.append(
            f"{int(row.get('index') or 0):02d}. {icon(row.get('state'))} {row.get('label') or row.get('key')}"
            f"{io} · owner {row.get('owner') or '-'}{reason}"
        )
    problems = [item for item in (obj.get("problems") or []) if isinstance(item, dict)]
    lines += ["", "[현재 문제]"]
    if not problems:
        lines.append("- 없음")
    else:
        for index, item in enumerate(problems[:12], 1):
            lines.append(
                f"{index}. {icon(item.get('state'))} {item.get('code') or '-'} · {item.get('reason') or '원인 정보없음'}\n"
                f"   영향: {item.get('impact') or '영향 정보없음'} · owner {item.get('owner') or '-'}"
            )
    lines += [
        "",
        "[판독 원칙]",
        "- 현재 cycle과 직전 완료 cycle을 섞지 않음",
        "- Main은 이 snapshot을 표시만 하며 다시 계산하지 않음",
        "- Gate·trigger·invalid·target·RR·청산계약 변경 없음",
    ]
    return "\n".join(lines)


def render_candidate_standard(_args: Sequence[str] = ()) -> str:
    obj = read_json(PATHS.candidate_standard, {}) or {}
    if not obj:
        return (
            "📐 후보·구조 기준판 v1181\n"
            "- 판정: 🟡 CHECK_SOURCE\n"
            "- 쉬운 뜻: Review의 현재 generation 기준판이 아직 없음\n"
            "- 과거 기준판으로 대신 판단하지 않음\n"
            "- 자동매수: OFF"
        )
    state = text(obj.get("state"), default="CHECK_SOURCE")
    delivery = mapping(obj.get("delivery"))
    candidate = mapping(obj.get("candidate"))
    structure = mapping(obj.get("structure"))
    quality = mapping(obj.get("quality"))
    time_info = mapping(obj.get("time"))
    performance = mapping(obj.get("performance"))
    lines = [
        "📐 후보·구조 기준판 v1181",
        f"- 판정: {icon(state)} {state} · {obj.get('easy_state') or '-'}",
        f"- generation: {delivery.get('pipeline_cycle_id') or '-'}",
        f"- commit: {delivery.get('candidate_commit_id') or '-'}",
        f"- 후보: 전체 {integer(candidate.get('total'))} / S1 {integer(candidate.get('s1'))} / S2 {integer(candidate.get('s2'))} / S3 {integer(candidate.get('s3'))}",
        f"- exact key 누락: candidate {integer(candidate.get('candidate_key_missing'))} / decision {integer(candidate.get('decision_key_missing'))}",
        f"- 구조근거: {integer(structure.get('complete'))}/{integer(structure.get('evaluated'))} · 누락 {integer(structure.get('source_missing'))}",
        f"- occurrence age 중앙: {fmt_sec(time_info.get('occurrence_age_median_sec'))}",
        f"- Strategy 전달: {fmt_sec(time_info.get('strategy_execution_handoff_sec'))} / 전체 {fmt_sec(time_info.get('strategy_full_cycle_sec'))}",
        f"- 성과 snapshot: {performance.get('snapshot_id') or '-'} · n {integer(performance.get('count'))} · 승률 {pct_text(performance.get('win_rate'), 1)} · 합산 {pct_text(performance.get('sum_pct'))}",
        "- Gate·TTL·RR·청산 변경 없음 · 자동매수 OFF",
        "",
        "[후보 품질 중앙값]",
    ]
    labels = {
        "price_reaction": "가격반응",
        "relative_strength": "상대강도",
        "money_flow": "money flow",
        "buy_ratio": "매수체결 비율",
        "buy_sustain": "매수지속",
        "rank_score": "rank score",
        "rr": "실제 진입 RR",
        "target_room": "target 공간%",
        "invalid_distance": "invalid 거리%",
        "chase": "추격률%",
        "spread": "spread%",
        "slippage": "slippage%",
    }
    for key, label in labels.items():
        metric = mapping(quality.get(key))
        value = metric.get("median")
        lines.append(f"- {label}: n{integer(metric.get('n'))} / 중앙 {value if value is not None else '정보없음'}")
    missing = obj.get("missing") or []
    lines += ["", "[원천 누락]", "- " + (", ".join(str(item) for item in missing) if missing else "없음")]
    return "\n".join(lines)


def render_health(_args: Sequence[str] = ()) -> str:
    obj = read_json(PATHS.ops_snapshot, {}) or {}
    workers = mapping(obj.get("workers"))
    lines = [
        f"🩺 코인봇 상태 · {BOT_VERSION}",
        f"- 운영지도: {icon(obj.get('overall_state'))} {obj.get('overall_state') or 'CHECK_SOURCE'}",
        f"- snapshot age: {fmt_sec(file_age(PATHS.ops_snapshot))}",
        "- 자동매수: OFF",
        "",
        "[공장 상태]",
    ]
    if not workers:
        lines.append("- Guard snapshot 없음")
    for key, item in workers.items():
        if not isinstance(item, dict):
            continue
        lines.append(
            f"- {icon(item.get('state'))} {key}: {item.get('state') or 'CHECK'} · "
            f"{item.get('version') or '-'} · age {fmt_sec(item.get('age_sec'))} · phase {item.get('phase') or '-'}"
        )
    return "\n".join(lines)


def render_pstatus(_args: Sequence[str] = ()) -> str:
    obj = read_json(PATHS.paper_status, {}) or {}
    if not obj:
        return "📄 Paper 상태\n- CHECK_SOURCE · paper_bot_status.json 없음\n- 자동매수 OFF"
    stats = mapping(obj.get("pick_stats"))
    post = mapping(obj.get("paper_postprocess_v1181"))
    return "\n".join([
        "📄 Paper 실행 core v1181",
        f"- 상태: {icon('NORMAL' if obj.get('running') is not False else 'FAIL')} {'실행 중' if obj.get('running') is not False else '중지'}",
        f"- 버전: {obj.get('version') or obj.get('paper_version') or '-'} / {obj.get('build') or '-'}",
        f"- phase: {obj.get('runtime_phase_v994') or obj.get('phase') or obj.get('startup_phase') or '-'}",
        f"- cycle: {fmt_sec(obj.get('elapsed_sec'))}",
        f"- OPEN: {integer(obj.get('open_count'), obj.get('open_total'))} / 신규 {integer(obj.get('opened_this_cycle'))}",
        f"- batch prepared/committed: {integer(stats.get('open_batch_prepared_v1180'))}/{integer(stats.get('open_batch_committed_v1180'))}",
        f"- OPEN snapshot write: {integer(stats.get('open_snapshot_write_count_v1180'))} / decision write: {integer(stats.get('decision_state_write_count_v1180'))}",
        f"- 후처리: {post.get('state') or '정보없음'} · 마지막 {post.get('last_success_text') or '-'}",
        "- 자동매수: OFF",
    ])


def render_popen(args: Sequence[str] = ()) -> str:
    obj = read_json(PATHS.paper_open, {}) or {}
    rows: List[Dict[str, Any]] = []
    if isinstance(obj, list):
        rows = [item for item in obj if isinstance(item, dict)]
    elif isinstance(obj, dict):
        for key, value in obj.items():
            if isinstance(value, dict):
                row = dict(value)
                row.setdefault("pos_id", key)
                rows.append(row)
    ticker_filter = str(args[0]).upper() if args else ""
    if ticker_filter:
        rows = [row for row in rows if ticker_filter in str(row.get("ticker") or row.get("market") or "").upper()]
    lines = [f"📂 현재 OPEN {len(rows)}개"]
    for row in rows[:30]:
        lines.append(
            f"- {row.get('ticker') or row.get('market') or '-'} · 진입 {row.get('entry_price') or '-'} · "
            f"현재 {row.get('current_price') or row.get('last_price') or '-'} · pos {row.get('pos_id') or '-'}"
        )
    if not rows:
        lines.append("- 없음")
    return "\n".join(lines)


def render_version_score(_args: Sequence[str] = ()) -> str:
    obj = read_json(PATHS.performance, {}) or {}
    if not obj:
        return "📊 canonical 성과\n- CHECK_SOURCE · Paper 성과 snapshot 없음\n- 구 cache fallback 사용 안 함"
    windows = mapping(obj.get("windows"))
    stat = mapping(windows.get("all"), obj.get("summary"))
    counts = mapping(obj.get("counts"))
    return "\n".join([
        "📊 canonical 성과",
        f"- snapshot: {obj.get('snapshot_id') or '-'}",
        f"- 생성: {obj.get('generated_at_text') or obj.get('generated_at') or '-'}",
        f"- 원본: {obj.get('source_owner') or '-'}",
        f"- 표본: {integer(stat.get('count'), counts.get('included'))} / 승 {integer(stat.get('wins'))} / 패 {integer(stat.get('losses'))}",
        f"- 승률: {pct_text(stat.get('win_rate'), 1)}",
        f"- 합산: {pct_text(stat.get('sum_pct'))} / 평균: {pct_text(stat.get('avg_pct'))}",
        f"- 중복 {integer(counts.get('duplicate_rows'), counts.get('duplicates'))} / key 누락 {integer(counts.get('decision_key_missing'), counts.get('missing_key'))}",
        "- Main 독립 재계산 없음",
    ])


def render_trade_review(_args: Sequence[str] = ()) -> str:
    obj = read_json(PATHS.review_snapshot, {}) or {}
    if not obj:
        return "🔎 거래 복기\n- CHECK_SOURCE · Review snapshot 없음"
    candidate = mapping(obj.get("candidate"))
    structure = mapping(obj.get("structure"))
    timing = mapping(obj.get("time"))
    perf = mapping(obj.get("performance"))
    return "\n".join([
        "🔎 거래·후보 복기 v1181",
        f"- snapshot: {obj.get('snapshot_id') or '-'}",
        f"- 후보 {integer(candidate.get('total'))} / S1 {integer(candidate.get('s1'))}",
        f"- 구조근거 완전 {integer(structure.get('complete'))}/{integer(structure.get('evaluated'))}",
        f"- occurrence age 중앙 {fmt_sec(timing.get('occurrence_age_median_sec'))}",
        f"- CLOSED 표본 {integer(perf.get('count'))} / 합산 {pct_text(perf.get('sum_pct'))} / 평균 {pct_text(perf.get('avg_pct'))}",
        "- 관찰값은 진입조건을 새로 만들지 않음",
    ])


def render_issue_ledger(_args: Sequence[str] = ()) -> str:
    path = find_ledger(BASE_DIR, "issue")
    if path is None:
        return "📒 문제장부\n- CHECK_SOURCE · canonical issue ledger 없음"
    rows = read_jsonl_tail(path, limit=500)
    latest: Dict[str, Dict[str, Any]] = {}
    for row in rows:
        key = text(row.get("issue_id"), row.get("id"), row.get("key"))
        if key:
            latest[key] = row
    active = [row for row in latest.values() if str(row.get("status") or row.get("state") or "").upper() not in {"DONE", "CLOSED", "RESOLVED"}]
    lines = [f"📒 문제장부 · 활성 {len(active)}개", f"- source: {path.name}"]
    for row in active[-30:]:
        state = text(row.get("status"), row.get("state"), default="CHECK")
        lines.append(
            f"- {icon(state)} {row.get('issue_id') or row.get('id') or '-'} · {state}\n"
            f"  {row.get('title') or row.get('detail') or row.get('symptom') or '내용 정보없음'}"
        )
    if not active:
        lines.append("- 활성 issue 없음")
    return "\n".join(lines)


def render_change_verify(_args: Sequence[str] = ()) -> str:
    path = find_ledger(BASE_DIR, "change")
    if path is None:
        return "🧾 변경·검수장부\n- CHECK_SOURCE · canonical change ledger 없음"
    rows = read_jsonl_tail(path, limit=60)
    lines = ["🧾 변경·검수장부 · 최근 기록", f"- source: {path.name}"]
    for row in rows[-20:]:
        state = text(row.get("verify_result"), row.get("status"), default="CHECK")
        lines.append(
            f"- {icon(state)} {row.get('change_id') or row.get('id') or '-'} · {state}\n"
            f"  {row.get('symptom') or row.get('new_mainline') or row.get('detail') or '-'}"
        )
    return "\n".join(lines)


def render_errorlog(_args: Sequence[str] = ()) -> str:
    lines = safe_error_tail(BASE_DIR, max_lines=80)
    if not lines:
        return "🧯 /errorlog · canonical\n\n✅ 새 실행 중 오류 없음"
    return "🧯 /errorlog · canonical\n\n" + "\n".join(lines[-80:])


def render_readiness(_args: Sequence[str] = ()) -> str:
    ops = read_json(PATHS.ops_snapshot, {}) or {}
    standard = read_json(PATHS.candidate_standard, {}) or {}
    paper = read_json(PATHS.paper_status, {}) or {}
    performance = read_json(PATHS.performance, {}) or {}
    checks = [
        ("운영 흐름", ops.get("overall_state") == "NORMAL"),
        ("후보 기준판", standard.get("state") == "NORMAL"),
        ("Paper fast core", paper.get("paper_fast_core_v1181") is True),
        ("성과 snapshot", bool(performance.get("snapshot_id"))),
        ("자동매수 OFF", True),
    ]
    ready = all(value for _label, value in checks[:-1])
    lines = [f"🚦 준비도 · {'🟢 REVIEWABLE' if ready else '🟡 CHECK'}"]
    for label, value in checks:
        lines.append(f"- {'✅' if value else '⚠️'} {label}")
    lines.append("- 실매수는 사용자 승인 전 항상 OFF")
    return "\n".join(lines)


def render_commands(_args: Sequence[str] = ()) -> str:
    return "\n".join([
        "📚 메인봇 명령",
        "/flow_map_full · 통합 운영지도",
        "/candidate_standard · 후보 기준판",
        "/health · 공장 상태",
        "/pstatus · Paper 실행 core",
        "/popen [티커] · 현재 OPEN",
        "/version_score · canonical 성과",
        "/trade_review · Review 복기",
        "/issue_ledger · 문제장부",
        "/change_verify · 변경·검수장부",
        "/readiness_board · 준비도",
        "/errorlog · 오류",
        "/batch · 핵심 묶음",
    ])


Render = Callable[[Sequence[str]], str]
COMMANDS: Dict[str, Render] = {
    "flow_map": render_flow_map_full,
    "flow_map_full": render_flow_map_full,
    "candidate_standard": render_candidate_standard,
    "candidate_standard_full": render_candidate_standard,
    "candidate_reason": render_candidate_standard,
    "health": render_health,
    "pstatus": render_pstatus,
    "paper_handoff": render_pstatus,
    "popen": render_popen,
    "version_score": render_version_score,
    "score": render_version_score,
    "quality": render_candidate_standard,
    "strategy_watch": render_flow_map_full,
    "trade_review": render_trade_review,
    "issue_ledger": render_issue_ledger,
    "change_verify": render_change_verify,
    "readiness_board": render_readiness,
    "errorlog": render_errorlog,
    "commands": render_commands,
    "help": render_commands,
}

BATCH_DEFAULT = ["health", "flow_map_full", "candidate_standard", "pstatus", "errorlog"]


def render_command(name: str, args: Sequence[str] = ()) -> str:
    key = str(name or "").strip().lstrip("/").lower()
    renderer = COMMANDS.get(key)
    if renderer is None:
        return f"알 수 없는 명령: /{key}\n/commands에서 확인"
    try:
        return renderer(args)
    except Exception as exc:
        log_error(f"render_{key}", exc)
        return f"❌ /{key} 표시 실패\n- {type(exc).__name__}: {exc}"


def render_batch(args: Sequence[str] = ()) -> str:
    names = [str(item).lstrip("/").lower() for item in args if str(item).strip()] or BATCH_DEFAULT
    sections = [
        f"코인봇 운영 요약집 v1181",
        f"- 생성: {now_text()} KST",
        f"- 메인봇: {BOT_VERSION} / {BUILD_LABEL}",
        "- 모든 값은 canonical snapshot reader",
        "- 자동매수: OFF",
    ]
    for name in names:
        sections += ["", f"## /{name}", "-" * 50, render_command(name)]
    return "\n".join(sections)


COMMANDS["batch"] = render_batch


def make_handler(name: str):
    def handler(update: Any, context: Any) -> None:
        chat_id = str(getattr(getattr(update, "effective_chat", None), "id", ""))
        if CHAT_ID and chat_id != CHAT_ID:
            return
        args = list(getattr(context, "args", []) or [])
        output = render_command(name, args)
        for chunk in split_text(output):
            update.effective_message.reply_text(chunk)
    return handler


def text_router(update: Any, _context: Any) -> None:
    raw = str(getattr(getattr(update, "effective_message", None), "text", "") or "").strip()
    if not raw.startswith("/"):
        return
    parts = raw.split()
    name = parts[0].lstrip("/").split("@", 1)[0]
    output = render_command(name, parts[1:])
    for chunk in split_text(output):
        update.effective_message.reply_text(chunk)


def heartbeat_loop() -> None:
    while not _STOP:
        try:
            write_status("running", phase="idle", command_count=len(COMMANDS))
        except Exception as exc:
            log_error("heartbeat", exc)
        for _ in range(int(HEARTBEAT_SEC * 5)):
            if _STOP:
                break
            time.sleep(0.2)


def signal_handler(_signum: int, _frame: Any) -> None:
    global _STOP
    _STOP = True


def set_commands(updater: Any) -> None:
    if BotCommand is None:
        return
    commands = [
        BotCommand("flow_map_full", "통합 운영지도"),
        BotCommand("candidate_standard", "후보 기준판"),
        BotCommand("health", "공장 상태"),
        BotCommand("pstatus", "Paper 상태"),
        BotCommand("popen", "현재 OPEN"),
        BotCommand("version_score", "canonical 성과"),
        BotCommand("issue_ledger", "문제장부"),
        BotCommand("errorlog", "오류"),
        BotCommand("batch", "핵심 묶음"),
    ]
    try:
        updater.bot.set_my_commands(commands)
    except Exception as exc:
        log_error("set_commands", exc)


def main() -> int:
    signal.signal(signal.SIGTERM, signal_handler)
    signal.signal(signal.SIGINT, signal_handler)
    write_status("initializing", phase="boot")
    threading.Thread(target=heartbeat_loop, name="main-heartbeat-v1181", daemon=True).start()
    if not TELEGRAM_TOKEN or Updater is None:
        write_status("running", phase="headless_no_telegram", telegram=False)
        print(f"{BOT_VERSION} headless status renderer active", flush=True)
        while not _STOP:
            time.sleep(1.0)
        write_status("stopped", phase="shutdown")
        return 0
    updater = Updater(token=TELEGRAM_TOKEN, use_context=True)
    dispatcher = updater.dispatcher
    for name in sorted(COMMANDS):
        if re.fullmatch(r"[A-Za-z0-9_]+", name):
            dispatcher.add_handler(CommandHandler(name, make_handler(name)))
    if MessageHandler is not None and Filters is not None:
        dispatcher.add_handler(MessageHandler(Filters.text & (~Filters.command), text_router))
    set_commands(updater)
    write_status("running", phase="telegram_polling", telegram=True)
    updater.start_polling(drop_pending_updates=True)
    try:
        if CHAT_ID:
            updater.bot.send_message(
                chat_id=CHAT_ID,
                text=f"✅ 메인봇 시작 완료\n- {BOT_VERSION}\n- {BUILD_LABEL}\n- snapshot 전용 상태판\n- 자동매수 OFF",
            )
    except Exception as exc:
        log_error("startup_notice", exc)
    updater.idle()
    write_status("stopped", phase="shutdown")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
