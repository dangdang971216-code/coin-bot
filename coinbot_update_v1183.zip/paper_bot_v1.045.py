#!/usr/bin/env python3
# -*- coding: utf-8 -*-
# Auto-flattened v1181 active dependency graph; historical unreachable definitions removed.

"""
paper_bot_v0.218_v603_final_trade_state_open_only_runtime_reapply_2026-05-31

목적:
- v0.50/v389/v397 계열의 무거운 paper runtime을 더 이상 타지 않는다.
- paper 실행기는 S1 후보 읽기 → OPEN → 기존 OPEN 청산 → 장부 저장 → 알림만 담당한다.
- OPEN/CLOSED/trade_log 장부는 보존하고, 전체 CLOSED 재계산/복기/score full 계산은 실행 루프에서 제외한다.
- v416/v0.127: paper OPEN 직전 최종 안전문을 직접 확인하고, 약한 체결/넓은 스프레드/미끄러짐 후보를 장부 OPEN 전에 보류한다.
- v479: 무반응 S1은 폐기/차단이 아니라 paper OPEN만 보류하고 다음 recheck cycle에 맡긴다.
"""

from __future__ import annotations

import json

import hashlib

import gc

import os

import signal

import subprocess

import threading

import sys

import time

import traceback

import re

import urllib.parse

import urllib.request

from collections import Counter, deque, defaultdict

from pathlib import Path

from datetime import datetime, timedelta, timezone

from typing import Any, Dict, Iterable, List, Optional, Tuple

VERSION = 'paper_bot_v0.795'

BUILD_LABEL = 'structure_board_mainline_2026-06-10'

BASE_DIR = Path(__file__).resolve().parent

FILES: Dict[str, Path] = {
    "paper_latest": BASE_DIR / "paper_candidates_latest.jsonl",
    "s1_hold": BASE_DIR / "paper_s1_hold_cache.json",
    "s1_hold_jsonl": BASE_DIR / "paper_s1_hold_cache.jsonl",
    "s1_hold_trace": BASE_DIR / "paper_s1_hold_consume_trace.jsonl",
    "open": BASE_DIR / "paper_bot_open.json",
    "closed": BASE_DIR / "paper_bot_closed.jsonl",
    "status": BASE_DIR / "paper_bot_status.json",
    "runtime_phase_v994": BASE_DIR / "paper_bot_runtime_phase_v994.json",
    "s3_observation_state_v994": BASE_DIR / "paper_s3_observation_state_v994.json",
    "control": BASE_DIR / "paper_bot_control.json",
    "pid": BASE_DIR / "paper_bot.pid",
    "trace": BASE_DIR / "paper_bot_candidate_handoff_trace.json",
    "handoff_status": BASE_DIR / "paper_bot_candidate_handoff_status.json",
    "score": BASE_DIR / "paper_bot_score_cache.json",
    "classify": BASE_DIR / "paper_bot_classify_cache.json",
    "trade_review": BASE_DIR / "paper_bot_trade_review_cache.json",
    "open_alert_trace": BASE_DIR / "paper_bot_open_alert_trace.jsonl",
    "open_backup": BASE_DIR / "paper_bot_open_backup.json",
    "open_quarantine": BASE_DIR / "paper_bot_open_quarantine.jsonl",
    "open_loss_trace": BASE_DIR / "paper_bot_open_loss_trace.jsonl",
    "close_alert_trace": BASE_DIR / "paper_bot_close_alert_trace.jsonl",
    "trade_detail_v798": BASE_DIR / "paper_bot_trade_detail_v798.jsonl",
    "trade_detail_cache_v798": BASE_DIR / "paper_bot_trade_detail_cache_v798.json",
    "trade_detail_v800": BASE_DIR / "paper_bot_trade_detail_v800.jsonl",
    "trade_detail_cache_v800": BASE_DIR / "paper_bot_trade_detail_cache_v800.json",
    "execution_cost_ledger_v917": BASE_DIR / "paper_execution_cost_ledger.jsonl",
    "execution_cost_status_v917": BASE_DIR / "paper_execution_cost_status.json",
    "closed_append_status_v925": BASE_DIR / "paper_closed_append_status_v925.json",
    "closed_append_events_v925": BASE_DIR / "paper_closed_append_events_v925.jsonl",
    "closed_commit_status": BASE_DIR / "paper_closed_commit_status.json",
    "closed_commit_events": BASE_DIR / "paper_closed_commit_events.jsonl",
    "decision_reconcile_status": BASE_DIR / "paper_decision_reconcile_status.json",
    "exit_monitor_status": BASE_DIR / "paper_exit_monitor_status.json",
    "exit_monitor_events": BASE_DIR / "paper_exit_monitor_events.jsonl",
    "writer_permission_status": BASE_DIR / "paper_writer_permission_status.json",
    "decision_state_v926": BASE_DIR / "paper_decision_state_v926.json",
    "decision_status_v926": BASE_DIR / "paper_decision_status_v926.json",
    "decision_events_v926": BASE_DIR / "paper_decision_events_v926.jsonl",
    "trigger_reach_state_v938": BASE_DIR / "paper_trigger_reach_state_v938.json",
    "timing_spine_status_v940": BASE_DIR / "paper_timing_spine_status_v940.json",
    "timing_spine_events_v940": BASE_DIR / "paper_timing_spine_events_v940.jsonl",
    "hot_rank": BASE_DIR / "clean_scanner_hot_rank_cache.json",
    "error": BASE_DIR / "paper_bot_error.log",
    "log": BASE_DIR / "paper_bot.log",
}

_v987_perf_SCHEMA = 'canonical_alt_swing_performance_snapshot_v987'

_v987_perf_STRATEGY_MODE = 'ALT_SWING_V977'

_v987_perf_CUTOVER_TS = 1782093476.0

_v987_perf_ALLOWED_EXIT_REASONS = {'structure_target', 'structure_invalid', 'swing_trailing', 'swing_no_progress', 'swing_max_weak_hold'}

_v987_perf_KST = timezone(timedelta(hours=9))

def _v987_perf_num(*values: Any, default: Optional[float]=0.0) -> Optional[float]:
    for value in values:
        try:
            if value in (None, '', [], {}):
                continue
            return float(str(value).replace(',', '').replace('%', ''))
        except Exception:
            continue
    return default

def _v987_perf_sources(row: Dict[str, Any]) -> List[Dict[str, Any]]:
    out: List[Dict[str, Any]] = []
    if not isinstance(row, dict):
        return out
    out.append(row)
    for key in ('closed_exact_v926', 'closed_evidence_v983', 'entry_evidence_v983', 'canonical_entry_snapshot', 'entry_snapshot', 'entry_context', 'entry_diagnostics', 'quality_evidence_v938', 'quality_evidence_v936', 'raw'):
        obj = row.get(key)
        if isinstance(obj, dict):
            out.append(obj)
            for nested_key in ('closed_exact_v926', 'closed_evidence_v983', 'entry_evidence_v983', 'canonical_entry_snapshot', 'entry_context', 'entry_diagnostics'):
                nested = obj.get(nested_key)
                if isinstance(nested, dict):
                    out.append(nested)
    return out

def _v987_perf_first(row: Dict[str, Any], keys: Iterable[str]) -> Any:
    for source in _v987_perf_sources(row):
        for key in keys:
            value = source.get(key)
            if value not in (None, '', [], {}):
                return value
    return None

def _v987_perf_open_ts(row: Dict[str, Any]) -> float:
    value = _v987_perf_first(row, ('opened_at', 'opened_ts', 'open_ts', 'entry_open_ts'))
    ts = _v987_perf_num(value, default=0.0) or 0.0
    if ts > 10000000000:
        ts /= 1000.0
    return ts if ts > 0 else 0.0

def _v987_perf_closed_ts(row: Dict[str, Any]) -> float:
    value = _v987_perf_first(row, ('closed_ts', 'exit_ts', 'close_ts', 'exited_ts', 'closed_at', 'timestamp', 'ts'))
    ts = _v987_perf_num(value, default=0.0) or 0.0
    if ts > 10000000000:
        ts /= 1000.0
    return ts if ts > 0 else 0.0

def _v987_perf_strategy_mode(row: Dict[str, Any]) -> str:
    return str(_v987_perf_first(row, ('strategy_mode', 'strategy_mode_v977')) or '').strip()

def _v987_perf_pos_id(row: Dict[str, Any]) -> str:
    return str(_v987_perf_first(row, ('pos_id', 'paper_pos_id_v926', 'event_id')) or '').strip()

def _v987_perf_decision_key(row: Dict[str, Any]) -> str:
    direct = str(_v987_perf_first(row, ('paper_decision_key_v926', 'swing_gate_decision_key_v977', 'minimal_gate_decision_key_v925', 'decision_key')) or '').strip()
    if direct.startswith('decision:'):
        direct = direct[len('decision:'):].strip()
    if direct:
        return direct
    pid = _v987_perf_pos_id(row)
    if pid.startswith('decision:'):
        return pid[len('decision:'):].strip()
    return ''

def _v987_perf_pnl_pct(row: Dict[str, Any]) -> Optional[float]:
    return _v987_perf_num(_v987_perf_first(row, ('net_after_configured_fee_pct_v983', 'net_pct', 'result_pct', 'pnl_pct', 'return_pct', 'profit_pct', 'final_realized_pnl_pct')), default=None)

def _v988_perf_observation_ingress(row: Dict[str, Any]) -> bool:
    if not isinstance(row, dict):
        return False
    for source in _v987_perf_sources(row):
        if any(source.get(key) is True for key in ('s3_observe_v732','s3_observe_v730','s3_observe_v729','s3_observe_v728','s3_observe_v727','s3_observation_only_v988','s3_review_only_v988')):
            return True
        for key in ('strategy_key','paper_strategy_key','strategy_label','strategy','route','setup_type'):
            text=str(source.get(key) or '').strip().lower()
            if text.startswith('coin_quality_s3_observe') or 's3 관찰/복기 후보' in text or 's3 관찰 후보' in text:
                return True
    return False

def _v987_perf_strategy_label(row: Dict[str, Any]) -> str:
    if _v988_perf_observation_ingress(row):
        return '과거 S3 관찰경로 유입'
    value = _v987_perf_first(row, ('strategy_label', 'paper_strategy_label', 'final_entry_label', 'strategy', 'strategy_key', 'route'))
    text = str(value or _v987_perf_STRATEGY_MODE).strip()
    return text if text else _v987_perf_STRATEGY_MODE

def _v987_perf_ticker(row: Dict[str, Any]) -> str:
    text = str(_v987_perf_first(row, ('ticker', 'market', 'symbol')) or '-').strip().upper()
    for prefix in ('KRW-', 'BITHUMB:'):
        if text.startswith(prefix):
            text = text[len(prefix):]
    for suffix in ('_KRW', '-KRW', '/KRW'):
        if text.endswith(suffix):
            text = text[:-len(suffix)]
    return text or '-'

def _v987_perf_exit_reason(row: Dict[str, Any]) -> str:
    return str(_v987_perf_first(row, ('exit_reason', 'exit_rule', 'close_reason')) or 'missing').strip() or 'missing'

def _v987_perf_hold_sec(row: Dict[str, Any]) -> Optional[float]:
    return _v987_perf_num(_v987_perf_first(row, ('hold_sec', 'holding_sec', 'duration_sec')), default=None)

def _v987_perf_peak_pct(row: Dict[str, Any]) -> Optional[float]:
    return _v987_perf_num(_v987_perf_first(row, ('max_net_profit_pct', 'net_peak_pct', 'peak_pct', 'max_profit_pct', 'peak_profit_pct')), default=None)

def _v987_perf_trough_pct(row: Dict[str, Any]) -> Optional[float]:
    return _v987_perf_num(_v987_perf_first(row, ('max_net_loss_pct', 'net_trough_pct', 'trough_pct', 'min_profit_pct', 'max_loss_pct')), default=None)

def _v987_perf_giveback_pct(row: Dict[str, Any]) -> Optional[float]:
    explicit = _v987_perf_num(_v987_perf_first(row, ('giveback_pct', 'missed_profit_pct')), default=None)
    if explicit is not None:
        return explicit
    peak = _v987_perf_peak_pct(row)
    pnl = _v987_perf_pnl_pct(row)
    if peak is not None and pnl is not None:
        return max(0.0, peak - pnl)
    return None

def _v987_perf_read_json(path: Path, default: Any) -> Any:
    try:
        return json.loads(path.read_text(encoding='utf-8', errors='ignore')) if path.exists() else default
    except Exception:
        return default

def _v987_perf_atomic_write_json(path: Path, obj: Dict[str, Any]) -> None:
    """Atomic streaming JSON write; do not allocate a second full snapshot string."""
    path.parent.mkdir(parents=True, exist_ok=True)
    tmp = path.with_name(f'.{path.name}.{os.getpid()}.{time.time_ns()}.tmp')
    try:
        with tmp.open('w', encoding='utf-8') as handle:
            json.dump(obj, handle, ensure_ascii=False, separators=(',', ':'), default=str)
            handle.flush(); os.fsync(handle.fileno())
        os.replace(tmp, path)
    finally:
        try: tmp.unlink(missing_ok=True)
        except OSError: pass

def _v987_perf_stat(rows: List[Dict[str, Any]]) -> Dict[str, Any]:
    values = [float(r['pnl_pct']) for r in rows if isinstance(r.get('pnl_pct'), (int, float))]
    wins = [v for v in values if v > 0]
    losses = [v for v in values if v <= 0]
    total = sum(values)
    return {'n': len(values), 'wins': len(wins), 'losses': len(losses), 'win_rate': round(len(wins) / len(values) * 100.0, 2) if values else 0.0, 'total': round(total, 4), 'avg': round(total / len(values), 4) if values else 0.0, 'avg_win': round(sum(wins) / len(wins), 4) if wins else None, 'avg_loss': round(sum(losses) / len(losses), 4) if losses else None}

def _v989_perf_line(row: Dict[str, Any], name: str, fallback_keys: Iterable[str], default_tf: str) -> Dict[str, Any]:
    evidence = _v987_perf_first(row, ('entry_evidence_v983',))
    evidence = evidence if isinstance(evidence, dict) else {}
    obj = evidence.get(name) if isinstance(evidence.get(name), dict) else {}
    price = _v987_perf_num(obj.get('price'), _v987_perf_first(row, fallback_keys), default=None)
    return {
        'price': price,
        'timeframe': str(obj.get('timeframe') or obj.get('tf') or default_tf).strip() or default_tf,
        'source': str(obj.get('source') or 'OPEN 봉인 구조선').strip() or 'OPEN 봉인 구조선',
    }

def _profitability_evidence_sources(row: Dict[str, Any]) -> List[Dict[str, Any]]:
    """Bounded evidence walk. Reads sealed OPEN/CLOSED evidence only; no current-market fallback."""
    if not isinstance(row, dict):
        return []
    nested_keys = (
        'profitability_entry_evidence_v1034','profitability_preopen_evidence_v1034',
        'entry_evidence_v983','closed_evidence_v983','canonical_entry_snapshot','entry_context',
        'entry_diagnostics','paper_final_safety_diagnostics','canonical_entry_decision',
        'quality_observation_v925','swing_entry_gate_v977','swing_structure_plan_v977',
        'structure_plan','metrics','risk_reward','raw','quality','risk','market_regime','late_risk_audit','profitability_shadow_trailing_v1034',
    )
    queue: List[Dict[str, Any]] = [row]
    out: List[Dict[str, Any]] = []
    seen: set[int] = set()
    while queue and len(out) < 40:
        obj=queue.pop(0)
        if not isinstance(obj,dict) or id(obj) in seen:
            continue
        seen.add(id(obj)); out.append(obj)
        for key in nested_keys:
            value=obj.get(key)
            if isinstance(value,dict): queue.append(value)
    return out

def _profitability_first(row: Dict[str, Any], *keys: str) -> Any:
    for source in _profitability_evidence_sources(row):
        for key in keys:
            value=source.get(key)
            if value not in (None,'',[],{}):
                return value
    return None

def _profitability_num(row: Dict[str, Any], *keys: str) -> Optional[float]:
    return _v987_perf_num(_profitability_first(row,*keys), default=None)

def _profitability_bool(row: Dict[str, Any], *keys: str) -> Optional[bool]:
    value=_profitability_first(row,*keys)
    if value in (None,''):
        return None
    if isinstance(value,bool): return value
    text=str(value).strip().lower()
    if text in ('1','true','yes','y','on'): return True
    if text in ('0','false','no','n','off'): return False
    return bool(value)

def _profitability_quality_fields(row: Dict[str, Any]) -> Dict[str, Any]:
    return {
        'price_reaction_pct':_profitability_num(row,'price_reaction_pct','entry_price_reaction_pct','reaction_pct'),
        'buy_ratio':_profitability_num(row,'buy_ratio','buy_trade_ratio','micro_buy_ratio'),
        'buy_sustain_1m':_profitability_num(row,'buy_sustain_1m','micro_buy_ratio_sustain_1m','buy_ratio_1m'),
        'relative_strength':_profitability_num(row,'relative_strength_pct','relative_strength','relative_strength_score'),
        'money_flow':_profitability_num(row,'money_flow_score','money_expand_score','turnover_change_pct'),
        'vwap_gap_pct':_profitability_num(row,'vwap_gap_pct'),
        'ema5_gap_pct':_profitability_num(row,'ema5_gap_pct'),
        'long_upper_wick':_profitability_bool(row,'long_upper_wick'),
    }

def _v987_perf_compact_row(row: Dict[str, Any], key: str, match_mode: str) -> Dict[str, Any]:
    observation_ingress = _v988_perf_observation_ingress(row)
    evidence = _v987_perf_first(row, ('entry_evidence_v983',))
    evidence = evidence if isinstance(evidence, dict) else {}
    profit_evidence = row.get('profitability_entry_evidence_v1034') if isinstance(row.get('profitability_entry_evidence_v1034'),dict) else {}
    market_context = evidence.get('market_context') if isinstance(evidence.get('market_context'), dict) else {}
    sealed_market = profit_evidence.get('market_regime') if isinstance(profit_evidence.get('market_regime'),dict) else {}
    if not market_context and sealed_market:
        market_context={'market_regime':sealed_market.get('mode'),'regime':sealed_market.get('mode'),'score':sealed_market.get('score'),'breadth_up_pct':sealed_market.get('breadth_up_pct'),'strong_count':sealed_market.get('strong_count'),'avg_top60_change':sealed_market.get('avg_top60_change'),'source':'paper_open_market_worker_snapshot_v1034'}
    cost = evidence.get('cost') if isinstance(evidence.get('cost'), dict) else {}
    execution_cost = row.get('paper_execution_cost_v917') if isinstance(row.get('paper_execution_cost_v917'), dict) else {}
    source_strategy = str(_v987_perf_strategy_label(row) or '').strip()
    evidence_method = str(evidence.get('setup_type') or '').strip()
    entry_method = source_strategy if source_strategy and source_strategy not in (_v987_perf_STRATEGY_MODE, '알트 스윙 구조 진입') else (evidence_method or source_strategy or _v987_perf_STRATEGY_MODE)
    signed_slippage=_v987_perf_num(cost.get('paper_reference_slippage_pct'),cost.get('reference_slippage_pct'),execution_cost.get('signed_slippage_pct'),_v987_perf_first(row, ('paper_reference_slippage_pct','reference_slippage_pct')),default=None)
    cost_slippage=_v987_perf_num(cost.get('paper_reference_cost_pct'),cost.get('reference_total_cost_pct'),execution_cost.get('cost_slippage_pct'),_v987_perf_first(row, ('paper_reference_cost_pct','reference_total_cost_pct')),default=None)
    measurement_state=str(execution_cost.get('measurement_state') or execution_cost.get('state') or cost.get('paper_reference_state') or ('legacy_numeric' if signed_slippage is not None else 'not_recorded'))
    trigger_line=_v989_perf_line(row,'trigger',('swing_trigger_price_v977','trigger_price'),'15m/5m')
    invalid_line=_v989_perf_line(row,'invalid',('swing_invalid_price_v977','invalid_price','stop_price'),'1h/30m')
    target_line=_v989_perf_line(row,'target',('swing_target_price_v977','target_price'),'4h/2h')
    entry_price=_v987_perf_num(_v987_perf_first(row,('entry_price','open_price')),default=None)
    actual_rr=profit_evidence.get('actual_entry_rr')
    actual_rr=_v987_perf_num(actual_rr,default=None)
    if actual_rr is None and entry_price and target_line.get('price') and invalid_line.get('price') and float(target_line['price'])>entry_price>float(invalid_line['price']):
        actual_rr=(float(target_line['price'])-entry_price)/(entry_price-float(invalid_line['price']))
    trigger_rr=_v987_perf_num(profit_evidence.get('trigger_rr'),evidence.get('risk_reward'),_v987_perf_first(row,('risk_reward_ratio','rr')),default=None)
    frozen_ts=_v987_perf_num(profit_evidence.get('trigger_frozen_ts'),_profitability_first(row,'trigger_frozen_ts','swing_trigger_frozen_ts_v977','frozen_ts'),default=None)
    opened_at=_v987_perf_open_ts(row)
    plan_age=(opened_at-frozen_ts) if frozen_ts and opened_at>=frozen_ts else None
    quality=_profitability_quality_fields(row)
    risk_evidence=profit_evidence.get('risk') if isinstance(profit_evidence.get('risk'),dict) else {}
    market_mode=str(sealed_market.get('mode') or market_context.get('market_regime') or market_context.get('regime') or market_context.get('market_state') or '').strip() or None
    shadow=row.get('profitability_shadow_trailing_v1034') if isinstance(row.get('profitability_shadow_trailing_v1034'),dict) else {}
    preopen=row.get('profitability_preopen_evidence_v1034') if isinstance(row.get('profitability_preopen_evidence_v1034'),dict) else {}
    exit_contract_v1038 = row.get('exit_contract_v1038') if isinstance(row.get('exit_contract_v1038'),dict) else (evidence.get('exit_contract') if isinstance(evidence.get('exit_contract'),dict) else {})
    reentry_gate_v1037 = row.get('loss_reentry_gate_v1037') if isinstance(row.get('loss_reentry_gate_v1037'),dict) else (evidence.get('loss_reentry_gate_v1037') if isinstance(evidence.get('loss_reentry_gate_v1037'),dict) else {})
    target_distance_pct = None
    invalid_distance_pct = None
    if entry_price and target_line.get('price') is not None:
        target_distance_pct = ((float(target_line['price']) - float(entry_price)) / float(entry_price)) * 100.0
    if entry_price and invalid_line.get('price') is not None:
        invalid_distance_pct = ((float(entry_price) - float(invalid_line['price'])) / float(entry_price)) * 100.0
    return {
        'identity':f'decision:{key}','decision_key':key,'pos_id':_v987_perf_pos_id(row),'match_mode':match_mode,
        'ticker':_v987_perf_ticker(row),'strategy':('과거 S3 관찰경로 유입' if observation_ingress else entry_method),'entry_method':entry_method,'observation_ingress_v988':observation_ingress,
        'opened_at':opened_at,'closed_at':_v987_perf_closed_ts(row),'entry_price':entry_price,'exit_price':_v987_perf_num(_v987_perf_first(row,('exit_price','close_price')),default=None),
        'pnl_pct':_v987_perf_pnl_pct(row),'exit_reason':_v987_perf_exit_reason(row),'contract_ok':_v987_perf_exit_reason(row) in _v987_perf_ALLOWED_EXIT_REASONS,
        'hold_sec':_v987_perf_hold_sec(row),'peak_pct':_v987_perf_peak_pct(row),'trough_pct':_v987_perf_trough_pct(row),'mfe_pct':_v987_perf_peak_pct(row),'mae_pct':_v987_perf_trough_pct(row),'giveback_pct':_v987_perf_giveback_pct(row),
        'trigger':trigger_line,'invalid':invalid_line,'target':target_line,'risk_reward':trigger_rr,'trigger_rr':trigger_rr,'actual_entry_rr':round(float(actual_rr),6) if actual_rr is not None else None,'actual_rr_delta':round(float(actual_rr-trigger_rr),6) if actual_rr is not None and trigger_rr is not None else None,'actual_rr_below_contract':bool(actual_rr is not None and actual_rr<1.5),
        'target_room_pct':_v987_perf_num(evidence.get('target_room_pct'),_v987_perf_first(row,('target_room_pct',)),default=None),'trigger_chase_pct':_v987_perf_num(evidence.get('trigger_chase_pct'),_v987_perf_first(row,('trigger_gap_pct',)),default=None),
        'spread_pct':_v987_perf_num(cost.get('spread_pct'),_v987_perf_first(row,('spread_pct','micro_spread_pct')),default=None),'configured_fee_pct':_v987_perf_num(cost.get('configured_roundtrip_fee_pct'),_v987_perf_first(row,('configured_roundtrip_fee_pct_v983',)),default=None),
        'paper_reference_slippage_pct':signed_slippage,'paper_reference_cost_pct':cost_slippage,'paper_reference_measurement_state':measurement_state,'paper_reference_exchange_confirmed':bool(execution_cost.get('exchange_confirmed')),
        'gross_pnl_pct':_v987_perf_num(_v987_perf_first(row,('gross_pnl_pct','price_change_pct')),default=None),'net_pnl_pct':_v987_perf_num(_v987_perf_first(row,('net_pnl_pct','realized_pnl_pct','pnl_pct')),default=None),
        'market_context':market_context,'market_mode_at_open':market_mode,'market_regime_evidence_state':('sealed_exact_v1034' if sealed_market else ('legacy_entry_context' if market_mode else 'missing')),
        **quality,
        'quality_late_risk_audit':preopen.get('late_risk_audit') if preopen else _profitability_bool(row,'late_risk_audit'),
        'risk_cooldown_at_open':bool(risk_evidence.get('cooldown_active')) if risk_evidence else None,'risk_cooldown_level':risk_evidence.get('level') if risk_evidence else None,'risk_cooldown_reasons':risk_evidence.get('reasons') if isinstance(risk_evidence.get('reasons'),list) else [],
        'source_lane':str(profit_evidence.get('source_lane') or preopen.get('source_lane') or _profitability_first(row,'_source_file','source_lane','candidate_lane') or '').strip() or None,'hot_rank_lane':bool(profit_evidence.get('hot_rank_lane')) if 'hot_rank_lane' in profit_evidence else ('hot-rank' in entry_method.lower() or 'hot_rank' in entry_method.lower()),
        'open_count_before':_v987_perf_num(profit_evidence.get('open_count_before'),_profitability_first(row,'paper_open_count_before_v1034'),default=None),'new_index_in_cycle':_v987_perf_num(profit_evidence.get('new_index_in_cycle'),_profitability_first(row,'paper_new_index_in_cycle_v1034'),default=None),
        'trigger_frozen_ts':frozen_ts,'frozen_plan_age_sec':round(plan_age,3) if plan_age is not None else None,'source_plan_move_detected':_profitability_bool(row,'source_plan_move_detected','swing_source_plan_moved_v977'),'frozen_plan_held':_profitability_bool(row,'frozen_plan_held'),
        'shadow_trailing_v1034':shadow,'target_first_touch_ts':_v987_perf_num(_profitability_first(row,'first_target_touch_ts_v983','target_first_touch_ts'),default=None),'invalid_first_touch_ts':_v987_perf_num(_profitability_first(row,'first_invalid_touch_ts_v983','invalid_first_touch_ts'),default=None),
        'target_distance_pct':round(float(target_distance_pct),6) if target_distance_pct is not None else None,'invalid_distance_pct':round(float(invalid_distance_pct),6) if invalid_distance_pct is not None else None,
        'exit_contract_schema_v1038':str(exit_contract_v1038.get('schema') or ''),'trailing_exit_enabled_v1038':bool(exit_contract_v1038.get('schema')=='alt_swing_exit_contract_v1038' and exit_contract_v1038.get('trailing_exit') is True),'trailing_trigger_pct_v1038':_v987_perf_num(exit_contract_v1038.get('trailing_trigger_pct'),default=None),'trailing_giveback_pct_v1038':_v987_perf_num(exit_contract_v1038.get('trailing_giveback_pct'),default=None),
        'loss_reentry_gate_state_v1037':str(reentry_gate_v1037.get('state') or ''),'loss_reentry_allowed_v1037':bool(reentry_gate_v1037.get('allowed') is True),'loss_reentry_prior_loss_v1037':bool(isinstance(reentry_gate_v1037.get('prior'),dict) and reentry_gate_v1037.get('prior')),'loss_reentry_reset_source_v1037':str(reentry_gate_v1037.get('reset_source') or ''),'trigger_occurrence_kind_v1037':str(((reentry_gate_v1037.get('current') or {}).get('occurrence') or {}).get('kind') or ''),
        'entry_build_key':str(_v987_perf_first(row,('entry_build_key','open_build_key','score_patch_version','opened_build','build')) or '-').strip(),'candidate_entry_build_key_v923':str(row.get('candidate_entry_build_key_v923') or row.get('candidate_entry_build_key') or execution_cost.get('candidate_entry_build_key') or _v987_perf_first(row,('entry_build_key','open_build_key')) or '').strip(),'good_s2_occurrence_key_v923':str(row.get('good_s2_occurrence_key_v923') or execution_cost.get('good_s2_occurrence_key_v923') or '').strip(),'closed_result_key':str(row.get('closed_result_key') or row.get('result_key') or key).strip(),
        'opened_paper_version':str(_v987_perf_first(row,('opened_paper_version','paper_version')) or '-').strip(),'paper_build_label':str(_v987_perf_first(row,('paper_build_label','opened_paper_build','paper_runtime_build')) or '-').strip(),'profitability_evidence_schema':'profitability_exact_row_v1034','source':'closed_ledger',
    }

def _v987_perf_digest_json(obj: Any) -> str:
    raw = json.dumps(obj, ensure_ascii=False, sort_keys=True, separators=(',', ':'), default=str).encode('utf-8')
    return hashlib.sha256(raw).hexdigest()

def _v1009_perf_market_label(row: Dict[str, Any]) -> str:
    ctx=row.get('market_context') if isinstance(row.get('market_context'),dict) else {}
    for key in ('market_regime','regime','market_state','state'):
        value=ctx.get(key)
        if value not in (None,''): return str(value)
    return '미기록'

def _v1010_metric_summary(rows: List[Dict[str, Any]]) -> Dict[str, Any]:
    def collect(field: str) -> List[float]:
        return [float(r[field]) for r in rows if isinstance(r.get(field),(int,float))]
    def avg(values: List[float]) -> Optional[float]:
        return round(sum(values)/len(values),4) if values else None
    mfe=collect('mfe_pct'); mae=collect('mae_pct'); giveback=collect('giveback_pct'); hold=collect('hold_sec')
    spread=collect('spread_pct'); fee=collect('configured_fee_pct'); slip=collect('paper_reference_slippage_pct'); ref_cost=collect('paper_reference_cost_pct')
    measurement_states=Counter(str(r.get('paper_reference_measurement_state') or 'not_recorded') for r in rows)
    confirmed_states={'paper_reference_confirmed','exchange_confirmed'}
    confirmed=sum(v for k,v in measurement_states.items() if k in confirmed_states)
    stale=sum(v for k,v in measurement_states.items() if 'stale' in k)
    missing=sum(v for k,v in measurement_states.items() if k in {'not_recorded','unknown'} or k.startswith('missing_') or k.endswith('_missing'))
    return {
        **_v987_perf_stat(rows),
        'avg_mfe_pct':avg(mfe),'mfe_rows':len(mfe),'avg_mae_pct':avg(mae),'mae_rows':len(mae),
        'avg_giveback_pct':avg(giveback),'giveback_rows':len(giveback),'avg_hold_sec':avg(hold),'hold_rows':len(hold),
        'avg_spread_pct':avg(spread),'spread_rows':len(spread),'avg_configured_fee_pct':avg(fee),'configured_fee_rows':len(fee),
        'avg_paper_reference_slippage_pct':avg(slip),'paper_reference_slippage_rows':len(slip),
        'avg_paper_reference_cost_pct':avg(ref_cost),'paper_reference_cost_rows':len(ref_cost),
        'paper_reference_measurement_state_counts':dict(measurement_states),
        'paper_reference_confirmed_rows':int(confirmed),'paper_reference_stale_rows':int(stale),'paper_reference_missing_rows':int(missing),
    }

def _v1010_group_metrics(rows: List[Dict[str, Any]], field: str, missing: str='미기록') -> Dict[str, Dict[str, Any]]:
    groups: Dict[str,List[Dict[str,Any]]]=defaultdict(list)
    for row in rows:
        value=row.get(field); key=str(value).strip() if value not in (None,'') else missing
        groups[key].append(row)
    return {key:_v1010_metric_summary(group) for key,group in groups.items()}

def _v1040_bucket_group(rows: List[Dict[str, Any]], value_fn, buckets: List[Tuple[str, Any]]) -> Dict[str, Dict[str, Any]]:
    grouped: Dict[str, List[Dict[str, Any]]] = {name: [] for name, _ in buckets}
    grouped['미기록'] = []
    for row in rows:
        try:
            value = value_fn(row)
        except Exception:
            value = None
        if not isinstance(value, (int, float)):
            grouped['미기록'].append(row)
            continue
        placed = False
        for name, predicate in buckets:
            try:
                if predicate(float(value)):
                    grouped[name].append(row); placed = True; break
            except Exception:
                continue
        if not placed:
            grouped['미기록'].append(row)
    return {name: _v1010_metric_summary(items) for name, items in grouped.items() if items}

def _v1040_pre_entry_feature_groups(rows: List[Dict[str, Any]]) -> Dict[str, Any]:
    return {
        'actual_entry_rr': _v1040_bucket_group(rows, lambda r: r.get('actual_entry_rr'), [
            ('1.50 미만', lambda v: v < 1.5), ('1.50~1.99', lambda v: 1.5 <= v < 2.0), ('2.00 이상', lambda v: v >= 2.0)]),
        'target_distance_pct': _v1040_bucket_group(rows, lambda r: r.get('target_distance_pct'), [
            ('5% 미만', lambda v: v < 5.0), ('5~9.99%', lambda v: 5.0 <= v < 10.0), ('10% 이상', lambda v: v >= 10.0)]),
        'invalid_distance_pct': _v1040_bucket_group(rows, lambda r: r.get('invalid_distance_pct'), [
            ('1% 미만', lambda v: v < 1.0), ('1~1.99%', lambda v: 1.0 <= v < 2.0), ('2~2.99%', lambda v: 2.0 <= v < 3.0), ('3~4.99%', lambda v: 3.0 <= v < 5.0), ('5% 이상', lambda v: v >= 5.0)]),
        'trigger_chase_pct': _v1040_bucket_group(rows, lambda r: r.get('trigger_chase_pct'), [
            ('0% 이하', lambda v: v <= 0.0), ('0~0.20%', lambda v: 0.0 < v <= 0.2), ('0.20~0.40%', lambda v: 0.2 < v <= 0.4), ('0.40~0.60%', lambda v: 0.4 < v <= 0.6), ('0.60% 초과', lambda v: v > 0.6)]),
        'prior_loss_reentry': {
            '이전 손실 뒤 재진입': _v1010_metric_summary([r for r in rows if r.get('loss_reentry_prior_loss_v1037') is True]),
            '일반 진입': _v1010_metric_summary([r for r in rows if r.get('loss_reentry_prior_loss_v1037') is not True]),
        },
    }

def _v1040_forward_contract_cohorts(rows: List[Dict[str, Any]]) -> Dict[str, Any]:
    v1038_rows=[r for r in rows if r.get('trailing_exit_enabled_v1038') is True]
    v1038_trailing=[r for r in v1038_rows if str(r.get('exit_reason') or '')=='swing_trailing']
    v1037_prior=[r for r in rows if r.get('loss_reentry_prior_loss_v1037') is True]
    v1037_rebreak=[r for r in v1037_prior if str(r.get('loss_reentry_gate_state_v1037') or '')=='NEW_TRIGGER_REBREAK_CONFIRMED']
    return {
        'v1038_profit_protection_new_closed': _v1010_metric_summary(v1038_rows),
        'v1038_swing_trailing_closed': _v1010_metric_summary(v1038_trailing),
        'v1037_prior_loss_reentry_closed': _v1010_metric_summary(v1037_prior),
        'v1037_new_trigger_rebreak_closed': _v1010_metric_summary(v1037_rebreak),
        'contract': 'forward exact only; no historical recalc or current-value backfill',
    }

def _v1010_perf_diagnostics(rows: List[Dict[str, Any]]) -> Dict[str, Any]:
    """Canonical descriptive diagnostics only. Primary causes are mutually exclusive; auxiliary tags may overlap."""
    losses=[r for r in rows if isinstance(r.get('pnl_pct'),(int,float)) and float(r['pnl_pct'])<=0]
    wins=[r for r in rows if isinstance(r.get('pnl_pct'),(int,float)) and float(r['pnl_pct'])>0]
    positive_mfe_loss=[r for r in losses if isinstance(r.get('mfe_pct'),(int,float)) and float(r['mfe_pct'])>0]
    no_positive_mfe=[r for r in losses if isinstance(r.get('mfe_pct'),(int,float)) and float(r['mfe_pct'])<=0]
    mfe_missing=[r for r in losses if not isinstance(r.get('mfe_pct'),(int,float))]
    target_wins=[r for r in wins if str(r.get('exit_reason') or '')=='structure_target']
    hold_groups={'10분 이하':[],'10~60분':[],'60분 초과':[],'미기록':[]}
    for row in rows:
        hold=row.get('hold_sec')
        if not isinstance(hold,(int,float)): hold_groups['미기록'].append(row)
        elif float(hold)<=600: hold_groups['10분 이하'].append(row)
        elif float(hold)<=3600: hold_groups['10~60분'].append(row)
        else: hold_groups['60분 초과'].append(row)
    ticker_counts=Counter(str(r.get('ticker') or '-').upper() for r in rows)
    repeated_names={ticker for ticker,count in ticker_counts.items() if ticker!='-' and count>1}
    repeated_rows=[r for r in rows if str(r.get('ticker') or '-').upper() in repeated_names]
    repeat_top=[{'ticker':ticker,'trades':count} for ticker,count in ticker_counts.most_common(8) if ticker!='-' and count>1]
    market_groups: Dict[str,List[Dict[str,Any]]]=defaultdict(list)
    for row in rows: market_groups[_v1009_perf_market_label(row)].append(row)
    observation=[r for r in rows if bool(r.get('observation_ingress_v988'))]
    normal=[r for r in rows if not bool(r.get('observation_ingress_v988')) and bool(r.get('contract_ok'))]
    outside=[r for r in rows if not bool(r.get('contract_ok'))]
    return {
        'analysis_only':True,'window_rows':len(rows),
        'primary_exit_reason':_v1010_group_metrics(rows,'exit_reason'),
        'by_entry_method':_v1010_group_metrics([r for r in rows if not r.get('observation_ingress_v988')],'entry_method'),
        'auxiliary_loss_tags':{
            'positive_mfe_then_loss':_v1010_metric_summary(positive_mfe_loss),
            'no_positive_mfe':_v1010_metric_summary(no_positive_mfe),
            'mfe_missing':_v1010_metric_summary(mfe_missing),
            'repeated_ticker_entry':_v1010_metric_summary(repeated_rows),
        },
        'winner_patterns':{'target_exit':_v1010_metric_summary(target_wins),'all_wins':_v1010_metric_summary(wins),'display_policy_v1040':'result-only target_exit is not a strategy feature'},
        'pre_entry_feature_groups_v1040':_v1040_pre_entry_feature_groups(rows),
        'forward_contract_cohorts_v1040':_v1040_forward_contract_cohorts(rows),
        'hold_buckets':{k:_v1010_metric_summary(v) for k,v in hold_groups.items()},
        'market_regime':{k:_v1010_metric_summary(v) for k,v in market_groups.items()},
        'contract_classification':{
            'normal_contract':_v1010_metric_summary(normal),'contract_outside':_v1010_metric_summary(outside),'historical_s3_ingress':_v1010_metric_summary(observation),
        },
        'overall_metrics':_v1010_metric_summary(rows),
        'repeat_tickers':{'ticker_count':len(repeat_top),'repeated_trade_rows':len(repeated_rows),'top':repeat_top},
        'counting_contract':{'primary_exit_reason_mutually_exclusive':True,'auxiliary_tags_can_overlap':True,'mfe_missing_separate_from_no_positive_mfe':True},
        'interpretation_contract':'descriptive evidence only; missing remains missing; no gate/stop/target change',
    }

_V1081_PERF_MEMORY_STATS: Dict[str, Any] = {
    'schema':'paper_performance_memory_v1081',
    'streaming_closed_reader':True,
    'previous_and_current_snapshot_overlap':False,
    'trade_rules_changed':False,
    'ledger_contract_changed':False,
    'auto_buy':False,
}

def _v1081_rss_bytes() -> int:
    try:
        for line in Path('/proc/self/status').read_text(encoding='utf-8', errors='ignore').splitlines():
            if line.startswith('VmRSS:'):
                return int(float(line.split()[1])) * 1024
    except Exception:
        pass
    return 0

def _v1081_release_heap(reason: str) -> Dict[str, Any]:
    import gc as _gc
    import ctypes as _ctypes
    before=_v1081_rss_bytes()
    collected=0; trim_result=None; error=''
    try:
        collected=int(_gc.collect())
    except Exception as exc:
        error=f'gc:{type(exc).__name__}:{exc}'
    try:
        libc=_ctypes.CDLL(None)
        trim=getattr(libc,'malloc_trim',None)
        if trim is not None:
            trim.argtypes=[_ctypes.c_size_t]; trim.restype=_ctypes.c_int
            trim_result=int(trim(0))
    except Exception as exc:
        if not error: error=f'trim:{type(exc).__name__}:{exc}'
    after=_v1081_rss_bytes()
    result={'reason':str(reason),'before_rss_bytes':before,'after_rss_bytes':after,'released_rss_bytes':max(0,before-after),'gc_collected':collected,'malloc_trim_result':trim_result,'error':error or None,'ts':time.time()}
    _V1081_PERF_MEMORY_STATS['last_reclaim']=result
    return result

def _v1081_perf_stream_rows(path: Path, stats: Dict[str, int]):
    """Yield only dict rows with the same logical index as the legacy filtered list."""
    stats['raw_ledger_rows']=0; stats['bad_json_rows']=0
    if not path.exists():
        return
    try:
        with path.open('r',encoding='utf-8',errors='ignore') as handle:
            for line in handle:
                if not line.strip():
                    continue
                try:
                    obj=json.loads(line)
                except Exception:
                    stats['bad_json_rows']+=1
                    continue
                if not isinstance(obj,dict):
                    stats['bad_json_rows']+=1
                    continue
                index=stats['raw_ledger_rows']
                stats['raw_ledger_rows']+=1
                yield index,obj
    except Exception:
        stats['bad_json_rows']+=1

def _v987_perf_build_snapshot__L559(base_dir: Path, paper_version: str, build_label: str, now_value: Optional[float]=None) -> Dict[str, Any]:
    nowv = float(now_value or time.time())
    closed_path = base_dir / 'paper_bot_closed.jsonl'
    decision_path = base_dir / 'paper_decision_state_v926.json'
    stream_stats: Dict[str, int] = {'raw_ledger_rows':0,'bad_json_rows':0}
    decision_obj = _v987_perf_read_json(decision_path, {}) or {}
    records = decision_obj.get('records') if isinstance(decision_obj, dict) and isinstance(decision_obj.get('records'), dict) else {}
    closed_decisions: Dict[str, Dict[str, Any]] = {}
    for key, value in records.items():
        if not isinstance(value, dict):
            continue
        clean_key = str(key or value.get('paper_decision_key_v926') or '').strip()
        if clean_key.startswith('decision:'):
            clean_key = clean_key[len('decision:'):].strip()
        if not clean_key or str(value.get('status') or '').upper() != 'CLOSED':
            continue
        closed_decisions[clean_key] = value
    counts = Counter()
    canonical_by_key: Dict[str, Dict[str, Any]] = {}
    duplicate_rows: List[Dict[str, Any]] = []
    excluded_samples: Dict[str, List[Dict[str, Any]]] = defaultdict(list)
    for index, row in _v1081_perf_stream_rows(closed_path, stream_stats):
        if not isinstance(row, dict):
            counts['non_dict_rows'] += 1
            continue
        opened = _v987_perf_open_ts(row)
        if opened <= 0:
            counts['missing_open_ts'] += 1
            if len(excluded_samples['missing_open_ts']) < 5:
                excluded_samples['missing_open_ts'].append({'index': index, 'ticker': _v987_perf_ticker(row)})
            continue
        if opened < _v987_perf_CUTOVER_TS:
            counts['before_cutover'] += 1
            continue
        if _v987_perf_strategy_mode(row) != _v987_perf_STRATEGY_MODE:
            counts['wrong_strategy_mode'] += 1
            continue
        counts['alt_swing_ledger_rows'] += 1
        key = _v987_perf_decision_key(row)
        match_mode = 'decision_key_exact'
        if not key:
            pid = _v987_perf_pos_id(row)
            counts['missing_decision_key'] += 1
            if len(excluded_samples['missing_decision_key']) < 5:
                excluded_samples['missing_decision_key'].append({'index': index, 'ticker': _v987_perf_ticker(row), 'pos_id': pid})
            continue
        decision = closed_decisions.get(key)
        if not isinstance(decision, dict):
            counts['decision_not_closed_or_missing'] += 1
            if len(excluded_samples['decision_not_closed_or_missing']) < 5:
                excluded_samples['decision_not_closed_or_missing'].append({'index': index, 'ticker': _v987_perf_ticker(row), 'decision_key': key})
            continue
        value = _v987_perf_pnl_pct(row)
        if value is None:
            counts['missing_pnl'] += 1
            if len(excluded_samples['missing_pnl']) < 5:
                excluded_samples['missing_pnl'].append({'index': index, 'ticker': _v987_perf_ticker(row), 'decision_key': key})
            continue
        compact = _v987_perf_compact_row(row, key, match_mode)
        if key in canonical_by_key:
            counts['duplicate_closed_rows'] += 1
            if len(duplicate_rows) < 20:
                duplicate_rows.append({'decision_key': key, 'ticker': compact.get('ticker'), 'kept_closed_at': canonical_by_key[key].get('closed_at'), 'duplicate_closed_at': compact.get('closed_at'), 'policy': 'first committed exact ledger row kept'})
            continue
        canonical_by_key[key] = compact
        counts['exact_unique_closed'] += 1
        counts[match_mode] += 1
        del row
    counts['raw_ledger_rows'] = int(stream_stats.get('raw_ledger_rows') or 0)
    counts['bad_json_rows'] = int(stream_stats.get('bad_json_rows') or 0)
    decision_records_count = len(records)
    closed_decision_records_count = len(closed_decisions)
    rows = list(canonical_by_key.values())
    del canonical_by_key, closed_decisions, records, decision_obj
    _v1081_release_heap('decision_membership_maps_released')
    rows.sort(key=lambda r: (float(r.get('closed_at') or 0.0), str(r.get('identity') or '')))
    today_key = datetime.fromtimestamp(nowv, _v987_perf_KST).date()
    yesterday_key = today_key - timedelta(days=1)
    cutoff_3h = nowv - 3 * 3600.0
    cutoff_6h = nowv - 6 * 3600.0
    cutoff_24h = nowv - 24 * 3600.0

    def day_rows(day: Any) -> List[Dict[str, Any]]:
        return [r for r in rows if float(r.get('closed_at') or 0.0) > 0 and datetime.fromtimestamp(float(r['closed_at']), _v987_perf_KST).date() == day]
    today_rows = day_rows(today_key)
    yesterday_rows = day_rows(yesterday_key)
    rows_3h = [r for r in rows if float(r.get('closed_at') or 0.0) >= cutoff_3h]
    rows_6h = [r for r in rows if float(r.get('closed_at') or 0.0) >= cutoff_6h]
    rows_24h = [r for r in rows if float(r.get('closed_at') or 0.0) >= cutoff_24h]
    contract_rows = [r for r in rows if bool(r.get('contract_ok'))]
    outside_rows = [r for r in rows if not bool(r.get('contract_ok'))]
    outside_reason_counts = Counter((str(r.get('exit_reason') or 'missing') for r in outside_rows))
    observation_ingress_rows = [r for r in rows if bool(r.get('observation_ingress_v988'))]
    today_observation_ingress_rows = [r for r in today_rows if bool(r.get('observation_ingress_v988'))]
    counts['historical_observation_ingress_rows_v988'] = len(observation_ingress_rows)
    by_strategy: Dict[str, List[Dict[str, Any]]] = defaultdict(list)
    for row in today_rows:
        if bool(row.get('observation_ingress_v988')):
            continue
        by_strategy[str(row.get('strategy') or _v987_perf_STRATEGY_MODE)].append(row)
    strategy_stats = {name: _v987_perf_stat(group) for name, group in by_strategy.items()}
    diagnostics_24h_v1010 = _v1010_perf_diagnostics(rows_24h)
    diagnostics_today_v1010 = _v1010_perf_diagnostics(today_rows)
    # v989 audit-only cohort: v987 server-proven exact cohort was the first 35 immutable rows.
    # This does not change membership; it only exposes rows appended after that checkpoint.
    baseline_exact_count_v989 = 35
    audit_rows_v989 = rows[baseline_exact_count_v989:] if len(rows) >= baseline_exact_count_v989 else []
    audit_strategy_groups_v989: Dict[str, List[Dict[str, Any]]] = defaultdict(list)
    for audit_row in audit_rows_v989:
        audit_strategy_groups_v989[str(audit_row.get('strategy') or _v987_perf_STRATEGY_MODE)].append(audit_row)
    audit_strategy_stats_v989 = {name: _v987_perf_stat(group) for name, group in audit_strategy_groups_v989.items()}
    audit_observation_rows_v989 = [r for r in audit_rows_v989 if bool(r.get('observation_ingress_v988'))]
    source_stat = closed_path.stat() if closed_path.exists() else None
    source_meta = {'closed_path': closed_path.name, 'closed_size': source_stat.st_size if source_stat else 0, 'closed_mtime_ns': source_stat.st_mtime_ns if source_stat else 0, 'decision_path': decision_path.name, 'decision_records': decision_records_count, 'closed_decision_records': closed_decision_records_count}
    membership_digest = _v987_perf_digest_json([(r.get('identity'), r.get('closed_at'), r.get('pnl_pct'), r.get('exit_reason')) for r in rows])
    source_digest = _v987_perf_digest_json({'source': source_meta, 'counts': dict(counts), 'membership': membership_digest})
    snapshot_id = f'perf-{int(nowv * 1000)}-{source_digest[:12]}'
    return {'schema': _v987_perf_SCHEMA, 'version': paper_version, 'build': build_label, 'snapshot_id': snapshot_id, 'generated_at': nowv, 'generated_at_text': datetime.fromtimestamp(nowv, _v987_perf_KST).strftime('%Y-%m-%d %H:%M:%S KST'), 'source_owner': 'paper_bot_single_canonical_performance_writer', 'source_policy': 'paper_bot_closed.jsonl only; decision state CLOSED required; decision-key dedupe; no alert-recovery performance rows; no reader-side recomputation', 'strategy_mode': _v987_perf_STRATEGY_MODE, 'cutover_ts': _v987_perf_CUTOVER_TS, 'membership_policy': 'OPEN-time ALT_SWING_V977 + CLOSED decision exact + first committed unique decision row', 'source_meta': source_meta, 'source_digest': source_digest, 'membership_digest': membership_digest, 'counts': dict(counts), 'excluded_samples': dict(excluded_samples), 'duplicate_samples': duplicate_rows, 'windows': {'all': _v987_perf_stat(rows), 'today': _v987_perf_stat(today_rows), 'yesterday': _v987_perf_stat(yesterday_rows), 'recent_3h': _v987_perf_stat(rows_3h), 'recent_6h': _v987_perf_stat(rows_6h), 'recent_24h': _v987_perf_stat(rows_24h)}, 'window_counts': {'all': len(rows), 'today': len(today_rows), 'yesterday': len(yesterday_rows), 'recent_3h': len(rows_3h), 'recent_6h': len(rows_6h), 'recent_24h': len(rows_24h)}, 'current_exit_contract': {'analysis_only': True, 'allowed_exit_reasons': sorted(_v987_perf_ALLOWED_EXIT_REASONS), 'contract_ok_rows': len(contract_rows), 'contract_outside_rows': len(outside_rows), 'outside_reason_counts': dict(outside_reason_counts), 'stats': _v987_perf_stat(contract_rows)}, 'today_strategy_stats': strategy_stats, 'diagnostics_v1010': {'recent_24h': diagnostics_24h_v1010, 'today': diagnostics_today_v1010}, 'historical_observation_ingress_v988': {'analysis_only': True, 'all_rows': len(observation_ingress_rows), 'today_rows': len(today_observation_ingress_rows), 'all_stats': _v987_perf_stat(observation_ingress_rows), 'today_stats': _v987_perf_stat(today_observation_ingress_rows), 'policy': 'historical exact rows remain in representative performance; excluded only from current trade-strategy breakdown'}, 'v989_exact_audit_since_v987_35': {'analysis_only': True, 'baseline_exact_count': baseline_exact_count_v989, 'current_exact_count': len(rows), 'added_rows': len(audit_rows_v989), 'stats': _v987_perf_stat(audit_rows_v989), 'strategy_stats': audit_strategy_stats_v989, 'observation_ingress_rows': len(audit_observation_rows_v989), 'rows': audit_rows_v989, 'policy': 'first 35 exact rows were server-proven v987 cohort; later immutable decision-key rows are audit-only and do not alter canonical membership'}, 'recent_rows': rows[-20:], 'rows': rows, 'invariants': {'single_source_ledger': True, 'single_writer': True, 'decision_closed_required': True, 'dedupe_by_decision_key': True, 'public_readers_recompute': False, 'raw_ledger_preserved': True, 'window_change_causes': ['new exact CLOSED', '24h/day boundary movement']}}

def _v987_perf_score_mirror(snapshot: Dict[str, Any]) -> Dict[str, Any]:
    """Compact compatibility mirror; the canonical snapshot is stored once only."""
    windows = snapshot.get('windows') if isinstance(snapshot.get('windows'), dict) else {}
    counts = snapshot.get('counts') if isinstance(snapshot.get('counts'), dict) else {}
    return {'schema': 'paper_score_cache_v1012_canonical_reference', 'version': snapshot.get('version'), 'build': snapshot.get('build'), 'snapshot_id': snapshot.get('snapshot_id'), 'source_owner': snapshot.get('source_owner'), 'source_digest': snapshot.get('source_digest'), 'membership_digest':snapshot.get('membership_digest'), 'updated_at': snapshot.get('generated_at'), 'updated_at_text': snapshot.get('generated_at_text'), 'score_scope': 'canonical_alt_swing_exact_unique_closed_v987', 'current_closed_count': counts.get('exact_unique_closed', 0), 'closed_count': counts.get('exact_unique_closed', 0), 'raw_closed_count_all': counts.get('raw_ledger_rows', 0), 'today_closed_count': (snapshot.get('window_counts') or {}).get('today', 0), 'review_today_closed_count': (snapshot.get('window_counts') or {}).get('today', 0), 'today_global_stats': windows.get('today', {}), 'yesterday_global_stats': windows.get('yesterday', {}), 'recent_3h_stats': windows.get('recent_3h', {}), 'recent_6h_stats': windows.get('recent_6h', {}), 'recent_24h_stats': windows.get('recent_24h', {}), 'today_strategy_stats': snapshot.get('today_strategy_stats', {}), 'recent_closed_source_trace': snapshot.get('recent_rows', []), 'canonical_snapshot_path':'canonical_performance_snapshot_v987.json', 'mirror_only': True, 'nested_canonical_snapshot':False}

def _v987_perf_review_mirror(snapshot: Dict[str, Any]) -> Dict[str, Any]:
    """Compact review reference; do not duplicate the full canonical rows list."""
    return {'schema': 'paper_trade_review_v1012_canonical_reference', 'version': snapshot.get('version'), 'build': snapshot.get('build'), 'snapshot_id': snapshot.get('snapshot_id'), 'source_owner': snapshot.get('source_owner'), 'source_digest':snapshot.get('source_digest'), 'membership_digest':snapshot.get('membership_digest'), 'updated_at': snapshot.get('generated_at'), 'updated_at_text': snapshot.get('generated_at_text'), 'closed_count': (snapshot.get('counts') or {}).get('exact_unique_closed', 0), 'today_closed_count': (snapshot.get('window_counts') or {}).get('today', 0), 'recent_rows':snapshot.get('recent_rows',[]), 'diagnostics_v1010':snapshot.get('diagnostics_v1010',{}), 'canonical_snapshot_path':'canonical_performance_snapshot_v987.json', 'mirror_only': True, 'nested_canonical_snapshot':False}

PERFORMANCE_SNAPSHOT_V987 = BASE_DIR / 'canonical_performance_snapshot_v987.json'

_PERFORMANCE_WRITER_OWNER = 'paper_bot_single_canonical_performance_writer'

_PERFORMANCE_LAST_SIGNATURE: Optional[Tuple[Any, ...]] = None

_PERFORMANCE_WRITE_COUNT = 0

_PERFORMANCE_LAST_WRITE_AT = 0.0

_PERFORMANCE_NEXT_BOUNDARY_TS = 0.0

def _canonical_performance_next_boundary(snapshot: Dict[str, Any], nowv: float) -> float:
    candidates: List[float] = []
    rows=snapshot.get('rows') if isinstance(snapshot,dict) and isinstance(snapshot.get('rows'),list) else []
    for row in rows:
        if not isinstance(row,dict): continue
        closed=_v987_perf_num(row.get('closed_at'),default=None)
        if closed is None: continue
        for sec in (3*3600.0,6*3600.0,24*3600.0):
            boundary=float(closed)+sec
            if boundary>nowv: candidates.append(boundary)
    local=datetime.fromtimestamp(nowv,_v987_perf_KST)
    next_midnight=datetime.combine(local.date()+timedelta(days=1),datetime.min.time(),tzinfo=_v987_perf_KST).timestamp()
    candidates.append(next_midnight)
    return min(candidates) if candidates else next_midnight

DEFAULT_CONTROL: Dict[str, Any] = {
    "running": True,
    "loop_seconds": 8,
    "open_monitor_interval_sec": 2.0,
    "max_open_strict": 0,
    "max_new_per_cycle": 0,
    "new_open_paused": False,
    "open_trade_ready_only": True,
    "notify_on_strict_open": True,
    "notify_on_strict_close": True,
    "notify_on_s1_decision_summary": True,
    "notify_s1_decision_summary_interval_sec": 3600,
    "notify_s1_decision_summary_min_interval_sec": 3600,  # backward compat
    "notify_open_min_score": 4.45,
    "notify_open_require_micro_fresh": False,
    "notify_open_require_ws_fresh": False,
    "preopen_micro_recheck": False,
    "preopen_micro_urgent_ttl_sec": 35,
    "paper_final_reaction_proof_enabled": False,
    "paper_final_reaction_proof_mode": "recheck_hold",
    "paper_final_reaction_proof_min_windows": 2,
    "paper_final_reaction_proof_min_flow_pct": 0.01,
    "block_same_ticker_open": True,
    "candidate_ttl_sec": 0,
    "candidate_read_max_lines": 800,
    "consume_latest_scan_only": True,
    "write_score_cache": True,
    "latest_scan_window_sec": 8,
    "fee_pct_roundtrip": 0.10,
    "take_profit_pct": 1.20,
    "protect_trigger_pct": 0.70,
    "protect_floor_pct": 0.35,
    "protect_strong_trigger_pct": 1.00,
    "protect_strong_floor_pct": 0.50,
    "protect_big_trigger_pct": 1.40,
    "protect_big_floor_pct": 0.75,
    "protect_giveback_pct": 0.55,
    "stop_loss_pct": -0.55,
    "fast_fail_after_min": 2.5,
    "fast_fail_peak_under_pct": 0.20,
    "fast_fail_loss_pct": -0.35,
    "fast_fail_after_min_late": 5.0,
    "fast_fail_loss_pct_late": -0.25,
    "slow_minutes": 20,
    "slow_peak_under_pct": 0.25,
    "time_exit_minutes": 0,  # v977: fixed 15m exit removed
    "swing_emergency_stop_pct": -2.50,
    "swing_no_progress_minutes": 360,
    "swing_no_progress_peak_under_pct": 0.35,
    "swing_no_progress_net_under_pct": 0.00,
    "swing_max_weak_hold_minutes": 4320,
    "swing_max_weak_peak_under_pct": 1.00,
    "swing_max_weak_net_under_pct": 0.25,
    # v1038: v977 active profit-protection contract restored for NEW OPEN only.
    "swing_trailing_trigger_pct": 2.00,
    "swing_trailing_giveback_pct": 0.80,
    # v486: 손실은 빠르게, 수익권은 조건부로 길게 본다.
    "profit_soft_protect_trigger_pct": 0.45,
    "profit_soft_protect_floor_pct": 0.10,
    "profit_soft_protect_giveback_pct": 0.45,
    "profit_run_extend_enabled": True,
    "profit_run_extend_minutes": 15,
    "profit_run_extend_max_count": 1,
    "profit_run_extend_min_net_pct": 0.20,
    "profit_run_extend_min_peak_pct": 0.25,
    "profit_run_extend_max_giveback_pct": 0.25,
    "profit_run_strategy_keywords": ["주도", "유동보유", "leader", "momentum"],
    "notify_market_hot_alert": True,
    "notify_market_hot_immediate_enabled": False,
    "notify_market_hot_summary_interval_sec": 3600,
    "notify_market_hot_immediate_min_interval_sec": 3600,  # backward compat
    "notify_market_hot_global_min_interval_sec": 3600,
    "notify_market_hot_ticker_cooldown_sec": 3600,
    "notify_market_hot_1m_pct": 0.80,
    "notify_market_hot_3m_pct": 1.50,
    "notify_market_hot_immediate_1m_pct": 1.50,
    "notify_market_hot_immediate_3m_pct": 2.50,
    "notify_market_hot_rank_top_n": 5,
    "notify_market_hot_max_items": 4,
    "notify_market_hot_cache_ttl_sec": 90,
    "notify_entry_timing_trace": True,
}

TOKEN = os.getenv("PAPER_BOT_TOKEN", os.getenv("TELEGRAM_TOKEN", "")).strip()

ALLOWED_CHAT_ID = (
    os.getenv("PAPER_BOT_ALLOWED_CHAT_ID", "").strip()
    or os.getenv("PAPER_BOT_CHAT_ID", "").strip()
    or os.getenv("CHAT_ID", "").strip()
    or os.getenv("GUARD_CHAT_ID", "").strip()
)

NOTIFY_CHAT_ID = os.getenv("PAPER_BOT_NOTIFY_CHAT_ID", "").strip() or ALLOWED_CHAT_ID

_STOP = False

_STOP_REASON = "running"

_LAST_PRICE_CACHE: Dict[str, Any] = {"ts": 0.0, "prices": {}}

V1079_ORDERFLOW_CACHE = BASE_DIR / "clean_orderflow_summary_cache.json"

_V1079_ENTRY_PRICE_CACHE: Dict[str, Any] = {"signature": None, "rows": {}, "updated_ts": 0.0}

_V1079_ENTRY_PRICE_LOCAL_HITS = 0

_V1079_ENTRY_PRICE_REST_FALLBACKS = 0

_V1079_ENTRY_PRICE_CACHE_READS = 0

_V1079_ENTRY_PRICE_CACHE_ERRORS = 0

_V1079_ENTRY_PRICE_LAST_SOURCE = "-"

_V1079_ENTRY_PRICE_LAST_AGE_SEC: Optional[float] = None

_LAST_STATUS: Dict[str, Any] = {}

_LAST_CLOSED_COUNT_CACHE: Dict[str, Any] = {"ts": 0.0, "count": 0}

_TG_OFFSET = 0

_S1_DECISION_SUMMARY_BUCKET: Dict[str, Any] = {}

_HOT_MARKET_NOTIFY_BUCKET: Dict[str, Any] = {}

def now_ts() -> float:
    return time.time()

def _kst_datetime(ts: Optional[float] = None):
    import datetime as _dt
    return _dt.datetime.fromtimestamp(ts or now_ts(), tz=_dt.timezone(_dt.timedelta(hours=9)))

def _kst_day_key(ts: Optional[float] = None) -> str:
    return _kst_datetime(ts).strftime("%Y-%m-%d")

def iso_ts(ts: Optional[float] = None) -> str:
    return _kst_datetime(ts).strftime("%Y-%m-%d %H:%M:%S KST")

def fnum(*vals: Any, default: float = 0.0) -> float:
    for v in vals:
        try:
            if v is None or v == "":
                continue
            if isinstance(v, str):
                v = v.replace(",", "").replace("%", "").strip()
            return float(v)
        except Exception:
            continue
    return default

def log(msg: str) -> None:
    try:
        with FILES["log"].open("a", encoding="utf-8") as f:
            f.write(f"[{iso_ts()}] {msg}\n")
    except Exception:
        pass

def log_error(where: str, exc: BaseException) -> None:
    try:
        with FILES["error"].open("a", encoding="utf-8") as f:
            f.write(f"[{iso_ts()}] {where}: {type(exc).__name__}: {exc}\n")
            f.write(traceback.format_exc() + "\n")
    except Exception:
        pass

def atomic_write_text(path: Path, text: str) -> None:
    tmp = path.with_suffix(path.suffix + ".tmp")
    tmp.write_text(text, encoding="utf-8")
    os.replace(tmp, path)

def save_json(path: Path, obj: Any) -> None:
    try:
        atomic_write_text(path, json.dumps(obj, ensure_ascii=False, separators=(",", ":")))
    except Exception as exc:
        log_error(f"save_json:{path.name}", exc)

def load_json(path: Path, default: Any = None) -> Any:
    try:
        if not path.exists():
            return default
        return json.loads(path.read_text(encoding="utf-8", errors="ignore"))
    except Exception as exc:
        log_error(f"load_json:{path.name}", exc)
        return default

def append_jsonl__L959(path: Path, obj: Dict[str, Any]) -> None:
    try:
        with path.open("a", encoding="utf-8") as f:
            f.write(json.dumps(obj, ensure_ascii=False, separators=(",", ":")) + "\n")
    except Exception as exc:
        log_error(f"append_jsonl:{path.name}", exc)

def tail_lines(path: Path, max_lines: int) -> List[str]:
    """Read only the requested JSONL tail; never scan a growing ledger from byte zero."""
    if not path.exists() or max_lines <= 0:
        return []
    try:
        with path.open("rb") as f:
            f.seek(0, os.SEEK_END)
            pos = f.tell()
            pending = b""
            reversed_lines: List[bytes] = []
            while pos > 0 and len(reversed_lines) < max_lines:
                take = min(1024 * 1024, pos)
                pos -= take
                f.seek(pos)
                pending = f.read(take) + pending
                parts = pending.split(b"\n")
                pending = parts[0]
                for raw in reversed(parts[1:]):
                    if raw.strip():
                        reversed_lines.append(raw)
                        if len(reversed_lines) >= max_lines:
                            break
            if pos == 0 and pending.strip() and len(reversed_lines) < max_lines:
                reversed_lines.append(pending)
        return [raw.decode("utf-8", errors="ignore") for raw in reversed(reversed_lines[:max_lines])]
    except Exception as exc:
        log_error(f"tail_lines:{path.name}", exc)
        return []

def read_jsonl_tail(path: Path, max_lines: int) -> List[Dict[str, Any]]:
    out: List[Dict[str, Any]] = []
    for line in tail_lines(path, max_lines):
        try:
            row = json.loads(line)
            if isinstance(row, dict):
                out.append(row)
        except Exception:
            continue
    return out

def line_count_cached(path: Path, ttl: float = 60.0) -> int:
    """Count an append-only ledger once, then count only newly appended bytes."""
    ts = now_ts()
    cache = _LAST_CLOSED_COUNT_CACHE
    try:
        if not path.exists():
            cache.clear(); cache.update({"ts":ts,"count":0,"inode":0,"offset":0,"initialized":True})
            return 0
        st = path.stat(); inode=int(st.st_ino); size=int(st.st_size)
        initialized=bool(cache.get("initialized")) and int(cache.get("inode") or 0)==inode and 0 <= int(cache.get("offset") or 0) <= size
        if initialized and ts-float(cache.get("ts") or 0.0) < ttl and int(cache.get("offset") or 0)==size:
            return int(cache.get("count") or 0)
        offset=int(cache.get("offset") or 0) if initialized else 0
        count=int(cache.get("count") or 0) if initialized else 0
        with path.open("rb") as f:
            f.seek(offset)
            while True:
                block=f.read(1024*1024)
                if not block: break
                count += block.count(b"\n")
            offset=f.tell()
        cache.clear(); cache.update({"ts":ts,"count":count,"inode":inode,"offset":offset,"initialized":True})
        return count
    except Exception as exc:
        log_error(f"line_count_cached:{path.name}", exc)
        return int(cache.get("count") or 0)

def normalize_ticker(v: Any) -> str:
    if v is None:
        return ""
    t = str(v).strip().upper().replace("/", "-").replace("_", "-")
    if not t:
        return ""
    parts = [p for p in t.split("-") if p]
    if len(parts) >= 2:
        non = [p for p in parts if p != "KRW"]
        return (non[-1] if non else parts[-1]).strip().upper()
    if t.endswith("KRW") and len(t) > 3:
        return t[:-3].strip().upper()
    return t

def row_ts(row: Dict[str, Any], *keys: str) -> float:
    for k in keys:
        v = row.get(k)
        x = fnum(v, default=0.0)
        if x > 1000000000:
            return x
        if isinstance(v, str) and v:
            try:
                import datetime as _dt
                return _dt.datetime.fromisoformat(v.replace("Z", "+00:00")).timestamp()
            except Exception:
                pass
    return 0.0

def event_created_ts(row: Dict[str, Any]) -> float:
    return row_ts(row, "created_at", "candidate_created_at", "source_created_at", "detected_ts", "event_ts", "ts", "timestamp")

def load_control() -> Dict[str, Any]:
    saved = load_json(FILES["control"], {})
    ctrl = dict(DEFAULT_CONTROL)
    if isinstance(saved, dict):
        ctrl.update(saved)
    # v1174 raw Paper intake: later safety layers are disabled as entry blockers.
    # The prior configured values are kept only as audit evidence.
    configured_v1174 = {
        "max_open_strict": int(fnum(ctrl.get("max_open_strict"), default=0)),
        "max_new_per_cycle": int(fnum(ctrl.get("max_new_per_cycle"), default=0)),
        "candidate_ttl_sec": fnum(ctrl.get("candidate_ttl_sec"), default=0.0),
        "preopen_micro_recheck": bool(ctrl.get("preopen_micro_recheck", False)),
        "notify_open_require_micro_fresh": bool(ctrl.get("notify_open_require_micro_fresh", False)),
        "notify_open_require_ws_fresh": bool(ctrl.get("notify_open_require_ws_fresh", False)),
        "paper_final_reaction_proof_enabled": bool(ctrl.get("paper_final_reaction_proof_enabled", False)),
        "new_open_paused": bool(ctrl.get("new_open_paused", False)),
    }
    ctrl["max_open_strict"] = 0
    ctrl["max_new_per_cycle"] = 0
    ctrl["candidate_ttl_sec"] = 0
    ctrl["preopen_micro_recheck"] = False
    ctrl["notify_open_require_micro_fresh"] = False
    ctrl["notify_open_require_ws_fresh"] = False
    ctrl["paper_final_reaction_proof_enabled"] = False
    ctrl["new_open_paused"] = False
    ctrl["paper_raw_intake_v1174"] = True
    ctrl["quality_rebuild_limit_contract_v1095"] = {
        "schema": "paper_raw_intake_contract_v1174",
        "state": "RAW_PAPER_NO_LATE_SAFETY_BLOCKS",
        "max_open_strict": 0,
        "max_new_per_cycle": 0,
        "candidate_ttl_sec": 0,
        "configured_before_override": configured_v1174,
        "kept_integrity_guards": ["S1 exact decision", "position/decision duplicate", "same ticker duplicate", "OPEN/CLOSED commit"],
        "owner": "paper_bot.load_control",
        "auto_buy": False,
    }
    # v400: paper 실행기는 기본 ON. 사용자가 명시적으로 running=false로 저장한 경우만 정지한다.
    if "running" not in ctrl:
        ctrl["running"] = True
    return ctrl

def write_pid() -> None:
    try:
        FILES["pid"].write_text(str(os.getpid()), encoding="utf-8")
    except Exception:
        pass

def _v740_open_pos_key(row: Dict[str, Any], idx: int) -> str:
    for k in ("pos_id", "position_id", "event_id", "id", "hold_key"):
        v = str(row.get(k) or "").strip()
        if v:
            return v
    t = normalize_ticker(row.get("ticker") or row.get("market") or row.get("symbol"))
    ts = str(row.get("opened_ts") or row.get("entry_ts") or row.get("created_at") or row.get("ts") or idx)
    return f"{t or 'malformed'}:{ts}:{idx}"

def _v740_normalize_open_obj(obj: Any) -> Dict[str, Dict[str, Any]]:
    out: Dict[str, Dict[str, Any]] = {}
    if isinstance(obj, dict):
        list_rows = None
        for k in ("rows", "positions", "open", "OPEN"):
            if isinstance(obj.get(k), list):
                list_rows = obj.get(k)
                break
        if isinstance(list_rows, list):
            for i, row in enumerate(list_rows):
                if isinstance(row, dict):
                    out[_v740_open_pos_key(row, i)] = dict(row)
            return out
        for k, row in obj.items():
            if isinstance(row, dict):
                rr = dict(row)
                rr.setdefault("pos_id", str(k))
                out[str(k)] = rr
        return out
    if isinstance(obj, list):
        for i, row in enumerate(obj):
            if isinstance(row, dict):
                out[_v740_open_pos_key(row, i)] = dict(row)
    return out

def load_open__L1129() -> Dict[str, Dict[str, Any]]:
    obj = load_json(FILES["open"], {})
    return _v740_normalize_open_obj(obj)

def open_tickers(open_pos: Dict[str, Dict[str, Any]]) -> set[str]:
    return {normalize_ticker(p.get("ticker")) for p in open_pos.values() if isinstance(p, dict) and normalize_ticker(p.get("ticker"))}

def _v734_is_malformed_open(pos: Dict[str, Any]) -> bool:
    if not isinstance(pos, dict):
        return True
    t = normalize_ticker(pos.get("ticker") or pos.get("market") or pos.get("symbol"))
    price = fnum(pos.get("entry_price"), pos.get("entry"), default=0.0)
    return (not t) or price <= 0

def _v734_is_legacy_experiment_open(pos: Dict[str, Any]) -> bool:
    if not isinstance(pos, dict):
        return False
    if str(pos.get("paper_experiment_lane") or "") == FAST_EXPERIMENT_LANE_V669:
        return True
    diag = pos.get("entry_diagnostics") if isinstance(pos.get("entry_diagnostics"), dict) else {}
    hay = " ".join(str(pos.get(k) or "") for k in ("strategy_key", "strategy_label", "strategy", "lane", "entry_reason", "paper_entry_action"))
    if isinstance(diag, dict):
        hay += " " + " ".join(str(diag.get(k) or "") for k in ("strategy_key", "strategy_label", "strategy", "lane"))
    return ("fast_quality_paper" in hay) or ("고품질 빠른진입 paper 실험" in hay)

def _v734_strict_open_count(open_pos: Dict[str, Dict[str, Any]]) -> int:
    """S1 hold 신규 OPEN 상한에는 정상 strict OPEN만 계산한다.

    구 실험 잔여와 malformed row는 장부에는 보존하지만, 새 정식 S1 진입을 막는 strict OPEN으로 보지 않는다.
    """
    n = 0
    for pos in (open_pos or {}).values():
        if not isinstance(pos, dict):
            continue
        if _v734_is_malformed_open(pos) or _v734_is_legacy_experiment_open(pos):
            continue
        n += 1
    return n

def _v734_hold_status(ev: Dict[str, Any]) -> str:
    return str(ev.get("s1_hold_status_v738") or ev.get("s1_hold_status_v737") or ev.get("s1_hold_status_v736") or ev.get("s1_hold_status_v735") or ev.get("s1_hold_status_v734") or ev.get("s1_hold_status_v732") or "")

def _v734_is_hold(ev: Dict[str, Any]) -> bool:
    return bool(ev.get("s1_hold_v738") or ev.get("s1_hold_v737") or ev.get("s1_hold_v736") or ev.get("s1_hold_v735") or ev.get("s1_hold_v734") or ev.get("s1_hold_v732"))

def _v734_trace_hold(ev: Dict[str, Any], status: str, reason: Any = None, extra: Optional[Dict[str, Any]] = None) -> None:
    try:
        obj = {
            "ts": now_ts(),
            "ticker": normalize_ticker(ev.get("ticker") or ev.get("market") or ev.get("symbol")),
            "status": status,
            "reason": reason if reason not in (None, "", []) else "-",
            "event_id": event_id(ev, "strict"),
            "hold_status": _v734_hold_status(ev),
            "open_ready": bool(ev.get("s1_hold_open_ready_v738") or ev.get("s1_hold_open_ready_v737") or ev.get("s1_hold_open_ready_v736") or ev.get("s1_hold_open_ready_v735") or ev.get("s1_hold_open_ready_v734") or ev.get("s1_hold_open_ready_v732")),
            "paper_version": VERSION,
        }
        if isinstance(extra, dict):
            obj.update(extra)
        append_jsonl(FILES.get("s1_hold_trace", BASE_DIR / "paper_s1_hold_consume_trace.jsonl"), obj)
    except Exception as exc:
        log_error("v734_trace_hold", exc)

_V1085_CLOSED_RECENT_CACHE: Dict[str, Any] = {
    "inode": 0,
    "offset": 0,
    "size": 0,
    "limit": 0,
    "rows": deque(),
    "id_counts": Counter(),
    "initialized": False,
}

_V1085_CLOSED_RECENT_STATS: Dict[str, Any] = {
    "schema": "paper_closed_recent_id_stream_index_v1085",
    "initial_tail_scans": 0,
    "incremental_scans": 0,
    "cache_hits": 0,
    "rows_examined": 0,
    "parse_errors": 0,
    "bytes_read": 0,
    "last_bytes_read": 0,
    "last_rows_examined": 0,
    "last_duration_sec": 0.0,
    "last_mode": "not_started",
    "full_row_list_materialized": False,
}

def _v1085_reverse_tail_raw_lines(path: Path, max_lines: int, chunk_size: int = 1024 * 1024):
    """Yield at most max_lines non-empty raw lines newest->oldest without holding the tail list."""
    if max_lines <= 0:
        return
    with path.open("rb") as handle:
        handle.seek(0, os.SEEK_END)
        pos = handle.tell()
        pending = b""
        yielded = 0
        while pos > 0 and yielded < max_lines:
            take = min(chunk_size, pos)
            pos -= take
            handle.seek(pos)
            pending = handle.read(take) + pending
            parts = pending.split(b"\n")
            pending = parts[0]
            for raw in reversed(parts[1:]):
                if not raw.strip():
                    continue
                yield raw
                yielded += 1
                if yielded >= max_lines:
                    return
        if pos == 0 and pending.strip() and yielded < max_lines:
            yield pending

def _v1085_closed_ids_from_raw(raw: bytes) -> Tuple[str, ...]:
    try:
        row = json.loads(raw)
    except Exception:
        _V1085_CLOSED_RECENT_STATS["parse_errors"] = int(_V1085_CLOSED_RECENT_STATS.get("parse_errors") or 0) + 1
        return tuple()
    if not isinstance(row, dict):
        return tuple()
    vals: List[str] = []
    for key in ("pos_id", "event_id", "trace_id", "handoff_id", "candidate_uid"):
        value = str(row.get(key) or "").strip()
        if value and value not in vals:
            vals.append(value)
    return tuple(vals)

def _v1085_closed_index_push(ids: Tuple[str, ...], limit: int) -> None:
    rows = _V1085_CLOSED_RECENT_CACHE["rows"]
    counts = _V1085_CLOSED_RECENT_CACHE["id_counts"]
    rows.append(ids)
    for value in ids:
        counts[value] += 1
    while len(rows) > limit:
        expired = rows.popleft()
        for value in expired:
            counts[value] -= 1
            if counts[value] <= 0:
                counts.pop(value, None)

def _v1085_closed_index_rebuild(path: Path, limit: int, inode: int, size: int) -> None:
    started = time.monotonic()
    rows = deque()
    counts = Counter()
    examined = 0
    bytes_read = 0
    for raw in _v1085_reverse_tail_raw_lines(path, limit):
        examined += 1
        bytes_read += len(raw)
        ids = _v1085_closed_ids_from_raw(raw)
        rows.appendleft(ids)
        for value in ids:
            counts[value] += 1
    cache = _V1085_CLOSED_RECENT_CACHE
    cache.clear()
    cache.update({
        "inode": inode,
        "offset": size,
        "size": size,
        "limit": limit,
        "rows": rows,
        "id_counts": counts,
        "initialized": True,
    })
    stats = _V1085_CLOSED_RECENT_STATS
    stats["initial_tail_scans"] = int(stats.get("initial_tail_scans") or 0) + 1
    stats["rows_examined"] = int(stats.get("rows_examined") or 0) + examined
    stats["bytes_read"] = int(stats.get("bytes_read") or 0) + bytes_read
    stats["last_rows_examined"] = examined
    stats["last_bytes_read"] = bytes_read
    stats["last_duration_sec"] = round(time.monotonic() - started, 6)
    stats["last_mode"] = "reverse_tail_rebuild"

def _v1085_closed_index_append(path: Path, limit: int, inode: int, size: int) -> None:
    started = time.monotonic()
    cache = _V1085_CLOSED_RECENT_CACHE
    offset = int(cache.get("offset") or 0)
    examined = 0
    bytes_read = 0
    with path.open("rb") as handle:
        handle.seek(offset)
        while True:
            line_start = handle.tell()
            raw = handle.readline()
            if not raw:
                break
            # Do not consume an incomplete append. The next call will retry it.
            if not raw.endswith(b"\n"):
                handle.seek(line_start)
                break
            offset = handle.tell()
            if not raw.strip():
                continue
            examined += 1
            bytes_read += len(raw)
            _v1085_closed_index_push(_v1085_closed_ids_from_raw(raw.rstrip(b"\n")), limit)
    cache.update({"inode": inode, "offset": offset, "size": size, "limit": limit, "initialized": True})
    stats = _V1085_CLOSED_RECENT_STATS
    stats["incremental_scans"] = int(stats.get("incremental_scans") or 0) + 1
    stats["rows_examined"] = int(stats.get("rows_examined") or 0) + examined
    stats["bytes_read"] = int(stats.get("bytes_read") or 0) + bytes_read
    stats["last_rows_examined"] = examined
    stats["last_bytes_read"] = bytes_read
    stats["last_duration_sec"] = round(time.monotonic() - started, 6)
    stats["last_mode"] = "append_only_incremental"

def closed_recent_ids(limit: int = 2000) -> set[str]:
    """Return IDs from the last N CLOSED lines without materializing CLOSED rows.

    Startup reads only the last N raw lines one at a time. Later calls consume only
    newly appended bytes. Truncation/inode replacement rebuilds the bounded tail.
    """
    path = FILES["closed"]
    limit = max(1, int(limit or 2000))
    try:
        st = path.stat()
        inode, size = int(st.st_ino), int(st.st_size)
    except OSError:
        _V1085_CLOSED_RECENT_CACHE.update({"inode": 0, "offset": 0, "size": 0, "limit": limit, "rows": deque(), "id_counts": Counter(), "initialized": True})
        return set()
    cache = _V1085_CLOSED_RECENT_CACHE
    rebuild = bool(
        not cache.get("initialized")
        or int(cache.get("inode") or 0) != inode
        or int(cache.get("limit") or 0) != limit
        or size < int(cache.get("offset") or 0)
    )
    if rebuild:
        _v1085_closed_index_rebuild(path, limit, inode, size)
    elif size > int(cache.get("offset") or 0):
        _v1085_closed_index_append(path, limit, inode, size)
    else:
        _V1085_CLOSED_RECENT_STATS["cache_hits"] = int(_V1085_CLOSED_RECENT_STATS.get("cache_hits") or 0) + 1
        _V1085_CLOSED_RECENT_STATS["last_mode"] = "cache_hit"
        _V1085_CLOSED_RECENT_STATS["last_rows_examined"] = 0
        _V1085_CLOSED_RECENT_STATS["last_bytes_read"] = 0
        _V1085_CLOSED_RECENT_STATS["last_duration_sec"] = 0.0
    counts = cache.get("id_counts")
    return set(counts.keys()) if isinstance(counts, Counter) else set()

def event_id(ev: Dict[str, Any], lane: str = "strict") -> str:
    for k in ("event_id", "event_key", "trace_id", "handoff_id", "candidate_uid", "id"):
        v = str(ev.get(k) or "").strip()
        if v:
            return v
    t = normalize_ticker(ev.get("ticker") or ev.get("market") or ev.get("symbol")) or "UNKNOWN"
    scan = str(ev.get("scan_id") or ev.get("source_scan_id") or ev.get("strategy_scan_id") or "")[:40]
    created = int(event_created_ts(ev) or now_ts())
    score = fnum(ev.get("score"), ev.get("leader_score"), default=0.0)
    return f"{lane}:{t}:{scan}:{created}:{score:.3f}"

def candidate_brief(ev: Dict[str, Any], status: str = "", reason: str = "") -> Dict[str, Any]:
    """paper handoff 상태판용 짧은 후보 요약.

    OPEN 여부를 바꾸지 않고, S1이 paper까지 왔는지/왜 막혔는지만 남긴다.
    """
    try:
        ctx = ev.get("entry_context") if isinstance(ev.get("entry_context"), dict) else {}
        diag = ev.get("paper_final_safety_diagnostics") if isinstance(ev.get("paper_final_safety_diagnostics"), dict) else build_entry_diagnostics(ev, ctx)
    except Exception:
        diag = {}
    return {
        "ticker": normalize_ticker(ev.get("ticker") or ev.get("market") or ev.get("symbol")),
        "event_id": event_id(ev, "strict"),
        "stage": ev.get("s_stage") or ev.get("candidate_stage") or ev.get("stage") or ev.get("candidate_grade") or ev.get("grade"),
        "strategy": ev.get("strategy_label") or ev.get("strategy_key") or ev.get("strategy") or ev.get("route"),
        "score": fnum(ev.get("score"), ev.get("leader_score"), default=0.0),
        "status": status or "seen",
        "reason": reason or "-",
        "created_at": ev.get("created_at") or ev.get("candidate_created_at") or ev.get("source_created_at"),
        "seen_at": now_ts(),
        "seen_at_text": iso_ts(),
        "price_reaction_pct": fnum(diag.get("price_reaction_pct"), default=0.0) if isinstance(diag, dict) else 0.0,
        "spread_pct": fnum(diag.get("spread_pct"), default=-1.0) if isinstance(diag, dict) else -1.0,
        "buy_ratio": fnum(diag.get("buy_ratio"), default=-1.0) if isinstance(diag, dict) else -1.0,
        "buy_sustain_1m": fnum(diag.get("buy_sustain_1m"), default=-1.0) if isinstance(diag, dict) else -1.0,
        "block_reasons": list(ev.get("paper_entry_hold_reasons") or ev.get("paper_final_block_reasons") or [])[:8] if isinstance((ev.get("paper_entry_hold_reasons") or ev.get("paper_final_block_reasons")), list) else [],
    }

def _record_decision(stats: Dict[str, Any], key: str, ev: Dict[str, Any], status: str, reason: str = "") -> None:
    brief = candidate_brief(ev, status=status, reason=reason)
    stats[key] = brief
    rows = stats.get("recent_s1_decisions")
    if not isinstance(rows, list):
        rows = []
    rows.append(brief)
    stats["recent_s1_decisions"] = rows[-12:]

def get_event_price(ev: Dict[str, Any]) -> float:
    for k in ("live_price", "current_price", "price", "trade_price", "close", "last_price", "entry_price", "detected_price"):
        x = fnum(ev.get(k), default=0.0)
        if x > 0:
            return x
    ctx = ev.get("entry_context") if isinstance(ev.get("entry_context"), dict) else {}
    for k in ("live_price", "current_price", "price", "close"):
        x = fnum(ctx.get(k), default=0.0)
        if x > 0:
            return x
    return 0.0

def fetch_all_prices_cached(ttl: float = 4.0) -> Dict[str, float]:
    ts = now_ts()
    if ts - float(_LAST_PRICE_CACHE.get("ts") or 0.0) < ttl:
        # v1051: this mapping is paper-owned and the only consumer is read-only live_price().
        # Returning a 460-ticker copy once per OPEN caused O(open*tickers) allocations every sweep.
        prices = _LAST_PRICE_CACHE.get("prices")
        return prices if isinstance(prices, dict) else {}
    prices: Dict[str, float] = {}
    try:
        req = urllib.request.Request(
            "https://api.bithumb.com/public/ticker/ALL_KRW",
            headers={"Accept": "application/json", "User-Agent": VERSION},
        )
        with urllib.request.urlopen(req, timeout=4) as resp:
            data = json.loads(resp.read().decode("utf-8", errors="ignore"))
        raw = data.get("data") if isinstance(data, dict) else {}
        if isinstance(raw, dict):
            for k, v in raw.items():
                if not isinstance(v, dict):
                    continue
                t = normalize_ticker(k)
                p = fnum(v.get("closing_price"), v.get("close"), default=0.0)
                if t and p > 0:
                    prices[t] = p
    except Exception as exc:
        log_error("fetch_all_prices", exc)
    if prices:
        _LAST_PRICE_CACHE.update({"ts": ts, "prices": prices})
    cached = _LAST_PRICE_CACHE.get("prices")
    return cached if isinstance(cached, dict) else prices

def live_price(ticker: str, fallback: float = 0.0) -> float:
    t = normalize_ticker(ticker)
    prices = fetch_all_prices_cached()
    return float(prices.get(t) or fallback or 0.0)

def _v1079_orderflow_rest_price_map() -> Dict[str, Tuple[float, float]]:
    """Read the canonical Orderflow-published scanner REST price once per file commit.

    Stored values are (price, observed_ts).  The consumer still enforces the
    legacy 4-second freshness window before using the local owner.
    """
    global _V1079_ENTRY_PRICE_CACHE_READS, _V1079_ENTRY_PRICE_CACHE_ERRORS
    path = V1079_ORDERFLOW_CACHE
    try:
        st = path.stat()
        signature = (int(st.st_ino), int(st.st_size), int(st.st_mtime_ns))
    except OSError:
        return {}
    cached = _V1079_ENTRY_PRICE_CACHE
    if cached.get("signature") == signature and isinstance(cached.get("rows"), dict):
        return cached["rows"]
    try:
        obj = load_json(path, {}) or {}
        rows = obj.get("rows") if isinstance(obj, dict) and isinstance(obj.get("rows"), list) else []
        top_ts = fnum(obj.get("updated_ts"), default=0.0) if isinstance(obj, dict) else 0.0
        mapped: Dict[str, Tuple[float, float]] = {}
        for row in rows:
            if not isinstance(row, dict):
                continue
            ticker = normalize_ticker(row.get("ticker") or row.get("market") or row.get("symbol"))
            price = fnum(row.get("rest_price"), default=0.0)
            if not ticker or price <= 0 or row.get("rest_fresh") is not True:
                continue
            age_at_write = fnum(row.get("rest_age_sec"), default=-1.0)
            observed_ts = top_ts - age_at_write if top_ts > 0 and age_at_write >= 0 else 0.0
            if observed_ts <= 0:
                observed_ts = fnum(row.get("rest_ts"), row.get("updated_ts"), default=0.0)
            if observed_ts > 0:
                mapped[ticker] = (price, observed_ts)
        cached.update({"signature": signature, "rows": mapped, "updated_ts": top_ts})
        _V1079_ENTRY_PRICE_CACHE_READS += 1
        return mapped
    except Exception as exc:
        _V1079_ENTRY_PRICE_CACHE_ERRORS += 1
        log_error("v1079_orderflow_entry_price_cache", exc)
        return {}

def _v1079_entry_confirmation_price(ticker: str, fallback: float = 0.0) -> Tuple[float, str, Optional[float]]:
    global _V1079_ENTRY_PRICE_LOCAL_HITS, _V1079_ENTRY_PRICE_REST_FALLBACKS
    global _V1079_ENTRY_PRICE_LAST_SOURCE, _V1079_ENTRY_PRICE_LAST_AGE_SEC
    t = normalize_ticker(ticker)
    item = _v1079_orderflow_rest_price_map().get(t)
    if isinstance(item, tuple) and len(item) == 2:
        price = fnum(item[0], default=0.0)
        observed_ts = fnum(item[1], default=0.0)
        age = max(0.0, now_ts() - observed_ts) if observed_ts > 0 else None
        if price > 0 and age is not None and age <= 4.0:
            _V1079_ENTRY_PRICE_LOCAL_HITS += 1
            _V1079_ENTRY_PRICE_LAST_SOURCE = "orderflow.scanner_rest_price"
            _V1079_ENTRY_PRICE_LAST_AGE_SEC = round(age, 3)
            return price, _V1079_ENTRY_PRICE_LAST_SOURCE, _V1079_ENTRY_PRICE_LAST_AGE_SEC
    _V1079_ENTRY_PRICE_REST_FALLBACKS += 1
    price = live_price(t, fallback)
    _V1079_ENTRY_PRICE_LAST_SOURCE = "paper.bithumb_all_rest_fallback"
    _V1079_ENTRY_PRICE_LAST_AGE_SEC = None
    return price, _V1079_ENTRY_PRICE_LAST_SOURCE, None

def candidate_freshness_evidence_v1039(ev: Dict[str, Any], ctrl: Dict[str, Any]) -> Dict[str, Any]:
    """v1174: candidate age remains visible but never blocks raw Paper intake."""
    row = ev if isinstance(ev, dict) else {}
    nowv = now_ts()
    legacy_ttl = 120.0
    expiry_keys = ("expires_at", "candidate_expires_at", "hold_expires_at")
    for key in expiry_keys:
        exp = row_ts(row, key)
        if exp > 0:
            would_be_fresh = bool(exp >= nowv)
            return {
                "schema": "paper_candidate_freshness_v1174_audit_only",
                "fresh": True, "ttl_enabled": False, "code": "TTL_DISABLED_RAW_MODE",
                "source": key, "age_sec": None, "expires_at": exp, "ttl_sec": 0.0,
                "legacy_ttl_sec": legacy_ttl, "would_be_fresh_v1174": would_be_fresh,
                "would_be_reason_v1174": "legacy expiry check",
            }
    created_keys = (
        "created_at", "candidate_created_at", "source_created_at", "hold_created_at",
        "created_ts", "updated_ts", "updated_at", "published_at",
        "detected_ts", "event_ts", "ts", "timestamp",
    )
    for key in created_keys:
        created = row_ts(row, key)
        if created > 0:
            age = max(0.0, nowv - created)
            return {
                "schema": "paper_candidate_freshness_v1174_audit_only",
                "fresh": True, "ttl_enabled": False, "code": "TTL_DISABLED_RAW_MODE",
                "source": key, "age_sec": round(age, 3), "expires_at": None, "ttl_sec": 0.0,
                "legacy_ttl_sec": legacy_ttl, "would_be_fresh_v1174": bool(age <= legacy_ttl),
                "would_be_reason_v1174": f"legacy age {age:.3f}s vs {legacy_ttl:.1f}s",
            }
    return {
        "schema": "paper_candidate_freshness_v1174_audit_only",
        "fresh": True, "ttl_enabled": False, "code": "TTL_DISABLED_RAW_MODE",
        "source": "timestamp_missing", "age_sec": None, "expires_at": None, "ttl_sec": 0.0,
        "legacy_ttl_sec": legacy_ttl, "would_be_fresh_v1174": False,
        "would_be_reason_v1174": "timestamp missing; recorded only",
    }

def candidate_is_fresh(ev: Dict[str, Any], ctrl: Dict[str, Any]) -> bool:
    return candidate_freshness_evidence_v1039(ev, ctrl).get("fresh") is True

def micro_fresh(ev: Dict[str, Any], ctrl: Dict[str, Any]) -> bool:
    ctx = ev.get("entry_context") if isinstance(ev.get("entry_context"), dict) else {}
    vals = [ev, ctx]
    for obj in vals:
        if bool(obj.get("micro_fresh")):
            return True
        if str(obj.get("micro_row_status") or "").lower() in {"fresh", "ok", "true", "1"}:
            return True
        age = fnum(obj.get("micro_age_sec"), default=999999.0)
        if age <= fnum(ctrl.get("preopen_micro_urgent_ttl_sec"), default=35.0):
            return True
    return False

def ws_fresh(ev: Dict[str, Any]) -> bool:
    ctx = ev.get("entry_context") if isinstance(ev.get("entry_context"), dict) else {}
    for obj in (ev, ctx):
        if bool(obj.get("ws_fresh")):
            return True
        if str(obj.get("ws_row_status") or "").lower() in {"fresh", "ok", "true", "1"}:
            return True
        if fnum(obj.get("ws_age_sec"), default=999999.0) <= 30:
            return True
    return False

def _version_from_text(txt: Any) -> str:
    s = str(txt or "").strip()
    if not s:
        return ""
    m = re.search(r"(?:^|[^0-9])2[_\.]13[_\.](\d{1,4})(?:[^0-9]|$)", s)
    if m:
        return f"v2.13.{int(m.group(1))}"
    m = re.search(r"v2\.13\.(\d{1,4})", s)
    if m:
        return f"v2.13.{int(m.group(1))}"
    return ""

_ACTIVE_MAIN_VERSION_CACHE: Dict[str, Any] = {"ts": 0.0, "version": "", "source": ""}

def _deployed_main_version_detail() -> Tuple[str, str]:
    """실제 적용된 메인봇 버전과 출처.

    v460 단일 본선:
    - DEPLOY_TARGET.txt는 구값(v2.13.320)이 남는 경우가 있어 마지막 fallback으로만 쓴다.
    - paper 성과판은 현재 실행 중인 메인봇 상태파일/실제 배포파일을 우선한다.
    - CLOSED 장부 원본은 수정하지 않고, score cache 집계 시점에만 보정한다.
    """
    candidates: List[Tuple[str, str]] = []

    # 1) 메인봇 heartbeat/status. 실제 실행 중인 BOT_VERSION이 가장 안전하다.
    for name in ("clean_brain_status.json", "clean_resource_status.json"):
        try:
            obj = json.loads((BASE_DIR / name).read_text(encoding="utf-8", errors="ignore"))
            if isinstance(obj, dict):
                for key in ("version", "bot_version", "main_version", "BOT_VERSION"):
                    v = _version_from_text(obj.get(key))
                    if v:
                        candidates.append((v, f"{name}:{key}"))
        except Exception:
            pass

    # 2) guard가 실제 배포 완료 후 남기는 단일 진실값 후보들.
    for name in (".deployed_target", ".deployed_main_target", ".active_main_target", "deployed_target.txt"):
        try:
            txt = (BASE_DIR / name).read_text(encoding="utf-8", errors="ignore").strip()
            v = _version_from_text(txt)
            if v:
                candidates.append((v, name))
        except Exception:
            pass

    # 3) 현재 bundle main 항목. paper-only bundle이면 main이 없을 수 있으므로 보조로만 사용.
    try:
        obj = json.loads((BASE_DIR / "DEPLOY_BUNDLE.json").read_text(encoding="utf-8", errors="ignore"))
        if isinstance(obj, dict):
            for key in ("main", "target", "deploy_target", "main_file"):
                v = _version_from_text(obj.get(key))
                if v:
                    candidates.append((v, f"DEPLOY_BUNDLE.json:{key}"))
    except Exception:
        pass

    # 4) bot.py/메인 파일 내부 BOT_VERSION. 짧은 앞부분만 읽어서 무거운 경로를 피한다.
    for name in ("bot.py",):
        try:
            path = BASE_DIR / name
            if path.exists():
                txt = path.read_text(encoding="utf-8", errors="ignore")[:20000]
                v = _version_from_text(txt)
                if v:
                    candidates.append((v, f"{name}:BOT_VERSION"))
        except Exception:
            pass

    # 5) 서버에 놓인 최신 coinbot_main 파일명.
    try:
        best = 0
        for f in BASE_DIR.glob("coinbot_main_v2_13_*.py"):
            m = re.search(r"coinbot_main_v2_13_(\d+)\.py$", f.name)
            if m:
                best = max(best, int(m.group(1)))
        if best:
            candidates.append((f"v2.13.{best}", "latest_coinbot_main_file"))
    except Exception:
        pass

    # 6) 마지막 fallback: 구 DEPLOY_TARGET. 단독으로만 쓴다.
    legacy = _legacy_deploy_target_version()
    if candidates:
        # paper-only bundle/구파일 혼재 시 가장 높은 v2.13.xxx를 실제 적용 후보로 본다.
        def _n(item: Tuple[str, str]) -> int:
            m = re.search(r"v2\.13\.(\d+)", item[0])
            return int(m.group(1)) if m else 0
        best = max(candidates, key=_n)
        return best
    if legacy:
        return legacy, "DEPLOY_TARGET.txt:fallback"
    return "", ""

def _legacy_deploy_target_version() -> str:
    try:
        txt = (BASE_DIR / "DEPLOY_TARGET.txt").read_text(encoding="utf-8", errors="ignore").strip()
        return _version_from_text(txt)
    except Exception:
        return ""

def active_main_version_detail(ttl: float = 3.0) -> Tuple[str, str]:
    ts = now_ts()
    if ts - float(_ACTIVE_MAIN_VERSION_CACHE.get("ts") or 0.0) < ttl:
        return str(_ACTIVE_MAIN_VERSION_CACHE.get("version") or ""), str(_ACTIVE_MAIN_VERSION_CACHE.get("source") or "")
    v, src = _deployed_main_version_detail()
    _ACTIVE_MAIN_VERSION_CACHE.update({"ts": ts, "version": v, "source": src})
    return v, src

def active_main_version() -> str:
    """성과판용 현재 메인봇 파일 버전.

    실제 실행/배포값을 우선하고, 오래된 DEPLOY_TARGET.txt는 마지막 fallback으로만 사용한다.
    """
    v, _src = active_main_version_detail()
    return v

_ACTIVE_PATCH_VERSION_CACHE: Dict[str, Any] = {"ts": 0.0, "version": "", "source": ""}

def _patch_version_from_text(txt: Any) -> str:
    s = str(txt or "").strip()
    if not s:
        return ""
    m = re.search(r"(?:^|[^0-9])v(\d{3,4})(?:[^0-9]|$)", s)
    if m:
        n = int(m.group(1))
        if 300 <= n <= 9999:
            return f"v{n}"
    return ""

def active_patch_version_detail(ttl: float = 3.0) -> Tuple[str, str]:
    ts = now_ts()
    if ts - float(_ACTIVE_PATCH_VERSION_CACHE.get("ts") or 0.0) < ttl:
        return str(_ACTIVE_PATCH_VERSION_CACHE.get("version") or ""), str(_ACTIVE_PATCH_VERSION_CACHE.get("source") or "")
    candidates: List[Tuple[str, str]] = []
    # 1) 현재 배포 묶음의 version이 사용자가 보는 수정판 기준이다.
    try:
        obj = json.loads((BASE_DIR / "DEPLOY_BUNDLE.json").read_text(encoding="utf-8", errors="ignore"))
        if isinstance(obj, dict):
            for key in ("version", "patch_version", "bundle_version"):
                v = _patch_version_from_text(obj.get(key))
                if v:
                    candidates.append((v, f"DEPLOY_BUNDLE.json:{key}"))
    except Exception:
        pass
    # 2) 메인 status/build label 보조.
    for name in ("clean_brain_status.json", "clean_resource_status.json"):
        try:
            obj = json.loads((BASE_DIR / name).read_text(encoding="utf-8", errors="ignore"))
            if isinstance(obj, dict):
                for key in ("build", "restore_build", "patch_version", "deploy_version", "version"):
                    v = _patch_version_from_text(obj.get(key))
                    if v:
                        candidates.append((v, f"{name}:{key}"))
        except Exception:
            pass
    best = candidates[0] if candidates else ("", "")
    _ACTIVE_PATCH_VERSION_CACHE.update({"ts": ts, "version": best[0], "source": best[1]})
    return best

def active_patch_version() -> str:
    v, _src = active_patch_version_detail()
    return v or _patch_version_from_text(BUILD_LABEL) or 'v607'

FAST_EXPERIMENT_LANE_V669 = "fast_quality_paper_v669"

STRATEGY_PIPELINE_COMMIT_V1150 = BASE_DIR / 'strategy_candidate_pipeline_commit_v1150.json'

def _v1158_handoff_content_digest(handoff: Dict[str, Any]) -> str:
    obj=handoff if isinstance(handoff,dict) else {}
    source={
        'cycle_id':str(obj.get('cycle_id') or ''),
        'candidate_commit_id':str(obj.get('candidate_commit_id') or ''),
        's1_rows':obj.get('s1_rows') if isinstance(obj.get('s1_rows'),list) else [],
        'candidate_rows':int(fnum(obj.get('candidate_rows'),default=0.0)),
        'priority_request_count':int(fnum(obj.get('priority_request_count'),default=0.0)),
        'target_count':int(fnum(obj.get('target_count'),default=0.0)),
    }
    return hashlib.sha256(json.dumps(source,ensure_ascii=False,sort_keys=True,separators=(',',':'),default=str).encode('utf-8')).hexdigest()

def _v1158_resolve_completed_handoff_v1158(ctrl: Dict[str, Any]) -> Tuple[Dict[str, Any], Dict[str, Any]]:
    """Resolve and read exactly one immutable current/last-complete generation."""
    nowv=now_ts(); commit=load_json(STRATEGY_PIPELINE_COMMIT_V1150,{}) or {}
    current_normal=bool(commit.get('state')=='NORMAL' and commit.get('complete') is True)
    last_complete=commit.get('last_complete_cycle_v1152') if isinstance(commit.get('last_complete_cycle_v1152'),dict) else {}
    if current_normal:
        effective=dict(commit); generation_source='CURRENT_COMPLETE'
    elif last_complete.get('state')=='NORMAL':
        effective=dict(last_complete); generation_source='LAST_COMPLETE_WHILE_CURRENT_IN_PROGRESS'
    else:
        effective={}; generation_source='NO_COMPLETE_GENERATION'
    cycle_id=str(effective.get('cycle_id') or '').strip(); candidate_commit_id=str(effective.get('candidate_commit_id') or '').strip()
    file_text=str(effective.get('committed_handoff_file_v1158') or '').strip()
    handoff_path=Path(file_text) if file_text else None
    handoff=load_json(handoff_path,{}) if isinstance(handoff_path,Path) else {}
    if not isinstance(handoff,dict): handoff={}
    completed_ts=fnum(effective.get('committed_handoff_completed_ts_v1158'),effective.get('completed_ts_v1152'),effective.get('completed_ts'),default=0.0)
    age=max(0.0,nowv-completed_ts) if completed_ts>0 else None
    max_age=max(180.0,fnum((ctrl or {}).get('candidate_ttl_sec'),default=120.0)*2.0)
    expected_id=str(effective.get('committed_handoff_id_v1158') or '').strip(); expected_digest=str(effective.get('committed_handoff_digest_v1158') or '').strip()
    computed_digest=_v1158_handoff_content_digest(handoff) if handoff else ''
    checks={
        'complete_generation_present':bool(cycle_id),
        'handoff_file_present':bool(handoff_path and handoff_path.is_file()),
        'committed_handoff_schema':handoff.get('schema')=='strategy_paper_handoff_committed_v1158',
        'handoff_cycle_match':bool(cycle_id) and str(handoff.get('cycle_id') or '')==cycle_id,
        'candidate_commit_match':bool(candidate_commit_id) and str(handoff.get('candidate_commit_id') or '')==candidate_commit_id,
        'handoff_id_match':bool(expected_id) and str(handoff.get('handoff_id_v1158') or '')==expected_id,
        'handoff_digest_pointer_match':bool(expected_digest) and str(handoff.get('digest_v1158') or '')==expected_digest,
        'handoff_content_digest_match':bool(expected_digest) and computed_digest==expected_digest,
        'required_commits':handoff.get('all_required_commits_v1158') is True,
        'fresh':True,
    }
    ready=all(checks.values()); failed=[k for k,v in checks.items() if not v]
    # v1166: this is the exact Paper-side generation-resolve clock.  It is
    # attached only in memory and does not mutate Strategy's immutable file.
    handoff['_paper_generation_resolved_at_v1166']=nowv
    gate={
        'schema':'paper_strategy_pipeline_gate_v1158','state':'NORMAL' if ready else 'BLOCKED','ready':ready,
        'cycle_id':cycle_id or None,'effective_generation_source_v1158':generation_source,
        'current_strategy_cycle_id':commit.get('cycle_id'),'current_strategy_state':commit.get('state'),
        'current_cycle_in_progress':bool(commit.get('current_cycle_in_progress_v1152')),
        'age_sec':round(age,3) if age is not None else None,'max_age_sec':None,
        'generation_age_blocking_v1174':False,'legacy_max_age_sec_v1174':max_age,
        'failed_checks':failed,'checks':checks,'candidate_commit_id':candidate_commit_id or None,
        'committed_handoff_id_v1158':handoff.get('handoff_id_v1158'),'committed_handoff_digest_v1158':handoff.get('digest_v1158'),
        'committed_handoff_file_v1158':file_text or None,
        'committed_s1_count_v1158':len(handoff.get('s1_rows') or []) if isinstance(handoff.get('s1_rows'),list) else 0,
        'completed_ts_v1152':completed_ts or None,
        'paper_generation_resolved_at_v1166':nowv,
        'last_complete_cycle_v1152':last_complete or None,
        'reason':'완료된 동일 generation S1을 소비함' if ready else '완료된 동일 generation handoff 증거가 불완전함',
        'owner':'Strategy immutable completed handoff -> Paper exact-generation consumer',
        'strategy_formula_changed':False,'auto_buy':False,
    }
    return gate,handoff

def strategy_candidate_pipeline_ready_v1150(ctrl: Dict[str, Any]) -> Dict[str, Any]:
    gate,_handoff=_v1158_resolve_completed_handoff_v1158(ctrl)
    return gate

def _v1152_nonnegative_delta(end_ts: Any, start_ts: Any) -> Optional[float]:
    end=fnum(end_ts,default=0.0); start=fnum(start_ts,default=0.0)
    if end<=0 or start<=0 or end<start:
        return None
    return round(end-start,3)

V1153_PAPER_PATH_LEDGER = BASE_DIR / 'paper_candidate_path_events_v1153.jsonl'

V1153_PAPER_PATH_STATE = BASE_DIR / 'paper_candidate_path_state_v1153.json'

_V1153_PAPER_PATH_LOCK = threading.RLock()

def _v1153_paper_path_identity(ev: Dict[str, Any]) -> Dict[str, str]:
    ev=ev if isinstance(ev,dict) else {}
    gate=read_strategy_entry_gate(ev)
    occ=gate.get('trigger_occurrence') if isinstance(gate.get('trigger_occurrence'),dict) else ev.get('trigger_occurrence') if isinstance(ev.get('trigger_occurrence'),dict) else {}
    ticker=normalize_ticker(ev.get('ticker') or ev.get('market') or ev.get('symbol'))
    direct=str(read_strategy_decision_key(ev,gate) or occ.get('decision_key') or '').strip()
    candidate=str(ev.get('trigger_occurrence_candidate_key') or occ.get('candidate_key') or ev.get('entry_build_key') or ev.get('event_id') or ev.get('event_key') or '').strip()
    trigger=str(occ.get('candidate_key') or ev.get('trigger_occurrence_candidate_key') or direct or '').strip()
    return {'ticker':ticker,'direct_decision_key':direct,'candidate_key':candidate,'trigger_event_key':trigger}

def _v1153_paper_event_once(stage: str, ev: Dict[str, Any], reasons: Any=None,
                            extra: Optional[Dict[str, Any]]=None) -> Optional[float]:
    """Append the first stage event once and count later exposures in mutable state.

    The JSONL ledger remains append-once.  Only the dedup/runtime state updates
    seen_count/last_seen_at so the map can distinguish first delivery from the
    same trigger event being exposed again in later Paper cycles.
    """
    ident=_v1153_paper_path_identity(ev)
    anchor=ident.get('trigger_event_key') or ident.get('direct_decision_key') or ident.get('candidate_key')
    if not anchor:
        return None
    stage_u=str(stage or '').strip().upper()
    uid=hashlib.sha256(f"paper|{stage_u}|{anchor}".encode('utf-8')).hexdigest()
    nowv=now_ts()
    exposure_map=ev.get('paper_path_exposure_v1156') if isinstance(ev.get('paper_path_exposure_v1156'),dict) else {}
    with _V1153_PAPER_PATH_LOCK:
        state=load_json(V1153_PAPER_PATH_STATE,{}) or {}
        records=state.get('records') if isinstance(state,dict) and isinstance(state.get('records'),dict) else {}
        old=records.get(uid) if isinstance(records.get(uid),dict) else {}
        if old:
            first=fnum(old.get('recorded_at'),old.get('first_seen_at'),default=0.0) or None
            seen=max(1,int(fnum(old.get('seen_count'),default=1.0)))+1
            old.update({'recorded_at':first,'first_seen_at':first,'last_seen_at':nowv,'seen_count':seen,
                        'repeat_exposure_count':max(0,seen-1),'stage':stage_u,'anchor':anchor})
            records[uid]=old
            exposure_map[stage_u]={
                'stage':stage_u,'first_seen_at':first,'last_seen_at':nowv,
                'exposure_count':seen,'repeat_exposure_count':max(0,seen-1),'event_uid':uid,
            }
            ev['paper_path_exposure_v1156']=exposure_map
            try:
                save_json(V1153_PAPER_PATH_STATE,{
                    'schema':'paper_candidate_path_state_v1153','version':VERSION,'build':BUILD_LABEL,
                    'updated_ts':nowv,'record_count':len(records),'records':records,
                    'policy':'append-only event ledger; mutable dedup state also counts repeat exposure',
                })
            except Exception as exc:
                log_error('paper_candidate_repeat_exposure_v1156',exc)
            return first
        reason_list=[str(x).strip() for x in (reasons if isinstance(reasons,list) else [reasons]) if str(x).strip()]
        payload={
            'schema':'paper_candidate_path_event_v1153','event_uid':uid,'stage':stage_u,
            'owner':'paper_bot','recorded_at':nowv,'recorded_text':iso_ts(nowv),**ident,
            'reasons':reason_list[:12],
            'paper_version':VERSION,'paper_build':BUILD_LABEL,
            'strategy_formula_changed':False,'entry_contract_changed':False,'auto_buy':False,
        }
        if isinstance(extra,dict): payload['evidence']=extra
        try:
            V1153_PAPER_PATH_LEDGER.parent.mkdir(parents=True,exist_ok=True)
            with V1153_PAPER_PATH_LEDGER.open('a',encoding='utf-8') as fh:
                fh.write(json.dumps(payload,ensure_ascii=False,separators=(',',':'),default=str)+'\n')
                fh.flush(); os.fsync(fh.fileno())
            records[uid]={'recorded_at':nowv,'first_seen_at':nowv,'last_seen_at':nowv,
                          'seen_count':1,'repeat_exposure_count':0,'stage':stage_u,'anchor':anchor}
            save_json(V1153_PAPER_PATH_STATE,{
                'schema':'paper_candidate_path_state_v1153','version':VERSION,'build':BUILD_LABEL,
                'updated_ts':nowv,'record_count':len(records),'records':records,
                'policy':'append-only event ledger; mutable dedup state also counts repeat exposure',
            })
            exposure_map[stage_u]={
                'stage':stage_u,'first_seen_at':nowv,'last_seen_at':nowv,
                'exposure_count':1,'repeat_exposure_count':0,'event_uid':uid,
            }
            ev['paper_path_exposure_v1156']=exposure_map
            return nowv
        except Exception as exc:
            log_error('paper_candidate_path_v1153',exc)
            return None

def _v1153_set_path_ts(ev: Dict[str, Any], key: str, value: Optional[float]) -> None:
    if not isinstance(ev,dict) or not value:
        return
    path=dict(ev.get('candidate_path_timestamps_v1153') or {}) if isinstance(ev.get('candidate_path_timestamps_v1153'),dict) else {'schema':'candidate_path_timestamps_v1153'}
    path[key]=value
    ev['candidate_path_timestamps_v1153']=path
    ev[f'{key}_v1153']=value

def candidate_delay_path_v1152(ev: Dict[str, Any], pipeline: Dict[str, Any], ctrl: Dict[str, Any], paper_ts: Optional[float]=None) -> Dict[str, Any]:
    """Split strategic waiting from the actual Strategy→Paper transport spine.

    v1153 mixed first semantic events (trigger/quality/S1) with file/generation
    commit timestamps and then called the largest combined gap a writer delay.
    v1166 keeps both truths but never uses a strategic wait as proof of an I/O
    bottleneck.  Trading gates and TTL remain unchanged.
    """
    row=ev if isinstance(ev,dict) else {}
    pipe=pipeline if isinstance(pipeline,dict) else {}
    gate=read_strategy_entry_gate(row)
    occurrence=gate.get('trigger_occurrence') if isinstance(gate.get('trigger_occurrence'),dict) else row.get('trigger_occurrence') if isinstance(row.get('trigger_occurrence'),dict) else {}
    path_ts=row.get('candidate_path_timestamps_v1153') if isinstance(row.get('candidate_path_timestamps_v1153'),dict) else {}
    nowv=float(paper_ts if paper_ts is not None else now_ts())
    event_ts=fnum(path_ts.get('trigger_event_at'),(occurrence or {}).get('event_ts'),(occurrence or {}).get('rebreak_ts'),default=0.0)
    quality_ts=fnum(path_ts.get('quality_evaluated_at'),row.get('quality_evaluated_at_v1153'),default=0.0)
    quality_pass_ts=fnum(path_ts.get('quality_pass_at'),row.get('quality_pass_at_v1153'),quality_ts,default=0.0)
    s1_first_ts=fnum(path_ts.get('s1_hold_created_at'),row.get('s1_hold_created_at_v1153'),row.get('hold_created_at'),default=0.0)
    paper_received_ts=fnum(path_ts.get('paper_received_at'),row.get('paper_received_at_v1153'),nowv,default=0.0)
    execution_ready_ts=fnum(path_ts.get('execution_data_ready_at'),row.get('execution_data_ready_at_v1153'),default=0.0)
    selector_ts=fnum(path_ts.get('selector_decided_at'),row.get('selector_decided_at_v1153'),default=0.0)
    open_ts=fnum(path_ts.get('open_committed_at'),row.get('open_committed_at_v1153'),default=0.0)

    cycle_started=fnum(row.get('candidate_pipeline_cycle_started_ts_v1152'),pipe.get('cycle_started_ts'),default=0.0)
    s1_commit_ts=fnum(path_ts.get('s1_hold_file_committed_at_v1166'),row.get('s1_hold_file_committed_at_v1166'),pipe.get('s1_hold_completed_ts_v1166'),pipe.get('s1_hold_completed_ts_v1152'),default=0.0)
    candidate_commit_ts=fnum(path_ts.get('candidate_snapshot_committed_at_v1166'),row.get('candidate_snapshot_committed_at_v1166'),pipe.get('candidate_snapshot_completed_ts_v1166'),pipe.get('candidate_snapshot_completed_ts_v1152'),default=0.0)
    priority_commit_ts=fnum(path_ts.get('priority_requests_committed_at_v1166'),row.get('priority_requests_committed_at_v1166'),pipe.get('priority_requests_completed_ts_v1166'),pipe.get('priority_requests_completed_ts_v1152'),default=0.0)
    generation_commit_ts=fnum(path_ts.get('completed_generation_committed_at_v1166'),row.get('completed_generation_committed_at_v1166'),pipe.get('completed_generation_committed_at_v1166'),pipe.get('committed_handoff_completed_ts_v1158'),pipe.get('completed_ts_v1152'),default=0.0)
    generation_resolve_ts=fnum(path_ts.get('paper_generation_resolved_at_v1166'),row.get('paper_generation_resolved_at_v1166'),default=0.0)
    ttl=fnum((ctrl or {}).get('candidate_ttl_sec'),default=0.0)

    semantic_segments={
        'trigger_to_quality_sec':_v1152_nonnegative_delta(quality_ts,event_ts),
        'quality_to_s1_sec':_v1152_nonnegative_delta(s1_first_ts,quality_pass_ts or quality_ts),
    }
    transport_segments={
        's1_event_to_s1_commit_sec':_v1152_nonnegative_delta(s1_commit_ts,s1_first_ts),
        's1_commit_to_candidate_snapshot_sec':_v1152_nonnegative_delta(candidate_commit_ts,s1_commit_ts),
        'candidate_snapshot_to_priority_commit_sec':_v1152_nonnegative_delta(priority_commit_ts,candidate_commit_ts),
        'priority_commit_to_handoff_commit_sec':_v1152_nonnegative_delta(generation_commit_ts,priority_commit_ts),
        'handoff_commit_to_paper_resolve_sec':_v1152_nonnegative_delta(generation_resolve_ts,generation_commit_ts),
        'paper_resolve_to_candidate_read_sec':_v1152_nonnegative_delta(paper_received_ts,generation_resolve_ts),
    }
    downstream_segments={
        'paper_to_execution_ready_sec':_v1152_nonnegative_delta(execution_ready_ts,paper_received_ts),
        'execution_ready_to_selector_sec':_v1152_nonnegative_delta(selector_ts,execution_ready_ts),
        'selector_to_open_sec':_v1152_nonnegative_delta(open_ts,selector_ts),
    }
    exact_segments={
        **semantic_segments,
        's1_to_paper_sec':_v1152_nonnegative_delta(paper_received_ts,s1_first_ts),
        **downstream_segments,
    }
    fallback_segments={
        'trigger_to_strategy_start_sec':_v1152_nonnegative_delta(cycle_started,event_ts),
        'strategy_start_to_s1_sec':_v1152_nonnegative_delta(s1_commit_ts,cycle_started),
        's1_to_candidate_snapshot_sec':_v1152_nonnegative_delta(candidate_commit_ts,s1_commit_ts),
        'candidate_snapshot_to_priority_sec':_v1152_nonnegative_delta(priority_commit_ts,candidate_commit_ts),
        'priority_to_paper_sec':_v1152_nonnegative_delta(paper_received_ts or nowv,priority_commit_ts),
    }
    semantic_available={k:v for k,v in semantic_segments.items() if isinstance(v,(int,float))}
    transport_available={k:v for k,v in transport_segments.items() if isinstance(v,(int,float))}
    fallback_available={k:v for k,v in fallback_segments.items() if isinstance(v,(int,float))}
    largest_transport=max(transport_available,key=transport_available.get) if transport_available else None
    largest_semantic=max(semantic_available,key=semantic_available.get) if semantic_available else None
    # Public bottleneck owner is transport-only.  Strategic waiting is shown in a
    # separate field and cannot accuse a writer/cache without commit evidence.
    largest=largest_transport or (max(fallback_available,key=fallback_available.get) if fallback_available else largest_semantic)
    largest_source='transport_commit_spine_v1166' if largest_transport else ('v1152_cycle_fallback' if fallback_available else 'semantic_wait_only_v1166')
    total=_v1152_nonnegative_delta(paper_received_ts or nowv,event_ts)
    transport_total=_v1152_nonnegative_delta(paper_received_ts or nowv,s1_commit_ts)
    ident_v1156=_v1153_paper_path_identity(row)
    exposure_v1156=row.get('paper_path_exposure_v1156') if isinstance(row.get('paper_path_exposure_v1156'),dict) else {}
    paper_receive_exposure_v1156=exposure_v1156.get('PAPER_RECEIVED') if isinstance(exposure_v1156.get('PAPER_RECEIVED'),dict) else {}
    return {
        'schema':'paper_candidate_delay_path_v1166_owner_split','ticker':normalize_ticker(row.get('ticker') or row.get('market') or row.get('symbol')),
        'trigger_event_key':ident_v1156.get('trigger_event_key'),'candidate_key':ident_v1156.get('candidate_key'),
        'direct_decision_key':ident_v1156.get('direct_decision_key'),
        'paper_received_exposure_v1156':paper_receive_exposure_v1156,
        'paper_received_exposure_count_v1156':int(paper_receive_exposure_v1156.get('exposure_count') or 0),
        'paper_received_repeat_count_v1156':int(paper_receive_exposure_v1156.get('repeat_exposure_count') or 0),
        'cycle_id':row.get('candidate_pipeline_cycle_id_v1150') or pipe.get('cycle_id'),
        'candidate_commit_id':pipe.get('candidate_commit_id'),'event_ts':event_ts or None,
        'quality_evaluated_at':quality_ts or None,'quality_pass_at':quality_pass_ts or None,
        's1_hold_created_at':s1_first_ts or None,'paper_received_at':paper_received_ts or None,
        'execution_data_ready_at':execution_ready_ts or None,'selector_decided_at':selector_ts or None,'open_committed_at':open_ts or None,
        'strategy_cycle_started_ts':cycle_started or None,'s1_hold_completed_ts':s1_commit_ts or None,
        'candidate_snapshot_completed_ts':candidate_commit_ts or None,'priority_requests_completed_ts':priority_commit_ts or None,
        'completed_generation_committed_at_v1166':generation_commit_ts or None,
        'paper_generation_resolved_at_v1166':generation_resolve_ts or None,
        'paper_checked_ts':nowv,'segments':fallback_segments,'exact_segments_v1153':exact_segments,
        'semantic_wait_segments_v1166':semantic_segments,'transport_segments_v1166':transport_segments,
        'downstream_segments_v1166':downstream_segments,
        'largest_transport_segment_v1166':largest_transport,
        'largest_transport_segment_sec_v1166':transport_available.get(largest_transport) if largest_transport else None,
        'largest_semantic_wait_segment_v1166':largest_semantic,
        'largest_semantic_wait_segment_sec_v1166':semantic_available.get(largest_semantic) if largest_semantic else None,
        'largest_segment':largest,
        'largest_segment_sec':(transport_available.get(largest) if largest in transport_available else fallback_available.get(largest) if largest in fallback_available else semantic_available.get(largest)),
        'largest_segment_source_v1153':largest_source,
        'largest_segment_source_v1166':largest_source,
        'total_trigger_to_paper_sec':total,'paper_transport_total_sec_v1166':transport_total,'ttl_sec':0.0,
        'expired_by_sec':None,'ttl_disabled_v1174':True,'legacy_ttl_sec_v1174':120.0,
        'timing_complete':all(v is not None for v in exact_segments.values()),
        'first_three_segments_complete_v1153':all(exact_segments.get(k) is not None for k in ('trigger_to_quality_sec','quality_to_s1_sec','s1_to_paper_sec')),
        'transport_spine_complete_v1166':all(transport_segments.get(k) is not None for k in transport_segments),
        'time_owner_policy_v1166':'semantic waits and runtime transport commits are separate; only transport timestamps can name a writer/cache bottleneck',
        'strategy_formula_changed':False,'ttl_changed':False,'auto_buy':False,
    }

def _v1152_record_delay_summary(stats: Dict[str, Any], path: Dict[str, Any], code: str) -> None:
    if not isinstance(stats,dict) or not isinstance(path,dict):
        return
    summary=stats.get('trigger_delay_path_summary_v1152') if isinstance(stats.get('trigger_delay_path_summary_v1152'),dict) else {
        'schema':'paper_trigger_delay_summary_v1152','count':0,'stale_count':0,'fresh_count':0,'total_age_sum_sec':0.0,
        'largest_segment_counts':{},'samples':[],'owner':'Paper trigger occurrence check','ttl_changed':False,'strategy_formula_changed':False,
    }
    summary['count']=int(summary.get('count') or 0)+1
    if str(code)=='STALE_TRIGGER_OCCURRENCE': summary['stale_count']=int(summary.get('stale_count') or 0)+1
    if str(code)=='FRESH_QUALIFIED_TRIGGER_OCCURRENCE': summary['fresh_count']=int(summary.get('fresh_count') or 0)+1
    if path.get('timing_complete') is True: summary['exact_path_complete_count_v1153']=int(summary.get('exact_path_complete_count_v1153') or 0)+1
    if path.get('first_three_segments_complete_v1153') is True: summary['first_three_complete_count_v1153']=int(summary.get('first_three_complete_count_v1153') or 0)+1
    total=path.get('total_trigger_to_paper_sec')
    if isinstance(total,(int,float)):
        summary['total_age_sum_sec']=round(float(summary.get('total_age_sum_sec') or 0.0)+float(total),3)
        summary['mean_total_age_sec']=round(float(summary['total_age_sum_sec'])/max(1,int(summary['count'])),3)
    largest=str(path.get('largest_segment') or '정보없음')
    counts=summary.get('largest_segment_counts') if isinstance(summary.get('largest_segment_counts'),dict) else {}
    counts[largest]=int(counts.get(largest) or 0)+1
    summary['largest_segment_counts']=dict(sorted(counts.items(),key=lambda kv:(-int(kv[1]),kv[0])))
    samples=summary.get('samples') if isinstance(summary.get('samples'),list) else []
    if len(samples)<10:
        sample={k:path.get(k) for k in ('ticker','trigger_event_key','candidate_key','direct_decision_key','cycle_id','candidate_commit_id','total_trigger_to_paper_sec','paper_transport_total_sec_v1166','ttl_sec','expired_by_sec','largest_segment','largest_segment_sec','largest_segment_source_v1153','largest_segment_source_v1166','largest_transport_segment_v1166','largest_transport_segment_sec_v1166','largest_semantic_wait_segment_v1166','largest_semantic_wait_segment_sec_v1166','segments','exact_segments_v1153','semantic_wait_segments_v1166','transport_segments_v1166','downstream_segments_v1166','transport_spine_complete_v1166','first_three_segments_complete_v1153','paper_received_exposure_count_v1156','paper_received_repeat_count_v1156','paper_received_exposure_v1156')}
        sample['reason_code']=str(code or 'UNKNOWN')
        samples.append(sample)
    summary['samples']=samples
    stats['trigger_delay_path_summary_v1152']=summary

def candidate_sources(ctrl: Dict[str, Any], committed_handoff_v1158: Optional[Dict[str, Any]]=None) -> List[Tuple[str, Path, List[Dict[str, Any]]]]:
    """Paper OPEN source: one atomic, fully completed Strategy generation only.

    `paper_s1_hold_cache.json` remains current-cycle inventory for observation. It is
    never used as the trading source because it can belong to an in-progress generation.
    """
    obj=committed_handoff_v1158 if isinstance(committed_handoff_v1158,dict) else {}
    rows=obj.get('s1_rows') if isinstance(obj.get('s1_rows'),list) else []
    out: List[Dict[str, Any]]=[]
    cycle_id=str(obj.get('cycle_id') or '').strip()
    handoff_id=str(obj.get('handoff_id_v1158') or '').strip()
    generation_resolved_at_v1166=fnum(obj.get('_paper_generation_resolved_at_v1166'),default=0.0)
    generation_committed_at_v1166=fnum(obj.get('completed_generation_committed_at_v1166'),obj.get('completed_ts'),default=0.0)
    for r in rows:
        if not isinstance(r,dict): continue
        rr=dict(r)
        rr['_source_file']='s1_hold_committed_v1158'
        rr['paper_consumed_pipeline_cycle_id_v1158']=cycle_id or None
        rr['paper_consumed_handoff_id_v1158']=handoff_id or None
        rr['completed_generation_committed_at_v1166']=generation_committed_at_v1166 or rr.get('completed_generation_committed_at_v1166')
        rr['paper_generation_resolved_at_v1166']=generation_resolved_at_v1166 or None
        path_ts=dict(rr.get('candidate_path_timestamps_v1153') or {}) if isinstance(rr.get('candidate_path_timestamps_v1153'),dict) else {'schema':'candidate_path_timestamps_v1153'}
        if generation_committed_at_v1166>0: path_ts['completed_generation_committed_at_v1166']=generation_committed_at_v1166
        if generation_resolved_at_v1166>0: path_ts['paper_generation_resolved_at_v1166']=generation_resolved_at_v1166
        rr['candidate_path_timestamps_v1153']=path_ts
        out.append(rr)
    return [('s1_hold',Path(str(obj.get('handoff_file_v1158') or 'strategy_paper_handoff_committed_v1158.json')),out)]

def latest_scan_filter__L1801(rows: List[Dict[str, Any]], ctrl: Dict[str, Any]) -> List[Dict[str, Any]]:
    hold_rows = [r for r in (rows or []) if isinstance(r, dict) and _v734_is_hold(r)]
    if hold_rows:
        return hold_rows
    if not rows or not bool(ctrl.get("consume_latest_scan_only", True)):
        return rows
    scan_ids = [str(r.get("scan_id") or r.get("source_scan_id") or "").strip() for r in rows if str(r.get("scan_id") or r.get("source_scan_id") or "").strip()]
    if scan_ids:
        latest = scan_ids[-1]
        same = [r for r in rows if str(r.get("scan_id") or r.get("source_scan_id") or "").strip() == latest]
        if same:
            return same
    latest_ts = max((event_created_ts(r) for r in rows), default=0.0)
    if latest_ts > 0:
        win = fnum(ctrl.get("latest_scan_window_sec"), default=8.0)
        return [r for r in rows if event_created_ts(r) >= latest_ts - win]
    return rows

def copy_entry_context(ev: Dict[str, Any]) -> Dict[str, Any]:
    ctx: Dict[str, Any] = {}
    if isinstance(ev.get("entry_context"), dict):
        ctx.update(ev["entry_context"])
    for k, v in ev.items():
        if k.startswith("_"):
            continue
        if k not in ctx and k not in {"raw"}:
            ctx[k] = v
    return ctx

def _diag_sources(ev: Dict[str, Any], ctx: Optional[Dict[str, Any]] = None) -> List[Dict[str, Any]]:
    srcs: List[Dict[str, Any]] = []
    for obj in (ev, ctx, ev.get("entry_context"), ev.get("entry_snapshot"), ev.get("profile"), ev.get("raw")):
        if isinstance(obj, dict):
            srcs.append(obj)
            for kk in (
                "flat", "strategy", "strategy_context", "metrics", "entry_metrics", "recheck_metrics",
                "orderflow", "orderflow_summary", "feature", "features", "price_flow", "price_context",
                "money_flow", "position", "risk", "micro", "micro_summary", "ws", "quote",
                "market", "market_context", "standard_values", "candidate_values", "score_context", "ticker_state",
            ):
                vv = obj.get(kk)
                if isinstance(vv, dict):
                    srcs.append(vv)
    return srcs

def _diag_first(ev: Dict[str, Any], keys: Iterable[str], default: Any = None, ctx: Optional[Dict[str, Any]] = None) -> Any:
    for src in _diag_sources(ev, ctx):
        for k in keys:
            if k in src and src.get(k) not in (None, "", [], {}):
                return src.get(k)
    return default

def _diag_list(ev: Dict[str, Any], keys: Iterable[str], ctx: Optional[Dict[str, Any]] = None, limit: int = 8) -> List[str]:
    out: List[str] = []
    for src in _diag_sources(ev, ctx):
        for k in keys:
            v = src.get(k)
            if v in (None, "", [], {}):
                continue
            vals: List[Any]
            if isinstance(v, list):
                vals = v
            elif isinstance(v, dict):
                vals = [f"{kk}:{vv}" for kk, vv in list(v.items())[:limit]]
            else:
                vals = [v]
            for item in vals:
                txt = str(item).strip()
                if txt and txt not in out:
                    out.append(txt)
                    if len(out) >= limit:
                        return out
    return out

def _fmt_bool(v: Any) -> str:
    if isinstance(v, str):
        if v.lower() in {"fresh", "ok", "true", "1", "yes"}:
            return "OK"
        if v.lower() in {"stale", "old", "false", "0", "no"}:
            return "부족"
    if v is True:
        return "OK"
    if v is False:
        return "부족"
    return "-" if v in (None, "") else str(v)

def _paper_v143_num_if_present(obj: Any, key: str) -> Optional[float]:
    if not isinstance(obj, dict) or obj.get(key) in (None, ""):
        return None
    try:
        return float(str(obj.get(key)).replace(",", "").replace("%", "").strip())
    except Exception:
        return None

def _paper_v143_all_present(srcs: List[Dict[str, Any]], keys: List[str], group: str) -> List[Dict[str, Any]]:
    out: List[Dict[str, Any]] = []
    for src in srcs:
        if not isinstance(src, dict):
            continue
        for k in keys:
            v = _paper_v143_num_if_present(src, k)
            if v is not None:
                out.append({"group": group, "source": k, "value": round(float(v), 4)})
    return out

def _paper_v143_first_present(srcs: List[Dict[str, Any]], keys: List[str]) -> Tuple[Optional[float], str]:
    for src in srcs:
        if not isinstance(src, dict):
            continue
        for k in keys:
            v = _paper_v143_num_if_present(src, k)
            if v is not None:
                return v, k
    return None, ""

def _paper_v143_price_delta_candidate(srcs: List[Dict[str, Any]]) -> Dict[str, Any]:
    cur, cur_src = _paper_v143_first_present(srcs, [
        "current_price", "price", "last_price", "close", "trade_price", "quote_price", "ws_price", "micro_price"
    ])
    ref, ref_src = _paper_v143_first_present(srcs, [
        "detected_price", "watch_price", "first_seen_price", "s3_price", "s2_price",
        "candidate_price", "base_price", "entry_signal_price", "signal_price", "recheck_start_price"
    ])
    if cur is not None and ref is not None and cur > 0 and ref > 0:
        return {"group": "price_delta", "source": f"{cur_src}/{ref_src}", "value": round((cur - ref) / ref * 100.0, 4)}
    return {}

def _paper_v144_flow_window_candidates(ev: Dict[str, Any], ctx: Optional[Dict[str, Any]] = None) -> List[Dict[str, Any]]:
    """Return actually-present short-flow windows for the final no-reaction proof.

    This deliberately does not treat missing values as 0. Missing information is not
    silently converted into a block signal; only explicit 0/negative short-flow rows
    are used to prevent VIRTUAL-style no-reaction entries.
    """
    ctx = ctx if isinstance(ctx, dict) else {}
    srcs = _diag_sources(ev, ctx)
    groups = [
        ("1m", ["flow_1m_pct", "change_1m", "chg_1m", "flow_1m", "change_1m_pct", "ret_1m_pct", "price_change_1m"]),
        ("3m", ["flow_3m_pct", "change_3m", "chg_3m", "flow_3m", "change_3m_pct", "ret_3m_pct", "price_change_3m"]),
        ("5m", ["flow_5m_pct", "change_5m", "chg_5m", "flow_5m", "change_5m_pct", "ret_5m_pct", "price_change_5m"]),
        ("15m", ["flow_15m_pct", "change_15m", "chg_15m", "flow_15m", "change_15m_pct", "ret_15m_pct", "price_change_15m"]),
    ]
    out: List[Dict[str, Any]] = []
    for label, keys in groups:
        val, src = _paper_v143_first_present(srcs, keys)
        if val is not None:
            out.append({"window": label, "value": round(float(val), 4), "source": src})
    return out

def _paper_v144_reaction_proof_block(diag: Dict[str, Any], ctrl: Dict[str, Any]) -> str:
    """Hold confirmed no-reaction S1 entries right before OPEN.

    This is not an S1/S2/S3 threshold change and not a discard rule. If enough
    short-flow windows are present and all are flat/negative below the tiny proof
    threshold, paper only skips this OPEN attempt and leaves the candidate to the
    next recheck/strategy cycle.
    """
    if not bool(ctrl.get("paper_final_reaction_proof_enabled", True)):
        return ""
    flows = diag.get("flow_window_candidates") if isinstance(diag.get("flow_window_candidates"), list) else []
    min_windows = int(fnum(ctrl.get("paper_final_reaction_proof_min_windows"), default=2.0))
    min_flow = fnum(ctrl.get("paper_final_reaction_proof_min_flow_pct"), default=0.01)
    usable = []
    for x in flows:
        if isinstance(x, dict) and x.get("value") is not None:
            try:
                usable.append((str(x.get("window") or "?"), float(x.get("value") or 0.0)))
            except Exception:
                pass
    if len(usable) < max(1, min_windows):
        return ""
    best = max(v for _w, v in usable)
    if best < min_flow:
        flow_txt = " / ".join(f"{w} {v:+.2f}%" for w, v in usable[:4])
        return f"진입 직전 무반응 재확인 보류({flow_txt} / 최고흐름 {best:+.2f}% < +{min_flow:.2f}%)"
    return ""

def paper_price_reaction_spine(ev: Dict[str, Any], ctx: Optional[Dict[str, Any]] = None) -> Dict[str, Any]:
    """paper final safety가 strategy recheck와 같은 가격반응 spine을 보게 한다.

    명시 0값이 있더라도 실제 non-zero short-flow/price-delta가 있으면 그 값을 사용한다.
    이것은 최종 안전문 기준 완화가 아니라 구 0.00 경로 제거다.
    """
    ctx = ctx if isinstance(ctx, dict) else {}
    srcs = _diag_sources(ev, ctx)
    explicit_keys = ["price_reaction_pct", "reaction_pct", "price_response_pct", "price_recheck_pct"]
    flow_keys = [
        "flow_1m_pct", "change_1m", "chg_1m", "change_1m_pct", "ret_1m_pct", "price_change_1m",
        "flow_3m_pct", "change_3m", "chg_3m", "change_3m_pct", "ret_3m_pct", "price_change_3m",
    ]
    candidates: List[Dict[str, Any]] = []
    candidates.extend(_paper_v143_all_present(srcs, explicit_keys, "explicit"))
    candidates.extend(_paper_v143_all_present(srcs, flow_keys, "short_flow"))
    pd = _paper_v143_price_delta_candidate(srcs)
    if pd:
        candidates.append(pd)
    explicit = [c for c in candidates if c.get("group") == "explicit"]
    nonzero_explicit = [c for c in explicit if abs(float(c.get("value") or 0.0)) >= 0.001]
    if nonzero_explicit:
        c = nonzero_explicit[0]
        return {"known": True, "value": float(c["value"]), "source": c.get("source"), "method": "explicit", "candidates": candidates[:8], "schema": "paper_price_reaction_spine_v143"}
    nonzero_alt = [c for c in candidates if c.get("group") in ("short_flow", "price_delta") and abs(float(c.get("value") or 0.0)) >= 0.001]
    if nonzero_alt:
        c = nonzero_alt[0]
        zero_src = explicit[0].get("source") if explicit else ""
        method = "explicit_zero_overridden" if explicit else str(c.get("group") or "alternate")
        return {"known": True, "value": float(c["value"]), "source": f"{c.get('source')}" + (f"; explicit0={zero_src}" if zero_src else ""), "method": method, "candidates": candidates[:8], "schema": "paper_price_reaction_spine_v143"}
    if explicit:
        c = explicit[0]
        return {"known": True, "value": float(c.get("value") or 0.0), "source": c.get("source"), "method": "explicit_zero", "candidates": candidates[:8], "schema": "paper_price_reaction_spine_v143"}
    if candidates:
        c = candidates[0]
        return {"known": True, "value": float(c.get("value") or 0.0), "source": c.get("source"), "method": str(c.get("group") or "candidate"), "candidates": candidates[:8], "schema": "paper_price_reaction_spine_v143"}
    return {"known": False, "value": 0.0, "source": "missing", "method": "missing", "candidates": [], "schema": "paper_price_reaction_spine_v143"}

def build_entry_diagnostics(ev: Dict[str, Any], ctx: Optional[Dict[str, Any]] = None) -> Dict[str, Any]:
    ctx = ctx if isinstance(ctx, dict) else {}
    # v553: 진입근거는 strategy_worker가 분리 봉인한 entry_reasons만 우선 사용한다.
    # s_stage_reasons/reason은 위험·부족·재확인 문구가 섞일 수 있으므로 진입근거 fallback에서 제외한다.
    reasons = _diag_list(ev, ("entry_reasons", "final_entry_reasons", "trade_ready_reasons"), ctx, 10)
    structure_tags = _diag_list(ev, ("entry_structure_tags", "structure_tags", "matched_strategy_labels"), ctx, 10)
    confirm_signals = _diag_list(ev, ("confirm_signals", "s1_passed_conditions", "condition_pass_summary"), ctx, 10)
    risk_tags = _diag_list(ev, ("execution_risk_tags", "risk_tags", "structure_risk_tags"), ctx, 10)
    recheck_reasons = _diag_list(ev, ("recheck_reasons", "s2_recheck_reasons", "freshness_flags"), ctx, 10)
    block_reasons = _diag_list(ev, ("block_reasons", "s1_missing_conditions", "unmet_conditions"), ctx, 10)
    missing = _diag_list(ev, ("missing_info", "missing_fields", "info_missing", "info_needed", "need_info", "entry_missing_info", "s1_missing"), ctx, 10)
    if not missing:
        missing = []
    matched = _diag_list(ev, ("matched_strategies", "strategy_matches", "strategy_tags", "tags"), ctx, 8)
    structure_levels = _diag_first(ev, ("structure_levels",), ctx=ctx)
    if not isinstance(structure_levels, dict):
        structure_levels = {}
    entry_plan = _diag_first(ev, ("entry_plan",), ctx=ctx)
    if not isinstance(entry_plan, dict):
        entry_plan = {}
    risk_reward = _diag_first(ev, ("risk_reward",), ctx=ctx)
    if not isinstance(risk_reward, dict):
        risk_reward = {}
    entry_timing_spine = _diag_first(ev, ("entry_timing_spine",), ctx=ctx)
    if not isinstance(entry_timing_spine, dict):
        entry_timing_spine = {}
    diag = {
        "stage_policy_schema": _diag_first(ev, ("stage_policy_schema", "lifecycle_schema"), ctx=ctx),
        "stage": _diag_first(ev, ("s_stage", "candidate_stage", "candidate_grade", "grade"), ctx=ctx),
        "strategy_key": _diag_first(ev, ("strategy_key", "paper_strategy_key", "strategy", "route", "section"), ctx=ctx),
        "strategy_label": _diag_first(ev, ("strategy_label", "paper_strategy_label", "final_entry_label"), ctx=ctx),
        "entry_reasons": reasons,
        "entry_structure_tags": structure_tags,
        "confirm_signals": confirm_signals,
        "execution_risk_tags": risk_tags,
        "recheck_reasons": recheck_reasons,
        "block_reasons": block_reasons,
        "missing_info": missing,
        "matched_strategies": matched,
        "reason_taxonomy_schema": _diag_first(ev, ("reason_taxonomy_schema",), ctx=ctx),
        "structure_levels": structure_levels,
        "entry_plan": entry_plan,
        "risk_reward": risk_reward,
        "entry_timing_spine": entry_timing_spine,
        "late_chase_flag": bool(_diag_first(ev, ("late_chase_flag",), ctx=ctx)),
        "micro_fresh": _fmt_bool(_diag_first(ev, ("micro_fresh", "micro_row_status", "micro_status"), ctx=ctx)),
        "ws_fresh": _fmt_bool(_diag_first(ev, ("ws_fresh", "ws_row_status", "quote_fresh", "quote_status"), ctx=ctx)),
        "buy_ratio": fnum(_diag_first(ev, ("buy_ratio", "buy_ratio_30s", "buy_trade_ratio", "micro_buy_ratio"), ctx=ctx), default=-1.0),
        "buy_sustain_1m": fnum(_diag_first(ev, ("micro_buy_ratio_sustain_1m", "buy_ratio_1m", "buy_sustain_1m"), ctx=ctx), default=-1.0),
        "spread_pct": fnum(_diag_first(ev, ("spread_pct", "micro_spread_pct", "orderbook_spread_pct"), ctx=ctx), default=-1.0),
        "slippage_pct": fnum(_diag_first(ev, ("slippage_est_pct", "expected_slippage_pct", "slippage_pct"), ctx=ctx), default=-1.0),
        "price_reaction_pct": fnum(_diag_first(ev, ("price_reaction_pct", "price_reaction", "reaction_pct", "price_recheck_pct"), ctx=ctx), default=0.0),
        "flow_1m_pct": fnum(_diag_first(ev, ("flow_1m_pct", "change_1m", "chg_1m", "flow_1m", "change_1m_pct", "ret_1m_pct", "price_change_1m"), ctx=ctx), default=0.0),
        "flow_3m_pct": fnum(_diag_first(ev, ("flow_3m_pct", "change_3m", "chg_3m", "flow_3m", "change_3m_pct", "ret_3m_pct", "price_change_3m"), ctx=ctx), default=0.0),
        "flow_5m_pct": fnum(_diag_first(ev, ("chg_5m", "flow_5m", "change_5m_pct", "ret_5m_pct"), ctx=ctx), default=0.0),
        "flow_15m_pct": fnum(_diag_first(ev, ("chg_15m", "flow_15m", "change_15m_pct", "ret_15m_pct"), ctx=ctx), default=0.0),
        "flow_30m_pct": fnum(_diag_first(ev, ("chg_30m", "flow_30m", "change_30m_pct", "ret_30m_pct"), ctx=ctx), default=0.0),
        "vwap_pos_pct": fnum(_diag_first(ev, ("vwap_pos_pct", "vwap_gap_pct", "vwap_position_pct", "vwap"), ctx=ctx), default=0.0),
        "ema5_pos_pct": fnum(_diag_first(ev, ("ema5_pos_pct", "ema5_gap_pct", "ema5_position_pct", "ema5"), ctx=ctx), default=0.0),
        "relative_strength": fnum(_diag_first(ev, ("relative_strength", "relative", "market_relative_strength"), ctx=ctx), default=0.0),
        "turnover_krw": fnum(_diag_first(ev, ("turnover_krw", "trade_amount_krw", "value_krw", "acc_trade_price_24h"), ctx=ctx), default=0.0),
        "sell_pressure": _diag_first(ev, ("sell_pressure", "ask_wall_pressure", "sell_trade_pressure"), ctx=ctx),
    }
    diag["flow_window_candidates"] = _paper_v144_flow_window_candidates(ev, ctx)
    diag["flow_window_source_schema"] = "paper_final_reaction_proof_v479_recheck_hold"
    diag["flow_window_map"] = {str(x.get("window")): x for x in diag["flow_window_candidates"] if isinstance(x, dict) and x.get("window")}
    pr_spine = paper_price_reaction_spine(ev, ctx)
    diag["price_reaction_pct"] = fnum(pr_spine.get("value"), default=0.0)
    diag["price_reaction_source"] = pr_spine.get("source")
    diag["price_reaction_method"] = pr_spine.get("method")
    diag["price_reaction_spine_schema"] = pr_spine.get("schema")
    diag["price_reaction_candidates"] = pr_spine.get("candidates") or []
    passed: List[str] = []
    if diag["micro_fresh"] == "OK": passed.append("micro신선")
    if diag["ws_fresh"] == "OK": passed.append("WS신선")
    if diag["buy_ratio"] >= 0: passed.append(f"매수체결 {diag['buy_ratio']:.2f}")
    if diag["buy_sustain_1m"] >= 0: passed.append(f"1분지속 {diag['buy_sustain_1m']:.2f}")
    if diag["spread_pct"] >= 0: passed.append(f"스프레드 {diag['spread_pct']:.2f}%")
    if diag["slippage_pct"] >= 0: passed.append(f"슬리피지 {diag['slippage_pct']:.2f}%")
    if diag["price_reaction_pct"]: passed.append(f"가격반응 {diag['price_reaction_pct']:+.2f}%")
    diag["condition_pass_summary"] = passed[:8]
    return diag

def _v494_first_ts_from_sources(ev: Dict[str, Any], ctx: Optional[Dict[str, Any]], keys: Iterable[str]) -> Tuple[float, str]:
    """Trace helper only. It must not change entry/exit decisions."""
    ctx = ctx if isinstance(ctx, dict) else {}
    for src in _diag_sources(ev, ctx):
        if not isinstance(src, dict):
            continue
        for k in keys:
            if k in src:
                ts = row_ts(src, k)
                if ts > 0:
                    return ts, k
    return 0.0, ""

def build_entry_timing_trace(ev: Dict[str, Any], diag: Optional[Dict[str, Any]] = None) -> Dict[str, Any]:
    """진입이 늦었는지 확인하기 위한 trace. 조건/청산 변경에 쓰지 않는다."""
    ctx = copy_entry_context(ev)
    diag = diag if isinstance(diag, dict) else build_entry_diagnostics(ev, ctx)
    source_ts, src_key = _v494_first_ts_from_sources(ev, ctx, (
        "first_detected_ts", "first_seen_ts", "detected_ts", "candidate_created_at",
        "source_created_at", "created_at", "event_ts", "ts", "timestamp",
    ))
    promotion_ts, promotion_key = _v494_first_ts_from_sources(ev, ctx, (
        "s1_promotion_ts", "recheck_promotion_ts", "promoted_ts", "paper_handoff_ts",
        "handoff_ts", "updated_ts", "updated_at",
    ))
    nowv = now_ts()
    source_age_sec = max(0.0, nowv - source_ts) if source_ts > 0 else 0.0
    promotion_age_sec = max(0.0, nowv - promotion_ts) if promotion_ts > 0 else 0.0
    source_to_promotion_sec = max(0.0, promotion_ts - source_ts) if source_ts > 0 and promotion_ts > 0 else 0.0
    hot1 = _diag_first(ev, ("hot_rank_1m", "scanner_hot_rank_1m"), ctx=ctx)
    hot3 = _diag_first(ev, ("hot_rank_3m", "scanner_hot_rank_3m"), ctx=ctx)
    change_1m_source = _diag_first(ev, ("change_1m_source", "scanner_change_1m_source"), ctx=ctx)
    change_3m_source = _diag_first(ev, ("change_3m_source", "scanner_change_3m_source"), ctx=ctx)
    flags: List[str] = []
    f1 = fnum(diag.get("flow_1m_pct"), default=0.0)
    f3 = fnum(diag.get("flow_3m_pct"), default=0.0)
    react = fnum(diag.get("price_reaction_pct"), default=0.0)
    pr_src = str(diag.get("price_reaction_source") or "")
    if source_age_sec >= 120:
        flags.append(f"후보오래됨({source_age_sec/60.0:.1f}분)")
    if source_to_promotion_sec >= 60:
        flags.append(f"S1승격지연({source_to_promotion_sec:.0f}초)")
    if promotion_age_sec >= 45:
        flags.append(f"paper읽기지연({promotion_age_sec:.0f}초)")
    if f1 <= 0.01 and max(react, f3) >= 0.15:
        flags.append("현재1m약함/과거반응주의")
    if pr_src and ("3m" in pr_src or "5m" in pr_src or "15m" in pr_src) and f1 <= 0.01:
        flags.append("반응원천이현재1m아님")
    return {
        "schema": "entry_timing_trace_v494",
        "source_ts": source_ts, "source_key": src_key or "-",
        "s1_promotion_ts": promotion_ts, "s1_promotion_key": promotion_key or "-",
        "source_age_sec": round(source_age_sec, 1), "source_age_min": round(source_age_sec / 60.0, 2),
        "source_to_promotion_sec": round(source_to_promotion_sec, 1),
        "paper_read_delay_sec": round(promotion_age_sec, 1),
        "price_reaction_pct": round(react, 4),
        "price_reaction_source": diag.get("price_reaction_source") or "-",
        "price_reaction_method": diag.get("price_reaction_method") or "-",
        "flow_1m_pct": round(f1, 4), "flow_3m_pct": round(f3, 4),
        "hot_rank_1m": hot1, "hot_rank_3m": hot3,
        "change_1m_source": change_1m_source or "-", "change_3m_source": change_3m_source or "-",
        "flags": flags,
    }

def _v793_list(v: Any) -> List[str]:
    if v is None:
        return []
    if isinstance(v, (list, tuple, set)):
        out: List[str] = []
        for x in v:
            if x is None: continue
            ss = str(x).strip()
            if ss and ss not in out:
                out.append(ss)
        return out
    ss = str(v).strip()
    return [ss] if ss else []

def _v793_sources(ev_or_row: Dict[str, Any]) -> List[Dict[str, Any]]:
    out: List[Dict[str, Any]] = []
    def add(o: Any) -> None:
        if isinstance(o, dict) and o not in out:
            out.append(o)
    add(ev_or_row)
    for key in ('entry_context','entry_diagnostics','raw','canonical_entry_snapshot','entry_snapshot','source_row','candidate_row'):
        obj = ev_or_row.get(key) if isinstance(ev_or_row, dict) else None
        add(obj)
        if isinstance(obj, dict):
            for k2 in ('entry_context','entry_diagnostics','raw','canonical_metric_row','structure_quality_v792'):
                add(obj.get(k2))
    return out

def _v793_quality_from_any(row: Dict[str, Any]) -> Dict[str, Any]:
    srcs = _v793_sources(row)
    q: Dict[str, Any] = {}
    for obj in srcs:
        if isinstance(obj, dict) and isinstance(obj.get('structure_quality_v792'), dict):
            q.update(obj.get('structure_quality_v792') or {})
            break
    good: List[str] = []
    fail: List[str] = []
    early: List[str] = []
    risk: List[str] = []
    exec_cls = ''
    exec_label = ''
    weak_rel = False
    for obj in srcs:
        if not isinstance(obj, dict):
            continue
        good += _v793_list(obj.get('structure_good_tags_v792') or obj.get('good_tags'))
        fail += _v793_list(obj.get('structure_failure_tags_v792') or obj.get('failure_pattern_tags_v792') or obj.get('failure_pattern_tags'))
        early += _v793_list(obj.get('early_fail_watch_tags_v792') or obj.get('early_fail_watch_tags'))
        risk += _v793_list(obj.get('risk_tags') or obj.get('execution_risk_tags'))
        exec_cls = exec_cls or str(obj.get('exec_risk_class_v792') or obj.get('exec_risk_class') or '').strip()
        exec_label = exec_label or str(obj.get('exec_risk_label_v792') or obj.get('exec_risk_label') or '').strip()
        weak_rel = weak_rel or bool(obj.get('weak_market_relative_strength_v792') or obj.get('weak_market_relative_strength'))
    if q:
        good += _v793_list(q.get('good_tags'))
        fail += _v793_list(q.get('failure_pattern_tags'))
        early += _v793_list(q.get('early_fail_watch_tags'))
        risk += _v793_list(q.get('risk_tags'))
        exec_cls = exec_cls or str(q.get('exec_risk_class') or '').strip()
        exec_label = exec_label or str(q.get('exec_risk_label') or '').strip()
        weak_rel = weak_rel or bool(q.get('weak_market_relative_strength'))
    def uniq(xs: List[str], limit: int = 10) -> List[str]:
        out: List[str] = []
        for x in xs:
            ss = str(x).strip()
            if ss and ss not in out:
                out.append(ss)
            if len(out) >= limit:
                break
        return out
    return {
        'schema': 'paper_structure_quality_v793_from_open_row',
        'good_tags': uniq(good, 10),
        'failure_pattern_tags': uniq(fail, 10),
        'early_fail_watch_tags': uniq(early, 8),
        'risk_tags': uniq(risk, 10),
        'exec_risk_class': exec_cls or 'unknown',
        'exec_risk_label': exec_label or exec_cls or 'unknown',
        'weak_market_relative_strength': weak_rel,
    }

def _v793_attach_entry_quality(pos: Dict[str, Any], ev: Dict[str, Any], owner: str = 'open') -> Dict[str, Any]:
    q = _v793_quality_from_any(ev if isinstance(ev, dict) else pos)
    if not q.get('good_tags') and not q.get('failure_pattern_tags') and isinstance(pos.get('structure_quality_v792'), dict):
        q = _v793_quality_from_any(pos)
    pos['structure_quality_v793'] = q
    pos['structure_quality_v792'] = pos.get('structure_quality_v792') or q
    pos['structure_good_tags_v792'] = q.get('good_tags') or []
    pos['structure_failure_tags_v792'] = q.get('failure_pattern_tags') or []
    pos['early_fail_watch_tags_v792'] = q.get('early_fail_watch_tags') or []
    pos['exec_risk_class_v792'] = q.get('exec_risk_class')
    pos['exec_risk_label_v792'] = q.get('exec_risk_label')
    pos['weak_market_relative_strength_v792'] = bool(q.get('weak_market_relative_strength'))
    pos['entry_structure_perf_owner_v793'] = owner
    return pos

def _v793_update_reaction_milestones(pos: Dict[str, Any], age_min: float, net: float, peak: float, gross: Optional[float] = None, gross_peak: Optional[float] = None, gross_trough: Optional[float] = None) -> None:
    """v804: 진입 후 반응을 gross/net으로 분리 봉인한다.

    v800의 -0.10% 반복은 실제 가격이 안 움직였을 때 수수료 반영 net 값으로 보일 수 있다.
    그래서 매매 판단은 바꾸지 않고, 복기표에는 gross_pct/net_pct/reaction_basis를 같이 남긴다.
    """
    obj = pos.get('post_entry_reaction_v800') if isinstance(pos.get('post_entry_reaction_v800'), dict) else {}
    if all(key in obj for key in ('s30','m1','m3','m5','m10')):
        pos['reaction_milestones_reused_v1051'] = True
        return
    fee = fnum(DEFAULT_CONTROL.get('fee_pct_roundtrip'), default=0.10)
    if gross is None:
        gross = net + fee
    if gross_peak is None:
        gross_peak = max(0.0, peak + fee)
    if gross_trough is None:
        gross_trough = fnum(pos.get('gross_trough_pct'), default=gross)
    trough = fnum(pos.get('trough_pct'), default=net)
    def _label(g: float, gp: float, gt: float, n: float, p: float, tr: float) -> str:
        if g <= -0.18 and gp < 0.10:
            return '바로역행'
        if gp < 0.05 and abs(g) < 0.04:
            return '수수료권무반응'
        if gp < 0.08:
            return '무반응'
        if gp >= 0.90:
            return '강한상승'
        if gp >= 0.35:
            return '초반반응'
        if g > 0.03:
            return '약한상승'
        if gt <= -0.30 or tr <= -0.35:
            return '역행주의'
        return '반응약함'
    for minute, key in ((0.5, 's30'), (1.0, 'm1'), (3.0, 'm3'), (5.0, 'm5'), (10.0, 'm10')):
        if age_min >= minute and key not in obj:
            label = _label(float(gross), float(gross_peak), float(gross_trough), float(net), float(peak), float(trough))
            obj[key] = {
                'age_min': round(age_min, 3),
                'gross_pct': round(float(gross), 4),
                'gross_peak_pct': round(float(gross_peak), 4),
                'gross_trough_pct': round(float(gross_trough), 4),
                'net_pct': round(net, 4),
                'peak_pct': round(peak, 4),
                'trough_pct': round(trough, 4),
                'fee_pct_roundtrip': round(fee, 4),
                'reaction_basis_v804': 'gross_price_move_plus_fee_adjusted_net',
                'fee_only_no_move_v804': bool(abs(float(gross)) < 0.04 and abs(float(net) + fee) < 0.04),
                'label': label,
                'recorded_at': now_ts(),
                'recorded_at_text': iso_ts(),
            }
    if obj:
        pos['post_entry_reaction_v800'] = obj
        pos['post_entry_reaction_basis_v804'] = 'gross/net separated'
        # old score/review readers still look at v793 keys; keep them fed from the same owner.
        legacy = pos.get('post_entry_reaction_v793') if isinstance(pos.get('post_entry_reaction_v793'), dict) else {}
        for src, dst in (('m1','m1'), ('m3','m3')):
            if src in obj and dst not in legacy:
                legacy[dst] = obj[src]
        if legacy:
            pos['post_entry_reaction_v793'] = legacy

def _v793_loss_similarity(row: Dict[str, Any]) -> Dict[str, Any]:
    q = _v793_quality_from_any(row)
    react = row.get('post_entry_reaction_v793') if isinstance(row.get('post_entry_reaction_v793'), dict) else {}
    score = 0
    reasons: List[str] = []
    for x in q.get('failure_pattern_tags') or []:
        score += 12; reasons.append(str(x))
    if q.get('exec_risk_class') in ('hard_exec_risk',):
        score += 20; reasons.append('실행비용높음')
    elif q.get('exec_risk_class') in ('exec_recheck','spread_only_recheckable'):
        score += 8; reasons.append('실행위험재확인')
    m1 = react.get('m1') if isinstance(react.get('m1'), dict) else {}
    m3 = react.get('m3') if isinstance(react.get('m3'), dict) else {}
    if str(m1.get('label') or '') in ('no_reaction','early_adverse'):
        score += 18; reasons.append('1분반응없음')
    if str(m3.get('label') or '') in ('no_reaction','early_adverse'):
        score += 14; reasons.append('3분반응없음')
    if fnum(row.get('peak_pct'), default=0.0) < 0.20 and fnum(row.get('pnl_pct'), row.get('profit_pct'), default=0.0) <= 0:
        score += 16; reasons.append('최고수익낮음')
    label = 'high' if score >= 45 else ('mid' if score >= 25 else ('low' if score > 0 else 'none'))
    return {'schema': 'loss_similarity_v793', 'score': int(score), 'label': label, 'reasons': reasons[:8]}

EXIT_LABELS = {
    "take_profit": "✅ 익절 종료",
    "stop_loss": "❌ 손절 종료",
    "protect_stop_after_tp": "🛡️ 익절 후 보호청산",
    "slow_no_progress": "⚠️ 지지부진 종료",
    "fast_fail_stop": "📉 빠른실패 정리",
    "time_exit": "⏱️ 시간 종료",
    "spike_fast_fail_stop": "⚡ 급등형 빠른실패",
    "spike_runner_trailing": "🏃 급등형 추적청산",
    "spike_time_exit": "⏱️ 급등형 시간청산",
}

def _v494_fast_fail_cause(row: Dict[str, Any]) -> Dict[str, Any]:
    """fast_fail 원인 표시용. 청산조건은 변경하지 않는다."""
    diag = row.get("entry_diagnostics") if isinstance(row.get("entry_diagnostics"), dict) else {}
    trace = row.get("entry_timing_trace") if isinstance(row.get("entry_timing_trace"), dict) else {}
    if not trace and isinstance(diag, dict) and isinstance(diag.get("entry_timing_trace"), dict):
        trace = diag.get("entry_timing_trace")
    peak = fnum(row.get("peak_pct"), default=0.0)
    pnl = fnum(row.get("pnl_pct"), default=fnum(row.get("last_pnl_pct"), default=0.0))
    age_min = fnum(row.get("age_min"), default=0.0)
    source_age = fnum(trace.get("source_age_sec"), default=0.0) if isinstance(trace, dict) else 0.0
    source_to_promo = fnum(trace.get("source_to_promotion_sec"), default=0.0) if isinstance(trace, dict) else 0.0
    paper_delay = fnum(trace.get("paper_read_delay_sec"), default=0.0) if isinstance(trace, dict) else 0.0
    react = fnum(diag.get("price_reaction_pct"), default=0.0) if isinstance(diag, dict) else 0.0
    buy = fnum(diag.get("buy_ratio"), default=-1.0) if isinstance(diag, dict) else -1.0
    sustain = fnum(diag.get("buy_sustain_1m"), default=-1.0) if isinstance(diag, dict) else -1.0
    spread = fnum(diag.get("spread_pct"), default=-1.0) if isinstance(diag, dict) else -1.0
    slip = fnum(diag.get("slippage_pct"), default=-1.0) if isinstance(diag, dict) else -1.0
    reasons: List[str] = []
    label = "진입후반응없음"
    if source_to_promo >= 60 or source_age >= 120 or paper_delay >= 45:
        label = "늦은진입 의심"
        if source_age >= 120: reasons.append(f"감지후 {source_age/60.0:.1f}분")
        if source_to_promo >= 60: reasons.append(f"S1승격까지 {source_to_promo:.0f}초")
        if paper_delay >= 45: reasons.append(f"paper읽기 {paper_delay:.0f}초")
    elif react < 0.10:
        label = "진입반응 약함"
        reasons.append(f"가격반응 {react:+.2f}%")
    elif buy >= 0.70 and sustain >= 0.70 and peak <= 0.02:
        label = "체결은 좋지만 가격 안 감"
        reasons.append(f"매수 {buy:.2f} / 지속 {sustain:.2f} / 최고 {peak:+.2f}%")
    elif spread >= 0.20 or slip >= 0.20:
        label = "스프레드·미끄러짐 부담"
        if spread >= 0: reasons.append(f"스프 {spread:.2f}%")
        if slip >= 0: reasons.append(f"미끄러짐 {slip:.2f}%")
    else:
        reasons.append(f"최고 {peak:+.2f}% / 최종 {pnl:+.2f}% / 보유 {age_min:.1f}분")
    return {
        "schema": "fast_fail_cause_v494",
        "label": label,
        "reasons": reasons[:5],
        "source_age_sec": round(source_age, 1),
        "source_to_promotion_sec": round(source_to_promo, 1),
        "paper_read_delay_sec": round(paper_delay, 1),
        "price_reaction_pct": round(react, 4),
        "buy_ratio": round(buy, 4) if buy >= 0 else None,
        "buy_sustain_1m": round(sustain, 4) if sustain >= 0 else None,
        "spread_pct": round(spread, 4) if spread >= 0 else None,
        "slippage_pct": round(slip, 4) if slip >= 0 else None,
    }

def close_review_tag(peak: float, pnl: float, reason: str) -> str:
    giveback = peak - pnl
    if peak >= 0.70 and pnl < 0:
        return "보호익절 필요 후보"
    if peak >= 0.70 and giveback >= 0.55:
        return "수익 되돌림 큼"
    if reason == "fast_fail_stop":
        return "빠른실패 정리 작동"
    if pnl <= -0.60 and peak < 0.25:
        return "빠른실패 정리 후보"
    if reason == "protect_stop_after_tp":
        return "보호익절 작동"
    if pnl > 0 and peak - pnl <= 0.35:
        return "수익 보존 양호"
    return "관찰"

def update_position(pos: Dict[str, Any], ctrl: Dict[str, Any]) -> Tuple[Dict[str, Any], Optional[Dict[str, Any]]]:
    """Canonical OPEN evaluator. One owner for age -> exit decision -> CLOSED row."""
    cycle_now = now_ts()
    before_update_ts = fnum(pos.get("last_update"), default=0.0) if isinstance(pos, dict) else 0.0
    prepare_open_position_for_exit(pos)
    ticker = normalize_ticker(pos.get("ticker"))
    entry = fnum(pos.get("entry_price"), default=0.0)
    if not ticker or entry <= 0:
        return pos, None
    price = live_price(ticker, fnum(pos.get("current_price"), default=entry))
    gross = ((price / entry) - 1.0) * 100.0 if entry else 0.0
    net = gross - fnum(ctrl.get("fee_pct_roundtrip"), default=0.10)
    pos["current_price"] = price
    pos["last_gross_pct_v804"] = round(gross, 4)
    pos["last_pnl_pct"] = round(net, 4)
    pos["gross_peak_pct"] = max(fnum(pos.get("gross_peak_pct"), default=0.0), gross)
    pos["gross_trough_pct"] = min(fnum(pos.get("gross_trough_pct"), default=0.0), gross)
    pos["peak_pct"] = max(fnum(pos.get("peak_pct"), default=0.0), net)
    pos["trough_pct"] = min(fnum(pos.get("trough_pct"), default=0.0), net)
    pos['highest_price_v983'] = max(fnum(pos.get('highest_price_v983'), default=entry), price)
    pos['lowest_price_v983'] = min(fnum(pos.get('lowest_price_v983'), default=entry), price)
    pos['mfe_pct_v983'] = round(fnum(pos.get('peak_pct'), default=0.0), 4)
    pos['mae_pct_v983'] = round(fnum(pos.get('trough_pct'), default=0.0), 4)
    pos['giveback_pct_v983'] = round(max(0.0, fnum(pos.get('peak_pct'), default=0.0)-net), 4)
    shadow = pos.get('profitability_shadow_trailing_v1034') if isinstance(pos.get('profitability_shadow_trailing_v1034'), dict) else {'schema':'profitability_shadow_trailing_v1034','trigger_pct':2.0,'giveback_pct':0.8,'triggered':False,'policy':'shadow observation only; active exit unchanged'}
    if not shadow.get('triggered') and fnum(pos.get('peak_pct'), default=0.0) >= 2.0 and pos['giveback_pct_v983'] >= 0.8 and net > 0:
        shadow.update({'triggered':True,'first_trigger_ts':cycle_now,'first_trigger_text':iso_ts(cycle_now),'shadow_exit_price':price,'shadow_exit_net_pct':round(net,4),'peak_at_trigger_pct':round(fnum(pos.get('peak_pct'),default=0.0),4),'giveback_at_trigger_pct':round(pos['giveback_pct_v983'],4),'source':'paper_open_monitor_exact_poll'})
    shadow['last_checked_ts']=cycle_now; shadow['last_net_pct']=round(net,4); shadow['last_peak_pct']=round(fnum(pos.get('peak_pct'),default=0.0),4); shadow['last_giveback_pct']=round(pos['giveback_pct_v983'],4)
    pos['profitability_shadow_trailing_v1034']=shadow
    _target_v983 = _swing_plan_price(pos, 'target')
    _invalid_v983 = _swing_plan_price(pos, 'invalid')
    if _target_v983 > 0 and price >= _target_v983 and not pos.get('first_target_touch_ts_v983'):
        pos['first_target_touch_ts_v983'] = cycle_now
    if _invalid_v983 > 0 and price <= _invalid_v983 and not pos.get('first_invalid_touch_ts_v983'):
        pos['first_invalid_touch_ts_v983'] = cycle_now
    pos["last_update"] = now_ts()
    try:
        # v1051: OPEN-time entry quality is immutable evidence. Reuse the sealed object;
        # only legacy/missing rows are backfilled once.
        if not isinstance(pos.get("structure_quality_v793"), dict):
            _v793_attach_entry_quality(pos, pos, "update_backfill_v1051")
            pos["entry_quality_backfilled_once_v1051"] = True
        else:
            pos["entry_quality_reused_v1051"] = True
    except Exception as exc:
        log_error("v793_attach_quality_update", exc)
    opened_at = read_opened_at_for_exit(pos)
    if opened_at <= 0:
        pos["exit_monitor_error"] = "missing_opened_at"
        pos["last_exit_decision"] = "error"
        pos["last_exit_decision_reason"] = "missing_opened_at"
        pos["last_exit_decision_detail"] = "OPEN 시각이 없어 청산 나이를 계산할 수 없음"
        return pos, None
    if opened_at > cycle_now + 60.0:
        pos["exit_monitor_error"] = "opened_at_in_future"
        pos["last_exit_decision"] = "error"
        pos["last_exit_decision_reason"] = "opened_at_in_future"
        pos["last_exit_decision_detail"] = "OPEN 시각이 현재보다 미래로 기록됨"
        return pos, None
    age_min = max(0.0, (cycle_now - opened_at) / 60.0)
    peak = fnum(pos.get("peak_pct"), default=0.0)
    try:
        _v793_update_reaction_milestones(pos, age_min, net, peak, gross, fnum(pos.get('gross_peak_pct'), default=gross), fnum(pos.get('gross_trough_pct'), default=gross))
    except Exception as exc:
        log_error("v793_reaction_milestone", exc)
    decision = _exit_decision_spine(pos, age_min, peak, net, ctrl)
    pos["exit_decision_spine"] = decision
    pos["last_exit_decision"] = decision.get("action")
    pos["last_exit_decision_reason"] = decision.get("reason") or "hold"
    pos["last_exit_decision_detail"] = decision.get("detail") or "보유"
    if decision.get("action") == "extend":
        ext_count = int(fnum(pos.get("time_exit_extension_count"), default=0)) + 1
        extend_min = fnum(ctrl.get("profit_run_extend_minutes"), default=15.0)
        pos["time_exit_extension_count"] = ext_count
        pos["time_exit_extended_at"] = now_ts()
        pos["time_exit_extended_until_age_min"] = round(age_min + extend_min, 4)
        pos["time_exit_extension_reason"] = decision.get("detail") or "수익권 유동보유 연장"
        return pos, None
    if decision.get("action") != "close":
        return pos, None
    reason = str(decision.get("reason") or "").strip()
    detail = str(decision.get("detail") or reason).strip()
    if not reason:
        return pos, None
    closed_ts = now_ts()
    hold_sec = max(0, int(closed_ts - opened_at))
    closed = dict(pos)
    current_main_version = active_main_version()
    current_patch_version = active_patch_version()
    if current_main_version:
        # 파일 버전은 참고값으로 유지한다. 성과판의 주 기준은 아래 score_patch_version이다.
        raw_version_before_close = closed.get("score_main_version") or closed.get("closed_main_version") or closed.get("main_version") or closed.get("deploy_version") or closed.get("opened_main_version")
        if raw_version_before_close and not closed.get("source_main_version_raw"):
            closed["source_main_version_raw"] = raw_version_before_close
        for key in ("score_main_version", "closed_main_version", "opened_main_version", "main_version", "deploy_version", "score_file_version"):
            closed[key] = current_main_version
    if current_patch_version:
        # v634: 성과 기준은 OPEN 당시 entry_build_key/score_patch_version으로 고정한다.
        # CLOSED 시점 버전은 close_patch_version/closed_patch_version 참고값으로만 남긴다.
        entry_patch = closed.get("entry_build_key") or closed.get("score_patch_version") or closed.get("opened_patch_version") or closed.get("patch_version") or closed.get("run_patch_version") or closed.get("deploy_patch_version")
        if entry_patch and not closed.get("source_patch_version_raw"):
            closed["source_patch_version_raw"] = entry_patch
        if entry_patch:
            for key in ("entry_build_key", "open_build_key", "entry_patch_version", "score_patch_version", "opened_patch_version", "patch_version", "run_patch_version", "deploy_patch_version"):
                closed.setdefault(key, entry_patch)
        closed["closed_patch_version"] = current_patch_version
        closed["close_patch_version"] = current_patch_version
    closed.update({
        "closed_at": closed_ts,
        "closed_ts": closed_ts,
        "closed_at_text": iso_ts(closed_ts),
        "closed_day_kst": _kst_day_key(closed_ts),
        "closed_result_key": (
            "closed:" + str(closed.get("pos_id") or closed.get("event_id") or closed.get("entry_build_key"))
            if (closed.get("pos_id") or closed.get("event_id") or closed.get("entry_build_key")) else ""
        ),
        "closed_result_key_source": (
            "pos_id" if closed.get("pos_id") else ("event_id" if closed.get("event_id") else ("entry_build_key" if closed.get("entry_build_key") else "missing"))
        ),
        "exit_price": price,
        "pnl_pct": round(net, 4),
        "peak_pct": round(peak, 4),
        "trough_pct": round(fnum(pos.get("trough_pct"), default=0.0), 4),
        "missed_profit_pct": round(max(0.0, peak - net), 4),
        "giveback_pct": round(max(0.0, peak - net), 4),
        "went_negative_after_profit": bool(peak >= 0.70 and net < 0),
        "close_review_tag": close_review_tag(peak, net, reason),
        "age_min": round(age_min, 2),
        "hold_sec": hold_sec,
        "exit_reason": reason,
        "exit_rule": reason,
        "exit_rule_label": EXIT_LABELS.get(reason, reason),
        "exit_rule_reason": detail,
        "exit_decision_schema": "alt_swing_exit_spine_v977",
        "exit_decision_spine": decision,
        "time_exit_extension_count": int(fnum(pos.get("time_exit_extension_count"), default=0)),
        "time_exit_extension_reason": pos.get("time_exit_extension_reason") or "",
        "closed_paper_version": VERSION,
        "close_source": "paper_bot_v0.953_alt_swing_exit",
    })
    if reason == "fast_fail_stop":
        try:
            cause = _v494_fast_fail_cause(closed)
            closed["fast_fail_cause"] = cause
            closed["fast_fail_cause_label"] = cause.get("label")
            closed["fast_fail_cause_reasons"] = cause.get("reasons") or []
        except Exception as exc:
            log_error("v494_fast_fail_cause", exc)
    closed = _v983_seal_closed_evidence(closed, pos, ctrl)
    closed = finalize_closed_position_metadata(pos, closed, ctrl, cycle_now, before_update_ts)
    return pos, closed

def fmt_price(v: Any) -> str:
    x = fnum(v, default=0.0)
    if x >= 1000:
        return f"{x:,.0f}"
    if x >= 1:
        return f"{x:,.4f}"
    return f"{x:,.8f}"

def _decision_line(obj: Any, label: str) -> str:
    if not isinstance(obj, dict):
        return f"- {label}: -"
    t = obj.get("ticker") or "-"
    status = obj.get("status") or "-"
    reason = str(obj.get("reason") or "-")
    react = fnum(obj.get("price_reaction_pct"), default=0.0)
    buy = fnum(obj.get("buy_ratio"), default=-1.0)
    sustain = fnum(obj.get("buy_sustain_1m"), default=-1.0)
    spread = fnum(obj.get("spread_pct"), default=-1.0)
    nums = []
    nums.append(f"반응 {react:+.2f}%")
    if buy >= 0:
        nums.append(f"매수 {buy:.2f}")
    if sustain >= 0:
        nums.append(f"지속 {sustain:.2f}")
    if spread >= 0:
        nums.append(f"스프 {spread:.2f}%")
    return f"- {label}: {t} / {status} / {' · '.join(nums)} / {reason[:180]}"

def _summary_reason_text(obj: Any) -> str:
    if not isinstance(obj, dict):
        return "-"
    reason = str(obj.get("reason") or "").strip()
    if not reason:
        reasons = obj.get("block_reasons") or obj.get("missing_info") or []
        if isinstance(reasons, list) and reasons:
            reason = str(reasons[0]).strip()
    return reason[:160] if reason else "-"

def _summary_counter_add(counter: Counter, text: str, amount: int = 1) -> None:
    text = str(text or "").strip()
    if not text or text == "-":
        return
    # 너무 긴 종목별 수치가 TOP을 어지럽히지 않도록 앞부분만 묶는다.
    key = text.split("/")[0].strip()[:90]
    if key:
        counter[key] += max(1, int(amount))

def _summary_top(counter: Counter, limit: int = 5) -> str:
    if not isinstance(counter, Counter) or not counter:
        return "-"
    return " / ".join(f"{k} {v}" for k, v in counter.most_common(limit))

def _reset_s1_summary_bucket(now: Optional[float] = None) -> Dict[str, Any]:
    ts = fnum(now, default=now_ts())
    bucket = {
        "start_ts": ts,
        "cycles": 0,
        "s1_seen": 0,
        "selected_s1": 0,
        "paper_final_block": 0,  # legacy counter name
        "paper_entry_hold": 0,
        "micro_preopen_wait": 0,
        "opened": 0,
        "closed": 0,
        "latest_count_max": 0,
        "fresh_count_max": 0,
        "final_block_reasons": Counter(),
        "skip_reasons": Counter(),
        "last_paper_final_block": None,
        "last_skip": None,
        "last_open_try": None,
        "last_s1_seen": None,
    }
    _S1_DECISION_SUMMARY_BUCKET.clear()
    _S1_DECISION_SUMMARY_BUCKET.update(bucket)
    return _S1_DECISION_SUMMARY_BUCKET

def _ensure_s1_summary_bucket() -> Dict[str, Any]:
    if not isinstance(_S1_DECISION_SUMMARY_BUCKET, dict) or not _S1_DECISION_SUMMARY_BUCKET.get("start_ts"):
        return _reset_s1_summary_bucket(now_ts())
    if not isinstance(_S1_DECISION_SUMMARY_BUCKET.get("final_block_reasons"), Counter):
        _S1_DECISION_SUMMARY_BUCKET["final_block_reasons"] = Counter()
    if not isinstance(_S1_DECISION_SUMMARY_BUCKET.get("skip_reasons"), Counter):
        _S1_DECISION_SUMMARY_BUCKET["skip_reasons"] = Counter()
    return _S1_DECISION_SUMMARY_BUCKET

def notify_s1_decision_summary__L3259(pick_stats: Dict[str, Any], opened_count: int = 0, closed_count: int = 0, ctrl: Optional[Dict[str, Any]] = None) -> None:
    """S1/final block 흐름은 30분 단위로 묶어 보낸다.

    OPEN/CLOSED 즉시 알림은 유지한다. 후보/OPEN보류/무반응 재확인은 매 cycle마다
    보내지 않고, 1시간 동안 누적해서 가장 많은 보류 사유와 마지막 사례만 보여준다.
    조건/전략/장부는 건드리지 않는 알림 안정화 계층이다.
    """
    if not isinstance(pick_stats, dict):
        return
    ctrl = ctrl if isinstance(ctrl, dict) else {}
    if not bool(ctrl.get("notify_on_s1_decision_summary", True)):
        return

    now = now_ts()
    interval = fnum(
        ctrl.get("notify_s1_decision_summary_interval_sec", ctrl.get("notify_s1_decision_summary_min_interval_sec", 3600)),
        default=3600.0,
    )
    interval = max(3600.0, interval)  # v513: 후보요약은 최소 1시간. 조건/전략 판단은 유지.
    bucket = _ensure_s1_summary_bucket()

    s1_seen = int(fnum(pick_stats.get("s1_seen"), default=0.0))
    selected = int(fnum(pick_stats.get("selected_s1"), default=0.0))
    final_block = int(fnum(pick_stats.get("paper_final_block"), default=0.0))
    entry_hold = int(fnum(pick_stats.get("paper_entry_hold"), default=final_block))
    micro_wait = int(fnum(pick_stats.get("micro_preopen_wait"), default=0.0))

    bucket["cycles"] = int(bucket.get("cycles", 0)) + 1
    bucket["s1_seen"] = int(bucket.get("s1_seen", 0)) + s1_seen
    bucket["selected_s1"] = int(bucket.get("selected_s1", 0)) + selected
    bucket["paper_final_block"] = int(bucket.get("paper_final_block", 0)) + final_block
    bucket["paper_entry_hold"] = int(bucket.get("paper_entry_hold", 0)) + entry_hold
    bucket["micro_preopen_wait"] = int(bucket.get("micro_preopen_wait", 0)) + micro_wait
    bucket["opened"] = int(bucket.get("opened", 0)) + int(opened_count or 0)
    bucket["closed"] = int(bucket.get("closed", 0)) + int(closed_count or 0)
    bucket["latest_count_max"] = max(int(bucket.get("latest_count_max", 0)), int(fnum(pick_stats.get("latest_count"), default=0.0)))
    bucket["fresh_count_max"] = max(int(bucket.get("fresh_count_max", 0)), int(fnum(pick_stats.get("merged_fresh"), default=0.0)))

    last_block = pick_stats.get("last_paper_entry_hold") or pick_stats.get("last_paper_final_block")
    last_skip = pick_stats.get("last_skip")
    last_open = pick_stats.get("last_open_try")
    last_seen = pick_stats.get("last_s1_seen")

    if isinstance(last_block, dict):
        bucket["last_paper_final_block"] = last_block
        _summary_counter_add(bucket["final_block_reasons"], _summary_reason_text(last_block), amount=max(1, final_block))
    if isinstance(last_skip, dict):
        bucket["last_skip"] = last_skip
        _summary_counter_add(bucket["skip_reasons"], _summary_reason_text(last_skip), amount=1)
    if isinstance(last_open, dict):
        bucket["last_open_try"] = last_open
    if isinstance(last_seen, dict):
        bucket["last_s1_seen"] = last_seen

    elapsed = now - fnum(bucket.get("start_ts"), default=now)
    if elapsed < interval:
        return

    meaningful = (
        int(bucket.get("s1_seen", 0))
        + int(bucket.get("selected_s1", 0))
        + int(bucket.get("paper_entry_hold", bucket.get("paper_final_block", 0)))
        + int(bucket.get("opened", 0))
        + int(bucket.get("closed", 0))
    )
    if meaningful <= 0:
        _reset_s1_summary_bucket(now)
        return

    final_top = _summary_top(bucket.get("final_block_reasons"), limit=5)
    skip_top = _summary_top(bucket.get("skip_reasons"), limit=5)
    title = "🧭 paper S1 1시간 재확인/보류 요약"
    if "무반응" in final_top:
        title = "🧭 paper 1시간 무반응 재확인 보류 요약"

    minutes = max(1, int(round(elapsed / 60.0)))
    lines = [
        title,
        f"- 기간: 약 {minutes}분 / cycle {bucket.get('cycles', 0)}회",
        f"- S1감지 {bucket.get('s1_seen', 0)} / OPEN선택 {bucket.get('selected_s1', 0)} / OPEN보류 {bucket.get('paper_entry_hold', bucket.get('paper_final_block', 0))}",
        f"- OPEN {bucket.get('opened', 0)} / CLOSED {bucket.get('closed', 0)} / micro대기 {bucket.get('micro_preopen_wait', 0)}",
        f"- 후보 max latest {bucket.get('latest_count_max', 0)} / fresh {bucket.get('fresh_count_max', 0)}",
        f"- 보류 TOP: {final_top}",
        f"- 스킵 TOP: {skip_top}",
        _decision_line(bucket.get("last_paper_final_block"), "마지막 OPEN보류"),
        _decision_line(bucket.get("last_open_try"), "마지막 OPEN시도"),
        _decision_line(bucket.get("last_s1_seen"), "마지막 S1감지"),
        f"- paper: {VERSION}",
    ]
    send_message("\n".join(lines))
    _reset_s1_summary_bucket(now)

def _reset_hot_market_bucket(now: Optional[float] = None) -> Dict[str, Any]:
    ts = fnum(now, default=now_ts())
    bucket = {
        "start_ts": ts,
        "last_immediate_ts": 0.0,
        "cycles": 0,
        "hot_seen": 0,
        "best_by_ticker": {},
        "last_cache_age": None,
        "last_by_ticker": {},
    }
    _HOT_MARKET_NOTIFY_BUCKET.clear(); _HOT_MARKET_NOTIFY_BUCKET.update(bucket); return _HOT_MARKET_NOTIFY_BUCKET

def _ensure_hot_market_bucket() -> Dict[str, Any]:
    if not isinstance(_HOT_MARKET_NOTIFY_BUCKET, dict) or not _HOT_MARKET_NOTIFY_BUCKET.get("start_ts"):
        return _reset_hot_market_bucket(now_ts())
    if not isinstance(_HOT_MARKET_NOTIFY_BUCKET.get("best_by_ticker"), dict):
        _HOT_MARKET_NOTIFY_BUCKET["best_by_ticker"] = {}
    if not isinstance(_HOT_MARKET_NOTIFY_BUCKET.get("last_by_ticker"), dict):
        _HOT_MARKET_NOTIFY_BUCKET["last_by_ticker"] = {}
    return _HOT_MARKET_NOTIFY_BUCKET

def _load_hot_rank_rows(ctrl: Dict[str, Any]) -> Tuple[List[Dict[str, Any]], float, Dict[str, Any]]:
    obj = load_json(FILES.get("hot_rank", BASE_DIR / "clean_scanner_hot_rank_cache.json"), {}) or {}
    if not isinstance(obj, dict): return [], 999999.0, {}
    updated = fnum(obj.get("updated_ts"), default=0.0)
    age = now_ts() - updated if updated > 0 else 999999.0
    rows = obj.get("rows") if isinstance(obj.get("rows"), list) else []
    ttl = fnum(ctrl.get("notify_market_hot_cache_ttl_sec"), default=90.0)
    if age > max(10.0, ttl): return [], age, obj
    return [r for r in rows if isinstance(r, dict)], age, obj

def _hot_row_score(row: Dict[str, Any]) -> float:
    c1=fnum(row.get("scanner_change_1m_pct"),default=0.0); c3=fnum(row.get("scanner_change_3m_pct"),default=0.0)
    r1=fnum(row.get("scanner_hot_rank_1m"),default=9999.0); r3=fnum(row.get("scanner_hot_rank_3m"),default=9999.0)
    return max(0.0,c1)*4.0 + max(0.0,c3)*2.0 + max(0.0,12.0-min(r1,r3))

def _hot_candidate_stage_index() -> Dict[str, Dict[str, Any]]:
    """hot-rank 알림에 후보판정 단계만 붙인다. OPEN/조건 판단은 바꾸지 않는다."""
    idx: Dict[str, Dict[str, Any]] = {}
    try:
        for r in read_jsonl_tail(FILES.get("paper_latest", BASE_DIR / "paper_candidates_latest.jsonl"), 300):
            if not isinstance(r, dict):
                continue
            t = normalize_ticker(r.get("ticker") or r.get("market") or r.get("symbol"))
            if not t:
                continue
            idx[t] = r
    except Exception:
        pass
    return idx

def _v514_short_text(value: Any, limit: int = 38) -> str:
    if value is None:
        return ""
    if isinstance(value, (list, tuple)):
        parts = [str(x).strip() for x in value if str(x).strip()]
        txt = " / ".join(parts[:3])
    elif isinstance(value, dict):
        parts = []
        for k, v in value.items():
            if v in (None, "", [], {}):
                continue
            parts.append(f"{k}:{v}")
        txt = " / ".join(parts[:3])
    else:
        txt = str(value).strip()
    txt = re.sub(r"\s+", " ", txt)
    if len(txt) > limit:
        txt = txt[:limit-1] + "…"
    return txt

def _v514_first_text(row: Dict[str, Any], keys: Iterable[str], limit: int = 38) -> str:
    if not isinstance(row, dict):
        return ""
    for k in keys:
        if k in row and row.get(k) not in (None, "", [], {}):
            txt = _v514_short_text(row.get(k), limit=limit)
            if txt:
                return txt
    return ""

def _v514_time_label_from_row(row: Dict[str, Any]) -> str:
    ts = fnum(row.get("detected_ts"), row.get("first_seen_ts"), row.get("created_at"), row.get("updated_ts"), row.get("ts"), default=0.0)
    if ts <= 0:
        return "포착 -"
    try:
        return "포착 " + time.strftime("%H:%M:%S", time.localtime(ts))
    except Exception:
        return "포착 -"

def notify_market_hot_summary__L3524(ctrl: Optional[Dict[str, Any]] = None) -> None:
    # 시장 급등 관찰 알림. 매수/진입 조건은 바꾸지 않고, 실시간 알림만 강한 급등 중심으로 줄인다.
    ctrl = ctrl if isinstance(ctrl, dict) else load_control()
    if not bool(ctrl.get("notify_market_hot_alert", True)): return
    bucket=_ensure_hot_market_bucket(); rows, age, meta=_load_hot_rank_rows(ctrl); now=now_ts()
    interval=max(3600.0,fnum(ctrl.get("notify_market_hot_summary_interval_sec"),default=3600.0))
    immediate_interval=max(3600.0,fnum(ctrl.get("notify_market_hot_global_min_interval_sec"),default=3600.0))
    ticker_cooldown=max(3600.0,fnum(ctrl.get("notify_market_hot_ticker_cooldown_sec", ctrl.get("notify_market_hot_immediate_min_interval_sec")),default=3600.0))
    max_items=max(1,int(fnum(ctrl.get("notify_market_hot_max_items"),default=4)))
    top_n=max(1,int(fnum(ctrl.get("notify_market_hot_rank_top_n"),default=5)))
    weak_th1=fnum(ctrl.get("notify_market_hot_1m_pct"),default=0.80); weak_th3=fnum(ctrl.get("notify_market_hot_3m_pct"),default=1.50)
    strong_th1=fnum(ctrl.get("notify_market_hot_immediate_1m_pct"),default=1.50); strong_th3=fnum(ctrl.get("notify_market_hot_immediate_3m_pct"),default=2.50)
    stage_idx = _hot_candidate_stage_index()
    good=[]
    strong=[]
    for r in rows:
        c1=fnum(r.get("scanner_change_1m_pct"),default=0.0); c3=fnum(r.get("scanner_change_3m_pct"),default=0.0)
        r1=fnum(r.get("scanner_hot_rank_1m"),default=9999.0); r3=fnum(r.get("scanner_hot_rank_3m"),default=9999.0)
        is_good = c1>=weak_th1 or c3>=weak_th3 or (r1<=top_n and c1>=0.20) or (r3<=top_n and c3>=0.40)
        is_strong = c1>=strong_th1 or c3>=strong_th3 or (r1<=3 and c1>=weak_th1) or (r3<=3 and c3>=weak_th3)
        if is_good:
            rr=dict(r); rr["_hot_score"]=_hot_row_score(rr); good.append(rr)
            if is_strong:
                strong.append(rr)
    good.sort(key=lambda x:fnum(x.get("_hot_score"),default=0.0), reverse=True)
    strong.sort(key=lambda x:fnum(x.get("_hot_score"),default=0.0), reverse=True)
    bucket["cycles"]=int(bucket.get("cycles",0))+1
    bucket["hot_seen"]=int(bucket.get("hot_seen",0))+len(good)
    bucket["strong_seen"]=int(bucket.get("strong_seen",0))+len(strong)
    bucket["last_cache_age"]=round(age,1) if age<999999 else None
    best=bucket.get("best_by_ticker") if isinstance(bucket.get("best_by_ticker"),dict) else {}
    for r in good[:max_items*3]:
        t=normalize_ticker(r.get("ticker") or r.get("market") or r.get("symbol"))
        if t and (t not in best or _hot_row_score(r)>_hot_row_score(best[t])):
            best[t]=r
    bucket["best_by_ticker"]=best

    last_by_ticker=bucket.get("last_by_ticker") if isinstance(bucket.get("last_by_ticker"),dict) else {}
    fresh_strong=[]
    for r in strong:
        t=normalize_ticker(r.get("ticker") or r.get("market") or r.get("symbol"))
        if not t:
            continue
        if now-fnum(last_by_ticker.get(t),default=0.0) >= ticker_cooldown:
            fresh_strong.append(r)
    if bool(ctrl.get("notify_market_hot_immediate_enabled", False)) and fresh_strong and now-fnum(bucket.get("last_immediate_ts"),default=0.0)>=immediate_interval:
        lines=[
            "⚡ 강한 급등 감지 / hot-rank",
            f"- 즉시 기준 1m +{strong_th1:.2f}% 또는 3m +{strong_th3:.2f}% / 약한 급등은 1시간 요약",
            f"- 신규/쿨다운 통과 {min(len(fresh_strong), max_items)}개 · 같은 종목 {int(round(ticker_cooldown/60.0))}분 쿨다운 · 전체 {int(round(immediate_interval/60.0))}분 묶음",
            "- 매수 알림 아님 · S1/OPEN 여부는 별도 판단",
        ]
        for r in fresh_strong[:max_items]:
            lines.append("- "+_format_hot_row(r, stage_idx))
            t=normalize_ticker(r.get("ticker") or r.get("market") or r.get("symbol"))
            if t:
                last_by_ticker[t]=now
        bucket["last_by_ticker"]=last_by_ticker
        lines.append(f"- paper: {VERSION}")
        send_message("\n".join(lines))
        bucket["last_immediate_ts"]=now
    elapsed=now-fnum(bucket.get("start_ts"),default=now)
    if elapsed<interval:
        return
    best_rows=list(best.values()); best_rows.sort(key=lambda x:_hot_row_score(x), reverse=True)
    if not best_rows:
        _reset_hot_market_bucket(now); return
    minutes=max(1,int(round(elapsed/60.0)))
    lines=["🧭 시장 hot-rank 1시간 요약", f"- 기간 약 {minutes}분 / cycle {bucket.get('cycles',0)}회 / 감지누적 {bucket.get('hot_seen',0)} / 강한급등 {bucket.get('strong_seen',0)}", f"- cache age {bucket.get('last_cache_age','-')}s / row {meta.get('row_count','-') if isinstance(meta,dict) else '-'}", "- 매수 알림 아님 · 많이 오른 종목/포착시간/후보단계 연결 확인용"]
    for r in best_rows[:max_items]:
        lines.append("- "+_format_hot_row(r, stage_idx))
    lines.append(f"- paper: {VERSION}")
    send_message("\n".join(lines))
    _reset_hot_market_bucket(now)

def _score_stat(rows: List[Dict[str, Any]]) -> Dict[str, Any]:
    n = len(rows)
    wins = sum(1 for r in rows if fnum(r.get("pnl_pct"), r.get("profit_pct"), default=0.0) > 0)
    losses = max(0, n - wins)
    total = sum(fnum(r.get("pnl_pct"), r.get("profit_pct"), default=0.0) for r in rows)
    return {"n": n, "wins": wins, "losses": losses, "win_rate": (wins / n * 100.0 if n else 0.0), "total": total, "avg": (total / n if n else 0.0)}

def _v557_row_ts(row: Dict[str, Any]) -> float:
    """CLOSED canonical timestamp reader.

    Numeric closed_ts is the owner.  Text timestamps are parsed as KST when
    timezone information is absent, so a UTC server cannot push a KST CLOSED
    row nine hours into the future and exclude it from today's score/review.
    """
    if not isinstance(row, dict):
        return 0.0
    # Canonical numeric fields first.
    for k in ("closed_ts", "exit_ts", "exited_at", "closed_at", "timestamp", "ts", "updated_at", "created_at"):
        v = row.get(k)
        if v in (None, "", [], {}):
            continue
        try:
            if isinstance(v, (int, float)):
                x = float(v)
                if x > 0:
                    return x / 1000.0 if x > 100000000000 else x
            if isinstance(v, str):
                vv = v.strip()
                if vv.replace(".", "", 1).isdigit():
                    x = float(vv)
                    if x > 0:
                        return x / 1000.0 if x > 100000000000 else x
        except Exception:
            continue
    # Display strings are secondary evidence only.  Naive strings mean KST.
    import datetime as _dt
    kst = _dt.timezone(_dt.timedelta(hours=9))
    for k in ("closed_at_text", "closed_time", "exit_time_text", "ts_text", "updated_at_text"):
        v = row.get(k)
        if not isinstance(v, str) or not v.strip():
            continue
        vv = v.strip().replace(" KST", "+09:00").replace("Z", "+00:00")
        try:
            dt = _dt.datetime.fromisoformat(vv.replace("T", " "))
            if dt.tzinfo is None:
                dt = dt.replace(tzinfo=kst)
            return dt.timestamp()
        except Exception:
            continue
    return 0.0

_STATUS_PENDING: Dict[str, Any] = {}

_STATUS_WRITE_COUNT = 0

_STATUS_WRITER_OWNER = 'paper_bot_single_status_writer_v994'

_PROCESS_STARTED_AT = now_ts()

_PROCESS_STARTED_TEXT = iso_ts(_PROCESS_STARTED_AT)

_RUNTIME_INSTANCE_ID = f'paper-{os.getpid()}-{time.time_ns()}'

_STATUS_IDENTITY_FIELDS = {
    'pid','self_pid','process_pid','main_pid','writer_pid','status_writer_pid',
    'running','process_alive','stop_reason','process_started_at','process_started_text',
    'started_at','started_at_text','writer_started_at','writer_started_text',
    'runtime_instance_id','status_writer_owner','status_writer_count',
}

def _reset_status_runtime_identity() -> None:
    """Start one clean status identity for this exact OS process."""
    global _LAST_STATUS, _STATUS_PENDING, _STATUS_WRITE_COUNT
    global _PROCESS_STARTED_AT, _PROCESS_STARTED_TEXT, _RUNTIME_INSTANCE_ID
    global _STOP, _STOP_REASON, _STOP_REQUESTED_AT, _STOP_WATCHDOG_STARTED
    global _RUNTIME_PHASE, _RUNTIME_PHASE_AT, _RUNTIME_PHASE_DETAIL, _EXACT_COMMIT_DEPTH
    _LAST_STATUS = {}
    _STATUS_PENDING = {}
    _STATUS_WRITE_COUNT = 0
    _STOP = False
    _STOP_REASON = 'running'
    _STOP_REQUESTED_AT = 0.0
    _STOP_WATCHDOG_STARTED = False
    _EXACT_COMMIT_DEPTH = 0
    _RUNTIME_PHASE = 'process_start'
    _RUNTIME_PHASE_AT = now_ts()
    _RUNTIME_PHASE_DETAIL = ''
    _PROCESS_STARTED_AT = now_ts()
    _PROCESS_STARTED_TEXT = iso_ts(_PROCESS_STARTED_AT)
    _RUNTIME_INSTANCE_ID = f'paper-{os.getpid()}-{time.time_ns()}'

def _stage_status_fields(fields: Optional[Dict[str, Any]]) -> None:
    """Stage auxiliary evidence only; runtime identity always comes from this process."""
    global _LAST_STATUS
    if not isinstance(fields, dict):
        return
    clean = {k: v for k, v in fields.items() if k not in _STATUS_IDENTITY_FIELDS}
    _STATUS_PENDING.update(clean)
    if isinstance(_LAST_STATUS, dict):
        _LAST_STATUS.update(clean)

def _runtime_status_identity(running: bool, nowv: float, stop_reason: str = '') -> Dict[str, Any]:
    pid = os.getpid()
    return {
        'version': VERSION,
        'paper_version': VERSION,
        'active_reader_version': VERSION,
        'build': BUILD_LABEL,
        'paper_runtime_build': BUILD_LABEL,
        'pid': pid,
        'self_pid': pid,
        'process_pid': pid,
        'main_pid': pid,
        'writer_pid': pid,
        'status_writer_pid': pid,
        'status_pid': pid,
        'running': bool(running),
        'process_alive': bool(running),
        'stop_reason': '' if running else str(stop_reason or _STOP_REASON or 'stopped'),
        'process_started_at': _PROCESS_STARTED_AT,
        'process_started_text': _PROCESS_STARTED_TEXT,
        'started_at': _PROCESS_STARTED_AT,
        'started_at_text': _PROCESS_STARTED_TEXT,
        'writer_started_at': _PROCESS_STARTED_AT,
        'writer_started_text': _PROCESS_STARTED_TEXT,
        'runtime_instance_id': _RUNTIME_INSTANCE_ID,
        'updated_at': nowv,
        'updated_at_text': iso_ts(nowv),
        'last_write_at': nowv,
        'last_write_text': iso_ts(nowv),
        'status_writer_owner': _STATUS_WRITER_OWNER,
        'status_writer_count': 1,
        'legacy_status_writers_removed': True,
        'status_identity_source': 'os.getpid_direct_each_write',
        'status_tmp_mode': 'unique_pid_time_ns_fsync_atomic_replace',
        'status_path': str(FILES['status']),
        'runtime_phase': _RUNTIME_PHASE,
        'runtime_phase_at': _RUNTIME_PHASE_AT,
        'runtime_phase_detail': _RUNTIME_PHASE_DETAIL,
        'stop_requested_at': _STOP_REQUESTED_AT or None,
        'exact_commit_active': bool(_EXACT_COMMIT_DEPTH),
        'score_review_writer': _PERFORMANCE_WRITER_OWNER,
        'review_schema': 'paper_review_spine_v994_interruptible_runtime_single_spine',
    }

def write_status__L4253(status: Dict[str, Any]) -> None:
    """Only owner of paper_bot_status.json; final identity is stamped after every helper."""
    global _LAST_STATUS, _STATUS_WRITE_COUNT
    incoming = dict(status or {})
    st = dict(_LAST_STATUS) if isinstance(_LAST_STATUS, dict) else {}
    st.update(_STATUS_PENDING)
    st.update(incoming)
    running = bool(incoming.get('running', st.get('running', True)))
    stop_reason = str(incoming.get('stop_reason') or st.get('stop_reason') or _STOP_REASON or '')
    nowv = now_ts()
    identity = _runtime_status_identity(running, nowv, stop_reason)
    st.update(identity)
    ctrl = load_control()
    open_pos = load_open()
    st['open_count'] = len(open_pos)
    st['open_total'] = len(open_pos)
    rows = _v582_active_rows(ctrl)
    snapshot, pick = _v582_make_snapshot(rows, ctrl, st.get('pick_stats') if isinstance(st.get('pick_stats'), dict) else {}, open_pos)
    trace_obj = _v582_minimal_trace(rows, ctrl, open_pos, 'canonical_status_single_writer')
    status_out = _v582_write_spine(st, trace_obj, snapshot, pick, open_pos)
    # Helper output can never reintroduce an old PID, stop reason, owner, or start time.
    status_out.update(identity)
    _STATUS_WRITE_COUNT += 1
    status_out['status_write_seq'] = _STATUS_WRITE_COUNT
    status_out['status_writer_owner'] = _STATUS_WRITER_OWNER
    status_out['status_writer_count'] = 1
    status_out['writer_pid'] = os.getpid()
    status_out['status_writer_pid'] = os.getpid()
    status_out['last_write_at'] = nowv
    status_out['last_write_text'] = iso_ts(nowv)
    _atomic_write_status_payload(status_out)
    _LAST_STATUS = status_out
    _STATUS_PENDING.clear()

def _atomic_write_status_payload(payload_obj: Dict[str, Any]) -> None:
    path = FILES['status']
    path.parent.mkdir(parents=True, exist_ok=True)
    tmp = path.with_name(f'.{path.name}.{os.getpid()}.{time.time_ns()}.tmp')
    try:
        payload = json.dumps(payload_obj, ensure_ascii=False, separators=(',', ':'), default=str)
        with tmp.open('w', encoding='utf-8') as handle:
            handle.write(payload)
            handle.flush()
            os.fsync(handle.fileno())
        os.replace(tmp, path)
    finally:
        try:
            if tmp.exists():
                tmp.unlink()
        except Exception:
            pass

def _write_shutdown_status_fast() -> None:
    """One final lightweight status commit after the main loop exits."""
    global _LAST_STATUS, _STATUS_WRITE_COUNT
    nowv = now_ts()
    out = dict(_LAST_STATUS) if isinstance(_LAST_STATUS, dict) else {}
    out.update(_runtime_status_identity(False, nowv, _STOP_REASON))
    _STATUS_WRITE_COUNT += 1
    out['status_write_seq'] = _STATUS_WRITE_COUNT
    out['shutdown_status_fast_path'] = True
    out['performance_write_on_shutdown'] = False
    _atomic_write_status_payload(out)
    _LAST_STATUS = out

def _v561_age_from(obj: Any) -> str:
    try:
        if not isinstance(obj, dict):
            return '-'
        ts = fnum(obj.get('updated_at') or obj.get('ts'), default=0.0)
        if ts <= 0:
            return '-'
        return f"{max(0.0, now_ts() - ts):.1f}s"
    except Exception:
        return '-'

def _v1039_error_blocks(lines: List[str]) -> List[Dict[str, Any]]:
    blocks: List[Dict[str, Any]] = []
    current: List[str] = []
    current_ts = 0.0
    stamp = re.compile(r'^\[(\d{4}-\d{2}-\d{2} \d{2}:\d{2}:\d{2}) KST\]')
    for line in lines:
        match = stamp.match(str(line))
        if match:
            if current:
                blocks.append({'ts': current_ts, 'text': '\n'.join(current)})
            current = [str(line)]
            try:
                import datetime as _dt
                tz = _dt.timezone(_dt.timedelta(hours=9))
                current_ts = _dt.datetime.strptime(match.group(1), '%Y-%m-%d %H:%M:%S').replace(tzinfo=tz).timestamp()
            except Exception:
                current_ts = 0.0
        elif current:
            current.append(str(line))
    if current:
        blocks.append({'ts': current_ts, 'text': '\n'.join(current)})
    return blocks

def perror_text() -> str:
    status = load_json(FILES.get('status', BASE_DIR / 'paper_bot_status.json'), {}) or {}
    runtime_start = fnum((status or {}).get('process_started_at'), (status or {}).get('started_at'), default=0.0)
    lines = tail_lines(FILES["error"], 500)
    blocks = _v1039_error_blocks(lines)
    current = [b for b in blocks if runtime_start > 0 and fnum(b.get('ts'), default=0.0) >= runtime_start - 3.0]
    historical = [b for b in blocks if b not in current]
    out = ['🧯 paper 오류 /perror', f'- 현재 runtime 시작: {iso_ts(runtime_start) if runtime_start > 0 else "확인불가"}']
    if current:
        out += [f'- 현재 runtime 신규 오류: {len(current)}건', '', '\n\n'.join(str(b.get('text') or '') for b in current[-3:])[-3200:]]
    else:
        out.append('✅ 현재 runtime 신규 오류 없음')
    if historical:
        last_ts = max(fnum(b.get('ts'), default=0.0) for b in historical)
        out.append(f'- 과거 보존 오류 tail: {len(historical)}건 / 마지막 {iso_ts(last_ts) if last_ts > 0 else "시각미상"}')
        out.append('- 과거 오류는 삭제하지 않고 원장에 보존')
    elif not blocks:
        out.append('- 과거 보존 오류 없음')
    return '\n'.join(out)

def plog_text() -> str:
    return "🧾 paper 로그 /plog\n\n" + ("\n".join(tail_lines(FILES["log"], 50))[-3500:] or "로그 없음")

def candidate_summary_text__L4564() -> str:
    ctrl=load_control()
    hold_obj=load_json(FILES.get('s1_hold', BASE_DIR/'paper_s1_hold_cache.json'),{}) or {}
    hold_rows=hold_obj.get('rows') if isinstance(hold_obj,dict) and isinstance(hold_obj.get('rows'),list) else []
    hold_rows=[dict(r) for r in hold_rows if isinstance(r,dict)]
    fresh_hold=[r for r in hold_rows if candidate_is_fresh(r,ctrl)]
    latest_rows=read_jsonl_tail(FILES.get('paper_latest',BASE_DIR/'paper_candidates_latest.jsonl'),300)
    latest_fresh=[r for r in latest_rows if isinstance(r,dict) and candidate_is_fresh(r,ctrl)]
    stage_counts=Counter(str(r.get('candidate_grade') or r.get('s_stage') or r.get('stage') or r.get('grade') or '-').upper() for r in latest_fresh)
    status=load_json(FILES.get('status',BASE_DIR/'paper_bot_status.json'),{}) or {}
    pick=status.get('pick_stats') if isinstance(status,dict) and isinstance(status.get('pick_stats'),dict) else {}
    reason_counts=pick.get('paper_entry_hold_reason_counts_v1099') if isinstance(pick.get('paper_entry_hold_reason_counts_v1099'),dict) else {}
    blocked_rows=pick.get('paper_entry_hold_rows_v1099') if isinstance(pick.get('paper_entry_hold_rows_v1099'),list) else []
    blocked_by_ticker={normalize_ticker(r.get('ticker')):r for r in blocked_rows if isinstance(r,dict) and normalize_ticker(r.get('ticker'))}
    lines=['🧭 후보요약 현재 보기 /candidate_summary · canonical Paper 입력',
           f"- 실제 S1 hold {len(hold_rows)} / TTL fresh {len(fresh_hold)} / 실행증명 fresh {pick.get('s1_execution_fresh_v1039',0)} / 최종검사 {pick.get('paper_final_safety_checked_v1099',0)} / 선택 {pick.get('selected_s1',0)} / 보류 {pick.get('paper_entry_hold',pick.get('paper_final_block',0))}",
           f"- 퍼널 accounting: 입력 {pick.get('s1_seen',len(fresh_hold))} / 종결 {pick.get('paper_funnel_accounted_v1102',0)} / 미분류 {pick.get('paper_funnel_unclassified_v1102',0)} / balance {pick.get('paper_funnel_balance_ok_v1102','정보없음')}",
           f"- 전체 후보판 latest {len(latest_rows)} / fresh {len(latest_fresh)} / S1 {stage_counts.get('S1',0)} / S2 {stage_counts.get('S2',0)} / S3 {stage_counts.get('S3',0)}"]
    if reason_counts:
        lines.append('- 보류 사유 TOP: '+' / '.join(f'{k} {v}' for k,v in list(reason_counts.items())[:8]))
    show=sorted(fresh_hold,key=lambda r:(int(fnum(r.get('swing_quality_rank'),default=10**9)), -fnum(r.get('swing_quality_rank_score'),default=-1e9),normalize_ticker(r.get('ticker'))))[:12]
    if show: lines.append('[현재 Paper S1 입력]')
    for r in show:
        t=normalize_ticker(r.get('ticker') or r.get('market') or r.get('symbol')) or '-'
        gate=read_strategy_entry_gate(r)
        b=blocked_by_ticker.get(t) or {}
        reasons=b.get('reason_codes') if isinstance(b.get('reason_codes'),list) else []
        rr=fnum(r.get('actual_entry_rr_v1034'),r.get('risk_reward'),r.get('risk_reward_ratio'),default=0.0)
        spread=fnum(r.get('spread_pct'),r.get('micro_spread_pct'),default=-1.0)
        slip,slip_source=_v925_confirmed_slippage(r)
        lines.append(f"- {t} · rank {r.get('swing_quality_rank',gate.get('swing_quality_rank','-'))} · RR {rr:.3f} · spread {spread:.3f}% · slip {slip if slip is not None else '-'} ({slip_source or '-'}) · exec {gate.get('execution_fresh_ok_v1039',r.get('execution_fresh_ok_v1039'))} · {','.join(reasons) if reasons else '보류기록 없음'}")
    return '\n'.join(lines)

_PAPER_LONG_JOB_LOCK_V1074 = threading.Lock()

_PAPER_LONG_JOB_V1074: Dict[str, Any] = {}

def _paper_long_job_begin_v1074(command: str) -> tuple[bool,str]:
    nowv=time.time()
    with _PAPER_LONG_JOB_LOCK_V1074:
        if _PAPER_LONG_JOB_V1074.get('running'):
            age=max(0.0,nowv-float(_PAPER_LONG_JOB_V1074.get('started_ts') or nowv))
            return False,f"⏳ paper 명령 이미 실행 중\n- 명령: {_PAPER_LONG_JOB_V1074.get('command') or '-'}\n- 시작 후 {age:.1f}초\n- 단계: {_PAPER_LONG_JOB_V1074.get('phase') or '-'}"
        _PAPER_LONG_JOB_V1074.clear()
        _PAPER_LONG_JOB_V1074.update({'running':True,'command':command,'started_ts':nowv,'phase':'접수'})
        return True,''

def _paper_long_job_phase_v1074(phase: str) -> None:
    with _PAPER_LONG_JOB_LOCK_V1074:
        if _PAPER_LONG_JOB_V1074.get('running'):
            _PAPER_LONG_JOB_V1074['phase']=str(phase or '-')[:120]
            _PAPER_LONG_JOB_V1074['phase_ts']=time.time()

def _paper_long_job_end_v1074() -> None:
    with _PAPER_LONG_JOB_LOCK_V1074:
        _PAPER_LONG_JOB_V1074.clear()

def poll_telegram_once() -> None:
    global _TG_OFFSET
    if not TOKEN or not ALLOWED_CHAT_ID:
        return
    try:
        params = urllib.parse.urlencode({'timeout': 0, 'offset': _TG_OFFSET + 1})
        req = urllib.request.Request(f'https://api.telegram.org/bot{TOKEN}/getUpdates?{params}')
        with urllib.request.urlopen(req, timeout=3) as resp:
            data = json.loads(resp.read().decode('utf-8', errors='ignore'))
        for upd in data.get('result', []) if isinstance(data, dict) else []:
            _TG_OFFSET = max(_TG_OFFSET, int(upd.get('update_id') or 0))
            msg = upd.get('message') or upd.get('edited_message') or {}
            chat = msg.get('chat') or {}
            chat_id = str(chat.get('id') or '')
            text = str(msg.get('text') or '')
            if ALLOWED_CHAT_ID and chat_id != str(ALLOWED_CHAT_ID):
                continue
            commands = _paper_command_tokens(text)
            if not commands:
                continue
            old_notify = globals().get('NOTIFY_CHAT_ID')
            try:
                globals()['NOTIFY_CHAT_ID'] = chat_id
                for command in commands:
                    long_command=command in {'/pbatch','/batch','/ponce'}
                    started_cmd=time.time()
                    if long_command:
                        accepted,duplicate_text=_paper_long_job_begin_v1074(command)
                        if not accepted:
                            send_message(duplicate_text)
                            continue
                        send_message(f"🧪 paper 명령 접수 · {command}\n- 현재 단계: 접수\n- 완료 후 최종결과를 전송")
                    try:
                        if long_command: _paper_long_job_phase_v1074('상태·원장 읽기' if command!='/ponce' else 'paper cycle 1회 실행')
                        result=_handle_single_paper_command(command)
                        send_message(result)
                        if long_command:
                            send_message(f"✅ paper 명령 완료 · {command}\n- total {time.time()-started_cmd:.1f}s")
                    finally:
                        if long_command: _paper_long_job_end_v1074()
            finally:
                globals()['NOTIFY_CHAT_ID'] = old_notify
    except Exception as exc:
        log_error('poll_telegram_once', exc)

_RUNTIME_PHASE = 'module_loaded'

_RUNTIME_PHASE_AT = now_ts()

_RUNTIME_PHASE_DETAIL = ''

_STOP_REQUESTED_AT = 0.0

_STOP_WATCHDOG_STARTED = False

_EXACT_COMMIT_DEPTH = 0

def _atomic_write_small_json_v994(path: Path, obj: Dict[str, Any]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    tmp = path.with_name(f'.{path.name}.{os.getpid()}.{time.time_ns()}.tmp')
    try:
        text = json.dumps(obj, ensure_ascii=False, separators=(',', ':'), default=str)
        with tmp.open('w', encoding='utf-8') as handle:
            handle.write(text)
            handle.flush()
            os.fsync(handle.fileno())
        os.replace(tmp, path)
    finally:
        try:
            if tmp.exists():
                tmp.unlink()
        except Exception:
            pass

def _set_runtime_phase_v994(phase: str, detail: str = '', persist: bool = True) -> None:
    global _RUNTIME_PHASE, _RUNTIME_PHASE_AT, _RUNTIME_PHASE_DETAIL
    _RUNTIME_PHASE = str(phase or 'unknown')
    _RUNTIME_PHASE_AT = now_ts()
    _RUNTIME_PHASE_DETAIL = str(detail or '')[:240]
    if not persist:
        return
    try:
        _atomic_write_small_json_v994(FILES['runtime_phase_v994'], {
            'schema': 'paper_runtime_phase_v994', 'version': VERSION, 'build': BUILD_LABEL,
            'pid': os.getpid(), 'phase': _RUNTIME_PHASE, 'detail': _RUNTIME_PHASE_DETAIL,
            'phase_at': _RUNTIME_PHASE_AT, 'phase_text': iso_ts(_RUNTIME_PHASE_AT),
            'stop_requested': bool(_STOP), 'stop_requested_at': _STOP_REQUESTED_AT or None,
            'exact_commit_active': bool(_EXACT_COMMIT_DEPTH),
        })
    except Exception:
        pass

def _exact_commit_enter_v994() -> None:
    global _EXACT_COMMIT_DEPTH
    _EXACT_COMMIT_DEPTH += 1

def _exact_commit_exit_v994() -> None:
    global _EXACT_COMMIT_DEPTH
    _EXACT_COMMIT_DEPTH = max(0, _EXACT_COMMIT_DEPTH - 1)

def _stop_watchdog_v994() -> None:
    """Prestarted daemon: exit before systemd SIGKILL, never cut an exact ledger commit."""
    while not _STOP:
        time.sleep(0.05)
    started = _STOP_REQUESTED_AT or now_ts()
    while now_ts() - started < 6.2:
        if _EXACT_COMMIT_DEPTH == 0 and now_ts() - started >= 2.0:
            try:
                _set_runtime_phase_v994('shutdown_watchdog', 'noncritical work exceeded 2s after signal')
                _write_shutdown_status_fast()
            except Exception:
                pass
            os._exit(0)
        time.sleep(0.05)

def _start_stop_watchdog_v994() -> None:
    global _STOP_WATCHDOG_STARTED
    if _STOP_WATCHDOG_STARTED:
        return
    _STOP_WATCHDOG_STARTED = True
    threading.Thread(target=_stop_watchdog_v994, name='paper-stop-watchdog-v994', daemon=True).start()

def signal_handler(signum: int, _frame: Any) -> None:
    """Signal context stays flag-only; a daemon watchdog handles noncritical blocking work."""
    global _STOP, _STOP_REASON, _STOP_REQUESTED_AT
    _STOP = True
    _STOP_REASON = f"signal_{signum}"
    _STOP_REQUESTED_AT = now_ts()
    _set_runtime_phase_v994('stop_requested', _STOP_REASON, persist=False)

def canonical_writer_permission_snapshot() -> Dict[str, Any]:
    """Prove canonical files are owned and writable by this exact paper process."""
    targets = [
        FILES['closed'], FILES['open'], FILES['closed_append_status_v925'], FILES['closed_append_events_v925'],
        FILES['closed_commit_status'], FILES['closed_commit_events'], FILES['decision_state_v926'],
        FILES['decision_status_v926'], FILES['decision_events_v926'], FILES['decision_reconcile_status'],
        FILES['exit_monitor_status'], FILES['exit_monitor_events'], FILES['writer_permission_status'],
    ]
    process_uid = int(os.geteuid()); process_gid = int(os.getegid())
    rows: List[Dict[str, Any]] = []
    failed: List[str] = []; owner_mismatch: List[str] = []
    for path in targets:
        p = Path(path); exists = p.exists()
        writable = os.access(p, os.W_OK) if exists else os.access(p.parent, os.W_OK)
        row: Dict[str, Any] = {'path':str(p),'name':p.name,'exists':exists,'writable':bool(writable),
                               'process_uid':process_uid,'process_gid':process_gid}
        owner_ok = True
        if exists:
            st = p.stat(); owner_ok = int(st.st_uid) == process_uid and int(st.st_gid) == process_gid
            row.update({'uid':int(st.st_uid),'gid':int(st.st_gid),'mode':oct(st.st_mode & 0o777),
                        'owner_matches_process':bool(owner_ok)})
            if not owner_ok: owner_mismatch.append(p.name)
        if not writable or not owner_ok:
            failed.append(p.name)
        rows.append(row)
    return {
        'schema':'paper_writer_permission_status_v970','version':VERSION,'build':BUILD_LABEL,
        'updated_ts':now_ts(),'updated_text':iso_ts(),'ok':not failed,'failed':failed,
        'owner_mismatch':owner_mismatch,'process_uid':process_uid,'process_gid':process_gid,'targets':rows,
        'policy':'canonical files must be owned by the exact paper runtime uid/gid; BOT_DIR owner is not evidence; no alternate ledger',
    }

def assert_canonical_writer_permissions() -> Dict[str, Any]:
    snap = canonical_writer_permission_snapshot()
    if not _paper_write_json_verified(FILES['writer_permission_status'], snap):
        raise PermissionError('paper_writer_permission_status write verification failed')
    if not snap.get('ok'):
        raise PermissionError('canonical paper writer permission denied: ' + ','.join(snap.get('failed') or []))
    return snap

def process_open_positions_for_exit(open_pos: Dict[str, Dict[str, Any]], ctrl: Dict[str, Any], owner: str) -> Dict[str, Any]:
    """One live path: inspect every OPEN, evaluate exit, exact commit, persist, audit."""
    started = now_ts()
    writer_permission = canonical_writer_permission_snapshot()
    if not writer_permission.get('ok'):
        status = {
            'schema':'paper_exit_monitor_status','version':VERSION,'build':BUILD_LABEL,'state':'ERROR_PERMISSION',
            'owner':owner,'updated_ts':now_ts(),'updated_text':iso_ts(),'open_count_after':len(open_pos),'checked':0,
            'held':0,'extended':0,'close_committed':0,'commit_failed':0,'errors':1,
            'missing_opened_at':0,'future_opened_at':0,'time_exit_minutes':fnum(ctrl.get('time_exit_minutes'), default=15.0),
            'over_time_exit_count':0,'min_age_min':None,'max_age_min':None,
            'decision_reason_counts':{'writer_permission_denied':1},'samples':[],'elapsed_sec':round(now_ts()-started,4),
            'writer_permission':writer_permission,
            'policy':'runtime permission drift stops before any item; OPEN is preserved; alternate ledger forbidden',
        }
        _paper_write_json_verified(FILES['exit_monitor_status'], status)
        raise PermissionError('canonical writer ownership drift: ' + ','.join(writer_permission.get('failed') or []))
    checked = 0; committed = 0; failed = 0; held = 0; extended = 0; errors = 0
    close_alert_attempted = 0; close_alert_errors = 0
    missing_opened_at = 0; future_opened_at = 0; over_time_exit = 0
    ages: List[float] = []; reasons: Counter = Counter(); samples: List[Dict[str, Any]] = []; closed_items: List[Dict[str, Any]] = []
    entry_quality_reused_v1051 = 0; entry_quality_backfilled_v1051 = 0; reaction_milestones_reused_v1051 = 0
    price_map_id_v1051 = id((_LAST_PRICE_CACHE.get('prices') if isinstance(_LAST_PRICE_CACHE, dict) else None))
    time_exit_min = fnum(ctrl.get('time_exit_minutes'), default=15.0)
    _set_runtime_phase_v994('exit_sweep', owner)
    stop_checkpoint = False
    for pid, pos in list(open_pos.items()):
        if _STOP:
            stop_checkpoint = True
            reasons['stop_checkpoint_before_item_v994'] += 1
            break
        checked += 1
        opened_at = read_opened_at_for_exit(pos)
        age_min = max(0.0, (started-opened_at)/60.0) if opened_at > 0 and opened_at <= started+60.0 else None
        if opened_at <= 0: missing_opened_at += 1
        elif opened_at > started+60.0: future_opened_at += 1
        elif age_min is not None:
            ages.append(age_min)
            if age_min >= time_exit_min: over_time_exit += 1
        try:
            updated, closed = update_position(pos, ctrl)
            if isinstance(updated, dict):
                entry_quality_reused_v1051 += 1 if updated.get('entry_quality_reused_v1051') else 0
                entry_quality_backfilled_v1051 += 1 if updated.get('entry_quality_backfilled_once_v1051') else 0
                reaction_milestones_reused_v1051 += 1 if updated.get('reaction_milestones_reused_v1051') else 0
            action = str((updated.get('last_exit_decision') if isinstance(updated,dict) else '') or 'hold')
            reason = str((updated.get('last_exit_decision_reason') if isinstance(updated,dict) else '') or action)
            reasons[reason] += 1
            if closed:
                closed['exit_monitor_owner'] = owner
                _exact_commit_enter_v994()
                try:
                    committed_row, ok, commit_reason = commit_closed_position_exact(open_pos, str(pid), updated, closed, owner)
                finally:
                    _exact_commit_exit_v994()
                reasons[commit_reason] += 1
                if ok:
                    committed += 1; closed_items.append(committed_row); _LAST_CLOSED_COUNT_CACHE['ts']=0.0
                    if _STOP:
                        reasons['close_alert_skipped_stop_v994'] += 1
                    else:
                        close_alert_attempted += 1
                    try:
                        if not _STOP:
                            notify_closed(committed_row)
                    except Exception as exc:
                        close_alert_errors += 1
                        log_error('canonical_closed_alert', exc)
                        _v567_append_trade_alert_trace('closed', committed_row, 'message_build_error', False, f'{type(exc).__name__}: {exc}', 'canonical exit processor notify_closed raised')
                else:
                    failed += 1
            else:
                open_pos[str(pid)] = updated
                if action == 'extend': extended += 1
                elif action == 'error': errors += 1
                else: held += 1
            if len(samples) < 20:
                samples.append({'pos_id':str(pid),'ticker':(updated or pos).get('ticker') if isinstance(updated or pos,dict) else None,
                                'age_min':round(age_min,3) if age_min is not None else None,'action':action,'reason':reason})
            if _STOP:
                stop_checkpoint = True
                reasons['stop_checkpoint_after_item_v994'] += 1
                break
        except Exception as exc:
            errors += 1; reasons[f'exception:{type(exc).__name__}'] += 1
            log_error('canonical_exit_monitor_item', exc)
            if len(samples) < 20:
                samples.append({'pos_id':str(pid),'ticker':pos.get('ticker') if isinstance(pos,dict) else None,'age_min':round(age_min,3) if age_min is not None else None,'action':'error','reason':f'{type(exc).__name__}: {exc}'})
    persist_ok = persist_open_positions(open_pos)
    if not persist_ok:
        raise RuntimeError('OPEN persistence verification failed after canonical exit monitor')
    status = {
        'schema':'paper_exit_monitor_status','version':VERSION,'build':BUILD_LABEL,'state':'ACTIVE' if errors==0 and failed==0 else 'CHECK',
        'owner':owner,'updated_ts':now_ts(),'updated_text':iso_ts(),'open_count_after':len(open_pos),'checked':checked,
        'held':held,'extended':extended,'close_committed':committed,'commit_failed':failed,'errors':errors,
        'close_alert_attempted':close_alert_attempted,'close_alert_errors':close_alert_errors,
        'missing_opened_at':missing_opened_at,'future_opened_at':future_opened_at,'time_exit_minutes':time_exit_min,
        'over_time_exit_count':over_time_exit,'min_age_min':round(min(ages),3) if ages else None,'max_age_min':round(max(ages),3) if ages else None,
        'decision_reason_counts':dict(reasons),'samples':samples,'elapsed_sec':round(now_ts()-started,4),
        'writer_permission':writer_permission,'stop_checkpoint_v994':stop_checkpoint,'stop_requested':bool(_STOP),
        'system_cleanup_v1051':{
            'shared_price_map_read_only':True,
            'price_map_object_id_before_sweep':price_map_id_v1051,
            'price_map_object_id_after_sweep':id((_LAST_PRICE_CACHE.get('prices') if isinstance(_LAST_PRICE_CACHE, dict) else None)),
            'entry_quality_reused':entry_quality_reused_v1051,
            'entry_quality_backfilled':entry_quality_backfilled_v1051,
            'reaction_milestones_reused':reaction_milestones_reused_v1051,
            'open_checked':checked,
        },
        'policy':'one canonical evaluator; no missing timestamp reset; exact commit append->decision CLOSED->OPEN remove; thresholds unchanged'
    }
    if not _paper_write_json_verified(FILES['exit_monitor_status'], status):
        log_error('exit_monitor_status_write_verified', RuntimeError('exit monitor status persistence failed'))
    status['closed_items'] = closed_items
    return status

def run_exact_exit_monitor__L4905(ctrl: Optional[Dict[str, Any]] = None, owner: str = 'paper_exact_exit_monitor') -> Dict[str, Any]:
    ctrl = ctrl if isinstance(ctrl, dict) else load_control()
    open_pos = load_open()
    status = process_open_positions_for_exit(open_pos, ctrl, owner)
    public = dict(status); public.pop('closed_items', None)
    return public

def main() -> None:
    global _STOP_REASON
    _reset_status_runtime_identity()
    _set_runtime_phase_v994('startup_identity')
    write_pid()
    signal.signal(signal.SIGTERM, signal_handler)
    signal.signal(signal.SIGINT, signal_handler)
    _start_stop_watchdog_v994()

    startup_open_v1092 = load_open()
    startup_status: Dict[str, Any] = {
        'running': True,
        'startup_status': True,
        'startup_phase': 'identity_published',
        'paper_cycle_completed_v1118': False,
        'paper_funnel_ready_v1118': False,
        'paper_funnel_state_v1118': 'STARTUP_WAIT',
        'paper_funnel_pending_reason_v1118': 'first full Paper cycle has not completed for this runtime instance',
        'open_count': len(startup_open_v1092),
        'open_total': len(startup_open_v1092),
        'closed_total': line_count_cached(FILES['closed'], ttl=0),
        'engine': 'paper_interruptible_runtime_single_spine_v994',
        'legacy_loop': False,
    }
    # Publish this process identity before slower cleanup/reconcile work.
    write_status(startup_status)

    try:
        _set_runtime_phase_v994('startup_permissions')
        writer_permission = assert_canonical_writer_permissions()
        _set_runtime_phase_v994('startup_owner_cleanup')
        if '_v853_startup_owner_cleanup' in globals():
            _v853_startup_owner_cleanup()
        if '_v859_tmp_cleanup_snapshot' in globals():
            _v859_tmp_cleanup_snapshot(source='startup_preflight', force=True, min_age=0.0)
        if '_v917_touch_execution_status' in globals():
            _v917_touch_execution_status()
        _set_runtime_phase_v994('startup_decision_reconcile')
        startup_reconcile = reconcile_decision_state_at_startup(force=True)
        if not isinstance(startup_reconcile, dict) or startup_reconcile.get('completed') is not True:
            raise RuntimeError('paper startup exact decision reconcile failed')
        reset_pending_v1097 = False
        try:
            reset_pending_v1097 = bool(globals().get('_v1045_reset_in_progress', lambda: False)())
        except Exception:
            reset_pending_v1097 = True
        startup_status.update({
            'startup_phase': 'ready_for_reset' if reset_pending_v1097 else 'ready',
            'startup_reconcile': startup_reconcile,
            'writer_permission': writer_permission,
            'startup_heavy_refresh_deferred_v1097': bool(reset_pending_v1097),
        })
        _set_runtime_phase_v994('startup_ready_published', f'reset_pending={reset_pending_v1097}')
        write_status(startup_status)
        # During an approved reset, enter the cycle immediately. The reset owner will
        # refresh canonical performance after exact commits; startup must not hide the
        # cycle behind a full performance/classifier pass.
        if not reset_pending_v1097:
            _set_runtime_phase_v994('startup_performance_refresh')
            write_score_cache(startup_status, force=not PERFORMANCE_SNAPSHOT_V987.exists(), open_positions=startup_open_v1092)
            _set_runtime_phase_v994('startup_classify_refresh')
            _run_classify_helper_v1013('startup',force=True)
        del startup_open_v1092
        log(f"{VERSION} started pid={os.getpid()} build={BUILD_LABEL} token={'yes' if TOKEN else 'no'} chat={'yes' if ALLOWED_CHAT_ID else 'no'}")

        last_cycle = 0.0
        last_poll = 0.0
        last_exit_sweep = 0.0
        _set_runtime_phase_v994('idle')
        while not _STOP:
            try:
                ctrl = load_control()
                loop_sec = max(2.0, fnum(ctrl.get('loop_seconds'), default=8.0))
                sweep_sec = max(0.5, fnum(ctrl.get('open_monitor_interval_sec'), default=1.0))
                if now_ts() - last_exit_sweep >= sweep_sec:
                    _set_runtime_phase_v994('main_exit_sweep')
                    run_exact_exit_monitor(ctrl, owner='paper_exact_exit_monitor')
                    if _STOP:
                        break
                    last_exit_sweep = now_ts()
                if now_ts() - last_cycle >= loop_sec:
                    _set_runtime_phase_v994('main_cycle')
                    run_cycle()
                    if _STOP:
                        break
                    last_cycle = now_ts()
                elif now_ts() - fnum(_LAST_STATUS.get('updated_at'), default=0.0) >= 10:
                    hb = dict(_LAST_STATUS)
                    hb.update({'heartbeat': True})
                    write_status(hb)
                if now_ts() - last_poll >= 3.0:
                    if not _STOP:
                        _set_runtime_phase_v994('telegram_poll')
                        poll_telegram_once()
                    last_poll = now_ts()
            except PermissionError as exc:
                log_error('main_loop_permission_fail_fast', exc)
                raise
            except Exception as exc:
                log_error('main_loop', exc)
                write_status({'running': True, 'last_error': f'{type(exc).__name__}: {exc}', 'engine': 'paper_interruptible_runtime_single_spine_v994'})
            if _STOP:
                break
            _set_runtime_phase_v994('idle')
            time.sleep(0.2)
    except Exception as exc:
        log_error('paper_main_fail', exc)
        _STOP_REASON = f'error_{type(exc).__name__}'
        raise
    finally:
        try:
            _set_runtime_phase_v994('shutdown_final')
            if '_v1055_force_dirty_flush_on_shutdown' in globals():
                _v1055_force_dirty_flush_on_shutdown()
            _write_shutdown_status_fast()
        except Exception as exc:
            log_error('shutdown_status_fast', exc)
        log(f"{VERSION} stopped reason={_STOP_REASON}")

def _v561_send_message_with_result(text: str) -> Tuple[bool, str]:
    if not TOKEN or not NOTIFY_CHAT_ID:
        return False, 'telegram_disabled: TOKEN or NOTIFY_CHAT_ID missing'
    try:
        data = urllib.parse.urlencode({"chat_id": NOTIFY_CHAT_ID, "text": text[:3900], "disable_web_page_preview": "true"}).encode("utf-8")
        req = urllib.request.Request(f"https://api.telegram.org/bot{TOKEN}/sendMessage", data=data)
        urllib.request.urlopen(req, timeout=2.5).read()
        return True, ''
    except Exception as exc:
        log_error('send_message', exc)
        return False, f"{type(exc).__name__}: {exc}"

def send_message(text: str) -> None:  # type: ignore[override]
    _v561_send_message_with_result(text)

def _v565_int(v: Any, default: int = 0) -> int:
    try:
        if v is None or v == '':
            return default
        return int(float(v))
    except Exception:
        return default

def _v561_pick_spine(status: Dict[str, Any], handoff: Dict[str, Any]) -> Dict[str, Any]:  # type: ignore[override]
    """/pstatus는 status/handoff의 개별 fresh가 아니라 snapshot을 최우선으로 읽는다."""
    pick: Dict[str, Any] = {}
    for src in (status, handoff):
        if not isinstance(src, dict):
            continue
        snap = src.get('paper_candidate_snapshot')
        if isinstance(snap, dict):
            pick.update(snap)
    for src in (status, handoff):
        if not isinstance(src, dict):
            continue
        if isinstance(src.get('pick_stats'), dict):
            ps = src.get('pick_stats') or {}
            # last_* 같은 상세 추적은 pick_stats에서 보존하되 fresh/latest는 snapshot 값이 우선이다.
            for k, v in ps.items():
                if k in {'latest_count', 'paper_latest_count', 'merged_fresh', 'fresh_count'} and k in pick:
                    continue
                pick.setdefault(k, v)
    for src in (status, handoff):
        if not isinstance(src, dict):
            continue
        for dst, keys in {
            'latest_count': ('latest_count', 'paper_latest_count', 'active_latest_count'),
            'merged_fresh': ('merged_fresh', 'fresh_count'),
            's1_seen': ('s1_seen',),
            'selected_s1': ('selected_s1',),
            'paper_entry_hold': ('paper_entry_hold', 'paper_final_block'),
            'micro_preopen_wait': ('micro_preopen_wait',),
        }.items():
            if dst in pick and pick.get(dst) not in (None, ''):
                continue
            for k in keys:
                if k in src and src.get(k) not in (None, ''):
                    pick[dst] = src.get(k)
                    break
    return pick

def _v567_trade_alert_path(kind: str) -> Path:
    if str(kind).lower() == 'closed':
        return BASE_DIR / 'paper_bot_close_alert_trace.jsonl'
    return FILES.get('open_alert_trace', BASE_DIR / 'paper_bot_open_alert_trace.jsonl')

def _v567_append_trade_alert_trace(kind: str, row: Dict[str, Any], phase: str, ok: bool = False, err: str = '', note: str = '') -> None:
    try:
        payload = {
            'schema': f'paper_{kind}_alert_trace_v567',
            'version': VERSION,
            'build': BUILD_LABEL,
            'kind': kind,
            'phase': phase,
            'ts': now_ts(),
            'ts_text': iso_ts(),
            'ticker': normalize_ticker(row.get('ticker')),
            'pos_id': row.get('pos_id') or row.get('event_id') or row.get('entry_id'),
            'event_id': row.get('event_id') or row.get('pos_id') or row.get('entry_id'),
            'opened_at': row.get('opened_at'),
            'opened_at_text': row.get('opened_at_text'),
            'closed_at': row.get('closed_at'),
            'closed_ts': row.get('closed_ts') or row.get('closed_at'),
            'closed_at_text': row.get('closed_at_text'),
            'closed_day_kst': row.get('closed_day_kst') or (_kst_day_key(fnum(row.get('closed_ts'), row.get('closed_at'), default=0.0)) if fnum(row.get('closed_ts'), row.get('closed_at'), default=0.0) > 0 else ''),
            'closed_result_key': row.get('closed_result_key'),
            'closed_result_key_source': row.get('closed_result_key_source'),
            'entry_price': row.get('entry_price'),
            'exit_price': row.get('exit_price'),
            'pnl_pct': row.get('pnl_pct'),
            'strategy': row.get('strategy_label') or row.get('strategy_key') or row.get('strategy'),
            'candidate_grade': row.get('candidate_grade'),
            'exit_reason': row.get('exit_reason') or row.get('exit_rule'),
            'entry_build_key': row.get('entry_build_key') or row.get('score_patch_version') or row.get('opened_patch_version') or row.get('patch_version'),
            'score_patch_version': row.get('score_patch_version') or row.get('entry_build_key') or row.get('opened_patch_version') or row.get('patch_version'),
            'opened_patch_version': row.get('opened_patch_version') or row.get('entry_build_key') or row.get('score_patch_version'),
            'closed_patch_version': row.get('closed_patch_version') or row.get('close_patch_version'),
            'close_patch_version': row.get('close_patch_version') or row.get('closed_patch_version'),
            'sent_ok': bool(ok),
            'error': str(err or ''),
            'note': str(note or ''),
        }
        append_jsonl(_v567_trade_alert_path(kind), payload)
    except Exception as exc:
        log_error(f'v567_{kind}_alert_trace_append', exc)

def _v582_stage_key(ev: Dict[str, Any]) -> str:
    v = str(ev.get('s_stage') or ev.get('candidate_grade') or ev.get('stage') or ev.get('grade') or '').upper().strip()
    if v in {'S1','S2','S3'}:
        return v
    if v in {'X','EXCLUDE','EXCLUDED','BLOCK','BLOCKED'}:
        return 'X'
    return v or '-'

_V1085_STATUS_CANDIDATE_STATS: Dict[str, Any] = {
    "schema": "paper_status_candidate_stream_reader_v1085",
    "calls": 0,
    "rows_examined": 0,
    "rows_compacted": 0,
    "parse_errors": 0,
    "bytes_read": 0,
    "last_rows_examined": 0,
    "last_rows_compacted": 0,
    "last_bytes_read": 0,
    "last_duration_sec": 0.0,
    "full_candidate_rows_retained": False,
    "source": "paper_candidates_latest.jsonl",
}

_V1085_STATUS_ROW_KEYS = (
    "ticker", "symbol", "market",
    "s_stage", "candidate_stage", "candidate_grade", "stage", "grade",
    "strategy_label", "strategy", "strategy_key",
    "event_id", "event_key", "trace_id", "handoff_id", "candidate_uid", "id",
    "scan_id", "source_scan_id", "strategy_scan_id", "score", "leader_score",
    "expires_at", "candidate_expires_at", "hold_expires_at",
    "created_at", "candidate_created_at", "source_created_at", "hold_created_at",
    "created_ts", "updated_ts", "updated_at", "published_at",
    "detected_ts", "event_ts", "ts", "timestamp",
    "s1_hold_v738", "s1_hold_v737", "s1_hold_v736", "s1_hold_v735", "s1_hold_v734", "s1_hold_v732",
    "s1_hold_status_v738", "s1_hold_status_v737", "s1_hold_status_v736", "s1_hold_status_v735", "s1_hold_status_v734", "s1_hold_status_v732",
)

def _v1085_compact_status_candidate(row: Dict[str, Any]) -> Dict[str, Any]:
    return {key: row.get(key) for key in _V1085_STATUS_ROW_KEYS if key in row}

def _v582_active_rows(ctrl: Optional[Dict[str, Any]] = None, max_rows: int = 800) -> List[Dict[str, Any]]:
    """Read the status-only candidate tail without retaining large nested rows."""
    started = time.monotonic()
    examined = compacted = parse_errors = bytes_read = 0
    try:
        ctrl = ctrl or load_control()
        limit = int(fnum(ctrl.get('candidate_read_max_lines'), default=max_rows))
        limit = max(100, min(max_rows, limit))
        compact_rows = deque()
        for raw in _v1085_reverse_tail_raw_lines(FILES['paper_latest'], limit):
            examined += 1
            bytes_read += len(raw)
            try:
                row = json.loads(raw)
            except Exception:
                parse_errors += 1
                continue
            if not isinstance(row, dict):
                continue
            compact_rows.appendleft(_v1085_compact_status_candidate(row))
            compacted += 1
        rows = list(compact_rows)
        try:
            out = latest_scan_filter(rows, ctrl)
        except Exception as exc:
            log_error('v582_latest_scan_filter', exc)
            out = rows
        return out
    except Exception as exc:
        log_error('v582_active_rows', exc)
        return []
    finally:
        stats = _V1085_STATUS_CANDIDATE_STATS
        stats['calls'] = int(stats.get('calls') or 0) + 1
        stats['rows_examined'] = int(stats.get('rows_examined') or 0) + examined
        stats['rows_compacted'] = int(stats.get('rows_compacted') or 0) + compacted
        stats['parse_errors'] = int(stats.get('parse_errors') or 0) + parse_errors
        stats['bytes_read'] = int(stats.get('bytes_read') or 0) + bytes_read
        stats['last_rows_examined'] = examined
        stats['last_rows_compacted'] = compacted
        stats['last_bytes_read'] = bytes_read
        stats['last_duration_sec'] = round(time.monotonic() - started, 6)

def _v582_make_snapshot(rows: List[Dict[str, Any]], ctrl: Dict[str, Any], pick_stats: Optional[Dict[str, Any]], open_pos: Dict[str, Dict[str, Any]]) -> Tuple[Dict[str, Any], Dict[str, Any]]:
    rows = [r for r in (rows or []) if isinstance(r, dict)]
    pick = dict(pick_stats or {})
    fresh_n = 0
    for r in rows:
        try:
            if candidate_is_fresh(r, ctrl):
                fresh_n += 1
        except Exception:
            pass
    stage_counts = Counter(_v582_stage_key(r) for r in rows)
    nowv = now_ts()
    snapshot = {
        'schema': 'paper_candidate_snapshot_v584_direct_rows',
        'version': VERSION,
        'build': BUILD_LABEL,
        'updated_at': nowv,
        'updated_at_text': iso_ts(nowv),
        'snapshot_id': f"v584-{int(nowv*1000)}",
        'snapshot_owner': 'paper_bot',
        'snapshot_rule': 'direct active rows -> one status/handoff/trace writer; paper reads strategy canonical_metric_row',
        'latest_count': len(rows),
        'paper_latest_count': len(rows),
        'active_latest_count': len(rows),
        'latest_lines': len(rows),
        'merged_fresh': fresh_n,
        'fresh_count': fresh_n,
        'fresh_source': 'v584_direct_active_rows_candidate_is_fresh',
        'stage_counts': dict(stage_counts),
        's1_count': int(stage_counts.get('S1', 0)),
        's2_count': int(stage_counts.get('S2', 0)),
        's3_count': int(stage_counts.get('S3', 0)),
        'x_count': int(stage_counts.get('X', 0)),
        'open_count': len(open_pos) if isinstance(open_pos, dict) else 0,
        'open_total': len(open_pos) if isinstance(open_pos, dict) else 0,
        'writer': 'v584_direct_spine_writer',
    }
    # Mirror snapshot values into pick_stats so /pstatus and main bot readers do not borrow stale handoff values.
    pick.update({
        'latest_count': snapshot['latest_count'],
        'paper_latest_count': snapshot['paper_latest_count'],
        'active_latest_count': snapshot['active_latest_count'],
        'merged_fresh': snapshot['merged_fresh'],
        'fresh_count': snapshot['fresh_count'],
        'fresh_source': snapshot['fresh_source'],
        'stage_counts': snapshot['stage_counts'],
        's1_seen': _v565_int(pick.get('s1_seen'), 0),
        'candidate_snapshot_s1_count_v1157': int(snapshot['s1_count']),
        's1_seen_owner_v1157': 'paper_bot.select_candidates exact current-cycle evaluated count; zero is valid',
        'candidate_snapshot_s1_owner_v1157': 'paper candidate inventory only; never substitutes Paper evaluated count',
        's1_seen_snapshot_fallback_removed_v1157': True,
        'paper_candidate_snapshot': snapshot,
        'snapshot_schema': snapshot['schema'],
        'snapshot_id': snapshot['snapshot_id'],
        'writer': 'v584_direct_spine_writer',
    })
    return snapshot, pick

def _v582_minimal_trace(rows: List[Dict[str, Any]], ctrl: Dict[str, Any], open_pos: Dict[str, Dict[str, Any]], err: str = '') -> Dict[str, Any]:
    out = []
    for ev in (rows or [])[:120]:
        if not isinstance(ev, dict):
            continue
        try:
            eid = event_id(ev)
            out.append({
                'trace_id': eid,
                'ticker': normalize_ticker(ev.get('ticker') or ev.get('symbol') or ev.get('market')),
                'stage': _v582_stage_key(ev),
                'fresh': candidate_is_fresh(ev, ctrl),
                'open': eid in open_pos,
                'strategy': ev.get('strategy_label') or ev.get('strategy') or ev.get('strategy_key'),
                'status': 'open' if eid in open_pos else 'observed',
            })
        except Exception:
            continue
    return {
        'schema': 'paper_candidate_handoff_trace_v584_minimal',
        'version': VERSION,
        'trace_version': VERSION,
        'build': BUILD_LABEL,
        'updated_at': now_ts(),
        'updated_at_text': iso_ts(),
        'rows': out,
        'fallback_reason': err,
    }

def _v582_write_spine(status: Dict[str, Any], trace_obj: Dict[str, Any], snapshot: Dict[str, Any], pick_stats: Dict[str, Any], open_pos: Dict[str, Dict[str, Any]]) -> Dict[str, Any]:
    nowv = now_ts()
    trace_rows = trace_obj.get('rows') if isinstance(trace_obj.get('rows'), list) else []
    common = {
        'version': VERSION,
        'paper_version': VERSION,
        'active_reader_version': VERSION,
        'build': BUILD_LABEL,
        'updated_at': nowv,
        'updated_at_text': iso_ts(nowv),
        'latest_count': snapshot.get('latest_count', 0),
        'paper_latest_count': snapshot.get('paper_latest_count', snapshot.get('latest_count', 0)),
        'active_latest_count': snapshot.get('active_latest_count', snapshot.get('latest_count', 0)),
        'latest_lines': snapshot.get('latest_lines', snapshot.get('latest_count', 0)),
        'merged_fresh': snapshot.get('merged_fresh', snapshot.get('fresh_count', 0)),
        'fresh_count': snapshot.get('fresh_count', snapshot.get('merged_fresh', 0)),
        'fresh_source': snapshot.get('fresh_source'),
        'open_count': len(open_pos) if isinstance(open_pos, dict) else 0,
        'open_total': len(open_pos) if isinstance(open_pos, dict) else 0,
        'stage_counts': snapshot.get('stage_counts', {}),
        'snapshot_id': snapshot.get('snapshot_id'),
        'snapshot_schema': snapshot.get('schema'),
        'paper_candidate_snapshot': snapshot,
        'pick_stats': pick_stats,
        'writer': 'v584_direct_spine_writer',
        'cache_spine': 'v584 direct single writer: status/handoff/trace + canonical metric row review',
    }
    trace_out = dict(trace_obj or {})
    trace_out.update(common)
    trace_out.update({
        'schema': 'paper_candidate_handoff_trace_v584_direct_spine',
        'trace_version': VERSION,
        'trace_rows': len(trace_rows),
    })
    handoff = dict(common)
    handoff.update({
        'schema': 'paper_handoff_status_v584_direct_spine',
        'trace_version': VERSION,
        'trace_rows': len(trace_rows),
    })
    # v745: handoff/status가 같은 runtime trace summary를 보게 한다.
    # main_bot은 계산하지 않고 paper_bot이 봉인한 값만 표시한다.
    for _k in (
        'hold_trace_summary_v736',
        'hold_trace_summary_v743',
        'stop_overrun_summary_v745',
        'exit_loop_probe_v745',
    ):
        if _k in (status or {}):
            handoff[_k] = (status or {}).get(_k)
    status_out = dict(status or {})
    status_out.update(common)
    status_out.update({
        'schema': 'paper_status_v584_direct_spine',
        'running': bool(status_out.get('running', True)),
        'process_alive': bool(status_out.get('process_alive', status_out.get('running', True))),
        'trace_version': VERSION,
        'trace_rows': len(trace_rows),
        'cache_spine_version': 'v584',
    })
    # Candidate trace/handoff have their own owners. paper_bot_status.json is written only by write_status.
    save_json(FILES['trace'], trace_out)
    save_json(FILES['handoff_status'], handoff)
    return status_out

def pstatus_text__L7472() -> str:  # type: ignore[override]
    status = load_json(FILES['status'], {}) or {}
    handoff = load_json(FILES['handoff_status'], {}) or {}
    trace = load_json(FILES['trace'], {}) or {}
    op = load_open()
    snap = status.get('paper_candidate_snapshot') if isinstance(status.get('paper_candidate_snapshot'), dict) else {}
    latest = status.get('latest_count', snap.get('latest_count', '-'))
    fresh = status.get('merged_fresh', snap.get('merged_fresh', '-'))
    lines = [
        f"🧪 paper 상태 /pstatus ({VERSION})",
        f"- running: {status.get('running', True)} / open {len(op)} / status age {_v561_age_from(status)} / handoff age {_v561_age_from(handoff)} / trace age {_v561_age_from(trace)}",
        f"- 이번 cycle: OPEN {status.get('opened_this_cycle',0)} / CLOSED {status.get('closed_this_cycle',0)} / elapsed {status.get('elapsed_sec','-')}s",
        f"- 후보: latest {latest} / fresh {fresh} / S1감지 {(status.get('pick_stats') or {}).get('s1_seen', snap.get('s1_count',0))} / S1선택 {(status.get('pick_stats') or {}).get('selected_s1',0)} / OPEN보류 {(status.get('pick_stats') or {}).get('paper_entry_hold', (status.get('pick_stats') or {}).get('paper_final_block',0))} / micro대기 {(status.get('pick_stats') or {}).get('micro_preopen_wait',0)}",
        f"- spine: status {status.get('version','-')} / handoff {handoff.get('version','-')} / trace {trace.get('version') or trace.get('trace_version') or '-'} / snapshot {status.get('snapshot_id') or snap.get('snapshot_id') or '-'}",
        "- writer: v584 direct_spine_writer / paper reads strategy canonical_metric_row only",
    ]
    return '\n'.join(lines)

def _v586_present(v: Any) -> bool:
    if v is None:
        return False
    if isinstance(v, str) and not v.strip():
        return False
    return True

def _v586_to_float(v: Any) -> Optional[float]:
    if not _v586_present(v):
        return None
    try:
        return float(str(v).replace(',', '').replace('%', '').strip())
    except Exception:
        return None

def _v739_open_quarantine_reason(pos: Dict[str, Any]) -> str:
    if _v734_is_malformed_open(pos):
        return "장부 이상 row: ticker/entry_price 없음"
    if _v734_is_legacy_experiment_open(pos):
        return "구 실험 OPEN 잔여: active OPEN에서 격리"
    return ""

def _v739_quarantine_open_positions(open_pos: Dict[str, Dict[str, Any]]) -> List[Dict[str, Any]]:
    if not isinstance(open_pos, dict) or not open_pos:
        return []
    moved: List[Dict[str, Any]] = []
    for pid, pos in list(open_pos.items()):
        if not isinstance(pos, dict):
            continue
        reason = _v739_open_quarantine_reason(pos)
        if not reason:
            continue
        row = dict(pos)
        row.update({
            "quarantine_ts": now_ts(),
            "quarantine_text": iso_ts(),
            "quarantine_reason": reason,
            "original_pos_id": pid,
            "paper_version": VERSION,
            "schema": "paper_open_quarantine_v742",
        })
        append_jsonl(FILES.get("open_quarantine", BASE_DIR / "paper_bot_open_quarantine.jsonl"), row)
        moved.append(row)
        open_pos.pop(pid, None)
    return moved

def _v587_status_spine() -> Dict[str, Any]:
    status = load_json(FILES.get('status', BASE_DIR / 'paper_bot_status.json'), {}) or {}
    handoff = load_json(FILES.get('handoff_status', BASE_DIR / 'paper_bot_candidate_handoff_status.json'), {}) or {}
    trace = load_json(FILES.get('trace', BASE_DIR / 'paper_bot_candidate_handoff_trace.json'), {}) or {}
    if not isinstance(status, dict): status = {}
    if not isinstance(handoff, dict): handoff = {}
    if not isinstance(trace, dict): trace = {}
    snap = status.get('paper_candidate_snapshot') if isinstance(status.get('paper_candidate_snapshot'), dict) else {}
    latest = status.get('latest_count', snap.get('latest_count', '-'))
    fresh = status.get('merged_fresh', status.get('fresh_count', snap.get('merged_fresh', snap.get('fresh_count', '-'))))
    return {
        'version': status.get('version') or status.get('paper_version') or VERSION,
        'build': status.get('build') or BUILD_LABEL,
        'latest': latest,
        'fresh': fresh,
        'snapshot_id': status.get('snapshot_id') or snap.get('snapshot_id') or handoff.get('snapshot_id') or trace.get('snapshot_id') or '-',
        'status_age': _v561_age_from(status),
        'handoff_age': _v561_age_from(handoff),
        'trace_age': _v561_age_from(trace),
    }

def _v587_paper_spine_label() -> str:
    sp = _v587_status_spine()
    return f"{sp.get('version','-')} / latest {sp.get('latest','-')} / fresh {sp.get('fresh','-')} / snapshot {sp.get('snapshot_id','-')}"

def _v587_tick_distortion_reason(row: Dict[str, Any]) -> str:
    price = _v586_to_float(row.get('current_price') or row.get('price') or row.get('trade_price'))
    c1 = _v586_to_float(row.get('scanner_change_1m_pct')) or 0.0
    c3 = _v586_to_float(row.get('scanner_change_3m_pct')) or 0.0
    t = normalize_ticker(row.get('ticker') or row.get('market') or row.get('symbol')) or ''
    if price is not None and price <= 0.001 and (abs(c1) >= 10.0 or abs(c3) >= 10.0):
        return '초저가/틱단위 급등 왜곡 의심'
    if t in {'BTT','NFT'} and (abs(c1) >= 10.0 or abs(c3) >= 10.0):
        return '초저가/틱단위 급등 왜곡 의심'
    return ''

def _v587_candidate_stage_detail_for_hot(row: Dict[str, Any], idx: Optional[Dict[str, Dict[str, Any]]] = None) -> Tuple[str, str, str, str]:
    """hot-rank 발견 → strategy 최신 후보 매칭 → paper 상태를 한 줄로 남긴다.
    매수 판단은 바꾸지 않고, not_seen의 원인 범주만 표시한다.
    """
    ticker = normalize_ticker(row.get('ticker') or row.get('market') or row.get('symbol')) or ''
    tick_reason = _v587_tick_distortion_reason(row)
    if not ticker or not isinstance(idx, dict):
        reason = 'scanner 발견 / strategy 매칭확인 불가'
        if tick_reason: reason += ' / ' + tick_reason
        return '후보확인불가', reason, 'paper not_seen', ''
    r = idx.get(ticker)
    if not isinstance(r, dict):
        reason = 'scanner 발견 / strategy latest 후보 매칭 없음'
        if tick_reason: reason += ' / ' + tick_reason
        # 후보없음은 사라지는 상태가 아니라 복기 가능한 not_candidate 상태로 표시한다.
        return '후보없음(not_candidate)', reason, 'paper not_seen', ''

    st = str(r.get('candidate_grade') or r.get('s_stage') or r.get('stage') or r.get('grade') or '-').upper()
    if st not in {'S1', 'S2', 'S3', 'X'}:
        st = '-'
    block = _v514_first_text(r, (
        's1_block_reason', 'final_block_reason', 'block_reason', 'main_block_reason',
        'reject_reason', 'entry_block_reason', 'reason', 'candidate_reason',
        '막힘', 'block_reasons', 'reasons'
    ), limit=44)
    missing = _v514_first_text(r, (
        'missing_reason', 'missing_info', 'missing_tags', 'lack_reason', 'info_missing', '부족',
    ), limit=34)
    risk = _v514_first_text(r, (
        'risk_tags', 'risk_reason', 'structure_risk_tags', 'spike_guard_reasons', 'stale_reasons', '위험'
    ), limit=34)
    reason_parts = []
    if block: reason_parts.append(block)
    if risk: reason_parts.append('위험 ' + risk)
    if missing: reason_parts.append('부족 ' + missing)
    if tick_reason: reason_parts.append(tick_reason)
    reason = ' / '.join(reason_parts[:4])
    if st == 'S1':
        pstate = 'paper open대상'
    elif st in {'S2','S3'}:
        pstate = 'paper not_s1'
    elif st == 'X':
        pstate = 'paper 제외'
    else:
        pstate = 'paper not_candidate'
    seen = _v514_first_text(r, ('paper_state', 'paper_status', 'handoff_status', 'paper_trace_status'), limit=24)
    if seen:
        pstate = 'paper ' + seen
    strat = str(r.get('strategy_label') or r.get('strategy_key') or r.get('strategy') or '')
    return f'후보 {st}', reason, pstate, strat

def _format_hot_row(row: Dict[str, Any], stage_idx: Optional[Dict[str, Dict[str, Any]]] = None) -> str:  # type: ignore[override]
    t = normalize_ticker(row.get('ticker') or row.get('market') or row.get('symbol')) or '-'
    c1 = fnum(row.get('scanner_change_1m_pct'), default=0.0)
    c3 = fnum(row.get('scanner_change_3m_pct'), default=0.0)
    r1 = row.get('scanner_hot_rank_1m') or '-'
    r3 = row.get('scanner_hot_rank_3m') or '-'
    price = row.get('current_price') or row.get('price') or row.get('trade_price')
    stage, reason, pstate, strat = _v587_candidate_stage_detail_for_hot(row, stage_idx)
    base = f"{t} {fmt_price(price)} / 1m {c1:+.2f}% #{r1} · 3m {c3:+.2f}% #{r3} / {stage}"
    extras = []
    tl = _v514_time_label_from_row(row)
    if tl != '포착 -': extras.append(tl)
    if strat: extras.append(strat)
    if reason: extras.append('이유 ' + reason)
    if pstate: extras.append(pstate)
    return base + (' / ' + ' / '.join(extras[:5]) if extras else '')

def notify_s1_decision_summary__L8093(pick_stats: Dict[str, Any], opened_count: int = 0, closed_count: int = 0, ctrl: Optional[Dict[str, Any]] = None) -> None:  # type: ignore[override]
    """v587: 기존 1시간 S1 요약 기능을 유지하되 paper label은 현재 status spine으로 표시한다."""
    # 원본 함수의 로직을 유지하기 위해 같은 bucket을 사용하되, 발송 직전 label만 바꾼다.
    # 원본 함수 내부가 send_message를 직접 호출하므로 여기서는 짧은 monkey-patch 방식으로 message text만 보정한다.
    original_send = globals().get('send_message')
    def _send_with_spine(text: str) -> Any:
        if isinstance(text, str) and 'paper S1 1시간' in text:
            text = re.sub(r'- paper: .*$', '- paper spine: ' + _v587_paper_spine_label(), text, flags=re.MULTILINE)
        return original_send(text) if callable(original_send) else None
    globals()['send_message'] = _send_with_spine
    try:
        return _v587_base_notify_s1_decision_summary(pick_stats, opened_count=opened_count, closed_count=closed_count, ctrl=ctrl)
    finally:
        globals()['send_message'] = original_send

def notify_market_hot_summary__L8111(ctrl: Optional[Dict[str, Any]] = None) -> None:  # type: ignore[override]
    """v587: hot-rank 요약 기능은 유지하고, 마지막 paper label을 현재 paper spine으로 보정한다.
    _format_hot_row override가 scanner→strategy 매칭 상태를 함께 표시한다.
    """
    original_send = globals().get('send_message')
    def _send_with_spine(text: str) -> Any:
        if isinstance(text, str) and ('시장 hot-rank' in text or '강한 급등 감지' in text):
            text = re.sub(r'- paper: .*$', '- paper spine: ' + _v587_paper_spine_label(), text, flags=re.MULTILINE)
        return original_send(text) if callable(original_send) else None
    globals()['send_message'] = _send_with_spine
    try:
        return _v587_base_notify_market_hot_summary(ctrl)
    finally:
        globals()['send_message'] = original_send

def hot_summary_text() -> str:  # type: ignore[override]
    ctrl = load_control(); rows, age, meta = _load_hot_rank_rows(ctrl)
    stage_idx = _hot_candidate_stage_index()
    top_n = max(5, int(fnum(ctrl.get('notify_market_hot_rank_top_n'), default=5)))
    good = []
    for r in rows:
        c1 = fnum(r.get('scanner_change_1m_pct'), default=0.0); c3 = fnum(r.get('scanner_change_3m_pct'), default=0.0)
        r1 = fnum(r.get('scanner_hot_rank_1m'), default=9999.0); r3 = fnum(r.get('scanner_hot_rank_3m'), default=9999.0)
        if c1 >= 0.2 or c3 >= 0.4 or r1 <= top_n or r3 <= top_n:
            rr = dict(r); rr['_hot_score'] = _hot_row_score(rr); good.append(rr)
    good.sort(key=lambda x: fnum(x.get('_hot_score'), default=0.0), reverse=True)
    lines = [
        '🧭 시장 hot-rank 현재 요약 /hot_summary · v587 scanner→strategy 연결표',
        f"- cache age {age:.1f}s / row {meta.get('row_count','-') if isinstance(meta,dict) else '-'}",
        '- 매수 알림 아님 · 급등 발견→strategy 검토→paper 상태 확인용',
        '- not_seen은 매수누락 확정이 아니라 strategy latest row 매칭 없음 표시',
    ]
    for r in good[:max(5, top_n)]:
        lines.append('- ' + _format_hot_row(r, stage_idx))
    lines.append('- paper spine: ' + _v587_paper_spine_label())
    return '\n'.join(lines)

def _v588_json_safe(obj: Any) -> Any:
    try:
        return json.loads(json.dumps(obj, ensure_ascii=False, default=str))
    except Exception:
        return {}

def _v588_first_nonempty(*vals: Any) -> Any:
    for v in vals:
        if v is None:
            continue
        if isinstance(v, str) and not v.strip():
            continue
        if isinstance(v, (list, tuple, dict)) and len(v) == 0:
            continue
        return v
    return None

def _v588_path(obj: Any, path: Tuple[str, ...]) -> Any:
    cur = obj
    for k in path:
        if not isinstance(cur, dict):
            return None
        cur = cur.get(k)
    return cur

def _v588_paths(sources: List[Dict[str, Any]], *paths: Tuple[str, ...]) -> Any:
    for src in sources:
        if not isinstance(src, dict):
            continue
        for path in paths:
            v = _v588_path(src, path)
            if _v588_first_nonempty(v) is not None:
                return v
    return None

def _v588_first_dict(*vals: Any) -> Dict[str, Any]:
    for v in vals:
        if isinstance(v, dict) and v:
            return v
    return {}

def _v588_first_list(*vals: Any) -> List[Any]:
    for v in vals:
        if isinstance(v, list) and v:
            return v
        if isinstance(v, tuple) and v:
            return list(v)
    return []

def _v588_metric_value(sources: List[Dict[str, Any]], keys: Tuple[str, ...]) -> Any:
    paths = []
    for k in keys:
        paths.extend([
            (k,),
            ('metrics', k),
            ('feature', k),
            ('orderflow', k),
            ('micro', k),
            ('execution_risk', k),
            ('freshness_map', k),
            ('entry_diagnostics', k),
        ])
    return _v588_paths(sources, *paths)

def _v588_build_canonical_entry_snapshot(ev: Dict[str, Any], pos: Optional[Dict[str, Any]] = None) -> Dict[str, Any]:
    ev = ev if isinstance(ev, dict) else {}
    pos = pos if isinstance(pos, dict) else {}
    ctx = _v588_first_dict(
        pos.get('entry_context'), ev.get('entry_context'), ev.get('strategy_context'), ev.get('raw') if isinstance(ev.get('raw'), dict) else {}
    )
    raw = _v588_first_dict(pos.get('raw'), ev.get('raw'))
    diag = _v588_first_dict(pos.get('entry_diagnostics'), ev.get('paper_final_safety_diagnostics'), ev.get('entry_diagnostics'), ctx.get('entry_diagnostics'))
    cm = _v588_first_dict(
        pos.get('canonical_metric_row'), ev.get('canonical_metric_row'), ctx.get('canonical_metric_row'), diag.get('canonical_metric_row'), raw.get('canonical_metric_row') if isinstance(raw, dict) else {}
    )
    dec = _v588_first_dict(pos.get('canonical_entry_decision'), ev.get('canonical_entry_decision'), ctx.get('canonical_entry_decision'), diag.get('canonical_entry_decision'))
    sources = [pos, ev, diag, cm, ctx, raw]

    structure = _v588_first_dict(cm.get('structure'), diag.get('structure'), ctx.get('structure'))
    freshness = _v588_first_dict(cm.get('freshness_map'), diag.get('freshness_map'), ctx.get('freshness_map'))
    exec_risk = _v588_first_dict(cm.get('execution_risk'), diag.get('execution_risk'), ctx.get('execution_risk'))
    timing = _v588_first_dict(cm.get('timing_spine'), pos.get('entry_timing_spine'), diag.get('entry_timing_spine'), diag.get('entry_timing_trace'), ctx.get('entry_timing_spine'))
    levels = _v588_first_dict(cm.get('structure_levels'), pos.get('structure_levels'), diag.get('structure_levels'), ctx.get('structure_levels'))
    plan = _v588_first_dict(cm.get('entry_plan'), pos.get('entry_plan'), diag.get('entry_plan'), ctx.get('entry_plan'))
    rr = _v588_first_dict(cm.get('risk_reward'), pos.get('risk_reward'), diag.get('risk_reward'), ctx.get('risk_reward'))

    metrics = {
        'price_reaction_pct': _v588_metric_value(sources, ('price_reaction_pct','reaction_pct','reaction','price_reaction','response_pct','price_response_pct')),
        'buy_trade_ratio': _v588_metric_value(sources, ('buy_trade_ratio','buy_ratio','buy_strength','buy_aggr_ratio','buy_exec_ratio','buy_pressure_ratio')),
        'one_min_sustain': _v588_metric_value(sources, ('one_min_sustain','one_min_buy_sustain','buy_sustain_1m','sustain_1m','one_min_persist','one_min_persistence')),
        'spread_pct': _v588_metric_value(sources, ('spread_pct','orderbook_spread_pct','spread_rate_pct')),
        'slippage_pct': _v588_metric_value(sources, ('slippage_pct','expected_slippage_pct','est_slippage_pct')),
        'sell_pressure': _v588_metric_value(sources, ('sell_pressure','sell_pressure_score','ask_wall_pressure','sell_wall_pressure')),
        'flow_1m_pct': _v588_metric_value(sources, ('flow_1m_pct','change_1m_pct','rate_1m','return_1m_pct')),
        'flow_3m_pct': _v588_metric_value(sources, ('flow_3m_pct','change_3m_pct','rate_3m','return_3m_pct')),
        'flow_5m_pct': _v588_metric_value(sources, ('flow_5m_pct','change_5m_pct','rate_5m','return_5m_pct')),
        'flow_15m_pct': _v588_metric_value(sources, ('flow_15m_pct','change_15m_pct','rate_15m','return_15m_pct')),
    }
    ages = {
        'micro_age_sec': _v588_metric_value(sources, ('micro_age_sec','micro_age','micro_fresh_age_sec')),
        'orderflow_age_sec': _v588_metric_value(sources, ('orderflow_age_sec','orderflow_age','orderflow_fresh_age_sec')),
        'price_age_sec': _v588_metric_value(sources, ('price_age_sec','price_age','ticker_age_sec')),
        'feature_age_sec': _v588_metric_value(sources, ('feature_age_sec','feature_age')),
        'paper_age_sec': _v588_metric_value(sources, ('paper_age_sec','paper_fresh_age_sec')),
    }
    snapshot = {
        'schema': 'canonical_entry_snapshot_v588',
        'paper_version': VERSION,
        'build': BUILD_LABEL,
        'created_at': now_ts(),
        'created_at_text': iso_ts(),
        'event_id': pos.get('event_id') or pos.get('pos_id') or event_id(ev) if ev else pos.get('pos_id'),
        'ticker': normalize_ticker(pos.get('ticker') or ev.get('ticker') or ev.get('symbol') or ev.get('market')),
        'strategy': pos.get('strategy') or ev.get('strategy') or ev.get('strategy_key'),
        'strategy_key': pos.get('strategy_key') or ev.get('strategy_key') or ev.get('strategy'),
        'candidate_grade': pos.get('candidate_grade') or ev.get('candidate_grade') or ev.get('s_stage') or 'S1',
        'entry_price': pos.get('entry_price') or get_event_price(ev),
        'detected_price': pos.get('detected_price') or get_event_price(ev),
        'metrics': _v588_json_safe(metrics),
        'freshness': {
            'overall': freshness.get('overall') or freshness.get('state') or diag.get('fresh_state') or diag.get('freshness_state'),
            'ages': _v588_json_safe(ages),
            'raw': _v588_json_safe(freshness),
        },
        'structure': {
            'state': structure.get('state') or cm.get('structure_state') or diag.get('structure_state'),
            'tags': _v588_first_list(structure.get('tags'), cm.get('structure_tags'), diag.get('entry_structure_tags'), pos.get('entry_structure_tags')),
            'levels': _v588_json_safe(levels),
        },
        'execution_risk': {
            'state': exec_risk.get('state') or cm.get('execution_risk_state') or diag.get('execution_risk_state'),
            'tags': _v588_first_list(exec_risk.get('tags'), cm.get('execution_risk_tags'), diag.get('execution_risk_tags'), pos.get('execution_risk_tags')),
            'raw': _v588_json_safe(exec_risk),
        },
        'timing_spine': _v588_json_safe(timing),
        'entry_plan': _v588_json_safe(plan),
        'risk_reward': _v588_json_safe(rr),
        'decision': {
            'reference': cm.get('decision_reference') or diag.get('decision_reference') or pos.get('final_entry_label') or ev.get('final_entry_label'),
            'entry_reasons': _v588_first_list(cm.get('entry_reasons'), diag.get('entry_reasons'), pos.get('entry_condition_reasons')),
            'block_reasons': _v588_first_list(cm.get('block_reasons'), diag.get('block_reasons'), pos.get('block_reasons')),
            'confirm_signals': _v588_first_list(diag.get('confirm_signals'), pos.get('confirm_signals'), cm.get('confirm_signals')),
            'late_chase_flag': bool(_v588_first_nonempty(cm.get('late_chase_flag'), diag.get('late_chase_flag'), pos.get('late_chase_flag'), False)),
        },
        'paper_preopen': {
            'paper_final_safety_passed': bool(pos.get('paper_final_safety_passed') or ev.get('paper_final_safety_passed')),
            'diagnostics_schema': diag.get('schema') or diag.get('entry_decision_schema'),
            'canonical_entry_decision': _v588_json_safe(dec),
        },
        'source_snapshot': _v588_json_safe(_v588_first_dict(cm.get('source_snapshot'), diag.get('source_snapshot'), ctx.get('source_snapshot'))),
    }
    return _v588_json_safe(snapshot)

def _v607_close_alert_trace_path() -> Path:
    return FILES.get('close_alert_trace', BASE_DIR / 'paper_bot_close_alert_trace.jsonl')

def _v607_row_key(row: Dict[str, Any]) -> str:
    tid = str(row.get('pos_id') or row.get('event_id') or row.get('entry_id') or '').strip()
    if tid:
        return 'id:' + tid
    ticker = normalize_ticker(row.get('ticker'))
    opened = fnum(row.get('opened_at'), default=0.0)
    closed = fnum(row.get('closed_at'), row.get('ts'), default=0.0)
    if ticker and (opened or closed):
        return f'tc:{ticker}:{round(opened or 0.0,1)}:{round(closed or 0.0,1)}'
    return ''

def _v607_alert_to_closed_row__L8822(row: Dict[str, Any]) -> Dict[str, Any]:
    ts = fnum(row.get('closed_at'), row.get('ts'), default=0.0)
    out = {
        'schema': 'paper_closed_reconciled_from_close_alert_trace_v607',
        'reconciled_from_close_alert_trace': True,
        'source': 'paper_bot_close_alert_trace',
        'source_alert_phase': row.get('phase'),
        'source_alert_version': row.get('version'),
        'source_alert_build': row.get('build'),
        'ticker': normalize_ticker(row.get('ticker')),
        'pos_id': row.get('pos_id') or row.get('event_id') or row.get('entry_id'),
        'event_id': row.get('event_id') or row.get('pos_id') or row.get('entry_id'),
        'opened_at': fnum(row.get('opened_at'), default=0.0),
        'opened_at_text': row.get('opened_at_text'),
        'closed_at': ts,
        'closed_ts': fnum(row.get('closed_ts'), ts, default=0.0),
        'closed_at_text': row.get('closed_at_text') or (iso_ts(ts) if ts else ''),
        'closed_day_kst': row.get('closed_day_kst') or (_kst_day_key(ts) if ts else ''),
        'closed_result_key': row.get('closed_result_key') or (('closed:' + str(row.get('pos_id') or row.get('event_id') or row.get('entry_id'))) if (row.get('pos_id') or row.get('event_id') or row.get('entry_id')) else ''),
        'closed_result_key_source': row.get('closed_result_key_source') or ('alert_trade_id' if (row.get('pos_id') or row.get('event_id') or row.get('entry_id')) else 'missing'),
        'entry_price': fnum(row.get('entry_price'), default=0.0),
        'exit_price': fnum(row.get('exit_price'), default=0.0),
        'pnl_pct': fnum(row.get('pnl_pct'), default=0.0),
        'profit_pct': fnum(row.get('pnl_pct'), default=0.0),
        'strategy_label': row.get('strategy') or row.get('strategy_label') or row.get('strategy_key') or '-',
        'strategy': row.get('strategy') or row.get('strategy_label') or row.get('strategy_key') or '-',
        'candidate_grade': row.get('candidate_grade') or row.get('grade') or '-',
        'exit_reason': row.get('exit_reason') or row.get('exit_rule') or '-',
        'closed_paper_version': row.get('version') or VERSION,
        'opened_paper_version': row.get('version') or VERSION,
        'entry_build_key': row.get('entry_build_key') or row.get('score_patch_version') or row.get('opened_patch_version') or row.get('patch_version') or active_patch_version(),
        'open_build_key': row.get('open_build_key') or row.get('entry_build_key') or row.get('score_patch_version') or row.get('opened_patch_version') or active_patch_version(),
        'entry_patch_version': row.get('entry_patch_version') or row.get('entry_build_key') or row.get('score_patch_version') or row.get('opened_patch_version') or active_patch_version(),
        'score_patch_version': row.get('score_patch_version') or row.get('entry_build_key') or row.get('opened_patch_version') or active_patch_version(),
        'opened_patch_version': row.get('opened_patch_version') or row.get('entry_build_key') or row.get('score_patch_version') or active_patch_version(),
        'patch_version': row.get('patch_version') or row.get('entry_build_key') or row.get('score_patch_version') or active_patch_version(),
        'closed_patch_version': row.get('closed_patch_version') or row.get('close_patch_version') or active_patch_version(),
        'close_patch_version': row.get('close_patch_version') or row.get('closed_patch_version') or active_patch_version(),
        'score_main_version': active_main_version(),
        'closed_main_version': active_main_version(),
    }
    return out

def _v608_closed_hourly_lines() -> List[str]:
    score = load_json(FILES.get('score', BASE_DIR / 'paper_bot_score_cache.json'), {}) or {}
    if not isinstance(score, dict):
        return ['📉 CLOSED 요약', '- score cache 준비중']
    today = score.get('today_global_stats') if isinstance(score.get('today_global_stats'), dict) else {}
    recent = score.get('recent_12h') if isinstance(score.get('recent_12h'), dict) else {}
    rec = score.get('closed_source_reconcile') if isinstance(score.get('closed_source_reconcile'), dict) else {}
    lines = ['📉 CLOSED 요약']
    lines.append(f"- 오늘: {int(today.get('n') or today.get('count') or 0)}전 / 합산 {fnum(today.get('sum_pct'), today.get('total_pct'), default=0.0):+.2f}% / 평균 {fnum(today.get('avg_pct'), default=0.0):+.2f}%")
    if recent:
        lines.append(f"- 최근 12시간: {int(recent.get('count') or recent.get('n') or 0)}전 / 합산 {fnum(recent.get('sum_pct'), recent.get('total_pct'), default=0.0):+.2f}%")
    if rec:
        lines.append(f"- CLOSED source: 장부 {rec.get('ledger_count')} / 알림보강 {rec.get('alert_recovered_count')}")
    return lines

def paper_guide_text() -> str:
    return "\n".join([
        "🧭 paper 명령어 가이드 /pguide",
        "",
        "✅ 현재 상태",
        "- /pstatus : paper ON/OFF, OPEN 수, 후보선별",
        "- /popen : 현재 진행 중인 OPEN만 보기",
        "",
        "📌 후보/시장",
        "- /candidate_summary : paper가 받은 S1/S2/S3 후보",
        "- /hot_summary : 1시간 hot-rank 요약",
        "- /paper_hourly : 후보·hot-rank·CLOSED를 1시간 요약",
        "",
        "🧯 점검",
        "- /perror : paper 오류",
        "- /plog : 최근 로그",
        "- 여러 명령을 한 메시지에 줄바꿈하거나 띄어 쓰면 각각 처리",
        "- /pversion : paper 버전",
        "",
        "고정: paper 명령은 cache/status만 읽고 장부를 고치지 않습니다.",
    ])

def paper_hourly_text__L9095() -> str:  # type: ignore[override]
    return "\n\n".join([
        "🧭 paper 1시간 요약 · v612",
        "✅ 현재 상태",
        _v612_prev_pstatus_text(),
        "📉 CLOSED 요약",
        "\n".join(_v608_closed_hourly_lines()) if '_v608_closed_hourly_lines' in globals() else "- score cache 준비중",
        "🔥 hot-rank",
        _v612_prev_hot_summary_text(),
        "📌 paper 후보",
        _v612_prev_candidate_summary_text(),
        "고정: 1시간 요약은 cache/status만 읽습니다.",
    ])

def _paper_command_tokens(text: str) -> List[str]:
    """Extract every Telegram command in message order, including multiline input."""
    raw = str(text or '')
    found = re.findall(r'(?<!\S)(/[A-Za-z_][A-Za-z0-9_]*(?:@[A-Za-z0-9_]+)?)', raw)
    commands: List[str] = []
    for item in found[:12]:
        command = item.split('@', 1)[0].lower()
        if command not in commands:
            commands.append(command)
    return commands

def _handle_single_paper_command(command: str) -> str:
    c = str(command or '').strip().split()[0].split('@', 1)[0].lower()
    if c in {'/pguide', '/guide', '/help', '/commands'}:
        return paper_guide_text()
    if c in {'/pstatus', '/status'}:
        return pstatus_text()
    if c in {'/popen', '/open'}:
        return popen_text()
    if c in {'/perror', '/error'}:
        return perror_text()
    if c in {'/plog', '/log'}:
        return plog_text()
    if c in {'/pbatch', '/batch'}:
        return '\n\n'.join([pstatus_text(), popen_text(), perror_text()])
    if c in {'/hot_summary', '/hot', '/phot'}:
        return hot_summary_text()
    if c in {'/candidate_summary', '/candidate', '/pcandidate'}:
        return candidate_summary_text()
    if c in {'/paper_hourly', '/hourly', '/phourly'}:
        return paper_hourly_text()
    if c in {'/pversion', '/version'}:
        return f'{VERSION} / {BUILD_LABEL}'
    if c == '/ponce':
        st = run_cycle()
        return f"✅ run once: opened {st.get('opened_this_cycle')} closed {st.get('closed_this_cycle')} elapsed {st.get('elapsed_sec')}s"
    return '명령: /pstatus /popen /hot_summary /candidate_summary /paper_hourly /perror /plog /pbatch /pversion /ponce\n- 여러 명령을 줄바꿈하거나 띄어 써도 각각 처리합니다.'

try:
    BUILD_LABEL = 'v621_open_score_review_source_spine_20260601'
except Exception:
    pass

def popen_text__L9300() -> str:  # type: ignore[override]
    rows_obj = load_open()
    rows = [dict(v) for v in rows_obj.values() if isinstance(v, dict)]
    rows.sort(key=lambda r: fnum(r.get('opened_at'), default=0.0))
    lines = [
        f'📂 PAPER OPEN · {VERSION}',
        '- 기준: paper_bot_open.json active OPEN',
        f'- 정상 OPEN: {len(rows)}개',
    ]
    if not rows:
        return '\n'.join(lines + ['', 'OPEN 없음'])
    for idx, row in enumerate(rows[:12], 1):
        ev = row.get('entry_evidence_v983') if isinstance(row.get('entry_evidence_v983'), dict) else _v983_build_entry_evidence(row)
        trigger = ev.get('trigger') if isinstance(ev.get('trigger'), dict) else {}
        invalid = ev.get('invalid') if isinstance(ev.get('invalid'), dict) else {}
        target = ev.get('target') if isinstance(ev.get('target'), dict) else {}
        entry = fnum(row.get('entry_price'), default=0.0)
        current = fnum(row.get('current_price'), default=entry)
        pnl = ((current/entry)-1.0)*100.0 if entry > 0 and current > 0 else fnum(row.get('last_pnl_pct'), default=0.0)
        age = max(0.0, (now_ts()-fnum(row.get('opened_at'),default=now_ts()))/60.0)
        lines += [
            '', f'[{idx}] {normalize_ticker(row.get("ticker")) or "자료 없음"}',
            f'진입 방식: {ev.get("setup_type") or "자료 없음"}',
            f'진입가 → 현재가: {fmt_price(entry)} → {fmt_price(current)} · {pnl:+.2f}%',
            f'Trigger: {fmt_price(trigger.get("price"))} · {trigger.get("timeframe") or "자료 없음"}',
            f'Invalid: {fmt_price(invalid.get("price"))} · {invalid.get("timeframe") or "자료 없음"}',
            f'Target: {fmt_price(target.get("price"))} · {target.get("timeframe") or "자료 없음"}',
            ('수익보호: ON · 최고 +2.00% 후 0.80%p 반납' if (_v1038_sealed_exit_contract(row).get('schema') == 'alt_swing_exit_contract_v1038' and _v1038_sealed_exit_contract(row).get('trailing_exit') is True) else '수익보호: OFF · 기존 진입계약 유지'),
            f'보유: {age:.1f}분 · MFE {fnum(row.get("mfe_pct_v983",row.get("peak_pct")),default=0.0):+.2f}% · MAE {fnum(row.get("mae_pct_v983",row.get("trough_pct")),default=0.0):+.2f}%',
        ]
    if len(rows) > 12:
        lines += ['', f'외 {len(rows)-12}개 · 원장은 모두 보존']
    return '\n'.join(lines)

try:
    BUILD_LABEL = 'v622_strategy_win_loss_review_2026-06-01'
except Exception:
    pass

try:
    BUILD_LABEL = 'v623_strategy_win_loss_force_writer_20260602'
except Exception:
    pass

BUILD_LABEL = 'structure_board_mainline_2026-06-10'

FILES['hourly_event_trace'] = BASE_DIR / 'paper_bot_hourly_event_trace.jsonl'

FILES['hourly_state'] = BASE_DIR / 'paper_bot_hourly_raw_state.json'

BUILD_LABEL = 'structure_board_mainline_2026-06-10'

FILES['hourly_event_trace'] = BASE_DIR / 'paper_bot_hourly_event_trace.jsonl'

FILES['hourly_state'] = BASE_DIR / 'paper_bot_hourly_raw_state.json'

BUILD_LABEL = 'structure_board_mainline_2026-06-10'

BUILD_LABEL = 'structure_board_mainline_2026-06-10'

FILES.setdefault('hourly_event_trace', BASE_DIR / 'paper_bot_hourly_raw_event_trace.jsonl')

FILES.setdefault('hourly_sent_state', BASE_DIR / 'paper_bot_hourly_raw_pack_sent.json')

def _v628_now() -> float:
    return now_ts()

def _v628_deep_values(obj: Any, key: str, depth: int = 5) -> List[Any]:
    out: List[Any] = []
    if depth < 0:
        return out
    if isinstance(obj, dict):
        if key in obj and obj.get(key) not in (None, '', [], {}):
            out.append(obj.get(key))
        for v in obj.values():
            if isinstance(v, (dict, list)):
                out.extend(_v628_deep_values(v, key, depth-1))
    elif isinstance(obj, list):
        for v in obj[:80]:
            if isinstance(v, (dict, list)):
                out.extend(_v628_deep_values(v, key, depth-1))
    return out

def _v628_first_num(*objs: Any, keys: Tuple[str, ...], default: float = 0.0) -> float:
    for obj in objs:
        for key in keys:
            for v in _v628_deep_values(obj, key, depth=5):
                x = fnum(v, default=0.0)
                if x > 0:
                    return x
    return default

def _v930_json_bytes(obj: Any) -> bytes:
    try:
        return json.dumps(obj, ensure_ascii=False, sort_keys=True, separators=(",", ":"), default=str).encode("utf-8")
    except Exception:
        return str(obj).encode("utf-8", errors="ignore")

def _v930_digest(obj: Any) -> str:
    try:
        return hashlib.sha256(_v930_json_bytes(obj)).hexdigest()
    except Exception:
        return ""

def _v930_slim_value(value: Any, depth: int = 0) -> Any:
    """Bound audit-only nested payloads without changing execution fields."""
    if depth >= 4:
        if isinstance(value, dict):
            return {"_trimmed_v930": True, "keys": list(value.keys())[:16], "sha256": _v930_digest(value)}
        if isinstance(value, list):
            return value[:16]
        return value
    if isinstance(value, dict):
        out: Dict[str, Any] = {}
        blocked = {"raw", "candidate_row", "source_event", "source_row", "_source_row", "worker_rows", "debug_payload", "trace_rows"}
        for k, v in list(value.items())[:160]:
            if str(k) in blocked:
                continue
            out[str(k)] = _v930_slim_value(v, depth + 1)
        return out
    if isinstance(value, list):
        return [_v930_slim_value(v, depth + 1) for v in value[:48]]
    if isinstance(value, str) and len(value) > 2000:
        return value[:2000] + "…"
    return value

_V930_EVIDENCE_DICT_KEYS = {
    "swing_entry_gate_v977", "minimal_entry_gate_v925", "trigger_provenance_v924", "quality_observation_v925",
    "trigger_gate", "trigger_gate_v738", "structure_levels", "entry_plan", "risk_reward",
    "structure_trade_plan_v796", "candidate_input_coverage_v906", "freshness_map", "source_snapshot",
    "canonical_entry_decision", "common_entry_decision", "entry_timing_spine", "entry_timing_trace",
    "canonical_metric_row", "structure_first_route_v773", "structure_route_applied_v774",
    "canonical_entry_basis_v764", "chart_line_reaction_v772", "paper_final_safety_diagnostics",
}

def _v930_compact_candidate_evidence(row: Dict[str, Any]) -> Dict[str, Any]:
    src = row if isinstance(row, dict) else {}
    out: Dict[str, Any] = {
        "schema": "paper_candidate_evidence_v930_compact",
        "source_sha256": _v930_digest(src),
        "source_bytes": len(_v930_json_bytes(src)),
    }
    for k, v in src.items():
        if k in {"raw", "candidate_row", "source_event", "source_row", "_source_row", "entry_context", "entry_diagnostics"}:
            continue
        if isinstance(v, (str, int, float, bool)) or v is None:
            out[k] = v[:2000] + "…" if isinstance(v, str) and len(v) > 2000 else v
        elif isinstance(v, list):
            if k.endswith("_tags") or k.endswith("_reasons") or k in {
                "final_trade_reasons", "final_entry_reasons", "entry_condition_reasons", "confirm_signals",
                "execution_risk_tags", "recheck_reasons", "block_reasons", "extreme_quality_risk_tags_v925",
            }:
                out[k] = _v930_slim_value(v)
        elif isinstance(v, dict) and (k in _V930_EVIDENCE_DICT_KEYS or k.startswith("minimal_") or k.startswith("trigger_")):
            slim = _v930_slim_value(v)
            raw_bytes = len(_v930_json_bytes(slim))
            out[k] = slim if raw_bytes <= 65536 else {
                "schema": "paper_nested_evidence_ref_v930", "sha256": _v930_digest(v),
                "source_bytes": len(_v930_json_bytes(v)), "keys": list(v.keys())[:32],
            }
    return out

def _v930_compact_hourly_event(kind: str, row: Dict[str, Any], message_text: str = '', phase: str = '', note: str = '') -> Dict[str, Any]:
    src = row if isinstance(row, dict) else {}
    ts = _v628_now()
    return {
        'schema':'paper_hourly_event_v930_compact',
        'version':VERSION,
        'build':BUILD_LABEL,
        'kind':str(kind or ''),
        'phase':str(phase or ''),
        'ts':ts,
        'ts_text':iso_ts(ts),
        'kst_hour':_v628_hour_key(ts),
        'ticker':normalize_ticker(src.get('ticker') or src.get('market') or src.get('symbol')),
        'event_id':src.get('event_id') or src.get('pos_id') or src.get('entry_id'),
        'pos_id':src.get('pos_id') or src.get('event_id') or src.get('entry_id'),
        'paper_decision_key_v926':src.get('paper_decision_key_v926') or src.get('swing_gate_decision_key_v977') or src.get('minimal_gate_decision_key_v925'),
        'closed_result_key':src.get('closed_result_key'),
        'entry_build_key':src.get('entry_build_key'),
        'strategy':src.get('strategy_label') or src.get('strategy_key') or src.get('strategy'),
        'candidate_grade':src.get('candidate_grade') or src.get('s_stage'),
        'entry_price':src.get('entry_price'),
        'trigger_price':_v628_first_num(src, keys=('trigger_price',), default=0.0) or None,
        'invalid_price':_v628_first_num(src, keys=('invalid_price','stop_price'), default=0.0) or None,
        'target_price':_v628_first_num(src, keys=('target1_price','target_price'), default=0.0) or None,
        'rr_ratio':src.get('rr_ratio') or src.get('risk_reward_ratio') or src.get('rr'),
        'pnl_pct':src.get('pnl_pct'),
        'exit_reason':src.get('exit_reason') or src.get('exit_rule'),
        'note':str(note or '')[:2000],
        'message_text':str(message_text or '')[:8000],
        'source_sha256_v930':_v930_digest(src),
        'source_bytes_v930':len(_v930_json_bytes(src)),
        'raw_payload_stored_v930':False,
    }

def _v628_append_hourly_event(kind: str, row: Dict[str, Any], message_text: str = '', phase: str = '', note: str = '') -> None:
    try:
        append_jsonl(FILES['hourly_event_trace'], _v930_compact_hourly_event(kind, row, message_text, phase, note))
    except Exception as exc:
        log_error('v930_append_hourly_event', exc)

def _v797_sources(obj: Any) -> List[Dict[str, Any]]:
    out: List[Dict[str, Any]] = []
    def add(v: Any) -> None:
        if isinstance(v, dict) and v not in out:
            out.append(v)
    add(obj)
    if isinstance(obj, dict):
        for k in ('entry_context','entry_diagnostics','paper_open_spine_v566','paper_open_spine','paper_final_safety_diagnostics','swing_entry_gate_v977','minimal_entry_gate_v925','raw','canonical_entry_snapshot','canonical_entry_snapshot_v796','entry_snapshot','source_event','candidate_row'):
            v = obj.get(k)
            add(v)
            if isinstance(v, dict):
                for k2 in ('entry_context','entry_diagnostics','paper_open_spine_v566','paper_open_spine','paper_final_safety_diagnostics','trigger_gate','entry_timing_spine','raw','canonical_entry_snapshot','structure_trade_plan_v796','s1_promotion_gate'):
                    add(v.get(k2))
    return out

def _v797_find_plan(obj: Any) -> Dict[str, Any]:
    for src in _v797_sources(obj):
        if isinstance(src.get('structure_trade_plan_v796'), dict) and src.get('structure_trade_plan_v796'):
            return dict(src.get('structure_trade_plan_v796') or {})
        gate = src.get('s1_promotion_gate') if isinstance(src.get('s1_promotion_gate'), dict) else {}
        if isinstance(gate.get('structure_trade_plan_v796'), dict) and gate.get('structure_trade_plan_v796'):
            return dict(gate.get('structure_trade_plan_v796') or {})
    return {}

def _v797_list(v: Any, limit: int = 8) -> List[str]:
    if v is None:
        return []
    vals = v if isinstance(v, (list, tuple, set)) else [v]
    out: List[str] = []
    for x in vals:
        ss = str(x or '').strip()
        if ss and ss not in out:
            out.append(ss)
        if len(out) >= limit:
            break
    return out

def _v797_find_quality(obj: Any) -> Dict[str, Any]:
    plan = _v797_find_plan(obj)
    good: List[str] = []
    warn: List[str] = []
    reactions: List[str] = []
    line_quality = str(plan.get('line_quality') or '').strip()
    line_reaction = str(plan.get('line_reaction') or '').strip()
    interpretation = str(plan.get('structure_interpretation') or '').strip()
    for src in _v797_sources(obj):
        good += _v797_list(src.get('structure_good_tags_v792') or src.get('structure_good_tags_v794') or src.get('good_tags'), 8)
        warn += _v797_list(src.get('structure_failure_tags_v792') or src.get('structure_warning_tags_v794') or src.get('failure_pattern_tags_v792') or src.get('warning_tags'), 8)
        reactions += _v797_list(src.get('line_reaction_tags_v794') or src.get('structure_line_reaction_tags_v794') or src.get('chart_state_tags_v772'), 8)
        line_quality = line_quality or str(src.get('line_quality_v794') or src.get('structure_line_quality_v794') or '').strip()
        line_reaction = line_reaction or str(src.get('line_reaction_v794') or '').strip()
        interpretation = interpretation or str(src.get('structure_interpretation_v794') or '').strip()
        q = src.get('structure_quality_v793') if isinstance(src.get('structure_quality_v793'), dict) else src.get('structure_quality_v792') if isinstance(src.get('structure_quality_v792'), dict) else {}
        if q:
            good += _v797_list(q.get('good_tags'), 8)
            warn += _v797_list(q.get('failure_pattern_tags'), 8)
    def uniq(xs: List[str], limit: int = 8) -> List[str]:
        out: List[str] = []
        for x in xs:
            ss = str(x or '').strip()
            if ss and ss not in out:
                out.append(ss)
            if len(out) >= limit:
                break
        return out
    return {
        'line_quality': line_quality or '-',
        'line_reaction': line_reaction or (reactions[0] if reactions else '-'),
        'structure_interpretation': interpretation or '-',
        'good_tags': uniq(good, 8),
        'warning_tags': uniq(warn, 8),
        'reaction_tags': uniq(reactions, 8),
    }

def _v797_attach_plan_to_pos(pos: Dict[str, Any], src: Any = None, mark: str = '') -> None:
    if not isinstance(pos, dict):
        return
    plan = _v797_find_plan(pos) or _v797_find_plan(src)
    q = _v797_find_quality(pos) if _v797_find_plan(pos) else _v797_find_quality(src)
    if plan:
        pos['structure_trade_plan_v796'] = plan
        pos['paper_structure_trade_plan_v797'] = plan
        pos['structure_plan_state_v796'] = plan.get('plan_state')
        pos['structure_rr_ratio_v796'] = plan.get('rr_ratio')
        ctx = pos.get('entry_context') if isinstance(pos.get('entry_context'), dict) else {}
        ctx = dict(ctx); ctx['structure_trade_plan_v796'] = plan; pos['entry_context'] = ctx
        diag = pos.get('entry_diagnostics') if isinstance(pos.get('entry_diagnostics'), dict) else {}
        diag = dict(diag); diag['structure_trade_plan_v796'] = plan; pos['entry_diagnostics'] = diag
    if q:
        pos['paper_structure_quality_v797'] = q
    pos['paper_structure_plan_owner_v797'] = mark or 'paper'

def _v797_plan_result_label(row: Dict[str, Any]) -> str:
    plan = _v797_find_plan(row)
    if not plan:
        return '구조계획 없음'
    pnl = fnum(row.get('pnl_pct'), default=0.0)
    peak = fnum(row.get('peak_pct'), default=0.0)
    trough = fnum(row.get('trough_pct'), default=0.0)
    reward = fnum(plan.get('reward_pct'), default=0.0)
    risk = abs(fnum(plan.get('risk_pct'), default=0.0))
    if reward and peak >= reward:
        return '목표도달'
    if risk and trough <= -risk:
        return '무효선권역 이탈'
    if pnl > 0:
        return '구조 일부 성공'
    if peak < 0.20:
        return '진입후 반응 약함'
    return '구조계획 재검토'

def _v800_kst_text(ts: Any = None) -> str:
    try:
        import datetime as _dt
        t = float(ts or now_ts())
        return _dt.datetime.fromtimestamp(t, _dt.timezone(_dt.timedelta(hours=9))).strftime('%Y-%m-%d %H:%M:%S KST')
    except Exception:
        return iso_ts(ts or now_ts())

def _v800_entry_checks(row: Dict[str, Any]) -> Dict[str, Any]:
    srcs = _v793_sources(row) if '_v793_sources' in globals() else [row]
    def pick(*keys: str, default: Any = None) -> Any:
        for obj in srcs:
            if not isinstance(obj, dict):
                continue
            for k in keys:
                v = obj.get(k)
                if v not in (None, '', [], {}):
                    return v
        return default
    return {
        'price_reaction_pct': pick('price_reaction_pct','change_1m_pct','price_chg_60s', default=0.0),
        'buy_ratio': pick('buy_ratio','buy_trade_ratio','buy_ratio_1m', default=0.0),
        'buy_sustain_1m': pick('buy_sustain_1m','buy_sustain_60s','buy_sustain_20s', default=0.0),
        'spread_pct': pick('spread_pct','orderbook_spread_pct', default=0.0),
        'slippage_pct': pick('slippage_pct','expected_slippage_pct','spread_pct', default=0.0),
        'sell_pressure': pick('sell_pressure','sell_pressure_score','ask_pressure', default=0.0),
        'vwap_pos_pct': pick('vwap_pos_pct','vwap_gap_pct', default=0.0),
        'ema5_pos_pct': pick('ema5_pos_pct','ema_gap_pct', default=0.0),
        'trigger_gap_pct': pick('trigger_gap_pct', default=0.0),
    }

def _v800_reaction_label(row: Dict[str, Any]) -> str:
    react = row.get('post_entry_reaction_v800') if isinstance(row.get('post_entry_reaction_v800'), dict) else {}
    if not react:
        return '진입후반응대기'
    labels = [str((react.get(k) or {}).get('label') or '') for k in ('s30','m1','m3','m5','m10') if isinstance(react.get(k), dict)]
    peak = fnum(row.get('peak_pct'), default=0.0)
    trough = fnum(row.get('trough_pct'), default=0.0)
    if any(x in ('바로역행','역행주의') for x in labels):
        return '바로역행'
    if labels and all(x in ('무반응','수수료권무반응') for x in labels[:2]):
        return '진입후반응없음'
    if peak >= 0.90:
        return '강한상승'
    if peak >= 0.35:
        return '초반반응있음'
    if trough <= -0.35 and peak < 0.15:
        return '진입후반응약함'
    return labels[-1] if labels else '진입후반응대기'

def _v800_quality_flags(row: Dict[str, Any]) -> List[str]:
    flags: List[str] = []
    plan = _v797_find_plan(row) if '_v797_find_plan' in globals() else {}
    q = _v797_find_quality(row) if '_v797_find_quality' in globals() else {}
    state = str(plan.get('plan_state') or '') if isinstance(plan, dict) else ''
    rr = fnum(plan.get('rr_ratio'), default=0.0) if isinstance(plan, dict) else 0.0
    line_q = str(q.get('line_quality') or row.get('line_quality') or '')
    if state == 'hard_risk_hold':
        flags.append('hard_risk_hold_open')
    if rr and rr < 1.0:
        flags.append('rr_below_1_open')
    if line_q == 'calculated_line_recheck':
        flags.append('계산선재확인')
    reaction_label = _v800_reaction_label(row)
    if reaction_label in ('바로역행','진입후반응없음','진입후반응약함'):
        flags.append(reaction_label)
    if fnum(row.get('peak_pct'), default=0.0) < 0.05 and row.get('kind') == 'closed':
        flags.append('최고수익0권')
    out=[]
    for x in flags:
        if x and x not in out:
            out.append(x)
    return out[:8]

def _v800_quality_label(row: Dict[str, Any]) -> str:
    pnl = fnum(row.get('pnl_pct'), default=0.0)
    flags = _v800_quality_flags(row)
    if 'hard_risk_hold_open' in flags or 'rr_below_1_open' in flags:
        return 'OPEN하면안됐던후보'
    if '바로역행' in flags:
        return '바로역행'
    if '진입후반응없음' in flags or '진입후반응약함' in flags:
        return '진입후반응약함'
    if pnl > 0:
        return '구조계획성공'
    return '구조계획재검토'

def _v797_trade_detail_record__L11095(kind: str, row: Dict[str, Any], message_text: str = '') -> Dict[str, Any]:
    plan = _v797_find_plan(row)
    q = _v797_find_quality(row)
    timing_spine_v806: Dict[str, Any] = {}
    recheck_trace_v806: Dict[str, Any] = {}
    try:
        for src in _v797_sources(row):
            if not timing_spine_v806 and isinstance(src.get('entry_timing_spine'), dict):
                timing_spine_v806 = dict(src.get('entry_timing_spine') or {})
            if not timing_spine_v806 and isinstance(src.get('entry_timing_trace'), dict):
                timing_spine_v806 = dict(src.get('entry_timing_trace') or {})
            if not recheck_trace_v806 and isinstance(src.get('recheck_freshness_trace_v806'), dict):
                recheck_trace_v806 = dict(src.get('recheck_freshness_trace_v806') or {})
            ctx = src.get('entry_context') if isinstance(src.get('entry_context'), dict) else {}
            if not timing_spine_v806 and isinstance(ctx.get('entry_timing_spine'), dict):
                timing_spine_v806 = dict(ctx.get('entry_timing_spine') or {})
            if not recheck_trace_v806 and isinstance(ctx.get('recheck_freshness_trace_v806'), dict):
                recheck_trace_v806 = dict(ctx.get('recheck_freshness_trace_v806') or {})
    except Exception:
        timing_spine_v806 = timing_spine_v806 or {}
        recheck_trace_v806 = recheck_trace_v806 or {}
    def _quality_value(*keys: str) -> Any:
        try:
            for src in _v797_sources(row):
                if not isinstance(src, dict):
                    continue
                for key in keys:
                    value = src.get(key)
                    if value not in (None, '', [], {}):
                        return value
        except Exception:
            pass
        return None
    exact_decision_key = _v926_decision_key_from_row(row) if '_v926_decision_key_from_row' in globals() else ''
    exact_quality_v938 = _v938_quality_evidence_from_row(row) if '_v938_quality_evidence_from_row' in globals() else {}
    rec = {
        'schema': 'paper_trade_detail_v800',
        'ts': now_ts(),
        'ts_text': iso_ts(),
        'ts_text_kst': _v800_kst_text(now_ts()),
        'kind': kind,
        'ticker': normalize_ticker(row.get('ticker')),
        'pos_id': row.get('pos_id'),
        'event_id': row.get('event_id') or row.get('pos_id'),
        'paper_decision_key_v926': exact_decision_key,
        'minimal_gate_decision_key_v925': _quality_value('minimal_gate_decision_key_v925','decision_key'),
        'opened_ts': exact_quality_v938.get('opened_ts'),
        'paper_selected_ts': exact_quality_v938.get('paper_selected_ts'),
        'first_to_selected_delay_sec': exact_quality_v938.get('first_to_selected_delay_sec'),
        's1_to_selected_delay_sec': exact_quality_v938.get('s1_to_selected_delay_sec'),
        'trigger_to_selected_delay_sec': exact_quality_v938.get('trigger_to_selected_delay_sec'),
        'selected_to_open_delay_sec': exact_quality_v938.get('selected_to_open_delay_sec'),
        'first_to_paper_delay_sec': exact_quality_v938.get('first_to_paper_delay_sec'),
        's1_to_paper_delay_sec': exact_quality_v938.get('s1_to_paper_delay_sec'),
        'trigger_reached_ts': exact_quality_v938.get('trigger_reached_ts'),
        'trigger_frozen_ts': exact_quality_v938.get('trigger_frozen_ts'),
        'entry_trigger_gap_pct': exact_quality_v938.get('entry_trigger_gap_pct'),
        'first_seen_ts': exact_quality_v938.get('first_seen_ts'),
        's1_seen_ts': exact_quality_v938.get('s1_seen_ts'),
        'trigger_reached_ts_source_v938': exact_quality_v938.get('trigger_reached_ts_source_v938'),
        'quality_evidence_schema_v938': exact_quality_v938.get('quality_evidence_schema_v938'),
        'entry_build_key': row.get('entry_build_key') or row.get('score_patch_version'),
        'closed_result_key': row.get('closed_result_key'),
        'closed_ts': row.get('closed_ts') or row.get('closed_at'),
        'closed_day_kst': row.get('closed_day_kst'),
        'strategy': row.get('strategy_label') or row.get('strategy_key') or row.get('strategy') or '-',
        'grade': row.get('candidate_grade') or row.get('s_stage') or '-',
        'entry_price': row.get('entry_price'),
        'exit_price': row.get('exit_price'),
        'pnl_pct': row.get('pnl_pct'),
        'gross_peak_pct': row.get('gross_peak_pct'),
        'gross_trough_pct': row.get('gross_trough_pct'),
        'last_gross_pct_v804': row.get('last_gross_pct_v804'),
        'peak_pct': row.get('peak_pct'),
        'trough_pct': row.get('trough_pct'),
        'age_min': row.get('age_min'),
        'hold_sec': row.get('hold_sec'),
        'exit_reason': row.get('exit_rule_label') or row.get('exit_reason'),
        'plan': plan,
        'entry_timing_spine': timing_spine_v806,
        'recheck_freshness_trace_v806': recheck_trace_v806,
        'line_quality': q.get('line_quality'),
        'line_reaction': q.get('line_reaction'),
        'structure_interpretation': q.get('structure_interpretation'),
        'good_tags': q.get('good_tags') or [],
        'warning_tags': q.get('warning_tags') or [],
        'reaction_tags': q.get('reaction_tags') or [],
        'entry_checks_v800': _v800_entry_checks(row),
        'post_entry_reaction_v800': row.get('post_entry_reaction_v800') if isinstance(row.get('post_entry_reaction_v800'), dict) else {},
        'post_entry_reaction_v793': row.get('post_entry_reaction_v793') if isinstance(row.get('post_entry_reaction_v793'), dict) else {},
        'plan_result_label': _v797_plan_result_label(row) if kind == 'closed' else '-',
        'quality_label_v800': _v800_quality_label(row) if kind == 'closed' else 'OPEN대기',
        'quality_flags_v800': _v800_quality_flags(row),
        'paper_version': VERSION,
        'build': BUILD_LABEL,
        'message_preview': str(message_text or '')[:1200],
    }
    return rec

def _v797_append_trade_detail(kind: str, row: Dict[str, Any], message_text: str = '') -> None:
    try:
        rec = _v797_trade_detail_record(kind, row, message_text)
        path = FILES.get('trade_detail_v800', BASE_DIR / 'paper_bot_trade_detail_v800.jsonl')
        append_jsonl(path, rec)
        rows = read_jsonl_tail(path, 320) if 'read_jsonl_tail' in globals() else []
        save_json(FILES.get('trade_detail_cache_v800', BASE_DIR / 'paper_bot_trade_detail_cache_v800.json'), {
            'schema': 'paper_trade_detail_cache_v800',
            'updated_ts': now_ts(),
            'updated_text': iso_ts(),
            'updated_text_kst': _v800_kst_text(now_ts()),
            'count': len(rows),
            'events': rows,
            'owner': 'paper_bot',
            'note': 'main /batch reads this paper-owned cache only; OPEN/CLOSED ledger is not deleted or recalculated here.',
        })
    except Exception as exc:
        try: log_error('v800_append_trade_detail', exc)
        except Exception: pass

def _v983_reason_label(reason: Any) -> str:
    value = str(reason or '').strip()
    return {
        'structure_target':'구조 목표가 도달',
        'structure_invalid':'구조 무효선 이탈',
        'swing_no_progress':'6시간 무반응 약세 정리',
        'swing_max_weak_hold':'72시간 약한 흐름 정리',
        'swing_trailing':'수익보호 추적청산',
    }.get(value, value or '자료 없음')

def _v983_fmt_optional(v: Any, digits: int = 2, suffix: str = '') -> str:
    try:
        if v in (None, '', '-'):
            return '자료 없음'
        return f'{float(v):+.{digits}f}{suffix}'
    except Exception:
        return str(v)

def _v983_open_message_text(pos: Dict[str, Any]) -> str:
    pos = pos if isinstance(pos, dict) else {}
    ev = pos.get('entry_evidence_v983') if isinstance(pos.get('entry_evidence_v983'), dict) else _v983_build_entry_evidence(pos)
    t = normalize_ticker(pos.get('ticker'))
    link = f'https://www.bithumb.com/trade/order/{t}_KRW' if t else ''
    trigger = ev.get('trigger') if isinstance(ev.get('trigger'), dict) else {}
    invalid = ev.get('invalid') if isinstance(ev.get('invalid'), dict) else {}
    target = ev.get('target') if isinstance(ev.get('target'), dict) else {}
    cost = ev.get('cost') if isinstance(ev.get('cost'), dict) else {}
    timing = ev.get('timing') if isinstance(ev.get('timing'), dict) else {}
    lines = [
        '🟡 PAPER OPEN', '',
        f'종목: {t or "자료 없음"}',
        f'진입 방식: {ev.get("setup_type") or "자료 없음"}',
        f'전략: {ev.get("strategy_mode") or "ALT_SWING_V977"}',
        f'등급: {pos.get("candidate_grade") or "S1"} · 점수 {fnum(pos.get("score"),default=0.0):.2f}', '',
        '[가격 구조]',
        f'진입가: {fmt_price(ev.get("entry_price"))}',
        f'Trigger: {fmt_price(trigger.get("price"))} · {trigger.get("timeframe") or "자료 없음"}',
        f'Invalid: {fmt_price(invalid.get("price"))} · {invalid.get("timeframe") or "자료 없음"}',
        f'Target: {fmt_price(target.get("price"))} · {target.get("timeframe") or "자료 없음"}', '',
        '[진입 조건]',
        f'손익비: {fnum(ev.get("risk_reward"),default=0.0):.2f}',
        f'목표 공간: {fnum(ev.get("target_room_pct"),default=0.0):+.2f}%',
        f'Trigger 추격: {fnum(ev.get("trigger_chase_pct"),default=0.0):+.2f}%',
        f'Spread: {fnum(cost.get("spread_pct"),default=0.0):.2f}%', '',
        '[진입 시간]',
        f'최초 후보→OPEN: {_v983_fmt_optional(timing.get("first_to_open_delay_sec"),1,"초")}',
        f'S1→OPEN: {_v983_fmt_optional(timing.get("s1_to_open_delay_sec"),1,"초")}',
        f'선택→OPEN: {_v983_fmt_optional(timing.get("selected_to_open_delay_sec"),1,"초")}', '',
        '[판정]',
        '상태: S1_PASS',
        '자동매수: OFF',
        '15분 고정청산: 사용 안 함',
    ]
    if link:
        lines += ['', f'바로보기: {link}']
    lines += ['', f'paper: {VERSION} · {BUILD_LABEL}']
    return '\n'.join(lines)

def _v983_closed_message_text(row: Dict[str, Any]) -> str:
    row = row if isinstance(row, dict) else {}
    ev = row.get('entry_evidence_v983') if isinstance(row.get('entry_evidence_v983'), dict) else _v983_build_entry_evidence(row)
    trigger = ev.get('trigger') if isinstance(ev.get('trigger'), dict) else {}
    invalid = ev.get('invalid') if isinstance(ev.get('invalid'), dict) else {}
    target = ev.get('target') if isinstance(ev.get('target'), dict) else {}
    compliant, violation = _v983_exit_contract_status(row.get('exit_reason') or row.get('exit_rule'))
    age = fnum(row.get('age_min'), default=0.0)
    hold = f'{age:.1f}분' if age < 60 else f'{age/60.0:.2f}시간'
    closed_emoji = _v988_closed_emoji(row)
    lines = [
        f'{closed_emoji} PAPER CLOSED', '',
        f'종목: {normalize_ticker(row.get("ticker")) or "자료 없음"}',
        f'진입 방식: {ev.get("setup_type") or "자료 없음"}',
        f'청산 사유: {_v983_reason_label(row.get("exit_reason") or row.get("exit_rule"))}',
        f'계약 판정: {"정상" if compliant else "제외 대상 · " + violation}',
        f'최종 실현손익: {_v983_fmt_optional(row.get("net_after_configured_fee_pct_v983", row.get("pnl_pct")),2,"%")}', '',
        '[가격]',
        f'진입가: {fmt_price(row.get("entry_price"))}',
        f'청산가: {fmt_price(row.get("exit_price"))}',
        f'Trigger: {fmt_price(trigger.get("price"))} · {trigger.get("timeframe") or "자료 없음"}',
        f'Invalid: {fmt_price(invalid.get("price"))} · {invalid.get("timeframe") or "자료 없음"}',
        f'Target: {fmt_price(target.get("price"))} · {target.get("timeframe") or "자료 없음"}', '',
        '[결과 상세]',
        f'가격 변동: {_v983_fmt_optional(row.get("gross_pnl_pct_v983", row.get("last_gross_pct_v804")),2,"%")}',
        f'거래비용: -{fnum(row.get("configured_roundtrip_fee_pct_v983"),default=0.10):.2f}%',
        f'보유시간: {hold}', '',
        '[가격 경로]',
        f'MFE 최대수익: {_v983_fmt_optional(row.get("mfe_pct_v983", row.get("peak_pct")),2,"%")}',
        f'MAE 최대손실: {_v983_fmt_optional(row.get("mae_pct_v983", row.get("trough_pct")),2,"%")}',
        f'수익 반납: {fnum(row.get("giveback_pct_v983", row.get("giveback_pct")),default=0.0):.2f}%p', '',
        '[원장]',
        'CLOSED 저장: 성공',
        'Decision CLOSED: 성공',
        'OPEN 제거: 성공',
        f'paper: {VERSION} · {BUILD_LABEL}',
    ]
    return '\n'.join(lines)

def _v628_send_with_result(text: str) -> Tuple[bool, str]:
    if '_v561_send_message_with_result' in globals():
        try:
            return _v561_send_message_with_result(text)  # type: ignore[name-defined]
        except Exception as exc:
            log_error('v628_send_with_result_prev', exc)
    try:
        send_message(text)
        return True, ''
    except Exception as exc:
        return False, f'{type(exc).__name__}: {exc}'

def notify_opened__L11378(pos: Dict[str, Any]) -> None:  # type: ignore[override]
    _v567_append_trade_alert_trace('open', pos, 'attempt_start', False, '', 'canonical OPEN persisted; alert send started')
    try:
        text = _v983_open_message_text(pos)
    except Exception as exc:
        err = f'{type(exc).__name__}: {exc}'
        _v567_append_trade_alert_trace('open', pos, 'message_build_error', False, err, 'OPEN alert text build failed')
        log_error('notify_opened_text_build', exc)
        return
    ok, err = _v628_send_with_result(text)
    phase = 'send_ok' if ok else 'send_error'
    _v567_append_trade_alert_trace('open', pos, phase, ok, err, 'canonical OPEN alert send result')
    _v628_append_hourly_event('open', pos, text, phase, err)
    _v797_append_trade_detail('open', pos, text)
    if not ok:
        log_error('notify_opened_send_result', Exception(err or 'send failed'))

def notify_closed(row: Dict[str, Any]) -> None:
    _v567_append_trade_alert_trace('closed', row, 'attempt_start', False, '', 'canonical CLOSED commit completed; alert send started')
    try:
        text = _v983_closed_message_text(row)
    except Exception as exc:
        err = f'{type(exc).__name__}: {exc}'
        _v567_append_trade_alert_trace('closed', row, 'message_build_error', False, err, 'CLOSED alert text build failed')
        log_error('notify_closed_text_build', exc)
        return
    ok, err = _v628_send_with_result(text)
    phase = 'send_ok' if ok else 'send_error'
    _v567_append_trade_alert_trace('closed', row, phase, ok, err, 'canonical CLOSED alert send result')
    try:
        _v797_attach_plan_to_pos(row, row, 'closed')
    except Exception as exc:
        log_error('notify_closed_attach_plan', exc)
    _v628_append_hourly_event('closed', row, text, phase, err)
    _v797_append_trade_detail('closed', row, text)
    if not ok:
        log_error('notify_closed_send_result', Exception(err or 'send failed'))

def _v628_hour_key(ts: Optional[float] = None) -> str:
    return _kst_datetime(ts or now_ts()).strftime('%Y-%m-%d_%H')

def _v930_read_jsonl_tail_bytes(path: Path, max_lines: int, max_bytes: int = 64 * 1024 * 1024) -> List[Dict[str, Any]]:
    if max_lines <= 0 or not path.exists():
        return []
    try:
        size = path.stat().st_size
        chunks: List[bytes] = []
        remain = min(size, max_bytes)
        with path.open('rb') as f:
            pos = size
            newline_count = 0
            while pos > 0 and remain > 0 and newline_count <= max_lines:
                take = min(65536, pos, remain)
                pos -= take
                f.seek(pos)
                block = f.read(take)
                chunks.append(block)
                newline_count += block.count(b'\n')
                remain -= take
        data = b''.join(reversed(chunks))
        lines = data.splitlines()[-max_lines:]
        out: List[Dict[str, Any]] = []
        for line in lines:
            try:
                obj = json.loads(line.decode('utf-8', errors='ignore'))
                if isinstance(obj, dict):
                    out.append(obj)
            except Exception:
                continue
        return out
    except Exception as exc:
        log_error('v930_read_hourly_tail', exc)
        return []

def _v628_event_rows() -> List[Dict[str, Any]]:
    return _v930_read_jsonl_tail_bytes(FILES['hourly_event_trace'], 5000)

BUILD_LABEL = 'structure_board_mainline_2026-06-10'

BUILD_LABEL = 'structure_board_mainline_2026-06-10'

def _v741_closed_ts(row: Dict[str, Any]) -> float:
    if not isinstance(row, dict):
        return 0.0
    return fnum(
        row.get("closed_at"), row.get("closed_ts"), row.get("exit_ts"), row.get("closed_time"),
        row.get("updated_at"), row.get("ts"), row.get("timestamp"),
        default=0.0,
    )

def _v741_recent_rows(rows: List[Dict[str, Any]], hours: float) -> List[Dict[str, Any]]:
    cutoff = now_ts() - float(hours) * 3600.0
    return [r for r in (rows or []) if isinstance(r, dict) and _v741_closed_ts(r) >= cutoff]

def _v747_closed_bucket(row: Dict[str, Any]) -> str:
    pnl = fnum(row.get('pnl_pct'), row.get('profit_pct'), row.get('return_pct'), default=0.0)
    reason = str(row.get('exit_reason') or row.get('exit_rule') or row.get('close_reason') or '').lower()
    if pnl >= 2.0:
        return 'big_profit'
    if pnl > 0:
        return 'normal_profit'
    if 'fast_fail' in reason or '빠른실패' in reason:
        return 'fast_fail'
    if 'time' in reason or '시간' in reason:
        return 'time_exit'
    if 'stop' in reason or pnl <= -0.50:
        return 'stop_loss'
    return 'other_loss'

def _v747_stat_rows(rows: List[Dict[str, Any]]) -> Dict[str, Any]:
    return _score_stat([r for r in (rows or []) if isinstance(r, dict)])

def _v747_bucket_stats(rows: List[Dict[str, Any]]) -> Dict[str, Any]:
    buckets: Dict[str, List[Dict[str, Any]]] = {k: [] for k in ('big_profit','normal_profit','stop_loss','fast_fail','time_exit','other_loss')}
    for r in rows or []:
        if isinstance(r, dict):
            buckets.setdefault(_v747_closed_bucket(r), []).append(r)
    return {k: _v747_stat_rows(v) for k, v in buckets.items()}

def _v747_pick_num(*vals: Any) -> Tuple[bool, float]:
    """값 없음과 0.0을 구분한다. classify 과분류 방지용."""
    for v in vals:
        if v is None:
            continue
        if isinstance(v, str) and not v.strip():
            continue
        try:
            x = fnum(v, default=None)  # type: ignore[arg-type]
        except Exception:
            x = None
        if x is not None:
            return True, float(x)
    return False, 0.0

def _v747_timing_age(row: Dict[str, Any]) -> float:
    snap = row.get('canonical_entry_snapshot') if isinstance(row.get('canonical_entry_snapshot'), dict) else {}
    timing = snap.get('timing_spine') if isinstance(snap.get('timing_spine'), dict) else {}
    vals = [
        row.get('entry_age_sec'), row.get('candidate_age_sec'), row.get('first_to_now_delay_sec'), row.get('s2_to_now_delay_sec'),
        timing.get('first_to_now_delay_sec'), timing.get('s2_to_now_delay_sec'), timing.get('first_to_s1_delay_sec'),
    ]
    nums = []
    for v in vals:
        ok, x = _v747_pick_num(v)
        if ok:
            nums.append(x)
    return max(nums or [0.0])

def _v751_source_age_for_closed(row: Dict[str, Any]) -> float:
    raw, snap, mat, ctx = _v747_nested(row)
    ok, ts = _v747_pick_num(
        row.get('candidate_created_at'), row.get('source_created_at'), row.get('event_ts'), row.get('detected_ts'), row.get('created_at'), row.get('entry_ts'), row.get('opened_at'),
        raw.get('candidate_created_at'), raw.get('source_created_at'), raw.get('event_ts'), raw.get('detected_ts'), raw.get('created_at'),
        snap.get('candidate_created_at'), snap.get('source_created_at'), snap.get('event_ts'), snap.get('detected_ts'), snap.get('created_at'),
        ctx.get('candidate_created_at'), ctx.get('source_created_at'), ctx.get('event_ts'), ctx.get('detected_ts'), ctx.get('created_at'),
    )
    if not ok or ts <= 0:
        return 999999.0
    base_ts = fnum(row.get('entry_ts'), row.get('opened_at'), row.get('created_at'), default=0.0) or now_ts()
    return max(0.0, base_ts - ts)

def _v751_timing_contaminated(row: Dict[str, Any]) -> bool:
    return _v747_timing_age(row) >= 600 and _v751_source_age_for_closed(row) <= 300

def _v747_entry_price(row: Dict[str, Any]) -> float:
    return fnum(row.get('entry_price'), row.get('open_price'), row.get('buy_price'), row.get('price'), default=0.0)

def _v747_trigger_gap(row: Dict[str, Any]) -> float:
    raw, snap, mat, ctx = _v747_nested(row)
    ok, gap = _v747_pick_num(row.get('trigger_gap_pct'), raw.get('trigger_gap_pct'), row.get('entry_trigger_gap_pct'), ctx.get('trigger_gap_pct'))
    if ok:
        return gap
    entry = _v747_entry_price(row)
    trig_ok, trig = _v747_pick_num(row.get('trigger_price'), raw.get('trigger_price'), ctx.get('trigger_price'))
    if entry > 0 and trig_ok and trig > 0:
        return ((entry - trig) / trig) * 100.0
    return 0.0

def _v747_exit_issue_trace() -> Dict[str, Any]:
    c: Counter = Counter()
    rows = read_jsonl_tail(BASE_DIR / 'paper_bot_stop_overrun_trace.jsonl', 160)
    for r in rows:
        if not isinstance(r, dict):
            continue
        c['손절초과'] += 1
        if fnum(r.get('position_update_gap_sec'), default=0.0) >= 10:
            c['loopgap 의심'] += 1
        if fnum(r.get('price_cache_age_sec'), default=0.0) >= 10:
            c['가격조회 지연'] += 1
    return {'tail_count': len(rows), 'top': dict(c.most_common(10))}

def _v747_lifecycle_from_status(status: Optional[Dict[str, Any]]) -> Dict[str, Any]:
    c: Counter = Counter()
    if isinstance(status, dict):
        ht = status.get('hold_trace_summary_v746') if isinstance(status.get('hold_trace_summary_v746'), dict) else {}
        counts = ht.get('status_counts') if isinstance(ht.get('status_counts'), dict) else {}
        tail = counts.get('tail') if isinstance(counts.get('tail'), dict) else {}
        for k, v in tail.items():
            c[str(k)] += int(v or 0)
        pre = ht.get('preopen_guard_top') if isinstance(ht.get('preopen_guard_top'), dict) else {}
        last5 = pre.get('last5m') if isinstance(pre.get('last5m'), dict) else {}
        for k, v in last5.items():
            c[f'OPEN직전:{k}'] += int(v or 0)
    return {'top': dict(c.most_common(10))}

def _v747_build_classify_cache__L12363(rows: List[Dict[str, Any]], status: Optional[Dict[str, Any]] = None) -> Dict[str, Any]:
    nowv = now_ts()
    rows = [r for r in (rows or []) if isinstance(r, dict)]
    r3 = _v741_recent_rows(rows, 3.0)
    r6 = _v741_recent_rows(rows, 6.0)
    r24 = _v741_recent_rows(rows, 24.0)
    return {
        'schema': 'paper_classify_board_v754',
        'version': VERSION,
        'paper_version': VERSION,
        'build': BUILD_LABEL,
        'updated_at': nowv,
        'updated_at_text': iso_ts(nowv),
        'source': 'paper_bot_reconciled_closed_tail_plus_status_trace_cache_only',
        'policy': 'classification board is persistent; add new categories here instead of deleting/recreating scattered panels',
        'performance_breakdown': {
            'recent_3h': {'global': _v747_stat_rows(r3), 'buckets': _v747_bucket_stats(r3)},
            'recent_6h': {'global': _v747_stat_rows(r6), 'buckets': _v747_bucket_stats(r6)},
            'recent_24h': {'global': _v747_stat_rows(r24), 'buckets': _v747_bucket_stats(r24)},
        },
        'entry_quality': _v747_entry_quality(r24),
        'loss_split': {
            'recent_3h': _v749_loss_split(r3),
            'recent_6h': _v749_loss_split(r6),
            'recent_24h': _v749_loss_split(r24),
        },
        'exit_issues': _v747_exit_issue_trace(),
        'lifecycle': _v747_lifecycle_from_status(status),
        'notes': ['성과분해', '진입품질', '청산문제', '후보생애주기', 'worker age는 main_bot /classify에서 합성 표시', 'v754: pre-main active entry_snapshot spine; legacy rows separated from missing materials'],
    }

BUILD_LABEL = 'structure_board_mainline_2026-06-10'

FILES.setdefault('hourly_summary_trace', BASE_DIR / 'paper_bot_hourly_summary_trace.json')

FILES.setdefault('hourly_summary_tmp', BASE_DIR / 'paper_bot_latest_hourly_summary.txt')

_V631_HOURLY_BUCKET: Dict[str, Any] = {}

def _v631_trim_text(s: Any, limit: int = 5000) -> str:
    txt = str(s or '').strip()
    if len(txt) <= limit:
        return txt
    return txt[:limit] + '\n…(1시간 요약집에서 일부 절단)'

def _v631_bucket_reset(now: Optional[float] = None) -> Dict[str, Any]:
    ts = fnum(now, default=now_ts())
    obj = {
        'start_ts': ts,
        'start_text': iso_ts(ts),
        'cycles': 0,
        's1_seen': 0,
        'selected_s1': 0,
        'paper_entry_hold': 0,
        'paper_final_block': 0,
        'micro_preopen_wait': 0,
        'opened': 0,
        'closed': 0,
        'latest_count_max': 0,
        'fresh_count_max': 0,
        'last_s1_seen': None,
        'last_paper_entry_hold': None,
        'last_open_try': None,
        'last_skip': None,
    }
    _V631_HOURLY_BUCKET.clear()
    _V631_HOURLY_BUCKET.update(obj)
    return _V631_HOURLY_BUCKET

def _v631_bucket() -> Dict[str, Any]:
    if not isinstance(_V631_HOURLY_BUCKET, dict) or not _V631_HOURLY_BUCKET.get('start_ts'):
        return _v631_bucket_reset(now_ts())
    return _V631_HOURLY_BUCKET

def _v631_pick_int(pick: Dict[str, Any], *keys: str) -> int:
    for k in keys:
        if k in pick:
            return int(fnum(pick.get(k), default=0.0))
    return 0

def _v631_bucket_collect(status: Dict[str, Any]) -> Dict[str, Any]:
    b = _v631_bucket()
    pick = status.get('pick_stats') if isinstance(status.get('pick_stats'), dict) else {}
    b['cycles'] = int(b.get('cycles') or 0) + 1
    b['s1_seen'] = int(b.get('s1_seen') or 0) + _v631_pick_int(pick, 's1_seen')
    b['selected_s1'] = int(b.get('selected_s1') or 0) + _v631_pick_int(pick, 'selected_s1')
    hold = _v631_pick_int(pick, 'paper_entry_hold', 'paper_final_block')
    b['paper_entry_hold'] = int(b.get('paper_entry_hold') or 0) + hold
    b['paper_final_block'] = int(b.get('paper_final_block') or 0) + _v631_pick_int(pick, 'paper_final_block')
    b['micro_preopen_wait'] = int(b.get('micro_preopen_wait') or 0) + _v631_pick_int(pick, 'micro_preopen_wait')
    b['opened'] = int(b.get('opened') or 0) + int(fnum(status.get('opened_this_cycle'), default=0.0))
    b['closed'] = int(b.get('closed') or 0) + int(fnum(status.get('closed_this_cycle'), default=0.0))
    b['latest_count_max'] = max(int(b.get('latest_count_max') or 0), int(fnum(pick.get('latest_count', status.get('latest_count')), default=0.0)))
    b['fresh_count_max'] = max(int(b.get('fresh_count_max') or 0), int(fnum(pick.get('merged_fresh', status.get('merged_fresh')), default=0.0)))
    for src_key, dst_key in (('last_s1_seen','last_s1_seen'), ('last_paper_entry_hold','last_paper_entry_hold'), ('last_paper_final_block','last_paper_entry_hold'), ('last_open_try','last_open_try'), ('last_skip','last_skip')):
        obj = pick.get(src_key)
        if isinstance(obj, dict):
            b[dst_key] = obj
    return b

def _v631_row_ts(row: Dict[str, Any]) -> float:
    for k in ('closed_at', 'close_ts', 'closed_ts', 'exit_ts', 'updated_at', 'ts', 'time'):
        v = row.get(k)
        if isinstance(v, (int, float)) and v > 1_000_000_000:
            return float(v)
        if isinstance(v, str):
            try:
                return float(v)
            except Exception:
                pass
    return 0.0

def _v631_recent_closed_rows(hours: float = 1.0, max_lines: int = 800) -> List[Dict[str, Any]]:
    cutoff = now_ts() - max(0.2, hours) * 3600.0
    rows: List[Dict[str, Any]] = []
    try:
        if not FILES['closed'].exists():
            return []
        lines = FILES['closed'].read_text(encoding='utf-8', errors='ignore').splitlines()[-max_lines:]
        for line in lines:
            try:
                obj = json.loads(line)
            except Exception:
                continue
            if not isinstance(obj, dict):
                continue
            ts = _v631_row_ts(obj)
            if ts and ts >= cutoff:
                rows.append(obj)
    except Exception as exc:
        log_error('v631_recent_closed_rows', exc)
    return rows[-80:]

def _v631_row_pnl(row: Dict[str, Any]) -> float:
    return fnum(row.get('net_pct'), row.get('pnl_pct'), row.get('profit_pct'), row.get('return_pct'), default=0.0)

def _v631_row_strategy(row: Dict[str, Any]) -> str:
    return str(row.get('strategy_label') or row.get('strategy') or row.get('strategy_key') or '미분류')

def _v631_closed_lines(rows: List[Dict[str, Any]], limit: int = 20) -> List[str]:
    if not rows:
        return ['- 최근 1시간 CLOSED 없음']
    out: List[str] = []
    total = sum(_v631_row_pnl(r) for r in rows)
    wins = sum(1 for r in rows if _v631_row_pnl(r) > 0)
    out.append(f"- 최근 1시간 CLOSED {len(rows)}전 / {wins}승 {len(rows)-wins}패 / 합산 {total:+.2f}% / 평균 {(total/len(rows)):+.2f}%")
    for r in rows[-limit:]:
        t = str(r.get('ticker') or r.get('symbol') or '-').replace('KRW-','').replace('_KRW','')
        reason = str(r.get('exit_reason') or r.get('exit_rule_label') or r.get('reason') or '-')
        out.append(f"- {t} {_v631_row_pnl(r):+.2f}% / {_v631_row_strategy(r)} / {reason}")
    return out

def _v631_open_lines(limit: int = 20) -> List[str]:
    try:
        rows = list(load_open().values())
    except Exception:
        rows = []
    if not rows:
        return ['- 현재 OPEN 없음']
    out = [f'- 현재 OPEN {len(rows)}개']
    for r in rows[:limit]:
        if not isinstance(r, dict):
            continue
        t = str(r.get('ticker') or r.get('symbol') or '-').replace('KRW-','').replace('_KRW','')
        entry = fmt_price(r.get('entry_price'))
        out.append(f"- {t} / 진입 {entry} / {_v631_row_strategy(r)} / {r.get('candidate_grade', r.get('grade','S1'))}")
    return out

def _v631_short_decision(obj: Any, label: str) -> str:
    if not isinstance(obj, dict):
        return f'- {label}: -'
    t = str(obj.get('ticker') or obj.get('symbol') or '-').replace('KRW-','').replace('_KRW','')
    reason = str(obj.get('reason') or obj.get('block_reason') or obj.get('status') or '-')[:160]
    return f'- {label}: {t} / {reason}'

def _v631_build_hourly_summary_text(status: Dict[str, Any], bucket: Dict[str, Any], closed_rows: List[Dict[str, Any]]) -> str:
    start_ts = fnum(bucket.get('start_ts'), default=now_ts())
    elapsed_min = max(1, int(round((now_ts() - start_ts) / 60.0)))
    pick = status.get('pick_stats') if isinstance(status.get('pick_stats'), dict) else {}
    sections: List[str] = [
        'paper 매매 1시간 요약집 v631',
        f'- 생성: {iso_ts()}',
        f'- 기간: {bucket.get("start_text") or iso_ts(start_ts)} ~ {iso_ts()} / 약 {elapsed_min}분',
        f'- paper: {VERSION} / {BUILD_LABEL}',
        '',
        '[1시간 집계]',
        f"- cycle {bucket.get('cycles',0)} / S1감지 {bucket.get('s1_seen',0)} / 선택 {bucket.get('selected_s1',0)} / OPEN보류 {bucket.get('paper_entry_hold',0)} / micro대기 {bucket.get('micro_preopen_wait',0)}",
        f"- OPEN {bucket.get('opened',0)} / CLOSED {bucket.get('closed',0)} / 후보 max latest {bucket.get('latest_count_max',0)} / fresh {bucket.get('fresh_count_max',0)}",
        _v631_short_decision(bucket.get('last_paper_entry_hold'), '마지막 OPEN보류'),
        _v631_short_decision(bucket.get('last_open_try'), '마지막 OPEN시도'),
        _v631_short_decision(bucket.get('last_s1_seen'), '마지막 S1감지'),
        '',
        '[현재 OPEN]',
        *_v631_open_lines(),
        '',
        '[최근 1시간 CLOSED]',
        *_v631_closed_lines(closed_rows),
        '',
        '[paper 상태 /pstatus]',
        _v631_trim_text(pstatus_text() if 'pstatus_text' in globals() else '', 4500),
        '',
        '[시장 hot-rank 요약]',
        _v631_trim_text(hot_summary_text() if 'hot_summary_text' in globals() else '', 3500),
        '',
        '[후보 요약]',
        _v631_trim_text(candidate_summary_text() if 'candidate_summary_text' in globals() else '', 3500),
    ]
    try:
        review = load_json(FILES['trade_review'], {}) or {}
        rv = str(review.get('summary_text') or '').strip()
        if rv:
            sections += ['', '[전략 승리군/패배군 요약]', _v631_trim_text(rv, 6000)]
    except Exception as exc:
        log_error('v631_hourly_review_section', exc)
    sections += ['', '[trace]', '- 전송 성공 시 이 txt는 서버에서 즉시 삭제됩니다.', '- 조건/S등급/청산/자동매수/장부 변경 없음.']
    return '\n'.join(sections)

BUILD_LABEL = 'structure_board_mainline_2026-06-10'

_V632_HOURLY_SCHEMA = 'paper_hourly_summary_v632_dual_room_send_delete'

FILES.setdefault('hourly_summary_trace', BASE_DIR / 'paper_bot_hourly_summary_trace.json')

FILES.setdefault('hourly_summary_tmp', BASE_DIR / 'paper_bot_latest_hourly_summary.txt')

FILES.setdefault('hourly_raw_pack_trace', BASE_DIR / 'paper_bot_hourly_raw_pack_trace.json')

def _v632_send_document_to_chat(path: Path, filename: str, caption: str, chat_id: str) -> Tuple[bool, str]:
    if not TOKEN:
        return False, 'telegram_disabled: TOKEN missing'
    if not chat_id:
        return False, 'telegram_disabled: chat_id missing'
    try:
        import uuid
        boundary = '----coinbotpaperhourlyv632' + uuid.uuid4().hex
        chunks: List[bytes] = []
        def field(name: str, value: str) -> None:
            chunks.append((f'--{boundary}\r\nContent-Disposition: form-data; name="{name}"\r\n\r\n{value}\r\n').encode('utf-8'))
        field('chat_id', str(chat_id))
        field('caption', caption[:1000])
        field('disable_web_page_preview', 'true')
        chunks.append((f'--{boundary}\r\nContent-Disposition: form-data; name="document"; filename="{filename}"\r\nContent-Type: text/plain; charset=utf-8\r\n\r\n').encode('utf-8'))
        chunks.append(path.read_bytes())
        chunks.append(f'\r\n--{boundary}--\r\n'.encode('utf-8'))
        req = urllib.request.Request(
            f'https://api.telegram.org/bot{TOKEN}/sendDocument',
            data=b''.join(chunks),
            headers={'Content-Type': f'multipart/form-data; boundary={boundary}'},
        )
        urllib.request.urlopen(req, timeout=3).read()
        return True, ''
    except Exception as exc:
        log_error('v632_send_document_to_chat', exc)
        return False, f'{type(exc).__name__}: {exc}'

def _v632_save_hourly_trace(trace: Dict[str, Any]) -> None:
    try:
        trace = dict(trace or {})
        trace.setdefault('schema', _V632_HOURLY_SCHEMA)
        trace.setdefault('version', VERSION)
        trace.setdefault('build', BUILD_LABEL)
        trace.setdefault('updated_at', now_ts())
        trace.setdefault('updated_at_text', iso_ts())
        save_json(FILES['hourly_summary_trace'], trace)
    except Exception as exc:
        log_error('v632_save_hourly_trace', exc)
    try:
        st = load_json(FILES['status'], {}) or {}
        if isinstance(st, dict):
            st['version'] = VERSION
            st['paper_version'] = VERSION
            st['build'] = BUILD_LABEL
            st['paper_hourly_summary_trace'] = trace
            st['hourly_summary_schema'] = _V632_HOURLY_SCHEMA
            st['hourly_summary_updated_at'] = now_ts()
            _stage_status_fields(st)
    except Exception as exc:
        log_error('v632_status_hourly_trace', exc)

def _v632_hourly_trace_result(result: str, bucket: Dict[str, Any], extra: Optional[Dict[str, Any]] = None) -> Dict[str, Any]:
    obj = {
        'schema': _V632_HOURLY_SCHEMA,
        'version': VERSION,
        'build': BUILD_LABEL,
        'updated_at': now_ts(),
        'updated_at_text': iso_ts(),
        'window_start_ts': fnum(bucket.get('start_ts'), default=now_ts()) if isinstance(bucket, dict) else now_ts(),
        'window_start_text': bucket.get('start_text') if isinstance(bucket, dict) else '',
        'result': result,
        'cycles': int(bucket.get('cycles') or 0) if isinstance(bucket, dict) else 0,
        's1_seen': int(bucket.get('s1_seen') or 0) if isinstance(bucket, dict) else 0,
        'selected_s1': int(bucket.get('selected_s1') or 0) if isinstance(bucket, dict) else 0,
        'paper_entry_hold': int(bucket.get('paper_entry_hold') or 0) if isinstance(bucket, dict) else 0,
        'micro_preopen_wait': int(bucket.get('micro_preopen_wait') or 0) if isinstance(bucket, dict) else 0,
        'opened': int(bucket.get('opened') or 0) if isinstance(bucket, dict) else 0,
        'closed': int(bucket.get('closed') or 0) if isinstance(bucket, dict) else 0,
    }
    if isinstance(extra, dict):
        obj.update(extra)
    return obj

def _v632_maybe_send_paper_hourly_summary(status: Dict[str, Any]) -> None:
    try:
        ctrl = load_control()
        if not bool(ctrl.get('notify_paper_hourly_summary_enabled', True)):
            return
        interval = max(3600.0, fnum(ctrl.get('notify_paper_hourly_summary_interval_sec'), default=3600.0))
        b = _v631_bucket_collect(status if isinstance(status, dict) else {})
        now = now_ts()
        elapsed = now - fnum(b.get('start_ts'), default=now)
        if elapsed < interval:
            _v632_save_hourly_trace(_v632_hourly_trace_result('waiting_interval', b, {'next_in_sec': round(interval - elapsed, 1), 'targets': _v632_send_document_dual.__name__}))
            return
        closed_rows = _v631_recent_closed_rows(hours=max(1.0, elapsed / 3600.0))
        meaningful = int(b.get('s1_seen') or 0) + int(b.get('paper_entry_hold') or 0) + int(b.get('opened') or 0) + int(b.get('closed') or 0) + len(closed_rows)
        if meaningful <= 0 and not bool(ctrl.get('notify_paper_hourly_summary_send_idle', False)):
            trace = _v632_hourly_trace_result('skipped_no_activity', b, {
                'skip_reason': '1시간 내 S1/OPEN/CLOSED/보류 없음',
                'paper_sent_ok': False,
                'main_sent_ok': False,
                'temp_deleted': True,
            })
            _v632_save_hourly_trace(trace)
            _v631_bucket_reset(now)
            return
        text = _v631_build_hourly_summary_text(status if isinstance(status, dict) else {}, b, closed_rows)
        filename = f"paper_hourly_summary_{time.strftime('%Y%m%d_%H%M%S')}.txt"
        tmp = FILES['hourly_summary_tmp']
        tmp.write_text(text, encoding='utf-8')
        send = _v632_send_document_dual(tmp, filename, f'🧾 paper 1시간 요약 · {iso_ts()}')
        deleted = False
        if bool(send.get('all_configured_sent_ok')):
            try:
                tmp.unlink(missing_ok=True)
                deleted = True
            except Exception as exc:
                log_error('v632_hourly_tmp_delete', exc)
        trace = _v632_hourly_trace_result('sent_ok' if bool(send.get('all_configured_sent_ok')) else 'send_partial_or_error', b, {
            'sent_ok': bool(send.get('all_configured_sent_ok')),
            'paper_sent_ok': bool(send.get('paper_sent_ok')),
            'main_sent_ok': bool(send.get('main_sent_ok')),
            'send_targets': send.get('targets'),
            'filename': filename,
            'temp_deleted': bool(deleted),
            'temp_path': str(tmp if not deleted else ''),
            'closed_recent': len(closed_rows),
            'text_chars': len(text),
        })
        _v632_save_hourly_trace(trace)
        _v631_bucket_reset(now)
    except Exception as exc:
        log_error('v632_maybe_send_paper_hourly_summary', exc)
        try:
            _v632_save_hourly_trace({'schema': _V632_HOURLY_SCHEMA, 'version': VERSION, 'build': BUILD_LABEL, 'updated_at': now_ts(), 'updated_at_text': iso_ts(), 'result': 'internal_error', 'error': f'{type(exc).__name__}: {exc}'})
        except Exception:
            pass

def _v628_send_document(path: Path, caption: str = '') -> Tuple[bool, str]:  # type: ignore[override]
    try:
        filename = path.name
        send = _v632_send_document_dual(path, filename, caption or f'paper hourly raw pack / {BUILD_LABEL}')
        trace = {
            'schema': 'paper_hourly_raw_pack_v632_dual_room_send',
            'version': VERSION,
            'build': BUILD_LABEL,
            'updated_at': now_ts(),
            'updated_at_text': iso_ts(),
            'filename': filename,
            'paper_sent_ok': bool(send.get('paper_sent_ok')),
            'main_sent_ok': bool(send.get('main_sent_ok')),
            'sent_ok': bool(send.get('all_configured_sent_ok')),
            'send_targets': send.get('targets'),
        }
        try:
            save_json(FILES['hourly_raw_pack_trace'], trace)
        except Exception as exc:
            log_error('v632_raw_pack_trace', exc)
        return bool(send.get('all_configured_sent_ok')), '' if bool(send.get('all_configured_sent_ok')) else json.dumps(send.get('targets'), ensure_ascii=False)[:500]
    except Exception as exc:
        log_error('v632_v628_send_document_override', exc)
        return False, f'{type(exc).__name__}: {exc}'

BUILD_LABEL = 'structure_board_mainline_2026-06-10'

_V635_OPEN_PATCH_FIELDS = (
    'entry_build_key','open_build_key','entry_patch_version','score_patch_version','opened_patch_version'
)

def _v635_patch_from_any(v: Any) -> str:
    try:
        if str(v or '').strip() == 'legacy_unknown':
            return 'legacy_unknown'
        return _patch_version_from_text(v)
    except Exception:
        return ''

def _v607_alert_to_closed_row__L13030(row: Dict[str, Any]) -> Dict[str, Any]:  # type: ignore[override]
    if callable(_v635_prev_alert_to_closed_row):
        out = _v635_prev_alert_to_closed_row(row)
    else:
        out = dict(row or {})
    explicit = False
    if isinstance(row, dict):
        for k in _V635_OPEN_PATCH_FIELDS:
            if _v635_patch_from_any(row.get(k)):
                explicit = True; break
    if not explicit:
        for k in ('entry_build_key','open_build_key','entry_patch_version','score_patch_version','opened_patch_version','patch_version','run_patch_version','deploy_patch_version'):
            out.pop(k, None)
        out['entry_build_key'] = 'legacy_unknown'
        out['score_patch_version'] = 'legacy_unknown'
        out['version_key_note'] = 'v635: close_alert_trace had no OPEN-time patch key; current patch was not injected'
    out['closed_patch_version'] = row.get('closed_patch_version') or row.get('close_patch_version') or active_patch_version()
    out['close_patch_version'] = out['closed_patch_version']
    return out

BUILD_LABEL = 'structure_board_mainline_2026-06-10'

_V638_HOURLY_SCHEMA = 'paper_hourly_summary_v638_dual_room_trace_refine'

def _v638_env_or_file_chat_id() -> str:
    names = (
        'PAPER_BOT_MAIN_NOTIFY_CHAT_ID', 'PAPER_BOT_MAIN_CHAT_ID',
        'MAIN_BOT_CHAT_ID', 'MAIN_CHAT_ID', 'COINBOT_MAIN_CHAT_ID',
    )
    for name in names:
        try:
            val = os.getenv(name, '').strip()
            if val:
                return val
        except Exception:
            pass
    for fn in ('MAIN_BOT_CHAT_ID.txt', 'main_chat_id.txt', 'coinbot_main_chat_id.txt'):
        try:
            p = BASE_DIR / fn
            if p.exists():
                val = p.read_text(encoding='utf-8', errors='ignore').strip().splitlines()[0].strip()
                if val:
                    return val
        except Exception:
            pass
    for fn in ('clean_brain_status.json', 'main_bot_status.json', 'coinbot_main_status.json'):
        try:
            p = BASE_DIR / fn
            obj = load_json(p, {}) if p.exists() else {}
            if isinstance(obj, dict):
                for k in ('main_chat_id','notify_chat_id','chat_id','allowed_chat_id','telegram_chat_id'):
                    val = str(obj.get(k) or '').strip()
                    if val:
                        return val
        except Exception:
            pass
    return ''

def _v638_send_document_dual(path: Path, filename: str, caption: str) -> Dict[str, Any]:
    results: Dict[str, Any] = {}
    paper_chat = str(NOTIFY_CHAT_ID or ALLOWED_CHAT_ID or '').strip()
    main_chat = _v638_env_or_file_chat_id()
    # paper target: required
    if not paper_chat:
        results['paper'] = {'sent_ok': False, 'skipped': True, 'reason': 'paper_chat_id_missing', 'chat_id_present': False}
    else:
        ok, err = _v632_send_document_to_chat(path, filename, caption, paper_chat)
        results['paper'] = {'sent_ok': bool(ok), 'error': err, 'chat_id_present': True}
    # main target: optional but visible
    if not main_chat:
        results['main'] = {'sent_ok': None, 'skipped': True, 'reason': 'missing_chat_id', 'chat_id_present': False, 'required': False}
    elif main_chat == paper_chat:
        results['main'] = {'sent_ok': True, 'skipped': True, 'reason': 'same_as_paper_chat_id', 'chat_id_present': True, 'required': False}
    else:
        ok, err = _v632_send_document_to_chat(path, filename, caption, main_chat)
        results['main'] = {'sent_ok': bool(ok), 'error': err, 'chat_id_present': True, 'required': False}
    paper_ok = bool(results.get('paper', {}).get('sent_ok'))
    main_val = results.get('main', {}).get('sent_ok')
    all_configured_ok = paper_ok and (main_val is not False)
    return {
        'paper_sent_ok': paper_ok,
        'main_sent_ok': main_val,
        'all_configured_sent_ok': all_configured_ok,
        'targets': results,
        'schema': _V638_HOURLY_SCHEMA,
    }

BUILD_LABEL = 'structure_board_mainline_2026-06-10'

BUILD_LABEL = 'structure_board_mainline_2026-06-10'

VERSION = 'paper_bot_v0.795'

V983_ALLOWED_EXIT_REASONS = {
    'structure_target', 'structure_invalid', 'swing_trailing', 'swing_no_progress', 'swing_max_weak_hold'
}

def _v983_first_dict(*values: Any) -> Dict[str, Any]:
    for value in values:
        if isinstance(value, dict) and value:
            return value
    return {}

def _v983_line_obj(row: Dict[str, Any], side: str) -> Dict[str, Any]:
    row = row if isinstance(row, dict) else {}
    gate = _v983_first_dict(row.get('swing_entry_gate_v977'), (row.get('entry_diagnostics') or {}).get('swing_entry_gate_v977') if isinstance(row.get('entry_diagnostics'), dict) else None)
    plan = _v983_first_dict(row.get('swing_structure_plan_v977'), gate.get('structure_plan'), row.get('entry_plan'))
    obj = _v983_first_dict(plan.get(side), gate.get(side))
    return dict(obj)

def _v983_line_tf(row: Dict[str, Any], side: str) -> str:
    obj = _v983_line_obj(row, side)
    for key in ('timeframe','tf','source_tf','candle_tf','role_tf'):
        value = str(obj.get(key) or '').strip()
        if value:
            return value
    role = str(obj.get('role') or '').strip()
    defaults = {'trigger':'15m/5m', 'invalid':'1h/30m', 'target':'4h/2h'}
    return f"{role}·{defaults.get(side,'-')}" if role else defaults.get(side, '-')

def _v983_line_source(row: Dict[str, Any], side: str) -> str:
    obj = _v983_line_obj(row, side)
    for key in ('source','source_name','line_source','method','reason'):
        value = str(obj.get(key) or '').strip()
        if value:
            return value
    return 'strategy 구조선'

def _v983_setup_type(row: Dict[str, Any]) -> str:
    row = row if isinstance(row, dict) else {}
    for source in (row, row.get('entry_diagnostics'), row.get('entry_context'), row.get('raw')):
        if not isinstance(source, dict):
            continue
        for key in ('setup_type','structure_method','method_key','structure_method_key','strategy_label','final_entry_label','strategy'):
            value = str(source.get(key) or '').strip()
            if value and value not in ('-', 'ALT_SWING_V977'):
                return value
    return '알트 스윙 구조 진입'

def _v983_cost_snapshot(row: Dict[str, Any]) -> Dict[str, Any]:
    row = row if isinstance(row, dict) else {}
    gate = _v983_first_dict(row.get('swing_entry_gate_v977'), (row.get('entry_diagnostics') or {}).get('swing_entry_gate_v977') if isinstance(row.get('entry_diagnostics'), dict) else None)
    obs = row.get('paper_execution_cost_v917') if isinstance(row.get('paper_execution_cost_v917'), dict) else {}
    return {
        'spread_pct': fnum(gate.get('spread_pct'), row.get('spread_pct'), default=0.0),
        'paper_reference_signed_pct': obs.get('signed_slippage_pct'),
        'paper_reference_cost_pct': obs.get('cost_slippage_pct'),
        'paper_reference_state': obs.get('measurement_state') or obs.get('state') or 'not_recorded',
        'exchange_confirmed': bool(obs.get('exchange_confirmed')),
        'configured_roundtrip_fee_pct': fnum(DEFAULT_CONTROL.get('fee_pct_roundtrip'), default=0.10),
        'policy': 'spread, paper-reference gap and configured fee are separate; paper-reference is not exchange average fill',
    }

def _v1038_new_open_exit_contract() -> Dict[str, Any]:
    """Build the exact exit contract for a NEW v1038 OPEN from canonical control.

    Existing OPEN rows are never upgraded. Failure to read a valid contract blocks
    the new OPEN rather than silently using an unsealed fallback.
    """
    ctrl = load_control()
    trigger = fnum(ctrl.get('swing_trailing_trigger_pct'), default=0.0)
    giveback = fnum(ctrl.get('swing_trailing_giveback_pct'), default=0.0)
    if trigger <= 0 or giveback <= 0:
        raise RuntimeError('v1038 trailing contract missing/invalid in canonical control')
    return {
        'schema':'alt_swing_exit_contract_v1038',
        'version':'v1038',
        'strategy_mode':'ALT_SWING_V977',
        'allowed_reasons':sorted(V983_ALLOWED_EXIT_REASONS),
        'minimum_hold_minutes':0,
        'fixed_15m_exit':False,
        'trailing_exit':True,
        'trailing_trigger_pct':round(trigger,4),
        'trailing_giveback_pct':round(giveback,4),
        'trailing_requires_positive_net':True,
        'applies_to':'new_open_from_v1038_only',
        'source':'v977 active contract restored into current canonical exit spine',
        'sealed_at':now_ts(),
        'sealed_by':'paper_single_alt_swing_open_writer_v1038',
    }

def _v1038_sealed_exit_contract(pos: Dict[str, Any]) -> Dict[str, Any]:
    """Read only the contract sealed at OPEN; never upgrade old OPENs."""
    pos = pos if isinstance(pos, dict) else {}
    ev = pos.get('entry_evidence_v983') if isinstance(pos.get('entry_evidence_v983'), dict) else {}
    contract = ev.get('exit_contract') if isinstance(ev.get('exit_contract'), dict) else {}
    if not contract and isinstance(pos.get('exit_contract_v1038'), dict):
        contract = pos.get('exit_contract_v1038')
    if isinstance(contract, dict) and contract:
        return dict(contract)
    return {
        'schema':'pre_v1038_or_unsealed_exit_contract',
        'trailing_exit':False,
        'applies_to':'existing_open_contract_preserved',
        'policy':'missing old contract is never upgraded from current values',
    }

def _v983_build_entry_evidence(row: Dict[str, Any], opened_at: Any = None) -> Dict[str, Any]:
    row = row if isinstance(row, dict) else {}
    gate = _v983_first_dict(row.get('swing_entry_gate_v977'), (row.get('entry_diagnostics') or {}).get('swing_entry_gate_v977') if isinstance(row.get('entry_diagnostics'), dict) else None)
    timing = _v983_first_dict(row.get('paper_timing_spine_v940'), row.get('entry_timing_trace'), (row.get('entry_diagnostics') or {}).get('entry_timing_trace') if isinstance(row.get('entry_diagnostics'), dict) else None)
    trigger = fnum(row.get('swing_trigger_price_v977'), row.get('trigger_price'), default=0.0)
    invalid = fnum(row.get('swing_invalid_price_v977'), gate.get('invalid_price'), default=0.0)
    target = fnum(row.get('swing_target_price_v977'), gate.get('target_price'), default=0.0)
    entry = fnum(row.get('entry_price'), default=0.0)
    market_context: Dict[str, Any] = {}
    source_used=[]
    for source_name in ('market_context','entry_context','quality_evidence','quality_observation_v925','source_snapshot'):
        source=row.get(source_name)
        if not isinstance(source,dict):
            continue
        candidate=source.get('market_context') if isinstance(source.get('market_context'),dict) else source
        copied=False
        for target_name,keys in {
            'market_regime':('market_regime','regime','market_state','state'),
            'relative_strength':('relative_strength','relative_strength_score'),
            'turnover_bucket':('turnover_bucket',),
            'turnover_change_pct':('turnover_change_pct',),
            'money_flow_state':('money_flow_state','flow_state'),
        }.items():
            if market_context.get(target_name) not in (None,''):
                continue
            for key in keys:
                if candidate.get(key) not in (None,''):
                    market_context[target_name]=candidate.get(key); copied=True; break
        if copied: source_used.append(source_name)
    for key in ('market_regime','relative_strength','turnover_bucket','turnover_change_pct','money_flow_state'):
        if row.get(key) not in (None,''):
            market_context[key]=row.get(key)
            if 'top_level' not in source_used: source_used.append('top_level')
    return {
        'schema':'paper_entry_evidence_v1012_exact',
        'strategy_mode':'ALT_SWING_V977',
        'setup_type':_v983_setup_type(row),
        'pos_id':row.get('pos_id') or row.get('paper_pos_id_v926'),
        'decision_key':row.get('paper_decision_key_v926') or row.get('swing_gate_decision_key_v977') or gate.get('decision_key'),
        'candidate_key':row.get('candidate_entry_build_key') or row.get('entry_build_key'),
        'opened_at':fnum(opened_at, row.get('opened_at'), default=0.0) or None,
        'entry_price':entry or None,
        'trigger':{'price':trigger or None,'timeframe':_v983_line_tf(row,'trigger'),'source':_v983_line_source(row,'trigger')},
        'invalid':{'price':invalid or None,'timeframe':_v983_line_tf(row,'invalid'),'source':_v983_line_source(row,'invalid')},
        'target':{'price':target or None,'timeframe':_v983_line_tf(row,'target'),'source':_v983_line_source(row,'target')},
        'risk_reward':fnum(gate.get('risk_reward'), (row.get('risk_reward') or {}).get('ratio') if isinstance(row.get('risk_reward'),dict) else None, default=0.0),
        'target_room_pct':fnum(gate.get('target_room_pct'), (row.get('risk_reward') or {}).get('target_room_pct') if isinstance(row.get('risk_reward'),dict) else None, default=0.0),
        'trigger_chase_pct':fnum(row.get('trigger_gap_pct'), default=0.0),
        'cost':_v983_cost_snapshot(row),
        'timing':{k: timing.get(k) for k in ('scanner_to_candidate_sec','scanner_to_s1_sec','trigger_to_open_delay_sec','selected_to_open_delay_sec','first_to_open_delay_sec','s1_to_open_delay_sec') if timing.get(k) not in (None,'')},
        'market_context':market_context,
        'market_context_source_v1012':source_used or ['not_recorded_at_open'],
        'exit_contract':dict(row.get('exit_contract_v1038')) if isinstance(row.get('exit_contract_v1038'),dict) else {'schema':'pre_v1038_exit_contract','allowed_reasons':['structure_target','structure_invalid','swing_no_progress','swing_max_weak_hold'],'minimum_hold_minutes':0,'fixed_15m_exit':False,'trailing_exit':False,'applies_to':'existing_open_contract_preserved'},
        'sealed_at':now_ts(),'sealed_by':'paper_single_alt_swing_open_writer',
    }

def _v983_exit_contract_status(reason: Any) -> Tuple[bool, str]:
    value = str(reason or '').strip()
    if value in V983_ALLOWED_EXIT_REASONS:
        return True, ''
    return False, f'unapproved_exit_reason:{value or "missing"}'

def _v983_seal_closed_evidence(row: Dict[str, Any], source_pos: Dict[str, Any], ctrl: Dict[str, Any]) -> Dict[str, Any]:
    row = row if isinstance(row, dict) else {}
    source_pos = source_pos if isinstance(source_pos, dict) else {}
    entry_ev = source_pos.get('entry_evidence_v983') if isinstance(source_pos.get('entry_evidence_v983'), dict) else _v983_build_entry_evidence(source_pos or row)
    reason = str(row.get('exit_reason') or row.get('exit_rule') or '').strip()
    compliant, violation = _v983_exit_contract_status(reason)
    gross = fnum(row.get('last_gross_pct_v804'), default=0.0)
    fee = fnum(ctrl.get('fee_pct_roundtrip'), default=0.10)
    peak = fnum(row.get('peak_pct'), default=0.0)
    trough = fnum(row.get('trough_pct'), default=0.0)
    row['gross_pnl_pct_v983'] = round(gross, 4)
    row['configured_roundtrip_fee_pct_v983'] = round(fee, 4)
    row['net_after_configured_fee_pct_v983'] = round(fnum(row.get('pnl_pct'), default=gross-fee), 4)
    row['mfe_pct_v983'] = round(peak, 4)
    row['mae_pct_v983'] = round(trough, 4)
    row['giveback_pct_v983'] = round(max(0.0, peak-fnum(row.get('pnl_pct'), default=0.0)), 4)
    row['entry_evidence_v983'] = entry_ev
    row['exit_contract_compliant_v983'] = compliant
    row['exit_contract_violation_v983'] = violation or None
    row['closed_evidence_v983'] = {
        'schema':'paper_closed_evidence_v983_exact',
        'pos_id':row.get('pos_id'),'decision_key':row.get('paper_decision_key_v926') or row.get('swing_gate_decision_key_v977'),
        'exit_reason':reason,'exit_detail':row.get('exit_rule_reason'),'contract_compliant':compliant,'contract_violation':violation or None,
        'entry_price':row.get('entry_price'),'exit_price':row.get('exit_price'),
        'gross_pnl_pct':row.get('gross_pnl_pct_v983'),'net_after_configured_fee_pct':row.get('net_after_configured_fee_pct_v983'),
        'configured_roundtrip_fee_pct':row.get('configured_roundtrip_fee_pct_v983'),
        'mfe_pct':row.get('mfe_pct_v983'),'mae_pct':row.get('mae_pct_v983'),'giveback_pct':row.get('giveback_pct_v983'),
        'hold_sec':row.get('hold_sec'),'age_min':row.get('age_min'),
        'target_first_touch_ts':row.get('first_target_touch_ts_v983'),'invalid_first_touch_ts':row.get('first_invalid_touch_ts_v983'),
        'entry_evidence':entry_ev,
        'ledger_policy':'raw CLOSED preserved; score/review clean sample requires approved exit contract',
        'sealed_at':now_ts(),'sealed_by':'canonical_open_exit_evaluator_v983',
    }
    return row

def build_profitability_entry_evidence(pos: Dict[str, Any], src: Dict[str, Any], gate: Dict[str, Any], trigger_gate: Dict[str, Any], opened_ts: float) -> Dict[str, Any]:
    pre=src.get('profitability_preopen_evidence_v1034') if isinstance(src.get('profitability_preopen_evidence_v1034'),dict) else {}
    entry=_v987_perf_num(pos.get('entry_price'),default=None)
    trigger=_v987_perf_num(pos.get('swing_trigger_price_v977'),trigger_gate.get('trigger_price'),default=None)
    invalid=_v987_perf_num(pos.get('swing_invalid_price_v977'),gate.get('invalid_price'),default=None)
    target=_v987_perf_num(pos.get('swing_target_price_v977'),gate.get('target_price'),default=None)
    trigger_rr=_v987_perf_num(gate.get('risk_reward'),default=None)
    actual_rr=None
    if entry is not None and target is not None and invalid is not None and target>entry>invalid:
        actual_rr=(target-entry)/(entry-invalid)
    plan=pos.get('swing_structure_plan_v977') if isinstance(pos.get('swing_structure_plan_v977'),dict) else (gate.get('structure_plan') if isinstance(gate.get('structure_plan'),dict) else {})
    frozen_ts=_v987_perf_num(plan.get('frozen_ts'),_profitability_first(src,'trigger_frozen_ts','swing_trigger_frozen_ts_v977','frozen_ts'),default=None)
    frozen_age=(opened_ts-frozen_ts) if frozen_ts and opened_ts>=frozen_ts else None
    market=pre.get('market_regime') if isinstance(pre.get('market_regime'),dict) else {}
    risk=pre.get('risk') if isinstance(pre.get('risk'),dict) else {}
    quality=pre.get('quality') if isinstance(pre.get('quality'),dict) else _profitability_quality_fields(src)
    return {
        'schema':'profitability_entry_evidence_v1034','sealed_at':opened_ts,'sealed_by':'paper_single_alt_swing_open_writer',
        'entry_price':entry,'trigger_price':trigger,'invalid_price':invalid,'target_price':target,
        'trigger_rr':round(trigger_rr,6) if trigger_rr is not None else None,'actual_entry_rr':round(actual_rr,6) if actual_rr is not None else None,
        'actual_rr_delta':round(actual_rr-trigger_rr,6) if actual_rr is not None and trigger_rr is not None else None,
        'actual_rr_below_contract':bool(actual_rr is not None and actual_rr<PAPER_MIN_RR),
        'trigger_chase_pct':_v987_perf_num(trigger_gate.get('trigger_gap_pct'),src.get('trigger_gap_pct'),default=None),
        'open_count_before':pre.get('open_count_before') if pre else src.get('paper_open_count_before_v1034'),
        'new_index_in_cycle':pre.get('new_index_in_cycle') if pre else src.get('paper_new_index_in_cycle_v1034'),
        'source_lane':pre.get('source_lane') if pre else src.get('_source_file'),'hot_rank_lane':bool(pre.get('hot_rank_lane')) if pre else False,
        'risk':risk,'market_regime':market,'quality':quality,'late_risk_audit':pre.get('late_risk_audit') if pre else None,
        'trigger_frozen_ts':frozen_ts,'frozen_plan_age_sec':round(frozen_age,3) if frozen_age is not None else None,
        'source_plan_move_detected':bool(plan.get('source_plan_move_detected')),'frozen_plan_held':bool(plan.get('frozen_plan_held')),
        'decision_key':pos.get('paper_decision_key_v926'),'candidate_key':pos.get('candidate_entry_build_key') or pos.get('entry_build_key'),
        'policy':'evidence-only; actual entry RR is measured but does not block this v1034 OPEN; auto-buy remains OFF',
    }

def _v1176_verify_open_seal(pos: Dict[str, Any], decision_key: str) -> bool:
    """Verify immutable OPEN evidence without reviving retired entry blockers.

    The loss-reentry result remains sealed as audit evidence. In raw Paper mode its
    allowed flag is diagnostic only, so OPEN integrity requires the evidence schema,
    not allowed=True.
    """
    reentry = pos.get('loss_reentry_gate_v1037') if isinstance(pos.get('loss_reentry_gate_v1037'), dict) else {}
    evidence = pos.get('entry_evidence_v983') if isinstance(pos.get('entry_evidence_v983'), dict) else {}
    exit_contract = evidence.get('exit_contract') if isinstance(evidence.get('exit_contract'), dict) else {}
    required = {
        'strategy_mode': pos.get('strategy_mode') == 'ALT_SWING_V977',
        'decision_key': str(pos.get('paper_decision_key_v926') or '') == decision_key,
        'swing_gate': isinstance(pos.get('swing_entry_gate_v977'), dict) and pos['swing_entry_gate_v977'].get('schema') == 'swing_entry_gate_v977_single_owner',
        'trigger': fnum(pos.get('swing_trigger_price_v977'), default=0.0) > 0,
        'invalid': fnum(pos.get('swing_invalid_price_v977'), default=0.0) > 0,
        'target': fnum(pos.get('swing_target_price_v977'), default=0.0) > 0,
        'loss_reentry_audit_v1037': reentry.get('schema') == 'loss_reentry_gate_v1037',
        'exit_contract_v1038': exit_contract.get('schema') == 'alt_swing_exit_contract_v1038' and exit_contract.get('trailing_exit') is True,
        'opened_at': fnum(pos.get('opened_at'), default=0.0) > 0,
    }
    failed = [name for name, ok in required.items() if not ok]
    if failed:
        raise RuntimeError('ALT_SWING OPEN seal verification failed: ' + ','.join(failed))
    return True

def open_position__L14174(pos_id: str, ev: Dict[str, Any]) -> Dict[str, Any]:
    """Single ALT_SWING OPEN writer.

    Consumes only the strategy-owned swing gate already rechecked by paper_final_safety.
    It never reruns the retired _v628 trigger gate and never falls back to v925
    trigger/invalid/target fields for a new OPEN.
    """
    if not isinstance(ev, dict):
        raise TypeError('ALT_SWING OPEN candidate must be dict')
    src = dict(ev)
    if _v988_is_s3_observation_only(src):
        raise ValueError('S3 observation-only candidate blocked at OPEN writer')
    gate = read_strategy_entry_gate(src)
    decision_key = read_strategy_decision_key(src, gate)
    mode = str(src.get('strategy_mode') or src.get('strategy_mode_v977') or '').upper()
    if mode != 'ALT_SWING_V977':
        raise ValueError('ALT_SWING strategy_mode missing at OPEN writer')
    if gate.get('schema') != 'swing_entry_gate_v977_single_owner':
        raise ValueError('ALT_SWING swing gate schema mismatch at OPEN writer')
    if gate.get('hard_pass') is not True or str(gate.get('final_trade_state') or '') != 'S1_PASS':
        raise ValueError('ALT_SWING swing gate is not S1_PASS at OPEN writer')
    if not decision_key or str(gate.get('decision_key') or '') != decision_key:
        raise ValueError('ALT_SWING exact swing decision key missing/mismatch at OPEN writer')
    reentry_gate_v1037=src.get('loss_reentry_gate_v1037') if isinstance(src.get('loss_reentry_gate_v1037'),dict) else {
        'schema':'loss_reentry_gate_v1037','allowed':None,'state':'SOURCE_MISSING_AUDIT_ONLY_V1174'
    }

    diag = dict(src.get('paper_final_safety_diagnostics')) if isinstance(src.get('paper_final_safety_diagnostics'), dict) else {}
    diag['paper_raw_intake_v1174']=True
    occurrence_freshness=diag.get('trigger_occurrence_freshness') if isinstance(diag.get('trigger_occurrence_freshness'),dict) else trigger_occurrence_freshness(src,DEFAULT_CONTROL)
    trigger_gate = diag.get('trigger_gate') if isinstance(diag.get('trigger_gate'), dict) else evaluate_frozen_trigger(src, diag)
    trigger_gap = fnum(trigger_gate.get('trigger_gap_pct'), default=0.0)

    ticker = normalize_ticker(src.get('ticker') or src.get('market') or src.get('symbol'))
    if not ticker:
        raise ValueError('ticker missing at ALT_SWING OPEN writer')
    detected = get_event_price(src)
    confirmation = fnum(trigger_gate.get('entry_price'), trigger_gate.get('current_confirmation_price'), default=0.0)
    price = confirmation if confirmation > 0 else (live_price(ticker, detected) or detected)
    trigger_price = fnum(trigger_gate.get('trigger_price'), src.get('swing_trigger_price_v977'), default=0.0)
    invalid_price = fnum(src.get('swing_invalid_price_v977'), gate.get('invalid_price'), default=0.0)
    target_price = fnum(src.get('swing_target_price_v977'), gate.get('target_price'), default=0.0)
    if min(price, trigger_price, invalid_price, target_price) <= 0:
        raise ValueError('ALT_SWING trigger/invalid/target/entry price missing at OPEN writer')
    if not (invalid_price < trigger_price < target_price):
        raise ValueError('ALT_SWING invalid < trigger < target structure contract mismatch at OPEN writer')
    diag['actual_entry_relation_v1174']={
        'entry_price':price,'trigger_price':trigger_price,'target_price':target_price,
        'entry_above_trigger':bool(price>=trigger_price),'entry_below_target':bool(price<target_price),
        'blocking':False,
    }
    # v1174: Strategy-owned RR/room and actual entry relation are sealed for analysis but not re-blocked by Paper.

    ts = now_ts()
    ctx = copy_entry_context(src)
    diag['trigger_gate'] = trigger_gate
    diag['swing_entry_gate_v977'] = gate
    diag['swing_gate_decision_key_v977'] = decision_key
    diag['entry_timing_trace'] = build_entry_timing_trace(src, diag) if 'build_entry_timing_trace' in globals() else {}
    candidate_key = src.get('entry_build_key') or src.get('candidate_entry_build_key') or src.get('event_id') or src.get('event_key')
    exit_contract_v1038 = _v1038_new_open_exit_contract()
    current_main_version = active_main_version()
    current_patch_version = active_patch_version()
    grade = str(src.get('s_stage') or src.get('candidate_stage') or src.get('candidate_grade') or 'S1').upper()
    if grade != 'S1':
        raise ValueError('ALT_SWING candidate stage is not S1 at OPEN writer')

    pos: Dict[str, Any] = {
        'pos_id': pos_id, 'event_id': pos_id, 'paper_pos_id_v926': pos_id,
        'paper_decision_key_v926': decision_key, 'swing_gate_decision_key_v977': decision_key,
        'ticker': ticker, 'lane': 'strict', 'opened_at': ts, 'opened_at_text': iso_ts(ts),
        'opened_paper_version': VERSION, 'paper_build_label': BUILD_LABEL,
        'score_main_version': current_main_version, 'opened_main_version': current_main_version,
        'main_version': current_main_version, 'deploy_version': current_main_version,
        'entry_build_key': candidate_key or current_patch_version,
        'candidate_entry_build_key': candidate_key,
        'open_build_key': current_patch_version, 'entry_patch_version': current_patch_version,
        'score_patch_version': current_patch_version, 'opened_patch_version': current_patch_version,
        'patch_version': current_patch_version, 'run_patch_version': current_patch_version,
        'strategy_worker_version': src.get('strategy_worker_version') or src.get('source_version') or src.get('brain_version') or '',
        'entry_price': price, 'detected_price': detected, 'current_price': price,
        'peak_pct': 0.0, 'trough_pct': 0.0, 'gross_peak_pct': 0.0, 'gross_trough_pct': 0.0,
        'last_gross_pct_v804': 0.0, 'last_pnl_pct': -fnum(DEFAULT_CONTROL.get('fee_pct_roundtrip'), default=0.10),
        'last_update': ts,
        'strategy_mode': 'ALT_SWING_V977', 'strategy_mode_v977': 'ALT_SWING_V977',
        'strategy_timeframe_contract_v977': {'major':'4h/2h','setup':'1h/30m','entry':'15m/5m','execution':'1m/quote'},
        'strategy': src.get('strategy') or src.get('strategy_key') or src.get('route') or 'ALT_SWING_V977',
        'strategy_key': src.get('strategy_key') or src.get('paper_strategy_key') or src.get('route') or src.get('strategy') or 'ALT_SWING_V977',
        'strategy_label': src.get('strategy_label') or src.get('paper_strategy_label') or src.get('final_entry_label') or 'ALT_SWING_V977',
        'candidate_grade': 'S1', 'score': fnum(src.get('score'), src.get('leader_score'), default=0.0),
        'trade_ready': True, 'real_eligible': False, 'auto_buy_ready': False, 'buy_ready': False,
        'paper_final_safety_passed': True, 'paper_final_safety_diagnostics': diag,
        'paper_raw_intake_v1174': True,
        'paper_raw_audit_reasons_v1174': list(src.get('paper_raw_audit_reasons_v1174') or []),
        'paper_final_safety_would_pass_v1174': src.get('paper_final_safety_would_pass_v1174'),
        'entry_slippage_est_pct':src.get('entry_slippage_est_pct'),'entry_slippage_source':src.get('entry_slippage_source'),'entry_slippage_ts':src.get('entry_slippage_ts'),'entry_slippage_age_sec':src.get('entry_slippage_age_sec'),'entry_slippage_confirmed':src.get('entry_slippage_confirmed'),'entry_slippage_basis':src.get('entry_slippage_basis'),'entry_slippage_order_amount_krw':src.get('entry_slippage_order_amount_krw'),'entry_slippage_order_amount_state':src.get('entry_slippage_order_amount_state'),'entry_slippage_owner':src.get('entry_slippage_owner'),'entry_slippage_limit_pct':PAPER_MAX_UNTRADABLE_SPREAD_PCT,
        'entry_context': ctx, 'entry_diagnostics': diag, 'entry_timing_trace': diag.get('entry_timing_trace') or {},
        'swing_entry_gate_v977': dict(gate), 'swing_structure_plan_v977': src.get('swing_structure_plan_v977') or gate.get('structure_plan') or {},
        'swing_trigger_price_v977': trigger_price, 'swing_invalid_price_v977': invalid_price, 'swing_target_price_v977': target_price,
        'trigger_gate': trigger_gate, 'trigger_reached': bool(trigger_gate.get('trigger_reached')), 'trigger_price': trigger_price,
        'trigger_gap_pct': trigger_gap, 'risk_reward': {'ratio': fnum(gate.get('risk_reward'), default=0.0), 'target_room_pct': fnum(gate.get('target_room_pct'), default=0.0)},
        'entry_plan': gate.get('structure_plan') if isinstance(gate.get('structure_plan'), dict) else {},
        'loss_reentry_gate_v1037':dict(reentry_gate_v1037),'reentry_event_identity_v1037':reentry_gate_v1037.get('current'),
        'trigger_occurrence':gate.get('trigger_occurrence'),'trigger_occurrence_contract':gate.get('trigger_occurrence_contract'),'trigger_occurrence_freshness':dict(occurrence_freshness),'trigger_occurrence_candidate_key':src.get('trigger_occurrence_candidate_key'),
        'candidate_path_timestamps_v1153':dict(src.get('candidate_path_timestamps_v1153') or {}) if isinstance(src.get('candidate_path_timestamps_v1153'),dict) else {},
        'minimum_hold_minutes_v977': 0, 'fixed_time_exit_enabled_v977': False,
        'exit_contract_v1038':dict(exit_contract_v1038),
        'open_source': 'paper_single_alt_swing_open_writer_v1038', 'open_writer_schema_v981': 'paper_alt_swing_open_writer_v981_single_owner',
        'raw': src,
    }

    # Observation/enrichment helpers are called directly from this one writer; none may replace the swing contract.
    try: pos.update(_v923_candidate_result_link_fields(src))
    except Exception as exc: log_error('v981_candidate_result_link', exc)
    try: pos = attach_paper_timing_spine_to_open(pos, src)
    except Exception as exc: log_error('v981_open_timing_spine', exc)
    try:
        snap = _v588_build_canonical_entry_snapshot(src, pos)
        pos['canonical_entry_snapshot'] = snap
        pos['canonical_entry_snapshot_schema'] = snap.get('schema') if isinstance(snap, dict) else None
    except Exception as exc: log_error('v981_canonical_entry_snapshot', exc)
    try:
        line_snap = _v752_line_snapshot(src, diag, pos)
        _v752_apply_entry_snapshot_to_row(pos, line_snap)
    except Exception as exc: log_error('v981_line_snapshot', exc)
    try: pos = _v756_prepare_position_snapshot(pos, src)
    except Exception as exc: log_error('v981_prepare_position_snapshot', exc)
    try:
        strategy_snap = _v762_find_strategy_snapshot(src) or _v762_find_strategy_snapshot(pos)
        if strategy_snap: _v762_apply_snapshot(pos, strategy_snap, 'paper_open_single_writer_v981')
    except Exception as exc: log_error('v981_strategy_snapshot', exc)
    try:
        basis = _v764_find_basis(src) or _v764_find_basis(pos)
        snap2 = _v764_find_snapshot(src) or _v764_find_snapshot(pos)
        _v764_apply_basis(pos, basis, snap2, 'paper_open_single_writer_v981')
        _v771_mark_basis(pos, 'paper_open_single_writer_v981')
        _v772_mark_entry_check(pos, 'paper_open_single_writer_v981')
        _v773_mark_structure_route(pos, src, 'paper_open_single_writer_v981')
        _v774_mark_entry_and_route(pos, src, 'open')
    except Exception as exc: log_error('v981_structure_enrichment', exc)
    try: pos['paper_execution_cost_v917'] = _v917_record_execution_cost(pos, src)
    except Exception as exc: log_error('v981_execution_cost_observation', exc)
    pos['entry_evidence_v983'] = _v983_build_entry_evidence(pos, ts)
    pos['open_evidence_schema_v983'] = 'paper_entry_evidence_v983_exact'
    pos['open_source'] = 'paper_single_alt_swing_open_writer_v983'
    pos['profitability_entry_evidence_v1034'] = build_profitability_entry_evidence(pos, src, gate, trigger_gate, ts)
    pos['actual_entry_rr_v1034'] = pos['profitability_entry_evidence_v1034'].get('actual_entry_rr')
    pos['trigger_rr_v1034'] = pos['profitability_entry_evidence_v1034'].get('trigger_rr')
    pos['actual_rr_below_contract_v1034'] = pos['profitability_entry_evidence_v1034'].get('actual_rr_below_contract')
    pos['market_regime_at_open_v1034'] = (pos['profitability_entry_evidence_v1034'].get('market_regime') or {}).get('mode')
    pos['risk_cooldown_at_open_v1034'] = bool((pos['profitability_entry_evidence_v1034'].get('risk') or {}).get('cooldown_active'))
    pos['profitability_shadow_trailing_v1034'] = {'schema':'profitability_shadow_trailing_v1034','trigger_pct':exit_contract_v1038.get('trailing_trigger_pct'),'giveback_pct':exit_contract_v1038.get('trailing_giveback_pct'),'triggered':False,'policy':'v1038 active for this new OPEN; forward exact evidence retained','active_exit_contract':True}

    # Strip retired live-contract aliases before writing OPEN. Historical ledgers remain untouched.
    for key in ('minimal_entry_gate_v925','minimal_gate_decision_key_v925','target_price_v925','invalid_price_v925','trigger_price_rounded_v925','trigger_price_raw_v925'):
        pos.pop(key, None)
    raw = pos.get('raw') if isinstance(pos.get('raw'), dict) else {}
    if raw:
        raw = dict(raw)
        for key in ('minimal_entry_gate_v925','minimal_gate_decision_key_v925','target_price_v925','invalid_price_v925','trigger_price_rounded_v925','trigger_price_raw_v925'):
            raw.pop(key, None)
        pos['raw'] = raw
    pos = _v930_compact_open_row(pos, src)

    _v1176_verify_open_seal(pos, decision_key)
    return pos

VERSION = 'paper_bot_v0.795'

BUILD_LABEL = 'structure_board_mainline_2026-06-10'

VERSION = 'paper_bot_v0.795'

BUILD_LABEL = 'structure_board_mainline_2026-06-10'

VERSION = 'paper_bot_v0.795'

BUILD_LABEL = 'structure_board_mainline_2026-06-10'

def _swing_plan_price(pos: Dict[str, Any], side: str) -> float:
    pos = pos if isinstance(pos, dict) else {}
    mode = str(pos.get('strategy_mode') or pos.get('strategy_mode_v977') or '').upper()
    if mode == 'ALT_SWING_V977':
        keys = (('swing_target_price_v977','target_price') if side == 'target' else ('swing_invalid_price_v977','invalid_price'))
        nested_keys = ('swing_entry_gate_v977','canonical_entry_decision','metrics','structure_plan','swing_structure_plan_v977','raw')
    else:
        # Historical ledger inspection only. This branch cannot create a new OPEN.
        keys = (('swing_target_price_v977','target_price_v925','target_price','target1_price') if side == 'target' else ('swing_invalid_price_v977','invalid_price_v925','invalid_price','stop_price'))
        nested_keys = ('swing_entry_gate_v977','minimal_entry_gate_v925','canonical_entry_decision','metrics','structure_plan','structure_plan_provenance_v925','raw')
    queue: List[Dict[str, Any]] = [pos]
    seen = set()
    while queue and len(seen) < 32:
        obj = queue.pop(0)
        if not isinstance(obj, dict) or id(obj) in seen:
            continue
        seen.add(id(obj))
        for key in keys:
            value = fnum(obj.get(key), default=0.0)
            if value > 0:
                return value
        nested = obj.get(side)
        if isinstance(nested, dict):
            value = fnum(nested.get('rounded_price'), nested.get('raw_price'), nested.get('price'), default=0.0)
            if value > 0:
                return value
        for key in nested_keys:
            value = obj.get(key)
            if isinstance(value, dict):
                queue.append(value)
    return 0.0

def _exit_decision_spine(pos: Dict[str, Any], age_min: float, peak: float, net: float, ctrl: Dict[str, Any]) -> Dict[str, Any]:
    """ALT_SWING_V977 canonical exit owner.

    There is no minimum hold and no fixed 15-minute exit. A structural target or
    invalidation closes immediately, even five minutes after entry. Time is used
    only to retire weak/no-progress positions.
    """
    current = fnum(pos.get('current_price'), default=0.0)
    target = _swing_plan_price(pos, 'target')
    invalid = _swing_plan_price(pos, 'invalid')
    giveback = max(0.0, peak - net)
    d: Dict[str, Any] = {
        'schema':'alt_swing_exit_spine_v977','strategy_mode':'ALT_SWING_V977',
        'action':'hold','reason':'','detail':'구조 유지 보유',
        'age_min':round(age_min,4),'net_pct':round(net,4),'peak_pct':round(peak,4),'giveback_pct':round(giveback,4),
        'current_price':current or None,'target_price':target or None,'invalid_price':invalid or None,
        'minimum_hold_minutes':0,'fixed_time_exit_enabled':False,
    }
    if target > 0 and current >= target:
        d.update(action='close', reason='structure_target', detail=f'구조 목표가 도달: 현재 {current:.8g} / 목표 {target:.8g} / 보유 {age_min:.1f}분')
        return d
    if invalid > 0 and current <= invalid:
        d.update(action='close', reason='structure_invalid', detail=f'구조 무효선 이탈: 현재 {current:.8g} / 무효 {invalid:.8g} / 보유 {age_min:.1f}분')
        return d
    if invalid <= 0 and net <= fnum(ctrl.get('swing_emergency_stop_pct'), default=-2.50):
        d.update(action='close', reason='swing_emergency_stop', detail=f'구조 무효선 누락 비상손절: 현재 {net:+.2f}%')
        return d
    d['allowed_exit_reasons_v983'] = sorted(V983_ALLOWED_EXIT_REASONS)
    sealed_contract = _v1038_sealed_exit_contract(pos)
    trailing_enabled = sealed_contract.get('schema') == 'alt_swing_exit_contract_v1038' and sealed_contract.get('trailing_exit') is True
    d['exit_contract_schema_v1038'] = sealed_contract.get('schema')
    d['trailing_exit_enabled_v1038'] = bool(trailing_enabled)
    d['trailing_contract_applies_to_v1038'] = sealed_contract.get('applies_to')
    if trailing_enabled:
        trail_trigger = fnum(sealed_contract.get('trailing_trigger_pct'), default=0.0)
        trail_giveback = fnum(sealed_contract.get('trailing_giveback_pct'), default=0.0)
        d['trailing_trigger_pct_v1038'] = round(trail_trigger,4) if trail_trigger > 0 else None
        d['trailing_giveback_pct_v1038'] = round(trail_giveback,4) if trail_giveback > 0 else None
        if trail_trigger <= 0 or trail_giveback <= 0:
            d['exit_contract_error_v1038'] = 'invalid_sealed_trailing_threshold'
        elif peak >= trail_trigger and giveback >= trail_giveback and net > 0:
            d.update(action='close', reason='swing_trailing', detail=f'v1038 수익보호: 최고 {peak:+.2f}% / 현재 {net:+.2f}% / 반납 {giveback:+.2f}%')
            return d
    no_progress_min = fnum(ctrl.get('swing_no_progress_minutes'), default=360.0)
    if age_min >= no_progress_min and peak < fnum(ctrl.get('swing_no_progress_peak_under_pct'), default=0.35) and net <= fnum(ctrl.get('swing_no_progress_net_under_pct'), default=0.0):
        d.update(action='close', reason='swing_no_progress', detail=f'6시간 무반응 정리: 보유 {age_min:.1f}분 / 최고 {peak:+.2f}% / 현재 {net:+.2f}%')
        return d
    max_weak_min = fnum(ctrl.get('swing_max_weak_hold_minutes'), default=4320.0)
    if age_min >= max_weak_min and peak < fnum(ctrl.get('swing_max_weak_peak_under_pct'), default=1.0) and net <= fnum(ctrl.get('swing_max_weak_net_under_pct'), default=0.25):
        d.update(action='close', reason='swing_max_weak_hold', detail=f'72시간 약한 흐름 정리: 보유 {age_min/60.0:.1f}시간 / 최고 {peak:+.2f}% / 현재 {net:+.2f}%')
        return d
    return d

VERSION = 'paper_bot_v0.795'

BUILD_LABEL = 'structure_board_mainline_2026-06-10'

VERSION = 'paper_bot_v0.795'

BUILD_LABEL = 'structure_board_mainline_2026-06-10'

VERSION = 'paper_bot_v0.795'

BUILD_LABEL = 'structure_board_mainline_2026-06-10'

VERSION = 'paper_bot_v0.795'

BUILD_LABEL = 'structure_board_mainline_2026-06-10'

def _v677_is_exp_row(ev: Dict[str, Any]) -> bool:
    return isinstance(ev, dict) and ev.get('paper_experiment_open') is True and str(ev.get('paper_experiment_lane') or '') == FAST_EXPERIMENT_LANE_V669

def _v677_event_key(ev: Dict[str, Any]) -> str:
    try:
        return str(ev.get('event_id') or ev.get('event_key') or ev.get('handoff_id') or ev.get('candidate_uid') or event_id(ev, 'strict'))
    except Exception:
        return str(id(ev))

def latest_scan_filter__L14633(rows: List[Dict[str, Any]], ctrl: Dict[str, Any]) -> List[Dict[str, Any]]:  # type: ignore[override]
    base = _v677_prev_latest_scan_filter(rows, ctrl)
    try:
        if not rows:
            return base
        nowv = time.time()
        latest_ts = max((event_created_ts(r) for r in rows if isinstance(r, dict)), default=0.0)
        # Paper experiment rows are strategy-owned handoff rows.  They must not be
        # dropped just because their scan_id differs from the latest normal scan.
        win = max(45.0, fnum(ctrl.get('latest_scan_window_sec'), default=8.0) * 8.0)
        exp_rows: List[Dict[str, Any]] = []
        for r in rows:
            if not _v677_is_exp_row(r):
                continue
            ts = event_created_ts(r)
            if ts <= 0:
                ts = fnum(r.get('paper_handoff_ts'), r.get('updated_ts'), default=0.0)
            # Keep fresh fast/near rows either by absolute age or by latest scan proximity.
            fresh_by_now = ts > 0 and (nowv - ts) <= win
            fresh_by_scan = latest_ts > 0 and ts >= latest_ts - win
            if fresh_by_now or fresh_by_scan:
                exp_rows.append(r)
        if not exp_rows:
            return base
        merged: Dict[str, Dict[str, Any]] = {}
        for r in list(base or []) + exp_rows:
            if isinstance(r, dict):
                merged[_v677_event_key(r)] = r
        return list(merged.values())
    except Exception as exc:
        try: log_error('v677_latest_scan_filter', exc)
        except Exception: pass
        return base

VERSION = 'paper_bot_v0.795'

BUILD_LABEL = 'structure_board_mainline_2026-06-10'

FILES.setdefault('cleanup_state', BASE_DIR / 'paper_bot_cleanup_state.json')

FILES.setdefault('stop_overrun_trace', BASE_DIR / 'paper_bot_stop_overrun_trace.jsonl')

def _v678_hot_tail_limit(name: str, default: int) -> int:
    try:
        return max(50, int(float(os.getenv(name, str(default)))))
    except Exception:
        return default

def _v678_closed_ts(row: Dict[str, Any]) -> float:
    if not isinstance(row, dict):
        return 0.0
    return fnum(row.get('closed_at'), row.get('closed_ts'), row.get('ts'), row.get('updated_at'), default=0.0)

def _v678_hot_closed_filter(rows: List[Dict[str, Any]], nowv: Optional[float] = None) -> List[Dict[str, Any]]:
    nowv = now_ts() if nowv is None else nowv
    hours = max(3.0, fnum(os.getenv('PAPER_SCORE_HOT_HOURS'), default=24.0))
    max_rows = _v678_hot_tail_limit('PAPER_SCORE_HOT_ROWS', 420)
    cutoff = nowv - hours * 3600.0
    clean = [r for r in rows if isinstance(r, dict)]
    clean.sort(key=lambda x: _v678_closed_ts(x))
    recent = [r for r in clean if _v678_closed_ts(r) >= cutoff]
    tail = clean[-max_rows:]
    merged: Dict[str, Dict[str, Any]] = {}
    for r in tail + recent:
        try:
            k = _v607_row_key(r) if '_v607_row_key' in globals() else ''
        except Exception:
            k = ''
        if not k:
            k = f"{r.get('ticker') or r.get('symbol')}-{_v678_closed_ts(r)}-{r.get('pnl_pct') or r.get('profit_pct')}"
        merged[str(k)] = r
    out = list(merged.values())
    out.sort(key=lambda x: _v678_closed_ts(x))
    return out

def _v678_jsonl_prune(path: Path, max_age_sec: float, max_lines: int, ts_keys: Tuple[str, ...] = ('ts','updated_at','closed_at','created_at')) -> Dict[str, Any]:
    res = {'path': str(path), 'exists': False, 'before': 0, 'after': 0, 'removed': 0, 'ok': True, 'error': ''}
    try:
        if not path or not path.exists():
            return res
        res['exists'] = True
        raw_lines = path.read_text(encoding='utf-8', errors='ignore').splitlines()
        res['before'] = len(raw_lines)
        nowv = now_ts(); cutoff = nowv - max_age_sec
        kept: List[str] = []
        for ln in raw_lines:
            if not ln.strip():
                continue
            keep_by_ts = True
            try:
                obj = json.loads(ln)
                if isinstance(obj, dict):
                    ts = 0.0
                    for k in ts_keys:
                        ts = fnum(obj.get(k), default=0.0)
                        if ts > 0: break
                    if ts > 0:
                        keep_by_ts = ts >= cutoff
            except Exception:
                keep_by_ts = True
            if keep_by_ts:
                kept.append(ln)
        if max_lines > 0 and len(kept) > max_lines:
            kept = kept[-max_lines:]
        tmp = path.with_suffix(path.suffix + '.v678tmp')
        tmp.write_text(('\n'.join(kept) + ('\n' if kept else '')), encoding='utf-8')
        os.replace(tmp, path)
        res['after'] = len(kept)
        res['removed'] = max(0, int(res['before']) - len(kept))
        return res
    except Exception as exc:
        res['ok'] = False; res['error'] = f'{type(exc).__name__}: {exc}'
        try: log_error('v678_jsonl_prune', exc)
        except Exception: pass
        return res

def _v678_remove_stale_tmp_files(pattern: str, max_age_sec: float) -> Dict[str, Any]:
    out = {'pattern': pattern, 'checked': 0, 'removed': 0, 'errors': 0}
    try:
        nowv = now_ts()
        for path in BASE_DIR.glob(pattern):
            if not path.is_file():
                continue
            out['checked'] += 1
            try:
                if nowv - path.stat().st_mtime >= max_age_sec:
                    path.unlink(missing_ok=True)
                    out['removed'] += 1
            except Exception as exc:
                out['errors'] += 1
                log_error('v678_remove_stale_tmp_files', exc)
    except Exception as exc:
        out['errors'] += 1
        try: log_error('v678_remove_stale_glob', exc)
        except Exception: pass
    return out

def _v678_runtime_cleanup__L14872(ctrl: Dict[str, Any], status: Dict[str, Any]) -> Dict[str, Any]:
    nowv = now_ts()
    max_age_trace = max(3600.0, fnum(ctrl.get('paper_trace_retention_sec'), default=6*3600.0))
    max_age_alert = max(3600.0, fnum(ctrl.get('paper_alert_trace_retention_sec'), default=24*3600.0))
    cleanup = {
        'schema': 'paper_runtime_cleanup_v678',
        'version': VERSION,
        'build': BUILD_LABEL,
        'updated_at': nowv,
        'updated_at_text': iso_ts() if 'iso_ts' in globals() else now_text(),
        'policy': 'OPEN/CLOSED ledger preserved; runtime traces/raw temp files are pruned; score/review uses hot rows only.',
        'closed_ledger_preserved': True,
        'score_hot_rows_policy': {'hours': fnum(os.getenv('PAPER_SCORE_HOT_HOURS'), default=24.0), 'tail': _v678_hot_tail_limit('PAPER_SCORE_HOT_ROWS', 420)},
        'jsonl_prune': {},
        'tmp_file_prune': {},
    }
    try:
        targets = {
            'open_alert_trace': (FILES.get('open_alert_trace', BASE_DIR / 'paper_bot_open_alert_trace.jsonl'), max_age_alert, 700),
            'close_alert_trace': (FILES.get('close_alert_trace', BASE_DIR / 'paper_bot_close_alert_trace.jsonl'), max_age_alert, 700),
            'hourly_event_trace': (FILES.get('hourly_event_trace', BASE_DIR / 'paper_bot_hourly_raw_event_trace.jsonl'), max_age_trace, 1200),
            'stop_overrun_trace': (FILES.get('stop_overrun_trace', BASE_DIR / 'paper_bot_stop_overrun_trace.jsonl'), max_age_alert, 500),
        }
        for name, (path, age, lines) in targets.items():
            cleanup['jsonl_prune'][name] = _v678_jsonl_prune(path, age, lines)
        cleanup['tmp_file_prune']['raw_pack_txt'] = _v678_remove_stale_tmp_files('paper_hourly_raw_pack_*.txt', 10 * 60.0)
        cleanup['tmp_file_prune']['summary_tmp_txt'] = _v678_remove_stale_tmp_files('paper_hourly_summary_tmp*.txt', 10 * 60.0)
        cleanup['open_count'] = int(status.get('open_count') or status.get('open_total') or 0) if isinstance(status, dict) else 0
        cleanup['closed_total'] = int(status.get('closed_total') or 0) if isinstance(status, dict) else 0
        cleanup['ok'] = True
        save_json(FILES['cleanup_state'], cleanup)
    except Exception as exc:
        cleanup['ok'] = False
        cleanup['error'] = f'{type(exc).__name__}: {exc}'
        log_error('v678_runtime_cleanup', exc)
    return cleanup

def _v678_send_due_hourly_raw_pack() -> None:
    """v678 raw pack owner: 전송 후 삭제 결과를 trace에 확정 봉인한다."""
    try:
        rows = _v628_event_rows() if '_v628_event_rows' in globals() else []
        if not rows:
            return
        cur = _v628_hour_key(now_ts()) if '_v628_hour_key' in globals() else time.strftime('%Y%m%d_%H')
        state = load_json(FILES.get('hourly_sent_state', BASE_DIR / 'paper_bot_hourly_raw_pack_sent.json'), {}) or {}
        sent = set(state.get('sent_hours') or []) if isinstance(state, dict) else set()
        hours = sorted({str(r.get('kst_hour')) for r in rows if isinstance(r, dict) and r.get('kst_hour') and str(r.get('kst_hour')) < cur})
        last_trace: Dict[str, Any] = {}
        for hour in hours:
            if hour in sent:
                continue
            evs = [r for r in rows if isinstance(r, dict) and str(r.get('kst_hour')) == hour]
            if not evs:
                continue
            text = []
            text.append(f'paper 1시간 원문 묶음집 · {hour} KST')
            text.append(f'- paper: {VERSION} / {BUILD_LABEL}')
            text.append(f'- main: {active_main_version()} / patch {active_patch_version()}')
            text.append(f'- events: {len(evs)} / OPEN {sum(1 for e in evs if e.get("kind")=="open")} / CLOSED {sum(1 for e in evs if e.get("kind")=="closed")} / 보류 {sum(1 for e in evs if e.get("kind")=="open_block")}')
            text.append('')
            for i, e in enumerate(evs, 1):
                text.append(f'[{i}] {e.get("kind")} / {e.get("ticker")} / {e.get("phase")} / {e.get("ts_text")}')
                if e.get('note'):
                    text.append('- note: ' + str(e.get('note')))
                msg = str(e.get('message_text') or '').strip()
                text.append(msg if msg else json.dumps(e.get('raw') or e, ensure_ascii=False, indent=2)[:6000])
                text.append('\n---\n')
            path = BASE_DIR / f'paper_hourly_raw_pack_{hour}.txt'
            path.write_text('\n'.join(text), encoding='utf-8')
            ok, err = _v628_send_document(path, f'paper hourly raw pack {hour} / {BUILD_LABEL}') if '_v628_send_document' in globals() else (False, 'send_document_missing')
            deleted = False; delete_error = ''
            try:
                path.unlink(missing_ok=True)
                deleted = not path.exists()
            except Exception as exc:
                delete_error = f'{type(exc).__name__}: {exc}'
                log_error('v678_hourly_pack_delete', exc)
            if ok:
                sent.add(hour)
            else:
                log_error('v678_hourly_pack_send', Exception(str(err)))
            last_trace = {
                'schema': 'paper_hourly_raw_pack_v678_delete_sealed',
                'version': VERSION,
                'build': BUILD_LABEL,
                'updated_at': now_ts(),
                'updated_at_text': iso_ts() if 'iso_ts' in globals() else now_text(),
                'hour': hour,
                'filename': path.name,
                'sent_ok': bool(ok),
                'paper_sent_ok': bool(ok),
                'main_sent_ok': bool(ok),
                'temp_deleted': bool(deleted),
                'deleted': bool(deleted),
                'delete_error': delete_error,
                'send_error': str(err or ''),
                'event_count': len(evs),
                'result': 'sent_deleted' if ok and deleted else ('sent_delete_failed' if ok else 'send_failed_deleted' if deleted else 'send_failed_delete_failed'),
            }
            save_json(FILES.get('hourly_raw_pack_trace', BASE_DIR / 'paper_bot_hourly_raw_pack_trace.json'), last_trace)
        save_json(FILES.get('hourly_sent_state', BASE_DIR / 'paper_bot_hourly_raw_pack_sent.json'), {'schema':'paper_hourly_sent_v678','version':VERSION,'sent_hours':sorted(sent)[-72:], 'updated_at':now_ts(), 'updated_at_text':iso_ts() if 'iso_ts' in globals() else now_text(), 'last_trace': last_trace})
        _v678_jsonl_prune(FILES.get('hourly_event_trace', BASE_DIR / 'paper_bot_hourly_raw_event_trace.jsonl'), 6*3600.0, 1200)
    except Exception as exc:
        log_error('v678_send_due_hourly_raw_pack', exc)

def _v926_decision_key_from_row(row: Dict[str, Any]) -> str:
    """Return only the strategy-owned frozen-plan decision key.

    No ticker/event-id fallback is allowed here: volatile scan ids caused the same
    frozen plan to reopen repeatedly and made CLOSED keys collide.
    """
    if not isinstance(row, dict):
        return ''
    direct = row.get('paper_decision_key_v926') or row.get('swing_gate_decision_key_v977') or row.get('minimal_gate_decision_key_v925')
    if direct not in (None, '', '-', [], {}):
        return str(direct).strip()
    for parent_key in ('swing_entry_gate_v977', 'canonical_entry_decision', 'paper_final_safety_diagnostics', 'entry_diagnostics', 'raw', 'minimal_entry_gate_v925'):
        parent = row.get(parent_key)
        if not isinstance(parent, dict):
            continue
        value = parent.get('paper_decision_key_v926') or parent.get('swing_gate_decision_key_v977') or parent.get('minimal_gate_decision_key_v925') or parent.get('decision_key')
        if value not in (None, '', '-', [], {}):
            return str(value).strip()
        gate = parent.get('swing_entry_gate_v977') if isinstance(parent.get('swing_entry_gate_v977'), dict) else parent.get('minimal_entry_gate_v925')
        if isinstance(gate, dict) and gate.get('decision_key') not in (None, '', '-', [], {}):
            return str(gate.get('decision_key')).strip()
    # v965 canonical exact identity: paper v926 OPEN seals pos_id as decision:<decision_key>.
    # This is not ticker/event reconstruction; it is the writer-owned exact key itself.
    pos_id = str(row.get('pos_id') or row.get('paper_pos_id_v926') or '').strip()
    if pos_id.startswith('decision:') and len(pos_id) > len('decision:'):
        return pos_id[len('decision:'):].strip()
    if pos_id.startswith('market:') and '|plan:' in pos_id:
        return pos_id
    return ''

def _v922_closed_key(row: Dict[str, Any]) -> str:
    if not isinstance(row, dict):
        return ''
    key = str(row.get('closed_result_key') or '').strip()
    if key:
        return key
    decision_key = _v926_decision_key_from_row(row)
    if decision_key:
        return f'closed:{decision_key}'
    ident = row.get('pos_id') or row.get('event_id') or row.get('entry_build_key')
    return ('closed:' + str(ident)) if ident not in (None, '', '-', [], {}) else ''

def _v922_seal_closed_row(row: Dict[str, Any]) -> Dict[str, Any]:
    rr = row if isinstance(row, dict) else {}
    ts = _v557_row_ts(rr) if '_v557_row_ts' in globals() else fnum(rr.get('closed_ts'), rr.get('closed_at'), default=0.0)
    if ts > 0:
        rr['closed_ts'] = ts
        rr['closed_at'] = ts
        rr['closed_at_text'] = rr.get('closed_at_text') or iso_ts(ts)
        rr['closed_day_kst'] = rr.get('closed_day_kst') or _kst_day_key(ts)
    decision_key = _v926_decision_key_from_row(rr)
    if decision_key:
        rr['paper_decision_key_v926'] = decision_key
        rr['closed_result_key'] = f'closed:{decision_key}'
        rr['closed_result_key_source'] = 'paper_decision_key_v926'
    else:
        key = _v922_closed_key(rr)
        if key:
            rr['closed_result_key'] = key
            rr.setdefault('closed_result_key_source', 'pos_id_or_event_or_entry_key')
    rr['closed_spine_schema_v922'] = 'paper_closed_exact_spine_v922'
    rr['closed_spine_schema_v926'] = 'paper_decision_exact_closed_spine_v926'
    if rr.get('good_s2_occurrence_key_v923'):
        rr['good_s2_closed_link_ready_v923'] = True
        rr['good_s2_closed_link_owner_v923'] = 'paper_closed_inherits_open_occurrence'
    return rr

def _v922_tail_has_closed_key(key: str, limit: int = 80) -> bool:
    if not key:
        return False
    try:
        return any(_v922_closed_key(r) == key for r in read_jsonl_tail(FILES['closed'], limit) if isinstance(r, dict))
    except Exception:
        return False

def _v925_record_closed_append(rr: Dict[str, Any], ok: bool, reason: str, before_count: int, after_count: int) -> None:
    path = FILES.get('closed_append_status_v925', BASE_DIR / 'paper_closed_append_status_v925.json')
    event_path = FILES.get('closed_append_events_v925', BASE_DIR / 'paper_closed_append_events_v925.jsonl')
    prior = load_json(path, {}) or {}
    is_duplicate = reason == 'already_present'
    requested_total = int(fnum(prior.get('requested_total'), default=0)) + (0 if is_duplicate else 1)
    verified_total = int(fnum(prior.get('verified_total'), default=0)) + (1 if ok and not is_duplicate else 0)
    failed_total = int(fnum(prior.get('failed_total'), default=0)) + (1 if (not ok and not is_duplicate) else 0)
    duplicate_total = int(fnum(prior.get('duplicate_total'), default=0)) + (1 if is_duplicate else 0)
    event = {
        'schema':'paper_closed_append_event_v926','version':VERSION,'build':BUILD_LABEL,
        'ts':now_ts(),'ts_text':iso_ts() if 'iso_ts' in globals() else now_text(),
        'paper_decision_key_v926':_v926_decision_key_from_row(rr),
        'closed_result_key':rr.get('closed_result_key'),'pos_id':rr.get('pos_id'),'entry_build_key':rr.get('entry_build_key'),
        'ticker':rr.get('ticker'),'closed_ts':rr.get('closed_ts'),'ok':bool(ok),'reason':reason,
        'before_count':before_count,'after_count':after_count,
    }
    append_jsonl(event_path, event)
    status = {
        'schema':'paper_closed_append_status_v926','version':VERSION,'build':BUILD_LABEL,
        'updated_ts':event['ts'],'updated_text':event['ts_text'],
        'requested_total':requested_total,'verified_total':verified_total,'failed_total':failed_total,'duplicate_total':duplicate_total,
        'last_event':event,'last_verified_key':rr.get('closed_result_key') if ok and not is_duplicate else prior.get('last_verified_key'),
        'ledger_count':after_count,
        'policy':'one frozen-plan decision opens once; one CLOSED key per decision; append+flush+fsync+tail exact verification',
    }
    save_json(path, status)

def _v922_append_closed_once(row: Dict[str, Any]) -> Tuple[Dict[str, Any], bool, str]:
    rr = _v922_seal_closed_row(row)
    key = _v922_closed_key(rr)
    before_count = line_count_cached(FILES['closed'], ttl=0)
    if not key:
        _v925_record_closed_append(rr, False, 'closed_result_key_missing', before_count, before_count)
        return rr, False, 'closed_result_key_missing'
    if _v922_tail_has_closed_key(key, limit=2500):
        _v925_record_closed_append(rr, True, 'already_present', before_count, before_count)
        return rr, True, 'already_present'
    append_jsonl(FILES['closed'], rr)
    ok = _v922_tail_has_closed_key(key, limit=2500)
    after_count = line_count_cached(FILES['closed'], ttl=0)
    verified = bool(ok and after_count >= before_count + 1)
    reason = 'appended_verified' if verified else ('append_count_mismatch' if ok else 'append_verify_failed')
    _v925_record_closed_append(rr, verified, reason, before_count, after_count)
    return rr, verified, reason

def record_closed_commit(row: Dict[str, Any], committed: bool, reason: str, owner: str, pos_id: str) -> None:
    path = FILES.get('closed_commit_status', BASE_DIR / 'paper_closed_commit_status.json')
    events = FILES.get('closed_commit_events', BASE_DIR / 'paper_closed_commit_events.jsonl')
    prior = load_json(path, {}) or {}
    event = {
        'schema':'paper_closed_commit_event_v968','version':VERSION,'build':BUILD_LABEL,
        'ts':now_ts(),'ts_text':iso_ts(),'committed':bool(committed),'reason':reason,'owner':owner,
        'paper_decision_key_v926':_v926_decision_key_from_row(row),'closed_result_key':row.get('closed_result_key'),
        'pos_id':pos_id or row.get('pos_id'),'ticker':row.get('ticker'),
    }
    append_jsonl(events, event)
    payload = {
        'schema':'paper_closed_commit_status_v968','version':VERSION,'build':BUILD_LABEL,
        'updated_ts':event['ts'],'updated_text':event['ts_text'],
        'requested_total':int(fnum(prior.get('requested_total'), default=0))+1,
        'committed_total':int(fnum(prior.get('committed_total'), default=0))+(1 if committed else 0),
        'failed_total':int(fnum(prior.get('failed_total'), default=0))+(0 if committed else 1),
        'last_event':event,
        'policy':'append+fsync verify -> decision CLOSED seal -> OPEN remove; any failure keeps OPEN',
    }
    if not _paper_write_json_verified(path, payload):
        log_error('closed_commit_status_write_verified', RuntimeError('closed commit status persistence failed'))

def read_opened_at_for_exit(pos: Dict[str, Any]) -> float:
    """Read only sealed OPEN timestamps. Never replace a missing timestamp with now."""
    if not isinstance(pos, dict):
        return 0.0
    return fnum(pos.get('opened_at'), pos.get('opened_ts'), default=0.0)

def prepare_open_position_for_exit(pos: Dict[str, Any]) -> None:
    """Backfill analysis metadata only. OPEN age/price/decision identities are untouched."""
    if not isinstance(pos, dict):
        return
    if not isinstance(pos.get('canonical_entry_snapshot'), dict):
        pos['canonical_entry_snapshot'] = _v588_build_canonical_entry_snapshot(pos.get('raw') if isinstance(pos.get('raw'), dict) else {}, pos)
        pos['canonical_entry_snapshot_schema'] = 'canonical_entry_snapshot_backfilled_open'

def finalize_closed_position_metadata(pos: Dict[str, Any], closed: Dict[str, Any], ctrl: Dict[str, Any], cycle_now: float, before_update_ts: float) -> Dict[str, Any]:
    """Single CLOSED enrichment path replacing the historical update_position wrapper chain."""
    row = dict(closed)
    # Fast-paper protection model metadata; entry/exit thresholds are unchanged.
    if str(row.get('paper_experiment_lane') or '') == FAST_EXPERIMENT_LANE_V669 and str(row.get('exit_reason') or '') == 'protect_stop_after_tp':
        floor = fnum((row.get('exit_decision_spine') if isinstance(row.get('exit_decision_spine'), dict) else {}).get('paper_fast_protect_floor_pct'), default=0.0)
        pnl = fnum(row.get('pnl_pct'), default=0.0)
        entry = fnum(row.get('entry_price'), default=0.0)
        if floor > 0 and pnl < floor and entry > 0:
            modeled_exit = entry * (1.0 + (floor + fnum(ctrl.get('fee_pct_roundtrip'), default=0.10))/100.0)
            row['paper_model_raw_exit_price'] = row.get('exit_price')
            row['paper_model_raw_pnl_pct'] = pnl
            row['exit_price'] = round(modeled_exit, 8)
            row['pnl_pct'] = round(floor, 4)
            row['missed_profit_pct'] = round(max(0.0, fnum(row.get('peak_pct'), default=0.0) - floor), 4)
            row['giveback_pct'] = row['missed_profit_pct']
            row['went_negative_after_profit'] = False
            row['close_review_tag'] = close_review_tag(fnum(row.get('peak_pct'), default=0.0), floor, 'protect_stop_after_tp')
            row['exit_rule_reason'] = str(row.get('exit_rule_reason') or '') + f" / 보호모델: 실제 polling {pnl:+.2f}% → floor {floor:+.2f}%"
    # Runtime overrun trace.
    stop = fnum(ctrl.get('stop_loss_pct'), default=-0.55)
    pnl = fnum(row.get('pnl_pct'), default=0.0)
    cache_age = max(0.0, now_ts() - fnum(_LAST_PRICE_CACHE.get('ts'), default=0.0)) if isinstance(_LAST_PRICE_CACHE, dict) else None
    loop_gap = max(0.0, cycle_now - before_update_ts) if before_update_ts > 0 else None
    row['exit_runtime_owner'] = 'canonical_open_exit_evaluator'
    row['price_cache_age_sec_at_close'] = round(cache_age, 3) if cache_age is not None else None
    if loop_gap is not None:
        row['position_update_gap_sec'] = round(loop_gap, 3)
    if pnl <= stop - 0.20:
        trace = {
            'schema':'paper_stop_overrun_trace','version':VERSION,'build':BUILD_LABEL,'ts':now_ts(),'ts_text':iso_ts(),
            'ticker':row.get('ticker'),'entry_price':row.get('entry_price'),'exit_price':row.get('exit_price'),'pnl_pct':pnl,
            'stop_loss_pct':stop,'overrun_pct':round(pnl-stop,4),'exit_reason':row.get('exit_reason') or row.get('exit_rule'),
            'position_update_gap_sec':row.get('position_update_gap_sec'),'price_cache_age_sec':row.get('price_cache_age_sec_at_close'),
            'note':'청산기준 변경 없음. OPEN 감시 지연 확인용.'
        }
        row['stop_loss_overrun'] = trace
        append_jsonl(FILES['stop_overrun_trace'], trace)
    # Preserve entry evidence once, without additional update_position wrappers.
    snap = row.get('entry_snapshot_v752') if isinstance(row.get('entry_snapshot_v752'), dict) else (pos.get('entry_snapshot_v752') if isinstance(pos.get('entry_snapshot_v752'), dict) else {})
    if not snap:
        raw = row.get('raw') if isinstance(row.get('raw'), dict) else {}
        diag = row.get('entry_diagnostics') if isinstance(row.get('entry_diagnostics'), dict) else {}
        snap = _v752_line_snapshot(raw, diag, row)
    _v752_apply_entry_snapshot_to_row(row, snap)
    row = _v756_prepare_closed_row(row, pos)
    strategy_snapshot = _v762_find_strategy_snapshot(pos) or _v762_find_strategy_snapshot(row)
    if strategy_snapshot:
        _v762_apply_snapshot(row, strategy_snapshot, 'paper_closed_copied_from_open_strategy_snapshot')
    basis = _v764_find_basis(pos) or _v764_find_basis(row)
    entry_snapshot = _v764_find_snapshot(pos) or _v764_find_snapshot(row)
    _v764_apply_basis(row, basis, entry_snapshot, 'paper_closed_copied_entry_basis')
    _v771_mark_basis(row, 'paper_closed_basis_probe')
    _v772_mark_entry_check(row, 'paper_closed_entry_check')
    _v773_mark_structure_route(row, pos, 'closed')
    _v774_mark_entry_and_route(row, pos, 'closed')
    _v793_attach_entry_quality(row, row, 'closed')
    row['post_entry_reaction_v793'] = pos.get('post_entry_reaction_v793') if isinstance(pos.get('post_entry_reaction_v793'), dict) else {}
    row['loss_similarity_v793'] = _v793_loss_similarity(row)
    row['closed_metadata_owner'] = 'finalize_closed_position_metadata'
    return row

def commit_closed_position_exact(open_pos: Dict[str, Dict[str, Any]], pid: str, updated: Dict[str, Any], closed: Dict[str, Any], owner: str) -> Tuple[Dict[str, Any], bool, str]:
    """Canonical live CLOSED transaction. Never remove OPEN before both writes succeed."""
    rr = dict(closed) if isinstance(closed, dict) else {}
    rr['closed_commit_owner'] = owner
    rr['closed_commit_schema'] = 'paper_closed_commit_v968'
    rr, append_ok, append_reason = _v922_append_closed_once(rr)
    if not append_ok:
        open_pos[pid] = updated if isinstance(updated, dict) else dict(rr)
        reason = f'closed_append_failed:{append_reason}'
        record_closed_commit(rr, False, reason, owner, pid)
        return rr, False, reason
    try:
        decision_ok = _v926_mark_decision(rr, 'CLOSED', pos_id=str(pid), reason=append_reason)
    except Exception as exc:
        decision_ok = False
        append_reason = f'decision_exception:{type(exc).__name__}'
        log_error('v965_closed_decision_commit', exc)
    if not decision_ok:
        open_pos[pid] = updated if isinstance(updated, dict) else dict(rr)
        reason = f'decision_closed_commit_failed:{append_reason}'
        record_closed_commit(rr, False, reason, owner, pid)
        return rr, False, reason
    remaining=dict(open_pos); remaining.pop(pid,None)
    if not _v1055_persist_open_force(remaining, 'exact_closed_open_remove'):
        open_pos[pid] = updated if isinstance(updated, dict) else dict(rr)
        reason='open_remove_persist_failed_after_exact_closed'
        record_closed_commit(rr,False,reason,owner,pid)
        return rr,False,reason
    open_pos.clear(); open_pos.update(remaining)
    reason = 'committed_exact_closed' if append_reason != 'already_present' else 'committed_existing_exact_closed'
    record_closed_commit(rr, True, reason, owner, pid)
    return rr, True, reason

_DECISION_RECONCILED_THIS_PROCESS = False

def _paper_json_digest(obj: Any) -> str:
    raw=json.dumps(obj,ensure_ascii=False,separators=(',',':'),sort_keys=True,default=str).encode('utf-8')
    return hashlib.sha256(raw).hexdigest()

def _paper_write_json_verified__L15292(path: Path, obj: Any) -> bool:
    """Atomic JSON write with file+directory fsync and exact read-back verification."""
    tmp=path.with_name(f'.{path.name}.{os.getpid()}.{time.time_ns()}.tmp')
    try:
        path.parent.mkdir(parents=True,exist_ok=True)
        text=json.dumps(obj,ensure_ascii=False,separators=(',',':'),default=str)
        with tmp.open('w',encoding='utf-8') as handle:
            handle.write(text); handle.flush(); os.fsync(handle.fileno())
        os.replace(tmp,path)
        try:
            dir_fd=os.open(str(path.parent),os.O_RDONLY)
            try: os.fsync(dir_fd)
            finally: os.close(dir_fd)
        except Exception as exc:
            log_error(f'directory_fsync:{path.name}',exc)
            return False
        loaded=json.loads(path.read_text(encoding='utf-8',errors='strict'))
        return _paper_json_digest(loaded)==_paper_json_digest(obj)
    except Exception as exc:
        log_error(f'write_json_verified:{path.name}',exc)
        try:
            if tmp.exists(): tmp.unlink()
        except Exception as cleanup_exc:
            log_error(f'write_json_verified_cleanup:{path.name}',cleanup_exc)
        return False

def _paper_closed_exact_sets() -> Tuple[Dict[str, Dict[str, Any]], set[str]]:
    """Read exact CLOSED identities from the canonical ledger only."""
    by_decision: Dict[str, Dict[str, Any]]={}
    pos_ids: set[str]=set()
    path=FILES['closed']
    if not path.exists():
        return by_decision,pos_ids
    try:
        with path.open('r',encoding='utf-8',errors='ignore') as handle:
            for line in handle:
                if not line.strip(): continue
                try: row=json.loads(line)
                except Exception: continue
                if not isinstance(row,dict): continue
                key=_v926_decision_key_from_row(row)
                closed_key=str(row.get('closed_result_key') or '').strip()
                if not key or closed_key not in (f'closed:{key}',):
                    continue
                by_decision[str(key)]=row
                pos_id=str(row.get('pos_id') or '').strip()
                if pos_id: pos_ids.add(pos_id)
    except Exception as exc:
        log_error('read_closed_exact_sets',exc)
    return by_decision,pos_ids

def reconcile_decision_state_at_startup(force: bool=False) -> Dict[str, Any]:
    """Rebuild decision statuses from exact active OPEN and exact CLOSED identities.

    A prior completion marker is never trusted. Historical decisions with neither exact
    active OPEN nor exact CLOSED evidence become LEGACY_EXIT_UNVERIFIED.
    """
    global _DECISION_RECONCILED_THIS_PROCESS
    status_path=FILES.get('decision_reconcile_status',BASE_DIR/'paper_decision_reconcile_status.json')
    if _DECISION_RECONCILED_THIS_PROCESS and not force:
        prior=load_json(status_path,{}) or {}
        return prior if isinstance(prior,dict) else {}
    started=now_ts()
    open_pos=load_open()
    closed_by_key,closed_pos_ids=_paper_closed_exact_sets()
    stale_open_ids=[]
    for pid,pos in list(open_pos.items()):
        if not isinstance(pos,dict): continue
        key=_v926_decision_key_from_row(pos)
        pos_id=str(pos.get('pos_id') or pid)
        if (key and str(key) in closed_by_key) or pos_id in closed_pos_ids:
            stale_open_ids.append(str(pid)); open_pos.pop(pid,None)
    open_cleanup_ok=True
    if stale_open_ids:
        open_cleanup_ok=persist_open_positions(open_pos)
        if not open_cleanup_ok:
            open_pos=load_open()
    active_keys=set(); active_pos_ids=set(); active_missing_key=0
    for pid,pos in open_pos.items():
        if not isinstance(pos,dict): continue
        key=_v926_decision_key_from_row(pos)
        if key: active_keys.add(str(key))
        else: active_missing_key+=1
        active_pos_ids.add(str(pos.get('pos_id') or pid))
    state=_v926_load_decision_state(); records=state.get('records') if isinstance(state.get('records'),dict) else {}
    changed=0; active_open=0; exact_closed=0; legacy=0
    all_keys=set(records.keys())|set(active_keys)|set(closed_by_key.keys())
    nowv=now_ts()
    for key in all_keys:
        rec=dict(records.get(key)) if isinstance(records.get(key),dict) else {'paper_decision_key_v926':key}
        prior_status=str(rec.get('status') or '').upper()
        if key in closed_by_key:
            row=closed_by_key[key]
            rec.update({'status':'CLOSED','paper_decision_key_v926':key,'pos_id':row.get('pos_id') or rec.get('pos_id'),
                        'ticker':normalize_ticker(row.get('ticker') or row.get('market') or row.get('symbol') or rec.get('ticker')),
                        'closed_ts':fnum(row.get('closed_ts'),row.get('closed_at'),default=0.0) or rec.get('closed_ts'),
                        'closed_result_key':row.get('closed_result_key'),'source':'startup_exact_closed_ledger_v967',
                        'last_seen_ts':nowv})
            exact_closed+=1
        elif key in active_keys or str(rec.get('pos_id') or '') in active_pos_ids:
            rec.update({'status':'OPEN','paper_decision_key_v926':key,'source':'startup_active_open_exact_v967','last_seen_ts':nowv})
            active_open+=1
        else:
            rec.update({'status':'LEGACY_EXIT_UNVERIFIED','paper_decision_key_v926':key,
                        'legacy_exit_unverified_v967':True,
                        'legacy_exit_reason_v967':'no active OPEN exact identity and no exact CLOSED ledger row',
                        'source':'startup_orphan_reconcile_v967','last_seen_ts':nowv})
            legacy+=1
        if str(rec.get('status') or '').upper()!=prior_status: changed+=1
        records[str(key)]=rec
    state['records']=records
    state['last_reconcile_v967']={'ts':nowv,'active_keys':len(active_keys),'closed_keys':len(closed_by_key),'legacy':legacy}
    state_write_ok=_v926_save_decision_state(state)
    verify_state=_v926_load_decision_state() if state_write_ok else {'records':{}}
    verify_records=verify_state.get('records') if isinstance(verify_state.get('records'),dict) else {}
    verify_counts=Counter(str(v.get('status') or 'UNKNOWN') for v in verify_records.values() if isinstance(v,dict))
    expected_legacy=max(0,len(all_keys)-len(active_keys)-len(closed_by_key))
    counts_match=bool(
        state_write_ok
        and int(verify_counts.get('OPEN',0))==len(active_keys)
        and int(verify_counts.get('CLOSED',0))==len(closed_by_key)
        and int(verify_counts.get('LEGACY_EXIT_UNVERIFIED',0))==expected_legacy
        and sum(int(v) for v in verify_counts.values())==len(all_keys)
    )
    result={
        'schema':'paper_decision_startup_reconcile_v967','version':VERSION,'build':BUILD_LABEL,
        'state':'ACTIVE' if counts_match and open_cleanup_ok and active_missing_key==0 else 'ERROR',
        'completed':bool(counts_match and open_cleanup_ok and active_missing_key==0),
        'updated_ts':now_ts(),'updated_text':iso_ts(),'elapsed_sec':round(now_ts()-started,3),
        'active_open_exact':len(active_keys),'active_open_positions':len(open_pos),'active_open_missing_decision_key':active_missing_key,
        'exact_closed_decisions':len(closed_by_key),'legacy_exit_unverified':int(verify_counts.get('LEGACY_EXIT_UNVERIFIED',0)),
        'decision_open_verified':int(verify_counts.get('OPEN',0)),'decision_closed_verified':int(verify_counts.get('CLOSED',0)),'expected_legacy_exit_unverified':expected_legacy,
        'changed_records':changed,'stale_open_exact_closed_removed':len(stale_open_ids),'stale_open_ids':stale_open_ids[:20],
        'open_cleanup_write_verified':open_cleanup_ok,'decision_state_write_verified':state_write_ok,'counts_match':counts_match,
        'status_write_verified':True,
        'policy':'reconcile every process startup from exact OPEN/CLOSED sets; fail fast on any count mismatch; no completed-marker skip; no ticker/time-near CLOSED recovery',
    }
    status_write_ok=_paper_write_json_verified(status_path,result)
    if not status_write_ok:
        result['status_write_verified']=False
        result['state']='ERROR'
        result['completed']=False
    _DECISION_RECONCILED_THIS_PROCESS=bool(result.get('completed'))
    return result

_CLASSIFY_DIRTY_V1013: Dict[str, Any] = {'dirty':True,'reason':'startup','updated_ts':0.0}

CLASSIFY_HELPER_STATUS_V1013 = BASE_DIR / 'paper_classify_helper_status_v1013.json'

def _run_classify_helper_v1013(reason: str, force: bool=False) -> Dict[str, Any]:
    if not force and not bool(_CLASSIFY_DIRTY_V1013.get('dirty')):
        return {'ok':True,'skipped':True,'reason':'not_dirty'}
    started=time.time(); env=dict(os.environ); env['PAPER_V1013_CLASSIFY_CHILD']='1'
    proc=subprocess.run([sys.executable,str(Path(__file__).resolve()),'--classify-refresh-v1013'],stdout=subprocess.PIPE,stderr=subprocess.PIPE,text=True,timeout=300,env=env,check=False)
    payload={}
    try: payload=json.loads(proc.stdout.strip().splitlines()[-1]) if proc.stdout.strip() else {}
    except Exception: payload={'stdout_tail':proc.stdout[-500:]}
    status={'schema':'paper_classify_helper_status_v1013','version':VERSION,'build':BUILD_LABEL,'updated_at':now_ts(),'reason':reason,'ok':proc.returncode==0 and bool(payload.get('ok')),'returncode':proc.returncode,'elapsed_sec':round(time.time()-started,3),'payload':payload,'stderr_tail':proc.stderr[-500:]}
    save_json(CLASSIFY_HELPER_STATUS_V1013,status)
    if status['ok']:
        _CLASSIFY_DIRTY_V1013.update({'dirty':False,'reason':'','updated_ts':now_ts()})
    else:
        log_error('classify_helper_v1013',RuntimeError(str(status)))
    return status

def _v1180_stage_open_decision(state: Dict[str, Any], row: Dict[str, Any], pos_id: str, reason: str='paper_open_registered') -> Tuple[bool, Dict[str, Any], Dict[str, Any]]:
    key=_v926_decision_key_from_row(row)
    if not key:
        return False,{},{}
    records=state.get('records') if isinstance(state.get('records'),dict) else {}
    prior=records.get(key) if isinstance(records.get(key),dict) else {}
    if str(prior.get('status') or '').upper() in ('OPEN','CLOSED'):
        return False,{},{}
    nowv=now_ts(); rec=dict(prior)
    rec.update({'status':'OPEN','paper_decision_key_v926':key,'pos_id':pos_id or row.get('pos_id'),'ticker':normalize_ticker(row.get('ticker') or row.get('market') or row.get('symbol')),'last_seen_ts':nowv,'last_reason':reason})
    for evidence_key,evidence_value in _v938_quality_evidence_from_row(row).items():
        if evidence_value not in (None,'',[],{}): rec[evidence_key]=evidence_value
    rec['opened_ts']=fnum(row.get('opened_at'),row.get('opened_ts'),default=0.0) or nowv
    records[key]=rec; state['records']=records
    event={'schema':'paper_decision_event_v1180','version':VERSION,'build':BUILD_LABEL,'ts':nowv,'ts_text':iso_ts(nowv),'status':'OPEN','paper_decision_key_v926':key,'pos_id':rec.get('pos_id'),'ticker':rec.get('ticker'),'reason':reason,'selected_to_open_delay_sec':rec.get('selected_to_open_delay_sec'),'timing_spine_schema_v940':rec.get('timing_spine_schema_v940')}
    state['last_event']=event
    return True,rec,event

def _v1180_commit_open_batch(open_pos: Dict[str, Dict[str, Any]], prepared: List[Tuple[str, Dict[str, Any], Dict[str, Any]]]) -> Tuple[List[Dict[str, Any]], List[Tuple[str, Dict[str, Any]]]]:
    """One verified OPEN snapshot + one verified decision-state snapshot per cycle."""
    if not prepared:
        return [],[]
    original=dict(open_pos); staged=dict(open_pos)
    decision_state=_v926_load_decision_state()
    committed_meta=[]; decision_events=[]; seen_keys=set()
    for pid,pos,ev in prepared:
        key=_v926_decision_key_from_row(pos)
        if not key or key in seen_keys or pid in staged:
            continue
        ok,_rec,event=_v1180_stage_open_decision(decision_state,pos,str(pid))
        if not ok:
            continue
        seen_keys.add(key); staged[pid]=pos; committed_meta.append((pid,pos,ev)); decision_events.append(event)
    if not committed_meta:
        return [],[]
    _exact_commit_enter_v994()
    try:
        if not persist_open_positions(staged):
            raise RuntimeError('v1180 batch OPEN persistence verification failed')
        if not _v926_save_decision_state(decision_state):
            if not persist_open_positions(original):
                raise RuntimeError('v1180 decision save failed and OPEN rollback failed')
            raise RuntimeError('v1180 batch decision-state persistence verification failed')
        open_pos.clear(); open_pos.update(staged)
    finally:
        _exact_commit_exit_v994()
    for event in decision_events:
        try: append_jsonl(FILES.get('decision_events_v926',BASE_DIR/'paper_decision_events_v926.jsonl'),event)
        except Exception as exc: log_error('v1180_decision_event_append',exc)
    opened=[]; traces=[]
    for pid,pos,ev in committed_meta:
        ts=_v1153_paper_event_once('OPEN_COMMITTED',pos,extra={'pos_id':str(pid),'entry_price':pos.get('entry_price'),'batch_commit_v1180':True})
        _v1153_set_path_ts(pos,'open_committed_at',ts)
        opened.append(pos); traces.append((pid,ev))
    return opened,traces

VERSION = 'paper_bot_v0.795'

BUILD_LABEL = 'structure_board_mainline_2026-06-10'

VERSION = 'paper_bot_v0.795'

BUILD_LABEL = 'structure_board_mainline_2026-06-10'

def _v752_first_known_num(*vals: Any, default: Optional[float] = None) -> Optional[float]:
    for v in vals:
        if v is None or v == '':
            continue
        try:
            x = float(v)
            return x
        except Exception:
            continue
    return default

def _v752_first_dict(*vals: Any) -> Dict[str, Any]:
    for v in vals:
        if isinstance(v, dict) and v:
            return v
    return {}

def _v752_nested_sources(ev: Dict[str, Any], diag: Optional[Dict[str, Any]] = None, pos: Optional[Dict[str, Any]] = None) -> Dict[str, Dict[str, Any]]:
    ev = ev if isinstance(ev, dict) else {}
    diag = diag if isinstance(diag, dict) else {}
    pos = pos if isinstance(pos, dict) else {}
    ctx = _v752_first_dict(pos.get('entry_context'), ev.get('entry_context'), diag.get('entry_context'))
    raw = _v752_first_dict(pos.get('raw'), ev.get('raw'))
    cm = _v752_first_dict(pos.get('canonical_metric_row'), ev.get('canonical_metric_row'), ctx.get('canonical_metric_row'), diag.get('canonical_metric_row'))
    levels = _v752_first_dict(pos.get('structure_levels'), diag.get('structure_levels'), ctx.get('structure_levels'), ev.get('structure_levels'), cm.get('structure_levels'))
    plan = _v752_first_dict(pos.get('entry_plan'), diag.get('entry_plan'), ctx.get('entry_plan'), ev.get('entry_plan'), cm.get('entry_plan'))
    rr = _v752_first_dict(pos.get('risk_reward'), diag.get('risk_reward'), ctx.get('risk_reward'), ev.get('risk_reward'), cm.get('risk_reward'))
    osi = _v752_first_dict(pos.get('official_structure_inputs_raw'), ev.get('official_structure_inputs_raw'), ctx.get('official_structure_inputs_raw'), raw.get('official_structure_inputs_raw'))
    return {'pos': pos, 'ev': ev, 'diag': diag, 'ctx': ctx, 'raw': raw, 'cm': cm, 'levels': levels, 'plan': plan, 'rr': rr, 'osi': osi}

def _v752_source_age(ev: Dict[str, Any], base_ts: Optional[float] = None) -> float:
    ev = ev if isinstance(ev, dict) else {}
    ts = _v752_first_known_num(ev.get('candidate_created_at'), ev.get('source_created_at'), ev.get('event_ts'), ev.get('detected_ts'), ev.get('created_at'), ev.get('updated_ts'), default=None)
    if ts is None or ts <= 0:
        return 999999.0
    nowv = float(base_ts or now_ts())
    return max(0.0, nowv - ts)

def _v747_target_info(row: Dict[str, Any]) -> Tuple[bool, float]:  # type: ignore[override]
    raw, snap, mat, ctx = _v754_nested(row)
    plan = snap.get('entry_plan') if isinstance(snap.get('entry_plan'), dict) else {}
    levels = snap.get('structure_levels') if isinstance(snap.get('structure_levels'), dict) else {}
    return _v747_pick_num(
        row.get('target_price'), row.get('target1_price'), row.get('target1'), row.get('take_profit_price'), row.get('tp1'),
        snap.get('target1_price'), snap.get('target_price'), snap.get('target1'), snap.get('take_profit_price'), snap.get('tp1'),
        levels.get('target1_price'), levels.get('target_price'), plan.get('target1_price'), plan.get('target_price'),
        raw.get('target_price'), raw.get('target1_price'), raw.get('target1'), raw.get('take_profit_price'), raw.get('tp1'),
        mat.get('target1_price'), mat.get('target_price'), mat.get('target1'), mat.get('take_profit_price'), mat.get('tp1'),
        ctx.get('target_price'), ctx.get('target1_price'), ctx.get('target1'), ctx.get('take_profit_price'), ctx.get('tp1'),
    )

def _v747_stop_info(row: Dict[str, Any]) -> Tuple[bool, float]:  # type: ignore[override]
    raw, snap, mat, ctx = _v754_nested(row)
    plan = snap.get('entry_plan') if isinstance(snap.get('entry_plan'), dict) else {}
    levels = snap.get('structure_levels') if isinstance(snap.get('structure_levels'), dict) else {}
    return _v747_pick_num(
        row.get('invalid_price'), row.get('stop_price'), row.get('stop_loss_price'), row.get('loss_cut_price'),
        snap.get('invalid_price'), snap.get('stop_price'), snap.get('stop_loss_price'),
        levels.get('invalid_price'), levels.get('stop_price'), plan.get('invalid_price'), plan.get('stop_price'),
        raw.get('invalid_price'), raw.get('stop_price'), raw.get('stop_loss_price'), raw.get('loss_cut_price'),
        mat.get('invalid_price'), mat.get('stop_price'), mat.get('stop_loss_price'), mat.get('loss_cut_price'),
        ctx.get('invalid_price'), ctx.get('stop_price'), ctx.get('stop_loss_price'), ctx.get('loss_cut_price'),
    )

def _v747_rr_info(row: Dict[str, Any]) -> Tuple[bool, float, str]:  # type: ignore[override]
    raw, snap, mat, ctx = _v754_nested(row)
    rrbox = snap.get('risk_reward') if isinstance(snap.get('risk_reward'), dict) else {}
    ok, rr = _v747_pick_num(
        row.get('rr'), row.get('rr_ratio'), row.get('risk_reward'), row.get('risk_reward_ratio'),
        snap.get('rr_ratio'), snap.get('rr'), snap.get('risk_reward_ratio'),
        rrbox.get('rr_ratio'), rrbox.get('risk_reward_ratio'), rrbox.get('rr'),
        raw.get('rr'), raw.get('rr_ratio'), raw.get('risk_reward'), raw.get('risk_reward_ratio'),
        mat.get('rr_ratio'), mat.get('rr'), mat.get('risk_reward'), mat.get('risk_reward_ratio'),
        ctx.get('rr'), ctx.get('rr_ratio'), ctx.get('risk_reward'), ctx.get('risk_reward_ratio'),
    )
    if ok:
        return True, rr, 'explicit'
    entry = _v747_entry_price(row)
    tok, target = _v747_target_info(row)
    sok, stop = _v747_stop_info(row)
    if entry > 0 and tok and sok:
        reward = target - entry
        risk = entry - stop
        if risk > 0 and reward > 0:
            return True, reward / risk, 'calculated'
    return False, 0.0, 'missing'

def _v747_reaction_info(row: Dict[str, Any]) -> Tuple[bool, float]:  # type: ignore[override]
    raw, snap, mat, ctx = _v754_nested(row)
    return _v747_pick_num(
        row.get('entry_price_reaction_pct'), row.get('price_reaction_pct'), row.get('change_1m_pct'), row.get('price_chg_60s'),
        snap.get('price_reaction_pct'), snap.get('change_1m_pct'), snap.get('price_chg_60s'),
        raw.get('entry_price_reaction_pct'), raw.get('price_reaction_pct'), raw.get('change_1m_pct'), raw.get('price_chg_60s'),
        mat.get('price_reaction_pct'), mat.get('change_1m_pct'), mat.get('price_chg_60s'),
        ctx.get('price_reaction_pct'), ctx.get('change_1m_pct'), ctx.get('price_chg_60s'),
    )

def _v747_candle_age(row: Dict[str, Any]) -> float:  # type: ignore[override]
    raw, snap, mat, ctx = _v754_nested(row)
    osi = row.get('official_structure_inputs_raw') if isinstance(row.get('official_structure_inputs_raw'), dict) else {}
    ok, ca = _v747_pick_num(
        row.get('official_candle_age'), snap.get('official_candle_age'), raw.get('official_candle_age'), osi.get('official_candle_age'),
        mat.get('official_candle_age'), ctx.get('official_candle_age')
    )
    return ca if ok else 0.0

def _v754_line_snapshot(ev: Dict[str, Any], diag: Optional[Dict[str, Any]] = None, pos: Optional[Dict[str, Any]] = None) -> Dict[str, Any]:
    diag = diag if isinstance(diag, dict) else {}
    pos = pos if isinstance(pos, dict) else {}
    src = _v752_nested_sources(ev if isinstance(ev, dict) else {}, diag, pos)
    ctx = src.get('ctx', {}) if isinstance(src.get('ctx'), dict) else {}
    # v752가 놓친 diag 내부 구조재료를 공식 소스로 포함한다.
    levels = _v752_first_dict(pos.get('structure_levels'), diag.get('structure_levels'), ctx.get('structure_levels'), (ev or {}).get('structure_levels'))
    plan = _v752_first_dict(pos.get('entry_plan'), diag.get('entry_plan'), ctx.get('entry_plan'), (ev or {}).get('entry_plan'))
    rrbox = _v752_first_dict(pos.get('risk_reward'), diag.get('risk_reward'), ctx.get('risk_reward'), (ev or {}).get('risk_reward'))
    osi = _v752_first_dict(pos.get('official_structure_inputs_raw'), diag.get('official_structure_inputs_raw'), (ev or {}).get('official_structure_inputs_raw'), ctx.get('official_structure_inputs_raw'))
    gate = _v752_first_dict(pos.get('trigger_gate'), diag.get('trigger_gate'), (ev or {}).get('trigger_gate'))
    entry = _v752_first_known_num(pos.get('entry_price'), gate.get('entry_price'), (ev or {}).get('entry_price'), (ev or {}).get('current_price'), (ev or {}).get('price'), default=0.0) or 0.0
    trigger = _v752_first_known_num(gate.get('trigger_price'), pos.get('trigger_price'), levels.get('trigger_price'), plan.get('trigger_price'), (ev or {}).get('trigger_price'), default=0.0) or 0.0
    target1 = _v752_first_known_num(levels.get('target1_price'), levels.get('target_price'), plan.get('target1_price'), plan.get('target_price'), rrbox.get('target1_price'), rrbox.get('target_price'), (ev or {}).get('target1_price'), (ev or {}).get('target_price'), default=0.0) or 0.0
    target2 = _v752_first_known_num(levels.get('target2_price'), plan.get('target2_price'), rrbox.get('target2_price'), (ev or {}).get('target2_price'), default=0.0) or 0.0
    invalid = _v752_first_known_num(levels.get('invalid_price'), levels.get('stop_price'), plan.get('invalid_price'), plan.get('stop_price'), rrbox.get('invalid_price'), rrbox.get('stop_price'), (ev or {}).get('invalid_price'), (ev or {}).get('stop_price'), default=0.0) or 0.0
    rr_ratio = _v752_first_known_num(rrbox.get('rr_ratio'), rrbox.get('risk_reward_ratio'), (ev or {}).get('rr_ratio'), (ev or {}).get('risk_reward_ratio'), default=None)
    if rr_ratio is None and entry > 0 and target1 > entry and invalid > 0 and invalid < entry:
        rr_ratio = (target1 - entry) / (entry - invalid)
    reaction = _v752_first_known_num((ev or {}).get('price_reaction_pct'), (ev or {}).get('change_1m_pct'), ctx.get('price_reaction_pct'), ctx.get('change_1m_pct'), diag.get('price_reaction_pct'), diag.get('change_1m_pct'), default=None)
    candle_age = _v752_first_known_num((ev or {}).get('official_candle_age'), osi.get('official_candle_age'), ctx.get('official_candle_age'), diag.get('official_candle_age'), default=None)
    candle_source = str((ev or {}).get('official_candle_source') or osi.get('official_candle_source') or ctx.get('official_candle_source') or diag.get('official_candle_source') or '')
    source_age = _v752_source_age(ev if isinstance(ev, dict) else {}, base_ts=_v752_first_known_num(pos.get('opened_at'), default=None) or now_ts())
    return {
        'schema': 'paper_entry_snapshot_v754_closed_spine',
        'paper_version': VERSION,
        'build': BUILD_LABEL,
        'sealed_at': now_ts(),
        'sealed_at_text': iso_ts(),
        'ticker': normalize_ticker(pos.get('ticker') or (ev or {}).get('ticker') or (ev or {}).get('symbol') or (ev or {}).get('market')),
        'event_id': (ev or {}).get('event_id') or (ev or {}).get('event_key') or pos.get('event_id'),
        'candidate_created_at': (ev or {}).get('candidate_created_at'),
        'source_created_at': (ev or {}).get('source_created_at'),
        'event_ts': (ev or {}).get('event_ts'),
        'source_age_at_open_sec': round(source_age, 3) if source_age < 999999 else source_age,
        'entry_price': entry or None,
        'trigger_price': trigger or None,
        'target1_price': target1 or None,
        'target2_price': target2 or None,
        'invalid_price': invalid or None,
        'rr_ratio': round(float(rr_ratio), 4) if rr_ratio is not None else None,
        'price_reaction_pct': reaction,
        'micro_age_sec': _v752_first_known_num((ev or {}).get('micro_age_sec'), ctx.get('micro_age_sec'), diag.get('micro_age_sec'), default=None),
        'orderflow_age_sec': _v752_first_known_num((ev or {}).get('orderflow_age_sec'), ctx.get('orderflow_age_sec'), diag.get('orderflow_age_sec'), default=None),
        'price_reaction_age_sec': _v752_first_known_num((ev or {}).get('price_reaction_age_sec'), ctx.get('price_reaction_age_sec'), diag.get('price_reaction_age_sec'), default=None),
        'official_candle_age': candle_age,
        'official_candle_source': candle_source or None,
        'line_source': 'v753_same_snapshot_diag_ctx_event',
        'structure_levels': _v588_json_safe(levels) if '_v588_json_safe' in globals() else levels,
        'entry_plan': _v588_json_safe(plan) if '_v588_json_safe' in globals() else plan,
        'risk_reward': _v588_json_safe(rrbox) if '_v588_json_safe' in globals() else rrbox,
        'official_structure_inputs_raw': _v588_json_safe(osi) if '_v588_json_safe' in globals() else osi,
    }

def _v752_line_snapshot__L16164(ev: Dict[str, Any], diag: Optional[Dict[str, Any]] = None, pos: Optional[Dict[str, Any]] = None) -> Dict[str, Any]:  # type: ignore[override]
    return _v754_line_snapshot(ev, diag, pos)

def _v752_apply_entry_snapshot_to_row__L16168(row: Dict[str, Any], snap: Dict[str, Any]) -> None:  # type: ignore[override]
    if not isinstance(row, dict) or not isinstance(snap, dict):
        return
    row['entry_snapshot'] = snap
    row['entry_snapshot_v754'] = snap
    row['entry_snapshot_v753'] = snap
    row['entry_snapshot_v752'] = snap
    row['entry_snapshot_schema'] = snap.get('schema')
    for k in ('candidate_created_at','source_created_at','event_ts','source_age_at_open_sec','trigger_price','target1_price','target2_price','invalid_price','rr_ratio','price_reaction_pct','micro_age_sec','orderflow_age_sec','price_reaction_age_sec','official_candle_age','official_candle_source'):
        v = snap.get(k)
        if v not in (None, ''):
            row[k] = v
    if snap.get('target1_price') not in (None, ''):
        row['target_price'] = snap.get('target1_price')
    if snap.get('invalid_price') not in (None, ''):
        row['stop_price'] = snap.get('invalid_price')
    if snap.get('rr_ratio') not in (None, ''):
        row['rr'] = snap.get('rr_ratio')
        row['risk_reward_ratio'] = snap.get('rr_ratio')
    row['closed_open_snapshot_spine_v754'] = True

def _v747_entry_quality__L16190(rows: List[Dict[str, Any]]) -> Dict[str, Any]:  # type: ignore[override]
    c: Counter = Counter()
    examples: Dict[str, List[str]] = {}
    def mark(key: str, row: Dict[str, Any]) -> None:
        c[key] += 1
        examples.setdefault(key, [])
        if len(examples[key]) < 5:
            examples[key].append(str(row.get('ticker') or row.get('symbol') or '-'))
    for r in rows or []:
        if not isinstance(r, dict):
            continue
        if not _v754_has_entry_snapshot(r):
            mark('legacy_without_entry_snapshot', r)
            continue
        mark('snapshot_ready_rows', r)
        age = _v747_timing_age(r)
        source_age = _v751_source_age_for_closed(r)
        if age >= 600 and source_age <= 300:
            mark('timing_field_contaminated', r)
        elif age >= 600:
            mark('old_candidate_entry', r)
        if source_age >= 300 and source_age < 999999:
            mark('old_source_entry', r)
        entry = _v747_entry_price(r)
        tok, target = _v747_target_info(r)
        if entry > 0 and tok and target > 0 and entry >= target * 0.995:
            mark('target_near_or_above_entry', r)
        if _v747_trigger_gap(r) >= 0.60:
            mark('trigger_gap_high', r)
        rr_ok, rr, rr_src = _v747_rr_info(r)
        if rr_ok:
            if rr < 1.20:
                mark('rr_bad_or_missing', r); mark('rr_bad', r)
            if rr_src == 'calculated':
                mark('rr_calculated', r)
        else:
            mark('rr_missing', r)
        reac_ok, reac = _v747_reaction_info(r)
        if reac_ok:
            if reac < 0.15:
                mark('reaction_off_before_entry', r); mark('reaction_off', r)
        else:
            mark('reaction_missing', r)
        ca = _v747_candle_age(r)
        if ca >= 120:
            mark('official_candle_stale_120s', r)
        elif ca <= 0:
            mark('official_candle_missing', r)
    out = dict(c)
    out['top'] = dict(c.most_common(12))
    out['examples'] = examples
    out['precision_policy_v754'] = 'legacy rows without entry_snapshot are not counted as missing materials; new snapshot rows are classified separately'
    return out

def _v749_loss_split(rows: List[Dict[str, Any]]) -> Dict[str, Any]:  # type: ignore[override]
    loss_rows = [r for r in (rows or []) if isinstance(r, dict) and _v747_closed_bucket(r) in ('stop_loss','fast_fail','time_exit','other_loss')]
    strategy = Counter(); issues = Counter(); examples: Dict[str, List[str]] = {}
    def ex(key: str, row: Dict[str, Any]) -> None:
        examples.setdefault(key, [])
        if len(examples[key]) < 5:
            examples[key].append(str(row.get('ticker') or row.get('symbol') or '-'))
    for r in loss_rows:
        sk = str(r.get('strategy') or r.get('strategy_label') or r.get('paper_strategy_key') or r.get('strategy_key') or 'unknown')
        strategy[sk] += 1
        if not _v754_has_entry_snapshot(r):
            issues['구버전snapshot없음'] += 1; ex('구버전snapshot없음', r)
            continue
        if _v751_timing_contaminated(r):
            issues['timing필드오염'] += 1; ex('timing필드오염', r)
        elif _v747_timing_age(r) >= 600:
            issues['오래된후보진입'] += 1; ex('오래된후보진입', r)
        entry = _v747_entry_price(r); tok, target = _v747_target_info(r)
        if entry > 0 and tok and target > 0 and entry >= target * 0.995:
            issues['목표근처진입'] += 1; ex('목표근처진입', r)
        if _v747_trigger_gap(r) >= 0.60:
            issues['방아쇠gap과다'] += 1; ex('방아쇠gap과다', r)
        rr_ok, rr, _ = _v747_rr_info(r)
        if rr_ok and rr < 1.20:
            issues['RR불량'] += 1; ex('RR불량', r)
        elif not rr_ok:
            issues['RR확인불가'] += 1; ex('RR확인불가', r)
        reac_ok, reac = _v747_reaction_info(r)
        if reac_ok and reac < 0.15:
            issues['진입직전반응꺼짐'] += 1; ex('진입직전반응꺼짐', r)
        elif not reac_ok:
            issues['진입반응확인불가'] += 1; ex('진입반응확인불가', r)
        ca = _v747_candle_age(r)
        if ca >= 120:
            issues['공식캔들stale'] += 1; ex('공식캔들stale', r)
        elif ca <= 0:
            issues['공식캔들없음'] += 1; ex('공식캔들없음', r)
    return {'n': len(loss_rows), 'strategy_top': dict(strategy.most_common(10)), 'issue_top': dict(issues.most_common(12)), 'examples': examples}

VERSION = 'paper_bot_v0.795'

BUILD_LABEL = 'structure_board_mainline_2026-06-10'

def _v755_list_from_any(v: Any) -> List[str]:
    if v in (None, '', [], {}):
        return []
    raw = v if isinstance(v, list) else [v]
    return [str(x).strip() for x in raw if str(x).strip()]

def _v755_first_taxonomy(*objs: Any) -> Dict[str, Any]:
    for obj in objs:
        if not isinstance(obj, dict):
            continue
        tax = obj.get('structure_taxonomy_v755')
        if isinstance(tax, dict) and (tax.get('good') or tax.get('bad') or tax.get('recheck')):
            return tax
    good: List[str] = []
    bad: List[str] = []
    recheck: List[str] = []
    for obj in objs:
        if not isinstance(obj, dict):
            continue
        good += _v755_list_from_any(obj.get('structure_good_tags_v755'))
        bad += _v755_list_from_any(obj.get('structure_bad_tags_v755'))
        recheck += _v755_list_from_any(obj.get('structure_recheck_tags_v755'))
    def uniq(xs: List[str], limit: int = 20) -> List[str]:
        out=[]
        for x in xs:
            if x and x not in out:
                out.append(x)
            if len(out)>=limit:
                break
        return out
    good=uniq(good); bad=uniq(bad); recheck=uniq(recheck)
    side='neutral'
    if good and not bad: side='good'
    elif bad and not good: side='bad'
    elif good and bad: side='mixed'
    elif recheck: side='recheck'
    return {'schema':'structure_taxonomy_v755_snapshot_copy','good':good,'bad':bad,'recheck':recheck,'side':side,'policy':'classification_only_no_threshold_change'}

def _v752_line_snapshot__L16344(ev: Dict[str, Any], diag: Optional[Dict[str, Any]] = None, pos: Optional[Dict[str, Any]] = None) -> Dict[str, Any]:  # type: ignore[override]
    snap = _v755_prev_line_snapshot(ev, diag, pos)
    try:
        ev = ev if isinstance(ev, dict) else {}
        diag = diag if isinstance(diag, dict) else {}
        pos = pos if isinstance(pos, dict) else {}
        ctx = ev.get('entry_context') if isinstance(ev.get('entry_context'), dict) else {}
        raw = ev.get('raw') if isinstance(ev.get('raw'), dict) else {}
        cm = ev.get('canonical_metric_row') if isinstance(ev.get('canonical_metric_row'), dict) else {}
        tax = _v755_first_taxonomy(ev, ctx, raw, cm, diag, pos)
        snap['structure_taxonomy_v755'] = tax
        snap['structure_good_tags_v755'] = tax.get('good') or []
        snap['structure_bad_tags_v755'] = tax.get('bad') or []
        snap['structure_recheck_tags_v755'] = tax.get('recheck') or []
        snap['structure_signal_side_v755'] = tax.get('side') or 'neutral'
    except Exception as exc:
        log_error('v755_line_snapshot_structure_taxonomy', exc)
    return snap

def _v752_apply_entry_snapshot_to_row__L16365(row: Dict[str, Any], snap: Dict[str, Any]) -> None:  # type: ignore[override]
    _v755_prev_apply_entry_snapshot_to_row(row, snap)
    if not isinstance(row, dict) or not isinstance(snap, dict):
        return
    tax = snap.get('structure_taxonomy_v755') if isinstance(snap.get('structure_taxonomy_v755'), dict) else {}
    if tax:
        row['structure_taxonomy_v755'] = tax
        row['structure_good_tags_v755'] = tax.get('good') or []
        row['structure_bad_tags_v755'] = tax.get('bad') or []
        row['structure_recheck_tags_v755'] = tax.get('recheck') or []
        row['structure_signal_side_v755'] = tax.get('side') or 'neutral'

def _v755_row_taxonomy__L16377(row: Dict[str, Any]) -> Dict[str, Any]:
    row = row if isinstance(row, dict) else {}
    for key in ('entry_snapshot_v754','entry_snapshot_v753','entry_snapshot_v752','entry_snapshot','canonical_entry_snapshot'):
        obj = row.get(key)
        if isinstance(obj, dict):
            tax = obj.get('structure_taxonomy_v755')
            if isinstance(tax, dict) and (tax.get('good') or tax.get('bad') or tax.get('recheck')):
                return tax
    return _v755_first_taxonomy(row)

def _v755_structure_split(rows: List[Dict[str, Any]]) -> Dict[str, Any]:
    buckets: Dict[str, List[Dict[str, Any]]] = {}
    side_counter: Counter = Counter()
    tag_counter: Counter = Counter()
    loss_tag_counter: Counter = Counter()
    examples: Dict[str, List[str]] = {}
    def add_ex(key: str, r: Dict[str, Any]) -> None:
        examples.setdefault(key, [])
        if len(examples[key]) < 5:
            examples[key].append(str(r.get('ticker') or r.get('symbol') or '-'))
    for r in rows or []:
        if not isinstance(r, dict):
            continue
        tax = _v755_row_taxonomy(r)
        side = str(tax.get('side') or 'no_snapshot')
        if not _v754_has_entry_snapshot(r):
            side = 'legacy_without_entry_snapshot'
        side_counter[side] += 1
        buckets.setdefault(side, []).append(r)
        tags = []
        for group_name in ('good','bad','recheck'):
            for t in _v755_list_from_any(tax.get(group_name)):
                key = f'{group_name}:{t}'
                tags.append(key)
                tag_counter[key] += 1
                if _v747_closed_bucket(r) in ('stop_loss','fast_fail','time_exit','other_loss'):
                    loss_tag_counter[key] += 1
                    add_ex(key, r)
    side_stats = {k: _v747_stat_rows(v) for k, v in buckets.items()}
    return {
        'schema': 'structure_profit_split_v755',
        'side_counts': dict(side_counter.most_common(12)),
        'side_stats': side_stats,
        'tag_top': dict(tag_counter.most_common(20)),
        'loss_tag_top': dict(loss_tag_counter.most_common(20)),
        'examples': examples,
        'policy': 'structure taxonomy is classification-only; thresholds unchanged',
    }

def _v747_build_classify_cache__L16428(rows: List[Dict[str, Any]], status: Optional[Dict[str, Any]] = None) -> Dict[str, Any]:  # type: ignore[override]
    out = _v755_prev_build_classify_cache(rows, status)
    try:
        rows = [r for r in (rows or []) if isinstance(r, dict)]
        out['structure_split_v755'] = {
            'recent_3h': _v755_structure_split(_v741_recent_rows(rows, 3.0)),
            'recent_6h': _v755_structure_split(_v741_recent_rows(rows, 6.0)),
            'recent_24h': _v755_structure_split(_v741_recent_rows(rows, 24.0)),
        }
        notes = out.get('notes') if isinstance(out.get('notes'), list) else []
        notes.append('v755: structure good/bad/recheck taxonomy split added without changing thresholds')
        out['notes'] = notes
        out['schema'] = 'paper_classify_board_v755_structure_taxonomy'
    except Exception as exc:
        log_error('v755_build_classify_structure_split', exc)
    return out

VERSION = 'paper_bot_v0.795'

BUILD_LABEL = 'structure_board_mainline_2026-06-10'

def _v756_snapshot_keys() -> tuple:
    return ('entry_snapshot_v756', 'entry_snapshot_v754', 'entry_snapshot_v753', 'entry_snapshot_v752', 'entry_snapshot', 'canonical_entry_snapshot')

def _v756_existing_snapshot(row: Dict[str, Any]) -> Dict[str, Any]:
    row = row if isinstance(row, dict) else {}
    for k in _v756_snapshot_keys():
        obj = row.get(k)
        if isinstance(obj, dict) and obj:
            return obj
    return {}

def _v756_build_snapshot_from_row(row: Dict[str, Any]) -> Dict[str, Any]:
    row = row if isinstance(row, dict) else {}
    snap = _v756_existing_snapshot(row)
    if snap:
        return snap
    raw = row.get('raw') if isinstance(row.get('raw'), dict) else row
    diag = row.get('entry_diagnostics') if isinstance(row.get('entry_diagnostics'), dict) else {}
    if not diag:
        diag = row.get('paper_final_safety_diagnostics') if isinstance(row.get('paper_final_safety_diagnostics'), dict) else {}
    try:
        snap = _v752_line_snapshot(raw if isinstance(raw, dict) else row, diag, row)
    except Exception as exc:
        log_error('v756_build_snapshot_from_row', exc)
        snap = {}
    if not isinstance(snap, dict):
        snap = {}
    if snap:
        snap['schema'] = 'paper_entry_snapshot_v756_closed_writer_spine'
        snap['closed_writer_reconstructed_v756'] = True
        snap['paper_version'] = VERSION
        snap['build'] = BUILD_LABEL
    return snap

def _v756_apply_snapshot(row: Dict[str, Any], snap: Dict[str, Any]) -> Dict[str, Any]:
    if not isinstance(row, dict):
        return row
    if not isinstance(snap, dict) or not snap:
        row['entry_snapshot_missing_reason_v756'] = 'snapshot_unavailable_after_reconstruct'
        return row
    try:
        _v752_apply_entry_snapshot_to_row(row, snap)
    except Exception as exc:
        log_error('v756_apply_v752_snapshot', exc)
    row['entry_snapshot'] = snap
    row['entry_snapshot_v756'] = snap
    row['entry_snapshot_v754'] = row.get('entry_snapshot_v754') if isinstance(row.get('entry_snapshot_v754'), dict) else snap
    row['entry_snapshot_schema'] = snap.get('schema') or row.get('entry_snapshot_schema')
    row['closed_writer_snapshot_spine_v756'] = True
    # classify가 깊은 source를 못 찾아도 바로 읽게 평탄화
    for k in ('candidate_created_at','source_created_at','event_ts','source_age_at_open_sec','trigger_price','target1_price','target2_price','invalid_price','rr_ratio','price_reaction_pct','micro_age_sec','orderflow_age_sec','price_reaction_age_sec','official_candle_age','official_candle_source'):
        v = snap.get(k)
        if v not in (None, ''):
            row[k] = v
    if snap.get('target1_price') not in (None, ''):
        row['target_price'] = snap.get('target1_price')
    if snap.get('invalid_price') not in (None, ''):
        row['stop_price'] = snap.get('invalid_price')
    if snap.get('rr_ratio') not in (None, ''):
        row['rr'] = snap.get('rr_ratio')
        row['risk_reward_ratio'] = snap.get('rr_ratio')
    return row

def _v756_prepare_position_snapshot(pos: Dict[str, Any], ev: Optional[Dict[str, Any]] = None) -> Dict[str, Any]:
    if not isinstance(pos, dict):
        return pos
    ev = ev if isinstance(ev, dict) else (pos.get('raw') if isinstance(pos.get('raw'), dict) else pos)
    diag = pos.get('entry_diagnostics') if isinstance(pos.get('entry_diagnostics'), dict) else {}
    try:
        snap = _v752_line_snapshot(ev if isinstance(ev, dict) else pos, diag, pos)
        if isinstance(snap, dict) and snap:
            snap['schema'] = 'paper_entry_snapshot_v756_open_writer_spine'
            snap['paper_version'] = VERSION
            snap['build'] = BUILD_LABEL
            _v756_apply_snapshot(pos, snap)
    except Exception as exc:
        log_error('v756_prepare_position_snapshot', exc)
    return pos

def _v756_prepare_closed_row(row: Dict[str, Any], source_pos: Optional[Dict[str, Any]] = None) -> Dict[str, Any]:
    if not isinstance(row, dict):
        return row
    # CLOSED row 우선, 없으면 source OPEN row에서 snapshot/raw/diag를 끌어온다.
    snap = _v756_existing_snapshot(row)
    if not snap and isinstance(source_pos, dict):
        snap = _v756_existing_snapshot(source_pos)
        if snap:
            row.setdefault('entry_snapshot_source_v756', 'source_open_position')
    if not snap:
        base = dict(source_pos) if isinstance(source_pos, dict) else row
        for k, v in row.items():
            base[k] = v
        snap = _v756_build_snapshot_from_row(base)
        row.setdefault('entry_snapshot_source_v756', 'closed_writer_reconstructed')
    _v756_apply_snapshot(row, snap)
    row['closed_writer_snapshot_spine_v756'] = True
    row['closed_paper_version'] = VERSION
    row['close_build_label_v756'] = BUILD_LABEL
    return row

def append_jsonl__L16581(path: Path, obj: Dict[str, Any]) -> None:  # type: ignore[override]
    try:
        closed_path = FILES.get('closed')
        if closed_path is not None and Path(path) == Path(closed_path) and isinstance(obj, dict):
            obj = _v756_prepare_closed_row(obj)
    except Exception as exc:
        log_error('v756_append_closed_prepare', exc)
    _v756_prev_append_jsonl(path, obj)
    try:
        closed_path = FILES.get('closed')
        if closed_path is not None and Path(path) == Path(closed_path):
            rows = [r for r in read_jsonl_tail(FILES['closed'], 1200) if isinstance(r, dict)]
            status = load_json(FILES['status'], {}) or {}
            save_json(FILES.get('classify', BASE_DIR / 'paper_bot_classify_cache.json'), _v747_build_classify_cache(rows, status))
    except Exception as exc:
        log_error('v756_append_closed_refresh_classify', exc)

def _v755_row_taxonomy__L16617(row: Dict[str, Any]) -> Dict[str, Any]:  # type: ignore[override]
    row = row if isinstance(row, dict) else {}
    snap = row.get('entry_snapshot_v756') if isinstance(row.get('entry_snapshot_v756'), dict) else {}
    if snap:
        tax = snap.get('structure_taxonomy_v755') if isinstance(snap.get('structure_taxonomy_v755'), dict) else {}
        if tax and (tax.get('good') or tax.get('bad') or tax.get('recheck')):
            return tax
    if _v756_prev_v755_row_taxonomy:
        return _v756_prev_v755_row_taxonomy(row)
    return _v755_first_taxonomy(row)

VERSION = 'paper_bot_v0.795'

BUILD_LABEL = 'structure_board_mainline_2026-06-10'

def _v757_text_has_v756plus(*vals: Any) -> bool:
    blob = ' '.join(str(v or '') for v in vals)
    return any(x in blob for x in ('v0.756', 'v0.757', 'v756_', 'v757_', 'paper_bot_v0.756', 'paper_bot_v0.787'))

def _v757_row_has_v756plus_marker(row: Dict[str, Any]) -> bool:
    row = row if isinstance(row, dict) else {}
    keys = (
        'version','paper_version','closed_paper_version','opened_paper_version','source_alert_version',
        'build','source_alert_build','close_build_label_v756','close_build_label_v757',
        'entry_snapshot_source_v756','closed_writer_snapshot_spine_v756','classify_source_owner_v757'
    )
    vals = [row.get(k) for k in keys]
    for parent in ('entry_snapshot','entry_snapshot_v756','entry_snapshot_v754','entry_snapshot_v753','entry_snapshot_v752','canonical_entry_snapshot'):
        obj = row.get(parent)
        if isinstance(obj, dict):
            vals += [obj.get('paper_version'), obj.get('build'), obj.get('schema')]
    return _v757_text_has_v756plus(*vals)

def _v757_row_key(row: Dict[str, Any]) -> str:
    try:
        k = _v607_row_key(row) if '_v607_row_key' in globals() else ''
        if k:
            return str(k)
    except Exception:
        pass
    ticker = normalize_ticker((row or {}).get('ticker') or (row or {}).get('symbol') or '')
    opened = fnum((row or {}).get('opened_at'), default=0.0)
    closed = fnum((row or {}).get('closed_at'), (row or {}).get('ts'), default=0.0)
    pnl = fnum((row or {}).get('pnl_pct'), (row or {}).get('profit_pct'), default=0.0)
    return f'fallback:{ticker}:{round(opened,1)}:{round(closed,1)}:{round(pnl,4)}'

def _v757_has_snapshot(row: Dict[str, Any]) -> bool:
    try:
        return bool(_v756_existing_snapshot(row)) if '_v756_existing_snapshot' in globals() else bool(_v754_has_entry_snapshot(row))
    except Exception:
        return False

def _v757_prepare_classify_row(row: Dict[str, Any], source: str = 'ledger') -> Dict[str, Any]:
    out = dict(row or {})
    out['classify_source_owner_v757'] = 'ledger_snapshot_priority'
    out['classify_row_source_v757'] = source
    if _v757_has_snapshot(out):
        out['classify_snapshot_state_v757'] = 'snapshot_present'
        return out
    if source == 'ledger' and _v757_row_has_v756plus_marker(out):
        try:
            out = _v756_prepare_closed_row(out) if '_v756_prepare_closed_row' in globals() else out
        except Exception as exc:
            log_error('v757_prepare_ledger_snapshot', exc)
        if _v757_has_snapshot(out):
            out['classify_snapshot_state_v757'] = 'ledger_reconstructed_snapshot'
            out['entry_snapshot_source_v757'] = out.get('entry_snapshot_source_v756') or 'ledger_reader_reconstructed'
            return out
        out['classify_snapshot_state_v757'] = 'v756plus_ledger_snapshot_missing_after_reconstruct'
        return out
    if source == 'alert_recovered':
        out['classify_snapshot_state_v757'] = 'alert_recovered_no_snapshot'
        out['alert_recovered_no_snapshot_v757'] = True
        return out
    out['classify_snapshot_state_v757'] = 'legacy_without_entry_snapshot'
    return out

def _v757_merge_alert_into_ledger(ledger_row: Dict[str, Any], alert_row: Dict[str, Any]) -> Dict[str, Any]:
    out = dict(ledger_row or {})
    alert_row = alert_row if isinstance(alert_row, dict) else {}
    for k in ('source_alert_phase','source_alert_version','source_alert_build','close_alert_sent','alert_sent','message_id'):
        if out.get(k) in (None, '') and alert_row.get(k) not in (None, ''):
            out[k] = alert_row.get(k)
    # 알림에는 있지만 장부에는 없는 표시값만 보조로 붙인다. snapshot/진입값은 ledger 우선.
    for k in ('closed_at_text','exit_reason','exit_rule','strategy','strategy_label'):
        if out.get(k) in (None, '', '-') and alert_row.get(k) not in (None, '', '-'):
            out[k] = alert_row.get(k)
    out['alert_merged_into_ledger_v757'] = True
    return out

def _v757_hot_filter(rows: List[Dict[str, Any]]) -> List[Dict[str, Any]]:
    try:
        return _v678_hot_closed_filter(rows, now_ts()) if '_v678_hot_closed_filter' in globals() else rows
    except Exception:
        return rows

def _v757_reconciled_closed_rows(limit_closed: int = 720, limit_alert: int = 720) -> Tuple[List[Dict[str, Any]], Dict[str, Any]]:
    ledger_raw = [r for r in read_jsonl_tail(FILES['closed'], limit_closed) if isinstance(r, dict)]
    ledger_rows = [_v757_prepare_classify_row(r, 'ledger') for r in _v757_hot_filter(ledger_raw)]
    ledger_by_key: Dict[str, Dict[str, Any]] = {}
    for r in ledger_rows:
        k = _v757_row_key(r)
        if k:
            ledger_by_key[k] = r
    raw_alerts: List[Dict[str, Any]] = []
    try:
        ap = _v607_close_alert_trace_path() if '_v607_close_alert_trace_path' in globals() else FILES.get('close_alert_trace', BASE_DIR / 'paper_bot_close_alert_trace.jsonl')
        raw_alerts = [r for r in read_jsonl_tail(ap, limit_alert) if isinstance(r, dict) and str(r.get('kind') or '').lower() == 'closed']
    except Exception as exc:
        log_error('v757_reconcile_alert_read', exc)
    alert_hot = _v757_hot_filter(raw_alerts)
    phase_rank = {'send_ok': 3, 'attempt_start': 2, 'without_alert_trace': 1, 'send_error': 0, 'message_build_error': 0}
    best: Dict[str, Dict[str, Any]] = {}
    for r in alert_hot:
        k = _v757_row_key(r)
        if not k:
            continue
        cur = best.get(k)
        if not cur or phase_rank.get(str(r.get('phase') or ''), 0) >= phase_rank.get(str(cur.get('phase') or ''), 0):
            best[k] = r
    recovered: List[Dict[str, Any]] = []
    merged_alerts = 0
    for k, alert in best.items():
        if k in ledger_by_key:
            ledger_by_key[k] = _v757_merge_alert_into_ledger(ledger_by_key[k], alert)
            merged_alerts += 1
            continue
        try:
            cr = _v607_alert_to_closed_row(alert) if '_v607_alert_to_closed_row' in globals() else dict(alert)
            if cr.get('ticker') and fnum(cr.get('closed_at'), cr.get('ts'), default=0.0) > 0:
                recovered.append(_v757_prepare_classify_row(cr, 'alert_recovered'))
        except Exception as exc:
            log_error('v757_alert_to_closed_row', exc)
    rows = list(ledger_by_key.values()) + recovered
    rows = _v757_hot_filter(rows)
    rows.sort(key=lambda x: fnum(x.get('closed_at'), x.get('ts'), default=0.0))
    snap_count = sum(1 for r in rows if _v757_has_snapshot(r))
    legacy_count = sum(1 for r in rows if str(r.get('classify_snapshot_state_v757') or '') in ('legacy_without_entry_snapshot','alert_recovered_no_snapshot'))
    meta = {
        'schema': 'paper_closed_source_reconcile_v757_ledger_snapshot_priority',
        'version': VERSION,
        'build': BUILD_LABEL,
        'ledger_tail_read': len(ledger_raw),
        'ledger_hot_count': len(ledger_rows),
        'alert_trace_tail_read': len(raw_alerts),
        'alert_unique_count': len(best),
        'alert_merged_into_ledger': merged_alerts,
        'alert_recovered_count': len(recovered),
        'snapshot_rows': snap_count,
        'legacy_or_alert_no_snapshot_rows': legacy_count,
        'source_policy': 'classify/score/review use CLOSED ledger row first; close_alert rows only recover missing ledger rows and never override ledger snapshot',
    }
    return rows, meta

def append_jsonl__L16808(path: Path, obj: Dict[str, Any]) -> None:  # type: ignore[override]
    closed_path = FILES.get('closed')
    is_closed = False
    try:
        is_closed = closed_path is not None and Path(path) == Path(closed_path)
    except Exception:
        is_closed = False
    if is_closed and isinstance(obj, dict):
        obj = _v757_prepare_classify_row(obj, 'ledger')
        obj['closed_writer_snapshot_spine_v757'] = True
        obj['closed_paper_version'] = VERSION
        obj['close_build_label_v757'] = BUILD_LABEL
    _v757_prev_append_jsonl(path, obj)
    if is_closed:
        try:
            rows, _rec = _v757_reconciled_closed_rows()
            status = load_json(FILES['status'], {}) or {}
            save_json(FILES.get('classify', BASE_DIR / 'paper_bot_classify_cache.json'), _v747_build_classify_cache(rows, status))
        except Exception as exc:
            log_error('v757_append_closed_refresh_classify', exc)

VERSION = 'paper_bot_v0.795'

BUILD_LABEL = 'structure_board_mainline_2026-06-10'

def _v758_snapshot_keys() -> tuple:
    return ('entry_snapshot_v758','entry_snapshot_v756','entry_snapshot_v754','entry_snapshot_v753','entry_snapshot_v752','entry_snapshot','canonical_entry_snapshot')

def _v758_existing_snapshot__L16859(row: Dict[str, Any]) -> Dict[str, Any]:
    row = row if isinstance(row, dict) else {}
    for k in _v758_snapshot_keys():
        obj = row.get(k)
        if isinstance(obj, dict) and obj:
            return obj
    return {}

def _v758_build_snapshot(row: Dict[str, Any]) -> Dict[str, Any]:
    row = row if isinstance(row, dict) else {}
    snap = _v758_existing_snapshot(row)
    if snap:
        return snap
    raw = row.get('raw') if isinstance(row.get('raw'), dict) else row
    diag = row.get('entry_diagnostics') if isinstance(row.get('entry_diagnostics'), dict) else {}
    if not diag:
        diag = row.get('paper_final_safety_diagnostics') if isinstance(row.get('paper_final_safety_diagnostics'), dict) else {}
    # CLOSED row의 flat 필드와 entry_context를 diag 보조 재료로 합친다.
    try:
        ctx = row.get('entry_context') if isinstance(row.get('entry_context'), dict) else {}
        for k in ('structure_levels','entry_plan','risk_reward','price_reaction_pct','buy_ratio','buy_sustain_1m','spread_pct','slippage_pct','official_candle_age','official_candle_source'):
            if k not in diag and row.get(k) not in (None, '', [], {}):
                diag[k] = row.get(k)
            if k not in diag and ctx.get(k) not in (None, '', [], {}):
                diag[k] = ctx.get(k)
    except Exception:
        pass
    try:
        if '_v752_line_snapshot' in globals():
            snap = _v752_line_snapshot(raw if isinstance(raw, dict) else row, diag, row)  # type: ignore[name-defined]
        elif '_v756_build_snapshot_from_row' in globals():
            snap = _v756_build_snapshot_from_row(row)  # type: ignore[name-defined]
        else:
            snap = {}
    except Exception as exc:
        log_error('v758_build_snapshot', exc)
        snap = {}
    if not isinstance(snap, dict):
        snap = {}
    if snap:
        snap['schema'] = 'paper_entry_snapshot_v758_classify_ledger_rebuild'
        snap['paper_version'] = VERSION
        snap['build'] = BUILD_LABEL
        snap['classify_rebuilt_v758'] = True
    return snap

def _v758_apply_snapshot(row: Dict[str, Any], snap: Dict[str, Any], source: str = 'ledger') -> Dict[str, Any]:
    row = row if isinstance(row, dict) else {}
    if not isinstance(snap, dict) or not snap:
        row['classify_snapshot_state_v758'] = 'snapshot_unavailable'
        return row
    try:
        if '_v752_apply_entry_snapshot_to_row' in globals():
            _v752_apply_entry_snapshot_to_row(row, snap)  # type: ignore[name-defined]
    except Exception as exc:
        log_error('v758_apply_v752_snapshot', exc)
    row['entry_snapshot'] = snap
    row['entry_snapshot_v758'] = snap
    row.setdefault('entry_snapshot_v756', snap)
    row['entry_snapshot_schema'] = snap.get('schema') or row.get('entry_snapshot_schema')
    row['classify_snapshot_state_v758'] = 'snapshot_present' if source == 'ledger_original' else 'ledger_rebuilt_snapshot'
    row['classify_row_source_v758'] = source
    row['classify_snapshot_rebuild_v758'] = source != 'ledger_original'
    row['classify_source_owner_v758'] = 'closed_ledger_snapshot_rebuild_single_source'
    # 구조 taxonomy는 snapshot에도 row에도 복사한다.
    try:
        tax = snap.get('structure_taxonomy_v755') if isinstance(snap.get('structure_taxonomy_v755'), dict) else None
        if tax:
            row['structure_taxonomy_v755'] = tax
            row['structure_good_tags_v755'] = tax.get('good') or []
            row['structure_bad_tags_v755'] = tax.get('bad') or []
            row['structure_recheck_tags_v755'] = tax.get('recheck') or []
            row['structure_signal_side_v755'] = tax.get('side') or 'neutral'
    except Exception:
        pass
    return row

def _v758_prepare_classify_ledger_row(row: Dict[str, Any], source: str = 'ledger') -> Dict[str, Any]:
    out = dict(row or {})
    existing = _v758_existing_snapshot(out)
    if existing:
        return _v758_apply_snapshot(out, existing, 'ledger_original')
    snap = _v758_build_snapshot(out)
    if _v758_meaningful_snapshot(snap):
        return _v758_apply_snapshot(out, snap, source)
    out['classify_snapshot_state_v758'] = 'legacy_without_rebuildable_snapshot'
    out['classify_row_source_v758'] = source
    out['classify_source_owner_v758'] = 'closed_ledger_snapshot_rebuild_single_source'
    return out

def _v755_row_taxonomy__L16990(row: Dict[str, Any]) -> Dict[str, Any]:  # type: ignore[override]
    row = row if isinstance(row, dict) else {}
    snap = _v758_existing_snapshot(row)
    tax = snap.get('structure_taxonomy_v755') if isinstance(snap.get('structure_taxonomy_v755'), dict) else {}
    if tax and (tax.get('good') or tax.get('bad') or tax.get('recheck')):
        return tax
    if _v758_prev_v755_row_taxonomy:
        return _v758_prev_v755_row_taxonomy(row)
    return _v755_first_taxonomy(row) if '_v755_first_taxonomy' in globals() else {'good': [], 'bad': [], 'recheck': [], 'side': 'neutral'}

def append_jsonl__L17087(path: Path, obj: Dict[str, Any]) -> None:  # type: ignore[override]
    closed_path = FILES.get('closed')
    try:
        is_closed = closed_path is not None and Path(path) == Path(closed_path)
    except Exception:
        is_closed = False
    if not is_closed:
        _v758_prev_append_jsonl(path, obj)
        return
    rr = _v922_seal_closed_row(dict(obj or {})) if '_v922_seal_closed_row' in globals() else dict(obj or {})
    rr = _v758_prepare_classify_ledger_row(rr, 'closed_writer_rebuilt')
    rr['closed_writer_snapshot_spine_v758'] = True
    rr['closed_paper_version'] = VERSION
    rr['close_build_label_v758'] = BUILD_LABEL
    p = Path(path)
    p.parent.mkdir(parents=True, exist_ok=True)
    line = json.dumps(rr, ensure_ascii=False, default=str) + '\n'
    with p.open('a', encoding='utf-8') as f:
        f.write(line)
        f.flush()
        os.fsync(f.fileno())
    if isinstance(obj, dict):
        obj.clear(); obj.update(rr)
    if is_closed:
        _CLASSIFY_DIRTY_V1013['dirty']=True
        _CLASSIFY_DIRTY_V1013['reason']='new_closed_append'
        _CLASSIFY_DIRTY_V1013['updated_ts']=now_ts()

VERSION = 'paper_bot_v0.795'

BUILD_LABEL = 'structure_board_mainline_2026-06-10'

def _v759_d(*vals: Any) -> Dict[str, Any]:
    for v in vals:
        if isinstance(v, dict) and v:
            return v
    return {}

def _v759_list(v: Any) -> List[str]:
    out: List[str] = []
    if isinstance(v, list):
        src = v
    elif isinstance(v, tuple):
        src = list(v)
    elif isinstance(v, str) and v.strip():
        src = [x.strip() for x in v.replace('|','/').split('/')]
    else:
        src = []
    for x in src:
        txt = str(x).strip()
        if txt and txt not in out:
            out.append(txt)
    return out

def _v759_num(*vals: Any, default: Optional[float] = None) -> Optional[float]:
    for v in vals:
        if v in (None, ''):
            continue
        try:
            return float(str(v).replace(',', '').replace('%',''))
        except Exception:
            continue
    return default

def _v759_original_snapshot__L17178(row: Dict[str, Any]) -> Dict[str, Any]:
    row = row if isinstance(row, dict) else {}
    if _v759_prev_v758_existing_snapshot:
        try:
            snap = _v759_prev_v758_existing_snapshot(row)  # type: ignore[misc]
            if isinstance(snap, dict) and snap:
                return snap
        except Exception:
            pass
    for k in ('entry_snapshot_v758','entry_snapshot_v756','entry_snapshot_v754','entry_snapshot_v753','entry_snapshot_v752','entry_snapshot','canonical_entry_snapshot'):
        obj = row.get(k)
        if isinstance(obj, dict) and obj:
            return obj
    return {}

def _v759_structure_line_audit(row: Dict[str, Any], snap: Dict[str, Any], levels: Dict[str, Any]) -> Dict[str, Any]:
    row = row if isinstance(row, dict) else {}
    snap = snap if isinstance(snap, dict) else {}
    levels = levels if isinstance(levels, dict) else {}
    struct = _v759_d(snap.get('structure'))
    ev = _v759_d(levels.get('structure_line_evidence'), struct.get('line_evidence'), snap.get('structure_line_evidence'))
    official = _v759_d(
        row.get('official_structure_inputs_raw'), row.get('official_structure_inputs'),
        snap.get('official_structure_inputs_raw'), snap.get('official_structure_inputs'),
        levels.get('official_structure_inputs_raw_v759'), levels.get('official_structure_inputs_raw'), ev.get('official_structure_inputs'),
    )
    present = int(_v759_num(official.get('present_count'), default=0.0) or 0)
    age = _v759_num(row.get('official_candle_age'), snap.get('official_candle_age'), official.get('official_candle_age'), default=None)
    quality = str(ev.get('quality') or levels.get('line_reliability_v759') or levels.get('quality') or '')
    trigger_conf = _v759_num(ev.get('trigger_confidence'), levels.get('trigger_confidence'), default=0.0) or 0.0
    support_conf = _v759_num(ev.get('support_confidence'), default=0.0) or 0.0
    resistance_conf = _v759_num(ev.get('resistance_confidence'), default=0.0) or 0.0
    source_kind = str(levels.get('line_source_kind_v759') or '')
    if not source_kind:
        if present >= 6 and age is not None and age <= 180 and ('official' in quality or trigger_conf >= 52 or support_conf >= 42):
            source_kind = 'official_candle_reactive_line'
        elif present >= 3:
            source_kind = 'official_partial_watch_line'
        elif levels:
            source_kind = 'gap_or_synthetic_line'
        else:
            source_kind = 'line_missing'
    if present <= 0 and age is None:
        reliability = 'missing_official_material'
    elif age is not None and age >= 180:
        reliability = 'stale_official_material'
    elif source_kind == 'official_candle_reactive_line':
        reliability = 'official_reactive'
    elif source_kind == 'official_partial_watch_line':
        reliability = 'official_partial'
    elif source_kind == 'line_missing':
        reliability = 'line_missing'
    else:
        reliability = 'synthetic_or_gap'
    return {
        'schema': 'structure_line_source_audit_v759',
        'source_kind': source_kind,
        'reliability': reliability,
        'official_present_count': present,
        'official_candle_age': age,
        'evidence_quality': quality or None,
        'support_confidence': support_conf,
        'resistance_confidence': resistance_conf,
        'trigger_confidence': trigger_conf,
        'line_price_policy': 'audit/classify only; no threshold or exit change',
    }

def _v759_flatten_snapshot(row: Dict[str, Any]) -> Dict[str, Any]:
    row = row if isinstance(row, dict) else {}
    snap0 = _v759_original_snapshot(row)
    if not isinstance(snap0, dict):
        snap0 = {}
    raw = row.get('raw') if isinstance(row.get('raw'), dict) else {}
    ctx = _v759_d(row.get('entry_context'), snap0.get('entry_context'))
    diag = _v759_d(row.get('entry_diagnostics'), row.get('paper_final_safety_diagnostics'))
    metrics = _v759_d(snap0.get('metrics'), snap0.get('materials'), row.get('metrics_at_entry'), ctx)
    struct = _v759_d(snap0.get('structure'), row.get('structure'))
    freshness = _v759_d(snap0.get('freshness'))
    ages = _v759_d(freshness.get('ages'))
    levels = _v759_d(row.get('structure_levels'), snap0.get('structure_levels'), struct.get('levels'), diag.get('structure_levels'), ctx.get('structure_levels'))
    plan = _v759_d(row.get('entry_plan'), snap0.get('entry_plan'), diag.get('entry_plan'), ctx.get('entry_plan'))
    rrbox = _v759_d(row.get('risk_reward'), snap0.get('risk_reward'), diag.get('risk_reward'), ctx.get('risk_reward'))
    entry = _v759_num(row.get('entry_price'), snap0.get('entry_price'), raw.get('entry_price'), default=None)
    trigger = _v759_num(row.get('trigger_price'), snap0.get('trigger_price'), levels.get('trigger_price'), plan.get('trigger_price'), default=None)
    target1 = _v759_num(row.get('target1_price'), row.get('target_price'), snap0.get('target1_price'), snap0.get('target_price'), levels.get('target1_price'), levels.get('target_price'), plan.get('target1_price'), plan.get('target_price'), rrbox.get('target1_price'), rrbox.get('target_price'), default=None)
    target2 = _v759_num(row.get('target2_price'), snap0.get('target2_price'), levels.get('target2_price'), plan.get('target2_price'), rrbox.get('target2_price'), default=None)
    invalid = _v759_num(row.get('invalid_price'), row.get('stop_price'), snap0.get('invalid_price'), levels.get('invalid_price'), levels.get('stop_price'), plan.get('invalid_price'), plan.get('stop_price'), rrbox.get('invalid_price'), rrbox.get('stop_price'), default=None)
    rr = _v759_num(row.get('rr_ratio'), row.get('risk_reward_ratio'), row.get('rr'), snap0.get('rr_ratio'), rrbox.get('rr_ratio'), rrbox.get('risk_reward_ratio'), levels.get('rr_ratio'), default=None)
    if rr is None and entry and target1 and invalid and target1 > entry and entry > invalid:
        rr = (target1 - entry) / (entry - invalid)
    reaction = _v759_num(row.get('price_reaction_pct'), row.get('entry_price_reaction_pct'), snap0.get('price_reaction_pct'), metrics.get('price_reaction_pct'), metrics.get('flow_1m_pct'), ctx.get('price_reaction_pct'), diag.get('price_reaction_pct'), default=None)
    buy = _v759_num(row.get('buy_ratio'), snap0.get('buy_ratio'), metrics.get('buy_trade_ratio'), metrics.get('buy_ratio'), ctx.get('buy_ratio'), diag.get('buy_ratio'), default=None)
    sustain = _v759_num(row.get('buy_sustain_1m'), snap0.get('buy_sustain_1m'), metrics.get('one_min_sustain'), ctx.get('buy_sustain_1m'), diag.get('buy_sustain_1m'), default=None)
    candle_age = _v759_num(row.get('official_candle_age'), snap0.get('official_candle_age'), ctx.get('official_candle_age'), diag.get('official_candle_age'), default=None)
    candle_source = row.get('official_candle_source') or snap0.get('official_candle_source') or ctx.get('official_candle_source') or diag.get('official_candle_source')
    tags = _v759_list(struct.get('tags')) + _v759_list(row.get('entry_structure_tags')) + _v759_list(row.get('structure_tags')) + _v759_list(ctx.get('structure_tags'))
    risk_tags = _v759_list(row.get('execution_risk_tags')) + _v759_list(row.get('risk_tags')) + _v759_list(ctx.get('risk_tags')) + _v759_list(struct.get('risk_tags'))
    # 기존 v755 taxonomy가 없거나 빈 껍데기면 flatten된 row로 다시 계산한다.
    tax = _v759_d(snap0.get('structure_taxonomy_v755'), row.get('structure_taxonomy_v755'), ctx.get('structure_taxonomy_v755'))
    temp = dict(row)
    temp.update({'entry_price': entry, 'current_price': entry, 'trigger_price': trigger, 'target1_price': target1, 'target_price': target1, 'invalid_price': invalid, 'stop_price': invalid, 'rr_ratio': rr, 'price_reaction_pct': reaction, 'buy_ratio': buy, 'buy_sustain_1m': sustain, 'official_candle_age': candle_age, 'official_candle_source': candle_source, 'structure_levels': levels, 'risk_tags': risk_tags, 'structure_tags': tags})
    audit = _v759_structure_line_audit(temp, snap0, levels)
    temp['structure_line_audit_v759'] = audit
    try:
        if (not tax) or not (tax.get('good') or tax.get('bad') or tax.get('recheck')):
            tax = _v755_first_taxonomy(temp) if '_v755_first_taxonomy' in globals() else _v755_row_taxonomy(temp) if '_v755_row_taxonomy' in globals() else {}
    except Exception:
        tax = tax or {}
    flat = dict(snap0)
    flat.update({
        'schema': 'paper_entry_snapshot_v759_flattened',
        'paper_version': VERSION,
        'build': BUILD_LABEL,
        'flattened_v759': True,
        'ticker': row.get('ticker') or snap0.get('ticker'),
        'entry_price': entry,
        'trigger_price': trigger,
        'target1_price': target1,
        'target2_price': target2,
        'invalid_price': invalid,
        'rr_ratio': round(float(rr), 4) if rr is not None else None,
        'price_reaction_pct': reaction,
        'buy_ratio': buy,
        'buy_sustain_1m': sustain,
        'micro_age_sec': _v759_num(row.get('micro_age_sec'), snap0.get('micro_age_sec'), ages.get('micro_age_sec'), default=None),
        'orderflow_age_sec': _v759_num(row.get('orderflow_age_sec'), snap0.get('orderflow_age_sec'), ages.get('orderflow_age_sec'), default=None),
        'official_candle_age': candle_age,
        'official_candle_source': candle_source,
        'structure_levels': levels,
        'entry_plan': plan,
        'risk_reward': rrbox,
        'structure_tags': _v759_list(tags),
        'risk_tags': _v759_list(risk_tags),
        'structure_taxonomy_v755': tax,
        'structure_good_tags_v755': tax.get('good') if isinstance(tax, dict) else [],
        'structure_bad_tags_v755': tax.get('bad') if isinstance(tax, dict) else [],
        'structure_recheck_tags_v755': tax.get('recheck') if isinstance(tax, dict) else [],
        'structure_signal_side_v755': tax.get('side') if isinstance(tax, dict) else 'neutral',
        'structure_line_audit_v759': audit,
    })
    return flat

def _v759_snapshot_has_core(snap: Dict[str, Any]) -> bool:
    if not isinstance(snap, dict) or not snap:
        return False
    if snap.get('rr_ratio') not in (None, ''):
        return True
    if snap.get('price_reaction_pct') not in (None, ''):
        return True
    tax = snap.get('structure_taxonomy_v755') if isinstance(snap.get('structure_taxonomy_v755'), dict) else {}
    if tax.get('good') or tax.get('bad') or tax.get('recheck'):
        return True
    audit = snap.get('structure_line_audit_v759') if isinstance(snap.get('structure_line_audit_v759'), dict) else {}
    if audit.get('source_kind') not in (None, '', 'line_missing'):
        return True
    return False

def _v758_existing_snapshot__L17339(row: Dict[str, Any]) -> Dict[str, Any]:  # type: ignore[override]
    return _v759_flatten_snapshot(row)

def _v758_meaningful_snapshot(snap: Dict[str, Any]) -> bool:  # type: ignore[override]
    return _v759_snapshot_has_core(snap)

def _v754_has_entry_snapshot(row: Dict[str, Any]) -> bool:  # type: ignore[override]
    return _v759_snapshot_has_core(_v759_flatten_snapshot(row))

def _v754_nested(row: Dict[str, Any]) -> Tuple[Dict[str, Any], Dict[str, Any], Dict[str, Any], Dict[str, Any]]:  # type: ignore[override]
    row = row if isinstance(row, dict) else {}
    raw = row.get('raw') if isinstance(row.get('raw'), dict) else {}
    snap = _v759_flatten_snapshot(row)
    mat: Dict[str, Any] = {}
    for src in (snap.get('materials') if isinstance(snap.get('materials'), dict) else {}, snap):
        if isinstance(src, dict):
            for k, v in src.items():
                if k not in mat:
                    mat[k] = v
    ctx = row.get('entry_context') if isinstance(row.get('entry_context'), dict) else {}
    return raw, snap, mat, ctx

def _v747_nested(row: Dict[str, Any]) -> Tuple[Dict[str, Any], Dict[str, Any], Dict[str, Any], Dict[str, Any]]:  # type: ignore[override]
    return _v754_nested(row)

def _v747_entry_quality__L17375(rows: List[Dict[str, Any]]) -> Dict[str, Any]:  # type: ignore[override]
    out = _v759_prev_entry_quality(rows)
    try:
        rows2 = [r for r in (rows or []) if isinstance(r, dict)]
        ready = 0; empty = 0; line_official = 0; line_synth = 0; tag_rows = 0
        for r in rows2:
            snap = _v759_flatten_snapshot(r)
            if _v759_snapshot_has_core(snap):
                ready += 1
            else:
                empty += 1
            tax = snap.get('structure_taxonomy_v755') if isinstance(snap.get('structure_taxonomy_v755'), dict) else {}
            if tax.get('good') or tax.get('bad') or tax.get('recheck'):
                tag_rows += 1
            audit = snap.get('structure_line_audit_v759') if isinstance(snap.get('structure_line_audit_v759'), dict) else {}
            if str(audit.get('reliability') or '').startswith('official'):
                line_official += 1
            elif audit:
                line_synth += 1
        out['snapshot_ready_rows'] = ready
        out['snapshot_empty_rows_v759'] = empty
        out['structure_tag_rows_v759'] = tag_rows
        out['official_line_rows_v759'] = line_official
        out['synthetic_or_gap_line_rows_v759'] = line_synth
        top = out.get('top') if isinstance(out.get('top'), dict) else {}
        top['snapshot_ready_rows'] = ready
        if empty:
            top['snapshot_empty_rows_v759'] = empty
        if tag_rows:
            top['structure_tag_rows_v759'] = tag_rows
        out['top'] = top
        out['precision_policy_v759'] = 'snapshot_ready requires real flattened material, not a shell; canonical nested metrics/structure/levels are flattened here'
    except Exception as exc:
        log_error('v759_entry_quality_flatten', exc)
    return out

def _v747_build_classify_cache__L17414(rows: List[Dict[str, Any]], status: Optional[Dict[str, Any]] = None) -> Dict[str, Any]:  # type: ignore[override]
    out = _v759_prev_build_classify_cache(rows, status)
    try:
        out['schema'] = 'paper_classify_board_v759_snapshot_flatten_structure_line_audit'
        out['version'] = VERSION
        out['paper_version'] = VERSION
        out['build'] = BUILD_LABEL
        notes = out.get('notes') if isinstance(out.get('notes'), list) else []
        notes.append('v759: canonical snapshot metrics/structure/levels flattened; structure line source audit added')
        out['notes'] = notes
    except Exception as exc:
        log_error('v759_classify_cache_stamp', exc)
    return out

VERSION = 'paper_bot_v0.795'

BUILD_LABEL = 'structure_board_mainline_2026-06-10'

def _v762_find_strategy_snapshot(obj: Dict[str, Any]) -> Dict[str, Any]:
    obj = obj if isinstance(obj, dict) else {}
    ctx = obj.get('entry_context') if isinstance(obj.get('entry_context'), dict) else {}
    raw = obj.get('raw') if isinstance(obj.get('raw'), dict) else {}
    diag = obj.get('entry_diagnostics') if isinstance(obj.get('entry_diagnostics'), dict) else {}
    for src in (obj, ctx, raw, diag):
        if not isinstance(src, dict):
            continue
        for key in ('canonical_entry_snapshot_v762','structure_snapshot_v762','canonical_entry_snapshot','entry_snapshot_v762'):
            snap = src.get(key)
            if isinstance(snap, dict) and snap:
                return snap
    return {}

def _v762_apply_snapshot(row: Dict[str, Any], snap: Dict[str, Any], source: str) -> None:
    if not isinstance(row, dict) or not isinstance(snap, dict) or not snap:
        return
    row['canonical_entry_snapshot_v762'] = snap
    row['entry_snapshot_v762'] = snap
    row['canonical_entry_snapshot'] = snap
    row['entry_snapshot'] = snap
    row['entry_snapshot_schema'] = snap.get('schema')
    row['entry_snapshot_source_v762'] = source
    row['structure_snapshot_copied_v762'] = True
    ctx = row.get('entry_context') if isinstance(row.get('entry_context'), dict) else {}
    ctx = dict(ctx)
    ctx['canonical_entry_snapshot_v762'] = snap
    ctx['structure_snapshot_v762'] = snap
    row['entry_context'] = ctx
    diag = row.get('entry_diagnostics') if isinstance(row.get('entry_diagnostics'), dict) else {}
    diag = dict(diag)
    diag['canonical_entry_snapshot_v762'] = snap
    diag['structure_snapshot_v762'] = snap
    row['entry_diagnostics'] = diag

def _v759_original_snapshot__L17491(row: Dict[str, Any]) -> Dict[str, Any]:  # type: ignore[override]
    row = row if isinstance(row, dict) else {}
    snap = _v762_find_strategy_snapshot(row)
    if snap:
        return snap
    if _v762_prev_v759_original_snapshot:
        try:
            return _v762_prev_v759_original_snapshot(row)  # type: ignore[misc]
        except Exception:
            pass
    return {}

def _v747_build_classify_cache__L17506(rows: List[Dict[str, Any]], status: Optional[Dict[str, Any]] = None) -> Dict[str, Any]:  # type: ignore[override]
    out = _v762_prev_build_classify_cache(rows, status)
    try:
        ready = 0; v762 = 0; copied = 0; tag_rows = 0; official = 0; partial = 0; synthetic = 0
        for r in rows or []:
            snap = _v762_find_strategy_snapshot(r if isinstance(r, dict) else {})
            if snap:
                v762 += 1
                line = snap.get('structure_line_source_v762') if isinstance(snap.get('structure_line_source_v762'), dict) else (snap.get('structure', {}) if isinstance(snap.get('structure'), dict) else {}).get('line_source', {})
                tax = snap.get('structure_taxonomy_v762') if isinstance(snap.get('structure_taxonomy_v762'), dict) else snap.get('structure_taxonomy_v755') if isinstance(snap.get('structure_taxonomy_v755'), dict) else {}
                if snap.get('structure_snapshot_copied_v762') or r.get('structure_snapshot_copied_v762'):
                    copied += 1
                if tax.get('good') or tax.get('bad') or tax.get('recheck'):
                    tag_rows += 1
                q = str(line.get('line_quality_v762') or line.get('reliability') or '') if isinstance(line, dict) else ''
                if q == 'official_full': official += 1
                elif q in ('official_partial','official_weak'): partial += 1
                elif q: synthetic += 1
                if snap.get('rr_ratio') not in (None, '', 0, 0.0) or snap.get('price_reaction_pct') not in (None, '') or tag_rows:
                    ready += 1
        out['v762_strategy_snapshot_rows'] = v762
        out['v762_strategy_snapshot_copied_rows'] = copied
        q = out.get('entry_quality_v747') if isinstance(out.get('entry_quality_v747'), dict) else {}
        q['v762_strategy_snapshot_rows'] = v762
        q['v762_structure_tag_rows'] = tag_rows
        q['v762_official_full_rows'] = official
        q['v762_official_partial_rows'] = partial
        q['v762_synthetic_or_missing_rows'] = synthetic
        out['entry_quality_v747'] = q
        out['snapshot_ready_rows_v762'] = ready
        out['structure_tag_rows_v762'] = tag_rows
        out['official_line_rows_v762'] = official
        out['partial_official_line_rows_v762'] = partial
        out['synthetic_or_missing_line_rows_v762'] = synthetic
        out['schema'] = 'paper_classify_board_v762_strategy_snapshot_spine'
        out['version'] = VERSION
        out['paper_version'] = VERSION
        out['build'] = BUILD_LABEL
        notes = out.get('notes') if isinstance(out.get('notes'), list) else []
        notes.append('v762: classify prefers strategy-owned canonical_entry_snapshot_v762 copied from S1 hold/open row')
        out['notes'] = notes
    except Exception as exc:
        log_error('v762_classify_snapshot_counts', exc)
    return out

VERSION = 'paper_bot_v0.795'

BUILD_LABEL = 'structure_board_mainline_2026-06-10'

def _v764_apply_basis(row: Dict[str, Any], basis: Dict[str, Any], snap: Dict[str, Any], source: str) -> None:
    if not isinstance(row, dict):
        return
    if isinstance(snap, dict) and snap:
        row['canonical_entry_snapshot_v764'] = snap
        row['canonical_entry_snapshot'] = snap
        row['entry_snapshot'] = snap
    if isinstance(basis, dict) and basis:
        row['canonical_entry_basis_v764'] = basis
        row['entry_basis_check_v764'] = basis.get('basis_status')
        row['entry_basis_source_v764'] = source
        ctx = row.get('entry_context') if isinstance(row.get('entry_context'), dict) else {}
        ctx = dict(ctx)
        ctx['canonical_entry_basis_v764'] = basis
        if snap:
            ctx['canonical_entry_snapshot_v764'] = snap
        row['entry_context'] = ctx
        diag = row.get('entry_diagnostics') if isinstance(row.get('entry_diagnostics'), dict) else {}
        diag = dict(diag)
        diag['canonical_entry_basis_v764'] = basis
        if snap:
            diag['canonical_entry_snapshot_v764'] = snap
        row['entry_diagnostics'] = diag
        row['entry_basis_copied_v764'] = True

def _v747_build_classify_cache__L17631(rows: List[Dict[str, Any]], status: Optional[Dict[str, Any]] = None) -> Dict[str, Any]:  # type: ignore[override]
    out = _v764_prev_build_classify_cache(rows, status)
    try:
        status_counts: Counter = Counter()
        complete = 0; copied = 0; mismatch = 0; warning = 0; missing = 0; calc = 0; official = 0
        for r in rows or []:
            if not isinstance(r, dict):
                continue
            basis = _v764_find_basis(r)
            if not basis:
                missing += 1
                continue
            if r.get('entry_basis_copied_v764'):
                copied += 1
            bs = basis.get('basis_status') if isinstance(basis.get('basis_status'), dict) else {}
            label = str(bs.get('status') or '❔ 정보 없음')
            status_counts[label] += 1
            if label.startswith('❌'):
                mismatch += 1
            elif label.startswith('⚠️'):
                warning += 1
            pb = basis.get('price_basis') if isinstance(basis.get('price_basis'), dict) else {}
            sb = basis.get('source_basis') if isinstance(basis.get('source_basis'), dict) else {}
            if pb.get('entry_price') and pb.get('trigger_price') and pb.get('target1_price') and pb.get('invalid_price'):
                complete += 1
            q = str(sb.get('structure_line_quality') or '')
            if q == 'official_full': official += 1
            elif q in ('official_weak','official_partial','fallback_gap','synthetic_pct_line','missing_official','missing'):
                calc += 1
        out['entry_basis_v764'] = {
            'rows_with_basis': sum(status_counts.values()),
            'basis_complete_rows': complete,
            'basis_copied_rows': copied,
            'status_counts': dict(status_counts),
            'basis_mismatch_rows': mismatch,
            'basis_warning_rows': warning,
            'basis_missing_rows': missing,
            'official_line_basis_rows': official,
            'calculated_or_partial_line_rows': calc,
            'user_labels': {'ok': '✅ 기준 일치', 'warn': '⚠️ 일부 주의', 'bad': '❌ 기준 불일치', 'missing': '❔ 정보 없음'},
        }
        out['schema'] = 'paper_classify_board_v764_entry_basis_unify'
        out['version'] = VERSION
        out['paper_version'] = VERSION
        out['build'] = BUILD_LABEL
        notes = out.get('notes') if isinstance(out.get('notes'), list) else []
        notes.append('v764: entry price/trigger/target/RR/source-age basis is sealed by strategy and copied by paper; user-readable basis status added')
        out['notes'] = notes
    except Exception as exc:
        log_error('v764_classify_basis_counts', exc)
    return out

VERSION = 'paper_bot_v0.795'

BUILD_LABEL = 'structure_board_mainline_2026-06-10'

def _v771_mark_basis(row: Dict[str, Any], source: str) -> None:
    try:
        basis = _v764_find_basis(row) if '_v764_find_basis' in globals() else {}
        snap = _v764_find_snapshot(row) if '_v764_find_snapshot' in globals() else {}
        if isinstance(basis, dict) and basis:
            row['canonical_entry_basis_v771'] = basis
            row['entry_basis_v771_source'] = source
        if isinstance(snap, dict) and snap:
            row['canonical_entry_snapshot_v771'] = snap
            row['entry_snapshot_v771'] = snap
        row['ledger_snapshot_probe_v771'] = {'basis': bool(basis), 'snapshot': bool(snap), 'source': source}
    except Exception as exc:
        try: log_error('v771_mark_basis', exc)
        except Exception: pass

BUILD_LABEL = 'structure_board_mainline_2026-06-10'

VERSION = 'paper_bot_v0.795'

def _v772_find_basis_from_snapshot(snap: Any) -> Dict[str, Any]:
    if not isinstance(snap, dict):
        return {}
    for key in ('canonical_entry_basis_v772', 'canonical_entry_basis_v771', 'canonical_entry_basis_v764', 'entry_basis', 'entry_check'):
        v = snap.get(key)
        if isinstance(v, dict) and v:
            return v
    return {}

def _v764_find_basis(obj: Dict[str, Any]) -> Dict[str, Any]:  # type: ignore[override]
    """Compatibility reader used by v764/v771 classify paths.
    Prefer the newest entry-check key, then older v764 key. This removes the
    'chart tag exists but entry check missing' ledger false-negative.
    """
    if not isinstance(obj, dict):
        return {}
    sources = [obj]
    for k in ('entry_context', 'entry_diagnostics', 'raw', 'source_event'):
        v = obj.get(k)
        if isinstance(v, dict):
            sources.append(v)
    for src in sources:
        for key in ('canonical_entry_basis_v772', 'canonical_entry_basis_v771', 'canonical_entry_basis_v764', 'entry_basis', 'entry_check'):
            v = src.get(key)
            if isinstance(v, dict) and v:
                return v
        for sk in ('canonical_entry_snapshot_v772', 'canonical_entry_snapshot_v771', 'canonical_entry_snapshot_v764', 'canonical_entry_snapshot_v762', 'canonical_entry_snapshot', 'entry_snapshot_v771', 'entry_snapshot_v762', 'entry_snapshot'):
            snap = src.get(sk)
            b = _v772_find_basis_from_snapshot(snap)
            if b:
                return b
    return {}

def _v764_find_snapshot(obj: Dict[str, Any]) -> Dict[str, Any]:  # type: ignore[override]
    if not isinstance(obj, dict):
        return {}
    sources = [obj]
    for k in ('entry_context', 'entry_diagnostics', 'raw', 'source_event'):
        v = obj.get(k)
        if isinstance(v, dict):
            sources.append(v)
    for src in sources:
        for key in ('canonical_entry_snapshot_v772', 'canonical_entry_snapshot_v771', 'canonical_entry_snapshot_v764', 'canonical_entry_snapshot_v762', 'structure_snapshot_v762', 'canonical_entry_snapshot', 'entry_snapshot_v771', 'entry_snapshot_v762', 'entry_snapshot'):
            snap = src.get(key)
            if isinstance(snap, dict) and snap:
                return snap
    return {}

def _v772_mark_entry_check(row: Dict[str, Any], source: str) -> None:
    try:
        if not isinstance(row, dict):
            return
        basis = _v764_find_basis(row)
        snap = _v764_find_snapshot(row)
        if isinstance(basis, dict) and basis:
            row['canonical_entry_basis_v772'] = basis
            row['entry_check_v772'] = basis
            row['entry_check_copied_v772'] = True
        if isinstance(snap, dict) and snap:
            row['canonical_entry_snapshot_v772'] = snap
            row['entry_record_v772'] = snap
            # Keep chart reaction directly visible on the ledger row.
            reaction = snap.get('chart_line_reaction_v772') if isinstance(snap.get('chart_line_reaction_v772'), dict) else {}
            if reaction:
                row['chart_line_reaction_v772'] = reaction
                row['chart_state_tags_v772'] = reaction.get('tags') or []
        ctx = row.get('entry_context') if isinstance(row.get('entry_context'), dict) else {}
        ctx = dict(ctx)
        if isinstance(basis, dict) and basis:
            ctx['canonical_entry_basis_v772'] = basis
            ctx['entry_check_v772'] = basis
        if isinstance(snap, dict) and snap:
            ctx['canonical_entry_snapshot_v772'] = snap
            ctx['entry_record_v772'] = snap
        row['entry_context'] = ctx
        row['ledger_entry_check_probe_v772'] = {'entry_check': bool(basis), 'entry_record': bool(snap), 'source': source}
    except Exception as exc:
        try: log_error('v772_mark_entry_check', exc)
        except Exception: pass

BUILD_LABEL = 'structure_board_mainline_2026-06-10'

VERSION = 'paper_bot_v0.795'

def _v773_find_structure_route(obj: Any) -> Dict[str, Any]:
    if not isinstance(obj, dict):
        return {}
    sources = [obj]
    for k in ('entry_context','entry_diagnostics','raw','source_event'):
        v = obj.get(k)
        if isinstance(v, dict): sources.append(v)
    for src in sources:
        v = src.get('structure_first_route_v773')
        if isinstance(v, dict) and v: return v
        for sk in ('canonical_entry_snapshot_v772','entry_record_v772','canonical_entry_snapshot_v771','canonical_entry_snapshot_v764','canonical_entry_snapshot_v762','structure_snapshot_v762','canonical_entry_snapshot','entry_snapshot'):
            snap = src.get(sk)
            if isinstance(snap, dict):
                v = snap.get('structure_first_route_v773')
                if isinstance(v, dict) and v: return v
    return {}

def _v773_mark_structure_route(row: Dict[str, Any], src: Any = None, mark: str = '') -> None:
    try:
        route = _v773_find_structure_route(row) or _v773_find_structure_route(src)
        if route:
            row['structure_first_route_v773'] = route
            ctx = row.get('entry_context') if isinstance(row.get('entry_context'), dict) else {}
            ctx = dict(ctx); ctx['structure_first_route_v773'] = route; row['entry_context'] = ctx
            snap = row.get('canonical_entry_snapshot_v772') if isinstance(row.get('canonical_entry_snapshot_v772'), dict) else row.get('canonical_entry_snapshot_v764') if isinstance(row.get('canonical_entry_snapshot_v764'), dict) else row.get('canonical_entry_snapshot') if isinstance(row.get('canonical_entry_snapshot'), dict) else {}
            if isinstance(snap, dict):
                snap2 = dict(snap); snap2['structure_first_route_v773'] = route
                row['canonical_entry_snapshot_v773'] = snap2
                row['canonical_entry_snapshot'] = snap2
            row['structure_first_route_copied_v773'] = True
        row['v773_route_probe'] = {'route': bool(route), 'mark': mark}
    except Exception as exc:
        try: log_error('v773_mark_structure_route', exc)
        except Exception: pass

BUILD_LABEL = 'structure_board_mainline_2026-06-10'

VERSION = 'paper_bot_v0.795'

def _v774_find_route_applied(obj: Any) -> Dict[str, Any]:
    if not isinstance(obj, dict): return {}
    sources=[obj]
    for k in ('entry_context','entry_diagnostics','raw','source_event'):
        v=obj.get(k)
        if isinstance(v, dict): sources.append(v)
    for src in sources:
        v=src.get('structure_route_applied_v774') or src.get('structure_first_route_v774') or src.get('structure_first_route_v773')
        if isinstance(v, dict) and v: return v
        for sk in ('canonical_entry_snapshot_v772','entry_record_v772','canonical_entry_snapshot_v774','canonical_entry_snapshot_v773','canonical_entry_snapshot_v762','canonical_entry_snapshot','entry_snapshot'):
            snap=src.get(sk)
            if isinstance(snap, dict):
                v=snap.get('structure_route_applied_v774') or snap.get('structure_first_route_v774') or snap.get('structure_first_route_v773')
                if isinstance(v, dict) and v: return v
    return {}

def _v774_mark_entry_and_route(row: Dict[str, Any], src: Any = None, mark: str = '') -> None:
    try:
        if not isinstance(row, dict): return
        basis = _v764_find_basis(row) if '_v764_find_basis' in globals() else {}
        snap = _v764_find_snapshot(row) if '_v764_find_snapshot' in globals() else {}
        if not basis and isinstance(src, dict) and '_v764_find_basis' in globals(): basis = _v764_find_basis(src)
        if not snap and isinstance(src, dict) and '_v764_find_snapshot' in globals(): snap = _v764_find_snapshot(src)
        route = _v774_find_route_applied(row) or _v774_find_route_applied(src)
        if isinstance(basis, dict) and basis:
            row['canonical_entry_basis_v774'] = basis
            row['entry_check_v774'] = basis
            row['entry_check_copied_v774'] = True
        if isinstance(snap, dict) and snap:
            if route:
                snap = dict(snap); snap['structure_route_applied_v774'] = route
            row['canonical_entry_snapshot_v774'] = snap
            row['entry_record_v774'] = snap
            reaction = snap.get('chart_line_reaction_v772') if isinstance(snap.get('chart_line_reaction_v772'), dict) else {}
            if reaction:
                row['chart_line_reaction_v772'] = reaction
                row['chart_state_tags_v772'] = reaction.get('tags') or []
        if route:
            row['structure_route_applied_v774'] = route
            row['structure_first_route_v774'] = route
        ctx = row.get('entry_context') if isinstance(row.get('entry_context'), dict) else {}
        ctx = dict(ctx)
        if basis: ctx['canonical_entry_basis_v774'] = basis; ctx['entry_check_v774'] = basis
        if snap: ctx['canonical_entry_snapshot_v774'] = snap; ctx['entry_record_v774'] = snap
        if route: ctx['structure_route_applied_v774'] = route; ctx['structure_first_route_v774'] = route
        row['entry_context'] = ctx
        row['v774_entry_route_probe'] = {'entry_check': bool(basis), 'entry_record': bool(snap), 'route': bool(route), 'mark': mark}
    except Exception as exc:
        try: log_error('v774_mark_entry_and_route', exc)
        except Exception: pass

V917_EXECUTION_COST_LEDGER = FILES.get('execution_cost_ledger_v917', BASE_DIR / 'paper_execution_cost_ledger.jsonl')

V917_EXECUTION_COST_STATUS = FILES.get('execution_cost_status_v917', BASE_DIR / 'paper_execution_cost_status.json')

V917_MICRO_CACHE = BASE_DIR / 'clean_bithumb_micro_cache.json'

V917_QUOTE_FRESH_SEC = 20.0

def _v917_read_json_object(path: Path, label: str) -> Tuple[Dict[str, Any], str]:
    if not path.exists():
        return {}, 'file_missing'
    try:
        obj = json.loads(path.read_text(encoding='utf-8', errors='strict'))
        if not isinstance(obj, dict):
            raise ValueError(f'{label} root is not object')
        return obj, 'ok'
    except Exception as exc:
        log_error(f'v917_read_{label}', exc)
        return {}, 'read_error'

def _v917_micro_row(ticker: str) -> Tuple[Dict[str, Any], Dict[str, Any]]:
    cache, read_state = _v917_read_json_object(V917_MICRO_CACHE, 'micro_cache')
    if read_state != 'ok':
        return {}, {'state': read_state, 'cache_exists': V917_MICRO_CACHE.exists()}
    rows = cache.get('rows')
    t = normalize_ticker(ticker)
    row: Dict[str, Any] = {}
    if isinstance(rows, dict):
        direct = rows.get(t)
        if not isinstance(direct, dict):
            direct = rows.get(f'KRW-{t}')
        if not isinstance(direct, dict):
            direct = rows.get(f'{t}_KRW')
        if isinstance(direct, dict):
            row = direct
        else:
            for k, v in rows.items():
                if isinstance(v, dict) and normalize_ticker(v.get('ticker') or v.get('market') or v.get('symbol') or k) == t:
                    row = v
                    break
    elif isinstance(rows, list):
        for v in rows:
            if isinstance(v, dict) and normalize_ticker(v.get('ticker') or v.get('market') or v.get('symbol')) == t:
                row = v
                break
    return row, {
        'state': 'row_found' if row else 'ticker_missing',
        'cache_exists': V917_MICRO_CACHE.exists(),
        'cache_updated_ts': fnum(cache.get('updated_ts'), default=0.0),
        'cache_version': cache.get('version'),
    }

def _v917_candidate_key(ev: Dict[str, Any], pos: Dict[str, Any]) -> Tuple[str, str]:
    ev = ev if isinstance(ev, dict) else {}
    for key in ('entry_build_key','same_number_key_v896','candidate_follow_key_v896','stable_event_key_v895','candidate_follow_key_v895','stable_event_key_v894','candidate_follow_key_v894','event_id','event_key'):
        value = ev.get(key)
        if value not in (None, '', '-', [], {}):
            return str(value), key
    # paper pos_id is only a ledger dedup fallback, never an exact candidate key.
    return '', 'missing'

def _v917_execution_cost_key(pos: Dict[str, Any], candidate_key: str) -> str:
    ticker = normalize_ticker(pos.get('ticker'))
    pos_id = str(pos.get('pos_id') or pos.get('event_id') or '')
    return f'{ticker}|{candidate_key or pos_id}|{pos_id}'

def _v917_existing_execution_keys(limit: int = 5000) -> set:
    out = set()
    for row in read_jsonl_tail(V917_EXECUTION_COST_LEDGER, limit):
        if isinstance(row, dict) and row.get('execution_cost_key'):
            out.add(str(row.get('execution_cost_key')))
    return out

def _v917_write_execution_status(latest: Optional[Dict[str, Any]] = None, duplicate: bool = False) -> Dict[str, Any]:
    rows = [r for r in read_jsonl_tail(V917_EXECUTION_COST_LEDGER, 5000) if isinstance(r, dict)]
    state_counts = Counter(str(r.get('measurement_state') or 'unknown') for r in rows)
    confirmed = [fnum(r.get('signed_slippage_pct'), default=0.0) for r in rows if str(r.get('measurement_state')) == 'paper_reference_confirmed' and r.get('signed_slippage_pct') is not None]
    confirmed_cost = [fnum(r.get('cost_slippage_pct'), default=0.0) for r in rows if str(r.get('measurement_state')) == 'paper_reference_confirmed' and r.get('cost_slippage_pct') is not None]
    confirmed_sorted = sorted(confirmed)
    confirmed_cost_sorted = sorted(confirmed_cost)
    median = None
    if confirmed_sorted:
        n=len(confirmed_sorted); mid=n//2
        median = confirmed_sorted[mid] if n % 2 else (confirmed_sorted[mid-1] + confirmed_sorted[mid]) / 2.0
    median_cost = None
    if confirmed_cost_sorted:
        n_cost=len(confirmed_cost_sorted); mid_cost=n_cost//2
        median_cost = confirmed_cost_sorted[mid_cost] if n_cost % 2 else (confirmed_cost_sorted[mid_cost-1] + confirmed_cost_sorted[mid_cost]) / 2.0
    prior, _prior_state = _v917_read_json_object(V917_EXECUTION_COST_STATUS, 'execution_cost_status')
    if _prior_state == 'file_missing':
        prior = {}
    duplicate_count = int(fnum(prior.get('duplicate_skipped'), default=0.0)) + (1 if duplicate else 0)
    nowv = now_ts()
    status = {
        'schema': 'paper_execution_cost_status_v917',
        'version': VERSION,
        'build': BUILD_LABEL,
        'updated_ts': nowv,
        'updated_text': iso_ts(nowv),
        'runtime_heartbeat_ts': nowv,
        'runtime_heartbeat_text': iso_ts(nowv),
        'last_observation_ts': fnum((rows[-1] if rows else {}).get('paper_opened_at'), default=0.0) or None,
        'ledger_file': V917_EXECUTION_COST_LEDGER.name,
        'total_rows': len(rows),
        'state_counts': dict(state_counts),
        'paper_reference_confirmed': int(state_counts.get('paper_reference_confirmed', 0)),
        'stale_rows': int(state_counts.get('paper_reference_stale', 0)),
        'missing_rows': sum(v for k, v in state_counts.items() if str(k).startswith('missing_') or str(k) in {'candidate_key_missing','quote_timestamp_missing'}),
        'duplicate_skipped': duplicate_count,
        'avg_signed_slippage_pct': round(sum(confirmed)/len(confirmed), 6) if confirmed else None,
        'median_signed_slippage_pct': round(float(median), 6) if median is not None else None,
        'max_signed_slippage_pct': round(max(confirmed), 6) if confirmed else None,
        'min_signed_slippage_pct': round(min(confirmed), 6) if confirmed else None,
        'avg_cost_slippage_pct': round(sum(confirmed_cost)/len(confirmed_cost), 6) if confirmed_cost else None,
        'median_cost_slippage_pct': round(float(median_cost), 6) if median_cost is not None else None,
        'max_cost_slippage_pct': round(max(confirmed_cost), 6) if confirmed_cost else None,
        'last_row': latest if isinstance(latest, dict) else (rows[-1] if rows else None),
        'measurement_policy': 'paper OPEN reference gap only; best ask versus paper entry reference; not an exchange fill and not used by OPEN/exit criteria',
        'conditions_changed': False,
        'paper_open_changed': False,
        'exit_changed': False,
    }
    save_json(V917_EXECUTION_COST_STATUS, status)
    return status

def _v917_touch_execution_status() -> Dict[str, Any]:
    if not V917_EXECUTION_COST_STATUS.exists():
        return _v917_write_execution_status()
    status, read_state = _v917_read_json_object(V917_EXECUTION_COST_STATUS, 'execution_cost_status')
    if read_state != 'ok':
        return _v917_write_execution_status()
    nowv = now_ts()
    status['version'] = VERSION
    status['build'] = BUILD_LABEL
    status['updated_ts'] = nowv
    status['updated_text'] = iso_ts(nowv)
    status['runtime_heartbeat_ts'] = nowv
    status['runtime_heartbeat_text'] = iso_ts(nowv)
    status['measurement_policy'] = 'paper OPEN reference gap only; best ask versus paper entry reference; not an exchange fill and not used by OPEN/exit criteria'
    save_json(V917_EXECUTION_COST_STATUS, status)
    return status

def _v917_record_execution_cost(pos: Dict[str, Any], ev: Dict[str, Any]) -> Dict[str, Any]:
    ticker = normalize_ticker(pos.get('ticker') or ev.get('ticker') or ev.get('market') or ev.get('symbol'))
    nowv = fnum(pos.get('opened_at'), default=now_ts())
    micro, cache_meta = _v917_micro_row(ticker)
    best_bid = fnum(micro.get('best_bid'), default=0.0)
    best_ask = fnum(micro.get('best_ask'), default=0.0)
    quote_ts_source = 'row.ts'
    quote_ts = fnum(micro.get('ts'), default=0.0)
    if quote_ts <= 0:
        quote_ts_source = 'row.updated_ts'
        quote_ts = fnum(micro.get('updated_ts'), default=0.0)
    if quote_ts <= 0:
        quote_ts_source = 'cache.updated_ts'
        quote_ts = fnum(cache_meta.get('cache_updated_ts'), default=0.0)
    quote_age = max(0.0, nowv - quote_ts) if quote_ts > 0 else None
    fill_ref = fnum(pos.get('entry_price'), default=0.0)
    candidate_key, candidate_key_source = _v917_candidate_key(ev, pos)
    execution_key = _v917_execution_cost_key(pos, candidate_key)
    spread_pct = None
    if best_bid > 0 and best_ask >= best_bid:
        mid=(best_bid+best_ask)/2.0
        if mid > 0:
            spread_pct=((best_ask-best_bid)/mid)*100.0
    if spread_pct is None:
        raw_spread = micro.get('micro_spread_pct')
        if raw_spread not in (None, '', '-'):
            spread_pct=fnum(raw_spread, default=0.0)
    signed = ((fill_ref-best_ask)/best_ask*100.0) if best_ask > 0 and fill_ref > 0 else None
    cost = max(0.0, signed) if signed is not None else None
    improvement = max(0.0, -signed) if signed is not None else None
    if best_ask <= 0:
        state='missing_expected_best_ask'
    elif fill_ref <= 0:
        state='missing_paper_entry_reference'
    elif quote_ts <= 0:
        state='quote_timestamp_missing'
    elif not candidate_key:
        state='candidate_key_missing'
    elif quote_age is not None and quote_age > V917_QUOTE_FRESH_SEC:
        state='paper_reference_stale'
    else:
        state='paper_reference_confirmed'
    row = {
        'schema': 'paper_execution_cost_observation_v917',
        'version': VERSION,
        'build': BUILD_LABEL,
        'execution_cost_key': execution_key,
        'ticker': ticker,
        'pos_id': pos.get('pos_id'),
        'event_id': pos.get('event_id'),
        'candidate_entry_build_key': candidate_key,
        'candidate_entry_build_key_source': candidate_key_source,
        'good_s2_occurrence_key_v923': ev.get('good_s2_occurrence_key_v923') or pos.get('good_s2_occurrence_key_v923'),
        'good_s2_state_key_v923': ev.get('good_s2_state_key_v923') or pos.get('good_s2_state_key_v923'),
        'paper_score_patch_version': pos.get('score_patch_version'),
        'paper_opened_at': nowv,
        'paper_opened_at_text': pos.get('opened_at_text') or iso_ts(nowv),
        'expected_buy_price': best_ask if best_ask > 0 else None,
        'expected_buy_price_source': 'clean_bithumb_micro_cache.best_ask' if best_ask > 0 else 'missing',
        'best_bid': best_bid if best_bid > 0 else None,
        'best_ask': best_ask if best_ask > 0 else None,
        'paper_fill_reference_price': fill_ref if fill_ref > 0 else None,
        'paper_fill_reference_source': 'paper_open.entry_price',
        'signed_slippage_pct': round(signed, 6) if signed is not None else None,
        'cost_slippage_pct': round(cost, 6) if cost is not None else None,
        'price_improvement_pct': round(improvement, 6) if improvement is not None else None,
        'spread_pct': round(spread_pct, 6) if spread_pct is not None else None,
        'quote_ts': quote_ts if quote_ts > 0 else None,
        'quote_ts_source': quote_ts_source if quote_ts > 0 else 'missing',
        'quote_age_sec': round(quote_age, 3) if quote_age is not None else None,
        'quote_fresh_limit_sec': V917_QUOTE_FRESH_SEC,
        'micro_cache_state': cache_meta.get('state'),
        'micro_cache_version': cache_meta.get('cache_version'),
        'measurement_state': state,
        'measurement_type': 'paper_reference_gap',
        'exchange_confirmed': False,
        'used_for_entry_gate': False,
        'used_for_exit': False,
        'policy': 'observation only; do not treat as exchange average fill slippage',
    }
    if execution_key in _v917_existing_execution_keys():
        row['duplicate_skipped'] = True
        _v917_write_execution_status(None, duplicate=True)
        return row
    append_jsonl(V917_EXECUTION_COST_LEDGER, row)
    _v917_write_execution_status(row, duplicate=False)
    return row

def _v923_candidate_result_link_fields(ev: Dict[str, Any]) -> Dict[str, Any]:
    """Preserve candidate-owned exact evidence without changing paper version keys.

    paper entry_build_key remains the OPEN-time score patch owner. Candidate event
    identity and good-S2 occurrence are stored under explicit candidate fields so
    review can join OPEN/CLOSED without ticker fallback.
    """
    src = ev if isinstance(ev, dict) else {}
    exact = src.get('entry_build_key') or src.get('candidate_entry_build_key') or src.get('event_id') or src.get('event_key')
    stable = src.get('stable_event_key_v896') or src.get('candidate_follow_key_v896') or src.get('stable_event_key_v895') or src.get('candidate_follow_key_v895') or src.get('stable_event_key_v894') or src.get('candidate_follow_key_v894')
    occurrence = src.get('good_s2_occurrence_key_v923')
    out = {
        'candidate_entry_build_key_v923': exact,
        'candidate_stable_key_v923': stable,
        'good_s2_occurrence_key_v923': occurrence,
        'good_s2_state_key_v923': src.get('good_s2_state_key_v923'),
        'good_s2_started_ts_v923': src.get('good_s2_started_ts_v923'),
        'good_s2_last_good_ts_v923': src.get('good_s2_last_good_ts_v923'),
        'good_s2_lifecycle_transition_v923': src.get('good_s2_lifecycle_transition_v923'),
        'good_s2_result_link_ready_v923': bool(occurrence),
        'good_s2_result_link_owner_v923': 'paper_open_preserves_strategy_occurrence',
        'good_s2_result_link_policy_v923': 'exact occurrence/candidate evidence only; ticker is audit-only',
    }
    return {k: v for k, v in out.items() if v not in (None, '', '-', [], {}) or k == 'good_s2_result_link_ready_v923'}

def _v930_compact_open_row(pos: Dict[str, Any], ev: Dict[str, Any]) -> Dict[str, Any]:
    """Remove duplicate source blobs only; execution, gate and ledger evidence stay top-level."""
    if not isinstance(pos, dict):
        return pos
    before = len(_v930_json_bytes(pos))
    src = ev if isinstance(ev, dict) else {}
    source_digest = _v930_digest(src)
    compact = _v930_compact_candidate_evidence(src)
    removed: List[str] = []
    pos['raw'] = compact
    removed.append('raw_full_candidate')
    # These historical aliases sometimes contain the exact same candidate object.
    for key in ('candidate_row', 'source_event', 'source_row', '_source_row'):
        val = pos.get(key)
        if isinstance(val, (dict, list)) and _v930_digest(val) == source_digest:
            pos.pop(key, None)
            removed.append(key)
    # Drop only nested full-source copies. Other context fields remain untouched for readers.
    for parent in ('entry_context', 'entry_diagnostics'):
        obj = pos.get(parent)
        if not isinstance(obj, dict):
            continue
        obj2 = dict(obj)
        changed = False
        for key in ('raw', 'candidate_row', 'source_event', 'source_row', '_source_row'):
            val = obj2.get(key)
            if isinstance(val, (dict, list)) and len(_v930_json_bytes(val)) > 4096:
                obj2.pop(key, None)
                removed.append(f'{parent}.{key}')
                changed = True
        if changed:
            pos[parent] = obj2
    after_without_meta = len(_v930_json_bytes(pos))
    pos['paper_open_payload_v930'] = {
        'schema':'paper_open_payload_v930_compact',
        'version':VERSION,
        'build':BUILD_LABEL,
        'source_sha256':source_digest,
        'before_bytes':before,
        'after_bytes_before_meta':after_without_meta,
        'saved_bytes_before_meta':max(0, before-after_without_meta),
        'removed_paths':removed[:16],
        'raw_payload_full_stored':False,
        'entry_context_preserved':True,
        'policy':'remove duplicate full candidate/source blobs only; exact decision/trigger/invalid/target/RR and OPEN/CLOSED semantics unchanged',
    }
    pos['paper_open_payload_v930']['final_bytes'] = len(_v930_json_bytes(pos))
    return pos

def _v930_compact_existing_open_rows(open_pos: Dict[str, Dict[str, Any]]) -> int:
    changed = 0
    if not isinstance(open_pos, dict):
        return 0
    for pid, row in list(open_pos.items()):
        if not isinstance(row, dict):
            continue
        meta = row.get('paper_open_payload_v930') if isinstance(row.get('paper_open_payload_v930'), dict) else {}
        raw = row.get('raw') if isinstance(row.get('raw'), dict) else {}
        if meta.get('schema') == 'paper_open_payload_v930_compact' and raw.get('schema') == 'paper_candidate_evidence_v930_compact':
            continue
        source = raw if raw and raw.get('schema') != 'paper_candidate_evidence_v930_compact' else row
        before = len(_v930_json_bytes(row))
        compacted = _v930_compact_open_row(dict(row), source if isinstance(source, dict) else {})
        after = len(_v930_json_bytes(compacted))
        if after < before or compacted.get('paper_open_payload_v930'):
            open_pos[pid] = compacted
            changed += 1
    return changed

def _v783_file_size(path: Path) -> int:
    try:
        return int(path.stat().st_size)
    except Exception:
        return 0

def _v783_protected_names() -> set:
    names = {
        'paper_bot_open.json', 'paper_bot_closed.jsonl', 'paper_bot_trade_log.jsonl',
        'paper_bot_open_positions.json', 'paper_bot_status.json', 'paper_bot_score_cache.json',
        'paper_bot_review_cache.json', 'paper_bot_classify_cache.json',
        'paper_execution_cost_ledger.jsonl', 'paper_execution_cost_status.json',
        'paper_decision_state_v926.json', 'paper_decision_status_v926.json', 'paper_decision_events_v926.jsonl',
        'paper_timing_spine_status_v940.json', 'paper_timing_spine_events_v940.jsonl',
        'paper_closed_append_status_v925.json', 'paper_closed_append_events_v925.jsonl',
        'DEPLOY_TARGET.txt', 'DEPLOY_BUNDLE.json', 'bot.py', 'paper_bot.py',
    }
    try:
        dep = (BASE_DIR / 'DEPLOY_TARGET.txt').read_text(encoding='utf-8', errors='ignore').strip()
        if dep: names.add(Path(dep).name)
    except Exception:
        pass
    names.add(Path(__file__).name)
    names.add('paper_bot.py')
    names.add('paper_bot_v0.931.py')
    names.add('strategy_worker_v0.801.py')
    names.add('coinbot_main_v2_13_806.py')
    return names

def _v783_delete_file(path: Path, res: Dict[str, Any], reason: str) -> None:
    try:
        if not path.exists() or not path.is_file():
            return
        if path.name in _v783_protected_names():
            res['preserved'] += 1
            return
        sz = _v783_file_size(path)
        path.unlink(missing_ok=True)
        res['deleted_files'] += 1
        res['deleted_bytes'] += sz
        res.setdefault('by_reason', {}).setdefault(reason, {'files': 0, 'bytes': 0})
        res['by_reason'][reason]['files'] += 1
        res['by_reason'][reason]['bytes'] += sz
    except Exception as exc:
        res['errors'] += 1
        res.setdefault('error_sample', []).append(f'{path.name}: {type(exc).__name__}')
        try: log_error('v783_cleanup_delete_file', exc)
        except Exception: pass

def _v783_remove_old_glob(pattern: str, max_age_sec: float, res: Dict[str, Any], reason: str, keep_newest: int = 0) -> None:
    try:
        nowv = now_ts()
        files = [p for p in BASE_DIR.glob(pattern) if p.is_file()]
        files.sort(key=lambda p: p.stat().st_mtime if p.exists() else 0, reverse=True)
        keep = set(files[:max(0, int(keep_newest))])
        for path in files:
            res['checked_files'] += 1
            if path in keep or path.name in _v783_protected_names():
                res['preserved'] += 1
                continue
            try:
                if nowv - path.stat().st_mtime >= max_age_sec:
                    _v783_delete_file(path, res, reason)
            except Exception as exc:
                res['errors'] += 1
                res.setdefault('error_sample', []).append(f'{path.name}: {type(exc).__name__}')
    except Exception as exc:
        res['errors'] += 1
        try: log_error('v783_remove_old_glob', exc)
        except Exception: pass

def _v783_remove_pycache(res: Dict[str, Any]) -> None:
    try:
        nowv = now_ts(); max_age = 24 * 3600.0
        for d in BASE_DIR.rglob('__pycache__'):
            if not d.is_dir():
                continue
            try:
                newest = max((p.stat().st_mtime for p in d.rglob('*') if p.exists()), default=0)
                if newest and nowv - newest < max_age:
                    res['preserved'] += 1
                    continue
                total = sum(_v783_file_size(p) for p in d.rglob('*') if p.is_file())
                for p in sorted(d.rglob('*'), reverse=True):
                    try:
                        if p.is_file(): p.unlink(missing_ok=True)
                        elif p.is_dir(): p.rmdir()
                    except Exception:
                        pass
                try: d.rmdir()
                except Exception: pass
                res['deleted_files'] += 1
                res['deleted_bytes'] += total
                res.setdefault('by_reason', {}).setdefault('__pycache__', {'files': 0, 'bytes': 0})
                res['by_reason']['__pycache__']['files'] += 1
                res['by_reason']['__pycache__']['bytes'] += total
            except Exception as exc:
                res['errors'] += 1
                res.setdefault('error_sample', []).append(f'{d.name}: {type(exc).__name__}')
    except Exception as exc:
        res['errors'] += 1
        try: log_error('v783_remove_pycache', exc)
        except Exception: pass

def _v783_large_file_top(limit: int = 8) -> List[Dict[str, Any]]:
    out: List[Dict[str, Any]] = []
    protected = _v783_protected_names()
    try:
        for p in BASE_DIR.iterdir():
            try:
                if not p.is_file() or p.name in protected:
                    continue
                sz = _v783_file_size(p)
                if sz < 5 * 1024 * 1024:
                    continue
                out.append({'name': p.name, 'mb': round(sz / 1024 / 1024, 2), 'age_sec': round(max(0.0, now_ts() - p.stat().st_mtime), 1)})
            except Exception:
                pass
    except Exception:
        pass
    out.sort(key=lambda x: float(x.get('mb') or 0.0), reverse=True)
    return out[:limit]

def _v678_runtime_cleanup__L18413(ctrl: Dict[str, Any], status: Dict[str, Any]) -> Dict[str, Any]:  # type: ignore[override]
    cleanup = _v783_prev_runtime_cleanup(ctrl, status)
    if not isinstance(cleanup, dict):
        cleanup = {}
    res: Dict[str, Any] = {
        'schema': 'paper_runtime_cleanup_v783_broad_rotation',
        'version': VERSION,
        'build': BUILD_LABEL,
        'updated_at': now_ts(),
        'updated_at_text': iso_ts() if 'iso_ts' in globals() else now_text(),
        'checked_files': 0,
        'deleted_files': 0,
        'deleted_bytes': 0,
        'preserved': 0,
        'errors': 0,
        'by_reason': {},
        'policy': 'Preserve OPEN/CLOSED/trade_log/core score. Rotate old zips/backups/debug/cache/snapshot/log/temp/__pycache__.',
    }
    try:
        # Keep current and a few recent deploy artifacts; remove stale build clutter.
        one_day = 24 * 3600.0
        two_days = 2 * 24 * 3600.0
        three_days = 3 * 24 * 3600.0
        seven_days = 7 * 24 * 3600.0
        for pat in ('coinbot_update_v*.zip', '코인봇_*묶음*.zip', '코인봇_인수인계_*묶음*.zip'):
            _v783_remove_old_glob(pat, one_day, res, 'old_update_zip', keep_newest=4)
        for pat in ('coinbot_main_v2_13_*.py', '수익형_v*.py', 'strategy_worker_v0.*.py', 'paper_bot_v0.*.py'):
            _v783_remove_old_glob(pat, two_days, res, 'old_bot_versions', keep_newest=4)
        for pat in ('*.backup*', '*.bak', 'bot.py.backup*', '*_backup_*', '*old*.py'):
            _v783_remove_old_glob(pat, two_days, res, 'old_backup', keep_newest=2)
        for pat in ('*_tmp*', '*.tmp', '*.v678tmp', '*debug*.json', '*debug*.jsonl', '*snapshot*.json', '*trace*.jsonl', '*trace*.log', 'clean_*_cache_*.json', 'clean_*_snapshot_*.json'):
            _v783_remove_old_glob(pat, three_days, res, 'stale_debug_cache_trace', keep_newest=2)
        for pat in ('*.log', '*error*.log'):
            _v783_remove_old_glob(pat, seven_days, res, 'old_logs', keep_newest=2)
        _v783_remove_pycache(res)
        res['deleted_mb'] = round(float(res.get('deleted_bytes') or 0) / 1024 / 1024, 2)
        res['large_file_top_outside_target'] = _v783_large_file_top(8)
        cleanup['broad_rotation_v783'] = res
        cleanup['deleted_files_v783'] = int(res.get('deleted_files') or 0)
        cleanup['deleted_mb_v783'] = res.get('deleted_mb')
        cleanup['preserved_files_v783'] = int(res.get('preserved') or 0)
        cleanup['errors_v783'] = int(res.get('errors') or 0)
        cleanup['policy_v783'] = res.get('policy')
        cleanup['ok'] = bool(cleanup.get('ok', True)) and int(res.get('errors') or 0) == 0
        save_json(FILES['cleanup_state'], cleanup)
    except Exception as exc:
        cleanup['ok'] = False
        cleanup['error_v783'] = f'{type(exc).__name__}: {exc}'
        try: log_error('v783_runtime_cleanup', exc)
        except Exception: pass
    return cleanup

_V798_SHORT_CACHE_PATTERNS = (
    ('paper_bot_trade_detail_v*.jsonl', 24 * 3600.0, 'paper_trade_detail_short_retention', 2),
    ('paper_bot_trade_detail_cache_v*.json', 24 * 3600.0, 'paper_trade_detail_short_retention', 2),
    ('coinbot_batch_summary_marker_v*.json', 7 * 24 * 3600.0, 'old_batch_markers', 2),
    ('coinbot_batch_summary_*.txt', 6 * 3600.0, 'leftover_batch_summary_txt', 0),
    ('clean_candidate_reason*_cache*.json', 2 * 24 * 3600.0, 'candidate_reason_cache_short_retention', 1),
    ('clean_recheck_candidates*_cache*.json', 2 * 24 * 3600.0, 'recheck_cache_short_retention', 1),
    ('clean_recheck_candidates*_state*.json', 2 * 24 * 3600.0, 'recheck_state_short_retention', 1),
    ('clean_*review*_cache*.json', 2 * 24 * 3600.0, 'review_cache_short_retention', 1),
    ('clean_*reason*_compact*.json', 2 * 24 * 3600.0, 'compact_reason_cache_short_retention', 1),
    ('*_detail_cache*.json', 2 * 24 * 3600.0, 'detail_cache_short_retention', 1),
    ('*_detail_*.jsonl', 2 * 24 * 3600.0, 'detail_jsonl_short_retention', 1),
)

def _v798_short_cache_rotation(cleanup: Dict[str, Any]) -> Dict[str, Any]:
    res: Dict[str, Any] = {
        'schema': 'paper_runtime_cleanup_v798_short_cache_rotation',
        'version': VERSION,
        'build': BUILD_LABEL,
        'updated_at': now_ts(),
        'updated_at_text': iso_ts() if 'iso_ts' in globals() else now_text(),
        'checked_files': 0,
        'deleted_files': 0,
        'deleted_bytes': 0,
        'preserved': 0,
        'errors': 0,
        'by_reason': {},
        'policy': '핵심 OPEN/CLOSED/trade_log/score는 보존. paper 구조계획 상세, batch 임시 txt, candidate/recheck/review/detail 임시 cache는 1~2일 짧은 순환삭제.',
        'protected_policy': '삭제 금지: paper_bot_open.json, paper_bot_closed.jsonl, paper_bot_trade_log.jsonl, paper_bot_score_cache.json, active bot/paper/main/worker.',
    }
    try:
        for pat, max_age, reason, keep in _V798_SHORT_CACHE_PATTERNS:
            _v783_remove_old_glob(pat, float(max_age), res, str(reason), keep_newest=int(keep))
        res['deleted_mb'] = round(float(res.get('deleted_bytes') or 0) / 1024 / 1024, 2)
        res['large_file_top_outside_target'] = _v783_large_file_top(8)
    except Exception as exc:
        res['errors'] = int(res.get('errors') or 0) + 1
        res.setdefault('error_sample', []).append(f'v798_short_rotation: {type(exc).__name__}')
        try: log_error('v798_short_cache_rotation', exc)
        except Exception: pass
    cleanup['short_rotation_v798'] = res
    cleanup['deleted_files_v798'] = int(res.get('deleted_files') or 0)
    cleanup['deleted_mb_v798'] = res.get('deleted_mb')
    cleanup['preserved_files_v798'] = int(res.get('preserved') or 0)
    cleanup['errors_v798'] = int(res.get('errors') or 0)
    cleanup['policy_v798'] = res.get('policy')
    cleanup['ok'] = bool(cleanup.get('ok', True)) and int(res.get('errors') or 0) == 0
    return cleanup

def _v678_runtime_cleanup__L18524(ctrl: Dict[str, Any], status: Dict[str, Any]) -> Dict[str, Any]:  # type: ignore[override]
    cleanup = _v798_prev_runtime_cleanup(ctrl, status)
    if not isinstance(cleanup, dict):
        cleanup = {}
    try:
        cleanup = _v798_short_cache_rotation(cleanup)
        save_json(FILES['cleanup_state'], cleanup)
    except Exception as exc:
        cleanup['ok'] = False
        cleanup['error_v798'] = f'{type(exc).__name__}: {exc}'
        try: log_error('v798_runtime_cleanup', exc)
        except Exception: pass
    return cleanup

VERSION = 'paper_bot_v0.795'

BUILD_LABEL = 'structure_board_mainline_2026-06-10'

VERSION = 'paper_bot_v0.795'

BUILD_LABEL = 'structure_board_mainline_2026-06-10'

def _v811_confirm_strong_but_no_followthrough(row: Dict[str, Any]) -> bool:
    if not isinstance(row, dict) or str(row.get('kind') or '').lower() != 'closed':
        return False
    checks = row.get('entry_checks_v800') if isinstance(row.get('entry_checks_v800'), dict) else (_v800_entry_checks(row) if '_v800_entry_checks' in globals() else {})
    react = fnum(checks.get('price_reaction_pct'), default=0.0)
    buy = fnum(checks.get('buy_ratio'), default=0.0)
    sus = fnum(checks.get('buy_sustain_1m'), default=0.0)
    peak = fnum(row.get('peak_pct'), row.get('gross_peak_pct'), default=0.0)
    pnl = fnum(row.get('pnl_pct'), default=0.0)
    # Review tag only: strong entry confirmations, but no post-entry upside.
    return bool(react >= 0.35 and buy >= 0.70 and sus >= 0.70 and peak < 0.10 and pnl < 0.0)

def _v797_trade_detail_record__L18865(kind: str, row: Dict[str, Any], message_text: str = '') -> Dict[str, Any]:  # type: ignore[override]
    rec = _v811_base_trade_detail_record(kind, row, message_text) if callable(_v811_base_trade_detail_record) else dict(row or {})
    try:
        if str(kind).lower() == 'closed' and _v811_confirm_strong_but_no_followthrough(dict(rec, kind='closed')):
            flags = list(rec.get('quality_flags_v800') or [])
            for tag in ('confirm_strong_but_no_followthrough_v811', '강한확인값 후속실패'):
                if tag not in flags:
                    flags.append(tag)
            rec['quality_flags_v800'] = flags[:10]
            rec['quality_label_v811'] = '강한확인값 후속실패'
            rec['confirm_strong_but_no_followthrough_v811'] = True
            rec['v811_review_only_tag'] = True
            rec['v811_review_policy'] = '복기 태그 전용. S1/S2/S3/청산/자동매수 조건 변경 없음.'
    except Exception as exc:
        log_error('v811_trade_detail_no_followthrough_tag', exc)
    return rec

VERSION = 'paper_bot_v0.796'

BUILD_LABEL = 'ledger_disk_rotation_cleanup_v835_2026-06-11'

def _v835_cleanup_protected_names() -> set:
    names = set()
    try:
        names.update(_v783_protected_names() if '_v783_protected_names' in globals() else set())
    except Exception:
        pass
    names.update({
        'paper_bot_open.json', 'paper_bot_closed.jsonl', 'paper_bot_trade_log.jsonl',
        'paper_bot_open_positions.json', 'paper_bot_status.json', 'paper_bot_score_cache.json',
        'paper_bot_review_cache.json', 'paper_bot_classify_cache.json',
        'paper_candidates_latest.jsonl', 'paper_candidates.jsonl',
        'clean_candidate_latest_snapshot.json', 'clean_strategy_worker_status.json',
        'DEPLOY_TARGET.txt', 'DEPLOY_BUNDLE.json', 'bot.py', 'paper_bot.py', 'strategy_worker.py',
    })
    try:
        dep = (BASE_DIR / 'DEPLOY_TARGET.txt').read_text(encoding='utf-8', errors='ignore').strip()
        if dep:
            names.add(Path(dep).name)
    except Exception:
        pass
    names.add('paper_bot_v0.796.py')
    return names

def _v835_size(path: Path) -> int:
    try:
        return int(path.stat().st_size)
    except Exception:
        return 0

def _v835_record_reason(res: Dict[str, Any], reason: str, files: int, bytes_count: int) -> None:
    try:
        d = res.setdefault('by_reason', {}).setdefault(str(reason), {'files': 0, 'bytes': 0})
        d['files'] = int(d.get('files') or 0) + int(files or 0)
        d['bytes'] = int(d.get('bytes') or 0) + int(bytes_count or 0)
    except Exception:
        pass

def _v835_trim_large_text_file(path: Path, res: Dict[str, Any], reason: str, max_mb: float, keep_tail_mb: float) -> None:
    try:
        if not path.exists() or not path.is_file():
            return
        res['checked_files'] = int(res.get('checked_files') or 0) + 1
        if path.name in _v835_cleanup_protected_names():
            res['preserved'] = int(res.get('preserved') or 0) + 1
            return
        size = _v835_size(path)
        max_bytes = int(max_mb * 1024 * 1024)
        keep_bytes = int(keep_tail_mb * 1024 * 1024)
        if size <= max_bytes or keep_bytes <= 0:
            res['preserved'] = int(res.get('preserved') or 0) + 1
            return
        with path.open('rb') as f:
            try:
                f.seek(max(0, size - keep_bytes))
            except Exception:
                pass
            tail = f.read(keep_bytes)
        header = (f"[v835 log compacted at {iso_ts() if 'iso_ts' in globals() else now_text()}] original_bytes={size} kept_tail_bytes={len(tail)} policy=core ledger preserved\n").encode('utf-8', errors='ignore')
        tmp = path.with_suffix(path.suffix + '.v835tmp')
        tmp.write_bytes(header + tail)
        os.replace(tmp, path)
        trimmed = max(0, size - len(header) - len(tail))
        res['trimmed_files'] = int(res.get('trimmed_files') or 0) + 1
        res['trimmed_bytes'] = int(res.get('trimmed_bytes') or 0) + trimmed
        _v835_record_reason(res, reason, 1, trimmed)
    except Exception as exc:
        res['errors'] = int(res.get('errors') or 0) + 1
        res.setdefault('error_sample', []).append(f'{path.name}: {type(exc).__name__}')
        try: log_error('v835_trim_large_text_file', exc)
        except Exception: pass

def _v835_delete_old_files(pattern: str, max_age_sec: float, res: Dict[str, Any], reason: str, keep_newest: int = 0) -> None:
    try:
        nowv = now_ts()
        files = [p for p in BASE_DIR.glob(pattern) if p.is_file()]
        files.sort(key=lambda p: p.stat().st_mtime if p.exists() else 0, reverse=True)
        keep = set(files[:max(0, int(keep_newest))])
        protected = _v835_cleanup_protected_names()
        for path in files:
            try:
                res['checked_files'] = int(res.get('checked_files') or 0) + 1
                if path in keep or path.name in protected:
                    res['preserved'] = int(res.get('preserved') or 0) + 1
                    continue
                age = nowv - path.stat().st_mtime
                if age < max_age_sec:
                    res['preserved'] = int(res.get('preserved') or 0) + 1
                    continue
                sz = _v835_size(path)
                path.unlink(missing_ok=True)
                res['deleted_files'] = int(res.get('deleted_files') or 0) + 1
                res['deleted_bytes'] = int(res.get('deleted_bytes') or 0) + sz
                _v835_record_reason(res, reason, 1, sz)
            except Exception as exc:
                res['errors'] = int(res.get('errors') or 0) + 1
                res.setdefault('error_sample', []).append(f'{path.name}: {type(exc).__name__}')
    except Exception as exc:
        res['errors'] = int(res.get('errors') or 0) + 1
        try: log_error('v835_delete_old_files', exc)
        except Exception: pass

def _v835_prune_jsonl(path: Path, max_age_sec: float, max_lines: int, res: Dict[str, Any], reason: str) -> None:
    try:
        before_size = _v835_size(path)
        if '_v678_jsonl_prune' in globals():
            out = _v678_jsonl_prune(path, max_age_sec, max_lines)
        else:
            out = {'exists': False, 'removed': 0, 'ok': True}
        if not out.get('exists'):
            return
        res['checked_files'] = int(res.get('checked_files') or 0) + 1
        removed = int(out.get('removed') or 0)
        after_size = _v835_size(path)
        trimmed = max(0, before_size - after_size)
        if removed > 0 or trimmed > 0:
            res['pruned_jsonl_files'] = int(res.get('pruned_jsonl_files') or 0) + 1
            res['jsonl_removed_lines'] = int(res.get('jsonl_removed_lines') or 0) + removed
            res['trimmed_bytes'] = int(res.get('trimmed_bytes') or 0) + trimmed
            _v835_record_reason(res, reason, 1, trimmed)
        else:
            res['preserved'] = int(res.get('preserved') or 0) + 1
        if out.get('ok') is False:
            res['errors'] = int(res.get('errors') or 0) + 1
            res.setdefault('error_sample', []).append(f'{path.name}: prune_not_ok')
    except Exception as exc:
        res['errors'] = int(res.get('errors') or 0) + 1
        res.setdefault('error_sample', []).append(f'{path.name}: {type(exc).__name__}')
        try: log_error('v835_prune_jsonl', exc)
        except Exception: pass

def _v835_large_file_top(limit: int = 8) -> List[Dict[str, Any]]:
    out: List[Dict[str, Any]] = []
    protected = _v835_cleanup_protected_names()
    try:
        for p in BASE_DIR.iterdir():
            try:
                if not p.is_file():
                    continue
                sz = _v835_size(p)
                if sz < 5 * 1024 * 1024:
                    continue
                out.append({'name': p.name, 'mb': round(sz / 1024 / 1024, 2), 'age_sec': round(max(0.0, now_ts() - p.stat().st_mtime), 1), 'protected': p.name in protected})
            except Exception:
                pass
    except Exception:
        pass
    out.sort(key=lambda x: float(x.get('mb') or 0.0), reverse=True)
    return out[:limit]

def _v835_ledger_disk_rotation(cleanup: Dict[str, Any], status: Dict[str, Any]) -> Dict[str, Any]:
    res: Dict[str, Any] = {
        'schema': 'paper_runtime_cleanup_v835_ledger_disk_rotation',
        'version': VERSION,
        'build': BUILD_LABEL,
        'updated_at': now_ts(),
        'updated_at_text': iso_ts() if 'iso_ts' in globals() else now_text(),
        'checked_files': 0,
        'deleted_files': 0,
        'deleted_bytes': 0,
        'trimmed_files': 0,
        'trimmed_bytes': 0,
        'pruned_jsonl_files': 0,
        'jsonl_removed_lines': 0,
        'preserved': 0,
        'errors': 0,
        'open_kept': int(status.get('open_count') or status.get('open_total') or 0) if isinstance(status, dict) else 0,
        'check_kept': 0,
        'done_archived': 0,
        'sample_compacted': 0,
        'by_reason': {},
        'policy': 'OPEN/CLOSED/trade_log/score/current OPEN trace preserved. DONE/old samples/temp txt/debug detail/log tails are rotated.',
    }
    try:
        # 1) left-over Telegram txt and old generated summaries.
        _v835_delete_old_files('coinbot_batch_summary_*.txt', 30 * 60.0, res, 'leftover_batch_summary_txt', keep_newest=1)
        _v835_delete_old_files('paper_hourly_raw_pack_*.txt', 10 * 60.0, res, 'leftover_raw_pack_txt', keep_newest=0)
        _v835_delete_old_files('paper_hourly_summary_tmp*.txt', 10 * 60.0, res, 'leftover_hourly_summary_txt', keep_newest=0)
        # 2) old detail/debug caches and issue/review ledger byproducts, but preserve core ledger.
        for pat, age, reason, keep in (
            ('*_issue_ledger*.json', 3 * 24 * 3600.0, 'old_issue_ledger_cache', 2),
            ('*_ledger_backlog*.json', 3 * 24 * 3600.0, 'old_ledger_backlog_cache', 2),
            ('*_review_detail*.json', 2 * 24 * 3600.0, 'old_review_detail_cache', 2),
            ('*_quality_detail*.json', 2 * 24 * 3600.0, 'old_quality_detail_cache', 2),
            ('*_missed_detail*.json', 2 * 24 * 3600.0, 'old_missed_detail_cache', 2),
            ('*_tmp*.json', 12 * 3600.0, 'old_tmp_json', 1),
            ('*.v835tmp', 5 * 60.0, 'leftover_tmp_write', 0),
            ('*.v678tmp', 5 * 60.0, 'leftover_tmp_write', 0),
        ):
            _v835_delete_old_files(pat, float(age), res, reason, keep_newest=int(keep))
        # 3) prune trace/sample jsonl. Core CLOSED/trade_log are not in this list.
        trace_targets = [
            (BASE_DIR / 'paper_preopen_miss_review_trace.jsonl', 2 * 24 * 3600.0, 2400, 'preopen_review_trace_tail'),
            (BASE_DIR / 'paper_preopen_miss_review_trace_v810.jsonl', 2 * 24 * 3600.0, 1000, 'preopen_review_trace_legacy_tail'),
            (BASE_DIR / 'paper_bot_stop_overrun_trace.jsonl', 7 * 24 * 3600.0, 600, 'stop_overrun_trace_tail'),
            (BASE_DIR / 'paper_bot_hourly_raw_event_trace.jsonl', 6 * 3600.0, 1200, 'hourly_raw_event_trace_tail'),
            (BASE_DIR / 'paper_bot_open_alert_trace.jsonl', 24 * 3600.0, 700, 'open_alert_trace_tail'),
            (BASE_DIR / 'paper_bot_close_alert_trace.jsonl', 24 * 3600.0, 700, 'close_alert_trace_tail'),
        ]
        for path, age, lines, reason in trace_targets:
            _v835_prune_jsonl(path, float(age), int(lines), res, reason)
        # 4) compact large logs instead of keeping them unbounded.
        max_log_mb = max(80.0, fnum(os.getenv('PAPER_LOG_COMPACT_MAX_MB'), default=160.0))
        keep_tail_mb = max(2.0, fnum(os.getenv('PAPER_LOG_COMPACT_KEEP_MB'), default=6.0))
        for pat in ('*.log', '*error*.log'):
            for path in BASE_DIR.glob(pat):
                _v835_trim_large_text_file(path, res, 'large_log_tail_compact', max_log_mb, keep_tail_mb)
        # 5) old pycache is already handled by v783; run once more in case it was created after.
        try:
            if '_v783_remove_pycache' in globals():
                _v783_remove_pycache(res)
        except Exception:
            pass
        res['deleted_mb'] = round(float(res.get('deleted_bytes') or 0) / 1024 / 1024, 2)
        res['trimmed_mb'] = round(float(res.get('trimmed_bytes') or 0) / 1024 / 1024, 2)
        res['sample_compacted'] = int(res.get('jsonl_removed_lines') or 0)
        res['large_file_top_outside_target'] = _v835_large_file_top(8)
        cleanup['ledger_disk_rotation_v835'] = res
        cleanup['deleted_files_v835'] = int(res.get('deleted_files') or 0) + int(res.get('pruned_jsonl_files') or 0) + int(res.get('trimmed_files') or 0)
        cleanup['deleted_mb_v835'] = round(float(res.get('deleted_mb') or 0.0) + float(res.get('trimmed_mb') or 0.0), 2)
        cleanup['preserved_files_v835'] = int(res.get('preserved') or 0)
        cleanup['errors_v835'] = int(res.get('errors') or 0)
        cleanup['policy_v835'] = res.get('policy')
        cleanup['ok'] = bool(cleanup.get('ok', True)) and int(res.get('errors') or 0) == 0
    except Exception as exc:
        cleanup['ok'] = False
        cleanup['error_v835'] = f'{type(exc).__name__}: {exc}'
        try: log_error('v835_ledger_disk_rotation', exc)
        except Exception: pass
    return cleanup

def _v678_runtime_cleanup__L19140(ctrl: Dict[str, Any], status: Dict[str, Any]) -> Dict[str, Any]:  # type: ignore[override]
    cleanup = _v835_prev_runtime_cleanup(ctrl, status)
    if not isinstance(cleanup, dict):
        cleanup = {}
    try:
        cleanup = _v835_ledger_disk_rotation(cleanup, status if isinstance(status, dict) else {})
        save_json(FILES['cleanup_state'], cleanup)
    except Exception as exc:
        cleanup['ok'] = False
        cleanup['error_v835'] = f'{type(exc).__name__}: {exc}'
        try: log_error('v835_runtime_cleanup', exc)
        except Exception: pass
    return cleanup

VERSION = 'paper_bot_v0.799'

BUILD_LABEL = 'emergency_disk_retention_v840_2026-06-11'

def _v836_size(path: Path) -> int:
    try: return int(path.stat().st_size)
    except Exception: return 0

def _v836_mb_from_bytes(n: Any) -> float:
    try: return round(float(n or 0) / 1024.0 / 1024.0, 2)
    except Exception: return 0.0

def _v836_protected_core_names() -> set:
    names = set(_v835_cleanup_protected_names() if '_v835_cleanup_protected_names' in globals() else [])
    names.update({
        'paper_bot_open.json', 'paper_bot_closed.jsonl', 'paper_bot_trade_log.jsonl',
        'paper_bot_score_cache.json', 'paper_bot_status.json', 'paper_bot_open_positions.json',
        'bot.py', 'paper_bot.py', 'strategy_worker.py', 'DEPLOY_TARGET.txt', 'DEPLOY_BUNDLE.json',
        'clean_candidate_latest_snapshot.json', 'clean_strategy_worker_status.json',
    })
    names.add('paper_bot_v0.797.py')
    try:
        dep=(BASE_DIR/'DEPLOY_TARGET.txt').read_text(encoding='utf-8', errors='ignore').strip()
        if dep: names.add(Path(dep).name)
    except Exception: pass
    return names

def _v836_add_reason(res: Dict[str, Any], reason: str, files: int, bytes_count: int) -> None:
    try:
        d=res.setdefault('by_reason', {}).setdefault(str(reason), {'files':0,'bytes':0})
        d['files']=int(d.get('files') or 0)+int(files or 0)
        d['bytes']=int(d.get('bytes') or 0)+int(bytes_count or 0)
    except Exception: pass

def _v836_classify_large_file(path: Path) -> Dict[str, Any]:
    name=path.name; mb=_v836_mb_from_bytes(_v836_size(path)); prot=name in _v836_protected_core_names()
    cls='보호'; action='유지'; reason='핵심/현재 원천'
    if '_V839_LEGACY_CACHE_EXACT' in globals() and name in _V839_LEGACY_CACHE_EXACT:
        return {'name':name,'mb':mb,'class':'구형격리대상','action':'gzip archive + live reset','reason':'v824~v838 구조 변경 전 누적 cache/state · worker 재생성 대상','protected':False}
    if name == 'paper_candidates_latest.jsonl':
        cls='정리대상'; action='최근 tail 유지'; reason='append-only paper 후보 입력 · 최근 tail은 유지'
    elif prot:
        cls='보호'; action='삭제금지'; reason='핵심 원장/현재 실행파일/현재 snapshot'
    elif name.endswith('.log') or 'error.log' in name or name.startswith('clean_') and name.endswith('_error.log'):
        cls='정리대상'; action='tail 압축'; reason='큰 로그는 최근 tail만 유지'
    elif name.endswith('.jsonl') and ('trace' in name or 'detail' in name or 'review' in name or 'candidate' in name):
        cls='정리대상'; action='age/line prune'; reason='runtime trace/detail cache'
    elif name.endswith('.json') and ('cache' in name or 'review' in name or 'reason' in name or 'recheck' in name):
        cls='보호/관찰'; action='대상분류만'; reason='현재 worker cache일 수 있어 삭제 보류'
    elif name.endswith('.zip'):
        cls='정리대상'; action='old zip 삭제'; reason='오래된 배포 zip'
    else:
        cls='대상외'; action='유지'; reason='정책 미지정'
    return {'name':name,'mb':mb,'class':cls,'action':action,'reason':reason,'protected':prot}

def _v836_large_file_top(limit: int = 10) -> List[Dict[str, Any]]:
    out=[]
    try:
        for p in BASE_DIR.iterdir():
            if not p.is_file(): continue
            sz=_v836_size(p)
            if sz < 5*1024*1024: continue
            d=_v836_classify_large_file(p)
            d['age_sec']=round(max(0.0, now_ts()-p.stat().st_mtime),1)
            out.append(d)
    except Exception: pass
    out.sort(key=lambda x: float(x.get('mb') or 0.0), reverse=True)
    return out[:limit]

def _v836_tail_compact_text(path: Path, res: Dict[str, Any], max_mb: float, keep_mb: float, reason: str) -> None:
    try:
        if not path.exists() or not path.is_file(): return
        res['checked_files']=int(res.get('checked_files') or 0)+1
        if path.name in _v836_protected_core_names():
            res['protected_files']=int(res.get('protected_files') or 0)+1; return
        size=_v836_size(path); max_b=int(max_mb*1024*1024); keep_b=int(keep_mb*1024*1024)
        if size <= max_b:
            res['age_miss_or_small']=int(res.get('age_miss_or_small') or 0)+1; return
        with path.open('rb') as f:
            f.seek(max(0, size-keep_b)); tail=f.read(keep_b)
        header=(f"[v836 compacted {iso_ts() if 'iso_ts' in globals() else now_text()}] original_bytes={size} kept_tail={len(tail)}\n").encode('utf-8', errors='ignore')
        tmp=path.with_suffix(path.suffix+'.v836tmp')
        tmp.write_bytes(header+tail)
        os.replace(tmp, path)
        saved=max(0, size-_v836_size(path))
        res['trimmed_files']=int(res.get('trimmed_files') or 0)+1
        res['trimmed_bytes']=int(res.get('trimmed_bytes') or 0)+saved
        _v836_add_reason(res, reason, 1, saved)
    except Exception as exc:
        res['errors']=int(res.get('errors') or 0)+1
        res.setdefault('error_sample', []).append(f'{path.name}: {type(exc).__name__}')
        try: log_error('v836_tail_compact_text', exc)
        except Exception: pass

def _v836_compact_jsonl_tail_bytes(path: Path, res: Dict[str, Any], max_mb: float, keep_mb: float, reason: str) -> None:
    try:
        if not path.exists() or not path.is_file(): return
        res['checked_files']=int(res.get('checked_files') or 0)+1
        # Core ledger/trade_log is protected. Candidate latest is allowed because paper uses recent tail.
        if path.name in _v836_protected_core_names() and path.name != 'paper_candidates_latest.jsonl':
            res['protected_files']=int(res.get('protected_files') or 0)+1; return
        size=_v836_size(path); max_b=int(max_mb*1024*1024); keep_b=int(keep_mb*1024*1024)
        if size <= max_b:
            res['age_miss_or_small']=int(res.get('age_miss_or_small') or 0)+1; return
        with path.open('rb') as f:
            f.seek(max(0, size-keep_b)); data=f.read(keep_b)
        # Avoid leaving a partial JSON line at file start.
        if b'\n' in data:
            data=data[data.find(b'\n')+1:]
        tmp=path.with_suffix(path.suffix+'.v836tmp')
        tmp.write_bytes(data)
        os.replace(tmp, path)
        saved=max(0, size-_v836_size(path))
        res['compacted_files']=int(res.get('compacted_files') or 0)+1
        res['compacted_bytes']=int(res.get('compacted_bytes') or 0)+saved
        _v836_add_reason(res, reason, 1, saved)
    except Exception as exc:
        res['errors']=int(res.get('errors') or 0)+1
        res.setdefault('error_sample', []).append(f'{path.name}: {type(exc).__name__}')
        try: log_error('v836_compact_jsonl_tail_bytes', exc)
        except Exception: pass

def _v836_delete_old_file_glob(pattern: str, max_age_sec: float, res: Dict[str, Any], reason: str, keep_newest: int = 0) -> None:
    try:
        nowv=now_ts(); files=[p for p in BASE_DIR.glob(pattern) if p.is_file()]
        files.sort(key=lambda p: p.stat().st_mtime if p.exists() else 0, reverse=True)
        keep=set(files[:max(0,int(keep_newest))])
        prot=_v836_protected_core_names()
        for p in files:
            try:
                res['checked_files']=int(res.get('checked_files') or 0)+1
                if p in keep or p.name in prot:
                    res['protected_files']=int(res.get('protected_files') or 0)+1; continue
                age=nowv-p.stat().st_mtime
                if age < max_age_sec:
                    res['age_miss_or_small']=int(res.get('age_miss_or_small') or 0)+1; continue
                sz=_v836_size(p); p.unlink(missing_ok=True)
                res['deleted_files']=int(res.get('deleted_files') or 0)+1
                res['deleted_bytes']=int(res.get('deleted_bytes') or 0)+sz
                _v836_add_reason(res, reason, 1, sz)
            except Exception as exc:
                res['errors']=int(res.get('errors') or 0)+1
                res.setdefault('error_sample', []).append(f'{p.name}: {type(exc).__name__}')
    except Exception as exc:
        res['errors']=int(res.get('errors') or 0)+1
        try: log_error('v836_delete_old_file_glob', exc)
        except Exception: pass

_V839_LEGACY_CACHE_EXACT = {
    'paper_bot_hourly_event_trace.jsonl': 'paper_hourly_event_trace_reset',
}

def _v836_policy_cleanup(cleanup: Dict[str, Any], status: Dict[str, Any]) -> Dict[str, Any]:
    res: Dict[str, Any] = {
        'schema':'paper_runtime_cleanup_v836_policy', 'version':VERSION, 'build':BUILD_LABEL,
        'updated_at': now_ts(), 'updated_at_text': iso_ts() if 'iso_ts' in globals() else now_text(),
        'checked_files':0, 'deleted_files':0, 'deleted_bytes':0, 'trimmed_files':0, 'trimmed_bytes':0,
        'compacted_files':0, 'compacted_bytes':0, 'pruned_jsonl_files':0, 'jsonl_removed_lines':0,
        'protected_files':0, 'age_miss_or_small':0, 'errors':0, 'open_kept': int(status.get('open_count') or status.get('open_total') or 0) if isinstance(status, dict) else 0,
        'check_kept':0, 'done_archived':0, 'sample_compacted':0, 'by_reason':{},
        'policy':'최근 7일 상세 보관 · 구형 cache/state는 gzip 격리 후 재생성 · OPEN/CLOSED/trade_log/score 핵심 원장 삭제 금지',
    }
    try:
        # Old deployment clutter and leftover txt. Keep a few newest.
        _v836_delete_old_file_glob('coinbot_batch_summary_*.txt', 10*60.0, res, 'leftover_batch_summary_txt', keep_newest=1)
        _v836_delete_old_file_glob('paper_hourly_raw_pack_*.txt', 10*60.0, res, 'leftover_raw_pack_txt', keep_newest=0)
        _v836_delete_old_file_glob('paper_hourly_summary_tmp*.txt', 10*60.0, res, 'leftover_hourly_summary_txt', keep_newest=0)
        _v836_delete_old_file_glob('*.v836tmp', 60.0, res, 'leftover_tmp_write', keep_newest=0)
        _v836_delete_old_file_glob('*.v835tmp', 60.0, res, 'leftover_tmp_write', keep_newest=0)
        # Recurring runtime cleanup must not rerun the old one-time v839 migration.
        # Current strategy-owned cache/state files are live data, not legacy files.
        # Re-archiving them every cleanup cycle caused repeated 50~400MB snapshots.
        res['legacy_runtime_archive_disabled'] = True
        res['legacy_runtime_archive_owner'] = 'guard_storage_cleanup_explicit_noncore_archive_prune'
        res['legacy_runtime_archive_reason'] = 'one_time_migration_completed; live cache/state must stay writer-owned'
        for pat in ('coinbot_update_v*.zip', '코인봇_*묶음*.zip'):
            _v836_delete_old_file_glob(pat, 12*3600.0, res, 'old_deploy_bundle_zip', keep_newest=3)
        # Large logs: real tail compaction. Strategy error log was the main offender.
        for pat in ('*.log', '*error*.log'):
            for p in BASE_DIR.glob(pat):
                _v836_tail_compact_text(p, res, max_mb=32.0, keep_mb=4.0, reason='large_log_tail_compact_v836')
        # Append-only runtime jsonl caches. Core ledgers protected; paper latest uses recent tail.
        _v836_compact_jsonl_tail_bytes(BASE_DIR/'paper_candidates_latest.jsonl', res, max_mb=120.0, keep_mb=48.0, reason='paper_latest_tail_compact')
        for path, age, lines, reason in [
            (BASE_DIR/'paper_preopen_miss_review_trace.jsonl', 2*24*3600.0, 1600, 'preopen_review_trace_tail'),
            (BASE_DIR/'paper_preopen_miss_review_trace_v810.jsonl', 2*24*3600.0, 800, 'preopen_review_trace_legacy_tail'),
            (BASE_DIR/'paper_bot_hourly_raw_event_trace.jsonl', 6*3600.0, 1000, 'hourly_raw_event_trace_tail'),
            (BASE_DIR/'paper_bot_open_alert_trace.jsonl', 7*24*3600.0, 700, 'open_alert_trace_7d_tail'),
            (BASE_DIR/'paper_bot_close_alert_trace.jsonl', 7*24*3600.0, 700, 'close_alert_trace_7d_tail'),
            (BASE_DIR/'paper_bot_stop_overrun_trace.jsonl', 7*24*3600.0, 500, 'stop_overrun_trace_7d_tail'),
            (BASE_DIR/'paper_bot_trade_detail_v800.jsonl', 7*24*3600.0, 1000, 'trade_detail_7d_tail'),
        ]:
            try:
                before=_v836_size(path)
                if '_v678_jsonl_prune' in globals():
                    out=_v678_jsonl_prune(path, float(age), int(lines))
                    if out.get('exists'):
                        res['checked_files']=int(res.get('checked_files') or 0)+1
                        removed=int(out.get('removed') or 0); after=_v836_size(path); saved=max(0,before-after)
                        if removed or saved:
                            res['pruned_jsonl_files']=int(res.get('pruned_jsonl_files') or 0)+1
                            res['jsonl_removed_lines']=int(res.get('jsonl_removed_lines') or 0)+removed
                            res['trimmed_bytes']=int(res.get('trimmed_bytes') or 0)+saved
                            _v836_add_reason(res, reason, 1, saved)
                        else:
                            res['age_miss_or_small']=int(res.get('age_miss_or_small') or 0)+1
            except Exception as exc:
                res['errors']=int(res.get('errors') or 0)+1; res.setdefault('error_sample', []).append(f'{path.name}: {type(exc).__name__}')
        try:
            if '_v783_remove_pycache' in globals(): _v783_remove_pycache(res)
        except Exception: pass
        res['deleted_mb']=_v836_mb_from_bytes(res.get('deleted_bytes'))
        res['trimmed_mb']=_v836_mb_from_bytes(res.get('trimmed_bytes'))
        res['compacted_mb']=_v836_mb_from_bytes(res.get('compacted_bytes'))
        res['archived_mb']=_v836_mb_from_bytes(res.get('archived_bytes'))
        res['archive_mb']=_v836_mb_from_bytes(res.get('archive_bytes'))
        res['saved_mb']=_v836_mb_from_bytes(res.get('saved_bytes'))
        res['sample_compacted']=int(res.get('jsonl_removed_lines') or 0)
        res['large_file_top']=_v836_large_file_top(10)
        res['target_review']=res['large_file_top'][:10]
        cleanup['cleanup_policy_v836']=res
        cleanup['ledger_disk_rotation_v836']=res
        cleanup['legacy_cache_archive_v839']=res
        cleanup['cleanup_policy_v839']=res
        cleanup['deleted_files_v836']=int(res.get('deleted_files') or 0)+int(res.get('trimmed_files') or 0)+int(res.get('compacted_files') or 0)+int(res.get('pruned_jsonl_files') or 0)+int(res.get('archived_files') or 0)
        cleanup['deleted_mb_v836']=round(float(res.get('deleted_mb') or 0)+float(res.get('trimmed_mb') or 0)+float(res.get('compacted_mb') or 0)+float(res.get('saved_mb') or 0),2)
        cleanup['deleted_files_v839']=cleanup['deleted_files_v836']
        cleanup['deleted_mb_v839']=cleanup['deleted_mb_v836']
        cleanup['errors_v836']=int(res.get('errors') or 0)
        cleanup['errors_v839']=int(res.get('errors') or 0)
        cleanup['policy_v836']=res.get('policy')
        cleanup['policy_v839']=res.get('policy')
        cleanup['ok']=bool(cleanup.get('ok', True)) and int(res.get('errors') or 0)==0
    except Exception as exc:
        cleanup['ok']=False; cleanup['error_v836']=f'{type(exc).__name__}: {exc}'
        try: log_error('v836_policy_cleanup', exc)
        except Exception: pass
    return cleanup

def _v678_runtime_cleanup__L19525(ctrl: Dict[str, Any], status: Dict[str, Any]) -> Dict[str, Any]:  # type: ignore[override]
    cleanup = _v836_prev_runtime_cleanup(ctrl, status)
    if not isinstance(cleanup, dict): cleanup = {}
    try:
        cleanup = _v836_policy_cleanup(cleanup, status if isinstance(status, dict) else {})
        save_json(FILES['cleanup_state'], cleanup)
    except Exception as exc:
        cleanup['ok']=False; cleanup['error_v836']=f'{type(exc).__name__}: {exc}'
        try: log_error('v836_runtime_cleanup', exc)
        except Exception: pass
    return cleanup

VERSION = 'paper_bot_v0.799'

BUILD_LABEL = 'emergency_disk_retention_v840_2026-06-11'

_V840_CORE_PROTECT = {'paper_bot_open.json','paper_bot_closed.jsonl','paper_bot_trade_log.jsonl','paper_bot_score_cache.json','paper_bot_current_score_anchor.json','paper_bot_status.json','paper_bot_open_positions.json','clean_candidate_latest_snapshot.json','paper_decision_state_v926.json','paper_decision_status_v926.json','paper_decision_events_v926.jsonl','paper_closed_append_status_v925.json','paper_closed_append_events_v925.jsonl'}

def _v840_sz(path: Path) -> int:
    try: return int(path.stat().st_size)
    except Exception: return 0

def _v840_mb(n: Any) -> float:
    try: return round(float(n or 0)/1024/1024,2)
    except Exception: return 0.0

def _v840_reason(res: Dict[str,Any], reason: str, files:int, b:int) -> None:
    d=res.setdefault('by_reason',{}).setdefault(reason, {'files':0,'bytes':0})
    d['files']=int(d.get('files') or 0)+files; d['bytes']=int(d.get('bytes') or 0)+b

def _v840_disk() -> Dict[str,Any]:
    try:
        import shutil
        total, used, free = shutil.disk_usage(BASE_DIR)
        return {'free_gb':round(free/1024/1024/1024,2),'used_pct':round(used/max(total,1)*100,1)}
    except Exception: return {'free_gb':0,'used_pct':0}

def _v840_tail(path: Path, res: Dict[str,Any], max_mb: float, keep_mb: float, reason: str) -> None:
    try:
        if not path.exists() or not path.is_file(): return
        res['checked_files']=int(res.get('checked_files') or 0)+1
        if path.name in _V840_CORE_PROTECT: res['protected_files']=int(res.get('protected_files') or 0)+1; return
        size=_v840_sz(path)
        if size <= int(max_mb*1024*1024): res['small_or_skip']=int(res.get('small_or_skip') or 0)+1; return
        keep=int(keep_mb*1024*1024)
        with path.open('rb') as f: f.seek(max(0,size-keep)); data=f.read(keep)
        if path.suffix == '.jsonl' and b'\n' in data: data=data[data.find(b'\n')+1:]
        with path.open('wb') as f: f.write(data)
        after=_v840_sz(path); saved=max(0,size-after)
        res['tail_compacted_files']=int(res.get('tail_compacted_files') or 0)+1; res['tail_compacted_bytes']=int(res.get('tail_compacted_bytes') or 0)+saved; _v840_reason(res,reason,1,saved)
    except Exception as exc:
        res['errors']=int(res.get('errors') or 0)+1; res.setdefault('error_sample',[]).append(f'{path.name}: {type(exc).__name__}')

def _v840_emergency_cleanup(cleanup: Dict[str,Any], status: Dict[str,Any]) -> Dict[str,Any]:
    res={'schema':'paper_runtime_trace_cleanup','version':VERSION,'build':BUILD_LABEL,'updated_at':now_ts(),'updated_at_text':iso_ts() if 'iso_ts' in globals() else now_text(),'target_free_gb':None,'policy':'불필요 trace/log tail만 축소. live cache/state gzip reset 금지. OPEN/CLOSED/trade_log/score 삭제 금지.','before_disk':_v840_disk(),'checked_files':0,'deleted_files':0,'deleted_bytes':0,'force_reset_files':0,'force_reset_saved_bytes':0,'tail_compacted_files':0,'tail_compacted_bytes':0,'protected_files':0,'small_or_skip':0,'errors':0,'by_reason':{},'legacy_force_reset_disabled':True}
    try:
        # Old v840 force-reset targets are active writer-owned cache/state files now.
        # Do not archive or reset them during recurring paper cleanup.
        _v840_tail(BASE_DIR/'paper_candidates_latest.jsonl',res,45.0,20.0,'paper_latest_45mb_cap_tail20')
        for p in BASE_DIR.glob('*.log'): _v840_tail(p,res,20.0,3.0,'log_20mb_cap_tail3')
        for p in BASE_DIR.glob('*.jsonl'):
            if any(k in p.name for k in ('trace','detail','review','event')): _v840_tail(p,res,35.0,8.0,'jsonl_trace_35mb_cap_tail8')
        res['after_disk']=_v840_disk(); res['force_reset_saved_mb']=_v840_mb(res.get('force_reset_saved_bytes')); res['tail_compacted_mb']=_v840_mb(res.get('tail_compacted_bytes')); res['deleted_mb']=_v840_mb(res.get('deleted_bytes')); res['total_saved_mb']=round(float(res.get('force_reset_saved_mb') or 0)+float(res.get('tail_compacted_mb') or 0)+float(res.get('deleted_mb') or 0),2)
        cleanup['emergency_disk_cleanup_v840']=res; cleanup['cleanup_policy_v840']=res; cleanup['deleted_files_v840']=int(res.get('force_reset_files') or 0)+int(res.get('tail_compacted_files') or 0)+int(res.get('deleted_files') or 0); cleanup['deleted_mb_v840']=res.get('total_saved_mb'); cleanup['errors_v840']=int(res.get('errors') or 0); cleanup['policy_v840']=res.get('policy'); cleanup['ok']=bool(cleanup.get('ok',True)) and int(res.get('errors') or 0)==0
        save_json(FILES['cleanup_state'], cleanup)
    except Exception as exc:
        cleanup['ok']=False; cleanup['error_v840']=f'{type(exc).__name__}: {exc}'
        try: log_error('v840_emergency_cleanup', exc)
        except Exception: pass
    return cleanup

def _v678_runtime_cleanup__L19640(ctrl: Dict[str, Any], status: Dict[str, Any]) -> Dict[str, Any]:  # type: ignore[override]
    cleanup = _v840_prev_runtime_cleanup(ctrl, status)
    if not isinstance(cleanup, dict): cleanup={}
    return _v840_emergency_cleanup(cleanup, status if isinstance(status, dict) else {})

VERSION = 'paper_bot_v0.800'

BUILD_LABEL = 'queue_paper_owner_cleanup_v841_2026-06-11'

def _v678_runtime_cleanup__L19712(ctrl: Dict[str, Any], status: Dict[str, Any]) -> Dict[str, Any]:  # type: ignore[override]
    cleanup = _v841_prev_runtime_cleanup(ctrl, status)
    if not isinstance(cleanup, dict):
        cleanup = {}
    cleanup = _v841_paper_latest_owner_cleanup(cleanup, status if isinstance(status, dict) else {})
    return cleanup

VERSION = 'paper_bot_v0.801'

BUILD_LABEL = 'paper_runtime_trigger_spine_v842_2026-06-11'

def _v842_now() -> float:
    try:
        return now_ts()
    except Exception:
        return time.time()

def _v842_append_runtime_spine_status(cleanup: Dict[str, Any], status: Dict[str, Any]) -> Dict[str, Any]:
    obj: Dict[str, Any] = {
        'schema': 'paper_runtime_trigger_spine_status_v842',
        'version': VERSION,
        'build': BUILD_LABEL,
        'updated_at': _v842_now(),
        'updated_at_text': iso_ts() if 'iso_ts' in globals() else now_text(),
        'paper_latest_mb': _v840_mb(_v840_sz(BASE_DIR/'paper_candidates_latest.jsonl')) if '_v840_mb' in globals() and '_v840_sz' in globals() else 0.0,
        'paper_latest_limit_mb': 45.0,
        'paper_latest_owner': 'paper_bot',
        'trigger_spine_owner': 'paper_runtime_snapshot',
        'v628_user_visible_reason_removed': True,
        'formula_changed': False,
    }
    try:
        cleanup['paper_trigger_spine_v842'] = obj
        cleanup['paper_runtime_version_v842'] = VERSION
        cleanup['paper_runtime_build_v842'] = BUILD_LABEL
        status['paper_trigger_spine_v842'] = obj
        status['version'] = VERSION
        status['paper_version'] = VERSION
        status['build'] = BUILD_LABEL
        status['paper_runtime_build'] = BUILD_LABEL
        save_json(FILES['cleanup_state'], cleanup)
        _stage_status_fields(status)
    except Exception as exc:
        try: log_error('v842_runtime_spine_status_save', exc)
        except Exception: pass
    return cleanup

def _v678_runtime_cleanup__L19842(ctrl: Dict[str, Any], status: Dict[str, Any]) -> Dict[str, Any]:  # type: ignore[override]
    cleanup = _v842_prev_runtime_cleanup(ctrl, status) if callable(_v842_prev_runtime_cleanup) else {}
    if not isinstance(cleanup, dict):
        cleanup = {}
    try:
        # run paper latest owner cleanup again under v842 key for visible confirmation
        cleanup = _v841_paper_latest_owner_cleanup(cleanup, status if isinstance(status, dict) else {}) if '_v841_paper_latest_owner_cleanup' in globals() else cleanup
        owner = cleanup.get('paper_latest_owner_cleanup_v841') if isinstance(cleanup.get('paper_latest_owner_cleanup_v841'), dict) else {}
        if owner:
            cleanup['paper_latest_owner_cleanup_v842'] = dict(owner, version=VERSION, build=BUILD_LABEL, schema='paper_latest_owner_cleanup_v842')
        cleanup = _v842_append_runtime_spine_status(cleanup, status if isinstance(status, dict) else {})
    except Exception as exc:
        cleanup['ok'] = False
        cleanup['error_v842'] = f'{type(exc).__name__}: {exc}'
        try: log_error('v842_runtime_cleanup', exc)
        except Exception: pass
    return cleanup

VERSION = 'paper_bot_v0.802'

BUILD_LABEL = 'paper_entrypoint_pin_v843_2026-06-12'

def _v843_now() -> float:
    try:
        return now_ts()
    except Exception:
        return time.time()

def _v843_file_mb(path: Path) -> float:
    try:
        return round(path.stat().st_size / 1024.0 / 1024.0, 2) if Path(path).exists() else 0.0
    except Exception:
        return 0.0

def _v843_file_age(path: Path) -> float:
    try:
        return max(0.0, time.time() - Path(path).stat().st_mtime) if Path(path).exists() else 0.0
    except Exception:
        return 0.0

def _v843_cleanup_tmp_latest() -> Dict[str, Any]:
    tmp = BASE_DIR / 'paper_candidates_latest.jsonl.tmp'
    obj = {'path': str(tmp), 'exists': tmp.exists(), 'removed': False, 'mb_before': _v843_file_mb(tmp), 'age_sec': _v843_file_age(tmp)}
    try:
        # Only remove stale temp leftovers. Active writer temp files are left untouched.
        if tmp.exists() and obj['age_sec'] >= 60.0:
            tmp.unlink()
            obj['removed'] = True
            obj['mb_after'] = 0.0
        else:
            obj['mb_after'] = obj['mb_before']
    except Exception as exc:
        obj['error'] = f'{type(exc).__name__}: {exc}'
        try: log_error('v843_cleanup_tmp_latest', exc)
        except Exception: pass
    return obj

def _v843_runtime_pin_status(cleanup: Dict[str, Any], status: Dict[str, Any]) -> Dict[str, Any]:
    latest = BASE_DIR / 'paper_candidates_latest.jsonl'
    tmp = BASE_DIR / 'paper_candidates_latest.jsonl.tmp'
    latest_mb = _v843_file_mb(latest)
    tmp_mb = _v843_file_mb(tmp)
    owner_ok = (0.0 < latest_mb <= 50.0)
    pin = {
        'schema': 'paper_entrypoint_pin_v843',
        'version': VERSION,
        'build': BUILD_LABEL,
        'updated_at': _v843_now(),
        'updated_at_text': iso_ts() if 'iso_ts' in globals() else now_text(),
        'active': True,
        'entrypoint_files_pinned': ['paper_bot.py','paper_bot_v0.930.py'],
        'paper_latest_mb': latest_mb,
        'paper_latest_tmp_mb': tmp_mb,
        'paper_latest_limit_mb': 45.0,
        'paper_latest_owner_done': bool(owner_ok),
        'trigger_spine_active': True,
        'formula_changed': False,
        'reason': 'old paper entrypoint aliases are overwritten with the same v843 paper runtime',
    }
    try:
        cleanup['paper_entrypoint_pin_v843'] = pin
        cleanup['paper_latest_owner_cleanup_v843'] = {
            'schema': 'paper_latest_owner_cleanup_v843',
            'version': VERSION,
            'build': BUILD_LABEL,
            'ok': bool(owner_ok),
            'latest_mb': latest_mb,
            'tmp_mb': tmp_mb,
            'limit_mb': 45.0,
            'owner': 'paper_bot',
            'updated_at': pin['updated_at'],
            'updated_at_text': pin['updated_at_text'],
        }
        cleanup['paper_trigger_spine_v843'] = {
            'schema': 'paper_trigger_spine_v843_status',
            'version': VERSION,
            'build': BUILD_LABEL,
            'active': True,
            'owner': 'paper_runtime_snapshot',
            'formula_changed': False,
            'updated_at': pin['updated_at'],
            'updated_at_text': pin['updated_at_text'],
        }
        cleanup['paper_runtime_version_v843'] = VERSION
        cleanup['paper_runtime_build_v843'] = BUILD_LABEL
        status['version'] = VERSION
        status['paper_version'] = VERSION
        status['build'] = BUILD_LABEL
        status['paper_runtime_build'] = BUILD_LABEL
        status['paper_entrypoint_pin_v843'] = pin
        status['paper_trigger_spine_v843'] = cleanup['paper_trigger_spine_v843']
        status['paper_trigger_spine_v843_active'] = True
        status['paper_latest_owner_done_v843'] = bool(owner_ok)
        status['paper_latest_mb_v843'] = latest_mb
        save_json(FILES['cleanup_state'], cleanup)
        _stage_status_fields(status)
    except Exception as exc:
        try: log_error('v843_runtime_pin_status_save', exc)
        except Exception: pass
    return cleanup

def _v678_runtime_cleanup__L19983(ctrl: Dict[str, Any], status: Dict[str, Any]) -> Dict[str, Any]:  # type: ignore[override]
    cleanup = _v843_prev_runtime_cleanup(ctrl, status) if callable(_v843_prev_runtime_cleanup) else {}
    if not isinstance(cleanup, dict):
        cleanup = {}
    try:
        # Preserve paper-owned latest cleanup line. Do not let main truncate paper files.
        cleanup = _v841_paper_latest_owner_cleanup(cleanup, status if isinstance(status, dict) else {}) if '_v841_paper_latest_owner_cleanup' in globals() else cleanup
        cleanup['paper_candidates_latest_tmp_cleanup_v843'] = _v843_cleanup_tmp_latest()
        cleanup = _v843_runtime_pin_status(cleanup, status if isinstance(status, dict) else {})
    except Exception as exc:
        cleanup['ok'] = False
        cleanup['error_v843'] = f'{type(exc).__name__}: {exc}'
        try: log_error('v843_runtime_cleanup', exc)
        except Exception: pass
    return cleanup

VERSION = 'paper_bot_v0.795'

BUILD_LABEL = 'paper_latest_actual_cleanup_v846_2026-06-12'

def _v846_now() -> float:
    try: return now_ts()
    except Exception: return time.time()

def _v846_file_mb(path: Path) -> float:
    try: return round(Path(path).stat().st_size / 1024.0 / 1024.0, 2) if Path(path).exists() else 0.0
    except Exception: return 0.0

def _v846_file_age(path: Path) -> float:
    try: return max(0.0, time.time() - Path(path).stat().st_mtime) if Path(path).exists() else 0.0
    except Exception: return 0.0

def _v846_remove_stale_tmp_files(obj: Dict[str, Any]) -> None:
    removed=[]
    for pat in ('paper_candidates_latest.jsonl.tmp', '.paper_candidates_latest.v846.*.tmp'):
        try:
            for tmp in BASE_DIR.glob(pat):
                if tmp.exists() and _v846_file_age(tmp) >= 60.0:
                    mb=_v846_file_mb(tmp); tmp.unlink(); removed.append({'name':tmp.name,'mb':mb})
        except Exception as exc:
            obj.setdefault('tmp_errors', []).append(f'{pat}: {type(exc).__name__}: {exc}')
    obj['tmp_removed'] = removed; obj['tmp_removed_count'] = len(removed)

def _v846_compact_paper_latest_actual(cleanup: Dict[str, Any], status: Dict[str, Any], force: bool=False) -> Dict[str, Any]:
    path = BASE_DIR / 'paper_candidates_latest.jsonl'; max_mb=45.0; keep_mb=20.0
    obj={'schema':'paper_latest_actual_cleanup_v846','version':VERSION,'build':BUILD_LABEL,'updated_at':_v846_now(),'updated_at_text':iso_ts() if 'iso_ts' in globals() else now_text(),'target':'paper_candidates_latest.jsonl','owner':'paper_bot','max_mb':max_mb,'keep_mb':keep_mb,'errors':0,'action':'skip','formula_changed':False}
    try:
        before=path.stat().st_size if path.exists() else 0; obj['before_mb']=round(before/1024/1024,2); _v846_remove_stale_tmp_files(obj)
        if path.exists() and path.is_file() and (force or before > int(max_mb*1024*1024)):
            keep=int(keep_mb*1024*1024)
            with path.open('rb') as f:
                f.seek(max(0,before-keep)); data=f.read(keep)
            if b'\n' in data: data=data[data.find(b'\n')+1:]
            if data and not data.endswith(b'\n'): data += b'\n'
            tmp=BASE_DIR / f'.paper_candidates_latest.v846.{os.getpid()}.tmp'
            with tmp.open('wb') as f:
                f.write(data)
                try: f.flush(); os.fsync(f.fileno())
                except Exception: pass
            os.replace(tmp,path); obj['action']='atomic_tail20_replace_by_paper_owner'
        after=path.stat().st_size if path.exists() else 0; obj['after_mb']=round(after/1024/1024,2); obj['saved_mb']=round(max(0,before-after)/1024/1024,2)
        obj['ok']=bool(path.exists() and 0 < after <= int(50.0*1024*1024)); obj['latest_ok']=obj['ok']; obj['owner_done']=obj['ok']
        if not obj['ok']: obj['reason']='actual_file_still_over_cap_or_missing'
    except Exception as exc:
        obj['errors']=int(obj.get('errors') or 0)+1; obj['ok']=False; obj['owner_done']=False; obj['error']=f'{type(exc).__name__}: {exc}'
        try: log_error('v846_compact_paper_latest_actual', exc)
        except Exception: pass
    try:
        cleanup['paper_latest_actual_cleanup_v846']=obj; cleanup['paper_latest_owner_cleanup_v846']=obj; cleanup['paper_runtime_version_v846']=VERSION; cleanup['paper_runtime_build_v846']=BUILD_LABEL; cleanup['updated_at']=obj.get('updated_at')
        status['version']=VERSION; status['paper_version']=VERSION; status['build']=BUILD_LABEL; status['paper_runtime_build']=BUILD_LABEL; status['paper_latest_actual_cleanup_v846']=obj; status['paper_latest_mb_v846']=obj.get('after_mb'); status['paper_latest_owner_done_v846']=bool(obj.get('owner_done'))
        status['paper_entrypoint_pin_v846']={'schema':'paper_entrypoint_pin_v846','version':VERSION,'build':BUILD_LABEL,'active':True,'updated_at':obj.get('updated_at'),'updated_at_text':obj.get('updated_at_text')}
        status['paper_trigger_spine_v846']={'schema':'paper_trigger_spine_v846_status','version':VERSION,'build':BUILD_LABEL,'active':True,'owner':'paper_runtime_snapshot','formula_changed':False,'updated_at':obj.get('updated_at'),'updated_at_text':obj.get('updated_at_text')}
        cleanup['paper_entrypoint_pin_v846']=status['paper_entrypoint_pin_v846']; cleanup['paper_trigger_spine_v846']=status['paper_trigger_spine_v846']
        save_json(FILES['cleanup_state'], cleanup); _stage_status_fields(status)
    except Exception as exc:
        try: log_error('v846_compact_paper_latest_save', exc)
        except Exception: pass
    return cleanup

def _v678_runtime_cleanup__L20077(ctrl: Dict[str, Any], status: Dict[str, Any]) -> Dict[str, Any]:  # type: ignore[override]
    cleanup = _v846_prev_runtime_cleanup(ctrl, status) if callable(_v846_prev_runtime_cleanup) else {}
    if not isinstance(cleanup, dict): cleanup={}
    return _v846_compact_paper_latest_actual(cleanup, status if isinstance(status, dict) else {}, force=False)

VERSION = 'paper_bot_v0.795'

BUILD_LABEL = 'paper_owner_cleanup_permission_bridge_v852_actual_entrypoint_2026-06-12'

def _v849_now() -> float:
    try: return now_ts()
    except Exception: return time.time()

def _v849_file_mb(path: Path) -> float:
    try: return round(Path(path).stat().st_size / 1024.0 / 1024.0, 2) if Path(path).exists() else 0.0
    except Exception: return 0.0

def _v849_file_age(path: Path) -> float:
    try: return max(0.0, time.time() - Path(path).stat().st_mtime) if Path(path).exists() else 0.0
    except Exception: return 0.0

def _v849_owner_cleanup_base_obj(action: str='skip') -> Dict[str, Any]:
    return {
        'schema':'paper_latest_actual_cleanup_v852', 'version':VERSION, 'build':BUILD_LABEL,
        'updated_at':_v849_now(), 'updated_at_text':iso_ts() if 'iso_ts' in globals() else now_text(),
        'target':'paper_candidates_latest.jsonl', 'owner':'paper_bot', 'max_mb':45.0, 'keep_mb':20.0,
        'errors':0, 'action':action, 'formula_changed':False,
    }

def _v849_skip_paper_latest_tail(path: Path, res: Dict[str, Any], max_mb: float, keep_mb: float, reason: str) -> None:
    # v849: paper_candidates_latest is handled only by _v852_compact_paper_latest_actual.
    # Old in-place cleanup produced PermissionError noise and stale ledger rows.
    try:
        if Path(path).name == 'paper_candidates_latest.jsonl':
            res['checked_files'] = int(res.get('checked_files') or 0) + 1
            res.setdefault('owner_deferred', []).append({'name':'paper_candidates_latest.jsonl','mb':_v849_file_mb(Path(path)),'owner':'paper_bot','reason':'v852_current_owner_cleanup_only'})
            return
    except Exception:
        pass
    return _v849_prev_v840_tail(path, res, max_mb, keep_mb, reason)

try:
    _v849_prev_v840_tail = _v840_tail  # type: ignore[name-defined]
    _v840_tail = _v849_skip_paper_latest_tail  # type: ignore[assignment]
except Exception:
    pass

def _v849_remove_stale_tmp_files(obj: Dict[str, Any]) -> None:
    removed=[]
    for pat in ('paper_candidates_latest.jsonl.tmp', '.paper_candidates_latest.v846.*.tmp', '.paper_candidates_latest.v849.*.tmp'):
        try:
            for tmp in BASE_DIR.glob(pat):
                if tmp.exists() and _v849_file_age(tmp) >= 60.0:
                    mb=_v849_file_mb(tmp); tmp.unlink(); removed.append({'name':tmp.name,'mb':mb})
        except Exception as exc:
            obj.setdefault('tmp_errors', []).append(f'{pat}: {type(exc).__name__}: {exc}')
    obj['tmp_removed'] = removed
    obj['tmp_removed_count'] = len(removed)

def _v849_permission_obj(path: Path, tmp_dir: Path) -> Dict[str, Any]:
    return {
        'path_exists': bool(path.exists()),
        'path_writable': bool(os.access(path, os.W_OK)) if path.exists() else False,
        'dir_writable': bool(os.access(tmp_dir, os.W_OK)),
        'tmp_dir': str(tmp_dir),
    }

def _v852_compact_paper_latest_actual(cleanup: Dict[str, Any], status: Dict[str, Any], force: bool=False) -> Dict[str, Any]:
    path = BASE_DIR / 'paper_candidates_latest.jsonl'
    max_mb=45.0; keep_mb=20.0
    obj=_v849_owner_cleanup_base_obj('skip')
    tmp = BASE_DIR / f'.paper_candidates_latest.v849.{os.getpid()}.tmp'
    try:
        before=path.stat().st_size if path.exists() else 0
        obj['before_mb']=round(before/1024/1024,2)
        obj['permission'] = _v849_permission_obj(path, BASE_DIR)
        _v849_remove_stale_tmp_files(obj)
        if path.exists() and path.is_file() and (force or before > int(max_mb*1024*1024)):
            keep=int(keep_mb*1024*1024)
            with path.open('rb') as f:
                f.seek(max(0,before-keep))
                data=f.read(keep)
            if b'\n' in data:
                data=data[data.find(b'\n')+1:]
            if data and not data.endswith(b'\n'):
                data += b'\n'
            with tmp.open('wb') as f:
                f.write(data)
                try: f.flush(); os.fsync(f.fileno())
                except Exception: pass
            # Single current owner path: hidden temp file -> atomic replace.
            os.replace(tmp, path)
            obj['action']='atomic_tail20_replace_by_v852_paper_owner'
        after=path.stat().st_size if path.exists() else 0
        obj['after_mb']=round(after/1024/1024,2)
        obj['saved_mb']=round(max(0,before-after)/1024/1024,2)
        tmp_mb=_v849_file_mb(BASE_DIR/'paper_candidates_latest.jsonl.tmp')
        obj['tmp_mb']=tmp_mb
        obj['ok']=bool(path.exists() and 0 < after <= int(50.0*1024*1024) and tmp_mb <= 0.01)
        obj['latest_ok']=obj['ok']
        obj['owner_done']=obj['ok']
        obj['permission_ok']=bool(obj.get('permission',{}).get('dir_writable'))
        if not obj['ok']:
            if after > int(50.0*1024*1024): obj['reason']='actual_file_still_over_cap'
            elif tmp_mb > 0.01: obj['reason']='tmp_leftover_present'
            else: obj['reason']='actual_file_missing_or_empty'
    except Exception as exc:
        obj['errors']=int(obj.get('errors') or 0)+1
        obj['ok']=False; obj['latest_ok']=False; obj['owner_done']=False
        obj['error']=f'{type(exc).__name__}: {exc}'
        obj['permission'] = obj.get('permission') or _v849_permission_obj(path, BASE_DIR)
        try:
            if tmp.exists(): tmp.unlink(missing_ok=True)
        except Exception as tmp_exc:
            obj['tmp_cleanup_error']=f'{type(tmp_exc).__name__}: {tmp_exc}'
        try: log_error('v852_compact_paper_latest_actual', exc)
        except Exception: pass
    try:
        cleanup['paper_latest_actual_cleanup_v852']=obj
        cleanup['paper_latest_owner_cleanup_v852']=obj
        # compatibility: older main displays may still read v849 keys during one deploy cycle.
        cleanup['paper_latest_actual_cleanup_v849']=obj
        cleanup['paper_latest_owner_cleanup_v849']=obj
        cleanup['paper_runtime_version_v852']=VERSION
        cleanup['paper_runtime_build_v852']=BUILD_LABEL
        cleanup['paper_runtime_version_v849']=VERSION
        cleanup['paper_runtime_build_v849']=BUILD_LABEL
        cleanup['updated_at']=obj.get('updated_at')
        cleanup['paper_entrypoint_pin_v852']={'schema':'paper_entrypoint_pin_v852','version':VERSION,'build':BUILD_LABEL,'active':True,'updated_at':obj.get('updated_at'),'updated_at_text':obj.get('updated_at_text'),'entrypoint_files_pinned':['paper_bot.py','paper_bot_v0.930.py']}
        cleanup['paper_trigger_spine_v852']={'schema':'paper_trigger_spine_v852_status','version':VERSION,'build':BUILD_LABEL,'active':True,'owner':'paper_runtime_snapshot','formula_changed':False,'updated_at':obj.get('updated_at'),'updated_at_text':obj.get('updated_at_text')}
        status['version']=VERSION; status['paper_version']=VERSION; status['build']=BUILD_LABEL; status['paper_runtime_build']=BUILD_LABEL
        status['paper_latest_actual_cleanup_v852']=obj
        status['paper_latest_actual_cleanup_v849']=obj
        status['paper_latest_mb_v852']=obj.get('after_mb')
        status['paper_latest_mb_v849']=obj.get('after_mb')
        status['paper_latest_owner_done_v852']=bool(obj.get('owner_done'))
        status['paper_latest_owner_done_v849']=bool(obj.get('owner_done'))
        status['paper_entrypoint_pin_v852']=cleanup['paper_entrypoint_pin_v852']
        status['paper_entrypoint_pin_v849']=cleanup['paper_entrypoint_pin_v852']
        status['paper_trigger_spine_v852']=cleanup['paper_trigger_spine_v852']
        status['paper_trigger_spine_v849']=cleanup['paper_trigger_spine_v852']
        status['paper_trigger_spine_v852_active']=True
        status['paper_trigger_spine_v849_active']=True
        save_json(FILES['cleanup_state'], cleanup)
        _stage_status_fields(status)
    except Exception as exc:
        try: log_error('v852_compact_paper_latest_save', exc)
        except Exception: pass
    return cleanup

def _v849_paper_latest_owner_cleanup(cleanup: Dict[str, Any], status: Dict[str, Any]) -> Dict[str, Any]:
    # Replace old v841 in-place owner function with current v849 owner line.
    return _v852_compact_paper_latest_actual(cleanup if isinstance(cleanup, dict) else {}, status if isinstance(status, dict) else {}, force=False)

try:
    _v841_paper_latest_owner_cleanup = _v849_paper_latest_owner_cleanup  # type: ignore[assignment]
except Exception:
    pass

def _v678_runtime_cleanup__L20257(ctrl: Dict[str, Any], status: Dict[str, Any]) -> Dict[str, Any]:  # type: ignore[override]
    cleanup = _v849_prev_runtime_cleanup(ctrl, status) if callable(_v849_prev_runtime_cleanup) else {}
    if not isinstance(cleanup, dict): cleanup={}
    return _v852_compact_paper_latest_actual(cleanup, status if isinstance(status, dict) else {}, force=False)

VERSION = 'paper_bot_v0.853'

BUILD_LABEL = 'paper_owner_cleanup_execution_fix_v853_2026-06-12'

def _v853_now() -> float:
    try:
        return now_ts()
    except Exception:
        return time.time()

def _v853_mb_bytes(n: int) -> float:
    try:
        return round(float(n) / 1024.0 / 1024.0, 2)
    except Exception:
        return 0.0

def _v853_file_mb(path: Path) -> float:
    try:
        p = Path(path)
        return _v853_mb_bytes(p.stat().st_size) if p.exists() else 0.0
    except Exception:
        return 0.0

def _v853_file_age(path: Path) -> float:
    try:
        p = Path(path)
        return max(0.0, time.time() - p.stat().st_mtime) if p.exists() else 0.0
    except Exception:
        return 0.0

def _v853_perm(path: Path) -> Dict[str, Any]:
    p = Path(path)
    return {
        'path': str(p),
        'path_exists': bool(p.exists()),
        'path_writable': bool(os.access(p, os.W_OK)) if p.exists() else False,
        'dir': str(p.parent),
        'dir_writable': bool(os.access(p.parent, os.W_OK)),
        'uid': os.getuid() if hasattr(os, 'getuid') else None,
        'pid': os.getpid(),
    }

def _v853_remove_legacy_tmp__L20323(obj: Dict[str, Any], *, min_age: float = 5.0) -> None:
    """Remove abandoned paper_latest tmp files owned by old cleanup paths."""
    removed = []
    kept = []
    errors = []
    patterns = (
        'paper_candidates_latest.jsonl.tmp',
        '.paper_candidates_latest.v846.*.tmp',
        '.paper_candidates_latest.v849.*.tmp',
        '.paper_candidates_latest.v852.*.tmp',
        '.paper_candidates_latest.v853.*.tmp',
    )
    for pat in patterns:
        try:
            for tmp in BASE_DIR.glob(pat):
                try:
                    if not tmp.exists():
                        continue
                    age = _v853_file_age(tmp)
                    mb = _v853_file_mb(tmp)
                    # Do not delete the current process temp if it is brand-new.
                    if age < float(min_age) and tmp.name.startswith('.paper_candidates_latest.v853.'):
                        kept.append({'name': tmp.name, 'mb': mb, 'age': round(age, 1), 'reason': 'current_tmp_too_new'})
                        continue
                    tmp.unlink()
                    removed.append({'name': tmp.name, 'mb': mb, 'age': round(age, 1)})
                except Exception as exc:
                    errors.append({'name': getattr(tmp, 'name', str(tmp)), 'error': f'{type(exc).__name__}: {exc}'})
        except Exception as exc:
            errors.append({'pattern': pat, 'error': f'{type(exc).__name__}: {exc}'})
    obj['tmp_removed'] = removed
    obj['tmp_removed_count'] = len(removed)
    obj['tmp_kept'] = kept
    obj['tmp_errors'] = errors

def _v853_read_tail_bytes(path: Path, keep_mb: float) -> bytes:
    size = path.stat().st_size if path.exists() else 0
    keep = int(float(keep_mb) * 1024 * 1024)
    with path.open('rb') as f:
        f.seek(max(0, size - keep))
        data = f.read(keep)
    if b'\n' in data:
        data = data[data.find(b'\n') + 1:]
    if data and not data.endswith(b'\n'):
        data += b'\n'
    return data

def _stage_cleanup_status_fields(cleanup: Dict[str, Any], status: Dict[str, Any], obj: Dict[str, Any]) -> None:
    cleanup['paper_latest_actual_cleanup_v853'] = obj
    cleanup['paper_latest_owner_cleanup_v853'] = obj
    # Keep compatibility keys for existing main display paths during one deploy.
    cleanup['paper_latest_actual_cleanup_v852'] = obj
    cleanup['paper_latest_owner_cleanup_v852'] = obj
    cleanup['paper_latest_actual_cleanup_v849'] = obj
    cleanup['paper_latest_owner_cleanup_v849'] = obj
    cleanup['paper_runtime_version_v853'] = VERSION
    cleanup['paper_runtime_build_v853'] = BUILD_LABEL
    cleanup['paper_runtime_version_v852'] = VERSION
    cleanup['paper_runtime_build_v852'] = BUILD_LABEL
    cleanup['updated_at'] = obj.get('updated_at')
    pin = {'schema': 'paper_entrypoint_pin_v853', 'version': VERSION, 'build': BUILD_LABEL, 'active': True,
           'updated_at': obj.get('updated_at'), 'updated_at_text': obj.get('updated_at_text'),
           'entrypoint_files_pinned': ['paper_bot.py', 'paper_bot_v0.930.py']}
    spine = {'schema': 'paper_trigger_spine_v853_status', 'version': VERSION, 'build': BUILD_LABEL, 'active': True,
             'owner': 'paper_runtime_snapshot', 'formula_changed': False,
             'updated_at': obj.get('updated_at'), 'updated_at_text': obj.get('updated_at_text')}
    cleanup['paper_entrypoint_pin_v853'] = pin
    cleanup['paper_entrypoint_pin_v852'] = pin
    cleanup['paper_trigger_spine_v853'] = spine
    cleanup['paper_trigger_spine_v852'] = spine
    status['version'] = VERSION
    status['paper_version'] = VERSION
    status['build'] = BUILD_LABEL
    status['paper_runtime_build'] = BUILD_LABEL
    status['paper_latest_actual_cleanup_v853'] = obj
    status['paper_latest_actual_cleanup_v852'] = obj
    status['paper_latest_actual_cleanup_v849'] = obj
    status['paper_latest_mb_v853'] = obj.get('after_mb')
    status['paper_latest_mb_v852'] = obj.get('after_mb')
    status['paper_latest_owner_done_v853'] = bool(obj.get('owner_done'))
    status['paper_latest_owner_done_v852'] = bool(obj.get('owner_done'))
    status['paper_entrypoint_pin_v853'] = pin
    status['paper_entrypoint_pin_v852'] = pin
    status['paper_trigger_spine_v853'] = spine
    status['paper_trigger_spine_v852'] = spine
    status['paper_trigger_spine_v853_active'] = True
    status['paper_trigger_spine_v852_active'] = True
    save_json(FILES['cleanup_state'], cleanup)
    _stage_status_fields(status)

def _v853_compact_paper_latest_actual(cleanup: Dict[str, Any], status: Dict[str, Any], force: bool = False, source: str = 'cycle') -> Dict[str, Any]:
    path = BASE_DIR / 'paper_candidates_latest.jsonl'
    max_mb = 45.0
    keep_mb = 20.0
    obj: Dict[str, Any] = {
        'schema': 'paper_latest_actual_cleanup_v853',
        'version': VERSION,
        'build': BUILD_LABEL,
        'updated_at': _v853_now(),
        'updated_at_text': iso_ts() if 'iso_ts' in globals() else now_text(),
        'target': 'paper_candidates_latest.jsonl',
        'owner': 'paper_bot',
        'source': source,
        'max_mb': max_mb,
        'keep_mb': keep_mb,
        'errors': 0,
        'action': 'skip',
        'formula_changed': False,
        'permission': _v853_perm(path),
    }
    tmp = BASE_DIR / f'.paper_candidates_latest.v853.{os.getpid()}.tmp'
    try:
        before = path.stat().st_size if path.exists() else 0
        obj['before_mb'] = _v853_mb_bytes(before)
        _v853_remove_legacy_tmp(obj, min_age=5.0)
        if path.exists() and path.is_file() and (force or before > int(max_mb * 1024 * 1024)):
            data = _v853_read_tail_bytes(path, keep_mb)
            with tmp.open('wb') as f:
                f.write(data)
                try:
                    f.flush(); os.fsync(f.fileno())
                except Exception:
                    pass
            try:
                os.replace(tmp, path)
                obj['action'] = 'atomic_tail20_replace_by_v853_paper_owner'
            except Exception as exc:
                obj['replace_error'] = f'{type(exc).__name__}: {exc}'
                # Same owner fallback: if directory replace is blocked but file write is allowed,
                # rewrite the file directly. Main still never truncates this file.
                with path.open('wb') as f:
                    f.write(data)
                    try:
                        f.flush(); os.fsync(f.fileno())
                    except Exception:
                        pass
                obj['action'] = 'direct_tail20_rewrite_by_v853_paper_owner_after_replace_error'
                try:
                    if tmp.exists(): tmp.unlink()
                except Exception as tmp_exc:
                    obj['tmp_cleanup_error'] = f'{type(tmp_exc).__name__}: {tmp_exc}'
        # Cleanup any leftover tmp after owner rewrite.
        _v853_remove_legacy_tmp(obj, min_age=0.0)
        after = path.stat().st_size if path.exists() else 0
        obj['after_mb'] = _v853_mb_bytes(after)
        obj['saved_mb'] = _v853_mb_bytes(max(0, before - after))
        legacy_tmp = BASE_DIR / 'paper_candidates_latest.jsonl.tmp'
        obj['tmp_mb'] = _v853_file_mb(legacy_tmp)
        obj['verified_live_mb'] = obj['after_mb']
        obj['ok'] = bool(path.exists() and 0 < after <= int(50.0 * 1024 * 1024) and obj['tmp_mb'] <= 0.01 and not obj.get('tmp_errors'))
        obj['latest_ok'] = bool(path.exists() and 0 < after <= int(50.0 * 1024 * 1024))
        obj['owner_done'] = bool(obj['ok'])
        obj['permission_ok'] = bool(obj.get('permission', {}).get('dir_writable') or obj.get('permission', {}).get('path_writable'))
        if not obj['ok']:
            if after > int(50.0 * 1024 * 1024):
                obj['reason'] = 'actual_file_still_over_cap_after_owner_cleanup'
            elif obj['tmp_mb'] > 0.01:
                obj['reason'] = 'legacy_tmp_leftover_present_after_owner_cleanup'
            elif obj.get('tmp_errors'):
                obj['reason'] = 'tmp_cleanup_error'
            else:
                obj['reason'] = 'actual_file_missing_or_empty'
    except Exception as exc:
        obj['errors'] = int(obj.get('errors') or 0) + 1
        obj['ok'] = False
        obj['latest_ok'] = False
        obj['owner_done'] = False
        obj['error'] = f'{type(exc).__name__}: {exc}'
        obj['permission'] = obj.get('permission') or _v853_perm(path)
        try:
            if tmp.exists(): tmp.unlink()
        except Exception as tmp_exc:
            obj['tmp_cleanup_error'] = f'{type(tmp_exc).__name__}: {tmp_exc}'
        try:
            log_error('v853_compact_paper_latest_actual', exc)
        except Exception:
            pass
    try:
        _stage_cleanup_status_fields(cleanup if isinstance(cleanup, dict) else {}, status if isinstance(status, dict) else {}, obj)
    except Exception as exc:
        try:
            log_error('v853_compact_paper_latest_save', exc)
        except Exception:
            pass
    return cleanup if isinstance(cleanup, dict) else {}

def _v678_runtime_cleanup__L20516(ctrl: Dict[str, Any], status: Dict[str, Any]) -> Dict[str, Any]:  # type: ignore[override]
    cleanup = _v853_prev_runtime_cleanup(ctrl, status) if callable(_v853_prev_runtime_cleanup) else {}
    if not isinstance(cleanup, dict):
        cleanup = {}
    return _v853_compact_paper_latest_actual(cleanup, status if isinstance(status, dict) else {}, force=False, source='runtime_cleanup')

def _v853_startup_owner_cleanup() -> None:
    try:
        cleanup = load_json(FILES['cleanup_state'], {}) if 'FILES' in globals() else {}
        if not isinstance(cleanup, dict):
            cleanup = {}
        status = load_json(FILES['status'], {}) if 'FILES' in globals() else {}
        if not isinstance(status, dict):
            status = {}
        _v853_compact_paper_latest_actual(cleanup, status, force=True, source='startup_preflight')
    except Exception as exc:
        try: log_error('v853_startup_owner_cleanup', exc)
        except Exception: pass

VERSION = 'paper_bot_v0.859'

BUILD_LABEL = 'paper_tmp_cleanup_trigger_display_v859_2026-06-12'

def _v859_now() -> float:
    try: return now_ts()
    except Exception: return time.time()

def _v859_file_mb(path: Path) -> float:
    try:
        p = Path(path)
        return round(p.stat().st_size / 1024.0 / 1024.0, 2) if p.exists() else 0.0
    except Exception:
        return 0.0

def _v859_file_age(path: Path) -> float:
    try:
        p = Path(path)
        return max(0.0, time.time() - p.stat().st_mtime) if p.exists() else 0.0
    except Exception:
        return 0.0

def _v859_tmp_cleanup_snapshot(source: str='cycle', force: bool=False, min_age: float=3.0) -> Dict[str, Any]:
    latest = BASE_DIR / 'paper_candidates_latest.jsonl'
    obj: Dict[str, Any] = {
        'schema': 'paper_tmp_cleanup_v859', 'version': VERSION, 'build': BUILD_LABEL,
        'updated_at': _v859_now(), 'updated_at_text': iso_ts() if 'iso_ts' in globals() else now_text(),
        'owner': 'paper_bot', 'source': source, 'formula_changed': False,
        'latest_mb': _v859_file_mb(latest), 'removed': [], 'kept': [], 'errors': [],
    }
    patterns = (
        'paper_candidates_latest.jsonl.tmp',
        '.paper_candidates_latest.v846.*.tmp', '.paper_candidates_latest.v849.*.tmp',
        '.paper_candidates_latest.v852.*.tmp', '.paper_candidates_latest.v853.*.tmp',
        '.paper_candidates_latest.v859.*.tmp',
    )
    for pat in patterns:
        try:
            for tmp in BASE_DIR.glob(pat):
                try:
                    if not tmp.exists():
                        continue
                    age = _v859_file_age(tmp); mb = _v859_file_mb(tmp)
                    # Hidden temp from the current process can be fresh; legacy visible tmp is safe after min_age.
                    if not force and age < float(min_age):
                        obj['kept'].append({'name': tmp.name, 'mb': mb, 'age': round(age,1), 'reason': 'too_new'})
                        continue
                    tmp.unlink()
                    obj['removed'].append({'name': tmp.name, 'mb': mb, 'age': round(age,1)})
                except Exception as exc:
                    obj['errors'].append({'name': getattr(tmp, 'name', str(tmp)), 'error': f'{type(exc).__name__}: {exc}'})
        except Exception as exc:
            obj['errors'].append({'pattern': pat, 'error': f'{type(exc).__name__}: {exc}'})
    obj['removed_count'] = len(obj.get('removed') or [])
    obj['removed_mb'] = round(sum(float(x.get('mb') or 0.0) for x in (obj.get('removed') or [])), 2)
    legacy_tmp = BASE_DIR / 'paper_candidates_latest.jsonl.tmp'
    obj['tmp_after_mb'] = _v859_file_mb(legacy_tmp)
    obj['ok'] = bool(obj['tmp_after_mb'] <= 0.01 and not obj.get('errors'))
    obj['permission_ok'] = bool(os.access(BASE_DIR, os.W_OK))
    try:
        cleanup = load_json(FILES['cleanup_state'], {}) if 'FILES' in globals() else {}
        if not isinstance(cleanup, dict): cleanup = {}
        status = load_json(FILES['status'], {}) if 'FILES' in globals() else {}
        if not isinstance(status, dict): status = {}
        cleanup['paper_tmp_cleanup_v859'] = obj
        cleanup['paper_runtime_version_v859'] = VERSION
        cleanup['paper_runtime_build_v859'] = BUILD_LABEL
        cleanup['updated_at'] = obj.get('updated_at')
        pin = {'schema': 'paper_entrypoint_pin_v859', 'version': VERSION, 'build': BUILD_LABEL, 'active': True, 'updated_at': obj.get('updated_at'), 'updated_at_text': obj.get('updated_at_text'), 'entrypoint_files_pinned': ['paper_bot.py','paper_bot_v0.930.py']}
        spine = {'schema': 'paper_trigger_spine_v859_status', 'version': VERSION, 'build': BUILD_LABEL, 'active': True, 'owner': 'paper_runtime_snapshot', 'formula_changed': False, 'updated_at': obj.get('updated_at'), 'updated_at_text': obj.get('updated_at_text')}
        cleanup['paper_entrypoint_pin_v859'] = pin
        cleanup['paper_trigger_spine_v859'] = spine
        status['version'] = VERSION; status['paper_version'] = VERSION; status['build'] = BUILD_LABEL; status['paper_runtime_build'] = BUILD_LABEL
        status['paper_tmp_cleanup_v859'] = obj
        status['paper_entrypoint_pin_v859'] = pin
        status['paper_trigger_spine_v859'] = spine
        status['paper_trigger_spine_v859_active'] = True
        save_json(FILES['cleanup_state'], cleanup); _stage_status_fields(status)
    except Exception as exc:
        obj.setdefault('errors', []).append({'save': f'{type(exc).__name__}: {exc}'})
        try: log_error('v859_tmp_cleanup_snapshot_save', exc)
        except Exception: pass
    return obj

def _v853_remove_legacy_tmp__L20640(obj: Dict[str, Any], *, min_age: float = 5.0) -> None:  # type: ignore[override]
    if callable(_v859_prev_v853_remove_legacy_tmp):
        _v859_prev_v853_remove_legacy_tmp(obj, min_age=min_age)
    snap = _v859_tmp_cleanup_snapshot(source='v853_remove_bridge', force=bool(min_age <= 0.0), min_age=min_age)
    obj['tmp_cleanup_v859'] = snap
    obj['tmp_mb'] = snap.get('tmp_after_mb', obj.get('tmp_mb'))

VERSION = 'paper_bot_v0.796'

BUILD_LABEL = 'preopen_review_same_key_seal_v895_2026-06-14'

VERSION = 'paper_bot_v0.797'

BUILD_LABEL = 'preopen_result_same_key_alias_v896_2026-06-14'

VERSION = 'paper_bot_v0.798'

BUILD_LABEL = 'preopen_freshness_missing_trace_v904_2026-06-15'

VERSION = 'paper_bot_v0.799'

BUILD_LABEL = 'preopen_input_hydration_v905_2026-06-15'

VERSION = 'paper_bot_v0.989'

BUILD_LABEL = 'v1052_paper_release_identity_manifest_guard_spine_2026-06-26'

PAPER_MAX_UNTRADABLE_SPREAD_PCT = 1.20

PAPER_MIN_RR = 1.50

PAPER_MIN_TARGET_ROOM_PCT = 1.20

PAPER_MAX_TRIGGER_CHASE_PCT = 0.60

def read_strategy_entry_gate(ev: Dict[str, Any]) -> Dict[str, Any]:
    """Read the single strategy-owned ALT_SWING entry gate."""
    if not isinstance(ev, dict):
        return {}
    gate = ev.get('swing_entry_gate_v977')
    if isinstance(gate, dict) and gate:
        return gate
    ctx = ev.get('entry_context') if isinstance(ev.get('entry_context'), dict) else {}
    gate = ctx.get('swing_entry_gate_v977')
    return gate if isinstance(gate, dict) else {}

def read_strategy_decision_key(ev: Dict[str, Any], gate: Optional[Dict[str, Any]] = None) -> str:
    """Read the strategy-owned exact plan key without ticker/event reconstruction."""
    if not isinstance(ev, dict):
        return ''
    for value in (
        ev.get('swing_gate_decision_key_v977'),
        (gate or {}).get('decision_key') if isinstance(gate, dict) else None,
    ):
        if value not in (None, '', '-', [], {}):
            return str(value).strip()
    return ''

V1159_TRIGGER_TERMINAL_FEEDBACK_STATE = BASE_DIR / 'paper_trigger_terminal_feedback_v1159.json'

def _v1159_trigger_terminal_identity(ev: Dict[str, Any], proof: Dict[str, Any]) -> Dict[str, Any]:
    row = ev if isinstance(ev, dict) else {}
    gate = read_strategy_entry_gate(row)
    occurrence = gate.get('trigger_occurrence') if isinstance(gate.get('trigger_occurrence'), dict) else row.get('trigger_occurrence') if isinstance(row.get('trigger_occurrence'), dict) else {}
    decision = str((proof or {}).get('decision_key') or occurrence.get('decision_key') or read_strategy_decision_key(row, gate) or '').strip()
    event_ts = fnum((proof or {}).get('event_ts'), occurrence.get('event_ts'), occurrence.get('rebreak_ts'), default=0.0)
    ticker = normalize_ticker(row.get('ticker') or row.get('market') or row.get('symbol'))
    candidate_key = str(occurrence.get('candidate_key') or row.get('trigger_occurrence_candidate_key') or row.get('entry_build_key') or '').strip()
    return {
        'decision_key': decision,
        'trigger_event_ts': event_ts,
        'ticker': ticker,
        'candidate_key': candidate_key,
        'pipeline_cycle_id': row.get('candidate_pipeline_cycle_id_v1150'),
        'paper_consumed_handoff_id_v1158': row.get('paper_consumed_handoff_id_v1158'),
    }

def _v1160_existing_terminal_feedback(ev: Dict[str, Any]) -> Dict[str, Any]:
    """Classify an exact stale terminal event before Paper evaluates it again.

    The same immutable completed handoff is read on every fast Paper cycle while
    Strategy is still building the next generation.  Re-reading that same handoff
    is not a new Strategy publication and must not increase Paper receive/repeat
    counts.  A different handoff carrying the same decision+event remains visible
    as a true Strategy republish and is not suppressed.
    """
    ident = _v1159_trigger_terminal_identity(ev, {})
    decision = str(ident.get('decision_key') or '').strip()
    event_ts = fnum(ident.get('trigger_event_ts'), default=0.0)
    current_handoff = str(ident.get('paper_consumed_handoff_id_v1158') or '').strip()
    current_cycle = str(ident.get('pipeline_cycle_id') or '').strip()
    if not decision or event_ts <= 0:
        return {'state': 'NO_EXACT_IDENTITY', 'suppress': False}
    state = load_json(V1159_TRIGGER_TERMINAL_FEEDBACK_STATE, {}) or {}
    records = state.get('records') if isinstance(state, dict) and isinstance(state.get('records'), dict) else {}
    old = records.get(decision) if isinstance(records.get(decision), dict) else {}
    if not old:
        return {'state': 'NOT_TERMINAL', 'suppress': False}
    old_event_ts = fnum(old.get('trigger_event_ts'), old.get('event_ts'), default=0.0)
    if str(old.get('terminal_code') or '').upper() != 'STALE_TRIGGER_OCCURRENCE' or abs(old_event_ts-event_ts) > 0.001:
        return {'state': 'DIFFERENT_EVENT', 'suppress': False}
    first_handoff = str(old.get('first_handoff_id_v1160') or old.get('paper_consumed_handoff_id_v1158') or '').strip()
    first_cycle = str(old.get('first_pipeline_cycle_id_v1160') or old.get('pipeline_cycle_id') or '').strip()
    same_generation = bool(
        (current_handoff and first_handoff and current_handoff == first_handoff)
        or (not (current_handoff and first_handoff) and current_cycle and first_cycle and current_cycle == first_cycle)
    )
    if same_generation:
        return {
            'state': 'SAME_COMPLETED_HANDOFF_ALREADY_TERMINAL', 'suppress': True,
            'decision_key': decision, 'trigger_event_ts': event_ts,
            'handoff_id': current_handoff or None, 'pipeline_cycle_id': current_cycle or None,
            'event_uid': old.get('event_uid'), 'first_seen_ts': old.get('first_seen_ts'),
        }
    return {
        'state': 'NEW_HANDOFF_SAME_EVENT_REPUBLISH', 'suppress': False,
        'decision_key': decision, 'trigger_event_ts': event_ts,
        'handoff_id': current_handoff or None, 'pipeline_cycle_id': current_cycle or None,
        'first_handoff_id': first_handoff or None, 'first_pipeline_cycle_id': first_cycle or None,
        'event_uid': old.get('event_uid'),
    }

def is_strategy_s1_candidate(ev: Dict[str, Any]) -> bool:
    if _v988_is_s3_observation_only(ev):
        return False
    gate = read_strategy_entry_gate(ev)
    stage = str(ev.get('s_stage') or ev.get('candidate_stage') or ev.get('candidate_grade') or ev.get('grade') or '').upper()
    mode = str(ev.get('strategy_mode') or ev.get('strategy_mode_v977') or gate.get('strategy_mode') or '').upper()
    decision_key = read_strategy_decision_key(ev, gate)
    return bool(
        gate.get('schema') == 'swing_entry_gate_v977_single_owner' and
        mode == 'ALT_SWING_V977' and
        gate.get('hard_pass') is True and
        str(gate.get('final_trade_state') or '') == 'S1_PASS' and
        bool(decision_key) and
        str(gate.get('decision_key') or '') == decision_key and
        stage == 'S1'
    )

def _v925_confirmed_slippage(ev: Dict[str, Any]) -> Tuple[Optional[float], str]:
    """Consume only the Orderflow-owned v1100 executable slippage contract."""
    source = str(ev.get('entry_slippage_source') or '').strip().lower()
    confirmed = ev.get('entry_slippage_confirmed') is True
    owner = str(ev.get('entry_slippage_owner') or '').strip().lower()
    if not confirmed or owner != 'orderflow_worker':
        return None, 'missing'
    if not source or source in ('missing','none','-'):
        return None, 'missing'
    if 'spread_copy' in source or 'derived_from_spread' in source:
        return None, 'spread_copy_forbidden'
    if not any(token in source for token in ('best_ask_reference_orderflow_v1100','micro_depth_estimate_orderflow_v1100')):
        return None, f'unconfirmed:{source}'
    value = fnum(ev.get('entry_slippage_est_pct'), default=-1.0)
    return (value if value >= 0 else None), source

def evaluate_frozen_trigger(ev: Dict[str, Any], diag: Optional[Dict[str, Any]] = None, entry_override: Optional[float] = None) -> Dict[str, Any]:
    """Runtime confirmation against the strategy-owned frozen swing trigger."""
    diag = diag if isinstance(diag, dict) else {}
    gate = read_strategy_entry_gate(ev)
    plan = gate.get('structure_plan') if isinstance(gate.get('structure_plan'), dict) else {}
    if not plan:
        plan = gate.get('trigger') if isinstance(gate.get('trigger'), dict) else {}
    trigger_line = plan.get('trigger') if isinstance(plan.get('trigger'), dict) else {}
    trigger = fnum(
        trigger_line.get('rounded_price'), trigger_line.get('raw_price'),
        ev.get('swing_trigger_price_v977'), ev.get('trigger_price'), default=0.0,
    )
    ticker = normalize_ticker(ev.get('ticker') or ev.get('market') or ev.get('symbol'))
    base = fnum(entry_override, ev.get('current_price'), ev.get('entry_price'), ev.get('live_price'), ev.get('trade_price'), ev.get('price'), default=0.0)
    if base <= 0:
        base = get_event_price(ev)
    if ticker:
        confirmation, confirmation_source_v1079, confirmation_age_v1079 = _v1079_entry_confirmation_price(ticker, base)
    else:
        confirmation, confirmation_source_v1079, confirmation_age_v1079 = base, "candidate_fallback", None
    reached = bool(trigger > 0 and confirmation > 0 and confirmation >= trigger)
    gap = round((confirmation - trigger) / trigger * 100.0, 6) if trigger > 0 and confirmation > 0 else None
    if trigger <= 0:
        reason = '봉인된 구조 방아쇠 없음'
        code = 'frozen_trigger_missing'
    elif not reached:
        reason = f'현재 확인가 {fmt_price(confirmation)} < 봉인 방아쇠 {fmt_price(trigger)}'
        code = 'frozen_trigger_not_reached'
    else:
        reason = '봉인 방아쇠 도달 확인'
        code = 'frozen_trigger_reached'
    return {
        'schema': 'paper_trigger_gate_v926_exact_decision_owner',
        'ticker': ticker,
        'entry_price': confirmation or None,
        'current_confirmation_price': confirmation or None,
        'confirmation_price_source_v1079': confirmation_source_v1079,
        'confirmation_price_age_sec_v1079': confirmation_age_v1079,
        'trigger_price': trigger or None,
        'trigger_reached': reached,
        'trigger_gap_pct': gap,
        'reason': reason,
        'reason_code': code,
        'trigger_source': trigger_line.get('source'),
        'trigger_source_key': trigger_line.get('source_key'),
        'trigger_tf': trigger_line.get('tf'),
        'trigger_frozen_ts': plan.get('frozen_ts'),
        'source_plan_move_detected': bool(plan.get('source_plan_move_detected')),
        'frozen_plan_held': bool(plan.get('frozen_plan_held')),
        'pretrigger_tolerance_pct': 0.0,
    }

def build_open_alert_freshness_snapshot(ev: Dict[str, Any], diag: Dict[str, Any]) -> Dict[str, Any]:
    """Seal the exact OPEN-time freshness inputs used for the Telegram formatter.

    The formatter must not reconstruct freshness from a reduced diagnostics object.
    """
    ev = ev if isinstance(ev, dict) else {}
    diag = diag if isinstance(diag, dict) else {}
    sources: List[Tuple[str, Dict[str, Any]]] = []

    def add_source(name: str, obj: Any) -> None:
        if isinstance(obj, dict) and obj:
            sources.append((name, obj))

    add_source('candidate', ev)
    add_source('candidate.entry_context', ev.get('entry_context'))
    add_source('candidate.freshness_map', ev.get('freshness_map'))
    add_source('candidate.input_coverage', ev.get('candidate_input_coverage_v906'))
    add_source('candidate.canonical_metric_row', ev.get('canonical_metric_row'))
    add_source('candidate.canonical_entry_snapshot', ev.get('canonical_entry_snapshot'))
    add_source('diagnostics', diag)
    add_source('diagnostics.freshness_map', diag.get('freshness_map'))

    spec = {
        'scanner_hot': (('hot_signal_age_sec','scanner_hot_age_sec','_scanner_hot_cache_age_sec'), 35.0),
        'micro': (('micro_age_sec','quote_age_sec'), 20.0),
        'orderflow': (('orderflow_age_sec','trade_age_sec'), 20.0),
        'price_reaction': (('price_reaction_age_sec','feature_age_sec'), 30.0),
        'quote': (('quote_age_sec','micro_age_sec'), 20.0),
    }
    items: Dict[str, Dict[str, Any]] = {}
    missing: List[str] = []
    stale: List[str] = []
    fresh: List[str] = []
    for name, (keys, ttl) in spec.items():
        age: Optional[float] = None
        source = ''
        for source_name, obj in sources:
            for key in keys:
                value = obj.get(key)
                try:
                    number = float(value)
                except Exception:
                    number = -1.0
                if 0.0 <= number < 99999.0:
                    age = number
                    source = f'{source_name}.{key}'
                    break
            if age is None:
                nested_items = obj.get('items') if isinstance(obj.get('items'), dict) else {}
                nested = nested_items.get(name) if isinstance(nested_items.get(name), dict) else {}
                try:
                    number = float(nested.get('age_sec'))
                except Exception:
                    number = -1.0
                if 0.0 <= number < 99999.0:
                    age = number
                    source = f'{source_name}.items.{name}.age_sec'
            if age is not None:
                break
        state = 'missing' if age is None else ('fresh' if age <= ttl else 'stale')
        items[name] = {'age_sec': round(age, 3) if age is not None else None, 'ttl_sec': ttl, 'state': state, 'source': source or 'missing'}
        if state == 'missing': missing.append(name)
        elif state == 'stale': stale.append(name)
        else: fresh.append(name)
    required = ('micro','orderflow','price_reaction','quote')
    overall = 'fresh_ok' if all(items[k]['state']=='fresh' for k in required) else ('fresh_missing' if any(items[k]['state']=='missing' for k in required) else 'fresh_stale')
    return {
        'schema': 'paper_open_alert_freshness_snapshot_v973',
        'overall': overall,
        'items': items,
        'missing_fields': missing,
        'stale_fields': stale,
        'fresh_fields': fresh,
        'sealed_at': now_ts(),
        'policy': 'exact OPEN-time candidate inputs; formatter reads this snapshot only',
    }

V988_FIRE_PNL_THRESHOLD_PCT = 5.0

def _v988_is_s3_observation_only(row: Dict[str, Any]) -> bool:
    if not isinstance(row, dict):
        return False
    sources: List[Dict[str, Any]] = [row]
    for key in ('entry_evidence_v983','entry_context','canonical_entry_decision','common_entry_decision','raw'):
        obj=row.get(key)
        if isinstance(obj,dict):
            sources.append(obj)
    for source in sources:
        if any(source.get(key) is True for key in ('s3_observe_v732','s3_observe_v730','s3_observe_v729','s3_observe_v728','s3_observe_v727','s3_observation_only_v988','s3_review_only_v988','observation_open_forbidden_v988')):
            return True
        for key in ('strategy_key','paper_strategy_key','route','strategy','strategy_label','setup_type'):
            text=str(source.get(key) or '').strip().lower()
            if text.startswith('coin_quality_s3_observe') or 's3 관찰/복기 후보' in text or 's3 관찰 후보' in text:
                return True
    return False

def _v988_closed_emoji(row: Dict[str, Any]) -> str:
    """Canonical CLOSED result icon: final fee-adjusted loss always wins."""
    reason=str(row.get('exit_reason') or row.get('exit_rule') or '').strip()
    pnl=fnum(row.get('net_after_configured_fee_pct_v983'),row.get('pnl_pct'),default=0.0)
    if pnl < 0 or reason == 'structure_invalid':
        return '🔴'
    if pnl >= V988_FIRE_PNL_THRESHOLD_PCT:
        return '🔥'
    if pnl > 0 or reason == 'structure_target':
        return '🟢'
    if reason in ('swing_no_progress','swing_max_weak_hold'):
        return '🟠'
    return '⚪'

def paper_final_safety(ev: Dict[str, Any], ctrl: Dict[str, Any]) -> Tuple[bool, List[str], Dict[str, Any]]:
    """Single paper safety owner. Reads the strategy decision and rechecks runtime facts only."""
    ctx = copy_entry_context(ev)
    diag = build_entry_diagnostics(ev, ctx)
    alert_freshness = build_open_alert_freshness_snapshot(ev, diag)
    diag['open_alert_freshness_snapshot'] = alert_freshness
    diag['freshness_map'] = alert_freshness
    reasons: List[str] = []
    reason_records_v1122: List[Dict[str, Any]] = []
    def add_reason_v1122(code: str, message: Any, source: str) -> None:
        text=str(message or '').strip()
        if not text:
            return
        if text not in reasons:
            reasons.append(text)
            reason_records_v1122.append({'code':str(code or 'SAFETY_REASON_CONTRACT_MISSING').strip().upper(),'message':text,'source':source})
    if _v988_is_s3_observation_only(ev):
        add_reason_v1122('OBSERVATION_ONLY','S3 관찰·복기 전용 후보는 OPEN 금지','observation_role')
        diag['observation_only_block_v988'] = True
    gate = read_strategy_entry_gate(ev)
    decision_key = read_strategy_decision_key(ev, gate)
    if not gate:
        add_reason_v1122('SWING_GATE_MISSING','ALT_SWING 진입판 누락','strategy_gate')
    else:
        if gate.get('schema') != 'swing_entry_gate_v977_single_owner':
            add_reason_v1122('SWING_GATE_SCHEMA_MISMATCH','ALT_SWING 진입판 형식 불일치','strategy_gate')
        mode = str(ev.get('strategy_mode') or ev.get('strategy_mode_v977') or gate.get('strategy_mode') or '').upper()
        if mode != 'ALT_SWING_V977':
            add_reason_v1122('STRATEGY_MODE_MISMATCH','ALT_SWING 전략모드 불일치','strategy_mode')
        if not gate.get('decision_key') or not decision_key:
            add_reason_v1122('DECISION_KEY_MISSING','전략 판정번호 누락','decision_identity')
        elif str(gate.get('decision_key')) != decision_key:
            add_reason_v1122('DECISION_KEY_MISMATCH','전략 판정번호 불일치','decision_identity')
        if not bool(gate.get('hard_pass')) or str(gate.get('final_trade_state') or '') != 'S1_PASS':
            hard = gate.get('hard_block_reasons') if isinstance(gate.get('hard_block_reasons'), list) else []
            add_reason_v1122('STRATEGY_GATE_BLOCKED','전략 진입조건 미통과' + (': ' + ' / '.join(str(x) for x in hard[:5]) if hard else ''),'strategy_gate')
        if fnum(gate.get('risk_reward'), default=0.0) < PAPER_MIN_RR:
            add_reason_v1122('SEALED_RR_LOW','손익비 부족','sealed_contract')
        if fnum(gate.get('target_room_pct'), default=0.0) < PAPER_MIN_TARGET_ROOM_PCT:
            add_reason_v1122('SEALED_TARGET_ROOM_LOW','목표 공간 부족','sealed_contract')
        if not bool(gate.get('source_fresh')):
            add_reason_v1122('SEALED_SOURCE_STALE','전략 봉인 자료 최신성 부족','sealed_contract')

    occurrence_freshness=trigger_occurrence_freshness(ev,ctrl)
    diag['trigger_occurrence_freshness']=occurrence_freshness
    if occurrence_freshness.get('fresh') is not True:
        add_reason_v1122(str(occurrence_freshness.get('code') or 'WAIT_TRIGGER_PATH'),str(occurrence_freshness.get('reason') or '새 가격경로 reset→rebreak 또는 최종계약 재확인 대기'),'trigger_occurrence')

    trigger_gate = evaluate_frozen_trigger(ev, diag)
    diag['trigger_gate'] = trigger_gate
    diag['trigger_gate_v628'] = trigger_gate  # compatibility key, same single object
    diag['trigger_reached'] = bool(trigger_gate.get('trigger_reached'))
    diag['trigger_price'] = trigger_gate.get('trigger_price')
    diag['entry_price'] = trigger_gate.get('entry_price')
    diag['trigger_gap_pct'] = trigger_gate.get('trigger_gap_pct')
    if not trigger_gate.get('trigger_reached'):
        add_reason_v1122('TRIGGER_WAIT',str(trigger_gate.get('reason') or '봉인 방아쇠 미도달'),'frozen_trigger')
    elif fnum(trigger_gate.get('trigger_gap_pct'), default=0.0) > PAPER_MAX_TRIGGER_CHASE_PCT:
        add_reason_v1122('CHASE_OVER_LIMIT',f"trigger 추격 초과 {fnum(trigger_gate.get('trigger_gap_pct'), default=0.0):.3f}%",'actual_entry_contract')

    actual_entry=fnum(trigger_gate.get('entry_price'),default=0.0)
    actual_invalid=fnum(gate.get('invalid_price'),default=0.0) if isinstance(gate,dict) else 0.0
    actual_target=fnum(gate.get('target_price'),default=0.0) if isinstance(gate,dict) else 0.0
    actual_risk=actual_entry-actual_invalid
    actual_reward=actual_target-actual_entry
    actual_rr=(actual_reward/actual_risk) if actual_entry>0 and actual_risk>0 and actual_reward>0 else None
    actual_room=(actual_reward/actual_entry*100.0) if actual_entry>0 and actual_reward>0 else None
    diag['actual_entry_contract_v1095']={'schema':'actual_entry_contract_v1095','entry_price':actual_entry or None,'invalid_price':actual_invalid or None,'target_price':actual_target or None,'actual_entry_rr':round(actual_rr,6) if actual_rr is not None else None,'actual_target_room_pct':round(actual_room,6) if actual_room is not None else None,'minimum_rr':PAPER_MIN_RR,'minimum_target_room_pct':PAPER_MIN_TARGET_ROOM_PCT}
    if actual_rr is None:
        add_reason_v1122('ACTUAL_ENTRY_RR_MISSING','실제 진입가 RR 계산불가','actual_entry_contract')
    elif actual_rr < PAPER_MIN_RR:
        add_reason_v1122('ACTUAL_ENTRY_RR_LOW',f'실제 진입가 RR 부족 {actual_rr:.3f} < {PAPER_MIN_RR:.2f}','actual_entry_contract')
    if actual_room is None:
        add_reason_v1122('TARGET_ROOM_MISSING','실제 진입가 목표공간 계산불가','actual_entry_contract')
    elif actual_room < PAPER_MIN_TARGET_ROOM_PCT:
        add_reason_v1122('TARGET_ROOM_LOW',f'실제 진입가 목표공간 부족 {actual_room:.3f}% < {PAPER_MIN_TARGET_ROOM_PCT:.2f}%','actual_entry_contract')

    if not micro_fresh(ev, ctrl):
        add_reason_v1122('ORDERFLOW_STALE','OPEN 직전 호가·체결 자료 오래됨','execution_freshness')
    if bool(ctrl.get('paper_final_require_ws_fresh', False)) and not ws_fresh(ev):
        add_reason_v1122('WS_STALE','OPEN 직전 실시간 시세 오래됨','execution_freshness')

    spread = fnum(ev.get('spread_pct'), ev.get('micro_spread_pct'), ev.get('orderbook_spread_pct'), default=-1.0)
    if spread < 0:
        add_reason_v1122('SPREAD_SOURCE_MISSING','OPEN 직전 스프레드 자료 없음','execution_cost')
    elif spread > PAPER_MAX_UNTRADABLE_SPREAD_PCT:
        add_reason_v1122('SPREAD_OVER_LIMIT',f'거래불가 스프레드 {spread:.3f}%','execution_cost')

    slip, slip_source = _v925_confirmed_slippage(ev)
    slip_ts=fnum(ev.get('entry_slippage_ts'),default=0.0)
    slip_age=fnum(ev.get('entry_slippage_age_sec'),default=-1.0)
    if slip_ts > 0:
        live_slip_age=max(0.0,now_ts()-slip_ts)
        slip_age=max(slip_age,live_slip_age) if slip_age >= 0 else live_slip_age
    slip_ttl=max(5.0,fnum(ctrl.get('preopen_micro_urgent_ttl_sec'),default=35.0))
    if slip is None:
        add_reason_v1122('SLIPPAGE_SOURCE_MISSING','OPEN 직전 확정 미끄러짐 자료 없음','execution_cost')
    elif slip_age < 0 or slip_age > slip_ttl:
        add_reason_v1122('SLIPPAGE_STALE',f'OPEN 직전 확정 미끄러짐 자료 오래됨 {slip_age:.1f}s > {slip_ttl:.1f}s','execution_cost')
    elif slip > PAPER_MAX_UNTRADABLE_SPREAD_PCT:
        add_reason_v1122('SLIPPAGE_OVER_LIMIT',f'확정 미끄러짐 과다 {slip:.3f}%','execution_cost')
    reaction_reason=_paper_v144_reaction_proof_block(diag,ctrl) if bool(ctrl.get('paper_final_reaction_proof_enabled',True)) else ''
    if reaction_reason:
        add_reason_v1122('REACTION_UNSAFE',reaction_reason,'price_reaction')
    diag['reaction_proof_connected_v1095']=True

    clean: List[str] = []
    for reason in reasons:
        text = str(reason or '').strip()
        if text and text not in clean:
            clean.append(text)

    diag['swing_entry_gate_v977'] = gate
    diag['swing_gate_decision_key_v977'] = decision_key or None
    diag['quality_observation_v925'] = ev.get('quality_observation_v925') if isinstance(ev.get('quality_observation_v925'), dict) else {}
    diag['extreme_quality_risk_tags_v925'] = list(ev.get('extreme_quality_risk_tags_v925') or [])
    diag['paper_final_safety_schema'] = 'paper_final_safety_v1122_structured_reason_owner'
    diag['paper_final_safety_reasons'] = clean
    diag['paper_final_safety_reason_records_v1122'] = [row for row in reason_records_v1122 if row.get('message') in clean]
    diag['paper_final_safety_reason_codes_v1122'] = [row.get('code') for row in diag['paper_final_safety_reason_records_v1122']]
    diag['paper_final_safety_unmapped_reason_count_v1122'] = sum(1 for row in diag['paper_final_safety_reason_records_v1122'] if row.get('code') in {'UNMAPPED_SAFETY_REASON','INFORMATION_UNAVAILABLE','SAFETY_REASON_CONTRACT_MISSING'})
    diag['spread_pct_v925'] = spread if spread >= 0 else None
    diag['confirmed_slippage_pct_v925'] = slip
    diag['confirmed_slippage_source_v925'] = slip_source
    diag['entry_slippage_contract_v1100'] = {k:ev.get(k) for k in ('entry_slippage_est_pct','entry_slippage_source','entry_slippage_ts','entry_slippage_age_sec','entry_slippage_confirmed','entry_slippage_basis','entry_slippage_order_amount_krw','entry_slippage_order_amount_state','entry_slippage_owner')}
    diag['quality_conditions_blocking_v925'] = False
    diag['paper_raw_intake_v1174'] = True
    diag['paper_final_safety_would_pass_v1174'] = not clean
    diag['paper_final_safety_blocking_v1174'] = False
    diag['quality_selector_contract_v1097'] = ev.get('swing_quality_gate') if isinstance(ev.get('swing_quality_gate'),dict) else {}
    diag['auto_buy_ready'] = False

    # v1174: all late Paper safety findings are audit-only.
    # Selection still requires the Strategy-owned exact S1 decision and duplicate integrity.
    return True, clean[:12], diag

def _v926_load_decision_state() -> Dict[str, Any]:
    path = FILES.get('decision_state_v926', BASE_DIR / 'paper_decision_state_v926.json')
    obj = load_json(path, {}) or {}
    records = obj.get('records') if isinstance(obj, dict) and isinstance(obj.get('records'), dict) else {}
    return {
        'schema': 'paper_decision_state_v926',
        'version': VERSION,
        'build': BUILD_LABEL,
        'records': {str(k): dict(v) for k, v in records.items() if isinstance(v, dict)},
        'duplicate_blocked_total': int(fnum(obj.get('duplicate_blocked_total'), default=0)) if isinstance(obj, dict) else 0,
        'decision_key_missing_total': int(fnum(obj.get('decision_key_missing_total'), default=0)) if isinstance(obj, dict) else 0,
        'last_event': obj.get('last_event') if isinstance(obj, dict) and isinstance(obj.get('last_event'), dict) else None,
        'last_reconcile_v967': obj.get('last_reconcile_v967') if isinstance(obj, dict) and isinstance(obj.get('last_reconcile_v967'), dict) else None,
    }

def _v926_save_decision_state__L21755(state: Dict[str, Any]) -> bool:
    records = state.get('records') if isinstance(state, dict) and isinstance(state.get('records'), dict) else {}
    nowv = now_ts()
    payload = {
        'schema': 'paper_decision_state_v926', 'version': VERSION, 'build': BUILD_LABEL,
        'updated_ts': nowv, 'updated_text': iso_ts(nowv), 'records': records,
        'duplicate_blocked_total': int(fnum(state.get('duplicate_blocked_total'), default=0)),
        'decision_key_missing_total': int(fnum(state.get('decision_key_missing_total'), default=0)),
        'last_event': state.get('last_event') if isinstance(state.get('last_event'), dict) else None,
        'last_reconcile_v967': state.get('last_reconcile_v967') if isinstance(state.get('last_reconcile_v967'),dict) else None,
        'policy': 'one exact frozen-plan decision key may OPEN once; status is rebuilt from exact OPEN/CLOSED identities at startup',
    }
    state_path=FILES.get('decision_state_v926', BASE_DIR / 'paper_decision_state_v926.json')
    if not _paper_write_json_verified(state_path,payload):
        return False
    loaded=load_json(state_path,{}) or {}
    loaded_records=loaded.get('records') if isinstance(loaded,dict) and isinstance(loaded.get('records'),dict) else {}
    if _paper_json_digest(loaded_records)!=_paper_json_digest(records):
        log_error('decision_state_readback',RuntimeError('decision records digest mismatch'))
        return False
    status_counts = Counter(str(v.get('status') or 'UNKNOWN') for v in records.values() if isinstance(v, dict))
    closed_records_v1092 = {
        str(k): v for k, v in records.items()
        if isinstance(v, dict) and str(v.get('status') or '').upper() == 'CLOSED'
    }
    status = {
        'schema': 'paper_decision_status_v926', 'version': VERSION, 'build': BUILD_LABEL,
        'updated_ts': nowv, 'updated_text': iso_ts(nowv), 'total_decisions': len(records),
        'open_decisions': int(status_counts.get('OPEN', 0)), 'closed_decisions': int(status_counts.get('CLOSED', 0)),
        'legacy_exit_unverified_decisions': int(status_counts.get('LEGACY_EXIT_UNVERIFIED', 0)),
        'status_counts': dict(status_counts), 'last_event': state.get('last_event'),
        'duplicate_blocked_total': int(fnum(state.get('duplicate_blocked_total'), default=0)),
        'decision_key_missing_total': int(fnum(state.get('decision_key_missing_total'), default=0)),
        'state_write_verified': True, 'records_digest': _paper_json_digest(records),
        'closed_records_digest_v1092': _paper_json_digest(closed_records_v1092),
        'closed_records_count_v1092': len(closed_records_v1092),
        'performance_membership_digest_owner_v1092': 'paper_decision_status_closed_records_only',
        'policy': payload['policy'],
    }
    status_path=FILES.get('decision_status_v926', BASE_DIR / 'paper_decision_status_v926.json')
    status_ok=_paper_write_json_verified(status_path,status)
    if not status_ok:
        log_error('decision_status_write_verified',RuntimeError('decision status persistence failed'))
    return bool(status_ok)

_V1018_CLOSED_SEED_INODE = 0

_V1018_CLOSED_SEED_OFFSET = 0

_V1018_CLOSED_SEED_PENDING = b''

_V1018_CLOSED_SEED_INITIALIZED = False

_V1018_SEED_CALLS = 0

_V1018_SEED_NOOP_COUNT = 0

_V1018_SEED_OPEN_CHANGE_COUNT = 0

_V1018_SEED_CLOSED_CHANGE_COUNT = 0

_V1018_CLOSED_INCREMENTAL_READ_CALLS = 0

_V1018_CLOSED_INCREMENTAL_READ_BYTES = 0

_V1018_CLOSED_INCREMENTAL_ROWS = 0

_V1018_CLOSED_RECOVERY_TAIL_SCANS = 0

def _v1018_apply_seed_record(records: Dict[str, Dict[str, Any]], key: str, desired: Dict[str, Any], source: str) -> bool:
    prior = records.get(key) if isinstance(records.get(key), dict) else {}
    if all(_v1018_same_seed_value(field, prior.get(field), value) for field, value in desired.items()):
        return False
    rec = dict(prior)
    rec.update(desired)
    rec['last_seen_ts'] = now_ts()
    rec['source'] = source
    records[key] = rec
    return True

def _v1018_read_new_closed_rows() -> List[Dict[str, Any]]:
    """After startup reconciliation, read only bytes appended to CLOSED."""
    global _V1018_CLOSED_SEED_INODE, _V1018_CLOSED_SEED_OFFSET, _V1018_CLOSED_SEED_PENDING
    global _V1018_CLOSED_SEED_INITIALIZED, _V1018_CLOSED_INCREMENTAL_READ_CALLS
    global _V1018_CLOSED_INCREMENTAL_READ_BYTES, _V1018_CLOSED_INCREMENTAL_ROWS
    global _V1018_CLOSED_RECOVERY_TAIL_SCANS
    path = FILES['closed']
    if not path.exists():
        _V1018_CLOSED_SEED_INODE = 0
        _V1018_CLOSED_SEED_OFFSET = 0
        _V1018_CLOSED_SEED_PENDING = b''
        _V1018_CLOSED_SEED_INITIALIZED = True
        return []
    try:
        st = path.stat()
        inode = int(st.st_ino)
        size = int(st.st_size)
        if not _V1018_CLOSED_SEED_INITIALIZED:
            # Startup reconcile already rebuilt exact CLOSED membership.
            _V1018_CLOSED_SEED_INODE = inode
            _V1018_CLOSED_SEED_OFFSET = size
            _V1018_CLOSED_SEED_PENDING = b''
            _V1018_CLOSED_SEED_INITIALIZED = True
            return []
        if inode != _V1018_CLOSED_SEED_INODE or size < _V1018_CLOSED_SEED_OFFSET:
            _V1018_CLOSED_RECOVERY_TAIL_SCANS += 1
            rows = read_jsonl_tail(path, 2500)
            _V1018_CLOSED_SEED_INODE = inode
            _V1018_CLOSED_SEED_OFFSET = size
            _V1018_CLOSED_SEED_PENDING = b''
            return rows
        if size == _V1018_CLOSED_SEED_OFFSET:
            return []
        with path.open('rb') as handle:
            handle.seek(_V1018_CLOSED_SEED_OFFSET)
            chunk = handle.read(size - _V1018_CLOSED_SEED_OFFSET)
        _V1018_CLOSED_INCREMENTAL_READ_CALLS += 1
        _V1018_CLOSED_INCREMENTAL_READ_BYTES += len(chunk)
        _V1018_CLOSED_SEED_OFFSET = size
        combined = _V1018_CLOSED_SEED_PENDING + chunk
        if combined.endswith(b'\n'):
            complete = combined
            _V1018_CLOSED_SEED_PENDING = b''
        else:
            cut = combined.rfind(b'\n')
            if cut < 0:
                _V1018_CLOSED_SEED_PENDING = combined
                return []
            complete = combined[:cut + 1]
            _V1018_CLOSED_SEED_PENDING = combined[cut + 1:]
        rows: List[Dict[str, Any]] = []
        for raw in complete.splitlines():
            if not raw.strip():
                continue
            try:
                obj = json.loads(raw.decode('utf-8', errors='ignore'))
            except Exception:
                continue
            if isinstance(obj, dict):
                rows.append(obj)
        _V1018_CLOSED_INCREMENTAL_ROWS += len(rows)
        return rows
    except Exception as exc:
        log_error('v1018_closed_incremental_seed', exc)
        return []

def _v926_seed_decision_state(open_pos: Dict[str, Dict[str, Any]]) -> Dict[str, Any]:
    """Seed exact decision state without timestamp churn or repeated 2,500-row tail reads."""
    global _V1018_SEED_CALLS, _V1018_SEED_NOOP_COUNT
    global _V1018_SEED_OPEN_CHANGE_COUNT, _V1018_SEED_CLOSED_CHANGE_COUNT
    _V1018_SEED_CALLS += 1
    state = _v926_load_decision_state()
    records = state['records']
    changed = False
    for pid, pos in (open_pos or {}).items():
        if not isinstance(pos, dict):
            continue
        key = _v926_decision_key_from_row(pos)
        if not key:
            continue
        prior = records.get(key) if isinstance(records.get(key), dict) else {}
        if str(prior.get('status') or '').upper() == 'CLOSED':
            continue
        desired = {
            'status': 'OPEN',
            'paper_decision_key_v926': key,
            'pos_id': pos.get('pos_id') or pid,
            'ticker': normalize_ticker(pos.get('ticker') or pos.get('market') or pos.get('symbol')),
            'opened_ts': fnum(pos.get('opened_at'), pos.get('opened_ts'), default=0.0) or prior.get('opened_ts'),
        }
        if _v1018_apply_seed_record(records, key, desired, 'seed_from_open_exact_v1018'):
            _V1018_SEED_OPEN_CHANGE_COUNT += 1
            changed = True
    for row in _v1018_read_new_closed_rows():
        if not isinstance(row, dict):
            continue
        key = _v926_decision_key_from_row(row)
        if not key:
            continue
        prior = records.get(key) if isinstance(records.get(key), dict) else {}
        desired = {
            'status': 'CLOSED',
            'paper_decision_key_v926': key,
            'pos_id': row.get('pos_id') or prior.get('pos_id'),
            'ticker': normalize_ticker(row.get('ticker') or row.get('market') or row.get('symbol') or prior.get('ticker')),
            'opened_ts': fnum(row.get('opened_at'), row.get('opened_ts'), default=0.0) or prior.get('opened_ts'),
            'closed_ts': fnum(row.get('closed_ts'), row.get('closed_at'), default=0.0) or prior.get('closed_ts'),
            'closed_result_key': row.get('closed_result_key') or prior.get('closed_result_key') or f'closed:{key}',
        }
        if _v1018_apply_seed_record(records, key, desired, 'seed_from_closed_incremental_v1018'):
            _V1018_SEED_CLOSED_CHANGE_COUNT += 1
            changed = True
    status_path = FILES.get('decision_status_v926', BASE_DIR / 'paper_decision_status_v926.json')
    if changed or not status_path.exists():
        _v926_save_decision_state(state)
    else:
        _V1018_SEED_NOOP_COUNT += 1
    return state

def _v938_ts(value: Any) -> Optional[float]:
    try:
        v = float(value)
    except Exception:
        return None
    if v <= 0:
        return None
    if v > 100_000_000_000:
        v /= 1000.0
    return v if v > 0 else None

def _v938_delay(opened: Optional[float], earlier: Optional[float]) -> Optional[float]:
    if opened is None or earlier is None or opened < earlier:
        return None
    diff = opened - earlier
    return round(diff, 3) if 0.0 <= diff <= 7 * 86400.0 else None

def _v938_quality_evidence_from_row(row: Dict[str, Any]) -> Dict[str, Any]:
    if not isinstance(row, dict):
        return {}
    queue: List[Dict[str, Any]] = [row]
    seen = set()
    nested = (
        'entry_context','entry_diagnostics','entry_timing_spine','entry_timing_trace',
        'paper_open_spine_v566','paper_open_spine','paper_final_safety_diagnostics',
        'swing_entry_gate_v977','minimal_entry_gate_v925','trigger_gate','trigger_gate_v628','trigger_gate_v738','trigger_provenance_v924','paper_timing_spine_v940','paper_selection_spine_v940',
        'coherent_structure_plan_v925','frozen_structure_plan_v925','structure_plan_provenance_v925','raw',
    )
    sources: List[Dict[str, Any]] = []
    while queue and len(sources) < 32:
        current = queue.pop(0)
        if not isinstance(current, dict) or id(current) in seen:
            continue
        seen.add(id(current)); sources.append(current)
        for key in nested:
            value = current.get(key)
            if isinstance(value, dict): queue.append(value)
    def first(*keys: str) -> Any:
        for source in sources:
            for key in keys:
                value = source.get(key)
                if value not in (None, '', [], {}): return value
        return None

    opened = _v938_ts(first('opened_ts','opened_at','entry_ts','open_ts'))
    first_ts = _v938_ts(first('first_seen_ts','first_seen_at','first_detected_ts','detected_ts','candidate_created_at'))
    s1_ts = _v938_ts(first('s1_seen_ts','s1_seen_at','s1_at','promoted_at','promoted_ts'))
    trigger_ts = _v938_ts(first('trigger_reached_ts','paper_confirmed_trigger_reached_ts_v938','first_trigger_reached_ts','trigger_touch_ts','trigger_confirmed_ts'))
    selected_ts = _v938_ts(first('paper_selected_ts','paper_selected_ts_v940','selected_for_open_ts','paper_selected_at'))
    first_delay = first('first_to_paper_delay_sec','first_to_open_delay_sec')
    s1_delay = first('s1_to_paper_delay_sec','s1_to_open_delay_sec')
    try: first_delay = float(first_delay) if first_delay not in (None,'') else None
    except Exception: first_delay = None
    try: s1_delay = float(s1_delay) if s1_delay not in (None,'') else None
    except Exception: s1_delay = None
    if first_delay is None: first_delay = _v938_delay(opened, first_ts)
    if s1_delay is None: s1_delay = _v938_delay(opened, s1_ts)
    first_to_selected = paper_timing_delay(selected_ts, first_ts) if 'paper_timing_delay' in globals() else None
    s1_to_selected = paper_timing_delay(selected_ts, s1_ts) if 'paper_timing_delay' in globals() else None
    trigger_to_selected = paper_timing_delay(selected_ts, trigger_ts) if 'paper_timing_delay' in globals() else None
    selected_to_open = paper_timing_delay(opened, selected_ts) if 'paper_timing_delay' in globals() else None
    return {
        'opened_ts': opened,
        'paper_selected_ts': selected_ts,
        'first_to_selected_delay_sec': first_to_selected,
        's1_to_selected_delay_sec': s1_to_selected,
        'trigger_to_selected_delay_sec': trigger_to_selected,
        'selected_to_open_delay_sec': selected_to_open,
        'first_seen_ts': first_ts,
        's1_seen_ts': s1_ts,
        'first_to_paper_delay_sec': first_delay,
        's1_to_paper_delay_sec': s1_delay,
        'trigger_reached_ts': trigger_ts,
        'trigger_reached_ts_source_v938': first('trigger_reached_ts_source_v938','trigger_reached_ts_source'),
        'trigger_frozen_ts': first('trigger_frozen_ts','trigger_frozen_ts_v925','frozen_ts'),
        'entry_trigger_gap_pct': first('entry_trigger_gap_pct','trigger_gap_pct','distance_pct'),
        'quality_evidence_schema_v938': 'paper_exact_timing_evidence_v938',
        'timing_spine_schema_v940': 'paper_timing_spine_v940' if selected_ts is not None else None,
    }

def paper_timing_ts(value: Any) -> Optional[float]:
    return _v938_ts(value) if '_v938_ts' in globals() else None

def paper_timing_delay(later: Optional[float], earlier: Optional[float]) -> Optional[float]:
    if later is None or earlier is None or later < earlier:
        return None
    diff = later - earlier
    return round(diff, 3) if 0.0 <= diff <= 7 * 86400.0 else None

def collect_paper_timing_spine(row: Dict[str, Any], *, selected_ts: Optional[float] = None, opened_ts: Optional[float] = None, phase: str = '') -> Dict[str, Any]:
    """Paper-owned timing spine. Observation only; no gate/entry/exit change."""
    row = row if isinstance(row, dict) else {}
    evidence = _v938_quality_evidence_from_row(row) if '_v938_quality_evidence_from_row' in globals() else {}
    selected = paper_timing_ts(selected_ts) or paper_timing_ts(row.get('paper_selected_ts_v940') or row.get('paper_selected_ts') or evidence.get('paper_selected_ts'))
    opened = paper_timing_ts(opened_ts) or paper_timing_ts(row.get('opened_at') or row.get('opened_ts') or evidence.get('opened_ts'))
    first_ts = paper_timing_ts(evidence.get('first_seen_ts') or row.get('first_seen_ts'))
    s1_ts = paper_timing_ts(evidence.get('s1_seen_ts') or row.get('s1_seen_ts'))
    trigger_ts = paper_timing_ts(evidence.get('trigger_reached_ts') or row.get('trigger_reached_ts') or row.get('paper_confirmed_trigger_reached_ts_v938'))
    decision_key = _v926_decision_key_from_row(row) if '_v926_decision_key_from_row' in globals() else str(row.get('paper_decision_key_v926') or row.get('swing_gate_decision_key_v977') or '')
    spine = {
        'schema': 'paper_timing_spine_v940',
        'version': VERSION,
        'build': BUILD_LABEL,
        'phase': phase or 'paper_timing_spine',
        'paper_decision_key_v926': decision_key,
        'ticker': normalize_ticker(row.get('ticker') or row.get('market') or row.get('symbol')),
        'first_seen_ts': first_ts,
        's1_seen_ts': s1_ts,
        'trigger_reached_ts': trigger_ts,
        'paper_selected_ts': selected,
        'opened_ts': opened,
        'first_to_selected_delay_sec': paper_timing_delay(selected, first_ts),
        's1_to_selected_delay_sec': paper_timing_delay(selected, s1_ts),
        'trigger_to_selected_delay_sec': paper_timing_delay(selected, trigger_ts),
        'selected_to_open_delay_sec': paper_timing_delay(opened, selected),
        'first_to_open_delay_sec': paper_timing_delay(opened, first_ts),
        's1_to_open_delay_sec': paper_timing_delay(opened, s1_ts),
        'trigger_to_open_delay_sec': paper_timing_delay(opened, trigger_ts),
        'source': 'paper_select_open_timing_spine',
        'used_for_entry_gate': False,
        'used_for_exit': False,
        'policy': 'timing evidence only; S grade, trigger formula, entry, exit and cost criteria unchanged',
    }
    return {k: v for k, v in spine.items() if v not in (None, '', [], {})}

def mark_paper_selected_for_open(row: Dict[str, Any], diag: Dict[str, Any], stats: Dict[str, Any]) -> Dict[str, Any]:
    """Seal paper_selected_ts at the exact point select_candidates picks an OPEN candidate."""
    selected_ts = now_ts()
    if isinstance(row, dict):
        row['paper_selected_ts'] = selected_ts
        row['paper_selected_ts_v940'] = selected_ts
        row['paper_selected_ts_text_v940'] = iso_ts(selected_ts)
        row['paper_selected_ts_source_v940'] = 'select_candidates_selected_for_open'
    if isinstance(diag, dict):
        diag['paper_selected_ts'] = selected_ts
        diag['paper_selected_ts_v940'] = selected_ts
        diag['paper_selected_ts_source_v940'] = 'select_candidates_selected_for_open'
    spine = collect_paper_timing_spine(row, selected_ts=selected_ts, phase='selected_for_open')
    if isinstance(row, dict):
        row['paper_timing_spine_v940'] = spine
    if isinstance(diag, dict):
        diag['paper_timing_spine_v940'] = spine
    if isinstance(stats, dict):
        stats['paper_selected_ts_sealed_v940'] = int(stats.get('paper_selected_ts_sealed_v940', 0)) + 1
        if spine.get('trigger_to_selected_delay_sec') is not None:
            stats['trigger_to_selected_sample_v940'] = int(stats.get('trigger_to_selected_sample_v940', 0)) + 1
        if spine.get('s1_to_selected_delay_sec') is not None:
            stats['s1_to_selected_sample_v940'] = int(stats.get('s1_to_selected_sample_v940', 0)) + 1
    return spine

def attach_paper_timing_spine_to_open(pos: Dict[str, Any], ev: Dict[str, Any]) -> Dict[str, Any]:
    if not isinstance(pos, dict):
        return pos
    ev = ev if isinstance(ev, dict) else {}
    selected_ts = paper_timing_ts(ev.get('paper_selected_ts_v940') or ev.get('paper_selected_ts'))
    opened_ts = paper_timing_ts(pos.get('opened_at') or pos.get('opened_ts')) or now_ts()
    spine = collect_paper_timing_spine(ev, selected_ts=selected_ts, opened_ts=opened_ts, phase='opened')
    if spine:
        pos['paper_timing_spine_v940'] = spine
        for key in ('paper_selected_ts','first_seen_ts','s1_seen_ts','trigger_reached_ts','first_to_selected_delay_sec','s1_to_selected_delay_sec','trigger_to_selected_delay_sec','selected_to_open_delay_sec','first_to_open_delay_sec','s1_to_open_delay_sec','trigger_to_open_delay_sec'):
            if spine.get(key) not in (None, '', [], {}):
                pos[key] = spine.get(key)
        diag = pos.get('entry_diagnostics') if isinstance(pos.get('entry_diagnostics'), dict) else {}
        if isinstance(diag, dict):
            diag['paper_timing_spine_v940'] = spine
            if spine.get('paper_selected_ts'):
                diag['paper_selected_ts_v940'] = spine.get('paper_selected_ts')
            pos['entry_diagnostics'] = diag
    return pos

def write_paper_timing_spine_status(stats: Dict[str, Any], picked: List[Tuple[str, Dict[str, Any]]]) -> None:
    try:
        selected_rows = [row for _pid, row in (picked or []) if isinstance(row, dict)]
        samples = []
        for row in selected_rows[:8]:
            spine = row.get('paper_timing_spine_v940') if isinstance(row.get('paper_timing_spine_v940'), dict) else collect_paper_timing_spine(row, phase='status_sample')
            samples.append({k: spine.get(k) for k in ('ticker','paper_decision_key_v926','first_to_selected_delay_sec','s1_to_selected_delay_sec','trigger_to_selected_delay_sec','paper_selected_ts') if spine.get(k) not in (None, '', [], {})})
        payload = {
            'schema': 'paper_timing_spine_status_v940',
            'version': VERSION,
            'build': BUILD_LABEL,
            'updated_ts': now_ts(),
            'updated_text': iso_ts(),
            'selected_this_cycle': len(selected_rows),
            'stats': dict(stats or {}),
            'samples': samples,
            'policy': 'timing observation only; no S grade, trigger, entry, exit or cost criteria change',
        }
        save_json(FILES.get('timing_spine_status_v940', BASE_DIR / 'paper_timing_spine_status_v940.json'), payload)
        for row in selected_rows[:20]:
            spine = row.get('paper_timing_spine_v940') if isinstance(row.get('paper_timing_spine_v940'), dict) else {}
            if spine:
                append_jsonl(FILES.get('timing_spine_events_v940', BASE_DIR / 'paper_timing_spine_events_v940.jsonl'), dict(spine, event_ts=now_ts(), event_ts_text=iso_ts()))
    except Exception as exc:
        log_error('paper_timing_spine_status', exc)

def _v938_load_trigger_reach_state() -> Dict[str, Any]:
    path = FILES.get('trigger_reach_state_v938', BASE_DIR / 'paper_trigger_reach_state_v938.json')
    obj = load_json(path, {}) or {}
    records = obj.get('records') if isinstance(obj, dict) and isinstance(obj.get('records'), dict) else {}
    return {
        'schema':'paper_trigger_reach_state_v938', 'version':VERSION, 'build':BUILD_LABEL,
        'records':records, 'updated_ts':fnum(obj.get('updated_ts'), default=0.0) if isinstance(obj, dict) else 0.0,
        '_dirty':False,
    }

def _v938_note_trigger_reach(state: Dict[str, Any], row: Dict[str, Any], gate: Dict[str, Any]) -> Optional[float]:
    if not isinstance(state, dict) or not isinstance(row, dict) or not isinstance(gate, dict) or not bool(gate.get('trigger_reached')):
        return None
    key = _v926_decision_key_from_row(row)
    if not key:
        return None
    records = state.setdefault('records', {})
    prior = records.get(key) if isinstance(records.get(key), dict) else {}
    reached_ts = _v938_ts(prior.get('trigger_reached_ts')) or now_ts()
    rec = dict(prior)
    rec.update({
        'paper_decision_key_v926':key,
        'pos_id':row.get('paper_pos_id_v926') or row.get('pos_id'),
        'ticker':normalize_ticker(row.get('ticker') or row.get('market') or row.get('symbol')),
        'trigger_reached_ts':reached_ts,
        'trigger_reached_ts_text':iso_ts(reached_ts),
        'trigger_reached_ts_source_v938':'paper_final_safety_first_reached_v938',
        'trigger_price':gate.get('trigger_price'),
        'confirmation_price':gate.get('current_confirmation_price') or gate.get('entry_price'),
        'trigger_gap_pct':gate.get('trigger_gap_pct'),
        'last_seen_ts':now_ts(),
    })
    if rec != prior:
        records[key] = rec; state['_dirty'] = True
    gate['trigger_reached_ts'] = reached_ts
    gate['paper_confirmed_trigger_reached_ts_v938'] = reached_ts
    gate['trigger_reached_ts_source_v938'] = 'paper_final_safety_first_reached_v938'
    row['trigger_reached_ts'] = reached_ts
    row['paper_confirmed_trigger_reached_ts_v938'] = reached_ts
    row['trigger_reached_ts_source_v938'] = 'paper_final_safety_first_reached_v938'
    return reached_ts

def _v938_save_trigger_reach_state(state: Dict[str, Any]) -> None:
    path = FILES.get('trigger_reach_state_v938', BASE_DIR / 'paper_trigger_reach_state_v938.json')
    if not isinstance(state, dict):
        raise TypeError('trigger reach state must be dict')
    if not state.get('_dirty') and path.exists():
        return
    records = state.get('records') if isinstance(state.get('records'), dict) else {}
    if len(records) > 5000:
        ordered = sorted(records.items(), key=lambda kv: fnum((kv[1] or {}).get('last_seen_ts'), default=0.0), reverse=True)[:5000]
        records = dict(ordered)
    payload = {
        'schema':'paper_trigger_reach_state_v938','version':VERSION,'build':BUILD_LABEL,
        'updated_ts':now_ts(),'updated_text':iso_ts(),'count':len(records),'records':records,
        'policy':'first paper-final-safety trigger reach per exact decision key; no trigger formula or gate change',
    }
    save_json(path, payload)

def _v926_mark_decision(row: Dict[str, Any], status: str, *, pos_id: str = '', reason: str = '') -> bool:
    key = _v926_decision_key_from_row(row)
    if not key:
        return False
    state = _v926_load_decision_state()
    records = state['records']
    prior = records.get(key) if isinstance(records.get(key), dict) else {}
    prior_status = str(prior.get('status') or '').upper()
    if str(status).upper() == 'OPEN' and prior_status in ('OPEN', 'CLOSED'):
        return False
    nowv = now_ts()
    rec = dict(prior)
    rec.update({
        'status': status, 'paper_decision_key_v926': key,
        'pos_id': pos_id or row.get('pos_id') or prior.get('pos_id'),
        'ticker': normalize_ticker(row.get('ticker') or row.get('market') or row.get('symbol') or prior.get('ticker')),
        'last_seen_ts': nowv, 'last_reason': reason or '-',
    })
    quality_evidence = _v938_quality_evidence_from_row(row)
    for evidence_key, evidence_value in quality_evidence.items():
        if evidence_value not in (None, '', [], {}):
            rec[evidence_key] = evidence_value
    if status == 'OPEN':
        rec['opened_ts'] = fnum(row.get('opened_at'), row.get('opened_ts'), default=0.0) or nowv
    if status == 'CLOSED':
        rec['closed_ts'] = fnum(row.get('closed_ts'), row.get('closed_at'), default=0.0) or nowv
        rec['closed_result_key'] = row.get('closed_result_key') or f'closed:{key}'
    records[key] = rec
    event = {
        'schema':'paper_decision_event_v926','version':VERSION,'build':BUILD_LABEL,
        'ts':nowv,'ts_text':iso_ts(nowv),'status':status,'paper_decision_key_v926':key,
        'pos_id':rec.get('pos_id'),'ticker':rec.get('ticker'),'reason':reason or '-',
        'closed_result_key':rec.get('closed_result_key'),
        'first_to_paper_delay_sec':rec.get('first_to_paper_delay_sec'),
        's1_to_paper_delay_sec':rec.get('s1_to_paper_delay_sec'),
        'trigger_reached_ts':rec.get('trigger_reached_ts'),
        'trigger_frozen_ts':rec.get('trigger_frozen_ts'),
        'entry_trigger_gap_pct':rec.get('entry_trigger_gap_pct'),
        'first_seen_ts':rec.get('first_seen_ts'),
        's1_seen_ts':rec.get('s1_seen_ts'),
        'trigger_reached_ts_source_v938':rec.get('trigger_reached_ts_source_v938'),
        'paper_selected_ts':rec.get('paper_selected_ts'),
        'first_to_selected_delay_sec':rec.get('first_to_selected_delay_sec'),
        's1_to_selected_delay_sec':rec.get('s1_to_selected_delay_sec'),
        'trigger_to_selected_delay_sec':rec.get('trigger_to_selected_delay_sec'),
        'selected_to_open_delay_sec':rec.get('selected_to_open_delay_sec'),
        'timing_spine_schema_v940':rec.get('timing_spine_schema_v940'),
        'quality_evidence_schema_v938':rec.get('quality_evidence_schema_v938'),
    }
    append_jsonl(FILES.get('decision_events_v926', BASE_DIR / 'paper_decision_events_v926.jsonl'), event)
    state['last_event'] = event
    return _v926_save_decision_state(state)

def _v926_note_decision_skip(state: Dict[str, Any], kind: str, ev: Dict[str, Any]) -> None:
    key_name = 'duplicate_blocked_total' if kind == 'duplicate' else 'decision_key_missing_total'
    state[key_name] = int(fnum(state.get(key_name), default=0)) + 1
    state['last_event'] = {
        'schema':'paper_decision_event_v926','version':VERSION,'build':BUILD_LABEL,
        'ts':now_ts(),'ts_text':iso_ts(),'status':'SKIP','reason':kind,
        'paper_decision_key_v926':_v926_decision_key_from_row(ev),
        'ticker':normalize_ticker(ev.get('ticker') or ev.get('market') or ev.get('symbol')),
    }

def _v1037_text(value: Any) -> str:
    if value in (None, '', '-', [], {}):
        return ''
    return str(value).strip()

def _v1037_first_dict(*values: Any) -> Dict[str, Any]:
    for value in values:
        if isinstance(value, dict) and value:
            return value
    return {}

def _v1037_file_signature(path: Path) -> Dict[str, Any]:
    try:
        st=path.stat()
        return {'inode':int(st.st_ino),'size':int(st.st_size),'mtime_ns':int(st.st_mtime_ns)}
    except Exception:
        return {'inode':-1,'size':-1,'mtime_ns':-1}

def _v1037_candidate_key(row: Dict[str, Any]) -> str:
    row=row if isinstance(row,dict) else {}
    occurrence=_v1037_first_dict(row.get('trigger_occurrence'), (read_strategy_entry_gate(row).get('trigger_occurrence') if 'read_strategy_entry_gate' in globals() else None))
    evidence=_v1037_first_dict(row.get('entry_evidence_v983'),row.get('entry_evidence'))
    for value in (occurrence.get('candidate_key'),row.get('trigger_occurrence_candidate_key'),row.get('candidate_entry_build_key'),row.get('entry_build_key'),evidence.get('candidate_key'),row.get('event_id'),row.get('event_key')):
        text=_v1037_text(value)
        if text: return text
    return ''

def _v1037_occurrence(row: Dict[str, Any], gate: Dict[str, Any]) -> Dict[str, Any]:
    return _v1037_first_dict((gate or {}).get('trigger_occurrence'), row.get('trigger_occurrence'), (((gate or {}).get('structure_plan') or {}).get('trigger_occurrence') if isinstance((gate or {}).get('structure_plan'),dict) else None))

def _v1037_loss_reentry_gate(ev: Dict[str, Any], prior: Dict[str, Any], trigger_gate: Dict[str, Any]) -> Dict[str, Any]:
    ticker=normalize_ticker(ev.get('ticker') or ev.get('market') or ev.get('symbol'))
    gate=read_strategy_entry_gate(ev)
    occurrence=_v1037_occurrence(ev,gate)
    decision=_v1037_text(read_strategy_decision_key(ev,gate))
    candidate=_v1037_candidate_key(ev)
    trigger_price=fnum((trigger_gate or {}).get('trigger_price'),occurrence.get('trigger_price'),ev.get('swing_trigger_price_v977'),ev.get('trigger_price'),default=0.0)
    current={'ticker':ticker,'candidate_key':candidate or None,'decision_key':decision or None,'trigger_price':trigger_price or None,'trigger_reached':bool((trigger_gate or {}).get('trigger_reached')),'occurrence':occurrence or None}
    if not isinstance(prior,dict) or not prior:
        return {'schema':'loss_reentry_gate_v1037','allowed':True,'state':'NO_PRIOR_LOSS','current':current,'prior':None,'requirements':{},'policy':'normal ALT_SWING gate; no previous loss'}
    prior_candidate=_v1037_text(prior.get('candidate_key')); prior_decision=_v1037_text(prior.get('decision_key'))
    prior_closed=fnum(prior.get('closed_ts'),default=0.0); prior_trigger=fnum(prior.get('trigger_price'),default=0.0); prior_exit=fnum(prior.get('exit_price'),default=0.0)
    reset_ts=fnum(occurrence.get('reset_ts'),default=0.0); rebreak_ts=fnum(occurrence.get('rebreak_ts'),default=0.0); plan_frozen_ts=fnum(occurrence.get('plan_frozen_ts'),default=0.0)
    exit_reset=bool(prior_closed>0 and prior_trigger>0 and prior_exit>0 and prior_exit<prior_trigger)
    occurrence_reset=bool(reset_ts>prior_closed>0)
    occurrence_rebreak=bool(str(occurrence.get('kind') or '') in {'QUALIFIED_PATH_REBREAK','REBREAK'} and rebreak_ts>reset_ts>prior_closed>0)
    requirements={
        'prior_identity_complete':bool(prior.get('identity_complete') and prior_candidate and prior_decision and prior_trigger>0 and prior_closed>0),
        'current_candidate_key_ready':bool(candidate),'current_decision_key_ready':bool(decision),
        'new_candidate_key':bool(candidate and prior_candidate and candidate!=prior_candidate),
        'new_decision_key':bool(decision and prior_decision and decision!=prior_decision),
        'reset_after_loss':bool(exit_reset or occurrence_reset),
        'trigger_rebreak_after_reset':bool(occurrence_rebreak),
        'paper_trigger_reached':bool((trigger_gate or {}).get('trigger_reached')),
    }
    allowed=all(requirements.values())
    if not requirements['prior_identity_complete']: state='PRIOR_IDENTITY_MISSING_BLOCK'; reason='이전 손실 candidate·decision·trigger·시각 근거 불완전'
    elif not requirements['current_candidate_key_ready'] or not requirements['current_decision_key_ready']: state='CURRENT_IDENTITY_MISSING'; reason='현재 trigger occurrence candidate 또는 decision key 누락'
    elif not requirements['new_candidate_key'] or not requirements['new_decision_key']: state='SAME_EVENT_BLOCK'; reason='이전 손실과 같은 candidate 또는 direct decision 사건'
    elif not requirements['reset_after_loss']: state='WAIT_TRIGGER_RESET'; reason='이전 손실 뒤 trigger 아래 리셋 미확인'
    elif not requirements['trigger_rebreak_after_reset'] or not requirements['paper_trigger_reached']: state='WAIT_TRIGGER_REBREAK'; reason='리셋 이후 trigger 재돌파 미확인'
    else: state='NEW_TRIGGER_REBREAK_CONFIRMED'; reason=''
    return {'schema':'loss_reentry_gate_v1037','allowed':allowed,'state':state,'reason':reason or None,'current':current,'prior':prior,'requirements':requirements,'reset_source':('prior_loss_exit_below_trigger' if exit_reset else ('strategy_reset_after_loss' if occurrence_reset else None)),'structure_line_change_required':False,'target_invalid_change_required':False,'policy':'4h/2h major and target/invalid may remain; require a post-loss below-trigger reset and a new Strategy-owned trigger occurrence'}

def _v1057_validate_loss_reentry_source(snapshot: Dict[str, Any], current_closed_signature: Dict[str, Any]) -> Tuple[bool, str, Dict[str, Any]]:
    src = snapshot if isinstance(snapshot, dict) else {}
    contract = src.get('loss_reentry_source_contract_v1057') if isinstance(src.get('loss_reentry_source_contract_v1057'), dict) else {}
    event_map = src.get('last_loss_event_by_ticker') if isinstance(src.get('last_loss_event_by_ticker'), dict) else None
    contract_sig = contract.get('closed_signature') if isinstance(contract.get('closed_signature'), dict) else {}
    checks = {
        'contract_schema': contract.get('schema') == 'loss_reentry_source_contract_v1057',
        'owner': contract.get('owner') == 'risk_worker',
        'source_complete': contract.get('source_complete') is True,
        'selection_owner': contract.get('latest_loss_selection') == 'max_numeric_closed_ts_per_ticker',
        'event_map': isinstance(event_map, dict),
        'event_count': isinstance(event_map, dict) and int(contract.get('event_count') or 0) == len(event_map),
        'signature_match': bool(contract_sig and contract_sig == current_closed_signature),
    }
    failed = [name for name, ok in checks.items() if not ok]
    ready = not failed
    reason = 'ready' if ready else 'contract_check_failed:' + ','.join(failed)
    return ready, reason, {
        'schema': 'paper_risk_consumer_check_v1057',
        'ready': ready,
        'reason': reason,
        'checks': checks,
        'producer_version_observed': str(src.get('version') or ''),
        'producer_schema_observed': str(src.get('schema') or ''),
        'contract': contract,
    }

def _v1099_hold_reason_code(reason: Any) -> str:
    text=str(reason or '').strip()
    low=text.lower()
    if not text: return 'UNKNOWN_HOLD'
    if '확정 미끄러짐 자료 없음' in text: return 'SLIPPAGE_SOURCE_MISSING'
    if '확정 미끄러짐 자료 오래됨' in text: return 'SLIPPAGE_STALE'
    if '확정 미끄러짐 과다' in text or ('미끄러짐' in text and '과다' in text): return 'SLIPPAGE_OVER_LIMIT'
    if '스프레드 자료 없음' in text: return 'SPREAD_SOURCE_MISSING'
    if '거래불가 스프레드' in text or ('스프레드' in text and '초과' in text): return 'SPREAD_OVER_LIMIT'
    if '호가·체결 자료 오래됨' in text or 'micro' in low: return 'ORDERFLOW_STALE'
    if '실시간 시세 오래됨' in text or 'ws' in low: return 'WS_STALE'
    if '실제 진입가 rr 계산불가' in low: return 'ACTUAL_ENTRY_RR_MISSING'
    if '실제 진입가 rr 부족' in low: return 'ACTUAL_ENTRY_RR_LOW'
    if '목표공간 계산불가' in text: return 'TARGET_ROOM_MISSING'
    if '목표공간 부족' in text: return 'TARGET_ROOM_LOW'
    if '방아쇠' in text and ('미도달' in text or '대기' in text): return 'TRIGGER_WAIT'
    if '추격' in text: return 'CHASE_OVER_LIMIT'
    if '가격반응' in text or 'reaction' in low: return 'REACTION_UNSAFE'
    if '같은 봉인 판정번호' in text or 'already' in low: return 'DECISION_ALREADY_CONSUMED'
    if '동일종목' in text: return 'SAME_TICKER_OPEN'
    if '신규 open 일시정지' in low: return 'NEW_OPEN_PAUSED'
    if 'open 상한' in low: return 'OPEN_LIMIT'
    if 'cycle 신규 open 상한' in low: return 'CYCLE_LIMIT'
    if 'trigger occurrence 만료' in text or 'stale_trigger_occurrence' in low: return 'STALE_TRIGGER_OCCURRENCE'
    if '새 가격경로 reset→rebreak' in text or 'wait_trigger_path' in low: return 'WAIT_TRIGGER_PATH'
    if 'trigger occurrence 시각' in text: return 'TRIGGER_OCCURRENCE_TIME_INVALID'
    if '손실' in text and ('재돌파' in text or 'trigger' in low): return 'LOSS_REENTRY_BLOCK'
    if '판정번호 없음' in text: return 'DECISION_KEY_MISSING'
    if '종목 식별정보 없음' in text: return 'TICKER_MISSING'
    if '실제 진입가격 정보 없음' in text: return 'ENTRY_PRICE_MISSING'
    if 'position id' in low: return 'POSITION_ID_DUPLICATE'
    if 'ttl' in low or 'timestamp' in low or '후보 원천' in text: return 'CANDIDATE_STALE'
    compact=re.sub(r'[^A-Z0-9]+','_',low.upper()).strip('_')
    if re.fullmatch(r'(?:\d+M_)?[0-9_]+', compact or '') or (compact.count('_') >= 5 and not re.search(r'[A-Z]{3,}', compact or '')):
        return 'UNMAPPED_SAFETY_REASON'
    return compact[:64] or 'INFORMATION_UNAVAILABLE'

def _v1122_structured_reason_codes(diag: Optional[Dict[str, Any]], reason_list: List[str]) -> List[str]:
    """Read canonical codes sealed by the final-safety owner.

    Before v1122 the funnel guessed a code from Korean free text. Numeric-heavy
    messages could fall into UNMAPPED_SAFETY_REASON even though Paper knew the
    exact branch that blocked the candidate. The source owner now seals code
    and message together; fallback parsing remains only for non-safety stages.
    """
    d=diag if isinstance(diag,dict) else {}
    records=d.get('paper_final_safety_reason_records_v1122') if isinstance(d.get('paper_final_safety_reason_records_v1122'),list) else []
    by_message={str(row.get('message') or '').strip():str(row.get('code') or '').strip().upper() for row in records if isinstance(row,dict)}
    out=[]
    for reason in reason_list:
        code=by_message.get(str(reason).strip()) or _v1099_hold_reason_code(reason)
        if code and code not in out: out.append(code)
    return out

def _v1099_compact_funnel_row(ev: Dict[str, Any], stage: str, reasons: Any, diag: Optional[Dict[str, Any]]=None) -> Dict[str, Any]:
    row=ev if isinstance(ev,dict) else {}
    d=diag if isinstance(diag,dict) else {}
    reason_list=[str(x).strip() for x in (reasons if isinstance(reasons,list) else [reasons]) if str(x).strip()]
    actual=d.get('actual_entry_contract_v1095') if isinstance(d.get('actual_entry_contract_v1095'),dict) else {}
    freshness=row.get('s1_hold_freshness_v790') if isinstance(row.get('s1_hold_freshness_v790'),dict) else {}
    gate=read_strategy_entry_gate(row) if 'read_strategy_entry_gate' in globals() else {}
    decision_key=read_strategy_decision_key(row,gate) if 'read_strategy_decision_key' in globals() else row.get('swing_gate_decision_key_v977')
    slip,slip_source=_v925_confirmed_slippage(row) if '_v925_confirmed_slippage' in globals() else (None,None)
    return {
        'ticker': normalize_ticker(row.get('ticker') or row.get('market') or row.get('symbol')),
        'stage': stage,
        'reason_codes': _v1122_structured_reason_codes(d, reason_list)[:8],
        'reasons': reason_list[:8],
        'candidate_key': row.get('entry_build_key') or row.get('candidate_uid') or row.get('event_key'),
        'decision_key': decision_key,
        'quality_rank': row.get('swing_quality_rank') or gate.get('swing_quality_rank'),
        'quality_rank_score': row.get('swing_quality_rank_score') or gate.get('swing_quality_rank_score'),
        'actual_entry_rr': actual.get('actual_entry_rr'),
        'actual_target_room_pct': actual.get('actual_target_room_pct'),
        'spread_pct': d.get('spread_pct_v925', row.get('spread_pct')),
        'confirmed_slippage_pct': d.get('confirmed_slippage_pct_v925', slip),
        'confirmed_slippage_source': d.get('confirmed_slippage_source_v925', slip_source),
        'entry_slippage_age_sec': row.get('entry_slippage_age_sec'),
        'entry_slippage_basis': row.get('entry_slippage_basis'),
        'entry_slippage_owner': row.get('entry_slippage_owner'),
        'entry_slippage_order_amount_state': row.get('entry_slippage_order_amount_state'),
        'execution_fresh_ok_v1039': gate.get('execution_fresh_ok_v1039', row.get('execution_fresh_ok_v1039')),
        'price_age_sec': row.get('price_age_sec', freshness.get('price_age')),
        'micro_age_sec': row.get('micro_age_sec', freshness.get('micro_age')),
        'orderflow_age_sec': row.get('orderflow_age_sec', freshness.get('orderflow_age')),
        'source_age_sec': row.get('source_age', freshness.get('source_age')),
        'ts': now_ts(),
    }

def _v1099_record_funnel_block(stats: Dict[str, Any], ev: Dict[str, Any], stage: str, reasons: Any, diag: Optional[Dict[str, Any]]=None) -> None:
    if not isinstance(stats,dict): return
    reason_list=[str(x).strip() for x in (reasons if isinstance(reasons,list) else [reasons]) if str(x).strip()]
    counts=stats.get('paper_entry_hold_reason_counts_v1099') if isinstance(stats.get('paper_entry_hold_reason_counts_v1099'),dict) else {}
    compact_row=_v1099_compact_funnel_row(ev,stage,reason_list or ['UNKNOWN_HOLD'],diag)
    for code in (compact_row.get('reason_codes') or ['UNKNOWN_HOLD']):
        counts[str(code)]=int(counts.get(str(code)) or 0)+1
    stats['paper_entry_hold_reason_counts_v1099']=dict(sorted(counts.items(),key=lambda kv:(-int(kv[1]),kv[0])))
    rows=stats.get('paper_entry_hold_rows_v1099') if isinstance(stats.get('paper_entry_hold_rows_v1099'),list) else []
    rows.append(compact_row)
    stats['paper_entry_hold_rows_v1099']=rows[-24:]
    stats['paper_entry_last_stage_v1099']=stage

def _v1102_record_funnel_terminal(stats: Dict[str, Any], ev: Dict[str, Any], stage: str, terminal: str, reasons: Any=None, diag: Optional[Dict[str, Any]]=None) -> None:
    """Seal exactly one terminal outcome for every S1 row evaluated by Paper.

    This is observability/accounting only. It does not change any gate, threshold,
    selector, OPEN limit or execution decision.
    """
    if not isinstance(stats,dict):
        return
    terminal_code=str(terminal or 'INFORMATION_UNAVAILABLE').strip().upper() or 'INFORMATION_UNAVAILABLE'
    stage_name='SELECTOR_DECIDED' if terminal_code=='SELECTED' else 'TERMINAL_BLOCKED'
    terminal_ts_v1153=_v1153_paper_event_once(stage_name,ev,reasons,{'terminal':terminal_code,'stage':stage})
    _v1153_set_path_ts(ev,'selector_decided_at' if terminal_code=='SELECTED' else 'terminal_blocked_at',terminal_ts_v1153)
    stats['paper_funnel_accounted_v1102']=int(stats.get('paper_funnel_accounted_v1102') or 0)+1
    terminal_counts=stats.get('paper_funnel_terminal_counts_v1102') if isinstance(stats.get('paper_funnel_terminal_counts_v1102'),dict) else {}
    terminal_counts[terminal_code]=int(terminal_counts.get(terminal_code) or 0)+1
    stats['paper_funnel_terminal_counts_v1102']=dict(sorted(terminal_counts.items(),key=lambda kv:(-int(kv[1]),kv[0])))
    stage_counts=stats.get('paper_funnel_stage_terminal_counts_v1102') if isinstance(stats.get('paper_funnel_stage_terminal_counts_v1102'),dict) else {}
    stage_counts[str(stage or '정보없음')]=int(stage_counts.get(str(stage or '정보없음')) or 0)+1
    stats['paper_funnel_stage_terminal_counts_v1102']=dict(sorted(stage_counts.items(),key=lambda kv:(-int(kv[1]),kv[0])))
    reason_list=[str(x).strip() for x in (reasons if isinstance(reasons,list) else [reasons]) if str(x).strip()]
    if terminal_code != 'SELECTED':
        _v1099_record_funnel_block(stats,ev,stage,reason_list or ['정보없음'],diag)
    row=_v1099_compact_funnel_row(ev,stage,reason_list or (['선택 완료'] if terminal_code=='SELECTED' else ['정보없음']),diag)
    row['terminal_v1102']=terminal_code
    rows=stats.get('paper_funnel_terminal_rows_v1102') if isinstance(stats.get('paper_funnel_terminal_rows_v1102'),list) else []
    rows.append(row)
    stats['paper_funnel_terminal_rows_v1102']=rows[-48:]

def _v1102_finalize_funnel_accounting(stats: Dict[str, Any]) -> None:
    if not isinstance(stats,dict):
        return
    numeric_keys=(
        's1_seen','s1_ttl_fresh_v1039','s1_execution_fresh_v1039','paper_ttl_pass_v1099',
        'paper_execution_pass_v1099','paper_final_safety_checked_v1099','paper_final_safety_pass_v1099',
        'paper_reentry_pass_v1099','selected_s1','paper_entry_hold','paper_final_block',
        'paper_funnel_accounted_v1102','open_writer_failed_v981'
    )
    for key in numeric_keys:
        try: stats[key]=int(stats.get(key) or 0)
        except Exception: stats[key]=0
    s1=int(stats.get('s1_seen') or 0)
    accounted=int(stats.get('paper_funnel_accounted_v1102') or 0)
    unclassified=max(0,s1-accounted)
    stats['paper_funnel_unclassified_v1102']=unclassified
    stats['paper_funnel_balance_ok_v1102']=bool(s1==accounted)
    stats['paper_funnel_contract_v1102']='S1 = SELECTED + BLOCKED/HELD/DUPLICATE/ERROR terminal outcomes'
    if unclassified:
        terminal_counts=stats.get('paper_funnel_terminal_counts_v1102') if isinstance(stats.get('paper_funnel_terminal_counts_v1102'),dict) else {}
        terminal_counts['INFORMATION_UNAVAILABLE']=int(terminal_counts.get('INFORMATION_UNAVAILABLE') or 0)+unclassified
        stats['paper_funnel_terminal_counts_v1102']=dict(sorted(terminal_counts.items(),key=lambda kv:(-int(kv[1]),kv[0])))

def select_candidates__L22385(ctrl: Dict[str, Any], open_pos: Dict[str, Dict[str, Any]]) -> Tuple[List[Tuple[str, Dict[str, Any]]], Dict[str, Any], List[Dict[str, Any]]]:
    """Single S1-only paper selection path. No S2 experiment and no duplicate plan gate."""
    stats: Dict[str, Any] = Counter()
    pipeline_v1150, committed_handoff_v1158 = _v1158_resolve_completed_handoff_v1158(ctrl)
    stats['strategy_candidate_pipeline_v1150'] = pipeline_v1150
    stats['paper_consumed_pipeline_cycle_id_v1158'] = pipeline_v1150.get('cycle_id')
    stats['paper_consumed_generation_source_v1158'] = pipeline_v1150.get('effective_generation_source_v1158')
    stats['paper_consumed_handoff_id_v1158'] = pipeline_v1150.get('committed_handoff_id_v1158')
    if pipeline_v1150.get('ready') is not True:
        stats['candidate_pipeline_blocked_v1150'] = 1
        stats['candidate_pipeline_block_reason_v1150'] = pipeline_v1150.get('reason')
        stats['candidate_pipeline_failed_checks_v1150'] = pipeline_v1150.get('failed_checks')
        return [], stats, []
    all_rows: List[Dict[str, Any]] = []
    latest_count = 0
    for name, _path, rows in candidate_sources(ctrl, committed_handoff_v1158):
        stats[f'{name}_read'] = int(stats.get(f'{name}_read', 0)) + len(rows)
        if name == 'paper_latest':
            stats['paper_latest_rows_v1039'] = len(rows)
            latest_count = len(rows)
        elif name == 's1_hold':
            stats['s1_hold_rows_v1039'] = len(rows)
        for row in rows:
            if isinstance(row, dict):
                item = dict(row)
                item.setdefault('_source_file', name)
                all_rows.append(item)
    filtered = latest_scan_filter(all_rows, ctrl)
    filtered.sort(key=lambda row:(0 if isinstance(row,dict) and row.get('open_eligible') is True else 1, int(fnum((row or {}).get('swing_quality_rank'),default=10**9)) if isinstance(row,dict) else 10**9, -fnum((row or {}).get('swing_quality_rank_score'),default=-1e9) if isinstance(row,dict) else 1e9, normalize_ticker((row or {}).get('ticker') or (row or {}).get('market') or (row or {}).get('symbol')) if isinstance(row,dict) else ''))
    stats['quality_rank_sort_owner_v1095']='strategy rank fields consumed by paper.select_candidates'
    stats['latest_scan_before'] = len(all_rows)
    stats['latest_scan_after'] = len(filtered)
    decision_state = _v926_seed_decision_state(open_pos)
    decision_records = decision_state.get('records') if isinstance(decision_state.get('records'), dict) else {}
    trigger_reach_state_v938 = _v938_load_trigger_reach_state()
    profitability_risk_snapshot_v1034 = load_json(BASE_DIR / 'clean_risk_filter_cache.json', {}) or {}
    if not isinstance(profitability_risk_snapshot_v1034, dict): profitability_risk_snapshot_v1034 = {}
    loss_event_map_v1037 = profitability_risk_snapshot_v1034.get('last_loss_event_by_ticker') if isinstance(profitability_risk_snapshot_v1034.get('last_loss_event_by_ticker'), dict) else {}
    current_closed_signature_v1037 = _v1037_file_signature(BASE_DIR / 'paper_bot_closed.jsonl')
    loss_reentry_source_ready_v1037, loss_reentry_source_reason_v1057, loss_reentry_source_diag_v1057 = _v1057_validate_loss_reentry_source(profitability_risk_snapshot_v1034, current_closed_signature_v1037)
    stats['loss_reentry_source_ready_v1037'] = loss_reentry_source_ready_v1037
    stats['loss_reentry_source_ready_v1057'] = loss_reentry_source_ready_v1037
    stats['loss_reentry_source_reason_v1057'] = loss_reentry_source_reason_v1057
    stats['loss_reentry_source_contract_v1057'] = loss_reentry_source_diag_v1057
    stats['loss_reentry_source_schema_v1037'] = profitability_risk_snapshot_v1034.get('schema')
    stats['loss_reentry_prior_events_v1037'] = len(loss_event_map_v1037)
    stats['loss_reentry_source_closed_signature_match_v1057'] = bool(((loss_reentry_source_diag_v1057.get('checks') or {}).get('signature_match')))
    stats['loss_reentry_closed_signature_match_v1037'] = stats['loss_reentry_source_closed_signature_match_v1057']
    profitability_market_snapshot_v1034 = load_json(BASE_DIR / 'clean_market_regime_cache.json', {}) or {}
    if not isinstance(profitability_market_snapshot_v1034, dict): profitability_market_snapshot_v1034 = {}
    existing_ids = set(open_pos.keys()) | closed_recent_ids()
    blocked_tickers = open_tickers(open_pos) if ctrl.get('block_same_ticker_open', True) else set()
    picked: List[Tuple[str, Dict[str, Any]]] = []
    max_new = int(fnum(ctrl.get('max_new_per_cycle'), default=0))
    max_open = int(fnum(ctrl.get('max_open_strict'), default=0))
    legacy_limit_contract_v1175 = ctrl.get('quality_rebuild_limit_contract_v1095') if isinstance(ctrl.get('quality_rebuild_limit_contract_v1095'),dict) else {}
    legacy_config_v1175 = legacy_limit_contract_v1175.get('configured_before_override') if isinstance(legacy_limit_contract_v1175.get('configured_before_override'),dict) else {}
    legacy_max_open_v1175 = int(fnum(legacy_config_v1175.get('max_open_strict'),default=0))
    legacy_max_new_v1175 = int(fnum(legacy_config_v1175.get('max_new_per_cycle'),default=0))
    legacy_pause_v1175 = bool(legacy_config_v1175.get('new_open_paused'))
    stats['audit_legacy_max_open_configured_v1175'] = legacy_max_open_v1175
    stats['audit_legacy_max_new_per_cycle_configured_v1175'] = legacy_max_new_v1175
    stats['audit_legacy_new_open_paused_configured_v1175'] = legacy_pause_v1175
    strict_open_now = _v734_strict_open_count(open_pos)
    stats['open_total_raw'] = len(open_pos or {})
    stats['strict_open_count_v734'] = strict_open_now
    stats['legacy_or_bad_open_ignored_v734'] = max(0, len(open_pos or {}) - strict_open_now)
    stats['paper_selection_owner'] = 'paper_bot.select_candidates'
    stats['paper_entry_gate_contract'] = 'swing_entry_gate_v977_single_owner'
    stats['paper_exact_decision_contract'] = 'strategy_frozen_plan_key'
    stats['decision_state_total_v926'] = len(decision_records)

    for ev in filtered:
        if _STOP:
            stats['stop_checkpoint_v994'] = 'candidate_loop'
            break
        if not isinstance(ev, dict):
            continue
        stats['last_seen_candidate'] = candidate_brief(ev, status='seen')
        ticker_v1037 = normalize_ticker(ev.get('ticker') or ev.get('market') or ev.get('symbol'))
        prior_loss_v1037 = loss_event_map_v1037.get(ticker_v1037) if isinstance(loss_event_map_v1037.get(ticker_v1037),dict) else {}
        is_hold = _v734_is_hold(ev)
        hold_status = _v734_hold_status(ev)
        if _v988_is_s3_observation_only(ev):
            stats['s3_observation_only_skip_v988'] = int(stats.get('s3_observation_only_skip_v988', 0)) + 1
            _record_decision(stats, 'last_skip', ev, 's3_observation_only_v988', 'S3 관찰·복기 전용 후보 OPEN 금지')
            continue
        if is_hold:
            stats['s1_hold_seen'] = int(stats.get('s1_hold_seen', 0)) + 1
            stats[f's1_hold_{hold_status or "unknown"}'] = int(stats.get(f's1_hold_{hold_status or "unknown"}', 0)) + 1
        is_s1 = is_strategy_s1_candidate(ev)
        if is_s1:
            terminal_consumption_v1160 = _v1160_existing_terminal_feedback(ev)
            if terminal_consumption_v1160.get('suppress') is True:
                stats['terminal_same_handoff_audit_only_v1174'] = int(stats.get('terminal_same_handoff_audit_only_v1174', 0)) + 1
                stats['last_terminal_same_handoff_audit_only_v1174'] = terminal_consumption_v1160
            if terminal_consumption_v1160.get('state') == 'NEW_HANDOFF_SAME_EVENT_REPUBLISH':
                stats['terminal_new_handoff_republish_v1160'] = int(stats.get('terminal_new_handoff_republish_v1160', 0)) + 1
                stats['last_terminal_new_handoff_republish_v1160'] = terminal_consumption_v1160
        freshness_v1039 = candidate_freshness_evidence_v1039(ev, ctrl)
        if freshness_v1039.get('fresh') is True:
            stats['ttl_fresh_total_v1039'] = int(stats.get('ttl_fresh_total_v1039', 0)) + 1
        else:
            stats['ttl_stale_total_v1039'] = int(stats.get('ttl_stale_total_v1039', 0)) + 1
        if is_s1:
            stats['s1_seen'] = int(stats.get('s1_seen', 0)) + 1
            paper_received_at_v1153 = _v1153_paper_event_once('PAPER_RECEIVED',ev,extra={
                'pipeline_cycle_id':ev.get('candidate_pipeline_cycle_id_v1150'),
                'hold_created_at':ev.get('s1_hold_created_at_v1153') or ev.get('hold_created_at'),
            })
            _v1153_set_path_ts(ev,'paper_received_at',paper_received_at_v1153)
            if freshness_v1039.get('fresh') is True:
                stats['s1_ttl_fresh_v1039'] = int(stats.get('s1_ttl_fresh_v1039', 0)) + 1
            else:
                stats['s1_ttl_stale_v1039'] = int(stats.get('s1_ttl_stale_v1039', 0)) + 1
            strategy_gate_v1039 = read_strategy_entry_gate(ev)
            if strategy_gate_v1039.get('execution_fresh_ok_v1039') is True:
                stats['s1_execution_fresh_v1039'] = int(stats.get('s1_execution_fresh_v1039', 0)) + 1
            _record_decision(stats, 'last_s1_seen', ev, 's1_seen')

        if is_hold and hold_status in {'stale_hold','trigger_wait'}:
            stats['s1_hold_late_status_audit_only_v1174'] = int(stats.get('s1_hold_late_status_audit_only_v1174',0)) + 1
            _v734_trace_hold(ev, f'{hold_status}_audit_only_v1174', ev.get('stale_reasons') or [])
        if not is_s1:
            stats['not_s1_skip'] = int(stats.get('not_s1_skip', 0)) + 1
            continue
        occurrence_freshness=trigger_occurrence_freshness(ev,ctrl)
        delay_path_v1152=candidate_delay_path_v1152(ev,pipeline_v1150,ctrl)
        occurrence_freshness['delay_path_v1152']=delay_path_v1152
        ev['trigger_occurrence_freshness']=occurrence_freshness
        ev['candidate_delay_path_v1152']=delay_path_v1152
        _v1152_record_delay_summary(stats,delay_path_v1152,str(occurrence_freshness.get('code') or 'UNKNOWN'))
        occurrence_code=str(occurrence_freshness.get('code') or 'TTL_DISABLED_RAW_MODE')
        if occurrence_freshness.get('would_be_fresh_v1174') is False or occurrence_freshness.get('raw_identity_ready_v1174') is False:
            stats['trigger_occurrence_audit_issue_v1174']=int(stats.get('trigger_occurrence_audit_issue_v1174',0))+1
        stats['trigger_occurrence_fresh_pass']=int(stats.get('trigger_occurrence_fresh_pass',0))+1
        stats['open_limit_disabled_v1174']=True
        stats['cycle_limit_disabled_v1174']=True
        if ((ctrl.get('quality_rebuild_limit_contract_v1095') or {}).get('configured_before_override') or {}).get('new_open_paused') is True:
            stats['new_open_paused_audit_only_v1174'] = int(stats.get('new_open_paused_audit_only_v1174', 0)) + 1
        if freshness_v1039.get('would_be_fresh_v1174') is False:
            stats['candidate_ttl_audit_issue_v1174'] = int(stats.get('candidate_ttl_audit_issue_v1174',0)) + 1
        stats['paper_ttl_pass_v1099']=int(stats.get('paper_ttl_pass_v1099',0))+1
        micro_ok_v1174=micro_fresh(ev,ctrl)
        ws_ok_v1174=ws_fresh(ev)
        if not micro_ok_v1174:
            stats['micro_fresh_audit_issue_v1174']=int(stats.get('micro_fresh_audit_issue_v1174',0))+1
        if not ws_ok_v1174:
            stats['ws_fresh_audit_issue_v1174']=int(stats.get('ws_fresh_audit_issue_v1174',0))+1
        stats['paper_execution_pass_v1099']=int(stats.get('paper_execution_pass_v1099',0))+1
        execution_ready_at_v1153 = _v1153_paper_event_once('EXECUTION_DATA_READY',ev,extra={
            'micro_fresh':micro_ok_v1174,'ws_fresh':ws_ok_v1174,'ws_required':False,
            'slippage_ts':ev.get('entry_slippage_ts'),'slippage_age_sec':ev.get('entry_slippage_age_sec'),
        })
        _v1153_set_path_ts(ev,'execution_data_ready_at',execution_ready_at_v1153)

        ticker = normalize_ticker(ev.get('ticker') or ev.get('market') or ev.get('symbol'))
        price = get_event_price(ev)
        if not ticker:
            stats['ticker_missing_skip'] = int(stats.get('ticker_missing_skip', 0)) + 1
            _v1102_record_funnel_terminal(stats,ev,'identity','ERROR',['종목 식별정보 없음'])
            continue
        if price <= 0:
            stats['price_missing_skip'] = int(stats.get('price_missing_skip', 0)) + 1
            _v1102_record_funnel_terminal(stats,ev,'entry_price','ERROR',['실제 진입가격 정보 없음'])
            continue
        decision_key = read_strategy_decision_key(ev, read_strategy_entry_gate(ev))
        if not decision_key:
            stats['decision_key_missing_v926'] = int(stats.get('decision_key_missing_v926', 0)) + 1
            _record_decision(stats, 'last_skip', ev, 'decision_key_missing_v926', '전략 봉인 판정번호 없음')
            _v926_note_decision_skip(decision_state, 'decision_key_missing', ev)
            _v1102_record_funnel_terminal(stats,ev,'decision_identity','ERROR',['전략 봉인 판정번호 없음'])
            continue
        eid = f'decision:{decision_key}'
        if decision_key in decision_records:
            stats['decision_already_consumed_v926'] = int(stats.get('decision_already_consumed_v926', 0)) + 1
            _record_decision(stats, 'last_skip', ev, 'already_consumed_exact_v926', '같은 봉인 판정번호는 이미 OPEN 또는 CLOSED 처리됨')
            if is_hold:
                _v734_trace_hold(ev, 'already_consumed_exact_v926', decision_key)
            _v926_note_decision_skip(decision_state, 'duplicate', ev)
            _v1102_record_funnel_terminal(stats,ev,'decision_identity','DUPLICATE',['같은 봉인 판정번호는 이미 OPEN 또는 CLOSED 처리됨'])
            continue
        if eid in existing_ids:
            stats['dup_skip'] = int(stats.get('dup_skip', 0)) + 1
            _v1102_record_funnel_terminal(stats,ev,'position_identity','DUPLICATE',['같은 Paper position id가 이미 존재'])
            continue
        if ctrl.get('block_same_ticker_open', True) and ticker in blocked_tickers:
            stats['same_ticker_skip'] = int(stats.get('same_ticker_skip', 0)) + 1
            _v1102_record_funnel_terminal(stats,ev,'same_ticker','DUPLICATE',['동일종목 OPEN 또는 동일 cycle 선택 존재'])
            continue

        stats['paper_final_safety_checked_v1099']=int(stats.get('paper_final_safety_checked_v1099',0))+1
        ok, reasons, diag = paper_final_safety(ev, ctrl)
        trigger_gate_v938 = diag.get('trigger_gate') if isinstance(diag.get('trigger_gate'), dict) else {}
        _v938_note_trigger_reach(trigger_reach_state_v938, ev, trigger_gate_v938)
        if reasons:
            stats['paper_final_safety_audit_issue_v1174']=int(stats.get('paper_final_safety_audit_issue_v1174',0))+1
        stats['paper_final_safety_pass_v1099']=int(stats.get('paper_final_safety_pass_v1099',0))+1

        if not loss_reentry_source_ready_v1037:
            stats['loss_reentry_source_audit_issue_v1174'] = int(stats.get('loss_reentry_source_audit_issue_v1174',0))+1
        reentry_gate_v1037=_v1037_loss_reentry_gate(ev,prior_loss_v1037,trigger_gate_v938)
        ev['loss_reentry_gate_v1037']=reentry_gate_v1037
        state_v1037=str(reentry_gate_v1037.get('state') or 'UNKNOWN')
        stats[f'loss_reentry_{state_v1037.lower()}_v1037']=int(stats.get(f'loss_reentry_{state_v1037.lower()}_v1037',0))+1
        if reentry_gate_v1037.get('allowed') is not True:
            stats['loss_reentry_audit_issue_v1174']=int(stats.get('loss_reentry_audit_issue_v1174',0))+1
        stats['paper_reentry_pass_v1099']=int(stats.get('paper_reentry_pass_v1099',0))+1
        if state_v1037=='NEW_TRIGGER_REBREAK_CONFIRMED': stats['loss_reentry_new_trigger_rebreak_v1037']=int(stats.get('loss_reentry_new_trigger_rebreak_v1037',0))+1

        legacy_would_reasons_v1175: List[str] = []
        if legacy_pause_v1175:
            stats['audit_would_block_new_open_pause_v1175'] = int(stats.get('audit_would_block_new_open_pause_v1175',0)) + 1
            legacy_would_reasons_v1175.append('NEW_OPEN_PAUSED')
        if legacy_max_open_v1175 > 0 and (strict_open_now + len(picked)) >= legacy_max_open_v1175:
            stats['audit_would_block_open_limit_v1175'] = int(stats.get('audit_would_block_open_limit_v1175',0)) + 1
            legacy_would_reasons_v1175.append('OPEN_LIMIT')
        if legacy_max_new_v1175 > 0 and len(picked) >= legacy_max_new_v1175:
            stats['audit_would_block_cycle_limit_v1175'] = int(stats.get('audit_would_block_cycle_limit_v1175',0)) + 1
            legacy_would_reasons_v1175.append('CYCLE_LIMIT')
        if legacy_would_reasons_v1175:
            stats['audit_would_block_any_limit_v1175'] = int(stats.get('audit_would_block_any_limit_v1175',0)) + 1

        selected = dict(ev)
        mark_paper_selected_for_open(selected, diag, stats)
        selected['paper_decision_key_v926'] = decision_key
        selected['paper_pos_id_v926'] = eid
        selected['lane'] = 'strict'
        selected['paper_experiment_lane'] = None
        selected['real_eligible'] = False
        selected['auto_buy_ready'] = False
        selected['buy_ready'] = False
        selected['paper_final_safety_passed'] = True
        selected['paper_final_safety_diagnostics'] = diag
        selected['paper_raw_intake_v1174'] = True
        selected['paper_raw_audit_reasons_v1174'] = list(reasons or [])
        selected['paper_final_safety_would_pass_v1174'] = bool(diag.get('paper_final_safety_would_pass_v1174'))
        selected['legacy_limit_audit_v1175'] = {
            'schema':'paper_legacy_limit_audit_v1175','blocking':False,
            'configured_max_open':legacy_max_open_v1175,'configured_max_new_per_cycle':legacy_max_new_v1175,
            'configured_new_open_paused':legacy_pause_v1175,'would_block_reasons':list(legacy_would_reasons_v1175),
            'open_count_before':strict_open_now + len(picked),'new_index_in_cycle':len(picked)+1,
        }
        selected['loss_reentry_gate_v1037'] = reentry_gate_v1037
        selected['trigger_occurrence_freshness'] = trigger_occurrence_freshness(selected,ctrl)
        selected['reentry_event_identity_v1037'] = reentry_gate_v1037.get('current')
        cooldown_map = profitability_risk_snapshot_v1034.get('cooldown') if isinstance(profitability_risk_snapshot_v1034.get('cooldown'), dict) else {}
        cooldown_item = cooldown_map.get(ticker) if isinstance(cooldown_map.get(ticker), dict) else {}
        qv = _profitability_quality_fields(selected)
        spread_audit = _v987_perf_num(selected.get('spread_pct'), selected.get('micro_spread_pct'), qv.get('spread_pct'), default=None)
        buy_audit = qv.get('buy_ratio'); sustain_audit = qv.get('buy_sustain_1m')
        late_risk_audit = bool((buy_audit is not None and buy_audit < 0.70) or (sustain_audit is not None and sustain_audit < 0.70) or (spread_audit is not None and spread_audit > 0.35) or bool(qv.get('long_upper_wick')))
        source_lane = str(selected.get('_source_file') or selected.get('source_lane') or 'candidate').strip()
        method_blob = ' '.join(str(selected.get(k) or '') for k in ('strategy','strategy_key','strategy_label','final_entry_label')).lower()
        selected['paper_open_count_before_v1034'] = strict_open_now + len(picked)
        selected['paper_new_index_in_cycle_v1034'] = len(picked) + 1
        selected['profitability_preopen_evidence_v1034'] = {
            'schema':'profitability_preopen_evidence_v1034','sealed_at':now_ts(),'ticker':ticker,
            'open_count_before':strict_open_now + len(picked),'new_index_in_cycle':len(picked)+1,
            'source_lane':source_lane,'hot_rank_lane':bool('hot-rank' in method_blob or 'hot_rank' in method_blob),
            'risk':{'cache_updated_ts':profitability_risk_snapshot_v1034.get('updated_ts'),'cooldown_active':bool(cooldown_item),'level':cooldown_item.get('level') if cooldown_item else None,'reasons':list(cooldown_item.get('reasons') or []) if cooldown_item else [],'last_profit':cooldown_item.get('last_profit') if cooldown_item else None,'last_ts':cooldown_item.get('last_ts') if cooldown_item else None},
            'market_regime':{k:profitability_market_snapshot_v1034.get(k) for k in ('schema','version','updated_ts','mode','score','row_count','breadth_up_pct','strong_count','avg_top60_change','top30_turnover')},
            'quality':qv,'late_risk_audit':late_risk_audit,'loss_reentry_gate_v1037':reentry_gate_v1037,
            'policy':'OPEN-time evidence; v1174 late safety and reentry findings are audit-only; exact S1/duplicate/commit integrity remains',
        }
        _record_decision(stats, 'last_open_try', selected, 'selected_for_open', 'v979 ALT_SWING swing-only contract 통과')
        picked.append((eid, selected))
        existing_ids.add(eid)
        blocked_tickers.add(ticker)
        stats['selected_s1'] = int(stats.get('selected_s1', 0)) + 1
        stats['selected_exact_decision_v926'] = int(stats.get('selected_exact_decision_v926', 0)) + 1
        _v1102_record_funnel_terminal(stats,selected,'selector','SELECTED',['선택 완료'],diag)

    stats['latest_count'] = latest_count
    stats['merged_fresh'] = sum(1 for row in filtered if candidate_is_fresh(row, ctrl))
    stats['candidate_freshness_schema_v1039'] = 'v1174 audit-only age evidence; TTL and freshness do not block raw Paper intake'
    stats['paper_raw_intake_v1174'] = True
    stats['late_safety_block_count_v1174'] = 0
    stats['quality_metric_hard_block_count_v1039'] = int(stats.get('paper_final_block',0))
    stats['quality_metric_role_v1039'] = 'strategy exact S1 selects; Paper late safety is audit-only v1174'
    stats['max_open_strict_v1095'] = max_open
    stats['max_new_per_cycle_v1095'] = max_new
    stats['paper_experiment_enabled'] = False
    stats['obsolete_minimal_gate_consumed_v979'] = 0
    _v1102_finalize_funnel_accounting(stats)
    write_paper_timing_spine_status(stats, picked)
    _v926_save_decision_state(decision_state)
    _v938_save_trigger_reach_state(trigger_reach_state_v938)
    return picked, dict(stats), filtered

_V1017_DECISION_MATERIAL_SIGNATURE: Optional[str] = None

_V1017_DECISION_SAVE_CALLS = 0

_V1017_DECISION_WRITE_COUNT = 0

_V1017_DECISION_NOOP_SKIP_COUNT = 0

_V1017_DECISION_LAST_WRITE_AT = 0.0

_V1017_DECISION_LAST_WRITE_BYTES = 0

_V1017_PERF_CHECK_COUNT = 0

_V1017_PERF_WRITE_COUNT = 0

_V1017_PERF_SKIP_COUNT = 0

_V1017_PERF_LAST_REASON = 'startup'

def _v1017_decision_material_signature(state: Dict[str, Any]) -> str:
    records = state.get('records') if isinstance(state, dict) and isinstance(state.get('records'), dict) else {}
    material = {
        'records_digest': _paper_json_digest(records),
        'last_reconcile_v967': state.get('last_reconcile_v967') if isinstance(state, dict) and isinstance(state.get('last_reconcile_v967'), dict) else None,
    }
    return _paper_json_digest(material)

def _v1017_existing_decision_material_signature() -> str:
    path = FILES.get('decision_state_v926', BASE_DIR / 'paper_decision_state_v926.json')
    obj = load_json(path, {}) or {}
    return _v1017_decision_material_signature(obj if isinstance(obj, dict) else {})

def _v926_save_decision_state__L22754(state: Dict[str, Any]) -> bool:  # type: ignore[override]
    """Persist only canonical record/reconcile changes; keep verified original commit path."""
    global _V1017_DECISION_MATERIAL_SIGNATURE, _V1017_DECISION_SAVE_CALLS
    global _V1017_DECISION_WRITE_COUNT, _V1017_DECISION_NOOP_SKIP_COUNT
    global _V1017_DECISION_LAST_WRITE_AT, _V1017_DECISION_LAST_WRITE_BYTES
    _V1017_DECISION_SAVE_CALLS += 1
    state_path = FILES.get('decision_state_v926', BASE_DIR / 'paper_decision_state_v926.json')
    status_path = FILES.get('decision_status_v926', BASE_DIR / 'paper_decision_status_v926.json')
    current_sig = _v1017_decision_material_signature(state if isinstance(state, dict) else {})
    if _V1017_DECISION_MATERIAL_SIGNATURE is None:
        _V1017_DECISION_MATERIAL_SIGNATURE = _v1017_existing_decision_material_signature()
    if state_path.exists() and status_path.exists() and current_sig == _V1017_DECISION_MATERIAL_SIGNATURE:
        _V1017_DECISION_NOOP_SKIP_COUNT += 1
        return True
    ok = bool(_V1017_PREV_SAVE_DECISION_STATE(state))
    if ok:
        _V1017_DECISION_MATERIAL_SIGNATURE = current_sig
        _V1017_DECISION_WRITE_COUNT += 1
        _V1017_DECISION_LAST_WRITE_AT = now_ts()
        try:
            _V1017_DECISION_LAST_WRITE_BYTES = int(state_path.stat().st_size)
        except Exception:
            _V1017_DECISION_LAST_WRITE_BYTES = 0
    return ok

def _canonical_performance_source_signature__L22780(now_value: Optional[float] = None) -> Tuple[Any, ...]:  # type: ignore[override]
    """Exact membership signature: append-only CLOSED cursor + CLOSED-only decision digest."""
    out: List[Any] = []
    closed_path = BASE_DIR / 'paper_bot_closed.jsonl'
    try:
        st = closed_path.stat()
        out.extend((closed_path.name, int(st.st_ino), int(st.st_size)))
    except FileNotFoundError:
        out.extend((closed_path.name, -1, -1))
    decision_status = _v987_perf_read_json(BASE_DIR / 'paper_decision_status_v926.json', {}) or {}
    closed_digest = str(decision_status.get('closed_records_digest_v1092') or '').strip() if isinstance(decision_status, dict) else ''
    if not closed_digest:
        decision_state = _v987_perf_read_json(BASE_DIR / 'paper_decision_state_v926.json', {}) or {}
        records = decision_state.get('records') if isinstance(decision_state, dict) and isinstance(decision_state.get('records'), dict) else {}
        closed_records = {str(k): v for k, v in records.items() if isinstance(v, dict) and str(v.get('status') or '').upper() == 'CLOSED'}
        closed_digest = _paper_json_digest(closed_records)
    out.extend(('paper_closed_decision_records_digest_v1092', closed_digest))
    return tuple(out)

def _v1017_paper_io_evidence() -> Dict[str, Any]:
    state_path = FILES.get('decision_state_v926', BASE_DIR / 'paper_decision_state_v926.json')
    perf_path = BASE_DIR / 'canonical_performance_snapshot_v987.json'
    try:
        state_bytes = int(state_path.stat().st_size)
    except Exception:
        state_bytes = 0
    try:
        perf_bytes = int(perf_path.stat().st_size)
    except Exception:
        perf_bytes = 0
    return {
        'schema': 'paper_io_evidence_v1018', 'version': VERSION, 'build': BUILD_LABEL,
        'writer_pid': os.getpid(), 'updated_at': now_ts(),
        'decision_save_calls': _V1017_DECISION_SAVE_CALLS,
        'decision_write_count': _V1017_DECISION_WRITE_COUNT,
        'decision_noop_skip_count': _V1017_DECISION_NOOP_SKIP_COUNT,
        'decision_last_write_at': _V1017_DECISION_LAST_WRITE_AT or None,
        'decision_last_write_bytes': _V1017_DECISION_LAST_WRITE_BYTES,
        'decision_state_bytes': state_bytes,
        'performance_check_count': _V1017_PERF_CHECK_COUNT,
        'performance_write_count_v1017': _V1017_PERF_WRITE_COUNT,
        'performance_skip_count_v1017': _V1017_PERF_SKIP_COUNT,
        'performance_last_reason': _V1017_PERF_LAST_REASON,
        'canonical_performance_write_count': int(globals().get('_PERFORMANCE_WRITE_COUNT', 0) or 0),
        'canonical_snapshot_bytes': perf_bytes,
        'source_signature_policy': 'closed append identity + decision records_digest; no decision mtime noise',
        'seed_calls_v1018': _V1018_SEED_CALLS,
        'seed_noop_count_v1018': _V1018_SEED_NOOP_COUNT,
        'seed_open_change_count_v1018': _V1018_SEED_OPEN_CHANGE_COUNT,
        'seed_closed_change_count_v1018': _V1018_SEED_CLOSED_CHANGE_COUNT,
        'closed_incremental_read_calls_v1018': _V1018_CLOSED_INCREMENTAL_READ_CALLS,
        'closed_incremental_read_bytes_v1018': _V1018_CLOSED_INCREMENTAL_READ_BYTES,
        'closed_incremental_rows_v1018': _V1018_CLOSED_INCREMENTAL_ROWS,
        'closed_recovery_tail_scans_v1018': _V1018_CLOSED_RECOVERY_TAIL_SCANS,
        'decision_write_policy': 'verified write only when canonical records/reconcile digest changes',
    }

def write_status__L22853(status: Dict[str, Any]) -> None:  # type: ignore[override]
    out = dict(status or {})
    out['paper_io_v1018'] = _v1017_paper_io_evidence()
    out['paper_io_v1017'] = out['paper_io_v1018']
    _V1017_PREV_WRITE_STATUS(out)

BOOK_RESET_CONTROL_V1044 = BASE_DIR / 'paper_quality_rebuild_control_v1095.json'

BOOK_RESET_MANIFEST_V1044 = BASE_DIR / 'paper_quality_rebuild_manifest_v1095.json'

BOOK_RESET_STATUS_V1044 = BASE_DIR / 'paper_quality_rebuild_status_v1095.json'

def _v1044_reset_pos_id(pid: Any, row: Dict[str, Any]) -> str:
    for value in (pid, row.get('pos_id'), row.get('position_id'), row.get('entry_build_key'), row.get('execution_key_v1037')):
        text = str(value or '').strip()
        if text:
            return text
    return '-'

def select_candidates__L23042(ctrl: Dict[str, Any], open_pos: Dict[str, Dict[str, Any]]):  # type: ignore[override]
    picked, stats, latest = _V1044_PREV_SELECT_CANDIDATES(ctrl, open_pos)
    stats = dict(stats or {})
    legacy_control = load_json(BOOK_RESET_CONTROL_V1044, {}) or {}
    stats['book_reset_entry_freeze_v1044'] = False
    stats['book_reset_audit_only_v1174'] = True
    stats['legacy_book_reset_state_v1174'] = legacy_control.get('state')
    stats['legacy_book_reset_entry_freeze_v1174'] = bool(legacy_control.get('entry_freeze', False))
    stats['book_reset_blocked_new_open_count_v1044'] = 0
    return picked, stats, latest

PERFORMANCE_EPOCH_V1045 = BASE_DIR / 'paper_quality_rebuild_epoch_v1095.json'

EXIT_LABELS['quality_rebuild_reset_v1095'] = '🧹 품질 재구축 기존 OPEN 정리'

def _v1045_manifest() -> Dict[str, Any]:
    obj = load_json(BOOK_RESET_MANIFEST_V1044, {}) or {}
    return obj if isinstance(obj, dict) else {}

def _v1045_epoch() -> Dict[str, Any]:
    obj = load_json(PERFORMANCE_EPOCH_V1045, {}) or {}
    return obj if isinstance(obj, dict) else {}

def _v1045_perf_compact_row(row: Dict[str, Any], key: str, match_mode: str) -> Dict[str, Any]:
    out = _V1045_PREV_PERF_COMPACT_ROW(row, key, match_mode)
    out['performance_epoch_id'] = str(row.get('performance_epoch_id') or '').strip() or None
    out['performance_epoch_role'] = str(row.get('performance_epoch_role') or '').strip() or None
    out['book_reset_batch_id'] = str(row.get('book_reset_batch_id') or '').strip() or None
    out['operator_book_reset_v1045'] = bool(row.get('operator_book_reset_v1045'))
    out['excluded_from_strategy_windows_v1045'] = bool(row.get('excluded_from_strategy_windows_v1045'))
    return out

def _v1045_perf_windows(rows: List[Dict[str, Any]], nowv: float) -> Tuple[Dict[str, Any], Dict[str, int]]:
    today_key = datetime.fromtimestamp(nowv, _v987_perf_KST).date()
    yesterday_key = today_key - timedelta(days=1)
    def day_rows(day: Any) -> List[Dict[str, Any]]:
        return [r for r in rows if float(r.get('closed_at') or 0.0) > 0 and datetime.fromtimestamp(float(r['closed_at']), _v987_perf_KST).date() == day]
    groups = {
        'all': rows,
        'today': day_rows(today_key),
        'yesterday': day_rows(yesterday_key),
        'recent_3h': [r for r in rows if float(r.get('closed_at') or 0.0) >= nowv - 3*3600.0],
        'recent_6h': [r for r in rows if float(r.get('closed_at') or 0.0) >= nowv - 6*3600.0],
        'recent_24h': [r for r in rows if float(r.get('closed_at') or 0.0) >= nowv - 24*3600.0],
    }
    return ({k: _v987_perf_stat(v) for k, v in groups.items()}, {k: len(v) for k, v in groups.items()})

def _v1045_apply_performance_epoch_contract(snap: Dict[str, Any], nowv: float, active_open_v1046: Optional[Dict[str, Dict[str, Any]]]=None) -> Dict[str, Any]:
    rows = [r for r in (snap.get('rows') or []) if isinstance(r, dict)]
    reset_rows = [r for r in rows if str(r.get('performance_epoch_role') or '') == 'reset_transition_close' or bool(r.get('operator_book_reset_v1045'))]
    strategy_rows = [r for r in rows if r not in reset_rows]
    old_windows = snap.get('windows') if isinstance(snap.get('windows'), dict) else {}
    old_counts = snap.get('window_counts') if isinstance(snap.get('window_counts'), dict) else {}
    strategy_windows, strategy_counts = _v1045_perf_windows(strategy_rows, nowv)
    epoch = _v1045_epoch()
    epoch_id = str(epoch.get('epoch_id') or '').strip()
    epoch_rows = [r for r in strategy_rows if epoch_id and str(r.get('performance_epoch_id') or '') == epoch_id]
    epoch_windows, epoch_counts = _v1045_perf_windows(epoch_rows, nowv)
    # v1046: seal current OPEN membership in the same paper-owned performance snapshot.
    # Main must not independently re-read OPEN when displaying epoch performance.
    active_open_v1046 = active_open_v1046 if isinstance(active_open_v1046,dict) else load_open()
    epoch_open_ids_v1046 = sorted(
        _v1044_reset_pos_id(pid, row)
        for pid, row in (active_open_v1046 or {}).items()
        if isinstance(row, dict) and epoch_id and str(row.get('performance_epoch_id') or '') == epoch_id
    )
    epoch_open_digest_v1046 = hashlib.sha256(
        ('\n'.join(epoch_open_ids_v1046)).encode('utf-8')
    ).hexdigest()
    manifest_v1046 = _v1045_manifest()
    target_set_v1046 = {str(x) for x in (manifest_v1046.get('target_pos_ids') or []) if str(x)}
    active_ids_v1046 = {
        _v1044_reset_pos_id(pid, row)
        for pid, row in (active_open_v1046 or {}).items() if isinstance(row, dict)
    }
    invalid_unexpected_v1046 = sorted(active_ids_v1046 - target_set_v1046 - set(epoch_open_ids_v1046))
    today_strategy_rows = [r for r in strategy_rows if float(r.get('closed_at') or 0.0) > 0 and datetime.fromtimestamp(float(r['closed_at']), _v987_perf_KST).date() == datetime.fromtimestamp(nowv, _v987_perf_KST).date()]
    by_strategy: Dict[str, List[Dict[str, Any]]] = defaultdict(list)
    for row in today_strategy_rows:
        if bool(row.get('observation_ingress_v988')):
            continue
        by_strategy[str(row.get('strategy') or _v987_perf_STRATEGY_MODE)].append(row)
    snap['windows_including_operator_reset_v1045'] = old_windows
    snap['window_counts_including_operator_reset_v1045'] = old_counts
    snap['windows'] = strategy_windows
    snap['window_counts'] = strategy_counts
    snap['today_strategy_stats'] = {name: _v987_perf_stat(group) for name, group in by_strategy.items()}
    snap['diagnostics_v1010'] = {
        'recent_24h': _v1010_perf_diagnostics([r for r in strategy_rows if float(r.get('closed_at') or 0.0) >= nowv - 24*3600.0]),
        'today': _v1010_perf_diagnostics(today_strategy_rows),
    }
    contract_rows = [r for r in strategy_rows if bool(r.get('contract_ok'))]
    outside_rows = [r for r in strategy_rows if not bool(r.get('contract_ok'))]
    snap['current_exit_contract'] = {
        'analysis_only': True,
        'allowed_exit_reasons': sorted(_v987_perf_ALLOWED_EXIT_REASONS),
        'contract_ok_rows': len(contract_rows),
        'contract_outside_rows': len(outside_rows),
        'outside_reason_counts': dict(Counter(str(r.get('exit_reason') or 'missing') for r in outside_rows)),
        'stats': _v987_perf_stat(contract_rows),
    }
    snap['reset_transition_v1045'] = {
        'batch_id': epoch.get('reset_batch_id') or (reset_rows[-1].get('book_reset_batch_id') if reset_rows else None),
        'rows': len(reset_rows),
        'stats': _v987_perf_stat(reset_rows),
        'recent_rows': reset_rows[-20:],
        'excluded_from_strategy_windows': True,
        'policy': 'operator-approved reset closures remain exact CLOSED history but are excluded from strategy profitability windows',
    }
    snap['performance_epoch_v1045'] = {
        'state': epoch.get('state') or 'NOT_STARTED',
        'epoch_id': epoch_id or None,
        'started_at': epoch.get('started_at'),
        'started_text': epoch.get('started_text'),
        'entry_resumed_at': epoch.get('entry_resumed_at'),
        'reset_batch_id': epoch.get('reset_batch_id'),
        'zero_open_proof': bool(epoch.get('zero_open_proof')),
        'rows': len(epoch_rows),
        'windows': epoch_windows,
        'window_counts': epoch_counts,
        'recent_rows': epoch_rows[-20:],
        'current_open_count': len(epoch_open_ids_v1046),
        'current_open_membership_digest': epoch_open_digest_v1046,
        'current_open_snapshot_at': nowv,
        'current_open_pos_ids_sample': epoch_open_ids_v1046[:50],
        'invalid_unexpected_open_count': len(invalid_unexpected_v1046),
        'invalid_unexpected_open_pos_ids_sample': invalid_unexpected_v1046[:50],
        'open_membership_owner': 'paper_bot_single_canonical_performance_writer_v1046',
        'policy': 'new sample includes only exact CLOSED rows and current OPEN rows sealed with the active post-reset epoch id',
    }
    counts = snap.get('counts') if isinstance(snap.get('counts'), dict) else {}
    counts['operator_reset_exact_rows_v1045'] = len(reset_rows)
    counts['strategy_rows_excluding_operator_reset_v1045'] = len(strategy_rows)
    counts['current_epoch_exact_rows_v1045'] = len(epoch_rows)
    counts['current_epoch_open_rows_v1046'] = len(epoch_open_ids_v1046)
    counts['invalid_unexpected_open_rows_v1046'] = len(invalid_unexpected_v1046)
    snap['counts'] = counts
    snap['recent_rows_including_operator_reset_v1045'] = rows[-20:]
    snap['recent_rows'] = strategy_rows[-20:]
    invariants = snap.get('invariants') if isinstance(snap.get('invariants'), dict) else {}
    invariants['operator_reset_exact_history_preserved'] = True
    invariants['operator_reset_excluded_from_strategy_windows'] = True
    invariants['post_reset_epoch_exact_key_only'] = True
    snap['invariants'] = invariants
    return snap

def _v987_perf_build_snapshot__L23202(base_dir: Path, paper_version: str, build_label: str, now_value: Optional[float]=None) -> Dict[str, Any]:  # type: ignore[override]
    snap = _V1045_PREV_PERF_BUILD_SNAPSHOT(base_dir, paper_version, build_label, now_value=now_value)
    nowv = float(now_value if now_value is not None else time.time())
    return _v1045_apply_performance_epoch_contract(snap, nowv)

def open_position__L23309(pos_id: str, ev: Dict[str, Any]) -> Dict[str, Any]:  # type: ignore[override]
    row = _V1045_PREV_OPEN_POSITION(pos_id, ev)
    epoch = _v1045_epoch()
    epoch_id = str(epoch.get('epoch_id') or '').strip()
    active = bool(epoch_id and str(epoch.get('state') or '').startswith('ACTIVE'))
    if active:
        row['performance_epoch_id'] = epoch_id
        row['performance_epoch_role'] = 'post_reset_strategy_open'
        row['performance_epoch_started_at'] = epoch.get('started_at')
        row['performance_epoch_reset_batch_id'] = epoch.get('reset_batch_id')
    else:
        row['performance_epoch_id'] = None
        row['performance_epoch_role'] = 'raw_paper_no_active_epoch_v1174'
        row['performance_epoch_missing_audit_v1174'] = True
        row['legacy_epoch_state_v1174'] = epoch.get('state')
    row['performance_epoch_sealed_at'] = now_ts()
    row['performance_epoch_sealed_by'] = 'paper_single_open_writer_v1174_raw'
    return row

def _v1045_reset_in_progress() -> bool:
    # v1174 raw Paper: never divert normal cycle/exit into legacy bulk-close reset.
    return False

def run_exact_exit_monitor__L23671(ctrl: Optional[Dict[str, Any]]=None, owner: str='paper_exact_exit_monitor') -> Dict[str, Any]:  # type: ignore[override]
    # v1174 raw Paper: normal exact-exit owner always runs; reset owner is retired.
    return _V1045_PREV_RUN_EXACT_EXIT_MONITOR(ctrl, owner)

def write_status__L23723(status: Dict[str, Any]) -> None:  # type: ignore[override]
    out = dict(status or {})
    legacy_control = load_json(BOOK_RESET_CONTROL_V1044, {}) or {}
    legacy_manifest = load_json(BOOK_RESET_MANIFEST_V1044, {}) or {}
    reset_status = {
        'schema':'paper_book_reset_status_v1174_audit_only',
        'state':'DISABLED_RAW_MODE_V1174',
        'entry_freeze':False,
        'bulk_close_enabled':False,
        'legacy_control_state':legacy_control.get('state'),
        'legacy_control_entry_freeze':bool(legacy_control.get('entry_freeze',False)),
        'legacy_batch_id':legacy_manifest.get('batch_id'),
        'active_owner':False,
        'ledger_mutated':False,
        'auto_buy':False,
    }
    out['book_reset_v1045'] = reset_status
    out['book_reset_v1044'] = reset_status
    out['performance_epoch_v1045'] = _v1045_epoch()
    out['operator_book_reset_owner_v1045'] = False
    _V1045_PREV_WRITE_STATUS(out)

VERSION = 'paper_bot_v0.990'

BUILD_LABEL = 'v1053_paper_cycle_writer_measurement_spine_2026-06-26'

_V1053_CURRENT_PROFILE: Dict[str, Any] = {}

_V1053_LAST_CYCLE_PROFILE: Dict[str, Any] = {}

_V1053_LAST_EXIT_PROFILE: Dict[str, Any] = {}

def _v1053_profile_add(name: str, elapsed: float, calls: int=1) -> None:
    global _V1053_CURRENT_PROFILE
    if not isinstance(_V1053_CURRENT_PROFILE,dict): _V1053_CURRENT_PROFILE={}
    rec=_V1053_CURRENT_PROFILE.get(name) if isinstance(_V1053_CURRENT_PROFILE.get(name),dict) else {'calls':0,'sec':0.0}
    rec['calls']=int(rec.get('calls') or 0)+int(calls); rec['sec']=round(float(rec.get('sec') or 0.0)+max(0.0,elapsed),6)
    _V1053_CURRENT_PROFILE[name]=rec

def load_open__L23763(*args: Any, **kwargs: Any):  # type: ignore[override]
    st=time.monotonic(); result=_V1053_PREV_LOAD_OPEN(*args,**kwargs); _v1053_profile_add('load_open',time.monotonic()-st)
    return result

def _paper_write_json_verified__L23768(path: Path, obj: Any) -> bool:  # type: ignore[override]
    st=time.monotonic(); ok=_V1053_PREV_VERIFIED_WRITE(path,obj); _v1053_profile_add('verified_json_write',time.monotonic()-st)
    return ok

def run_exact_exit_monitor__L23773(ctrl: Optional[Dict[str, Any]]=None, owner: str='paper_exact_exit_monitor') -> Dict[str, Any]:  # type: ignore[override]
    global _V1053_CURRENT_PROFILE,_V1053_LAST_EXIT_PROFILE
    _V1053_CURRENT_PROFILE={}; st=time.monotonic(); cpu=time.process_time()
    if '_v1055_begin_exit_sweep' in globals():
        _v1055_begin_exit_sweep(load_open(), owner)
    try:
        result=_V1053_PREV_RUN_EXACT_EXIT_MONITOR(ctrl,owner)
    finally:
        if '_v1055_end_exit_sweep' in globals():
            _v1055_end_exit_sweep(owner)
    _V1053_CURRENT_PROFILE['total']={'calls':1,'sec':round(time.monotonic()-st,6),'cpu_sec':round(time.process_time()-cpu,6)}
    _V1053_CURRENT_PROFILE['open_checked']=int(result.get('checked') or 0) if isinstance(result,dict) else 0
    _V1053_LAST_EXIT_PROFILE=dict(_V1053_CURRENT_PROFILE)
    return result

def write_status__L23802(status: Dict[str, Any]) -> None:  # type: ignore[override]
    out=dict(status or {})
    out['paper_cycle_profile_v1053']={'schema':'paper_cycle_writer_profile_v1053','version':VERSION,'build':BUILD_LABEL,'cycle':dict(_V1053_LAST_CYCLE_PROFILE),'exit_monitor':dict(_V1053_LAST_EXIT_PROFILE),'measurement_only':True,'trade_rules_changed':False}
    _V1053_PREV_WRITE_STATUS(out)

VERSION = 'paper_bot_v0.996'

BUILD_LABEL = 'v1059_risk_paper_status_heartbeat_preserve_2026-06-26'

_V1054_OPEN_CACHE_LOCK = threading.RLock()

_V1054_OPEN_CACHE_ROWS: Optional[Dict[str, Dict[str, Any]]] = None

_V1054_OPEN_CACHE_FINGERPRINT: Optional[Tuple[int, int, int]] = None

_V1054_OPEN_CACHE_STATS: Dict[str, Any] = {
    'cache_hits': 0,
    'cache_misses': 0,
    'full_json_parses': 0,
    'stream_verified_writes': 0,
    'stream_verified_write_failures': 0,
    'readback_json_parses': 0,
    'cache_invalidations': 0,
    'bytes_written': 0,
    'bytes_verified': 0,
    'last_load_sec': 0.0,
    'last_write_sec': 0.0,
    'last_verify_sec': 0.0,
    'last_error': '',
}

def _v1054_open_fingerprint(path: Path) -> Optional[Tuple[int, int, int]]:
    try:
        st = path.stat()
        return (int(st.st_ino), int(st.st_size), int(st.st_mtime_ns))
    except FileNotFoundError:
        return None
    except Exception as exc:
        _V1054_OPEN_CACHE_STATS['last_error'] = f'fingerprint:{type(exc).__name__}:{exc}'
        return None

def _v1054_open_row_snapshot(rows: Any) -> Dict[str, Dict[str, Any]]:
    """Copy only the top mapping and row dictionaries; keep large sealed nested evidence shared."""
    if not isinstance(rows, dict):
        return {}
    out: Dict[str, Dict[str, Any]] = {}
    for key, row in rows.items():
        if isinstance(row, dict):
            out[str(key)] = dict(row)
    return out

def _v1054_open_cache_invalidate(reason: str) -> None:
    global _V1054_OPEN_CACHE_ROWS, _V1054_OPEN_CACHE_FINGERPRINT
    with _V1054_OPEN_CACHE_LOCK:
        _V1054_OPEN_CACHE_ROWS = None
        _V1054_OPEN_CACHE_FINGERPRINT = None
        _V1054_OPEN_CACHE_STATS['cache_invalidations'] = int(_V1054_OPEN_CACHE_STATS.get('cache_invalidations') or 0) + 1
        _V1054_OPEN_CACHE_STATS['last_invalidation_reason'] = str(reason or 'unknown')

def _v1054_open_cache_publish(rows: Dict[str, Dict[str, Any]], fingerprint: Optional[Tuple[int, int, int]]=None) -> None:
    global _V1054_OPEN_CACHE_ROWS, _V1054_OPEN_CACHE_FINGERPRINT
    with _V1054_OPEN_CACHE_LOCK:
        _V1054_OPEN_CACHE_ROWS = _v1054_open_row_snapshot(rows)
        _V1054_OPEN_CACHE_FINGERPRINT = fingerprint if fingerprint is not None else _v1054_open_fingerprint(FILES['open'])
        _V1054_OPEN_CACHE_STATS['cached_rows'] = len(_V1054_OPEN_CACHE_ROWS)
        _V1054_OPEN_CACHE_STATS['cached_fingerprint'] = list(_V1054_OPEN_CACHE_FINGERPRINT) if _V1054_OPEN_CACHE_FINGERPRINT else None

def _v1054_current_rss_mb() -> Optional[float]:
    try:
        for line in Path('/proc/self/status').read_text(encoding='utf-8', errors='ignore').splitlines():
            if line.startswith('VmRSS:'):
                return round(float(line.split()[1]) / 1024.0, 2)
    except Exception:
        pass
    return None

def load_open__L23894(*args: Any, **kwargs: Any) -> Dict[str, Dict[str, Any]]:  # type: ignore[override]
    started = time.monotonic()
    path = FILES['open']
    fingerprint = _v1054_open_fingerprint(path)
    with _V1054_OPEN_CACHE_LOCK:
        if _V1054_OPEN_CACHE_ROWS is not None and fingerprint == _V1054_OPEN_CACHE_FINGERPRINT:
            _V1054_OPEN_CACHE_STATS['cache_hits'] = int(_V1054_OPEN_CACHE_STATS.get('cache_hits') or 0) + 1
            _V1054_OPEN_CACHE_STATS['last_load_source'] = 'cache_hit'
            _V1054_OPEN_CACHE_STATS['last_load_sec'] = round(time.monotonic() - started, 6)
            return _v1054_open_row_snapshot(_V1054_OPEN_CACHE_ROWS)
        _V1054_OPEN_CACHE_STATS['cache_misses'] = int(_V1054_OPEN_CACHE_STATS.get('cache_misses') or 0) + 1
    try:
        rows = _V1054_PREV_LOAD_OPEN(*args, **kwargs)
        if not isinstance(rows, dict):
            rows = {}
        with _V1054_OPEN_CACHE_LOCK:
            _V1054_OPEN_CACHE_STATS['full_json_parses'] = int(_V1054_OPEN_CACHE_STATS.get('full_json_parses') or 0) + 1
            _V1054_OPEN_CACHE_STATS['last_load_source'] = 'disk_parse'
        _v1054_open_cache_publish(rows, _v1054_open_fingerprint(path))
        return _v1054_open_row_snapshot(rows)
    except Exception:
        _v1054_open_cache_invalidate('load_open_exception')
        raise
    finally:
        _V1054_OPEN_CACHE_STATS['last_load_sec'] = round(time.monotonic() - started, 6)

def _v1054_restore_open_after_failed_replace(path: Path, backup: Optional[Path], had_prior: bool) -> bool:
    """Restore the previous OPEN inode after any post-replace verification failure."""
    try:
        if had_prior and backup is not None and backup.exists():
            os.replace(backup, path)
        elif not had_prior and path.exists():
            path.unlink()
        dir_fd = os.open(str(path.parent), os.O_RDONLY)
        try:
            os.fsync(dir_fd)
        finally:
            os.close(dir_fd)
        return True
    except Exception as exc:
        _V1054_OPEN_CACHE_STATS['last_restore_error'] = f'{type(exc).__name__}:{exc}'
        log_error('v1054_restore_open_after_failed_replace', exc)
        return False

def _v1054_stream_write_open_verified(open_pos: Dict[str, Dict[str, Any]]) -> bool:
    """Atomic streaming JSON write and exact-byte verification without full read-back parsing.

    Before replace, a hard-link rollback point is created for the existing OPEN inode.
    Any post-replace fsync/verify failure restores that inode so a False return really
    means the prior OPEN file is still canonical.
    """
    path = FILES['open']
    token = f'{os.getpid()}.{time.time_ns()}'
    tmp = path.with_name(f'.{path.name}.{token}.tmp')
    backup = path.with_name(f'.{path.name}.{token}.rollback')
    started = time.monotonic()
    write_digest = hashlib.sha256()
    written = 0
    had_prior = path.exists()
    replaced = False
    try:
        path.parent.mkdir(parents=True, exist_ok=True)
        encoder = json.JSONEncoder(ensure_ascii=False, separators=(',', ':'), default=str)
        with tmp.open('wb') as handle:
            for chunk in encoder.iterencode(open_pos if isinstance(open_pos, dict) else {}):
                data = chunk.encode('utf-8')
                handle.write(data)
                write_digest.update(data)
                written += len(data)
            handle.flush()
            os.fsync(handle.fileno())
        if had_prior:
            try:
                os.link(path, backup)
            except Exception as exc:
                _V1054_OPEN_CACHE_STATS['last_error'] = f'rollback_link:{type(exc).__name__}:{exc}'
                _V1054_OPEN_CACHE_STATS['stream_verified_write_failures'] = int(_V1054_OPEN_CACHE_STATS.get('stream_verified_write_failures') or 0) + 1
                _v1054_open_cache_invalidate('rollback_link_failed_before_replace')
                return False
        os.replace(tmp, path)
        replaced = True
        try:
            dir_fd = os.open(str(path.parent), os.O_RDONLY)
            try:
                os.fsync(dir_fd)
            finally:
                os.close(dir_fd)
        except Exception as exc:
            restored = _v1054_restore_open_after_failed_replace(path, backup if had_prior else None, had_prior)
            _V1054_OPEN_CACHE_STATS['last_error'] = f'directory_fsync:{type(exc).__name__}:{exc}:restored={restored}'
            _V1054_OPEN_CACHE_STATS['stream_verified_write_failures'] = int(_V1054_OPEN_CACHE_STATS.get('stream_verified_write_failures') or 0) + 1
            _v1054_open_cache_invalidate('directory_fsync_failed_after_replace')
            return False
        verify_started = time.monotonic()
        read_digest = hashlib.sha256()
        verified = 0
        with path.open('rb') as handle:
            while True:
                data = handle.read(1024 * 1024)
                if not data:
                    break
                read_digest.update(data)
                verified += len(data)
        _V1054_OPEN_CACHE_STATS['last_verify_sec'] = round(time.monotonic() - verify_started, 6)
        ok = bool(verified == written and read_digest.digest() == write_digest.digest())
        if not ok:
            restored = _v1054_restore_open_after_failed_replace(path, backup if had_prior else None, had_prior)
            _V1054_OPEN_CACHE_STATS['last_error'] = f'exact_byte_verify_mismatch:{written}:{verified}:restored={restored}'
            _V1054_OPEN_CACHE_STATS['stream_verified_write_failures'] = int(_V1054_OPEN_CACHE_STATS.get('stream_verified_write_failures') or 0) + 1
            _v1054_open_cache_invalidate('exact_byte_verify_mismatch')
            return False
        try:
            if backup.exists():
                backup.unlink()
        except Exception as exc:
            log_error('v1054_remove_open_rollback_link', exc)
        _V1054_OPEN_CACHE_STATS['stream_verified_writes'] = int(_V1054_OPEN_CACHE_STATS.get('stream_verified_writes') or 0) + 1
        _V1054_OPEN_CACHE_STATS['bytes_written'] = int(_V1054_OPEN_CACHE_STATS.get('bytes_written') or 0) + written
        _V1054_OPEN_CACHE_STATS['bytes_verified'] = int(_V1054_OPEN_CACHE_STATS.get('bytes_verified') or 0) + verified
        _V1054_OPEN_CACHE_STATS['last_error'] = ''
        _V1054_OPEN_CACHE_STATS['rollback_link_used'] = bool(had_prior)
        _V1054_OPEN_CACHE_STATS['rollback_restore_failures'] = int(_V1054_OPEN_CACHE_STATS.get('rollback_restore_failures') or 0)
        _v1054_open_cache_publish(open_pos, _v1054_open_fingerprint(path))
        return True
    except Exception as exc:
        if replaced:
            restored = _v1054_restore_open_after_failed_replace(path, backup if had_prior else None, had_prior)
            if not restored:
                _V1054_OPEN_CACHE_STATS['rollback_restore_failures'] = int(_V1054_OPEN_CACHE_STATS.get('rollback_restore_failures') or 0) + 1
        _V1054_OPEN_CACHE_STATS['stream_verified_write_failures'] = int(_V1054_OPEN_CACHE_STATS.get('stream_verified_write_failures') or 0) + 1
        _V1054_OPEN_CACHE_STATS['last_error'] = f'{type(exc).__name__}:{exc}'
        _v1054_open_cache_invalidate('stream_write_exception')
        log_error('v1054_stream_write_open_verified', exc)
        return False
    finally:
        _V1054_OPEN_CACHE_STATS['last_write_sec'] = round(time.monotonic() - started, 6)
        for leftover in (tmp, backup):
            try:
                if leftover.exists():
                    leftover.unlink()
            except Exception as cleanup_exc:
                log_error('v1054_stream_write_open_cleanup', cleanup_exc)
        if '_v1053_profile_add' in globals():
            try:
                _v1053_profile_add('open_stream_verified_write_v1054', time.monotonic() - started)
            except Exception:
                pass

_V1055_STATE_LOCK = threading.RLock()

_V1055_IN_EXIT_SWEEP = False

_V1055_SWEEP_CRITICAL_BEFORE: Any = None

_V1055_LAST_FULL_FLUSH_MONO = 0.0

_V1055_DIRTY = False

_V1055_DIRTY_SINCE_MONO = 0.0

_V1055_FLUSH_INTERVAL_SEC = 10.0

_V1055_STATS: Dict[str, Any] = {
    'standalone_sweeps': 0,
    'cycle_exit_sweeps_removed': 2,
    'full_open_flushes': 0,
    'coalesced_open_writes': 0,
    'exact_forced_writes': 0,
    'critical_forced_writes': 0,
    'shutdown_forced_writes': 0,
    'write_failures': 0,
    'last_flush_reason': '',
    'last_error': '',
}

def _v1055_critical_signature(rows: Any) -> tuple:
    if not isinstance(rows,dict): return tuple()
    out=[]
    for pid,row in rows.items():
        if not isinstance(row,dict): continue
        shadow=row.get('profitability_shadow_trailing_v1034') if isinstance(row.get('profitability_shadow_trailing_v1034'),dict) else {}
        action=str(row.get('last_exit_decision') or '')
        out.append((str(pid),bool(row.get('first_target_touch_ts_v983')),bool(row.get('first_invalid_touch_ts_v983')),bool(shadow.get('triggered')),int(fnum(row.get('time_exit_extension_count'),default=0)),action if action in {'extend','error','close'} else ''))
    out.sort(); return tuple(out)

def _v1055_flush_interval() -> float:
    try:
        ctrl=load_control(); raw=fnum(ctrl.get('open_state_flush_interval_sec_v1055'),default=_V1055_FLUSH_INTERVAL_SEC) if isinstance(ctrl,dict) else _V1055_FLUSH_INTERVAL_SEC
        return max(5.0,min(30.0,float(raw)))
    except Exception: return _V1055_FLUSH_INTERVAL_SEC

def _v1055_begin_exit_sweep(rows: Dict[str, Dict[str, Any]], owner: str) -> None:
    global _V1055_IN_EXIT_SWEEP,_V1055_SWEEP_CRITICAL_BEFORE
    with _V1055_STATE_LOCK:
        _V1055_IN_EXIT_SWEEP=True
        _V1055_SWEEP_CRITICAL_BEFORE=_v1055_critical_signature(rows)
        if owner=='paper_exact_exit_monitor': _V1055_STATS['standalone_sweeps']=int(_V1055_STATS.get('standalone_sweeps') or 0)+1

def _v1055_end_exit_sweep(owner: str) -> None:
    global _V1055_IN_EXIT_SWEEP,_V1055_SWEEP_CRITICAL_BEFORE
    with _V1055_STATE_LOCK:
        _V1055_IN_EXIT_SWEEP=False; _V1055_SWEEP_CRITICAL_BEFORE=None

def _v1055_persist_open_force(open_pos: Dict[str, Dict[str, Any]], reason: str='exact_force') -> bool:
    global _V1055_LAST_FULL_FLUSH_MONO,_V1055_DIRTY,_V1055_DIRTY_SINCE_MONO
    ok=_v1054_stream_write_open_verified(open_pos if isinstance(open_pos,dict) else {})
    with _V1055_STATE_LOCK:
        if ok:
            global _V1055_SWEEP_CRITICAL_BEFORE
            _V1055_LAST_FULL_FLUSH_MONO=time.monotonic(); _V1055_DIRTY=False; _V1055_DIRTY_SINCE_MONO=0.0
            if _V1055_IN_EXIT_SWEEP:
                _V1055_SWEEP_CRITICAL_BEFORE=_v1055_critical_signature(open_pos)
            _V1055_STATS['full_open_flushes']=int(_V1055_STATS.get('full_open_flushes') or 0)+1
            _V1055_STATS['exact_forced_writes']=int(_V1055_STATS.get('exact_forced_writes') or 0)+1
            _V1055_STATS['last_flush_reason']=reason; _V1055_STATS['last_error']=''
        else:
            _V1055_STATS['write_failures']=int(_V1055_STATS.get('write_failures') or 0)+1; _V1055_STATS['last_error']=f'force_failed:{reason}'
    return bool(ok)

def persist_open_positions(open_pos: Dict[str, Dict[str, Any]]) -> bool:  # type: ignore[override]
    global _V1055_LAST_FULL_FLUSH_MONO,_V1055_DIRTY,_V1055_DIRTY_SINCE_MONO
    rows=open_pos if isinstance(open_pos,dict) else {}; nowm=time.monotonic()
    with _V1055_STATE_LOCK:
        in_sweep=bool(_V1055_IN_EXIT_SWEEP); before=_V1055_SWEEP_CRITICAL_BEFORE; last=_V1055_LAST_FULL_FLUSH_MONO; was_dirty=_V1055_DIRTY
    critical=bool(in_sweep and before is not None and _v1055_critical_signature(rows)!=before)
    due=bool(last<=0.0 or nowm-last>=_v1055_flush_interval())
    if (not in_sweep) or critical or due or bool(globals().get('_STOP',False)):
        reason='outside_exit_sweep' if not in_sweep else ('critical_open_state_change' if critical else ('shutdown_dirty_flush' if bool(globals().get('_STOP',False)) else 'bounded_interval_flush'))
        ok=_v1054_stream_write_open_verified(rows)
        with _V1055_STATE_LOCK:
            if ok:
                _V1055_LAST_FULL_FLUSH_MONO=time.monotonic(); _V1055_DIRTY=False; _V1055_DIRTY_SINCE_MONO=0.0
                _V1055_STATS['full_open_flushes']=int(_V1055_STATS.get('full_open_flushes') or 0)+1; _V1055_STATS['last_flush_reason']=reason; _V1055_STATS['last_error']=''
                if critical: _V1055_STATS['critical_forced_writes']=int(_V1055_STATS.get('critical_forced_writes') or 0)+1
                if bool(globals().get('_STOP',False)): _V1055_STATS['shutdown_forced_writes']=int(_V1055_STATS.get('shutdown_forced_writes') or 0)+1
            else:
                _V1055_STATS['write_failures']=int(_V1055_STATS.get('write_failures') or 0)+1; _V1055_STATS['last_error']=f'persist_failed:{reason}'
        return bool(ok)
    _v1054_open_cache_publish(rows,_v1054_open_fingerprint(FILES['open']))
    with _V1055_STATE_LOCK:
        if not was_dirty: _V1055_DIRTY=True; _V1055_DIRTY_SINCE_MONO=nowm
        _V1055_STATS['coalesced_open_writes']=int(_V1055_STATS.get('coalesced_open_writes') or 0)+1; _V1055_STATS['last_flush_reason']='coalesced_in_memory'
    return True

def _v1055_force_dirty_flush_on_shutdown() -> None:
    with _V1055_STATE_LOCK: dirty=bool(_V1055_DIRTY)
    if not dirty: return
    try:
        if not _v1055_persist_open_force(load_open(),'shutdown_dirty_flush'):
            raise RuntimeError('v1055 shutdown dirty OPEN flush failed')
        with _V1055_STATE_LOCK: _V1055_STATS['shutdown_forced_writes']=int(_V1055_STATS.get('shutdown_forced_writes') or 0)+1
    except Exception as exc:
        _V1055_STATS['last_error']=f'shutdown:{type(exc).__name__}:{exc}'; log_error('v1055_shutdown_dirty_flush',exc)

def _v1054_open_cache_status() -> Dict[str, Any]:
    with _V1054_OPEN_CACHE_LOCK:
        stats = dict(_V1054_OPEN_CACHE_STATS)
        fp = _v1054_open_fingerprint(FILES['open'])
        stats.update({
            'schema': 'paper_open_cache_status_v1054',
            'version': VERSION,
            'build': BUILD_LABEL,
            'enabled': True,
            'cache_key': 'inode+size+mtime_ns',
            'cached_rows': len(_V1054_OPEN_CACHE_ROWS or {}),
            'cache_fingerprint_matches_file': bool(_V1054_OPEN_CACHE_ROWS is not None and fp == _V1054_OPEN_CACHE_FINGERPRINT),
            'current_file_fingerprint': list(fp) if fp else None,
            'full_json_parse_on_unchanged_load': False,
            'open_write_mode': 'stream_iterencode_fsync_atomic_replace_chunked_sha256_verify',
            'readback_json_parse_count': int(stats.get('readback_json_parses') or 0),
            'rss_mb': _v1054_current_rss_mb(),
            'trade_rules_changed': False,
            'closed_commit_order_changed': False,
        })
        return stats

def _v1059_has_consumer_evidence(pick: Any) -> bool:
    if not isinstance(pick, dict):
        return False
    return bool(
        isinstance(pick.get('loss_reentry_source_contract_v1057'), dict)
        or 'loss_reentry_source_ready_v1057' in pick
        or 'loss_reentry_source_closed_signature_match_v1057' in pick
        or 'loss_reentry_source_reason_v1057' in pick
    )

def _v1059_contract_from_pick(pick: Dict[str, Any]) -> Dict[str, Any]:
    diag = pick.get('loss_reentry_source_contract_v1057') if isinstance(pick.get('loss_reentry_source_contract_v1057'), dict) else {}
    checks = diag.get('checks') if isinstance(diag.get('checks'), dict) else {}
    producer_contract = diag.get('contract') if isinstance(diag.get('contract'), dict) else {}
    ready = bool(pick.get('loss_reentry_source_ready_v1057') is True)
    signature_match = bool(pick.get('loss_reentry_source_closed_signature_match_v1057') is True)
    reason = str(pick.get('loss_reentry_source_reason_v1057') or ('ready' if ready else 'consumer_contract_not_ready'))
    return {
        'schema': 'paper_risk_contract_status_v1059',
        'version': VERSION,
        'build': BUILD_LABEL,
        'consumer_owner': 'paper_bot.select_candidates',
        'status_owner': 'paper_bot.write_status',
        'source_contract_schema': producer_contract.get('schema'),
        'producer_version_observed': diag.get('producer_version_observed'),
        'producer_schema_observed': diag.get('producer_schema_observed'),
        'ready': ready,
        'reason': reason,
        'closed_signature_match': signature_match,
        'source_complete': bool(checks.get('source_complete') is True),
        'required_fields_ready': bool(
            checks.get('contract_schema') is True
            and checks.get('owner') is True
            and checks.get('event_map') is True
            and checks.get('event_count') is True
        ),
        'latest_loss_selection': producer_contract.get('latest_loss_selection'),
        'event_count': int(producer_contract.get('event_count') or 0),
        'source_mismatch_blocked_this_cycle': int(pick.get('loss_reentry_source_missing_block_v1057') or 0),
        'old_version_string_gate_active': False,
        'canonical_top_level': True,
        'consumer_evidence_present': True,
        'heartbeat_preserve_mode': True,
        'trade_rules_changed': False,
        'exit_rules_changed': False,
        'auto_buy': False,
        'consumer_evaluated_ts': now_ts(),
    }

def write_status__L24232(status: Dict[str, Any]) -> None:  # type: ignore[override]
    out = dict(status or {})
    out['paper_open_cache_v1054'] = _v1054_open_cache_status()
    with _V1055_STATE_LOCK:
        nowm=time.monotonic(); dirty_age=max(0.0,nowm-_V1055_DIRTY_SINCE_MONO) if _V1055_DIRTY and _V1055_DIRTY_SINCE_MONO>0 else 0.0
        spine=dict(_V1055_STATS)
        spine.update({'schema':'paper_single_exit_owner_status_v1055','version':VERSION,'build':BUILD_LABEL,'active':True,'single_exit_sweep_owner':True,'cycle_internal_duplicate_sweeps_removed':True,'open_state_flush_interval_sec':_v1055_flush_interval(),'open_state_dirty':bool(_V1055_DIRTY),'dirty_age_sec':round(dirty_age,3),'rss_mb':_v1054_current_rss_mb(),'closed_commit_order_changed':False,'trade_rules_changed':False,'auto_buy':False,'policy':'main exact monitor is sole exit evaluator; noncritical OPEN values coalesce; exact commits/critical changes/shutdown force verified persistence'})
    out['paper_single_exit_owner_v1055'] = spine

    # v1059: only a real select_candidates result may replace the canonical
    # Risk->Paper consumer status. Startup/heartbeat writes contain no
    # pick_stats evidence and therefore preserve the last evaluated block.
    incoming_pick = out.get('pick_stats') if isinstance(out.get('pick_stats'), dict) else {}
    if _v1059_has_consumer_evidence(incoming_pick):
        canonical_contract = _v1059_contract_from_pick(incoming_pick)
        out['risk_paper_contract_v1059'] = canonical_contract
        out['loss_reentry_source_ready_v1057'] = canonical_contract.get('ready')
        out['loss_reentry_source_reason_v1057'] = canonical_contract.get('reason')
        out['loss_reentry_source_closed_signature_match_v1057'] = canonical_contract.get('closed_signature_match')
        out['loss_reentry_latest_loss_selection_v1057'] = canonical_contract.get('latest_loss_selection')
    else:
        previous_status = globals().get('_LAST_STATUS') if isinstance(globals().get('_LAST_STATUS'), dict) else {}
        previous_contract = previous_status.get('risk_paper_contract_v1059') if isinstance(previous_status.get('risk_paper_contract_v1059'), dict) else {}
        if previous_contract:
            out['risk_paper_contract_v1059'] = dict(previous_contract)
        # Do not synthesize ready=False from a heartbeat with no consumer
        # evidence. The underlying single writer merges the previous status.

    out['resource_measurement_v1074'] = {
        'schema':'paper_resource_self_sample_v1074',
        'self_rss_mb':_v1054_current_rss_mb(),
        'sample_ts':now_ts(),
        'sample_owner':'paper process self /proc sample',
        'canonical_operational_owner':'guard_single_runtime_status_writer',
        'role':'diagnostic_only_not_operational_threshold',
        'missing_is_not_zero':True,
    }
    _V1054_PREV_WRITE_STATUS(out)

_V1076_PROFILE_LOCK = threading.RLock()

_V1076_ACTIVE_PROFILE: Optional[Dict[str, Any]] = None

_V1076_LAST_CYCLE_PROFILE: Dict[str, Any] = {}

_V1076_LAST_EXIT_PROFILE: Dict[str, Any] = {}

def _v1076_proc_status_bytes() -> Dict[str, int]:
    out: Dict[str, int] = {}
    try:
        for line in Path('/proc/self/status').read_text(encoding='utf-8', errors='ignore').splitlines():
            if ':' not in line:
                continue
            key, raw = line.split(':', 1)
            if key not in {'VmRSS','VmHWM','RssAnon','RssFile','RssShmem','VmData','VmSwap','Threads'}:
                continue
            parts = raw.strip().split()
            if not parts:
                continue
            value = int(float(parts[0]))
            out[key] = value if key == 'Threads' else value * 1024
    except Exception:
        pass
    return out

def _v1076_proc_io() -> Dict[str, int]:
    out: Dict[str, int] = {}
    try:
        for line in Path('/proc/self/io').read_text(encoding='utf-8', errors='ignore').splitlines():
            if ':' not in line:
                continue
            key, raw = line.split(':', 1)
            try:
                out[key.strip()] = int(raw.strip())
            except Exception:
                continue
    except Exception:
        pass
    return out

def _v1076_smaps_rollup_bytes() -> Dict[str, int]:
    out: Dict[str, int] = {}
    wanted = {
        'Rss','Pss','Pss_Anon','Pss_File','Pss_Shmem','Shared_Clean','Shared_Dirty',
        'Private_Clean','Private_Dirty','Anonymous','LazyFree','AnonHugePages','Swap',
    }
    try:
        for line in Path('/proc/self/smaps_rollup').read_text(encoding='utf-8', errors='ignore').splitlines():
            if ':' not in line:
                continue
            key, raw = line.split(':', 1)
            if key not in wanted:
                continue
            parts = raw.strip().split()
            if parts:
                out[key] = int(float(parts[0])) * 1024
    except Exception:
        pass
    return out

def _v1076_resource_snapshot(include_smaps: bool=False) -> Dict[str, Any]:
    status = _v1076_proc_status_bytes()
    snap: Dict[str, Any] = {
        'ts': now_ts(),
        'rss_bytes': int(status.get('VmRSS') or 0),
        'rss_anon_bytes': int(status.get('RssAnon') or 0),
        'rss_file_bytes': int(status.get('RssFile') or 0),
        'rss_shmem_bytes': int(status.get('RssShmem') or 0),
        'vm_data_bytes': int(status.get('VmData') or 0),
        'vm_swap_bytes': int(status.get('VmSwap') or 0),
        'threads': int(status.get('Threads') or 0),
        'io': _v1076_proc_io(),
    }
    if include_smaps:
        snap['smaps_rollup'] = _v1076_smaps_rollup_bytes()
    return snap

def _v1076_profile_phase_close(active: Dict[str, Any]) -> None:
    phase = str(active.get('phase') or '')
    token = active.get('phase_token')
    if not phase or not isinstance(token, tuple) or len(token) != 4:
        return
    wall = max(0.0, time.monotonic() - float(token[0]))
    cpu = max(0.0, time.process_time() - float(token[1]))
    end = _v1076_resource_snapshot(include_smaps=False)
    start_rss = int(token[2] or 0)
    start_io = token[3] if isinstance(token[3], dict) else {}
    end_io = end.get('io') if isinstance(end.get('io'), dict) else {}
    phases = active.setdefault('phases', {})
    prev = phases.get(phase) if isinstance(phases.get(phase), dict) else {}
    phases[phase] = {
        'calls': int(prev.get('calls') or 0) + 1,
        'wall_sec': round(float(prev.get('wall_sec') or 0.0) + wall, 6),
        'cpu_sec': round(float(prev.get('cpu_sec') or 0.0) + cpu, 6),
        'rss_start_bytes': start_rss,
        'rss_end_bytes': int(end.get('rss_bytes') or 0),
        'rss_delta_bytes': int(end.get('rss_bytes') or 0) - start_rss,
        'read_bytes_delta': int(prev.get('read_bytes_delta') or 0) + max(0, int(end_io.get('read_bytes') or 0) - int(start_io.get('read_bytes') or 0)),
        'write_bytes_delta': int(prev.get('write_bytes_delta') or 0) + max(0, int(end_io.get('write_bytes') or 0) - int(start_io.get('write_bytes') or 0)),
        'rchar_delta': int(prev.get('rchar_delta') or 0) + max(0, int(end_io.get('rchar') or 0) - int(start_io.get('rchar') or 0)),
        'wchar_delta': int(prev.get('wchar_delta') or 0) + max(0, int(end_io.get('wchar') or 0) - int(start_io.get('wchar') or 0)),
    }

def _v1076_profile_phase_start(active: Dict[str, Any], phase: str) -> None:
    snap = _v1076_resource_snapshot(include_smaps=False)
    active['phase'] = str(phase or 'unknown')
    active['phase_token'] = (time.monotonic(), time.process_time(), int(snap.get('rss_bytes') or 0), snap.get('io') or {})

def _v1076_profile_begin(scope: str) -> None:
    global _V1076_ACTIVE_PROFILE
    with _V1076_PROFILE_LOCK:
        start = _v1076_resource_snapshot(include_smaps=True)
        _V1076_ACTIVE_PROFILE = {
            'schema':'paper_phase_resource_profile_v1076',
            'scope':str(scope),
            'version':VERSION,
            'build':BUILD_LABEL,
            'pid':os.getpid(),
            'started_ts':now_ts(),
            'started_mono':time.monotonic(),
            'started_cpu':time.process_time(),
            'start_resource':start,
            'phases':{},
            'measurement_only':True,
            'trade_rules_changed':False,
            'ledger_contract_changed':False,
            'auto_buy':False,
        }
        _v1076_profile_phase_start(_V1076_ACTIVE_PROFILE, f'{scope}_enter')

def _v1076_profile_finish(scope: str, error: str='') -> Dict[str, Any]:
    global _V1076_ACTIVE_PROFILE, _V1076_LAST_CYCLE_PROFILE, _V1076_LAST_EXIT_PROFILE
    with _V1076_PROFILE_LOCK:
        active = _V1076_ACTIVE_PROFILE if isinstance(_V1076_ACTIVE_PROFILE, dict) else {}
        if not active or str(active.get('scope')) != str(scope):
            return {}
        _v1076_profile_phase_close(active)
        end = _v1076_resource_snapshot(include_smaps=True)
        phases = active.get('phases') if isinstance(active.get('phases'), dict) else {}
        ranked = sorted(
            ({'phase':str(name), **dict(row)} for name,row in phases.items() if isinstance(row,dict)),
            key=lambda row:(float(row.get('wall_sec') or 0.0), float(row.get('cpu_sec') or 0.0)),
            reverse=True,
        )
        active.update({
            'finished_ts':now_ts(),
            'wall_sec':round(max(0.0,time.monotonic()-float(active.get('started_mono') or time.monotonic())),6),
            'cpu_sec':round(max(0.0,time.process_time()-float(active.get('started_cpu') or time.process_time())),6),
            'end_resource':end,
            'rss_delta_bytes':int(end.get('rss_bytes') or 0)-int((active.get('start_resource') or {}).get('rss_bytes') or 0),
            'top_phases':ranked[:12],
            'phase_count':len(ranked),
            'error':str(error or '')[:300] or None,
            'policy':'measurement only; observes existing v994 phases and /proc counters; no strategy, entry, exit or ledger mutation',
        })
        active.pop('started_mono',None); active.pop('started_cpu',None); active.pop('phase_token',None)
        final = dict(active)
        if scope == 'cycle':
            _V1076_LAST_CYCLE_PROFILE = final
        else:
            _V1076_LAST_EXIT_PROFILE = final
        _V1076_ACTIVE_PROFILE = None
        return final

def _v1076_active_profile_snapshot() -> Dict[str, Any]:
    with _V1076_PROFILE_LOCK:
        active = _V1076_ACTIVE_PROFILE if isinstance(_V1076_ACTIVE_PROFILE,dict) else {}
        if not active:
            return {}
        return {
            'scope':active.get('scope'),
            'phase':active.get('phase'),
            'elapsed_sec':round(max(0.0,time.monotonic()-float((active.get('phase_token') or (time.monotonic(),))[0])),3),
            'cycle_age_sec':round(max(0.0,time.monotonic()-float(active.get('started_mono') or time.monotonic())),3),
            'resource':_v1076_resource_snapshot(include_smaps=False),
        }

def _set_runtime_phase_v994__v1076(phase: str, detail: str='', persist: bool=True) -> None:  # type: ignore[override]
    with _V1076_PROFILE_LOCK:
        active = _V1076_ACTIVE_PROFILE if isinstance(_V1076_ACTIVE_PROFILE,dict) else None
        if active is not None:
            _v1076_profile_phase_close(active)
            _v1076_profile_phase_start(active, str(phase or 'unknown'))
    _V1076_PREV_SET_RUNTIME_PHASE(phase, detail, persist)

def run_exact_exit_monitor__v1076(ctrl: Optional[Dict[str, Any]]=None, owner: str='paper_exact_exit_monitor') -> Dict[str, Any]:  # type: ignore[override]
    _v1076_profile_begin('exit_monitor')
    try:
        return _V1076_PREV_RUN_EXACT_EXIT_MONITOR(ctrl, owner)
    except Exception as exc:
        _v1076_profile_finish('exit_monitor', f'{type(exc).__name__}: {exc}')
        raise
    finally:
        if isinstance(_V1076_ACTIVE_PROFILE,dict) and _V1076_ACTIVE_PROFILE.get('scope') == 'exit_monitor':
            _v1076_profile_finish('exit_monitor')

def write_status__v1076(status: Dict[str, Any]) -> None:  # type: ignore[override]
    out = dict(status or {})
    out['paper_entry_price_owner_v1079'] = {
        'schema':'paper_entry_price_owner_v1079',
        'owner':'orderflow.scanner_rest_price_with_paper_rest_fallback',
        'local_hit_count':_V1079_ENTRY_PRICE_LOCAL_HITS,
        'rest_fallback_count':_V1079_ENTRY_PRICE_REST_FALLBACKS,
        'cache_read_count':_V1079_ENTRY_PRICE_CACHE_READS,
        'cache_error_count':_V1079_ENTRY_PRICE_CACHE_ERRORS,
        'last_source':_V1079_ENTRY_PRICE_LAST_SOURCE,
        'last_age_sec':_V1079_ENTRY_PRICE_LAST_AGE_SEC,
        'fresh_limit_sec':4.0,
        'exit_price_owner_changed':False,
        'trigger_threshold_changed':False,
    }
    out['paper_performance_memory_v1081'] = dict(_V1081_PERF_MEMORY_STATS)
    out['paper_resource_profile_v1076'] = {
        'schema':'paper_resource_profile_status_v1076',
        'version':VERSION,
        'build':BUILD_LABEL,
        'cycle':dict(_V1076_LAST_CYCLE_PROFILE),
        'exit_monitor':dict(_V1076_LAST_EXIT_PROFILE),
        'active':_v1076_active_profile_snapshot(),
        'measurement_only':True,
        'strategy_impact':'none',
        'auto_buy':False,
    }
    _V1076_PREV_WRITE_STATUS(out)

_V1082_PERF_META: Dict[str, Any] = {}

_V1082_PERF_NOOP_PARSE_AVOIDED = 0

_V1082_PERF_FULL_RESULT_RELEASES = 0

_V1082_PERF_REAL_REBUILDS = 0

def _v1082_compact_perf_meta(snapshot: Any) -> Dict[str, Any]:
    if not isinstance(snapshot, dict):
        return {}
    counts = snapshot.get('counts') if isinstance(snapshot.get('counts'), dict) else {}
    window_counts = snapshot.get('window_counts') if isinstance(snapshot.get('window_counts'), dict) else {}
    return {
        'schema': snapshot.get('schema'),
        'version': snapshot.get('version'),
        'build': snapshot.get('build'),
        'snapshot_id': snapshot.get('snapshot_id'),
        'generated_at': snapshot.get('generated_at'),
        'generated_at_text': snapshot.get('generated_at_text'),
        'source_owner': snapshot.get('source_owner'),
        'source_digest': snapshot.get('source_digest'),
        'membership_digest': snapshot.get('membership_digest'),
        'counts': dict(counts),
        'window_counts': dict(window_counts),
        'canonical_snapshot_path': 'canonical_performance_snapshot_v987.json',
        'compact_runtime_reference_v1082': True,
        'full_rows_loaded': False,
    }

def write_status__v1082(status: Dict[str, Any]) -> None:  # type: ignore[override]
    out = dict(status or {})
    out['paper_performance_read_cache_v1082'] = {
        'schema': 'paper_performance_read_cache_v1082',
        'owner': 'paper_bot_single_canonical_performance_writer',
        'compact_meta_ready': bool(_V1082_PERF_META.get('snapshot_id')),
        'snapshot_id': _V1082_PERF_META.get('snapshot_id'),
        'unchanged_snapshot_full_parse_avoided': _V1082_PERF_NOOP_PARSE_AVOIDED,
        'full_snapshot_noop_reads': 0,
        'real_rebuild_count': _V1082_PERF_REAL_REBUILDS,
        'full_result_release_count': _V1082_PERF_FULL_RESULT_RELEASES,
        'canonical_output_changed': False,
        'entry_exit_changed': False,
    }
    out['paper_memory_reader_v1085'] = {
        'schema': 'paper_memory_reader_status_v1085',
        'closed_recent_index': dict(_V1085_CLOSED_RECENT_STATS),
        'closed_recent_cached_rows': len(_V1085_CLOSED_RECENT_CACHE.get('rows') or ()),
        'closed_recent_cached_ids': len(_V1085_CLOSED_RECENT_CACHE.get('id_counts') or {}),
        'status_candidate_reader': dict(_V1085_STATUS_CANDIDATE_STATS),
        'closed_full_dict_tail_materialization': False,
        'status_full_candidate_row_retention': False,
        'strategy_changed': False,
        'entry_exit_changed': False,
        'core_ledger_changed': False,
        'auto_buy': False,
    }
    v1092_stats = globals().get('_V1092_PERF_STATS')
    if isinstance(v1092_stats, dict):
        out['paper_performance_writer_v1092'] = dict(v1092_stats)
    _V1082_PREV_WRITE_STATUS(out)

_V1092_PERF_STATS: Dict[str, Any] = {
    'schema':'paper_performance_append_cursor_v1092',
    'owner':'paper_bot_single_canonical_performance_writer',
    'last_mode':'startup',
    'last_write_sec':0.0,
    'last_delta_bytes':0,
    'last_delta_rows':0,
    'last_processed_offset':0,
    'last_closed_size':0,
    'incremental_write_count':0,
    'boundary_refresh_count':0,
    'bootstrap_reseal_count':0,
    'open_membership_refresh_count':0,
    'noop_count':0,
    'full_rebuild_count':0,
    'full_rebuild_reasons':{},
    'closed_full_scan_on_normal_append':False,
    'canonical_snapshot_single_writer':True,
    'strategy_changed':False,
    'entry_exit_changed':False,
    'performance_formula_changed':False,
    'core_ledger_changed':False,
    'auto_buy':False,
}

_V1092_PERF_READY = False

_V1092_PERF_CURSOR: Dict[str, Any] = {}

def _v1092_snapshot_valid(snapshot: Any) -> bool:
    if not isinstance(snapshot, dict) or snapshot.get('schema') != _v987_perf_SCHEMA:
        return False
    if not isinstance(snapshot.get('rows'), list) or not isinstance(snapshot.get('counts'), dict):
        return False
    source = snapshot.get('source_meta') if isinstance(snapshot.get('source_meta'), dict) else {}
    membership = str(snapshot.get('membership_digest') or '')
    source_digest = str(snapshot.get('source_digest') or '')
    if not source or not membership or not source_digest:
        return False
    counts=snapshot.get('counts') if isinstance(snapshot.get('counts'),dict) else {}
    expected = _v987_perf_digest_json({'source':source,'counts':counts,'membership':membership})
    if expected == source_digest:
        return True
    # v1045 historically appended derived reset/epoch counts after source_digest.
    legacy_counts=dict(counts)
    for key in ('operator_reset_exact_rows_v1045','strategy_rows_excluding_operator_reset_v1045','current_epoch_exact_rows_v1045','current_epoch_open_rows_v1046','invalid_unexpected_open_rows_v1046'):
        legacy_counts.pop(key,None)
    legacy_expected=_v987_perf_digest_json({'source':source,'counts':legacy_counts,'membership':membership})
    return legacy_expected == source_digest

def _v1092_open_membership_digest(open_positions: Optional[Dict[str, Dict[str, Any]]]) -> str:
    positions=open_positions if isinstance(open_positions,dict) else {}
    material=[]
    for pid,row in positions.items():
        if not isinstance(row,dict):
            continue
        sealed_id=_v1044_reset_pos_id(str(pid),row) if '_v1044_reset_pos_id' in globals() else str(row.get('pos_id') or pid)
        material.append((sealed_id,str(row.get('performance_epoch_id') or ''),str(row.get('paper_decision_key_v926') or row.get('decision_key') or '')))
    material.sort()
    return _v987_perf_digest_json(material)

def _v1092_closed_decision_state(base_dir: Path) -> Tuple[Dict[str, Dict[str, Any]], int, str]:
    obj = _v987_perf_read_json(base_dir / 'paper_decision_state_v926.json', {}) or {}
    records = obj.get('records') if isinstance(obj, dict) and isinstance(obj.get('records'), dict) else {}
    closed: Dict[str, Dict[str, Any]] = {}
    for key, value in records.items():
        if not isinstance(value, dict) or str(value.get('status') or '').upper() != 'CLOSED':
            continue
        clean = str(key or value.get('paper_decision_key_v926') or '').strip()
        if clean.startswith('decision:'):
            clean = clean[len('decision:'):].strip()
        if clean:
            closed[clean] = value
    return closed, len(records), _paper_json_digest(closed)

def _v1092_read_closed_delta(path: Path, offset: int, base_raw_index: int) -> Tuple[List[Tuple[int, Dict[str, Any]]], int, int, int]:
    """Read complete append-only lines. Return rows, bad count, processed offset, bytes read."""
    st = path.stat()
    size = int(st.st_size)
    if offset < 0 or offset > size:
        raise RuntimeError(f'closed cursor out of range: {offset}>{size}')
    if offset > 0:
        with path.open('rb') as handle:
            handle.seek(offset - 1)
            if handle.read(1) != b'\n':
                raise RuntimeError('closed cursor is not on a line boundary')
    if size == offset:
        return [], 0, offset, 0
    with path.open('rb') as handle:
        handle.seek(offset)
        data = handle.read(size - offset)
    cut = len(data) if data.endswith(b'\n') else data.rfind(b'\n') + 1
    if cut <= 0:
        return [], 0, offset, len(data)
    complete = data[:cut]
    rows: List[Tuple[int, Dict[str, Any]]] = []
    bad = 0
    raw_index = int(base_raw_index)
    for raw in complete.splitlines():
        if not raw.strip():
            continue
        try:
            obj = json.loads(raw.decode('utf-8', errors='ignore'))
        except Exception:
            bad += 1
            continue
        if not isinstance(obj, dict):
            bad += 1
            continue
        rows.append((raw_index, obj))
        raw_index += 1
    return rows, bad, offset + cut, len(data)

def _v1092_finalize_snapshot(
    base_dir: Path,
    paper_version: str,
    build_label: str,
    nowv: float,
    rows: List[Dict[str, Any]],
    counts: Counter,
    excluded_samples: Dict[str, List[Dict[str, Any]]],
    duplicate_rows: List[Dict[str, Any]],
    decision_records_count: int,
    closed_decision_records_count: int,
    closed_records_digest: str,
    processed_offset: int,
    mode: str,
    active_open_v1092: Optional[Dict[str, Dict[str, Any]]]=None,
) -> Dict[str, Any]:
    closed_path = base_dir / 'paper_bot_closed.jsonl'
    decision_path = base_dir / 'paper_decision_state_v926.json'
    rows.sort(key=lambda r: (float(r.get('closed_at') or 0.0), str(r.get('identity') or '')))
    today_key = datetime.fromtimestamp(nowv, _v987_perf_KST).date()
    yesterday_key = today_key - timedelta(days=1)
    cutoff_3h, cutoff_6h, cutoff_24h = nowv-10800.0, nowv-21600.0, nowv-86400.0
    today_rows=[r for r in rows if float(r.get('closed_at') or 0.0)>0 and datetime.fromtimestamp(float(r['closed_at']),_v987_perf_KST).date()==today_key]
    yesterday_rows=[r for r in rows if float(r.get('closed_at') or 0.0)>0 and datetime.fromtimestamp(float(r['closed_at']),_v987_perf_KST).date()==yesterday_key]
    rows_3h=[r for r in rows if float(r.get('closed_at') or 0.0)>=cutoff_3h]
    rows_6h=[r for r in rows if float(r.get('closed_at') or 0.0)>=cutoff_6h]
    rows_24h=[r for r in rows if float(r.get('closed_at') or 0.0)>=cutoff_24h]
    contract_rows=[r for r in rows if bool(r.get('contract_ok'))]
    outside_rows=[r for r in rows if not bool(r.get('contract_ok'))]
    outside_reason_counts=Counter(str(r.get('exit_reason') or 'missing') for r in outside_rows)
    observation_ingress_rows=[r for r in rows if bool(r.get('observation_ingress_v988'))]
    today_observation_ingress_rows=[r for r in today_rows if bool(r.get('observation_ingress_v988'))]
    counts['historical_observation_ingress_rows_v988']=len(observation_ingress_rows)
    by_strategy: Dict[str,List[Dict[str,Any]]]=defaultdict(list)
    for row in today_rows:
        if not bool(row.get('observation_ingress_v988')):
            by_strategy[str(row.get('strategy') or _v987_perf_STRATEGY_MODE)].append(row)
    strategy_stats={name:_v987_perf_stat(group) for name,group in by_strategy.items()}
    diagnostics_24h_v1010=_v1010_perf_diagnostics(rows_24h)
    diagnostics_today_v1010=_v1010_perf_diagnostics(today_rows)
    baseline_exact_count_v989=35
    audit_rows_v989=rows[baseline_exact_count_v989:] if len(rows)>=baseline_exact_count_v989 else []
    audit_strategy_groups_v989: Dict[str,List[Dict[str,Any]]]=defaultdict(list)
    for audit_row in audit_rows_v989:
        audit_strategy_groups_v989[str(audit_row.get('strategy') or _v987_perf_STRATEGY_MODE)].append(audit_row)
    audit_strategy_stats_v989={name:_v987_perf_stat(group) for name,group in audit_strategy_groups_v989.items()}
    audit_observation_rows_v989=[r for r in audit_rows_v989 if bool(r.get('observation_ingress_v988'))]
    source_stat=closed_path.stat() if closed_path.exists() else None
    source_meta={
        'closed_path':closed_path.name,
        'closed_size':int(processed_offset),
        'closed_mtime_ns':source_stat.st_mtime_ns if source_stat else 0,
        'closed_inode_v1092':int(source_stat.st_ino) if source_stat else 0,
        'closed_processed_offset_v1092':int(processed_offset),
        'decision_path':decision_path.name,
        'decision_records':int(decision_records_count),
        'closed_decision_records':int(closed_decision_records_count),
        'closed_records_digest_v1092':str(closed_records_digest),
        'refresh_mode_v1092':str(mode),
        'open_membership_digest_v1092':_v1092_open_membership_digest(active_open_v1092),
    }
    membership_digest=_v987_perf_digest_json([(r.get('identity'),r.get('closed_at'),r.get('pnl_pct'),r.get('exit_reason')) for r in rows])
    source_digest=_v987_perf_digest_json({'source':source_meta,'counts':dict(counts),'membership':membership_digest})
    snapshot_id=f'perf-{int(nowv*1000)}-{source_digest[:12]}'
    snap = {
        'schema':_v987_perf_SCHEMA,'version':paper_version,'build':build_label,'snapshot_id':snapshot_id,
        'generated_at':nowv,'generated_at_text':datetime.fromtimestamp(nowv,_v987_perf_KST).strftime('%Y-%m-%d %H:%M:%S KST'),
        'source_owner':'paper_bot_single_canonical_performance_writer',
        'source_policy':'paper_bot_closed.jsonl only; decision state CLOSED required; decision-key dedupe; no alert-recovery performance rows; no reader-side recomputation',
        'strategy_mode':_v987_perf_STRATEGY_MODE,'cutover_ts':_v987_perf_CUTOVER_TS,
        'membership_policy':'OPEN-time ALT_SWING_V977 + CLOSED decision exact + first committed unique decision row',
        'source_meta':source_meta,'source_digest':source_digest,'membership_digest':membership_digest,
        'counts':dict(counts),'excluded_samples':dict(excluded_samples),'duplicate_samples':duplicate_rows,
        'windows':{'all':_v987_perf_stat(rows),'today':_v987_perf_stat(today_rows),'yesterday':_v987_perf_stat(yesterday_rows),'recent_3h':_v987_perf_stat(rows_3h),'recent_6h':_v987_perf_stat(rows_6h),'recent_24h':_v987_perf_stat(rows_24h)},
        'window_counts':{'all':len(rows),'today':len(today_rows),'yesterday':len(yesterday_rows),'recent_3h':len(rows_3h),'recent_6h':len(rows_6h),'recent_24h':len(rows_24h)},
        'current_exit_contract':{'analysis_only':True,'allowed_exit_reasons':sorted(_v987_perf_ALLOWED_EXIT_REASONS),'contract_ok_rows':len(contract_rows),'contract_outside_rows':len(outside_rows),'outside_reason_counts':dict(outside_reason_counts),'stats':_v987_perf_stat(contract_rows)},
        'today_strategy_stats':strategy_stats,
        'diagnostics_v1010':{'recent_24h':diagnostics_24h_v1010,'today':diagnostics_today_v1010},
        'historical_observation_ingress_v988':{'analysis_only':True,'all_rows':len(observation_ingress_rows),'today_rows':len(today_observation_ingress_rows),'all_stats':_v987_perf_stat(observation_ingress_rows),'today_stats':_v987_perf_stat(today_observation_ingress_rows),'policy':'historical exact rows remain in representative performance; excluded only from current trade-strategy breakdown'},
        'v989_exact_audit_since_v987_35':{'analysis_only':True,'baseline_exact_count':baseline_exact_count_v989,'current_exact_count':len(rows),'added_rows':len(audit_rows_v989),'stats':_v987_perf_stat(audit_rows_v989),'strategy_stats':audit_strategy_stats_v989,'observation_ingress_rows':len(audit_observation_rows_v989),'rows':audit_rows_v989,'policy':'first 35 exact rows were server-proven v987 cohort; later immutable decision-key rows are audit-only and do not alter canonical membership'},
        'recent_rows':rows[-20:],'rows':rows,
        'incremental_writer_v1092':{'mode':mode,'processed_offset':int(processed_offset),'raw_closed_full_scan':mode.startswith('full_rebuild'),'single_writer':True,'formula_changed':False},
        'invariants':{'single_source_ledger':True,'single_writer':True,'decision_closed_required':True,'dedupe_by_decision_key':True,'public_readers_recompute':False,'raw_ledger_preserved':True,'window_change_causes':['new exact CLOSED','24h/day boundary movement']},
    }
    snap=_v1045_apply_performance_epoch_contract(snap,nowv,active_open_v1092)
    snap['source_digest']=_v987_perf_digest_json({'source':snap.get('source_meta'),'counts':snap.get('counts'),'membership':snap.get('membership_digest')})
    snap['snapshot_id']=f"perf-{int(nowv*1000)}-{str(snap['source_digest'])[:12]}"
    return snap

def _v1092_apply_delta(
    previous: Dict[str, Any],
    delta_rows: List[Tuple[int, Dict[str, Any]]],
    bad_delta: int,
    closed_decisions: Dict[str, Dict[str, Any]],
) -> Tuple[List[Dict[str, Any]], Counter, Dict[str, List[Dict[str, Any]]], List[Dict[str, Any]], int]:
    rows=[r for r in previous.get('rows',[]) if isinstance(r,dict)]
    counts=Counter(previous.get('counts') if isinstance(previous.get('counts'),dict) else {})
    excluded: Dict[str,List[Dict[str,Any]]]=defaultdict(list)
    for key, values in (previous.get('excluded_samples') or {}).items():
        if isinstance(values,list): excluded[str(key)]=[dict(v) for v in values if isinstance(v,dict)][:5]
    duplicates=[dict(v) for v in (previous.get('duplicate_samples') or []) if isinstance(v,dict)][:20]
    by_key={str(r.get('decision_key') or ''):r for r in rows if str(r.get('decision_key') or '')}
    valid_delta=0
    for index,row in delta_rows:
        valid_delta+=1
        opened=_v987_perf_open_ts(row)
        if opened<=0:
            counts['missing_open_ts']+=1
            if len(excluded['missing_open_ts'])<5: excluded['missing_open_ts'].append({'index':index,'ticker':_v987_perf_ticker(row)})
            continue
        if opened<_v987_perf_CUTOVER_TS:
            counts['before_cutover']+=1; continue
        if _v987_perf_strategy_mode(row)!=_v987_perf_STRATEGY_MODE:
            counts['wrong_strategy_mode']+=1; continue
        counts['alt_swing_ledger_rows']+=1
        key=_v987_perf_decision_key(row); match_mode='decision_key_exact'
        if not key:
            counts['missing_decision_key']+=1
            if len(excluded['missing_decision_key'])<5: excluded['missing_decision_key'].append({'index':index,'ticker':_v987_perf_ticker(row),'pos_id':_v987_perf_pos_id(row)})
            continue
        if not isinstance(closed_decisions.get(key),dict):
            counts['decision_not_closed_or_missing']+=1
            if len(excluded['decision_not_closed_or_missing'])<5: excluded['decision_not_closed_or_missing'].append({'index':index,'ticker':_v987_perf_ticker(row),'decision_key':key})
            continue
        if _v987_perf_pnl_pct(row) is None:
            counts['missing_pnl']+=1
            if len(excluded['missing_pnl'])<5: excluded['missing_pnl'].append({'index':index,'ticker':_v987_perf_ticker(row),'decision_key':key})
            continue
        compact=_v987_perf_compact_row(row,key,match_mode)
        if key in by_key:
            counts['duplicate_closed_rows']+=1
            if len(duplicates)<20: duplicates.append({'decision_key':key,'ticker':compact.get('ticker'),'kept_closed_at':by_key[key].get('closed_at'),'duplicate_closed_at':compact.get('closed_at'),'policy':'first committed exact ledger row kept'})
            continue
        rows.append(compact); by_key[key]=compact
        counts['exact_unique_closed']+=1; counts[match_mode]+=1
    counts['raw_ledger_rows']=int(counts.get('raw_ledger_rows') or 0)+valid_delta
    counts['bad_json_rows']=int(counts.get('bad_json_rows') or 0)+int(bad_delta)
    return rows,counts,excluded,duplicates,valid_delta

def _v1092_previous_reference(previous: Dict[str, Any]) -> Dict[str, Any]:
    rows=previous.get('rows') if isinstance(previous.get('rows'),list) else []
    key_list=[str(r.get('decision_key') or '') for r in rows if isinstance(r,dict) and str(r.get('decision_key') or '')]
    return {
        'snapshot_id':previous.get('snapshot_id'),'generated_at':previous.get('generated_at'),
        'exact_count':len(rows),'key_list':key_list,
        'last_membership_change_v989':dict(previous.get('last_membership_change_v989')) if isinstance(previous.get('last_membership_change_v989'),dict) else {},
    }

def _v1092_add_membership_delta(snapshot: Dict[str, Any], previous_ref: Dict[str, Any]) -> None:
    current_rows=snapshot.get('rows') if isinstance(snapshot.get('rows'),list) else []
    previous_key_list=[str(x) for x in (previous_ref.get('key_list') or []) if str(x)]
    previous_keys=set(previous_key_list)
    current_keys={str(r.get('decision_key') or '') for r in current_rows if isinstance(r,dict) and str(r.get('decision_key') or '')}
    added_key_set=current_keys-previous_keys
    removed_keys=[k for k in previous_key_list if k not in current_keys]
    added_rows=[r for r in current_rows if isinstance(r,dict) and str(r.get('decision_key') or '') in added_key_set]
    delta={
        'analysis_only':True,'previous_snapshot_id':previous_ref.get('snapshot_id'),'previous_generated_at':previous_ref.get('generated_at'),
        'previous_exact_count':int(previous_ref.get('exact_count') or 0),'current_exact_count':len(current_rows),'added_count':len(added_rows),'removed_count':len(removed_keys),
        'added_stats':_v987_perf_stat(added_rows),'added_rows':added_rows[-20:],'removed_keys':removed_keys[:20],
        'membership_changed':bool(added_key_set or removed_keys),'changed_at':snapshot.get('generated_at'),'changed_at_text':snapshot.get('generated_at_text'),
        'policy':'comparison against immediately previous canonical snapshot; analysis only; no reader-side recomputation',
    }
    snapshot['previous_membership_delta_v989']=delta
    prior=previous_ref.get('last_membership_change_v989') if isinstance(previous_ref.get('last_membership_change_v989'),dict) else {}
    snapshot['last_membership_change_v989']=delta if delta['membership_changed'] else dict(prior)

def _v1092_write_snapshot(snapshot: Dict[str, Any], previous_ref: Dict[str, Any], mode: str, started: float, delta_bytes: int, delta_rows: int) -> Dict[str, Any]:
    global _PERFORMANCE_LAST_SIGNATURE,_PERFORMANCE_WRITE_COUNT,_PERFORMANCE_LAST_WRITE_AT,_PERFORMANCE_NEXT_BOUNDARY_TS
    global _V1082_PERF_META,_V1082_PERF_REAL_REBUILDS,_V1017_PERF_WRITE_COUNT,_V1017_PERF_LAST_REASON,_V1092_PERF_CURSOR
    _v1092_add_membership_delta(snapshot,previous_ref)
    _v987_perf_atomic_write_json(PERFORMANCE_SNAPSHOT_V987,snapshot)
    _v987_perf_atomic_write_json(BASE_DIR/'paper_bot_score_cache.json',_v987_perf_score_mirror(snapshot))
    _v987_perf_atomic_write_json(BASE_DIR/'paper_bot_trade_review_cache.json',_v987_perf_review_mirror(snapshot))
    source=snapshot.get('source_meta') if isinstance(snapshot.get('source_meta'),dict) else {}
    processed_offset=int(source.get('closed_processed_offset_v1092') or source.get('closed_size') or 0)
    processed_inode=int(source.get('closed_inode_v1092') or 0)
    processed_digest=str(source.get('closed_records_digest_v1092') or '')
    processed_open_digest=str(source.get('open_membership_digest_v1092') or '')
    _PERFORMANCE_LAST_SIGNATURE=(str(source.get('closed_path') or 'paper_bot_closed.jsonl'),processed_inode,processed_offset,'paper_closed_decision_records_digest_v1092',processed_digest,'open_membership_digest_v1092',processed_open_digest)
    _V1092_PERF_CURSOR={'inode':processed_inode,'offset':processed_offset,'closed_digest':processed_digest,'open_digest':processed_open_digest}
    _PERFORMANCE_WRITE_COUNT+=1; _PERFORMANCE_LAST_WRITE_AT=time.time()
    _PERFORMANCE_NEXT_BOUNDARY_TS=_canonical_performance_next_boundary(snapshot,time.time())
    _V1082_PERF_META=_v1082_compact_perf_meta(snapshot)
    _V1082_PERF_REAL_REBUILDS+=1; _V1017_PERF_WRITE_COUNT+=1
    _V1017_PERF_LAST_REASON=mode
    elapsed=time.monotonic()-started
    _V1092_PERF_STATS.update({
        'last_mode':mode,'last_write_sec':round(elapsed,6),'last_delta_bytes':int(delta_bytes),'last_delta_rows':int(delta_rows),
        'last_processed_offset':processed_offset,
        'last_closed_size':int((BASE_DIR/'paper_bot_closed.jsonl').stat().st_size) if (BASE_DIR/'paper_bot_closed.jsonl').exists() else 0,
        'last_snapshot_id':snapshot.get('snapshot_id'),'last_write_at':time.time(),'last_membership_digest':snapshot.get('membership_digest'),
        'rss_before_release_bytes':_v1081_rss_bytes(),
    })
    if mode=='incremental_append': _V1092_PERF_STATS['incremental_write_count']=int(_V1092_PERF_STATS.get('incremental_write_count') or 0)+1
    elif mode=='boundary_refresh': _V1092_PERF_STATS['boundary_refresh_count']=int(_V1092_PERF_STATS.get('boundary_refresh_count') or 0)+1
    elif mode=='bootstrap_reseal': _V1092_PERF_STATS['bootstrap_reseal_count']=int(_V1092_PERF_STATS.get('bootstrap_reseal_count') or 0)+1
    elif mode=='open_membership_refresh': _V1092_PERF_STATS['open_membership_refresh_count']=int(_V1092_PERF_STATS.get('open_membership_refresh_count') or 0)+1
    elif mode.startswith('full_rebuild'):
        _V1092_PERF_STATS['full_rebuild_count']=int(_V1092_PERF_STATS.get('full_rebuild_count') or 0)+1
        reasons=dict(_V1092_PERF_STATS.get('full_rebuild_reasons') or {}); reasons[mode]=int(reasons.get(mode) or 0)+1; _V1092_PERF_STATS['full_rebuild_reasons']=reasons
    return dict(_V1082_PERF_META)

def write_score_cache(status: Optional[Dict[str, Any]]=None, force: bool=False, open_positions: Optional[Dict[str, Dict[str, Any]]]=None) -> Dict[str, Any]:  # type: ignore[override]
    """Single canonical performance writer: snapshot bootstrap, append delta, boundary refresh, explicit recovery."""
    global _V1092_PERF_READY,_V1092_PERF_CURSOR,_PERFORMANCE_LAST_SIGNATURE,_PERFORMANCE_NEXT_BOUNDARY_TS
    global _V1082_PERF_META,_V1082_PERF_NOOP_PARSE_AVOIDED,_V1017_PERF_CHECK_COUNT,_V1017_PERF_SKIP_COUNT,_V1017_PERF_LAST_REASON
    started=time.monotonic(); _V1017_PERF_CHECK_COUNT+=1
    closed_path=BASE_DIR/'paper_bot_closed.jsonl'
    try:
        st=closed_path.stat(); current_inode=int(st.st_ino); current_size=int(st.st_size)
    except FileNotFoundError:
        current_inode=0; current_size=0
    if open_positions is None:
        open_positions=load_open()
    current_open_digest=_v1092_open_membership_digest(open_positions)
    current_signature=tuple(_canonical_performance_source_signature(time.time()))+('open_membership_digest_v1092',current_open_digest)
    nowv=time.time()
    boundary_due=bool(_PERFORMANCE_NEXT_BOUNDARY_TS and nowv>=_PERFORMANCE_NEXT_BOUNDARY_TS)
    if _V1092_PERF_READY and not force and not boundary_due and current_signature==_PERFORMANCE_LAST_SIGNATURE and _V1082_PERF_META.get('snapshot_id'):
        _V1092_PERF_STATS['noop_count']=int(_V1092_PERF_STATS.get('noop_count') or 0)+1
        _V1092_PERF_STATS.update({'last_mode':'noop','last_write_sec':round(time.monotonic()-started,6),'last_delta_bytes':0,'last_delta_rows':0})
        _V1082_PERF_NOOP_PARSE_AVOIDED+=1; _V1017_PERF_SKIP_COUNT+=1; _V1017_PERF_LAST_REASON='semantic_signature_unchanged_v1092'
        return dict(_V1082_PERF_META)

    previous=_v987_perf_read_json(PERFORMANCE_SNAPSHOT_V987,{}) or {}
    valid=_v1092_snapshot_valid(previous)
    previous_ref=_v1092_previous_reference(previous if isinstance(previous,dict) else {})
    previous_meta=_v1082_compact_perf_meta(previous) if valid else {}
    previous_version=str(previous.get('version') or '') if valid else ''
    previous_build=str(previous.get('build') or '') if valid else ''
    source=previous.get('source_meta') if valid and isinstance(previous.get('source_meta'),dict) else {}
    previous_offset=int(source.get('closed_processed_offset_v1092') or source.get('closed_size') or 0) if valid else 0
    previous_inode=int(source.get('closed_inode_v1092') or 0) if valid else 0
    previous_closed_digest=str(source.get('closed_records_digest_v1092') or '') if valid else ''
    previous_open_digest=str(source.get('open_membership_digest_v1092') or '') if valid else ''
    current_closed_digest=str(current_signature[-3]) if len(current_signature)>=3 else ''

    mode=''; delta_bytes=0; delta_count=0
    needs_full_reason=''
    if not valid:
        needs_full_reason='full_rebuild_invalid_or_missing_snapshot'
    elif current_size<previous_offset:
        needs_full_reason='full_rebuild_closed_truncated'
    elif previous_inode and current_inode!=previous_inode:
        needs_full_reason='full_rebuild_closed_inode_changed'
    elif current_size==previous_offset and previous_closed_digest and current_closed_digest!=previous_closed_digest:
        needs_full_reason='full_rebuild_closed_decision_digest_changed_without_append'

    if needs_full_reason:
        del previous
        _v1081_release_heap('v1092_previous_snapshot_released_before_full_rebuild')
        snapshot=_v987_perf_build_snapshot(BASE_DIR,VERSION,BUILD_LABEL,now_value=nowv)
        closed_decisions,decision_total,closed_digest=_v1092_closed_decision_state(BASE_DIR)
        closed_total=len(closed_decisions); del closed_decisions
        source2=snapshot.get('source_meta') if isinstance(snapshot.get('source_meta'),dict) else {}
        source2.update({'closed_inode_v1092':current_inode,'closed_processed_offset_v1092':current_size,'closed_size':current_size,'closed_records_digest_v1092':closed_digest,'decision_records':decision_total,'closed_decision_records':closed_total,'refresh_mode_v1092':needs_full_reason,'open_membership_digest_v1092':current_open_digest})
        snapshot['source_meta']=source2
        snapshot['source_digest']=_v987_perf_digest_json({'source':source2,'counts':snapshot.get('counts'),'membership':snapshot.get('membership_digest')})
        snapshot['snapshot_id']=f"perf-{int(nowv*1000)}-{str(snapshot['source_digest'])[:12]}"
        mode=needs_full_reason
    else:
        canonical_rows=previous.get('rows') if isinstance(previous.get('rows'),list) else []
        rows=[r for r in canonical_rows if isinstance(r,dict)]
        counts=Counter(previous.get('counts') if isinstance(previous.get('counts'),dict) else {})
        excluded: Dict[str,List[Dict[str,Any]]]=defaultdict(list)
        for k,v in (previous.get('excluded_samples') or {}).items():
            if isinstance(v,list): excluded[str(k)]=[dict(x) for x in v if isinstance(x,dict)][:5]
        duplicates=[dict(x) for x in (previous.get('duplicate_samples') or []) if isinstance(x,dict)][:20]
        decision_total=int(source.get('decision_records') or 0); closed_total=int(source.get('closed_decision_records') or 0)
        closed_digest=current_closed_digest
        processed_offset=previous_offset
        # Remove duplicate audit/diagnostic copies before finalizing the next snapshot.
        previous.clear()
        del previous, canonical_rows
        _v1081_release_heap('v1092_previous_snapshot_noncanonical_copies_released')
        baseline={'rows':rows,'counts':dict(counts),'excluded_samples':dict(excluded),'duplicate_samples':duplicates}
        if current_size>previous_offset:
            closed_decisions,decision_total,closed_digest=_v1092_closed_decision_state(BASE_DIR); closed_total=len(closed_decisions)
            delta,bad,processed_offset,delta_bytes=_v1092_read_closed_delta(closed_path,previous_offset,int(counts.get('raw_ledger_rows') or 0))
            rows,counts,excluded,duplicates,delta_count=_v1092_apply_delta(baseline,delta,bad,closed_decisions)
            mode='incremental_append'; del closed_decisions,delta
        elif previous_open_digest and current_open_digest!=previous_open_digest:
            mode='open_membership_refresh'
        elif boundary_due:
            mode='boundary_refresh'
        elif force:
            mode='forced_compact_reseal'
        elif previous_version!=VERSION or previous_build!=BUILD_LABEL or not previous_inode or not previous_closed_digest or not previous_open_digest:
            mode='bootstrap_reseal'
        else:
            _V1092_PERF_READY=True; _V1092_PERF_CURSOR={'inode':current_inode,'offset':previous_offset,'closed_digest':current_closed_digest,'open_digest':current_open_digest}
            _PERFORMANCE_LAST_SIGNATURE=current_signature
            compact_source={'rows':rows}
            _PERFORMANCE_NEXT_BOUNDARY_TS=_canonical_performance_next_boundary(compact_source,nowv)
            # Reuse already-read compact metadata without a second canonical JSON parse.
            _V1082_PERF_META=dict(previous_meta)
            del compact_source,baseline,rows
            reclaim=_v1081_release_heap('v1092_startup_snapshot_reuse_release')
            _V1092_PERF_STATS.update({'last_mode':'startup_snapshot_reuse','last_write_sec':round(time.monotonic()-started,6),'last_delta_bytes':0,'last_delta_rows':0,'last_processed_offset':previous_offset,'last_closed_size':current_size,'last_snapshot_id':_V1082_PERF_META.get('snapshot_id'),'last_reclaim':reclaim})
            _V1017_PERF_SKIP_COUNT+=1; _V1017_PERF_LAST_REASON='startup_snapshot_reuse_v1092'
            del previous_ref,previous_meta
            return dict(_V1082_PERF_META)
        del baseline
        snapshot=_v1092_finalize_snapshot(BASE_DIR,VERSION,BUILD_LABEL,nowv,rows,counts,excluded,duplicates,decision_total,closed_total,closed_digest,processed_offset,mode,open_positions)

    meta=_v1092_write_snapshot(snapshot,previous_ref,mode,started,delta_bytes,delta_count)
    _V1092_PERF_READY=True
    del snapshot,previous_ref,previous_meta
    reclaim=_v1081_release_heap('v1092_canonical_objects_released_after_write')
    _V1092_PERF_STATS['rss_after_release_bytes']=_v1081_rss_bytes(); _V1092_PERF_STATS['last_reclaim']=reclaim
    return meta

if '_run_classify_helper_v1013' in globals():
    _V1113_PREV_CLASSIFY_HELPER = _run_classify_helper_v1013
    def _run_classify_helper_v1013__v1113_probe(*args,**kwargs):
        return _v1113_probe_helper('classify_helper',_V1113_PREV_CLASSIFY_HELPER,*args,**kwargs)
    _run_classify_helper_v1013=_run_classify_helper_v1013__v1113_probe

PAPER_HEAP_RECLAIM_STATUS_V1116 = BASE_DIR / 'paper_heap_reclaim_status_v1116.json'

_V1116_RECLAIM_LOCK = threading.RLock()

_V1116_LAST_RECLAIM_MONO = 0.0

_V1116_RECLAIM_COUNT = 0

_V1116_RECLAIM_COOLDOWN_SEC = 60.0

_V1116_RECLAIM_TRIGGER_BYTES = 768 * 1024 * 1024

_V1116_RECLAIM_PROOF_BYTES = 64 * 1024 * 1024

_V1116_LAST_RECLAIM_STATUS: Dict[str, Any] = {}

def _v1116_allocated_blocks() -> int:
    try:
        return int(getattr(sys, 'getallocatedblocks', lambda: 0)() or 0)
    except Exception:
        return 0

def _v1116_write_reclaim_status(payload: Dict[str, Any]) -> bool:
    try:
        return bool(_paper_write_json_verified(PAPER_HEAP_RECLAIM_STATUS_V1116, payload))
    except Exception as exc:
        try:
            log_error('paper_heap_reclaim_status_v1116', exc)
        except Exception:
            pass
        return False

def _v1116_maybe_reclaim_heap(scope: str) -> Dict[str, Any]:
    """Rate-limited safe-boundary reclaim and allocator/live-reference proof."""
    global _V1116_LAST_RECLAIM_MONO, _V1116_RECLAIM_COUNT, _V1116_LAST_RECLAIM_STATUS
    nowm = time.monotonic()
    before_rss = int(_v1081_rss_bytes() or 0)
    before_blocks = _v1116_allocated_blocks()
    with _V1116_RECLAIM_LOCK:
        cooldown_remaining = max(0.0, _V1116_RECLAIM_COOLDOWN_SEC - (nowm - _V1116_LAST_RECLAIM_MONO)) if _V1116_LAST_RECLAIM_MONO else 0.0
        blocked_reason = ''
        if int(globals().get('_EXACT_COMMIT_DEPTH') or 0) != 0:
            blocked_reason = 'exact_commit_active'
        elif before_rss < _V1116_RECLAIM_TRIGGER_BYTES:
            blocked_reason = 'rss_below_trigger'
        elif cooldown_remaining > 0:
            blocked_reason = 'cooldown'
        if blocked_reason:
            payload = {
                'schema':'paper_heap_reclaim_status_v1116','version':VERSION,'build':BUILD_LABEL,
                'pid':os.getpid(),'updated_ts':now_ts(),'updated_text':iso_ts(),
                'scope':str(scope),'attempted':False,'blocked_reason':blocked_reason,
                'before_rss_bytes':before_rss,'after_rss_bytes':before_rss,'released_rss_bytes':0,
                'before_allocated_blocks':before_blocks,'after_allocated_blocks':before_blocks,
                'allocated_blocks_delta':0,'cooldown_remaining_sec':round(cooldown_remaining,3),
                'reclaim_count':_V1116_RECLAIM_COUNT,'allocator_retention_proven':False,
                'live_reference_growth_suspected':False,'exact_commit_active':bool(globals().get('_EXACT_COMMIT_DEPTH')),
                'trade_rules_changed':False,'ledger_contract_changed':False,'auto_buy':False,
                'policy':'safe-boundary, high-RSS, rate-limited diagnostic reclaim; no trade or ledger mutation',
            }
            _V1116_LAST_RECLAIM_STATUS = payload
            # Avoid a status write every one-second exit sweep when below threshold/cooldown.
            if blocked_reason not in {'rss_below_trigger','cooldown'}:
                _v1116_write_reclaim_status(payload)
            return payload

        _V1116_LAST_RECLAIM_MONO = nowm
        reclaim = _v1081_release_heap(f'v1116_{scope}_safe_boundary')
        _V1116_RECLAIM_COUNT += 1
        after_rss = int(reclaim.get('after_rss_bytes') or _v1081_rss_bytes() or 0)
        after_blocks = _v1116_allocated_blocks()
        released = max(0, before_rss - after_rss)
        block_delta = after_blocks - before_blocks
        allocator_proven = released >= _V1116_RECLAIM_PROOF_BYTES
        # If trim cannot return meaningful RSS and Python blocks keep increasing,
        # retain CHECK instead of declaring allocator retention fixed.
        live_ref_suspected = bool(not allocator_proven and block_delta > 10000)
        payload = {
            'schema':'paper_heap_reclaim_status_v1116','version':VERSION,'build':BUILD_LABEL,
            'pid':os.getpid(),'updated_ts':now_ts(),'updated_text':iso_ts(),
            'scope':str(scope),'attempted':True,'blocked_reason':None,
            'before_rss_bytes':before_rss,'after_rss_bytes':after_rss,'released_rss_bytes':released,
            'before_allocated_blocks':before_blocks,'after_allocated_blocks':after_blocks,
            'allocated_blocks_delta':block_delta,'gc_collected':reclaim.get('gc_collected'),
            'malloc_trim_result':reclaim.get('malloc_trim_result'),'reclaim_error':reclaim.get('error'),
            'reclaim_count':_V1116_RECLAIM_COUNT,'allocator_retention_proven':allocator_proven,
            'live_reference_growth_suspected':live_ref_suspected,
            'proof_threshold_bytes':_V1116_RECLAIM_PROOF_BYTES,
            'exact_commit_active':bool(globals().get('_EXACT_COMMIT_DEPTH')),
            'trade_rules_changed':False,'ledger_contract_changed':False,'auto_buy':False,
            'policy':'safe-boundary, high-RSS, rate-limited diagnostic reclaim; no trade or ledger mutation',
        }
        _V1116_LAST_RECLAIM_STATUS = payload
        _v1116_write_reclaim_status(payload)
        return payload

_V1117_PERF_SEMANTIC_HEARTBEAT: Dict[str, Any] = {
    'schema':'paper_performance_semantic_heartbeat_v1117',
    'owner':'paper_bot_single_canonical_performance_writer',
    'state':'STARTUP',
    'last_check_at':0.0,
    'semantic_current':False,
    'trade_rules_changed':False,
    'performance_formula_changed':False,
    'canonical_snapshot_rewrite_for_heartbeat':False,
}

def write_score_cache__v1117(
    status: Optional[Dict[str, Any]]=None,
    force: bool=False,
    open_positions: Optional[Dict[str, Dict[str, Any]]]=None,
) -> Dict[str, Any]:  # type: ignore[override]
    global _V1117_PERF_SEMANTIC_HEARTBEAT
    nowv=time.time()
    positions=open_positions if isinstance(open_positions,dict) else load_open()
    open_digest=_v1092_open_membership_digest(positions)
    checked_signature=tuple(_canonical_performance_source_signature(nowv)) + ('open_membership_digest_v1092',open_digest)
    boundary_due_before=bool(_PERFORMANCE_NEXT_BOUNDARY_TS and nowv>=_PERFORMANCE_NEXT_BOUNDARY_TS)
    result=_V1117_PREV_WRITE_SCORE_CACHE(status,force=force,open_positions=positions)
    checked_at=time.time()
    last_mode=str(_V1092_PERF_STATS.get('last_mode') or '')
    signature_match=bool(_PERFORMANCE_LAST_SIGNATURE is not None and checked_signature==tuple(_PERFORMANCE_LAST_SIGNATURE))
    boundary_due_after=bool(_PERFORMANCE_NEXT_BOUNDARY_TS and checked_at>=_PERFORMANCE_NEXT_BOUNDARY_TS)
    try:
        st=PERFORMANCE_SNAPSHOT_V987.stat()
        snapshot_exists=True
        snapshot_mtime=float(st.st_mtime)
        snapshot_age=max(0.0,checked_at-snapshot_mtime)
    except OSError:
        snapshot_exists=False
        snapshot_mtime=0.0
        snapshot_age=None
    semantic_idle=bool(
        not force and snapshot_exists and signature_match and not boundary_due_after
        and last_mode in {'noop','startup_snapshot_reuse'}
        and bool(_V1082_PERF_META.get('snapshot_id'))
    )
    semantic_current=bool(snapshot_exists and signature_match and not boundary_due_after and bool(_V1082_PERF_META.get('snapshot_id')))
    _V1117_PERF_SEMANTIC_HEARTBEAT={
        'schema':'paper_performance_semantic_heartbeat_v1117',
        'owner':'paper_bot_single_canonical_performance_writer',
        'state':'EVENT_DRIVEN_IDLE' if semantic_idle else ('CURRENT_AFTER_WRITE' if semantic_current else 'CHECK'),
        'last_check_at':checked_at,
        'last_check_text':iso_ts(checked_at),
        'last_mode':last_mode,
        'semantic_current':semantic_current,
        'event_driven_idle':semantic_idle,
        'source_signature_match':signature_match,
        'source_signature_digest':_v987_perf_digest_json(list(checked_signature)),
        'open_membership_digest':open_digest,
        'boundary_due_before_check':boundary_due_before,
        'boundary_due_after_check':boundary_due_after,
        'next_boundary_ts':float(_PERFORMANCE_NEXT_BOUNDARY_TS or 0.0),
        'next_boundary_in_sec':round(max(0.0,float(_PERFORMANCE_NEXT_BOUNDARY_TS or 0.0)-checked_at),3) if _PERFORMANCE_NEXT_BOUNDARY_TS else None,
        'snapshot_exists':snapshot_exists,
        'snapshot_id':_V1082_PERF_META.get('snapshot_id'),
        'snapshot_generated_at':_V1082_PERF_META.get('generated_at'),
        'snapshot_mtime':snapshot_mtime,
        'snapshot_age_sec':round(snapshot_age,3) if isinstance(snapshot_age,(int,float)) else None,
        'last_real_write_at':float(_PERFORMANCE_LAST_WRITE_AT or 0.0),
        'canonical_snapshot_rewrite_for_heartbeat':False,
        'freshness_policy':'SEMANTIC_SIGNATURE_EVENT_DRIVEN',
        'trade_rules_changed':False,
        'performance_formula_changed':False,
        'ledger_contract_changed':False,
        'auto_buy':False,
    }
    return result

VERSION = 'paper_bot_v1.020'

BUILD_LABEL = 'v1122_structured_paper_safety_reason_contract_2026-06-29'

if '_V1113_PREV_LOAD_OPEN' in globals():
    load_open = _V1113_PREV_LOAD_OPEN

if '_V1113_PREV_SELECT_CANDIDATES' in globals():
    select_candidates = _V1113_PREV_SELECT_CANDIDATES

if '_V1113_PREV_CLASSIFY_HELPER' in globals():
    _run_classify_helper_v1013 = _V1113_PREV_CLASSIFY_HELPER

def write_status__v1121_no_heavy_probe(status: Dict[str, Any]) -> None:
    out=dict(status or {})
    heartbeat=dict(_V1117_PERF_SEMANTIC_HEARTBEAT) if isinstance(_V1117_PERF_SEMANTIC_HEARTBEAT,dict) else {}
    checked=float(heartbeat.get('last_check_at') or 0.0)
    heartbeat['check_age_sec']=round(max(0.0,time.time()-checked),3) if checked>0 else None
    out['paper_performance_semantic_heartbeat_v1117']=heartbeat
    out['paper_resource_probe_v1113_active']=False
    out['paper_memory_owner_v1121']='heavy diagnostic probe retired; safe reclaim retained'
    _V1113_PREV_WRITE_STATUS(out)

def run_exact_exit_monitor__v1121_no_heavy_probe(ctrl: Optional[Dict[str, Any]]=None, owner: str='paper_exact_exit_monitor') -> Dict[str, Any]:
    try:
        return _V1113_PREV_EXIT_MONITOR(ctrl,owner)
    finally:
        if int(globals().get('_EXACT_COMMIT_DEPTH') or 0)==0:
            _v1116_maybe_reclaim_heap('exit_monitor_v1121')

VERSION = 'paper_bot_v1.036'

BUILD_LABEL = 'v1167_canonical_trigger_price_path_consumer_2026-07-01'

V1135_RESET_BASELINE = BASE_DIR / 'paper_v1135_fresh_epoch_reset_baseline.json'

V1135_TRIGGER_AUDIT = BASE_DIR / 'paper_trigger_occurrence_audit_v1135.json'

V1135_FRESH_PATH_EVIDENCE = BASE_DIR / 'paper_fresh_path_evidence_v1135.json'

V1135_STRATEGY_TRIGGER_STATE = BASE_DIR / 'clean_strategy_swing_gate_state_v977.json'

def _v1135_update_trigger_stability_audit() -> Dict[str, Any]:
    """Read-only audit: a decision must not change while the same event remains above."""
    source=load_json(V1135_STRATEGY_TRIGGER_STATE,{}) or {}
    active=source.get('active') if isinstance(source,dict) and isinstance(source.get('active'),dict) else {}
    audit=load_json(V1135_TRIGGER_AUDIT,{}) or {}
    if not isinstance(audit,dict): audit={}
    last_source_ts=float(fnum(audit.get('last_strategy_updated_ts'),default=0.0))
    source_ts=float(fnum(source.get('updated_ts'),default=0.0))
    if source_ts<=0 or not active:
        return audit if audit else {'schema':'paper_trigger_occurrence_audit_v1135','state':'SOURCE_MISSING','same_above_decision_violation_count':0,'qualified_above_stable_samples':0}
    if source_ts==last_source_ts:
        return audit
    previous=audit.get('state') if isinstance(audit.get('state'),dict) else {}
    state=dict(previous)
    violations=int(fnum(audit.get('same_above_decision_violation_count'),default=0.0))
    stable=int(fnum(audit.get('qualified_above_stable_samples'),default=0.0))
    qualified_seen=int(fnum(audit.get('qualified_event_seen'),default=0.0))
    samples=list(audit.get('violation_samples') or []) if isinstance(audit.get('violation_samples'),list) else []
    for key,rec in active.items():
        if not isinstance(rec,dict): continue
        side=str(rec.get('trigger_side') or '').lower()
        decision=str(rec.get('trigger_occurrence_decision_key') or '')
        reset_ts=float(fnum(rec.get('trigger_reset_ts'),default=0.0))
        event_ts=float(fnum(rec.get('trigger_event_ts'),default=0.0))
        qualification=str(rec.get('trigger_qualification_state') or '')
        prior=previous.get(str(key)) if isinstance(previous.get(str(key)),dict) else {}
        if decision and qualification=='QUALIFIED_EVENT': qualified_seen+=1
        same_above=side=='above' and str(prior.get('side') or '')=='above' and abs(float(fnum(prior.get('reset_ts'),default=0.0))-reset_ts)<0.000001
        if same_above:
            prior_decision=str(prior.get('decision') or '')
            if decision!=prior_decision:
                violations+=1
                samples.append({'state_key':str(key),'previous_decision':prior_decision or None,'current_decision':decision or None,'reset_ts':reset_ts,'previous_event_ts':prior.get('event_ts'),'current_event_ts':event_ts,'detected_at':now_ts()})
            elif decision and qualification=='QUALIFIED_EVENT':
                stable+=1
        state[str(key)]={'side':side,'decision':decision or None,'reset_ts':reset_ts or None,'event_ts':event_ts or None,'qualification_state':qualification or None,'seen_at':now_ts()}
    out={
        'schema':'paper_trigger_occurrence_audit_v1135','version':VERSION,'build':BUILD_LABEL,
        'updated_at':now_ts(),'updated_text':iso_ts(),'last_strategy_updated_ts':source_ts or None,
        'active_state_count':len(active),'qualified_event_seen':qualified_seen,
        'qualified_above_stable_samples':stable,
        'same_above_decision_violation_count':violations,
        'violation_samples':samples[-20:],'state':state,
        'owner':'Paper read-only audit of Strategy clean_strategy_swing_gate_state_v977.json',
        'policy':'same state_key + same reset_ts + above must keep one decision/event; no Strategy mutation',
        'auto_buy':False,
    }
    _paper_write_json_verified(V1135_TRIGGER_AUDIT,out)
    return out

def _v1135_update_fresh_path_evidence(status: Dict[str, Any]) -> Dict[str, Any]:
    epoch=_v1045_epoch() if '_v1045_epoch' in globals() else {}
    epoch_id=str(epoch.get('epoch_id') or '') if isinstance(epoch,dict) else ''
    existing=load_json(V1135_FRESH_PATH_EVIDENCE,{}) or {}
    if not isinstance(existing,dict) or str(existing.get('epoch_id') or '')!=epoch_id:
        existing={
            'schema':'paper_fresh_path_evidence_v1135','version':VERSION,'build':BUILD_LABEL,
            'epoch_id':epoch_id or None,'epoch_started_at':epoch.get('started_at') if isinstance(epoch,dict) else None,
            'occurrence_fresh_pass_seen':False,'paper_ttl_pass_seen':False,
            'paper_execution_pass_seen':False,'paper_final_safety_pass_seen':False,
            'selected_or_opened_seen':False,'first_seen_at':None,'last_seen_at':None,'samples':[],
            'policy':'post-v1135 epoch cumulative evidence; no reader-side reconstruction of entry contract',
        }
    pick=status.get('pick_stats') if isinstance(status,dict) and isinstance(status.get('pick_stats'),dict) else {}
    current={
        'occurrence_fresh_pass_seen':int(fnum(pick.get('trigger_occurrence_fresh_pass'),default=0.0))>0,
        'paper_ttl_pass_seen':int(fnum(pick.get('paper_ttl_pass_v1099'),default=0.0))>0,
        'paper_execution_pass_seen':int(fnum(pick.get('paper_execution_pass_v1099'),default=0.0))>0,
        'paper_final_safety_pass_seen':int(fnum(pick.get('paper_final_safety_pass_v1099'),default=0.0))>0,
        'selected_or_opened_seen':int(fnum(pick.get('selected_s1'),status.get('opened_this_cycle'),default=0.0))>0,
    }
    changed=False
    for key,val in current.items():
        if val and not existing.get(key): existing[key]=True; changed=True
    if any(current.values()):
        nowv=now_ts(); existing['first_seen_at']=existing.get('first_seen_at') or nowv; existing['last_seen_at']=nowv
        sample={
            'ts':nowv,'text':iso_ts(nowv),
            'strategy_decision':pick.get('last_open_try') or pick.get('last_s1_seen'),
            'counts':{k:pick.get(k) for k in ('trigger_occurrence_fresh_pass','paper_ttl_pass_v1099','paper_execution_pass_v1099','paper_final_safety_pass_v1099','selected_s1')},
        }
        samples=list(existing.get('samples') or []) if isinstance(existing.get('samples'),list) else []
        sig=json.dumps(sample.get('counts'),sort_keys=True,default=str)+json.dumps(sample.get('strategy_decision'),sort_keys=True,default=str)
        last_sig=str(existing.get('last_sample_signature') or '')
        if sig!=last_sig:
            samples.append(sample); existing['samples']=samples[-20:]; existing['last_sample_signature']=sig; changed=True
    existing['updated_at']=now_ts(); existing['updated_text']=iso_ts(); existing['complete']=all(bool(existing.get(k)) for k in current)
    prior=load_json(V1135_FRESH_PATH_EVIDENCE,{}) or {}
    if changed or prior!=existing:
        _paper_write_json_verified(V1135_FRESH_PATH_EVIDENCE,existing)
    return existing

def _read_current_candidate_snapshot() -> Tuple[List[Dict[str, Any]], Dict[str, Any]]:
    """Read one complete Strategy atomic snapshot; never a tail sample."""
    path=FILES.get('paper_latest',BASE_DIR/'paper_candidates_latest.jsonl')
    rows: List[Dict[str, Any]]=[]; invalid=0; line_count=0; file_bytes=0
    try:
        file_bytes=int(path.stat().st_size)
        with path.open('r',encoding='utf-8',errors='strict') as handle:
            for line in handle:
                if not line.strip(): continue
                line_count+=1
                obj=json.loads(line)
                if isinstance(obj,dict): rows.append(obj)
                else: invalid+=1
    except Exception as exc:
        scope={'schema':'paper_candidate_summary_scope_v1143','state':'CHECK','reason':f'{exc.__class__.__name__}: {exc}','owner':'Strategy atomic candidate writer proof -> Paper full read-only command reader','tail_cap_removed':True,'current_snapshot_atomic':True}
        return [],scope
    writer=load_json(BASE_DIR/'clean_strategy_paper_latest_writer_status.json',{}) or {}
    expected=int(fnum(writer.get('rows_written'),writer.get('candidate_rows_v1021'),writer.get('compact_rows'),default=-1.0)) if isinstance(writer,dict) else -1
    writer_result=str(writer.get('result') or '') if isinstance(writer,dict) else ''
    state='NORMAL' if invalid==0 and len(rows)==line_count and writer_result=='OK' and expected==len(rows) else 'CHECK'
    scope={
        'schema':'paper_candidate_summary_scope_v1143','state':state,
        'owner':'Strategy atomic candidate writer proof -> Paper full read-only command reader',
        'current_snapshot_atomic':True,'tail_cap_removed':True,'legacy_tail_cap':300,
        'file_lines':line_count,'parsed_rows':len(rows),'invalid_lines':invalid,
        'writer_result':writer_result or None,'writer_expected_rows':expected if expected>=0 else None,'file_bytes':file_bytes,
        'judgement_policy':'S1/S2/S3 distribution is current atomic snapshot only; scope CHECK on writer/file mismatch',
    }
    return rows,scope

def write_status__v1135(status: Dict[str, Any]) -> None:
    out=dict(status or {})
    audit=_v1135_update_trigger_stability_audit()
    fresh_evidence=_v1135_update_fresh_path_evidence(out)
    baseline=load_json(V1135_RESET_BASELINE,{}) or {}
    reset=load_json(BOOK_RESET_STATUS_V1044,{}) or {}
    manifest=_v1045_manifest() if '_v1045_manifest' in globals() else {}
    epoch=_v1045_epoch() if '_v1045_epoch' in globals() else {}
    writer_status=load_json(BASE_DIR/'clean_strategy_paper_latest_writer_status.json',{}) or {}
    scope_status=writer_status.get('candidate_snapshot_scope') if isinstance(writer_status.get('candidate_snapshot_scope'),dict) else {}
    out['candidate_summary_scope_v1143']={
        'schema':'paper_candidate_summary_scope_v1143',
        'state':'NORMAL' if scope_status.get('state')=='NORMAL' and scope_status.get('complete_snapshot') is True and scope_status.get('atomic_replace') is True else 'CHECK',
        'owner':'Strategy atomic candidate writer proof -> Paper read-only command',
        'current_snapshot_atomic':bool(scope_status.get('atomic_replace')),
        'complete_snapshot':bool(scope_status.get('complete_snapshot')),
        'tail_cap_removed':scope_status.get('tail_cap') is None,
        'rows_written':scope_status.get('rows_written'),
        'output_bytes':scope_status.get('output_bytes'),
        'commit_id':scope_status.get('commit_id'),
        'proof_ts':scope_status.get('updated_ts'),
        'formula_changed':False,'entry_contract_changed':False,
    }
    out['strategy_candidate_pipeline_v1150']=strategy_candidate_pipeline_ready_v1150(effective_ctrl if 'effective_ctrl' in locals() else load_control())
    out['candidate_rr_reader_v1135']={
        'schema':'paper_candidate_rr_reader_v1135','owner':'swing_entry_gate_v977.risk_reward',
        'missing_policy':'MISSING/CHECK','zero_fallback_removed':True,'formula_changed':False,
    }
    out['fresh_epoch_reset_v1135']={
        'schema':'paper_fresh_epoch_reset_v1135','approved':True,
        'batch_id':manifest.get('batch_id'),'reason':manifest.get('recovery_reason_v1097'),
        'target_open_count':manifest.get('target_open_count',baseline.get('target_open_count')),
        'state':reset.get('state'),'remaining_target_open_count':reset.get('remaining_target_open_count'),
        'unresolved_target_count':reset.get('unresolved_target_count'),'zero_open_proof':reset.get('zero_open_proof'),
        'performance_epoch_id':epoch.get('epoch_id'),'performance_epoch_state':epoch.get('state'),
        'baseline_stale_occurrence_proof':baseline.get('stale_occurrence_proof_before_reset'),
        'ledger_deleted':False,'strategy_contract_changed':False,'auto_buy':False,
    }
    effective_ctrl=load_control()
    out['effective_control_contract_v1142']={
        'schema':'paper_effective_control_contract_v1142',
        'state':'NORMAL',
        'owner':'paper_bot.load_control',
        'candidate_ttl_sec':fnum(effective_ctrl.get('candidate_ttl_sec'),default=120.0),
        'max_open_strict':int(fnum(effective_ctrl.get('max_open_strict'),default=30)),
        'max_new_per_cycle':int(fnum(effective_ctrl.get('max_new_per_cycle'),default=3)),
        'new_open_paused':bool(effective_ctrl.get('new_open_paused')),
        'running':bool(effective_ctrl.get('running',True)),
        'exit_contract':{
            'swing_emergency_stop_pct':fnum(effective_ctrl.get('swing_emergency_stop_pct'),default=-2.50),
            'swing_no_progress_minutes':fnum(effective_ctrl.get('swing_no_progress_minutes'),default=360.0),
            'swing_trailing_trigger_pct':fnum(effective_ctrl.get('swing_trailing_trigger_pct'),default=2.00),
            'swing_trailing_giveback_pct':fnum(effective_ctrl.get('swing_trailing_giveback_pct'),default=0.80),
            'time_exit_minutes':fnum(effective_ctrl.get('time_exit_minutes'),default=0.0),
        },
        'source':'DEFAULT_CONTROL + paper_bot_control.json + v1174 raw override',
        'strategy_formula_changed':False,
        'exit_formula_changed':False,
        'open_limit_changed':True,
        'auto_buy':False,
    }
    out['trigger_occurrence_audit_v1135']={k:audit.get(k) for k in ('schema','updated_at','last_strategy_updated_ts','active_state_count','qualified_event_seen','qualified_above_stable_samples','same_above_decision_violation_count','violation_samples','owner','policy')}
    out['fresh_path_evidence_v1135']={k:fresh_evidence.get(k) for k in ('schema','epoch_id','occurrence_fresh_pass_seen','paper_ttl_pass_seen','paper_execution_pass_seen','paper_final_safety_pass_seen','selected_or_opened_seen','complete','first_seen_at','last_seen_at','samples','policy')}
    _V1135_PREV_WRITE_STATUS(out)

def main__v1135() -> None:
    # v1174 raw Paper: legacy fresh-epoch reset startup is retired.
    return _V1135_PREV_MAIN()

VERSION = 'paper_bot_v1.041'

BUILD_LABEL = 'v1174_raw_paper_intake_remove_late_safety_blocks_2026-07-01'

def _v1170_recovery_occurrence(ev: Dict[str,Any]) -> Dict[str,Any]:
    row=ev if isinstance(ev,dict) else {}
    gate=read_strategy_entry_gate(row)
    occ=gate.get('trigger_occurrence') if isinstance(gate.get('trigger_occurrence'),dict) else row.get('trigger_occurrence') if isinstance(row.get('trigger_occurrence'),dict) else {}
    return occ if isinstance(occ,dict) else {}

def paper_final_safety__v1170(ev: Dict[str,Any], ctrl: Dict[str,Any]) -> Tuple[bool,List[str],Dict[str,Any]]:
    occ=_v1170_recovery_occurrence(ev)
    recovery=bool(occ.get('recovery_mode_v1170') is True or str(occ.get('schema') or '')=='trigger_occurrence_v1037')
    ctrl_effective=dict(ctrl or {})
    if recovery:
        ctrl_effective['paper_final_reaction_proof_enabled']=False
    ok,reasons,diag=_V1170_PREV_FINAL_SAFETY(ev,ctrl_effective)
    diag=dict(diag or {})
    if recovery:
        diag['quality_conditions_blocking_v925']=False
        diag['quality_owner_v1170']='Strategy v1051 recovery core; Paper execution-only recheck'
        diag['recovery_mode_v1170']=True
        diag['reaction_duplicate_block_removed_v1170']=True
    return ok,reasons,diag

def write_status__v1170(status: Dict[str,Any]) -> None:
    out=dict(status or {})
    out['recovery_contract_v1170']={'schema':'paper_raw_intake_contract_v1174','state':'RAW_PAPER_NO_LATE_SAFETY_BLOCKS','strategy_base':'v1051 strategy_worker_v0.989','paper_base':'current exact-ledger/exit/runtime','quality_owner':'Strategy exact S1 decision','paper_audit_only':'TTL/open-count/micro/ws/RR-room/spread/slippage/reaction/reentry','paper_integrity_owner':'exact decision + duplicate + append/commit','terminal_feedback_to_strategy':False,'open_limit_changed':True,'exit_contract_changed':False,'auto_buy':False}
    _V1170_PREV_WRITE_STATUS(out)

def _v1173_entry_contract(ev: Dict[str,Any]) -> Tuple[Dict[str,Any],Dict[str,Any],Dict[str,Any]]:
    row=ev if isinstance(ev,dict) else {}
    gate=read_strategy_entry_gate(row)
    occ=gate.get('trigger_occurrence') if isinstance(gate.get('trigger_occurrence'),dict) else row.get('trigger_occurrence') if isinstance(row.get('trigger_occurrence'),dict) else {}
    contract=gate.get('trigger_occurrence_contract') if isinstance(gate.get('trigger_occurrence_contract'),dict) else row.get('trigger_occurrence_contract') if isinstance(row.get('trigger_occurrence_contract'),dict) else {}
    return row, (gate if isinstance(gate,dict) else {}), (occ if isinstance(occ,dict) else {})

def trigger_occurrence_freshness__v1174(ev: Dict[str,Any], ctrl: Dict[str,Any], nowv: Optional[float]=None) -> Dict[str,Any]:
    row,gate,occ=_v1173_entry_contract(ev)
    now_value=float(nowv if nowv is not None else now_ts())
    decision=str(occ.get('decision_key') or gate.get('decision_key') or '').strip()
    actual_event_ts=fnum(occ.get('event_ts'),default=0.0)
    state=str(occ.get('qualification_state') or '').strip()
    kind=str(occ.get('kind') or '').strip()
    contract=gate.get('trigger_occurrence_contract') if isinstance(gate.get('trigger_occurrence_contract'),dict) else row.get('trigger_occurrence_contract') if isinstance(row.get('trigger_occurrence_contract'),dict) else {}
    s1_ready_ts=fnum(occ.get('s1_ready_ts_v1173'),contract.get('s1_ready_ts_v1173'),row.get('s1_ready_at_v1173'),default=0.0)
    s1_decision=str(occ.get('s1_ready_decision_key_v1173') or contract.get('s1_ready_decision_key_v1173') or row.get('s1_ready_decision_key_v1173') or '').strip()
    trigger_age=max(0.0,now_value-actual_event_ts) if actual_event_ts>0 else None
    transport_age=max(0.0,now_value-s1_ready_ts) if s1_ready_ts>0 else None
    identity_ready=bool(decision and actual_event_ts>0)
    owner_ready=bool(s1_ready_ts>0 and s1_decision==decision)
    would_be_fresh=bool(owner_ready and transport_age is not None and transport_age<=120.0)
    return {
        'schema':'paper_trigger_occurrence_freshness_v1174_audit_only',
        'fresh':True,'code':'TTL_DISABLED_RAW_MODE','reason':'TTL·사건나이 차단 비활성; 시간은 감사값으로만 기록',
        'event_ts':actual_event_ts or None,'actual_trigger_event_ts':actual_event_ts or None,
        'actual_trigger_age_sec':round(trigger_age,3) if trigger_age is not None else None,
        's1_ready_ts_v1173':s1_ready_ts or None,'age_sec':round(transport_age,3) if transport_age is not None else None,
        'transport_age_sec':round(transport_age,3) if transport_age is not None else None,
        'ttl_sec':0.0,'legacy_ttl_sec_v1174':120.0,'ttl_enabled':False,
        'decision_key':decision or None,'s1_ready_decision_key_v1173':s1_decision or None,
        'qualification_state':state or None,'kind':kind or None,
        'raw_identity_ready_v1174':identity_ready,'raw_s1_ready_owner_ok_v1174':owner_ready,
        'would_be_fresh_v1174':would_be_fresh,
        'would_be_code_v1174':('FRESH_S1_TRANSPORT' if would_be_fresh else 'WAIT_OR_STALE_S1_TRANSPORT'),
        'event_time_owner':'actual_trigger_crossing','transport_ttl_owner':'disabled_raw_mode_v1174',
        'source':'trigger_occurrence.event_ts + s1_ready_ts_v1173',
    }

def write_status__v1174(status: Dict[str,Any]) -> None:
    out=dict(status or {})
    out['paper_raw_intake_contract_v1174']={
        'schema':'paper_raw_intake_contract_v1174',
        'state':'RAW_PAPER_NO_LATE_SAFETY_BLOCKS',
        'disabled_blockers':['candidate TTL','trigger/S1 transport TTL','completed-generation age','OPEN total limit','cycle new-OPEN limit','micro freshness','WS freshness','Paper RR/room/spread/slippage/reaction recheck','loss reentry gate','legacy book-reset entry freeze','post-reset epoch gate','operator bulk-close reset diversion','new OPEN pause'],
        'kept_integrity':['Strategy exact S1 decision','ticker/price/structure data validity','exact decision duplicate','position duplicate','same ticker duplicate','OPEN/CLOSED append and commit'],
        'candidate_quality_changed':False,'exit_contract_changed':False,'auto_buy':False,
    }
    out.pop('transport_ttl_contract_v1173',None)
    _V1173_PREV_WRITE_STATUS(out)

VERSION = 'paper_bot_v1.044'

BUILD_LABEL = 'v1180_strategy_core_and_paper_batch_commit_2026-07-01'

def _v1175_pick_status() -> Tuple[Dict[str,Any],Dict[str,Any],Dict[str,Any]]:
    status=load_json(FILES.get('status',BASE_DIR/'paper_bot_status.json'),{}) or {}
    handoff=load_json(FILES.get('handoff_status',BASE_DIR/'paper_bot_candidate_handoff_status.json'),{}) or {}
    status=status if isinstance(status,dict) else {}
    handoff=handoff if isinstance(handoff,dict) else {}
    pick=_v561_pick_spine(status,handoff) if '_v561_pick_spine' in globals() else (status.get('pick_stats') if isinstance(status.get('pick_stats'),dict) else {})
    return status,handoff,(pick if isinstance(pick,dict) else {})

def _v1175_integrity_block_counts(pick: Dict[str,Any]) -> Dict[str,int]:
    keys={
        '관찰전용':'s3_observation_only_skip_v988',
        'S1아님':'not_s1_skip',
        '종목누락':'ticker_missing_skip',
        '가격누락':'price_missing_skip',
        'decision누락':'decision_key_missing_v926',
        'decision중복':'decision_already_consumed_v926',
        'position중복':'dup_skip',
        '동일종목중복':'same_ticker_skip',
        '배관미완료':'candidate_pipeline_blocked_v1150',
    }
    return {label:int(fnum(pick.get(key),default=0)) for label,key in keys.items()}

def _v1175_audit_counts(pick: Dict[str,Any]) -> Dict[str,int]:
    return {
        '후보TTL':int(fnum(pick.get('candidate_ttl_audit_issue_v1174'),default=0)),
        'trigger·S1시간':int(fnum(pick.get('trigger_occurrence_audit_issue_v1174'),default=0)),
        'micro':int(fnum(pick.get('micro_fresh_audit_issue_v1174'),default=0)),
        'WS':int(fnum(pick.get('ws_fresh_audit_issue_v1174'),default=0)),
        '최종안전':int(fnum(pick.get('paper_final_safety_audit_issue_v1174'),default=0)),
        '재진입자료':int(fnum(pick.get('loss_reentry_source_audit_issue_v1174'),default=0)),
        '재진입조건':int(fnum(pick.get('loss_reentry_audit_issue_v1174'),default=0)),
        '구OPEN제한':int(fnum(pick.get('audit_would_block_open_limit_v1175'),default=0)),
        '구cycle제한':int(fnum(pick.get('audit_would_block_cycle_limit_v1175'),default=0)),
        '구진입정지':int(fnum(pick.get('audit_would_block_new_open_pause_v1175'),default=0)),
    }

def _v1175_nonzero_text(rows: Dict[str,int]) -> str:
    shown=[f'{k} {v}' for k,v in rows.items() if int(v)>0]
    return ' / '.join(shown) if shown else '이상 0'

def pstatus_text__v1175() -> str:  # type: ignore[override]
    status,_handoff,pick=_v1175_pick_status()
    op=load_open()
    integrity=_v1175_integrity_block_counts(pick)
    audit=_v1175_audit_counts(pick)
    configured_open=int(fnum(pick.get('audit_legacy_max_open_configured_v1175'),default=0))
    configured_cycle=int(fnum(pick.get('audit_legacy_max_new_per_cycle_configured_v1175'),default=0))
    actual_late_blocks=int(fnum(pick.get('late_safety_block_count_v1174'),default=0))
    return '\n'.join([
        f'🧪 paper 상태 /pstatus · {VERSION}',
        f'- build: {BUILD_LABEL}',
        '- 현재 모드: 날것 Paper · 후대 안전차단 OFF · 자동매수 OFF',
        f"- runtime: running={status.get('running')} / pid={status.get('pid') or '-'} / 오류={status.get('last_error') or status.get('error') or '-'}",
        f'- OPEN {len(op)} / 이번 cycle OPEN {status.get("opened_this_cycle",0)} / CLOSED {status.get("closed_this_cycle",0)} / elapsed {status.get("elapsed_sec","-")}s',
        f"- 후보 흐름: S1 {pick.get('s1_seen',0)} / 선택 {pick.get('selected_s1',0)} / 실제 후대차단 {actual_late_blocks}",
        f"- 실제 유지 차단: {_v1175_nonzero_text(integrity)}",
        f"- 진단 전용 이상: {_v1175_nonzero_text(audit)}",
        f'- 제거 전 설정 참고: OPEN {configured_open if configured_open>0 else "무제한"} / cycle {configured_cycle if configured_cycle>0 else "무제한"} · 현재 적용 0/0(무제한)',
        '- 해석: 진단 전용 이상은 후보를 막지 않으며, 원천 문제가 복구됐는지 확인하기 위한 숫자',
        '- 유지: exact S1·decision, 관찰후보 제외, decision/position/동일종목 중복, OPEN/CLOSED commit, 기존 청산',
    ])

def candidate_summary_text__v1175() -> str:  # type: ignore[override]
    ctrl=load_control()
    hold_obj=load_json(FILES.get('s1_hold',BASE_DIR/'paper_s1_hold_cache.json'),{}) or {}
    hold_rows=hold_obj.get('rows') if isinstance(hold_obj,dict) and isinstance(hold_obj.get('rows'),list) else []
    hold_rows=[dict(r) for r in hold_rows if isinstance(r,dict)]
    latest_rows,scope=_read_current_candidate_snapshot()
    stage_counts=Counter(str(r.get('candidate_grade') or r.get('s_stage') or r.get('stage') or r.get('grade') or '-').upper() for r in latest_rows if isinstance(r,dict))
    _status,_handoff,pick=_v1175_pick_status()
    audit=_v1175_audit_counts(pick)
    integrity=_v1175_integrity_block_counts(pick)
    row_ttl_issue=0; occurrence_issue=0
    for row in hold_rows:
        if candidate_freshness_evidence_v1039(row,ctrl).get('would_be_fresh_v1174') is False:
            row_ttl_issue+=1
        occ=trigger_occurrence_freshness(row,ctrl)
        if occ.get('would_be_fresh_v1174') is False or occ.get('raw_identity_ready_v1174') is False or occ.get('raw_s1_ready_owner_ok_v1174') is False:
            occurrence_issue+=1
    lines=[
        '🧭 후보요약 /candidate_summary · 날것 Paper',
        f"- 실제 S1 hold {len(hold_rows)} / 이번 cycle S1 {pick.get('s1_seen',0)} / 선택 {pick.get('selected_s1',0)} / 후대차단 {pick.get('late_safety_block_count_v1174',0)}",
        f'- 현재 hold 진단: 후보TTL 이상 {row_ttl_issue} / trigger·S1시간 이상 {occurrence_issue} · 차단 아님',
        f"- cycle 진단 전용: {_v1175_nonzero_text(audit)}",
        f"- 실제 유지 차단: {_v1175_nonzero_text(integrity)}",
        f"- 후보판 snapshot {len(latest_rows)} / scope {scope.get('state')} / S1 {stage_counts.get('S1',0)} / S2 {stage_counts.get('S2',0)} / S3 {stage_counts.get('S3',0)}",
    ]
    show=sorted(hold_rows,key=lambda r:(int(fnum(r.get('swing_quality_rank'),default=10**9)),normalize_ticker(r.get('ticker'))))[:10]
    if show: lines.append('[S1 진단 표본]')
    for row in show:
        ticker=normalize_ticker(row.get('ticker') or row.get('market') or row.get('symbol')) or '-'
        occ=trigger_occurrence_freshness(row,ctrl)
        transport=occ.get('transport_age_sec'); trigger_age=occ.get('actual_trigger_age_sec')
        flags=[]
        if candidate_freshness_evidence_v1039(row,ctrl).get('would_be_fresh_v1174') is False: flags.append('후보TTL')
        if occ.get('would_be_fresh_v1174') is False: flags.append('S1시간')
        if occ.get('raw_identity_ready_v1174') is False: flags.append('trigger신원')
        if occ.get('raw_s1_ready_owner_ok_v1174') is False: flags.append('S1-owner')
        lines.append(f"- {ticker} · trigger age {float(trigger_age):.1f}s" if isinstance(trigger_age,(int,float)) else f'- {ticker} · trigger age -' )
        lines[-1]+=f" / S1→Paper {float(transport):.1f}s" if isinstance(transport,(int,float)) else ' / S1→Paper -'
        lines[-1]+=f" / 진단 {','.join(flags) if flags else '정상'} / 실제차단 없음"
    lines += ['', '[뜻]', '- 진단값은 삭제하지 않고 계속 계산함', '- 숫자가 0으로 내려가면 해당 원천 문제가 복구된 것', '- 실제 진입을 막는 것은 exact 신원·관찰후보·중복·원장 무결성뿐']
    return '\n'.join(lines)

def write_status__v1175(status: Dict[str,Any]) -> None:
    out=dict(status or {})
    pick=out.get('pick_stats') if isinstance(out.get('pick_stats'),dict) else {}
    out['paper_audit_only_summary_v1175']={
        'schema':'paper_audit_only_summary_v1175','state':'RAW_MODE_AUDIT_VISIBLE',
        'actual_late_safety_block_count':int(fnum(pick.get('late_safety_block_count_v1174'),default=0)),
        'audit_only_counts':_v1175_audit_counts(pick),
        'integrity_block_counts':_v1175_integrity_block_counts(pick),
        'configured_before_override':{
            'max_open_strict':int(fnum(pick.get('audit_legacy_max_open_configured_v1175'),default=0)),
            'max_new_per_cycle':int(fnum(pick.get('audit_legacy_max_new_per_cycle_configured_v1175'),default=0)),
        },
        'applied':{'max_open_strict':0,'max_new_per_cycle':0,'ttl_enabled':False,'late_safety_blocking':False},
        'policy':'retired blockers remain measured; diagnostics never promote to entry block; integrity blockers unchanged',
        'strategy_formula_changed':False,'exit_contract_changed':False,'auto_buy':False,
    }
    _V1175_PREV_WRITE_STATUS(out)

VERSION = 'paper_bot_v1.045'

BUILD_LABEL = 'v1181_paper_fast_core_async_postprocess_2026-07-02'

V1181_POSTPROCESS_QUEUE = BASE_DIR / 'runtime' / 'paper_postprocess_queue_v1181'

V1181_POSTPROCESS_STATUS = BASE_DIR / 'paper_postprocess_status_v1181.json'

_V1181_POSTPROCESS_THREAD: Optional[threading.Thread] = None

_V1181_POSTPROCESS_STOP = threading.Event()

_V1181_STATUS_LOCK = threading.RLock()

def write_status__v1181(status: Dict[str, Any]) -> None:
    """Serialize status writers and stamp the v1181 split-owner contract."""
    out = dict(status or {})
    out['version'] = VERSION
    out['paper_version'] = VERSION
    out['build'] = BUILD_LABEL
    out['paper_execution_core_owner_v1181'] = 'run_cycle__v1181_fast_core'
    out['paper_postprocess_owner_v1181'] = '_v1181_postprocess_loop'
    out['paper_exact_exit_monitor_owner_v1181'] = 'existing run_exact_exit_monitor unchanged'
    out['paper_core_postprocess_split_v1181'] = True
    out['strategy_formula_changed_v1181'] = False
    out['exit_contract_changed_v1181'] = False
    out['auto_buy'] = False
    with _V1181_STATUS_LOCK:
        _V1181_PREV_WRITE_STATUS(out)

def _v1181_queue_postprocess(payload: Dict[str, Any]) -> Path:
    V1181_POSTPROCESS_QUEUE.mkdir(parents=True, exist_ok=True)
    created = now_ts()
    request_id = str(payload.get('request_id') or f"paper-{int(created * 1000)}-{os.getpid()}")
    body = dict(payload or {})
    body.update({
        'schema': 'paper_postprocess_request_v1181',
        'request_id': request_id,
        'created_ts': created,
        'created_text': iso_ts(created),
        'version': VERSION,
        'build': BUILD_LABEL,
        'auto_buy': False,
        'live_ledger_write': False,
    })
    path = V1181_POSTPROCESS_QUEUE / f"{request_id}.json"
    save_json(path, body)
    return path

def run_cycle__v1181_fast_core() -> Dict[str, Any]:
    """Paper execution-only cycle.

    Exact decision reconciliation, candidate selection, duplicate protection,
    OPEN row construction, and the v1180 atomic OPEN+decision batch commit stay
    synchronous.  All noncritical reporting is queued after status commit.
    """
    _set_runtime_phase_v994('v1181_core_start')
    started = now_ts()
    reconcile_decision_state_at_startup(force=False)
    ctrl = load_control()
    open_pos = load_open()
    existing_open_compacted_v930 = _v930_compact_existing_open_rows(open_pos)
    quarantined_items = _v739_quarantine_open_positions(open_pos)
    if quarantined_items or existing_open_compacted_v930:
        if not persist_open_positions(open_pos):
            raise RuntimeError('v1181 OPEN compact/quarantine persistence verification failed')

    opened_items: List[Dict[str, Any]] = []
    pick_stats: Dict[str, Any] = {}
    latest_rows: List[Dict[str, Any]] = []
    picked: List[Tuple[str, Dict[str, Any]]] = []

    if ctrl.get('running', True) and not _STOP:
        _set_runtime_phase_v994('v1181_candidate_select')
        try:
            picked, pick_stats, latest_rows = select_candidates(ctrl, open_pos)
        except Exception as exc:
            log_error('v1181_select_candidates', exc)
            picked, pick_stats, latest_rows = [], {
                'select_error': f'{type(exc).__name__}: {exc}'
            }, []

        prepared: List[Tuple[str, Dict[str, Any], Dict[str, Any]]] = []
        for pid, ev in picked:
            if _STOP:
                pick_stats['stop_checkpoint_v994'] = 'before_open_item_v1181'
                break
            if pid in open_pos:
                continue
            try:
                pos = open_position(pid, ev)
                if not _v926_decision_key_from_row(pos):
                    raise ValueError('paper_decision_key_v926 missing at OPEN writer')
                prepared.append((pid, pos, ev))
            except Exception as exc:
                pick_stats['open_writer_failed_v981'] = int(pick_stats.get('open_writer_failed_v981', 0)) + 1
                pick_stats['last_open_writer_error_v981'] = f'{type(exc).__name__}: {exc}'
                pick_stats['last_open_writer_ticker_v981'] = normalize_ticker(
                    ev.get('ticker') or ev.get('market') or ev.get('symbol')
                ) if isinstance(ev, dict) else ''
                log_error('v1181_open_position_prepare', exc)

        _set_runtime_phase_v994('v1181_open_batch_commit')
        try:
            opened_items, batch_traces = _v1180_commit_open_batch(open_pos, prepared)
            pick_stats['open_batch_prepared_v1180'] = len(prepared)
            pick_stats['open_batch_committed_v1180'] = len(opened_items)
            pick_stats['open_snapshot_write_count_v1180'] = 1 if opened_items else 0
            pick_stats['decision_state_write_count_v1180'] = 1 if opened_items else 0
            pick_stats['open_batch_commit_owner_v1181'] = '_v1180_commit_open_batch'
            for pid, ev in batch_traces:
                if _v734_is_hold(ev):
                    pos = open_pos.get(pid) if isinstance(open_pos.get(pid), dict) else {}
                    _v734_trace_hold(
                        ev,
                        'opened_exact_v1181_batch',
                        'paper OPEN 묶음 등록',
                        {
                            'pos_id': pid,
                            'ticker': pos.get('ticker'),
                            'entry_price': pos.get('entry_price'),
                            'paper_decision_key_v926': _v926_decision_key_from_row(pos),
                        },
                    )
        except Exception as exc:
            pick_stats['open_batch_failed_v1180'] = 1
            pick_stats['last_open_writer_error_v981'] = f'{type(exc).__name__}: {exc}'
            log_error('v1181_open_batch_commit', exc)
    else:
        pick_stats['paused'] = 1
        try:
            latest_rows = _v582_active_rows(ctrl) if '_v582_active_rows' in globals() else []
        except Exception:
            latest_rows = []

    completed = now_ts()
    elapsed = max(0.0, completed - started)
    status: Dict[str, Any] = {
        'running': bool(ctrl.get('running', True)),
        'startup_status': False,
        'startup_phase': 'cycle_complete',
        'paper_cycle_completed_v1118': True,
        'paper_cycle_completed_at_v1118': completed,
        'paper_cycle_runtime_instance_id_v1118': _RUNTIME_INSTANCE_ID,
        'paper_funnel_ready_v1118': True,
        'paper_funnel_state_v1118': 'EVALUATED',
        'paper_funnel_pending_reason_v1118': None,
        'loop_seconds': ctrl.get('loop_seconds'),
        'cycle_started_at': started,
        'opened_this_cycle': len(opened_items),
        'closed_this_cycle': 0,
        'open_total': len(open_pos),
        'open_count': len(open_pos),
        'open_strict': len(open_pos),
        'closed_total': line_count_cached(FILES['closed'], ttl=30.0),
        'quarantined_this_cycle_v742': len(quarantined_items),
        'pick_stats': pick_stats,
        's1_hold_source': 'paper_s1_hold_cache.json',
        'elapsed_sec': round(elapsed, 6),
        'engine': 'paper_v1181_execution_core',
        'legacy_loop': False,
        'legacy_run_cycle_chain_bypassed': True,
        'paper_fast_core_v1181': True,
        'paper_postprocess_queued_v1181': True,
        'paper_exit_priority_owner_v682': False,
        'paper_exact_exit_monitor_owner': True,
        'candidate_rows_seen_v1181': len(latest_rows or []),
        'selected_rows_v1181': len(picked or []),
        'existing_open_compacted_v930': existing_open_compacted_v930,
        'writer': 'v1180_atomic_open_decision_batch_commit',
        'version': VERSION,
        'paper_version': VERSION,
        'build': BUILD_LABEL,
        'auto_buy': False,
    }
    _set_runtime_phase_v994('v1181_status_write')
    write_status(status)

    # Persist a bounded, non-live-ledger request after the execution commit.
    # OPEN rows are copied only for notification; the canonical OPEN file remains
    # the sole execution source of truth.
    request_path = _v1181_queue_postprocess({
        'request_id': f"paper-{int(completed * 1000)}-{_RUNTIME_INSTANCE_ID}",
        'cycle_started_at': started,
        'cycle_completed_at': completed,
        'opened_items': [dict(x) for x in opened_items[:100] if isinstance(x, dict)],
        'opened_count': len(opened_items),
        'open_count': len(open_pos),
        'candidate_rows_seen': len(latest_rows or []),
        'selected_rows': len(picked or []),
        'pick_stats': dict(pick_stats),
        'core_elapsed_sec': round(elapsed, 6),
    })
    status['paper_postprocess_request_v1181'] = request_path.name
    _set_runtime_phase_v994('idle')
    try:
        log(
            f"{VERSION} fast-core opened={len(opened_items)} open={len(open_pos)} "
            f"selected={len(picked or [])} elapsed={elapsed:.3f}s"
        )
    except Exception:
        pass
    return status

def _v1181_write_postprocess_status(payload: Dict[str, Any]) -> None:
    body = {
        'schema': 'paper_postprocess_status_v1181',
        'version': VERSION,
        'build': BUILD_LABEL,
        'updated_ts': now_ts(),
        'updated_text': iso_ts(),
        'owner': '_v1181_postprocess_loop',
        'live_ledger_write': False,
        'auto_buy': False,
    }
    body.update(dict(payload or {}))
    save_json(V1181_POSTPROCESS_STATUS, body)

def _v1181_process_postrequest(path: Path) -> Dict[str, Any]:
    req = load_json(path, {}) or {}
    if not isinstance(req, dict):
        raise ValueError(f'invalid postprocess request: {path.name}')
    started = now_ts()
    opened = [dict(x) for x in (req.get('opened_items') or []) if isinstance(x, dict)]
    pick_stats = req.get('pick_stats') if isinstance(req.get('pick_stats'), dict) else {}
    ctrl = load_control()
    status = load_json(FILES.get('status', BASE_DIR / 'paper_bot_status.json'), {}) or {}
    status = status if isinstance(status, dict) else {}
    open_pos = load_open()

    # Alerts are downstream of committed OPEN and therefore cannot delay or
    # invalidate the exact batch commit.
    alert_ok = 0
    for pos in opened:
        try:
            notify_opened(pos)
            alert_ok += 1
        except Exception as exc:
            log_error('v1181_postprocess_notify_opened', exc)
    try:
        notify_s1_decision_summary(
            pick_stats,
            opened_count=len(opened),
            closed_count=0,
            ctrl=ctrl,
        )
    except Exception as exc:
        log_error('v1181_postprocess_s1_summary', exc)
    try:
        notify_market_hot_summary(ctrl)
    except Exception as exc:
        log_error('v1181_postprocess_market_summary', exc)

    perf_snapshot: Dict[str, Any] = {}
    try:
        if ctrl.get('write_score_cache', True):
            perf_snapshot = write_score_cache(status, open_positions=open_pos) or {}
    except Exception as exc:
        log_error('v1181_postprocess_performance', exc)
    try:
        _v628_send_due_hourly_raw_pack()
        if '_v631_maybe_send_paper_hourly_summary' in globals():
            _v631_maybe_send_paper_hourly_summary(status)  # type: ignore[name-defined]
    except Exception as exc:
        log_error('v1181_postprocess_hourly', exc)
    try:
        cleanup = _v678_runtime_cleanup(ctrl, status)
    except Exception as exc:
        cleanup = {'ok': False, 'error': f'{type(exc).__name__}: {exc}'}
        log_error('v1181_postprocess_cleanup', exc)

    elapsed = max(0.0, now_ts() - started)
    result = {
        'state': 'NORMAL',
        'request_id': req.get('request_id'),
        'request_file': path.name,
        'opened_alert_requested': len(opened),
        'opened_alert_success': alert_ok,
        'performance_snapshot_id': perf_snapshot.get('snapshot_id') if isinstance(perf_snapshot, dict) else None,
        'cleanup_ok': bool(cleanup.get('ok', True)) if isinstance(cleanup, dict) else False,
        'elapsed_sec': round(elapsed, 6),
        'last_success_ts': now_ts(),
    }
    _v1181_write_postprocess_status(result)
    merged = load_json(FILES.get('status', BASE_DIR / 'paper_bot_status.json'), {}) or {}
    merged = merged if isinstance(merged, dict) else {}
    merged['paper_postprocess_v1181'] = result
    write_status(merged)
    path.unlink(missing_ok=True)
    return result

def _v1181_postprocess_loop() -> None:
    V1181_POSTPROCESS_QUEUE.mkdir(parents=True, exist_ok=True)
    _v1181_write_postprocess_status({'state': 'STARTING'})
    last_periodic = 0.0
    last_classify = 0.0
    while not _V1181_POSTPROCESS_STOP.is_set() and not _STOP:
        if int(globals().get('_EXACT_COMMIT_DEPTH') or 0) > 0:
            _V1181_POSTPROCESS_STOP.wait(0.2)
            continue
        files = sorted(V1181_POSTPROCESS_QUEUE.glob('*.json'), key=lambda x: x.name)
        if files:
            for path in files[:20]:
                if _V1181_POSTPROCESS_STOP.is_set() or _STOP:
                    break
                try:
                    _v1181_process_postrequest(path)
                except Exception as exc:
                    log_error('v1181_postprocess_request', exc)
                    _v1181_write_postprocess_status({
                        'state': 'ERROR',
                        'request_file': path.name,
                        'last_error': f'{type(exc).__name__}: {exc}',
                    })
                    break  # fail visible; keep request for retry
        nowv = now_ts()
        if nowv - last_periodic >= 30.0 and int(globals().get('_EXACT_COMMIT_DEPTH') or 0) == 0:
            try:
                status = load_json(FILES.get('status', BASE_DIR / 'paper_bot_status.json'), {}) or {}
                status = status if isinstance(status, dict) else {}
                ctrl = load_control()
                open_pos = load_open()
                if ctrl.get('write_score_cache', True):
                    write_score_cache(status, open_positions=open_pos)
                if nowv - last_classify >= 300.0 and '_run_classify_helper_v1013' in globals():
                    _run_classify_helper_v1013('v1181_periodic', force=False)
                    last_classify = nowv
                _v1181_write_postprocess_status({
                    'state': 'NORMAL',
                    'periodic_heartbeat': True,
                    'queue_depth': len(list(V1181_POSTPROCESS_QUEUE.glob('*.json'))),
                    'last_success_ts': now_ts(),
                })
            except Exception as exc:
                log_error('v1181_postprocess_periodic', exc)
                _v1181_write_postprocess_status({
                    'state': 'ERROR',
                    'periodic_heartbeat': True,
                    'last_error': f'{type(exc).__name__}: {exc}',
                })
            last_periodic = nowv
        _V1181_POSTPROCESS_STOP.wait(0.5)
    _v1181_write_postprocess_status({'state': 'STOPPED'})

def _v1181_start_postprocess_thread() -> None:
    global _V1181_POSTPROCESS_THREAD
    if _V1181_POSTPROCESS_THREAD is not None and _V1181_POSTPROCESS_THREAD.is_alive():
        return
    _V1181_POSTPROCESS_STOP.clear()
    _V1181_POSTPROCESS_THREAD = threading.Thread(
        target=_v1181_postprocess_loop,
        name='paper-postprocess-v1181',
        daemon=True,
    )
    _V1181_POSTPROCESS_THREAD.start()

def main__v1181() -> None:
    _v1181_start_postprocess_thread()
    try:
        return _V1181_PREV_MAIN()
    finally:
        _V1181_POSTPROCESS_STOP.set()
        thread = _V1181_POSTPROCESS_THREAD
        if thread is not None and thread.is_alive():
            thread.join(timeout=3.0)

# Flattened final runtime bindings
_V1017_PREV_SAVE_DECISION_STATE = _v926_save_decision_state__L21755
_V1017_PREV_WRITE_STATUS = write_status__L4253
_V1044_PREV_SELECT_CANDIDATES = select_candidates__L22385
_V1045_PREV_OPEN_POSITION = open_position__L14174
_V1045_PREV_PERF_BUILD_SNAPSHOT = _v987_perf_build_snapshot__L559
_V1045_PREV_PERF_COMPACT_ROW = _v987_perf_compact_row
_V1045_PREV_RUN_EXACT_EXIT_MONITOR = run_exact_exit_monitor__L4905
_V1045_PREV_WRITE_STATUS = write_status__L22853
_V1053_PREV_LOAD_OPEN = load_open__L1129
_V1053_PREV_RUN_EXACT_EXIT_MONITOR = run_exact_exit_monitor__L23671
_V1053_PREV_VERIFIED_WRITE = _paper_write_json_verified__L15292
_V1053_PREV_WRITE_STATUS = write_status__L23723
_V1054_PREV_LOAD_OPEN = load_open__L23763
_V1054_PREV_WRITE_STATUS = write_status__L23802
_V1076_PREV_RUN_EXACT_EXIT_MONITOR = run_exact_exit_monitor__L23773
_V1076_PREV_SET_RUNTIME_PHASE = _set_runtime_phase_v994
_V1076_PREV_WRITE_STATUS = write_status__L24232
_V1082_PREV_WRITE_STATUS = write_status__v1076
_V1113_PREV_EXIT_MONITOR = run_exact_exit_monitor__v1076
_V1113_PREV_WRITE_STATUS = write_status__v1082
_V1117_PREV_WRITE_SCORE_CACHE = write_score_cache
_V1135_PREV_MAIN = main
_V1135_PREV_WRITE_STATUS = write_status__v1121_no_heavy_probe
_V1170_PREV_FINAL_SAFETY = paper_final_safety
_V1170_PREV_WRITE_STATUS = write_status__v1135
_V1173_PREV_WRITE_STATUS = write_status__v1170
_V1175_PREV_WRITE_STATUS = write_status__v1174
_V1181_PREV_MAIN = main__v1135
_V1181_PREV_WRITE_STATUS = write_status__v1175
_canonical_performance_source_signature = _canonical_performance_source_signature__L22780
_paper_write_json_verified = _paper_write_json_verified__L23768
_set_runtime_phase_v994 = _set_runtime_phase_v994__v1076
_v587_base_notify_market_hot_summary = notify_market_hot_summary__L3524
_v587_base_notify_s1_decision_summary = notify_s1_decision_summary__L3259
_v607_alert_to_closed_row = _v607_alert_to_closed_row__L13030
_v612_prev_candidate_summary_text = candidate_summary_text__L4564
_v612_prev_hot_summary_text = hot_summary_text
_v612_prev_pstatus_text = pstatus_text__L7472
_v628_send_due_hourly_raw_pack = _v678_send_due_hourly_raw_pack
_v631_maybe_send_paper_hourly_summary = _v632_maybe_send_paper_hourly_summary
_v632_send_document_dual = _v638_send_document_dual
_v635_prev_alert_to_closed_row = _v607_alert_to_closed_row__L8822
_v677_prev_latest_scan_filter = latest_scan_filter__L1801
_v678_runtime_cleanup = _v678_runtime_cleanup__L20516
_v747_build_classify_cache = _v747_build_classify_cache__L17631
_v747_entry_quality = _v747_entry_quality__L17375
_v752_apply_entry_snapshot_to_row = _v752_apply_entry_snapshot_to_row__L16365
_v752_line_snapshot = _v752_line_snapshot__L16344
_v755_prev_apply_entry_snapshot_to_row = _v752_apply_entry_snapshot_to_row__L16168
_v755_prev_build_classify_cache = _v747_build_classify_cache__L12363
_v755_prev_line_snapshot = _v752_line_snapshot__L16164
_v755_row_taxonomy = _v755_row_taxonomy__L16990
_v756_prev_append_jsonl = append_jsonl__L959
_v756_prev_v755_row_taxonomy = _v755_row_taxonomy__L16377
_v757_prev_append_jsonl = append_jsonl__L16581
_v758_existing_snapshot = _v758_existing_snapshot__L17339
_v758_prev_append_jsonl = append_jsonl__L16808
_v758_prev_v755_row_taxonomy = _v755_row_taxonomy__L16617
_v759_original_snapshot = _v759_original_snapshot__L17491
_v759_prev_build_classify_cache = _v747_build_classify_cache__L16428
_v759_prev_entry_quality = _v747_entry_quality__L16190
_v759_prev_v758_existing_snapshot = _v758_existing_snapshot__L16859
_v762_prev_build_classify_cache = _v747_build_classify_cache__L17414
_v762_prev_v759_original_snapshot = _v759_original_snapshot__L17178
_v764_prev_build_classify_cache = _v747_build_classify_cache__L17506
_v783_prev_runtime_cleanup = _v678_runtime_cleanup__L14872
_v797_trade_detail_record = _v797_trade_detail_record__L18865
_v798_prev_runtime_cleanup = _v678_runtime_cleanup__L18413
_v811_base_trade_detail_record = _v797_trade_detail_record__L11095
_v835_prev_runtime_cleanup = _v678_runtime_cleanup__L18524
_v836_prev_runtime_cleanup = _v678_runtime_cleanup__L19140
_v840_prev_runtime_cleanup = _v678_runtime_cleanup__L19525
_v840_tail = _v849_skip_paper_latest_tail
_v841_paper_latest_owner_cleanup = _v849_paper_latest_owner_cleanup
_v841_prev_runtime_cleanup = _v678_runtime_cleanup__L19640
_v842_prev_runtime_cleanup = _v678_runtime_cleanup__L19712
_v843_prev_runtime_cleanup = _v678_runtime_cleanup__L19842
_v846_prev_runtime_cleanup = _v678_runtime_cleanup__L19983
_v849_prev_runtime_cleanup = _v678_runtime_cleanup__L20077
_v849_prev_v840_tail = _v840_tail
_v853_prev_runtime_cleanup = _v678_runtime_cleanup__L20257
_v853_remove_legacy_tmp = _v853_remove_legacy_tmp__L20640
_v859_prev_v853_remove_legacy_tmp = _v853_remove_legacy_tmp__L20323
_v926_save_decision_state = _v926_save_decision_state__L22754
_v987_perf_build_snapshot = _v987_perf_build_snapshot__L23202
_v987_perf_compact_row = _v1045_perf_compact_row
append_jsonl = append_jsonl__L17087
candidate_summary_text = candidate_summary_text__v1175
latest_scan_filter = latest_scan_filter__L14633
load_open = load_open__L23894
main = main__v1181
notify_market_hot_summary = notify_market_hot_summary__L8111
notify_opened = notify_opened__L11378
notify_s1_decision_summary = notify_s1_decision_summary__L8093
open_position = open_position__L23309
paper_final_safety = paper_final_safety__v1170
paper_hourly_text = paper_hourly_text__L9095
popen_text = popen_text__L9300
pstatus_text = pstatus_text__v1175
run_cycle = run_cycle__v1181_fast_core
run_exact_exit_monitor = run_exact_exit_monitor__v1121_no_heavy_probe
select_candidates = select_candidates__L23042
trigger_occurrence_freshness = trigger_occurrence_freshness__v1174
write_score_cache = write_score_cache__v1117
write_status = write_status__v1181

if __name__ == "__main__":
    main()
