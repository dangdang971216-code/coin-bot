from pathlib import Path
import ast, json
ROOT=Path(__file__).resolve().parent
guard=(ROOT/'backga_guard_bot_v2_5_197.py').read_text(encoding='utf-8')
review=(ROOT/'review_worker_v1.014.py').read_text(encoding='utf-8')
assert 'review_dedup_retired_v1182' not in guard
assert 'legacy_dedup_index_retired' not in review
assert 'legacy_trace_rebuild_retired' not in review
tree=ast.parse(guard)
func=[n for n in tree.body if isinstance(n,ast.FunctionDef) and n.name=='_worker_singleton_evidence_v1111']
assert len(func)==1
segment=ast.get_source_segment(guard,func[0])
assert 'review_sqlite_single_writer' not in segment
assert 'requires_lock = name in {"strategy", "review"}' in segment
manifest=json.loads((ROOT/'DEPLOY_BUNDLE.json').read_text(encoding='utf-8'))
assert manifest['version']=='v1183'
assert list(manifest['workers'])==['strategy','review']
print('PASS v1183 direct replacement contract')
