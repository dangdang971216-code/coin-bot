v1183는 v1182에 조건을 덧붙인 버전이 아니다.
가드의 worker fresh-boot 검수 함수를 통째로 단일 canonical 계약으로 교체했고,
v1182 전용 review_dedup 조건과 Review legacy 상태필드를 삭제했다.
자동 묶음 적용 순서와 one-shot continuation 함수는 기존 정상 흐름 그대로다.
전략·진입·청산·원장 변경 없음. 자동매수 OFF. 서버 검증 전 CHECK.
