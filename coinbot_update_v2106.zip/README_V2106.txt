coinbot_update_v2106.zip

목적
- 양수 후 음수 거래를 MFE 경로 4종으로 분해
- actual v2086 봉인 probe에서 3중보류를 통과한 이유 확인
- 기존 1h/3h/6h 생존 Shadow와 연결
- 단일 대수익 제외 current epoch 성과 확인

새 명령
- /entry_failure_audit
- /entry_root_audit
- /dead_entry_audit

변경 없음
- 실제 진입/청산/target/invalid/후보등급
- 기존 OPEN 계약
- 기존 Shadow와 누적자료
- 자동매수 OFF
