Coinbot v2167 single runtime owner

- Strategy worker/core/model/candidate/S1/Review/Main use one runtime identity.
- Release PASS requires exact active Strategy alias, PID/lock, status, core, model and candidate contracts.
- Review no longer hard-codes a model generation.
- Main renders one whole-market comparison board.
- Candidate/OPEN/CLOSED/decision/exact/history preserved.
- Auto-buy OFF.
