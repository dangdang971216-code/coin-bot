# v1074 CORE V2 시스템 마감 묶음

## 범위

- CORE V2 v1071 전환 후 runtime·source hash·Risk–Paper·candidate writer·exact 0/0/0 재증명
- 성공 시 issue/change 원장에 v1074 DONE append 및 중복 실행 방지 marker 기록
- Guard를 CPU/RSS의 canonical owner로 고정
- Main `/batch`, `/batch_full`에 실행 상태와 중복 요청 상태 표시
- Paper `/pbatch`, `/ponce`에 접수·완료 및 중복 상태 표시

## 변경하지 않은 영역

- Strategy v0.992
- Risk v0.11
- Review v0.995
- trigger·invalid·target·RR·spread·slippage
- 진입·청산·수익보호 계약
- OPEN/CLOSED/decision/exact 원장 원문
- 자동매수 OFF

## 적용 후 검수

1. Guard에서 `/gupgrade_bundle` 단독 실행
2. 배포 PASS 확인
3. Guard에서 `/gcore_v2_closeout`, `/gworker_state`, `/gdeep_audit` 실행
4. Main에서 `/health`, `/change_verify`, `/issue_ledger`, `/errorlog` 실행
5. Paper에서 `/pstatus`, `/perror` 실행

`/gcore_v2_closeout`이 DONE이어야 CORE V2 시스템 마감을 닫는다.
