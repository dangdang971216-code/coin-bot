import importlib.util, os, tempfile, pathlib, json, ast, hashlib
ROOT=pathlib.Path(__file__).resolve().parent

def load(name,path, envdir):
    os.environ['TRADING_BOT_DIR']=str(envdir)
    spec=importlib.util.spec_from_file_location(name,path)
    mod=importlib.util.module_from_spec(spec); spec.loader.exec_module(mod); return mod

with tempfile.TemporaryDirectory() as td:
    td=pathlib.Path(td)
    s=load('strategy_v1133',ROOT/'strategy_worker_v1.011.py',td)
    rec={'frozen_ts':100.0}
    # Migration while above must never inherit/create a decision.
    ev,key=s._v1133_trigger_occurrence(rec,'market:AAA',110.0,100.0,1000.0,True)
    assert not key and ev['qualification_state']=='WAIT_RESET_BELOW' and ev['migration_reset_required'] is True
    # Later quality pass while still above cannot revive old event.
    ev,key=s._v1133_trigger_occurrence(rec,'market:AAA',109.0,100.0,1010.0,True)
    assert not key and ev['requires_new_rebreak'] is True
    # Reset below.
    ev,key=s._v1133_trigger_occurrence(rec,'market:AAA',99.0,100.0,1020.0,False)
    assert not key and ev['qualification_state']=='WAIT_REBREAK' and ev['reset_ts']==1020.0
    # Unqualified rebreak is consumed and cannot later become qualified above.
    ev,key=s._v1133_trigger_occurrence(rec,'market:AAA',101.0,100.0,1030.0,False)
    assert not key and ev['kind']=='UNQUALIFIED_REBREAK_WAIT_RESET'
    ev,key=s._v1133_trigger_occurrence(rec,'market:AAA',101.0,100.0,1040.0,True)
    assert not key and ev['qualification_state']=='WAIT_RESET_BELOW'
    # New reset + qualified rebreak creates exactly one decision.
    s._v1133_trigger_occurrence(rec,'market:AAA',99.0,100.0,1050.0,False)
    ev,key=s._v1133_trigger_occurrence(rec,'market:AAA',100.1,100.0,1060.0,True)
    assert key.endswith('|rebreak:1060000') and ev['contract_ready_at_cross'] is True and ev['event_ts']==1060.0
    ev2,key2=s._v1133_trigger_occurrence(rec,'market:AAA',100.2,100.0,1070.0,False)
    assert key2==key and ev2['event_ts']==1060.0

    p=load('paper_v1133',ROOT/'paper_bot_v1.021.py',td)
    row={'swing_entry_gate_v977':{'trigger_occurrence_v1037':ev,'decision_key':key},'swing_gate_decision_key_v977':key}
    fresh=p.trigger_occurrence_freshness_v1133(row,{'candidate_ttl_sec':120},nowv=1100.0)
    assert fresh['fresh'] is True and fresh['age_sec']==40.0
    stale=p.trigger_occurrence_freshness_v1133(row,{'candidate_ttl_sec':120},nowv=1181.0)
    assert stale['fresh'] is False and stale['code']=='STALE_TRIGGER_OCCURRENCE'
    waitrow={'swing_entry_gate_v977':{'trigger_occurrence_v1037':{'schema':'trigger_occurrence_v1133','qualification_state':'WAIT_RESET_BELOW','requires_new_rebreak':True}}}
    wait=p.trigger_occurrence_freshness_v1133(waitrow,{'candidate_ttl_sec':120},nowv=1181.0)
    assert wait['fresh'] is False and wait['code']=='WAIT_NEW_REBREAK'

    r=load('review_v1133',ROOT/'review_worker_v1.007.py',td)
    rr={'ticker':'AAA','s_stage':'S2','open_eligible':False,'trigger_occurrence_owner_state_v1128':'EXPECTED_TRIGGER_REBREAK_PRECONTRACT_NO_OWNER_V1133','trigger_occurrence_v1037':{'schema':'trigger_occurrence_v1133','qualification_state':'WAIT_RESET_BELOW','requires_new_rebreak':True}}
    evidence=r._quality_identity_evidence_v1126(rr)
    code,severity,diag=r._quality_missing_owner_class_v1128(rr,evidence)
    assert code=='EXPECTED_TRIGGER_REBREAK_PRECONTRACT_NO_OWNER_V1133' and severity=='EXPECTED'

# AST unchanged checks for quality/plan and exit formulas.
def fn_hash(path,names):
    tree=ast.parse(pathlib.Path(path).read_text(encoding='utf-8'))
    out={}
    for node in ast.walk(tree):
        if isinstance(node,(ast.FunctionDef,ast.AsyncFunctionDef)) and node.name in names:
            out[node.name]=hashlib.sha256(ast.dump(node,include_attributes=False).encode()).hexdigest()
    return out
expected_strategy={
    '_v925_current_actual_plan':'52861f3e88b72c5e25cbad38f2b2d156bcbf444cb4bdf13f1669fa5f15ef6995',
    '_v925_plan_price':'6cac518a311b6e52e644d858a2cee2f1a12f49278479659eb6e4cb1be6dd300b',
    '_swing_quality_gate':'1d97ab0738d5eb0bab21979aecce9161603c8dc166c4c03d4549758f21ee00f1',
}
expected_paper={
    'update_position':'014e907341f61dfcd8be147873850eff94c46c46585ae24486cdee2c5f404b40',
    '_exit_decision_spine':'3acf5282fd5a00651c0a3c39a0b36e3b33921096c5a2704e588b0c8ed1e145b1',
}
new_s=fn_hash(ROOT/'strategy_worker_v1.011.py',set(expected_strategy))
new_p=fn_hash(ROOT/'paper_bot_v1.021.py',set(expected_paper))
assert new_s==expected_strategy,(new_s,expected_strategy)
assert new_p==expected_paper,(new_p,expected_paper)
print(json.dumps({'strategy_contract':'PASS','paper_occurrence_ttl':'PASS','review_expected_owner':'PASS','unchanged_strategy_ast':new_s,'unchanged_paper_exit_ast':new_p},ensure_ascii=False,indent=2))
