# v1133 scope

## Owner surgery
- Strategy `apply_swing_entry_gate`: occurrence is sealed only at a fully ready below→above event.
- Paper `trigger_occurrence_freshness_v1133`: existing candidate TTL is applied to occurrence event time, not refreshed hold time.
- Paper final safety and OPEN writer recheck the same evidence.
- Review classifies wait-reset/rebreak rows as expected no-owner pre-contract rows.
- Main appends issue/change events and closes the issue only after server proof.

## Removed active path
- unqualified/migrated above-trigger decision inheritance
- base-plan decision fallback when no qualified occurrence exists
- refreshed S1 hold timestamp as sufficient trigger freshness

## Not changed
Invalid, target, trailing, exit monitor, quality formula/thresholds, rank formula, OPEN 30/cycle 3, ledgers, auto-buy OFF.
