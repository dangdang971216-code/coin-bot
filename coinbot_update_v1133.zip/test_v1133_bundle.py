from pathlib import Path
import json, py_compile, hashlib
root=Path(__file__).resolve().parent
manifest=json.loads((root/'DEPLOY_BUNDLE.json').read_text(encoding='utf-8'))
required=[manifest['main'],manifest['paper'],*manifest.get('workers',{}).values(),*manifest.get('support_files',[])]
missing=[name for name in required if not (root/name).exists()]
assert not missing,missing
py_files=sorted(p for p in root.rglob('*.py') if '__pycache__' not in p.parts)
for path in py_files:
    py_compile.compile(str(path),doraise=True)
assert manifest['version']=='v1133'
assert manifest['auto_buy'] is False
assert manifest['invalid_formula_change'] is False
assert manifest['target_formula_change'] is False
assert manifest['trailing_exit_change'] is False
assert manifest['open_limit_change'] is False
assert manifest['cycle_limit_change'] is False
print(json.dumps({'required_files':len(required),'python_files':len(py_files),'manifest':'PASS','py_compile':'PASS'},ensure_ascii=False))
