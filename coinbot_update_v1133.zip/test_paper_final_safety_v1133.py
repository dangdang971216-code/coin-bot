import importlib.util, pathlib, tempfile
ROOT=pathlib.Path(__file__).resolve().parent
spec=importlib.util.spec_from_file_location('paper_v1133',ROOT/'paper_bot_v1.021.py')
p=importlib.util.module_from_spec(spec); spec.loader.exec_module(p)
# isolate runtime facts
p.copy_entry_context=lambda ev:{}
p.build_entry_diagnostics=lambda ev,ctx:{}
p.build_open_alert_freshness_snapshot=lambda ev,diag:{}
p.micro_fresh=lambda ev,ctrl:True
p.ws_fresh=lambda ev:True
p._v925_confirmed_slippage=lambda ev:(0.05,'test')
p._paper_v144_reaction_proof_block=lambda diag,ctrl:''
p.evaluate_frozen_trigger=lambda ev,diag:{'trigger_reached':True,'trigger_price':100.0,'entry_price':101.0,'trigger_gap_pct':0.1}
p._v628_append_hourly_event=lambda *a,**k:None
base_occ={'schema':'trigger_occurrence_v1133','decision_key':'d1','event_ts':1000.0,'rebreak_ts':1000.0,'contract_ready_at_cross':True,'qualification_state':'QUALIFIED_EVENT','requires_new_rebreak':False}
def row(occ):
    gate={'schema':'swing_entry_gate_v977_single_owner','decision_key':'d1','hard_pass':True,'final_trade_state':'S1_PASS','risk_reward':3.0,'target_room_pct':5.0,'source_fresh':True,'invalid_price':99.0,'target_price':110.0,'trigger_occurrence_v1037':occ}
    return {'strategy_mode':'ALT_SWING_V977','swing_entry_gate_v977':gate,'swing_gate_decision_key_v977':'d1','spread_pct':0.1,'entry_slippage_ts':p.now_ts(),'entry_slippage_age_sec':0.1,'entry_slippage_confirmed':True}
ctrl={'candidate_ttl_sec':120,'preopen_micro_urgent_ttl_sec':35,'paper_final_reaction_proof_enabled':True,'paper_final_require_ws_fresh':False}
# force stale relative to real now
stale=dict(base_occ); stale['event_ts']=p.now_ts()-121; stale['rebreak_ts']=stale['event_ts']
ok,reasons,diag=p.paper_final_safety(row(stale),ctrl)
assert not ok and 'STALE_TRIGGER_OCCURRENCE' in diag['paper_final_safety_reason_codes_v1122'],(ok,reasons,diag)
fresh=dict(base_occ); fresh['event_ts']=p.now_ts()-10; fresh['rebreak_ts']=fresh['event_ts']
ok,reasons,diag=p.paper_final_safety(row(fresh),ctrl)
assert ok,(reasons,diag)
wait={'schema':'trigger_occurrence_v1133','qualification_state':'WAIT_RESET_BELOW','requires_new_rebreak':True}
ok,reasons,diag=p.paper_final_safety(row(wait),ctrl)
assert not ok and 'WAIT_NEW_REBREAK' in diag['paper_final_safety_reason_codes_v1122'],(reasons,diag)
print('PASS paper final-safety occurrence TTL/rebreak')
