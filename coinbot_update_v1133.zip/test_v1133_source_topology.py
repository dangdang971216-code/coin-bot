from pathlib import Path
import ast, re
root=Path(__file__).resolve().parent
s=(root/'strategy_worker_v1.011.py').read_text(encoding='utf-8')
p=(root/'paper_bot_v1.021.py').read_text(encoding='utf-8')
r=(root/'review_worker_v1.007.py').read_text(encoding='utf-8')
m=(root/'coinbot_main_v2_13_1101.py').read_text(encoding='utf-8')
assert 'def _v1037_trigger_occurrence(' not in s
assert 'occurrence_decision_key_v1037 or build_minimal_gate_decision_key' not in s
assert s.index('quality_gate = _swing_quality_gate') < s.index('_v1133_trigger_occurrence(' , s.index('def apply_swing_entry_gate'))
assert "hard.append('wait_new_reset_rebreak_v1133')" in s
assert p.count('trigger_occurrence_freshness_v1133(') >= 5
assert "add_reason_v1122(str(occurrence_freshness_v1133.get('code')" in p
assert "raise ValueError(str(occurrence_freshness_v1133.get('reason')" in p
assert 'EXPECTED_TRIGGER_REBREAK_PRECONTRACT_NO_OWNER_V1133' in r
assert '수익형 v2.13.1101' in m
for name in ('strategy_worker_v1.011.py','paper_bot_v1.021.py','review_worker_v1.007.py','coinbot_main_v2_13_1101.py'):
    ast.parse((root/name).read_text(encoding='utf-8'))
print('PASS v1133 source topology')
