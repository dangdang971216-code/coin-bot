import json
from pathlib import Path
base=Path(__file__).resolve().parents[1]
b=json.loads((base/'DEPLOY_BUNDLE.json').read_text())
assert b['release']=='v1276'
assert b['auto_buy'] is False
assert b['trigger_changed'] is False
assert b['invalid_selection_changed'] is False
assert b['target_selection_changed'] is False
assert b['rr_threshold_changed'] is False
assert b['v1270_profit_guard_changed'] is False
assert b['runtime_files']['paper']=='paper_bot_v1.083.py'
assert b['runtime_files']['strategy']=='strategy_worker_v1.067.py'
