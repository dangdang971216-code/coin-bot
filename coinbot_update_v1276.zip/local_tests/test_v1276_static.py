from pathlib import Path
base=Path(__file__).resolve().parents[1]
s=(base/'strategy_worker_v1.067.py').read_text()
p=(base/'paper_bot_v1.083.py').read_text()
g=(base/'backga_guard_bot_v2_5_254.py').read_text()
assert 'strategy_worker_v1.067' in s
assert 'strategy_actual_cost_alignment_v1276' in s
assert 'actual_cost_rr_below_paper_minimum_v1276' in s
assert 'paper_bot_v1.083' in p
assert 'actual_cost_rr_v1212' in p
assert 'guard_v2.5.254_v1276' in g
assert 'gledger_v1276_text' in g
