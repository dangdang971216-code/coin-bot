v1276: Strategy S1 actual-cost alignment with existing Paper final safety. Apply with /gupgrade_bundle. Auto-buy remains OFF.
