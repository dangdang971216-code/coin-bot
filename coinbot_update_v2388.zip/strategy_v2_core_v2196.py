from __future__ import annotations

import hashlib
import json
import math
import statistics
import time
from collections import Counter
from typing import Any, Dict, Iterable, List, Optional, Tuple

VERSION = "strategy_v2_core_v2196"
BUILD_LABEL = "prediction_primary_12_material_post_structure_target_truth_2026-08-01"
GENERATION = "ALT_SWING_V2_COMBINED_V2149_RESET_20260722"
PREDICTION_MODEL_GENERATION = "RISE_PRICE_DIRECTION_PRIMARY_5D_PRE_STRUCTURE_12"

REQUIRED_ROWS = {"m5": 48, "m15": 32, "m30": 48, "h1": 48, "h2": 32, "h4": 20}
TF_WEIGHT = {"m5": 1.0, "m15": 1.5, "m30": 2.1, "h1": 2.9, "h2": 4.0, "h4": 5.0}
RISE_MATERIAL_NAMES = (
    "return_30m_atr_adjusted",
    "price_acceleration_30m",
    "price_acceleration_1h",
    "relative_strength_1h",
    "relative_strength_acceleration_1h",
    "turnover_growth_recent1h_vs_prior3h",
    "turnover_acceleration_30m",
    "higher_low_strength_atr",
    "pullback_recovery_ratio",
    "btc_price_acceleration_1h",
    "market_breadth_change",
    "market_liquidity_state",
)
POST_STRUCTURE_MATERIAL_NAMES = ("target_path_consumed_ratio",)

def _num(value: Any, default: Optional[float] = None) -> Optional[float]:
    try:
        if value is None or isinstance(value, bool):
            return default
        out = float(value)
        return out if math.isfinite(out) else default
    except Exception:
        return default

def _clip(value: float, low: float, high: float) -> float:
    return max(low, min(high, float(value)))

def _median(values: Iterable[float], default: float = 0.0) -> float:
    vals = [float(x) for x in values if _num(x) is not None]
    return float(statistics.median(vals)) if vals else float(default)

def _ema(values: List[float], period: int) -> Optional[float]:
    clean = [float(x) for x in values if _num(x) is not None]
    if len(clean) < max(2, period):
        return None
    alpha = 2.0 / (float(period) + 1.0)
    value = sum(clean[:period]) / float(period)
    for item in clean[period:]:
        value = alpha * item + (1.0 - alpha) * value
    return value

def _atr(rows: List[Dict[str, float]], period: int = 14) -> float:
    if len(rows) < 2:
        return 0.0
    trs: List[float] = []
    prev: Optional[float] = None
    for row in rows[-max(period * 4, 48):]:
        high = float(row.get("h") or 0.0)
        low = float(row.get("l") or 0.0)
        close = float(row.get("c") or 0.0)
        if min(high, low, close) <= 0:
            continue
        tr = high - low if prev is None else max(high - low, abs(high - prev), abs(low - prev))
        trs.append(max(0.0, tr))
        prev = close
    if not trs:
        return 0.0
    seed = min(period, len(trs))
    value = sum(trs[:seed]) / seed
    for tr in trs[seed:]:
        value = ((period - 1.0) * value + tr) / period
    return max(0.0, value)

def _pivots(rows: List[Dict[str, float]], side: str, window: int) -> List[Dict[str, Any]]:
    out: List[Dict[str, Any]] = []
    if len(rows) < window * 2 + 3:
        return out
    for idx in range(window, len(rows) - window):
        row = rows[idx]
        value = float(row["l"] if side == "low" else row["h"])
        peers = [float(rows[j]["l"] if side == "low" else rows[j]["h"]) for j in range(idx - window, idx + window + 1) if j != idx]
        confirmed = value < min(peers) if side == "low" else value > max(peers)
        if confirmed:
            out.append({"price": value, "ts": float(row["ts"]), "index": idx, "side": side})
    return out

def _cluster_levels(levels: List[Dict[str, Any]], *, atr_ref: float, current: float) -> List[Dict[str, Any]]:
    clean = [dict(x) for x in levels if (_num(x.get("price"), 0.0) or 0.0) > 0]
    clean.sort(key=lambda x: float(x["price"]))
    groups: List[List[Dict[str, Any]]] = []
    tolerance = max(atr_ref * 0.22, current * 0.0012)
    for item in clean:
        price = float(item["price"])
        if groups:
            center = sum(float(x["price"]) * float(x.get("weight") or 1.0) for x in groups[-1]) / max(1e-12, sum(float(x.get("weight") or 1.0) for x in groups[-1]))
            if abs(price - center) <= tolerance:
                groups[-1].append(item)
                continue
        groups.append([item])
    out: List[Dict[str, Any]] = []
    for group in groups:
        weight_sum = sum(float(x.get("weight") or 1.0) for x in group)
        center = sum(float(x["price"]) * float(x.get("weight") or 1.0) for x in group) / max(weight_sum, 1e-12)
        out.append({
            "price": center,
            "low": min(float(x["price"]) for x in group) - tolerance * 0.35,
            "high": max(float(x["price"]) for x in group) + tolerance * 0.35,
            "score": weight_sum + min(3.0, len({str(x.get("tf")) for x in group})) * 0.5,
            "source_count": len(group),
            "timeframes": sorted({str(x.get("tf")) for x in group}),
            "last_source_ts": max(float(x.get("ts") or 0.0) for x in group),
        })
    return out

def _level_candidates(frames: Dict[str, List[Dict[str, float]]], tfs: Tuple[str, ...], side: str) -> List[Dict[str, Any]]:
    levels: List[Dict[str, Any]] = []
    for tf in tfs:
        rows = frames.get(tf) or []
        window = 2 if tf in {"m5", "m15"} else 3
        for item in _pivots(rows[-120:], "low" if side == "support" else "high", window):
            item["tf"] = tf
            item["weight"] = TF_WEIGHT.get(tf, 1.0)
            levels.append(item)
    return levels

def _trend_axis(rows: List[Dict[str, float]]) -> Optional[float]:
    closes = [float(r["c"]) for r in rows if float(r.get("c") or 0.0) > 0]
    if len(closes) < 24:
        return None
    fast = _ema(closes, 8)
    slow = _ema(closes, 21)
    prior_fast = _ema(closes[:-3], 8) if len(closes) >= 27 else None
    if fast is None or slow is None or prior_fast is None or slow <= 0:
        return None
    spread = (fast - slow) / slow * 100.0
    slope = (fast - prior_fast) / max(abs(prior_fast), 1e-12) * 100.0
    return _clip(spread * 2.8 + slope * 5.0, -1.0, 1.0)

def _row_price(row: Dict[str, Any]) -> Optional[float]:
    for obj in (row, row.get("raw") if isinstance(row.get("raw"), dict) else {}, row.get("entry_context") if isinstance(row.get("entry_context"), dict) else {}):
        if not isinstance(obj, dict):
            continue
        for key in ("current_price", "trade_price", "price", "last_price", "close", "entry_price"):
            value = _num(obj.get(key))
            if value is not None and value > 0:
                return value
    return None

def _nested(row: Dict[str, Any], *keys: str) -> Dict[str, Any]:
    for key in keys:
        value = row.get(key)
        if isinstance(value, dict):
            return value
    return {}

def _plan_hash(payload: Dict[str, Any]) -> str:
    raw = json.dumps(payload, ensure_ascii=False, sort_keys=True, separators=(",", ":")).encode("utf-8")
    return hashlib.sha256(raw).hexdigest()[:20]

def _return_pct(rows: List[Dict[str, float]], bars: int, end_offset: int = 0) -> Optional[float]:
    if bars <= 0 or len(rows) < bars + 1 + end_offset:
        return None
    end_index = len(rows) - 1 - end_offset
    start_index = end_index - bars
    start = _num(rows[start_index].get("c"))
    end = _num(rows[end_index].get("c"))
    if start is None or end is None or start <= 0:
        return None
    return (end / start - 1.0) * 100.0


def _bar_turnover(row: Dict[str, float]) -> Optional[float]:
    close = _num(row.get("c"))
    volume = _num(row.get("v"))
    if close is None or volume is None or close <= 0 or volume < 0:
        return None
    return close * volume


def _avg_turnover(rows: List[Dict[str, float]]) -> Optional[float]:
    values = [_bar_turnover(row) for row in rows]
    ready = [float(value) for value in values if value is not None]
    return sum(ready) / len(ready) if ready else None



def _frame_state(rows: List[Dict[str, float]], need: int, nowv: float, frame_sec: float, truth: Optional[Dict[str,Any]] = None) -> Dict[str, Any]:
    count=len(rows)
    latest=_num(rows[-1].get('ts')) if rows else None
    latest_close=latest+frame_sec if latest is not None else None
    age=max(0.0,nowv-latest_close) if latest_close is not None else None
    truth=truth if isinstance(truth,dict) else {}
    owner_state=str(truth.get('data_state') or truth.get('state') or '').upper()
    owner_reason=str(truth.get('data_reason') or truth.get('reason') or '')
    if owner_state=='SOURCE_MISSING':
        state='SOURCE_MISSING'; reason=owner_reason or 'SOURCE_MISSING'
    elif owner_state=='MISSING':
        state='MISSING'; reason=owner_reason or 'SOURCE_HAS_NO_USABLE_COMPLETED_BAR'
    elif count<need:
        state='MISSING'; reason='INSUFFICIENT_COMPLETED_BARS'
    elif owner_state=='STALE' or (not owner_state and age is not None and age>frame_sec*2.25):
        state='STALE'; reason=owner_reason or 'REFRESH_DUE'
    else:
        state='READY'; reason=None
    return {
        'state':state,'owner_data_state':owner_state or None,'owner_data_reason':owner_reason or None,
        'count':count,'required':need,'last_source_bar_ts':latest,'last_completed_ts':latest_close,
        'age_sec':round(age,3) if age is not None else None,'reason':reason,
        'attempted_ts':_num(truth.get('attempted_ts')),'api_success_ts':_num(truth.get('api_success_ts')),
        'completed_update_ts':_num(truth.get('completed_update_ts')),'completed_bar_changed':truth.get('completed_bar_changed') is True,
        'fetch_state':truth.get('fetch_state')
    }


def _material(name: str, value: Any, source_owner: str, source: str, state: str, raw: Any = None) -> Dict[str, Any]:
    numeric=_num(value)
    source_state=str(state or 'MISSING').upper()
    if source_state not in {'READY','STALE','MISSING','SOURCE_MISSING'}:
        source_state='MISSING'
    public_value=round(numeric,8) if numeric is not None else value if isinstance(value,(str,dict,list)) else None
    observed_value_available=public_value is not None
    if source_state=='READY' and observed_value_available:
        material_state='READY'; value_state='READY'; missing_reason=None
    elif source_state=='STALE':
        material_state='STALE'; value_state='STALE'; missing_reason='SOURCE_STALE'
    elif source_state=='SOURCE_MISSING':
        material_state='SOURCE_MISSING'; value_state='MISSING'; missing_reason='SOURCE_MISSING'
    elif source_state=='MISSING':
        material_state='MISSING'; value_state='MISSING'; missing_reason='SOURCE_MISSING'
    else:
        material_state='MISSING'; value_state='MISSING'; missing_reason='DERIVED_VALUE_NOT_AVAILABLE'
    return {
        'name':name,'value':public_value,'raw':raw,'owner':'strategy_v2_core','calculation_owner':'strategy_v2_core',
        'source_owner':source_owner,'source':source,'state':material_state,'source_state':source_state,'value_state':value_state,
        'observed_value_available':observed_value_available,'missing_reason':missing_reason,
        'source_last_completed_ts':None,'source_updated_ts':None,'source_age_sec':None,'source_attempted_ts':None,'source_success_ts':None,
        'source_completed_update_ts':None,'source_completed_bar_changed':None,'source_fetch_states':[],
        'used_as_gate':False,'zero_filled':False
    }


def _source_state(*states: str) -> str:
    values=[str(value or 'MISSING').upper() for value in states]
    if any(value=='SOURCE_MISSING' for value in values): return 'SOURCE_MISSING'
    if any(value=='MISSING' for value in values): return 'MISSING'
    if any(value=='STALE' for value in values): return 'STALE'
    return 'READY'


def _latest_confirmed_swing_low(rows: List[Dict[str, float]]) -> Dict[str, Any]:
    lows = _pivots(rows[-80:], "low", 2)
    if not lows:
        return {"state": "MISSING", "price": None, "ts": None}
    item = lows[-1]
    return {"state": "READY", "price": _num(item.get("price")), "ts": _num(item.get("ts"))}


def _market_context(row: Dict[str, Any]) -> Dict[str, Any]:
    for key in ("global_market_context_v2130", "market_context_v2130"):
        value = row.get(key)
        if isinstance(value, dict):
            return value
    return {}




def _owner_meta(row: Dict[str, Any], owner_key: str, nowv: float) -> Dict[str, Any]:
    root = row.get("prediction_owner_meta_v2155") if isinstance(row.get("prediction_owner_meta_v2155"), dict) else {}
    item = root.get(owner_key) if isinstance(root.get(owner_key), dict) else {}
    updated = _num(item.get("updated_ts"))
    attempted = _num(item.get("attempted_ts"), _num(item.get("last_attempt_ts")))
    success = _num(item.get("success_ts"), _num(item.get("last_success_ts"), updated))
    return {
        "owner": item.get("owner"),
        "updated_ts": updated,
        "attempted_ts": attempted,
        "success_ts": success,
        "age_sec": round(max(0.0, nowv - updated), 3) if updated is not None else None,
    }


def _completed_close_ts(row: Dict[str, float], sec: float) -> Optional[float]:
    ts = _num(row.get("ts"))
    return ts + sec if ts is not None else None


def _acceleration_series(rows: List[Dict[str, float]], mode: str) -> List[Dict[str, Any]]:
    out: List[Dict[str, Any]] = []
    if mode == "price":
        for idx in range(2, len(rows)):
            p0 = _num(rows[idx - 2].get("c")); p1 = _num(rows[idx - 1].get("c")); p2 = _num(rows[idx].get("c"))
            if p0 is None or p1 is None or p2 is None or min(p0, p1) <= 0:
                continue
            r0 = (p1 / p0 - 1.0) * 100.0
            r1 = (p2 / p1 - 1.0) * 100.0
            out.append({"ts": _completed_close_ts(rows[idx], 1800.0), "value": r1 - r0})
    else:
        turns = [_bar_turnover(row) for row in rows]
        for idx in range(1, len(rows)):
            prev = turns[idx - 1]; cur = turns[idx]
            if prev is None or cur is None or prev <= 0:
                continue
            out.append({"ts": _completed_close_ts(rows[idx], 1800.0), "value": ((cur / prev) - 1.0) * 100.0})
    return out


def _latest_positive_transition(series: List[Dict[str, Any]]) -> Optional[float]:
    latest: Optional[float] = None
    previous: Optional[float] = None
    for item in series:
        value = _num(item.get("value"))
        ts = _num(item.get("ts"))
        if value is None or ts is None:
            continue
        if value > 0 and (previous is None or previous <= 0):
            latest = ts
        previous = value
    return latest


def _price_volume_sequence(m30: List[Dict[str, float]]) -> Dict[str, Any]:
    price_ts = _latest_positive_transition(_acceleration_series(m30[-12:], "price"))
    volume_ts = _latest_positive_transition(_acceleration_series(m30[-12:], "turnover"))
    if price_ts is None or volume_ts is None:
        state = "UNKNOWN"
        reason = "POSITIVE_TRANSITION_TIMESTAMP_MISSING"
    elif abs(price_ts - volume_ts) < 1.0:
        state = "SAME_BAR"
        reason = "PRICE_AND_TURNOVER_ACCELERATION_TURNED_POSITIVE_ON_SAME_COMPLETED_30M_BAR"
    elif volume_ts < price_ts:
        state = "VOLUME_LEADS"
        reason = "TURNOVER_ACCELERATION_TURNED_POSITIVE_BEFORE_PRICE_ACCELERATION"
    else:
        state = "PRICE_LEADS"
        reason = "PRICE_ACCELERATION_TURNED_POSITIVE_BEFORE_TURNOVER_ACCELERATION"
    return {
        "state": state,
        "price_positive_transition_ts": price_ts,
        "turnover_positive_transition_ts": volume_ts,
        "reason": reason,
        "completed_candles_only": True,
        "used_as_gate": False,
    }


def _explanation_tags(
    *, price_accel: Optional[float], prior_price_accel: Optional[float],
    rs_accel: Optional[float], prior_rs_accel: Optional[float],
    turnover_accel: Optional[float], prior_turnover_accel: Optional[float],
    higher_low: Optional[float], prior_return_30m: Optional[float],
    recovery: Optional[float], prior_recovery: Optional[float],
    pre_signal_rise: Optional[float], episode_bar_count: Optional[int],
) -> Dict[str, Any]:
    evidence: Dict[str, Dict[str, Any]] = {}
    beginning = bool(
        price_accel is not None and price_accel > 0
        and rs_accel is not None and rs_accel > 0
        and ((prior_price_accel is not None and prior_price_accel <= 0) or (prior_rs_accel is not None and prior_rs_accel <= 0))
    )
    evidence["BEGINNING"] = {
        "matched": beginning,
        "reason": "PRICE_AND_RELATIVE_STRENGTH_ACCELERATION_POSITIVE_AFTER_PRIOR_NONPOSITIVE_AXIS",
        "values": {"price_acceleration_30m": price_accel, "prior_price_acceleration_30m": prior_price_accel, "relative_strength_acceleration_1h": rs_accel, "prior_relative_strength_acceleration_1h": prior_rs_accel},
    }
    restart = bool(
        higher_low is not None and higher_low > 0
        and prior_return_30m is not None and prior_return_30m <= 0
        and price_accel is not None and price_accel > 0
        and recovery is not None and prior_recovery is not None and recovery > prior_recovery
    )
    evidence["RESTART"] = {
        "matched": restart,
        "reason": "HIGHER_LOW_WITH_PULLBACK_THEN_PRICE_ACCELERATION_AND_RECOVERY_REEXPANSION",
        "values": {"higher_low_strength_atr": higher_low, "prior_30m_return_pct": prior_return_30m, "price_acceleration_30m": price_accel, "pullback_recovery_ratio": recovery, "prior_pullback_recovery_ratio": prior_recovery},
    }
    chase = bool(
        pre_signal_rise is not None and pre_signal_rise > 0
        and episode_bar_count is not None and episode_bar_count >= 2
    )
    evidence["CHASE"] = {
        "matched": chase,
        "reason": "PRE_SIGNAL_RISE_ALREADY_IN_PROGRESS_BEFORE_STRUCTURE",
        "values": {"pre_signal_rise_pct": pre_signal_rise, "episode_completed_30m_bars": episode_bar_count},
    }
    weakened = [
        price_accel is not None and prior_price_accel is not None and price_accel < prior_price_accel,
        rs_accel is not None and prior_rs_accel is not None and rs_accel < prior_rs_accel,
        turnover_accel is not None and prior_turnover_accel is not None and turnover_accel < prior_turnover_accel,
    ]
    exhaustion = sum(bool(item) for item in weakened) >= 2 and bool(prior_price_accel is not None and prior_price_accel > 0)
    evidence["EXHAUSTION"] = {
        "matched": exhaustion,
        "reason": "AT_LEAST_TWO_ACCELERATION_AXES_WEAKEN_AFTER_PRIOR_POSITIVE_PRICE_ACCELERATION",
        "values": {"price_acceleration_30m": price_accel, "prior_price_acceleration_30m": prior_price_accel, "relative_strength_acceleration_1h": rs_accel, "prior_relative_strength_acceleration_1h": prior_rs_accel, "turnover_acceleration_30m": turnover_accel, "prior_turnover_acceleration_30m": prior_turnover_accel},
    }
    tags = [name for name, item in evidence.items() if item.get("matched")]
    return {
        "tags": tags,
        "labels_ko": [{"BEGINNING": "초입", "RESTART": "재출발", "CHASE": "추격", "EXHAUSTION": "소진"}[name] for name in tags],
        "evidence": evidence,
        "overlap_allowed": True,
        "no_tag_allowed": True,
        "used_as_gate": False,
        "used_as_score": False,
    }



def _model_value(value: Any) -> Tuple[str,Any]:
    numeric=_num(value)
    if numeric is not None: return 'numeric',float(numeric)
    if isinstance(value,dict):
        risk=str(value.get('risk_state') or 'UNKNOWN'); context=str(value.get('context_state') or 'UNKNOWN'); concentration=_num(value.get('turnover_concentration_top10_pct'))
        band='UNKNOWN' if concentration is None else 'HIGH' if concentration>=65 else 'MID' if concentration>=40 else 'LOW'
        return 'categorical',f'RISK_{risk}|CONTEXT_{context}|CONCENTRATION_{band}'
    if value is None: return 'missing',None
    return 'categorical',str(value)


def _model_bucket(value: float, edges: List[float]) -> str:
    if len(edges)<3: return 'ALL'
    if value<=edges[0]: return 'Q1'
    if value<=edges[1]: return 'Q2'
    if value<=edges[2]: return 'Q3'
    return 'Q4'


def _logit(probability: float) -> float:
    p=max(0.01,min(0.99,float(probability)))
    return math.log(p/(1.0-p))


def _logistic(value: float) -> float:
    if value>=0: return 1.0/(1.0+math.exp(-min(60.0,value)))
    exp=math.exp(max(-60.0,value)); return exp/(1.0+exp)


def _score_target(target: Dict[str,Any], payload: Dict[str,Any]) -> Dict[str,Any]:
    target=target if isinstance(target,dict) else {}
    base_pct=_num(target.get('base_probability_pct'),50.0) or 50.0
    base=max(0.01,min(0.99,base_pct/100.0))
    materials=payload.get('materials') if isinstance(payload.get('materials'),dict) else {}
    feature_models=target.get('feature_models') if isinstance(target.get('feature_models'),dict) else {}
    evidence=[]
    for name,model in feature_models.items():
        item=materials.get(name) if isinstance(materials.get(name),dict) else {}
        # Only the Candle/owner READY truth is eligible. Old numeric values from
        # STALE/MISSING sources remain visible for audit but never enter prediction.
        if str(item.get('state') or '')!='READY' or str(item.get('source_state') or '')!='READY' or item.get('value') is None:
            continue
        kind,value=_model_value(item.get('value'))
        buckets=model.get('buckets') if isinstance(model.get('buckets'),dict) else {}
        bucket=None
        if kind=='numeric' and str(model.get('kind'))=='numeric':
            bucket=_model_bucket(float(value),[float(x) for x in (model.get('edges') or [])])
        elif kind=='categorical':
            bucket=str(value)
        stats=buckets.get(bucket) if bucket and isinstance(buckets.get(bucket),dict) else None
        if not stats: continue
        probability=_num(stats.get('probability_pct')); sample=_num(stats.get('effective_sample'),0.0) or 0.0
        if probability is None: continue
        weight=min(1.0,sample/20.0)
        delta=_logit(probability/100.0)-_logit(base)
        evidence.append((weight,delta,f'{name}:{bucket}'))
    tags=[str(tag) for tag in (payload.get('explanation_tags') or [])]
    for tag in tags:
        stats=(target.get('tag_models') or {}).get(tag) if isinstance(target.get('tag_models'),dict) else None
        if isinstance(stats,dict) and _num(stats.get('probability_pct')) is not None:
            sample=_num(stats.get('effective_sample'),0.0) or 0.0
            evidence.append((min(0.65,sample/30.0),_logit(float(stats['probability_pct'])/100.0)-_logit(base),f'TAG:{tag}'))
    combo='+'.join(sorted(tags)) or 'NONE'
    stats=(target.get('tag_combination_models') or {}).get(combo) if isinstance(target.get('tag_combination_models'),dict) else None
    if isinstance(stats,dict) and _num(stats.get('probability_pct')) is not None:
        sample=_num(stats.get('effective_sample'),0.0) or 0.0
        evidence.append((min(0.8,sample/20.0),_logit(float(stats['probability_pct'])/100.0)-_logit(base),f'TAG_COMBO:{combo}'))
    sequence=str((payload.get('price_volume_sequence') or {}).get('state') or 'UNKNOWN') if isinstance(payload.get('price_volume_sequence'),dict) else 'UNKNOWN'
    stats=(target.get('sequence_models') or {}).get(sequence) if isinstance(target.get('sequence_models'),dict) else None
    if isinstance(stats,dict) and _num(stats.get('probability_pct')) is not None:
        sample=_num(stats.get('effective_sample'),0.0) or 0.0
        evidence.append((min(0.65,sample/30.0),_logit(float(stats['probability_pct'])/100.0)-_logit(base),f'SEQUENCE:{sequence}'))
    # Neutral evidence used to dilute every candidate back to the market base.
    # Keep the strongest current matches only; each bucket is already posterior-
    # shrunk in Review, so no second blanket shrink is applied here.
    ranked=sorted(evidence,key=lambda item:abs(item[0]*item[1]),reverse=True)
    selected=ranked[:6]
    weight_sum=sum(weight for weight,_,_ in selected)
    adjustment=(sum(weight*delta for weight,delta,_ in selected)/weight_sum) if weight_sum>0 else 0.0
    probability=_logistic(_logit(base)+adjustment)*100.0
    return {
        'probability_pct':round(max(1.0,min(99.0,probability)),3),
        'evidence_count':len(selected),'available_evidence_count':len(evidence),'evidence_weight':round(weight_sum,6),
        'evidence_keys':[key for _,_,key in selected],
        'target_sample_count':int(target.get('raw_sample_count') or 0),
        'target_effective_sample':_num(target.get('effective_sample'),0.0) or 0.0,
        'base_probability_pct':round(base*100.0,3),
        'target_basis':target.get('target_basis')
    }


def _apply_live_prediction(payload: Dict[str,Any], row: Dict[str,Any]) -> Dict[str,Any]:
    model=row.get('rise_prediction_model_snapshot') if isinstance(row.get('rise_prediction_model_snapshot'),dict) else {}
    targets=model.get('targets') if isinstance(model.get('targets'),dict) else {}
    scores={name:_score_target(targets.get(name) if isinstance(targets.get(name),dict) else {},payload) for name in ('probability_3h','probability_6h','giveback_risk','late_capture_risk')}
    usable=sum(1 for item in (payload.get('materials') or {}).values() if isinstance(item,dict) and str(item.get('state') or '')=='READY' and str(item.get('source_state') or '')=='READY' and item.get('value') is not None)
    effective_samples=[float(score.get('target_effective_sample') or 0.0) for score in scores.values()]
    sample_strength=min(1.0,(sum(effective_samples)/len(effective_samples))/200.0) if effective_samples else 0.0
    coverage=usable/max(1,len(RISE_MATERIAL_NAMES))
    evidence=sum(int(score.get('evidence_count') or 0) for score in scores.values())/4.0
    confidence=max(0.0,min(100.0,100.0*(0.45*sample_strength+0.35*coverage+0.20*min(1.0,evidence/6.0))))
    confidence_state='HIGH' if confidence>=75 else 'MEDIUM' if confidence>=50 else 'LOW'
    live=any(int(score.get('target_sample_count') or 0)>0 for score in scores.values())
    payload.update({
        'probability_3h':scores['probability_3h']['probability_pct'],'probability_6h':scores['probability_6h']['probability_pct'],
        'giveback_risk':scores['giveback_risk']['probability_pct'],'late_capture_risk':scores['late_capture_risk']['probability_pct'],
        'predicted_direction_3h':('NEUTRAL' if int(scores['probability_3h'].get('target_sample_count') or 0)<=0 or scores['probability_3h']['probability_pct']==50.0 else 'UP' if scores['probability_3h']['probability_pct']>50.0 else 'DOWN'),
        'predicted_direction_6h':('NEUTRAL' if int(scores['probability_6h'].get('target_sample_count') or 0)<=0 or scores['probability_6h']['probability_pct']==50.0 else 'UP' if scores['probability_6h']['probability_pct']>50.0 else 'DOWN'),
        'output_states':{name:'LIVE' if int(score.get('target_sample_count') or 0)>0 else 'LOW_SAMPLE_NEUTRAL' for name,score in scores.items()},
        'model_state':'LIVE' if live else 'LOW_SAMPLE_NEUTRAL','prediction_model_id':model.get('model_id'),'prediction_model_generated_ts':_num(model.get('generated_ts')),
        'prediction_model_retention_days':int(model.get('retention_days') or 5),'prediction_confidence_pct':round(confidence,3),'prediction_confidence_state':confidence_state,
        'prediction_confidence_meaning':'DATA_AND_MODEL_SAMPLE_COMPLETENESS_NOT_VERIFIED_ACCURACY',
        'prediction_evidence_count':sum(int(score.get('evidence_count') or 0) for score in scores.values()),'prediction_target_scores':scores,
        'usable_input_count':usable,'usable_input_coverage_pct':round(coverage*100.0,3),'probability_calculation_active':True,
        'model_evidence_weighting_applied':True,'weights_applied':False,'thresholds_applied':False,'prediction_used_as_gate':True,
        'candidate_preserved':True,'zero_fill_used':False,'auto_buy':False
    })
    return payload


def build_rise_prediction_input(row: Dict[str, Any], frames: Dict[str, List[Dict[str, float]]], structure: Dict[str, Any], nowv: float) -> Dict[str, Any]:
    ticker = str(row.get("ticker") or row.get("symbol") or "").upper().replace("KRW-", "").strip()
    m30 = frames.get("m30") if isinstance(frames.get("m30"), list) else []
    h1 = frames.get("h1") if isinstance(frames.get("h1"), list) else []
    # Strategy normalizes the shared BTC completed h1 list once per owner-map cycle.
    # This core only reads that existing list; no per-ticker reparse or copy.
    btc_h1 = row.get("prediction_benchmark_h1") if isinstance(row.get("prediction_benchmark_h1"), list) else []

    ticker_truth=row.get('prediction_candle_frame_truth') if isinstance(row.get('prediction_candle_frame_truth'),dict) else {}
    btc_truth=row.get('prediction_benchmark_frame_truth') if isinstance(row.get('prediction_benchmark_frame_truth'),dict) else {}
    states = {
        "m30": _frame_state(m30, 8, nowv, 1800.0, ticker_truth.get('m30') if isinstance(ticker_truth.get('m30'),dict) else {}),
        "h1": _frame_state(h1, 16, nowv, 3600.0, ticker_truth.get('h1') if isinstance(ticker_truth.get('h1'),dict) else {}),
        "btc_h1": _frame_state(btc_h1, 4, nowv, 3600.0, btc_truth.get('h1') if isinstance(btc_truth.get('h1'),dict) else {}),
    }
    current = _row_price(row)
    atr1h = _atr(h1, 14) if h1 else 0.0
    atr1h_pct = (atr1h / current * 100.0) if current and current > 0 and atr1h > 0 else None

    ret30 = _return_pct(m30, 1)
    prior30 = _return_pct(m30, 1, 1)
    priorprior30 = _return_pct(m30, 1, 2)
    ret1h = _return_pct(h1, 1)
    prior1h = _return_pct(h1, 1, 1)
    priorprior1h = _return_pct(h1, 1, 2)
    btc1h = _return_pct(btc_h1, 1)
    btc_prior1h = _return_pct(btc_h1, 1, 1)
    btc_priorprior1h = _return_pct(btc_h1, 1, 2)
    price_accel_30m = (ret30 - prior30) if ret30 is not None and prior30 is not None else None
    prior_price_accel_30m = (prior30 - priorprior30) if prior30 is not None and priorprior30 is not None else None
    price_accel_1h = (ret1h - prior1h) if ret1h is not None and prior1h is not None else None

    recent1h_turn = _avg_turnover(h1[-1:]) if len(h1) >= 1 else None
    prior3h_turn = _avg_turnover(h1[-4:-1]) if len(h1) >= 4 else None
    recent30_turn = _avg_turnover(m30[-1:]) if len(m30) >= 1 else None
    prior30_turn = _avg_turnover(m30[-2:-1]) if len(m30) >= 2 else None
    priorprior30_turn = _avg_turnover(m30[-3:-2]) if len(m30) >= 3 else None
    turnover_accel_30m = ((recent30_turn / prior30_turn) - 1.0) * 100.0 if recent30_turn is not None and prior30_turn and prior30_turn > 0 else None
    prior_turnover_accel_30m = ((prior30_turn / priorprior30_turn) - 1.0) * 100.0 if prior30_turn is not None and priorprior30_turn and priorprior30_turn > 0 else None

    swing = _latest_confirmed_swing_low(m30)
    previous_swings = _pivots(m30[-80:], "low", 2)
    prior_swing_price = _num(previous_swings[-2].get("price")) if len(previous_swings) >= 2 else None
    current_swing_price = _num(swing.get("price"))
    higher_low = ((current_swing_price - prior_swing_price) / max(atr1h, 1e-12)) if current_swing_price is not None and prior_swing_price is not None and atr1h > 0 else None

    recent_highs = _pivots(m30[-80:], "high", 2)
    prior_high = _num(recent_highs[-1].get("price")) if recent_highs else None
    pullback_recovery = None
    prior_pullback_recovery = None
    if current is not None and current_swing_price is not None and prior_high is not None and prior_high > current_swing_price:
        pullback_recovery = (current - current_swing_price) / (prior_high - current_swing_price)
        prior_close = _num(m30[-2].get("c")) if len(m30) >= 2 else None
        prior_close_ts = _num(m30[-2].get("ts")) if len(m30) >= 2 else None
        if prior_close is not None and prior_close_ts is not None and (swing.get("ts") is None or prior_close_ts >= float(swing.get("ts"))):
            prior_pullback_recovery = (prior_close - current_swing_price) / (prior_high - current_swing_price)

    market = _market_context(row)
    breadth_change = _num(market.get("breadth_velocity_pct_v2130"))
    market_age = None
    market_updated = _num(market.get("updated_ts"))
    if market_updated is not None:
        market_age = max(0.0, nowv - market_updated)
    market_state = "MISSING" if not market else ("STALE" if market_age is not None and market_age > 300.0 else "READY")
    liquidity_raw = {
        "turnover_concentration_top10_pct": _num(market.get("turnover_concentration_top10_pct_v2130")),
        "turnover_concentration_velocity": _num(market.get("turnover_concentration_velocity_v2130")),
        "market_change_dispersion_pct": _num(market.get("market_change_dispersion_pct_v2155")),
        "risk_state": market.get("risk_state_v2130"),
        "context_state": market.get("state"),
    }

    material_rows: Dict[str, Dict[str, Any]] = {}
    material_rows["return_30m_atr_adjusted"] = _material(
        "return_30m_atr_adjusted",
        (ret30 / atr1h_pct) if ret30 is not None and atr1h_pct and atr1h_pct > 0 else None,
        "candle_worker", "completed m30 return / h1 ATR%", _source_state(states["m30"]["state"], states["h1"]["state"]),
        {"return_30m_pct": ret30, "atr_1h_pct": atr1h_pct},
    )
    material_rows["price_acceleration_30m"] = _material(
        "price_acceleration_30m", price_accel_30m,
        "candle_worker", "recent completed 30m return - prior completed 30m return", states["m30"]["state"],
        {"recent_30m_pct": ret30, "prior_30m_pct": prior30},
    )
    material_rows["price_acceleration_1h"] = _material(
        "price_acceleration_1h", price_accel_1h,
        "candle_worker", "recent completed 1h return - prior completed 1h return", states["h1"]["state"],
        {"recent_1h_pct": ret1h, "prior_1h_pct": prior1h},
    )
    rs1h = (ret1h - btc1h) if ret1h is not None and btc1h is not None else None
    prior_rs1h = (prior1h - btc_prior1h) if prior1h is not None and btc_prior1h is not None else None
    priorprior_rs1h = (priorprior1h - btc_priorprior1h) if priorprior1h is not None and btc_priorprior1h is not None else None
    rs_accel_1h = (rs1h - prior_rs1h) if rs1h is not None and prior_rs1h is not None else None
    prior_rs_accel_1h = (prior_rs1h - priorprior_rs1h) if prior_rs1h is not None and priorprior_rs1h is not None else None
    rs_state = _source_state(states["h1"]["state"], states["btc_h1"]["state"])
    material_rows["relative_strength_1h"] = _material(
        "relative_strength_1h", rs1h, "strategy_v2_core", "ticker completed h1 return - BTC completed h1 return", rs_state,
        {"ticker_1h_pct": ret1h, "btc_1h_pct": btc1h},
    )
    material_rows["relative_strength_acceleration_1h"] = _material(
        "relative_strength_acceleration_1h", rs_accel_1h,
        "strategy_v2_core", "current 1h relative strength - prior 1h relative strength", rs_state,
        {"current_rs_1h": rs1h, "prior_rs_1h": prior_rs1h},
    )
    material_rows["turnover_growth_recent1h_vs_prior3h"] = _material(
        "turnover_growth_recent1h_vs_prior3h",
        ((recent1h_turn / prior3h_turn) - 1.0) * 100.0 if recent1h_turn is not None and prior3h_turn and prior3h_turn > 0 else None,
        "candle_worker", "completed OHLCV close*volume recent 1h vs prior 3h hourly average", states["h1"]["state"],
        {"recent_1h_turnover_proxy": recent1h_turn, "prior_3h_hourly_avg_proxy": prior3h_turn},
    )
    material_rows["turnover_acceleration_30m"] = _material(
        "turnover_acceleration_30m",
        turnover_accel_30m,
        "candle_worker", "completed OHLCV close*volume recent 30m vs prior 30m", states["m30"]["state"],
        {"recent_30m_turnover_proxy": recent30_turn, "prior_30m_turnover_proxy": prior30_turn},
    )
    material_rows["higher_low_strength_atr"] = _material(
        "higher_low_strength_atr", higher_low, "strategy_v2_core", "latest two confirmed m30 swing lows / h1 ATR", _source_state(states["m30"]["state"], states["h1"]["state"]),
        {"latest_swing_low": current_swing_price, "prior_swing_low": prior_swing_price, "atr_1h": atr1h},
    )
    material_rows["pullback_recovery_ratio"] = _material(
        "pullback_recovery_ratio", pullback_recovery, "strategy_v2_core", "current recovery between latest confirmed m30 swing low and prior confirmed high", states["m30"]["state"],
        {"current_price": current, "swing_low": current_swing_price, "prior_swing_high": prior_high},
    )
    material_rows["btc_price_acceleration_1h"] = _material(
        "btc_price_acceleration_1h", (btc1h - btc_prior1h) if btc1h is not None and btc_prior1h is not None else None,
        "candle_worker", "BTC recent completed 1h return - prior completed 1h return", states["btc_h1"]["state"],
        {"recent_btc_1h_pct": btc1h, "prior_btc_1h_pct": btc_prior1h},
    )
    material_rows["market_breadth_change"] = _material(
        "market_breadth_change", breadth_change, "market_regime_worker", "breadth_velocity_pct_v2130", market_state,
        {"breadth_up_pct": _num(market.get("breadth_up_pct")), "breadth_change": breadth_change, "age_sec": market_age},
    )
    material_rows["market_liquidity_state"] = _material(
        "market_liquidity_state", liquidity_raw, "market_regime_worker", "turnover concentration + concentration velocity + market dispersion + risk state", market_state, liquidity_raw,
    )

    owner_meta = {
        "candle": _owner_meta(row, "candle", nowv),
        "market": _owner_meta(row, "market", nowv),
        "strategy": {"owner": "strategy_v2_core", "updated_ts": nowv, "attempted_ts": nowv, "success_ts": nowv, "age_sec": 0.0},
    }
    material_source_contract = {
        "return_30m_atr_adjusted": ("candle", [states["m30"], states["h1"]], ["m30", "h1"]),
        "price_acceleration_30m": ("candle", [states["m30"]], ["m30"]),
        "price_acceleration_1h": ("candle", [states["h1"]], ["h1"]),
        "relative_strength_1h": ("candle", [states["h1"], states["btc_h1"]], ["ticker_h1", "btc_h1"]),
        "relative_strength_acceleration_1h": ("candle", [states["h1"], states["btc_h1"]], ["ticker_h1", "btc_h1"]),
        "turnover_growth_recent1h_vs_prior3h": ("candle", [states["h1"]], ["h1"]),
        "turnover_acceleration_30m": ("candle", [states["m30"]], ["m30"]),
        "higher_low_strength_atr": ("candle", [states["m30"], states["h1"]], ["m30_confirmed_swings", "h1_atr"]),
        "pullback_recovery_ratio": ("candle", [states["m30"]], ["m30_confirmed_swing_low", "m30_confirmed_swing_high"]),
        "btc_price_acceleration_1h": ("candle", [states["btc_h1"]], ["btc_h1"]),
        "market_breadth_change": ("market", [], ["market_regime"]),
        "market_liquidity_state": ("market", [], ["market_regime"]),
    }
    for name, item in material_rows.items():
        owner_key, frame_items, required_inputs = material_source_contract[name]
        completed_values = [_num(frame.get("last_completed_ts")) for frame in frame_items if isinstance(frame, dict)]
        completed_values = [value for value in completed_values if value is not None]
        item["source_last_completed_ts"] = min(completed_values) if completed_values else (market_updated if owner_key == "market" else nowv if owner_key == "strategy" else None)
        item["source_updated_ts"] = owner_meta[owner_key].get("updated_ts")
        item["source_attempted_ts"] = owner_meta[owner_key].get("attempted_ts")
        frame_attempts=[_num(frame.get('attempted_ts')) for frame in frame_items if isinstance(frame,dict) and _num(frame.get('attempted_ts')) is not None]
        frame_successes=[_num(frame.get('api_success_ts')) for frame in frame_items if isinstance(frame,dict) and _num(frame.get('api_success_ts')) is not None]
        frame_updates=[_num(frame.get('completed_update_ts')) for frame in frame_items if isinstance(frame,dict) and _num(frame.get('completed_update_ts')) is not None]
        item["source_attempted_ts"] = max(frame_attempts) if frame_attempts else owner_meta[owner_key].get("attempted_ts")
        item["source_success_ts"] = max(frame_successes) if frame_successes else owner_meta[owner_key].get("success_ts")
        item["source_completed_update_ts"] = max(frame_updates) if frame_updates else None
        item["source_completed_bar_changed"] = any(bool(frame.get('completed_bar_changed')) for frame in frame_items if isinstance(frame,dict))
        item["source_fetch_states"] = [str(frame.get('fetch_state') or '') for frame in frame_items if isinstance(frame,dict) and frame.get('fetch_state')]
        source_reasons=[str(frame.get('reason') or frame.get('owner_data_reason') or '') for frame in frame_items if isinstance(frame,dict) and (frame.get('reason') or frame.get('owner_data_reason'))]
        item["source_reasons"] = list(dict.fromkeys(source_reasons))
        if item.get("state") != "READY" and source_reasons:
            item["missing_reason"] = '|'.join(dict.fromkeys(source_reasons))
        item["source_age_sec"] = max([float(frame.get('age_sec')) for frame in frame_items if isinstance(frame,dict) and _num(frame.get('age_sec')) is not None],default=owner_meta[owner_key].get("age_sec"))
        item["source_required_inputs"] = required_inputs
        if item.get("source_state") == "READY" and item.get("value") is None:
            item["state"] = "MISSING"
            item["value_state"] = "MISSING"
            if name == "higher_low_strength_atr":
                item["missing_reason"] = "TWO_CONFIRMED_M30_SWING_LOWS_NOT_AVAILABLE"
            elif name == "pullback_recovery_ratio":
                item["missing_reason"] = "CONFIRMED_PULLBACK_RANGE_NOT_AVAILABLE"
            elif name in {"market_breadth_change", "market_liquidity_state"}:
                item["missing_reason"] = "MARKET_OWNER_VALUE_NOT_AVAILABLE"
            else:
                item["missing_reason"] = "DERIVED_VALUE_NOT_AVAILABLE_FROM_COMPLETED_SOURCE"
    state_counts = Counter(str(item.get("state") or "MISSING") for item in material_rows.values())
    ready_count = state_counts.get("READY", 0)
    usable_count = ready_count
    latest_m30_ts = _num(m30[-1].get("ts")) if m30 else None
    event_bar_close_ts = latest_m30_ts + 1800.0 if latest_m30_ts is not None else None
    episode_low_ts = _num(swing.get("ts"))
    episode_id = f"{ticker}:{int(episode_low_ts)}" if ticker and episode_low_ts is not None else None
    event_key = f"{ticker}:{int(event_bar_close_ts)}" if ticker and event_bar_close_ts is not None else None
    event_price = _num(m30[-1].get("c")) if m30 else current
    pre_signal_rise_pct = None
    if event_price is not None and current_swing_price is not None and current_swing_price > 0:
        pre_signal_rise_pct = (event_price / current_swing_price - 1.0) * 100.0
    episode_bar_count = None
    if episode_low_ts is not None:
        episode_bar_count = sum(1 for bar in m30 if (_num(bar.get("ts")) or -1.0) >= episode_low_ts)
    signal_position = {
        "episode_low_ts": episode_low_ts,
        "episode_low_price": current_swing_price,
        "episode_completed_30m_bars": episode_bar_count,
        "pre_signal_rise_pct": round(pre_signal_rise_pct, 8) if pre_signal_rise_pct is not None else None,
        "pullback_recovery_ratio": pullback_recovery,
        "prior_pullback_recovery_ratio": prior_pullback_recovery,
        "prior_confirmed_swing_high": prior_high,
        "event_price": event_price,
        "late_capture_reason_inputs": {
            "pre_signal_rise_pct": pre_signal_rise_pct,
                "episode_completed_30m_bars": episode_bar_count,
        },
    }
    sequence = _price_volume_sequence(m30)
    tags = _explanation_tags(
        price_accel=price_accel_30m,
        prior_price_accel=prior_price_accel_30m,
        rs_accel=rs_accel_1h,
        prior_rs_accel=prior_rs_accel_1h,
        turnover_accel=turnover_accel_30m,
        prior_turnover_accel=prior_turnover_accel_30m,
        higher_low=higher_low,
        prior_return_30m=prior30,
        recovery=pullback_recovery,
        prior_recovery=prior_pullback_recovery,
        pre_signal_rise=pre_signal_rise_pct,
        episode_bar_count=episode_bar_count,
    )
    values = {name: material_rows[name].get("value") for name in RISE_MATERIAL_NAMES}
    payload = {
        "schema": "rise_prediction_input",
        "state": "READY" if ready_count == len(RISE_MATERIAL_NAMES) else ("PARTIAL" if usable_count else "MISSING"),
        "owner": "strategy_v2_core",
        "ticker": ticker,
        "event_key": event_key,
        "event_bar_close_ts": event_bar_close_ts,
        "event_price": round(event_price, 12) if event_price is not None else None,
        "episode_id": episode_id,
        "episode_low_ts": episode_low_ts,
        "episode_low_price": current_swing_price,
        "pre_signal_rise_pct": round(pre_signal_rise_pct, 8) if pre_signal_rise_pct is not None else None,
        "signal_position": signal_position,
        "price_volume_sequence": sequence,
        "explanation_tags": tags.get("tags"),
        "explanation_tag_labels_ko": tags.get("labels_ko"),
        "explanation_tag_evidence": tags.get("evidence"),
        "tag_overlap_allowed": True,
        "tag_used_as_gate": False,
        "materials": material_rows,
        "material_values": values,
        "material_names": list(RISE_MATERIAL_NAMES),
        "prediction_material_count": len(RISE_MATERIAL_NAMES),
        "post_structure_material_names": list(POST_STRUCTURE_MATERIAL_NAMES),
        "target_path_stage": "POST_STRUCTURE_ONLY",
        "source_state_counts": dict(state_counts),
        "input_coverage_pct": round(ready_count / len(RISE_MATERIAL_NAMES) * 100.0, 3),
        "usable_input_count": usable_count,
        "usable_input_coverage_pct": round(usable_count / len(RISE_MATERIAL_NAMES) * 100.0, 3),
        "probability_3h": None,
        "probability_6h": None,
        "giveback_risk": None,
        "late_capture_risk": None,
        "output_states": {},
        "model_state": "MODEL_LOADING",
        "probability_calculation_active": True,
        "weights_applied": False,
        "thresholds_applied": False,
        "prediction_used_as_gate": True,
        "candidate_preserved": True,
        "zero_fill_used": False,
        "auto_buy": False,
    }
    return _apply_live_prediction(payload,row)



def _prediction(row: Dict[str, Any], frames: Dict[str, List[Dict[str, float]]]) -> Dict[str, Any]:
    nowv = _num(
        row.get('prediction_owner_meta_v2155', {}).get('strategy_cycle_ts')
        if isinstance(row.get('prediction_owner_meta_v2155'), dict) else None,
        time.time(),
    ) or time.time()
    payload = build_rise_prediction_input(row, frames, {}, nowv)
    return {
        'schema': 'rise_prediction_observation',
        'state': payload.get('model_state'),
        'prediction_model_generation': PREDICTION_MODEL_GENERATION,
        'rise_prediction_input': payload,
        'materials': payload.get('materials'),
        'material_values': payload.get('material_values'),
        'input_coverage_pct': payload.get('input_coverage_pct'),
        'usable_input_coverage_pct': payload.get('usable_input_coverage_pct'),
        'probability_3h': payload.get('probability_3h'),
        'probability_6h': payload.get('probability_6h'),
        'giveback_risk': payload.get('giveback_risk'),
        'late_capture_risk': payload.get('late_capture_risk'),
        'prediction_model_id': payload.get('prediction_model_id'),
        'prediction_confidence_pct': payload.get('prediction_confidence_pct'),
        'prediction_confidence_state': payload.get('prediction_confidence_state'),
        'weights_applied': False,
        'thresholds_applied': False,
        'prediction_used_in_final_decision': True,
        'decision_reason': '상승예측이 전체 코인을 먼저 판정하고 UP 종목만 구조선 계산으로 전달',
        'candidate_preserved': True,
        'auto_buy': False,
    }


def _prediction_selection(prediction: Dict[str, Any]) -> Dict[str, Any]:
    payload = prediction.get('rise_prediction_input') if isinstance(prediction.get('rise_prediction_input'), dict) else {}
    p3 = _num(payload.get('probability_3h'))
    p6 = _num(payload.get('probability_6h'))
    usable = int(_num(payload.get('usable_input_count'), 0.0) or 0)
    model_state = str(payload.get('model_state') or 'MODEL_MISSING')
    target_scores = payload.get('prediction_target_scores') if isinstance(payload.get('prediction_target_scores'), dict) else {}
    sample3 = int((target_scores.get('probability_3h') or {}).get('target_sample_count') or 0) if isinstance(target_scores.get('probability_3h'), dict) else 0
    sample6 = int((target_scores.get('probability_6h') or {}).get('target_sample_count') or 0) if isinstance(target_scores.get('probability_6h'), dict) else 0

    if p3 is None or p6 is None or model_state not in {'LIVE', 'LOW_SAMPLE_NEUTRAL'}:
        decision = 'HOLD'
        reason = 'PREDICTION_OUTPUT_MISSING'
    elif sample3 <= 0 and sample6 <= 0:
        decision = 'HOLD'
        reason = 'PREDICTION_SAMPLE_MISSING'
    elif usable <= 0:
        decision = 'HOLD'
        reason = 'PREDICTION_INPUT_MISSING'
    elif p3 > 50.0 and p6 > 50.0:
        decision = 'UP'
        reason = 'RAW_RISE_PROBABILITY_ABOVE_HALF_BOTH_HORIZONS'
    elif p3 < 50.0 and p6 < 50.0:
        decision = 'DOWN'
        reason = 'RAW_RISE_PROBABILITY_BELOW_HALF_BOTH_HORIZONS'
    else:
        decision = 'HOLD'
        reason = 'HORIZON_DIRECTION_CONFLICT'

    return {
        'schema': 'rise_prediction_primary_selection',
        'decision': decision,
        'structure_allowed': decision == 'UP',
        'reason': reason,
        'probability_3h': p3,
        'probability_6h': p6,
        'combined_probability_pct': round((p3 + p6) / 2.0, 3) if p3 is not None and p6 is not None else None,
        'usable_input_count': usable,
        'model_state': model_state,
        'model_id': payload.get('prediction_model_id'),
        'prediction_first': True,
        'candidate_count_target_used': False,
        'forced_up_used': False,
        'auto_buy': False,
    }


def _combine_prediction_structure(selection: Dict[str, Any], structure: Dict[str, Any]) -> Dict[str, Any]:
    decision = str(selection.get('decision') or 'HOLD')
    structure_state = str(structure.get('state') or 'NOT_BUILT')
    if decision != 'UP':
        state = 'PREDICTION_DOWN' if decision == 'DOWN' else 'PREDICTION_HOLD'
        eligible = False
        reason = f"상승예측 {decision} · 구조선 계산 미실행 · {selection.get('reason') or '-'}"
    elif structure_state == 'STRUCTURE_READY':
        state = 'ENTRY_READY'
        eligible = True
        reason = '상승예측 UP 통과 후 기존 동적 trigger·invalid·target 구조 준비 완료'
    else:
        state = structure_state
        eligible = False
        reason = f"상승예측 UP 통과 · 구조 상태 {structure_state}"
    return {
        'schema': 'prediction_primary_structure_combiner',
        'state': state,
        'entry_eligible': eligible,
        'owner': 'strategy_v2_core.rise_prediction_primary',
        'reason': reason,
        'prediction_decision': decision,
        'prediction_reason': selection.get('reason'),
        'structure_state': structure_state,
        'prediction_first': True,
        'prediction_recomputed_in_paper': False,
        'prediction_used_as_gate': True,
        'candidate_preserved': True,
        'auto_buy': False,
    }

def build_combined_v2_contract(row: Dict[str, Any], frames: Dict[str, List[Dict[str, float]]], *, now_ts: Optional[float] = None) -> Dict[str, Any]:
    ts = float(now_ts if now_ts is not None else time.time())
    ticker = str(row.get("ticker") or row.get("symbol") or "").upper().replace("KRW-", "").strip()
    current = _row_price(row)
    counts = {tf: len(frames.get(tf) or []) for tf in REQUIRED_ROWS}
    missing = [tf for tf, need in REQUIRED_ROWS.items() if counts.get(tf, 0) < need]
    if current is None or current <= 0:
        missing.append("current_price")
    base: Dict[str, Any] = {
        "schema": "combined_v2_trade_contract_v2149", "version": VERSION, "build": BUILD_LABEL,
        "generation": GENERATION, "prediction_model_generation": PREDICTION_MODEL_GENERATION, "ticker": ticker, "evaluated_ts": ts,
        "candidate_preserved": True, "historical_ledger_rewritten": False,
        "legacy_structure_used": False, "legacy_entry_gate_used": False,
        "prediction_gate_active": True, "prediction_first": True, "decision_combiner_active": True, "auto_buy": False,
    }

    # Single active order: prediction on the whole universe first. Structure is
    # never calculated for DOWN/HOLD rows, but every row remains in the canonical
    # snapshot for missed-rise review.
    prediction = _prediction(row, frames)
    selection = _prediction_selection(prediction)
    prediction["primary_selection"] = dict(selection)
    rise_input = prediction.get("rise_prediction_input") if isinstance(prediction.get("rise_prediction_input"), dict) else {}
    rise_input["primary_selection"] = dict(selection)
    rise_input["prediction_used_as_gate"] = True
    rise_input["candidate_preserved"] = True

    if selection.get("structure_allowed") is not True:
        structure = {
            "schema": "prediction_primary_structure_not_built",
            "state": "NOT_BUILT_PREDICTION_FIRST",
            "reason": selection.get("reason"),
            "frame_counts": counts,
            "completed_candles_only": True,
        }
        combiner = _combine_prediction_structure(selection, structure)
        base.update({
            "state": combiner["state"], "decision_key": None, "plan_key": None,
            "material_diagnosis": {"state": combiner["state"], "owner": "strategy_v2_core.rise_prediction_primary", "missing": [], "candidate_quality_failed": False},
            "structure": structure, "prediction": prediction, "prediction_selection": selection, "decision_combiner": combiner,
            "execution_policy": {
                "schema": "combined_v2_execution_policy_v2149", "actual_price_required": True,
                "fresh_spread_slippage_required": True, "after_cost_reward_must_be_positive": True,
                "entry_must_remain_in_first_half_to_t1": True, "fixed_legacy_rr_room_chase_thresholds_used": False,
                "prediction_recomputed_in_paper": False, "decision_combiner_active": True,
                "prediction_calculated_in_strategy": True, "prediction_used_in_strategy": True,
            },
        })
        return base

    if missing:
        structure = {"state": "DATA_MISSING", "frame_counts": counts, "completed_candles_only": True}
        combiner = _combine_prediction_structure(selection, structure)
        base.update({
            "state": "DATA_MISSING", "decision_key": None, "plan_key": None,
            "material_diagnosis": {"state": "DATA_MISSING", "owner": "candle_worker" if "current_price" not in missing else "feature_worker", "missing": sorted(set(missing)), "candidate_quality_failed": False},
            "structure": structure,
            "prediction": prediction,
            "prediction_selection": selection,
            "decision_combiner": combiner,
        })
        return base

    m5, m15, m30, h1, h2, h4 = (frames[tf] for tf in ("m5", "m15", "m30", "h1", "h2", "h4"))
    atr5, atr15, atr30, atr1h, atr2h, atr4h = (_atr(x) for x in (m5, m15, m30, h1, h2, h4))
    major_axes = [x for x in (_trend_axis(h4), _trend_axis(h2)) if x is not None]
    setup_axes = [x for x in (_trend_axis(h1), _trend_axis(m30)) if x is not None]
    major_axis = sum(major_axes) / len(major_axes) if major_axes else 0.0
    setup_axis = sum(setup_axes) / len(setup_axes) if setup_axes else 0.0

    entry_levels = _level_candidates(frames, ("m5", "m15"), "resistance")
    entry_clusters = _cluster_levels(entry_levels, atr_ref=max(atr5, atr15 * 0.6), current=current)
    setup_levels = _level_candidates(frames, ("m30", "h1"), "support")
    support_clusters = _cluster_levels(setup_levels, atr_ref=max(atr30, atr1h * 0.55), current=current)
    target_levels = _level_candidates(frames, ("h2", "h4"), "resistance")
    target_clusters = _cluster_levels(target_levels, atr_ref=max(atr2h, atr4h * 0.55), current=current)

    # v2159 Trigger correctness repair.
    # - A resistance is a zone, so breakout ownership is the zone HIGH, never the center.
    # - A completed breakout remains valid for up to three completed 5m bars while closes hold above it.
    # - Among equally near zones (same clustering tolerance), prefer the better confirmed/recent zone.
    recent_rows = m5[-6:]
    recent_closes = [float(r["c"]) for r in recent_rows]
    recent_lows = [float(r["l"]) for r in recent_rows]
    # v2166: the 5m close remains the primary confirmation, but completed 1m/3m
    # candles may confirm the same already-built WAIT_TRIGGER contract earlier.
    # Forming candles are still excluded by the candle owner.
    m1 = list(frames.get("m1") or [])
    m3 = list(frames.get("m3") or [])
    short_frames_ready_v2166 = bool(len(m1) >= 3 or len(m3) >= 2)
    trigger_obj: Optional[Dict[str, Any]] = None
    trigger_state = "WAIT_TRIGGER"
    trigger_event_ts: Optional[float] = None
    trigger_mode = "WAIT_BREAK"
    trigger_break_index: Optional[int] = None
    trigger_selection_policy = "ZONE_HIGH_RECENT_HOLD_QUALITY_WITHIN_NEAREST_CLUSTER_BAND_V2159"

    def zone_line(zone: Dict[str, Any]) -> float:
        return float(zone.get("high") or zone.get("price") or 0.0)

    def zone_quality(zone: Dict[str, Any]) -> Tuple[float, float, float, float]:
        return (
            float(len(zone.get("timeframes") or [])),
            float(zone.get("source_count") or 0),
            float(zone.get("score") or 0.0),
            float(zone.get("last_source_ts") or 0.0),
        )

    fired: List[Tuple[float, Tuple[float, float, float, float], Dict[str, Any], str, int]] = []
    for zone in entry_clusters:
        level = zone_line(zone)
        if level <= 0 or len(recent_closes) < 2:
            continue
        break_idx: Optional[int] = None
        # Only the last three completed bars can own a still-valid breakout.
        first_idx = max(1, len(recent_closes) - 4)
        for idx in range(first_idx, len(recent_closes)):
            if recent_closes[idx - 1] <= level < recent_closes[idx]:
                break_idx = idx
        crossed_now = break_idx == len(recent_closes) - 1
        held_after_break = break_idx is not None and all(c > level for c in recent_closes[break_idx:])
        retested_now = (
            any(c > level for c in recent_closes[-5:-1])
            and recent_lows[-1] <= level + max(atr5 * 0.18, current * 0.0008)
            and recent_closes[-1] > level
        )
        early_mode = None
        early_event_ts = None
        early_tolerance = max(atr5 * 0.10, current * 0.0005)
        if len(m1) >= 3:
            c0, c1, c2 = (float(m1[-3]["c"]), float(m1[-2]["c"]), float(m1[-1]["c"]))
            l1, l2 = float(m1[-2]["l"]), float(m1[-1]["l"])
            if c0 <= level < c1 and c2 > level and min(l1, l2) >= level - early_tolerance:
                early_mode = "EARLY_M1_DOUBLE_HOLD"
                early_event_ts = float(m1[-2]["ts"])
        if early_mode is None and len(m3) >= 2:
            c0, c1 = float(m3[-2]["c"]), float(m3[-1]["c"])
            l1 = float(m3[-1]["l"])
            if c0 <= level < c1 and l1 >= level - early_tolerance:
                early_mode = "EARLY_M3_BREAK_HOLD"
                early_event_ts = float(m3[-1]["ts"])
        if crossed_now:
            mode = "COMPLETED_BREAK"
            event_idx = len(recent_closes) - 1
        elif retested_now:
            mode = "COMPLETED_RETEST_HOLD"
            event_idx = len(recent_closes) - 1
        elif held_after_break:
            mode = "COMPLETED_BREAK_HOLD"
            event_idx = int(break_idx)
        elif early_mode is not None and early_event_ts is not None:
            mode = early_mode
            event_idx = -1
        else:
            continue
        event_ts = float(early_event_ts if mode.startswith("EARLY_") else recent_rows[event_idx]["ts"])
        fired.append((event_ts, zone_quality(zone), zone, mode, event_idx))

    if fired:
        fired.sort(key=lambda item: (item[0], item[1]), reverse=True)
        trigger_event_ts, _, trigger_obj, trigger_mode, trigger_break_index = fired[0]
        trigger_state = "TRIGGER_FIRED"
    else:
        above = [z for z in entry_clusters if zone_line(z) >= current * 0.999]
        if above:
            nearest = min(zone_line(z) for z in above)
            selection_band = max(max(atr5, atr15 * 0.6) * 0.22, current * 0.0012)
            near_band = [z for z in above if zone_line(z) <= nearest + selection_band]
            trigger_obj = max(near_band, key=lambda z: (zone_quality(z), -abs(zone_line(z) - current)))
            trigger_state = "WAIT_TRIGGER"
        else:
            below = [z for z in entry_clusters if zone_line(z) < current]
            if below:
                trigger_obj = max(below, key=lambda z: zone_line(z))
                trigger_state = "TRIGGER_PASSED"
                trigger_mode = "OLD_LEVEL_ALREADY_CONSUMED"
    if trigger_obj is None:
        base.update({
            "state": "NO_TRIGGER_STRUCTURE", "decision_key": None, "plan_key": None,
            "material_diagnosis": {"state": "NO_TRIGGER_STRUCTURE", "owner": "strategy_v2_core_v2161", "candidate_quality_failed": False},
            "structure": {"state": "NO_TRIGGER_STRUCTURE", "frame_counts": counts, "major_trend_axis": major_axis, "setup_trend_axis": setup_axis},
        })
        base["prediction"] = prediction
        base["prediction_selection"] = selection
        base["decision_combiner"] = _combine_prediction_structure(selection, base["structure"])
        return base

    trigger = float(trigger_obj.get("high") or trigger_obj["price"])
    support_candidates = [z for z in support_clusters if float(z["high"]) < trigger and (int(z.get("source_count") or 0) >= 2 or "h1" in (z.get("timeframes") or []))]
    support = max(support_candidates, key=lambda z: float(z["price"]), default=None)
    if support is None:
        structure = {"state": "NO_INVALID_STRUCTURE", "trigger": trigger, "trigger_state": trigger_state, "frame_counts": counts, "major_trend_axis": major_axis, "setup_trend_axis": setup_axis}
        base.update({"state": "NO_INVALID_STRUCTURE", "decision_key": None, "plan_key": None, "material_diagnosis": {"state": "NO_INVALID_STRUCTURE", "owner": "strategy_v2_core_v2161", "candidate_quality_failed": False}, "structure": structure})
        base["prediction"] = prediction
        base["prediction_selection"] = selection
        base["decision_combiner"] = _combine_prediction_structure(selection, structure)
        return base

    invalid_buffer = max(atr30 * 0.22, atr1h * 0.10, trigger * 0.0008)
    invalid = float(support["low"]) - invalid_buffer
    target_floor = max(trigger, current)
    targets = [z for z in target_clusters if float(z["low"]) > target_floor * 1.00001]
    if not targets:
        structure = {"state": "NO_REACHABLE_T1", "trigger": trigger, "execution_invalid": invalid, "trigger_state": trigger_state, "frame_counts": counts, "major_trend_axis": major_axis, "setup_trend_axis": setup_axis}
        base.update({"state": "NO_REACHABLE_T1", "decision_key": None, "plan_key": None, "material_diagnosis": {"state": "NO_REACHABLE_T1", "owner": "strategy_v2_core_v2161", "candidate_quality_failed": False}, "structure": structure})
        base["prediction"] = prediction
        base["prediction_selection"] = selection
        base["decision_combiner"] = _combine_prediction_structure(selection, structure)
        return base
    targets.sort(key=lambda z: float(z["low"]))
    t1 = float(targets[0]["low"])
    t2 = float(targets[1]["low"]) if len(targets) > 1 else None
    reference = current if trigger_state == "TRIGGER_FIRED" else trigger
    if not (invalid < reference < t1):
        structure_state = "PRICE_ORDER_INVALID"
    elif trigger_state == "WAIT_TRIGGER":
        structure_state = "WAIT_TRIGGER"
    elif trigger_state == "TRIGGER_PASSED":
        structure_state = "TRIGGER_PASSED"
    else:
        structure_state = "STRUCTURE_READY"

    risk_pct = (reference - invalid) / reference * 100.0
    room_pct = (t1 - reference) / reference * 100.0
    rr = room_pct / risk_pct if risk_pct > 0 else None
    fraction = max(0.0, (current - trigger) / max(t1 - trigger, 1e-12))
    # v2166 candidate-quality axis: after early detection is enabled, a remaining
    # non-retest entry that already consumed a large part of T1 and arrived after
    # an outsized 15m/30m run is held for a retest instead of chased.
    change_15m = _num(row.get("change_15m"), 0.0) or 0.0
    change_30m = _num(row.get("change_30m"), 0.0) or 0.0
    pre_entry_run_pct_v2166 = max(change_15m, change_30m)
    atr15_pct_v2166 = (atr15 / current * 100.0) if current > 0 else 0.0
    late_run_limit_v2166 = max(2.0, atr15_pct_v2166 * 2.4)
    entry_timing_wait_v2166 = bool(
        trigger_state == "TRIGGER_FIRED"
        and trigger_mode not in {"COMPLETED_RETEST_HOLD"}
        and fraction >= 0.32
        and pre_entry_run_pct_v2166 >= late_run_limit_v2166
    )
    if entry_timing_wait_v2166:
        structure_state = "ENTRY_TIMING_WAIT"
    vol_now = sum(float(r.get("v") or 0.0) for r in m5[-3:]) / 3.0
    vol_base = _median([float(r.get("v") or 0.0) for r in m5[-30:-3]], default=0.0)
    volume_axis = _clip(math.log(max(vol_now, 1e-12) / max(vol_base, 1e-12)) / 1.2, -1.0, 1.0) if vol_base > 0 else 0.0
    trigger_quality = (
        0.75 if trigger_state == "TRIGGER_FIRED" and trigger_mode == "COMPLETED_RETEST_HOLD"
        else 0.62 if trigger_state == "TRIGGER_FIRED" and trigger_mode == "EARLY_M1_DOUBLE_HOLD"
        else 0.58 if trigger_state == "TRIGGER_FIRED" and trigger_mode == "EARLY_M3_BREAK_HOLD"
        else 0.60 if trigger_state == "TRIGGER_FIRED" and trigger_mode == "COMPLETED_BREAK_HOLD"
        else 0.45 if trigger_state == "TRIGGER_FIRED"
        else -0.15 if trigger_state == "WAIT_TRIGGER"
        else -0.65
    )
    last_bar=m5[-1];bar_range=max(float(last_bar["h"])-float(last_bar["l"]),1e-12)
    breakout_body_pct=abs(float(last_bar["c"])-float(last_bar["o"]))/bar_range*100.0
    breakout_upper_wick_pct=(float(last_bar["h"])-max(float(last_bar["o"]),float(last_bar["c"])))/bar_range*100.0
    breakout_close_position_pct=(float(last_bar["c"])-float(last_bar["l"]))/bar_range*100.0
    trigger_hold_above_pct=(float(last_bar["c"])-trigger)/trigger*100.0 if trigger>0 else None
    atr_pct={"m5":atr5/current*100.0,"m15":atr15/current*100.0,"m30":atr30/current*100.0,"h1":atr1h/current*100.0,"h2":atr2h/current*100.0,"h4":atr4h/current*100.0}
    tr_now=_median([float(r["h"])-float(r["l"]) for r in m5[-5:]],default=0.0)
    tr_base=_median([float(r["h"])-float(r["l"]) for r in m5[-30:-5]],default=0.0)
    short_atr_expansion_ratio=(tr_now/tr_base) if tr_base>0 else None
    invalid_noise_ref=max(atr_pct["m30"],atr_pct["h1"]*0.55,0.000001)
    target_atr_ref=max(atr_pct["h2"],atr_pct["h4"]*0.55,0.000001)
    invalid_noise_multiple=risk_pct/invalid_noise_ref if invalid_noise_ref>0 else None
    target_atr_multiple=room_pct/target_atr_ref if target_atr_ref>0 else None
    plan_seed = {
        "ticker": ticker, "trigger": round(trigger, 12), "invalid": round(invalid, 12), "t1": round(t1, 12),
        "t2": round(t2, 12) if t2 else None, "trigger_state": trigger_state,
        "trigger_event_ts": trigger_event_ts, "h4_ts": float(h4[-1]["ts"]), "m5_ts": float(m5[-1]["ts"]),
    }
    plan_key = "v2149-plan:" + _plan_hash(plan_seed)
    structure = {
        "schema": "combined_v2_structure_v2149", "state": structure_state, "reference_entry": round(reference, 12),
        "current_price": round(current, 12), "trigger": round(trigger, 12), "trigger_state": trigger_state,
        "trigger_mode": trigger_mode, "trigger_event_ts": trigger_event_ts,
        "trigger_selection_policy_v2159": trigger_selection_policy,
        "trigger_breakout_line_source_v2159": "entry_zone_high",
        "trigger_valid_hold_bars_v2159": 3,
        "trigger_early_completed_frames_v2166": ["m1", "m3"],
        "trigger_short_frames_ready_v2166": short_frames_ready_v2166,
        "pretrigger_contract_ready_v2166": True,
        "entry_timing_wait_v2166": entry_timing_wait_v2166,
        "pre_entry_run_pct_v2166": round(pre_entry_run_pct_v2166, 6),
        "late_run_limit_pct_v2166": round(late_run_limit_v2166, 6),
        "trigger_break_index_v2159": trigger_break_index,
        "trigger_zone_score_v2159": round(float(trigger_obj.get("score") or 0.0), 6),
        "trigger_zone_source_count_v2159": int(trigger_obj.get("source_count") or 0),
        "trigger_zone_timeframes_v2159": list(trigger_obj.get("timeframes") or []),
        "entry_zone_low": round(float(trigger_obj["low"]), 12), "entry_zone_high": round(float(trigger_obj["high"]), 12),
        "execution_invalid": round(invalid, 12), "structural_support": round(float(support["price"]), 12),
        "target_t1": round(t1, 12), "target_t2": round(t2, 12) if t2 else None,
        "risk_pct": round(risk_pct, 6), "t1_room_pct": round(room_pct, 6), "rr_t1": round(rr, 6) if rr is not None else None,
        "entry_fraction_to_t1": round(fraction, 6),
        "target_path_consumed_ratio": round(fraction, 6),
        "target_path_owner": "strategy_v2_core.structure",
        "target_path_stage": "POST_PREDICTION_STRUCTURE",
        "target_path_used_by_primary_prediction": False,
        "major_trend_axis": round(major_axis, 6),
        "setup_trend_axis": round(setup_axis, 6), "trigger_quality_axis": round(trigger_quality, 6),
        "volume_expansion_axis": round(volume_axis, 6), "frame_counts": counts,
        "breakout_body_pct":round(breakout_body_pct,6),"breakout_upper_wick_pct":round(breakout_upper_wick_pct,6),
        "breakout_close_position_pct":round(breakout_close_position_pct,6),"trigger_hold_above_pct":round(trigger_hold_above_pct,6) if trigger_hold_above_pct is not None else None,
        "trigger_age_sec":round(max(0.0,ts-trigger_event_ts),3) if trigger_event_ts else None,"atr_pct_v2155":{k:round(v,6) for k,v in atr_pct.items()},
        "short_atr_expansion_ratio":round(short_atr_expansion_ratio,6) if short_atr_expansion_ratio is not None else None,
        "invalid_noise_multiple":round(invalid_noise_multiple,6) if invalid_noise_multiple is not None else None,
        "target_atr_multiple":round(target_atr_multiple,6) if target_atr_multiple is not None else None,
        "completed_candles_only": True, "forming_candle_excluded": True,
        "timeframe_contract": {"major": "4h/2h", "setup": "1h/30m", "trigger": "15m/5m", "execution": "1m/quote"},
        "source": "strategy_v2_core_v2168_only", "legacy_structure_used": False,
    }
    post_structure_observation = {
        "target_path_consumed_ratio": structure.get("target_path_consumed_ratio"),
        "owner": structure.get("target_path_owner"),
        "stage": structure.get("target_path_stage"),
        "used_by_primary_prediction": False,
        "structure_state": structure.get("state"),
    }
    prediction["post_structure_observation"] = post_structure_observation
    rise_payload = prediction.get("rise_prediction_input") if isinstance(prediction.get("rise_prediction_input"), dict) else {}
    rise_payload["post_structure_observation"] = post_structure_observation
    combiner = _combine_prediction_structure(selection, structure)
    state = str(combiner.get("state") or "ENGINE_ERROR")
    decision_key = None
    if state == "ENTRY_READY" and trigger_event_ts:
        decision_key = f"v2149:{ticker}:{plan_key.split(':')[-1]}:{int(trigger_event_ts * 1000)}"
    base.update({
        "state": state, "decision_key": decision_key, "plan_key": plan_key,
        "material_diagnosis": {"state": "READY" if state in {"ENTRY_READY", "WAIT_TRIGGER", "TRIGGER_PASSED", "ENTRY_TIMING_WAIT"} else state, "owner": str(combiner.get("owner") or "strategy_v2_core.structure"), "candidate_quality_failed": False, "missing": []},
        "structure": structure, "prediction": prediction, "prediction_selection": selection, "decision_combiner": combiner,
        "execution_policy": {
            "schema": "combined_v2_execution_policy_v2149", "actual_price_required": True,
            "fresh_spread_slippage_required": True, "after_cost_reward_must_be_positive": True,
            "entry_must_remain_in_first_half_to_t1": True, "fixed_legacy_rr_room_chase_thresholds_used": False,
            "prediction_recomputed_in_paper": False, "decision_combiner_active": True,
            "prediction_calculated_in_strategy": True, "prediction_used_in_strategy": True,
        },
    })
    return base



def compact_combined_v2_contract(value: Any) -> Dict[str, Any]:
    if not isinstance(value, dict):
        return {}
    structure = value.get("structure") if isinstance(value.get("structure"), dict) else {}
    prediction = value.get("prediction") if isinstance(value.get("prediction"), dict) else {}
    combiner = value.get("decision_combiner") if isinstance(value.get("decision_combiner"), dict) else {}
    rise_input = prediction.get("rise_prediction_input") if isinstance(prediction.get("rise_prediction_input"), dict) else {}
    structure_keys = (
        "state", "reference_entry", "current_price", "trigger", "trigger_state", "trigger_mode", "trigger_event_ts",
        "entry_zone_low", "entry_zone_high", "execution_invalid", "structural_support", "target_t1", "target_t2",
        "risk_pct", "t1_room_pct", "rr_t1", "entry_fraction_to_t1", "target_path_consumed_ratio", "target_path_owner", "target_path_stage", "target_path_used_by_primary_prediction", "major_trend_axis", "setup_trend_axis",
        "trigger_quality_axis", "volume_expansion_axis", "frame_counts", "completed_candles_only", "forming_candle_excluded",
        "timeframe_contract", "source", "legacy_structure_used", "entry_timing_wait_v2166", "pre_entry_run_pct_v2166",
        "late_run_limit_pct_v2166", "trigger_selection_policy_v2159", "trigger_breakout_line_source_v2159",
        "trigger_valid_hold_bars_v2159", "trigger_break_index_v2159", "trigger_zone_score_v2159",
        "trigger_zone_source_count_v2159", "trigger_zone_timeframes_v2159",
    )
    compact_input = {
        "schema": rise_input.get("schema"),
        "state": rise_input.get("state"),
        "owner": rise_input.get("owner"),
        "ticker": rise_input.get("ticker"),
        "event_key": rise_input.get("event_key"),
        "event_bar_close_ts": rise_input.get("event_bar_close_ts"),
        "event_price": rise_input.get("event_price"),
        "episode_id": rise_input.get("episode_id"),
        "episode_low_ts": rise_input.get("episode_low_ts"),
        "episode_low_price": rise_input.get("episode_low_price"),
        "pre_signal_rise_pct": rise_input.get("pre_signal_rise_pct"),
        "signal_position": rise_input.get("signal_position"),
        "price_volume_sequence": rise_input.get("price_volume_sequence"),
        "explanation_tags": rise_input.get("explanation_tags"),
        "explanation_tag_labels_ko": rise_input.get("explanation_tag_labels_ko"),
        "explanation_tag_evidence": rise_input.get("explanation_tag_evidence"),
        "tag_overlap_allowed": True,
        "tag_used_as_gate": False,
        "materials": rise_input.get("materials"),
        "material_values": rise_input.get("material_values"),
        "material_names": rise_input.get("material_names"),
        "prediction_material_count": rise_input.get("prediction_material_count"),
        "post_structure_material_names": rise_input.get("post_structure_material_names"),
        "target_path_stage": rise_input.get("target_path_stage"),
        "post_structure_observation": rise_input.get("post_structure_observation"),
        "source_state_counts": rise_input.get("source_state_counts"),
        "input_coverage_pct": rise_input.get("input_coverage_pct"),
        "probability_3h": rise_input.get("probability_3h"),
        "probability_6h": rise_input.get("probability_6h"),
        "giveback_risk": rise_input.get("giveback_risk"),
        "late_capture_risk": rise_input.get("late_capture_risk"),
        "predicted_direction_3h": rise_input.get("predicted_direction_3h"),
        "predicted_direction_6h": rise_input.get("predicted_direction_6h"),
        "output_states": rise_input.get("output_states") or {},
        "model_state": rise_input.get("model_state"),
        "prediction_model_id": rise_input.get("prediction_model_id"),
        "prediction_model_generated_ts": rise_input.get("prediction_model_generated_ts"),
        "prediction_confidence_pct": rise_input.get("prediction_confidence_pct"),
        "prediction_confidence_state": rise_input.get("prediction_confidence_state"),
        "prediction_evidence_count": rise_input.get("prediction_evidence_count"),
        "usable_input_count": rise_input.get("usable_input_count"),
        "usable_input_coverage_pct": rise_input.get("usable_input_coverage_pct"),
        "weights_applied": False,
        "thresholds_applied": False,
        "prediction_used_as_gate": True,
        "zero_fill_used": False,
        "auto_buy": False,
    }
    return {
        "schema": "combined_v2_trade_contract_compact",
        "version": value.get("version"),
        "build": value.get("build"),
        "generation": value.get("generation"),
        "prediction_model_generation": value.get("prediction_model_generation"),
        "state": value.get("state"),
        "ticker": value.get("ticker"),
        "evaluated_ts": value.get("evaluated_ts"),
        "decision_key": value.get("decision_key"),
        "plan_key": value.get("plan_key"),
        "material_diagnosis": value.get("material_diagnosis"),
        "structure": {key: structure.get(key) for key in structure_keys},
        "prediction_selection": value.get("prediction_selection") if isinstance(value.get("prediction_selection"), dict) else (prediction.get("primary_selection") if isinstance(prediction.get("primary_selection"), dict) else {}),
        "prediction": {
            "schema": prediction.get("schema"),
            "state": prediction.get("state"),
            "prediction_model_generation": prediction.get("prediction_model_generation"),
            "rise_prediction_input": compact_input,
            "input_coverage_pct": prediction.get("input_coverage_pct"),
            "probability_3h": prediction.get("probability_3h"),
            "probability_6h": prediction.get("probability_6h"),
            "giveback_risk": prediction.get("giveback_risk"),
            "late_capture_risk": prediction.get("late_capture_risk"),
            "prediction_model_id": prediction.get("prediction_model_id"),
            "prediction_confidence_pct": prediction.get("prediction_confidence_pct"),
            "prediction_confidence_state": prediction.get("prediction_confidence_state"),
            "weights_applied": False,
            "thresholds_applied": False,
            "prediction_used_in_final_decision": True,
            "decision_reason": prediction.get("decision_reason"),
            "candidate_preserved": True,
            "prediction_first": True,
            "auto_buy": False,
        },
        "prediction_evidence": {
            "rise_prediction_input": compact_input,
            "materials": compact_input.get("materials"),
            "material_values": compact_input.get("material_values"),
            "source_state_counts": compact_input.get("source_state_counts"),
            "input_coverage_pct": compact_input.get("input_coverage_pct"),
            "zero_fill_used": False,
        },
        "decision_combiner": {
            "state": combiner.get("state"),
            "entry_eligible": combiner.get("entry_eligible"),
            "owner": combiner.get("owner"),
            "reason": combiner.get("reason"),
            "structure_state": combiner.get("structure_state"),
            "prediction_state": combiner.get("prediction_state"),
            "prediction_used_as_gate": True,
            "candidate_preserved": True,
        },
        "execution_policy": value.get("execution_policy"),
        "prediction_gate_active": True,
        "candidate_preserved": True,
        "auto_buy": False,
    }


def prediction_contract_identity(role_contract_hash: Optional[str] = None) -> Dict[str, Any]:
    payload = {
        "schema": "rise_prediction_material_contract",
        "model_generation": PREDICTION_MODEL_GENERATION,
        "material_names": list(RISE_MATERIAL_NAMES),
        "weights_applied": False,
        "thresholds_applied": False,
        "prediction_used_as_gate": True,
    }
    digest = hashlib.sha256(json.dumps(payload, ensure_ascii=False, sort_keys=True, separators=(",", ":")).encode("utf-8")).hexdigest()
    return {**payload, "contract_hash": digest, "ready": True, "auto_buy": False}

