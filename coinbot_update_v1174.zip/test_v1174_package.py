import hashlib,json,py_compile,sys,tempfile
from pathlib import Path
root=Path(sys.argv[1] if len(sys.argv)>1 else '.').resolve()
manifest=json.loads((root/'DEPLOY_BUNDLE.json').read_text(encoding='utf-8'))
assert manifest['version']=='v1174'
assert manifest['paper']=='paper_bot_v1.041.py'
assert manifest['workers']=={}
assert manifest['auto_buy'] is False
src=root/manifest['paper']
actual=hashlib.sha256(src.read_bytes()).hexdigest()
assert actual==manifest['source_sha256'][src.name]

with tempfile.TemporaryDirectory() as td:
    py_compile.compile(str(src),cfile=str(Path(td)/'paper_bot_v1.041.pyc'),doraise=True)
for forbidden in ('paper_bot_open.json','paper_bot_closed.jsonl','paper_decision_state_v926.json','trade_log.jsonl'):
    assert not (root/forbidden).exists()
print('PASS v1174 package directory')
