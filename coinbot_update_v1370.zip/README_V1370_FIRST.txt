v1370 is Guard-only. It forces Guard to reload canonical_spine_v1190.py so /flow_map_full uses the old-base runtime evidence reader. Strategy/Paper/Main trading logic is unchanged.
