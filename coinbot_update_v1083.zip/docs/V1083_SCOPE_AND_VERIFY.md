# v1083 Paper live memory owner probe

## Scope

Measurement only. No strategy, entry, exit, OPEN limit, ledger, or auto-buy change.

The probe starts before `main()` so startup `write_status()` allocations are captured. It then profiles three normal Paper cycles and disables itself.

Measured owner paths:

- `status_candidate_rows_reload`: `_v582_active_rows()` invoked again inside `write_status()`
- `decision_state_full_load_and_record_copy`: `_v926_load_decision_state()`
- `decision_state_full_json_digest`: `_v1017_decision_material_signature()` / `_paper_json_digest(records)`
- `candidate_select_total`
- `preopen_review_total`
- `performance_writer_total`
- `status_writer_total`
- `run_cycle_total`

Evidence:

- process RSS/anonymous memory sampled every 20 ms
- tracemalloc current and per-call transient peak
- before/after RSS for every owner call
- actual input file sizes
- bounded deep size of persistent Paper globals
- top live allocation lines after three cycles

## Verify

Run `/gpaper_memory_owner_v1083 180` after deployment. A DONE result requires:

- Paper v1.005 active/target hash match
- three cycles completed
- phase evidence present
- exact 0/0/0
- auto-buy OFF

The command identifies the primary and secondary memory owner. It does not perform a fix.
