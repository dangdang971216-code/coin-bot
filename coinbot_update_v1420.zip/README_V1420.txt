v1420 Strategy-only S1 blocker audit + shadow unlock. 실제 Paper 진입/전략수치 변경 없음. 자동매수 OFF.
