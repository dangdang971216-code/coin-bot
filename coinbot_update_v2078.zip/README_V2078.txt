v2078: existing shadow easy readout and loss audit field/epoch repair. No strategy change. Auto-buy OFF.
