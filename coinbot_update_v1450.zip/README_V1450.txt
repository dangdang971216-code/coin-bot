v1450: Paper v1449 fast-index load-order hotfix. Auto-buy OFF. No trading-rule change.
