coinbot_update_v1405
- guard ACK + wide disk cleanup
- auto-buy OFF
- no strategy rule changes
