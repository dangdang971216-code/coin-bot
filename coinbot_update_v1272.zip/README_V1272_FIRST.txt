v1272 적용 후 먼저 /gstorage_prune_3d 실행. 그 다음 /gdeploy /grelease_verify /gdeep_audit /gledger_v1272 확인.
