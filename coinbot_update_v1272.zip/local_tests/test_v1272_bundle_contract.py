import json
from pathlib import Path
b=json.loads(Path('DEPLOY_BUNDLE.json').read_text(encoding='utf-8'))
assert b['release']=='v1272'
assert b['runtime_files']['guard']=='backga_guard_bot_v2_5_250.py'
assert b['auto_buy'] is False
for k in ['trigger_changed','invalid_selection_changed','target_selection_changed','rr_threshold_changed','historical_trade_ledgers_rewritten']:
    assert b[k] is False
assert '/gstorage_prune_3d' in b['operator_after_apply_commands']
