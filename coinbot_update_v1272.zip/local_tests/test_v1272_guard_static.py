from pathlib import Path
p=Path('backga_guard_bot_v2_5_250.py')
s=p.read_text(encoding='utf-8')
assert 'guard_v2.5.250_v1272_storage_retention_prune_3d_2026-07-06' in s
assert 'def gstorage_prune_3d_text' in s
assert 'def v1272_storage_prune_3d' in s
assert '/gstorage_prune_3d' in s
assert 'def gledger_v1272_text' in s
assert 'OPEN/CLOSED/trade_log/decision/exact/change/issue/good-S2' in s
assert 'v1270 보호 기준 변경 없음' in s
