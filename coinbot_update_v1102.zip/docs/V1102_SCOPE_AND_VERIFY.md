# v1102 범위와 검수

## 목적

흩어진 `/system_map`, `/ops_focus`, `/resource_map`, `/ledger_map`을 평소마다 각각 확인하지 않도록, Guard가 수집한 증거를 하나의 canonical flow snapshot으로 봉인하고 Main `/flow_map`에서 중요한 상태만 보여준다.

동시에 v1101에서 드러난 Paper 진입 퍼널의 미분류를 제거한다. 모든 S1 후보는 선택, 안전차단, TTL/실행자료 차단, 재진입 차단, 중복, 한도, 오류 중 정확히 하나의 terminal outcome으로 기록된다.

## 전체 흐름

1. 거래소·WS·Micro·Orderflow
2. Scanner
3. Feature
4. Candle
5. Market
6. Orderflow 실행비용
7. Target Router
8. Strategy 자료합류·구조판정
9. 품질 Gate·Rank
10. S1 Hold
11. Paper TTL·실행자료
12. Paper 최종안전·재진입
13. Selector
14. OPEN Writer·Decision Commit
15. 보유·Exit Monitor
16. CLOSED·Decision Commit
17. Canonical Performance
18. Review·Structure Lab
19. Main·Telegram
20. Guard single map writer

각 단계는 상태, 입력·출력·차단·보류·오류, 처리시간, source age, owner를 기록한다. 후보 단계의 계약은 `입력 = 통과 + 차단 + 보류 + 오류`다.

## `/flow_map` 기본 화면

- 현재 중요 오류와 막힌 위치/이유
- 전체 후보·진입 흐름
- 품질/Paper 차단 사유 TOP
- worker별 주요 병목과 phase
- CPU/RSS/디스크/RAM
- runtime DOWN/CHECK/PID·hash·version mismatch
- 장부 다중 writer, owner 정보없음, 증가 TOP
- 지도 커버리지와 정보없음 건수

세부 기존 명령은 진단이 필요할 때만 사용한다. `/flow_map` 값은 독립 재계산하지 않고 Guard canonical snapshot만 읽는다.

## 변경하지 않은 계약

- 품질 threshold
- actual-entry RR, target room, chase, spread, slippage 기준
- OPEN 30 / cycle 3
- trigger / invalid / target
- 청산계약
- OPEN/CLOSED/decision/exact 원장 형식
- 자동매수 OFF

## 최소 서버 검수

1. `/gupgrade_bundle` 단독 실행
2. Guard `/gops_refresh`
3. Main `/flow_map`

`/gops_refresh`는 v1102 flow coverage와 Paper accounting을 issue/change 원장에 append-only로 기록한다.
