코인봇 v925 시작점
- 서버 적용: coinbot_update_v925.zip
- 전체 최신 코드: v925 ACTIVE FULL FINAL ZIP
- 상태: 로컬 검수 완료 / 실서버 검수 전
- 먼저 읽기: docs/코인봇_인수인계_v925_FINAL_코드완료_서버검수전_20260617.txt
- 적용 명령: /gupgrade_bundle coinbot_update_v925.zip
- 자동매수: OFF
