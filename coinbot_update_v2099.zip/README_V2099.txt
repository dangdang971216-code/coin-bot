코인봇 v2099 · 넓은 구조 invalid·MFE0 대손실 방어감사판

목적
- MLK처럼 구조 invalid가 10% 이상 멀고 MFE가 0인데도 -10%대까지 가는 거래를 막을 방법을 찾는다.
- 구조선을 전부 1~2%로 좁히지 않고, 넓은 invalid 앞에 별도 중간 안전막을 둘 근거를 찾는다.
- 대수익 거래의 MAE를 함께 비교해 손실막이 대수익을 얼마나 자를지도 동시에 확인한다.
- 기존 1h·3h·6h 생존 Shadow를 재사용하며 새 Shadow·새 원장은 만들지 않는다.

/wide_invalid_audit
- invalid 거리 <2 / 2~4 / 4~6 / 6~10 / 10%+별 전체 exact 성과
- invalid 6%+ 거래의 MFE 0~0.05 / 0.05~0.30 / 0.30~1.50 / 1.50%+별 성과
- 넓은 invalid 대손실과 +5% 대수익의 진입 당시 RR·목표공간·spread·반응·상대강도·돈흐름 비교
- invalid 6%+와 10%+에서 -2.5 / -3 / -4% 절대막의 손실축소 상한과 수익·대수익 조기절단 위험
- 1h·3h·6h 동안 MFE가 거의 없었던 무반응 거래의 표본·손익
- 현재 OPEN 중 invalid 6% 이상 위험 종목 표시
- 기존 entry_survival Shadow의 1h·3h·6h 결과 연결

중요
- 최종손익·MAE 기반 절대막 비교는 첫 접촉 실제 quote·spread·slippage가 없는 상한 모델이다.
- final MFE가 낮고 보유시간이 길면 해당 시간까지 무반응이었다는 것은 확인되지만, 그 시점 정확한 손익은 별도 forward 자료가 필요하다.
- 구조 invalid·target·진입·청산·재진입은 아직 변경하지 않는다.

변경하지 않음
- Strategy 구조선·trigger·invalid·target
- Paper 진입·청산·수익보호·재진입
- 기존 OPEN 계약과 v2086/v2089
- OPEN/CLOSED/decision/exact 원장
- 새 Shadow·generation·원장
- 자동매수 OFF

판정
- 로컬 py_compile·AST·synthetic import/fixture PASS
- 서버 exact에서 invalid 10%+ 절대막별 대수익 훼손과 3h/6h 무반응 표본 확인 전 CHECK
