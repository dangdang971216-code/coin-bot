coinbot_update_v2108.zip

v2107 실패
- bot.py line 55642 nested f-string SyntaxError
- bundle py_compile 단계에서 중단되어 서버 미적용

v2108 수리
- 평균·MFE 표시값을 별도 변수로 먼저 계산
- 서버 Python 3.11 문법 기준 AST 검수
- v2107의 Paper 고점연동 안전막, Review 흔들림 Shadow, 빠른 entry 감사 기능은 그대로 유지
- 전략·청산 수치 추가 변경 없음
- 자동매수 OFF
