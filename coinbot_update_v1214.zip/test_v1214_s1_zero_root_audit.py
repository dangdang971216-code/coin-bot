import importlib.util
import json
import tempfile
import unittest
import sys
import types
from pathlib import Path

MODULE_PATH = Path(__file__).with_name('backga_guard_bot_v2_5_211.py')


def load_module():
    probe = types.ModuleType('runtime_phase_probe_v1190')
    probe.wrap_function = lambda *args, **kwargs: None
    sys.modules.setdefault('runtime_phase_probe_v1190', probe)
    spec = importlib.util.spec_from_file_location('guard_v1214_under_test', MODULE_PATH)
    module = importlib.util.module_from_spec(spec)
    assert spec.loader is not None
    spec.loader.exec_module(module)
    return module


def write_json(path: Path, obj):
    path.write_text(json.dumps(obj, ensure_ascii=False), encoding='utf-8')


def write_jsonl(path: Path, rows):
    with path.open('w', encoding='utf-8') as fh:
        for row in rows:
            fh.write(json.dumps(row, ensure_ascii=False, separators=(',', ':')) + '\n')


def structure_plan():
    return {
        'trigger': {'price': 101.0},
        'invalid': {'price': 95.0},
        'target': {'price': 115.0},
    }


class V1214S1ZeroAuditTest(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.mod = load_module()

    def configure(self, root: Path):
        self.mod.BOT_DIR = root

    def writer_status(self, rows: int, cycle: str):
        return {
            'result': 'OK',
            'rows_written': rows,
            'candidate_snapshot_scope': {
                'rows_written': rows,
                'pipeline_cycle_id_v1150': cycle,
                'commit_id': 'candidate-test-commit',
                'complete_snapshot': True,
                'state': 'NORMAL',
                'updated_ts': 123456.0,
            },
        }

    def gate_status(self, rows: int, s1: int, s2: int, s3: int, observation: int):
        return {
            'rows': rows,
            'pass_s1': s1,
            'recheck_s2': s2,
            'observe_s3': s3,
            'observation_only_blocked_v988': observation,
            'hard_reason_top': [],
            'updated_ts': 123456.0,
        }

    def observation_row(self, ticker: str, cycle: str):
        return {
            'ticker': ticker,
            's_stage': 'S3',
            'strategy_key': 'coin_quality_s3_observe',
            's3_observe_v732': True,
            'candidate_pipeline_cycle_id_v1150': cycle,
            'swing_trigger_price_v977': 101.0,
            'swing_invalid_price_v977': 95.0,
            'swing_target_price_v977': 115.0,
            'swing_entry_gate_v977': {
                'stage': 'S3',
                'hard_block_reasons': ['s3_observation_only_no_open'],
                'trigger_price': 101.0,
                'invalid_price': 95.0,
                'target_price': 115.0,
                'structure_plan': structure_plan(),
            },
        }

    def dynamic_missing_row(self, ticker: str, cycle: str):
        return {
            'ticker': ticker,
            's_stage': 'S3',
            'candidate_pipeline_cycle_id_v1150': cycle,
            'swing_entry_gate_v977': {
                'stage': 'S3',
                'hard_block_reasons': [
                    'dynamic_structure_source_missing',
                    'actual_structural_trigger_missing',
                    'actual_structural_invalid_missing',
                    'next_structural_target_missing',
                    'coherent_structure_plan_incomplete',
                ],
                'structure_plan': {},
            },
        }

    def test_mixed_severe_is_exactly_accounted(self):
        with tempfile.TemporaryDirectory() as td:
            root = Path(td)
            self.configure(root)
            cycle = 'strategy-test-cycle'
            rows = [
                self.observation_row('KRW-AAA', cycle),
                self.observation_row('KRW-BBB', cycle),
                self.dynamic_missing_row('KRW-CCC', cycle),
            ]
            write_jsonl(root / self.mod.S1_ZERO_AUDIT_CANDIDATES_V1214, rows)
            write_json(root / self.mod.S1_ZERO_AUDIT_GATE_STATUS_V1214, self.gate_status(3, 0, 0, 3, 2))
            write_json(root / self.mod.S1_ZERO_AUDIT_WRITER_STATUS_V1214, self.writer_status(3, cycle))

            report = self.mod.collect_s1_zero_root_audit_v1214()

            self.assertEqual(report['verdict'], 'PROVEN_MIXED_SEVERE')
            self.assertEqual(report['stage'], {'total': 3, 's1': 0, 's2': 0, 's3': 3, 'other': 0})
            self.assertEqual(report['root_counts']['s3_observation_only_no_open'], 2)
            self.assertEqual(report['root_counts']['dynamic_structure_source_missing'], 1)
            self.assertEqual(report['root_counts']['severe_rows'], 3)
            self.assertTrue(report['source']['same_cycle'])
            self.assertTrue(report['source']['same_rows'])
            self.assertTrue(report['source']['same_stage'])
            self.assertTrue((root / self.mod.S1_ZERO_AUDIT_STATUS_V1214).exists())
            self.assertFalse((root / 'paper_bot_open.json').exists())
            self.assertFalse((root / 'paper_bot_closed.jsonl').exists())

    def test_all_observation_only_is_proven(self):
        with tempfile.TemporaryDirectory() as td:
            root = Path(td)
            self.configure(root)
            cycle = 'strategy-all-observation'
            rows = [self.observation_row(f'KRW-{i}', cycle) for i in range(3)]
            write_jsonl(root / self.mod.S1_ZERO_AUDIT_CANDIDATES_V1214, rows)
            write_json(root / self.mod.S1_ZERO_AUDIT_GATE_STATUS_V1214, self.gate_status(3, 0, 0, 3, 3))
            write_json(root / self.mod.S1_ZERO_AUDIT_WRITER_STATUS_V1214, self.writer_status(3, cycle))

            report = self.mod.collect_s1_zero_root_audit_v1214()

            self.assertEqual(report['verdict'], 'PROVEN_OBSERVATION_ONLY_ALL')
            self.assertEqual(report['root_counts']['s3_observation_only_no_open'], 3)
            self.assertTrue(report['checks']['observation_count_consistent'])

    def test_cycle_mismatch_fails_closed(self):
        with tempfile.TemporaryDirectory() as td:
            root = Path(td)
            self.configure(root)
            rows = [self.observation_row('KRW-AAA', 'row-cycle')]
            write_jsonl(root / self.mod.S1_ZERO_AUDIT_CANDIDATES_V1214, rows)
            write_json(root / self.mod.S1_ZERO_AUDIT_GATE_STATUS_V1214, self.gate_status(1, 0, 0, 1, 1))
            write_json(root / self.mod.S1_ZERO_AUDIT_WRITER_STATUS_V1214, self.writer_status(1, 'different-cycle'))

            report = self.mod.collect_s1_zero_root_audit_v1214()

            self.assertEqual(report['verdict'], 'CHECK_SOURCE_MISMATCH')
            self.assertFalse(report['source']['same_cycle'])

    def test_command_and_policy_are_registered(self):
        source = MODULE_PATH.read_text(encoding='utf-8')
        self.assertIn('guard_v2.5.211_v1214_s1_zero_root_audit_2026-07-03', source)
        self.assertIn('/gs1_zero_audit', source)
        self.assertIn('read_only', source)
        self.assertIn('"strategy_changed": False', source)
        self.assertIn('"entry_exit_changed": False', source)
        self.assertIn('"auto_buy": False', source)


if __name__ == '__main__':
    unittest.main(verbosity=2)
