코인봇 v1214 S1 0 원인감사
===========================
상태: 로컬 PASS / 서버 원문 확인 전 CHECK
목적: 463개가 전부 S3가 된 원인을 실제 후보 row와 Strategy Gate 상태에서 정확히 집계
변경: Guard 읽기 전용 명령 /gs1_zero_audit 추가
미변경: Strategy, 후보 기준, ATR, RR, Trigger, Invalid, Target, Paper, OPEN/CLOSED, 청산계약
자동매수: OFF

중요
- 기존 /candidate_standard의 Trigger·Invalid·Target 누락 0은 S1 row만 본 값이다.
- S1이 0이면 그 0은 전체 463개 구조선 완전성을 증명하지 못한다.
- v1214는 원인 증명 전용이다. 실제 원인 수리는 서버 결과를 받은 다음 v1215에서 한다.
