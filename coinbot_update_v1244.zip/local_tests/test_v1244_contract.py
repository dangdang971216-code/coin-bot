#!/usr/bin/env python3
import ast, json
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
review=ROOT/'review_worker_v1.031.py'
tree=ast.parse(review.read_text(encoding='utf-8'))
funcs={n.name for n in tree.body if isinstance(n,(ast.FunctionDef,ast.AsyncFunctionDef))}
assert 'run_loop' in funcs
text=review.read_text(encoding='utf-8')
assert 'VERSION = "review_worker_v1.031"' in text
manifest=json.loads((ROOT/'DEPLOY_BUNDLE.json').read_text(encoding='utf-8'))
assert not manifest.get('guard')
assert 'guard' not in manifest.get('runtime_files',{})
assert manifest['main']=='coinbot_main_v2_13_1152.py'
assert manifest['paper']=='paper_bot_v1.072.py'
assert manifest['workers']['review']=='review_worker_v1.031.py'
for group in manifest['ledger_event_files'].values():
    for rel in group:
        for line in (ROOT/rel).read_text(encoding='utf-8').splitlines():
            if line.strip():
                obj=json.loads(line)
                assert obj.get('issue_id') or obj.get('change_id')
print('V1244_CONTRACT_PASS')
