#!/usr/bin/env python3
from __future__ import annotations

import importlib.util
import json
import os
import sys
import tempfile
from pathlib import Path

ROOT = Path(__file__).resolve().parent
sys.path.insert(0, str(ROOT))
BASE = Path(tempfile.mkdtemp(prefix="coinbot_v1185_test_"))
os.environ["COINBOT_BASE_DIR"] = str(BASE)
os.environ.pop("TELEGRAM_TOKEN", None)

(BASE / "ops_spine_snapshot_v1181.json").write_text(json.dumps({
    "snapshot_id": "ops-test", "overall_state": "NORMAL",
    "current_cycle": {"state": "NORMAL", "pipeline_cycle_id": "cy1", "candidate_commit_id": "cm1", "candidate_rows": 461, "s1_count": 5, "paper_received": 461},
    "last_completed_cycle": {"state": "NORMAL", "pipeline_cycle_id": "cy0", "candidate_commit_id": "cm0"},
    "timing": {"strategy_execution_handoff_sec": 10.5, "strategy_full_cycle_sec": 11.2, "paper_fast_cycle_sec": 70.9, "review_cycle_sec": 0.5},
    "disk": {"free_mb": 2800}, "stages": [], "problems": [], "workers": {}
}, ensure_ascii=False), encoding="utf-8")
(BASE / "canonical_candidate_standard_v1181.json").write_text(json.dumps({
    "state": "NORMAL", "easy_state": "전체 정상", "scope": {},
    "delivery": {"pipeline_cycle_id": "cy1", "candidate_commit_id": "cm1", "state": "NORMAL"},
    "candidate": {"total": 461, "s1": 5}, "structure": {"evaluated": 5, "complete": 5},
    "quality": {"rr": {"n": 5, "median": 5.5}},
    "time": {"occurrence_age_count": 5, "occurrence_age_median_sec": 20, "strategy_execution_handoff_sec": 10.5},
    "performance": {"snapshot_id": "perf", "count": 20, "wins": 12, "losses": 8, "win_rate": 60, "sum_pct": 10, "avg_pct": 0.5},
    "contract": {"state": "NORMAL", "owner": "paper"}, "missing": []
}, ensure_ascii=False), encoding="utf-8")
(BASE / "canonical_performance_snapshot_v987.json").write_text(json.dumps({
    "snapshot_id": "perf", "generated_at_text": "now", "source_owner": "paper",
    "counts": {"raw_ledger_rows": 100, "exact_unique_closed": 90},
    "performance_epoch_v1045": {"stats": {"n": 20, "wins": 12, "losses": 8, "win_rate": 60, "total": 10, "avg": 0.5}},
    "windows": {"today": {"n": 5, "wins": 3, "total": 2, "avg": 0.4}, "all": {"n": 90, "wins": 50, "total": 20, "avg": 0.22}},
    "book_performance": {"fresh_open": {"n": 4, "wins": 2, "total": -1, "avg": -0.25}, "fresh_closed_plus_open": {"n": 24, "wins": 14, "total": 9, "avg": 0.375}},
    "recent_rows": [{"ticker": "BTC", "pnl_pct": 1.2, "reason": "target", "mfe_pct": 2, "mae_pct": -0.5}]
}, ensure_ascii=False), encoding="utf-8")
(BASE / "paper_bot_status.json").write_text(json.dumps({"running": True, "version": "paper_bot_v1.046", "paper_fast_core_v1181": True, "elapsed_sec": 70.9}), encoding="utf-8")
(BASE / "paper_bot_open.json").write_text("{}", encoding="utf-8")

spec = importlib.util.spec_from_file_location("coinbot_main_v1185_test", ROOT / "coinbot_main_v2_13_1128.py")
module = importlib.util.module_from_spec(spec)
assert spec and spec.loader
spec.loader.exec_module(module)

for command in ("flow_map_full", "candidate_standard", "health", "swing_status", "version_score", "performance_lab", "commands"):
    output = module.render_command(command)
    assert output and "표시 실패" not in output, command

score = module.render_command("version_score")
for required in ("fresh CLOSED", "기간별 전략 결과", "CLOSED + 현재 OPEN", "최근 CLOSED 5건", "snapshot·원장"):
    assert required in score, required

module.set_runtime_state(telegram_state="polling_started")
module.write_status("running")
status = json.loads((BASE / "clean_brain_status.json").read_text(encoding="utf-8"))
assert status["telegram_state"] == "polling_started"
assert status["command_count"] >= 20

class Message:
    def __init__(self):
        self.text = "/flow_map_full\n/candidate_standard\n/errorlog"
        self.message_id = 1
        self.chat_id = 1
        self.texts = []
        self.documents = []
    def reply_text(self, value):
        self.texts.append(value)
    def reply_document(self, document, filename=None):
        self.documents.append((filename, document.read()))

class Chat:
    id = 1

class Update:
    update_id = 1
    effective_chat = Chat()
    def __init__(self):
        self.effective_message = Message()
        self.message = self.effective_message

update = Update()
module.collect_and_send(update, module.parse_command_lines(update.effective_message.text), batch=False)
assert len(update.effective_message.documents) == 1
assert update.effective_message.documents[0][0].startswith("coinbot_batch_summary_")
assert not list(BASE.glob("coinbot_batch_summary_*.txt"))
assert any("완료" in text for text in update.effective_message.texts)

print("PASS")
