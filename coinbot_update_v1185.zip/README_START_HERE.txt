Coinbot v1185 CHECK

This bundle restores the old Main-bot convenience on the new canonical spine:
- familiar command menu and wording
- /version_score with fresh CLOSED, current OPEN, periods, causes, and recent trades
- multi-line commands executed as one request
- Telegram compact cards plus one coinbot_batch_summary_*.txt detail file
- exact Main Telegram runtime fields for Guard /gdeploy
- in-memory exact-signature JSON cache to reduce command latency without stale fallback
- Review metrics aliases and readable Guard timing text

The old calculation paths, command override chains, and cache fallbacks are NOT restored.
Strategy formulas, trigger/invalid/target, RR, execution, exit contracts, and live ledgers are unchanged.
Auto-buy remains OFF.
