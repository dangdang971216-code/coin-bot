코인봇 v2130 역할 재지정·상승예측 대수술 설계
========================================================================
릴리스: v2130_one_shot_role_reassignment_prediction_verify_2026-07-21
상태: LOCAL PASS / SERVER CHECK
자동매수: OFF

1. 대수술 목적
- 구조선이 위치·invalid·target·위험과 미래 상승예측을 동시에 맡던 구조를 분리한다.
- 구조선은 매매 가능한 위치와 계약 위험만 담당한다.
- 상승 지속 가능성은 전체시장/BTC, 상대강도·돈흐름의 변화, 체결·호가의 연속 변화를 별도 owner가 만든다.
- Strategy는 owner 자료를 합쳐 Shadow Prediction만 생성한다.
- Review는 5m/15m/30m/3h/6h 실제 가격경로로 예측력을 검증한다.
- Paper는 실제 예정 진입가·비용·최종안전 owner를 유지한다.

2. 역할 재지정
- Candle/기존 Structure: 구조 구역, trigger 위치, invalid, target, 위험 공간
- Market v2.001: 전체시장 breadth·변화, 거래대금 집중 변화, 주도 지속, 빗썸 BTC 단기방향, 외부 BTC 선행
- Feature v2.001: 상대강도 변화, 돈흐름 변화, 모멘텀 지속, VWAP/EMA 위치 유지
- Orderflow v2.001: 매수 지속 변화, 매도벽 소진·재충전, bid 변화, spread 안정
- Strategy v2.044: 구조점수와 raw 상대강도·추격률을 제외한 continuation_prediction_v2130 생성
- Review v2.049: Prediction 등급별 실제 미래 MFE/MAE와 3h/6h 구분력 검증
- Main v2.13.2111: 데이터 owner·누락·잠금·표본 통합판
- Guard v2.6.16: 실제 systemd PID·cmdline·소스 버전·artifact·후보보존 통합검수

3. 최초 Trigger 사건 보존
- 같은 decision key는 append-once다.
- 자료가 부족해도 후보·구조·최초 사건을 삭제하지 않는다.
- source_missing은 명시하고 실행만 보류한다.
- 재돌파가 생겨도 최초 사건을 현재값으로 덮지 않는다.

4. 상승예측 잠금
- Prediction은 Shadow 전용이다.
- 현재 S1/S2/S3, 실제 진입, 실제 청산, 기존 OPEN에는 영향을 주지 않는다.
- 최소 3 snapshot, 충분한 STRONG/WEAK 표본, 최근·전체 비악화, 수익거래 훼손 거의 없음, 사용자 승인 전 본선 승격 불가다.

5. 절대 변경하지 않은 값
- trigger·invalid·target 공식
- RR·목표공간·추격·spread·slippage 기준
- 기존 후보수·등급·BUY_READY 흐름
- Paper 실제 진입·청산 계약
- OPEN/CLOSED/decision/exact 원장
- 기존 Shadow generation과 자료
- 자동매수 OFF

6. 통합 검수
Guard 명령: /gmajor_surgery_verify
- 실제 코드 버전과 alias
- systemd ActiveState/MainPID/cmdline
- Market/Feature/Orderflow 필수 필드와 자료 나이
- Strategy 역할·Prediction coverage·READY·source_missing
- 후보 입력/출력 보존
- compact 전달에서 역할·Prediction 필드 누락 여부
- Review snapshot·표본·승격 잠금
- Paper handoff 신선도
- 실제 진입·청산 비변경
- 자동매수 OFF
실패 시 코드명, 원인, owner를 한 판 아래에 표시한다.
