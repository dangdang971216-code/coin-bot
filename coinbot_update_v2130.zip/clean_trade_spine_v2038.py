"""Clean ALT_SWING trading spine v2038.

This module contains only decision logic. It never reads files, writes ledgers,
places orders, or mutates historical contracts. Runtime owners pass already
produced materials into these pure functions.
"""
from __future__ import annotations

from typing import Any, Dict, Iterable, List, Optional, Tuple
import hashlib
import json
import math

SCHEMA_ENTRY = "clean_entry_contract_v2038"
SCHEMA_EXIT = "clean_smart_exit_contract_v2038"


def num(*values: Any, default: Optional[float] = None) -> Optional[float]:
    for value in values:
        if value in (None, "", [], {}):
            continue
        try:
            out = float(str(value).replace(",", "").replace("%", "").strip())
        except (TypeError, ValueError):
            continue
        if math.isfinite(out):
            return out
    return default


def first_dict_value(sources: Iterable[Dict[str, Any]], *keys: str) -> Any:
    for source in sources:
        if not isinstance(source, dict):
            continue
        for key in keys:
            value = source.get(key)
            if value not in (None, "", [], {}):
                return value
    return None


def line_price(line: Any) -> Optional[float]:
    if isinstance(line, dict):
        return num(line.get("rounded_price"), line.get("raw_price"), line.get("price"), line.get("p"))
    return num(line)


def compact_line(line: Any) -> Dict[str, Any]:
    obj = line if isinstance(line, dict) else {}
    price = line_price(obj if obj else line)
    return {
        "price": round(price, 10) if price is not None else None,
        "timeframe": str(obj.get("tf") or obj.get("timeframe") or ""),
        "source": str(obj.get("source") or obj.get("source_key") or obj.get("reason") or ""),
    }


def compact_quality(row: Dict[str, Any]) -> Dict[str, Any]:
    nested: List[Dict[str, Any]] = [row]
    for key in ("quality_observation_v925", "quality_metrics", "entry_context", "raw"):
        value = row.get(key)
        if isinstance(value, dict):
            nested.append(value)
    return {
        "reaction": num(first_dict_value(nested, "price_reaction_pct", "reaction_score")),
        "relative_strength": num(first_dict_value(nested, "relative_strength_pct", "relative_strength", "relative_strength_rank_pct_v1095")),
        "money_flow": num(first_dict_value(nested, "money_flow_score", "money_flow")),
        "buy_ratio": num(first_dict_value(nested, "buy_ratio", "micro_buy_ratio", "buy_strength")),
        "buy_sustain": num(first_dict_value(nested, "buy_sustain_1m", "buy_sustain_60s", "micro_buy_ratio_sustain_1m")),
        "orderflow_score": num(first_dict_value(nested, "orderflow_score", "trade_flow_score")),
        "vwap_gap_pct": num(first_dict_value(nested, "vwap_gap_pct")),
        "ema_gap_pct": num(first_dict_value(nested, "ema5_gap_pct", "ma5_gap_pct", "ema10_gap_pct", "ema_gap_pct")),
        "normal_noise_pct": num(first_dict_value(nested, "normal_noise_p80_pct_v2032", "timeframe_noise_p80_pct_v2032", "noise_p80_pct_v2032")),
    }


def plan_digest(ticker: str, trigger: Dict[str, Any], invalid: Dict[str, Any], target: Dict[str, Any]) -> str:
    payload = {
        "ticker": ticker,
        "trigger": trigger,
        "invalid": invalid,
        "target": target,
    }
    raw = json.dumps(payload, ensure_ascii=False, sort_keys=True, separators=(",", ":"), default=str)
    return hashlib.sha256(raw.encode("utf-8")).hexdigest()[:24]


def update_trigger_occurrence(
    record: Dict[str, Any], *, ticker: str, plan_key: str, current_price: float,
    trigger_price: float, now_ts: float
) -> Tuple[Dict[str, Any], Dict[str, Any]]:
    """Single-pass trigger owner.

    The first candidate event seen at or above the frozen trigger receives one
    exact direct decision immediately.  Remaining above reuses the same key;
    a later natural below-to-above transition creates a new REBREAK event.
    There is no separate reset/recheck queue.
    """
    rec = dict(record or {})
    side = "above" if current_price >= trigger_price else "below"
    previous = str(rec.get("side") or "")
    sequence = int(num(rec.get("sequence"), default=0) or 0)
    reset_ts = num(rec.get("reset_ts"), default=None)
    event_ts = num(rec.get("event_ts"), rec.get("rebreak_ts"), default=None)
    decision_key = str(rec.get("decision_key") or "").strip() or None
    last_kind = str(rec.get("last_event_kind") or rec.get("kind") or "").strip()

    if side == "below":
        if previous != "below" or not reset_ts:
            reset_ts = now_ts
        event_ts = None
        decision_key = None
        kind = "WAIT_TRIGGER"
        new_open_event = False
    elif previous == "above" and decision_key and event_ts:
        kind = last_kind if last_kind in {"DIRECT_TRIGGER_EVENT", "REBREAK"} else "DIRECT_TRIGGER_EVENT"
        new_open_event = False
    else:
        sequence += 1
        event_ts = now_ts
        kind = "REBREAK" if previous == "below" and reset_ts else "DIRECT_TRIGGER_EVENT"
        decision_key = f"v2046:{ticker}:{plan_key}:event:{int(event_ts * 1000)}"
        new_open_event = True

    rec.update({
        "schema": "clean_trigger_state_v2046",
        "ticker": ticker, "plan_key": plan_key, "side": side, "kind": kind,
        "last_event_kind": kind if side == "above" else last_kind,
        "sequence": sequence, "reset_ts": reset_ts,
        "event_ts": event_ts, "rebreak_ts": event_ts,
        "decision_key": decision_key, "last_seen_ts": now_ts,
    })
    occurrence = {
        "schema": "clean_trigger_occurrence_v2046",
        "kind": kind, "side": side, "sequence": sequence,
        "reset_ts": reset_ts, "event_ts": event_ts, "rebreak_ts": event_ts,
        "trigger_price": trigger_price, "current_price": current_price,
        "decision_key": decision_key, "new_open_event": bool(new_open_event),
        "trigger_reached": side == "above",
        "qualification_state": "QUALIFIED_EVENT" if side == "above" and decision_key else "WAIT_TRIGGER",
        "contract_ready_at_cross": bool(side == "above" and decision_key),
        "requires_new_rebreak": False,
        "policy": "first event is decided immediately; same-above reuses exact key; natural below waits for trigger",
    }
    return rec, occurrence

def build_entry_contract(
    row: Dict[str, Any], plan: Dict[str, Any], occurrence: Dict[str, Any], *,
    ticker: str, current_price: float, now_ts: float, min_rr: float, min_room_pct: float
) -> Dict[str, Any]:
    trigger = compact_line(plan.get("trigger") if isinstance(plan, dict) else None)
    invalid = compact_line(plan.get("invalid") if isinstance(plan, dict) else None)
    target = compact_line(plan.get("target") if isinstance(plan, dict) else None)
    trigger_price = num(trigger.get("price"), default=0.0) or 0.0
    invalid_price = num(invalid.get("price"), default=0.0) or 0.0
    target_price = num(target.get("price"), default=0.0) or 0.0

    wait_reasons: List[str] = []
    block_reasons: List[str] = []
    missing: List[str] = []
    if not ticker:
        missing.append("ticker")
    if current_price <= 0:
        missing.append("current_price")
    for name, value in (("trigger", trigger_price), ("invalid", invalid_price), ("target", target_price)):
        if value <= 0:
            missing.append(name)
    if missing:
        wait_reasons.append("SOURCE_MISSING:" + ",".join(missing))

    risk = trigger_price - invalid_price
    reward = target_price - trigger_price
    rr = reward / risk if risk > 0 and reward > 0 else None
    room = reward / trigger_price * 100.0 if trigger_price > 0 and reward > 0 else None
    if not missing and not (invalid_price < trigger_price < target_price):
        block_reasons.append("INVALID_TRIGGER_TARGET_ORDER")
    if rr is not None and rr < min_rr:
        block_reasons.append("RR_BELOW_HARD_MIN")
    if room is not None and room < min_room_pct:
        block_reasons.append("TARGET_ROOM_BELOW_HARD_MIN")

    trigger_reached = bool(current_price > 0 and trigger_price > 0 and current_price >= trigger_price)
    occurrence_kind = str(occurrence.get("kind") or "")
    decision_key = str(occurrence.get("decision_key") or "")
    if not block_reasons and not wait_reasons:
        if not trigger_reached:
            wait_reasons.append("WAIT_TRIGGER")
        elif not decision_key:
            wait_reasons.append("TRIGGER_EVENT_MISSING")

    if block_reasons:
        state, stage = "BLOCK", "S3"
    elif wait_reasons:
        state, stage = "WAIT", "S2"
    else:
        state, stage = "READY", "S1"

    immutable = {
        "ticker": ticker,
        "decision_key": decision_key or None,
        "plan_key": plan_digest(ticker, trigger, invalid, target) if ticker else None,
        "trigger": trigger,
        "invalid": invalid,
        "target": target,
        "risk_reward": round(rr, 6) if rr is not None else None,
        "target_room_pct": round(room, 6) if room is not None else None,
        "current_price_at_decision": round(current_price, 10) if current_price > 0 else None,
        "occurrence": occurrence,
    }
    digest_raw = json.dumps(immutable, ensure_ascii=False, sort_keys=True, separators=(",", ":"), default=str)
    return {
        "schema": SCHEMA_ENTRY,
        "state": state,
        "stage": stage,
        "sealed_ts": now_ts,
        "digest": hashlib.sha256(digest_raw.encode("utf-8")).hexdigest()[:24],
        "immutable": immutable,
        "quality_observation": compact_quality(row),
        "wait_reasons": wait_reasons,
        "hard_block_reasons": block_reasons,
        "hard_thresholds": {"minimum_rr": min_rr, "minimum_target_room_pct": min_room_pct},
        "policy": {
            "quality_is_nonblocking": True,
            "separate_recheck_lane": False,
            "missing_is_wait_not_bad_quality": True,
            "paper_may_refresh_execution_only": True,
            "paper_may_rerank": False,
            "auto_buy": False,
        },
    }



# =============================================================================
# v2130 Strategy continuation prediction model (SHADOW-LOCKED)
# - Structure lines are intentionally excluded from the prediction score.
# - Market/feature/orderflow owners provide evidence; Strategy combines it once.
# - The result never changes S1/S2/S3, trigger, invalid, target, Paper or exit.
# =============================================================================
def _v2130_clip(value: float, low: float=0.0, high: float=100.0) -> float:
    return max(float(low), min(float(high), float(value)))

def _v2130_obj(row: Dict[str, Any], *keys: str) -> Dict[str, Any]:
    for key in keys:
        value=row.get(key) if isinstance(row,dict) else None
        if isinstance(value,dict):
            return value
    return {}

def _v2130_linear(value: Optional[float], scale: float, center: float=50.0, inverse: bool=False) -> Optional[float]:
    if value is None:
        return None
    raw=center + float(value)*float(scale)*(-1.0 if inverse else 1.0)
    return _v2130_clip(raw)

def build_continuation_prediction_v2130(row: Dict[str, Any], *, now_ts: float) -> Dict[str, Any]:
    """Combine owner evidence into one observation-only continuation prediction.

    Raw relative-strength level and chase rate are intentionally not rewarded:
    the v2129 audit showed their current expected direction could be inverted.
    Only change/velocity and persistence evidence is used here.
    """
    market=_v2130_obj(row,'global_market_context_v2130','market_context_v2130')
    feature=_v2130_obj(row,'feature_momentum_context_v2130')
    orderflow=_v2130_obj(row,'orderflow_continuation_v2130')

    axes: Dict[str, Dict[str, Any]]={}
    missing: List[str]=[]
    positive: List[str]=[]
    risks: List[str]=[]

    def add(name: str, score: Optional[float], value: Any, source: str, group: str, note: str='') -> None:
        if score is None:
            missing.append(name)
            axes[name]={'state':'SOURCE_MISSING','value':value,'source':source,'group':group}
            return
        score=_v2130_clip(float(score))
        axes[name]={'state':'READY','score':round(score,3),'value':value,'source':source,'group':group}
        if note: axes[name]['note']=note
        if score>=62: positive.append(name)
        elif score<=38: risks.append(name)

    market_score=num(market.get('continuation_score_v2130'),default=None)
    add('global_market',market_score,market.get('state') or market.get('mode'),'market_regime_worker.global_market_context_v2130','market')
    btc_dir=str(market.get('btc_short_direction') or '').upper()
    btc_score={'UP':72.0,'STRONG_UP':82.0,'FLAT':50.0,'MIXED':48.0,'DOWN':28.0,'STRONG_DOWN':18.0}.get(btc_dir)
    add('btc_short_direction',btc_score,btc_dir or None,'market_regime_worker.global_market_context_v2130','market')
    external=market.get('external_market_lead_v2130') if isinstance(market.get('external_market_lead_v2130'),dict) else {}
    external_dir=str(external.get('direction') or '').upper() if external.get('state')=='READY' else ''
    external_score={'UP':72.0,'STRONG_UP':82.0,'FLAT':50.0,'MIXED':48.0,'DOWN':28.0,'STRONG_DOWN':18.0}.get(external_dir)
    add('external_market_lead',external_score,external_dir or None,'market_regime_worker.external_market_lead_v2130','market')
    breadth_vel=num(market.get('breadth_velocity_pct_v2130'),default=None)
    add('breadth_velocity',_v2130_linear(breadth_vel,5.0),breadth_vel,'market_regime_worker.global_market_context_v2130','market')
    leadership=num(market.get('leader_persistence_pct_v2130'),default=None)
    add('leader_persistence',leadership,leadership,'market_regime_worker.global_market_context_v2130','market')

    rel_vel=num(feature.get('relative_strength_velocity_v2130'),default=None)
    add('relative_strength_velocity',_v2130_linear(rel_vel,8.0),rel_vel,'feature_worker.feature_momentum_context_v2130','feature',
        'raw relative-strength rank is observation-only; velocity is used')
    flow_vel=num(feature.get('money_flow_velocity_v2130'),default=None)
    add('money_flow_velocity',_v2130_linear(flow_vel,1.6),flow_vel,'feature_worker.feature_momentum_context_v2130','feature')
    consistency=num(feature.get('momentum_consistency_pct_v2130'),default=None)
    add('momentum_consistency',consistency,consistency,'feature_worker.feature_momentum_context_v2130','feature')
    location_score=num(feature.get('location_hold_score_v2130'),default=None)
    add('location_hold',location_score,feature.get('location_state_v2130'),'feature_worker.feature_momentum_context_v2130','feature')

    of_score=num(orderflow.get('continuation_score_v2130'),default=None)
    add('orderflow_continuation',of_score,orderflow.get('state'),'orderflow_worker.orderflow_continuation_v2130','orderflow')
    buy_delta=num(orderflow.get('buy_sustain_delta_v2130'),default=None)
    add('buy_sustain_velocity',_v2130_linear(buy_delta,180.0),buy_delta,'orderflow_worker.orderflow_continuation_v2130','orderflow')
    ask_depletion=num(orderflow.get('ask_wall_depletion_v2130'),default=None)
    add('ask_wall_depletion',_v2130_linear(ask_depletion,35.0),ask_depletion,'orderflow_worker.orderflow_continuation_v2130','orderflow')
    spread_delta=num(orderflow.get('spread_delta_v2130'),default=None)
    add('spread_stability',_v2130_linear(spread_delta,220.0,inverse=True),spread_delta,'orderflow_worker.orderflow_continuation_v2130','orderflow')

    groups={'market':[],'feature':[],'orderflow':[]}
    for axis in axes.values():
        if axis.get('state')=='READY' and axis.get('group') in groups:
            groups[str(axis.get('group'))].append(float(axis.get('score')))
    group_scores={k:(sum(v)/len(v) if v else None) for k,v in groups.items()}
    weights={'market':0.30,'feature':0.30,'orderflow':0.40}
    numerator=0.0; denominator=0.0
    for group,score in group_scores.items():
        if score is None: continue
        numerator+=score*weights[group]; denominator+=weights[group]
    score=(numerator/denominator) if denominator>0 else None
    ready_axes=sum(1 for x in axes.values() if x.get('state')=='READY')
    expected_axes=len(axes)
    ready_groups=sum(1 for x in group_scores.values() if x is not None)
    confidence=(ready_axes/max(1,expected_axes))*100.0

    market_risk=str(market.get('risk_state_v2130') or market.get('risk_state') or '').upper()
    if market_risk in {'RISK_OFF','DANGER','WEAK'}: risks.append('global_market_risk')
    if external_dir in {'DOWN','STRONG_DOWN'}: risks.append('external_market_risk')
    if bool(orderflow.get('spread_widening_v2130')): risks.append('spread_widening')
    if bool(orderflow.get('sell_wall_refill_v2130')): risks.append('sell_wall_refill')

    if score is None or ready_groups<2:
        grade='SOURCE_MISSING'; state='SOURCE_MISSING'
    elif score>=68 and confidence>=65 and not {'global_market_risk','spread_widening'}.intersection(risks):
        grade='STRONG_CONTINUATION'; state='READY'
    elif score>=58:
        grade='FAVORABLE'; state='READY'
    elif score>=44:
        grade='MIXED'; state='READY'
    else:
        grade='WEAK_CONTINUATION'; state='READY'

    return {
        'schema':'continuation_prediction_v2130','owner':'strategy_worker','state':state,
        'score_v2130':round(score,3) if score is not None else None,'grade_v2130':grade,
        'confidence_pct_v2130':round(confidence,2),'ready_axes_v2130':ready_axes,'expected_axes_v2130':expected_axes,
        'ready_groups_v2130':ready_groups,'group_scores_v2130':{k:(round(v,3) if v is not None else None) for k,v in group_scores.items()},
        'positive_axes_v2130':sorted(set(positive)),'risk_axes_v2130':sorted(set(risks)),
        'source_missing_v2130':sorted(set(missing)),'axes_v2130':axes,
        'structure_score_used_for_prediction_v2130':False,'raw_relative_strength_level_used_v2130':False,
        'chase_rate_used_v2130':False,'prediction_gate_active_v2130':False,
        'promotion_lock_v2130':'SHADOW_ONLY_UNTIL_3_SNAPSHOTS_EXACT_OUTCOME_AND_USER_APPROVAL',
        'actual_entry_changed_v2130':False,'actual_exit_changed_v2130':False,'candidate_deleted_v2130':False,
        'evaluated_ts':float(now_ts),'auto_buy':False,
    }

def validate_entry_contract(contract: Any) -> Tuple[bool, str]:
    if not isinstance(contract, dict) or contract.get("schema") != SCHEMA_ENTRY:
        return False, "CONTRACT_MISSING"
    if contract.get("state") != "READY" or contract.get("stage") != "S1":
        return False, "CONTRACT_NOT_READY"
    immutable = contract.get("immutable") if isinstance(contract.get("immutable"), dict) else {}
    if not immutable.get("decision_key"):
        return False, "DECISION_KEY_MISSING"
    occurrence = immutable.get("occurrence") if isinstance(immutable.get("occurrence"), dict) else {}
    if not occurrence.get("decision_key") or occurrence.get("trigger_reached") is not True:
        return False, "TRIGGER_EVENT_MISSING"
    for role in ("trigger", "invalid", "target"):
        line = immutable.get(role) if isinstance(immutable.get(role), dict) else {}
        if (num(line.get("price"), default=0.0) or 0.0) <= 0:
            return False, f"{role.upper()}_MISSING"
    return True, "OK"


def metric_drop(current: Optional[float], baseline: Optional[float], previous: Optional[float]) -> bool:
    return current is not None and baseline is not None and previous is not None and current < baseline and current < previous


def metric_recover(current: Optional[float], previous: Optional[float]) -> bool:
    return current is not None and previous is not None and current > previous


def evaluate_smart_exit(
    *, position: Dict[str, Any], materials: Dict[str, Any], peak_pct: float,
    net_pct: float, now_ts: float
) -> Dict[str, Any]:
    """Promoted v2011 structure+strength protection with profit-to-loss guard.

    It is not a fixed 1%/2% exit. Exact support and at least two independent
    strength groups are required. Weakness must persist for two observations,
    except a previously meaningful positive trade that is already at/below zero
    may close on the first complete true-weakness observation.
    """
    state = position.get("smart_exit_state_v2038") if isinstance(position.get("smart_exit_state_v2038"), dict) else {}
    baseline = state.get("baseline_metrics") if isinstance(state.get("baseline_metrics"), dict) else {}
    previous = state.get("prior_metrics") if isinstance(state.get("prior_metrics"), dict) else {}
    metrics = materials.get("metrics") if isinstance(materials.get("metrics"), dict) else {}
    support = num(materials.get("support_price"), default=None)
    current_price = num(materials.get("current_price"), default=None)
    cost_pct = max(0.0, num(materials.get("roundtrip_cost_pct"), default=0.0) or 0.0)
    noise_pct = num(materials.get("normal_noise_pct"), default=None)

    for key, value in metrics.items():
        if baseline.get(key) is None and value is not None:
            baseline[key] = value
    if not previous:
        previous = dict(metrics)

    vwap_gap = num(metrics.get("vwap_gap_pct"), default=None)
    ema_gap = num(metrics.get("ema_gap_pct"), default=None)
    relative = num(metrics.get("relative_strength"), default=None)
    location_available = vwap_gap is not None and ema_gap is not None
    relative_available = relative is not None
    flow_keys = ("money_flow", "buy_sustain", "buy_ratio", "orderflow_score")
    flow_available = sum(1 for key in flow_keys if metrics.get(key) is not None and previous.get(key) is not None)
    source_groups = (1 if location_available else 0) + (1 if relative_available else 0) + (1 if flow_available >= 2 else 0)
    source_ready = bool(support is not None and current_price is not None and source_groups >= 2)

    pullback = bool(peak_pct > 0 and net_pct < peak_pct)
    structure_broken = bool(source_ready and current_price < support)
    structure_reclaimed = bool(source_ready and current_price >= support)
    location_weak = bool(location_available and vwap_gap < 0 and ema_gap < 0)
    location_recovered = bool(location_available and vwap_gap >= 0 and ema_gap >= 0)
    relative_weak = bool(metric_drop(relative, num(baseline.get("relative_strength")), num(previous.get("relative_strength"))) and relative <= 0)

    flow_votes = [
        metric_drop(num(metrics.get("money_flow")), num(baseline.get("money_flow")), num(previous.get("money_flow"))),
        metric_drop(num(metrics.get("buy_sustain")), num(baseline.get("buy_sustain")), num(previous.get("buy_sustain"))),
        bool(num(metrics.get("buy_ratio")) is not None and num(previous.get("buy_ratio")) is not None and num(metrics.get("buy_ratio")) < 0.5 and num(metrics.get("buy_ratio")) < num(previous.get("buy_ratio"))),
        bool(num(metrics.get("orderflow_score")) is not None and num(previous.get("orderflow_score")) is not None and num(metrics.get("orderflow_score")) < 0 and num(metrics.get("orderflow_score")) < num(previous.get("orderflow_score"))),
    ]
    flow_weak = bool(flow_available >= 2 and sum(1 for vote in flow_votes if vote) >= 2)
    weak_group_count = (1 if location_weak else 0) + (1 if relative_weak else 0) + (1 if flow_weak else 0)
    weakness_candidate = bool(pullback and source_ready and structure_broken and weak_group_count >= 2)

    recovery_votes = [
        metric_recover(num(metrics.get("relative_strength")), num(previous.get("relative_strength"))),
        metric_recover(num(metrics.get("money_flow")), num(previous.get("money_flow"))),
        metric_recover(num(metrics.get("buy_sustain")), num(previous.get("buy_sustain"))),
        metric_recover(num(metrics.get("buy_ratio")), num(previous.get("buy_ratio"))),
        metric_recover(num(metrics.get("orderflow_score")), num(previous.get("orderflow_score"))),
    ]
    strength_recovering = sum(1 for vote in recovery_votes if vote) >= 2
    recovery_candidate = bool(source_ready and (structure_reclaimed or location_recovered) and strength_recovering)

    weak_streak = int(num(state.get("weak_streak"), default=0) or 0)
    recovery_streak = int(num(state.get("recovery_streak"), default=0) or 0)
    had_watch = bool(state.get("had_weakness_watch"))
    if weakness_candidate:
        weak_streak += 1
        recovery_streak = 0
        had_watch = True
    elif recovery_candidate and had_watch:
        recovery_streak += 1
        weak_streak = 0
    else:
        weak_streak = 0
        recovery_streak = 0

    meaningful_peak_threshold = max(cost_pct * 1.25, (noise_pct or 0.0) * 0.5)
    meaningful_positive_seen = bool(peak_pct > max(0.0, meaningful_peak_threshold))

    if not source_ready:
        classification = "SOURCE_MISSING"
    elif weak_streak >= 2:
        classification = "TRUE_WEAKNESS"
    elif recovery_streak >= 2:
        classification = "FAKE_SHAKE_RECOVERED"
    elif weakness_candidate:
        classification = "WEAKNESS_WATCH"
    elif pullback:
        classification = "NORMAL_SHAKE"
    else:
        classification = "UP_OR_FLAT"

    close = False
    reason = None
    # User-required profit-to-loss guard: only after a coin-specific meaningful
    # positive excursion AND complete structure+strength weakness evidence.
    if meaningful_positive_seen and net_pct <= 0 and weakness_candidate:
        close = True
        reason = "smart_profit_to_loss_guard"
    elif classification == "TRUE_WEAKNESS":
        close = True
        reason = "smart_true_weakness"

    new_state = {
        "schema": "clean_smart_exit_state_v2038",
        "classification": classification,
        "baseline_metrics": baseline,
        "prior_metrics": dict(metrics),
        "weak_streak": weak_streak,
        "recovery_streak": recovery_streak,
        "had_weakness_watch": had_watch,
        "source_ready": source_ready,
        "source_groups": source_groups,
        "structure_broken": structure_broken,
        "location_weak": location_weak,
        "relative_weak": relative_weak,
        "flow_weak": flow_weak,
        "weak_group_count": weak_group_count,
        "meaningful_peak_threshold_pct": round(meaningful_peak_threshold, 6),
        "meaningful_positive_seen": meaningful_positive_seen,
        "last_checked_ts": now_ts,
    }
    return {
        "action": "close" if close else "hold",
        "reason": reason,
        "classification": classification,
        "state": new_state,
        "evidence": {
            "support_price": support,
            "current_price": current_price,
            "peak_pct": peak_pct,
            "net_pct": net_pct,
            "pullback": pullback,
            "structure_broken": structure_broken,
            "location_weak": location_weak,
            "relative_weak": relative_weak,
            "flow_weak": flow_weak,
            "weak_group_count": weak_group_count,
            "source_groups": source_groups,
            "source_ready": source_ready,
            "normal_noise_pct": noise_pct,
            "roundtrip_cost_pct": cost_pct,
        },
        "policy": {
            "fixed_one_percent_exit": False,
            "fixed_two_percent_exit": False,
            "exact_support_required": True,
            "two_independent_strength_groups_required": True,
            "persistent_confirmation": 2,
            "missing_is_check_not_zero": True,
            "auto_buy": False,
        },
    }
