코인봇 업데이트 v1400

목적:
- v1153~v1158을 순서대로 합친 v1158 완료 generation 기준 복구본
- 모든 컴포넌트 표시 버전을 v1400으로 통일
- v1376의 mixed identity CHECK 방지
- 자동매수 OFF, 전략 수치 변경 없음

주의:
- 패키지 자체는 장부를 삭제하지 않음
- 장부 새 시작은 coinbot_ledger_clean_start_v1400.py --apply 별도 실행
