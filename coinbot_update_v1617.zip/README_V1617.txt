v1617: S1 hold cycle split repair. No threshold/trading rule change. Auto-buy OFF.
