이 파일들은 release seed다. 서버 live OPEN/CLOSED/trade_log/decision/change/issue 원장을 덮어쓰거나 삭제하지 않는다.
