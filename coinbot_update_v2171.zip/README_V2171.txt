v2171은 v2170의 실패한 큰흐름·구조 +0.341 본선 gate를 원복한다.
Strategy가 current_candidate_snapshot_v2171.json 한 파일을 봉인하고 Review·Main 시장판이 재필터 없이 그대로 읽는다.
Paper는 candidate_commit_id + s1_generation_id + receipt_event_id로 S1 0개와 다건 사건을 분리한다.
Scanner는 완료 Candle 자료로 1시간 가격 이력을 복구하며 자료 없음은 0으로 덮지 않는다.
과거 후보·OPEN/CLOSED/decision/exact·v2170 실패기록은 보존한다. 자동매수 OFF.
