#!/usr/bin/env python3
from __future__ import annotations
import ast, hashlib, importlib.util, json, os, shutil, tempfile
from pathlib import Path
ROOT=Path(__file__).resolve().parent

def load(name: str, path: Path, base_dir: Path):
    module_dir=Path(base_dir)/'module_copy'; runtime_root=Path(base_dir)/'runtime_root'
    module_dir.mkdir(parents=True,exist_ok=True); runtime_root.mkdir(parents=True,exist_ok=True)
    copied=module_dir/path.name; shutil.copy2(path,copied)
    old=os.environ.get('TRADING_BOT_DIR'); os.environ['TRADING_BOT_DIR']=str(runtime_root)
    try:
        spec=importlib.util.spec_from_file_location(name,str(copied)); mod=importlib.util.module_from_spec(spec); assert spec.loader
        spec.loader.exec_module(mod); return mod
    finally:
        if old is None: os.environ.pop('TRADING_BOT_DIR',None)
        else: os.environ['TRADING_BOT_DIR']=old

def fn_hash(path: Path, name: str) -> str:
    tree=ast.parse(path.read_text(encoding='utf-8'))
    nodes=[n for n in tree.body if isinstance(n,(ast.FunctionDef,ast.AsyncFunctionDef)) and n.name==name]
    assert nodes,name
    return hashlib.sha256(ast.dump(nodes[-1],include_attributes=False).encode()).hexdigest()

with tempfile.TemporaryDirectory() as td:
    base=Path(td); strategy=load('strategy_v1154_dep',ROOT/'strategy_worker_v1.020.py',base/'strategy')
    strategy.V1153_STRATEGY_PATH_LEDGER=base/'strategy_events.jsonl'; strategy.V1153_STRATEGY_PATH_STATE=base/'strategy_state.json'
    row={'ticker':'KRW-TEST','entry_build_key':'cand-1'}
    occ={'decision_key':'decision-1','candidate_key':'trigger-1','state_key':'state-1','event_ts':100.0,'rebreak_ts':100.0,'kind':'QUALIFIED_REBREAK','trigger_price':10.0,'contract_ready_at_cross':True}
    quality={'hard_pass':True,'known_axes':4,'missing_axes':[],'block_reasons':[],'rank_score':75.0}
    ts=strategy._v1153_capture_strategy_gate_path(row,occ,quality,110.0,'state-1','trigger-1','decision-1',True,[],{'execution_fresh_ok':True})
    assert ts['trigger_event_at']==100.0 and ts['quality_evaluated_at'] and ts['quality_pass_at']
    strategy._v1153_capture_strategy_gate_path(row,occ,quality,111.0,'state-1','trigger-1','decision-1',True,[],{'execution_fresh_ok':True})
    lines=(base/'strategy_events.jsonl').read_text(encoding='utf-8').strip().splitlines()
    assert len(lines)==3 and {json.loads(x)['stage'] for x in lines}=={'TRIGGER_EVENT','QUALITY_EVALUATED','QUALITY_PASS'}

with tempfile.TemporaryDirectory() as td:
    base=Path(td); paper=load('paper_v1154_dep',ROOT/'paper_bot_v1.029.py',base/'paper')
    paper.V1153_PAPER_PATH_LEDGER=base/'paper_events.jsonl'; paper.V1153_PAPER_PATH_STATE=base/'paper_state.json'
    ev={'ticker':'KRW-TEST','trigger_occurrence_candidate_key_v1037':'trigger-1','swing_gate_decision_key_v977':'decision-1',
        'swing_entry_gate_v977':{'schema':'swing_entry_gate_v977_single_owner','decision_key':'decision-1','trigger_occurrence_v1037':{'event_ts':100.0,'rebreak_ts':100.0,'decision_key':'decision-1','candidate_key':'trigger-1','qualification_state':'QUALIFIED_EVENT','contract_ready_at_cross':True}},
        'candidate_path_timestamps_v1153':{'trigger_event_at':100.0,'quality_evaluated_at':105.0,'quality_pass_at':106.0,'s1_hold_created_at':108.0}}
    recv=paper._v1153_paper_event_once('PAPER_RECEIVED',ev); paper._v1153_set_path_ts(ev,'paper_received_at',recv)
    paper._v1153_paper_event_once('PAPER_RECEIVED',ev)
    lines=(base/'paper_events.jsonl').read_text(encoding='utf-8').strip().splitlines(); assert len(lines)==1
    path=paper.candidate_delay_path_v1152(ev,{}, {'candidate_ttl_sec':120.0},paper_ts=float(recv))
    assert path['exact_segments_v1153']['trigger_to_quality_sec']==5.0
    assert path['exact_segments_v1153']['quality_to_s1_sec']==2.0
    assert path['exact_segments_v1153']['s1_to_paper_sec'] is not None

fixture=json.loads((ROOT/'tests/fixtures/V1152_TRADING_INVARIANTS.json').read_text(encoding='utf-8'))
for name,digest in fixture['strategy_function_ast_sha256'].items(): assert fn_hash(ROOT/'strategy_worker_v1.020.py',name)==digest,name
for name,digest in fixture['paper_function_ast_sha256'].items(): assert fn_hash(ROOT/'paper_bot_v1.029.py',name)==digest,name
print(json.dumps({'status':'PASS','v1153_append_once_dependency':True,'exact_first_three_segments':True,'trading_function_ast_unchanged':True,'auto_buy':False},ensure_ascii=False))
