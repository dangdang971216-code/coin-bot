# v1154 범위와 검수

## 누적 적용 기준
v1153이 아직 서버에 적용되지 않았어도 한 번에 적용할 수 있도록 아래 누적 source를 포함한다.

- Strategy v1.020: v1153 append-once trigger/quality/S1 timestamp
- Paper v1.029: v1153 first receive/execution/selector/block/OPEN timestamp
- Guard v2.5.190: v1154 후보 전달·시간품질 독립 판정
- Main v2.13.1115: v1154 쉬운 지도 분리 출력

Strategy v1.020과 Paper v1.029는 v1153 파일과 SHA256이 동일하다.

## 지도 판정
### 전달 배관
- COMPLETE: 전달 정상
- IN_PROGRESS: 현재 cycle 진행 중
- SLOW/STUCK/FAIL: 전달 문제

### 후보 시간 품질
- CHECK: STALE_TRIGGER_OCCURRENCE, SLIPPAGE_STALE 또는 source missing 존재
- COLLECTING: 새 시간표본 없음, 앞단 timestamp 일부 누락, 또는 WAIT_NEW_REBREAK 관찰 중
- NORMAL: stale/source missing 0이며 최근 표본의 trigger→quality→S1→Paper timestamp가 준비됨

### 전체
- 전달 문제 또는 시간품질 CHECK: 빨간색
- 시간증거 수집 중: 노란색
- 전달·시간품질 모두 정상: 초록색

## 로컬 검수
- py_compile PASS
- Guard time-quality contract CHECK/COLLECTING/NORMAL synthetic test PASS
- 전달 NORMAL + 시간품질 CHECK가 전체 빨간색으로 표시되는 Main render test PASS
- Strategy/Paper v1153 hash 동일
- v1154 diff에 Gate·TTL·RR·room·spread/slippage·entry/exit 수치 변경 없음
- 자동매수 OFF

## 서버 검수
1. Guard v2.5.190 / Main v2.13.1115 / Strategy v1.020 / Paper v1.029 runtime·hash 일치
2. `/flow_map_full` 상단에 전체·전달·시간품질 3개 판정 표시
3. 오래된 trigger/slippage가 있으면 전달 정상이어도 전체 빨간색
4. 오류그룹에 `CANDIDATE_TIME_QUALITY_DEGRADED` 표시
5. 새 v1153 표본에서 정확한 앞단 시간증거 비율 증가
6. 신규 runtime 오류 0
7. 자동매수 OFF
