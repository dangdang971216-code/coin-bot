# v1154 작업 잠금

## 증상
`/flow_map_full`은 Strategy cycle·후보 파일·Paper 접수가 정상이라는 이유로 상단을 `후보 배관 정상`으로 표시했다. 그러나 같은 snapshot 안에서 최근 후보 5건 중 4건은 `STALE_TRIGGER_OCCURRENCE`, 1건은 `SLIPPAGE_STALE`로 폐기됐다.

## 실제 원인
지도 owner가 두 상태를 하나로 섞었다.

1. 전달 배관 상태: Strategy가 S1·전체 후보·priority 요청을 저장하고 Paper가 읽었는가
2. 후보 시간 품질: 전달된 후보 내부의 trigger·slippage 사건이 실제 최신인가

파일 mtime과 cycle 완료만으로는 후보 내부 사건의 최신성을 증명할 수 없다.

## 이번 버전 범위
- Guard가 전달 배관과 후보 시간 품질을 독립 계약으로 판정
- stale trigger, stale slippage, source missing, WAIT_NEW_REBREAK, v1153 정확한 앞단 timestamp coverage 공개
- stale/source missing이 있으면 전달이 정상이어도 `CANDIDATE_TIME_QUALITY_DEGRADED`를 오류그룹에 등록
- Main 쉬운 지도에서 `전체 판정 / 전달 배관 / 후보 시간 품질`을 분리 표시
- Review 기대 버전 표시를 실제 active v1.011로 정렬

## 단일 owner
- 시간 원천: Strategy/Paper v1153 append-once candidate path timestamps
- terminal reason 원천: Paper pick_stats
- 최종 시간품질 판정: Guard
- 사용자 표시: Main read-only

## 삭제하는 구판정
- 최신 파일·완료 cycle만으로 후보 전체를 NORMAL 처리
- 전달 상태와 후보 사건시간 상태를 한 줄의 `후보 배관 정상`으로 혼합

## 변경하지 않는 영역
- Strategy/Paper 매매 source
- 품질 Gate·rank
- TTL
- trigger·invalid·target
- 실제 진입가 RR·target room
- spread·slippage 기준
- 재진입·청산 계약
- OPEN 30·cycle 신규 3
- 자동매수 OFF

## 상태
로컬 PASS / 서버 적용·runtime 증명 전 CHECK
