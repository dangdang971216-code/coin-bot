# v1154 이후 원인 수술 순서

v1154는 지도 누락을 고치는 버전이다. 실제 후보 지연을 아직 제거하지 않는다.

지도에서 새 표본이 쌓이면 다음 중 하나를 단일 축으로 선택한다.

1. trigger→quality가 큼: Feature 준비·Strategy 품질 join 순서 수술
2. quality→S1이 큼: Strategy cycle/cache·Gate 이후 publish 수술
3. S1→Paper가 큼: S1 commit/reader handoff 수술
4. SLIPPAGE_STALE 중심: Orderflow priority·수신/계산/write/read timestamp 수술
5. 첫 도착은 빠른데 같은 key가 반복 노출: terminal event feedback·재게시 생명주기 수술

TTL·Gate·RR 완화는 하지 않는다.
