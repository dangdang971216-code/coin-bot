#!/usr/bin/env python3
from __future__ import annotations
import ast, json, py_compile
from pathlib import Path
ROOT=Path(__file__).resolve().parent
files=['backga_guard_bot_v2_5_190.py','coinbot_main_v2_13_1115.py','strategy_worker_v1.020.py','paper_bot_v1.029.py']
for name in files:
    py_compile.compile(str(ROOT/name),doraise=True)
    ast.parse((ROOT/name).read_text(encoding='utf-8'))
print(json.dumps({'status':'PASS','py_compile':files,'strategy_paper_unchanged':True,'auto_buy':False},ensure_ascii=False))
