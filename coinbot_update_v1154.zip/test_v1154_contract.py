#!/usr/bin/env python3
from __future__ import annotations
import ast, hashlib, importlib.util, json, os, shutil, tempfile
from pathlib import Path

ROOT=Path(__file__).resolve().parent

def final_assign(path: Path, name: str):
    tree=ast.parse(path.read_text(encoding='utf-8'))
    value=None
    for node in tree.body:
        if isinstance(node,ast.Assign):
            for target in node.targets:
                if isinstance(target,ast.Name) and target.id==name:
                    try: value=ast.literal_eval(node.value)
                    except Exception: pass
    return value

def load_guard(base: Path):
    moddir=base/'guard_mod'; botdir=base/'server'; moddir.mkdir(); botdir.mkdir()
    src=moddir/'backga_guard_bot_v2_5_190.py'; shutil.copy2(ROOT/src.name,src)
    (moddir/'guard.env').write_text(f'BOT_DIR={botdir}\nGUARD_BOT_TOKEN=dummy\nGUARD_CHAT_ID=1\n',encoding='utf-8')
    spec=importlib.util.spec_from_file_location('guard_v1154_test',src)
    mod=importlib.util.module_from_spec(spec); assert spec.loader; spec.loader.exec_module(mod)
    return mod,botdir

def load_main(base: Path):
    moddir=base/'main_mod'; moddir.mkdir()
    src=moddir/'coinbot_main_v2_13_1115.py'; shutil.copy2(ROOT/src.name,src)
    spec=importlib.util.spec_from_file_location('main_v1154_test',src)
    mod=importlib.util.module_from_spec(spec); assert spec.loader; spec.loader.exec_module(mod)
    return mod,moddir

assert final_assign(ROOT/'backga_guard_bot_v2_5_190.py','VERSION')=='guard_v2.5.190_candidate_time_quality_map_v1154_2026-06-30'
assert final_assign(ROOT/'coinbot_main_v2_13_1115.py','BOT_VERSION')=='수익형 v2.13.1115'
assert final_assign(ROOT/'coinbot_main_v2_13_1115.py','V650_BUILD_LABEL')=='v1154_candidate_delivery_time_quality_split_2026-06-30'

source_hashes=json.loads((ROOT/'tests/fixtures/V1153_SOURCE_HASHES.json').read_text(encoding='utf-8'))
for name,digest in source_hashes.items():
    actual=hashlib.sha256((ROOT/name).read_bytes()).hexdigest()
    assert actual==digest,(name,actual,digest)

with tempfile.TemporaryDirectory() as td:
    guard,botdir=load_guard(Path(td))
    collecting=guard._v1154_candidate_time_quality_contract({}, {})
    assert collecting['state']=='COLLECTING'

    degraded=guard._v1154_candidate_time_quality_contract(
        {'paper_entry_hold_reason_counts_v1099':{'STALE_TRIGGER_OCCURRENCE':4,'SLIPPAGE_STALE':1}},
        {'count':5,'stale_count':4,'first_three_complete_count_v1153':3,'mean_total_age_sec':2210.3,
         'largest_segment_counts':{'trigger_to_quality_sec':4},
         'samples':[{'expired_by_sec':38.0,'exact_segments_v1153':{'trigger_to_quality_sec':117.0,'quality_to_s1_sec':1.0,'s1_to_paper_sec':0.2}}]}
    )
    assert degraded['state']=='CHECK'
    assert degraded['stale_trigger_count']==4 and degraded['slippage_stale_count']==1
    assert degraded['exact_coverage_pct']==60.0

    normal=guard._v1154_candidate_time_quality_contract(
        {'paper_entry_hold_reason_counts_v1099':{}},
        {'count':2,'stale_count':0,'first_three_complete_count_v1153':2,
         'samples':[{'expired_by_sec':0.0,'exact_segments_v1153':{'trigger_to_quality_sec':1.0,'quality_to_s1_sec':1.0,'s1_to_paper_sec':0.1}}]}
    )
    assert normal['state']=='NORMAL'

    missing=guard._v1154_candidate_time_quality_contract(
        {'paper_entry_hold_reason_counts_v1099':{'SLIPPAGE_SOURCE_MISSING':1}},
        {'count':1,'stale_count':0,'first_three_complete_count_v1153':1}
    )
    assert missing['state']=='CHECK' and missing['source_missing_count']==1

    waiting=guard._v1154_candidate_time_quality_contract(
        {'paper_entry_hold_reason_counts_v1099':{'WAIT_NEW_REBREAK':2}},
        {'count':2,'stale_count':0,'first_three_complete_count_v1153':2}
    )
    assert waiting['state']=='COLLECTING' and waiting['wait_new_rebreak_count']==2

with tempfile.TemporaryDirectory() as td:
    main,moddir=load_main(Path(td))
    ops={
      'reader_owner_contracts_v1150':{'candidate_pipeline':{
        'state':'NORMAL','progress_state_v1152':'COMPLETE','overall_state_v1154':'CHECK',
        'cycle_id':'strategy-1','age_sec':1.0,'last_completed_step':'PRIORITY_REQUESTS',
        's1_hold_count':5,'candidate_rows':460,'priority_request_count':1279,
        'candidate_time_quality_v1154':{
          'state':'CHECK','sample_count':5,'stale_trigger_count':4,'slippage_stale_count':1,
          'exact_first_three_count':3,'exact_coverage_pct':60.0,'wait_new_rebreak_count':0,
          'source_missing_count':0,'plain_impact':'파일 전달은 됐지만 오래된 후보가 폐기되고 있음'
        },
        'delay_summary_v1152':{'count':5,'stale_count':4,'mean_total_age_sec':2210.3,'largest_segment_counts':{'trigger_to_quality_sec':4},'samples':[]}
      }}
    }
    (moddir/'ops_map_snapshot.json').write_text(json.dumps(ops,ensure_ascii=False),encoding='utf-8')
    text='\n'.join(main._v1151_plain_pipeline_lines())
    assert '전체: 🔴 후보 시간 문제' in text
    assert '전달 판정: ✅ 전달 정상' in text
    assert '시간 판정: 🔴 비정상' in text
    assert '오래된 trigger 4개' in text and '오래된 slippage 1개' in text
    assert '파일이 최신이어도' in text

source_guard=(ROOT/'backga_guard_bot_v2_5_190.py').read_text(encoding='utf-8')
source_main=(ROOT/'coinbot_main_v2_13_1115.py').read_text(encoding='utf-8')
assert 'CANDIDATE_TIME_QUALITY_DEGRADED' in source_guard
assert "'delivery_state_v1154':pipeline_state_v1150" in source_guard
assert "EXPECTED_REVIEW_VERSION = 'review_worker_v1.011'" in source_main
print(json.dumps({'status':'PASS','delivery_time_quality_split':True,'stale_visible_when_delivery_normal':True,'collecting_state':True,'normal_state':True,'auto_buy':False},ensure_ascii=False))
