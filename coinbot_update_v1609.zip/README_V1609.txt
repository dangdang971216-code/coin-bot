v1609: Strategy→Paper candidate handoff commit repair/status. No trading rule changes. Auto-buy OFF.
