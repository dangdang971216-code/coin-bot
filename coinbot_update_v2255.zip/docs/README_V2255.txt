코인봇 v2255 오류 우선·상승예측 본선 교정

- Paper 상태는 실제 물리 writer 1개에서 canonical OPEN/손실방어를 강제한다.
- Review는 최근 exact 최대 500건만 overlay하고 과거 전체 run_once를 active path에서 제거한다.
- Main 4개 명령은 과거 renderer/정규식 wrapper를 호출하지 않고 현재 원본에서 직접 만든다.
- 상승예측은 exact에서 확인된 continuation_velocity>0 AND continuation_persistence>0 조합을 본선에 적용한다.
- 시장·실행위험·과열은 양수 가점이 아니라 감점만 한다.
- 후보 사건은 보존하며 불명확 후보는 실행만 보류한다. 새 Shadow 없음.
- -2% 손실방어 수치, trigger/invalid/target, 청산계약, 과거 원장은 변경하지 않는다.
- 자동매수 OFF.
- 서버 적용 전 CHECK.
