Coinbot v2168 canonical identity and event spine

- One canonical runtime identity file owns Strategy worker/core/model/cycle/commit.
- The same runtime signature is sealed into current candidate rows and the existing S1 hold.
- Review publishes generation-wide exact and active-model exact scopes from the same Paper exact books.
- Scanner-only symbols are preserved as SOURCE_WAIT candidates instead of disappearing before Feature catches up.
- Trigger-confirmed and S1-published timestamps are sealed on the same event.
- Current Main boards remove contradictory old-schema current claims. Historical rows and ledgers remain preserved.
- No trigger/invalid/T1/prediction/Paper cost/exit numeric change.
- Auto-buy OFF.
