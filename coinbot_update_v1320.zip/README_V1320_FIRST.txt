Apply with /gupgrade_bundle. This updates guard first if needed, then review/main/paper. Auto-buy remains OFF.
