코인봇 v2216 — v2215 최종 실행문 순서·런타임 신분 근본수리

현재 상태
- 자동매수 OFF
- v2215 재료 역할 단일계약·exact 재생 내용 그대로 유지
- 상승예측 식/가중치/양수선 변경 없음
- 후보/S1/Paper/진입/청산 변경 없음
- 기존 v2213 Shadow 보존

실패 원인
- v2215 Main·Strategy·Review 새 코드가 기존 if __name__ == __main__: main() 뒤에 붙어 있었음
- 파일 hash는 v2215였지만 프로세스가 먼저 v2214 무한루프에 들어가 새 정의까지 도달하지 못함
- 그 결과 Review active hash는 v2.094 파일과 같지만 status_version·lock_version은 v2.093으로 남음

수정
1. Main·Strategy·Review의 기존 중간 실행문 제거
2. 모든 최신 VERSION/BUILD/handler/run_once 정의가 끝난 파일 맨 끝에 실행문 1개만 배치
3. Review는 기존 singleton lock을 final v2.095 신분으로 획득하고 첫 전체스캔 전에 status를 즉시 v2.095로 기록
4. Strategy도 final v2.079·Core v2177 globals가 활성화된 뒤 main 시작
5. Main도 v2.13.2181 명령 바인딩이 끝난 뒤 Telegram polling 시작

서버 완료 조건
- Review MainPID=statusPID=lockPID 동일
- Review status_version=lock_version=review_worker_v2.095
- Strategy MainPID=statusPID=lockPID 동일, version=strategy_worker_v2.079
- Main 수익형 v2.13.2181
- Core v2177 역할계약 PASS, 기존 exact 재생 및 Shadow 보존
- 자동매수 OFF
