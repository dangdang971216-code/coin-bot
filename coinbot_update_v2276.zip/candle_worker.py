#!/usr/bin/env python3
# -*- coding: utf-8 -*-

from __future__ import annotations
import json, os, time, math, traceback, urllib.request, concurrent.futures, copy
from pathlib import Path
from typing import Any, Dict, List, Tuple, Optional
BASE_DIR = Path(os.getenv("TRADING_BOT_DIR", "/home/dangdang971216/trading_bot"))
def now_ts() -> float: return time.time()
def now_text(ts: Optional[float]=None) -> str: return time.strftime("%Y-%m-%d %H:%M:%S", time.localtime(ts or now_ts()))
def fnum(*vals: Any, default: float=0.0) -> float:
    for v in vals:
        try:
            if v is None or v == "": continue
            return float(str(v).replace(",", "").replace("%", ""))
        except Exception: continue
    return default
def load_json(path: Path, default: Any=None) -> Any:
    try:
        if not path.exists(): return default
        return json.loads(path.read_text(encoding="utf-8", errors="ignore"))
    except Exception: return default
def save_json(path: Path, obj: Any) -> None:
    # v1016: serialize before opening the visible tmp file, then perform one
    # buffered binary write. This prevents a 32MB checkpoint tmp from growing
    # slowly for tens of seconds while json.dump emits many chunks.
    path.parent.mkdir(parents=True,exist_ok=True)
    payload=json.dumps(obj,ensure_ascii=False,separators=(',',':'),default=str).encode('utf-8')
    tmp=path.with_name(path.name+f'.tmp.{os.getpid()}.{time.time_ns()}')
    try:
        with tmp.open('wb') as f:
            f.write(payload); f.flush(); os.fsync(f.fileno())
        os.replace(tmp,path)
    finally:
        try: tmp.unlink(missing_ok=True)
        except OSError: pass

def append_jsonl(path: Path, obj: Dict[str, Any]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("a", encoding="utf-8") as f:
        f.write(json.dumps(obj, ensure_ascii=False, separators=(",", ":"), default=str)+"\n")
def write_jsonl_atomic(path: Path, rows: List[Dict[str, Any]]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    tmp = path.with_suffix(path.suffix + ".tmp")
    with tmp.open("w", encoding="utf-8") as f:
        for r in rows:
            f.write(json.dumps(r, ensure_ascii=False, separators=(",", ":"), default=str)+"\n")
    os.replace(tmp, path)
def read_jsonl(path: Path, max_lines: int=1000) -> List[Dict[str, Any]]:
    if not path.exists(): return []
    try:
        lines = path.read_text(encoding="utf-8", errors="ignore").splitlines()
        if max_lines and len(lines) > max_lines: lines = lines[-max_lines:]
        out=[]
        for ln in lines:
            try:
                if ln.strip():
                    o=json.loads(ln)
                    if isinstance(o,dict): out.append(o)
            except Exception: pass
        return out
    except Exception: return []
def append_error(path: Path, where: str, exc: BaseException) -> None:
    try:
        path.parent.mkdir(parents=True, exist_ok=True)
        with path.open("a", encoding="utf-8") as f:
            f.write(f"[{now_text()}] {where}: {exc.__class__.__name__}: {exc}\n")
            f.write(traceback.format_exc()[-1500:]+"\n")
    except Exception: pass
def ticker_norm(x: Any) -> str:
    t = str(x or "").strip().upper().replace("/", "-").replace("_", "-")
    parts=[p for p in t.split("-") if p]
    if len(parts)>=2:
        non=[p for p in parts if p != "KRW"]
        t = non[-1] if non else parts[-1]
    if t.endswith("KRW") and len(t)>3: t=t[:-3]
    return t.strip().upper()
def pct(a: float, b: float) -> float: return ((a-b)/b*100.0) if b else 0.0
def age_sec(path: Path) -> float:
    try: return max(0.0, now_ts()-path.stat().st_mtime)
    except Exception: return 999999.0
def map_rows(obj: Any) -> Dict[str, Dict[str, Any]]:
    if isinstance(obj, dict) and isinstance(obj.get("rows"), list): obj = obj.get("rows")
    elif isinstance(obj, dict) and isinstance(obj.get("rows"), dict): obj = obj.get("rows")
    elif isinstance(obj, dict) and isinstance(obj.get("cache"), dict): obj = obj.get("cache")
    out: Dict[str, Dict[str, Any]] = {}
    if isinstance(obj, list):
        for r in obj:
            if isinstance(r, dict):
                t=ticker_norm(r.get("ticker") or r.get("symbol") or r.get("market"))
                if t: out[t]=r
    elif isinstance(obj, dict):
        for k,v in obj.items():
            t=ticker_norm(k)
            if t and isinstance(v, dict):
                vv=dict(v); vv.setdefault("ticker", t); out[t]=vv
    return out

VERSION="candle_worker_v0.960"
INTERVAL_SEC=float(os.getenv("CANDLE_WORKER_INTERVAL_SEC","3.0")); BATCH=int(os.getenv("CANDLE_WORKER_BATCH","20")); HTTP_TIMEOUT=float(os.getenv("CANDLE_WORKER_TIMEOUT","1.2")); MAX_WORKERS=int(os.getenv("CANDLE_WORKER_MAX_WORKERS","6"))
# v916: 구조 source-missing full-profile 요청은 일반 core 요청에 밀려 영구 미선택되지 않도록
# cycle마다 전용 슬롯을 사용한다. 전체 batch 크기와 전략 기준은 바꾸지 않는다.
STRUCTURE_FULL_PROFILE_BATCH=max(1, min(BATCH, int(os.getenv("CANDLE_WORKER_STRUCTURE_FULL_PROFILE_BATCH", str(max(4, BATCH//2))))))
# v954: reserved backfill slots remain after important live candidates receive first slots.
# This is a source backfill scheduler, not a trading priority or candidate cap.
STRUCTURE_LAB_BACKFILL_BATCH=max(1, min(BATCH, int(os.getenv("CANDLE_WORKER_STRUCTURE_LAB_BACKFILL_BATCH", str(max(4, BATCH//5))))))
STATUS=BASE_DIR/"clean_candle_status.json"; OUT=BASE_DIR/"clean_candle_cache.json"; ERROR=BASE_DIR/"clean_candle_error.log"
POOL=BASE_DIR/"clean_scanner_candidate_pool.json"; STRAT_TARGET=BASE_DIR/"clean_ws_targets.json"; PAPER_LATEST=BASE_DIR/"paper_candidates_latest.jsonl"; PRIORITY_REQ=BASE_DIR/"clean_strategy_priority_requests.json"; SCANNER_HOT=BASE_DIR/"clean_scanner_hot_rank_cache.json"
CANDLE_URGENT_TARGETS=BASE_DIR/"clean_candle_urgent_targets.json"; CANDLE_URGENT_RESULT=BASE_DIR/"clean_candle_urgent_result.json"; STRUCTURE_REFRESH_REQ=BASE_DIR/"clean_structure_lab_refresh_requests.json"
CANDLE_CACHE_PUBLISH_MAX_SEC=max(30.0,float(os.getenv('CANDLE_CACHE_PUBLISH_MAX_SEC','60.0')))
CANDLE_CACHE_HEARTBEAT_MAX_SEC=max(CANDLE_CACHE_PUBLISH_MAX_SEC,float(os.getenv('CANDLE_CACHE_HEARTBEAT_MAX_SEC','300.0')))
CANDLE_DELTA_MAX_BYTES=max(2*1024*1024,int(float(os.getenv('CANDLE_DELTA_MAX_MB','8.0'))*1024*1024))
CANDLE_DELTA_V1014=BASE_DIR/'clean_candle_delta_v1014.jsonl'
_LAST_CACHE_PUBLISH_TS=0.0
_LAST_CACHE_SEMANTIC_DIGEST=''
_CANDLE_MEMORY_CACHE_V1014: Optional[Dict[str, Dict[str, Any]]] = None
_CANDLE_DELTA_ROWS_SINCE_CHECKPOINT_V1014=0
_CANDLE_DELTA_RESET_COUNT_V1016=0
_CANDLE_DELTA_LAST_RESET_TS_V1016=0.0
_CANDLE_DELTA_LAST_RESET_BYTES_V1016=0
_CANDLE_BASE_CHECKPOINT_ID_V1016=''
_STRUCTURE_CURSOR_V1012=None

def _cache_semantic_digest_v1012(rows: List[Dict[str,Any]], cursor: int) -> str:
    def stable(value: Any) -> Any:
        if isinstance(value,dict):
            out={}
            for key,item in value.items():
                name=str(key).lower()
                if name in {'updated_ts','updated_text','observed_ts','last_seen_ts','candle_ts','age_sec','refresh_ts','last_refresh_ts'} or name.endswith('_age_sec'):
                    continue
                out[str(key)]=stable(item)
            return out
        if isinstance(value,list): return [stable(item) for item in value]
        return value
    material=[]
    for row in rows:
        if not isinstance(row,dict): continue
        frames=row.get('frames') if isinstance(row.get('frames'),dict) else {}
        frame_sig=[]
        for tf,frame in sorted(frames.items()):
            if not isinstance(frame,dict): continue
            frame_sig.append((tf,frame.get('completed_candle_ts') or frame.get('last_closed_ts'),frame.get('close'),frame.get('high'),frame.get('low'),frame.get('volume')))
        structure=row.get('structure_context_v871') if isinstance(row.get('structure_context_v871'),dict) else {}
        structure_sig=stable({k:structure.get(k) for k in ('major','setup','execution','invalid','target')})
        material.append((ticker_norm(row.get('ticker')),tuple(frame_sig),structure_sig))
    raw=json.dumps(material,ensure_ascii=False,sort_keys=True,separators=(',',':'),default=str).encode('utf-8')
    import hashlib
    return hashlib.sha256(raw).hexdigest()
def write_status(state:str, **extra:Any)->None: save_json(STATUS,{"version":VERSION,"state":state,"pid":os.getpid(),"updated_ts":now_ts(),"updated_text":now_text(),**extra})
def http_json(url:str)->Any:
    req=urllib.request.Request(url,headers={"Accept":"application/json","User-Agent":"coinbot-candle-worker/0.916-structure-priority-scheduler"})
    with urllib.request.urlopen(req,timeout=HTTP_TIMEOUT) as r: return json.loads(r.read().decode("utf-8",errors="ignore"))
def _rows_from_any(obj: Any) -> List[Dict[str, Any]]:
    if isinstance(obj, dict):
        for key in ("rows", "display_rows", "items", "top_candidates", "candidates", "requests"):
            val = obj.get(key)
            if isinstance(val, list):
                return [x for x in val if isinstance(x, dict)]
        if isinstance(obj.get("targets"), list):
            return [{"ticker": x} for x in obj.get("targets") if x]
    if isinstance(obj, list):
        return [x for x in obj if isinstance(x, dict)]
    return []

def _append_tickers(out: List[str], rows: List[Dict[str, Any]], limit: int = 999) -> None:
    for r in rows[:limit]:
        t = ticker_norm(r.get("ticker") or r.get("symbol") or r.get("market"))
        if t:
            out.append(t)

def _stage(row: Dict[str, Any]) -> str:
    for k in ("s_stage", "candidate_stage", "candidate_grade", "stage", "grade"):
        v = str(row.get(k) or "").upper()
        if v in ("S1", "S2", "S3"):
            return v
    return ""

def _row_reasons(row: Dict[str, Any]) -> str:
    vals=[]
    # v603: final_trade_state가 "공식 캔들 오래됨"으로 S2 대기인 경우도 candle_worker가 읽어야 한다.
    for k in ("final_trade_reasons", "final_decision", "final_trade_label", "trade_ready_label", "s_stage_reasons", "s2_recheck_reasons", "block_reasons", "missing_info", "risk_tags", "structure_risk_tags"):
        v=row.get(k)
        if isinstance(v,list): vals += [str(x) for x in v]
        elif v not in (None, ""): vals.append(str(v))
    cm=row.get("canonical_metric_row") if isinstance(row.get("canonical_metric_row"),dict) else {}
    if isinstance(cm,dict):
        v=cm.get("final_trade_reasons")
        if isinstance(v,list): vals += [str(x) for x in v]
        elif v not in (None, ""): vals.append(str(v))
    return " ".join(vals).lower()

def _trigger_gap(row: Dict[str, Any]) -> float:
    return abs(fnum(row.get("trigger_gap_pct"), row.get("s2_trigger_gap_pct"), row.get("gap_pct"), default=999.0))

def _needs_candle_fresh(row: Dict[str, Any]) -> bool:
    txt=_row_reasons(row)
    if any(w in txt for w in ("공식 캔들", "공식캔들", "캔들 오래", "candle", "ohlcv")):
        return True
    cm=row.get("canonical_metric_row") if isinstance(row.get("canonical_metric_row"),dict) else {}
    if isinstance(cm,dict):
        state=str(cm.get("final_trade_state") or row.get("final_trade_state") or "")
        reasons=" ".join(str(x) for x in (cm.get("final_trade_reasons") or [])) if isinstance(cm.get("final_trade_reasons"),list) else str(cm.get("final_trade_reasons") or "")
        if state == "S2_RECHECK" and any(w in reasons for w in ("공식 캔들", "공식캔들", "캔들 오래")):
            return True
    return False

def _existing_age_map(existing: Any) -> Dict[str, float]:
    out: Dict[str, float] = {}
    nowv=now_ts()
    for t,r in map_rows(existing).items():
        if not isinstance(r,dict):
            continue
        ts=fnum(r.get("candle_ts"), default=0.0)
        out[t]=max(999999.0 if ts<=0 else 0.0, nowv-ts) if ts<=0 else max(0.0, nowv-ts)
    return out

def _lane_from_bucket(bucket: str) -> str:
    """Refresh lanes are explicit roles; generic S2 must not become core."""
    b=str(bucket or '').lower()
    if 'structure_core_refresh' in b or 'urgent_s1' in b or 's1/preopen' in b or 'priority_s1' in b:
        return 'core'
    if 'trigger_urgent' in b or 'candle_trigger' in b or 'coin_quality_candle' in b:
        return 'core'
    if 'structure_near_refresh' in b or 'trigger_near' in b or 's2_trigger_near' in b or 's2_fresh_wait' in b or 'urgent_s2' in b:
        return 'near'
    if 'structure_watch_refresh' in b or 's2' in b or 's3' in b or 'watch_' in b:
        return 'watch'
    if 'hot_rank_recent' in b or 'hot' in b or 'spike' in b:
        return 'near'
    if 'structure_broad_refresh' in b or 'scanner' in b or 'ws_target' in b:
        return 'broad'
    return 'broad'

def _profile_from_lane(lane: str) -> str:
    return {'core':'full_1m3m5m', 'near':'mid_1m3m', 'watch':'light_1m', 'broad':'light_1m'}.get(str(lane or ''), 'light_1m')

_PROFILE_DEPTH={'light_1m':1, 'mid_1m3m':2, 'full_1m3m5m':3, 'structure_full_htf_mtf_ltf':4}
def _deeper_profile(a: str, b: str) -> str:
    aa=str(a or 'light_1m'); bb=str(b or 'light_1m')
    return aa if _PROFILE_DEPTH.get(aa,0) >= _PROFILE_DEPTH.get(bb,0) else bb

def _bucket_rank(bucket: str) -> int:
    lane=_lane_from_bucket(bucket)
    if 'coin_quality_candle' in str(bucket or '').lower() or 'candle_trigger' in str(bucket or '').lower(): return 985
    if lane == 'core': return 950
    if lane == 'near': return 760
    if lane == 'watch': return 520
    b=str(bucket or '').lower()
    if 'hot' in b or 'spike' in b: return 300
    if 'ws_target' in b: return 180
    if 'scanner' in b: return 120
    return 100

def _add_priority(book: Dict[str, Dict[str, Any]], ticker: str, bucket: str, base: float, target_age: float, age_map: Dict[str, float], reason: str="", requested_profile: str="") -> None:
    t=ticker_norm(ticker)
    if not t:
        return
    age=age_map.get(t, 999999.0)
    group_rank=_bucket_rank(bucket)
    lane=_lane_from_bucket(bucket)
    allowed_profiles={'full_1m3m5m','mid_1m3m','light_1m','structure_full_htf_mtf_ltf'}
    requested_profile=str(requested_profile or '').strip()
    profile=requested_profile if requested_profile in allowed_profiles else ('structure_full_htf_mtf_ltf' if 'structure_source_missing' in str(bucket or '').lower() else _profile_from_lane(lane))
    stale_bonus=max(0.0, age-target_age)*1.2
    fresh_penalty=220.0 if age < target_age*0.65 else 0.0
    score=base+stale_bonus-fresh_penalty
    final_score=group_rank*10000.0 + score
    cur=book.get(t)
    row={"ticker":t,"bucket":bucket,"lane":lane,"profile":profile,"bucket_rank":group_rank,"base":base,"target_age":target_age,"age":round(age,1) if age<999998 else None,"score":round(score,2),"final_score":round(final_score,2),"reason":reason,"profile_sources":[profile]}
    if not cur:
        book[t]=row
        return
    merged_profile=_deeper_profile(str(cur.get("profile") or ""), profile)
    profile_sources=[]
    for x in list(cur.get("profile_sources") or [])+[str(cur.get("profile") or ""), profile]:
        if x and x not in profile_sources:
            profile_sources.append(x)
    if final_score>float(cur.get("final_score",-999999)):
        row["profile"]=merged_profile
        row["profile_sources"]=profile_sources
        row["profile_preserved_from_other_request"]=bool(len(profile_sources)>1)
        book[t]=row
    else:
        cur["profile"]=merged_profile
        cur["profile_sources"]=profile_sources
        cur["profile_preserved_from_other_request"]=bool(len(profile_sources)>1)

def _hot_rows() -> List[Dict[str, Any]]:
    obj=load_json(SCANNER_HOT,{}) or {}
    rows=_rows_from_any(obj)
    # Some hot-rank caches store nested rows under hot/top keys; keep this defensive but do not call APIs here.
    if not rows and isinstance(obj,dict):
        for k,v in obj.items():
            if isinstance(v,list):
                rows += [x for x in v if isinstance(x,dict)]
    return rows

def _v608_urgent_rows() -> List[Dict[str, Any]]:
    obj=load_json(CANDLE_URGENT_TARGETS,{}) or {}
    rows=_rows_from_any(obj)
    out=[]
    for r in rows:
        t=ticker_norm(r.get("ticker") or r.get("symbol") or r.get("market"))
        if not t:
            continue
        rr=dict(r); rr["ticker"]=t
        out.append(rr)
    return out

def _v608_build_urgent_result(urgent_rows: List[Dict[str, Any]], new: List[str], fail: List[Dict[str, Any]], cache: Dict[str, Dict[str, Any]], batch: Optional[List[str]]=None, profile_map: Optional[Dict[str,str]]=None) -> Dict[str, Any]:
    # v611: 요청/선택/API/cache/age 단계별 사유를 남긴다.
    # 이전에는 "미회복"만 보여 원인이 API 실패인지, batch 미선택인지, cache 매칭 실패인지 알 수 없었다.
    nowv=now_ts()
    newset={ticker_norm(x) for x in new}
    batchset={ticker_norm(x) for x in (batch or [])}
    failmap={ticker_norm((x or {}).get("ticker")): str((x or {}).get("error") or "fetch_failed") for x in fail if isinstance(x,dict)}
    rows=[]; ok_under=0; ok_refreshed=0; miss=0
    lane_result: Dict[str, Dict[str, int]] = {}
    reason_counts: Dict[str, int] = {}
    profile_counts: Dict[str, int] = {}
    samples_by_reason: Dict[str, List[str]] = {}
    def add_reason(key: str, ticker: str) -> None:
        reason_counts[key]=reason_counts.get(key,0)+1
        samples_by_reason.setdefault(key, [])
        if len(samples_by_reason[key]) < 8:
            samples_by_reason[key].append(ticker)
    for r in urgent_rows:
        t=ticker_norm(r.get("ticker"))
        if not t:
            continue
        lane=str(r.get('lane') or _lane_from_bucket(str(r.get('bucket') or '')))
        profile=str((profile_map or {}).get(t) or r.get('profile') or _profile_from_lane(lane))
        profile_counts[profile]=profile_counts.get(profile,0)+1
        lr=lane_result.setdefault(lane, {"requested":0,"selected":0,"refreshed":0,"under_target":0,"miss":0,"failed":0,"not_selected":0,"cache_no_ts":0,"stale_after_fetch":0})
        lr["requested"] += 1
        selected = t in batchset
        if selected:
            lr["selected"] += 1
        else:
            lr["not_selected"] += 1
        cr=cache.get(t) if isinstance(cache,dict) else None
        ts=fnum((cr or {}).get("candle_ts"), default=0.0) if isinstance(cr,dict) else 0.0
        age=max(999999.0 if ts<=0 else 0.0, nowv-ts) if ts<=0 else max(0.0, nowv-ts)
        target_age=fnum(r.get("required_age_sec"), r.get("target_age"), default=120.0)
        refreshed=t in newset
        failed=t in failmap
        under=bool(age <= target_age)
        detail="ok_under_target"
        api_error=failmap.get(t)
        if not selected:
            detail="not_selected_this_cycle"; add_reason(detail,t)
        elif failed:
            detail="api_fetch_failed"; add_reason(detail,t); lr["failed"] += 1
        elif refreshed and ts<=0:
            detail="cache_write_no_ts"; add_reason(detail,t); lr["cache_no_ts"] += 1
        elif refreshed and not under:
            detail="stale_after_fetch"; add_reason(detail,t); lr["stale_after_fetch"] += 1
        elif (not refreshed) and not under:
            detail="selected_but_not_refreshed"; add_reason(detail,t)
        elif under and not refreshed:
            detail="already_fresh_from_cache"; add_reason(detail,t)
        else:
            add_reason(detail,t)
        if refreshed:
            ok_refreshed += 1; lr["refreshed"] += 1
        if under:
            ok_under += 1; lr["under_target"] += 1
        if not under:
            miss += 1; lr["miss"] += 1
        rows.append({"ticker":t,"bucket":r.get("bucket"),"lane":lane,"profile":profile,"strategy_reason":r.get("reason"),"target_age":target_age,"age":round(age,1) if age<999998 else None,"selected":selected,"refreshed":refreshed,"under_target_age":under,"failed":failed,"result_reason":detail,"api_error":api_error})
    obj={
        "schema":"candle_urgent_result_v611_reasoned",
        "version":VERSION,
        "updated_ts":nowv,
        "updated_text":now_text(nowv),
        "requested_count":len(rows),
        "selected_count":sum(1 for r in rows if r.get("selected")),
        "refreshed_count":ok_refreshed,
        "under_target_age_count":ok_under,
        "miss_count":miss,
        "reason_counts":reason_counts,
        "samples_by_reason":samples_by_reason,
        "lane_result":lane_result,
        "profile_counts":profile_counts,
        "rows":rows,
        "policy":"v916: no fixed candidate-count cap. Full-profile rows retain profile through dedup, receive rotating reserved slots, and result records selection/fetch/cache/age evidence.",
    }
    save_json(CANDLE_URGENT_RESULT,obj)
    return obj

def _priority_plan(existing: Any) -> Tuple[List[str], Dict[str, Any]]:
    age_map=_existing_age_map(existing)
    existing_map=map_rows(existing)
    book: Dict[str, Dict[str, Any]] = {}
    paper_rows=read_jsonl(PAPER_LATEST, max_lines=260)
    pri_rows=_rows_from_any(load_json(PRIORITY_REQ,{}) or {})
    hot_rows=_hot_rows()
    urgent_req_rows=_v608_urgent_rows()
    structure_refresh_rows=_rows_from_any(load_json(STRUCTURE_REFRESH_REQ,{}) or {})

    for r in structure_refresh_rows:
        t=ticker_norm(r.get("ticker") or r.get("symbol") or r.get("market"))
        lane=str(r.get("lane") or "watch").lower()
        if lane not in ("core","near","watch","broad"): lane="watch"
        bucket=f"structure_{lane}_refresh"
        requested_profile=str(r.get("profile") or ("structure_full_htf_mtf_ltf" if lane in ("core","near") else "full_1m3m5m"))
        priority=fnum(r.get("priority"),default=700.0)
        base={"core":900.0,"near":700.0,"watch":460.0,"broad":180.0}[lane]+min(260.0,priority*0.12)
        target={"core":25.0,"near":45.0,"watch":120.0,"broad":300.0}[lane]
        _add_priority(book,t,bucket,base,target,age_map,str(r.get("reason") or "structure map/live source refresh"),requested_profile)

    for r in urgent_req_rows:
        t=ticker_norm(r.get("ticker") or r.get("symbol") or r.get("market"))
        stage=str(r.get("stage") or r.get("candidate_stage") or "S2").upper()
        bucket=str(r.get("bucket") or ("urgent_S1_candle_fresh_lock" if stage=="S1" else "urgent_S2_candle_fresh_lock"))
        target=fnum(r.get("required_age_sec"), r.get("target_age"), default=120.0)
        pri=fnum(r.get("priority"), default=1000.0)
        _add_priority(book,t,bucket,900+min(180,pri*0.05),target,age_map,str(r.get("reason") or "strategy urgent candle fresh lock"),str(r.get('profile') or ''))

    for r in paper_rows:
        t=ticker_norm(r.get("ticker") or r.get("symbol") or r.get("market")); st=_stage(r); txt=_row_reasons(r); gap=_trigger_gap(r)
        if st=="S1": _add_priority(book,t,"S1/preopen",560,35,age_map,"paper latest S1")
        elif st=="S2" and _needs_candle_fresh(r): _add_priority(book,t,"S2_candle_fresh_wait",560,35,age_map,"final_trade_state candle wait")
        elif st=="S2" and gap<=0.60: _add_priority(book,t,"S2_trigger_near",450+(0.60-gap)*70,55,age_map,f"trigger_gap {gap:.3f}%")
        elif st=="S2" and ("fresh" in txt or "신선" in txt or "정보" in txt): _add_priority(book,t,"S2_fresh_wait",430,55,age_map,"fresh wait")
        elif st=="S2": _add_priority(book,t,"S2",350,90,age_map,"paper latest S2")
        elif st=="S3": _add_priority(book,t,"S3_watch",210,240,age_map,"paper latest S3")
        elif t: _add_priority(book,t,"paper_latest",260,160,age_map,"paper latest")

    for r in pri_rows:
        t=ticker_norm(r.get("ticker") or r.get("symbol") or r.get("market")); st=_stage(r); pri=fnum(r.get("priority"), default=130.0)
        bucket=str(r.get("bucket") or ("priority_S1" if st=="S1" else "strategy_priority")); needs=r.get("need") if isinstance(r.get("need"), list) else []; low_bucket=bucket.lower()
        if ("coin_quality_candle" in low_bucket) or ("candle_trigger" in low_bucket): target=25; base=780+min(260,pri*0.20); reason="v659 coin-quality/trigger candle urgent request"
        elif "candle" in [str(x).lower() for x in needs] or "candle" in low_bucket: target=30; base=560+min(240,pri*0.18); reason="strategy candle priority request"
        else: target=40 if st=="S1" or "s1" in low_bucket else 75; base=380+min(180,pri); reason="strategy priority request"
        _add_priority(book,t,bucket,base,target,age_map,reason)

    for r in hot_rows[:120]:
        t=ticker_norm(r.get("ticker") or r.get("symbol") or r.get("market")); ch=max(abs(fnum(r.get("change_1m_pct"), r.get("chg_1m"), r.get("m1"), default=0.0)), abs(fnum(r.get("change_3m_pct"), r.get("chg_3m"), r.get("m3"), default=0.0)))
        _add_priority(book,t,"hot_rank_recent",260+min(80,ch*8),120,age_map,f"hot_rank {ch:.2f}%")

    o=load_json(STRAT_TARGET,{}) or {}; raw=o.get("targets") if isinstance(o,dict) else []
    if isinstance(raw,list):
        for x in raw: _add_priority(book,ticker_norm(x),"ws_target_rotate",120,360,age_map,"ws target rotate")
    p=load_json(POOL,{}) or {}; pool_rows=p.get("rows") if isinstance(p,dict) else []
    if isinstance(pool_rows,list):
        for r in pool_rows: _add_priority(book,ticker_norm(r.get("ticker")),"scanner_universe",90,480,age_map,"scanner universe rotate")

    ranked=sorted(book.values(), key=lambda x:(float(x.get("final_score", x.get("score",0))), float(x.get("score",0)), float(x.get("base",0))), reverse=True)
    targets=[x["ticker"] for x in ranked if x.get("ticker")]
    universe=sorted(set(targets))
    coverage=_structure_lab_coverage(existing_map,universe)
    counts: Dict[str,int] = {}; lane_counts: Dict[str,int] = {}
    for x in ranked:
        b=str(x.get("bucket") or "unknown"); counts[b]=counts.get(b,0)+1; ln=str(x.get("lane") or _lane_from_bucket(b)); lane_counts[ln]=lane_counts.get(ln,0)+1
    urgent=[x for x in ranked if int(x.get("bucket_rank",0))>=400]
    diag={"schema":"candle_priority_plan_v954_wide_scan_priority_refresh","policy":"wide scanner universe remains complete; core=S1/current-hot/trigger-imminent only, near=true-good-S2/near-trigger, ordinary S2=watch, then broad rotation; no candidate cap and no trading threshold change.","target_count":len(targets),"urgent_count":len(urgent),"structure_refresh_request_count":len(structure_refresh_rows),"bucket_counts":counts,"lane_counts":lane_counts,"top":ranked[:20],"urgent_top":urgent[:40],"plan_rows":ranked,"structure_coverage":coverage,"structure_coverage_universe":universe}
    return targets, diag

def pick_targets(existing: Any=None)->List[str]:
    targets, _diag = _priority_plan(existing or load_json(OUT,{}) or {})
    return targets
def _v869_normalize_ohlcv(op: float, cl: float, hi: float, lo: float, vol: float) -> Tuple[float, float, float, float, float, bool]:
    """Normalize official candle OHLCV.

    Some exchange/cached payloads have high/low order ambiguity or stale rows.
    The horizontal line factory must never draw a support/resistance line from
    inverted high/low values.  This fixes only raw candle material, not
    S-grade thresholds, trigger formula, exits, or paper OPEN.
    """
    swapped = False
    try:
        op=float(op); cl=float(cl); hi=float(hi); lo=float(lo); vol=float(vol)
        # If the parsed high is below the parsed low, the source row was likely
        # [open, close, low, high, volume].  Swap once and keep a diagnostic flag.
        if hi < lo:
            hi, lo = lo, hi
            swapped = True
        # Final safety: make high/low envelop open/close.  This prevents a bad
        # source field from becoming a wrong chart horizontal line.
        real_hi = max(hi, op, cl, lo)
        real_lo = min(lo, op, cl, hi)
        if real_hi != hi or real_lo != lo:
            hi, lo = real_hi, real_lo
            swapped = True
    except Exception:
        pass
    return op, cl, hi, lo, vol, swapped

def parse_candles(obj:Any)->List[List[float]]:
    data=obj.get("data") if isinstance(obj,dict) else obj
    out=[]
    swap_count = 0
    if not isinstance(data,list): return out
    for x in data[-80:]:
        try:
            # Bithumb candle rows are treated as [time, open, close, high, low, volume].
            # v869 validates high/low order instead of trusting a positional guess.
            if isinstance(x,(list,tuple)) and len(x)>=6:
                op=fnum(x[1]); cl=fnum(x[2]); hi=fnum(x[3]); lo=fnum(x[4]); vol=fnum(x[5])
                op,cl,hi,lo,vol,swapped = _v869_normalize_ohlcv(op,cl,hi,lo,vol)
                if swapped: swap_count += 1
                if op and cl and hi and lo:
                    out.append([op,cl,hi,lo,vol])
        except Exception: pass
    # diagnostics are attached in candle_features/fetch_one where metadata can be stored.
    return out
def _ema(vals: List[float], period: int) -> float:
    if not vals: return 0.0
    k=2.0/(period+1.0); e=float(vals[0])
    for v in vals[1:]: e=float(v)*k+e*(1.0-k)
    return e

def _vwap(c: List[List[float]]) -> float:
    pv=0.0; vv=0.0
    for op,cl,hi,lo,vol in c:
        tp=(hi+lo+cl)/3.0
        pv += tp*max(vol,0.0); vv += max(vol,0.0)
    return pv/vv if vv else 0.0

def _touch_count(c: List[List[float]], level: float, side: str, tol_pct: float=0.18) -> int:
    if not level: return 0
    tol=abs(level)*tol_pct/100.0
    cnt=0
    for op,cl,hi,lo,vol in c:
        if side=='support' and lo <= level+tol and cl >= level-tol: cnt+=1
        elif side=='resistance' and hi >= level-tol and cl <= level+tol: cnt+=1
    return cnt


def _v824_candle_structure_features(c: List[List[float]], base: Dict[str, Any]) -> Dict[str, Any]:
    """Higher-timeframe structure material produced by candle_worker.

    This is raw structure material only: swing/box/touch/wick/volume context.
    strategy_worker remains the decision owner. No S-grade/exit/autobuy logic here.
    """
    out: Dict[str, Any] = {}
    try:
        if not c or len(c) < 3:
            return out
        op, cl, hi, lo, vol = c[-1]
        box_hi = fnum(base.get('box_high_price'), default=0.0)
        box_lo = fnum(base.get('box_low_price'), default=0.0)
        swing_hi = fnum(base.get('swing_high_price'), default=0.0)
        swing_lo = fnum(base.get('swing_low_price'), default=0.0)
        recent_hi = fnum(base.get('recent_high_price'), default=0.0)
        recent_lo = fnum(base.get('recent_low_price'), default=0.0)
        support_touch = int(fnum(base.get('support_touch_count'), default=0.0))
        resistance_touch = int(fnum(base.get('resistance_touch_count'), default=0.0))
        lower = fnum(base.get('lower_wick_pct'), default=0.0)
        upper = fnum(base.get('upper_wick_pct'), default=0.0)
        vr = fnum(base.get('volume_ratio'), default=0.0)
        vwap_gap = fnum(base.get('vwap_gap_pct'), default=999.0)
        ema10_gap = fnum(base.get('ema10_gap_pct'), default=999.0)
        ema20_gap = fnum(base.get('ema20_gap_pct'), default=999.0)
        breakout = bool(base.get('box_breakout_hint') or base.get('breakout_hint'))
        sweep = bool(base.get('sweep_reclaim_hint') or base.get('support_reclaim_hint'))
        reject = bool(base.get('resistance_reject_hint'))
        reasons: List[str] = []
        risks: List[str] = []
        score = 0.0
        if box_hi and box_lo and box_hi > box_lo:
            pos = (cl - box_lo) / max(1e-12, box_hi - box_lo) * 100.0
            out['box_position_pct'] = round(pos, 1)
            out['box_range_pct'] = round((box_hi - box_lo) / max(cl, 1e-12) * 100.0, 3)
        if box_lo:
            out['near_box_low_pct'] = round(pct(cl, box_lo), 3)
        if box_hi:
            out['near_box_high_pct'] = round(pct(cl, box_hi), 3)
        if swing_lo:
            out['near_swing_low_pct'] = round(pct(cl, swing_lo), 3)
        if swing_hi:
            out['near_swing_high_pct'] = round(pct(cl, swing_hi), 3)
        if support_touch >= 2:
            score += 22; reasons.append(f'지지선 반복터치 {support_touch}')
        elif support_touch >= 1:
            score += 12; reasons.append('지지선 터치')
        if resistance_touch >= 2:
            score += 10; reasons.append(f'저항선 반복터치 {resistance_touch}')
        if breakout:
            score += 24; reasons.append('박스/전고 돌파 힌트')
        if sweep:
            score += 20; reasons.append('저점쓸림·지지회복 힌트')
        if lower >= 30 and cl >= op:
            score += 14; reasons.append(f'아랫꼬리 회복 {lower:.0f}%')
        if vr >= 1.20:
            score += 10; reasons.append(f'거래량 반응 {vr:.2f}x')
        if -0.25 <= vwap_gap <= 0.65 and ema20_gap > -0.45:
            score += 10; reasons.append('VWAP/EMA 근처 방어')
        if upper >= 45 and not breakout:
            risks.append(f'윗꼬리 매물 {upper:.0f}%')
            score -= 8
        if reject:
            risks.append('저항권 거절 힌트')
            score -= 8
        if breakout:
            stype = 'breakout_hold'
        elif sweep and lower >= 25:
            stype = 'liquidity_sweep_recovery'
        elif support_touch >= 1 and lower >= 20:
            stype = 'support_rebound'
        elif -0.25 <= vwap_gap <= 0.65 and ema10_gap > -0.45:
            stype = 'vwap_ema_hold'
        else:
            stype = 'common_structure_watch'
        if score >= 42 and reasons and len(risks) == 0:
            quality = 'confirmed_line'; setup_state = 'setup_confirmed'
        elif score >= 26 and reasons:
            quality = 'reaction_line'; setup_state = 'setup_watch'
        elif box_hi or box_lo or swing_hi or swing_lo or recent_hi or recent_lo:
            quality = 'calculated_line'; setup_state = 'setup_watch'
        else:
            quality = 'weak_line'; setup_state = 'setup_missing'
        out.update({
            'structure_material_schema_v824': 'candle_structure_material_v824',
            'structure_type_v824': stype,
            'structure_line_quality_v824': quality,
            'structure_setup_state_v824': setup_state,
            'structure_score_v824': round(score, 1),
            'structure_reasons_v824': reasons[:8],
            'structure_risks_v824': risks[:6],
            'structure_has_box_v824': bool(box_hi and box_lo),
            'structure_has_swing_v824': bool(swing_hi and swing_lo),
            'structure_is_breakout_v824': bool(breakout),
            'structure_is_sweep_reclaim_v824': bool(sweep),
            'structure_hard_risk_v824': bool(risks and score < 35),
        })
    except Exception as exc:
        out['structure_material_schema_v824'] = 'candle_structure_material_v824_error'
        out['structure_error_v824'] = str(exc)[:80]
    return out



def _v869_closed_line_material(c: List[List[float]]) -> Dict[str, Any]:
    """Build v871 chart structure lines from completed candles only.

    v869 fixed high/low normalization and excluded the forming candle. v871
    keeps that rule and adds role-specific lookbacks so 1m/base lines are not
    confused with major support/resistance:
    - major line: longest completed window available in this TF feature set
    - setup line: medium completed window
    - execution line: short completed window for trigger/retest only
    This function only produces source material. It does not change strategy
    thresholds, S1/S2/S3 gates, trigger formula, exits, or paper OPEN.
    """
    if not c:
        return {}
    closed = c[:-1] if len(c) >= 6 else list(c)
    if len(closed) < 3:
        closed = list(c)
    if not closed:
        return {}

    def _win(n: int) -> List[List[float]]:
        return closed[-min(n, len(closed)):]

    exec_rows = _win(30)
    setup_rows = _win(72)
    major_rows = _win(120)
    recent = exec_rows or closed
    longer = setup_rows or recent
    major = major_rows or longer

    def _hi(rows: List[List[float]]) -> float:
        return max(float(x[2]) for x in rows) if rows else 0.0
    def _lo(rows: List[List[float]]) -> float:
        return min(float(x[3]) for x in rows) if rows else 0.0

    recent_high = _hi(recent); recent_low = _lo(recent)
    box_high = _hi(longer); box_low = _lo(longer)
    swing_high = recent_high; swing_low = recent_low
    major_high = _hi(major); major_low = _lo(major)
    setup_high = box_high; setup_low = box_low
    execution_high = recent_high; execution_low = recent_low

    support_touches = _touch_count(recent, recent_low, 'support')
    resistance_touches = _touch_count(recent, recent_high, 'resistance')
    return {
        'recent_high_price': round(recent_high, 8),
        'recent_low_price': round(recent_low, 8),
        'swing_high_price': round(swing_high, 8),
        'swing_low_price': round(swing_low, 8),
        'box_high_price': round(box_high, 8),
        'box_low_price': round(box_low, 8),
        'major_resistance_price': round(major_high, 8),
        'major_support_price': round(major_low, 8),
        'setup_resistance_price': round(setup_high, 8),
        'setup_support_price': round(setup_low, 8),
        'execution_high_price': round(execution_high, 8),
        'execution_low_price': round(execution_low, 8),
        'support_touch_count': support_touches,
        'resistance_touch_count': resistance_touches,
        'horizontal_line_schema_v869': 'official_ohlcv_closed_candle_horizontal_lines_v869',
        'horizontal_line_policy_v869': 'completed_candles_only_high_low_normalized_no_condition_change',
        'horizontal_line_closed_rows_v869': len(closed),
        'horizontal_line_recent_rows_v869': len(recent),
        'horizontal_line_longer_rows_v869': len(longer),
        'structure_context_schema_v871': 'htf_mtf_ltf_structure_context_lines_v871',
        'structure_context_policy_v871': 'major=HTF map, setup=MTF seat, execution=LTF trigger; strategy labels are tag-only',
        'major_lookback_rows_v871': len(major),
        'setup_lookback_rows_v871': len(setup_rows),
        'execution_lookback_rows_v871': len(exec_rows),
        'strategy_is_tag_only_v871': True,
        'conditions_changed_v871': False,
        'trigger_formula_changed_v871': False,
        'paper_open_changed_v871': False,
    }

def candle_features(c:List[List[float]])->Dict[str,Any]:
    if len(c)<3: return {}
    op,cl,hi,lo,vol = c[-1]
    prev= c[-2][1]
    ch1=pct(cl, prev); ch3=pct(cl, c[-3][1]) if len(c)>=3 else ch1; ch5=pct(cl, c[-5][1]) if len(c)>=5 else ch3
    rng=max(hi-lo, 1e-12); body=abs(cl-op)/rng*100; upper=(hi-max(op,cl))/rng*100; lower=(min(op,cl)-lo)/rng*100
    # v869: horizontal support/resistance lines are calculated from completed
    # candles only and after high/low normalization.  The current candle still
    # drives reaction metrics, but it no longer moves swing/box lines intrabar.
    line_material = _v869_closed_line_material(c)
    closed_for_vwap = c[:-1] if len(c) >= 6 else list(c)
    longer = closed_for_vwap[-min(24,len(closed_for_vwap)):] if closed_for_vwap else c[-min(24,len(c)):]
    vols=[x[4] for x in c[-8:]]; vavg=sum(vols[:-1])/max(1,len(vols)-1); vr=vol/vavg if vavg else 0
    closes=[x[1] for x in c]
    recent_high=fnum(line_material.get('recent_high_price'), default=max(x[2] for x in c[-min(12,len(c)):]))
    recent_low=fnum(line_material.get('recent_low_price'), default=min(x[3] for x in c[-min(12,len(c)):]))
    box_high=fnum(line_material.get('box_high_price'), default=max(x[2] for x in c[-min(24,len(c)):]))
    box_low=fnum(line_material.get('box_low_price'), default=min(x[3] for x in c[-min(24,len(c)):]))
    swing_high=fnum(line_material.get('swing_high_price'), default=recent_high); swing_low=fnum(line_material.get('swing_low_price'), default=recent_low)
    vw=_vwap(longer); ema5=_ema(closes[-20:],5); ema10=_ema(closes[-25:],10); ema20=_ema(closes[-35:],20)
    support_touches=int(fnum(line_material.get('support_touch_count'), default=0.0))
    resistance_touches=int(fnum(line_material.get('resistance_touch_count'), default=0.0))
    prev_vol_avg=sum([x[4] for x in c[-7:-1]])/max(1,len(c[-7:-1]))
    pullback_contract = bool(cl < op and prev_vol_avg and vol <= prev_vol_avg*0.85)
    reclaim_expand = bool(cl > op and vr >= 1.15 and lower >= 25)
    close_near_high = upper < 25 and cl >= op
    long_upper = upper > 45
    breakout = cl>=recent_high*0.998 and vr>=1.15
    sweep = lower>35 and cl>op and vr>=1.0
    base={
        "candle_change_1":round(ch1,3),"candle_change_3":round(ch3,3),"candle_change_5":round(ch5,3),
        "candle_body_pct":round(body,1),"upper_wick_pct":round(upper,1),"lower_wick_pct":round(lower,1),
        "volume_ratio":round(vr,2),"volume_expansion_pct":round((vr-1.0)*100.0,1),
        "recent_high_gap_pct":round(pct(cl,recent_high),3),"recent_low_rebound_pct":round(pct(cl,recent_low),3),
        "recent_high_price":round(recent_high,8),"recent_low_price":round(recent_low,8),
        "swing_high_price":round(swing_high,8),"swing_low_price":round(swing_low,8),
        "box_high_price":round(box_high,8),"box_low_price":round(box_low,8),
        "support_touch_count":support_touches,"resistance_touch_count":resistance_touches,
        "vwap_price":round(vw,8) if vw else None,"vwap_gap_pct":round(pct(cl,vw),3) if vw else None,
        "ema5_price":round(ema5,8) if ema5 else None,"ema10_price":round(ema10,8) if ema10 else None,"ema20_price":round(ema20,8) if ema20 else None,
        "ema5_gap_pct":round(pct(cl,ema5),3) if ema5 else None,"ema10_gap_pct":round(pct(cl,ema10),3) if ema10 else None,"ema20_gap_pct":round(pct(cl,ema20),3) if ema20 else None,
        "close_near_high": close_near_high,"long_upper_wick": long_upper,"volume_expanding": vr>=1.25,
        "breakout_hint": breakout,"box_breakout_hint": bool(cl>=box_high*0.998 and vr>=1.10),
        "sweep_reclaim_hint": sweep,"support_reclaim_hint": bool((support_touches>=1 and lower>=25 and cl>op) or sweep),
        "resistance_reject_hint": bool(resistance_touches>=1 and upper>=35 and cl<hi),
        "pullback_volume_contract": pullback_contract,"reclaim_volume_expand": reclaim_expand,
        "official_structure_schema":"official_ohlcv_structure_inputs_v596"}
    base.update(line_material)
    base.update({
        "official_structure_schema_v869":"official_ohlcv_closed_candle_horizontal_lines_v869",
        "line_factory_version_v869": VERSION,
        "line_factory_owner_v869":"candle_worker",
        "line_formula_changed_v869": False,
        "conditions_changed_v869": False,
        "structure_context_schema_v871":"htf_mtf_ltf_structure_context_lines_v871",
        "line_factory_version_v871": VERSION,
        "line_factory_owner_v871":"candle_worker",
        "strategy_is_tag_only_v871": True,
        "line_formula_changed_v871": False,
        "conditions_changed_v871": False,
        "trigger_formula_changed_v871": False,
        "paper_open_changed_v871": False,
    })
    base.update(_v824_candle_structure_features(c, base))
    return base



# =============================================================================
# candle_worker v0.952: complete-market structure-history backfill source
# - Stores longer completed-OHLCV history in compact arrays [ts,o,c,h,l,v].
# - The forming candle is excluded before any structure method sees the data.
# - Observation source only: no S grade, trigger, entry, exit, cost, or paper change.
# =============================================================================
STRUCTURE_LAB_DIRECT_LIMITS = {'m1':96,'m3':96,'m5':120,'m30':160,'h1':192}
STRUCTURE_LAB_DERIVED_LIMITS = {'m15':40,'h2':96,'h4':48}
STRUCTURE_LAB_MIN_USEFUL = {'m1':48,'m3':48,'m5':60,'m15':20,'m30':80,'h1':96,'h2':48,'h4':24}


def _structure_lab_parse_payload(obj: Any, tf: str) -> List[List[float]]:
    data=obj.get("data") if isinstance(obj,dict) else obj
    if not isinstance(data,list):
        return []
    limit=int(STRUCTURE_LAB_DIRECT_LIMITS.get(tf,96))
    dedup: Dict[float,List[float]]={}
    for x in data:
        if not isinstance(x,(list,tuple)) or len(x)<6:
            continue
        raw_ts=fnum(x[0],default=0.0)
        ts=raw_ts/1000.0 if raw_ts>10_000_000_000 else raw_ts
        op=fnum(x[1]); cl=fnum(x[2]); hi=fnum(x[3]); lo=fnum(x[4]); vol=fnum(x[5])
        op,cl,hi,lo,vol,_=_v869_normalize_ohlcv(op,cl,hi,lo,vol)
        if ts<=0 or min(op,cl,hi,lo)<=0:
            continue
        dedup[round(ts,3)]=[round(ts,3),op,cl,hi,lo,max(0.0,vol)]
    rows=[dedup[k] for k in sorted(dedup)]
    # The latest exchange candle can still be forming. Never let it confirm a line.
    if len(rows)>=2:
        rows=rows[:-1]
    return rows[-limit:]


def _structure_lab_aggregate(rows: List[List[float]], group: int, limit: int) -> List[List[float]]:
    if not rows or group<=1:
        return list(rows[-limit:]) if isinstance(rows,list) else []
    usable=len(rows)-(len(rows)%group)
    aligned=rows[len(rows)-usable:] if usable>0 else []
    out: List[List[float]]=[]
    for i in range(0,len(aligned),group):
        chunk=aligned[i:i+group]
        if len(chunk)<group:
            continue
        out.append([
            float(chunk[-1][0]),float(chunk[0][1]),float(chunk[-1][2]),
            max(float(x[3]) for x in chunk),min(float(x[4]) for x in chunk),
            sum(max(0.0,float(x[5])) for x in chunk),
        ])
    return out[-limit:]


def _structure_lab_snapshot(prev: Dict[str,Any], raw_by_prefix: Dict[str,List[List[float]]], fetched_prefixes: set, nowv: float) -> Dict[str,Any]:
    prior=prev.get('structure_lab_candles') if isinstance(prev.get('structure_lab_candles'),dict) else {}
    prior_frames=prior.get('frames') if isinstance(prior.get('frames'),dict) else {}
    prior_sources=prior.get('sources') if isinstance(prior.get('sources'),dict) else {}
    frames: Dict[str,List[List[float]]]={}
    sources: Dict[str,str]={}
    for tf in ('m1','m3','m5','m30','h1'):
        rows=raw_by_prefix.get(tf)
        limit=int(STRUCTURE_LAB_DIRECT_LIMITS[tf])
        if isinstance(rows,list) and rows:
            frames[tf]=rows[-limit:]
            sources[tf]='official_exchange_completed_candles_compact'
        elif isinstance(prior_frames.get(tf),list):
            frames[tf]=prior_frames[tf][-limit:]
            sources[tf]=str(prior_sources.get(tf) or 'preserved_completed_candles')
    if frames.get('m5'):
        frames['m15']=_structure_lab_aggregate(frames['m5'],3,STRUCTURE_LAB_DERIVED_LIMITS['m15'])
        sources['m15']='derived_from_official_5m_x3_completed_compact'
    if frames.get('h1'):
        frames['h2']=_structure_lab_aggregate(frames['h1'],2,STRUCTURE_LAB_DERIVED_LIMITS['h2'])
        frames['h4']=_structure_lab_aggregate(frames['h1'],4,STRUCTURE_LAB_DERIVED_LIMITS['h4'])
        sources['h2']='derived_from_official_1h_x2_completed_compact'
        sources['h4']='derived_from_official_1h_x4_completed_compact'
    counts={k:len(v) for k,v in frames.items()}
    sufficient={tf:counts.get(tf,0)>=need for tf,need in STRUCTURE_LAB_MIN_USEFUL.items()}
    ready=all(bool(sufficient.get(tf)) for tf in STRUCTURE_LAB_MIN_USEFUL)
    state='READY' if ready else ('PARTIAL' if any(counts.values()) else 'NOT_READY')
    direct_full=all(tf in fetched_prefixes for tf in STRUCTURE_LAB_DIRECT_LIMITS)
    prior_full=fnum(prior.get('last_full_profile_fetch_ts'),default=0.0)
    return {
        'schema':'structure_lab_completed_ohlcv_v954_priority_refresh','owner':'candle_worker','updated_ts':nowv,
        'last_full_profile_fetch_ts':nowv if direct_full else prior_full,
        'completed_candles_only':True,'forming_candle_excluded':True,'compact_row_order':['ts','o','c','h','l','v'],
        'frames':frames,'sources':sources,'frame_counts':counts,'history_min_useful':dict(STRUCTURE_LAB_MIN_USEFUL),
        'history_sufficient':sufficient,'source_state':state,'analysis_ready':ready,
        'raw_trade_volume_profile_available':False,
        'policy':'complete-market rotating backfill of longer completed OHLCV; observation only; no trading decision change',
    }


def _structure_lab_source_state(row: Dict[str,Any]) -> str:
    lab=row.get('structure_lab_candles') if isinstance(row.get('structure_lab_candles'),dict) else {}
    if not lab:
        return 'NOT_READY'
    sufficient=lab.get('history_sufficient') if isinstance(lab.get('history_sufficient'),dict) else {}
    if all(bool(sufficient.get(tf)) for tf in STRUCTURE_LAB_MIN_USEFUL):
        return 'READY'
    counts=lab.get('frame_counts') if isinstance(lab.get('frame_counts'),dict) else {}
    return 'PARTIAL' if any(fnum(v,default=0.0)>0 for v in counts.values()) else 'NOT_READY'


def _structure_lab_coverage(cache: Dict[str,Dict[str,Any]], universe: List[str]) -> Dict[str,Any]:
    ready=[]; partial=[]; missing=[]; frame_ready={tf:0 for tf in STRUCTURE_LAB_MIN_USEFUL}
    for t in universe:
        row=cache.get(t) if isinstance(cache.get(t),dict) else {}
        state=_structure_lab_source_state(row)
        if state=='READY': ready.append(t)
        elif state=='PARTIAL': partial.append(t)
        else: missing.append(t)
        lab=row.get('structure_lab_candles') if isinstance(row.get('structure_lab_candles'),dict) else {}
        sufficient=lab.get('history_sufficient') if isinstance(lab.get('history_sufficient'),dict) else {}
        for tf in frame_ready:
            if sufficient.get(tf): frame_ready[tf]+=1
    return {'universe_count':len(universe),'ready_count':len(ready),'partial_count':len(partial),'not_ready_count':len(partial)+len(missing),'missing_count':len(missing),'frame_ready_counts':frame_ready,'ready_tickers':ready,'pending_tickers':partial+missing}

def _aggregate_candles(c: List[List[float]], group: int) -> List[List[float]]:
    """Build higher timeframe candles from already fetched official OHLCV candles.
    Input rows are [open, close, high, low, volume] in chronological order.
    This is derived from official candles, not a new external source.
    """
    if not c or group <= 1:
        return list(c or [])
    out: List[List[float]] = []
    usable = len(c) - (len(c) % group)
    start = max(0, usable - min(480, usable))
    # v871: keep enough derived 2h/4h candles for major support/resistance context.
    # align from the end so latest candle grouping is stable.
    aligned = c[len(c)-usable:] if usable > 0 else []
    for i in range(0, len(aligned), group):
        chunk = aligned[i:i+group]
        if len(chunk) < group:
            continue
        op = chunk[0][0]
        cl = chunk[-1][1]
        hi = max(x[2] for x in chunk)
        lo = min(x[3] for x in chunk)
        vol = sum(max(0.0, x[4]) for x in chunk)
        out.append([op, cl, hi, lo, vol])
    return out


def _copy_prev_prefixes(feats: Dict[str, Any], prev: Dict[str, Any], fetched_prefixes: set) -> None:
    for pfx in ("m1","m3","m5","m15","m30","h1","h2","h4"):
        if pfx in fetched_prefixes:
            continue
        for k,v in prev.items():
            if str(k).startswith(pfx+"_"):
                feats[k]=v


def _v2031_structure_reliability_material_missing(prev: Dict[str, Any], prefix: str) -> bool:
    """True only when the Candle-owned v2029 reaction material was never built for this frame."""
    if not isinstance(prev, dict):
        return True
    return str(prev.get(f'{prefix}_structure_reliability_material_schema_v2029') or '') != 'completed_candle_role_line_reaction_material_v2029'

def _v2272_frame_success_age(prev: Dict[str, Any], prefix: str, nowv: float) -> float:
    """Age of the actual successful source refresh for one timeframe.

    Never uses top-level candle_ts: a successful short-frame fetch must not make
    m30/h1 look fresh. Existing v2265 per-frame owner timestamps are canonical.
    Missing legacy timestamps force one owner refresh instead of silently preserving
    an unprovable fresh state.
    """
    if not isinstance(prev, dict):
        return 999999.0
    lab = prev.get("structure_lab_candles") if isinstance(prev.get("structure_lab_candles"), dict) else {}
    success = lab.get("frame_last_fetch_success_ts_v2265") if isinstance(lab.get("frame_last_fetch_success_ts_v2265"), dict) else {}
    owner_prefix = {"m15": "m5", "h2": "h1", "h4": "h1"}.get(prefix, prefix)
    ts = fnum(success.get(owner_prefix), default=0.0)
    if ts <= 0:
        # Compatibility with any later explicit per-frame owner field. Do not fall
        # back to common candle_ts, which is the defect being repaired.
        ts = fnum(prev.get(f"{owner_prefix}_last_fetch_success_ts"), default=0.0)
    return max(0.0, nowv - ts) if ts > 0 else 999999.0


def fetch_one(ticker:str, prev: Optional[Dict[str,Any]]=None, profile: str="full_1m3m5m")->Dict[str,Any]:
    base=f"https://api.bithumb.com/public/candlestick/{ticker}_KRW"
    prev = prev if isinstance(prev, dict) else {}
    profile=str(profile or "light_1m")
    nowv=now_ts()
    feats={"ticker":ticker,"candle_ts":nowv,"candle_refresh_profile":profile,"candle_worker_build":"v0.916_structure_priority_scheduler"}
    prev_ts=fnum(prev.get("candle_ts"), default=0.0)
    prev_age=max(999999.0 if prev_ts<=0 else 0.0, nowv-prev_ts) if prev_ts<=0 else max(0.0, nowv-prev_ts)
    # v2272: scheduling is owned per timeframe. prev_age is retained only for
    # non-frame compatibility fields and must not decide m5/m30/h1 refresh.
    frame_age={tf:_v2272_frame_success_age(prev,tf,nowv) for tf in ("m1","m3","m5","m15","m30","h1","h2","h4")}

    # v0.17: candle_worker remains the raw-data owner. It fetches short TF often,
    # mid/long TF only when missing/stale to avoid v760-style worker lag.
    if profile == "structure_full_htf_mtf_ltf":
        # v914 root fix: source-missing refresh must collect the frames that own
        # HTF major and MTF setup lines, not only 1m/3m. m15/h2/h4 are derived below.
        intervals=[("1m","m1"),("3m","m3"),("5m","m5"),("30m","m30"),("1h","h1")]
    elif profile == "full_1m3m5m":
        intervals=[("1m","m1"),("3m","m3"),("5m","m5")]
        if (not prev.get("m30_ok")) or frame_age["m30"]>900:
            intervals.append(("30m","m30"))
        if (not prev.get("h1_ok")) or frame_age["h1"]>3600:
            intervals.append(("1h","h1"))
    elif profile == "mid_1m3m":
        intervals=[("1m","m1"),("3m","m3")]
        if (not prev.get("m5_ok")) or frame_age["m5"]>600:
            intervals.append(("5m","m5"))
        if (not prev.get("m30_ok")) or frame_age["m30"]>1200:
            intervals.append(("30m","m30"))
    else:
        intervals=[("1m","m1")]
        if not prev.get("m3_ok"):
            intervals.append(("3m","m3"))
        if not prev.get("m5_ok"):
            intervals.append(("5m","m5"))
        # v824: even light/watch lanes need occasional HTF structure material.
        # This is stale/missing-only and does not change strategy thresholds.
        if (not prev.get("m30_ok")) or frame_age["m30"]>1800:
            intervals.append(("30m","m30"))
        if (not prev.get("h1_ok")) or frame_age["h1"]>5400:
            intervals.append(("1h","h1"))
    # v2031: an old frame can still be marked *_ok while predating the v2029
    # reaction/recency material. Do not preserve that old cache as current source.
    # Refresh only the owner frames needed by target/invalid reliability, once;
    # after the v2029 schema is present the normal scheduler owns refresh cadence again.
    def _v2031_ensure_interval(interval: str, key: str) -> None:
        if not any(existing_key == key for _existing_interval, existing_key in intervals):
            intervals.append((interval, key))

    if any(_v2031_structure_reliability_material_missing(prev, pref) for pref in ('m5','m15')):
        _v2031_ensure_interval('5m', 'm5')
    if _v2031_structure_reliability_material_missing(prev, 'm30'):
        _v2031_ensure_interval('30m', 'm30')
    if any(_v2031_structure_reliability_material_missing(prev, pref) for pref in ('h1','h2','h4')):
        _v2031_ensure_interval('1h', 'h1')

    fetched_prefixes={key for _interval,key in intervals}
    candle_raw_by_prefix: Dict[str, List[List[float]]] = {}
    structure_lab_raw_by_prefix: Dict[str, List[Dict[str,float]]] = {}
    for interval,key in intervals:
        try:
            payload=http_json(base+"/"+interval)
            c=parse_candles(payload); candle_raw_by_prefix[key]=c
            structure_lab_raw_by_prefix[key]=_structure_lab_parse_payload(payload,key)
            cf=candle_features(c)
            for k,v in cf.items(): feats[f"{key}_{k}"]=v
            feats[f"{key}_ok"]=bool(cf)
            feats[f"{key}_age_sec"]=0.0
            feats[f"{key}_candle_age_sec"]=0.0
        except Exception as exc:
            feats[f"{key}_ok"]=False; feats[f"{key}_err"]=str(exc)[:60]
    # v0.17 derived official material: 15m from 5m, 2h/4h from 1h when available.
    # Derived rows keep their source explicit, so strategy can distinguish them from direct API TF.
    try:
        m5raw = candle_raw_by_prefix.get("m5")
        if m5raw and (profile == 'structure_full_htf_mtf_ltf' or (not prev.get("m15_ok")) or frame_age["m5"]>900 or _v2031_structure_reliability_material_missing(prev, 'm15')):
            c15=_aggregate_candles(m5raw,3); cf15=candle_features(c15)
            for k,v in cf15.items(): feats[f"m15_{k}"]=v
            feats["m15_ok"]=bool(cf15); feats["m15_source"]="derived_from_official_5m_x3"; feats["m15_age_sec"]=0.0; feats["m15_candle_age_sec"]=0.0
            fetched_prefixes.add("m15")
    except Exception as exc:
        feats["m15_ok"]=False; feats["m15_err"]="derive:"+str(exc)[:50]
    try:
        h1raw = candle_raw_by_prefix.get("h1")
        if h1raw:
            for dst,grp in (("h2",2),("h4",4)):
                if profile == 'structure_full_htf_mtf_ltf' or (not prev.get(f"{dst}_ok")) or frame_age["h1"]>7200 or _v2031_structure_reliability_material_missing(prev, dst):
                    cd=_aggregate_candles(h1raw,grp); cfd=candle_features(cd)
                    for k,v in cfd.items(): feats[f"{dst}_{k}"]=v
                    feats[f"{dst}_ok"]=bool(cfd); feats[f"{dst}_source"]=f"derived_from_official_1h_x{grp}"; feats[f"{dst}_age_sec"]=0.0; feats[f"{dst}_candle_age_sec"]=0.0
                    fetched_prefixes.add(dst)
    except Exception as exc:
        feats["h2_ok"]=False; feats["h4_ok"]=False; feats["h_derive_err"]="derive:"+str(exc)[:50]

    # v950: one longer compact completed-candle profile is shared by all five structure methods.
    feats['structure_lab_candles']=_structure_lab_snapshot(prev,structure_lab_raw_by_prefix,fetched_prefixes,nowv)
    # skipped interval values are preserved; this keeps long structure material alive without refetching every cycle.
    _copy_prev_prefixes(feats, prev, fetched_prefixes)
    feats["fast_interval_policy"]="v0.955: wide scan + important-first source refresh + pending-history rotation; observation only."
    return feats


def _pick_tiered_batch(priority_diag: Dict[str, Any], targets: List[str], structure_cursor: int=0) -> Tuple[List[str], Dict[str, str], Dict[str, int], int]:
    rows=priority_diag.get("plan_rows") if isinstance(priority_diag.get("plan_rows"), list) else []
    seen=set(); lanes={"core":[],"near":[],"watch":[],"broad":[]}; profiles: Dict[str,str] = {}; urgent_structure=[]
    for r in rows:
        if not isinstance(r,dict): continue
        t=ticker_norm(r.get("ticker"))
        if not t or t in seen: continue
        lane=str(r.get("lane") or _lane_from_bucket(str(r.get("bucket") or "")))
        if lane not in lanes: lane="broad"
        profile=str(r.get("profile") or _profile_from_lane(lane))
        lanes[lane].append(t); profiles[t]=profile; seen.add(t)
        if profile == "structure_full_htf_mtf_ltf": urgent_structure.append(t)

    batch=[]
    def take_rows(source: List[str], limit: int) -> int:
        added=0
        for t in source:
            if len(batch)>=BATCH or added>=max(0,limit): break
            if t not in batch: batch.append(t); added+=1
        return added

    # Important live candidates always receive the first slots.
    core_quota=min(len(lanes['core']),max(1,BATCH//2))
    core_added=take_rows(lanes['core'],core_quota)
    near_quota=min(len(lanes['near']),max(1,BATCH//6),max(0,BATCH-len(batch)))
    near_added=take_rows(lanes['near'],near_quota)

    # Keep a small guaranteed slot for complete-market long-history backfill.
    # v2276: prove each Candle collection stage instead of treating a returned row
    # as an API success. fetch_one preserves old frames on per-interval failure, so
    # ThreadPool completion alone is not evidence that fresh data was received.
    proof_frames=('m1','m3','m5','m30','h1')
    proof_attempted={tf:0 for tf in proof_frames}; proof_succeeded={tf:0 for tf in proof_frames}
    proof_failed={tf:0 for tf in proof_frames}; proof_preserved={tf:0 for tf in proof_frames}
    proof_full_success=0; proof_partial=0; proof_no_success=0; proof_samples=[]
    for t in batch:
        row=cache.get(t) if isinstance(cache.get(t),dict) else {}
        before=before_batch_v1016.get(t) if isinstance(before_batch_v1016.get(t),dict) else {}
        lab=row.get('structure_lab_candles') if isinstance(row.get('structure_lab_candles'),dict) else {}
        attempted=set(str(x) for x in (lab.get('fetch_attempted_prefixes_v2265') or []))
        succeeded=set(str(x) for x in (lab.get('fetch_succeeded_prefixes_v2265') or []))
        for tf in proof_frames:
            if tf in attempted:
                proof_attempted[tf]+=1
                if tf in succeeded:
                    proof_succeeded[tf]+=1
                else:
                    proof_failed[tf]+=1
                    prior_lab=before.get('structure_lab_candles') if isinstance(before.get('structure_lab_candles'),dict) else {}
                    prior_frames=prior_lab.get('frames') if isinstance(prior_lab.get('frames'),dict) else {}
                    if isinstance(prior_frames.get(tf),list) and prior_frames.get(tf): proof_preserved[tf]+=1
        if attempted and attempted.issubset(succeeded): proof_full_success+=1
        elif succeeded: proof_partial+=1
        else: proof_no_success+=1
        failed_tfs=sorted(attempted-succeeded)
        if failed_tfs and len(proof_samples)<20:
            errors={}
            for tf in failed_tfs:
                err=row.get(f'{tf}_err')
                if err: errors[tf]=str(err)[:120]
            proof_samples.append({'ticker':t,'profile':profile_map.get(t),'attempted':sorted(attempted),'succeeded':sorted(succeeded),'failed':failed_tfs,'errors':errors})
    collection_proof={
        'selected_count':len(batch),'thread_exception_count':len(fail),
        'ticker_full_success':proof_full_success,'ticker_partial_success':proof_partial,'ticker_no_success':proof_no_success,
        'frame_attempted':proof_attempted,'frame_succeeded':proof_succeeded,'frame_failed':proof_failed,'frame_failed_preserved':proof_preserved,
        'failure_samples':proof_samples,
        'meaning':'thread completion is separated from exchange fetch success and canonical preservation'
    }
    universe=priority_diag.get('structure_coverage_universe') if isinstance(priority_diag.get('structure_coverage_universe'),list) else []
    coverage=priority_diag.get('structure_coverage') if isinstance(priority_diag.get('structure_coverage'),dict) else {}
    pending=set(str(x) for x in (coverage.get('pending_tickers') or []) if x)
    coverage_added=0; scanned=0; cur=0
    # v2003: complete-market structure-lab backfill must not sit in front of live
    # candidate Candle refresh.  Under live core/near pressure, defer only the lab
    # backfill slot; exact current structure refresh requests remain urgent below.
    live_pressure_v2003=len(lanes['core'])+len(lanes['near'])
    # v2271 root fix: live pressure must not turn full-universe refresh off.
    # Core/near still receive the first slots, then the existing rotating
    # structure backfill gets guaranteed slots every cycle. This changes only
    # collection coverage; candidate ranking and trading conditions stay intact.
    remaining_after_live=max(0,BATCH-len(batch))
    backfill_budget_v2003=min(STRUCTURE_LAB_BACKFILL_BATCH,remaining_after_live)
    backfill_deferred_v2003=bool(pending and backfill_budget_v2003==0)
    if universe:
        cur=max(0,int(structure_cursor or 0))%len(universe)
        while scanned<len(universe) and coverage_added<backfill_budget_v2003 and len(batch)<BATCH:
            t=ticker_norm(universe[(cur+scanned)%len(universe)]); scanned+=1
            if t and t in pending and t not in batch:
                batch.append(t); profiles[t]='structure_full_htf_mtf_ltf'; coverage_added+=1
        next_structure_cursor=(cur+max(1,scanned))%len(universe)
    else:
        next_structure_cursor=0

    # Any remaining exact structure refresh request stays ahead of watch/broad rotation.
    urgent_left=[t for t in urgent_structure if t not in batch]
    urgent_quota=min(max(0,BATCH-len(batch)),STRUCTURE_FULL_PROFILE_BATCH,len(urgent_left))
    urgent_added=take_rows(urgent_left,urgent_quota)

    watch_quota=1 if lanes['watch'] and len(batch)<BATCH else 0
    watch_added=take_rows(lanes['watch'],watch_quota)
    if len(batch)<BATCH: take_rows(targets,BATCH-len(batch))

    selected_counts={"core":sum(1 for t in batch if t in lanes["core"]),"near":sum(1 for t in batch if t in lanes["near"]),"watch":sum(1 for t in batch if t in lanes["watch"]),"broad":sum(1 for t in batch if t in lanes["broad"]),"core_first_added":core_added,"near_first_added":near_added,"watch_reserved_added":watch_added,"structure_lab_backfill":coverage_added,"structure_lab_backfill_budget_v2003":backfill_budget_v2003,"structure_lab_backfill_deferred_v2003":backfill_deferred_v2003,"live_pressure_v2003":live_pressure_v2003,"full_universe_refresh_guaranteed_v2271":bool(backfill_budget_v2003>0 or not pending),"full_universe_pending_v2271":len(pending),"urgent_structure_full_profile":urgent_added,"structure_full_profile":sum(1 for t in batch if profiles.get(t)=="structure_full_htf_mtf_ltf"),"coverage_scanned":scanned,"plan_rows":len(rows)}
    return list(dict.fromkeys(batch)), profiles, selected_counts, next_structure_cursor


# v1016 candle delta spine
# - durable full cache remains the recovery checkpoint
# - active delta carries path operations, not full ticker rows
# - completed OHLCV arrays use roll/append operations when possible
# - checkpoint decision happens before append; a successful checkpoint resets
#   the same active delta atomically, while a failed checkpoint falls back to
#   appending the prepared operations so no current update is lost

def _v1016_path_parent(root: Dict[str, Any], path: List[str], create: bool=True) -> tuple[Optional[Dict[str, Any]], str]:
    if not path:
        return None, ''
    cur: Any=root
    for raw in path[:-1]:
        key=str(raw)
        if not isinstance(cur,dict):
            return None,str(path[-1])
        nxt=cur.get(key)
        if not isinstance(nxt,dict):
            if not create:
                return None,str(path[-1])
            nxt={}; cur[key]=nxt
        cur=nxt
    return cur if isinstance(cur,dict) else None,str(path[-1])

def _v1016_apply_ops(row: Dict[str, Any], ops: List[Dict[str, Any]]) -> Dict[str, Any]:
    out=copy.deepcopy(row) if isinstance(row,dict) else {}
    for op in ops if isinstance(ops,list) else []:
        if not isinstance(op,dict):
            continue
        kind=str(op.get('op') or '')
        path=[str(x) for x in (op.get('path') or [])]
        if not path:
            continue
        parent,key=_v1016_path_parent(out,path,create=kind!='remove')
        if not isinstance(parent,dict):
            continue
        if kind=='remove':
            parent.pop(key,None)
        elif kind=='set':
            parent[key]=copy.deepcopy(op.get('value'))
        elif kind=='list_roll':
            current=parent.get(key)
            if not isinstance(current,list):
                current=[]
            drop=max(0,int(fnum(op.get('drop_front'),default=0.0)))
            append_rows=op.get('append') if isinstance(op.get('append'),list) else []
            parent[key]=copy.deepcopy(current[drop:]+append_rows)
    return out

def _v1016_ohlcv_series(value: Any) -> bool:
    if not isinstance(value,list) or not value:
        return False
    sample=value[-min(3,len(value)):]
    return all(isinstance(x,list) and len(x)>=6 and fnum(x[0],default=0.0)>0 for x in sample)

def _v1016_roll_op(previous: List[Any], current: List[Any], path: List[str]) -> Optional[Dict[str, Any]]:
    if not (_v1016_ohlcv_series(previous) and _v1016_ohlcv_series(current)):
        return None
    # Timestamp identity is canonical for completed candles. Verify full rows in
    # the overlap so a corrected exchange candle is never hidden.
    prev_pos={str(row[0]):idx for idx,row in enumerate(previous) if isinstance(row,list) and row}
    overlap=0
    if current and str(current[0][0]) in prev_pos:
        idx=prev_pos[str(current[0][0])]
        candidate=min(len(previous)-idx,len(current))
        if previous[idx:idx+candidate]==current[:candidate]:
            overlap=candidate
    if overlap<=0:
        return None
    drop=len(previous)-overlap
    append_rows=current[overlap:]
    op={'op':'list_roll','path':path,'drop_front':drop,'append':append_rows}
    full={'op':'set','path':path,'value':current}
    if len(json.dumps(op,ensure_ascii=False,separators=(',',':'),default=str)) >= len(json.dumps(full,ensure_ascii=False,separators=(',',':'),default=str)):
        return None
    return op

def _v1016_build_ops(previous: Any, current: Any, path: Optional[List[str]]=None) -> List[Dict[str, Any]]:
    path=list(path or [])
    if previous==current:
        return []
    if isinstance(previous,dict) and isinstance(current,dict):
        ops: List[Dict[str, Any]]=[]
        for key in sorted(set(previous)|set(current)):
            child=path+[str(key)]
            if key not in current:
                ops.append({'op':'remove','path':child})
            elif key not in previous:
                ops.append({'op':'set','path':child,'value':current.get(key)})
            else:
                ops.extend(_v1016_build_ops(previous.get(key),current.get(key),child))
        return ops
    if isinstance(previous,list) and isinstance(current,list):
        roll=_v1016_roll_op(previous,current,path)
        return [roll] if roll else [{'op':'set','path':path,'value':current}]
    return [{'op':'set','path':path,'value':current}]

def _read_candle_delta_v1014(path: Path=CANDLE_DELTA_V1014, base: Optional[Dict[str, Dict[str, Any]]]=None, base_checkpoint_id: str='') -> Dict[str, Dict[str, Any]]:
    out: Dict[str, Dict[str, Any]]={}
    base=base if isinstance(base,dict) else {}
    if not path.exists():
        return out
    try:
        with path.open('r',encoding='utf-8',errors='ignore') as handle:
            for line in handle:
                try: item=json.loads(line)
                except Exception: continue
                if not isinstance(item,dict): continue
                ticker=ticker_norm(item.get('ticker'))
                schema=str(item.get('schema') or '')
                if schema=='candle_delta_ops_v1016':
                    item_base_id=str(item.get('base_checkpoint_id_v1016') or '')
                    if base_checkpoint_id and item_base_id and item_base_id!=base_checkpoint_id:
                        continue
                    if not ticker: continue
                    seed=out.get(ticker)
                    if not isinstance(seed,dict): seed=base.get(ticker) or {}
                    row=_v1016_apply_ops(seed,item.get('ops') if isinstance(item.get('ops'),list) else [])
                    row['ticker']=ticker; out[ticker]=row
                    continue
                if schema=='candle_delta_patch_v1015':
                    patch=item.get('patch') if isinstance(item.get('patch'),dict) else {}
                    seed=out.get(ticker)
                    if not isinstance(seed,dict): seed=base.get(ticker) or {}
                    row=dict(seed); row.update(patch)
                    for key in item.get('remove') or []: row.pop(str(key),None)
                    if ticker: row['ticker']=ticker; out[ticker]=row
                    continue
                row=item.get('row') if isinstance(item.get('row'),dict) else item
                if not isinstance(row,dict): continue
                ticker=ticker or ticker_norm(row.get('ticker') or row.get('market') or row.get('symbol'))
                if ticker: row=dict(row); row['ticker']=ticker; out[ticker]=row
    except OSError as exc:
        append_error(ERROR,'candle_delta_read_v1016',exc)
    return out

def _load_candle_memory_v1014() -> Dict[str, Dict[str, Any]]:
    global _CANDLE_MEMORY_CACHE_V1014,_LAST_CACHE_PUBLISH_TS,_CANDLE_BASE_CHECKPOINT_ID_V1016
    if _CANDLE_MEMORY_CACHE_V1014 is None:
        raw=load_json(OUT,{}) or {}
        base=map_rows(raw)
        if isinstance(raw,dict):
            _CANDLE_BASE_CHECKPOINT_ID_V1016=str(raw.get('delta_checkpoint_id_v1016') or '')
        if not _CANDLE_BASE_CHECKPOINT_ID_V1016:
            try:
                st=OUT.stat(); _CANDLE_BASE_CHECKPOINT_ID_V1016=f'legacy-{int(st.st_ino)}-{int(st.st_mtime_ns)}'
            except OSError:
                _CANDLE_BASE_CHECKPOINT_ID_V1016=f'bootstrap-{os.getpid()}-{time.time_ns()}'
        delta=_read_candle_delta_v1014(base=base,base_checkpoint_id=_CANDLE_BASE_CHECKPOINT_ID_V1016)
        base.update(delta)
        _CANDLE_MEMORY_CACHE_V1014=base
        try: _LAST_CACHE_PUBLISH_TS=float(OUT.stat().st_mtime) if OUT.exists() else 0.0
        except OSError: _LAST_CACHE_PUBLISH_TS=0.0
    return _CANDLE_MEMORY_CACHE_V1014

def _v1016_prepare_delta_records(changes: List[Tuple[Dict[str, Any], Dict[str, Any]]], nowv: float, base_checkpoint_id: str) -> tuple[List[str],Dict[str,Any]]:
    encoded_rows: List[str]=[]; op_counts=[]; row_bytes=[]; changed_tickers=[]
    for previous,row in changes:
        if not isinstance(row,dict): continue
        ticker=ticker_norm(row.get('ticker') or row.get('market') or row.get('symbol'))
        if not ticker: continue
        ops=_v1016_build_ops(previous if isinstance(previous,dict) else {},row,[])
        if not ops: continue
        item={'schema':'candle_delta_ops_v1016','version':VERSION,'build':BUILD_LABEL,'updated_ts':nowv,'base_checkpoint_id_v1016':base_checkpoint_id,'ticker':ticker,'ops':ops}
        encoded=json.dumps(item,ensure_ascii=False,separators=(',',':'),default=str)+'\n'
        encoded_rows.append(encoded); op_counts.append(len(ops)); row_bytes.append(len(encoded.encode('utf-8'))); changed_tickers.append(ticker)
    total=sum(row_bytes)
    metrics={
        'records':len(encoded_rows),'bytes':total,'changed_tickers':changed_tickers,
        'avg_ops':round(sum(op_counts)/len(op_counts),2) if op_counts else 0.0,
        'max_ops':max(op_counts) if op_counts else 0,
        'avg_record_bytes':round(total/len(row_bytes),1) if row_bytes else 0.0,
        'max_record_bytes':max(row_bytes) if row_bytes else 0,
    }
    return encoded_rows,metrics

def _v1016_append_delta_records(encoded_rows: List[str]) -> None:
    if not encoded_rows: return
    CANDLE_DELTA_V1014.parent.mkdir(parents=True,exist_ok=True)
    with CANDLE_DELTA_V1014.open('a',encoding='utf-8') as handle:
        handle.writelines(encoded_rows); handle.flush(); os.fsync(handle.fileno())

def _reset_candle_delta_v1014(nowv: float) -> tuple[int,int]:
    global _CANDLE_DELTA_RESET_COUNT_V1016,_CANDLE_DELTA_LAST_RESET_TS_V1016,_CANDLE_DELTA_LAST_RESET_BYTES_V1016
    try: before=int(CANDLE_DELTA_V1014.stat().st_size) if CANDLE_DELTA_V1014.exists() else 0
    except OSError: before=0
    tmp=CANDLE_DELTA_V1014.with_name(CANDLE_DELTA_V1014.name+f'.tmp.{os.getpid()}.{time.time_ns()}')
    try:
        with tmp.open('wb') as handle:
            handle.flush(); os.fsync(handle.fileno())
        os.replace(tmp,CANDLE_DELTA_V1014)
    finally:
        try: tmp.unlink(missing_ok=True)
        except OSError: pass
    _CANDLE_DELTA_RESET_COUNT_V1016+=1; _CANDLE_DELTA_LAST_RESET_TS_V1016=nowv; _CANDLE_DELTA_LAST_RESET_BYTES_V1016=before
    return before,0

def run_once()->Dict[str,Any]:
    global _LAST_CACHE_PUBLISH_TS, _LAST_CACHE_SEMANTIC_DIGEST, _STRUCTURE_CURSOR_V1012, _CANDLE_DELTA_ROWS_SINCE_CHECKPOINT_V1014, _CANDLE_DELTA_RESET_COUNT_V1016, _CANDLE_DELTA_LAST_RESET_TS_V1016, _CANDLE_DELTA_LAST_RESET_BYTES_V1016, _CANDLE_BASE_CHECKPOINT_ID_V1016
    st=now_ts(); cache=_load_candle_memory_v1014()
    existing=load_json(OUT,{}) or {}
    merged_existing=dict(existing) if isinstance(existing,dict) else {}; merged_existing['rows']=list(cache.values())
    targets, priority_diag = _priority_plan(merged_existing)
    if _STRUCTURE_CURSOR_V1012 is None:
        _STRUCTURE_CURSOR_V1012=int(fnum(existing.get("structure_cursor"), existing.get("cursor"), default=0.0)) if isinstance(existing,dict) else 0
    structure_cursor=int(_STRUCTURE_CURSOR_V1012 or 0)
    batch, profile_map, selected_counts, next_structure_cursor = _pick_tiered_batch(priority_diag, targets, structure_cursor=structure_cursor)
    _STRUCTURE_CURSOR_V1012=next_structure_cursor
    before_batch_v1016={ticker:copy.deepcopy(cache.get(ticker) or {}) for ticker in batch}
    new=[]; fail=[]
    coverage_before=priority_diag.get('structure_coverage') if isinstance(priority_diag.get('structure_coverage'),dict) else {}
    write_status("running", phase="fetching_priority_then_market_rotation", row_count=len(cache), target_count=len(targets), batch=len(batch), tier_selected=selected_counts, structure_coverage=coverage_before, max_workers=MAX_WORKERS, last_sec=0, priority_policy=priority_diag.get("policy"), priority_bucket_counts=priority_diag.get("bucket_counts",{}), priority_lane_counts=priority_diag.get("lane_counts",{}), priority_top=priority_diag.get("top",[])[:5])
    def _job(t:str)->Tuple[str, Optional[Dict[str,Any]], Optional[str]]:
        try: return t, fetch_one(t, cache.get(t), profile_map.get(t,"light_1m")), None
        except Exception as exc: return t, None, f"{exc.__class__.__name__}: {str(exc)[:80]}"
    workers=max(1,min(MAX_WORKERS,len(batch) or 1))
    with concurrent.futures.ThreadPoolExecutor(max_workers=workers) as ex:
        futs=[ex.submit(_job,t) for t in batch]
        for fut in concurrent.futures.as_completed(futs):
            t,row,err=fut.result()
            if row: cache[t]=row; new.append(t)
            elif err: fail.append({"ticker":t,"error":err})
    universe=priority_diag.get('structure_coverage_universe') if isinstance(priority_diag.get('structure_coverage_universe'),list) else []
    coverage_after=_structure_lab_coverage(cache,universe)
    cutoff=now_ts()-1200
    rows=[]
    for v in cache.values():
        if not isinstance(v,dict): continue
        ts=fnum(v.get('candle_ts'),default=0.0)
        # Preserve completed long-history source while regular fast freshness continues to rotate.
        if ts>=cutoff or _structure_lab_source_state(v) in ('READY','PARTIAL'): rows.append(v)
    rows.sort(key=lambda r:fnum(r.get("candle_ts")),reverse=True)
    ages=[max(0.0,now_ts()-fnum(r.get("candle_ts"),default=0.0)) for r in rows if fnum(r.get("candle_ts"),default=0.0)>0]
    age_diag={"avg":round(sum(ages)/len(ages),1) if ages else None,"under_120":sum(1 for a in ages if a<=120),"over_300":sum(1 for a in ages if a>300),"max":round(max(ages),1) if ages else None}
    urgent_plan_rows=_v608_urgent_rows(); urgent_result=_v608_build_urgent_result(urgent_plan_rows,new,fail,cache,batch=batch,profile_map=profile_map)
    out={"version":VERSION,"schema":"candle_cache_v1012_bounded_publish","updated_ts":now_ts(),"updated_text":now_text(),"row_count":len(rows),"target_count":len(targets),"cursor":next_structure_cursor,"structure_cursor":next_structure_cursor,"updated_batch":new,"failed_batch":fail[:8],"age_diag":age_diag,"priority_plan":priority_diag,"tier_selected":selected_counts,"structure_lab_coverage":coverage_after,"profile_map_sample":{k:profile_map.get(k) for k in batch[:20]},"urgent_result":urgent_result,"collection_proof":collection_proof,"rows":rows}
    semantic_digest=_cache_semantic_digest_v1012(rows,next_structure_cursor)
    nowv=now_ts(); semantic_changed=(semantic_digest!=_LAST_CACHE_SEMANTIC_DIGEST)
    publish_due=bool(not OUT.exists() or _LAST_CACHE_PUBLISH_TS<=0 or nowv-_LAST_CACHE_PUBLISH_TS>=CANDLE_CACHE_PUBLISH_MAX_SEC)
    heartbeat_due=bool(_LAST_CACHE_PUBLISH_TS>0 and nowv-_LAST_CACHE_PUBLISH_TS>=CANDLE_CACHE_HEARTBEAT_MAX_SEC)
    changed_pairs=[(before_batch_v1016.get(ticker) or {},cache[ticker]) for ticker in new if isinstance(cache.get(ticker),dict)]
    encoded_delta,delta_metrics=_v1016_prepare_delta_records(changed_pairs,nowv,_CANDLE_BASE_CHECKPOINT_ID_V1016)
    try: delta_size_before=int(CANDLE_DELTA_V1014.stat().st_size) if CANDLE_DELTA_V1014.exists() else 0
    except OSError: delta_size_before=0
    projected_delta_bytes=delta_size_before+int(delta_metrics.get('bytes') or 0)
    checkpoint_reasons=[]
    if not OUT.exists(): checkpoint_reasons.append('base_missing')
    if encoded_delta and publish_due: checkpoint_reasons.append('interval_due')
    if heartbeat_due: checkpoint_reasons.append('heartbeat_due')
    if projected_delta_bytes>=CANDLE_DELTA_MAX_BYTES: checkpoint_reasons.append('projected_cap_due')
    checkpoint_due=bool(checkpoint_reasons)
    checkpoint_success=False; checkpoint_error=''; reset_before=delta_size_before; reset_after=delta_size_before
    delta_appended_v1016=0; delta_payload_bytes_v1016=0
    if checkpoint_due:
        out['delta_checkpoint_rows_v1014']=_CANDLE_DELTA_ROWS_SINCE_CHECKPOINT_V1014+int(delta_metrics.get('records') or 0)
        out['delta_checkpoint_ts_v1014']=nowv
        out['delta_checkpoint_reason_v1016']=checkpoint_reasons
        next_checkpoint_id=f'cp-{int(nowv*1000)}-{semantic_digest[:12]}'
        out['delta_checkpoint_id_v1016']=next_checkpoint_id
        try:
            save_json(OUT,out)
            _CANDLE_BASE_CHECKPOINT_ID_V1016=next_checkpoint_id
            _LAST_CACHE_PUBLISH_TS=nowv; _LAST_CACHE_SEMANTIC_DIGEST=semantic_digest
            reset_before,reset_after=_reset_candle_delta_v1014(nowv)
            _CANDLE_DELTA_ROWS_SINCE_CHECKPOINT_V1014=0
            checkpoint_success=True
        except Exception as exc:
            checkpoint_error=f'{exc.__class__.__name__}: {str(exc)[:180]}'
            append_error(ERROR,'candle_checkpoint_v1016',exc)
            # The checkpoint failed, so preserve the current cycle through the
            # append-only delta instead of losing fresh candle data.
            _v1016_append_delta_records(encoded_delta)
            delta_appended_v1016=int(delta_metrics.get('records') or 0)
            delta_payload_bytes_v1016=int(delta_metrics.get('bytes') or 0)
            _CANDLE_DELTA_ROWS_SINCE_CHECKPOINT_V1014+=delta_appended_v1016
    else:
        _v1016_append_delta_records(encoded_delta)
        delta_appended_v1016=int(delta_metrics.get('records') or 0)
        delta_payload_bytes_v1016=int(delta_metrics.get('bytes') or 0)
        _CANDLE_DELTA_ROWS_SINCE_CHECKPOINT_V1014+=delta_appended_v1016
    try: delta_size_after=int(CANDLE_DELTA_V1014.stat().st_size) if CANDLE_DELTA_V1014.exists() else 0
    except OSError: delta_size_after=0
    sec=now_ts()-st
    write_status(
        "running", phase="done_priority_then_market_rotation", row_count=len(rows), target_count=len(targets), batch=len(new), failed=len(fail),
        tier_selected=selected_counts, structure_coverage=coverage_after, max_workers=workers, last_sec=round(sec,3), updated_batch=new, failed_batch=fail[:5],
        age_diag=age_diag, urgent_result=urgent_result, priority_policy=priority_diag.get("policy"), priority_bucket_counts=priority_diag.get("bucket_counts",{}),
        priority_lane_counts=priority_diag.get("lane_counts",{}), priority_top=priority_diag.get("top",[])[:8],
        cache_written_v1012=checkpoint_success, semantic_changed_v1012=semantic_changed, publish_due_v1012=publish_due, publish_max_sec_v1012=CANDLE_CACHE_PUBLISH_MAX_SEC,
        delta_writer_pid_v1016=os.getpid(), delta_writer_source_v1016=str(Path(__file__).resolve()), delta_writer_version_v1016=VERSION, delta_writer_build_v1016=BUILD_LABEL, delta_base_checkpoint_id_v1016=_CANDLE_BASE_CHECKPOINT_ID_V1016,
        delta_schema_v1016='candle_delta_ops_v1016', delta_changed_tickers_v1016=len(delta_metrics.get('changed_tickers') or []), delta_changed_ticker_sample_v1016=(delta_metrics.get('changed_tickers') or [])[:12],
        delta_prepared_records_v1016=int(delta_metrics.get('records') or 0), delta_appended_records_v1016=delta_appended_v1016, delta_appended_bytes_v1016=delta_payload_bytes_v1016,
        delta_avg_ops_v1016=delta_metrics.get('avg_ops'), delta_max_ops_v1016=delta_metrics.get('max_ops'), delta_avg_record_bytes_v1016=delta_metrics.get('avg_record_bytes'), delta_max_record_bytes_v1016=delta_metrics.get('max_record_bytes'),
        delta_size_before_v1016=delta_size_before, delta_projected_bytes_v1016=projected_delta_bytes, delta_size_after_v1016=delta_size_after, delta_max_bytes_v1016=CANDLE_DELTA_MAX_BYTES,
        collection_proof=collection_proof,
        checkpoint_due_v1016=checkpoint_due, checkpoint_reason_v1016=checkpoint_reasons, checkpoint_success_v1016=checkpoint_success, checkpoint_error_v1016=checkpoint_error or None,
        checkpoint_reset_before_bytes_v1016=reset_before, checkpoint_reset_after_bytes_v1016=reset_after, reset_count_v1016=_CANDLE_DELTA_RESET_COUNT_V1016,
        last_reset_ts_v1016=_CANDLE_DELTA_LAST_RESET_TS_V1016 or None, last_reset_bytes_v1016=_CANDLE_DELTA_LAST_RESET_BYTES_V1016,
        delta_rows_since_checkpoint_v1016=_CANDLE_DELTA_ROWS_SINCE_CHECKPOINT_V1014, full_checkpoint_interval_sec_v1016=CANDLE_CACHE_PUBLISH_MAX_SEC, full_checkpoint_heartbeat_sec_v1016=CANDLE_CACHE_HEARTBEAT_MAX_SEC
    )
    return {"rows":len(rows),"sec":sec,"structure_lab_coverage":coverage_after,"delta_bytes":delta_payload_bytes_v1016,"checkpoint":checkpoint_success}

def main()->None:
    # systemd/guard가 initializing에서 timeout으로 오판하지 않도록 즉시 running 상태를 남긴다.
    cache=_load_candle_memory_v1014()
    write_status("running", phase="boot_v955_priority_refresh", row_count=len(cache), target_count=0, batch=0, last_sec=0, priority_policy="v955 unchanged role-priority refresh + completed-candle identity", delta_source_v1014=CANDLE_DELTA_V1014.name)
    while True:
        try: run_once()
        except KeyboardInterrupt: write_status("stopping"); raise
        except Exception as exc: append_error(ERROR,"loop",exc); write_status("error", error=f"{exc.__class__.__name__}: {exc}")
        time.sleep(max(1.0,INTERVAL_SEC))
VERSION="candle_worker_v0.960"
BUILD_LABEL="v1016_candle_operation_delta_checkpoint_spine_2026-06-25"



# =============================================================================
# Candle v2.004 / release v2029
# Observation-only structure-line reliability source material.
# Existing v869 line prices and all existing feature values remain unchanged.
# New fields count separated completed-candle reactions to each exact major/setup/
# execution line and seal the last reaction age in bars. No strategy decision here.
# =============================================================================
def _v2029_separated_line_reaction_stats(rows: List[List[float]], level: float, side: str, tol_pct: float) -> Dict[str, Any]:
    if not rows or not level or level <= 0:
        return {'count':None,'last_bars_ago':None}
    tol=abs(float(level))*max(0.0,float(tol_pct))/100.0
    raw=[]
    for i,item in enumerate(rows):
        try:
            op,cl,hi,lo,vol=item
            touched=(lo <= level+tol and cl >= level-tol) if side=='support' else (hi >= level-tol and cl <= level+tol)
            if touched: raw.append(i)
        except Exception:
            continue
    separated=[]
    for i in raw:
        if not separated or i-separated[-1] >= 2:
            separated.append(i)
    return {
        'count':len(separated),
        'last_bars_ago':(len(rows)-1-separated[-1]) if separated else None,
    }


_V2029_PREV_CLOSED_LINE_MATERIAL = _v869_closed_line_material

def _v869_closed_line_material(c: List[List[float]]) -> Dict[str, Any]:  # type: ignore[override]
    out=_V2029_PREV_CLOSED_LINE_MATERIAL(c)
    if not isinstance(out,dict) or not out:
        return out
    closed=c[:-1] if len(c)>=6 else list(c)
    if len(closed)<3: closed=list(c)
    if not closed: return out
    close=float(closed[-1][1] or 0.0)
    scopes={
        'execution':closed[-min(30,len(closed)):],
        'setup':closed[-min(72,len(closed)):],
        'major':closed[-min(120,len(closed)):],
    }
    level_keys={
        'execution':('execution_low_price','execution_high_price'),
        'setup':('setup_support_price','setup_resistance_price'),
        'major':('major_support_price','major_resistance_price'),
    }
    for scope,rows in scopes.items():
        support_key,resistance_key=level_keys[scope]
        support=fnum(out.get(support_key),default=0.0); resistance=fnum(out.get(resistance_key),default=0.0)
        if rows and close>0:
            high=max(float(x[2]) for x in rows); low=min(float(x[3]) for x in rows)
            range_pct=max(0.0,(high-low)/close*100.0)
            tolerance=max(0.06,min(0.60,range_pct*0.08))
        else:
            range_pct=None; tolerance=None
        s=_v2029_separated_line_reaction_stats(rows,support,'support',tolerance or 0.0) if tolerance is not None else {'count':None,'last_bars_ago':None}
        r=_v2029_separated_line_reaction_stats(rows,resistance,'resistance',tolerance or 0.0) if tolerance is not None else {'count':None,'last_bars_ago':None}
        out[f'{scope}_range_pct_v2029']=round(range_pct,6) if range_pct is not None else None
        out[f'{scope}_zone_tolerance_pct_v2029']=round(tolerance,6) if tolerance is not None else None
        out[f'{scope}_lookback_rows_v2029']=len(rows)
        out[f'{scope}_support_reaction_count_v2029']=s.get('count')
        out[f'{scope}_support_last_reaction_bars_ago_v2029']=s.get('last_bars_ago')
        out[f'{scope}_resistance_reaction_count_v2029']=r.get('count')
        out[f'{scope}_resistance_last_reaction_bars_ago_v2029']=r.get('last_bars_ago')
    out['structure_reliability_material_schema_v2029']='completed_candle_role_line_reaction_material_v2029'
    out['structure_reliability_material_policy_v2029']='separated reactions min 2 bars; adaptive tolerance from same role window; observation only'
    out['structure_line_price_changed_v2029']=False
    out['trading_rules_changed_v2029']=False
    return out


def _v2029_candle_structure_reliability_issue_once() -> None:
    marker=BASE_DIR/'runtime'/'v2029_structure_reliability_candle.seeded'
    if marker.exists(): return
    try:
        ts=now_ts(); text=now_text(ts)
        append_jsonl(BASE_DIR/'runtime'/'change_verify_ledger.jsonl',{
            'schema':'change_verify_ledger_v870','change_id':'v2029-structure-reliability-candle-source-001','issue_id':'STRUCTURE-LINE-RELIABILITY-2029','version':'v2029','verify_result':'CHECK','created_ts':ts,'created_at':text,'created_text':text,'writer':'candle_v2029_lifecycle_writer',
            'symptom':'Current structure contracts choose exact lines but do not preserve role-specific repeated-reaction and last-reaction evidence for the selected major/setup line.',
            'cause':'Existing support_touch_count/resistance_touch_count describe the recent execution line, not necessarily the exact major/setup target or invalid line selected in the contract.',
            'files_changed':['candle_worker_v2.004.py','strategy_worker_v2.011.py','review_worker_v2.023.py','coinbot_main_v2_13_2029.py'],
            'new_mainline':'Candle adds observation-only completed-candle separated reaction count, last reaction bars ago, role window range and adaptive zone tolerance for exact major/setup/execution line material. Existing line prices/features stay unchanged.',
            'not_touched':['existing line prices','candidate/S1/Paper selector','trigger/invalid/target selection','RR/room/chase/cost gates','actual OPEN/exit','auto-buy OFF'],
            'remaining':'Server prove Candle v2.004 source fields are present for new candidate events and existing line values remain identical in semantic output.','auto_buy':False})
        append_jsonl(BASE_DIR/'ledger'/'issue_ledger_events.jsonl',{'schema':'coinbot_single_work_ledger_v870','event_type':'ISSUE','issue_id':'STRUCTURE-LINE-RELIABILITY-2029','status':'CHECK','title':'구조선 자체 신뢰도 Shadow 원천','detail':'완료캔들 기준 반복반응·마지막반응·시간봉 겹침용 원천만 추가. 기존 구조선 가격과 본선 계약 무변경.','version':'v2029','created_ts':ts,'created_at':text,'created_text':text,'auto_buy':False})
        marker.parent.mkdir(parents=True,exist_ok=True); marker.write_text(text,encoding='utf-8')
    except Exception: pass

try: _v2029_candle_structure_reliability_issue_once()
except Exception: pass

# v2029 structure-line reliability observation source
VERSION = 'candle_worker_v2.004'
BUILD_LABEL = 'v2029_structure_line_reliability_source_material_2026-07-15'
MAIN_DEPLOY_VERSION = BUILD_LABEL


# =============================================================================
# Candle v2.005 / release v2031
# Root source-owner repair: old *_ok frame caches created before v2029 can lack
# reliability material forever because top-level candle_ts is refreshed by short
# frames. Refresh only missing owner frames from completed candles once.
# =============================================================================
def _v2031_candle_structure_reliability_cache_refresh_issue_once() -> None:
    marker=BASE_DIR/'runtime'/'v2031_structure_reliability_owner_cache_refresh.seeded'
    if marker.exists(): return
    try:
        ts=now_ts(); text=now_text(ts)
        append_jsonl(BASE_DIR/'runtime'/'change_verify_ledger.jsonl',{
            'schema':'change_verify_ledger_v870','change_id':'v2031-structure-reliability-candle-owner-refresh-001',
            'issue_id':'STRUCTURE-LINE-RELIABILITY-2029','version':'v2031','verify_result':'CHECK','created_ts':ts,'created_at':text,'created_text':text,'writer':'candle_v2031_lifecycle_writer',
            'symptom':'v2030 server grew structure-reliability forward rows to 22 while source missing also grew to 22.',
            'cause':'Frame caches created before v2029 remained *_ok. Short-frame refresh kept top-level candle_ts fresh, so missing m30/h1/h2/h4 v2029 reaction material could be copied forward indefinitely and Strategy had no owned value to preserve.',
            'files_changed':['candle_worker_v2.005.py','review_worker_v2.024.py','coinbot_main_v2_13_2031.py'],
            'new_mainline':'At the Candle owner only, detect required structure frames that are *_ok but lack the v2029 material schema. Refresh m30 directly and h1 once, then rebuild missing h2/h4 from the same completed h1 source. Normal scheduler resumes after material exists.',
            'not_touched':['structure line formula','target/invalid selection','candidate rank','S1/Paper selector','OPEN/exit','old Shadow rows','auto-buy OFF'],
            'remaining':'Server prove post-repair new contracts have current source missing 0 and HIGH/MID/LOW grades begin growing; historical pre-repair missing rows remain reference-only.','auto_buy':False})
        append_jsonl(BASE_DIR/'ledger'/'issue_ledger_events.jsonl',{'schema':'coinbot_single_work_ledger_v870','event_type':'ISSUE','issue_id':'STRUCTURE-LINE-RELIABILITY-2029','status':'CHECK','title':'구조선 신뢰도 옛 시간봉 캐시 원천수리','detail':'v2029 전 *_ok 캐시가 새 반복반응 자료 없이 계속 복사되던 원인. Candle 주인에서 필요한 시간봉만 원천캔들로 1회 갱신.','version':'v2031','created_ts':ts,'created_at':text,'created_text':text,'auto_buy':False})
        marker.parent.mkdir(parents=True,exist_ok=True); marker.write_text(text,encoding='utf-8')
    except Exception:
        pass

try: _v2031_candle_structure_reliability_cache_refresh_issue_once()
except Exception: pass

VERSION = 'candle_worker_v2.005'
BUILD_LABEL = 'v2031_structure_reliability_owner_cache_refresh_2026-07-16'
MAIN_DEPLOY_VERSION = BUILD_LABEL


# =============================================================================
# Candle v2.006 / release v2032
# Structure-zone reliability material from already-owned completed OHLCV only.
# Adds zone width, reaction volume, rejection quality, repeated-test weakening,
# role flip, approach speed and normal-noise material. No line price or gate change.
# =============================================================================
def _v2032_median(values: List[float]) -> Optional[float]:
    vals=sorted(float(x) for x in values if isinstance(x,(int,float)) and math.isfinite(float(x)))
    if not vals: return None
    n=len(vals); mid=n//2
    return vals[mid] if n%2 else (vals[mid-1]+vals[mid])/2.0


def _v2032_percentile(values: List[float], q: float) -> Optional[float]:
    vals=sorted(float(x) for x in values if isinstance(x,(int,float)) and math.isfinite(float(x)))
    if not vals: return None
    q=max(0.0,min(1.0,float(q)))
    if len(vals)==1: return vals[0]
    pos=(len(vals)-1)*q; lo=int(math.floor(pos)); hi=int(math.ceil(pos))
    if lo==hi: return vals[lo]
    return vals[lo]+(vals[hi]-vals[lo])*(pos-lo)


def _v2032_noise_stats(rows: List[List[float]]) -> Dict[str,Any]:
    if not rows: return {'median_pct':None,'p80_pct':None,'lookback_rows':0}
    tr=[]
    prev=None
    for item in rows:
        try:
            op,cl,hi,lo,vol=item
            cl=float(cl); hi=float(hi); lo=float(lo)
            base=float(prev if prev and prev>0 else cl)
            true_range=max(hi-lo,abs(hi-base),abs(lo-base))
            if base>0: tr.append(max(0.0,true_range/base*100.0))
            prev=cl
        except Exception:
            continue
    med=_v2032_median(tr); p80=_v2032_percentile(tr,0.80)
    return {'median_pct':round(med,6) if med is not None else None,'p80_pct':round(p80,6) if p80 is not None else None,'lookback_rows':len(tr)}


def _v2032_line_detail(rows: List[List[float]], level: float, side: str, tol_pct: float, zone_pct: Optional[float]=None) -> Dict[str,Any]:
    if not rows or not level or level<=0:
        return {'source_state':'CHECK_SOURCE'}
    tol_abs=abs(level)*max(0.0,float(tol_pct))/100.0
    raw=[]
    for i,item in enumerate(rows):
        try:
            op,cl,hi,lo,vol=item
            cl=float(cl); hi=float(hi); lo=float(lo)
            touched=(lo<=level+tol_abs and cl>=level-tol_abs) if side=='support' else (hi>=level-tol_abs and cl<=level+tol_abs)
            if touched: raw.append(i)
        except Exception:
            continue
    touches=[]
    for i in raw:
        if not touches or i-touches[-1]>=2: touches.append(i)
    vols=[]
    for item in rows:
        try:
            v=float(item[4])
            if v>=0: vols.append(v)
        except Exception: pass
    baseline_vol=_v2032_median(vols)
    vol_ratios=[]; rejections=[]
    for idx in touches:
        try:
            vol=float(rows[idx][4])
            if baseline_vol and baseline_vol>0: vol_ratios.append(vol/baseline_vol)
            closes=[]
            for j in range(idx,min(len(rows),idx+3)):
                try: closes.append(float(rows[j][1]))
                except Exception: pass
            if closes:
                rej=max(0.0,(max(closes)-level)/level*100.0) if side=='support' else max(0.0,(level-min(closes))/level*100.0)
                rejections.append(rej)
        except Exception:
            continue
    first_ago=(len(rows)-1-touches[0]) if touches else None
    last_ago=(len(rows)-1-touches[-1]) if touches else None
    recent_cut=max(0,len(rows)-max(4,int(math.ceil(len(rows)/3.0))))
    recent_share=(sum(1 for x in touches if x>=recent_cut)/len(touches)) if touches else None
    recent_rej=rejections[-1] if rejections else None
    prior_med=_v2032_median(rejections[:-1]) if len(rejections)>=2 else None
    decay=(recent_rej/prior_med) if recent_rej is not None and prior_med and prior_med>0 else None
    if len(touches)<2:
        weakening='INSUFFICIENT_REACTIONS'
    elif len(touches)>=3 and recent_share is not None and recent_share>=0.5 and decay is not None and decay<0.70:
        weakening='WEAKENING'
    elif decay is not None and decay>=0.90:
        weakening='HOLDING'
    else:
        weakening='NEUTRAL'

    # Role-flip evidence must come from a prior pivot near the currently selected
    # zone. The selected line itself is a full-window high/low, so testing a break
    # beyond that same extreme would be impossible and would falsely mark every
    # line as active.
    cut=max(3,min(len(rows)-1,int(len(rows)*0.70))) if len(rows)>=5 else 0
    prior_rows=rows[:cut] if cut else []
    later_rows=rows[cut:] if cut else []
    prior_level=None
    if prior_rows:
        try:
            prior_level=(min(float(x[3]) for x in prior_rows) if side=='support' else max(float(x[2]) for x in prior_rows))
        except Exception: prior_level=None
    near_prior=bool(prior_level and abs(float(prior_level)-level)/level*100.0<=max(float(zone_pct if zone_pct is not None else tol_pct),0.08))
    flip='NO_PRIOR_PIVOT_NEAR_SELECTED_ZONE'
    confirmed=False; break_seen=False
    if near_prior and prior_level:
        ptol=abs(float(prior_level))*max(0.0,float(tol_pct))/100.0
        for i,item in enumerate(later_rows):
            try:
                cl=float(item[1])
                broke=(side=='resistance' and cl>prior_level+ptol) or (side=='support' and cl<prior_level-ptol)
                if not broke: continue
                break_seen=True
                for nxt in later_rows[i+1:]:
                    try:
                        ncl=float(nxt[1]); nhi=float(nxt[2]); nlo=float(nxt[3])
                        if side=='resistance' and nlo<=prior_level+ptol and ncl>=prior_level-ptol and ncl>=prior_level:
                            confirmed=True; break
                        if side=='support' and nhi>=prior_level-ptol and ncl<=prior_level+ptol and ncl<=prior_level:
                            confirmed=True; break
                    except Exception: pass
                if confirmed: break
            except Exception: pass
        if side=='resistance':
            flip='NEAR_ZONE_RESISTANCE_TO_SUPPORT_CONFIRMED' if confirmed else ('NEAR_ZONE_BROKEN_ABOVE_UNCONFIRMED' if break_seen else 'ORIGINAL_RESISTANCE_ACTIVE_NEAR_ZONE')
        else:
            flip='NEAR_ZONE_SUPPORT_TO_RESISTANCE_CONFIRMED' if confirmed else ('NEAR_ZONE_BROKEN_BELOW_UNCONFIRMED' if break_seen else 'ORIGINAL_SUPPORT_ACTIVE_NEAR_ZONE')

    approach_speed=None; approach_distance=None; approach_state='CHECK_SOURCE'
    if len(rows)>=2:
        bars=min(4,len(rows)-1)
        try:
            start=float(rows[-1-bars][1]); current=float(rows[-1][1])
            if side=='resistance':
                ds=(level-start)/level*100.0; dn=(level-current)/level*100.0
            else:
                ds=(start-level)/level*100.0; dn=(current-level)/level*100.0
            approach_speed=(ds-dn)/max(1,bars)
            approach_distance=dn
            if dn<0: approach_state='PAST_LINE'
            elif approach_speed>0: approach_state='APPROACHING'
            elif approach_speed<0: approach_state='MOVING_AWAY'
            else: approach_state='FLAT'
        except Exception:
            pass
    return {
        'source_state':'READY','reaction_count':len(touches),'first_reaction_bars_ago':first_ago,'last_reaction_bars_ago':last_ago,
        'reaction_volume_ratio_median':round(_v2032_median(vol_ratios),6) if _v2032_median(vol_ratios) is not None else None,
        'rejection_pct_median':round(_v2032_median(rejections),6) if _v2032_median(rejections) is not None else None,
        'recent_rejection_pct':round(recent_rej,6) if recent_rej is not None else None,
        'rejection_decay_ratio':round(decay,6) if decay is not None else None,
        'recent_touch_share':round(recent_share,6) if recent_share is not None else None,
        'weakening_state':weakening,'role_flip_state':flip,'role_flip_confirmed':confirmed,
        'approach_speed_pct_per_bar':round(approach_speed,6) if approach_speed is not None else None,
        'approach_distance_pct':round(approach_distance,6) if approach_distance is not None else None,
        'approach_state':approach_state,
    }


_V2032_PREV_CLOSED_LINE_MATERIAL=_v869_closed_line_material

def _v869_closed_line_material(c: List[List[float]]) -> Dict[str,Any]:  # type: ignore[override]
    out=_V2032_PREV_CLOSED_LINE_MATERIAL(c)
    if not isinstance(out,dict) or not out: return out
    closed=c[:-1] if len(c)>=6 else list(c)
    if len(closed)<3: closed=list(c)
    if not closed: return out
    noise=_v2032_noise_stats(closed[-min(60,len(closed)):])
    out['noise_median_pct_v2032']=noise.get('median_pct')
    out['noise_p80_pct_v2032']=noise.get('p80_pct')
    out['noise_lookback_rows_v2032']=noise.get('lookback_rows')
    scopes={'execution':closed[-min(30,len(closed)):],'setup':closed[-min(72,len(closed)):],'major':closed[-min(120,len(closed)):]}
    level_keys={'execution':('execution_low_price','execution_high_price'),'setup':('setup_support_price','setup_resistance_price'),'major':('major_support_price','major_resistance_price')}
    for scope,rows in scopes.items():
        tol=fnum(out.get(f'{scope}_zone_tolerance_pct_v2029'),default=0.0)
        zone_width=max(tol,min(1.20,max(0.0,float(noise.get('p80_pct') or 0.0))*0.60)) if tol>0 else None
        out[f'{scope}_zone_width_pct_v2032']=round(zone_width,6) if zone_width is not None else None
        support_key,resistance_key=level_keys[scope]
        for side,key in (('support',support_key),('resistance',resistance_key)):
            level=fnum(out.get(key),default=0.0)
            detail=_v2032_line_detail(rows,level,side,tol or 0.0,zone_width)
            for name,value in detail.items():
                out[f'{scope}_{side}_{name}_v2032']=value
    out['structure_zone_reliability_material_schema_v2032']='completed_candle_structure_zone_reliability_material_v2032'
    out['structure_zone_reliability_material_policy_v2032']='completed OHLCV only; adaptive zone + reaction volume + rejection + weakening + role flip + approach + normal noise; shadow only'
    out['structure_line_price_changed_v2032']=False
    out['trading_rules_changed_v2032']=False
    return out


_V2032_PREV_OWNER_MISSING=_v2031_structure_reliability_material_missing

def _v2031_structure_reliability_material_missing(prev: Dict[str,Any], prefix: str) -> bool:  # type: ignore[override]
    if _V2032_PREV_OWNER_MISSING(prev,prefix): return True
    return str(prev.get(f'{prefix}_structure_zone_reliability_material_schema_v2032') or '')!='completed_candle_structure_zone_reliability_material_v2032'


def _v2032_candle_issue_once() -> None:
    marker=BASE_DIR/'runtime'/'v2032_structure_zone_reliability_candle.seeded'
    if marker.exists(): return
    try:
        ts=now_ts(); text=now_text(ts)
        append_jsonl(BASE_DIR/'runtime'/'change_verify_ledger.jsonl',{
            'schema':'change_verify_ledger_v870','change_id':'v2032-structure-zone-reliability-candle-001','issue_id':'STRUCTURE-ZONE-RELIABILITY-2032','version':'v2032','verify_result':'CHECK','created_ts':ts,'created_at':text,'created_text':text,'writer':'candle_v2032_lifecycle_writer',
            'symptom':'Current structure Shadow uses reaction count/recency/confluence but cannot distinguish high-volume reactions, weakening repeated tests, role flips, normal-noise zones or approach context.',
            'cause':'The Candle owner had enough completed OHLCV but did not yet reduce those materials into compact role-line scalars.',
            'files_changed':['candle_worker_v2.006.py','strategy_worker_v2.013.py','review_worker_v2.025.py','coinbot_main_v2_13_2032.py'],
            'new_mainline':'Using existing completed OHLCV only, Candle produces adaptive zone width, reaction-volume ratio, rejection strength/decay, repeated-test weakening state, role-flip state, approach speed and normal-noise percentiles for exact structure roles.',
            'not_touched':['line prices','trigger/invalid/target selection','candidate rank/gates','Paper OPEN/exit','auto-buy OFF'],
            'remaining':'Server prove v2032 owner material refreshes once, new exact contracts carry READY compact material, and no Candle timing regression.','auto_buy':False})
        append_jsonl(BASE_DIR/'ledger'/'issue_ledger_events.jsonl',{'schema':'coinbot_single_work_ledger_v870','event_type':'ISSUE','issue_id':'STRUCTURE-ZONE-RELIABILITY-2032','status':'CHECK','title':'구조선 구간·신뢰도 재료 보강','detail':'기존 완료봉·거래량만으로 반응량, 밀림/회복 힘, 반복 두드림 약화, 역할전환, 정상흔들림, 접근속도를 작은 요약값으로 생산. 본선 무변경.','version':'v2032','created_ts':ts,'created_at':text,'created_text':text,'auto_buy':False})
        marker.parent.mkdir(parents=True,exist_ok=True); marker.write_text(text,encoding='utf-8')
    except Exception: pass

try: _v2032_candle_issue_once()
except Exception: pass

VERSION='candle_worker_v2.006'
BUILD_LABEL='v2032_structure_zone_reliability_material_2026-07-16'
MAIN_DEPLOY_VERSION=BUILD_LABEL


# =============================================================================
# Candle v2.007 / release v2265
# Per-timeframe source truth and full-profile refresh ownership.
# Observation/source repair only: no strategy gate, score, entry or exit change.
# =============================================================================
_V2265_PREV_FETCH_ONE = fetch_one
_V2265_PREV_URGENT_RESULT = _v608_build_urgent_result
_V2265_FRAME_SEC = {'m1':60.0,'m3':180.0,'m5':300.0,'m15':900.0,'m30':1800.0,'h1':3600.0,'h2':7200.0,'h4':14400.0}
_V2265_DIRECTION_NEED = {'m30':48,'h1':72,'h4':18}
_V2265_DIRECTION_MAX_AGE = {'m30':5400.0,'h1':10800.0,'h4':28800.0}


def _structure_lab_aggregate(rows: List[List[float]], group: int, limit: int) -> List[List[float]]:  # type: ignore[override]
    """Aggregate completed parents on their actual cadence and store target START ts.

    The old compact owner stored the last parent timestamp as the target timestamp.
    Readers then added the whole target duration again, distorting freshness and
    event-time cutoffs.  This source repair infers the exchange cadence phase,
    requires every parent slot, and writes the first parent start timestamp.
    """
    if not rows or group <= 1:
        return list(rows[-limit:]) if isinstance(rows, list) else []
    clean=[]
    for item in rows:
        if not isinstance(item,(list,tuple)) or len(item)<6: continue
        try:
            clean.append([float(item[0]),float(item[1]),float(item[2]),float(item[3]),float(item[4]),max(0.0,float(item[5]))])
        except Exception: continue
    if len(clean)<group: return []
    clean=sorted({round(x[0],3):x for x in clean}.values(),key=lambda x:x[0])
    diffs=[b[0]-a[0] for a,b in zip(clean[:-1],clean[1:]) if b[0]>a[0]]
    source_sec=_v2032_median(diffs) if diffs else None
    if source_sec is None or source_sec<=0: return []
    source_sec=float(source_sec); tolerance=max(1.0,source_sec*0.02)
    expected=int(group); best=[]; best_score=None
    for phase in range(expected):
        buckets={}
        for item in clean:
            slot=int(round(item[0]/source_sec)); bucket=(slot-phase)//expected
            buckets.setdefault(bucket,[]).append((slot,item))
        candidate=[]
        for bucket in sorted(buckets):
            chunk=sorted(buckets[bucket],key=lambda x:x[0])
            if len(chunk)!=expected: continue
            slots=[x[0] for x in chunk]
            if any(slots[i]-slots[i-1]!=1 for i in range(1,len(slots))): continue
            parents=[x[1] for x in chunk]
            if any(abs((parents[i][0]-parents[i-1][0])-source_sec)>tolerance for i in range(1,len(parents))): continue
            candidate.append([parents[0][0],parents[0][1],parents[-1][2],max(x[3] for x in parents),min(x[4] for x in parents),sum(max(0.0,x[5]) for x in parents)])
        if candidate:
            score=(len(candidate),candidate[-1][0])
            if best_score is None or score>best_score: best_score=score; best=candidate
    return best[-limit:]


def _structure_lab_snapshot(prev: Dict[str,Any], raw_by_prefix: Dict[str,List[List[float]]], fetched_prefixes: set, nowv: float) -> Dict[str,Any]:  # type: ignore[override]
    prior=prev.get('structure_lab_candles') if isinstance(prev.get('structure_lab_candles'),dict) else {}
    prior_frames=prior.get('frames') if isinstance(prior.get('frames'),dict) else {}
    prior_sources=prior.get('sources') if isinstance(prior.get('sources'),dict) else {}
    prior_success=prior.get('frame_last_fetch_success_ts_v2265') if isinstance(prior.get('frame_last_fetch_success_ts_v2265'),dict) else {}
    prior_attempt=prior.get('frame_last_fetch_attempt_ts_v2265') if isinstance(prior.get('frame_last_fetch_attempt_ts_v2265'),dict) else {}
    attempted=set(str(x) for x in (fetched_prefixes or set()))
    succeeded={tf for tf,rows in (raw_by_prefix or {}).items() if isinstance(rows,list) and rows}
    frames={};sources={};fetch_state={};success_ts={};attempt_ts={}
    for tf in ('m1','m3','m5','m30','h1'):
        rows=raw_by_prefix.get(tf);limit=int(STRUCTURE_LAB_DIRECT_LIMITS[tf])
        if isinstance(rows,list) and rows:
            frames[tf]=rows[-limit:];sources[tf]='official_exchange_completed_candles_compact'
            fetch_state[tf]='FRESH_FETCH';success_ts[tf]=nowv;attempt_ts[tf]=nowv
        elif isinstance(prior_frames.get(tf),list) and prior_frames.get(tf):
            frames[tf]=prior_frames[tf][-limit:];sources[tf]=str(prior_sources.get(tf) or 'preserved_completed_candles')
            fetch_state[tf]='FETCH_FAILED_PRESERVED' if tf in attempted else 'PRESERVED'
            success_ts[tf]=fnum(prior_success.get(tf),default=0.0);attempt_ts[tf]=nowv if tf in attempted else fnum(prior_attempt.get(tf),default=0.0)
        else:
            fetch_state[tf]='FETCH_FAILED_MISSING' if tf in attempted else 'MISSING'
            success_ts[tf]=fnum(prior_success.get(tf),default=0.0);attempt_ts[tf]=nowv if tf in attempted else fnum(prior_attempt.get(tf),default=0.0)
    if frames.get('m5'):
        frames['m15']=_structure_lab_aggregate(frames['m5'],3,STRUCTURE_LAB_DERIVED_LIMITS['m15']);sources['m15']='derived_from_official_5m_x3_completed_compact'
        parent_state=fetch_state.get('m5');fetch_state['m15']='DERIVED_FROM_FRESH_PARENT' if parent_state=='FRESH_FETCH' else 'DERIVED_FROM_PRESERVED_PARENT'
        success_ts['m15']=success_ts.get('m5',0.0);attempt_ts['m15']=attempt_ts.get('m5',0.0)
    if frames.get('h1'):
        for tf,grp in (('h2',2),('h4',4)):
            frames[tf]=_structure_lab_aggregate(frames['h1'],grp,STRUCTURE_LAB_DERIVED_LIMITS[tf]);sources[tf]=f'derived_from_official_1h_x{grp}_completed_compact'
            parent_state=fetch_state.get('h1');fetch_state[tf]='DERIVED_FROM_FRESH_PARENT' if parent_state=='FRESH_FETCH' else 'DERIVED_FROM_PRESERVED_PARENT'
            success_ts[tf]=success_ts.get('h1',0.0);attempt_ts[tf]=attempt_ts.get('h1',0.0)
    counts={k:len(v) for k,v in frames.items()}
    sufficient={tf:counts.get(tf,0)>=need for tf,need in STRUCTURE_LAB_MIN_USEFUL.items()}
    ready=all(bool(sufficient.get(tf)) for tf in STRUCTURE_LAB_MIN_USEFUL)
    state='READY' if ready else ('PARTIAL' if any(counts.values()) else 'NOT_READY')
    latest_closed={};ages={}
    for tf,sec in _V2265_FRAME_SEC.items():
        rows=frames.get(tf) or [];close_ts=(float(rows[-1][0])+sec) if rows else None
        latest_closed[tf]=close_ts;ages[tf]=max(0.0,nowv-close_ts) if close_ts is not None else None
    direction_missing=[];direction_stale=[]
    for tf,need in _V2265_DIRECTION_NEED.items():
        if counts.get(tf,0)<need: direction_missing.append(f'{tf}:bars<{need}')
        elif ages.get(tf) is None or ages[tf]>_V2265_DIRECTION_MAX_AGE[tf]: direction_stale.append(f'{tf}:age>{int(_V2265_DIRECTION_MAX_AGE[tf])}')
    direction_state='READY' if not direction_missing and not direction_stale else ('DATA_MISSING' if direction_missing else 'STALE')
    full_attempt=all(tf in attempted for tf in STRUCTURE_LAB_DIRECT_LIMITS)
    full_success=all(tf in succeeded for tf in STRUCTURE_LAB_DIRECT_LIMITS)
    prior_full=fnum(prior.get('last_full_profile_fetch_ts'),default=0.0)
    prior_full_attempt=fnum(prior.get('last_full_profile_attempt_ts_v2265'),default=0.0)
    return {
        'schema':'structure_lab_completed_ohlcv_v2265_source_truth','owner':'candle_worker','updated_ts':nowv,
        'last_full_profile_fetch_ts':nowv if full_success else prior_full,
        'last_full_profile_attempt_ts_v2265':nowv if full_attempt else prior_full_attempt,
        'full_profile_attempt_success_v2265':bool(full_success),'completed_candles_only':True,'forming_candle_excluded':True,
        'compact_row_order':['ts','o','c','h','l','v'],'frames':frames,'sources':sources,'frame_counts':counts,
        'history_min_useful':dict(STRUCTURE_LAB_MIN_USEFUL),'history_sufficient':sufficient,'source_state':state,'analysis_ready':ready,
        'frame_fetch_state_v2265':fetch_state,'frame_last_fetch_success_ts_v2265':success_ts,'frame_last_fetch_attempt_ts_v2265':attempt_ts,
        'frame_last_closed_ts_v2265':latest_closed,'frame_age_sec_v2265':ages,
        'direction_source_state_v2265':direction_state,'direction_missing_v2265':direction_missing,'direction_stale_v2265':direction_stale,
        'direction_required_bars_v2265':dict(_V2265_DIRECTION_NEED),'direction_max_age_sec_v2265':dict(_V2265_DIRECTION_MAX_AGE),
        'fetch_attempted_prefixes_v2265':sorted(attempted),'fetch_succeeded_prefixes_v2265':sorted(succeeded),
        'raw_trade_volume_profile_available':False,'candidate_quality_failed':False,
        'policy':'per-timeframe completed-candle source truth; failed full-profile attempts cannot refresh the success clock; no trading condition change',
    }


def fetch_one(ticker:str, prev: Optional[Dict[str,Any]]=None, profile: str='full_1m3m5m')->Dict[str,Any]:  # type: ignore[override]
    prev=prev if isinstance(prev,dict) else {}
    out=dict(_V2265_PREV_FETCH_ONE(ticker,prev,profile) or {})
    lab=out.get('structure_lab_candles') if isinstance(out.get('structure_lab_candles'),dict) else {}
    succeeded=list(lab.get('fetch_succeeded_prefixes_v2265') or [])
    attempt_ts=now_ts();prev_ts=fnum(prev.get('candle_ts'),default=0.0)
    out['candle_fetch_attempt_ts_v2265']=attempt_ts
    out['candle_fetch_success_v2265']=bool(succeeded)
    out['candle_fetch_succeeded_prefixes_v2265']=succeeded
    out['candle_ts']=attempt_ts if succeeded else prev_ts
    out['structure_refresh_success_ts_v2265']=fnum(lab.get('last_full_profile_fetch_ts'),default=0.0)
    out['structure_refresh_attempt_ts_v2265']=fnum(lab.get('last_full_profile_attempt_ts_v2265'),default=0.0)
    out['structure_direction_state_v2265']=lab.get('direction_source_state_v2265')
    out['source_truth_schema_v2265']='per_timeframe_fetch_success_and_completed_close_truth'
    frame_success=lab.get('frame_last_fetch_success_ts_v2265') if isinstance(lab.get('frame_last_fetch_success_ts_v2265'),dict) else {}
    for tf in ('m1','m3','m5','m30','h1'):
        out[f'{tf}_last_fetch_success_ts']=fnum(frame_success.get(tf),default=0.0)
    out['frame_refresh_owner_v2272']='structure_lab_candles.frame_last_fetch_success_ts_v2265'
    out['common_candle_ts_used_for_frame_schedule_v2272']=False
    return out


def _existing_age_map(existing: Any) -> Dict[str, Any]:  # type: ignore[override]
    out={};nowv=now_ts()
    for t,r in map_rows(existing).items():
        if not isinstance(r,dict): continue
        general_ts=fnum(r.get('candle_ts'),default=0.0)
        lab=r.get('structure_lab_candles') if isinstance(r.get('structure_lab_candles'),dict) else {}
        full_ts=fnum(lab.get('last_full_profile_fetch_ts'),r.get('structure_refresh_success_ts_v2265'),default=0.0)
        out[t]={
            'general':max(999999.0 if general_ts<=0 else 0.0,nowv-general_ts) if general_ts<=0 else max(0.0,nowv-general_ts),
            'structure':max(999999.0 if full_ts<=0 else 0.0,nowv-full_ts) if full_ts<=0 else max(0.0,nowv-full_ts),
            'direction_state':lab.get('direction_source_state_v2265'),'frame_age_sec':dict(lab.get('frame_age_sec_v2265') or {}),
        }
    return out


def _add_priority(book: Dict[str, Dict[str, Any]], ticker: str, bucket: str, base: float, target_age: float, age_map: Dict[str, Any], reason: str='', requested_profile: str='') -> None:  # type: ignore[override]
    t=ticker_norm(ticker)
    if not t:return
    group_rank=_bucket_rank(bucket);lane=_lane_from_bucket(bucket)
    allowed_profiles={'full_1m3m5m','mid_1m3m','light_1m','structure_full_htf_mtf_ltf'}
    requested_profile=str(requested_profile or '').strip()
    profile=requested_profile if requested_profile in allowed_profiles else ('structure_full_htf_mtf_ltf' if 'structure_source_missing' in str(bucket or '').lower() else _profile_from_lane(lane))
    age_info=age_map.get(t,999999.0)
    if isinstance(age_info,dict):age=fnum(age_info.get('structure' if profile=='structure_full_htf_mtf_ltf' else 'general'),default=999999.0)
    else:age=fnum(age_info,default=999999.0)
    stale_bonus=max(0.0,age-target_age)*1.2;fresh_penalty=220.0 if age<target_age*0.65 else 0.0
    score=base+stale_bonus-fresh_penalty;final_score=group_rank*10000.0+score
    cur=book.get(t);row={'ticker':t,'bucket':bucket,'lane':lane,'profile':profile,'bucket_rank':group_rank,'base':base,'target_age':target_age,
        'age':round(age,1) if age<999998 else None,'age_owner_v2265':'last_full_profile_fetch_success' if profile=='structure_full_htf_mtf_ltf' else 'last_any_successful_fetch',
        'score':round(score,2),'final_score':round(final_score,2),'reason':reason,'profile_sources':[profile]}
    if not cur:book[t]=row;return
    merged_profile=_deeper_profile(str(cur.get('profile') or ''),profile);sources=[]
    for x in list(cur.get('profile_sources') or [])+[str(cur.get('profile') or ''),profile]:
        if x and x not in sources:sources.append(x)
    if final_score>float(cur.get('final_score',-999999)):
        row['profile']=merged_profile;row['profile_sources']=sources;row['profile_preserved_from_other_request']=bool(len(sources)>1);book[t]=row
    else:
        cur['profile']=merged_profile;cur['profile_sources']=sources;cur['profile_preserved_from_other_request']=bool(len(sources)>1)


def _v608_build_urgent_result(urgent_rows: List[Dict[str, Any]], new: List[str], fail: List[Dict[str, Any]], cache: Dict[str, Dict[str, Any]], batch: Optional[List[str]]=None, profile_map: Optional[Dict[str,str]]=None) -> Dict[str, Any]:  # type: ignore[override]
    obj=dict(_V2265_PREV_URGENT_RESULT(urgent_rows,new,fail,cache,batch,profile_map) or {})
    for rec in obj.get('rows') or []:
        if not isinstance(rec,dict):continue
        t=ticker_norm(rec.get('ticker'));row=cache.get(t) if isinstance(cache,dict) and isinstance(cache.get(t),dict) else {}
        lab=row.get('structure_lab_candles') if isinstance(row.get('structure_lab_candles'),dict) else {}
        rec['direction_source_state_v2265']=lab.get('direction_source_state_v2265')
        rec['direction_missing_v2265']=list(lab.get('direction_missing_v2265') or [])
        rec['direction_stale_v2265']=list(lab.get('direction_stale_v2265') or [])
        rec['frame_fetch_state_v2265']=dict(lab.get('frame_fetch_state_v2265') or {})
        rec['full_profile_fetch_success_v2265']=bool(lab.get('full_profile_attempt_success_v2265'))
    try:save_json(CANDLE_URGENT_RESULT,obj)
    except Exception:pass
    return obj

VERSION='candle_worker_v2.007'
BUILD_LABEL='v2265_per_timeframe_candle_source_truth_2026-07-28'
MAIN_DEPLOY_VERSION=BUILD_LABEL

# Candle v2.010 / release v2272
# Per-timeframe successful-refresh owner repair. Existing source and queue only.
VERSION="candle_worker_v2.010"
BUILD_LABEL="v2272_per_timeframe_refresh_owner_repair_2026-07-29"
MAIN_DEPLOY_VERSION=BUILD_LABEL
V2272_REFRESH_POLICY={
    "frame_schedule_owner":"structure_lab_candles.frame_last_fetch_success_ts_v2265",
    "common_candle_ts_used_for_frame_schedule":False,
    "failed_fetch_updates_success_ts":False,
    "candidate_universe_preserved":True,
    "new_queue_created":False,
    "strategy_threshold_changed":False,
    "auto_buy":False,
}

def _v2272_candle_owner_ledger_once() -> None:
    marker=BASE_DIR/'runtime'/'v2272_per_timeframe_refresh_owner.seeded'
    if marker.exists(): return
    ts=now_ts(); text=datetime.fromtimestamp(ts).astimezone().strftime('%Y-%m-%d %H:%M:%S %Z')
    append_jsonl(BASE_DIR/'ledger'/'change_verify_ledger_events.jsonl',{
        'schema':'coinbot_single_work_ledger_v870','event_type':'CHANGE_VERIFY','version':'v2272','status':'CHECK',
        'title':'시간축별 캔들 갱신시각 Owner 수리','created_ts':ts,'created_at':text,
        'cause':'공통 candle_ts가 짧은 봉 성공만으로 최신화되어 m30·h1 재수집 판단을 계속 미루던 오류',
        'files_changed':['candle_worker_v2.010.py','candle_worker.py'],
        'new_mainline':'기존 v2265 시간축별 실제 성공시각을 재수집 판단의 단일 Owner로 사용',
        'not_touched':['후보 수','상승예측 조건','trigger/invalid/target','Paper OPEN/CLOSED','자동매수 OFF'],
        'remaining':'서버에서 466개 전체 순환과 m30·h1 지연·DATA_MISSING 감소를 Runtime 검증','auto_buy':False})
    append_jsonl(BASE_DIR/'ledger'/'issue_ledger_events.jsonl',{
        'schema':'coinbot_single_work_ledger_v870','event_type':'ISSUE','issue_id':'CANDLE-PER-TF-REFRESH-OWNER-2272',
        'status':'CHECK','title':'공통 candle_ts 장기봉 갱신 억제 오류','detail':'로컬 단위검수 PASS, 서버 Runtime 미검증',
        'version':'v2272','created_ts':ts,'created_at':text,'auto_buy':False})
    marker.parent.mkdir(parents=True,exist_ok=True); marker.write_text(text,encoding='utf-8')

try: _v2272_candle_owner_ledger_once()
except Exception: pass

# v2271 full-universe rotation remains active underneath v2272.
V2271_REFRESH_POLICY={
    "candidate_universe_preserved":True,
    "full_universe_refresh_guaranteed":True,
    "new_queue_created":False,
    "strategy_threshold_changed":False,
    "auto_buy":False,
}


# =============================================================================
# Candle v2.011 / release v2273
# Canonical direction-frame refresh rotation repair.
# Root cause: v2271 reserved full-universe slots only for structure coverage
# backfill. Once every ticker had a structure_lab row, that pending set became
# empty even when m30/h1/h4 completed bars were stale. The remaining scheduler
# ranked by top-level candle_ts (mostly 1m freshness), so long-frame refresh had
# no guaranteed owner path and READY/STALE oscillated.
# =============================================================================
_V2273_PREV_PRIORITY_PLAN = _priority_plan
_V2273_PREV_PICK_TIERED_BATCH = _pick_tiered_batch
_V2273_DIRECTION_EARLY_AGE = {'m30':3600.0, 'h1':7200.0, 'h4':21600.0}


def _v2273_direction_refresh_rows(existing_map: Dict[str, Dict[str, Any]], universe: List[str]) -> List[Dict[str, Any]]:
    rows=[]
    for raw_t in universe:
        t=ticker_norm(raw_t)
        r=existing_map.get(t) if isinstance(existing_map.get(t),dict) else {}
        lab=r.get('structure_lab_candles') if isinstance(r.get('structure_lab_candles'),dict) else {}
        counts=lab.get('frame_counts') if isinstance(lab.get('frame_counts'),dict) else {}
        ages=lab.get('frame_age_sec_v2265') if isinstance(lab.get('frame_age_sec_v2265'),dict) else {}
        state=str(lab.get('direction_source_state_v2265') or '')
        reasons=[]; urgency=0.0
        for tf,need in _V2265_DIRECTION_NEED.items():
            cnt=int(fnum(counts.get(tf),default=0.0))
            age=fnum(ages.get(tf),default=999999.0)
            early=float(_V2273_DIRECTION_EARLY_AGE[tf])
            if cnt < int(need):
                reasons.append(f'{tf}:bars<{int(need)}')
                urgency=max(urgency,10.0+(int(need)-cnt)/max(1.0,float(need)))
            elif age >= early:
                reasons.append(f'{tf}:age>={int(early)}')
                urgency=max(urgency,age/max(1.0,early))
        if state in ('DATA_MISSING','STALE') and not reasons:
            reasons.append(f'state:{state}')
            urgency=max(urgency,9.0)
        if reasons:
            rows.append({'ticker':t,'urgency':round(urgency,6),'reasons':reasons,'direction_state':state or 'UNKNOWN'})
    rows.sort(key=lambda x:(float(x.get('urgency') or 0.0),str(x.get('ticker') or '')),reverse=True)
    return rows


def _priority_plan(existing: Any) -> Tuple[List[str], Dict[str, Any]]:  # type: ignore[override]
    targets,diag=_V2273_PREV_PRIORITY_PLAN(existing)
    existing_map=map_rows(existing)
    universe=list(diag.get('structure_coverage_universe') or targets or [])
    direction_rows=_v2273_direction_refresh_rows(existing_map,universe)
    diag=dict(diag)
    diag['direction_refresh_pending_v2273']=direction_rows
    diag['direction_refresh_pending_count_v2273']=len(direction_rows)
    diag['direction_refresh_owner_v2273']='structure_lab_candles.frame_age_sec_v2265 + frame_counts'
    diag['direction_refresh_early_age_v2273']=dict(_V2273_DIRECTION_EARLY_AGE)
    diag['direction_refresh_policy_v2273']='same canonical Candle owner; reserve existing batch slots before stale; no new queue'
    return targets,diag


def _pick_tiered_batch(priority_diag: Dict[str, Any], targets: List[str], structure_cursor: int=0) -> Tuple[List[str], Dict[str, str], Dict[str, int], int]:  # type: ignore[override]
    batch,profiles,counts,next_cursor=_V2273_PREV_PICK_TIERED_BATCH(priority_diag,targets,structure_cursor=structure_cursor)
    direction_rows=priority_diag.get('direction_refresh_pending_v2273') if isinstance(priority_diag.get('direction_refresh_pending_v2273'),list) else []
    if not direction_rows:
        counts=dict(counts); counts['direction_refresh_reserved_v2273']=0; counts['direction_refresh_pending_v2273']=0
        return batch,profiles,counts,next_cursor

    # Rotate over all due direction rows. Keep core/near live slots; replace only
    # the lowest-priority watch/broad tail when the batch is already full.
    due=[ticker_norm(x.get('ticker')) for x in direction_rows if isinstance(x,dict) and ticker_norm(x.get('ticker'))]
    if not due:
        counts=dict(counts); counts['direction_refresh_reserved_v2273']=0; counts['direction_refresh_pending_v2273']=0
        return batch,profiles,counts,next_cursor
    cur=max(0,int(structure_cursor or 0))%len(due)
    reserve=min(max(4,BATCH//5),BATCH,len(due))
    lane_by_t={}
    for row in priority_diag.get('plan_rows') or []:
        if isinstance(row,dict): lane_by_t[ticker_norm(row.get('ticker'))]=str(row.get('lane') or _lane_from_bucket(str(row.get('bucket') or '')))
    added=0; scanned=0
    while scanned<len(due) and added<reserve:
        t=due[(cur+scanned)%len(due)]; scanned+=1
        if t in batch:
            profiles[t]='structure_full_htf_mtf_ltf'
            added+=1
            continue
        if len(batch)>=BATCH:
            victim=None
            for idx in range(len(batch)-1,-1,-1):
                bt=batch[idx]
                if lane_by_t.get(bt,'broad') not in ('core','near') and profiles.get(bt)!='structure_full_htf_mtf_ltf':
                    victim=idx; break
            if victim is None:
                continue
            old=batch.pop(victim); profiles.pop(old,None)
        batch.append(t); profiles[t]='structure_full_htf_mtf_ltf'; added+=1
    next_cursor=(cur+max(1,scanned))%len(due)
    counts=dict(counts)
    counts['direction_refresh_reserved_v2273']=added
    counts['direction_refresh_pending_v2273']=len(due)
    counts['direction_refresh_owner_v2273']='canonical frame age/count'
    return list(dict.fromkeys(batch)),profiles,counts,next_cursor

VERSION="candle_worker_v2.011"
BUILD_LABEL="v2273_canonical_direction_refresh_rotation_2026-07-29"
MAIN_DEPLOY_VERSION=BUILD_LABEL
V2273_REFRESH_POLICY={
    'owner':'candle_worker.structure_lab_candles',
    'writer_count':1,
    'reader_schedule_source':'frame_age_sec_v2265 + frame_counts',
    'top_level_candle_ts_for_direction_schedule':False,
    'guaranteed_existing_batch_rotation':True,
    'new_queue_created':False,
    'strategy_threshold_changed':False,
    'auto_buy':False,
}

def _v2273_candle_owner_ledger_once() -> None:
    marker=BASE_DIR/'runtime'/'v2273_canonical_direction_refresh_rotation.seeded'
    if marker.exists(): return
    ts=now_ts(); text=datetime.fromtimestamp(ts).astimezone().strftime('%Y-%m-%d %H:%M:%S %Z')
    append_jsonl(BASE_DIR/'ledger'/'change_verify_ledger_events.jsonl',{
        'schema':'coinbot_single_work_ledger_v870','event_type':'CHANGE_VERIFY','version':'v2273','status':'CHECK',
        'title':'466개 장기봉 canonical 갱신 순환 단일화','created_ts':ts,'created_at':text,
        'cause':'v2271 전체순환 예약이 실제 장기봉 stale가 아니라 structure coverage 미완료만 보아, coverage 완료 뒤 m30/h1/h4 갱신 보장 슬롯이 사라짐',
        'files_changed':['candle_worker_v2.011.py','candle_worker.py'],
        'new_mainline':'Candle의 canonical frame age/count만으로 장기봉 갱신 필요 코인을 뽑고 기존 batch 안에서 매 cycle 예약 순환',
        'not_touched':['후보 수','상승예측 조건','trigger/invalid/target','Paper OPEN/CLOSED','자동매수 OFF'],
        'remaining':'서버에서 자료정상·m30/h1/h4 지연·DATA_MISSING이 여러 cycle 동안 안정적으로 개선되는지 Runtime 검증','auto_buy':False})
    append_jsonl(BASE_DIR/'ledger'/'issue_ledger_events.jsonl',{
        'schema':'coinbot_single_work_ledger_v870','event_type':'ISSUE','issue_id':'CANDLE-DIRECTION-ROTATION-OWNER-2273',
        'status':'CHECK','title':'coverage 완료 후 장기봉 갱신 예약 소멸','detail':'코드 원인 수리 및 로컬 검수 PASS, 서버 Runtime 미검증',
        'version':'v2273','created_ts':ts,'created_at':text,'auto_buy':False})
    marker.parent.mkdir(parents=True,exist_ok=True); marker.write_text(text,encoding='utf-8')

try: _v2273_candle_owner_ledger_once()
except Exception: pass



# =============================================================================
# Candle v2.008 / release v2268
# Existing urgent queue throughput repair only. No new queue or trading change.
# =============================================================================
VERSION="candle_worker_v2.008"
BUILD_LABEL="v2268_existing_refresh_queue_throughput_repair_2026-07-28"
MAIN_DEPLOY_VERSION=BUILD_LABEL
V2268_RECOVERY_POLICY={
    "existing_queue_reused":True,"new_queue_created":False,"default_batch":BATCH,
    "default_max_workers":MAX_WORKERS,"full_profile_batch":STRUCTURE_FULL_PROFILE_BATCH,
    "priority":"core material stale requests before watch/broad rotation",
    "candidate_changed":False,"strategy_threshold_changed":False,"auto_buy":False}


# =============================================================================
# Candle v2.012 / release v2274
# Full due-universe first sweep + automatic retry.
# Approved operation rule:
# - inspect all market tickers every cycle through the existing canonical cache;
# - fetch every ticker whose required completed direction frames are missing/stale;
# - use the existing bounded thread pool (no new queue/service/cache);
# - failed/missed tickers remain due and are retried on the next cycle;
# - once caught up, only newly due tickers are fetched.
# =============================================================================
_V2274_PREV_PICK_TIERED_BATCH = _pick_tiered_batch
_V2274_FULL_DUE_MAX = max(BATCH, int(os.getenv('CANDLE_WORKER_FULL_DUE_MAX', '466')))


def _pick_tiered_batch(priority_diag: Dict[str, Any], targets: List[str], structure_cursor: int=0) -> Tuple[List[str], Dict[str, str], Dict[str, int], int]:  # type: ignore[override]
    batch, profiles, counts, next_cursor = _V2274_PREV_PICK_TIERED_BATCH(
        priority_diag, targets, structure_cursor=structure_cursor
    )
    direction_rows = priority_diag.get('direction_refresh_pending_v2273')
    if not isinstance(direction_rows, list):
        direction_rows = []

    # Canonical due list is already calculated from the single Candle owner:
    # structure_lab_candles.frame_counts + frame_age_sec_v2265.
    due=[]
    for row in direction_rows:
        if not isinstance(row, dict):
            continue
        ticker=ticker_norm(row.get('ticker'))
        if ticker and ticker not in due:
            due.append(ticker)

    # First sweep: attempt every due ticker in this same run.  Concurrency remains
    # bounded by MAX_WORKERS, so this expands coverage without creating a second
    # worker, queue, cache, or writer.  Any failed ticker keeps its old canonical
    # frame age/count and therefore remains due for the next run automatically.
    capacity=max(BATCH, min(_V2274_FULL_DUE_MAX, max(len(batch), len(due))))
    for ticker in due:
        if len(batch) >= capacity:
            break
        if ticker not in batch:
            batch.append(ticker)
        profiles[ticker]='structure_full_htf_mtf_ltf'

    # Keep stable order and no duplicates. Existing core/near rows remain first;
    # all additional due rows follow in canonical urgency order.
    batch=list(dict.fromkeys(batch))
    counts=dict(counts)
    counts['full_due_pending_v2274']=len(due)
    counts['full_due_selected_v2274']=sum(1 for t in due if t in batch)
    counts['full_due_unselected_v2274']=max(0,len(due)-counts['full_due_selected_v2274'])
    counts['full_due_max_v2274']=_V2274_FULL_DUE_MAX
    counts['full_due_retry_policy_v2274']='failed_or_stale_remains_due_next_cycle'
    counts['full_due_owner_v2274']='structure_lab_candles.frame_counts+frame_age_sec_v2265'
    return batch, profiles, counts, next_cursor


VERSION='candle_worker_v2.013'
BUILD_LABEL='v2275_single_entrypoint_full_due_runtime_activation_2026-07-29'
MAIN_DEPLOY_VERSION=BUILD_LABEL
V2274_COLLECTION_POLICY={
    'inspect_universe_each_cycle':True,
    'attempt_all_due_same_run':True,
    'due_max':_V2274_FULL_DUE_MAX,
    'bounded_existing_workers':MAX_WORKERS,
    'retry_failed_next_cycle':True,
    'owner':'candle_worker.structure_lab_candles',
    'writer_count':1,
    'new_queue_created':False,
    'new_worker_created':False,
    'new_cache_created':False,
    'strategy_threshold_changed':False,
    'auto_buy':False,
}


def _v2274_candle_owner_ledger_once() -> None:
    marker=BASE_DIR/'runtime'/'v2274_full_due_first_sweep_retry.seeded'
    if marker.exists():
        return
    ts=now_ts()
    text=datetime.fromtimestamp(ts).astimezone().strftime('%Y-%m-%d %H:%M:%S %Z')
    append_jsonl(BASE_DIR/'ledger'/'change_verify_ledger_events.jsonl',{
        'schema':'coinbot_single_work_ledger_v870','event_type':'CHANGE_VERIFY',
        'version':'v2274','status':'CHECK','ts':ts,'text':text,
        'issue_id':'CANDLE-FULL-DUE-COVERAGE-001',
        'symptom':'466개 canonical 후보를 확인하지만 장기 완료봉 due 전용 선택이 고정 소수라 갱신대기가 cycle 사이 재누적됨.',
        'root_cause':'기존 scheduler가 due 전체를 계산한 뒤에도 기존 BATCH 안의 일부만 선택해 같은 run에서 전체 due 수집 시도를 완료하지 못함.',
        'files_changed':['candle_worker.py','candle_worker_v2.012.py'],
        'new_mainline':'canonical due 전체 계산 -> 기존 bounded ThreadPool로 같은 run 안에 전부 수집 시도 -> 실패/미갱신은 canonical due로 남아 다음 cycle 자동 재시도',
        'not_touched':['strategy thresholds','candidate count','Paper OPEN/CLOSED','trade/decision/exact ledgers','auto-buy'],
        'verify_result':'LOCAL_COMPILE_PASS_SERVER_RUNTIME_CHECK',
        'remaining':'서버에서 full_due_selected_v2274=pending, unselected=0 및 여러 cycle DATA_MISSING 재급증 없음 확인.'
    })
    append_jsonl(BASE_DIR/'ledger'/'issue_ledger_events.jsonl',{
        'schema':'coinbot_issue_ledger_v870','event_type':'ISSUE','version':'v2274',
        'issue_id':'CANDLE-FULL-DUE-COVERAGE-001','status':'CHECK','ts':ts,'text':text,
        'owner':'candle_worker','cause':'due 전체 미선택','impact':'자료정상/갱신대기 반복 진동',
        'resolution':'기존 owner와 worker pool 안에서 due 전체 same-run 수집 및 실패 자동 재시도',
        'remaining':'SERVER_RUNTIME_CHECK'
    })
    try:
        marker.parent.mkdir(parents=True,exist_ok=True)
        marker.write_text(text+'\n',encoding='utf-8')
    except Exception as exc:
        append_error(ERROR,'v2274_ledger_marker',exc)


try:
    _v2274_candle_owner_ledger_once()
except Exception as _v2274_ledger_exc:
    try:
        append_error(ERROR,'v2274_ledger_once',_v2274_ledger_exc)
    except Exception:
        pass


# v2276: collection-stage proof only. No source, queue, strategy, or trading change.
VERSION='candle_worker_v2.014'
BUILD_LABEL='v2276_candle_collection_stage_proof_2026-07-29'
MAIN_DEPLOY_VERSION=BUILD_LABEL

def _candle_collection_proof_ledger_once() -> None:
    marker=BASE_DIR/'runtime'/'candle_collection_stage_proof.seeded'
    if marker.exists(): return
    ts=now_ts(); text=now_text(ts)
    append_jsonl(BASE_DIR/'ledger'/'change_verify_ledger_events.jsonl',{
        'schema':'coinbot_single_work_ledger_v870','event_type':'CHANGE_VERIFY','version':'v2276','status':'CHECK',
        'title':'캔들 수집 단계별 실제 성공 증명','created_ts':ts,'created_at':text,
        'cause':'기존 run은 ThreadPool에서 row가 반환되면 성공처럼 집계했지만, 시간축 API 실패는 fetch_one 내부에서 보존자료로 흡수되어 실제 요청·성공·실패가 보이지 않았음',
        'files_changed':['candle_worker.py','candle_worker_v2.014.py'],
        'new_mainline':'선택수→시간축 요청수→실제 성공수→실패수→보존자료 사용수를 동일 Candle status에 기록',
        'not_touched':['수집 원천','배치/동시성','후보','전략 조건','Paper 원장','자동매수 OFF'],
        'remaining':'서버 collection_proof로 API 실패·rate limit·저장 전 실패 중 실제 원인을 확정','auto_buy':False})
    append_jsonl(BASE_DIR/'ledger'/'issue_ledger_events.jsonl',{
        'schema':'coinbot_single_work_ledger_v870','event_type':'ISSUE','issue_id':'CANDLE-COLLECTION-PROOF',
        'status':'CHECK','title':'캔들 실제 수집 성공과 row 반환 혼동','detail':'실패를 보존자료로 흡수해 Thread 완료만으로는 실제 갱신 성공을 증명하지 못함',
        'version':'v2276','created_ts':ts,'created_at':text,'auto_buy':False})
    marker.parent.mkdir(parents=True,exist_ok=True); marker.write_text(text,encoding='utf-8')

try: _candle_collection_proof_ledger_once()
except Exception: pass

# All runtime overrides are defined before the sole process entrypoint.
if __name__ == "__main__":
    main()
