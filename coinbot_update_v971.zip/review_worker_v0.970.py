#!/usr/bin/env python3
# -*- coding: utf-8 -*-
from __future__ import annotations
import json, os, time, traceback, gzip, math
from pathlib import Path
from typing import Any, Dict, List, Optional
from collections import Counter

BASE_DIR = Path(os.getenv("TRADING_BOT_DIR", "/home/dangdang971216/trading_bot"))
VERSION = "review_worker_v0.970"
INTERVAL_SEC = float(os.getenv("REVIEW_WORKER_INTERVAL_SEC", "30"))
RETENTION_DAYS = float(os.getenv("REVIEW_RETENTION_DAYS", "0.25"))
ACTIVE_REVIEW_MAX = int(os.getenv("REVIEW_ACTIVE_MAX", "180"))
TRIGGER_SHADOW_PENDING_TTL_SEC = float(os.getenv("TRIGGER_SHADOW_PENDING_TTL_SEC", "900"))
TRIGGER_SHADOW_ENTERED_TTL_SEC = float(os.getenv("TRIGGER_SHADOW_ENTERED_TTL_SEC", "3600"))
TRIGGER_SHADOW_ACTIVE_MAX = int(os.getenv("TRIGGER_SHADOW_ACTIVE_MAX", "900"))
SOURCE_SNAPSHOT_LINES = int(os.getenv("REVIEW_SOURCE_SNAPSHOT_LINES", "260"))

STATUS = BASE_DIR / "clean_review_worker_status.json"
ERROR = BASE_DIR / "clean_review_worker_error.log"
CLOSED = BASE_DIR / "paper_bot_closed.jsonl"
OPEN = BASE_DIR / "paper_bot_open.json"
PAPER_LATEST = BASE_DIR / "paper_candidates_latest.jsonl"
GOOD_S2_OBSERVATION_LEDGER = BASE_DIR / "good_s2_observation_ledger.jsonl"
GOOD_S2_RESULT_STATE = BASE_DIR / "good_s2_result_state_v923.json"
GOOD_S2_RESULT_SNAPSHOT = BASE_DIR / "good_s2_result_snapshot.json"
GOOD_S2_RESULT_LEDGER = BASE_DIR / "good_s2_result_ledger.jsonl"
GOOD_S2_RESULT_HORIZON_SEC = 6 * 3600.0
GOOD_S2_RESULT_RETENTION_SEC = 7 * 86400.0
GOOD_S2_RESULT_RESET_META_V925 = BASE_DIR / 'quarantine' / 'good_s2_result_state_reset_meta_v925.json'
GOOD_S2_RESULT_RESET_META_V926 = BASE_DIR / 'quarantine' / 'good_s2_result_source_spine_reset_meta_v926.json'
FEATURE = BASE_DIR / "clean_feature_cache.json"
ORDERFLOW = BASE_DIR / "clean_orderflow_summary_cache.json"
REGIME = BASE_DIR / "clean_market_regime_cache.json"
QUEUE = BASE_DIR / "clean_missed_review_queue.json"
STATE = BASE_DIR / "clean_missed_review_state.json"
SUMMARY = BASE_DIR / "clean_missed_review_summary.json"
OLD_SUMMARY = BASE_DIR / "clean_review_summary.json"
TRIGGER_SHADOW_CANDIDATES = BASE_DIR / "clean_trigger_shadow_candidates_v665.json"
TRIGGER_SHADOW_STATE = BASE_DIR / "clean_trigger_shadow_state_v665.json"
TRIGGER_SHADOW_SUMMARY = BASE_DIR / "clean_trigger_shadow_review_v665.json"
MARKET_MISS_CANDIDATES = BASE_DIR / "clean_market_miss_candidates_v667.json"
MARKET_MISS_STATE = BASE_DIR / "clean_market_miss_state_v667.json"
MARKET_MISS_SUMMARY = BASE_DIR / "clean_market_miss_review_v667.json"
QUALITY_SHADOW_STATE = BASE_DIR / "clean_quality_shadow_state_v946.json"
QUALITY_SHADOW_STATUS = BASE_DIR / "clean_quality_shadow_status_v946.json"
QUALITY_SHADOW_LEDGER = BASE_DIR / "quality_shadow_result_ledger_v946.jsonl"
QUALITY_SHADOW_RETENTION_SEC = float(os.getenv("QUALITY_SHADOW_RETENTION_SEC", str(3 * 3600)))
QUALITY_SHADOW_FINAL_GRACE_SEC = float(os.getenv("QUALITY_SHADOW_FINAL_GRACE_SEC", "300"))
# Safety ceiling only. Unfinished records are retained by time until the 60m horizon,
# so a busy market cannot evict them merely because a count cap was reached.
QUALITY_SHADOW_SAFETY_MAX_RECORDS = int(os.getenv("QUALITY_SHADOW_SAFETY_MAX_RECORDS", "20000"))
QUALITY_SHADOW_ARCHIVE = BASE_DIR / "quality_shadow_archive"
QUALITY_SHADOW_LEDGER_MAX_BYTES = int(os.getenv("QUALITY_SHADOW_LEDGER_MAX_BYTES", str(50 * 1024 * 1024)))
QUALITY_SHADOW_LEDGER_KEEP_LINES = int(os.getenv("QUALITY_SHADOW_LEDGER_KEEP_LINES", "5000"))
_QUALITY_FINAL_KEYS_CACHE: Optional[set[str]] = None
QUALITY_SHADOW_HORIZONS = (("1m",60.0),("3m",180.0),("5m",300.0),("10m",600.0),("20m",1200.0),("60m",3600.0))
LATE_PATH_STATUS = BASE_DIR / "clean_late_path_status_v947.json"
PAPER_DECISION_STATE = BASE_DIR / "paper_decision_state_v926.json"
SAMPLE_BOARD_STATUS = BASE_DIR / 'clean_sample_board_status_v948.json'
SMART_STRUCTURE_CANDIDATES = BASE_DIR / 'clean_smart_structure_shadow_candidates_v948.json'
SMART_STRUCTURE_STATE = BASE_DIR / 'clean_smart_structure_shadow_state_v948.json'
SMART_STRUCTURE_STATUS = BASE_DIR / 'clean_smart_structure_shadow_review_status_v948.json'
SMART_STRUCTURE_HORIZONS = (('1m',60.0),('3m',180.0),('5m',300.0),('10m',600.0),('20m',1200.0),('60m',3600.0))
STRUCTURE_LAB_CANDIDATES = BASE_DIR / 'clean_structure_lab_candidates_v956.json'
STRUCTURE_LAB_STRATEGY_STATUS = BASE_DIR / 'clean_structure_lab_strategy_status_v956.json'
STRUCTURE_LAB_STATE_V952 = BASE_DIR / 'clean_structure_lab_state_v952.json'
STRUCTURE_LAB_STATE_V955 = BASE_DIR / 'clean_structure_lab_state_v955.json'
STRUCTURE_LAB_ACTIVE_STATE = BASE_DIR / 'clean_structure_lab_active_state_v956.json'
STRUCTURE_LAB_REVIEW_STATUS = BASE_DIR / 'clean_structure_lab_review_status_v956.json'
STRUCTURE_MISSED_STATE_V952 = BASE_DIR / 'clean_structure_missed_state_v952.json'
STRUCTURE_MISSED_STATE_V955 = BASE_DIR / 'clean_structure_missed_state_v955.json'
STRUCTURE_MISSED_STATE = BASE_DIR / 'clean_structure_missed_state_v956.json'
STRUCTURE_MISSED_STATUS = BASE_DIR / 'clean_structure_missed_status_v956.json'
STRUCTURE_LAB_EVENT_DETAIL_LEDGER_LEGACY = BASE_DIR / 'structure_lab_event_detail_ledger_v955.jsonl'
STRUCTURE_LAB_EVENT_DETAIL_LEDGER = BASE_DIR / 'structure_lab_event_detail_ledger_v956.jsonl'
STRUCTURE_LAB_HORIZON_LEDGER = BASE_DIR / 'structure_lab_horizon_result_ledger_v956.jsonl'
STRUCTURE_LAB_HORIZON_SUMMARY = BASE_DIR / 'clean_structure_lab_horizon_summary_v956.json'
STRUCTURE_LAB_FINAL_LEDGER = BASE_DIR / 'structure_lab_event_final_ledger_v956.jsonl'
STRUCTURE_REVIEW_UPDATE_BUDGET = max(60, int(os.getenv('STRUCTURE_REVIEW_UPDATE_BUDGET', '420')))
STRUCTURE_REVIEW_FAST_SEC = float(os.getenv('STRUCTURE_REVIEW_FAST_SEC', '30'))
STRUCTURE_REVIEW_MID_SEC = float(os.getenv('STRUCTURE_REVIEW_MID_SEC', '60'))
STRUCTURE_REVIEW_SLOW_SEC = float(os.getenv('STRUCTURE_REVIEW_SLOW_SEC', '180'))
STRUCTURE_LAB_HORIZONS = (('1m',60.0),('3m',180.0),('5m',300.0),('10m',600.0),('20m',1200.0),('60m',3600.0),('120m',7200.0),('240m',14400.0))
STRUCTURE_LAB_RETENTION_SEC = 5 * 3600.0
PERFORMANCE_LAB_STATUS = BASE_DIR / 'clean_performance_lab_status_v959.json'
PERFORMANCE_STRUCTURE_INDEX = BASE_DIR / 'clean_performance_structure_index_v959.json'
PAPER_EXECUTION_COST_LEDGER = BASE_DIR / 'paper_execution_cost_ledger.jsonl'
PERFORMANCE_COST_INDEX = BASE_DIR / 'clean_performance_cost_index.json'
PERFORMANCE_C_SHADOW_INDEX = BASE_DIR / 'clean_performance_c_break_retest_shadow_index_v962.json'
QUALITY_EVENT_CONTEXT_SCHEMA = 'quality_event_context_v965'
QUALITY_EVENT_CONTEXT_MIGRATION_SCHEMA = 'quality_event_context_migration_v965'
PERFORMANCE_STRUCTURE_METHODS = ('A_SWING','B_REACTION_ZONE','C_BREAK_RETEST','D_SUPPLY_DEMAND','E_VOLUME_PROFILE')
PERFORMANCE_STRUCTURE_HORIZONS = tuple(label for label,_sec in STRUCTURE_LAB_HORIZONS)
PERFORMANCE_FEE_SOURCE_STATUS = 'WAITING_EXACT_FEE_SOURCE'

def now_ts() -> float: return time.time()
def now_text(ts: Optional[float]=None) -> str: return time.strftime("%Y-%m-%d %H:%M:%S", time.localtime(ts or now_ts()))
def fnum(*vals: Any, default: float=0.0) -> float:
    for v in vals:
        try:
            if v is None or v == "": continue
            return float(str(v).replace(",", "").replace("%", ""))
        except Exception: continue
    return default

def load_json(path: Path, default: Any=None) -> Any:
    try:
        if not path.exists(): return default
        return json.loads(path.read_text(encoding="utf-8", errors="ignore"))
    except Exception: return default

def save_json(path: Path, obj: Any) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    tmp = path.with_suffix(path.suffix + ".tmp")
    tmp.write_text(json.dumps(obj, ensure_ascii=False, separators=(",", ":"), default=str), encoding="utf-8")
    os.replace(tmp, path)

_JSONL_CYCLE_CACHE: Dict[tuple, List[Dict[str, Any]]] = {}

def _tail_text_lines(path: Path, max_lines: int) -> List[str]:
    if max_lines <= 0:
        return path.read_text(encoding="utf-8", errors="ignore").splitlines()
    chunks: List[bytes] = []
    newline_count = 0
    with path.open("rb") as f:
        f.seek(0, os.SEEK_END)
        pos = f.tell()
        while pos > 0 and newline_count <= max_lines:
            size = min(65536, pos)
            pos -= size
            f.seek(pos)
            block = f.read(size)
            chunks.append(block)
            newline_count += block.count(b"\n")
    data = b"".join(reversed(chunks)).decode("utf-8", errors="ignore")
    return data.splitlines()[-max_lines:]

def read_jsonl(path: Path, max_lines: int=1000) -> List[Dict[str, Any]]:
    if not path.exists():
        return []
    try:
        stat = path.stat()
        key = (str(path), int(max_lines), int(stat.st_mtime_ns), int(stat.st_size))
        cached = _JSONL_CYCLE_CACHE.get(key)
        if cached is not None:
            return cached
        lines = _tail_text_lines(path, int(max_lines))
        out: List[Dict[str, Any]] = []
        for ln in lines:
            try:
                if ln.strip():
                    obj = json.loads(ln)
                    if isinstance(obj, dict):
                        out.append(obj)
            except Exception:
                continue
        _JSONL_CYCLE_CACHE[key] = out
        return out
    except Exception as exc:
        append_error(ERROR, "read_jsonl_v929", exc)
        return []

def append_error(path: Path, where: str, exc: BaseException) -> None:
    try:
        path.parent.mkdir(parents=True, exist_ok=True)
        with path.open("a", encoding="utf-8") as f:
            f.write(f"[{now_text()}] {where}: {exc.__class__.__name__}: {exc}\n")
            f.write(traceback.format_exc()[-1500:] + "\n")
    except Exception: pass

def ticker_norm(x: Any) -> str:
    t = str(x or "").strip().upper().replace("/", "-").replace("_", "-")
    parts = [p for p in t.split("-") if p]
    if len(parts) >= 2:
        non = [p for p in parts if p != "KRW"]
        t = non[-1] if non else parts[-1]
    if t.endswith("KRW") and len(t) > 3: t = t[:-3]
    return t.strip().upper()

def map_rows(obj: Any) -> Dict[str, Dict[str, Any]]:
    if isinstance(obj, dict) and isinstance(obj.get("rows"), list): obj = obj.get("rows")
    elif isinstance(obj, dict) and isinstance(obj.get("rows"), dict): obj = obj.get("rows")
    elif isinstance(obj, dict) and isinstance(obj.get("cache"), dict): obj = obj.get("cache")
    out: Dict[str, Dict[str, Any]] = {}
    if isinstance(obj, list):
        for r in obj:
            if isinstance(r, dict):
                t = ticker_norm(r.get("ticker") or r.get("symbol") or r.get("market"))
                if t: out[t] = r
    elif isinstance(obj, dict):
        for k, v in obj.items():
            t = ticker_norm(k)
            if t and isinstance(v, dict):
                vv = dict(v); vv.setdefault("ticker", t); out[t] = vv
    return out

def write_status(state: str, **extra: Any) -> None:
    save_json(STATUS, {"version": VERSION, "state": state, "pid": os.getpid(), "updated_ts": now_ts(), "updated_text": now_text(), **extra})

def profit(row: Dict[str, Any]) -> float:
    return fnum(row.get("profit_pct"), row.get("return_pct"), row.get("pnl_pct"), row.get("profit_rate"), default=0.0)

def _current_price(ticker: str, fmap: Dict[str, Dict[str, Any]], ofmap: Dict[str, Dict[str, Any]]) -> float:
    f = fmap.get(ticker, {}) or {}
    o = ofmap.get(ticker, {}) or {}
    return fnum(o.get("quote_price"), o.get("current_price"), o.get("price"), f.get("current_price"), f.get("price"), f.get("last_price"), f.get("close"), default=0.0)

STRUCTURE_REVIEW_PRICE_TTL_SEC = float(os.environ.get('STRUCTURE_REVIEW_PRICE_TTL_SEC', '45'))


def _review_path_age(path: Path, nowv: float) -> Optional[float]:
    try:
        return max(0.0, nowv - path.stat().st_mtime)
    except OSError:
        return None


def _review_row_age(row: Dict[str,Any], path: Path, nowv: float) -> tuple[Optional[float],str]:
    for key in ('quote_age_sec','micro_age_sec','orderflow_age_sec','price_age_sec','feature_age_sec','age_sec'):
        raw=row.get(key)
        if raw in (None,''): continue
        try: age=float(str(raw).replace(',',''))
        except Exception: continue
        if math.isfinite(age) and 0<=age<999998: return age,key
    for key in ('updated_ts','quote_ts','price_ts','last_update_ts','timestamp','ts'):
        raw=row.get(key)
        if raw in (None,''): continue
        try: ts=float(str(raw).replace(',',''))
        except Exception: continue
        if ts>1e12: ts/=1000.0
        if ts>1e9 and math.isfinite(ts): return max(0.0,nowv-ts),key
    age=_review_path_age(path,nowv)
    return age,'file_mtime' if age is not None else ''


def _structure_review_price_state(ticker: str, fmap: Dict[str,Dict[str,Any]], ofmap: Dict[str,Dict[str,Any]], nowv: float) -> Dict[str,Any]:
    f=fmap.get(ticker,{}) or {}; o=ofmap.get(ticker,{}) or {}
    choices=[]
    op=fnum(o.get('quote_price'),o.get('current_price'),o.get('price'),default=0.0)
    oa,osrc=_review_row_age(o,ORDERFLOW,nowv)
    if op>0: choices.append(('orderflow',op,oa,osrc))
    fp=fnum(f.get('current_price'),f.get('price'),f.get('last_price'),f.get('close'),default=0.0)
    fa,fsrc=_review_row_age(f,FEATURE,nowv)
    if fp>0: choices.append(('feature',fp,fa,fsrc))
    for source,price,age,age_source in choices:
        if age is not None and age<=STRUCTURE_REVIEW_PRICE_TTL_SEC:
            return {'fresh':True,'price':price,'source':source,'age_sec':round(age,3),'age_source':age_source,'ttl_sec':STRUCTURE_REVIEW_PRICE_TTL_SEC,'reason':None}
    best=min(choices,key=lambda x:x[2] if x[2] is not None else 1e18) if choices else None
    return {'fresh':False,'price':0.0,'source':best[0] if best else None,'age_sec':round(best[2],3) if best and best[2] is not None else None,'age_source':best[3] if best else None,'ttl_sec':STRUCTURE_REVIEW_PRICE_TTL_SEC,'reason':'review_price_stale_or_missing'}

def _pct(cur: float, base: float) -> float:
    return round((cur - base) / base * 100.0, 3) if cur and base else 0.0

def _risk_profile(rec: Dict[str, Any]) -> Dict[str, Any]:
    """결과만 오른 위험 후보와 진짜 놓친 후보를 분리하기 위한 표시용 판정.
    조건/S1/S2/S3 기준은 바꾸지 않고 review 분류만 정리한다.
    """
    m = rec.get("metrics") if isinstance(rec.get("metrics"), dict) else {}
    spread = fnum(m.get("spread_pct"), default=0.0)
    slip = fnum(m.get("slippage_pct"), default=0.0)
    buy = fnum(m.get("buy_ratio"), default=0.0)
    sustain = fnum(m.get("buy_sustain_1m"), default=0.0)
    cur_pct = fnum(rec.get("current_pct"), default=0.0)
    reasons = " / ".join(str(x) for x in (rec.get("block_reasons") or []) if str(x).strip())
    risk: List[str] = []
    mild: List[str] = []
    if spread >= 0.30: risk.append(f"스프레드 {spread:.2f}%")
    elif spread >= 0.20: mild.append(f"스프레드 {spread:.2f}%")
    if slip >= 0.30: risk.append(f"미끄러짐 {slip:.2f}%")
    elif slip >= 0.20: mild.append(f"미끄러짐 {slip:.2f}%")
    if buy and buy < 0.55: risk.append(f"매수체결 {buy:.2f}")
    elif buy and buy < 0.68: mild.append(f"매수체결 {buy:.2f}")
    if sustain and sustain < 0.55: risk.append(f"1분지속 {sustain:.2f}")
    elif sustain and sustain < 0.64: mild.append(f"1분지속 {sustain:.2f}")
    for word in ("매도벽", "매도압력", "EMA5 아래", "추세 부담"):
        if word in reasons:
            risk.append(word)
    if cur_pct <= -1.00:
        risk.append(f"현재 되돌림 {cur_pct:+.2f}%")
    return {"risk": risk, "mild": mild, "is_high_risk": bool(risk), "risk_note": " / ".join(risk[:4]) if risk else (" / ".join(mild[:4]) if mild else "위험 낮음")}

def _sample_pct(rec: Dict[str, Any], label: str) -> Optional[float]:
    # label: 5m/10m/20m. direct value가 없으면 samples[label].pct를 본다.
    key = f"after_{label}_pct"
    v = rec.get(key)
    if v not in (None, ""):
        return fnum(v, default=0.0)
    samples = rec.get("samples") if isinstance(rec.get("samples"), dict) else {}
    sample = samples.get(label) if isinstance(samples.get(label), dict) else {}
    if sample.get("pct") not in (None, ""):
        return fnum(sample.get("pct"), default=0.0)
    return None

def _timing_profile(rec: Dict[str, Any]) -> Dict[str, Any]:
    """v457: 최고수익 착시를 분리한다.
    S1 완화/승격 근거는 5/10/20분 안에 오른 후보만 쓰기 위함이다.
    """
    a5 = _sample_pct(rec, "5m")
    a10 = _sample_pct(rec, "10m")
    a20 = _sample_pct(rec, "20m")
    vals = {"5m": a5, "10m": a10, "20m": a20}
    # 초반에 명확히 간 후보만 진짜놓침 근거로 둔다.
    early_hit = (a5 is not None and a5 >= 0.30) or (a10 is not None and a10 >= 0.50) or (a20 is not None and a20 >= 0.70)
    mild_hit = (a5 is not None and a5 >= 0.10) or (a10 is not None and a10 >= 0.20) or (a20 is not None and a20 >= 0.30)
    sample_ready = any(v is not None for v in vals.values())
    note = " / ".join(f"{k} {v:+.2f}%" for k, v in vals.items() if v is not None) or "시간표 부족"
    return {"early_hit": early_hit, "mild_hit": mild_hit, "sample_ready": sample_ready, "note": note, "samples": vals}

def _decision(rec: Dict[str, Any], elapsed: float) -> str:
    max_pct = fnum(rec.get("max_pct"), default=0.0)
    cur_pct = fnum(rec.get("current_pct"), default=0.0)
    rp = _risk_profile(rec)
    tp = _timing_profile(rec)
    rec["risk_reasons"] = rp.get("risk", [])
    rec["risk_note"] = rp.get("risk_note", "")
    rec["timing_note"] = tp.get("note", "")
    rec["timing_samples"] = tp.get("samples", {})
    if max_pct >= 1.20:
        if rp.get("is_high_risk"):
            rec["timing_class"] = "위험상승"
            return "🔥 결과만 오른 위험 후보"
        if tp.get("early_hit"):
            rec["timing_class"] = "초반상승"
            return "❌ 진짜 놓친 후보"
        # 최고수익만 큰 후보는 S1 완화 근거로 쓰지 않는다.
        rec["timing_class"] = "늦게오름"
        return "⏳ 늦게 오른 후보"
    if max_pct >= 0.70:
        if rp.get("is_high_risk"):
            rec["timing_class"] = "위험상승"
            return "🔥 결과만 오른 위험 후보"
        if tp.get("mild_hit"):
            rec["timing_class"] = "아까움"
            return "⚠️ 아까운 후보"
        rec["timing_class"] = "늦게오름"
        return "⏳ 늦게 오른 후보"
    if elapsed >= 1200 and max_pct < 0.30:
        rec["timing_class"] = "초반무반응"
        return "✅ 안 산 게 맞음"
    if elapsed >= 300 and cur_pct <= -0.30 and max_pct < 0.50:
        rec["timing_class"] = "빠른약세"
        return "✅ 안 산 게 맞음"
    rec["timing_class"] = "추적중"
    return "❔ 추적중"

def _short_reasons(rec: Dict[str, Any]) -> str:
    reasons = rec.get("block_reasons") if isinstance(rec.get("block_reasons"), list) else []
    missing = rec.get("missing_info") if isinstance(rec.get("missing_info"), list) else []
    arr = [str(x) for x in (reasons + missing) if str(x).strip()]
    return " / ".join(arr[:3]) if arr else "-"


def _has_structure(rec: Dict[str, Any]) -> bool:
    if not isinstance(rec, dict):
        return False
    tags = rec.get("structure_tags")
    risk = rec.get("structure_risk_tags")
    fit = rec.get("structure_fit")
    return (isinstance(tags, list) and bool(tags)) or (isinstance(risk, list) and bool(risk)) or bool(str(fit or "").strip())

def _copy_structure(dst: Dict[str, Any], src: Dict[str, Any]) -> bool:
    if not isinstance(dst, dict) or not isinstance(src, dict) or not _has_structure(src):
        return False
    st = src.get("chart_structure") if isinstance(src.get("chart_structure"), dict) else {}
    dst["structure_tags"] = src.get("structure_tags") if isinstance(src.get("structure_tags"), list) else st.get("tags", [])
    dst["structure_good_tags"] = src.get("structure_good_tags") if isinstance(src.get("structure_good_tags"), list) else st.get("good_tags", [])
    dst["structure_risk_tags"] = src.get("structure_risk_tags") if isinstance(src.get("structure_risk_tags"), list) else st.get("risk_tags", [])
    dst["structure_fit"] = str(src.get("structure_fit") or st.get("strategy_fit") or "")
    dst["structure_summary"] = str(src.get("structure_summary") or st.get("summary") or "")
    dst["chart_structure"] = st
    dst["structure_source"] = "candidate_snapshot"
    return True


def _has_market(rec: Dict[str, Any]) -> bool:
    return isinstance(rec, dict) and (isinstance(rec.get("market_regime_tags"), list) and bool(rec.get("market_regime_tags")) or bool(str(rec.get("market_regime_summary") or "").strip()))

def _copy_market(dst: Dict[str, Any], src: Dict[str, Any]) -> bool:
    if not isinstance(dst, dict) or not isinstance(src, dict) or not _has_market(src):
        return False
    mr = src.get("market_regime") if isinstance(src.get("market_regime"), dict) else {}
    dst["market_regime_tags"] = src.get("market_regime_tags") if isinstance(src.get("market_regime_tags"), list) else mr.get("tags", [])
    dst["market_risk_tags"] = src.get("market_risk_tags") if isinstance(src.get("market_risk_tags"), list) else mr.get("risk_tags", [])
    dst["market_regime_summary"] = str(src.get("market_regime_summary") or mr.get("summary") or "")
    dst["market_regime"] = mr
    dst["market_source"] = "candidate_snapshot"
    return True

def _derive_market_from_rec(rec: Dict[str, Any], fmap: Dict[str, Dict[str, Any]], ofmap: Dict[str, Dict[str, Any]], regime: Dict[str, Any]) -> Dict[str, Any]:
    t = ticker_norm(rec.get("ticker"))
    row = fmap.get(t, {}) if t else {}
    of = ofmap.get(t, {}) if t else {}
    tags: List[str] = []
    risks: List[str] = []
    mode = str((regime or {}).get("market_mode") or (regime or {}).get("mode") or row.get("market_mode") or of.get("market_mode") or "")
    def add(arr: List[str], x: str) -> None:
        if x and x not in arr:
            arr.append(x)
    if "강" in mode:
        add(tags, "시장강함")
    elif "약" in mode:
        add(tags, "시장약함")
    elif mode:
        add(tags, "시장보통")
    else:
        add(tags, "장세정보부족")
    pressure = str((regime or {}).get("market_pressure") or row.get("market_pressure") or of.get("market_pressure") or "")
    if "급락" in mode or "급락" in pressure:
        add(risks, "시장급락위험")
    if "과열" in mode or "과열" in pressure:
        add(risks, "시장과열")
    if "횡보" in mode or "횡보" in pressure:
        add(tags, "시장횡보")
    return {"schema":"market_regime_tags_v447_review_only", "tags":tags[:8], "risk_tags":risks[:6], "summary":(", ".join(tags[:3]) if tags else "-") + (" / 위험 " + ", ".join(risks[:2]) if risks else "")}

def _ensure_market(rec: Dict[str, Any], sources: Dict[str, Dict[str, Any]], fmap: Dict[str, Dict[str, Any]], ofmap: Dict[str, Dict[str, Any]], regime: Dict[str, Any]) -> None:
    if not isinstance(rec, dict) or _has_market(rec):
        return
    t = ticker_norm(rec.get("ticker"))
    if t and _copy_market(rec, sources.get(t, {}) or {}):
        return
    mt = _derive_market_from_rec(rec, fmap, ofmap, regime)
    rec["market_regime"] = mt
    rec["market_regime_tags"] = mt.get("tags", [])
    rec["market_risk_tags"] = mt.get("risk_tags", [])
    rec["market_regime_summary"] = mt.get("summary", "")
    rec["market_source"] = "review_derived_display"

def _unique(items: List[str]) -> List[str]:
    out: List[str] = []
    for x in items:
        t = str(x or "").strip()
        if t and t not in out:
            out.append(t)
    return out

def _derive_structure_from_rec(rec: Dict[str, Any]) -> Dict[str, Any]:
    """기존 active review state처럼 구조태그가 없던 기록에 붙이는 표시용 보강.
    후보 차단·S1 승격·청산에는 쓰지 않는다.
    """
    text = " / ".join(str(x) for x in (rec.get("block_reasons") or []) if str(x).strip())
    strat = str(rec.get("strategy") or rec.get("strategy_key") or "")
    m = rec.get("metrics") if isinstance(rec.get("metrics"), dict) else {}
    spread = fnum(m.get("spread_pct"), default=0.0)
    slip = fnum(m.get("slippage_pct"), default=0.0)
    buy = fnum(m.get("buy_ratio"), default=0.0)
    cur = fnum(rec.get("current_pct"), default=0.0)
    maxp = fnum(rec.get("max_pct"), default=0.0)
    tags: List[str] = []
    risks: List[str] = []

    if "돈흐름" in strat or "reaccel" in strat:
        tags += ["눌림후재가속", "돈흐름재유입"]
        if "VWAP" not in text and "EMA" not in text:
            tags.append("VWAP방어")
    if "돌파" in strat or "breakout" in strat:
        tags += ["저항돌파", "저항돌파후재테스트"]
        if "돌파 후" in text or "돌파선" in text:
            tags.append("지지전환확인")
    if "저점" in strat or "VWAP 회복" in strat or "sweep" in strat:
        tags += ["저점유동성쓸림", "쓸림후빠른회복", "VWAP재회복"]
    if "주도흐름" in strat or "유동보유" in strat or "adaptive_hold" in strat:
        tags += ["얕은눌림", "VWAP방어", "EMA방어", "상대강도유지"]
    if "주도추세" in strat or "momentum" in strat:
        tags += ["고점저점상승", "추세지속", "채널하단방어"]
    if "급등" in strat or "재돌파" in strat or "rebreak" in strat:
        tags += ["급등후눌림", "고점재돌파", "돈흐름재유입"]

    if "고점권" in text and "가격반응" in text:
        risks.append("고점권가격반응약함")
    if "스프레드" in text or spread >= 0.30:
        risks.append("스프레드부담")
    if "미끄" in text or slip >= 0.30:
        risks.append("미끄러짐부담")
    if "매도벽" in text or "매도압력" in text:
        risks.append("매도압력부담")
    if "돌파 후" in text and "부족" in text:
        risks.append("가짜돌파위험")
    if cur <= -1.0 or (maxp >= 1.2 and cur < 0):
        risks.append("되돌림위험")
    if buy and buy < 0.55:
        risks.append("매수체결약함")

    if not tags:
        tags = ["구조정보부족"]
    tags = _unique(tags)[:10]
    risks = _unique(risks)[:8]
    fit = "구조좋음" if tags and tags != ["구조정보부족"] else "구조정보부족"
    severe = any(x in risks for x in ["스프레드부담", "미끄러짐부담", "매도압력부담", "되돌림위험", "매수체결약함", "가짜돌파위험"])
    if risks and fit == "구조좋음":
        fit = "구조좋음 · 위험동반" if severe else "구조관찰"
    elif risks:
        fit = "구조위험"
    return {
        "schema": "review_structure_derived_display_v447",
        "tags": tags,
        "good_tags": [t for t in tags if t != "구조정보부족"],
        "risk_tags": risks,
        "strategy_fit": fit,
        "summary": f"{fit} · 좋음 {', '.join(tags[:3]) if tags else '-'} / 위험 {', '.join(risks[:3]) if risks else '-'}",
    }

def _ensure_structure(rec: Dict[str, Any], sources: Dict[str, Dict[str, Any]]) -> None:
    if not isinstance(rec, dict) or _has_structure(rec):
        return
    t = ticker_norm(rec.get("ticker"))
    if t and _copy_structure(rec, sources.get(t, {}) or {}):
        return
    st = _derive_structure_from_rec(rec)
    rec["chart_structure"] = st
    rec["structure_tags"] = st.get("tags", [])
    rec["structure_good_tags"] = st.get("good_tags", [])
    rec["structure_risk_tags"] = st.get("risk_tags", [])
    rec["structure_fit"] = st.get("strategy_fit", "")
    rec["structure_summary"] = st.get("summary", "")
    rec["structure_source"] = "review_derived_display"

def _summ_rows(rows: List[Dict[str, Any]], limit: int = 8) -> List[Dict[str, Any]]:
    rows = sorted(rows, key=lambda r: (fnum(r.get("max_pct"), default=0.0), fnum(r.get("score"), default=0.0)), reverse=True)
    out = []
    for r in rows[:limit]:
        out.append({
            "ticker": r.get("ticker"), "stage": r.get("stage"), "strategy": r.get("strategy"),
            "score": r.get("score"), "decision": r.get("decision"),
            "first_price": r.get("first_price"), "current_price": r.get("current_price"),
            "current_pct": r.get("current_pct"), "max_pct": r.get("max_pct"),
            "after_5m_pct": r.get("after_5m_pct"), "after_10m_pct": r.get("after_10m_pct"), "after_20m_pct": r.get("after_20m_pct"),
            "first_seen_ts": r.get("first_seen_ts"), "first_seen_text": r.get("first_seen_text"),
            "last_seen_ts": r.get("last_seen_ts"), "last_seen_text": r.get("last_seen_text"),
            "max_seen_ts": r.get("max_seen_ts"), "max_seen_text": r.get("max_seen_text"),
            "reasons": _short_reasons(r),
            "risk_note": r.get("risk_note", ""),
            "risk_reasons": r.get("risk_reasons", []),
            "structure_tags": r.get("structure_tags", []),
            "structure_good_tags": r.get("structure_good_tags", []),
            "structure_risk_tags": r.get("structure_risk_tags", []),
            "structure_fit": r.get("structure_fit", ""),
            "structure_summary": r.get("structure_summary", ""),
            "chart_structure": r.get("chart_structure", {}),
            "market_regime_tags": r.get("market_regime_tags", []),
            "market_risk_tags": r.get("market_risk_tags", []),
            "market_regime_summary": r.get("market_regime_summary", ""),
            "market_regime": r.get("market_regime", {}),
            "review_class": r.get("decision", ""),
            "timing_class": r.get("timing_class", ""),
            "timing_note": r.get("timing_note", ""),
            "timing_samples": r.get("timing_samples", {}),
        })
    return out

def _reason_top(rows: List[Dict[str, Any]], limit: int = 8) -> List[Dict[str, Any]]:
    cnt: Dict[str, int] = {}
    for r in rows:
        for x in (r.get("block_reasons") or []):
            key = str(x).split()[0].strip() or str(x).strip()
            if key: cnt[key] = cnt.get(key, 0) + 1
    return [{"reason": k, "count": v} for k, v in sorted(cnt.items(), key=lambda kv: kv[1], reverse=True)[:limit]]

def _close_item_from_trade(r: Dict[str, Any], tag: str, give: float, sources: Dict[str, Dict[str, Any]], fmap: Dict[str, Dict[str, Any]], ofmap: Dict[str, Dict[str, Any]], regime: Dict[str, Any]) -> Dict[str, Any]:
    item = {"ticker": ticker_norm(r.get("ticker")), "peak_pct": fnum(r.get("peak_pct"), r.get("max_profit_pct"), default=0.0), "pnl_pct": fnum(r.get("pnl_pct"), r.get("profit_pct"), default=0.0), "giveback_pct": round(give,3), "reason": r.get("exit_reason"), "tag": r.get("close_review_tag") or tag}
    # closed row 자체의 entry_context/snapshot 구조를 우선 복사하고, 없으면 현재 후보 snapshot 또는 표시용 파생값을 붙인다.
    ctx = r.get("entry_context") if isinstance(r.get("entry_context"), dict) else {}
    snap = r.get("entry_snapshot") if isinstance(r.get("entry_snapshot"), dict) else {}
    flat = snap.get("flat") if isinstance(snap.get("flat"), dict) else {}
    src = dict(r)
    for k in ("chart_structure", "structure_tags", "structure_good_tags", "structure_risk_tags", "structure_fit", "structure_summary", "market_regime", "market_regime_tags", "market_risk_tags", "market_regime_summary"):
        if k not in src and k in ctx: src[k] = ctx[k]
        if k not in src and k in flat: src[k] = flat[k]
    if _has_structure(src):
        _copy_structure(item, src)
    else:
        t = ticker_norm(item.get("ticker"))
        if t:
            _copy_structure(item, sources.get(t, {}) or {})
        _ensure_structure(item, sources)
    if _has_market(src):
        _copy_market(item, src)
    else:
        t = ticker_norm(item.get("ticker"))
        if t:
            _copy_market(item, sources.get(t, {}) or {})
        _ensure_market(item, sources, fmap, ofmap, regime)
    return item

def _legacy_closed_summary(sources: Optional[Dict[str, Dict[str, Any]]]=None, fmap: Optional[Dict[str, Dict[str, Any]]]=None, ofmap: Optional[Dict[str, Dict[str, Any]]]=None, regime: Optional[Dict[str, Any]]=None) -> Dict[str, Any]:
    sources = sources or {}; fmap = fmap or {}; ofmap = ofmap or {}; regime = regime or {}
    rows = read_jsonl(CLOSED, max_lines=360)
    def pnl(r: Dict[str, Any]) -> float: return fnum(r.get("pnl_pct"), r.get("profit_pct"), default=0.0)
    def peak(r: Dict[str, Any]) -> float: return fnum(r.get("peak_pct"), r.get("max_profit_pct"), default=0.0)
    protect_needed=[]; fast_fail=[]; good_keep=[]
    for r in rows[-80:]:
        pk=peak(r); pn=pnl(r); give=max(0.0, pk-pn)
        if pk >= 0.70 and (pn < 0 or give >= 0.55):
            protect_needed.append(_close_item_from_trade(r, "보호익절 필요 후보", give, sources, fmap, ofmap, regime))
        elif pn <= -0.60 and pk < 0.25:
            fast_fail.append(_close_item_from_trade(r, "빠른실패 정리 후보", give, sources, fmap, ofmap, regime))
        elif pn > 0 and pk-pn <= 0.35:
            good_keep.append(_close_item_from_trade(r, "수익 보존 양호", give, sources, fmap, ofmap, regime))
    big_loss = sorted([r for r in rows if profit(r) <= -0.8], key=profit)[:10]
    good_win = sorted([r for r in rows if profit(r) >= 1.0], key=profit, reverse=True)[:10]
    return {"closed_recent": len(rows), "big_loss": len(big_loss), "good_win": len(good_win), "close_review": {"protect_needed_count": len(protect_needed), "fast_fail_count": len(fast_fail), "good_keep_count": len(good_keep), "protect_needed": protect_needed[-5:], "fast_fail": fast_fail[-5:], "good_keep": good_keep[-5:]}}



# v655: review_worker는 후보판단/장부 주인이 아니라 복기 요약 주인이다.
# paper CLOSED 장부는 삭제하지 않고, active missed-review state에서 의미 낮은 추적만 빨리 순환한다.
def _v655_keep_active_review(rec: Dict[str, Any], nowv: float, base_ttl: float) -> bool:
    if not isinstance(rec, dict):
        return False
    first = fnum(rec.get("first_seen_ts"), default=nowv)
    age = max(0.0, nowv - first)
    cls = str(rec.get("decision") or rec.get("review_class") or rec.get("review_hint") or "")
    maxp = fnum(rec.get("max_pct"), default=0.0)
    curp = fnum(rec.get("current_pct"), default=0.0)
    # 중요한 복기 후보는 기존 보관기한 유지.
    if any(w in cls for w in ("진짜 놓친", "아까운", "위험 후보", "위험상승")):
        return age <= base_ttl
    # 늦게 오른 후보/큰 변동 후보는 전략 보정 참고용으로 몇 시간만 유지.
    if "늦게 오른" in cls or maxp >= 0.70 or abs(curp) >= 1.00:
        return age <= min(base_ttl, 6 * 3600.0)
    # 추적중/안 산 게 맞음은 디스크·CPU를 잡아먹지 않게 짧게 순환.
    if "추적중" in cls or not cls:
        return age <= min(base_ttl, 90 * 60.0)
    if "안 산 게 맞음" in cls:
        return age <= min(base_ttl, 45 * 60.0)
    return age <= min(base_ttl, 2 * 3600.0)



def _v664_prune_active_size(active: Dict[str, Dict[str, Any]], nowv: float, max_keep: int = ACTIVE_REVIEW_MAX) -> Dict[str, Dict[str, Any]]:
    """v664: active missed-review state 크기 제한.
    paper CLOSED 장부는 손대지 않고, 상태 추적용 active dict만 핵심/최근 후보 위주로 유지한다.
    """
    if not isinstance(active, dict) or len(active) <= max_keep:
        return active
    important_words = ("진짜 놓친", "아까운", "위험 후보", "위험상승", "늦게 오른")
    rows = []
    for k, v in active.items():
        if not isinstance(v, dict):
            continue
        cls = str(v.get('decision') or v.get('review_class') or v.get('review_hint') or '')
        imp = 1 if any(w in cls for w in important_words) else 0
        maxp = fnum(v.get('max_pct'), default=0.0)
        curp = abs(fnum(v.get('current_pct'), default=0.0))
        last = fnum(v.get('last_seen_ts'), v.get('first_seen_ts'), default=0.0)
        score = imp * 1000000.0 + maxp * 1000.0 + curp * 300.0 + last / 100000.0
        rows.append((score, k, v))
    rows.sort(key=lambda x: x[0], reverse=True)
    kept = {k: v for _, k, v in rows[:max_keep]}
    return kept


# =============================================================================
# review_worker v0.14 / v665: trigger shadow benchmark 추적
# - strategy_worker가 만든 shadow 후보를 읽어 이후 가격 경로를 비교한다.
# - 실제 paper OPEN/장부/청산은 바꾸지 않는다.
# =============================================================================

def _v665_variant_key(c: Dict[str, Any], variant: Dict[str, Any]) -> str:
    return '|'.join(str(x or '-') for x in (c.get('shadow_key_base'), variant.get('key')))



def _v678_trigger_shadow_score(rec: Dict[str, Any], nowv: float) -> float:
    try:
        entered = 1 if bool(rec.get('entered')) else 0
        maxp = fnum(rec.get('max_pct'), default=0.0)
        curp = abs(fnum(rec.get('current_pct'), default=0.0))
        last = fnum(rec.get('last_seen_ts'), rec.get('first_seen_ts'), default=nowv)
        sampled = len(rec.get('samples') if isinstance(rec.get('samples'), dict) else {})
        return entered * 1000000.0 + sampled * 200000.0 + maxp * 1000.0 + curp * 200.0 + last / 100000.0
    except Exception:
        return 0.0


def _v678_prune_trigger_shadow_active(active: Dict[str, Dict[str, Any]], nowv: float) -> Dict[str, Dict[str, Any]]:
    """trigger shadow는 검증용 state라 오래 들고 있지 않는다. touched라고 TTL을 무시하지 않는다."""
    ttl_entered = max(600.0, TRIGGER_SHADOW_ENTERED_TTL_SEC)
    ttl_pending = max(300.0, TRIGGER_SHADOW_PENDING_TTL_SEC)
    max_keep = max(100, TRIGGER_SHADOW_ACTIVE_MAX)
    kept = {}
    for k, rec in (active or {}).items():
        if not isinstance(rec, dict):
            continue
        first = fnum(rec.get('first_seen_ts'), default=nowv)
        age = max(0.0, nowv - first)
        entered = bool(rec.get('entered'))
        if entered and age <= ttl_entered:
            kept[k] = rec
        elif (not entered) and age <= ttl_pending:
            kept[k] = rec
    if len(kept) <= max_keep:
        return kept
    ranked = sorted(kept.items(), key=lambda kv: _v678_trigger_shadow_score(kv[1], nowv), reverse=True)
    return {k: v for k, v in ranked[:max_keep]}

def _v665_trigger_shadow_update(nowv: float, fmap: Dict[str, Dict[str, Any]], ofmap: Dict[str, Dict[str, Any]]) -> Dict[str, Any]:
    cand_obj = load_json(TRIGGER_SHADOW_CANDIDATES, {}) or {}
    candidates = cand_obj.get('rows') if isinstance(cand_obj, dict) and isinstance(cand_obj.get('rows'), list) else []
    state_obj = load_json(TRIGGER_SHADOW_STATE, {}) or {}
    active = state_obj.get('active') if isinstance(state_obj, dict) and isinstance(state_obj.get('active'), dict) else {}
    touched = set()
    # 기존 state 정리 TTL: 미진입 30분, 진입 40분 이후 요약만 남김
    for c in candidates:
        if not isinstance(c, dict):
            continue
        t = ticker_norm(c.get('ticker'))
        if not t:
            continue
        cur = _current_price(t, fmap, ofmap)
        if not cur:
            cur = fnum(c.get('current_price'), default=0.0)
        for var in c.get('variants') or []:
            if not isinstance(var, dict):
                continue
            k = _v665_variant_key(c, var)
            touched.add(k)
            threshold = fnum(var.get('threshold_price'), default=0.0)
            rec = active.get(k) if isinstance(active.get(k), dict) else None
            if not rec:
                rec = {
                    'schema': 'trigger_shadow_variant_state_v665',
                    'key': k,
                    'ticker': t,
                    'variant': var.get('key'),
                    'variant_label': var.get('label'),
                    'entry_mode': var.get('entry_mode'),
                    'threshold_price': threshold,
                    'first_seen_ts': nowv,
                    'first_seen_text': now_text(nowv),
                    'source': c.get('trigger_source'),
                    'stage': c.get('stage'),
                    'coin_quality_score': c.get('coin_quality_score'),
                    'trigger_price': c.get('trigger_price'),
                    'trigger_gap_pct': c.get('trigger_gap_pct'),
                    'entered': False,
                    'samples': {},
                    'max_pct': 0.0,
                    'min_pct': 0.0,
                    'policy': 'v665 shadow only. 실제 주문/장부 변경 없음.',
                }
            rec['last_seen_ts'] = nowv
            rec['last_seen_text'] = now_text(nowv)
            rec['latest_price'] = cur
            # 진입 판정: immediate는 첫 가격, threshold는 해당 가격 이상 도달 시 가상진입.
            if not rec.get('entered') and cur:
                if str(var.get('entry_mode')) == 'immediate' or (threshold and cur >= threshold):
                    rec['entered'] = True
                    rec['entry_ts'] = nowv
                    rec['entry_text'] = now_text(nowv)
                    rec['entry_price'] = cur
                    rec['entry_reason'] = 'immediate_current' if str(var.get('entry_mode')) == 'immediate' else 'threshold_reached'
            if rec.get('entered') and cur:
                entry = fnum(rec.get('entry_price'), default=0.0)
                pct = _pct(cur, entry)
                rec['current_pct'] = pct
                rec['max_pct'] = max(fnum(rec.get('max_pct'), default=pct), pct)
                rec['min_pct'] = min(fnum(rec.get('min_pct'), default=pct), pct)
                elapsed = max(0.0, nowv - fnum(rec.get('entry_ts'), default=nowv))
                samples = rec.get('samples') if isinstance(rec.get('samples'), dict) else {}
                for label, sec in (('3m',180),('5m',300),('10m',600),('20m',1200)):
                    if elapsed >= sec and label not in samples:
                        samples[label] = {'ts': nowv, 'text': now_text(nowv), 'price': cur, 'pct': pct, 'max_pct': rec.get('max_pct'), 'min_pct': rec.get('min_pct')}
                rec['samples'] = samples
            else:
                wait = max(0.0, nowv - fnum(rec.get('first_seen_ts'), default=nowv))
                rec['wait_sec'] = round(wait, 1)
                if wait >= 1200:
                    rec['not_entered_timeout'] = True
            active[k] = rec
    # v678 active pruning owner
    # 이전 구경로는 k in touched면 TTL을 넘어도 계속 살려 active가 수천 개로 누적됐다.
    # touched 예외를 삭제하고, entered/pending TTL + 서버보호 safety cap으로 단일화한다.
    before_shadow_active = len(active)
    active = _v678_prune_trigger_shadow_active(active, nowv)
    pruned_shadow_active = max(0, before_shadow_active - len(active))
    rows = list(active.values())
    entered = [r for r in rows if r.get('entered')]
    pending = [r for r in rows if not r.get('entered')]
    by_variant: Dict[str, List[Dict[str, Any]]] = {}
    for r in rows:
        by_variant.setdefault(str(r.get('variant') or '-'), []).append(r)
    variant_summary = {}
    for vk, arr in by_variant.items():
        ent = [r for r in arr if r.get('entered')]
        variant_summary[vk] = {
            'total': len(arr),
            'entered': len(ent),
            'pending': len(arr) - len(ent),
            'avg_max_pct': round(sum(fnum(r.get('max_pct'), default=0.0) for r in ent) / len(ent), 3) if ent else 0.0,
            'win_0_3_count': sum(1 for r in ent if fnum(r.get('max_pct'), default=0.0) >= 0.30),
            'loss_0_3_count': sum(1 for r in ent if fnum(r.get('min_pct'), default=0.0) <= -0.30),
        }
    top = sorted(entered, key=lambda r: fnum(r.get('max_pct'), default=0.0), reverse=True)[:8]
    summary = {
        'schema': 'trigger_shadow_review_v665',
        'version': VERSION,
        'updated_ts': nowv,
        'updated_text': now_text(nowv),
        'candidate_source_age_sec': round(nowv - fnum(cand_obj.get('updated_ts'), default=nowv), 1) if isinstance(cand_obj, dict) else None,
        'active_count': len(rows),
        'entered_count': len(entered),
        'pending_count': len(pending),
        'pruned_count_v678': pruned_shadow_active,
        'active_max_v678': TRIGGER_SHADOW_ACTIVE_MAX,
        'ttl_entered_sec_v678': TRIGGER_SHADOW_ENTERED_TTL_SEC,
        'ttl_pending_sec_v678': TRIGGER_SHADOW_PENDING_TTL_SEC,
        'variant_summary': variant_summary,
        'top_entered': [{k:r.get(k) for k in ('ticker','variant','variant_label','source','stage','coin_quality_score','entry_price','latest_price','current_pct','max_pct','min_pct')} for r in top],
        'policy': 'v678 trigger shadow hot/cold. 실제 S1/paper OPEN/청산/자동매수 변경 없음. touched TTL 예외 삭제.',
    }
    save_json(TRIGGER_SHADOW_STATE, {'schema':'trigger_shadow_state_v665', 'version':VERSION, 'updated_ts':nowv, 'updated_text':now_text(nowv), 'active':active})
    save_json(TRIGGER_SHADOW_SUMMARY, summary)
    return summary



# =============================================================================
# review_worker v0.15 / v667: whole-market missed-scan review
# - strategy_worker가 저장한 전체 canonical snapshot을 추적해 3/5/10분 뒤 상승 후보가 어디서 묻혔는지 본다.
# - 실제 paper 장부/OPEN/청산/자동매수는 변경하지 않는다.
# =============================================================================

def _v667_miss_key(c: Dict[str, Any]) -> str:
    return ticker_norm(c.get('ticker'))


def _v667_market_miss_update(nowv: float, fmap: Dict[str, Dict[str, Any]], ofmap: Dict[str, Dict[str, Any]]) -> Dict[str, Any]:
    cand_obj = load_json(MARKET_MISS_CANDIDATES, {}) or {}
    candidates = cand_obj.get('rows') if isinstance(cand_obj, dict) and isinstance(cand_obj.get('rows'), list) else []
    # v668: always publish a visible summary, even before 3/5/10m maturity.
    state = load_json(MARKET_MISS_STATE, {}) or {}
    active = state.get('active') if isinstance(state, dict) and isinstance(state.get('active'), dict) else {}
    # TTL: 최근 35분만 추적. 전체 456개를 보되 ticker별 1개 state만 유지한다.
    ttl = 35 * 60.0
    active = {k:v for k,v in active.items() if isinstance(v, dict) and nowv - fnum(v.get('first_seen_ts'), default=nowv) <= ttl}
    for c in candidates:
        if not isinstance(c, dict):
            continue
        t = _v667_miss_key(c)
        if not t:
            continue
        cur = _current_price(t, fmap, ofmap)
        base = fnum(c.get('snapshot_price'), default=0.0) or cur
        if not base:
            continue
        rec = active.get(t)
        if not isinstance(rec, dict):
            rec = {
                'schema': 'market_miss_state_row_v667',
                'ticker': t,
                'first_seen_ts': nowv,
                'first_seen_text': now_text(nowv),
                'first_price': base,
                'min_pct': 0.0,
                'max_pct': 0.0,
                'samples': {},
            }
        rec.update({
            'last_seen_ts': nowv,
            'last_seen_text': now_text(nowv),
            'initial_stage': c.get('initial_stage'),
            'coin_quality_score': c.get('coin_quality_score'),
            'execution_risk_score': c.get('execution_risk_score'),
            'miss_bucket': c.get('miss_bucket'),
            'initial_reason': c.get('initial_reason'),
            'trigger_source': c.get('trigger_source'),
            'trigger_gap_pct': c.get('trigger_gap_pct'),
            'coverage_only': c.get('coverage_only'),
        })
        if cur:
            rec['latest_price'] = cur
            cp = _pct(cur, fnum(rec.get('first_price'), default=base))
            rec['current_pct'] = cp
            rec['max_pct'] = max(fnum(rec.get('max_pct'), default=cp), cp)
            rec['min_pct'] = min(fnum(rec.get('min_pct'), default=cp), cp)
            elapsed = nowv - fnum(rec.get('first_seen_ts'), default=nowv)
            rec['age_sec'] = round(elapsed, 1)
            samples = rec.get('samples') if isinstance(rec.get('samples'), dict) else {}
            for label, sec in (('3m',180),('5m',300),('10m',600)):
                if elapsed >= sec and label not in samples:
                    samples[label] = {'ts': nowv, 'text': now_text(nowv), 'price': cur, 'pct': cp, 'max_pct': rec.get('max_pct'), 'min_pct': rec.get('min_pct')}
            rec['samples'] = samples
            # 분류: 오른 후보가 왜 안 샀는지. 위험 낮고 품질 높으면 진짜 놓침 가능성.
            maxp = fnum(rec.get('max_pct'), default=0.0)
            risk = fnum(rec.get('execution_risk_score'), default=0.0)
            q = fnum(rec.get('coin_quality_score'), default=0.0)
            bucket = str(rec.get('miss_bucket') or '-')
            if maxp >= 0.70 and q >= 60 and risk <= 40 and bucket not in ('risk_filter_candidate',):
                rec['miss_decision'] = '❌ 진짜놓침_후보'
            elif maxp >= 0.70 and bucket == 'risk_filter_candidate':
                rec['miss_decision'] = '✅ 위험필터_성공검토'
            elif maxp >= 0.40:
                rec['miss_decision'] = '⚠️ 아까운상승'
            else:
                rec['miss_decision'] = '관찰중'
        active[t] = rec
    rows = list(active.values())
    matured = [r for r in rows if fnum(r.get('age_sec'), default=0) >= 180]
    risers = [r for r in rows if fnum(r.get('max_pct'), default=0) >= 0.40]
    true_missed = [r for r in rows if str(r.get('miss_decision')) == '❌ 진짜놓침_후보']
    buckets = Counter(str(r.get('miss_bucket') or '-') for r in risers)
    stages = Counter(str(r.get('initial_stage') or '-') for r in rows)
    decisions = Counter(str(r.get('miss_decision') or '-') for r in rows)
    top = sorted(risers, key=lambda r: fnum(r.get('max_pct'), default=0.0), reverse=True)[:12]
    true_top = sorted(true_missed, key=lambda r: fnum(r.get('max_pct'), default=0.0), reverse=True)[:10]
    def slim(r: Dict[str, Any]) -> Dict[str, Any]:
        return {k:r.get(k) for k in ('ticker','initial_stage','miss_bucket','miss_decision','coin_quality_score','execution_risk_score','first_price','latest_price','current_pct','max_pct','min_pct','age_sec','initial_reason','trigger_source','trigger_gap_pct')}
    summary = {
        'schema': 'market_miss_review_v671_tracking_fixed',
        'version': VERSION,
        'updated_ts': nowv,
        'updated_text': now_text(nowv),
        'candidate_source_age_sec': round(nowv - fnum(cand_obj.get('updated_ts'), default=nowv), 1) if isinstance(cand_obj, dict) else None,
        'tracking_total': len(rows),
        'matured_count': len(matured),
        'rise_count': len(risers),
        'true_missed_count': len(true_missed),
        'candidate_source_count': len(candidates),
        'active_saved_count': len(rows),
        'price_source': 'orderflow/feature current price + snapshot fallback',
        'tracking_waiting_3m': sum(1 for r in rows if fnum(r.get('age_sec'), default=0) < 180),
        'miss_bucket_counts': dict(buckets.most_common(10)),
        'initial_stage_counts': dict(stages.most_common(6)),
        'decision_counts': dict(decisions.most_common(8)),
        'recheck_lane_counts': dict(Counter(str(r.get('miss_bucket') or '-') for r in rows if str(r.get('miss_decision')) in ('❌ 진짜놓침_후보','⚠️ 아까운상승')).most_common(10)),
        'top_risers': [slim(r) for r in top],
        'true_missed_top': [slim(r) for r in true_top],
        'policy': 'v671: Counter import/runtime error 복구 + 전체 456 놓침검증 추적 상태를 항상 저장/표시. 실제 S1/paper OPEN/청산/자동매수 변경 없음.',
    }
    save_json(MARKET_MISS_STATE, {'schema':'market_miss_state_v671_tracking_fixed', 'version':VERSION, 'updated_ts':nowv, 'updated_text':now_text(nowv), 'active':active})
    save_json(MARKET_MISS_SUMMARY, summary)
    return summary

def _v923_append_jsonl(path: Path, row: Dict[str, Any]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open('a', encoding='utf-8') as f:
        f.write(json.dumps(row, ensure_ascii=False, separators=(',', ':'), default=str) + '\n')
        f.flush()
        os.fsync(f.fileno())


def _v923_open_rows() -> List[Dict[str, Any]]:
    obj = load_json(OPEN, {}) or {}
    if isinstance(obj, dict) and isinstance(obj.get('positions'), dict):
        return [dict(v) for v in obj.get('positions', {}).values() if isinstance(v, dict)]
    if isinstance(obj, dict):
        rows = []
        for k, v in obj.items():
            if isinstance(v, dict) and (v.get('ticker') or v.get('pos_id') or v.get('event_id')):
                rr = dict(v); rr.setdefault('pos_id', k); rows.append(rr)
        return rows
    if isinstance(obj, list):
        return [dict(v) for v in obj if isinstance(v, dict)]
    return []


def _v923_candidate_key_from_paper(row: Dict[str, Any]) -> str:
    if not isinstance(row, dict):
        return ''
    for k in ('candidate_entry_build_key_v923', 'candidate_entry_build_key'):
        v = row.get(k)
        if v not in (None, '', '-', [], {}):
            return str(v)
    cost = row.get('paper_execution_cost_v917') if isinstance(row.get('paper_execution_cost_v917'), dict) else {}
    v = cost.get('candidate_entry_build_key')
    return str(v) if v not in (None, '', '-', [], {}) else ''


def _v923_occurrence_from_paper(row: Dict[str, Any]) -> str:
    if not isinstance(row, dict):
        return ''
    v = row.get('good_s2_occurrence_key_v923')
    if v not in (None, '', '-', [], {}):
        return str(v)
    cost = row.get('paper_execution_cost_v917') if isinstance(row.get('paper_execution_cost_v917'), dict) else {}
    v = cost.get('good_s2_occurrence_key_v923')
    return str(v) if v not in (None, '', '-', [], {}) else ''


def _v923_exact_maps(rows: List[Dict[str, Any]]) -> Dict[str, Dict[str, Any]]:
    by_occ: Dict[str, Dict[str, Any]] = {}
    candidate_lists: Dict[str, List[Dict[str, Any]]] = {}
    for row in rows or []:
        if not isinstance(row, dict):
            continue
        occ = _v923_occurrence_from_paper(row)
        if occ:
            by_occ[occ] = row
        ck = _v923_candidate_key_from_paper(row)
        if ck:
            candidate_lists.setdefault(ck, []).append(row)
    by_candidate = {k: v[0] for k, v in candidate_lists.items() if len(v) == 1}
    ambiguous = {k: len(v) for k, v in candidate_lists.items() if len(v) > 1}
    return {'by_occurrence': by_occ, 'by_candidate': by_candidate, 'ambiguous_candidate': ambiguous}


def _v923_result_record_from_observation(obs: Dict[str, Any]) -> Dict[str, Any]:
    occurrence = str(obs.get('occurrence_key') or '')
    price = fnum(obs.get('price'), default=0.0)
    ts = fnum(obs.get('observed_ts'), default=0.0)
    return {
        'schema': 'good_s2_result_state_row_v923',
        'version': 'review_worker_v0.926',
        'build': 'good_s2_source_exact_result_v926_2026-06-18',
        'occurrence_key': occurrence,
        'observation_key': obs.get('observation_key'),
        'ticker': ticker_norm(obs.get('ticker')),
        'observed_ts': ts,
        'observed_text': obs.get('observed_text') or now_text(ts),
        'first_price': price,
        'latest_price': price,
        'current_pct': 0.0,
        'max_pct': 0.0,
        'min_pct': 0.0,
        'giveback_pct': 0.0,
        'max_seen_ts': ts,
        'min_seen_ts': ts,
        'samples': {},
        'entry_build_key': obs.get('entry_build_key'),
        'stable_event_key': obs.get('stable_event_key'),
        'candidate_follow_key': obs.get('candidate_follow_key'),
        'score_patch_version': obs.get('score_patch_version'),
        'initial_metrics': obs.get('metrics') if isinstance(obs.get('metrics'), dict) else {},
        'structure': obs.get('structure') if isinstance(obs.get('structure'), dict) else {},
        'structure_tags': list(obs.get('structure_tags') or [])[:12],
        'quality_tags': list(obs.get('quality_tags') or [])[:12],
        'open_linked': False,
        'closed_linked': False,
        'terminal': False,
        'result_state': 'tracking',
        'link_policy': 'occurrence key exact first; unique candidate event exact second; ticker never final',
    }


def _v923_result_final_key(rec: Dict[str, Any]) -> str:
    occ = str(rec.get('occurrence_key') or '')
    if rec.get('closed_linked') and rec.get('closed_result_key'):
        return f"{occ}|closed:{rec.get('closed_result_key')}"
    if rec.get('horizon_complete'):
        return f'{occ}|horizon:{int(GOOD_S2_RESULT_HORIZON_SEC)}'
    return ''



def _v925_reset_overcount_result_state_if_needed(nowv: float, valid_occurrences: set[str]) -> Dict[str, Any]:
    """Quarantine every non-source-backed review row, including old terminal rows.

    v925 removed only non-terminal cache rows. The 1,647 contaminated terminal rows
    therefore remained in the live state/final ledger and still distorted averages.
    v926 makes the strategy observation ledger the only valid occurrence spine.
    Removed rows are gzip-quarantined; OPEN/CLOSED ledgers are never touched.
    """
    qdir = BASE_DIR / 'quarantine'; qdir.mkdir(parents=True, exist_ok=True)
    stamp = time.strftime('%Y%m%d_%H%M%S', time.localtime(nowv))

    state = load_json(GOOD_S2_RESULT_STATE, {}) or {}
    records = state.get('records') if isinstance(state, dict) and isinstance(state.get('records'), dict) else {}
    stale_state = {str(k): v for k, v in records.items() if str(k) not in valid_occurrences and isinstance(v, dict)}
    kept_state = {str(k): v for k, v in records.items() if str(k) in valid_occurrences and isinstance(v, dict)}
    state_quarantine = ''
    if stale_state:
        state_dest = qdir / f'good_s2_result_state_non_source_{stamp}.json.gz'
        with gzip.open(state_dest, 'wt', encoding='utf-8', compresslevel=6) as f:
            json.dump({'schema':'good_s2_result_state_quarantine_v926','removed_records':stale_state,'source_state_meta':{k:v for k,v in state.items() if k!='records'}}, f, ensure_ascii=False, separators=(',', ':'), default=str)
        state_quarantine = state_dest.name
        save_json(GOOD_S2_RESULT_STATE, {
            'schema':'good_s2_result_state_v923','version':'review_worker_v0.926',
            'build':'good_s2_source_exact_result_v926_2026-06-18',
            'updated_ts':nowv,'updated_text':now_text(nowv),'records':kept_state,
            'retention_sec':GOOD_S2_RESULT_RETENTION_SEC,
        })

    ledger_rows = [r for r in read_jsonl(GOOD_S2_RESULT_LEDGER, max_lines=0) if isinstance(r, dict)]
    kept_ledger = [r for r in ledger_rows if str(r.get('occurrence_key') or '') in valid_occurrences]
    stale_ledger = [r for r in ledger_rows if str(r.get('occurrence_key') or '') not in valid_occurrences]
    ledger_quarantine = ''
    if stale_ledger:
        ledger_dest = qdir / f'good_s2_result_ledger_non_source_{stamp}.jsonl.gz'
        with gzip.open(ledger_dest, 'wt', encoding='utf-8', compresslevel=6) as f:
            for row in stale_ledger:
                f.write(json.dumps(row, ensure_ascii=False, separators=(',', ':'), default=str) + '\n')
        ledger_quarantine = ledger_dest.name
        tmp = GOOD_S2_RESULT_LEDGER.with_suffix(GOOD_S2_RESULT_LEDGER.suffix + '.v926tmp')
        tmp.parent.mkdir(parents=True, exist_ok=True)
        with tmp.open('w', encoding='utf-8') as f:
            for row in kept_ledger:
                f.write(json.dumps(row, ensure_ascii=False, separators=(',', ':'), default=str) + '\n')
            f.flush(); os.fsync(f.fileno())
        os.replace(tmp, GOOD_S2_RESULT_LEDGER)

    meta = {
        'schema':'good_s2_result_source_spine_reset_v926','completed':True,
        'state':'QUARANTINED_NON_SOURCE' if (stale_state or stale_ledger) else 'SOURCE_BACKED',
        'records_before':len(records),'records_kept':len(kept_state),
        'valid_occurrence_count':len(valid_occurrences),'removed_state_records':len(stale_state),
        'ledger_rows_before':len(ledger_rows),'ledger_rows_kept':len(kept_ledger),'removed_ledger_rows':len(stale_ledger),
        'state_quarantine_file':state_quarantine,'ledger_quarantine_file':ledger_quarantine,
        'performance_excluded':True,'updated_ts':nowv,'updated_text':now_text(nowv),
        'policy':'only strategy observation occurrence keys remain in live good-S2 result state/ledger; removed rows are gzip-quarantined',
    }
    save_json(GOOD_S2_RESULT_RESET_META_V926, meta)
    save_json(GOOD_S2_RESULT_RESET_META_V925, meta)
    return meta

def _v923_update_good_s2_results(nowv: float, fmap: Dict[str, Dict[str, Any]], ofmap: Dict[str, Dict[str, Any]]) -> Dict[str, Any]:
    observations = [r for r in read_jsonl(GOOD_S2_OBSERVATION_LEDGER, max_lines=5000)
                    if isinstance(r, dict) and str(r.get('schema') or '') == 'good_s2_observation_v923'
                    and str(r.get('version') or '') in {'strategy_worker_v0.923','strategy_worker_v0.925'}
                    and not bool(r.get('performance_excluded'))
                    and str(r.get('occurrence_key') or '')]
    valid_occurrences = {str(r.get('occurrence_key') or '') for r in observations if str(r.get('occurrence_key') or '')}
    reset_meta_v925 = _v925_reset_overcount_result_state_if_needed(nowv, valid_occurrences)
    state_obj = load_json(GOOD_S2_RESULT_STATE, {}) or {}
    records = state_obj.get('records') if isinstance(state_obj, dict) and isinstance(state_obj.get('records'), dict) else {}
    records = {str(k): dict(v) for k, v in records.items() if isinstance(v, dict) and (str(k) in valid_occurrences or bool(v.get('closed_linked')) or bool(v.get('final_result_key')))}
    new_records = 0
    for obs in observations:
        occ = str(obs.get('occurrence_key') or '')
        if occ not in records:
            records[occ] = _v923_result_record_from_observation(obs)
            new_records += 1

    open_rows = _v923_open_rows()
    closed_rows = [r for r in read_jsonl(CLOSED, max_lines=2500) if isinstance(r, dict)]
    open_maps = _v923_exact_maps(open_rows)
    closed_maps = _v923_exact_maps(closed_rows)
    final_existing = {str(r.get('final_result_key') or '') for r in read_jsonl(GOOD_S2_RESULT_LEDGER, max_lines=10000) if isinstance(r, dict) and r.get('final_result_key')}
    link_modes = Counter()
    samples_ready = Counter()
    appended_final = 0
    ticker_audit_open = 0
    ticker_audit_closed = 0
    open_tickers = {ticker_norm(r.get('ticker')) for r in open_rows if isinstance(r, dict)}
    closed_tickers = {ticker_norm(r.get('ticker')) for r in closed_rows if isinstance(r, dict)}

    for occ, rec in list(records.items()):
        if not isinstance(rec, dict):
            continue
        ticker = ticker_norm(rec.get('ticker'))
        first_price = fnum(rec.get('first_price'), default=0.0)
        cur = _current_price(ticker, fmap, ofmap) if ticker else 0.0
        if cur <= 0:
            cur = fnum(rec.get('latest_price'), default=first_price)
        if cur > 0 and first_price > 0:
            pct = _pct(cur, first_price)
            rec['latest_price'] = cur
            rec['current_pct'] = pct
            old_max = fnum(rec.get('max_pct'), default=pct)
            old_min = fnum(rec.get('min_pct'), default=pct)
            if pct >= old_max:
                rec['max_seen_ts'] = nowv
                rec['max_seen_text'] = now_text(nowv)
            if pct <= old_min:
                rec['min_seen_ts'] = nowv
                rec['min_seen_text'] = now_text(nowv)
            rec['max_pct'] = max(old_max, pct)
            rec['min_pct'] = min(old_min, pct)
            rec['giveback_pct'] = round(max(0.0, fnum(rec.get('max_pct'), default=0.0) - pct), 3)
        age = max(0.0, nowv - fnum(rec.get('observed_ts'), default=nowv))
        rec['age_sec'] = round(age, 1)
        rec['last_updated_ts'] = nowv
        rec['last_updated_text'] = now_text(nowv)
        samples = rec.get('samples') if isinstance(rec.get('samples'), dict) else {}
        for label, sec in (('3m',180),('5m',300),('10m',600),('20m',1200),('60m',3600)):
            if age >= sec and label not in samples:
                samples[label] = {
                    'ts': nowv, 'text': now_text(nowv), 'price': rec.get('latest_price'),
                    'pct': rec.get('current_pct'), 'max_pct': rec.get('max_pct'), 'min_pct': rec.get('min_pct'),
                    'giveback_pct': rec.get('giveback_pct'),
                }
            if label in samples:
                samples_ready[label] += 1
        rec['samples'] = samples

        exact = str(rec.get('entry_build_key') or '')
        open_row = open_maps['by_occurrence'].get(occ)
        open_mode = 'occurrence_exact' if isinstance(open_row, dict) else ''
        if open_row is None and exact:
            open_row = open_maps['by_candidate'].get(exact)
            open_mode = 'candidate_event_exact' if isinstance(open_row, dict) else ''
        if isinstance(open_row, dict):
            rec['open_linked'] = True
            rec['open_match_mode'] = open_mode
            rec['open_pos_id'] = open_row.get('pos_id') or open_row.get('event_id')
            rec['opened_at'] = fnum(open_row.get('opened_at'), default=0.0) or None
            rec['open_entry_price'] = fnum(open_row.get('entry_price'), default=0.0) or None
            rec['open_score_patch_version'] = open_row.get('score_patch_version') or open_row.get('entry_build_key')
            link_modes[f'open:{open_mode}'] += 1
        elif ticker and ticker in open_tickers:
            ticker_audit_open += 1

        closed_row = closed_maps['by_occurrence'].get(occ)
        closed_mode = 'occurrence_exact' if isinstance(closed_row, dict) else ''
        if closed_row is None and exact:
            closed_row = closed_maps['by_candidate'].get(exact)
            closed_mode = 'candidate_event_exact' if isinstance(closed_row, dict) else ''
        if isinstance(closed_row, dict):
            rec['closed_linked'] = True
            rec['closed_match_mode'] = closed_mode
            rec['closed_result_key'] = closed_row.get('closed_result_key')
            rec['closed_ts'] = fnum(closed_row.get('closed_ts'), closed_row.get('closed_at'), default=0.0) or None
            rec['closed_pnl_pct'] = fnum(closed_row.get('pnl_pct'), closed_row.get('profit_pct'), default=0.0)
            rec['closed_peak_pct'] = fnum(closed_row.get('peak_pct'), default=0.0)
            rec['closed_trough_pct'] = fnum(closed_row.get('trough_pct'), default=0.0)
            rec['closed_giveback_pct'] = fnum(closed_row.get('giveback_pct'), closed_row.get('missed_profit_pct'), default=0.0)
            rec['exit_reason'] = closed_row.get('exit_reason') or closed_row.get('exit_rule')
            rec['terminal'] = True
            rec['result_state'] = 'closed_exact'
            link_modes[f'closed:{closed_mode}'] += 1
        elif ticker and ticker in closed_tickers:
            ticker_audit_closed += 1

        if not rec.get('closed_linked') and age >= GOOD_S2_RESULT_HORIZON_SEC:
            rec['horizon_complete'] = True
            rec['terminal'] = True
            rec['result_state'] = 'review_horizon_6h'
        final_key = _v923_result_final_key(rec)
        if final_key and final_key not in final_existing:
            final_row = {
                'schema': 'good_s2_final_result_v923',
                'version': 'review_worker_v0.923',
                'build': 'good_s2_exact_result_tracker_v923_2026-06-17',
                'final_result_key': final_key,
                'finalized_ts': nowv,
                'finalized_text': now_text(nowv),
                **{k: rec.get(k) for k in (
                    'occurrence_key','observation_key','ticker','observed_ts','first_price','latest_price','current_pct','max_pct','min_pct','giveback_pct',
                    'entry_build_key','stable_event_key','candidate_follow_key','score_patch_version','open_linked','open_match_mode','open_pos_id','opened_at','open_entry_price',
                    'closed_linked','closed_match_mode','closed_result_key','closed_ts','closed_pnl_pct','closed_peak_pct','closed_trough_pct','closed_giveback_pct','exit_reason',
                    'horizon_complete','result_state','samples','initial_metrics','structure','structure_tags','quality_tags')},
                'performance_eligible': True,
                'join_policy': 'exact occurrence or unique candidate event only; no ticker final join',
            }
            _v923_append_jsonl(GOOD_S2_RESULT_LEDGER, final_row)
            final_existing.add(final_key)
            rec['final_result_key'] = final_key
            rec['finalized_ts'] = nowv
            appended_final += 1

    # Keep completed state seven days; source/final ledgers remain preserved.
    kept: Dict[str, Dict[str, Any]] = {}
    pruned = 0
    for occ, rec in records.items():
        ref = fnum(rec.get('closed_ts'), rec.get('finalized_ts'), rec.get('last_updated_ts'), rec.get('observed_ts'), default=nowv)
        if rec.get('terminal') and nowv - ref > GOOD_S2_RESULT_RETENTION_SEC:
            pruned += 1
            continue
        kept[occ] = rec
    records = kept
    rows = list(records.values())
    closed_exact = [r for r in rows if r.get('closed_linked')]
    opened_exact = [r for r in rows if r.get('open_linked')]
    tracking = [r for r in rows if not r.get('terminal')]
    max_vals = [fnum(r.get('max_pct'), default=0.0) for r in rows]
    min_vals = [fnum(r.get('min_pct'), default=0.0) for r in rows]
    give_vals = [fnum(r.get('giveback_pct'), default=0.0) for r in rows]
    closed_pnls = [fnum(r.get('closed_pnl_pct'), default=0.0) for r in closed_exact]
    result_ledger_rows = len(read_jsonl(GOOD_S2_RESULT_LEDGER, max_lines=0))
    result_ledger_bytes = GOOD_S2_RESULT_LEDGER.stat().st_size if GOOD_S2_RESULT_LEDGER.exists() else 0
    recent = sorted(rows, key=lambda r: fnum(r.get('observed_ts'), default=0.0), reverse=True)[:80]
    snapshot = {
        'schema': 'good_s2_result_snapshot_v923',
        'version': 'review_worker_v0.926',
        'build': 'good_s2_source_exact_result_v926_2026-06-18',
        'updated_ts': nowv,
        'updated_text': now_text(nowv),
        'source_observation_rows_v923': len(observations),
        'state_reset_v925': reset_meta_v925,
        'new_records_this_cycle': new_records,
        'tracked_total': len(rows),
        'tracking_active': len(tracking),
        'opened_exact': len(opened_exact),
        'closed_exact': len(closed_exact),
        'horizon_complete': sum(1 for r in rows if r.get('horizon_complete')),
        'unmatched_exact': sum(1 for r in rows if not r.get('open_linked') and not r.get('closed_linked')),
        'ticker_audit_only_open': ticker_audit_open,
        'ticker_audit_only_closed': ticker_audit_closed,
        'link_mode_counts': dict(link_modes),
        'samples_ready': dict(samples_ready),
        'avg_max_pct': round(sum(max_vals)/len(max_vals), 4) if max_vals else None,
        'avg_min_pct': round(sum(min_vals)/len(min_vals), 4) if min_vals else None,
        'avg_giveback_pct': round(sum(give_vals)/len(give_vals), 4) if give_vals else None,
        'closed_wins': sum(1 for x in closed_pnls if x > 0),
        'closed_losses': sum(1 for x in closed_pnls if x <= 0),
        'closed_avg_pnl_pct': round(sum(closed_pnls)/len(closed_pnls), 4) if closed_pnls else None,
        'closed_sum_pnl_pct': round(sum(closed_pnls), 4) if closed_pnls else None,
        'final_appended_this_cycle': appended_final,
        'final_ledger_rows': result_ledger_rows,
        'final_ledger_bytes': result_ledger_bytes,
        'state_pruned_this_cycle': pruned,
        'review_horizon_sec': GOOD_S2_RESULT_HORIZON_SEC,
        'rows': recent,
        'last_row': recent[0] if recent else None,
        'policy': 'strategy occurrence -> live price path -> paper OPEN/CLOSED exact; ticker is audit only; no trading criteria change',
        'conditions_changed': False,
        'paper_open_changed': False,
        'exit_changed': False,
    }
    save_json(GOOD_S2_RESULT_STATE, {
        'schema': 'good_s2_result_state_v923', 'version': 'review_worker_v0.926',
        'build': 'good_s2_source_exact_result_v926_2026-06-18',
        'updated_ts': nowv, 'updated_text': now_text(nowv), 'records': records,
        'retention_sec': GOOD_S2_RESULT_RETENTION_SEC,
    })
    save_json(GOOD_S2_RESULT_SNAPSHOT, snapshot)
    return snapshot



def _quality_optional_num(*values: Any) -> Optional[float]:
    for value in values:
        if value in (None, '', '-', [], {}):
            continue
        try:
            number = float(str(value).replace(',', '').replace('%', ''))
        except Exception:
            continue
        if number == number and number not in (float('inf'), float('-inf')):
            return number
    return None


def _quality_exact_identity(row: Dict[str, Any]) -> tuple[str, str]:
    """Decision exact first, candidate exact second. Ticker/time-near is never an identity."""
    if not isinstance(row, dict):
        return '', ''
    gate = row.get('minimal_entry_gate_v925') if isinstance(row.get('minimal_entry_gate_v925'), dict) else {}
    decision = row.get('minimal_gate_decision_key_v925') or gate.get('decision_key')
    if decision not in (None, '', '-', [], {}):
        return 'decision:' + str(decision).strip(), 'minimal_gate_decision_exact'
    candidate = row.get('entry_build_key')
    if candidate not in (None, '', '-', [], {}):
        return 'candidate:' + str(candidate).strip(), 'candidate_entry_build_exact'
    return '', ''


def _quality_gate(row: Dict[str, Any]) -> Dict[str, Any]:
    gate = row.get('minimal_entry_gate_v925')
    return gate if isinstance(gate, dict) else {}


def _quality_block_reasons(row: Dict[str, Any], gate: Dict[str, Any]) -> List[str]:
    values = gate.get('hard_block_reasons') if isinstance(gate.get('hard_block_reasons'), list) else row.get('final_trade_reasons')
    seq = values if isinstance(values, list) else ([values] if values not in (None, '', '-', [], {}) else [])
    out: List[str] = []
    for item in seq:
        text = str(item or '').strip()
        if text and text not in out:
            out.append(text)
    return out


def _quality_cohort(hard_pass: bool, reasons: List[str]) -> str:
    if hard_pass:
        return 's1_pass'
    priority = (
        'frozen_trigger_not_reached',
        'risk_reward_below_minimum',
        'target_room_below_minimum',
        'coherent_structure_plan_incomplete',
        'actual_structural_invalid_missing',
        'next_structural_target_missing',
        'candidate_sources_not_fresh',
        'untradable_spread',
        'untradable_liquidity',
    )
    for reason in priority:
        if reason in reasons:
            return reason
    return reasons[0] if reasons else 'other_blocked'


def _seal_quality_event_context(row: Dict[str, Any], feature_row: Dict[str, Any], regime_snapshot: Dict[str, Any], observed_ts: float) -> Dict[str, Any]:
    """Create immutable event-time market and turnover context exactly once."""
    row = row if isinstance(row, dict) else {}
    feature_row = feature_row if isinstance(feature_row, dict) else {}
    regime_snapshot = regime_snapshot if isinstance(regime_snapshot, dict) else {}
    market_obj = row.get('market_regime') if isinstance(row.get('market_regime'), dict) else {}
    tags = row.get('market_regime_tags') if isinstance(row.get('market_regime_tags'), list) else market_obj.get('tags') if isinstance(market_obj.get('tags'), list) else []
    risks = row.get('market_risk_tags') if isinstance(row.get('market_risk_tags'), list) else market_obj.get('risk_tags') if isinstance(market_obj.get('risk_tags'), list) else []
    summary = str(row.get('market_regime_summary') or market_obj.get('summary') or '').strip()

    row_mode = str(row.get('market_mode') or row.get('market_state') or row.get('regime') or market_obj.get('mode') or '').strip()
    feature_mode = str(feature_row.get('market_mode') or feature_row.get('market_state') or feature_row.get('regime') or '').strip()
    regime_mode = str(regime_snapshot.get('market_mode') or regime_snapshot.get('mode') or '').strip()
    mode = row_mode or feature_mode or regime_mode

    row_strength = _quality_optional_num(row.get('market_strength'), row.get('market_breadth'), row.get('regime_strength'))
    feature_strength = _quality_optional_num(feature_row.get('market_strength'), feature_row.get('market_breadth'), feature_row.get('regime_strength'))
    regime_strength = _quality_optional_num(regime_snapshot.get('market_strength'), regime_snapshot.get('market_breadth'), regime_snapshot.get('regime_strength'))
    strength = row_strength if row_strength is not None else feature_strength if feature_strength is not None else regime_strength

    text = ' / '.join([mode, summary, *[str(x) for x in tags], *[str(x) for x in risks]]).lower()
    if any(x in text for x in ('상승','강함','bull','strong')) or (strength is not None and strength >= 0.2):
        label = 'up_or_strong'
    elif any(x in text for x in ('하락','약함','bear','weak','급락')) or (strength is not None and strength <= -0.2):
        label = 'down_or_weak'
    elif any(x in text for x in ('횡보','side','neutral','보통')):
        label = 'sideways_or_neutral'
    else:
        label = 'context_missing'

    if row_mode or tags or summary or row_strength is not None:
        market_source = 'candidate_snapshot_at_event'
    elif feature_mode or feature_strength is not None:
        market_source = 'feature_snapshot_at_event'
    elif regime_mode or regime_strength is not None:
        market_source = 'regime_snapshot_at_event'
    else:
        market_source = 'legacy_context_missing'

    row_turnover = _quality_optional_num(row.get('turnover_24h'), row.get('trade_value_24h'), row.get('acc_trade_price_24h'))
    feature_turnover = _quality_optional_num(feature_row.get('turnover_24h'), feature_row.get('trade_value_24h'), feature_row.get('acc_trade_price_24h'))
    turnover = row_turnover if row_turnover is not None else feature_turnover
    row_volume_ratio = _quality_optional_num(row.get('volume_ratio'), row.get('trade_value_ratio'), row.get('volume_expansion_ratio'))
    feature_volume_ratio = _quality_optional_num(feature_row.get('volume_ratio'), feature_row.get('trade_value_ratio'), feature_row.get('volume_expansion_ratio'))
    volume_ratio = row_volume_ratio if row_volume_ratio is not None else feature_volume_ratio
    turnover_change = _quality_optional_num(
        row.get('turnover_change_pct'), row.get('trade_value_change_pct'), row.get('volume_expansion_pct'),
        feature_row.get('turnover_change_pct'), feature_row.get('trade_value_change_pct'), feature_row.get('volume_expansion_pct')
    )
    if row_turnover is not None or row_volume_ratio is not None:
        turnover_source = 'candidate_snapshot_at_event'
    elif feature_turnover is not None or feature_volume_ratio is not None:
        turnover_source = 'feature_snapshot_at_event'
    else:
        turnover_source = 'legacy_context_missing'

    return {
        'schema': QUALITY_EVENT_CONTEXT_SCHEMA,
        'sealed_at_ts': observed_ts,
        'sealed_at_text': now_text(observed_ts),
        'market_regime': label,
        'market_mode': mode or None,
        'market_summary': summary or None,
        'market_tags': [str(x) for x in tags[:8]],
        'market_risk_tags': [str(x) for x in risks[:6]],
        'market_strength': strength,
        'market_context_source': market_source,
        'market_context_sealed': label != 'context_missing',
        'turnover_24h': turnover,
        'volume_ratio': volume_ratio,
        'turnover_change_pct': turnover_change,
        'turnover_context_source': turnover_source,
        'turnover_context_sealed': turnover is not None or volume_ratio is not None,
        'immutable_event_time_context': True,
        'context_cutover':'v965_new_event_only',
    }


def _legacy_missing_event_context() -> Dict[str, Any]:
    return {
        'schema': QUALITY_EVENT_CONTEXT_SCHEMA,
        'sealed_at_ts': None,
        'sealed_at_text': None,
        'market_regime': 'context_missing',
        'market_mode': None,
        'market_summary': None,
        'market_tags': [],
        'market_risk_tags': [],
        'market_strength': None,
        'market_context_source': 'legacy_context_missing',
        'market_context_sealed': False,
        'turnover_24h': None,
        'volume_ratio': None,
        'turnover_change_pct': None,
        'turnover_context_source': 'legacy_context_missing',
        'turnover_context_sealed': False,
        'immutable_event_time_context': True,
        'legacy_before_v965_context_spine': True,
    }


def _quality_initial_metrics(row: Dict[str, Any], gate: Dict[str, Any]) -> Dict[str, Any]:
    """Mutable non-context metrics only. Event market context lives in rec['event_context']."""
    quality = row.get('quality_observation_v925') if isinstance(row.get('quality_observation_v925'), dict) else {}
    hot = row.get('hot_watch_timing_v945') if isinstance(row.get('hot_watch_timing_v945'), dict) else {}
    return {
        'price_reaction_pct': _quality_optional_num(row.get('price_reaction_pct'), row.get('change_1m_pct'), quality.get('price_reaction_pct')),
        'buy_ratio': _quality_optional_num(row.get('buy_ratio'), row.get('buy_trade_ratio'), quality.get('buy_ratio')),
        'buy_sustain_1m': _quality_optional_num(row.get('buy_sustain_1m'), row.get('buy_sustain_60s'), quality.get('buy_sustain_1m')),
        'spread_pct': _quality_optional_num(gate.get('spread_pct'), row.get('spread_pct'), row.get('micro_spread_pct')),
        'risk_reward': _quality_optional_num(gate.get('risk_reward')),
        'target_room_pct': _quality_optional_num(gate.get('target_room_pct')),
        'trigger_gap_pct': _quality_optional_num(row.get('trigger_gap_pct'), (gate.get('structure_plan') or {}).get('distance_pct') if isinstance(gate.get('structure_plan'), dict) else None),
        'relative_strength': _quality_optional_num(row.get('relative_strength'), row.get('relative_strength_score'), quality.get('relative_strength')),
        'money_flow': _quality_optional_num(row.get('money_flow'), row.get('money_flow_score'), quality.get('money_flow')),
        'scanner_to_candidate_sec': _quality_optional_num(hot.get('scanner_to_strategy_sec')),
        'scanner_to_s2_sec': _quality_optional_num(hot.get('scanner_to_s2_sec')),
        'scanner_to_s1_sec': _quality_optional_num(hot.get('scanner_to_s1_sec')),
        'first_price': _quality_optional_num(row.get('current_price'), row.get('entry_price'), row.get('price'), row.get('detected_price')),
        'confirmed_slippage_pct': _quality_optional_num(row.get('slippage_pct_confirmed')),
        'confirmed_slippage_source': str(row.get('slippage_pct_source_v903') or row.get('slippage_pct_source') or '').strip() or None,
        'smart_structure_shadow_v948': row.get('smart_structure_shadow_v948') if isinstance(row.get('smart_structure_shadow_v948'),dict) else None,
    }


def _quality_load_final_keys() -> set[str]:
    global _QUALITY_FINAL_KEYS_CACHE
    if _QUALITY_FINAL_KEYS_CACHE is not None:
        return _QUALITY_FINAL_KEYS_CACHE
    keys: set[str] = set()
    paths: List[Path] = []
    if QUALITY_SHADOW_LEDGER.exists(): paths.append(QUALITY_SHADOW_LEDGER)
    if QUALITY_SHADOW_ARCHIVE.exists(): paths.extend(sorted(QUALITY_SHADOW_ARCHIVE.glob('quality_shadow_result_*.jsonl.gz')))
    for path in paths:
        try:
            if path.suffix == '.gz':
                handle = gzip.open(path, 'rt', encoding='utf-8')
            else:
                handle = path.open('r', encoding='utf-8', errors='ignore')
            with handle:
                for line in handle:
                    try:
                        obj=json.loads(line)
                    except Exception:
                        continue
                    if isinstance(obj,dict) and obj.get('quality_event_key_v946'):
                        keys.add(str(obj.get('quality_event_key_v946')))
        except Exception as exc:
            append_error(ERROR, 'quality_shadow_final_key_load', exc)
    _QUALITY_FINAL_KEYS_CACHE=keys
    return keys


def _quality_append_final(row: Dict[str, Any]) -> bool:
    key=str(row.get('quality_event_key_v946') or '')
    if not key:
        raise ValueError('quality_event_key_v946 missing on final append')
    keys=_quality_load_final_keys()
    if key in keys:
        return False
    QUALITY_SHADOW_LEDGER.parent.mkdir(parents=True, exist_ok=True)
    with QUALITY_SHADOW_LEDGER.open('a', encoding='utf-8') as handle:
        handle.write(json.dumps(row, ensure_ascii=False, separators=(',', ':'), default=str) + '\n')
        handle.flush()
        os.fsync(handle.fileno())
    keys.add(key)
    return True


def _quality_rotate_ledger(nowv: float) -> Dict[str, Any]:
    if not QUALITY_SHADOW_LEDGER.exists() or QUALITY_SHADOW_LEDGER.stat().st_size <= QUALITY_SHADOW_LEDGER_MAX_BYTES:
        return {'rotated':False,'moved_rows':0,'archive_file':None}
    lines=QUALITY_SHADOW_LEDGER.read_text(encoding='utf-8',errors='ignore').splitlines()
    keep=max(1,min(QUALITY_SHADOW_LEDGER_KEEP_LINES,len(lines)))
    moved=lines[:-keep]; remain=lines[-keep:]
    if not moved:
        return {'rotated':False,'moved_rows':0,'archive_file':None}
    QUALITY_SHADOW_ARCHIVE.mkdir(parents=True,exist_ok=True)
    stamp=time.strftime('%Y%m%d_%H%M%S',time.localtime(nowv))
    archive=QUALITY_SHADOW_ARCHIVE/f'quality_shadow_result_{stamp}.jsonl.gz'
    with gzip.open(archive,'wt',encoding='utf-8',compresslevel=6) as handle:
        for line in moved: handle.write(line+'\n')
    tmp=QUALITY_SHADOW_LEDGER.with_suffix('.jsonl.tmp')
    tmp.write_text('\n'.join(remain)+'\n',encoding='utf-8')
    os.replace(tmp,QUALITY_SHADOW_LEDGER)
    return {'rotated':True,'moved_rows':len(moved),'archive_file':archive.name}


def _quality_percentile(values: List[float], q: float) -> Optional[float]:
    vals=sorted(float(v) for v in values if isinstance(v,(int,float)))
    if not vals: return None
    pos=(len(vals)-1)*max(0.0,min(1.0,float(q)))
    lo=int(pos); hi=min(len(vals)-1,lo+1); frac=pos-lo
    return vals[lo]*(1.0-frac)+vals[hi]*frac


def _quality_metric_stats(vals: List[float], peaks: List[float], troughs: List[float], givebacks: List[float]) -> Dict[str, Any]:
    if not vals: return {}
    return {
        'n':len(vals),
        'avg_pct':round(sum(vals)/len(vals),4),
        'median_pct':round(_quality_percentile(vals,0.50),4),
        'p10_pct':round(_quality_percentile(vals,0.10),4),
        'p90_pct':round(_quality_percentile(vals,0.90),4),
        'positive_0_1_count':sum(1 for v in vals if v>=0.10),
        'negative_0_1_count':sum(1 for v in vals if v<=-0.10),
        'avg_max_pct':round(sum(peaks)/len(peaks),4) if peaks else None,
        'avg_min_pct':round(sum(troughs)/len(troughs),4) if troughs else None,
        'avg_giveback_pct':round(sum(givebacks)/len(givebacks),4) if givebacks else None,
    }


def _quality_summary_stats(rows: List[Dict[str, Any]]) -> Dict[str, Any]:
    out: Dict[str, Any] = {}
    by_cohort: Dict[str, List[Dict[str, Any]]] = {}
    for row in rows:
        by_cohort.setdefault(str(row.get('cohort') or 'unknown'), []).append(row)
    for cohort, cohort_rows in by_cohort.items():
        item: Dict[str, Any] = {'tracked': len(cohort_rows)}
        occurrence_first: Dict[str, Dict[str, Any]] = {}
        for row in cohort_rows:
            occ=str(row.get('hot_watch_occurrence_key_v945') or '').strip()
            if not occ: continue
            current=occurrence_first.get(occ)
            if current is None or (_quality_optional_num(row.get('first_seen_ts')) or 0.0) < (_quality_optional_num(current.get('first_seen_ts')) or 0.0):
                occurrence_first[occ]=row
        item['unique_hot_occurrences']=len(occurrence_first)
        for label, _ in QUALITY_SHADOW_HORIZONS:
            vals=[]; peaks=[]; troughs=[]; givebacks=[]
            for row in cohort_rows:
                sample=(row.get('samples') or {}).get(label) if isinstance(row.get('samples'), dict) else None
                if not isinstance(sample, dict): continue
                v=_quality_optional_num(sample.get('pct')); p=_quality_optional_num(sample.get('max_pct')); t=_quality_optional_num(sample.get('min_pct')); g=_quality_optional_num(sample.get('giveback_pct'))
                if v is not None: vals.append(v)
                if p is not None: peaks.append(p)
                if t is not None: troughs.append(t)
                if g is not None: givebacks.append(g)
            stats=_quality_metric_stats(vals,peaks,troughs,givebacks)
            if stats: item[label]=stats
            occ_vals=[]; occ_peaks=[]; occ_troughs=[]; occ_givebacks=[]
            for row in occurrence_first.values():
                sample=(row.get('samples') or {}).get(label) if isinstance(row.get('samples'),dict) else None
                if not isinstance(sample,dict): continue
                v=_quality_optional_num(sample.get('pct')); p=_quality_optional_num(sample.get('max_pct')); t=_quality_optional_num(sample.get('min_pct')); g=_quality_optional_num(sample.get('giveback_pct'))
                if v is not None: occ_vals.append(v)
                if p is not None: occ_peaks.append(p)
                if t is not None: occ_troughs.append(t)
                if g is not None: occ_givebacks.append(g)
            occ_stats=_quality_metric_stats(occ_vals,occ_peaks,occ_troughs,occ_givebacks)
            if occ_stats: item[label+'_occurrence']=occ_stats
        out[cohort] = item
    return out



def _late_num(value: Any) -> Optional[float]:
    return _quality_optional_num(value)


def _late_nested_values(row: Dict[str, Any]) -> List[Dict[str, Any]]:
    out=[row]
    for key in ('paper_timing_spine_v940','quality_evidence_v938','quality_evidence_v936','entry_diagnostics'):
        obj=row.get(key) if isinstance(row,dict) else None
        if isinstance(obj,dict): out.append(obj)
    diag=row.get('entry_diagnostics') if isinstance(row,dict) and isinstance(row.get('entry_diagnostics'),dict) else {}
    for key in ('paper_timing_spine_v940','quality_evidence_v938','quality_evidence_v936'):
        obj=diag.get(key) if isinstance(diag,dict) else None
        if isinstance(obj,dict): out.append(obj)
    return out


def _late_first(row: Dict[str, Any], keys: tuple[str,...]) -> Any:
    for obj in _late_nested_values(row):
        for key in keys:
            value=obj.get(key)
            if value not in (None,'',[],{}): return value
    return None


def _late_stage_stats(values: List[float]) -> Dict[str, Any]:
    vals=[float(v) for v in values if isinstance(v,(int,float)) and v>=0]
    if not vals: return {'n':0}
    return {
        'n':len(vals),'avg_sec':round(sum(vals)/len(vals),3),'median_sec':round(_quality_percentile(vals,0.50),3),
        'p90_sec':round(_quality_percentile(vals,0.90),3),'max_sec':round(max(vals),3),
        'gt60_count':sum(1 for v in vals if v>=60.0),'gt180_count':sum(1 for v in vals if v>=180.0),
    }


def _late_outcome_quartiles(rows: List[Dict[str, Any]], delay_key: str, sample_label: str='10m') -> Dict[str, Any]:
    pairs=[]
    for rec in rows:
        delay=_late_num((rec.get('initial_metrics') or {}).get(delay_key) if isinstance(rec.get('initial_metrics'),dict) else None)
        sample=(rec.get('samples') or {}).get(sample_label) if isinstance(rec.get('samples'),dict) else None
        pct=_late_num(sample.get('pct')) if isinstance(sample,dict) else None
        if delay is not None and pct is not None: pairs.append((delay,pct,rec))
    if len(pairs)<4: return {'n':len(pairs),'sample_label':sample_label}
    delays=[x[0] for x in pairs]; q25=_quality_percentile(delays,0.25); q75=_quality_percentile(delays,0.75)
    def bundle(selected):
        vals=[x[1] for x in selected]
        return {'n':len(vals),'avg_pct':round(sum(vals)/len(vals),4) if vals else None,'median_pct':round(_quality_percentile(vals,0.50),4) if vals else None,'positive_0_1_count':sum(1 for v in vals if v>=0.1),'negative_0_1_count':sum(1 for v in vals if v<=-0.1)}
    fast=[x for x in pairs if x[0]<=q25]; slow=[x for x in pairs if x[0]>=q75]
    return {'n':len(pairs),'sample_label':sample_label,'q25_sec':round(q25,3),'q75_sec':round(q75,3),'fast':bundle(fast),'slow':bundle(slow)}


def _late_occurrence_rows(records: List[Dict[str, Any]]) -> List[Dict[str, Any]]:
    by_occ: Dict[str, Dict[str, Any]]={}
    no_occ=[]
    timing_names=('scanner_to_candidate_sec','scanner_to_s2_sec','scanner_to_s1_sec')
    for rec in records:
        occ=str(rec.get('hot_watch_occurrence_key_v945') or '').strip()
        if not occ:
            no_occ.append(rec); continue
        cur=by_occ.get(occ)
        if cur is None:
            by_occ[occ]=dict(rec); continue
        cur_ts=_late_num(cur.get('first_seen_ts')) or 0.0; new_ts=_late_num(rec.get('first_seen_ts')) or 0.0
        if new_ts and (not cur_ts or new_ts<cur_ts):
            base=dict(rec); prior=cur
        else:
            base=cur; prior=rec
        merged=base.get('initial_metrics') if isinstance(base.get('initial_metrics'),dict) else {}
        other=prior.get('initial_metrics') if isinstance(prior.get('initial_metrics'),dict) else {}
        for name in timing_names:
            values=[v for v in (_late_num(merged.get(name)),_late_num(other.get(name))) if v is not None]
            if values: merged[name]=min(values)
        base['initial_metrics']=merged
        by_occ[occ]=base
    return list(by_occ.values())+no_occ


def update_late_path_status(nowv: float, quality_records: List[Dict[str, Any]]) -> Dict[str, Any]:
    """Review-owned latency decomposition. Read-only observation; never used by entry/exit."""
    occurrence_rows=_late_occurrence_rows(quality_records)
    stage_values={'scanner_to_candidate_sec':[],'scanner_to_s2_sec':[],'scanner_to_s1_sec':[],'candidate_to_s2_sec':[],'s2_to_s1_sec':[]}
    samples=[]
    for rec in occurrence_rows:
        metrics=rec.get('initial_metrics') if isinstance(rec.get('initial_metrics'),dict) else {}
        c=_late_num(metrics.get('scanner_to_candidate_sec')); s2=_late_num(metrics.get('scanner_to_s2_sec')); s1=_late_num(metrics.get('scanner_to_s1_sec'))
        if c is not None: stage_values['scanner_to_candidate_sec'].append(c)
        if s2 is not None: stage_values['scanner_to_s2_sec'].append(s2)
        if s1 is not None: stage_values['scanner_to_s1_sec'].append(s1)
        if c is not None and s2 is not None and s2>=c: stage_values['candidate_to_s2_sec'].append(s2-c)
        if s2 is not None and s1 is not None and s1>=s2: stage_values['s2_to_s1_sec'].append(s1-s2)
        if any(v is not None and v>=60 for v in (c,s2,s1)):
            samples.append({'ticker':rec.get('ticker'),'occurrence_key':rec.get('hot_watch_occurrence_key_v945'),'scanner_to_candidate_sec':c,'scanner_to_s2_sec':s2,'scanner_to_s1_sec':s1,'cohort':rec.get('cohort'),'m10_pct':_late_num(((rec.get('samples') or {}).get('10m') or {}).get('pct')) if isinstance(rec.get('samples'),dict) else None})
    decision_obj=load_json(PAPER_DECISION_STATE,{}) or {}
    decision_records=decision_obj.get('records') if isinstance(decision_obj,dict) and isinstance(decision_obj.get('records'),dict) else {}
    paper_values={'first_to_open_sec':[],'s1_to_selected_sec':[],'trigger_to_selected_sec':[],'selected_to_open_sec':[],'trigger_to_open_sec':[]}
    for raw in decision_records.values():
        if not isinstance(raw,dict): continue
        mappings={
            'first_to_open_sec':('first_to_open_delay_sec','first_to_paper_delay_sec'),
            's1_to_selected_sec':('s1_to_selected_delay_sec',),
            'trigger_to_selected_sec':('trigger_to_selected_delay_sec',),
            'selected_to_open_sec':('selected_to_open_delay_sec','selected_delay_sec'),
            'trigger_to_open_sec':('trigger_to_open_delay_sec',),
        }
        for name,keys in mappings.items():
            value=_late_num(_late_first(raw,keys))
            if value is not None and value>=0: paper_values[name].append(value)
    stages={name:_late_stage_stats(vals) for name,vals in stage_values.items()}
    paper={name:_late_stage_stats(vals) for name,vals in paper_values.items()}
    outcome={name:_late_outcome_quartiles(occurrence_rows,name,'10m') for name in ('scanner_to_candidate_sec','scanner_to_s2_sec','scanner_to_s1_sec')}
    bottlenecks=[]
    for name,stats in stages.items():
        if stats.get('n'):
            bottlenecks.append({'stage':name,**stats})
    bottlenecks.sort(key=lambda x:(x.get('p90_sec') or 0.0,x.get('max_sec') or 0.0),reverse=True)
    status={
        'schema':'late_path_status_v947','version':'review_worker_v0.948','build':'late_exact_stage_decomposition_v947_2026-06-19','state':'ACTIVE',
        'updated_ts':nowv,'updated_text':now_text(nowv),'quality_exact_records':len(quality_records),'occurrence_normalized_records':len(occurrence_rows),
        'stages':stages,'paper_stages':paper,'outcome_quartiles_10m':outcome,'bottleneck_order':bottlenecks[:5],
        'slow_samples':sorted(samples,key=lambda x:max([v for v in (x.get('scanner_to_candidate_sec'),x.get('scanner_to_s2_sec'),x.get('scanner_to_s1_sec')) if isinstance(v,(int,float))] or [0]),reverse=True)[:8],
        'identity_policy':'hot occurrence normalized for latency distribution; exact candidate records remain source evidence; ticker never joins final results',
        'policy':'observation only; no S grade, trigger, entry, exit, protection or cost criteria change',
        'conditions_changed':False,'trigger_changed':False,'paper_open_changed':False,'exit_changed':False,'auto_buy':False,
    }
    save_json(LATE_PATH_STATUS,status)
    return status


def _migrate_quality_event_context_once(records: Dict[str, Dict[str, Any]], state_obj: Dict[str, Any], nowv: float) -> tuple[int, Dict[str, Any]]:
    """One-time v965 cutover: distrust all prior context, preserve price paths, then trust only events created after this cutover."""
    marker = state_obj.get('event_context_migration') if isinstance(state_obj, dict) and isinstance(state_obj.get('event_context_migration'), dict) else {}
    if marker.get('schema') == QUALITY_EVENT_CONTEXT_MIGRATION_SCHEMA and marker.get('done') is True:
        return 0, marker
    removed_fields = (
        'turnover_24h','volume_ratio','turnover_change_pct','market_strength','market_regime',
        'market_regime_mode','market_regime_summary','market_regime_tags','market_risk_tags',
        'market_context_source','market_context_sealed',
    )
    changed = 0
    for rec in records.values():
        if not isinstance(rec, dict):
            continue
        metrics = rec.get('initial_metrics') if isinstance(rec.get('initial_metrics'), dict) else {}
        for key in removed_fields:
            metrics.pop(key, None)
        rec['initial_metrics'] = metrics
        rec['event_context'] = _legacy_missing_event_context()
        changed += 1
    marker = {
        'schema': QUALITY_EVENT_CONTEXT_MIGRATION_SCHEMA,
        'done': True,
        'migrated_at_ts': nowv,
        'migrated_at_text': now_text(nowv),
        'records_reset_to_legacy_missing': changed,
        'policy': 'v965 one-time cutover; every existing event becomes legacy missing; only newly created events receive immutable context',
    }
    return changed, marker


def update_quality_shadow(nowv: float, fmap: Dict[str, Dict[str, Any]], ofmap: Dict[str, Dict[str, Any]]) -> Dict[str, Any]:
    """Observe current gate cohorts and later price paths without affecting any trade decision."""
    source_rows = [row for row in read_jsonl(PAPER_LATEST, max_lines=0) if isinstance(row, dict)]
    regime_loaded=load_json(REGIME,{})
    regime_snapshot=regime_loaded if isinstance(regime_loaded,dict) else {}
    state_obj = load_json(QUALITY_SHADOW_STATE, {}) or {}
    records = state_obj.get('records') if isinstance(state_obj, dict) and isinstance(state_obj.get('records'), dict) else {}
    records = {str(k): dict(v) for k, v in records.items() if isinstance(v, dict)}
    event_context_migrated, event_context_migration = _migrate_quality_event_context_once(records, state_obj, nowv)
    exact_ready=0; exact_missing=0; created=0; finalized=0; source_seen=set(); reason_counts=Counter(); cohort_counts=Counter()

    for row in source_rows:
        exact_key, identity_mode = _quality_exact_identity(row)
        if not exact_key:
            exact_missing += 1
            continue
        exact_ready += 1; source_seen.add(exact_key)
        ticker = ticker_norm(row.get('ticker') or row.get('market') or row.get('symbol'))
        gate = _quality_gate(row); reasons = _quality_block_reasons(row, gate)
        hard_pass = bool(gate.get('hard_pass'))
        cohort = _quality_cohort(hard_pass, reasons)
        for reason in reasons: reason_counts[reason] += 1
        cohort_counts[cohort] += 1
        current = _current_price(ticker, fmap, ofmap) or _quality_optional_num(row.get('current_price'), row.get('entry_price'), row.get('price'), row.get('detected_price')) or 0.0
        rec = records.get(exact_key)
        if rec is None:
            if current <= 0:
                continue
            rec = {
                'schema':'quality_shadow_state_row_v947','version':'review_worker_v0.948','build':'quality_exact_gate_path_retention_v947_2026-06-19',
                'quality_event_key_v946':exact_key,'identity_mode_v946':identity_mode,'entry_build_key':row.get('entry_build_key'),'minimal_gate_decision_key_v925':row.get('minimal_gate_decision_key_v925'),
                'ticker':ticker,'hot_watch_occurrence_key_v945':str((row.get('hot_watch_timing_v945') or {}).get('hot_watch_occurrence_key_v945') or row.get('hot_watch_occurrence_key_v945') or ''),'first_seen_ts':nowv,'first_seen_text':now_text(nowv),'first_price':current,
                'stage_at_first':str(gate.get('stage') or row.get('s_stage') or row.get('candidate_stage') or '-'),
                'hard_pass_at_first':hard_pass,'ever_hard_pass':hard_pass,'first_pass_ts':nowv if hard_pass else None,'cohort':cohort,'hard_block_reasons':reasons,
                'initial_metrics':_quality_initial_metrics(row,gate),'event_context':_seal_quality_event_context(row,fmap.get(ticker),regime_snapshot,nowv),'samples':{},'max_pct':0.0,'min_pct':0.0,'giveback_pct':0.0,
                'last_price':current,'last_seen_ts':nowv,'last_candidate_seen_ts':nowv,'final_appended':False,
                'identity_policy':'entry_build_key exact only; ticker is price-source lookup only; no ticker result join',
                'observation_only':True,'used_for_entry_gate':False,'used_for_exit':False,
            }
            records[exact_key]=rec; created += 1
        else:
            rec['last_candidate_seen_ts']=nowv
            rec['last_hard_pass']=hard_pass
            if hard_pass and not rec.get('ever_hard_pass'):
                rec['ever_hard_pass']=True; rec['first_pass_ts']=nowv
            rec['last_stage']=str(gate.get('stage') or row.get('s_stage') or row.get('candidate_stage') or rec.get('last_stage') or '-')
            rec['last_hard_block_reasons']=reasons
            hot_key=str((row.get('hot_watch_timing_v945') or {}).get('hot_watch_occurrence_key_v945') or row.get('hot_watch_occurrence_key_v945') or '')
            if hot_key and not rec.get('hot_watch_occurrence_key_v945'): rec['hot_watch_occurrence_key_v945']=hot_key
            existing_metrics=rec.get('initial_metrics') if isinstance(rec.get('initial_metrics'),dict) else {}
            fresh_metrics=_quality_initial_metrics(row,gate)
            for metric_name,metric_value in fresh_metrics.items():
                if metric_value is not None and existing_metrics.get(metric_name) is None:
                    existing_metrics[metric_name]=metric_value
            rec['initial_metrics']=existing_metrics

    for exact_key, rec in list(records.items()):
        ticker=ticker_norm(rec.get('ticker'))
        current=_current_price(ticker,fmap,ofmap)
        base=_quality_optional_num(rec.get('first_price')) or 0.0
        if current > 0 and base > 0:
            pct=round((current-base)/base*100.0,6)
            rec['last_price']=current; rec['last_seen_ts']=nowv; rec['current_pct']=pct
            rec['max_pct']=max(_quality_optional_num(rec.get('max_pct')) or pct,pct)
            rec['min_pct']=min(_quality_optional_num(rec.get('min_pct')) or pct,pct)
            rec['giveback_pct']=round((_quality_optional_num(rec.get('max_pct')) or pct)-pct,6)
            elapsed=max(0.0,nowv-(_quality_optional_num(rec.get('first_seen_ts')) or nowv)); rec['age_sec']=round(elapsed,3)
            samples=rec.get('samples') if isinstance(rec.get('samples'),dict) else {}
            for label,sec in QUALITY_SHADOW_HORIZONS:
                if elapsed >= sec and label not in samples:
                    samples[label]={'ts':nowv,'text':now_text(nowv),'price':current,'pct':pct,'max_pct':rec.get('max_pct'),'min_pct':rec.get('min_pct'),'giveback_pct':rec.get('giveback_pct')}
            rec['samples']=samples
            if elapsed >= QUALITY_SHADOW_HORIZONS[-1][1] and not rec.get('final_appended'):
                final=dict(rec); final['schema']='quality_shadow_result_v947'; final['finalized_ts']=nowv; final['finalized_text']=now_text(nowv)
                appended=_quality_append_final(final); rec['final_appended']=True; rec['finalized_ts']=nowv
                if appended: finalized += 1
        records[exact_key]=rec

    # Time-bounded retention: unfinished exact events must survive the full 60m horizon.
    # The old 1,500-row slice evicted unfinished records before 60m in a busy market.
    keep=[]; stale_unfinished_pruned=0; finalized_pruned=0; safety_pruned=0; premature_unfinished_pruned=0
    final_horizon=QUALITY_SHADOW_HORIZONS[-1][1]
    for key,rec in records.items():
        age=max(0.0,nowv-(_quality_optional_num(rec.get('first_seen_ts')) or nowv))
        if rec.get('final_appended'):
            if age <= final_horizon + QUALITY_SHADOW_FINAL_GRACE_SEC:
                keep.append((key,rec))
            else:
                finalized_pruned += 1
        elif age <= QUALITY_SHADOW_RETENTION_SEC:
            keep.append((key,rec))
        else:
            stale_unfinished_pruned += 1
    keep.sort(key=lambda kv:_quality_optional_num(kv[1].get('first_seen_ts')) or 0.0, reverse=True)
    if len(keep) > QUALITY_SHADOW_SAFETY_MAX_RECORDS:
        # Safety ceiling is intentionally far above expected 3h flow. Prefer unfinished/new rows.
        keep.sort(key=lambda kv:(bool(kv[1].get('final_appended')), -(_quality_optional_num(kv[1].get('first_seen_ts')) or 0.0)))
        dropped=keep[QUALITY_SHADOW_SAFETY_MAX_RECORDS:]
        safety_pruned=len(dropped)
        premature_unfinished_pruned=sum(1 for _key,rec in dropped if not rec.get('final_appended') and max(0.0,nowv-(_quality_optional_num(rec.get('first_seen_ts')) or nowv))<final_horizon)
        keep=keep[:QUALITY_SHADOW_SAFETY_MAX_RECORDS]
    records=dict(keep)
    rows=list(records.values()); cohorts=_quality_summary_stats(rows)
    samples=sorted(rows,key=lambda r:_quality_optional_num(r.get('max_pct')) or -999.0,reverse=True)[:4]
    samples += sorted(rows,key=lambda r:_quality_optional_num(r.get('min_pct')) or 999.0)[:4]
    compact_samples=[]; seen=set()
    for rec in samples:
        key=str(rec.get('quality_event_key_v946') or '')
        if not key or key in seen: continue
        seen.add(key)
        compact_samples.append({k:rec.get(k) for k in ('ticker','quality_event_key_v946','identity_mode_v946','entry_build_key','minimal_gate_decision_key_v925','cohort','hard_block_reasons','age_sec','current_pct','max_pct','min_pct','giveback_pct','samples')})
    rotation=_quality_rotate_ledger(nowv)
    ledger_rows=len(_quality_load_final_keys()); ledger_bytes=0; archive_files=0; archive_bytes=0
    if QUALITY_SHADOW_LEDGER.exists():
        try:
            ledger_bytes=QUALITY_SHADOW_LEDGER.stat().st_size
        except Exception as exc:
            append_error(ERROR, 'quality_shadow_ledger_stats', exc)
            ledger_bytes=0
    if QUALITY_SHADOW_ARCHIVE.exists():
        try:
            archives=[path for path in QUALITY_SHADOW_ARCHIVE.glob('quality_shadow_result_*.jsonl.gz') if path.is_file()]
            archive_files=len(archives); archive_bytes=sum(path.stat().st_size for path in archives)
        except Exception as exc:
            append_error(ERROR, 'quality_shadow_archive_stats', exc)
    status={
        'schema':'quality_shadow_status_v947','version':'review_worker_v0.948','build':'quality_exact_gate_path_retention_v947_2026-06-19',
        'state':'ACTIVE','updated_ts':nowv,'updated_text':now_text(nowv),'candidate_rows':len(source_rows),
        'exact_key_ready':exact_ready,'exact_key_missing':exact_missing,'tracked_records':len(rows),'new_records_this_cycle':created,
        'event_context_migrated_this_cycle':event_context_migrated,'event_context_migration':event_context_migration,
        'finalized_this_cycle':finalized,'final_ledger_rows':ledger_rows,'final_ledger_bytes':ledger_bytes,'rotation':rotation,'archive_files':archive_files,'archive_bytes':archive_bytes,
        'current_cohort_counts':dict(cohort_counts),'current_block_reason_counts':dict(reason_counts),'cohorts':cohorts,'samples':compact_samples,
        'horizons':[label for label,_ in QUALITY_SHADOW_HORIZONS],
        'policy':'review-owned exact candidate gate cohort -> 1/3/5/10/20/60m path with time-bounded unfinished retention; no trade criteria/trigger/open/exit change',
        'identity_policy':'minimal gate decision exact first; candidate entry_build exact second; ticker is price lookup, never final result join',
        'oldest_unfinished_age_sec':round(max([max(0.0,nowv-(_quality_optional_num(r.get('first_seen_ts')) or nowv)) for r in rows if not r.get('final_appended')] or [0.0]),3),'unfinished_records':sum(1 for r in rows if not r.get('final_appended')),'stale_unfinished_pruned':stale_unfinished_pruned,'finalized_pruned':finalized_pruned,'safety_pruned':safety_pruned,'premature_unfinished_pruned':premature_unfinished_pruned,'retention_policy':'unfinished kept by time through 60m; finalized rows move to fsync ledger; count ceiling is safety-only','conditions_changed':False,'trigger_changed':False,'paper_open_changed':False,'exit_changed':False,'auto_buy':False,
    }
    save_json(QUALITY_SHADOW_STATE,{'schema':'quality_shadow_state_v965','version':VERSION,'build':BUILD_LABEL,'updated_ts':nowv,'updated_text':now_text(nowv),'final_ledger_rows':ledger_rows,'event_context_migration':event_context_migration,'records':records})
    save_json(QUALITY_SHADOW_STATUS,status)
    return status



def _sample_price_unit(price: float) -> float:
    if price >= 100000: return 100.0
    if price >= 10000: return 10.0
    if price >= 1000: return 1.0
    if price >= 100: return 0.1
    if price >= 10: return 0.01
    if price >= 1: return 0.001
    return 0.00001


def _sample_trimmed_mean(values: List[float], trim_ratio: float=0.05) -> Optional[float]:
    vals=sorted(float(v) for v in values if isinstance(v,(int,float)))
    if not vals: return None
    cut=int(len(vals)*trim_ratio)
    core=vals[cut:len(vals)-cut] if cut>0 and len(vals)>cut*2 else vals
    return sum(core)/len(core) if core else None


def _sample_result_rows(records: List[Dict[str,Any]], horizon: str) -> List[Dict[str,Any]]:
    out=[]
    for rec in records:
        sample=(rec.get('samples') or {}).get(horizon) if isinstance(rec.get('samples'),dict) else None
        if not isinstance(sample,dict): continue
        pctv=_quality_optional_num(sample.get('pct'))
        if pctv is None: continue
        metrics=rec.get('initial_metrics') if isinstance(rec.get('initial_metrics'),dict) else {}
        event_context=rec.get('event_context') if isinstance(rec.get('event_context'),dict) else _legacy_missing_event_context()
        price=_quality_optional_num(rec.get('first_price'),metrics.get('first_price')) or 0.0
        tick_pct=_sample_price_unit(price)/price*100.0 if price>0 else 0.0
        spread=_quality_optional_num(metrics.get('spread_pct'))
        slip=_quality_optional_num(metrics.get('confirmed_slippage_pct'))
        source=str(metrics.get('confirmed_slippage_source') or '').lower()
        slip_confirmed=slip is not None and any(x in source for x in ('confirmed','exchange','average_fill','paper_reference','best_ask_reference')) and 'derived_from_spread' not in source
        cost=(spread or 0.0)+(slip if slip_confirmed else 0.0)
        out.append({'ticker':ticker_norm(rec.get('ticker')),'cohort':str(rec.get('cohort') or 'unknown'),'pct':pctv,'max_pct':_quality_optional_num(sample.get('max_pct')),'min_pct':_quality_optional_num(sample.get('min_pct')),'giveback_pct':_quality_optional_num(sample.get('giveback_pct')),'price':price,'tick_pct':tick_pct,'distortion':bool(tick_pct>=0.50 or abs(pctv)>=15.0),'spread_pct':spread,'confirmed_slippage_pct':slip if slip_confirmed else None,'cost_adjusted_pct':pctv-cost,'market_regime':event_context.get('market_regime'),'market_strength':_quality_optional_num(event_context.get('market_strength')),'volume_ratio':_quality_optional_num(event_context.get('volume_ratio')),'scanner_to_s2_sec':_quality_optional_num(metrics.get('scanner_to_s2_sec')),'scanner_to_s1_sec':_quality_optional_num(metrics.get('scanner_to_s1_sec')),'event_key':rec.get('quality_event_key_v946'),'occurrence':rec.get('hot_watch_occurrence_key_v945')})
    return out


def _sample_group_stats(rows: List[Dict[str,Any]]) -> Dict[str,Any]:
    vals=[float(r['pct']) for r in rows if isinstance(r.get('pct'),(int,float))]
    clean=[float(r['pct']) for r in rows if isinstance(r.get('pct'),(int,float)) and not r.get('distortion')]
    costs=[float(r['cost_adjusted_pct']) for r in rows if isinstance(r.get('cost_adjusted_pct'),(int,float))]
    tickers=Counter(str(r.get('ticker') or '-') for r in rows)
    unique_occ={str(r.get('occurrence')) for r in rows if str(r.get('occurrence') or '').strip()}
    unique_ticker_rows=[]
    seen=set()
    for r in sorted(rows,key=lambda x:str(x.get('event_key') or '')):
        t=str(r.get('ticker') or '')
        if t and t not in seen: seen.add(t); unique_ticker_rows.append(r)
    unique_vals=[float(r['pct']) for r in unique_ticker_rows if isinstance(r.get('pct'),(int,float))]
    top_share=(tickers.most_common(1)[0][1]/len(rows)) if rows and tickers else 0.0
    trust='판단대기'
    if len(clean)>=30 and len(tickers)>=20 and top_share<=0.20: trust='참고가능'
    if len(clean)>=100 and len(tickers)>=40 and top_share<=0.12: trust='신뢰권'
    return {'n':len(vals),'unique_tickers':len(tickers),'unique_occurrences':len(unique_occ),'raw_avg_pct':round(sum(vals)/len(vals),4) if vals else None,'median_pct':round(_quality_percentile(vals,0.5),4) if vals else None,'trimmed_avg_pct':round(_sample_trimmed_mean(vals) or 0.0,4) if vals else None,'distortion_excluded_n':len(clean),'distortion_excluded_avg_pct':round(sum(clean)/len(clean),4) if clean else None,'unique_ticker_avg_pct':round(sum(unique_vals)/len(unique_vals),4) if unique_vals else None,'cost_adjusted_avg_pct':round(sum(costs)/len(costs),4) if costs else None,'distortion_count':sum(1 for r in rows if r.get('distortion')),'top_ticker_share_pct':round(top_share*100.0,2),'top_tickers':[{'ticker':k,'n':v} for k,v in tickers.most_common(5)],'positive_0_1':sum(1 for v in vals if v>=0.1),'negative_0_1':sum(1 for v in vals if v<=-0.1),'trust':trust}


def update_sample_board(nowv: float, records: List[Dict[str,Any]]) -> Dict[str,Any]:
    cohorts=('s1_pass','frozen_trigger_not_reached','risk_reward_below_minimum','target_room_below_minimum','coherent_structure_plan_incomplete','actual_structural_invalid_missing','next_structural_target_missing','candidate_sources_not_fresh','untradable_spread','untradable_liquidity','other_blocked')
    horizon_results={}
    for horizon in ('10m','60m'):
        rows=_sample_result_rows(records,horizon)
        by={c:_sample_group_stats([r for r in rows if r.get('cohort')==c]) for c in cohorts}
        by={k:v for k,v in by.items() if v.get('n')}
        narrow=_sample_group_stats([r for r in rows if (_quality_optional_num(r.get('spread_pct')) or 999)<0.20])
        wide=_sample_group_stats([r for r in rows if (_quality_optional_num(r.get('spread_pct')) or 0)>=0.20])
        high_vol=_sample_group_stats([r for r in rows if (_quality_optional_num(r.get('volume_ratio')) or 0)>=1.2])
        normal_vol=_sample_group_stats([r for r in rows if (_quality_optional_num(r.get('volume_ratio')) or 0)<1.2])
        fast_s2=_sample_group_stats([r for r in rows if (_quality_optional_num(r.get('scanner_to_s2_sec')) is not None and (_quality_optional_num(r.get('scanner_to_s2_sec')) or 0)<=30)])
        slow_s2=_sample_group_stats([r for r in rows if (_quality_optional_num(r.get('scanner_to_s2_sec')) or 0)>120])
        horizon_results[horizon]={'total':_sample_group_stats(rows),'cohorts':by,'market_splits':{'spread_narrow':narrow,'spread_wide':wide,'volume_high':high_vol,'volume_normal':normal_vol,'s2_fast_30s':fast_s2,'s2_slow_120s':slow_s2}}
    status={'schema':'sample_board_status_v948','version':VERSION,'build':BUILD_LABEL,'state':'ACTIVE','updated_ts':nowv,'updated_text':now_text(nowv),'tracked_records':len(records),'horizons':horizon_results,'rules':{'distortion':'tick_pct>=0.50% or abs(return)>=15%','dedup':'raw exact + unique ticker + unique occurrence shown together','cost':'spread + confirmed/reference slippage only; legacy spread-copy excluded','trust':'sample count + unique tickers + concentration'} ,'policy':'observation only; no gate/trigger/open/exit change','trading_rules_changed':False}
    save_json(SAMPLE_BOARD_STATUS,status); return status


def _structure_variant_stats(records: List[Dict[str,Any]], variant: str) -> Dict[str,Any]:
    reached=[]
    for rec in records:
        v=(rec.get('variants') or {}).get(variant) if isinstance(rec.get('variants'),dict) else None
        if isinstance(v,dict) and v.get('reached_ts'): reached.append(v)
    out={'tracked':len(records),'reached':len(reached),'reach_rate_pct':round(len(reached)/len(records)*100.0,2) if records else 0.0}
    for label,_ in SMART_STRUCTURE_HORIZONS:
        vals=[]; peaks=[]; troughs=[]; give=[]
        for v in reached:
            sm=(v.get('samples') or {}).get(label) if isinstance(v.get('samples'),dict) else None
            if not isinstance(sm,dict): continue
            x=_quality_optional_num(sm.get('pct')); p=_quality_optional_num(sm.get('max_pct')); t=_quality_optional_num(sm.get('min_pct')); g=_quality_optional_num(sm.get('giveback_pct'))
            if x is not None: vals.append(x)
            if p is not None: peaks.append(p)
            if t is not None: troughs.append(t)
            if g is not None: give.append(g)
        out[label]=_quality_metric_stats(vals,peaks,troughs,give)
    out['invalid_breach_count']=sum(1 for v in reached if v.get('invalid_breached'))
    out['target_hit_count']=sum(1 for v in reached if v.get('target_hit'))
    return out


def update_smart_structure_shadow(nowv: float, fmap: Dict[str,Dict[str,Any]], ofmap: Dict[str,Dict[str,Any]]) -> Dict[str,Any]:
    source=load_json(SMART_STRUCTURE_CANDIDATES,{}) or {}
    rows=source.get('rows') if isinstance(source,dict) and isinstance(source.get('rows'),list) else []
    state=load_json(SMART_STRUCTURE_STATE,{}) or {}; records=state.get('records') if isinstance(state,dict) and isinstance(state.get('records'),dict) else {}
    records={str(k):dict(v) for k,v in records.items() if isinstance(v,dict)}; new=0
    for row in rows:
        if not isinstance(row,dict): continue
        key=str(row.get('shadow_key') or '').strip(); ticker=ticker_norm(row.get('ticker'))
        if not key or not ticker: continue
        rec=records.get(key)
        ex=row.get('existing') if isinstance(row.get('existing'),dict) else {}; sm=row.get('smart') if isinstance(row.get('smart'),dict) else {}
        if rec is None:
            rec={'schema':'smart_structure_shadow_state_row_v948','key':key,'ticker':ticker,'first_seen_ts':nowv,'first_seen_text':now_text(nowv),'low_price_tick_risk':bool(row.get('low_price_tick_risk')),'dynamic_zone_tolerance_pct':row.get('dynamic_zone_tolerance_pct'),'variants':{},'observation_only':True}; new+=1
        for name,plan in (('existing',ex),('smart',sm)):
            variant=(rec.get('variants') or {}).get(name) if isinstance(rec.get('variants'),dict) else None
            if not isinstance(variant,dict): variant={'trigger':plan.get('trigger'),'invalid':plan.get('invalid'),'target':plan.get('target'),'samples':{},'max_pct':0.0,'min_pct':0.0,'giveback_pct':0.0}
            variants=rec.get('variants') if isinstance(rec.get('variants'),dict) else {}; variants[name]=variant; rec['variants']=variants
        rec['last_seen_ts']=nowv; records[key]=rec
    for key,rec in list(records.items()):
        ticker=ticker_norm(rec.get('ticker')); price_state=_structure_review_price_state(ticker,fmap,ofmap,nowv)
        rec['review_price_state']=price_state; rec['review_price_checked_ts']=nowv
        if not price_state.get('fresh'):
            rec['line_state']='stale_price_wait'; rec['review_price_stale_skip_count']=int(rec.get('review_price_stale_skip_count') or 0)+1; review_price_stale_skips+=1; records[key]=rec; continue
        cur=float(price_state.get('price') or 0.0); review_price_fresh_samples+=1
        if cur<=0: continue
        for name,v in list((rec.get('variants') or {}).items()):
            if not isinstance(v,dict): continue
            trigger=_quality_optional_num(v.get('trigger')) or 0.0
            if not v.get('reached_ts') and trigger>0 and cur>=trigger*0.999:
                v['reached_ts']=nowv; v['reached_text']=now_text(nowv); v['entry_price']=cur; v['max_pct']=0.0; v['min_pct']=0.0; v['giveback_pct']=0.0
            if v.get('reached_ts') and (_quality_optional_num(v.get('entry_price')) or 0)>0:
                base=float(v['entry_price']); pctv=(cur-base)/base*100.0; v['current_pct']=round(pctv,6); v['max_pct']=max(_quality_optional_num(v.get('max_pct')) or pctv,pctv); v['min_pct']=min(_quality_optional_num(v.get('min_pct')) or pctv,pctv); v['giveback_pct']=round(float(v['max_pct'])-pctv,6)
                invalid=_quality_optional_num(v.get('invalid')); target=_quality_optional_num(v.get('target'))
                if invalid and cur<=invalid*1.001: v['invalid_breached']=True
                if target and cur>=target*0.999: v['target_hit']=True
                elapsed=max(0.0,nowv-float(v['reached_ts'])); samples=v.get('samples') if isinstance(v.get('samples'),dict) else {}
                for label,sec in SMART_STRUCTURE_HORIZONS:
                    if elapsed>=sec and label not in samples: samples[label]={'ts':nowv,'pct':v['current_pct'],'max_pct':v['max_pct'],'min_pct':v['min_pct'],'giveback_pct':v['giveback_pct']}
                v['samples']=samples
            rec['variants'][name]=v
        records[key]=rec
    records={k:v for k,v in records.items() if nowv-(_quality_optional_num(v.get('first_seen_ts')) or nowv)<=3*3600}
    vals=list(records.values()); exstats=_structure_variant_stats(vals,'existing'); smstats=_structure_variant_stats(vals,'smart')
    def delta(label,key='avg_pct'):
        a=((smstats.get(label) or {}).get(key)); b=((exstats.get(label) or {}).get(key)); return round(float(a)-float(b),4) if isinstance(a,(int,float)) and isinstance(b,(int,float)) else None
    status={'schema':'smart_structure_shadow_review_status_v948','version':VERSION,'build':BUILD_LABEL,'state':'ACTIVE' if rows else 'WAITING','updated_ts':nowv,'updated_text':now_text(nowv),'source_rows':len(rows),'tracked_records':len(vals),'new_records_this_cycle':new,'existing':exstats,'smart':smstats,'smart_minus_existing':{'10m_avg_pct':delta('10m'),'60m_avg_pct':delta('60m'),'10m_avg_min_pct':delta('10m','avg_min_pct'),'10m_avg_giveback_pct':delta('10m','avg_giveback_pct')},'low_price_tick_risk_records':sum(1 for r in vals if r.get('low_price_tick_risk')),'policy':'smart zones are review-only; existing v925 lines remain the only trading lines','trading_rules_changed':False}
    save_json(SMART_STRUCTURE_STATE,{'schema':'smart_structure_shadow_state_v948','version':VERSION,'updated_ts':nowv,'records':records}); save_json(SMART_STRUCTURE_STATUS,status); return status



# =============================================================================
# review_worker v0.950: structure discovery, method event, and plan outcome review
# =============================================================================

def _structure_plan_stats(records: List[Dict[str,Any]], method: str) -> Dict[str,Any]:
    rows=[r for r in records if str(r.get('method') or '')==method]
    reached=[r for r in rows if r.get('trigger_reached_ts')]
    state_counts=Counter(str(r.get('structure_state') or 'unknown') for r in rows)
    activation_counts=Counter(str(r.get('trigger_activation_mode') or 'unknown') for r in rows)
    out={'tracked':len(rows),'complete_tracked':sum(1 for r in rows if r.get('source_plan_complete')),'partial_tracked':sum(1 for r in rows if not r.get('source_plan_complete')),'trigger_reached':len(reached),'support_touched':sum(1 for r in rows if r.get('support_touch_count',0)>0),'target_first':sum(1 for r in reached if r.get('first_terminal')=='target'),'invalid_first':sum(1 for r in reached if r.get('first_terminal')=='invalid'),'terminal_unknown':sum(1 for r in reached if r.get('first_terminal') in (None,'','ambiguous')),'weakened_lines':sum(1 for r in rows if r.get('line_weakened')),'role_flip_confirmed':sum(1 for r in rows if r.get('role_flip_confirmed_ts')),'stale_unreached':sum(1 for r in rows if r.get('line_state')=='stale_unreached'),'confirmed_event_started':sum(1 for r in rows if r.get('activation_source')=='confirmed_completed_candle_event_seen_by_review'),'structure_state_counts':dict(state_counts),'activation_mode_counts':dict(activation_counts)}
    for label,_sec in STRUCTURE_LAB_HORIZONS:
        vals=[]; peaks=[]; mins=[]; give=[]; rel=[]
        for r in reached:
            sample_map=r.get('samples'); sm=sample_map.get(label) if isinstance(sample_map,dict) else None
            if not isinstance(sm,dict): continue
            for arr,key in ((vals,'pct'),(peaks,'max_pct'),(mins,'min_pct'),(give,'giveback_pct'),(rel,'relative_to_btc_pct')):
                v=_quality_optional_num(sm.get(key))
                if v is not None: arr.append(v)
        out[label]={'n':len(vals),'avg_pct':round(sum(vals)/len(vals),4) if vals else None,'median_pct':round(_quality_percentile(vals,0.5),4) if vals else None,'avg_max_pct':round(sum(peaks)/len(peaks),4) if peaks else None,'avg_min_pct':round(sum(mins)/len(mins),4) if mins else None,'avg_giveback_pct':round(sum(give)/len(give),4) if give else None,'avg_relative_to_btc_pct':round(sum(rel)/len(rel),4) if rel else None}
    return out


def _structure_missed_stats(records: List[Dict[str,Any]]) -> Dict[str,Any]:
    rows=list(records); reasons=Counter(str(r.get('reason') or 'unknown') for r in rows); sources=Counter(str(r.get('source') or 'unknown') for r in rows)
    discovery=Counter(); incomplete=Counter(); method_states={m:Counter() for m in ('A_SWING','B_REACTION_ZONE','C_BREAK_RETEST','D_SUPPLY_DEMAND','E_VOLUME_PROFILE')}
    for r in rows:
        diagnostics=r.get('method_diagnostics') if isinstance(r.get('method_diagnostics'),dict) else {}
        for method,diag in diagnostics.items():
            if method not in method_states or not isinstance(diag,dict): continue
            method_states[method][str(diag.get('structure_state') or 'unknown')]+=1
            discovery_reasons=diag.get('discovery_reasons') if isinstance(diag.get('discovery_reasons'),list) else []
            incomplete_reasons=diag.get('incomplete_reasons') if isinstance(diag.get('incomplete_reasons'),list) else []
            for reason in discovery_reasons: discovery[f'{method}:{reason}']+=1
            for reason in incomplete_reasons: incomplete[f'{method}:{reason}']+=1
    out={'tracked':len(rows),'reason_top':[{'reason':k,'count':v} for k,v in reasons.most_common(15)],'source_counts':dict(sources),'method_discovery_reason_top':[{'reason':k,'count':v} for k,v in discovery.most_common(20)],'method_incomplete_reason_top':[{'reason':k,'count':v} for k,v in incomplete.most_common(20)],'method_state_counts':{m:dict(v) for m,v in method_states.items()},'later_structure_created':sum(1 for r in rows if r.get('later_structure_created_ts')),'later_complete_plan_created':sum(1 for r in rows if r.get('later_complete_plan_created_ts'))}
    for label,_sec in STRUCTURE_LAB_HORIZONS:
        vals=[]; peaks=[]; mins=[]
        for r in rows:
            sample_map=r.get('samples'); sm=sample_map.get(label) if isinstance(sample_map,dict) else None
            if not isinstance(sm,dict): continue
            v=_quality_optional_num(sm.get('pct')); p=_quality_optional_num(sm.get('max_pct')); m=_quality_optional_num(sm.get('min_pct'))
            if v is not None: vals.append(v)
            if p is not None: peaks.append(p)
            if m is not None: mins.append(m)
        out[label]={'n':len(vals),'avg_pct':round(sum(vals)/len(vals),4) if vals else None,'median_pct':round(_quality_percentile(vals,0.5),4) if vals else None,'avg_max_pct':round(sum(peaks)/len(peaks),4) if peaks else None,'avg_min_pct':round(sum(mins)/len(mins),4) if mins else None,'rise_0_5_count':sum(1 for v in peaks if v>=0.5),'rise_1_0_count':sum(1 for v in peaks if v>=1.0)}
    return out


def _structure_zone_bounds(zone: Any) -> tuple[Optional[float],Optional[float]]:
    if isinstance(zone,(list,tuple)) and len(zone)>=2:
        low=_quality_optional_num(zone[0]); high=_quality_optional_num(zone[1])
    else:
        z=zone if isinstance(zone,dict) else {}
        low=_quality_optional_num(z.get('low_raw'),z.get('low')); high=_quality_optional_num(z.get('high_raw'),z.get('high'))
    if low is None or high is None: return None,None
    return min(low,high),max(low,high)


_STRUCTURE_DETAIL_KEYS_CACHE: Optional[set[str]] = None


def _append_structure_detail_once(rec: Dict[str,Any]) -> bool:
    global _STRUCTURE_DETAIL_KEYS_CACHE
    key=str(rec.get('event_key') or rec.get('plan_key') or '').strip()
    if not key: return False
    if _STRUCTURE_DETAIL_KEYS_CACHE is None:
        keys:set[str]=set()
        for detail_path in (STRUCTURE_LAB_EVENT_DETAIL_LEDGER_LEGACY,STRUCTURE_LAB_EVENT_DETAIL_LEDGER):
            if not detail_path.exists(): continue
            try:
                for line in detail_path.read_text(encoding='utf-8',errors='ignore').splitlines():
                    try:
                        obj=json.loads(line)
                        k=str(obj.get('event_key') or obj.get('plan_key') or '').strip() if isinstance(obj,dict) else ''
                        if k: keys.add(k)
                    except Exception: continue
            except Exception: pass
        _STRUCTURE_DETAIL_KEYS_CACHE=keys
    if key in _STRUCTURE_DETAIL_KEYS_CACHE: return False
    STRUCTURE_LAB_EVENT_DETAIL_LEDGER.parent.mkdir(parents=True,exist_ok=True)
    with STRUCTURE_LAB_EVENT_DETAIL_LEDGER.open('a',encoding='utf-8') as f:
        f.write(json.dumps(rec,ensure_ascii=False,separators=(',',':'),default=str)+'\n'); f.flush(); os.fsync(f.fileno())
    _STRUCTURE_DETAIL_KEYS_CACHE.add(key)
    return True


_STRUCTURE_HORIZON_KEYS_CACHE: Optional[set[str]] = None
_STRUCTURE_FINAL_KEYS_CACHE: Optional[set[str]] = None
_STRUCTURE_HORIZON_SUMMARY_CACHE: Optional[Dict[str,Any]] = None
_STRUCTURE_HORIZON_SUMMARY_LEDGER_SIZE = -1
_STRUCTURE_HORIZON_SUMMARY_MEMORY_HITS = 0
_STRUCTURE_HORIZON_SUMMARY_DISK_HITS = 0
_STRUCTURE_HORIZON_SUMMARY_FULL_SCANS = 0
_STRUCTURE_HORIZON_KEY_INDEX_LOADS = 0
_STRUCTURE_FINAL_KEY_INDEX_LOADS = 0
_STRUCTURE_HORIZON_BITS = {label:(1 << idx) for idx,(label,_sec) in enumerate(STRUCTURE_LAB_HORIZONS)}
_STRUCTURE_ALL_HORIZONS_MASK = sum(_STRUCTURE_HORIZON_BITS.values())


def _structure_zone_pair(zone: Any) -> Optional[List[float]]:
    low,high=_structure_zone_bounds(zone)
    if low is None or high is None: return None
    return [float(low),float(high)]


def _structure_active_record(rec: Dict[str,Any]) -> Dict[str,Any]:
    support=_structure_zone_pair(rec.get('support_zone'))
    trigger_zone=_structure_zone_pair(rec.get('trigger_zone'))
    out={
        'schema':'structure_lab_active_row_v956',
        'event_key':str(rec.get('event_key') or rec.get('plan_key') or ''),
        'method':str(rec.get('method') or ''),
        'ticker':ticker_norm(rec.get('ticker')),
        'candidate_exact_identity':rec.get('candidate_exact_identity') or rec.get('candidate_exact_identity_last'),
        'candidate_exact_identity_last':rec.get('candidate_exact_identity_last') or rec.get('candidate_exact_identity'),
        'first_seen_ts':_quality_optional_num(rec.get('first_seen_ts')),
        'first_price':_quality_optional_num(rec.get('first_price')),
        'structure_state':rec.get('structure_state'),
        'source_plan_complete':bool(rec.get('source_plan_complete')),
        'trigger_activation_mode':rec.get('trigger_activation_mode'),
        'trigger':_quality_optional_num(rec.get('trigger')),
        'invalid':_quality_optional_num(rec.get('invalid')),
        'target':_quality_optional_num(rec.get('target')),
        'support_zone':support,
        'trigger_zone':trigger_zone,
        'primary_tf':rec.get('primary_tf'),
        'source_event_ts':_quality_optional_num(rec.get('source_event_ts')),
        'source_event_price':_quality_optional_num(rec.get('source_event_price')),
        'source_to_review_lag_sec':_quality_optional_num(rec.get('source_to_review_lag_sec')),
        'line_state':rec.get('line_state'),
        'support_touch_count':int(rec.get('support_touch_count') or 0),
        'trigger_retest_count':int(rec.get('trigger_retest_count') or 0),
        'max_pct':_quality_optional_num(rec.get('max_pct')) or 0.0,
        'min_pct':_quality_optional_num(rec.get('min_pct')) or 0.0,
        'giveback_pct':_quality_optional_num(rec.get('giveback_pct')) or 0.0,
        'btc_start_price':_quality_optional_num(rec.get('btc_start_price')),
        'trigger_reached_ts':_quality_optional_num(rec.get('trigger_reached_ts')),
        'entry_price':_quality_optional_num(rec.get('entry_price')),
        'activation_source':rec.get('activation_source'),
        'source_current_state_fresh':bool(rec.get('source_current_state_fresh')),
        'source_map_refresh_pending':bool(rec.get('source_map_refresh_pending')),
        'source_priority_lane':rec.get('source_priority_lane'),
        'last_source_seen_ts':_quality_optional_num(rec.get('last_source_seen_ts')),
        'review_price_source':rec.get('review_price_source'),
        'review_price_age_sec':_quality_optional_num(rec.get('review_price_age_sec')),
        'review_price_stale_skip_count':int(rec.get('review_price_stale_skip_count') or 0),
        'line_age_sec':_quality_optional_num(rec.get('line_age_sec')),
        'last_support_touch_ts':_quality_optional_num(rec.get('last_support_touch_ts')),
        'line_weakened':bool(rec.get('line_weakened')),
        'weakening_reason':rec.get('weakening_reason'),
        'last_trigger_retest_ts':_quality_optional_num(rec.get('last_trigger_retest_ts')),
        'role_flip_confirmed_ts':_quality_optional_num(rec.get('role_flip_confirmed_ts')),
        'current_price':_quality_optional_num(rec.get('current_price')),
        'current_pct':_quality_optional_num(rec.get('current_pct')),
        'invalid_ts':_quality_optional_num(rec.get('invalid_ts')),
        'target_ts':_quality_optional_num(rec.get('target_ts')),
        'first_terminal':rec.get('first_terminal'),
        'next_review_due_ts':_quality_optional_num(rec.get('next_review_due_ts')),
        'last_review_update_ts':_quality_optional_num(rec.get('last_review_update_ts')),
        'last_review_interval_sec':_quality_optional_num(rec.get('last_review_interval_sec')),
        'review_update_count':int(rec.get('review_update_count') or 0),
        'horizon_mask':int(rec.get('horizon_mask') or 0),
    }
    return {k:v for k,v in out.items() if v is not None and v!=''}


def _load_jsonl_key_set(paths: List[Path], key_builder) -> set[str]:
    keys:set[str]=set()
    for path in paths:
        if not path.exists(): continue
        try:
            with path.open('r',encoding='utf-8',errors='ignore') as handle:
                for line in handle:
                    try:
                        row=json.loads(line)
                    except Exception:
                        continue
                    if not isinstance(row,dict): continue
                    key=key_builder(row)
                    if key: keys.add(key)
        except Exception:
            continue
    return keys


def _structure_horizon_key(row: Dict[str,Any]) -> str:
    event_key=str(row.get('event_key') or '').strip(); label=str(row.get('horizon') or '').strip()
    return f'{event_key}|{label}' if event_key and label else ''


def _structure_summary_empty() -> Dict[str,Any]:
    return {'schema':'structure_lab_horizon_summary_v956','version':VERSION,'updated_ts':0.0,'ledger_size_bytes':0,'total_rows':0,'methods':{}}


def _structure_summary_add(summary: Dict[str,Any], row: Dict[str,Any]) -> None:
    method=str(row.get('method') or 'unknown'); label=str(row.get('horizon') or '')
    if not label: return
    methods=summary.setdefault('methods',{}); m=methods.setdefault(method,{}); bucket=m.setdefault(label,{'n':0,'sum_pct':0.0,'sum_max_pct':0.0,'sum_min_pct':0.0,'sum_giveback_pct':0.0,'sum_relative_to_btc_pct':0.0,'relative_n':0})
    bucket['n']=int(bucket.get('n') or 0)+1
    for source_key,sum_key in (('pct','sum_pct'),('max_pct','sum_max_pct'),('min_pct','sum_min_pct'),('giveback_pct','sum_giveback_pct')):
        val=_quality_optional_num(row.get(source_key))
        if val is not None: bucket[sum_key]=float(bucket.get(sum_key) or 0.0)+float(val)
    rel=_quality_optional_num(row.get('relative_to_btc_pct'))
    if rel is not None:
        bucket['sum_relative_to_btc_pct']=float(bucket.get('sum_relative_to_btc_pct') or 0.0)+float(rel)
        bucket['relative_n']=int(bucket.get('relative_n') or 0)+1
    summary['total_rows']=int(summary.get('total_rows') or 0)+1


def _load_structure_horizon_summary() -> tuple[Dict[str,Any],Dict[str,Any]]:
    global _STRUCTURE_HORIZON_SUMMARY_CACHE, _STRUCTURE_HORIZON_SUMMARY_LEDGER_SIZE
    global _STRUCTURE_HORIZON_SUMMARY_MEMORY_HITS, _STRUCTURE_HORIZON_SUMMARY_DISK_HITS, _STRUCTURE_HORIZON_SUMMARY_FULL_SCANS
    global _STRUCTURE_HORIZON_KEYS_CACHE, _STRUCTURE_HORIZON_KEY_INDEX_LOADS
    ledger_size=STRUCTURE_LAB_HORIZON_LEDGER.stat().st_size if STRUCTURE_LAB_HORIZON_LEDGER.exists() else 0
    if isinstance(_STRUCTURE_HORIZON_SUMMARY_CACHE,dict) and _STRUCTURE_HORIZON_SUMMARY_LEDGER_SIZE==ledger_size:
        _STRUCTURE_HORIZON_SUMMARY_MEMORY_HITS+=1
        return _STRUCTURE_HORIZON_SUMMARY_CACHE,{'memory_reused':True,'disk_summary_reused':False,'rebuilt_from_ledger':False,'ledger_size_bytes':ledger_size}
    obj=load_json(STRUCTURE_LAB_HORIZON_SUMMARY,{})
    if isinstance(obj,dict) and isinstance(obj.get('methods'),dict) and int(obj.get('ledger_size_bytes') or 0)==ledger_size:
        _STRUCTURE_HORIZON_SUMMARY_CACHE=obj
        _STRUCTURE_HORIZON_SUMMARY_LEDGER_SIZE=ledger_size
        _STRUCTURE_HORIZON_SUMMARY_DISK_HITS+=1
        return obj,{'memory_reused':False,'disk_summary_reused':True,'rebuilt_from_ledger':False,'ledger_size_bytes':ledger_size}
    summary=_structure_summary_empty(); rebuilt_keys:set[str]=set()
    if STRUCTURE_LAB_HORIZON_LEDGER.exists():
        try:
            with STRUCTURE_LAB_HORIZON_LEDGER.open('r',encoding='utf-8',errors='ignore') as handle:
                for line in handle:
                    try: row=json.loads(line)
                    except Exception: continue
                    if isinstance(row,dict):
                        _structure_summary_add(summary,row)
                        key=_structure_horizon_key(row)
                        if key: rebuilt_keys.add(key)
        except Exception: pass
    summary['ledger_size_bytes']=ledger_size
    _STRUCTURE_HORIZON_KEYS_CACHE=rebuilt_keys
    _STRUCTURE_HORIZON_KEY_INDEX_LOADS+=1
    _STRUCTURE_HORIZON_SUMMARY_CACHE=summary
    _STRUCTURE_HORIZON_SUMMARY_LEDGER_SIZE=ledger_size
    _STRUCTURE_HORIZON_SUMMARY_FULL_SCANS+=1
    return summary,{'memory_reused':False,'disk_summary_reused':False,'rebuilt_from_ledger':True,'ledger_size_bytes':ledger_size}


def _append_jsonl_batch_fsync(path: Path, rows: List[Dict[str,Any]]) -> int:
    if not rows: return 0
    path.parent.mkdir(parents=True,exist_ok=True)
    original_size=path.stat().st_size if path.exists() else 0
    payload=''.join(json.dumps(row,ensure_ascii=False,separators=(',',':'),default=str)+'\n' for row in rows)
    try:
        with path.open('a',encoding='utf-8') as handle:
            handle.write(payload)
            handle.flush()
            os.fsync(handle.fileno())
    except Exception:
        try:
            with path.open('r+b') as rollback:
                rollback.truncate(original_size)
                rollback.flush()
                os.fsync(rollback.fileno())
        except Exception:
            pass
        raise
    return len(rows)

def _append_structure_horizon_once(rec: Dict[str,Any], label: str, sample: Dict[str,Any], summary: Dict[str,Any], *, migrated: bool=False, batch_rows: Optional[List[Dict[str,Any]]]=None) -> bool:
    global _STRUCTURE_HORIZON_KEYS_CACHE
    event_key=str(rec.get('event_key') or '').strip()
    if not event_key or label not in _STRUCTURE_HORIZON_BITS: return False
    if _STRUCTURE_HORIZON_KEYS_CACHE is None:
        global _STRUCTURE_HORIZON_KEY_INDEX_LOADS
        _STRUCTURE_HORIZON_KEYS_CACHE=_load_jsonl_key_set([STRUCTURE_LAB_HORIZON_LEDGER],_structure_horizon_key)
        _STRUCTURE_HORIZON_KEY_INDEX_LOADS+=1
    key=f'{event_key}|{label}'
    if key in _STRUCTURE_HORIZON_KEYS_CACHE:
        rec['horizon_mask']=int(rec.get('horizon_mask') or 0)|_STRUCTURE_HORIZON_BITS[label]
        return False
    row={
        'schema':'structure_lab_horizon_result_v956','version':VERSION,'result_key':key,
        'event_key':event_key,'method':rec.get('method'),'ticker':rec.get('ticker'),'horizon':label,
        'candidate_exact_identity':rec.get('candidate_exact_identity') or rec.get('candidate_exact_identity_last'),
        'event_ts':rec.get('trigger_reached_ts') or rec.get('first_seen_ts'),'entry_price':rec.get('entry_price') or rec.get('first_price'),
        'sample_ts':_quality_optional_num(sample.get('ts')) or now_ts(),'pct':_quality_optional_num(sample.get('pct')),
        'max_pct':_quality_optional_num(sample.get('max_pct')),'min_pct':_quality_optional_num(sample.get('min_pct')),
        'giveback_pct':_quality_optional_num(sample.get('giveback_pct')),'btc_pct':_quality_optional_num(sample.get('btc_pct')),
        'relative_to_btc_pct':_quality_optional_num(sample.get('relative_to_btc_pct')),'sample_lag_sec':_quality_optional_num(sample.get('sample_lag_sec')),
        'first_terminal':rec.get('first_terminal'),'invalid_ts':rec.get('invalid_ts'),'target_ts':rec.get('target_ts'),
        'migrated_from_v955':bool(migrated),'observation_only':True,
    }
    if batch_rows is not None:
        batch_rows.append(row)
    else:
        STRUCTURE_LAB_HORIZON_LEDGER.parent.mkdir(parents=True,exist_ok=True)
        with STRUCTURE_LAB_HORIZON_LEDGER.open('a',encoding='utf-8') as handle:
            handle.write(json.dumps(row,ensure_ascii=False,separators=(',',':'),default=str)+'\n'); handle.flush(); os.fsync(handle.fileno())
    _STRUCTURE_HORIZON_KEYS_CACHE.add(key); _structure_summary_add(summary,row)
    rec['horizon_mask']=int(rec.get('horizon_mask') or 0)|_STRUCTURE_HORIZON_BITS[label]
    return True


def _structure_final_key(row: Dict[str,Any]) -> str:
    return str(row.get('event_key') or '').strip()


def _append_structure_final_once(rec: Dict[str,Any], nowv: float, *, migrated: bool=False, batch_rows: Optional[List[Dict[str,Any]]]=None) -> bool:
    global _STRUCTURE_FINAL_KEYS_CACHE
    key=str(rec.get('event_key') or '').strip()
    if not key: return False
    if _STRUCTURE_FINAL_KEYS_CACHE is None:
        global _STRUCTURE_FINAL_KEY_INDEX_LOADS
        _STRUCTURE_FINAL_KEYS_CACHE=_load_jsonl_key_set([STRUCTURE_LAB_FINAL_LEDGER],_structure_final_key)
        _STRUCTURE_FINAL_KEY_INDEX_LOADS+=1
    if key in _STRUCTURE_FINAL_KEYS_CACHE: return False
    row={'schema':'structure_lab_event_final_v956','version':VERSION,'event_key':key,'method':rec.get('method'),'ticker':rec.get('ticker'),'event_ts':rec.get('trigger_reached_ts') or rec.get('first_seen_ts'),'entry_price':rec.get('entry_price') or rec.get('first_price'),'completed_ts':nowv,'max_pct':rec.get('max_pct'),'min_pct':rec.get('min_pct'),'giveback_pct':rec.get('giveback_pct'),'current_pct':rec.get('current_pct'),'first_terminal':rec.get('first_terminal'),'invalid_ts':rec.get('invalid_ts'),'target_ts':rec.get('target_ts'),'horizon_mask':int(rec.get('horizon_mask') or 0),'migrated_from_v955':bool(migrated),'observation_only':True}
    if batch_rows is not None:
        batch_rows.append(row)
    else:
        STRUCTURE_LAB_FINAL_LEDGER.parent.mkdir(parents=True,exist_ok=True)
        with STRUCTURE_LAB_FINAL_LEDGER.open('a',encoding='utf-8') as handle:
            handle.write(json.dumps(row,ensure_ascii=False,separators=(',',':'),default=str)+'\n'); handle.flush(); os.fsync(handle.fileno())
    _STRUCTURE_FINAL_KEYS_CACHE.add(key)
    return True


def _migrate_structure_record(rec: Dict[str,Any], nowv: float, summary: Dict[str,Any], horizon_batch: List[Dict[str,Any]], final_batch: List[Dict[str,Any]]) -> tuple[Optional[Dict[str,Any]],int,bool]:
    active=_structure_active_record(rec); migrated_samples=0
    samples=rec.get('samples') if isinstance(rec.get('samples'),dict) else {}
    for label,sample in samples.items():
        if label in _STRUCTURE_HORIZON_BITS and isinstance(sample,dict):
            if _append_structure_horizon_once(active,label,sample,summary,migrated=True,batch_rows=horizon_batch): migrated_samples+=1
    if int(active.get('horizon_mask') or 0)==_STRUCTURE_ALL_HORIZONS_MASK:
        _append_structure_final_once(active,nowv,migrated=True,batch_rows=final_batch)
        return None,migrated_samples,True
    if _quality_optional_num(active.get('next_review_due_ts')) is None:
        interval=_structure_review_interval(active,nowv); active['next_review_due_ts']=nowv+(abs(hash(str(active.get('event_key'))))%max(1,int(interval)))
    return active,migrated_samples,False


def _load_structure_state_v956(nowv: float, summary: Dict[str,Any]) -> tuple[Dict[str,Dict[str,Any]],Dict[str,int]]:
    if STRUCTURE_LAB_ACTIVE_STATE.exists():
        obj=load_json(STRUCTURE_LAB_ACTIVE_STATE,{}) or {}; raw=obj.get('records') if isinstance(obj,dict) else {}
        records={str(k):_structure_active_record(v) for k,v in raw.items() if isinstance(v,dict)} if isinstance(raw,dict) else {}
        return records,{'migrated_records':0,'migrated_samples':0,'finalized_on_migration':0}
    source_path=None
    for path in (STRUCTURE_LAB_STATE_V955,STRUCTURE_LAB_STATE_V952):
        if path.exists(): source_path=path; break
    raw={}
    if source_path is not None:
        obj=load_json(source_path,{}) or {}; raw=obj.get('records') if isinstance(obj,dict) else {}
    out:Dict[str,Dict[str,Any]]={}; migrated_records=0; migrated_samples=0; finalized=0; horizon_batch:List[Dict[str,Any]]=[]; final_batch:List[Dict[str,Any]]=[]
    if isinstance(raw,dict):
        for key,val in raw.items():
            if not isinstance(val,dict): continue
            active,sample_count,was_final=_migrate_structure_record(dict(val),nowv,summary,horizon_batch,final_batch)
            migrated_records+=1; migrated_samples+=sample_count; finalized+=int(was_final)
            if active is not None: out[str(active.get('event_key') or key)]=active
    _append_jsonl_batch_fsync(STRUCTURE_LAB_HORIZON_LEDGER,horizon_batch)
    _append_jsonl_batch_fsync(STRUCTURE_LAB_FINAL_LEDGER,final_batch)
    return out,{'migrated_records':migrated_records,'migrated_samples':migrated_samples,'finalized_on_migration':finalized,'migration_horizon_batch_rows':len(horizon_batch),'migration_final_batch_rows':len(final_batch)}


def _load_structure_missed_state_v956() -> tuple[Dict[str,Dict[str,Any]],int]:
    if STRUCTURE_MISSED_STATE.exists():
        obj=load_json(STRUCTURE_MISSED_STATE,{}) or {}; raw=obj.get('records') if isinstance(obj,dict) else {}
        return ({str(k):dict(v) for k,v in raw.items() if isinstance(v,dict)} if isinstance(raw,dict) else {}),0
    for path in (STRUCTURE_MISSED_STATE_V955,STRUCTURE_MISSED_STATE_V952):
        if not path.exists(): continue
        obj=load_json(path,{}) or {}; raw=obj.get('records') if isinstance(obj,dict) else {}
        out={str(k):dict(v) for k,v in raw.items() if isinstance(v,dict)} if isinstance(raw,dict) else {}
        return out,len(out)
    return {},0


def _structure_review_interval(rec: Dict[str,Any], nowv: float) -> float:
    if int(rec.get('horizon_mask') or 0)==_STRUCTURE_ALL_HORIZONS_MASK: return 300.0
    age=max(0.0,nowv-(_quality_optional_num(rec.get('trigger_reached_ts'),rec.get('first_seen_ts')) or nowv))
    if age<=600.0: return STRUCTURE_REVIEW_FAST_SEC
    if age<=3600.0: return STRUCTURE_REVIEW_MID_SEC
    return STRUCTURE_REVIEW_SLOW_SEC


def _structure_due_selection(records: Dict[str,Dict[str,Any]], nowv: float) -> tuple[List[str],Dict[str,Any]]:
    due=[]; future=0; recent_due=[]; overdue=0; oldest_overdue=0.0
    for key,rec in records.items():
        due_ts=_quality_optional_num(rec.get('next_review_due_ts'))
        if due_ts is None:
            interval=_structure_review_interval(rec,nowv); due_ts=nowv+(abs(hash(key))%max(1,int(interval))); rec['next_review_due_ts']=due_ts
        if due_ts<=nowv:
            age=max(0.0,nowv-(_quality_optional_num(rec.get('trigger_reached_ts'),rec.get('first_seen_ts')) or nowv))
            item=(float(due_ts),key); due.append(item)
            if age<=600.0: recent_due.append(item)
            lateness=max(0.0,nowv-float(due_ts)); cadence=_quality_optional_num(rec.get('last_review_interval_sec')) or _structure_review_interval(rec,nowv)
            if lateness>cadence:
                overdue+=1; oldest_overdue=max(oldest_overdue,lateness)
        else:
            future+=1
    recent_due.sort(); recent_keys=[k for _d,k in recent_due]; recent_set=set(recent_keys)
    older=sorted((d,k) for d,k in due if k not in recent_set); remaining=max(0,STRUCTURE_REVIEW_UPDATE_BUDGET-len(recent_keys)); selected=recent_keys+[k for _d,k in older[:remaining]]
    return selected,{'due_total':len(due),'recent_due':len(recent_keys),'deferred_due':max(0,len(due)-len(selected)),'scheduled_future':future,'overdue_total':overdue,'oldest_overdue_sec':round(oldest_overdue,3)}


def _structure_plan_stats_v956(records: List[Dict[str,Any]], method: str, summary: Dict[str,Any]) -> Dict[str,Any]:
    rows=[r for r in records if str(r.get('method') or '')==method]; reached=[r for r in rows if r.get('trigger_reached_ts')]
    state_counts=Counter(str(r.get('structure_state') or 'unknown') for r in rows); activation_counts=Counter(str(r.get('trigger_activation_mode') or 'unknown') for r in rows)
    out={'tracked':len(rows),'complete_tracked':sum(1 for r in rows if r.get('source_plan_complete')),'partial_tracked':sum(1 for r in rows if not r.get('source_plan_complete')),'trigger_reached':len(reached),'support_touched':sum(1 for r in rows if r.get('support_touch_count',0)>0),'target_first':sum(1 for r in reached if r.get('first_terminal')=='target'),'invalid_first':sum(1 for r in reached if r.get('first_terminal')=='invalid'),'terminal_unknown':sum(1 for r in reached if r.get('first_terminal') in (None,'','ambiguous')),'weakened_lines':sum(1 for r in rows if r.get('line_weakened')),'role_flip_confirmed':sum(1 for r in rows if r.get('role_flip_confirmed_ts')),'stale_unreached':sum(1 for r in rows if r.get('line_state')=='stale_unreached'),'confirmed_event_started':sum(1 for r in rows if r.get('activation_source')=='confirmed_completed_candle_event_seen_by_review'),'structure_state_counts':dict(state_counts),'activation_mode_counts':dict(activation_counts)}
    method_summary=((summary.get('methods') or {}).get(method) or {}) if isinstance(summary,dict) else {}
    for label,_sec in STRUCTURE_LAB_HORIZONS:
        bucket=method_summary.get(label) if isinstance(method_summary,dict) else None; bucket=bucket if isinstance(bucket,dict) else {}; n=int(bucket.get('n') or 0)
        out[label]={'n':n,'avg_pct':round(float(bucket.get('sum_pct') or 0.0)/n,4) if n else None,'median_pct':None,'avg_max_pct':round(float(bucket.get('sum_max_pct') or 0.0)/n,4) if n else None,'avg_min_pct':round(float(bucket.get('sum_min_pct') or 0.0)/n,4) if n else None,'avg_giveback_pct':round(float(bucket.get('sum_giveback_pct') or 0.0)/n,4) if n else None,'avg_relative_to_btc_pct':round(float(bucket.get('sum_relative_to_btc_pct') or 0.0)/int(bucket.get('relative_n') or 1),4) if int(bucket.get('relative_n') or 0) else None}
    return out

def update_structure_laboratory(nowv: float, fmap: Dict[str,Dict[str,Any]], ofmap: Dict[str,Dict[str,Any]]) -> tuple[Dict[str,Any],Dict[str,Any]]:
    global _STRUCTURE_HORIZON_SUMMARY_CACHE, _STRUCTURE_HORIZON_SUMMARY_LEDGER_SIZE
    global _STRUCTURE_HORIZON_KEYS_CACHE, _STRUCTURE_FINAL_KEYS_CACHE, _STRUCTURE_FINAL_KEY_INDEX_LOADS
    started=time.time(); summary,summary_load=_load_structure_horizon_summary()
    horizon_index_memory_reused=_STRUCTURE_HORIZON_KEYS_CACHE is not None
    final_index_memory_reused=_STRUCTURE_FINAL_KEYS_CACHE is not None
    source_raw=load_json(STRUCTURE_LAB_CANDIDATES,{})
    source=source_raw if isinstance(source_raw,dict) else {}
    current_raw=load_json(STRUCTURE_LAB_STRATEGY_STATUS,{})
    current=current_raw if isinstance(current_raw,dict) else {}
    detail_snapshot_key=str(source.get('snapshot_key') or '').strip()
    current_snapshot_key=str(current.get('snapshot_key') or '').strip()
    snapshot_match=bool(detail_snapshot_key and current_snapshot_key and detail_snapshot_key==current_snapshot_key)
    if snapshot_match:
        lab_rows=source.get('rows') if isinstance(source.get('rows'),list) else []
        missed_rows=source.get('missed_rows') if isinstance(source.get('missed_rows'),list) else []
        snapshot_state='MATCHED'
    else:
        lab_rows=[]
        missed_rows=[]
        snapshot_state='WAITING_DETAIL_SYNC' if current else 'WAITING_CURRENT_STATUS'
    try:
        records,migration=_load_structure_state_v956(nowv,summary)
    except Exception:
        _STRUCTURE_HORIZON_KEYS_CACHE=None; _STRUCTURE_FINAL_KEYS_CACHE=None
        _STRUCTURE_HORIZON_SUMMARY_CACHE=None; _STRUCTURE_HORIZON_SUMMARY_LEDGER_SIZE=-1
        raise
    missed,migrated_missed=_load_structure_missed_state_v956()
    new_plans=0; new_missed=0; detail_appended=0; horizon_appended=0; finalized_this_cycle=0; current_found_by_ticker={}; current_complete_by_ticker={}; review_price_fresh_samples=0; review_price_stale_skips=0; state_dirty=bool(migration.get('migrated_records')); summary_dirty=bool(migration.get('migrated_samples')) or bool(summary_load.get('rebuilt_from_ledger'))
    horizon_cycle_rows:List[Dict[str,Any]]=[]; final_cycle_rows:List[Dict[str,Any]]=[]
    btc_state=_structure_review_price_state('BTC',fmap,ofmap,nowv); btc_now=btc_state.get('price') if btc_state.get('fresh') else 0.0
    for lab in lab_rows:
        if not isinstance(lab,dict): continue
        ticker=ticker_norm(lab.get('ticker')); methods=lab.get('methods') if isinstance(lab.get('methods'),dict) else {}
        found_methods=lab.get('found_methods') if isinstance(lab.get('found_methods'),list) else []; complete_methods=lab.get('complete_methods') if isinstance(lab.get('complete_methods'),list) else []
        if ticker:
            current_found_by_ticker[ticker]=set(str(x) for x in found_methods); current_complete_by_ticker[ticker]=set(str(x) for x in complete_methods)
        for method,plan in methods.items():
            if not isinstance(plan,dict) or not plan.get('trackable') or plan.get('signal_state') not in ('new_signal','active_signal_delivery') or not plan.get('structure_found'): continue
            key=str(plan.get('event_key') or '').strip()
            if not key or not ticker: continue
            rec=records.get(key)
            if rec is None:
                event_ts=_quality_optional_num(plan.get('event_source_ts')) or nowv; start_price=_quality_optional_num(plan.get('event_source_price')) or _quality_optional_num(plan.get('current_price')) or _current_price(ticker,fmap,ofmap)
                full={'schema':'structure_lab_event_detail_v956','plan_key':key,'event_key':key,'method':str(method),'method_label':plan.get('method_label'),'ticker':ticker,'candidate_exact_identity':plan.get('candidate_exact_identity'),'first_seen_ts':event_ts,'first_seen_text':now_text(event_ts),'first_price':start_price,'structure_state':plan.get('structure_state'),'signal_state':plan.get('signal_state'),'event_kind':plan.get('event_kind'),'event_lifecycle_state':plan.get('event_lifecycle_state'),'source_plan_complete':bool(plan.get('plan_complete')),'component_status':plan.get('component_status'),'discovery_reasons':plan.get('discovery_reasons'),'incomplete_reasons':plan.get('incomplete_reasons'),'trigger_activation_mode':plan.get('trigger_activation_mode'),'trigger_source_state':plan.get('trigger_source_state'),'trigger':plan.get('trigger'),'invalid':plan.get('invalid'),'target':plan.get('target'),'support_zone':plan.get('support_zone'),'trigger_zone':plan.get('trigger_zone'),'target_zone':plan.get('target_zone'),'anchor_zone':plan.get('anchor_zone'),'primary_tf':plan.get('primary_tf'),'evidence':plan.get('evidence'),'method_contract_version':plan.get('method_contract_version'),'market_context':plan.get('market_context'),'execution_snapshot':plan.get('execution_snapshot'),'tick_pct':plan.get('tick_pct'),'low_price_tick_risk':plan.get('low_price_tick_risk'),'source_event_ts':event_ts,'source_event_price':start_price,'source_to_review_lag_sec':round(max(0.0,nowv-event_ts),3),'line_state':'fresh_completed_candle_signal','support_touch_count':0,'trigger_retest_count':0,'max_pct':0.0,'min_pct':0.0,'giveback_pct':0.0,'btc_start_price':btc_now or None,'observation_only':True,'trigger_reached_ts':event_ts,'entry_price':start_price,'activation_source':'strategy_exact_completed_candle_event','source_current_state_fresh':bool(plan.get('current_state_fresh')),'source_map_refresh_pending':bool(plan.get('map_refresh_pending')),'source_priority_lane':plan.get('priority_lane'),'next_review_due_ts':nowv,'horizon_mask':0}
                if _append_structure_detail_once(full): detail_appended+=1
                rec=_structure_active_record(full); new_plans+=1; state_dirty=True
            rec['last_source_seen_ts']=nowv; rec['candidate_exact_identity_last']=plan.get('candidate_exact_identity'); rec['source_plan_complete']=bool(plan.get('plan_complete')); rec['structure_state']=plan.get('structure_state'); rec['source_current_state_fresh']=bool(plan.get('current_state_fresh')); rec['source_map_refresh_pending']=bool(plan.get('map_refresh_pending')); rec['source_priority_lane']=plan.get('priority_lane'); records[key]=rec; state_dirty=True

    selected_keys,due_meta=_structure_due_selection(records,nowv); recent_processed=0; finalize_keys=[]
    for key in selected_keys:
        rec=records.get(key)
        if not isinstance(rec,dict): continue
        age0=max(0.0,nowv-(_quality_optional_num(rec.get('trigger_reached_ts'),rec.get('first_seen_ts')) or nowv))
        if age0<=600: recent_processed+=1
        ticker=ticker_norm(rec.get('ticker')); price_state=_structure_review_price_state(ticker,fmap,ofmap,nowv); rec['review_price_source']=price_state.get('source'); rec['review_price_age_sec']=price_state.get('age_sec')
        if not price_state.get('fresh'):
            rec['line_state']='stale_price_wait'; rec['review_price_stale_skip_count']=int(rec.get('review_price_stale_skip_count') or 0)+1; review_price_stale_skips+=1
            interval=_structure_review_interval(rec,nowv); rec['next_review_due_ts']=nowv+interval; rec['last_review_interval_sec']=interval; rec['last_review_update_ts']=nowv; rec['review_update_count']=int(rec.get('review_update_count') or 0)+1; records[key]=rec; state_dirty=True; continue
        cur=float(price_state.get('price') or 0.0); review_price_fresh_samples+=1
        if cur<=0: continue
        age=max(0.0,nowv-float(rec.get('first_seen_ts') or nowv)); rec['line_age_sec']=round(age,1)
        tf=str(rec.get('primary_tf') or 'm1'); stale_limit={'h4':14400.0,'h2':10800.0,'h1':7200.0,'m30':5400.0,'m15':3600.0,'m5':2400.0,'m3':1800.0,'m1':1200.0}.get(tf,1800.0)
        if not rec.get('trigger_reached_ts') and age>=stale_limit: rec['line_state']='stale_unreached'
        sl,sh=_structure_zone_bounds(rec.get('support_zone')); zone_eps=max(1e-12,max(abs(sl or 0.0),abs(sh or 0.0),abs(cur))*1e-12)
        if sl is not None and sh is not None and sl-zone_eps<=cur<=sh+zone_eps:
            last=_quality_optional_num(rec.get('last_support_touch_ts')) or 0.0
            if nowv-last>=30.0:
                rec['support_touch_count']=int(rec.get('support_touch_count') or 0)+1; rec['last_support_touch_ts']=nowv; rec['line_state']='support_touched'
                if rec['support_touch_count']>=3: rec['line_weakened']=True; rec['weakening_reason']='support_zone_reused_three_or_more_times'; rec['line_state']='weakened_multi_touch'
        trigger=_quality_optional_num(rec.get('trigger')) or 0.0; mode=str(rec.get('trigger_activation_mode') or ''); can_activate=False
        if mode=='swing_resistance_breakout': can_activate=trigger>0 and cur>=trigger
        elif mode in ('support_recovery_after_touch','demand_recovery_after_touch','volume_node_reclaim_after_touch'): can_activate=bool(rec.get('support_touch_count',0)>0 and trigger>0 and cur>=trigger)
        elif mode=='confirmed_break_retest_event': can_activate=bool(rec.get('trigger_reached_ts'))
        if not rec.get('trigger_reached_ts') and can_activate:
            rec['trigger_reached_ts']=nowv; rec['entry_price']=cur; rec['line_state']='trigger_reached'; rec['activation_source']='live_review_condition'; rec['max_pct']=0.0; rec['min_pct']=0.0; rec['giveback_pct']=0.0
        if rec.get('trigger_reached_ts') and (_quality_optional_num(rec.get('entry_price')) or 0)>0:
            tl,th=_structure_zone_bounds(rec.get('trigger_zone'))
            if tl is not None and th is not None and tl<=cur<=th and nowv-float(rec.get('trigger_reached_ts') or nowv)>=30.0:
                last=_quality_optional_num(rec.get('last_trigger_retest_ts')) or 0.0
                if nowv-last>=30.0:
                    rec['trigger_retest_count']=int(rec.get('trigger_retest_count') or 0)+1; rec['last_trigger_retest_ts']=nowv
                    if mode=='swing_resistance_breakout': rec['role_flip_confirmed_ts']=nowv; rec['line_state']='resistance_to_support_confirmed'
            base=float(rec['entry_price']); pctv=(cur-base)/base*100.0; rec['current_price']=cur; rec['current_pct']=round(pctv,6); rec['max_pct']=max(_quality_optional_num(rec.get('max_pct')) or pctv,pctv); rec['min_pct']=min(_quality_optional_num(rec.get('min_pct')) or pctv,pctv); rec['giveback_pct']=round(float(rec['max_pct'])-pctv,6)
            inv=_quality_optional_num(rec.get('invalid')); tgt=_quality_optional_num(rec.get('target')); terminal=[]
            if inv and cur<=inv:
                if not rec.get('invalid_ts'): rec['invalid_ts']=nowv
                terminal.append('invalid')
            if tgt and cur>=tgt:
                if not rec.get('target_ts'): rec['target_ts']=nowv
                terminal.append('target')
            if not rec.get('first_terminal'):
                if len(terminal)==1: rec['first_terminal']=terminal[0]; rec['line_state']=terminal[0]+'_first'
                elif len(terminal)>1: rec['first_terminal']='ambiguous'; rec['line_state']='terminal_order_unknown'
            elapsed=max(0.0,nowv-float(rec['trigger_reached_ts'])); btc_start=_quality_optional_num(rec.get('btc_start_price')); btc_ret=(btc_now-btc_start)/btc_start*100.0 if btc_start and btc_now else None
            for label,sec in STRUCTURE_LAB_HORIZONS:
                if elapsed<sec or int(rec.get('horizon_mask') or 0)&_STRUCTURE_HORIZON_BITS[label]: continue
                sample={'ts':nowv,'pct':rec['current_pct'],'max_pct':rec['max_pct'],'min_pct':rec['min_pct'],'giveback_pct':rec['giveback_pct'],'btc_pct':round(btc_ret,6) if btc_ret is not None else None,'relative_to_btc_pct':round(rec['current_pct']-btc_ret,6) if btc_ret is not None else None,'sample_lag_sec':round(max(0.0,elapsed-sec),3)}
                if _append_structure_horizon_once(rec,label,sample,summary,batch_rows=horizon_cycle_rows): horizon_appended+=1; summary_dirty=True
        interval=_structure_review_interval(rec,nowv); rec['next_review_due_ts']=nowv+interval; rec['last_review_interval_sec']=interval; rec['last_review_update_ts']=nowv; rec['review_update_count']=int(rec.get('review_update_count') or 0)+1; records[key]=rec; state_dirty=True
        if int(rec.get('horizon_mask') or 0)==_STRUCTURE_ALL_HORIZONS_MASK:
            if _append_structure_final_once(rec,nowv,batch_rows=final_cycle_rows): finalized_this_cycle+=1
            finalize_keys.append(key)
    try:
        horizon_batch_written=_append_jsonl_batch_fsync(STRUCTURE_LAB_HORIZON_LEDGER,horizon_cycle_rows)
    except Exception:
        _STRUCTURE_HORIZON_KEYS_CACHE=None
        _STRUCTURE_HORIZON_SUMMARY_CACHE=None; _STRUCTURE_HORIZON_SUMMARY_LEDGER_SIZE=-1
        raise
    try:
        final_batch_written=_append_jsonl_batch_fsync(STRUCTURE_LAB_FINAL_LEDGER,final_cycle_rows)
    except Exception:
        _STRUCTURE_FINAL_KEYS_CACHE=None
        raise
    for key in finalize_keys: records.pop(key,None)

    for item in missed_rows:
        if not isinstance(item,dict): continue
        key=str(item.get('miss_key') or '').strip(); ticker=ticker_norm(item.get('ticker'))
        if not key or not ticker: continue
        rec=missed.get(key)
        if rec is None:
            first=_quality_optional_num(item.get('first_price')) or _current_price(ticker,fmap,ofmap)
            rec={'schema':'structure_missed_state_row_v956','miss_key':key,'ticker':ticker,'source':item.get('source'),'reason':item.get('reason'),'method_diagnostics':item.get('method_diagnostics'),'found_methods':item.get('found_methods'),'candidate_exact_identity':item.get('candidate_exact_identity'),'structure_occurrence_key':item.get('structure_occurrence_key'),'scanner_occurrence':item.get('scanner_occurrence'),'first_seen_ts':_quality_optional_num(item.get('first_seen_ts')) or nowv,'first_price':first,'samples':{},'max_pct':0.0,'min_pct':0.0,'btc_start_price':btc_now or None,'observation_only':True}; new_missed+=1
        rec['last_source_seen_ts']=nowv; rec['candidate_exact_identity_last']=item.get('candidate_exact_identity'); missed[key]=rec
    for key,rec in list(missed.items()):
        ticker=ticker_norm(rec.get('ticker')); price_state=_structure_review_price_state(ticker,fmap,ofmap,nowv); base=_quality_optional_num(rec.get('first_price')) or 0.0
        if not price_state.get('fresh'):
            rec['review_price_stale_skip_count']=int(rec.get('review_price_stale_skip_count') or 0)+1; review_price_stale_skips+=1; missed[key]=rec; continue
        cur=float(price_state.get('price') or 0.0); review_price_fresh_samples+=1
        if cur>0 and base>0:
            pctv=(cur-base)/base*100.0; rec['current_price']=cur; rec['current_pct']=round(pctv,6); rec['max_pct']=max(_quality_optional_num(rec.get('max_pct')) or pctv,pctv); rec['min_pct']=min(_quality_optional_num(rec.get('min_pct')) or pctv,pctv)
            elapsed=max(0.0,nowv-float(rec.get('first_seen_ts') or nowv)); samples=rec.get('samples') if isinstance(rec.get('samples'),dict) else {}
            for label,sec in STRUCTURE_LAB_HORIZONS:
                if elapsed>=sec and label not in samples: samples[label]={'ts':nowv,'pct':rec['current_pct'],'max_pct':rec['max_pct'],'min_pct':rec['min_pct']}
            rec['samples']=samples
        if current_found_by_ticker.get(ticker) and not rec.get('later_structure_created_ts'):
            rec['later_structure_created_ts']=nowv; rec['later_found_methods']=sorted(current_found_by_ticker[ticker])
        if current_complete_by_ticker.get(ticker) and not rec.get('later_complete_plan_created_ts'):
            rec['later_complete_plan_created_ts']=nowv; rec['later_complete_methods']=sorted(current_complete_by_ticker[ticker])
        missed[key]=rec

    records={k:v for k,v in records.items() if nowv-(_quality_optional_num(v.get('first_seen_ts')) or nowv)<=STRUCTURE_LAB_RETENTION_SEC}; missed={k:v for k,v in missed.items() if nowv-(_quality_optional_num(v.get('first_seen_ts')) or nowv)<=STRUCTURE_LAB_RETENTION_SEC}
    vals=list(records.values()); miss_vals=list(missed.values()); method_stats={m:_structure_plan_stats_v956(vals,m,summary) for m in ('A_SWING','B_REACTION_ZONE','C_BREAK_RETEST','D_SUPPLY_DEMAND','E_VOLUME_PROFILE')}
    active_write=False
    if state_dirty or not STRUCTURE_LAB_ACTIVE_STATE.exists():
        save_json(STRUCTURE_LAB_ACTIVE_STATE,{'schema':'structure_lab_active_state_v956','version':VERSION,'updated_ts':nowv,'records':records,'static_detail_ledgers':[STRUCTURE_LAB_EVENT_DETAIL_LEDGER_LEGACY.name,STRUCTURE_LAB_EVENT_DETAIL_LEDGER.name],'horizon_ledger':STRUCTURE_LAB_HORIZON_LEDGER.name,'final_ledger':STRUCTURE_LAB_FINAL_LEDGER.name}); active_write=True
    save_json(STRUCTURE_MISSED_STATE,{'schema':'structure_missed_state_v956','version':VERSION,'updated_ts':nowv,'records':missed})
    summary_write=False
    current_horizon_size=STRUCTURE_LAB_HORIZON_LEDGER.stat().st_size if STRUCTURE_LAB_HORIZON_LEDGER.exists() else 0
    if summary_dirty or not STRUCTURE_LAB_HORIZON_SUMMARY.exists() or int(summary.get('ledger_size_bytes') or 0)!=current_horizon_size:
        summary['updated_ts']=nowv; summary['ledger_size_bytes']=current_horizon_size; save_json(STRUCTURE_LAB_HORIZON_SUMMARY,summary); summary_write=True
    _STRUCTURE_HORIZON_SUMMARY_CACHE=summary; _STRUCTURE_HORIZON_SUMMARY_LEDGER_SIZE=current_horizon_size
    active_bytes=STRUCTURE_LAB_ACTIVE_STATE.stat().st_size if STRUCTURE_LAB_ACTIVE_STATE.exists() else 0; horizon_bytes=STRUCTURE_LAB_HORIZON_LEDGER.stat().st_size if STRUCTURE_LAB_HORIZON_LEDGER.exists() else 0; final_bytes=STRUCTURE_LAB_FINAL_LEDGER.stat().st_size if STRUCTURE_LAB_FINAL_LEDGER.exists() else 0
    if _STRUCTURE_FINAL_KEYS_CACHE is None:
        _STRUCTURE_FINAL_KEYS_CACHE=_load_jsonl_key_set([STRUCTURE_LAB_FINAL_LEDGER],_structure_final_key)
        _STRUCTURE_FINAL_KEY_INDEX_LOADS+=1
    status={'schema':'structure_lab_review_status_v960','version':VERSION,'build':'performance_cost_exact_identity_v961_2026-06-21','state':'ACTIVE' if vals else ('WAITING_FRESH_SIGNAL' if lab_rows else 'WAITING_SOURCE'),'updated_ts':nowv,'updated_text':now_text(nowv),'source_candidate_rows':len(lab_rows),'source_candidate_unique_tickers':current.get('candidate_unique_tickers') if isinstance(current,dict) else 0,'source_total_candidate_rows':current.get('candidate_rows',0) if isinstance(current,dict) else 0,'source_analysis_ready_rows':current.get('analysis_ready_rows',0) if isinstance(current,dict) else 0,'source_partial_rows':current.get('source_partial_rows',0) if isinstance(current,dict) else 0,'source_not_ready_rows':current.get('source_not_ready_rows_count',0) if isinstance(current,dict) else 0,'source_frame_ready_counts':current.get('source_frame_ready_counts',{}) if isinstance(current,dict) else {},'source_snapshot_state':snapshot_state,'source_snapshot_match':snapshot_match,'source_snapshot_key':current_snapshot_key,'detail_snapshot_key':detail_snapshot_key,'detail_rows_processed':len(lab_rows),'tracked_structures':len(vals),'completed_events_total':len(_STRUCTURE_FINAL_KEYS_CACHE),'finalized_this_cycle':finalized_this_cycle,'new_structures_this_cycle':new_plans,'review_price_fresh_samples':review_price_fresh_samples,'review_price_stale_skips':review_price_stale_skips,'review_price_ttl_sec':STRUCTURE_REVIEW_PRICE_TTL_SEC,'review_update_budget':STRUCTURE_REVIEW_UPDATE_BUDGET,'review_due_processed':len(selected_keys),'review_recent_fast_processed':recent_processed,'review_due_total':due_meta.get('due_total',0),'review_deferred_due':due_meta.get('deferred_due',0),'review_scheduled_future':due_meta.get('scheduled_future',0),'review_overdue_total':due_meta.get('overdue_total',0),'review_oldest_overdue_sec':due_meta.get('oldest_overdue_sec',0.0),'legacy_state_migrated_records':migration.get('migrated_records',0),'legacy_horizon_samples_migrated':migration.get('migrated_samples',0),'legacy_finalized_on_migration':migration.get('finalized_on_migration',0),'migration_horizon_batch_rows':migration.get('migration_horizon_batch_rows',0),'migration_final_batch_rows':migration.get('migration_final_batch_rows',0),'missed_migrated':migrated_missed,'detail_ledger_appended_this_cycle':detail_appended,'horizon_appended_this_cycle':horizon_appended,'horizon_batch_rows_this_cycle':horizon_batch_written,'horizon_fsync_count_this_cycle':1 if horizon_batch_written else 0,'final_batch_rows_this_cycle':final_batch_written,'final_fsync_count_this_cycle':1 if final_batch_written else 0,'horizon_summary_memory_reused':bool(summary_load.get('memory_reused')),'horizon_summary_disk_reused':bool(summary_load.get('disk_summary_reused')),'horizon_summary_rebuilt_this_cycle':bool(summary_load.get('rebuilt_from_ledger')),'horizon_summary_write_this_cycle':summary_write,'horizon_summary_full_scans_process':_STRUCTURE_HORIZON_SUMMARY_FULL_SCANS,'horizon_summary_memory_hits_process':_STRUCTURE_HORIZON_SUMMARY_MEMORY_HITS,'horizon_key_index_memory_reused':horizon_index_memory_reused,'final_key_index_memory_reused':final_index_memory_reused,'horizon_key_index_loads_process':_STRUCTURE_HORIZON_KEY_INDEX_LOADS,'final_key_index_loads_process':_STRUCTURE_FINAL_KEY_INDEX_LOADS,'horizon_key_index_size':len(_STRUCTURE_HORIZON_KEYS_CACHE or ()),'final_key_index_size':len(_STRUCTURE_FINAL_KEYS_CACHE or ()),'active_state_bytes':active_bytes,'horizon_ledger_bytes':horizon_bytes,'horizon_result_rows':int(summary.get('total_rows') or 0),'final_ledger_bytes':final_bytes,'active_state_write_this_cycle':active_write,'review_cycle_sec':round(time.time()-started,3),'btc_price_fresh':bool(btc_state.get('fresh')),'method_stats':method_stats,'source_method_found_counts':current.get('method_found_counts') if isinstance(current,dict) else {},'source_method_complete_counts':current.get('method_complete_counts') if isinstance(current,dict) else {},'source_method_partial_counts':current.get('method_partial_counts') if isinstance(current,dict) else {},'source_method_no_structure_counts':current.get('method_no_structure_counts') if isinstance(current,dict) else {},'source_method_component_counts':current.get('method_component_counts') if isinstance(current,dict) else {},'source_method_signal_state_counts':current.get('method_signal_state_counts') if isinstance(current,dict) else {},'source_event_scan_same_frame_skipped':int(current.get('event_scan_same_frame_skipped') or 0) if isinstance(current,dict) else 0,'source_event_scan_executed':int(current.get('event_scan_executed') or 0) if isinstance(current,dict) else 0,'source_fresh_signal_count':int(current.get('fresh_signal_count') or 0) if isinstance(current,dict) else 0,'source_active_signal_delivery_count':int(current.get('active_signal_delivery_count') or 0) if isinstance(current,dict) else 0,'source_historical_baseline_event_count':int(current.get('historical_baseline_event_count') or 0) if isinstance(current,dict) else 0,'source_waiting_new_event_count':int(current.get('waiting_new_event_count') or 0) if isinstance(current,dict) else 0,'source_invalid_or_completed_event_count':int(current.get('invalid_or_completed_event_count') or 0) if isinstance(current,dict) else 0,'source_age_sec':round(max(0.0,nowv-(_quality_optional_num(current.get('updated_ts')) or nowv)),3) if isinstance(current,dict) else None,'source_broad_scan_unique_tickers':int(current.get('broad_scan_unique_tickers') or 0) if isinstance(current,dict) else 0,'source_priority_lane_counts':current.get('priority_lane_counts',{}) if isinstance(current,dict) else {},'source_reused_historical_map':int(current.get('reused_historical_map') or 0) if isinstance(current,dict) else 0,'source_recomputed_this_cycle':int(current.get('recomputed_this_cycle') or 0) if isinstance(current,dict) else 0,'source_map_refresh_pending_count':int(current.get('map_refresh_pending_count') or 0) if isinstance(current,dict) else 0,'source_live_state_fresh_count':int(current.get('live_state_fresh_count') or 0) if isinstance(current,dict) else 0,'source_live_state_stale_count':int(current.get('live_state_stale_count') or 0) if isinstance(current,dict) else 0,'source_map_source_fresh_count':int(current.get('map_source_fresh_count') or 0) if isinstance(current,dict) else 0,'source_map_source_stale_count':int(current.get('map_source_stale_count') or 0) if isinstance(current,dict) else 0,'source_refresh_request_count':int(current.get('refresh_request_count') or 0) if isinstance(current,dict) else 0,'source_stale_current_state_wait_count':int(current.get('stale_current_state_wait_count') or 0) if isinstance(current,dict) else 0,'source_stale_event_source_wait_count':int(current.get('stale_event_source_wait_count') or 0) if isinstance(current,dict) else 0,'discovery_reason_top':current.get('discovery_reason_top') if isinstance(current,dict) else [],'incomplete_reason_top':current.get('incomplete_reason_top') if isinstance(current,dict) else [],'completed_candles_only':True,'forming_candle_excluded':True,'policy':'static detail append-once; each horizon append-once; live state stores dynamic fields only; full 240m completion moves to final ledger and leaves active state; due/overdue/scheduled are separately measured; stale prices are skipped','trading_rules_changed':False}
    missed_status={'schema':'structure_missed_status_v960','version':VERSION,'build':'performance_cost_exact_identity_v961_2026-06-21','state':'ACTIVE' if miss_vals else ('WAITING_DETAIL_SYNC' if current else 'WAITING_CURRENT_STATUS'),'updated_ts':nowv,'updated_text':now_text(nowv),'new_missed_this_cycle':new_missed,'current_snapshot_state':snapshot_state,'current_snapshot_match':snapshot_match,'current_snapshot_key':current_snapshot_key,'detail_snapshot_key':detail_snapshot_key,'detail_rows_processed':len(lab_rows),'source_not_ready_excluded':int(current.get('source_not_ready_rows_count') or 0) if isinstance(current,dict) else 0,'source_analysis_ready_rows':int(current.get('analysis_ready_rows') or 0) if isinstance(current,dict) else 0,'source_all_methods_no_structure':int(current.get('all_methods_no_structure_count') or 0) if isinstance(current,dict) else 0,'source_structure_found_no_complete':int(current.get('structure_found_no_complete_count') or 0) if isinstance(current,dict) else 0,'source_scanner_not_candidate':int(current.get('scanner_seen_not_candidate_count') or 0) if isinstance(current,dict) else 0,'source_scanner_not_candidate_unique':int(current.get('scanner_seen_not_candidate_unique_tickers') or 0) if isinstance(current,dict) else 0,'source_scanner_pool_not_candidate':int(current.get('scanner_pool_not_candidate_count') or 0) if isinstance(current,dict) else 0,'source_scanner_pool_not_candidate_unique':int(current.get('scanner_pool_not_candidate_unique_tickers') or 0) if isinstance(current,dict) else 0,'market_counts':{'candidate_rows':current.get('candidate_rows',0),'candidate_unique_tickers':current.get('candidate_unique_tickers',0),'scanner_hot_rows':current.get('scanner_hot_rows',0),'scanner_hot_unique_tickers':current.get('scanner_hot_unique_tickers',0),'scanner_pool_rows':current.get('scanner_pool_rows',0),'scanner_pool_unique_tickers':current.get('scanner_pool_unique_tickers',0)},'stats':_structure_missed_stats(miss_vals),'samples':sorted(miss_vals,key=lambda r:_quality_optional_num(r.get('max_pct')) or -999,reverse=True)[:12],'policy':'current market counts come only from strategy compact status; missed detail rows are consumed only when both files share the exact snapshot key; old missed records stay preserved','trading_rules_changed':False}
    save_json(STRUCTURE_LAB_REVIEW_STATUS,status); save_json(STRUCTURE_MISSED_STATUS,missed_status)
    return status,missed_status



def _performance_empty_structure_index() -> Dict[str, Any]:
    return {
        'schema':'performance_structure_index_v959','ledger_size_bytes':0,'ledger_rows':0,
        'methods':{},'updated_ts':0.0,
    }


def _performance_bucket(index: Dict[str, Any], method: str, horizon: str) -> Dict[str, Any]:
    methods=index.setdefault('methods',{})
    method_obj=methods.setdefault(method,{})
    return method_obj.setdefault(horizon,{
        'n':0,'sum_pct':0.0,'values':[],'clean_n':0,'clean_sum_pct':0.0,
        'max_n':0,'sum_max_pct':0.0,'min_n':0,'sum_min_pct':0.0,
        'giveback_n':0,'sum_giveback_pct':0.0,'relative_n':0,'sum_relative_pct':0.0,
        'distortion_count':0,'ticker_stats':{},'terminal_counts':{},
    })


def _performance_tick_pct(price: Optional[float]) -> float:
    if price is None or price <= 0: return 0.0
    return _sample_price_unit(float(price))/float(price)*100.0


def _performance_add_structure_row(index: Dict[str, Any], row: Dict[str, Any]) -> bool:
    method=str(row.get('method') or '').strip(); horizon=str(row.get('horizon') or '').strip()
    if method not in PERFORMANCE_STRUCTURE_METHODS or horizon not in PERFORMANCE_STRUCTURE_HORIZONS:
        return False
    pct=_quality_optional_num(row.get('pct'))
    if pct is None: return False
    bucket=_performance_bucket(index,method,horizon)
    bucket['n']=int(bucket.get('n') or 0)+1
    bucket['sum_pct']=float(bucket.get('sum_pct') or 0.0)+pct
    values=bucket.get('values') if isinstance(bucket.get('values'),list) else []
    values.append(round(pct,6)); bucket['values']=values
    price=_quality_optional_num(row.get('entry_price'))
    distortion=bool(_performance_tick_pct(price)>=0.50 or abs(pct)>=15.0)
    if distortion:
        bucket['distortion_count']=int(bucket.get('distortion_count') or 0)+1
    else:
        bucket['clean_n']=int(bucket.get('clean_n') or 0)+1
        bucket['clean_sum_pct']=float(bucket.get('clean_sum_pct') or 0.0)+pct
    for field,nkey,skey in (
        ('max_pct','max_n','sum_max_pct'),('min_pct','min_n','sum_min_pct'),
        ('giveback_pct','giveback_n','sum_giveback_pct'),('relative_to_btc_pct','relative_n','sum_relative_pct')):
        value=_quality_optional_num(row.get(field))
        if value is not None:
            bucket[nkey]=int(bucket.get(nkey) or 0)+1
            bucket[skey]=float(bucket.get(skey) or 0.0)+value
    ticker=ticker_norm(row.get('ticker'))
    if ticker:
        ticker_stats=bucket.get('ticker_stats') if isinstance(bucket.get('ticker_stats'),dict) else {}
        pair=ticker_stats.get(ticker) if isinstance(ticker_stats.get(ticker),list) else [0.0,0]
        pair=[float(pair[0])+pct,int(pair[1])+1]; ticker_stats[ticker]=pair; bucket['ticker_stats']=ticker_stats
    terminal=str(row.get('first_terminal') or 'unknown')
    terminal_counts=bucket.get('terminal_counts') if isinstance(bucket.get('terminal_counts'),dict) else {}
    terminal_counts[terminal]=int(terminal_counts.get(terminal) or 0)+1; bucket['terminal_counts']=terminal_counts
    index['ledger_rows']=int(index.get('ledger_rows') or 0)+1
    return True


def _performance_refresh_structure_index(nowv: float) -> tuple[Dict[str, Any],Dict[str, Any]]:
    current_size=STRUCTURE_LAB_HORIZON_LEDGER.stat().st_size if STRUCTURE_LAB_HORIZON_LEDGER.exists() else 0
    saved=load_json(PERFORMANCE_STRUCTURE_INDEX,{}) or {}
    valid=isinstance(saved,dict) and saved.get('schema')=='performance_structure_index_v959'
    old_size=int(saved.get('ledger_size_bytes') or 0) if valid else 0
    rebuild=(not valid) or old_size<0 or old_size>current_size
    index=_performance_empty_structure_index() if rebuild else saved
    start=0 if rebuild else old_size
    rows_read=0
    if current_size>start:
        with STRUCTURE_LAB_HORIZON_LEDGER.open('rb') as handle:
            handle.seek(start)
            data=handle.read()
        # Writer commits complete newline-terminated batches. Ignore a partial tail defensively.
        complete=data.rsplit(b'\n',1)[0] if data and not data.endswith(b'\n') else data
        for raw in complete.splitlines():
            if not raw.strip(): continue
            try: row=json.loads(raw.decode('utf-8','ignore'))
            except Exception: continue
            if isinstance(row,dict) and _performance_add_structure_row(index,row): rows_read+=1
    index_write=bool(rebuild or rows_read or not PERFORMANCE_STRUCTURE_INDEX.exists())
    index['ledger_size_bytes']=current_size
    if index_write:
        index['updated_ts']=nowv
        save_json(PERFORMANCE_STRUCTURE_INDEX,index)
    return index,{
        'rebuilt':rebuild,'incremental_rows':rows_read,'ledger_size_bytes':current_size,
        'ledger_rows':int(index.get('ledger_rows') or 0),'start_offset':start,'index_write_this_cycle':index_write,
    }


def _performance_structure_stats(index: Dict[str, Any]) -> Dict[str, Any]:
    out={}
    methods=index.get('methods') if isinstance(index.get('methods'),dict) else {}
    for method in PERFORMANCE_STRUCTURE_METHODS:
        method_out={}
        raw_method=methods.get(method) if isinstance(methods.get(method),dict) else {}
        for horizon in PERFORMANCE_STRUCTURE_HORIZONS:
            bucket=raw_method.get(horizon) if isinstance(raw_method.get(horizon),dict) else {}
            n=int(bucket.get('n') or 0)
            if not n: continue
            values=[float(x) for x in (bucket.get('values') or []) if isinstance(x,(int,float))]
            ticker_stats=bucket.get('ticker_stats') if isinstance(bucket.get('ticker_stats'),dict) else {}
            ticker_avgs=[float(v[0])/int(v[1]) for v in ticker_stats.values() if isinstance(v,list) and len(v)>=2 and int(v[1])>0]
            def avg(sum_key: str,n_key: str) -> Optional[float]:
                count=int(bucket.get(n_key) or 0)
                return round(float(bucket.get(sum_key) or 0.0)/count,4) if count else None
            clean_n=int(bucket.get('clean_n') or 0)
            method_out[horizon]={
                'n':n,'avg_pct':round(float(bucket.get('sum_pct') or 0.0)/n,4),
                'median_pct':round(_quality_percentile(values,0.50),4) if values else None,
                'p10_pct':round(_quality_percentile(values,0.10),4) if values else None,
                'p90_pct':round(_quality_percentile(values,0.90),4) if values else None,
                'clean_n':clean_n,'clean_avg_pct':round(float(bucket.get('clean_sum_pct') or 0.0)/clean_n,4) if clean_n else None,
                'unique_tickers':len(ticker_stats),'unique_ticker_avg_pct':round(sum(ticker_avgs)/len(ticker_avgs),4) if ticker_avgs else None,
                'avg_max_pct':avg('sum_max_pct','max_n'),'avg_min_pct':avg('sum_min_pct','min_n'),
                'avg_giveback_pct':avg('sum_giveback_pct','giveback_n'),'avg_relative_to_btc_pct':avg('sum_relative_pct','relative_n'),
                'distortion_count':int(bucket.get('distortion_count') or 0),
                'terminal_counts':dict(bucket.get('terminal_counts') or {}),
            }
        out[method]=method_out
    return out


def _performance_cost_state_rank(row: Dict[str, Any]) -> int:
    if not isinstance(row, dict):
        return 0
    state=str(row.get('measurement_state') or '').strip().lower()
    if row.get('exchange_confirmed') is True or state in {'exchange_confirmed','average_fill_confirmed','actual_fill_confirmed'}:
        return 40
    if state=='paper_reference_confirmed':
        return 30
    if state=='paper_reference_stale':
        return 20
    if state:
        return 10
    return 0


def _performance_cost_exact_identity(row: Dict[str, Any]) -> Dict[str, Any]:
    """Read only identities sealed by paper's execution-cost writer.

    Writer contract:
      execution_cost_key = ticker|candidate_entry_build_key|pos_id
      pos_id = decision:<minimal_gate_decision_key> for v926 exact OPEN rows.
    No ticker/time-near reconstruction is permitted.
    """
    if not isinstance(row,dict):
        return {'candidate':'','decision':'','pos_id':'','conflict':True,'conflict_reasons':['row_not_dict']}
    execution=str(row.get('execution_cost_key') or '').strip()
    explicit_candidate=str(row.get('candidate_entry_build_key') or '').strip()
    explicit_pos=str(row.get('pos_id') or '').strip()
    parsed_candidate=''; parsed_pos=''
    if execution:
        parts=execution.split('|',2)
        if len(parts)==3:
            parsed_candidate=str(parts[1] or '').strip()
            parsed_pos=str(parts[2] or '').strip()
    conflicts=[]
    if explicit_candidate and parsed_candidate and explicit_candidate!=parsed_candidate:
        conflicts.append('candidate_vs_execution_key')
    if explicit_pos and parsed_pos and explicit_pos!=parsed_pos:
        conflicts.append('pos_vs_execution_key')
    candidate=explicit_candidate
    pos=explicit_pos or parsed_pos
    explicit_decision=str(_performance_first(row,('paper_decision_key_v926','minimal_gate_decision_key_v925','decision_key')) or '').strip()
    decision=''; decision_source='missing'
    if explicit_decision:
        decision=explicit_decision; decision_source='explicit_decision_key'
    elif pos.startswith('decision:') and len(pos)>len('decision:'):
        decision=pos[len('decision:'):].strip(); decision_source='pos_id_decision_prefix'
    elif pos.startswith('market:') and '|plan:' in pos:
        decision=pos; decision_source='pos_id_direct_decision'
    if decision.startswith('decision:'):
        decision=decision[len('decision:'):].strip()
    return {
        'candidate':candidate,'decision':decision,'pos_id':pos,
        'parsed_candidate':parsed_candidate,'parsed_pos_id':parsed_pos,
        'decision_source':decision_source,'conflict':bool(conflicts),'conflict_reasons':conflicts,
    }


def _performance_normalize_cost_observation(row: Dict[str, Any]) -> Dict[str, Any]:
    """Normalize raw cost ledger numbers once at the index boundary."""
    signed=_quality_optional_num(row.get('signed_slippage_pct'))
    cost=_quality_optional_num(row.get('cost_slippage_pct'))
    if cost is None and signed is not None:
        cost=max(0.0,float(signed))
    ready=bool(signed is not None or cost is not None)
    return {
        'canonical_signed_pct':signed,
        'canonical_cost_pct':cost,
        'canonical_numeric_ready':ready,
        'canonical_numeric_source':'paper_execution_cost_ledger',
    }


def _performance_cost_prefer(new_row: Dict[str, Any], prior_row: Optional[Dict[str, Any]]) -> bool:
    """Prefer stronger measurement state, then an actual numeric row, then recency."""
    if not isinstance(prior_row,dict):
        return True
    new_rank=_performance_cost_state_rank(new_row); prior_rank=_performance_cost_state_rank(prior_row)
    if new_rank!=prior_rank:
        return new_rank>prior_rank
    new_ready=bool(new_row.get('canonical_numeric_ready'))
    prior_ready=bool(prior_row.get('canonical_numeric_ready'))
    if new_ready!=prior_ready:
        return new_ready
    new_ts=_quality_optional_num(new_row.get('paper_opened_at')) or 0.0
    prior_ts=_quality_optional_num(prior_row.get('paper_opened_at')) or 0.0
    return new_ts>=prior_ts


def _performance_refresh_cost_index(nowv: float) -> tuple[Dict[str, Any], Dict[str, Any]]:
    """Build the only exact execution-cost index.

    Raw signed/cost fields are consumed only by _performance_normalize_cost_observation.
    Every downstream reader receives canonical_signed_pct/canonical_cost_pct only.
    """
    if PAPER_EXECUTION_COST_LEDGER.exists():
        stat=PAPER_EXECUTION_COST_LEDGER.stat(); current_size=stat.st_size; current_inode=stat.st_ino; current_mtime_ns=stat.st_mtime_ns
    else:
        current_size=0; current_inode=0; current_mtime_ns=0
    loaded=load_json(PERFORMANCE_COST_INDEX,{})
    index=loaded if isinstance(loaded,dict) else {}
    valid=(index.get('schema')=='performance_cost_index_v967' and index.get('numeric_contract')=='canonical_numeric_v967' and isinstance(index.get('observations'),dict))
    start=int(index.get('ledger_size_bytes') or 0) if valid else 0
    saved_inode=int(index.get('ledger_inode') or 0) if valid else 0
    saved_mtime_ns=int(index.get('ledger_mtime_ns') or 0) if valid else 0
    replaced=bool(valid and saved_inode and current_inode and saved_inode!=current_inode)
    same_size_rewritten=bool(valid and current_size==start and saved_mtime_ns and current_mtime_ns!=saved_mtime_ns)
    rebuild=(not valid) or start<0 or start>current_size or replaced or same_size_rewritten
    observations={} if rebuild else dict(index.get('observations'))
    if rebuild: start=0
    rows_read=0; consumed_size=start; partial_tail_bytes=0
    keep_fields=(
        'execution_cost_key','candidate_entry_build_key','candidate_entry_build_key_source','pos_id','event_id',
        'paper_decision_key_v926','minimal_gate_decision_key_v925','decision_key','paper_score_patch_version',
        'measurement_state','measurement_type','paper_opened_at','quote_age_sec','exchange_confirmed','ticker'
    )
    if current_size>start:
        with PAPER_EXECUTION_COST_LEDGER.open('rb') as handle:
            handle.seek(start); data=handle.read()
        if data.endswith(b'\n'):
            complete=data
        else:
            last_newline=data.rfind(b'\n')
            complete=data[:last_newline+1] if last_newline>=0 else b''
            partial_tail_bytes=len(data)-len(complete)
        consumed_size=start+len(complete)
        for raw in complete.splitlines():
            if not raw.strip(): continue
            try: row=json.loads(raw.decode('utf-8','ignore'))
            except Exception: continue
            if not isinstance(row,dict): continue
            execution=str(row.get('execution_cost_key') or '').strip()
            if not execution: continue
            sealed={k:row.get(k) for k in keep_fields}
            sealed.update(_performance_normalize_cost_observation(row))
            observations[execution]=sealed
            rows_read+=1
    by_identity={}; state_counts=Counter(); identity_source_counts=Counter(); conflict_counts=Counter(); decision_source_counts=Counter()
    observation_identity_counts=Counter()
    for row in observations.values():
        if not isinstance(row,dict): continue
        state=str(row.get('measurement_state') or 'unknown'); state_counts[state]+=1
        exact=_performance_cost_exact_identity(row)
        decision_source_counts[str(exact.get('decision_source') or 'missing')]+=1
        if exact.get('conflict'):
            for reason in exact.get('conflict_reasons') or ['unknown_conflict']:
                conflict_counts[str(reason)]+=1
            continue
        aliases=[]
        candidate=str(exact.get('candidate') or '').strip(); decision=str(exact.get('decision') or '').strip(); pos=str(exact.get('pos_id') or '').strip()
        if candidate: aliases.append(('candidate:'+candidate.removeprefix('candidate:'),'candidate_entry_build_key'))
        if decision: aliases.append(('decision:'+decision.removeprefix('decision:'),str(exact.get('decision_source') or 'decision_exact')))
        if pos: aliases.append(('pos:'+pos,'pos_id_exact'))
        observation_identity_counts[len(aliases)]+=1
        for key,source in aliases:
            canonical={
                'measurement_state':state,
                'exchange_confirmed':bool(row.get('exchange_confirmed')),
                'canonical_signed_pct':_quality_optional_num(row.get('canonical_signed_pct')),
                'canonical_cost_pct':_quality_optional_num(row.get('canonical_cost_pct')),
                'canonical_numeric_ready':bool(row.get('canonical_numeric_ready')),
                'paper_opened_at':_quality_optional_num(row.get('paper_opened_at')),
                '_performance_identity_key':key,
                '_performance_identity_source':source,
                '_performance_decision_key':decision or None,
                '_performance_candidate_key':candidate or None,
            }
            if canonical['canonical_cost_pct'] is None and canonical['canonical_signed_pct'] is not None:
                canonical['canonical_cost_pct']=max(0.0,float(canonical['canonical_signed_pct']))
            canonical['canonical_numeric_ready']=bool(canonical['canonical_signed_pct'] is not None or canonical['canonical_cost_pct'] is not None)
            prior=by_identity.get(key)
            if _performance_cost_prefer(canonical,prior):
                by_identity[key]=canonical
            identity_source_counts[source]+=1
    identity_state_counts=Counter(str(r.get('measurement_state') or 'unknown') for r in by_identity.values() if isinstance(r,dict))
    identity_numeric_counts=Counter('ready' if bool(r.get('canonical_numeric_ready')) else 'missing' for r in by_identity.values() if isinstance(r,dict))
    contract_errors=sum(1 for r in observations.values() if isinstance(r,dict) and _performance_cost_state_rank(r)>=30 and not bool(r.get('canonical_numeric_ready')))
    write=bool(rebuild or rows_read or not PERFORMANCE_COST_INDEX.exists())
    index={
        'schema':'performance_cost_index_v967','version':VERSION,'numeric_contract':'canonical_numeric_v967','updated_ts':nowv,
        'ledger_size_bytes':consumed_size,'ledger_file_size_bytes':current_size,'ledger_inode':current_inode,'ledger_mtime_ns':current_mtime_ns,
        'ledger_rows':len(observations),'observations':observations,
        'identity_contract':'raw cost row -> one canonical numeric payload -> exact candidate/decision/pos aliases; consumers never read raw numeric fields',
    }
    if write: save_json(PERFORMANCE_COST_INDEX,index)
    meta={
        'rebuilt':rebuild,'rebuild_reason':'schema_or_file_change' if rebuild else 'none','incremental_rows':rows_read,
        'ledger_rows':len(observations),'ledger_size_bytes':consumed_size,'ledger_file_size_bytes':current_size,
        'partial_tail_bytes':partial_tail_bytes,'index_write_this_cycle':write,'state_counts':dict(state_counts),
        'exact_identity_rows':len(by_identity),'confirmed_exact_identity_rows':sum(1 for r in by_identity.values() if _performance_cost_state_rank(r)>=30),
        'identity_state_counts':dict(identity_state_counts),'identity_source_counts':dict(identity_source_counts),
        'decision_source_counts':dict(decision_source_counts),'identity_numeric_counts':dict(identity_numeric_counts),'numeric_contract_errors':contract_errors,
        'identity_conflicts':sum(conflict_counts.values()),'identity_conflict_counts':dict(conflict_counts),'observation_alias_count_distribution':dict(observation_identity_counts),
        'numeric_join_policy':'exact aliases are tried in order; a matched alias without canonical numeric values is skipped, not counted as a cost connection',
    }
    return {'by_identity':by_identity,'state_counts':dict(state_counts),'ledger_rows':len(observations)},meta


def _performance_canonical_cost_values(cost_row: Optional[Dict[str, Any]]) -> Dict[str, Any]:
    """The only downstream numeric cost consumer."""
    if not isinstance(cost_row,dict):
        return {'ready':False,'signed':None,'cost':None,'state':'','reason':'no_exact_cost'}
    signed=_quality_optional_num(cost_row.get('canonical_signed_pct'))
    cost=_quality_optional_num(cost_row.get('canonical_cost_pct'))
    if cost is None and signed is not None:
        cost=max(0.0,float(signed))
    ready=bool(cost_row.get('canonical_numeric_ready') and (signed is not None or cost is not None))
    return {
        'ready':ready,'signed':signed,'cost':cost,
        'state':str(cost_row.get('measurement_state') or ''),
        'reason':'canonical_numeric_ready' if ready else 'canonical_numeric_missing',
    }


def _performance_cost_for_record(rec: Dict[str, Any], cost_context: Dict[str, Any]) -> tuple[Optional[Dict[str, Any]], str]:
    by_identity=cost_context.get('by_identity') if isinstance(cost_context,dict) and isinstance(cost_context.get('by_identity'),dict) else {}
    candidates=[]
    event=str(rec.get('quality_event_key_v946') or '').strip()
    decision=str(rec.get('minimal_gate_decision_key_v925') or '').strip()
    candidate=str(rec.get('entry_build_key') or '').strip()
    if event.startswith('decision:') or event.startswith('candidate:'):
        candidates.append((event,'quality_event_exact'))
    if decision:
        key='decision:'+decision.removeprefix('decision:')
        if key not in [x[0] for x in candidates]: candidates.append((key,'decision_key_exact'))
    if candidate:
        key='candidate:'+candidate.removeprefix('candidate:')
        if key not in [x[0] for x in candidates]: candidates.append((key,'candidate_key_exact'))
    matched_missing=[]
    for key,mode in candidates:
        row=by_identity.get(key)
        if not isinstance(row,dict):
            continue
        canonical=_performance_canonical_cost_values(row)
        if not canonical.get('ready'):
            matched_missing.append(key)
            continue
        matched=dict(row); matched['_performance_match_key']=key; matched['_performance_match_mode']=mode
        return matched,mode
    if not candidates:
        return None,'quality_record_exact_key_missing'
    if matched_missing:
        return None,'exact_key_numeric_missing:'+'|'.join(matched_missing[:3])
    return None,'missing_exact_cost_key'


def _performance_quality_rows(records: List[Dict[str, Any]], horizon: str, cost_context: Optional[Dict[str, Any]]=None) -> List[Dict[str, Any]]:
    rows=[]
    for rec in records:
        if not isinstance(rec,dict): continue
        sample=(rec.get('samples') or {}).get(horizon) if isinstance(rec.get('samples'),dict) else None
        if not isinstance(sample,dict): continue
        pct=_quality_optional_num(sample.get('pct'))
        if pct is None: continue
        metrics=rec.get('initial_metrics') if isinstance(rec.get('initial_metrics'),dict) else {}
        event_context=rec.get('event_context') if isinstance(rec.get('event_context'),dict) else _legacy_missing_event_context()
        price=_quality_optional_num(rec.get('first_price'),metrics.get('first_price')) or 0.0
        spread=_quality_optional_num(metrics.get('spread_pct'))
        slip=_quality_optional_num(metrics.get('confirmed_slippage_pct'))
        slip_source=str(metrics.get('confirmed_slippage_source') or '').lower()
        cost_row,cost_join_mode=_performance_cost_for_record(rec,cost_context if isinstance(cost_context,dict) else {})
        signed_reference=None
        canonical_cost=_performance_canonical_cost_values(cost_row)
        # Exact canonical cost has priority over every legacy row-local slippage field.
        # The old order classified derived_from_spread first, so an exact numeric match
        # was counted as connected while its numeric value was deliberately discarded.
        if isinstance(cost_row,dict) and str(cost_row.get('measurement_state') or '')=='paper_reference_confirmed' and canonical_cost.get('ready'):
            slip_class='paper_reference'
            signed_reference=canonical_cost.get('signed')
            usable_slip=canonical_cost.get('cost')
            slip_source='paper_execution_cost_ledger_canonical'
        elif slip is not None and any(x in slip_source for x in ('exchange','average_fill','actual_fill')):
            slip_class='exchange_confirmed'; usable_slip=slip
        elif 'derived_from_spread' in slip_source:
            slip_class='legacy_derived'; usable_slip=None
        elif slip is not None and any(x in slip_source for x in ('paper_reference','best_ask_reference')):
            slip_class='paper_reference'; signed_reference=slip; usable_slip=max(0.0,float(slip))
        else:
            slip_class='missing'; usable_slip=None
        occurrence=str(rec.get('hot_watch_occurrence_key_v945') or '').strip()
        regime=str(event_context.get('market_regime') or 'context_missing')
        if regime not in ('up_or_strong','down_or_weak','sideways_or_neutral','context_missing'): regime='context_missing'
        turnover=_quality_optional_num(event_context.get('turnover_24h'))
        volume_ratio=_quality_optional_num(event_context.get('volume_ratio'))
        if turnover is None and volume_ratio is None: volume_state='context_missing'
        elif (volume_ratio is not None and volume_ratio>=1.2) or (turnover is not None and turnover>=400_000_000): volume_state='strong_or_high'
        elif turnover is not None and turnover<250_000_000: volume_state='low_turnover'
        else: volume_state='normal'
        if price<100: price_band='low_under_100'
        elif price<1000: price_band='mid_100_999'
        else: price_band='high_1000_plus'
        tick_pct=_performance_tick_pct(price)
        rows.append({
            'event_key':str(rec.get('quality_event_key_v946') or ''),'identity_mode':str(rec.get('identity_mode_v946') or ''),
            'ticker':ticker_norm(rec.get('ticker')),'occurrence':occurrence,'cohort':str(rec.get('cohort') or 'unknown'),
            'pct':pct,'max_pct':_quality_optional_num(sample.get('max_pct')),'min_pct':_quality_optional_num(sample.get('min_pct')),
            'giveback_pct':_quality_optional_num(sample.get('giveback_pct')),'first_seen_ts':_quality_optional_num(rec.get('first_seen_ts')),
            'spread_pct':spread,'slippage_pct':usable_slip,'paper_reference_signed_pct':signed_reference,'slippage_class':slip_class,'slippage_source':slip_source,'cost_join_mode':cost_join_mode,
            'cost_measurement_state':str(cost_row.get('measurement_state') or 'no_exact_cost') if isinstance(cost_row,dict) else 'no_exact_cost',
            'cost_identity_source':str(cost_row.get('_performance_identity_source') or 'none') if isinstance(cost_row,dict) else 'none',
            'cost_numeric_reason':(_performance_canonical_cost_values(cost_row).get('reason') if isinstance(cost_row,dict) else 'no_exact_cost'),
            'spread_net_pct':pct-(spread or 0.0),
            'reference_net_pct':pct-(spread or 0.0)-(usable_slip or 0.0) if slip_class in ('exchange_confirmed','paper_reference') else None,
            'confirmed_net_pct':pct-(spread or 0.0)-(usable_slip or 0.0) if slip_class=='exchange_confirmed' else None,
            'fee_pct':None,'regime':regime,'market_context_source':event_context.get('market_context_source') or 'legacy_context_missing','hot_state':'hot_occurrence' if occurrence else 'general_market',
            'volume_state':volume_state,'turnover_24h':turnover,'volume_ratio':volume_ratio,
            'price_band':price_band,'distortion':bool(tick_pct>=0.50 or abs(pct)>=15.0),'tick_pct':tick_pct,
            'scanner_to_candidate_sec':_quality_optional_num(metrics.get('scanner_to_candidate_sec')),
            'scanner_to_s2_sec':_quality_optional_num(metrics.get('scanner_to_s2_sec')),
            'scanner_to_s1_sec':_quality_optional_num(metrics.get('scanner_to_s1_sec')),
        })
    return rows


def _performance_group_stats(rows: List[Dict[str, Any]]) -> Dict[str, Any]:
    vals=[float(r['pct']) for r in rows if isinstance(r.get('pct'),(int,float))]
    if not vals: return {'n':0}
    clean=[float(r['pct']) for r in rows if isinstance(r.get('pct'),(int,float)) and not r.get('distortion')]
    spread_net=[float(r['spread_net_pct']) for r in rows if isinstance(r.get('spread_net_pct'),(int,float))]
    ref_net=[float(r['reference_net_pct']) for r in rows if isinstance(r.get('reference_net_pct'),(int,float))]
    confirmed_net=[float(r['confirmed_net_pct']) for r in rows if isinstance(r.get('confirmed_net_pct'),(int,float))]
    tickers=Counter(str(r.get('ticker') or '-') for r in rows)
    occurrences={str(r.get('occurrence')) for r in rows if str(r.get('occurrence') or '').strip()}
    by_ticker={}
    by_occ={}
    for row in sorted(rows,key=lambda r:(_quality_optional_num(r.get('first_seen_ts')) or 0.0,str(r.get('event_key') or ''))):
        ticker=str(row.get('ticker') or '')
        occ=str(row.get('occurrence') or '')
        if ticker and ticker not in by_ticker: by_ticker[ticker]=row
        if occ and occ not in by_occ: by_occ[occ]=row
    ticker_vals=[float(r['pct']) for r in by_ticker.values() if isinstance(r.get('pct'),(int,float))]
    occ_vals=[float(r['pct']) for r in by_occ.values() if isinstance(r.get('pct'),(int,float))]
    top_share=tickers.most_common(1)[0][1]/len(rows) if rows and tickers else 0.0
    trust='WAITING'
    if len(clean)>=30 and len(tickers)>=20 and top_share<=0.20: trust='REFERENCE'
    if len(clean)>=100 and len(tickers)>=40 and top_share<=0.12: trust='TRUSTED'
    return {
        'n':len(vals),'avg_pct':round(sum(vals)/len(vals),4),'median_pct':round(_quality_percentile(vals,0.50),4),
        'trimmed_avg_pct':round(_sample_trimmed_mean(vals) or 0.0,4),
        'clean_n':len(clean),'clean_avg_pct':round(sum(clean)/len(clean),4) if clean else None,
        'unique_tickers':len(tickers),'unique_occurrences':len(occurrences),
        'unique_ticker_avg_pct':round(sum(ticker_vals)/len(ticker_vals),4) if ticker_vals else None,
        'unique_occurrence_avg_pct':round(sum(occ_vals)/len(occ_vals),4) if occ_vals else None,
        'spread_net_avg_pct':round(sum(spread_net)/len(spread_net),4) if spread_net else None,
        'reference_net_n':len(ref_net),'reference_net_avg_pct':round(sum(ref_net)/len(ref_net),4) if ref_net else None,
        'confirmed_net_n':len(confirmed_net),'confirmed_net_avg_pct':round(sum(confirmed_net)/len(confirmed_net),4) if confirmed_net else None,
        'winner_0_5_count':sum(1 for v in vals if v>=0.5),'loser_minus_0_1_count':sum(1 for v in vals if v<=-0.1),
        'distortion_count':sum(1 for r in rows if r.get('distortion')),'top_ticker_share_pct':round(top_share*100.0,2),
        'trust':trust,
    }


def _performance_quality_analysis(records: List[Dict[str, Any]], quality_status: Dict[str, Any], cost_context: Optional[Dict[str, Any]]=None) -> Dict[str, Any]:
    horizon_rows={label:_performance_quality_rows(records,label,cost_context) for label in ('1m','3m','5m','10m','20m','60m')}
    blocked={}
    cohorts=sorted({str(r.get('cohort') or 'unknown') for r in records if str(r.get('cohort') or '')!='s1_pass'})
    for cohort in cohorts:
        item={}
        for horizon in ('10m','60m'):
            rows=[r for r in horizon_rows[horizon] if r.get('cohort')==cohort]
            stats=_performance_group_stats(rows)
            if stats.get('n'): item[horizon]=stats
        if item: blocked[cohort]=item
    s1_1=[r for r in horizon_rows['1m'] if r.get('cohort')=='s1_pass']
    s1_10=[r for r in horizon_rows['10m'] if r.get('cohort')=='s1_pass']
    m10_by_key={r.get('event_key'):r for r in s1_10}
    adverse=[r for r in s1_1 if float(r.get('pct') or 0.0)<=-0.1]
    recovered=sum(1 for r in adverse if isinstance((m10_by_key.get(r.get('event_key')) or {}).get('pct'),(int,float)) and float((m10_by_key.get(r.get('event_key')) or {}).get('pct'))>=0.1)
    persistent=sum(1 for r in adverse if isinstance((m10_by_key.get(r.get('event_key')) or {}).get('pct'),(int,float)) and float((m10_by_key.get(r.get('event_key')) or {}).get('pct'))<=-0.1)
    giveback=[r for r in s1_10 if isinstance(r.get('max_pct'),(int,float)) and isinstance(r.get('pct'),(int,float)) and float(r.get('max_pct'))-float(r.get('pct'))>=0.5]
    passed={
        's1_1m':_performance_group_stats(s1_1),'s1_10m':_performance_group_stats(s1_10),
        'immediate_adverse_count':len(adverse),'recovered_positive_by_10m':recovered,'persistent_negative_10m':persistent,
        'giveback_0_5_count':len(giveback),'positive_to_negative_count':sum(1 for r in giveback if float(r.get('max_pct') or 0)>0.2 and float(r.get('pct') or 0)<0),
        'adverse_samples':[{k:r.get(k) for k in ('ticker','event_key','pct','min_pct','occurrence')} for r in sorted(adverse,key=lambda x:float(x.get('pct') or 0))[:5]],
        'giveback_samples':[{**{k:r.get(k) for k in ('ticker','event_key','pct','max_pct','giveback_pct')},'observed_giveback_pct':round(float(r.get('max_pct'))-float(r.get('pct')),4)} for r in sorted(giveback,key=lambda x:float(x.get('max_pct') or 0)-float(x.get('pct') or 0),reverse=True)[:5]],
    }
    market={}
    for horizon in ('10m','60m'):
        rows=horizon_rows[horizon]; splits={}
        for field in ('regime','hot_state','volume_state','price_band'):
            split={}
            for value in sorted({str(r.get(field) or 'unknown') for r in rows}):
                stats=_performance_group_stats([r for r in rows if str(r.get(field) or 'unknown')==value])
                if stats.get('n'): split[value]=stats
            splits[field]=split
        market[horizon]=splits
    all10=horizon_rows['10m']; slip_counts=Counter(str(r.get('slippage_class') or 'missing') for r in all10)
    exact_modes=Counter(str(r.get('identity_mode_v946') or 'unknown') for r in records)
    market_context_counts=Counter(str(r.get('regime') or 'context_missing') for r in all10)
    market_source_counts=Counter(str(r.get('market_context_source') or 'legacy_context_missing') for r in all10)
    volume_context_counts=Counter(str(r.get('volume_state') or 'context_missing') for r in all10)
    cost_join_counts=Counter(str(r.get('cost_join_mode') or 'missing_exact_cost_key') for r in all10)
    cost_measurement_state_counts=Counter(str(r.get('cost_measurement_state') or 'no_exact_cost') for r in all10)
    cost_identity_source_counts=Counter(str(r.get('cost_identity_source') or 'none') for r in all10)
    cost_numeric_state_counts=Counter(str(r.get('cost_numeric_reason') or 'no_exact_cost') for r in all10)
    paper_reference_numeric_rows=sum(1 for r in all10 if str(r.get('slippage_class') or '')=='paper_reference' and isinstance(r.get('reference_net_pct'),(int,float)))
    # A cost connection exists only when the same canonical row supplied a number.
    # State-only alias matches remain diagnostics and are never reported as connected.
    paper_reference_connected_rows=paper_reference_numeric_rows
    tracked_market_sealed=0; tracked_turnover_sealed=0
    for rec in records:
        event_context=rec.get('event_context') if isinstance(rec,dict) and isinstance(rec.get('event_context'),dict) else _legacy_missing_event_context()
        if event_context.get('market_context_sealed') is True: tracked_market_sealed+=1
        if event_context.get('turnover_context_sealed') is True: tracked_turnover_sealed+=1
    return {
        'tracked_records':len(records),'quality_exact_ready':int(quality_status.get('exact_key_ready') or 0),
        'quality_exact_missing':int(quality_status.get('exact_key_missing') or 0),'identity_modes':dict(exact_modes),
        'blocked_winners':blocked,'passed_losers':passed,'market_splits':market,'context_connection':{'tracked_records':len(records),'tracked_market_sealed':tracked_market_sealed,'tracked_market_missing':max(0,len(records)-tracked_market_sealed),'tracked_turnover_sealed':tracked_turnover_sealed,'tracked_turnover_missing':max(0,len(records)-tracked_turnover_sealed),'market_counts':dict(market_context_counts),'market_source_counts':dict(market_source_counts),'volume_counts':dict(volume_context_counts),'cost_join_counts':dict(cost_join_counts),'cost_measurement_state_counts':dict(cost_measurement_state_counts),'cost_identity_source_counts':dict(cost_identity_source_counts),'cost_numeric_state_counts':dict(cost_numeric_state_counts),'paper_reference_connected_rows':paper_reference_connected_rows,'paper_reference_numeric_rows':paper_reference_numeric_rows,'paper_reference_missing_numeric_rows':max(0,paper_reference_connected_rows-paper_reference_numeric_rows),'legacy_market_context_missing':market_context_counts.get('context_missing',0),'legacy_volume_context_missing':volume_context_counts.get('context_missing',0),'event_context_migrated_this_cycle':int(quality_status.get('event_context_migrated_this_cycle') or 0),'event_context_migration':quality_status.get('event_context_migration') if isinstance(quality_status.get('event_context_migration'),dict) else {}},
        'cost':{
            'ten_minute':_performance_group_stats(all10),'slippage_source_counts':dict(slip_counts),
            'exchange_confirmed_slippage_rows':slip_counts.get('exchange_confirmed',0),
            'paper_reference_slippage_rows':slip_counts.get('paper_reference',0),
            'paper_reference_connected_rows':paper_reference_connected_rows,
            'paper_reference_numeric_rows':paper_reference_numeric_rows,
            'paper_reference_missing_numeric_rows':max(0,paper_reference_connected_rows-paper_reference_numeric_rows),
            'legacy_derived_rows':slip_counts.get('legacy_derived',0),'missing_slippage_rows':slip_counts.get('missing',0),
            'fee_source_status':PERFORMANCE_FEE_SOURCE_STATUS,'confirmed_net_ready':bool(slip_counts.get('exchange_confirmed',0)) and False,
            'policy':'gross, spread-only and paper-reference cost are separated; confirmed net waits for exchange fill slippage and exact fee source',
        },
        'blocked_samples':[
            {k:r.get(k) for k in ('ticker','event_key','cohort','pct','max_pct','min_pct','giveback_pct','occurrence')}
            for r in sorted([r for r in all10 if r.get('cohort')!='s1_pass' and float(r.get('pct') or 0)>=0.5],key=lambda x:float(x.get('pct') or 0),reverse=True)[:8]
        ],
    }


def _performance_sources(row: Dict[str, Any]) -> List[Dict[str, Any]]:
    if not isinstance(row,dict): return []
    out=[row]
    for key in ('quality_evidence_v938','quality_evidence_v936','entry_diagnostics','paper_timing_spine_v940','closed_exact_v926'):
        obj=row.get(key)
        if isinstance(obj,dict):
            out.append(obj)
            for nested_key in ('quality_evidence_v938','quality_evidence_v936','paper_timing_spine_v940'):
                nested=obj.get(nested_key)
                if isinstance(nested,dict): out.append(nested)
    return out


def _performance_first(row: Dict[str, Any], keys: tuple[str,...]) -> Any:
    for source in _performance_sources(row):
        for key in keys:
            value=source.get(key)
            if value not in (None,'',[],{}): return value
    return None


def _performance_exact_key(row: Dict[str, Any]) -> str:
    value=_performance_first(row,('paper_decision_key_v926','minimal_gate_decision_key_v925','decision_key'))
    return str(value or '').strip()


def _performance_pos_id(row: Dict[str, Any]) -> str:
    value=_performance_first(row,('pos_id','paper_pos_id_v926'))
    return str(value or '').strip()


CLEAN_SCORE_CUTOVER_TS = 1782093476.0  # 2026-06-22 10:57:56 Asia/Seoul
CLEAN_SCORE_CUTOVER_LABEL = 'v970_clean_open_after_canonical_closed_runtime'


def performance_open_timestamp(row: Dict[str, Any]) -> float:
    for source in _performance_sources(row):
        for key in ('opened_at', 'opened_ts', 'open_ts', 'entry_open_ts'):
            try:
                value = source.get(key)
                if value not in (None, '', [], {}):
                    ts = float(value)
                    if ts > 10_000_000_000:
                        ts /= 1000.0
                    if ts > 0:
                        return ts
            except Exception:
                continue
    return 0.0


def performance_row_is_clean(row: Dict[str, Any]) -> bool:
    return performance_open_timestamp(row) >= CLEAN_SCORE_CUTOVER_TS


def _performance_closed_analysis() -> Dict[str, Any]:
    decision_obj=load_json(PAPER_DECISION_STATE,{}) or {}
    decision_raw=decision_obj.get('records') if isinstance(decision_obj,dict) and isinstance(decision_obj.get('records'),dict) else {}
    decisions=[]
    for key,row in decision_raw.items():
        if not isinstance(row,dict): continue
        rr=dict(row); rr.setdefault('paper_decision_key_v926',str(key)); decisions.append(rr)
    # A CLOSED ledger append is not a completed exact result until the same decision is sealed CLOSED.
    closed_decisions=[r for r in decisions if str(r.get('status') or '').upper()=='CLOSED']
    by_key={_performance_exact_key(r):r for r in closed_decisions if _performance_exact_key(r)}
    by_pos={_performance_pos_id(r):r for r in closed_decisions if _performance_pos_id(r)}
    closed_rows_raw=read_jsonl(CLOSED,max_lines=3000)
    excluded_before_cutover=0; excluded_missing_open_ts=0
    closed_rows=[]
    for row in closed_rows_raw:
        if not isinstance(row,dict):
            continue
        opened=performance_open_timestamp(row)
        if opened <= 0:
            excluded_missing_open_ts += 1
            continue
        if opened < CLEAN_SCORE_CUTOVER_TS:
            excluded_before_cutover += 1
            continue
        closed_rows.append(row)
    matched=[]; direct=0; pos_match=0
    for row in closed_rows:
        if not isinstance(row,dict): continue
        source=str(row.get('source') or row.get('closed_source') or '').lower()
        if 'alert_trace_recovered' in source or row.get('reconciled_from_close_alert_trace'): continue
        key=_performance_exact_key(row); pos=_performance_pos_id(row); mode=''
        decision=by_key.get(key) if key else None
        if decision is not None: mode='decision_key_exact'; direct+=1
        elif pos and pos in by_pos: decision=by_pos[pos]; mode='sealed_pos_id'; pos_match+=1
        if decision is None: continue
        pnl=_quality_optional_num(_performance_first(row,('net_pct','result_pct','pnl_pct','return_pct','profit_pct')))
        peak=_quality_optional_num(_performance_first(row,('gross_peak_pct','peak_profit_pct','peak_pct','max_profit_pct')))
        trough=_quality_optional_num(_performance_first(row,('gross_trough_pct','trough_pct','min_profit_pct','max_loss_pct')))
        matched.append({'key':key or _performance_exact_key(decision),'pos_id':pos,'match_mode':mode,'pnl_pct':pnl,'peak_pct':peak,'trough_pct':trough,'giveback_pct':peak-pnl if peak is not None and pnl is not None else None})
    pnl=[float(r['pnl_pct']) for r in matched if isinstance(r.get('pnl_pct'),(int,float))]
    wins=[v for v in pnl if v>0]; losses=[v for v in pnl if v<=0]
    avg_win=sum(wins)/len(wins) if wins else None; avg_loss=sum(losses)/len(losses) if losses else None
    payoff=(avg_win/abs(avg_loss)) if avg_win is not None and avg_loss not in (None,0) else None
    return {
        'state':'ACTIVE' if pnl else 'WAITING_FIRST_CLEAN_EXACT_CLOSED','decision_records':len(decisions),'closed_rows_seen':len(closed_rows),
        'raw_closed_rows_seen':len(closed_rows_raw),'score_cutover_schema':'performance_clean_open_cutover_v971',
        'score_cutover_ts':CLEAN_SCORE_CUTOVER_TS,'score_cutover_text':'2026-06-22 10:57:56 KST',
        'score_cutover_label':CLEAN_SCORE_CUTOVER_LABEL,'score_cutover_basis':'opened_at_not_closed_at',
        'excluded_before_cutover':excluded_before_cutover,'excluded_missing_open_ts':excluded_missing_open_ts,
        'matched_results':len(matched),'decision_key_exact':direct,'sealed_pos_id':pos_match,'ticker_match_used':0,
        'wins':len(wins),'losses':len(losses),'win_rate_pct':round(len(wins)/len(pnl)*100.0,2) if pnl else None,
        'avg_pnl_pct':round(sum(pnl)/len(pnl),4) if pnl else None,'avg_win_pct':round(avg_win,4) if avg_win is not None else None,
        'avg_loss_pct':round(avg_loss,4) if avg_loss is not None else None,'payoff_ratio':round(payoff,4) if payoff is not None else None,
        'expectancy_pct':round(sum(pnl)/len(pnl),4) if pnl else None,
        'avg_giveback_pct':round(sum(float(r['giveback_pct']) for r in matched if isinstance(r.get('giveback_pct'),(int,float)))/sum(1 for r in matched if isinstance(r.get('giveback_pct'),(int,float))),4) if any(isinstance(r.get('giveback_pct'),(int,float)) for r in matched) else None,
        'matched_exact_keys':[('decision:'+str(r.get('key')).removeprefix('decision:')) for r in matched if str(r.get('key') or '').strip()][:1000],
        'policy':'decision status CLOSED required; decision key exact first, sealed pos_id second, ticker never finalizes CLOSED result',
    }


def _performance_normalize_structure_identity_v962(value: Any) -> str:
    text=str(value or '').strip()
    if not text:
        return ''
    if text.startswith('decision:') or text.startswith('candidate:'):
        return text
    if text.startswith('market:') or '|plan:' in text:
        return 'decision:'+text
    return 'candidate:'+text

def _performance_refresh_c_shadow_index_v962(nowv: float) -> tuple[Dict[str, Any], Dict[str, Any]]:
    if STRUCTURE_LAB_HORIZON_LEDGER.exists():
        stat=STRUCTURE_LAB_HORIZON_LEDGER.stat(); current_size=stat.st_size; current_inode=stat.st_ino; current_mtime_ns=stat.st_mtime_ns
    else:
        current_size=0; current_inode=0; current_mtime_ns=0
    loaded=load_json(PERFORMANCE_C_SHADOW_INDEX,{})
    valid=isinstance(loaded,dict) and loaded.get('schema')=='performance_c_break_retest_shadow_index_v962' and isinstance(loaded.get('observations'),dict)
    start=int(loaded.get('ledger_size_bytes') or 0) if valid else 0
    replaced=bool(valid and int(loaded.get('ledger_inode') or 0) and current_inode and int(loaded.get('ledger_inode') or 0)!=current_inode)
    same_size_rewritten=bool(valid and current_size==start and int(loaded.get('ledger_mtime_ns') or 0) and int(loaded.get('ledger_mtime_ns') or 0)!=current_mtime_ns)
    rebuild=(not valid) or start<0 or start>current_size or replaced or same_size_rewritten
    observations={} if rebuild else dict(loaded.get('observations') or {})
    legacy_missing=0 if rebuild else int(loaded.get('legacy_identity_missing_rows') or 0)
    if rebuild:
        start=0
    rows_read=0; c_rows_read=0; exact_rows_added=0; consumed_size=start; partial_tail_bytes=0
    if current_size>start:
        with STRUCTURE_LAB_HORIZON_LEDGER.open('rb') as handle:
            handle.seek(start); data=handle.read()
        if data.endswith(b'\n'):
            complete=data
        else:
            last=data.rfind(b'\n'); complete=data[:last+1] if last>=0 else b''; partial_tail_bytes=len(data)-len(complete)
        consumed_size=start+len(complete)
        for raw in complete.splitlines():
            if not raw.strip():
                continue
            try:
                row=json.loads(raw.decode('utf-8','ignore'))
            except Exception:
                continue
            if not isinstance(row,dict):
                continue
            rows_read+=1
            if str(row.get('method') or '')!='C_BREAK_RETEST':
                continue
            c_rows_read+=1
            identity=_performance_normalize_structure_identity_v962(row.get('candidate_exact_identity'))
            if not identity:
                legacy_missing+=1
                continue
            result_key=str(row.get('result_key') or (str(row.get('event_key') or '')+'|'+str(row.get('horizon') or ''))).strip()
            if not result_key:
                continue
            observations[result_key]={
                'result_key':result_key,'event_key':row.get('event_key'),'ticker':row.get('ticker'),'horizon':row.get('horizon'),
                'candidate_exact_identity':identity,'event_ts':row.get('event_ts'),'entry_price':row.get('entry_price'),
                'pct':row.get('pct'),'max_pct':row.get('max_pct'),'min_pct':row.get('min_pct'),'giveback_pct':row.get('giveback_pct'),
                'first_terminal':row.get('first_terminal'),'invalid_ts':row.get('invalid_ts'),'target_ts':row.get('target_ts'),
            }
            exact_rows_added+=1
    write=bool(rebuild or rows_read or not PERFORMANCE_C_SHADOW_INDEX.exists())
    index={
        'schema':'performance_c_break_retest_shadow_index_v962','version':VERSION,'updated_ts':nowv,
        'ledger_size_bytes':consumed_size,'ledger_file_size_bytes':current_size,'ledger_inode':current_inode,'ledger_mtime_ns':current_mtime_ns,
        'observations':observations,'legacy_identity_missing_rows':legacy_missing,
        'policy':'C_BREAK_RETEST only; future structure horizon rows carry candidate exact identity; legacy missing is never ticker/time-near joined',
    }
    if write:
        save_json(PERFORMANCE_C_SHADOW_INDEX,index)
    return index,{
        'rebuilt':rebuild,'incremental_rows':rows_read,'c_rows_read':c_rows_read,'exact_rows_added':exact_rows_added,
        'exact_observation_rows':len(observations),'legacy_identity_missing_rows':legacy_missing,'index_write_this_cycle':write,
        'ledger_size_bytes':consumed_size,'partial_tail_bytes':partial_tail_bytes,
    }

def _performance_quality_alias_map_v962(records: List[Dict[str, Any]]) -> Dict[str, Dict[str, Any]]:
    aliases={}
    for rec in records:
        if not isinstance(rec,dict):
            continue
        keys=[]
        event=str(rec.get('quality_event_key_v946') or '').strip()
        if event:
            keys.append(event)
        decision=str(rec.get('minimal_gate_decision_key_v925') or '').strip()
        candidate=str(rec.get('entry_build_key') or '').strip()
        if decision:
            keys.append('decision:'+decision.removeprefix('decision:'))
        if candidate:
            keys.append('candidate:'+candidate.removeprefix('candidate:'))
        for key in keys:
            if key and key not in aliases:
                aliases[key]=rec
    return aliases

def _performance_c_shadow_analysis_v962(index: Dict[str, Any], quality_records: List[Dict[str, Any]], cost_context: Dict[str, Any], structure: Dict[str, Any], closed: Dict[str, Any]) -> Dict[str, Any]:
    observations=index.get('observations') if isinstance(index,dict) and isinstance(index.get('observations'),dict) else {}
    quality_map=_performance_quality_alias_map_v962(quality_records)
    exact_rows=[]; s1_rows=[]; quality_joined=0; terminal_counts=Counter(); identity_modes=Counter()
    exact_identity_keys=set(); quality_joined_identities=set(); s1_identity_keys=set(); cost_connected_identities=set(); exchange_connected_identities=set(); terminal_seen_events=set()
    for obs in observations.values():
        if not isinstance(obs,dict):
            continue
        identity=str(obs.get('candidate_exact_identity') or '').strip()
        if not identity:
            continue
        exact_identity_keys.add(identity)
        quality_rec=quality_map.get(identity)
        if isinstance(quality_rec,dict):
            quality_joined+=1
            quality_joined_identities.add(identity)
            identity_modes[str(quality_rec.get('identity_mode_v946') or 'unknown')]+=1
        pct=_quality_optional_num(obs.get('pct'))
        if pct is None:
            continue
        price=_quality_optional_num(obs.get('entry_price')) or 0.0
        row={
            'event_key':obs.get('event_key'),'ticker':ticker_norm(obs.get('ticker')),'occurrence':obs.get('event_key'),
            'pct':pct,'max_pct':_quality_optional_num(obs.get('max_pct')),'min_pct':_quality_optional_num(obs.get('min_pct')),
            'giveback_pct':_quality_optional_num(obs.get('giveback_pct')),'first_seen_ts':_quality_optional_num(obs.get('event_ts')),
            'distortion':bool(_performance_tick_pct(price)>=0.50 or abs(pct)>=15.0),'horizon':str(obs.get('horizon') or ''),
            'reference_net_pct':None,'confirmed_net_pct':None,'spread_net_pct':pct,
        }
        exact_rows.append(row)
        terminal_event=str(obs.get('event_key') or '')
        if terminal_event not in terminal_seen_events:
            terminal_seen_events.add(terminal_event)
            terminal_counts[str(obs.get('first_terminal') or 'unknown')]+=1
        if isinstance(quality_rec,dict) and str(quality_rec.get('cohort') or '')=='s1_pass':
            s1_identity_keys.add(identity)
            metrics=quality_rec.get('initial_metrics') if isinstance(quality_rec.get('initial_metrics'),dict) else {}
            spread=_quality_optional_num(metrics.get('spread_pct')) or 0.0
            row=dict(row); row['spread_net_pct']=pct-spread
            cost_row,_mode=_performance_cost_for_record(quality_rec,cost_context)
            canonical_cost=_performance_canonical_cost_values(cost_row)
            if isinstance(cost_row,dict) and str(cost_row.get('measurement_state') or '')=='paper_reference_confirmed' and canonical_cost.get('ready'):
                usable=float(canonical_cost.get('cost') or 0.0)
                row['reference_net_pct']=pct-spread-usable; cost_connected_identities.add(identity)
            elif isinstance(cost_row,dict) and _performance_cost_state_rank(cost_row)>=40 and canonical_cost.get('ready'):
                usable=float(canonical_cost.get('cost') or 0.0)
                row['confirmed_net_pct']=pct-spread-max(0.0,usable); exchange_connected_identities.add(identity)
            s1_rows.append(row)
    def by_horizon(rows: List[Dict[str, Any]]) -> Dict[str, Any]:
        return {h:_performance_group_stats([r for r in rows if r.get('horizon')==h]) for h in PERFORMANCE_STRUCTURE_HORIZONS}
    exact_stats=by_horizon(exact_rows); s1_stats=by_horizon(s1_rows)
    c_all=structure.get('C_BREAK_RETEST') if isinstance(structure.get('C_BREAK_RETEST'),dict) else {}
    matched_closed=set(str(x) for x in (closed.get('matched_exact_keys') or []) if str(x))
    closed_exact=len(exact_identity_keys & matched_closed)
    checks={
        's1_10m_n_30':int((s1_stats.get('10m') or {}).get('clean_n') or 0)>=30,
        's1_60m_n_30':int((s1_stats.get('60m') or {}).get('clean_n') or 0)>=30,
        's1_240m_n_30':int((s1_stats.get('240m') or {}).get('clean_n') or 0)>=30,
        's1_10m_positive':((_performance_num_v962((s1_stats.get('10m') or {}).get('clean_avg_pct')) or -999)>0),
        's1_60m_positive':((_performance_num_v962((s1_stats.get('60m') or {}).get('clean_avg_pct')) or -999)>0),
        's1_240m_positive':((_performance_num_v962((s1_stats.get('240m') or {}).get('clean_avg_pct')) or -999)>0),
        'target_more_than_invalid':int(terminal_counts.get('target') or 0)>int(terminal_counts.get('invalid') or 0),
        'paper_reference_cost_n_30':len(cost_connected_identities)>=30,
        'exchange_cost_n_30':len(exchange_connected_identities)>=30,
        'exact_closed_n_30':closed_exact>=30,
        'user_approval':False,
    }
    return {
        'schema':'c_break_retest_shadow_status_v962','target_method':'C_BREAK_RETEST','label':'C 돌파 재확인',
        'state':'COLLECTING_EXACT_C_SHADOW','observation_only':True,'same_existing_gate_only':True,
        'legacy_all_c':c_all,'exact_structure_rows':len(exact_rows),'exact_identity_count':len(exact_identity_keys),
        'quality_joined_rows':quality_joined,'quality_joined_identity_count':len(quality_joined_identities),
        's1_pass_rows':len(s1_rows),'s1_pass_identity_count':len(s1_identity_keys),'identity_modes':dict(identity_modes),
        'exact_horizons':exact_stats,'s1_same_gate_horizons':s1_stats,'terminal_counts':dict(terminal_counts),
        'paper_reference_cost_rows':sum(1 for r in s1_rows if isinstance(r.get('reference_net_pct'),(int,float))),
        'paper_reference_cost_identity_count':len(cost_connected_identities),
        'exchange_confirmed_cost_rows':sum(1 for r in s1_rows if isinstance(r.get('confirmed_net_pct'),(int,float))),
        'exchange_confirmed_cost_identity_count':len(exchange_connected_identities),'exact_closed_rows':closed_exact,
        'readiness_checks':checks,'ready_for_rule_change':False,
        'blockers':[k for k,v in checks.items() if not v],
        'policy':'C only. Existing S1 gate/trigger/RR/target room/spread/freshness are unchanged; future exact C events are compared separately from legacy C aggregate; ticker/time-near join forbidden',
    }

def _performance_num_v962(value: Any) -> Optional[float]:
    try:
        if value in (None,'','-',[],{}):
            return None
        number=float(value)
        return number if math.isfinite(number) else None
    except Exception:
        return None

def _performance_shadow_candidates(structure: Dict[str, Any], quality: Dict[str, Any], late_path: Dict[str, Any], closed: Dict[str, Any]) -> Dict[str, Any]:
    items=[]
    blocked=quality.get('blocked_winners') if isinstance(quality.get('blocked_winners'),dict) else {}
    for cohort,data in blocked.items():
        ten=data.get('10m') if isinstance(data,dict) and isinstance(data.get('10m'),dict) else {}
        if int(ten.get('clean_n') or 0)>=30 and (ten.get('clean_avg_pct') is not None) and float(ten.get('clean_avg_pct'))>=0.15:
            items.append({'type':'relax_shadow_candidate','target':cohort,'evidence':ten,'ready':False,'blocker':'confirmed cost + exact CLOSED required'})
    passed=quality.get('passed_losers') if isinstance(quality.get('passed_losers'),dict) else {}
    s1=passed.get('s1_10m') if isinstance(passed.get('s1_10m'),dict) else {}
    if int(s1.get('clean_n') or 0)>=30 and s1.get('clean_avg_pct') is not None and float(s1.get('clean_avg_pct'))<=-0.10:
        items.append({'type':'strengthen_shadow_candidate','target':'s1_pass_entry_quality','evidence':s1,'ready':False,'blocker':'first exact CLOSED required'})
    outcome=late_path.get('outcome_comparison') if isinstance(late_path,dict) and isinstance(late_path.get('outcome_comparison'),dict) else {}
    for stage,stats in outcome.items():
        if not isinstance(stats,dict): continue
        fast=stats.get('fast') if isinstance(stats.get('fast'),dict) else {}; slow=stats.get('slow') if isinstance(stats.get('slow'),dict) else {}
        if int(fast.get('n') or 0)>=20 and int(slow.get('n') or 0)>=20 and fast.get('avg_pct') is not None and slow.get('avg_pct') is not None and float(slow.get('avg_pct'))<=float(fast.get('avg_pct'))-0.15:
            items.append({'type':'delay_shadow_candidate','target':stage,'evidence':stats,'ready':False,'blocker':'occurrence age/outlier audit + exact CLOSED required'})
    # Current experiment owner is fixed to C_BREAK_RETEST. Do not auto-switch to A/B/D/E by recent average.
    c_horizons=structure.get('C_BREAK_RETEST') if isinstance(structure.get('C_BREAK_RETEST'),dict) else {}
    c_sixty=c_horizons.get('60m') if isinstance(c_horizons.get('60m'),dict) else {}
    items.append({'type':'structure_method_shadow_candidate','target':'C_BREAK_RETEST','evidence':c_sixty,'ready':False,'blocker':'C exact cost + exact CLOSED + user approval required'})
    return {
        'candidates':items[:8],'ready_for_rule_change':False,
        'global_blockers':[
            'first exact CLOSED missing' if closed.get('state')!='ACTIVE' else None,
            'exchange-confirmed slippage missing' if not bool((quality.get('cost') or {}).get('exchange_confirmed_slippage_rows')) else None,
            'exact fee source missing',
            'user approval required',
        ],
        'policy':'suggest shadow experiments only; never auto-change S grade, trigger, entry, exit, protection or cost rules',
    }


def update_performance_lab(nowv: float, quality_records: List[Dict[str, Any]], quality_status: Dict[str, Any], late_path: Dict[str, Any], structure_lab: Dict[str, Any], structure_missed: Dict[str, Any]) -> Dict[str, Any]:
    started=time.time()
    index,index_io=_performance_refresh_structure_index(nowv)
    cost_context,cost_index_io=_performance_refresh_cost_index(nowv)
    c_shadow_index,c_shadow_index_io=_performance_refresh_c_shadow_index_v962(nowv)
    structure=_performance_structure_stats(index)
    quality=_performance_quality_analysis(quality_records,quality_status,cost_context)
    closed=_performance_closed_analysis()
    c_shadow=_performance_c_shadow_analysis_v962(c_shadow_index,quality_records,cost_context,structure,closed)
    shadow=_performance_shadow_candidates(structure,quality,late_path,closed)
    quality_cost=quality.get('cost') if isinstance(quality.get('cost'),dict) else {}
    overall_numeric=int(quality_cost.get('paper_reference_numeric_rows') or 0)
    c_numeric=int(c_shadow.get('paper_reference_cost_rows') or 0)
    connected=int(quality_cost.get('paper_reference_connected_rows') or 0)
    contradiction=bool((connected>0 and overall_numeric==0) or (c_numeric>0 and overall_numeric==0))
    state='ERROR_COST_CONSUMER_DIVERGENCE' if contradiction or int(cost_index_io.get('numeric_contract_errors') or 0)>0 else 'ACTIVE'
    if contradiction:
        append_error(ERROR,'v968_cost_consumer_divergence',RuntimeError(f'connected={connected} overall_numeric={overall_numeric} c_numeric={c_numeric}'))
    status={
        'schema':'performance_lab_status_v971_clean_score_cutover','version':VERSION,'build':'clean_score_cutover_v971_2026-06-22',
        'state':state,'updated_ts':nowv,'updated_text':now_text(nowv),'cycle_sec':round(time.time()-started,3),
        'structure_index_io':index_io,'cost_index_io':cost_index_io,'c_shadow_index_io':c_shadow_index_io,
        'structure_methods':structure,'quality':quality,'c_break_retest_shadow':c_shadow,
        'delay':{
            'stages':late_path.get('stages',{}) if isinstance(late_path,dict) else {},
            'paper_execution':late_path.get('paper_stages',{}) if isinstance(late_path,dict) else {},
            'outcome_comparison':late_path.get('outcome_quartiles_10m',{}) if isinstance(late_path,dict) else {},
            'source_schema':late_path.get('schema') if isinstance(late_path,dict) else None,
            'source_state':late_path.get('state') if isinstance(late_path,dict) else None,
            'occurrence_normalized_records':late_path.get('occurrence_normalized_records',0) if isinstance(late_path,dict) else 0,
        },
        'closed_exact':closed,'shadow_candidates':shadow,
        'cost_consistency_v967':{'connected_rows':connected,'overall_numeric_rows':overall_numeric,'c_shadow_numeric_rows':c_numeric,'contradiction':contradiction,'consumer':'_performance_canonical_cost_values','numeric_contract_errors':int(cost_index_io.get('numeric_contract_errors') or 0),'source_priority':'exact canonical cost before legacy row-local slippage'},
        'source_state':{
            'structure_snapshot':structure_lab.get('source_snapshot_state') if isinstance(structure_lab,dict) else None,
            'structure_analysis_ready':structure_lab.get('source_analysis_ready_rows') if isinstance(structure_lab,dict) else None,
            'missed_tracked':((structure_missed.get('stats') or {}).get('tracked') if isinstance(structure_missed,dict) else None),
        },
        'locks':{'trading_rules_changed':False,'s_grades_changed':False,'trigger_changed':False,'entry_changed':False,'exit_changed':False,'cost_rules_changed':False,'auto_buy':False},
        'policy':'quality event context immutable; raw cost numbers normalize once into the canonical index; exact canonical cost outranks legacy derived spread and all consumers use one numeric reader; main read-only',
    }
    save_json(PERFORMANCE_LAB_STATUS,status)
    return status

def run_once() -> Dict[str, Any]:
    _JSONL_CYCLE_CACHE.clear()
    st = now_ts(); write_status("running", phase="refreshing", last_sec=0, jsonl_reader_v929="tail_cached_single_cycle")
    queue = load_json(QUEUE, {}) or {}
    qrows = queue.get("review_candidates") if isinstance(queue, dict) and isinstance(queue.get("review_candidates"), list) else []
    # v446: review state에 이미 들어간 구 후보도 구조태그가 보이도록 현재 후보 snapshot/queue와 표시용 파생값으로 보강한다.
    source_rows = [r for r in read_jsonl(PAPER_LATEST, max_lines=SOURCE_SNAPSHOT_LINES) if isinstance(r, dict)] + [r for r in qrows if isinstance(r, dict)]
    structure_sources: Dict[str, Dict[str, Any]] = {}
    for sr in source_rows:
        tt = ticker_norm(sr.get("ticker") or sr.get("symbol") or sr.get("market"))
        if tt and (_has_structure(sr) or _has_market(sr)):
            structure_sources[tt] = sr
    state = load_json(STATE, {}) or {}
    active = state.get("active") if isinstance(state.get("active"), dict) else {}
    fmap = map_rows(load_json(FEATURE, {}) or {})
    ofmap = map_rows(load_json(ORDERFLOW, {}) or {})
    regime = load_json(REGIME, {}) or {}
    nowv = now_ts()
    try:
        trigger_shadow_v665 = _v665_trigger_shadow_update(nowv, fmap, ofmap)
    except Exception as exc:
        append_error(ERROR, "v665_trigger_shadow_update", exc)
        trigger_shadow_v665 = {"schema":"trigger_shadow_review_v665_error", "error": f"{exc.__class__.__name__}: {exc}"}
    try:
        market_miss_v667 = _v667_market_miss_update(nowv, fmap, ofmap)
    except Exception as exc:
        append_error(ERROR, "v667_market_miss_update", exc)
        market_miss_v667 = {"schema":"market_miss_review_v667_error", "error": f"{exc.__class__.__name__}: {exc}"}
    try:
        good_s2_result_v923 = _v923_update_good_s2_results(nowv, fmap, ofmap)
    except Exception as exc:
        append_error(ERROR, 'v923_good_s2_result_update', exc)
        good_s2_result_v923 = {'schema':'good_s2_result_snapshot_v923_error','error':f'{exc.__class__.__name__}: {exc}'}
    try:
        quality_shadow = update_quality_shadow(nowv, fmap, ofmap)
    except Exception as exc:
        append_error(ERROR, 'quality_shadow_update', exc)
        quality_shadow = {'schema':'quality_shadow_status_v947_error','state':'ERROR','error':f'{exc.__class__.__name__}: {exc}'}
    qstate=load_json(QUALITY_SHADOW_STATE,{}) or {}
    qrecords=[r for r in ((qstate.get('records') or {}).values() if isinstance(qstate,dict) and isinstance(qstate.get('records'),dict) else []) if isinstance(r,dict)]
    try:
        late_path = update_late_path_status(nowv, qrecords)
    except Exception as exc:
        append_error(ERROR, 'late_path_update', exc)
        late_path = {'schema':'late_path_status_v947_error','state':'ERROR','error':f'{exc.__class__.__name__}: {exc}'}
    try:
        sample_board = update_sample_board(nowv,qrecords)
    except Exception as exc:
        append_error(ERROR,'sample_board_update',exc); sample_board={'schema':'sample_board_status_v948_error','state':'ERROR','error':f'{exc.__class__.__name__}: {exc}'}
    try:
        smart_structure = update_smart_structure_shadow(nowv,fmap,ofmap)
    except Exception as exc:
        append_error(ERROR,'smart_structure_shadow_update',exc); smart_structure={'schema':'smart_structure_shadow_review_status_v948_error','state':'ERROR','error':f'{exc.__class__.__name__}: {exc}'}
    try:
        structure_lab, structure_missed = update_structure_laboratory(nowv,fmap,ofmap)
    except Exception as exc:
        append_error(ERROR,'structure_laboratory_update',exc)
        structure_lab={'schema':'structure_lab_review_status_v957_error','state':'ERROR','error':f'{exc.__class__.__name__}: {exc}'}
        structure_missed={'schema':'structure_missed_status_v957_error','state':'ERROR','error':f'{exc.__class__.__name__}: {exc}'}
    try:
        performance_lab = update_performance_lab(nowv,qrecords,quality_shadow,late_path,structure_lab,structure_missed)
    except Exception as exc:
        append_error(ERROR,'performance_lab_update',exc)
        performance_lab={'schema':'performance_lab_status_v960_error','state':'ERROR','error':f'{exc.__class__.__name__}: {exc}'}
    ttl = max(3600.0, RETENTION_DAYS * 86400.0)
    # 오래된 비핵심 복기 state만 제거. paper 장부는 삭제하지 않음.
    before_active = len(active)
    active = {k:v for k,v in active.items() if _v655_keep_active_review(v, nowv, ttl)}
    active = _v664_prune_active_size(active, nowv, ACTIVE_REVIEW_MAX)
    pruned_active = max(0, before_active - len(active))

    for c in qrows:
        if not isinstance(c, dict): continue
        stage = str(c.get("stage") or "").upper()
        if stage not in ("S2", "S3"): continue
        t = ticker_norm(c.get("ticker"))
        if not t: continue
        cur = _current_price(t, fmap, ofmap)
        base = fnum(c.get("snapshot_price"), c.get("price"), default=0.0) or cur
        rec = active.get(t) or {
            "ticker": t, "first_seen_ts": nowv, "first_seen_text": now_text(nowv),
            "first_price": base, "min_pct": 0.0, "max_pct": 0.0,
            "max_seen_ts": nowv, "max_seen_text": now_text(nowv), "samples": {},
        }
        rec.update({
            "stage": stage, "strategy": c.get("strategy"), "strategy_key": c.get("strategy_key"),
            "score": c.get("score"), "block_reasons": c.get("block_reasons", []),
            "missing_info": c.get("missing_info", []), "metrics": c.get("metrics", {}),
            "structure_tags": c.get("structure_tags", []),
            "structure_good_tags": c.get("structure_good_tags", []),
            "structure_risk_tags": c.get("structure_risk_tags", []),
            "structure_fit": c.get("structure_fit", ""),
            "structure_summary": c.get("structure_summary", ""),
            "chart_structure": c.get("chart_structure", {}),
            "last_seen_ts": nowv, "last_seen_text": now_text(nowv),
        })
        if not fnum(rec.get("first_price"), default=0.0) and base:
            rec["first_price"] = base
        if cur:
            rec["current_price"] = cur
            cp = _pct(cur, fnum(rec.get("first_price"), default=0.0))
            rec["current_pct"] = cp
            prev_max = fnum(rec.get("max_pct"), default=cp)
            if cp >= prev_max:
                rec["max_seen_ts"] = nowv
                rec["max_seen_text"] = now_text(nowv)
            rec["max_pct"] = max(prev_max, cp)
            rec["min_pct"] = min(fnum(rec.get("min_pct"), default=cp), cp)
            elapsed = nowv - fnum(rec.get("first_seen_ts"), default=nowv)
            samples = rec.get("samples") if isinstance(rec.get("samples"), dict) else {}
            for label, sec in (("5m",300),("10m",600),("20m",1200)):
                if elapsed >= sec and label not in samples:
                    samples[label] = {"ts": nowv, "text": now_text(nowv), "price": cur, "pct": cp}
                    rec[f"after_{label}_pct"] = cp
            rec["samples"] = samples
            rec["decision"] = _decision(rec, elapsed)
        active[t] = rec

    # v441: active state에 남은 구 decision/review_hint를 그대로 쓰지 않는다.
    # 현재 max/current/위험프로필 기준으로 다시 분류해 /review 상단 count와 후보별 문구가 어긋나지 않게 한다.
    for rec in active.values():
        if not isinstance(rec, dict):
            continue
        _ensure_structure(rec, structure_sources)
        _ensure_market(rec, structure_sources, fmap, ofmap, regime if isinstance(regime, dict) else {})
        elapsed = nowv - fnum(rec.get("first_seen_ts"), default=nowv)
        rec["decision"] = _decision(rec, elapsed)
        rec["review_class"] = rec["decision"]
        rec["review_hint"] = rec["decision"]
    all_rows = list(active.values())
    missed = [r for r in all_rows if str(r.get("decision")) == "❌ 진짜 놓친 후보"]
    regret = [r for r in all_rows if str(r.get("decision")) == "⚠️ 아까운 후보"]
    late_rise = [r for r in all_rows if str(r.get("decision")) == "⏳ 늦게 오른 후보"]
    risk_rise = [r for r in all_rows if str(r.get("decision")) == "🔥 결과만 오른 위험 후보"]
    correct = [r for r in all_rows if str(r.get("decision")) == "✅ 안 산 게 맞음"]
    done = {"❌ 진짜 놓친 후보", "⚠️ 아까운 후보", "⏳ 늦게 오른 후보", "🔥 결과만 오른 위험 후보", "✅ 안 산 게 맞음"}
    pending = [r for r in all_rows if str(r.get("decision")) not in done]
    legacy = _legacy_closed_summary(structure_sources, fmap, ofmap, regime if isinstance(regime, dict) else {})
    summary = {
        "schema": "missed_review_summary_v457_timing_split",
        "version": VERSION,
        "updated_ts": nowv, "updated_text": now_text(nowv),
        "queue_age_sec": round(nowv - fnum(queue.get("updated_ts"), default=nowv), 1) if isinstance(queue, dict) else None,
        "tracking_total": len(all_rows), "queue_candidates": len(qrows),
        "missed_count": len(missed), "regret_count": len(regret), "late_rise_count": len(late_rise), "risk_rise_count": len(risk_rise), "correct_count": len(correct), "pending_count": len(pending),
        "missed": _summ_rows(missed, 8), "regret": _summ_rows(regret, 8), "late_rise": _summ_rows(late_rise, 8), "risk_rise": _summ_rows(risk_rise, 8), "correct": _summ_rows(correct, 5), "pending": _summ_rows(pending, 8),
        "missed_reason_top": _reason_top(missed + regret, 8),
        "v655_active_pruned": pruned_active,
        "v655_policy": "중요 복기 후보는 유지하고 추적중/안산게맞음 active state만 짧게 순환해 CPU를 줄임. paper 장부 삭제 없음.",
        "v664_active_max": ACTIVE_REVIEW_MAX,
        "v664_source_snapshot_lines": SOURCE_SNAPSHOT_LINES,
        "v664_policy": "review_worker는 paper 장부를 지우지 않고 active missed-review 상태만 핵심/최근 후보 중심으로 제한해 CPU를 줄임.",
        "trigger_shadow_v665": trigger_shadow_v665,
        "market_miss_v667": market_miss_v667,
        "good_s2_result_v923": good_s2_result_v923,
        "quality_shadow_v946": quality_shadow,
        "late_path_v947": late_path,
        "sample_board_v948": sample_board,
        "smart_structure_shadow_v948": smart_structure,
        "structure_lab_v956": structure_lab,
        "structure_missed_v956": structure_missed,
        "performance_lab_v960": performance_lab,
        "late_rise_reason_top": _reason_top(late_rise, 8),
        "risk_rise_reason_top": _reason_top(risk_rise, 8),
        "policy": "v457: 최고수익 착시를 분리한다. 진짜놓침은 5/10/20분 안에 상승한 후보만 남기고, 늦게 오른 후보는 S1 완화 근거에서 제외한다. 조건/청산숫자/paper 장부 변경 없음.",
        **legacy,
    }
    save_json(STATE, {"schema":"missed_review_state_v457_timing_split", "version":VERSION, "updated_ts":nowv, "active":active})
    save_json(SUMMARY, summary)
    save_json(OLD_SUMMARY, {"version":VERSION, "updated_ts":nowv, "updated_text":now_text(nowv), **legacy, "missed_review": summary})
    sec = now_ts() - st
    write_status("running", tracked=len(all_rows), missed=len(missed), regret=len(regret), late_rise=len(late_rise), risk_rise=len(risk_rise), correct=len(correct), pending=len(pending), closed_recent=legacy.get("closed_recent",0), big_loss=legacy.get("big_loss",0), good_win=legacy.get("good_win",0), active_pruned=pruned_active, active_max=ACTIVE_REVIEW_MAX, source_snapshot_lines=SOURCE_SNAPSHOT_LINES, trigger_shadow_active=(trigger_shadow_v665 or {}).get("active_count",0), trigger_shadow_entered=(trigger_shadow_v665 or {}).get("entered_count",0), trigger_shadow_pruned=(trigger_shadow_v665 or {}).get("pruned_count_v678",0), market_miss_tracking=(market_miss_v667 or {}).get("tracking_total",0), market_miss_rise=(market_miss_v667 or {}).get("rise_count",0), good_s2_result_total=(good_s2_result_v923 or {}).get("tracked_total",0), good_s2_result_opened=(good_s2_result_v923 or {}).get("opened_exact",0), good_s2_result_closed=(good_s2_result_v923 or {}).get("closed_exact",0), good_s2_result_final=(good_s2_result_v923 or {}).get("final_ledger_rows",0), quality_shadow_tracked=(quality_shadow or {}).get("tracked_records",0), quality_shadow_final=(quality_shadow or {}).get("final_ledger_rows",0), late_path_occurrences=(late_path or {}).get("occurrence_normalized_records",0), sample_board_records=(sample_board or {}).get("tracked_records",0), smart_structure_records=(smart_structure or {}).get("tracked_records",0), structure_lab_plans=(structure_lab or {}).get("tracked_structures",0), structure_missed_records=((structure_missed or {}).get("stats") or {}).get("tracked",0), performance_lab_cycle_sec=(performance_lab or {}).get("cycle_sec",0), performance_lab_state=(performance_lab or {}).get("state","-"), last_sec=round(sec,3), structure_enriched=sum(1 for r in active.values() if isinstance(r, dict) and _has_structure(r)))
    return {"tracked": len(all_rows), "missed": len(missed), "regret": len(regret), "late_rise": len(late_rise), "correct": len(correct), "good_s2_result": good_s2_result_v923, "quality_shadow": quality_shadow, "late_path": late_path, "sample_board": sample_board, "smart_structure": smart_structure, "structure_lab": structure_lab, "structure_missed": structure_missed, "performance_lab": performance_lab}

def main() -> None:
    write_status("initializing")
    while True:
        try: run_once()
        except KeyboardInterrupt: write_status("stopping"); raise
        except Exception as exc:
            append_error(ERROR, "loop", exc); write_status("error", error=f"{exc.__class__.__name__}: {exc}")
        time.sleep(max(10.0, INTERVAL_SEC))

# =============================================================================
# review_worker v0.19 / v675: preserve canonical values in missed-review state
# =============================================================================
VERSION = "review_worker_v0.970"

def _v675_first(*vals: Any, default: Any=None) -> Any:
    for v in vals:
        if v not in (None, '', '-', [], {}): return v
    return default

_v675_prev_market_miss_update = _v667_market_miss_update

def _v667_market_miss_update(nowv: float, fmap: Dict[str, Dict[str, Any]], ofmap: Dict[str, Dict[str, Any]]) -> Dict[str, Any]:  # type: ignore[override]
    summary = _v675_prev_market_miss_update(nowv, fmap, ofmap)
    try:
        cand_obj = load_json(MARKET_MISS_CANDIDATES, {}) or {}; candidates = cand_obj.get('rows') if isinstance(cand_obj, dict) and isinstance(cand_obj.get('rows'), list) else []
        by_ticker = {ticker_norm(c.get('ticker')): c for c in candidates if isinstance(c, dict) and ticker_norm(c.get('ticker'))}
        state = load_json(MARKET_MISS_STATE, {}) or {}; active = state.get('active') if isinstance(state, dict) and isinstance(state.get('active'), dict) else {}
        for t, rec in list(active.items()):
            if not isinstance(rec, dict): continue
            c = by_ticker.get(t) or {}
            rec['coin_quality_score'] = fnum(_v675_first(c.get('coin_quality_score'), c.get('q'), rec.get('coin_quality_score')), default=0.0); rec['q'] = rec['coin_quality_score']
            rec['execution_risk_score'] = fnum(_v675_first(c.get('execution_risk_score'), c.get('risk'), rec.get('execution_risk_score')), default=0.0); rec['risk'] = rec['execution_risk_score']
            for k in ('trigger_source','trigger_confidence','trigger_gap_pct','price_reaction_pct','buy_ratio','buy_sustain_1m','spread_pct','slippage_pct','candle_age_sec'):
                if c.get(k) not in (None, '', '-'): rec[k] = c.get(k)
            maxp = fnum(rec.get('max_pct'), default=0.0); q=fnum(rec.get('coin_quality_score'), default=0.0); risk=fnum(rec.get('execution_risk_score'), default=0.0); bucket=str(rec.get('miss_bucket') or '-')
            if maxp >= 0.70 and q >= 60 and risk <= 40 and bucket not in ('risk_filter_candidate',): rec['miss_decision']='❌ 진짜놓침_후보'
            elif maxp >= 0.70 and bucket == 'risk_filter_candidate': rec['miss_decision']='✅ 위험필터_성공검토'
            elif maxp >= 0.40: rec['miss_decision']='⚠️ 아까운상승'
            else: rec['miss_decision']='관찰중'
            active[t]=rec
        rows=list(active.values()); matured=[r for r in rows if fnum(r.get('age_sec'), default=0)>=180]; risers=[r for r in rows if fnum(r.get('max_pct'), default=0)>=0.40]; true_missed=[r for r in rows if str(r.get('miss_decision'))=='❌ 진짜놓침_후보']
        buckets=Counter(str(r.get('miss_bucket') or '-') for r in risers); decisions=Counter(str(r.get('miss_decision') or '-') for r in rows)
        def slim(r: Dict[str, Any]) -> Dict[str, Any]:
            return {k:r.get(k) for k in ('ticker','initial_stage','miss_bucket','miss_decision','coin_quality_score','q','execution_risk_score','risk','first_price','latest_price','current_pct','max_pct','min_pct','age_sec','initial_reason','trigger_source','trigger_confidence','trigger_gap_pct','price_reaction_pct','buy_ratio','buy_sustain_1m','spread_pct','slippage_pct','candle_age_sec')}
        top=sorted(risers, key=lambda r:fnum(r.get('max_pct'), default=0.0), reverse=True)[:12]; true_top=sorted(true_missed, key=lambda r:fnum(r.get('max_pct'), default=0.0), reverse=True)[:10]
        summary=dict(summary or {}); summary.update({'schema':'market_miss_review_v675_value_enriched','version':VERSION,'updated_ts':nowv,'updated_text':now_text(nowv),'tracking_total':len(rows),'matured_count':len(matured),'rise_count':len(risers),'true_missed_count':len(true_missed),'miss_bucket_counts':dict(buckets.most_common(10)),'decision_counts':dict(decisions.most_common(8)),'top_risers':[slim(r) for r in top],'true_missed_top':[slim(r) for r in true_top],'value_enriched_v675':True,'policy':'v675: missed candidates keep Q/R/trigger/execution values from canonical candidate snapshot. 실제 S1/paper OPEN/청산/자동매수 변경 없음.'})
        save_json(MARKET_MISS_STATE, {'schema':'market_miss_state_v675_value_enriched','version':VERSION,'updated_ts':nowv,'updated_text':now_text(nowv),'active':active}); save_json(MARKET_MISS_SUMMARY, summary)
    except Exception as exc: append_error(ERROR, 'v675_market_miss_value_enrich', exc)
    return summary


# =============================================================================
# review_worker v0.20 / v676: market-miss CPU cache guard
# - Keep whole-market review, but do not rebuild the expensive 456-row maturity
#   summary every loop when the cache is still fresh.
# =============================================================================
VERSION = "review_worker_v0.970"
V676_MARKET_MISS_MIN_REFRESH_SEC = float(os.getenv('REVIEW_MARKET_MISS_MIN_REFRESH_SEC', '25'))
_v676_prev_market_miss_update = _v667_market_miss_update

def _v667_market_miss_update(nowv: float, fmap: Dict[str, Dict[str, Any]], ofmap: Dict[str, Dict[str, Any]]) -> Dict[str, Any]:  # type: ignore[override]
    try:
        if MARKET_MISS_SUMMARY.exists():
            age = max(0.0, nowv - MARKET_MISS_SUMMARY.stat().st_mtime)
            if age < V676_MARKET_MISS_MIN_REFRESH_SEC:
                cached = load_json(MARKET_MISS_SUMMARY, {}) or {}
                if isinstance(cached, dict) and cached.get('tracking_total'):
                    cached = dict(cached)
                    cached['cache_reused_v676'] = True
                    cached['cache_age_sec_v676'] = round(age, 3)
                    return cached
    except Exception:
        pass
    out = _v676_prev_market_miss_update(nowv, fmap, ofmap)
    try:
        if isinstance(out, dict):
            out['cache_reused_v676'] = False
            out['min_refresh_sec_v676'] = V676_MARKET_MISS_MIN_REFRESH_SEC
            save_json(MARKET_MISS_SUMMARY, out)
    except Exception as exc:
        append_error(ERROR, 'v676_market_miss_cache_mark', exc)
    return out




# =============================================================================
# review_worker v0.721 / v895: same-number seal for market-miss after review
# - 후보 row의 stable_event_key/candidate_follow_key/entry_build_key를 market-miss 결과에 보존한다.
# - 실제 S1/paper OPEN/청산/자동매수/조건은 변경하지 않는다.
# =============================================================================
VERSION = "review_worker_v0.970"
BUILD_LABEL = 'clean_score_cutover_v971_2026-06-22'


def _v895_present(v: Any) -> bool:
    return v not in (None, '', '-', [], {})


def _v895_event_prefix_bucket(value: Any) -> tuple[str, Optional[int]]:
    s = str(value or '').strip()
    if not s or s == '-': return '', None
    parts = s.split(':')
    if len(parts) >= 2 and parts[-1].isdigit():
        try: return ':'.join(parts[:-1]), int(parts[-1])
        except Exception: return ':'.join(parts[:-1]), None
    return s, None


def _v895_stable_fields(c: Dict[str, Any]) -> Dict[str, Any]:
    if not isinstance(c, dict): return {}
    eid = None
    for k in ('event_id','event_key','trace_id','handoff_id','candidate_uid','candidate_id','scan_id','source_scan_id','entry_build_key','build_key'):
        if _v895_present(c.get(k)):
            eid = c.get(k); break
    stable = None
    for k in ('stable_event_key_v894','candidate_follow_key_v894','stable_event_key_v895','candidate_follow_key_v895'):
        if _v895_present(c.get(k)):
            stable = c.get(k); break
    bucket = None
    for k in ('stable_event_bucket_v894','candidate_event_bucket_v894','stable_event_bucket_v895','candidate_event_bucket_v895'):
        if _v895_present(c.get(k)):
            bucket = c.get(k); break
    if not _v895_present(stable) and _v895_present(eid):
        stable, bucket2 = _v895_event_prefix_bucket(eid)
        if not _v895_present(bucket): bucket = bucket2
    out = {
        'event_id': eid,
        'stable_event_key_v894': stable,
        'candidate_follow_key_v894': stable,
        'stable_event_key_v895': stable,
        'candidate_follow_key_v895': stable,
        'entry_build_key': c.get('entry_build_key') or c.get('build_key') or eid,
        'score_patch_version': c.get('score_patch_version') or c.get('patch_version') or VERSION,
        'signal_ts': c.get('signal_ts') or c.get('created_at') or c.get('candidate_created_at') or c.get('source_created_at'),
        'same_key_sealed_v895': bool(_v895_present(stable) or _v895_present(eid)),
        'same_key_owner_v895': 'review_worker_market_miss_writer',
        'same_key_policy_v895': 'use candidate stable key for after metric review; no trading condition change',
    }
    if _v895_present(bucket):
        try: out['stable_event_bucket_v894'] = int(float(bucket)); out['stable_event_bucket_v895'] = int(float(bucket))
        except Exception: out['stable_event_bucket_v894'] = bucket; out['stable_event_bucket_v895'] = bucket
    return {k:v for k,v in out.items() if _v895_present(v) or k == 'same_key_sealed_v895'}


_v895_prev_miss_key = _v667_miss_key

def _v667_miss_key(c: Dict[str, Any]) -> str:  # type: ignore[override]
    fields = _v895_stable_fields(c)
    return str(fields.get('stable_event_key_v895') or fields.get('stable_event_key_v894') or fields.get('entry_build_key') or _v895_prev_miss_key(c))


def _v895_enrich_market_miss_outputs(summary: Dict[str, Any], nowv: float) -> Dict[str, Any]:
    cand_obj = load_json(MARKET_MISS_CANDIDATES, {}) or {}
    candidates = cand_obj.get('rows') if isinstance(cand_obj, dict) and isinstance(cand_obj.get('rows'), list) else []
    by_key: Dict[str, Dict[str, Any]] = {}
    by_ticker: Dict[str, Dict[str, Any]] = {}
    for c in candidates:
        if not isinstance(c, dict): continue
        fields = _v895_stable_fields(c)
        key = str(fields.get('stable_event_key_v895') or fields.get('entry_build_key') or '')
        t = ticker_norm(c.get('ticker') or c.get('symbol') or c.get('market'))
        cc = dict(c); cc.update(fields)
        if key: by_key[key] = cc
        if t: by_ticker[t] = cc
    state = load_json(MARKET_MISS_STATE, {}) or {}
    active = state.get('active') if isinstance(state, dict) and isinstance(state.get('active'), dict) else {}
    sealed = 0
    rows = []
    for k, rec in list(active.items()):
        if not isinstance(rec, dict): continue
        t = ticker_norm(rec.get('ticker'))
        c = by_key.get(str(k)) or by_key.get(str(rec.get('stable_event_key_v895') or rec.get('stable_event_key_v894') or '')) or by_ticker.get(t)
        if isinstance(c, dict):
            fields = _v895_stable_fields(c)
            rec.update(fields)
        if rec.get('same_key_sealed_v895'): sealed += 1
        rows.append(rec)
    if isinstance(active, dict):
        save_json(MARKET_MISS_STATE, {'schema':'market_miss_state_v895_same_key','version':VERSION,'build':BUILD_LABEL,'updated_ts':nowv,'updated_text':now_text(nowv),'active':active})
    def enrich_arr(arr: Any) -> list:
        out=[]
        for r in arr if isinstance(arr, list) else []:
            if not isinstance(r, dict): continue
            t = ticker_norm(r.get('ticker'))
            c = by_key.get(str(r.get('stable_event_key_v895') or r.get('stable_event_key_v894') or '')) or by_ticker.get(t)
            rr = dict(r)
            if isinstance(c, dict): rr.update(_v895_stable_fields(c))
            out.append(rr)
        return out
    summary = dict(summary or {})
    for key in ('top_risers','true_missed_top','rows','items','missed','regret','late_rise'):
        if isinstance(summary.get(key), list):
            summary[key] = enrich_arr(summary.get(key))
    # main v889 reads rows too; publish a compact stable-key rows list without replacing existing summaries.
    summary['rows'] = sorted(rows, key=lambda x: fnum(x.get('max_pct'), default=0.0), reverse=True)[:240]
    summary['same_key_seal_v895'] = {'candidate_rows': len(candidates), 'active_rows': len(rows), 'sealed_rows': sealed, 'version': VERSION, 'build': BUILD_LABEL}
    summary['version'] = VERSION; summary['build'] = BUILD_LABEL
    save_json(MARKET_MISS_SUMMARY, summary)
    return summary


_v895_prev_market_miss_update = _v667_market_miss_update

def _v667_market_miss_update(nowv: float, fmap: Dict[str, Dict[str, Any]], ofmap: Dict[str, Dict[str, Any]]) -> Dict[str, Any]:  # type: ignore[override]
    summary = _v895_prev_market_miss_update(nowv, fmap, ofmap)
    try:
        return _v895_enrich_market_miss_outputs(summary if isinstance(summary, dict) else {}, nowv)
    except Exception as exc:
        append_error(ERROR, 'v895_market_miss_same_key_seal', exc)
        return summary


# =============================================================================
# review_worker v0.722 / v896: same-key alias for market-miss performance prep
# - Adds v896 aliases and match mode into market-miss result rows.
# - No trading condition, trigger, exit, paper OPEN/CLOSED, auto-buy change.
# =============================================================================
VERSION = "review_worker_v0.970"
BUILD_LABEL = 'clean_score_cutover_v971_2026-06-22'


def _v896_present(v: Any) -> bool:
    return v not in (None, '', '-', [], {})


def _v896_stable_fields(c: Dict[str, Any], mode: str = 'candidate_key') -> Dict[str, Any]:
    if not isinstance(c, dict): return {}
    stable = c.get('stable_event_key_v896') or c.get('candidate_follow_key_v896') or c.get('stable_event_key_v895') or c.get('candidate_follow_key_v895') or c.get('stable_event_key_v894') or c.get('candidate_follow_key_v894')
    bucket = c.get('stable_event_bucket_v896') or c.get('candidate_event_bucket_v896') or c.get('stable_event_bucket_v895') or c.get('candidate_event_bucket_v895') or c.get('stable_event_bucket_v894') or c.get('candidate_event_bucket_v894')
    eid = c.get('entry_build_key') or c.get('event_id') or c.get('event_key') or c.get('trace_id')
    if not _v896_present(stable) and _v896_present(eid):
        try:
            stable, b2 = _v895_event_prefix_bucket(eid)
            if not _v896_present(bucket): bucket = b2
        except Exception:
            stable = eid
    out = {
        'event_id': c.get('event_id') or eid,
        'stable_event_key_v896': stable,
        'candidate_follow_key_v896': stable,
        'stable_event_key_v895': stable,
        'candidate_follow_key_v895': stable,
        'stable_event_key_v894': stable,
        'candidate_follow_key_v894': stable,
        'same_number_key_v896': stable,
        'entry_build_key': c.get('entry_build_key') or eid,
        'score_patch_version': c.get('score_patch_version') or c.get('patch_version') or VERSION,
        'signal_ts': c.get('signal_ts') or c.get('created_at') or c.get('candidate_created_at') or c.get('source_created_at'),
        'same_key_sealed_v896': bool(stable or eid),
        'same_key_owner_v896': 'review_worker_market_miss_writer',
        'same_key_match_mode_v896': mode,
        'same_key_policy_v896': 'same key for quality tag performance prep; no trading condition change',
    }
    if _v896_present(bucket):
        try:
            out['stable_event_bucket_v896'] = int(float(bucket)); out['candidate_event_bucket_v896'] = int(float(bucket))
        except Exception:
            out['stable_event_bucket_v896'] = bucket; out['candidate_event_bucket_v896'] = bucket
    return {k:v for k,v in out.items() if _v896_present(v) or k == 'same_key_sealed_v896'}

_v896_prev_miss_key = _v667_miss_key

def _v667_miss_key(c: Dict[str, Any]) -> str:  # type: ignore[override]
    fields = _v896_stable_fields(c, 'exact_candidate_key')
    return str(fields.get('same_number_key_v896') or fields.get('stable_event_key_v896') or fields.get('entry_build_key') or _v896_prev_miss_key(c))

_v896_prev_market_miss_update = _v667_market_miss_update

def _v667_market_miss_update(nowv: float, fmap: Dict[str, Dict[str, Any]], ofmap: Dict[str, Dict[str, Any]]) -> Dict[str, Any]:  # type: ignore[override]
    summary = _v896_prev_market_miss_update(nowv, fmap, ofmap)
    try:
        cand_obj = load_json(MARKET_MISS_CANDIDATES, {}) or {}
        candidates = cand_obj.get('rows') if isinstance(cand_obj, dict) and isinstance(cand_obj.get('rows'), list) else []
        by_key: Dict[str, Dict[str, Any]] = {}; by_ticker: Dict[str, Dict[str, Any]] = {}
        for c in candidates:
            if not isinstance(c, dict): continue
            fields = _v896_stable_fields(c, 'exact_candidate_key')
            cc = dict(c); cc.update(fields)
            for k in ('same_number_key_v896','stable_event_key_v896','candidate_follow_key_v896','entry_build_key','event_id'):
                if _v896_present(cc.get(k)): by_key[str(cc.get(k))] = cc
            t = ticker_norm(c.get('ticker') or c.get('symbol') or c.get('market'))
            if t: by_ticker[t] = cc
        state = load_json(MARKET_MISS_STATE, {}) or {}
        active = state.get('active') if isinstance(state, dict) and isinstance(state.get('active'), dict) else {}
        rows=[]; sealed=0; exact=0; near=0
        for k, rec in list(active.items()):
            if not isinstance(rec, dict): continue
            c = by_key.get(str(k)) or by_key.get(str(rec.get('same_number_key_v896') or rec.get('stable_event_key_v896') or rec.get('stable_event_key_v895') or rec.get('entry_build_key') or rec.get('event_id') or ''))
            mode = 'exact_candidate_key' if isinstance(c, dict) else ''
            if c is None:
                t = ticker_norm(rec.get('ticker'))
                c = by_ticker.get(t); mode = 'ticker_time_near_audit' if isinstance(c, dict) else ''
            rr = dict(rec)
            if isinstance(c, dict): rr.update(_v896_stable_fields(c, mode))
            if rr.get('same_key_sealed_v896'): sealed += 1
            if rr.get('same_key_match_mode_v896') == 'exact_candidate_key': exact += 1
            if rr.get('same_key_match_mode_v896') == 'ticker_time_near_audit': near += 1
            rows.append(rr)
        summary = dict(summary or {})
        summary['rows'] = sorted(rows, key=lambda x: fnum(x.get('max_pct'), default=0.0), reverse=True)[:240]
        summary['same_key_seal_v896'] = {'candidate_rows':len(candidates),'active_rows':len(rows),'sealed_rows':sealed,'exact_rows':exact,'near_rows':near,'version':VERSION,'build':BUILD_LABEL,'updated_ts':nowv}
        summary['version']=VERSION; summary['build']=BUILD_LABEL
        save_json(MARKET_MISS_SUMMARY, summary)
        return summary
    except Exception as exc:
        append_error(ERROR, 'v896_market_miss_same_key_alias', exc)
        return summary

if __name__ == "__main__": main()
