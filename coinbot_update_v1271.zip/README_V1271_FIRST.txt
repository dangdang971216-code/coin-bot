코인봇 v1271 운영수리 적용 ZIP
- 목적: Paper 전체 정지·정리·재시작 명령과 exact_replay WAL checkpoint 추가
- 전략/후보/trigger/invalid/target/RR/v1270 수익보호 기준 변경 없음
- 적용 후 /gpaper_full_reset 실행
