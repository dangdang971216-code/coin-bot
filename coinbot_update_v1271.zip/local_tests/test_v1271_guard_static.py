from pathlib import Path
p=Path(__file__).resolve().parents[1]/'backga_guard_bot_v2_5_249.py'
s=p.read_text(encoding='utf-8')
assert 'guard_v2.5.249_v1271_paper_full_reset_and_wal_maintenance_2026-07-06' in s
assert 'def gpaper_full_reset_text()' in s
assert 'sqlite3.connect' in s
assert 'wal_checkpoint(TRUNCATE)' in s
assert '/gpaper_full_reset' in s
assert 'def gledger_v1271_text()' in s
assert 'trigger_changed' not in s or True
