import json
from pathlib import Path
root=Path(__file__).resolve().parents[1]
manifest=json.loads((root/'DEPLOY_BUNDLE.json').read_text(encoding='utf-8'))
assert manifest['release']=='v1271'
assert manifest['guard']=='backga_guard_bot_v2_5_249.py'
assert manifest.get('paper') in (None,'')
assert manifest['actual_trading_changed'] is False
assert manifest['trigger_changed'] is False
assert manifest['target_selection_changed'] is False
assert manifest['invalid_selection_changed'] is False
assert manifest['rr_threshold_changed'] is False
assert manifest['exit_threshold_changed'] is False
assert manifest['historical_trade_ledgers_rewritten'] is False
assert manifest['auto_buy'] is False
