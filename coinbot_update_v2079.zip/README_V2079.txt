v2079: manifest fix for v2078 main application. Existing shadow easy readout + loss audit repair. No strategy change. Auto-buy OFF.
