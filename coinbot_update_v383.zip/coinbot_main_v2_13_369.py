#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""수익형_v2.13.352.py

Clean main bot renewal phase v366.
- 메인봇은 무거운 전체시장 스캔/정밀/전략판정을 직접 하지 않는다.
- scanner/feature/orderflow/strategy/review worker가 만든 캐시만 읽는다.
- 실제 paper OPEN은 strategy worker의 S급 후보만 허용한다.
- A/B/C 실시간 후보와 무거운 가상복기는 메인봇 경로에서 제거한다.
"""
from __future__ import annotations
import json, os, sys, time, traceback, re
from pathlib import Path
from typing import Any, Dict, List, Optional
import threading
from collections import Counter

try:
    from telegram import Bot, BotCommand
    from telegram.ext import Updater, CommandHandler, MessageHandler, Filters
except Exception:
    Bot = None; BotCommand = None; Updater = None; CommandHandler = None; MessageHandler = None; Filters = None

BOT_VERSION="수익형 v2.13.369"
BASE_DIR=Path(__file__).resolve().parent
TELEGRAM_TOKEN=os.getenv("TELEGRAM_TOKEN","").strip()
CHAT_ID=os.getenv("CHAT_ID","").strip()
WORKERS={
    "scanner": {"file":"scanner_worker_v0.3.py", "status":"clean_scanner_status.json"},
    "candle": {"file":"candle_worker_v0.2.py", "status":"clean_candle_status.json"},
    "market": {"file":"market_regime_worker_v0.1.py", "status":"clean_market_regime_status.json"},
    "feature": {"file":"feature_worker_v0.2.py", "status":"clean_feature_status.json"},
    "orderflow": {"file":"orderflow_worker_v0.7.py", "status":"clean_orderflow_status.json"},
    "risk": {"file":"risk_worker_v0.2.py", "status":"clean_risk_status.json"},
    "strategy": {"file":"strategy_worker_v0.18.py", "status":"clean_strategy_worker_status.json"},
    "target_router": {"file":"target_router_worker_v0.7.py", "status":"clean_target_router_status.json"},
    "review": {"file":"review_worker_v0.2.py", "status":"clean_review_worker_status.json"},
}
FILES={
    "brain_status":BASE_DIR/"clean_brain_status.json",
    "brain_runtime":BASE_DIR/"clean_brain_runtime.log",
    "brain_error":BASE_DIR/"clean_brain_error.log",
    "resource":BASE_DIR/"clean_resource_status.json",
    "scanner_market":BASE_DIR/"clean_scanner_market_cache.json",
    "feature":BASE_DIR/"clean_feature_cache.json",
    "orderflow":BASE_DIR/"clean_orderflow_summary_cache.json",
    "strategy_summary":BASE_DIR/"clean_strategy_s_summary.json",
    "candle":BASE_DIR/"clean_candle_cache.json",
    "market_regime":BASE_DIR/"clean_market_regime_cache.json",
    "risk":BASE_DIR/"clean_risk_filter_cache.json",
    "strategy_reject":BASE_DIR/"clean_strategy_s_reject_summary.json",
    "review":BASE_DIR/"clean_review_summary.json",
    "paper_status":BASE_DIR/"paper_bot_status.json",
    "paper_open":BASE_DIR/"paper_bot_open.json",
    "paper_score":BASE_DIR/"paper_bot_score_cache.json",
    "paper_latest":BASE_DIR/"paper_candidates_latest.jsonl",
    "paper_archive":BASE_DIR/"paper_candidates.jsonl",
    "paper_handoff":BASE_DIR/"clean_strategy_paper_handoff_status.json",
    "paperbot_handoff":BASE_DIR/"paper_bot_candidate_handoff_status.json",
    "candidate_handoff_trace":BASE_DIR/"paper_bot_candidate_handoff_trace.json",
    "paper_closed":BASE_DIR/"paper_bot_closed.jsonl",
    "score_anchor":BASE_DIR/"paper_bot_current_score_anchor.json",
    "target_router":BASE_DIR/"clean_target_router_queue.json",
    "ws_status":BASE_DIR/"clean_ws_sidecar_status.json",
    "micro_status":BASE_DIR/"clean_bithumb_micro_status.json",
    "micro_targets":BASE_DIR/"clean_micro_targets.json",
}
START_TS=time.time()

def now_ts()->float: return time.time()
def now_text(ts:Optional[float]=None)->str: return time.strftime("%Y-%m-%d %H:%M:%S", time.localtime(ts or now_ts()))
def fnum(v:Any, *more:Any, default:float=0.0)->float:
    """안전 숫자 변환.

    기존 호출(fnum(x, -1.0))은 두 번째 인자를 fallback 값처럼 쓰고,
    v345 preview 쪽 호출(fnum(a,b,c, default=0))은 앞에서부터 숫자값을 고른다.
    """
    for val in (v,) + tuple(more):
        try:
            if val is None or val == "":
                continue
            return float(str(val).replace(",", ""))
        except Exception:
            continue
    return default

def norm_ticker(v: Any) -> str:
    """메인봇 preview 전용 안전 티커 정규화.

    v345에서 paper 추적 로직이 norm_ticker를 참조했지만 메인봇 파일에는
    정의가 없어 /preview NameError가 났다. 여기서는 거래소 접두사/마켓 접미사만
    정리하고, 판단 로직에는 관여하지 않는다.
    """
    try:
        s = str(v or "").strip().upper()
        if not s:
            return ""
        if ":" in s:
            s = s.split(":", 1)[1]
        for suf in ("_KRW", "-KRW", "/KRW", "KRW"):
            if s.endswith(suf):
                s = s[:-len(suf)]
                break
        s = s.replace("_", "").replace("-", "").replace("/", "")
        return s
    except Exception:
        return ""

def load_json(path:Path, default:Any=None)->Any:
    try:
        if not path.exists(): return default
        return json.loads(path.read_text(encoding="utf-8", errors="ignore"))
    except Exception: return default

def save_json(path:Path,obj:Any)->None:
    path.parent.mkdir(parents=True,exist_ok=True)
    tmp=path.with_suffix(path.suffix+".tmp")
    tmp.write_text(json.dumps(obj,ensure_ascii=False,separators=(",",":"),default=str),encoding="utf-8")
    os.replace(tmp,path)

def read_jsonl(path:Path,max_lines:int=1000)->List[Dict[str,Any]]:
    if not path.exists(): return []
    try:
        lines=path.read_text(encoding="utf-8",errors="ignore").splitlines()
        if len(lines)>max_lines: lines=lines[-max_lines:]
        out=[]
        for ln in lines:
            try:
                if ln.strip():
                    o=json.loads(ln)
                    if isinstance(o,dict): out.append(o)
            except Exception: pass
        return out
    except Exception: return []

def line_count(path: Path, max_bytes: int = 2_000_000) -> int:
    try:
        if not path.exists(): return 0
        if path.stat().st_size > max_bytes:
            # 큰 archive는 기본 명령에서 전체를 세지 않는다. tail이 아니라 대략 표시만 한다.
            return -1
        return len(path.read_text(encoding="utf-8", errors="ignore").splitlines())
    except Exception: return 0

def log_runtime(msg:str)->None:
    try:
        with FILES["brain_runtime"].open("a",encoding="utf-8") as f: f.write(f"[{now_text()}] {msg}\n")
    except Exception: pass

def log_error(where:str,exc:BaseException)->None:
    try:
        with FILES["brain_error"].open("a",encoding="utf-8") as f:
            f.write(f"[{now_text()}] {where}: {exc.__class__.__name__}: {exc}\n{traceback.format_exc()[-1500:]}\n")
    except Exception: pass

def age(path:Path)->float:
    try: return max(0.0, now_ts()-path.stat().st_mtime)
    except Exception: return 999999.0

def pid_alive(pid:int)->bool:
    if pid<=0: return False
    try: os.kill(pid,0); return True
    except Exception: return False

def worker_status(name:str)->Dict[str,Any]:
    spec=WORKERS[name]; path=BASE_DIR/spec["status"]
    obj=load_json(path,{}) or {}; pid=int(fnum(obj.get("pid"),default=0)); alive=pid_alive(pid)
    a=age(path)
    state=str(obj.get("state") or "missing") if obj else "missing"
    return {"name":name,"state":state,"pid":pid,"alive":alive,"age":round(a,1),"version":obj.get("version","-"),"last_sec":obj.get("last_sec","-"),"row_count":obj.get("row_count",obj.get("evaluated",obj.get("closed_recent","-"))),"raw":obj}

def ensure_workers()->None:
    # v329: worker 실행/재시작은 가드봇 systemd 전담. 메인봇은 절대 직접 worker를 켜지 않는다.
    return

def resource_snapshot()->Dict[str,Any]:
    try:
        import shutil
        total, used, free = shutil.disk_usage(BASE_DIR)
        mem_total=mem_free=0
        try:
            for ln in Path('/proc/meminfo').read_text().splitlines():
                if ln.startswith('MemTotal:'): mem_total=int(ln.split()[1])*1024
                if ln.startswith('MemAvailable:'): mem_free=int(ln.split()[1])*1024
        except Exception: pass
        load=os.getloadavg() if hasattr(os,'getloadavg') else (0,0,0)
        return {"disk_free_gb":round(free/1024**3,2),"disk_used_pct":round(used/total*100,1),"mem_free_mb":round(mem_free/1024**2,1) if mem_free else 0,"mem_used_pct":round((1-mem_free/mem_total)*100,1) if mem_total and mem_free else 0,"load":[round(x,2) for x in load]}
    except Exception as exc:
        log_error("resource_snapshot",exc); return {}

def update_brain_status(state:str="running")->None:
    """메인봇 heartbeat/status만 저장한다.
    v329 기준 worker 실행/재시작은 가드봇 systemd 전담이다.
    """
    workers={k:worker_status(k) for k in WORKERS}
    save_json(FILES["brain_status"],{
        "version":BOT_VERSION,
        "state":state,
        "telegram_state":state,
        "pid":os.getpid(),
        "updated_ts":now_ts(),
        "updated_text":now_text(),
        "uptime_sec":round(now_ts()-START_TS,1),
        "workers":workers,
        "resource":resource_snapshot(),
        "note":"v330 main is cache-only; worker lifecycle is guard/systemd only",
    })

def worker_ok(st:Dict[str,Any])->str:
    state=str(st.get('state') or '').lower()
    a=fnum(st.get('age'), default=999999)
    if state in {'error','failed','stopped','missing','dead'}:
        return '❌'
    if state in {'running','ready','ok','initializing'}:
        return '✅' if a < 45 else '⚠️'
    return '❔'

def line_worker(st:Dict[str,Any], detail:bool=False)->str:
    icon=worker_ok(st)
    base=f"- {icon} {st['name']}: {st.get('version','-')} / {st.get('state')} / age {st.get('age')}s"
    if detail:
        base += f" / rows {st.get('row_count')} / sec {st.get('last_sec')}"
    return base

def router_flow_summary(router: Dict[str, Any]) -> str:
    """v337: target_router를 개수 제한표가 아니라 전체/우선/순환/대기/버림으로 보여준다."""
    if not isinstance(router, dict) or not router:
        return "- 정보배차: 상태 없음"
    return (
        f"- 정보배차: 전체 {router.get('queue_count','-')} / 최우선 {router.get('priority_protected_count','-')} "
        f"/ 이번내보냄 {router.get('active_target_count', router.get('target_count','-'))} "
        f"/ 순환대기 {router.get('rotation_wait_count', router.get('backlog_count','-'))} "
        f"/ 버림 {router.get('dropped_count',0)}"
    )

def router_flow_detail(router: Dict[str, Any]) -> List[str]:
    if not isinstance(router, dict) or not router:
        return ["- 정보배차 상태 없음"]
    return [
        router_flow_summary(router),
        f"- 채워야할 정보: WS필요 {router.get('need_ws','-')} / micro필요 {router.get('need_micro','-')} / fresh회복 {router.get('fresh_recovered','-')}",
        f"- 순환상태: rotation pool {router.get('rotation_pool_count','-')} / 이번순환 {router.get('rotation_export_count','-')} / 다음커서 {router.get('next_rotation_cursor','-')}",
        f"- 보호슬롯: 전략요청 {router.get('strategy_req_total_count','-')} / 강제보호 {router.get('strategy_req_forced_active_count','-')} / micro요청 {router.get('strategy_req_micro_target_count','-')}",
    ]


def health_text()->str:
    # v340: health는 기본 상태판이므로 v338 형식 유지. worker 시작/재시작/직접계산 금지.
    update_brain_status('running')
    workers=[worker_status(k) for k in WORKERS]
    res=resource_snapshot()
    paper=load_json(FILES['paper_status'],{}) or {}
    ws=load_json(FILES['ws_status'],{}) or {}
    micro=load_json(FILES['micro_status'],{}) or {}
    strat=load_json(FILES['strategy_summary'],{}) or {}
    reject=load_json(FILES['strategy_reject'],{}) or {}
    oflow=load_json(FILES['orderflow'],{}) or {}
    router=load_json(FILES['target_router'],{}) or {}
    good=sum(1 for w in workers if worker_ok(w)=='✅')
    warn=sum(1 for w in workers if worker_ok(w)=='⚠️')
    bad=sum(1 for w in workers if worker_ok(w)=='❌')
    evaluated = int(fnum(reject.get('evaluated') or strat.get('evaluated') or 0, 0))
    quote_ready = int(fnum(strat.get('quote_ready_count') or reject.get('quote_ready_count') or oflow.get('quote_fresh') or 0, 0))
    micro_ready = int(fnum(strat.get('micro_ready_count') or reject.get('micro_ready_count') or oflow.get('fresh_micro') or 0, 0))
    full_ready = int(fnum(strat.get('full_info_ready_count') or reject.get('full_info_ready_count') or oflow.get('info_ready') or 0, 0))
    sent_count = router.get('export_count', router.get('active_target_count', router.get('target_count','-')))
    lines=[
        "🧭 건강상태 /health",
        f"✅ 메인봇 {BOT_VERSION} / clean worker hub v369 / uptime {int(now_ts()-START_TS)}s",
        "",
        "[한눈요약 · 기존 health 값 유지]",
        f"✅ 전체 {evaluated or '-'}개 평가 / 시세 {quote_ready}/{evaluated or '-'} / 호가·체결 {micro_ready}/{evaluated or '-'} / 둘다 {full_ready}/{evaluated or '-'}",
        f"✅ 배차 전체 {router.get('queue_count','-')}개 → 이번내보냄 {sent_count}개 / 순환대기 {router.get('rotation_wait_count','-')}개 / 버림 {router.get('dropped_count',0)}개",
        f"✅ worker 정상 {good}개 / 주의 {warn}개 / 문제 {bad}개",
        f"✅ 오류 없음 기준은 /errorlog / 메모리 {res.get('mem_used_pct','-')}% / load {res.get('load','-')}",
        "",
        f"- worker: ✅ {good} / ⚠️ {warn} / ❌ {bad}",
        f"- paper: {paper.get('version','-')} / OPEN {paper.get('open_count', paper.get('open_total','-'))} / age {age(FILES['paper_status']):.1f}s",
        f"- WS: age {age(FILES['ws_status']):.1f}s / cache {ws.get('cache', ws.get('cache_count','-'))} / fresh {ws.get('fresh','-')}",
        f"- micro: age {age(FILES['micro_status']):.1f}s / targets {micro.get('targets','-')} / batch {micro.get('poll_batch','-')} / cached {micro.get('cached','-')} / fresh {micro.get('fresh','-')}",
        f"- orderflow: quote {oflow.get('quote_fresh','-')} / micro {oflow.get('fresh_micro','-')} / ready {oflow.get('info_ready','-')} / active {oflow.get('active_count','-')}",
        router_flow_summary(router),
        f"- S 후보 {strat.get('s_count',0)} / 평가 {reject.get('evaluated','-')} / 탈락 {reject.get('reject_count','-')}",
        f"- 디스크 {res.get('disk_used_pct','-')}% / 남음 {res.get('disk_free_gb','-')}GB / 메모리 {res.get('mem_used_pct','-')}% / load {res.get('load','-')}",
        "",
        "[worker 요약]",
    ]
    lines += [line_worker(w, detail=False) for w in workers]
    lines += ["", "[원칙] 메인봇은 worker cache만 읽음. worker 실행/재시작은 가드봇 systemd 전담."]
    return "\n".join(lines)

def _worker_metric_int(st: Dict[str, Any], *keys: str) -> Any:
    raw = st.get('raw') if isinstance(st.get('raw'), dict) else {}
    for k in keys:
        v = raw.get(k)
        if v not in (None, '', '-'):
            return v
    return '-'

def workers_text()->str:
    update_brain_status('running')
    workers={k:worker_status(k) for k in WORKERS}
    router=load_json(FILES['target_router'],{}) or {}
    strat=load_json(FILES['strategy_summary'],{}) or {}
    oflow=load_json(FILES['orderflow'],{}) or {}
    scanner=workers.get('scanner',{})
    feature=workers.get('feature',{})
    candle=workers.get('candle',{})
    market=workers.get('market',{})
    orderflow=workers.get('orderflow',{})
    risk=workers.get('risk',{})
    strategy=workers.get('strategy',{})
    target=workers.get('target_router',{})
    review=workers.get('review',{})
    lines=["🧩 worker 상태 /workers", "- 메인봇은 상태파일만 읽고 worker를 직접 실행하지 않음.", "", "[시장/재료]"]
    lines.append(f"- {worker_ok(scanner)} 스캐너: 전체 {_worker_metric_int(scanner,'row_count','pool_count')}개 수집 / {scanner.get('last_sec','-')}초")
    lines.append(f"- {worker_ok(feature)} 특징: {_worker_metric_int(feature,'row_count')}개 표준값 / {feature.get('last_sec','-')}초")
    lines.append(f"- {worker_ok(candle)} 캔들: {_worker_metric_int(candle,'row_count')}개 보강 / target {_worker_metric_int(candle,'target_count')} / {candle.get('last_sec','-')}초")
    lines.append(f"- {worker_ok(market)} 장세: {_worker_metric_int(market,'row_count')}개 확인 / {market.get('last_sec','-')}초")
    lines += ["", "[정보 보강]"]
    lines.append(f"- {worker_ok(orderflow)} 호가요약: 전체 {_worker_metric_int(orderflow,'row_count')}개 / WS {_worker_metric_int(orderflow,'fresh_ws')} / micro {_worker_metric_int(orderflow,'fresh_micro')} / {orderflow.get('last_sec','-')}초")
    lines.append(f"- {worker_ok(target)} 정보배차: 전체 {router.get('queue_count','-')}개 → 내보냄 {router.get('export_count',router.get('active_target_count','-'))}개 / 순환대기 {router.get('rotation_wait_count','-')} / 버림 {router.get('dropped_count',0)}")
    lines += ["", "[판정/복기]"]
    # v346: strategy status가 순간적으로 rows 0으로 보일 때 summary 캐시 기준값으로 보정 표시.
    # 상태 판단은 worker status를 쓰되, 숫자 표시는 clean_strategy_s_summary / reject summary까지 같이 본다.
    reject_sum = load_json(FILES['strategy_reject'], {}) or {}
    st_eval = _worker_metric_int(strategy,'evaluated','row_count')
    if st_eval in ('-', None, '', 0, '0'):
        st_eval = strat.get('evaluated') or reject_sum.get('evaluated') or '-'
    st_s = _worker_metric_int(strategy,'s_count')
    if st_s in ('-', None, ''):
        st_s = strat.get('s_count', 0)
    st_pending = _worker_metric_int(strategy,'info_pending_count')
    if st_pending in ('-', None, ''):
        st_pending = strat.get('info_pending_count') or reject_sum.get('info_pending_count') or 0
    st_sec = strategy.get('last_sec','-')
    if st_sec in ('-', None, '', 0, '0'):
        st_sec = strat.get('last_sec') or reject_sum.get('last_sec') or st_sec
    lines.append(f"- {worker_ok(strategy)} 전략판정: 평가 {st_eval}개 / S {st_s}개 / 정보대기 {st_pending}개 / {st_sec}초")
    lines.append(f"- {worker_ok(risk)} 위험: 최근손실/쿨다운 확인 / {risk.get('last_sec','-')}초")
    lines.append(f"- {worker_ok(review)} 복기: 최근완료 {_worker_metric_int(review,'closed_recent')}개 / 큰손실 {_worker_metric_int(review,'big_loss')} / 좋은승리 {_worker_metric_int(review,'good_win')} / {review.get('last_sec','-')}초")
    lines += ["", "[상세 원본]"]
    lines += [line_worker(workers[k], detail=True) for k in WORKERS]
    return "\n".join(lines)

def _paper_score_cache_version_ok(ver: str) -> bool:
    """v355: paper score cache gate 단일화.

    기존 v354는 허용 버전을 v0.86~v0.92 목록으로 박아두어 paper_bot이 v0.95로
    올라가면 같은 current-version score cache도 구버전으로 오판했다.
    이제 schema/scope는 그대로 엄격히 보되, paper_bot_v0.86 이상은 버전 숫자로 판정한다.
    구 v0.77/v0.80 계열 cache가 섞이지 않게 86 미만은 계속 차단한다.
    """
    m = re.search(r"paper_bot_v0\.(\d+)", str(ver or ""))
    if not m:
        return False
    return int(m.group(1)) >= 86


def _current_paper_score_cache() -> Dict[str, Any]:
    """v355: /score는 현재판 paper score cache만 읽는다.

    오래된 직접계산 fallback은 쓰지 않는다. 다만 paper_bot 버전이 올라갈 때마다
    메인봇 허용목록을 손으로 추가해야 하는 구경로는 제거했다.
    """
    c = load_json(FILES['paper_score'], {}) or {}
    if not isinstance(c, dict):
        return {}
    if not _paper_score_cache_version_ok(str(c.get('version') or '')):
        return {}
    if str(c.get('schema') or '') != 'paper_score_cache_v086':
        return {}
    if str(c.get('score_scope') or '') != 'current_version_anchor':
        return {}
    if c.get('current_closed_count') is None:
        return {}
    return c


def _score_stat_line(label: str, st: Dict[str, Any]) -> str:
    if not isinstance(st, dict):
        st = {}
    n = int(fnum(st.get('n', st.get('count', 0)), default=0))
    wins = int(fnum(st.get('wins', 0), default=0))
    losses = int(fnum(st.get('losses', 0), default=0))
    wr = fnum(st.get('win_rate', st.get('win_rate_pct', 0)), default=0.0)
    total = fnum(st.get('total', st.get('total_pct', st.get('profit_sum', 0))), default=0.0)
    avg = fnum(st.get('avg', st.get('avg_pct', 0)), default=0.0)
    return f"- {label}: {n}전 {wins}승 {losses}패 / 승률 {wr:.1f}% / 합산 {total:+.2f}% / 평균 {avg:+.2f}%"



def score_text()->str:
    cache = _current_paper_score_cache()
    raw = load_json(FILES['paper_score'], {}) or {}
    lines=["📊 전략별 스코어 /score", "- 목적: 닫힌 paper 결과를 대표전략 기준으로 본다. 중복태그 성과는 참고용."]
    label_map={'money_reaccel_s':'돈흐름 재가속','leader_momentum_s':'주도추세 지속','breakout_early_s':'돌파 초입','sweep_vwap_recovery_s':'저점 VWAP 회복','surge_rebreak_s':'급등 후 재돌파','leader_flow_adaptive_hold_s':'주도흐름 유동보유'}
    if cache:
        gs = cache.get('grade_stats') if isinstance(cache.get('grade_stats'), dict) else {}
        current_n=int(fnum(cache.get('current_closed_count') or 0,0))
        primary_stats = cache.get('strategy_primary_stats') if isinstance(cache.get('strategy_primary_stats'), list) else cache.get('strategy_s_stats') if isinstance(cache.get('strategy_s_stats'), list) else []
        overlap_stats = cache.get('strategy_overlap_stats') if isinstance(cache.get('strategy_overlap_stats'), list) else []
        primary_total=int(fnum(cache.get('strategy_primary_total') or sum(int(fnum(x.get('n') or 0,0)) for x in primary_stats if isinstance(x,dict)),0))
        overlap_total=int(fnum(cache.get('strategy_overlap_total') or sum(int(fnum(x.get('n') or 0,0)) for x in overlap_stats if isinstance(x,dict)),0))
        lines.append(f"- 캐시 age {age(FILES['paper_score']):.1f}s / 현재판 CLOSED {current_n}개 / 대표전략 집계 {primary_total}개")
        lines += [
            _score_stat_line('✅ S 전체', gs.get('S', {})),
            _score_stat_line('현재판 전체', gs.get('ALL', {})),
        ]
        lines += ["", "[대표전략 기준 · 실제 거래수와 맞는 성과]"]
        stat_map={str(st.get('key') or st.get('label') or ''):st for st in primary_stats if isinstance(st,dict)}
        for key,label in label_map.items():
            lines.append(_score_stat_line(label, stat_map.get(key, {})))
        if overlap_stats:
            lines += ["", f"[중복태그 포함 · 참고용 / 합계 {overlap_total}개]"]
            over_map={str(st.get('key') or st.get('label') or ''):st for st in overlap_stats if isinstance(st,dict)}
            for key,label in label_map.items():
                lines.append(_score_stat_line(label, over_map.get(key, {})))
            if overlap_total > current_n:
                lines.append(f"- ⚠️ 중복태그 때문에 참고용 합계가 CLOSED보다 {overlap_total-current_n}개 많습니다.")
    else:
        old_ver = raw.get('version','없음') if isinstance(raw,dict) else '없음'
        old_schema = raw.get('schema','-') if isinstance(raw,dict) else '-'
        lines.append(f"- ✅ 구 score cache 차단: {old_ver} / {old_schema}")
        lines.append("- 현재판 paper_bot score cache 준비중입니다. 예전 승률·수익률은 기본 /score에 섞지 않습니다.")
    strat=load_json(FILES['strategy_summary'],{}) or {}
    pbh=load_json(FILES['paperbot_handoff'],{}) or {}
    if strat:
        router=load_json(FILES.get('target_router', BASE_DIR/'clean_target_router_queue.json'),{}) or {}
        lines += ["", "[현재 후보/정보 흐름]"]
        lines.append(f"- 현재 S {strat.get('s_count',0)} / latest {strat.get('paper_latest_count',0)} / paper 병합 {pbh.get('merged_fresh','-')} / archive {pbh.get('archive_window','-')}")
        lines.append(f"- 정보: 전체 {strat.get('evaluated','-')}개 / 시세 {strat.get('quote_ready_count','-')} / micro {strat.get('micro_ready_count','-')} / 둘다 {strat.get('full_info_ready_count','-')}")
        lines.append(f"- 배차: 전체 {router.get('queue_count','-')} / 내보냄 {router.get('export_count', router.get('active_target_count','-'))} / 대기 {router.get('rotation_wait_count','-')} / 버림 {router.get('dropped_count',0)}")
    return "\n".join(lines)



def quality_text()->str:
    reject=load_json(FILES['strategy_reject'],{}) or {}; strat=load_json(FILES['strategy_summary'],{}) or {}
    hand=load_json(FILES['paper_handoff'],{}) or {}
    pbh=load_json(FILES['paperbot_handoff'],{}) or {}
    latest_lines=line_count(FILES['paper_latest'])
    archive_lines=line_count(FILES['paper_archive'])
    router=load_json(FILES.get('target_router', BASE_DIR/'clean_target_router_queue.json'),{}) or {}
    evaluated=int(fnum(reject.get('evaluated') or strat.get('evaluated') or 0,0))
    quote=int(fnum(reject.get('quote_ready_count') or strat.get('quote_ready_count') or evaluated,0))
    micro=int(fnum(reject.get('micro_ready_count') or strat.get('micro_ready_count') or 0,0))
    both=int(fnum(reject.get('full_info_ready_count') or strat.get('full_info_ready_count') or min(quote,micro),0))
    not_micro=max(0,evaluated-micro) if evaluated else 0
    dropped=int(fnum(router.get('dropped_count') or 0,0))
    rot_wait=int(fnum(router.get('rotation_wait_count') or 0,0))
    need_micro=int(fnum(router.get('need_micro') or reject.get('info_pending_count') or 0,0))
    lines=[
        "🔍 후보품질 /quality",
        f"✅ 전체 {evaluated}개 평가 / 최종 S {strat.get('s_count',0)}개 / paper latest {latest_lines}줄 / 병합 {pbh.get('merged_fresh','-')}",
        "",
        "[정보가 얼마나 채워졌나]",
        f"- 시세: {quote}/{evaluated}개 / 호가·체결: {micro}/{evaluated}개 / 둘다: {both}/{evaluated}개",
        f"- 아직 micro 미신선: {not_micro}개 / 지금 꼭 필요한 micro: {need_micro}개",
        "",
        "[안 넣은 게 아니라 순환 상태]",
        f"- 전체배차 {router.get('queue_count','-')}개 → 이번내보냄 {router.get('export_count', router.get('active_target_count','-'))}개",
        f"- 순환대기 {rot_wait}개 / 버림 {dropped}개 / safety초과 {router.get('export_over_budget_count',0)}개",
        f"- 최우선 {router.get('priority_protected_count','-')}개 / 보호슬롯 req {router.get('strategy_req_total_count','-')}개 / req_micro_target {router.get('strategy_req_micro_target_count','-')}개",
        "",
        "[후보 판정]",
        f"- cheap탈락 {reject.get('cheap_reject_count','-')} / 정보대기 {reject.get('info_pending_count','-')} / 정보불필요 {reject.get('info_not_requested','-')} / fresh완료 {reject.get('fresh_ready_count','-')}",
        f"- paper 전달: strategy handoff {hand.get('paper_latest_count','-')} / archive {'대형' if archive_lines<0 else str(archive_lines)+'줄'}",
    ]
    evs=strat.get('events') if isinstance(strat.get('events'),list) else []
    cur_s=int(fnum(strat.get('s_count') or 0,0))
    lines += ["", "[현재 최종 S 후보 TOP]" if cur_s else "[latest/handoff 후보 TOP · 현재 S 0이면 보관 후보]"]
    if evs:
        for e in evs[:8]:
            lines.append(f"- {'✅' if cur_s else '❔'} {e.get('ticker')} / {e.get('strategy_bucket_primary_label', e.get('strategy_name'))} / 점수 {e.get('score')} / 근거 {', '.join(e.get('reasons',[])[:4])}")
    else: lines.append("- 없음")
    wait_sample=reject.get('priority_wait_sample') if isinstance(reject.get('priority_wait_sample'),list) else []
    micro_payload=load_json(FILES.get('micro_targets', BASE_DIR/'clean_micro_targets.json'),{}) or {}
    micro_targets=set(str(x).upper() for x in (micro_payload.get('targets') if isinstance(micro_payload.get('targets'),list) else []))
    active_targets=set(str(x).upper() for x in ((router.get('active_targets') or router.get('targets')) if isinstance((router.get('active_targets') or router.get('targets')),list) else []))
    lines += ["", "[정보대기 TOP · 왜 아직 못 들어갔나]"]
    if wait_sample:
        for x in wait_sample[:6]:
            t=str(x.get('ticker') or '').upper(); mt_bool=bool(x.get('micro_target')) or t in micro_targets; act_bool=bool(x.get('router_active')) or t in active_targets
            q='✅' if x.get('quote_ready') else '❌'; m='✅' if x.get('micro_ready') else '❌'; mt='✅' if mt_bool else '❌'; a='✅' if act_bool else '❌'
            if (not mt_bool): why='target 미반영'
            elif not x.get('micro_ready'): why='micro 수집대기'
            else: why='확인필요'
            lines.append(f"- {t}: 시세 {q} / micro {m} / target {mt} / active {a} / {why}")
    else:
        lines.append("- 없음")
    lines += ["", "[탈락 사유 TOP]"]
    tops=reject.get('reason_top') if isinstance(reject.get('reason_top'),list) else []
    for x in tops[:12]:
        reason=str(x.get('reason') or '-')
        icon='⚠️' if ('고점' in reason or '손실' in reason or '매도' in reason or '윗꼬리' in reason) else '❔'
        lines.append(f"- {icon} {reason}: {x.get('count')}")
    if not tops: lines.append("- 아직 없음")
    return "\n".join(lines)


def strategy_watch_text()->str:
    strat=load_json(FILES['strategy_summary'],{}) or {}
    hand=load_json(FILES['paper_handoff'],{}) or {}
    lines=["👀 전략 감시 /strategy_watch", "- 전략별 S만 감시. A/B/C는 기본화면에서 제외.", f"- handoff: latest {hand.get('paper_latest_count','-')} / 새S {hand.get('new_s_count','-')} / append {hand.get('archive_appended','-')}"]
    for k,v in (strat.get('strategies') or {}).items(): lines.append(f"- {k}: S {v}")
    evs=strat.get('events') if isinstance(strat.get('events'),list) else []
    lines += ["", "[OPEN 전달 후보]"]
    if evs:
        for e in evs[:10]: lines.append(f"- ✅ {e.get('ticker')} / {e.get('strategy_bucket_primary_label')} / {e.get('score')} / {', '.join(e.get('reasons',[])[:3])}")
    else: lines.append("- 없음")
    return "\n".join(lines)

def errorlog_text()->str:
    path=FILES['brain_error']
    header="🧯 오류로그 /errorlog"
    if not path.exists():
        return header+"\n\n✅ 새 실행 중 오류 없음"
    txt=path.read_text(encoding='utf-8',errors='ignore')
    lines=txt.splitlines()
    # 로그 형식: [YYYY-MM-DD HH:MM:SS] where: Error
    new_lines=[]; old_lines=[]
    for ln in lines[-300:]:
        ts=0.0
        m=re.match(r"\[(\d{4}-\d{2}-\d{2} \d{2}:\d{2}:\d{2})\]", ln)
        if m:
            try:
                ts=time.mktime(time.strptime(m.group(1), "%Y-%m-%d %H:%M:%S"))
            except Exception:
                ts=0.0
        if ts and ts >= START_TS:
            new_lines.append(ln)
        elif '[' in ln:
            old_lines.append(ln)
    out=[header]
    if new_lines:
        out += ["", "❌ 새 실행 이후 오류", *new_lines[-10:]]
    else:
        out += ["", "✅ 새 실행 중 오류 없음"]
        if old_lines:
            out.append(f"- 과거 오류 흔적 {len(old_lines)}줄 있음 / 최근 2개만 참고")
            out += old_lines[-2:]
    return "\n".join(out)

def open_text()->str:
    obj=load_json(FILES['paper_open'],{}) or {}
    lines=["📂 OPEN 요약 /popen_short"]
    if not obj: return "\n".join(lines+["- OPEN 없음"])
    for _,p in list(obj.items())[:12]: lines.append(f"- {p.get('ticker')} / {p.get('strategy_name',p.get('strategy_key','-'))} / {p.get('profit_pct',p.get('current_profit_pct','-'))}%")
    return "\n".join(lines)



def _rows_for_pipe(obj:Any)->List[Any]:
    if isinstance(obj,list): return obj
    if isinstance(obj,dict):
        for k in ("rows","items","targets","active","active_rows","queue","data","symbols"):
            if isinstance(obj.get(k),list): return obj.get(k)
    return []

def _sym_for_pipe(x:Any)->str:
    if isinstance(x,str): v=x
    elif isinstance(x,dict): v=x.get("symbol") or x.get("ticker") or x.get("market") or x.get("coin") or x.get("code") or ""
    else: v=""
    return str(v).replace("KRW-","").replace("_KRW","").replace("/KRW","").upper()

def _set_from_file(path:Path)->set:
    return {_sym_for_pipe(r) for r in _rows_for_pipe(load_json(path,{}) or {}) if _sym_for_pipe(r)}

def pipe_check_text()->str:
    update_brain_status('running')
    paths={
        'ws_targets': BASE_DIR/'clean_ws_targets.json',
        'micro_targets': BASE_DIR/'clean_micro_targets.json',
        'router': BASE_DIR/'clean_target_router_queue.json',
        'strategy_req': BASE_DIR/'clean_strategy_priority_requests.json',
        'strategy': BASE_DIR/'clean_strategy_s_reject_summary.json',
        'orderflow': BASE_DIR/'clean_orderflow_summary_cache.json',
        'ws_status': FILES['ws_status'],
        'micro_status': FILES['micro_status'],
    }
    sets={k:_set_from_file(p) for k,p in paths.items()}
    router=load_json(paths['router'],{}) or {}; reject=load_json(paths['strategy'],{}) or {}; req=load_json(paths['strategy_req'],{}) or {}; of=load_json(paths['orderflow'],{}) or {}; ws=load_json(paths['ws_status'],{}) or {}; mi=load_json(paths['micro_status'],{}) or {}
    of_rows=_rows_for_pipe(of)
    quote_ready=sum(1 for r in of_rows if isinstance(r,dict) and (r.get('quote_fresh') or r.get('ws_fresh')))
    micro_ready=sum(1 for r in of_rows if isinstance(r,dict) and r.get('micro_fresh'))
    full_ready=sum(1 for r in of_rows if isinstance(r,dict) and (r.get('info_ready') or ((r.get('quote_fresh') or r.get('ws_fresh')) and r.get('micro_fresh'))))
    active_ready=sum(1 for r in of_rows if isinstance(r,dict) and r.get('router_active') and (r.get('info_ready') or ((r.get('quote_fresh') or r.get('ws_fresh')) and r.get('micro_fresh'))))
    lines=["🧪 정보배관 점검 /pipe_check", "- SSH 없이 target → orderflow → strategy 병합 상태만 봅니다."]
    lines.append(f"- WS 상태: age {age(paths['ws_status']):.1f}s / fresh {ws.get('fresh','-')} / targets {len(sets['ws_targets'])}")
    lines.append(f"- micro 상태: age {age(paths['micro_status']):.1f}s / fresh {mi.get('fresh','-')} / targets {mi.get('targets','-')} / target파일 {len(sets['micro_targets'])}")
    lines.append(f"- orderflow: rows {len(of_rows)} / quote준비 {quote_ready} / micro준비 {micro_ready} / 둘다준비 {full_ready} / active준비 {active_ready}")
    lines.append(router_flow_summary(router))
    lines.append(f"- router 세부: 이번순환 {router.get('rotation_export_count','-')} / 순환대기 {router.get('rotation_wait_count','-')} / 버림 {router.get('dropped_count',0)} / fresh회복 {router.get('fresh_recovered','-')}")
    lines.append(f"- strategy: 평가 {reject.get('evaluated','-')} / cheap탈락 {reject.get('cheap_reject_count','-')} / 정보필요 {reject.get('info_needed_count','-')} / 정보대기 {reject.get('info_pending_count','-')} / fresh완료 {reject.get('fresh_ready_count','-')} / 병합 {reject.get('orderflow_attached_count','-')}")
    lines.append("")
    checks=[('ws_targets','orderflow'),('micro_targets','orderflow'),('router','ws_targets'),('router','micro_targets'),('strategy_req','orderflow')]
    for a,b in checks:
        lines.append(f"- 겹침 {a}↔{b}: {len(sets[a] & sets[b])}")
    lines.append("")
    if len(sets['ws_targets']) and len(sets['ws_targets'] & sets['orderflow']): lines.append("✅ WS target은 orderflow에 심볼 기준 붙음")
    elif len(sets['ws_targets']): lines.append("❌ WS target은 있으나 orderflow에 심볼이 안 붙음")
    else: lines.append("⚠️ WS active target 없음")
    if len(sets['micro_targets']) and len(sets['micro_targets'] & sets['orderflow']): lines.append("✅ micro target은 orderflow에 심볼 기준 붙음")
    elif len(sets['micro_targets']): lines.append("❌ micro target은 있으나 orderflow에 심볼이 안 붙음")
    else: lines.append("⚠️ micro active target 없음")
    # 전략 요청 후보를 개별로 짧게 보여준다. 흐름이 막히면 여기서 quote/micro/target 중 무엇이 빠졌는지 바로 보인다.
    of_map = { _sym_for_pipe(r): r for r in of_rows if isinstance(r, dict) and _sym_for_pipe(r) }
    req_rows = _rows_for_pipe(req)
    if isinstance(req, dict) and isinstance(req.get('requests'), list):
        req_rows = req.get('requests')
    if req_rows:
        lines += ["", "[전략요청 후보 상태]"]
        for r in req_rows[:8]:
            t=_sym_for_pipe(r)
            ofr=of_map.get(t,{})
            q=bool(ofr.get('quote_fresh') or ofr.get('ws_fresh'))
            m=bool(ofr.get('micro_fresh'))
            a=t in sets['micro_targets']
            active=bool(ofr.get('router_active'))
            qicon='✅' if q else '❌'
            micon='✅' if m else '❌'
            ticon='✅' if a else '❌'
            aicon='✅' if active else '❌'
            need = r.get('need') if isinstance(r,dict) and isinstance(r.get('need'),list) else []
            why=''
            if not a:
                why=' / 원인 microTarget 미반영'
            elif not active:
                why=' / 원인 orderflow active 미표시'
            elif not m:
                why=' / 원인 micro 수집대기'
            lines.append(f"- {t}: quote {qicon} / micro {micon} / microTarget {ticon} / active {aicon} / {r.get('bucket','-') if isinstance(r,dict) else '-'} / need {','.join(need)}{why}")
    if full_ready:
        lines.append("✅ orderflow canonical 정보가 준비된 후보 있음")
    else:
        lines.append("⚠️ orderflow canonical 둘다준비 후보 없음: micro/quote 중 하나가 부족")
    lines.append("- 판단: v340 기준: strategy는 quote_fresh(WS 또는 scanner REST)+micro_fresh를 기준으로 보고, S근접 micro 대기는 우선배차로 따로 추적합니다.")
    return "\n".join(lines)


# -----------------------------
# v343: 메인봇에서 paper 복기/성과 명령을 캐시 전용으로 읽는다.
# paper_bot은 실행/장부/알림 담당, 메인봇은 사용자가 한 방에서 볼 수 있게 요약만 읽는다.
# -----------------------------
STRATEGY_LABELS = {
    'money_reaccel_s': '돈흐름 재가속',
    'leader_momentum_s': '주도추세 지속',
    'breakout_early_s': '돌파 초입',
    'sweep_vwap_recovery_s': '저점 VWAP 회복',
    'surge_rebreak_s': '급등 후 재돌파',
    'leader_flow_adaptive_hold_s': '주도흐름 유동보유',
}

def _short_ticker(v: Any) -> str:
    return str(v or '').upper().replace('KRW-', '').replace('_KRW', '').replace('/KRW', '').replace('KRW', '').strip()

def _paper_open_positions() -> Dict[str, Dict[str, Any]]:
    obj = load_json(FILES['paper_open'], {}) or {}
    return obj if isinstance(obj, dict) else {}

def _paper_score_cache_current() -> Dict[str, Any]:
    return _current_paper_score_cache()

def _stat_line(label: str, st: Dict[str, Any]) -> str:
    return _score_stat_line(label, st)

def _paper_strategy_label(row_or_key: Any) -> str:
    if isinstance(row_or_key, dict):
        k = str(row_or_key.get('strategy_key') or row_or_key.get('primary_strategy_key') or row_or_key.get('representative_strategy_key') or '')
        name = str(row_or_key.get('strategy_bucket_primary_label') or row_or_key.get('strategy_name') or row_or_key.get('strategy') or '')
        if k in STRATEGY_LABELS:
            return STRATEGY_LABELS[k]
        for kk, vv in STRATEGY_LABELS.items():
            if vv in name:
                return vv
        return name or '-'
    k = str(row_or_key or '')
    return STRATEGY_LABELS.get(k, k or '-')

def _paper_grade(row: Dict[str, Any]) -> str:
    g = str(row.get('grade') or row.get('entry_grade') or row.get('signal_grade') or 'S').upper()
    return g if g else 'S'

def pstatus_text() -> str:
    status = load_json(FILES['paper_status'], {}) or {}
    open_pos = _paper_open_positions()
    cache = _paper_score_cache_current()
    hand = load_json(FILES['paperbot_handoff'], {}) or {}
    grade_counts = Counter(_paper_grade(p) for p in open_pos.values() if isinstance(p, dict))
    lines = [
        '🧪 paper 상태 /pstatus · 메인봇 캐시전용',
        '- paper_bot 명령을 메인봇방에서 읽는 요약입니다. 실행/장부/알림은 paper_bot 담당.',
        f"- 상태: {'ON' if status.get('running', True) else '확인필요'} / loop {status.get('loop_sec', status.get('loop_interval_sec', '-'))}s / OPEN {len(open_pos)} / age {age(FILES['paper_status']):.1f}s",
        f"- OPEN: S {grade_counts.get('S',0)} / A {grade_counts.get('A',0)} / B {grade_counts.get('B',0)} / C {grade_counts.get('C',0)} / 제외 {grade_counts.get('X',0)}",
        f"- handoff: latest {hand.get('latest_count', hand.get('paper_latest_count','-'))} / archive창 {hand.get('archive_window','-')} / 병합fresh {hand.get('merged_fresh','-')}",
        f"- 선별배관: 읽음 {status.get('pick_stats',{}).get('paper_file','-') if isinstance(status.get('pick_stats'),dict) else '-'} / S1선택 {status.get('pick_stats',{}).get('v369_s1_selected', status.get('pick_stats',{}).get('v368_s1_open','-')) if isinstance(status.get('pick_stats'),dict) else '-'} / S2보류 {status.get('pick_stats',{}).get('v369_s2_trace','-') if isinstance(status.get('pick_stats'),dict) else '-'} / S3관찰 {status.get('pick_stats',{}).get('v369_s3_trace','-') if isinstance(status.get('pick_stats'),dict) else '-'} / 실제OPEN {status.get('opened_this_cycle','-')}",
    ]
    if cache:
        gs = cache.get('grade_stats') if isinstance(cache.get('grade_stats'), dict) else {}
        current_n = int(fnum(cache.get('current_closed_count') or 0, 0))
        primary_total = int(fnum(cache.get('strategy_primary_total') or 0, 0))
        lines += [
            f"- 성과범위: 현재판 앵커 이후 / {cache.get('anchor_text','-')} / CLOSED {current_n}개 / 대표전략 집계 {primary_total}개",
            '[현재판 성과]',
            _stat_line('✅ S', gs.get('S', {})),
            _stat_line('현재판 전체', gs.get('ALL', {})),
            '- 전략별 상세는 /pscore 또는 /score',
        ]
    else:
        raw = load_json(FILES['paper_score'], {}) or {}
        lines += [
            '- 현재판 score cache 준비중',
            f"- 구버전 성과캐시 무시: {raw.get('version','-')} / {raw.get('schema','-')}",
        ]
    return '\n'.join(lines)

def pscore_text() -> str:
    # 메인봇 /score와 같은 현재판 cache를 사용하되 paper 명령 이름으로 보여준다.
    txt = score_text()
    return txt.replace('📊 전략별 스코어 /score', '📊 paper 전략별 스코어 /pscore · 메인봇 캐시전용', 1)

def _pos_profit_pct(pos: Dict[str, Any]) -> float:
    for k in ('pnl_pct','profit_pct','current_profit_pct','unrealized_pct'):
        if pos.get(k) not in (None, ''):
            return fnum(pos.get(k), 0.0)
    entry = fnum(pos.get('entry_price'), 0.0)
    cur = fnum(pos.get('current_price') or pos.get('last_price'), 0.0)
    if entry > 0 and cur > 0:
        return (cur - entry) / entry * 100.0
    return 0.0

def _pos_entry_price(pos: Dict[str, Any]) -> str:
    v = pos.get('entry_price') or pos.get('entry') or '-'
    try:
        fv = float(str(v).replace(',', ''))
        if fv >= 1000:
            return f"{fv:,.0f}"
        return f"{fv:.4f}"
    except Exception:
        return str(v)

def _pos_current_price(pos: Dict[str, Any]) -> str:
    v = pos.get('current_price') or pos.get('last_price') or pos.get('entry_price') or '-'
    try:
        fv = float(str(v).replace(',', ''))
        if fv >= 1000:
            return f"{fv:,.0f}"
        return f"{fv:.4f}"
    except Exception:
        return str(v)

def _pos_snapshot_flat(pos: Dict[str, Any]) -> Dict[str, Any]:
    ctx = pos.get('entry_context') if isinstance(pos.get('entry_context'), dict) else {}
    snap = ctx.get('entry_snapshot') if isinstance(ctx.get('entry_snapshot'), dict) else pos.get('entry_snapshot') if isinstance(pos.get('entry_snapshot'), dict) else {}
    vals: Dict[str, Any] = {}
    if isinstance(snap, dict):
        flat = snap.get('flat')
        if isinstance(flat, dict): vals.update(flat)
        for gname in ('price_flow','position','money_flow','orderflow','risk','strategy'):
            g = snap.get(gname)
            if isinstance(g, dict):
                for k, v in g.items(): vals.setdefault(k, v)
    if isinstance(ctx, dict):
        for k, v in ctx.items(): vals.setdefault(k, v)
    for k, v in pos.items():
        if k not in vals and k not in {'entry_context','entry_snapshot'}:
            vals[k] = v
    return vals

def _pos_hold_sec(pos: Dict[str, Any]) -> float:
    for k in ('hold_sec','age_sec'):
        v = fnum(pos.get(k), default=-1.0)
        if v > 0:
            return v
    for k in ('opened_at','entry_ts','open_ts','opened_ts','created_at','start_ts'):
        v = pos.get(k)
        ts = fnum(v, default=0.0)
        if ts > 10_000_000_000:
            ts = ts / 1000.0
        if ts <= 0 and isinstance(v, str):
            try:
                # ISO/text time fallback. timezone 없는 서버 로컬 기준.
                ts = time.mktime(time.strptime(v[:19].replace('T',' '), '%Y-%m-%d %H:%M:%S'))
            except Exception:
                ts = 0.0
        if ts > 0:
            return max(0.0, now_ts() - ts)
    return 0.0

def popen_text() -> str:
    open_pos = _paper_open_positions()
    lines = ['📂 paper OPEN /popen · 메인봇 캐시전용']
    if not open_pos:
        return '\n'.join(lines + ['OPEN 없음'])
    rows = [p for p in open_pos.values() if isinstance(p, dict)]
    rows.sort(key=lambda p: fnum(p.get('opened_at') or p.get('entry_ts') or 0, 0), reverse=True)
    by_strategy = Counter(_paper_strategy_label(p) for p in rows)
    lines.append('전략별 OPEN: ' + ' / '.join(f'{k} {v}' for k, v in by_strategy.items()))
    for p in rows[:10]:
        t = _short_ticker(p.get('ticker') or p.get('symbol'))
        pnl = _pos_profit_pct(p)
        hold = _pos_hold_sec(p)
        vals = _pos_snapshot_flat(p)
        buy = vals.get('buy_ratio') or vals.get('micro_trade_buy_ratio_30') or '-'
        reason = p.get('reason') or p.get('entry_reason') or p.get('watch_note') or 'time_exit 대기'
        try: buy_txt = f"{float(buy):.2f}"
        except Exception: buy_txt = str(buy)
        lines.append(f"- ✅ {_paper_grade(p)}급 {t} / {_paper_strategy_label(p)} / 진입 {_pos_entry_price(p)} / 현재 {_pos_current_price(p)} / {pnl:+.2f}% / 보유 {int(hold//60)}분 {int(hold%60)}초 / 감시 {reason}")
        lines.append(f"  · 근거: 매수체결 {buy_txt} / 주의: {p.get('risk_label') or p.get('risk_tags') or '특이사항 없음'}")
    if len(rows) > 10:
        lines.append(f"- 나머지 {len(rows)-10}개는 paper_bot /popen 단독 또는 이후 full에서 확인")
    return '\n'.join(lines)


# =============================================================================
# v347: paper review canonical module
# - 기존 v341~v346에서 덧붙은 preview/missed_review override들을 제거하고
#   단일 canonical 경로로 재작성한다.
# - 목적: /preview가 어떤 필드 타입(dict/float/list/None)을 만나도 죽지 않게 하고,
#   놓친 후보 추적/손실 복기 판단을 한 곳에서만 수행한다.
# =============================================================================

def as_dict(v: Any) -> Dict[str, Any]:
    return v if isinstance(v, dict) else {}

def as_list(v: Any) -> List[Any]:
    if isinstance(v, list):
        return v
    if isinstance(v, tuple):
        return list(v)
    return []

def first_value(*vals: Any, default: Any = None) -> Any:
    for v in vals:
        if v is None or v == "":
            continue
        return v
    return default

def price_from_any(v: Any) -> float:
    """dict/float/int/str/list 어떤 형태든 current price 후보를 안전하게 숫자로 변환."""
    if isinstance(v, dict):
        return fnum(v.get('current_price'), v.get('price'), v.get('trade_price'), v.get('close'), v.get('last'), default=0.0)
    if isinstance(v, (int, float, str)):
        return fnum(v, default=0.0)
    return 0.0

def _event_ts(ev: Dict[str, Any]) -> float:
    row = as_dict(ev)
    return fnum(
        row.get('candidate_created_at'), row.get('source_created_at'), row.get('detected_ts'),
        row.get('event_ts'), row.get('created_at'), row.get('timestamp'), default=0.0
    )

def _primary_strategy_key(row: Dict[str, Any]) -> str:
    row = as_dict(row)
    ctx = as_dict(row.get('entry_context'))
    snap = as_dict(row.get('entry_snapshot') or ctx.get('entry_snapshot'))
    strat = as_dict(snap.get('strategy'))
    candidates = [
        row.get('representative_strategy_key'), row.get('primary_strategy_key'), row.get('paper_strategy_key'),
        row.get('strategy_bucket_primary'), row.get('strategy_key'), row.get('strategy'), row.get('strategy_name'),
        row.get('strategy_label'), row.get('strategy_bucket_primary_label'),
        ctx.get('representative_strategy_key'), ctx.get('primary_strategy_key'), ctx.get('paper_strategy_key'),
        ctx.get('strategy_bucket_primary'), ctx.get('strategy_key'), ctx.get('strategy'), ctx.get('strategy_name'),
        ctx.get('strategy_bucket_primary_label'), strat.get('primary_key'), strat.get('primary_label')
    ]
    for v in candidates:
        text = str(v or '')
        if not text:
            continue
        if text in STRATEGY_LABELS:
            return text
        for k, label in STRATEGY_LABELS.items():
            if k in text or label in text or f'{label} S' in text:
                return k
    for vals in (
        row.get('multi_strategy_s'), row.get('strategy_bucket_keys'), ctx.get('multi_strategy_s'),
        ctx.get('strategy_bucket_keys'), strat.get('tags')
    ):
        for x in as_list(vals):
            text = str(x or '')
            if text in STRATEGY_LABELS:
                return text
            for k, label in STRATEGY_LABELS.items():
                if k in text or label in text:
                    return k
    return 'unknown'

def _paper_anchor_ts() -> float:
    c = _paper_score_cache_current()
    if isinstance(c, dict) and c:
        return fnum(c.get('anchor_ts'), c.get('current_anchor_ts'), default=0.0)
    a = load_json(FILES.get('score_anchor', BASE_DIR/'paper_bot_current_score_anchor.json'), {}) or {}
    return fnum(as_dict(a).get('anchor_ts'), default=0.0)

def _paper_current_closed_rows(max_lines:int=2600) -> List[Dict[str, Any]]:
    rows = read_jsonl(FILES.get('paper_closed', BASE_DIR/'paper_bot_closed.jsonl'), max_lines=max_lines)
    anchor = _paper_anchor_ts()
    if not anchor:
        return rows
    out=[]
    for r in rows:
        if not isinstance(r, dict):
            continue
        ts = fnum(r.get('closed_at'), r.get('closed_ts'), r.get('close_ts'), r.get('timestamp'), default=0.0)
        ots = fnum(r.get('opened_at'), r.get('entry_ts'), r.get('open_ts'), default=0.0)
        if max(ts, ots) >= anchor:
            out.append(r)
    return out

def _snapshot_flat(row: Dict[str, Any]) -> Dict[str, Any]:
    """entry_context/entry_snapshot nested group을 안전하게 평탄화한다."""
    row = as_dict(row)
    ctx = as_dict(row.get('entry_context'))
    snap = as_dict(row.get('entry_snapshot') or ctx.get('entry_snapshot'))
    vals: Dict[str, Any] = {}
    for gname in ('price_flow','position','money_flow','orderflow','risk','strategy'):
        g = as_dict(snap.get(gname))
        vals.update({k:v for k,v in g.items() if k not in vals})
    vals.update({k:v for k,v in ctx.items() if k not in vals and k != 'entry_snapshot'})
    vals.update({k:v for k,v in row.items() if k not in vals and k not in {'entry_context','entry_snapshot'}})
    return vals

def _loss_causes(row: Dict[str, Any]) -> List[str]:
    row = as_dict(row); ctx=_snapshot_flat(row)
    causes=[]
    pnl=fnum(row.get('pnl_pct'), row.get('profit_pct'), row.get('return_pct'), default=0.0)
    peak=fnum(row.get('peak_pct'), row.get('max_profit_pct'), row.get('max_pnl_pct'), default=0.0)
    trough=fnum(row.get('trough_pct'), row.get('min_profit_pct'), row.get('min_pnl_pct'), default=0.0)
    hold=fnum(row.get('hold_sec'), row.get('duration_sec'), default=0.0)
    spread=fnum(ctx.get('spread_pct'), default=-1.0)
    buy=fnum(ctx.get('buy_ratio'), ctx.get('micro_trade_buy_ratio_30'), ctx.get('buy_trade_ratio'), default=-1.0)
    buy_s=fnum(ctx.get('buy_ratio_1m'), ctx.get('micro_buy_ratio_sustain_1m'), ctx.get('buy_ratio_sustain'), default=-1.0)
    vwap=fnum(ctx.get('vwap_gap_pct'), default=999.0)
    ema=fnum(ctx.get('ema5_gap_pct'), ctx.get('ema_gap_pct'), default=999.0)
    ch3=fnum(ctx.get('change_3m'), ctx.get('price_change_3m'), default=999.0)
    ch5=fnum(ctx.get('change_5m'), ctx.get('price_change_5m'), default=999.0)
    if pnl < 0:
        if peak <= 0.10: causes.append('진입후반응없음(최고+0.1%이하)')
        elif peak <= 0.30: causes.append('반응약함(최고+0.3%이하)')
        if hold and hold <= 180: causes.append('초반빠른손실(3분이내)')
        if trough <= -0.70: causes.append('깊은역행')
    if spread >= 0.28: causes.append('스프레드넓음')
    if 0 <= buy < 0.65: causes.append('매수체결약함')
    if 0 <= buy_s < 0.60: causes.append('매수체결지속약함')
    if ctx.get('sell_pressure') or ctx.get('ask_wall_pressure') or ctx.get('sell_trade_pressure'):
        causes.append('매도압력')
    if vwap != 999.0 and vwap < -0.15: causes.append('VWAP아래')
    if ema != 999.0 and ema < -0.20: causes.append('EMA아래')
    if ch3 != 999.0 and ch5 != 999.0 and ch3 <= 0.05 and ch5 <= 0.10:
        causes.append('가격반응부족')
    if not any(k in ctx for k in ('change_3m','price_change_3m','vwap_gap_pct','buy_ratio','spread_pct')):
        causes.append('근거스냅샷부족')
    if not causes and pnl < 0:
        causes.append('기타손실')
    # 중복 제거, 순서 유지
    out=[]
    for c in causes:
        if c not in out: out.append(c)
    return out

def ploss_review_text() -> str:
    rows=_paper_current_closed_rows()
    losses=[r for r in rows if fnum(r.get('pnl_pct'), r.get('profit_pct'), default=0.0)<0]
    wins=[r for r in rows if fnum(r.get('pnl_pct'), r.get('profit_pct'), default=0.0)>0]
    cc=Counter(); by={k:[] for k in STRATEGY_LABELS}; sc={k:Counter() for k in STRATEGY_LABELS}; unknown=[]
    for r in losses:
        key=_primary_strategy_key(r)
        if key not in STRATEGY_LABELS:
            unknown.append(r); key='unknown'
        by.setdefault(key,[]).append(r); sc.setdefault(key,Counter())
        for cause in _loss_causes(r):
            cc[cause]+=1; sc[key][cause]+=1
    lines=['🧯 손실 원인 복기 /ploss_review · 메인봇 캐시전용', '- 현재판 CLOSED 손실에서 공통 패배 패턴을 봅니다.', f'- 현재판 CLOSED {len(rows)}개 / 승리 {len(wins)}개 / 손실 {len(losses)}개 / 미분류손실 {len(unknown)}개', '', '[공통 손실 TOP]']
    if cc:
        for k,v in cc.most_common(10): lines.append(f'- ⚠️ {k}: {v}개')
    else:
        lines.append('- 아직 손실 표본 없음')
    lines += ['', '[전략별 손실 원인 · 대표전략 기준]']
    for k,label in STRATEGY_LABELS.items():
        sub=by.get(k,[]); tops=', '.join(f'{a} {b}' for a,b in sc.get(k,Counter()).most_common(3)) or '-'
        lines.append(f'- {label}: 손실 {len(sub)}개 / {tops}')
    if unknown:
        tops=', '.join(f'{a} {b}' for a,b in sc.get('unknown',Counter()).most_common(3)) or '-'
        lines.append(f'- 미분류: 손실 {len(unknown)}개 / {tops}')
    lines += ['', '[조건 설계 힌트]']
    if cc.get('진입후반응없음(최고+0.1%이하)',0) >= max(3, len(losses)*0.25): lines.append('- 진입 전/직후 가격반응 조건을 전략별로 넣을 가치가 큼')
    if cc.get('매수체결약함',0) or cc.get('매수체결지속약함',0): lines.append('- 매수체결 순간값보다 지속성 조건을 봐야 함')
    if cc.get('매도압력',0): lines.append('- 매도벽/매도체결압력은 공통 하드차단이 아니라 전략별 강도 조절 필요')
    if cc.get('근거스냅샷부족',0): lines.append('- 일부 구 OPEN/CLOSED는 snapshot 부족. 신규 snapshot CLOSED를 더 신뢰')
    return '\n'.join(lines)

def _market_price_map() -> Dict[str, Dict[str, Any]]:
    """시장 가격 map을 항상 dict 형태로 반환한다. 기존 float 반환 경로 제거."""
    out: Dict[str, Dict[str, Any]] = {}
    for p in (FILES['scanner_market'], FILES['feature'], FILES['orderflow']):
        obj=load_json(p,{}) or {}; rows=[]
        if isinstance(obj, list):
            rows=obj
        elif isinstance(obj, dict):
            for key in ('rows','items','data'):
                if isinstance(obj.get(key), list):
                    rows=obj.get(key); break
            if not rows and isinstance(obj.get('cache'), dict):
                for k,v in obj.get('cache',{}).items():
                    if isinstance(v,dict):
                        vv=dict(v); vv.setdefault('ticker',k); rows.append(vv)
        for r in rows or []:
            if not isinstance(r,dict):
                continue
            t=norm_ticker(r.get('ticker') or r.get('symbol') or r.get('market'))
            price=price_from_any(r)
            if t and price>0:
                cur=out.setdefault(t, {})
                cur['current_price']=price
                cur.setdefault('source', p.name)
    return out

def _candidate_norm(ev: Dict[str, Any]) -> Dict[str, Any]:
    row=dict(as_dict(ev))
    raw_id = first_value(row.get('event_id'), row.get('event_key'), row.get('trace_id'), row.get('handoff_id'), row.get('candidate_uid'), row.get('id'))
    t=norm_ticker(row.get('ticker') or row.get('market') or row.get('symbol')) or 'UNKNOWN'
    sk=_primary_strategy_key(row) or 'strategy_s'
    ts=_event_ts(row) or now_ts()
    eid=str(raw_id or f"ev:{t}:{sk}:{int(ts//30)}")
    row['event_id']=eid; row['event_key']=eid
    row.setdefault('trace_id', eid); row.setdefault('handoff_id', eid); row.setdefault('candidate_uid', eid)
    if not raw_id:
        row.setdefault('event_id_origin','legacy_fallback')
    return row

def _candidate_keys(ev: Dict[str, Any]) -> set:
    row=_candidate_norm(ev); keys=set()
    for k in ('event_id','event_key','trace_id','handoff_id','candidate_uid','pos_id'):
        v=row.get(k)
        if v not in (None,'','-'): keys.add(str(v))
    t=norm_ticker(row.get('ticker') or row.get('market') or row.get('symbol')) or ''
    sk=_primary_strategy_key(row); ts=_event_ts(row)
    if t and sk and ts:
        keys.add(f'fb:{t}:{sk}:{int(ts//30)}')
        keys.add(f'fbm:{t}:{sk}:{int(ts//60)}')
    if t: keys.add(f'ticker:{t}')
    return keys

def _open_closed_candidate_keys():
    open_rows=[]
    try:
        op=load_json(BASE_DIR/'paper_open_positions.json',{})
        if isinstance(op,dict): open_rows=list(op.values())
    except Exception: pass
    closed_rows = _paper_current_closed_rows(max_lines=2600)
    open_keys=set(); closed_keys=set(); open_tickers=set()
    for p in open_rows:
        if isinstance(p,dict):
            open_keys |= _candidate_keys(p)
            t=norm_ticker(p.get('ticker') or p.get('market') or p.get('symbol')) or ''
            if t: open_tickers.add(t)
    for r in closed_rows:
        if isinstance(r,dict):
            closed_keys |= _candidate_keys(r)
            src=as_dict(r.get('source_event'))
            if src: closed_keys |= _candidate_keys(src)
    return open_keys, closed_keys, open_tickers



# v349: preview/missed_review/open-closed key canonical alias.
# 기존 pmissed_review 계열에서 _open_closed_keys 이름을 쓰는 경로와
# _open_closed_candidate_keys 이름을 쓰는 경로를 하나로 통일한다.
def _open_closed_keys():
    return _open_closed_candidate_keys()

def _merged_candidate_keys():
    rows=[]
    for name in ['paper_candidates_handoff_merged.jsonl','paper_candidates_latest.jsonl']:
        try: rows += read_jsonl(BASE_DIR/name, max_lines=500)
        except Exception: pass
    keys=set()
    for r in rows:
        if isinstance(r,dict): keys |= _candidate_keys(r)
    return keys

def _missed_reason(row: Dict[str,Any], merged_keys=None) -> str:
    row=_candidate_norm(row); nowv=now_ts(); reasons=[]
    keys=_candidate_keys(row); merged_keys=merged_keys if merged_keys is not None else _merged_candidate_keys()
    exp=fnum(row.get('expires_at'), default=0.0); ts=_event_ts(row)
    if exp and exp < nowv: reasons.append('handoff만료')
    if ts and nowv-ts>180: reasons.append('후보오래됨')
    if not (keys & merged_keys): reasons.append('paper미병합')
    ctx=as_dict(row.get('entry_context'))
    if not (row.get('micro_fresh') or ctx.get('micro_fresh')): reasons.append('micro미확인')
    if row.get('stale') or row.get('is_stale'): reasons.append('stale')
    if row.get('open_eligible') is False or row.get('paper_bot_open') is False: reasons.append('open_eligible_false')
    if row.get('event_id_origin') == 'legacy_fallback': reasons.append('구후보ID보정')
    if not reasons: reasons.append('paper미병합/만료확인')
    out=[]
    for r in reasons:
        if r not in out: out.append(r)
    return ','.join(out[:5])

def pmissed_review_text() -> str:
    anchor_ts = _paper_anchor_ts()
    events=[]
    for name,maxn in [('paper_candidates.jsonl',1000),('paper_candidates_latest.jsonl',250)]:
        try: events += read_jsonl(BASE_DIR/name, max_lines=maxn)
        except Exception: pass
    market = _market_price_map()
    open_keys, closed_keys, open_tickers = _open_closed_candidate_keys()
    merged_keys = _merged_candidate_keys()
    seen=set(); missed=[]; watched=0; counter=Counter()
    for raw in events:
        if not isinstance(raw,dict): continue
        ev=_candidate_norm(raw); ts=_event_ts(ev)
        if anchor_ts and ts and ts<anchor_ts: continue
        t=norm_ticker(ev.get('ticker') or ev.get('market') or ev.get('symbol')) or ''
        if not t: continue
        keys=_candidate_keys(ev); dedupe=str(ev.get('event_id') or f'{t}:{_primary_strategy_key(ev)}:{int(ts//30) if ts else 0}')
        if dedupe in seen: continue
        seen.add(dedupe); watched+=1
        if (keys & closed_keys) or (keys & open_keys) or t in open_tickers: continue
        cur=market.get(t,{}) if isinstance(market,dict) else {}
        cur_price=price_from_any(cur)
        entry=fnum(ev.get('entry_price'), ev.get('current_price'), ev.get('detected_price'), default=0.0)
        if cur_price<=0 or entry<=0: continue
        gain=(cur_price-entry)/entry*100.0
        if gain>=0.70:
            why=_missed_reason(ev, merged_keys)
            for r in why.split(','):
                if r: counter[r]+=1
            rs=ev.get('reasons') or ev.get('final_entry_reasons') or []
            missed.append({'ticker':t,'gain':gain,'strategy':ev.get('strategy_bucket_primary_label') or ev.get('strategy_name') or ev.get('strategy'), 'score':ev.get('score'), 'reasons':rs if isinstance(rs,list) else [], 'missed_reason':why})
    missed.sort(key=lambda x:x.get('gain',0), reverse=True)
    lines=['🔎 놓친 후보 복기 /pmissed_review · 메인봇 캐시전용','- 후보 archive/latest 중 OPEN/CLOSED로 이어지지 않았는데 이후 오른 코인을 봅니다.',f'- 확인 후보 {watched}개 / 현재가 비교 가능 상승후보 {len(missed)}개','','[놓친 이유 추정 TOP]']
    if counter:
        for k,v in counter.most_common(10):
            icon='⚠️' if k in {'paper미병합','handoff만료','후보오래됨','micro미확인'} else '❔'
            lines.append(f'- {icon} {k}: {v}개')
    else:
        lines.append('- 아직 분류할 상승후보 없음')
    lines += ['', '[이후 오른 후보 TOP]']
    if missed:
        for m in missed[:10]:
            rs=m.get('reasons') if isinstance(m.get('reasons'),list) else []
            lines.append(f"- {'⚠️' if m['gain']>=1.5 else '❔'} {m['ticker']} / +{m['gain']:.2f}% / {m.get('strategy','-')} / 점수 {m.get('score','-')} / 놓친이유 {m.get('missed_reason','-')} / 근거 {', '.join(map(str, rs[:3]))}")
    else:
        lines.append('- 아직 뚜렷한 놓친 상승후보 없음')
    lines += ['', '[판독]', '- 자주 오르는 패턴은 조건에서 죽이면 안 됨', '- paper미병합/만료/오래됨이 많으면 전략조건보다 handoff·진입타이밍 문제를 먼저 봅니다', '- 손실필터는 /ploss_review와 같이 봐야 합니다']
    return '\n'.join(lines)

def preview_text() -> str:
    # 단일 canonical preview: loss + missed를 각각 보호 실행해 한쪽 오류가 전체를 죽이지 않게 한다.
    parts=[]
    for title, fn in [('ploss_review', ploss_review_text), ('pmissed_review', pmissed_review_text)]:
        try:
            parts.append(fn())
        except Exception as exc:
            log_error(f'preview_{title}', exc)
            parts.append(f'❌ {title} 생성 오류: {exc.__class__.__name__}: {exc}')
    return '\n\n'.join(parts)



# =============================================================================
# v348: missed trace / handoff canonical review
# - paper_bot_v0.91의 candidate_handoff_trace를 우선 사용한다.
# - 같은 ticker/전략의 중복 놓친 후보는 1개로 합친다.
# - 조건 판단 전, 왜 paper OPEN으로 이어지지 않았는지 추적한다.
# =============================================================================

def _v348_trace_rows() -> List[Dict[str, Any]]:
    obj = load_json(FILES.get('candidate_handoff_trace', BASE_DIR/'paper_bot_candidate_handoff_trace.json'), {}) or {}
    rows = obj.get('rows') if isinstance(obj, dict) else []
    return [r for r in rows if isinstance(r, dict)] if isinstance(rows, list) else []


def _v348_trace_map() -> Dict[str, Dict[str, Any]]:
    out: Dict[str, Dict[str, Any]] = {}
    for r in _v348_trace_rows():
        t = norm_ticker(r.get('ticker') or r.get('market') or r.get('symbol'))
        sk = _primary_strategy_key(r) or str(r.get('strategy_key') or r.get('strategy') or '')
        for k in [str(r.get('event_id') or ''), str(r.get('event_key') or ''), str(r.get('trace_id') or ''), str(r.get('handoff_id') or ''), f'{t}:{sk}']:
            if k and k != '-':
                out[k] = r
    return out


def _v348_trace_for_candidate(ev: Dict[str, Any], trace_map: Optional[Dict[str, Dict[str, Any]]] = None) -> Dict[str, Any]:
    trace_map = trace_map or _v348_trace_map()
    t = norm_ticker(ev.get('ticker') or ev.get('market') or ev.get('symbol'))
    sk = _primary_strategy_key(ev) or str(ev.get('strategy_key') or ev.get('strategy') or '')
    keys = [str(ev.get('event_id') or ''), str(ev.get('event_key') or ''), str(ev.get('trace_id') or ''), str(ev.get('handoff_id') or ''), str(ev.get('candidate_uid') or ''), f'{t}:{sk}']
    for k in keys:
        if k and k in trace_map:
            return trace_map[k]
    return {}


def _v348_reason_from_trace(ev: Dict[str, Any], trace: Dict[str, Any], fallback: str = '') -> str:
    vals: List[str] = []
    for src in (trace, ev):
        for key in ('reason', 'missed_reason', 'status_reason'):
            v = src.get(key) if isinstance(src, dict) else None
            if isinstance(v, list):
                vals += [str(x) for x in v if str(x)]
            elif v not in (None, '', '-'):
                vals += [x.strip() for x in str(v).split(',') if x.strip()]
    if fallback:
        vals += [x.strip() for x in str(fallback).split(',') if x.strip()]
    if trace:
        st = str(trace.get('status') or '')
        if st and st not in {'candidate','unknown'}:
            vals.append(st)
    out=[]
    for v in vals:
        if v and v not in out:
            out.append(v)
    return ','.join(out[:6]) if out else 'paper미병합/만료확인'


def missed_trace_text() -> str:
    obj = load_json(FILES.get('candidate_handoff_trace', BASE_DIR/'paper_bot_candidate_handoff_trace.json'), {}) or {}
    rows = _v348_trace_rows()
    by_status = Counter(str(r.get('status') or 'unknown') for r in rows)
    reasons = Counter()
    for r in rows:
        for x in str(r.get('reason') or '').split(','):
            x=x.strip()
            if x: reasons[x]+=1
    lines = [
        '🧭 놓친 후보 추적 /missed_trace',
        '- strategy 후보 → handoff → paper 병합/OPEN/CLOSED 흐름을 추적합니다.',
        f"- trace age {age(FILES.get('candidate_handoff_trace', BASE_DIR/'paper_bot_candidate_handoff_trace.json')):.1f}s / rows {len(rows)} / version {obj.get('version','-') if isinstance(obj,dict) else '-'}",
        '', '[상태 TOP]'
    ]
    if by_status:
        for k,v in by_status.most_common(8):
            icon = '✅' if k in {'open','closed'} else '⚠️' if k in {'expired','not_merged','merged_waiting_open'} else '❔'
            lines.append(f'- {icon} {k}: {v}개')
    else:
        lines.append('- trace 없음')
    lines += ['', '[이유 TOP]']
    if reasons:
        for k,v in reasons.most_common(10):
            icon = '⚠️' if k in {'paper미병합','handoff만료','후보오래됨','micro미확인','picked_not_opened'} else '❔'
            lines.append(f'- {icon} {k}: {v}개')
    else:
        lines.append('- 이유 없음')
    lines += ['', '[주의 후보 TOP]']
    risky = [r for r in rows if str(r.get('status') or '') not in {'open','closed'}]
    risky.sort(key=lambda r: (float(first_value(r.get('score'),0) or 0), float(first_value(r.get('created_at'),0) or 0)), reverse=True)
    seen_risky=set(); shown=0
    for r in risky:
        t = norm_ticker(r.get('ticker'))
        sk = str(r.get('strategy_key') or r.get('strategy') or '-')
        key = f'{t}:{sk}:{r.get("status","-")}:{r.get("reason","-")}'
        if key in seen_risky:
            continue
        seen_risky.add(key); shown += 1
        lines.append(f"- ⚠️ {t} / {r.get('strategy') or r.get('strategy_key','-')} / score {r.get('score','-')} / status {r.get('status','-')} / 이유 {r.get('reason','-')}")
        if shown >= 10:
            break
    if not risky:
        lines.append('- 현재 주의 후보 없음')
    elif len(seen_risky) < len(risky):
        lines.append(f'- 중복 후보 {len(risky)-len(seen_risky)}개는 묶어서 숨김')
    return '\n'.join(lines)


def pmissed_review_text() -> str:  # type: ignore[override]
    anchor_ts = _paper_anchor_ts()
    events=[]
    for name,maxn in [('paper_candidates.jsonl',1200),('paper_candidates_latest.jsonl',300)]:
        events += read_jsonl(BASE_DIR/name, max_lines=maxn)
    market = _market_price_map()
    open_ids, closed_ids, open_tickers = _open_closed_keys()
    trace_map = _v348_trace_map()
    nowv=now_ts(); watched=0; by_key: Dict[str, Dict[str, Any]] = {}; reason_counter=Counter()
    for raw in events:
        if not isinstance(raw, dict):
            continue
        ev = ensure_event_id(raw)
        ts = float(first_value(ev.get('created_at'), ev.get('candidate_created_at'), ev.get('detected_ts'), ev.get('event_ts'), 0) or 0)
        if anchor_ts and ts and ts < anchor_ts:
            continue
        t=norm_ticker(ev.get('ticker') or ev.get('market') or ev.get('symbol'))
        if not t:
            continue
        watched += 1
        keys=_candidate_keys(ev)
        if (keys & open_ids) or (keys & closed_ids) or t in open_tickers:
            continue
        cur = market.get(t, {})
        cur_price = price_from_any(cur)
        entry = float(first_value(ev.get('entry_price'), ev.get('current_price'), ev.get('detected_price'), ev.get('price'), 0) or 0)
        if cur_price <= 0 or entry <= 0:
            continue
        gain = (cur_price-entry)/entry*100.0
        if gain < 0.70:
            continue
        trace = _v348_trace_for_candidate(ev, trace_map)
        why = _v348_reason_from_trace(ev, trace, _missed_reason(ev, set()))
        for x in why.split(','):
            if x: reason_counter[x]+=1
        sk = _primary_strategy_key(ev) or str(ev.get('strategy_key') or ev.get('strategy') or '')
        dedupe = f'{t}:{sk}'
        item = {'ticker':t,'gain':gain,'strategy':ev.get('strategy_bucket_primary_label') or ev.get('strategy_name') or ev.get('strategy') or trace.get('strategy'), 'score':ev.get('score') or trace.get('score'), 'reasons':ev.get('reasons') or ev.get('final_entry_reasons') or [], 'missed_reason':why, 'trace_status':trace.get('status','-') if trace else '-'}
        old = by_key.get(dedupe)
        if old is None or gain > float(old.get('gain',0)):
            by_key[dedupe]=item
    missed=list(by_key.values()); missed.sort(key=lambda x:x.get('gain',0), reverse=True)
    lines=['🔎 놓친 후보 복기 /pmissed_review · 메인봇 캐시전용', '- 후보 archive/latest 중 OPEN/CLOSED로 이어지지 않았는데 이후 오른 코인을 봅니다.', f'- 확인 후보 {watched}개 / 중복제거 상승후보 {len(missed)}개', '', '[놓친 이유 추정 TOP]']
    if reason_counter:
        for k,v in reason_counter.most_common(10):
            icon='⚠️' if k in {'paper미병합','handoff만료','후보오래됨','micro미확인','picked_not_opened'} else '❔'
            lines.append(f'- {icon} {k}: {v}개')
    else:
        lines.append('- 아직 분류할 상승후보 없음')
    lines += ['', '[이후 오른 후보 TOP]']
    if missed:
        for m in missed[:10]:
            rs=m.get('reasons') if isinstance(m.get('reasons'), list) else []
            lines.append(f"- {'⚠️' if m['gain']>=1.5 else '❔'} {m['ticker']} / +{m['gain']:.2f}% / {m.get('strategy','-')} / 점수 {m.get('score','-')} / 상태 {m.get('trace_status','-')} / 놓친이유 {m.get('missed_reason','-')} / 근거 {', '.join(map(str, rs[:3]))}")
    else:
        lines.append('- 아직 뚜렷한 놓친 상승후보 없음')
    lines += ['', '[판독]', '- 자주 오르는 패턴은 조건에서 죽이면 안 됨', '- paper미병합/만료/오래됨이 많으면 전략조건보다 handoff·진입타이밍 문제를 먼저 봅니다', '- 손실필터는 /ploss_review와 같이 봐야 합니다']
    return '\n'.join(lines)


def preview_text() -> str:  # type: ignore[override]
    parts=[]
    for title, fn in [('ploss_review', ploss_review_text), ('pmissed_review', pmissed_review_text)]:
        try:
            parts.append(fn())
        except Exception as exc:
            log_error(f'preview_{title}', exc)
            parts.append(f'⚠️ {title} 출력 오류: {type(exc).__name__}: {exc}')
    return '\n\n'.join(parts)



# =============================================================================
# v354: main review canonical final layer
# v355: score cache version gate는 목록식 whitelist 대신 paper_bot_v0.86+ 숫자 판정으로 단일화
# - preview/missed_trace에서 이름 누락/중복 override가 다시 타지 않도록 최종 단일 함수를 둔다.
# - 전략/청산/자동매수에는 관여하지 않고, paper_bot_v0.92 trace/cache를 읽는 조회 전용이다.
# =============================================================================

def _v354_trace_rows() -> List[Dict[str, Any]]:
    obj = load_json(FILES.get('candidate_handoff_trace', BASE_DIR/'paper_bot_candidate_handoff_trace.json'), {}) or {}
    rows = obj.get('rows') if isinstance(obj, dict) else []
    return [r for r in rows if isinstance(r, dict)] if isinstance(rows, list) else []

def _v354_trace_map() -> Dict[str, Dict[str, Any]]:
    out: Dict[str, Dict[str, Any]] = {}
    priority = {'closed': 60, 'open': 55, 'picked': 50, 'merged_waiting_pick': 40, 'micro_wait': 35, 'not_merged': 25, 'expired': 10, 'skipped': 5}
    for r in _v354_trace_rows():
        t = norm_ticker(r.get('ticker') or r.get('market') or r.get('symbol'))
        sk = _primary_strategy_key(r) or str(r.get('strategy_key') or r.get('strategy') or '')
        ts = fnum(r.get('created_at') or r.get('updated_at'), default=0.0)
        keys = [r.get('event_id'), r.get('event_key'), r.get('trace_id'), r.get('handoff_id'), r.get('candidate_uid'), f'{t}:{sk}']
        for k in keys:
            k=str(k or '')
            if not k or k == '-':
                continue
            old = out.get(k)
            if old is None:
                out[k] = r
                continue
            old_score = priority.get(str(old.get('status') or ''), 0)
            new_score = priority.get(str(r.get('status') or ''), 0)
            old_ts = fnum(old.get('created_at') or old.get('updated_at'), default=0.0)
            # 같은 ticker:strategy 키에서 과거 expired가 최신 open/closed/picked를 덮지 못하게 한다.
            if (new_score, ts) > (old_score, old_ts):
                out[k] = r
    return out

def _v354_trace_for_candidate(ev: Dict[str, Any], trace_map: Optional[Dict[str, Dict[str, Any]]] = None) -> Dict[str, Any]:
    trace_map = trace_map or _v354_trace_map()
    row = _candidate_norm(ev)
    t = norm_ticker(row.get('ticker') or row.get('market') or row.get('symbol'))
    sk = _primary_strategy_key(row) or str(row.get('strategy_key') or row.get('strategy') or '')
    keys = [row.get('event_id'), row.get('event_key'), row.get('trace_id'), row.get('handoff_id'), row.get('candidate_uid'), f'{t}:{sk}']
    for k in keys:
        k=str(k or '')
        if k and k in trace_map:
            return trace_map[k]
    return {}

def _v354_reason_from_trace(ev: Dict[str, Any], trace: Dict[str, Any], fallback: str = '') -> str:
    vals: List[str] = []
    for src in (trace, ev):
        if not isinstance(src, dict):
            continue
        for key in ('reason', 'missed_reason', 'status_reason'):
            v = src.get(key)
            if isinstance(v, list):
                vals += [str(x).strip() for x in v if str(x).strip()]
            elif v not in (None, '', '-'):
                vals += [x.strip() for x in str(v).split(',') if x.strip()]
    if fallback:
        vals += [x.strip() for x in str(fallback).split(',') if x.strip()]
    if trace:
        st=str(trace.get('status') or '')
        if st and st not in {'candidate','unknown'}:
            vals.append(st)
    out=[]
    for v in vals:
        if v and v not in out:
            out.append(v)
    return ','.join(out[:6]) if out else 'paper미병합/만료확인'

def missed_trace_text() -> str:  # type: ignore[override]
    obj = load_json(FILES.get('candidate_handoff_trace', BASE_DIR/'paper_bot_candidate_handoff_trace.json'), {}) or {}
    rows = _v354_trace_rows()
    by_status = Counter(str(r.get('status') or 'unknown') for r in rows)
    reasons = Counter()
    for r in rows:
        for x in str(r.get('reason') or '').split(','):
            x=x.strip()
            if x: reasons[x]+=1
    lines = [
        '🧭 놓친 후보 추적 /missed_trace',
        '- strategy 후보 → handoff → paper 병합/OPEN/CLOSED 흐름을 추적합니다.',
        f"- trace age {age(FILES.get('candidate_handoff_trace', BASE_DIR/'paper_bot_candidate_handoff_trace.json')):.1f}s / rows {len(rows)} / version {obj.get('version','-') if isinstance(obj,dict) else '-'}",
        '', '[상태 TOP]'
    ]
    if by_status:
        for k,v in by_status.most_common(10):
            icon = '✅' if k in {'open','closed','picked'} else '⚠️' if k in {'expired','not_merged','merged_waiting_pick','micro_wait','skipped'} else '❔'
            lines.append(f'- {icon} {k}: {v}개')
    else:
        lines.append('- trace 없음')
    lines += ['', '[이유 TOP]']
    if reasons:
        for k,v in reasons.most_common(10):
            icon = '⚠️' if k in {'paper미병합','handoff만료','후보오래됨','micro미확인','picked_not_opened'} else '❔'
            lines.append(f'- {icon} {k}: {v}개')
    else:
        lines.append('- 이유 없음')
    lines += ['', '[주의 후보 TOP]']
    risky = [r for r in rows if str(r.get('status') or '') not in {'open','closed'}]
    risky.sort(key=lambda r: (float(first_value(r.get('score'),0) or 0), float(first_value(r.get('created_at'),0) or 0)), reverse=True)
    for r in risky[:10]:
        lines.append(f"- ⚠️ {norm_ticker(r.get('ticker'))} / {r.get('strategy') or r.get('strategy_key','-')} / score {r.get('score','-')} / status {r.get('status','-')} / 이유 {r.get('reason','-')}")
    if not risky:
        lines.append('- 현재 주의 후보 없음')
    return '\n'.join(lines)

def _v358_recent_review_events() -> List[Dict[str, Any]]:
    """v358: /pmissed_review 기본판은 오래된 archive 전체를 다시 훑지 않는다.

    trace 수술 이후 기본 복기는 latest/handoff/actual trace 중심으로만 본다.
    archive 전체 재검사는 나중에 full 명령으로 분리할 대상이며, 기본 명령에서
    handoff만료/paper미병합을 과대표시하지 않게 한다.
    """
    events: List[Dict[str, Any]] = []
    seen: set[str] = set()
    for name, maxn in [('paper_candidates_latest.jsonl', 250), ('paper_candidates_handoff_merged.jsonl', 300)]:
        for ev in read_jsonl(BASE_DIR/name, max_lines=maxn):
            if not isinstance(ev, dict):
                continue
            key = str(ev.get('event_id') or ev.get('event_key') or ev.get('candidate_uid') or '')
            t = norm_ticker(ev.get('ticker') or ev.get('market') or ev.get('symbol'))
            ts = str(first_value(ev.get('created_at'), ev.get('candidate_created_at'), ev.get('event_ts'), ''))
            sk = str(_primary_strategy_key(ev) or ev.get('strategy_key') or ev.get('strategy') or '')
            dk = key or f'{t}:{sk}:{ts}'
            if dk in seen:
                continue
            seen.add(dk)
            events.append(ev)
    # actual trace도 후보 추적 기준으로만 보강한다. 오래된 source/archive trace fallback은 쓰지 않는다.
    obj = load_json(FILES.get('candidate_handoff_trace', BASE_DIR/'paper_bot_candidate_handoff_trace.json'), {}) or {}
    rows = obj.get('rows') if isinstance(obj, dict) else []
    if isinstance(rows, list):
        for r in rows[:300]:
            if not isinstance(r, dict):
                continue
            key = str(r.get('event_id') or r.get('event_key') or r.get('candidate_uid') or r.get('trace_id') or '')
            t = norm_ticker(r.get('ticker') or r.get('market') or r.get('symbol'))
            ts = str(first_value(r.get('created_at'), r.get('candidate_created_at'), r.get('event_ts'), ''))
            sk = str(_primary_strategy_key(r) or r.get('strategy_key') or r.get('strategy') or '')
            dk = key or f'trace:{t}:{sk}:{ts}'
            if dk in seen:
                continue
            seen.add(dk)
            events.append(r)
    return events


def pmissed_review_text() -> str:  # type: ignore[override]
    """v358 기본 missed 복기.

    기본 명령은 latest/handoff/actual trace만 본다. archive 전체 재검사는 렉과
    과대표시를 만들 수 있으므로 기본 경로에서 제외한다.
    """
    anchor_ts = _paper_anchor_ts()
    events = _v358_recent_review_events()
    market = _market_price_map()
    open_ids, closed_ids, open_tickers = _open_closed_keys()
    trace_map = _v354_trace_map()
    watched=0; by_key: Dict[str, Dict[str, Any]] = {}; reason_counter=Counter()
    for raw in events:
        if not isinstance(raw, dict):
            continue
        ev = _candidate_norm(raw)
        ts = float(first_value(ev.get('created_at'), ev.get('candidate_created_at'), ev.get('detected_ts'), ev.get('event_ts'), 0) or 0)
        if anchor_ts and ts and ts < anchor_ts:
            continue
        t=norm_ticker(ev.get('ticker') or ev.get('market') or ev.get('symbol'))
        if not t:
            continue
        watched += 1
        keys=_candidate_keys(ev)
        if (keys & open_ids) or (keys & closed_ids) or t in open_tickers:
            continue
        cur_price = price_from_any(market.get(t, {}))
        entry = float(first_value(ev.get('entry_price'), ev.get('current_price'), ev.get('detected_price'), ev.get('price'), 0) or 0)
        if cur_price <= 0 or entry <= 0:
            continue
        gain = (cur_price-entry)/entry*100.0
        if gain < 0.70:
            continue
        trace = _v354_trace_for_candidate(ev, trace_map)
        why = _v354_reason_from_trace(ev, trace, _missed_reason(ev, set()))
        for x in why.split(','):
            if x: reason_counter[x]+=1
        sk = _primary_strategy_key(ev) or str(ev.get('strategy_key') or ev.get('strategy') or '')
        dedupe = f'{t}:{sk}'
        item = {'ticker':t,'gain':gain,'strategy':ev.get('strategy_bucket_primary_label') or ev.get('strategy_name') or ev.get('strategy') or trace.get('strategy'), 'score':ev.get('score') or trace.get('score'), 'reasons':ev.get('reasons') or ev.get('final_entry_reasons') or [], 'missed_reason':why, 'trace_status':trace.get('status','-') if trace else '-'}
        old=by_key.get(dedupe)
        if old is None or gain > float(old.get('gain',0)):
            by_key[dedupe]=item
    missed=list(by_key.values()); missed.sort(key=lambda x:x.get('gain',0), reverse=True)
    lines=['🔎 놓친 후보 복기 /pmissed_review · 메인봇 캐시전용', '- 기본 범위: latest/handoff/actual trace 중심. archive 전체 재검사는 기본에서 제외.', f'- 확인 후보 {watched}개 / 중복제거 상승후보 {len(missed)}개', '', '[놓친 이유 추정 TOP]']
    if reason_counter:
        for k,v in reason_counter.most_common(8):
            icon='⚠️' if k in {'paper미병합','handoff만료','후보오래됨','micro미확인','picked_not_opened'} else '❔'
            lines.append(f'- {icon} {k}: {v}개')
    else:
        lines.append('- 아직 분류할 상승후보 없음')
    lines += ['', '[이후 오른 후보 TOP]']
    if missed:
        for m in missed[:5]:
            rs=m.get('reasons') if isinstance(m.get('reasons'), list) else []
            lines.append(f"- {'⚠️' if m['gain']>=1.5 else '❔'} {m['ticker']} / +{m['gain']:.2f}% / {m.get('strategy','-')} / 점수 {m.get('score','-')} / 상태 {m.get('trace_status','-')} / 놓친이유 {m.get('missed_reason','-')} / 근거 {', '.join(map(str, rs[:3]))}")
    else:
        lines.append('- 아직 뚜렷한 놓친 상승후보 없음')
    lines += ['', '[판독]', '- 기본판에서 paper미병합/만료가 많으면 handoff·paper 병합 타이밍을 봅니다', '- 전략조건 수정은 score/trace가 정상 출력된 뒤 판단합니다']
    return '\n'.join(lines)


def _v358_trim_loss_preview(txt: str) -> str:
    lines = txt.splitlines()
    out: List[str] = []
    keep = True
    for ln in lines:
        if ln.startswith('[전략별 손실 원인'):
            keep = False
            continue
        if ln.startswith('[조건 설계 힌트]'):
            keep = True
        if keep:
            out.append(ln)
        if len(out) >= 18:
            break
    if '[전략별 손실 원인 · 대표전략 기준]' in txt:
        out += ['', '- 전략별 상세 손실은 /ploss_review에서 확인']
    return '\n'.join(out)


def preview_text() -> str:  # type: ignore[override]
    """v358 기본 preview 경량화.

    전체 상세를 반복 출력하지 않고 손실 TOP + missed 기본판만 묶는다.
    """
    parts=[]
    try:
        parts.append(_v358_trim_loss_preview(ploss_review_text()))
    except Exception as exc:
        log_error('preview_ploss_review', exc)
        parts.append(f'⚠️ ploss_review 출력 오류: {type(exc).__name__}: {exc}')
    try:
        parts.append(pmissed_review_text())
    except Exception as exc:
        log_error('preview_pmissed_review', exc)
        parts.append(f'⚠️ pmissed_review 출력 오류: {type(exc).__name__}: {exc}')
    return '\n\n'.join(parts)




# =============================================================================
# v365: 버전별 성과판 복구
# - v349~v364 결과가 한 장부에 섞이면 현재 수정 효과를 판단하기 어렵다.
# - /version_score는 paper CLOSED를 직접 읽어 brain version별 승률/손익/손실패턴을 분리한다.
# - score cache fallback을 만들지 않고, 조회 전용으로만 계산한다.
# =============================================================================

def _v365_norm_version_from_row(row: Dict[str, Any]) -> str:
    row = as_dict(row)
    ctx = as_dict(row.get('entry_context'))
    raw = as_dict(row.get('raw'))
    vals = [
        row.get('opened_brain_version'), row.get('brain_version'), row.get('main_version'), row.get('bot_version'),
        ctx.get('opened_brain_version'), ctx.get('brain_version'), ctx.get('main_version'), ctx.get('bot_version'),
        raw.get('opened_brain_version'), raw.get('brain_version'), raw.get('main_version'), raw.get('bot_version'),
    ]
    for v in vals:
        s = str(v or '').strip()
        if not s:
            continue
        m = re.search(r'v?2[._]13[._](\d+)', s)
        if m:
            return f"v2.13.{int(m.group(1))}"
        m = re.search(r'v(\d{3,})', s)
        if m:
            return f"v2.13.{int(m.group(1))}"
        return s[:32]
    return '버전 미기록'


def _v365_closed_ts(row: Dict[str, Any]) -> float:
    return fnum(row.get('closed_at'), row.get('closed_ts'), row.get('close_ts'), row.get('exit_ts'), row.get('timestamp'), row.get('updated_at'), default=0.0)


def _v365_pnl(row: Dict[str, Any]) -> float:
    return fnum(row.get('pnl_pct'), row.get('profit_pct'), row.get('return_pct'), row.get('profit_rate_pct'), default=0.0)


def _v365_strategy_key(row: Dict[str, Any]) -> str:
    key = _strategy_key_from_row(row) if '_strategy_key_from_row' in globals() else str(row.get('strategy_key') or row.get('strategy') or 'unknown')
    return key or 'unknown'


def _v365_stat(rows: List[Dict[str, Any]]) -> Dict[str, Any]:
    n=len(rows)
    wins=sum(1 for r in rows if _v365_pnl(r)>0)
    losses=sum(1 for r in rows if _v365_pnl(r)<0)
    total=sum(_v365_pnl(r) for r in rows)
    avg=total/n if n else 0.0
    fast=sum(1 for r in rows if _v365_pnl(r)<0 and fnum(r.get('hold_sec'), r.get('duration_sec'), default=999999) <= 300)
    hard=sum(1 for r in rows if '하드' in str(r.get('exit_reason') or r.get('exit_label') or r.get('close_reason') or '') or _v365_pnl(r) <= -0.95)
    no_react=sum(1 for r in rows if _v365_pnl(r)<0 and fnum(r.get('peak_pct'), r.get('max_profit_pct'), r.get('max_pnl_pct'), default=0.0) <= 0.10)
    hold_avg=sum(fnum(r.get('hold_sec'), r.get('duration_sec'), default=0.0) for r in rows)/n if n else 0.0
    return {'n':n,'wins':wins,'losses':losses,'win_rate':(wins/n*100.0 if n else 0.0),'total':total,'avg':avg,'fast':fast,'hard':hard,'no_react':no_react,'hold_avg':hold_avg}


def _v365_stat_line(label: str, rows: List[Dict[str, Any]]) -> str:
    st=_v365_stat(rows)
    sample = ' ⚠️표본적음' if 0 < st['n'] < 10 else ''
    return f"- {label}: {st['n']}전 {st['wins']}승 {st['losses']}패 / 승률 {st['win_rate']:.1f}% / 합산 {st['total']:+.2f}% / 평균 {st['avg']:+.2f}%{sample} / 5분내손실 {st['fast']} / 하드손실 {st['hard']} / 무반응손실 {st['no_react']}"


def version_score_text() -> str:
    rows = [r for r in read_jsonl(FILES.get('paper_closed', BASE_DIR/'paper_bot_closed.jsonl'), max_lines=30000) if isinstance(r, dict)]
    groups: Dict[str, List[Dict[str, Any]]] = {}
    for r in rows:
        groups.setdefault(_v365_norm_version_from_row(r), []).append(r)
    items=[]
    for ver, arr in groups.items():
        latest=max((_v365_closed_ts(r) for r in arr), default=0.0)
        # 버전 미기록은 아래로 보낸다.
        if ver == '버전 미기록': latest = -1
        items.append((latest, ver, arr))
    items.sort(reverse=True)
    lines=[
        '📊 버전별 성과 /version_score',
        '- 목적: v349~현재 결과가 섞이지 않게 버전별 승률·손익을 따로 봅니다.',
        '- 기준: paper CLOSED 전체 장부 직접 조회 / 기본 score cache와 별도',
        '',
        '[최근 버전별 요약]'
    ]
    if not items:
        lines.append('- 아직 CLOSED 장부 없음')
        return '\n'.join(lines)
    for _, ver, arr in items[:12]:
        icon='✅' if _v365_stat(arr).get('total',0)>0 else ('⚠️' if len(arr)<10 else '❌')
        lines.append(_v365_stat_line(f'{icon} {ver}', arr))
    latest_ver = items[0][1]
    latest_rows = items[0][2]
    strat_groups: Dict[str, List[Dict[str, Any]]] = {}
    for r in latest_rows:
        strat_groups.setdefault(_v365_strategy_key(r), []).append(r)
    label_map={'money_reaccel_s':'돈흐름 재가속','leader_momentum_s':'주도추세 지속','breakout_early_s':'돌파 초입','sweep_vwap_recovery_s':'저점 VWAP 회복','surge_rebreak_s':'급등 후 재돌파','leader_flow_adaptive_hold_s':'주도흐름 유동보유','unknown':'대표전략 미확인'}
    lines += ['', f'[최근 버전 전략별 · {latest_ver}]']
    for k, arr in sorted(strat_groups.items(), key=lambda kv: len(kv[1]), reverse=True)[:8]:
        lines.append(_v365_stat_line(label_map.get(k,k), arr))
    lines += ['', '[판독]', '- 현재 /score는 현재판 anchor 기준이고, /version_score는 버전별 장부 기준입니다.', '- 새 조건 효과는 최신 버전 줄만 보고, 예전 손실은 참고로만 봅니다.']
    return '\n'.join(lines)

COMMANDS={'health':health_text,'core':health_text,'workers':workers_text,'score':score_text,'version_score':version_score_text,'vscore':version_score_text,'quality':quality_text,'strategy_watch':strategy_watch_text,'pipe_check':pipe_check_text,'pstatus':pstatus_text,'pscore':pscore_text,'popen':popen_text,'ploss_review':ploss_review_text,'pmissed_review':pmissed_review_text,'preview':preview_text,'loss_review':ploss_review_text,'missed_review':pmissed_review_text,'missed_trace':missed_trace_text,'trace_missed':missed_trace_text,'errorlog':errorlog_text,'popen_short':open_text}

def send(update, text:str)->None:
    try:
        # Telegram hard limit 보호
        if len(text)>3900: text=text[:3850]+"\n…(잘림: full 명령에서 확인)"
        update.message.reply_text(text)
    except Exception as exc: log_error('telegram_send',exc)

def make_handler(name:str):
    def h(update, context):
        try:
            txt = getattr(update.message, 'text', '') or ''
            lines = [x.strip().lstrip('/') for x in txt.splitlines() if x.strip().startswith('/')]
            if len(lines) >= 2:
                context.args = lines[:12]
                return batch_handler(update, context)
            send(update, COMMANDS[name]())
        except Exception as exc:
            log_error(f'cmd_{name}',exc); send(update, f"❌ /{name} 오류: {exc.__class__.__name__}: {exc}")
    return h

def batch_handler(update, context):
    cmds=context.args or ['health','score','quality','strategy_watch','errorlog']
    cmds=[str(x).strip().lstrip('/') for x in cmds[:12] if str(x).strip()]
    st=time.time(); sent=0; timings=[]
    try:
        send(update, f"📦 자동 묶음 명령 접수\n- 실행 {len(cmds)}개\n- v369: S2/S3 관찰·trace·최근3버전 성과 수술")
    except Exception:
        pass
    total=len(cmds)
    for raw in cmds:
        name=raw.strip().lstrip('/')
        fn=COMMANDS.get(name)
        if not fn:
            continue
        t=time.time()
        try:
            body=fn()
            ok="OK"
        except Exception as exc:
            body=f"❌ /{name} 오류 {exc.__class__.__name__}: {exc}"
            ok="ERR"
            log_error(f'batch_{name}', exc)
        sec=time.time()-t
        sent += 1
        timings.append(f"- {'✅' if ok=='OK' else '❌'} /{name}: {sec:.2f}s / {ok}")
        send(update, f"[{sent}/{total}] /{name} ({sec:.2f}s / {ok})\n{body}")
    send(update, "🧾 자동 묶음 시간표 · v369 명령별 전송\n"+"\n".join(timings)+f"\n- 합계 {time.time()-st:.2f}s")

def text_router(update, context):
    try:
        txt=update.message.text or ''
        lines=[x.strip().lstrip('/') for x in txt.splitlines() if x.strip().startswith('/')]
        if len(lines)>=2:
            context.args=lines[:12]; return batch_handler(update, context)
    except Exception as exc: log_error('text_router',exc)

def set_commands(updater):
    try:
        updater.bot.set_my_commands([BotCommand('health','메인/worker/paper 빠른상태'),BotCommand('workers','worker 상세 상태'),BotCommand('score','S1/S2/S3 성과'),BotCommand('version_score','버전별 성과'),BotCommand('quality','S1/S2/S3 후보와 탈락사유'),BotCommand('pstatus','paper 상태'),BotCommand('popen','paper OPEN'),BotCommand('preview','손실+놓친후보 복기'),BotCommand('missed_trace','후보 handoff 추적'),BotCommand('errorlog','오류로그'),BotCommand('batch','묶음 확인')])
    except Exception as exc: log_error('set_commands',exc)

def startup_notify(updater):
    try:
        if not CHAT_ID:
            return
        text=(
            f"✅ 메인봇 시작 완료\n"
            f"- 버전: {BOT_VERSION}\n"
            f"- 구조: clean worker hub v369\n"
            f"- 명령: /health /score /quality /pstatus /popen /preview /errorlog"
        )
        updater.bot.send_message(chat_id=CHAT_ID, text=text)
    except Exception as exc:
        log_error('startup_notify', exc)

def heartbeat_loop():
    while True:
        try:
            update_brain_status('running')
        except Exception as exc:
            log_error('heartbeat', exc)
        time.sleep(10)

def main():
    log_runtime(f"telegram_state=initializing version={BOT_VERSION}")
    update_brain_status('initializing')
    if not TELEGRAM_TOKEN:
        print('TELEGRAM_TOKEN missing; worker hub status only')
        while True:
            update_brain_status('running_no_telegram'); time.sleep(5)
    updater=Updater(token=TELEGRAM_TOKEN, use_context=True)
    dp=updater.dispatcher
    for name in COMMANDS: dp.add_handler(CommandHandler(name, make_handler(name)))
    dp.add_handler(CommandHandler('batch', batch_handler))
    if MessageHandler is not None and Filters is not None: dp.add_handler(MessageHandler(Filters.text & (~Filters.command), text_router))
    set_commands(updater)
    log_runtime(f"telegram_state=commands_installed version={BOT_VERSION}")
    update_brain_status('running')
    threading.Thread(target=heartbeat_loop, daemon=True).start()
    updater.start_polling(drop_pending_updates=True)
    startup_notify(updater)
    log_runtime(f"{BOT_VERSION} telegram polling_started")
    log_runtime("telegram_state=running error=-")
    updater.idle()






# =============================================================================
# v366: 버전표시 단일화 - tail override도 현재 버전으로 고정
# v358: S 단일 등급을 S1/S2/S3로 분리해 표시/성과판 단일화
# - S1: 즉시 paper OPEN 대상
# - S2: 재확인 대기 후보
# - S3: 관찰/복기 후보
# - 기존 A/B/C 기본 출력은 제거하고, 과거 S/A는 S1로, B/C는 S3로만 호환 표시한다.
# =============================================================================
BOT_VERSION = "수익형 v2.13.369"
CLEAN_WORKER_HUB_LABEL = "clean worker hub v369"

def _v358_stage_from_row(row: Dict[str, Any]) -> str:
    ctx = row.get('entry_context') if isinstance(row.get('entry_context'), dict) else {}
    g = str(row.get('s_stage') or row.get('candidate_grade') or row.get('grade') or row.get('entry_grade') or row.get('signal_grade') or ctx.get('s_stage') or ctx.get('candidate_grade') or '').upper().strip()
    if g in {'S1','S2','S3','X'}:
        return g
    if g in {'S','A'}:
        return 'S1'
    if g in {'B','C'}:
        return 'S3'
    label = str(row.get('candidate_grade_label') or ctx.get('candidate_grade_label') or '')
    if 'S1' in label or '즉시' in label:
        return 'S1'
    if 'S2' in label or '재확인' in label:
        return 'S2'
    if 'S3' in label or '관찰' in label or '복기' in label:
        return 'S3'
    if '제외' in label or '차단' in label or '금지' in label:
        return 'X'
    return 'S1'

def _v358_stage_label(stage: str) -> str:
    return {
        'S1': '✅ S1 즉시진입',
        'S2': '⚠️ S2 재확인',
        'S3': '❔ S3 관찰복기',
        'X': '❌ 제외',
    }.get(str(stage or '').upper(), str(stage or '-'))

def _v358_stage_counts_from_latest(max_lines: int = 300) -> Counter:
    c = Counter()
    try:
        for r in read_jsonl(FILES['paper_latest'], max_lines=max_lines):
            if isinstance(r, dict): c[_v358_stage_from_row(r)] += 1
    except Exception:
        pass
    return c

def _paper_grade(row: Dict[str, Any]) -> str:  # type: ignore[override]
    return _v358_stage_from_row(row)

def score_text()->str:  # type: ignore[override]
    cache = _current_paper_score_cache()
    raw = load_json(FILES['paper_score'], {}) or {}
    lines=["📊 S1/S2/S3 스코어 /score", "- 목적: 닫힌 paper 결과를 S1/S2/S3와 대표전략 기준으로 본다. S2/S3는 주로 재확인·관찰용이라 CLOSED가 적을 수 있음."]
    label_map={'money_reaccel_s':'돈흐름 재가속','leader_momentum_s':'주도추세 지속','breakout_early_s':'돌파 초입','sweep_vwap_recovery_s':'저점 VWAP 회복','surge_rebreak_s':'급등 후 재돌파','leader_flow_adaptive_hold_s':'주도흐름 유동보유'}
    if cache:
        gs = cache.get('grade_stats') if isinstance(cache.get('grade_stats'), dict) else {}
        current_n=int(fnum(cache.get('current_closed_count') or 0,0))
        primary_stats = cache.get('strategy_primary_stats') if isinstance(cache.get('strategy_primary_stats'), list) else cache.get('strategy_s_stats') if isinstance(cache.get('strategy_s_stats'), list) else []
        overlap_stats = cache.get('strategy_overlap_stats') if isinstance(cache.get('strategy_overlap_stats'), list) else []
        primary_total=int(fnum(cache.get('strategy_primary_total') or sum(int(fnum(x.get('n') or 0,0)) for x in primary_stats if isinstance(x,dict)),0))
        overlap_total=int(fnum(cache.get('strategy_overlap_total') or sum(int(fnum(x.get('n') or 0,0)) for x in overlap_stats if isinstance(x,dict)),0))
        lines.append(f"- 캐시 age {age(FILES['paper_score']):.1f}s / 현재판 CLOSED {current_n}개 / 대표전략 집계 {primary_total}개")
        lines += [
            _score_stat_line('✅ S1 즉시진입', gs.get('S1', gs.get('S', {}))),
            _score_stat_line('⚠️ S2 재확인', gs.get('S2', {})),
            _score_stat_line('❔ S3 관찰복기', gs.get('S3', {})),
            _score_stat_line('현재판 전체', gs.get('ALL', {})),
        ]
        lines += ["", "[대표전략 기준 · 실제 거래수와 맞는 성과]"]
        stat_map={str(st.get('key') or st.get('label') or ''):st for st in primary_stats if isinstance(st,dict)}
        for key,label in label_map.items():
            lines.append(_score_stat_line(label, stat_map.get(key, {})))
        if overlap_stats:
            lines += ["", f"[중복태그 포함 · 참고용 / 합계 {overlap_total}개]"]
            over_map={str(st.get('key') or st.get('label') or ''):st for st in overlap_stats if isinstance(st,dict)}
            for key,label in label_map.items():
                lines.append(_score_stat_line(label, over_map.get(key, {})))
            if overlap_total > current_n:
                lines.append(f"- ⚠️ 중복태그 때문에 참고용 합계가 CLOSED보다 {overlap_total-current_n}개 많습니다.")
    else:
        old_ver = raw.get('version','없음') if isinstance(raw,dict) else '없음'
        old_schema = raw.get('schema','-') if isinstance(raw,dict) else '-'
        lines.append(f"- ✅ 구 score cache 차단: {old_ver} / {old_schema}")
        lines.append("- 현재판 paper_bot score cache 준비중입니다. 예전 승률·수익률은 기본 /score에 섞지 않습니다.")
    strat=load_json(FILES['strategy_summary'],{}) or {}
    pbh=load_json(FILES['paperbot_handoff'],{}) or {}
    if strat:
        router=load_json(FILES.get('target_router', BASE_DIR/'clean_target_router_queue.json'),{}) or {}
        sc = _v358_stage_counts_from_latest()
        lines += ["", "[현재 후보/정보 흐름]"]
        lines.append(f"- 현재 S1 {sc.get('S1',0)} / S2 {sc.get('S2',0)} / S3 {sc.get('S3',0)} / latest {strat.get('paper_latest_count',0)} / paper 병합 {pbh.get('merged_fresh','-')} / archive {pbh.get('archive_window','-')}")
        lines.append(f"- 정보: 전체 {strat.get('evaluated','-')}개 / 시세 {strat.get('quote_ready_count','-')} / micro {strat.get('micro_ready_count','-')} / 둘다 {strat.get('full_info_ready_count','-')}")
        lines.append(f"- 배차: 전체 {router.get('queue_count','-')} / 내보냄 {router.get('export_count', router.get('active_target_count','-'))} / 대기 {router.get('rotation_wait_count','-')} / 버림 {router.get('dropped_count',0)}")
    return "\n".join(lines)

def pscore_text() -> str:  # type: ignore[override]
    txt = score_text()
    return txt.replace('📊 S1/S2/S3 스코어 /score', '📊 paper S1/S2/S3 스코어 /pscore · 메인봇 캐시전용', 1)

def pstatus_text() -> str:  # type: ignore[override]
    status = load_json(FILES['paper_status'], {}) or {}
    open_pos = _paper_open_positions()
    cache = _paper_score_cache_current()
    hand = load_json(FILES['paperbot_handoff'], {}) or {}
    grade_counts = Counter(_paper_grade(p) for p in open_pos.values() if isinstance(p, dict))
    lines = [
        '🧪 paper 상태 /pstatus · 메인봇 캐시전용',
        '- paper_bot 명령을 메인봇방에서 읽는 요약입니다. 실행/장부/알림은 paper_bot 담당.',
        f"- 상태: {'ON' if status.get('running', True) else '확인필요'} / loop {status.get('loop_sec', status.get('loop_interval_sec', '-'))}s / OPEN {len(open_pos)} / age {age(FILES['paper_status']):.1f}s",
        f"- OPEN: S1 {grade_counts.get('S1',0)} / S2 {grade_counts.get('S2',0)} / S3 {grade_counts.get('S3',0)} / 제외 {grade_counts.get('X',0)}",
        f"- handoff: latest {hand.get('latest_count', hand.get('paper_latest_count','-'))} / archive창 {hand.get('archive_window','-')} / 병합fresh {hand.get('merged_fresh','-')}",
        f"- 선별배관: 읽음 {status.get('pick_stats',{}).get('paper_file','-') if isinstance(status.get('pick_stats'),dict) else '-'} / S1선택 {status.get('pick_stats',{}).get('v369_s1_selected', status.get('pick_stats',{}).get('v368_s1_open','-')) if isinstance(status.get('pick_stats'),dict) else '-'} / S2보류 {status.get('pick_stats',{}).get('v369_s2_trace','-') if isinstance(status.get('pick_stats'),dict) else '-'} / S3관찰 {status.get('pick_stats',{}).get('v369_s3_trace','-') if isinstance(status.get('pick_stats'),dict) else '-'} / 실제OPEN {status.get('opened_this_cycle','-')}",
    ]
    if cache:
        gs = cache.get('grade_stats') if isinstance(cache.get('grade_stats'), dict) else {}
        current_n = int(fnum(cache.get('current_closed_count') or 0, 0))
        primary_total = int(fnum(cache.get('strategy_primary_total') or 0, 0))
        lines += [
            f"- 성과범위: 현재판 앵커 이후 / {cache.get('anchor_text','-')} / CLOSED {current_n}개 / 대표전략 집계 {primary_total}개",
            '[현재판 성과]',
            _stat_line('✅ S1 즉시진입', gs.get('S1', gs.get('S', {}))),
            _stat_line('⚠️ S2 재확인', gs.get('S2', {})),
            _stat_line('❔ S3 관찰복기', gs.get('S3', {})),
            _stat_line('현재판 전체', gs.get('ALL', {})),
            '- 전략별 상세는 /pscore 또는 /score',
        ]
    else:
        raw = load_json(FILES['paper_score'], {}) or {}
        lines += ['- 현재판 score cache 준비중', f"- 구버전 성과캐시 무시: {raw.get('version','-')} / {raw.get('schema','-')}"]
    return '\n'.join(lines)

def quality_text()->str:  # type: ignore[override]
    reject=load_json(FILES['strategy_reject'],{}) or {}; strat=load_json(FILES['strategy_summary'],{}) or {}
    hand=load_json(FILES['paper_handoff'],{}) or {}; pbh=load_json(FILES['paperbot_handoff'],{}) or {}
    latest_lines=line_count(FILES['paper_latest']); archive_lines=line_count(FILES['paper_archive'])
    router=load_json(FILES.get('target_router', BASE_DIR/'clean_target_router_queue.json'),{}) or {}
    evaluated=int(fnum(reject.get('evaluated') or strat.get('evaluated') or 0,0))
    quote=int(fnum(reject.get('quote_ready_count') or strat.get('quote_ready_count') or evaluated,0))
    micro=int(fnum(reject.get('micro_ready_count') or strat.get('micro_ready_count') or 0,0))
    both=int(fnum(reject.get('full_info_ready_count') or strat.get('full_info_ready_count') or min(quote,micro),0))
    sc=_v358_stage_counts_from_latest(); not_micro=max(0,evaluated-micro) if evaluated else 0
    lines=[
        '🔍 후보품질 /quality',
        f"✅ 전체 {evaluated}개 평가 / S1 {sc.get('S1',0)} / S2 {sc.get('S2',0)} / S3 {sc.get('S3',0)} / latest {latest_lines}줄 / 병합 {pbh.get('merged_fresh','-')}",
        '', '[S1/S2/S3 의미]',
        '- S1: 즉시 paper OPEN / S2: 재확인 후 승격 후보 / S3: 관찰·복기 후보',
        '- 유동보유: 0~5분 검증 → 5~30분 확인 → 30~120분 확장 관찰',
        '', '[정보가 얼마나 채워졌나]',
        f"- 시세: {quote}/{evaluated}개 / 호가·체결: {micro}/{evaluated}개 / 둘다: {both}/{evaluated}개",
        f"- 아직 micro 미신선: {not_micro}개 / 지금 꼭 필요한 micro: {router.get('need_micro') or reject.get('info_pending_count') or 0}개",
        '', '[안 넣은 게 아니라 단계 분리]',
        f"- 전체배차 {router.get('queue_count','-')}개 → 이번내보냄 {router.get('export_count', router.get('active_target_count','-'))}",
        f"- 순환대기 {router.get('rotation_wait_count','-')}개 / 버림 {router.get('dropped_count',0)}개 / safety초과 {router.get('safety_overflow',0)}개",
        '', '[탈락/보류 사유 TOP]'
    ]
    top=reject.get('reason_top') if isinstance(reject.get('reason_top'),list) else []
    if top:
        for r in top[:12]:
            lines.append(f"- ❔ {r.get('reason')}: {r.get('count')}")
    else:
        lines.append('- 아직 집계 없음')
    return '\n'.join(lines)

def popen_text() -> str:  # type: ignore[override]
    open_pos = _paper_open_positions()
    lines = ['📂 paper OPEN /popen · 메인봇 캐시전용']
    if not open_pos:
        return '\n'.join(lines + ['OPEN 없음'])
    rows = [p for p in open_pos.values() if isinstance(p, dict)]
    rows.sort(key=lambda p: fnum(p.get('opened_at') or p.get('entry_ts') or 0, 0), reverse=True)
    by_stage = Counter(_paper_grade(p) for p in rows)
    by_strategy = Counter(_paper_strategy_label(p) for p in rows)
    lines.append('등급별 OPEN: ' + ' / '.join(f'{_v358_stage_label(k)} {v}' for k,v in by_stage.items()))
    lines.append('전략별 OPEN: ' + ' / '.join(f'{k} {v}' for k, v in by_strategy.items()))
    for p in rows[:10]:
        t = _short_ticker(p.get('ticker') or p.get('symbol'))
        pnl = _pos_profit_pct(p); hold = _pos_hold_sec(p); vals = _pos_snapshot_flat(p)
        buy = vals.get('buy_ratio') or vals.get('micro_trade_buy_ratio_30') or '-'
        reason = p.get('reason') or p.get('entry_reason') or p.get('watch_note') or 'time_exit 대기'
        try: buy_txt = f"{float(buy):.2f}"
        except Exception: buy_txt = str(buy)
        lines.append(f"- {_v358_stage_label(_paper_grade(p))} {t} / {_paper_strategy_label(p)} / 진입 {_pos_entry_price(p)} / 현재 {_pos_current_price(p)} / {pnl:+.2f}% / 보유 {int(hold//60)}분 {int(hold%60)}초 / 감시 {reason}")
        lines.append(f"  · 근거: 매수체결 {buy_txt} / 주의: {p.get('risk_label') or p.get('risk_tags') or '특이사항 없음'}")
    if len(rows) > 10:
        lines.append(f"- 나머지 {len(rows)-10}개는 이후 full에서 확인")
    return '\n'.join(lines)

def set_commands(updater):  # type: ignore[override]
    try:
        updater.bot.set_my_commands([BotCommand('health','메인/worker/paper 빠른상태'),BotCommand('workers','worker 상세 상태'),BotCommand('score','S1/S2/S3 성과'),BotCommand('version_score','버전별 성과'),BotCommand('quality','S1/S2/S3 후보품질'),BotCommand('pstatus','paper 상태'),BotCommand('popen','paper OPEN'),BotCommand('preview','손실+놓친후보 복기'),BotCommand('missed_trace','후보 handoff 추적'),BotCommand('errorlog','오류로그'),BotCommand('batch','묶음 확인')])
    except Exception as exc: log_error('set_commands',exc)

def startup_notify(updater):  # type: ignore[override]
    try:
        if not CHAT_ID:
            return
        text=(f"✅ 메인봇 시작 완료\n- 버전: {BOT_VERSION}\n- 구조: {CLEAN_WORKER_HUB_LABEL}\n- 등급: S1 즉시진입 / S2 재확인 / S3 관찰복기\n- 새 전략: 주도흐름 유동보유\n- 명령: /health /score /quality /pstatus /popen /preview /errorlog")
        updater.bot.send_message(chat_id=CHAT_ID, text=text)
    except Exception as exc:
        log_error('startup_notify', exc)


# =============================================================================
# v360: COMMANDS 재바인딩 + S1/S2/S3 기본 출력 고정
# - v358에서 /score, /pstatus가 COMMANDS 초기 참조 때문에 구 함수로 남는 문제를 제거한다.
# - 새 기준은 S1 즉시진입 / S2 재확인 / S3 관찰복기만 기본 출력한다.
# =============================================================================
try:
    COMMANDS.update({
        'health': health_text,
        'core': health_text,
        'workers': workers_text,
        'score': score_text,
        'quality': quality_text,
        'strategy_watch': strategy_watch_text,
        'pipe_check': pipe_check_text,
        'pstatus': pstatus_text,
        'pscore': pscore_text,
        'popen': popen_text,
        'ploss_review': ploss_review_text,
        'pmissed_review': pmissed_review_text,
        'preview': preview_text,
        'loss_review': ploss_review_text,
        'missed_review': pmissed_review_text,
        'missed_trace': missed_trace_text,
        'trace_missed': missed_trace_text,
        'errorlog': errorlog_text,
        'popen_short': open_text,
    })
except Exception:
    pass


# =============================================================================
# v367: /version_score 최근 3개 적용버전 + S2/S3 관찰 배관 표시 단일화
# - 구 worker 버전명 나열을 기본 출력에서 끊고, 최근 3개 적용 버전만 본다.
# - 새 CLOSED는 main/deploy version 필드를 우선 사용한다.
# - S2/S3는 CLOSED가 적을 수 있으므로 /quality 현재 후보와 /missed_trace 중심으로 판단한다.
# =============================================================================
BOT_VERSION = "수익형 v2.13.369"
CLEAN_WORKER_HUB_LABEL = "clean worker hub v369"

_VERSION_SCORE_LIMIT = 3

def _v367_version_key(row: Dict[str, Any]) -> str:
    row = as_dict(row)
    ctx = as_dict(row.get('entry_context'))
    raw = as_dict(row.get('raw'))
    snap = as_dict(row.get('entry_snapshot'))
    flat = as_dict(snap.get('flat'))
    vals = [
        row.get('main_version'), row.get('main_bot_version'), row.get('deploy_version'), row.get('deployed_version'), row.get('bot_version'),
        ctx.get('main_version'), ctx.get('main_bot_version'), ctx.get('deploy_version'), ctx.get('deployed_version'), ctx.get('bot_version'),
        raw.get('main_version'), raw.get('main_bot_version'), raw.get('deploy_version'), raw.get('deployed_version'), raw.get('bot_version'),
        flat.get('main_version'), flat.get('main_bot_version'), flat.get('deploy_version'), flat.get('deployed_version'), flat.get('bot_version'),
    ]
    vals_fallback = [row.get('opened_brain_version'), row.get('brain_version'), ctx.get('opened_brain_version'), ctx.get('brain_version'), raw.get('brain_version')]
    for seq in (vals, vals_fallback):
        for v in seq:
            s = str(v or '').strip()
            if not s:
                continue
            m = re.search(r'v?2[._]13[._](\d+)', s)
            if m:
                return f"v2.13.{int(m.group(1))}"
            m = re.search(r'v(\d{3,})', s)
            if m:
                return f"v2.13.{int(m.group(1))}"
            if 'strategy_worker' in s:
                return s[:32]
    return '버전 미기록'

def _v367_version_sort(ver: str, arr: List[Dict[str, Any]]) -> Tuple[int, float]:
    m = re.search(r'v2\.13\.(\d+)', str(ver))
    n = int(m.group(1)) if m else -1
    latest = max((_v365_closed_ts(r) for r in arr), default=0.0)
    return (n, latest)

def version_score_text() -> str:  # type: ignore[override]
    rows = [r for r in read_jsonl(FILES.get('paper_closed', BASE_DIR/'paper_bot_closed.jsonl'), max_lines=30000) if isinstance(r, dict)]
    groups: Dict[str, List[Dict[str, Any]]] = {}
    for r in rows:
        groups.setdefault(_v367_version_key(r), []).append(r)
    items = []
    for ver, arr in groups.items():
        if ver == '버전 미기록':
            continue
        items.append((_v367_version_sort(ver, arr), ver, arr))
    items.sort(key=lambda x: x[0], reverse=True)
    items = items[:_VERSION_SCORE_LIMIT]
    lines = [
        '📊 버전별 성과 /version_score',
        f'- 기본 출력: 최근 적용 버전 {_VERSION_SCORE_LIMIT}개만 표시합니다.',
        '- 기준: paper CLOSED 장부 직접 조회 / 메인 적용버전 우선 / worker 버전은 보조값',
        '',
        '[최근 3개 버전 요약]'
    ]
    if not items:
        lines.append('- 아직 버전이 기록된 CLOSED 장부 없음')
        return '\n'.join(lines)
    for _, ver, arr in items:
        st = _v365_stat(arr)
        icon = '✅' if st.get('total',0) > 0 else ('⚠️' if st.get('n',0) < 10 else '❌')
        lines.append(_v365_stat_line(f'{icon} {ver}', arr))
    latest_ver = items[0][1]
    latest_rows = items[0][2]
    strat_groups: Dict[str, List[Dict[str, Any]]] = {}
    for r in latest_rows:
        strat_groups.setdefault(_v365_strategy_key(r), []).append(r)
    label_map={'money_reaccel_s':'돈흐름 재가속','leader_momentum_s':'주도추세 지속','breakout_early_s':'돌파 초입','sweep_vwap_recovery_s':'저점 VWAP 회복','surge_rebreak_s':'급등 후 재돌파','leader_flow_adaptive_hold_s':'주도흐름 유동보유','unknown':'대표전략 미확인'}
    lines += ['', f'[최신 버전 전략별 · {latest_ver}]']
    if strat_groups:
        for k, arr in sorted(strat_groups.items(), key=lambda kv: len(kv[1]), reverse=True)[:8]:
            lines.append(_v365_stat_line(label_map.get(k,k), arr))
    else:
        lines.append('- 아직 최신 버전 CLOSED 없음')
    lines += ['', '[판독]', '- /score는 현재판 anchor 성과, /version_score는 최근 3개 적용버전 비교입니다.', '- 오래된 worker 버전 나열은 기본 출력에서 제외했습니다.']
    return '\n'.join(lines)

try:
    COMMANDS.update({'version_score': version_score_text, 'vscore': version_score_text})
except Exception:
    pass



# =============================================================================
# main v2.13.369: 최근 3개 적용버전 고정 + trace/quality 표시 정리
# =============================================================================
BOT_VERSION = "수익형 v2.13.369"
CLEAN_WORKER_HUB_LABEL = "clean worker hub v369"
_VERSION_SCORE_LIMIT = 3
_CURRENT_MAIN_VER = "v2.13.369"


def _v369_ver_num(ver: str) -> int:
    m=re.search(r'v?2[._]13[._](\d+)', str(ver or ''))
    return int(m.group(1)) if m else -1


def _v369_recent_main_versions(n: int = 3) -> List[str]:
    cur=_v369_ver_num(_CURRENT_MAIN_VER)
    if cur <= 0:
        return [_CURRENT_MAIN_VER]
    return [f"v2.13.{cur-i}" for i in range(n)]


def _v369_main_version_key(row: Dict[str, Any]) -> str:
    row=as_dict(row); ctx=as_dict(row.get('entry_context')); raw=as_dict(row.get('raw')); snap=as_dict(row.get('entry_snapshot')); flat=as_dict(snap.get('flat'))
    vals=[row.get('main_version'),row.get('main_bot_version'),row.get('deploy_version'),row.get('deployed_version'),row.get('bot_version'),ctx.get('main_version'),ctx.get('main_bot_version'),ctx.get('deploy_version'),ctx.get('deployed_version'),ctx.get('bot_version'),raw.get('main_version'),raw.get('deploy_version'),flat.get('main_version'),flat.get('deploy_version')]
    for v in vals:
        s=str(v or '').strip()
        if not s or 'strategy_worker' in s or 'paper_bot' in s:
            continue
        m=re.search(r'v?2[._]13[._](\d+)', s)
        if m:
            return f"v2.13.{int(m.group(1))}"
        m=re.search(r'v(\d{3,})', s)
        if m:
            num=int(m.group(1))
            if num >= 340:
                return f"v2.13.{num}"
    return '버전 미기록'


def version_score_text() -> str:  # type: ignore[override]
    rows=[r for r in read_jsonl(FILES.get('paper_closed', BASE_DIR/'paper_bot_closed.jsonl'), max_lines=30000) if isinstance(r, dict)]
    wanted=_v369_recent_main_versions(_VERSION_SCORE_LIMIT)
    groups={v: [] for v in wanted}
    missing=0
    for r in rows:
        k=_v369_main_version_key(r)
        if k in groups:
            groups[k].append(r)
        elif k == '버전 미기록':
            missing += 1
    lines=['📊 버전별 성과 /version_score', f'- 기본 출력: 최근 적용 버전 {_VERSION_SCORE_LIMIT}개만 표시합니다.', '- 기준: main_version/deploy_version 기록만 사용합니다. worker 버전 줄세우기는 기본에서 제외합니다.', '', '[최근 3개 버전 요약]']
    for ver in wanted:
        arr=groups.get(ver, [])
        if arr:
            lines.append(_v365_stat_line(('✅ ' if _v365_stat(arr).get('total',0)>0 else '❌ ') + ver, arr))
        else:
            lines.append(f'- ❔ {ver}: CLOSED 0건 / 아직 이 버전으로 닫힌 결과 없음')
    latest_ver=wanted[0]
    latest_rows=groups.get(latest_ver, [])
    label_map={'money_reaccel_s':'돈흐름 재가속','leader_momentum_s':'주도추세 지속','breakout_early_s':'돌파 초입','sweep_vwap_recovery_s':'저점 VWAP 회복','surge_rebreak_s':'급등 후 재돌파','leader_flow_adaptive_hold_s':'주도흐름 유동보유','unknown':'대표전략 미확인'}
    lines += ['', f'[최신 버전 전략별 · {latest_ver}]']
    if latest_rows:
        strat_groups={}
        for r in latest_rows:
            strat_groups.setdefault(_v365_strategy_key(r), []).append(r)
        for k, arr in sorted(strat_groups.items(), key=lambda kv: len(kv[1]), reverse=True)[:8]:
            lines.append(_v365_stat_line(label_map.get(k,k), arr))
    else:
        lines.append('- 아직 최신 버전 CLOSED 없음')
    if missing:
        lines += ['', f'- 참고: main_version 없는 과거 CLOSED {missing}건은 기본 비교에서 제외했습니다.']
    lines += ['', '[판독]', '- /score는 현재판 anchor 성과, /version_score는 최근 3개 적용버전만 비교합니다.', '- 새 조건 효과는 최신 버전 줄만 보고, 예전 손실은 참고에서 제외합니다.']
    return '\n'.join(lines)


def batch_handler(update, context):  # type: ignore[override]
    cmds=context.args or ['health','version_score','score','quality','missed_trace','errorlog']
    cmds=[str(x).strip().lstrip('/') for x in cmds[:12] if str(x).strip()]
    st=time.time(); sent=0; timings=[]
    try:
        send(update, f"📦 자동 묶음 명령 접수\n- 실행 {len(cmds)}개\n- v369: 최근3버전 성과 + S2/S3 관찰배관 + actual trace 단일화")
    except Exception:
        pass
    total=len(cmds)
    for raw in cmds:
        name=raw.strip().lstrip('/')
        fn=COMMANDS.get(name)
        if not fn:
            continue
        t=time.time()
        try:
            body=fn(); ok='OK'
        except Exception as exc:
            body=f"❌ /{name} 오류 {exc.__class__.__name__}: {exc}"; ok='ERR'; log_error(f'batch_{name}', exc)
        sec=time.time()-t; sent+=1
        timings.append(f"- {'✅' if ok=='OK' else '❌'} /{name}: {sec:.2f}s / {ok}")
        send(update, f"[{sent}/{total}] /{name} ({sec:.2f}s / {ok})\n{body}")
    send(update, "🧾 자동 묶음 시간표 · v369 명령별 전송\n"+"\n".join(timings)+f"\n- 합계 {time.time()-st:.2f}s")

try:
    COMMANDS.update({'version_score': version_score_text, 'vscore': version_score_text})
except Exception:
    pass



# =============================================================================
# main v2.13.369 / v377: 구 S 전적 착시 제거 + 상태판 숫자 기준 설명
# - 구 S/A CLOSED를 새 S1 성과로 보여주지 않는다.
# - 새 S1/S2/S3 성과는 명시 등급이 있는 CLOSED만 따로 본다.
# - /pstatus의 읽음/S2/S3 숫자 기준이 다르면 설명을 붙여 착시를 줄인다.
# =============================================================================
def _v377_score_cache_current() -> Dict[str, Any]:
    c = load_json(FILES['paper_score'], {}) or {}
    if not isinstance(c, dict) or not c:
        return {}
    ver = str(c.get('version') or '')
    if not _paper_score_cache_version_ok(ver):
        return {}
    if str(c.get('score_scope') or '') != 'current_version_anchor':
        return {}
    if c.get('current_closed_count') is None:
        return {}
    schema = str(c.get('schema') or '')
    if schema not in {'paper_score_cache_v086', 'paper_score_cache_v377'}:
        return {}
    return c

_current_paper_score_cache = _v377_score_cache_current  # type: ignore[assignment]
_paper_score_cache_current = _v377_score_cache_current  # type: ignore[assignment]


def _v377_cache_pick_stats(status: Dict[str, Any], cache: Dict[str, Any]) -> Dict[str, Any]:
    pick = status.get('pick_stats') if isinstance(status.get('pick_stats'), dict) else {}
    if not pick and isinstance(cache.get('pick_stats'), dict):
        pick = cache.get('pick_stats') or {}
    return pick if isinstance(pick, dict) else {}


def _v377_score_line(label: str, st: Any) -> str:
    return _score_stat_line(label, st if isinstance(st, dict) else {})


def score_text() -> str:  # type: ignore[override]
    cache = _v377_score_cache_current()
    raw = load_json(FILES['paper_score'], {}) or {}
    lines = [
        '📊 S1/S2/S3 스코어 /score',
        '- 목적: 구 S 통합전적과 새 S1/S2/S3 전적을 분리해서 봅니다.',
        '- 주의: 예전 S 전적은 새 S1 성과가 아닙니다. 새 등급은 v377 앵커 이후부터 따로 쌓습니다.',
    ]
    label_map={'money_reaccel_s':'돈흐름 재가속','leader_momentum_s':'주도추세 지속','breakout_early_s':'돌파 초입','sweep_vwap_recovery_s':'저점 VWAP 회복','surge_rebreak_s':'급등 후 재돌파','leader_flow_adaptive_hold_s':'주도흐름 유동보유'}
    if cache:
        gs = cache.get('grade_stats') if isinstance(cache.get('grade_stats'), dict) else {}
        current_n = int(fnum(cache.get('current_closed_count') or 0, 0))
        primary_stats = cache.get('strategy_primary_stats') if isinstance(cache.get('strategy_primary_stats'), list) else cache.get('strategy_s_stats') if isinstance(cache.get('strategy_s_stats'), list) else []
        overlap_stats = cache.get('strategy_overlap_stats') if isinstance(cache.get('strategy_overlap_stats'), list) else []
        primary_total = int(fnum(cache.get('strategy_primary_total') or sum(int(fnum(x.get('n') or 0,0)) for x in primary_stats if isinstance(x,dict)),0))
        overlap_total = int(fnum(cache.get('strategy_overlap_total') or sum(int(fnum(x.get('n') or 0,0)) for x in overlap_stats if isinstance(x,dict)),0))
        lines.append(f"- 캐시 age {age(FILES['paper_score']):.1f}s / 현재판 CLOSED {current_n}개 / 대표전략 집계 {primary_total}개")
        lines += [
            '', '[등급별 성과 · 구/신 분리]',
            _v377_score_line('📦 구 S 통합전적(참고)', gs.get('LEGACY_S', gs.get('S', {}))),
            _v377_score_line('✅ 새 S1 즉시진입', gs.get('S1', {})),
            _v377_score_line('⚠️ 새 S2 재확인', gs.get('S2', {})),
            _v377_score_line('❔ 새 S3 관찰복기', gs.get('S3', {})),
            _v377_score_line('현재판 전체', gs.get('ALL', {})),
        ]
        if isinstance(gs.get('LEGACY_S'), dict) and int(fnum(gs.get('LEGACY_S',{}).get('n'),0)):
            lines.append('- 판독: 위 구 S 통합전적은 S1/S2/S3 분리 전 기록이라 새 S1 성과로 판단하지 않습니다.')
        lines += ['', '[대표전략 기준 · 실제 거래수와 맞는 성과]']
        stat_map={str(st.get('key') or st.get('label') or ''):st for st in primary_stats if isinstance(st,dict)}
        for key,label in label_map.items():
            lines.append(_v377_score_line(label, stat_map.get(key, {})))
        if overlap_stats:
            lines += ['', f'[중복태그 포함 · 참고용 / 합계 {overlap_total}개]']
            over_map={str(st.get('key') or st.get('label') or ''):st for st in overlap_stats if isinstance(st,dict)}
            for key,label in label_map.items():
                lines.append(_v377_score_line(label, over_map.get(key, {})))
            if overlap_total > current_n:
                lines.append(f'- ⚠️ 중복태그 때문에 참고용 합계가 CLOSED보다 {overlap_total-current_n}개 많습니다.')
    else:
        old_ver = raw.get('version','없음') if isinstance(raw,dict) else '없음'
        old_schema = raw.get('schema','-') if isinstance(raw,dict) else '-'
        lines.append(f'- ✅ 구 score cache 차단/대기: {old_ver} / {old_schema}')
        lines.append('- 다음 paper loop에서 v377 score cache가 생성되면 구 S와 새 S1/S2/S3가 분리 표시됩니다.')
    strat=load_json(FILES['strategy_summary'],{}) or {}
    pbh=load_json(FILES['paperbot_handoff'],{}) or {}
    if strat:
        router=load_json(FILES.get('target_router', BASE_DIR/'clean_target_router_queue.json'),{}) or {}
        sc = _v358_stage_counts_from_latest() if '_v358_stage_counts_from_latest' in globals() else Counter()
        lines += ['', '[현재 후보/정보 흐름]']
        lines.append(f"- 현재 후보: S1 {sc.get('S1',0)} / S2 {sc.get('S2',0)} / S3 {sc.get('S3',0)} / latest {strat.get('paper_latest_count',0)} / paper 병합 {pbh.get('merged_fresh','-')} / archive {pbh.get('archive_window','-')}")
        lines.append(f"- 정보: 전체 {strat.get('evaluated','-')}개 / 시세 {strat.get('quote_ready_count','-')} / micro {strat.get('micro_ready_count','-')} / 둘다 {strat.get('full_info_ready_count','-')}")
        lines.append(f"- 배차: 전체 {router.get('queue_count','-')} / 내보냄 {router.get('export_count', router.get('active_target_count','-'))} / 대기 {router.get('rotation_wait_count','-')} / 버림 {router.get('dropped_count',0)}")
    return '\n'.join(lines)


def pscore_text() -> str:  # type: ignore[override]
    txt = score_text()
    return txt.replace('📊 S1/S2/S3 스코어 /score', '📊 paper S1/S2/S3 스코어 /pscore · 메인봇 캐시전용', 1)


def pstatus_text() -> str:  # type: ignore[override]
    status = load_json(FILES['paper_status'], {}) or {}
    open_pos = _paper_open_positions()
    cache = _v377_score_cache_current()
    hand = load_json(FILES['paperbot_handoff'], {}) or {}
    grade_counts = Counter(_paper_grade(p) for p in open_pos.values() if isinstance(p, dict))
    pick = _v377_cache_pick_stats(status, cache)
    read_n = pick.get('paper_file', pick.get('read', pick.get('read_count', '-')))
    s1_sel = pick.get('v369_s1_selected', pick.get('v368_s1_open', pick.get('grade_s1_open', pick.get('grade_s1_seen','-'))))
    s2_n = pick.get('v369_s2_trace', pick.get('grade_s2_recheck', pick.get('grade_s2_seen','-')))
    s3_n = pick.get('v369_s3_trace', pick.get('grade_s3_observe', pick.get('grade_s3_seen','-')))
    opened = status.get('opened_this_cycle', '-')
    latest = hand.get('latest_count', hand.get('latest_lines', hand.get('paper_latest_count','-')))
    lines = [
        '🧪 paper 상태 /pstatus · 메인봇 캐시전용',
        '- paper_bot 명령을 메인봇방에서 읽는 요약입니다. 실행/장부/알림은 paper_bot 담당.',
        f"- 상태: {'ON' if status.get('running', True) else '확인필요'} / loop {status.get('loop_sec', status.get('loop_interval_sec', '-'))}s / OPEN {len(open_pos)} / age {age(FILES['paper_status']):.1f}s",
        f"- OPEN: S1 {grade_counts.get('S1',0)} / S2 {grade_counts.get('S2',0)} / S3 {grade_counts.get('S3',0)} / 제외 {grade_counts.get('X',0)}",
        f"- handoff: latest {latest} / archive창 {hand.get('archive_window','-')} / 병합fresh {hand.get('merged_fresh','-')}",
        f"- 선별배관: 읽음 {read_n} / S1선택 {s1_sel} / S2보류 {s2_n} / S3관찰 {s3_n} / 실제OPEN {opened}",
    ]
    try:
        if isinstance(read_n, (int,float)) and isinstance(s2_n, (int,float)) and isinstance(s3_n, (int,float)) and (s2_n+s3_n) > read_n:
            lines.append('- ⚠️ 숫자 기준: 읽음은 이번 cycle 기준, S2/S3는 병합/trace창 누적 기준이라 더 크게 보일 수 있습니다. 다음 판에서 cycle/trace 기준을 더 분리합니다.')
    except Exception:
        pass
    if cache:
        gs = cache.get('grade_stats') if isinstance(cache.get('grade_stats'), dict) else {}
        current_n = int(fnum(cache.get('current_closed_count') or 0, 0))
        primary_total = int(fnum(cache.get('strategy_primary_total') or 0, 0))
        lines += [
            f"- 성과범위: 현재판 앵커 이후 / {cache.get('anchor_text','-')} / CLOSED {current_n}개 / 대표전략 집계 {primary_total}개",
            '[현재판 성과 · 구/신 분리]',
            _v377_score_line('📦 구 S 통합전적(참고)', gs.get('LEGACY_S', gs.get('S', {}))),
            _v377_score_line('✅ 새 S1 즉시진입', gs.get('S1', {})),
            _v377_score_line('⚠️ 새 S2 재확인', gs.get('S2', {})),
            _v377_score_line('❔ 새 S3 관찰복기', gs.get('S3', {})),
            _v377_score_line('현재판 전체', gs.get('ALL', {})),
            '- 전략별 상세는 /pscore 또는 /score',
        ]
    else:
        raw = load_json(FILES['paper_score'], {}) or {}
        lines += ['- 현재판 score cache 준비중', f"- 구버전 성과캐시 무시/대기: {raw.get('version','-')} / {raw.get('schema','-')}"]
    return '\n'.join(lines)

try:
    COMMANDS.update({'score': score_text, 'pscore': pscore_text, 'pstatus': pstatus_text})
except Exception:
    pass



# =============================================================================
# main v2.13.369 / v379: S1/S2/S3를 승패표가 아닌 생애주기로 표시
# - S2/S3는 S1의 재료/하위단계이므로 승패를 표시하지 않는다.
# - 실제 승패는 S1 OPEN만 본다.
# - S3→S2→S1 승격 흐름, 정보부족, 놓친상승을 별도 표로 본다.
# =============================================================================
def _v379_score_cache_current() -> Dict[str, Any]:
    c = load_json(FILES['paper_score'], {}) or {}
    if not isinstance(c, dict) or not c:
        return {}
    ver = str(c.get('version') or '')
    if not _paper_score_cache_version_ok(ver):
        return {}
    if str(c.get('score_scope') or '') != 'current_version_anchor':
        return {}
    if c.get('current_closed_count') is None:
        return {}
    schema = str(c.get('schema') or '')
    if schema not in {'paper_score_cache_v086', 'paper_score_cache_v377', 'paper_score_cache_v378', 'paper_score_cache_v379', 'paper_score_cache_v383'}:
        return {}
    return c

_current_paper_score_cache = _v379_score_cache_current  # type: ignore[assignment]
_paper_score_cache_current = _v379_score_cache_current  # type: ignore[assignment]

def _v379_lifecycle_from_cache(cache: Dict[str, Any]) -> Dict[str, Any]:
    life = cache.get('lifecycle_stats') if isinstance(cache.get('lifecycle_stats'), dict) else cache.get('stage_stats') if isinstance(cache.get('stage_stats'), dict) else {}
    if isinstance(life, dict) and life:
        return life
    sm = load_json(FILES.get('strategy_summary', BASE_DIR/'clean_strategy_s_summary.json'), {}) or {}
    return sm.get('lifecycle_stats') if isinstance(sm.get('lifecycle_stats'), dict) else {}

def _v379_stage_lines(life: Dict[str, Any]) -> List[str]:
    stage_counts = life.get('active_stage_counts') if isinstance(life.get('active_stage_counts'), dict) else life.get('stage_counts') if isinstance(life.get('stage_counts'), dict) else {}
    transitions = life.get('transitions') if isinstance(life.get('transitions'), dict) else {}
    missed = life.get('missed_rise_counts') if isinstance(life.get('missed_rise_counts'), dict) else {}
    lines = ['[후보 생애주기 · 승패 아님]']
    lines.append(f"- S3 관찰포착: {int(fnum(stage_counts.get('S3'),0))}개 / 새 관찰 {int(fnum(transitions.get('new_s3'),0))} / S3→S2 {int(fnum(transitions.get('s3_to_s2'),0))}")
    lines.append(f"- S2 재확인: {int(fnum(stage_counts.get('S2'),0))}개 / S2유지 {int(fnum(transitions.get('s2_hold'),0))} / S2→S1 {int(fnum(transitions.get('s2_to_s1'),0))} / S1보류 {int(fnum(transitions.get('blocked_s1_signal'),0))}")
    fails = life.get('s2_to_s1_fail_reasons') if isinstance(life.get('s2_to_s1_fail_reasons'), dict) else {}
    if fails:
        top = sorted(fails.items(), key=lambda kv: int(fnum(kv[1],0)), reverse=True)[:5]
        lines.append('- S2→S1 실패 TOP: ' + ' / '.join(f"{k} {int(fnum(v,0))}" for k,v in top))
    lines.append(f"- S1 실제진입 대기: {int(fnum(stage_counts.get('S1'),0))}개")
    if missed:
        lines.append(f"- 놓친상승 참고: S2 +0.7%↑ {int(fnum(missed.get('S2_up_07'),0))}개 / S3 +0.7%↑ {int(fnum(missed.get('S3_up_07'),0))}개")
    lines.append('- 판독: S2/S3는 승패가 아니라 S1로 올라가기 전 재료·승격 흐름입니다.')
    return lines

def score_text() -> str:  # type: ignore[override]
    cache = _v379_score_cache_current()
    raw = load_json(FILES['paper_score'], {}) or {}
    lines = [
        '📊 S1/S2/S3 흐름표 /score',
        '- 목적: 실제 매매 성과와 S3→S2→S1 승격 흐름을 분리해서 봅니다.',
        '- 핵심: S2/S3는 승패 대상이 아니라 S1의 재료/하위단계입니다.',
    ]
    label_map={'money_reaccel_s':'돈흐름 재가속','leader_momentum_s':'주도추세 지속','breakout_early_s':'돌파 초입','sweep_vwap_recovery_s':'저점 VWAP 회복','surge_rebreak_s':'급등 후 재돌파','leader_flow_adaptive_hold_s':'주도흐름 유동보유'}
    if cache:
        gs = cache.get('grade_stats') if isinstance(cache.get('grade_stats'), dict) else {}
        life = _v379_lifecycle_from_cache(cache)
        current_n = int(fnum(cache.get('current_closed_count') or 0, 0))
        primary_stats = cache.get('strategy_primary_stats') if isinstance(cache.get('strategy_primary_stats'), list) else cache.get('strategy_s_stats') if isinstance(cache.get('strategy_s_stats'), list) else []
        overlap_stats = cache.get('strategy_overlap_stats') if isinstance(cache.get('strategy_overlap_stats'), list) else []
        primary_total = int(fnum(cache.get('strategy_primary_total') or sum(int(fnum(x.get('n') or 0,0)) for x in primary_stats if isinstance(x,dict)),0))
        overlap_total = int(fnum(cache.get('strategy_overlap_total') or sum(int(fnum(x.get('n') or 0,0)) for x in overlap_stats if isinstance(x,dict)),0))
        lines.append(f"- 캐시 age {age(FILES['paper_score']):.1f}s / 현재판 CLOSED {current_n}개 / 대표전략 집계 {primary_total}개")
        lines += ['', '[실제 모의매매 성과]']
        lines.append(_v377_score_line('📦 구 S 통합전적(참고)', gs.get('LEGACY_S', gs.get('S', {}))))
        lines.append(_v377_score_line('✅ 검증된 S1 OPEN', gs.get('S1', {})))
        if isinstance(gs.get('S1_UNVERIFIED'), dict) and int(fnum((gs.get('S1_UNVERIFIED') or {}).get('n'),0)):
            lines.append(_v377_score_line('⚠️ S1 표시 CLOSED(검증전)', gs.get('S1_UNVERIFIED', {})))
        lines.append(_v377_score_line('현재판 전체', gs.get('ALL', {})))
        lines.append('- 주의: 구 S 통합전적은 S1/S2/S3 분리 전 기록이라 새 S1 성과가 아닙니다.')
        if life:
            lines += [''] + _v379_stage_lines(life)
        else:
            lines += ['', '[후보 생애주기 · 승패 아님]', '- 생애주기 cache 준비중: 다음 strategy/paper loop 이후 표시됩니다.']
        lines += ['', '[대표전략 기준 · 실제 CLOSED 성과]']
        stat_map={str(st.get('key') or st.get('label') or ''):st for st in primary_stats if isinstance(st,dict)}
        for key,label in label_map.items():
            lines.append(_v377_score_line(label, stat_map.get(key, {})))
        if overlap_stats:
            lines += ['', f'[중복태그 포함 · 참고용 / 합계 {overlap_total}개]']
            over_map={str(st.get('key') or st.get('label') or ''):st for st in overlap_stats if isinstance(st,dict)}
            for key,label in label_map.items():
                lines.append(_v377_score_line(label, over_map.get(key, {})))
            if overlap_total > current_n:
                lines.append(f'- ⚠️ 중복태그 때문에 참고용 합계가 CLOSED보다 {overlap_total-current_n}개 많습니다.')
    else:
        old_ver = raw.get('version','없음') if isinstance(raw,dict) else '없음'
        old_schema = raw.get('schema','-') if isinstance(raw,dict) else '-'
        lines.append(f'- ✅ 구 score cache 차단/대기: {old_ver} / {old_schema}')
        lines.append('- 다음 paper loop에서 v379 score cache가 생성되면 구 S와 새 S1 실제 성과, S2/S3 생애주기가 분리 표시됩니다.')
    strat=load_json(FILES['strategy_summary'],{}) or {}
    pbh=load_json(FILES['paperbot_handoff'],{}) or {}
    if strat:
        router=load_json(FILES.get('target_router', BASE_DIR/'clean_target_router_queue.json'),{}) or {}
        sc = strat.get('s_stage_counts') if isinstance(strat.get('s_stage_counts'), dict) else (_v358_stage_counts_from_latest() if '_v358_stage_counts_from_latest' in globals() else Counter())
        lines += ['', '[현재 후보/정보 흐름]']
        lines.append(f"- 현재 후보: S1 {sc.get('S1',0)} / S2 {sc.get('S2',0)} / S3 {sc.get('S3',0)} / latest {strat.get('paper_latest_count',0)} / paper 병합 {pbh.get('merged_fresh','-')} / archive {pbh.get('archive_window','-')}")
        lines.append(f"- 정보: 전체 {strat.get('evaluated','-')}개 / 시세 {strat.get('quote_ready_count','-')} / micro {strat.get('micro_ready_count','-')} / 둘다 {strat.get('full_info_ready_count','-')}")
        lines.append(f"- 배차: 전체 {router.get('queue_count','-')} / 내보냄 {router.get('export_count', router.get('active_target_count','-'))} / 대기 {router.get('rotation_wait_count','-')} / 버림 {router.get('dropped_count',0)}")
    return '\n'.join(lines)

def pscore_text() -> str:  # type: ignore[override]
    txt = score_text()
    return txt.replace('📊 S1/S2/S3 흐름표 /score', '📊 paper S1/S2/S3 흐름표 /pscore · 메인봇 캐시전용', 1)

def pstatus_text() -> str:  # type: ignore[override]
    status = load_json(FILES['paper_status'], {}) or {}
    open_pos = _paper_open_positions()
    cache = _v379_score_cache_current()
    hand = load_json(FILES['paperbot_handoff'], {}) or {}
    strat = load_json(FILES['strategy_summary'], {}) or {}
    grade_counts = Counter(_paper_grade(p) for p in open_pos.values() if isinstance(p, dict))
    pick = _v377_cache_pick_stats(status, cache)
    read_n = pick.get('paper_file', pick.get('read', pick.get('read_count', '-')))
    s1_sel = pick.get('v369_s1_selected', pick.get('v368_s1_open', pick.get('grade_s1_open', pick.get('grade_s1_seen','-'))))
    s2_n = pick.get('v369_s2_trace', pick.get('grade_s2_recheck', pick.get('grade_s2_seen','-')))
    s3_n = pick.get('v369_s3_trace', pick.get('grade_s3_observe', pick.get('grade_s3_seen','-')))
    opened = status.get('opened_this_cycle', '-')
    latest = hand.get('latest_count', hand.get('latest_lines', hand.get('paper_latest_count','-')))
    lines = [
        '🧪 paper 상태 /pstatus · 메인봇 캐시전용',
        '- paper_bot 명령을 메인봇방에서 읽는 요약입니다. 실행/장부/알림은 paper_bot 담당.',
        f"- 상태: {'ON' if status.get('running', True) else '확인필요'} / loop {status.get('loop_sec', status.get('loop_interval_sec', '-'))}s / OPEN {len(open_pos)} / age {age(FILES['paper_status']):.1f}s",
        f"- OPEN: S1 {grade_counts.get('S1',0)} / 제외 {grade_counts.get('X',0)}",
        f"- handoff: latest {latest} / archive창 {hand.get('archive_window','-')} / 병합fresh {hand.get('merged_fresh','-')}",
        f"- 선별배관: 읽음 {read_n} / S1선택 {s1_sel} / 실제OPEN {opened}",
        f"- 재확인/관찰: S2 {s2_n} / S3 {s3_n}  ※ 승패가 아니라 S1 이전 단계",
    ]
    life = _v379_lifecycle_from_cache(cache) if cache else (strat.get('lifecycle_stats') if isinstance(strat.get('lifecycle_stats'), dict) else {})
    if life:
        lines += _v379_stage_lines(life)
    if cache:
        gs = cache.get('grade_stats') if isinstance(cache.get('grade_stats'), dict) else {}
        current_n = int(fnum(cache.get('current_closed_count') or 0, 0))
        primary_total = int(fnum(cache.get('strategy_primary_total') or 0, 0))
        lines += [
            f"- 성과범위: 현재판 앵커 이후 / {cache.get('anchor_text','-')} / CLOSED {current_n}개 / 대표전략 집계 {primary_total}개",
            '[현재판 실제 성과]',
            _v377_score_line('📦 구 S 통합전적(참고)', gs.get('LEGACY_S', gs.get('S', {}))),
            _v377_score_line('✅ 검증된 S1 OPEN', gs.get('S1', {})),
            _v377_score_line('⚠️ S1 표시 CLOSED(검증전)', gs.get('S1_UNVERIFIED', {})),
            _v377_score_line('현재판 전체', gs.get('ALL', {})),
            '- S2/S3는 실제 진입 전 단계라 승패로 표시하지 않습니다. 전략별 상세는 /pscore 또는 /score',
        ]
    else:
        raw = load_json(FILES['paper_score'], {}) or {}
        lines += ['- 현재판 score cache 준비중', f"- 구버전 성과캐시 무시/대기: {raw.get('version','-')} / {raw.get('schema','-')}"]
    return '\n'.join(lines)

try:
    COMMANDS.update({'score': score_text, 'pscore': pscore_text, 'pstatus': pstatus_text})
except Exception:
    pass




# =============================================================================
# main v2.13.369 / v380: /quality 사유 TOP 범위 분리
# - 기본 화면의 부족 TOP은 전체 455개 누적/전략별 실패가 아니라 이번 latest 후보(S2/S3/S1 미승격) 기준으로 본다.
# - 전체시장 reject reason_top은 참고 섹션으로 내린다.
# - 적용 직후 paper target/status version mismatch도 상태판에 보이게 한다.
# =============================================================================
def _v380_event_stage(ev: Dict[str, Any]) -> str:
    g = str(ev.get('s_stage') or ev.get('candidate_grade') or ev.get('grade') or '').upper()
    if g == 'S': g = 'S1'
    return g if g in {'S1','S2','S3'} else 'S3'

def _v380_event_reasons(ev: Dict[str, Any]) -> List[str]:
    out=[]
    for key in ('s_stage_reasons','stage_reasons','reasons','reason_tags','missing_info','block_reasons'):
        v=ev.get(key)
        if isinstance(v, list): out += [str(x) for x in v if x]
        elif isinstance(v, str) and v.strip(): out += [x.strip() for x in re.split(r'[,/|]+', v) if x.strip()]
    for key in ('summary_reason','reason','status_reason','recheck_reason','watch_note'):
        v=ev.get(key)
        if isinstance(v, str) and v.strip(): out += [x.strip() for x in re.split(r'[,/|]+', v) if x.strip()]
    clean=[]
    for r in out:
        r=str(r).strip()
        if not r or r in {'-', 'None', 'null'}: continue
        # 너무 세부 전략명 prefix는 기본 품질판에서 줄인다.
        r = r.replace('정보보강대기:', '정보보강대기:')
        clean.append(r[:60])
    return list(dict.fromkeys(clean))

def _v380_current_loop_reason_top(max_rows: int = 160) -> Dict[str, Any]:
    rows = read_jsonl(FILES['paper_latest'], max_lines=max_rows)
    stage_counts=Counter(); ctr=Counter(); info_ctr=Counter(); cond_ctr=Counter()
    samples=[]
    for ev in rows:
        if not isinstance(ev, dict): continue
        st=_v380_event_stage(ev); stage_counts[st]+=1
        reasons=_v380_event_reasons(ev)
        if st != 'S1':
            for r in reasons[:8]:
                ctr[r]+=1
                if any(x in r for x in ('미확인','정보부족','정보보강','micro','WS','슬리피지')):
                    info_ctr[r]+=1
                else:
                    cond_ctr[r]+=1
            if len(samples)<8:
                samples.append({'ticker': _short_ticker(ev.get('ticker') or ev.get('symbol')), 'stage': st, 'score': fnum(ev.get('score'),0), 'reasons': reasons[:4]})
    return {'rows': len(rows), 'stage_counts': dict(stage_counts), 'top': ctr.most_common(12), 'info_top': info_ctr.most_common(6), 'condition_top': cond_ctr.most_common(6), 'samples': samples}

def _v380_paper_target_hint() -> str:
    try:
        deployed = (BASE_DIR / 'DEPLOYED_PAPER.txt').read_text(encoding='utf-8', errors='ignore').strip() if (BASE_DIR / 'DEPLOYED_PAPER.txt').exists() else ''
    except Exception:
        deployed = ''
    st = load_json(FILES['paper_status'], {}) or {}
    sv = str(st.get('version') or '') if isinstance(st, dict) else ''
    tr = load_json(FILES['candidate_handoff_trace'], {}) or {}
    tv = str(tr.get('version') or '') if isinstance(tr, dict) else ''
    bits=[]
    if deployed: bits.append(f'배포파일 {deployed}')
    if sv: bits.append(f'status {sv}')
    if tv: bits.append(f'trace {tv}')
    if deployed and sv and deployed.replace('.py','') not in sv:
        bits.append('⚠️ paper 배포/status 버전 불일치')
    return ' / '.join(bits)

def quality_text() -> str:  # type: ignore[override]
    reject=load_json(FILES['strategy_reject'],{}) or {}; strat=load_json(FILES['strategy_summary'],{}) or {}
    hand=load_json(FILES['paper_handoff'],{}) or {}; pbh=load_json(FILES['paperbot_handoff'],{}) or {}
    latest_lines=line_count(FILES['paper_latest']); archive_lines=line_count(FILES['paper_archive'])
    router=load_json(FILES.get('target_router', BASE_DIR/'clean_target_router_queue.json'),{}) or {}
    evaluated=int(fnum(reject.get('evaluated') or strat.get('evaluated') or 0,0))
    quote=int(fnum(reject.get('quote_ready_count') or strat.get('quote_ready_count') or evaluated,0))
    micro=int(fnum(reject.get('micro_ready_count') or strat.get('micro_ready_count') or 0,0))
    both=int(fnum(reject.get('full_info_ready_count') or strat.get('full_info_ready_count') or min(quote,micro),0))
    sc=strat.get('s_stage_counts') if isinstance(strat.get('s_stage_counts'), dict) else (_v358_stage_counts_from_latest() if '_v358_stage_counts_from_latest' in globals() else Counter())
    loop=_v380_current_loop_reason_top()
    not_micro=max(0,evaluated-micro) if evaluated else 0
    lines=[
        '🔍 후보품질 /quality',
        f"✅ 전체 {evaluated}개 평가 / S1 {sc.get('S1',0)} / S2 {sc.get('S2',0)} / S3 {sc.get('S3',0)} / latest {latest_lines}줄 / 병합 {pbh.get('merged_fresh','-')}",
        '', '[S1/S2/S3 의미]',
        '- S3: 관찰포착 / S2: 재확인·정보보강 / S1: 최종 paper OPEN',
        '- S2/S3는 승패가 아니라 S1로 올라가기 전 생애주기 단계입니다.',
        '', '[정보가 얼마나 채워졌나]',
        f"- 시세: {quote}/{evaluated}개 / 호가·체결: {micro}/{evaluated}개 / 둘다: {both}/{evaluated}개",
        f"- 아직 micro 미신선: {not_micro}개 / 지금 꼭 필요한 micro: {router.get('need_micro') or reject.get('info_pending_count') or 0}개",
    ]
    hint=_v380_paper_target_hint()
    if hint:
        lines += ['', '[paper 적용/trace 확인]', f'- {hint}']
    lines += [
        '', '[이번 루프 후보 미승격 사유 TOP · latest 기준]',
        f"- 이번 latest {loop.get('rows',0)}개 / S1 {loop.get('stage_counts',{}).get('S1',0)} / S2 {loop.get('stage_counts',{}).get('S2',0)} / S3 {loop.get('stage_counts',{}).get('S3',0)}",
    ]
    if loop.get('info_top'):
        lines.append('- 정보부족/판단값 미생성: ' + ' / '.join(f'{k} {v}' for k,v in loop.get('info_top',[])[:5]))
    if loop.get('condition_top'):
        lines.append('- 조건부족/흐름부족: ' + ' / '.join(f'{k} {v}' for k,v in loop.get('condition_top',[])[:5]))
    if not loop.get('top'):
        lines.append('- 이번 루프 미승격 사유 집계 없음')
    if loop.get('samples'):
        lines.append('- 샘플:')
        for s in loop.get('samples',[])[:5]:
            lines.append(f"  · {s.get('stage')} {s.get('ticker')} / 점수 {s.get('score'):.2f} / {','.join(s.get('reasons') or []) or '-'}")
    lines += [
        '', '[전체시장 탈락 사유 TOP · 참고]',
        '- 아래 숫자는 이번 latest 후보만이 아니라 전체 평가 455개 기준입니다. 전략 판단은 위 latest 기준을 우선 봅니다.'
    ]
    top=reject.get('reason_top') if isinstance(reject.get('reason_top'),list) else []
    if top:
        for r in top[:8]:
            lines.append(f"- ❔ {r.get('reason')}: {r.get('count')}")
    else:
        lines.append('- 아직 집계 없음')
    lines += [
        '', '[배차/보강]',
        f"- 전체배차 {router.get('queue_count','-')}개 → 이번내보냄 {router.get('export_count', router.get('active_target_count','-'))}",
        f"- 순환대기 {router.get('rotation_wait_count','-')}개 / 버림 {router.get('dropped_count',0)}개 / safety초과 {router.get('safety_overflow',0)}개",
    ]
    return '\n'.join(lines)

try:
    COMMANDS.update({'quality': quality_text})
except Exception:
    pass




# =============================================================================
# main v2.13.369 / v381: 상태판 소음 정리 + 구 cache 착시 차단
# - 전략조건/OPEN/청산 변경 없음.
# - /health, /quality, /pstatus, /missed_trace를 "전략 판단용"으로 정리한다.
# - paper status version과 trace version이 다르면 구 trace rows를 전략 판단에 섞지 않는다.
# - S2/S3는 승패가 아니라 생애주기 단계로만 표시한다.
# =============================================================================
def _v381_file_age(path_key: str, default_name: str = '') -> float:
    try:
        path = FILES.get(path_key, BASE_DIR/default_name) if default_name else FILES.get(path_key)
        return age(path) if path else 999999.0
    except Exception:
        return 999999.0

def _v381_paper_versions() -> Dict[str, Any]:
    st = load_json(FILES.get('paper_status', BASE_DIR/'paper_bot_status.json'), {}) or {}
    tr = load_json(FILES.get('candidate_handoff_trace', BASE_DIR/'paper_bot_candidate_handoff_trace.json'), {}) or {}
    pv = str(st.get('version') or '-') if isinstance(st, dict) else '-'
    tv = str(tr.get('version') or '-') if isinstance(tr, dict) else '-'
    pa = _v381_file_age('paper_status','paper_bot_status.json')
    ta = _v381_file_age('candidate_handoff_trace','paper_bot_candidate_handoff_trace.json')
    ok = (pv != '-' and tv != '-' and pv == tv and pa < 90 and ta < 90)
    return {'paper_version': pv, 'trace_version': tv, 'paper_age': pa, 'trace_age': ta, 'ok': ok, 'status': st, 'trace': tr}

def _v381_state_icon(ok: bool, warn: bool = False) -> str:
    return '✅' if ok else ('⚠️' if warn else '❌')

def _v381_loop_summary() -> Dict[str, Any]:
    try:
        return _v380_current_loop_reason_top()
    except Exception:
        return {'rows': 0, 'stage_counts': {}, 'info_top': [], 'condition_top': [], 'samples': []}

def health_text() -> str:  # type: ignore[override]
    update_brain_status('running')
    workers=[worker_status(k) for k in WORKERS]
    res=resource_snapshot()
    paper=load_json(FILES['paper_status'],{}) or {}
    ws=load_json(FILES['ws_status'],{}) or {}
    micro=load_json(FILES['micro_status'],{}) or {}
    strat=load_json(FILES['strategy_summary'],{}) or {}
    reject=load_json(FILES['strategy_reject'],{}) or {}
    oflow=load_json(FILES['orderflow'],{}) or {}
    router=load_json(FILES['target_router'],{}) or {}
    vers=_v381_paper_versions()
    good=sum(1 for w in workers if worker_ok(w)=='✅')
    warn=sum(1 for w in workers if worker_ok(w)=='⚠️')
    bad=sum(1 for w in workers if worker_ok(w)=='❌')
    evaluated=int(fnum(reject.get('evaluated') or strat.get('evaluated') or 0,0))
    quote_ready=int(fnum(strat.get('quote_ready_count') or reject.get('quote_ready_count') or oflow.get('quote_fresh') or 0,0))
    micro_ready=int(fnum(strat.get('micro_ready_count') or reject.get('micro_ready_count') or oflow.get('fresh_micro') or 0,0))
    full_ready=int(fnum(strat.get('full_info_ready_count') or reject.get('full_info_ready_count') or oflow.get('info_ready') or 0,0))
    sc=strat.get('s_stage_counts') if isinstance(strat.get('s_stage_counts'), dict) else {}
    if not sc:
        try: sc=_v358_stage_counts_from_latest()
        except Exception: sc={}
    paper_ok = bool(paper.get('running', True)) and vers.get('paper_age',9999) < 90 and vers.get('trace_age',9999) < 90 and vers.get('paper_version') == vers.get('trace_version')
    res_warn = float(fnum(res.get('mem_used_pct'),0)) >= 80 or float(fnum(res.get('disk_used_pct'),0)) >= 85
    lines=[
        '🧭 건강상태 /health',
        f"{_v381_state_icon(bad==0 and paper_ok and not res_warn, warn or res_warn or not paper_ok)} 전체판독: worker {good}/9 정상 · paper/trace {'정상' if paper_ok else '확인필요'} · 자원 {'주의' if res_warn else '정상'}",
        f"- 메인봇 {BOT_VERSION} / {CLEAN_WORKER_HUB_LABEL} / uptime {int(now_ts()-START_TS)}s",
        f"- 정보: 평가 {evaluated or '-'} / 시세 {quote_ready}/{evaluated or '-'} / micro {micro_ready}/{evaluated or '-'} / 둘다 {full_ready}/{evaluated or '-'}",
        f"- 후보 생애주기: S1 {sc.get('S1',0)} / S2 {sc.get('S2',0)} / S3 {sc.get('S3',0)} / latest {strat.get('paper_latest_count', line_count(FILES.get('paper_latest', BASE_DIR/'paper_candidates_latest.jsonl')))}",
        f"- paper: {vers.get('paper_version')} / trace {vers.get('trace_version')} / status age {vers.get('paper_age',0):.1f}s / trace age {vers.get('trace_age',0):.1f}s / OPEN {paper.get('open_count', paper.get('open_total','-'))}",
        f"- 배차: 전체 {router.get('queue_count','-')} → 내보냄 {router.get('export_count', router.get('active_target_count','-'))} / 대기 {router.get('rotation_wait_count','-')} / 버림 {router.get('dropped_count',0)}",
        f"- 자원: 디스크 {res.get('disk_used_pct','-')}% / 남음 {res.get('disk_free_gb','-')}GB / 메모리 {res.get('mem_used_pct','-')}% / load {res.get('load','-')}",
    ]
    if not paper_ok:
        lines.append('- ⚠️ paper status와 trace가 최신/동일 버전인지 먼저 확인해야 합니다. 구 trace는 전략 판단에서 제외합니다.')
    lines += ['', '[worker 요약]']
    lines += [line_worker(w, detail=False) for w in workers]
    return '\n'.join(lines)

def _v381_lifecycle_lines() -> List[str]:
    cache = _v379_score_cache_current() if '_v379_score_cache_current' in globals() else {}
    strat = load_json(FILES['strategy_summary'], {}) or {}
    life = _v379_lifecycle_from_cache(cache) if cache else (strat.get('lifecycle_stats') if isinstance(strat.get('lifecycle_stats'), dict) else {})
    if life:
        return _v379_stage_lines(life)
    return ['[후보 생애주기 · 승패 아님]', '- 생애주기 cache 준비중']

def pstatus_text() -> str:  # type: ignore[override]
    status = load_json(FILES['paper_status'], {}) or {}
    open_pos = _paper_open_positions()
    hand = load_json(FILES['paperbot_handoff'], {}) or {}
    vers=_v381_paper_versions()
    pick = status.get('pick_stats') if isinstance(status.get('pick_stats'), dict) else {}
    grade_counts = Counter(_paper_grade(p) for p in open_pos.values() if isinstance(p, dict))
    read_n = pick.get('paper_file', pick.get('read', pick.get('read_count', '-')))
    s1_sel = pick.get('v369_s1_selected', pick.get('v368_s1_open', pick.get('grade_s1_open', pick.get('grade_s1_seen','-'))))
    opened = status.get('opened_this_cycle', '-')
    lines=[
        '🧪 paper 상태 /pstatus · 메인봇 캐시전용',
        f"- 상태: {'ON' if status.get('running', True) else '확인필요'} / paper {vers.get('paper_version')} / trace {vers.get('trace_version')} / status age {vers.get('paper_age',0):.1f}s / OPEN {len(open_pos)}",
        f"- OPEN: S1 {grade_counts.get('S1',0)} / 제외 {grade_counts.get('X',0)}",
        f"- handoff: latest {hand.get('latest_count', hand.get('latest_lines', hand.get('paper_latest_count','-')))} / 병합fresh {hand.get('merged_fresh','-')} / archive창 {hand.get('archive_window','-')}",
        f"- 선별배관: 읽음 {read_n} / S1선택 {s1_sel} / 실제OPEN {opened}",
        '- S2/S3는 실제 진입 전 단계라 승패로 표시하지 않습니다.',
    ]
    if vers.get('paper_version') != vers.get('trace_version') or vers.get('paper_age',9999) >= 90:
        lines.append('- ⚠️ paper 상태 최신성 확인 필요: 이 상태에서는 OPEN/trace 판단을 보류합니다.')
    lines += _v381_lifecycle_lines()
    cache = _v379_score_cache_current() if '_v379_score_cache_current' in globals() else {}
    if cache:
        gs = cache.get('grade_stats') if isinstance(cache.get('grade_stats'), dict) else {}
        lines += ['', '[실제 모의매매 성과]']
        lines.append(_v377_score_line('📦 구 S 통합전적(참고)', gs.get('LEGACY_S', gs.get('S', {}))))
        lines.append(_v377_score_line('✅ 검증된 S1 OPEN', gs.get('S1', {})))
    return '\n'.join(lines)

def missed_trace_text() -> str:  # type: ignore[override]
    vers=_v381_paper_versions()
    obj = vers.get('trace') if isinstance(vers.get('trace'), dict) else {}
    rows = obj.get('rows') if isinstance(obj, dict) else []
    rows = [r for r in rows if isinstance(r, dict)] if isinstance(rows, list) else []
    lines=[
        '🧭 놓친 후보 추적 /missed_trace',
        '- strategy 후보 → handoff → paper 병합/OPEN/CLOSED 흐름을 추적합니다.',
        f"- paper {vers.get('paper_version')} / trace {vers.get('trace_version')} / trace age {vers.get('trace_age',0):.1f}s / rows {len(rows)}",
    ]
    if vers.get('paper_version') != vers.get('trace_version'):
        lines += ['', '⚠️ trace 버전 불일치', '- 구 trace rows는 전략 판단에 섞지 않습니다. paper loop 1~2회 뒤 다시 확인하세요.']
        return '\n'.join(lines)
    by_status=Counter(str(r.get('status') or 'unknown') for r in rows)
    reasons=Counter()
    for r in rows:
        for x in str(r.get('reason') or '').split(','):
            x=x.strip()
            if x: reasons[x]+=1
    lines += ['', '[상태 TOP]']
    if by_status:
        for k,v in by_status.most_common(6):
            icon='✅' if k in {'open','closed','picked'} else '⚠️' if k in {'expired','not_merged','merged_waiting_pick','micro_wait','skipped'} else '❔'
            lines.append(f'- {icon} {k}: {v}개')
    else:
        lines.append('- trace 없음')
    lines += ['', '[이유 TOP]']
    if reasons:
        for k,v in reasons.most_common(6):
            icon='⚠️' if k in {'paper미병합','handoff만료','후보오래됨','micro미확인','picked_not_opened'} else '❔'
            lines.append(f'- {icon} {k}: {v}개')
    else:
        lines.append('- 이유 없음')
    risky=[r for r in rows if str(r.get('status') or '') not in {'open','closed'}]
    risky.sort(key=lambda r:(float(first_value(r.get('score'),0) or 0), float(first_value(r.get('created_at'),0) or 0)), reverse=True)
    lines += ['', '[주의 후보 TOP]']
    for r in risky[:8]:
        lines.append(f"- ⚠️ {norm_ticker(r.get('ticker'))} / {r.get('strategy') or r.get('strategy_key','-')} / score {r.get('score','-')} / status {r.get('status','-')} / 이유 {r.get('reason','-')}")
    if not risky:
        lines.append('- 현재 주의 후보 없음')
    return '\n'.join(lines)

def quality_text() -> str:  # type: ignore[override]
    reject=load_json(FILES['strategy_reject'],{}) or {}; strat=load_json(FILES['strategy_summary'],{}) or {}
    pbh=load_json(FILES['paperbot_handoff'],{}) or {}; router=load_json(FILES.get('target_router', BASE_DIR/'clean_target_router_queue.json'),{}) or {}
    evaluated=int(fnum(reject.get('evaluated') or strat.get('evaluated') or 0,0))
    quote=int(fnum(reject.get('quote_ready_count') or strat.get('quote_ready_count') or evaluated,0))
    micro=int(fnum(reject.get('micro_ready_count') or strat.get('micro_ready_count') or 0,0))
    both=int(fnum(reject.get('full_info_ready_count') or strat.get('full_info_ready_count') or min(quote,micro),0))
    sc=strat.get('s_stage_counts') if isinstance(strat.get('s_stage_counts'), dict) else (_v358_stage_counts_from_latest() if '_v358_stage_counts_from_latest' in globals() else Counter())
    loop=_v381_loop_summary(); vers=_v381_paper_versions()
    lines=[
        '🔍 후보품질 /quality',
        f"✅ 이번판: S1 {sc.get('S1',0)} / S2 {sc.get('S2',0)} / S3 {sc.get('S3',0)} / latest {line_count(FILES['paper_latest'])}줄 / 병합 {pbh.get('merged_fresh','-')}",
        '- 해석: S3=관찰포착 → S2=재확인/정보보강 → S1=최종 paper OPEN',
        f"- 정보: 시세 {quote}/{evaluated or '-'} / micro {micro}/{evaluated or '-'} / 둘다 {both}/{evaluated or '-'} / 필요 micro {router.get('need_micro') or reject.get('info_pending_count') or 0}",
        f"- paper/trace: {vers.get('paper_version')} / {vers.get('trace_version')} / age {vers.get('paper_age',0):.0f}s·{vers.get('trace_age',0):.0f}s",
        '', '[이번 latest 미승격 핵심]',
        f"- latest {loop.get('rows',0)}개 / S1 {loop.get('stage_counts',{}).get('S1',0)} / S2 {loop.get('stage_counts',{}).get('S2',0)} / S3 {loop.get('stage_counts',{}).get('S3',0)}",
    ]
    if loop.get('info_top'):
        lines.append('- 정보부족/판단값 미생성: ' + ' / '.join(f'{k} {v}' for k,v in loop.get('info_top',[])[:4]))
    if loop.get('condition_top'):
        lines.append('- 조건부족/흐름부족: ' + ' / '.join(f'{k} {v}' for k,v in loop.get('condition_top',[])[:4]))
    if loop.get('samples'):
        lines.append('- 샘플:')
        for s in loop.get('samples',[])[:4]:
            lines.append(f"  · {s.get('stage')} {s.get('ticker')} / 점수 {s.get('score'):.2f} / {','.join(s.get('reasons') or []) or '-'}")
    lines += ['', '[전체시장 탈락 TOP · 참고]', '- 전체 455개 평가 기준입니다. 전략 판단은 위 latest 기준을 우선 봅니다.']
    top=reject.get('reason_top') if isinstance(reject.get('reason_top'),list) else []
    for r in top[:5]:
        lines.append(f"- ❔ {r.get('reason')}: {r.get('count')}")
    if not top:
        lines.append('- 아직 집계 없음')
    return '\n'.join(lines)

try:
    COMMANDS.update({'health': health_text, 'quality': quality_text, 'pstatus': pstatus_text, 'missed_trace': missed_trace_text, 'trace_missed': missed_trace_text})
except Exception:
    pass




# =============================================================================
# main v2.13.369 / v382: 정보부족 vs 전략조건 미달 문구 단일화
# - 전략조건/OPEN/청산 변경 없음.
# - 전체시장 TOP(455개)은 "정보부족"이 아니라 "전략조건 미달"로 명확히 표시한다.
# - 이번 latest 후보 기준의 실제 정보부족/판단값 미생성만 따로 보여준다.
# =============================================================================
def _v382_loop_reason_summary() -> Dict[str, Any]:
    try:
        loop = _v380_current_loop_reason_top()
    except Exception:
        loop = {'rows': 0, 'stage_counts': {}, 'info_top': [], 'condition_top': [], 'samples': []}
    info_top = loop.get('info_top') or []
    cond_top = loop.get('condition_top') or []
    info_total = 0
    cond_total = 0
    try:
        info_total = sum(int(v) for _, v in info_top)
        cond_total = sum(int(v) for _, v in cond_top)
    except Exception:
        pass
    loop['info_total'] = info_total
    loop['condition_total'] = cond_total
    return loop

def _v382_reason_label(reason: Any) -> str:
    r = str(reason or '').strip()
    if not r:
        return '-'
    # 사용자 혼동 방지: 전체시장 사유는 정보부족이 아니라 조건 미달 중심으로 읽게 정리한다.
    r = r.replace('돈흐름 재가속 S:', '돈흐름 재가속 조건미달:')
    r = r.replace('주도흐름 유동보유 S:', '유동보유 조건미달:')
    r = r.replace('주도추세 지속 S:', '주도추세 조건미달:')
    r = r.replace('돌파 초입 S:', '돌파초입 조건미달:')
    return r

def _v382_quality_text() -> str:
    reject=load_json(FILES['strategy_reject'],{}) or {}; strat=load_json(FILES['strategy_summary'],{}) or {}
    pbh=load_json(FILES['paperbot_handoff'],{}) or {}; router=load_json(FILES.get('target_router', BASE_DIR/'clean_target_router_queue.json'),{}) or {}
    evaluated=int(fnum(reject.get('evaluated') or strat.get('evaluated') or 0,0))
    quote=int(fnum(reject.get('quote_ready_count') or strat.get('quote_ready_count') or evaluated,0))
    micro=int(fnum(reject.get('micro_ready_count') or strat.get('micro_ready_count') or 0,0))
    both=int(fnum(reject.get('full_info_ready_count') or strat.get('full_info_ready_count') or min(quote,micro),0))
    sc=strat.get('s_stage_counts') if isinstance(strat.get('s_stage_counts'), dict) else (_v358_stage_counts_from_latest() if '_v358_stage_counts_from_latest' in globals() else Counter())
    loop=_v382_loop_reason_summary(); vers=_v381_paper_versions()
    latest_n = line_count(FILES['paper_latest'])
    need_micro = router.get('need_micro') or reject.get('info_pending_count') or 0
    not_micro=max(0,evaluated-micro) if evaluated else 0
    lines=[
        '🔍 후보품질 /quality',
        f"✅ 이번판: S1 {sc.get('S1',0)} / S2 {sc.get('S2',0)} / S3 {sc.get('S3',0)} / latest {latest_n}줄 / 병합 {pbh.get('merged_fresh','-')}",
        '- 해석: S3=관찰포착 → S2=재확인/정보보강 → S1=최종 paper OPEN',
        f"- 정보수집: 시세 {quote}/{evaluated or '-'} / micro {micro}/{evaluated or '-'} / 둘다 {both}/{evaluated or '-'} / 미신선 {not_micro} / 지금 필요한 micro {need_micro}",
        f"- paper/trace: {vers.get('paper_version')} / {vers.get('trace_version')} / age {vers.get('paper_age',0):.0f}s·{vers.get('trace_age',0):.0f}s",
        '', '[이번 latest 미승격 핵심 · 실제 후보 기준]',
        f"- latest {loop.get('rows',0)}개 / S1 {loop.get('stage_counts',{}).get('S1',0)} / S2 {loop.get('stage_counts',{}).get('S2',0)} / S3 {loop.get('stage_counts',{}).get('S3',0)}",
    ]
    if loop.get('info_top'):
        lines.append('- ✅ 진짜 정보부족/판단값 미생성: ' + ' / '.join(f'{k} {v}' for k,v in loop.get('info_top',[])[:4]))
    else:
        lines.append('- ✅ 진짜 정보부족/판단값 미생성: 없음')
    if loop.get('condition_top'):
        lines.append('- ❔ 전략조건 미달/흐름부족: ' + ' / '.join(f'{k} {v}' for k,v in loop.get('condition_top',[])[:4]))
    else:
        lines.append('- ❔ 전략조건 미달/흐름부족: 없음')
    lines.append('- 판독: 아래 400개대 숫자는 정보가 없다는 뜻이 아니라 전체시장 후보가 전략조건에 못 미친 숫자입니다.')
    if loop.get('samples'):
        lines.append('- 샘플:')
        for s in loop.get('samples',[])[:4]:
            lines.append(f"  · {s.get('stage')} {s.get('ticker')} / 점수 {s.get('score'):.2f} / {','.join(s.get('reasons') or []) or '-'}")
    lines += ['', '[전체시장 전략조건 미달 TOP · 참고용]', '- 전체 455개 평가 기준입니다. 정보부족이 아니라 조건 미달/흐름 미달입니다. 전략 판단은 위 latest 기준을 우선 봅니다.']
    top=reject.get('reason_top') if isinstance(reject.get('reason_top'),list) else []
    for r in top[:6]:
        lines.append(f"- ❔ {_v382_reason_label(r.get('reason'))}: {r.get('count')}")
    if not top:
        lines.append('- 아직 집계 없음')
    lines += ['', '[다음 판단 기준]', '- S2/S3 후보가 이후 오르면 조건 미달인지, 정보부족인지, 승격 루프 문제인지 구분해서 봅니다.']
    return '\n'.join(lines)

try:
    quality_text = _v382_quality_text  # type: ignore[assignment]
    COMMANDS.update({'quality': quality_text})
except Exception:
    pass

if __name__=='__main__': main()
