v1413 targeted bundle: paper_bot + strategy_worker only. Fix oversized v1153 path-state cache single owner. No trading-rule change. Auto-buy OFF.
