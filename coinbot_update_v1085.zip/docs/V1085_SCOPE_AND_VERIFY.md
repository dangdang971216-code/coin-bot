# v1085 scope and verification

## Root cause fixed

`select_candidates()` called `closed_recent_ids(2000)`. The old reader built a list of the last 2,000 raw CLOSED strings and then another list of 2,000 full dictionaries even though only five possible ID fields were consumed. With the live CLOSED ledger near 257 MB, v1084 measured candidate selection at +841 MB RSS and a 1.78 GB peak.

## Runtime change

- Keep a bounded deque of the last 2,000 CLOSED-line ID tuples and an ID Counter.
- Initial startup reads the reverse tail one raw line at a time.
- Later cycles read only bytes appended after the stored offset.
- Inode replacement, truncation, or limit change rebuilds the bounded tail.
- Invalid and empty lines preserve the old last-N-line semantics.
- The status-only paper_latest reader parses one row at a time and retains only fields consumed by latest-scan, freshness, stage, event ID, and minimal trace logic.
- v1084 measurement hooks are removed from production runtime.

## Unchanged

Strategy mode, S1 contract, trigger, invalid, target, RR, spread, slippage, entry, exit, OPEN/CLOSED commit order, exact ledgers, and auto-buy are unchanged. Auto-buy remains OFF.

## Server proof

Run `/gpaper_memory_fix_v1085 180` after deployment. DONE requires runtime/hash identity, three live cycles, bounded CLOSED index, compact status reader, Paper RSS bounds, candidate-select median below 4 seconds, candidate contract completeness, exact 0/0/0, and auto-buy OFF.
