#!/usr/bin/env python3
from __future__ import annotations
import importlib.util, pathlib, sys, tempfile
ROOT=pathlib.Path(__file__).resolve().parent; PACKAGE_ROOT=ROOT.parent
if str(PACKAGE_ROOT) not in sys.path: sys.path.insert(0,str(PACKAGE_ROOT))

def load(name,path):
    spec=importlib.util.spec_from_file_location(name,path); mod=importlib.util.module_from_spec(spec); sys.modules[name]=mod; assert spec and spec.loader; spec.loader.exec_module(mod); return mod

def main():
    guard=load('guard_v1230', PACKAGE_ROOT/'backga_guard_bot_v2_5_223.py')
    with tempfile.TemporaryDirectory() as td:
        guard.BOT_DIR=pathlib.Path(td)
        (guard.BOT_DIR/'clean_strategy_worker_error.log').write_text('2026-07-05 loop_v512 ValueError: v1021 candidate row exceeds hard ceiling: 24700B\n',encoding='utf-8')
        guard.run=lambda *a,**k:(0,'systemd restart only')
        text=guard.gworker_log_text('strategy',120)
        assert '[실제 worker 오류파일]' in text
        assert 'candidate row exceeds hard ceiling' in text
        assert '[systemd 기록]' in text
    assert '2.5.223' in guard.VERSION
    print('PASS v1230 guard worker log reads actual strategy error file before systemd restart records')
if __name__=='__main__': main()
