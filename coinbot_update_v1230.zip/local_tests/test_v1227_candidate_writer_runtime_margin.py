#!/usr/bin/env python3
from __future__ import annotations
import copy
import importlib.util
import json
import pathlib
import sys

ROOT = pathlib.Path(__file__).resolve().parent
PACKAGE_ROOT = ROOT.parent
if str(PACKAGE_ROOT) not in sys.path:
    sys.path.insert(0, str(PACKAGE_ROOT))


def load(name: str, path: pathlib.Path):
    spec = importlib.util.spec_from_file_location(name, path)
    mod = importlib.util.module_from_spec(spec)
    sys.modules[name] = mod
    assert spec and spec.loader
    spec.loader.exec_module(mod)
    return mod


def install_material(mod) -> None:
    def frame_rows(_row, tf):
        return [{'tf': tf}] * 10
    def atr(rows):
        tf = rows[0]['tf'] if rows else ''
        return {'m5': 0.7, 'm15': 1.0, 'm30': 1.0, 'h1': 1.2, 'h2': 2.0, 'h4': 5.0}.get(tf, 1.0)
    def zone(tf, low, high, score=80.0, side='resistance'):
        return {'tf': tf, 'side': side, 'price': (low + high) / 2.0,
                'zone_low': low, 'zone_high': high, 'score': score,
                'touch_count': 3, 'source': f'candle.{tf}', 'atr_pct': 1.0, 'gap_pct': 0.0}
    def candidates(_rows, tf, side, _price):
        if side == 'support':
            return [zone(tf, 97.0, 97.2, side='support')] if tf == 'h1' else []
        table = {
            'm15': [zone('m15', 100.4, 100.5)],
            'm30': [zone('m30', 100.9, 101.0)],
            'h1': [zone('h1', 103.0, 103.2)],
            'h2': [zone('h2', 106.0, 106.2)],
            'h4': [zone('h4', 109.0, 109.2)],
        }
        return table.get(tf, [])
    mod._v1212_frame_rows = frame_rows
    mod._v1212_atr_pct = atr
    mod._v1212_zone_candidates = candidates
    mod._v1212_cost_inputs = lambda _row: {
        'spread_pct': 0.1, 'slippage_pct': 0.1, 'slippage_source': 'test',
        'fee_pct': 0.2, 'estimated_roundtrip_cost_pct': 0.5, 'complete': True,
    }
    mod._v1212_strength_factor = lambda _row: 1.0


def main() -> None:
    old = load('strategy_v1226_margin_failure', PACKAGE_ROOT / 'baselines' / 'strategy_worker_v1.053_v1226_writer_margin_failure.py')
    new = load('strategy_v1227_margin_repair', PACKAGE_ROOT / 'strategy_worker_v1.057.py')
    install_material(old)
    install_material(new)

    old_plan = old._v925_current_actual_plan({'ticker': 'TEST', 'current_price': 100.0})
    new_plan = new._v925_current_actual_plan({'ticker': 'TEST', 'current_price': 100.0})
    assert old_plan['trigger'] == new_plan['trigger']
    assert old_plan['entry_flow_baseline_v1221'] == new_plan['entry_flow_baseline_v1221']

    source = {
        'ticker': 'TEST', 'market': 'KRW-TEST', 'candidate_pipeline_cycle_id_v1150': 'cycle-x',
        's_stage': 'S2', 'current_price': 100.0,
        'structure_integrity_v1048': 'OK', 'structure_integrity_block_v1048': False,
        'structure_integrity_refresh_required_v1048': False,
        'structure_integrity_v1049': 'OK', 'structure_integrity_block_v1049': False,
        'structure_integrity_refresh_required_v1049': False,
        'structure_contract_version': new_plan['structure_contract_version'],
        'structure_contract_hash': new_plan['structure_contract_hash'],
        'structure_quality_score_v1212': 81.4,
        'target_reachability_score_v1212': 83.2,
        'global_entry_score_v1212': 77.7,
        'dynamic_chase_limit_pct_v1212': 0.8,
        'ranking_contract_version': 'ranking_contract_v1212_global_dynamic_score',
        'selection_contract_version': 'selection_contract_v1212_global_top_score',
        'current_cycle_observation_only_v1215': False,
        'current_cycle_observation_role_owner_v1215': 'strategy',
        'legacy_s3_observation_label_v1215': False,
        'legacy_s3_observation_retired_v1215': True,
        'entry_flow_state_v1221': 'WATCHING_FROZEN_TRIGGER',
        'entry_flow_baseline_v1221': 'v1211_trigger_watch_then_s1_then_paper',
        'entry_flow_violation_v1221': False,
        'v1211_structure_shadow_ready_v1222': True,
        'dynamic_structure_material_evidence_v1215': {
            'schema': 'dynamic_structure_material_evidence_v1215',
            'link_mode': 'canonical_candle_map', 'source_state': 'READY',
            'analysis_ready': True, 'frame_counts': new_plan['frame_counts_v1215'],
        },
    }
    old_source = copy.deepcopy(source)
    old_padded_plan = copy.deepcopy(old_plan)
    # Server evidence was 24,755B. Reproduce that real boundary class exactly.
    old_padded_plan['runtime_padding_v1227'] = 'P' * 15504
    old_source['dynamic_structure_plan_v1212'] = old_padded_plan
    old_source['structure_contract_v1212'] = old_padded_plan
    old_source['structure_contract_version'] = old_plan['structure_contract_version']
    old_source['structure_contract_hash'] = old_plan['structure_contract_hash']

    try:
        old._v861_compact_row_for_latest(old_source)
        raise AssertionError('v1.053 runtime-size failure was not reproduced')
    except ValueError as exc:
        assert 'candidate row exceeds hard ceiling' in str(exc), str(exc)

    new_padded_plan = copy.deepcopy(new_plan)
    new_padded_plan['runtime_padding_v1227'] = 'P' * 15000
    source['dynamic_structure_plan_v1212'] = new_padded_plan
    source['structure_contract_v1212'] = new_padded_plan
    compact = new._v861_compact_row_for_latest(source)
    encoded = json.dumps(compact, ensure_ascii=False, separators=(',', ':'), default=str).encode('utf-8')
    assert len(encoded) <= new.V1020_ROW_HARD_CEILING_BYTES - 900, len(encoded)
    plan = compact['dynamic_structure_plan_v1212']
    assert plan['trigger'] == new_plan['trigger']
    assert plan['invalid'] == new_plan['invalid']
    assert plan['target'] == new_plan['target']
    for key in ('role','rounded_price','tf','source','zone_score','contract_role_v1225'):
        assert plan['intermediate_resistance_v1225'].get(key) == new_plan['intermediate_resistance_v1225'].get(key)
    assert plan['cost_inputs'] == new_plan['cost_inputs']
    assert 'selection_diagnostics_v1216' not in plan
    assert compact['candidate_structure_diagnostic_v1218']['schema'] == 'dynamic_structure_selection_diagnostics_v1216'
    assert 'frame_counts_v1215' not in plan
    assert compact['dynamic_structure_material_evidence_v1215']['frame_counts'] == new_plan['frame_counts_v1215']
    assert compact['selection_contract_version'] == 'selection_contract_v1212_global_top_score'
    gate_view = new._v1020_gate_view({
        'stage': 'S2', 'risk_reward': 1.7, 'target_room_pct': 2.5,
        'minimum_risk_reward': 1.5, 'minimum_target_room_pct': 1.2,
    })
    assert gate_view['minimum_risk_reward'] == 1.5
    assert gate_view['minimum_target_room_pct'] == 1.2
    assert new.VERSION == 'strategy_worker_v1.057'
    assert new.BUILD_LABEL == 'v1230_pairing_transport_budget_and_error_log_2026-07-05'
    print(f'PASS v1227 runtime margin: old 24755B failure reproduced, new {len(encoded)}B, writer margin preserved after coherent pairing')


if __name__ == '__main__':
    main()
