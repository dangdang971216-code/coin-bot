코인봇 v1202 Paper 후보선택 반복 JSON 읽기 수리 적용 ZIP

- 변경: Paper v1.053 -> v1.054
- 원인: S1 후보마다 paper_trigger_terminal_feedback_v1159.json 전체를 다시 읽음
- 수정: 한 selector cycle에서 최초 S1 때 1회만 읽고 같은 immutable snapshot 재사용
- 결과: 24개 S1 기준 전체파일 읽기 24회 -> 1회
- 변경 안 함: 후보식, 후보 수, OPEN/cycle 제한, trigger/invalid/target/RR, 청산계약
- 자동매수: OFF
- 상태: 로컬 PASS / 서버 적용 전 CHECK
