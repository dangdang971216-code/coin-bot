v1613: refresh-chain request_id trace. No trading rule change. Auto-buy OFF.
