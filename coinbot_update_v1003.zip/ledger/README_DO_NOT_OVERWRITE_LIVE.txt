배포 이력 seed만 포함한다. 서버의 live OPEN/CLOSED/trade_log/decision/change_verify/issue 원장을 덮어쓰지 않는다.
