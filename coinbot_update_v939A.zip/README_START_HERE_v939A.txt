v939-A는 main 명령 본선 역할명 정리판입니다. paper/strategy/review 매매판단은 변경하지 않았습니다. 적용은 /gupgrade_bundle, 검수는 main /batch입니다.
