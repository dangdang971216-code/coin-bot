v2077: existing shadow readout + loss defense active path audit. No strategy/ledger/auto-buy changes.
