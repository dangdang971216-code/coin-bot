v2230은 새 기능이나 새 Shadow를 만들지 않는다.

Main은 현재 Review producer와 같은 instance로 봉인된 existing exact decomposition을 읽는다. 최근 7일 READY 결과는 분석에 표시하지만 전체 누적 완료 전 본선 식·가중치 변경은 금지한다.

Paper는 runtime identity를 먼저 봉인하고 기존 canonical OPEN 범위값을 같은 status에 합친 뒤 기존 main으로 들어간다. -2% 기준, target 우선, invalid, 재진입, CLOSED/decision/OPEN 순서는 바꾸지 않는다.

Guard는 v2.6.55 기존 빠른 경로를 유지한다. ZIP manifest에 들어 있는 파일만 compile/hash 비교하고 바뀐 alias와 서비스만 적용한다. 이번 번들에서는 Main·Paper만 바뀌므로 Review·Strategy·Guard는 재시작하지 않는다.
