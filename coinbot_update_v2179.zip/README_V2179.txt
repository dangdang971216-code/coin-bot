v2179 deployment recovery. Fixes /gupgrade_bundle hanging at 2/5 by removing extractall and all-file pre-copy from guard-first phase. No strategy, candidate-quality, entry, exit or ledger changes.
