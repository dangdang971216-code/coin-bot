#!/usr/bin/env bash
set -euo pipefail
BOT_DIR="${BOT_DIR:-/home/dangdang971216/trading_bot}"
SRC="${1:-backga_guard_bot_v2_6_39.py}"
cd "$BOT_DIR"
test -f "$SRC"
python3 -m py_compile "$SRC"
cp -f "$SRC" backga_guard_bot.py
printf '%s\n' "$SRC" > .deployed_guard_target
sudo systemctl restart tradingbot-guard
sudo systemctl is-active tradingbot-guard
