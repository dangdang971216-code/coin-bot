v1340 old material compare read-only. Apply bundle then run /old_material_compare. No trading rule changes.
