v1361: fixes Strategy cycle_id/candidate_commit_id status owner for current Guard. No trading-rule change. Auto-buy OFF.
