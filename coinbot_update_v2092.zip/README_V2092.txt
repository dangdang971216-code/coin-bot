코인봇 v2092 · 메인봇 단일명령 compact 화면 + 상세 TXT 자동분리

목적
- 메인봇 명령어를 1개만 실행해도 Telegram에는 필요한 핵심만 표시하고, 같은 canonical 결과의 상세 TXT 1개를 자동 첨부한다.
- Telegram과 TXT를 따로 재계산하지 않는다. 명령은 1회만 실행한다.

수정
- 모든 공개 메인봇 단일명령: compact Telegram + command-specific detailed TXT.
- TXT: 전체 canonical 본문, renderer·snapshot·runtime, 관련 source 파일 age/size, 주요 snapshot/queue 원문 발췌 포함.
- /structure_board TXT: urgent targets/result/status와 writer status 원문을 포함해 누락·요청·선택·갱신·대기·실패를 한 파일로 추적.
- /batch·여러 줄 명령: 화면은 compact, TXT는 각 명령 전체 본문을 그대로 보존.
- 단일명령 TXT는 무관한 /flow_map_full을 다시 실행하지 않는다.

변경하지 않음
- Strategy/Paper/Review/Guard 실행경로
- 후보 수·S1/S2/S3·rank
- trigger/invalid/target
- 기존 OPEN/CLOSED/decision/exact 원장
- 진입·청산·수익보호
- 자동매수 OFF

판정
- 로컬 py_compile, AST, import synthetic, 74/74 공개명령 TXT 대상 확인 PASS
- 서버에서 단일명령 1회 실행 → compact 화면 1개 + TXT 1개, 명령 재실행 없음 확인 전 CHECK
