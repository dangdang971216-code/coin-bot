# v1108 지도 신뢰도 마감

## 수정 범위
- Guard canonical 운영지도 artifact 분류와 보존계약
- Main `/flow_map` TXT 표시
- ZIP·서비스 로그·생성 보고서를 장부에서 분리
- 파일 상태를 ACTIVE_RUNTIME_ARTIFACT / LEGACY_STOPPED / ORPHAN_CHECK / 보호장부 / 비장부로 구분
- owner·증가속도·runtime writer·보존등급·정리 가능 여부·행동을 함께 표시
- event-driven cache를 단순 mtime이 아닌 source 변화와 owner heartbeat로 판정
- RSS 시간당 추세는 같은 PID 30표본·1800초 이상에서만 MEASURED

## 수정하지 않은 영역
- Strategy·Paper·Risk·Review 매매 로직
- 품질 threshold
- actual-entry RR·spread·slippage 계약
- OPEN 30 / cycle 신규 3
- trigger·invalid·target·청산계약
- 핵심 원장 내용·형식·삭제정책
- 자동매수 OFF

## 최소 서버 검수
1. 가드봇 `/gupgrade_bundle` 단독 실행
2. 적용 후 가드봇 `/gops_refresh`
3. 메인봇에서 `/flow_map`과 `/errorlog`를 같은 메시지로 실행

## 정상 기대
- Main v2.13.1092 / Guard v2.5.161
- 위치계약 20/20, 미매핑 0, runtime mismatch 0
- active orphan 0 또는 해당 파일의 정확한 caller/writer 감사 지시
- ZIP·로그는 NON_LEDGER
- 정지된 과거 state는 LEGACY_STOPPED·관찰만
- 짧은 재시작 메모리 표본은 INSUFFICIENT_WINDOW
