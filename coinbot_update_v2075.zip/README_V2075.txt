v2075: familiar /version_score period board uses post-reset current Paper epoch stats; includes v2074 latency timestamp bridge.
