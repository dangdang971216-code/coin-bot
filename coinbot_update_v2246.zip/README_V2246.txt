코인봇 v2246 — Review 주인 단일화

확인된 문제
- Guard와 Review가 같은 파생 cache 삭제를 둘 다 수행함.
- 배포 검증이 실행신분과 분석완료를 섞고, 실제 source 주인을 family 이름만으로 추정함.
- v2245 전체코드 ZIP의 DEPLOY_BUNDLE.json이 v2244로 남아 있던 포장 오류도 확인됨.

수정
1. Guard: stop/drain/cache cleanup/stale identity 제거 단독 주인.
2. Review: singleton lock/status/분석 단독 주인. 시작 첫 쓰기는 lock→running status.
3. Main: Review 결과 읽기만 유지.
4. active alias=deployed target hash, systemd ExecStart, MainPID cmdline까지 같은 source인지 증명.
5. runtime identity PASS와 분석 준비상태를 분리.

보존
- 원본 거래·decision·exact·change·issue·기존 Shadow 장부
- 상승예측식/가중치, 후보/S1/Paper, 진입/청산계약
- 자동매수 OFF
