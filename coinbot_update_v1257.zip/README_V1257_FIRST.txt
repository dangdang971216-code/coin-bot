코인봇 v1257 통합 완성본

이 ZIP 하나가 적용 대상이다.
- v1211부터 현재까지 실제 코드·owner·원장 연결을 다시 추적했다.
- 현재 동적 구조선이 후보·S1·기본 trigger/invalid/target의 유일한 본선이다.
- v1211은 신규 OPEN의 가까운 진입실패 지지선과 강한 거래의 먼 확장저항 제안에만 사용한다.
- 기존 OPEN은 절대 새 계약으로 바꾸지 않는다.
- policy_competition/structure_rebuild 서비스는 중지·비활성화하되 파일과 과거 기록은 보존한다.
- 자동매수 OFF.

적용 명령은 APPLY_V1257.txt 참고.
