coinbot update v2153

Purpose
- Fix Guard integrated-release false CHECK for unchanged workers represented by null/blank placeholders.
- Correct the Strategy role display: role_mismatch_* values are mismatch-row counts, so 0 means normal.

Changed
- Guard v2.6.24 only

Unchanged
- Main, Paper, Strategy v2.053, Review and all other workers
- Structure/prediction/entry/exit formulas and candidate delivery
- Current OPEN/CLOSED and all historical ledgers
- Auto-buy OFF
