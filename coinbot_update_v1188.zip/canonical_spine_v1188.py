#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Coinbot canonical spine v1188.

One owner per value, atomic snapshots, bounded readers, and no trading-rule
recalculation in Main/Guard/Review. This module contains only shared I/O and
read-only aggregation helpers. It never writes OPEN/CLOSED/decision ledgers.
"""
from __future__ import annotations

import hashlib
import json
import math
import os
import re
import statistics
import time
from collections import Counter
from dataclasses import dataclass
from datetime import datetime
from pathlib import Path
from typing import Any, Dict, Iterable, List, Mapping, MutableMapping, Optional, Sequence, Tuple

SPINE_VERSION = "v1188"
SPINE_SCHEMA = "coinbot_canonical_spine_v1188"
AUTO_BUY = False
STRATEGY_MODE = "ALT_SWING"


def now_ts() -> float:
    return time.time()


def now_text(ts: Optional[float] = None) -> str:
    return time.strftime("%Y-%m-%d %H:%M:%S", time.localtime(ts or now_ts()))


def json_default(value: Any) -> Any:
    if isinstance(value, Path):
        return str(value)
    return str(value)


def atomic_write_json(path: Path, payload: Any) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    tmp = path.with_name(f".{path.name}.tmp.{os.getpid()}.{time.time_ns()}")
    with tmp.open("w", encoding="utf-8") as handle:
        json.dump(payload, handle, ensure_ascii=False, separators=(",", ":"), default=json_default)
        handle.flush()
        os.fsync(handle.fileno())
    os.replace(tmp, path)
    try:
        directory_fd = os.open(str(path.parent), os.O_RDONLY)
    except OSError:
        return
    try:
        os.fsync(directory_fd)
    finally:
        os.close(directory_fd)


def append_jsonl(path: Path, payload: Mapping[str, Any]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    line = json.dumps(dict(payload), ensure_ascii=False, separators=(",", ":"), default=json_default) + "\n"
    with path.open("a", encoding="utf-8") as handle:
        handle.write(line)
        handle.flush()
        os.fsync(handle.fileno())


def read_json(path: Path, default: Any = None) -> Any:
    try:
        if not path.exists() or not path.is_file():
            return default
        return json.loads(path.read_text(encoding="utf-8", errors="ignore"))
    except (OSError, json.JSONDecodeError, TypeError, ValueError):
        return default


def read_text(path: Path, default: str = "", max_bytes: int = 2_000_000) -> str:
    try:
        if not path.exists() or not path.is_file():
            return default
        size = path.stat().st_size
        with path.open("rb") as handle:
            if size > max_bytes:
                handle.seek(size - max_bytes)
            raw = handle.read(max_bytes)
        return raw.decode("utf-8", errors="ignore")
    except OSError:
        return default


def read_jsonl_tail(path: Path, limit: int = 2000, max_bytes: int = 32 * 1024 * 1024) -> List[Dict[str, Any]]:
    if limit <= 0 or not path.exists() or not path.is_file():
        return []
    try:
        size = path.stat().st_size
        take = min(size, max_bytes)
        with path.open("rb") as handle:
            if size > take:
                handle.seek(size - take)
                handle.readline()
            data = handle.read(take)
    except OSError:
        return []
    out: List[Dict[str, Any]] = []
    for raw in data.splitlines()[-limit:]:
        try:
            item = json.loads(raw.decode("utf-8", errors="ignore"))
        except (UnicodeDecodeError, json.JSONDecodeError):
            continue
        if isinstance(item, dict):
            out.append(item)
    return out


def read_candidate_rows(path: Path, max_rows: int = 5000) -> List[Dict[str, Any]]:
    """Read current candidate snapshot only.

    The canonical file may be JSONL or a compact JSON object/list depending on
    the deployed writer version. No stale cache fallback is used.
    """
    if not path.exists():
        return []
    obj = read_json(path, None)
    rows = rows_from(obj)
    if rows:
        return rows[:max_rows]
    return read_jsonl_tail(path, max_rows, max_bytes=64 * 1024 * 1024)


def rows_from(obj: Any) -> List[Dict[str, Any]]:
    if isinstance(obj, list):
        return [dict(item) for item in obj if isinstance(item, dict)]
    if not isinstance(obj, dict):
        return []
    for key in (
        "rows", "items", "candidates", "active_rows", "display_rows",
        "top_candidates", "positions", "open_positions", "data",
    ):
        value = obj.get(key)
        if isinstance(value, list):
            return [dict(item) for item in value if isinstance(item, dict)]
        if isinstance(value, dict):
            out: List[Dict[str, Any]] = []
            for item_key, item_value in value.items():
                if isinstance(item_value, dict):
                    row = dict(item_value)
                    row.setdefault("pos_id", item_key)
                    out.append(row)
            if out:
                return out
    if obj and all(isinstance(value, dict) for value in obj.values()):
        return [dict(value, pos_id=value.get("pos_id") or key) for key, value in obj.items()]
    return []


def file_age(path: Path, at: Optional[float] = None) -> Optional[float]:
    try:
        return max(0.0, (at or now_ts()) - path.stat().st_mtime)
    except OSError:
        return None


def sha256_file(path: Path, chunk_size: int = 1024 * 1024) -> str:
    digest = hashlib.sha256()
    try:
        with path.open("rb") as handle:
            while True:
                chunk = handle.read(chunk_size)
                if not chunk:
                    break
                digest.update(chunk)
    except OSError:
        return ""
    return digest.hexdigest()


def digest_obj(payload: Any) -> str:
    raw = json.dumps(payload, ensure_ascii=False, sort_keys=True, separators=(",", ":"), default=json_default)
    return hashlib.sha256(raw.encode("utf-8")).hexdigest()


def num(*values: Any, default: Optional[float] = None) -> Optional[float]:
    for value in values:
        if value in (None, "", [], {}):
            continue
        try:
            parsed = float(str(value).replace(",", "").replace("%", "").strip())
        except (TypeError, ValueError):
            continue
        if math.isfinite(parsed):
            return parsed
    return default


def integer(*values: Any, default: int = 0) -> int:
    value = num(*values, default=None)
    return int(value) if value is not None else default


def text(*values: Any, default: str = "") -> str:
    for value in values:
        if value in (None, "", "-", [], {}):
            continue
        out = str(value).strip()
        if out:
            return out
    return default


def mapping(*values: Any) -> Dict[str, Any]:
    for value in values:
        if isinstance(value, dict):
            return value
    return {}


def sequence(*values: Any) -> List[Any]:
    for value in values:
        if isinstance(value, (list, tuple)):
            return list(value)
    return []


def deep_get(obj: Any, path: str, default: Any = None) -> Any:
    current = obj
    for part in path.split("."):
        if not isinstance(current, dict) or part not in current:
            return default
        current = current[part]
    return current


def first_path(obj: Mapping[str, Any], paths: Sequence[str], default: Any = None) -> Any:
    for path in paths:
        value = deep_get(obj, path, None)
        if value not in (None, "", [], {}):
            return value
    return default


def parse_ts(*values: Any) -> float:
    for value in values:
        if value in (None, "", [], {}):
            continue
        if isinstance(value, (int, float)):
            candidate = float(value)
            if candidate > 1e12:
                candidate /= 1000.0
            if candidate > 1e9:
                return candidate
        raw = str(value).strip().replace(" KST", "")
        try:
            candidate = float(raw)
            if candidate > 1e12:
                candidate /= 1000.0
            if candidate > 1e9:
                return candidate
        except ValueError:
            pass
        for fmt in ("%Y-%m-%d %H:%M:%S", "%Y-%m-%dT%H:%M:%S", "%Y-%m-%dT%H:%M:%S%z"):
            try:
                return datetime.strptime(raw, fmt).timestamp()
            except ValueError:
                continue
    return 0.0


def ticker(value: Any) -> str:
    out = str(value or "").strip().upper().replace("/", "-").replace("_", "-")
    parts = [part for part in out.split("-") if part]
    if len(parts) > 1:
        parts = [part for part in parts if part != "KRW"]
        out = parts[-1] if parts else out
    if out.endswith("KRW") and len(out) > 3:
        out = out[:-3]
    return out


def stage(row: Mapping[str, Any]) -> str:
    gate = mapping(row.get("swing_entry_gate_v977"), row.get("swing_entry_gate"))
    value = text(
        gate.get("stage"), row.get("s_stage"), row.get("stage"),
        row.get("grade"), row.get("candidate_stage"), default="UNKNOWN",
    ).upper()
    if value in {"BUY_READY", "READY", "S"}:
        return "S1"
    return value


def decision_key(row: Mapping[str, Any]) -> str:
    gate = mapping(row.get("swing_entry_gate_v977"), row.get("swing_entry_gate"))
    decision = mapping(row.get("canonical_entry_decision"))
    return text(
        row.get("paper_decision_key_v926"), row.get("swing_gate_decision_key_v977"),
        gate.get("decision_key"), decision.get("decision_key"), row.get("decision_key"),
    )


def candidate_key(row: Mapping[str, Any]) -> str:
    return text(
        row.get("trigger_occurrence_candidate_key_v1037"), row.get("candidate_key"),
        row.get("entry_build_key"), row.get("event_key"), row.get("event_id"),
    )


def row_price(row: Mapping[str, Any]) -> Optional[float]:
    return num(row.get("current_price"), row.get("entry_price"), row.get("price"), row.get("trade_price"))


def median(values: Iterable[Any]) -> Optional[float]:
    clean: List[float] = []
    for value in values:
        parsed = num(value, default=None)
        if parsed is not None:
            clean.append(parsed)
    return float(statistics.median(clean)) if clean else None


def average(values: Iterable[Any]) -> Optional[float]:
    clean: List[float] = []
    for value in values:
        parsed = num(value, default=None)
        if parsed is not None:
            clean.append(parsed)
    return float(sum(clean) / len(clean)) if clean else None


def pct_text(value: Any, digits: int = 3) -> str:
    parsed = num(value, default=None)
    return "정보없음" if parsed is None else f"{parsed:+.{digits}f}%"


@dataclass(frozen=True)
class SpinePaths:
    base: Path

    @property
    def strategy_status(self) -> Path:
        return self.base / "clean_strategy_worker_status.json"

    @property
    def strategy_candidates(self) -> Path:
        return self.base / "paper_candidates_latest.jsonl"

    @property
    def strategy_hold(self) -> Path:
        return self.base / "paper_s1_hold_cache.json"

    @property
    def strategy_pipeline(self) -> Path:
        return self.base / "clean_strategy_candidate_pipeline_status_v1150.json"

    @property
    def strategy_handoff(self) -> Path:
        return self.base / "clean_strategy_paper_handoff_status.json"

    @property
    def review_request(self) -> Path:
        return self.base / "review_observation_request_v1181.json"

    @property
    def review_status(self) -> Path:
        return self.base / "clean_review_worker_status.json"

    @property
    def review_snapshot(self) -> Path:
        return self.base / "canonical_review_snapshot_v1181.json"

    @property
    def candidate_standard(self) -> Path:
        return self.base / "canonical_candidate_standard_v1181.json"

    @property
    def paper_status(self) -> Path:
        return self.base / "paper_bot_status.json"

    @property
    def paper_open(self) -> Path:
        return self.base / "paper_bot_open.json"

    @property
    def paper_control(self) -> Path:
        return self.base / "paper_bot_control.json"

    @property
    def paper_handoff(self) -> Path:
        return self.base / "paper_bot_candidate_handoff_status.json"

    @property
    def paper_trace(self) -> Path:
        return self.base / "paper_bot_candidate_handoff_trace.json"

    @property
    def performance(self) -> Path:
        return self.base / "canonical_performance_snapshot_v987.json"

    @property
    def ops_snapshot(self) -> Path:
        return self.base / "ops_spine_snapshot_v1181.json"

    @property
    def main_status(self) -> Path:
        return self.base / "clean_brain_status.json"

    @property
    def guard_status(self) -> Path:
        return self.base / "clean_guard_runtime_status_v1010.json"

    @property
    def scanner_status(self) -> Path:
        return self.base / "clean_scanner_status.json"

    @property
    def feature_status(self) -> Path:
        return self.base / "clean_feature_status.json"

    @property
    def candle_status(self) -> Path:
        return self.base / "clean_candle_status.json"

    @property
    def market_status(self) -> Path:
        return self.base / "clean_market_regime_status.json"

    @property
    def orderflow_status(self) -> Path:
        return self.base / "clean_orderflow_status.json"

    @property
    def target_status(self) -> Path:
        return self.base / "clean_target_router_status.json"

    @property
    def risk_status(self) -> Path:
        return self.base / "clean_risk_status.json"

    @property
    def ws_status(self) -> Path:
        return self.base / "clean_ws_sidecar_status.json"

    @property
    def micro_status(self) -> Path:
        return self.base / "clean_bithumb_micro_status.json"


def metric_from_row(row: Mapping[str, Any], name: str) -> Optional[float]:
    gate = mapping(row.get("swing_entry_gate_v977"), row.get("swing_entry_gate"))
    quality = mapping(row.get("swing_quality_gate"), gate.get("swing_quality_gate"))
    execution = mapping(row.get("execution_risk"), row.get("paper_execution_diagnostics"))
    path_map: Dict[str, Sequence[str]] = {
        "price_reaction": (
            "price_reaction_score", "price_reaction", "price_reaction_pct", "price_reaction_1m_pct", "feature_price_reaction",
            "swing_quality_gate.price_reaction", "quality_observation_v925.price_reaction",
        ),
        "relative_strength": (
            "relative_strength", "relative_strength_pct", "relative_strength_score", "relative_strength_rank_pct_v1095", "market_relative_strength",
            "swing_quality_gate.relative_strength",
        ),
        "money_flow": (
            "money_flow", "money_flow_score", "money_flow_strength",
            "swing_quality_gate.money_flow",
        ),
        "buy_ratio": (
            "buy_trade_ratio", "buy_ratio", "trade_buy_ratio", "micro_buy_ratio",
            "swing_quality_gate.buy_ratio", "execution_risk.buy_trade_ratio",
        ),
        "buy_sustain": (
            "buy_sustain", "buy_sustain_1m", "buy_sustain_1m_real", "micro_buy_sustain_1m", "one_min_persist", "buy_pressure_persist",
            "swing_quality_gate.buy_sustain",
        ),
        "rank_score": (
            "swing_quality_rank_score", "quality_rank_score_v1095", "score",
            "swing_quality_gate.rank_score",
        ),
        "rr": (
            "risk_reward", "rr_ratio", "actual_entry_rr",
            "swing_entry_gate_v977.risk_reward", "swing_entry_gate.risk_reward",
        ),
        "target_room": (
            "target_room_pct", "expected_upside_pct", "target_space_pct",
            "swing_entry_gate_v977.target_room_pct", "risk_reward.expected_upside_pct",
        ),
        "invalid_distance": (
            "invalid_distance_pct", "distance_to_invalid_pct", "expected_downside_pct", "stop_distance_pct",
            "risk_reward.expected_downside_pct",
        ),
        "chase": (
            "trigger_chase_pct", "trigger_overshoot_pct", "late_chase_pct",
        ),
        "spread": (
            "spread_pct", "spread", "execution_risk.spread", "swing_entry_gate_v977.spread_pct",
        ),
        "slippage": (
            "confirmed_slippage_pct", "slippage_pct", "execution_risk.slippage",
            "swing_entry_gate_v977.confirmed_slippage_pct",
        ),
    }
    value = first_path(row, path_map.get(name, (name,)), None)
    if value is None:
        if name == "rank_score":
            value = quality.get("rank_score")
        elif name == "spread":
            value = execution.get("spread")
        elif name == "slippage":
            value = execution.get("slippage")
    return num(value, default=None)


def structure_sources(row: Mapping[str, Any]) -> Dict[str, Any]:
    gate = mapping(row.get("swing_entry_gate_v977"), row.get("swing_entry_gate"))
    plan = mapping(row.get("swing_structure_plan_v977"), gate.get("structure_plan"), row.get("structure_plan"))
    trigger = mapping(plan.get("trigger"))
    invalid = mapping(plan.get("invalid"))
    target = mapping(plan.get("target"))
    levels = mapping(row.get("structure_levels"), row.get("structure_context_v871"))
    return {
        "trigger_source": text(row.get("swing_trigger_source_v977"), trigger.get("source"), levels.get("execution_resistance_source")),
        "invalid_source": text(row.get("swing_invalid_source_v977"), invalid.get("source"), levels.get("setup_support_source")),
        "target_source": text(row.get("swing_target_source_v977"), target.get("source"), levels.get("major_resistance_source")),
        "trigger_price": num(row.get("swing_trigger_price_v977"), row.get("trigger_price"), trigger.get("price"), default=None),
        "invalid_price": num(row.get("swing_invalid_price_v977"), row.get("invalid_price"), invalid.get("price"), default=None),
        "target_price": num(row.get("swing_target_price_v977"), row.get("target_price"), target.get("price"), default=None),
    }


def source_lane(row: Mapping[str, Any]) -> str:
    raw = text(
        row.get("source_lane"), row.get("candidate_source"), row.get("ingress_source"),
        row.get("source_path"), row.get("canonical_lane"), row.get("scanner_reason"),
        row.get("strategy_key"), default="unknown",
    ).lower()
    if "hot" in raw or "spike" in raw or "급등" in raw:
        return "hot-rank"
    if "break" in raw or "돌파" in raw:
        return "돌파초입"
    if "money" in raw or "돈흐름" in raw:
        return "돈흐름"
    if "lead" in raw or "주도" in raw:
        return "주도흐름"
    if "low" in raw or "저점" in raw or "vwap" in raw:
        return "저점회복"
    if "coverage" in raw or "전체" in raw:
        return "전체커버"
    return text(row.get("canonical_lane"), default="기타")


def performance_summary(performance: Mapping[str, Any]) -> Dict[str, Any]:
    windows = mapping(performance.get("windows"))
    epoch = mapping(performance.get("performance_epoch_v1045"))
    epoch_windows = mapping(epoch.get("windows"))
    current = mapping(epoch.get("stats"), epoch_windows.get("all"), performance.get("fresh_epoch_stats"), windows.get("all"), performance.get("summary"))
    counts = mapping(performance.get("counts"))
    rows = sequence(performance.get("rows"))
    return {
        "snapshot_id": performance.get("snapshot_id"),
        "generated_at": performance.get("generated_at"),
        "source_owner": performance.get("source_owner"),
        "count": integer(current.get("count"), current.get("n"), counts.get("current_epoch_exact_rows_v1045"), counts.get("included"), len(rows)),
        "wins": integer(current.get("wins"), current.get("win_count")),
        "losses": integer(current.get("losses"), current.get("loss_count")),
        "win_rate": num(current.get("win_rate"), current.get("win_rate_pct"), current.get("win_pct"), default=None),
        "sum_pct": num(current.get("sum_pct"), current.get("total_pct"), current.get("pnl_pct_sum"), current.get("total"), default=None),
        "avg_pct": num(current.get("avg_pct"), current.get("average_pct"), current.get("avg"), default=None),
        "mfe_median": num(current.get("mfe_median"), current.get("median_mfe_pct"), current.get("mfe"), default=None),
        "mae_median": num(current.get("mae_median"), current.get("median_mae_pct"), current.get("mae"), default=None),
        "duplicate": integer(counts.get("duplicate_rows"), counts.get("duplicates")),
        "missing_key": integer(counts.get("decision_key_missing"), counts.get("missing_key")),
        "unlinked": integer(counts.get("decision_unlinked"), counts.get("unlinked")),
    }


def build_review_snapshot(base: Path, request: Optional[Mapping[str, Any]] = None) -> Dict[str, Any]:
    paths = SpinePaths(base)
    now = now_ts()
    req = dict(request or read_json(paths.review_request, {}) or {})
    rows = read_candidate_rows(paths.strategy_candidates)
    strategy_status = read_json(paths.strategy_status, {}) or {}
    paper_status = read_json(paths.paper_status, {}) or {}
    performance = read_json(paths.performance, {}) or {}
    contract = read_json(base / "clean_candidate_standard_contract_v1141.json", {}) or {}

    stage_counts = Counter(stage(row) for row in rows)
    source_counts = Counter(source_lane(row) for row in rows)
    active_rows = [row for row in rows if stage(row) == "S1"]
    decision_missing = sum(1 for row in active_rows if not decision_key(row))
    candidate_missing = sum(1 for row in active_rows if not candidate_key(row))
    structure_complete = 0
    source_combinations: Counter[str] = Counter()
    metrics: Dict[str, List[float]] = {key: [] for key in (
        "price_reaction", "relative_strength", "money_flow", "buy_ratio", "buy_sustain",
        "rank_score", "rr", "target_room", "invalid_distance", "chase", "spread", "slippage",
    )}
    occurrence_ages: List[float] = []
    samples: List[Dict[str, Any]] = []
    for row in active_rows:
        sources = structure_sources(row)
        complete = all(sources.get(key) not in (None, "", 0, 0.0) for key in (
            "trigger_price", "invalid_price", "target_price",
        ))
        if complete:
            structure_complete += 1
        combo = "|".join([
            text(sources.get("trigger_source"), default="SOURCE_MISSING"),
            text(sources.get("invalid_source"), default="SOURCE_MISSING"),
            text(sources.get("target_source"), default="SOURCE_MISSING"),
        ])
        source_combinations[combo] += 1
        for name in metrics:
            value = metric_from_row(row, name)
            if value is not None:
                metrics[name].append(value)
        event_ts = parse_ts(
            row.get("actual_trigger_event_at_v1173"), row.get("trigger_event_at_v1153"),
            deep_get(row, "trigger_occurrence_v1037.event_ts"), deep_get(row, "candidate_path_timestamps_v1153.trigger_event_at"),
        )
        if event_ts > 0:
            occurrence_ages.append(max(0.0, now - event_ts))
        if len(samples) < 20 and stage(row) in {"S1", "S2"}:
            samples.append({
                "ticker": ticker(row.get("ticker") or row.get("market") or row.get("symbol")),
                "stage": stage(row),
                "decision_key": decision_key(row),
                "candidate_key": candidate_key(row),
                "source_lane": source_lane(row),
                "rr": metric_from_row(row, "rr"),
                "target_room_pct": metric_from_row(row, "target_room"),
                "spread_pct": metric_from_row(row, "spread"),
                "structure": sources,
            })

    request_age = None
    req_ts = parse_ts(req.get("committed_handoff_completed_ts"), req.get("created_ts"), req.get("updated_ts"))
    if req_ts:
        request_age = max(0.0, now - req_ts)
    pipeline_id = text(req.get("pipeline_cycle_id"), req.get("candidate_pipeline_cycle_id_v1150"))
    commit_id = text(req.get("candidate_commit_id"), req.get("candidate_commit_id_v1150"))
    row_count_match = integer(req.get("candidate_rows"), default=len(rows)) == len(rows)
    source_state = "NORMAL" if rows and pipeline_id and commit_id and row_count_match else "CHECK"
    contract_digest = text(contract.get("contract_digest"))
    perf = performance_summary(performance)

    snapshot: Dict[str, Any] = {
        "schema": "canonical_review_snapshot_v1181",
        "version": "review_worker_v1.016",
        "build": "v1186_review_s1_scope_and_performance_mapping_2026-07-02",
        "generated_ts": now,
        "generated_text": now_text(now),
        "strategy_mode": STRATEGY_MODE,
        "auto_buy": False,
        "owner": "review_worker_single_candidate_standard_owner_v1181",
        "source": {
            "state": source_state,
            "pipeline_cycle_id": pipeline_id,
            "candidate_commit_id": commit_id,
            "request_age_sec": request_age,
            "candidate_file_age_sec": file_age(paths.strategy_candidates, now),
            "candidate_rows": len(rows),
            "request_rows": integer(req.get("candidate_rows"), default=len(rows)),
            "row_count_match": row_count_match,
            "strategy_version": strategy_status.get("version") or strategy_status.get("strategy_worker_version"),
            "paper_version": paper_status.get("version") or paper_status.get("paper_version"),
        },
        "candidate": {
            "total": len(rows),
            "stage_counts": dict(stage_counts),
            "s1": stage_counts.get("S1", 0),
            "s2": stage_counts.get("S2", 0),
            "s3": stage_counts.get("S3", 0),
            "decision_key_missing": decision_missing,
            "candidate_key_missing": candidate_missing,
            "source_lane_counts": dict(source_counts),
            "source_lane_top": source_counts.most_common(10),
        },
        "structure": {
            "evaluated": len(active_rows),
            "complete": structure_complete,
            "complete_pct": round(structure_complete / len(active_rows) * 100.0, 3) if active_rows else None,
            "source_missing": max(0, len(active_rows) - structure_complete),
            "source_combinations": dict(source_combinations.most_common(20)),
        },
        "quality": {
            name: {"n": len(values), "median": median(values), "average": average(values)}
            for name, values in metrics.items()
        },
        "time": {
            "occurrence_age_n": len(occurrence_ages),
            "occurrence_age_median_sec": median(occurrence_ages),
            "occurrence_age_max_sec": max(occurrence_ages) if occurrence_ages else None,
            "strategy_execution_handoff_sec": num(strategy_status.get("execution_handoff_elapsed_sec_v1179"), default=None),
            "strategy_full_cycle_sec": num(strategy_status.get("full_cycle_sec_v1031"), strategy_status.get("last_sec"), default=None),
            "paper_cycle_sec": num(paper_status.get("elapsed_sec"), deep_get(paper_status, "paper_cycle_profile_v1053.cycle.total.sec"), default=None),
        },
        "performance": perf,
        "contract": {
            "schema": contract.get("schema"),
            "contract_digest": contract_digest,
            "strategy_source_sha256": contract.get("strategy_source_sha256"),
            "invariants": contract.get("invariants"),
            "auto_baseline_replace": False,
        },
        "samples": samples,
        "invariants": {
            "candidate_formula_changed": False,
            "trigger_changed": False,
            "invalid_changed": False,
            "target_changed": False,
            "rr_changed": False,
            "exit_contract_changed": False,
            "auto_buy": False,
            "live_ledger_write": False,
        },
    }
    snapshot["snapshot_id"] = f"review-{int(now * 1000)}-{digest_obj(snapshot)[:12]}"
    return snapshot


def build_candidate_standard(snapshot: Mapping[str, Any]) -> Dict[str, Any]:
    source = mapping(snapshot.get("source"))
    candidate = mapping(snapshot.get("candidate"))
    structure = mapping(snapshot.get("structure"))
    quality = mapping(snapshot.get("quality"))
    time_info = mapping(snapshot.get("time"))
    perf = mapping(snapshot.get("performance"))
    contract = mapping(snapshot.get("contract"))
    source_state = text(source.get("state"), default="CHECK")
    missing: List[str] = []
    if integer(candidate.get("decision_key_missing")):
        missing.append("decision_key")
    if integer(candidate.get("candidate_key_missing")):
        missing.append("candidate_key")
    if integer(structure.get("source_missing")):
        missing.append("structure_source")
    if not text(contract.get("contract_digest")):
        missing.append("contract_digest")
    if source_state != "NORMAL":
        state = "CHECK_SOURCE"
    elif missing:
        state = "PARTIAL_SOURCE"
    else:
        state = "NORMAL"
    return {
        "schema": "canonical_candidate_standard_v1181",
        "version": snapshot.get("version"),
        "snapshot_id": snapshot.get("snapshot_id"),
        "generated_ts": snapshot.get("generated_ts"),
        "generated_text": snapshot.get("generated_text"),
        "state": state,
        "easy_state": {
            "NORMAL": "전체 정상",
            "PARTIAL_SOURCE": "일부 근거 누락",
            "CHECK_SOURCE": "현재 원천 확인 필요",
        }.get(state, "확인 필요"),
        "strategy_mode": STRATEGY_MODE,
        "auto_buy": False,
        "scope": {
            "delivery": "current Strategy committed generation",
            "candidate": "same candidate commit rows",
            "performance": "Paper canonical performance snapshot only",
        },
        "delivery": source,
        "candidate": candidate,
        "structure": structure,
        "quality": quality,
        "time": time_info,
        "performance": perf,
        "contract": contract,
        "missing": missing,
        "samples": snapshot.get("samples") or [],
        "invariants": snapshot.get("invariants") or {},
    }


def _status_record(name: str, path: Path, owner: str, fresh_limit: float, at: float) -> Dict[str, Any]:
    obj = read_json(path, {}) or {}
    age = file_age(path, at)
    running = obj.get("running")
    state_raw = text(obj.get("state"), obj.get("status"), obj.get("phase"), default="UNKNOWN")
    if not path.exists():
        state = "CHECK"
        reason = "status file missing"
    elif age is None or age > fresh_limit:
        state = "CHECK"
        reason = f"status stale {age:.1f}s" if age is not None else "status age unknown"
    elif running is False or state_raw.upper() in {"ERROR", "FAIL", "FAILED", "STOPPED", "DOWN"}:
        state = "FAIL"
        reason = text(obj.get("last_error"), obj.get("error"), state_raw)
    else:
        state = "NORMAL"
        reason = ""
    return {
        "name": name,
        "owner": owner,
        "state": state,
        "reason": reason,
        "age_sec": age,
        "version": obj.get("version") or obj.get("worker_version") or obj.get("strategy_worker_version") or obj.get("paper_version"),
        "build": obj.get("build") or obj.get("build_label"),
        "phase": obj.get("phase") or obj.get("runtime_phase_v994") or obj.get("startup_phase"),
        "raw": obj,
    }



_STATE_RANK = {"NORMAL": 0, "COLLECTING": 1, "PARTIAL": 2, "CHECK": 3, "FAIL": 4}


def normalize_state(value: Any, default: str = "CHECK") -> str:
    raw = text(value, default=default).upper()
    aliases = {
        "OK": "NORMAL", "PASS": "NORMAL", "DONE": "NORMAL", "READY": "NORMAL",
        "RUNNING": "NORMAL", "ACTIVE": "NORMAL", "REVIEWABLE": "NORMAL",
        "PARTIAL_SOURCE": "PARTIAL", "CHECK_SOURCE": "CHECK",
        "ERROR": "FAIL", "FAILED": "FAIL", "DOWN": "FAIL", "STOPPED": "FAIL",
    }
    raw = aliases.get(raw, raw)
    return raw if raw in _STATE_RANK else default


def merge_states(*values: Any) -> str:
    states = [normalize_state(value) for value in values if value not in (None, "")]
    if not states:
        return "CHECK"
    return max(states, key=lambda item: _STATE_RANK.get(item, 3))


def _safe_size(path: Path) -> Optional[int]:
    try:
        return int(path.stat().st_size)
    except OSError:
        return None


def _file_evidence(path: Path, at: float, *, fresh_limit: Optional[float] = None) -> Dict[str, Any]:
    age = file_age(path, at)
    exists = path.exists() and path.is_file()
    if not exists:
        state, reason = "CHECK", "파일 없음"
    elif fresh_limit is not None and (age is None or age > fresh_limit):
        state, reason = "CHECK", f"오래됨 {age:.1f}초" if age is not None else "시간 확인 불가"
    else:
        state, reason = "NORMAL", ""
    return {
        "path": path.name,
        "exists": exists,
        "age_sec": age,
        "size_bytes": _safe_size(path),
        "state": state,
        "reason": reason,
    }


def _value_count(obj: Mapping[str, Any], *paths: str, default: int = 0) -> int:
    for path in paths:
        value = deep_get(obj, path, None)
        if value not in (None, "", [], {}):
            return integer(value, default=default)
    return default


def _value_num(obj: Mapping[str, Any], *paths: str) -> Optional[float]:
    for path in paths:
        value = deep_get(obj, path, None)
        parsed = num(value, default=None)
        if parsed is not None:
            return parsed
    return None


def _pid_alive(pid: int) -> bool:
    return bool(pid > 0 and Path(f"/proc/{pid}").exists())


def _read_lock(base: Path, relative: str) -> Dict[str, Any]:
    return read_json(base / relative, {}) or {}


def _runtime_contract(base: Path, guard_runtime: Mapping[str, Any], workers: Mapping[str, Mapping[str, Any]]) -> Dict[str, Any]:
    components = mapping(guard_runtime.get("components"))
    singleton_names = {"main", "paper", "guard", "strategy", "review", "ws", "micro"}
    rows: List[Dict[str, Any]] = []
    problems: List[Dict[str, Any]] = []
    for key in ("main", "paper", "guard", "strategy", "review", "scanner", "feature", "candle", "market", "orderflow", "target_router", "risk", "ws", "micro"):
        comp_key = "target" if key == "target_router" else key
        comp = mapping(components.get(comp_key), components.get(key))
        worker = mapping(workers.get(comp_key), workers.get(key))
        if not comp:
            state = "CHECK"
            row = {"component": key, "state": state, "reason": "Guard runtime component 증거 없음"}
            rows.append(row)
            problems.append(row)
            continue
        main_pid = integer(comp.get("main_pid"))
        status_pid = integer(comp.get("status_pid"))
        process_count = integer(comp.get("process_count"))
        runtime_state = normalize_state(comp.get("runtime_state"), default="CHECK")
        pid_ok = _pid_alive(main_pid)
        status_pid_match = status_pid in (0, main_pid)
        singleton_ok = process_count == 1 if key in singleton_names else process_count >= 1
        alias_match = comp.get("source_alias_hash_match")
        checks = {
            "service_runtime": runtime_state == "NORMAL",
            "main_pid_alive": pid_ok,
            "singleton": singleton_ok,
            "status_pid_match": status_pid_match,
            "source_alias_hash_match": alias_match is not False,
        }
        if not pid_ok or runtime_state == "FAIL" or (key in singleton_names and process_count > 1):
            state = "FAIL"
        elif not all(checks.values()):
            state = "CHECK"
        else:
            state = "NORMAL"
        reason_parts = [name for name, ok in checks.items() if not ok]
        row = {
            "component": key,
            "state": state,
            "service": comp.get("service"),
            "main_pid": main_pid,
            "status_pid": status_pid,
            "process_count": process_count,
            "cpu_pct": num(comp.get("cpu_pct"), default=None),
            "rss_mb": num(comp.get("rss_mb"), default=None),
            "status_age_sec": num(comp.get("status_age_sec"), default=None),
            "status_version": comp.get("status_version") or worker.get("version"),
            "phase": worker.get("phase"),
            "source_alias_hash_match": alias_match,
            "reason": ", ".join(reason_parts),
            "checks": checks,
        }
        rows.append(row)
        if state != "NORMAL":
            problems.append(row)

    locks: List[Dict[str, Any]] = []
    lock_specs = (
        ("strategy", "runtime/strategy_worker_singleton_v1110.lock"),
        ("review", "runtime/review_worker_singleton_v1121.lock"),
    )
    by_name = {str(row.get("component")): row for row in rows}
    for name, relative in lock_specs:
        lock = _read_lock(base, relative)
        runtime = by_name.get(name, {})
        lock_pid = integer(lock.get("pid"))
        runtime_pid = integer(runtime.get("main_pid"))
        version = text(lock.get("version"))
        runtime_version = text(runtime.get("status_version"))
        exists = bool(lock)
        match = bool(exists and lock_pid == runtime_pid and (not version or not runtime_version or version == runtime_version))
        state = "NORMAL" if match else "CHECK"
        lock_row = {
            "component": name,
            "path": relative,
            "state": state,
            "lock_pid": lock_pid,
            "runtime_pid": runtime_pid,
            "lock_version": version,
            "runtime_version": runtime_version,
            "match": match,
        }
        locks.append(lock_row)
        if state != "NORMAL":
            problems.append(dict(lock_row, reason="singleton lock와 runtime 불일치"))
    state = merge_states(*(row.get("state") for row in rows), *(row.get("state") for row in locks))
    return {"state": state, "components": rows, "locks": locks, "problems": problems}


_ERROR_TIME_RE = re.compile(r"^\[(\d{4}-\d{2}-\d{2}[ T]\d{2}:\d{2}:\d{2})(?:\s+KST)?\]")


def _error_events(path: Path, runtime_start: float, max_bytes: int = 1_500_000) -> Dict[str, Any]:
    raw = read_text(path, max_bytes=max_bytes)
    if not raw.strip():
        return {"current": [], "historical": [], "unscoped": [], "line_count": 0}
    events: List[Dict[str, Any]] = []
    current: Optional[Dict[str, Any]] = None
    unscoped_lines: List[str] = []
    for line in raw.splitlines():
        match = _ERROR_TIME_RE.match(line.strip())
        if match:
            if current:
                events.append(current)
            ts = parse_ts(match.group(1))
            current = {"ts": ts, "head": line.strip(), "lines": [line.strip()]}
        elif current is not None:
            current["lines"].append(line.strip())
        elif line.strip():
            unscoped_lines.append(line.strip())
    if current:
        events.append(current)
    current_events: List[Dict[str, Any]] = []
    historical: List[Dict[str, Any]] = []
    for event in events:
        compact = {
            "ts": event.get("ts"),
            "head": event.get("head"),
            "excerpt": " | ".join([x for x in event.get("lines", []) if x][:4])[:700],
        }
        if runtime_start > 0 and num(event.get("ts"), default=0.0) >= runtime_start - 0.001:
            current_events.append(compact)
        else:
            historical.append(compact)
    return {
        "current": current_events,
        "historical": historical,
        "unscoped": unscoped_lines[-20:],
        "line_count": len(raw.splitlines()),
    }


def _error_scope_summary(base: Path) -> Dict[str, Any]:
    specs = (
        ("main", "clean_brain_error.log"),
        ("strategy", "clean_strategy_worker_error.log"),
        ("paper", "paper_bot_error.log"),
        ("review", "clean_review_worker_error.log"),
        ("guard", "clean_guard_error.log"),
        ("ws", "ws_sidecar_error.log"),
        ("micro", "clean_bithumb_micro_error.log"),
        ("scanner", "clean_scanner_error.log"),
        ("feature", "clean_feature_error.log"),
        ("candle", "clean_candle_error.log"),
        ("market", "clean_market_regime_error.log"),
        ("orderflow", "clean_orderflow_error.log"),
        ("target", "clean_target_router_error.log"),
        ("risk", "clean_risk_error.log"),
    )
    rows: List[Dict[str, Any]] = []
    current_total = 0
    historical_total = 0
    unscoped_total = 0
    for owner, name in specs:
        path = base / name
        if not path.exists():
            continue
        runtime_start = _runtime_start_for_error_log(base, name)
        parsed = _error_events(path, runtime_start)
        current_count = len(parsed["current"])
        historical_count = len(parsed["historical"])
        unscoped_count = len(parsed["unscoped"])
        current_total += current_count
        historical_total += historical_count
        unscoped_total += unscoped_count
        if current_count:
            state = "FAIL"
        elif unscoped_count and runtime_start <= 0:
            state = "CHECK"
        elif unscoped_count and (file_age(path) or 0) < 300:
            state = "CHECK"
        else:
            state = "NORMAL"
        rows.append({
            "owner": owner,
            "path": name,
            "state": state,
            "runtime_start": runtime_start or None,
            "current_count": current_count,
            "historical_count": historical_count,
            "unscoped_line_count": unscoped_count,
            "last_current": parsed["current"][-1] if parsed["current"] else None,
            "last_historical": parsed["historical"][-1] if parsed["historical"] else None,
            "unscoped_sample": parsed["unscoped"][-3:],
            "age_sec": file_age(path),
        })
    state = "FAIL" if current_total else ("CHECK" if unscoped_total else "NORMAL")
    return {
        "state": state,
        "current_count": current_total,
        "historical_count": historical_total,
        "unscoped_line_count": unscoped_total,
        "logs": rows,
        "policy": "현재 runtime 시작 이후 오류만 현재 오류; 이전 오류는 보존 이력",
    }


def _segment_value(value: Any) -> Optional[float]:
    if isinstance(value, dict):
        return num(value.get("sec"), value.get("seconds"), value.get("duration_sec"), value.get("value"), default=None)
    return num(value, default=None)


def _append_segment(store: MutableMapping[str, List[float]], key: str, value: Any) -> None:
    parsed = _segment_value(value)
    if parsed is not None and parsed >= 0:
        store.setdefault(key, []).append(parsed)


def _timing_path_summary(base: Path, strategy_status: Mapping[str, Any], paper_status: Mapping[str, Any]) -> Dict[str, Any]:
    pipeline = read_json(base / "strategy_candidate_pipeline_commit_v1150.json", {}) or {}
    path_state = read_json(base / "paper_candidate_path_state_v1153.json", {}) or {}
    timing_status = read_json(base / "paper_timing_spine_status_v940.json", {}) or {}
    path_events = read_jsonl_tail(base / "paper_candidate_path_events_v1153.jsonl", 5000, max_bytes=16 * 1024 * 1024)
    timing_events = read_jsonl_tail(base / "paper_timing_spine_events_v940.jsonl", 1000, max_bytes=8 * 1024 * 1024)
    segment_values: Dict[str, List[float]] = {}

    # Strategy-owned exact file/generation timestamps.
    p_start = parse_ts(pipeline.get("cycle_started_ts"))
    p_s1 = parse_ts(pipeline.get("s1_hold_completed_ts_v1166"), pipeline.get("s1_hold_completed_ts_v1152"))
    p_candidate = parse_ts(pipeline.get("candidate_snapshot_completed_ts_v1166"), pipeline.get("candidate_snapshot_completed_ts_v1152"))
    p_priority = parse_ts(pipeline.get("priority_requests_completed_ts_v1166"), pipeline.get("priority_requests_completed_ts_v1152"))
    p_generation = parse_ts(pipeline.get("committed_handoff_completed_ts_v1158"), pipeline.get("completed_ts_v1152"))
    for key, later, earlier in (
        ("cycle_start_to_s1_commit_sec", p_s1, p_start),
        ("s1_commit_to_candidate_snapshot_sec", p_candidate, p_s1),
        ("candidate_snapshot_to_priority_commit_sec", p_priority, p_candidate),
        ("priority_commit_to_generation_commit_sec", p_generation, p_priority),
    ):
        if later > 0 and earlier > 0 and later >= earlier:
            _append_segment(segment_values, key, later - earlier)

    # Paper append-once event ledger: per candidate stage transitions.
    by_anchor: Dict[str, Dict[str, float]] = {}
    repeat_exposure = 0
    for event in path_events:
        anchor = text(event.get("trigger_event_key"), event.get("direct_decision_key"), event.get("candidate_key"))
        stage_name = text(event.get("stage")).upper()
        ts = parse_ts(event.get("recorded_at"), event.get("event_ts"))
        if anchor and stage_name and ts > 0:
            by_anchor.setdefault(anchor, {}).setdefault(stage_name, ts)
    records = mapping(path_state.get("records"))
    for record in records.values():
        if isinstance(record, dict):
            repeat_exposure += integer(record.get("repeat_exposure_count"))
    for stages in by_anchor.values():
        received = stages.get("PAPER_RECEIVED", 0.0)
        ready = stages.get("EXECUTION_DATA_READY", 0.0)
        opened = stages.get("OPEN_COMMITTED", 0.0)
        if received and ready and ready >= received:
            _append_segment(segment_values, "paper_received_to_execution_ready_sec", ready - received)
        if ready and opened and opened >= ready:
            _append_segment(segment_values, "execution_ready_to_open_commit_sec", opened - ready)
        if received and opened and opened >= received:
            _append_segment(segment_values, "paper_received_to_open_commit_sec", opened - received)

    # Paper selection/open timing owner.
    samples = sequence(timing_status.get("samples")) + timing_events
    for sample in samples:
        if not isinstance(sample, dict):
            continue
        for key in (
            "first_to_selected_delay_sec", "s1_to_selected_delay_sec", "trigger_to_selected_delay_sec",
            "selected_to_open_delay_sec", "first_to_open_delay_sec", "s1_to_open_delay_sec", "trigger_to_open_delay_sec",
        ):
            _append_segment(segment_values, key, sample.get(key))

    # Candidate transport samples may be sealed in current Paper status.
    sample_candidates: List[Any] = []
    for path in (
        "pick_stats.candidate_delay_path_samples_v1152",
        "pick_stats.time_path_samples_v1166",
        "paper_timing_path_samples_v1166",
        "candidate_time_path.samples",
    ):
        value = deep_get(paper_status, path, None)
        if isinstance(value, list):
            sample_candidates.extend(value)
    for sample in sample_candidates:
        if not isinstance(sample, dict):
            continue
        for family in ("exact_segments_v1153", "semantic_wait_segments_v1166", "transport_segments_v1166", "downstream_segments_v1166", "segments"):
            segment_map = mapping(sample.get(family))
            for key, value in segment_map.items():
                _append_segment(segment_values, str(key), value)

    segments: List[Dict[str, Any]] = []
    for key, values in segment_values.items():
        if not values:
            continue
        segments.append({
            "key": key,
            "n": len(values),
            "median_sec": round(float(statistics.median(values)), 3),
            "max_sec": round(max(values), 3),
            "avg_sec": round(sum(values) / len(values), 3),
        })
    segments.sort(key=lambda row: (row.get("median_sec") or 0.0, row.get("max_sec") or 0.0), reverse=True)
    exact_n = sum(1 for stages in by_anchor.values() if "PAPER_RECEIVED" in stages)
    state = "NORMAL" if segments and exact_n > 0 else "COLLECTING"
    slow: List[Dict[str, Any]] = []
    observation_limits = {
        "strategy_execution_handoff_sec": 15.0,
        "handoff_commit_to_paper_resolve_sec": 3.0,
        "selected_to_open_delay_sec": 5.0,
        "paper_received_to_open_commit_sec": 10.0,
    }
    direct = {
        "strategy_execution_handoff_sec": num(strategy_status.get("execution_handoff_elapsed_sec_v1179"), default=None),
        "strategy_full_cycle_sec": num(strategy_status.get("full_cycle_sec_v1031"), strategy_status.get("last_sec"), default=None),
        "paper_cycle_sec": num(paper_status.get("elapsed_sec"), default=None),
    }
    for key, value in direct.items():
        if value is not None:
            _append_segment(segment_values, key, value)
    segment_by_key = {row["key"]: row for row in segments}
    for key, limit in observation_limits.items():
        value = direct.get(key)
        if value is None:
            value = num(segment_by_key.get(key, {}).get("median_sec"), default=None)
        if value is not None and value > limit:
            slow.append({"key": key, "value_sec": value, "observe_limit_sec": limit, "blocking": False})
    if slow and state == "NORMAL":
        state = "CHECK"
    return {
        "state": state,
        "direct": direct,
        "segments": segments,
        "top_slowest": segments[:8],
        "path_event_count": len(path_events),
        "path_identity_count": len(by_anchor),
        "paper_received_identity_count": exact_n,
        "repeat_exposure_count": repeat_exposure,
        "slow_observations": slow,
        "diagnostic_only": True,
        "blocking_change": False,
    }


def _paper_funnel_summary(paper_status: Mapping[str, Any]) -> Dict[str, Any]:
    pick = mapping(paper_status.get("pick_stats"))
    audit = mapping(paper_status.get("paper_audit_only_summary_v1175"))
    actual = mapping(audit.get("integrity_block_counts"))
    diagnostic = mapping(audit.get("audit_only_counts"))
    s1_seen = integer(pick.get("s1_seen"))
    selected = integer(pick.get("selected_s1"))
    opened = integer(paper_status.get("opened_this_cycle"))
    closed = integer(paper_status.get("closed_this_cycle"))
    accounted = integer(pick.get("paper_funnel_accounted_v1102"))
    unclassified = integer(pick.get("paper_funnel_unclassified_v1102"), default=max(0, s1_seen - accounted))
    balance = pick.get("paper_funnel_balance_ok_v1102")
    if balance is False or unclassified > 0:
        state = "CHECK"
    elif balance is True:
        state = "NORMAL"
    else:
        state = "COLLECTING"
    return {
        "state": state,
        "candidate_seen": _value_count(paper_status, "pick_stats.latest_count", "latest_count"),
        "s1_seen": s1_seen,
        "selected": selected,
        "opened": opened,
        "closed": closed,
        "accounted": accounted,
        "unclassified": unclassified,
        "balance_ok": balance,
        "terminal_counts": mapping(pick.get("paper_funnel_terminal_counts_v1102")),
        "actual_integrity_exclusions": actual,
        "audit_only_findings": diagnostic,
        "late_safety_actual_block_count": integer(audit.get("actual_late_safety_block_count")),
        "policy": "진단값은 표시만 하며 차단하지 않음; exact·관찰전용·중복·원장 무결성만 유지",
        "blocking_change": False,
    }


def _open_monitor_summary(base: Path, at: float) -> Dict[str, Any]:
    path = base / "paper_bot_open.json"
    obj = read_json(path, {}) or {}
    rows = rows_from(obj)
    tickers: Counter[str] = Counter()
    pos_ids: Counter[str] = Counter()
    decision_missing = structure_missing = price_missing = 0
    mfe_missing = mae_missing = giveback_missing = 0
    target_touch = invalid_touch = 0
    monitor_ts: List[float] = []
    for row in rows:
        symbol = ticker(row.get("ticker") or row.get("market") or row.get("symbol"))
        if symbol:
            tickers[symbol] += 1
        pos = text(row.get("pos_id"), row.get("paper_pos_id_v926"), row.get("event_id"))
        if pos:
            pos_ids[pos] += 1
        if not decision_key(row):
            decision_missing += 1
        sources = structure_sources(row)
        if any(sources.get(key) in (None, 0, 0.0, "") for key in ("trigger_price", "invalid_price", "target_price")):
            structure_missing += 1
        if row_price(row) is None:
            price_missing += 1
        if num(row.get("mfe_pct_v983"), row.get("peak_pct"), default=None) is None:
            mfe_missing += 1
        if num(row.get("mae_pct_v983"), row.get("trough_pct"), default=None) is None:
            mae_missing += 1
        if num(row.get("giveback_pct_v983"), row.get("giveback_pct"), default=None) is None:
            giveback_missing += 1
        if parse_ts(row.get("first_target_touch_ts_v983")) > 0:
            target_touch += 1
        if parse_ts(row.get("first_invalid_touch_ts_v983")) > 0:
            invalid_touch += 1
        ts = parse_ts(
            row.get("last_checked_ts"), row.get("last_price_ts"), row.get("current_price_ts"),
            row.get("updated_ts"), row.get("paper_last_monitor_ts"),
        )
        if ts > 0:
            monitor_ts.append(ts)
    duplicate_tickers = {key: count for key, count in tickers.items() if count > 1}
    duplicate_pos_ids = {key: count for key, count in pos_ids.items() if count > 1}
    monitor_age = max(0.0, at - max(monitor_ts)) if monitor_ts else None
    coverage_missing = decision_missing + structure_missing + price_missing + mfe_missing + mae_missing + giveback_missing
    if duplicate_tickers or duplicate_pos_ids:
        state = "FAIL"
    elif rows and coverage_missing:
        state = "PARTIAL"
    elif rows and monitor_age is None:
        state = "COLLECTING"
    else:
        state = "NORMAL"
    return {
        "state": state,
        "open_count": len(rows),
        "file_age_sec": file_age(path, at),
        "decision_key_missing": decision_missing,
        "structure_contract_missing": structure_missing,
        "price_missing": price_missing,
        "mfe_missing": mfe_missing,
        "mae_missing": mae_missing,
        "giveback_missing": giveback_missing,
        "target_touched_still_open": target_touch,
        "invalid_touched_still_open": invalid_touch,
        "latest_monitor_age_sec": monitor_age,
        "duplicate_tickers": duplicate_tickers,
        "duplicate_pos_ids": duplicate_pos_ids,
        "contract_coverage_pct": round((1.0 - coverage_missing / max(1, len(rows) * 6)) * 100.0, 3) if rows else 100.0,
    }


def _ledger_summary(base: Path, at: float, performance: Mapping[str, Any], paper_status: Mapping[str, Any], candidate_standard: Mapping[str, Any]) -> Dict[str, Any]:
    counts = mapping(performance.get("counts"))
    heartbeat = mapping(paper_status.get("paper_performance_semantic_heartbeat_v1117"))
    snapshot_id = text(performance.get("snapshot_id"))
    candidate_perf = mapping(candidate_standard.get("performance"))
    candidate_snapshot_id = text(candidate_perf.get("snapshot_id"))
    files = {
        "open": _file_evidence(base / "paper_bot_open.json", at),
        "closed": _file_evidence(base / "paper_bot_closed.jsonl", at),
        "decision": _file_evidence(base / "paper_decision_state_v926.json", at),
        "closed_append_status": _file_evidence(base / "paper_closed_append_status_v925.json", at),
        "performance": _file_evidence(base / "canonical_performance_snapshot_v987.json", at),
        "change_ledger": _file_evidence(find_ledger(base, "change") or (base / "change_verify_ledger.jsonl"), at),
        "issue_ledger": _file_evidence(find_ledger(base, "issue") or (base / "issue_ledger.jsonl"), at),
    }
    duplicate = integer(counts.get("duplicate_closed_rows"), counts.get("duplicate_rows"), counts.get("duplicates"))
    missing_key = integer(counts.get("missing_decision_key"), counts.get("decision_key_missing"), counts.get("missing_key"))
    unlinked = integer(counts.get("decision_not_closed_or_missing"), counts.get("decision_unlinked"), counts.get("unlinked"))
    bad_json = integer(counts.get("bad_json_rows"))
    semantic_current = heartbeat.get("semantic_current")
    performance_age = file_age(base / "canonical_performance_snapshot_v987.json", at)
    snapshot_match = not candidate_snapshot_id or not snapshot_id or candidate_snapshot_id == snapshot_id
    missing_core = [name for name in ("open", "closed", "decision", "performance") if not files[name].get("exists")]
    if missing_core:
        state = "FAIL"
    elif bad_json or missing_key or unlinked or duplicate:
        state = "PARTIAL"
    elif semantic_current is False:
        state = "CHECK"
    elif not snapshot_match:
        state = "CHECK"
    else:
        state = "NORMAL"
    return {
        "state": state,
        "snapshot_id": snapshot_id,
        "candidate_performance_snapshot_id": candidate_snapshot_id,
        "snapshot_match": snapshot_match,
        "performance_age_sec": performance_age,
        "semantic_current": semantic_current,
        "heartbeat_state": heartbeat.get("state"),
        "raw_rows": integer(counts.get("raw_ledger_rows")),
        "exact_rows": integer(counts.get("exact_unique_closed"), counts.get("included")),
        "duplicates": duplicate,
        "missing_decision_key": missing_key,
        "unlinked": unlinked,
        "bad_json": bad_json,
        "files": files,
        "missing_core_files": missing_core,
    }


def _command_delivery_summary(base: Path, at: float, main_status: Mapping[str, Any]) -> Dict[str, Any]:
    summary_path = base / "command_summary_status_v1187.json"
    summary = read_json(summary_path, {}) or {}
    telegram_state = text(main_status.get("telegram_state"), default="UNKNOWN").lower()
    command_count = integer(main_status.get("command_count"))
    summary_age = file_age(summary_path, at)
    summary_ok = summary.get("ok") is True
    txt_count = integer(summary.get("txt_count"))
    if telegram_state not in {"running", "ready", "polling", "polling_started"}:
        state = "CHECK"
    elif command_count <= 0:
        state = "CHECK"
    elif summary and (not summary_ok or txt_count != 1):
        state = "CHECK"
    else:
        state = "NORMAL" if summary else "COLLECTING"
    return {
        "state": state,
        "telegram_state": telegram_state,
        "telegram_error": main_status.get("telegram_error"),
        "command_count": command_count,
        "scan_running": main_status.get("scan_running"),
        "scan_stage": main_status.get("scan_last_stage") or main_status.get("phase"),
        "summary_exists": bool(summary),
        "summary_age_sec": summary_age,
        "summary_ok": summary_ok if summary else None,
        "txt_count": txt_count if summary else None,
        "render_sum_sec": num(summary.get("render_sum_sec"), default=None),
        "delivery_total_sec": num(summary.get("delivery_total_sec"), default=None),
        "summary_status": summary.get("status"),
        "snapshot_id": summary.get("snapshot_id"),
    }


def _resource_summary(base: Path, guard_runtime: Mapping[str, Any]) -> Dict[str, Any]:
    server = mapping(guard_runtime.get("server"))
    components = mapping(guard_runtime.get("components"))
    if not server:
        try:
            stat = os.statvfs(base)
            server = {
                "disk_free_gb": stat.f_bavail * stat.f_frsize / 1024 ** 3,
                "disk_used_pct": (1.0 - stat.f_bavail / max(1, stat.f_blocks)) * 100.0,
            }
        except OSError:
            server = {}
    disk_free_gb = num(server.get("disk_free_gb"), default=None)
    disk_used_pct = num(server.get("disk_used_pct"), default=None)
    mem_used_pct = num(server.get("mem_used_pct"), default=None)
    if disk_free_gb is not None and disk_free_gb < 1.0:
        state = "FAIL"
    elif (disk_free_gb is not None and disk_free_gb < 3.0) or (disk_used_pct is not None and disk_used_pct > 90.0):
        state = "CHECK"
    else:
        state = "NORMAL" if server else "CHECK"
    slow_cpu = []
    high_rss = []
    for name, row in components.items():
        if not isinstance(row, dict):
            continue
        cpu = num(row.get("cpu_pct"), default=0.0) or 0.0
        rss = num(row.get("rss_mb"), default=0.0) or 0.0
        if cpu >= 80.0:
            slow_cpu.append({"component": name, "cpu_pct": cpu})
        if rss >= 1024.0:
            high_rss.append({"component": name, "rss_mb": rss})
    return {
        "state": state,
        "server": server,
        "disk_free_gb": disk_free_gb,
        "disk_used_pct": disk_used_pct,
        "mem_used_pct": mem_used_pct,
        "slow_cpu": slow_cpu,
        "high_rss": high_rss,
        "io_top": sequence(guard_runtime.get("io_top_components_v1011"))[:8],
    }



def _artifact_chain_summary(
    base: Path, at: float, pipeline: Mapping[str, Any], request: Mapping[str, Any],
    review: Mapping[str, Any], standard: Mapping[str, Any], performance: Mapping[str, Any],
) -> Dict[str, Any]:
    """Audit the canonical file and cycle/commit chain without recalculation."""
    source = mapping(review.get("source"))
    expected_cycle = text(pipeline.get("cycle_id"))
    expected_commit = text(pipeline.get("candidate_commit_id"))
    handoff_text = text(pipeline.get("committed_handoff_file_v1158"))
    handoff_path = Path(handoff_text) if handoff_text else base / "strategy_paper_handoff_committed_v1158.json"
    if not handoff_path.is_absolute():
        handoff_path = base / handoff_path
    handoff = read_json(handoff_path, {}) or {}
    files = {
        "strategy_pipeline": _file_evidence(base / "strategy_candidate_pipeline_commit_v1150.json", at),
        "strategy_handoff": _file_evidence(handoff_path, at),
        "review_request": _file_evidence(base / "review_observation_request_v1181.json", at),
        "review_snapshot": _file_evidence(base / "canonical_review_snapshot_v1181.json", at),
        "candidate_standard": _file_evidence(base / "canonical_candidate_standard_v1181.json", at),
        "paper_status": _file_evidence(base / "paper_bot_status.json", at),
        "open": _file_evidence(base / "paper_bot_open.json", at),
        "closed_append": _file_evidence(base / "paper_closed_append_status_v925.json", at),
        "performance": _file_evidence(base / "canonical_performance_snapshot_v987.json", at),
    }
    id_rows = []
    for name, obj in (
        ("strategy_pipeline", pipeline),
        ("strategy_handoff", handoff),
        ("review_request", request),
        ("review_snapshot", source),
    ):
        cycle = text(obj.get("cycle_id"), obj.get("pipeline_cycle_id"), obj.get("candidate_pipeline_cycle_id_v1150"))
        commit = text(obj.get("candidate_commit_id"), obj.get("candidate_commit_id_v1150"))
        if name == "strategy_pipeline":
            cycle, commit = expected_cycle, expected_commit
        if name == "strategy_handoff":
            cycle = text(handoff.get("cycle_id"))
            commit = text(handoff.get("candidate_commit_id"))
        match = bool(expected_cycle and expected_commit and cycle == expected_cycle and commit == expected_commit)
        if name == "strategy_pipeline":
            match = bool(expected_cycle and expected_commit)
        state = "NORMAL" if match else ("FAIL" if cycle or commit else "CHECK")
        id_rows.append({"artifact": name, "state": state, "cycle_id": cycle or None, "candidate_commit_id": commit or None, "match_current": match})
    missing = [name for name, row in files.items() if not row.get("exists")]
    mismatched = [row["artifact"] for row in id_rows if row["state"] == "FAIL"]
    missing_ids = [row["artifact"] for row in id_rows if row["state"] == "CHECK"]
    stale = [name for name, row in files.items() if row.get("age_sec") is not None and num(row.get("age_sec"), default=0.0) > 900.0 and name not in {"open"}]
    if mismatched:
        state = "FAIL"
    elif missing or missing_ids or stale:
        state = "CHECK"
    else:
        state = "NORMAL"
    return {
        "state": state,
        "expected_cycle_id": expected_cycle or None,
        "expected_candidate_commit_id": expected_commit or None,
        "files": files,
        "id_chain": id_rows,
        "missing_files": missing,
        "missing_id_evidence": missing_ids,
        "mismatched_ids": mismatched,
        "stale_artifacts": stale,
        "performance_snapshot_id": performance.get("snapshot_id"),
        "no_stale_fallback": True,
    }


def _storage_hygiene_summary(base: Path, at: float) -> Dict[str, Any]:
    """Bounded top-level storage audit; never deletes or rewrites anything."""
    counts = Counter()
    bytes_by_kind: Counter[str] = Counter()
    abandoned_temp: List[Dict[str, Any]] = []
    try:
        entries = list(base.iterdir())[:5000]
    except OSError:
        entries = []
    for path in entries:
        name = path.name
        kind = "other"
        if name.startswith(".bundle_unpack_") or name.startswith(".tmp") or name.startswith("tmp_"):
            kind = "temporary"
        elif "backup" in name.lower() or name.endswith(".bak"):
            kind = "backup"
        elif name.endswith(".zip"):
            kind = "zip"
        elif name == "__pycache__" or name.endswith(".pyc"):
            kind = "pycache"
        elif name.endswith(".log") or name.endswith(".jsonl"):
            kind = "log_or_ledger"
        counts[kind] += 1
        try:
            if path.is_file():
                bytes_by_kind[kind] += path.stat().st_size
            age = max(0.0, at - path.stat().st_mtime)
        except OSError:
            age = None
        if kind == "temporary" and age is not None and age > 300.0:
            abandoned_temp.append({"name": name, "age_sec": round(age, 3), "is_dir": path.is_dir()})
    state = "CHECK" if abandoned_temp else "NORMAL"
    return {
        "state": state,
        "counts": dict(counts),
        "bytes_by_kind": dict(bytes_by_kind),
        "abandoned_temp": abandoned_temp[:30],
        "scanned_top_level": len(entries),
        "read_only": True,
        "deleted": 0,
    }

def _problem(code: str, state: str, owner: str, reason: str, impact: str, *, blocking: bool = False) -> Dict[str, Any]:
    return {
        "code": code,
        "state": normalize_state(state),
        "owner": owner,
        "reason": reason,
        "impact": impact,
        "blocking": bool(blocking),
        "diagnostic_only": not bool(blocking),
    }


def build_ops_snapshot(base: Path) -> Dict[str, Any]:
    """Build the evidence-complete, read-only operations map.

    No trading gate, entry limit, exit condition, or ledger row is changed here.
    Missing evidence is CHECK/COLLECTING, never silently NORMAL.
    """
    paths = SpinePaths(base)
    at = now_ts()
    workers = {
        "scanner": _status_record("전체시장 Scanner", paths.scanner_status, "scanner_worker", 120.0, at),
        "feature": _status_record("Feature 품질값", paths.feature_status, "feature_worker", 120.0, at),
        "candle": _status_record("Candle 완료봉 구조", paths.candle_status, "candle_worker", 180.0, at),
        "market": _status_record("Market 장세", paths.market_status, "market_regime_worker", 180.0, at),
        "orderflow": _status_record("Orderflow 실행비용", paths.orderflow_status, "orderflow_worker", 120.0, at),
        "target": _status_record("Target Router 정보배차", paths.target_status, "target_router_worker", 120.0, at),
        "strategy": _status_record("Strategy 후보·진입계약", paths.strategy_status, "strategy_worker", 180.0, at),
        "paper": _status_record("Paper 실행 core", paths.paper_status, "paper_bot", 120.0, at),
        "review": _status_record("Review 복기·성과", paths.review_status, "review_worker", 120.0, at),
        "main": _status_record("Main 표시", paths.main_status, "main_bot", 120.0, at),
        "guard": _status_record("Guard runtime", paths.guard_status, "guard", 180.0, at),
        "risk": _status_record("Risk 계약", paths.risk_status, "risk_worker", 180.0, at),
        "ws": _status_record("WS 실시간가격", paths.ws_status, "ws_sidecar", 120.0, at),
        "micro": _status_record("Micro 호가·체결", paths.micro_status, "micro_sidecar", 120.0, at),
    }
    request = read_json(paths.review_request, {}) or {}
    review = read_json(paths.review_snapshot, {}) or {}
    standard = read_json(paths.candidate_standard, {}) or {}
    strategy_status = mapping(workers["strategy"].get("raw"))
    paper_status = mapping(workers["paper"].get("raw"))
    main_status = mapping(workers["main"].get("raw"))
    guard_runtime = mapping(workers["guard"].get("raw"))
    performance = read_json(paths.performance, {}) or {}
    pipeline = read_json(base / "strategy_candidate_pipeline_commit_v1150.json", {}) or {}
    candidate = mapping(review.get("candidate"))
    source = mapping(review.get("source"))

    current_pipeline_id = text(pipeline.get("cycle_id"), source.get("pipeline_cycle_id"), request.get("pipeline_cycle_id"), request.get("candidate_pipeline_cycle_id_v1150"))
    current_commit_id = text(pipeline.get("candidate_commit_id"), source.get("candidate_commit_id"), request.get("candidate_commit_id"), request.get("candidate_commit_id_v1150"))
    last_complete = mapping(pipeline.get("last_complete_cycle_v1152"))
    strategy_rows = integer(pipeline.get("candidate_rows"), candidate.get("total"), request.get("candidate_rows"), strategy_status.get("paper_latest_count"))
    s1_count = integer(pipeline.get("s1_hold_count"), candidate.get("s1"), strategy_status.get("s1_count"))
    paper_received = integer(
        deep_get(paper_status, "pick_stats.paper_generation_candidate_count_v1158"),
        deep_get(paper_status, "pick_stats.paper_candidates_seen"),
        deep_get(paper_status, "pick_stats.latest_count"),
        paper_status.get("latest_count"),
        default=0,
    )
    pipeline_state_raw = text(pipeline.get("state"), default="CHECK").upper()
    if pipeline.get("current_cycle_in_progress_v1152") is True:
        current_cycle_state = "COLLECTING"
    elif pipeline_state_raw == "NORMAL" and pipeline.get("complete") is True and current_pipeline_id and current_commit_id:
        current_cycle_state = "NORMAL"
    elif pipeline_state_raw == "FAIL":
        current_cycle_state = "FAIL"
    else:
        current_cycle_state = "CHECK"

    timing_path = _timing_path_summary(base, strategy_status, paper_status)
    funnel = _paper_funnel_summary(paper_status)
    open_monitor = _open_monitor_summary(base, at)
    ledger = _ledger_summary(base, at, performance, paper_status, standard)
    errors = _error_scope_summary(base)
    runtime = _runtime_contract(base, guard_runtime, workers)
    commands = _command_delivery_summary(base, at, main_status)
    resources = _resource_summary(base, guard_runtime)
    artifact_chain = _artifact_chain_summary(base, at, pipeline, request, review, standard, performance)
    storage_hygiene = _storage_hygiene_summary(base, at)

    stage_rows: List[Dict[str, Any]] = []

    def add(index: int, key: str, label: str, state: str, owner: str, input_count: Any = None,
            output_count: Any = None, reason: str = "", duration_sec: Any = None,
            evidence_age_sec: Any = None, evidence: Optional[Mapping[str, Any]] = None) -> None:
        stage_rows.append({
            "index": index, "key": key, "label": label, "state": normalize_state(state), "owner": owner,
            "input": input_count, "output": output_count, "reason": reason,
            "duration_sec": num(duration_sec, default=None), "evidence_age_sec": num(evidence_age_sec, default=None),
            "evidence": dict(evidence or {}),
        })

    exchange_state = merge_states(workers["ws"]["state"], workers["micro"]["state"])
    add(1, "exchange", "거래소·네트워크 수신", exchange_state, "WS/Micro",
        output_count=integer(deep_get(workers["micro"], "raw.target_count"), deep_get(workers["ws"], "raw.cache_count")),
        reason=workers["ws"].get("reason") or workers["micro"].get("reason"),
        duration_sec=num(deep_get(workers["micro"], "raw.last_sec"), deep_get(workers["ws"], "raw.last_sec"), default=None),
        evidence={"ws_age_sec": workers["ws"].get("age_sec"), "micro_age_sec": workers["micro"].get("age_sec")})
    for index, key, label, owner in (
        (2, "scanner", "전체시장 Scanner", "scanner_worker"),
        (3, "feature", "Feature 품질값", "feature_worker"),
        (4, "candle", "Candle 완료봉 구조", "candle_worker"),
        (5, "market", "Market 장세", "market_regime_worker"),
        (6, "orderflow", "Orderflow 실행비용", "orderflow_worker"),
        (7, "target", "Target Router 정보배차", "target_router_worker"),
    ):
        raw = mapping(workers[key].get("raw"))
        add(index, key, label, workers[key]["state"], owner,
            input_count=integer(raw.get("input_count"), raw.get("source_count"), default=0) or None,
            output_count=integer(raw.get("row_count"), raw.get("target_count"), raw.get("pool_count"), default=0) or None,
            reason=workers[key].get("reason") or "",
            duration_sec=num(raw.get("last_sec"), raw.get("cycle_sec"), default=None),
            evidence_age_sec=workers[key].get("age_sec"),
            evidence={"phase": workers[key].get("phase"), "version": workers[key].get("version")})
    add(8, "strategy", "Strategy 자료합류·구조판정", workers["strategy"]["state"], "strategy_worker",
        output_count=strategy_rows, reason=workers["strategy"].get("reason") or "",
        duration_sec=num(strategy_status.get("full_cycle_sec_v1031"), strategy_status.get("last_sec"), default=None),
        evidence_age_sec=workers["strategy"].get("age_sec"),
        evidence={"phase": workers["strategy"].get("phase"), "profile_top": first_path(strategy_status, ("phase_profile_v1032.top", "profile.top"), None)})
    candidate_state = normalize_state(standard.get("state"), default=current_cycle_state)
    add(9, "gate", "품질 Gate·Rank", merge_states(current_cycle_state, candidate_state), "strategy_worker",
        input_count=strategy_rows, output_count=strategy_rows,
        reason="후보 기준판 증거 누락" if candidate_state != "NORMAL" else "",
        evidence={"candidate_standard_state": standard.get("state"), "missing": standard.get("missing") or []})
    handoff_complete = bool(pipeline.get("all_required_commits_v1150") is True and pipeline.get("committed_handoff_file_v1158"))
    handoff_state = merge_states(current_cycle_state, "NORMAL" if handoff_complete else "CHECK")
    add(10, "handoff", "S1·전체후보·우선요청 묶음 전달", handoff_state, "strategy_worker",
        input_count=strategy_rows, output_count=s1_count,
        reason="필수 저장·generation 봉인 증거 불완전" if not handoff_complete else "",
        duration_sec=num(strategy_status.get("execution_handoff_elapsed_sec_v1179"), default=None),
        evidence={
            "pipeline_cycle_id": current_pipeline_id, "candidate_commit_id": current_commit_id,
            "s1_hold_count": pipeline.get("s1_hold_count"), "candidate_rows": pipeline.get("candidate_rows"),
            "priority_request_count": pipeline.get("priority_request_count"), "all_required_commits": pipeline.get("all_required_commits_v1150"),
        })
    add(11, "paper_read", "Paper generation 확인·후보 판독", merge_states(workers["paper"]["state"], timing_path["state"]), "paper_bot",
        input_count=s1_count, output_count=paper_received, reason=workers["paper"].get("reason") or "",
        evidence_age_sec=workers["paper"].get("age_sec"),
        evidence={"paper_received_identity_count": timing_path.get("paper_received_identity_count"), "repeat_exposure_count": timing_path.get("repeat_exposure_count")})
    add(12, "paper_safety", "Paper exact·중복·원장 무결성", funnel["state"], "paper_bot",
        input_count=funnel.get("s1_seen"), output_count=funnel.get("accounted"),
        reason="미분류 후보 있음" if funnel.get("unclassified") else "",
        evidence={"actual_exclusions": funnel.get("actual_integrity_exclusions"), "audit_only": funnel.get("audit_only_findings"), "blocking_change": False})
    add(13, "selector", "Paper Selector", funnel["state"], "paper_bot",
        input_count=funnel.get("s1_seen"), output_count=funnel.get("selected"),
        evidence={"terminal_counts": funnel.get("terminal_counts"), "balance_ok": funnel.get("balance_ok")})
    open_commit_state = merge_states(workers["paper"]["state"], "CHECK" if funnel.get("selected", 0) > funnel.get("opened", 0) and funnel.get("unclassified", 0) else "NORMAL")
    add(14, "open", "OPEN Writer·Decision 묶음 Commit", open_commit_state, "paper_bot",
        input_count=funnel.get("selected"), output_count=funnel.get("opened"),
        evidence={"open_snapshot_write_count": first_path(paper_status, ("open_batch_snapshot_write_count_v1180", "open_snapshot_write_count"), None),
                  "decision_write_count": first_path(paper_status, ("open_batch_decision_write_count_v1180", "decision_write_count"), None),
                  "rollback_count": first_path(paper_status, ("open_batch_rollback_count_v1180", "rollback_count"), None)})
    add(15, "exit", "보유·가격감시·MFE/MAE·접촉시각", open_monitor["state"], "paper_bot",
        input_count=open_monitor.get("open_count"), output_count=open_monitor.get("open_count"),
        reason="OPEN 증거 일부 누락" if open_monitor["state"] in {"PARTIAL", "CHECK"} else "",
        evidence=open_monitor)
    closed_commit_status = read_json(base / "paper_closed_append_status_v925.json", {}) or {}
    closed_commit_state = normalize_state(closed_commit_status.get("state"), default="COLLECTING" if not closed_commit_status else "NORMAL")
    if text(closed_commit_status.get("last_error"), closed_commit_status.get("error")):
        closed_commit_state = "FAIL"
    add(16, "closed", "CLOSED append→decision→OPEN 제거→알림", closed_commit_state, "paper_bot",
        input_count=funnel.get("closed"), output_count=funnel.get("closed"),
        reason=text(closed_commit_status.get("last_error"), closed_commit_status.get("error")),
        evidence={"status": closed_commit_status.get("state"), "age_sec": file_age(base / "paper_closed_append_status_v925.json", at),
                  "append_verified": closed_commit_status.get("append_verified"), "decision_saved": closed_commit_status.get("decision_saved"),
                  "open_removed": closed_commit_status.get("open_removed"), "notification_sent": closed_commit_status.get("notification_sent")})
    add(17, "performance", "Canonical Performance·CLOSED+OPEN", ledger["state"], "paper performance owner",
        input_count=ledger.get("raw_rows"), output_count=ledger.get("exact_rows"),
        reason="원장·snapshot 증거 확인 필요" if ledger["state"] != "NORMAL" else "",
        evidence={"snapshot_id": ledger.get("snapshot_id"), "semantic_current": ledger.get("semantic_current"),
                  "duplicates": ledger.get("duplicates"), "missing_key": ledger.get("missing_decision_key"), "unlinked": ledger.get("unlinked")})
    add(18, "review", "Review·후보기준·복기", merge_states(workers["review"]["state"], candidate_state), "review_worker",
        input_count=strategy_rows, output_count=integer(candidate.get("total")), reason=workers["review"].get("reason") or "",
        duration_sec=num(mapping(workers["review"].get("raw")).get("last_cycle_sec"), mapping(workers["review"].get("raw")).get("last_sec"), default=None),
        evidence={"candidate_standard_state": standard.get("state"), "snapshot_id": standard.get("snapshot_id")})
    add(19, "main", "Main 명령·Telegram·TXT 전송", merge_states(workers["main"]["state"], commands["state"]), "main_bot",
        reason=workers["main"].get("reason") or ("명령·전송 증거 확인 필요" if commands["state"] != "NORMAL" else ""),
        duration_sec=commands.get("delivery_total_sec"), evidence=commands)
    add(20, "guard", "Guard runtime·버전·PID·지도 writer", merge_states(workers["guard"]["state"], runtime["state"], resources["state"]), "guard",
        reason="runtime·자원 증거 확인 필요" if merge_states(runtime["state"], resources["state"]) != "NORMAL" else "",
        evidence={"runtime_state": runtime.get("state"), "resource_state": resources.get("state"), "disk_free_gb": resources.get("disk_free_gb")})

    problems: List[Dict[str, Any]] = []
    for row in stage_rows:
        if row["state"] != "NORMAL":
            problems.append(_problem(
                f"FLOW-{row['index']:02d}-{row['key'].upper()}", row["state"], row["owner"],
                row.get("reason") or f"{row['label']} 증거 {row['state']}",
                "해당 단계의 처리·시간·증거를 확인해야 함; 신규 차단은 추가하지 않음",
            ))
    for item in timing_path.get("slow_observations") or []:
        problems.append(_problem(
            f"TIME-{str(item.get('key')).upper()}", "CHECK", "timing owner",
            f"{item.get('key')} {item.get('value_sec')}초 / 관찰기준 {item.get('observe_limit_sec')}초",
            "속도 원인수리 대상; 매매 차단 없음",
        ))
    if errors.get("current_count"):
        problems.append(_problem("RUNTIME-CURRENT-ERROR", "FAIL", "runtime owners", f"현재 runtime 오류 {errors.get('current_count')}건", "오류 owner 수리 필요; 자동 차단 추가 없음"))
    elif errors.get("unscoped_line_count"):
        problems.append(_problem("RUNTIME-ERROR-SCOPE-CHECK", "CHECK", "runtime owners", f"시각 범위 불명 오류 줄 {errors.get('unscoped_line_count')}개", "현재·과거 구분 증거 보완 필요"))
    if ledger.get("state") != "NORMAL":
        problems.append(_problem("LEDGER-CANONICAL-CHECK", ledger["state"], "paper performance owner", "원장·snapshot 연결 확인 필요", "성과·OPEN 표시 신뢰도 확인"))
    if resources.get("state") != "NORMAL":
        problems.append(_problem("RESOURCE-CHECK", resources["state"], "guard", f"디스크 남음 {resources.get('disk_free_gb')}GB", "자원 증가 owner 추적; 거래기준 변경 없음"))
    if artifact_chain.get("state") != "NORMAL":
        problems.append(_problem("ARTIFACT-CHAIN-CHECK", artifact_chain["state"], "canonical owners", f"파일 누락 {artifact_chain.get('missing_files')} / ID 불일치 {artifact_chain.get('mismatched_ids')} / ID 누락 {artifact_chain.get('missing_id_evidence')}", "cycle·commit·snapshot 연결 증거 확인; fallback 사용 없음"))
    if storage_hygiene.get("state") != "NORMAL":
        problems.append(_problem("STORAGE-TEMP-CHECK", storage_hygiene["state"], "guard", f"오래 남은 임시경로 {len(storage_hygiene.get('abandoned_temp') or [])}개", "임시폴더 생성·정리 owner 추적; 자동삭제 없음"))

    evidence_groups = {
        "data_intake": merge_states(*(workers[key]["state"] for key in ("ws", "micro", "scanner", "feature", "candle", "market", "orderflow", "target"))),
        "candidate_pipeline": merge_states(current_cycle_state, candidate_state, stage_rows[9]["state"]),
        "paper_execution": merge_states(funnel["state"], open_monitor["state"], closed_commit_state),
        "ledger_performance": ledger["state"],
        "runtime_errors": errors["state"],
        "runtime_deploy": runtime["state"],
        "resources": resources["state"],
        "commands_delivery": commands["state"],
        "artifact_chain": artifact_chain["state"],
        "storage_hygiene": storage_hygiene["state"],
    }
    overall = merge_states(*(row.get("state") for row in stage_rows), *(evidence_groups.values()))
    state_counts = Counter(normalize_state(row.get("state")) for row in stage_rows)

    snapshot: Dict[str, Any] = {
        "schema": "ops_spine_snapshot_v1188",
        "version": "guard_map_v1188",
        "generated_ts": at,
        "generated_text": now_text(at),
        "owner": "guard_evidence_complete_ops_map_writer_v1188",
        "overall_state": overall,
        "state_counts": dict(state_counts),
        "auto_buy": False,
        "strategy_mode": STRATEGY_MODE,
        "diagnostic_only": True,
        "new_blockers_added": False,
        "current_cycle": {
            "state": current_cycle_state,
            "pipeline_cycle_id": current_pipeline_id,
            "candidate_commit_id": current_commit_id,
            "candidate_rows": strategy_rows,
            "s1_count": s1_count,
            "paper_received": paper_received,
            "pipeline_progress": pipeline.get("progress_state_v1152"),
            "source_age_sec": file_age(base / "strategy_candidate_pipeline_commit_v1150.json", at),
        },
        "last_completed_cycle": {
            "pipeline_cycle_id": last_complete.get("cycle_id"),
            "candidate_commit_id": last_complete.get("candidate_commit_id"),
            "state": last_complete.get("state") or "CHECK",
            "completed_ts": last_complete.get("completed_ts"),
            "candidate_rows": last_complete.get("candidate_rows"),
            "s1_count": last_complete.get("s1_hold_count"),
        },
        "stages": stage_rows,
        "evidence_groups": evidence_groups,
        "problems": problems,
        "timing": {
            "strategy_execution_handoff_sec": timing_path["direct"].get("strategy_execution_handoff_sec"),
            "strategy_full_cycle_sec": timing_path["direct"].get("strategy_full_cycle_sec"),
            "paper_fast_cycle_sec": timing_path["direct"].get("paper_cycle_sec"),
            "review_cycle_sec": num(mapping(workers["review"].get("raw")).get("last_cycle_sec"), default=None),
        },
        "timing_path": timing_path,
        "paper_funnel": funnel,
        "open_exit_monitor": open_monitor,
        "ledger_performance": ledger,
        "errors": errors,
        "runtime_deploy": runtime,
        "resources": resources,
        "commands_delivery": commands,
        "artifact_chain": artifact_chain,
        "storage_hygiene": storage_hygiene,
        "candidate_standard": {
            "state": standard.get("state"),
            "snapshot_id": standard.get("snapshot_id"),
            "missing": standard.get("missing") or [],
        },
        "workers": {key: {field: value for field, value in item.items() if field != "raw"} for key, item in workers.items()},
        "invariants": {
            "candidate_formula_changed": False,
            "trigger_changed": False,
            "invalid_changed": False,
            "target_changed": False,
            "rr_changed": False,
            "exit_contract_changed": False,
            "auto_buy": False,
            "live_ledger_write": False,
            "new_blockers_added": False,
        },
    }
    snapshot["snapshot_id"] = f"ops-{int(at * 1000)}-{digest_obj(snapshot)[:12]}"
    return snapshot

def _runtime_start_for_error_log(base: Path, log_name: str) -> float:
    status_candidates: Dict[str, Sequence[Tuple[str, Sequence[str]]]] = {
        "clean_brain_error.log": (("clean_brain_status.json", ("started_at", "process_started_at")),),
        "clean_strategy_worker_error.log": (("clean_strategy_worker_status.json", ("candidate_process_start_ts_v1026", "process_started_at", "started_at")),),
        "paper_bot_error.log": (("paper_bot_status.json", ("process_started_at", "started_at")),),
        "clean_review_worker_error.log": (
            ("runtime/review_worker_singleton_v1121.lock", ("acquired_ts", "started_at")),
            ("clean_review_worker_status.json", ("process_started_at", "started_at", "last_success_ts")),
        ),
        "clean_guard_error.log": (("clean_guard_runtime_status_v1011.json", ("process_started_at", "started_at")),),
        "ws_sidecar_error.log": (("clean_ws_sidecar_status.json", ("process_started_at", "started_at")),),
    }
    for relative, fields in status_candidates.get(log_name, ()):
        obj = read_json(base / relative, {}) or {}
        if not isinstance(obj, dict):
            continue
        for field in fields:
            value = parse_ts(obj.get(field))
            if value > 0:
                return value
    return 0.0


def safe_error_tail(base: Path, max_lines: int = 80) -> List[str]:
    candidates = [
        base / "clean_brain_error.log",
        base / "clean_strategy_worker_error.log",
        base / "paper_bot_error.log",
        base / "clean_review_worker_error.log",
        base / "clean_guard_error.log",
        base / "ws_sidecar_error.log",
    ]
    out: List[str] = []
    for path in candidates:
        try:
            stat = path.stat()
        except OSError:
            continue
        runtime_start = _runtime_start_for_error_log(base, path.name)
        # A prior-runtime log is evidence history, not a current runtime error.
        if runtime_start > 0 and stat.st_mtime < runtime_start - 0.001:
            continue
        raw = read_text(path, max_bytes=512_000)
        if not raw.strip():
            continue
        for line in raw.splitlines()[-max_lines:]:
            if line.strip():
                out.append(f"[{path.name}] {line.strip()}")
    return out[-max_lines:]



def error_scope_summary(base: Path) -> Dict[str, Any]:
    """Public read-only current-vs-history error scope for Main/Guard."""
    return _error_scope_summary(base)

def find_ledger(base: Path, kind: str) -> Optional[Path]:
    names = {
        "issue": (
            "ledger/issue_ledger_events.jsonl", "runtime/issue_ledger_events.jsonl",
            "issue_ledger_events.jsonl", "issue_ledger.jsonl",
        ),
        "change": (
            "runtime/change_verify_ledger.jsonl", "ledger/change_verify_ledger.jsonl",
            "change_verify_ledger.jsonl",
        ),
    }
    for name in names.get(kind, ()):
        path = base / name
        if path.exists():
            return path
    return None
