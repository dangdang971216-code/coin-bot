코인봇 업데이트 v1188 · 전수증거 운영지도 완성판

현재 사용자 증거 기준
- Guard v2.5.199
- Strategy v1.037
- Review v1.016
- Main v2.13.1130
- Paper v1.048
- 후보→선택→OPEN 작동 확인
- 자동매수 OFF

v1188 대상
- Guard v2.5.200
- Main v2.13.1131
- Strategy v1.037 유지
- Review v1.016 유지
- Paper v1.048 유지

핵심 변경
- 기존 20단계를 건수·시간·증거와 함께 전수 확인
- 시세·호가→후보→generation→Paper→OPEN→CLOSED→성과→표시 전체 경로 확인
- 현재 cycle과 직전 정상 cycle 완전 분리
- 후보·Paper 구간별 시간과 가장 느린 구간 표시
- 선택·실제 제외·진단·OPEN·CLOSED 퍼널 확인
- OPEN 계약, 가격감시, MFE·MAE·반납, target/invalid 접촉증거 확인
- OPEN/CLOSED/decision/성과 snapshot 연결 확인
- 현재 runtime 오류와 과거 보존 오류 분리
- PID·버전·hash·중복프로세스·lock 확인
- CPU·메모리·디스크·I/O 확인
- 명령·Telegram·TXT 생성·전송 확인
- 공식 파일과 cycle_id·candidate_commit_id 연결 확인
- 임시폴더·backup·cache·ZIP 보존상태 확인
- OPEN 수익 TOP3·손실 TOP3·반납 TOP3 합계 문구 추가

중요 원칙
- 지도는 진단 전용이다.
- 시간 초와 실제 오류를 보고 owner에서 수리한다.
- 신규 차단·Gate·TTL·OPEN 제한을 추가하지 않는다.
- 증거가 없으면 NORMAL이 아니라 CHECK/COLLECTING/PARTIAL로 표시한다.
- 전략식·trigger·invalid·target·RR·청산계약 변경 없음.
- 라이브 원장 미포함·미수정.
- 자동매수 OFF.

적용
1. 가드봇에서 /gupgrade_bundle 단독 실행
2. 자동 이어적용 완료 후 가드·Main·Paper 검수
3. runtime exact/hash, 다음 cycle, 재시작 유지 확인 전 DONE 금지
