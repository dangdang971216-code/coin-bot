#!/usr/bin/env python3
from __future__ import annotations
import importlib.util
import json
import os
import sys
import tempfile
import time
from pathlib import Path

ROOT=Path(__file__).resolve().parent
BASE=Path(tempfile.mkdtemp(prefix='coinbot_v1188_test_'))
os.environ['COINBOT_BASE_DIR']=str(BASE)
os.environ.pop('TELEGRAM_TOKEN',None)
sys.path.insert(0,str(ROOT))
now=time.time(); pid=os.getpid()

def write(name,obj):
    p=BASE/name; p.parent.mkdir(parents=True,exist_ok=True); p.write_text(json.dumps(obj,ensure_ascii=False),encoding='utf-8')

def status(name,version,rows=3,last=0.2):
    write(name,{'running':True,'state':'running','version':version,'pid':pid,'updated_ts':now,'row_count':rows,'last_sec':last,'phase':'idle'})

status('clean_scanner_status.json','scanner_worker_v0.945')
status('clean_feature_status.json','feature_worker_v0.6')
status('clean_candle_status.json','candle_worker_v0.960')
status('clean_market_regime_status.json','market_regime_worker_v0.1')
status('clean_orderflow_status.json','orderflow_worker_v0.11')
status('clean_target_router_status.json','target_router_worker_v0.28')
status('clean_risk_status.json','risk_worker_v0.13')
status('clean_ws_sidecar_status.json','ws_sidecar_v0.7')
status('clean_bithumb_micro_status.json','micro_v0.15')
write('clean_strategy_worker_status.json',{'running':True,'state':'running','version':'strategy_worker_v1.037','pid':pid,'updated_ts':now,'paper_latest_count':3,'s1_count':1,'last_sec':1.2,'full_cycle_sec_v1031':1.2,'execution_handoff_elapsed_sec_v1179':0.8,'phase':'idle'})
write('clean_review_worker_status.json',{'running':True,'state':'running','version':'review_worker_v1.016','pid':pid,'updated_ts':now,'candidate_rows':3,'last_cycle_sec':0.1,'phase':'idle'})
write('clean_brain_status.json',{'running':True,'state':'running','version':'수익형 v2.13.1131','pid':pid,'started_at':now-100,'updated_ts':now,'telegram_state':'running','telegram_error':'-','command_count':24,'scan_running':False,'phase':'idle'})
write('paper_bot_status.json',{
    'running':True,'state':'running','version':'paper_bot_v1.048','pid':pid,'process_started_at':now-100,'updated_ts':now,
    'elapsed_sec':1.5,'opened_this_cycle':1,'closed_this_cycle':0,'open_count':1,
    'pick_stats':{'latest_count':3,'s1_seen':1,'selected_s1':1,'paper_funnel_accounted_v1102':1,'paper_funnel_unclassified_v1102':0,'paper_funnel_balance_ok_v1102':True,'paper_funnel_terminal_counts_v1102':{'SELECTED':1}},
    'paper_audit_only_summary_v1175':{'integrity_block_counts':{},'audit_only_counts':{},'actual_late_safety_block_count':0},
    'paper_performance_semantic_heartbeat_v1117':{'semantic_current':True,'state':'CURRENT_AFTER_WRITE'},
})
components={}
for name,ver in [('main','수익형 v2.13.1131'),('paper','paper_bot_v1.048'),('guard','guard_v2.5.200'),('strategy','strategy_worker_v1.037'),('review','review_worker_v1.016'),('scanner','scanner_worker_v0.945'),('feature','feature_worker_v0.6'),('candle','candle_worker_v0.960'),('market','market_regime_worker_v0.1'),('orderflow','orderflow_worker_v0.11'),('target','target_router_worker_v0.28'),('risk','risk_worker_v0.13'),('ws','ws_sidecar_v0.7'),('micro','micro_v0.15')]:
    components[name]={'service':name,'runtime_state':'OK','main_pid':pid,'process_count':1,'status_pid':pid,'status_version':ver,'cpu_pct':1.0,'rss_mb':20.0,'status_age_sec':0.1,'source_alias_hash_match':True}
write('clean_guard_runtime_status_v1010.json',{'version':'guard_v2.5.200','generated_at':now,'components':components,'server':{'cpu_pct':10.0,'iowait_pct':1.0,'mem_used_pct':20.0,'mem_available_mb':1000,'swap_used_mb':0,'disk_free_gb':10.0,'disk_used_pct':50.0},'io_top_components_v1011':[]})
write('runtime/strategy_worker_singleton_v1110.lock',{'pid':pid,'version':'strategy_worker_v1.037'})
write('runtime/review_worker_singleton_v1121.lock',{'pid':pid,'version':'review_worker_v1.016'})
write('strategy_candidate_pipeline_commit_v1150.json',{'state':'NORMAL','complete':True,'cycle_id':'cy1','candidate_commit_id':'cm1','candidate_rows':3,'s1_hold_count':1,'priority_request_count':3,'all_required_commits_v1150':True,'committed_handoff_file_v1158':str(BASE/'handoff.json'),'cycle_started_ts':now-2,'s1_hold_completed_ts_v1152':now-1.2,'candidate_snapshot_completed_ts_v1152':now-1.0,'priority_requests_completed_ts_v1152':now-0.9,'committed_handoff_completed_ts_v1158':now-0.8,'progress_state_v1152':'COMPLETE','last_complete_cycle_v1152':{'state':'NORMAL','cycle_id':'cy1','candidate_commit_id':'cm1','candidate_rows':3,'s1_hold_count':1,'completed_ts':now-0.8}})
write('handoff.json',{'schema':'strategy_paper_handoff_committed_v1158','cycle_id':'cy1','candidate_commit_id':'cm1'})
write('review_observation_request_v1181.json',{'pipeline_cycle_id':'cy1','candidate_commit_id':'cm1','candidate_rows':3,'created_ts':now-0.7})
write('canonical_review_snapshot_v1181.json',{'source':{'state':'NORMAL','pipeline_cycle_id':'cy1','candidate_commit_id':'cm1'},'candidate':{'total':3,'s1':1}})
write('canonical_candidate_standard_v1181.json',{'state':'NORMAL','snapshot_id':'std1','missing':[],'performance':{'snapshot_id':'perf1'}})
write('paper_bot_open.json',{'p1':{'pos_id':'p1','ticker':'ABC','paper_decision_key_v926':'d1','trigger_price':100,'invalid_price':95,'target_price':110,'current_price':101,'mfe_pct_v983':2.0,'mae_pct_v983':-1.0,'giveback_pct_v983':1.0,'last_checked_ts':now}})
write('paper_decision_state_v926.json',{'records':{'d1':{}}})
(BASE/'paper_bot_closed.jsonl').write_text('',encoding='utf-8')
write('paper_closed_append_status_v925.json',{'state':'NORMAL','append_verified':True,'decision_saved':True,'open_removed':True,'notification_sent':True})
write('canonical_performance_snapshot_v987.json',{'snapshot_id':'perf1','generated_at':now,'counts':{'raw_ledger_rows':1,'exact_unique_closed':1,'duplicate_closed_rows':0,'missing_decision_key':0,'decision_not_closed_or_missing':0,'bad_json_rows':0},'windows':{'today':{'n':1,'wins':1,'losses':0,'win_rate':100,'total':1,'avg':1},'yesterday':{},'recent_3h':{'n':1,'wins':1,'losses':0,'win_rate':100,'total':1,'avg':1},'recent_6h':{'n':1,'wins':1,'losses':0,'win_rate':100,'total':1,'avg':1},'recent_24h':{'n':1,'wins':1,'losses':0,'win_rate':100,'total':1,'avg':1},'all':{'n':1,'wins':1,'losses':0,'win_rate':100,'total':1,'avg':1}},'performance_epoch_v1045':{'stats':{'n':1,'wins':1,'losses':0,'win_rate':100,'total':1,'avg':1},'current_open_count':1},'book_performance_v1043':{'open_count':1,'valid_pnl_rows':1,'missing_pnl_rows':0,'current_total':1.0,'current_avg':1.0,'wins':1,'losses':0,'positive_total':1.0,'negative_total':0.0,'profit_top':[{'ticker':'ABC','pnl_pct':1.0}],'profit_top_sum':1.0}})
write('command_summary_status_v1187.json',{'ok':True,'txt_count':1,'status':'TXT 전송완료 후 서버삭제','render_sum_sec':0.1,'delivery_total_sec':0.2,'snapshot_id':'old','updated_ts':now})
# Timing evidence
with (BASE/'paper_candidate_path_events_v1153.jsonl').open('w',encoding='utf-8') as f:
    for stage,ts in [('PAPER_RECEIVED',now-0.7),('EXECUTION_DATA_READY',now-0.5),('OPEN_COMMITTED',now-0.2)]:
        f.write(json.dumps({'stage':stage,'trigger_event_key':'e1','recorded_at':ts})+'\n')
write('paper_candidate_path_state_v1153.json',{'records':{'x':{'repeat_exposure_count':0}}})
write('paper_timing_spine_status_v940.json',{'samples':[{'ticker':'ABC','selected_to_open_delay_sec':0.2,'s1_to_selected_delay_sec':0.3}]})

spec=importlib.util.spec_from_file_location('spine',ROOT/'canonical_spine_v1188.py'); spine=importlib.util.module_from_spec(spec); assert spec and spec.loader; sys.modules['spine']=spine; spec.loader.exec_module(spine)
snap=spine.build_ops_snapshot(BASE)
assert snap['overall_state']=='NORMAL', snap['problems']
assert len(snap['stages'])==20
assert snap['errors']['current_count']==0
assert snap['paper_funnel']['balance_ok'] is True
assert snap['open_exit_monitor']['open_count']==1
assert snap['ledger_performance']['snapshot_match'] is True
(BASE/'ops_spine_snapshot_v1181.json').write_text(json.dumps(snap,ensure_ascii=False),encoding='utf-8')

spec=importlib.util.spec_from_file_location('main',ROOT/'coinbot_main_v2_13_1131.py'); main=importlib.util.module_from_spec(spec); assert spec and spec.loader; sys.modules['main']=main; spec.loader.exec_module(main)
compact=main.render_flow_map_compact()
for text in ['전수감사 한눈판','후보 생성·저장·전달','현재 runtime 오류 0건','신규 차단을 만들지 않음']:
    assert text in compact,(text,compact)
full=main.render_flow_map_full()
for text in ['후보·Paper 전체 시간경로','Paper 후보 퍼널','OPEN·가격감시·청산증거','runtime·배포·단일프로세스','Main 명령·Telegram·TXT 편의 흐름']:
    assert text in full,(text,full)
score=main.render_version_score_compact()
assert '현재 수익 TOP3 · 합 +1.00%' in score, score
assert '- ABC +1.00%' in score, score
err=main.render_errorlog()
assert '현재 runtime 오류 0건' in err and '신규 오류 없음' in err
print('PASS')
