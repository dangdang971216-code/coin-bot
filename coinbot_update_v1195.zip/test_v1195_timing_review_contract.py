#!/usr/bin/env python3
from __future__ import annotations

import importlib.util
import json
import sys
import tempfile
import unittest
from pathlib import Path

HERE = Path(__file__).resolve().parent
if str(HERE) not in sys.path:
    sys.path.insert(0, str(HERE))

import canonical_spine_v1186 as review_spine
import canonical_spine_v1190 as ops_spine


def load_review_worker():
    spec = importlib.util.spec_from_file_location("review_worker_v1195_test", HERE / "review_worker_v1.018.py")
    assert spec and spec.loader
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


class V1195TimingReviewContractTests(unittest.TestCase):
    def test_current_strategy_timing_fields_beat_stale_legacy_fields(self):
        status = {
            "execution_handoff_sec_v1181": 8.260,
            "execution_handoff_elapsed_sec_v1179": 10.344,
            "full_cycle_sec_v1181": 8.369,
            "full_cycle_sec_v1031": 20.563,
            "last_sec": 8.369,
        }
        for module in (review_spine, ops_spine):
            self.assertEqual(module.strategy_handoff_sec(status), 8.260)
            self.assertEqual(module.strategy_full_cycle_sec(status), 8.369)

    def test_review_snapshot_and_candidate_standard_show_current_strategy_time(self):
        with tempfile.TemporaryDirectory() as td:
            base = Path(td)
            (base / "clean_strategy_worker_status.json").write_text(json.dumps({
                "version": "strategy_worker_v1.039",
                "execution_handoff_sec_v1181": 8.260,
                "execution_handoff_elapsed_sec_v1179": 10.344,
                "full_cycle_sec_v1181": 8.369,
                "full_cycle_sec_v1031": 20.563,
                "last_sec": 8.369,
            }), encoding="utf-8")
            (base / "paper_candidates_latest.jsonl").write_text(json.dumps({
                "ticker": "TEST",
                "s_stage": "S1",
                "paper_decision_key_v926": "d1",
                "candidate_key": "c1",
                "swing_trigger_price_v977": 100,
                "swing_invalid_price_v977": 95,
                "swing_target_price_v977": 120,
            }) + "\n", encoding="utf-8")
            (base / "review_observation_request_v1181.json").write_text(json.dumps({
                "pipeline_cycle_id": "cycle-1",
                "candidate_commit_id": "commit-1",
                "candidate_rows": 1,
            }), encoding="utf-8")
            (base / "paper_bot_status.json").write_text("{}", encoding="utf-8")
            (base / "canonical_performance_snapshot_v987.json").write_text("{}", encoding="utf-8")
            (base / "clean_candidate_standard_contract_v1141.json").write_text(json.dumps({"contract_digest": "x"}), encoding="utf-8")
            snapshot = review_spine.build_review_snapshot(base)
            standard = review_spine.build_candidate_standard(snapshot)
            self.assertEqual(snapshot["time"]["strategy_execution_handoff_sec"], 8.260)
            self.assertEqual(snapshot["time"]["strategy_full_cycle_sec"], 8.369)
            self.assertEqual(standard["time"]["strategy_full_cycle_sec"], 8.369)

    def test_review_commit_view_accepts_missing_nested_objects_without_none_get(self):
        module = load_review_worker()
        view = module._v1195_review_commit_view(
            {"snapshot_id": "r1", "source": None, "candidate": None, "performance": None},
            {"state": "CHECK_SOURCE"},
        )
        self.assertIsNone(view["pipeline_cycle_id"])
        self.assertIsNone(view["candidate_rows"])
        self.assertEqual(view["performance_count"], 0)

    def test_review_commit_view_rejects_non_mapping_before_commit(self):
        module = load_review_worker()
        with self.assertRaisesRegex(TypeError, "snapshot contract expected dict"):
            module._v1195_review_commit_view(None, {})
        with self.assertRaisesRegex(TypeError, "candidate standard contract expected dict"):
            module._v1195_review_commit_view({}, None)

    def test_review_process_commits_normalized_generation_without_none_get(self):
        module = load_review_worker()
        with tempfile.TemporaryDirectory() as td:
            base = Path(td)
            module.build_review_snapshot = lambda _base, request=None: {
                "snapshot_id": "review-1",
                "source": None,
                "candidate": None,
                "performance": None,
                "invariants": {},
            }
            module.build_candidate_standard = lambda snapshot: {
                "snapshot_id": snapshot.get("snapshot_id"),
                "state": "CHECK_SOURCE",
            }
            result = module.process_once(base, force=True)
            self.assertTrue(result["processed"])
            status = json.loads((base / "clean_review_worker_status.json").read_text(encoding="utf-8"))
            self.assertEqual(status["state"], "running")
            self.assertEqual(status["health_state"], "NORMAL")
            self.assertEqual(status["candidate_standard_state"], "CHECK_SOURCE")
            self.assertEqual(status["performance_count"], 0)
            event = json.loads((base / "review_generation_events_v1181.jsonl").read_text(encoding="utf-8").splitlines()[-1])
            self.assertIsNone(event["pipeline_cycle_id"])

    def test_ops_source_uses_current_timing_helpers_for_stage_rows(self):
        source = (HERE / "canonical_spine_v1190.py").read_text(encoding="utf-8")
        self.assertIn("duration_sec=strategy_full_cycle_sec(strategy_status)", source)
        self.assertIn("duration_sec=strategy_handoff_sec(strategy_status)", source)
        self.assertNotIn('duration_sec=num(strategy_status.get("full_cycle_sec_v1031")', source)


if __name__ == "__main__":
    unittest.main(verbosity=2)
