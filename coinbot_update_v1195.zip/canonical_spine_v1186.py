#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Coinbot canonical spine v1186.

One owner per value, atomic snapshots, bounded readers, and no trading-rule
recalculation in Main/Guard/Review. This module contains only shared I/O and
read-only aggregation helpers. It never writes OPEN/CLOSED/decision ledgers.
"""
from __future__ import annotations

import hashlib
import json
import math
import os
import statistics
import time
from collections import Counter
from dataclasses import dataclass
from datetime import datetime
from pathlib import Path
from typing import Any, Dict, Iterable, List, Mapping, MutableMapping, Optional, Sequence, Tuple

SPINE_VERSION = "v1186"
SPINE_SCHEMA = "coinbot_canonical_spine_v1186"
AUTO_BUY = False
STRATEGY_MODE = "ALT_SWING"


def now_ts() -> float:
    return time.time()


def now_text(ts: Optional[float] = None) -> str:
    return time.strftime("%Y-%m-%d %H:%M:%S", time.localtime(ts or now_ts()))


def json_default(value: Any) -> Any:
    if isinstance(value, Path):
        return str(value)
    return str(value)


def atomic_write_json(path: Path, payload: Any) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    tmp = path.with_name(f".{path.name}.tmp.{os.getpid()}.{time.time_ns()}")
    with tmp.open("w", encoding="utf-8") as handle:
        json.dump(payload, handle, ensure_ascii=False, separators=(",", ":"), default=json_default)
        handle.flush()
        os.fsync(handle.fileno())
    os.replace(tmp, path)
    try:
        directory_fd = os.open(str(path.parent), os.O_RDONLY)
    except OSError:
        return
    try:
        os.fsync(directory_fd)
    finally:
        os.close(directory_fd)


def append_jsonl(path: Path, payload: Mapping[str, Any]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    line = json.dumps(dict(payload), ensure_ascii=False, separators=(",", ":"), default=json_default) + "\n"
    with path.open("a", encoding="utf-8") as handle:
        handle.write(line)
        handle.flush()
        os.fsync(handle.fileno())


def read_json(path: Path, default: Any = None) -> Any:
    try:
        if not path.exists() or not path.is_file():
            return default
        return json.loads(path.read_text(encoding="utf-8", errors="ignore"))
    except (OSError, json.JSONDecodeError, TypeError, ValueError):
        return default


def read_text(path: Path, default: str = "", max_bytes: int = 2_000_000) -> str:
    try:
        if not path.exists() or not path.is_file():
            return default
        size = path.stat().st_size
        with path.open("rb") as handle:
            if size > max_bytes:
                handle.seek(size - max_bytes)
            raw = handle.read(max_bytes)
        return raw.decode("utf-8", errors="ignore")
    except OSError:
        return default


def read_jsonl_tail(path: Path, limit: int = 2000, max_bytes: int = 32 * 1024 * 1024) -> List[Dict[str, Any]]:
    if limit <= 0 or not path.exists() or not path.is_file():
        return []
    try:
        size = path.stat().st_size
        take = min(size, max_bytes)
        with path.open("rb") as handle:
            if size > take:
                handle.seek(size - take)
                handle.readline()
            data = handle.read(take)
    except OSError:
        return []
    out: List[Dict[str, Any]] = []
    for raw in data.splitlines()[-limit:]:
        try:
            item = json.loads(raw.decode("utf-8", errors="ignore"))
        except (UnicodeDecodeError, json.JSONDecodeError):
            continue
        if isinstance(item, dict):
            out.append(item)
    return out


def read_candidate_rows(path: Path, max_rows: int = 5000) -> List[Dict[str, Any]]:
    """Read current candidate snapshot only.

    The canonical file may be JSONL or a compact JSON object/list depending on
    the deployed writer version. No stale cache fallback is used.
    """
    if not path.exists():
        return []
    obj = read_json(path, None)
    rows = rows_from(obj)
    if rows:
        return rows[:max_rows]
    return read_jsonl_tail(path, max_rows, max_bytes=64 * 1024 * 1024)


def rows_from(obj: Any) -> List[Dict[str, Any]]:
    if isinstance(obj, list):
        return [dict(item) for item in obj if isinstance(item, dict)]
    if not isinstance(obj, dict):
        return []
    for key in (
        "rows", "items", "candidates", "active_rows", "display_rows",
        "top_candidates", "positions", "open_positions", "data",
    ):
        value = obj.get(key)
        if isinstance(value, list):
            return [dict(item) for item in value if isinstance(item, dict)]
        if isinstance(value, dict):
            out: List[Dict[str, Any]] = []
            for item_key, item_value in value.items():
                if isinstance(item_value, dict):
                    row = dict(item_value)
                    row.setdefault("pos_id", item_key)
                    out.append(row)
            if out:
                return out
    if obj and all(isinstance(value, dict) for value in obj.values()):
        return [dict(value, pos_id=value.get("pos_id") or key) for key, value in obj.items()]
    return []


def file_age(path: Path, at: Optional[float] = None) -> Optional[float]:
    try:
        return max(0.0, (at or now_ts()) - path.stat().st_mtime)
    except OSError:
        return None


def sha256_file(path: Path, chunk_size: int = 1024 * 1024) -> str:
    digest = hashlib.sha256()
    try:
        with path.open("rb") as handle:
            while True:
                chunk = handle.read(chunk_size)
                if not chunk:
                    break
                digest.update(chunk)
    except OSError:
        return ""
    return digest.hexdigest()


def digest_obj(payload: Any) -> str:
    raw = json.dumps(payload, ensure_ascii=False, sort_keys=True, separators=(",", ":"), default=json_default)
    return hashlib.sha256(raw.encode("utf-8")).hexdigest()


def num(*values: Any, default: Optional[float] = None) -> Optional[float]:
    for value in values:
        if value in (None, "", [], {}):
            continue
        try:
            parsed = float(str(value).replace(",", "").replace("%", "").strip())
        except (TypeError, ValueError):
            continue
        if math.isfinite(parsed):
            return parsed
    return default


def integer(*values: Any, default: int = 0) -> int:
    value = num(*values, default=None)
    return int(value) if value is not None else default


def strategy_handoff_sec(status: Mapping[str, Any]) -> Optional[float]:
    """Read the newest Strategy handoff owner field before legacy aliases.

    v1181 renamed the immutable execution-generation timing field.  Older
    fields stay available only for historic compatibility and must not mask a
    current v1181 value.
    """
    row = mapping(status)
    return num(
        row.get("execution_handoff_sec_v1181"),
        row.get("execution_handoff_elapsed_sec_v1179"),
        row.get("execution_handoff_sec"),
        default=None,
    )


def strategy_full_cycle_sec(status: Mapping[str, Any]) -> Optional[float]:
    """Read the immutable generation cycle time from its current owner.

    ``full_cycle_sec_v1031`` may remain preserved in the merged status payload
    after a deploy.  Prefer the v1181 field written by the current Strategy
    cycle so a stale legacy value cannot overwrite current runtime truth.
    """
    row = mapping(status)
    return num(
        row.get("full_cycle_sec_v1181"),
        row.get("full_cycle_sec_v1031"),
        row.get("last_sec"),
        default=None,
    )


def strategy_timing_provenance(status: Mapping[str, Any]) -> Dict[str, Any]:
    row = mapping(status)
    handoff_field = next((key for key in (
        "execution_handoff_sec_v1181", "execution_handoff_elapsed_sec_v1179", "execution_handoff_sec"
    ) if num(row.get(key), default=None) is not None), None)
    full_field = next((key for key in (
        "full_cycle_sec_v1181", "full_cycle_sec_v1031", "last_sec"
    ) if num(row.get(key), default=None) is not None), None)
    return {
        "reader_patch": "v1195_current_owner_first",
        "execution_handoff_field": handoff_field,
        "full_cycle_field": full_field,
    }


def text(*values: Any, default: str = "") -> str:
    for value in values:
        if value in (None, "", "-", [], {}):
            continue
        out = str(value).strip()
        if out:
            return out
    return default


def mapping(*values: Any) -> Dict[str, Any]:
    for value in values:
        if isinstance(value, dict):
            return value
    return {}


def sequence(*values: Any) -> List[Any]:
    for value in values:
        if isinstance(value, (list, tuple)):
            return list(value)
    return []


def deep_get(obj: Any, path: str, default: Any = None) -> Any:
    current = obj
    for part in path.split("."):
        if not isinstance(current, dict) or part not in current:
            return default
        current = current[part]
    return current


def first_path(obj: Mapping[str, Any], paths: Sequence[str], default: Any = None) -> Any:
    for path in paths:
        value = deep_get(obj, path, None)
        if value not in (None, "", [], {}):
            return value
    return default


def parse_ts(*values: Any) -> float:
    for value in values:
        if value in (None, "", [], {}):
            continue
        if isinstance(value, (int, float)):
            candidate = float(value)
            if candidate > 1e12:
                candidate /= 1000.0
            if candidate > 1e9:
                return candidate
        raw = str(value).strip().replace(" KST", "")
        try:
            candidate = float(raw)
            if candidate > 1e12:
                candidate /= 1000.0
            if candidate > 1e9:
                return candidate
        except ValueError:
            pass
        for fmt in ("%Y-%m-%d %H:%M:%S", "%Y-%m-%dT%H:%M:%S", "%Y-%m-%dT%H:%M:%S%z"):
            try:
                return datetime.strptime(raw, fmt).timestamp()
            except ValueError:
                continue
    return 0.0


def ticker(value: Any) -> str:
    out = str(value or "").strip().upper().replace("/", "-").replace("_", "-")
    parts = [part for part in out.split("-") if part]
    if len(parts) > 1:
        parts = [part for part in parts if part != "KRW"]
        out = parts[-1] if parts else out
    if out.endswith("KRW") and len(out) > 3:
        out = out[:-3]
    return out


def stage(row: Mapping[str, Any]) -> str:
    gate = mapping(row.get("swing_entry_gate_v977"), row.get("swing_entry_gate"))
    value = text(
        gate.get("stage"), row.get("s_stage"), row.get("stage"),
        row.get("grade"), row.get("candidate_stage"), default="UNKNOWN",
    ).upper()
    if value in {"BUY_READY", "READY", "S"}:
        return "S1"
    return value


def decision_key(row: Mapping[str, Any]) -> str:
    gate = mapping(row.get("swing_entry_gate_v977"), row.get("swing_entry_gate"))
    decision = mapping(row.get("canonical_entry_decision"))
    return text(
        row.get("paper_decision_key_v926"), row.get("swing_gate_decision_key_v977"),
        gate.get("decision_key"), decision.get("decision_key"), row.get("decision_key"),
    )


def candidate_key(row: Mapping[str, Any]) -> str:
    return text(
        row.get("trigger_occurrence_candidate_key_v1037"), row.get("candidate_key"),
        row.get("entry_build_key"), row.get("event_key"), row.get("event_id"),
    )


def row_price(row: Mapping[str, Any]) -> Optional[float]:
    return num(row.get("current_price"), row.get("entry_price"), row.get("price"), row.get("trade_price"))


def median(values: Iterable[Any]) -> Optional[float]:
    clean: List[float] = []
    for value in values:
        parsed = num(value, default=None)
        if parsed is not None:
            clean.append(parsed)
    return float(statistics.median(clean)) if clean else None


def average(values: Iterable[Any]) -> Optional[float]:
    clean: List[float] = []
    for value in values:
        parsed = num(value, default=None)
        if parsed is not None:
            clean.append(parsed)
    return float(sum(clean) / len(clean)) if clean else None


def pct_text(value: Any, digits: int = 3) -> str:
    parsed = num(value, default=None)
    return "정보없음" if parsed is None else f"{parsed:+.{digits}f}%"


@dataclass(frozen=True)
class SpinePaths:
    base: Path

    @property
    def strategy_status(self) -> Path:
        return self.base / "clean_strategy_worker_status.json"

    @property
    def strategy_candidates(self) -> Path:
        return self.base / "paper_candidates_latest.jsonl"

    @property
    def strategy_hold(self) -> Path:
        return self.base / "paper_s1_hold_cache.json"

    @property
    def strategy_pipeline(self) -> Path:
        return self.base / "clean_strategy_candidate_pipeline_status_v1150.json"

    @property
    def strategy_handoff(self) -> Path:
        return self.base / "clean_strategy_paper_handoff_status.json"

    @property
    def review_request(self) -> Path:
        return self.base / "review_observation_request_v1181.json"

    @property
    def review_status(self) -> Path:
        return self.base / "clean_review_worker_status.json"

    @property
    def review_snapshot(self) -> Path:
        return self.base / "canonical_review_snapshot_v1181.json"

    @property
    def candidate_standard(self) -> Path:
        return self.base / "canonical_candidate_standard_v1181.json"

    @property
    def paper_status(self) -> Path:
        return self.base / "paper_bot_status.json"

    @property
    def paper_open(self) -> Path:
        return self.base / "paper_bot_open.json"

    @property
    def paper_control(self) -> Path:
        return self.base / "paper_bot_control.json"

    @property
    def paper_handoff(self) -> Path:
        return self.base / "paper_bot_candidate_handoff_status.json"

    @property
    def paper_trace(self) -> Path:
        return self.base / "paper_bot_candidate_handoff_trace.json"

    @property
    def performance(self) -> Path:
        return self.base / "canonical_performance_snapshot_v987.json"

    @property
    def ops_snapshot(self) -> Path:
        return self.base / "ops_spine_snapshot_v1181.json"

    @property
    def main_status(self) -> Path:
        return self.base / "clean_brain_status.json"

    @property
    def guard_status(self) -> Path:
        return self.base / "clean_guard_runtime_status_v1010.json"

    @property
    def scanner_status(self) -> Path:
        return self.base / "clean_scanner_status.json"

    @property
    def feature_status(self) -> Path:
        return self.base / "clean_feature_status.json"

    @property
    def candle_status(self) -> Path:
        return self.base / "clean_candle_status.json"

    @property
    def market_status(self) -> Path:
        return self.base / "clean_market_regime_status.json"

    @property
    def orderflow_status(self) -> Path:
        return self.base / "clean_orderflow_status.json"

    @property
    def target_status(self) -> Path:
        return self.base / "clean_target_router_status.json"

    @property
    def risk_status(self) -> Path:
        return self.base / "clean_risk_status.json"

    @property
    def ws_status(self) -> Path:
        return self.base / "clean_ws_sidecar_status.json"

    @property
    def micro_status(self) -> Path:
        return self.base / "clean_bithumb_micro_status.json"


def metric_from_row(row: Mapping[str, Any], name: str) -> Optional[float]:
    gate = mapping(row.get("swing_entry_gate_v977"), row.get("swing_entry_gate"))
    quality = mapping(row.get("swing_quality_gate"), gate.get("swing_quality_gate"))
    execution = mapping(row.get("execution_risk"), row.get("paper_execution_diagnostics"))
    path_map: Dict[str, Sequence[str]] = {
        "price_reaction": (
            "price_reaction_score", "price_reaction", "price_reaction_pct", "price_reaction_1m_pct", "feature_price_reaction",
            "swing_quality_gate.price_reaction", "quality_observation_v925.price_reaction",
        ),
        "relative_strength": (
            "relative_strength", "relative_strength_pct", "relative_strength_score", "relative_strength_rank_pct_v1095", "market_relative_strength",
            "swing_quality_gate.relative_strength",
        ),
        "money_flow": (
            "money_flow", "money_flow_score", "money_flow_strength",
            "swing_quality_gate.money_flow",
        ),
        "buy_ratio": (
            "buy_trade_ratio", "buy_ratio", "trade_buy_ratio", "micro_buy_ratio",
            "swing_quality_gate.buy_ratio", "execution_risk.buy_trade_ratio",
        ),
        "buy_sustain": (
            "buy_sustain", "buy_sustain_1m", "buy_sustain_1m_real", "micro_buy_sustain_1m", "one_min_persist", "buy_pressure_persist",
            "swing_quality_gate.buy_sustain",
        ),
        "rank_score": (
            "swing_quality_rank_score", "quality_rank_score_v1095", "score",
            "swing_quality_gate.rank_score",
        ),
        "rr": (
            "risk_reward", "rr_ratio", "actual_entry_rr",
            "swing_entry_gate_v977.risk_reward", "swing_entry_gate.risk_reward",
        ),
        "target_room": (
            "target_room_pct", "expected_upside_pct", "target_space_pct",
            "swing_entry_gate_v977.target_room_pct", "risk_reward.expected_upside_pct",
        ),
        "invalid_distance": (
            "invalid_distance_pct", "distance_to_invalid_pct", "expected_downside_pct", "stop_distance_pct",
            "risk_reward.expected_downside_pct",
        ),
        "chase": (
            "trigger_chase_pct", "trigger_overshoot_pct", "late_chase_pct",
        ),
        "spread": (
            "spread_pct", "spread", "execution_risk.spread", "swing_entry_gate_v977.spread_pct",
        ),
        "slippage": (
            "confirmed_slippage_pct", "slippage_pct", "execution_risk.slippage",
            "swing_entry_gate_v977.confirmed_slippage_pct",
        ),
    }
    value = first_path(row, path_map.get(name, (name,)), None)
    if value is None:
        if name == "rank_score":
            value = quality.get("rank_score")
        elif name == "spread":
            value = execution.get("spread")
        elif name == "slippage":
            value = execution.get("slippage")
    return num(value, default=None)


def structure_sources(row: Mapping[str, Any]) -> Dict[str, Any]:
    gate = mapping(row.get("swing_entry_gate_v977"), row.get("swing_entry_gate"))
    plan = mapping(row.get("swing_structure_plan_v977"), gate.get("structure_plan"), row.get("structure_plan"))
    trigger = mapping(plan.get("trigger"))
    invalid = mapping(plan.get("invalid"))
    target = mapping(plan.get("target"))
    levels = mapping(row.get("structure_levels"), row.get("structure_context_v871"))
    return {
        "trigger_source": text(row.get("swing_trigger_source_v977"), trigger.get("source"), levels.get("execution_resistance_source")),
        "invalid_source": text(row.get("swing_invalid_source_v977"), invalid.get("source"), levels.get("setup_support_source")),
        "target_source": text(row.get("swing_target_source_v977"), target.get("source"), levels.get("major_resistance_source")),
        "trigger_price": num(row.get("swing_trigger_price_v977"), row.get("trigger_price"), trigger.get("price"), default=None),
        "invalid_price": num(row.get("swing_invalid_price_v977"), row.get("invalid_price"), invalid.get("price"), default=None),
        "target_price": num(row.get("swing_target_price_v977"), row.get("target_price"), target.get("price"), default=None),
    }


def source_lane(row: Mapping[str, Any]) -> str:
    raw = text(
        row.get("source_lane"), row.get("candidate_source"), row.get("ingress_source"),
        row.get("source_path"), row.get("canonical_lane"), row.get("scanner_reason"),
        row.get("strategy_key"), default="unknown",
    ).lower()
    if "hot" in raw or "spike" in raw or "급등" in raw:
        return "hot-rank"
    if "break" in raw or "돌파" in raw:
        return "돌파초입"
    if "money" in raw or "돈흐름" in raw:
        return "돈흐름"
    if "lead" in raw or "주도" in raw:
        return "주도흐름"
    if "low" in raw or "저점" in raw or "vwap" in raw:
        return "저점회복"
    if "coverage" in raw or "전체" in raw:
        return "전체커버"
    return text(row.get("canonical_lane"), default="기타")


def performance_summary(performance: Mapping[str, Any]) -> Dict[str, Any]:
    windows = mapping(performance.get("windows"))
    epoch = mapping(performance.get("performance_epoch_v1045"))
    epoch_windows = mapping(epoch.get("windows"))
    current = mapping(epoch.get("stats"), epoch_windows.get("all"), performance.get("fresh_epoch_stats"), windows.get("all"), performance.get("summary"))
    counts = mapping(performance.get("counts"))
    rows = sequence(performance.get("rows"))
    return {
        "snapshot_id": performance.get("snapshot_id"),
        "generated_at": performance.get("generated_at"),
        "source_owner": performance.get("source_owner"),
        "count": integer(current.get("count"), current.get("n"), counts.get("current_epoch_exact_rows_v1045"), counts.get("included"), len(rows)),
        "wins": integer(current.get("wins"), current.get("win_count")),
        "losses": integer(current.get("losses"), current.get("loss_count")),
        "win_rate": num(current.get("win_rate"), current.get("win_rate_pct"), current.get("win_pct"), default=None),
        "sum_pct": num(current.get("sum_pct"), current.get("total_pct"), current.get("pnl_pct_sum"), current.get("total"), default=None),
        "avg_pct": num(current.get("avg_pct"), current.get("average_pct"), current.get("avg"), default=None),
        "mfe_median": num(current.get("mfe_median"), current.get("median_mfe_pct"), current.get("mfe"), default=None),
        "mae_median": num(current.get("mae_median"), current.get("median_mae_pct"), current.get("mae"), default=None),
        "duplicate": integer(counts.get("duplicate_rows"), counts.get("duplicates")),
        "missing_key": integer(counts.get("decision_key_missing"), counts.get("missing_key")),
        "unlinked": integer(counts.get("decision_unlinked"), counts.get("unlinked")),
    }


def build_review_snapshot(base: Path, request: Optional[Mapping[str, Any]] = None) -> Dict[str, Any]:
    paths = SpinePaths(base)
    now = now_ts()
    req = dict(request or read_json(paths.review_request, {}) or {})
    rows = read_candidate_rows(paths.strategy_candidates)
    strategy_status = read_json(paths.strategy_status, {}) or {}
    paper_status = read_json(paths.paper_status, {}) or {}
    performance = read_json(paths.performance, {}) or {}
    contract = read_json(base / "clean_candidate_standard_contract_v1141.json", {}) or {}

    stage_counts = Counter(stage(row) for row in rows)
    source_counts = Counter(source_lane(row) for row in rows)
    active_rows = [row for row in rows if stage(row) == "S1"]
    decision_missing = sum(1 for row in active_rows if not decision_key(row))
    candidate_missing = sum(1 for row in active_rows if not candidate_key(row))
    structure_complete = 0
    source_combinations: Counter[str] = Counter()
    metrics: Dict[str, List[float]] = {key: [] for key in (
        "price_reaction", "relative_strength", "money_flow", "buy_ratio", "buy_sustain",
        "rank_score", "rr", "target_room", "invalid_distance", "chase", "spread", "slippage",
    )}
    occurrence_ages: List[float] = []
    samples: List[Dict[str, Any]] = []
    for row in active_rows:
        sources = structure_sources(row)
        complete = all(sources.get(key) not in (None, "", 0, 0.0) for key in (
            "trigger_price", "invalid_price", "target_price",
        ))
        if complete:
            structure_complete += 1
        combo = "|".join([
            text(sources.get("trigger_source"), default="SOURCE_MISSING"),
            text(sources.get("invalid_source"), default="SOURCE_MISSING"),
            text(sources.get("target_source"), default="SOURCE_MISSING"),
        ])
        source_combinations[combo] += 1
        for name in metrics:
            value = metric_from_row(row, name)
            if value is not None:
                metrics[name].append(value)
        event_ts = parse_ts(
            row.get("actual_trigger_event_at_v1173"), row.get("trigger_event_at_v1153"),
            deep_get(row, "trigger_occurrence_v1037.event_ts"), deep_get(row, "candidate_path_timestamps_v1153.trigger_event_at"),
        )
        if event_ts > 0:
            occurrence_ages.append(max(0.0, now - event_ts))
        if len(samples) < 20 and stage(row) in {"S1", "S2"}:
            samples.append({
                "ticker": ticker(row.get("ticker") or row.get("market") or row.get("symbol")),
                "stage": stage(row),
                "decision_key": decision_key(row),
                "candidate_key": candidate_key(row),
                "source_lane": source_lane(row),
                "rr": metric_from_row(row, "rr"),
                "target_room_pct": metric_from_row(row, "target_room"),
                "spread_pct": metric_from_row(row, "spread"),
                "structure": sources,
            })

    request_age = None
    req_ts = parse_ts(req.get("committed_handoff_completed_ts"), req.get("created_ts"), req.get("updated_ts"))
    if req_ts:
        request_age = max(0.0, now - req_ts)
    pipeline_id = text(req.get("pipeline_cycle_id"), req.get("candidate_pipeline_cycle_id_v1150"))
    commit_id = text(req.get("candidate_commit_id"), req.get("candidate_commit_id_v1150"))
    row_count_match = integer(req.get("candidate_rows"), default=len(rows)) == len(rows)
    source_state = "NORMAL" if rows and pipeline_id and commit_id and row_count_match else "CHECK"
    contract_digest = text(contract.get("contract_digest"))
    perf = performance_summary(performance)

    snapshot: Dict[str, Any] = {
        "schema": "canonical_review_snapshot_v1181",
        "version": "review_worker_v1.016",
        "build": "v1186_review_s1_scope_and_performance_mapping_2026-07-02",
        "generated_ts": now,
        "generated_text": now_text(now),
        "strategy_mode": STRATEGY_MODE,
        "auto_buy": False,
        "owner": "review_worker_single_candidate_standard_owner_v1181",
        "source": {
            "state": source_state,
            "pipeline_cycle_id": pipeline_id,
            "candidate_commit_id": commit_id,
            "request_age_sec": request_age,
            "candidate_file_age_sec": file_age(paths.strategy_candidates, now),
            "candidate_rows": len(rows),
            "request_rows": integer(req.get("candidate_rows"), default=len(rows)),
            "row_count_match": row_count_match,
            "strategy_version": strategy_status.get("version") or strategy_status.get("strategy_worker_version"),
            "paper_version": paper_status.get("version") or paper_status.get("paper_version"),
        },
        "candidate": {
            "total": len(rows),
            "stage_counts": dict(stage_counts),
            "s1": stage_counts.get("S1", 0),
            "s2": stage_counts.get("S2", 0),
            "s3": stage_counts.get("S3", 0),
            "decision_key_missing": decision_missing,
            "candidate_key_missing": candidate_missing,
            "source_lane_counts": dict(source_counts),
            "source_lane_top": source_counts.most_common(10),
        },
        "structure": {
            "evaluated": len(active_rows),
            "complete": structure_complete,
            "complete_pct": round(structure_complete / len(active_rows) * 100.0, 3) if active_rows else None,
            "source_missing": max(0, len(active_rows) - structure_complete),
            "source_combinations": dict(source_combinations.most_common(20)),
        },
        "quality": {
            name: {"n": len(values), "median": median(values), "average": average(values)}
            for name, values in metrics.items()
        },
        "time": {
            "occurrence_age_n": len(occurrence_ages),
            "occurrence_age_median_sec": median(occurrence_ages),
            "occurrence_age_max_sec": max(occurrence_ages) if occurrence_ages else None,
            "strategy_execution_handoff_sec": strategy_handoff_sec(strategy_status),
            "strategy_full_cycle_sec": strategy_full_cycle_sec(strategy_status),
            "paper_cycle_sec": num(paper_status.get("elapsed_sec"), deep_get(paper_status, "paper_cycle_profile_v1053.cycle.total.sec"), default=None),
            "strategy_timing_reader_v1195": strategy_timing_provenance(strategy_status),
        },
        "performance": perf,
        "contract": {
            "schema": contract.get("schema"),
            "contract_digest": contract_digest,
            "strategy_source_sha256": contract.get("strategy_source_sha256"),
            "invariants": contract.get("invariants"),
            "auto_baseline_replace": False,
        },
        "samples": samples,
        "invariants": {
            "candidate_formula_changed": False,
            "trigger_changed": False,
            "invalid_changed": False,
            "target_changed": False,
            "rr_changed": False,
            "exit_contract_changed": False,
            "auto_buy": False,
            "live_ledger_write": False,
        },
    }
    snapshot["snapshot_id"] = f"review-{int(now * 1000)}-{digest_obj(snapshot)[:12]}"
    return snapshot


def build_candidate_standard(snapshot: Mapping[str, Any]) -> Dict[str, Any]:
    source = mapping(snapshot.get("source"))
    candidate = mapping(snapshot.get("candidate"))
    structure = mapping(snapshot.get("structure"))
    quality = mapping(snapshot.get("quality"))
    time_info = mapping(snapshot.get("time"))
    perf = mapping(snapshot.get("performance"))
    contract = mapping(snapshot.get("contract"))
    source_state = text(source.get("state"), default="CHECK")
    missing: List[str] = []
    if integer(candidate.get("decision_key_missing")):
        missing.append("decision_key")
    if integer(candidate.get("candidate_key_missing")):
        missing.append("candidate_key")
    if integer(structure.get("source_missing")):
        missing.append("structure_source")
    if not text(contract.get("contract_digest")):
        missing.append("contract_digest")
    if source_state != "NORMAL":
        state = "CHECK_SOURCE"
    elif missing:
        state = "PARTIAL_SOURCE"
    else:
        state = "NORMAL"
    return {
        "schema": "canonical_candidate_standard_v1181",
        "version": snapshot.get("version"),
        "snapshot_id": snapshot.get("snapshot_id"),
        "generated_ts": snapshot.get("generated_ts"),
        "generated_text": snapshot.get("generated_text"),
        "state": state,
        "easy_state": {
            "NORMAL": "전체 정상",
            "PARTIAL_SOURCE": "일부 근거 누락",
            "CHECK_SOURCE": "현재 원천 확인 필요",
        }.get(state, "확인 필요"),
        "strategy_mode": STRATEGY_MODE,
        "auto_buy": False,
        "scope": {
            "delivery": "current Strategy committed generation",
            "candidate": "same candidate commit rows",
            "performance": "Paper canonical performance snapshot only",
        },
        "delivery": source,
        "candidate": candidate,
        "structure": structure,
        "quality": quality,
        "time": time_info,
        "performance": perf,
        "contract": contract,
        "missing": missing,
        "samples": snapshot.get("samples") or [],
        "invariants": snapshot.get("invariants") or {},
    }


def _status_record(name: str, path: Path, owner: str, fresh_limit: float, at: float) -> Dict[str, Any]:
    obj = read_json(path, {}) or {}
    age = file_age(path, at)
    running = obj.get("running")
    state_raw = text(obj.get("state"), obj.get("status"), obj.get("phase"), default="UNKNOWN")
    if not path.exists():
        state = "CHECK"
        reason = "status file missing"
    elif age is None or age > fresh_limit:
        state = "CHECK"
        reason = f"status stale {age:.1f}s" if age is not None else "status age unknown"
    elif running is False or state_raw.upper() in {"ERROR", "FAIL", "FAILED", "STOPPED", "DOWN"}:
        state = "FAIL"
        reason = text(obj.get("last_error"), obj.get("error"), state_raw)
    else:
        state = "NORMAL"
        reason = ""
    return {
        "name": name,
        "owner": owner,
        "state": state,
        "reason": reason,
        "age_sec": age,
        "version": obj.get("version") or obj.get("worker_version") or obj.get("strategy_worker_version") or obj.get("paper_version"),
        "build": obj.get("build") or obj.get("build_label"),
        "phase": obj.get("phase") or obj.get("runtime_phase_v994") or obj.get("startup_phase"),
        "raw": obj,
    }


def build_ops_snapshot(base: Path) -> Dict[str, Any]:
    paths = SpinePaths(base)
    at = now_ts()
    workers = {
        "scanner": _status_record("전체시장 Scanner", paths.scanner_status, "scanner_worker", 120.0, at),
        "feature": _status_record("Feature 품질값", paths.feature_status, "feature_worker", 120.0, at),
        "candle": _status_record("Candle 완료봉 구조", paths.candle_status, "candle_worker", 180.0, at),
        "market": _status_record("Market 장세", paths.market_status, "market_regime_worker", 180.0, at),
        "orderflow": _status_record("Orderflow 실행비용", paths.orderflow_status, "orderflow_worker", 120.0, at),
        "target": _status_record("Target Router 정보배차", paths.target_status, "target_router_worker", 120.0, at),
        "strategy": _status_record("Strategy 후보·진입계약", paths.strategy_status, "strategy_worker", 180.0, at),
        "paper": _status_record("Paper 실행 core", paths.paper_status, "paper_bot", 120.0, at),
        "review": _status_record("Review 복기·성과", paths.review_status, "review_worker", 120.0, at),
        "main": _status_record("Main 표시", paths.main_status, "main_bot", 120.0, at),
        "guard": _status_record("Guard runtime", paths.guard_status, "guard", 180.0, at),
        "risk": _status_record("Risk 계약", paths.risk_status, "risk_worker", 180.0, at),
        "ws": _status_record("WS 실시간가격", paths.ws_status, "ws_sidecar", 120.0, at),
        "micro": _status_record("Micro 호가·체결", paths.micro_status, "micro_sidecar", 120.0, at),
    }
    request = read_json(paths.review_request, {}) or {}
    review = read_json(paths.review_snapshot, {}) or {}
    standard = read_json(paths.candidate_standard, {}) or {}
    strategy_status = workers["strategy"]["raw"]
    paper_status = workers["paper"]["raw"]
    candidate = mapping(review.get("candidate"))
    source = mapping(review.get("source"))

    generation_id = text(source.get("pipeline_cycle_id"), request.get("pipeline_cycle_id"), request.get("candidate_pipeline_cycle_id_v1150"))
    commit_id = text(source.get("candidate_commit_id"), request.get("candidate_commit_id"), request.get("candidate_commit_id_v1150"))
    strategy_rows = integer(candidate.get("total"), request.get("candidate_rows"), strategy_status.get("paper_latest_count"))
    s1_count = integer(candidate.get("s1"), strategy_status.get("s1_count"))
    paper_received = integer(
        deep_get(paper_status, "pick_stats.paper_generation_candidate_count_v1158"),
        deep_get(paper_status, "pick_stats.paper_candidates_seen"),
        deep_get(paper_status, "pick_stats.latest_count"),
        default=0,
    )
    current_cycle_state = "NORMAL" if generation_id and commit_id and source.get("state") == "NORMAL" else "CHECK"
    stage_rows: List[Dict[str, Any]] = []

    def add(index: int, key: str, label: str, state: str, owner: str, input_count: Any = None, output_count: Any = None, reason: str = "") -> None:
        stage_rows.append({
            "index": index,
            "key": key,
            "label": label,
            "state": state,
            "owner": owner,
            "input": input_count,
            "output": output_count,
            "reason": reason,
        })

    add(1, "exchange", "거래소·네트워크 수신", workers["ws"]["state"], "WS/Micro", None, None, workers["ws"]["reason"])
    add(2, "scanner", "전체시장 Scanner", workers["scanner"]["state"], "scanner_worker")
    add(3, "feature", "Feature 품질값", workers["feature"]["state"], "feature_worker")
    add(4, "candle", "Candle 완료봉 구조", workers["candle"]["state"], "candle_worker")
    add(5, "market", "Market 장세", workers["market"]["state"], "market_regime_worker")
    add(6, "orderflow", "Orderflow 실행비용", workers["orderflow"]["state"], "orderflow_worker")
    add(7, "target", "Target Router 정보배차", workers["target"]["state"], "target_router_worker")
    add(8, "strategy", "Strategy 자료합류·구조판정", workers["strategy"]["state"], "strategy_worker", None, strategy_rows, workers["strategy"]["reason"])
    add(9, "gate", "품질 Gate·Rank", current_cycle_state, "strategy_worker", strategy_rows, strategy_rows)
    add(10, "handoff", "S1·전체후보·우선요청 묶음 전달", current_cycle_state, "strategy_worker", strategy_rows, s1_count)
    add(11, "paper_read", "Paper generation 확인·후보 판독", workers["paper"]["state"], "paper_bot", s1_count, paper_received, workers["paper"]["reason"])
    add(12, "paper_safety", "Paper exact·중복 안전", workers["paper"]["state"], "paper_bot")
    add(13, "selector", "Paper Selector", workers["paper"]["state"], "paper_bot")
    add(14, "open", "OPEN Writer·Commit", workers["paper"]["state"], "paper_bot", None, integer(paper_status.get("opened_this_cycle")))
    add(15, "exit", "보유·Exit Monitor", workers["paper"]["state"], "paper_bot", integer(paper_status.get("open_count"), paper_status.get("open_total")), None)
    add(16, "closed", "CLOSED·Decision Commit", workers["paper"]["state"], "paper_bot")
    perf_state = "NORMAL" if paths.performance.exists() and (file_age(paths.performance, at) or 999999) <= 900 else "CHECK"
    add(17, "performance", "Canonical Performance", perf_state, "paper postprocess owner")
    add(18, "review", "Review·Structure Lab·복기", workers["review"]["state"], "review_worker", strategy_rows, integer(candidate.get("total")), workers["review"]["reason"])
    add(19, "main", "Main 표시·Telegram", workers["main"]["state"], "main_bot", None, None, workers["main"]["reason"])
    add(20, "guard", "Guard runtime·지도 writer", "NORMAL", "guard", None, None, "")

    critical = [row for row in stage_rows if row["state"] in {"FAIL", "CHECK"}]
    overall = "NORMAL" if not critical else ("FAIL" if any(row["state"] == "FAIL" for row in critical) else "CHECK")
    disk = {}
    try:
        stat = os.statvfs(base)
        disk = {
            "free_bytes": stat.f_bavail * stat.f_frsize,
            "total_bytes": stat.f_blocks * stat.f_frsize,
        }
        disk["free_mb"] = round(disk["free_bytes"] / 1024 / 1024, 1)
    except OSError:
        disk = {"free_bytes": None, "total_bytes": None, "free_mb": None}

    snapshot: Dict[str, Any] = {
        "schema": "ops_spine_snapshot_v1181",
        "version": "guard_v2.5.195",
        "generated_ts": at,
        "generated_text": now_text(at),
        "owner": "guard_canonical_ops_spine_writer_v1181",
        "overall_state": overall,
        "auto_buy": False,
        "strategy_mode": STRATEGY_MODE,
        "current_cycle": {
            "state": current_cycle_state,
            "pipeline_cycle_id": generation_id,
            "candidate_commit_id": commit_id,
            "candidate_rows": strategy_rows,
            "s1_count": s1_count,
            "paper_received": paper_received,
            "source_age_sec": source.get("request_age_sec"),
        },
        "last_completed_cycle": {
            "pipeline_cycle_id": generation_id,
            "candidate_commit_id": commit_id,
            "state": current_cycle_state,
            "completed_ts": request.get("committed_handoff_completed_ts") or request.get("created_ts"),
        },
        "stages": stage_rows,
        "problems": [
            {
                "code": f"FLOW-{row['index']:02d}-{row['key'].upper()}",
                "state": row["state"],
                "owner": row["owner"],
                "reason": row["reason"] or "owner status CHECK",
                "impact": "해당 단계 이후 신규 후보·표시 신뢰도 확인 필요",
            }
            for row in critical
        ],
        "timing": {
            "strategy_execution_handoff_sec": strategy_handoff_sec(strategy_status),
            "strategy_full_cycle_sec": strategy_full_cycle_sec(strategy_status),
            "paper_fast_cycle_sec": num(paper_status.get("elapsed_sec"), default=None),
            "review_cycle_sec": num(workers["review"]["raw"].get("last_cycle_sec"), default=None),
        },
        "candidate_standard": {
            "state": standard.get("state"),
            "snapshot_id": standard.get("snapshot_id"),
            "missing": standard.get("missing") or [],
        },
        "workers": {key: {field: value for field, value in item.items() if field != "raw"} for key, item in workers.items()},
        "disk": disk,
        "invariants": {
            "candidate_formula_changed": False,
            "trigger_changed": False,
            "invalid_changed": False,
            "target_changed": False,
            "rr_changed": False,
            "exit_contract_changed": False,
            "auto_buy": False,
            "live_ledger_write": False,
        },
    }
    snapshot["snapshot_id"] = f"ops-{int(at * 1000)}-{digest_obj(snapshot)[:12]}"
    return snapshot


def _runtime_start_for_error_log(base: Path, log_name: str) -> float:
    status_candidates: Dict[str, Sequence[Tuple[str, Sequence[str]]]] = {
        "clean_brain_error.log": (("clean_brain_status.json", ("started_at", "process_started_at")),),
        "clean_strategy_worker_error.log": (("clean_strategy_worker_status.json", ("candidate_process_start_ts_v1026", "process_started_at", "started_at")),),
        "paper_bot_error.log": (("paper_bot_status.json", ("process_started_at", "started_at")),),
        "clean_review_worker_error.log": (
            ("runtime/review_worker_singleton_v1121.lock", ("acquired_ts", "started_at")),
            ("clean_review_worker_status.json", ("process_started_at", "started_at", "last_success_ts")),
        ),
        "clean_guard_error.log": (("clean_guard_runtime_status_v1011.json", ("process_started_at", "started_at")),),
        "ws_sidecar_error.log": (("clean_ws_sidecar_status.json", ("process_started_at", "started_at")),),
    }
    for relative, fields in status_candidates.get(log_name, ()):
        obj = read_json(base / relative, {}) or {}
        if not isinstance(obj, dict):
            continue
        for field in fields:
            value = parse_ts(obj.get(field))
            if value > 0:
                return value
    return 0.0


def safe_error_tail(base: Path, max_lines: int = 80) -> List[str]:
    candidates = [
        base / "clean_brain_error.log",
        base / "clean_strategy_worker_error.log",
        base / "paper_bot_error.log",
        base / "clean_review_worker_error.log",
        base / "clean_guard_error.log",
        base / "ws_sidecar_error.log",
    ]
    out: List[str] = []
    for path in candidates:
        try:
            stat = path.stat()
        except OSError:
            continue
        runtime_start = _runtime_start_for_error_log(base, path.name)
        # A prior-runtime log is evidence history, not a current runtime error.
        if runtime_start > 0 and stat.st_mtime < runtime_start - 0.001:
            continue
        raw = read_text(path, max_bytes=512_000)
        if not raw.strip():
            continue
        for line in raw.splitlines()[-max_lines:]:
            if line.strip():
                out.append(f"[{path.name}] {line.strip()}")
    return out[-max_lines:]


def find_ledger(base: Path, kind: str) -> Optional[Path]:
    names = {
        "issue": (
            "ledger/issue_ledger_events.jsonl", "runtime/issue_ledger_events.jsonl",
            "issue_ledger_events.jsonl", "issue_ledger.jsonl",
        ),
        "change": (
            "runtime/change_verify_ledger.jsonl", "ledger/change_verify_ledger.jsonl",
            "change_verify_ledger.jsonl",
        ),
    }
    for name in names.get(kind, ()):
        path = base / name
        if path.exists():
            return path
    return None
