coinbot update v1195

목적
- Strategy 현재 8초대 시간이 구 20.563초로 가려지는 reader owner 오류 수리
- Review canonical commit 뒤 NoneType 상태오류가 날 수 있는 부분 commit 구조 수리

변경
- canonical_spine_v1186.py
- canonical_spine_v1190.py
- review_worker_v1.018.py

재시작 필요
- Guard: canonical_spine_v1190 재로딩
- Review: v1.018 + canonical_spine_v1186 재로딩
- Main: canonical_spine_v1190 재로딩

변경 없음
- Strategy v1.039
- Paper v1.052
- 매매 기준·차단·원장·청산
- 자동매수 OFF

상태
- 로컬 22/22 PASS
- 서버 적용 전 CHECK_PENDING_DEPLOY
