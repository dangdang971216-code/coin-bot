v1626 rewrites candidate lifecycle and execution refresh bus. Candidate selection flow after source rows unchanged. Auto-buy OFF.
