v2128 적용 ZIP

수정
- 단독/여러 줄 /version_score가 같은 핵심판 추출기와 1회 Telegram 전송 owner 사용
- v2095 고정 표식 제거: 현재 v2107 표식이어도 CLOSED/OPEN/TOP 핵심판 전체 전달
- Strategy 배포 검수는 현재 systemd MainPID·active hash·프로세스가 보유한 kernel flock payload로 즉시 증명
- 첫 completed cycle 상태는 별도 관찰값이며 구 singleton JSON 때문에 65초 대기하거나 중간 FAIL을 만들지 않음
- worker 적용 total 시간을 결과 앞쪽에 표시

미변경
- 후보 품질, Strategy/Paper 매매코드, trigger/invalid/target, RR/목표공간/추격/spread/slippage, 진입·청산, 원장, Shadow, 자동매수 OFF

서버 판정
- Guard v2.6.15와 Main v2.13.2109 실제 runtime 확인 전 CHECK
