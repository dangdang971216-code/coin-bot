코인봇 v1222 · v1211↔현재 구조선 같은 후보 비교감사

1. /gupgrade_bundle 단독 실행
2. 가드·Strategy 재시작 후 새 완료 cycle 대기
3. /gstructure_pairing_audit 실행

정상 증거:
- Strategy 1.051 / Guard 2.5.219
- rows/stage/cycle True
- v1211 exact 후보수 = 전체 후보수
- v1211과 현재의 손절거리·목표공간·RR 중앙값 표시

이 버전은 구조선·기준·진입·청산을 바꾸지 않는다.
자동매수 OFF.
