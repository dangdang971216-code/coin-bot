import importlib.util
import tempfile
import json
import time
import unittest
from pathlib import Path
from unittest import mock

ROOT=Path(__file__).resolve().parent
SOURCE=ROOT/'paper_bot_v1.064.py'
spec=importlib.util.spec_from_file_location('paper_v1207_test',SOURCE)
paper=importlib.util.module_from_spec(spec); assert spec and spec.loader; spec.loader.exec_module(paper)


def evidence(*, state='FULL', support=101.0, strong=4, weak=0, buffer=0.1):
    return {
        'schema':'paper_dynamic_exit_signal_snapshot_v1207','state':state,
        'feature_fresh':state in {'FULL','STRUCTURE_ONLY'},'micro_fresh':state=='FULL',
        'support_candidate_price':support,'support_sources':['recent_low','vwap'] if support else [],
        'support_basis':'two_source_cluster' if support else 'none','break_buffer_pct':buffer,
        'spread_pct':0.1,'fee_pct_roundtrip':0.1,'strength_count':strong,'weakness_count':weak,
        'strength_signals':['s']*strong,'weakness_signals':['w']*weak,
    }


def position(role='general', current=100.0):
    return {
        'ticker':'TEST','entry_price':100.0,'current_price':current,
        'ranked_top10_contract_v1206':{'slot_role':role},
        'exit_contract_v1206':{
            'schema':'alt_swing_exit_contract_v1206','response_protect_enabled':True,
            'response_trigger_net_peak_pct':1.0,'response_floor_net_pct':0.0,
            'entry_failure_structure_line':{'active':False},
        },
        'exit_contract_v1207':{'schema':paper.V1207_DYNAMIC_SCHEMA},
    }


class V1207Tests(unittest.TestCase):
    def test_new_open_seals_dynamic_contract_without_mutating_old_contract(self):
        base={'ticker':'TEST','ranked_top10_contract_v1206':{'slot_role':'runner'},'exit_contract_v1206':{'schema':'alt_swing_exit_contract_v1206'}}
        with mock.patch.object(paper,'_V1207_PREV_OPEN_POSITION',return_value=base.copy()):
            row=paper.open_position__v1207_dynamic_exit('p1',{})
        self.assertEqual(row['exit_contract_v1207']['schema'],paper.V1207_DYNAMIC_SCHEMA)
        self.assertEqual(row['exit_contract_v1207']['slot_role'],'runner')
        self.assertEqual(row['exit_contract_v1206']['schema'],'alt_swing_exit_contract_v1206')

    def test_existing_v1206_open_is_not_migrated(self):
        pos=position(); pos.pop('exit_contract_v1207')
        d=paper._exit_decision_spine__v1207(pos,30.0,1.2,0.0,{'fee_pct_roundtrip':0.1})
        self.assertEqual(d['reason'],'swing_response_protect')
        self.assertNotIn('dynamic_exit_state_v1207',pos)

    def test_strong_structure_suppresses_fixed_breakeven_exit(self):
        pos=position(current=101.5)
        with mock.patch.object(paper,'_v1207_signal_snapshot',return_value=evidence(support=101.0,strong=5,weak=1)):
            d=paper._exit_decision_spine__v1207(pos,30.0,1.2,0.0,{'fee_pct_roundtrip':0.1})
        self.assertEqual(d['action'],'hold')
        self.assertEqual(d['reason'],'dynamic_structure_strength_hold')
        self.assertEqual(d['suppressed_fixed_reason_v1207'],'swing_response_protect')

    def test_general_structure_break_requires_two_confirmations(self):
        pos=position('general',current=100.5)
        ev=evidence(support=101.0,strong=0,weak=4,buffer=0.1)
        with mock.patch.object(paper,'_v1207_signal_snapshot',return_value=ev):
            d1=paper._exit_decision_spine__v1207(pos,40.0,1.5,0.4,{'fee_pct_roundtrip':0.1})
            d2=paper._exit_decision_spine__v1207(pos,40.1,1.5,0.4,{'fee_pct_roundtrip':0.1})
        self.assertNotEqual(d1.get('reason'),'swing_dynamic_structure_break')
        self.assertEqual(d2.get('reason'),'swing_dynamic_structure_break')

    def test_runner_structure_break_requires_three_confirmations(self):
        pos=position('runner',current=100.5)
        ev=evidence(support=101.0,strong=0,weak=4,buffer=0.1)
        with mock.patch.object(paper,'_v1207_signal_snapshot',return_value=ev):
            d1=paper._exit_decision_spine__v1207(pos,40.0,1.5,0.4,{'fee_pct_roundtrip':0.1})
            d2=paper._exit_decision_spine__v1207(pos,40.1,1.5,0.4,{'fee_pct_roundtrip':0.1})
            d3=paper._exit_decision_spine__v1207(pos,40.2,1.5,0.4,{'fee_pct_roundtrip':0.1})
        self.assertNotEqual(d1.get('reason'),'swing_dynamic_structure_break')
        self.assertNotEqual(d2.get('reason'),'swing_dynamic_structure_break')
        self.assertEqual(d3.get('reason'),'swing_dynamic_structure_break')

    def test_stale_evidence_uses_v1206_fallback(self):
        pos=position(current=100.0)
        with mock.patch.object(paper,'_v1207_signal_snapshot',return_value=evidence(state='STALE_OR_MISSING',support=0,strong=0,weak=0)):
            d=paper._exit_decision_spine__v1207(pos,30.0,1.2,0.0,{'fee_pct_roundtrip':0.1})
        self.assertEqual(d['reason'],'swing_response_protect')
        self.assertTrue(d['dynamic_fixed_fallback_used_v1207'])

    def test_support_line_only_ratchets_up(self):
        pos=position(current=103.0)
        with mock.patch.object(paper,'_v1207_signal_snapshot',side_effect=[
            evidence(support=101.0,strong=4,weak=0),
            evidence(support=100.5,strong=4,weak=0),
        ]):
            paper._exit_decision_spine__v1207(pos,10.0,1.5,1.0,{'fee_pct_roundtrip':0.1})
            first=pos['dynamic_exit_state_v1207']['protect_line_price']
            paper._exit_decision_spine__v1207(pos,10.1,1.5,1.0,{'fee_pct_roundtrip':0.1})
            second=pos['dynamic_exit_state_v1207']['protect_line_price']
        self.assertEqual(first,101.0)
        self.assertEqual(second,101.0)

    def test_original_target_still_closes_first(self):
        pos=position(current=110.0)
        pos['swing_target_price_v977']=109.0
        with mock.patch.object(paper,'_v1207_signal_snapshot') as snap:
            d=paper._exit_decision_spine__v1207(pos,20.0,9.9,9.8,{'fee_pct_roundtrip':0.1})
        self.assertEqual(d['reason'],'structure_target')
        snap.assert_not_called()

    def test_live_feature_and_micro_build_two_source_support(self):
        with tempfile.TemporaryDirectory() as td:
            root=Path(td); now=time.time()
            feature=root/'feature.json'; micro=root/'micro.json'
            feature.write_text(json.dumps({'version':'feature-test','updated_ts':now,'rows':[{'ticker':'TEST','feature_ts':now,'vwap_gap_pct':1.0,'ema5_gap_pct':1.1,'relative_strength_pct':2.0,'money_flow_score':60.0,'change_3m_known':True,'change_3m':0.2,'change_5m_known':True,'change_5m':0.3,'recent_low_price':101.0,'swing_low_price':100.8,'support_touch_count':2}]}),encoding='utf-8')
            micro.write_text(json.dumps({'version':'micro-test','updated_ts':now,'rows':{'TEST':{'ticker':'TEST','ts':now,'micro_spread_pct':0.1,'trade_buy_ratio_30':0.60,'bid_ask_wall_ratio':1.2}}}),encoding='utf-8')
            paper.V1207_FEATURE_CACHE=feature; paper.V1207_MICRO_CACHE=micro
            paper._V1207_CACHE={'feature':{'mtime_ns':-1,'root':{},'rows':{}},'micro':{'mtime_ns':-1,'root':{},'rows':{}}}
            pos=position(current=102.5)
            ev=paper._v1207_signal_snapshot(pos,{'fee_pct_roundtrip':0.1})
        self.assertEqual(ev['state'],'FULL')
        self.assertGreater(ev['support_candidate_price'],100.0)
        self.assertGreaterEqual(ev['strength_count'],4)

    def test_stale_sources_do_not_create_weakness(self):
        with tempfile.TemporaryDirectory() as td:
            root=Path(td); old=time.time()-300
            feature=root/'feature.json'; micro=root/'micro.json'
            feature.write_text(json.dumps({'version':'feature-test','updated_ts':old,'rows':[{'ticker':'TEST','feature_ts':old,'vwap_gap_pct':-5.0,'ema5_gap_pct':-5.0,'money_flow_score':0.0}]}),encoding='utf-8')
            micro.write_text(json.dumps({'version':'micro-test','updated_ts':old,'rows':{'TEST':{'ticker':'TEST','ts':old,'trade_buy_ratio_30':0.0,'bid_ask_wall_ratio':0.0,'sell_trade_pressure':True}}}),encoding='utf-8')
            paper.V1207_FEATURE_CACHE=feature; paper.V1207_MICRO_CACHE=micro
            paper._V1207_CACHE={'feature':{'mtime_ns':-1,'root':{},'rows':{}},'micro':{'mtime_ns':-1,'root':{},'rows':{}}}
            ev=paper._v1207_signal_snapshot(position(current=100.0),{'fee_pct_roundtrip':0.1})
        self.assertEqual(ev['state'],'STALE_OR_MISSING')
        self.assertEqual(ev['weakness_count'],0)
        self.assertIn('feature_live_structure',ev['source_missing'])


if __name__=='__main__': unittest.main(verbosity=2)
