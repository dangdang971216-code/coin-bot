import importlib.util
import json
import math
import pathlib
import sys
import tempfile
import time
import unittest
from unittest import mock

ROOT = pathlib.Path(__file__).resolve().parent


def load(name: str, path: pathlib.Path):
    spec = importlib.util.spec_from_file_location(name, path)
    mod = importlib.util.module_from_spec(spec)
    assert spec and spec.loader
    sys.modules[name] = mod
    spec.loader.exec_module(mod)
    return mod


OLD = load('strategy_v1216_stale_blob_baseline', ROOT / 'baselines' / 'strategy_worker_v1.046_v1216_stale_blob.py')
NEW = load('strategy_v1217_tests', ROOT / 'baselines' / 'strategy_worker_v1.047_v1217_ceiling_failure.py')
GUARD = load('guard_v1217_tests', ROOT / 'baselines' / 'backga_guard_bot_v2_5_214_v1217.py')


def frame(n: int, center: float, amp: float, step: int):
    now = time.time()
    out = []
    for i in range(n):
        base = center + amp * math.sin(i * math.pi / 3.0)
        out.append([
            now - (n - i) * step,
            base - amp * 0.08,
            base + amp * 0.08,
            base + amp * 0.30,
            base - amp * 0.30,
            1000.0 * (1.7 if i % 6 == 1 else 1.0),
        ])
    return out


def candle_lab():
    return {'frames': {
        'm5': frame(120, 100.7, 0.7, 300),
        'm15': frame(40, 100.7, 0.7, 900),
        'm30': frame(160, 101.0, 2.0, 1800),
        'h1': frame(192, 101.0, 2.0, 3600),
        'h2': frame(96, 101.0, 2.4, 7200),
        'h4': frame(48, 101.0, 2.4, 14400),
    }}


def source_row(mod, price: float = 130.0, ticker: str = 'TEST', cycle: str = 'strategy-test-v1217'):
    row = {
        'ticker': ticker,
        'current_price': price,
        'spread_pct': 0.08,
        'entry_slippage_confirmed': True,
        'entry_slippage_owner': 'orderflow_worker',
        'entry_slippage_source': 'best_ask_reference_orderflow_v1100',
        'entry_slippage_est_pct': 0.05,
        'fee_pct_roundtrip': 0.08,
        'relative_strength_rank_pct_v1095': 70,
        'relative_strength_pct': 1.0,
        'money_flow_score': 65,
        'market_regime_score': 60,
        'candidate_pipeline_cycle_id_v1150': cycle,
        '_dynamic_structure_candle_material_v1215': candle_lab(),
    }
    plan = mod._v925_current_actual_plan(row)
    row.pop('_dynamic_structure_candle_material_v1215', None)
    row['dynamic_structure_plan_v1212'] = plan
    row['structure_contract_v1212'] = plan
    row['dynamic_structure_material_evidence_v1215'] = {
        'schema': 'dynamic_structure_material_evidence_v1215',
        'link_mode': plan.get('material_link_mode_v1215'),
        'frame_counts': dict(plan.get('frame_counts_v1215') or {}),
    }
    row['s_stage'] = 'S3' if plan.get('selection_diagnostics_v1216', {}).get('missing_axes') else 'S2'
    row['swing_entry_gate_v977'] = {
        'schema': 'swing_entry_gate_v977',
        'hard_block_reasons': ['dynamic_structure_source_missing'] if row['s_stage'] == 'S3' else [],
    }
    return row


class CandidateBlobPersistenceTests(unittest.TestCase):
    def test_root_cause_old_cached_blob_omits_final_wrapper_fields(self):
        row = source_row(OLD)
        compact, encoded, _, _ = OLD._v1194_build_candidate_publish_views([row], time.time())
        written = json.loads(encoded[0])
        self.assertIn('dynamic_structure_plan_v1212', compact[0])
        self.assertNotIn('dynamic_structure_plan_v1212', written)
        self.assertNotIn('dynamic_structure_material_evidence_v1215', written)

    def test_v1217_final_cached_blob_matches_final_compact_object(self):
        row = source_row(NEW)
        compact, encoded, sizes, _ = NEW._v1194_build_candidate_publish_views([row], time.time())
        written = json.loads(encoded[0])
        self.assertEqual(written, compact[0])
        self.assertEqual(sizes[0], len(encoded[0]))
        self.assertTrue(written['candidate_structure_diagnostic_persisted_v1217'])
        self.assertIn('selection_diagnostics_v1216', written['dynamic_structure_plan_v1212'])
        self.assertIn('dynamic_structure_material_evidence_v1215', written)

    def test_final_evidence_is_budgeted_before_optional_fields(self):
        row = source_row(NEW)
        for i in range(80):
            row[f'optional_noise_{i:03d}'] = 'x' * 400
        compact, encoded, sizes, _ = NEW._v1194_build_candidate_publish_views([row], time.time())
        saved = json.loads(encoded[0])
        self.assertLessEqual(sizes[0], NEW.V1020_ROW_HARD_CEILING_BYTES)
        self.assertIn('dynamic_structure_plan_v1212', saved)
        self.assertIn('selection_diagnostics_v1216', saved['dynamic_structure_plan_v1212'])
        self.assertTrue(saved['candidate_structure_diagnostic_persisted_v1217'])
        self.assertEqual(saved, compact[0])

    def test_encoded_evidence_contract_counts_expected_compact_and_blob(self):
        rows = [source_row(NEW, 130.0, 'AAA'), source_row(NEW, 101.0, 'BBB')]
        compact, encoded, _, _ = NEW._v1194_build_candidate_publish_views(rows, time.time())
        contract = NEW._v1217_candidate_encoded_evidence_contract(rows, compact, encoded)
        self.assertTrue(contract['candidate_encoded_evidence_exact_v1217'])
        self.assertEqual(contract['candidate_expected_diag_rows_v1217'], 2)
        self.assertEqual(contract['candidate_compact_diag_rows_v1217'], 2)
        self.assertEqual(contract['candidate_encoded_diag_rows_v1217'], 2)

    def test_atomic_candidate_writer_persists_diagnostic_and_writer_proof(self):
        with tempfile.TemporaryDirectory() as td:
            base = pathlib.Path(td)
            output = base / 'paper_candidates_latest.jsonl'
            status_path = base / 'clean_strategy_paper_latest_writer_status.json'
            lite_path = base / 'clean_candidate_latest_snapshot.json'
            io_path = base / 'clean_strategy_io_status_v1021.json'
            row = source_row(NEW)
            # Isolate process counters and paths for an end-to-end atomic write.
            with mock.patch.object(NEW, 'PAPER_LATEST_WRITER_STATUS_V861', status_path), \
                 mock.patch.object(NEW, 'CANDIDATE_LITE_SNAPSHOT', lite_path), \
                 mock.patch.object(NEW, 'STRATEGY_IO_STATUS_V1021', io_path):
                NEW._V1026_COUNTER_STATE_LOADED = False
                NEW._V1026_TOTAL_COMMIT_COUNT = 0
                NEW._V1026_TOTAL_COMMIT_RECORDED = False
                NEW._V1026_PROCESS_COMMIT_COUNT = 0
                result = NEW._v1021_publish_candidate_snapshot(output, [row], {})
            saved = json.loads(output.read_text(encoding='utf-8').strip())
            status = json.loads(status_path.read_text(encoding='utf-8'))
            self.assertIn('selection_diagnostics_v1216', saved['dynamic_structure_plan_v1212'])
            self.assertTrue(saved['candidate_structure_diagnostic_persisted_v1217'])
            self.assertTrue(result['candidate_encoded_evidence_exact_v1217'])
            self.assertTrue(status['candidate_encoded_evidence_exact_v1217'])
            self.assertEqual(status['candidate_expected_diag_rows_v1217'], 1)
            self.assertEqual(status['candidate_encoded_diag_rows_v1217'], 1)

    def test_guard_reads_same_cycle_persisted_diagnostics_and_writer_proof(self):
        with tempfile.TemporaryDirectory() as td:
            base = pathlib.Path(td)
            cycle = 'strategy-guard-v1217'
            row = source_row(NEW, 130.0, 'AAA', cycle)
            compact, encoded, _, _ = NEW._v1194_build_candidate_publish_views([row], time.time())
            (base / 'paper_candidates_latest.jsonl').write_bytes(encoded[0] + b'\n')
            (base / 'clean_strategy_swing_gate_status_v977.json').write_text(json.dumps({
                'rows': 1, 'pass_s1': 0, 'recheck_s2': 0, 'observe_s3': 1,
                'hard_reason_top': [{'reason': 'dynamic_structure_source_missing', 'count': 1}],
            }), encoding='utf-8')
            contract = NEW._v1217_candidate_encoded_evidence_contract([row], compact, encoded)
            writer = {
                'rows_written': 1,
                'candidate_snapshot_scope': {
                    'rows_written': 1,
                    'pipeline_cycle_id_v1150': cycle,
                    'commit_id': 'candidate-v1217-test',
                },
                **contract,
            }
            (base / 'clean_strategy_paper_latest_writer_status.json').write_text(json.dumps(writer), encoding='utf-8')
            with mock.patch.object(GUARD, 'BOT_DIR', base):
                report = GUARD.collect_structure_missing_exact_audit_v1216()
            self.assertEqual(report['verdict'], 'PROVEN_SELECTION_FILTER_EMPTY')
            self.assertEqual(report['diagnostic_ready_rows'], 1)
            self.assertEqual(report['diagnostic_missing_rows'], 0)
            writer_proof = report['source']['writer_evidence_v1217']
            self.assertTrue(writer_proof['exact'])
            self.assertEqual(writer_proof['expected_diag'], 1)
            self.assertEqual(writer_proof['encoded_diag'], 1)

    def test_trading_formula_outputs_unchanged_from_v1216(self):
        old = source_row(OLD, 130.0, 'SAME')['dynamic_structure_plan_v1212']
        new = source_row(NEW, 130.0, 'SAME')['dynamic_structure_plan_v1212']
        old.pop('selection_diagnostics_v1216', None)
        new.pop('selection_diagnostics_v1216', None)
        self.assertEqual(old, new)
        self.assertEqual(NEW.VERSION, 'strategy_worker_v1.047')
        self.assertIn('v1217_candidate_final_blob_evidence_persistence', NEW.BUILD_LABEL)


if __name__ == '__main__':
    unittest.main(verbosity=2)
