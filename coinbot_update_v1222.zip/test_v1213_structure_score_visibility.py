import importlib.util
import pathlib
import sys
import time
import unittest
from unittest import mock

ROOT = pathlib.Path(__file__).resolve().parent

def load(name, filename):
    spec = importlib.util.spec_from_file_location(name, ROOT / filename)
    mod = importlib.util.module_from_spec(spec)
    assert spec and spec.loader
    sys.modules[name] = mod
    spec.loader.exec_module(mod)
    return mod

PAPER = load('paper_v1213_tests', 'paper_bot_v1.064.py')
MAIN = load('main_v1213_tests', 'coinbot_main_v2_13_1143.py')

class StructureScoreVisibilityTests(unittest.TestCase):
    def test_release_identity(self):
        self.assertEqual(PAPER.VERSION, 'paper_bot_v1.064')
        self.assertEqual(MAIN.BOT_VERSION, '수익형 v2.13.1143')
        self.assertIn('v1213', PAPER.BUILD_LABEL)
        self.assertIn('v1215', MAIN.BUILD_LABEL)

    def test_empty_changed_cohort_is_always_materialized(self):
        now = time.time()
        rows = [{
            'structure_contract_version': 'structure_contract_v1211_legacy',
            'opened_at': now - 3600, 'closed_at': now - 100,
            'pnl_pct': 1.0, 'mfe_pct': 1.5, 'mae_pct': -0.2,
            'giveback_pct': 0.5, 'hold_sec': 1800,
        }]
        root = PAPER._v1213_contract_stats(rows, now)
        contracts = root['contracts']
        self.assertIn('structure_contract_v1211_legacy', contracts)
        self.assertIn('structure_contract_v1212_dynamic_zones', contracts)
        self.assertEqual(contracts['structure_contract_v1211_legacy']['windows']['all']['n'], 1)
        self.assertEqual(contracts['structure_contract_v1212_dynamic_zones']['windows']['all']['n'], 0)
        self.assertTrue(contracts['structure_contract_v1212_dynamic_zones']['collecting'])

    def test_comparison_scope_excludes_operator_reset(self):
        now = time.time()
        rows = [
            {'structure_contract_version':'structure_contract_v1211_legacy','opened_at':now-5000,'closed_at':now-100,'pnl_pct':1.0},
            {'structure_contract_version':'structure_contract_v1211_legacy','opened_at':now-5000,'closed_at':now-100,'pnl_pct':-1.0,'operator_book_reset_v1045':True},
        ]
        snap = {'rows': rows, 'windows': {}, 'window_counts': {}, 'counts': {}, 'invariants': {}}
        with mock.patch.object(PAPER, '_V1213_PREV_APPLY_PERFORMANCE_EPOCH', side_effect=lambda s,n,a=None:s), \
             mock.patch.object(PAPER, '_v1045_epoch', return_value={}):
            out = PAPER._v1045_apply_performance_epoch_contract__v1213(snap, now, {})
        comparison = out['contract_performance_v1213']
        self.assertEqual(comparison['rows'], 1)
        self.assertEqual(comparison['contracts']['structure_contract_v1211_legacy']['windows']['all']['n'], 1)

    def test_compact_and_full_render_show_plain_labels_and_zero_panel(self):
        now = time.time()
        root = PAPER._v1213_contract_stats([], now)
        snapshot = {
            'snapshot_id':'test','generated_at':now,'generated_at_text':'test','source_owner':'paper',
            'contract_performance_v1213':root,'contract_performance_v1212':root,
            'windows':{},'counts':{},'performance_epoch_v1045':{'current_open_count':0},
            'invariants':{},
        }
        with mock.patch.object(MAIN, '_performance_snapshot', return_value=snapshot), \
             mock.patch.object(MAIN, 'file_age', return_value=1.0):
            compact = MAIN.render_version_score_compact(())
            full = MAIN.render_version_score(())
        for text in (compact, full):
            self.assertIn('[이전 구조선 · OPEN 당시 계약 기준]', text)
            self.assertIn('[구조선 변경 후 · OPEN 당시 계약 기준]', text)
            self.assertIn('아직 종료된 거래 0건 · 표본 수집 중', text)
            self.assertNotIn('새 구조선 v1212', text)
            self.assertNotIn('이전 구조선 v1211', text)
            self.assertIn('최근 3시간', text)
            self.assertIn('20-23시', text)

if __name__ == '__main__':
    unittest.main(verbosity=2)
