import importlib.util
import json
import math
import pathlib
import sys
import tempfile
import time
import unittest
from unittest import mock

ROOT = pathlib.Path(__file__).resolve().parent

def load(name, filename):
    spec = importlib.util.spec_from_file_location(name, ROOT / filename)
    mod = importlib.util.module_from_spec(spec)
    assert spec and spec.loader
    sys.modules[name] = mod
    spec.loader.exec_module(mod)
    return mod

STRATEGY = load('strategy_v1215_tests', 'baselines/strategy_worker_v1.047_v1217_ceiling_failure.py')
SPINE1187 = load('spine1187_v1215_tests', 'canonical_spine_v1187.py')
SPINE1190 = load('spine1190_v1215_tests', 'canonical_spine_v1190.py')
MAIN = load('main_v1215_tests', 'coinbot_main_v2_13_1143.py')


def frame(n, center, amp, step):
    now = time.time()
    out = []
    for i in range(n):
        base = center + amp * math.sin(i * math.pi / 3.0)
        out.append([now-(n-i)*step, base-amp*.08, base+amp*.08, base+amp*.30, base-amp*.30, 1000.0*(1.7 if i % 6 == 1 else 1.0)])
    return out


def candle_lab():
    return {'frames': {
        'm5': frame(120, 100.7, .7, 300),
        'm15': frame(40, 100.7, .7, 900),
        'm30': frame(160, 101.0, 2.0, 1800),
        'h1': frame(192, 101.0, 2.0, 3600),
        'h2': frame(96, 101.0, 2.4, 7200),
        'h4': frame(48, 101.0, 2.4, 14400),
    }}


def base_row(ticker='TEST'):
    return {
        'ticker': ticker, 'current_price': 101.0, 'spread_pct': 0.08,
        'entry_slippage_confirmed': True, 'entry_slippage_owner': 'orderflow_worker',
        'entry_slippage_source': 'best_ask_reference_orderflow_v1100', 'entry_slippage_est_pct': 0.05,
        'fee_pct_roundtrip': 0.08, 'relative_strength_rank_pct_v1095': 70,
        'relative_strength_pct': 1.0, 'money_flow_score': 65, 'market_regime_score': 60,
    }


class DynamicMaterialRepairTests(unittest.TestCase):
    def test_release_identity(self):
        self.assertEqual(STRATEGY.VERSION, 'strategy_worker_v1.047')
        self.assertEqual(MAIN.BOT_VERSION, '수익형 v2.13.1143')
        self.assertIn('v1217', STRATEGY.BUILD_LABEL)
        self.assertIn('v1215', MAIN.BUILD_LABEL)

    def test_canonical_candle_map_reaches_dynamic_plan(self):
        row = base_row()
        rows, summary = STRATEGY._v1215_attach_dynamic_structure_material(
            [row], {'TEST': {'structure_lab_candles': candle_lab()}}
        )
        plan = STRATEGY._v925_current_actual_plan(rows[0])
        self.assertEqual(summary['dynamic_structure_material_linked_rows_v1215'], 1)
        self.assertEqual(summary['dynamic_structure_material_missing_rows_v1215'], 0)
        self.assertTrue(plan.get('trigger'))
        self.assertTrue(plan.get('invalid'))
        self.assertTrue(plan.get('target'))
        self.assertEqual(plan.get('material_link_mode_v1215'), 'candle_map_ephemeral_reference')
        self.assertEqual(plan.get('frame_counts_v1215', {}).get('h4'), 48)

    def test_private_candle_reference_is_not_serialized_but_evidence_is(self):
        row = base_row()
        row['_dynamic_structure_candle_material_v1215'] = candle_lab()
        row['dynamic_structure_material_evidence_v1215'] = {'link_mode': 'candle_map_ephemeral_reference'}
        row['legacy_s3_observation_retired_v1215'] = True
        out = STRATEGY._v861_compact_row_for_latest(row)
        self.assertNotIn('_dynamic_structure_candle_material_v1215', out)
        self.assertEqual(out['dynamic_structure_material_evidence_v1215']['link_mode'], 'candle_map_ephemeral_reference')
        self.assertTrue(out['legacy_s3_observation_retired_v1215'])

    def test_legacy_s3_label_no_longer_becomes_current_source_owned_block(self):
        legacy = {'s3_observe_v732': True, 'strategy_key': 'coin_quality_s3_observe'}
        self.assertTrue(STRATEGY._v988_is_s3_observation_only(legacy))
        self.assertFalse(STRATEGY._v1215_explicit_observation_only_source(legacy))
        legacy['current_cycle_observation_only_v1215'] = False
        self.assertFalse(STRATEGY._v988_is_s3_observation_only(legacy))
        explicit = {'explicit_observation_only_v1215': True, 'observation_role_owner': 'scanner_explicit_alert_lane'}
        self.assertTrue(STRATEGY._v1215_explicit_observation_only_source(explicit))

    def test_no_threshold_or_exit_contract_change(self):
        src = (ROOT / 'baselines' / 'strategy_worker_v1.047_v1217_ceiling_failure.py').read_text(encoding='utf-8')
        self.assertIn("'thresholds_changed_v1215':False", src)
        self.assertIn("row['exit_changed_v925']=False", src)
        self.assertNotIn("row['exit_changed_v925']=True", src)
        self.assertIn("'serialized_to_candidate_v1215':False", src)


class TruthBoardTests(unittest.TestCase):
    def write_json(self, path, obj):
        path.write_text(json.dumps(obj, ensure_ascii=False), encoding='utf-8')

    def write_jsonl(self, path, rows):
        with path.open('w', encoding='utf-8') as fh:
            for row in rows:
                fh.write(json.dumps(row, ensure_ascii=False) + '\n')

    def test_review_counts_structure_over_all_rows_not_s1_only(self):
        with tempfile.TemporaryDirectory() as td:
            base = pathlib.Path(td)
            rows = [
                {
                    'ticker': 'AAA', 's_stage': 'S3',
                    'swing_trigger_price_v977': 101, 'swing_invalid_price_v977': 95, 'swing_target_price_v977': 115,
                    'swing_trigger_source_v977': 'm5_zone', 'swing_invalid_source_v977': 'h1_zone', 'swing_target_source_v977': 'h4_zone',
                    'dynamic_structure_material_evidence_v1215': {'link_mode':'candle_map_ephemeral_reference','frame_counts':{'m5':10,'h4':10}},
                    'legacy_s3_observation_retired_v1215': True,
                    'swing_entry_gate_v977': {'stage':'S3','hard_block_reasons':['frozen_trigger_not_reached']},
                },
                {
                    'ticker': 'BBB', 's_stage': 'S3',
                    'dynamic_structure_material_evidence_v1215': {'link_mode':'SOURCE_MISSING','frame_counts':{}},
                    'swing_entry_gate_v977': {'stage':'S3','hard_block_reasons':['dynamic_structure_source_missing']},
                },
            ]
            self.write_jsonl(base/'paper_candidates_latest.jsonl', rows)
            self.write_json(base/'review_observation_request_v1181.json', {'pipeline_cycle_id':'c1','candidate_commit_id':'k1','candidate_rows':2,'created_ts':time.time()})
            self.write_json(base/'clean_strategy_swing_gate_status_v977.json', {'rows':2,'observation_only_blocked_v988':0})
            snap = SPINE1187.build_review_snapshot(base)
            self.assertEqual(snap['candidate']['s1'], 0)
            self.assertEqual(snap['structure']['evaluated'], 2)
            self.assertEqual(snap['structure']['complete'], 1)
            self.assertEqual(snap['structure']['source_missing'], 1)
            self.assertEqual(snap['structure_s1']['evaluated'], 0)
            self.assertEqual(snap['reason_accounting']['legacy_s3_labels_retired_v1215'], 1)
            self.assertEqual(snap['reason_accounting']['hard_reason_top']['dynamic_structure_source_missing'], 1)

    def test_ops_map_marks_all_dynamic_structure_missing_as_partial(self):
        with tempfile.TemporaryDirectory() as td:
            base = pathlib.Path(td)
            self.write_json(base/'clean_strategy_swing_gate_status_v977.json', {
                'rows':463,'pass_s1':0,'recheck_s2':0,'observe_s3':463,
                'dynamic_structure_material_linked_rows_v1215':0,
                'dynamic_structure_material_missing_rows_v1215':463,
                'legacy_observation_labels_retired_v1215':209,
                'hard_reason_top':[{'reason':'dynamic_structure_source_missing','count':463}],
            })
            self.write_json(base/'strategy_candidate_pipeline_commit_v1150.json', {
                'state':'NORMAL','complete':True,'cycle_id':'c1','candidate_commit_id':'k1','candidate_rows':463,'s1_hold_count':0,
                'all_required_commits_v1150':True,'committed_handoff_file_v1158':'x',
            })
            snap = SPINE1190.build_ops_snapshot(base)
            health = snap['strategy_gate_health_v1215']
            self.assertEqual(health['state'], 'PARTIAL')
            self.assertEqual(health['entry_impact'], '신규 진입 불가')
            self.assertEqual(health['legacy_s3_labels_retired'], 209)
            self.assertIn('Strategy', health['stopped_at'])
            self.assertEqual(snap['evidence_groups']['candidate_pipeline'], 'PARTIAL')

    def test_candidate_board_shows_all_scope_contract_and_fixed_wording(self):
        candidate = {
            'state':'PARTIAL_SOURCE','easy_state':'일부 근거 누락','missing':['structure_source'],
            'delivery':{'pipeline_cycle_id':'c1','candidate_commit_id':'k1'},
            'candidate':{'total':463,'s1':0,'s2':0,'s3':463},
            'structure':{'evaluated':463,'complete':0,'source_missing':463,'material_linked':0,'material_missing':463,'trigger_source_missing':463,'invalid_source_missing':463,'target_source_missing':463},
            'structure_s1':{'evaluated':0,'complete':0,'source_missing':0},
            'reason_accounting':{'hard_reason_top':{'dynamic_structure_source_missing':463},'legacy_s3_labels_retired_v1215':209,'explicit_observation_only_blocked_v1215':0},
            'quality':{'state':'COLLECTING','invalid_distance':{},'chase':{},'score_components':{},'metric_missing_counts':{}},
            'time':{},'performance':{},'contract':{},
            'selection_contract_v1215':{'ranking':'all executable S1 rows compete by global score','zero_entry_allowed':True},
            'contract_changes_since_v1211':{'dynamic_trigger':True,'dynamic_invalid':True,'dynamic_target':True,'global_ranking':True,'strategy_quota_removed':True,'runner_reservation_removed':True,'exit_contract_changed':False},
            'v1215_change_scope':{'dynamic_material_connection_repaired':True,'legacy_s3_label_as_permanent_block_removed':True,'atr_rr_thresholds_changed':False,'trigger_invalid_target_formula_changed':False},
        }
        contract = {'schema':'paper_active_trade_contract_v1208','entry':{'total_cap':10,'cycle_new_open_cap':2,'state':'NORMAL'},'exit':{'state':'v1207'}}
        with mock.patch.object(MAIN,'_candidate_snapshot',return_value=candidate), mock.patch.object(MAIN,'_active_contract_snapshot',return_value=contract):
            text = MAIN.render_candidate_standard(())
        self.assertIn('후보·구조 기준판 v1215', text)
        self.assertIn('평가 463 / 근거완전 0 / source missing 463', text)
        self.assertIn('S1 구조선 · 별도 범위', text)
        self.assertIn('전략별 자리 없음 / Runner 예약 0', text)
        self.assertNotIn('일반 10 / 대수익 1', text)
        self.assertIn('동적 Trigger True', text)

    def test_flow_map_shows_actual_stop_and_impact(self):
        ops = {
            'overall_state':'PARTIAL','current_cycle':{'state':'NORMAL','candidate_rows':463,'s1_count':0,'paper_received':463,'pipeline_cycle_id':'c1','candidate_commit_id':'k1'},
            'last_completed_cycle':{},'timing':{},'timing_path':{},'evidence_groups':{},'errors':{},'resources':{},'problems':[],
            'strategy_gate_health_v1215':{'state':'PARTIAL','easy_state':'동적 구조선 생성 실패 · 신규 진입 불가','stopped_at':'Strategy 자료합류 → 동적 Trigger·Invalid·Target 생성','entry_impact':'신규 진입 불가'},
        }
        with mock.patch.object(MAIN,'_ops_snapshot',return_value=ops), mock.patch.object(MAIN,'_active_contract_snapshot',return_value={}):
            text = MAIN.render_flow_map_compact(())
        self.assertIn('동적 구조선 생성 실패', text)
        self.assertIn('멈춘 위치', text)
        self.assertIn('신규 진입 불가', text)


if __name__ == '__main__':
    unittest.main(verbosity=2)
