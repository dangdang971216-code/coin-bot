import importlib.util
import json
import pathlib
import sys
import tempfile
import unittest
from unittest import mock

ROOT = pathlib.Path(__file__).resolve().parent


def load(name, filename):
    spec = importlib.util.spec_from_file_location(name, ROOT / filename)
    mod = importlib.util.module_from_spec(spec)
    assert spec and spec.loader
    sys.modules[name] = mod
    spec.loader.exec_module(mod)
    return mod


STRATEGY = load('strategy_v1221_tests', 'strategy_worker_v1.051.py')
GUARD = load('guard_v1221_tests', 'backga_guard_bot_v2_5_219.py')


def zone(side, tf, low, high, score=80.0):
    return {
        'side': side, 'tf': tf, 'price': (low + high) / 2.0,
        'zone_low': low, 'zone_high': high, 'score': score,
        'touch_count': 3, 'source': f'test.{tf}', 'atr_pct': 1.0,
        'gap_pct': 0.0,
    }


def plan(trigger=100.0, invalid=95.0, target=110.0):
    def line(role, price):
        return {
            'role': role, 'raw_price': price, 'rounded_price': price,
            'tf': 'm5' if role == 'execution' else ('m30' if role == 'setup' else 'h1'),
            'source': 'test', 'source_key': 'test',
        }
    return {
        'schema': 'alt_swing_dynamic_structure_plan_v1212',
        'structure_contract_version': 'structure_contract_v1212_dynamic_zones',
        'structure_contract_hash': 'test-hash',
        'trigger': line('execution', trigger),
        'invalid': line('setup', invalid),
        'target': line('target', target),
        'dynamic_chase_limit_pct': 0.8,
        'structure_quality_score': 80.0,
        'target_reachability_score': 80.0,
        'material_link_mode_v1215': 'candle_map_ephemeral_reference',
        'frame_counts_v1215': {'m5': 20, 'm15': 20, 'm30': 20, 'h1': 20, 'h2': 20, 'h4': 20},
        'material_source_state_v1215': 'NORMAL',
        'material_analysis_ready_v1215': True,
    }


class TargetContractTests(unittest.TestCase):
    def _dynamic_plan(self, target_low):
        trigger_zone = zone('resistance', 'm5', 99.8, 100.0)
        invalid_zone = zone('support', 'm30', 97.0, 97.2)
        target_zone = zone('resistance', 'm30', target_low, target_low + 0.20)

        def fake_zones(rows, tf, side, price):
            if tf == 'm5' and side == 'resistance':
                return [trigger_zone]
            if tf == 'm30' and side == 'support':
                return [invalid_zone]
            if tf == 'm30' and side == 'resistance':
                return [target_zone]
            return []

        row = {'ticker': 'TEST', 'current_price': 99.95}
        with mock.patch.object(STRATEGY, '_v1212_frame_rows', return_value=[1] * 10), \
             mock.patch.object(STRATEGY, '_v1212_atr_pct', return_value=1.0), \
             mock.patch.object(STRATEGY, '_v1212_zone_candidates', side_effect=fake_zones), \
             mock.patch.object(STRATEGY, '_v1212_cost_inputs', return_value={
                 'spread_pct': 0.04, 'slippage_pct': 0.02, 'fee_pct': 0.08,
                 'estimated_roundtrip_cost_pct': 0.10, 'complete': True,
             }), \
             mock.patch.object(STRATEGY, '_v1212_strength_factor', return_value=1.0):
            return STRATEGY._v925_current_actual_plan(row)

    def test_actual_resistance_is_sealed_without_pre_capture_shift(self):
        result = self._dynamic_plan(100.20)
        self.assertTrue(result.get('target'))
        self.assertGreater(result['target']['rounded_price'], result['trigger']['rounded_price'])
        self.assertAlmostEqual(result['target']['raw_price'], 100.20, places=8)
        diag = result['selection_diagnostics_v1216']['target']
        self.assertFalse(diag['capture_applied_to_target_v1221'])
        self.assertEqual(diag['capture_role_v1221'], 'audit_only_not_applied_to_structural_target')
        self.assertEqual(result['target_contract_role_v1221'], 'actual_structural_resistance_not_pre_capture_price')

    def test_no_farther_target_is_invented_and_no_new_wait_state(self):
        result = self._dynamic_plan(101.50)
        self.assertEqual(result.get('target_mode_v1212'), 'nearest_actual_resistance')
        self.assertAlmostEqual(result['target']['raw_price'], 101.50, places=8)
        src = (ROOT / 'strategy_worker_v1.051.py').read_text(encoding='utf-8')
        self.assertNotIn('REFORMATION_WAIT', src)
        self.assertNotIn('target_nearest_resistance_too_close_after_capture', src)


class EntryLifecycleTests(unittest.TestCase):
    def _run_gate(self, price):
        row = {
            'ticker': 'TEST', 'current_price': price, 'spread_pct': 0.05,
            'candidate_pipeline_cycle_id_v1150': 'cycle-test',
            'entry_build_key': 'event-test',
        }
        occurrence = {
            'event_ts': 1000.0 if price >= 100.0 else None,
            'decision_key': 'decision-test' if price >= 100.0 else None,
            'kind': 'REBREAK' if price >= 100.0 else 'WAIT',
        }
        patches = [
            mock.patch.object(STRATEGY, '_v925_read_gate_state', return_value=({}, 'ok')),
            mock.patch.object(STRATEGY, '_v1208_hot_watch_by_ticker', return_value={}),
            mock.patch.object(STRATEGY, '_v1208_seal_owner_evidence', return_value=None),
            mock.patch.object(STRATEGY, '_v988_is_s3_observation_only', return_value=False),
            mock.patch.object(STRATEGY, '_v1215_explicit_observation_only_source', return_value=False),
            mock.patch.object(STRATEGY, '_v925_quality_observation', return_value={'extreme_quality_risk_tags': []}),
            mock.patch.object(STRATEGY, '_v925_structure_context', return_value={}),
            mock.patch.object(STRATEGY, 'minimal_gate_state_key', return_value='TEST'),
            mock.patch.object(STRATEGY, '_v1048_structure_integrity', return_value={'blocked': False, 'refresh_required': False}),
            mock.patch.object(STRATEGY, '_v925_current_actual_plan', return_value=plan()),
            mock.patch.object(STRATEGY, '_v1039_execution_freshness', return_value={'execution_fresh_ok': True}),
            mock.patch.object(STRATEGY, '_v925_slippage_confirmed', return_value=(0.02, 'best_ask_reference_orderflow_v1100')),
            mock.patch.object(STRATEGY, '_swing_quality_gate', return_value={'hard_pass': True, 'block_reasons': [], 'score_components': {}, 'rank_score': 80.0}),
            mock.patch.object(STRATEGY, '_v1037_trigger_occurrence', return_value=(occurrence, 'decision-test' if price >= 100.0 else '')),
            mock.patch.object(STRATEGY, '_v925_write_gate_state', return_value={'active_count': 1, 'pruned_this_cycle': 0}),
            mock.patch.object(STRATEGY, 'save_json', return_value=None),
        ]
        with patches[0], patches[1], patches[2], patches[3], patches[4], patches[5], patches[6], patches[7], patches[8], patches[9], patches[10], patches[11], patches[12], patches[13], patches[14]:
            out, status = STRATEGY.apply_swing_entry_gate__v1177_current_cycle([row], 2000.0)
        return out[0], status

    def test_before_trigger_is_s2_watch_and_never_open(self):
        row, _ = self._run_gate(99.0)
        self.assertEqual(row['s_stage'], 'S2')
        self.assertFalse(row['open_eligible'])
        self.assertFalse(row['paper_bot_open'])
        self.assertEqual(row['entry_flow_state_v1221'], 'WATCHING_FROZEN_TRIGGER')
        self.assertIn('frozen_trigger_not_reached', row['final_trade_reasons'])

    def test_trigger_reached_becomes_s1_for_paper(self):
        row, _ = self._run_gate(100.0)
        self.assertEqual(row['s_stage'], 'S1')
        self.assertTrue(row['open_eligible'])
        self.assertTrue(row['trigger_reached'])
        self.assertEqual(row['entry_flow_state_v1221'], 'TRIGGER_REACHED_S1_READY')
        self.assertEqual(row['entry_flow_contract_v1221']['paper_actual_entry_recheck_owner'], 'paper_bot')


class GuardAuditTests(unittest.TestCase):
    def _write_json(self, path, obj):
        path.write_text(json.dumps(obj, ensure_ascii=False), encoding='utf-8')

    def test_guard_proves_flow_and_detects_no_trigger_bypass(self):
        with tempfile.TemporaryDirectory() as td:
            root = pathlib.Path(td)
            rows = [
                {
                    'ticker': 'WAIT', 'candidate_pipeline_cycle_id_v1150': 'cycle-x',
                    's_stage': 'S2', 'trigger_reached': False, 'open_eligible': False,
                    'current_price': 99.0, 'trigger_price': 100.0, 'invalid_price': 95.0, 'target_price': 110.0,
                    'entry_flow_state_v1221': 'WATCHING_FROZEN_TRIGGER',
                    'entry_flow_contract_v1221': {'current_state': 'WATCHING_FROZEN_TRIGGER', 'trigger_reached': False},
                    'swing_entry_gate_v977': {'trigger_reached': False, 'hard_pass': False},
                },
                {
                    'ticker': 'READY', 'candidate_pipeline_cycle_id_v1150': 'cycle-x',
                    's_stage': 'S1', 'trigger_reached': True, 'open_eligible': True,
                    'current_price': 100.0, 'trigger_price': 100.0, 'invalid_price': 95.0, 'target_price': 110.0,
                    'entry_flow_state_v1221': 'TRIGGER_REACHED_S1_READY',
                    'entry_flow_contract_v1221': {'current_state': 'TRIGGER_REACHED_S1_READY', 'trigger_reached': True},
                    'swing_entry_gate_v977': {'trigger_reached': True, 'hard_pass': True},
                },
            ]
            (root / GUARD.S1_ZERO_AUDIT_CANDIDATES_V1214).write_text('\n'.join(json.dumps(x) for x in rows) + '\n', encoding='utf-8')
            self._write_json(root / GUARD.S1_ZERO_AUDIT_GATE_STATUS_V1214, {'rows': 2, 'pass_s1': 1, 'recheck_s2': 1, 'observe_s3': 0})
            self._write_json(root / GUARD.S1_ZERO_AUDIT_WRITER_STATUS_V1214, {'candidate_snapshot_scope': {'rows_written': 2, 'pipeline_cycle_id_v1150': 'cycle-x', 'commit_id': 'commit-x'}})
            self._write_json(root / GUARD.PAPER_ACTIVE_CONTRACT_V1221, {'version': 'paper_bot_v1.064', 'entry': {'entry_mode': 'Strategy exact S1 + Paper integrity + ranked capacity pacing'}, 'integrity': {'exact_s1': True}})
            with mock.patch.object(GUARD, 'BOT_DIR', root):
                report = GUARD.collect_entry_flow_contract_audit_v1221()
            self.assertEqual(report['verdict'], 'PROVEN_V1211_FLOW_PRESERVED')
            self.assertEqual(report['flow']['s1_before_trigger_violation'], 0)
            self.assertEqual(report['flow']['open_before_trigger_violation'], 0)

    def test_release_identity(self):
        self.assertEqual(STRATEGY.VERSION, 'strategy_worker_v1.051')
        self.assertIn('v1222_v1211_vs_dynamic_structure_readonly_evidence', STRATEGY.BUILD_LABEL)
        self.assertIn('guard_v2.5.219_v1222', GUARD.VERSION)


if __name__ == '__main__':
    unittest.main(verbosity=2)
