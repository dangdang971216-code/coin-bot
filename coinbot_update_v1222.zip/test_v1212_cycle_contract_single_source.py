import importlib.util
import sys
import tempfile
import unittest
from pathlib import Path
from unittest import mock

ROOT=Path(__file__).resolve().parent
sys.path.insert(0,str(ROOT))

def load(name, filename):
    spec=importlib.util.spec_from_file_location(name,ROOT/filename)
    mod=importlib.util.module_from_spec(spec); assert spec and spec.loader
    sys.modules[name]=mod
    spec.loader.exec_module(mod)
    return mod

paper=load('paper_v1212_cycle_test','paper_bot_v1.064.py')


def candidates(cycle='cy1', commit='co1'):
    scores=[92.0,89.0,81.0,74.0,68.0]
    strategies=['same','same','other','third','third']
    rows=[]
    for i,(score,strategy) in enumerate(zip(scores,strategies)):
        row={
            'ticker':f'KRW-T{i}','strategy_name':strategy,
            'global_entry_score_v1212':score,'quality_rank_score_v1095':score,
            'target_room_pct':6.0-i*0.2,'actual_entry_cost_rr_v1212':2.4-i*0.1,
            'entry_price':100+i,'runner_pass':i==4,
            'pipeline_cycle_id':cycle,'candidate_commit_id':commit,
            'decision_key':f'd-{cycle}-{i}','spread_pct':0.1,
            'slippage_pct':0.05,'trigger_chase_pct':0.0,
            'structure_contract_version':'structure_contract_v1212_dynamic_zones',
            'structure_contract_hash':'hash-v1212',
            'ranking_contract_version':'ranking_contract_v1212_global_dynamic_score',
            'selection_contract_version':'selection_contract_v1212_global_top_score',
        }
        rows.append((f'p{i}',row))
    return rows


class V1212CycleContractTests(unittest.TestCase):
    def test_global_top_two_can_come_from_same_strategy(self):
        selected,e=paper.rank_executable_candidates_for_open(candidates(),{},2)
        self.assertEqual([r['ticker'] for _,r in selected],['KRW-T0','KRW-T1'])
        self.assertEqual(len({r['strategy_name'] for _,r in selected}),1)
        self.assertEqual(e['runner_reserved_slots'],0)
        self.assertEqual(e['selection_contract_version'],'selection_contract_v1212_global_top_score')

    def test_same_generation_cannot_open_more_than_two_and_rows_are_not_reused(self):
        with tempfile.TemporaryDirectory() as td:
            root=Path(td)
            old_state,old_ledger=paper.V1206_TOP10_STATE,paper.V1206_TOP10_LEDGER
            old_prev,old_active=paper._V1206_PREV_SELECT_CANDIDATES,paper._v1206_ranked_active
            old_digest=paper._V1206_LAST_LEDGER_DIGEST
            try:
                paper.V1206_TOP10_STATE=root/'state.json'
                paper.V1206_TOP10_LEDGER=root/'ledger.jsonl'
                paper._V1206_LAST_LEDGER_DIGEST=''
                paper._v1206_ranked_active=lambda: True
                rows=candidates('cy1','co1')
                paper._V1206_PREV_SELECT_CANDIDATES=lambda ctrl,open_pos:(rows,{},None)
                first,_,_=paper.select_candidates__v1208_ranked_top10_cycle2({}, {})
                second,stats,_=paper.select_candidates__v1208_ranked_top10_cycle2({}, {})
                self.assertEqual(len(first),2)
                self.assertEqual(len(second),0)
                self.assertGreaterEqual(stats['cycle_new_open_deferred_v1208'],1)
                rows[:]=candidates('cy2','co2')
                third,_,_=paper.select_candidates__v1208_ranked_top10_cycle2({}, {})
                self.assertEqual(len(third),2)
            finally:
                paper.V1206_TOP10_STATE,paper.V1206_TOP10_LEDGER=old_state,old_ledger
                paper._V1206_PREV_SELECT_CANDIDATES,paper._v1206_ranked_active=old_prev,old_active
                paper._V1206_LAST_LEDGER_DIGEST=old_digest

    def test_open_seals_v1212_entry_contract_and_preserves_v1206_exit_contract(self):
        ev=dict(candidates()[0][1])
        ev.update({
            'ranked_top10_slot_role_v1206':'general',
            'ranked_top10_cycle_rank_v1208':1,
            'candidate_pipeline_cycle_id_v1208':'cy1',
            'candidate_commit_id_v1208':'co1',
            'roundtrip_cost_pct':0.35,
        })
        base={'ticker':'KRW-T0','entry_price':100.0,'current_price':100.0,
              'invalid_price':96.0,'invalid_timeframe':'1h'}
        with mock.patch.object(paper,'_V1206_PREV_OPEN_POSITION',return_value=dict(base)):
            row=paper.open_position__v1206_ranked_contract('p0',ev)
        contract=row['ranked_top10_contract_v1206']
        self.assertEqual(contract['schema'],'ranked_top10_open_contract_v1212')
        self.assertEqual(contract['cycle_new_open_cap'],2)
        self.assertEqual(contract['cycle_selection_rank'],1)
        self.assertEqual(contract['candidate_pipeline_cycle_id'],'cy1')
        self.assertEqual(contract['candidate_commit_id'],'co1')
        self.assertEqual(contract['structure_contract_version'],'structure_contract_v1212_dynamic_zones')
        self.assertAlmostEqual(contract['actual_entry_evidence']['actual_rr'],2.4)
        self.assertEqual(row['exit_contract_v1206']['schema'],'alt_swing_exit_contract_v1206')
        self.assertTrue(row['exit_contract_v1206']['original_structure_invalid_preserved'])
        self.assertFalse(contract['deferred_rows_reused'])

    def test_active_contract_declares_no_strategy_quota_and_runner_tag_only(self):
        with mock.patch.object(paper,'load_json',return_value={}), \
             mock.patch.object(paper,'_v1206_ranked_active',return_value=True), \
             mock.patch.object(paper,'_v1206_active_epoch',return_value={'epoch_id':'ep'}), \
             mock.patch.object(paper,'_v1204_read_control',return_value={'pause_new_open':False}), \
             mock.patch.object(paper,'_v1205_reset_thread_alive',return_value=False):
            snap=paper._v1208_active_contract_payload({})
        self.assertEqual(snap['entry']['total_cap'],10)
        self.assertEqual(snap['entry']['cycle_new_open_cap'],2)
        self.assertIn('no strategy quota',snap['entry']['count_policy'])
        self.assertIn('runner tag only',snap['entry']['count_policy'])
        self.assertEqual(snap['open_contract_seal']['schema'],'paper_ranked_top10_open_contract_v1212')
        self.assertFalse(snap['auto_buy'])

    def test_below_absolute_score_floor_produces_zero_entry(self):
        rows=candidates()
        for _,row in rows:
            row['global_entry_score_v1212']=39.9
        selected,e=paper.rank_executable_candidates_for_open(rows,{},2)
        self.assertEqual(selected,[])
        self.assertEqual(e['eligible_count'],0)
        self.assertTrue(all(x['reason']=='below_dynamic_global_score_floor' for x in e['not_selected']))


if __name__=='__main__':
    unittest.main(verbosity=2)
