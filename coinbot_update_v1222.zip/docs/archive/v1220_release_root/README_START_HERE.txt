코인봇 업데이트 v1220

목적
- 가까운 실제 저항에 capture 여유를 빼면서 Target이 Trigger 아래로 내려가던 불가능 계약 수리
- RR/목표공간 감사의 비교범위를 Strategy 실제 적용범위와 통일
- 서버에서 누락된 orderflow v0.12 versioned source 복원

적용
1. 가드봇에서 /gupgrade_bundle 단독 실행
2. 자동 재시작 완료 후 새 Strategy 완료 cycle 대기
3. 가드봇 검수 명령 실행

변경
- Strategy 1.049
- Guard 2.5.217
- Orderflow 계산·active alias 변경 없음; v0.12 source 파일만 복원

고정
- RR·목표공간·ATR·순위·진입·청산 변경 없음
- 기존 OPEN·원장 변경 없음
- 자동매수 OFF
