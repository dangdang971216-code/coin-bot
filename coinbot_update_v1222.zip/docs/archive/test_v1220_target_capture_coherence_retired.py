import importlib.util
import pathlib
import sys
import unittest
from unittest import mock

ROOT = pathlib.Path(__file__).resolve().parent


def load(name, filename):
    spec = importlib.util.spec_from_file_location(name, ROOT / filename)
    mod = importlib.util.module_from_spec(spec)
    assert spec and spec.loader
    sys.modules[name] = mod
    spec.loader.exec_module(mod)
    return mod


STRATEGY = load('strategy_v1220_tests', 'strategy_worker_v1.049.py')
GUARD = load('guard_v1220_tests', 'backga_guard_bot_v2_5_217.py')


def zone(side, tf, low, high, score=80.0):
    return {
        'side': side, 'tf': tf, 'price': (low + high) / 2.0,
        'zone_low': low, 'zone_high': high, 'score': score,
        'touch_count': 3, 'source': f'test.{tf}', 'atr_pct': 1.0,
        'gap_pct': 0.0,
    }


class TargetCaptureCoherenceTests(unittest.TestCase):
    def _plan(self, target_low):
        trigger_zone = zone('resistance', 'm5', 99.8, 100.0)
        invalid_zone = zone('support', 'm30', 97.0, 97.2)
        target_zone = zone('resistance', 'm30', target_low, target_low + 0.20)

        def fake_zones(rows, tf, side, price):
            if tf == 'm5' and side == 'resistance':
                return [trigger_zone]
            if tf == 'm30' and side == 'support':
                return [invalid_zone]
            if tf == 'm30' and side == 'resistance':
                return [target_zone]
            return []

        row = {'ticker': 'TEST', 'current_price': 99.95}
        with mock.patch.object(STRATEGY, '_v1212_frame_rows', return_value=[1] * 10), \
             mock.patch.object(STRATEGY, '_v1212_atr_pct', return_value=1.0), \
             mock.patch.object(STRATEGY, '_v1212_zone_candidates', side_effect=fake_zones), \
             mock.patch.object(STRATEGY, '_v1212_cost_inputs', return_value={
                 'spread_pct': 0.04, 'slippage_pct': 0.02, 'fee_pct': 0.08,
                 'estimated_roundtrip_cost_pct': 0.10, 'complete': True,
             }), \
             mock.patch.object(STRATEGY, '_v1212_strength_factor', return_value=1.0):
            return STRATEGY._v925_current_actual_plan(row)

    def test_nearest_resistance_capture_cannot_create_target_below_trigger(self):
        plan = self._plan(100.12)
        self.assertTrue(plan.get('trigger'))
        self.assertTrue(plan.get('invalid'))
        self.assertEqual(plan.get('target'), {})
        self.assertEqual(plan.get('target_mode_v1212'), 'nearest_resistance_too_close_after_capture')
        diag = plan['selection_diagnostics_v1216']
        self.assertIn('target_nearest_resistance_too_close_after_capture', diag['missing_reason_codes'])
        self.assertEqual(diag['target']['rejected_capture_at_or_below_trigger'], 1)

    def test_valid_nearest_resistance_is_unchanged(self):
        plan = self._plan(101.50)
        self.assertTrue(plan.get('target'))
        self.assertGreater(plan['target']['rounded_price'], plan['trigger']['rounded_price'])
        self.assertEqual(plan.get('target_mode_v1212'), 'nearest_actual_resistance')
        self.assertEqual(plan['selection_diagnostics_v1216']['target']['rejected_capture_at_or_below_trigger'], 0)

    def test_release_identity(self):
        self.assertEqual(STRATEGY.VERSION, 'strategy_worker_v1.049')
        self.assertIn('v1220_target_capture_coherence_repair', STRATEGY.BUILD_LABEL)
        self.assertIn('guard_v2.5.217_v1220', GUARD.VERSION)

    def test_guard_reason_balance_uses_strategy_applicability_scope(self):
        src = (ROOT / 'backga_guard_bot_v2_5_217.py').read_text(encoding='utf-8')
        self.assertIn("metric_reason_applicable = gate.get('structure_integrity_block_v1048') is not True", src)
        self.assertIn('rr_metric_below_all = applicable_gate_rr_below', src)
        self.assertIn('room_metric_below_all = applicable_gate_room_below', src)


if __name__ == '__main__':
    unittest.main(verbosity=2)
