코인봇 업데이트 v1221

목적
- 구조선 변경 전 v1211 진입 흐름을 그대로 고정
- 동적 Target을 실제 저항선으로 봉인하고 capture 사전차감 제거
- Trigger 전 S1·OPEN 우회가 없는지 읽기 전용 감사 추가

핵심 흐름
후보계약 생성 → Trigger 감시 → Trigger 도달 → Strategy S1 → Paper 실제 진입가 최종검증 → 통과 즉시 OPEN

변경
- Strategy 1.050
- Guard 2.5.218
- /gentry_flow_audit 추가

고정
- Trigger·Invalid 계산, ATR, RR, 목표공간, rank, 청산, 기존 OPEN 변경 없음
- 새 대기상태·조기진입·먼 Target 강제선택 없음
- 자동매수 OFF

적용
1. 가드봇에서 /gupgrade_bundle 단독 실행
2. 자동 재시작 후 새 완료 cycle 대기
3. 가드봇 검수 명령 실행
