import importlib.util
import json
import math
import pathlib
import sys
import tempfile
import time
import unittest
from unittest import mock

ROOT = pathlib.Path(__file__).resolve().parent


def load(name, filename):
    spec = importlib.util.spec_from_file_location(name, ROOT / filename)
    mod = importlib.util.module_from_spec(spec)
    assert spec and spec.loader
    sys.modules[name] = mod
    spec.loader.exec_module(mod)
    return mod


STRATEGY = load('strategy_v1216_tests', 'baselines/strategy_worker_v1.047_v1217_ceiling_failure.py')
GUARD = load('guard_v1216_tests', 'baselines/backga_guard_bot_v2_5_214_v1217.py')


def frame(n, center, amp, step):
    now = time.time()
    out = []
    for i in range(n):
        base = center + amp * math.sin(i * math.pi / 3.0)
        out.append([now-(n-i)*step, base-amp*.08, base+amp*.08, base+amp*.30, base-amp*.30, 1000.0*(1.7 if i % 6 == 1 else 1.0)])
    return out


def candle_lab():
    return {'frames': {
        'm5': frame(120, 100.7, .7, 300),
        'm15': frame(40, 100.7, .7, 900),
        'm30': frame(160, 101.0, 2.0, 1800),
        'h1': frame(192, 101.0, 2.0, 3600),
        'h2': frame(96, 101.0, 2.4, 7200),
        'h4': frame(48, 101.0, 2.4, 14400),
    }}


def base_row(price=101.0, ticker='TEST'):
    return {
        'ticker': ticker, 'current_price': price, 'spread_pct': 0.08,
        'entry_slippage_confirmed': True, 'entry_slippage_owner': 'orderflow_worker',
        'entry_slippage_source': 'best_ask_reference_orderflow_v1100', 'entry_slippage_est_pct': 0.05,
        'fee_pct_roundtrip': 0.08, 'relative_strength_rank_pct_v1095': 70,
        'relative_strength_pct': 1.0, 'money_flow_score': 65, 'market_regime_score': 60,
        '_dynamic_structure_candle_material_v1215': candle_lab(),
    }


class StrategyEvidenceTests(unittest.TestCase):
    def test_release_identity_and_no_formula_change(self):
        self.assertEqual(STRATEGY.VERSION, 'strategy_worker_v1.047')
        self.assertIn('v1217_candidate_final_blob_evidence_persistence', STRATEGY.BUILD_LABEL)
        src = (ROOT / 'baselines' / 'strategy_worker_v1.047_v1217_ceiling_failure.py').read_text(encoding='utf-8')
        self.assertIn("'evidence_only':True", src)
        self.assertIn("'thresholds_changed':False", src)

    def test_complete_plan_records_complete_diagnostic(self):
        plan = STRATEGY._v925_current_actual_plan(base_row())
        diag = plan['selection_diagnostics_v1216']
        self.assertEqual(diag['missing_axes'], [])
        self.assertEqual(diag['missing_reason_codes'], ['complete'])
        self.assertTrue(plan['trigger'])
        self.assertTrue(plan['invalid'])
        self.assertTrue(plan['target'])

    def test_far_above_entry_zones_records_exact_reason(self):
        plan = STRATEGY._v925_current_actual_plan(base_row(price=130.0))
        diag = plan['selection_diagnostics_v1216']
        self.assertIn('trigger', diag['missing_axes'])
        self.assertIn('trigger_all_zones_far_below_after_breakout', diag['missing_reason_codes'])
        self.assertGreater(diag['trigger']['rejected_far_below_after_breakout'], 0)


class GuardAuditTests(unittest.TestCase):
    def write_json(self, path, obj):
        path.write_text(json.dumps(obj, ensure_ascii=False), encoding='utf-8')

    def write_jsonl(self, path, rows):
        with path.open('w', encoding='utf-8') as fh:
            for row in rows:
                fh.write(json.dumps(row, ensure_ascii=False) + '\n')

    def test_exact_audit_counts_reason_and_same_cycle(self):
        with tempfile.TemporaryDirectory() as td:
            base = pathlib.Path(td)
            cycle = 'strategy-test-cycle'
            plan = STRATEGY._v925_current_actual_plan(base_row(price=130.0, ticker='AAA'))
            row = {
                'ticker':'AAA', 's_stage':'S3', 'candidate_pipeline_cycle_id_v1150':cycle,
                'dynamic_structure_plan_v1212':plan,
                'dynamic_structure_material_evidence_v1215':{'link_mode':'candle_map_ephemeral_reference','frame_counts':plan['frame_counts_v1215']},
                'swing_entry_gate_v977':{'hard_block_reasons':['dynamic_structure_source_missing','actual_structural_trigger_missing']},
            }
            self.write_jsonl(base/'paper_candidates_latest.jsonl', [row])
            self.write_json(base/'clean_strategy_swing_gate_status_v977.json', {
                'rows':1,'pass_s1':0,'recheck_s2':0,'observe_s3':1,
                'hard_reason_top':[{'reason':'dynamic_structure_source_missing','count':1}],
            })
            self.write_json(base/'clean_strategy_paper_latest_writer_status.json', {
                'candidate_snapshot_scope':{'rows_written':1,'pipeline_cycle_id_v1150':cycle,'commit_id':'commit-test'},
                'candidate_final_blob_schema_v1217':'candidate_final_wrapper_exact_encoded_blob_v1217',
                'candidate_expected_plan_rows_v1217':1,
                'candidate_compact_plan_rows_v1217':1,
                'candidate_encoded_plan_rows_v1217':1,
                'candidate_expected_diag_rows_v1217':1,
                'candidate_compact_diag_rows_v1217':1,
                'candidate_encoded_diag_rows_v1217':1,
                'candidate_expected_material_rows_v1217':1,
                'candidate_compact_material_rows_v1217':1,
                'candidate_encoded_material_rows_v1217':1,
                'candidate_encoded_evidence_exact_v1217':True,
                'candidate_stale_pre_wrapper_blob_retired_v1217':True,
            })
            with mock.patch.object(GUARD, 'BOT_DIR', base):
                report = GUARD.collect_structure_missing_exact_audit_v1216()
            self.assertEqual(report['verdict'], 'PROVEN_SELECTION_FILTER_EMPTY')
            self.assertEqual(report['dynamic_missing_rows'], 1)
            self.assertEqual(report['material_link_modes']['candle_map_ephemeral_reference'], 1)
            self.assertEqual(report['missing_reason_counts']['trigger_all_zones_far_below_after_breakout'], 1)
            self.assertTrue(report['source']['same_rows'])
            self.assertTrue(report['source']['same_cycle'])


if __name__ == '__main__':
    unittest.main(verbosity=2)
