v1702: 후보선택 엑스레이 + Gate 전수조사판

기준: v1701/v1454 표시전용 흐름 위에 조사 명령만 추가.
목적: 모의매매 후보까지 가기 전 후보가 어디서 사라지는지 실행 trace와 코드 정적 전수조사로 함께 확인.
추가 명령: /candidate_flow_trace, /gate_inventory, /paper_select_path, /pipeline_map, /data_pipeline
변경 금지 유지: Gate/TTL/RR/trigger/invalid/target/청산/OPEN limit/자동매수.
자동매수: OFF
