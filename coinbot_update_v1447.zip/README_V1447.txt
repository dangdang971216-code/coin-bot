coinbot update v1447

Purpose:
- Candidate board single-source operator display.
- /shadow_board groups detailed shadows.
- Dynamic-structure profit weakness diagnosis added.

No trading rule changes. Auto-buy OFF.
