v1472 MATERIAL_SPINE_SINGLE_OWNER_SOURCE_FIX_AUTOBUY_OFF

목적:
- v1471에서 드러난 Strategy 후보판 ↔ Paper live판 불일치와 재료 증명 누락을 단일배관 상태로 정리.
- broad nested 숫자 긁기 대신 허용된 핵심 필드만 재료로 감사.
- target/invalid/trigger/volume/RS/market/cost/freshness를 snapshot/select/picked로 분리 표시.

변경 없음:
- 자동매수 OFF
- target/invalid/trigger/RR 기준 변경 없음
- BUY_READY/OPEN 강제 없음
- 청산계약 변경 없음
- 원장 재작성 없음
