v1325 restores the last-good Strategy writer path after v1322-v1324 failed with trigger_occurrence_candidate_key_changed.
This is not an S1 widening patch and not a strategy change.
Apply, verify Strategy writer OK/cycle/commit first, then resume code comparison against v1054/v1190/v1208/v1210/v1211.
