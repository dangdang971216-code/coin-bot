#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Coinbot Main v2.13.1134 / v1191.

Canonical snapshot-only Main with the familiar command UX restored.
It never recalculates candidates, performance, OPEN/CLOSED, or strategy values.
Large canonical JSON files are cached only while their exact size+mtime signature
is unchanged. A missing or unreadable current file is never replaced with an old
cached value.
"""
from __future__ import annotations

import json
import os
import re
import signal
import tempfile
import threading
import time
import traceback
from pathlib import Path
from typing import Any, Callable, Dict, Iterable, List, Mapping, Optional, Sequence, Tuple

from canonical_spine_v1190 import (
    STRATEGY_MODE,
    SpinePaths,
    atomic_write_json,
    file_age,
    find_ledger,
    integer,
    mapping,
    now_text,
    now_ts,
    num,
    pct_text,
    read_json,
    read_jsonl_tail,
    safe_error_tail,
    error_scope_summary,
    text,
)

try:
    from telegram import BotCommand
    from telegram.ext import CommandHandler, Filters, MessageHandler, Updater
except Exception:
    BotCommand = None
    CommandHandler = None
    Filters = None
    MessageHandler = None
    Updater = None

BOT_VERSION = "수익형 v2.13.1193"
MAIN_BOT_VERSION = BOT_VERSION
BUILD_LABEL = "v1325_restore_last_good_strategy_writer_2026-07-07"
V650_BUILD_LABEL = BUILD_LABEL
RELEASE_TAG = "v1305"
HEARTBEAT_SEC = 5.0
TELEGRAM_LIMIT = 3900
_STOP = False
_STARTED_TS = now_ts()
_TELEGRAM_STATE = "initializing"
_TELEGRAM_ERROR = ""
_TELEGRAM_NOTE = "boot"
_SCAN_RUNNING = False
_SCAN_STAGE = "idle"


def base_dir() -> Path:
    override = os.getenv("COINBOT_BASE_DIR", "").strip()
    return Path(override).expanduser().resolve() if override else Path(__file__).resolve().parent


BASE_DIR = base_dir()
PATHS = SpinePaths(BASE_DIR)
TELEGRAM_TOKEN = os.getenv("TELEGRAM_TOKEN", "").strip()
CHAT_ID = os.getenv("CHAT_ID", "").strip()
COMMAND_SUMMARY_STATUS = BASE_DIR / "command_summary_status_v1187.json"
RUNTIME_LOG = BASE_DIR / "clean_brain_runtime.log"
ERROR_LOG = BASE_DIR / "clean_brain_error.log"
ACTIVE_CONTRACT_PATH = BASE_DIR / "paper_active_contract_snapshot_v1208.json"

_CACHE_LOCK = threading.RLock()
_JSON_CACHE: Dict[str, Tuple[Tuple[int, int], Any]] = {}
_PINNED_JSON: Optional[Dict[str, Any]] = None
_PINNED_META: Dict[str, Any] = {}
_COMMAND_LOCK = threading.Lock()
_REQUEST_LOCK = threading.Lock()
_REQUEST_SEEN: Dict[str, float] = {}


def log_error(where: str, exc: BaseException) -> None:
    message = (
        f"[{now_text()}] {where}: {type(exc).__name__}: {exc}\n"
        f"{traceback.format_exc()[-4000:]}\n"
    )
    try:
        with ERROR_LOG.open("a", encoding="utf-8") as handle:
            handle.write(message)
    except OSError:
        pass


def log_runtime(message: str) -> None:
    try:
        with RUNTIME_LOG.open("a", encoding="utf-8") as handle:
            handle.write(f"[{now_text()}] {message}\n")
    except OSError:
        pass


def _path_signature(path: Path) -> Optional[Tuple[int, int]]:
    try:
        stat = path.stat()
        return int(stat.st_mtime_ns), int(stat.st_size)
    except OSError:
        return None


def current_json(path: Path, default: Any = None) -> Any:
    """Read current canonical bytes, or the exact request-pinned object."""
    key = str(path)
    with _CACHE_LOCK:
        if _PINNED_JSON is not None and key in _PINNED_JSON:
            value = _PINNED_JSON.get(key)
            return default if value is None else value
    signature = _path_signature(path)
    if signature is None:
        with _CACHE_LOCK:
            _JSON_CACHE.pop(key, None)
        return default
    with _CACHE_LOCK:
        cached = _JSON_CACHE.get(key)
        if cached and cached[0] == signature:
            return cached[1]
    obj = read_json(path, None)
    if obj is None:
        with _CACHE_LOCK:
            _JSON_CACHE.pop(key, None)
        return default
    with _CACHE_LOCK:
        _JSON_CACHE[key] = (signature, obj)
    return obj


def begin_canonical_pin() -> Dict[str, Any]:
    """Pin one exact set of canonical files for a command bundle.

    This is not stale fallback: a missing/unreadable current file is pinned as
    None and reported as CHECK. The pin is released when the request finishes.
    """
    global _PINNED_JSON, _PINNED_META
    paths = (
        PATHS.ops_snapshot, PATHS.candidate_standard, PATHS.review_snapshot,
        PATHS.paper_status, PATHS.paper_open, PATHS.performance,
    )
    pinned: Dict[str, Any] = {}
    signatures: Dict[str, Any] = {}
    for path in paths:
        key = str(path)
        obj = None
        stable_sig = None
        for _attempt in range(3):
            before = _path_signature(path)
            if before is None:
                break
            candidate = read_json(path, None)
            after = _path_signature(path)
            if before == after and candidate is not None:
                obj = candidate
                stable_sig = before
                break
        pinned[key] = obj
        signatures[path.name] = list(stable_sig) if stable_sig else None
    ops = pinned.get(str(PATHS.ops_snapshot))
    _PINNED_JSON = pinned
    _PINNED_META = {
        "started_ts": now_ts(),
        "ops_snapshot_id": ops.get("snapshot_id") if isinstance(ops, dict) else None,
        "signatures": signatures,
        "missing": [Path(k).name for k, v in pinned.items() if v is None],
    }
    return dict(_PINNED_META)


def end_canonical_pin() -> None:
    global _PINNED_JSON, _PINNED_META
    with _CACHE_LOCK:
        _PINNED_JSON = None
        _PINNED_META = {}


def warm_canonical_cache() -> None:
    for path in (
        PATHS.ops_snapshot,
        PATHS.candidate_standard,
        PATHS.review_snapshot,
        PATHS.paper_status,
        PATHS.paper_open,
        PATHS.performance,
    ):
        try:
            current_json(path, None)
        except Exception as exc:
            log_error(f"warm_cache_{path.name}", exc)


def set_runtime_state(*, telegram_state: Optional[str] = None, telegram_error: Optional[str] = None,
                      telegram_note: Optional[str] = None, scan_running: Optional[bool] = None,
                      scan_stage: Optional[str] = None) -> None:
    global _TELEGRAM_STATE, _TELEGRAM_ERROR, _TELEGRAM_NOTE, _SCAN_RUNNING, _SCAN_STAGE
    if telegram_state is not None:
        _TELEGRAM_STATE = telegram_state
    if telegram_error is not None:
        _TELEGRAM_ERROR = telegram_error
    if telegram_note is not None:
        _TELEGRAM_NOTE = telegram_note
    if scan_running is not None:
        _SCAN_RUNNING = bool(scan_running)
    if scan_stage is not None:
        _SCAN_STAGE = str(scan_stage or "idle")


def write_status(state: str = "running", **extra: Any) -> None:
    updated = now_ts()
    payload: Dict[str, Any] = {
        "schema": "main_status_v1186",
        "version": BOT_VERSION,
        "brain_version": BOT_VERSION,
        "build": BUILD_LABEL,
        "running": state not in {"stopped", "error"},
        "state": state,
        "phase": extra.pop("phase", _SCAN_STAGE if _SCAN_RUNNING else "idle"),
        "updated_ts": updated,
        "updated_text": now_text(updated),
        "started_at": _STARTED_TS,
        "pid": os.getpid(),
        "owner": "main_canonical_snapshot_renderer_and_ux_v1186",
        "strategy_mode": STRATEGY_MODE,
        "auto_buy": False,
        "candidate_recalculation": False,
        "performance_recalculation": False,
        "legacy_command_override_chain": False,
        # Exact fields consumed by Guard /gdeploy.
        "telegram_state": _TELEGRAM_STATE,
        "telegram_error": _TELEGRAM_ERROR or "-",
        "telegram_note": _TELEGRAM_NOTE,
        "telegram_updated_ts": updated,
        "command_count": len(COMMANDS) if "COMMANDS" in globals() else 0,
        "scan_running": _SCAN_RUNNING,
        "scan_last_stage": _SCAN_STAGE,
        "scan_last_ts": updated,
    }
    payload.update(extra)
    atomic_write_json(PATHS.main_status, payload)


def icon(state: Any) -> str:
    value = str(state or "CHECK").upper()
    if value in {"NORMAL", "DONE", "PASS", "READY", "RUNNING", "REVIEWABLE", "ACTIVE"}:
        return "🟢"
    if value in {"FAIL", "FAILED", "ERROR", "DOWN", "SYSTEM_REGRESSION"}:
        return "🔴"
    return "🟡"


def fmt_sec(value: Any, digits: int = 3) -> str:
    parsed = num(value, default=None)
    return "수집 중" if parsed is None else f"{parsed:.{digits}f}초"

def fmt_ts(value: Any) -> str:
    parsed = num(value, default=None)
    if parsed is None or parsed <= 0:
        return "-"
    return time.strftime("%Y-%m-%d %H:%M:%S KST", time.localtime(parsed))


def fmt_num(value: Any, digits: int = 3, signed: bool = False) -> str:
    parsed = num(value, default=None)
    if parsed is None:
        return "정보없음"
    sign = "+" if signed else ""
    return f"{parsed:{sign}.{digits}f}"


def fmt_pct(value: Any, digits: int = 3) -> str:
    parsed = num(value, default=None)
    return "정보없음" if parsed is None else f"{parsed:+.{digits}f}%"


def split_text(message: str, limit: int = TELEGRAM_LIMIT) -> List[str]:
    if len(message) <= limit:
        return [message]
    chunks: List[str] = []
    current: List[str] = []
    size = 0
    for line in message.splitlines(True):
        if current and size + len(line) > limit:
            chunks.append("".join(current).rstrip())
            current = []
            size = 0
        if len(line) > limit:
            for start in range(0, len(line), limit):
                if current:
                    chunks.append("".join(current).rstrip())
                    current = []
                    size = 0
                chunks.append(line[start:start + limit].rstrip())
            continue
        current.append(line)
        size += len(line)
    if current:
        chunks.append("".join(current).rstrip())
    return [chunk for chunk in chunks if chunk]


def send_text(update: Any, message: str) -> None:
    target = getattr(update, "effective_message", None) or getattr(update, "message", None)
    if target is None:
        return
    for chunk in split_text(message):
        target.reply_text(chunk)


def _chat_allowed(update: Any) -> bool:
    if not CHAT_ID:
        return True
    chat_id = str(getattr(getattr(update, "effective_chat", None), "id", ""))
    return chat_id == CHAT_ID


def request_key(update: Any) -> str:
    message = getattr(update, "effective_message", None) or getattr(update, "message", None)
    chat_id = getattr(message, "chat_id", None) or getattr(getattr(message, "chat", None), "id", None)
    message_id = getattr(message, "message_id", None)
    update_id = getattr(update, "update_id", None)
    return f"{chat_id}:{message_id}:{update_id}"


def acquire_request(update: Any) -> bool:
    key = request_key(update)
    now_value = time.time()
    with _REQUEST_LOCK:
        for old_key, ts in list(_REQUEST_SEEN.items()):
            if now_value - ts > 180:
                _REQUEST_SEEN.pop(old_key, None)
        if key in _REQUEST_SEEN:
            return False
        _REQUEST_SEEN[key] = now_value
    return True


def _deep_mapping(obj: Mapping[str, Any], *paths: str) -> Dict[str, Any]:
    for path in paths:
        cur: Any = obj
        okay = True
        for part in path.split("."):
            if not isinstance(cur, dict) or part not in cur:
                okay = False
                break
            cur = cur[part]
        if okay and isinstance(cur, dict):
            return cur
    return {}


def _deep_value(obj: Mapping[str, Any], *paths: str, default: Any = None) -> Any:
    for path in paths:
        cur: Any = obj
        okay = True
        for part in path.split("."):
            if not isinstance(cur, dict) or part not in cur:
                okay = False
                break
            cur = cur[part]
        if okay and cur not in (None, "", [], {}):
            return cur
    return default


def _stat_count(stat: Mapping[str, Any]) -> int:
    return integer(stat.get("count"), stat.get("n"), stat.get("closed_count"), default=0)


def _stat_wins(stat: Mapping[str, Any]) -> int:
    return integer(stat.get("wins"), stat.get("win"), default=0)


def _stat_losses(stat: Mapping[str, Any]) -> int:
    n = _stat_count(stat)
    wins = _stat_wins(stat)
    return integer(stat.get("losses"), stat.get("loss"), default=max(0, n - wins))


def _stat_total(stat: Mapping[str, Any]) -> Optional[float]:
    return num(stat.get("sum_pct"), stat.get("total"), stat.get("total_pct"), stat.get("pnl_sum_pct"), default=None)


def _stat_avg(stat: Mapping[str, Any]) -> Optional[float]:
    return num(stat.get("avg_pct"), stat.get("avg"), stat.get("mean_pct"), default=None)


def _stat_win_rate(stat: Mapping[str, Any]) -> Optional[float]:
    value = num(stat.get("win_rate"), stat.get("win_rate_pct"), default=None)
    if value is not None:
        return value
    n = _stat_count(stat)
    return (100.0 * _stat_wins(stat) / n) if n else None


def stat_line(label: str, stat_obj: Any, include_path: bool = True) -> str:
    stat = stat_obj if isinstance(stat_obj, dict) else {}
    n = _stat_count(stat)
    if not stat and n == 0:
        return f"- {label}: 정보없음"
    parts = [
        f"- {label}: n{n}",
        f"{_stat_wins(stat)}승 {_stat_losses(stat)}패",
        f"승률 {fmt_num(_stat_win_rate(stat), 1)}%" if _stat_win_rate(stat) is not None else "승률 정보없음",
        f"합산 {fmt_pct(_stat_total(stat), 3)}",
        f"평균 {fmt_pct(_stat_avg(stat), 3)}",
    ]
    if include_path:
        mfe = num(stat.get("avg_mfe_pct"), stat.get("mfe"), stat.get("mfe_median_pct"), default=None)
        mae = num(stat.get("avg_mae_pct"), stat.get("mae"), stat.get("mae_median_pct"), default=None)
        giveback = num(stat.get("avg_giveback_pct"), stat.get("giveback"), stat.get("giveback_median_pct"), default=None)
        if mfe is not None:
            parts.append(f"MFE {mfe:+.3f}%")
        if mae is not None:
            parts.append(f"MAE {mae:+.3f}%")
        if giveback is not None:
            parts.append(f"반납 {giveback:+.3f}%")
    return " · ".join(parts)


def _performance_snapshot() -> Dict[str, Any]:
    obj = current_json(PATHS.performance, {}) or {}
    return obj if isinstance(obj, dict) else {}


def _ops_snapshot() -> Dict[str, Any]:
    obj = current_json(PATHS.ops_snapshot, {}) or {}
    return obj if isinstance(obj, dict) else {}


def _candidate_snapshot() -> Dict[str, Any]:
    ops = _ops_snapshot()
    embedded = ops.get("candidate_standard_full") if isinstance(ops, dict) else None
    if isinstance(embedded, dict) and embedded:
        return embedded
    obj = current_json(PATHS.candidate_standard, {}) or {}
    return obj if isinstance(obj, dict) else {}


def _paper_status() -> Dict[str, Any]:
    obj = current_json(PATHS.paper_status, {}) or {}
    return obj if isinstance(obj, dict) else {}

def _active_contract_snapshot() -> Dict[str, Any]:
    obj = current_json(ACTIVE_CONTRACT_PATH, {}) or {}
    return obj if isinstance(obj, dict) else {}


def _state_summary_line(label: str, value: Any) -> str:
    state = str(value or "CHECK").upper()
    return f"- {icon(state)} {label}: {state}"


def _contract_compact_line(contract: Mapping[str, Any]) -> str:
    entry=mapping(contract.get('entry'))
    exit_info=mapping(contract.get('exit'))
    if contract.get('schema')!='paper_active_trade_contract_v1208':
        return '- 실제 진입·청산 계약 snapshot CHECK · 자동매수 OFF'
    return (
        f"- 실제 계약: OPEN {entry.get('total_cap')}/일반 {entry.get('general_cap')}/대수익 {entry.get('runner_cap')} "
        f"· cycle당 {entry.get('cycle_new_open_cap')} · 동적청산 {exit_info.get('state') or '-'} · 자동매수 OFF"
    )

def render_flow_map_compact(_args: Sequence[str] = ()) -> str:
    obj = _ops_snapshot()
    if not obj:
        return "🗺️ 운영지도 · 전수감사\n🚦 전체 🟡 CHECK_SOURCE\n- Guard 전수증거 snapshot 대기\n- 차단 추가 없음 · 자동매수 OFF"
    current = mapping(obj.get("current_cycle"))
    timing = mapping(obj.get("timing"))
    timing_path = mapping(obj.get("timing_path"))
    groups = mapping(obj.get("evidence_groups"))
    errors = mapping(obj.get("errors"))
    resources = mapping(obj.get("resources"))
    problems = [x for x in (obj.get("problems") or []) if isinstance(x, dict)]
    slow = [x for x in (timing_path.get("top_slowest") or []) if isinstance(x, dict)]
    lines = [
        "🗺️ 운영지도 · 전수감사 한눈판",
        f"🚦 전체 {icon(obj.get('overall_state'))} {obj.get('overall_state') or 'CHECK'}",
        "",
        "📍 현재 cycle",
        f"- {icon(current.get('state'))} {current.get('state') or 'CHECK'} · 전체 {integer(current.get('candidate_rows'))} → S1 {integer(current.get('s1_count'))} → Paper 확인 {integer(current.get('paper_received'))}",
        f"- cycle {current.get('pipeline_cycle_id') or '-'}",
        f"- commit {current.get('candidate_commit_id') or '-'}",
        "",
        "⏱️ 핵심 처리시간",
        f"- Strategy 전달 {fmt_sec(timing.get('strategy_execution_handoff_sec'))} · 전체 {fmt_sec(timing.get('strategy_full_cycle_sec'))}",
        f"- Paper core {fmt_sec(timing.get('paper_fast_cycle_sec'))} · Review {fmt_sec(timing.get('review_cycle_sec'))}",
    ]
    if slow:
        top=slow[0]
        lines.append(f"- 가장 느린 구간: {top.get('key') or '-'} · 중앙 {fmt_sec(top.get('median_sec'))} · 최대 {fmt_sec(top.get('max_sec'))}")
    lines += ["", "🔎 전수 증거판"]
    labels = (
        ("data_intake", "시세·호가·전체시장"),
        ("candidate_pipeline", "후보 생성·저장·전달"),
        ("paper_execution", "Paper 선택·OPEN·청산"),
        ("ledger_performance", "원장·성과 snapshot"),
        ("runtime_errors", "현재 runtime 오류"),
        ("runtime_deploy", "PID·버전·hash·중복"),
        ("resources", "CPU·메모리·디스크"),
        ("commands_delivery", "명령·Telegram·TXT"),
        ("artifact_chain", "공식파일·cycle/commit 연결"),
        ("storage_hygiene", "임시폴더·backup·cache"),
    )
    for key, label in labels:
        lines.append(_state_summary_line(label, groups.get(key)))
    lines += [
        "",
        f"🧯 현재 오류 원인 {integer(errors.get('current_cause_count'))}개 · 반복 {integer(errors.get('current_count'))}회 · 과거 {integer(errors.get('historical_count'))}회",
        f"💽 디스크 남음 {fmt_num(resources.get('disk_free_gb'), 2)}GB",
        f"🧩 확인할 문제 {len(problems)}개",
    ]
    for item in problems[:4]:
        lines.append(f"- {item.get('code') or '-'} · {item.get('reason') or '확인 필요'}")
    if not problems:
        lines.append("- 없음")
    lines += [
        "",
        "- 이 지도는 진단·수리 위치 확인용이며 신규 차단을 만들지 않음",
        _contract_compact_line(_active_contract_snapshot()),
    ]
    return "\n".join(lines)


def render_flow_map_full(_args: Sequence[str] = ()) -> str:
    obj = _ops_snapshot()
    if not obj:
        return render_flow_map_compact()
    current = mapping(obj.get("current_cycle"))
    last = mapping(obj.get("last_completed_cycle"))
    timing = mapping(obj.get("timing"))
    timing_path = mapping(obj.get("timing_path"))
    funnel = mapping(obj.get("paper_funnel"))
    open_monitor = mapping(obj.get("open_exit_monitor"))
    ledger = mapping(obj.get("ledger_performance"))
    errors = mapping(obj.get("errors"))
    runtime = mapping(obj.get("runtime_deploy"))
    resources = mapping(obj.get("resources"))
    commands = mapping(obj.get("commands_delivery"))
    artifact_chain = mapping(obj.get("artifact_chain"))
    storage_hygiene = mapping(obj.get("storage_hygiene"))
    phase_profiles = mapping(obj.get("phase_profiles"))
    hotpath_v1211 = mapping(obj.get("hotpath_optimization_v1211"))
    invariants = mapping(obj.get("invariants"))
    groups = mapping(obj.get("evidence_groups"))
    problems = [x for x in (obj.get("problems") or []) if isinstance(x, dict)]
    lines = [
        f"코인봇 운영지도 {RELEASE_TAG} · 전수증거·내부시간판",
        "=" * 72,
        "",
        "[1. 한눈에 보기]",
        render_flow_map_compact(),
        "",
        "[2. 현재 cycle · 직전 정상 cycle 분리]",
        f"- 현재: {icon(current.get('state'))} {current.get('state') or 'CHECK'} / cycle {current.get('pipeline_cycle_id') or '-'} / commit {current.get('candidate_commit_id') or '-'}",
        f"- 현재 건수: 후보 {integer(current.get('candidate_rows'))} / S1 {integer(current.get('s1_count'))} / Paper 확인 {integer(current.get('paper_received'))}",
        f"- 진행상태: {current.get('pipeline_progress') or '-'} / 증거 age {fmt_sec(current.get('source_age_sec'))}",
        f"- 직전 정상: {last.get('state') or 'CHECK'} / cycle {last.get('pipeline_cycle_id') or '-'} / commit {last.get('candidate_commit_id') or '-'}",
        f"- 직전 건수: 후보 {last.get('candidate_rows') if last.get('candidate_rows') is not None else '-'} / S1 {last.get('s1_count') if last.get('s1_count') is not None else '-'}",
        "",
        "[3. 20단계 본선 · 건수·시간·증거]",
    ]
    for row in obj.get("stages") or []:
        if not isinstance(row, dict):
            continue
        io = ""
        evidence = mapping(row.get("evidence"))
        if row.get("key") == "exchange":
            io = f" · WS {integer(evidence.get('ws_count'))} / Micro {integer(evidence.get('micro_count'))}"
        elif row.get("key") == "paper_read":
            io = f" · 완료 generation {integer(evidence.get('generation_candidate_rows'))} 확인 / 실행대상 S1 {integer(evidence.get('execution_s1_rows'))} 판독"
        elif row.get("input") is not None or row.get("output") is not None:
            io = f" · 입력 {row.get('input')} → 출력 {row.get('output')}"
        time_text = f" · {fmt_sec(row.get('duration_sec'))}" if row.get("duration_sec") is not None else ""
        age_text = f" · 증거 age {fmt_sec(row.get('evidence_age_sec'))}" if row.get("evidence_age_sec") is not None else ""
        reason = f" · 이유 {row.get('reason')}" if row.get("reason") else ""
        lines.append(f"{int(row.get('index') or 0):02d}. {icon(row.get('state'))} {row.get('label') or row.get('key')}{io}{time_text}{age_text} · owner {row.get('owner') or '-'}{reason}")
    lines += ["", "[3A. 모든 구성요소 내부 단계 시간 · 실제 profile]"]
    profile_components = [x for x in (phase_profiles.get("components") or []) if isinstance(x, dict)]
    if not profile_components:
        lines.append("- 🟡 COLLECTING · 내부시간 profile 첫 표본 대기")
    for component in profile_components:
        scopes = [x for x in (component.get("scopes") or []) if isinstance(x, dict)]
        if not scopes:
            reason = f" · {component.get('reason')}" if component.get('reason') else ""
            lines.append(f"- {icon(component.get('state'))} {component.get('component')} · 내부 단계 표본 대기 · age {fmt_sec(component.get('age_sec'))}{reason}")
            continue
        for scope in scopes:
            slowest = mapping(scope.get("slowest"))
            slow_text = "-"
            if slowest:
                slow_text = f"{slowest.get('category') or '내부처리'} / {slowest.get('function') or '-'} {fmt_sec(slowest.get('cumulative_sec'))}"
            window_text = ""
            if integer(scope.get('window_count')) > 0:
                window_text = f" · 최근 {integer(scope.get('window_count'))}회 평균 {fmt_sec(scope.get('window_avg_sec'))} / 최대 {fmt_sec(scope.get('window_max_sec'))}"
            relation = ""
            if component.get('pid_match') is False or component.get('version_match') is False:
                relation = f" · runtime PID/버전 불일치({component.get('reason') or '확인 필요'})"
            recent_sec = num(scope.get('last_sec'), default=None)
            if recent_sec is None or recent_sec <= 0:
                recent_sec = num(scope.get('total_sec'), default=None)
            lines.append(f"- {icon(scope.get('state'))} {component.get('component')} · {scope.get('scope')} 최근 {fmt_sec(recent_sec)}{window_text} · 최장 {slow_text} · profile {'새표본' if scope.get('profiled_this_call') else '직전표본 유지'}{relation}")
            top = [x for x in (scope.get("top_functions") or []) if isinstance(x, dict)]
            for rank, fn in enumerate(top[:5], 1):
                lines.append(f"   {rank}) {fn.get('category') or '내부처리'} · {fn.get('function') or '-'} · 누적 {fmt_sec(fn.get('cumulative_sec'))} / 자체 {fmt_sec(fn.get('self_sec'))} / 호출 {integer(fn.get('calls'))}")
    lines += ["", "[4. 현재 generation 시간경로 · 과거표본 분리]"]
    execution_rows = [x for x in (timing_path.get("execution_segments") or []) if isinstance(x, dict)]
    semantic_rows = [x for x in (timing_path.get("semantic_wait_segments") or []) if isinstance(x, dict)]
    historical_rows = [x for x in (timing_path.get("historical_reference_segments") or []) if isinstance(x, dict)]
    lines.append(f"- scope cycle {timing_path.get('scope_cycle_id') or '-'} / commit {timing_path.get('scope_candidate_commit_id') or '-'}")
    lines.append("[현재 실행·배관 시간]")
    if not execution_rows:
        lines.append("- 🟡 COLLECTING · 현재 generation 실행시간 표본 수집 중")
    for row in execution_rows[:14]:
        lines.append(f"- {row.get('key') or '-'} · n{integer(row.get('n'))} · 중앙 {fmt_sec(row.get('median_sec'))} · 평균 {fmt_sec(row.get('avg_sec'))} · 최대 {fmt_sec(row.get('max_sec'))}")
    lines.append("[현재 의미상 대기 · 배관속도와 분리]")
    if not semantic_rows:
        lines.append("- 표본 없음")
    for row in semantic_rows[:10]:
        lines.append(f"- {row.get('key') or '-'} · n{integer(row.get('n'))} · 중앙 {fmt_sec(row.get('median_sec'))} · 최대 {fmt_sec(row.get('max_sec'))}")
    lines.append("[과거·범위불명 참고 · 현재 속도판정에 미사용]")
    lines.append(f"- 과거 path 사건 {integer(timing_path.get('historical_path_event_count'))} / 범위불명 path {integer(timing_path.get('unscoped_path_event_count'))} / 범위불명 timing {integer(timing_path.get('unscoped_timing_sample_count'))}")
    for row in historical_rows[:6]:
        lines.append(f"- {row.get('key') or '-'} · n{integer(row.get('n'))} · 중앙 {fmt_sec(row.get('median_sec'))} · 최대 {fmt_sec(row.get('max_sec'))}")
    lines += [
        f"- 현재 Paper 수신 사건 {integer(timing_path.get('paper_received_identity_count'))}개 / 현재 반복노출 {integer(timing_path.get('repeat_exposure_count'))}회",
        f"- 시간판정 {icon(timing_path.get('state'))} {timing_path.get('state') or 'COLLECTING'} · 진단 전용 / 차단 변경 없음",
    ]
    slow_observations = [x for x in (timing_path.get("slow_observations") or []) if isinstance(x, dict)]
    if slow_observations:
        lines += ["", "[속도 수리 우선순위 · 차단 아님]"]
        for row in slow_observations:
            lines.append(f"- {row.get('key')} · {fmt_sec(row.get('value_sec'))} / 관찰기준 {fmt_sec(row.get('observe_limit_sec'))}")
    lines += [
        "",
        "[5. Paper 후보 퍼널 · 실제 제외와 진단 분리]",
        f"- 상태 {icon(funnel.get('state'))} {funnel.get('state') or 'CHECK'}",
        f"- 후보 {integer(funnel.get('candidate_seen'))} → S1 {integer(funnel.get('s1_seen'))} → 선택 {integer(funnel.get('selected'))} → OPEN {integer(funnel.get('opened'))} → CLOSED {integer(funnel.get('closed'))}",
        f"- terminal accounting {integer(funnel.get('accounted'))}/{integer(funnel.get('s1_seen'))} · 미분류 {integer(funnel.get('unclassified'))} · balance {funnel.get('balance_ok')}",
        f"- 실제 진입 제외: {funnel.get('actual_integrity_exclusions') or {}}",
        f"- 진단 전용·차단 아님: {funnel.get('audit_only_findings') or {}}",
        "- 신규 차단 0 · 기존 exact/관찰전용/중복/원장 무결성만 유지",
        "",
        "[6. OPEN·가격감시·청산증거]",
        f"- 상태 {icon(open_monitor.get('state'))} {open_monitor.get('state') or 'CHECK'} / OPEN {integer(open_monitor.get('open_count'))}",
        f"- decision key 누락 {integer(open_monitor.get('decision_key_missing'))} / trigger·invalid·target 누락 {integer(open_monitor.get('structure_contract_missing'))} / 가격 누락 {integer(open_monitor.get('price_missing'))}",
        f"- MFE 누락 {integer(open_monitor.get('mfe_missing'))} / MAE 누락 {integer(open_monitor.get('mae_missing'))} / 반납 누락 {integer(open_monitor.get('giveback_missing'))}",
        f"- target 접촉 후 OPEN {integer(open_monitor.get('target_touched_still_open'))} / invalid 접촉 후 OPEN {integer(open_monitor.get('invalid_touched_still_open'))}",
        f"- 최근 감시 age {fmt_sec(open_monitor.get('latest_monitor_age_sec'))} / 계약증거 완전도 {fmt_num(open_monitor.get('contract_coverage_pct'), 1)}%",
        f"- 동일종목 중복 {open_monitor.get('duplicate_tickers') or {}} / pos_id 중복 {open_monitor.get('duplicate_pos_ids') or {}}",
        "",
        "[7. OPEN·CLOSED·decision·성과 원장]",
        f"- 상태 {icon(ledger.get('state'))} {ledger.get('state') or 'CHECK'} / snapshot {ledger.get('snapshot_id') or '-'}",
        f"- raw {integer(ledger.get('raw_rows'))} / exact {integer(ledger.get('exact_rows'))} / 중복 {integer(ledger.get('duplicates'))} / key 누락 {integer(ledger.get('missing_decision_key'))} / 미연결 {integer(ledger.get('unlinked'))} / bad JSON {integer(ledger.get('bad_json'))}",
        f"- 성과 semantic current {ledger.get('semantic_current')} / heartbeat {ledger.get('heartbeat_state') or '-'} / snapshot age {fmt_sec(ledger.get('performance_age_sec'))}",
        f"- 후보판 성과참조 관계 {ledger.get('reference_relation') or '-'} / 관계정상 {ledger.get('reference_relation_ok')} / OPEN손익 snapshot {ledger.get('book_performance_present')} / 누락 핵심파일 {ledger.get('missing_core_files') or []}",
        "",
        "[8. 현재 runtime 오류 · 과거 오류 분리]",
        f"- 상태 {icon(errors.get('state'))} {errors.get('state') or 'CHECK'} / 현재 원인 {integer(errors.get('current_cause_count'))}개 · 반복 {integer(errors.get('current_count'))}회 / 과거 {integer(errors.get('historical_count'))}회 / 시각불명 {integer(errors.get('unscoped_line_count'))}줄",
    ]
    for row in errors.get("logs") or []:
        if not isinstance(row, dict) or (integer(row.get("current_count")) == 0 and row.get("state") == "NORMAL"):
            continue
        causes = [x for x in (row.get("current_causes") or []) if isinstance(x, dict)]
        if causes:
            for cause in causes[:5]:
                sample = mapping(cause.get("sample"))
                lines.append(f"- {icon(row.get('state'))} {row.get('owner')} · 원인 1개 / 반복 {integer(cause.get('repeat_count'))}회 · 최초 {fmt_ts(cause.get('first_ts'))} / 최근 {fmt_ts(cause.get('last_ts'))} · {str(sample.get('head') or sample.get('excerpt') or '-')[:220]}")
        else:
            excerpt = " / ".join(row.get("unscoped_sample") or []) or "-"
            lines.append(f"- {icon(row.get('state'))} {row.get('owner')} · 시각범위 확인 필요 · {str(excerpt)[:240]}")
    lines += [
        "",
        "[9. runtime·배포·단일프로세스]",
        f"- 상태 {icon(runtime.get('state'))} {runtime.get('state') or 'CHECK'}",
    ]
    for row in runtime.get("components") or []:
        if not isinstance(row, dict):
            continue
        lines.append(f"- {icon(row.get('state'))} {row.get('component')} · PID {row.get('main_pid') or '-'} / proc {row.get('process_count') if row.get('process_count') is not None else '-'} / statusPID {row.get('status_pid') or '-'} / {row.get('status_version') or '-'} / CPU {fmt_num(row.get('cpu_pct'),1)}% / RSS {fmt_num(row.get('rss_mb'),1)}MB / hash일치 {row.get('source_alias_hash_match')}")
    for row in runtime.get("locks") or []:
        if isinstance(row, dict):
            lines.append(f"- lock {row.get('component')} · {icon(row.get('state'))} PID {row.get('lock_pid') or '-'}={row.get('runtime_pid') or '-'} / version {row.get('lock_version') or '-'}")
    server = mapping(resources.get("server"))
    lines += [
        "",
        "[10. 자원·디스크·I/O]",
        f"- 상태 {icon(resources.get('state'))} {resources.get('state') or 'CHECK'}",
        f"- CPU {fmt_num(server.get('cpu_pct'),1)}% / iowait {fmt_num(server.get('iowait_pct'),1)}% / load {server.get('load1') if server.get('load1') is not None else '-'}",
        f"- 메모리 사용 {fmt_num(server.get('mem_used_pct'),1)}% / 사용가능 {fmt_num(server.get('mem_available_mb'),1)}MB / swap 사용 {fmt_num(server.get('swap_used_mb'),1)}MB",
        f"- 디스크 사용 {fmt_num(resources.get('disk_used_pct'),1)}% / 남음 {fmt_num(resources.get('disk_free_gb'),2)}GB",
        f"- 높은 CPU {resources.get('slow_cpu') or []} / 1GB 이상 RSS {resources.get('high_rss') or []}",
        f"- I/O TOP {resources.get('io_top') or []}",
        "",
        "[10A. v1211 중복작업 제거 증거]",
        f"- Paper 상태 {hotpath_v1211.get('paper_state') or 'COLLECTING'} / Strategy 상태 {hotpath_v1211.get('strategy_state') or 'COLLECTING'}",
        f"- Paper 쓰기계층 {mapping(mapping(hotpath_v1211.get('paper')).get('write_tiers')) or {}}",
        f"- Paper 후처리 {mapping(mapping(hotpath_v1211.get('paper')).get('queue')) or {}} / cleanup 주기 {mapping(hotpath_v1211.get('paper')).get('cleanup_interval_sec') or '-'}초",
        f"- Strategy writer {mapping(hotpath_v1211.get('strategy')) or {}}",
        "- 후보·S1·trigger·invalid·target·RR·TOP10·청산계약 변경 없음 / 자동매수 OFF",
        "",
        "[11. Main 명령·Telegram·TXT 편의 흐름]",
        f"- 상태 {icon(commands.get('state'))} {commands.get('state') or 'CHECK'} / Telegram {commands.get('telegram_state') or '-'} / 명령 {integer(commands.get('command_count'))}개",
        f"- 최근 묶음결과 {commands.get('summary_status') or '수집 중'} / TXT {commands.get('txt_count') if commands.get('txt_count') is not None else '-'}개 / snapshot {commands.get('snapshot_id') or '-'}",
        f"- 화면생성 {fmt_sec(commands.get('render_sum_sec'))} / 전송포함 {fmt_sec(commands.get('delivery_total_sec'))} / age {fmt_sec(commands.get('summary_age_sec'))}",
        "",
        "[12. 공식 파일·cycle/commit·snapshot 연결]",
        f"- 상태 {icon(artifact_chain.get('state'))} {artifact_chain.get('state') or 'CHECK'} / fallback 사용 {not bool(artifact_chain.get('no_stale_fallback'))}",
        f"- 기준 cycle {artifact_chain.get('expected_cycle_id') or '-'} / commit {artifact_chain.get('expected_candidate_commit_id') or '-'} / 성과 snapshot {artifact_chain.get('performance_snapshot_id') or '-'}",
        f"- 파일 누락 {artifact_chain.get('missing_files') or []} / ID 누락 {artifact_chain.get('missing_id_evidence') or []} / 실제 불일치 {artifact_chain.get('mismatched_ids') or []} / 수집 중 consumer {artifact_chain.get('collecting_consumers') or []} / 오래된 파일 {artifact_chain.get('stale_artifacts') or []}",
        f"- Review 관계 {artifact_chain.get('review_relation') or '-'} / Review age {fmt_sec(artifact_chain.get('review_age_sec'))} / 요청 age {fmt_sec(artifact_chain.get('review_request_age_sec'))}",
    ]
    for row in artifact_chain.get("id_chain") or []:
        if isinstance(row, dict):
            lines.append(f"- {icon(row.get('state'))} {row.get('artifact')} · 역할 {row.get('role') or '-'} / cycle {row.get('cycle_id') or '-'} / commit {row.get('candidate_commit_id') or '-'} / 현재 일치 {row.get('match_current')} / 관계 {row.get('relation') or '-'}")
    lines += [
        "",
        "[13. 임시폴더·backup·cache·ZIP 보존상태]",
        f"- 상태 {icon(storage_hygiene.get('state'))} {storage_hygiene.get('state') or 'CHECK'} / 상위경로 검사 {integer(storage_hygiene.get('scanned_top_level'))}개 / 삭제 0",
        f"- 개수 {storage_hygiene.get('counts') or {}}",
        f"- 용량 {storage_hygiene.get('bytes_by_kind') or {}}",
        f"- 5분 이상 남은 임시경로 {storage_hygiene.get('abandoned_temp') or []}",
        "",
        "[14. 변경금지·차단금지 고정판]",
        f"- 후보식 변경 {invariants.get('candidate_formula_changed')} / trigger {invariants.get('trigger_changed')} / invalid {invariants.get('invalid_changed')} / target {invariants.get('target_changed')}",
        f"- RR 변경 {invariants.get('rr_changed')} / 청산계약 변경 {invariants.get('exit_contract_changed')} / 신규 차단 {invariants.get('new_blockers_added')}",
        f"- 라이브 원장 쓰기 {invariants.get('live_ledger_write')} / 자동매수 {invariants.get('auto_buy')}",
        _contract_compact_line(mapping(obj.get('active_trade_contract_v1208')) or _active_contract_snapshot()),
        "",
        "[15. 증거그룹 최종판정]",
    ]
    label_map = {
        "data_intake":"시세·호가·시장 입력", "candidate_pipeline":"후보 생성·배관", "paper_execution":"Paper 실행·청산",
        "ledger_performance":"원장·성과", "runtime_errors":"현재 오류", "runtime_deploy":"runtime·배포", "resources":"자원", "commands_delivery":"명령·알림",
        "artifact_chain":"공식파일·cycle/commit", "storage_hygiene":"임시폴더·backup·cache", "phase_timing":"모든 구성요소 내부 단계시간",
    }
    for key, value in groups.items():
        lines.append(_state_summary_line(label_map.get(key, key), value))
    lines += ["", "[16. 중요 문제와 다음 수리 위치]"]
    if not problems:
        lines.append("- 없음")
    for idx, item in enumerate(problems[:30], 1):
        lines.append(f"{idx}. {icon(item.get('state'))} {item.get('code') or '-'}\n   원인: {item.get('reason') or '확인 필요'}\n   영향: {item.get('impact') or '-'}\n   owner: {item.get('owner') or '-'} · 차단추가 {item.get('blocking') is True}")
    lines += [
        "",
        "[판독 원칙]",
        "- NORMAL은 실제 증거가 있을 때만 표시",
        "- 증거 없음=CHECK, 표본 수집 중=COLLECTING, 일부 누락=PARTIAL, 실제 실패=FAIL",
        "- 현재 cycle과 직전 정상 cycle을 섞지 않음",
        "- 지도는 진단·수리 위치 확인용이며 신규 차단을 추가하지 않음",
        "- Main은 Guard snapshot을 표시만 하며 구 cache fallback 없음",
        "- 후보 Gate·trigger·invalid·target·RR은 변경 없음 · 실제 진입·청산 계약은 Paper snapshot 단일본선",
        "- 자동매수 OFF",
    ]
    return "\n".join(lines)

def render_candidate_compact(_args: Sequence[str] = ()) -> str:
    obj = _candidate_snapshot()
    if not obj:
        return "📐 후보 기준판 · 핵심\n🚦 판정 🟡 CHECK_SOURCE\n- Review canonical 기준판 대기\n- 과거판 fallback 없음 · 자동매수 OFF"
    delivery = mapping(obj.get("delivery"))
    candidate = mapping(obj.get("candidate"))
    quality = mapping(obj.get("quality"))
    time_info = mapping(obj.get("time"))
    performance = mapping(obj.get("performance"))
    contract = mapping(mapping(obj.get("contract")).get("paper"), obj.get("contract"))
    active_contract = _active_contract_snapshot()
    active_entry = mapping(active_contract.get('entry'))
    missing = list(obj.get('missing') or [])
    lines = [
        "📐 후보 기준판 · 한눈에 보기",
        f"🚦 판정 {icon(obj.get('state'))} {obj.get('state') or 'CHECK'} · {obj.get('easy_state') or '-'}",
        "",
        "🚰 후보 전달",
        f"- 전체 {integer(candidate.get('total'))} → S1 {integer(candidate.get('s1'))} / S2 {integer(candidate.get('s2'))} / S3 {integer(candidate.get('s3'))}",
        f"- cycle {delivery.get('pipeline_cycle_id') or '-'}",
        f"- commit {delivery.get('candidate_commit_id') or '-'}",
        "",
        "🔬 품질 증거",
        f"- 상태 {quality.get('state') or '-'} · invalid 거리 n{integer(mapping(quality.get('invalid_distance')).get('n'))} · 추격률 n{integer(mapping(quality.get('chase')).get('n'))}",
        f"- Scanner 최초발견 n{integer(time_info.get('occurrence_age_count'))} · Paper 계약 {active_entry.get('state') or contract.get('state') or '정보없음'}",
        "",
        "⏱️ 시간",
        f"- Strategy 전달 {fmt_sec(time_info.get('strategy_execution_handoff_sec'))} · Scanner 최초발견 중앙 {fmt_sec(time_info.get('occurrence_age_median_sec'))}",
        "",
        "📊 fresh CLOSED",
        f"- n{integer(performance.get('count'))} · 승률 {fmt_num(performance.get('win_rate'), 1)}% · 합산 {fmt_pct(performance.get('sum_pct'))}",
        "",
        f"🧩 원천 누락 {len(missing)}개" + (f" · {', '.join(str(x) for x in missing[:4])}" if missing else " · 없음"),
        _contract_compact_line(active_contract),
    ]
    return "\n".join(lines)


def _candidate_metric_text(metric: Mapping[str, Any], digits: int = 3, suffix: str = "") -> str:
    return f"n{integer(metric.get('n'))} / 중앙 {fmt_num(metric.get('median'), digits)}{suffix}"


def _candidate_sample_line(sample: Mapping[str, Any]) -> str:
    metrics = mapping(sample.get("metrics"))
    structure = mapping(sample.get("structure"))
    tags = [str(x) for x in (sample.get("risk_tags") or []) if str(x)]
    risk = "/".join(tags[:2]) if tags else "위험표시 없음"
    return (
        f"- {sample.get('ticker') or '-'} · {sample.get('source_lane') or '-'} · {sample.get('quality_tier') or '-'} "
        f"· 점수 {fmt_num(metrics.get('rank_score'),1)} · RR {fmt_num(metrics.get('rr'),2)} "
        f"· 목표 {fmt_num(metrics.get('target_room'),2)}% · 손절거리 {fmt_num(metrics.get('invalid_distance'),2)}% "
        f"· 추격 {fmt_num(metrics.get('chase'),2)}% · 비용 {fmt_num(metrics.get('spread'),2)}/{fmt_num(metrics.get('slippage'),2)}% "
        f"· 최초 {fmt_sec(sample.get('scanner_occurrence_age_sec'))} · {risk} "
        f"· T/I/G {fmt_num(structure.get('trigger_price'),8)}/{fmt_num(structure.get('invalid_price'),8)}/{fmt_num(structure.get('target_price'),8)}"
    )


def render_candidate_standard(_args: Sequence[str] = ()) -> str:
    obj = _candidate_snapshot()
    if not obj:
        return render_candidate_compact()
    delivery = mapping(obj.get("delivery"))
    candidate = mapping(obj.get("candidate"))
    structure = mapping(obj.get("structure"))
    quality = mapping(obj.get("quality"))
    time_info = mapping(obj.get("time"))
    performance = mapping(obj.get("performance"))
    contract_root = mapping(obj.get("contract"))
    contract = mapping(contract_root.get("paper"), contract_root)
    active_contract = _active_contract_snapshot()
    active_entry = mapping(active_contract.get('entry'))
    active_exit = mapping(active_contract.get('exit'))
    score_components = mapping(quality.get("score_components"))
    missing_counts = mapping(quality.get("metric_missing_counts"))
    lane_summaries = list(quality.get("lane_summaries") or [])
    samples = list(obj.get("samples") or [])
    lines = [
        "코인봇 후보·구조 기준판 v1208",
        "=" * 72,
        "",
        "[한눈에 보기]",
        render_candidate_compact(),
        "",
        "[숫자 범위 · 섞어 보지 않음]",
        f"- 전달: {mapping(obj.get('scope')).get('delivery') or 'current Strategy committed generation'}",
        f"- 후보: {mapping(obj.get('scope')).get('candidate') or 'same candidate commit rows'}",
        f"- 품질: {mapping(obj.get('scope')).get('quality') or 'same-commit Strategy sealed values'}",
        f"- 성과: {mapping(obj.get('scope')).get('performance') or 'Paper canonical performance snapshot only'}",
        "",
        "[후보 전달 배관]",
        f"- cycle {delivery.get('pipeline_cycle_id') or '-'}",
        f"- commit {delivery.get('candidate_commit_id') or '-'}",
        f"- source state {delivery.get('state') or '-'} / age {fmt_sec(delivery.get('request_age_sec'))}",
        "",
        "[구조선 근거 완전성]",
        f"- 평가 {integer(structure.get('evaluated'))} / 근거완전 {integer(structure.get('complete'))} / source missing {integer(structure.get('source_missing'))}",
        f"- trigger source 누락 {integer(structure.get('trigger_source_missing'))} / invalid {integer(structure.get('invalid_source_missing'))} / target {integer(structure.get('target_source_missing'))}",
        "",
        "[진입계약 핵심 · 같은 commit]",
    ]
    core_labels = {
        "rr": ("실제 진입 RR", ""), "target_room": ("target 공간", "%"),
        "invalid_distance": ("invalid 거리", "%"), "chase": ("trigger 추격률", "%"),
        "spread": ("spread", "%"), "slippage": ("slippage", "%"),
    }
    for key, (label, suffix) in core_labels.items():
        lines.append(f"- {label}: {_candidate_metric_text(mapping(quality.get(key)), 3, suffix)} · 누락 {integer(missing_counts.get(key))}")
    lines += ["", "[후보 품질값 · 같은 commit]"]
    quality_labels = {
        "price_reaction": ("가격반응", "%"), "relative_strength": ("상대강도", ""), "money_flow": ("money flow", ""),
        "buy_ratio": ("매수체결 비율", ""), "buy_sustain": ("매수지속", ""), "rank_score": ("rank score", ""),
        "vwap_gap": ("VWAP 거리", "%"), "ema5_gap": ("EMA5 거리", "%"), "turnover_rank": ("거래대금 순위", "%"),
        "volume_ratio": ("거래량 비율", ""), "volume_expansion": ("거래량 변화", "%"), "recent_high_gap": ("최근 고점 거리", "%"),
        "day_position": ("당일 가격 위치", "%"), "upper_wick": ("윗꼬리", "%"), "change_1m": ("1분 변화", "%"), "change_3m": ("3분 변화", "%"),
    }
    for key, (label, suffix) in quality_labels.items():
        lines.append(f"- {label}: {_candidate_metric_text(mapping(quality.get(key)), 3, suffix)} · 누락 {integer(missing_counts.get(key))}")
    turnover = mapping(quality.get("turnover_24h_krw"))
    turnover_median = num(turnover.get("median"), default=None)
    lines.append(f"- 24시간 거래대금: n{integer(turnover.get('n'))} / 중앙 {fmt_num((turnover_median / 100000000.0) if turnover_median is not None else None,2)}억원 · 누락 {integer(missing_counts.get('turnover_24h_krw'))}")
    lines += ["", "[품질 점수 구성]"]
    for key, label in (("structure","구조"),("reaction","가격반응"),("relative_strength","상대강도"),("money_flow","돈흐름"),("execution","실행비용")):
        lines.append(f"- {label}: {_candidate_metric_text(mapping(score_components.get(key)), 3)}")
    lines.append(f"- 등급 분포: {quality.get('quality_tier_counts') or {}}")
    lines.append(f"- 자료없는 축: {quality.get('missing_axis_counts') or {}}")
    lines.append(f"- 주요 위험표시: {quality.get('risk_tag_counts') or {}}")
    lines += ["", "[경로별 S1 비교]"]
    if not lane_summaries:
        lines.append("- 표본 없음")
    for lane in lane_summaries[:10]:
        lines.append(
            f"- {lane.get('lane') or '-'} n{integer(lane.get('count'))} · 점수 {fmt_num(lane.get('rank_score_median'),1)} "
            f"· RR {fmt_num(lane.get('rr_median'),2)} · 목표 {fmt_num(lane.get('target_room_median'),2)}% "
            f"· 손절 {fmt_num(lane.get('invalid_distance_median'),2)}% · 추격 {fmt_num(lane.get('chase_median'),2)}% "
            f"· spread {fmt_num(lane.get('spread_median'),2)}% · 상대강도 {fmt_num(lane.get('relative_strength_median'),1)} · 돈흐름 {fmt_num(lane.get('money_flow_median'),1)}"
        )
    lines += ["", "[현재 S1 상위 후보 · rank score 순]"]
    if not samples:
        lines.append("- 표본 없음")
    for sample in samples[:12]:
        lines.append(_candidate_sample_line(mapping(sample)))
    lines += [
        "",
        "[시간 경로]",
        f"- Scanner 최초발견: n{integer(time_info.get('occurrence_age_count'))} / 중앙 {fmt_sec(time_info.get('occurrence_age_median_sec'))} / owner {time_info.get('occurrence_owner') or '-'}",
        f"- 실제 trigger 발생: n{integer(time_info.get('trigger_age_n'))} / 중앙 {fmt_sec(time_info.get('trigger_age_median_sec'))}",
        f"- S1 준비 후: n{integer(time_info.get('s1_ready_age_n'))} / 중앙 {fmt_sec(time_info.get('s1_ready_age_median_sec'))}",
        f"- Strategy 전달 {fmt_sec(time_info.get('strategy_execution_handoff_sec'))} / 전체 {fmt_sec(time_info.get('strategy_full_cycle_sec'))}",
        "",
        "[Paper 실제 실행·청산 계약]",
        f"- 상태 {active_entry.get('state') or contract.get('state') or '정보없음'} / owner paper_bot.paper_active_contract_snapshot_v1208 / Paper {active_contract.get('version') or contract.get('paper_version') or '-'}",
        f"- 진입 방식 {active_entry.get('entry_mode') or contract.get('entry_mode') or '-'}",
        f"- 실제 개수계약: 총 {active_entry.get('total_cap')} / 일반 {active_entry.get('general_cap')} / 대수익 {active_entry.get('runner_cap')} / cycle당 신규 {active_entry.get('cycle_new_open_cap')}",
        f"- cycle 제한 대기: {active_entry.get('last_cycle_deferred_count',0)}개 · 다음 cycle 새 가격·RR·목표공간·추격·spread·slippage·비용으로 재평가",
        f"- 실제 유지 무결성: {', '.join(str(x) for x in (contract.get('kept_integrity') or [])) or '-'}",
        f"- 진단만 하고 차단하지 않음: {', '.join(str(x) for x in (contract.get('disabled_diagnostics') or [])) or '-'}",
    ]
    lines.append(
        f"- 신규 OPEN 청산계약: 동적 {active_exit.get('state') or '-'} / 일반 이탈·약화 {mapping(active_exit.get('general_confirmation')).get('support_break_polls')}회·힘약화 {mapping(active_exit.get('general_confirmation')).get('momentum_weak_polls')}회 "
        f"/ 대수익 {mapping(active_exit.get('runner_confirmation')).get('support_break_polls')}회·{mapping(active_exit.get('runner_confirmation')).get('momentum_weak_polls')}회 / 무진행 {fmt_num(active_exit.get('no_progress_minutes'),0)}분"
    )
    lines += [
        "- 기존 OPEN은 진입 당시 봉인 계약 유지 · 이 화면은 읽기만 함",
        "",
        "[fresh 성과]",
        stat_line("fresh CLOSED", performance),
        f"- snapshot {performance.get('snapshot_id') or '-'} / owner {performance.get('source_owner') or '-'}",
        "",
        "[원천 누락]",
        "- " + (", ".join(str(x) for x in (obj.get("missing") or [])) if obj.get("missing") else "없음"),
        "",
        "[잠금]",
        "- 후보식·trigger·invalid·target·RR은 변경 없음 · 청산은 OPEN 당시 봉인 계약 유지",
        f"- 실제 개수계약: 총 {active_entry.get('total_cap')} / 일반 {active_entry.get('general_cap')} / 대수익 {active_entry.get('runner_cap')} / cycle당 신규 {active_entry.get('cycle_new_open_cap')} · 자동매수 OFF",
    ]
    return "\n".join(lines)

def render_health(_args: Sequence[str] = ()) -> str:
    obj = _ops_snapshot()
    workers = mapping(obj.get("workers"))
    disk = mapping(obj.get("disk"))
    lines = [
        f"🩺 코인봇 상태 · {BOT_VERSION}",
        f"- 운영지도: {icon(obj.get('overall_state'))} {obj.get('overall_state') or 'CHECK_SOURCE'}",
        f"- snapshot age: {fmt_sec(file_age(PATHS.ops_snapshot))}",
        f"- 디스크 남음: {disk.get('free_mb') if disk.get('free_mb') is not None else '정보없음'}MB",
        "- 자동매수: OFF",
        "",
        "[공장 상태]",
    ]
    if not workers:
        lines.append("- Guard snapshot 없음")
    for key, item in workers.items():
        if not isinstance(item, dict):
            continue
        lines.append(
            f"- {icon(item.get('state'))} {key}: {item.get('state') or 'CHECK'} · "
            f"{item.get('version') or '-'} · age {fmt_sec(item.get('age_sec'))} · phase {item.get('phase') or '-'}"
        )
    return "\n".join(lines)


def render_swing_status(_args: Sequence[str] = ()) -> str:
    standard = _candidate_snapshot()
    paper = _paper_status()
    contract = mapping(standard.get("contract"))
    return "\n".join([
        "🎯 ALT_SWING 상태",
        f"- 전략모드: {STRATEGY_MODE}",
        "- 시간축: 4h·2h 대세/target → 1h·30m setup/invalid → 15m·5m trigger → 1m·호가 실행비용",
        f"- 후보 기준판: {icon(standard.get('state'))} {standard.get('state') or 'CHECK_SOURCE'}",
        f"- Paper: {paper.get('version') or paper.get('paper_version') or '-'} / phase {paper.get('runtime_phase_v994') or paper.get('phase') or paper.get('startup_phase') or '-'}",
        f"- 실행 core: {'정상 분리' if paper.get('paper_fast_core_v1181') is True else '확인 필요'} / cycle {fmt_sec(paper.get('elapsed_sec'))}",
        f"- 계약 owner: {contract.get('owner') or '정보없음'}",
        "- 후보식·Gate·trigger·invalid·target·RR은 변경 없음 · 실제 청산계약은 Paper snapshot 표시",
        "- 자동매수 OFF",
    ])


def render_pstatus(_args: Sequence[str] = ()) -> str:
    obj = _paper_status()
    if not obj:
        return "📄 Paper 상태\n- CHECK_SOURCE · paper_bot_status.json 없음\n- 자동매수 OFF"
    stats = mapping(obj.get("pick_stats"))
    post = mapping(obj.get("paper_postprocess_v1181"))
    return "\n".join([
        "📄 Paper 실행 core",
        f"- 상태: {icon('NORMAL' if obj.get('running') is not False else 'FAIL')} {'실행 중' if obj.get('running') is not False else '중지'}",
        f"- 버전: {obj.get('version') or obj.get('paper_version') or '-'} / {obj.get('build') or '-'}",
        f"- phase: {obj.get('runtime_phase_v994') or obj.get('phase') or obj.get('startup_phase') or '-'}",
        f"- cycle: {fmt_sec(obj.get('elapsed_sec'))}",
        f"- OPEN: {integer(obj.get('open_count'), obj.get('open_total'))} / 신규 {integer(obj.get('opened_this_cycle'))} / CLOSED {integer(obj.get('closed_this_cycle'))}",
        f"- batch prepared/committed: {integer(stats.get('open_batch_prepared_v1180'))}/{integer(stats.get('open_batch_committed_v1180'))}",
        f"- OPEN snapshot write: {integer(stats.get('open_snapshot_write_count_v1180'))} / decision write: {integer(stats.get('decision_state_write_count_v1180'))}",
        f"- 후처리: {post.get('state') or '수집 중'} · {fmt_sec(post.get('elapsed_sec'))}",
        "- 자동매수 OFF",
    ])


def _open_rows() -> List[Dict[str, Any]]:
    obj = current_json(PATHS.paper_open, {}) or {}
    rows: List[Dict[str, Any]] = []
    if isinstance(obj, list):
        rows = [dict(x) for x in obj if isinstance(x, dict)]
    elif isinstance(obj, dict):
        for key, value in obj.items():
            if isinstance(value, dict):
                row = dict(value)
                row.setdefault("pos_id", key)
                rows.append(row)
    return rows


def render_popen(args: Sequence[str] = ()) -> str:
    rows = _open_rows()
    ticker_filter = str(args[0]).upper() if args else ""
    if ticker_filter:
        rows = [row for row in rows if ticker_filter in str(row.get("ticker") or row.get("market") or "").upper()]
    lines = [f"📂 현재 OPEN {len(rows)}개"]
    for row in rows[:30]:
        pnl = num(row.get("pnl_pct"), row.get("current_pnl_pct"), row.get("unrealized_pnl_pct"), default=None)
        lines.append(
            f"- {row.get('ticker') or row.get('market') or '-'} · 진입 {row.get('entry_price') or '-'} · "
            f"현재 {row.get('current_price') or row.get('last_price') or '-'} · 손익 {fmt_pct(pnl)} · pos {row.get('pos_id') or '-'}"
        )
    if not rows:
        lines.append("- 없음")
    if len(rows) > 30:
        lines.append(f"- 외 {len(rows)-30}개 · 상세는 /open_book_audit")
    return "\n".join(lines)


def _window_stat(snapshot: Mapping[str, Any], *names: str) -> Dict[str, Any]:
    windows = mapping(snapshot.get("windows"))
    for name in names:
        value = windows.get(name)
        if isinstance(value, dict):
            return value
    return {}


def _book_map(snapshot: Mapping[str, Any]) -> Dict[str, Any]:
    return _deep_mapping(
        snapshot,
        "book_performance_v1189",
        "book_performance",
        "book_performance_v1043",
        "open_book",
        "diagnostics_v1010.book_performance",
    )


def _fresh_epoch(snapshot: Mapping[str, Any]) -> Dict[str, Any]:
    return _deep_mapping(
        snapshot,
        "performance_epoch_v1045.stats",
        "performance_epoch_v1045.windows.all",
        "fresh_epoch_stats",
        "fresh_epoch",
        "summary",
    )


def _recent_diag(snapshot: Mapping[str, Any]) -> Dict[str, Any]:
    return _deep_mapping(snapshot, "diagnostics_v1010.recent_24h", "diagnostics.recent_24h")


def _today_profit_top_lines(snapshot: Mapping[str, Any]) -> List[str]:
    top = mapping(snapshot.get("today_profit_top_v1189"))
    rows = [x for x in (top.get("rows") or []) if isinstance(x, dict)]
    lines = ["🏆 오늘 실현수익 TOP5 · CLOSED"]
    if not rows:
        lines.append("- 오늘 양수 CLOSED 표본 수집 중")
        return lines
    for idx, row in enumerate(rows[:5], 1):
        lines.append(f"{idx}. {row.get('ticker') or '-'} {fmt_pct(row.get('pnl_pct'), 2)} · {row.get('exit_reason') or '-'}")
    lines.append(f"- TOP{len(rows[:5])} 합산 {fmt_pct(top.get('sum_pct'), 2)}")
    return lines


def render_version_score(_args: Sequence[str] = ()) -> str:
    snapshot = _performance_snapshot()
    if not snapshot:
        return "📊 성과 /version_score · canonical 단일본선\n❌ canonical snapshot 준비 안 됨\n- 구 cache fallback 없음"
    counts = mapping(snapshot.get("counts"))
    fresh = _fresh_epoch(snapshot)
    if not fresh:
        fresh = _window_stat(snapshot, "all")
    book = _book_map(snapshot)
    diag = _recent_diag(snapshot)
    reasons = mapping(diag.get("primary_exit_reason"))
    tags = mapping(diag.get("auxiliary_loss_tags"))
    methods = mapping(diag.get("by_entry_method"))
    source_perf = _deep_mapping(snapshot, "source_inflow_performance", "by_source_lane", "diagnostics_v1010.source_inflow_performance")
    age = file_age(PATHS.performance)
    trust_state = "NORMAL" if age is not None and age <= 900 else "CHECK"
    lines = [
        "📊 성과 /version_score · canonical 단일본선",
        "",
        "[성과 신뢰판정]",
        f"- 데이터 신뢰: {icon(trust_state)} {trust_state} / snapshot age {fmt_sec(age)}",
        f"- snapshot: {snapshot.get('snapshot_id') or '-'}",
        f"- 생성: {snapshot.get('generated_at_text') or snapshot.get('generated_at') or snapshot.get('generated_text') or '-'}",
        f"- owner: {snapshot.get('source_owner') or snapshot.get('owner') or '-'}",
        "- Main 독립 재계산·구 cache fallback 없음",
        "",
        "[시간별 실현 CLOSED · 현재 흐름 먼저]",
    ]
    windows_to_show = [
        ("최근 3시간", ("recent_3h", "last_3h")),
        ("최근 6시간", ("recent_6h", "last_6h")),
        ("최근 24시간", ("recent_24h", "last_24h")),
        ("오늘", ("today",)),
        ("어제", ("yesterday",)),
    ]
    for label, names in windows_to_show:
        lines.append(stat_line(label, _window_stat(snapshot, *names)))
    lines += ["", "[오늘 수익 상위 거래]"] + _today_profit_top_lines(snapshot)
    lines += [
        "",
        "[새 성과구간 · fresh exact CLOSED]",
        stat_line("새 성과구간", fresh),
        "",
        "[전체 누적 · 참고값]",
        stat_line("전체", _window_stat(snapshot, "all")),
    ]

    lines += ["", "━━━━━━━━━━━━━━━━━━━━", "⚖️ CLOSED + 현재 OPEN 함께 보기", "━━━━━━━━━━━━━━━━━━━━"]
    closed_stat = mapping(book.get("fresh_closed"), fresh)
    open_stat = mapping(book.get("fresh_open"), book.get("current_open"), book.get("current"))
    combined = mapping(book.get("fresh_closed_plus_open"), book.get("combined"))
    if closed_stat or open_stat or combined:
        lines.append(stat_line("fresh CLOSED", closed_stat))
        lines.append(stat_line("현재 OPEN", open_stat, include_path=False))
        lines.append(stat_line("CLOSED+OPEN 단순합", combined, include_path=False))
        account = num(book.get("account_weighted_compound_pct"), book.get("account_compound_pct"), default=None)
        lines.append(f"- 계좌 가중 누적수익률: {fmt_pct(account)}")
    else:
        lines.append("- Paper canonical book 성과 필드 수집 중")
    lines.append("- 거래별 % 단순합은 계좌 누적수익률이 아님")

    if source_perf:
        lines += ["", "[유입경로별 fresh CLOSED 성과]"]
        for name, stat in sorted(source_perf.items(), key=lambda item: _stat_count(item[1] if isinstance(item[1], dict) else {}), reverse=True):
            if isinstance(stat, dict):
                lines.append(stat_line(str(name), stat))

    if reasons:
        lines += ["", "[주 청산원인 · 거래당 1개]"]
        for name, stat in sorted(reasons.items(), key=lambda item: _stat_count(item[1] if isinstance(item[1], dict) else {}), reverse=True)[:12]:
            if isinstance(stat, dict) and _stat_count(stat):
                lines.append(stat_line(str(name), stat))
    if tags:
        lines += ["", "[보조 손실태그 · 서로 중복 가능]"]
        labels = {
            "positive_mfe_then_loss": "수익구간 후 손실전환",
            "no_positive_mfe": "양수 MFE 없이 종료",
            "mfe_missing": "MFE 미기록",
            "repeated_ticker_entry": "반복 종목 진입",
        }
        for key, label in labels.items():
            stat = mapping(tags.get(key))
            if stat and _stat_count(stat):
                lines.append(stat_line(label, stat))
    if methods:
        lines += ["", "[실제 진입방식별 · 최근 24시간]"]
        for name, stat in sorted(methods.items(), key=lambda item: _stat_count(item[1] if isinstance(item[1], dict) else {}), reverse=True)[:10]:
            if isinstance(stat, dict):
                lines.append(stat_line(str(name), stat))

    recent = snapshot.get("recent_rows") if isinstance(snapshot.get("recent_rows"), list) else []
    lines += ["", "[최근 CLOSED 5건]"]
    if not recent:
        lines.append("- 정보없음")
    for row in recent[-5:]:
        if not isinstance(row, dict):
            continue
        lines.append(
            f"- {row.get('ticker') or row.get('market') or '-'} · {fmt_pct(row.get('net_pnl_pct') or row.get('pnl_pct'))} · "
            f"{row.get('reason') or row.get('exit_reason') or '-'} · MFE {fmt_pct(row.get('mfe_pct'))} / MAE {fmt_pct(row.get('mae_pct'))}"
        )
    lines += [
        "",
        "[snapshot·원장]",
        f"- raw {integer(counts.get('raw_ledger_rows'))} · exact {integer(counts.get('exact_unique_closed'), counts.get('included'))} · 중복 {integer(counts.get('duplicate_closed_rows'), counts.get('duplicates'))}",
        f"- key 누락 {integer(counts.get('missing_decision_key'), counts.get('missing_key'))} · 미연결 {integer(counts.get('decision_not_closed_or_missing'), counts.get('unlinked'))} · bad JSON {integer(counts.get('bad_json_rows'))}",
        "- 기술통계만 표시 · 전략 수치 자동 변경 없음",
        "- 자동매수 OFF",
    ]
    return "\n".join(lines)


def _score_period_icon(stat_obj: Any) -> str:
    stat = stat_obj if isinstance(stat_obj, dict) else {}
    total = _stat_total(stat)
    if total is None:
        return "⚪"
    if total > 0:
        return "✅"
    if total < 0:
        return "❌"
    return "➖"


def _score_period_lines(label: str, stat_obj: Any) -> List[str]:
    stat = stat_obj if isinstance(stat_obj, dict) else {}
    n = _stat_count(stat)
    if not stat and n == 0:
        return [f"⚪ {label} · 정보 수집 중"]
    return [
        f"{_score_period_icon(stat)} {label} · {n}전 {_stat_wins(stat)}승 {_stat_losses(stat)}패 · 승률 {fmt_num(_stat_win_rate(stat), 1)}%",
        f"   합산 {fmt_pct(_stat_total(stat), 2)} · 평균 {fmt_pct(_stat_avg(stat), 2)}",
    ]


def _top_rows_from_book(raw: Mapping[str, Any], family: str) -> Tuple[List[Dict[str, Any]], Optional[float]]:
    aliases = {
        "profit": ("profit_top", "profit_top_rows", "top_profit", "top_winners", "positive_top", "current_profit_top"),
        "loss": ("loss_top", "loss_top_rows", "top_loss", "top_losers", "negative_top", "current_loss_top"),
        "giveback": ("giveback_top", "giveback_top_rows", "top_giveback", "current_giveback_top"),
    }
    sum_aliases = {
        "profit": ("profit_top_sum", "top_profit_sum", "positive_top_sum"),
        "loss": ("loss_top_sum", "top_loss_sum", "negative_top_sum"),
        "giveback": ("giveback_top_sum", "top_giveback_sum"),
    }
    rows: List[Dict[str, Any]] = []
    for key in aliases.get(family, ()):
        value = raw.get(key)
        if isinstance(value, list):
            rows = [dict(x) for x in value if isinstance(x, dict)][:3]
            if rows:
                break
    total = None
    for key in sum_aliases.get(family, ()):
        total = num(raw.get(key), default=None)
        if total is not None:
            break
    if total is None and rows:
        values = []
        for row in rows:
            if family == "giveback":
                value = num(row.get("giveback_pct"), row.get("value_pct"), default=None)
            else:
                value = num(row.get("pnl_pct"), row.get("current_pnl_pct"), row.get("value_pct"), default=None)
            if value is not None:
                values.append(value)
        if values:
            total = sum(values)
    return rows, total


def _open_book_lines(book: Mapping[str, Any], fallback_open_count: int = 0) -> List[str]:
    raw = dict(book or {})
    open_stat = mapping(raw.get("fresh_open"), raw.get("current_open"), raw.get("current"))
    open_count = integer(raw.get("open_count"), open_stat.get("count"), open_stat.get("n"), fallback_open_count, default=0)
    valid = integer(raw.get("valid_pnl_rows"), open_stat.get("count"), open_stat.get("n"), default=0)
    missing = integer(raw.get("missing_pnl_rows"), default=max(0, open_count - valid))
    current_total = num(raw.get("current_total"), _stat_total(open_stat), default=None)
    current_avg = num(raw.get("current_avg"), _stat_avg(open_stat), default=None)
    wins = integer(raw.get("wins"), open_stat.get("wins"), default=0)
    losses = integer(raw.get("losses"), open_stat.get("losses"), default=0)
    flats = integer(raw.get("flats"), default=max(0, valid - wins - losses))
    positive_total = num(raw.get("positive_total"), default=None)
    negative_total = num(raw.get("negative_total"), default=None)
    lines = [
        "━━━━━━━━━━━━━━━━━━━━",
        f"📦 현재 OPEN {open_count}개 · 미종료 거래",
        "━━━━━━━━━━━━━━━━━━━━",
    ]
    if not raw and not open_stat:
        lines += [
            "📊 평가손익 원천 수집 중",
            "- OPEN 수는 Paper epoch 기준 · 손익은 canonical book snapshot 대기",
        ]
        return lines
    lines += [
        f"📊 평가 가능 {valid}개 · 확인 필요 {missing}개",
        f"💰 전체 평가손익 {fmt_pct(current_total, 2)} · 평균 {fmt_pct(current_avg, 2)}",
        "",
        f"🟢 수익 {wins}개" + (f" · 합계 {fmt_pct(positive_total, 2)}" if positive_total is not None else ""),
        f"🔴 손실 {losses}개" + (f" · 합계 {fmt_pct(negative_total, 2)}" if negative_total is not None else ""),
        f"⚪ 보합 {flats}개",
    ]
    mfe_total = num(raw.get("mfe_total"), default=None)
    giveback_total = num(raw.get("giveback_total"), default=None)
    giveback_avg = num(raw.get("giveback_avg"), default=None)
    if mfe_total is not None or giveback_total is not None:
        lines += [
            "",
            f"🚀 보유 중 최고수익 합 {fmt_pct(mfe_total, 2)}",
            f"↩️ 현재까지 반납 합 {fmt_num(giveback_total, 2)}%p · 평균 {fmt_num(giveback_avg, 2)}%p",
        ]
    for family, title, emoji in (("profit", "현재 수익 TOP3", "⬆️"), ("loss", "현재 손실 TOP3", "⬇️"), ("giveback", "수익 반납 TOP3", "⚠️")):
        rows, total = _top_rows_from_book(raw, family)
        if not rows:
            continue
        unit = "%p" if family == "giveback" else "%"
        total_text = "정보없음" if total is None else f"{total:+.2f}{unit}"
        lines += ["", f"{emoji} {title} · 합 {total_text}"]
        for row in rows:
            symbol = row.get("ticker") or row.get("market") or row.get("symbol") or "-"
            if family == "giveback":
                value = num(row.get("giveback_pct"), default=None)
            else:
                value = num(row.get("pnl_pct"), row.get("current_pnl_pct"), row.get("value_pct"), default=None)
            value_text = "정보없음" if value is None else (f"{value:+.2f}%p" if family == "giveback" else f"{value:+.2f}%")
            lines.append(f"- {symbol} {value_text}")
    lines += [
        "⚠️ 위 CLOSED 승률에는 현재 OPEN이 포함되지 않음",
        "- 손익 합계는 종목별 수익률 단순합 · 계좌 가중수익률 아님",
    ]
    return lines

def render_version_score_compact(_args: Sequence[str] = ()) -> str:
    snapshot = _performance_snapshot()
    if not snapshot:
        return render_version_score()
    age = file_age(PATHS.performance)
    epoch = _deep_mapping(snapshot, "performance_epoch_v1045")
    fallback_open_count = integer(epoch.get("current_open_count"), default=0)
    lines = [
        "📊 성과 /version_score · canonical 단일본선",
        "",
        "[기간별 전략 결과 · 현재 흐름]",
        f"- 신뢰: {icon('NORMAL' if age is not None and age <= 900 else 'CHECK')} snapshot age {fmt_sec(age)}",
    ]
    windows_to_show = [
        ("오늘", ("today",)),
        ("어제", ("yesterday",)),
        ("최근 3시간", ("recent_3h", "last_3h")),
        ("최근 6시간", ("recent_6h", "last_6h")),
        ("최근 24시간", ("recent_24h", "last_24h")),
    ]
    for label, names in windows_to_show:
        lines.extend(_score_period_lines(label, _window_stat(snapshot, *names)))
    lines.extend([""] + _today_profit_top_lines(snapshot))
    fresh = _fresh_epoch(snapshot)
    lines += [
        "",
        "━━━━━━━━━━━━━━━━━━━━",
        "🧪 새 성과구간 · fresh exact CLOSED",
        "━━━━━━━━━━━━━━━━━━━━",
    ]
    lines.extend(_score_period_lines("새 성과구간", fresh))
    lines.extend([""] + _open_book_lines(_book_map(snapshot), fallback_open_count))
    lines += [
        "",
        "📚 전체 누적 · 과거 참고",
    ]
    lines.extend(_score_period_lines("전체 누적", _window_stat(snapshot, "all")))
    lines += [
        f"- snapshot {snapshot.get('snapshot_id') or '-'}",
        "- 상세 원인·진입방식·최근거래는 TXT",
        "- 자동매수 OFF",
    ]
    return "\n".join(lines)


def render_performance_lab(_args: Sequence[str] = ()) -> str:
    snapshot = _performance_snapshot()
    if not snapshot:
        return "📈 /performance_lab\n- CHECK_SOURCE · canonical performance snapshot 없음"
    counts = mapping(snapshot.get("counts"))
    diag = _recent_diag(snapshot)
    overall = mapping(diag.get("overall_metrics"))
    classes = mapping(diag.get("contract_classification"))
    lines = [
        "📈 /performance_lab · canonical 단일본선",
        "",
        "[canonical 연결]",
        f"- snapshot {snapshot.get('snapshot_id') or '-'} / owner {snapshot.get('source_owner') or snapshot.get('owner') or '-'} / age {fmt_sec(file_age(PATHS.performance))}",
        f"- exact CLOSED {integer(counts.get('exact_unique_closed'), counts.get('included'))} · raw {integer(counts.get('raw_ledger_rows'))}",
        f"- 중복 {integer(counts.get('duplicate_closed_rows'))} · key 누락 {integer(counts.get('missing_decision_key'))} · 미연결 {integer(counts.get('decision_not_closed_or_missing'))}",
        "",
        "[최근 24시간 품질]",
        stat_line("전체", overall),
    ]
    if classes:
        lines += ["", "[계약 분류]"]
        for name, stat in classes.items():
            if isinstance(stat, dict):
                lines.append(stat_line(str(name), stat))
    lines += ["", "- Main은 snapshot을 읽기만 함 · 전략수치 변경 없음"]
    return "\n".join(lines)


def render_profit_audit(_args: Sequence[str] = ()) -> str:
    snapshot = _performance_snapshot()
    if not snapshot:
        return "💰 /profit_audit\n- CHECK_SOURCE · canonical performance snapshot 없음"
    book = _book_map(snapshot)
    source_perf = _deep_mapping(snapshot, "source_inflow_performance", "by_source_lane", "diagnostics_v1010.source_inflow_performance")
    lines = ["💰 수익성 감사 · canonical", stat_line("fresh CLOSED", _fresh_epoch(snapshot) or _window_stat(snapshot, "all"))]
    if book:
        lines += [stat_line("현재 OPEN", mapping(book.get("fresh_open"), book.get("current_open")), False), stat_line("CLOSED+OPEN", mapping(book.get("fresh_closed_plus_open"), book.get("combined")), False)]
    if source_perf:
        lines += ["", "[유입경로]"]
        for name, stat in source_perf.items():
            if isinstance(stat, dict):
                lines.append(stat_line(str(name), stat))
    lines += ["", "- 비용 후 기대값과 현재 OPEN 포함 결과가 검증되기 전 실매수 금지", "- 자동매수 OFF"]
    return "\n".join(lines)


def render_open_book_audit(_args: Sequence[str] = ()) -> str:
    snapshot = _performance_snapshot()
    book = _book_map(snapshot)
    rows = _open_rows()
    lines = ["📚 /open_book_audit · canonical OPEN", f"- 현재 OPEN row {len(rows)}"]
    if book:
        lines += [stat_line("현재 OPEN", mapping(book.get("fresh_open"), book.get("current_open"), book.get("current")), False), stat_line("CLOSED+OPEN", mapping(book.get("fresh_closed_plus_open"), book.get("combined")), False)]
    else:
        lines.append("- canonical OPEN 성과요약 수집 중")
    lines += ["", "[보유 표본]"]
    for row in rows[:20]:
        lines.append(f"- {row.get('ticker') or row.get('market') or '-'} · 손익 {fmt_pct(row.get('pnl_pct') or row.get('current_pnl_pct'))} · MFE {fmt_pct(row.get('mfe_pct'))} · MAE {fmt_pct(row.get('mae_pct'))}")
    if len(rows) > 20:
        lines.append(f"- 외 {len(rows)-20}개")
    lines += ["", "- OPEN/CLOSED/decision 원장 재작성 없음", "- 기존 OPEN 계약 변경 없음 · 자동매수 OFF"]
    return "\n".join(lines)


def render_book_reset_status(_args: Sequence[str] = ()) -> str:
    paths = [
        BASE_DIR / "paper_quality_rebuild_status_v1095.json",
        BASE_DIR / "paper_quality_rebuild_manifest_v1095.json",
        BASE_DIR / "paper_quality_rebuild_control_v1095.json",
        BASE_DIR / "paper_quality_rebuild_execution_v1045.json",
    ]
    objs = [(path, current_json(path, {}) or {}) for path in paths]
    lines = ["📘 /book_reset_status · canonical", "- 과거 reset·성과구간 참고판"]
    found = False
    for path, obj in objs:
        if isinstance(obj, dict) and obj:
            found = True
            lines.append(f"- {path.name}: {obj.get('state') or obj.get('status') or '기록 있음'} / age {fmt_sec(file_age(path))}")
    if not found:
        lines.append("- 현재 원천 없음 · 구 cache fallback 사용 안 함")
    lines += ["- 현재 전략·OPEN 계약 변경 없음 · 자동매수 OFF"]
    return "\n".join(lines)


def render_trade_review(_args: Sequence[str] = ()) -> str:
    obj = current_json(PATHS.review_snapshot, {}) or {}
    if not isinstance(obj, dict) or not obj:
        return "🔎 거래 복기\n- CHECK_SOURCE · Review snapshot 없음"
    candidate = mapping(obj.get("candidate"))
    structure = mapping(obj.get("structure"))
    timing = mapping(obj.get("time"))
    perf = mapping(obj.get("performance"))
    return "\n".join([
        "🔎 거래·후보 복기",
        f"- snapshot: {obj.get('snapshot_id') or '-'}",
        f"- 후보 {integer(candidate.get('total'))} / S1 {integer(candidate.get('s1'))}",
        f"- 구조근거 완전 {integer(structure.get('complete'))}/{integer(structure.get('evaluated'))}",
        f"- occurrence age 중앙 {fmt_sec(timing.get('occurrence_age_median_sec'))}",
        stat_line("fresh CLOSED", perf),
        "- 관찰값은 진입조건을 새로 만들지 않음",
    ])


def render_early_audit(_args: Sequence[str] = ()) -> str:
    standard = _candidate_snapshot()
    samples = [x for x in (standard.get("samples") or []) if isinstance(x, dict)]
    lines = ["🚀 /early_audit · 현재 candidate commit 표본", f"- 표본 {len(samples)}개"]
    for row in samples[:20]:
        lines.append(f"- {row.get('ticker') or row.get('market') or '-'} · grade {row.get('candidate_grade') or row.get('stage') or '-'} · source {row.get('source_lane') or row.get('candidate_source') or '-'}")
    if not samples:
        lines.append("- 표본 없음")
    lines += ["- 분석 전용 · selector 자동 반영 없음"]
    return "\n".join(lines)


def _ledger_path(kind: str) -> Optional[Path]:
    return find_ledger(BASE_DIR, kind)


def render_issue_ledger(_args: Sequence[str] = (), full: bool = False) -> str:
    path = _ledger_path("issue")
    if path is None:
        return "📒 문제장부\n- CHECK_SOURCE · canonical issue ledger 없음"
    rows = read_jsonl_tail(path, limit=3000 if full else 700)
    latest: Dict[str, Dict[str, Any]] = {}
    for row in rows:
        key = text(row.get("issue_id"), row.get("id"), row.get("key"))
        if key:
            latest[key] = row
    active = [row for row in latest.values() if str(row.get("status") or row.get("state") or "").upper() not in {"DONE", "CLOSED", "RESOLVED"}]
    lines = [f"📒 문제장부 · 활성 {len(active)}개", f"- source: {path.name}"]
    limit = 100 if full else 30
    for row in active[-limit:]:
        state = text(row.get("status"), row.get("state"), default="CHECK")
        lines.append(f"- {icon(state)} {row.get('issue_id') or row.get('id') or '-'} · {state}\n  {row.get('title') or row.get('detail') or row.get('symptom') or '내용 정보없음'}")
    if not active:
        lines.append("- 활성 issue 없음")
    return "\n".join(lines)


def render_change_verify(_args: Sequence[str] = (), full: bool = False) -> str:
    path = _ledger_path("change")
    if path is None:
        return "🧾 변경·검수장부\n- CHECK_SOURCE · canonical change ledger 없음"
    rows = read_jsonl_tail(path, limit=500 if full else 80)
    lines = ["🧾 변경·검수장부 · 최근 기록", f"- source: {path.name}"]
    limit = 100 if full else 20
    for row in rows[-limit:]:
        state = text(row.get("verify_result"), row.get("status"), default="CHECK")
        lines.append(f"- {icon(state)} {row.get('change_id') or row.get('id') or '-'} · {state}\n  {row.get('symptom') or row.get('new_mainline') or row.get('detail') or '-'}")
    return "\n".join(lines)


def render_ledger_audit(_args: Sequence[str] = ()) -> str:
    snapshot = _performance_snapshot()
    counts = mapping(snapshot.get("counts"))
    return "\n".join([
        "📚 /ledger_audit · canonical",
        f"- snapshot {snapshot.get('snapshot_id') or '-'} / age {fmt_sec(file_age(PATHS.performance))}",
        f"- raw {integer(counts.get('raw_ledger_rows'))} / exact {integer(counts.get('exact_unique_closed'), counts.get('included'))}",
        f"- 중복 {integer(counts.get('duplicate_closed_rows'), counts.get('duplicates'))}",
        f"- decision key 누락 {integer(counts.get('missing_decision_key'), counts.get('missing_key'))}",
        f"- decision 미연결 {integer(counts.get('decision_not_closed_or_missing'), counts.get('unlinked'))}",
        f"- bad JSON {integer(counts.get('bad_json_rows'))}",
        "- 원장 삭제·축소·재작성 없음",
    ])


def render_errorlog(_args: Sequence[str] = ()) -> str:
    summary = error_scope_summary(BASE_DIR)
    lines = [
        "🧯 /errorlog · 현재 runtime 기준",
        "",
        f"- 상태 {icon(summary.get('state'))} {summary.get('state') or 'CHECK'}",
        f"- 현재 오류 원인 {integer(summary.get('current_cause_count'))}개 · 반복 {integer(summary.get('current_count'))}회",
        f"- 과거 보존 {integer(summary.get('historical_count'))}회 · 원인 {integer(summary.get('historical_cause_count'))}개",
        f"- 시각 범위 불명 {integer(summary.get('unscoped_line_count'))}줄",
    ]
    causes = [x for x in (summary.get("current_causes") or []) if isinstance(x, dict)]
    if not causes:
        lines += ["", "✅ 현재 runtime 신규 오류 없음"]
    else:
        lines += ["", "[현재 runtime 오류 원인]"]
        for cause in causes[:12]:
            sample = mapping(cause.get("sample"))
            lines.append(f"- {sample.get('owner') or '-'} · 반복 {integer(cause.get('repeat_count'))}회")
            lines.append(f"  최초 {cause.get('first_ts') or '-'} / 최근 {cause.get('last_ts') or '-'}")
            lines.append(f"  {sample.get('head') or sample.get('excerpt') or '-'}")
    check_rows = [row for row in (summary.get("logs") or []) if isinstance(row, dict) and row.get("state") == "CHECK"]
    if check_rows:
        lines += ["", "[시각 범위 확인 필요]"]
        for row in check_rows:
            lines.append(f"- {row.get('owner')} · {' / '.join(row.get('unscoped_sample') or [])[:500]}")
    lines += ["", "- 과거 오류는 삭제하지 않고 보존하되 현재 문제 수에는 포함하지 않음"]
    return "\n".join(lines)

def render_readiness(_args: Sequence[str] = ()) -> str:
    ops = _ops_snapshot()
    standard = _candidate_snapshot()
    paper = _paper_status()
    performance = _performance_snapshot()
    checks = [
        ("운영 흐름", ops.get("overall_state") == "NORMAL"),
        ("후보 기준판", standard.get("state") == "NORMAL"),
        ("Paper 실행 core", paper.get("paper_fast_core_v1181") is True),
        ("성과 snapshot", bool(performance.get("snapshot_id"))),
        ("자동매수 OFF", True),
    ]
    ready = all(value for _label, value in checks[:-1])
    lines = [f"🚦 준비도 · {'🟢 REVIEWABLE' if ready else '🟡 CHECK'}"]
    for label, value in checks:
        lines.append(f"- {'✅' if value else '⚠️'} {label}")
    lines.append("- 실매수는 사용자 승인 전 항상 OFF")
    return "\n".join(lines)


def render_commands(_args: Sequence[str] = ()) -> str:
    return "\n".join([
        "🧭 코인봇 메뉴 · canonical",
        "",
        "[평소 확인]",
        "/batch - 운영 핵심 + Telegram 요약 + TXT 1개",
        "/health - 공장·자원 상태",
        "/core /deploy /upgradestatus - 이전 상태명령 호환",
        "/swing_status - ALT_SWING 계약·runtime",
        "/version_score - 최근 3h·6h·24h·오늘·어제 성과",
        "/popen [티커] - 현재 OPEN",
        "/trade_review - 후보·거래 복기",
        "",
        "[지도·후보]",
        "/flow_map_full - 배관·시간·원장·오류·runtime·자원 전수지도 + TXT",
        "/candidate_standard - 후보·구조 기준판 + TXT",
        "/readiness_board - 실매매 준비도",
        "",
        "[정밀 확인]",
        "/batch_full - 정밀 명령 + TXT 1개",
        "/performance_lab - 성과 배관·계약 분류",
        "/profit_audit - 유입경로·CLOSED+OPEN",
        "/open_book_audit - 현재 OPEN 전수판",
        "/book_reset_status - 성과구간 참고판",
        "/early_audit - 현재 candidate 표본",
        "/ledger_audit - 중복·key 누락·미연결",
        "/issue_ledger /issue_history - 문제장부",
        "/change_verify /change_verify_full - 변경장부",
        "/errorlog - 오류",
        "",
        "[편의]",
        "- 여러 명령을 한 메시지에 줄바꿈해 보내면 각각 실행하고 TXT 1개로 묶음",
        "- Telegram은 핵심, TXT는 같은 snapshot의 상세",
        "- 자동매수 OFF",
    ])


Render = Callable[[Sequence[str]], str]
COMMANDS: Dict[str, Render] = {
    "flow_map": render_flow_map_compact,
    "flow_map_full": render_flow_map_full,
    "ops_map": render_flow_map_full,
    "candidate_standard": render_candidate_standard,
    "candidate_standard_full": render_candidate_standard,
    "candidate_reason": render_candidate_standard,
    "quality": render_candidate_standard,
    "structure_board": render_candidate_standard,
    "health": render_health,
    "core": render_health,
    "deploy": render_health,
    "upgradestatus": render_health,
    "swing_status": render_swing_status,
    "pstatus": render_pstatus,
    "paper_handoff": render_pstatus,
    "popen": render_popen,
    "version_score": render_version_score,
    "score": render_version_score,
    "performance_lab": render_performance_lab,
    "profit_audit": render_profit_audit,
    "open_book_audit": render_open_book_audit,
    "book_reset_status": render_book_reset_status,
    "trade_review": render_trade_review,
    "early_audit": render_early_audit,
    "issue_ledger": render_issue_ledger,
    "issue_history": lambda args=(): render_issue_ledger(args, full=True),
    "change_verify": render_change_verify,
    "change_verify_full": lambda args=(): render_change_verify(args, full=True),
    "ledger_audit": render_ledger_audit,
    "readiness_board": render_readiness,
    "errorlog": render_errorlog,
    "commands": render_commands,
    "help": render_commands,
}

BATCH_DEFAULT = [
    "flow_map_full", "candidate_standard", "health", "swing_status", "version_score",
    "performance_lab", "change_verify", "issue_ledger", "errorlog",
]
BATCH_FULL = BATCH_DEFAULT + ["pstatus", "open_book_audit", "profit_audit", "ledger_audit", "readiness_board"]
BATCH_ALIASES = {"batch", "summary", "pbatch"}
SINGLE_TXT = {"flow_map_full", "candidate_standard", "version_score"}
ALWAYS_COMPACT = {"flow_map_full", "candidate_standard", "version_score", "issue_ledger", "change_verify", "errorlog"}


def render_command(name: str, args: Sequence[str] = ()) -> str:
    key = str(name or "").strip().lstrip("/").lower()
    renderer = COMMANDS.get(key)
    if renderer is None:
        return f"알 수 없는 명령: /{key}\n/commands에서 확인"
    try:
        return renderer(args)
    except Exception as exc:
        log_error(f"render_{key}", exc)
        return f"❌ /{key} 표시 실패\n- {type(exc).__name__}: {exc}"


def compact_command_output(name: str, body: str) -> str:
    key = str(name).lower()
    if key in {"flow_map", "flow_map_full", "ops_map"}:
        return render_flow_map_compact()
    if key in {"candidate_standard", "candidate_standard_full", "candidate_reason", "quality", "structure_board"}:
        return render_candidate_compact()
    if key in {"version_score", "score"}:
        return render_version_score_compact()
    lines = str(body or "").splitlines()
    if key == "errorlog":
        if any("새 실행 중 오류 없음" in line for line in lines):
            return "🧯 오류 요약\n- ✅ 새 실행 중 오류 없음"
        return "🧯 오류 요약\n" + "\n".join([line for line in lines[1:] if line.strip()][:6])
    if key == "issue_ledger":
        return "\n".join(lines[:15] + (["- 상세는 TXT"] if len(lines) > 15 else []))
    if key == "change_verify":
        return "\n".join(lines[:10] + (["- 상세는 TXT"] if len(lines) > 10 else []))
    if key in {"health", "performance_lab", "pstatus", "swing_status"}:
        return "\n".join(lines[:20])
    return "\n".join(lines[:14])


def parse_command_lines(raw: str) -> List[Tuple[str, List[str]]]:
    out: List[Tuple[str, List[str]]] = []
    for line in str(raw or "").splitlines():
        stripped = line.strip()
        if not stripped.startswith("/"):
            continue
        parts = stripped.split()
        name = parts[0].lstrip("/").split("@", 1)[0].lower()
        if name:
            out.append((name, parts[1:]))
    return out


def _unique_commands(items: Iterable[Tuple[str, List[str]]]) -> List[Tuple[str, List[str]]]:
    seen = set()
    result: List[Tuple[str, List[str]]] = []
    for name, args in items:
        key = (name, tuple(args))
        if key in seen:
            continue
        seen.add(key)
        result.append((name, list(args)))
    return result


def build_summary_text(order: Sequence[Tuple[str, List[str]]], outputs: Mapping[str, str], timings: Sequence[Mapping[str, Any]], total_sec: float, full_mode: bool = False) -> str:
    ops = _ops_snapshot()
    title = f"코인봇 통합 상세집 {RELEASE_TAG}" if full_mode else f"코인봇 운영 요약집 {RELEASE_TAG}"
    names = [name for name, _args in order]
    lines = [
        title,
        "=" * 72,
        f"- 생성: {now_text()} KST",
        f"- 메인봇: {BOT_VERSION} / {BUILD_LABEL}",
        f"- 요청·포함: {', '.join('/'+name for name in names)}",
        f"- 화면 생성 합계: {sum(float(x.get('sec') or 0.0) for x in timings):.2f}s",
        f"- Telegram·TXT 포함 총시간: {total_sec:.2f}s",
        f"- 운영지도 snapshot: {ops.get('snapshot_id') or '-'}",
        "- 자동매수: OFF",
        "",
        "[한눈에 보기]",
        render_flow_map_compact(),
        "",
        render_candidate_compact(),
        "",
        render_version_score_compact(),
        "",
        "[명령 처리시간]",
    ]
    for item in timings:
        lines.append(f"- {'✅' if item.get('ok') else '❌'} /{item.get('name')}: {float(item.get('sec') or 0.0):.2f}s")
    lines += ["", "=" * 72, "[상세 결과]"]
    for name, _args in order:
        lines += ["", f"## /{name}", "-" * 72, outputs.get(name, "")]
    lines += [
        "",
        "=" * 72,
        "[판독 원칙]",
        "- Telegram은 현재 상태·원인·우선순위만 표시",
        "- TXT는 같은 canonical snapshot의 상세 근거를 표시",
        "- Main 독립 재계산·구 cache fallback 없음",
        "- 후보수치 변경 없음 · 진입·청산은 Paper canonical 계약 snapshot 기준",
        "- 자동매수 OFF",
    ]
    return "\n".join(lines)


def send_summary_file(update: Any, content: str) -> str:
    stamp = time.strftime("%Y%m%d_%H%M%S")
    path = BASE_DIR / f"coinbot_batch_summary_{stamp}.txt"
    sent = False
    try:
        path.write_text(content, encoding="utf-8")
        target = getattr(update, "effective_message", None) or getattr(update, "message", None)
        if target is None:
            raise RuntimeError("telegram message target missing")
        with path.open("rb") as handle:
            target.reply_document(document=handle, filename=path.name)
        sent = True
        return "TXT 전송완료 후 서버삭제"
    except Exception as exc:
        log_error("send_summary_file", exc)
        return f"TXT 전송실패 · 서버파일 유지 {path.name} · {type(exc).__name__}"
    finally:
        if sent:
            try:
                path.unlink(missing_ok=True)
            except OSError as exc:
                log_error("summary_delete", exc)


def collect_and_send(update: Any, requested: Sequence[Tuple[str, List[str]]], *, batch: bool = False, full_mode: bool = False) -> None:
    if not _chat_allowed(update) or not acquire_request(update):
        return
    if not _COMMAND_LOCK.acquire(blocking=False):
        send_text(update, "⏳ 메인봇 명령 묶음이 이미 실행 중\n- 잠시 뒤 다시 실행")
        return
    started = time.time()
    pin_meta = begin_canonical_pin()
    set_runtime_state(scan_running=True, scan_stage="command_collect")
    write_status("running", phase="command_collect")
    try:
        order = list(_unique_commands(requested))
        if batch:
            base_names = BATCH_FULL if full_mode else BATCH_DEFAULT
            existing = {name for name, _args in order}
            for name in base_names:
                if name not in existing:
                    order.append((name, []))
        # Remove aliases from execution list.
        order = [(name, args) for name, args in order if name not in BATCH_ALIASES and name != "batch_full"]
        send_text(update, f"📚 {'상세 batch' if full_mode else ('핵심 batch' if batch else '묶음 명령')} {len(order)}개 · {RELEASE_TAG} · TXT 1개")
        outputs: Dict[str, str] = {}
        timings: List[Dict[str, Any]] = []
        for idx, (name, args) in enumerate(order, 1):
            set_runtime_state(scan_running=True, scan_stage=f"{idx}/{len(order)} /{name}")
            write_status("running", phase="command_render")
            item_started = time.time()
            body = render_command(name, args)
            elapsed = time.time() - item_started
            ok = not body.startswith("❌")
            outputs[name] = body
            timings.append({"name": name, "sec": round(elapsed, 3), "ok": ok})
            # Explicit commands and the familiar batch cards are visible in Telegram.
            if not batch or name in {"flow_map_full", "candidate_standard", "health", "swing_status", "version_score", "issue_ledger", "errorlog"}:
                send_text(update, compact_command_output(name, body))
        set_runtime_state(scan_running=True, scan_stage="summary_txt")
        total = time.time() - started
        summary = build_summary_text(order, outputs, timings, total, full_mode=full_mode)
        status = send_summary_file(update, summary)
        payload = {
            "schema": "command_summary_status_v1185",
            "ok": status.startswith("TXT 전송완료"),
            "requested": [name for name, _args in requested],
            "included": [name for name, _args in order],
            "status": status,
            "txt_count": 1 if status.startswith("TXT 전송완료") else 0,
            "snapshot_id": _ops_snapshot().get("snapshot_id"),
            "pinned_snapshot_id_v1189": pin_meta.get("ops_snapshot_id"),
            "pin_missing_v1189": pin_meta.get("missing") or [],
            "render_sum_sec": round(sum(float(x.get("sec") or 0.0) for x in timings), 3),
            "delivery_total_sec": round(time.time() - started, 3),
            "updated_ts": now_ts(),
        }
        atomic_write_json(COMMAND_SUMMARY_STATUS, payload)
        send_text(update, f"✅ 완료 · 화면생성 {payload['render_sum_sec']:.2f}s / 전송포함 {payload['delivery_total_sec']:.2f}s / {status}")
    except Exception as exc:
        log_error("collect_and_send", exc)
        send_text(update, f"❌ 명령 묶음 실패\n- {type(exc).__name__}: {exc}")
    finally:
        end_canonical_pin()
        set_runtime_state(scan_running=False, scan_stage="idle")
        write_status("running", phase="idle")
        _COMMAND_LOCK.release()


def make_handler(name: str):
    def handler(update: Any, context: Any) -> None:
        if not _chat_allowed(update):
            return
        raw = str(getattr(getattr(update, "effective_message", None), "text", "") or "")
        parsed = parse_command_lines(raw)
        if len(parsed) >= 2:
            batch = any(cmd in BATCH_ALIASES or cmd == "batch_full" for cmd, _args in parsed)
            full = any(cmd == "batch_full" for cmd, _args in parsed)
            collect_and_send(update, parsed, batch=batch, full_mode=full)
            return
        args = list(getattr(context, "args", []) or [])
        command = str(name).lower()
        if command in BATCH_ALIASES:
            collect_and_send(update, [(command, args)], batch=True, full_mode=False)
            return
        if command == "batch_full":
            collect_and_send(update, [(command, args)], batch=True, full_mode=True)
            return
        if command in SINGLE_TXT:
            collect_and_send(update, [(command, args)], batch=False, full_mode=False)
            return
        if not acquire_request(update):
            return
        started = time.time()
        set_runtime_state(scan_running=True, scan_stage=f"/{command}")
        write_status("running", phase="command_render")
        try:
            body = render_command(command, args)
            send_text(update, compact_command_output(command, body) if command in ALWAYS_COMPACT else body)
        finally:
            set_runtime_state(scan_running=False, scan_stage="idle")
            write_status("running", phase="idle", last_command=command, last_command_sec=round(time.time() - started, 3))
    return handler


def text_router(update: Any, _context: Any) -> None:
    raw = str(getattr(getattr(update, "effective_message", None), "text", "") or "").strip()
    parsed = parse_command_lines(raw)
    if not parsed:
        return
    batch = any(cmd in BATCH_ALIASES or cmd == "batch_full" for cmd, _args in parsed)
    full = any(cmd == "batch_full" for cmd, _args in parsed)
    if len(parsed) >= 2 or batch:
        collect_and_send(update, parsed, batch=batch, full_mode=full)
        return
    name, args = parsed[0]
    handler = make_handler(name)
    class Context:
        pass
    ctx = Context()
    ctx.args = args
    handler(update, ctx)


def heartbeat_loop() -> None:
    while not _STOP:
        try:
            warm_canonical_cache()
            write_status("running", phase=_SCAN_STAGE if _SCAN_RUNNING else "idle")
        except Exception as exc:
            log_error("heartbeat", exc)
        slept = 0.0
        while slept < HEARTBEAT_SEC and not _STOP:
            step = min(0.2, HEARTBEAT_SEC - slept)
            time.sleep(step)
            slept += step


def signal_handler(_signum: int, _frame: Any) -> None:
    global _STOP
    _STOP = True
    set_runtime_state(telegram_state="stopping", telegram_note="signal received")
    try:
        write_status("stopped", phase="shutdown")
    except Exception:
        pass


def set_commands(updater: Any) -> None:
    if BotCommand is None:
        return
    commands = [
        BotCommand("batch", "운영 핵심 + TXT"),
        BotCommand("batch_full", "정밀 상세 + TXT"),
        BotCommand("health", "공장·자원 상태"),
        BotCommand("core", "공장·배포 상태"),
        BotCommand("deploy", "공장·배포 상태"),
        BotCommand("upgradestatus", "업그레이드 상태"),
        BotCommand("swing_status", "ALT_SWING 계약"),
        BotCommand("version_score", "CLOSED+OPEN 성과"),
        BotCommand("popen", "현재 OPEN"),
        BotCommand("trade_review", "거래·후보 복기"),
        BotCommand("flow_map_full", "전수 증거 운영지도"),
        BotCommand("candidate_standard", "후보·구조 기준판"),
        BotCommand("performance_lab", "성과 배관"),
        BotCommand("profit_audit", "수익성 감사"),
        BotCommand("open_book_audit", "OPEN 전수판"),
        BotCommand("ledger_audit", "원장 연결 감사"),
        BotCommand("change_verify", "수정검수 장부"),
        BotCommand("issue_ledger", "문제장부"),
        BotCommand("readiness_board", "실매매 준비도"),
        BotCommand("errorlog", "오류"),
        BotCommand("commands", "메뉴"),
    ]
    updater.bot.set_my_commands(commands)


# Register aliases after helper definitions.
COMMANDS["batch"] = lambda _args=(): "배치 handler 전용"
COMMANDS["batch_full"] = lambda _args=(): "상세 배치 handler 전용"
COMMANDS["summary"] = COMMANDS["batch"]
COMMANDS["pbatch"] = COMMANDS["batch"]


def main() -> int:
    signal.signal(signal.SIGTERM, signal_handler)
    signal.signal(signal.SIGINT, signal_handler)
    set_runtime_state(telegram_state="initializing", telegram_note="main boot")
    write_status("initializing", phase="boot")
    log_runtime(f"telegram_state=initializing version={BOT_VERSION} build={BUILD_LABEL}")
    threading.Thread(target=heartbeat_loop, name="main-heartbeat-v1186", daemon=True).start()
    if not TELEGRAM_TOKEN or Updater is None:
        set_runtime_state(telegram_state="disabled", telegram_note="headless_no_telegram")
        write_status("running", phase="headless_no_telegram", telegram=False)
        log_runtime(f"{BOT_VERSION} headless snapshot renderer active")
        while not _STOP:
            time.sleep(1.0)
        return 0
    try:
        updater = Updater(token=TELEGRAM_TOKEN, use_context=True)
        dispatcher = updater.dispatcher
        for name in sorted(COMMANDS):
            if re.fullmatch(r"[A-Za-z0-9_]+", name):
                dispatcher.add_handler(CommandHandler(name, make_handler(name)))
        # Non-command text containing slash-lines still uses the same multi-command router.
        if MessageHandler is not None and Filters is not None:
            dispatcher.add_handler(MessageHandler(Filters.text & (~Filters.command), text_router))
        set_commands(updater)
        set_runtime_state(telegram_state="commands_installed", telegram_note="telegram commands installed")
        write_status("running", phase="commands_installed", telegram=True)
        updater.start_polling(drop_pending_updates=True)
        set_runtime_state(telegram_state="polling_started", telegram_error="", telegram_note="command receive ready")
        write_status("running", phase="telegram_polling", telegram=True)
        log_runtime(f"{BOT_VERSION} telegram polling_started build={BUILD_LABEL}")
        try:
            if CHAT_ID:
                updater.bot.send_message(
                    chat_id=CHAT_ID,
                    text=(
                        f"✅ 메인봇 시작 완료\n- {BOT_VERSION}\n- {BUILD_LABEL}\n"
                        "- 기존 명령·요약집 편의 복원\n- canonical snapshot 전용\n- 자동매수 OFF"
                    ),
                )
        except Exception as exc:
            log_error("startup_notice", exc)
            set_runtime_state(telegram_state="polling_started_notify_failed", telegram_error=f"{type(exc).__name__}: {exc}", telegram_note="polling is active; startup notice failed")
            write_status("running", phase="telegram_polling", telegram=True)
        updater.idle()
    except Exception as exc:
        log_error("main", exc)
        set_runtime_state(telegram_state="error", telegram_error=f"{type(exc).__name__}: {exc}", telegram_note="main telegram loop failed")
        write_status("error", phase="telegram_error", telegram=False)
        return 1
    set_runtime_state(telegram_state="stopping", telegram_note="updater idle ended")
    write_status("stopped", phase="shutdown")
    return 0





# =============================================================================
# v1303 - v1211-style version score board + candidate-quality diagnosis panel
# Reads Paper-owned zero anchor from v1303/v1302 detail.  This is a display-only
# change: candidate formula, trigger, invalid, target, RR, entry and exit
# thresholds remain v1211/v1302 clean-rebase runtime values.
# =============================================================================


# ===== v1304: v1211-style pretty /version_score + candidate-quality cause board =====
def _v1304_detail() -> Dict[str, Any]:
    snap = _performance_snapshot()
    if not isinstance(snap, dict):
        return {}
    for key in ('version_score_detail_v1305','version_score_detail_v1304','version_score_detail_v1303','version_score_detail_v1302'):
        d = mapping(snap.get(key))
        if d:
            return d
    return {}


def _v1304_active_epoch(detail: Optional[Dict[str, Any]] = None) -> Dict[str, Any]:
    d = detail if isinstance(detail, dict) else _v1304_detail()
    for key in ('active_epoch_v1305','active_epoch_v1304','active_epoch_v1303','active_epoch_v1302'):
        v = mapping(d.get(key))
        if v:
            return v
    return {}


def _v1304_anchor(detail: Optional[Dict[str, Any]] = None) -> Dict[str, Any]:
    d = detail if isinstance(detail, dict) else _v1304_detail()
    for key in ('score_epoch_anchor_v1305','score_epoch_anchor_v1304','score_epoch_anchor_v1303','score_epoch_anchor_v1302'):
        v = mapping(d.get(key))
        if v:
            return v
    return {}


def _v1304_windows(detail: Dict[str, Any]) -> Dict[str, Any]:
    return mapping(_v1304_active_epoch(detail).get('windows'))


# v1305 display guard: Paper v1302/v1303 anchors did not always publish a
# KST today window.  Display only; no performance recomputation beyond the
# active epoch stats already owned by Paper.
def _v1305_same_kst_day(ts: Any, ref: Optional[float] = None) -> bool:
    parsed = num(ts, default=None)
    if parsed is None or parsed <= 0:
        return False
    return time.strftime('%Y-%m-%d', time.localtime(parsed)) == time.strftime('%Y-%m-%d', time.localtime(ref or time.time()))


def _v1305_display_windows(detail: Dict[str, Any]) -> Dict[str, Any]:
    windows = dict(_v1304_windows(detail))
    today = mapping(windows.get('today'))
    if _stat_count(today) <= 0:
        epoch = _v1304_active_epoch(detail)
        anchor = _v1304_anchor(detail)
        started = anchor.get('started_at') or epoch.get('started_at')
        all_stat = mapping(windows.get('all'), epoch.get('closed'))
        # If the active score anchor itself started today, all active-epoch rows
        # are necessarily today's rows.  This fixes the 3h>0 but today=0 display
        # bug without borrowing old CLOSED rows.
        if _v1305_same_kst_day(started) and _stat_count(all_stat) > 0:
            fixed = dict(all_stat)
            fixed['source'] = 'v1305_kst_today_from_active_epoch_all'
            windows['today'] = fixed
    return windows


def _v1304_stat_icon(stat_obj: Any) -> str:
    stat = mapping(stat_obj)
    n = _stat_count(stat)
    total = _stat_total(stat)
    if n <= 0:
        return '⚪'
    if total is None:
        return '⚪'
    if total > 0:
        return '✅'
    if total < 0:
        return '❌'
    return '➖'


def _v1304_period_lines(label: str, stat_obj: Any) -> List[str]:
    stat = mapping(stat_obj)
    n = _stat_count(stat)
    wins = _stat_wins(stat)
    losses = _stat_losses(stat)
    wr = _stat_win_rate(stat)
    total = _stat_total(stat)
    avg = _stat_avg(stat)
    if n <= 0:
        return [
            f"⚪ {label} · 0전 0승 0패 · 승률 -",
            "   합산 0.00% · 평균 0.00%",
        ]
    return [
        f"{_v1304_stat_icon(stat)} {label} · {n}전 {wins}승 {losses}패 · 승률 {fmt_num(wr, 1)}%",
        f"   합산 {fmt_pct(total, 2)} · 평균 {fmt_pct(avg, 2)}",
    ]


def _v1304_window_block(detail: Dict[str, Any]) -> List[str]:
    windows = _v1305_display_windows(detail)
    rows: List[str] = []
    for key, label in (
        ('recent_3h','최근 3시간'),
        ('recent_6h','최근 6시간'),
        ('recent_12h','최근 12시간'),
        ('recent_24h','최근 24시간'),
        ('today','오늘'),
        ('all','전체'),
    ):
        stat = mapping(windows.get(key))
        # No fallback. If today is not provided, keep it as 0/collecting instead of borrowing all.
        rows.extend(_v1304_period_lines(label, stat))
    return rows


def _v1304_find_no_limit(detail: Dict[str, Any], snap: Dict[str, Any]) -> Dict[str, Any]:
    candidates = [
        detail.get('no_limit_shadow_v1304'), detail.get('no_limit_shadow_v1303'), detail.get('unlimited_shadow_v1304'), detail.get('unlimited_shadow_v1303'),
        detail.get('all_executable_shadow_v1304'), detail.get('all_executable_shadow_v1303'),
        snap.get('no_limit_shadow_v1304'), snap.get('no_limit_shadow_v1303'), snap.get('unlimited_shadow_v1304'), snap.get('unlimited_shadow_v1303'),
        snap.get('version_score_no_limit'), snap.get('no_limit_performance'), snap.get('virtual_no_limit_performance'),
    ]
    for obj in candidates:
        m = mapping(obj)
        if m:
            return m
    return {}


def _v1304_no_limit_lines(no_limit: Dict[str, Any]) -> List[str]:
    lines = [
        '━━━━━━━━━━━━━━━━━━━━',
        'B. 갯수제한 없는 경우 · 비교/가상판',
        '━━━━━━━━━━━━━━━━━━━━',
    ]
    if not no_limit:
        lines += [
            '⚪ 무제한 가상 원장 · 수집 중',
            '   실제로 OPEN하지 않은 후보 수익률을 기존 CLOSED로 꾸미지 않음',
            '   no-limit shadow 원장이 생기면 여기서 3h·6h·12h·24h·전체를 표시',
        ]
        return lines
    windows = mapping(no_limit.get('windows'))
    for key, label in (('recent_3h','최근 3시간'),('recent_6h','최근 6시간'),('recent_12h','최근 12시간'),('recent_24h','최근 24시간'),('all','전체')):
        lines.extend(_v1304_period_lines(label, mapping(windows.get(key), no_limit.get(key))))
    lines.append('   실제 제한판과 섞지 않음 · 별도 shadow 원장만 사용')
    return lines


def _v1304_reason_counts_from_rows(limit: int = 2500) -> Dict[str, int]:
    counts: Dict[str, int] = {}
    path = PATHS.strategy_candidates
    try:
        if not path.exists() or not path.is_file():
            return counts
        raw_lines = path.read_text(encoding='utf-8', errors='ignore').splitlines()
    except Exception:
        return counts
    for line in raw_lines[-limit:]:
        line = line.strip()
        if not line:
            continue
        try:
            row = json.loads(line)
        except Exception:
            continue
        if not isinstance(row, dict):
            continue
        values: List[Any] = []
        for key in ('hard_reason','final_reason','block_reason','drop_reason','s1_reason','s1_block_reason','not_s1_reason','decision_reason','reason'):
            value = row.get(key)
            if value:
                values.append(value)
        for key in ('hard_reasons','reasons','drop_reasons','blocked_reasons','s1_block_reasons','why_not_s1','fail_reasons'):
            value = row.get(key)
            if isinstance(value, list):
                values.extend(value)
            elif isinstance(value, dict):
                for k,v in value.items():
                    if v:
                        values.append(k)
        for value in values:
            name = str(value).strip()
            if not name or name.lower() in {'none','null','ok','pass','s1'}:
                continue
            counts[name] = counts.get(name, 0) + 1
    return counts


def _v1304_reason_counts(obj: Dict[str, Any]) -> Dict[str, Any]:
    def normalize_reason_source(value: Any) -> Dict[str, int]:
        out: Dict[str, int] = {}
        if isinstance(value, dict):
            for k, v in value.items():
                if isinstance(v, dict):
                    cnt = integer(v.get('count'), v.get('n'), default=0)
                else:
                    cnt = integer(v, default=0)
                if cnt > 0:
                    out[str(k)] = out.get(str(k), 0) + cnt
        elif isinstance(value, list):
            for item in value:
                if isinstance(item, dict):
                    name = item.get('reason') or item.get('name') or item.get('key')
                    cnt = integer(item.get('count'), item.get('n'), default=0)
                    if name and cnt > 0:
                        out[str(name)] = out.get(str(name), 0) + cnt
                elif item:
                    out[str(item)] = out.get(str(item), 0) + 1
        return out

    buckets = [obj, mapping(obj.get('candidate')), mapping(obj.get('quality')), mapping(obj.get('structure')), mapping(obj.get('gate')), mapping(obj.get('reasons'))]
    # Strategy status owns the real swing-gate hard reason TOP in v1211/v1302.
    st = current_json(PATHS.strategy_status, {}) or {}
    if isinstance(st, dict):
        buckets.append(st)
        for k in ('swing_gate_hard_reason_top_v979','hard_reason_top','hard_reason_top_v1302','swing_gate_reason_top','reason_counts'):
            got = normalize_reason_source(st.get(k))
            if got:
                return got
    keys = ('hard_reason_counts','blocked_reason_counts','final_reason_counts','reason_counts','reason_summary','hard_reasons','drop_reasons','swing_gate_hard_reason_top_v979','hard_reason_top')
    for b in buckets:
        for k in keys:
            v = b.get(k) if isinstance(b, dict) else None
            got = normalize_reason_source(v)
            if got:
                return got
    rows = _v1304_reason_counts_from_rows()
    return rows


def _v1304_top_reason_lines(reasons: Dict[str, Any], limit: int = 8) -> List[str]:
    if not reasons:
        return ['⚪ 주요 탈락 이유 · 수집 중', '   후보 기준 변경 없음 · 다음 cycle snapshot에서 재확인']
    rows=[]
    for k,v in reasons.items():
        cnt = integer(v, mapping(v).get('count'), mapping(v).get('n'), default=0)
        if cnt > 0:
            rows.append((str(k), cnt))
    rows.sort(key=lambda x: x[1], reverse=True)
    out = []
    for name,cnt in rows[:limit]:
        out.append(f"- {name}: {cnt}개")
    return out or ['⚪ 주요 탈락 이유 · 수집 중']


def _v1321_pre1211_audit_lines() -> List[str]:
    st = current_json(PATHS.strategy_status, {}) or {}
    audit = mapping(st.get('pre1211_s1_recovery_audit_v1321')) if isinstance(st, dict) else {}
    if not audit:
        return []
    current_s1 = integer(audit.get('current_s1'), default=0)
    would_s1 = integer(audit.get('would_s1_without_trigger_wait'), default=0)
    wait_only = integer(audit.get('trigger_wait_only'), default=0)
    lines = [
        '',
        '🧭 v1322 trigger 감시형 S1 복구판',
        f"- 현재 S1 {current_s1}개 / trigger 대기만 빼면 S1 후보 {would_s1}개",
        f"- 그중 trigger만 기다리는 후보 {wait_only}개",
        '- 실제 OPEN은 Paper가 trigger 도달을 다시 확인할 때만 발생',
    ]
    top = audit.get('remaining_block_reasons_without_trigger_wait_top')
    if isinstance(top, list) and top:
        lines.append('- trigger 대기 제외 후에도 남는 차단 TOP')
        for item in top[:6]:
            if isinstance(item, dict):
                lines.append(f"  · {item.get('reason') or '-'}: {integer(item.get('count'))}개")
    samples = audit.get('samples')
    if isinstance(samples, list) and samples:
        lines.append('- 표본')
        for r in [x for x in samples if isinstance(x, dict)][:5]:
            lines.append(f"  · {r.get('ticker') or '-'} · RR {r.get('rr') or '-'} / 목표 {r.get('room') or '-'}% / 이유 {', '.join(str(x) for x in (r.get('current_reasons') or [])[:3]) or '없음'}")
    return lines

def _v1304_candidate_quality_lines(obj: Dict[str, Any]) -> List[str]:
    cand = mapping(obj.get('candidate'))
    struct = mapping(obj.get('structure'))
    qual = mapping(obj.get('quality'))
    miss = mapping(qual.get('metric_missing_counts'))
    reasons = _v1304_reason_counts(obj)
    s1 = integer(cand.get('s1'), default=0)
    total = integer(cand.get('total'), default=0)
    lines = [
        '━━━━━━━━━━━━━━━━━━━━',
        'C. 후보품질 진단 · 나중에 품질 손댈 때 보는 판',
        '━━━━━━━━━━━━━━━━━━━━',
        f"- 후보: 전체 {total} → S1 {s1} / S2 {integer(cand.get('s2'))} / S3 {integer(cand.get('s3'))}",
        f"- 구조근거: 평가 {integer(struct.get('evaluated'))} / 완전 {integer(struct.get('complete'))} / source missing {integer(struct.get('source_missing'))}",
        f"- trigger/invalid/target source 누락: {integer(struct.get('trigger_source_missing'))}/{integer(struct.get('invalid_source_missing'))}/{integer(struct.get('target_source_missing'))}",
        '',
        '✅ 좋은 점',
    ]
    if s1 > 0:
        lines += [
            f"- S1 {s1}개 · 실제 후보 품질 비교 가능",
            f"- RR 중앙: {_candidate_metric_text(mapping(qual.get('rr')), 3)} · 목표공간: {_candidate_metric_text(mapping(qual.get('target_room')), 3, '%')}",
            f"- 추격률: {_candidate_metric_text(mapping(qual.get('chase')), 3, '%')} · spread: {_candidate_metric_text(mapping(qual.get('spread')), 3, '%')} · slippage: {_candidate_metric_text(mapping(qual.get('slippage')), 3, '%')}",
        ]
    else:
        lines += [
            '- S1 0개 · 기준 완화보다 S1 미발생 원인 확인이 먼저',
            '- 표본 만들려고 BUY_READY/기준완화 금지',
        ]
    bad: List[str] = []
    if integer(struct.get('source_missing')) > 0:
        bad.append(f"source_missing {integer(struct.get('source_missing'))}개")
    if s1 <= 0 and total > 0:
        bad.append('S1 0개')
    for key,label in (('rr','RR'),('target_room','목표공간'),('spread','spread'),('slippage','slippage'),('relative_strength','상대강도'),('money_flow','돈흐름'),('turnover_24h_krw','24h 거래대금')):
        if integer(miss.get(key)) > 0:
            bad.append(f"{label} 누락 {integer(miss.get(key))}개")
    lines += ['', '❌ 안 좋은 점 / 먼저 확인할 것']
    if bad:
        for x in bad[:10]:
            lines.append(f"- {x}")
    else:
        lines.append('- 현재 표시판 기준 핵심 누락 없음 · 실제 CLOSED/MFE로 검증 필요')
    lines += ['', '🔎 왜 탈락했는지 · 원인 TOP']
    lines += _v1304_top_reason_lines(reasons)
    lines += _v1321_pre1211_audit_lines()
    lines += [
        '',
        '🔒 후보품질 수정 전 잠금',
        '- 이 판은 읽기 전용 · 후보식/trigger/invalid/target/RR 자동 변경 없음',
        '- 품질값은 다음 수정 후보를 찾기 위한 원인표시만 함',
    ]
    return lines


def render_version_score(_args: Sequence[str] = ()) -> str:  # type: ignore[override]
    snap = _performance_snapshot()
    if not snap:
        return '📊 성과 /version_score · v1305 v1211식 성과판\n❌ canonical snapshot 준비 안 됨\n- 과거 성과 fallback 없음 · 자동매수 OFF'
    detail = _v1304_detail()
    epoch = _v1304_active_epoch(detail)
    anchor = _v1304_anchor(detail)
    reset = mapping(detail.get('reset_exclusions_v1304'), detail.get('reset_exclusions_v1303'), detail.get('reset_exclusions_v1302'))
    candidate = _candidate_snapshot()
    ccount = mapping(candidate.get('candidate'))
    ops = _ops_snapshot(); funnel = mapping(ops.get('paper_funnel'))
    counts = mapping(snap.get('counts'))
    age = file_age(PATHS.performance)
    trust = 'NORMAL' if age is not None and age <= 900 and (epoch or anchor) else 'CHECK'
    contract = _active_contract_snapshot()
    entry = mapping(contract.get('entry'))
    closed = mapping(epoch.get('closed'))
    no_limit = _v1304_find_no_limit(detail, snap)
    total_cap = integer(entry.get('total_cap'), default=10)
    cycle_cap = integer(entry.get('cycle_new_open_cap'), default=2)
    lines = [
        '📊 성과 /version_score · v1305 v1211식 성과판',
        f"- 신뢰: {icon(trust)} {trust} / snapshot {snap.get('snapshot_id') or '-'} / age {fmt_sec(age)}",
        f"- 기준: v1211 후보·진입 본선 / KST 오늘 보정 v1305 / score anchor {anchor.get('epoch_id') or epoch.get('epoch_id') or 'CHECK_SOURCE'}",
        '- 원칙: 과거 CLOSED/reset/구 epoch fallback 금지 · 원장 삭제 없음 · 자동매수 OFF',
        _contract_compact_line(contract),
        '',
        '━━━━━━━━━━━━━━━━━━━━',
        f'A. 실제 Paper 제한판 · OPEN {total_cap}개 / cycle당 {cycle_cap}개',
        '━━━━━━━━━━━━━━━━━━━━',
        f"- 선발: S1 후보 점수순 → 높은 순위부터 진입 / 총 {total_cap}개 · cycle당 {cycle_cap}개",
    ]
    lines.extend(_v1304_period_lines('전체 CLOSED', closed))
    lines += ['']
    lines.extend(_v1304_window_block(detail))
    lines += [
        '',
        f"- 새 epoch OPEN {integer(epoch.get('current_open_count'))}개 / 적용 전 OPEN {integer(epoch.get('pre_anchor_open_count'))}개",
        f"- reset 제외 row {integer(reset.get('reset_transition_closed'))}개 / old CLOSED 제외 {integer(reset.get('pre_anchor_closed'))}개 · 원장 보존",
        '',
    ]
    lines += _v1304_no_limit_lines(no_limit)
    lines += [
        '',
        '━━━━━━━━━━━━━━━━━━━━',
        'Paper 통과 · 이번 cycle',
        '━━━━━━━━━━━━━━━━━━━━',
        f"- 후보 전체 {integer(ccount.get('total'))} → S1 {integer(ccount.get('s1'))} / S2 {integer(ccount.get('s2'))} / S3 {integer(ccount.get('s3'))}",
        f"- Paper S1 판독 {integer(funnel.get('s1_seen'))} → 선택 {integer(funnel.get('selected'))} → OPEN {integer(funnel.get('opened'))}",
        '- 후보식·trigger·invalid·target·RR은 v1211 기준 유지',
        '',
    ]
    lines += _v1304_candidate_quality_lines(candidate)
    lines += [
        '',
        '━━━━━━━━━━━━━━━━━━━━',
        'D. 초기화 명령',
        '━━━━━━━━━━━━━━━━━━━━',
        '- Paper봇 /pzero_reset_v1305 : Paper OPEN 정리 + /version_score 0전 anchor 재시작',
        '- reset CLOSED는 원장 보존 · 새 성과판에서 제외',
        '',
        '[보존 원장 참고]',
        f"- raw {integer(counts.get('raw_ledger_rows'))} / exact {integer(counts.get('exact_unique_closed'), counts.get('included'))} / 중복 {integer(counts.get('duplicate_closed_rows'), counts.get('duplicates'))}",
        '- 위 숫자는 보존 확인용 · 새 전략 성과 숫자가 아님',
    ]
    return '\n'.join(lines)


def render_version_score_compact(_args: Sequence[str] = ()) -> str:  # type: ignore[override]
    snap = _performance_snapshot()
    if not snap:
        return '📊 성과 요약 · v1305 v1211식 성과판\n- CHECK_SOURCE · canonical performance snapshot 없음\n- 과거 성과 fallback 없음'
    detail = _v1304_detail(); epoch = _v1304_active_epoch(detail); closed = mapping(epoch.get('closed'))
    candidate = _candidate_snapshot(); ccount = mapping(candidate.get('candidate'))
    anchor = _v1304_anchor(detail)
    contract = _active_contract_snapshot(); entry = mapping(contract.get('entry'))
    no_limit = _v1304_find_no_limit(detail, snap)
    lines = [
        '📊 성과 요약 · v1305 v1211식 성과판',
        f"- anchor: {anchor.get('epoch_id') or epoch.get('epoch_id') or 'CHECK_SOURCE'} / state {epoch.get('state') or '-'}",
        '',
        f"A. 실제 제한판 · OPEN {entry.get('total_cap',10)} / cycle {entry.get('cycle_new_open_cap',2)}",
    ]
    lines.extend(_v1304_period_lines('전체 CLOSED', closed))
    lines.extend(_v1304_window_block(detail))
    lines += ['', 'B. 갯수제한 없는 경우']
    if not no_limit:
        lines += ['⚪ 무제한 가상 원장 · 수집 중', '   기존 CLOSED로 대체 안 함']
    else:
        lines.extend(_v1304_period_lines('무제한 전체', mapping(mapping(no_limit.get('windows')).get('all'), no_limit.get('all'))))
    lines += [
        '',
        'C. 후보품질',
        f"- 후보 전체 {integer(ccount.get('total'))} → S1 {integer(ccount.get('s1'))} / S2 {integer(ccount.get('s2'))} / S3 {integer(ccount.get('s3'))}",
        '- 후보품질 원인판은 TXT 상세에 표시 · 자동매수 OFF',
        '- 초기화: Paper봇 /pzero_reset_v1305',
    ]
    return '\n'.join(lines)

try:
    COMMANDS['version_score'] = render_version_score
    COMMANDS['score'] = render_version_score
except Exception:
    pass



# =============================================================================
# v1307 - readable score board with no-limit shadow and win/loss diagnosis
# Display only.  Main reads Paper-owned canonical snapshot and shadow ledger.
# BOT_VERSION/BUILD_LABEL owner is the file header only; no lower redefinition.
# =============================================================================


def _v1306_detail() -> Dict[str, Any]:
    snap = _performance_snapshot()
    if not isinstance(snap, dict): return {}
    for key in ('version_score_detail_v1306','version_score_detail_v1305','version_score_detail_v1304','version_score_detail_v1303','version_score_detail_v1302'):
        d = mapping(snap.get(key))
        if d: return d
    return {}


def _v1306_active_epoch(detail: Optional[Dict[str, Any]] = None) -> Dict[str, Any]:
    d = detail if isinstance(detail, dict) else _v1306_detail()
    for key in ('active_epoch_v1306','active_epoch_v1305','active_epoch_v1304','active_epoch_v1303','active_epoch_v1302'):
        v = mapping(d.get(key))
        if v: return v
    return {}


def _v1306_anchor(detail: Optional[Dict[str, Any]] = None) -> Dict[str, Any]:
    d = detail if isinstance(detail, dict) else _v1306_detail()
    for key in ('score_epoch_anchor_v1306','score_epoch_anchor_v1305','score_epoch_anchor_v1304','score_epoch_anchor_v1303','score_epoch_anchor_v1302'):
        v = mapping(d.get(key))
        if v: return v
    return {}


def _v1306_no_limit(detail: Dict[str, Any], snap: Dict[str, Any]) -> Dict[str, Any]:
    for obj in (detail.get('no_limit_shadow_v1306'), snap.get('no_limit_shadow_v1306'), detail.get('no_limit_shadow_v1304'), snap.get('version_score_no_limit'), snap.get('no_limit_performance')):
        m = mapping(obj)
        if m: return m
    return {}


def _v1306_row_ts(row: Dict[str, Any], *keys: str) -> float:
    for key in keys:
        v = num(row.get(key), default=None)
        if v is not None and v > 0: return float(v)
    return 0.0


def _v1306_row_pnl(row: Dict[str, Any]) -> Optional[float]:
    return num(row.get('net_pnl_pct'), row.get('net_pct'), row.get('pnl_pct'), row.get('profit_pct'), row.get('return_pct'), default=None)


def _v1306_is_reset(row: Dict[str, Any]) -> bool:
    reason = str(row.get('exit_reason') or row.get('reason') or row.get('exit_rule') or '')
    return bool(row.get('operator_reset_v1204') is True or row.get('operator_book_reset_v1045') is True or row.get('excluded_from_strategy_windows_v1045') is True or row.get('performance_epoch_role') == 'reset_transition_close' or reason in {'operator_reset_v1204','operator_reset_v1205','strategy_epoch_reset_v1294'})


def _v1306_epoch_rows(snapshot: Dict[str, Any], detail: Dict[str, Any]) -> List[Dict[str, Any]]:
    anchor = _v1306_anchor(detail); ats = num(anchor.get('started_at'), default=0.0) or 0.0
    rows = [r for r in (snapshot.get('rows') or []) if isinstance(r, dict)]
    out=[]
    for r in rows:
        if _v1306_is_reset(r): continue
        ots = _v1306_row_ts(r, 'opened_at','entry_ts','open_ts','created_at')
        cts = _v1306_row_ts(r, 'closed_at','closed_ts','exit_ts')
        if ats and (ots < ats or cts < ats): continue
        out.append(r)
    return out


def _v1306_metric(rows: List[Dict[str, Any]]) -> Dict[str, Any]:
    vals=[]
    for r in rows:
        p=_v1306_row_pnl(r)
        if p is not None: vals.append(float(p))
    n=len(vals); wins=sum(1 for x in vals if x>0); losses=sum(1 for x in vals if x<0); total=sum(vals)
    return {'count':n,'n':n,'wins':wins,'losses':losses,'win_rate':round(wins/n*100.0,4) if n else None,'sum_pct':round(total,6),'avg_pct':round(total/n,6) if n else 0.0}


def _v1306_reason_label(row: Dict[str, Any]) -> str:
    raw = str(row.get('exit_reason') or row.get('reason') or row.get('exit_rule') or row.get('closed_reason') or 'unknown')
    labels = {
        'structure_invalid':'구조 invalid 이탈', 'invalid':'invalid 이탈', 'stop_loss':'손절',
        'time_exit':'시간청산', 'no_progress':'무진행', 'weak_hold':'약한 보유',
        'target':'target 익절', 'structure_target':'구조 target 익절',
        'virtual_invalid_touch':'가상 invalid', 'virtual_target_touch':'가상 target',
    }
    return labels.get(raw, raw or 'unknown')


def _v1306_analysis_lines(rows: List[Dict[str, Any]]) -> List[str]:
    lines=['━━━━━━━━━━━━━━━━━━━━','D. 승패 분석 · 왜 이겼고 왜 졌는지','━━━━━━━━━━━━━━━━━━━━']
    if not rows:
        return lines+['⚪ CLOSED 표본 0개 · 분석 대기','- 새 epoch CLOSED가 쌓이면 원인별로 자동 표시']
    wins=[r for r in rows if (_v1306_row_pnl(r) or 0)>0]; losses=[r for r in rows if (_v1306_row_pnl(r) or 0)<0]
    lines += [f"- 표본: {len(rows)}전 · 승 {len(wins)} / 패 {len(losses)}", f"- 승패 균형: {'❌ 손실 우세' if len(losses)>len(wins) else '✅ 승리 우세' if len(wins)>len(losses) else '➖ 동일'}"]
    # reason buckets
    buckets: Dict[str, List[Dict[str, Any]]] = {}
    for r in rows:
        buckets.setdefault(_v1306_reason_label(r), []).append(r)
    lines += ['', '🔎 청산 원인별']
    for name, items in sorted(buckets.items(), key=lambda kv: (len(kv[1]), abs(sum((_v1306_row_pnl(x) or 0) for x in kv[1]))), reverse=True)[:8]:
        st=_v1306_metric(items)
        lines.append(f"- {name}: {st['count']}전 {st['wins']}승 {st['losses']}패 · 합산 {fmt_pct(st['sum_pct'],2)} · 평균 {fmt_pct(st['avg_pct'],2)}")
    no_mfe=0; profit_to_loss=0; givebacks=[]
    for r in rows:
        mfe=num(r.get('mfe_pct'), r.get('max_profit_pct'), r.get('peak_pct'), default=None)
        pnl=_v1306_row_pnl(r) or 0.0
        give=num(r.get('giveback_pct'), r.get('missed_profit_pct'), default=None)
        if mfe is not None and mfe <= 0 and pnl < 0: no_mfe += 1
        if mfe is not None and mfe > 0 and pnl < 0: profit_to_loss += 1
        if give is not None: givebacks.append(float(give))
    lines += ['', '⚠️ 손실 품질 신호']
    lines.append(f"- 양수 MFE 없이 손실: {no_mfe}건")
    lines.append(f"- 수익구간 후 손실전환: {profit_to_loss}건")
    if givebacks:
        lines.append(f"- 수익반납 평균: {sum(givebacks)/len(givebacks):.2f}%p / 최대 {max(givebacks):.2f}%p")
    lines += ['', '최근 CLOSED']
    for r in rows[-5:]:
        lines.append(f"- {r.get('ticker') or r.get('market') or '-'} · {fmt_pct(_v1306_row_pnl(r),2)} · {_v1306_reason_label(r)} · MFE {fmt_pct(r.get('mfe_pct'),2)} / MAE {fmt_pct(r.get('mae_pct'),2)}")
    lines.append('- 이 분석은 표시 전용 · 후보식/청산조건 자동 변경 없음')
    return lines


def _v1306_no_limit_lines(no_limit: Dict[str, Any]) -> List[str]:
    lines=['━━━━━━━━━━━━━━━━━━━━','B. 갯수제한 없는 경우 · no-limit shadow','━━━━━━━━━━━━━━━━━━━━']
    if not no_limit:
        return lines+['⚪ shadow 원장 없음 · Paper v1306 적용 후 다음 S1부터 수집','- 기존 CLOSED로 대체하지 않음']
    windows=mapping(no_limit.get('windows')); current=mapping(no_limit.get('current'))
    active=integer(no_limit.get('active_count'), current.get('count'), default=0); closed=integer(no_limit.get('closed_count'), mapping(windows.get('all')).get('count'), default=0)
    lines += [f"- 상태: 가상 OPEN {active}개 / 가상 CLOSED {closed}개", '- 범위: exact S1 통과 후 OPEN 10/cycle 2 제한만 제거한 비교판']
    if active:
        lines.append(f"- 현재 가상손익: {integer(current.get('count'))}개 · 합산 {fmt_pct(current.get('sum_pct'),2)} · 평균 {fmt_pct(current.get('avg_pct'),2)}")
    for key,label in (('recent_3h','최근 3시간'),('recent_6h','최근 6시간'),('recent_12h','최근 12시간'),('recent_24h','최근 24시간'),('today','오늘'),('all','전체')):
        lines.extend(_v1304_period_lines(label, mapping(windows.get(key))))
    rows=[r for r in (no_limit.get('active_sample') or []) if isinstance(r,dict)]
    if rows:
        lines += ['', '가상 OPEN 표본']
        for r in rows[:5]:
            lines.append(f"- {r.get('ticker') or '-'} · 현재 {fmt_pct(r.get('current_pct'),2)} · 목표 {r.get('target_price') or '-'} / invalid {r.get('invalid_price') or '-'}")
    lines.append('- 실제 Paper 성과와 섞지 않음 · 자동매수 OFF')
    return lines


def render_version_score(_args: Sequence[str] = ()) -> str:  # type: ignore[override]
    snap=_performance_snapshot()
    if not snap: return '📊 성과 /version_score · v1306\n❌ canonical snapshot 준비 안 됨\n- 과거 성과 fallback 없음 · 자동매수 OFF'
    detail=_v1306_detail(); epoch=_v1306_active_epoch(detail); anchor=_v1306_anchor(detail); candidate=_candidate_snapshot(); ccount=mapping(candidate.get('candidate'))
    ops=_ops_snapshot(); funnel=mapping(ops.get('paper_funnel')); contract=_active_contract_snapshot(); entry=mapping(contract.get('entry'))
    age=file_age(PATHS.performance); trust='NORMAL' if age is not None and age<=900 and (epoch or anchor) else 'CHECK'
    rows=_v1306_epoch_rows(snap, detail); closed=mapping(epoch.get('closed')) or _v1306_metric(rows)
    reset=mapping(detail.get('reset_exclusions_v1305'), detail.get('reset_exclusions_v1304'), detail.get('reset_exclusions_v1302'))
    no_limit=_v1306_no_limit(detail, snap)
    lines=['📊 성과 /version_score · v1307 v1211식 성과판 + 분석판', f"- 신뢰: {icon(trust)} {trust} / snapshot {snap.get('snapshot_id') or '-'} / age {fmt_sec(age)}", f"- 기준: v1211 후보·진입 본선 / score anchor {anchor.get('epoch_id') or epoch.get('epoch_id') or 'CHECK_SOURCE'}", '- 원칙: 과거 CLOSED/reset/구 epoch fallback 금지 · 원장 삭제 없음 · 자동매수 OFF', _contract_compact_line(contract), '', '━━━━━━━━━━━━━━━━━━━━', f"A. 실제 Paper 제한판 · OPEN {entry.get('total_cap',10)}개 / cycle당 {entry.get('cycle_new_open_cap',2)}개", '━━━━━━━━━━━━━━━━━━━━', f"- 선발: S1 후보 점수순 → 높은 순위부터 진입 / 총 {entry.get('total_cap',10)}개 · cycle당 {entry.get('cycle_new_open_cap',2)}개"]
    lines.extend(_v1304_period_lines('전체 CLOSED', closed)); lines += ['']; lines.extend(_v1304_window_block(detail)); lines += ['', f"- 새 epoch OPEN {integer(epoch.get('current_open_count'))}개 / 적용 전 OPEN {integer(epoch.get('pre_anchor_open_count'))}개", f"- reset 제외 row {integer(reset.get('reset_transition_closed'))}개 / old CLOSED 제외 {integer(reset.get('pre_anchor_closed'))}개 · 원장 보존", '']
    lines += _v1306_no_limit_lines(no_limit)
    lines += ['', '━━━━━━━━━━━━━━━━━━━━', 'C. Paper 통과 · 이번 cycle', '━━━━━━━━━━━━━━━━━━━━', f"- 후보 전체 {integer(ccount.get('total'))} → S1 {integer(ccount.get('s1'))} / S2 {integer(ccount.get('s2'))} / S3 {integer(ccount.get('s3'))}", f"- Paper S1 판독 {integer(funnel.get('s1_seen'))} → 선택 {integer(funnel.get('selected'))} → OPEN {integer(funnel.get('opened'))}", '- 후보식·trigger·invalid·target·RR은 v1211 기준 유지', '']
    lines += _v1304_candidate_quality_lines(candidate)
    lines += ['', *(_v1306_analysis_lines(rows)), '', '━━━━━━━━━━━━━━━━━━━━', 'E. 초기화 명령', '━━━━━━━━━━━━━━━━━━━━', '- Paper봇 /pzero_reset_v1306 : Paper OPEN 정리 + /version_score 0전 anchor + no-limit shadow 0전 재시작', '- reset CLOSED는 원장 보존 · 새 성과판에서 제외', '', '[보존 원장 참고]', f"- raw {integer(mapping(snap.get('counts')).get('raw_ledger_rows'))} / exact {integer(mapping(snap.get('counts')).get('exact_unique_closed'), mapping(snap.get('counts')).get('included'))} / 중복 {integer(mapping(snap.get('counts')).get('duplicate_closed_rows'), mapping(snap.get('counts')).get('duplicates'))}", '- 위 숫자는 보존 확인용 · 새 전략 성과 숫자가 아님']
    return '\n'.join(lines)


def render_version_score_compact(_args: Sequence[str] = ()) -> str:  # type: ignore[override]
    snap=_performance_snapshot()
    if not snap: return '📊 성과 요약 · v1306\n- CHECK_SOURCE · canonical performance snapshot 없음'
    detail=_v1306_detail(); epoch=_v1306_active_epoch(detail); anchor=_v1306_anchor(detail); closed=mapping(epoch.get('closed')); candidate=_candidate_snapshot(); ccount=mapping(candidate.get('candidate')); no_limit=_v1306_no_limit(detail, snap); contract=_active_contract_snapshot(); entry=mapping(contract.get('entry'))
    rows=_v1306_epoch_rows(snap, detail); metric=_v1306_metric(rows)
    lines=['📊 성과 요약 · v1307 v1211식 분석판', f"- anchor: {anchor.get('epoch_id') or epoch.get('epoch_id') or 'CHECK_SOURCE'} / state {epoch.get('state') or '-'}", '', f"A. 실제 제한판 · OPEN {entry.get('total_cap',10)} / cycle {entry.get('cycle_new_open_cap',2)}"]
    lines.extend(_v1304_period_lines('전체 CLOSED', closed or metric)); lines.extend(_v1304_window_block(detail))
    lines += ['', 'B. 갯수제한 없는 경우']
    if no_limit:
        cur=mapping(no_limit.get('current')); lines.append(f"- 가상 OPEN {integer(no_limit.get('active_count'))} / 가상 CLOSED {integer(no_limit.get('closed_count'))} · 현재합 {fmt_pct(cur.get('sum_pct'),2)}")
        lines.extend(_v1304_period_lines('무제한 전체', mapping(mapping(no_limit.get('windows')).get('all'))))
    else:
        lines += ['⚪ Paper v1306 적용 후 다음 S1부터 shadow 수집', '   기존 CLOSED로 대체 안 함']
    lines += ['', 'C. 승패 분석', f"- 실제 CLOSED {metric['count']}전 · 승 {metric['wins']} / 패 {metric['losses']} · 합산 {fmt_pct(metric['sum_pct'],2)}"]
    if rows: lines.append(f"- 최근: {rows[-1].get('ticker') or '-'} · {fmt_pct(_v1306_row_pnl(rows[-1]),2)} · {_v1306_reason_label(rows[-1])}")
    lines += ['', 'D. 후보품질', f"- 후보 전체 {integer(ccount.get('total'))} → S1 {integer(ccount.get('s1'))} / S2 {integer(ccount.get('s2'))} / S3 {integer(ccount.get('s3'))}", '- 상세 원인판은 TXT · 자동매수 OFF', '- 초기화: Paper봇 /pzero_reset_v1306']
    return '\n'.join(lines)

try:
    COMMANDS['version_score'] = render_version_score
    COMMANDS['score'] = render_version_score
except Exception:
    pass



# =============================================================================
# v1309 - version_score no-limit shadow display: show picked-S1 diagnostics so
# shadow=0 is explainable; prefer v1309 summary if present.
# Display-only; no strategy/candidate/exit change.
# =============================================================================

def _v1309_no_limit(detail: Dict[str, Any], snap: Dict[str, Any]) -> Dict[str, Any]:
    for key in ('no_limit_shadow_v1310', 'no_limit_shadow_v1309', 'no_limit_shadow_v1306'):
        obj = detail.get(key) if isinstance(detail, dict) else None
        if isinstance(obj, dict):
            return obj
    obj = snap.get('no_limit_shadow_v1310') if isinstance(snap, dict) else None
    if isinstance(obj, dict):
        return obj
    obj = snap.get('no_limit_shadow_v1309') if isinstance(snap, dict) else None
    if isinstance(obj, dict):
        return obj
    obj = snap.get('no_limit_shadow_v1306') if isinstance(snap, dict) else None
    return obj if isinstance(obj, dict) else {}


def _v1309_no_limit_lines(no_limit: Dict[str, Any]) -> List[str]:
    lines=['━━━━━━━━━━━━━━━━━━━━','B. 갯수제한 없는 경우 · no-limit shadow','━━━━━━━━━━━━━━━━━━━━']
    if not no_limit:
        return lines+['⚪ shadow 원장 없음 · Paper 적용 후 다음 S1부터 수집','- 기존 CLOSED로 대체하지 않음']
    windows=mapping(no_limit.get('windows')); current=mapping(no_limit.get('current'))
    active=integer(no_limit.get('active_count'), current.get('count'), default=0); closed=integer(no_limit.get('closed_count'), mapping(windows.get('all')).get('count'), default=0)
    seen=integer(no_limit.get('last_picked_s1_count'), no_limit.get('candidate_count_seen'), default=0)
    started=integer(no_limit.get('last_started_virtual_count'), default=0)
    missing=integer(no_limit.get('last_price_missing_count'), default=0)
    lines += [
        f"- 상태: picked S1 {seen}개 확인 → 가상 OPEN {active}개 / 가상 CLOSED {closed}개",
        f"- 이번 cycle 가상 시작 {started}개 / 가격누락 {missing}개",
        f"- 중복key {integer(no_limit.get('last_duplicate_key_count'))} / 동일종목 {integer(no_limit.get('last_same_ticker_count'))} / capacity {integer(no_limit.get('last_capacity_skip_count'))}",
        '- 범위: exact S1 후보에서 OPEN 10/cycle 2 개수제한만 제거한 비교판',
    ]
    if no_limit.get('retired_v1309_shadow'):
        lines.append('- v1309 폭주 shadow는 제외하고 v1310 bounded shadow만 표시')
    if active:
        lines.append(f"- 현재 가상손익: {integer(current.get('count'))}개 · 합산 {fmt_pct(current.get('sum_pct'),2)} · 평균 {fmt_pct(current.get('avg_pct'),2)}")
    elif seen:
        lines.append('⚠️ picked S1은 있었지만 가상 OPEN 0개 · 가격누락/중복/이미 추적 중 여부를 아래에서 확인')
    for key,label in (('recent_3h','최근 3시간'),('recent_6h','최근 6시간'),('recent_12h','최근 12시간'),('recent_24h','최근 24시간'),('today','오늘'),('all','전체')):
        lines.extend(_v1304_period_lines(label, mapping(windows.get(key))))
    rows=[r for r in (no_limit.get('active_sample') or []) if isinstance(r,dict)]
    if rows:
        lines += ['', '가상 OPEN 표본']
        for r in rows[:5]:
            overlap=' · 실제OPEN동일종목' if r.get('actual_open_same_ticker_at_start') else ''
            lines.append(f"- {r.get('ticker') or '-'} · 현재 {fmt_pct(r.get('current_pct'),2)} · RR {r.get('rr') or '-'} · 목표 {r.get('target_price') or '-'} / invalid {r.get('invalid_price') or '-'}{overlap}")
    skipped=[r for r in (no_limit.get('last_skipped') or []) if isinstance(r,dict)]
    if skipped:
        lines += ['', '가상 추적 제외 표본']
        for r in skipped[:5]:
            lines.append(f"- {r.get('ticker') or r.get('identity') or '-'} · {r.get('reason') or '-'}")
    lines.append('- 실제 Paper 성과와 섞지 않음 · 자동매수 OFF')
    return lines


def render_version_score(_args: Sequence[str] = ()) -> str:  # type: ignore[override]
    snap=_performance_snapshot()
    if not snap: return '📊 성과 /version_score · v1310\n❌ canonical snapshot 준비 안 됨\n- 과거 성과 fallback 없음 · 자동매수 OFF'
    detail=_v1306_detail(); epoch=_v1306_active_epoch(detail); anchor=_v1306_anchor(detail); candidate=_candidate_snapshot(); ccount=mapping(candidate.get('candidate'))
    ops=_ops_snapshot(); funnel=mapping(ops.get('paper_funnel')); contract=_active_contract_snapshot(); entry=mapping(contract.get('entry'))
    age=file_age(PATHS.performance); trust='NORMAL' if age is not None and age<=900 and (epoch or anchor) else 'CHECK'
    rows=_v1306_epoch_rows(snap, detail); closed=mapping(epoch.get('closed')) or _v1306_metric(rows)
    reset=mapping(detail.get('reset_exclusions_v1305'), detail.get('reset_exclusions_v1304'), detail.get('reset_exclusions_v1302'))
    no_limit=_v1309_no_limit(detail, snap)
    lines=['📊 성과 /version_score · v1310 v1211식 성과판 + 분석판', f"- 신뢰: {icon(trust)} {trust} / snapshot {snap.get('snapshot_id') or '-'} / age {fmt_sec(age)}", f"- 기준: v1211 후보·진입 본선 / score anchor {anchor.get('epoch_id') or epoch.get('epoch_id') or 'CHECK_SOURCE'}", '- 원칙: 과거 CLOSED/reset/구 epoch fallback 금지 · 원장 삭제 없음 · 자동매수 OFF', _contract_compact_line(contract), '', '━━━━━━━━━━━━━━━━━━━━', f"A. 실제 Paper 제한판 · OPEN {entry.get('total_cap',10)}개 / cycle당 {entry.get('cycle_new_open_cap',2)}개", '━━━━━━━━━━━━━━━━━━━━', f"- 선발: S1 후보 점수순 → 높은 순위부터 진입 / 총 {entry.get('total_cap',10)}개 · cycle당 {entry.get('cycle_new_open_cap',2)}개"]
    lines.extend(_v1304_period_lines('전체 CLOSED', closed)); lines += ['']; lines.extend(_v1304_window_block(detail)); lines += ['', f"- 새 epoch OPEN {integer(epoch.get('current_open_count'))}개 / 적용 전 OPEN {integer(epoch.get('pre_anchor_open_count'))}개", f"- reset 제외 row {integer(reset.get('reset_transition_closed'))}개 / old CLOSED 제외 {integer(reset.get('pre_anchor_closed'))}개 · 원장 보존", '']
    lines += _v1309_no_limit_lines(no_limit)
    lines += ['', '━━━━━━━━━━━━━━━━━━━━', 'C. Paper 통과 · 이번 cycle', '━━━━━━━━━━━━━━━━━━━━', f"- 후보 전체 {integer(ccount.get('total'))} → S1 {integer(ccount.get('s1'))} / S2 {integer(ccount.get('s2'))} / S3 {integer(ccount.get('s3'))}", f"- Paper S1 판독 {integer(funnel.get('s1_seen'))} → 선택 {integer(funnel.get('selected'))} → OPEN {integer(funnel.get('opened'))}", '- 후보식·trigger·invalid·target·RR은 v1211 기준 유지', '']
    lines += _v1304_candidate_quality_lines(candidate)
    lines += ['', *(_v1306_analysis_lines(rows)), '', '━━━━━━━━━━━━━━━━━━━━', 'E. 초기화 명령', '━━━━━━━━━━━━━━━━━━━━', '- Paper봇 /pzero_reset_v1310 : Paper OPEN 정리 + /version_score 0전 anchor + no-limit shadow 0전 재시작', '- reset CLOSED는 원장 보존 · 새 성과판에서 제외', '', '[보존 원장 참고]', f"- raw {integer(mapping(snap.get('counts')).get('raw_ledger_rows'))} / exact {integer(mapping(snap.get('counts')).get('exact_unique_closed'), mapping(snap.get('counts')).get('included'))} / 중복 {integer(mapping(snap.get('counts')).get('duplicate_closed_rows'), mapping(snap.get('counts')).get('duplicates'))}", '- 위 숫자는 보존 확인용 · 새 전략 성과 숫자가 아님']
    return '\n'.join(lines)


def render_version_score_compact(_args: Sequence[str] = ()) -> str:  # type: ignore[override]
    snap=_performance_snapshot()
    if not snap: return '📊 성과 요약 · v1310\n- CHECK_SOURCE · canonical performance snapshot 없음'
    detail=_v1306_detail(); epoch=_v1306_active_epoch(detail); anchor=_v1306_anchor(detail); closed=mapping(epoch.get('closed')); candidate=_candidate_snapshot(); ccount=mapping(candidate.get('candidate')); no_limit=_v1309_no_limit(detail, snap); contract=_active_contract_snapshot(); entry=mapping(contract.get('entry'))
    rows=_v1306_epoch_rows(snap, detail); metric=_v1306_metric(rows)
    lines=['📊 성과 요약 · v1310 v1211식 분석판', f"- anchor: {anchor.get('epoch_id') or epoch.get('epoch_id') or 'CHECK_SOURCE'} / state {epoch.get('state') or '-'}", '', f"A. 실제 제한판 · OPEN {entry.get('total_cap',10)} / cycle {entry.get('cycle_new_open_cap',2)}"]
    lines.extend(_v1304_period_lines('전체 CLOSED', closed or metric)); lines.extend(_v1304_window_block(detail))
    lines += ['', 'B. 갯수제한 없는 경우']
    if no_limit:
        cur=mapping(no_limit.get('current')); lines.append(f"- picked S1 {integer(no_limit.get('last_picked_s1_count'), no_limit.get('candidate_count_seen'))} / 가상 OPEN {integer(no_limit.get('active_count'))} / 가상 CLOSED {integer(no_limit.get('closed_count'))} · 현재합 {fmt_pct(cur.get('sum_pct'),2)}")
        lines.extend(_v1304_period_lines('무제한 전체', mapping(mapping(no_limit.get('windows')).get('all'))))
    else:
        lines += ['⚪ Paper 적용 후 다음 S1부터 shadow 수집', '   기존 CLOSED로 대체 안 함']
    lines += ['', 'C. 승패 분석', f"- 실제 CLOSED {metric['count']}전 · 승 {metric['wins']} / 패 {metric['losses']} · 합산 {fmt_pct(metric['sum_pct'],2)}"]
    if rows: lines.append(f"- 최근: {rows[-1].get('ticker') or '-'} · {fmt_pct(_v1306_row_pnl(rows[-1]),2)} · {_v1306_reason_label(rows[-1])}")
    lines += ['', 'D. 후보품질', f"- 후보 전체 {integer(ccount.get('total'))} → S1 {integer(ccount.get('s1'))} / S2 {integer(ccount.get('s2'))} / S3 {integer(ccount.get('s3'))}", '- 상세 원인판은 TXT · 자동매수 OFF', '- 초기화: Paper봇 /pzero_reset_v1310']
    return '\n'.join(lines)

try:
    COMMANDS['version_score'] = render_version_score
    COMMANDS['score'] = render_version_score
except Exception:
    pass




# =============================================================================
# v1311 - restore OPEN-aware /version_score and make Paper collecting obvious.
# Display only.  Reads canonical snapshots; no strategy/candidate/exit changes.
# =============================================================================

def _v1311_perf_semantic_state(snap: Mapping[str, Any]) -> Tuple[str, List[str]]:
    reasons: List[str] = []
    state = 'NORMAL'
    age = file_age(PATHS.performance)
    if age is None or age > 300:
        state = 'CHECK'; reasons.append(f'snapshot age {fmt_sec(age)}')
    for key in ('semantic_current','is_current','current'):
        if key in snap and snap.get(key) is False:
            state = 'CHECK'; reasons.append(f'{key}=False')
    hb = snap.get('heartbeat') or snap.get('writer_heartbeat') or snap.get('state')
    if str(hb).upper() in {'STARTUP','COLLECTING','CHECK'}:
        state = 'CHECK'; reasons.append(f'heartbeat {hb}')
    return state, reasons

def _v1311_open_lines_for_score(snap: Mapping[str, Any], epoch: Mapping[str, Any]) -> List[str]:
    fallback_open_count = integer(epoch.get('current_open_count'), epoch.get('open_count'), default=0)
    lines = _open_book_lines(_book_map(snap), fallback_open_count)
    # If the canonical book is sparse, still show the epoch OPEN count near the top.
    if fallback_open_count and not any(f'현재 OPEN {fallback_open_count}개' in x for x in lines):
        lines.insert(3, f'- epoch OPEN {fallback_open_count}개 · 손익 상세는 canonical book snapshot 기준')
    return lines

def _v1311_paper_collecting_lines(candidate: Mapping[str, Any], ops: Mapping[str, Any]) -> List[str]:
    ccount = mapping(candidate.get('candidate'))
    funnel = mapping(ops.get('paper_funnel'))
    strategy_s1 = integer(ccount.get('s1'), default=0)
    paper_s1 = integer(funnel.get('s1_seen'), default=0)
    selected = integer(funnel.get('selected'), default=0)
    opened = integer(funnel.get('opened'), default=0)
    state = str(funnel.get('state') or ops.get('paper_state') or '').upper()
    lines = [
        '━━━━━━━━━━━━━━━━━━━━',
        'C. Paper 후보판독 · 현재 cycle',
        '━━━━━━━━━━━━━━━━━━━━',
        f'- Strategy S1 {strategy_s1}개 / Paper S1 판독 {paper_s1}개 → 선택 {selected} → OPEN {opened}',
    ]
    if strategy_s1 > 0 and paper_s1 == 0:
        lines += [
            '🟡 Paper 수집 중 또는 판독 지연',
            '- 후보가 0개인 문제가 아니라 Strategy→Paper 판독 증거가 아직 맞지 않음',
            '- 이 상태에서는 신규 OPEN 0개가 정상 성과로 해석되면 안 됨',
        ]
    elif paper_s1 > 0 and selected == 0:
        lines += [
            '🟡 S1은 읽었지만 실제 선택 0개',
            '- 중복종목·재진입·OPEN 자리·최종 안전조건을 아래 지도에서 확인',
        ]
    else:
        lines.append('- 후보식·trigger·invalid·target·RR은 v1211 기준 유지')
    return lines

def _v1311_no_limit_safe_lines(no_limit: Dict[str, Any], strategy_s1: int = 0) -> List[str]:
    lines=['━━━━━━━━━━━━━━━━━━━━','B. 갯수제한 없는 경우 · no-limit shadow','━━━━━━━━━━━━━━━━━━━━']
    if not no_limit:
        return lines+['⚪ shadow 원장 없음 · Paper 적용 후 다음 S1부터 수집','- 기존 CLOSED로 대체하지 않음']
    windows=mapping(no_limit.get('windows')); current=mapping(no_limit.get('current'))
    active=integer(no_limit.get('active_count'), current.get('count'), default=0)
    closed=integer(no_limit.get('closed_count'), mapping(windows.get('all')).get('count'), default=0)
    picked=integer(no_limit.get('last_picked_s1_count'), no_limit.get('candidate_count_seen'), default=0)
    runaway = active > max(100, max(1, picked, strategy_s1) * 5)
    if runaway:
        lines += [
            f'❌ shadow 비정상 · picked S1 {picked}개인데 가상 OPEN {active}개',
            '- 이 값은 성과 비교에 사용 금지',
            '- v1311은 새 bounded shadow만 사용하고 이전 폭주분은 표시 제외 대상으로 봄',
        ]
        return lines
    lines += [
        f'- 상태: picked S1 {picked}개 확인 → 가상 OPEN {active}개 / 가상 CLOSED {closed}개',
        f"- 신규 {integer(no_limit.get('last_started_virtual_count'))} / 중복key {integer(no_limit.get('last_duplicate_key_count'))} / 동일종목 {integer(no_limit.get('last_same_ticker_count'))} / 가격누락 {integer(no_limit.get('last_price_missing_count'))}",
        '- 범위: exact S1 후보에서 OPEN 10/cycle 2 개수제한만 제거한 비교판',
    ]
    if active:
        lines.append(f"- 현재 가상손익: {integer(current.get('count'))}개 · 합산 {fmt_pct(current.get('sum_pct'),2)} · 평균 {fmt_pct(current.get('avg_pct'),2)}")
    for key,label in (('recent_3h','최근 3시간'),('recent_6h','최근 6시간'),('recent_12h','최근 12시간'),('recent_24h','최근 24시간'),('today','오늘'),('all','전체')):
        lines.extend(_v1304_period_lines(label, mapping(windows.get(key))))
    rows=[r for r in (no_limit.get('active_sample') or []) if isinstance(r,dict)]
    if rows:
        lines += ['', '가상 OPEN 표본']
        for r in rows[:5]:
            lines.append(f"- {r.get('ticker') or '-'} · 현재 {fmt_pct(r.get('current_pct'),2)} · 목표 {r.get('target_price') or '-'} / invalid {r.get('invalid_price') or '-'}")
    lines.append('- 실제 Paper 성과와 섞지 않음 · 자동매수 OFF')
    return lines

def render_version_score(_args: Sequence[str] = ()) -> str:  # type: ignore[override]
    snap=_performance_snapshot()
    if not snap: return '📊 성과 /version_score · v1311\n❌ canonical snapshot 준비 안 됨\n- 과거 성과 fallback 없음 · 자동매수 OFF'
    detail=_v1306_detail(); epoch=_v1306_active_epoch(detail); anchor=_v1306_anchor(detail); candidate=_candidate_snapshot(); ccount=mapping(candidate.get('candidate'))
    ops=_ops_snapshot(); contract=_active_contract_snapshot(); entry=mapping(contract.get('entry'))
    trust,reasons=_v1311_perf_semantic_state(snap)
    rows=_v1306_epoch_rows(snap, detail); closed=mapping(epoch.get('closed')) or _v1306_metric(rows)
    reset=mapping(detail.get('reset_exclusions_v1305'), detail.get('reset_exclusions_v1304'), detail.get('reset_exclusions_v1302'))
    no_limit=_v1309_no_limit(detail, snap); strategy_s1=integer(ccount.get('s1'), default=0)
    lines=['📊 성과 /version_score · v1311 v1211식 성과판 + OPEN판', f"- 신뢰: {icon(trust)} {trust} / snapshot {snap.get('snapshot_id') or '-'} / age {fmt_sec(file_age(PATHS.performance))}", f"- 기준: v1211 후보·진입 본선 / score anchor {anchor.get('epoch_id') or epoch.get('epoch_id') or 'CHECK_SOURCE'}", '- 원칙: 과거 CLOSED/reset/구 epoch fallback 금지 · 원장 삭제 없음 · 자동매수 OFF', _contract_compact_line(contract)]
    if reasons:
        lines.append('- CHECK 이유: ' + ', '.join(reasons[:4]))
    lines += ['', '━━━━━━━━━━━━━━━━━━━━', f"A. 실제 Paper 제한판 · OPEN {entry.get('total_cap',10)}개 / cycle당 {entry.get('cycle_new_open_cap',2)}개", '━━━━━━━━━━━━━━━━━━━━', f"- 선발: S1 후보 점수순 → 높은 순위부터 진입 / 총 {entry.get('total_cap',10)}개 · cycle당 {entry.get('cycle_new_open_cap',2)}개"]
    lines.extend(_v1304_period_lines('전체 CLOSED', closed)); lines += ['']; lines.extend(_v1304_window_block(detail))
    lines += ['', *(_v1311_open_lines_for_score(snap, epoch)), '', f"- 새 epoch OPEN {integer(epoch.get('current_open_count'))}개 / 적용 전 OPEN {integer(epoch.get('pre_anchor_open_count'))}개", f"- reset 제외 row {integer(reset.get('reset_transition_closed'))}개 / old CLOSED 제외 {integer(reset.get('pre_anchor_closed'))}개 · 원장 보존", '']
    lines += _v1311_no_limit_safe_lines(no_limit, strategy_s1=strategy_s1)
    lines += ['', *_v1311_paper_collecting_lines(candidate, ops), '']
    lines += _v1304_candidate_quality_lines(candidate)
    lines += ['', *(_v1306_analysis_lines(rows)), '', '━━━━━━━━━━━━━━━━━━━━', 'E. 초기화 명령', '━━━━━━━━━━━━━━━━━━━━', '- Paper봇 /pzero_reset_v1311 : Paper OPEN 정리 + /version_score 0전 anchor + no-limit shadow 0전 재시작', '- reset CLOSED는 원장 보존 · 새 성과판에서 제외', '', '[보존 원장 참고]', f"- raw {integer(mapping(snap.get('counts')).get('raw_ledger_rows'))} / exact {integer(mapping(snap.get('counts')).get('exact_unique_closed'), mapping(snap.get('counts')).get('included'))} / 중복 {integer(mapping(snap.get('counts')).get('duplicate_closed_rows'), mapping(snap.get('counts')).get('duplicates'))}", '- 위 숫자는 보존 확인용 · 새 전략 성과 숫자가 아님']
    return '\n'.join(lines)

def render_version_score_compact(_args: Sequence[str] = ()) -> str:  # type: ignore[override]
    snap=_performance_snapshot()
    if not snap: return '📊 성과 요약 · v1311\n- CHECK_SOURCE · canonical performance snapshot 없음'
    detail=_v1306_detail(); epoch=_v1306_active_epoch(detail); anchor=_v1306_anchor(detail); closed=mapping(epoch.get('closed')); candidate=_candidate_snapshot(); ccount=mapping(candidate.get('candidate')); no_limit=_v1309_no_limit(detail, snap); contract=_active_contract_snapshot(); entry=mapping(contract.get('entry'))
    rows=_v1306_epoch_rows(snap, detail); metric=_v1306_metric(rows); trust,reasons=_v1311_perf_semantic_state(snap)
    open_book=_book_map(snap); open_stat=mapping(open_book.get('fresh_open'), open_book.get('current_open'), open_book.get('current'))
    open_count=integer(open_book.get('open_count'), open_stat.get('count'), epoch.get('current_open_count'), default=0)
    open_total=num(open_book.get('current_total'), _stat_total(open_stat), default=None)
    open_avg=num(open_book.get('current_avg'), _stat_avg(open_stat), default=None)
    open_wins=integer(open_book.get('wins'), open_stat.get('wins'), default=0); open_losses=integer(open_book.get('losses'), open_stat.get('losses'), default=0)
    lines=['📊 성과 요약 · v1311 v1211식 OPEN 포함판', f"- 신뢰: {icon(trust)} {trust} / anchor {anchor.get('epoch_id') or epoch.get('epoch_id') or 'CHECK_SOURCE'}"]
    if reasons: lines.append('- CHECK 이유: ' + ', '.join(reasons[:3]))
    lines += ['', f"A. 실제 제한판 · OPEN {entry.get('total_cap',10)} / cycle {entry.get('cycle_new_open_cap',2)}"]
    lines.extend(_v1304_period_lines('전체 CLOSED', closed or metric)); lines.extend(_v1304_window_block(detail))
    lines += ['', f"📦 현재 OPEN {open_count}개 · 평가손익 {fmt_pct(open_total,2)} · 평균 {fmt_pct(open_avg,2)}", f"- 수익 {open_wins} / 손실 {open_losses} · CLOSED 승률에는 미포함"]
    strategy_s1=integer(ccount.get('s1'), default=0); active=integer(no_limit.get('active_count')) if no_limit else 0; picked=integer(no_limit.get('last_picked_s1_count'), no_limit.get('candidate_count_seen')) if no_limit else 0
    runaway = bool(no_limit) and active > max(100, max(1,picked,strategy_s1)*5)
    lines += ['', 'B. 갯수제한 없는 경우']
    if runaway:
        lines += [f'❌ shadow 비정상 · picked S1 {picked} / 가상 OPEN {active}', '- 비교 성과 사용 금지 · v1311 bounded shadow 재시작 필요']
    elif no_limit:
        cur=mapping(no_limit.get('current')); lines.append(f"- picked S1 {picked} / 가상 OPEN {active} / 가상 CLOSED {integer(no_limit.get('closed_count'))} · 현재합 {fmt_pct(cur.get('sum_pct'),2)}")
        lines.extend(_v1304_period_lines('무제한 전체', mapping(mapping(no_limit.get('windows')).get('all'))))
    else:
        lines += ['⚪ Paper 적용 후 다음 S1부터 shadow 수집', '   기존 CLOSED로 대체 안 함']
    ops=_ops_snapshot(); funnel=mapping(ops.get('paper_funnel')); paper_s1=integer(funnel.get('s1_seen'), default=0)
    lines += ['', 'C. Paper 후보판독', f"- Strategy S1 {strategy_s1} / Paper S1 {paper_s1} → 선택 {integer(funnel.get('selected'))} → OPEN {integer(funnel.get('opened'))}"]
    if strategy_s1>0 and paper_s1==0: lines.append('- 🟡 Paper 수집 중/판독 지연 · 신규 OPEN 0을 정상 성과로 해석 금지')
    lines += ['', 'D. 승패 분석', f"- 실제 CLOSED {metric['count']}전 · 승 {metric['wins']} / 패 {metric['losses']} · 합산 {fmt_pct(metric['sum_pct'],2)}"]
    if rows: lines.append(f"- 최근: {rows[-1].get('ticker') or '-'} · {fmt_pct(_v1306_row_pnl(rows[-1]),2)} · {_v1306_reason_label(rows[-1])}")
    lines += ['', 'E. 후보품질', f"- 후보 전체 {integer(ccount.get('total'))} → S1 {strategy_s1} / S2 {integer(ccount.get('s2'))} / S3 {integer(ccount.get('s3'))}", '- 상세 원인판은 TXT · 자동매수 OFF', '- 초기화: Paper봇 /pzero_reset_v1311']
    return '\n'.join(lines)

try:
    COMMANDS['version_score'] = render_version_score
    COMMANDS['score'] = render_version_score
except Exception:
    pass


# v1190 read-only Main command-bundle phase timing
from runtime_phase_probe_v1190 import wrap_function as _v1190_wrap_function
_v1190_wrap_function(globals(), "collect_and_send", "main", "command_bundle", BOT_VERSION, 300.0)

# =============================================================================
# v1317 - display repair after Paper core restore.
# Main remains read-only.  It does not recalculate performance/candidates.
# =============================================================================
BOT_VERSION = "수익형 v2.13.1193"
MAIN_BOT_VERSION = BOT_VERSION
BUILD_LABEL = "v1325_restore_last_good_strategy_writer_2026-07-07"
V650_BUILD_LABEL = BUILD_LABEL


def _v1317_no_limit_view(detail: Dict[str, Any], snap: Dict[str, Any]) -> Dict[str, Any]:
    # Prefer the new disabled status.  Never surface v1309/v1310 runaway files as
    # active comparison data again.
    for key in ('no_limit_shadow_v1317', 'no_limit_shadow_v1311'):
        obj = detail.get(key) if isinstance(detail, dict) else None
        if isinstance(obj, dict):
            return obj
        obj = snap.get(key) if isinstance(snap, dict) else None
        if isinstance(obj, dict):
            return obj
    status = current_json(BASE_DIR / 'paper_no_limit_shadow_v1317_status.json', {}) or {}
    if isinstance(status, dict) and status:
        return status
    old = {}
    for key in ('no_limit_shadow_v1310', 'no_limit_shadow_v1309', 'no_limit_shadow_v1306'):
        obj = detail.get(key) if isinstance(detail, dict) else None
        if isinstance(obj, dict):
            old = obj; break
    if not old:
        for key in ('no_limit_shadow_v1310', 'no_limit_shadow_v1309', 'no_limit_shadow_v1306'):
            obj = snap.get(key) if isinstance(snap, dict) else None
            if isinstance(obj, dict):
                old = obj; break
    if old:
        return {
            'schema': 'paper_no_limit_shadow_summary_v1317',
            'state': 'DISABLED_FOR_PAPER_STABILITY',
            'reason': 'old shadow file exists but v1317 excludes it after runaway virtual OPEN',
            'old_shadow_active_count': integer(old.get('active_count'), mapping(old.get('current')).get('count'), default=0),
            'old_shadow_schema': old.get('schema'),
            'active_count': 0, 'closed_count': 0,
            'current': {'count':0,'sum_pct':0.0,'avg_pct':0.0},
            'windows': {},
            'old_shadow_excluded': True,
            'auto_buy': False,
        }
    return {}

# Replace the old lookup used by the v1311 renderer.
_v1309_no_limit = _v1317_no_limit_view  # type: ignore[assignment]


def _v1317_no_limit_safe_lines(no_limit: Dict[str, Any], strategy_s1: int = 0) -> List[str]:
    lines=['━━━━━━━━━━━━━━━━━━━━','B. 갯수제한 없는 경우 · no-limit shadow','━━━━━━━━━━━━━━━━━━━━']
    if not no_limit:
        return lines+['⚪ shadow 원장 없음 또는 안정화 대기', '- 기존 CLOSED로 대체하지 않음']
    state = str(no_limit.get('state') or '').upper()
    if state == 'DISABLED_FOR_PAPER_STABILITY' or no_limit.get('old_shadow_excluded'):
        old_count = integer(no_limit.get('old_shadow_active_count'), default=0)
        lines += [
            '🟡 no-limit shadow 비활성 · Paper core 복구 우선',
            f"- 이유: {no_limit.get('reason') or 'old shadow retired'}",
            f'- 이전 폭주 shadow active {old_count}개는 비교 성과에서 제외',
            '- 실제 Paper 제한판/OPEN/CLOSED와 섞지 않음 · 자동매수 OFF',
        ]
        return lines
    return _v1311_no_limit_safe_lines(no_limit, strategy_s1=strategy_s1) if '_v1311_no_limit_safe_lines' in globals() else lines

_v1311_no_limit_safe_lines = _v1317_no_limit_safe_lines  # type: ignore[assignment]

# Ensure commands point at the latest read-only renderer labels.
try:
    COMMANDS['version_score'] = render_version_score
    COMMANDS['score'] = render_version_score
except Exception:
    pass


# =============================================================================
# v1320 - read-only display for bounded no-limit shadow and current candidate board.
# Main still reads only canonical Paper/Review files. It does not recompute or
# change Strategy/Paper decisions.
# =============================================================================
BOT_VERSION = "수익형 v2.13.1193"
MAIN_BOT_VERSION = BOT_VERSION
BUILD_LABEL = "v1325_restore_last_good_strategy_writer_2026-07-07"
V650_BUILD_LABEL = BUILD_LABEL


def _v1320_no_limit_view(detail: Dict[str, Any], snap: Dict[str, Any]) -> Dict[str, Any]:
    for path_name in ('paper_no_limit_shadow_v1320.json','paper_no_limit_shadow_v1311.json'):
        obj = current_json(BASE_DIR / path_name, {}) or {}
        if isinstance(obj, dict) and obj:
            # v1320 is safe. Older v1311 is accepted only when it is not runaway.
            active=integer(obj.get('active_count'), mapping(obj.get('current')).get('count'), default=0)
            picked=integer(obj.get('last_picked_s1_count'), obj.get('candidate_count_seen'), default=0)
            if path_name.endswith('v1320.json') or active <= max(100, max(1,picked)*5):
                return obj
    status = current_json(BASE_DIR / 'paper_no_limit_shadow_v1320.json', {}) or {}
    return status if isinstance(status,dict) else {}


def _v1320_no_limit_lines(no_limit: Dict[str, Any], strategy_s1: int = 0) -> List[str]:
    lines=['━━━━━━━━━━━━━━━━━━━━','B. 갯수제한 없는 경우 · no-limit shadow','━━━━━━━━━━━━━━━━━━━━']
    if not no_limit:
        return lines+['⚪ 무제한 가상 원장 · 수집 대기', '- 실제로 OPEN하지 않은 후보 수익률을 기존 CLOSED로 꾸미지 않음', '- 다음 S1부터 3h·6h·12h·24h·오늘·전체를 표시']
    state=str(no_limit.get('state') or '').upper()
    if state in {'DISABLED_FOR_PAPER_STABILITY','ERROR'} or no_limit.get('old_shadow_excluded'):
        return lines+[f"🟡 무제한 가상 원장 {state or 'CHECK'}", f"- 이유: {no_limit.get('reason') or no_limit.get('error') or '확인 필요'}", '- 실제 Paper 제한판/OPEN/CLOSED와 섞지 않음 · 자동매수 OFF']
    windows=mapping(no_limit.get('windows')); current=mapping(no_limit.get('current'))
    active=integer(no_limit.get('active_count'), current.get('count'), default=0)
    closed=integer(no_limit.get('closed_count'), mapping(windows.get('all')).get('count'), default=0)
    picked=integer(no_limit.get('last_picked_s1_count'), no_limit.get('candidate_count_seen'), default=0)
    runaway=active > max(100, max(1,picked,strategy_s1)*5)
    if runaway:
        return lines+[f'❌ shadow 비정상 · picked S1 {picked} / 가상 OPEN {active}', '- 비교 성과 사용 금지 · bounded shadow 재시작 필요']
    lines += [
        f'- 상태: picked S1 {picked}개 확인 → 가상 OPEN {active}개 / 가상 CLOSED {closed}개',
        f"- 신규 {integer(no_limit.get('last_started_virtual_count'))} / 중복key {integer(no_limit.get('last_duplicate_key_count'))} / 동일종목 {integer(no_limit.get('last_same_ticker_count'))} / 가격누락 {integer(no_limit.get('last_price_missing_count'))}",
        '- 범위: exact S1 후보에서 OPEN 10/cycle 2 개수제한만 제거한 비교판',
    ]
    if active:
        lines.append(f"- 현재 가상손익: {integer(current.get('count'))}개 · 합산 {fmt_pct(current.get('sum_pct'),2)} · 평균 {fmt_pct(current.get('avg_pct'),2)}")
    for key,label in (('recent_3h','최근 3시간'),('recent_6h','최근 6시간'),('recent_12h','최근 12시간'),('recent_24h','최근 24시간'),('today','오늘'),('all','전체')):
        lines.extend(_v1304_period_lines(label, mapping(windows.get(key))))
    rows=[r for r in (no_limit.get('active_sample') or []) if isinstance(r,dict)]
    if rows:
        lines += ['', '가상 OPEN 표본']
        for r in rows[:5]:
            lines.append(f"- {r.get('ticker') or '-'} · 현재 {fmt_pct(r.get('current_pct'),2)} · entry {r.get('entry_price') or '-'} / target {r.get('target_price') or '-'} / invalid {r.get('invalid_price') or '-'}")
    lines.append('- 실제 Paper 성과와 섞지 않음 · 자동매수 OFF')
    return lines

# Override v1317 disabled display with v1320 bounded shadow display.
_v1309_no_limit = _v1320_no_limit_view  # type: ignore[assignment]
_v1311_no_limit_safe_lines = _v1320_no_limit_lines  # type: ignore[assignment]
try:
    COMMANDS['version_score'] = render_version_score
    COMMANDS['score'] = render_version_score
except Exception:
    pass


if __name__ == "__main__":
    raise SystemExit(main())
