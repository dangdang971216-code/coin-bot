import importlib.util
import json
import sys
import tempfile
import unittest
from pathlib import Path

ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT))

def load(name,path):
    spec=importlib.util.spec_from_file_location(name,ROOT/path)
    mod=importlib.util.module_from_spec(spec); spec.loader.exec_module(mod); return mod

review=load('review_v1242','review_worker_v1.030.py')
main=load('main_v1242','coinbot_main_v2_13_1152.py')
paper=load('paper_v1242','paper_bot_v1.072.py')

def write_json(path,obj):
    path.write_text(json.dumps(obj,ensure_ascii=False),encoding='utf-8')

def candidate(ticker='AAA',cycle='cycle-1',stage='S1',price=100.0,score=80.0):
    return {
        'ticker':ticker,'candidate_pipeline_cycle_id_v1150':cycle,'s_stage':stage,
        'current_price':price,'global_entry_score_v1212':score,'configured_fee_pct':0.1,
        'dynamic_structure_plan_v1212':{
            'trigger':{'price':99.0},'invalid':{'price':95.0},'target':{'price':110.0}},
        'v1211_structure_shadow_v1222':{
            'source_exact':True,'trigger':{'price':98.0},'invalid':{'price':94.0},'target':{'price':108.0}},
    }

class V1242Contract(unittest.TestCase):
    def setUp(self):
        self.tmp=tempfile.TemporaryDirectory(); self.base=Path(self.tmp.name)
        write_json(self.base/'canonical_performance_snapshot_v987.json',{'rows':[]})
        paper.V1242_EXIT_REPLAY_POLL_LEDGER=self.base/'paper_exit_replay_poll_v1242.jsonl'
        paper.V1242_EXIT_REPLAY_CLOSE_LEDGER=self.base/'paper_exit_replay_close_v1242.jsonl'
        paper.V1242_EXIT_REPLAY_STATUS=self.base/'paper_exit_replay_status_v1242.json'
        paper._V1242_SWEEP_BUFFER.clear(); paper._V1242_SWEEP_CONTEXT.clear()

    def tearDown(self): self.tmp.cleanup()

    def write_generation(self,rows,cycle='cycle-1',commit='commit-1'):
        (self.base/'paper_candidates_latest.jsonl').write_text('\n'.join(json.dumps(r) for r in rows)+'\n')
        req={'pipeline_cycle_id':cycle,'candidate_commit_id':commit,'candidate_rows':len(rows),
             's1_count':sum(1 for r in rows if review.stage(r)=='S1')}
        write_json(self.base/'review_observation_request_v1181.json',req)
        write_json(self.base/'clean_strategy_candidate_pipeline_status_v1150.json',{
            'state':'NORMAL','complete':True,'cycle_id':cycle,'candidate_commit_id':commit,
            'candidate_rows':len(rows),'all_required_commits_v1150':True})
        return req

    def test_generation_alignment_and_legacy_separation(self):
        rows=[candidate(),candidate('BBB',stage='S2')]; req=self.write_generation(rows)
        loaded,info=review._v1241_stable_committed_rows(self.base,req,True)
        self.assertEqual(len(loaded),2); self.assertEqual(info['canonical_s1_rows'],1)
        legacy={'schema':review.V1233_STATE_SCHEMA,'paired_matchup_v1237':{
            'unlimited':{'open':{'old':{'event_id':'old'}},'closed':[],'skipped':[]},
            'practical':{'open':{},'closed':[],'skipped':[]}}}
        write_json(self.base/'version_score_review_state_v1237.json',legacy)
        gen={'cycle_id':'cycle-1','candidate_commit_id':'commit-1','generation_key':'cycle-1|commit-1','state':'NORMAL'}
        out=review.update_version_score_review(self.base,rows,live_rows=rows,generation=gen,generation_integrity=info)
        self.assertEqual(out['paired_matchup_v1241']['legacy_pre_v1241_excluded']['open_count'],1)
        self.assertIn('paper_exact_exit_replay_v1242',out)

    def test_poll_record_contains_exact_sequence_inputs(self):
        pos={
            'pos_id':'p1','ticker':'AAA','strategy_mode':'ALT_SWING_V977','entry_price':100.0,'current_price':101.0,'opened_at':1000.0,'last_update':1060.0,
            'last_pnl_pct':0.9,'peak_pct':1.2,'trough_pct':-0.2,'structure_contract_version':'structure_contract_v1212_dynamic_zones',
            'structure_contract_hash':'hash1','decision_key':'d1',
            'swing_structure_plan_v977':{'target':{'price':110.0,'tf':'h2'},'invalid':{'price':95.0,'tf':'m30'}},
            'exit_contract_v1207':{'schema':paper.V1207_DYNAMIC_SCHEMA,'general_confirmation':{'support_break_polls':2}},
            'exit_decision_spine':{'action':'hold','reason':'dynamic_structure_strength_hold','age_min':1.0,'suppressed_fixed_reason_v1207':'swing_trailing'},
            'dynamic_exit_state_v1207':{'protect_line_price':100.5,'break_streak':1,'weak_streak':2,'strength_count':3,'weakness_count':2,
                'last_evidence_state':'FULL','giveback_ratio':0.25,'role':'general','last_evidence':{'feature_age_sec':2.0,'micro_age_sec':3.0}},
        }
        row=paper._v1242_poll_record(pos)
        self.assertEqual(row['p'],'p1'); self.assertEqual(row['a'],'hold'); self.assertEqual(row['sp'],100.5)
        self.assertEqual(row['bs'],1); self.assertEqual(row['ws'],2); self.assertEqual(row['tg'],110.0); self.assertEqual(row['iv'],95.0)
        self.assertTrue(row['k']); self.assertTrue(row['cd']); self.assertEqual(pos['exit_replay_poll_key_v1242'],row['k'])

    def test_poll_sweep_append_and_status(self):
        original=paper._V1242_PREV_PROCESS_EXITS
        try:
            def fake(open_pos,ctrl,owner):
                paper._V1242_SWEEP_BUFFER.append({'k':'poll1','p':'p1','a':'hold'})
                return {'checked':1,'held':1}
            paper._V1242_PREV_PROCESS_EXITS=fake
            result=paper.process_open_positions_for_exit__v1242({'p1':{}},{},'test_owner')
        finally:
            paper._V1242_PREV_PROCESS_EXITS=original
        self.assertEqual(result['exact_exit_replay_capture_v1242']['record_count'],1)
        status=json.loads(paper.V1242_EXIT_REPLAY_STATUS.read_text())
        self.assertEqual(status['poll_sweeps'],1); self.assertEqual(status['poll_records'],1); self.assertEqual(status['state'],'NORMAL')
        payload=json.loads(paper.V1242_EXIT_REPLAY_POLL_LEDGER.read_text().strip())
        self.assertEqual(payload['records'][0]['k'],'poll1')


    def test_close_poll_is_written_before_commit_link(self):
        original_update=paper._V1242_PREV_UPDATE_POSITION
        original_commit=paper._V1242_PREV_COMMIT_CLOSED
        order=[]
        try:
            def fake_update(pos,ctrl):
                updated=dict(pos)
                updated.update({'last_update':1060.0,'last_pnl_pct':-0.5,'peak_pct':0.2,'trough_pct':-0.5,
                    'exit_decision_spine':{'action':'close','reason':'structure_invalid','age_min':1.0}})
                closed=dict(updated)
                return updated,closed
            def fake_commit(open_pos,pid,updated,closed,owner):
                order.append('commit')
                self.assertTrue(paper.V1242_EXIT_REPLAY_POLL_LEDGER.exists())
                poll=json.loads(paper.V1242_EXIT_REPLAY_POLL_LEDGER.read_text().strip())
                self.assertEqual(poll['schema'],'paper_exit_replay_close_poll_v1242')
                return dict(closed),True,'committed_exact_closed'
            paper._V1242_PREV_UPDATE_POSITION=fake_update
            paper._V1242_PREV_COMMIT_CLOSED=fake_commit
            pos={'pos_id':'p1','ticker':'AAA','strategy_mode':'ALT_SWING_V977','entry_price':100.0,'current_price':99.5,
                 'opened_at':1000.0,'swing_target_price_v977':110.0,'swing_invalid_price_v977':99.5}
            updated,closed=paper.update_position__v1242_exact_capture(pos,{})
            order.append('poll_written')
            paper.commit_closed_position_exact__v1242({},'p1',updated,closed,'owner')
        finally:
            paper._V1242_PREV_UPDATE_POSITION=original_update
            paper._V1242_PREV_COMMIT_CLOSED=original_commit
        self.assertEqual(order,['poll_written','commit'])

    def test_close_commit_link_is_append_only_and_does_not_change_result(self):
        original=paper._V1242_PREV_COMMIT_CLOSED
        try:
            def fake(open_pos,pid,updated,closed,owner):
                out=dict(closed); out.update({'ticker':'AAA','exit_reason':'swing_dynamic_momentum_decay','pnl_pct':1.25,'closed_result_key':'closed:p1'})
                return out,True,'committed_exact_closed'
            paper._V1242_PREV_COMMIT_CLOSED=fake
            updated={'ticker':'AAA','exit_replay_poll_key_v1242':'poll-x','exit_replay_contract_digest_v1242':'cd-x','decision_key':'d1'}
            rr,ok,reason=paper.commit_closed_position_exact__v1242({},'p1',updated,{},'owner')
        finally:
            paper._V1242_PREV_COMMIT_CLOSED=original
        self.assertTrue(ok); self.assertEqual(reason,'committed_exact_closed'); self.assertEqual(rr['pnl_pct'],1.25)
        event=json.loads(paper.V1242_EXIT_REPLAY_CLOSE_LEDGER.read_text().strip())
        self.assertEqual(event['poll_key'],'poll-x'); self.assertTrue(event['commit_ok'])
        status=json.loads(paper.V1242_EXIT_REPLAY_STATUS.read_text())
        self.assertEqual(status['close_commit_ok'],1)

    def test_review_and_main_show_stage1_without_claiming_full_replay(self):
        write_json(self.base/'paper_exit_replay_status_v1242.json',{
            'schema':'paper_exit_replay_status_v1242','state':'NORMAL','version':'paper_bot_v1.072','build':'v1242',
            'poll_sweeps':5,'poll_records':40,'close_commit_ok':2,'close_commit_fail':0,'evidence_append_failures':0,
            'historical_pre_v1242':'NOT_REPLAYABLE_WITHOUT_POLL_EVIDENCE'})
        replay=review._v1242_paper_exact_replay_status(self.base)
        self.assertTrue(replay['current_policy_poll_capture_exact'])
        self.assertEqual(replay['alternate_structure_exact_replay'],'READY_AFTER_LINKED_CLOSES')
        review_obj={'paper_exact_exit_replay_v1242':replay,'paired_matchup_v1241':{
            'same_entry_price_time_fee_within_event':True,'available_pair_rows':2,'entry_ready_pairs':1,'committed_s1_rows':1,
            'last_cycle':{'generation_state':'NORMAL'},'practical_contract':{},'exactness':{},'unlimited':{},'practical':{}}}
        text='\n'.join(main._v1237_pair_lines(review_obj))
        self.assertIn('Paper 실제 청산 재생 1단계: 정상 수집',text)
        self.assertIn('과거 poll 없는 거래: 판독불가 유지',text)


    def test_guard_protects_and_exports_replay_ledgers(self):
        text=(ROOT/'backga_guard_bot_v2_5_227.py').read_text(encoding='utf-8')
        self.assertIn('guard_v2.5.227_v1243_bundle_ledger_preflight_repair',text)
        self.assertIn('paper_exit_replay_poll_v1242.jsonl',text)
        self.assertIn('paper_exit_replay_close_v1242.jsonl',text)
        self.assertIn('"exit_replay"',text)

    def test_versions_and_safety(self):
        self.assertEqual(paper.VERSION,'paper_bot_v1.072')
        self.assertEqual(review.VERSION,'review_worker_v1.030')
        self.assertEqual(main.BOT_VERSION,'수익형 v2.13.1152')
        self.assertFalse(review.AUTO_BUY)

if __name__=='__main__': unittest.main()
