import ast, json, tempfile, unittest, hashlib, os, fcntl
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
SRC=(ROOT/'backga_guard_bot_v2_5_227.py').read_text(encoding='utf-8')
TREE=ast.parse(SRC)
NAMES={'_bundle_ledger_event_key_v1238','_bundle_ledger_specs_v1238','_append_packaged_ledger_events_v1238'}
MOD=ast.Module(body=[n for n in TREE.body if isinstance(n,(ast.FunctionDef,ast.AsyncFunctionDef)) and n.name in NAMES],type_ignores=[])
NS={'json':json,'hashlib':hashlib,'os':os,'fcntl':fcntl,'Path':Path}
exec(compile(ast.fix_missing_locations(MOD),'<guard-ledger-functions>','exec'),NS)

class LedgerPreflight(unittest.TestCase):
 def setUp(self):
  self.t=tempfile.TemporaryDirectory(); self.base=Path(self.t.name); self.bundle=self.base/'bundle'; self.bundle.mkdir(); NS['BOT_DIR']=self.base/'live'
 def tearDown(self): self.t.cleanup()
 def manifest(self,second): return {'ledger_event_files':{'issue':['issue.jsonl'],'change_verify':[second]}}
 def test_malformed_later_file_touches_neither_ledger(self):
  (self.bundle/'issue.jsonl').write_text(json.dumps({'issue_id':'I1','ts':'t','status':'OPEN','title':'x'})+'\n')
  (self.bundle/'bad.jsonl').write_text(json.dumps({'event':'PLAN_SHIFT','version':'v'})+'\n')
  ok,notes=NS['_append_packaged_ledger_events_v1238'](self.bundle,self.manifest('bad.jsonl'))
  self.assertFalse(ok); self.assertIn('preflight fail',' '.join(notes))
  self.assertFalse((self.base/'live/issue_ledger.jsonl').exists()); self.assertFalse((self.base/'live/change_verify_ledger.jsonl').exists())
 def test_valid_append_then_duplicate_only(self):
  (self.bundle/'issue.jsonl').write_text(json.dumps({'issue_id':'I1','ts':'t','status':'OPEN','title':'x'})+'\n')
  (self.bundle/'good.jsonl').write_text(json.dumps({'change_id':'C1','event':'VERIFY','version':'v','ts':'t','status':'DONE'})+'\n')
  ok,notes=NS['_append_packaged_ledger_events_v1238'](self.bundle,self.manifest('good.jsonl')); self.assertTrue(ok); self.assertIn('preflight: PASS',' '.join(notes))
  ok,notes=NS['_append_packaged_ledger_events_v1238'](self.bundle,self.manifest('good.jsonl')); self.assertTrue(ok); self.assertGreaterEqual(' '.join(notes).count('duplicate 1'),2)
  self.assertEqual(len((self.base/'live/issue_ledger.jsonl').read_text().splitlines()),1); self.assertEqual(len((self.base/'live/change_verify_ledger.jsonl').read_text().splitlines()),1)

if __name__=='__main__': unittest.main()
