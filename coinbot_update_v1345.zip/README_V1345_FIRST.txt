v1345: material fill first; old observe hard block only when evidence sufficient. Auto-buy OFF. No trigger/invalid/target/RR/exit change.
