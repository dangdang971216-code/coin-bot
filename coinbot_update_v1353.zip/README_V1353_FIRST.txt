v1353: Paper S1 판독 0 원인 진단/정규화 + Strategy body_ratio 최종 wrapper 순서 수리 + Paper after-open 기록 wrapper 재등록. 매매 기준 변경 없음, 자동매수 OFF.
