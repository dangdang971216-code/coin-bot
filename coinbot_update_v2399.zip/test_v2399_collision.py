from __future__ import annotations
import importlib.util, json, os, tempfile, shutil
from pathlib import Path

SRC=Path('/mnt/data/v2399_work/review_worker_v2.168.py')
work=Path(tempfile.mkdtemp(prefix='v2399_collision_'))
os.environ['TRADING_BOT_DIR']=str(work)
spec=importlib.util.spec_from_file_location('review2399_collision',SRC)
review=importlib.util.module_from_spec(spec); spec.loader.exec_module(review)

try:
    external='AAA-1785637800'
    def ev(formula, selection='UP'):
        row={
            'schema':'rise_prediction_ledger_record','record_type':'event',
            'contract_generation':'INFORMATION_CONTRACT_COMPLETE','information_contract_complete':True,
            'event_key':external,'event_ts':1_785_637_800.0,'ticker':'AAA','event_price':100.0,
            'prediction_contract_id':review.CURRENT_PREDICTION_CONTRACT_ID,
            'timeframe_role_formula_id':formula,'timeframe_role_input':{'formula_id':formula},
            'prediction_selection':selection,'material_names':list(review.MATERIAL_NAMES),
            'materials':{},'baseline_decision':{},'structure_contract':{},
        }
        row['review_event_key']=review._review_event_identity(row)
        return row

    old=ev(review.PREVIOUS_TIMEFRAME_ROLE_FORMULA_ID)
    new=ev(review.CURRENT_TIMEFRAME_ROLE_FORMULA_ID)
    assert old['review_event_key'] != new['review_event_key']

    # Same external key, different formula: new event must append, not dedupe.
    review._EVENTS={old['review_event_key']:old}
    review._candidate_rows=lambda snapshot:[{'x':1}]
    review._event_record=lambda row,snapshot:dict(new)
    created,dupes=review.append_new_events({})
    assert (created,dupes)==(1,0), (created,dupes)
    assert len(review._EVENTS)==2

    # Exact same formula is the only duplicate.
    created,dupes=review.append_new_events({})
    assert (created,dupes)==(0,1), (created,dupes)

    # Outcomes are formula-scoped too.
    old_out={'record_type':'outcome','event_key':external,'review_event_key':old['review_event_key'],'horizon':'30m','outcome_state':'READY'}
    new_out={'record_type':'outcome','event_key':external,'review_event_key':new['review_event_key'],'horizon':'30m','outcome_state':'READY'}
    review._OUTCOME_ROWS={(old['review_event_key'],'30m'):old_out,(new['review_event_key'],'30m'):new_out}
    assert review._event_for_outcome(old_out)['timeframe_role_formula_id']==review.PREVIOUS_TIMEFRAME_ROLE_FORMULA_ID
    assert review._event_for_outcome(new_out)['timeframe_role_formula_id']==review.CURRENT_TIMEFRAME_ROLE_FORMULA_ID

    # Restart/load preserves both formula generations without rewriting disk rows.
    ledger=work/'rise_prediction_ledger'/'2026-08-02.jsonl'
    ledger.parent.mkdir(parents=True,exist_ok=True)
    rows=[old,dict(old_out),new,dict(new_out)]
    with ledger.open('w',encoding='utf-8') as f:
        for row in rows:
            f.write(json.dumps(row,ensure_ascii=False)+'\n')
    review._EVENTS.clear(); review._OUTCOMES.clear(); review._OUTCOME_ROWS.clear(); review._STATE_LOADED=False
    review.now_ts=lambda:1_785_638_100.0
    review.load_state_once()
    assert len(review._EVENTS)==2, review._EVENTS.keys()
    assert len(review._OUTCOME_ROWS)==2, review._OUTCOME_ROWS.keys()

    # Current snapshot proof requires the current formula, not an old formula with the same external key.
    current=[e for e in review._EVENTS.values() if review._prediction_contract_id(e)==review.CURRENT_PREDICTION_CONTRACT_ID]
    assert len(current)==1 and current[0]['timeframe_role_formula_id']==review.CURRENT_TIMEFRAME_ROLE_FORMULA_ID
    print('V2399_FORMULA_SCOPED_COLLISION_TEST_PASS')
finally:
    os.environ.pop('TRADING_BOT_DIR',None)
    shutil.rmtree(work,ignore_errors=True)
