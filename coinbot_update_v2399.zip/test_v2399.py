#!/usr/bin/env python3
from __future__ import annotations
import ast, hashlib, importlib.util, os, shutil, subprocess, sys, tempfile, json
from pathlib import Path
ROOT=Path('/mnt/data/v2399_work')
CORE=ROOT/'strategy_v2_core_v2201.py'
STRATEGY=ROOT/'strategy_worker_v2.115.py'
REVIEW=ROOT/'review_worker_v2.168.py'
MAIN=ROOT/'coinbot_main_v2_13_2243.py'
BUILD='review_formula_scoped_event_identity_and_truthful_contract_proof_2026-08-02'

def load(name,path):
    spec=importlib.util.spec_from_file_location(name,path); m=importlib.util.module_from_spec(spec); spec.loader.exec_module(m); return m

def sha(p): return hashlib.sha256(p.read_bytes()).hexdigest()

def candles(now,interval,n,start,growth,vol_growth=.01):
    rows=[]; price=float(start)
    for i in range(n):
        ts=now-(n-i)*interval; op=price; close=price*(1+growth)
        rows.append({'ts':float(ts),'o':op,'c':close,'h':max(op,close)*1.004,'l':min(op,close)*.996,'v':1000*(1+vol_growth*i)})
        price=close
    return rows

for p in (CORE,STRATEGY,REVIEW,MAIN):
    subprocess.run([sys.executable,'-m','py_compile',str(p)],check=True); ast.parse(p.read_text(encoding='utf-8'))

core=load('core2398',CORE)
assert core.VERSION=='strategy_v2_core_v2201'
assert core.TIMEFRAME_ROLE_FORMULA_ID.endswith('V2_ROLE_VOTE')
now=1_700_000_000.0
up={'h1':candles(now,3600,50,100,.003,.02),'h4':candles(now,14400,40,80,.006,.02),'d1':candles(now,86400,30,50,.012,.01)}
btc={'h1':candles(now,3600,50,100,.001,.01),'h4':candles(now,14400,40,80,.002,.01),'d1':candles(now,86400,30,50,.004,.01)}
plain=core.build_timeframe_role_input_from_frames('TEST',up,btc,{},now,current_price=up['h1'][-1]['c'],source_mode='HISTORICAL_COMPLETED')
tagged=core.build_timeframe_role_input_from_frames('TEST',up,btc,{'_sealed_prediction_payload':{'explanation_tags':['CHASE','EXHAUSTION'],'price_volume_sequence':{'state':'PRICE_LEADS'}},'risk_state':'RISK_OFF','context_state':'BEAR'},now,current_price=up['h1'][-1]['c'],source_mode='HISTORICAL_COMPLETED')
for axis in ('1h_timing','4h_structure','24h_context'):
    assert plain['axes'][axis]['probability_pct']==tagged['axes'][axis]['probability_pct']
    assert plain['axes'][axis]['weights_applied'] is False
assert tagged['axes']['1h_timing']['inputs']['legacy_short_path_used_in_decision'] is False
assert tagged['axes']['24h_context']['inputs']['market_signal_used_in_decision'] is False
ev=core.evaluate_timeframe_role_input(plain)
assert ev['decision']=='UP' and ev['weights_applied'] is False and ev['thresholds_applied'] is False
manual=lambda d1,d4,d24: core.evaluate_timeframe_role_input({'axes':{'1h_timing':{'probability_pct':50,'direction':d1},'4h_structure':{'probability_pct':50,'direction':d4},'24h_context':{'probability_pct':50,'direction':d24}},'axis_source_state':{'h1':'READY','h4':'READY','d1':'READY'}})
assert manual('NEGATIVE','NEGATIVE','POSITIVE')['decision']=='DOWN'
assert manual('POSITIVE','POSITIVE','NEGATIVE')['decision']=='HOLD'
assert manual('POSITIVE','POSITIVE','NEUTRAL')['decision']=='UP'

# confidence truth: PARTIAL must never be HIGH
m30=candles(now,1800,80,100,.001,.01)
row={'ticker':'TEST','prediction_benchmark_frames':btc,'prediction_candle_frame_truth':{},'prediction_benchmark_frame_truth':{},'global_market_context_v2130':{}}
payload=core.build_rise_prediction_input(row,{'m30':m30,**up},{},now)
assert payload['weights_applied'] is False and payload['thresholds_applied'] is False
if payload['state']=='PARTIAL': assert payload['prediction_confidence_state']=='MEDIUM'

# Strategy isolated import / summary flags
work=Path(tempfile.mkdtemp(prefix='v2398_strategy_'))
try:
    shutil.copy2(CORE,work/'strategy_v2_core.py'); os.environ['TRADING_BOT_DIR']=str(work)
    strategy=load('strategy2398',STRATEGY)
    assert strategy.VERSION=='strategy_worker_v2.115'
    pld={'state':'PARTIAL','input_coverage_pct':90,'usable_input_coverage_pct':90,'event_key':'E','episode_id':'P','probability_1h_timing':55,'probability_4h_structure':55,'probability_24h_context':50,'combined_probability_pct':None,'prediction_confidence_state':'MEDIUM','prediction_model_id':core.TIMEFRAME_ROLE_FORMULA_ID,'output_states':{},'timeframe_role_evaluation':{'axis_states':{'1h_timing':'POSITIVE','4h_structure':'POSITIVE','24h_context':'NEUTRAL'}},'materials':{},'explanation_tags':['CHASE'],'price_volume_sequence':{'state':'PRICE_LEADS'},'weights_applied':False,'thresholds_applied':False}
    rr={'ticker':'TEST','trade_path_contract_v2149':{'state':'PREDICTION_HOLD','decision_combiner':{'entry_eligible':False},'structure':{'state':'NOT_BUILT_PREDICTION_FIRST'},'prediction':{'rise_prediction_input':pld},'prediction_selection':{'decision':'HOLD'}}}
    summ=strategy._v2176_decision_summary([rr],now)['rise_prediction']
    assert summ['weights_applied'] is False and summ['thresholds_applied'] is False
    assert summ['prediction_confidence_state_counts']['MEDIUM']==1
finally:
    os.environ.pop('TRADING_BOT_DIR',None); shutil.rmtree(work,ignore_errors=True)

# Review fixed answers, full-event metrics, previous-mainline cohort priority, HOLD preserved
work=Path(tempfile.mkdtemp(prefix='v2398_review_'))
try:
    shutil.copy2(CORE,work/'strategy_v2_core.py'); os.environ['TRADING_BOT_DIR']=str(work)
    review=load('review2398',REVIEW)
    assert review.VERSION=='review_worker_v2.168' and review.BUILD_LABEL==BUILD
    ts=2_000_000.0
    def event(k,symbol,old):
        return {'event_key':k,'prediction_contract_id':'PRE_STRUCTURE_1H_4H_24H','timeframe_role_formula_id':review.PREVIOUS_TIMEFRAME_ROLE_FORMULA_ID,'timeframe_role_input':{'formula_id':review.PREVIOUS_TIMEFRAME_ROLE_FORMULA_ID},'prediction_selection':old,'event_ts':ts,'event_price':100,'ticker':symbol,'materials':{}}
    review._EVENTS={'a':event('a','AAA','UP'),'b':event('b','BBB','HOLD'),'c':event('c','CCC','DOWN'),'d':event('d','DDD','UP')}
    # new formula decisions from fake core: a HOLD, b UP, c DOWN, d UP
    class FakeCore:
        TIMEFRAME_ROLE_FORMULA_ID='NEW'
        @staticmethod
        def build_timeframe_role_input_from_frames(symbol,*args,**kwargs): return {'symbol':symbol}
        @staticmethod
        def evaluate_timeframe_role_input(inp): return {'decision':{'AAA':'HOLD','BBB':'UP','CCC':'DOWN','DDD':'UP'}[inp['symbol']],'source_missing_axes':[]}
    review._load_active_strategy_core=lambda:FakeCore
    def outcome(k,net,mfe,touch='NO_TOUCH'):
        return {'event_key':k,'horizon':'1h','outcome_state':'READY','actual_direction':'UP' if net>0 else 'DOWN','raw_actual_direction':'UP' if net>0 else 'DOWN','mfe_pct':mfe,'mae_pct':-.5,'giveback_pct':max(0,mfe-net),'final_return_pct':net+.2,'scoring_cost_pct':.2,'scored_net_return_pct':net,'touch_order':touch}
    review._OUTCOME_ROWS={('a','1h'):outcome('a',1,2,'TARGET_FIRST'),('b','1h'):outcome('b',1,1.5,'NO_TOUCH'),('c','1h'):outcome('c',-1,.1,'INVALID_FIRST'),('d','1h'):outcome('d',-1,.1,'INVALID_FIRST')}
    idx={s:{'h1':candles(ts,3600,20,100,.001),'h4':candles(ts,14400,12,100,.001),'d1':candles(ts,86400,8,100,.001)} for s in ('AAA','BBB','CCC','DDD','BTC')}
    comp=review.build_timeframe_role_replay_comparison(idx)
    assert comp['comparison_source_cohort']=='PREVIOUS_MAINLINE_V1'
    h=comp['horizons']['1h']; strict=h['answer_layers']['contract_target_first']; finish=h['answer_layers']['after_cost_finish']
    assert strict['baseline']['positive_recall_valid'] is False and strict['baseline']['positive_recall_pct'] is None
    assert finish['baseline']['positive_recall_pct']==50.0 and finish['new']['positive_recall_pct']==50.0
    assert h['decision_transition_counts']['UP->HOLD']==1 and h['decision_transition_counts']['HOLD->UP']==1
    score=review._directional_score_summary(review._OUTCOME_ROWS.values(),lambda e:True)
    assert score['six_way_counts']['1h:HOLD_UP']==1
    assert score['accuracy_by_horizon']['1h']['hold_count']==1
finally:
    os.environ.pop('TRADING_BOT_DIR',None); shutil.rmtree(work,ignore_errors=True)

# Main rendering
work=Path(tempfile.mkdtemp(prefix='v2398_main_'))
try:
    shutil.copy2(MAIN,work/MAIN.name); main=load('main2398',work/MAIN.name)
    assert main.MAIN_VERSION=='수익형 v2.13.2243'
    canonical={'timeframe_role_replay_comparison':comp,'current_prediction_contract_directional_scoring':score,'directional_material_comparison':{'horizons':{}},'live_prediction_model_id':'NEW'}
    text='\n'.join(main._mainline_replay_compare_lines(canonical)+main._directional_accuracy_focus_lines(canonical)+main._directional_scoring_lines(canonical))
    for token in ('전체사건 공정 비교','계약이 있던 일부','성공회수 계산에 사용하지 않음','HOLD→상승','정확도 핵심 · 현재 본선 계약'):
        assert token in text, token
finally:
    shutil.rmtree(work,ignore_errors=True)

# untouched services
for name in ('candle_worker.py','paper_bot.py','backga_guard_bot.py'):
    assert (ROOT/name).exists()
print('ALL_V2398_REGRESSION_TESTS_PASS')
