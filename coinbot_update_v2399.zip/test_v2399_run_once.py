from __future__ import annotations
import importlib.util, os, tempfile, shutil
from pathlib import Path

SRC=Path('/mnt/data/v2399_work/review_worker_v2.168.py')
work=Path(tempfile.mkdtemp(prefix='v2399_runonce_'))
os.environ['TRADING_BOT_DIR']=str(work)
spec=importlib.util.spec_from_file_location('review2399_runonce',SRC)
review=importlib.util.module_from_spec(spec); spec.loader.exec_module(review)
try:
    ts=1_785_638_000.0
    external='AAA-1785637800'
    old={
        'record_type':'event','contract_generation':'INFORMATION_CONTRACT_COMPLETE','information_contract_complete':True,
        'event_key':external,'event_ts':ts,'ticker':'AAA','event_price':100.0,
        'prediction_contract_id':review.CURRENT_PREDICTION_CONTRACT_ID,
        'timeframe_role_formula_id':review.PREVIOUS_TIMEFRAME_ROLE_FORMULA_ID,
        'timeframe_role_input':{'formula_id':review.PREVIOUS_TIMEFRAME_ROLE_FORMULA_ID},
        'prediction_selection':'UP','material_names':list(review.MATERIAL_NAMES),'materials':{},
    }
    old['review_event_key']=review._review_event_identity(old)
    review._EVENTS={old['review_event_key']:old}; review._STATE_LOADED=True
    payload={
        'event_key':external,'event_bar_close_ts':ts,'ticker':'AAA','event_price':100.0,
        'prediction_contract_id':review.CURRENT_PREDICTION_CONTRACT_ID,
        'timeframe_role_formula_id':review.CURRENT_TIMEFRAME_ROLE_FORMULA_ID,
        'timeframe_role_input':{'formula_id':review.CURRENT_TIMEFRAME_ROLE_FORMULA_ID},
        'timeframe_role_evaluation':{'decision':'UP','combined_probability_pct':55.0},
        'primary_selection':{'decision':'UP','reason':'TEST'},
        'materials':{},'material_names':list(review.MATERIAL_NAMES),'model_state':'READY',
        'input_coverage_pct':100.0,'usable_input_count':12,'weights_applied':False,'thresholds_applied':False,
    }
    snapshot={'snapshot_id':'S','candidate_commit_id':'C','cycle_id':'Y','rows':[{'ticker':'AAA','rise_prediction_input':payload}]}
    original_load=review.load_json
    review.load_json=lambda path,default: snapshot if path==review.SNAPSHOT else default
    review.candle_index=lambda:({},0)
    review.paper_exact_index=lambda:{}
    review.append_due_outcomes=lambda nowv,index,paper_index:{}
    review.run_daily_maintenance=lambda nowv:{'rotation':{'rolled':0,'raw_files_deleted':0,'terminal_source_missing':0}}
    review.cleanup_old_rise_derived=lambda apply=False:{'removed':0}
    review.now_ts=lambda:ts+10
    status=review.run_once()
    canonical=status['rise_prediction_canonical']
    assert canonical['new_events']==1
    assert canonical['current_prediction_contract_event_count']==1
    assert canonical['current_snapshot_expected_event_count']==1
    assert canonical['review_consumed_event_set_count']==1
    assert canonical['current_snapshot_contract_state']=='PASS'
    assert canonical['current_snapshot_formula_match_required'] is True
    assert canonical['current_snapshot_formula_id']==review.CURRENT_TIMEFRAME_ROLE_FORMULA_ID
    assert len(review._EVENTS)==2
    print('V2399_RUN_ONCE_FORMULA_PROOF_PASS')
finally:
    os.environ.pop('TRADING_BOT_DIR',None)
    shutil.rmtree(work,ignore_errors=True)
