1) /gupgrade_bundle 단독 실행
2) 적용 뒤 /grelease_verify /gledger_v1293
3) 메인봇 /version_score
