#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Bithumb microstructure sidecar for coinbot.

Separate process. It polls Bithumb public orderbook and recent transaction
history for the tickers selected by the main bot. The main bot only reads the
cache files, so REST/API stalls here cannot block tradingbot.service.
"""
from __future__ import annotations

import json
import os
import signal
import time
import traceback
import urllib.parse
import urllib.request
from concurrent.futures import ThreadPoolExecutor, as_completed
from pathlib import Path
from typing import Any, Dict, List, Tuple

BASE_DIR = Path(os.getenv("TRADING_BOT_DIR", "/home/dangdang971216/trading_bot"))
TARGET_FILE = BASE_DIR / "clean_micro_targets.json"
WS_TARGET_FILE = BASE_DIR / "clean_ws_targets.json"
URGENT_TARGET_FILE = BASE_DIR / "clean_micro_urgent_targets.json"
CACHE_FILE = BASE_DIR / "clean_bithumb_micro_cache.json"
STATUS_FILE = BASE_DIR / "clean_bithumb_micro_status.json"
LOG_FILE = BASE_DIR / "clean_bithumb_micro.log"
PID_FILE = BASE_DIR / "clean_bithumb_micro.pid"

VERSION = "bithumb_micro_sidecar_v0.14_v619_urgent_first_normal_keepalive_2026-06-01"
# 전체 target queue는 자르지 않는다. 서버 보호는 고정 ticker 수가 아니라 시간예산/TTL/동시 worker로 처리한다.
TARGET_SAFETY_MAX = "not_cut_full_queue"
POLL_SEC = float(os.getenv("CLEAN_MICRO_POLL_SEC", "2.0"))
URGENT_FAST_SLEEP_SEC = float(os.getenv("CLEAN_MICRO_URGENT_FAST_SLEEP_SEC", "0.5"))
URGENT_RETRY_ROUNDS = int(os.getenv("CLEAN_MICRO_URGENT_RETRY_ROUNDS", "1"))
URGENT_RETRY_BUDGET_SEC = float(os.getenv("CLEAN_MICRO_URGENT_RETRY_BUDGET_SEC", "1.8"))
REQUEST_TIMEOUT = float(os.getenv("CLEAN_MICRO_REQUEST_TIMEOUT_SEC", "0.8"))
STALE_SEC = float(os.getenv("CLEAN_MICRO_STALE_SEC", "20"))
FRESH_REVISIT_SEC = float(os.getenv("CLEAN_MICRO_FRESH_REVISIT_SEC", str(max(8.0, STALE_SEC * 0.55))))
CYCLE_TIME_BUDGET_SEC = float(os.getenv("CLEAN_MICRO_CYCLE_TIME_BUDGET_SEC", "6.0"))
URGENT_BUDGET_RATIO = float(os.getenv("CLEAN_MICRO_URGENT_BUDGET_RATIO", "0.70"))
MIN_NORMAL_BUDGET_SEC = float(os.getenv("CLEAN_MICRO_MIN_NORMAL_BUDGET_SEC", "1.8"))
TARGET_RELOAD_SEC = float(os.getenv("CLEAN_MICRO_TARGET_RELOAD_SEC", "0.8"))
MAX_WORKERS = int(os.getenv("CLEAN_MICRO_WORKERS", "8"))
USER_AGENT = "coinbot-bithumb-micro-sidecar/0.14"
STABLE_EXCLUDED = {"USDC", "USDT", "BUSD", "USDP", "DAI", "TUSD", "FDUSD", "USDS", "USD1", "PYUSD", "USDE", "RLUSD"}
MAJORS = ["BTC", "ETH", "XRP"]

STOP = False
ROTATE = 0
ROWS: Dict[str, Dict[str, Any]] = {}
URGENT_TARGETS: List[str] = []
URGENT_ROTATE = 0
STATS: Dict[str, Any] = {
    "version": VERSION,
    "pid": os.getpid(),
    "state": "init",
    "targets": 0,
    "cached": 0,
    "fresh": 0,
    "orderbook_ok": 0,
    "orderbook_fail": 0,
    "trade_ok": 0,
    "trade_fail": 0,
    "poll_count": 0,
    "last_error": "-",
    "updated_ts": time.time(),
    "target_source": "init",
    "target_file_ts": 0.0,
    "target_reload_count": 0,
}


def now() -> float:
    return time.time()


def log(msg: str) -> None:
    try:
        LOG_FILE.parent.mkdir(parents=True, exist_ok=True)
        with LOG_FILE.open("a", encoding="utf-8") as f:
            f.write(f"[{time.strftime('%Y-%m-%d %H:%M:%S')}] {msg}\n")
    except Exception:
        pass


def atomic_write(path: Path, obj: Any) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    tmp = path.with_suffix(path.suffix + ".tmp")
    tmp.write_text(json.dumps(obj, ensure_ascii=False, indent=2, default=str), encoding="utf-8")
    os.replace(tmp, path)


def fnum(v: Any, default: float = 0.0) -> float:
    try:
        if v is None:
            return default
        if isinstance(v, str):
            v = v.replace(",", "").strip()
            if not v:
                return default
        return float(v)
    except Exception:
        return default


def to_ticker(symbol: Any) -> str:
    s = str(symbol or "").upper().strip().replace('"', '').replace("'", "").replace(" ", "")
    if not s:
        return ""
    if s.startswith("KRW-"):
        s = s.split("-", 1)[1]
    elif s.startswith("KRW_"):
        s = s.split("_", 1)[1]
    elif s.endswith("_KRW"):
        s = s[:-4]
    elif s.endswith("/KRW"):
        s = s[:-4]
    elif "/" in s:
        parts = [x for x in s.split("/") if x]
        if len(parts) == 2:
            s = parts[0] if parts[1] == "KRW" else parts[-1]
    if s.startswith("KRW") and len(s) > 3 and s[3] not in {"-", "_", "/"}:
        s = s[3:]
    return s.strip("-_/ ")


def http_json(url: str, timeout: float = REQUEST_TIMEOUT) -> Any:
    req = urllib.request.Request(url, headers={"User-Agent": USER_AGENT})
    with urllib.request.urlopen(req, timeout=timeout) as resp:
        return json.loads(resp.read().decode("utf-8", errors="ignore"))


def load_targets_from(path: Path) -> Tuple[List[str], str, float]:
    try:
        if not path.exists():
            return [], "missing", 0.0
        obj = json.loads(path.read_text(encoding="utf-8", errors="ignore"))
        raw = obj.get("targets") if isinstance(obj, dict) else obj
        reason = str(obj.get("reason") or path.name) if isinstance(obj, dict) else path.name
        ts = float(obj.get("updated_ts") or path.stat().st_mtime) if isinstance(obj, dict) else path.stat().st_mtime
        out: List[str] = []
        seen = set()
        if isinstance(raw, list):
            for x in raw:
                t = to_ticker(x)
                if t and t not in STABLE_EXCLUDED and t not in seen:
                    seen.add(t)
                    out.append(t)
        return out, reason, ts
    except Exception as exc:
        STATS["last_error"] = f"target {path.name} {exc.__class__.__name__}: {str(exc)[:120]}"
        log(STATS["last_error"])
        return [], "error", 0.0



def load_urgent_targets() -> Tuple[List[str], str, float]:
    try:
        if not URGENT_TARGET_FILE.exists():
            return [], "urgent_missing", 0.0
        obj = json.loads(URGENT_TARGET_FILE.read_text(encoding="utf-8", errors="ignore"))
        if not isinstance(obj, dict):
            return [], "urgent_bad", 0.0
        ts = fnum(obj.get("updated_ts"), URGENT_TARGET_FILE.stat().st_mtime)
        ttl = max(45.0, fnum(obj.get("ttl_sec"), 45.0))
        STATS["urgent_target_ttl_sec"] = ttl
        if now() - ts > ttl:
            return [], "urgent_expired", ts
        raw = obj.get("targets") or []
        out: List[str] = []
        seen = set()
        for x in raw:
            t = to_ticker(x)
            if t and t not in STABLE_EXCLUDED and t not in seen:
                seen.add(t); out.append(t)
        return out, str(obj.get("reason") or "urgent"), ts
    except Exception as exc:
        STATS["last_error"] = f"urgent target {exc.__class__.__name__}: {str(exc)[:120]}"
        log(STATS["last_error"])
        return [], "urgent_error", 0.0


def load_targets() -> List[str]:
    global URGENT_TARGETS
    urgent, urgent_reason, urgent_ts = load_urgent_targets()
    targets, reason, ts = load_targets_from(TARGET_FILE)
    if not targets:
        targets, reason, ts = load_targets_from(WS_TARGET_FILE)
        if targets:
            reason = "ws_targets_fallback:" + reason
    if not targets:
        targets = MAJORS[:]
        reason = "majors_fallback"
        ts = now()
    final: List[str] = []
    seen = set()
    # v0.13: target 파일에 들어온 전체 queue를 보존한다.
    # 뒤쪽 후보를 잘라버리지 않는다. 먼저 볼 대상만 우선순위/TTL/오래 밀린 순서로 정한다.
    # 서버 보호는 고정 ticker 수가 아니라 시간예산/동시 worker/TTL로 처리한다.
    for t in list(urgent or []) + list(targets or []):
        t = to_ticker(t)
        if t and t not in STABLE_EXCLUDED and t not in seen:
            final.append(t)
            seen.add(t)
    URGENT_TARGETS = [t for t in urgent if t in seen]
    STATS["target_source"] = ("urgent:" + urgent_reason + "+" + reason)[:120] if urgent else reason[:120]
    STATS["target_file_ts"] = max(ts, urgent_ts)
    STATS["targets"] = len(final)
    STATS["urgent_targets"] = len(URGENT_TARGETS)
    STATS["urgent_target_file_ts"] = urgent_ts
    STATS["target_safety_max"] = TARGET_SAFETY_MAX
    STATS["target_queue_policy"] = "v0.14/v619 full queue; S2 urgent first; normal lane keepalive never zero"
    return final



def _micro_age(ticker: str, *, ts: float | None = None) -> float:
    """Return seconds since last micro update. Missing rows get a very large age."""
    if ts is None:
        ts = now()
    row = ROWS.get(to_ticker(ticker))
    if not row:
        return 1_000_000.0
    return max(0.0, ts - fnum(row.get("ts") or row.get("updated_ts"), 0))


def _priority_plan(clean: List[str], *, urgent_set: set[str], source: str) -> List[str]:
    """v0.13: 고정 N개가 아니라 priority/TTL/age/rotation으로 전체 queue 순서를 만든다.

    이 함수는 target을 자르지 않는다. 실제 API 보호는 poll_budgeted()의 시간예산과 MAX_WORKERS가 담당한다.
    """
    global ROTATE
    if not clean:
        return []
    ts = now()
    rotate_start = ROTATE % len(clean)
    rotated = clean[rotate_start:] + clean[:rotate_start]

    scored: List[Tuple[float, int, str, float]] = []
    missing = stale = revisit = fresh = urgent_count = 0
    oldest_age = 0.0
    for pos, t in enumerate(rotated):
        age = _micro_age(t, ts=ts)
        is_missing = age >= 999_000
        is_urgent = t in urgent_set
        if is_urgent:
            urgent_count += 1
        if is_missing:
            missing += 1
            score = 900.0
        elif age > STALE_SEC:
            stale += 1
            score = 650.0 + min(250.0, age / max(1.0, STALE_SEC) * 25.0)
        elif age >= FRESH_REVISIT_SEC:
            revisit += 1
            score = 250.0 + min(120.0, age / max(1.0, FRESH_REVISIT_SEC) * 30.0)
        else:
            fresh += 1
            score = 20.0 + min(80.0, age / max(1.0, FRESH_REVISIT_SEC) * 20.0)
        if is_urgent:
            score += 700.0
        # stable sort tie-break: rotation 앞쪽을 살짝 우선해서 오래 뒤에 밀린 후보도 계속 돈다.
        scored.append((score, -pos, t, age))
        if not is_missing:
            oldest_age = max(oldest_age, age)

    scored.sort(reverse=True)
    plan = [t for _score, _pos, t, _age in scored]
    prefix = "urgent" if source == "urgent" else "normal"
    STATS[f"{prefix}_plan"] = len(plan)
    STATS[f"{prefix}_missing"] = missing
    STATS[f"{prefix}_stale"] = stale
    STATS[f"{prefix}_revisit_due"] = revisit
    STATS[f"{prefix}_fresh"] = fresh
    STATS[f"{prefix}_urgent_in_plan"] = urgent_count
    STATS[f"{prefix}_oldest_age"] = round(oldest_age, 1)
    STATS[f"{prefix}_policy"] = "priority_ttl_age_rotation_no_fixed_count"
    return plan


def select_poll_batch(targets: List[str], *, include_urgent: bool = False) -> List[str]:
    """호환용 이름 유지. 실제로는 batch cap 없이 normal priority plan을 만든다."""
    clean: List[str] = []
    seen = set()
    urgent_set = set(URGENT_TARGETS)
    for t in targets or []:
        tt = to_ticker(t)
        if tt and tt not in STABLE_EXCLUDED and tt not in seen:
            if include_urgent or tt not in urgent_set:
                seen.add(tt)
                clean.append(tt)
    if not clean:
        STATS.update({"poll_plan": 0, "poll_batch": 0, "normal_plan": 0, "normal_deferred": 0})
        return []
    plan = _priority_plan(clean, urgent_set=urgent_set, source="normal")
    STATS["poll_plan"] = len(plan)
    STATS["poll_batch"] = len(plan)  # 구 상태판 호환용: 실제 수집 수가 아니라 계획 수
    STATS["poll_policy"] = "v0.13/v617 full queue; no fixed ticker cap; CPU-guarded time-budgeted priority/TTL/age rotation"
    return plan


def poll_budgeted(plan: List[str], *, label: str, budget_sec: float) -> Tuple[int, float]:
    """Poll as many planned tickers as fit into a time budget.

    target 수로 자르지 않고, 동시 worker chunk를 반복하며 시간예산이 끝나면 다음 cycle로 넘긴다.
    """
    if not plan:
        STATS[f"{label}_done"] = 0
        STATS[f"{label}_deferred"] = 0
        STATS[f"{label}_budget_sec"] = round(max(0.0, budget_sec), 2)
        return 0, 0.0
    budget_sec = max(0.0, float(budget_sec or 0.0))
    t0 = now()
    done = 0
    idx = 0
    chunk_size = max(1, MAX_WORKERS)
    while idx < len(plan) and not STOP:
        if budget_sec > 0 and now() - t0 >= budget_sec:
            break
        chunk = plan[idx:idx + chunk_size]
        if not chunk:
            break
        got, _elapsed = poll_many(chunk, label=label)
        done += got
        idx += len(chunk)
    elapsed = now() - t0
    STATS[f"{label}_done"] = done
    STATS[f"{label}_deferred"] = max(0, len(plan) - idx)
    STATS[f"{label}_budget_sec"] = round(budget_sec, 2)
    STATS[f"{label}_elapsed"] = round(elapsed, 3)
    STATS[f"{label}_plan_symbols"] = plan[:12]
    return done, elapsed


def parse_orderbook(ticker: str) -> Dict[str, Any]:
    urls = [
        f"https://api.bithumb.com/public/orderbook/{urllib.parse.quote(ticker)}_KRW?count=5",
        f"https://api.bithumb.com/public/orderbook/{urllib.parse.quote(ticker)}/KRW?count=5",
    ]
    last_err = ""
    for url in urls:
        try:
            data = http_json(url)
            if not isinstance(data, dict) or str(data.get("status")) != "0000":
                last_err = f"status={data.get('status') if isinstance(data, dict) else '?'}"
                continue
            book = data.get("data") or {}
            bids = book.get("bids") or []
            asks = book.get("asks") or []
            if not bids or not asks:
                last_err = "empty book"
                continue
            bid1 = fnum((bids[0] or {}).get("price"), 0)
            ask1 = fnum((asks[0] or {}).get("price"), 0)
            mid = (bid1 + ask1) / 2 if bid1 > 0 and ask1 > 0 else 0.0
            spread = ((ask1 - bid1) / mid) * 100 if mid > 0 and ask1 >= bid1 else 999.0
            bid_wall = 0.0
            ask_wall = 0.0
            for r in bids[:5]:
                p = fnum((r or {}).get("price"), 0)
                q = fnum((r or {}).get("quantity") or (r or {}).get("qty"), 0)
                bid_wall += p * q
            for r in asks[:5]:
                p = fnum((r or {}).get("price"), 0)
                q = fnum((r or {}).get("quantity") or (r or {}).get("qty"), 0)
                ask_wall += p * q
            ratio = bid_wall / ask_wall if ask_wall > 0 else (9.99 if bid_wall > 0 else 0.0)
            return {
                "orderbook_ok": True,
                "best_bid": bid1,
                "best_ask": ask1,
                "micro_mid_price": mid,
                "micro_spread_pct": round(spread, 4) if spread < 900 else 999.0,
                "bid_wall_5_krw": round(bid_wall, 2),
                "ask_wall_5_krw": round(ask_wall, 2),
                "bid_ask_wall_ratio": round(ratio, 4),
                "ask_wall_pressure": bool(ask_wall > bid_wall * 1.5 and ask_wall > 3_000_000),
            }
        except Exception as exc:
            last_err = f"{exc.__class__.__name__}: {str(exc)[:100]}"
    return {"orderbook_ok": False, "orderbook_error": last_err or "unknown"}


def _trade_side(row: Dict[str, Any]) -> str:
    raw = str(row.get("type") or row.get("buySellGb") or row.get("ask_bid") or row.get("side") or "").lower()
    # Bithumb transaction_history has used bid/ask labels in multiple wrappers.
    if "bid" in raw or "buy" in raw or raw in {"1", "b"}:
        return "buy"
    if "ask" in raw or "sell" in raw or raw in {"2", "s"}:
        return "sell"
    return "unknown"


def parse_trades(ticker: str) -> Dict[str, Any]:
    urls = [
        f"https://api.bithumb.com/public/transaction_history/{urllib.parse.quote(ticker)}_KRW?count=30",
        f"https://api.bithumb.com/public/transaction_history/{urllib.parse.quote(ticker)}/KRW?count=30",
    ]
    last_err = ""
    for url in urls:
        try:
            data = http_json(url)
            if not isinstance(data, dict) or str(data.get("status")) != "0000":
                last_err = f"status={data.get('status') if isinstance(data, dict) else '?'}"
                continue
            arr = data.get("data") or []
            if isinstance(arr, dict):
                arr = arr.get("list") or arr.get("data") or []
            if not isinstance(arr, list):
                last_err = "bad data"
                continue
            buy = sell = unk = 0.0
            cnt = 0
            last_side = "unknown"
            for row in arr[:30]:
                if not isinstance(row, dict):
                    continue
                price = fnum(row.get("price") or row.get("contPrice") or row.get("trade_price"), 0)
                qty = fnum(row.get("units_traded") or row.get("quantity") or row.get("contQty") or row.get("qty"), 0)
                total = fnum(row.get("total") or row.get("contAmt") or row.get("value"), price * qty if price > 0 and qty > 0 else 0)
                side = _trade_side(row)
                if side == "buy":
                    buy += total
                elif side == "sell":
                    sell += total
                else:
                    unk += total
                if side != "unknown":
                    last_side = side
                cnt += 1
            denom = buy + sell
            buy_ratio = buy / denom if denom > 0 else 0.0
            return {
                "trade_ok": True,
                "trade_buy_krw_30": round(buy, 2),
                "trade_sell_krw_30": round(sell, 2),
                "trade_unknown_krw_30": round(unk, 2),
                "trade_buy_ratio_30": round(buy_ratio, 4),
                "trade_count_30": cnt,
                "last_trade_side": last_side,
                "sell_trade_pressure": bool(denom > 0 and buy_ratio < 0.42 and sell > buy * 1.25),
            }
        except Exception as exc:
            last_err = f"{exc.__class__.__name__}: {str(exc)[:100]}"
    return {"trade_ok": False, "trade_error": last_err or "unknown"}


def poll_one(ticker: str) -> Dict[str, Any]:
    t = to_ticker(ticker)
    ts = now()
    row: Dict[str, Any] = {"ticker": t, "ts": ts, "updated_ts": ts}
    ob = parse_orderbook(t)
    tr = parse_trades(t)
    row.update(ob)
    row.update(tr)
    flags: List[str] = []
    if not ob.get("orderbook_ok"):
        flags.append("호가정보없음")
    if not tr.get("trade_ok"):
        flags.append("체결정보없음")
    if fnum(row.get("micro_spread_pct"), 999) >= 0.45 and fnum(row.get("micro_spread_pct"), 999) < 900:
        flags.append("스프레드주의")
    if bool(row.get("ask_wall_pressure")):
        flags.append("매도벽두꺼움")
    if bool(row.get("sell_trade_pressure")):
        flags.append("매도체결우세")
    if fnum(row.get("trade_buy_ratio_30"), 0) >= 0.58:
        flags.append("매수체결우세")
    if not flags:
        flags.append("미세구조보통")
    row["micro_flags"] = flags[:6]
    if ob.get("orderbook_ok"):
        STATS["orderbook_ok"] = int(STATS.get("orderbook_ok", 0)) + 1
    else:
        STATS["orderbook_fail"] = int(STATS.get("orderbook_fail", 0)) + 1
    if tr.get("trade_ok"):
        STATS["trade_ok"] = int(STATS.get("trade_ok", 0)) + 1
    else:
        STATS["trade_fail"] = int(STATS.get("trade_fail", 0)) + 1
    return row


def write_status(state: str | None = None, error: str | None = None) -> None:
    if state is not None:
        STATS["state"] = state
    if error is not None:
        STATS["last_error"] = error[:240]
    ts = now()
    fresh = sum(1 for r in ROWS.values() if ts - fnum(r.get("ts"), 0) <= STALE_SEC)
    urgent_fresh = sum(1 for t in URGENT_TARGETS if t in ROWS and ts - fnum(ROWS.get(t, {}).get("ts"), 0) <= STALE_SEC)
    urgent_cached = sum(1 for t in URGENT_TARGETS if t in ROWS)
    STATS.update({"pid": os.getpid(), "updated_ts": ts, "cached": len(ROWS), "fresh": fresh, "urgent_fresh": urgent_fresh, "urgent_cached": urgent_cached, "urgent_stale_or_missing": max(0, len(URGENT_TARGETS)-urgent_fresh)})
    try:
        atomic_write(STATUS_FILE, STATS)
    except Exception:
        pass


def write_cache() -> None:
    try:
        atomic_write(CACHE_FILE, {"version": VERSION, "updated_ts": now(), "rows": ROWS, "stats": STATS})
    except Exception as exc:
        log(f"cache write error: {exc}")


def handle_signal(signum, frame) -> None:  # type: ignore[no-untyped-def]
    global STOP
    STOP = True
    write_status("종료요청", f"signal {signum}")


def poll_many(batch: List[str], *, label: str) -> Tuple[int, float]:
    """Poll a batch and update ROWS.

    v0.9 uses this for the urgent fast-lane before the normal rotation.
    It is not a fallback path; it is the single polling helper used by both paths.
    """
    if not batch:
        return 0, 0.0
    t0 = now()
    done = 0
    with ThreadPoolExecutor(max_workers=max(1, min(MAX_WORKERS, len(batch)))) as ex:
        futs = {ex.submit(poll_one, t): t for t in batch}
        for fut in as_completed(futs):
            try:
                row = fut.result()
                t = to_ticker(row.get("ticker"))
                if t:
                    ROWS[t] = row
                    done += 1
            except Exception as exc:
                STATS["last_error"] = f"{label} poll {futs.get(fut)} {exc.__class__.__name__}: {str(exc)[:100]}"
                log(STATS["last_error"])
    return done, now() - t0


def urgent_status_snapshot() -> Dict[str, Any]:
    ts = now()
    urgent = list(dict.fromkeys([to_ticker(t) for t in URGENT_TARGETS if to_ticker(t)]))
    fresh_syms = []
    stale_syms = []
    missing_syms = []
    for t in urgent:
        row = ROWS.get(t)
        if not row:
            missing_syms.append(t)
            continue
        age = ts - fnum(row.get("ts") or row.get("updated_ts"), 0)
        if age <= STALE_SEC:
            fresh_syms.append(t)
        else:
            stale_syms.append(t)
    return {
        "urgent_targets": len(urgent),
        "urgent_fresh": len(fresh_syms),
        "urgent_stale": len(stale_syms),
        "urgent_missing": len(missing_syms),
        "urgent_fresh_sample": fresh_syms[:8],
        "urgent_stale_sample": stale_syms[:8],
        "urgent_missing_sample": missing_syms[:8],
        "urgent_deferred": int(STATS.get("urgent_deferred", 0) or 0),
        "urgent_rotate_pos": int(STATS.get("urgent_rotate_pos", 0) or 0),
        "urgent_budget_sec": fnum(STATS.get("urgent_budget_sec"), 0.0),
        "urgent_policy": STATS.get("urgent_policy", "priority_ttl_age_rotation_no_fixed_count"),
    }



def select_urgent_batch() -> List[str]:
    """urgent 대상도 고정 개수로 자르지 않고 priority/TTL/age plan으로 만든다."""
    clean = list(dict.fromkeys([to_ticker(t) for t in URGENT_TARGETS if to_ticker(t)]))
    clean = [t for t in clean if t and t not in STABLE_EXCLUDED]
    if not clean:
        STATS["urgent_plan"] = 0
        STATS["urgent_deferred"] = 0
        return []
    urgent_set = set(clean)
    plan = _priority_plan(clean, urgent_set=urgent_set, source="urgent")
    STATS["urgent_plan"] = len(plan)
    STATS["urgent_policy"] = "priority_ttl_age_rotation_no_fixed_count"
    return plan


def select_urgent_stale_batch() -> List[str]:
    """v616: S2/S1근접 urgent 중 아직 stale/missing인 대상만 다시 뽑는다.

    전체 456개 순환을 건드리지 않고, 이미 target_router가 urgent로 확정한 대상만
    짧은 재시도 lane에 태운다. 조건/S등급/청산은 바꾸지 않는다.
    """
    clean = list(dict.fromkeys([to_ticker(t) for t in URGENT_TARGETS if to_ticker(t)]))
    clean = [t for t in clean if t and t not in STABLE_EXCLUDED]
    pending = [t for t in clean if _micro_age(t) > STALE_SEC]
    if not pending:
        STATS["urgent_retry_plan"] = 0
        return []
    plan = _priority_plan(pending, urgent_set=set(pending), source="urgent_retry")
    STATS["urgent_retry_plan"] = len(plan)
    STATS["urgent_retry_symbols"] = plan[:20]
    STATS["urgent_retry_policy"] = "v619_stale_or_missing_urgent_retry_lane_normal_keepalive"
    return plan

def poll_loop() -> None:
    global ROTATE
    targets = load_targets()
    last_target_load = 0.0
    write_status("시작", "-")
    log(f"{VERSION} started pid={os.getpid()}")
    while not STOP:
        try:
            if now() - last_target_load >= TARGET_RELOAD_SEC:
                targets = load_targets()
                last_target_load = now()
                STATS["target_reload_count"] = int(STATS.get("target_reload_count", 0)) + 1
            if not targets:
                write_status("대상없음", "targets empty")
                time.sleep(POLL_SEC)
                continue
            # v0.13: urgent도 고정 개수로 자르지 않는다.
            # 우선순위 plan을 만들고, 실제 API 보호는 시간예산/동시 worker로 처리한다.
            cycle_budget = max(0.8, CYCLE_TIME_BUDGET_SEC)
            urgent_budget = 0.0
            if URGENT_TARGETS:
                # v0.14: S2 승격용 urgent가 있으면 한 chunk만 보고 끝내지 않는다.
                # 전체 target은 유지하되, urgent pending 동안은 시간예산을 urgent lane에 몰아준다.
                urgent_budget = max(3.0, cycle_budget * max(0.10, min(0.95, URGENT_BUDGET_RATIO)))
            normal_budget = max(MIN_NORMAL_BUDGET_SEC, cycle_budget - urgent_budget)
            # v619: urgent가 있어도 일반 456개 순환을 0으로 만들지 않는다.
            # 후보폭은 strategy가 판단해야 하며, micro는 urgent 우선 + normal keepalive를 동시에 유지한다.
            if URGENT_TARGETS:
                normal_budget = max(MIN_NORMAL_BUDGET_SEC, normal_budget)

            urgent_batch = select_urgent_batch()
            urgent_done = 0
            urgent_elapsed = 0.0
            if urgent_batch:
                write_status("긴급수집중", "-")
                urgent_done, urgent_elapsed = poll_budgeted(urgent_batch, label="urgent", budget_sec=urgent_budget)
                STATS["urgent_poll_count"] = int(STATS.get("urgent_poll_count", 0)) + 1
                STATS["urgent_last_poll_ts"] = now()
                STATS["urgent_last_done"] = urgent_done
                STATS["urgent_last_elapsed"] = round(urgent_elapsed, 3)
                STATS["urgent_plan_symbols"] = urgent_batch[:20]
                STATS["v014_urgent_burst"] = True
                STATS["v014_urgent_batch_size"] = len(urgent_batch)
                write_cache()
                STATS.update(urgent_status_snapshot())
                STATS["v014_urgent_fresh_after"] = STATS.get("urgent_fresh", 0)
                STATS["v014_urgent_stale_after"] = STATS.get("urgent_stale", 0)
                STATS["v014_urgent_missing_after"] = STATS.get("urgent_missing", 0)

                # v616: target_router가 확정한 urgent가 전체 456개 순환에 묻히지 않도록
                # stale/missing urgent만 짧게 재시도한다. 새 후보를 만들거나 조건을 바꾸지 않는다.
                retry_total_done = 0
                retry_rounds_done = 0
                for retry_idx in range(max(0, URGENT_RETRY_ROUNDS)):
                    STATS.update(urgent_status_snapshot())
                    retry_batch = select_urgent_stale_batch()
                    if not retry_batch:
                        break
                    retry_rounds_done += 1
                    got, elapsed_retry = poll_budgeted(retry_batch, label=f"urgent_retry_{retry_idx+1}", budget_sec=URGENT_RETRY_BUDGET_SEC)
                    retry_total_done += got
                    STATS[f"urgent_retry_{retry_idx+1}_elapsed"] = round(elapsed_retry, 3)
                    write_cache()
                    STATS.update(urgent_status_snapshot())
                    if int(STATS.get("urgent_stale", 0) or 0) + int(STATS.get("urgent_missing", 0) or 0) <= 0:
                        break
                STATS["v616_urgent_retry_rounds"] = retry_rounds_done
                STATS["v616_urgent_retry_done"] = retry_total_done
                STATS["v616_urgent_fresh_after_retry"] = STATS.get("urgent_fresh", 0)
                STATS["v616_urgent_stale_after_retry"] = STATS.get("urgent_stale", 0)
                STATS["v616_urgent_missing_after_retry"] = STATS.get("urgent_missing", 0)
                write_status("긴급수집완료", "-")

            # v619: v617/v618의 normal lane pause를 제거한다.
            # urgent fresh 회복은 먼저 처리하되, 일반 456개 순환은 최소 시간예산으로 계속 유지한다.
            # 후보폭 축소를 막기 위한 수술이며 조건/S등급/청산은 건드리지 않는다.
            urgent_pending_after = int(STATS.get("urgent_stale", 0) or 0) + int(STATS.get("urgent_missing", 0) or 0)
            STATS["v619_normal_lane_keepalive"] = True
            STATS["v619_normal_keepalive_reason"] = f"urgent_pending_{urgent_pending_after}" if URGENT_TARGETS and urgent_pending_after > 0 else "normal"
            STATS["v617_normal_lane_paused"] = False
            STATS["v617_normal_pause_reason"] = "removed_by_v619"
            STATS["normal_deferred_by_urgent"] = 0
            batch = select_poll_batch(targets, include_urgent=False)
            if not batch and not urgent_batch:
                write_status("대상없음", "targets empty after batch select")
                time.sleep(POLL_SEC)
                continue
            if batch:
                write_status("수집중", "-")
                normal_done, normal_elapsed = poll_budgeted(batch, label="normal", budget_sec=normal_budget)
                STATS["normal_last_done"] = normal_done
                STATS["normal_last_elapsed"] = round(normal_elapsed, 3)
                STATS["normal_budget_sec"] = round(normal_budget, 3)
                STATS["normal_plan"] = len(batch)
                STATS["normal_plan_symbols"] = batch[:20]
            else:
                normal_done = 0
                normal_elapsed = 0.0
                STATS["normal_last_done"] = 0
                STATS["normal_last_elapsed"] = 0.0
                STATS["normal_budget_sec"] = round(normal_budget, 3)
                STATS["normal_plan"] = 0
            if targets:
                ROTATE = (ROTATE + max(1, int(STATS.get("normal_done", 0) or 0))) % max(1, len(targets))
            STATS["cycle_time_budget_sec"] = round(cycle_budget, 2)
            STATS["v617_cpu_guard"] = False
            STATS["v619_policy"] = "urgent first; normal full-queue keepalive never zero; conditions unchanged"
            STATS["poll_count"] = int(STATS.get("poll_count", 0)) + 1
            STATS.update(urgent_status_snapshot())
            write_cache()
            write_status("수집중", "-")
        except Exception as exc:
            err = f"{exc.__class__.__name__}: {str(exc)[:160]}"
            write_status("재시도대기", err)
            log("loop error: " + err)
            try:
                log(traceback.format_exc())
            except Exception:
                pass
        sleep_sec = max(1.0, POLL_SEC)
        try:
            if URGENT_TARGETS and int(STATS.get("urgent_stale", 0)) + int(STATS.get("urgent_missing", 0)) > 0:
                sleep_sec = max(0.7, min(sleep_sec, URGENT_FAST_SLEEP_SEC))
        except Exception:
            pass
        time.sleep(sleep_sec)
    write_cache()
    write_status("종료", "-")
    log(f"{VERSION} stopped")



# v1401 identity unification override (no trading-rule changes)
VERSION = 'bithumb_micro_sidecar_v2.000'
BUILD_LABEL = 'v2000_candidate_hot_path_reset_direct_s1_latest_execution_autobuy_off_2026-07-14'
MAIN_DEPLOY_VERSION = 'v2000_candidate_hot_path_reset_direct_s1_latest_execution_autobuy_off_2026-07-14'

if __name__ == "__main__":
    signal.signal(signal.SIGTERM, handle_signal)
    signal.signal(signal.SIGINT, handle_signal)
    try:
        PID_FILE.write_text(str(os.getpid()), encoding="utf-8")
    except Exception:
        pass
    poll_loop()
