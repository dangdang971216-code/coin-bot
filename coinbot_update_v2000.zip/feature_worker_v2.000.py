#!/usr/bin/env python3
# -*- coding: utf-8 -*-

from __future__ import annotations
import json, os, time, math, traceback, urllib.request
from pathlib import Path
from typing import Any, Dict, List, Tuple, Optional
BASE_DIR = Path(os.getenv("TRADING_BOT_DIR", "/home/dangdang971216/trading_bot"))
def now_ts() -> float: return time.time()
def now_text(ts: Optional[float]=None) -> str: return time.strftime("%Y-%m-%d %H:%M:%S", time.localtime(ts or now_ts()))
def fnum(*vals: Any, default: float=0.0) -> float:
    for v in vals:
        try:
            if v is None or v == "": continue
            return float(str(v).replace(",", "").replace("%", ""))
        except Exception: continue
    return default
def load_json(path: Path, default: Any=None) -> Any:
    try:
        if not path.exists(): return default
        return json.loads(path.read_text(encoding="utf-8", errors="ignore"))
    except Exception: return default
def save_json(path: Path, obj: Any) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    tmp = path.with_suffix(path.suffix + ".tmp")
    tmp.write_text(json.dumps(obj, ensure_ascii=False, separators=(",", ":"), default=str), encoding="utf-8")
    os.replace(tmp, path)
def append_jsonl(path: Path, obj: Dict[str, Any]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("a", encoding="utf-8") as f:
        f.write(json.dumps(obj, ensure_ascii=False, separators=(",", ":"), default=str)+"\n")
def write_jsonl_atomic(path: Path, rows: List[Dict[str, Any]]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    tmp = path.with_suffix(path.suffix + ".tmp")
    with tmp.open("w", encoding="utf-8") as f:
        for r in rows:
            f.write(json.dumps(r, ensure_ascii=False, separators=(",", ":"), default=str)+"\n")
    os.replace(tmp, path)
def read_jsonl(path: Path, max_lines: int=1000) -> List[Dict[str, Any]]:
    if not path.exists(): return []
    try:
        lines = path.read_text(encoding="utf-8", errors="ignore").splitlines()
        if max_lines and len(lines) > max_lines: lines = lines[-max_lines:]
        out=[]
        for ln in lines:
            try:
                if ln.strip():
                    o=json.loads(ln)
                    if isinstance(o,dict): out.append(o)
            except Exception: pass
        return out
    except Exception: return []
def append_error(path: Path, where: str, exc: BaseException) -> None:
    try:
        path.parent.mkdir(parents=True, exist_ok=True)
        with path.open("a", encoding="utf-8") as f:
            f.write(f"[{now_text()}] {where}: {exc.__class__.__name__}: {exc}\n")
            f.write(traceback.format_exc()[-1500:]+"\n")
    except Exception: pass
def ticker_norm(x: Any) -> str:
    t = str(x or "").strip().upper().replace("/", "-").replace("_", "-")
    parts=[p for p in t.split("-") if p]
    if len(parts)>=2:
        non=[p for p in parts if p != "KRW"]
        t = non[-1] if non else parts[-1]
    if t.endswith("KRW") and len(t)>3: t=t[:-3]
    return t.strip().upper()
def pct(a: float, b: float) -> float: return ((a-b)/b*100.0) if b else 0.0
def age_sec(path: Path) -> float:
    try: return max(0.0, now_ts()-path.stat().st_mtime)
    except Exception: return 999999.0
def map_rows(obj: Any) -> Dict[str, Dict[str, Any]]:
    if isinstance(obj, dict) and isinstance(obj.get("rows"), list): obj = obj.get("rows")
    elif isinstance(obj, dict) and isinstance(obj.get("rows"), dict): obj = obj.get("rows")
    elif isinstance(obj, dict) and isinstance(obj.get("cache"), dict): obj = obj.get("cache")
    out: Dict[str, Dict[str, Any]] = {}
    if isinstance(obj, list):
        for r in obj:
            if isinstance(r, dict):
                t=ticker_norm(r.get("ticker") or r.get("symbol") or r.get("market"))
                if t: out[t]=r
    elif isinstance(obj, dict):
        for k,v in obj.items():
            t=ticker_norm(k)
            if t and isinstance(v, dict):
                vv=dict(v); vv.setdefault("ticker", t); out[t]=vv
    return out

VERSION="feature_worker_v0.6"
INTERVAL_SEC=float(os.getenv("FEATURE_WORKER_INTERVAL_SEC","2.0"))
STATUS=BASE_DIR/"clean_feature_status.json"; OUT=BASE_DIR/"clean_feature_cache.json"; ERROR=BASE_DIR/"clean_feature_error.log"
SCANNER=BASE_DIR/"clean_scanner_candidate_pool.json"; CANDLE=BASE_DIR/"clean_candle_cache.json"; REGIME=BASE_DIR/"clean_market_regime_cache.json"; HOT=BASE_DIR/"clean_scanner_hot_rank_cache.json"

def _known_num(obj: Dict[str, Any], key: str) -> tuple[Optional[float], bool]:
    if not isinstance(obj, dict) or key not in obj or obj.get(key) in (None, ""):
        return None, False
    try:
        return float(str(obj.get(key)).replace(",", "").replace("%", "")), True
    except Exception:
        return None, False

def _flow_value(ticker: str, hot: Dict[str, Any], candle: Dict[str, Any], hot_key: str, candle_key: str, hot_src_key: str) -> tuple[Optional[float], bool, str]:
    hv, hk = _known_num(hot, hot_key)
    if hk:
        return hv, True, str(hot.get(hot_src_key) or "scanner_hot_rank")
    cv, ck = _known_num(candle, candle_key)
    if ck:
        return cv, True, "candle_worker"
    return None, False, "missing_no_fallback"



def _cross_section_percentile(rows: list[dict[str, Any]], key: str, out_key: str) -> int:
    pairs=[]
    for idx,row in enumerate(rows):
        value=row.get(key)
        if value is None:
            continue
        try:
            pairs.append((float(value),idx))
        except Exception:
            continue
    pairs.sort(key=lambda x:x[0])
    n=len(pairs)
    if not n:
        return 0
    for rank,(value,idx) in enumerate(pairs):
        pct=100.0 if n==1 else (rank/(n-1))*100.0
        rows[idx][out_key]=round(pct,3)
    return n

def _quality_component_value(row: Dict[str, Any], *keys: str) -> Optional[float]:
    for key in keys:
        if key not in row or row.get(key) in (None, ''):
            continue
        try:
            return float(row.get(key))
        except Exception:
            continue
    return None

def write_status(state:str, **extra:Any)->None: save_json(STATUS,{"version":VERSION,"state":state,"pid":os.getpid(),"updated_ts":now_ts(),"updated_text":now_text(),**extra})
def run_once()->Dict[str,Any]:
    st=now_ts(); sobj=load_json(SCANNER,{}) or {}; srows=sobj.get("rows") if isinstance(sobj,dict) else []
    if not isinstance(srows,list): srows=[]
    crows=map_rows(load_json(CANDLE,{}) or {}); hrows=map_rows(load_json(HOT,{}) or {}); reg=load_json(REGIME,{}) or {}; rows=[]; ts=now_ts()
    known_1m=known_3m=missing_1m=missing_3m=hot_used=0
    for r in srows:
        if not isinstance(r,dict): continue
        t=ticker_norm(r.get("ticker")); price=fnum(r.get("current_price"),default=0)
        if not t or price<=0: continue
        c=crows.get(t,{})
        h={**hrows.get(t,{}), **{k:r.get(k) for k in ("scanner_change_1m_pct","scanner_change_3m_pct","scanner_change_1m_source","scanner_change_3m_source","scanner_hot_rank_1m","scanner_hot_rank_3m","scanner_hot_observed_1m_sec","scanner_hot_observed_3m_sec") if k in r}}
        ch1, ch1_known, ch1_src = _flow_value(t, h, c, "scanner_change_1m_pct", "m1_candle_change_1", "scanner_change_1m_source")
        ch3, ch3_known, ch3_src = _flow_value(t, h, c, "scanner_change_3m_pct", "m3_candle_change_3", "scanner_change_3m_source")
        ch5, ch5_known, ch5_src = _flow_value(t, {}, c, "", "m5_candle_change_5", "")
        ch15, ch15_known, ch15_src = _flow_value(t, {}, c, "", "m5_candle_change_3", "")
        ch30, ch30_known, ch30_src = _flow_value(t, {}, c, "", "m30_candle_change_3", "")
        if ch1_known: known_1m += 1
        else: missing_1m += 1
        if ch3_known: known_3m += 1
        else: missing_3m += 1
        if str(ch1_src).startswith("scanner_price_history") or str(ch3_src).startswith("scanner_price_history"):
            hot_used += 1
        ch1_calc = ch1 if ch1 is not None else 0.0
        ch3_calc = ch3 if ch3 is not None else 0.0
        ch5_calc = ch5 if ch5 is not None else 0.0
        official_vwap_gap, official_vwap_ok = _known_num(c, "m5_vwap_gap_pct")
        official_ema5_gap, official_ema5_ok = _known_num(c, "m5_ema5_gap_pct")
        vwap_gap = official_vwap_gap if official_vwap_ok else fnum(c.get("m5_recent_low_rebound_pct"), default=fnum(r.get("day_pos_pct"))-50.0)/10.0
        ema5_gap = official_ema5_gap if official_ema5_ok else ch3_calc*0.45+ch5_calc*0.25
        day_pos=fnum(r.get("day_pos_pct"),default=50)
        change24, change24_known = _known_num(r, "change_24h")
        regime_avg, regime_avg_known = _known_num(reg if isinstance(reg,dict) else {}, "avg_top60_change")
        rel = (change24-regime_avg) if change24_known and regime_avg_known else None
        candle_ts=fnum(c.get("candle_ts"), default=0.0)
        official_candle_age=round(max(0.0, ts-candle_ts),1) if candle_ts else None
        rr={**r,"feature_ts":ts,
            "change_1m": None if ch1 is None else round(ch1,3), "change_1m_known": bool(ch1_known), "change_1m_source": ch1_src,
            "change_3m": None if ch3 is None else round(ch3,3), "change_3m_known": bool(ch3_known), "change_3m_source": ch3_src,
            "change_5m": None if ch5 is None else round(ch5,3), "change_5m_known": bool(ch5_known), "change_5m_source": ch5_src,
            "change_15m": None if ch15 is None else round(ch15,3), "change_15m_known": bool(ch15_known), "change_15m_source": ch15_src,
            "change_30m": None if ch30 is None else round(ch30,3), "change_30m_known": bool(ch30_known), "change_30m_source": ch30_src,
            "hot_rank_1m": h.get("scanner_hot_rank_1m"), "hot_rank_3m": h.get("scanner_hot_rank_3m"),
            "scanner_hot_observed_1m_sec": h.get("scanner_hot_observed_1m_sec"), "scanner_hot_observed_3m_sec": h.get("scanner_hot_observed_3m_sec"),
            "vwap_gap_pct":round(vwap_gap,3),"ema5_gap_pct":round(ema5_gap,3),
            "relative_strength_pct":round(rel,3) if rel is not None else None,
            "relative_strength_source_v1095":"scanner.change_24h-minus-market.avg_top60_change" if rel is not None else "source_missing",
            "turnover_24h_for_quality_v1095":turnover if (turnover:=fnum(r.get("turnover_24h"),default=-1.0))>=0 else None,
            "volume_flow_signal_v1095":(_quality_component_value(c,"volume_ratio","m5_volume_ratio","m3_volume_ratio") if isinstance(c,dict) else None),
            "short_flow_signal_v1095":ch3 if ch3 is not None else ch1,
            "day_pos_pct":day_pos,"market_mode":reg.get("mode","확인중"),"candle_ok":bool(c),
            "official_candle_source":"bithumb_public_candlestick" if c else "missing", "official_candle_age":official_candle_age, "official_candle_intervals":"1m/3m/5m/30m",
            "breakout_hint":bool(c.get("m5_breakout_hint") or c.get("m3_breakout_hint")),"box_breakout_hint":bool(c.get("m5_box_breakout_hint") or c.get("m3_box_breakout_hint")),
            "sweep_reclaim_hint":bool(c.get("m5_sweep_reclaim_hint") or c.get("m3_sweep_reclaim_hint")),"support_reclaim_hint":bool(c.get("m5_support_reclaim_hint") or c.get("m3_support_reclaim_hint")),
            "resistance_reject_hint":bool(c.get("m5_resistance_reject_hint") or c.get("m3_resistance_reject_hint")),
            "pullback_volume_contract":bool(c.get("m5_pullback_volume_contract") or c.get("m3_pullback_volume_contract")),"reclaim_volume_expand":bool(c.get("m5_reclaim_volume_expand") or c.get("m3_reclaim_volume_expand")),
            "volume_expanding":bool(c.get("m5_volume_expanding") or c.get("m3_volume_expanding")),"long_upper_wick":bool(c.get("m5_long_upper_wick") or c.get("m3_long_upper_wick")),
            "recent_high_gap_pct":fnum(c.get("m5_recent_high_gap_pct"),c.get("m3_recent_high_gap_pct"),default=0),"recent_low_rebound_pct":fnum(c.get("m5_recent_low_rebound_pct"),c.get("m3_recent_low_rebound_pct"),default=0),
            "recent_high_price":fnum(c.get("m5_recent_high_price"),c.get("m3_recent_high_price"),default=0),"recent_low_price":fnum(c.get("m5_recent_low_price"),c.get("m3_recent_low_price"),default=0),
            "swing_high_price":fnum(c.get("m5_swing_high_price"),c.get("m3_swing_high_price"),default=0),"swing_low_price":fnum(c.get("m5_swing_low_price"),c.get("m3_swing_low_price"),default=0),
            "box_high_price":fnum(c.get("m5_box_high_price"),c.get("m3_box_high_price"),default=0),"box_low_price":fnum(c.get("m5_box_low_price"),c.get("m3_box_low_price"),default=0),
            "support_touch_count":fnum(c.get("m5_support_touch_count"),c.get("m3_support_touch_count"),default=0),"resistance_touch_count":fnum(c.get("m5_resistance_touch_count"),c.get("m3_resistance_touch_count"),default=0),
            "upper_wick_pct":fnum(c.get("m5_upper_wick_pct"),c.get("m3_upper_wick_pct"),default=0),"lower_wick_pct":fnum(c.get("m5_lower_wick_pct"),c.get("m3_lower_wick_pct"),default=0),
            "ema10_gap_pct":fnum(c.get("m5_ema10_gap_pct"),c.get("m3_ema10_gap_pct"),default=0),"ema20_gap_pct":fnum(c.get("m5_ema20_gap_pct"),c.get("m3_ema20_gap_pct"),default=0),
            "volume_ratio":fnum(c.get("m5_volume_ratio"),c.get("m3_volume_ratio"),default=0),"volume_expansion_pct":fnum(c.get("m5_volume_expansion_pct"),c.get("m3_volume_expansion_pct"),default=0)}
        rows.append(rr)
    rel_known=_cross_section_percentile(rows,"relative_strength_pct","relative_strength_rank_pct_v1095")
    turnover_known=_cross_section_percentile(rows,"turnover_24h_for_quality_v1095","turnover_rank_pct_v1095")
    volume_known=_cross_section_percentile(rows,"volume_flow_signal_v1095","volume_flow_rank_pct_v1095")
    short_known=_cross_section_percentile(rows,"short_flow_signal_v1095","short_flow_rank_pct_v1095")
    money_known=0
    for row in rows:
        components=[row.get(k) for k in ("turnover_rank_pct_v1095","volume_flow_rank_pct_v1095","short_flow_rank_pct_v1095") if row.get(k) is not None]
        if len(components)>=2:
            row["money_flow_score"]=round(sum(float(x) for x in components)/len(components),3)
            row["money_flow_source_v1095"]="feature_cross_sectional_turnover_volume_shortflow"
            row["money_flow_source_missing_v1095"]=False
            money_known+=1
        else:
            row["money_flow_score"]=None
            row["money_flow_source_v1095"]="source_missing"
            row["money_flow_source_missing_v1095"]=True
        row["feature_quality_owner_v1095"]="feature_worker"
    save_json(OUT,{"version":VERSION,"schema":"feature_cache_v1095_swing_quality_owner","updated_ts":ts,"updated_text":now_text(ts),"row_count":len(rows),"scanner_age":round(age_sec(SCANNER),1),"candle_age":round(age_sec(CANDLE),1),"hot_age":round(age_sec(HOT),1),"regime_age":round(age_sec(REGIME),1),"known_1m":known_1m,"known_3m":known_3m,"missing_1m":missing_1m,"missing_3m":missing_3m,"hot_used":hot_used,"relative_strength_known_v1095":rel_known,"money_flow_known_v1095":money_known,"quality_owner_v1095":"feature_worker","note":"v1095 cross-sectional relative strength and money flow; v596: 1m/3m은 scanner hot rank 또는 candle에서만 사용. 공식 candle_worker OHLCV 구조재료를 feature row에 전달. missing은 missing으로 남김.","rows":rows})
    sec=now_ts()-st; write_status("running", row_count=len(rows), known_1m=known_1m, known_3m=known_3m, missing_1m=missing_1m, missing_3m=missing_3m, hot_used=hot_used, relative_strength_known_v1095=rel_known, money_flow_known_v1095=money_known, quality_owner_v1095="feature_worker", last_sec=round(sec,3), scanner_age=round(age_sec(SCANNER),1), candle_age=round(age_sec(CANDLE),1), hot_age=round(age_sec(HOT),1)); return {"rows":len(rows),"known_1m":known_1m,"known_3m":known_3m,"hot_used":hot_used}
def main()->None:
    write_status("initializing")
    while True:
        try: run_once()
        except KeyboardInterrupt: write_status("stopping"); raise
        except Exception as exc: append_error(ERROR,"loop",exc); write_status("error", error=f"{exc.__class__.__name__}: {exc}")
        time.sleep(max(0.5,INTERVAL_SEC))

# v1401 identity unification override (no trading-rule changes)
VERSION = 'feature_worker_v2.000'
BUILD_LABEL = 'v2000_candidate_hot_path_reset_direct_s1_latest_execution_autobuy_off_2026-07-14'
MAIN_DEPLOY_VERSION = 'v2000_candidate_hot_path_reset_direct_s1_latest_execution_autobuy_off_2026-07-14'

if __name__=="__main__": main()
