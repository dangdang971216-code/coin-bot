코인봇 업데이트 v1226

목적:
- v1225 Strategy v1.052가 후보 저장 24KB hard ceiling에서 멈춘 오류 수리
- 오류: required candidate scalar exceeds hard ceiling: selection_contract_version

수정:
- 실제 동적 구조계약은 그대로 1회 보존
- 압축 companion에서 중간저항 전체 복사와 중복 설명문 제거
- 후보마다 반복되던 formula/policy 설명문은 versioned source에만 보존
- Trigger/Invalid/Target 계산, RR 1.5, 목표공간 1.2%, 진입/청산 변경 없음

적용:
- Guard에서 /gupgrade_bundle 단독 실행
- 재시작 후 새 Strategy 완료 cycle을 기다린 다음 검수

자동매수 OFF 유지.
