#!/usr/bin/env python3
from __future__ import annotations
import copy
import importlib.util
import json
import pathlib
import sys

ROOT = pathlib.Path(__file__).resolve().parent
PACKAGE_ROOT = ROOT.parent
if str(PACKAGE_ROOT) not in sys.path:
    sys.path.insert(0, str(PACKAGE_ROOT))


def load(name: str, path: pathlib.Path):
    spec = importlib.util.spec_from_file_location(name, path)
    mod = importlib.util.module_from_spec(spec)
    sys.modules[name] = mod
    assert spec and spec.loader
    spec.loader.exec_module(mod)
    return mod


def install_material(mod) -> None:
    def frame_rows(_row, tf):
        return [{'tf': tf}] * 10
    def atr(rows):
        tf = rows[0]['tf'] if rows else ''
        return {'m5': 0.7, 'm15': 1.0, 'm30': 1.0, 'h1': 1.2, 'h2': 2.0, 'h4': 5.0}.get(tf, 1.0)
    def zone(tf, low, high, score=80.0):
        return {'tf': tf, 'side': 'resistance', 'price': (low + high) / 2.0,
                'zone_low': low, 'zone_high': high, 'score': score,
                'touch_count': 3, 'source': f'candle.{tf}', 'atr_pct': 1.0, 'gap_pct': 0.0}
    def support(tf, low, high):
        return {'tf': tf, 'side': 'support', 'price': (low + high) / 2.0,
                'zone_low': low, 'zone_high': high, 'score': 80.0,
                'touch_count': 3, 'source': f'candle.{tf}', 'atr_pct': 1.0, 'gap_pct': 0.0}
    def candidates(_rows, tf, side, _price):
        if side == 'support':
            return [support(tf, 97.0, 97.2)] if tf == 'h1' else []
        table = {
            'm15': [zone('m15', 100.4, 100.5)],
            'm30': [zone('m30', 100.9, 101.0)],
            'h1': [zone('h1', 103.0, 103.2)],
            'h2': [zone('h2', 106.0, 106.2)],
            'h4': [zone('h4', 109.0, 109.2)],
        }
        return table.get(tf, [])
    mod._v1212_frame_rows = frame_rows
    mod._v1212_atr_pct = atr
    mod._v1212_zone_candidates = candidates
    mod._v1212_cost_inputs = lambda _row: {
        'spread_pct': 0.1, 'slippage_pct': 0.1, 'slippage_source': 'test',
        'fee_pct': 0.2, 'estimated_roundtrip_cost_pct': 0.5, 'complete': True,
    }
    mod._v1212_strength_factor = lambda _row: 1.0


def main() -> None:
    old = load('strategy_v1225_writer_failure', PACKAGE_ROOT / 'baselines' / 'strategy_worker_v1.052_v1225_writer_failure.py')
    new = load('strategy_v1226_writer_repair', PACKAGE_ROOT / 'strategy_worker_v1.053.py')
    install_material(old)
    install_material(new)
    old_plan = old._v925_current_actual_plan({'ticker': 'TEST', 'current_price': 100.0})
    new_plan = new._v925_current_actual_plan({'ticker': 'TEST', 'current_price': 100.0})
    assert old_plan == new_plan

    source = {
        'ticker': 'TEST', 'market': 'KRW-TEST', 'candidate_pipeline_cycle_id_v1150': 'cycle-x',
        's_stage': 'S2', 'current_price': 100.0,
        'structure_integrity_v1048': 'OK', 'structure_integrity_block_v1048': False,
        'structure_integrity_refresh_required_v1048': False,
        'structure_integrity_v1049': 'OK', 'structure_integrity_block_v1049': False,
        'structure_integrity_refresh_required_v1049': False,
        'structure_contract_version': new_plan['structure_contract_version'],
        'structure_contract_hash': new_plan['structure_contract_hash'],
        'structure_quality_score_v1212': 81.4,
        'target_reachability_score_v1212': 83.2,
        'global_entry_score_v1212': 77.7,
        'dynamic_chase_limit_pct_v1212': 0.8,
        'ranking_contract_version': 'ranking_contract_v1212_global_dynamic_score',
        'selection_contract_version': 'selection_contract_v1212_global_top_score',
        'current_cycle_observation_only_v1215': False,
        'current_cycle_observation_role_owner_v1215': 'strategy',
        'legacy_s3_observation_label_v1215': False,
        'legacy_s3_observation_retired_v1215': True,
        'entry_flow_state_v1221': 'WATCHING_FROZEN_TRIGGER',
        'entry_flow_baseline_v1221': 'v1211_trigger_watch_then_s1_then_paper',
        'entry_flow_violation_v1221': False,
        'v1211_structure_shadow_ready_v1222': True,
    }
    padded_plan = copy.deepcopy(new_plan)
    # Exact boundary reproducer: v1.052 fails on the required selection scalar.
    # v1.053 preserves the executable plan once and drops only duplicated prose.
    padded_plan['runtime_padding_v1226'] = 'P' * 15069
    source['dynamic_structure_plan_v1212'] = padded_plan
    source['structure_contract_v1212'] = padded_plan

    try:
        old._v861_compact_row_for_latest(source)
        raise AssertionError('v1.052 failure was not reproduced')
    except ValueError as exc:
        assert 'required candidate scalar exceeds hard ceiling: selection_contract_version' in str(exc)

    compact = new._v861_compact_row_for_latest(source)
    encoded = json.dumps(compact, ensure_ascii=False, separators=(',', ':'), default=str).encode('utf-8')
    assert len(encoded) <= new.V1020_ROW_HARD_CEILING_BYTES
    assert compact['selection_contract_version'] == 'selection_contract_v1212_global_top_score'
    assert compact['dynamic_structure_plan_v1212']['trigger'] == new_plan['trigger']
    assert compact['dynamic_structure_plan_v1212']['invalid'] == new_plan['invalid']
    assert compact['dynamic_structure_plan_v1212']['target'] == new_plan['target']
    assert compact['dynamic_structure_plan_v1212']['intermediate_resistance_v1225'] == new_plan['intermediate_resistance_v1225']
    assert 'formula' not in compact['dynamic_structure_plan_v1212']
    assert 'policy' not in compact['dynamic_structure_plan_v1212']
    assert 'intermediate_resistance_v1225' not in compact['structure_contract_v1212']
    assert new.VERSION == 'strategy_worker_v1.053'
    assert new.BUILD_LABEL == 'v1226_candidate_writer_budget_contract_repair_2026-07-05'
    print(f'PASS v1226 writer repair: old exact failure reproduced, new row {len(encoded)}B, trading contract unchanged')


if __name__ == '__main__':
    main()
