v1712 PREOPEN full clean reset+rebuild. Auto-buy OFF. Adds /preopen_wait_detail and latest display fix.
