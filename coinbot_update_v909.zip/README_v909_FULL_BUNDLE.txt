코인봇 v909 FULL 코드묶음
- main: coinbot_main_v2_13_909.py / bot.py
- strategy: strategy_worker_v0.908.py unchanged
- paper: paper_bot_v0.800.py unchanged
- review: review_worker_v0.722.py unchanged
- 목적: trigger_audit 진짜놓침 세부분해 reader
- 변경 없음: 조건/S1/S2/S3/trigger 산식/청산/paper OPEN/CLOSED/trade_log/자동매수
