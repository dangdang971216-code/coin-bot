#!/usr/bin/env python3
# -*- coding: utf-8 -*-

from __future__ import annotations
import json, os, time, math, traceback, urllib.request
from pathlib import Path
from typing import Any, Dict, List, Tuple, Optional
import re
from collections import Counter
BASE_DIR = Path(os.getenv("TRADING_BOT_DIR", "/home/dangdang971216/trading_bot"))
def now_ts() -> float: return time.time()
def now_text(ts: Optional[float]=None) -> str: return time.strftime("%Y-%m-%d %H:%M:%S", time.localtime(ts or now_ts()))
def fnum(*vals: Any, default: float=0.0) -> float:
    for v in vals:
        try:
            if v is None or v == "": continue
            return float(str(v).replace(",", "").replace("%", ""))
        except Exception: continue
    return default
def load_json(path: Path, default: Any=None) -> Any:
    try:
        if not path.exists(): return default
        return json.loads(path.read_text(encoding="utf-8", errors="ignore"))
    except Exception: return default
def save_json(path: Path, obj: Any) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    tmp = path.with_suffix(path.suffix + ".tmp")
    tmp.write_text(json.dumps(obj, ensure_ascii=False, separators=(",", ":"), default=str), encoding="utf-8")
    os.replace(tmp, path)
def append_jsonl(path: Path, obj: Dict[str, Any]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("a", encoding="utf-8") as f:
        f.write(json.dumps(obj, ensure_ascii=False, separators=(",", ":"), default=str)+"\n")
def write_jsonl_atomic(path: Path, rows: List[Dict[str, Any]]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    tmp = path.with_suffix(path.suffix + ".tmp")
    with tmp.open("w", encoding="utf-8") as f:
        for r in rows:
            f.write(json.dumps(r, ensure_ascii=False, separators=(",", ":"), default=str)+"\n")
    os.replace(tmp, path)
def read_jsonl(path: Path, max_lines: int=1000) -> List[Dict[str, Any]]:
    if not path.exists(): return []
    try:
        lines = path.read_text(encoding="utf-8", errors="ignore").splitlines()
        if max_lines and len(lines) > max_lines: lines = lines[-max_lines:]
        out=[]
        for ln in lines:
            try:
                if ln.strip():
                    o=json.loads(ln)
                    if isinstance(o,dict): out.append(o)
            except Exception: pass
        return out
    except Exception: return []
def read_fresh_jsonl_by_ttl(path: Path, ttl_sec: float) -> List[Dict[str, Any]]:
    """TTL 기준으로 fresh 후보만 읽는다. 개수 제한으로 후보를 자르지 않는다.

    기존 latest/후보 복구 경로의 max_lines=120/500 및 [:40] 고정 상한을
    제거하기 위한 단일 읽기 경로다. 서버 보호는 후보 수 제한이 아니라 TTL로 처리한다.
    """
    if not path.exists():
        return []
    try:
        nowv = now_ts()
        lines = path.read_text(encoding="utf-8", errors="ignore").splitlines()
        out: List[Dict[str, Any]] = []
        for ln in reversed(lines):
            try:
                if not ln.strip():
                    continue
                o = json.loads(ln)
                if not isinstance(o, dict):
                    continue
                exp = fnum(o.get("expires_at"), default=0.0)
                ts = _event_created_ts(o)
                fresh = (exp >= nowv) if exp > 0 else (ts > 0 and (nowv - ts) <= ttl_sec)
                if fresh:
                    out.append(o)
                    continue
                # 파일은 시간순 append라, TTL의 여유구간보다 오래된 항목을 만나면 더 과거는 볼 필요 없다.
                if ts > 0 and (nowv - ts) > max(ttl_sec * 3.0, ttl_sec + 60.0):
                    break
            except Exception:
                continue
        out.reverse()
        return out
    except Exception:
        return []

def append_error(path: Path, where: str, exc: BaseException) -> None:
    try:
        path.parent.mkdir(parents=True, exist_ok=True)
        with path.open("a", encoding="utf-8") as f:
            f.write(f"[{now_text()}] {where}: {exc.__class__.__name__}: {exc}\n")
            f.write(traceback.format_exc()[-1500:]+"\n")
    except Exception: pass
def ticker_norm(x: Any) -> str:
    t = str(x or "").strip().upper().replace("/", "-").replace("_", "-")
    parts=[p for p in t.split("-") if p]
    if len(parts)>=2:
        non=[p for p in parts if p != "KRW"]
        t = non[-1] if non else parts[-1]
    if t.endswith("KRW") and len(t)>3: t=t[:-3]
    return t.strip().upper()
def pct(a: float, b: float) -> float: return ((a-b)/b*100.0) if b else 0.0
def age_sec(path: Path) -> float:
    try: return max(0.0, now_ts()-path.stat().st_mtime)
    except Exception: return 999999.0
def map_rows(obj: Any) -> Dict[str, Dict[str, Any]]:
    if isinstance(obj, dict) and isinstance(obj.get("rows"), list): obj = obj.get("rows")
    elif isinstance(obj, dict) and isinstance(obj.get("rows"), dict): obj = obj.get("rows")
    elif isinstance(obj, dict) and isinstance(obj.get("cache"), dict): obj = obj.get("cache")
    out: Dict[str, Dict[str, Any]] = {}
    if isinstance(obj, list):
        for r in obj:
            if isinstance(r, dict):
                t=ticker_norm(r.get("ticker") or r.get("symbol") or r.get("market"))
                if t: out[t]=r
    elif isinstance(obj, dict):
        for k,v in obj.items():
            t=ticker_norm(k)
            if t and isinstance(v, dict):
                vv=dict(v); vv.setdefault("ticker", t); out[t]=vv
    return out

def feature_rows(obj: Any) -> List[Dict[str, Any]]:
    """feature_worker cache를 한 본선으로 읽는다.
    rows/list/cache/dict 형태를 모두 map_rows로 표준화한다.
    전략 조건 수치는 변경하지 않는다.
    """
    return list(map_rows(obj).values())

INTERVAL_SEC=float(os.getenv("STRATEGY_WORKER_INTERVAL_SEC","2.0"))
STATUS=BASE_DIR/"clean_strategy_worker_status.json"; ERROR=BASE_DIR/"clean_strategy_worker_error.log"
FEATURE=BASE_DIR/"clean_feature_cache.json"; CANDLE=BASE_DIR/"clean_candle_cache.json"; ORDERFLOW=BASE_DIR/"clean_orderflow_summary_cache.json"; REGIME=BASE_DIR/"clean_market_regime_cache.json"; RISK=BASE_DIR/"clean_risk_filter_cache.json"
PAPER=BASE_DIR/"paper_candidates.jsonl"; PAPER_LATEST=BASE_DIR/"paper_candidates_latest.jsonl"; SUMMARY=BASE_DIR/"clean_strategy_s_summary.json"; REJECT=BASE_DIR/"clean_strategy_s_reject_summary.json"; HANDOFF=BASE_DIR/"clean_strategy_paper_handoff_status.json"; WS_TARGETS=BASE_DIR/"clean_ws_targets.json"; MICRO_TARGETS=BASE_DIR/"clean_micro_targets.json"; MICRO_URGENT=BASE_DIR/"clean_micro_urgent_targets.json"; PRIORITY_REQ=BASE_DIR/"clean_strategy_priority_requests.json"; TARGET_ROUTER_QUEUE=BASE_DIR/"clean_target_router_queue.json"; MISSED_REVIEW_QUEUE=BASE_DIR/"clean_missed_review_queue.json"; SCANNER_HOT=BASE_DIR/"clean_scanner_hot_rank_cache.json"
CANDIDATE_TTL_SEC=float(os.getenv("STRATEGY_PAPER_CANDIDATE_TTL_SEC","120"))
ENTRY_PLAN_STATE=BASE_DIR/"clean_strategy_entry_plan_state.json"
STRATEGIES={"money_reaccel_s":"돈흐름 재가속 S","leader_momentum_s":"주도추세 지속 S","breakout_early_s":"돌파 초입 S","sweep_vwap_recovery_s":"저점 VWAP 회복 S","surge_rebreak_s":"급등 후 재돌파 S","leader_flow_adaptive_hold_s":"주도흐름 유동보유 S"}

# v597: official structure-input keys must survive strategy row creation.
# v596 produced/loaded candle features, but candidate row construction dropped those fields before
# structure_line_evidence ran. Keep the source-cache values on the canonical candidate row.
V597_OFFICIAL_STRUCTURE_KEYS = (
    "official_candle_source", "official_candle_age", "official_candle_intervals", "official_candle_cache_schema", "official_structure_source",
    "swing_high_price", "swing_low_price", "box_high_price", "box_low_price", "recent_high_price", "recent_low_price",
    "support_touch_count", "resistance_touch_count", "upper_wick_pct", "lower_wick_pct",
    "vwap_gap_pct", "ema5_gap_pct", "ema10_gap_pct", "ema20_gap_pct",
    "volume_ratio", "volume_expansion_pct", "breakout_hint", "sweep_reclaim_hint", "box_breakout_hint",
    "support_reclaim_hint", "resistance_reject_hint", "pullback_volume_contract", "reclaim_volume_expand",
    "long_upper_wick", "volume_expanding", "close_near_high",
)

def _v597_pick_candle_value(c: Dict[str, Any], key: str, prefixes: Tuple[str, ...] = ("m5", "m3", "m1", "m30")) -> Any:
    if not isinstance(c, dict):
        return None
    for pref in prefixes:
        k = f"{pref}_{key}"
        if c.get(k) not in (None, ""):
            return c.get(k)
    return None

def _v597_candle_official_fields(c: Dict[str, Any], nowv: Optional[float] = None) -> Dict[str, Any]:
    """Convert candle_worker cache row into the unprefixed official structure fields used by strategy.
    No API call here. candle_worker remains the owner of official OHLCV collection.
    """
    if not isinstance(c, dict) or not c:
        return {}
    ts = nowv or now_ts()
    candle_ts = _v510_num(c.get("candle_ts"), default=0.0) if "_v510_num" in globals() else 0.0
    # accept only rows that actually have at least one interval ok or key feature; don't turn missing into zeroes.
    has_interval = bool(c.get("m5_ok") or c.get("m3_ok") or c.get("m1_ok") or c.get("m30_ok") or c.get("m5_swing_high_price") or c.get("m3_swing_high_price"))
    if not has_interval:
        return {}
    out: Dict[str, Any] = {
        "official_candle_source": "candle_worker_direct_cache_v597",
        "official_candle_intervals": "1m/3m/5m/30m",
        "official_candle_cache_schema": c.get("official_structure_schema") or c.get("schema") or "candle_cache_v2_official_structure_inputs",
        "official_structure_source": "candle_worker_cache_overlay_v597",
    }
    if candle_ts > 0:
        out["official_candle_age"] = round(max(0.0, ts - candle_ts), 1)
    for key in V597_OFFICIAL_STRUCTURE_KEYS:
        if key in out:
            continue
        v = _v597_pick_candle_value(c, key)
        if v not in (None, ""):
            out[key] = v
    return out

def _v597_overlay_candle_cache(src: Dict[str, Any], candle_map: Dict[str, Dict[str, Any]], nowv: Optional[float] = None) -> Dict[str, Any]:
    if not isinstance(src, dict):
        return src
    t = ticker_norm(src.get("ticker") or src.get("market") or src.get("symbol"))
    c = candle_map.get(t, {}) if t else {}
    add = _v597_candle_official_fields(c, nowv)
    if not add:
        return dict(src)
    rr = dict(src)
    for k, v in add.items():
        if rr.get(k) in (None, "", 0, 0.0) or k.startswith("official_"):
            rr[k] = v
    return rr
MAIN_DEPLOY_VERSION = "v2.13.461"
MAIN_BOT_VERSION = "수익형 v2.13.461"
def write_status(state:str, **extra:Any)->None:
    # v434: cycle 시작부의 evaluated=0/target=0 상태가 마지막 정상값을 지우지 않게
    # 중앙 status 저장부에서 구 0 초기화 경로를 제거한다.
    prev: Dict[str, Any] = {}
    phase = str(extra.get("phase") or "")
    is_cycle_start_zero = (
        state == "running"
        and phase.startswith("evaluating")
        and int(float(extra.get("evaluated") or 0)) <= 0
        and int(float(extra.get("target_count") or 0)) <= 0
    )
    if is_cycle_start_zero:
        try:
            prev = load_json(STATUS, {}) or {}
        except Exception:
            prev = {}
    obj={"version":VERSION,"state":state,"pid":os.getpid(),"updated_ts":now_ts(),"updated_text":now_text(),"last_error":""}
    obj.update(extra)
    if is_cycle_start_zero and prev:
        for key in ("evaluated", "target_count", "s_count", "paper_latest_count", "s1_count", "s2_count", "s3_count", "router_target_count", "router_queue_count", "router_backlog_count", "last_sec"):
            if key in prev and (obj.get(key) in (None, "", 0, "0", "-")):
                obj[key] = prev.get(key)
        obj["status_route_schema"] = "strategy_status_v435_no_zero_cycle_start_no_40_cap"
        obj["status_route_note"] = "v436: S1/S2/S3 단순화 + cycle 시작 0 초기화 방지 + 후보 latest 고정 40개 제한 제거"
    if state == "error" and "error" in extra:
        obj["last_error"] = str(extra.get("error") or "")[:240]
    save_json(STATUS,obj)

def _event_created_ts(ev: Dict[str, Any]) -> float:
    return fnum(ev.get("created_at"), ev.get("candidate_created_at"), ev.get("source_created_at"), ev.get("detected_ts"), ev.get("event_ts"), ev.get("ts"), ev.get("timestamp"), default=0.0)

# v533 removed legacy unused function: _normalize_paper_event

def _paper_event_fresh(ev: Dict[str, Any], nowv: Optional[float] = None) -> bool:
    nowv = nowv or now_ts()
    exp = fnum(ev.get("expires_at"), default=0.0)
    ts = _event_created_ts(ev)
    if exp > 0:
        return exp >= nowv
    return ts > 0 and (nowv - ts) <= CANDIDATE_TTL_SEC

def _paper_dedupe_key(ev: Dict[str, Any]) -> str:
    t = ticker_norm(ev.get("ticker") or ev.get("market") or ev.get("symbol"))
    sk = str(ev.get("strategy_key") or ev.get("strategy_bucket_primary") or "strategy_s")
    return f"{t}:{sk}"

# v510: legacy persist_paper_handoff removed from runtime. paper_candidates_latest is written once by _v510_publish.

def risk_bad(t:str)->List[str]:
    r=load_json(RISK,{}) or {}; cd=(r.get("cooldown") or {}) if isinstance(r,dict) else {}
    out=[]
    if t in cd: out.append("최근반복손실/하드손실")
    if t in set(r.get("open_tickers",[]) if isinstance(r,dict) else []): out.append("이미OPEN중")
    return out
def common_hard(row:Dict[str,Any], of:Dict[str,Any])->List[str]:
    """cheap/기본 차단만 본다.
    WS/micro 부족은 여기서 붙이지 않는다.
    v0.8: 붙일 필요도 없는 후보까지 정보부족으로 보이는 문제를 막기 위해
    정보부족은 cheap gate 통과 후보에게만 별도 부여한다.
    """
    hard=[]; t=ticker_norm(row.get("ticker")); hard+=risk_bad(t)
    if row.get("major_watch"): hard.append("대형주는시장참고")
    if bool(of.get("micro_fresh")):
        spread=fnum(of.get("spread_pct"),default=0)
        buy=fnum(of.get("buy_ratio"),default=0)
        if spread>0.28: hard.append(f"스프레드넓음 {spread:.2f}%")
        if buy and buy<0.58: hard.append(f"매수체결약함 {buy:.2f}")
        if of.get("sell_pressure"): hard.append("매도벽/매도체결압력")
    if fnum(row.get("turnover_24h"))<250_000_000: hard.append("거래대금부족")
    if row.get("long_upper_wick"): hard.append("윗꼬리위험")
    if fnum(row.get("day_pos_pct"),default=50)>94 and fnum(row.get("change_5m"))<0.2: hard.append("고점끝물위험")
    return hard[:8]

def orderflow_info_bad(of:Dict[str,Any])->List[str]:
    """v0.9: strategy는 WS 단독 fresh가 아니라 표준 시세(quote_fresh)를 본다.
    quote_fresh는 orderflow_worker가 WS 또는 scanner/feature REST 현재가로 만든 canonical 시세다.
    micro는 호가·체결 판단 재료라 별도로 필요하다.
    """
    info=[]
    if not bool(of.get("quote_fresh") or of.get("ws_fresh")):
        info.append("시세정보보강대기")
    if not bool(of.get("micro_fresh")):
        info.append("micro정보보강대기")
    return info[:4]
def eval_money(r,o):
    no=[]
    if fnum(r.get("change_3m"))<0.25 or fnum(r.get("change_5m"))<0.35: no.append("3/5분재가속부족")
    if fnum(r.get("vwap_gap_pct"))<-0.05 or fnum(r.get("ema5_gap_pct"))<-0.08: no.append("VWAP/EMA유지부족")
    if not r.get("volume_expanding"): no.append("캔들거래량확장부족")
    # micro가 fresh일 때만 매수체결비를 전략 실패로 본다. fresh가 없으면 정보보강대기로 분리한다.
    if o.get("micro_fresh") and fnum(o.get("buy_ratio"))<0.65: no.append("매수체결우세부족")
    return (not no, ["돈흐름재가속","3/5분재가속","VWAP/EMA유지","체결우세"], no)
def eval_leader(r,o):
    no=[]
    if fnum(r.get("change_15m"))<0.65 or fnum(r.get("change_30m"))<0.65: no.append("15/30분주도부족")
    if fnum(r.get("relative_strength_pct"))<0.3: no.append("시장대비강도부족")
    if fnum(r.get("vwap_gap_pct"))<0 or fnum(r.get("ema5_gap_pct"))<0: no.append("VWAP/EMA위치부족")
    if r.get("market_mode") == "약함": no.append("장세약함")
    return (not no, ["15/30분주도","시장대비강함","VWAP/EMA위"], no)
def eval_breakout(r,o):
    no=[]
    if not r.get("breakout_hint"): no.append("돌파캔들미확인")
    if fnum(r.get("recent_high_gap_pct"))<-0.15: no.append("돌파후유지부족")
    if fnum(r.get("change_15m"))>5.0 and not r.get("volume_expanding"): no.append("끝물추격위험")
    return (not no, ["돌파초입","거래량확장","고점돌파유지"], no)
def eval_sweep(r,o):
    no=[]
    if not r.get("sweep_reclaim_hint"): no.append("저점쓸림회복미확인")
    if fnum(r.get("vwap_gap_pct"))<-0.05: no.append("VWAP회복부족")
    if fnum(r.get("recent_low_rebound_pct"))<0.4: no.append("저점방어반등부족")
    return (not no, ["저점이탈실패","VWAP회복","매수회복"], no)
def eval_surge(r,o):
    no=[]
    if fnum(r.get("change_15m"))<1.2: no.append("1차상승부족")
    if fnum(r.get("change_3m"))<0.15: no.append("재돌파시도부족")
    if fnum(r.get("recent_high_gap_pct"))<-0.25: no.append("고점재접근부족")
    if r.get("long_upper_wick"): no.append("윗꼬리반락위험")
    return (not no, ["급등후재돌파","얕은눌림","체결재상승"], no)


def eval_adaptive_hold(r,o):
    """v0.19/v367 주도흐름 유동보유 전략.
    시간 고정이 아니라 0~5분 검증, 5~30분 확인, 30~120분 확장으로 나눠 본다.
    """
    no=[]
    ch1=fnum(r.get("change_1m"), r.get("price_change_1m"), default=0.0)
    ch3=fnum(r.get("change_3m"), r.get("price_change_3m"), default=0.0)
    ch5=fnum(r.get("change_5m"), r.get("price_change_5m"), default=0.0)
    ch15=fnum(r.get("change_15m"), r.get("price_change_15m"), default=0.0)
    ch30=fnum(r.get("change_30m"), r.get("price_change_30m"), default=0.0)
    vwap=fnum(r.get("vwap_gap_pct"), default=-9.0)
    ema=fnum(r.get("ema5_gap_pct"), r.get("ma5_gap_pct"), default=-9.0)
    rel=fnum(r.get("relative_strength_pct"), r.get("relative_strength"), default=0.0)
    day=fnum(r.get("day_pos_pct"), r.get("current_close_pos_ratio"), default=50.0)
    high_gap=fnum(r.get("recent_high_gap_pct"), r.get("below_high_pct"), default=-9.0)
    money=fnum(r.get("turnover_24h"), default=0.0)
    buy=fnum(o.get("buy_ratio"), o.get("micro_trade_buy_ratio_30"), default=0.0)
    spread=fnum(o.get("spread_pct"), default=99.0)
    if not ((ch3 >= 0.20 and ch5 >= 0.25) or (ch15 >= 0.70 and ch30 >= 0.40) or (ch5 >= 0.80 and ch15 >= 0.40)):
        no.append("흐름유지부족")
    if vwap < -0.10 or ema < -0.15:
        no.append("VWAP/EMA유지부족")
    if rel < -1.0 and ch5 < 1.0:
        no.append("시장대비약함")
    if money < 300_000_000:
        no.append("거래대금부족")
    if o.get("micro_fresh") and buy < 0.58:
        no.append("매수체결최소부족")
    if o.get("micro_fresh") and spread > 0.30:
        no.append("스프레드과다")
    if day >= 97.0 and high_gap >= -0.05 and ch1 <= 0.05:
        no.append("고점끝물재확인필요")
    if ch5 >= 12.0 and ema >= 6.0:
        no.append("급등과열재확인필요")
    return (not no, ["주도흐름유지","유동보유","VWAP/EMA방어","시간확장후보"], no)

def _pickv(src: Dict[str, Any], *keys: str, default: Any = None) -> Any:
    for k in keys:
        if isinstance(src, dict) and src.get(k) not in (None, "", "-"):
            return src.get(k)
    return default

def _boolv(v: Any) -> bool:
    if isinstance(v, bool): return v
    return str(v).lower() in {"1", "true", "yes", "ok", "fresh", "신선"}

# v533 removed legacy unused function: _entry_snapshot

def _v361_adaptive_hold_profile(row: Dict[str, Any], of: Dict[str, Any], skey: str) -> Dict[str, Any]:
    """유동 보유형 후보별 청산/복기 프로필."""
    ch5=fnum(row.get('change_5m'), row.get('price_change_5m'), default=0.0)
    ch15=fnum(row.get('change_15m'), row.get('price_change_15m'), default=0.0)
    ch30=fnum(row.get('change_30m'), row.get('price_change_30m'), default=0.0)
    rel=fnum(row.get('relative_strength_pct'), row.get('relative_strength'), default=0.0)
    vwap=fnum(row.get('vwap_gap_pct'), default=0.0)
    ema=fnum(row.get('ema5_gap_pct'), row.get('ma5_gap_pct'), default=0.0)
    strong = (ch15 >= 1.2 and ch30 >= 0.8 and rel >= 0.3) or (ch5 >= 1.2 and ch15 >= 0.8 and vwap >= 0 and ema >= 0)
    ext_tp = 2.20 if strong else 1.80
    max_min = 120 if strong else 75
    return {
        'strategy_family': 'adaptive_hold',
        'strategy_family_label': '주도흐름 유동보유',
        'hold_model': 'adaptive_0_5_30_120',
        'phase_1': '0~5분 진입검증: 가격반응/체결지속/VWAP 방어 없으면 빠른정리',
        'phase_2': '5~30분 수익확인: +0.5~1.2% 도달·VWAP/EMA 유지 시 보유',
        'phase_3': '30~120분 확장: +1.2% 이상 도달 후 추세 유지 시 보호익절로 연장',
        'take_profit_pct': 1.20,
        'extended_target_pct': ext_tp,
        'extended_take_profit_pct': ext_tp,
        'protect_trigger_pct': 0.70,
        'protect_floor_pct': 0.35,
        'stop_loss_pct': -0.60,
        'hard_loss_guard_pct': -0.90,
        'time_exit_minutes': max_min,
        'time_exit_min': max_min,
        'early_validation_minutes': 5,
        'mid_validation_minutes': 30,
        'adaptive_hold_note': '나쁜 후보는 0~5분 검증 실패로 빨리 정리하고, +1.2% 이상 간 후보만 30~120분 확장 관찰',
    }

# v533 removed legacy unused function: build_event

def _priority_score(row: Dict[str, Any], core_hits: List[Tuple[str, List[str]]], info_bad: List[str], hard_bad: List[str]) -> float:
    score = 0.0
    score += fnum(row.get("scanner_priority_score"), default=0.0)
    score += min(30.0, max(0.0, fnum(row.get("change_3m"), default=0.0) * 8))
    score += min(30.0, max(0.0, fnum(row.get("change_5m"), default=0.0) * 6))
    score += min(25.0, max(0.0, fnum(row.get("change_15m"), default=0.0) * 3))
    score += min(20.0, max(0.0, fnum(row.get("turnover_24h"), default=0.0) / 400_000_000))
    score += 25.0 * len(core_hits)
    if info_bad:
        score += 15.0
    if hard_bad:
        score -= 35.0
    return round(score, 3)


def _make_priority_request(t: str, row: Dict[str, Any], bucket: str, priority: float, need: List[str], core_hits: List[Tuple[str, List[str]]], reasons: List[str]) -> Dict[str, Any]:
    return {
        "ticker": t,
        "bucket": bucket,
        "priority": round(priority, 3),
        "need": need,
        "core_strategies": [k for k, _ in core_hits],
        "core_strategy_labels": [STRATEGIES.get(k, k) for k, _ in core_hits],
        "reasons": reasons[:8],
        "score": fnum(row.get("scanner_priority_score"), default=0.0),
        "change_3m": fnum(row.get("change_3m"), default=0.0),
        "change_5m": fnum(row.get("change_5m"), default=0.0),
        "change_15m": fnum(row.get("change_15m"), default=0.0),
        "turnover_24h": fnum(row.get("turnover_24h"), default=0.0),
        "updated_ts": now_ts(),
        "source": "strategy_worker",
    }


def _cheap_gate(row: Dict[str, Any], core_hits: List[Tuple[str, List[str]]], hard_bad: List[str]) -> Tuple[bool, str]:
    """정보를 붙일 가치가 있는 후보인지 cheap 재료만으로 먼저 가른다.
    개수 제한이 아니라 우선순위 gate다.
    - S 코어가 맞는 후보는 정보필요 후보
    - 코어가 아직 안 맞아도 돈/흐름/캔들/VWAP가 좋은 후보는 high 후보
    - 나머지는 WS/micro를 붙일 필요 없는 cheap 탈락 후보
    """
    if hard_bad:
        return False, "hard_block"
    if core_hits:
        return True, "core_hit"
    ch3=fnum(row.get("change_3m"), default=0.0)
    ch5=fnum(row.get("change_5m"), default=0.0)
    ch15=fnum(row.get("change_15m"), default=0.0)
    money=fnum(row.get("turnover_24h"), default=0.0)
    score=fnum(row.get("scanner_priority_score"), default=0.0)
    good_flow = (ch3 >= 0.35 and ch5 >= 0.45) or (ch5 >= 0.70) or (ch15 >= 1.20)
    good_position = fnum(row.get("vwap_gap_pct"), default=-9.0) >= -0.10 and fnum(row.get("ema5_gap_pct"), default=-9.0) >= -0.12
    good_signal = bool(row.get("volume_expanding") or row.get("breakout_hint") or row.get("sweep_reclaim_hint"))
    good_money = money >= 500_000_000
    if (good_flow and good_position and (good_signal or good_money)) or (score >= 88 and good_flow):
        return True, "high_cheap"
    return False, "cheap_drop"



# =============================================================================
# strategy_worker v0.87 / v510: clean single-pass canonical spine
# - Does not call legacy run_once / tail overrides.
# - Reads feature/orderflow once, builds base/spike lanes independently, merges once.
# - Writes paper_candidates_latest once. No old_latest re-mix, no archive runtime append.
# - Publishes candidate_reason / recheck / lifecycle / summary from the same final rows.
# =============================================================================
VERSION = "strategy_worker_v0.145"
MAIN_VERSION = "v2.13.474"
MAIN_DEPLOY_VERSION = "v2.13.461"
MAIN_BOT_VERSION = "수익형 v2.13.461"
V510_SCHEMA = "strategy_canonical_spine_v525_latest_only_publish"
CANDIDATE_REASON_COMPACT_CACHE = BASE_DIR / "clean_candidate_reason_compact_cache.json"
CANDIDATE_REASON_TEXT_CACHE = BASE_DIR / "clean_candidate_reason_text_cache.txt"
CANDIDATE_REASON_STATE_CACHE = BASE_DIR / "clean_candidate_reason_state_cache.json"
CANDLE_URGENT_TARGETS = BASE_DIR / "clean_candle_urgent_targets.json"
CANDLE_URGENT_RESULT = BASE_DIR / "clean_candle_urgent_result.json"
S1_LIFECYCLE_TRACE = BASE_DIR / "clean_s1_lifecycle_trace.json"
S1_LIFECYCLE_STATE = BASE_DIR / "clean_s1_lifecycle_state.json"
# v512: main command readers have used different historical names. We write the same object
# to explicit alias files, but all aliases are produced from one final_rows payload.
# v525: legacy candidate_reason/lifecycle alias cache files are no longer published.
# Main commands read paper_candidates_latest.jsonl directly. Keeping these lists empty prevents
# old cache readers from being revived by stale files.
CANDIDATE_REASON_ALIAS_FILES: List[Path] = []
S1_LIFECYCLE_ALIAS_FILES: List[Path] = []
RECHECK_CACHE = BASE_DIR / "clean_recheck_candidates_cache.json"
RECHECK_STATE = BASE_DIR / "clean_recheck_candidates_state.json"
CANONICAL_STRATEGY_SUMMARY = BASE_DIR / "clean_strategy_canonical_summary.json"
V510_TRACE = BASE_DIR / "clean_strategy_v510_single_pass_trace.json"

_STAGE_ORDER = {"S1": 3, "S2": 2, "S3": 1}


def _v510_num(*vals: Any, default: float = 0.0) -> float:
    return fnum(*vals, default=default)


def _v510_stage(row: Dict[str, Any]) -> str:
    st = str(row.get("s_stage") or row.get("candidate_grade") or row.get("stage") or row.get("grade") or "S3").upper()
    return st if st in ("S1", "S2", "S3") else "S3"


def _v510_uniq(xs: List[Any], maxn: int = 12) -> List[str]:
    out: List[str] = []
    seen = set()
    for x in xs or []:
        s = str(x or "").strip()
        if not s or s in seen:
            continue
        seen.add(s); out.append(s)
        if len(out) >= maxn:
            break
    return out


def _v510_bool(v: Any) -> bool:
    if isinstance(v, bool): return v
    return str(v).lower() in {"1", "true", "yes", "ok", "fresh", "신선"}


def _v510_age_from_of(of: Dict[str, Any], *keys: str, default: float = 999999.0) -> float:
    return _v510_num(*[of.get(k) for k in keys], default=default)



def _v521_file_age(path: Path) -> float:
    try:
        return max(0.0, now_ts() - path.stat().st_mtime)
    except Exception:
        return 999999.0


def _v521_row_age(row: Dict[str, Any], cache_age: float, *ts_keys: str) -> float:
    # 999999 means "age field missing", not "really stale".
    for k in ("age_sec", "cache_age_sec", "row_age_sec", "updated_age_sec"):
        a = _v510_num(row.get(k), default=-1.0)
        if 0 <= a < 999998:
            return a
    for k in ts_keys or ("updated_ts", "ts", "timestamp", "created_at", "event_ts"):
        ts = _v510_num(row.get(k), default=0.0)
        if ts > 1_000_000_000:
            return max(0.0, now_ts() - ts)
    return cache_age


def _v521_load_map_with_cache_age(path: Path, cache_name: str) -> Dict[str, Dict[str, Any]]:
    obj = load_json(path, {}) or {}
    c_age = _v521_file_age(path)
    out = map_rows(obj)
    top_ts = _v510_num(obj.get("updated_ts") if isinstance(obj, dict) else 0.0, default=0.0)
    top_age = max(0.0, now_ts() - top_ts) if top_ts > 1_000_000_000 else c_age
    for t, r in list(out.items()):
        rr = dict(r)
        rr.setdefault("_cache_name", cache_name)
        rr.setdefault("_cache_age_sec", min(c_age, top_age))
        rr.setdefault("_cache_updated_ts", top_ts or now_ts() - c_age)
        out[t] = rr
    return out


def _v521_hot_map() -> Dict[str, Dict[str, Any]]:
    out = _v521_load_map_with_cache_age(SCANNER_HOT, "scanner_hot")
    c_age = _v521_file_age(SCANNER_HOT)
    for t, r in list(out.items()):
        rr = dict(r)
        if "scanner_change_1m_pct" in rr and "change_1m" not in rr:
            rr["change_1m"] = rr.get("scanner_change_1m_pct")
        if "scanner_change_3m_pct" in rr and "change_3m" not in rr:
            rr["change_3m"] = rr.get("scanner_change_3m_pct")
        rr.setdefault("hot_signal_age_sec", _v521_row_age(rr, c_age, "updated_ts", "ts", "timestamp"))
        rr.setdefault("hot_fresh", c_age <= 10)
        rr.setdefault("scanner_hot_fresh", c_age <= 10)
        out[t] = rr
    return out


def _v521_overlay_feature(src: Dict[str, Any], hot: Dict[str, Any]) -> Dict[str, Any]:
    if not hot:
        return dict(src)
    merged = dict(src)
    for k in ("scanner_hot_score", "scanner_hot_rank_1m", "scanner_hot_rank_3m", "hot_signal_age_sec", "hot_fresh", "scanner_hot_fresh"):
        if merged.get(k) in (None, "", 0, 0.0, 999999, 999999.0):
            merged[k] = hot.get(k)
    if merged.get("change_1m") in (None, "", 0, 0.0) and hot.get("change_1m") is not None:
        merged["change_1m"] = hot.get("change_1m")
    if merged.get("change_3m") in (None, "", 0, 0.0) and hot.get("change_3m") is not None:
        merged["change_3m"] = hot.get("change_3m")
    merged["_scanner_hot_cache_age_sec"] = hot.get("_cache_age_sec", _v521_file_age(SCANNER_HOT))
    return merged


def _v521_age_from_sources(primary: Dict[str, Any], secondary: Dict[str, Any], cache_key: str, keys: Tuple[str, ...], default_cache_age: float = 999999.0) -> float:
    for row in (primary, secondary):
        for k in keys:
            a = _v510_num(row.get(k), default=-1.0)
            if 0 <= a < 999998:
                return a
    for row in (primary, secondary):
        c = _v510_num(row.get(cache_key), row.get("_cache_age_sec"), default=-1.0)
        if 0 <= c < 999998:
            return c
    return default_cache_age


def _v521_value_present(row: Dict[str, Any], *keys: str) -> bool:
    for k in keys:
        v = row.get(k)
        if v in (None, "", [], {}):
            continue
        try:
            if float(str(v).replace(",", "").replace("%", "")) != 0:
                return True
        except Exception:
            return True
    return False



def _v522_parse_age_item(item: Any) -> Tuple[str, float]:
    s = str(item or "").strip()
    m = re.search(r'(hot|micro|orderflow|price|quote|paper)\s+([0-9]+(?:\.[0-9]+)?)s', s)
    if not m:
        return s, 999999.0
    return m.group(1), _v510_num(m.group(2), default=999999.0)


def _v522_filter_stale_items(items: List[Any], strict: bool = True) -> List[str]:
    # A stale reason is valid only when the component is actually over TTL.
    ttl = {
        "hot": 35.0 if strict else 60.0,
        "micro": 20.0,
        "orderflow": 20.0,
        "price": 30.0,
        "quote": 20.0,
        "paper": 45.0,
    }
    out: List[str] = []
    for raw in items or []:
        comp, a = _v522_parse_age_item(raw)
        if comp in ttl:
            if a >= ttl[comp]:
                out.append(f"{comp} {a:.1f}s")
            continue
        s = str(raw or "").strip()
        if s:
            out.append(s)
    return _v510_uniq(out, 8)


def _v522_strip_freshness_text(raw: List[Any]) -> List[str]:
    # Old route may still pass "신선도재확인:hot 0.8s" as an existing reason.
    # Remove all freshness strings here; the single gate will re-add only real stale items.
    out: List[str] = []
    for x in raw or []:
        s = str(x or "").strip()
        if not s:
            continue
        if "신선" in s or "final_entry_gate" in s:
            continue
        out.append(s)
    return out


def _v520_age_ok(age_val: float, limit: float) -> bool:
    return age_val < 999998 and age_val <= limit


def _v520_bool_any(*vals: Any) -> bool:
    for v in vals:
        try:
            if _v510_bool(v):
                return True
        except Exception:
            continue
    return False


def _v520_fresh_stale_items(src: Dict[str, Any], of: Dict[str, Any], hot_age: float, micro_age: float, order_age: float, price_age: float, quote_age: float, sealed_price: float, strict: bool = True) -> List[str]:
    """v522 single freshness gate.
    Age under TTL is fresh. Value/cache presence is a bonus, not a second stale route.
    """
    hot_cache_age = _v510_num(src.get("_scanner_hot_cache_age_sec"), src.get("_cache_age_sec"), default=999999.0)
    of_cache_age = _v510_num(of.get("_cache_age_sec"), default=999999.0)

    ch1 = _v510_num(src.get("change_1m"), src.get("price_change_1m"), src.get("scanner_change_1m_pct"), default=0.0)
    ch3 = _v510_num(src.get("change_3m"), src.get("price_change_3m"), src.get("scanner_change_3m_pct"), default=0.0)
    hot_present = max(abs(ch1), abs(ch3)) > 0 or _v521_value_present(src, "scanner_hot_score", "scanner_hot_rank_1m", "scanner_hot_rank_3m")
    micro_present = _v521_value_present(of, "buy_ratio", "micro_trade_buy_ratio_30", "trade_buy_ratio", "spread_pct", "best_bid", "best_ask")
    order_present = micro_present or _v521_value_present(of, "orderflow_score", "sell_wall_ratio", "trade_count", "buy_count", "sell_count")
    quote_present = sealed_price > 0 or _v521_value_present(of, "quote_price", "current_price", "mid_price", "best_bid", "best_ask")
    price_present = sealed_price > 0 or _v521_value_present(src, "current_price", "price", "trade_price", "close", "last_price")

    # Missing embedded age uses cache age. If either age is fresh or value exists with fresh cache, it is fresh.
    hot_ok = bool(src.get("hot_fresh") or src.get("scanner_hot_fresh")) or _v520_age_ok(hot_age, 35) or (hot_cache_age <= 12 and hot_present)
    micro_ok = bool(of.get("micro_fresh")) or _v520_age_ok(micro_age, 20) or (of_cache_age <= 12 and micro_present)
    order_ok = bool(of.get("orderflow_fresh") or of.get("trade_fresh")) or _v520_age_ok(order_age, 20) or (of_cache_age <= 12 and order_present)
    quote_ok = bool(of.get("quote_fresh") or of.get("ws_fresh") or src.get("quote_fresh") or src.get("ws_fresh")) or _v520_age_ok(quote_age, 20) or (of_cache_age <= 12 and quote_present)
    price_ok = bool(src.get("price_reaction_fresh") or src.get("feature_fresh")) or _v520_age_ok(price_age, 30) or price_present

    stale: List[str] = []
    if strict and not hot_ok:
        stale.append(f"hot {hot_age:.1f}s")
    if not quote_ok:
        stale.append(f"quote {quote_age:.1f}s")
    if not micro_ok:
        stale.append(f"micro {micro_age:.1f}s")
    if strict and not order_ok:
        stale.append(f"orderflow {order_age:.1f}s")
    if not price_ok:
        stale.append(f"price {price_age:.1f}s")
    return _v522_filter_stale_items(stale, strict=strict)[:5]




def _v520_split_reasons(raw: List[Any], stale: List[str]) -> Tuple[List[str], List[str]]:
    decision: List[str] = []
    structure: List[str] = []
    raw = _v522_strip_freshness_text(raw)
    for x in raw or []:
        s = str(x or "").strip()
        if not s:
            continue
        if s.startswith("구조:"):
            structure.append(s.replace("구조:", "", 1).strip())
            continue
        if "fresh urgent" in s or "급등 확인" in s:
            decision.append("급등확인")
            continue
        decision.append(s)
    stale = _v522_filter_stale_items(stale, strict=True)
    if stale:
        decision.append("신선도재확인:" + "/".join(stale[:3]))
    return _v510_uniq(decision, 12), _v510_uniq(structure, 8)


def _v520_normalize_reason_row(r: Dict[str, Any]) -> Dict[str, Any]:
    stale = _v522_filter_stale_items([str(x).strip() for x in (r.get("stale_reasons") or []) if str(x).strip()], strict=True)
    reasons, structures = _v520_split_reasons(list(r.get("s_stage_reasons") or []) + list(r.get("block_reasons") or []), stale)
    base_structures = r.get("structure_tags") if isinstance(r.get("structure_tags"), list) else []
    r["structure_tags"] = _v510_uniq(list(base_structures) + structures, 10)
    r["s_stage_reasons"] = reasons
    r["reason"] = " / ".join(reasons)
    r["freshness_status"] = "recheck" if stale else "fresh"
    if stale:
        r["stale_reasons"] = stale
    else:
        r["stale_reasons"] = []
    ctx = r.get("entry_context") if isinstance(r.get("entry_context"), dict) else {}
    ctx = dict(ctx)
    ctx["structure_tags"] = r["structure_tags"]
    ctx["reasons"] = reasons
    ctx["freshness_status"] = r["freshness_status"]
    ctx["stale_reasons"] = r["stale_reasons"]
    r["entry_context"] = ctx
    return r


def _v510_price_reaction(row: Dict[str, Any], of: Dict[str, Any]) -> float:
    return _v510_num(of.get("price_reaction_pct"), of.get("reaction_pct"), row.get("price_reaction_pct"), row.get("change_1m"), row.get("price_change_1m"), default=0.0)


def _v510_spread(of: Dict[str, Any], row: Dict[str, Any]) -> float:
    return _v510_num(of.get("spread_pct"), row.get("spread_pct"), default=99.0)


def _v510_buy(of: Dict[str, Any], row: Dict[str, Any]) -> float:
    return _v510_num(of.get("buy_ratio"), of.get("micro_trade_buy_ratio_30"), row.get("buy_ratio"), default=0.0)


def _v524_sustain_detail(of: Dict[str, Any], row: Dict[str, Any]) -> Tuple[float, str, bool]:
    real_keys = (
        "buy_sustain_1m", "buy_sustain_60s", "buy_persist_1m",
        "buy_flow_1m", "buy_pressure_1m", "micro_buy_sustain_1m",
    )
    for k in real_keys:
        v = _v510_num(of.get(k), default=-1.0)
        if v >= 0:
            return v, k, True
    for k in real_keys:
        v = _v510_num(row.get(k), default=-1.0)
        if v >= 0:
            return v, k, True
    fb = _v510_num(of.get("buy_ratio"), of.get("micro_trade_buy_ratio_30"), row.get("buy_ratio"), default=_v510_buy(of, row))
    return fb, "buy_ratio_fallback", False


def _v510_sustain(of: Dict[str, Any], row: Dict[str, Any]) -> float:
    return _v524_sustain_detail(of, row)[0]


def _v510_structure_tags(row: Dict[str, Any]) -> List[str]:
    tags: List[str] = []
    if row.get("sweep_reclaim_hint"): tags += ["저점유동성쓸림", "쓸림후빠른회복"]
    if row.get("breakout_hint"): tags += ["저항돌파후재테스트"]
    if _v510_num(row.get("vwap_gap_pct"), default=-9.0) >= -0.05: tags.append("VWAP방어")
    if _v510_num(row.get("ema5_gap_pct"), row.get("ma5_gap_pct"), default=-9.0) >= -0.10: tags.append("EMA방어")
    if row.get("volume_expanding"): tags.append("거래량확장")
    if _v510_num(row.get("change_3m"), default=0.0) >= 0.35: tags.append("돈흐름재유입")
    return _v510_uniq(tags, 8)


def _v510_risk_tags(row: Dict[str, Any], of: Dict[str, Any], hard: List[str]) -> List[str]:
    tags: List[str] = []
    spread = _v510_spread(of, row)
    buy = _v510_buy(of, row)
    if spread >= 0.35: tags.append("스프레드부담")
    if spread >= 0.35: tags.append("미끄러짐부담")
    if buy and buy < 0.58: tags.append("매수체결약함")
    if row.get("long_upper_wick"): tags.append("윗꼬리위험")
    if _v510_num(row.get("day_pos_pct"), default=50.0) > 94 and _v510_num(row.get("change_1m"), default=0.0) <= 0.05:
        tags.append("되돌림위험")
    for h in hard or []:
        if "매도" in h: tags.append("매도압력부담")
        if "스프레드" in h: tags.append("스프레드부담")
    return _v510_uniq(tags, 8)


def _v510_event_id(ticker: str, skey: str, lane: str, nowv: float) -> str:
    return f"{ticker}:{lane}:{skey}:{int(nowv // 10)}"



# =============================================================================
# v529: S1 체크리스트 inline helper
# - 함수 덮어쓰기/override 없음.
# - _v510_make_row/_v510_final_gate/_v510_publish 본체에서 직접 호출한다.
# - 조건값 변경 없음. 진단값만 row에 봉인한다.
# =============================================================================
def _v529_core_ok_from_row(row: Dict[str, Any]) -> bool:
    keys = row.get("matched_strategy_keys") if isinstance(row.get("matched_strategy_keys"), list) else []
    sk = str(row.get("strategy_key") or "")
    if keys:
        return any(str(k) and not str(k).startswith("hot_rank") for k in keys)
    return bool(sk and not sk.startswith("hot_rank"))


def _v544_is_hot_rank_row(row: Dict[str, Any], labels: List[Any], keys: List[Any]) -> bool:
    hay = " ".join(str(x) for x in ([row.get("strategy_label"), row.get("strategy"), row.get("strategy_key")] + list(labels or []) + list(keys or []))).lower()
    return ("hot-rank" in hay) or ("hot_rank" in hay) or ("hot rank" in hay)


def _v545_guard_text(row: Dict[str, Any], labels: List[Any], keys: List[Any], risks: List[Any], structures: List[Any]) -> str:
    return " ".join(str(x) for x in ([
        row.get("strategy_label"), row.get("strategy"), row.get("strategy_key"), row.get("paper_strategy_key")
    ] + list(labels or []) + list(keys or []) + list(risks or []) + list(structures or []))).lower()


def _v545_has_any(hay: str, words: Tuple[str, ...]) -> bool:
    return any(str(w).lower() in hay for w in words)


def _v545_strategy_recheck_reasons(row: Dict[str, Any], react: float, buy: float, sustain: float, sustain20: float, spread: float, slippage: float, chg30: float, chg60: float, risks: List[Any], structures: List[Any], labels: List[Any], keys: List[Any]) -> Tuple[List[str], List[str]]:
    """v545 multi-strategy S1 quality guard.

    This reflects v543 win/loss analysis, but never blocks by itself.
    Compound loss-like S1 rows are moved to S2 recheck; very weak low-confidence rows
    may be marked as S3 observe. Global S1/S2/S3 thresholds and exit rules are unchanged.
    """
    hay = _v545_guard_text(row, labels, keys, risks, structures)
    risk_txt = " ".join(str(x) for x in (risks or []))
    struct_txt = " ".join(str(x) for x in (structures or []))
    spread_bad = spread >= 0.45 or slippage >= 0.45 or "스프레드부담" in risk_txt or "미끄러짐부담" in risk_txt
    spread_severe = spread >= 0.65 or slippage >= 0.65
    sustain_weak = sustain < 0.70 or sustain20 < 0.55
    buy_weak = buy < 0.70
    chase_like = react >= 0.30 or chg30 >= 0.45 or chg60 >= 1.20
    vwap_ema = ("VWAP" in struct_txt or "EMA" in struct_txt)
    money_structure = ("돈흐름" in struct_txt or "거래량" in struct_txt)

    recheck: List[str] = []
    observe: List[str] = []

    # 1) hot-rank 급등 재확인: v543에서 손실군은 추격성 가격반응 + 약한 지속 + 나쁜 스프레드/미끄러짐이 반복됨.
    if _v545_has_any(hay, ("hot-rank", "hot_rank", "hot rank", "급등 재확인")):
        if spread_bad and sustain_weak and chase_like:
            recheck.append("재확인: hot-rank 추격+스프레드/지속약함")
        if spread_severe and (buy_weak or sustain_weak):
            recheck.append("재확인: hot-rank 높은 미끄러짐+체결확인 부족")

    # 2) 주도흐름 유동보유: 단순 체결/스프레드 차이는 작았고, 손실군은 고점권/되돌림/채널상단 위험이 반복됨.
    if _v545_has_any(hay, ("leader_flow_adaptive_hold", "주도흐름 유동보유")):
        overheat_hits = sum(1 for w in ("고점권가격반응약함", "되돌림위험", "채널상단과열", "윗꼬리위험") if w in risk_txt or w in struct_txt)
        if overheat_hits >= 2:
            recheck.append("재확인: 주도흐름 고점권/되돌림 위험")
        elif overheat_hits >= 1 and chase_like and sustain_weak:
            recheck.append("재확인: 주도흐름 추격+지속 약화")

    # 3) 돈흐름 재가속: 성과는 손실우세이나 단순 평균값 차이는 애매함.
    #    그래서 최근반복손실/하드손실/윗꼬리 같은 명시 위험이 있고 확인값이 충분치 않을 때만 재확인.
    if _v545_has_any(hay, ("money_reaccel", "pullback_reaccel", "돈흐름 재가속")):
        loss_like = _v545_has_any(risk_txt, ("최근반복손실", "하드손실", "윗꼬리위험", "매도압력"))
        structure_ok = bool(vwap_ema and money_structure and buy >= 0.85 and sustain >= 0.75)
        if loss_like and not structure_ok:
            recheck.append("재확인: 돈흐름 손실유사 위험+확인부족")
        elif ("윗꼬리위험" in risk_txt or "매도압력" in risk_txt) and (buy < 0.80 or sustain < 0.75):
            recheck.append("재확인: 돈흐름 윗꼬리/매도압력")

    # 4) 돌파 초입: 표본은 작지만 손실군에 거래량없는돌파가 보임. 스프레드/미끄러짐과 같이 있을 때만 재확인.
    if _v545_has_any(hay, ("breakout_early", "돌파 초입")):
        no_volume_break = "거래량없는돌파" in risk_txt or "거래량없는돌파" in struct_txt
        if no_volume_break and (spread_bad or sustain_weak):
            recheck.append("재확인: 돌파 초입 거래량없는돌파+위험부담")

    # 5) 저점 VWAP 회복: 표본은 작지만 손익비가 나빴고, 손실군은 스프레드/미끄러짐+체결 약함이 반복됨.
    #    아주 약한 조합은 paper 즉시진입보다 S3 관찰로 내린다.
    if _v545_has_any(hay, ("sweep_vwap", "저점 vwap", "저점 VWAP")):
        if spread_bad and (buy < 0.75 or sustain < 0.70):
            observe.append("관찰: 저점 VWAP 스프레드/체결약함")

    return _v510_uniq(recheck, 5), _v510_uniq(observe, 3)


def _v532_build_canonical_entry_decision(row: Dict[str, Any]) -> Dict[str, Any]:
    """v535 canonical S1 판단 원천.
    normal_common은 기존 안정형 기준을 유지하고, 급등형은 별도 entry_profile로 paper-test한다.
    """
    react = _v510_num(row.get("price_reaction_pct"), default=0.0)
    buy = _v510_num(row.get("buy_ratio"), default=0.0)
    sustain = _v510_num(row.get("buy_sustain_1m"), default=0.0)
    sustain20 = _v510_num(row.get("buy_sustain_20s"), row.get("buy_ratio_20s"), default=sustain)
    buy10 = _v510_num(row.get("buy_ratio_10s"), default=buy)
    spread = _v510_num(row.get("spread_pct"), default=99.0)
    slippage = _v510_num(row.get("slippage_pct"), default=spread)
    chg10 = _v510_num(row.get("price_chg_10s"), default=0.0)
    chg20 = _v510_num(row.get("price_chg_20s"), default=0.0)
    chg30 = _v510_num(row.get("price_chg_30s"), default=0.0)
    chg60 = _v510_num(row.get("price_chg_60s"), row.get("change_1m_pct"), default=0.0)
    accel10 = _v510_num(row.get("price_accel_10s"), default=0.0)
    accel20 = _v510_num(row.get("price_accel_20s"), default=0.0)
    spread_widen = _v510_num(row.get("spread_widening_10s"), default=0.0)
    sustain_real = bool(row.get("buy_sustain_1m_real"))
    stale = row.get("stale_reasons") if isinstance(row.get("stale_reasons"), list) else []
    risks = row.get("risk_tags") if isinstance(row.get("risk_tags"), list) else []
    structures = row.get("structure_tags") if isinstance(row.get("structure_tags"), list) else []
    hard_like = [str(x) for x in risks if any(w in str(x) for w in ("매도압력", "스프레드부담", "미끄러짐부담"))]
    upper_wick = any("윗꼬리" in str(x) for x in risks)
    sell_pressure = any("매도압력" in str(x) for x in risks)
    vwap_ema_ok = any(("VWAP" in str(x) or "EMA" in str(x)) for x in structures)
    money_ok = any(("돈흐름" in str(x) or "거래량" in str(x)) for x in structures)
    matched_labels = row.get("matched_strategy_labels") if isinstance(row.get("matched_strategy_labels"), list) else []
    matched_keys = row.get("matched_strategy_keys") if isinstance(row.get("matched_strategy_keys"), list) else []
    strategy_label = row.get("strategy_label") or row.get("strategy") or row.get("strategy_key") or "-"

    def ok_missing(checks: List[Dict[str, Any]]) -> Tuple[bool, List[Dict[str, Any]], List[str]]:
        missing = [c for c in checks if not c.get("ok")]
        return (len(missing) == 0), missing, [str(c.get("reason")) for c in missing if str(c.get("reason") or "").strip()]

    normal_checks = [
        {"name": "전략태그", "ok": True, "value": matched_labels or strategy_label, "need": "tag only", "reason": "태그", "weight": 0},
        {"name": "신선도", "ok": not bool(stale), "value": stale[:3] if stale else "-", "need": "fresh", "reason": "신선도 재확인:" + "/".join(str(x) for x in stale[:3]) if stale else "통과", "weight": 2},
        {"name": "가격반응", "ok": react >= 0.35, "value": round(react,4), "need": ">=0.35", "reason": f"가격반응 {react:+.2f}% < +0.35%", "weight": 1},
        {"name": "매수체결", "ok": buy >= 0.70, "value": round(buy,4), "need": ">=0.70", "reason": f"매수체결 {buy:.2f} < 0.70", "weight": 1},
        {"name": "1분지속", "ok": bool(sustain_real and sustain >= 0.70), "value": round(sustain,4), "need": "real >=0.70", "reason": ("1분지속 실측없음" if not sustain_real else f"1분지속 {sustain:.2f} < 0.70"), "weight": 1},
        {"name": "스프레드", "ok": spread <= 0.18, "value": round(spread,4), "need": "<=0.18", "reason": f"스프레드 {spread:.2f}% > 0.18%", "weight": 1},
        {"name": "미끄러짐", "ok": slippage <= 0.20, "value": round(slippage,4), "need": "<=0.20", "reason": f"미끄러짐 {slippage:.2f}% > 0.20%", "weight": 1},
        {"name": "강한위험", "ok": not bool(hard_like), "value": hard_like[:3], "need": "none", "reason": "위험부담:" + "/".join(hard_like[:3]) if hard_like else "통과", "weight": 1},
    ]
    normal_ok, normal_missing, normal_reasons = ok_missing(normal_checks)

    spike_signal = bool(chg20 >= 0.30 or chg30 >= 0.45 or react >= 0.70 or accel10 >= 0.18 or accel20 >= 0.22)
    late_chase = bool((chg60 >= 2.50 and (buy10 < 0.55 or spread > 0.85 or spread_widen > 0.35)) or upper_wick or (spread > 1.10) or (slippage > 1.20))
    spike_fast_checks = [
        {"name": "신선도", "ok": not bool(stale), "value": stale[:3] if stale else "-", "need": "fresh", "reason": "신선도 재확인:" + "/".join(str(x) for x in stale[:3]) if stale else "통과", "weight": 2},
        {"name": "급등초입", "ok": spike_signal, "value": {"chg20": round(chg20,3), "chg30": round(chg30,3), "react": round(react,3), "accel10": round(accel10,3)}, "need": "20s>=0.30 or 30s>=0.45 or react>=0.70", "reason": "급등초입 신호 부족", "weight": 1},
        {"name": "매수체결", "ok": buy >= 0.55, "value": round(buy,4), "need": ">=0.55", "reason": f"급등형 매수체결 {buy:.2f} < 0.55", "weight": 1},
        {"name": "짧은매수", "ok": (sustain20 >= 0.55 or buy10 >= 0.65), "value": {"buy10": round(buy10,3), "sustain20": round(sustain20,3)}, "need": "20s>=0.55 or 10s>=0.65", "reason": f"짧은 매수세 부족 10s {buy10:.2f} / 20s {sustain20:.2f}", "weight": 1},
        {"name": "스프레드", "ok": spread <= 0.85, "value": round(spread,4), "need": "<=0.85", "reason": f"급등형 스프레드 {spread:.2f}% > 0.85%", "weight": 1},
        {"name": "미끄러짐", "ok": slippage <= 0.85, "value": round(slippage,4), "need": "<=0.85", "reason": f"급등형 미끄러짐 {slippage:.2f}% > 0.85%", "weight": 1},
        {"name": "최소체결", "ok": buy >= 0.40 and sustain20 >= 0.35, "value": {"buy": round(buy,3), "sustain20": round(sustain20,3)}, "need": "buy>=0.40 & 20s>=0.35", "reason": "급등형 최소 체결/지속 미달", "weight": 2},
        {"name": "늦은추격", "ok": not late_chase, "value": {"chg60": round(chg60,3), "spread_widen": round(spread_widen,3)}, "need": "not late chase", "reason": "늦은추격 위험", "weight": 2},
        {"name": "강한위험", "ok": not bool(sell_pressure or upper_wick), "value": risks[:3], "need": "none", "reason": "급등형 매도압력/윗꼬리 위험", "weight": 2},
    ]
    spike_fast_ok, spike_fast_missing, spike_fast_reasons = ok_missing(spike_fast_checks)

    runner_signal = bool(react >= 0.80 or chg60 >= 1.20 or chg30 >= 0.90)
    spike_runner_checks = [
        {"name": "신선도", "ok": not bool(stale), "value": stale[:3] if stale else "-", "need": "fresh", "reason": "신선도 재확인:" + "/".join(str(x) for x in stale[:3]) if stale else "통과", "weight": 2},
        {"name": "runner신호", "ok": runner_signal, "value": {"react": round(react,3), "chg60": round(chg60,3)}, "need": "react>=0.80 or 60s>=1.20", "reason": "runner 가격힘 부족", "weight": 1},
        {"name": "매수체결", "ok": buy >= 0.68, "value": round(buy,4), "need": ">=0.68", "reason": f"runner 매수체결 {buy:.2f} < 0.68", "weight": 1},
        {"name": "지속", "ok": sustain20 >= 0.65 and sustain >= 0.60, "value": {"20s": round(sustain20,3), "1m": round(sustain,3)}, "need": "20s>=0.65 and 1m>=0.60", "reason": "runner 매수지속 부족", "weight": 1},
        {"name": "스프레드", "ok": spread <= 0.55, "value": round(spread,4), "need": "<=0.55", "reason": f"runner 스프레드 {spread:.2f}% > 0.55%", "weight": 1},
        {"name": "미끄러짐", "ok": slippage <= 0.65, "value": round(slippage,4), "need": "<=0.65", "reason": f"runner 미끄러짐 {slippage:.2f}% > 0.65%", "weight": 1},
        {"name": "구조", "ok": bool(vwap_ema_ok and money_ok), "value": structures[:4], "need": "VWAP/EMA + money", "reason": "runner 구조 부족", "weight": 1},
        {"name": "강한위험", "ok": not bool(sell_pressure or upper_wick), "value": risks[:3], "need": "none", "reason": "runner 매도압력/윗꼬리 위험", "weight": 2},
    ]
    spike_runner_ok, spike_runner_missing, spike_runner_reasons = ok_missing(spike_runner_checks)

    spike_ok = bool(spike_fast_ok or spike_runner_ok)
    spike_watch = bool(spike_signal or runner_signal)
    spike_missing = spike_runner_missing if spike_runner_ok else spike_fast_missing
    spike_reasons = spike_runner_reasons if spike_runner_ok else spike_fast_reasons
    spike_checks = spike_runner_checks if spike_runner_ok else spike_fast_checks

    if normal_ok:
        entry_profile = "normal_common"
        exit_profile = "normal_exit"
        active_checks = normal_checks
        active_missing = normal_missing
        active_reasons = normal_reasons
    elif spike_ok:
        # v536: 급등형 진입은 spike 하나로만 기록한다. fast/runner 세부분류는 exit_reason/성과에서 본다.
        entry_profile = "spike"
        exit_profile = "spike_trailing"
        active_checks = spike_checks
        active_missing = spike_missing
        active_reasons = spike_reasons
    else:
        entry_profile = "watch"
        exit_profile = "watch_exit"
        active_checks = spike_fast_checks if spike_watch else normal_checks
        active_missing = spike_fast_missing if spike_watch else normal_missing
        active_reasons = spike_fast_reasons if spike_watch else normal_reasons

    raw_s1_allowed = bool(normal_ok or spike_ok)
    if raw_s1_allowed:
        recheck_guard_reasons, observe_guard_reasons = _v545_strategy_recheck_reasons(row, react, buy, sustain, sustain20, spread, slippage, chg30, chg60, risks, structures, matched_labels, matched_keys)
    else:
        recheck_guard_reasons, observe_guard_reasons = [], []
    # v547 surgery: S2 재확인은 출력부에서 꾸미지 않고, canonical decision에서 stage로 봉인한다.
    # - raw S1 손실유사 조합은 S2 재확인/S3 관찰로 분리한다.
    # - raw S3라도 구조/확인값이 살아 있고 부족값이 회복 가능한 경우는 S2 재확인으로 남긴다.
    block_score_pre = sum(int(c.get("weight", 1)) for c in active_missing)
    structure_present = bool(matched_labels or matched_keys or structures)
    strong_confirm = bool(buy >= 0.70 and sustain >= 0.70)
    partial_confirm = bool(buy >= 0.55 and sustain >= 0.55)
    severe_risk = bool(spread >= 1.20 or slippage >= 1.20 or (buy < 0.40 and sustain < 0.40))
    recoverable_recheck_reasons: List[str] = []
    if (not observe_guard_reasons) and (not severe_risk) and structure_present:
        if stale and (partial_confirm or react >= 0.05 or spike_signal or runner_signal):
            recoverable_recheck_reasons.append("재확인: 신선도 갱신 대기")
        if (spread > 0.18 or slippage > 0.20) and (strong_confirm or (react >= 0.30 and partial_confirm)):
            recoverable_recheck_reasons.append("재확인: 스프레드/미끄러짐 회복 대기")
        if (buy < 0.70 or sustain < 0.70) and (buy >= 0.55 or sustain >= 0.55) and (react >= 0.05 or spike_signal or runner_signal):
            recoverable_recheck_reasons.append("재확인: 체결/1분지속 회복 대기")
        if react < 0.35 and strong_confirm and (spread <= 0.85 and slippage <= 0.85):
            recoverable_recheck_reasons.append("재확인: 가격반응 확인 대기")
    recoverable_recheck_reasons = _v510_uniq(recoverable_recheck_reasons, 4)
    recheck_all_reasons = _v510_uniq(list(recheck_guard_reasons) + list(recoverable_recheck_reasons), 6)
    guard_reasons = list(recheck_all_reasons) + list(observe_guard_reasons)
    s1_allowed = bool(raw_s1_allowed and not guard_reasons)
    if guard_reasons:
        active_missing = list(active_missing) + [
            {"name": "S2재확인" if str(reason).startswith("재확인") else "S3관찰", "ok": False, "value": reason, "need": "recheck/observe", "reason": reason, "weight": 1}
            for reason in guard_reasons
        ]
        active_reasons = list(active_reasons) + guard_reasons
    block_score = sum(int(c.get("weight", 1)) for c in active_missing)
    s2_recheck = bool((recheck_all_reasons and not observe_guard_reasons) or ((not guard_reasons) and (not severe_risk) and structure_present and block_score <= 6 and ((react >= 0.15 and buy >= 0.55) or spike_signal or runner_signal or strong_confirm)))
    near = bool(block_score <= 3 or bool(recoverable_recheck_reasons))
    passed = [str(c.get("name")) for c in active_checks if c.get("ok")]
    raw_entry_profile = entry_profile
    if guard_reasons:
        entry_profile = "watch"
        exit_profile = "watch_exit"
    return {
        "schema": "canonical_entry_decision_v547_recheck_spine",
        "version": VERSION,
        "strategy_role": "tag",
        "entry_profile": entry_profile,
        "exit_profile": exit_profile,
        "profile_family": "spike" if entry_profile == "spike" else ("normal" if entry_profile == "normal_common" else "watch"),
        "matched_strategy_keys": matched_keys,
        "matched_strategy_labels": matched_labels or [str(strategy_label)],
        "gate_pass": s1_allowed,
        "raw_s1_allowed": raw_s1_allowed,
        "s1_allowed": s1_allowed,
        "s1_recheck_guard": bool(guard_reasons),
        "s1_recheck_guard_reasons": guard_reasons,
        "s1_recheck_reasons": recheck_all_reasons,
        "s2_recheck_reasons": recheck_all_reasons,
        "s1_observe_reasons": observe_guard_reasons,
        "s1_recheck_basis": "v547 surgery: recheck reasons are sealed as visible S2 in canonical stage spine, not patched in output",
        "s2_recheck": bool(s2_recheck and not s1_allowed),
        "recoverable_recheck_reasons": recoverable_recheck_reasons,
        "action": "paper_open_candidate" if s1_allowed else ("recheck" if s2_recheck else "observe"),
        "freshness_ok": not bool(stale),
        "stale_reasons": list(stale),
        "checks": active_checks,
        "passed_conditions": passed,
        "missing_conditions": active_reasons,
        "missing_names": [str(c.get("name")) for c in active_missing],
        "block_count": len(active_missing),
        "block_score": block_score,
        "s1_distance": block_score,
        "s1_near_miss": near,
        "s1_near_miss_level": "near" if near else ("mid" if block_score <= 5 else "far"),
        "display_reasons": active_reasons,
        "profile_decisions": {
            "normal_common": {"pass": normal_ok, "missing": normal_reasons[:6]},
            "spike": {"pass": spike_ok, "missing": spike_reasons[:6], "fast_pass": spike_fast_ok, "runner_pass": spike_runner_ok},
            "watch": {"pass": False, "missing": active_reasons[:6]},
            "raw_entry_profile": raw_entry_profile,
        },
        "metrics": {
            "price_reaction_pct": react,
            "price_chg_10s": chg10,
            "price_chg_20s": chg20,
            "price_chg_30s": chg30,
            "price_chg_60s": chg60,
            "price_accel_10s": accel10,
            "price_accel_20s": accel20,
            "buy_ratio": buy,
            "buy_ratio_10s": buy10,
            "buy_sustain_20s": sustain20,
            "buy_sustain_1m": sustain,
            "buy_sustain_1m_real": sustain_real,
            "spread_pct": spread,
            "slippage_pct": slippage,
            "spread_widening_10s": spread_widen,
        },
        "policy": "v553: entry reasons are separated from risk/recheck/block fields; conditions/exits unchanged.",
    }


def _v532_apply_canonical_entry_decision(row: Dict[str, Any]) -> Dict[str, Any]:
    if not isinstance(row, dict):
        return row
    dec = _v532_build_canonical_entry_decision(row)
    row["canonical_entry_decision"] = dec
    row["common_entry_decision"] = dec
    row["common_entry_pass"] = bool(dec.get("s1_allowed"))
    row["common_entry_schema"] = dec.get("schema")
    row["strategy_role"] = "tag"
    row["entry_profile"] = dec.get("entry_profile")
    row["exit_profile"] = dec.get("exit_profile")
    row["profile_family"] = dec.get("profile_family")
    row["profile_decisions"] = dec.get("profile_decisions", {})
    row["s1_checklist"] = dec.get("checks", [])
    row["s1_passed_conditions"] = dec.get("passed_conditions", [])
    row["s1_missing_conditions"] = dec.get("missing_conditions", [])
    row["s1_missing_names"] = dec.get("missing_names", [])
    row["s1_block_count"] = dec.get("block_count", 0)
    row["s1_block_score"] = dec.get("block_score", 0)
    row["s1_distance"] = dec.get("s1_distance", 0)
    row["s1_near_miss"] = bool(dec.get("s1_near_miss"))
    row["s1_near_miss_level"] = dec.get("s1_near_miss_level")
    row["s1_short_reason"] = " / ".join(str(x) for x in (dec.get("display_reasons") or [])[:4]) if dec.get("display_reasons") else "S1 조건 통과"
    if bool(dec.get("s1_allowed")):
        row["s_stage"] = row["candidate_stage"] = row["candidate_grade"] = row["stage"] = row["grade"] = "S1"
        row["open_eligible"] = True
        row["paper_bot_open"] = True
        row["trade_ready"] = True
    elif bool(dec.get("s2_recheck") or dec.get("action") == "recheck"):
        # v547: 재확인 사유가 있으면 출력 보정이 아니라 canonical stage를 S2로 봉인한다.
        row["s_stage"] = row["candidate_stage"] = row["candidate_grade"] = row["stage"] = row["grade"] = "S2"
        row["open_eligible"] = False
        row["paper_bot_open"] = False
        row["trade_ready"] = False
        row["recheck_state"] = "S2 재확인"
        row["s2_recheck_reasons"] = dec.get("s2_recheck_reasons") or dec.get("s1_recheck_reasons") or []
    elif _v510_stage(row) == "S1":
        row["s_stage"] = row["candidate_stage"] = row["candidate_grade"] = row["stage"] = row["grade"] = "S3"
        row["open_eligible"] = False
        row["paper_bot_open"] = False
        row["trade_ready"] = False
    else:
        st = _v510_stage(row)
        row["s_stage"] = row["candidate_stage"] = row["candidate_grade"] = row["stage"] = row["grade"] = st
        if st != "S1":
            row["open_eligible"] = False
            row["paper_bot_open"] = False
            row["trade_ready"] = False
    ctx = row.get("entry_context") if isinstance(row.get("entry_context"), dict) else {}
    ctx = dict(ctx)
    for k in (
        "canonical_entry_decision", "common_entry_decision", "common_entry_pass", "common_entry_schema", "strategy_role",
        "entry_profile", "exit_profile", "profile_family", "profile_decisions",
        "s1_checklist", "s1_passed_conditions", "s1_missing_conditions", "s1_missing_names",
        "s1_block_count", "s1_block_score", "s1_distance", "s1_near_miss", "s1_near_miss_level", "s1_short_reason", "s2_recheck_reasons", "recheck_state",
    ):
        ctx[k] = row.get(k)
    row["entry_context"] = ctx
    return row


# =============================================================================
# v553: 매수판단 정보 재분류 spine
# - 조건 수치/청산/S1 판정은 바꾸지 않는다.
# - strategy row 안에서 구조/확인/위험/신선도/재확인/차단/진입근거를 분리해 봉인한다.
# - paper_bot은 이 필드만 읽어 알림을 만든다. 위험태그를 진입근거로 출력하지 않는다.
# =============================================================================
def _v553_as_list(v: Any) -> List[str]:
    if v in (None, "", [], {}):
        return []
    raw = v if isinstance(v, list) else [v]
    out: List[str] = []
    for x in raw:
        if isinstance(x, dict):
            txt = str(x.get("reason") or x.get("name") or x.get("value") or "").strip()
        else:
            txt = str(x).strip()
        if txt and txt not in out:
            out.append(txt)
    return out


def _v553_has(txt: str, words: Tuple[str, ...]) -> bool:
    low = str(txt or "").lower()
    return any(str(w).lower() in low for w in words)


def _v553_bucket_reason(txt: str) -> str:
    t = str(txt or "").strip()
    if not t:
        return "other"
    if t.startswith("구조:") or _v553_has(t, ("저점", "쓸림", "VWAP", "EMA", "거래량확장", "돈흐름", "돌파", "재돌파", "주도", "상대강도", "눌림")):
        # 부족/위험 문장에 VWAP 같은 단어가 섞일 수 있으니 위험/부족을 먼저 제외한다.
        if _v553_has(t, ("부족", "미확인", "실패", "위험", "과다", "약함", "대기", "재확인", "차단", "손실", "고점끝물")):
            pass
        else:
            return "structure"
    if t.startswith("재확인") or _v553_has(t, ("갱신 대기", "회복 대기", "확인 대기", "hot-rank 급등 재확인", "신선도 재확인")):
        return "recheck"
    if _v553_has(t, ("스프레드", "미끄러짐", "매도", "윗꼬리", "되돌림", "늦은추격", "추격", "하드손실", "반복손실", "고점끝물", "거래대금부족", "대형주는시장참고")):
        return "risk"
    if _v553_has(t, ("micro", "시세정보", "정보보강", "신선도", "오래됨", "stale", "quote", "ws")):
        return "freshness"
    if _v553_has(t, ("부족", "미달", "약함", "미확인", "과다", "<", ">")):
        return "block"
    return "other"


def _v553_confirm_signals(row: Dict[str, Any], dec: Dict[str, Any]) -> List[str]:
    sig: List[str] = []
    passed = _v553_as_list(dec.get("passed_conditions") or row.get("s1_passed_conditions"))
    metrics = dec.get("metrics") if isinstance(dec.get("metrics"), dict) else {}
    react = _v510_num(metrics.get("price_reaction_pct"), row.get("price_reaction_pct"), default=0.0)
    buy = _v510_num(metrics.get("buy_ratio"), row.get("buy_ratio"), default=-1.0)
    sustain = _v510_num(metrics.get("buy_sustain_1m"), row.get("buy_sustain_1m"), default=-1.0)
    spread = _v510_num(metrics.get("spread_pct"), row.get("spread_pct"), default=99.0)
    slip = _v510_num(metrics.get("slippage_pct"), row.get("slippage_pct"), default=spread)
    if "신선도" in passed or dec.get("freshness_ok"):
        sig.append("신선도 통과")
    if react >= 0.35:
        sig.append(f"가격반응 통과 {react:+.2f}%")
    if buy >= 0.70:
        sig.append(f"매수체결 통과 {buy:.2f}")
    if sustain >= 0.70:
        sig.append(f"1분지속 통과 {sustain:.2f}")
    if spread <= 0.18:
        sig.append(f"스프레드 정상 {spread:.2f}%")
    if slip <= 0.20:
        sig.append(f"미끄러짐 정상 {slip:.2f}%")
    for p in passed:
        if p in {"급등초입", "짧은매수", "runner신호", "구조"} and p not in sig:
            sig.append(str(p) + " 통과")
    return _v510_uniq(sig, 10)


def _v553_apply_reason_taxonomy(row: Dict[str, Any]) -> Dict[str, Any]:
    if not isinstance(row, dict):
        return row
    dec = row.get("canonical_entry_decision") if isinstance(row.get("canonical_entry_decision"), dict) else {}
    raw_reasons = _v553_as_list(row.get("s_stage_reasons") or row.get("reason"))
    structures = _v510_uniq(_v553_as_list(row.get("structure_tags")) + _v553_as_list(row.get("matched_strategy_labels")), 12)
    risk_tags = _v510_uniq(_v553_as_list(row.get("risk_tags")), 12)
    freshness = _v510_uniq(_v553_as_list(row.get("stale_reasons")), 10)
    rechecks = _v510_uniq(_v553_as_list(dec.get("s2_recheck_reasons")) + _v553_as_list(row.get("s2_recheck_reasons")), 10)
    blocks = _v510_uniq(_v553_as_list(dec.get("missing_conditions")) + _v553_as_list(row.get("s1_missing_conditions")), 12)

    # 기존 s_stage_reasons/reason에 섞인 텍스트를 의미별로 분리한다.
    for txt in raw_reasons:
        b = _v553_bucket_reason(txt)
        clean = txt.replace("구조:", "").strip()
        if b == "structure":
            structures.append(clean)
        elif b == "risk":
            risk_tags.append(clean)
        elif b == "freshness":
            freshness.append(clean)
        elif b == "recheck":
            rechecks.append(clean)
        elif b == "block":
            blocks.append(clean)

    structures = _v510_uniq(structures, 12)
    risk_tags = _v510_uniq(risk_tags, 12)
    freshness = _v510_uniq(freshness, 10)
    rechecks = _v510_uniq(rechecks, 10)
    blocks = _v510_uniq(blocks, 12)
    confirm = _v553_confirm_signals(row, dec)

    # 진입근거는 좋은 구조 + 실제 확인 통과만 넣는다. 위험/부족/재확인은 절대 섞지 않는다.
    entry_reasons = _v510_uniq(structures[:5] + confirm[:5], 10)
    if not entry_reasons and bool(dec.get("s1_allowed")):
        entry_reasons = ["최종확인 통과"]

    row["reason_taxonomy_schema"] = "v553_entry_structure_confirm_risk_split"
    row["entry_structure_tags"] = structures
    row["confirm_signals"] = confirm
    row["execution_risk_tags"] = risk_tags
    row["freshness_flags"] = freshness
    row["recheck_reasons"] = rechecks
    row["block_reasons"] = blocks
    row["entry_reasons"] = entry_reasons
    row["final_entry_reasons"] = entry_reasons
    row["trade_ready_reasons"] = entry_reasons if bool(row.get("trade_ready") or row.get("open_eligible") or _v510_stage(row) == "S1") else []
    row["risk_tags"] = risk_tags
    row["structure_risk_tags"] = risk_tags
    row["missing_info"] = _v510_uniq(rechecks + blocks + freshness, 12)
    row["entry_reason_policy"] = "v553: 진입근거는 구조/확인만, 위험·재확인·부족은 별도 필드로 분리"

    ctx = row.get("entry_context") if isinstance(row.get("entry_context"), dict) else {}
    ctx = dict(ctx)
    for k in (
        "reason_taxonomy_schema", "entry_structure_tags", "confirm_signals", "execution_risk_tags",
        "freshness_flags", "recheck_reasons", "block_reasons", "entry_reasons", "final_entry_reasons",
        "trade_ready_reasons", "risk_tags", "structure_risk_tags", "missing_info", "entry_reason_policy",
    ):
        ctx[k] = row.get(k)
    row["entry_context"] = ctx
    return row


# =============================================================================
# v554: structure levels + S2 entry plan spine
# - Conditions/exits are not changed here.
# v555: ENTRY_PLAN_STATE 정의 누락 수정.
# v556: entry plan state를 실제 생애주기 spine으로 안정화.
# - Every strategy row receives structure_levels / entry_plan / risk_reward.
# - S2 means "entry-plan waiting candidate" rather than a vague maybe-candidate.
# =============================================================================
def _v554_price_from_gap(price: float, gap_pct: float) -> float:
    try:
        if price <= 0:
            return 0.0
        denom = 1.0 + (float(gap_pct) / 100.0)
        if abs(denom) < 0.0001:
            return 0.0
        return price / denom
    except Exception:
        return 0.0


def _v554_pct_to_price(price: float, pctv: float) -> float:
    try:
        return price * (1.0 + float(pctv) / 100.0) if price > 0 else 0.0
    except Exception:
        return 0.0


def _v554_pct_between(a: float, b: float) -> float:
    return ((a - b) / b * 100.0) if b else 0.0


def _v554_round_price(x: float) -> float:
    if not x or x <= 0:
        return 0.0
    if x >= 100000:
        return round(x, -2)
    if x >= 10000:
        return round(x, -1)
    if x >= 1000:
        return round(x, 0)
    if x >= 100:
        return round(x, 1)
    if x >= 10:
        return round(x, 2)
    if x >= 1:
        return round(x, 3)
    return round(x, 5)


def _v554_strategy_family(row: Dict[str, Any]) -> str:
    sk = str(row.get("strategy_key") or row.get("paper_strategy_key") or "").lower()
    labels = " ".join(str(x) for x in (row.get("matched_strategy_labels") or [])) + " " + str(row.get("strategy_label") or row.get("strategy") or "")
    hay = (sk + " " + labels).lower()
    if "money_reaccel" in hay or "돈흐름 재가속" in labels:
        return "money_reaccel"
    if "sweep_vwap" in hay or "저점 vwap" in hay or "저점 VWAP" in labels:
        return "sweep_vwap"
    if "leader_flow" in hay or "주도흐름 유동보유" in labels:
        return "leader_flow"
    if "leader_momentum" in hay or "주도추세 지속" in labels:
        return "leader_momentum"
    if "breakout" in hay or "돌파 초입" in labels:
        return "breakout"
    if "surge_rebreak" in hay or "급등 후 재돌파" in labels:
        return "surge_rebreak"
    if "hot_rank" in hay or "hot-rank" in hay:
        return "hot_rank"
    return "common"


def _v554_build_structure_levels(row: Dict[str, Any]) -> Dict[str, Any]:
    price = _v510_num(row.get("current_price"), row.get("entry_price"), row.get("price"), default=0.0)
    if price <= 0:
        return {"schema": "structure_levels_v554", "available": False, "reason": "price_missing"}
    fam = _v554_strategy_family(row)
    vwap_gap = _v510_num(row.get("vwap_gap_pct"), row.get("vwap_pos_pct"), row.get("vwap_position_pct"), default=0.0)
    ema_gap = _v510_num(row.get("ema5_gap_pct"), row.get("ema5_pos_pct"), row.get("ma5_gap_pct"), default=0.0)
    high_gap = _v510_num(row.get("recent_high_gap_pct"), row.get("below_high_pct"), row.get("high_gap_pct"), default=0.0)
    low_rebound = _v510_num(row.get("recent_low_rebound_pct"), row.get("low_rebound_pct"), default=0.0)
    react = _v510_num(row.get("price_reaction_pct"), default=0.0)
    ch1 = _v510_num(row.get("change_1m_pct"), row.get("change_1m"), default=0.0)
    ch3 = _v510_num(row.get("change_3m_pct"), row.get("change_3m"), default=0.0)
    spread = _v510_num(row.get("spread_pct"), default=0.0)

    vwap_price = _v554_price_from_gap(price, vwap_gap)
    ema_price = _v554_price_from_gap(price, ema_gap)
    recent_high = _v554_price_from_gap(price, high_gap) if abs(high_gap) > 0.0001 else 0.0
    recent_low = _v554_price_from_gap(price, low_rebound) if low_rebound > 0.0001 else 0.0

    supports = [x for x in (vwap_price, ema_price, recent_low, _v554_pct_to_price(price, -0.45)) if x and x < price * 1.003]
    resistances = [x for x in (recent_high, _v554_pct_to_price(price, 0.30 + min(max(react, 0.0), 1.2) * 0.15)) if x and x > price * 0.997]
    support = max([x for x in supports if x < price] or [_v554_pct_to_price(price, -0.45)])
    resistance = min([x for x in resistances if x > price] or [_v554_pct_to_price(price, 0.60)])

    # Strategy-specific structure line interpretation. These are plan/reference levels,
    # not new entry/exit thresholds.
    if fam == "money_reaccel":
        trigger = max(resistance, _v554_pct_to_price(price, 0.18))
        invalid = min(support, _v554_pct_to_price(price, -0.35))
        target1 = max(resistance, _v554_pct_to_price(trigger, 0.65))
        target2 = max(target1, _v554_pct_to_price(trigger, 1.20))
        plan_type = "눌림후 재가속 방아쇠"
        reason = "눌림 고점/직전 저항 재돌파 + 돈흐름 유지"
    elif fam == "sweep_vwap":
        trigger = max(vwap_price or price, _v554_pct_to_price(price, 0.10))
        invalid = min(recent_low or support, _v554_pct_to_price(price, -0.40))
        target1 = max(resistance, _v554_pct_to_price(trigger, 0.70))
        target2 = max(target1, _v554_pct_to_price(trigger, 1.25))
        plan_type = "저점쓸림 후 VWAP 회복 방아쇠"
        reason = "VWAP 재회복 + 저점 재이탈 없음"
    elif fam == "leader_flow":
        trigger = max(resistance, _v554_pct_to_price(price, 0.16))
        invalid = min(vwap_price or support, ema_price or support, _v554_pct_to_price(price, -0.45))
        target1 = max(resistance, _v554_pct_to_price(trigger, 0.55))
        target2 = max(target1, _v554_pct_to_price(trigger, 1.10))
        plan_type = "주도흐름 눌림회복 방아쇠"
        reason = "VWAP/EMA 방어 후 직전 고점 재접근"
    elif fam == "leader_momentum":
        trigger = max(resistance, _v554_pct_to_price(price, 0.20))
        invalid = min(vwap_price or support, ema_price or support, _v554_pct_to_price(price, -0.50))
        target1 = max(resistance, _v554_pct_to_price(trigger, 0.70))
        target2 = max(target1, _v554_pct_to_price(trigger, 1.35))
        plan_type = "주도추세 지속 돌파 방아쇠"
        reason = "주도성 유지 + 저항 재돌파"
    elif fam in {"breakout", "surge_rebreak", "hot_rank"}:
        trigger = max(resistance, _v554_pct_to_price(price, 0.25))
        invalid = min(support, _v554_pct_to_price(price, -0.50))
        target1 = max(resistance, _v554_pct_to_price(trigger, 0.55))
        target2 = max(target1, _v554_pct_to_price(trigger, 1.05))
        plan_type = "돌파/재돌파 방아쇠"
        reason = "저항 돌파 + 돌파선 위 유지"
    else:
        trigger = max(resistance, _v554_pct_to_price(price, 0.20))
        invalid = min(support, _v554_pct_to_price(price, -0.45))
        target1 = max(resistance, _v554_pct_to_price(trigger, 0.65))
        target2 = max(target1, _v554_pct_to_price(trigger, 1.15))
        plan_type = "공통 구조 방아쇠"
        reason = "구조선 도달 + 확인신호 통과"

    expected_up = _v554_pct_between(target1, price)
    expected_down = abs(_v554_pct_between(invalid, price))
    rr = (expected_up / expected_down) if expected_down > 0 else 0.0
    late_chase = bool((ch1 >= 1.80 or ch3 >= 3.20 or react >= 1.80) and fam in {"leader_flow", "leader_momentum", "breakout", "hot_rank", "surge_rebreak"})
    if spread >= 0.60:
        late_chase = True
    status = "triggered" if price >= trigger * 0.999 else "waiting"
    return {
        "schema": "structure_levels_v554_all_strategy",
        "available": True,
        "strategy_family": fam,
        "current_price": _v554_round_price(price),
        "support_price": _v554_round_price(support),
        "resistance_price": _v554_round_price(resistance),
        "trigger_price": _v554_round_price(trigger),
        "invalid_price": _v554_round_price(invalid),
        "target1_price": _v554_round_price(target1),
        "target2_price": _v554_round_price(target2),
        "distance_to_trigger_pct": round(_v554_pct_between(trigger, price), 3),
        "distance_to_invalid_pct": round(_v554_pct_between(invalid, price), 3),
        "expected_upside_pct": round(expected_up, 3),
        "expected_downside_pct": round(-abs(expected_down), 3),
        "expected_downside_abs_pct": round(abs(expected_down), 3),
        "rr_ratio": round(rr, 2),
        "plan_type": plan_type,
        "trigger_reason": reason,
        "target_reason": "다음 저항/구조 목표 우선, 기존 고정 청산은 유지",
        "stop_reason": "구조 무효화 가격. 실제 paper 손절조건은 변경 없음",
        "late_chase_flag": late_chase,
        "late_chase_basis": {"change_1m": round(ch1, 3), "change_3m": round(ch3, 3), "reaction": round(react, 3), "spread": round(spread, 3)},
        "late_chase_reason": ("가격반응/단기상승/스프레드 기준 늦은추격" if late_chase else ""),
        "status": status,
    }


def _v554_apply_entry_plan(row: Dict[str, Any], state: Dict[str, Any], nowv: float) -> Dict[str, Any]:
    if not isinstance(row, dict):
        return row
    out = dict(row)
    t = ticker_norm(out.get("ticker") or out.get("market") or out.get("symbol"))
    sk = str(out.get("strategy_key") or out.get("paper_strategy_key") or "-")
    fam = _v554_strategy_family(out)
    # v556: state key는 매 cycle마다 바뀔 수 있는 세부 strategy_key보다
    # ticker + strategy family를 우선한다. 기존 v554/v555 key도 migrate해서
    # first_seen/S2/S1 생애주기가 끊기지 않게 한다.
    key = f"{t}:{fam}" if t else fam
    legacy_keys = [f"{t}:{sk}" if t else sk, str(t or ""), f"{t}:common" if t else "common"]
    price = _v510_num(out.get("current_price"), out.get("entry_price"), out.get("price"), default=0.0)
    prev = state.get(key) if isinstance(state.get(key), dict) else {}
    if not prev:
        for lk in legacy_keys:
            if lk and isinstance(state.get(lk), dict):
                prev = dict(state.get(lk) or {})
                break
    first_ts = _v510_num(prev.get("first_seen_ts"), default=0.0) or nowv
    first_price = _v510_num(prev.get("first_seen_price"), default=0.0) or price
    structure_ts = _v510_num(prev.get("structure_seen_ts"), default=0.0) or nowv
    structure_price = _v510_num(prev.get("structure_seen_price"), default=0.0) or price
    stage = _v510_stage(out)
    if stage == "S2":
        s2_ts = _v510_num(prev.get("s2_seen_ts"), default=0.0) or nowv
        s2_price = _v510_num(prev.get("s2_price"), default=0.0) or price
        s1_ts = _v510_num(prev.get("s1_seen_ts"), default=0.0)
        s1_price = _v510_num(prev.get("s1_price"), default=0.0)
    elif stage == "S1":
        s2_ts = _v510_num(prev.get("s2_seen_ts"), default=0.0) or nowv
        s2_price = _v510_num(prev.get("s2_price"), default=0.0) or price
        s1_ts = _v510_num(prev.get("s1_seen_ts"), default=0.0) or nowv
        s1_price = _v510_num(prev.get("s1_price"), default=0.0) or price
    else:
        s2_ts = _v510_num(prev.get("s2_seen_ts"), default=0.0)
        s2_price = _v510_num(prev.get("s2_price"), default=0.0)
        s1_ts = _v510_num(prev.get("s1_seen_ts"), default=0.0)
        s1_price = _v510_num(prev.get("s1_price"), default=0.0)

    levels = _v554_build_structure_levels(out)
    entry_plan = {
        "schema": "entry_plan_v554_s2_trigger_waiting",
        "role": "S2=진입계획 대기 / S1=방아쇠+확인통과 / S3=구조관찰",
        "plan_type": levels.get("plan_type") or "구조선 대기",
        "trigger_price": levels.get("trigger_price"),
        "trigger_reason": levels.get("trigger_reason"),
        "invalid_price": levels.get("invalid_price"),
        "target1_price": levels.get("target1_price"),
        "target2_price": levels.get("target2_price"),
        "required_confirm": ["신선도", "가격반응", "매수체결", "1분지속", "스프레드/미끄러짐 정상"],
        "cancel_conditions": ["무효화 가격 이탈", "강한 매도압력", "스프레드/미끄러짐 과다", "늦은추격 위험"],
        "timeout_sec": 180 if stage != "S1" else 70,
        "status": "paper_open_ready" if stage == "S1" else ("entry_plan_wait" if stage == "S2" else "structure_observe"),
    }
    timing = {
        "schema": "entry_timing_spine_v554",
        "first_seen_ts": first_ts,
        "first_seen_price": _v554_round_price(first_price),
        "structure_seen_ts": structure_ts,
        "structure_seen_price": _v554_round_price(structure_price),
        "s2_seen_ts": s2_ts,
        "s2_price": _v554_round_price(s2_price),
        "s1_seen_ts": s1_ts,
        "s1_price": _v554_round_price(s1_price),
        "first_to_s1_delay_sec": round(max(0.0, s1_ts - first_ts), 1) if s1_ts else None,
        "s2_to_s1_delay_sec": round(max(0.0, s1_ts - s2_ts), 1) if s1_ts and s2_ts else None,
        "first_to_now_delay_sec": round(max(0.0, nowv - first_ts), 1),
        "s2_to_now_delay_sec": round(max(0.0, nowv - s2_ts), 1) if s2_ts else None,
        "first_to_current_delay_sec": round(max(0.0, nowv - first_ts), 1),
        "s2_to_current_delay_sec": round(max(0.0, nowv - s2_ts), 1) if s2_ts else None,
        "first_to_now_return_pct": round(_v554_pct_between(price, first_price), 3) if first_price else 0.0,
        "s2_to_now_return_pct": round(_v554_pct_between(price, s2_price), 3) if s2_price else 0.0,
        "first_to_current_return_pct": round(_v554_pct_between(price, first_price), 3) if first_price else 0.0,
        "s2_to_current_return_pct": round(_v554_pct_between(price, s2_price), 3) if s2_price else 0.0,
        "s1_to_now_return_pct": round(_v554_pct_between(price, s1_price), 3) if s1_price else 0.0,
        "late_chase_flag": bool(levels.get("late_chase_flag")),
        "late_chase_reason": levels.get("late_chase_reason") or "",
        "state_key": key,
    }
    rr = {
        "schema": "risk_reward_v556_structure_target",
        "expected_upside_pct": levels.get("expected_upside_pct"),
        "expected_downside_pct": levels.get("expected_downside_pct"),
        "expected_downside_abs_pct": levels.get("expected_downside_abs_pct"),
        "rr_ratio": levels.get("rr_ratio"),
        "target_reason": levels.get("target_reason"),
        "stop_reason": levels.get("stop_reason"),
    }
    out["structure_levels"] = levels
    out["entry_plan"] = entry_plan
    out["risk_reward"] = rr
    out["entry_timing_spine"] = timing
    out["late_chase_flag"] = bool(levels.get("late_chase_flag"))
    out["late_chase_basis"] = levels.get("late_chase_basis")
    if bool(out.get("late_chase_flag")):
        risks = out.get("risk_tags") if isinstance(out.get("risk_tags"), list) else []
        out["risk_tags"] = _v510_uniq(list(risks) + ["늦은추격위험"], 12)
        out["execution_risk_tags"] = out["risk_tags"]
    ctx = out.get("entry_context") if isinstance(out.get("entry_context"), dict) else {}
    ctx = dict(ctx)
    ctx.update({"structure_levels": levels, "entry_plan": entry_plan, "risk_reward": rr, "entry_timing_spine": timing, "late_chase_flag": out.get("late_chase_flag"), "late_chase_basis": out.get("late_chase_basis"), "late_chase_reason": levels.get("late_chase_reason")})
    out["entry_context"] = ctx
    state[key] = {
        "ticker": t,
        "strategy_key": sk,
        "first_seen_ts": first_ts,
        "first_seen_price": first_price,
        "structure_seen_ts": structure_ts,
        "structure_seen_price": structure_price,
        "s2_seen_ts": s2_ts,
        "s2_price": s2_price,
        "s1_seen_ts": s1_ts,
        "s1_price": s1_price,
        "last_seen_ts": nowv,
        "last_seen_price": price,
        "last_stage": stage,
        "strategy_family": fam,
        "state_key": key,
        "seen_count": int(_v510_num(prev.get("seen_count"), default=0.0)) + 1,
    }
    return out


def _v554_apply_entry_plan_state(rows: List[Dict[str, Any]], nowv: float) -> List[Dict[str, Any]]:
    obj = load_json(ENTRY_PLAN_STATE, {}) or {}
    state = obj.get("items") if isinstance(obj, dict) and isinstance(obj.get("items"), dict) else (obj if isinstance(obj, dict) else {})
    # old/no-longer-seen state is short-lived; it is only for timing/plan continuity.
    for k in list(state.keys()):
        try:
            if nowv - float(state.get(k, {}).get("last_seen_ts") or 0.0) > 1800:
                state.pop(k, None)
        except Exception:
            state.pop(k, None)
    out = [_v554_apply_entry_plan(r, state, nowv) for r in rows if isinstance(r, dict)]
    save_json(ENTRY_PLAN_STATE, {"schema": "entry_plan_state_v556_lifecycle", "version": VERSION, "updated_ts": nowv, "updated_text": now_text(nowv), "count": len(state), "items": state})
    return out

def _v510_make_row(src: Dict[str, Any], of: Dict[str, Any], stage: str, skey: str, label: str, lane: str, score: float, reasons: List[str], nowv: float, hard: Optional[List[str]] = None) -> Dict[str, Any]:
    t = ticker_norm(src.get("ticker") or src.get("market") or src.get("symbol"))
    react = _v510_price_reaction(src, of)
    spread = _v510_spread(of, src)
    buy = _v510_buy(of, src)
    sustain, sustain_source, sustain_real = _v524_sustain_detail(of, src)
    # v519: paper_bot OPEN 필수 가격값을 strategy canonical row에서 봉인한다.
    sealed_price = _v510_num(
        src.get("current_price"), src.get("price"), src.get("trade_price"), src.get("close"), src.get("last_price"),
        of.get("quote_price"), of.get("current_price"), of.get("price"), of.get("trade_price"), of.get("last_price"),
        of.get("mid_price"), of.get("best_bid"), of.get("bid_price"),
        default=0.0,
    )
    hot_age = _v521_age_from_sources(src, of, "_scanner_hot_cache_age_sec", ("hot_signal_age_sec", "hot_age_sec"), default_cache_age=_v521_file_age(SCANNER_HOT))
    micro_age = _v521_age_from_sources(of, src, "_cache_age_sec", ("micro_age_sec", "trade_age_sec"), default_cache_age=_v510_num(of.get("_cache_age_sec"), default=999999.0))
    order_age = _v521_age_from_sources(of, src, "_cache_age_sec", ("orderflow_age_sec", "trade_age_sec", "micro_age_sec"), default_cache_age=micro_age)
    price_age = _v521_age_from_sources(src, of, "_cache_age_sec", ("price_reaction_age_sec", "price_age_sec", "feature_age_sec"), default_cache_age=0.0)
    quote_age = _v521_age_from_sources(of, src, "_cache_age_sec", ("quote_age_sec", "ws_age_sec"), default_cache_age=_v510_num(of.get("_cache_age_sec"), default=999999.0))
    stale_items = _v520_fresh_stale_items(src, of, hot_age, micro_age, order_age, price_age, quote_age, sealed_price, strict=True)
    decision_reasons, reason_structure_tags = _v520_split_reasons(reasons, stale_items)
    row = {
        "schema": "paper_candidate_v520_reason_spine_row",
        "version": VERSION,
        "ticker": t,
        "market": f"KRW-{t}" if t else src.get("market"),
        "symbol": f"{t}_KRW" if t else src.get("symbol"),
        "event_id": _v510_event_id(t, skey, lane, nowv),
        "event_key": _v510_event_id(t, skey, lane, nowv),
        "created_at": nowv,
        "candidate_created_at": nowv,
        "source_created_at": nowv,
        "detected_ts": nowv,
        "event_ts": nowv,
        "created_at_text": now_text(nowv),
        "updated_ts": nowv,
        "expires_at": nowv + (70 if stage == "S1" else 180),
        "strategy_key": skey,
        "paper_strategy_key": skey,
        "strategy_label": label,
        "strategy": label,
        "matched_strategy_keys": list(src.get("_matched_strategy_keys") or [skey]),
        "matched_strategy_labels": list(src.get("_matched_strategy_labels") or [label]),
        "canonical_lane": lane,
        "s_stage": stage,
        "candidate_stage": stage,
        "candidate_grade": stage,
        "stage": stage,
        "grade": stage,
        "score": round(score, 3),
        "current_price": sealed_price,
        "entry_price": sealed_price,
        "detected_price": sealed_price,
        "live_price": sealed_price,
        "price": sealed_price,
        "trade_price": sealed_price,
        "price_source": "strategy_v522_sealed",
        "price_ready": bool(sealed_price and sealed_price > 0),
        "price_reaction_pct": round(react, 4),
        "spread_pct": round(spread, 4),
        "slippage_pct": round(spread, 4),
        "buy_ratio": round(buy, 4),
        "buy_sustain_1m": round(sustain, 4),
        "buy_sustain_1m_source": sustain_source,
        "buy_sustain_1m_real": bool(sustain_real),
        "buy_sustain_1m_is_fallback": not bool(sustain_real),
        "sustain_source": sustain_source,
        "change_1m_pct": _v510_num(src.get("change_1m"), src.get("price_change_1m"), default=0.0),
        "change_3m_pct": _v510_num(src.get("change_3m"), src.get("price_change_3m"), default=0.0),
        "change_5m_pct": _v510_num(src.get("change_5m"), src.get("price_change_5m"), default=0.0),
        "price_chg_5s": _v510_num(of.get("price_chg_5s"), src.get("price_chg_5s"), default=0.0),
        "price_chg_10s": _v510_num(of.get("price_chg_10s"), src.get("price_chg_10s"), default=0.0),
        "price_chg_20s": _v510_num(of.get("price_chg_20s"), src.get("price_chg_20s"), default=0.0),
        "price_chg_30s": _v510_num(of.get("price_chg_30s"), src.get("price_chg_30s"), default=0.0),
        "price_chg_60s": _v510_num(of.get("price_chg_60s"), src.get("price_chg_60s"), default=0.0),
        "price_accel_10s": _v510_num(of.get("price_accel_10s"), src.get("price_accel_10s"), default=0.0),
        "price_accel_20s": _v510_num(of.get("price_accel_20s"), src.get("price_accel_20s"), default=0.0),
        "buy_ratio_5s": _v510_num(of.get("buy_ratio_5s"), src.get("buy_ratio_5s"), default=buy),
        "buy_ratio_10s": _v510_num(of.get("buy_ratio_10s"), src.get("buy_ratio_10s"), default=buy),
        "buy_sustain_20s": _v510_num(of.get("buy_sustain_20s"), src.get("buy_sustain_20s"), default=sustain),
        "trade_burst_10s": _v510_num(of.get("trade_burst_10s"), src.get("trade_burst_10s"), default=0.0),
        "spread_widening_10s": _v510_num(of.get("spread_widening_10s"), src.get("spread_widening_10s"), default=0.0),
        "spike_fast_ready": bool(of.get("spike_fast_ready") or src.get("spike_fast_ready")),
        "hot_signal_age_sec": hot_age,
        "micro_age_sec": micro_age,
        "orderflow_age_sec": order_age,
        "price_reaction_age_sec": price_age,
        "quote_age_sec": quote_age,
        "structure_tags": _v510_uniq(_v510_structure_tags(src) + reason_structure_tags, 10),
        "risk_tags": _v510_risk_tags(src, of, hard or []),
        "stale_reasons": stale_items,
        "freshness_status": "recheck" if stale_items else "fresh",
        "official_structure_inputs_raw": {},
        "reason": " / ".join(decision_reasons),
        "s_stage_reasons": decision_reasons,
    }
    # v597: preserve official candle/structure inputs from feature/candle source row.
    # These are evidence fields, not new strategy conditions. Missing stays missing; no 0 fallback.
    _official_pack = {}
    for _ok in V597_OFFICIAL_STRUCTURE_KEYS:
        _ov = src.get(_ok)
        if _ov not in (None, ""):
            row[_ok] = _ov
            _official_pack[_ok] = _ov
    if _official_pack:
        row["official_structure_inputs_raw"] = _official_pack

    row["entry_context"] = {
        "strategy_key": skey,
        "strategy_label": label,
        "canonical_lane": lane,
        "structure_tags": row["structure_tags"],
        "risk_tags": row["risk_tags"],
        "hot_signal_age_sec": hot_age,
        "micro_age_sec": micro_age,
        "orderflow_age_sec": order_age,
        "price_reaction_age_sec": price_age,
        "quote_age_sec": quote_age,
        "freshness_status": "recheck" if stale_items else "fresh",
        "stale_reasons": stale_items,
        "current_price": sealed_price,
        "entry_price": sealed_price,
        "detected_price": sealed_price,
        "live_price": sealed_price,
        "price": sealed_price,
        "price_ready": bool(sealed_price and sealed_price > 0),
        "price_source": "strategy_v522_sealed",
        "price_reaction_pct": react,
        "buy_ratio": buy,
        "buy_sustain_1m": sustain,
        "buy_sustain_1m_source": sustain_source,
        "buy_sustain_1m_real": bool(sustain_real),
        "buy_sustain_1m_is_fallback": not bool(sustain_real),
        "spread_pct": spread,
        "price_chg_20s": row.get("price_chg_20s"),
        "price_chg_30s": row.get("price_chg_30s"),
        "price_chg_60s": row.get("price_chg_60s"),
        "price_accel_10s": row.get("price_accel_10s"),
        "buy_ratio_10s": row.get("buy_ratio_10s"),
        "buy_sustain_20s": row.get("buy_sustain_20s"),
        "spread_widening_10s": row.get("spread_widening_10s"),
        "reasons": row["s_stage_reasons"],
    }
    row = _v532_apply_canonical_entry_decision(row)
    row = _v553_apply_reason_taxonomy(row)
    return row


def _v510_final_gate(row: Dict[str, Any], nowv: float) -> Dict[str, Any]:
    r = dict(row)
    stage = _v510_stage(r)
    skey = str(r.get("strategy_key") or "")
    is_spike = skey in {"spike_momentum_ride", "spike_pullback_reaccel"}
    hot = _v510_num(r.get("hot_signal_age_sec"), default=999999.0)
    micro = _v510_num(r.get("micro_age_sec"), default=999999.0)
    order = _v510_num(r.get("orderflow_age_sec"), default=micro)
    price = _v510_num(r.get("price_reaction_age_sec"), default=999999.0)
    quote = _v510_num(r.get("quote_age_sec"), default=999999.0)
    paper_delay = max(0.0, nowv - _event_created_ts(r))
    sealed_price = _v510_num(r.get("current_price"), r.get("entry_price"), r.get("price"), default=0.0)
    stale: List[str] = _v520_fresh_stale_items(r, r, hot, micro, order, price, quote, sealed_price, strict=is_spike)
    if is_spike and paper_delay > 20:
        stale.append(f"paper {paper_delay:.1f}s")
    elif (not is_spike) and paper_delay > 45:
        stale.append(f"paper {paper_delay:.1f}s")
    stale = _v522_filter_stale_items(_v510_uniq(stale, 6), strict=is_spike)
    allowed = not stale
    if stage == "S1" and not allowed:
        r["v510_downgraded_from_s1"] = True
        r["s_stage"] = r["candidate_stage"] = r["candidate_grade"] = r["stage"] = r["grade"] = "S2"
        rr = list(r.get("s_stage_reasons") or []) + ["final_entry_gate 신선도 재확인: " + " / ".join(stale[:5])]
        r["s_stage_reasons"] = _v510_uniq(rr, 12)
    r["stale_reasons"] = stale
    r = _v520_normalize_reason_row(r)
    r["fresh_gate_ok"] = bool(allowed)
    r = _v532_apply_canonical_entry_decision(r)
    decision = r.get("canonical_entry_decision") if isinstance(r.get("canonical_entry_decision"), dict) else {}
    final_allowed = bool(decision.get("s1_allowed") and allowed)
    if not final_allowed and _v510_stage(r) == "S1":
        r["v510_downgraded_from_s1"] = True
        target_stage = "S2" if (stale or decision.get("s2_recheck") or decision.get("action") == "recheck") else "S3"
        r["s_stage"] = r["candidate_stage"] = r["candidate_grade"] = r["stage"] = r["grade"] = target_stage
    r["open_eligible"] = bool(final_allowed)
    r["paper_bot_open"] = bool(final_allowed)
    r["trade_ready"] = bool(final_allowed)
    r["v510_final_entry_gate"] = {
        "schema": "final_entry_gate_v536_profile_simplified",
        "version": VERSION,
        "checked_ts": nowv,
        "age_values": {"hot": hot, "micro": micro, "orderflow": order, "price": price, "quote": quote, "paper": paper_delay},
        "stale_reasons": stale,
        "s1_allowed": bool(final_allowed),
        "policy": "v536: canonical_entry_decision with simplified entry_profile; paper_candidates_latest.jsonl is canonical",
    }
    ctx = r.get("entry_context") if isinstance(r.get("entry_context"), dict) else {}
    ctx = dict(ctx); ctx["v510_final_entry_gate"] = r["v510_final_entry_gate"]
    r["entry_context"] = ctx
    dec = r.get("canonical_entry_decision") if isinstance(r.get("canonical_entry_decision"), dict) else {}
    if isinstance(dec, dict):
        dec = dict(dec)
        dec["v510_final_entry_gate"] = r["v510_final_entry_gate"]
        dec["s1_allowed"] = bool(final_allowed)
        dec["gate_pass"] = bool(final_allowed)
        dec["action"] = "paper_open_candidate" if final_allowed else ("recheck" if dec.get("s2_recheck") else "observe")
        r["canonical_entry_decision"] = dec
        r["common_entry_decision"] = dec
        r["entry_context"]["canonical_entry_decision"] = dec
        r["entry_context"]["common_entry_decision"] = dec
    r = _v553_apply_reason_taxonomy(r)
    return r


def _v510_base_lane(nowv: float, feature_list: List[Dict[str, Any]], ofmap: Dict[str, Dict[str, Any]]) -> Tuple[List[Dict[str, Any]], List[Dict[str, Any]], List[Dict[str, Any]]]:
    evals=[("leader_flow_adaptive_hold_s",eval_adaptive_hold),("money_reaccel_s",eval_money),("leader_momentum_s",eval_leader),("breakout_early_s",eval_breakout),("sweep_vwap_recovery_s",eval_sweep),("surge_rebreak_s",eval_surge)]
    rows: List[Dict[str, Any]] = []
    rejects: List[Dict[str, Any]] = []
    requests: List[Dict[str, Any]] = []
    for src in feature_list:
        t = ticker_norm(src.get("ticker") or src.get("market") or src.get("symbol"))
        if not t: continue
        of = ofmap.get(t, {}) or {}
        hard = common_hard(src, of)
        core_hits: List[Tuple[str, List[str]]] = []
        core_fail: List[str] = []
        for skey, fn in evals:
            ok, why, no = fn(src, of)
            if ok: core_hits.append((skey, why))
            else: core_fail += [f"{STRATEGIES.get(skey, skey)}:{x}" for x in no[:2]]
        need_info, cheap_bucket = _cheap_gate(src, core_hits, hard)
        info_bad = orderflow_info_bad(of) if need_info else []
        react = _v510_price_reaction(src, of)
        buy = _v510_buy(of, src)
        sustain, sustain_source, sustain_real = _v524_sustain_detail(of, src)
        spread = _v510_spread(of, src)
        score = _priority_score(src, core_hits, info_bad, hard)
        reasons: List[str] = []
        skey = core_hits[0][0] if core_hits else "leader_flow_adaptive_hold_s"
        label = STRATEGIES.get(skey, skey).replace(" S", "")
        if core_hits:
            reasons += [f"구조:{STRATEGIES.get(k,k)}" for k,_ in core_hits[:2]]
        reasons += hard[:4] + info_bad[:3]
        if react < 0.05: reasons.append("가격반응 기준근접(+0.00%→+0.05%)")
        if react < 0.35: reasons.append("가격반응 약함(+0.05%→+0.35%)")
        if buy < 0.70: reasons.append(f"매수체결 0.70 미만({buy:.2f})")
        if sustain < 0.70 and sustain_real:
            reasons.append("1분 매수지속 부족")
        elif sustain < 0.70 and not sustain_real:
            reasons.append("1분지속 실측없음(buy_ratio대체)")
        if spread > 0.35: reasons.append(f"스프레드 과다({spread:.2f}%)")
        elif spread > 0.18: reasons.append(f"스프레드 경계값({spread:.2f}%)→재확인")
        stage = ""
        common_s2 = (not hard and react >= 0.15 and buy >= 0.55 and spread <= 0.35)
        if core_hits or common_s2 or (need_info and cheap_bucket in {"core_hit", "high_cheap"}) or score >= 88:
            # S1 is not decided here. _v532_apply_canonical_entry_decision is the only S1 source.
            stage = "S2" if (core_hits or react >= 0.25 or score >= 105 or common_s2) else "S3"
        elif cheap_bucket == "high_cheap":
            stage = "S3"
        if not stage:
            rejects.append({"ticker": t, "score": score, "reasons": _v510_uniq(reasons + core_fail, 8), "updated_ts": nowv})
            continue
        src_for_row = dict(src)
        src_for_row["_matched_strategy_keys"] = [k for k, _ in core_hits] or [skey, "common_rise_entry"]
        src_for_row["_matched_strategy_labels"] = [STRATEGIES.get(k, k) for k, _ in core_hits] or [label, "공통상승조건"]
        row = _v510_make_row(src_for_row, of, stage, skey, label, "base", score, reasons or ["구조관찰"], nowv, hard)
        rows.append(row)
        need = []
        if not _v510_bool(of.get("quote_fresh") or of.get("ws_fresh")): need.append("quote")
        if not _v510_bool(of.get("micro_fresh")): need.append("micro")
        requests.append(_make_priority_request(t, src, "s_candidate" if stage == "S1" else "recheck_candidate", 100 + score + _STAGE_ORDER.get(stage,1)*20, need or ["micro"], core_hits, row.get("s_stage_reasons") or []))
    return rows, rejects, requests


def _v510_spike_lane(nowv: float, feature_list: List[Dict[str, Any]], ofmap: Dict[str, Dict[str, Any]]) -> List[Dict[str, Any]]:
    rows: List[Dict[str, Any]] = []
    for src in feature_list:
        t = ticker_norm(src.get("ticker") or src.get("market") or src.get("symbol"))
        if not t: continue
        of = ofmap.get(t, {}) or {}
        ch1 = _v510_num(src.get("change_1m"), src.get("price_change_1m"), default=0.0)
        ch3 = _v510_num(src.get("change_3m"), src.get("price_change_3m"), default=0.0)
        react = _v510_price_reaction(src, of)
        short20 = _v510_num(of.get("price_chg_20s"), src.get("price_chg_20s"), default=0.0)
        short30 = _v510_num(of.get("price_chg_30s"), src.get("price_chg_30s"), default=0.0)
        accel10 = _v510_num(of.get("price_accel_10s"), src.get("price_accel_10s"), default=0.0)
        # Wide prefilter only. It does not cap candidates.
        if max(ch1, ch3, react, short20, short30, accel10) < 0.30:
            continue
        spread = _v510_spread(of, src); buy = _v510_buy(of, src); sustain, sustain_source, sustain_real = _v524_sustain_detail(of, src)
        hot_age = _v521_age_from_sources(src, of, "_scanner_hot_cache_age_sec", ("hot_signal_age_sec", "hot_age_sec"), default_cache_age=_v521_file_age(SCANNER_HOT))
        micro_age = _v521_age_from_sources(of, src, "_cache_age_sec", ("micro_age_sec", "trade_age_sec"), default_cache_age=_v510_num(of.get("_cache_age_sec"), default=999999.0))
        order_age = _v521_age_from_sources(of, src, "_cache_age_sec", ("orderflow_age_sec", "trade_age_sec", "micro_age_sec"), default_cache_age=micro_age)
        price_age = _v521_age_from_sources(src, of, "_cache_age_sec", ("price_reaction_age_sec", "price_age_sec", "feature_age_sec"), default_cache_age=0.0)
        quote_age = _v521_age_from_sources(of, src, "_cache_age_sec", ("quote_age_sec", "ws_age_sec"), default_cache_age=_v510_num(of.get("_cache_age_sec"), default=999999.0))
        sealed_price_probe = _v510_num(
            src.get("current_price"), src.get("price"), src.get("trade_price"), src.get("close"), src.get("last_price"),
            of.get("quote_price"), of.get("current_price"), of.get("price"), of.get("trade_price"), of.get("last_price"),
            of.get("mid_price"), of.get("best_bid"), of.get("bid_price"),
            default=0.0,
        )
        fresh = not _v520_fresh_stale_items(src, of, hot_age, micro_age, order_age, price_age, quote_age, sealed_price_probe, strict=True)
        evals=[("leader_flow_adaptive_hold_s",eval_adaptive_hold),("money_reaccel_s",eval_money),("leader_momentum_s",eval_leader),("breakout_early_s",eval_breakout),("sweep_vwap_recovery_s",eval_sweep),("surge_rebreak_s",eval_surge)]
        core_hits: List[Tuple[str, List[str]]] = []
        for _skey, _fn in evals:
            _ok, _why, _no = _fn(src, of)
            if _ok:
                core_hits.append((_skey, _why))
        # S1 is not decided here. _v532_apply_canonical_entry_decision is the only S1 source.
        strong = (react >= 0.80 or ch1 >= 0.70 or ch3 >= 1.20) and buy >= 0.78 and sustain >= 0.78 and spread <= 0.18
        late_risk = (buy < 0.70 or sustain < 0.70 or spread > 0.35 or row_bool(src, "long_upper_wick"))
        stage = "S2" if (fresh and (react >= 0.35 or strong) and spread <= 0.50) else "S3"
        if core_hits:
            skey = core_hits[0][0]
            label = STRATEGIES.get(skey, skey).replace(" S", "")
        else:
            skey = "hot_rank_recheck"
            label = "hot-rank 급등 재확인"
        reasons: List[str] = []
        if stage == "S1":
            reasons.append("fresh urgent 급등 확인")
        elif core_hits:
            reasons.append("급등확인 재확인")
        else:
            reasons.append("hot-rank 급등 재확인")
        if buy < 0.70: reasons.append(f"매수체결 0.70 미만({buy:.2f})")
        if sustain < 0.70 and sustain_real:
            reasons.append("1분 매수지속 부족")
        elif sustain < 0.70 and not sustain_real:
            reasons.append("1분지속 실측없음(buy_ratio대체)")
        if spread > 0.35: reasons.append(f"스프레드 과다({spread:.2f}%)")
        score = 100 + max(0.0, react)*10 + max(0.0, ch1)*4 + max(0.0, ch3)*3 + max(0.0, buy)*2 + max(0.0, short20)*5 + max(0.0, accel10)*4
        src_for_row = dict(src)
        src_for_row["_matched_strategy_keys"] = [k for k, _ in core_hits] or [skey, "common_rise_entry"]
        src_for_row["_matched_strategy_labels"] = [STRATEGIES.get(k, k) for k, _ in core_hits] or [label, "공통상승조건"]
        row = _v510_make_row(src_for_row, of, stage, skey, label, "spike", score, reasons, nowv, [])
        rows.append(_v520_normalize_reason_row(row))
    return rows


def row_bool(row: Dict[str, Any], key: str) -> bool:
    try:
        return _v510_bool(row.get(key))
    except Exception:
        return False


def _v510_merge_rows(rows: List[Dict[str, Any]], nowv: float) -> List[Dict[str, Any]]:
    merged: Dict[str, Dict[str, Any]] = {}
    for r in rows:
        if not isinstance(r, dict): continue
        r = _v510_final_gate(r, nowv)
        t = ticker_norm(r.get("ticker") or r.get("market") or r.get("symbol"))
        if not t: continue
        key = t
        prev = merged.get(key)
        if prev is None:
            merged[key] = r; continue
        merged_keys = _v510_uniq(list(prev.get("matched_strategy_keys") or []) + list(r.get("matched_strategy_keys") or []), 8)
        merged_labels = _v510_uniq(list(prev.get("matched_strategy_labels") or []) + list(r.get("matched_strategy_labels") or []), 8)
        a = (_STAGE_ORDER.get(_v510_stage(r), 0), 1 if str(r.get("canonical_lane")) == "base" else 0, _v510_num(r.get("score"), default=0.0), _event_created_ts(r))
        b = (_STAGE_ORDER.get(_v510_stage(prev), 0), 1 if str(prev.get("canonical_lane")) == "base" else 0, _v510_num(prev.get("score"), default=0.0), _event_created_ts(prev))
        chosen = r if a >= b else prev
        chosen["matched_strategy_keys"] = merged_keys
        chosen["matched_strategy_labels"] = merged_labels
        merged[key] = chosen
    out = sorted(merged.values(), key=lambda x: (_STAGE_ORDER.get(_v510_stage(x),0), _v510_num(x.get("score"), default=0.0), _event_created_ts(x)), reverse=True)
    return out


def _v510_counts(rows: List[Dict[str, Any]]) -> Dict[str, int]:
    c = {"S1": 0, "S2": 0, "S3": 0}
    for r in rows:
        st = _v510_stage(r)
        c[st] = c.get(st, 0) + 1
    return c


def _v510_reason_top(rows: List[Dict[str, Any]], maxn: int = 20) -> List[Dict[str, Any]]:
    ctr: Dict[str, int] = {}
    for r in rows:
        if _v510_stage(r) == "S1": continue
        for reason in (r.get("s_stage_reasons") or r.get("block_reasons") or [])[:6]:
            s = str(reason or "").strip()
            if not s: continue
            # Collapse numeric variants lightly for panel readability.
            if "스프레드" in s: s = "스프레드"
            elif "미끄러짐" in s: s = "미끄러짐"
            elif "매수체결" in s: s = "매수체결"
            elif "1분" in s: s = "1분지속"
            elif "가격반응" in s: s = "가격반응"
            elif "신선" in s: s = "신선도재확인"
            ctr[s] = ctr.get(s, 0) + 1
    return [{"reason": k, "count": v} for k, v in sorted(ctr.items(), key=lambda kv: kv[1], reverse=True)[:maxn]]



def _v512_info_quality(feature_list: List[Dict[str, Any]], ofmap: Dict[str, Dict[str, Any]]) -> Dict[str, int]:
    """상태판이 읽는 정보품질 숫자를 single-pass canonical 기준으로 채운다.

    v510은 final_rows는 정상 생산했지만 /health 상단 정보요약이 0/전체로 표시됐다.
    이유는 예전 status/summary reader가 기대하던 quote_ready_count/micro_ready_count/full_info_ready_count
    계열 필드를 publish하지 않았기 때문이다. 여기서는 후보 조건을 바꾸지 않고, 같은 입력 feature/orderflow에서
    정보품질 숫자만 확정한다.
    """
    evaluated = len(feature_list)
    quote_ready = 0
    micro_ready = 0
    both_ready = 0
    orderflow_attached = 0
    price_ready = 0
    for row in feature_list:
        t = ticker_norm(row.get("ticker"))
        of = ofmap.get(t, {}) if t else {}
        has_price = _v510_num(row.get("current_price"), row.get("price"), of.get("quote_price"), of.get("current_price"), default=0.0) > 0
        quote = bool(of.get("quote_fresh") or of.get("ws_fresh") or has_price)
        micro = bool(of.get("micro_fresh") or of.get("orderflow_fresh") or of.get("buy_ratio") is not None or of.get("spread_pct") is not None)
        attached = bool(of)
        if has_price:
            price_ready += 1
        if attached:
            orderflow_attached += 1
        if quote:
            quote_ready += 1
        if micro:
            micro_ready += 1
        if quote and micro:
            both_ready += 1
    return {
        "price_ready_count": price_ready,
        "quote_ready_count": quote_ready,
        "market_price_ready_count": price_ready,
        "micro_ready_count": micro_ready,
        "full_info_ready_count": both_ready,
        "both_ready_count": both_ready,
        "orderflow_attached_count": orderflow_attached,
    }


def _v512_display_rows(rows: List[Dict[str, Any]], maxn: int = 80) -> List[Dict[str, Any]]:
    """candidate_reason/s1_lifecycle이 모두 볼 수 있는 표시 row aliases를 만든다.

    명령어 handler마다 top_candidates/items/rows/display_rows 중 서로 다른 key를 보던 구버전 흔적이 남아 있으므로,
    v512에서는 같은 canonical row를 여러 alias로만 publish한다. 새 계산 경로는 만들지 않는다.
    """
    out: List[Dict[str, Any]] = []
    for r in rows[:maxn]:
        rr = dict(r)
        rr.setdefault("display_name", rr.get("ticker") or rr.get("symbol"))
        rr.setdefault("stage", _v510_stage(rr))
        rr.setdefault("s_stage", _v510_stage(rr))
        rr.setdefault("strategy_label", rr.get("strategy") or rr.get("strategy_name") or rr.get("paper_strategy_label"))
        rr.setdefault("strategy_name", rr.get("strategy_label"))
        rr.setdefault("block_reasons", rr.get("s_stage_reasons") or rr.get("reasons") or [])
        rr.setdefault("missing_info", rr.get("missing_info") or [])
        rr.setdefault("structure_tags", rr.get("structure_tags") or rr.get("quality_structure_tags") or [])
        rr.setdefault("risk_tags", rr.get("risk_tags") or rr.get("quality_risk_tags") or [])
        out.append(rr)
    return out

# v533 removed legacy unused function: _v512_save_aliases

def _v512_enrich_summary_pointers(summary: Dict[str, Any], compact: Dict[str, Any], life: Dict[str, Any], recheck: Dict[str, Any]) -> None:
    """Expose cache pointers expected by older main-bot status readers."""
    ts = compact.get("updated_ts")
    summary.update({
        "candidate_reason_compact_cache_schema": compact.get("schema"),
        "candidate_reason_compact_cache_ts": ts,
        "candidate_reason_compact_cache_updated_ts": ts,
        "candidate_reason_compact_cache_status": compact.get("status", "fresh"),
        "candidate_reason_compact_cache_count": compact.get("candidate_count", 0),
        "candidate_reason_compact_cache_display_count": compact.get("display_count", 0),
        "candidate_reason_cache_file": str(CANDIDATE_REASON_COMPACT_CACHE), "candidate_reason_text_cache_file": str(CANDIDATE_REASON_TEXT_CACHE),
        "s1_lifecycle_schema": life.get("schema"),
        "s1_lifecycle_ts": life.get("updated_ts"),
        "s1_lifecycle_worker": life.get("worker"),
        "s1_lifecycle_fresh_count": life.get("fresh_count", 0),
        "s1_lifecycle_raw_count": life.get("raw_count", 0),
        "s1_lifecycle_cache_file": str(S1_LIFECYCLE_TRACE),
        "recheck_cache_schema": recheck.get("schema"),
        "recheck_cache_ts": recheck.get("updated_ts"),
        "recheck_candidate_count": recheck.get("candidate_count", 0),
    })


def _v513_legacy_candidate_reason_top(display_rows: List[Dict[str, Any]], limit: int = 10) -> List[Dict[str, Any]]:
    """Build the old /candidate_reason top_candidates shape from the same canonical display rows.

    Main-bot v468 is strict about the compact-cache schema/key shape.  We keep one
    canonical row source, but publish the compact payload in the legacy-compatible
    shape so the command does not report "cache 없음" while health/lifecycle can
    still read the same final rows.
    """
    top: List[Dict[str, Any]] = []
    for rr in display_rows[:limit]:
        st = _v510_stage(rr)
        fail = rr.get("block_reasons") or rr.get("s_stage_reasons") or rr.get("reasons") or []
        miss = rr.get("missing_info") or rr.get("entry_missing_info") or []
        risk = rr.get("risk_tags") or rr.get("structure_risk_tags") or []
        metrics = {
            "price_reaction_pct": _v510_num(rr.get("price_reaction_pct"), default=0.0),
            "spread_pct": _v510_num(rr.get("spread_pct"), default=0.0),
            "slippage_pct": _v510_num(rr.get("slippage_pct"), rr.get("spread_pct"), default=0.0),
            "buy_ratio": _v510_num(rr.get("buy_ratio"), default=0.0),
            "buy_sustain_1m": _v510_num(rr.get("buy_sustain_1m"), rr.get("buy_ratio"), default=0.0),
        }
        top.append({
            "ticker": ticker_norm(rr.get("ticker") or rr.get("market") or rr.get("symbol")),
            "stage": st,
            "s_stage": st,
            "strategy": str(rr.get("strategy_label") or rr.get("strategy") or rr.get("strategy_key") or "-"),
            "strategy_key": str(rr.get("strategy_key") or rr.get("paper_strategy_key") or "-"),
            "score": round(_v510_num(rr.get("score"), default=0.0), 2),
            "decision": str(rr.get("recheck_state") or rr.get("review_decision") or "-"),
            "block_reasons": _v510_uniq([str(x) for x in fail], 4),
            "missing_info": _v510_uniq([str(x) for x in miss], 3),
            "metrics": metrics,
            "metric_spine_source": "v513_canonical_final_rows",
            "needed_recovery": rr.get("needed_recovery") or rr.get("need_recovery") or [],
            "relative_context": rr.get("relative_context") or {},
            "structure_tags": rr.get("structure_tags") or [],
            "structure_good_tags": rr.get("structure_good_tags") or rr.get("structure_tags") or [],
            "structure_risk_tags": risk,
            "risk_tags": risk,
            "structure_fit": rr.get("structure_fit") or rr.get("structure_summary") or ("구조위험" if risk else "구조관찰"),
            "structure_summary": rr.get("structure_summary") or "",
            "market_regime_tags": rr.get("market_regime_tags") or [],
            "market_risk_tags": rr.get("market_risk_tags") or [],
            "market_regime_summary": rr.get("market_regime_summary") or "",
            "snapshot_ts": rr.get("updated_ts") or rr.get("created_at") or now_ts(),
            "snapshot_text": rr.get("updated_text") or now_text(),
            "fresh_for_paper": True,
        })
    return top


# =============================================================================
# strategy_worker v0.144 / v609: S3 near-S2 structure candle urgent lane
# - 조건/S등급 변경 없음.
# - strategy가 fresh_wait 후보뿐 아니라 S3 중 S2에 가까운 구조 후보도 candle_worker 긴급라인 파일로 봉인한다.
# - candle_worker 결과 cache를 candidate_reason에 같이 표시한다.
# =============================================================================
def _v608_candle_age_index() -> Dict[str, float]:
    obj = load_json(CANDLE, {}) or {}
    rows = obj.get('rows') if isinstance(obj, dict) else []
    nowv = now_ts(); out: Dict[str, float] = {}
    if isinstance(rows, list):
        for r in rows:
            if not isinstance(r, dict):
                continue
            t = ticker_norm(r.get('ticker') or r.get('symbol') or r.get('market'))
            ts = _v510_num(r.get('candle_ts'), default=0.0)
            if t:
                out[t] = max(999999.0 if ts <= 0 else 0.0, nowv - ts) if ts <= 0 else max(0.0, nowv - ts)
    return out

def _v608_row_text(row: Dict[str, Any]) -> str:
    vals: List[str] = []
    for k in ('final_trade_state','final_decision','final_trade_label','final_trade_reasons','v575_urgent_action_state','v574_fresh_urgent_reason','s2_promotion_lifecycle','s_stage_reasons','missing_info','risk_tags'):
        v = row.get(k)
        if isinstance(v, list): vals += [str(x) for x in v]
        elif isinstance(v, dict): vals.append(json.dumps(v, ensure_ascii=False, default=str))
        elif v not in (None, ''): vals.append(str(v))
    cm = row.get('canonical_metric_row') if isinstance(row.get('canonical_metric_row'), dict) else {}
    if isinstance(cm, dict):
        for k in ('final_trade_state','final_decision','final_trade_reasons','decision_reference'):
            v = cm.get(k)
            if isinstance(v, list): vals += [str(x) for x in v]
            elif v not in (None, ''): vals.append(str(v))
    return ' '.join(vals).lower()

def _v608_is_hard_risk_for_candle(row: Dict[str, Any]) -> bool:
    txt = _v608_row_text(row)
    # 캔들 긴급갱신 우선순위에서만 낮춘다. 후보 등급/조건 차단이 아니다.
    hard_words = (
        '가짜돌파', '방어실패', '구조위험', '늦은추격', '매도압력', '매도벽',
        '손실군', '위험우세', '상단저항', '윗꼬리', '실행위험 재확인'
    )
    return any(w in txt for w in hard_words)


def _v608_structure_good_for_candle(row: Dict[str, Any]) -> bool:
    vals: List[str] = []
    for k in ('entry_structure_tags','structure_tags','matched_strategy_labels','strategy_tags','entry_reasons','entry_basis','strategy','strategy_label'):
        v = row.get(k)
        if isinstance(v, list): vals += [str(x) for x in v]
        elif v not in (None, '', [], {}): vals.append(str(v))
    txt = ' '.join(vals) + ' ' + _v608_row_text(row)
    good_words = (
        'VWAP방어', 'EMA방어', '돈흐름재유입', '돈흐름', '눌림회복', '재가속',
        '주도흐름', '유동보유', '지지전환', '돌파', '회복', '방아쇠', 'recheck', 'trigger'
    )
    return any(w.lower() in txt.lower() for w in good_words)


def _v608_trigger_gap_for_candle(row: Dict[str, Any]) -> float:
    # 이미 row에 봉인된 gap이 있으면 먼저 사용한다.
    vals = [row.get('trigger_gap_pct'), row.get('s2_trigger_gap_pct'), row.get('gap_pct')]
    plan = row.get('entry_plan') if isinstance(row.get('entry_plan'), dict) else {}
    levels = row.get('structure_levels') if isinstance(row.get('structure_levels'), dict) else {}
    vals += [plan.get('trigger_gap_pct'), levels.get('trigger_gap_pct')]
    for v in vals:
        try:
            if v not in (None, ''):
                return abs(float(str(v).replace('%','')))
        except Exception:
            pass
    price = _v510_num(row.get('current_price'), row.get('entry_price'), row.get('price'), default=0.0)
    trigger = _v510_num(plan.get('trigger_price'), levels.get('trigger_price'), default=0.0)
    if price and trigger:
        try:
            return abs((trigger - price) / price * 100.0)
        except Exception:
            return 999.0
    return 999.0


def _v608_publish_candle_urgent_targets(rows: List[Dict[str, Any]], nowv: float) -> Dict[str, Any]:
    """v610 본선.
    v609는 S3까지 urgent에 올렸지만 모두 같은 무게로 처리해 candle_worker 처리량이 밀렸다.
    v610은 후보를 줄이지 않고 정보 투입량을 3단계로 나눈다.
    - core: OPEN/S1/S2/fresh_wait. 1m/3m/5m 전부.
    - near: near-S2/방아쇠근처 S3. 1m/3m 우선.
    - watch: 구조 좋은 S3/hot 구조 후보. 1m 최소 정보.
    조건/S등급/청산/장부는 변경하지 않는다.
    """
    age_map = _v608_candle_age_index()
    targets: List[Dict[str, Any]] = []
    seen=set()
    bucket_counter: Counter = Counter()
    lane_counter: Counter = Counter()

    lane_rank = {'core': 3000, 'near': 2000, 'watch': 1000}
    profile_by_lane = {'core': 'full_1m3m5m', 'near': 'mid_1m3m', 'watch': 'light_1m'}

    def add_target(row: Dict[str, Any], bucket: str, priority: int, target_age: int, reason: List[str], lane: str) -> None:
        t = ticker_norm(row.get('ticker') or row.get('symbol') or row.get('market'))
        if not t or t in seen:
            return
        lane = lane if lane in lane_rank else 'watch'
        age = age_map.get(t, 999999.0)
        targets.append({
            'ticker': t,
            'stage': _v510_stage(row),
            'bucket': bucket,
            'lane': lane,
            'profile': profile_by_lane.get(lane, 'light_1m'),
            'priority': int(lane_rank[lane] + priority),
            'raw_priority': priority,
            'required_age_sec': target_age,
            'current_age_sec': round(age, 1) if age < 999998 else None,
            'reason': ' / '.join(dict.fromkeys([str(x) for x in reason if x])),
            'retry_until_fresh': True,
            'requested_ts': nowv,
            'requested_text': now_text(nowv),
            'source': 'strategy_worker_v610_info_tier_candle_lane',
        })
        bucket_counter[bucket] += 1
        lane_counter[lane] += 1
        seen.add(t)

    for r in rows:
        if not isinstance(r, dict):
            continue
        st = _v510_stage(r)
        t = ticker_norm(r.get('ticker') or r.get('symbol') or r.get('market'))
        if not t or t in seen:
            continue
        txt = _v608_row_text(r)
        age = age_map.get(t, 999999.0)
        reason: List[str] = []

        if st == 'S1':
            if age > 75:
                add_target(r, 'core_S1_candle_fresh_lock', 1000, 90, ['S1 candle age >75s'], 'core')
            continue

        if st == 'S2':
            needs = False
            if bool(r.get('v574_fresh_urgent_request')):
                needs = True; reason.append('S2 fresh urgent')
            if any(w in txt for w in ('fresh_wait','신선','정보','공식 캔들','공식캔들','candle')):
                needs = True; reason.append('S2 candle/fresh wait')
            if age > 120 and ('s2_recheck' in txt or 'trigger_wait' in txt or 'fresh_wait' in txt):
                needs = True; reason.append('S2 stale while waiting')
            # S2는 fresh_wait 문구가 없어도 core lane에서 신선도 유지가 필요하다.
            if age > 180:
                needs = True; reason.append('S2 stale protection')
            if needs:
                add_target(r, 'core_S2_candle_fresh_lock', 940, 120, reason, 'core')
            continue

        if st != 'S3':
            continue
        if age <= 120:
            continue
        hard_risk = _v608_is_hard_risk_for_candle(r)
        structure_good = _v608_structure_good_for_candle(r)
        gap = _v608_trigger_gap_for_candle(r)
        s1_near = bool(r.get('s1_near_miss')) or str(r.get('s1_near_miss_level') or '').lower() in ('near','mid') or 'near_s1' in txt or 'would_be_s1' in txt
        hot_like = any(w in txt for w in ('hot', 'spike', '급등', '재확인', 'recheck'))
        fresh_text = any(w in txt for w in ('fresh_wait','신선','정보','공식 캔들','공식캔들','candle'))

        if s1_near and not hard_risk:
            add_target(r, 'near_S2_structure_candle', 860, 150, ['S3 near-S2 structure', f'age {round(age,1)}s'], 'near')
        elif gap <= 0.80 and not hard_risk:
            add_target(r, 'near_S3_trigger_candle', 820, 150, [f'trigger_gap {gap:.2f}%', f'age {round(age,1)}s'], 'near')
        elif structure_good and fresh_text and not hard_risk:
            add_target(r, 'near_S3_structure_good_fresh_wait', 780, 180, ['structure good + candle/fresh wait', f'age {round(age,1)}s'], 'near')
        elif hot_like and structure_good and age > 180 and not hard_risk:
            add_target(r, 'watch_S3_hot_structure_candle', 720, 240, ['hot/recheck + structure', f'age {round(age,1)}s'], 'watch')
        elif structure_good and age > 300 and not hard_risk:
            add_target(r, 'watch_S3_structure_refresh', 640, 300, ['structure watch stale refresh', f'age {round(age,1)}s'], 'watch')

    # 서버 보호용 상한. 후보를 버리는 조건이 아니라 candle 작업 큐 보호다.
    targets = sorted(targets, key=lambda x: int(x.get('priority') or 0), reverse=True)[:120]
    obj = {
        'schema': 'candle_urgent_targets_v610_info_tier',
        'version': VERSION,
        'updated_ts': nowv,
        'updated_text': now_text(nowv),
        'request_count': len(targets),
        'targets': [x.get('ticker') for x in targets],
        'bucket_counts': dict(bucket_counter),
        'lane_counts': dict(lane_counter),
        'rows': targets,
        'policy': 'v610: candidate count is not reduced; information depth is tiered. core=1m/3m/5m, near=1m/3m, watch=1m. No strategy thresholds changed.',
    }
    save_json(CANDLE_URGENT_TARGETS, obj)
    result = load_json(CANDLE_URGENT_RESULT, {}) or {}
    lane_result = result.get('lane_result') if isinstance(result, dict) and isinstance(result.get('lane_result'), dict) else {}
    return {
        'schema': 'strategy_candle_urgent_lock_summary_v610_info_tier',
        'version': VERSION,
        'request_count': len(targets),
        'targets': obj.get('targets'),
        'bucket_counts': obj.get('bucket_counts'),
        'lane_counts': obj.get('lane_counts'),
        'result_schema': result.get('schema') if isinstance(result, dict) else None,
        'result_requested': result.get('requested_count') if isinstance(result, dict) else None,
        'result_refreshed': result.get('refreshed_count') if isinstance(result, dict) else None,
        'result_under_target': result.get('under_target_age_count') if isinstance(result, dict) else None,
        'result_miss': result.get('miss_count') if isinstance(result, dict) else None,
        'lane_result': lane_result,
        'result_rows': (result.get('rows') or [])[:12] if isinstance(result, dict) else [],
        'policy': obj.get('policy'),
    }

def _v510_publish(rows: List[Dict[str, Any]], rejects: List[Dict[str, Any]], priority_requests: List[Dict[str, Any]], evaluated: int, cycle_ts: float, info_quality: Optional[Dict[str, int]] = None) -> Dict[str, Any]:
    nowv = now_ts()
    # v554: publish structure-level entry plans for every strategy row before all caches are rendered.
    rows = _v554_apply_entry_plan_state(rows, nowv)
    # v584: 구조/fresh/실행위험/진입타이밍을 canonical_metric_row로 봉인한다.
    rows = _v583_attach_structure_freshness(rows, nowv)
    # v563: S2->S1 승격 실패 생애주기를 같은 canonical row에 봉인한다.
    rows, s2_promotion_trace = _v563_attach_s2_promotion_lifecycle(rows, nowv)
    # v574: S2->S1 근접인데 fresh가 오래된 후보는 S2에 묵히지 않고
    # target_router/micro urgent 갱신 요청으로 보낸다. 조건/S등급 수치는 변경하지 않는다.
    priority_requests, v574_fresh_urgent_summary = _v574_attach_s2_fresh_urgent_requests(rows, priority_requests, nowv)
    v608_candle_urgent_summary = _v608_publish_candle_urgent_targets(rows, nowv)
    counts = _v510_counts(rows)
    info_quality = info_quality or {}
    display_rows = _v512_display_rows(rows, 120)
    lane_counts: Dict[str, int] = {}
    for r in rows:
        lane = str(r.get("canonical_lane") or "base")
        lane_counts[lane] = lane_counts.get(lane, 0) + 1
    s1_missing_counter = Counter()
    for r in rows:
        for x in (r.get("s1_missing_names") or []):
            s1_missing_counter[str(x)] += 1
    s1_near_count = sum(1 for r in rows if bool(r.get("s1_near_miss")))
    write_jsonl_atomic(PAPER_LATEST, rows)
    # Runtime OPEN does not append to archive. Archive/trade log stays paper-owned/history-only.
    priority_requests = sorted(priority_requests, key=lambda x: _v510_num(x.get("priority"), default=0.0), reverse=True)
    targets = list(dict.fromkeys([ticker_norm(r.get("ticker")) for r in priority_requests if ticker_norm(r.get("ticker"))]))
    pr_obj = {"schema": "strategy_priority_requests_v512", "version": VERSION, "updated_ts": nowv, "updated_text": now_text(nowv), "request_count": len(priority_requests), "targets": targets, "requests": priority_requests, "buckets": {}}
    for pr in priority_requests:
        b = str(pr.get("bucket") or "-"); pr_obj["buckets"][b] = pr_obj["buckets"].get(b, 0) + 1
    save_json(PRIORITY_REQ, pr_obj)
    reason_top = _v510_reason_top(rows)
    summary = {"schema": V510_SCHEMA, "version": VERSION, "main_version": MAIN_VERSION, "updated_ts": nowv, "updated_text": now_text(nowv), "evaluated": evaluated, "paper_latest_count": len(rows), "s_count": len(rows), "s_stage_counts": counts, "stage_counts": counts, "s1_count": counts.get("S1",0), "s2_count": counts.get("S2",0), "s3_count": counts.get("S3",0), "lane_counts": lane_counts, "reason_top": reason_top, "s1_diagnostic": {"schema":"v532_canonical_entry_decision", "near_miss_count": s1_near_count, "missing_top": dict(s1_missing_counter.most_common(8))}, "target_count": len(targets), "priority_request_count": len(priority_requests), "events": display_rows[:20], "sample": display_rows[:20], "top_candidates": display_rows[:20], "last_sec": round(nowv - cycle_ts, 3), "policy": "v554: 모든 전략에 구조선/진입계획/손익비/S2대기 역할을 붙임. 조건값/청산/자동매수 변경 없음."}
    summary.update(info_quality)
    summary["freshness_overlay"] = {"schema": "v536_profile_simplified", "scanner_hot_cache_age_sec": round(_v521_file_age(SCANNER_HOT), 3), "orderflow_cache_age_sec": round(_v521_file_age(ORDERFLOW), 3)}
    summary["v574_fresh_urgent_summary"] = v574_fresh_urgent_summary
    summary["v608_candle_urgent_summary"] = v608_candle_urgent_summary
    summary["fresh_urgent_request_count_v574"] = int(v574_fresh_urgent_summary.get("request_count") or 0) if isinstance(v574_fresh_urgent_summary, dict) else 0
    summary["s2_promotion_trace"] = s2_promotion_trace
    summary["s2_promotion_trace_schema"] = s2_promotion_trace.get("schema")
    summary["s2_promotion_trace_file"] = str(S2_PROMOTION_TRACE)
    save_json(SUMMARY, summary)
    save_json(REJECT, {**summary, "reject_count": len(rejects), "reject_sample": rejects[:30]})
    legacy_top = _v513_legacy_candidate_reason_top(display_rows, limit=10)
    compact = {"schema": "candidate_reason_compact_cache_v557_worker_rendered", "version": VERSION, "updated_ts": nowv, "updated_text": now_text(nowv), "status": "fresh", "evaluated": evaluated, "paper_latest_count": len(rows), "candidate_count": len(rows), "raw_candidate_count": len(rows), "stale_candidate_count": 0, "stale_s1_ignored_count": 0, "display_count": len(display_rows), "s_stage_counts": counts, "stage_counts": counts, "reason_top": reason_top, "missing_info_top": [x for x in reason_top if "정보" in x.get("reason", "")], "metric_spine_source_top": [{"reason": "v513_canonical_final_rows", "count": len(rows)}], "top_candidates": legacy_top, "display_rows": display_rows, "display_candidates": display_rows, "candidates": display_rows, "items": display_rows, "rows": display_rows, "top": legacy_top, "policy": summary["policy"]}
    compact["s2_promotion_trace"] = s2_promotion_trace
    compact["v574_fresh_urgent_summary"] = v574_fresh_urgent_summary
    compact["v608_candle_urgent_summary"] = v608_candle_urgent_summary
    compact["fresh_urgent_request_count_v574"] = int(v574_fresh_urgent_summary.get("request_count") or 0) if isinstance(v574_fresh_urgent_summary, dict) else 0
    compact["s2_promotion_trace_file"] = str(S2_PROMOTION_TRACE)
    v557_summary = _v557_build_candidate_reason_summary(display_rows, counts, reason_top, nowv)
    compact["summary_schema"] = v557_summary.get("schema")
    compact["summary_text"] = v557_summary.get("summary_text")
    compact["batch_state"] = v557_summary.get("batch_state")
    # v604: /candidate_reason 기본 명령이 큰 JSON을 파싱하지 않도록
    # worker가 미리 만든 text cache를 별도 파일로 봉인한다.
    # 정보 삭제가 아니라 소비 경로 변경이다: main_bot은 이 작은 text cache만 읽는다.
    try:
        text_summary = str(v557_summary.get("summary_text") or "").strip()
        CANDIDATE_REASON_TEXT_CACHE.parent.mkdir(parents=True, exist_ok=True)
        tmp_txt = CANDIDATE_REASON_TEXT_CACHE.with_suffix(CANDIDATE_REASON_TEXT_CACHE.suffix + ".tmp")
        tmp_txt.write_text(text_summary + "\n", encoding="utf-8")
        os.replace(tmp_txt, CANDIDATE_REASON_TEXT_CACHE)
        state_obj = {
            "schema": "candidate_reason_text_state_v610",
            "version": VERSION,
            "updated_ts": nowv,
            "updated_text": now_text(nowv),
            "text_cache_file": str(CANDIDATE_REASON_TEXT_CACHE),
            "text_len": len(text_summary),
            "stage_counts": counts,
            "rows": len(rows),
            "s1_count": counts.get("S1", 0),
            "s2_count": counts.get("S2", 0),
            "s3_count": counts.get("S3", 0),
            "priority_request_count": len(priority_requests),
            "policy": "v610: main /candidate_reason reads this text file directly; candle information depth is tiered by core/near/watch.",
        }
        save_json(CANDIDATE_REASON_STATE_CACHE, state_obj)
    except Exception as exc:
        append_error(ERROR, "v604_candidate_reason_text_cache", exc)
    summary["candidate_reason_worker_rendered"] = True
    summary["candidate_reason_summary_schema"] = v557_summary.get("schema")
    compact.update(info_quality)
    compact["top_rows"] = legacy_top
    compact["display_candidates"] = compact.get("display_rows", [])
    compact["source_file"] = str(PAPER_LATEST)
    compact["source_policy"] = summary["policy"]
    summary["legacy_candidate_reason_alias_publish"] = False  # v525: disabled
    re_rows = [r for r in rows if _v510_stage(r) in ("S2", "S3")]
    re_state_counts: Dict[str, int] = {}
    for r in re_rows:
        st = "위험우선" if r.get("risk_tags") else ("유연재확인" if _v510_stage(r) == "S2" else "추적중")
        r["recheck_state"] = st
        re_state_counts[st] = re_state_counts.get(st, 0) + 1
    recheck_display = _v512_display_rows(re_rows, 160)
    recheck = {"schema": "recheck_candidates_cache_v513", "version": VERSION, "updated_ts": nowv, "updated_text": now_text(nowv), "candidate_count": len(re_rows), "state_counts": re_state_counts, "top": recheck_display[:80], "top_candidates": recheck_display[:80], "display_rows": recheck_display, "rows": recheck_display, "promotion_summary": {"s1_promotion_count": counts.get("S1",0), "policy": "S2=진입계획 대기, S3=구조관찰. paper OPEN은 S1만."}, "s2_promotion_trace": s2_promotion_trace}
    summary["legacy_recheck_cache_publish"] = False  # v525: disabled; target_router reads paper_latest
    summary["legacy_recheck_state_publish"] = False  # v525 disabled
    s1_rows = [r for r in display_rows if _v510_stage(r)=="S1"]
    life = {"schema": "s1_lifecycle_trace_v563_canonical_s2_promotion", "version": VERSION, "worker": VERSION, "updated_ts": nowv, "updated_text": now_text(nowv), "current_s1_count": counts.get("S1",0), "current_s2_count": counts.get("S2",0), "current_s3_count": counts.get("S3",0), "recent_s1_count": counts.get("S1",0), "paper_waiting_count": 0, "paper_pre_downgrade_count": 0, "paper_block_count": 0, "paper_final_block_count": 0, "expired_s1_ignored_count": 0, "fresh_count": len(rows), "raw_count": len(rows), "current_fresh_count": len(rows), "current_raw_count": len(rows), "fresh_candidate_count": len(rows), "raw_candidate_count": len(rows), "counts": counts, "stage_counts": counts, "current_s1": s1_rows, "current_s1_rows": s1_rows, "paper_waiting": [], "paper_pre_downgrade": [], "paper_blocked": [], "paper_final_blocked": [], "expired_s1_ignored": [], "flow_rows": display_rows[:80], "recent_flow": display_rows[:80], "recent_rows": display_rows[:80], "top": display_rows[:80], "rows": display_rows, "s2_promotion_trace": s2_promotion_trace, "policy": "candidate_reason/s1_lifecycle/summary all read the same final_rows with S2 promotion lifecycle."}
    summary["legacy_s1_lifecycle_alias_publish"] = False  # v525: disabled
    summary["legacy_s1_lifecycle_state_publish"] = False  # v525 disabled
    # v550: publish every canonical read cache from the same final_rows batch.
    # This removes the split where paper_candidates_latest was current but
    # /candidate_reason kept reading an old compact cache.  No strategy or exit
    # threshold is changed here; this is a factory-output spine fix only.
    save_json(CANDIDATE_REASON_COMPACT_CACHE, compact)
    save_json(RECHECK_CACHE, recheck)
    save_json(RECHECK_STATE, recheck)
    save_json(S1_LIFECYCLE_TRACE, life)
    save_json(S1_LIFECYCLE_STATE, life)

    # v512: summary/health readers also need direct pointers to compact/lifecycle caches.
    _v512_enrich_summary_pointers(summary, compact, life, recheck)
    save_json(SUMMARY, summary)
    save_json(REJECT, {**summary, "reject_count": len(rejects), "reject_sample": rejects[:30]})
    can = {"schema": "strategy_canonical_summary_v584_canonical_metric_row", "version": VERSION, "updated_ts": nowv, "cycle_started_ts": cycle_ts, "cycle_elapsed_sec": round(nowv-cycle_ts,3), "s_stage_counts": counts, "paper_latest_count": len(rows), "candidate_reason": {"schema": compact["schema"], "updated_ts": nowv, "candidate_count": len(rows)}, "recheck": {"schema": recheck["schema"], "updated_ts": nowv, "candidate_count": len(re_rows)}, "s1_lifecycle": {"schema": life["schema"], "updated_ts": nowv, "current_s1_count": counts.get("S1",0)}, "s2_promotion_trace": s2_promotion_trace, "v574_fresh_urgent_summary": v574_fresh_urgent_summary, "source_policy": summary["policy"]}
    save_json(CANONICAL_STRATEGY_SUMMARY, can)
    price_ready_count = sum(1 for r in rows if _v510_num(r.get("current_price"), r.get("entry_price"), r.get("price"), default=0.0) > 0)
    save_json(HANDOFF, {"schema": "paper_handoff_status_v525", "version": VERSION, "updated_ts": nowv, "updated_text": now_text(nowv), "latest_count": len(rows), "stage_counts": counts, "lane_counts": lane_counts, "price_ready_count": price_ready_count, "source": "paper_candidates_latest", "archive_runtime_open": False, "old_latest_remix": False, "price_policy": "strategy seals current_price/entry_price/detected_price and v554 structure_levels/entry_plan for paper_bot"})
    save_json(V510_TRACE, {"schema": V510_SCHEMA, "version": VERSION, "updated_ts": nowv, "elapsed_sec": round(nowv-cycle_ts,3), "evaluated": evaluated, "stage_counts": counts, "lane_counts": lane_counts, "reason_top": reason_top, "sample": rows[:12]})
    write_status("running", phase="cycle_done_v525", phase_note="v584 canonical metric row publish", phase_started_ts=cycle_ts, strategy_worker_version=VERSION, main_version=MAIN_VERSION, deploy_version=MAIN_DEPLOY_VERSION, evaluated=evaluated, row_count=evaluated, s_count=len(rows), paper_latest_count=len(rows), s1_count=counts.get("S1",0), s2_count=counts.get("S2",0), s3_count=counts.get("S3",0), target_count=len(targets), priority_request_count=len(priority_requests), last_sec=round(nowv-cycle_ts,3), status_route_schema="strategy_status_v584_canonical_metric_row", **info_quality)
    return summary


def run_once() -> Dict[str, Any]:  # type: ignore[override]
    cycle_ts = now_ts()
    try:
        write_status("running", phase="evaluating_v544", phase_note="v529 S1 checklist inline publish 시작", strategy_worker_version=VERSION)
        fobj = load_json(FEATURE, {}) or {}
        raw_feature_list = feature_rows(fobj)
        # v597: feature rows may be produced by an older feature worker during deploy overlap.
        # Read candle_worker cache directly as a worker-cache overlay so official structure inputs
        # reach canonical rows without strategy calling external APIs.
        candle_map = map_rows(load_json(CANDLE, {}) or {})
        raw_feature_list = [_v597_overlay_candle_cache(src, candle_map, cycle_ts) for src in raw_feature_list]
        hotmap = _v521_hot_map()
        feature_list = [_v521_overlay_feature(src, hotmap.get(ticker_norm(src.get("ticker") or src.get("market") or src.get("symbol")), {})) for src in raw_feature_list]
        ofmap = _v521_load_map_with_cache_age(ORDERFLOW, "orderflow")
        base_rows, rejects, reqs = _v510_base_lane(cycle_ts, feature_list, ofmap)
        spike_rows = _v510_spike_lane(cycle_ts, feature_list, ofmap)
        final_rows = _v510_merge_rows(base_rows + spike_rows, cycle_ts)
        info_quality = _v512_info_quality(feature_list, ofmap)
        # Requests from spike rows are added after merge so stale/blocked rows still get recheck/urgent targets if useful.
        for r in final_rows:
            t = ticker_norm(r.get("ticker"))
            if not t: continue
            bucket = "s1_candidate" if _v510_stage(r)=="S1" else ("spike_recheck" if str(r.get("canonical_lane"))=="spike" else "recheck_candidate")
            pri = 180 if _v510_stage(r)=="S1" else (130 if _v510_stage(r)=="S2" else 90)
            reqs.append({"ticker": t, "bucket": bucket, "priority": pri + _v510_num(r.get("score"), default=0.0), "need": ["quote", "micro"], "source": "strategy_worker_v529", "strategy_key": r.get("strategy_key"), "stage": _v510_stage(r), "reasons": r.get("s_stage_reasons", [])[:6], "updated_ts": cycle_ts})
        return _v510_publish(final_rows, rejects, reqs, len(feature_list), cycle_ts, info_quality)
    except Exception as exc:
        append_error(ERROR, "v513_run_once", exc)
        write_status("error", error=f"{exc.__class__.__name__}: {exc}", strategy_worker_version=VERSION)
        raise



# =============================================================================
# strategy_worker v0.121 / v558: worker-rendered candidate summary cache producer
# - 메인봇 기본 명령은 후보 정렬/포맷을 하지 않고 이 summary_text만 읽는다.
# - paper_candidates_latest, candidate_reason compact, handoff status를 같은 final_rows에서 함께 생산한다.
# - 조건/S1/S2/S3/청산 수치 변경 없음.
# =============================================================================
def _v558_label_list(vals: Any, limit: int = 5) -> str:
    if not isinstance(vals, list):
        return "-"
    out: List[str] = []
    for v in vals:
        txt = str(v or "").strip()
        if txt and txt not in out:
            out.append(txt)
        if len(out) >= limit:
            break
    return ", ".join(out) if out else "-"


def _v558_price(x: Any) -> str:
    v = _v510_num(x, default=0.0)
    if v <= 0:
        return "-"
    if v >= 1000:
        return f"{v:,.0f}"
    if v >= 100:
        return f"{v:.1f}".rstrip("0").rstrip(".")
    if v >= 10:
        return f"{v:.2f}".rstrip("0").rstrip(".")
    if v >= 1:
        return f"{v:.4f}".rstrip("0").rstrip(".")
    return f"{v:.6f}".rstrip("0").rstrip(".")


def _v558_top_join(items: Any, limit: int = 5) -> str:
    if not items:
        return "-"
    out: List[str] = []
    if isinstance(items, dict):
        seq = sorted(items.items(), key=lambda kv: -int(kv[1] or 0))
        for k, v in seq[:limit]:
            out.append(f"{k} {v}")
    elif isinstance(items, list):
        for it in items[:limit]:
            if isinstance(it, dict):
                name = str(it.get("reason") or it.get("name") or it.get("key") or "-")
                cnt = it.get("count") or it.get("n") or ""
                out.append(f"{name} {cnt}".strip())
            else:
                out.append(str(it))
    return " / ".join([x for x in out if x and x != "-"]) or "-"


def _v558_counter_top(rows: List[Dict[str, Any]], keys: Tuple[str, ...], limit: int = 5) -> str:
    c: Counter = Counter()
    for r in rows:
        for k in keys:
            vals = r.get(k)
            if isinstance(vals, list):
                for v in vals:
                    txt = str(v or "").strip()
                    if txt: c[txt] += 1
            elif vals not in (None, "", [], {}):
                txt = str(vals).strip()
                if txt: c[txt] += 1
    return " / ".join(f"{k} {v}" for k, v in c.most_common(limit)) if c else "-"


def _v558_metric(row: Dict[str, Any], key: str, default: float = 0.0) -> float:
    m = row.get("metrics") if isinstance(row.get("metrics"), dict) else {}
    return _v510_num(row.get(key), m.get(key), default=default)


def _v558_build_candidate_reason_summary(display_rows: List[Dict[str, Any]], counts: Dict[str, int], reason_top: Any, nowv: float) -> Dict[str, Any]:
    rows = [r for r in display_rows if isinstance(r, dict)]
    s2_rows = [r for r in rows if _v510_stage(r) == "S2"]
    s1_near = sum(1 for r in rows if bool(r.get("s1_near_miss")) or str(r.get("s1_distance_label") or "").startswith("S1"))
    strategy_top = _v558_counter_top(rows, ("matched_strategy_labels", "strategy_tags", "structure_tags", "strategy", "strategy_key"), 5)
    risk_top = _v558_counter_top(rows, ("risk_tags", "execution_risk_tags", "structure_risk_tags"), 5)
    s2_recheck_top = _v558_counter_top(s2_rows, ("recheck_reasons", "s2_recheck_reasons", "missing_info", "block_reasons"), 5)
    top = rows[:3]
    lines = [
        "🧭 후보판정 이유 /candidate_reason · v558 worker-rendered cache",
        "- 기준: strategy_worker가 미리 만든 summary_text만 읽습니다. 후보 재계산 없음.",
        f"- rows {len(rows)} / updated {now_text(nowv)} / fresh",
        f"- 현재 단계: S1 {counts.get('S1',0)} / S2 {counts.get('S2',0)} / S3 {counts.get('S3',0)} / 제외 {counts.get('제외', counts.get('X',0))}",
        f"- S1 근접후보: {s1_near} / S2 재확인 TOP: {s2_recheck_top}",
        f"- 전략/발견 TOP: {strategy_top}",
        f"- 위험 TOP: {risk_top}",
        "",
        "[상위 후보 3개 · 구조선/계획]",
    ]
    if not top:
        lines.append("- 표시 후보 없음")
    for idx, r in enumerate(top, 1):
        t = ticker_norm(r.get("ticker") or r.get("symbol") or r.get("market")) or "-"
        st = _v510_stage(r)
        strat = str(r.get("strategy_label") or r.get("strategy") or r.get("strategy_key") or "-")
        price = _v510_num(r.get("current_price"), r.get("entry_price"), r.get("price"), default=0.0)
        react = _v558_metric(r, "price_reaction_pct")
        buy = _v558_metric(r, "buy_ratio")
        sustain = _v558_metric(r, "buy_sustain_1m")
        spread = _v558_metric(r, "spread_pct")
        levels = r.get("structure_levels") if isinstance(r.get("structure_levels"), dict) else {}
        plan = r.get("entry_plan") if isinstance(r.get("entry_plan"), dict) else {}
        rr = r.get("risk_reward") if isinstance(r.get("risk_reward"), dict) else {}
        timing = r.get("entry_timing_spine") if isinstance(r.get("entry_timing_spine"), dict) else {}
        late = "-"
        if r.get("late_chase_flag") or timing.get("late_chase_flag") or levels.get("late_chase_flag"):
            basis = levels.get("late_chase_basis") if isinstance(levels.get("late_chase_basis"), dict) else {}
            br = _v510_num(basis.get("reaction"), react, default=0.0)
            bs = _v510_num(basis.get("spread"), spread, default=0.0)
            late = f"⚠️ 주의({br:+.2f}%/{bs:.2f}%)"
        first_sec = timing.get("first_to_now_delay_sec", timing.get("first_to_current_delay_sec"))
        s2_sec = timing.get("s2_to_now_delay_sec", timing.get("s2_to_current_delay_sec"))
        first_ret = _v510_num(timing.get("first_to_now_return_pct"), timing.get("first_to_current_return_pct"), default=0.0)
        s2_ret = _v510_num(timing.get("s2_to_now_return_pct"), timing.get("s2_to_current_return_pct"), default=0.0)
        down = _v510_num(rr.get("expected_downside_pct"), levels.get("expected_downside_pct"), default=0.0)
        if down > 0: down = -abs(down)
        up = _v510_num(rr.get("expected_upside_pct"), levels.get("expected_upside_pct"), default=0.0)
        ratio = _v510_num(rr.get("rr_ratio"), levels.get("rr_ratio"), default=0.0)
        lines.extend([
            f"{idx}) {t} · {st} · {strat}",
            f"   수치: 반응 {react:+.2f}% / 매수 {buy:.2f} / 1분 {sustain:.2f} / 스프 {spread:.2f}% / 가격 {_v558_price(price)}",
            f"   구조: {_v558_label_list(r.get('entry_structure_tags') or r.get('structure_tags') or r.get('matched_strategy_labels'), 6)}",
            f"   구조선: 지지 {_v558_price(levels.get('support_price'))} / 방아쇠 {_v558_price(levels.get('trigger_price'))} / 무효 {_v558_price(levels.get('invalid_price'))} / 목표 {_v558_price(levels.get('target1_price'))}→{_v558_price(levels.get('target2_price'))}",
            f"   진입계획: {plan.get('trigger_reason') or levels.get('trigger_reason') or plan.get('plan_type') or '-'}",
            f"   손익비: 기대 {up:+.2f}% / 무효손실 {down:+.2f}% / RR {ratio:.2f}",
            f"   타이밍: 최초→현재 {first_sec if first_sec is not None else '-'}s/{first_ret:+.2f}% · S2→현재 {s2_sec if s2_sec is not None else '-'}s/{s2_ret:+.2f}% · 늦은추격 {late}",
            f"   재확인: {_v558_label_list(r.get('recheck_reasons') or r.get('s2_recheck_reasons') or r.get('missing_info'), 5)}",
            f"   위험: {_v558_label_list(r.get('execution_risk_tags') or r.get('risk_tags') or r.get('structure_risk_tags'), 5)}",
            "",
        ])
    lines.extend(["[안내]", "- 상세 후보 전체는 /candidate_reason_full에서 확인. 기본판은 worker-rendered cache만 표시합니다."])
    batch_state = {
        "schema": "candidate_reason_batch_state_v558",
        "rows": len(rows),
        "stage_counts": dict(counts or {}),
        "s1_near_count": s1_near,
        "s2_recheck_top": s2_recheck_top,
        "strategy_top": strategy_top,
        "risk_top": risk_top,
        "updated_ts": nowv,
        "updated_text": now_text(nowv),
    }
    return {"schema": "candidate_reason_summary_text_v558", "summary_text": "\n".join(lines), "batch_state": batch_state}

# Keep v557 callsite name, but the producer is v558.
_v557_build_candidate_reason_summary = _v558_build_candidate_reason_summary


# =============================================================================
# strategy_worker v0.123 / v560: compact worker-rendered summary
# - 기본 명령 속도 개선을 위해 summary_text를 더 짧게 생성한다.
# - count는 row별 중복 태그를 줄여 과대집계 착시를 줄인다.
# - 조건/S1/S2/S3/청산 기준 변경 없음.
# =============================================================================
def _v559_counter_top(rows: List[Dict[str, Any]], keys: Tuple[str, ...], limit: int = 5) -> str:
    c: Counter = Counter()
    for r in rows:
        seen: set[str] = set()
        for k in keys:
            vals = r.get(k)
            if isinstance(vals, list):
                for v in vals:
                    txt = str(v or '').strip()
                    if txt:
                        seen.add(txt)
            elif vals not in (None, '', [], {}):
                seen.add(str(vals).strip())
        for txt in seen:
            c[txt] += 1
    return ' / '.join(f'{k} {v}' for k, v in c.most_common(limit)) if c else '-'


def _v559_build_candidate_reason_summary(display_rows: List[Dict[str, Any]], counts: Dict[str, int], reason_top: Any, nowv: float) -> Dict[str, Any]:
    rows = [r for r in display_rows if isinstance(r, dict)]
    s2_rows = [r for r in rows if _v510_stage(r) == 'S2']
    s1_near = sum(1 for r in rows if bool(r.get('s1_near_miss')) or str(r.get('s1_distance_label') or '').startswith('S1'))
    strategy_top = _v559_counter_top(rows, ('matched_strategy_labels','strategy_tags','structure_tags','strategy','strategy_key'), 5)
    risk_top = _v559_counter_top(rows, ('risk_tags','execution_risk_tags','structure_risk_tags'), 5)
    s2_recheck_top = _v559_counter_top(s2_rows, ('recheck_reasons','s2_recheck_reasons','missing_info','block_reasons'), 5)
    top = rows[:2]
    lines = [
        '🧭 후보판정 이유 /candidate_reason · v560 worker-rendered cache',
        '- 기준: strategy_worker가 미리 만든 summary_text만 읽습니다. 후보 재계산 없음.',
        f'- rows {len(rows)} / updated {now_text(nowv)} / fresh',
        f'- 현재 단계: S1 {counts.get("S1",0)} / S2 {counts.get("S2",0)} / S3 {counts.get("S3",0)} / 제외 {counts.get("제외", counts.get("X",0))}',
        f'- S1 근접후보: {s1_near} / S2 재확인 TOP: {s2_recheck_top}',
        f'- 전략/발견 TOP: {strategy_top}',
        f'- 위험 TOP: {risk_top}',
        '',
        '[상위 후보 2개 · 구조선/계획]',
    ]
    if not top:
        lines.append('- 표시 후보 없음')
    for idx, r in enumerate(top, 1):
        t = ticker_norm(r.get('ticker') or r.get('symbol') or r.get('market')) or '-'
        st = _v510_stage(r)
        strat = str(r.get('strategy_label') or r.get('strategy') or r.get('strategy_key') or '-')
        price = _v510_num(r.get('current_price'), r.get('entry_price'), r.get('price'), default=0.0)
        react = _v558_metric(r, 'price_reaction_pct')
        buy = _v558_metric(r, 'buy_ratio')
        sustain = _v558_metric(r, 'buy_sustain_1m')
        spread = _v558_metric(r, 'spread_pct')
        levels = r.get('structure_levels') if isinstance(r.get('structure_levels'), dict) else {}
        plan = r.get('entry_plan') if isinstance(r.get('entry_plan'), dict) else {}
        rr = r.get('risk_reward') if isinstance(r.get('risk_reward'), dict) else {}
        timing = r.get('entry_timing_spine') if isinstance(r.get('entry_timing_spine'), dict) else {}
        first_sec = timing.get('first_to_now_delay_sec', timing.get('first_to_current_delay_sec'))
        s2_sec = timing.get('s2_to_now_delay_sec', timing.get('s2_to_current_delay_sec'))
        first_ret = _v510_num(timing.get('first_to_now_return_pct'), timing.get('first_to_current_return_pct'), default=0.0)
        s2_ret = _v510_num(timing.get('s2_to_now_return_pct'), timing.get('s2_to_current_return_pct'), default=0.0)
        down = _v510_num(rr.get('expected_downside_pct'), levels.get('expected_downside_pct'), default=0.0)
        if down > 0: down = -abs(down)
        up = _v510_num(rr.get('expected_upside_pct'), levels.get('expected_upside_pct'), default=0.0)
        ratio = _v510_num(rr.get('rr_ratio'), levels.get('rr_ratio'), default=0.0)
        late = '-'
        if r.get('late_chase_flag') or timing.get('late_chase_flag') or levels.get('late_chase_flag'):
            basis = levels.get('late_chase_basis') if isinstance(levels.get('late_chase_basis'), dict) else {}
            br = _v510_num(basis.get('reaction'), react, default=0.0)
            bs = _v510_num(basis.get('spread'), spread, default=0.0)
            late = f'⚠️ {br:+.2f}%/스프 {bs:.2f}%'
        lines.extend([
            f'{idx}) {t} · {st} · {strat}',
            f'   수치: 반응 {react:+.2f}% / 매수 {buy:.2f} / 1분 {sustain:.2f} / 스프 {spread:.2f}% / 가격 {_v558_price(price)}',
            f'   구조선: 지지 {_v558_price(levels.get("support_price"))} / 방아쇠 {_v558_price(levels.get("trigger_price"))} / 무효 {_v558_price(levels.get("invalid_price"))} / 목표 {_v558_price(levels.get("target1_price"))}→{_v558_price(levels.get("target2_price"))}',
            f'   계획: {plan.get("trigger_reason") or levels.get("trigger_reason") or plan.get("plan_type") or "-"} / RR {ratio:.2f} / 기대 {up:+.2f}% / 무효 {down:+.2f}%',
            f'   타이밍: 최초 {first_sec if first_sec is not None else "-"}s/{first_ret:+.2f}% · S2 {s2_sec if s2_sec is not None else "-"}s/{s2_ret:+.2f}% · 늦은추격 {late}',
            f'   재확인: {_v558_label_list(r.get("recheck_reasons") or r.get("s2_recheck_reasons") or r.get("missing_info"), 4)}',
            f'   위험: {_v558_label_list(r.get("execution_risk_tags") or r.get("risk_tags") or r.get("structure_risk_tags"), 4)}',
            '',
        ])
    lines.extend(['[안내]', '- 상세 후보 전체는 /candidate_reason_full에서 확인. 기본판은 worker-rendered cache만 표시합니다.'])
    batch_state = {
        'schema': 'candidate_reason_batch_state_v560',
        'rows': len(rows),
        'stage_counts': dict(counts or {}),
        's1_near_count': s1_near,
        's2_recheck_top': s2_recheck_top,
        'strategy_top': strategy_top,
        'risk_top': risk_top,
        'updated_ts': nowv,
        'updated_text': now_text(nowv),
    }
    return {'schema': 'candidate_reason_summary_text_v560', 'summary_text': '\n'.join(lines), 'batch_state': batch_state}


# =============================================================================
# strategy_worker v0.124 / v563: S2 -> S1 promotion lifecycle trace
# - 조건/S1·S2·S3/청산 수치 변경 없음.
# - S2 후보가 왜 S1으로 못 올라갔는지 canonical row/cache에 봉인한다.
# =============================================================================
S2_PROMOTION_TRACE = BASE_DIR / "clean_s2_promotion_lifecycle_trace.json"

def _v563_has_text(row: Dict[str, Any], needles: Tuple[str, ...]) -> bool:
    vals: List[str] = []
    for k in ("recheck_reasons", "s2_recheck_reasons", "missing_info", "block_reasons", "risk_tags", "execution_risk_tags", "structure_risk_tags", "s1_missing_names", "s_stage_reasons", "reasons"):
        v = row.get(k)
        if isinstance(v, list):
            vals.extend(str(x or "") for x in v)
        elif v not in (None, "", [], {}):
            vals.append(str(v))
    hay = " ".join(vals)
    return any(n in hay for n in needles)

def _v563_bool_ok(row: Dict[str, Any], metric: float, bad_words: Tuple[str, ...], min_value: Optional[float] = None, max_value: Optional[float] = None) -> bool:
    if _v563_has_text(row, bad_words):
        return False
    if min_value is not None and metric < min_value:
        return False
    if max_value is not None and metric > max_value:
        return False
    return True

def _v563_s2_promotion_record(row: Dict[str, Any], nowv: float) -> Dict[str, Any]:
    st = _v510_stage(row)
    levels = row.get("structure_levels") if isinstance(row.get("structure_levels"), dict) else {}
    timing = row.get("entry_timing_spine") if isinstance(row.get("entry_timing_spine"), dict) else {}
    plan = row.get("entry_plan") if isinstance(row.get("entry_plan"), dict) else {}
    t = ticker_norm(row.get("ticker") or row.get("symbol") or row.get("market"))
    price = _v510_num(row.get("current_price"), row.get("entry_price"), row.get("price"), default=0.0)
    trigger = _v510_num(levels.get("trigger_price"), plan.get("trigger_price"), default=0.0)
    trigger_gap = round(_v554_pct_between(trigger, price), 3) if price and trigger else None
    trigger_reached = bool(st == "S1" or (price and trigger and price >= trigger * 0.999) or str(levels.get("status") or "") == "triggered")
    react = _v510_num(row.get("price_reaction_pct"), default=0.0)
    buy = _v510_num(row.get("buy_ratio"), default=0.0)
    sustain = _v510_num(row.get("buy_sustain_1m"), row.get("buy_ratio"), default=0.0)
    spread = _v510_num(row.get("spread_pct"), default=0.0)
    slip = _v510_num(row.get("slippage_pct"), row.get("expected_slippage_pct"), row.get("spread_pct"), default=0.0)
    freshness_age = _v510_num(row.get("micro_age_sec"), row.get("orderflow_age_sec"), row.get("price_reaction_age_sec"), row.get("cache_age_sec"), default=0.0)
    freshness_ok = not _v563_has_text(row, ("신선도", "정보부족", "정보 부족", "갱신 대기", "stale"))
    price_reaction_ok = _v563_bool_ok(row, react, ("가격반응", "반응 약함"), min_value=0.35)
    buy_persist_ok = _v563_bool_ok(row, sustain, ("1분", "지속 부족"), min_value=0.60)
    buy_ratio_ok = _v563_bool_ok(row, buy, ("매수체결", "체결약함"), min_value=0.60)
    spread_ok = _v563_bool_ok(row, spread, ("스프레드",), max_value=0.50)
    slippage_ok = _v563_bool_ok(row, slip, ("미끄러짐", "슬리피지"), max_value=0.50)
    failed: List[str] = []
    if not trigger_reached:
        failed.append("방아쇠 미도달")
    if not freshness_ok:
        failed.append("정보/신선도 지연")
    if not price_reaction_ok:
        failed.append("가격반응 부족")
    if not buy_persist_ok:
        failed.append("1분 매수지속 부족")
    if not buy_ratio_ok:
        failed.append("매수체결 부족")
    if not spread_ok:
        failed.append("스프레드 회복 대기")
    if not slippage_ok:
        failed.append("미끄러짐 회복 대기")
    if row.get("late_chase_flag"):
        failed.append("늦은추격 위험")
    if st == "S1":
        promote_state = "promoted_s1"
    elif not trigger_reached:
        promote_state = "waiting_trigger"
    elif not freshness_ok:
        promote_state = "blocked_by_freshness_delay"
    elif not spread_ok or not slippage_ok:
        promote_state = "blocked_by_execution_risk"
    elif failed:
        promote_state = "blocked_by_confirm_signal"
    else:
        promote_state = "near_s1_needs_final_gate"
    would = []
    if not trigger_reached: would.append("방아쇠 가격 도달")
    if not freshness_ok: would.append("신선정보 갱신")
    if not price_reaction_ok: would.append("가격반응 회복")
    if not buy_persist_ok: would.append("1분 매수지속 회복")
    if not buy_ratio_ok: would.append("매수체결 회복")
    if not spread_ok: would.append("스프레드 회복")
    if not slippage_ok: would.append("미끄러짐 회복")
    rec = {
        "schema": "s2_promotion_lifecycle_row_v563",
        "ticker": t,
        "strategy": row.get("strategy_label") or row.get("strategy") or row.get("strategy_key"),
        "strategy_key": row.get("strategy_key") or row.get("paper_strategy_key"),
        "stage": st,
        "s2_seen_ts": timing.get("s2_seen_ts"),
        "s2_age_sec": timing.get("s2_to_now_delay_sec", timing.get("s2_to_current_delay_sec")),
        "first_seen_ts": timing.get("first_seen_ts"),
        "first_age_sec": timing.get("first_to_now_delay_sec", timing.get("first_to_current_delay_sec")),
        "current_price": price,
        "trigger_price": trigger,
        "trigger_reached": trigger_reached,
        "trigger_gap_pct": trigger_gap,
        "freshness_ok": freshness_ok,
        "freshness_age_sec": freshness_age,
        "spread_ok": spread_ok,
        "spread_pct": spread,
        "slippage_ok": slippage_ok,
        "slippage_pct": slip,
        "price_reaction_ok": price_reaction_ok,
        "price_reaction_pct": react,
        "buy_persist_ok": buy_persist_ok,
        "buy_sustain_1m": sustain,
        "buy_ratio_ok": buy_ratio_ok,
        "buy_ratio": buy,
        "promote_state": promote_state,
        "promote_block_reason": failed[:8],
        "failed_confirm": failed[:8],
        "would_be_s1_if": would[:8],
        "updated_ts": nowv,
        "updated_text": now_text(nowv),
    }
    return rec

def _v563_attach_s2_promotion_lifecycle(rows: List[Dict[str, Any]], nowv: float) -> Tuple[List[Dict[str, Any]], Dict[str, Any]]:
    out: List[Dict[str, Any]] = []
    records: List[Dict[str, Any]] = []
    state_counter: Counter = Counter()
    block_counter: Counter = Counter()
    for r in rows:
        rr = dict(r)
        st = _v510_stage(rr)
        rec = _v563_s2_promotion_record(rr, nowv)
        if st in ("S1", "S2"):
            records.append(rec)
            state_counter[rec.get("promote_state") or "-"] += 1
            for x in rec.get("promote_block_reason") or []:
                block_counter[str(x)] += 1
        rr["s2_promotion_lifecycle"] = rec
        rr["promotion_trace"] = rec
        rr["trigger_reached"] = rec.get("trigger_reached")
        rr["trigger_gap_pct"] = rec.get("trigger_gap_pct")
        rr["promote_state"] = rec.get("promote_state")
        rr["promote_block_reason"] = rec.get("promote_block_reason")
        rr["would_be_s1_if"] = rec.get("would_be_s1_if")
        ctx = rr.get("entry_context") if isinstance(rr.get("entry_context"), dict) else {}
        ctx = dict(ctx)
        ctx["s2_promotion_lifecycle"] = rec
        rr["entry_context"] = ctx
        out.append(rr)
    trace = {
        "schema": "s2_promotion_lifecycle_trace_v563",
        "version": VERSION,
        "updated_ts": nowv,
        "updated_text": now_text(nowv),
        "candidate_count": len(records),
        "state_counts": dict(state_counter),
        "block_top": [{"reason": k, "count": v} for k, v in block_counter.most_common(8)],
        "rows": records[:160],
        "policy": "조건/S등급/청산 변경 없이 S2->S1 승격 실패 원인만 기록",
    }
    save_json(S2_PROMOTION_TRACE, trace)
    return out, trace

def _v563_counter_text(counter_rows: List[Dict[str, Any]], key: str, limit: int = 5) -> str:
    c: Counter = Counter()
    for r in counter_rows:
        v = r.get(key)
        if isinstance(v, list):
            for x in v:
                if x: c[str(x)] += 1
        elif v:
            c[str(v)] += 1
    return " / ".join(f"{k} {v}" for k, v in c.most_common(limit)) if c else "-"

def _v563_build_candidate_reason_summary(display_rows: List[Dict[str, Any]], counts: Dict[str, int], reason_top: Any, nowv: float) -> Dict[str, Any]:
    rows = [r for r in display_rows if isinstance(r, dict)]
    s2_rows = [r for r in rows if _v510_stage(r) == 'S2']
    s1_near = sum(1 for r in rows if bool(r.get('s1_near_miss')) or str(r.get('s1_distance_label') or '').startswith('S1'))
    strategy_top = _v559_counter_top(rows, ('matched_strategy_labels','strategy_tags','structure_tags','strategy','strategy_key'), 5)
    risk_top = _v559_counter_top(rows, ('risk_tags','execution_risk_tags','structure_risk_tags'), 5)
    promo_state_top = _v563_counter_text([r.get('s2_promotion_lifecycle') or {} for r in rows], 'promote_state', 5)
    promo_block_top = _v559_counter_top(s2_rows, ('promote_block_reason','would_be_s1_if'), 5)
    top = rows[:2]
    lines = [
        '🧭 후보판정 이유 /candidate_reason · v563 S2 승격 생애주기',
        '- 기준: strategy_worker가 미리 만든 summary_text만 읽습니다. 후보 재계산 없음.',
        f'- rows {len(rows)} / updated {now_text(nowv)} / fresh',
        f'- 현재 단계: S1 {counts.get("S1",0)} / S2 {counts.get("S2",0)} / S3 {counts.get("S3",0)} / 제외 {counts.get("제외", counts.get("X",0))}',
        f'- S1 근접후보: {s1_near} / 승격상태 TOP: {promo_state_top}',
        f'- S2 막힘 TOP: {promo_block_top}',
        f'- 전략/발견 TOP: {strategy_top}',
        f'- 위험 TOP: {risk_top}',
        '',
        '[상위 후보 2개 · 구조선/계획/승격추적]',
    ]
    if not top:
        lines.append('- 표시 후보 없음')
    for idx, r in enumerate(top, 1):
        t = ticker_norm(r.get('ticker') or r.get('symbol') or r.get('market')) or '-'
        st = _v510_stage(r)
        strat = str(r.get('strategy_label') or r.get('strategy') or r.get('strategy_key') or '-')
        price = _v510_num(r.get('current_price'), r.get('entry_price'), r.get('price'), default=0.0)
        react = _v558_metric(r, 'price_reaction_pct')
        buy = _v558_metric(r, 'buy_ratio')
        sustain = _v558_metric(r, 'buy_sustain_1m')
        spread = _v558_metric(r, 'spread_pct')
        levels = r.get('structure_levels') if isinstance(r.get('structure_levels'), dict) else {}
        promo = r.get('s2_promotion_lifecycle') if isinstance(r.get('s2_promotion_lifecycle'), dict) else {}
        lines.extend([
            f'{idx}) {t} · {st} · {strat}',
            f'   수치: 반응 {react:+.2f}% / 매수 {buy:.2f} / 1분 {sustain:.2f} / 스프 {spread:.2f}% / 가격 {_v558_price(price)}',
            f'   구조선: 방아쇠 {_v558_price(levels.get("trigger_price"))} / 무효 {_v558_price(levels.get("invalid_price"))} / 목표 {_v558_price(levels.get("target1_price"))}',
            f'   승격추적: {promo.get("promote_state") or "-"} / 방아쇠 {"도달" if promo.get("trigger_reached") else "미도달"} / gap {promo.get("trigger_gap_pct") if promo.get("trigger_gap_pct") is not None else "-"}%',
            f'   막힘: {_v558_label_list(promo.get("promote_block_reason") or r.get("promote_block_reason"), 5)}',
            f'   S1조건화: {_v558_label_list(promo.get("would_be_s1_if") or r.get("would_be_s1_if"), 5)}',
            f'   위험: {_v558_label_list(r.get("execution_risk_tags") or r.get("risk_tags") or r.get("structure_risk_tags"), 4)}',
            '',
        ])
    lines.extend(['[안내]', '- 조건/S등급/청산은 변경하지 않고, S2가 왜 S1이 못 됐는지만 기록합니다.'])
    batch_state = {
        'schema': 'candidate_reason_batch_state_v563_s2_promotion',
        'rows': len(rows),
        'stage_counts': dict(counts or {}),
        's1_near_count': s1_near,
        'promotion_state_top': promo_state_top,
        'promotion_block_top': promo_block_top,
        'strategy_top': strategy_top,
        'risk_top': risk_top,
        'updated_ts': nowv,
        'updated_text': now_text(nowv),
    }
    return {'schema': 'candidate_reason_summary_text_v563_s2_promotion', 'summary_text': '\n'.join(lines), 'batch_state': batch_state}

# v563 최종 summary producer: v560 compact 경량화를 유지하면서 승격 생애주기를 표시한다.
_v557_build_candidate_reason_summary = _v563_build_candidate_reason_summary



# =============================================================================
# strategy_worker v0.125 / v573: freshness numeric proof + refined late-chase gate
# - 위치 원칙: S1/S2 승격 판단은 strategy_worker가 주인이다.
# - 조건 수치/청산/자동매수/BUY_READY 변경 없음.
# - 신선도 문구만 있고 숫자 근거가 없는 후보는 S1 직행 금지 -> S2 재확인.
# - 늦은추격 라벨은 좋은 후보까지 죽이지 않도록 hard/broad로 분리한다.
# =============================================================================
_V573_AGE_KEYS = (
    "micro_age_sec", "orderflow_age_sec", "trade_age_sec", "quote_age_sec", "ws_age_sec",
    "price_reaction_age_sec", "feature_age_sec", "hot_signal_age_sec", "scanner_hot_age_sec", "cache_age_sec",
)

def _v573_text_blob(row: Dict[str, Any]) -> str:
    vals: List[str] = []
    for k in ("stale_reasons", "freshness_flags", "recheck_reasons", "s2_recheck_reasons", "missing_info", "block_reasons", "risk_tags", "execution_risk_tags", "s1_missing_conditions"):
        v = row.get(k)
        if isinstance(v, list):
            vals.extend(str(x or "") for x in v)
        elif v not in (None, "", [], {}):
            vals.append(str(v))
    dec = row.get("canonical_entry_decision") if isinstance(row.get("canonical_entry_decision"), dict) else {}
    for k in ("stale_reasons", "display_reasons", "s1_recheck_reasons", "s2_recheck_reasons", "missing_conditions"):
        v = dec.get(k)
        if isinstance(v, list):
            vals.extend(str(x or "") for x in v)
    return " ".join(vals)

def _v573_age_value(row: Dict[str, Any], key: str) -> Optional[float]:
    v = row.get(key)
    if v is None and isinstance(row.get("entry_context"), dict):
        v = row.get("entry_context", {}).get(key)
    try:
        if v in (None, "", [], {}):
            return None
        f = float(str(v).replace(",", "").replace("%", ""))
        if f < 0:
            return None
        return f
    except Exception:
        return None

def _v573_freshness_numeric_profile(row: Dict[str, Any]) -> Dict[str, Any]:
    blob = _v573_text_blob(row)
    has_fresh_text = any(w in blob for w in ("신선", "정보", "fresh", "stale", "갱신 대기", "오래됨"))
    ages: Dict[str, float] = {}
    for k in _V573_AGE_KEYS:
        v = _v573_age_value(row, k)
        if v is not None:
            ages[k] = round(v, 3)
    # 핵심값 기준. 없는 값은 통과가 아니라 숫자근거 부족으로 둔다.
    core_keys = ("micro_age_sec", "orderflow_age_sec", "trade_age_sec", "quote_age_sec", "ws_age_sec", "price_reaction_age_sec", "feature_age_sec")
    core_ages = {k: ages[k] for k in core_keys if k in ages}
    numeric_present = bool(core_ages)
    worst_core_age = max(core_ages.values()) if core_ages else None
    numeric_stale = bool(worst_core_age is not None and worst_core_age > 25.0)
    text_without_numeric = bool(has_fresh_text and not numeric_present)
    numeric_ok = bool(numeric_present and not numeric_stale and not text_without_numeric)
    if text_without_numeric:
        state = "text_only_no_numeric"
    elif numeric_stale:
        state = "numeric_age_stale"
    elif numeric_ok:
        state = "numeric_fresh"
    elif has_fresh_text:
        state = "freshness_text_unclear"
    else:
        state = "no_freshness_warning"
    return {
        "schema": "freshness_numeric_profile_v573",
        "state": state,
        "has_freshness_text": has_fresh_text,
        "numeric_present": numeric_present,
        "text_without_numeric": text_without_numeric,
        "numeric_stale": numeric_stale,
        "numeric_ok": numeric_ok,
        "worst_core_age_sec": worst_core_age,
        "ages": ages,
        "policy": "신선도 문구만 있고 숫자근거 없으면 S1 직행 금지/S2 재확인",
    }

def _v573_refined_late_chase_profile(row: Dict[str, Any]) -> Dict[str, Any]:
    levels = row.get("structure_levels") if isinstance(row.get("structure_levels"), dict) else {}
    timing = row.get("entry_timing_spine") if isinstance(row.get("entry_timing_spine"), dict) else {}
    react = _v510_num(row.get("price_reaction_pct"), default=0.0)
    spread = _v510_num(row.get("spread_pct"), default=0.0)
    slip = _v510_num(row.get("slippage_pct"), row.get("expected_slippage_pct"), default=spread)
    buy = _v510_num(row.get("buy_ratio"), default=0.0)
    sustain = _v510_num(row.get("buy_sustain_1m"), row.get("buy_ratio"), default=0.0)
    ch1 = _v510_num(row.get("change_1m_pct"), row.get("change_1m"), default=0.0)
    ch3 = _v510_num(row.get("change_3m_pct"), row.get("change_3m"), default=0.0)
    first_ret = _v510_num(timing.get("first_to_now_return_pct"), timing.get("first_to_current_return_pct"), default=0.0)
    s2_ret = _v510_num(timing.get("s2_to_now_return_pct"), timing.get("s2_to_current_return_pct"), default=0.0)
    base_late = bool(row.get("late_chase_flag") or levels.get("late_chase_flag") or timing.get("late_chase_flag"))
    fast_move = bool(first_ret >= 1.20 or s2_ret >= 0.80 or ch1 >= 1.80 or ch3 >= 3.20 or react >= 1.80)
    weak_confirm = bool(buy < 0.70 or sustain < 0.70)
    exec_risk = bool(spread > 0.35 or slip > 0.35)
    wick_or_sell = _v563_has_text(row, ("윗꼬리", "매도압력", "되돌림위험", "고점권"))
    freshness = _v573_freshness_numeric_profile(row)
    freshness_risk = bool(freshness.get("text_without_numeric") or freshness.get("numeric_stale"))
    hard_late = bool(base_late and fast_move and (weak_confirm or exec_risk or wick_or_sell or freshness_risk))
    broad_only = bool(base_late and not hard_late)
    if hard_late:
        state = "hard_late_chase"
    elif broad_only:
        state = "broad_late_label_only"
    else:
        state = "not_late_chase"
    reasons: List[str] = []
    if fast_move: reasons.append("가격이 이미 많이 움직임")
    if freshness_risk: reasons.append("신선도 숫자근거 부족/지연")
    if weak_confirm: reasons.append("확인신호 약함")
    if exec_risk: reasons.append("스프레드/미끄러짐 부담")
    if wick_or_sell: reasons.append("되돌림/매도압력 위험")
    return {
        "schema": "refined_late_chase_profile_v573",
        "state": state,
        "base_late_chase_flag": base_late,
        "hard_late_chase": hard_late,
        "broad_late_label_only": broad_only,
        "fast_move": fast_move,
        "weak_confirm": weak_confirm,
        "execution_risk": exec_risk,
        "freshness_risk": freshness_risk,
        "basis": {"first_ret": round(first_ret,3), "s2_ret": round(s2_ret,3), "chg1": round(ch1,3), "chg3": round(ch3,3), "reaction": round(react,3), "spread": round(spread,3), "slippage": round(slip,3), "buy": round(buy,3), "sustain": round(sustain,3)},
        "reasons": reasons[:6],
    }

_v573_base_build_structure_levels = _v554_build_structure_levels

def _v554_build_structure_levels(row: Dict[str, Any]) -> Dict[str, Any]:  # type: ignore[override]
    levels = _v573_base_build_structure_levels(row)
    if not isinstance(levels, dict):
        return levels
    # base late flag는 남기되, S1 판단용 late flag는 refined hard late만 사용한다.
    temp = dict(row)
    temp["structure_levels"] = levels
    refined = _v573_refined_late_chase_profile(temp)
    base_flag = bool(levels.get("late_chase_flag"))
    levels["base_late_chase_flag"] = base_flag
    levels["late_chase_flag"] = bool(refined.get("hard_late_chase"))
    levels["refined_late_chase_profile"] = refined
    levels["late_chase_reason"] = " / ".join(refined.get("reasons") or []) if refined.get("hard_late_chase") else ("넓은 늦은추격 라벨만 있음" if refined.get("broad_late_label_only") else "")
    levels["schema"] = "structure_levels_v573_refined_late_chase"
    return levels

_v573_base_build_entry_decision = _v532_build_canonical_entry_decision

def _v532_build_canonical_entry_decision(row: Dict[str, Any]) -> Dict[str, Any]:  # type: ignore[override]
    dec = _v573_base_build_entry_decision(row)
    if not isinstance(dec, dict):
        return dec
    fresh = _v573_freshness_numeric_profile(row)
    late = _v573_refined_late_chase_profile(row)
    guard: List[str] = []
    if fresh.get("text_without_numeric"):
        guard.append("재확인: 신선도 숫자근거 확인 대기")
    # 숫자로도 오래된 신선도 + 진짜 늦은추격 조합은 S1 직행 금지. 단순 늦은추격 라벨만으로는 막지 않는다.
    if fresh.get("numeric_stale") and late.get("hard_late_chase"):
        guard.append("재확인: 신선도지연+진짜늦은추격")
    if guard:
        prev_guard = list(dec.get("s1_recheck_guard_reasons") or [])
        prev_recheck = list(dec.get("s1_recheck_reasons") or dec.get("s2_recheck_reasons") or [])
        merged = _v510_uniq(prev_guard + guard, 8)
        rechecks = _v510_uniq(prev_recheck + guard, 8)
        missing = list(dec.get("missing_conditions") or []) + guard
        checks = list(dec.get("checks") or [])
        for g in guard:
            checks.append({"name": "신선도근거" if "신선도" in g else "늦은추격정교화", "ok": False, "value": fresh.get("state"), "need": "numeric proof before S1", "reason": g, "weight": 2})
        dec.update({
            "schema": "canonical_entry_decision_v573_fresh_late_refined",
            "gate_pass": False,
            "s1_allowed": False,
            "s1_recheck_guard": True,
            "s1_recheck_guard_reasons": merged,
            "s1_recheck_reasons": rechecks,
            "s2_recheck_reasons": rechecks,
            "s2_recheck": True,
            "action": "recheck",
            "entry_profile": "watch",
            "exit_profile": "watch_exit",
            "profile_family": "watch",
            "missing_conditions": missing,
            "display_reasons": list(dec.get("display_reasons") or []) + guard,
            "checks": checks,
            "block_count": int(dec.get("block_count") or 0) + len(guard),
            "block_score": int(dec.get("block_score") or 0) + 2 * len(guard),
            "s1_distance": int(dec.get("s1_distance") or 0) + 2 * len(guard),
            "s1_near_miss": True,
            "s1_near_miss_level": "near",
        })
    dec["freshness_numeric_profile"] = fresh
    dec["refined_late_chase_profile"] = late
    dec["v573_policy"] = "신선도 숫자근거 없음은 S1 직행 금지, 늦은추격은 hard/broad로 분리"
    return dec

_v573_base_apply_entry_decision = _v532_apply_canonical_entry_decision

def _v532_apply_canonical_entry_decision(row: Dict[str, Any]) -> Dict[str, Any]:  # type: ignore[override]
    out = _v573_base_apply_entry_decision(row)
    if not isinstance(out, dict):
        return out
    dec = out.get("canonical_entry_decision") if isinstance(out.get("canonical_entry_decision"), dict) else {}
    fresh = dec.get("freshness_numeric_profile") if isinstance(dec.get("freshness_numeric_profile"), dict) else _v573_freshness_numeric_profile(out)
    late = dec.get("refined_late_chase_profile") if isinstance(dec.get("refined_late_chase_profile"), dict) else _v573_refined_late_chase_profile(out)
    out["freshness_numeric_profile"] = fresh
    out["freshness_numeric_state"] = fresh.get("state")
    out["freshness_text_without_numeric"] = bool(fresh.get("text_without_numeric"))
    out["freshness_numeric_stale"] = bool(fresh.get("numeric_stale"))
    out["refined_late_chase_profile"] = late
    out["late_chase_refined_state"] = late.get("state")
    out["hard_late_chase_flag"] = bool(late.get("hard_late_chase"))
    out["broad_late_label_only"] = bool(late.get("broad_late_label_only"))
    ctx = out.get("entry_context") if isinstance(out.get("entry_context"), dict) else {}
    ctx = dict(ctx)
    ctx["freshness_numeric_profile"] = fresh
    ctx["refined_late_chase_profile"] = late
    out["entry_context"] = ctx
    return out

_v573_base_s2_promotion_record = _v563_s2_promotion_record

def _v563_s2_promotion_record(row: Dict[str, Any], nowv: float) -> Dict[str, Any]:  # type: ignore[override]
    rec = _v573_base_s2_promotion_record(row, nowv)
    fresh = row.get("freshness_numeric_profile") if isinstance(row.get("freshness_numeric_profile"), dict) else _v573_freshness_numeric_profile(row)
    late = row.get("refined_late_chase_profile") if isinstance(row.get("refined_late_chase_profile"), dict) else _v573_refined_late_chase_profile(row)
    failed = list(rec.get("promote_block_reason") or [])
    would = list(rec.get("would_be_s1_if") or [])
    if fresh.get("text_without_numeric"):
        failed.append("신선도 숫자근거 없음")
        would.append("신선도 숫자근거 확보")
    if fresh.get("numeric_stale") and late.get("hard_late_chase"):
        failed.append("신선도지연+진짜늦은추격")
        would.append("긴급 신선정보 갱신 후 재판정")
    failed = _v510_uniq(failed, 10)
    would = _v510_uniq(would, 10)
    rec.update({
        "schema": "s2_promotion_lifecycle_row_v573_fresh_late_refined",
        "freshness_numeric_profile": fresh,
        "refined_late_chase_profile": late,
        "freshness_numeric_state": fresh.get("state"),
        "late_chase_refined_state": late.get("state"),
        "promote_block_reason": failed,
        "failed_confirm": failed,
        "would_be_s1_if": would,
    })
    if fresh.get("text_without_numeric"):
        rec["promote_state"] = "blocked_by_freshness_numeric_missing"
    elif fresh.get("numeric_stale") and late.get("hard_late_chase"):
        rec["promote_state"] = "blocked_by_freshness_late_chase"
    return rec

_v573_base_build_candidate_reason_summary = _v563_build_candidate_reason_summary

def _v573_counter_rows(rows: List[Dict[str, Any]], getter, limit: int = 5) -> str:
    c: Counter = Counter()
    for r in rows:
        try:
            v = getter(r)
        except Exception:
            v = None
        if isinstance(v, list):
            for x in v:
                if x: c[str(x)] += 1
        elif v not in (None, "", [], {}):
            c[str(v)] += 1
    return " / ".join(f"{k} {v}" for k, v in c.most_common(limit)) if c else "-"

def _v573_build_candidate_reason_summary(display_rows: List[Dict[str, Any]], counts: Dict[str, int], reason_top: Any, nowv: float) -> Dict[str, Any]:
    base = _v573_base_build_candidate_reason_summary(display_rows, counts, reason_top, nowv)
    rows = [r for r in display_rows if isinstance(r, dict)]
    fresh_top = _v573_counter_rows(rows, lambda r: (r.get("freshness_numeric_profile") or {}).get("state"), 4)
    late_top = _v573_counter_rows(rows, lambda r: (r.get("refined_late_chase_profile") or {}).get("state"), 4)
    text_missing = sum(1 for r in rows if bool(r.get("freshness_text_without_numeric")))
    hard_late = sum(1 for r in rows if bool(r.get("hard_late_chase_flag")))
    summary = str(base.get("summary_text") or "")
    head = [
        "🧭 후보판정 이유 /candidate_reason · v573 신선도근거+늦은추격 정교화",
        "- 기준: strategy_worker가 미리 만든 summary_text만 읽습니다. 후보 재계산 없음.",
        f"- 신선도근거 TOP: {fresh_top} / 숫자근거없음 {text_missing}",
        f"- 늦은추격 정교화 TOP: {late_top} / 진짜늦은추격 {hard_late}",
    ]
    # 기존 제목/기준 2줄은 v563 문구라서 핵심만 교체하고 나머지는 유지한다.
    parts = summary.split("\n")
    if parts and parts[0].startswith("🧭 후보판정 이유"):
        parts = parts[2:] if len(parts) > 2 else []
    base["summary_text"] = "\n".join(head + parts)
    base["schema"] = "candidate_reason_summary_text_v573_fresh_late_refined"
    bs = base.get("batch_state") if isinstance(base.get("batch_state"), dict) else {}
    bs.update({"schema": "candidate_reason_batch_state_v573", "freshness_numeric_top": fresh_top, "late_chase_refined_top": late_top, "freshness_text_without_numeric_count": text_missing, "hard_late_chase_count": hard_late})
    base["batch_state"] = bs
    return base


# =============================================================================
# strategy_worker v0.126 / v574: S2->S1 fresh urgent loop
# - S2가 방아쇠 근처인데 신선정보가 오래된 경우, 최종 막힘 사유로 묵히지 않고
#   target_router/micro/orderflow urgent 보강 요청을 만든다.
# - 조건 수치/S1/S2/S3 기준/청산/BUY_READY는 바꾸지 않는다.
# - 정보 생산은 target_router+micro/orderflow 공장, 전략 판단은 strategy_worker가 담당한다.
# =============================================================================
def _v574_is_s2_fresh_urgent_candidate(row: Dict[str, Any]) -> Tuple[bool, List[str], float]:
    if _v510_stage(row) != "S2":
        return False, [], 999.0
    promo = row.get("s2_promotion_lifecycle") if isinstance(row.get("s2_promotion_lifecycle"), dict) else {}
    fresh = row.get("freshness_numeric_profile") if isinstance(row.get("freshness_numeric_profile"), dict) else _v573_freshness_numeric_profile(row)
    dec = row.get("canonical_entry_decision") if isinstance(row.get("canonical_entry_decision"), dict) else {}
    reasons = []
    gap = _v510_num(promo.get("trigger_gap_pct"), default=999.0)
    trigger_near = bool((gap <= 0.65) or bool(row.get("s1_near_miss")) or "방아쇠" in " ".join(str(x) for x in (promo.get("would_be_s1_if") or [])))
    stale_numeric = bool(fresh.get("numeric_stale") or fresh.get("text_without_numeric"))
    stale_text = bool(_v563_has_text(row, ("신선정보 갱신", "신선도", "정보/신선도 지연", "fresh")))
    if trigger_near:
        reasons.append("S2 방아쇠 근접")
    if stale_numeric:
        reasons.append("신선정보 숫자 오래됨/부족")
    elif stale_text:
        reasons.append("신선정보 갱신 필요")
    if bool(dec.get("s1_near_miss")):
        reasons.append("S1 근접")
    ok = bool(trigger_near and (stale_numeric or stale_text or bool(dec.get("s1_near_miss"))))
    return ok, _v510_uniq(reasons, 6), gap


def _v574_attach_s2_fresh_urgent_requests(rows: List[Dict[str, Any]], priority_requests: List[Dict[str, Any]], nowv: float) -> Tuple[List[Dict[str, Any]], Dict[str, Any]]:
    out_reqs = list(priority_requests or [])
    urgent_rows: List[Dict[str, Any]] = []
    seen = set()
    for row in rows:
        ok, reasons, gap = _v574_is_s2_fresh_urgent_candidate(row)
        if not ok:
            row["v574_fresh_urgent_request"] = False
            continue
        t = ticker_norm(row.get("ticker") or row.get("market") or row.get("symbol"))
        if not t:
            continue
        fresh = row.get("freshness_numeric_profile") if isinstance(row.get("freshness_numeric_profile"), dict) else _v573_freshness_numeric_profile(row)
        promo = row.get("s2_promotion_lifecycle") if isinstance(row.get("s2_promotion_lifecycle"), dict) else {}
        pri = 760.0
        if gap <= 0.35:
            pri += 60.0
        elif gap <= 0.65:
            pri += 35.0
        if str(fresh.get("state")) == "numeric_age_stale":
            pri += 25.0
        if bool(row.get("s1_near_miss")):
            pri += 20.0
        req = {
            "ticker": t,
            "bucket": "near_s_info_wait",
            "priority": round(pri + min(40.0, _v510_num(row.get("score"), default=0.0)), 3),
            "need": ["quote", "ws", "micro"],
            "source": "strategy_worker_v574_s2_fresh_urgent",
            "stage": "S2",
            "strategy_key": row.get("strategy_key"),
            "trigger_gap_pct": gap if gap < 900 else None,
            "freshness_numeric_state": fresh.get("state"),
            "freshness_worst_age_sec": fresh.get("worst_core_age_sec"),
            "promote_state": promo.get("promote_state"),
            "reasons": reasons,
            "micro_urgent": True,
            "updated_ts": nowv,
            "policy": "S2 근접+fresh 부족은 S1 직행이 아니라 urgent refresh 후 재판정",
        }
        row["v574_fresh_urgent_request"] = True
        row["v574_fresh_urgent_reason"] = reasons
        row["v574_fresh_urgent_priority"] = req["priority"]
        row["v574_fresh_urgent_bucket"] = "near_s_info_wait"
        row["v574_fresh_urgent_requested_ts"] = nowv
        if t not in seen:
            out_reqs.append(req)
            urgent_rows.append(req)
            seen.add(t)
    return out_reqs, {
        "schema": "strategy_s2_fresh_urgent_summary_v574",
        "version": VERSION,
        "updated_ts": nowv,
        "request_count": len(urgent_rows),
        "targets": [r.get("ticker") for r in urgent_rows],
        "rows": urgent_rows[:60],
        "policy": "S2 근접 후보의 신선정보 갱신 필요를 최종 막힘으로 남기지 않고 target_router urgent refresh로 보낸다.",
    }

_v574_base_candidate_reason_summary = _v573_build_candidate_reason_summary

def _v574_build_candidate_reason_summary(display_rows: List[Dict[str, Any]], counts: Dict[str, int], reason_top: Any, nowv: float) -> Dict[str, Any]:
    base = _v574_base_candidate_reason_summary(display_rows, counts, reason_top, nowv)
    rows = [r for r in display_rows if isinstance(r, dict)]
    req_cnt = sum(1 for r in rows if bool(r.get("v574_fresh_urgent_request")))
    targets = [ticker_norm(r.get("ticker")) for r in rows if bool(r.get("v574_fresh_urgent_request")) and ticker_norm(r.get("ticker"))]
    summary = str(base.get("summary_text") or "")
    line = f"- 신선정보 긴급요청: {req_cnt}개" + (f" / {', '.join(targets[:5])}" if targets else "")
    parts = summary.split("\n")
    insert_at = 2 if len(parts) >= 2 else len(parts)
    parts.insert(insert_at, line)
    base["summary_text"] = "\n".join(parts)
    base["schema"] = "candidate_reason_summary_text_v574_s2_fresh_urgent"
    bs = base.get("batch_state") if isinstance(base.get("batch_state"), dict) else {}
    bs.update({"schema": "candidate_reason_batch_state_v574", "fresh_urgent_request_count": req_cnt, "fresh_urgent_targets": targets[:20]})
    base["batch_state"] = bs
    return base

_v557_build_candidate_reason_summary = _v574_build_candidate_reason_summary


# =============================================================================
# strategy_worker v0.127 / v575: S2 urgent fresh loop action result
# - 새 조건을 추가하지 않는다.
# - v574가 보낸 urgent fresh 요청이 현재 row에서 어떤 결과로 돌아왔는지 같은 canonical row에 봉인한다.
# - 목표는 "요청만 보냄"이 아니라, 회복/미회복/S2유지 사유/S1승격 가능성을 바로 보이게 하는 것이다.
# =============================================================================
def _v575_text_has_any(vals: Any, words: Tuple[str, ...]) -> bool:
    try:
        if isinstance(vals, dict):
            vals = list(vals.values())
        if not isinstance(vals, list):
            vals = [vals]
        blob = " / ".join(str(x) for x in vals if x is not None)
    except Exception:
        blob = str(vals or "")
    return any(w in blob for w in words)


def _v575_fresh_ok(row: Dict[str, Any]) -> bool:
    fresh = row.get("freshness_numeric_profile") if isinstance(row.get("freshness_numeric_profile"), dict) else _v573_freshness_numeric_profile(row)
    st = str(fresh.get("state") or "")
    if bool(fresh.get("text_without_numeric") or fresh.get("numeric_stale")):
        return False
    return st in {"numeric_fresh", "no_freshness_warning"}


def _v575_block_bucket(row: Dict[str, Any]) -> str:
    promo = row.get("s2_promotion_lifecycle") if isinstance(row.get("s2_promotion_lifecycle"), dict) else {}
    failed = list(promo.get("failed_confirm") or promo.get("promote_block_reason") or [])
    would = list(promo.get("would_be_s1_if") or [])
    reasons = list(row.get("s_stage_reasons") or []) + list(row.get("s2_recheck_reasons") or []) + failed + would
    if not _v575_fresh_ok(row):
        return "fresh_wait"
    if _v575_text_has_any(reasons, ("스프레드", "미끄러짐")):
        return "exec_risk_wait"
    if _v575_text_has_any(reasons, ("방아쇠", "trigger")):
        return "trigger_wait"
    if _v575_text_has_any(reasons, ("1분", "매수체결", "체결", "가격반응")):
        return "confirm_wait"
    if _v510_stage(row) == "S1":
        return "promoted_s1"
    return "s2_other_wait"


def _v575_attach_urgent_action_result(rows: List[Dict[str, Any]], summary: Dict[str, Any], nowv: float) -> Dict[str, Any]:
    counts: Counter = Counter()
    samples: List[Dict[str, Any]] = []
    for row in rows:
        requested = bool(row.get("v574_fresh_urgent_request"))
        if not requested:
            row["v575_urgent_action_state"] = "not_requested"
            continue
        bucket = _v575_block_bucket(row)
        fresh_ok = _v575_fresh_ok(row)
        counts[bucket] += 1
        row["v575_urgent_action_state"] = bucket
        row["v575_urgent_fresh_recovered"] = bool(fresh_ok)
        row["v575_urgent_result_policy"] = "urgent 갱신 후 fresh 회복이면 남은 실행/방아쇠/확인 사유로 S1 또는 S2 유지"
        if len(samples) < 12:
            promo = row.get("s2_promotion_lifecycle") if isinstance(row.get("s2_promotion_lifecycle"), dict) else {}
            samples.append({
                "ticker": ticker_norm(row.get("ticker") or row.get("market") or row.get("symbol")),
                "stage": _v510_stage(row),
                "action_state": bucket,
                "fresh_recovered": bool(fresh_ok),
                "trigger_gap_pct": promo.get("trigger_gap_pct"),
                "spread_pct": row.get("spread_pct"),
                "slippage_pct": row.get("slippage_pct"),
                "buy_ratio": row.get("buy_ratio"),
                "buy_sustain_1m": row.get("buy_sustain_1m"),
            })
    total = sum(counts.values())
    recovered = int(counts.get("exec_risk_wait",0)+counts.get("trigger_wait",0)+counts.get("confirm_wait",0)+counts.get("promoted_s1",0)+counts.get("s2_other_wait",0))
    result = {
        "schema": "s2_urgent_fresh_action_result_v575",
        "version": VERSION,
        "updated_ts": nowv,
        "request_count": total,
        "fresh_recovered_count": recovered,
        "s1_promoted_count": int(counts.get("promoted_s1",0)),
        "s2_keep_count": int(total - counts.get("promoted_s1",0)),
        "state_counts": dict(counts),
        "sample": samples,
        "policy": "S2 근접 fresh 부족은 urgent refresh를 태운 뒤 결과에 따라 S1 또는 S2 유지. 조건 수치 변경 없음.",
    }
    return result


_v575_prev_attach_s2_fresh_urgent_requests = _v574_attach_s2_fresh_urgent_requests

def _v575_attach_s2_fresh_urgent_requests(rows: List[Dict[str, Any]], priority_requests: List[Dict[str, Any]], nowv: float) -> Tuple[List[Dict[str, Any]], Dict[str, Any]]:
    out_reqs, base_summary = _v575_prev_attach_s2_fresh_urgent_requests(rows, priority_requests, nowv)
    action = _v575_attach_urgent_action_result(rows, base_summary if isinstance(base_summary, dict) else {}, nowv)
    if isinstance(base_summary, dict):
        base_summary = dict(base_summary)
    else:
        base_summary = {}
    base_summary["v575_action_result"] = action
    base_summary["schema"] = "strategy_s2_fresh_urgent_summary_v575_action"
    base_summary["policy"] = "urgent 요청 생성+현재 cycle 결과 분류를 함께 저장한다. 요청만 세지 않고 S1/S2 결과까지 본다."
    return out_reqs, base_summary

# v510_publish는 런타임 name lookup을 하므로 여기서 단일 본선 함수로 교체한다.
_v574_attach_s2_fresh_urgent_requests = _v575_attach_s2_fresh_urgent_requests


# =============================================================================
# strategy_worker v0.139 / v603: 공식 캔들 fresh 대기 후보를 candle_worker 우선요청으로 보냄
# - 조건 완화가 아니다. final_trade_state가 캔들 오래됨 때문에 S2_RECHECK인 경우
#   paper가 보기 전에 candle_worker가 그 종목을 먼저 갱신하도록 요청만 명확히 남긴다.
# =============================================================================
def _v603_has_candle_wait(row: Dict[str, Any]) -> Tuple[bool, float, List[str]]:
    reasons = _v602_list(row.get('final_trade_reasons'), row.get('s_stage_reasons'), row.get('s2_recheck_reasons'), limit=16)
    blob = ' / '.join(str(x) for x in reasons)
    canon = row.get('canonical_metric_row') if isinstance(row.get('canonical_metric_row'), dict) else {}
    struct = canon.get('structure') if isinstance(canon.get('structure'), dict) else {}
    official = struct.get('official_structure_inputs') if isinstance(struct.get('official_structure_inputs'), dict) else _v596_official_structure_inputs(row)
    age = _v510_num(official.get('official_candle_age'), row.get('official_candle_age'), row.get('candle_age_sec'), default=-1.0) if isinstance(official, dict) else -1.0
    present = _v510_num(official.get('present_count'), default=-1.0) if isinstance(official, dict) else -1.0
    text_wait = any(w in blob for w in ('공식 캔들 오래됨', '공식캔들 stale', '공식 구조재료 부족', '캔들 오래됨'))
    age_wait = bool(age > 45)
    missing_wait = bool(0 <= present < 6)
    return bool(text_wait or age_wait or missing_wait), age, reasons


_v603_prev_attach_s2_fresh_urgent_requests = _v574_attach_s2_fresh_urgent_requests

def _v603_attach_s2_fresh_urgent_requests(rows: List[Dict[str, Any]], priority_requests: List[Dict[str, Any]], nowv: float) -> Tuple[List[Dict[str, Any]], Dict[str, Any]]:
    out_reqs, base_summary = _v603_prev_attach_s2_fresh_urgent_requests(rows, priority_requests, nowv)
    out_reqs = list(out_reqs or [])
    added: List[Dict[str, Any]] = []
    seen = {ticker_norm(r.get('ticker')) for r in out_reqs if isinstance(r, dict) and ticker_norm(r.get('ticker'))}
    for row in rows or []:
        if not isinstance(row, dict):
            continue
        state = str(row.get('final_trade_state') or '')
        stage = _v510_stage(row)
        if state not in {'S2_RECHECK', 'S1_PASS'} and stage not in {'S1', 'S2'}:
            row['v603_candle_fresh_request'] = False
            continue
        need, age, reasons = _v603_has_candle_wait(row)
        if not need:
            row['v603_candle_fresh_request'] = False
            continue
        t = ticker_norm(row.get('ticker') or row.get('market') or row.get('symbol'))
        if not t:
            continue
        pri = 900.0 if stage == 'S1' or state == 'S1_PASS' else 850.0
        if age > 300:
            pri += 70.0
        elif age > 120:
            pri += 40.0
        req = {
            'ticker': t,
            'bucket': 's2_candle_fresh_wait' if stage == 'S2' else 's1_candle_preopen',
            'priority': round(pri + min(40.0, _v510_num(row.get('score'), default=0.0)), 3),
            'need': ['candle'],
            'source': 'strategy_worker_v603_final_trade_state_candle_wait',
            'stage': stage,
            'final_trade_state': state,
            'official_candle_age': age if age >= 0 else None,
            'reasons': reasons[:6] or ['공식 캔들 최신화 필요'],
            'updated_ts': nowv,
            'policy': '캔들이 오래돼 S1_PASS가 막힌 후보는 candle_worker가 먼저 갱신한다. 조건/S등급/청산 변경 없음.',
        }
        row['v603_candle_fresh_request'] = True
        row['v603_candle_fresh_age'] = age if age >= 0 else None
        row['v603_candle_fresh_bucket'] = req['bucket']
        if t not in seen:
            out_reqs.append(req)
            added.append(req)
            seen.add(t)
    if isinstance(base_summary, dict):
        base_summary = dict(base_summary)
    else:
        base_summary = {}
    base_summary['v603_candle_fresh_summary'] = {
        'schema': 'strategy_candle_fresh_priority_summary_v603',
        'version': VERSION,
        'request_count': len(added),
        'targets': [r.get('ticker') for r in added],
        'rows': added[:40],
        'policy': 'final_trade_state에서 공식 캔들 오래됨으로 막힌 S1/S2 후보를 candle_worker 우선순위로 보낸다.',
    }
    return out_reqs, base_summary


_v574_attach_s2_fresh_urgent_requests = _v603_attach_s2_fresh_urgent_requests

_v575_base_candidate_reason_summary = _v574_build_candidate_reason_summary

def _v575_build_candidate_reason_summary(display_rows: List[Dict[str, Any]], counts: Dict[str, int], reason_top: Any, nowv: float) -> Dict[str, Any]:
    base = _v575_base_candidate_reason_summary(display_rows, counts, reason_top, nowv)
    rows = [r for r in display_rows if isinstance(r, dict)]
    c = Counter(str(r.get("v575_urgent_action_state") or "not_requested") for r in rows if bool(r.get("v574_fresh_urgent_request")))
    req = sum(c.values())
    recovered = sum(c.get(k,0) for k in ("exec_risk_wait","trigger_wait","confirm_wait","promoted_s1","s2_other_wait"))
    promoted = c.get("promoted_s1", 0)
    keep = req - promoted
    top = " / ".join(f"{k} {v}" for k,v in c.most_common(5)) if c else "-"
    short = [
        "🧭 후보판정 이유 /candidate_reason · v575 긴급갱신 결과판",
        "- 기준: strategy_worker summary_text만 읽습니다. 후보 재계산 없음.",
        f"- 긴급갱신: 요청 {req} / fresh회복 {recovered} / S1승격 {promoted} / S2유지 {keep}",
        f"- 유지이유 TOP: {top}",
    ]
    summary = str(base.get("summary_text") or "")
    parts = summary.split("\n")
    if parts and parts[0].startswith("🧭 후보판정 이유"):
        # 기존 제목/상단 2~4줄은 v573/v574가 길게 붙인 부분이라 v575 요약으로 교체한다.
        drop = 0
        while drop < len(parts) and (parts[drop].startswith("🧭") or parts[drop].startswith("- 기준") or parts[drop].startswith("- 신선") or parts[drop].startswith("- 늦은") or parts[drop].startswith("- 긴급")):
            drop += 1
        parts = parts[drop:]
    base["summary_text"] = "\n".join(short + parts)
    base["schema"] = "candidate_reason_summary_text_v575_urgent_result"
    bs = base.get("batch_state") if isinstance(base.get("batch_state"), dict) else {}
    bs.update({"schema":"candidate_reason_batch_state_v575", "urgent_request_count": req, "urgent_fresh_recovered_count": recovered, "urgent_s1_promoted_count": promoted, "urgent_s2_keep_count": keep, "urgent_state_counts": dict(c)})
    base["batch_state"] = bs
    return base


# =============================================================================
# strategy_worker v0.128 / v580: S2 fresh/진입품질 원인 분리 표시
# - 조건/S1·S2·S3/청산 수치 변경 없음.
# - 현재 막힘(promote_block_reason)과 S1 필요조건(would_be_s1_if)을 섞어 집계하지 않는다.
# - fresh 회복 후 남은 병목이 실행위험/방아쇠/확인신호인지 한 줄로 분리한다.
# =============================================================================

def _v580_list_counter(rows: List[Dict[str, Any]], key: str, limit: int = 5) -> str:
    c: Counter = Counter()
    for r in rows:
        v = r.get(key)
        if isinstance(v, list):
            for x in v:
                if x:
                    c[str(x)] += 1
        elif v:
            c[str(v)] += 1
    return " / ".join(f"{k} {v}" for k, v in c.most_common(limit)) if c else "-"


def _v580_replace_or_insert(lines: List[str], prefix: str, replacement: List[str]) -> List[str]:
    out: List[str] = []
    done = False
    for line in lines:
        if (not done) and line.startswith(prefix):
            out.extend(replacement)
            done = True
        else:
            out.append(line)
    if not done:
        # 단계 줄 뒤에 끼워 넣는다.
        insert_at = 0
        for i, line in enumerate(out):
            if line.startswith('- 현재 단계:'):
                insert_at = i + 1
                break
        out[insert_at:insert_at] = replacement
    return out


def _v580_build_candidate_reason_summary(display_rows: List[Dict[str, Any]], counts: Dict[str, int], reason_top: Any, nowv: float) -> Dict[str, Any]:
    base = _v575_build_candidate_reason_summary(display_rows, counts, reason_top, nowv)
    rows = [r for r in display_rows if isinstance(r, dict)]
    s2_rows = [r for r in rows if _v510_stage(r) == 'S2']
    lifecycles = [r.get('s2_promotion_lifecycle') or {} for r in s2_rows]
    current_block_top = _v580_list_counter(lifecycles, 'promote_block_reason', 6)
    need_top = _v580_list_counter(lifecycles, 'would_be_s1_if', 6)
    c = Counter(str(r.get('v575_urgent_action_state') or 'not_requested') for r in rows if bool(r.get('v574_fresh_urgent_request')))
    req = sum(c.values())
    recovered = sum(c.get(k, 0) for k in ('exec_risk_wait', 'trigger_wait', 'confirm_wait', 'promoted_s1', 's2_other_wait'))
    fresh_wait = c.get('fresh_wait', 0)
    exec_wait = c.get('exec_risk_wait', 0)
    trigger_wait = c.get('trigger_wait', 0)
    confirm_wait = c.get('confirm_wait', 0)
    promoted = c.get('promoted_s1', 0)
    fresh_line = f"- fresh 분리: 요청 {req} / 회복 {recovered} / 미회복 {fresh_wait} / 회복후 실행위험 {exec_wait} / 방아쇠대기 {trigger_wait} / 확인대기 {confirm_wait} / S1 {promoted}"
    title = "🧭 후보판정 이유 /candidate_reason · v580 fresh·진입품질 분리판"
    summary = str(base.get('summary_text') or '')
    lines = summary.split('\n') if summary else []
    if lines and lines[0].startswith('🧭 후보판정 이유'):
        lines[0] = title
    else:
        lines.insert(0, title)
    # 기존 혼합 집계 한 줄을 현재막힘/필요조건으로 분리한다.
    lines = _v580_replace_or_insert(lines, '- S2 막힘 TOP:', [
        f'- S2 현재막힘 TOP: {current_block_top}',
        f'- S1 필요조건 TOP: {need_top}',
    ])
    # fresh 분리 줄은 긴급갱신/유지이유 뒤에 배치한다.
    insert_at = 0
    for i, line in enumerate(lines):
        if line.startswith('- 유지이유 TOP:'):
            insert_at = i + 1
            break
    if insert_at:
        lines.insert(insert_at, fresh_line)
    elif fresh_line not in lines:
        lines.insert(2 if len(lines) > 2 else len(lines), fresh_line)
    base['summary_text'] = '\n'.join(lines)
    base['schema'] = 'candidate_reason_summary_text_v580_fresh_entry_split'
    bs = base.get('batch_state') if isinstance(base.get('batch_state'), dict) else {}
    bs.update({
        'schema': 'candidate_reason_batch_state_v580',
        's2_current_block_top_text': current_block_top,
        's1_needed_top_text': need_top,
        'urgent_fresh_wait_count': fresh_wait,
        'urgent_exec_wait_count': exec_wait,
        'urgent_trigger_wait_count': trigger_wait,
        'urgent_confirm_wait_count': confirm_wait,
    })
    base['batch_state'] = bs
    return base

# 최종 summary 생산 본선 교체: 출력부 보정이 아니라 strategy_worker summary_text 생산부에서 분리한다.
_v557_build_candidate_reason_summary = _v580_build_candidate_reason_summary


# =============================================================================
# strategy_worker v0.130 / v584: 정보 주인표 + canonical metric row 본선
# - 기능 삭제 없음. 기존 structure_freshness/entry_context 호환 필드는 유지한다.
# - 새 정보는 생산 공장 → strategy canonical row → paper/main cache reader 순서로만 흐른다.
# - 조건/S등급/청산/자동매수 수치 변경 없음.
# =============================================================================

INFO_OWNER_TABLE_V584 = {
    'scanner': {'owner': 'scanner_worker', 'produces': ['ticker','hot_rank','volume','change_1m/3m/5m'], 'cache': 'scanner/feature input'},
    'feature': {'owner': 'feature_worker', 'produces': ['price','VWAP','EMA','relative_strength','price_reaction'], 'cache': 'feature cache'},
    'orderflow': {'owner': 'orderflow_worker+micro_ws', 'produces': ['quote','trade','spread','slippage','buy_ratio','sell_pressure'], 'cache': 'orderflow/micro cache'},
    'strategy': {'owner': 'strategy_worker', 'produces': ['structure','freshness_map','S1/S2/S3','entry_plan','risk_reward','block_reasons'], 'cache': 'canonical row + handoff'},
    'paper': {'owner': 'paper_bot', 'produces': ['OPEN','CLOSED','entry_reaction','score_cache','review_cache'], 'cache': 'paper status/trace/score/review'},
    'main': {'owner': 'main_bot', 'produces': ['display only'], 'cache': 'reads existing cache only'},
}


def _v584_num(row: Dict[str, Any], *keys: str, default: float = 0.0) -> float:
    vals = [row.get(k) for k in keys]
    return _v510_num(*vals, default=default)


def _v584_age_state(age: float, ttl: float) -> str:
    try:
        a = float(age)
    except Exception:
        a = 999999.0
    if a >= 99999:
        return 'missing'
    if a <= ttl:
        return 'fresh'
    return 'stale'


def _v584_build_freshness_map(row: Dict[str, Any], nowv: float) -> Dict[str, Any]:
    age_values = {
        'scanner_hot': _v584_num(row, 'hot_signal_age_sec', default=999999.0),
        'micro': _v584_num(row, 'micro_age_sec', default=999999.0),
        'orderflow': _v584_num(row, 'orderflow_age_sec', 'micro_age_sec', default=999999.0),
        'price_reaction': _v584_num(row, 'price_reaction_age_sec', default=999999.0),
        'quote': _v584_num(row, 'quote_age_sec', default=999999.0),
        'paper_row': max(0.0, nowv - _event_created_ts(row)),
    }
    ttl = {'scanner_hot': 35.0, 'micro': 20.0, 'orderflow': 20.0, 'price_reaction': 30.0, 'quote': 20.0, 'paper_row': 45.0}
    owners = {'scanner_hot': 'scanner_worker', 'micro': 'micro_sidecar/ws', 'orderflow': 'orderflow_worker', 'price_reaction': 'feature_worker', 'quote': 'micro_sidecar/ws', 'paper_row': 'strategy_worker'}
    items: Dict[str, Any] = {}
    stale_fields: List[str] = []
    for k, age in age_values.items():
        state = _v584_age_state(age, ttl[k])
        items[k] = {'owner': owners[k], 'age_sec': round(float(age), 3), 'ttl_sec': ttl[k], 'state': state}
        if state != 'fresh':
            stale_fields.append(f'{k} {float(age):.1f}s')
    for x in row.get('stale_reasons') or []:
        sx = str(x or '').strip()
        if sx and sx not in stale_fields:
            stale_fields.append(sx)
    core_keys = ('micro','orderflow','price_reaction','quote')
    core_states = [items[k]['state'] for k in core_keys]
    if all(x == 'fresh' for x in core_states):
        overall = 'fresh_ok'
    elif any(x == 'missing' for x in core_states):
        overall = 'fresh_missing'
    else:
        overall = 'fresh_recheck'
    max_core_age = max(float(items[k]['age_sec']) for k in core_keys)
    return {'schema': 'freshness_map_v584', 'overall': overall, 'max_core_age_sec': round(max_core_age, 3), 'items': items, 'stale_fields': stale_fields[:10]}


def _v584_structure_state(row: Dict[str, Any]) -> Tuple[str, List[str]]:
    levels = row.get('structure_levels') if isinstance(row.get('structure_levels'), dict) else {}
    timing = row.get('entry_timing_spine') if isinstance(row.get('entry_timing_spine'), dict) else {}
    tags = [str(x) for x in (row.get('structure_tags') or [])]
    risks = [str(x) for x in (row.get('risk_tags') or [])]
    price = _v584_num(row, 'current_price', 'entry_price', 'price', default=0.0)
    first_price = _v510_num(timing.get('first_seen_price'), timing.get('structure_seen_price'), default=0.0)
    s2_price = _v510_num(timing.get('s2_seen_price'), default=0.0)
    first_ret = round(((price - first_price) / first_price * 100.0), 3) if price and first_price else _v510_num(timing.get('first_to_now_return'), timing.get('first_to_now_return_pct'), default=0.0)
    s2_ret = round(((price - s2_price) / s2_price * 100.0), 3) if price and s2_price else _v510_num(timing.get('s2_to_now_return'), timing.get('s2_to_now_return_pct'), default=0.0)
    trigger_gap = _v510_num(row.get('trigger_gap_pct'), levels.get('distance_to_trigger_pct'), default=999999.0)
    defense_fail = any(('방어실패' in x or '이탈' in x or '윗꼬리' in x or '가짜돌파' in x) for x in tags + risks)
    recovery = any(('VWAP' in x or 'EMA' in x or '눌림' in x or '회복' in x or '방어' in x) for x in tags)
    late = bool(row.get('late_chase_flag') or (first_ret >= 1.4) or (s2_ret >= 0.8) or any('늦은추격' in x for x in risks))
    if defense_fail:
        state = '방어실패/가짜돌파위험'
    elif late:
        state = '늦은추격주의'
    elif recovery:
        state = '눌림회복/방어구조'
    elif trigger_gap < 0.35:
        state = '방아쇠근접'
    else:
        state = '구조관찰'
    basis = [f'first→now {first_ret:+.2f}%', f'S2→now {s2_ret:+.2f}%', f'trigger_gap {trigger_gap if trigger_gap < 900000 else 0:.3f}%']
    if tags:
        basis.append('tags:' + ','.join(tags[:3]))
    if risks:
        basis.append('risk:' + ','.join(risks[:3]))
    return state, basis[:8]


def _v584_execution_risk(row: Dict[str, Any]) -> Dict[str, Any]:
    spread = _v584_num(row, 'spread_pct', default=0.0)
    slippage = _v584_num(row, 'slippage_pct', 'spread_pct', default=spread)
    buy = _v584_num(row, 'buy_ratio', default=0.0)
    sustain = _v584_num(row, 'buy_sustain_1m', default=0.0)
    tags = [str(x) for x in (row.get('risk_tags') or [])]
    obs: List[str] = []
    if spread > 0.18: obs.append('스프레드부담')
    if slippage > 0.18: obs.append('미끄러짐부담')
    if buy < 0.70: obs.append('매수체결약함')
    if sustain < 0.70: obs.append('1분지속약함')
    for x in tags:
        if x not in obs: obs.append(x)
    level = 'risk_high' if any(x in obs for x in ['스프레드부담','미끄러짐부담','매도압력부담','매도벽/매도체결압력']) else ('risk_watch' if obs else 'risk_ok')
    return {'schema': 'execution_risk_v584', 'state': level, 'tags': obs[:10], 'spread_pct': round(spread,4), 'slippage_pct': round(slippage,4), 'buy_ratio': round(buy,4), 'buy_sustain_1m': round(sustain,4)}


def _v584_timing_spine(row: Dict[str, Any], nowv: float) -> Dict[str, Any]:
    old = row.get('entry_timing_spine') if isinstance(row.get('entry_timing_spine'), dict) else {}
    price = _v584_num(row, 'current_price', 'entry_price', 'price', default=0.0)
    first_ts = _v510_num(old.get('first_seen_ts'), row.get('first_seen_ts'), row.get('created_at'), default=0.0)
    s2_ts = _v510_num(old.get('s2_seen_ts'), row.get('s2_seen_ts'), default=0.0)
    s1_ts = _v510_num(old.get('s1_seen_ts'), row.get('s1_seen_ts'), default=0.0)
    first_price = _v510_num(old.get('first_seen_price'), row.get('first_seen_price'), row.get('detected_price'), price, default=0.0)
    s2_price = _v510_num(old.get('s2_seen_price'), row.get('s2_seen_price'), price if _v510_stage(row) == 'S2' else 0.0, default=0.0)
    s1_price = _v510_num(old.get('s1_seen_price'), row.get('s1_seen_price'), price if _v510_stage(row) == 'S1' else 0.0, default=0.0)
    first_to_now = round(((price-first_price)/first_price*100.0),3) if price and first_price else 0.0
    s2_to_now = round(((price-s2_price)/s2_price*100.0),3) if price and s2_price else 0.0
    return {'schema': 'entry_timing_spine_v584', 'first_seen_ts': first_ts or _event_created_ts(row), 's2_seen_ts': s2_ts, 's1_seen_ts': s1_ts, 'now_ts': nowv, 'first_seen_price': first_price, 's2_seen_price': s2_price, 's1_seen_price': s1_price, 'current_price': price, 'first_to_now_return_pct': first_to_now, 's2_to_now_return_pct': s2_to_now, 'first_to_s1_delay_sec': round(max(0.0, (s1_ts-first_ts)),3) if first_ts and s1_ts else None, 'late_chase_flag': bool(row.get('late_chase_flag') or first_to_now >= 1.4 or s2_to_now >= 0.8)}


def _v584_canonical_decision(structure_state: str, freshness: Dict[str, Any], execution: Dict[str, Any]) -> str:
    if freshness.get('overall') != 'fresh_ok':
        return '구조판단 fresh 재확인'
    if structure_state in {'늦은추격주의','방어실패/가짜돌파위험'}:
        return '구조위험 재확인'
    if execution.get('state') != 'risk_ok':
        return '실행위험 재확인'
    return '구조+fresh 관찰양호'


def _v584_build_canonical_metric_row(row: Dict[str, Any], nowv: float) -> Dict[str, Any]:
    structure_state, basis = _v584_structure_state(row)
    freshness = _v584_build_freshness_map(row, nowv)
    execution = _v584_execution_risk(row)
    timing = _v584_timing_spine(row, nowv)
    decision = _v584_canonical_decision(structure_state, freshness, execution)
    levels = row.get('structure_levels') if isinstance(row.get('structure_levels'), dict) else {}
    plan = row.get('entry_plan') if isinstance(row.get('entry_plan'), dict) else {}
    rr = row.get('risk_reward') if isinstance(row.get('risk_reward'), dict) else {}
    return {
        'schema': 'strategy_canonical_metric_row_v584',
        'version': VERSION,
        'updated_ts': nowv,
        'updated_text': now_text(nowv),
        'owner_policy': INFO_OWNER_TABLE_V584,
        'symbol': row.get('symbol') or row.get('ticker'),
        'ticker': row.get('ticker'),
        'strategy_key': row.get('strategy_key'),
        'strategy_label': row.get('strategy_label') or row.get('strategy'),
        'grade': _v510_stage(row),
        'metrics': {
            'price_reaction_pct': _v584_num(row, 'price_reaction_pct', default=0.0),
            'buy_ratio': _v584_num(row, 'buy_ratio', default=0.0),
            'buy_sustain_1m': _v584_num(row, 'buy_sustain_1m', default=0.0),
            'spread_pct': _v584_num(row, 'spread_pct', default=0.0),
            'slippage_pct': _v584_num(row, 'slippage_pct', 'spread_pct', default=0.0),
        },
        'freshness_map': freshness,
        'structure': {'state': structure_state, 'tags': list(row.get('structure_tags') or []), 'levels': levels, 'basis': basis},
        'entry_plan': plan,
        'risk_reward': rr,
        'execution_risk': execution,
        'timing_spine': timing,
        'block_reasons': list(row.get('block_reasons') or row.get('s_stage_reasons') or []),
        'entry_reasons': list(row.get('entry_reasons') or row.get('s_stage_reasons') or []),
        'source_snapshot': {'scanner': row.get('hot_signal_age_sec'), 'feature': row.get('price_reaction_age_sec'), 'orderflow': row.get('orderflow_age_sec'), 'micro': row.get('micro_age_sec'), 'quote': row.get('quote_age_sec')},
        'decision_reference': decision,
        'policy': '기능 유지. strategy_worker가 판단값을 봉인하고 paper/main은 읽기만 한다. 조건/S등급/청산 변경 없음.',
    }


def _v584_attach_canonical_metric_rows(rows: List[Dict[str, Any]], nowv: float) -> List[Dict[str, Any]]:
    out: List[Dict[str, Any]] = []
    for r in rows or []:
        if not isinstance(r, dict):
            continue
        rr = dict(r)
        canon = _v584_build_canonical_metric_row(rr, nowv)
        sf = {
            'schema': 'structure_freshness_spine_v584_alias',
            'version': VERSION,
            'updated_ts': nowv,
            'updated_text': now_text(nowv),
            'structure_state': canon['structure']['state'],
            'structure_basis': canon['structure']['basis'],
            'freshness_state': canon['freshness_map']['overall'],
            'age_values': {k: v.get('age_sec') for k, v in canon['freshness_map']['items'].items()},
            'max_core_age_sec': canon['freshness_map']['max_core_age_sec'],
            'stale_fields': canon['freshness_map']['stale_fields'],
            'execution_risk_observed': canon['execution_risk']['state'] != 'risk_ok',
            'decision_reference': canon['decision_reference'],
            'policy': canon['policy'],
        }
        rr['canonical_metric_row'] = canon
        rr['canonical_row_schema'] = canon['schema']
        rr['freshness_map'] = canon['freshness_map']
        rr['execution_risk'] = canon['execution_risk']
        rr['timing_spine_v584'] = canon['timing_spine']
        rr['structure_freshness'] = sf
        rr['structure_state_v584'] = sf['structure_state']
        rr['structure_freshness_state'] = sf['freshness_state']
        rr['structure_fresh_decision'] = sf['decision_reference']
        # v602: strategy canonical row 안에서 최종 매수 가능/대기/관찰/차단을 한 번 더 봉인한다.
        rr = _v602_seal_final_trade_state(rr, canon)
        canon = rr.get('canonical_metric_row') if isinstance(rr.get('canonical_metric_row'), dict) else canon
        ctx = rr.get('entry_context') if isinstance(rr.get('entry_context'), dict) else {}
        ctx = dict(ctx)
        ctx['canonical_metric_row'] = canon
        ctx['freshness_map'] = canon['freshness_map']
        ctx['execution_risk'] = canon['execution_risk']
        ctx['timing_spine_v584'] = canon['timing_spine']
        ctx['structure_freshness'] = sf
        ctx['final_trade_state'] = rr.get('final_trade_state')
        ctx['final_trade_allowed'] = rr.get('final_trade_allowed')
        ctx['final_trade_label'] = rr.get('final_trade_label')
        ctx['final_trade_reasons'] = rr.get('final_trade_reasons')
        rr['entry_context'] = ctx
        out.append(rr)
    return out

# _v510_publish 본체가 호출하는 v583 hook 자체를 v584 본선으로 교체한다.
_v583_attach_structure_freshness = _v584_attach_canonical_metric_rows



# =============================================================================
# strategy_worker v0.139 / v603: 공식캔들 반영 후 최종판정 확정
# - paper OPEN 최종 기준은 final_trade_state == S1_PASS 하나로 봉인한다.
# - paper_bot은 이 값을 읽기만 한다. 새 매수 판단은 paper에 추가하지 않는다.
# - 기존 canonical_entry_decision은 재료로 유지하되, 최종 허용값은 여기서 한 번 더 맞춘다.
# =============================================================================

def _v602_first_dict(*items: Any) -> Dict[str, Any]:
    for x in items:
        if isinstance(x, dict) and x:
            return x
    return {}


def _v602_list(*items: Any, limit: int = 12) -> List[str]:
    out: List[str] = []
    for item in items:
        if isinstance(item, list):
            src = item
        elif item in (None, "", {}, []):
            src = []
        else:
            src = [item]
        for v in src:
            sv = str(v or "").strip()
            if sv and sv not in out:
                out.append(sv)
            if len(out) >= limit:
                return out
    return out


def _v602_stage_for_state(state: str) -> str:
    if state == "S1_PASS":
        return "S1"
    if state == "S2_RECHECK":
        return "S2"
    return "S3"


def _v602_state_label(state: str) -> str:
    return {
        "S1_PASS": "✅ 매수 가능",
        "S2_RECHECK": "⚠️ 대기: 확인 더 필요",
        "S3_WATCH": "❔ 관찰만",
        "BLOCKED": "❌ 매수 금지: 위험",
    }.get(str(state or ""), "❔ 확인중")


def _v602_final_trade_decision(row: Dict[str, Any], canon: Dict[str, Any]) -> Dict[str, Any]:
    stage = _v510_stage(row)
    ctx = row.get("entry_context") if isinstance(row.get("entry_context"), dict) else {}
    dec = _v602_first_dict(row.get("canonical_entry_decision"), ctx.get("canonical_entry_decision"), row.get("common_entry_decision"), ctx.get("common_entry_decision"))
    freshness = canon.get("freshness_map") if isinstance(canon.get("freshness_map"), dict) else {}
    execution = canon.get("execution_risk") if isinstance(canon.get("execution_risk"), dict) else {}
    structure = canon.get("structure") if isinstance(canon.get("structure"), dict) else {}
    structure_state = str(structure.get("state") or row.get("structure_state_v584") or "")
    plan = canon.get("entry_plan") if isinstance(canon.get("entry_plan"), dict) else (row.get("entry_plan") if isinstance(row.get("entry_plan"), dict) else {})
    rr = canon.get("risk_reward") if isinstance(canon.get("risk_reward"), dict) else (row.get("risk_reward") if isinstance(row.get("risk_reward"), dict) else {})
    timing = canon.get("timing_spine") if isinstance(canon.get("timing_spine"), dict) else (row.get("entry_timing_spine") if isinstance(row.get("entry_timing_spine"), dict) else {})
    line_ev = structure.get("line_evidence") if isinstance(structure.get("line_evidence"), dict) else {}
    official = structure.get("official_structure_inputs") if isinstance(structure.get("official_structure_inputs"), dict) else _v596_official_structure_inputs(row) if "_v596_official_structure_inputs" in globals() else {}

    hard: List[str] = []
    wait: List[str] = []
    watch: List[str] = []

    if stage != "S1":
        if stage == "S2":
            wait.append("아직 S1이 아니라 재확인 대기")
        else:
            watch.append("S1 후보가 아니라 관찰")

    if not bool(dec.get("s1_allowed") or dec.get("gate_pass")):
        rs = dec.get("display_reasons") if isinstance(dec.get("display_reasons"), list) else (dec.get("s1_recheck_reasons") if isinstance(dec.get("s1_recheck_reasons"), list) else [])
        wait.append("전략 조건 최종통과 아님" + ((": " + " / ".join(str(x) for x in rs[:3])) if rs else ""))

    if row.get("fresh_gate_ok") is False:
        wait.append("정보가 오래돼 재확인 필요")
    if row.get("paper_bot_open") is False or row.get("open_eligible") is False or row.get("trade_ready") is False:
        wait.append("기존 OPEN 허용값이 꺼져 있음")

    if freshness.get("overall") != "fresh_ok":
        stale = freshness.get("stale_fields") if isinstance(freshness.get("stale_fields"), list) else []
        wait.append("최신정보 재확인 필요" + ((": " + " / ".join(str(x) for x in stale[:3])) if stale else ""))

    official_age = _v510_num(official.get("official_candle_age"), row.get("official_candle_age"), row.get("candle_age_sec"), default=-1.0) if isinstance(official, dict) else -1.0
    if official_age > 45:
        wait.append(f"공식 캔들 오래됨 {official_age:.0f}s")
    present = _v510_num(official.get("present_count"), default=-1.0) if isinstance(official, dict) else -1.0
    if 0 <= present < 6:
        wait.append("공식 구조재료 부족")

    line_risks = _v602_list(line_ev.get("line_risk_tags") if isinstance(line_ev, dict) else [], row.get("risk_tags"), execution.get("tags"), limit=12)
    if structure_state in {"늦은추격주의", "방어실패/가짜돌파위험"}:
        hard.append("차트 모양 위험: " + structure_state)
    if any(("가짜돌파" in x or "방어실패" in x or "윗꼬리" in x or "늦은추격" in x) for x in line_risks):
        hard.append("차트 위험태그: " + " / ".join(line_risks[:3]))

    exec_state = str(execution.get("state") or "")
    if exec_state == "risk_high":
        hard.append("진입 직전 거래위험 큼: " + " / ".join(line_risks[:4]))
    elif exec_state and exec_state != "risk_ok":
        wait.append("체결·스프레드 재확인 필요: " + exec_state)

    rr_ratio = _v510_num(rr.get("rr_ratio"), default=0.0) if isinstance(rr, dict) else 0.0
    if rr_ratio > 0 and rr_ratio < 1.0:
        wait.append(f"손익비 부족 {rr_ratio:.2f}")

    plan_status = str(plan.get("status") or "") if isinstance(plan, dict) else ""
    if plan_status and plan_status != "paper_open_ready":
        wait.append("진입계획 아직 대기: " + plan_status)

    if bool(timing.get("late_chase_flag")):
        hard.append("늦은 진입 위험")

    if hard:
        state = "BLOCKED"
    elif wait:
        state = "S2_RECHECK"
    elif watch:
        state = "S3_WATCH"
    else:
        state = "S1_PASS"

    reasons = _v602_list(hard, wait, watch, canon.get("decision_reference"), limit=10)
    if state == "S1_PASS" and not reasons:
        reasons = ["전략공장 최종 매수 가능"]
    return {
        "state": state,
        "allowed": state == "S1_PASS",
        "stage": _v602_stage_for_state(state),
        "label": _v602_state_label(state),
        "reasons": reasons,
        "decision_reference": canon.get("decision_reference"),
        "schema": "final_trade_state_v603_strategy_single_source",
    }


def _v602_seal_final_trade_state(row: Dict[str, Any], canon: Optional[Dict[str, Any]] = None) -> Dict[str, Any]:
    if not isinstance(row, dict):
        return row
    rr = dict(row)
    canon = canon if isinstance(canon, dict) else (rr.get("canonical_metric_row") if isinstance(rr.get("canonical_metric_row"), dict) else {})
    if not isinstance(canon, dict):
        canon = {}
    final = _v602_final_trade_decision(rr, canon)
    state = str(final.get("state") or "")
    allowed = bool(final.get("allowed"))
    final_stage = str(final.get("stage") or _v602_stage_for_state(state))

    canon = dict(canon)
    canon["schema"] = "strategy_canonical_metric_row_v603_final_trade_state"
    canon["final_trade_state"] = state
    canon["final_trade_allowed"] = allowed
    canon["final_trade_label"] = final.get("label")
    canon["final_trade_reasons"] = final.get("reasons") or []
    canon["final_decision"] = final.get("label")
    canon["final_decision_schema"] = final.get("schema")
    canon["paper_open_policy"] = "paper OPEN은 final_trade_state == S1_PASS 한 가지만 본다"

    rr["canonical_metric_row"] = canon
    rr["final_trade_state"] = state
    rr["final_trade_allowed"] = allowed
    rr["final_trade_label"] = final.get("label")
    rr["final_trade_reasons"] = final.get("reasons") or []
    rr["final_decision"] = final.get("label")
    rr["final_decision_schema"] = final.get("schema")
    rr["final_trade_state_source"] = "strategy_worker_canonical_metric_row_v603"
    rr["s_stage"] = rr["candidate_stage"] = rr["candidate_grade"] = rr["stage"] = rr["grade"] = final_stage
    rr["open_eligible"] = allowed
    rr["paper_bot_open"] = allowed
    rr["trade_ready"] = allowed
    rr["trade_ready_label"] = final.get("label")
    rr["final_entry_action"] = "paper_open" if allowed else "hold"
    rr["final_entry_label"] = final.get("label")
    rr["final_entry_reasons"] = final.get("reasons") or []
    rr["s1_short_reason"] = " / ".join((final.get("reasons") or [])[:3]) if not allowed else "최종 매수 가능"

    dec = rr.get("canonical_entry_decision") if isinstance(rr.get("canonical_entry_decision"), dict) else {}
    if dec:
        dec = dict(dec)
        dec["raw_s1_allowed_before_final_trade_state"] = bool(dec.get("s1_allowed") or dec.get("gate_pass"))
        dec["final_trade_state"] = state
        dec["final_trade_allowed"] = allowed
        dec["final_trade_label"] = final.get("label")
        dec["final_trade_reasons"] = final.get("reasons") or []
        dec["s1_allowed"] = allowed
        dec["gate_pass"] = allowed
        dec["action"] = "paper_open_candidate" if allowed else ("recheck" if final_stage == "S2" else "observe")
        rr["canonical_entry_decision"] = dec
        rr["common_entry_decision"] = dec
        rr["common_entry_pass"] = allowed

    sf = rr.get("structure_freshness") if isinstance(rr.get("structure_freshness"), dict) else {}
    if sf:
        sf = dict(sf)
        sf["final_trade_state"] = state
        sf["final_trade_label"] = final.get("label")
        sf["final_trade_reasons"] = final.get("reasons") or []
        rr["structure_freshness"] = sf

    ctx = rr.get("entry_context") if isinstance(rr.get("entry_context"), dict) else {}
    ctx = dict(ctx)
    ctx["canonical_metric_row"] = canon
    ctx["final_trade_state"] = state
    ctx["final_trade_allowed"] = allowed
    ctx["final_trade_label"] = final.get("label")
    ctx["final_trade_reasons"] = final.get("reasons") or []
    ctx["final_decision"] = final.get("label")
    ctx["final_decision_schema"] = final.get("schema")
    if dec:
        ctx["canonical_entry_decision"] = dec
        ctx["common_entry_decision"] = dec
    rr["entry_context"] = ctx
    return rr

def _v584_counter_text(rows: List[Dict[str, Any]], path: Tuple[str, ...], limit: int = 5) -> str:
    c: Counter = Counter()
    for r in rows:
        v: Any = r
        for k in path:
            if isinstance(v, dict):
                v = v.get(k)
            else:
                v = None
                break
        if v:
            c[str(v)] += 1
    return ' / '.join(f'{k} {v}' for k, v in c.most_common(limit)) if c else '-'


def _v584_build_candidate_reason_summary(display_rows: List[Dict[str, Any]], counts: Dict[str, int], reason_top: Any, nowv: float) -> Dict[str, Any]:
    base = _v580_build_candidate_reason_summary(display_rows, counts, reason_top, nowv)
    rows = [r for r in display_rows if isinstance(r, dict)]
    title = '🧭 후보판정 이유 /candidate_reason · v584 canonical row 구조'
    lines = str(base.get('summary_text') or '').split('\n')
    if lines and lines[0].startswith('🧭 후보판정 이유'):
        lines[0] = title
    else:
        lines.insert(0, title)
    struct_top = _v584_counter_text(rows, ('canonical_metric_row','structure','state'), 5)
    fresh_top = _v584_counter_text(rows, ('canonical_metric_row','freshness_map','overall'), 5)
    exec_top = _v584_counter_text(rows, ('canonical_metric_row','execution_risk','state'), 5)
    decision_top = _v584_counter_text(rows, ('canonical_metric_row','decision_reference'), 5)
    block = [
        '- 정보 위치: scanner/feature/orderflow는 생산만 · strategy가 canonical row 봉인 · paper/main은 읽기만',
        f'- canonical 구조 TOP: {struct_top}',
        f'- canonical fresh TOP: {fresh_top}',
        f'- canonical 실행위험 TOP: {exec_top}',
        f'- canonical 판정 TOP: {decision_top}',
    ]
    insert_at = 0
    for i, line in enumerate(lines):
        if line.startswith('- fresh 분리:'):
            insert_at = i + 1
            break
    if insert_at:
        lines[insert_at:insert_at] = block
    else:
        lines[2:2] = block
    base['summary_text'] = '\n'.join(lines)
    base['schema'] = 'candidate_reason_summary_text_v584_canonical_metric_row'
    bs = base.get('batch_state') if isinstance(base.get('batch_state'), dict) else {}
    bs.update({'schema': 'candidate_reason_batch_state_v584', 'canonical_structure_top_text': struct_top, 'canonical_fresh_top_text': fresh_top, 'canonical_execution_top_text': exec_top, 'canonical_decision_top_text': decision_top})
    base['batch_state'] = bs
    return base

_v557_build_candidate_reason_summary = _v584_build_candidate_reason_summary



# =============================================================================
# strategy_worker v0.131 / v595: reaction-based structure line refinement
# - 기능 추가가 아니라 구조선 생성/봉인 위치를 strategy_worker 본선으로 고정한다.
# - support/resistance/trigger/invalid가 계산선인지 실제 반응선인지 reason/confidence를 남긴다.
# - S1/S2/S3 체계, paper, main, 청산, 장부는 변경하지 않는다.
# =============================================================================

def _v595_num(row: Dict[str, Any], *keys: str, default: float = 0.0) -> float:
    for k in keys:
        try:
            if isinstance(row, dict) and row.get(k) not in (None, ""):
                return float(str(row.get(k)).replace(',', '').replace('%', ''))
        except Exception:
            continue
    return default


def _v595_has_any(row: Dict[str, Any], *keys: str) -> bool:
    return any(isinstance(row, dict) and row.get(k) not in (None, "", 0, 0.0) for k in keys)


def _v595_list(row: Dict[str, Any], *keys: str) -> List[str]:
    out: List[str] = []
    for k in keys:
        v = row.get(k) if isinstance(row, dict) else None
        if isinstance(v, list):
            out += [str(x) for x in v if x]
        elif v not in (None, ""):
            out.append(str(v))
    return out


def _v595_clip_conf(x: float) -> int:
    try:
        return max(0, min(100, int(round(float(x)))))
    except Exception:
        return 0


def _v595_structure_line_evidence(row: Dict[str, Any], levels: Dict[str, Any]) -> Dict[str, Any]:
    """실제 차트 반응 기반 구조선 근거를 만든다. 없는 값을 0으로 신뢰하지 않는다."""
    price = _v595_num(row, 'current_price', 'entry_price', 'price', default=0.0)
    fam = str(levels.get('strategy_family') or _v554_strategy_family(row))
    tags = _v595_list(row, 'structure_tags', 'matched_strategy_labels', 'entry_structure_tags')
    risks = _v595_list(row, 'risk_tags', 'execution_risk_tags', 'structure_risk_tags')
    react = _v595_num(row, 'price_reaction_pct', default=0.0)
    buy = _v595_num(row, 'buy_ratio', default=0.0)
    sustain = _v595_num(row, 'buy_sustain_1m', default=0.0)
    spread = _v595_num(row, 'spread_pct', default=0.0)
    slip = _v595_num(row, 'slippage_pct', 'spread_pct', default=spread)
    ch1 = _v595_num(row, 'change_1m_pct', 'change_1m', default=0.0)
    ch3 = _v595_num(row, 'change_3m_pct', 'change_3m', default=0.0)
    high_gap = _v595_num(row, 'recent_high_gap_pct', 'below_high_pct', 'high_gap_pct', default=0.0)
    low_rebound = _v595_num(row, 'recent_low_rebound_pct', 'low_rebound_pct', default=0.0)
    vwap_gap = _v595_num(row, 'vwap_gap_pct', 'vwap_pos_pct', 'vwap_position_pct', default=999999.0)
    ema_gap = _v595_num(row, 'ema5_gap_pct', 'ema5_pos_pct', 'ma5_gap_pct', default=999999.0)
    upper_wick = _v595_num(row, 'upper_wick_pct', 'upper_shadow_pct', 'long_upper_wick_pct', default=0.0)
    lower_wick = _v595_num(row, 'lower_wick_pct', 'lower_shadow_pct', 'long_lower_wick_pct', default=0.0)
    vol_exp = _v595_num(row, 'volume_expansion_pct', 'volume_change_pct', 'trade_value_change_pct', default=0.0)
    sell_wall = any(('매도벽' in x or '매도압력' in x) for x in risks)
    fake_or_fail = any(('가짜돌파' in x or '방어실패' in x or '재이탈' in x or '윗꼬리' in x) for x in risks + tags)
    late = bool(row.get('late_chase_flag') or ch1 >= 1.8 or ch3 >= 3.2 or react >= 1.8 or any('늦은추격' in x for x in risks))

    support_reasons: List[str] = []
    resistance_reasons: List[str] = []
    trigger_reasons: List[str] = []
    invalid_reasons: List[str] = []
    risk_tags: List[str] = []
    missing: List[str] = []

    support_conf = 0.0
    resistance_conf = 0.0

    if low_rebound > 0.12 or _v595_has_any(row, 'recent_low_price', 'swing_low_price', 'box_low_price'):
        support_conf += 30; support_reasons.append('최근 저점/박스하단 반응')
    else:
        missing.append('swing_low')
    if abs(vwap_gap) <= 0.35 or abs(ema_gap) <= 0.35:
        support_conf += 25; support_reasons.append('VWAP/EMA 근접 겹침')
    elif vwap_gap < -0.20 and ema_gap < -0.20:
        risk_tags.append('VWAP/EMA 하단 구조')
    if lower_wick >= 0.20 or any('쓸림' in x or '저점' in x for x in tags):
        support_conf += 15; support_reasons.append('아랫꼬리/쓸림 후 회복 근거')
    if react > 0.20 and buy >= 0.65:
        support_conf += 15; support_reasons.append('반응+매수체결 동반')
    if spread <= 0.18 and slip <= 0.18:
        support_conf += 10; support_reasons.append('실행위험 정상권')

    if high_gap < -0.05 or _v595_has_any(row, 'recent_high_price', 'swing_high_price', 'box_high_price'):
        resistance_conf += 35; resistance_reasons.append('직전 고점/박스상단 근거')
    else:
        missing.append('swing_high')
    if upper_wick >= 0.20:
        resistance_conf += 15; resistance_reasons.append('윗꼬리 저항 흔적')
        risk_tags.append('윗꼬리 저항 주의')
    if sell_wall:
        resistance_conf += 15; resistance_reasons.append('매도벽/매도압력 구간')
    if vol_exp > 0.0:
        resistance_conf += 10; resistance_reasons.append('거래량/거래대금 반응')

    # 방아쇠는 저항선 근거 + 진입 확인신호가 같이 있어야 신뢰한다.
    trigger_conf = resistance_conf * 0.55
    if react >= 0.35:
        trigger_conf += 15; trigger_reasons.append(f'가격반응 {react:+.2f}%')
    if buy >= 0.70:
        trigger_conf += 12; trigger_reasons.append(f'매수체결 {buy:.2f}')
    if sustain >= 0.70:
        trigger_conf += 12; trigger_reasons.append(f'1분지속 {sustain:.2f}')
    if spread <= 0.18 and slip <= 0.18:
        trigger_conf += 10; trigger_reasons.append(f'스프레드/미끄러짐 정상 {spread:.2f}/{slip:.2f}%')
    if fake_or_fail:
        trigger_conf -= 30; risk_tags.append('가짜돌파/방어실패 위험')
    if late:
        trigger_conf -= 25; risk_tags.append('늦은추격 구조위험')
    if fam == 'hot_rank':
        trigger_conf -= 10; risk_tags.append('hot-rank는 발견신호')
    if fam == 'sweep_vwap' and support_conf < 55:
        trigger_conf -= 15; risk_tags.append('저점 VWAP 회복 지지근거 약함')

    invalid_conf = support_conf * 0.75
    if support_conf >= 55:
        invalid_reasons.append('지지선 재이탈 기준')
    if vwap_gap > -0.10 or ema_gap > -0.10:
        invalid_reasons.append('VWAP/EMA 방어 실패 기준')
    if not invalid_reasons:
        invalid_reasons.append('구조 무효 근거 부족')
        risk_tags.append('무효선 계산선 의심')

    support_conf_i = _v595_clip_conf(support_conf)
    resistance_conf_i = _v595_clip_conf(resistance_conf)
    trigger_conf_i = _v595_clip_conf(trigger_conf)
    invalid_conf_i = _v595_clip_conf(invalid_conf)

    if trigger_conf_i >= 70 and support_conf_i >= 55 and not fake_or_fail:
        quality = 'reactive_line_confirmed'
    elif trigger_conf_i >= 50 and support_conf_i >= 40:
        quality = 'reactive_line_watch'
    else:
        quality = 'calculated_line_recheck'
        risk_tags.append('구조선 근거 재확인')

    return {
        'schema': 'structure_line_evidence_v595',
        'quality': quality,
        'support_confidence': support_conf_i,
        'resistance_confidence': resistance_conf_i,
        'trigger_confidence': trigger_conf_i,
        'invalid_confidence': invalid_conf_i,
        'support_reason': ' / '.join(support_reasons[:5]) or '실제 반응선 근거 부족',
        'resistance_reason': ' / '.join(resistance_reasons[:5]) or '실제 저항 근거 부족',
        'trigger_reason': ' / '.join(trigger_reasons[:6]) or '방아쇠 확인신호 부족',
        'invalid_reason': ' / '.join(invalid_reasons[:4]),
        'line_risk_tags': _v510_uniq(risk_tags, 8),
        'missing_structure_inputs': _v510_uniq(missing, 6),
        'basis': {'family': fam, 'price': price, 'react': round(react,3), 'buy': round(buy,3), 'sustain': round(sustain,3), 'spread': round(spread,3), 'slippage': round(slip,3), 'vwap_gap': round(vwap_gap if vwap_gap < 900000 else 0,3), 'ema_gap': round(ema_gap if ema_gap < 900000 else 0,3), 'high_gap': round(high_gap,3), 'low_rebound': round(low_rebound,3), 'late_chase': late},
    }


_v595_base_build_structure_levels = _v554_build_structure_levels

def _v554_build_structure_levels(row: Dict[str, Any]) -> Dict[str, Any]:  # type: ignore[override]
    levels = _v595_base_build_structure_levels(row)
    if not isinstance(levels, dict) or not levels.get('available'):
        return levels
    ev = _v595_structure_line_evidence(row, levels)
    levels = dict(levels)
    levels['schema'] = 'structure_levels_v595_reactive_lines'
    levels['line_policy'] = '실제 차트 반응선 우선. 계산선은 recheck로 표시하고 기능/청산은 변경하지 않는다.'
    levels['structure_line_evidence'] = ev
    levels['structure_line_quality'] = ev['quality']
    levels['support_reason'] = ev['support_reason']
    levels['resistance_reason'] = ev['resistance_reason']
    levels['trigger_reason'] = ev['trigger_reason'] if ev['trigger_reason'] != '방아쇠 확인신호 부족' else levels.get('trigger_reason') or ev['trigger_reason']
    levels['invalid_reason'] = ev['invalid_reason']
    levels['support_confidence'] = ev['support_confidence']
    levels['resistance_confidence'] = ev['resistance_confidence']
    levels['trigger_confidence'] = ev['trigger_confidence']
    levels['invalid_confidence'] = ev['invalid_confidence']
    levels['line_risk_tags'] = ev['line_risk_tags']
    levels['missing_structure_inputs'] = ev['missing_structure_inputs']
    # 목표/손익비 수치는 기존 값 유지. 단, 근거 문자열만 실제 반응선 근거로 보강한다.
    levels['target_reason'] = (levels.get('target_reason') or '') + ' / v595: 저항선·방아쇠 신뢰도 참고'
    return levels


def _v595_apply_structure_line_gate(row: Dict[str, Any]) -> Dict[str, Any]:
    r = dict(row)
    levels = r.get('structure_levels') if isinstance(r.get('structure_levels'), dict) else {}
    ev = levels.get('structure_line_evidence') if isinstance(levels.get('structure_line_evidence'), dict) else {}
    quality = str(levels.get('structure_line_quality') or ev.get('quality') or '')
    trig_conf = _v510_num(levels.get('trigger_confidence'), ev.get('trigger_confidence'), default=0.0)
    support_conf = _v510_num(levels.get('support_confidence'), ev.get('support_confidence'), default=0.0)
    line_risks = [str(x) for x in (levels.get('line_risk_tags') or ev.get('line_risk_tags') or [])]
    severe = any(('가짜돌파' in x or '방어실패' in x or '늦은추격' in x or '지지근거 약함' in x) for x in line_risks)
    needs_recheck = quality == 'calculated_line_recheck' or trig_conf < 45 or support_conf < 35 or severe
    r['structure_line_quality'] = quality
    r['structure_line_confidence'] = {'trigger': trig_conf, 'support': support_conf, 'quality': quality}
    r['structure_line_risk_tags'] = line_risks
    if line_risks:
        r['structure_risk_tags'] = _v510_uniq(list(r.get('structure_risk_tags') or []) + line_risks, 12)
        r['risk_tags'] = _v510_uniq(list(r.get('risk_tags') or []) + line_risks, 12)
    if _v510_stage(r) == 'S1' and needs_recheck:
        r['v595_downgraded_from_s1_structure_line'] = True
        r['s_stage'] = r['candidate_stage'] = r['candidate_grade'] = r['stage'] = r['grade'] = 'S2'
        r['open_eligible'] = False
        r['paper_bot_open'] = False
        r['trade_ready'] = False
        reason = f"구조선 재확인: {quality or 'unknown'} / trigger_conf {trig_conf:.0f} / support_conf {support_conf:.0f}"
        r['s_stage_reasons'] = _v510_uniq(list(r.get('s_stage_reasons') or []) + [reason], 14)
        r['s2_recheck_reasons'] = _v510_uniq(list(r.get('s2_recheck_reasons') or []) + [reason], 12)
    return r


_v595_base_attach_canonical_metric_rows = _v584_attach_canonical_metric_rows

def _v595_attach_reactive_structure_rows(rows: List[Dict[str, Any]], nowv: float) -> List[Dict[str, Any]]:
    gated = [_v595_apply_structure_line_gate(r) for r in (rows or []) if isinstance(r, dict)]
    out = _v595_base_attach_canonical_metric_rows(gated, nowv)
    for rr in out:
        levels = rr.get('structure_levels') if isinstance(rr.get('structure_levels'), dict) else {}
        ev = levels.get('structure_line_evidence') if isinstance(levels.get('structure_line_evidence'), dict) else {}
        canon = rr.get('canonical_metric_row') if isinstance(rr.get('canonical_metric_row'), dict) else {}
        if isinstance(canon, dict):
            canon['schema'] = 'strategy_canonical_metric_row_v595_reactive_structure_lines'
            struct = canon.get('structure') if isinstance(canon.get('structure'), dict) else {}
            struct['levels'] = levels
            struct['line_evidence'] = ev
            struct['line_quality'] = levels.get('structure_line_quality')
            struct['line_risk_tags'] = levels.get('line_risk_tags') or []
            canon['structure'] = struct
            canon['policy'] = 'v595: 구조선은 실제 반응선 reason/confidence로 봉인. paper/main은 읽기만. 청산/자동매수/장부 변경 없음.'
            rr['canonical_metric_row'] = canon
            ctx = rr.get('entry_context') if isinstance(rr.get('entry_context'), dict) else {}
            ctx = dict(ctx); ctx['canonical_metric_row'] = canon; rr['entry_context'] = ctx
    return out

_v583_attach_structure_freshness = _v595_attach_reactive_structure_rows


_v595_base_build_candidate_reason_summary = _v584_build_candidate_reason_summary

def _v595_counter_text(rows: List[Dict[str, Any]], path: Tuple[str, ...], limit: int = 5) -> str:
    c: Counter = Counter()
    for r in rows:
        v: Any = r
        for k in path:
            if isinstance(v, dict):
                v = v.get(k)
            else:
                v = None; break
        if isinstance(v, list):
            for x in v:
                if x: c[str(x)] += 1
        elif v:
            c[str(v)] += 1
    return ' / '.join(f'{k} {v}' for k, v in c.most_common(limit)) if c else '-'


def _v595_build_candidate_reason_summary(display_rows: List[Dict[str, Any]], counts: Dict[str, int], reason_top: Any, nowv: float) -> Dict[str, Any]:
    base = _v595_base_build_candidate_reason_summary(display_rows, counts, reason_top, nowv)
    rows = [r for r in display_rows if isinstance(r, dict)]
    lines = str(base.get('summary_text') or '').split('\n')
    title = '🧭 후보판정 이유 /candidate_reason · v595 구조선 정교화'
    if lines and lines[0].startswith('🧭 후보판정 이유'):
        lines[0] = title
    else:
        lines.insert(0, title)
    quality_top = _v595_counter_text(rows, ('structure_levels','structure_line_quality'), 5)
    line_risk_top = _v595_counter_text(rows, ('structure_levels','line_risk_tags'), 5)
    trigger_conf_values = []
    for r in rows:
        levels = r.get('structure_levels') if isinstance(r.get('structure_levels'), dict) else {}
        tv = _v510_num(levels.get('trigger_confidence'), default=-1)
        if tv >= 0: trigger_conf_values.append(tv)
    avg_trigger = round(sum(trigger_conf_values)/len(trigger_conf_values), 1) if trigger_conf_values else 0.0
    block = [
        '- 구조선 정책: 실제 반응선 reason/confidence를 strategy canonical row에 봉인',
        f'- 구조선 품질 TOP: {quality_top}',
        f'- 구조선 위험 TOP: {line_risk_top}',
        f'- 방아쇠 신뢰도 평균: {avg_trigger:.1f}',
    ]
    insert_at = 0
    for i, line in enumerate(lines):
        if line.startswith('- 정보 위치:'):
            insert_at = i + 1
            break
    if insert_at:
        lines[insert_at:insert_at] = block
    else:
        lines[2:2] = block
    base['summary_text'] = '\n'.join(lines)
    base['schema'] = 'candidate_reason_summary_text_v595_reactive_structure_lines'
    bs = base.get('batch_state') if isinstance(base.get('batch_state'), dict) else {}
    bs.update({'schema': 'candidate_reason_batch_state_v595', 'structure_line_quality_top_text': quality_top, 'structure_line_risk_top_text': line_risk_top, 'trigger_confidence_avg': avg_trigger})
    base['batch_state'] = bs
    return base

_v557_build_candidate_reason_summary = _v595_build_candidate_reason_summary


# =============================================================================
# strategy_worker v0.132 / v596: official API structure-input spine
# - candle/feature worker가 빗썸 공식 캔들 OHLCV에서 생산한 swing/box/wick/VWAP/EMA 정보를 우선 사용한다.
# - strategy_worker는 API 직접 호출 금지. 공식 데이터 cache만 읽고 canonical row에 봉인한다.
# - S1/S2/S3 수치 조건, 청산, paper, 장부는 변경하지 않는다.
# =============================================================================

def _v596_num_known(row: Dict[str, Any], *keys: str) -> Tuple[Optional[float], bool]:
    for k in keys:
        try:
            if isinstance(row, dict) and row.get(k) not in (None, ""):
                return float(str(row.get(k)).replace(',', '').replace('%', '')), True
        except Exception:
            continue
    return None, False


def _v596_official_structure_inputs(row: Dict[str, Any]) -> Dict[str, Any]:
    """feature_worker가 공식 캔들 API 기반으로 넘긴 구조선 재료를 표준화한다."""
    keys = [
        'official_candle_source','official_candle_age','official_candle_intervals',
        'swing_high_price','swing_low_price','box_high_price','box_low_price',
        'recent_high_price','recent_low_price','support_touch_count','resistance_touch_count',
        'upper_wick_pct','lower_wick_pct','vwap_gap_pct','ema5_gap_pct','ema10_gap_pct','ema20_gap_pct',
        'volume_ratio','volume_expansion_pct','breakout_hint','sweep_reclaim_hint','box_breakout_hint',
        'support_reclaim_hint','resistance_reject_hint','pullback_volume_contract','reclaim_volume_expand'
    ]
    out={k:row.get(k) for k in keys if isinstance(row,dict) and row.get(k) not in (None,'')}
    present=[k for k in keys if isinstance(row,dict) and row.get(k) not in (None,'')]
    missing=[]
    for k in ('swing_high_price','swing_low_price','box_high_price','box_low_price','upper_wick_pct','lower_wick_pct','vwap_gap_pct','ema5_gap_pct','volume_ratio'):
        if k not in present:
            missing.append(k)
    out['present_count']=len(present)
    out['missing_core']=missing[:12]
    out['source_policy']='v596: 공식 API OHLCV 구조 재료는 feature_worker 생산, strategy_worker 봉인만 수행'
    return out


_v596_prev_structure_line_evidence = _v595_structure_line_evidence

def _v595_structure_line_evidence(row: Dict[str, Any], levels: Dict[str, Any]) -> Dict[str, Any]:  # type: ignore[override]
    ev = _v596_prev_structure_line_evidence(row, levels)
    if not isinstance(ev, dict):
        ev={}
    official = _v596_official_structure_inputs(row)
    risk_tags=list(ev.get('line_risk_tags') or [])
    missing=list(ev.get('missing_structure_inputs') or [])
    support_reason=str(ev.get('support_reason') or '')
    resistance_reason=str(ev.get('resistance_reason') or '')
    trigger_reason=str(ev.get('trigger_reason') or '')
    support_conf=float(ev.get('support_confidence') or 0)
    resistance_conf=float(ev.get('resistance_confidence') or 0)
    trigger_conf=float(ev.get('trigger_confidence') or 0)

    support_touch, support_touch_ok = _v596_num_known(row,'support_touch_count')
    resist_touch, resist_touch_ok = _v596_num_known(row,'resistance_touch_count')
    swing_low, swing_low_ok = _v596_num_known(row,'swing_low_price','recent_low_price','box_low_price')
    swing_high, swing_high_ok = _v596_num_known(row,'swing_high_price','recent_high_price','box_high_price')
    vwap_gap, vwap_ok = _v596_num_known(row,'vwap_gap_pct')
    ema5_gap, ema5_ok = _v596_num_known(row,'ema5_gap_pct')
    upper, upper_ok = _v596_num_known(row,'upper_wick_pct')
    lower, lower_ok = _v596_num_known(row,'lower_wick_pct')
    vol_ratio, vol_ok = _v596_num_known(row,'volume_ratio')
    official_age, official_age_ok = _v596_num_known(row,'official_candle_age','candle_age_sec')

    add_support=[]; add_resist=[]; add_trigger=[]
    if support_touch_ok and support_touch >= 2:
        support_conf += 18; add_support.append(f'공식캔들 지지반응 {int(support_touch)}회')
    if swing_low_ok:
        support_conf += 10; add_support.append('공식 swing low/box low 존재')
    if vwap_ok and abs(vwap_gap or 0) <= 0.35:
        support_conf += 10; add_support.append('공식 VWAP 근접')
    if ema5_ok and abs(ema5_gap or 0) <= 0.35:
        support_conf += 8; add_support.append('공식 EMA5 근접')
    if lower_ok and lower >= 35:
        support_conf += 10; add_support.append('공식 아랫꼬리 회복')
    if bool(row.get('support_reclaim_hint') or row.get('sweep_reclaim_hint')):
        support_conf += 12; add_support.append('쓸림/지지 회복 힌트')

    if resist_touch_ok and resist_touch >= 2:
        resistance_conf += 18; add_resist.append(f'공식캔들 저항반응 {int(resist_touch)}회')
    if swing_high_ok:
        resistance_conf += 10; add_resist.append('공식 swing high/box high 존재')
    if upper_ok and upper >= 35:
        resistance_conf += 8; add_resist.append('공식 윗꼬리 저항')
    if bool(row.get('resistance_reject_hint')):
        resistance_conf += 10; add_resist.append('저항 거절 힌트')
    if vol_ok and vol_ratio >= 1.15:
        resistance_conf += 7; add_resist.append(f'공식 거래량반응 {vol_ratio:.2f}x')

    if bool(row.get('box_breakout_hint') or row.get('breakout_hint')) and swing_high_ok:
        trigger_conf += 15; add_trigger.append('공식 박스/직전고점 돌파 힌트')
    if bool(row.get('reclaim_volume_expand')):
        trigger_conf += 10; add_trigger.append('회복 거래량 재증가')
    if official_age_ok and official_age > 45:
        risk_tags.append(f'공식캔들 stale {official_age:.0f}s')
    if official.get('present_count',0) < 6:
        risk_tags.append('공식구조재료 부족')
    for m in official.get('missing_core') or []:
        if m not in missing:
            missing.append(m)

    support_conf_i=_v595_clip_conf(support_conf)
    resistance_conf_i=_v595_clip_conf(resistance_conf)
    trigger_conf_i=_v595_clip_conf(trigger_conf)
    severe = any(('가짜돌파' in x or '방어실패' in x or '늦은추격' in x or 'stale' in x) for x in risk_tags)
    if trigger_conf_i >= 72 and support_conf_i >= 60 and not severe:
        quality='official_reactive_line_confirmed'
    elif trigger_conf_i >= 52 and support_conf_i >= 42:
        quality='official_reactive_line_watch'
    else:
        quality=ev.get('quality') or 'calculated_line_recheck'

    ev.update({
        'schema':'structure_line_evidence_v596_official_api_inputs',
        'quality':quality,
        'support_confidence':support_conf_i,
        'resistance_confidence':resistance_conf_i,
        'trigger_confidence':trigger_conf_i,
        'support_reason':' / '.join([x for x in [support_reason]+add_support if x and x!='실제 반응선 근거 부족'][:7]) or '실제 반응선 근거 부족',
        'resistance_reason':' / '.join([x for x in [resistance_reason]+add_resist if x and x!='실제 저항 근거 부족'][:7]) or '실제 저항 근거 부족',
        'trigger_reason':' / '.join([x for x in [trigger_reason]+add_trigger if x and x!='방아쇠 확인신호 부족'][:8]) or '방아쇠 확인신호 부족',
        'line_risk_tags':_v510_uniq(risk_tags,10),
        'missing_structure_inputs':_v510_uniq(missing,12),
        'official_structure_inputs':official,
    })
    basis=ev.get('basis') if isinstance(ev.get('basis'),dict) else {}
    basis.update({'official_present':official.get('present_count'), 'official_age':official.get('official_candle_age'), 'support_touch':support_touch if support_touch_ok else None, 'resistance_touch':resist_touch if resist_touch_ok else None})
    ev['basis']=basis
    return ev


_v596_prev_attach_reactive_structure_rows = _v583_attach_structure_freshness

def _v596_attach_official_structure_rows(rows: List[Dict[str, Any]], nowv: float) -> List[Dict[str, Any]]:
    out = _v596_prev_attach_reactive_structure_rows(rows, nowv)
    # v603: 공식 candle/구조선 evidence를 붙인 뒤 final_trade_state를 다시 봉인하고,
    #       그 결과를 반드시 out[index]에 되돌려 넣는다.
    #       v602는 rr 로컬 변수만 재할당될 수 있어 paper row가 공식 candle 반영 전 판정으로 남을 수 있었다.
    for idx, rr0 in enumerate(out):
        if not isinstance(rr0, dict):
            continue
        rr = dict(rr0)
        levels=rr.get('structure_levels') if isinstance(rr.get('structure_levels'),dict) else {}
        ev=levels.get('structure_line_evidence') if isinstance(levels.get('structure_line_evidence'),dict) else {}
        canon=rr.get('canonical_metric_row') if isinstance(rr.get('canonical_metric_row'),dict) else {}
        if isinstance(canon,dict):
            canon=dict(canon)
            canon['schema']='strategy_canonical_metric_row_v603_official_structure_final_trade_state'
            struct=canon.get('structure') if isinstance(canon.get('structure'),dict) else {}
            struct=dict(struct)
            struct['official_structure_inputs']=ev.get('official_structure_inputs') or _v596_official_structure_inputs(rr)
            struct['line_evidence']=ev
            struct['line_quality']=levels.get('structure_line_quality') or ev.get('quality')
            canon['structure']=struct
            canon['policy']='v603: 공식 API 구조재료 반영 후 final_trade_state를 다시 봉인하고 paper/main은 그 값만 읽는다.'
            rr['canonical_metric_row']=canon
            rr = _v602_seal_final_trade_state(rr, canon)
            canon = rr.get('canonical_metric_row') if isinstance(rr.get('canonical_metric_row'), dict) else canon
            ctx=rr.get('entry_context') if isinstance(rr.get('entry_context'),dict) else {}
            ctx=dict(ctx); ctx['canonical_metric_row']=canon; ctx['final_trade_state']=rr.get('final_trade_state'); ctx['final_trade_label']=rr.get('final_trade_label'); ctx['final_trade_reasons']=rr.get('final_trade_reasons'); ctx['final_trade_allowed']=rr.get('final_trade_allowed'); rr['entry_context']=ctx
            rr['v603_official_final_state_resealed'] = True
            out[idx] = rr
    return out

_v583_attach_structure_freshness = _v596_attach_official_structure_rows


_v596_prev_build_candidate_reason_summary = _v557_build_candidate_reason_summary

def _v596_build_candidate_reason_summary(display_rows: List[Dict[str, Any]], counts: Dict[str,int], reason_top: Any, nowv: float) -> Dict[str,Any]:
    base=_v596_prev_build_candidate_reason_summary(display_rows, counts, reason_top, nowv)
    rows=[r for r in display_rows if isinstance(r,dict)]
    lines=str(base.get('summary_text') or '').split('\n')
    title='🧭 후보판정 이유 /candidate_reason · v596 공식API 구조선 재료'
    if lines and lines[0].startswith('🧭 후보판정 이유'):
        lines[0]=title
    else:
        lines.insert(0,title)
    official_ok=0; official_missing=0; ages=[]
    for r in rows:
        official=_v596_official_structure_inputs(r)
        if official.get('present_count',0) >= 6: official_ok+=1
        else: official_missing+=1
        try:
            if official.get('official_candle_age') not in (None,''):
                ages.append(float(official.get('official_candle_age')))
        except Exception: pass
    avg_age=round(sum(ages)/len(ages),1) if ages else 0.0
    block=[
        '- 공식API 구조재료: candle_worker/feature_worker가 OHLCV·swing·box·wick·VWAP/EMA 생산, strategy가 봉인',
        f'- 공식 구조재료 충분/부족: {official_ok}/{official_missing}',
        f'- 공식 candle age 평균: {avg_age:.1f}s' if ages else '- 공식 candle age 평균: -',
    ]
    insert_at=0
    for i,line in enumerate(lines):
        if line.startswith('- 구조선 정책:'):
            insert_at=i+1; break
    if insert_at:
        lines[insert_at:insert_at]=block
    else:
        lines[2:2]=block
    base['summary_text']='\n'.join(lines)
    base['schema']='candidate_reason_summary_text_v596_official_structure_inputs'
    bs=base.get('batch_state') if isinstance(base.get('batch_state'),dict) else {}
    bs.update({'schema':'candidate_reason_batch_state_v596','official_structure_ok':official_ok,'official_structure_missing':official_missing,'official_candle_age_avg':avg_age})
    base['batch_state']=bs
    return base

_v557_build_candidate_reason_summary = _v596_build_candidate_reason_summary


# v598: candidate_reason label/diagnostics for official candle evidence propagation runtime-fix.
_v597_prev_build_candidate_reason_summary = _v557_build_candidate_reason_summary

def _v597_build_candidate_reason_summary(display_rows: List[Dict[str, Any]], counts: Dict[str,int], reason_top: Any, nowv: float) -> Dict[str,Any]:
    base = _v597_prev_build_candidate_reason_summary(display_rows, counts, reason_top, nowv)
    lines = str(base.get('summary_text') or '').split('\n')
    title = '🧭 후보판정 이유 /candidate_reason · v598 공식API 구조재료 배관복구'
    if lines and lines[0].startswith('🧭 후보판정 이유'):
        lines[0] = title
    else:
        lines.insert(0, title)
    # Replace/add one concise line so we can distinguish v596 logic from the v597 propagation fix.
    diag = '- v598 배관복구: _v510_make_row UnboundLocalError 제거, candle_worker cache → strategy canonical row 보존. API 직접조회 없음.'
    if diag not in lines:
        insert_at = 0
        for i, line in enumerate(lines):
            if line.startswith('- 공식API 구조재료:'):
                insert_at = i + 1
                break
        if insert_at:
            lines.insert(insert_at, diag)
        else:
            lines.insert(2, diag)
    base['summary_text'] = '\n'.join(lines)
    bs = base.get('batch_state') if isinstance(base.get('batch_state'), dict) else {}
    bs['schema'] = 'candidate_reason_batch_state_v598'
    bs['official_structure_pipe'] = 'candle_worker_cache_to_strategy_canonical_row'
    base['batch_state'] = bs
    base['schema'] = 'candidate_reason_summary_text_v598_official_structure_pipe'
    return base

_v557_build_candidate_reason_summary = _v597_build_candidate_reason_summary


# v599: keep strategy->paper handoff/status fresh even when late summary/post-processing is slow.
# This is not a strategy-condition change.  It republishes the already-produced
# paper_candidates_latest into the handoff/status spine so paper/main do not keep
# reading a stale v0.132 handoff while candidate_reason has a newer compact cache.
def _v599_publish_handoff_from_latest(note: str = "cycle") -> None:
    nowv = now_ts()
    rows = read_jsonl(PAPER_LATEST, max_lines=2000)
    counts: Dict[str, int] = {"S1": 0, "S2": 0, "S3": 0}
    lane_counts: Dict[str, int] = {}
    price_ready_count = 0
    for r in rows:
        if not isinstance(r, dict):
            continue
        st = _v510_stage(r)
        counts[st] = counts.get(st, 0) + 1
        lane = str(r.get("canonical_lane") or "base")
        lane_counts[lane] = lane_counts.get(lane, 0) + 1
        if _v510_num(r.get("current_price"), r.get("entry_price"), r.get("price"), default=0.0) > 0:
            price_ready_count += 1
    obj = {
        "schema": "paper_handoff_status_v599_strategy_fresh_republish",
        "version": VERSION,
        "updated_ts": nowv,
        "updated_text": now_text(nowv),
        "latest_count": len(rows),
        "stage_counts": counts,
        "lane_counts": lane_counts,
        "price_ready_count": price_ready_count,
        "source": "paper_candidates_latest",
        "republish_note": note,
        "source_policy": "v599: candidate rows are produced by strategy_worker; this only republishes the already-produced latest rows into the handoff/status spine. No condition, grade, exit, paper or ledger change.",
    }
    save_json(HANDOFF, obj)
    # Health uses the worker status file for version/age; publish the same source age here.
    write_status(
        "running",
        phase="cycle_done_v599_handoff_republish",
        phase_note="v599 official-structure handoff freshness spine",
        strategy_worker_version=VERSION,
        main_version=MAIN_VERSION,
        deploy_version=MAIN_DEPLOY_VERSION,
        evaluated=len(rows),
        row_count=len(rows),
        s_count=len(rows),
        paper_latest_count=len(rows),
        s1_count=counts.get("S1", 0),
        s2_count=counts.get("S2", 0),
        s3_count=counts.get("S3", 0),
        target_count=0,
        priority_request_count=0,
        last_sec=0,
        status_route_schema="strategy_status_v599_handoff_fresh_republish",
    )

_v599_prev_run_once = run_once

def run_once() -> None:  # type: ignore[override]
    try:
        _v599_prev_run_once()
    finally:
        # Even if a later diagnostic/text writer regresses, do not leave the paper handoff stale.
        try:
            _v599_publish_handoff_from_latest("finally_after_live_cycle")
        except Exception as _v599_exc:
            append_error(ERROR, "v599_publish_handoff_from_latest", _v599_exc)

_v599_prev_build_candidate_reason_summary = _v557_build_candidate_reason_summary

def _v599_build_candidate_reason_summary(display_rows: List[Dict[str, Any]], counts: Dict[str,int], reason_top: Any, nowv: float) -> Dict[str,Any]:
    base = _v599_prev_build_candidate_reason_summary(display_rows, counts, reason_top, nowv)
    lines = str(base.get('summary_text') or '').split('\n')
    title = '🧭 후보판정 이유 /candidate_reason · v599 공식구조재료 fresh·handoff 배관'
    if lines and lines[0].startswith('🧭 후보판정 이유'):
        lines[0] = title
    else:
        lines.insert(0, title)
    diag = '- v599 배관: candle target 우선순위 + strategy handoff/status 최신 republish. 조건/S등급/청산 변경 없음.'
    if diag not in lines:
        insert_at = 0
        for i, line in enumerate(lines):
            if line.startswith('- v598 배관복구:'):
                insert_at = i + 1
                break
        lines.insert(insert_at if insert_at else min(3, len(lines)), diag)
    base['summary_text'] = '\n'.join(lines)
    bs = base.get('batch_state') if isinstance(base.get('batch_state'), dict) else {}
    bs['schema'] = 'candidate_reason_batch_state_v599'
    bs['handoff_fresh_republish'] = True
    base['batch_state'] = bs
    base['schema'] = 'candidate_reason_summary_text_v599_official_structure_fresh_handoff'
    return base

_v557_build_candidate_reason_summary = _v599_build_candidate_reason_summary


# =============================================================================

# =============================================================================
# strategy_worker v0.140 / v604: candidate_reason text cache + candle priority handoff clarity
# - 기본 명령은 큰 compact JSON을 파싱하지 않고 text cache만 읽는다.
# - S1/S2 캔들 fresh 요청은 clean_strategy_priority_requests에 명확히 남긴다.
# - 조건/S등급/청산/BUY_READY 변경 없음.
# =============================================================================

# strategy_worker v0.139 / v603: final_trade_state + candle fresh priority
# - 조건/S등급/청산 변경 없음.
# - candle_worker_v0.7의 실제 갱신량/age를 기본 candidate_reason에 짧게 표시한다.
# - v600에서 main() 뒤에 붙어 실행되지 않던 진단 override를 main 이전으로 고정한다.
# =============================================================================

def _v601_candle_priority_status() -> Dict[str, Any]:
    obj = load_json(CANDLE, {}) or {}
    st = load_json(BASE_DIR / "clean_candle_status.json", {}) or {}
    plan = obj.get("priority_plan") if isinstance(obj, dict) else {}
    if not isinstance(plan, dict):
        plan = {}
    counts = st.get("priority_bucket_counts") if isinstance(st, dict) else None
    if not isinstance(counts, dict):
        counts = plan.get("bucket_counts") if isinstance(plan.get("bucket_counts"), dict) else {}
    top = st.get("priority_top") if isinstance(st, dict) else None
    if not isinstance(top, list):
        top = plan.get("top") if isinstance(plan.get("top"), list) else []
    age_diag = st.get("age_diag") if isinstance(st, dict) and isinstance(st.get("age_diag"), dict) else (obj.get("age_diag") if isinstance(obj, dict) and isinstance(obj.get("age_diag"), dict) else {})
    urgent_result = st.get("urgent_result") if isinstance(st, dict) and isinstance(st.get("urgent_result"), dict) else (obj.get("urgent_result") if isinstance(obj, dict) and isinstance(obj.get("urgent_result"), dict) else (load_json(CANDLE_URGENT_RESULT, {}) or {}))
    urgent_targets = load_json(CANDLE_URGENT_TARGETS, {}) or {}
    return {
        "schema": "candle_priority_diag_v601",
        "candle_worker_version": st.get("version") if isinstance(st, dict) else None,
        "phase": st.get("phase") if isinstance(st, dict) else None,
        "status_age": round(max(0.0, now_ts() - _v510_num(st.get("updated_ts"), default=0.0)), 1) if isinstance(st, dict) and st.get("updated_ts") else None,
        "cache_age": round(max(0.0, now_ts() - _v510_num(obj.get("updated_ts"), default=0.0)), 1) if isinstance(obj, dict) and obj.get("updated_ts") else None,
        "target_count": (obj.get("target_count") if isinstance(obj, dict) else None) or plan.get("target_count"),
        "row_count": obj.get("row_count") if isinstance(obj, dict) else None,
        "updated_batch": obj.get("updated_batch") if isinstance(obj, dict) else None,
        "failed_batch": (obj.get("failed_batch") if isinstance(obj, dict) else None) or (st.get("failed_batch") if isinstance(st, dict) else None),
        "urgent_request_count": urgent_targets.get("request_count") if isinstance(urgent_targets, dict) else None,
        "urgent_bucket_counts": urgent_targets.get("bucket_counts") if isinstance(urgent_targets, dict) else {},
        "urgent_lane_counts": urgent_targets.get("lane_counts") if isinstance(urgent_targets, dict) else {},
        "urgent_result": urgent_result if isinstance(urgent_result, dict) else {},
        "bucket_counts": counts or {},
        "top": top[:8] if isinstance(top, list) else [],
        "age_diag": age_diag,
        "last_sec": st.get("last_sec") if isinstance(st, dict) else None,
        "max_workers": st.get("max_workers") if isinstance(st, dict) else None,
    }

def _v601_bucket_text(counts: Dict[str, Any], limit: int = 5) -> str:
    if not isinstance(counts, dict) or not counts:
        return "-"
    items=[]
    for k,v in counts.items():
        try: items.append((str(k), int(float(v))))
        except Exception: pass
    items.sort(key=lambda x:x[1], reverse=True)
    return " / ".join(f"{k} {v}" for k,v in items[:limit]) if items else "-"

_v601_prev_build_candidate_reason_summary = _v557_build_candidate_reason_summary

def _v601_build_candidate_reason_summary(display_rows: List[Dict[str, Any]], counts: Dict[str,int], reason_top: Any, nowv: float) -> Dict[str,Any]:
    base = _v601_prev_build_candidate_reason_summary(display_rows, counts, reason_top, nowv)
    raw_lines = [x for x in str(base.get('summary_text') or '').split('\n') if x.strip()]
    # Keep only high-value lines in the default command.  Full detail belongs to full/debug commands.
    keep_prefixes = (
        '- 기준:', '- 긴급갱신:', '- 유지이유 TOP:', '- fresh 분리:', '- 정보 위치:',
        '- 구조선 정책:', '- 공식API 구조재료:', '- v598 배관복구:', '- v599 배관:',
        '- 공식 구조재료 충분/부족:', '- 공식 candle age 평균:', '- 구조선 품질 TOP:',
        '- 구조선 위험 TOP:', '- 방아쇠 신뢰도 평균:', '- canonical 구조 TOP:', '- canonical fresh TOP:',
        '- canonical 실행위험 TOP:', '- canonical 판정 TOP:', '- rows ', '- 현재 단계:', '- S1 근접후보:',
        '- S2 현재막힘 TOP:', '- S1 필요조건 TOP:'
    )
    lines=['🧭 후보판정 이유 /candidate_reason · v610 캐시전용·정보단계캔들']
    for ln in raw_lines[1:]:
        if any(ln.startswith(p) for p in keep_prefixes):
            lines.append(ln)
    diag = _v601_candle_priority_status()
    top = diag.get('top') if isinstance(diag.get('top'), list) else []
    top_txt = ' / '.join(str(x.get('ticker')) + ':' + str(x.get('bucket')) + (f" age {x.get('age')}s" if x.get('age') is not None else '') for x in top[:4] if isinstance(x, dict) and x.get('ticker')) or '-'
    age_diag = diag.get('age_diag') if isinstance(diag.get('age_diag'), dict) else {}
    age_txt = f"avg {age_diag.get('avg')}s / <=120s {age_diag.get('under_120')} / >300s {age_diag.get('over_300')} / max {age_diag.get('max')}s" if age_diag else '-'
    block = [
        '- v610 정보단계 캔들: core는 1m/3m/5m, near는 1m/3m, watch는 1m만 우선 갱신. 조건/S등급/청산 변경 없음.',
        f"- candle worker: {diag.get('candle_worker_version') or '-'} / phase {diag.get('phase') or '-'} / cache age {diag.get('cache_age') if diag.get('cache_age') is not None else '-'}s / row {diag.get('row_count') or '-'} / target {diag.get('target_count') or '-'} / last {diag.get('last_sec') if diag.get('last_sec') is not None else '-'}s",
        f"- candle age diag: {age_txt}",
        f"- candle urgent: 요청 {diag.get('urgent_request_count') if diag.get('urgent_request_count') is not None else '-'} / 결과요청 {(diag.get('urgent_result') or {}).get('requested_count','-')} / 갱신 {(diag.get('urgent_result') or {}).get('refreshed_count','-')} / 120초이하 {(diag.get('urgent_result') or {}).get('under_target_age_count','-')} / 미회복 {(diag.get('urgent_result') or {}).get('miss_count','-')}",
        f"- candle urgent bucket TOP: {_v601_bucket_text(diag.get('urgent_bucket_counts') or {})}",
        f"- candle urgent lane: {_v601_bucket_text(diag.get('urgent_lane_counts') or {})}",
        f"- candle tier 결과: core {(diag.get('urgent_result') or {}).get('lane_result',{}).get('core','-')} / near {(diag.get('urgent_result') or {}).get('lane_result',{}).get('near','-')} / watch {(diag.get('urgent_result') or {}).get('lane_result',{}).get('watch','-')}",
        f"- candle priority bucket TOP: {_v601_bucket_text(diag.get('bucket_counts') or {})}",
        f"- candle priority top: {top_txt}",
        '- 안내: 기본판은 경량화했습니다. 후보별 긴 구조선/계산 상세는 full 계열에서만 봅니다.',
    ]
    # Place v601 block after v599 line if present, otherwise near top.
    insert_at = 4
    for i, line in enumerate(lines):
        if line.startswith('- v599 배관:'):
            insert_at = i + 1
            break
    lines[insert_at:insert_at] = block
    # hard cap to avoid command bloat in default /candidate_reason
    if len(lines) > 42:
        lines = lines[:42] + ['- … 기본판 경량화로 이하 생략. 상세는 full 계열 확인.']
    base['summary_text'] = '\n'.join(lines)
    bs = base.get('batch_state') if isinstance(base.get('batch_state'), dict) else {}
    bs['schema'] = 'candidate_reason_batch_state_v610'
    bs['candle_priority_diag'] = diag
    bs['default_summary_light'] = True
    base['batch_state'] = bs
    base['schema'] = 'candidate_reason_summary_text_v610_info_tier_candle_light'
    return base

_v557_build_candidate_reason_summary = _v601_build_candidate_reason_summary

def main() -> None:  # type: ignore[override]
    write_status("running", phase="boot_v610", evaluated=0, s_count=0, target_count=0, last_sec=0, strategy_worker_version=VERSION)
    while True:
        try:
            run_once()
        except KeyboardInterrupt:
            write_status("stopping", strategy_worker_version=VERSION)
            raise
        except Exception as exc:
            append_error(ERROR, "loop_v512", exc)
            write_status("error", error=f"{exc.__class__.__name__}: {exc}", strategy_worker_version=VERSION)
        time.sleep(max(0.5, INTERVAL_SEC))


if __name__ == "__main__":
    main()
