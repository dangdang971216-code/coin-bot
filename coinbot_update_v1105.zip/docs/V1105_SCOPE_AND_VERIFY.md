# v1105 Flow Map Truth

## Scope
Guard observability only. No Strategy, Paper, order, OPEN, exit or ledger-format change.

## Root causes fixed
1. Strategy carried a historical `MAIN_BOT_VERSION` plus its real worker `VERSION`. v1104 compared the historical Main label first, while the screen displayed the worker VERSION, creating a false mismatch.
2. Three flow edges lacked artifacts because the old map showed a nonexistent Strategy→Risk direct path and a Paper→Performance shortcut.
3. `clean_quality_shadow_state_v946.json` was written by Review but absent from the canonical owner table.
4. A historical Paper RSS peak was always promoted to CHECK even after current RSS returned low with a measured flat/falling trend.

## New evidence contract
- Main: `BOT_VERSION` → `MAIN_BOT_VERSION` → `VERSION`
- Other components: `VERSION` → `BOT_VERSION` → `MAIN_BOT_VERSION`
- Actual risk path: Paper OPEN/CLOSED → Risk cache → Strategy and Paper
- Multi-file edges preserve all required artifacts, including CLOSED + decision state for performance
- Append-only event ledgers use existence proof, not false mtime freshness
- RSS CHECK requires sustained current high use or a measured fast rise; recovered peak is INFO

## Minimum server verification
1. Guard: `/gupgrade_bundle` alone
2. Guard: `/gops_refresh`
3. Main, same message: `/flow_map` and `/errorlog`

Expected:
- Guard v2.5.158
- Strategy runtime mismatch removed when VERSION/PID/hash agree
- unknown flow edges 0
- growing UNKNOWN owner 0 for `clean_quality_shadow_state_v946.json`
- recovered Paper peak does not create an RSS error group
- auto-buy OFF; strategy and exit contracts unchanged
