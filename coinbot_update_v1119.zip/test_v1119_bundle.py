#!/usr/bin/env python3
from __future__ import annotations
import ast, copy, importlib.util, json, os, pathlib, tempfile, time

ROOT=pathlib.Path(__file__).resolve().parent
SRC=ROOT/'strategy_worker_v1.008.py'

def load_module():
    spec=importlib.util.spec_from_file_location('strategy_v1119_test',SRC)
    mod=importlib.util.module_from_spec(spec)
    assert spec and spec.loader
    spec.loader.exec_module(mod)
    return mod

def main():
    source=SRC.read_text(encoding='utf-8')
    tree=ast.parse(source)
    funcs=[n.name for n in tree.body if isinstance(n,(ast.FunctionDef,ast.AsyncFunctionDef))]
    duplicates=sorted({x for x in funcs if funcs.count(x)>1})
    assert not duplicates, duplicates
    assert funcs.count('load_json')==1 and funcs.count('save_json')==1

    m=load_module()
    assert m.VERSION=='strategy_worker_v1.008'
    assert m.BUILD_LABEL=='v1119_strategy_quality_io_owner_and_runtime_artifact_write_2026-06-29'
    assert m.V925_UNTRADABLE_SPREAD_PCT==1.2
    assert m.V925_MIN_RR==1.5
    assert m.V925_MIN_TARGET_ROOM_PCT==1.2
    assert m.V977_MAX_TRIGGER_OVERSHOOT_PCT==0.6

    with tempfile.TemporaryDirectory() as td_raw:
        td=pathlib.Path(td_raw)
        # Canonical save_json remains durable; regenerable status/queue writer does not fsync.
        fsync_calls=[]
        original_fsync=m.os.fsync
        m.os.fsync=lambda fd: fsync_calls.append(fd)
        durable=td/'durable.json'
        m.save_json(durable,{'a':1})
        assert len(fsync_calls)==1
        fsync_calls.clear()
        volatile=td/'volatile.json'
        m._v1119_save_runtime_artifact(volatile,{'b':2},'test')
        assert fsync_calls==[]
        assert json.loads(volatile.read_text(encoding='utf-8'))=={'b':2}
        m.os.fsync=original_fsync

        # File-identity cache returns the same payload and invalidates on replacement.
        assert m._v1119_load_json_identity(volatile,{})=={'b':2}
        assert m._v1119_load_json_identity(volatile,{})=={'b':2}
        time.sleep(0.002)
        volatile.write_text('{"b":3}',encoding='utf-8')
        assert m._v1119_load_json_identity(volatile,{})=={'b':3}

        # Per-file I/O evidence is cycle scoped and dormant outside explicit phase scope.
        m._v1119_io_cycle_reset(1700000000.0)
        prev=m._v1119_io_phase_enter('swing_entry_gate_v1119')
        probe=td/'probe.json'
        m.save_json(probe,{'x':1})
        assert m.load_json(probe,{})=={'x':1}
        m._v1119_io_phase_exit(prev)
        snap=m._v1119_io_snapshot()
        assert snap['total_io_calls']==2
        assert snap['phases']['swing_entry_gate_v1119']['calls']==2
        assert snap['strategy_contract_changed'] is False

        # Empty candle urgent publication preserves output contract while using a regenerable writer.
        m.CANDLE_URGENT_TARGETS=td/'targets.json'
        m.CANDLE_URGENT_RESULT=td/'result.json'
        m.CANDLE_URGENT_RESULT.write_text(json.dumps({
            'schema':'test_result','requested_count':0,'refreshed_count':0,
            'under_target_age_count':0,'miss_count':0,'rows':[]
        }),encoding='utf-8')
        urgent=m._v608_publish_candle_urgent_targets([],1700000000.0)
        assert urgent['request_count']==0
        assert json.loads(m.CANDLE_URGENT_TARGETS.read_text(encoding='utf-8'))['request_count']==0

        # Swing gate still writes durable plan state and produces the same blocked semantics for an incomplete row.
        m.V925_MINIMAL_GATE_STATE=td/'gate_state.json'
        m.V925_MINIMAL_GATE_STATUS=td/'gate_status.json'
        row={
            'ticker':'TEST','market':'KRW-TEST','current_price':100.0,'price':100.0,
            'event_id':'evt-test-1','canonical_lane':'base','strategy_key':'test',
            'stage':'S3','s_stage':'S3','open_eligible':False,
            'spread_pct':0.1,'entry_slippage_confirmed':True,
            'entry_slippage_owner':'orderflow_worker',
            'entry_slippage_source':'best_ask_reference_orderflow_v1100',
            'entry_slippage_est_pct':0.1,'price_reaction_pct':0.1,
            'relative_strength_rank':60,'money_flow_score':60,
            'buy_ratio':0.55,'buy_sustain_1m':0.5,
        }
        out,summary=m.apply_swing_entry_gate([copy.deepcopy(row)],1700000000.0)
        assert len(out)==1 and summary['swing_gate_rows_v979']==1
        assert out[0]['open_eligible'] is False
        assert m.V925_MINIMAL_GATE_STATE.exists() and m.V925_MINIMAL_GATE_STATUS.exists()

    required_phases={
        'quality_priority_requests_v1119','swing_entry_gate_v1119',
        'publish_candle_urgent_after_final_gate_v1049','seal_exact_keys_v1119'
    }
    assert required_phases.issubset(set(source.split("'")))
    assert "quality_gate_io_profile_v1119" in source
    assert "open_limit_changed':False" in source
    print(json.dumps({'status':'PASS','version':m.VERSION,'duplicates':duplicates},ensure_ascii=False))

if __name__=='__main__':
    main()
