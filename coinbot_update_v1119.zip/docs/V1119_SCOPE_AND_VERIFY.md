# v1119 범위와 검수

## 실제 원인
v1118 서버 결과에서 Strategy cycle 38.212초, 기존 `quality_gate_and_exact_keys` wall 10.661초가 관측됐지만 품질요청·Gate 계산·runtime 파일 저장·exact key 중 어느 경로가 대기시간을 만들었는지 분리되지 않았다.

## 수정
- 기존 aggregate를 네 direct phase로 분리한다.
- final quality 구간에서만 canonical JSON I/O 시간을 path별로 측정한다.
- 내구성이 필요한 `swing_gate_plan_state`는 기존 fsync를 유지한다.
- 재생성 가능한 `swing_gate_status`, `candle_urgent_targets`만 atomic replace/no-fsync로 기록한다.
- candle urgent result는 파일 identity가 같을 때 파싱 결과를 재사용한다.

## 변경하지 않음
품질 threshold, 품질 rank 산식, trigger, invalid, target, RR, spread/slippage 계약, OPEN 30, cycle 3, exit, 자동매수 OFF.

## 서버 검수
`/flow_map`에서 Strategy v1.008, 4개 direct phase, file I/O evidence, cycle 시간을 확인한다. 20초를 넘으면 가장 큰 phase와 path를 다음 한 owner 수술 대상으로 사용한다.
