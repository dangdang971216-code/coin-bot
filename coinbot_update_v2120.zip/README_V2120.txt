v2120 restores the final direct service entrypoint in Strategy, Review and Paper. No strategy, candidate, OPEN/CLOSED or exit logic changed. Auto-buy OFF.
