v1342 fixes v1341 paper deployment CHECK.
Cause: paper_bot_v1.109.py had VERSION/BUILD_LABEL reassigned after main() entry, so Guard could not prove exact runtime identity.
Fix: paper_bot_v1.110.py normalizes all VERSION/BUILD_LABEL assignments before runtime.
No strategy, candidate, entry, exit, or auto-buy change.
