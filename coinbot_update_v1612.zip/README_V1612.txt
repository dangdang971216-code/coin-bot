v1612 runtime entrypoint/order fix for root timing trace. No trading-rule changes. Auto-buy OFF.
