v2177 repairs only the failed v2176 deployment path. Unchanged support components are excluded from the update ZIP. No strategy, candidate-quality, entry, exit or ledger rewrite. Auto-buy OFF.
