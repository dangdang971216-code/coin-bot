#!/usr/bin/env python3
from __future__ import annotations
import ast, hashlib, importlib.util, json, os, shutil, subprocess, sys, tempfile, time
from pathlib import Path

ROOT=Path('/mnt/data/v2395_work')
BASE=Path('/mnt/data/v2393_work')
FILES={
 'core':ROOT/'strategy_v2_core_v2200.py',
 'strategy':ROOT/'strategy_worker_v2.114.py',
 'review':ROOT/'review_worker_v2.164.py',
 'main':ROOT/'coinbot_main_v2_13_2240.py',
}
BUILD='official_1h_4h_24h_role_mainline_and_replay_2026-08-02'

def load(name,path):
    spec=importlib.util.spec_from_file_location(name,path)
    mod=importlib.util.module_from_spec(spec); spec.loader.exec_module(mod); return mod

def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

def candles(now,interval,n,start,growth,vol_growth=0.01):
    rows=[]; price=float(start)
    for i in range(n):
        ts=now-(n-i)*interval; op=price; close=price*(1.0+growth)
        rows.append({'ts':float(ts),'o':op,'c':close,'h':max(op,close)*1.005,'l':min(op,close)*0.995,'v':1000.0*(1.0+vol_growth*i)})
        price=close
    return rows

def main():
    results=[]
    # Compile + AST.
    for label,path in FILES.items():
        subprocess.run([sys.executable,'-m','py_compile',str(path)],check=True)
        ast.parse(path.read_text(encoding='utf-8'))
        results.append(f'{label}:COMPILE_AST_PASS')

    core=load('core_v2395_test',FILES['core'])
    assert core.VERSION=='strategy_v2_core_v2200' and core.BUILD_LABEL==BUILD
    assert core.TIMEFRAME_ROLE_CONTRACT_ID=='PRE_STRUCTURE_1H_4H_24H'
    now=1700000000.0
    up={'h1':candles(now,3600,50,100,.003,.02),'h4':candles(now,14400,40,80,.008,.03),'d1':candles(now,86400,30,50,.015,.02)}
    btc={'h1':candles(now,3600,50,100,.001,.01),'h4':candles(now,14400,40,80,.003,.01),'d1':candles(now,86400,30,50,.005,.01)}
    m30=candles(now,1800,80,100,.001,.01)
    role=core.build_timeframe_role_input_from_frames('TEST',up,btc,{},now,current_price=up['h1'][-1]['c'],source_mode='HISTORICAL_COMPLETED')
    ev=core.evaluate_timeframe_role_input(role)
    assert ev['decision']=='UP' and role['synthetic_3h_6h_candles_used'] is False
    assert set(role['axis_source_state'])=={'h1','h4','d1'}
    results.append('core:OFFICIAL_1H_4H_24H_UP_PASS')

    # Direction correction: restart helps timing; chase/exhaustion hurts timing.
    restart=core.build_timeframe_role_input_from_frames('TEST',up,btc,{'_sealed_prediction_payload':{'explanation_tags':['RESTART'],'price_volume_sequence':{'state':'VOLUME_LEADS'}}},now,current_price=up['h1'][-1]['c'],source_mode='HISTORICAL_COMPLETED')
    chase=core.build_timeframe_role_input_from_frames('TEST',up,btc,{'_sealed_prediction_payload':{'explanation_tags':['CHASE','EXHAUSTION'],'price_volume_sequence':{'state':'PRICE_LEADS'}}},now,current_price=up['h1'][-1]['c'],source_mode='HISTORICAL_COMPLETED')
    restart_ev=core.evaluate_timeframe_role_input(restart); chase_ev=core.evaluate_timeframe_role_input(chase)
    assert restart_ev['probability_1h_timing']>ev['probability_1h_timing']>chase_ev['probability_1h_timing']
    assert chase_ev['decision']!='UP'
    results.append('core:RESTART_VS_CHASE_DIRECTION_PASS')

    # Explicit decision contract checks.
    def manual(p1,p4,p24,states=None):
        return core.evaluate_timeframe_role_input({'axes':{'1h_timing':{'probability_pct':p1},'4h_structure':{'probability_pct':p4},'24h_context':{'probability_pct':p24}},'axis_source_state':states or {'h1':'READY','h4':'READY','d1':'READY'}})
    assert manual(40,40,80)['decision']=='DOWN'
    assert manual(55,55,35)['decision']=='HOLD' and manual(55,55,35)['reason']=='D1_LARGE_DIRECTION_CONFLICT'
    assert manual(45,60,70)['decision']=='HOLD'
    assert manual(60,60,60,{'h1':'READY','h4':'READY','d1':'MISSING'})['decision']=='HOLD'
    results.append('core:DOWN_HOLD_CONFLICT_SOURCE_MISSING_PASS')

    # Full Strategy payload integration.
    row={'ticker':'TEST','current_price':m30[-1]['c'],'prediction_benchmark_frames':btc,'prediction_benchmark_frame_truth':{},'prediction_candle_frame_truth':{},'global_market_context_v2130':{'state':'RISK_NORMAL','updated_ts':now,'breadth_velocity_pct_v2130':1.0}}
    payload=core.build_rise_prediction_input(row,{'m30':m30,**up},{},now)
    assert payload['prediction_contract_id']=='PRE_STRUCTURE_1H_4H_24H'
    assert payload['probability_3h'] is None and payload['probability_6h'] is None
    assert payload['primary_selection']['decision']=='UP'
    results.append('core:FULL_PAYLOAD_NO_3H_6H_CANDLE_ROLE_PASS')

    # Strategy Worker runtime summary in isolated base.
    tmp=Path(tempfile.mkdtemp(prefix='v2395_strategy_test_'))
    try:
        shutil.copy2(FILES['core'],tmp/'strategy_v2_core.py')
        env=dict(os.environ); env['TRADING_BOT_DIR']=str(tmp)
        code=f"""
import importlib.util,json,time
p={str(FILES['strategy'])!r}
spec=importlib.util.spec_from_file_location('s',p); m=importlib.util.module_from_spec(spec); spec.loader.exec_module(m)
payload={{'state':'READY','input_coverage_pct':100,'usable_input_coverage_pct':100,'event_key':'A','episode_id':'E','probability_1h_timing':55,'probability_4h_structure':60,'probability_24h_context':52,'combined_probability_pct':57,'prediction_confidence_state':'HIGH','prediction_model_id':'OFFICIAL_1H_TIMING_4H_STRUCTURE_24H_CONTEXT_V1','output_states':{{'1h_timing':'READY','4h_structure':'READY','24h_context':'READY'}},'timeframe_role_evaluation':{{'axis_states':{{'1h_timing':'READY','4h_structure':'UP_STRUCTURE','24h_context':'SUPPORTIVE'}}}},'materials':{{}},'explanation_tags':[],'price_volume_sequence':{{'state':'UNKNOWN'}}}}
row={{'ticker':'TEST','s_stage':'S3','trade_path_contract_v2149':{{'state':'READY','decision_combiner':{{'entry_eligible':True}},'structure':{{'state':'READY'}},'prediction':{{'rise_prediction_input':payload}},'prediction_selection':{{'decision':'UP'}}}}}}
r=m._v2176_decision_summary([row],time.time())
assert m.VERSION=='strategy_worker_v2.114' and m.BUILD_LABEL=={BUILD!r}
assert r['rise_prediction']['decision_axes']==['1h_timing','4h_structure','24h_context']
assert r['rise_prediction']['elapsed_horizons_are_result_checks_only'] is True
assert 'predicted_direction_3h_counts' not in r['rise_prediction']
assert r['rise_prediction']['weights_applied'] is True and r['rise_prediction']['thresholds_applied'] is True
print('PASS')
"""
        out=subprocess.check_output([sys.executable,'-c',code],env=env,text=True).strip()
        assert out.endswith('PASS')
    finally:
        shutil.rmtree(tmp,ignore_errors=True)
    results.append('strategy:SUMMARY_RUNTIME_PASS')

    # Review historical replay: same Core function, old event untouched, future candle excluded.
    review=load('review_v2395_test',FILES['review'])
    tmp=Path(tempfile.mkdtemp(prefix='v2395_review_test_'))
    try:
        shutil.copy2(FILES['core'],tmp/'strategy_v2_core.py')
        review.BASE_DIR=tmp
        key='TEST:EVENT'
        original_event={'event_key':key,'event_ts':now,'ticker':'TEST','event_price':up['h1'][-1]['c'],'prediction_contract_id':'PRE_STRUCTURE_12','prediction_selection':'DOWN','materials':{},'explanation_tags':['RESTART'],'price_volume_sequence':{'state':'VOLUME_LEADS'}}
        review._EVENTS={key:json.loads(json.dumps(original_event))}; review._OUTCOME_ROWS={}
        for horizon,_ in review.HORIZONS:
            review._OUTCOME_ROWS[(key,horizon)]={'event_key':key,'horizon':horizon,'outcome_state':'READY','actual_direction':'UP','final_return_pct':1.0,'scored_net_return_pct':0.7,'mfe_pct':2.0,'mae_pct':-0.5,'giveback_pct':0.3}
        future=dict(up['h1'][-1]); future['ts']=now+3600; future['c']=1.0; future['o']=1.0; future['h']=1.1; future['l']=0.9
        idx={'TEST':{**up,'h1':up['h1']+[future]},'BTC':btc}
        shadow=review.build_timeframe_role_shadow(idx)
        assert shadow['state']=='READY' and shadow['evaluated_event_count']==1
        assert shadow['future_candle_used'] is False and shadow['synthetic_3h_6h_candle_used'] is False
        assert shadow['historical_event_rows_rewritten'] is False and shadow['historical_outcome_rows_rewritten'] is False
        assert review._EVENTS[key]==original_event
        assert shadow['horizons']['3h']['missed_rise_recovery_pct']==100.0
        assert shadow['horizons']['3h']['new_selected_metrics']['avg_scored_net_return_pct']==0.7
    finally:
        shutil.rmtree(tmp,ignore_errors=True)
    results.append('review:SHADOW_REPLAY_IMMUTABLE_NO_FUTURE_PASS')

    # Review run_once in an isolated runtime proves canonical schema is executable.
    tmp=Path(tempfile.mkdtemp(prefix='v2395_review_runtime_'))
    try:
        shutil.copy2(FILES['core'],tmp/'strategy_v2_core.py')
        env=dict(os.environ); env['TRADING_BOT_DIR']=str(tmp)
        code=f"""
import importlib.util
p={str(FILES['review'])!r}
spec=importlib.util.spec_from_file_location('r',p); m=importlib.util.module_from_spec(spec); spec.loader.exec_module(m)
s=m.run_once(); c=s['rise_prediction_canonical']
assert s['version']=='review_worker_v2.164' and s['build']=={BUILD!r}
assert c['current_prediction_contract_id']=='PRE_STRUCTURE_1H_4H_24H'
assert c['decision_axes']==['1h_timing','4h_structure','24h_context']
assert c['elapsed_horizons_are_result_checks_only'] is True
assert c['timeframe_role_shadow']['state']=='NO_BASELINE_EVENTS'
assert c['live_prediction_model_id']=='OFFICIAL_1H_TIMING_4H_STRUCTURE_24H_CONTEXT_V1'
print('PASS')
"""
        out=subprocess.check_output([sys.executable,'-c',code],env=env,text=True).strip(); assert out.endswith('PASS')
    finally:
        shutil.rmtree(tmp,ignore_errors=True)
    results.append('review:RUN_ONCE_CANONICAL_PASS')

    # Main display + module-load ledger seed contract in an isolated directory.
    tmp=Path(tempfile.mkdtemp(prefix='v2395_main_test_'))
    try:
        main_copy=tmp/FILES['main'].name; shutil.copy2(FILES['main'],main_copy)
        mainmod=load('main_v2395_test',main_copy)
        assert mainmod.MAIN_VERSION=='수익형 v2.13.2240' and mainmod.BUILD==BUILD
        synthetic={'timeframe_role_shadow':shadow,'live_prediction_model_id':'OFFICIAL_1H_TIMING_4H_STRUCTURE_24H_CONTEXT_V1','current_prediction_contract_directional_scoring':{}}
        text='\n'.join(mainmod._shadow_replay_lines(synthetic)+mainmod._timeframe_role_live_lines({'probability_summary':{'probability_1h_timing':{'count':1,'average_pct':55,'min_pct':55,'max_pct':55},'probability_4h_structure':{'count':1,'average_pct':60,'min_pct':60,'max_pct':60},'probability_24h_context':{'count':1,'average_pct':52,'min_pct':52,'max_pct':52},'combined_probability_pct':{'count':1,'average_pct':57,'min_pct':57,'max_pct':57}}}))
        for token in ('빗썸 공식 완료봉','과거자료 즉시 대입 Shadow','정답훼손','놓침복구','합성 3h/6h봉 0'):
            assert token in text
        assert (tmp/'runtime'/'main_official_timeframe_role_v2395.seeded').exists()
        change_text=(tmp/'ledger'/'change_verify_ledger_events.jsonl').read_text(encoding='utf-8')
        assert '공식 1h·4h·24h 본선과 과거자료 Shadow 표시' in change_text
    finally:
        shutil.rmtree(tmp,ignore_errors=True)
    main_source=FILES['main'].read_text(encoding='utf-8')
    assert '3시간 상승확률' not in main_source and '6시간 상승확률' not in main_source
    results.append('main:DISPLAY_AND_LEDGER_SEED_PASS')

    # Untouched services / active aliases from v2393 basis.
    for name in ('candle_worker.py','paper_bot.py','backga_guard_bot.py'):
        assert (ROOT/name).exists() and (BASE/name).exists()
        assert sha(ROOT/name)==sha(BASE/name), name
    results.append('unchanged:CANDLE_PAPER_GUARD_HASH_PASS')

    print('\n'.join(results))
    print('ALL_LOCAL_TESTS_PASS')

if __name__=='__main__': main()
