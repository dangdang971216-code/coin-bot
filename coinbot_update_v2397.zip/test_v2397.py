#!/usr/bin/env python3
from __future__ import annotations
import ast, hashlib, importlib.util, os, shutil, subprocess, sys, tempfile
from pathlib import Path
ROOT=Path('/tmp/v2397_work')
BASE=Path('/tmp/v2396')
REVIEW=ROOT/'review_worker_v2.166.py'
MAIN=ROOT/'coinbot_main_v2_13_2242.py'
CORE=ROOT/'strategy_v2_core_v2200.py'
BUILD='fair_shadow_layers_and_same_decision_contract_compare_2026-08-02'

def load(name,path):
    spec=importlib.util.spec_from_file_location(name,path)
    mod=importlib.util.module_from_spec(spec); spec.loader.exec_module(mod); return mod

def sha(p): return hashlib.sha256(p.read_bytes()).hexdigest()

def candles(event_ts,interval,n,start,growth):
    rows=[]
    for i in range(n):
        c=start+growth*i
        rows.append({'ts':event_ts-interval*(n-i+1),'o':c-.2,'h':c+.8,'l':c-.8,'c':c,'v':1000+i*10})
    return rows

for p in (REVIEW,MAIN):
    subprocess.run([sys.executable,'-m','py_compile',str(p)],check=True)
    ast.parse(p.read_text(encoding='utf-8'))

# Isolated Review import and answer layers
work=Path(tempfile.mkdtemp(prefix='v2397_review_'))
try:
    shutil.copy2(CORE,work/'strategy_v2_core.py')
    os.environ['TRADING_BOT_DIR']=str(work)
    r=load('review_v2397',REVIEW)
    assert r.VERSION=='review_worker_v2.166' and r.BUILD_LABEL==BUILD
    target={'event_key':'a','horizon':'3h','outcome_state':'READY','mfe_pct':2.0,'mae_pct':-.4,'giveback_pct':.5,'final_return_pct':1.5,'scoring_cost_pct':.2,'scored_net_return_pct':1.3,'target_first':True,'invalid_first':False,'touch_order':'TARGET_FIRST'}
    invalid={'event_key':'b','horizon':'3h','outcome_state':'READY','mfe_pct':1.0,'mae_pct':-2.0,'giveback_pct':1.4,'final_return_pct':-.4,'scoring_cost_pct':.2,'scored_net_return_pct':-.6,'target_first':False,'invalid_first':True,'touch_order':'INVALID_FIRST'}
    bounce={'event_key':'c','horizon':'3h','outcome_state':'READY','mfe_pct':.5,'mae_pct':-.3,'giveback_pct':.7,'final_return_pct':-.2,'scoring_cost_pct':.2,'scored_net_return_pct':-.4,'target_first':False,'invalid_first':False,'touch_order':'NO_TOUCH'}
    profitable={'event_key':'d','horizon':'3h','outcome_state':'READY','mfe_pct':.8,'mae_pct':-.1,'giveback_pct':.2,'final_return_pct':.6,'scoring_cost_pct':.2,'scored_net_return_pct':.4,'target_first':False,'invalid_first':False,'touch_order':'NO_TOUCH'}
    assert r._shadow_answer_from_outcome(target)['contract_success'] is True
    assert r._shadow_answer_from_outcome(invalid)['contract_success'] is False
    assert r._shadow_answer_from_outcome(bounce)['answer_class']=='INTRAPATH_OPPORTUNITY_ONLY'
    assert r._shadow_answer_from_outcome(profitable)['answer_class']=='PROFITABLE_FINISH_NO_TOUCH'
    # HOLD is not damage: prior correct UP moving HOLD is reported separately.
    met=r._binary_decision_metrics([('UP','HOLD',True),('DOWN','UP',True),('UP','DOWN',False),('HOLD','UP',False)])
    assert met['hold_counted_as_damage'] is False
    assert met['prior_correct_up_movement']['new_hold']==1
    assert met['prior_missed_positive_movement']['new_up']==1
    assert met['prior_false_up_movement']['new_down']==1
    assert met['new_false_up_from_prior_non_up_count']==1

    # Replay with exact same event layer. Fake core yields deterministic UP/HOLD/DOWN.
    class FakeCore:
        TIMEFRAME_ROLE_FORMULA_ID='FAKE'
        @staticmethod
        def build_timeframe_role_input_from_frames(symbol,*args,**kwargs): return {'symbol':symbol}
        @staticmethod
        def evaluate_timeframe_role_input(inp): return {'decision':{'AAA':'HOLD','BBB':'UP','CCC':'DOWN','DDD':'UP'}[inp['symbol']],'source_missing_axes':[]}
    r._load_active_strategy_core=lambda:FakeCore
    ts=2_000_000.0
    r._EVENTS={
      'a':{'event_key':'a','prediction_contract_id':'PRE_STRUCTURE_12','prediction_selection':'UP','event_ts':ts,'event_price':100,'ticker':'AAA','materials':{}},
      'b':{'event_key':'b','prediction_contract_id':'PRE_STRUCTURE_12','prediction_selection':'DOWN','event_ts':ts,'event_price':100,'ticker':'BBB','materials':{}},
      'c':{'event_key':'c','prediction_contract_id':'PRE_STRUCTURE_12','prediction_selection':'UP','event_ts':ts,'event_price':100,'ticker':'CCC','materials':{}},
      'd':{'event_key':'d','prediction_contract_id':'PRE_STRUCTURE_12','prediction_selection':'HOLD','event_ts':ts,'event_price':100,'ticker':'DDD','materials':{}},
    }
    r._OUTCOME_ROWS={('a','3h'):target,('b','3h'):{**target,'event_key':'b'},('c','3h'):invalid,('d','3h'):{**invalid,'event_key':'d'}}
    idx={s:{'h1':candles(ts,3600,20,100,.2),'h4':candles(ts,14400,12,100,.2),'d1':candles(ts,86400,10,100,.2)} for s in ('AAA','BBB','CCC','DDD','BTC')}
    comp=r.build_timeframe_role_replay_comparison(idx)
    assert comp['same_decision_layer'] is True and comp['hold_counted_as_damage'] is False
    strict=comp['horizons']['3h']['answer_layers']['contract_target_first']
    assert strict['prior_correct_up_movement']['new_hold']==1
    assert strict['prior_missed_positive_movement']['new_up']==1
    assert strict['prior_false_up_movement']['new_down']==1
    assert strict['new_false_up_from_prior_non_up_count']==1
    r._OUTCOME_ROWS={('a','3h'):target,('b','3h'):invalid,('c','3h'):bounce,('d','3h'):profitable}
    sheet=r.build_shadow_answer_sheet()
    h=sheet['horizons']['3h']
    assert h['contract_resolved_count']==2 and h['target_first_count']==1 and h['invalid_first_count']==1
    assert h['profitable_finish_count']==2 and h['cost_clearing_opportunity_count']==4
finally:
    os.environ.pop('TRADING_BOT_DIR',None); shutil.rmtree(work,ignore_errors=True)

# Main rendering
work=Path(tempfile.mkdtemp(prefix='v2397_main_'))
try:
    shutil.copy2(MAIN,work/MAIN.name)
    m=load('main_v2397',work/MAIN.name)
    assert m.MAIN_VERSION=='수익형 v2.13.2242' and m.BUILD==BUILD
    canonical={'shadow_answer_sheet':sheet,'timeframe_role_replay_comparison':comp,'current_prediction_contract_directional_scoring':{},'live_prediction_model_id':'OFFICIAL_1H_TIMING_4H_STRUCTURE_24H_CONTEXT_V1'}
    text='\n'.join(m._shadow_answer_sheet_lines(canonical)+['']+m._mainline_replay_compare_lines(canonical))
    for token in ('실제 결과 3단계 고정','같은 판정층 공정 비교','HOLD를 훼손 처리 0','기존 맞은 UP 이동','target우선 표본'):
        assert token in text, token
    assert '기존 정답훼손' not in text
finally:
    shutil.rmtree(work,ignore_errors=True)

# Only Review/Main active source changed.
for name in ('strategy_v2_core_v2200.py','strategy_worker_v2.114.py','candle_worker_v2.031.py','paper_bot_v2.142.py','backga_guard_bot_v2_6_104.py'):
    if (ROOT/name).exists() and (BASE/name).exists(): assert sha(ROOT/name)==sha(BASE/name),name
print('ALL_LOCAL_TESTS_PASS')
