v2161
- v2160 계산식은 바꾸지 않습니다.
- Main만 최신이고 Strategy가 FULL_INPUT_V2159였던 PARTIAL 적용을 수리합니다.
- 고유 worker v2.059와 core v2161을 실제 실행하고 기존 /version_score에서 exact 일치 시에만 DONE으로 표시합니다.
- 기존 OPEN/CLOSED·청산계약·Paper 공식·Trigger/예측 수치 변경 없음. 자동매수 OFF.
