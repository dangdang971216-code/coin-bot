v2112는 v2111 NameError, 현재 cycle/S1 건수 혼합, Paper funnel owner 상태, 폐기한 개발용 연결·전략별 후보품질·final-rank 활성 출력을 함께 수리한다. 진입·청산 공식과 기존 Shadow 자료·원장은 변경하지 않는다. 서버 검증 전 CHECK이며 자동매수는 OFF다.
