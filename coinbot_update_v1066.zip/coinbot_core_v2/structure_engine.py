from __future__ import annotations
from typing import Any,Dict,List,Optional,Tuple
from .common import num,text,pct,unique,ticker

MAJOR=(('h4','4h'),('h2','2h'))
SETUP=(('h1','1h'),('m30','30m'))
EXEC=(('m15','15m'),('m5','5m'))

def _line(row:Dict[str,Any],pref:str,names:Tuple[str,...])->Tuple[float,str]:
    for name in names:
        for key in (f'{pref}_{name}',name if not pref else ''):
            if not key: continue
            value=num(row.get(key),default=0.0) or 0.0
            if value>0: return value,key
    return 0.0,''

def _collect(row:Dict[str,Any],price:float,role:str)->Dict[str,Any]:
    if role=='major': tfs=MAJOR; sup=('major_support_price','box_low_price','swing_low_price','recent_low_price'); res=('major_resistance_price','box_high_price','swing_high_price','recent_high_price')
    elif role=='setup': tfs=SETUP; sup=('setup_support_price','box_low_price','swing_low_price','recent_low_price'); res=('setup_resistance_price','box_high_price','swing_high_price','recent_high_price')
    else: tfs=EXEC; sup=('execution_low_price','recent_low_price','swing_low_price'); res=('execution_high_price','recent_high_price','swing_high_price')
    supports=[]; resistances=[]; bad=[]
    for pref,tf in tfs:
        sp,sk=_line(row,pref,sup); rp,rk=_line(row,pref,res)
        if sp>0:
            item={'role':role,'side':'support','price':sp,'tf':tf,'source_key':sk,'source':f'{role}_support:{tf}:{sk}','gap_pct':pct(sp,price)}
            (bad if price and (abs(item['gap_pct'])>80 or sp>price*1.0008) else supports).append(item)
        if rp>0:
            item={'role':role,'side':'resistance','price':rp,'tf':tf,'source_key':rk,'source':f'{role}_resistance:{tf}:{rk}','gap_pct':pct(rp,price)}
            (bad if price and (abs(item['gap_pct'])>80 or rp<price*.9992) else resistances).append(item)
    support=max(supports,key=lambda x:x['price']) if supports else {}
    resistance=min(resistances,key=lambda x:x['price']) if resistances else {}
    return {'support':support,'resistance':resistance,'bad':bad,'support_candidates':supports[:8],'resistance_candidates':resistances[:8]}

def build_context(row:Dict[str,Any])->Dict[str,Any]:
    existing=row.get('structure_context_v871') if isinstance(row.get('structure_context_v871'),dict) else {}
    if existing and all(k in existing for k in ('major_ready','setup_ready','execution_ready')):
        return dict(existing)
    price=num(row.get('current_price'),row.get('live_price'),row.get('trade_price'),row.get('price'),row.get('close'),default=0.0) or 0.0
    major=_collect(row,price,'major'); setup=_collect(row,price,'setup'); execution=_collect(row,price,'execution')
    trigger=num(row.get('trigger_price'),row.get('entry_trigger_price'),row.get('m5_execution_high_price'),row.get('m15_execution_high_price'),(execution.get('resistance') or {}).get('price'),default=0.0) or 0.0
    exec_obj=(execution.get('resistance') or {})
    exec_trigger={'role':'execution','side':'trigger','price':trigger,'tf':exec_obj.get('tf') or '5m','source_key':exec_obj.get('source_key') or 'derived_execution_resistance','source':'execution_trigger:core_v2','gap_pct':pct(trigger,price)} if trigger>0 else {}
    mismatch=(major['bad']+setup['bad']+execution['bad'])[:8]
    return {
        'schema':'structure_context_v1066','current_price':price or None,
        'major_support':major['support'],'major_resistance':major['resistance'],
        'setup_support':setup['support'],'setup_resistance':setup['resistance'],
        'execution_support':execution['support'],'execution_resistance':execution['resistance'],'execution_trigger':exec_trigger,
        'major_ready':bool(major['support'] or major['resistance']),'setup_ready':bool(setup['support'] or setup['resistance']),'execution_ready':bool(exec_trigger or execution['support'] or execution['resistance']),
        'source_missing':not bool((major['support'] or major['resistance']) and (setup['support'] or setup['resistance']) and (exec_trigger or execution['support'] or execution['resistance'])),
        'role_mismatch_samples':mismatch,'strategy_is_tag_only':True,'strategy_label_role':'descriptive_result_tag_only_not_entry_blocker',
    }

def build_plan(row:Dict[str,Any],ctx:Dict[str,Any])->Dict[str,Any]:
    price=num(ctx.get('current_price'),row.get('current_price'),row.get('price'),default=0.0) or 0.0
    trigger=dict(ctx.get('execution_trigger') or ctx.get('execution_resistance') or {})
    tp=num(trigger.get('price'),trigger.get('rounded_price'),trigger.get('raw_price'),default=0.0) or 0.0
    ceiling=min(price,tp) if price>0 and tp>0 else tp
    invalids=[x for x in (ctx.get('setup_support'),ctx.get('major_support')) if isinstance(x,dict) and 0<(num(x.get('price'),default=0.0) or 0.0)<ceiling]
    invalid=max(invalids,key=lambda x:num(x.get('price'),default=0.0) or 0.0) if invalids else {}
    targets=[x for x in (ctx.get('major_resistance'),ctx.get('setup_resistance')) if isinstance(x,dict) and (num(x.get('price'),default=0.0) or 0.0)>tp*1.000001]
    target=targets[0] if targets else {}
    ip=num(invalid.get('price'),default=0.0) or 0.0; xp=num(target.get('price'),default=0.0) or 0.0
    risk=max(0.0,tp-ip); reward=max(0.0,xp-tp); rr=reward/risk if risk>0 else 0.0; room=reward/tp*100 if tp>0 else 0.0
    return {'schema':'alt_swing_actual_structure_plan_v1066','strategy_mode':'ALT_SWING_V977','timeframe_contract':{'major':'4h/2h','setup':'1h/30m','entry':'15m/5m','execution':'1m/quote'},'current_price':price or None,'trigger':trigger,'invalid':invalid,'target':target,'risk_reward':rr,'target_room_pct':room,'source_context_schema':ctx.get('schema')}
