from __future__ import annotations
from typing import Any,Dict,Tuple,List
from .common import num,text,pct,ticker
from .config import RuntimeConfig,STRATEGY_MODE

def best_price(row:Dict[str,Any])->Tuple[float,str]:
    for key,source in (
        ('best_ask','best_ask'),('ask_price','best_ask'),('quote_ask','best_ask'),('micro_best_ask','best_ask'),
        ('quote_price','quote'),('current_price','current'),('trade_price','trade'),('price','price'),('close','close'),
    ):
        value=num(row.get(key),default=0.0) or 0.0
        if value>0: return value,source
    return 0.0,'missing'

def actual_rr(entry:float,invalid:float,target:float)->float|None:
    if not (entry>0 and invalid>0 and target>entry and invalid<entry): return None
    risk=entry-invalid
    return (target-entry)/risk if risk>0 else None

def evaluate(row:Dict[str,Any],cfg:RuntimeConfig)->Dict[str,Any]:
    gate=row.get('swing_entry_gate_v977') if isinstance(row.get('swing_entry_gate_v977'),dict) else {}
    entry,entry_source=best_price(row)
    trigger=num(gate.get('trigger_price'),row.get('swing_trigger_price_v977'),row.get('trigger_price'),default=0.0) or 0.0
    invalid=num(gate.get('invalid_price'),row.get('swing_invalid_price_v977'),row.get('invalid_price'),default=0.0) or 0.0
    target=num(gate.get('target_price'),row.get('swing_target_price_v977'),row.get('target_price'),default=0.0) or 0.0
    rr=actual_rr(entry,invalid,target)
    spread=num(row.get('spread_pct'),row.get('micro_spread_pct'),row.get('orderbook_spread_pct'),default=-1.0)
    slip=num(row.get('paper_slippage_pct'),row.get('confirmed_slippage_pct_v925'),row.get('slippage_pct_confirmed'),default=None)
    slip_source=text(row.get('paper_slippage_source'),row.get('confirmed_slippage_source_v925'),row.get('slippage_pct_source')) or 'missing'
    chase=pct(entry,trigger) if entry and trigger else 0.0
    reasons:List[str]=[]
    if gate.get('schema')!='swing_entry_gate_v977_single_owner': reasons.append('ALT_SWING 진입판 형식 불일치')
    mode=text(row.get('strategy_mode'),gate.get('strategy_mode')).upper()
    if mode!=STRATEGY_MODE: reasons.append('ALT_SWING 전략모드 불일치')
    if gate.get('hard_pass') is not True or text(gate.get('final_trade_state'))!='S1_PASS': reasons.append('전략 진입조건 미통과')
    if not text(gate.get('decision_key'),row.get('swing_gate_decision_key_v977')): reasons.append('전략 판정번호 누락')
    if num(gate.get('risk_reward'),default=0.0)<cfg.thresholds.min_rr: reasons.append('손익비 부족')
    if num(gate.get('target_room_pct'),default=0.0)<cfg.thresholds.min_target_room_pct: reasons.append('목표 공간 부족')
    if gate.get('source_fresh') is not True: reasons.append('전략 봉인 자료 최신성 부족')
    if entry<=0: reasons.append('OPEN 직전 진입 예정가 누락')
    if not bool(gate.get('trigger_reached')): reasons.append('봉인 방아쇠 미도달')
    elif chase>cfg.thresholds.max_trigger_chase_pct: reasons.append(f'trigger 추격 초과 {chase:.3f}%')
    if spread is None or spread<0: reasons.append('OPEN 직전 스프레드 자료 없음')
    elif spread>cfg.thresholds.max_spread_pct: reasons.append(f'거래불가 스프레드 {spread:.3f}%')
    if slip is not None and slip>cfg.thresholds.max_spread_pct: reasons.append(f'확정 미끄러짐 과다 {slip:.3f}%')
    # Parity mode faithfully mirrors v1059: actual entry RR is recorded but not a hard block.
    actual_rr_blocked=bool((not cfg.parity_mode) and rr is not None and rr<cfg.thresholds.min_rr)
    if actual_rr_blocked: reasons.append(f'실제 진입가 RR 미달 {rr:.3f}')
    return {
      'schema':'execution_decision_v1066','ticker':ticker(row.get('ticker')),'entry_price':entry or None,'entry_price_source':entry_source,
      'trigger_price':trigger or None,'invalid_price':invalid or None,'target_price':target or None,'actual_entry_rr_v1034':rr,
      'spread_pct':spread if spread is not None and spread>=0 else None,'confirmed_slippage_pct':slip,'confirmed_slippage_source':slip_source,
      'trigger_chase_pct':chase,'parity_mode':cfg.parity_mode,'actual_rr_hard_block_enabled':not cfg.parity_mode,
      'allowed':not reasons,'reasons':reasons,'auto_buy':False,
    }
