from __future__ import annotations
from dataclasses import dataclass
from pathlib import Path
import os

VERSION = "core_v2_v1066"
BUILD = "v1066_full_core_single_spine_2026-06-26"
STRATEGY_MODE = "ALT_SWING_V977"
AUTO_BUY = False

@dataclass(frozen=True)
class Paths:
    base: Path
    scanner_market: Path
    scanner_pool: Path
    scanner_hot: Path
    candle_cache: Path
    candle_delta: Path
    market_regime: Path
    feature_cache: Path
    orderflow_cache: Path
    ws_cache: Path
    micro_cache: Path
    strategy_status: Path
    candidate_latest: Path
    s1_hold: Path
    gate_status: Path
    trigger_state: Path
    risk_status: Path
    risk_cache: Path
    paper_control: Path
    paper_status: Path
    paper_open: Path
    paper_closed: Path
    paper_decision: Path
    paper_decision_events: Path
    paper_events: Path
    paper_error: Path
    performance: Path
    command_snapshot: Path
    review_status: Path
    main_status: Path
    change_ledger: Path
    issue_ledger: Path

    @classmethod
    def at(cls, base: Path) -> "Paths":
        b=base.resolve()
        return cls(
            b,
            b/'clean_scanner_market_cache.json', b/'clean_scanner_candidate_pool.json', b/'clean_scanner_hot_rank_cache.json',
            b/'clean_candle_cache.json', b/'clean_candle_delta_v1014.jsonl', b/'clean_market_regime_cache.json',
            b/'clean_feature_cache.json', b/'clean_orderflow_summary_cache.json', b/'clean_ws_live_cache.json', b/'clean_bithumb_micro_cache.json',
            b/'clean_strategy_worker_status.json', b/'paper_candidates_latest.jsonl', b/'paper_s1_hold_cache.json', b/'clean_strategy_swing_gate_status_v977.json', b/'clean_strategy_trigger_state_v1066.json',
            b/'clean_risk_status.json', b/'clean_risk_filter_cache.json', b/'paper_bot_control.json', b/'paper_bot_status.json', b/'paper_bot_open.json', b/'paper_bot_closed.jsonl',
            b/'paper_decision_state_v926.json', b/'paper_decision_events_v926.jsonl', b/'paper_core_v2_events_v1066.jsonl', b/'paper_bot_error.log',
            b/'canonical_performance_snapshot_v987.json', b/'coinbot_core_v2_command_snapshot.json', b/'clean_review_worker_status.json', b/'clean_brain_status.json',
            b/'change_verify_ledger.jsonl', b/'issue_ledger.jsonl',
        )

@dataclass(frozen=True)
class Thresholds:
    max_spread_pct: float = 1.2
    min_rr: float = 1.5
    min_target_room_pct: float = 1.2
    max_trigger_chase_pct: float = 0.6
    emergency_stop_pct: float = -2.5
    trailing_trigger_pct: float = 2.0
    trailing_giveback_pct: float = 0.8
    no_progress_sec: float = 6*3600
    max_weak_hold_sec: float = 72*3600

@dataclass(frozen=True)
class RuntimeConfig:
    paths: Paths
    thresholds: Thresholds = Thresholds()
    strategy_interval_sec: float = 2.0
    risk_interval_sec: float = 2.0
    paper_cycle_sec: float = 8.0
    paper_exit_sec: float = 1.0
    review_interval_sec: float = 10.0
    auto_buy: bool = AUTO_BUY
    parity_mode: bool = True

    @classmethod
    def from_env(cls, base: Path|None=None) -> "RuntimeConfig":
        b=Path(base or os.getenv('BOT_DIR') or Path(__file__).resolve().parents[1])
        return cls(
            paths=Paths.at(b),
            strategy_interval_sec=max(.5,float(os.getenv('CORE_V2_STRATEGY_SEC','2'))),
            risk_interval_sec=max(.5,float(os.getenv('CORE_V2_RISK_SEC','2'))),
            paper_cycle_sec=max(2.0,float(os.getenv('CORE_V2_PAPER_CYCLE_SEC','8'))),
            paper_exit_sec=max(.5,float(os.getenv('CORE_V2_PAPER_EXIT_SEC','1'))),
            review_interval_sec=max(2.0,float(os.getenv('CORE_V2_REVIEW_SEC','10'))),
            auto_buy=False,
            parity_mode=os.getenv('CORE_V2_PARITY_MODE','1').lower() not in {'0','false','off'},
        )
