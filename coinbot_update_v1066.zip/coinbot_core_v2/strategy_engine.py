from __future__ import annotations
from collections import Counter
from typing import Any,Dict,List,Tuple
from .common import atomic_write_json,replace_jsonl,read_json,num,text,ticker,pct,now_ts,now_text,unique,merge_nonempty
from .config import RuntimeConfig,BUILD,STRATEGY_MODE
from .sources import SourceReader
from .structure_engine import build_context,build_plan

STRATEGIES={
 'leader_flow_adaptive_hold_s':'주도흐름 유동보유','money_reaccel_s':'돈흐름 재가속','leader_momentum_s':'주도추세 지속',
 'breakout_early_s':'돌파 초입','sweep_vwap_recovery_s':'저점 VWAP 회복','surge_rebreak_s':'급등 후 재돌파','hot_rank_recheck':'hot-rank 급등 재확인','coin_quality_coverage':'코인품질 전체커버'
}

def _price(row:Dict[str,Any])->float: return num(row.get('current_price'),row.get('trade_price'),row.get('live_price'),row.get('price'),row.get('close'),default=0.0) or 0.0

def _quality(row:Dict[str,Any])->Dict[str,float]:
    return {
      'reaction':num(row.get('price_reaction_pct'),row.get('price_reaction_1m_pct'),row.get('change_1m'),row.get('price_change_1m'),default=0.0) or 0.0,
      'buy':num(row.get('buy_ratio'),row.get('buy_strength'),default=0.0) or 0.0,
      'sustain':num(row.get('buy_sustain_1m'),row.get('buy_sustain_60s'),row.get('buy_ratio'),default=0.0) or 0.0,
      'spread':(lambda v: -1.0 if v is None else v)(num(row.get('spread_pct'),row.get('micro_spread_pct'),row.get('orderbook_spread_pct'),default=None)),
      'relative':num(row.get('relative_strength'),row.get('relative_strength_pct'),default=0.0) or 0.0,
      'money':num(row.get('money_flow_score'),row.get('money_expand_score'),row.get('turnover_change_pct'),default=0.0) or 0.0,
      'ch1':num(row.get('change_1m'),row.get('price_change_1m'),default=0.0) or 0.0,
      'ch3':num(row.get('change_3m'),row.get('price_change_3m'),default=0.0) or 0.0,
    }

def _route(row:Dict[str,Any],q:Dict[str,float],hot:bool)->Tuple[str,str]:
    if hot and max(q['reaction'],q['ch1'],q['ch3'],num(row.get('price_chg_20s'),default=0.0) or 0.0)>=0.30: return 'hot_rank_recheck',STRATEGIES['hot_rank_recheck']
    if q['money']>=1.0 and q['reaction']>=0.15: return 'money_reaccel_s',STRATEGIES['money_reaccel_s']
    if q['relative']>=1.0 and q['reaction']>=0.15: return 'leader_momentum_s',STRATEGIES['leader_momentum_s']
    if bool(row.get('breakout')) or q['ch3']>=0.8: return 'breakout_early_s',STRATEGIES['breakout_early_s']
    if bool(row.get('sweep_reclaim')) or (num(row.get('vwap_gap_pct'),default=-999.0) or -999.0)>=0: return 'sweep_vwap_recovery_s',STRATEGIES['sweep_vwap_recovery_s']
    if q['ch1']>=0.5 and q['ch3']>=1.0: return 'surge_rebreak_s',STRATEGIES['surge_rebreak_s']
    return 'coin_quality_coverage',STRATEGIES['coin_quality_coverage']

def _execution_fresh(row:Dict[str,Any])->Tuple[bool,Dict[str,str]]:
    cov=row.get('candidate_input_coverage_v908') if isinstance(row.get('candidate_input_coverage_v908'),dict) else {}
    items=cov.get('items') if isinstance(cov.get('items'),dict) else {}
    states={}
    for name,keys in {
      'micro':('micro_fresh','fresh_micro'),'orderflow':('orderflow_fresh','fresh_orderflow'),'quote':('quote_fresh','ws_fresh')
    }.items():
        state=str((items.get(name) or {}).get('state') or '').lower()
        if not state:
            val=next((row.get(k) for k in keys if row.get(k) is not None),None)
            present=(row.get('_sources_present') or {}) if isinstance(row.get('_sources_present'),dict) else {}
            source_present = (present.get('micro') if name=='micro' else (present.get('orderflow') if name=='orderflow' else (present.get('ws') or present.get('micro'))))
            if val is True or source_present:
                state='fresh'
            elif val is False:
                state='stale'
            else:
                state='missing'
        states[name]=state
    return all(v=='fresh' for v in states.values()),states

def _candidate_key(t:str,route:str,now:float,row:Dict[str,Any])->str:
    existing=text(row.get('candidate_entry_build_key'),row.get('entry_build_key'),row.get('event_id'),row.get('event_key'))
    if existing: return existing
    occurrence=int((num(row.get('hot_occurrence_ts'),row.get('occurrence_ts'),row.get('updated_ts'),default=now) or now)//10)
    return f'{t}:{route}:{occurrence}'

def _base_decision_key(t:str,frozen_ts:float)->str: return f'decision:market:{t}|plan:{int(frozen_ts*1000)}'

class StrategyEngine:
    def __init__(self,cfg:RuntimeConfig): self.cfg=cfg; self.sources=SourceReader(cfg)
    def _load_state(self)->Dict[str,Any]:
        obj=read_json(self.cfg.paths.trigger_state,{}) or {}; return obj if isinstance(obj,dict) else {}
    def _occurrence(self,rec:Dict[str,Any],t:str,price:float,trigger:float,now:float)->Tuple[Dict[str,Any],str]:
        base=_base_decision_key(t,float(rec.get('frozen_ts') or now)); side='above' if price>=trigger else 'below'; previous=str(rec.get('trigger_side') or '')
        reset=float(rec.get('reset_ts') or 0); rebreak=float(rec.get('rebreak_ts') or 0); seq=int(rec.get('seq') or 0); kind=str(rec.get('kind') or ''); decision=str(rec.get('decision_key') or base)
        if previous not in {'above','below'}:
            if side=='below': reset=now; rebreak=0; kind='RESET_BELOW'; decision=base
            else: kind='INITIAL_OR_MIGRATED_ABOVE'; seq=max(1,seq); decision=base
        elif side=='below' and previous!='below': reset=now; rebreak=0; kind='RESET_BELOW'
        elif side=='above' and previous=='below' and reset>0: rebreak=now; seq=max(1,seq+1); kind='REBREAK'; decision=f'{base}|rebreak:{int(now*1000)}'
        rec.update({'trigger_side':side,'reset_ts':reset or None,'rebreak_ts':rebreak or None,'seq':seq,'kind':kind,'decision_key':decision,'last_seen_ts':now})
        return {'schema':'trigger_occurrence_v1037','state_key':f'market:{t}','base_plan_decision_key':base,'decision_key':decision,'kind':kind,'side':side,'plan_frozen_ts':rec.get('frozen_ts'),'reset_ts':reset or None,'rebreak_ts':rebreak or None,'sequence':seq,'trigger_price':trigger,'current_price':price,'trigger_reached':side=='above','major_setup_target_invalid_change_required':False},decision
    def run(self,now:float|None=None)->Dict[str,Any]:
        now=float(now or now_ts()); bundle=self.sources.load(); risk=read_json(self.cfg.paths.risk_cache,{}) or {}; trigger_state=self._load_state(); active=trigger_state.get('active') if isinstance(trigger_state.get('active'),dict) else {}
        results=[]; summary=Counter(); reasons=Counter()
        for t,row0 in bundle.merged.items():
            row=dict(row0); price=_price(row)
            if price<=0: continue
            q=_quality(row); hot=bool(bundle.hot.get(t) or row.get('hot_rank') or row.get('scanner_hot'))
            route,label=_route(row,q,hot)
            ctx=build_context(row); plan=build_plan(row,ctx)
            trigger=num((plan.get('trigger') or {}).get('price'),default=0.0) or 0.0; invalid=num((plan.get('invalid') or {}).get('price'),default=0.0) or 0.0; target=num((plan.get('target') or {}).get('price'),default=0.0) or 0.0
            rec=active.get(t) if isinstance(active.get(t),dict) else None
            if rec:
                if (invalid>0 and price<=invalid) or (target>0 and price>=target): active.pop(t,None); rec=None
            if rec is None and trigger>0 and invalid>0 and target>0:
                rec={'ticker':t,'frozen_ts':now,'trigger':trigger,'invalid':invalid,'target':target}; active[t]=rec
            if rec:
                trigger=float(rec.get('trigger') or trigger); invalid=float(rec.get('invalid') or invalid); target=float(rec.get('target') or target)
            risk_amt=max(0.0,trigger-invalid); reward=max(0.0,target-trigger); rr=reward/risk_amt if risk_amt>0 else 0.0; room=reward/trigger*100 if trigger>0 else 0.0
            fresh,states=_execution_fresh(row); spread=q['spread']; trigger_reached=trigger>0 and price>=trigger; chase=pct(price,trigger) if trigger>0 else 0.0
            occ,decision=self._occurrence(rec or {'frozen_ts':now},t,price,trigger or price,now)
            candidate_key=_candidate_key(t,route,now,row); occ['candidate_key']=f'{candidate_key}|occ:{occ.get("kind") or "initial"}:{int((occ.get("rebreak_ts") or occ.get("plan_frozen_ts") or now)*1000)}'
            hard=[]; severe=False
            observation_only=bool(row.get('s3_observation_only_v988') or row.get('observation_only'))
            if observation_only: hard.append('s3_observation_only_no_open'); severe=True
            if ctx.get('source_missing'): hard.append('structure_source_or_role_missing'); severe=True
            if not (trigger>0 and invalid>0 and target>0): hard.append('coherent_structure_plan_incomplete'); severe=True
            elif not (invalid<min(price,trigger)<=trigger<target): hard.append('invalid_trigger_target_order_invalid'); severe=True
            if rr<self.cfg.thresholds.min_rr: hard.append('risk_reward_below_minimum')
            if room<self.cfg.thresholds.min_target_room_pct: hard.append('target_room_below_minimum')
            if not fresh: hard.append('execution_sources_not_fresh')
            if spread<0: hard.append('spread_source_missing')
            elif spread>self.cfg.thresholds.max_spread_pct: hard.append('untradable_spread'); severe=True
            if not trigger_reached: hard.append('frozen_trigger_not_reached')
            elif chase>self.cfg.thresholds.max_trigger_chase_pct: hard.append('trigger_chase_overshoot')
            hard=unique(hard,20)
            passed=not hard and not observation_only
            stage='S1' if passed else ('S3' if severe or observation_only else 'S2')
            final_state='S1_PASS' if passed else ('S3_OBSERVE_ONLY' if observation_only else ('S3_OBSERVE' if severe else 'S2_RECHECK'))
            for x in hard: reasons[x]+=1
            summary[stage]+=1
            gate={'schema':'swing_entry_gate_v977_single_owner','owner':'core_v2.strategy_engine','strategy_mode':STRATEGY_MODE,'decision_key':decision,'hard_pass':passed,'final_trade_state':final_state,'hard_block_reasons':hard,'trigger_price':trigger or None,'invalid_price':invalid or None,'target_price':target or None,'risk_reward':rr,'target_room_pct':room,'source_fresh':fresh,'trigger_reached':trigger_reached,'trigger_gap_pct':chase,'execution_states':states,'frozen_plan_ts':rec.get('frozen_ts') if rec else now}
            result=merge_nonempty(row,{
                'ticker':t,'strategy_mode':STRATEGY_MODE,'strategy_key':route,'strategy_label':label,'canonical_lane':'spike' if hot and route=='hot_rank_recheck' else 'base',
                's_stage':stage,'score':100+q['reaction']*10+q['ch1']*4+q['ch3']*3+q['buy']*2,'s_stage_reasons':hard or ['구조계약 통과'],
                'current_price':price,'structure_context_v871':ctx,'swing_structure_plan_v977':plan,
                'swing_entry_gate_v977':gate,'swing_gate_decision_key_v977':decision,'trigger_occurrence_v1037':occ,
                'trigger_occurrence_candidate_key_v1037':occ['candidate_key'],'candidate_entry_build_key':candidate_key,
                'swing_trigger_price_v977':trigger or None,'swing_invalid_price_v977':invalid or None,'swing_target_price_v977':target or None,
                'risk_reward':rr,'target_room_pct':room,'spread_pct':spread if spread>=0 else None,
                'quality_observation_v925':{'schema':'quality_observation_v925_non_blocking','observation_only':True,'metrics':q,'policy':'record/score/review only'},
                'candidate_input_coverage_v908':{'items':{name:{'state':state} for name,state in states.items()}},'updated_ts':now,
            })
            results.append(result)
        results.sort(key=lambda r:({'S1':3,'S2':2,'S3':1}.get(str(r.get('s_stage')),0),num(r.get('score'),default=0.0) or 0.0),reverse=True)
        s1=[r for r in results if r.get('s_stage')=='S1']
        replace_jsonl(self.cfg.paths.candidate_latest,results)
        atomic_write_json(self.cfg.paths.s1_hold,{'schema':'paper_s1_hold_cache_v1066','version':'strategy_worker_v1.000','updated_ts':now,'rows':s1})
        active={k:v for k,v in active.items() if now-float(v.get('last_seen_ts') or now)<7*86400}
        atomic_write_json(self.cfg.paths.trigger_state,{'schema':'trigger_state_v1066','active':active,'updated_ts':now})
        gate_status={'schema':'swing_entry_gate_status_v1066','version':'strategy_worker_v1.000','build':BUILD,'updated_ts':now,'rows':len(results),'pass_s1':len(s1),'recheck_s2':summary['S2'],'observe_s3':summary['S3'],'hard_reason_top':dict(reasons.most_common(20)),'thresholds':{'untradable_spread_pct':self.cfg.thresholds.max_spread_pct,'minimum_risk_reward':self.cfg.thresholds.min_rr,'minimum_target_room_pct':self.cfg.thresholds.min_target_room_pct,'maximum_trigger_overshoot_pct':self.cfg.thresholds.max_trigger_chase_pct},'soft_conditions':'quality/market/strategy labels remain observation inputs','single_owner':'core_v2.strategy_engine','auto_buy':False}
        atomic_write_json(self.cfg.paths.gate_status,gate_status)
        status={'version':'strategy_worker_v1.000','build':BUILD,'state':'running','phase':'done','pid':__import__('os').getpid(),'updated_ts':now,'evaluated':len(results),'row_count':len(results),'s_count':len(results),'s1_count':len(s1),'s2_count':summary['S2'],'s3_count':summary['S3'],'target_count':len(results),'last_sec':0.0,'last_error':'','writer_owner':'core_v2.strategy_engine.single_status_writer','auto_buy':False,'strategy_mode':STRATEGY_MODE}
        atomic_write_json(self.cfg.paths.strategy_status,status)
        return {'rows':results,'s1':s1,'status':status,'gate_status':gate_status}
