from __future__ import annotations
from collections import Counter,defaultdict
from typing import Any,Dict,List,Tuple
from .common import read_jsonl_tail,read_json,atomic_write_json,num,text,ticker,parse_ts,now_ts,now_text,file_signature
from .config import RuntimeConfig,BUILD,STRATEGY_MODE

def _pnl(row:Dict[str,Any])->float|None: return num(row.get('net_after_configured_fee_pct_v983'),row.get('net_pct'),row.get('pnl_pct'),row.get('result_pct'),row.get('profit_pct'),row.get('final_realized_pnl_pct'),default=None)
def _decision(row:Dict[str,Any])->str:
    d=text(row.get('paper_decision_key_v926'),row.get('swing_gate_decision_key_v977'),row.get('decision_key'))
    if not d:
        pid=text(row.get('pos_id'))
        d=pid[len('pos:'):] if pid.startswith('pos:') else pid
    return d

def summarize(rows:List[Dict[str,Any]])->Dict[str,Any]:
    pnls=[x for x in (_pnl(r) for r in rows) if x is not None]; wins=sum(1 for x in pnls if x>0); losses=sum(1 for x in pnls if x<0)
    return {'count':len(pnls),'wins':wins,'losses':losses,'draws':len(pnls)-wins-losses,'win_rate':wins/len(pnls)*100 if pnls else 0.0,'sum_pct':sum(pnls),'avg_pct':sum(pnls)/len(pnls) if pnls else 0.0}

class PerformanceWriter:
    def __init__(self,cfg:RuntimeConfig): self.cfg=cfg
    def build(self,now:float|None=None)->Dict[str,Any]:
        now=float(now or now_ts()); p=self.cfg.paths
        raw=read_jsonl_tail(p.paper_closed,limit=20000,max_bytes=256*1024*1024); decisions=read_json(p.paper_decision,{}) or {}; records=decisions.get('records') if isinstance(decisions.get('records'),dict) else {}
        exact=[]; duplicates=0; missing_key=0; unlinked=0; seen=set()
        for row in raw:
            mode=text(row.get('strategy_mode'),row.get('strategy_mode_v977')).upper()
            if mode and mode!=STRATEGY_MODE: continue
            key=_decision(row)
            if not key: missing_key+=1; continue
            if key in seen: duplicates+=1; continue
            seen.add(key)
            rec=records.get(key) if isinstance(records,dict) else None
            if not isinstance(rec,dict) or rec.get('state')!='CLOSED': unlinked+=1; continue
            if _pnl(row) is None: continue
            exact.append(row)
        exact.sort(key=lambda r:parse_ts(r.get('closed_ts'),r.get('closed_at'),r.get('ts')))
        windows={}
        for name,sec in [('3h',10800),('6h',21600),('24h',86400)]: windows[name]=summarize([r for r in exact if parse_ts(r.get('closed_ts'),r.get('closed_at'),r.get('ts'))>=now-sec])
        routes=defaultdict(list); exits=defaultdict(list); regimes=defaultdict(list)
        for r in exact[-2000:]:
            pnl=_pnl(r)
            if pnl is None: continue
            routes[text(r.get('actual_entry_method'),r.get('entry_method'),r.get('strategy_label'),r.get('strategy_key')) or '미기록'].append(pnl)
            exits[text(r.get('exit_reason'),r.get('close_reason')) or '미기록'].append(pnl)
            regimes[text(r.get('market_regime'),r.get('market_state')) or '미기록'].append(pnl)
        def groups(obj): return {k:{'count':len(v),'wins':sum(x>0 for x in v),'losses':sum(x<0 for x in v),'sum_pct':sum(v),'avg_pct':sum(v)/len(v) if v else 0.0} for k,v in sorted(obj.items(),key=lambda kv:len(kv[1]),reverse=True)}
        open_obj=read_json(p.paper_open,{}) or {}; open_rows=[r for r in open_obj.values() if isinstance(r,dict)] if isinstance(open_obj,dict) else []
        open_pnls=[num(r.get('net_pct'),r.get('pnl_pct'),default=0.0) or 0.0 for r in open_rows]
        snapshot={
          'schema':'canonical_alt_swing_performance_snapshot_v987','owner':'paper_bot_single_canonical_performance_writer','version':'paper_bot_v1.000','build':BUILD,'generated_ts':now,'generated_text':now_text(now),
          'snapshot_id':f'perf-v1066-{int(now*1000)}','strategy_mode':STRATEGY_MODE,'source_digest':file_signature(p.paper_closed),
          'raw_count':len(raw),'exact_count':len(exact),'duplicates':duplicates,'decision_key_missing':missing_key,'unlinked':unlinked,
          'overall':summarize(exact),'windows':windows,'current_open':{'count':len(open_rows),'sum_pct':sum(open_pnls),'avg_pct':sum(open_pnls)/len(open_pnls) if open_pnls else 0.0,'wins':sum(x>0 for x in open_pnls),'losses':sum(x<0 for x in open_pnls)},
          'by_route':groups(routes),'by_exit':groups(exits),'by_regime':groups(regimes),'recent_closed':exact[-20:],'auto_buy':False,
        }
        atomic_write_json(p.performance,snapshot); return snapshot
