from __future__ import annotations
from collections import defaultdict
from typing import Any,Dict,List,Tuple
from .common import read_json,read_jsonl_tail,atomic_write_json,file_signature,num,text,ticker,parse_ts,now_ts,now_text
from .config import RuntimeConfig,VERSION,BUILD,STRATEGY_MODE

LOSS_COOLDOWN_SEC_DEFAULT=6*3600

class RiskEngine:
    def __init__(self,cfg:RuntimeConfig): self.cfg=cfg
    def build(self,now:float|None=None)->Dict[str,Any]:
        now=float(now or now_ts()); p=self.cfg.paths
        closed=read_jsonl_tail(p.paper_closed,limit=12000,max_bytes=128*1024*1024)
        open_obj=read_json(p.paper_open,{}) or {}
        control=read_json(p.paper_control,{}) or {}
        cooldown_sec=max(0.0,num(control.get('loss_reentry_cooldown_sec'),default=LOSS_COOLDOWN_SEC_DEFAULT) or LOSS_COOLDOWN_SEC_DEFAULT)
        latest:Dict[str,Dict[str,Any]]={}; recent_losses=defaultdict(int); hard_losses=defaultdict(int)
        for row in closed:
            if not isinstance(row,dict): continue
            mode=text(row.get('strategy_mode'),row.get('strategy_mode_v977')).upper()
            if mode and mode!=STRATEGY_MODE: continue
            pnl=num(row.get('net_after_configured_fee_pct_v983'),row.get('net_pct'),row.get('pnl_pct'),row.get('profit_pct'),row.get('result_pct'),default=None)
            if pnl is None or pnl>=0: continue
            t=ticker(row.get('ticker') or row.get('market') or row.get('symbol'))
            if not t: continue
            ts=parse_ts(row.get('closed_ts'),row.get('closed_at'),row.get('exit_ts'),row.get('ts'))
            recent_losses[t]+=1
            if pnl<=-3.0: hard_losses[t]+=1
            current=latest.get(t)
            if current is None or ts>float(current.get('closed_ts') or 0):
                cand=text(row.get('trigger_occurrence_candidate_key_v1037'),row.get('candidate_key'),row.get('candidate_entry_build_key'),row.get('entry_build_key'))
                dec=text(row.get('paper_decision_key_v926'),row.get('swing_gate_decision_key_v977'),row.get('decision_key'))
                latest[t]={
                    'ticker':t,'closed_ts':ts,'exit_price':num(row.get('exit_price'),row.get('closed_price'),row.get('close_price'),default=None),
                    'trigger_price':num(row.get('swing_trigger_price_v977'),row.get('trigger_price'),default=None),
                    'candidate_key':cand or None,'decision_key':dec or None,'pnl_pct':pnl,
                    'identity_complete':bool(cand and dec and ts>0 and num(row.get('swing_trigger_price_v977'),row.get('trigger_price'),default=0.0)),
                    'exit_reason':text(row.get('exit_reason'),row.get('close_reason')) or None,
                }
        cooldown={}
        for t,event in latest.items():
            closed_ts=float(event.get('closed_ts') or 0); until=closed_ts+cooldown_sec
            cooldown[t]={'active':bool(closed_ts>0 and now<until),'until_ts':until,'remaining_sec':max(0.0,until-now),'last_loss':event}
        result={
            'schema':'risk_filter_v1066_core_v2','version':'risk_worker_v1.000','build':BUILD,'updated_ts':now,'updated_text':now_text(now),
            'strategy_mode':STRATEGY_MODE,'last_loss_event_by_ticker':latest,'cooldown_by_ticker':cooldown,
            'recent_loss_count_by_ticker':dict(recent_losses),'hard_loss_count_by_ticker':dict(hard_losses),
            'open_tickers':sorted({ticker((r or {}).get('ticker')) for r in (open_obj.values() if isinstance(open_obj,dict) else []) if isinstance(r,dict)}),
            'loss_reentry_source_contract_v1057':{
                'schema':'loss_reentry_source_contract_v1057','owner':'risk_worker','source_complete':True,
                'latest_loss_selection':'max_numeric_closed_ts_per_ticker','event_count':len(latest),'closed_signature':file_signature(p.paper_closed),
                'policy':'latest ALT_SWING loss by max numeric closed_ts; no ticker/time inference for exact linkage',
            },
            'auto_buy':False,'writer_owner':'risk_worker_v1.000.single_writer','writer_count':1,
        }
        atomic_write_json(p.risk_cache,result)
        atomic_write_json(p.risk_status,{
            'version':'risk_worker_v1.000','build':BUILD,'state':'running','phase':'done','pid':__import__('os').getpid(),'updated_ts':now,
            'row_count':len(latest),'last_sec':0.0,'schema':result['schema'],'error':'','auto_buy':False,
            'contract_ready':True,'latest_loss_selection':'max_numeric_closed_ts_per_ticker','writer_owner':'risk_worker_v1.000.single_status_writer',
        })
        return result

def loss_reentry_decision(candidate:Dict[str,Any],prior:Dict[str,Any]|None)->Dict[str,Any]:
    occ=candidate.get('trigger_occurrence_v1037') if isinstance(candidate.get('trigger_occurrence_v1037'),dict) else {}
    gate=candidate.get('swing_entry_gate_v977') if isinstance(candidate.get('swing_entry_gate_v977'),dict) else {}
    cand=text(occ.get('candidate_key'),candidate.get('trigger_occurrence_candidate_key_v1037'),candidate.get('candidate_key'),candidate.get('candidate_entry_build_key'))
    dec=text(candidate.get('swing_gate_decision_key_v977'),gate.get('decision_key'),candidate.get('decision_key'))
    trigger=num(gate.get('trigger_price'),candidate.get('swing_trigger_price_v977'),candidate.get('trigger_price'),default=0.0) or 0.0
    current={'ticker':ticker(candidate.get('ticker')),'candidate_key':cand or None,'decision_key':dec or None,'trigger_price':trigger or None,'trigger_reached':bool(gate.get('trigger_reached')),'occurrence':occ or None}
    if not prior:
        return {'schema':'loss_reentry_gate_v1037','allowed':True,'state':'NO_PRIOR_LOSS','reason':None,'current':current,'prior':None,'requirements':{}}
    prior_candidate=text(prior.get('candidate_key')); prior_decision=text(prior.get('decision_key')); prior_closed=num(prior.get('closed_ts'),default=0.0) or 0.0
    prior_trigger=num(prior.get('trigger_price'),default=0.0) or 0.0; prior_exit=num(prior.get('exit_price'),default=0.0) or 0.0
    reset_ts=num(occ.get('reset_ts'),default=0.0) or 0.0; rebreak_ts=num(occ.get('rebreak_ts'),default=0.0) or 0.0; plan_frozen=num(occ.get('plan_frozen_ts'),default=0.0) or 0.0
    exit_reset=bool(prior_closed>0 and prior_trigger>0 and prior_exit>0 and prior_exit<prior_trigger)
    occurrence_reset=bool(reset_ts>prior_closed>0)
    occurrence_rebreak=bool(str(occ.get('kind') or '')=='REBREAK' and rebreak_ts>reset_ts>prior_closed>0)
    initial_after_exit_reset=bool(exit_reset and str(occ.get('kind') or '')=='INITIAL_OR_MIGRATED_ABOVE' and plan_frozen>prior_closed>0 and bool(gate.get('trigger_reached')))
    req={
        'prior_identity_complete':bool(prior.get('identity_complete') and prior_candidate and prior_decision and prior_trigger>0 and prior_closed>0),
        'current_candidate_key_ready':bool(cand),'current_decision_key_ready':bool(dec),
        'new_candidate_key':bool(cand and prior_candidate and cand!=prior_candidate),'new_decision_key':bool(dec and prior_decision and dec!=prior_decision),
        'reset_after_loss':bool(exit_reset or occurrence_reset),'trigger_rebreak_after_reset':bool(occurrence_rebreak or initial_after_exit_reset),
        'paper_trigger_reached':bool(gate.get('trigger_reached')),
    }
    allowed=all(req.values())
    if not req['prior_identity_complete']: state='PRIOR_IDENTITY_MISSING_BLOCK'; reason='이전 손실 identity 불완전'
    elif not req['current_candidate_key_ready'] or not req['current_decision_key_ready']: state='CURRENT_IDENTITY_MISSING'; reason='현재 candidate/decision key 누락'
    elif not req['new_candidate_key'] or not req['new_decision_key']: state='SAME_EVENT_BLOCK'; reason='이전 손실과 같은 사건'
    elif not req['reset_after_loss']: state='WAIT_TRIGGER_RESET'; reason='이전 손실 뒤 trigger 아래 리셋 미확인'
    elif not req['trigger_rebreak_after_reset'] or not req['paper_trigger_reached']: state='WAIT_TRIGGER_REBREAK'; reason='리셋 이후 trigger 재돌파 미확인'
    else: state='NEW_TRIGGER_REBREAK_CONFIRMED'; reason=None
    return {'schema':'loss_reentry_gate_v1037','allowed':allowed,'state':state,'reason':reason,'current':current,'prior':prior,'requirements':req,'structure_line_change_required':False}
