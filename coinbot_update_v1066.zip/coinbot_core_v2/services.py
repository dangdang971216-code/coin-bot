from __future__ import annotations
import os,signal,time,traceback
from pathlib import Path
from typing import Any,Dict,List
from .config import RuntimeConfig,BUILD
from .common import atomic_write_json,append_jsonl_fsync,now_ts,now_text
from .risk_engine import RiskEngine
from .strategy_engine import StrategyEngine
from .paper_engine import PaperEngine
from .performance import PerformanceWriter
from .snapshot import SnapshotWriter
from .command_views import render_main,render_paper
from .telegram_runtime import TelegramPoller

_STOP=False
def _stop(*_args):
    global _STOP; _STOP=True

def install_signals(): signal.signal(signal.SIGTERM,_stop); signal.signal(signal.SIGINT,_stop)

def run_risk(base:Path)->None:
    install_signals(); cfg=RuntimeConfig.from_env(base); engine=RiskEngine(cfg)
    while not _STOP:
        started=time.monotonic()
        try: engine.build()
        except Exception as exc:
            atomic_write_json(cfg.paths.risk_status,{'version':'risk_worker_v1.000','build':BUILD,'state':'error','phase':'error','pid':os.getpid(),'updated_ts':now_ts(),'error':f'{type(exc).__name__}: {exc}','auto_buy':False})
        time.sleep(max(.1,cfg.risk_interval_sec-(time.monotonic()-started)))

def run_strategy(base:Path)->None:
    install_signals(); cfg=RuntimeConfig.from_env(base); engine=StrategyEngine(cfg)
    while not _STOP:
        started=time.monotonic()
        try: engine.run()
        except Exception as exc:
            atomic_write_json(cfg.paths.strategy_status,{'version':'strategy_worker_v1.000','build':BUILD,'state':'error','phase':'error','pid':os.getpid(),'updated_ts':now_ts(),'last_error':f'{type(exc).__name__}: {exc}','auto_buy':False})
        time.sleep(max(.1,cfg.strategy_interval_sec-(time.monotonic()-started)))

def run_review(base:Path)->None:
    install_signals(); cfg=RuntimeConfig.from_env(base); perf=PerformanceWriter(cfg); snap=SnapshotWriter(cfg)
    while not _STOP:
        started=time.monotonic()
        try:
            p=perf.build(); s=snap.build(); atomic_write_json(cfg.paths.review_status,{'version':'review_worker_v1.000','build':BUILD,'state':'running','phase':'done','pid':os.getpid(),'updated_ts':now_ts(),'row_count':p.get('exact_count',0),'closed_recent':(p.get('windows') or {}).get('24h',{}).get('count',0),'last_error':'','auto_buy':False,'writer_owner':'core_v2.review.single_status_writer'})
        except Exception as exc:
            atomic_write_json(cfg.paths.review_status,{'version':'review_worker_v1.000','build':BUILD,'state':'error','phase':'error','pid':os.getpid(),'updated_ts':now_ts(),'last_error':f'{type(exc).__name__}: {exc}','auto_buy':False})
        time.sleep(max(.2,cfg.review_interval_sec-(time.monotonic()-started)))

def run_paper(base:Path)->None:
    install_signals(); cfg=RuntimeConfig.from_env(base); engine=PaperEngine(cfg); snap=SnapshotWriter(cfg)
    token=os.getenv('PAPER_BOT_TOKEN',os.getenv('TELEGRAM_TOKEN','')); chat=os.getenv('PAPER_BOT_ALLOWED_CHAT_ID',os.getenv('PAPER_BOT_CHAT_ID',os.getenv('CHAT_ID','')))
    poller=TelegramPoller(token,chat,lambda c,a:render_paper(c,cfg,a),'paper')
    last_cycle=0.0; last_exit=0.0; last_snap=0.0
    engine.write_status({'phase':'startup','open_count':len(engine.store.load_open()),'open_total':len(engine.store.load_open()),'pick_stats':{}})
    while not _STOP:
        now=now_ts()
        try:
            if now-last_exit>=cfg.paper_exit_sec: engine.monitor_exits(now); last_exit=now
            if now-last_cycle>=cfg.paper_cycle_sec: engine.select_and_open(now); last_cycle=now
            if now-last_snap>=3: snap.build(); last_snap=now
            poller.poll_once()
        except Exception as exc:
            append_jsonl_fsync(cfg.paths.paper_events,{'schema':'paper_core_v2_error_v1066','ts':now,'where':'main_loop','error':f'{type(exc).__name__}: {exc}','trace':traceback.format_exc()[-3000:]})
            engine.write_status({'phase':'error','last_error':f'{type(exc).__name__}: {exc}'})
        time.sleep(.2)

def run_main(base:Path)->None:
    install_signals(); cfg=RuntimeConfig.from_env(base); snap=SnapshotWriter(cfg)
    token=os.getenv('TELEGRAM_TOKEN',''); chat=os.getenv('CHAT_ID','')
    poller=TelegramPoller(token,chat,lambda c,a:render_main(c,cfg,a),'main'); last=0.0
    while not _STOP:
        try:
            if now_ts()-last>=3: snap.build(); last=now_ts()
            poller.poll_once()
        except Exception: pass
        time.sleep(.2)
