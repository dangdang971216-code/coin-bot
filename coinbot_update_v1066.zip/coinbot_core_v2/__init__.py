"""Coinbot CORE V2 — single-spine runtime."""
__version__ = "2.0.0-v1066"
BUILD = "v1066_full_core_single_spine_2026-06-26"
