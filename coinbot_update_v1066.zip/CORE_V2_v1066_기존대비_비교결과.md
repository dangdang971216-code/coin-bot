# CORE V2 v1066 기존 대비 비교

## 코드 구조

| 영역 | 기존 | CORE V2 |
|---|---:|---:|
| Main | 47,420줄 | launcher 5줄 + 공통 command/snapshot |
| Paper | 24,268줄 | launcher 5줄 + paper engine/store |
| Strategy | 24,532줄 | launcher 5줄 + strategy/structure engine |
| Risk | 413줄 | launcher 5줄 + risk engine |
| Review | 5,940줄 | launcher 5줄 + performance/snapshot |
| 새 핵심 package | - | 1,211줄 |

기존 Main·Paper·Strategy에는 같은 함수명을 뒤에서 다시 정의하는 경로가 다수 있었다. CORE V2 package는 top-level active 함수·클래스 중복 정의가 0이며 각 owner가 한 번만 선언된다.

## 삭제되는 active 방식

- 버전별 같은 함수 재정의.
- status writer 중첩 wrapper.
- Main/Review의 raw 성과 독립 재계산.
- heartbeat가 consumer 판정을 새로 만드는 방식.
- 버전 문자열로 Risk–Paper 기능을 연결하는 방식.
- Main·Paper·Guard가 서로 다른 source에서 같은 값을 만드는 방식.

## 유지되는 외부 worker

scanner, candle, market, feature, orderflow, target_router, ws, micro는 현재 단일 owner와 cache가 확인됐으므로 v1066에서 임의 재작성하지 않는다. 해당 최신 source는 ZIP의 `reference_unchanged_workers/`에 포함한다.

## 명령 화면

기존 명령 이름은 모두 유지한다. 화면은 현재 상태 → 이번 cycle → 차단·청산 근거 → 성과 → 원장 → 확인 필요 순서로 통일한다. Main과 Paper는 `coinbot_core_v2_command_snapshot.json` 하나를 읽고 Guard는 runtime/systemd/배포 검수 owner로 분리한다.

## 전환 방식

1. `/gupgrade_bundle`: Guard와 전체 새 코드만 서버에 스테이징. 라이브 본선 미변경.
2. `/gcore_v2_verify`: 임시 공간에서 전체 cycle·명령·parity 검증.
3. `/gcore_v2_cutover`: 검증 PASS일 때만 Risk→Strategy→Paper→Review→Main 동시 전환.
4. 어느 단계든 실패하면 active alias·배포 marker를 모두 복원하고 서비스 재시작.
