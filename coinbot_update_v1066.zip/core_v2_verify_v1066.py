#!/usr/bin/env python3
from __future__ import annotations
import ast,json,os,sys,time,tempfile,shutil,math
from pathlib import Path
from typing import Any,Dict
from coinbot_core_v2.config import RuntimeConfig,BUILD
from coinbot_core_v2.common import read_json,atomic_write_json,rows,ticker,text,num,file_signature,pct
from coinbot_core_v2.risk_engine import RiskEngine
from coinbot_core_v2.strategy_engine import StrategyEngine
from coinbot_core_v2.paper_engine import PaperEngine
from coinbot_core_v2.snapshot import SnapshotWriter
from coinbot_core_v2.command_views import MAIN_COMMANDS,PAPER_COMMANDS,render_main,render_paper

REQUIRED_FLOW=['scanner','candle','market','feature','orderflow','strategy','risk','paper','performance','commands']

def duplicate_defs(root:Path):
    dup=[]
    for p in root.rglob('*.py'):
        if 'tests' in p.parts: continue
        try: tree=ast.parse(p.read_text(encoding='utf-8'))
        except Exception as exc: dup.append({'file':str(p),'syntax':str(exc)}); continue
        names={}
        for node in tree.body:
            if isinstance(node,(ast.FunctionDef,ast.AsyncFunctionDef,ast.ClassDef)): names[node.name]=names.get(node.name,0)+1
        for n,c in names.items():
            if c>1: dup.append({'file':str(p),'name':n,'count':c})
    return dup

def _plan(row:Dict[str,Any])->tuple[float,float,float]:
    return (num(row.get('swing_trigger_price_v977'),(row.get('swing_entry_gate_v977') or {}).get('trigger_price') if isinstance(row.get('swing_entry_gate_v977'),dict) else None,default=0.0) or 0.0,
            num(row.get('swing_invalid_price_v977'),(row.get('swing_entry_gate_v977') or {}).get('invalid_price') if isinstance(row.get('swing_entry_gate_v977'),dict) else None,default=0.0) or 0.0,
            num(row.get('swing_target_price_v977'),(row.get('swing_entry_gate_v977') or {}).get('target_price') if isinstance(row.get('swing_entry_gate_v977'),dict) else None,default=0.0) or 0.0)

def _near(a:float,b:float,tol_pct:float=.75)->bool:
    if a<=0 or b<=0: return False
    return abs(a/b-1.0)*100.0<=tol_pct

def verify(base:Path,out_path:Path|None=None)->Dict[str,Any]:
    cfg=RuntimeConfig.from_env(base)
    live_paths=[cfg.paths.paper_open,cfg.paths.paper_closed,cfg.paths.paper_decision,cfg.paths.paper_decision_events,cfg.paths.change_ledger,cfg.paths.issue_ledger]
    live_before={str(p):file_signature(p) for p in live_paths}
    # Read-only parity generation: run risk/strategy to an isolated temporary copy of state outputs.
    tmp=Path(tempfile.mkdtemp(prefix='core_v2_verify_'))
    try:
        # Symlink read sources, isolate every writer path by copying the config base skeleton.
        for p in base.iterdir():
            if p.is_file():
                try: os.symlink(p,tmp/p.name)
                except FileExistsError: pass
        # Replace writer destinations with isolated files.
        writer_names=['clean_risk_status.json','clean_risk_filter_cache.json','clean_strategy_worker_status.json','paper_candidates_latest.jsonl','paper_s1_hold_cache.json','clean_strategy_swing_gate_status_v977.json','clean_strategy_trigger_state_v1066.json','paper_bot_status.json','paper_bot_open.json','paper_bot_closed.jsonl','paper_decision_state_v926.json','paper_decision_events_v926.jsonl','paper_core_v2_events_v1066.jsonl','canonical_performance_snapshot_v987.json','coinbot_core_v2_command_snapshot.json','clean_review_worker_status.json','clean_brain_status.json']
        for name in writer_names:
            path=tmp/name
            if path.is_symlink(): path.unlink()
            src=base/name
            if src.exists() and name in {'paper_bot_open.json','paper_bot_closed.jsonl','paper_decision_state_v926.json','paper_decision_events_v926.jsonl','paper_performance_epoch_v1045.json'}: shutil.copy2(src,path)
        test_cfg=RuntimeConfig.from_env(tmp)
        risk=RiskEngine(test_cfg).build(); strategy=StrategyEngine(test_cfg).run(); paper_engine=PaperEngine(test_cfg); paper_select=paper_engine.select_and_open(); paper_exit=paper_engine.monitor_exits(); snap=SnapshotWriter(test_cfg).build()
        live_hold=rows(read_json(base/'paper_s1_hold_cache.json',{}) or {}); new_hold=rows(read_json(tmp/'paper_s1_hold_cache.json',{}) or {})
        live_map={ticker(r.get('ticker')):r for r in live_hold}; new_map={ticker(r.get('ticker')):r for r in new_hold}; live_t=set(live_map); new_t=set(new_map)
        common=live_t&new_t; overlap_ratio=(len(common)/max(1,len(live_t),len(new_t))) if (live_t or new_t) else 1.0
        contract_matches=0
        for t in common:
            lp=_plan(live_map[t]); np=_plan(new_map[t])
            if all(_near(a,b) for a,b in zip(lp,np)): contract_matches+=1
        contract_ratio=contract_matches/max(1,len(common)) if common else (1.0 if not live_t and not new_t else 0.0)
        count_delta=abs(len(live_t)-len(new_t)); count_tolerance=max(2,math.ceil(max(len(live_t),len(new_t),1)*.25))
        parity_ok=bool(overlap_ratio>=.75 and contract_ratio>=.80 and count_delta<=count_tolerance)
        command_samples={c:render_main('/'+c,test_cfg) for c in MAIN_COMMANDS}; paper_samples={c:render_paper('/'+c,test_cfg) for c in PAPER_COMMANDS}
        missing_main=[c for c,v in command_samples.items() if not isinstance(v,str) or not v.strip()]; missing_paper=[c for c,v in paper_samples.items() if not isinstance(v,str) or not v.strip()]
        package_root=Path(__file__).resolve().parent/'coinbot_core_v2'; dup=duplicate_defs(package_root)
        spec=json.loads((package_root/'command_spec.json').read_text(encoding='utf-8')); guard_source=(Path(__file__).resolve().parent/'backga_guard_bot_v2_5_121.py').read_text(encoding='utf-8',errors='ignore')
        missing_guard=[c for c in spec.get('guard',[]) if ('/'+c) not in guard_source]
        required_modules=['sources.py','structure_engine.py','strategy_engine.py','risk_engine.py','execution_engine.py','paper_store.py','paper_engine.py','exit_engine.py','performance.py','snapshot.py','command_views.py','services.py','telegram_runtime.py']
        required_launchers=['risk_worker_v1.000.py','strategy_worker_v1.000.py','paper_bot_v1.000.py','review_worker_v1.000.py','coinbot_main_v2_14_1066.py']
        flow_complete=all((package_root/x).exists() for x in required_modules) and all((Path(__file__).resolve().parent/x).exists() for x in required_launchers)
        live_after={str(p):file_signature(p) for p in live_paths}
        live_write_zero=live_before==live_after
        checks={
          'risk_contract_ready':((risk.get('loss_reentry_source_contract_v1057') or {}).get('source_complete') is True),
          'strategy_cycle_completed':isinstance(strategy.get('rows'),list),
          'candidate_identity_complete':all(text((r.get('trigger_occurrence_v1037') or {}).get('candidate_key'),r.get('candidate_entry_build_key')) and text(r.get('swing_gate_decision_key_v977')) for r in new_hold),
          'structure_complete':all(num(r.get('swing_trigger_price_v977'),default=0)>0 and num(r.get('swing_invalid_price_v977'),default=0)>0 and num(r.get('swing_target_price_v977'),default=0)>0 for r in new_hold),
          'main_commands_complete':not missing_main and len(MAIN_COMMANDS)==26,
          'paper_commands_complete':not missing_paper and len(PAPER_COMMANDS)==27,
          'guard_commands_complete':not missing_guard and len(spec.get('guard',[]))>=154,
          'flow_components_complete':flow_complete,
          'paper_full_cycle_completed':isinstance(paper_select,dict) and isinstance(paper_exit,dict),
          'parity_sample_acceptable':parity_ok,
          'duplicate_active_definitions_zero':not dup,
          'auto_buy_off':test_cfg.auto_buy is False,
          'live_ledger_write_zero':live_write_zero,
        }
        # Parity is reported, not forced: same formulas may need server proof before cutover.
        report={
          'schema':'core_v2_verify_v1066','version':'v1066','build':BUILD,'generated_ts':time.time(),'base':str(base),
          'checks':checks,'pass':all(checks.values()),'live_s1':len(live_hold),'core_v2_s1':len(new_hold),'same_s1_tickers':len(common),'overlap_ratio':overlap_ratio,'contract_match_ratio':contract_ratio,'contract_match_count':contract_matches,'count_delta':count_delta,'count_tolerance':count_tolerance,'live_only':sorted(live_t-new_t)[:50],'core_only':sorted(new_t-live_t)[:50],
          'duplicate_definitions':dup,'missing_main_commands':missing_main,'missing_paper_commands':missing_paper,'missing_guard_commands':missing_guard,'snapshot':{'open_count':snap.get('open_count'),'errors':snap.get('errors')},
          'cutover_policy':'code complete; cutover requires this structural PASS. Strategy candidate count parity is shown for inspection but does not tighten conditions.',
          'live_write_performed':False,'auto_buy':False,
        }
        if out_path: atomic_write_json(out_path,report)
        return report
    finally: shutil.rmtree(tmp,ignore_errors=True)

def render(r:Dict[str,Any])->str:
    checks=r.get('checks') or {}; lines=['🧬 CORE V2 전체코드 검증 · v1066',f"- 판정: {'PASS' if r.get('pass') else 'CHECK'}",'- 라이브 원장 쓰기 0 / 자동매수 OFF','', '[전체 점검]']
    labels={'risk_contract_ready':'Risk 계약','strategy_cycle_completed':'Strategy 전체 cycle','candidate_identity_complete':'candidate·decision key','structure_complete':'trigger·invalid·target','main_commands_complete':'Main 명령 26/26','paper_commands_complete':'Paper 명령 27/27','guard_commands_complete':'Guard 기존 명령 154/154','flow_components_complete':'전체 흐름 모듈','paper_full_cycle_completed':'Paper OPEN·보유·CLOSED cycle','parity_sample_acceptable':'현재 본선 parity 표본','duplicate_active_definitions_zero':'중복 active 정의 0','auto_buy_off':'자동매수 OFF','live_ledger_write_zero':'라이브 write 0'}
    for k,v in checks.items(): lines.append(f"- {'✅' if v else '⚠️'} {labels.get(k,k)}")
    lines += ['', '[현재 본선 비교]',f"- 기존 S1 {r.get('live_s1',0)} / 새 CORE S1 {r.get('core_v2_s1',0)} / 같은 ticker {r.get('same_s1_tickers',0)}",f"- 겹침 {r.get('overlap_ratio',0)*100:.1f}% / 구조계약 일치 {r.get('contract_match_ratio',0)*100:.1f}% / count delta {r.get('count_delta',0)}≤{r.get('count_tolerance',0)}",f"- 기존만 {', '.join(r.get('live_only') or []) or '-'}",f"- 새 CORE만 {', '.join(r.get('core_only') or []) or '-'}",'', '[다음]', '- PASS면 /gcore_v2_cutover로 Strategy·Risk·Paper·Review·Main을 한 번에 전환', '- 조건 수치 변경 없음 · parity 모드 유지']
    return '\n'.join(lines)

if __name__=='__main__':
    base=Path(sys.argv[1] if len(sys.argv)>1 else Path(__file__).resolve().parent); out=Path(sys.argv[2]) if len(sys.argv)>2 else base/'core_v2_verify_status_v1066.json'; r=verify(base,out); print(render(r)); raise SystemExit(0 if r.get('pass') else 2)
