#!/usr/bin/env python3
from pathlib import Path
from coinbot_core_v2.services import run_main
BOT_VERSION='수익형 v2.14.1066'; BUILD='v1066_full_core_single_spine_2026-06-26'
if __name__=='__main__': run_main(Path(__file__).resolve().parent)
