#!/usr/bin/env python3
from pathlib import Path
from coinbot_core_v2.services import run_review
VERSION='review_worker_v1.000'; BUILD='v1066_full_core_single_spine_2026-06-26'
if __name__=='__main__': run_review(Path(__file__).resolve().parent)
