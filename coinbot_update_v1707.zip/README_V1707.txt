v1707: full pre-OPEN root cause audit report + paper final block map + guard /gbigfiles /gclean_disk + processed_command_v1433 NameError fix. No trading rule change. Auto-buy OFF.
