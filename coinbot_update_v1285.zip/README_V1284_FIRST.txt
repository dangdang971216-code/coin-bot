v1284: Guard 저장공간 4GB 유지 가드레일. 전략/Paper/Main/exact_replay 매매로직 변경 없음. 적용 후 /gstorage_floor_v1284 force 실행.
