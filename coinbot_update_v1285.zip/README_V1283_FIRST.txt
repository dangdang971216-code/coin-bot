v1283 Guard Telegram menu startup hotfix. Apply if Guard v1282 fails with HTTPError 400 at setMyCommands.
