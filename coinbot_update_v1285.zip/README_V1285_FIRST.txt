v1285: exact_replay WAL 폭증 방지. exact_replay 일시정지와 index cache 제거를 Guard 명령으로 수행. 전략/Paper/Main 매매로직 변경 없음. 적용 후 /gexact_pause_v1285 실행.
