coinbot v1476 - candidate flow recovery + S2 quality shadow

What changed
- Fixes S1 shown in Strategy but dropped before Paper because old open aliases disagreed with final_trade_state.
- final_trade_state is the single owner of S1/S2/S3 and live-open aliases.
- Active Strategy commit filename is fixed: strategy_candidate_pipeline_commit.json.
- One immutable handoff carries real S1 rows and S2 shadow rows under the same cycle_id + candidate_commit_id.
- Paper selector reads only real S1 rows. S2 is candidate-quality shadow only and cannot OPEN.
- Paper writes paper_candidate_pipeline_status.json once after selection.

Candidate order
S3 observe -> S2 recheck/shadow -> new-event S1 -> Paper -> trigger -> safety -> selected -> OPEN.

Locks
ALT_SWING unchanged. No Gate/TTL/RR/trigger/invalid/target/exit change. Auto-buy OFF.
