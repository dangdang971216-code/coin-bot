코인봇 업데이트 v1186

현재 서버 기준
- Guard v2.5.198
- Strategy v1.037
- Review v1.015
- Main v2.13.1128
- Paper v1.046
- 자동매수 OFF

v1186 대상
- Guard v2.5.199
- Strategy v1.037 유지
- Review v1.016
- Main v2.13.1129
- Paper v1.047

적용
1. 가드봇에서 /gupgrade_bundle 단독 실행
2. 자동 이어적용 완료 후 가드·Paper·Main 검수
3. runtime exact/hash, 다음 cycle, 재시작 유지 확인 전 DONE 금지

핵심 검수
- /version_score Telegram 첫 화면이 3h·6h·24h·오늘·어제 순서
- Paper _v1018_same_seed_value NameError 0
- /errorlog에 적용 전 Review 오류가 현재 오류처럼 나오지 않음
- 후보 기준판의 구조·품질 평가 표본이 S1 수와 맞음
- 자동매수 OFF
