#!/usr/bin/env python3
from __future__ import annotations

import importlib.util
import json
import os
import sys
import tempfile
from pathlib import Path

ROOT = Path(__file__).resolve().parent
BASE = Path(tempfile.mkdtemp(prefix="coinbot_v1186_test_"))
os.environ["COINBOT_BASE_DIR"] = str(BASE)
os.environ.pop("TELEGRAM_TOKEN", None)
sys.path.insert(0, str(ROOT))

# Canonical time windows + fresh epoch snapshot.
perf = {
    "snapshot_id": "perf-v1186-test",
    "generated_at_text": "now",
    "source_owner": "paper_bot_single_canonical_performance_writer",
    "counts": {"raw_ledger_rows": 120, "exact_unique_closed": 100, "current_epoch_exact_rows_v1045": 12},
    "windows": {
        "recent_3h": {"n": 3, "wins": 2, "losses": 1, "win_rate": 66.7, "total": 1.2, "avg": 0.4},
        "recent_6h": {"n": 5, "wins": 3, "losses": 2, "win_rate": 60.0, "total": 1.0, "avg": 0.2},
        "recent_24h": {"n": 9, "wins": 5, "losses": 4, "win_rate": 55.6, "total": 2.2, "avg": 0.244},
        "today": {"n": 8, "wins": 5, "losses": 3, "win_rate": 62.5, "total": 3.0, "avg": 0.375},
        "yesterday": {"n": 7, "wins": 3, "losses": 4, "win_rate": 42.9, "total": -1.0, "avg": -0.143},
        "all": {"n": 100, "wins": 50, "losses": 50, "win_rate": 50.0, "total": 10.0, "avg": 0.1},
    },
    "performance_epoch_v1045": {
        "stats": {"n": 12, "wins": 7, "losses": 5, "win_rate": 58.3, "total": 4.2, "avg": 0.35},
        "current_open_count": 4,
    },
}
(BASE / "canonical_performance_snapshot_v987.json").write_text(json.dumps(perf), encoding="utf-8")
(BASE / "ops_spine_snapshot_v1181.json").write_text(json.dumps({"overall_state":"NORMAL","current_cycle":{},"stages":[],"problems":[]}), encoding="utf-8")
(BASE / "canonical_candidate_standard_v1181.json").write_text("{}", encoding="utf-8")
(BASE / "paper_bot_status.json").write_text(json.dumps({"running": True, "version": "paper_bot_v1.047", "paper_fast_core_v1181": True}), encoding="utf-8")
(BASE / "paper_bot_open.json").write_text("{}", encoding="utf-8")

spec = importlib.util.spec_from_file_location("main_v1186", ROOT / "coinbot_main_v2_13_1129.py")
main = importlib.util.module_from_spec(spec)
assert spec and spec.loader
spec.loader.exec_module(main)
score = main.render_version_score_compact()
labels = ["최근 3시간", "최근 6시간", "최근 24시간", "오늘", "어제", "새 성과구간", "현재 OPEN", "전체 누적 참고"]
for label in labels:
    assert label in score, (label, score)
assert [score.index(label) for label in labels] == sorted(score.index(label) for label in labels)
assert "fresh CLOSED" not in score.splitlines()[2], score
for alias in ("core", "deploy", "upgradestatus"):
    assert alias in main.COMMANDS

# Review must judge tradeable S1 rows, not all 461 observation rows.
from canonical_spine_v1186 import SpinePaths, build_review_snapshot, build_candidate_standard, safe_error_tail
paths = SpinePaths(BASE)
rows = [
    {
        "ticker":"AAA", "s_stage":"S1", "paper_decision_key_v926":"d1", "candidate_key":"c1",
        "swing_trigger_price_v977":100, "swing_invalid_price_v977":95, "swing_target_price_v977":110,
        "swing_trigger_source_v977":"5m", "swing_invalid_source_v977":"1h", "swing_target_source_v977":"4h",
        "price_reaction_pct":0.4, "relative_strength_pct":1.2, "money_flow":55, "buy_ratio":0.6,
        "buy_sustain_1m":0.7, "quality_rank_score_v1095":70, "actual_entry_rr":2.0,
        "target_room_pct":10, "distance_to_invalid_pct":5, "trigger_chase_pct":0.1, "spread_pct":0.2, "slippage_pct":0.05,
    },
    {
        "ticker":"BBB", "s_stage":"S3", "candidate_key":"c2", "money_flow":40,
    },
]
paths.strategy_candidates.write_text("\n".join(json.dumps(r) for r in rows)+"\n", encoding="utf-8")
paths.strategy_status.write_text(json.dumps({"version":"strategy_worker_v1.037","execution_handoff_elapsed_sec_v1179":9.0}), encoding="utf-8")
paths.paper_status.write_text(json.dumps({"version":"paper_bot_v1.047"}), encoding="utf-8")
(BASE / "clean_candidate_standard_contract_v1141.json").write_text(json.dumps({"schema":"x","contract_digest":"abc"}), encoding="utf-8")
paths.review_request.write_text(json.dumps({"pipeline_cycle_id":"cy","candidate_commit_id":"cm","candidate_rows":2,"created_ts":1}), encoding="utf-8")
snapshot = build_review_snapshot(BASE)
standard = build_candidate_standard(snapshot)
assert snapshot["structure"]["evaluated"] == 1, snapshot["structure"]
assert snapshot["candidate"]["decision_key_missing"] == 0
assert snapshot["quality"]["price_reaction"]["n"] == 1
assert snapshot["performance"]["count"] == 12, snapshot["performance"]
assert snapshot["performance"]["sum_pct"] == 4.2
assert standard["state"] == "NORMAL", standard

# Prior-runtime Review log is hidden; current Paper log remains visible.
review_log = BASE / "clean_review_worker_error.log"
review_log.write_text("old review error\n", encoding="utf-8")
(BASE / "runtime").mkdir(exist_ok=True)
(BASE / "runtime/review_worker_singleton_v1121.lock").write_text(json.dumps({"acquired_ts":2000000000}), encoding="utf-8")
os.utime(review_log, (1900000000, 1900000000))
paper_log = BASE / "paper_bot_error.log"
paper_log.write_text("current paper error\n", encoding="utf-8")
(BASE / "paper_bot_status.json").write_text(json.dumps({"process_started_at":2000000000}), encoding="utf-8")
os.utime(paper_log, (2100000000, 2100000000))
errors = safe_error_tail(BASE)
assert not any("old review error" in line for line in errors), errors
assert any("current paper error" in line for line in errors), errors

paper_source = (ROOT / "paper_bot_v1.047.py").read_text(encoding="utf-8")
assert "def _v1018_same_seed_value" in paper_source
assert "'stats': _v987_perf_stat(epoch_rows)" in paper_source
print("PASS")
