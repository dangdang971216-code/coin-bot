#!/usr/bin/env python3
# -*- coding: utf-8 -*-

from __future__ import annotations
import json, os, time, math, traceback, urllib.request, concurrent.futures
from pathlib import Path
from typing import Any, Dict, List, Tuple, Optional
BASE_DIR = Path(os.getenv("TRADING_BOT_DIR", "/home/dangdang971216/trading_bot"))
def now_ts() -> float: return time.time()
def now_text(ts: Optional[float]=None) -> str: return time.strftime("%Y-%m-%d %H:%M:%S", time.localtime(ts or now_ts()))
def fnum(*vals: Any, default: float=0.0) -> float:
    for v in vals:
        try:
            if v is None or v == "": continue
            return float(str(v).replace(",", "").replace("%", ""))
        except Exception: continue
    return default
def load_json(path: Path, default: Any=None) -> Any:
    try:
        if not path.exists(): return default
        return json.loads(path.read_text(encoding="utf-8", errors="ignore"))
    except Exception: return default
def save_json(path: Path, obj: Any) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    tmp = path.with_suffix(path.suffix + ".tmp")
    tmp.write_text(json.dumps(obj, ensure_ascii=False, separators=(",", ":"), default=str), encoding="utf-8")
    os.replace(tmp, path)
def append_jsonl(path: Path, obj: Dict[str, Any]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("a", encoding="utf-8") as f:
        f.write(json.dumps(obj, ensure_ascii=False, separators=(",", ":"), default=str)+"\n")
def write_jsonl_atomic(path: Path, rows: List[Dict[str, Any]]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    tmp = path.with_suffix(path.suffix + ".tmp")
    with tmp.open("w", encoding="utf-8") as f:
        for r in rows:
            f.write(json.dumps(r, ensure_ascii=False, separators=(",", ":"), default=str)+"\n")
    os.replace(tmp, path)
def read_jsonl(path: Path, max_lines: int=1000) -> List[Dict[str, Any]]:
    if not path.exists(): return []
    try:
        lines = path.read_text(encoding="utf-8", errors="ignore").splitlines()
        if max_lines and len(lines) > max_lines: lines = lines[-max_lines:]
        out=[]
        for ln in lines:
            try:
                if ln.strip():
                    o=json.loads(ln)
                    if isinstance(o,dict): out.append(o)
            except Exception: pass
        return out
    except Exception: return []
def append_error(path: Path, where: str, exc: BaseException) -> None:
    try:
        path.parent.mkdir(parents=True, exist_ok=True)
        with path.open("a", encoding="utf-8") as f:
            f.write(f"[{now_text()}] {where}: {exc.__class__.__name__}: {exc}\n")
            f.write(traceback.format_exc()[-1500:]+"\n")
    except Exception: pass
def ticker_norm(x: Any) -> str:
    t = str(x or "").strip().upper().replace("/", "-").replace("_", "-")
    parts=[p for p in t.split("-") if p]
    if len(parts)>=2:
        non=[p for p in parts if p != "KRW"]
        t = non[-1] if non else parts[-1]
    if t.endswith("KRW") and len(t)>3: t=t[:-3]
    return t.strip().upper()
def pct(a: float, b: float) -> float: return ((a-b)/b*100.0) if b else 0.0
def age_sec(path: Path) -> float:
    try: return max(0.0, now_ts()-path.stat().st_mtime)
    except Exception: return 999999.0
def map_rows(obj: Any) -> Dict[str, Dict[str, Any]]:
    if isinstance(obj, dict) and isinstance(obj.get("rows"), list): obj = obj.get("rows")
    elif isinstance(obj, dict) and isinstance(obj.get("rows"), dict): obj = obj.get("rows")
    elif isinstance(obj, dict) and isinstance(obj.get("cache"), dict): obj = obj.get("cache")
    out: Dict[str, Dict[str, Any]] = {}
    if isinstance(obj, list):
        for r in obj:
            if isinstance(r, dict):
                t=ticker_norm(r.get("ticker") or r.get("symbol") or r.get("market"))
                if t: out[t]=r
    elif isinstance(obj, dict):
        for k,v in obj.items():
            t=ticker_norm(k)
            if t and isinstance(v, dict):
                vv=dict(v); vv.setdefault("ticker", t); out[t]=vv
    return out

VERSION="candle_worker_v0.15"
INTERVAL_SEC=float(os.getenv("CANDLE_WORKER_INTERVAL_SEC","3.0")); BATCH=int(os.getenv("CANDLE_WORKER_BATCH","12")); HTTP_TIMEOUT=float(os.getenv("CANDLE_WORKER_TIMEOUT","1.2")); MAX_WORKERS=int(os.getenv("CANDLE_WORKER_MAX_WORKERS","4"))
# v607: v606 urgent lane used URGENT_BATCH at runtime without defining it.
# Keep it separate from BATCH so urgent S1/S2/fresh rows cannot be pushed out by broad hot-rank rotation.
URGENT_BATCH=max(1, min(BATCH, int(os.getenv("CANDLE_WORKER_URGENT_BATCH", str(BATCH)))))
STATUS=BASE_DIR/"clean_candle_status.json"; OUT=BASE_DIR/"clean_candle_cache.json"; ERROR=BASE_DIR/"clean_candle_error.log"
POOL=BASE_DIR/"clean_scanner_candidate_pool.json"; STRAT_TARGET=BASE_DIR/"clean_ws_targets.json"; PAPER_LATEST=BASE_DIR/"paper_candidates_latest.jsonl"; PRIORITY_REQ=BASE_DIR/"clean_strategy_priority_requests.json"; CANDIDATE_COMPACT=BASE_DIR/"clean_candidate_reason_compact_cache.json"; SCANNER_HOT=BASE_DIR/"clean_scanner_hot_rank_cache.json"
CANDLE_URGENT_TARGETS=BASE_DIR/"clean_candle_urgent_targets.json"; CANDLE_URGENT_RESULT=BASE_DIR/"clean_candle_urgent_result.json"
def write_status(state:str, **extra:Any)->None: save_json(STATUS,{"version":VERSION,"state":state,"pid":os.getpid(),"updated_ts":now_ts(),"updated_text":now_text(),**extra})
def http_json(url:str)->Any:
    req=urllib.request.Request(url,headers={"Accept":"application/json","User-Agent":"coinbot-candle-worker/0.15"})
    with urllib.request.urlopen(req,timeout=HTTP_TIMEOUT) as r: return json.loads(r.read().decode("utf-8",errors="ignore"))
def _rows_from_any(obj: Any) -> List[Dict[str, Any]]:
    if isinstance(obj, dict):
        for key in ("rows", "display_rows", "items", "top_candidates", "candidates", "requests"):
            val = obj.get(key)
            if isinstance(val, list):
                return [x for x in val if isinstance(x, dict)]
        if isinstance(obj.get("targets"), list):
            return [{"ticker": x} for x in obj.get("targets") if x]
    if isinstance(obj, list):
        return [x for x in obj if isinstance(x, dict)]
    return []

def _append_tickers(out: List[str], rows: List[Dict[str, Any]], limit: int = 999) -> None:
    for r in rows[:limit]:
        t = ticker_norm(r.get("ticker") or r.get("symbol") or r.get("market"))
        if t:
            out.append(t)

def _stage(row: Dict[str, Any]) -> str:
    for k in ("s_stage", "candidate_stage", "candidate_grade", "stage", "grade"):
        v = str(row.get(k) or "").upper()
        if v in ("S1", "S2", "S3"):
            return v
    return ""

def _row_reasons(row: Dict[str, Any]) -> str:
    vals=[]
    # v603: final_trade_state가 "공식 캔들 오래됨"으로 S2 대기인 경우도 candle_worker가 읽어야 한다.
    for k in ("final_trade_reasons", "final_decision", "final_trade_label", "trade_ready_label", "s_stage_reasons", "s2_recheck_reasons", "block_reasons", "missing_info", "risk_tags", "structure_risk_tags"):
        v=row.get(k)
        if isinstance(v,list): vals += [str(x) for x in v]
        elif v not in (None, ""): vals.append(str(v))
    cm=row.get("canonical_metric_row") if isinstance(row.get("canonical_metric_row"),dict) else {}
    if isinstance(cm,dict):
        v=cm.get("final_trade_reasons")
        if isinstance(v,list): vals += [str(x) for x in v]
        elif v not in (None, ""): vals.append(str(v))
    return " ".join(vals).lower()

def _trigger_gap(row: Dict[str, Any]) -> float:
    return abs(fnum(row.get("trigger_gap_pct"), row.get("s2_trigger_gap_pct"), row.get("gap_pct"), default=999.0))

def _needs_candle_fresh(row: Dict[str, Any]) -> bool:
    txt=_row_reasons(row)
    if any(w in txt for w in ("공식 캔들", "공식캔들", "캔들 오래", "candle", "ohlcv")):
        return True
    cm=row.get("canonical_metric_row") if isinstance(row.get("canonical_metric_row"),dict) else {}
    if isinstance(cm,dict):
        state=str(cm.get("final_trade_state") or row.get("final_trade_state") or "")
        reasons=" ".join(str(x) for x in (cm.get("final_trade_reasons") or [])) if isinstance(cm.get("final_trade_reasons"),list) else str(cm.get("final_trade_reasons") or "")
        if state == "S2_RECHECK" and any(w in reasons for w in ("공식 캔들", "공식캔들", "캔들 오래")):
            return True
    return False

def _existing_age_map(existing: Any) -> Dict[str, float]:
    out: Dict[str, float] = {}
    nowv=now_ts()
    for t,r in map_rows(existing).items():
        if not isinstance(r,dict):
            continue
        ts=fnum(r.get("candle_ts"), default=0.0)
        out[t]=max(999999.0 if ts<=0 else 0.0, nowv-ts) if ts<=0 else max(0.0, nowv-ts)
    return out

def _lane_from_bucket(bucket: str) -> str:
    b=str(bucket or '').lower()
    if 'core_' in b or ('s1' in b) or ('s2' in b) or ('fresh_lock' in b):
        return 'core'
    if 'near_' in b or 'trigger_near' in b:
        return 'near'
    if 'watch_' in b or 's3_structure' in b or 's3_hot' in b:
        return 'watch'
    if 'hot' in b or 'spike' in b or 'scanner' in b or 'ws_target' in b:
        return 'broad'
    return 'watch'

def _profile_from_lane(lane: str) -> str:
    return {'core':'full_1m3m5m', 'near':'mid_1m3m', 'watch':'light_1m', 'broad':'light_1m'}.get(str(lane or ''), 'light_1m')

def _bucket_rank(bucket: str) -> int:
    lane=_lane_from_bucket(bucket)
    if lane == 'core': return 950
    if lane == 'near': return 760
    if lane == 'watch': return 520
    b=str(bucket or '').lower()
    if 'hot' in b or 'spike' in b: return 300
    if 'ws_target' in b: return 180
    if 'scanner' in b: return 120
    return 100

def _add_priority(book: Dict[str, Dict[str, Any]], ticker: str, bucket: str, base: float, target_age: float, age_map: Dict[str, float], reason: str="") -> None:
    t=ticker_norm(ticker)
    if not t:
        return
    age=age_map.get(t, 999999.0)
    group_rank=_bucket_rank(bucket)
    lane=_lane_from_bucket(bucket)
    profile=_profile_from_lane(lane)
    stale_bonus=max(0.0, age-target_age)*1.2
    fresh_penalty=220.0 if age < target_age*0.65 else 0.0
    score=base+stale_bonus-fresh_penalty
    final_score=group_rank*10000.0 + score
    cur=book.get(t)
    if (not cur) or final_score>float(cur.get("final_score",-999999)):
        book[t]={"ticker":t,"bucket":bucket,"lane":lane,"profile":profile,"bucket_rank":group_rank,"base":base,"target_age":target_age,"age":round(age,1) if age<999998 else None,"score":round(score,2),"final_score":round(final_score,2),"reason":reason}

def _hot_rows() -> List[Dict[str, Any]]:
    obj=load_json(SCANNER_HOT,{}) or {}
    rows=_rows_from_any(obj)
    # Some hot-rank caches store nested rows under hot/top keys; keep this defensive but do not call APIs here.
    if not rows and isinstance(obj,dict):
        for k,v in obj.items():
            if isinstance(v,list):
                rows += [x for x in v if isinstance(x,dict)]
    return rows

def _v608_urgent_rows() -> List[Dict[str, Any]]:
    obj=load_json(CANDLE_URGENT_TARGETS,{}) or {}
    rows=_rows_from_any(obj)
    out=[]
    for r in rows:
        t=ticker_norm(r.get("ticker") or r.get("symbol") or r.get("market"))
        if not t:
            continue
        rr=dict(r); rr["ticker"]=t
        out.append(rr)
    return out

def _v608_build_urgent_result(urgent_rows: List[Dict[str, Any]], new: List[str], fail: List[Dict[str, Any]], cache: Dict[str, Dict[str, Any]], batch: Optional[List[str]]=None, profile_map: Optional[Dict[str,str]]=None) -> Dict[str, Any]:
    # v611: 요청/선택/API/cache/age 단계별 사유를 남긴다.
    # 이전에는 "미회복"만 보여 원인이 API 실패인지, batch 미선택인지, cache 매칭 실패인지 알 수 없었다.
    nowv=now_ts()
    newset={ticker_norm(x) for x in new}
    batchset={ticker_norm(x) for x in (batch or [])}
    failmap={ticker_norm((x or {}).get("ticker")): str((x or {}).get("error") or "fetch_failed") for x in fail if isinstance(x,dict)}
    rows=[]; ok_under=0; ok_refreshed=0; miss=0
    lane_result: Dict[str, Dict[str, int]] = {}
    reason_counts: Dict[str, int] = {}
    profile_counts: Dict[str, int] = {}
    samples_by_reason: Dict[str, List[str]] = {}
    def add_reason(key: str, ticker: str) -> None:
        reason_counts[key]=reason_counts.get(key,0)+1
        samples_by_reason.setdefault(key, [])
        if len(samples_by_reason[key]) < 8:
            samples_by_reason[key].append(ticker)
    for r in urgent_rows:
        t=ticker_norm(r.get("ticker"))
        if not t:
            continue
        lane=str(r.get('lane') or _lane_from_bucket(str(r.get('bucket') or '')))
        profile=str((profile_map or {}).get(t) or r.get('profile') or _profile_from_lane(lane))
        profile_counts[profile]=profile_counts.get(profile,0)+1
        lr=lane_result.setdefault(lane, {"requested":0,"selected":0,"refreshed":0,"under_target":0,"miss":0,"failed":0,"not_selected":0,"cache_no_ts":0,"stale_after_fetch":0})
        lr["requested"] += 1
        selected = t in batchset
        if selected:
            lr["selected"] += 1
        else:
            lr["not_selected"] += 1
        cr=cache.get(t) if isinstance(cache,dict) else None
        ts=fnum((cr or {}).get("candle_ts"), default=0.0) if isinstance(cr,dict) else 0.0
        age=max(999999.0 if ts<=0 else 0.0, nowv-ts) if ts<=0 else max(0.0, nowv-ts)
        target_age=fnum(r.get("required_age_sec"), r.get("target_age"), default=120.0)
        refreshed=t in newset
        failed=t in failmap
        under=bool(age <= target_age)
        detail="ok_under_target"
        api_error=failmap.get(t)
        if not selected:
            detail="not_selected_this_cycle"; add_reason(detail,t)
        elif failed:
            detail="api_fetch_failed"; add_reason(detail,t); lr["failed"] += 1
        elif refreshed and ts<=0:
            detail="cache_write_no_ts"; add_reason(detail,t); lr["cache_no_ts"] += 1
        elif refreshed and not under:
            detail="stale_after_fetch"; add_reason(detail,t); lr["stale_after_fetch"] += 1
        elif (not refreshed) and not under:
            detail="selected_but_not_refreshed"; add_reason(detail,t)
        elif under and not refreshed:
            detail="already_fresh_from_cache"; add_reason(detail,t)
        else:
            add_reason(detail,t)
        if refreshed:
            ok_refreshed += 1; lr["refreshed"] += 1
        if under:
            ok_under += 1; lr["under_target"] += 1
        if not under:
            miss += 1; lr["miss"] += 1
        rows.append({"ticker":t,"bucket":r.get("bucket"),"lane":lane,"profile":profile,"strategy_reason":r.get("reason"),"target_age":target_age,"age":round(age,1) if age<999998 else None,"selected":selected,"refreshed":refreshed,"under_target_age":under,"failed":failed,"result_reason":detail,"api_error":api_error})
    obj={
        "schema":"candle_urgent_result_v611_reasoned",
        "version":VERSION,
        "updated_ts":nowv,
        "updated_text":now_text(nowv),
        "requested_count":len(rows),
        "selected_count":sum(1 for r in rows if r.get("selected")),
        "refreshed_count":ok_refreshed,
        "under_target_age_count":ok_under,
        "miss_count":miss,
        "reason_counts":reason_counts,
        "samples_by_reason":samples_by_reason,
        "lane_result":lane_result,
        "profile_counts":profile_counts,
        "rows":rows[:160],
        "policy":"v611: no fixed candidate-count cap. Urgent rows keep queued; result records selected/fetch/cache/age reason so fresh_wait failures are explainable.",
    }
    save_json(CANDLE_URGENT_RESULT,obj)
    return obj

def _priority_plan(existing: Any) -> Tuple[List[str], Dict[str, Any]]:
    age_map=_existing_age_map(existing)
    book: Dict[str, Dict[str, Any]] = {}
    paper_rows=read_jsonl(PAPER_LATEST, max_lines=260)
    pri_rows=_rows_from_any(load_json(PRIORITY_REQ,{}) or {})
    compact_rows=_rows_from_any(load_json(CANDIDATE_COMPACT,{}) or {})
    hot_rows=_hot_rows()
    urgent_req_rows=_v608_urgent_rows()

    for r in urgent_req_rows:
        t=ticker_norm(r.get("ticker") or r.get("symbol") or r.get("market"))
        stage=str(r.get("stage") or r.get("candidate_stage") or "S2").upper()
        bucket=str(r.get("bucket") or ("urgent_S1_candle_fresh_lock" if stage=="S1" else "urgent_S2_candle_fresh_lock"))
        target=fnum(r.get("required_age_sec"), r.get("target_age"), default=120.0)
        pri=fnum(r.get("priority"), default=1000.0)
        _add_priority(book,t,bucket,900+min(180,pri*0.05),target,age_map,str(r.get("reason") or "strategy urgent candle fresh lock"))

    for r in paper_rows:
        t=ticker_norm(r.get("ticker") or r.get("symbol") or r.get("market"))
        st=_stage(r)
        txt=_row_reasons(r)
        gap=_trigger_gap(r)
        if st=="S1":
            _add_priority(book,t,"S1/preopen",560,35,age_map,"paper latest S1")
        elif st=="S2" and _needs_candle_fresh(r):
            _add_priority(book,t,"S2_candle_fresh_wait",560,35,age_map,"final_trade_state candle wait")
        elif st=="S2" and gap<=0.60:
            _add_priority(book,t,"S2_trigger_near",450+(0.60-gap)*70,55,age_map,f"trigger_gap {gap:.3f}%")
        elif st=="S2" and ("fresh" in txt or "신선" in txt or "정보" in txt):
            _add_priority(book,t,"S2_fresh_wait",430,55,age_map,"fresh wait")
        elif st=="S2":
            _add_priority(book,t,"S2",350,90,age_map,"paper latest S2")
        elif st=="S3":
            _add_priority(book,t,"S3_watch",210,240,age_map,"paper latest S3")
        elif t:
            _add_priority(book,t,"paper_latest",260,160,age_map,"paper latest")

    for r in pri_rows:
        t=ticker_norm(r.get("ticker") or r.get("symbol") or r.get("market"))
        st=_stage(r)
        pri=fnum(r.get("priority"), default=130.0)
        bucket=str(r.get("bucket") or ("priority_S1" if st=="S1" else "strategy_priority"))
        needs = r.get("need") if isinstance(r.get("need"), list) else []
        low_bucket = bucket.lower()
        if "candle" in [str(x).lower() for x in needs] or "candle" in low_bucket:
            target=30
            base=520+min(220,pri*0.18)
            reason="strategy candle priority request"
        else:
            target=40 if st=="S1" or "s1" in low_bucket else 75
            base=380+min(180,pri)
            reason="strategy priority request"
        _add_priority(book,t,bucket,base,target,age_map,reason)

    for r in compact_rows:
        t=ticker_norm(r.get("ticker") or r.get("symbol") or r.get("market"))
        st=_stage(r)
        gap=_trigger_gap(r)
        if st=="S1": _add_priority(book,t,"compact_S1",500,45,age_map,"candidate_reason compact")
        elif st=="S2" and _needs_candle_fresh(r): _add_priority(book,t,"compact_S2_candle_wait",500,35,age_map,"candidate_reason candle wait")
        elif st=="S2" and gap<=0.80: _add_priority(book,t,"compact_S2_near",390,65,age_map,"candidate_reason compact")
        elif st=="S2": _add_priority(book,t,"compact_S2",300,130,age_map,"candidate_reason compact")

    for r in hot_rows[:120]:
        t=ticker_norm(r.get("ticker") or r.get("symbol") or r.get("market"))
        ch=max(abs(fnum(r.get("change_1m_pct"), r.get("chg_1m"), r.get("m1"), default=0.0)), abs(fnum(r.get("change_3m_pct"), r.get("chg_3m"), r.get("m3"), default=0.0)))
        _add_priority(book,t,"hot_rank_recent",260+min(80,ch*8),120,age_map,f"hot_rank {ch:.2f}%")

    o=load_json(STRAT_TARGET,{}) or {}; raw=o.get("targets") if isinstance(o,dict) else []
    if isinstance(raw,list):
        for x in raw:
            _add_priority(book,ticker_norm(x),"ws_target_rotate",120,360,age_map,"ws target rotate")
    p=load_json(POOL,{}) or {}; rows=p.get("rows") if isinstance(p,dict) else []
    if isinstance(rows,list):
        for r in rows:
            _add_priority(book,ticker_norm(r.get("ticker")),"scanner_universe",90,480,age_map,"scanner universe rotate")

    ranked=sorted(book.values(), key=lambda x:(float(x.get("final_score", x.get("score",0))), float(x.get("score",0)), float(x.get("base",0))), reverse=True)
    # v610: 고정 개수 제한 금지. 전체 대상은 유지하고, 실제 갱신은 아래 tier/batch 시간예산으로 순환 처리한다.
    targets=[x["ticker"] for x in ranked if x.get("ticker")]
    counts: Dict[str,int] = {}
    lane_counts: Dict[str,int] = {}
    for x in ranked:
        b=str(x.get("bucket") or "unknown")
        counts[b]=counts.get(b,0)+1
        ln=str(x.get("lane") or _lane_from_bucket(b))
        lane_counts[ln]=lane_counts.get(ln,0)+1
    urgent=[x for x in ranked if int(x.get("bucket_rank",0))>=400]
    diag={"schema":"candle_priority_plan_v611_reasoned", "policy":"no fixed candidate-count cap; core/near/watch information-tier candle budget. Core rows get full 1m/3m/5m; near gets 1m/3m; watch gets light 1m. Batch is per-cycle server time budget, not strategy/candidate cap.", "target_count":len(targets), "urgent_count":len(urgent), "bucket_counts":counts, "lane_counts":lane_counts, "top":ranked[:20], "urgent_top":urgent[:40], "plan_rows":ranked[:160]}
    return targets, diag

def pick_targets(existing: Any=None)->List[str]:
    targets, _diag = _priority_plan(existing or load_json(OUT,{}) or {})
    return targets
def parse_candles(payload:Any)->List[List[float]]:
    data=payload.get("data") if isinstance(payload,dict) else payload
    if not isinstance(data,list): return []
    out=[]
    for x in data[-40:]:
        try:
            # Bithumb 구 candle: [time, open, close, high, low, volume]
            if isinstance(x,(list,tuple)) and len(x)>=6:
                vals=[fnum(x[1]),fnum(x[2]),fnum(x[3]),fnum(x[4]),fnum(x[5])]
                if vals[0] and vals[1]: out.append(vals)
        except Exception: pass
    return out
def _ema(vals: List[float], period: int) -> float:
    if not vals: return 0.0
    k=2.0/(period+1.0); e=float(vals[0])
    for v in vals[1:]: e=float(v)*k+e*(1.0-k)
    return e

def _vwap(c: List[List[float]]) -> float:
    pv=0.0; vv=0.0
    for op,cl,hi,lo,vol in c:
        tp=(hi+lo+cl)/3.0
        pv += tp*max(vol,0.0); vv += max(vol,0.0)
    return pv/vv if vv else 0.0

def _touch_count(c: List[List[float]], level: float, side: str, tol_pct: float=0.18) -> int:
    if not level: return 0
    tol=abs(level)*tol_pct/100.0
    cnt=0
    for op,cl,hi,lo,vol in c:
        if side=='support' and lo <= level+tol and cl >= level-tol: cnt+=1
        elif side=='resistance' and hi >= level-tol and cl <= level+tol: cnt+=1
    return cnt

def candle_features(c:List[List[float]])->Dict[str,Any]:
    if len(c)<3: return {}
    op,cl,hi,lo,vol = c[-1]
    prev= c[-2][1]
    ch1=pct(cl, prev); ch3=pct(cl, c[-3][1]) if len(c)>=3 else ch1; ch5=pct(cl, c[-5][1]) if len(c)>=5 else ch3
    rng=max(hi-lo, 1e-12); body=abs(cl-op)/rng*100; upper=(hi-max(op,cl))/rng*100; lower=(min(op,cl)-lo)/rng*100
    recent=c[-min(12,len(c)):]
    longer=c[-min(24,len(c)):]
    vols=[x[4] for x in c[-8:]]; vavg=sum(vols[:-1])/max(1,len(vols)-1); vr=vol/vavg if vavg else 0
    closes=[x[1] for x in c]
    recent_high=max(x[2] for x in recent); recent_low=min(x[3] for x in recent)
    box_high=max(x[2] for x in longer); box_low=min(x[3] for x in longer)
    swing_high=recent_high; swing_low=recent_low
    vw=_vwap(longer); ema5=_ema(closes[-20:],5); ema10=_ema(closes[-25:],10); ema20=_ema(closes[-35:],20)
    support_touches=_touch_count(recent, recent_low, 'support')
    resistance_touches=_touch_count(recent, recent_high, 'resistance')
    prev_vol_avg=sum([x[4] for x in c[-7:-1]])/max(1,len(c[-7:-1]))
    pullback_contract = bool(cl < op and prev_vol_avg and vol <= prev_vol_avg*0.85)
    reclaim_expand = bool(cl > op and vr >= 1.15 and lower >= 25)
    close_near_high = upper < 25 and cl >= op
    long_upper = upper > 45
    breakout = cl>=recent_high*0.998 and vr>=1.15
    sweep = lower>35 and cl>op and vr>=1.0
    return {
        "candle_change_1":round(ch1,3),"candle_change_3":round(ch3,3),"candle_change_5":round(ch5,3),
        "candle_body_pct":round(body,1),"upper_wick_pct":round(upper,1),"lower_wick_pct":round(lower,1),
        "volume_ratio":round(vr,2),"volume_expansion_pct":round((vr-1.0)*100.0,1),
        "recent_high_gap_pct":round(pct(cl,recent_high),3),"recent_low_rebound_pct":round(pct(cl,recent_low),3),
        "recent_high_price":round(recent_high,8),"recent_low_price":round(recent_low,8),
        "swing_high_price":round(swing_high,8),"swing_low_price":round(swing_low,8),
        "box_high_price":round(box_high,8),"box_low_price":round(box_low,8),
        "support_touch_count":support_touches,"resistance_touch_count":resistance_touches,
        "vwap_price":round(vw,8) if vw else None,"vwap_gap_pct":round(pct(cl,vw),3) if vw else None,
        "ema5_price":round(ema5,8) if ema5 else None,"ema10_price":round(ema10,8) if ema10 else None,"ema20_price":round(ema20,8) if ema20 else None,
        "ema5_gap_pct":round(pct(cl,ema5),3) if ema5 else None,"ema10_gap_pct":round(pct(cl,ema10),3) if ema10 else None,"ema20_gap_pct":round(pct(cl,ema20),3) if ema20 else None,
        "close_near_high": close_near_high,"long_upper_wick": long_upper,"volume_expanding": vr>=1.25,
        "breakout_hint": breakout,"box_breakout_hint": bool(cl>=box_high*0.998 and vr>=1.10),
        "sweep_reclaim_hint": sweep,"support_reclaim_hint": bool((support_touches>=1 and lower>=25 and cl>op) or sweep),
        "resistance_reject_hint": bool(resistance_touches>=1 and upper>=35 and cl<hi),
        "pullback_volume_contract": pullback_contract,"reclaim_volume_expand": reclaim_expand,
        "official_structure_schema":"official_ohlcv_structure_inputs_v596"}
def fetch_one(ticker:str, prev: Optional[Dict[str,Any]]=None, profile: str="full_1m3m5m")->Dict[str,Any]:
    base=f"https://api.bithumb.com/public/candlestick/{ticker}_KRW"
    prev = prev if isinstance(prev, dict) else {}
    profile=str(profile or "light_1m")
    feats={"ticker":ticker,"candle_ts":now_ts(),"candle_refresh_profile":profile}
    prev_ts=fnum(prev.get("candle_ts"), default=0.0)
    prev_age=max(999999.0 if prev_ts<=0 else 0.0, now_ts()-prev_ts) if prev_ts<=0 else max(0.0, now_ts()-prev_ts)
    if profile == "full_1m3m5m":
        intervals=[("1m","m1"),("3m","m3"),("5m","m5")]
    elif profile == "mid_1m3m":
        intervals=[("1m","m1"),("3m","m3")]
        # near 후보는 5m가 아예 없거나 매우 오래됐을 때만 보강한다.
        if (not prev.get("m5_ok")) or prev_age>600:
            intervals.append(("5m","m5"))
    else:
        intervals=[("1m","m1")]
        # watch 후보는 최소 정보만 갱신한다. 3m/5m는 없는 경우에만 보강해 API를 아낀다.
        if not prev.get("m3_ok"):
            intervals.append(("3m","m3"))
    if profile == "full_1m3m5m" and ((not prev.get("m30_ok")) or prev_age>900):
        intervals.append(("30m","m30"))
    fetched_prefixes={key for _interval,key in intervals}
    for interval,key in intervals:
        try:
            c=parse_candles(http_json(base+"/"+interval)); cf=candle_features(c)
            for k,v in cf.items(): feats[f"{key}_{k}"]=v
            feats[f"{key}_ok"]=bool(cf)
        except Exception as exc:
            feats[f"{key}_ok"]=False; feats[f"{key}_err"]=str(exc)[:60]
    # 스킵한 interval은 이전 값을 보존한다. 낮은 후보는 가벼운 정보만 새로 붙이고, 기존 긴 구조재료는 지우지 않는다.
    for pfx in ("m1","m3","m5","m30"):
        if pfx in fetched_prefixes:
            continue
        for k,v in prev.items():
            if str(k).startswith(pfx+"_"):
                feats[k]=v
    feats["fast_interval_policy"]="v611: core=1m/3m/5m, near=1m/3m, watch=1m minimum; skipped interval fields preserve previous cache. Failure reasons are written to urgent_result. No strategy thresholds changed."
    return feats

def _pick_tiered_batch(priority_diag: Dict[str, Any], targets: List[str]) -> Tuple[List[str], Dict[str, str], Dict[str, int]]:
    rows=priority_diag.get("plan_rows") if isinstance(priority_diag.get("plan_rows"), list) else []
    if not rows:
        rows=priority_diag.get("urgent_top") if isinstance(priority_diag.get("urgent_top"), list) else []
    seen=set(); lanes={"core":[],"near":[],"watch":[],"broad":[]}; profiles: Dict[str,str] = {}
    for r in rows:
        if not isinstance(r,dict): continue
        t=ticker_norm(r.get("ticker"))
        if not t or t in seen: continue
        lane=str(r.get("lane") or _lane_from_bucket(str(r.get("bucket") or "")))
        if lane not in lanes: lane="broad"
        lanes[lane].append(t); profiles[t]=str(r.get("profile") or _profile_from_lane(lane)); seen.add(t)
    # v610: core는 가능한 한 먼저 채운다. 남는 시간/배치만 near/watch/broad에 쓴다.
    batch=[]
    def take(name: str, n: int) -> None:
        nonlocal batch
        for t in lanes.get(name, []):
            if len(batch) >= BATCH or len([x for x in batch if x in lanes.get(name,[])]) >= n: break
            if t not in batch: batch.append(t)
    core_quota=min(BATCH, max(len(lanes["core"]), 0))
    take("core", core_quota)
    remain=BATCH-len(batch)
    if remain>0:
        near_quota = remain if not lanes["core"] else max(1, min(remain, max(1, BATCH//3)))
        take("near", near_quota)
    remain=BATCH-len(batch)
    if remain>0:
        watch_quota = max(0, min(remain, max(1, BATCH//4)))
        take("watch", watch_quota)
    remain=BATCH-len(batch)
    if remain>0:
        for t in targets:
            if t not in batch:
                batch.append(t); profiles.setdefault(t, "light_1m")
            if len(batch)>=BATCH: break
    selected_counts={"core":sum(1 for t in batch if t in lanes["core"]),"near":sum(1 for t in batch if t in lanes["near"]),"watch":sum(1 for t in batch if t in lanes["watch"]),"broad":sum(1 for t in batch if t in lanes["broad"])}
    return list(dict.fromkeys(batch)), profiles, selected_counts

def run_once()->Dict[str,Any]:
    st=now_ts(); existing=load_json(OUT,{}) or {}; cache=map_rows(existing)
    targets, priority_diag = _priority_plan(existing)
    batch, profile_map, selected_counts = _pick_tiered_batch(priority_diag, targets)
    new=[]; fail=[]
    write_status("running", phase="fetching_v611_reasoned_urgent", row_count=len(cache), target_count=len(targets), batch=len(batch), tier_selected=selected_counts, max_workers=MAX_WORKERS, last_sec=0, priority_policy="v611 reasoned urgent candle budget; core first, near/watch tiered, failure reasons saved", priority_bucket_counts=priority_diag.get("bucket_counts",{}), priority_lane_counts=priority_diag.get("lane_counts",{}), priority_top=priority_diag.get("top",[])[:5])
    def _job(t:str)->Tuple[str, Optional[Dict[str,Any]], Optional[str]]:
        try:
            return t, fetch_one(t, cache.get(t), profile_map.get(t,"light_1m")), None
        except Exception as exc:
            return t, None, f"{exc.__class__.__name__}: {str(exc)[:80]}"
    workers=max(1, min(MAX_WORKERS, len(batch) or 1))
    with concurrent.futures.ThreadPoolExecutor(max_workers=workers) as ex:
        futs=[ex.submit(_job,t) for t in batch]
        for fut in concurrent.futures.as_completed(futs):
            t,row,err=fut.result()
            if row:
                cache[t]=row; new.append(t)
            elif err:
                fail.append({"ticker":t,"error":err})
    cutoff=now_ts()-1200
    rows=[v for v in cache.values() if fnum(v.get("candle_ts"),default=0)>=cutoff]
    rows.sort(key=lambda r:fnum(r.get("candle_ts")), reverse=True)
    ages=[max(0.0, now_ts()-fnum(r.get("candle_ts"),default=0.0)) for r in rows if fnum(r.get("candle_ts"),default=0.0)>0]
    age_diag={"avg":round(sum(ages)/len(ages),1) if ages else None,"under_120":sum(1 for a in ages if a<=120),"over_300":sum(1 for a in ages if a>300),"max":round(max(ages),1) if ages else None}
    next_idx=0
    urgent_plan_rows=_v608_urgent_rows()
    urgent_result=_v608_build_urgent_result(urgent_plan_rows, new, fail, cache, batch=batch, profile_map=profile_map)
    save_json(OUT,{"version":VERSION,"schema":"candle_cache_v611_reasoned_urgent","updated_ts":now_ts(),"updated_text":now_text(),"row_count":len(rows),"target_count":len(targets),"cursor":next_idx,"updated_batch":new,"failed_batch":fail[:8],"age_diag":age_diag,"priority_plan":priority_diag,"tier_selected":selected_counts,"profile_map_sample":{k:profile_map.get(k) for k in batch[:20]},"urgent_result":urgent_result,"rows":rows})
    sec=now_ts()-st; write_status("running", phase="done_v611_reasoned_urgent", row_count=len(rows), target_count=len(targets), batch=len(new), failed=len(fail), tier_selected=selected_counts, max_workers=workers, last_sec=round(sec,3), updated_batch=new, failed_batch=fail[:5], age_diag=age_diag, urgent_result=urgent_result, priority_policy=priority_diag.get("policy"), priority_bucket_counts=priority_diag.get("bucket_counts",{}), priority_lane_counts=priority_diag.get("lane_counts",{}), priority_top=priority_diag.get("top",[])[:8])
    return {"rows":len(rows),"sec":sec}

def main()->None:
    # systemd/guard가 initializing에서 timeout으로 오판하지 않도록 즉시 running 상태를 남긴다.
    existing=load_json(OUT,{}) or {}; cache=map_rows(existing)
    write_status("running", phase="boot_v611_reasoned_urgent", row_count=len(cache), target_count=0, batch=0, last_sec=0, priority_policy="v611 reasoned urgent candle refresh")
    while True:
        try: run_once()
        except KeyboardInterrupt: write_status("stopping"); raise
        except Exception as exc: append_error(ERROR,"loop",exc); write_status("error", error=f"{exc.__class__.__name__}: {exc}")
        time.sleep(max(1.0,INTERVAL_SEC))
if __name__=="__main__": main()
