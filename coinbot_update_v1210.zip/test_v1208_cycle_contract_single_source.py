import importlib.util
import json
import os
import sys
import tempfile
import time
import unittest
from pathlib import Path
from unittest import mock

ROOT=Path(__file__).resolve().parent
sys.path.insert(0,str(ROOT))

def load(name, filename):
    spec=importlib.util.spec_from_file_location(name,ROOT/filename)
    mod=importlib.util.module_from_spec(spec); assert spec and spec.loader
    sys.modules[name]=mod
    spec.loader.exec_module(mod)
    return mod

paper=load('paper_v1208_test','paper_bot_v1.061.py')
strategy=load('strategy_v1208_test','strategy_worker_v1.042.py')
spine=load('spine_v1208_test','canonical_spine_v1187.py')
ops=load('ops_v1208_test','canonical_spine_v1190.py')


def candidates(cycle='cy1', commit='co1', n=5, runner_index=None):
    rows=[]
    for i in range(n):
        row={
            'ticker':f'KRW-T{i}','strategy_name':f's{i%2}','rank_score':100-i,
            'target_room_pct':12-i,'actual_entry_rr':3+i,'entry_price':100+i,
            'runner_pass':i==runner_index,'pipeline_cycle_id':cycle,
            'candidate_commit_id':commit,'decision_key':f'd-{cycle}-{i}',
            'spread_pct':0.1,'slippage_pct':0.05,'trigger_chase_pct':0.0,
        }
        if i==runner_index:
            row['target_room_pct']=20.0
        rows.append((f'p{i}',row))
    return rows


class V1208Tests(unittest.TestCase):
    def test_rank_is_max_two_and_deferred_rows_are_not_reused(self):
        selected,e=paper.rank_executable_candidates_for_open(candidates(),{},2)
        self.assertEqual(len(selected),2)
        self.assertEqual(e['cycle_deferred_count'],3)
        self.assertTrue(all(x['reason']=='cycle_new_open_limit_v1208' for x in e['not_selected_sample']))
        self.assertTrue(all('next Strategy cycle' in x['recheck_policy'] for x in e['not_selected_sample']))

    def test_runner_can_use_one_of_two_without_general_backfill_of_runner_slot(self):
        selected,e=paper.rank_executable_candidates_for_open(candidates(runner_index=3),{},2)
        self.assertEqual(len(selected),2)
        self.assertEqual(sum(1 for _,r in selected if r['ranked_top10_slot_role_v1206']=='runner'),1)
        selected2,e2=paper.rank_executable_candidates_for_open(candidates(runner_index=None),{},2)
        self.assertEqual(len(selected2),2)
        self.assertTrue(e2['runner_slot_empty'])

    def test_same_strategy_generation_cannot_open_more_than_two(self):
        with tempfile.TemporaryDirectory() as td:
            root=Path(td)
            old_state,old_ledger=paper.V1206_TOP10_STATE,paper.V1206_TOP10_LEDGER
            old_prev,old_active=paper._V1206_PREV_SELECT_CANDIDATES,paper._v1206_ranked_active
            old_digest=paper._V1206_LAST_LEDGER_DIGEST
            try:
                paper.V1206_TOP10_STATE=root/'state.json'
                paper.V1206_TOP10_LEDGER=root/'ledger.jsonl'
                paper._V1206_LAST_LEDGER_DIGEST=''
                paper._v1206_ranked_active=lambda: True
                rows=candidates('cy1','co1')
                paper._V1206_PREV_SELECT_CANDIDATES=lambda ctrl,open_pos:(rows,{},None)
                first,_,_=paper.select_candidates__v1208_ranked_top10_cycle2({}, {})
                second,stats,_=paper.select_candidates__v1208_ranked_top10_cycle2({}, {})
                self.assertEqual(len(first),2)
                self.assertEqual(len(second),0)
                self.assertEqual(stats['cycle_new_open_deferred_v1208'],5)
                rows[:] = candidates('cy2','co2')
                third,_,_=paper.select_candidates__v1208_ranked_top10_cycle2({}, {})
                self.assertEqual(len(third),2)
            finally:
                paper.V1206_TOP10_STATE, paper.V1206_TOP10_LEDGER=old_state,old_ledger
                paper._V1206_PREV_SELECT_CANDIDATES,paper._v1206_ranked_active=old_prev,old_active
                paper._V1206_LAST_LEDGER_DIGEST=old_digest

    def test_new_open_seals_cycle_rank_and_actual_entry_evidence(self):
        base={'ticker':'KRW-X','entry_price':100.0,'current_price':100.0}
        ev={
            'ticker':'KRW-X','entry_price':100.0,'actual_entry_rr':4.2,'target_room_pct':12.0,
            'trigger_chase_pct':0.1,'spread_pct':0.2,'slippage_pct':0.05,'roundtrip_cost_pct':0.35,
            'ranked_top10_slot_role_v1206':'general','ranked_top10_strategy_v1206':'base',
            'ranked_top10_strategy_rank_v1206':1,'ranked_top10_cycle_rank_v1208':2,
            'candidate_pipeline_cycle_id_v1208':'cy','candidate_commit_id_v1208':'co','decision_key':'d1',
        }
        with mock.patch.object(paper,'_V1206_PREV_OPEN_POSITION',return_value=dict(base)):
            row=paper.open_position__v1206_ranked_contract('p1',ev)
        contract=row['ranked_top10_contract_v1206']
        self.assertEqual(contract['schema'],'paper_ranked_top10_open_contract_v1208')
        self.assertEqual(contract['cycle_new_open_cap'],2)
        self.assertEqual(contract['cycle_selection_rank'],2)
        self.assertEqual(contract['pipeline_cycle_id'],'cy')
        self.assertEqual(contract['candidate_commit_id'],'co')
        self.assertAlmostEqual(contract['actual_entry_evidence']['actual_rr'],4.2)
        self.assertFalse(contract['deferred_rows_reused'])

    def test_active_contract_snapshot_is_single_truth(self):
        with mock.patch.object(paper,'load_json',return_value={}), \
             mock.patch.object(paper,'_v1206_ranked_active',return_value=True), \
             mock.patch.object(paper,'_v1206_active_epoch',return_value={'epoch_id':'ep'}), \
             mock.patch.object(paper,'_v1204_read_control',return_value={'pause_new_open':False}), \
             mock.patch.object(paper,'_v1205_reset_thread_alive',return_value=False):
            snap=paper._v1208_active_contract_payload({})
        self.assertEqual(snap['schema'],'paper_active_trade_contract_v1208')
        self.assertEqual(snap['entry']['total_cap'],10)
        self.assertEqual(snap['entry']['cycle_new_open_cap'],2)
        self.assertEqual(snap['exit']['state'],'ACTIVE_FOR_NEW_OPEN')
        summary=spine._paper_contract_summary({'active_contract_v1208':snap})
        self.assertEqual(summary['cycle_new_open_cap'],2)
        self.assertEqual(summary['contract_digest'],snap['contract_digest'])

    def test_reset_status_removes_old_warning_after_ranked_activation(self):
        with mock.patch.object(paper,'_v1204_read_control',return_value={'pause_new_open':False}), \
             mock.patch.object(paper,'load_json',return_value={'state':'ACTIVE_RANKED_TOP10_V1206'}), \
             mock.patch.object(paper,'load_open',return_value={}), \
             mock.patch.object(paper,'_v1205_reset_thread_alive',return_value=False), \
             mock.patch.object(paper,'_v1206_ranked_active',return_value=True):
            text=paper._v1205_reset_status_text()
        self.assertIn('TOP10 본선 활성화',text)
        self.assertNotIn('TOP10 본선 적용 전에는 신규 진입 재시작이 잠겨',text)

    def test_strategy_seals_owner_values_and_scanner_occurrence(self):
        row={'ticker':'KRW-X','below_high_pct':3.2,'current_close_pos_ratio':71.5}
        hot={'X':{'hot_watch_started_ts_v945':1234.0,'hot_watch_occurrence_key_v945':'occ-1'}}
        strategy._v1208_seal_owner_evidence(row,hot)
        self.assertEqual(row['recent_high_gap_pct'],3.2)
        self.assertEqual(row['day_pos_pct'],71.5)
        self.assertEqual(row['scanner_occurrence_started_ts_v1203'],1234.0)
        self.assertEqual(row['scanner_occurrence_key_v1203'],'occ-1')

    def test_old_pid_phase_profile_is_historical_even_when_old(self):
        with tempfile.TemporaryDirectory() as td:
            base=Path(td); (base/'runtime').mkdir()
            now=time.time()
            profile={
                'pid':111,'version':'paper-old','scopes':{
                    'execution_core':{'state':'NORMAL','total_sec':1.0,'completed_ts':now-1000,'window_count':3,'window_avg_sec':1.0}
                }
            }
            path=base/'runtime/runtime_phase_profile_paper_v1190.json'
            path.write_text(json.dumps(profile),encoding='utf-8')
            os.utime(path,(now-1000,now-1000))
            runtime={'components':[{'component':'paper','main_pid':222,'status_version':'paper-new','status_age_sec':1.0}]}
            result=ops._phase_profile_summary(base,now,runtime)
            paper_row=next(x for x in result['components'] if x['component']=='paper')
            self.assertEqual(paper_row['state'],'NORMAL')
            self.assertIn('이전 PID·버전',paper_row['reason'])

    def test_closed_append_stale_is_event_idle_when_no_close_pending(self):
        with tempfile.TemporaryDirectory() as td:
            base=Path(td); now=time.time()
            closed=base/'paper_closed_append_status_v925.json'
            closed.write_text(json.dumps({'state':'NORMAL'}),encoding='utf-8')
            os.utime(closed,(now-1000,now-1000))
            (base/'paper_bot_status.json').write_text(json.dumps({'closed_this_cycle':0}),encoding='utf-8')
            result=ops._artifact_chain_summary(base,now,{}, {}, {}, {}, {})
            self.assertIn('closed_append',result['event_driven_idle_artifacts_v1208'])
            self.assertNotIn('closed_append',result['stale_artifacts'])

    def test_main_has_no_unlimited_contract_display(self):
        text=(ROOT/'coinbot_main_v2_13_1139.py').read_text(encoding='utf-8')
        self.assertNotIn('후보·OPEN·cycle 개수 제한 없음',text)
        self.assertNotIn('OPEN 한도 무제한 / cycle 한도 무제한',text)
        self.assertIn('paper_active_contract_snapshot_v1208.json',text)
        self.assertIn('cycle당 신규',text)


if __name__=='__main__':
    unittest.main(verbosity=2)
