코인봇 업데이트 v1210
======================
목적: 후보·전체시장 감시를 줄이지 않고 Paper/Micro/Strategy의 중복 저장·요청·계산을 제거합니다.

핵심 파일
- paper_bot_v1.061.py
- bithumb_micro_sidecar_v0.17.py
- strategy_worker_v1.042.py
- coinbot_main_v2_13_1139.py
- backga_guard_bot_v2_5_208.py
- canonical_spine_v1190.py

거래계약
- 후보식/S1/trigger/invalid/target/RR 변경 없음
- TOP10 10/9/1, 같은 Strategy generation 신규 2 유지
- v1207 동적청산 및 기존 OPEN 봉인계약 유지
- 자동매수 OFF

검수
- 로컬 58/58 PASS
- 서버 적용 전 CHECK
- 자세한 원인·검수는 docs/V1210_WORK_LOCK_AND_ROOT_CAUSE.txt와 EXACT_AUDIT_SUMMARY_V1210.json 참고
