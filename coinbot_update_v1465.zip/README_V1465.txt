coinbot_update_v1465

목적:
- v1464에서 module_load 빈 owner가 ACTIVE처럼 보이는 문제 제거.
- Paper select_candidates live cycle만 후보흐름 주인으로 인정.
- candidate_flow / trigger_selector / s2_recheck는 paper_candidate_selection_live_owner_v1465.json만 읽음.
- protection_audit는 candidate/current row가 아니라 canonical CLOSED exact row에서 PEAQ의 봉인 invalid/target을 읽음.
- 자동매수 OFF. 기준완화/BUY_READY강제/OPEN강제/청산계약 변경 없음.

검수:
/gupgrade_bundle
/grelease_verify
/source_owner
/candidate_flow
/trigger_selector
/s2_recheck
/protection_audit
/version_score
/errorlog
