v2113은 compact 후보 JSONL 덮어쓰기, current cycle 증명, Paper 0개 S1 owner, Review 전체 후보 계약 coverage, 오래된 성과의 현재값 표시, Shadow ACTIVE 합계를 수리한다. 전략·진입·청산 수치와 기존 원장은 변경하지 않는다. 서버 검증 전 CHECK, 자동매수 OFF.
