v938 적용본
- 바로역행/반납/10분 대용 결과 원인분해
- first/S1/trigger exact timing 봉인
- 적용: 가드봇 /gupgrade_bundle
- 검수: 메인봇 /batch
