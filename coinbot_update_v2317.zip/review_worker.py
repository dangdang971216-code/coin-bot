#!/usr/bin/env python3
# -*- coding: utf-8 -*-
from __future__ import annotations
import atexit, fcntl, hashlib, json, math, os, resource, sys, time, traceback
from collections import deque
from collections import Counter
from pathlib import Path
from typing import Any, Dict, Iterable, List, Optional, Tuple

BASE_DIR=Path(os.getenv('TRADING_BOT_DIR','/home/dangdang971216/trading_bot'))
VERSION='review_worker_v2.104'
BUILD_LABEL='v2245_defer_module_ledger_io_identity_first_2026-07-27'
INTERVAL_SEC=max(5.0,float(os.getenv('REVIEW_WORKER_INTERVAL_SEC','30')))
STATUS=BASE_DIR/'clean_review_worker_status.json'
ERROR=BASE_DIR/'clean_review_worker_error.log'
PAPER_LATEST=BASE_DIR/'paper_candidates_latest.jsonl'
OPEN_PATH=BASE_DIR/'paper_v2_exact_open_v2135.json'
CLOSED_PATH=BASE_DIR/'paper_v2_exact_closed_v2135.jsonl'
OUTCOME_STATE=BASE_DIR/'strategy_v2_outcome_state_v2133.json'
OUTCOME_STATUS=BASE_DIR/'strategy_v2_outcome_status_v2133.json'
OUTCOME_LEDGER=BASE_DIR/'strategy_v2_outcomes_v2133.jsonl'
CHANGE_LEDGER=BASE_DIR/'runtime'/'change_verify_ledger.jsonl'
ISSUE_LEDGER=BASE_DIR/'ledger'/'issue_ledger_events.jsonl'
LOCK_PATH=BASE_DIR/'runtime'/'review_worker_singleton_v1121.lock'
# v2246: derived-cache cleanup is owned by Guard after zero-process proof.
GENERATION='ALT_SWING_V2_COMBINED_V2149_RESET_20260722'
STATE_KEY='v2149_rows'
HORIZONS=(('5m',300.0),('15m',900.0),('30m',1800.0),('1h',3600.0),('3h',10800.0),('6h',21600.0))
MODEL_GENERATION_FALLBACK=''
STATE_CHECKPOINT_SEC=max(60.0,float(os.getenv('REVIEW_STATE_CHECKPOINT_SEC_V2168','120')))
STRATEGY_STATUS=BASE_DIR/'clean_strategy_worker_status.json'
STRATEGY_DECISION_STATUS=BASE_DIR/'strategy_v2_decision_status_v2133.json'
SHADOW_WRITERS_REMOVED=(
    'trigger_shadow_v665','quality_shadow_v1125','smart_structure_shadow_v948',
    'unified_shadow_v2010','entry_survival_shadow_v2014','top10_shadow_v2015_v2019',
    'c_break_retest_performance_shadow','open_limit_shadow'
)
_LOCK_FH=None


def now_ts()->float:return time.time()
def now_text(ts:Optional[float]=None)->str:
    return time.strftime('%Y-%m-%d %H:%M:%S',time.localtime(ts or now_ts()))

def _atomic_json(path:Path,obj:Any)->None:
    path.parent.mkdir(parents=True,exist_ok=True)
    tmp=path.with_name(path.name+f'.tmp.{os.getpid()}')
    tmp.write_text(json.dumps(obj,ensure_ascii=False,separators=(',',':')),encoding='utf-8')
    os.replace(tmp,path)

def load_json(path:Path,default:Any)->Any:
    try:return json.loads(path.read_text(encoding='utf-8'))
    except Exception:return default

def read_jsonl(path:Path,max_lines:int=10000)->List[Dict[str,Any]]:
    if not path.exists():return []
    try:
        with path.open('r',encoding='utf-8',errors='ignore') as f:
            lines=deque(f,maxlen=max_lines)
    except Exception:return []
    out=[]
    for line in lines:
        try:
            row=json.loads(line)
            if isinstance(row,dict):out.append(row)
        except Exception:pass
    return out

def append_jsonl(path:Path,row:Dict[str,Any])->None:
    path.parent.mkdir(parents=True,exist_ok=True)
    with path.open('a',encoding='utf-8') as f:
        f.write(json.dumps(row,ensure_ascii=False,separators=(',',':'))+'\n')
        f.flush();os.fsync(f.fileno())

def append_error(where:str,exc:BaseException)->None:
    ERROR.parent.mkdir(parents=True,exist_ok=True)
    with ERROR.open('a',encoding='utf-8') as f:
        f.write(f'[{now_text()}] {where}: {type(exc).__name__}: {exc}\n')
        f.write(traceback.format_exc()+'\n')

def num(v:Any,default:Optional[float]=None)->Optional[float]:
    try:
        if v in (None,'') or isinstance(v,bool):return default
        x=float(v);return x if math.isfinite(x) else default
    except Exception:return default

def ticker(v:Any)->str:
    s=str(v or '').upper().strip().replace('KRW-','').replace('_KRW','').replace('/KRW','')
    return s

def contract_of(row:Dict[str,Any])->Dict[str,Any]:
    c=row.get('trade_path_contract_v2149')
    return c if isinstance(c,dict) and str(c.get('generation') or '')==GENERATION else {}

def open_contract(row:Dict[str,Any])->Dict[str,Any]:
    c=row.get('trade_path_contract_v2149_at_open')
    return c if isinstance(c,dict) else {}

def row_price(row:Dict[str,Any])->Optional[float]:
    for k in ('current_price','price','last_price','close','trade_price','market_price'):
        x=num(row.get(k))
        if x and x>0:return x
    c=contract_of(row);s=c.get('structure') if isinstance(c.get('structure'),dict) else {}
    x=num(s.get('current_price'))
    return x if x and x>0 else None

def exact_decision_keys(row:Dict[str,Any],contract:Optional[Dict[str,Any]]=None)->List[str]:
    c=contract if isinstance(contract,dict) else {}
    vals=(
        c.get('decision_key'),row.get('direct_decision_key_v2149'),row.get('direct_decision_key'),
        row.get('paper_decision_key_v926'),row.get('swing_gate_decision_key_v977'),
        row.get('source_decision_key'),row.get('decision_key'),
    )
    out=[]
    for v in vals:
        s=str(v or '').strip()
        if s and s not in out:out.append(s)
    return out

def plan_from_decision(decision:str)->str:
    # v2149:<ticker>:<plan_hash>:<trigger_event_ms>
    parts=str(decision or '').split(':')
    return 'v2149-plan:'+parts[-2] if len(parts)>=4 and parts[0]=='v2149' and parts[-2] else ''

def stable_key(row:Dict[str,Any],c:Dict[str,Any])->str:
    t=ticker(row.get('ticker') or c.get('ticker'))
    s=c.get('structure') if isinstance(c.get('structure'),dict) else {}
    inv=num(s.get('execution_invalid'));t1=num(s.get('target_t1'))
    if not t or not inv or not t1 or not t1>inv:return ''
    seed=json.dumps({'ticker':t,'invalid':round(inv,10),'target_t1':round(t1,10)},sort_keys=True,separators=(',',':'))
    return f'{GENERATION}|{t}|v2154-structure:{hashlib.sha256(seed.encode()).hexdigest()[:20]}'

def outcome(rec:Dict[str,Any])->str:
    a=num(rec.get('first_t1_ts'));b=num(rec.get('first_invalid_ts'))
    if a and b:
        if a==b:return 'AMBIGUOUS_SAME_SNAPSHOT'
        return 'T1_FIRST' if a<b else 'INVALID_FIRST'
    if a:return 'T1_FIRST'
    if b:return 'INVALID_FIRST'
    return 'NO_TOUCH'

def touch_order(up:Optional[float],down:Optional[float])->str:
    if up and down:
        if up==down:return 'AMBIGUOUS'
        return 'UP_FIRST' if up<down else 'DOWN_FIRST'
    if up:return 'UP_FIRST'
    if down:return 'DOWN_FIRST'
    return 'NO_TOUCH'

def group_scores(c:Dict[str,Any])->Dict[str,Any]:
    p=c.get('prediction') if isinstance(c.get('prediction'),dict) else {}
    e=c.get('prediction_evidence') if isinstance(c.get('prediction_evidence'),dict) else (p.get('evidence') if isinstance(p.get('evidence'),dict) else {})
    g=e.get('groups') if isinstance(e.get('groups'),dict) else {}
    def gs(name:str):
        v=g.get(name);return num(v.get('score')) if isinstance(v,dict) else None
    return {
        'continuation_score':num(p.get('continuation_score')),
        'participation_score':gs('participation'),
        'trigger_flow_score':gs('trigger_flow'),
        'structure_context_score_v2155':gs('structure_context'),
        'market_context_score_v2155':gs('market_context'),
        'continuation_lower_bound':num(p.get('continuation_lower_bound')),
        'model_confidence_pct':num(p.get('model_confidence_pct')),
    }

def create_record(row:Dict[str,Any],c:Dict[str,Any],price:float,nowv:float,key:str)->Dict[str,Any]:
    s=c.get('structure') if isinstance(c.get('structure'),dict) else {}
    p=c.get('prediction') if isinstance(c.get('prediction'),dict) else {}
    comb=c.get('decision_combiner') if isinstance(c.get('decision_combiner'),dict) else {}
    scores=group_scores(c)
    rec={
        'schema':'strategy_v2_outcome_state_row_v2163','generation':GENERATION,'event_key':key,
        'plan_key':c.get('plan_key'),'decision_key':None,'decision_keys_exact_v2163':[],
        'ticker':ticker(row.get('ticker') or c.get('ticker')),'start_ts':nowv,'start_text':now_text(nowv),
        'last_seen_ts':nowv,'reference_entry':num(s.get('reference_entry'),price),
        'execution_invalid':num(s.get('execution_invalid')),'target_t1':num(s.get('target_t1')),'target_t2':num(s.get('target_t2')),
        'geometry_state':'READY' if (num(s.get('execution_invalid'),0)<num(s.get('reference_entry'),price)<num(s.get('target_t1'),0)) else str(s.get('state') or ''),
        'contract_state':c.get('state'),'structure_state':s.get('state'),'prediction_state':p.get('state'),
        'combiner_state':comb.get('state') or c.get('state'),'combiner_eligible':comb.get('entry_eligible') is True,
        'prediction_model_generation':c.get('prediction_model_generation') or p.get('prediction_model_generation'),
        'probability_is_calibrated':p.get('probability_is_calibrated') is True,
        'max_pct':0.0,'min_pct':0.0,'samples':{},'practical_samples_v2163':{},
        'practical_tracking_started_ts_v2163':nowv,'first_up_pct_ts_v2163':{},'first_down_pct_ts_v2163':{},
        'final_appended':False,'actual_trade_exact_v2163':False,'tracking_version_v2166':VERSION,'auto_buy':False,
    }
    rec.update(scores)
    return rec

def update_identity(rec:Dict[str,Any],row:Dict[str,Any],c:Dict[str,Any],nowv:float)->None:
    keys=list(rec.get('decision_keys_exact_v2163') or [])
    for k in exact_decision_keys(row,c):
        if k not in keys:keys.append(k)
    rec['decision_keys_exact_v2163']=keys
    if keys:
        rec['decision_key']=keys[0];rec['decision_link_state_v2163']='DIRECT_DECISION_KEY_READY'
        if not isinstance(rec.get('decision_snapshot_v2163'),dict):
            snap={'captured_ts':nowv,'captured_text':now_text(nowv),'contract_state':c.get('state')}
            snap.update(group_scores(c));rec['decision_snapshot_v2163']=snap
    # Current lifecycle state can change; sealed initial scores above are never overwritten.
    comb=c.get('decision_combiner') if isinstance(c.get('decision_combiner'),dict) else {}
    rec['last_contract_state_v2163']=c.get('state');rec['last_combiner_state_v2163']=comb.get('state') or c.get('state')
    rec['last_combiner_eligible_v2163']=comb.get('entry_eligible') is True

def update_path(rec:Dict[str,Any],price:float,nowv:float)->None:
    entry=num(rec.get('reference_entry'))
    if not entry or entry<=0:return
    pct=(price/entry-1.0)*100.0
    rec['last_seen_ts']=nowv;rec['last_seen_text']=now_text(nowv);rec['last_price']=price
    rec['max_pct']=max(num(rec.get('max_pct'),pct) or pct,pct);rec['min_pct']=min(num(rec.get('min_pct'),pct) or pct,pct)
    t1=num(rec.get('target_t1'));inv=num(rec.get('execution_invalid'));t2=num(rec.get('target_t2'))
    if t1 and price>=t1 and not rec.get('first_t1_ts'):rec['first_t1_ts']=nowv
    if inv and price<=inv and not rec.get('first_invalid_ts'):rec['first_invalid_ts']=nowv
    if t2 and price>=t2 and not rec.get('first_t2_ts'):rec['first_t2_ts']=nowv
    ups=rec.setdefault('first_up_pct_ts_v2163',{});downs=rec.setdefault('first_down_pct_ts_v2163',{})
    for threshold in (1,2,3):
        k=str(threshold)
        if pct>=threshold and not ups.get(k):ups[k]=nowv
        if pct<=-threshold and not downs.get(k):downs[k]=nowv
    elapsed=max(0.0,nowv-num(rec.get('start_ts'),nowv))
    samples=rec.setdefault('samples',{})
    for label,sec in HORIZONS:
        if label in samples:continue
        if elapsed>=sec:
            lateness=max(0.0,elapsed-sec)
            samples[label]={
                'pct':round(pct,6),'max_pct':round(num(rec.get('max_pct'),0) or 0,6),'min_pct':round(num(rec.get('min_pct'),0) or 0,6),
                'outcome_so_far':outcome(rec),'sampled_ts':nowv,'sampled_text':now_text(nowv),
                'sample_precision_v2163':'FIRST_CYCLE_AFTER_HORIZON',
                'sample_lateness_sec_v2166':round(lateness,3),
                'same_event_cumulative_horizon_v2166':True
            }
    pstart=num(rec.get('practical_tracking_started_ts_v2163'),nowv) or nowv
    pelapsed=max(0.0,nowv-pstart);ps=rec.setdefault('practical_samples_v2163',{})
    for label,sec in HORIZONS:
        if label in ps or pelapsed<sec:continue
        ps[label]={
            'pct':round(pct,6),'max_pct':round(num(rec.get('max_pct'),0) or 0,6),'min_pct':round(num(rec.get('min_pct'),0) or 0,6),
            'up1_vs_down1':touch_order(num(ups.get('1')),num(downs.get('1'))),
            'up2_vs_down1':touch_order(num(ups.get('2')),num(downs.get('1'))),
            'up3_vs_down1':touch_order(num(ups.get('3')),num(downs.get('1'))),
            'up1_reached':bool(ups.get('1')),'up2_reached':bool(ups.get('2')),'up3_reached':bool(ups.get('3')),
            'down1_reached':bool(downs.get('1')),'sampled_ts':nowv,'sampled_text':now_text(nowv),
            'tracking_basis_v2163':'FORWARD_ONLY_FROM_V2163'
        }

def iter_open_rows()->List[Dict[str,Any]]:
    obj=load_json(OPEN_PATH,{})
    if isinstance(obj,list):return [x for x in obj if isinstance(x,dict)]
    if not isinstance(obj,dict):return []
    for k in ('open_positions','positions','rows','open'):
        v=obj.get(k)
        if isinstance(v,list):return [x for x in v if isinstance(x,dict)]
        if isinstance(v,dict):return [x for x in v.values() if isinstance(x,dict)]
    return [x for x in obj.values() if isinstance(x,dict)]

def actual_generation(row:Dict[str,Any],contract:Optional[Dict[str,Any]]=None)->str:
    c=contract if isinstance(contract,dict) else {}
    return str(row.get('paper_v2_generation') or c.get('generation') or '').strip()

def actual_model(row:Dict[str,Any],contract:Optional[Dict[str,Any]]=None)->str:
    c=contract if isinstance(contract,dict) else {}
    p=c.get('prediction') if isinstance(c.get('prediction'),dict) else {}
    return str(c.get('prediction_model_generation') or p.get('prediction_model_generation') or row.get('prediction_model_generation') or '').strip()

def attach_actual_trades(records:Dict[str,Dict[str,Any]],nowv:float,model_generation:str)->Dict[str,int]:
    open_rows=iter_open_rows()
    closed_rows=read_jsonl(CLOSED_PATH,2000)
    actual_rows=[(x,'OPEN') for x in open_rows]+[(x,'CLOSED') for x in closed_rows]
    by_decision:Dict[str,Dict[str,Any]]={}
    by_plan:Dict[str,List[Dict[str,Any]]]={}
    for rec in records.values():
        if not isinstance(rec,dict) or rec.get('superseded_duplicate_v2154'):continue
        for k in rec.get('decision_keys_exact_v2163') or []:by_decision[str(k)]=rec
        p=str(rec.get('plan_key') or '')
        if p:by_plan.setdefault(p,[]).append(rec)
    total=linked=plan_derived=missing=created=0
    open_total=closed_total=0
    for row,kind in actual_rows:
        if not isinstance(row,dict):continue
        c=open_contract(row)
        if actual_generation(row,c)!=GENERATION:continue
        if actual_model(row,c)!=model_generation:continue
        total+=1
        if kind=='OPEN':open_total+=1
        else:closed_total+=1
        keys=exact_decision_keys(row,c)
        if not keys:
            missing+=1;continue
        rec=None;source='DIRECT_DECISION_KEY'
        for k in keys:
            if k in by_decision:rec=by_decision[k];break
        if rec is None:
            plans={str(c.get('plan_key') or '').strip(),str(c.get('candidate_plan_key') or '').strip()}
            plans.update(plan_from_decision(k) for k in keys if plan_from_decision(k));plans.discard('')
            matches=[]
            for plan in plans:matches.extend(by_plan.get(plan,[]))
            unique={id(x):x for x in matches}
            if len(unique)==1:
                rec=next(iter(unique.values()));source='SEALED_PLAN_KEY_EXACT';plan_derived+=1
        if rec is None and c:
            entry=num(row.get('entry_price') or row.get('open_price') or ((c.get('structure') or {}).get('reference_entry') if isinstance(c.get('structure'),dict) else None))
            if entry and entry>0:
                event='actual:'+hashlib.sha256(keys[0].encode()).hexdigest()[:24]
                rec=create_record(row,c,entry,nowv,event)
                opened=num(row.get('paper_v2_exact_opened_ts') or row.get('opened_at') or row.get('open_ts') or row.get('entry_ts'))
                rec['start_ts']=opened or nowv;rec['start_text']=now_text(rec['start_ts'])
                rec['reference_entry']=entry;rec['practical_tracking_started_ts_v2163']=nowv
                rec['actual_record_created_from_sealed_contract_v2165']=True
                records[event]=rec;created+=1;source='SEALED_EXACT_BOOK_CONTRACT'
                plan=str(c.get('plan_key') or '')
                if plan:rec['plan_key']=plan;by_plan.setdefault(plan,[]).append(rec)
        if rec is None:
            missing+=1;continue
        arr=list(rec.get('decision_keys_exact_v2163') or [])
        for k in keys:
            if k not in arr:arr.append(k)
            by_decision[k]=rec
        rec['decision_keys_exact_v2163']=arr;rec['decision_key']=arr[0]
        rec['actual_trade_exact_v2163']=True;rec['actual_link_source_v2163']=source
        rec['actual_trade_open_v2164']=kind=='OPEN';rec['actual_trade_closed_v2164']=kind=='CLOSED'
        pos=str(row.get('pos_id') or row.get('position_id') or '').strip()
        if pos:
            ids=list(rec.get('actual_pos_ids_v2163') or [])
            if pos not in ids:ids.append(pos)
            rec['actual_pos_ids_v2163']=ids
        if not isinstance(rec.get('actual_entry_snapshot_v2163'),dict):
            rec['actual_entry_snapshot_v2163']={
                'opened_at':num(row.get('paper_v2_exact_opened_ts') or row.get('opened_at') or row.get('open_ts') or row.get('entry_ts')),
                'entry_price':num(row.get('entry_price') or row.get('open_price')),
                'decision_key':arr[0],'pos_id':pos or None,'captured_ts':nowv,
                'sealed_contract_present':bool(c),'paper_v2_generation':actual_generation(row,c)
            }
        live=row_price(row)
        if live and live>0:update_path(rec,live,nowv)
        linked+=1
    return {
        'actual_exact_total':total,'actual_exact_linked':linked,'actual_plan_derived_exact':plan_derived,
        'actual_exact_missing':missing,'actual_created_from_sealed_contract_v2164':created,
        'actual_created_from_sealed_contract_v2165':created,'actual_exact_open_total_v2165':open_total,
        'actual_exact_closed_total_v2165':closed_total,'actual_exact_source_v2165':'paper_v2_exact_open/closed_v2135'
    }


def _runtime_identity_from_strategy(source_rows:List[Dict[str,Any]])->Dict[str,Any]:
    st=load_json(STRATEGY_STATUS,{}) or {}
    ds=load_json(STRATEGY_DECISION_STATUS,{}) or {}
    ident=st.get('runtime_identity_v2168') if isinstance(st.get('runtime_identity_v2168'),dict) else {}
    if not ident and isinstance(ds.get('runtime_identity_v2168'),dict): ident=ds.get('runtime_identity_v2168')
    worker=str(ident.get('worker_version') or st.get('strategy_worker_version') or st.get('version') or '')
    build=str(ident.get('worker_build') or st.get('deploy_version') or st.get('build') or '')
    core=str(ident.get('core_version') or ds.get('active_prediction_owner') or '')
    model=str(ident.get('model_generation') or st.get('prediction_model_generation_v2168') or ds.get('prediction_model_generation_v2168') or '')
    candidate_models=Counter()
    candidate_cores=Counter()
    for row in source_rows:
        if not isinstance(row,dict): continue
        c=contract_of(row)
        m=actual_model(row,c)
        if m: candidate_models[m]+=1
        rid=c.get('runtime_identity_v2168') if isinstance(c.get('runtime_identity_v2168'),dict) else {}
        cv=str(rid.get('core_version') or c.get('version') or '')
        if cv: candidate_cores[cv]+=1
    candidate_model_ok=bool(not candidate_models or (len(candidate_models)==1 and model in candidate_models))
    candidate_core_ok=bool(not candidate_cores or (len(candidate_cores)==1 and core in candidate_cores))
    ready=bool(
        ident.get('ready') is True
        and worker=='strategy_worker_v2.062'
        and build=='v2168_single_identity_event_spine_2026-07-22'
        and core=='strategy_v2_core_v2168'
        and model=='FULL_INPUT_V2171'
        and candidate_model_ok and candidate_core_ok
    )
    return {
        'schema':'review_strategy_runtime_identity_v2168','ready':ready,
        'worker_version':worker,'worker_build':build,'core_version':core,'model_generation':model,
        'candidate_model_counts':dict(candidate_models),'candidate_core_counts':dict(candidate_cores),
        'candidate_model_ok':candidate_model_ok,'candidate_core_ok':candidate_core_ok,
        'source':'clean_strategy_worker_status + strategy_v2_decision_status + candidate contract',
        'auto_buy':False,
    }

def rss_mb()->float:
    try:
        for line in Path('/proc/self/status').read_text().splitlines():
            if line.startswith('VmRSS:'):return round(float(line.split()[1])/1024,2)
    except Exception:pass
    return 0.0

def run_once()->Dict[str,Any]:
    started=time.monotonic();nowv=now_ts();phase0=time.monotonic()
    source=[r for r in read_jsonl(PAPER_LATEST,1400) if str(r.get('strategy_generation_v2149') or '')==GENERATION]
    source_read_sec=round(time.monotonic()-phase0,4)
    runtime=_runtime_identity_from_strategy(source)
    active_model=str(runtime.get('model_generation') or '')
    phase1=time.monotonic()
    state=load_json(OUTCOME_STATE,{}) or {};state=dict(state) if isinstance(state,dict) else {}
    records=state.get(STATE_KEY) if isinstance(state.get(STATE_KEY),dict) else {}
    records={str(k):v for k,v in records.items() if isinstance(v,dict)}
    state_load_sec=round(time.monotonic()-phase1,4)
    new=0;current=0;model_counts=Counter();contract_counts=Counter();input_failures=Counter();connection_states=Counter()
    if runtime.get('ready'):
        for row in source:
            c=contract_of(row);price=row_price(row);key=stable_key(row,c) if c else ''
            if not c or not key or not price or price<=0:continue
            model=actual_model(row,c) or 'UNKNOWN';model_counts[model]+=1
            if model!=active_model:continue
            current+=1;contract_counts[str(c.get('state') or 'UNKNOWN')]+=1
            pred=c.get('prediction') if isinstance(c.get('prediction'),dict) else {}
            evidence=c.get('prediction_evidence') if isinstance(c.get('prediction_evidence'),dict) else (pred.get('evidence') if isinstance(pred.get('evidence'),dict) else {})
            for failure in (evidence.get('required_input_failures_v2155') or pred.get('required_input_failures_v2155') or []):input_failures[str(failure)]+=1
            conns=evidence.get('input_connections_v2155') if isinstance(evidence.get('input_connections_v2155'),dict) else {}
            for meta in conns.values():
                if isinstance(meta,dict):connection_states[str(meta.get('state') or 'MISSING')]+=1
            rec=records.get(key)
            if not isinstance(rec,dict):rec=create_record(row,c,price,nowv,key);records[key]=rec;new+=1
            update_identity(rec,row,c,nowv);update_path(rec,price,nowv)
    else:
        for row in source:
            c=contract_of(row);m=actual_model(row,c) if c else ''
            if m:model_counts[m]+=1
    phase2=time.monotonic()
    link=attach_actual_trades(records,nowv,active_model) if runtime.get('ready') else {
        'actual_exact_total':0,'actual_exact_linked':0,'actual_plan_derived_exact':0,'actual_exact_missing':0,
        'actual_created_from_sealed_contract_v2164':0,'actual_created_from_sealed_contract_v2165':0,
        'actual_exact_open_total_v2165':0,'actual_exact_closed_total_v2165':0,
        'actual_exact_source_v2165':'WAIT_RUNTIME_IDENTITY_V2167'
    }
    actual_link_sec=round(time.monotonic()-phase2,4)
    finalized=0;prune_keys=[]
    for rec_key,rec in records.items():
        if not isinstance(rec,dict) or rec.get('superseded_duplicate_v2154'):continue
        age=max(0.0,nowv-num(rec.get('start_ts'),nowv))
        if age>=21600 and not rec.get('final_appended'):
            final=dict(rec);final.update({'schema':'strategy_v2_outcome_v2163','generation':GENERATION,'outcome_6h':outcome(rec),'finalized_ts':nowv,'finalized_text':now_text(nowv),'historical_ledger_rewritten':False,'auto_buy':False})
            append_jsonl(OUTCOME_LEDGER,final);rec['final_appended']=True;finalized+=1
        if rec.get('final_appended') and (not rec.get('actual_trade_exact_v2163') or rec.get('actual_trade_closed_v2164')):prune_keys.append(str(rec_key))
    for rec_key in prune_keys:records.pop(rec_key,None)
    snapshot=int(state.get('v2149_snapshot_count') or 0)+1
    active=[r for r in records.values() if isinstance(r,dict) and not r.get('superseded_duplicate_v2154')]
    active_model_rows=[r for r in active if active_model and str(r.get('prediction_model_generation') or '')==active_model]
    horizon_counts={}
    for label,_ in HORIZONS:
        horizon_counts[label]={
            'contract_samples':sum(1 for r in active_model_rows if isinstance((r.get('samples') or {}).get(label),dict)),
            'practical_forward_samples':sum(1 for r in active_model_rows if isinstance((r.get('practical_samples_v2163') or {}).get(label),dict)),
        }
    active_ages=[max(0.0,nowv-(num(r.get('start_ts'),nowv) or nowv)) for r in active_model_rows]
    oldest=max(active_ages) if active_ages else 0.0
    finals=[r for r in read_jsonl(OUTCOME_LEDGER,12000) if str(r.get('generation') or '')==GENERATION]
    state_name='ACTIVE' if runtime.get('ready') and current else ('WAITING_ACTIVE_MODEL_CANDIDATES' if runtime.get('ready') else 'RUNTIME_IDENTITY_CHECK')
    status={
        'schema':'strategy_v2_outcome_status_v2167','version':VERSION,'build':BUILD_LABEL,'generation':GENERATION,
        'updated_ts':nowv,'updated_text':now_text(nowv),'state':state_name,
        'snapshot_count':snapshot,'candidate_rows':current,'active_records':len(active_model_rows),'new_records_cycle':new,'finalized_cycle':finalized,
        'pruned_derived_state_cycle_v2163':len(prune_keys),'pruned_derived_state_cycle_v2164':len(prune_keys),
        'prediction_model_counts_v2163':dict(model_counts),'prediction_model_counts_v2155':dict(model_counts),'contract_state_counts':dict(contract_counts),
        'required_input_failure_counts_v2155':dict(input_failures),'input_connection_state_counts_v2155':dict(connection_states),
        'full_input_active_records_v2155':len(active_model_rows),'full_input_finalized_records_v2155':sum(1 for r in finals if str(r.get('prediction_model_generation') or '').startswith('FULL_INPUT_')),
        'review_6h_state_v2154':'COMPLETE_AVAILABLE' if finals else ('WAITING_FIRST_6H' if active_model_rows else 'WAITING_CANDIDATES'),
        'oldest_active_age_sec_v2154':round(oldest,3),'first_6h_due_in_sec_v2154':round(max(0.0,21600-oldest),3) if active_model_rows and not finals else 0.0,
        'horizon_counts_v2163':horizon_counts,**link,
        'runtime_identity_v2168':runtime,'runtime_identity_ready_v2168':bool(runtime.get('ready')),
        'active_model_generation_v2168':active_model or None,
        'exact_link_policy_v2163':'direct decision key; deterministic plan hash derived from the same direct decision key only; no ticker/time proximity',
        'primary_horizons_v2163':['1h','3h'],'support_horizons_v2163':['30m','6h'],
        'same_event_horizon_contract_v2167':'30m -> 1h -> 3h -> 6h cumulative',
        'shadow_active_writers_v2163':0,'shadow_removed_active_paths_v2163':list(SHADOW_WRITERS_REMOVED),'shadow_historical_files_deleted_v2163':False,
        'historical_ledgers_rewritten':False,'probability_calibrated':False,'prediction_used_in_final_decision':True,'decision_combiner_active':True,
        'paper_prediction_recompute_calls':0,'actual_entry_changed':False,'actual_exit_changed':False,'strategy_numbers_changed':False,'auto_buy':False,
    }
    state.update({'schema':'strategy_v2_outcome_state_v2167','version':VERSION,'build':BUILD_LABEL,'updated_ts':nowv,'v2149_snapshot_count':snapshot,STATE_KEY:records,'active_generation':GENERATION,'active_model_generation_v2168':active_model or None,'prior_keys_preserved':True,'auto_buy':False})
    phase3=time.monotonic();last_state_mtime=OUTCOME_STATE.stat().st_mtime if OUTCOME_STATE.exists() else 0.0
    checkpoint_due=bool(nowv-last_state_mtime>=STATE_CHECKPOINT_SEC or finalized or link.get('actual_created_from_sealed_contract_v2165'))
    status['state_checkpoint_written_v2168']=checkpoint_due;status['state_checkpoint_interval_sec_v2168']=STATE_CHECKPOINT_SEC
    if checkpoint_due:_atomic_json(OUTCOME_STATE,state)
    _existing_outcome_status_v2203=load_json(OUTCOME_STATUS,{}) or {}
    if isinstance(_existing_outcome_status_v2203,dict):
        for _field_v2203 in ('prediction_validation_v2202','prediction_validation_v2202_runtime','prediction_analysis_owner_v2202','clean_review_worker_status_role_v2202','main_direct_ledger_scan_v2202','review_analysis_v2238'):
            if _field_v2203 in _existing_outcome_status_v2203:
                status[_field_v2203]=_existing_outcome_status_v2203[_field_v2203]
    _atomic_json(OUTCOME_STATUS,status)
    state_write_sec=round(time.monotonic()-phase3,4);sec=round(time.monotonic()-started,3)
    worker_status={
        'schema':'clean_review_worker_status_v2167','version':VERSION,'build':BUILD_LABEL,'state':state_name,'pid':os.getpid(),
        'active_owner':'review_worker_v2.066_canonical_identity_actual_owner','writer_count':1,'updated_ts':nowv,'updated_text':now_text(nowv),
        'last_sec':sec,'rss_mb':rss_mb(),'proc_rss_mb':rss_mb(),'phase':'current_outcome_single_runtime_owner',
        'phase_sec_v2168':{'source_read':source_read_sec,'state_load':state_load_sec,'actual_link':actual_link_sec,'state_write':state_write_sec},
        'runtime_identity_v2168':runtime,'runtime_identity_ready_v2168':bool(runtime.get('ready')),
        'model_generation_v2168':active_model or None,'state_checkpoint_written_v2168':checkpoint_due,'state_checkpoint_interval_sec_v2168':STATE_CHECKPOINT_SEC,
        'candidate_rows':current,'active_records':len(active_model_rows),'horizon_counts_v2163':horizon_counts,**link,
        'shadow_active_writers_v2163':0,'shadow_historical_files_deleted_v2163':False,'cycle_complete_v2168':True,'auto_buy':False,
    }
    _atomic_json(STATUS,worker_status);return worker_status

def ledger_once()->None:
    marker=BASE_DIR/'runtime'/'review_v2163_dense_horizon_exact_link.seeded'
    if marker.exists():return
    ts=now_ts();txt=now_text(ts)
    append_jsonl(CHANGE_LEDGER,{
        'schema':'change_verify_ledger_v870','change_id':'V2163-DENSE-HORIZON-EXACT-LINK-SHADOW-CLEANUP','issue_id':'OPEN-OUTCOME-EXACT-LINK-AND-HORIZON-GAP-2163','version':'v2163','verify_result':'LOCAL_PASS_SERVER_CHECK',
        'created_ts':ts,'created_at':txt,'writer':'review_worker_v2.061','cause':'Review created candidate rows before ENTRY_READY and did not attach the later direct decision key. Actual trades therefore failed exact linkage. The current comparison also skipped 1h and retained obsolete shadow code paths.',
        'fix':'Current-only Review owner updates direct decision aliases at ENTRY_READY, links actual trades only by direct key or its deterministic plan hash, records 30m/1h/3h/6h plus forward practical +1/+2/+3 paths, and removes all shadow writers from the active worker.',
        'not_touched':['Strategy/Trigger/Paper formulas','OPEN/CLOSED/decision/exact ledgers','sealed exits','historical shadow files','auto-buy OFF'],'auto_buy':False})
    append_jsonl(ISSUE_LEDGER,{
        'schema':'coinbot_single_work_ledger_v870','event_type':'ISSUE','issue_id':'OPEN-OUTCOME-EXACT-LINK-AND-HORIZON-GAP-2163','status':'CHECK','title':'실제매매·놓친상승 시간대별 정확비교','detail':'direct decision key exact 연결과 30분/1시간/3시간/6시간 비교. 구 Shadow writer 중단, 과거자료 보존.','version':'v2163','created_ts':ts,'created_at':txt,'auto_buy':False})
    marker.parent.mkdir(parents=True,exist_ok=True);marker.write_text(txt,encoding='utf-8')

def ledger_v2164_once()->None:
    marker=BASE_DIR/'runtime'/'review_v2164_runtime_order_review_fast.seeded'
    if marker.exists():return
    ts=now_ts();txt=now_text(ts)
    append_jsonl(CHANGE_LEDGER,{'schema':'change_verify_ledger_v870','change_id':'V2164-RUNTIME-ORDER-REVIEW-FAST-EXACT','issue_id':'MAIN-TAIL-NOT-ACTIVE-AND-REVIEW-LATENCY-2164','version':'v2164','verify_result':'LOCAL_PASS_SERVER_CHECK','created_ts':ts,'created_at':txt,'writer':'review_worker_v2.062','cause':'Review held finalized derived rows for 48h, reread large JSONL files and wrote no boot status until the first long cycle. Existing OPEN rows also needed an exact sealed-contract recovery path.','fix':'Tail-bounded JSONL reads, no shallow whole-state copy, append-ledger-before-derived-state rotation, sealed direct OPEN contract exact records, boot status before first cycle, and acquired_ts lock proof.','not_touched':['Strategy/Trigger/Paper/exit formulas','OPEN/CLOSED/decision/exact ledgers','historical outcome/Shadow files','auto-buy OFF'],'auto_buy':False})
    append_jsonl(ISSUE_LEDGER,{'schema':'coinbot_single_work_ledger_v870','event_type':'ISSUE','issue_id':'MAIN-TAIL-NOT-ACTIVE-AND-REVIEW-LATENCY-2164','status':'CHECK','title':'v2163 화면 미활성·Review 적용 지연','detail':'Main binding order, actual OPEN exact, Review cycle/RSS and Guard boot proof repaired together.','version':'v2164','created_ts':ts,'created_at':txt,'auto_buy':False})
    marker.parent.mkdir(parents=True,exist_ok=True);marker.write_text(txt,encoding='utf-8')

def ledger_v2165_once()->None:
    marker=BASE_DIR/'runtime'/'review_v2165_exact_book_market_compare.seeded'
    if marker.exists():return
    ts=now_ts();txt=now_text(ts)
    append_jsonl(CHANGE_LEDGER,{'schema':'change_verify_ledger_v870','change_id':'V2165-EXACT-BOOK-MARKET-COMPARE-QUALITY-READY','issue_id':'REVIEW-WRONG-ACTUAL-BOOK-AND-MARKET-TOP-BLIND-2165','version':'v2165','verify_result':'LOCAL_PASS_SERVER_CHECK','created_ts':ts,'created_at':txt,'writer':'review_worker_v2.063','cause':'Review read legacy paper_bot_open/closed instead of the active v2149 Paper exact books, so actual key showed 0/0 while Main listed current exact OPEN. The comparison also had no whole-market 15m/30m/1h reference.','fix':'Read paper_v2_exact_open/closed_v2135 only, exact-link their sealed direct contracts, update actual paths from the exact book, expose phase timings, and leave market-top rendering to the existing Main /trade_review using scanner+candle owner data.','not_touched':['Strategy/Trigger/Paper/exit formulas','OPEN/CLOSED/decision/exact ledgers','historical outcome/Shadow files','auto-buy OFF'],'auto_buy':False})
    append_jsonl(ISSUE_LEDGER,{'schema':'coinbot_single_work_ledger_v870','event_type':'ISSUE','issue_id':'REVIEW-WRONG-ACTUAL-BOOK-AND-MARKET-TOP-BLIND-2165','status':'CHECK','title':'실제매매 exact 장부·시장상승 TOP 대조 수리','detail':'Review actual owner를 현재 Paper exact 장부로 바로잡고 15m/30m/1h 전체시장 대조를 기존 /trade_review에 연결한다.','version':'v2165','created_ts':ts,'created_at':txt,'auto_buy':False})
    marker.parent.mkdir(parents=True,exist_ok=True);marker.write_text(txt,encoding='utf-8')


def ledger_v2166_once()->None:
    marker=BASE_DIR/'runtime'/'review_v2166_dense_horizon_owner.seeded'
    if marker.exists():return
    ts=now_ts();txt=now_text(ts)
    append_jsonl(CHANGE_LEDGER,{'schema':'change_verify_ledger_v870','change_id':'V2166-DENSE-HORIZON-OWNER-FAST','issue_id':'LATE-CANDIDATE-ENTRY-AND-DENSE-COMPARE-2166','version':'v2166','verify_result':'LOCAL_PASS_SERVER_CHECK','created_ts':ts,'created_at':txt,'writer':'review_worker_v2.064','cause':'The same event could show a 3h sample while 30m/1h were absent because sampling accepted only a narrow on-time cycle window. Full active state was also atomically rewritten every cycle.','fix':'For new FULL_INPUT_V2166 events, fill every elapsed horizon cumulatively on the first cycle after its boundary, expose sample lateness, checkpoint the same derived state at a bounded 45s cadence, and keep final append-only outcomes unchanged.','not_touched':['Strategy/Trigger/Paper/exit formulas','OPEN/CLOSED/decision/exact ledgers','historical outcome/Shadow files','auto-buy OFF'],'auto_buy':False})
    append_jsonl(ISSUE_LEDGER,{'schema':'coinbot_single_work_ledger_v870','event_type':'ISSUE','issue_id':'LATE-CANDIDATE-ENTRY-AND-DENSE-COMPARE-2166','status':'CHECK','title':'시간대 비교 동일사건 누락·Review 쓰기지연 수리','detail':'같은 신규 사건의 30분·1시간·3시간·6시간을 누적 연결하고 상태 전체쓰기 빈도를 줄인다.','version':'v2166','created_ts':ts,'created_at':txt,'auto_buy':False})
    marker.parent.mkdir(parents=True,exist_ok=True);marker.write_text(txt,encoding='utf-8')

def ledger_v2167_once()->None:
    marker=BASE_DIR/'runtime'/'review_v2167_single_runtime_owner.seeded'
    if marker.exists():return
    ts=now_ts();txt=now_text(ts)
    append_jsonl(CHANGE_LEDGER,{'schema':'change_verify_ledger_v870','change_id':'V2167-REVIEW-DYNAMIC-RUNTIME-OWNER','issue_id':'STRATEGY-RUNTIME-GENERATION-SPLIT-2167','version':'v2167','verify_result':'LOCAL_PASS_SERVER_CHECK','created_ts':ts,'created_at':txt,'writer':'review_worker_v2.065','cause':'Review hard-coded FULL_INPUT_V2166 while live Strategy remained FULL_INPUT_V2161, producing a zero-sample board that looked like missing data.','fix':'Review derives the active model only from the exact Strategy runtime identity and candidate contract. Mismatch is CHECK, never a silently empty model cohort. Historical model rows remain preserved and separate.','not_touched':['Strategy formulas','Paper/exit','historical outcome and trade ledgers','auto-buy OFF'],'auto_buy':False})
    append_jsonl(ISSUE_LEDGER,{'schema':'coinbot_single_work_ledger_v870','event_type':'ISSUE','issue_id':'STRATEGY-RUNTIME-GENERATION-SPLIT-2167','status':'CHECK','title':'Review 고정 모델명으로 표본 0 오판','detail':'현재 Strategy 실행신분을 직접 읽고 같은 모델 후보만 비교한다.','version':'v2167','created_ts':ts,'created_at':txt,'auto_buy':False})
    marker.parent.mkdir(parents=True,exist_ok=True);marker.write_text(txt,encoding='utf-8')


def acquire_lock()->None:
    global _LOCK_FH
    LOCK_PATH.parent.mkdir(parents=True,exist_ok=True)
    fh=LOCK_PATH.open('a+',encoding='utf-8')
    try:fcntl.flock(fh.fileno(),fcntl.LOCK_EX|fcntl.LOCK_NB)
    except BlockingIOError:raise SystemExit(0)
    fh.seek(0);fh.truncate();fh.write(json.dumps({'pid':os.getpid(),'version':VERSION,'build':BUILD_LABEL,'ts':now_ts(),'acquired_ts':now_ts()}));fh.flush()
    _LOCK_FH=fh
    atexit.register(lambda: fh.close() if not fh.closed else None)

def main()->None:
    # Runtime identity must be published before any ledger fsync or cache work.
    # This is the single existing Review process; no new worker or wrapper.
    acquire_lock()
    boot_ts=now_ts()
    _atomic_json(STATUS,{'schema':'clean_review_worker_status_v2239','version':VERSION,'build':BUILD_LABEL,'state':'booting','pid':os.getpid(),'active_owner':VERSION,'writer_count':1,'updated_ts':boot_ts,'updated_text':now_text(boot_ts),'phase':'BOOT_IDENTITY_PUBLISHED_BEFORE_LEDGER_IO_V2239','cycle_complete_v2164':False,'shadow_active_writers_v2163':0,'shadow_historical_files_deleted_v2163':False,'auto_buy':False})
    for _ledger_fn in (ledger_once,ledger_v2164_once,ledger_v2165_once,ledger_v2166_once,ledger_v2167_once,_v2233_review_ledger_once,_v2238_review_ledger_once):
        try:_ledger_fn()
        except Exception as exc:append_error(f'boot_ledger_{getattr(_ledger_fn,"__name__","unknown")}',exc)
    while True:
        try:run_once()
        except Exception as exc:
            append_error('run_once',exc)
            _atomic_json(STATUS,{'schema':'clean_review_worker_status_v2239','version':VERSION,'build':BUILD_LABEL,'state':'ERROR','pid':os.getpid(),'updated_ts':now_ts(),'updated_text':now_text(),'error':f'{type(exc).__name__}: {exc}','shadow_active_writers_v2163':0,'auto_buy':False})
        time.sleep(INTERVAL_SEC)


# =============================================================================
# v2168 canonical identity and exact-actual owner.
# Generation-wide exact counts and active-model exact counts are both explicit;
# no board may label one as the other.
# =============================================================================
VERSION='review_worker_v2.066'
BUILD_LABEL='v2168_single_identity_actual_owner_2026-07-22'
IDENTITY_PATH=BASE_DIR/'runtime'/'strategy_runtime_identity_current.json'
ACTUAL_STATUS_V2168=BASE_DIR/'strategy_v2_actual_exact_status_v2168.json'


def _v2168_identity_from_file(source_rows):
    ident=load_json(IDENTITY_PATH,{}) or {};st=load_json(STRATEGY_STATUS,{}) or {};ds=load_json(STRATEGY_DECISION_STATUS,{}) or {}
    signature=str(ident.get('runtime_signature') or '');candidate_sigs=Counter();candidate_models=Counter();candidate_cycles=Counter()
    for row in source_rows:
        if not isinstance(row,dict):continue
        c=contract_of(row)
        sig=str(c.get('runtime_signature_v2168') or row.get('runtime_signature_v2168') or '')
        if sig:candidate_sigs[sig]+=1
        m=actual_model(row,c)
        if m:candidate_models[m]+=1
        cyc=str(row.get('candidate_pipeline_cycle_id_v1150') or '')
        if cyc:candidate_cycles[cyc]+=1
    hold=load_json(BASE_DIR/'paper_s1_hold_cache.json',{}) or {}
    ready=bool(ident.get('ready') is True and ident.get('worker_version')=='strategy_worker_v2.062' and ident.get('worker_build')=='v2168_single_identity_event_spine_2026-07-22' and ident.get('core_version')=='strategy_v2_core_v2168' and ident.get('model_generation')=='FULL_INPUT_V2171' and signature and set(candidate_sigs or {signature:1})=={signature} and str(hold.get('runtime_signature_v2168') or '')==signature and str(st.get('runtime_signature_v2168') or (st.get('runtime_identity_v2168') or {}).get('runtime_signature') or '')==signature)
    return {'schema':'review_strategy_runtime_identity_v2168','ready':ready,**{k:ident.get(k) for k in ident},
            'candidate_signature_counts':dict(candidate_sigs),'candidate_model_counts':dict(candidate_models),'candidate_cycle_counts':dict(candidate_cycles),
            'hold_signature':hold.get('runtime_signature_v2168'),'status_signature':st.get('runtime_signature_v2168'),
            'source':'runtime/strategy_runtime_identity_current.json only; status/candidate/hold are equality proofs','auto_buy':False}


def attach_actual_trades_v2168(records,nowv,active_model):
    actual_rows=[(x,'OPEN') for x in iter_open_rows()]+[(x,'CLOSED') for x in read_jsonl(CLOSED_PATH,5000)]
    by_decision={};by_plan={}
    for rec in records.values():
        if not isinstance(rec,dict) or rec.get('superseded_duplicate_v2154'):continue
        for k in rec.get('decision_keys_exact_v2163') or []:by_decision[str(k)]=rec
        p=str(rec.get('plan_key') or '')
        if p:by_plan.setdefault(p,[]).append(rec)
    gen_total=gen_linked=gen_missing=0;active_total=active_linked=active_missing=0;created=0;open_total=closed_total=0
    model_totals=Counter();model_linked=Counter();missing_reasons=Counter()
    for row,kind in actual_rows:
        if not isinstance(row,dict):continue
        c=open_contract(row)
        if actual_generation(row,c)!=GENERATION:continue
        gen_total+=1;open_total+=int(kind=='OPEN');closed_total+=int(kind=='CLOSED')
        model=actual_model(row,c) or 'SOURCE_MISSING';model_totals[model]+=1
        is_active=model==active_model
        active_total+=int(is_active)
        keys=exact_decision_keys(row,c)
        if not keys:
            gen_missing+=1;active_missing+=int(is_active);missing_reasons['DIRECT_DECISION_KEY_MISSING']+=1;continue
        rec=None;source='DIRECT_DECISION_KEY'
        for k in keys:
            if k in by_decision:rec=by_decision[k];break
        if rec is None:
            plans={str(c.get('plan_key') or ''),str(c.get('candidate_plan_key') or '')};plans.update(plan_from_decision(k) for k in keys);plans.discard('')
            matches=[]
            for p in plans:matches.extend(by_plan.get(p,[]))
            uniq={id(x):x for x in matches}
            if len(uniq)==1:rec=next(iter(uniq.values()));source='SEALED_PLAN_KEY_EXACT'
        if rec is None and c:
            entry=num(row.get('entry_price') or row.get('open_price') or ((c.get('structure') or {}).get('reference_entry') if isinstance(c.get('structure'),dict) else None))
            if entry and entry>0:
                event='actual:'+hashlib.sha256(keys[0].encode()).hexdigest()[:24];rec=create_record(row,c,entry,nowv,event)
                opened=num(row.get('paper_v2_exact_opened_ts') or row.get('opened_at') or row.get('open_ts') or row.get('entry_ts'))
                rec['start_ts']=opened or nowv;rec['start_text']=now_text(rec['start_ts']);rec['reference_entry']=entry
                rec['prediction_model_generation']=model;rec['actual_record_created_from_sealed_contract_v2168']=True
                records[event]=rec;created+=1;source='SEALED_EXACT_BOOK_CONTRACT'
                p=str(c.get('plan_key') or '')
                if p:rec['plan_key']=p;by_plan.setdefault(p,[]).append(rec)
        if rec is None:
            gen_missing+=1;active_missing+=int(is_active);missing_reasons['NO_EXACT_RECORD_MATCH']+=1;continue
        arr=list(rec.get('decision_keys_exact_v2163') or [])
        for k in keys:
            if k not in arr:arr.append(k)
            by_decision[k]=rec
        rec['decision_keys_exact_v2163']=arr;rec['decision_key']=arr[0];rec['actual_trade_exact_v2163']=True
        rec['actual_link_source_v2168']=source;rec['actual_trade_open_v2164']=kind=='OPEN';rec['actual_trade_closed_v2164']=kind=='CLOSED'
        rec['actual_model_generation_v2168']=model
        live=row_price(row)
        if live and live>0:update_path(rec,live,nowv)
        gen_linked+=1;model_linked[model]+=1
        if is_active:active_linked+=1
    status={'schema':'strategy_v2_actual_exact_status_v2168','updated_ts':nowv,'updated_text':now_text(nowv),'generation':GENERATION,'active_model':active_model,
            'generation_total':gen_total,'generation_linked':gen_linked,'generation_missing':gen_missing,
            'active_model_total':active_total,'active_model_linked':active_linked,'active_model_missing':active_missing,
            'open_total':open_total,'closed_total':closed_total,'model_totals':dict(model_totals),'model_linked':dict(model_linked),
            'missing_reason_counts':dict(missing_reasons),'created_from_sealed_contract':created,
            'policy':'same generation exact books; direct decision key or deterministic sealed plan only; no ticker/time proximity','auto_buy':False}
    _atomic_json(ACTUAL_STATUS_V2168,status)
    return {'actual_exact_total':gen_total,'actual_exact_linked':gen_linked,'actual_exact_missing':gen_missing,
            'actual_exact_generation_total_v2168':gen_total,'actual_exact_generation_linked_v2168':gen_linked,'actual_exact_generation_missing_v2168':gen_missing,
            'actual_exact_active_model_total_v2168':active_total,'actual_exact_active_model_linked_v2168':active_linked,'actual_exact_active_model_missing_v2168':active_missing,
            'actual_exact_open_total_v2165':open_total,'actual_exact_closed_total_v2165':closed_total,'actual_created_from_sealed_contract_v2165':created,
            'actual_exact_source_v2165':'paper_v2_exact_open/closed_v2135 canonical v2168 scope'}


# Replace only the dynamic owner and actual linker used by run_once.
_runtime_identity_from_strategy=_v2168_identity_from_file
attach_actual_trades=attach_actual_trades_v2168


def ledger_v2168_once():
    marker=BASE_DIR/'runtime'/'review_v2168_single_identity_actual.seeded'
    if marker.exists():return
    ts=now_ts();txt=now_text(ts)
    append_jsonl(CHANGE_LEDGER,{'schema':'change_verify_ledger_v870','change_id':'V2168-REVIEW-CANONICAL-IDENTITY-ACTUAL','issue_id':'CURRENT-IDENTITY-ACTUAL-TIMING-CANDIDATE-GAP-2168','version':'v2168','verify_result':'LOCAL_PASS_SERVER_CHECK','created_ts':ts,'created_at':txt,'writer':'review_worker_v2.066','cause':'The board counted actual records once from outcome grouping and once from active-model exact books, so 2 and 0/0 could coexist. Current identity also remained duplicated in status readers.','fix':'Read one identity file and publish explicit generation-wide and active-model exact scopes from the same Paper exact books. Derived state checkpoints no longer rewrite on every new candidate; final append ledger remains first.','not_touched':['strategy thresholds','Paper/exit','historical ledgers','auto-buy OFF'],'auto_buy':False})
    append_jsonl(ISSUE_LEDGER,{'schema':'coinbot_single_work_ledger_v870','event_type':'ISSUE','issue_id':'CURRENT-IDENTITY-ACTUAL-TIMING-CANDIDATE-GAP-2168','status':'CHECK','title':'actual exact 2와 0/0 동시표시','detail':'세대 전체 exact와 현재모델 exact를 같은 장부에서 명시적으로 분리한다.','version':'v2168','created_ts':ts,'created_at':txt,'auto_buy':False})
    marker.parent.mkdir(parents=True,exist_ok=True);marker.write_text(txt,encoding='utf-8')
# v2245 deferred module-level call: ledger_v2168_once runs after runtime identity publication.



# =============================================================================
# v2169 canonical candidate continuity.
# Rows without finished invalid/T1 geometry receive a review-only stable key;
# they remain SOURCE_WAIT/STRUCTURE_WAIT and are never promoted or linked by
# ticker/time proximity. This makes source rows == current tracked rows.
# =============================================================================
VERSION='review_worker_v2.067'
BUILD_LABEL='v2169_full_candidate_continuity_2026-07-22'
_V2169_BASE_STABLE_KEY=stable_key
_V2169_BASE_ROW_PRICE=row_price
_V2169_SCANNER_CACHE={'ts':0.0,'rows':{}}


def stable_key(row,c):  # type: ignore[override]
    key=_V2169_BASE_STABLE_KEY(row,c)
    if key:return key
    t=ticker(row.get('ticker') or c.get('ticker'))
    if not t:return ''
    model=actual_model(row,c) or 'SOURCE_MISSING'
    return f'{GENERATION}|{t}|continuity:{model}'


def _v2169_scanner_prices():
    nowv=now_ts()
    if nowv-float(_V2169_SCANNER_CACHE.get('ts') or 0.0)<2.0:return _V2169_SCANNER_CACHE.get('rows') or {}
    obj=load_json(BASE_DIR/'clean_scanner_market_cache.json',{}) or {};raw=obj.get('rows') if isinstance(obj.get('rows'),list) else obj.get('items') if isinstance(obj.get('items'),list) else []
    rows={}
    for r in raw:
        if not isinstance(r,dict):continue
        t=ticker(r.get('ticker') or r.get('market') or r.get('symbol'));p=num(r.get('current_price') or r.get('price') or r.get('trade_price'))
        if t and p and p>0:rows[t]=p
    _V2169_SCANNER_CACHE.update({'ts':nowv,'rows':rows});return rows


def row_price(row):  # type: ignore[override]
    p=_V2169_BASE_ROW_PRICE(row)
    if p:return p
    return _v2169_scanner_prices().get(ticker(row.get('ticker') or row.get('market') or row.get('symbol')))


def _v2169_identity(source_rows):
    ident=load_json(IDENTITY_PATH,{}) or {};st=load_json(STRATEGY_STATUS,{}) or {};hold=load_json(BASE_DIR/'paper_s1_hold_cache.json',{}) or {}
    sig=str(ident.get('runtime_signature') or '');candidate_sigs=Counter();models=Counter()
    for row in source_rows:
        if not isinstance(row,dict):continue
        c=contract_of(row);rs=str(c.get('runtime_signature_v2169') or c.get('runtime_signature_v2168') or row.get('runtime_signature_v2169') or row.get('runtime_signature_v2168') or '')
        if rs:candidate_sigs[rs]+=1
        m=actual_model(row,c)
        if m:models[m]+=1
    hold_sig=str(hold.get('runtime_signature_v2169') or hold.get('runtime_signature_v2168') or '')
    status_sig=str(st.get('runtime_signature_v2169') or st.get('runtime_signature_v2168') or (st.get('runtime_identity_v2169') or st.get('runtime_identity_v2168') or {}).get('runtime_signature') or '')
    ready=bool(ident.get('ready') is True and ident.get('worker_version')=='strategy_worker_v2.063' and ident.get('worker_build')=='v2169_candidate_continuity_fresh_trigger_handoff_2026-07-22' and ident.get('core_version')=='strategy_v2_core_v2168' and ident.get('model_generation')=='FULL_INPUT_V2171' and sig and set(candidate_sigs or {sig:1})=={sig} and hold_sig==sig and status_sig==sig)
    return {'schema':'review_strategy_runtime_identity_v2169','ready':ready,**{k:ident.get(k) for k in ident},
            'candidate_signature_counts':dict(candidate_sigs),'candidate_model_counts':dict(models),'hold_signature':hold_sig,'status_signature':status_sig,
            'source':'runtime identity + exact equality proofs','auto_buy':False}

_runtime_identity_from_strategy=_v2169_identity
_V2169_BASE_RUN=run_once

def run_once__v2169():
    result=_V2169_BASE_RUN();source=[r for r in read_jsonl(PAPER_LATEST,1400) if str(r.get('strategy_generation_v2149') or '')==GENERATION]
    unique={ticker(r.get('ticker') or r.get('market') or r.get('symbol')) for r in source if isinstance(r,dict)};unique.discard('')
    keyed=sum(1 for r in source if isinstance(r,dict) and stable_key(r,contract_of(r)))
    priced=sum(1 for r in source if isinstance(r,dict) and row_price(r))
    status=load_json(STATUS,{}) or {};outcome=load_json(OUTCOME_STATUS,{}) or {};ident=_v2169_identity(source)
    status.update({'version':VERSION,'build':BUILD_LABEL,'runtime_identity_ready_v2169':bool(ident.get('ready')),'runtime_identity_ready_v2168':bool(ident.get('ready')),
                   'model_generation_v2169':ident.get('model_generation'),'model_generation_v2168':ident.get('model_generation'),
                   'candidate_source_rows_v2169':len(source),'candidate_unique_tickers_v2169':len(unique),'candidate_stable_keys_v2169':keyed,
                   'candidate_prices_v2169':priced,'candidate_continuity_pass_v2169':bool(len(source)==len(unique)==keyed and len(source)>0),
                   'candidate_geometry_not_required_for_tracking_v2169':True,'auto_buy':False})
    _atomic_json(STATUS,status)
    outcome.update({'review_candidate_source_rows_v2169':len(source),'review_candidate_unique_tickers_v2169':len(unique),
                    'review_candidate_stable_keys_v2169':keyed,'review_candidate_continuity_pass_v2169':bool(len(source)==len(unique)==keyed and len(source)>0),
                    'runtime_identity_ready_v2169':bool(ident.get('ready')),'model_generation_v2169':ident.get('model_generation'),'auto_buy':False})
    _atomic_json(OUTCOME_STATUS,outcome)
    return result
run_once=run_once__v2169
run_once.__name__='run_once';run_once.__qualname__='run_once'


def ledger_v2169_once():
    marker=BASE_DIR/'runtime'/'review_v2169_full_candidate_continuity.seeded'
    if marker.exists():return
    ts=now_ts();txt=now_text(ts)
    append_jsonl(CHANGE_LEDGER,{'schema':'change_verify_ledger_v870','change_id':'V2169-REVIEW-FULL-CANDIDATE-CONTINUITY','issue_id':'CANDIDATE-462-AND-TRIGGER-LATENCY-2169','version':'v2169','verify_result':'LOCAL_PASS_SERVER_CHECK','created_ts':ts,'created_at':txt,'writer':'review_worker_v2.067','cause':'Review stable keys required completed invalid/T1 geometry, so only 437 of 462 canonical rows were tracked and market winners appeared candidate-missing.','fix':'Use exact structure key when available and a review-only ticker+model continuity key for incomplete geometry. This changes no Strategy/Paper decision and uses no ticker/time actual linkage.','not_touched':['candidate grade','actual exact key rules','Paper/exit','historical ledgers','auto-buy OFF'],'auto_buy':False})
    marker.parent.mkdir(parents=True,exist_ok=True);marker.write_text(txt,encoding='utf-8')
# v2245 deferred module-level call: ledger_v2169_once runs after runtime identity publication.


# =============================================================================
# v2170 exact current-signature/cycle Review owner.
# The candidate JSONL is append-only, so current analysis must not accept an
# unsigned row or an older cycle merely because it shares the strategy generation.
# =============================================================================
VERSION='review_worker_v2.069'
BUILD_LABEL='v2170_exact_current_signature_cycle_review_2026-07-23'
MAIN_DEPLOY_VERSION=BUILD_LABEL
V2170_EXPECTED_WORKER='strategy_worker_v2.065'
V2170_EXPECTED_BUILD='v2171_snapshot_receipt_rollback_history_2026-07-23'
V2170_EXPECTED_CORE='strategy_v2_core_v2171'
V2170_EXPECTED_MODEL='FULL_INPUT_V2171'


def _v2170_tail_rows(path,limit=7000):
    try:
        with Path(path).open('rb') as f:
            size=Path(path).stat().st_size;f.seek(max(0,size-128*1024*1024));data=f.read().decode('utf-8',errors='ignore')
        lines=data.splitlines()
        if size>128*1024*1024 and lines:lines=lines[1:]
    except Exception:return []
    out=[]
    for line in lines[-max(1,int(limit)):]:
        try:r=json.loads(line)
        except Exception:continue
        if isinstance(r,dict):out.append(r)
    return out


def _v2170_row_sig(row):
    c=contract_of(row)
    return str(c.get('runtime_signature_v2170') or c.get('runtime_signature_v2169') or c.get('runtime_signature_v2168') or row.get('runtime_signature_v2170') or row.get('runtime_signature_v2169') or row.get('runtime_signature_v2168') or '')


def _v2170_row_cycle(row):
    c=contract_of(row)
    return str(row.get('candidate_pipeline_cycle_id_v1150') or row.get('cycle_id') or c.get('cycle_id') or '')


def _v2170_row_ts(row):
    c=contract_of(row)
    for v in (row.get('candidate_pipeline_cycle_started_ts_v1152'),c.get('evaluated_ts'),row.get('updated_ts'),row.get('source_ts')):
        try:
            if v not in (None,''):return float(v)
        except Exception:pass
    return 0.0


def _v2170_current_rows():
    ident=load_json(IDENTITY_PATH,{}) or {};sig=str(ident.get('runtime_signature') or '');cycle=str(ident.get('cycle_id') or '')
    groups={};rejected=Counter()
    for row in _v2170_tail_rows(PAPER_LATEST,7000):
        if str(row.get('strategy_generation_v2149') or '')!=GENERATION:continue
        rs=_v2170_row_sig(row);rc=_v2170_row_cycle(row)
        if not rs or rs!=sig:rejected['signature']+=1;continue
        if cycle and rc!=cycle:rejected['cycle']+=1;continue
        if not rc:rejected['cycle_missing']+=1;continue
        groups.setdefault(rc,[]).append(row)
    if not groups:return [],dict(rejected)
    selected=cycle if cycle in groups else max(groups,key=lambda k:max([_v2170_row_ts(x) for x in groups[k]] or [0.0]))
    by={}
    for row in groups[selected]:
        t=ticker(row.get('ticker') or row.get('market') or row.get('symbol'))
        if t and (t not in by or _v2170_row_ts(row)>=_v2170_row_ts(by[t])):by[t]=row
    return list(by.values()),dict(rejected)


def _v2170_identity(source_rows):
    ident=load_json(IDENTITY_PATH,{}) or {};st=load_json(STRATEGY_STATUS,{}) or {};hold=load_json(BASE_DIR/'paper_s1_hold_cache.json',{}) or {}
    sig=str(ident.get('runtime_signature') or '');cycle=str(ident.get('cycle_id') or '')
    candidate_sigs=Counter(_v2170_row_sig(r) for r in source_rows if _v2170_row_sig(r));candidate_cycles=Counter(_v2170_row_cycle(r) for r in source_rows if _v2170_row_cycle(r));models=Counter(actual_model(r,contract_of(r)) for r in source_rows if actual_model(r,contract_of(r)))
    hold_sig=str(hold.get('runtime_signature_v2170') or hold.get('runtime_signature_v2169') or hold.get('runtime_signature_v2168') or '')
    hold_commit=str(hold.get('candidate_commit_id') or '');status_sig=str(st.get('runtime_signature_v2170') or st.get('runtime_signature_v2169') or (st.get('runtime_identity_v2170') or st.get('runtime_identity_v2169') or {}).get('runtime_signature') or '')
    ready=bool(ident.get('ready') is True and ident.get('worker_version')==V2170_EXPECTED_WORKER and ident.get('worker_build')==V2170_EXPECTED_BUILD and ident.get('core_version')==V2170_EXPECTED_CORE and ident.get('model_generation')==V2170_EXPECTED_MODEL and sig and set(candidate_sigs)=={sig} and (not cycle or set(candidate_cycles)=={cycle}) and set(models)=={V2170_EXPECTED_MODEL} and hold_sig==sig and status_sig==sig and hold_commit==str(ident.get('candidate_commit_id') or ''))
    return {'schema':'review_strategy_runtime_identity_v2170','ready':ready,**{k:ident.get(k) for k in ident},'candidate_signature_counts':dict(candidate_sigs),'candidate_cycle_counts':dict(candidate_cycles),'candidate_model_counts':dict(models),'hold_signature':hold_sig,'hold_commit':hold_commit,'status_signature':status_sig,'source':'exact current runtime signature + exact current candidate cycle only','auto_buy':False}

_runtime_identity_from_strategy=_v2170_identity
_V2170_BASE_READ_JSONL=read_jsonl
_V2170_BASE_RUN=run_once


def run_once__v2170():
    current,rejected=_v2170_current_rows()
    def scoped_read(path,max_lines=1000):
        try:
            if Path(path).resolve()==Path(PAPER_LATEST).resolve():return [dict(x) for x in current]
        except Exception:pass
        return _V2170_BASE_READ_JSONL(path,max_lines)
    globals()['read_jsonl']=scoped_read
    try:result=_V2170_BASE_RUN()
    finally:globals()['read_jsonl']=_V2170_BASE_READ_JSONL
    result=dict(result) if isinstance(result,dict) else {}
    ident=_v2170_identity(current);unique={ticker(r.get('ticker') or r.get('market') or r.get('symbol')) for r in current if isinstance(r,dict)};unique.discard('')
    keyed=sum(1 for r in current if stable_key(r,contract_of(r)));priced=sum(1 for r in current if row_price(r))
    quality_wait=sum(1 for r in current if str(contract_of(r).get('state') or '')=='QUALITY_STRUCTURE_WAIT')
    status=load_json(STATUS,{}) or {};outcome=load_json(OUTCOME_STATUS,{}) or {}
    fields={'version':VERSION,'build':BUILD_LABEL,'runtime_identity_v2170':ident,'runtime_identity_ready_v2170':bool(ident.get('ready')),'runtime_identity_ready_v2169':bool(ident.get('ready')),
            'model_generation_v2170':ident.get('model_generation'),'candidate_source_rows_v2170':len(current),'candidate_unique_tickers_v2170':len(unique),'candidate_stable_keys_v2170':keyed,'candidate_prices_v2170':priced,
            'candidate_current_signature_cycle_pass_v2170':bool(ident.get('ready') and len(current)==len(unique)==keyed and len(current)>0),'rejected_old_or_unsigned_rows_v2170':rejected,
            'quality_structure_min_v2170':0.341,'quality_structure_wait_count_v2170':quality_wait,'historical_ledgers_rewritten':False,'auto_buy':False}
    status.update(fields);_atomic_json(STATUS,status)
    outcome.update({'review_candidate_source_rows_v2170':len(current),'review_candidate_unique_tickers_v2170':len(unique),'review_candidate_stable_keys_v2170':keyed,
                    'review_candidate_current_signature_cycle_pass_v2170':fields['candidate_current_signature_cycle_pass_v2170'],'runtime_identity_ready_v2170':bool(ident.get('ready')),
                    'model_generation_v2170':ident.get('model_generation'),'quality_structure_wait_count_v2170':quality_wait,'auto_buy':False});_atomic_json(OUTCOME_STATUS,outcome)
    return result

run_once=run_once__v2170
run_once.__name__='run_once';run_once.__qualname__='run_once'


def _v2170_ledger_once():
    marker=BASE_DIR/'runtime'/'review_v2170_current_signature_cycle.seeded'
    if marker.exists():return
    ts=now_ts();txt=now_text(ts)
    try:
        append_jsonl(CHANGE_LEDGER,{'schema':'change_verify_ledger_v870','change_id':'V2170-REVIEW-CURRENT-SIGNATURE-CYCLE','issue_id':'CURRENT-ROW-IDENTITY-PAPER-ZERO-S1-QUALITY-2170','version':'v2170','verify_result':'LOCAL_PASS_SERVER_CHECK','created_ts':ts,'created_at':txt,'writer':'review_worker_v2.068','cause':'The append-only candidate tail accepted unsigned and older-cycle rows, causing current market winners to be labeled runtime identity mismatch.','fix':'Scope every Review read to the exact active runtime signature and candidate cycle, deduplicate by ticker inside that cycle, and expose rejected old/unsigned counts.','not_touched':['actual exact key rules','Strategy/Paper decisions','historical outcome ledgers','auto-buy OFF'],'auto_buy':False})
        marker.parent.mkdir(parents=True,exist_ok=True);marker.write_text(txt,encoding='utf-8')
    except Exception:pass
# v2245 deferred module-level call: _v2170_ledger_once runs after runtime identity publication.

# =============================================================================
# v2171: consume Strategy's current snapshot directly. No second current-row
# filter is allowed in Review.
# =============================================================================
VERSION='review_worker_v2.069'
BUILD_LABEL='v2171_current_snapshot_outcome_2026-07-23'
MAIN_DEPLOY_VERSION=BUILD_LABEL
V2171_SNAPSHOT=BASE_DIR/'runtime'/'current_candidate_snapshot_v2171.json'


def _v2171_snapshot():
    obj=load_json(V2171_SNAPSHOT,{}) or {};rows=obj.get('rows') if isinstance(obj.get('rows'),list) else []
    return obj,[dict(r) for r in rows if isinstance(r,dict)]


def _v2170_current_rows():  # type: ignore[override]
    snap,rows=_v2171_snapshot()
    return rows,{} if rows else {'snapshot_missing':1}


def _v2170_identity(source_rows):  # type: ignore[override]
    snap,_=_v2171_snapshot();ident=snap.get('runtime_identity') if isinstance(snap.get('runtime_identity'),dict) else load_json(IDENTITY_PATH,{}) or {}
    hold=load_json(BASE_DIR/'paper_s1_hold_cache.json',{}) or {};sig=str(snap.get('runtime_signature') or ident.get('runtime_signature') or '')
    cycle=str(snap.get('cycle_id') or '');commit=str(snap.get('candidate_commit_id') or '')
    ready=bool(snap.get('row_count') and len(source_rows)==int(snap.get('row_count') or 0)==int(snap.get('unique_tickers') or 0)
               and ident.get('worker_version')=='strategy_worker_v2.065' and ident.get('core_version')=='strategy_v2_core_v2171'
               and ident.get('model_generation')=='FULL_INPUT_V2171' and sig and str(hold.get('runtime_signature_v2171') or '')==sig
               and str(hold.get('candidate_commit_id') or '')==commit and str(hold.get('cycle_id') or '')==cycle)
    return {'schema':'review_strategy_runtime_identity_v2171','ready':ready,**{k:ident.get(k) for k in ident},
            'runtime_signature':sig,'cycle_id':cycle,'candidate_commit_id':commit,'candidate_snapshot_id_v2171':snap.get('snapshot_id'),
            'source':'Strategy current_candidate_snapshot_v2171.json; no Review re-filter','auto_buy':False}


_V2171_BASE_RUN=run_once

def run_once__v2171():
    result=_V2171_BASE_RUN();result=dict(result) if isinstance(result,dict) else {}
    snap,rows=_v2171_snapshot();unique={ticker(r.get('ticker') or r.get('market') or r.get('symbol')) for r in rows};unique.discard('')
    identity=_v2170_identity(rows);status=load_json(STATUS,{}) or {};outcome=load_json(OUTCOME_STATUS,{}) or {}
    fields={'version':VERSION,'build':BUILD_LABEL,'runtime_identity_v2171':identity,'runtime_identity_ready_v2171':bool(identity.get('ready')),
            'candidate_snapshot_id_v2171':snap.get('snapshot_id'),'candidate_source_rows_v2171':len(rows),'candidate_unique_tickers_v2171':len(unique),
            'candidate_snapshot_exact_v2171':bool(identity.get('ready') and len(rows)==len(unique)==int(snap.get('row_count') or 0)),
            'quality_structure_gate_active_v2171':False,'v2170_failed_gate_rolled_back_v2171':True,
            'quality_structure_wait_count_v2171':sum(1 for r in rows if str(contract_of(r).get('state') or '')=='QUALITY_STRUCTURE_WAIT'),
            'historical_ledgers_rewritten':False,'auto_buy':False}
    status.update(fields);_atomic_json(STATUS,status)
    outcome.update({'review_candidate_source_rows_v2171':len(rows),'review_candidate_unique_tickers_v2171':len(unique),
                    'review_candidate_snapshot_exact_v2171':fields['candidate_snapshot_exact_v2171'],'runtime_identity_ready_v2171':bool(identity.get('ready')),
                    'model_generation_v2171':'FULL_INPUT_V2171','quality_structure_gate_active_v2171':False,'auto_buy':False});_atomic_json(OUTCOME_STATUS,outcome)
    result.update(fields)
    return result

run_once=run_once__v2171
run_once.__name__='run_once';run_once.__qualname__='run_once'


def _v2171_ledger_once():
    marker=BASE_DIR/'runtime'/'review_v2171_snapshot_owner.seeded'
    if marker.exists():return
    ts=now_ts();txt=now_text(ts)
    try:
        append_jsonl(CHANGE_LEDGER,{'schema':'change_verify_ledger_v870','change_id':'V2171-REVIEW-CURRENT-SNAPSHOT','issue_id':'V2170-CANDIDATE-REVIEW-PAPER-QUALITY-FAIL','version':'v2171','verify_result':'LOCAL_PASS_SERVER_CHECK','created_ts':ts,'created_at':txt,'writer':VERSION,'cause':'Review independently re-filtered the candidate JSONL and reduced a valid Strategy snapshot to zero.','fix':'Read the exact Strategy current snapshot file with no secondary signature/cycle filtering.','not_touched':['actual exact key rules','Strategy decisions','historical outcome ledgers','auto-buy OFF'],'auto_buy':False})
        marker.parent.mkdir(parents=True,exist_ok=True);marker.write_text(txt,encoding='utf-8')
    except Exception:pass
# v2245 deferred module-level call: _v2171_ledger_once runs after runtime identity publication.

# =============================================================================
# v2172 Review consumes the one Strategy snapshot and records no second owner.
# =============================================================================
VERSION='review_worker_v2.070'
BUILD_LABEL='v2172_exact_current_snapshot_owner_2026-07-23'
MAIN_DEPLOY_VERSION=BUILD_LABEL
V2172_SNAPSHOT=BASE_DIR/'runtime'/'current_candidate_snapshot_v2172.json'
V2171_SNAPSHOT=V2172_SNAPSHOT


def _v2171_snapshot():  # type: ignore[override]
    obj=load_json(V2172_SNAPSHOT,{}) or {};rows=obj.get('rows') if isinstance(obj.get('rows'),list) else []
    return obj,[dict(r) for r in rows if isinstance(r,dict)]


def _v2170_current_rows():  # type: ignore[override]
    snap,rows=_v2171_snapshot();return rows,{} if rows else {'snapshot_missing':1}


def _v2170_identity(source_rows):  # type: ignore[override]
    snap,_=_v2171_snapshot();ident=snap.get('runtime_identity') if isinstance(snap.get('runtime_identity'),dict) else load_json(IDENTITY_PATH,{}) or {}
    hold=load_json(BASE_DIR/'paper_s1_hold_cache.json',{}) or {};sig=str(snap.get('runtime_signature') or ident.get('runtime_signature') or '')
    cycle=str(snap.get('cycle_id') or '');commit=str(snap.get('candidate_commit_id') or '')
    ready=bool(snap.get('row_count') and len(source_rows)==int(snap.get('row_count') or 0)==int(snap.get('unique_tickers') or 0)
               and ident.get('worker_version')=='strategy_worker_v2.066' and ident.get('core_version')=='strategy_v2_core_v2171'
               and ident.get('model_generation')=='FULL_INPUT_V2171' and sig and str(hold.get('runtime_signature_v2172') or '')==sig
               and str(hold.get('candidate_commit_id') or '')==commit and str(hold.get('cycle_id') or '')==cycle)
    return {'schema':'review_strategy_runtime_identity_v2172','ready':ready,**{k:ident.get(k) for k in ident},
            'runtime_signature':sig,'cycle_id':cycle,'candidate_commit_id':commit,'candidate_snapshot_id_v2172':snap.get('snapshot_id'),
            'source':'Strategy current_candidate_snapshot_v2172.json; no Review re-filter','auto_buy':False}


_V2172_BASE_RUN=run_once

def run_once__v2172():
    result=_V2172_BASE_RUN();result=dict(result) if isinstance(result,dict) else {}
    snap,rows=_v2171_snapshot();unique={ticker(r.get('ticker') or r.get('market') or r.get('symbol')) for r in rows};unique.discard('')
    identity=_v2170_identity(rows);status=load_json(STATUS,{}) or {};outcome=load_json(OUTCOME_STATUS,{}) or {}
    fields={'version':VERSION,'build':BUILD_LABEL,'runtime_identity_v2172':identity,'runtime_identity_ready_v2172':bool(identity.get('ready')),
            'candidate_snapshot_id_v2172':snap.get('snapshot_id'),'candidate_source_rows_v2172':len(rows),'candidate_unique_tickers_v2172':len(unique),
            'candidate_snapshot_exact_v2172':bool(identity.get('ready') and len(rows)==len(unique)==int(snap.get('row_count') or 0)),
            'current_row_secondary_filter_used_v2172':False,'model_generation_v2172':'FULL_INPUT_V2171',
            'quality_structure_gate_active_v2172':False,'historical_ledgers_rewritten':False,'auto_buy':False}
    status.update(fields);_atomic_json(STATUS,status)
    outcome.update({'review_candidate_source_rows_v2172':len(rows),'review_candidate_unique_tickers_v2172':len(unique),
                    'review_candidate_snapshot_exact_v2172':fields['candidate_snapshot_exact_v2172'],
                    'runtime_identity_ready_v2172':bool(identity.get('ready')),'model_generation_v2172':'FULL_INPUT_V2171',
                    'quality_structure_gate_active_v2172':False,'auto_buy':False});_atomic_json(OUTCOME_STATUS,outcome)
    result.update(fields);return result
run_once=run_once__v2172
run_once.__name__='run_once';run_once.__qualname__='run_once'


# =============================================================================
# v2173 exact Strategy snapshot owner. No secondary current-row filter.
# =============================================================================
VERSION='review_worker_v2.071'
BUILD_LABEL='v2173_exact_snapshot_fast_event_owner_2026-07-23'
MAIN_DEPLOY_VERSION=BUILD_LABEL
V2173_SNAPSHOT=BASE_DIR/'runtime'/'current_candidate_snapshot_v2173.json'
V2172_SNAPSHOT=V2173_SNAPSHOT
V2171_SNAPSHOT=V2173_SNAPSHOT


def _v2171_snapshot():  # type: ignore[override]
    obj=load_json(V2173_SNAPSHOT,{}) or {};rows=obj.get('rows') if isinstance(obj.get('rows'),list) else []
    return obj,[dict(r) for r in rows if isinstance(r,dict)]


def _v2170_current_rows():  # type: ignore[override]
    snap,rows=_v2171_snapshot();return rows,{} if rows else {'snapshot_missing':1}


def _v2170_identity(source_rows):  # type: ignore[override]
    snap,_=_v2171_snapshot();ident=snap.get('runtime_identity') if isinstance(snap.get('runtime_identity'),dict) else load_json(IDENTITY_PATH,{}) or {};hold=load_json(BASE_DIR/'paper_s1_hold_cache.json',{}) or {}
    sig=str(snap.get('runtime_signature') or ident.get('runtime_signature') or '');cycle=str(snap.get('cycle_id') or '');commit=str(snap.get('candidate_commit_id') or '')
    ready=bool(snap.get('row_count') and len(source_rows)==int(snap.get('row_count') or 0)==int(snap.get('unique_tickers') or 0) and ident.get('worker_version')=='strategy_worker_v2.067'
               and ident.get('core_version')=='strategy_v2_core_v2171' and ident.get('model_generation')=='FULL_INPUT_V2171' and sig
               and str(hold.get('runtime_signature_v2173') or '')==sig and str(hold.get('candidate_commit_id') or '')==commit and str(hold.get('cycle_id') or '')==cycle
               and hold.get('publish_ready_v2173') is True)
    return {'schema':'review_strategy_runtime_identity_v2173','ready':ready,**{k:ident.get(k) for k in ident},'runtime_signature':sig,'cycle_id':cycle,'candidate_commit_id':commit,
            'candidate_snapshot_id_v2173':snap.get('snapshot_id'),'source':'Strategy current_candidate_snapshot_v2173.json only','auto_buy':False}

_V2173_BASE_RUN=run_once
def run_once__v2173():
    result=_V2173_BASE_RUN();result=dict(result) if isinstance(result,dict) else {};snap,rows=_v2171_snapshot();unique={ticker(r.get('ticker') or r.get('market') or r.get('symbol')) for r in rows};unique.discard('');identity=_v2170_identity(rows)
    status=load_json(STATUS,{}) or {};outcome=load_json(OUTCOME_STATUS,{}) or {};summary=snap.get('summary') if isinstance(snap.get('summary'),dict) else {}
    fields={'version':VERSION,'build':BUILD_LABEL,'runtime_identity_v2173':identity,'runtime_identity_ready_v2173':bool(identity.get('ready')),'candidate_snapshot_id_v2173':snap.get('snapshot_id'),
            'candidate_source_rows_v2173':len(rows),'candidate_unique_tickers_v2173':len(unique),'candidate_snapshot_exact_v2173':bool(identity.get('ready') and len(rows)==len(unique)==int(snap.get('row_count') or 0)),
            'current_row_secondary_filter_used_v2173':False,'model_generation_v2173':'FULL_INPUT_V2171','fast_direct_rows_merged_v2173':summary.get('fast_direct_rows_merged_v2173'),
            'candidate_quality_numbers_changed_v2173':False,'historical_ledgers_rewritten':False,'auto_buy':False}
    status.update(fields);_atomic_json(STATUS,status);outcome.update({'review_candidate_source_rows_v2173':len(rows),'review_candidate_unique_tickers_v2173':len(unique),'review_candidate_snapshot_exact_v2173':fields['candidate_snapshot_exact_v2173'],
        'runtime_identity_ready_v2173':bool(identity.get('ready')),'model_generation_v2173':'FULL_INPUT_V2171','fast_direct_rows_merged_v2173':summary.get('fast_direct_rows_merged_v2173'),'auto_buy':False});_atomic_json(OUTCOME_STATUS,outcome);result.update(fields);return result
run_once=run_once__v2173
run_once.__name__='run_once';run_once.__qualname__='run_once'



# =============================================================================
# review_worker v2.074 / v2176
# Canonical current snapshot reader. No JSONL re-filter, no prior snapshot
# fallback, and no second decision owner.
# =============================================================================
VERSION='review_worker_v2.075'
BUILD_LABEL='v2187_review_runtime_actual_cycle_repair_2026-07-24'
MAIN_DEPLOY_VERSION=BUILD_LABEL
V2176_SNAPSHOT=BASE_DIR/'runtime'/'current_candidate_snapshot_v2176.json'


def _v2171_snapshot():  # type: ignore[override]
    obj=load_json(V2176_SNAPSHOT,{}) or {}
    rows=obj.get('rows') if isinstance(obj.get('rows'),list) else []
    return obj,[dict(row) for row in rows if isinstance(row,dict)]


def _v2170_identity(source_rows):  # type: ignore[override]
    snap,_=_v2171_snapshot()
    ident=snap.get('runtime_identity') if isinstance(snap.get('runtime_identity'),dict) else load_json(IDENTITY_PATH,{}) or {}
    hold=load_json(BASE_DIR/'paper_s1_hold_cache.json',{}) or {}
    sig=str(snap.get('runtime_signature') or ident.get('runtime_signature') or '')
    cycle=str(snap.get('cycle_id') or '')
    commit=str(snap.get('candidate_commit_id') or '')
    rows=len(source_rows); unique=len({ticker(row.get('ticker') or row.get('market') or row.get('symbol')) for row in source_rows if ticker(row.get('ticker') or row.get('market') or row.get('symbol'))})
    ready=bool(
        rows>0 and rows==unique==int(snap.get('row_count') or 0)==int(snap.get('unique_tickers') or 0)
        and ident.get('worker_version')=='strategy_worker_v2.071'
        and ident.get('worker_build')=='v2182_strategy_final_main_singleton_lifecycle_restore_2026-07-24'
        and ident.get('core_version')=='strategy_v2_core_v2171'
        and ident.get('model_generation')=='FULL_INPUT_V2171'
        and sig and ident.get('single_decision_owner')
        and str(hold.get('runtime_signature_v2176') or '')==sig
        and str(hold.get('candidate_commit_id') or '')==commit
        and str(hold.get('cycle_id') or '')==cycle
        and hold.get('publish_ready_v2176') is True
        and hold.get('single_decision_function_full_and_event_v2176') is True
        and bool(hold.get('s1_generation_id_v2176'))
        and bool(hold.get('hold_hash_v2176'))
        and int(hold.get('row_count') or 0)==len(hold.get('rows') or [])
    )
    return {
        'schema':'review_strategy_runtime_identity_v2176','ready':ready,
        **{key:ident.get(key) for key in ident},
        'runtime_signature':sig,'cycle_id':cycle,'candidate_commit_id':commit,
        'candidate_snapshot_id_v2176':snap.get('snapshot_id'),
        'source':'Strategy current_candidate_snapshot_v2176.json only',
        'current_row_secondary_filter_used_v2176':False,
        'paper_latest_jsonl_used_for_current_v2176':False,
        'single_decision_owner_v2176':True,
        'auto_buy':False,
    }


_V2176_BASE_RUN=run_once

def run_once__v2176():
    result=_V2176_BASE_RUN()
    result=dict(result) if isinstance(result,dict) else {}
    snap,rows=_v2171_snapshot()
    unique={ticker(row.get('ticker') or row.get('market') or row.get('symbol')) for row in rows}; unique.discard('')
    identity=_v2170_identity(rows)
    summary=snap.get('summary') if isinstance(snap.get('summary'),dict) else {}
    event_status=load_json(BASE_DIR/'strategy_completed_bar_event_status_v2176.json',{}) or {}
    hold=load_json(BASE_DIR/'paper_s1_hold_cache.json',{}) or {}
    status=load_json(STATUS,{}) or {}
    outcome=load_json(OUTCOME_STATUS,{}) or {}
    review_state=('ACTIVE' if identity.get('ready') and rows else ('WAITING_ACTIVE_MODEL_CANDIDATES' if identity.get('ready') else 'RUNTIME_IDENTITY_CHECK'))
    fields={
        'version':VERSION,'build':BUILD_LABEL,
        'state':'running','review_state_v2187':review_state,'phase':'cycle_done_v2187',
        'cycle_complete_v2187':True,'error':None,'updated_ts':now_ts(),'updated_text':now_text(),
        'runtime_identity_v2176':identity,
        'runtime_identity_ready_v2176':bool(identity.get('ready')),
        'candidate_snapshot_id_v2176':snap.get('snapshot_id'),
        'candidate_commit_id_v2176':snap.get('candidate_commit_id'),
        's1_generation_id_v2176':hold.get('s1_generation_id_v2176'),
        'hold_hash_v2176':hold.get('hold_hash_v2176'),
        'hold_row_count_v2176':hold.get('row_count'),
        'candidate_source_rows_v2176':len(rows),
        'candidate_unique_tickers_v2176':len(unique),
        'candidate_snapshot_exact_v2176':bool(identity.get('ready') and len(rows)==len(unique)==int(snap.get('row_count') or 0)),
        'current_row_secondary_filter_used_v2176':False,
        'paper_latest_jsonl_used_for_current_v2176':False,
        'model_generation_v2176':'FULL_INPUT_V2171',
        'single_decision_function_full_and_event_v2176':summary.get('single_decision_function_full_and_event_v2176') is True,
        'separate_fast_decision_function_active_v2176':False,
        'completed_bar_event_state_v2176':event_status.get('state'),
        'completed_bar_event_entry_ready_v2176':event_status.get('entry_ready'),
        'completed_bar_event_direct_published_v2176':event_status.get('direct_published'),
        'candidate_quality_numbers_changed_v2176':False,
        'review_hold_local_fixed_v2187':True,
        'review_strategy_identity_aligned_v2187':True,
        'review_worker_state_contract_fixed_v2187':True,
        'historical_ledgers_rewritten':False,
        'auto_buy':False,
    }
    status.update(fields); _atomic_json(STATUS,status)
    outcome.update({
        'review_candidate_source_rows_v2176':len(rows),
        'review_candidate_unique_tickers_v2176':len(unique),
        'review_candidate_snapshot_exact_v2176':fields['candidate_snapshot_exact_v2176'],
        'runtime_identity_ready_v2176':bool(identity.get('ready')),
        'model_generation_v2176':'FULL_INPUT_V2171',
        'current_row_secondary_filter_used_v2176':False,
        'auto_buy':False,
    }); _atomic_json(OUTCOME_STATUS,outcome)
    result.update(fields)
    return result

run_once=run_once__v2176
run_once.__name__='run_once';run_once.__qualname__='run_once'


def _v2176_ledger_once():
    marker=BASE_DIR/'runtime'/'review_v2176_canonical_snapshot.seeded'
    if marker.exists():return
    ts=now_ts(); txt=now_text(ts)
    try:
        append_jsonl(CHANGE_LEDGER,{'schema':'change_verify_ledger_v870','change_id':'V2176-REVIEW-CANONICAL-SNAPSHOT','issue_id':'V2174-CROSSED-EXACT-BUT-DIRECT-ZERO','version':'v2176','verify_result':'LOCAL_PASS_SERVER_CHECK','created_ts':ts,'created_at':txt,'writer':'review_v2176_lifecycle','cause':'Review current candidates could be rebuilt from legacy current/JSONL readers after Strategy had already sealed a canonical snapshot.','fix':'Read only current_candidate_snapshot_v2176.json and use its exact rows/commit/runtime identity without secondary filtering or decision recomputation.','not_touched':['outcome history','prediction formula','candidate quality','Paper/exit','historical ledgers','auto-buy OFF'],'auto_buy':False})
        marker.parent.mkdir(parents=True,exist_ok=True);marker.write_text(txt,encoding='utf-8')
    except Exception as exc:append_error('v2176_ledger',exc)
# v2245 deferred module-level call: _v2176_ledger_once runs after runtime identity publication.


def _v2187_ledger_once():
    marker=BASE_DIR/'runtime'/'review_v2187_runtime_actual_cycle_repair.seeded'
    if marker.exists(): return
    ts=now_ts(); txt=now_text(ts)
    try:
        append_jsonl(CHANGE_LEDGER,{'schema':'change_verify_ledger_v870','change_id':'V2187-REVIEW-RUNTIME-ACTUAL-CYCLE-REPAIR','issue_id':'V2186-REVIEW-NAMEERROR-READY-FAIL','version':'v2187','verify_result':'LOCAL_PASS_SERVER_CHECK','created_ts':ts,'created_at':txt,'writer':'review_worker_v2.075','cause':'The active v2176 Review wrapper referenced hold without loading it, so every first cycle ended in NameError and Guard waited 95 seconds before failing. The Review identity still expected Strategy v2.069 while the deployed canonical Strategy is v2.071, and the worker status used analysis states where Guard expects running.','fix':'Load the existing Paper hold in the active wrapper, align the existing identity check to Strategy v2.071, and publish running as the worker health state while preserving the analysis state separately. No new command, Shadow, pipeline or gate.','not_touched':['prediction formula','candidate thresholds','Trigger/Invalid/T1','Paper costs','entry/exit','historical ledgers','auto-buy OFF'],'auto_buy':False})
        append_jsonl(ISSUE_LEDGER,{'schema':'coinbot_single_work_ledger_v870','event_type':'ISSUE','issue_id':'V2186-REVIEW-NAMEERROR-READY-FAIL','status':'DONE','title':'Review 첫 cycle 오류와 95초 배포 실패','detail':'정의되지 않은 hold 참조, Strategy 버전 기대값, worker 상태표시 계약을 기존 경로 안에서 수리.','version':'v2187','created_ts':ts,'created_at':txt,'auto_buy':False})
        marker.parent.mkdir(parents=True,exist_ok=True); marker.write_text(txt,encoding='utf-8')
    except Exception as exc:
        append_error('v2187_ledger',exc)
# v2245 deferred module-level call: _v2187_ledger_once runs after runtime identity publication.



# =============================================================================
# v2188 detailed prediction-to-result verification.
# Existing Review state/ledger is reused. Each event seals the detailed scores
# once, then labels every 30m/1h/3h/6h axis as correct/wrong from actual MFE/MAE.
# =============================================================================
VERSION='review_worker_v2.076'
BUILD_LABEL='v2188_prediction_input_outcome_verification_2026-07-24'
MAIN_DEPLOY_VERSION=BUILD_LABEL
V2188_EXPECTED_WORKER='strategy_worker_v2.072'
V2188_EXPECTED_BUILD='v2188_prediction_primary_committed_handoff_2026-07-24'
V2188_EXPECTED_CORE='strategy_v2_core_v2172'
V2188_EXPECTED_MODEL='FULL_INPUT_V2188_PRIMARY'
_V2188_BASE_STABLE_KEY=stable_key
_V2188_BASE_CREATE_RECORD=create_record
_V2188_BASE_UPDATE_PATH=update_path
_V2188_BASE_RUN=run_once


def _v2188_deepcopy(value):
    try:return json.loads(json.dumps(value,ensure_ascii=False,default=str))
    except Exception:return {}


def stable_key(row,c):  # type: ignore[override]
    t=ticker(row.get('ticker') or c.get('ticker'))
    for value in (row.get('candidate_event_id_v2176'),c.get('candidate_event_id_v2176'),c.get('decision_key'),row.get('direct_decision_key_v2149'),c.get('plan_key'),c.get('pretrigger_contract_id_v2176')):
        key=str(value or '').strip()
        if t and key:return f'{GENERATION}|{t}|v2188:{key}'
    return _V2188_BASE_STABLE_KEY(row,c)


def create_record(row,c,price,nowv,key):  # type: ignore[override]
    rec=_V2188_BASE_CREATE_RECORD(row,c,price,nowv,key)
    pred=c.get('prediction') if isinstance(c.get('prediction'),dict) else {};evidence=c.get('prediction_evidence') if isinstance(c.get('prediction_evidence'),dict) else pred.get('evidence') if isinstance(pred.get('evidence'),dict) else {};structure=c.get('structure') if isinstance(c.get('structure'),dict) else {}
    rec['schema']='strategy_v2_outcome_state_row_v2188';rec['prediction_input_seal_v2188']={'sealed_ts':nowv,'model_generation':c.get('prediction_model_generation') or pred.get('prediction_model_generation'),'prediction_state':pred.get('state'),'continuation_score':num(pred.get('continuation_score')),
        'primary_market_score':num(pred.get('primary_market_score_v2188')),'primary_participation_score':num(pred.get('primary_participation_score_v2188')),'primary_trigger_flow_score':num(pred.get('primary_trigger_flow_score_v2188')),
        'axes':_v2188_deepcopy(evidence.get('primary_axes_v2188') if isinstance(evidence.get('primary_axes_v2188'),dict) else evidence.get('axes') if isinstance(evidence.get('axes'),dict) else {}),
        'groups':_v2188_deepcopy(evidence.get('groups_v2188_primary') if isinstance(evidence.get('groups_v2188_primary'),dict) else evidence.get('groups') if isinstance(evidence.get('groups'),dict) else {}),
        'connections':_v2188_deepcopy(evidence.get('input_connections_v2155') if isinstance(evidence.get('input_connections_v2155'),dict) else {}),
        'entry_contract_mode':structure.get('entry_contract_mode_v2188'),'original_structure_state':structure.get('original_structure_state_v2188') or structure.get('state'),'invalid_mode':structure.get('invalid_mode_v2188'),'target_mode':structure.get('target_mode_v2188'),'sealed_from_current_candidate_event':True,'auto_buy':False}
    rec['prediction_factor_results_v2188']={};rec['prediction_details_preserved_v2188']=True
    return rec


def _v2188_horizon_truth(rec,label,sample):
    sampled=num(sample.get('sampled_ts'),0.0) or 0.0;ups=rec.get('first_up_pct_ts_v2163') if isinstance(rec.get('first_up_pct_ts_v2163'),dict) else {};downs=rec.get('first_down_pct_ts_v2163') if isinstance(rec.get('first_down_pct_ts_v2163'),dict) else {}
    up=num(ups.get('1'));down=num(downs.get('1'));up_ok=bool(up and up<=sampled);down_ok=bool(down and down<=sampled)
    if up_ok and down_ok:return 'UP' if up<down else 'DOWN' if down<up else 'MIXED'
    if up_ok:return 'UP'
    if down_ok:return 'DOWN'
    mfe=num(sample.get('max_pct'),0.0) or 0.0;mae=num(sample.get('min_pct'),0.0) or 0.0
    if mfe>=1.0 and mae>-1.0:return 'UP'
    if mae<=-1.0 and mfe<1.0:return 'DOWN'
    return 'MIXED'


def _v2188_factor_result(score,truth):
    value=num(score)
    if value is None or abs(value)<=0.12 or truth=='MIXED':return 'NOT_SCORED'
    predicted='UP' if value>0 else 'DOWN'
    return 'CORRECT' if predicted==truth else 'WRONG'


def update_path(rec,price,nowv):  # type: ignore[override]
    _V2188_BASE_UPDATE_PATH(rec,price,nowv)
    seal=rec.get('prediction_input_seal_v2188') if isinstance(rec.get('prediction_input_seal_v2188'),dict) else {};axes=seal.get('axes') if isinstance(seal.get('axes'),dict) else {};groups=seal.get('groups') if isinstance(seal.get('groups'),dict) else {};results=rec.setdefault('prediction_factor_results_v2188',{})
    samples=rec.get('samples') if isinstance(rec.get('samples'),dict) else {}
    for label in ('30m','1h','3h','6h'):
        sample=samples.get(label) if isinstance(samples.get(label),dict) else None
        if not sample or label in results:continue
        truth=_v2188_horizon_truth(rec,label,sample);axis_result={axis:_v2188_factor_result(score,truth) for axis,score in axes.items()};group_result={name:_v2188_factor_result((meta or {}).get('score') if isinstance(meta,dict) else meta,truth) for name,meta in groups.items()}
        results[label]={'truth':truth,'sampled_ts':sample.get('sampled_ts'),'mfe_pct':sample.get('max_pct'),'mae_pct':sample.get('min_pct'),'close_pct':sample.get('pct'),'axis_results':axis_result,'group_results':group_result,'rule':'existing +1% versus -1% first-touch, then horizon MFE/MAE','auto_buy':False}


def _v2188_identity(source_rows):
    snap,_=_v2171_snapshot();ident=snap.get('runtime_identity') if isinstance(snap.get('runtime_identity'),dict) else load_json(IDENTITY_PATH,{}) or {};hold=load_json(BASE_DIR/'paper_s1_hold_cache.json',{}) or {};sig=str(snap.get('runtime_signature') or ident.get('runtime_signature') or '');cycle=str(snap.get('cycle_id') or '');commit=str(snap.get('candidate_commit_id') or '')
    rows=len(source_rows);unique=len({ticker(row.get('ticker') or row.get('market') or row.get('symbol')) for row in source_rows if ticker(row.get('ticker') or row.get('market') or row.get('symbol'))})
    ready=bool(rows>0 and rows==unique==int(snap.get('row_count') or 0)==int(snap.get('unique_tickers') or 0) and ident.get('worker_version')==V2188_EXPECTED_WORKER and ident.get('worker_build')==V2188_EXPECTED_BUILD and ident.get('core_version')==V2188_EXPECTED_CORE and ident.get('model_generation')==V2188_EXPECTED_MODEL and sig and ident.get('single_decision_owner') and str(hold.get('runtime_signature_v2176') or '')==sig and str(hold.get('candidate_commit_id') or '')==commit and str(hold.get('cycle_id') or '')==cycle and hold.get('publish_ready_v2176') is True and bool(hold.get('s1_generation_id_v2176')) and bool(hold.get('hold_hash_v2176')) and int(hold.get('row_count') or 0)==len(hold.get('rows') or []))
    return {'schema':'review_strategy_runtime_identity_v2188','ready':ready,**{key:ident.get(key) for key in ident},'runtime_signature':sig,'cycle_id':cycle,'candidate_commit_id':commit,'candidate_snapshot_id_v2176':snap.get('snapshot_id'),'source':'Strategy current_candidate_snapshot_v2176.json only','prediction_primary_v2188':True,'auto_buy':False}


def _v2188_validation_summary(records):
    result={}
    for label in ('30m','1h','3h','6h'):
        axis_counts={};group_counts={};truth=Counter();samples=0
        for rec in records:
            if not isinstance(rec,dict):continue
            block=(rec.get('prediction_factor_results_v2188') or {}).get(label) if isinstance(rec.get('prediction_factor_results_v2188'),dict) else None
            if not isinstance(block,dict):continue
            samples+=1;truth[str(block.get('truth') or 'MIXED')]+=1
            for axis,state in (block.get('axis_results') or {}).items():
                if state not in ('CORRECT','WRONG'):continue
                axis_counts.setdefault(axis,Counter())[state]+=1
            for group,state in (block.get('group_results') or {}).items():
                if state not in ('CORRECT','WRONG'):continue
                group_counts.setdefault(group,Counter())[state]+=1
        def ranked(counts,state):
            rows=[]
            for name,c in counts.items():
                total=c['CORRECT']+c['WRONG'];rows.append({'name':name,'correct':c['CORRECT'],'wrong':c['WRONG'],'total':total,'accuracy_pct':round(c['CORRECT']/total*100.0,1) if total else None})
            rows.sort(key=lambda x:(x[state.lower()],x['total']),reverse=True);return rows[:6]
        result[label]={'samples':samples,'truth_counts':dict(truth),'top_correct_axes':ranked(axis_counts,'CORRECT'),'top_wrong_axes':ranked(axis_counts,'WRONG'),'group_results':ranked(group_counts,'WRONG')}
    return result


_runtime_identity_from_strategy=_v2188_identity
_v2170_identity=_v2188_identity

def run_once__v2188():
    result=_V2188_BASE_RUN();result=dict(result) if isinstance(result,dict) else {};state=load_json(OUTCOME_STATE,{}) or {};records=list((state.get(STATE_KEY) or {}).values()) if isinstance(state.get(STATE_KEY),dict) else [];finals=[r for r in read_jsonl(OUTCOME_LEDGER,12000) if str(r.get('generation') or '')==GENERATION and str(r.get('prediction_model_generation') or '')==V2188_EXPECTED_MODEL];validation=_v2188_validation_summary(records+finals)
    status=load_json(STATUS,{}) or {};outcome_status=load_json(OUTCOME_STATUS,{}) or {};snap,rows=_v2171_snapshot();identity=_v2188_identity(rows)
    fields={'version':VERSION,'build':BUILD_LABEL,'state':'running','review_state_v2188':'ACTIVE' if identity.get('ready') else 'RUNTIME_IDENTITY_CHECK','runtime_identity_v2188':identity,'runtime_identity_ready_v2188':bool(identity.get('ready')),'model_generation_v2188':V2188_EXPECTED_MODEL,'prediction_validation_v2188':validation,'prediction_details_preserved_v2188':True,'structure_required_for_review_key_v2188':False,'historical_ledgers_rewritten':False,'auto_buy':False}
    status.update(fields);_atomic_json(STATUS,status);outcome_status.update(fields);_atomic_json(OUTCOME_STATUS,outcome_status);result.update(fields);return result
run_once=run_once__v2188
run_once.__name__='run_once';run_once.__qualname__='run_once'


def _v2188_review_ledger_once():
    marker=BASE_DIR/'runtime'/'review_v2188_prediction_verification.seeded'
    if marker.exists():return
    ts=now_ts();txt=now_text(ts)
    try:
        append_jsonl(CHANGE_LEDGER,{'schema':'change_verify_ledger_v870','change_id':'V2188-REVIEW-PREDICTION-OUTCOME','issue_id':'PREDICTION-DETAIL-DROPPED-2188','version':'v2188','verify_result':'LOCAL_PASS_SERVER_CHECK','created_ts':ts,'created_at':txt,'writer':'review_worker_v2.076','cause':'Review kept only broad group scores, so correct and wrong detailed inputs could not be compared to actual 30m/1h/3h/6h paths.','fix':'Seal detailed axis/group/connection values once per candidate event and label correct/wrong from the existing +1%/-1% first-touch and MFE/MAE outcomes.','not_touched':['historical outcome ledger rows','entry thresholds','auto-buy OFF'],'auto_buy':False})
        marker.parent.mkdir(parents=True,exist_ok=True);marker.write_text(txt,encoding='utf-8')
    except Exception as exc:append_error('v2188_review_ledger',exc)
# v2245 deferred module-level call: _v2188_review_ledger_once runs after runtime identity publication.


# =============================================================================
# review_worker v2.077 / v2189: make the model-switch scope explicit.
# active_records remains the current prediction-model scope for compatibility.
# All-generation and prior-model counts prove that the v2188 count drop is a
# reader scope change, not deletion of preserved outcome state.
# =============================================================================
VERSION='review_worker_v2.077'
BUILD_LABEL='v2189_review_model_scope_preservation_2026-07-24'
_V2189_BASE_RUN_ONCE=run_once


def run_once__v2189():
    result=_V2189_BASE_RUN_ONCE();result=dict(result) if isinstance(result,dict) else {}
    state=load_json(OUTCOME_STATE,{}) or {};records=(state.get(STATE_KEY) or {}) if isinstance(state.get(STATE_KEY),dict) else {}
    rows=[r for r in records.values() if isinstance(r,dict) and not r.get('superseded_duplicate_v2154')]
    current_model=str(result.get('active_model_generation_v2168') or result.get('model_generation_v2188') or V2188_EXPECTED_MODEL)
    current=[r for r in rows if str(r.get('prediction_model_generation') or '')==current_model]
    prior=[r for r in rows if str(r.get('prediction_model_generation') or '')!=current_model]
    finals=read_jsonl(OUTCOME_LEDGER,12000)
    fields={'version':VERSION,'build':BUILD_LABEL,'state':'running','active_records':len(current),'active_records_current_model_v2189':len(current),'active_records_all_generation_v2189':len(rows),'active_records_prior_model_v2189':len(prior),'finalized_all_generation_v2189':sum(1 for r in finals if str(r.get('generation') or '')==GENERATION),'review_scope_v2189':'current model active count + preserved prior-model count','prior_model_records_deleted_v2189':False,'historical_ledgers_rewritten':False,'auto_buy':False}
    status=load_json(STATUS,{}) or {};outcome=load_json(OUTCOME_STATUS,{}) or {};status.update(fields);outcome.update(fields);_atomic_json(STATUS,status);_atomic_json(OUTCOME_STATUS,outcome);result.update(fields);return result
run_once=run_once__v2189
run_once.__name__='run_once';run_once.__qualname__='run_once'


def _v2189_review_ledger_once():
    marker=BASE_DIR/'runtime'/'review_v2189_model_scope_preservation.seeded'
    if marker.exists():return
    ts=now_ts();txt=now_text(ts)
    try:
        append_jsonl(CHANGE_LEDGER,{'schema':'change_verify_ledger_v870','change_id':'V2189-REVIEW-MODEL-SCOPE-PRESERVATION','issue_id':'V2189-ZERO-START-AND-REVIEW-SCOPE','version':'v2189','verify_result':'LOCAL_PASS_SERVER_CHECK','created_ts':ts,'created_at':txt,'writer':'review_worker_v2.077','cause':'The public board labelled current-model active_records as cumulative active tracking. After the v2188 model switch, the number therefore appeared to fall from the prior-model scope even though rows were preserved.','fix':'Keep the existing current-model count for compatibility and publish current-model, prior-model and all-generation active counts separately. No outcome row is deleted or rewritten.','not_touched':['prediction thresholds','Paper reset owner','historical outcome ledger','auto-buy OFF'],'auto_buy':False})
        marker.parent.mkdir(parents=True,exist_ok=True);marker.write_text(txt,encoding='utf-8')
    except Exception as exc:append_error('v2189_review_ledger',exc)
# v2245 deferred module-level call: _v2189_review_ledger_once runs after runtime identity publication.

# =============================================================================
# review_worker v2.078 / v2191: unique horizon-result truth.
# Active state and finalized JSONL can contain the same event. Public validation
# now deduplicates by sealed event_key, publishes the actual 6h price-result count,
# and keeps finalized-ledger count separate. No score or trading rule changes.
# =============================================================================
VERSION='review_worker_v2.078'
BUILD_LABEL='v2191_unique_horizon_result_truth_2026-07-25'
MAIN_DEPLOY_VERSION=BUILD_LABEL
_V2191_BASE_RUN_ONCE=run_once


def _v2191_unique_validation_rows():
    state=load_json(OUTCOME_STATE,{}) or {};records=(state.get(STATE_KEY) or {}) if isinstance(state.get(STATE_KEY),dict) else {}
    current_model=str(state.get('active_model_generation_v2168') or V2188_EXPECTED_MODEL)
    chosen={}
    for rec in records.values():
        if not isinstance(rec,dict) or rec.get('superseded_duplicate_v2154'):continue
        if str(rec.get('generation') or '')!=GENERATION or str(rec.get('prediction_model_generation') or '')!=current_model:continue
        key=str(rec.get('event_key') or '')
        if key:chosen[key]=dict(rec)
    finals=[]
    for rec in read_jsonl(OUTCOME_LEDGER,20000):
        if not isinstance(rec,dict) or str(rec.get('generation') or '')!=GENERATION or str(rec.get('prediction_model_generation') or '')!=current_model:continue
        finals.append(rec);key=str(rec.get('event_key') or '')
        if key:chosen[key]=dict(rec)  # finalized row wins over active duplicate
    return list(chosen.values()),finals,current_model


def run_once__v2191():
    result=_V2191_BASE_RUN_ONCE();result=dict(result) if isinstance(result,dict) else {}
    rows,finals,current_model=_v2191_unique_validation_rows()
    validation=_v2188_validation_summary(rows)
    six=int(((validation.get('6h') or {}).get('samples') if isinstance(validation.get('6h'),dict) else 0) or 0)
    fields={
        'version':VERSION,'build':BUILD_LABEL,'state':'running',
        'prediction_validation_v2191':validation,'prediction_validation_v2188':validation,
        'unique_validation_records_v2191':len(rows),'six_hour_price_results_v2191':six,
        'finalized_ledger_current_model_v2191':len(finals),
        'six_hour_result_semantics_v2191':'unique candidate events with an actual 6h price sample',
        'finalized_ledger_semantics_v2191':'append-only 6h finalized outcome rows; shown separately',
        'active_final_duplicate_counted_once_v2191':True,
        'prediction_numbers_changed':False,'historical_ledgers_rewritten':False,'auto_buy':False,
    }
    status=load_json(STATUS,{}) or {};outcome=load_json(OUTCOME_STATUS,{}) or {}
    status.update(fields);outcome.update(fields);_atomic_json(STATUS,status);_atomic_json(OUTCOME_STATUS,outcome);result.update(fields);return result
run_once=run_once__v2191
run_once.__name__='run_once';run_once.__qualname__='run_once'


def _v2191_review_ledger_once():
    marker=BASE_DIR/'runtime'/'review_v2191_unique_horizon_truth.seeded'
    if marker.exists():return
    ts=now_ts();txt=now_text(ts)
    try:
        append_jsonl(CHANGE_LEDGER,{'schema':'change_verify_ledger_v870','change_id':'V2191-REVIEW-UNIQUE-HORIZON-TRUTH','issue_id':'V2191-RESET-SCORE-AND-REVIEW-SAMPLE-MISMATCH','version':'v2191','verify_result':'LOCAL_PASS_SERVER_CHECK','created_ts':ts,'created_at':txt,'writer':'review_worker_v2.078','cause':'The Review board compared 6h factor-result samples with the finalized JSONL count as if they were the same measure, and active/final copies could both enter validation.','fix':'Deduplicate by sealed event_key, publish actual horizon-result counts and finalized-ledger counts separately, and keep the same existing factor scoring formula.','not_touched':['prediction scores and thresholds','outcome ledger rows','entry/exit','auto-buy OFF'],'auto_buy':False})
        marker.parent.mkdir(parents=True,exist_ok=True);marker.write_text(txt,encoding='utf-8')
    except Exception as exc:append_error('v2191_review_ledger',exc)
# v2245 deferred module-level call: _v2191_review_ledger_once runs after runtime identity publication.

# =============================================================================
# review_worker v2.079 / v2192: one event set and factor-by-factor truth.
# - One current-model candidate event is counted once by sealed event_key.
# - The same unique event set feeds 30m/1h/3h/6h totals and every factor result.
# - Market-shared factors are separated from candidate-specific factors by their
#   actual distinct sealed values, so repeated market counts are not presented as
#   independent candidate signals.
# - Existing scoring and +1%/-1% truth rules are unchanged.
# =============================================================================
VERSION='review_worker_v2.079'
BUILD_LABEL='v2192_unique_event_factor_truth_single_snapshot_2026-07-25'
MAIN_DEPLOY_VERSION=BUILD_LABEL
_V2192_BASE_RUN_ONCE=run_once


def _v2192_validation_snapshot():
    rows,finals,current_model=_v2191_unique_validation_rows()
    by_key={}
    for rec in rows:
        if not isinstance(rec,dict):continue
        key=str(rec.get('event_key') or '').strip()
        if key:by_key[key]=dict(rec)
    unique=list(by_key.values())
    result={}
    for label in ('30m','1h','3h','6h'):
        truth=Counter();factor={};sample_keys=[]
        for rec in unique:
            block=(rec.get('prediction_factor_results_v2188') or {}).get(label) if isinstance(rec.get('prediction_factor_results_v2188'),dict) else None
            if not isinstance(block,dict):continue
            key=str(rec.get('event_key') or '')
            sample_keys.append(key);truth[str(block.get('truth') or 'MIXED')]+=1
            seal=rec.get('prediction_input_seal_v2188') if isinstance(rec.get('prediction_input_seal_v2188'),dict) else {}
            axes=seal.get('axes') if isinstance(seal.get('axes'),dict) else {}
            for name,state in (block.get('axis_results') or {}).items():
                item=factor.setdefault(str(name),{'correct':0,'wrong':0,'not_scored':0,'values':set()})
                if state=='CORRECT':item['correct']+=1
                elif state=='WRONG':item['wrong']+=1
                else:item['not_scored']+=1
                try:item['values'].add(round(float(axes.get(name)),6))
                except Exception:pass
        rows_out=[]
        for name,item in factor.items():
            scored=int(item['correct'])+int(item['wrong']);distinct=len(item['values'])
            scope='MARKET_SHARED' if scored>=10 and distinct<=max(3,int(scored*0.01)) else 'CANDIDATE_SPECIFIC'
            rows_out.append({'name':name,'scope':scope,'correct':int(item['correct']),'wrong':int(item['wrong']),'not_scored':int(item['not_scored']),'scored':scored,'accuracy_pct':round(item['correct']/scored*100.0,2) if scored else None,'distinct_sealed_values':distinct})
        candidate=sorted([r for r in rows_out if r['scope']=='CANDIDATE_SPECIFIC' and r['scored']>0],key=lambda r:(r['accuracy_pct'] if r['accuracy_pct'] is not None else 999.0,-r['scored']))
        market=sorted([r for r in rows_out if r['scope']=='MARKET_SHARED' and r['scored']>0],key=lambda r:(r['accuracy_pct'] if r['accuracy_pct'] is not None else 999.0,-r['scored']))
        result[label]={'samples':len(sample_keys),'unique_event_count':len(set(sample_keys)),'truth_counts':dict(truth),'candidate_factor_rows':candidate,'market_factor_rows':market,'all_factor_rows':rows_out,'event_keys':sorted(set(sample_keys))}
    material={'model':current_model,'events':sorted(by_key),'horizons':{k:{'samples':v['samples'],'keys':v['event_keys']} for k,v in result.items()}}
    snapshot_id=hashlib.sha256(json.dumps(material,sort_keys=True,separators=(',',':'),default=str).encode()).hexdigest()[:16]
    for block in result.values():block.pop('event_keys',None)
    return {'schema':'prediction_validation_single_snapshot_v2192','snapshot_id':snapshot_id,'model_generation':current_model,'unique_events':len(unique),'finalized_rows_read':len(finals),'horizons':result,'same_event_owner_all_horizons':True,'score_formula_changed':False,'truth_rule_changed':False,'auto_buy':False}


def run_once__v2192():
    result=_V2192_BASE_RUN_ONCE();result=dict(result) if isinstance(result,dict) else {}
    validation=_v2192_validation_snapshot()
    fields={'version':VERSION,'build':BUILD_LABEL,'state':'running','prediction_validation_single_snapshot_v2192':validation,'validation_snapshot_id_v2192':validation.get('snapshot_id'),'unique_validation_events_v2192':validation.get('unique_events'),'same_event_owner_all_horizons_v2192':True,'market_shared_factors_separated_v2192':True,'prediction_numbers_changed':False,'historical_ledgers_rewritten':False,'auto_buy':False}
    status=load_json(STATUS,{}) or {};outcome=load_json(OUTCOME_STATUS,{}) or {}
    status.update(fields);outcome.update(fields);_atomic_json(STATUS,status);_atomic_json(OUTCOME_STATUS,outcome);result.update(fields);return result
run_once=run_once__v2192
run_once.__name__='run_once';run_once.__qualname__='run_once'


def _v2192_review_ledger_once():
    marker=BASE_DIR/'runtime'/'review_v2192_single_event_factor_truth.seeded'
    if marker.exists():return
    ts=now_ts();txt=now_text(ts)
    try:
        append_jsonl(CHANGE_LEDGER,{'schema':'change_verify_ledger_v870','change_id':'V2192-REVIEW-SINGLE-EVENT-FACTOR-TRUTH','issue_id':'V2192-PERFORMANCE-S1-REVIEW-SINGLE-TRUTH','version':'v2192','verify_result':'LOCAL_PASS_SERVER_CHECK','created_ts':ts,'created_at':txt,'writer':'review_worker_v2.079','cause':'Public factor results reused large raw counts without proving one event set across horizons, and market-wide factors appeared as if they were independent candidate signals.','fix':'Deduplicate once by sealed event_key, use that same set for all horizons, publish per-factor accuracy, and separate market-shared from candidate-specific factors by distinct sealed values.','not_touched':['factor scores','prediction threshold','truth rule','historical outcome rows','auto-buy OFF'],'auto_buy':False})
        marker.parent.mkdir(parents=True,exist_ok=True);marker.write_text(txt,encoding='utf-8')
    except Exception as exc:append_error('v2192_review_ledger',exc)
# v2245 deferred module-level call: _v2192_review_ledger_once runs after runtime identity publication.



# =============================================================================
# review_worker v2.080 / v2193: preserve old samples and replay the corrected
# prediction answer on the same sealed event keys. Performance reset is unrelated.
# Structure factors are excluded from this analysis.
# =============================================================================
VERSION='review_worker_v2.080'
BUILD_LABEL='v2193_preserved_sample_prediction_correction_replay_2026-07-25'
MAIN_DEPLOY_VERSION=BUILD_LABEL
V2188_EXPECTED_WORKER='strategy_worker_v2.074'
V2188_EXPECTED_BUILD='v2193_prediction_answer_correction_runtime_2026-07-25'
V2188_EXPECTED_CORE='strategy_v2_core_v2173'
V2188_EXPECTED_MODEL='FULL_INPUT_V2193_CORRECTED'
V2193_BASELINE_MODEL='FULL_INPUT_V2188_PRIMARY'
V2193_CURRENT_MODEL='FULL_INPUT_V2193_CORRECTED'
_V2193_BASE_RUN_ONCE=run_once

try:
    from strategy_v2_core_v2173 import score_prediction_axes_v2193 as _v2193_shared_score
except Exception:
    _v2193_shared_score=None


def _v2193_rows_for_model(model):
    state=load_json(OUTCOME_STATE,{}) or {};records=(state.get(STATE_KEY) or {}) if isinstance(state.get(STATE_KEY),dict) else {}
    chosen={}
    for rec in records.values():
        if not isinstance(rec,dict) or rec.get('superseded_duplicate_v2154'):continue
        if str(rec.get('generation') or '')!=GENERATION or str(rec.get('prediction_model_generation') or '')!=model:continue
        key=str(rec.get('event_key') or '').strip()
        if key:chosen[key]=dict(rec)
    final_count=0
    for rec in read_jsonl(OUTCOME_LEDGER,30000):
        if not isinstance(rec,dict) or str(rec.get('generation') or '')!=GENERATION or str(rec.get('prediction_model_generation') or '')!=model:continue
        final_count+=1;key=str(rec.get('event_key') or '').strip()
        if key:chosen[key]=dict(rec)
    return list(chosen.values()),final_count


def _v2193_accuracy(correct,wrong):
    total=int(correct)+int(wrong)
    return round(int(correct)/total*100.0,2) if total else None


def _v2193_model_result(score,truth):
    return _v2188_factor_result(score,truth)


def _v2193_replay_baseline(records):
    result={}
    factors=('leader_persistence','market_liquidity_regime','buy_ratio_level')
    for label in ('30m','1h','3h','6h'):
        factor={name:{'before_correct':0,'before_wrong':0,'after_correct':0,'after_wrong':0,'not_scored':0} for name in factors}
        model={'before_correct':0,'before_wrong':0,'after_correct':0,'after_wrong':0,'not_scored':0,'recovered_up':0,'avoided_down':0,'lost_up':0}
        truth_counts=Counter();samples=0
        for rec in records:
            block=(rec.get('prediction_factor_results_v2188') or {}).get(label) if isinstance(rec.get('prediction_factor_results_v2188'),dict) else None
            if not isinstance(block,dict):continue
            truth=str(block.get('truth') or 'MIXED');truth_counts[truth]+=1;samples+=1
            seal=rec.get('prediction_input_seal_v2188') if isinstance(rec.get('prediction_input_seal_v2188'),dict) else {}
            axes=seal.get('axes') if isinstance(seal.get('axes'),dict) else {}
            conns=seal.get('connections') if isinstance(seal.get('connections'),dict) else {}
            scored=_v2193_shared_score(axes,conns) if callable(_v2193_shared_score) else {}
            corrected=scored.get('axes') if isinstance(scored.get('axes'),dict) else {}
            for name in factors:
                before=(block.get('axis_results') or {}).get(name)
                after=_v2193_model_result(corrected.get(name),truth)
                if before=='CORRECT':factor[name]['before_correct']+=1
                elif before=='WRONG':factor[name]['before_wrong']+=1
                if after=='CORRECT':factor[name]['after_correct']+=1
                elif after=='WRONG':factor[name]['after_wrong']+=1
                else:factor[name]['not_scored']+=1
            before_score=num(seal.get('continuation_score'))
            after_score=num(scored.get('continuation_score')) if isinstance(scored,dict) else None
            before_state=_v2193_model_result(before_score,truth);after_state=_v2193_model_result(after_score,truth)
            if before_state=='CORRECT':model['before_correct']+=1
            elif before_state=='WRONG':model['before_wrong']+=1
            if after_state=='CORRECT':model['after_correct']+=1
            elif after_state=='WRONG':model['after_wrong']+=1
            else:model['not_scored']+=1
            if truth=='UP':
                if (before_score is None or before_score<=0.12) and after_score is not None and after_score>0.0:model['recovered_up']+=1
                if before_score is not None and before_score>0.12 and (after_score is None or after_score<=0.0):model['lost_up']+=1
            elif truth=='DOWN':
                if before_score is not None and before_score>0.12 and after_score is not None and after_score<=0.0:model['avoided_down']+=1
        factor_rows=[]
        for name,item in factor.items():
            before_acc=_v2193_accuracy(item['before_correct'],item['before_wrong']);after_acc=_v2193_accuracy(item['after_correct'],item['after_wrong'])
            factor_rows.append({'name':name,**item,'before_accuracy_pct':before_acc,'after_accuracy_pct':after_acc,'delta_accuracy_pct':round(after_acc-before_acc,2) if before_acc is not None and after_acc is not None else None})
        before_acc=_v2193_accuracy(model['before_correct'],model['before_wrong']);after_acc=_v2193_accuracy(model['after_correct'],model['after_wrong'])
        model.update({'before_accuracy_pct':before_acc,'after_accuracy_pct':after_acc,'delta_accuracy_pct':round(after_acc-before_acc,2) if before_acc is not None and after_acc is not None else None})
        result[label]={'samples':samples,'truth_counts':dict(truth_counts),'factor_corrections':factor_rows,'model_replay':model}
    return result


def _v2193_current_validation(records):
    # Reuse the exact event/horizon factor owner for the new model only.
    result={}
    for label in ('30m','1h','3h','6h'):
        truth=Counter();samples=0;counts={}
        for rec in records:
            block=(rec.get('prediction_factor_results_v2188') or {}).get(label) if isinstance(rec.get('prediction_factor_results_v2188'),dict) else None
            if not isinstance(block,dict):continue
            samples+=1;truth[str(block.get('truth') or 'MIXED')]+=1
            for name,state in (block.get('axis_results') or {}).items():
                if name in {'major_trend','setup_trend','location_hold','price_reaction','volatility_fit','entry_timing','trigger_quality','breakout_reaction'}:continue
                if state not in ('CORRECT','WRONG'):continue
                counts.setdefault(str(name),Counter())[state]+=1
        rows=[]
        for name,c in counts.items():
            total=c['CORRECT']+c['WRONG'];rows.append({'name':name,'correct':c['CORRECT'],'wrong':c['WRONG'],'scored':total,'accuracy_pct':round(c['CORRECT']/total*100.0,2) if total else None})
        rows.sort(key=lambda x:(x['accuracy_pct'] if x['accuracy_pct'] is not None else 999.0,-x['scored']))
        result[label]={'samples':samples,'truth_counts':dict(truth),'factor_rows':rows}
    return result


def _v2193_validation_snapshot():
    baseline,baseline_final=_v2193_rows_for_model(V2193_BASELINE_MODEL)
    current,current_final=_v2193_rows_for_model(V2193_CURRENT_MODEL)
    replay=_v2193_replay_baseline(baseline)
    current_validation=_v2193_current_validation(current)
    material={'baseline_model':V2193_BASELINE_MODEL,'baseline_keys':sorted(str(r.get('event_key') or '') for r in baseline),'current_model':V2193_CURRENT_MODEL,'current_keys':sorted(str(r.get('event_key') or '') for r in current),'samples':{k:v.get('samples') for k,v in replay.items()}}
    snapshot_id=hashlib.sha256(json.dumps(material,sort_keys=True,separators=(',',':'),default=str).encode()).hexdigest()[:16]
    return {'schema':'prediction_correction_replay_snapshot_v2193','snapshot_id':snapshot_id,'baseline_model':V2193_BASELINE_MODEL,'baseline_unique_events':len(baseline),'baseline_finalized_rows_read':baseline_final,'baseline_horizons':replay,'current_model':V2193_CURRENT_MODEL,'current_unique_events':len(current),'current_finalized_rows_read':current_final,'current_horizons':current_validation,'performance_epoch_reset_affects_prediction_samples':False,'structure_factors_used':False,'same_sealed_event_keys_replayed':True,'historical_rows_rewritten':False,'auto_buy':False}


def run_once__v2193():
    result=_V2193_BASE_RUN_ONCE();result=dict(result) if isinstance(result,dict) else {}
    validation=_v2193_validation_snapshot()
    fields={'version':VERSION,'build':BUILD_LABEL,'state':'running','prediction_validation_v2193':validation,'validation_snapshot_id_v2193':validation.get('snapshot_id'),'baseline_prediction_samples_preserved_v2193':validation.get('baseline_unique_events'),'current_prediction_samples_v2193':validation.get('current_unique_events'),'prediction_model_generation_v2193':V2193_CURRENT_MODEL,'baseline_model_generation_v2193':V2193_BASELINE_MODEL,'performance_epoch_reset_did_not_reset_prediction_samples_v2193':True,'structure_factors_used_in_analysis_v2193':False,'historical_ledgers_rewritten':False,'auto_buy':False}
    status=load_json(STATUS,{}) or {};outcome=load_json(OUTCOME_STATUS,{}) or {}
    status.update(fields);outcome.update(fields);_atomic_json(STATUS,status);_atomic_json(OUTCOME_STATUS,outcome);result.update(fields);return result
run_once=run_once__v2193
run_once.__name__='run_once';run_once.__qualname__='run_once'


def _v2193_review_ledger_once():
    marker=BASE_DIR/'runtime'/'review_v2193_preserved_sample_replay.seeded'
    if marker.exists():return
    ts=now_ts();txt=now_text(ts)
    try:
        append_jsonl(CHANGE_LEDGER,{'schema':'change_verify_ledger_v870','change_id':'V2193-PRESERVED-PREDICTION-SAMPLE-REPLAY','issue_id':'V2193-REPEATED-WRONG-PREDICTION-FACTORS','version':'v2193','verify_result':'LOCAL_PASS_SERVER_CHECK','created_ts':ts,'created_at':txt,'writer':VERSION,'cause':'v2192 current-model single reader hid the preserved v2188 prediction samples after performance was reset to 0 trades.','fix':'Keep Paper performance at the current zero epoch, separately reload all preserved FULL_INPUT_V2188_PRIMARY event keys, and replay the v2193 correction against the same 30m/1h/3h/6h truths. Structure factors are excluded.','not_touched':['Paper performance epoch','historical outcome rows','structure/entry/exit','auto-buy OFF'],'auto_buy':False})
        marker.parent.mkdir(parents=True,exist_ok=True);marker.write_text(txt,encoding='utf-8')
    except Exception as exc:append_error('v2193_review_ledger',exc)
# v2245 deferred module-level call: _v2193_review_ledger_once runs after runtime identity publication.


# =============================================================================
# review_worker v2.081 / v2198: replay v2193 and v2198 on the same preserved
# events. Existing outcome ledger/state only; no new Shadow or new ledger.
# =============================================================================
VERSION='review_worker_v2.081'
BUILD_LABEL='v2198_three_six_hour_prediction_replay_2026-07-25'
MAIN_DEPLOY_VERSION=BUILD_LABEL
V2198_CURRENT_MODEL='FULL_INPUT_V2198_CONTINUATION'
V2198_PREVIOUS_MODEL='FULL_INPUT_V2193_CORRECTED'
V2198_BASELINE_MODEL='FULL_INPUT_V2188_PRIMARY'
V2188_EXPECTED_WORKER='strategy_worker_v2.075'
V2188_EXPECTED_BUILD='v2198_three_six_hour_continuation_runtime_2026-07-25'
V2188_EXPECTED_CORE='strategy_v2_core_v2174'
V2188_EXPECTED_MODEL=V2198_CURRENT_MODEL
_V2198_BASE_RUN_ONCE=run_once
try:
    from strategy_v2_core_v2173 import score_prediction_axes_v2193 as _v2198_score_previous
except Exception:
    _v2198_score_previous=None
try:
    from strategy_v2_core_v2174 import score_prediction_axes_v2198 as _v2198_score_current
except Exception:
    _v2198_score_current=None


def _v2198_acc(c,w):
    total=int(c)+int(w);return round(int(c)/total*100.0,2) if total else None


def _v2198_replay(records):
    out={};factor_names=('leader_persistence','market_liquidity_regime','buy_ratio_level','momentum_level')
    for label in ('30m','1h','3h','6h'):
        prev={'correct':0,'wrong':0,'not_scored':0};cur={'correct':0,'wrong':0,'not_scored':0};factors={n:{'previous_correct':0,'previous_wrong':0,'current_correct':0,'current_wrong':0,'not_scored':0} for n in factor_names}
        truth_counts=Counter();samples=0;recovered_up=avoided_down=lost_up=0;prev_positive=cur_positive=0
        for rec in records:
            block=(rec.get('prediction_factor_results_v2188') or {}).get(label) if isinstance(rec.get('prediction_factor_results_v2188'),dict) else None
            if not isinstance(block,dict):continue
            truth=str(block.get('truth') or 'MIXED');truth_counts[truth]+=1;samples+=1
            seal=rec.get('prediction_input_seal_v2188') if isinstance(rec.get('prediction_input_seal_v2188'),dict) else {};axes=seal.get('axes') if isinstance(seal.get('axes'),dict) else {};conns=seal.get('connections') if isinstance(seal.get('connections'),dict) else {}
            ps=_v2198_score_previous(axes,conns) if callable(_v2198_score_previous) else {};cs=_v2198_score_current(axes,conns) if callable(_v2198_score_current) else {}
            pscore=num(ps.get('continuation_score')) if isinstance(ps,dict) else None;cscore=num(cs.get('continuation_score')) if isinstance(cs,dict) else None
            if pscore is not None and pscore>0:prev_positive+=1
            if cscore is not None and cscore>0:cur_positive+=1
            pr=_v2188_factor_result(pscore,truth);cr=_v2188_factor_result(cscore,truth)
            if pr=='CORRECT':prev['correct']+=1
            elif pr=='WRONG':prev['wrong']+=1
            else:prev['not_scored']+=1
            if cr=='CORRECT':cur['correct']+=1
            elif cr=='WRONG':cur['wrong']+=1
            else:cur['not_scored']+=1
            if truth=='UP':
                if (pscore is None or pscore<=0.12) and cscore is not None and cscore>0.0:recovered_up+=1
                if pscore is not None and pscore>0.12 and (cscore is None or cscore<=0.0):lost_up+=1
            elif truth=='DOWN' and pscore is not None and pscore>0.12 and cscore is not None and cscore<=0.0:avoided_down+=1
            pa=ps.get('axes') if isinstance(ps.get('axes'),dict) else {};ca=cs.get('axes') if isinstance(cs.get('axes'),dict) else {}
            for name in factor_names:
                a=_v2188_factor_result(pa.get(name),truth);b=_v2188_factor_result(ca.get(name),truth);item=factors[name]
                if a=='CORRECT':item['previous_correct']+=1
                elif a=='WRONG':item['previous_wrong']+=1
                if b=='CORRECT':item['current_correct']+=1
                elif b=='WRONG':item['current_wrong']+=1
                else:item['not_scored']+=1
        pacc=_v2198_acc(prev['correct'],prev['wrong']);cacc=_v2198_acc(cur['correct'],cur['wrong'])
        factor_rows=[]
        for name,item in factors.items():
            pa=_v2198_acc(item['previous_correct'],item['previous_wrong']);ca=_v2198_acc(item['current_correct'],item['current_wrong'])
            factor_rows.append({'name':name,**item,'previous_accuracy_pct':pa,'current_accuracy_pct':ca,'delta_accuracy_pct':round(ca-pa,2) if pa is not None and ca is not None else None})
        out[label]={'samples':samples,'truth_counts':dict(truth_counts),'previous_accuracy_pct':pacc,'current_accuracy_pct':cacc,'delta_accuracy_pct':round(cacc-pacc,2) if pacc is not None and cacc is not None else None,
                    'previous_positive_count':prev_positive,'current_positive_count':cur_positive,'candidate_retention_pct':round(cur_positive/max(1,prev_positive)*100.0,2),
                    'recovered_up':recovered_up,'avoided_down':avoided_down,'lost_up':lost_up,'factor_rows':factor_rows}
    vals=[]
    for label,weight in (('3h',0.45),('6h',0.55)):
        b=out.get(label) or {};a=b.get('current_accuracy_pct')
        if a is not None:vals.append((float(a),weight))
    long_acc=sum(v*w for v,w in vals)/sum(w for _,w in vals) if vals else None
    return out,round(long_acc,2) if long_acc is not None else None


def _v2198_current(records):
    return _v2193_current_validation(records)


def _v2198_validation_snapshot():
    baseline,_=_v2193_rows_for_model(V2198_BASELINE_MODEL);previous,_=_v2193_rows_for_model(V2198_PREVIOUS_MODEL);current,current_final=_v2193_rows_for_model(V2198_CURRENT_MODEL)
    replay,long_acc=_v2198_replay(baseline);current_h=_v2198_current(current)
    material={'baseline_keys':sorted(str(r.get('event_key') or '') for r in baseline),'current_keys':sorted(str(r.get('event_key') or '') for r in current),'samples':{k:v.get('samples') for k,v in replay.items()}}
    sid=hashlib.sha256(json.dumps(material,sort_keys=True,separators=(',',':'),default=str).encode()).hexdigest()[:16]
    return {'schema':'prediction_continuation_replay_snapshot_v2198','snapshot_id':sid,'baseline_model':V2198_BASELINE_MODEL,'baseline_unique_events':len(baseline),'previous_model':V2198_PREVIOUS_MODEL,'previous_unique_events':len(previous),'current_model':V2198_CURRENT_MODEL,'current_unique_events':len(current),'current_finalized_rows_read':current_final,
            'horizons':replay,'current_horizons':current_h,'long_objective_accuracy_pct_v2198':long_acc,'objective_horizons':['3h','6h'],'short_horizon_role':'entry_timing_only','structure_factors_used':False,'hard_veto_added':False,'candidate_rows_deleted':0,'historical_rows_rewritten':False,'auto_buy':False}


def run_once__v2198():
    result=_V2198_BASE_RUN_ONCE();result=dict(result) if isinstance(result,dict) else {};validation=_v2198_validation_snapshot()
    fields={'version':VERSION,'build':BUILD_LABEL,'state':'running','prediction_validation_v2198':validation,'validation_snapshot_id_v2198':validation.get('snapshot_id'),'baseline_prediction_samples_preserved_v2198':validation.get('baseline_unique_events'),'current_prediction_samples_v2198':validation.get('current_unique_events'),'prediction_model_generation_v2198':V2198_CURRENT_MODEL,'previous_model_generation_v2198':V2198_PREVIOUS_MODEL,'performance_epoch_reset_did_not_reset_prediction_samples_v2198':True,'structure_factors_used_in_analysis_v2198':False,'hard_veto_added_v2198':False,'historical_ledgers_rewritten':False,'auto_buy':False}
    status=load_json(STATUS,{}) or {};outcome=load_json(OUTCOME_STATUS,{}) or {};status.update(fields);outcome.update(fields);_atomic_json(STATUS,status);_atomic_json(OUTCOME_STATUS,outcome);result.update(fields);return result
run_once=run_once__v2198
run_once.__name__='run_once';run_once.__qualname__='run_once'


def _v2198_review_ledger_once():
    marker=BASE_DIR/'runtime'/'review_v2198_three_six_hour_replay.seeded'
    if marker.exists():return
    ts=now_ts();txt=now_text(ts)
    try:
        append_jsonl(CHANGE_LEDGER,{'schema':'change_verify_ledger_v870','change_id':'V2198-THREE-SIX-HOUR-PREDICTION-REPLAY','issue_id':'V2198-PREDICTION-SHORT-IMPULSE-LONG-CONTINUATION-MISMATCH','version':'v2198','verify_result':'LOCAL_PASS_SERVER_CHECK','created_ts':ts,'created_at':txt,'writer':VERSION,'cause':'Post-reset Paper performance showed low win rate while old prediction accuracy fell sharply at 3h/6h.','fix':'Replay v2193 and v2198 on the same preserved event keys and same 30m/1h/3h/6h MFE/MAE truths. Show candidate retention, recovered UP, avoided DOWN and lost UP.','not_touched':['performance epoch','historical outcome rows','structure/entry/exit','auto-buy OFF'],'auto_buy':False})
        marker.parent.mkdir(parents=True,exist_ok=True);marker.write_text(txt,encoding='utf-8')
    except Exception as exc:append_error('v2198_review_ledger',exc)
# v2245 deferred module-level call: _v2198_review_ledger_once runs after runtime identity publication.




# =============================================================================
# review_worker v2.083 / v2202: canonical prediction verification owner.
# The existing Review worker calculates once and publishes one compact snapshot to
# strategy_v2_outcome_status_v2133.json. Main commands never scan ledgers.
# Full historical rebuild runs in this process only; appended finalized rows are
# read incrementally. No new file, process, command, Shadow, gate or trading change.
# =============================================================================
import threading
VERSION='review_worker_v2.083'
BUILD_LABEL='v2202_canonical_prediction_review_owner_incremental_2026-07-25'
MAIN_DEPLOY_VERSION=BUILD_LABEL
V2202_PREVIOUS_MODEL='FULL_INPUT_V2193_CORRECTED'
V2202_CURRENT_MODEL='FULL_INPUT_V2198_CONTINUATION'
V2202_NEUTRAL_PCT=0.10
_V2202_TRACKING_RUN=_V2188_BASE_RUN
_V2202_BASE_UPDATE_PATH=update_path
_V2202_LOCK=threading.RLock()
_V2202_CACHE={'building':False,'ready':False,'error':None,'by_key':{},'ledger_inode':None,'ledger_offset':0,'ledger_size':0,'ledger_mtime_ns':0,'state_mtime_ns':0,'snapshot':None,'build_started_ts':None,'build_finished_ts':None,'diagnostics':{}}


def _v2202_num(value):
    try:
        if value in (None,'') or isinstance(value,bool):return None
        value=float(value)
        return value if math.isfinite(value) else None
    except Exception:return None


def _v2202_truth(close):
    value=_v2202_num(close)
    if value is None:return None
    if value>V2202_NEUTRAL_PCT:return 'UP'
    if value<-V2202_NEUTRAL_PCT:return 'DOWN'
    return 'FLAT'


def update_path(rec,price,nowv):  # type: ignore[override]
    _V2202_BASE_UPDATE_PATH(rec,price,nowv)
    entry=_v2202_num(rec.get('reference_entry'))
    current=((float(price)/entry-1.0)*100.0) if entry and entry>0 else None
    raw_max=_v2202_num(rec.get('max_pct'));raw_min=_v2202_num(rec.get('min_pct'))
    rec['max_pct']=max(0.0,raw_max if raw_max is not None else 0.0,current if current is not None else 0.0)
    rec['min_pct']=min(0.0,raw_min if raw_min is not None else 0.0,current if current is not None else 0.0)
    samples=rec.get('samples') if isinstance(rec.get('samples'),dict) else {}
    results=rec.get('prediction_factor_results_v2188') if isinstance(rec.get('prediction_factor_results_v2188'),dict) else {}
    seal=rec.get('prediction_input_seal_v2188') if isinstance(rec.get('prediction_input_seal_v2188'),dict) else {}
    axes=seal.get('axes') if isinstance(seal.get('axes'),dict) else {};groups=seal.get('groups') if isinstance(seal.get('groups'),dict) else {}
    for label in ('30m','1h','3h','6h'):
        sample=samples.get(label) if isinstance(samples.get(label),dict) else None
        if isinstance(sample,dict):
            sm=_v2202_num(sample.get('max_pct'));sn=_v2202_num(sample.get('min_pct'))
            if sm is not None:sample['max_pct']=max(0.0,sm)
            if sn is not None:sample['min_pct']=min(0.0,sn)
        block=results.get(label) if isinstance(results.get(label),dict) else None
        if not isinstance(block,dict):continue
        close=_v2202_num(block.get('close_pct'))
        if close is None and isinstance(sample,dict):close=_v2202_num(sample.get('pct'))
        truth=_v2202_truth(close)
        if truth is None:continue
        raw_mfe=_v2202_num(block.get('mfe_pct'));raw_mae=_v2202_num(block.get('mae_pct'))
        if raw_mfe is None and isinstance(sample,dict):raw_mfe=_v2202_num(sample.get('max_pct'))
        if raw_mae is None and isinstance(sample,dict):raw_mae=_v2202_num(sample.get('min_pct'))
        block['truth']=truth;block['close_pct']=close
        block['mfe_pct']=max(0.0,raw_mfe) if raw_mfe is not None else None
        block['mae_pct']=min(0.0,raw_mae) if raw_mae is not None else None
        block['axis_results']={name:_v2188_factor_result(value,truth if truth!='FLAT' else 'MIXED') for name,value in axes.items()}
        block['group_results']={name:_v2188_factor_result((meta or {}).get('score') if isinstance(meta,dict) else meta,truth if truth!='FLAT' else 'MIXED') for name,meta in groups.items()}
        block['rule']='each horizon close_pct with ±0.10% neutral; first-touch path evidence only; path MFE/MAE never fabricated from close'
        block['truth_source_v2202']='horizon_close_pct'
        block['path_source_v2202']='recorded_horizon_path' if raw_mfe is not None and raw_mae is not None else 'SOURCE_MISSING'
    rec['review_truth_rule_v2202']='horizon_close_pct'
    rec['mfe_mae_close_fallback_v2202']=False


def _v2202_event_time(row):
    seal=row.get('prediction_input_seal_v2188') if isinstance(row.get('prediction_input_seal_v2188'),dict) else {}
    for value in (seal.get('sealed_ts'),row.get('start_ts'),row.get('created_ts'),row.get('finalized_ts')):
        number=_v2202_num(value)
        if number:return number
    return None


def _v2202_horizon_raw(row,label):
    results=row.get('prediction_factor_results_v2188') if isinstance(row.get('prediction_factor_results_v2188'),dict) else {}
    samples=row.get('samples') if isinstance(row.get('samples'),dict) else {}
    block=results.get(label) if isinstance(results.get(label),dict) else {}
    sample=samples.get(label) if isinstance(samples.get(label),dict) else {}
    close=_v2202_num(block.get('close_pct'))
    if close is None:close=_v2202_num(sample.get('pct'))
    if close is None:return None
    mfe=_v2202_num(block.get('mfe_pct'))
    if mfe is None:mfe=_v2202_num(sample.get('max_pct'))
    mae=_v2202_num(block.get('mae_pct'))
    if mae is None:mae=_v2202_num(sample.get('min_pct'))
    return {'close_pct':close,'truth':_v2202_truth(close),'sampled_ts':_v2202_num(block.get('sampled_ts')) or _v2202_num(sample.get('sampled_ts')),
            'mfe_pct':max(0.0,mfe) if mfe is not None else None,'mae_pct':min(0.0,mae) if mae is not None else None,
            'path_ready':bool(mfe is not None and mae is not None)}


def _v2202_rank(row,priority=0):
    complete=0;latest=0.0
    for label in ('30m','1h','3h','6h'):
        b=_v2202_horizon_raw(row,label)
        if b is not None:
            complete+=1;latest=max(latest,_v2202_num(b.get('sampled_ts')) or 0.0)
    row_ts=max(_v2202_num(row.get('finalized_ts')) or 0.0,_v2202_num(row.get('last_seen_ts')) or 0.0,_v2202_event_time(row) or 0.0)
    return (complete,latest,row_ts,int(priority))


def _v2202_prepare_row(row,previous_fn,current_fn):
    if not isinstance(row,dict):return None,'ROW_NOT_OBJECT'
    key=str(row.get('event_key') or '').strip()
    if not key:return None,'EVENT_KEY_MISSING'
    seal=row.get('prediction_input_seal_v2188') if isinstance(row.get('prediction_input_seal_v2188'),dict) else {}
    axes=seal.get('axes') if isinstance(seal.get('axes'),dict) else {}
    conns=seal.get('connections') if isinstance(seal.get('connections'),dict) else {}
    horizons={label:_v2202_horizon_raw(row,label) for label in ('30m','1h','3h','6h')}
    if not any(isinstance(v,dict) for v in horizons.values()):return None,'HORIZON_RESULT_MISSING'
    base={'event_key':key,'event_key_short':hashlib.sha256(key.encode()).hexdigest()[:10],'ticker':ticker(row.get('ticker')) or '-',
          'entry_ts':_v2202_event_time(row),'model_generation':str(row.get('prediction_model_generation') or seal.get('model_generation') or 'UNKNOWN'),
          'previous_score':None,'current_score':None,'current_axes':{},'horizons':horizons,'score_error':None,'input_state':'READY'}
    if not axes:
        base['input_state']='INPUT_SEAL_MISSING';return base,'INPUT_SEAL_MISSING'
    if not conns:
        base['input_state']='CONNECTIONS_MISSING';return base,'CONNECTIONS_MISSING'
    score_error=None
    try:previous=previous_fn(axes,conns) if callable(previous_fn) else {}
    except Exception as exc:previous={};score_error=f'previous:{type(exc).__name__}'
    try:current=current_fn(axes,conns) if callable(current_fn) else {}
    except Exception as exc:current={};score_error=(score_error+';' if score_error else '')+f'current:{type(exc).__name__}'
    previous=previous if isinstance(previous,dict) else {};current=current if isinstance(current,dict) else {}
    current_axes=current.get('axes') if isinstance(current.get('axes'),dict) else {}
    base.update({'previous_score':_v2202_num(previous.get('continuation_score')),'current_score':_v2202_num(current.get('continuation_score')),
                 'current_axes':{str(k):_v2202_num(v) for k,v in current_axes.items()},'score_error':score_error,'input_state':'SCORE_ERROR' if score_error else 'READY'})
    return base,('SCORE_ERROR' if score_error else None)


def _v2202_accept_raw(target,row,priority,diagnostics):
    if not isinstance(row,dict):return
    generation=str(row.get('generation') or '')
    if generation and generation!=GENERATION:
        diagnostics['wrong_generation_raw']+=1;return
    key=str(row.get('event_key') or '').strip()
    if not key:
        diagnostics['missing_event_key_raw']+=1;return
    rank=_v2202_rank(row,priority)
    old=target.get(key)
    if old is not None:
        diagnostics['duplicates_removed']+=1
        if rank<=old[0]:return
    target[key]=(rank,dict(row))


def _v2202_scan_full():
    started=time.monotonic();diagnostics={'ledger_raw_rows':0,'ledger_json_errors':0,'wrong_generation_raw':0,'missing_event_key_raw':0,'duplicates_removed':0}
    selected={};inode=None;offset=0;size=0;mtime_ns=0
    if OUTCOME_LEDGER.exists():
        st=OUTCOME_LEDGER.stat();inode=getattr(st,'st_ino',None);size=st.st_size;mtime_ns=st.st_mtime_ns
        with OUTCOME_LEDGER.open('rb') as handle:
            for raw in handle:
                diagnostics['ledger_raw_rows']+=1
                try:row=json.loads(raw.decode('utf-8','replace'))
                except Exception:
                    diagnostics['ledger_json_errors']+=1;continue
                _v2202_accept_raw(selected,row,1,diagnostics)
            offset=handle.tell()
    diagnostics['ledger_unique_keys']=len(selected)
    return selected,diagnostics,{'inode':inode,'offset':offset,'size':size,'mtime_ns':mtime_ns,'scan_sec':round(time.monotonic()-started,3)}


def _v2202_read_state_rows():
    state=load_json(OUTCOME_STATE,{}) or {};rows=(state.get(STATE_KEY) or {}) if isinstance(state.get(STATE_KEY),dict) else {}
    try:mtime=OUTCOME_STATE.stat().st_mtime_ns
    except Exception:mtime=0
    return [r for r in rows.values() if isinstance(r,dict)],mtime


def _v2202_pct(a,b):
    total=int(a)+int(b);return round(int(a)/total*100.0,2) if total else None


def _v2202_avg(values):
    values=[float(v) for v in values if _v2202_num(v) is not None]
    return round(sum(values)/len(values),6) if values else None


def _v2202_bucket(score):
    if score is None:return None
    if score<0:return ('NEG','<0')
    if score<0.05:return ('P00','0.00~0.05')
    if score<0.10:return ('P05','0.05~0.10')
    if score<0.20:return ('P10','0.10~0.20')
    return ('P20','0.20 이상')


def _v2202_example(event,block):
    return {'ticker':event.get('ticker'),'event_key_short':event.get('event_key_short'),'entry_ts':event.get('entry_ts'),'sampled_ts':block.get('sampled_ts'),'close_pct':block.get('close_pct'),'mfe_pct':block.get('mfe_pct'),'mae_pct':block.get('mae_pct'),'previous_score':event.get('previous_score'),'current_score':event.get('current_score')}


def _v2202_aggregate(events,recent_cutoff=None):
    labels={'relative_strength_level':'상대강도','relative_strength_delta':'상대강도 변화','money_flow_level':'자금유입','money_flow_delta':'자금유입 변화','buy_sustain_level':'매수 지속','trade_intensity_delta':'체결 변화','sell_pressure_level':'매도압력','leader_persistence':'주도 알트 지속','market_liquidity_regime':'시장 유동성','buy_ratio_level':'공격매수 비율','momentum_level':'현재 모멘텀'}
    out={}
    for label in ('30m','1h','3h','6h'):
        b={'samples':0,'actual_up':0,'actual_down':0,'actual_flat':0,'previous_score_ready':0,'previous_score_missing':0,'current_score_ready':0,'current_score_missing':0,
           'previous_correct':0,'previous_wrong':0,'current_correct':0,'current_wrong':0,'previous_pass_count':0,'previous_pass_up':0,'previous_pass_down':0,
           'current_pass_count':0,'current_pass_up':0,'current_pass_down':0,'current_pass_flat':0,'formula_missed_up_count':0,'score_missing_up_count':0,'false_positive_count':0,
           'recovered_up':0,'avoided_down':0,'lost_up':0,'pass_close':[],'pass_mfe':[],'pass_mae':[],'current_pass_path_ready':0,
           'formula_missed_up_examples':[],'score_missing_up_examples':[],'false_positive_examples':[],'factor':{name:{'correct':0,'wrong':0} for name in labels},
           'buckets':{key:{'key':key,'label':lab,'n':0,'up':0,'down':0,'flat':0,'close':[]} for key,lab in (('NEG','<0'),('P00','0.00~0.05'),('P05','0.05~0.10'),('P10','0.10~0.20'),('P20','0.20 이상'))}}
        for event in events:
            block=(event.get('horizons') or {}).get(label)
            if not isinstance(block,dict) or block.get('truth') is None:continue
            if recent_cutoff is not None:
                sampled=_v2202_num(block.get('sampled_ts'))
                if sampled is None or sampled<recent_cutoff:continue
            truth=block['truth'];b['samples']+=1;b['actual_'+truth.lower()]+=1
            ps=event.get('previous_score');cs=event.get('current_score')
            if ps is None:b['previous_score_missing']+=1
            else:
                b['previous_score_ready']+=1
                if truth in ('UP','DOWN'):
                    if ('UP' if ps>0 else 'DOWN')==truth:b['previous_correct']+=1
                    else:b['previous_wrong']+=1
                if ps>0:
                    b['previous_pass_count']+=1;b['previous_pass_up']+=int(truth=='UP');b['previous_pass_down']+=int(truth=='DOWN')
            live_pass=event.get('current_formula_pass_v2210')
            current_pass=bool(live_pass) if live_pass is not None else bool(cs is not None and cs>0)
            if cs is None:b['current_score_missing']+=1
            else:
                b['current_score_ready']+=1
                if truth in ('UP','DOWN'):
                    if ('UP' if cs>0 else 'DOWN')==truth:b['current_correct']+=1
                    else:b['current_wrong']+=1
                buck=_v2202_bucket(cs)
                if buck:
                    item=b['buckets'][buck[0]];item['n']+=1;item[truth.lower()]+=1;item['close'].append(block.get('close_pct'))
                if current_pass:
                    b['current_pass_count']+=1;b['current_pass_up']+=int(truth=='UP');b['current_pass_down']+=int(truth=='DOWN');b['current_pass_flat']+=int(truth=='FLAT')
                    b['pass_close'].append(block.get('close_pct'))
                    if block.get('path_ready'):
                        b['current_pass_path_ready']+=1;b['pass_mfe'].append(block.get('mfe_pct'));b['pass_mae'].append(block.get('mae_pct'))
            previous_pass=bool(ps is not None and ps>0)
            if truth=='UP':
                if cs is None:
                    b['score_missing_up_count']+=1;b['score_missing_up_examples'].append(_v2202_example(event,block))
                elif not current_pass:
                    b['formula_missed_up_count']+=1;b['formula_missed_up_examples'].append(_v2202_example(event,block))
                if not previous_pass and current_pass:b['recovered_up']+=1
                if previous_pass and not current_pass:b['lost_up']+=1
            elif truth=='DOWN':
                if current_pass:
                    b['false_positive_count']+=1;b['false_positive_examples'].append(_v2202_example(event,block))
                if previous_pass and not current_pass:b['avoided_down']+=1
            for name,item in b['factor'].items():
                val=(event.get('current_axes') or {}).get(name)
                if val is None or abs(val)<=0.12 or truth not in ('UP','DOWN'):continue
                pred='UP' if val>0 else 'DOWN'
                item['correct' if pred==truth else 'wrong']+=1
        b['previous_accuracy_pct']=_v2202_pct(b['previous_correct'],b['previous_wrong'])
        b['current_accuracy_pct']=_v2202_pct(b['current_correct'],b['current_wrong'])
        b['previous_pass_win_rate_pct']=_v2202_pct(b['previous_pass_up'],b['previous_pass_down'])
        b['current_pass_win_rate_pct']=_v2202_pct(b['current_pass_up'],b['current_pass_down'])
        b['current_pass_avg_close_pct']=_v2202_avg(b.pop('pass_close'))
        b['current_pass_mfe_avg_pct']=_v2202_avg(b.pop('pass_mfe'))
        b['current_pass_mae_avg_pct']=_v2202_avg(b.pop('pass_mae'))
        for key in ('formula_missed_up_examples','score_missing_up_examples'):
            b[key].sort(key=lambda x:float(x.get('close_pct') or 0.0),reverse=True);b[key]=b[key][:8]
        b['false_positive_examples'].sort(key=lambda x:float(x.get('close_pct') or 0.0));b['false_positive_examples']=b['false_positive_examples'][:8]
        rows=[]
        for key in ('NEG','P00','P05','P10','P20'):
            item=b['buckets'][key];rows.append({'key':key,'label':item['label'],'n':item['n'],'up':item['up'],'down':item['down'],'flat':item['flat'],'up_rate_pct':_v2202_pct(item['up'],item['down']),'avg_close_pct':_v2202_avg(item['close'])})
        b['score_buckets']=rows;b.pop('buckets',None)
        factors=[]
        for name,item in b.pop('factor').items():
            scored=item['correct']+item['wrong'];factors.append({'name':name,'label':labels[name],'correct':item['correct'],'wrong':item['wrong'],'scored':scored,'accuracy_pct':_v2202_pct(item['correct'],item['wrong'])})
        factors.sort(key=lambda x:(x['accuracy_pct'] if x['accuracy_pct'] is not None else 999.0,-x['scored']))
        b['factor_rows']=factors
        out[label]=b
    return out


def _v2202_build_snapshot(final_selected,base_diag,source_info):
    started=time.monotonic();previous_fn=_v2198_score_previous;current_fn=_v2198_score_current
    selected=dict(final_selected)
    state_rows,state_mtime=_v2202_read_state_rows();overlay_diag={'wrong_generation_raw':0,'missing_event_key_raw':0,'duplicates_removed':0}
    for row in state_rows:_v2202_accept_raw(selected,row,2,overlay_diag)
    events=[];missing=Counter();score_errors=0
    for rank,row in selected.values():
        event,reason=_v2202_prepare_row(row,previous_fn,current_fn)
        if reason:missing[reason]+=1
        if event is None:continue
        if event.get('score_error'):score_errors+=1
        events.append(event)
    horizons=_v2202_aggregate(events);recent=_v2202_aggregate(events,now_ts()-86400.0)
    low={label:(horizons.get(label) or {}).get('factor_rows',[])[:6] for label in ('3h','6h')}
    d=dict(base_diag);d.update({'unique_event_keys':len(selected),'valid_events':len(events),'input_seal_missing_unique':missing['INPUT_SEAL_MISSING'],'connections_missing_unique':missing['CONNECTIONS_MISSING'],'horizon_result_missing_unique':missing['HORIZON_RESULT_MISSING'],'score_error_events':score_errors,'state_rows':len(state_rows),'state_overlay_duplicates':overlay_diag['duplicates_removed']})
    source_info=dict(source_info);source_info['state_mtime_ns']=state_mtime
    material={'ledger':source_info,'state_mtime':state_mtime,'valid':len(events),'h':{k:(v.get('samples'),v.get('current_score_ready'),v.get('current_pass_count')) for k,v in horizons.items()}}
    sid=hashlib.sha256(json.dumps(material,sort_keys=True,separators=(',',':'),default=str).encode()).hexdigest()[:16]
    return {'schema':'prediction_review_snapshot_v2202','owner':'review_worker_v2.083','state':'PASS' if callable(previous_fn) and callable(current_fn) else 'FAIL','snapshot_id':'review-'+sid,'calculated_ts':now_ts(),'calculated_text':now_text(),'calculation_sec':round(time.monotonic()-started,3),'source_owner':'strategy_v2_outcome_state_v2133.json + strategy_v2_outcomes_v2133.jsonl','source_info':source_info,'diagnostics':d,'previous_model':V2202_PREVIOUS_MODEL,'current_model':V2202_CURRENT_MODEL,'truth_rule':'each horizon close_pct; ±0.10% neutral','path_rule':'recorded horizon MFE/MAE only; entry 0 normalization; no close fallback','horizons':horizons,'recent_24h':recent,'low_accuracy_factors':low,'main_recalculation_count':0,'historical_ledgers_rewritten':False,'historical_ledgers_deleted':False,'new_shadow_created':False,'auto_buy':False}


def _v2202_publish(snapshot,runtime_state=None):
    outcome=load_json(OUTCOME_STATUS,{}) or {};outcome=dict(outcome) if isinstance(outcome,dict) else {}
    if isinstance(snapshot,dict):outcome['prediction_validation_v2202']=snapshot
    runtime={'schema':'prediction_review_runtime_v2202','owner':'review_worker_v2.083','state':runtime_state or ('READY' if isinstance(snapshot,dict) else 'WAITING'),'updated_ts':now_ts(),'updated_text':now_text(),'building':bool(_V2202_CACHE.get('building')),'error':_V2202_CACHE.get('error'),'main_recalculation_count':0,'analysis_status_file':'strategy_v2_outcome_status_v2133.json','health_status_file':'clean_review_worker_status.json'}
    outcome.update({'version':VERSION,'build':BUILD_LABEL,'prediction_validation_v2202_runtime':runtime,'prediction_analysis_owner_v2202':'review_worker_v2.083 -> strategy_v2_outcome_status_v2133.json','clean_review_worker_status_role_v2202':'health_only','main_direct_ledger_scan_v2202':False,'auto_buy':False})
    _atomic_json(OUTCOME_STATUS,outcome)
    return runtime


def _v2202_full_build_thread():
    try:
        selected,diag,info=_v2202_scan_full();snapshot=_v2202_build_snapshot(selected,diag,info)
        with _V2202_LOCK:
            _V2202_CACHE.update({'building':False,'ready':True,'error':None,'by_key':selected,'ledger_inode':info.get('inode'),'ledger_offset':info.get('offset'),'ledger_size':info.get('size'),'ledger_mtime_ns':info.get('mtime_ns'),'state_mtime_ns':snapshot.get('source_info',{}).get('state_mtime_ns',0),'snapshot':snapshot,'build_finished_ts':now_ts(),'diagnostics':diag})
        _v2202_publish(snapshot,'READY')
    except Exception as exc:
        with _V2202_LOCK:_V2202_CACHE.update({'building':False,'ready':False,'error':f'{type(exc).__name__}: {exc}','build_finished_ts':now_ts()})
        append_error('v2202_full_review_build',exc);_v2202_publish(None,'ERROR')


def _v2202_start_build():
    with _V2202_LOCK:
        if _V2202_CACHE.get('building'):return
        _V2202_CACHE.update({'building':True,'error':None,'build_started_ts':now_ts()})
    thread=threading.Thread(target=_v2202_full_build_thread,name='review-v2202-canonical-build',daemon=True);thread.start()


def _v2202_incremental_ledger():
    with _V2202_LOCK:
        if not _V2202_CACHE.get('ready') or _V2202_CACHE.get('building'):return False
        inode=_V2202_CACHE.get('ledger_inode');offset=int(_V2202_CACHE.get('ledger_offset') or 0);selected=_V2202_CACHE.get('by_key');diag=_V2202_CACHE.get('diagnostics')
    try:st=OUTCOME_LEDGER.stat()
    except Exception:return False
    if getattr(st,'st_ino',None)!=inode or st.st_size<offset:
        _v2202_start_build();return False
    if st.st_size==offset:return False
    changed=False
    with OUTCOME_LEDGER.open('rb') as handle:
        handle.seek(offset)
        for raw in handle:
            diag['ledger_raw_rows']=int(diag.get('ledger_raw_rows') or 0)+1
            try:row=json.loads(raw.decode('utf-8','replace'))
            except Exception:
                diag['ledger_json_errors']=int(diag.get('ledger_json_errors') or 0)+1;continue
            before=len(selected);_v2202_accept_raw(selected,row,1,diag);changed=changed or len(selected)!=before or bool(row)
        new_offset=handle.tell()
    with _V2202_LOCK:_V2202_CACHE.update({'ledger_offset':new_offset,'ledger_size':st.st_size,'ledger_mtime_ns':st.st_mtime_ns})
    return changed


def _v2202_refresh_snapshot(force=False):
    if not _V2202_CACHE.get('ready'):
        _v2202_start_build();return 'BUILDING'
    changed=_v2202_incremental_ledger()
    try:state_mtime=OUTCOME_STATE.stat().st_mtime_ns
    except Exception:state_mtime=0
    if not force and not changed and state_mtime==_V2202_CACHE.get('state_mtime_ns'):
        _v2202_publish(_V2202_CACHE.get('snapshot'),'READY');return 'READY'
    with _V2202_LOCK:
        selected=dict(_V2202_CACHE.get('by_key') or {});diag=dict(_V2202_CACHE.get('diagnostics') or {});info={'inode':_V2202_CACHE.get('ledger_inode'),'offset':_V2202_CACHE.get('ledger_offset'),'size':_V2202_CACHE.get('ledger_size'),'mtime_ns':_V2202_CACHE.get('ledger_mtime_ns')}
    snapshot=_v2202_build_snapshot(selected,diag,info)
    with _V2202_LOCK:_V2202_CACHE.update({'snapshot':snapshot,'state_mtime_ns':state_mtime})
    _v2202_publish(snapshot,'READY');return 'READY'


def run_once__v2202():
    result=_V2202_TRACKING_RUN();result=dict(result) if isinstance(result,dict) else {}
    runtime_state=_v2202_refresh_snapshot()
    outcome=load_json(OUTCOME_STATUS,{}) or {};health=load_json(STATUS,{}) or {}
    snapshot=_V2202_CACHE.get('snapshot') if isinstance(_V2202_CACHE.get('snapshot'),dict) else outcome.get('prediction_validation_v2202') if isinstance(outcome.get('prediction_validation_v2202'),dict) else None
    runtime=_v2202_publish(snapshot,runtime_state)
    health.update({'schema':'clean_review_worker_status_v2202','version':VERSION,'build':BUILD_LABEL,'state':'running','phase':'canonical_tracking_plus_background_prediction_review','prediction_review_runtime_v2202':runtime,'prediction_review_snapshot_id_v2202':snapshot.get('snapshot_id') if isinstance(snapshot,dict) else None,'analysis_owner_v2202':'strategy_v2_outcome_status_v2133.json','health_only_status_v2202':True,'main_direct_ledger_scan_v2202':False,'cycle_complete_v2202':True,'auto_buy':False})
    _atomic_json(STATUS,health)
    result.update({'version':VERSION,'build':BUILD_LABEL,'state':'running','prediction_validation_v2202':snapshot,'prediction_validation_v2202_runtime':runtime,'auto_buy':False})
    return result


run_once=run_once__v2202
run_once.__name__='run_once';run_once.__qualname__='run_once'


def _v2202_review_ledger_once():
    marker=BASE_DIR/'runtime'/'review_v2202_canonical_owner.seeded'
    if marker.exists():return
    ts=now_ts();txt=now_text(ts)
    try:
        append_jsonl(CHANGE_LEDGER,{'schema':'change_verify_ledger_v870','change_id':'V2202-REVIEW-CANONICAL-OWNER','issue_id':'V2201-MAIN-FULL-LEDGER-TRIPLE-SCAN-AND-READER-SPLIT','version':'v2202','verify_result':'LOCAL_PASS_SERVER_CHECK','created_ts':ts,'created_at':txt,'writer':VERSION,'cause':'Main became a second analysis owner and scanned the whole outcome ledger once per public output. Review health and analysis status also carried overlapping validation fields.','fix':'Review tracking process is the only calculation owner. It publishes one compact prediction_validation_v2202 in the existing outcome status, rebuilds history in background, consumes later finalized appends incrementally, and keeps health status health-only. Main commands are readers only.','not_touched':['prediction formula/threshold','candidate/S1/Paper','structure/entry/exit','historical ledgers','auto-buy OFF'],'auto_buy':False})
        marker.parent.mkdir(parents=True,exist_ok=True);marker.write_text(txt,encoding='utf-8')
    except Exception as exc:append_error('v2202_review_ledger',exc)
# v2245 deferred module-level call: _v2202_review_ledger_once runs after runtime identity publication.


# =============================================================================
# review_worker v2.084 / v2203: preserve the one canonical snapshot atomically.
# Root repair: the base tracking writer no longer removes canonical fields from
# the shared existing outcome status between writes. The last completed snapshot
# stays readable while one Review-only refresh runs in background.
# =============================================================================
VERSION='review_worker_v2.084'
BUILD_LABEL='v2203_canonical_snapshot_persist_compact_refresh_2026-07-25'
MAIN_DEPLOY_VERSION=BUILD_LABEL
_V2203_TRACKING_RUN=_V2202_TRACKING_RUN


def _v2203_compact_row(row):
    seal=row.get('prediction_input_seal_v2188') if isinstance(row.get('prediction_input_seal_v2188'),dict) else {}
    compact_seal={
        'sealed_ts':seal.get('sealed_ts'),
        'model_generation':seal.get('model_generation'),
        'continuation_score':seal.get('continuation_score'),
        'prediction_state':seal.get('prediction_state'),
        'axes':dict(seal.get('axes') or {}) if isinstance(seal.get('axes'),dict) else {},
        'connections':dict(seal.get('connections') or {}) if isinstance(seal.get('connections'),dict) else {},
    }
    results={}
    raw_results=row.get('prediction_factor_results_v2188') if isinstance(row.get('prediction_factor_results_v2188'),dict) else {}
    samples={}
    raw_samples=row.get('samples') if isinstance(row.get('samples'),dict) else {}
    for label in ('30m','1h','3h','6h'):
        block=raw_results.get(label) if isinstance(raw_results.get(label),dict) else None
        if isinstance(block,dict):
            results[label]={k:block.get(k) for k in ('close_pct','mfe_pct','mae_pct','sampled_ts')}
        sample=raw_samples.get(label) if isinstance(raw_samples.get(label),dict) else None
        if isinstance(sample,dict):
            samples[label]={k:sample.get(k) for k in ('pct','max_pct','min_pct','sampled_ts')}
    return {
        'generation':row.get('generation'),'event_key':row.get('event_key'),'ticker':row.get('ticker'),
        'start_ts':row.get('start_ts'),'created_ts':row.get('created_ts'),'finalized_ts':row.get('finalized_ts'),'last_seen_ts':row.get('last_seen_ts'),
        'prediction_model_generation':row.get('prediction_model_generation'),
        'prediction_input_seal_v2188':compact_seal,'prediction_factor_results_v2188':results,'samples':samples,
    }


def _v2203_accept_raw(target,row,priority,diagnostics):
    if not isinstance(row,dict):return
    generation=str(row.get('generation') or '')
    if generation and generation!=GENERATION:
        diagnostics['wrong_generation_raw']+=1;return
    key=str(row.get('event_key') or '').strip()
    if not key:
        diagnostics['missing_event_key_raw']+=1;return
    rank=_v2202_rank(row,priority);old=target.get(key)
    if old is not None:
        diagnostics['duplicates_removed']+=1
        if rank<=old[0]:return
    target[key]=(rank,_v2203_compact_row(row))


_v2202_accept_raw=_v2203_accept_raw
_V2203_BASE_BUILD_SNAPSHOT=_v2202_build_snapshot

def _v2203_build_snapshot(final_selected,base_diag,source_info):
    snap=_V2203_BASE_BUILD_SNAPSHOT(final_selected,base_diag,source_info)
    snap=dict(snap) if isinstance(snap,dict) else {}
    snap.update({'schema':'prediction_review_snapshot_v2203','owner':'review_worker_v2.084','state':'PASS','canonical_status_file':'strategy_v2_outcome_status_v2133.json','base_tracking_writer_preserves_snapshot_v2203':True})
    return snap


_v2202_build_snapshot=_v2203_build_snapshot


def _v2203_publish(snapshot,runtime_state=None):
    outcome=load_json(OUTCOME_STATUS,{}) or {};outcome=dict(outcome) if isinstance(outcome,dict) else {}
    if isinstance(snapshot,dict):outcome['prediction_validation_v2202']=snapshot
    previous_runtime=outcome.get('prediction_validation_v2202_runtime') if isinstance(outcome.get('prediction_validation_v2202_runtime'),dict) else {}
    started=_V2202_CACHE.get('build_started_ts')
    runtime={'schema':'prediction_review_runtime_v2203','owner':'review_worker_v2.084','state':runtime_state or ('READY' if isinstance(snapshot,dict) else 'WAITING'),'updated_ts':now_ts(),'updated_text':now_text(),'building':bool(_V2202_CACHE.get('building')),'error':_V2202_CACHE.get('error'),'build_started_ts':started,'build_elapsed_sec':round(max(0.0,now_ts()-float(started)),3) if started else 0.0,'last_completed_snapshot_id':snapshot.get('snapshot_id') if isinstance(snapshot,dict) else previous_runtime.get('last_completed_snapshot_id'),'main_recalculation_count':0,'analysis_status_file':'strategy_v2_outcome_status_v2133.json','health_status_file':'clean_review_worker_status.json','canonical_fields_preserved_during_tracking_write':True}
    outcome.update({'version':VERSION,'build':BUILD_LABEL,'prediction_validation_v2202_runtime':runtime,'prediction_analysis_owner_v2202':'review_worker_v2.084 -> strategy_v2_outcome_status_v2133.json','clean_review_worker_status_role_v2202':'health_only','main_direct_ledger_scan_v2202':False,'auto_buy':False})
    _atomic_json(OUTCOME_STATUS,outcome)
    return runtime


_v2202_publish=_v2203_publish


def run_once__v2203():
    # Start the one background refresh before the tracking cycle. The tracking
    # writer preserves the last completed canonical fields, so there is no gap.
    if not _V2202_CACHE.get('ready') and not _V2202_CACHE.get('building'):
        _v2202_start_build()
    result=_V2203_TRACKING_RUN();result=dict(result) if isinstance(result,dict) else {}
    runtime_state=_v2202_refresh_snapshot()
    outcome=load_json(OUTCOME_STATUS,{}) or {};health=load_json(STATUS,{}) or {}
    snapshot=_V2202_CACHE.get('snapshot') if isinstance(_V2202_CACHE.get('snapshot'),dict) else outcome.get('prediction_validation_v2202') if isinstance(outcome.get('prediction_validation_v2202'),dict) else None
    runtime=_v2203_publish(snapshot,runtime_state)
    health.update({'schema':'clean_review_worker_status_v2203','version':VERSION,'build':BUILD_LABEL,'state':'running','phase':'canonical_tracking_plus_single_background_refresh','prediction_review_runtime_v2202':runtime,'prediction_review_snapshot_id_v2203':snapshot.get('snapshot_id') if isinstance(snapshot,dict) else None,'analysis_owner_v2203':'strategy_v2_outcome_status_v2133.json','health_only_status_v2203':True,'base_tracking_writer_preserves_snapshot_v2203':True,'main_direct_ledger_scan_v2203':False,'cycle_complete_v2203':True,'auto_buy':False})
    _atomic_json(STATUS,health)
    result.update({'version':VERSION,'build':BUILD_LABEL,'state':'running','prediction_validation_v2202':snapshot,'prediction_validation_v2202_runtime':runtime,'auto_buy':False})
    return result


run_once=run_once__v2203
run_once.__name__='run_once';run_once.__qualname__='run_once'


def _v2203_review_ledger_once():
    marker=BASE_DIR/'runtime'/'review_v2203_canonical_snapshot_persist.seeded'
    if marker.exists():return
    ts=now_ts();txt=now_text(ts)
    try:
        append_jsonl(CHANGE_LEDGER,{'schema':'change_verify_ledger_v870','change_id':'V2203-CANONICAL-SNAPSHOT-PERSIST','issue_id':'V2202-OUTCOME-STATUS-CANONICAL-FIELDS-DISAPPEAR-BETWEEN-WRITES','version':'v2203','verify_result':'LOCAL_PASS_SERVER_CHECK','created_ts':ts,'created_at':txt,'writer':VERSION,'cause':'The base tracking cycle replaced the shared outcome status before v2202 republished its canonical snapshot. Commands could read that short owner gap as WAITING even though Review was healthy.','fix':'Preserve the canonical prediction snapshot/runtime fields in every base status write, start the one refresh before tracking, keep the last completed snapshot visible while refreshing, and compact ledger rows in the Review-only rebuild.','not_touched':['prediction formula/threshold','candidate/S1/Paper','structure/entry/exit','historical ledgers','new file/command/Shadow','auto-buy OFF'],'auto_buy':False})
        marker.parent.mkdir(parents=True,exist_ok=True);marker.write_text(txt,encoding='utf-8')
    except Exception as exc:append_error('v2203_review_ledger',exc)
# v2245 deferred module-level call: _v2203_review_ledger_once runs after runtime identity publication.



# =============================================================================
# review_worker v2.085 / v2204: align boot health state with Guard readiness.
# The process is running immediately after singleton/PID proof, while the
# prediction-review snapshot may independently remain BUILDING in its runtime
# field. No analysis formula, threshold, ledger, candidate, or trading path changes.
# =============================================================================
VERSION='review_worker_v2.085'
BUILD_LABEL='v2204_review_boot_state_guard_contract_2026-07-26'
MAIN_DEPLOY_VERSION=BUILD_LABEL


def _v2204_review_ledger_once():
    marker=BASE_DIR/'runtime'/'review_v2204_boot_state_guard_contract.seeded'
    if marker.exists():return
    ts=now_ts();txt=now_text(ts)
    try:
        append_jsonl(CHANGE_LEDGER,{'schema':'change_verify_ledger_v870','change_id':'V2204-REVIEW-BOOT-STATE-CONTRACT','issue_id':'V2203-REVIEW-READY-TIMEOUT-ACTIVE-STATE','version':'v2204','verify_result':'LOCAL_PASS_SERVER_CHECK','created_ts':ts,'created_at':txt,'writer':VERSION,'cause':'Review wrote boot health state ACTIVE while Guard wait_worker_ready accepts only running/ready. The first heavy cycle exceeded the 90-second wait, so exact target hash/PID/version boot was falsely reported as review apply FAIL.','fix':'Publish health state running immediately after singleton/PID proof and keep phase BOOTING_FIRST_CYCLE. Prediction analysis readiness remains separately BUILDING/READY in the canonical outcome status.','not_touched':['prediction formula/threshold','candidate/S1/Paper','structure/entry/exit','historical ledgers','new file/command/Shadow','auto-buy OFF'],'auto_buy':False})
        append_jsonl(ISSUE_LEDGER,{'schema':'coinbot_single_work_ledger_v870','event_type':'ISSUE','issue_id':'V2203-REVIEW-READY-TIMEOUT-ACTIVE-STATE','status':'CHECK','title':'Review 실제 기동 성공인데 Guard ready timeout 오판','detail':'Review boot state ACTIVE와 Guard running/ready 계약 불일치. v2204에서 health state 계약만 정렬.','version':'v2204','created_ts':ts,'created_at':txt,'auto_buy':False})
        marker.parent.mkdir(parents=True,exist_ok=True);marker.write_text(txt,encoding='utf-8')
    except Exception as exc:append_error('v2204_review_ledger',exc)
# v2245 deferred module-level call: _v2204_review_ledger_once runs after runtime identity publication.


# =============================================================================
# review_worker v2.086 / v2206: exact prediction-input and horizon-result contract.
# Root repair only:
# - all historical outcome events remain visible, but formula accuracy uses only
#   events that contain the exact candidate-time axes + connections seal;
# - old pre-seal rows are reference-only and never counted as formula misses;
# - each horizon requires its own close and a sampled time after the exact event
#   time; invalid/missing time rows are separated, not reused across horizons;
# - new/current events seal aliases from the one current candidate contract.
# No prediction formula, pass threshold, candidate, structure, Paper or exit change.
# =============================================================================
VERSION='review_worker_v2.087'
BUILD_LABEL='v2207_prediction_input_horizon_contract_deploy_verified_2026-07-26'
MAIN_DEPLOY_VERSION=BUILD_LABEL
V2206_HORIZON_SEC={'30m':1800.0,'1h':3600.0,'3h':10800.0,'6h':21600.0}
V2206_EXACT_MODELS={'FULL_INPUT_V2188_PRIMARY','FULL_INPUT_V2193_CORRECTED','FULL_INPUT_V2198_CONTINUATION'}
_V2206_BASE_CREATE_RECORD=create_record
_V2206_BASE_UPDATE_IDENTITY=update_identity


def _v2206_dict(*values):
    for value in values:
        if isinstance(value,dict) and value:return value
    return {}


def _v2206_event_ts_from_candidate(row,c,nowv):
    spine=_v2206_dict(row.get('candidate_event_spine_v2176'),c.get('candidate_event_spine_v2176'))
    candidates=(
        ('S1_PUBLISHED',spine.get('s1_published_ts_v2176')),
        ('TRIGGER_DETECTED',spine.get('trigger_detected_ts_v2176')),
        ('TRIGGER_BAR_CLOSE',spine.get('source_trigger_bar_close_ts_v2176')),
        ('CONTRACT_EVALUATED',c.get('evaluated_ts')),
        ('ROW_UPDATED',row.get('updated_ts')),
        ('REVIEW_SEEN',nowv),
    )
    for source,value in candidates:
        number=_v2202_num(value)
        if number is not None and number>0 and number<=nowv+5.0:return number,source
    return nowv,'REVIEW_SEEN'


def _v2206_extract_candidate_seal(row,c,nowv):
    pred=c.get('prediction') if isinstance(c.get('prediction'),dict) else {}
    evidence=_v2206_dict(c.get('prediction_evidence'),pred.get('evidence'))
    axes=_v2206_dict(
        evidence.get('primary_axes_v2198_continuation'),
        evidence.get('primary_axes_v2193_corrected'),
        evidence.get('primary_axes_v2188'),
        evidence.get('axes'),
    )
    groups=_v2206_dict(
        evidence.get('groups_v2198_continuation'),
        evidence.get('groups_v2193_corrected'),
        evidence.get('groups_v2188_primary'),
        evidence.get('groups'),
    )
    conns=_v2206_dict(evidence.get('input_connections_v2155'))
    sealed_ts,time_source=_v2206_event_ts_from_candidate(row,c,nowv)
    return {
        'sealed_ts':sealed_ts,'sealed_text':now_text(sealed_ts),'seal_time_source_v2206':time_source,
        'model_generation':c.get('prediction_model_generation') or pred.get('prediction_model_generation'),
        'prediction_state':pred.get('state'),'continuation_score':_v2202_num(pred.get('continuation_score')),
        'primary_market_score':_v2202_num(pred.get('primary_market_score_v2198') if pred.get('primary_market_score_v2198') is not None else pred.get('primary_market_score_v2188')),
        'primary_participation_score':_v2202_num(pred.get('primary_participation_score_v2198') if pred.get('primary_participation_score_v2198') is not None else pred.get('primary_participation_score_v2188')),
        'primary_trigger_flow_score':_v2202_num(pred.get('primary_trigger_flow_score_v2198') if pred.get('primary_trigger_flow_score_v2198') is not None else pred.get('primary_trigger_flow_score_v2188')),
        'axes':_v2188_deepcopy(axes),'groups':_v2188_deepcopy(groups),'connections':_v2188_deepcopy(conns),
        'sealed_from_current_candidate_event':True,'canonical_alias_resolution_v2206':True,
        'exact_replay_ready_v2206':bool(axes and conns),'auto_buy':False,
    }


def create_record(row,c,price,nowv,key):  # type: ignore[override]
    rec=_V2206_BASE_CREATE_RECORD(row,c,price,nowv,key)
    seal=_v2206_extract_candidate_seal(row,c,nowv)
    rec['prediction_input_seal_v2188']=seal
    sealed_ts=_v2202_num(seal.get('sealed_ts'))
    if sealed_ts is not None and sealed_ts>0:
        rec['start_ts']=sealed_ts;rec['start_text']=now_text(sealed_ts)
    rec['prediction_input_owner_v2206']='current candidate compact contract -> Review sealed row'
    rec['prediction_input_exact_ready_v2206']=bool(seal.get('exact_replay_ready_v2206'))
    return rec


def update_identity(rec,row,c,nowv):  # type: ignore[override]
    _V2206_BASE_UPDATE_IDENTITY(rec,row,c,nowv)
    samples=rec.get('samples') if isinstance(rec.get('samples'),dict) else {}
    old=rec.get('prediction_input_seal_v2188') if isinstance(rec.get('prediction_input_seal_v2188'),dict) else {}
    ready=bool(isinstance(old.get('axes'),dict) and old.get('axes') and isinstance(old.get('connections'),dict) and old.get('connections'))
    # Only repair the still-open same exact event before any horizon was sealed.
    # Completed/history rows are never rewritten or guessed from ticker/time.
    if not ready and not samples:
        seal=_v2206_extract_candidate_seal(row,c,nowv)
        if seal.get('exact_replay_ready_v2206'):
            rec['prediction_input_seal_v2188']=seal
            sealed_ts=_v2202_num(seal.get('sealed_ts'))
            if sealed_ts is not None and sealed_ts>0:
                rec['start_ts']=sealed_ts;rec['start_text']=now_text(sealed_ts)
            rec['prediction_input_backfilled_before_first_horizon_v2206']=True
    rec['prediction_input_exact_ready_v2206']=bool((rec.get('prediction_input_seal_v2188') or {}).get('exact_replay_ready_v2206') or ready)


def _v2206_exact_entry_ts(row,seal):
    # start_ts is the Review event clock. The candidate seal clock is preferred
    # only when it is not later than start_ts; this prevents late migration time
    # from replacing the original event start.
    start=_v2202_num(row.get('start_ts'))
    sealed=_v2202_num(seal.get('sealed_ts'))
    values=[('START_TS',start),('SEALED_TS',sealed)] if start and sealed and start<=sealed else [('SEALED_TS',sealed),('START_TS',start)]
    for source,value in values:
        if value is not None and value>0:return value,source
    return None,'MISSING'


def _v2206_horizon_raw(row,label,entry_ts):
    results=row.get('prediction_factor_results_v2188') if isinstance(row.get('prediction_factor_results_v2188'),dict) else {}
    samples=row.get('samples') if isinstance(row.get('samples'),dict) else {}
    block=results.get(label) if isinstance(results.get(label),dict) else {}
    sample=samples.get(label) if isinstance(samples.get(label),dict) else {}
    if not block and not sample:return None
    close=_v2202_num(block.get('close_pct'))
    if close is None:close=_v2202_num(sample.get('pct'))
    sampled=_v2202_num(block.get('sampled_ts'))
    if sampled is None:sampled=_v2202_num(sample.get('sampled_ts'))
    state='READY';reason=None;elapsed=None
    if close is None:state='INVALID';reason='CLOSE_MISSING'
    elif entry_ts is None or sampled is None:state='INVALID';reason='TIME_MISSING'
    else:
        elapsed=sampled-entry_ts
        minimum=V2206_HORIZON_SEC[label]-2.0
        if elapsed<minimum:state='INVALID';reason='HORIZON_TIME_TOO_EARLY'
    mfe=_v2202_num(block.get('mfe_pct'))
    if mfe is None:mfe=_v2202_num(sample.get('max_pct'))
    mae=_v2202_num(block.get('mae_pct'))
    if mae is None:mae=_v2202_num(sample.get('min_pct'))
    return {'state':state,'invalid_reason':reason,'close_pct':close,'truth':_v2202_truth(close) if state=='READY' else None,
            'sampled_ts':sampled,'elapsed_sec':elapsed,'expected_horizon_sec':V2206_HORIZON_SEC[label],
            'mfe_pct':max(0.0,mfe) if mfe is not None else None,'mae_pct':min(0.0,mae) if mae is not None else None,
            'path_ready':bool(mfe is not None and mae is not None)}


def _v2206_prepare_row(row,previous_fn,current_fn):
    if not isinstance(row,dict):return None,'ROW_NOT_OBJECT'
    key=str(row.get('event_key') or '').strip()
    if not key:return None,'EVENT_KEY_MISSING'
    seal=row.get('prediction_input_seal_v2188') if isinstance(row.get('prediction_input_seal_v2188'),dict) else {}
    axes=_v2206_dict(seal.get('axes'))
    conns=_v2206_dict(seal.get('connections'))
    exact=bool(axes and conns)
    entry_ts,entry_source=_v2206_exact_entry_ts(row,seal)
    horizons={label:_v2206_horizon_raw(row,label,entry_ts) for label in ('30m','1h','3h','6h')}
    if not any(isinstance(v,dict) for v in horizons.values()):return None,'HORIZON_RESULT_MISSING'
    model=str(row.get('prediction_model_generation') or seal.get('model_generation') or 'UNKNOWN')
    base={'event_key':key,'event_key_short':hashlib.sha256(key.encode()).hexdigest()[:10],'ticker':ticker(row.get('ticker')) or '-',
          'entry_ts':entry_ts,'entry_time_source_v2206':entry_source,'model_generation':model,
          'exact_input_ready_v2206':exact,'legacy_preseal_v2206':not exact,
          'previous_score':None,'current_score':None,'sealed_live_score':_v2202_num(seal.get('continuation_score')),
          'current_axes':{},'horizons':horizons,'score_error':None,'input_state':'READY' if exact else 'LEGACY_PRESEAL'}
    if not exact:return base,'LEGACY_PRESEAL'
    score_error=None
    try:previous=previous_fn(axes,conns) if callable(previous_fn) else {}
    except Exception as exc:previous={};score_error=f'previous:{type(exc).__name__}'
    try:current=current_fn(axes,conns) if callable(current_fn) else {}
    except Exception as exc:current={};score_error=(score_error+';' if score_error else '')+f'current:{type(exc).__name__}'
    previous=previous if isinstance(previous,dict) else {};current=current if isinstance(current,dict) else {}
    current_axes=current.get('axes') if isinstance(current.get('axes'),dict) else {}
    base.update({'previous_score':_v2202_num(previous.get('continuation_score')),'current_score':_v2202_num(current.get('continuation_score')),
                 'current_axes':{str(k):_v2202_num(v) for k,v in current_axes.items()},'score_error':score_error,
                 'input_state':'SCORE_ERROR' if score_error else 'READY'})
    return base,('SCORE_ERROR' if score_error else None)


def _v2206_aggregate(events,recent_cutoff=None):
    labels={'relative_strength_level':'상대강도','relative_strength_delta':'상대강도 변화','money_flow_level':'자금유입','money_flow_delta':'자금유입 변화','buy_sustain_level':'매수 지속','trade_intensity_delta':'체결 변화','sell_pressure_level':'매도압력','leader_persistence':'주도 알트 지속','market_liquidity_regime':'시장 유동성','buy_ratio_level':'공격매수 비율','momentum_level':'현재 모멘텀'}
    out={}
    for label in ('30m','1h','3h','6h'):
        b={'raw_result_rows':0,'samples':0,'time_invalid':0,'time_missing':0,'close_missing':0,'exact_samples':0,'legacy_samples':0,
           'actual_up':0,'actual_down':0,'actual_flat':0,'previous_score_ready':0,'previous_score_missing':0,'current_score_ready':0,'current_score_missing':0,
           'previous_correct':0,'previous_wrong':0,'current_correct':0,'current_wrong':0,'previous_pass_count':0,'previous_pass_up':0,'previous_pass_down':0,
           'current_pass_count':0,'current_pass_up':0,'current_pass_down':0,'current_pass_flat':0,'formula_missed_up_count':0,'score_missing_up_count':0,'false_positive_count':0,
           'recovered_up':0,'avoided_down':0,'lost_up':0,'pass_close':[],'pass_mfe':[],'pass_mae':[],'current_pass_path_ready':0,
           'formula_missed_up_examples':[],'score_missing_up_examples':[],'false_positive_examples':[],'factor':{name:{'correct':0,'wrong':0} for name in labels},
           'buckets':{key:{'key':key,'label':lab,'n':0,'up':0,'down':0,'flat':0,'close':[]} for key,lab in (('NEG','<0'),('P00','0.00~0.05'),('P05','0.05~0.10'),('P10','0.10~0.20'),('P20','0.20 이상'))}}
        for event in events:
            block=(event.get('horizons') or {}).get(label)
            if not isinstance(block,dict):continue
            b['raw_result_rows']+=1
            if block.get('state')!='READY':
                reason=str(block.get('invalid_reason') or '')
                if reason=='HORIZON_TIME_TOO_EARLY':b['time_invalid']+=1
                elif reason=='TIME_MISSING':b['time_missing']+=1
                elif reason=='CLOSE_MISSING':b['close_missing']+=1
                continue
            if recent_cutoff is not None:
                sampled=_v2202_num(block.get('sampled_ts'))
                if sampled is None or sampled<recent_cutoff:continue
            truth=block.get('truth')
            if truth not in ('UP','DOWN','FLAT'):continue
            b['samples']+=1;b['actual_'+truth.lower()]+=1
            exact=bool(event.get('exact_input_ready_v2206'))
            if not exact:
                b['legacy_samples']+=1;b['current_score_missing']+=1;b['previous_score_missing']+=1
                if truth=='UP':b['score_missing_up_count']+=1;b['score_missing_up_examples'].append(_v2202_example(event,block))
                continue
            b['exact_samples']+=1
            ps=event.get('previous_score');cs=event.get('current_score')
            if ps is None:b['previous_score_missing']+=1
            else:
                b['previous_score_ready']+=1
                if truth in ('UP','DOWN'):
                    if ('UP' if ps>0 else 'DOWN')==truth:b['previous_correct']+=1
                    else:b['previous_wrong']+=1
                if ps>0:b['previous_pass_count']+=1;b['previous_pass_up']+=int(truth=='UP');b['previous_pass_down']+=int(truth=='DOWN')
            live_pass=event.get('current_formula_pass_v2210')
            current_pass=bool(live_pass) if live_pass is not None else bool(cs is not None and cs>0)
            if cs is None:b['current_score_missing']+=1
            else:
                b['current_score_ready']+=1
                if truth in ('UP','DOWN'):
                    current_direction=('UP' if current_pass else 'DOWN') if live_pass is not None else ('UP' if cs>0 else 'DOWN')
                    if current_direction==truth:b['current_correct']+=1
                    else:b['current_wrong']+=1
                buck=_v2202_bucket(cs)
                if buck:
                    item=b['buckets'][buck[0]];item['n']+=1;item[truth.lower()]+=1;item['close'].append(block.get('close_pct'))
                if current_pass:
                    b['current_pass_count']+=1;b['current_pass_up']+=int(truth=='UP');b['current_pass_down']+=int(truth=='DOWN');b['current_pass_flat']+=int(truth=='FLAT')
                    b['pass_close'].append(block.get('close_pct'))
                    if block.get('path_ready'):
                        b['current_pass_path_ready']+=1;b['pass_mfe'].append(block.get('mfe_pct'));b['pass_mae'].append(block.get('mae_pct'))
            previous_pass=bool(ps is not None and ps>0)
            if truth=='UP':
                if cs is not None and not current_pass:b['formula_missed_up_count']+=1;b['formula_missed_up_examples'].append(_v2202_example(event,block))
                if not previous_pass and current_pass:b['recovered_up']+=1
                if previous_pass and not current_pass:b['lost_up']+=1
            elif truth=='DOWN':
                if current_pass:b['false_positive_count']+=1;b['false_positive_examples'].append(_v2202_example(event,block))
                if previous_pass and not current_pass:b['avoided_down']+=1
            for name,item in b['factor'].items():
                val=(event.get('current_axes') or {}).get(name)
                if val is None or abs(val)<=0.12 or truth not in ('UP','DOWN'):continue
                item['correct' if ('UP' if val>0 else 'DOWN')==truth else 'wrong']+=1
        b['previous_accuracy_pct']=_v2202_pct(b['previous_correct'],b['previous_wrong'])
        b['current_accuracy_pct']=_v2202_pct(b['current_correct'],b['current_wrong'])
        b['previous_pass_win_rate_pct']=_v2202_pct(b['previous_pass_up'],b['previous_pass_down'])
        b['current_pass_win_rate_pct']=_v2202_pct(b['current_pass_up'],b['current_pass_down'])
        b['current_pass_avg_close_pct']=_v2202_avg(b.pop('pass_close'));b['current_pass_mfe_avg_pct']=_v2202_avg(b.pop('pass_mfe'));b['current_pass_mae_avg_pct']=_v2202_avg(b.pop('pass_mae'))
        for key in ('formula_missed_up_examples','score_missing_up_examples'):
            b[key].sort(key=lambda x:float(x.get('close_pct') or 0.0),reverse=True);b[key]=b[key][:8]
        b['false_positive_examples'].sort(key=lambda x:float(x.get('close_pct') or 0.0));b['false_positive_examples']=b['false_positive_examples'][:8]
        rows=[]
        for key in ('NEG','P00','P05','P10','P20'):
            item=b['buckets'][key];rows.append({'key':key,'label':item['label'],'n':item['n'],'up':item['up'],'down':item['down'],'flat':item['flat'],'up_rate_pct':_v2202_pct(item['up'],item['down']),'avg_close_pct':_v2202_avg(item['close'])})
        b['score_buckets']=rows;b.pop('buckets',None)
        factors=[]
        for name,item in b.pop('factor').items():
            scored=item['correct']+item['wrong'];factors.append({'name':name,'label':labels[name],'correct':item['correct'],'wrong':item['wrong'],'scored':scored,'accuracy_pct':_v2202_pct(item['correct'],item['wrong'])})
        factors.sort(key=lambda x:(x['accuracy_pct'] if x['accuracy_pct'] is not None else 999.0,-x['scored']));b['factor_rows']=factors
        out[label]=b
    return out


# Make the existing one Review build owner use the exact contract above.
_v2202_prepare_row=_v2206_prepare_row
_v2202_aggregate=_v2206_aggregate


def _v2206_build_snapshot(final_selected,base_diag,source_info):
    started=time.monotonic();previous_fn=_v2198_score_previous;current_fn=_v2198_score_current
    selected=dict(final_selected)
    state_rows,state_mtime=_v2202_read_state_rows();overlay_diag={'wrong_generation_raw':0,'missing_event_key_raw':0,'duplicates_removed':0}
    for row in state_rows:_v2202_accept_raw(selected,row,2,overlay_diag)
    events=[];missing=Counter();score_errors=0
    for rank,row in selected.values():
        event,reason=_v2206_prepare_row(row,previous_fn,current_fn)
        if reason:missing[reason]+=1
        if event is None:continue
        if event.get('score_error'):score_errors+=1
        events.append(event)
    horizons=_v2206_aggregate(events);recent=_v2206_aggregate(events,now_ts()-86400.0)
    exact=sum(1 for e in events if e.get('exact_input_ready_v2206'));legacy=len(events)-exact
    current_exact=sum(1 for e in events if e.get('exact_input_ready_v2206') and str(e.get('model_generation') or '')==V2202_CURRENT_MODEL)
    d=dict(base_diag);d.update({'unique_event_keys':len(selected),'outcome_events_with_horizon':len(events),'valid_events':exact,
        'exact_sealed_events_v2206':exact,'legacy_preseal_events_v2206':legacy,'current_model_exact_events_v2206':current_exact,
        'exact_seal_coverage_pct_v2206':round(exact/len(events)*100.0,3) if events else 0.0,
        'input_seal_missing_unique':missing['LEGACY_PRESEAL'],'connections_missing_unique':0,
        'horizon_result_missing_unique':missing['HORIZON_RESULT_MISSING'],'score_error_events':score_errors,
        'state_rows':len(state_rows),'state_overlay_duplicates':overlay_diag['duplicates_removed'],
        'horizon_time_invalid_v2206':{k:int((v or {}).get('time_invalid') or 0) for k,v in horizons.items()},
        'horizon_time_missing_v2206':{k:int((v or {}).get('time_missing') or 0) for k,v in horizons.items()}})
    source_info=dict(source_info);source_info['state_mtime_ns']=state_mtime
    material={'ledger':source_info,'state_mtime':state_mtime,'exact':exact,'h':{k:(v.get('samples'),v.get('exact_samples'),v.get('current_pass_count'),v.get('time_invalid')) for k,v in horizons.items()}}
    sid=hashlib.sha256(json.dumps(material,sort_keys=True,separators=(',',':'),default=str).encode()).hexdigest()[:16]
    return {'schema':'prediction_review_snapshot_v2206','owner':'review_worker_v2.087','state':'PASS' if callable(previous_fn) and callable(current_fn) else 'FAIL',
        'snapshot_id':'review-'+sid,'calculated_ts':now_ts(),'calculated_text':now_text(),'calculation_sec':round(time.monotonic()-started,3),
        'source_owner':'Review worker: strategy_v2_outcome_state_v2133.json + strategy_v2_outcomes_v2133.jsonl',
        'input_owner_contract_v2206':'candidate compact contract -> prediction_input_seal_v2188 -> exact event_key outcome',
        'formula_scope_v2206':'exact candidate-time axes+connections seal only; legacy pre-seal rows reference-only',
        'source_info':source_info,'diagnostics':d,'previous_model':V2202_PREVIOUS_MODEL,'current_model':V2202_CURRENT_MODEL,
        'truth_rule':'each horizon own close_pct; ±0.10% neutral; sampled_ts must be after exact event time by that horizon',
        'path_rule':'recorded horizon MFE/MAE only; entry 0 normalization; no close fallback','horizons':horizons,'recent_24h':recent,
        'low_accuracy_factors':{label:(horizons.get(label) or {}).get('factor_rows',[])[:6] for label in ('3h','6h')},
        'main_recalculation_count':0,'historical_ledgers_rewritten':False,'historical_ledgers_deleted':False,'new_shadow_created':False,'auto_buy':False}


_v2202_build_snapshot=_v2206_build_snapshot


def _v2206_publish(snapshot,runtime_state=None):
    outcome=load_json(OUTCOME_STATUS,{}) or {};outcome=dict(outcome) if isinstance(outcome,dict) else {}
    if isinstance(snapshot,dict):outcome['prediction_validation_v2202']=snapshot
    previous_runtime=outcome.get('prediction_validation_v2202_runtime') if isinstance(outcome.get('prediction_validation_v2202_runtime'),dict) else {}
    started=_V2202_CACHE.get('build_started_ts')
    runtime={'schema':'prediction_review_runtime_v2206','owner':'review_worker_v2.087','state':runtime_state or ('READY' if isinstance(snapshot,dict) else 'WAITING'),
        'updated_ts':now_ts(),'updated_text':now_text(),'building':bool(_V2202_CACHE.get('building')),'error':_V2202_CACHE.get('error'),
        'build_started_ts':started,'build_elapsed_sec':round(max(0.0,now_ts()-float(started)),3) if started else 0.0,
        'last_completed_snapshot_id':snapshot.get('snapshot_id') if isinstance(snapshot,dict) else previous_runtime.get('last_completed_snapshot_id'),
        'main_recalculation_count':0,'analysis_status_file':'strategy_v2_outcome_status_v2133.json','health_status_file':'clean_review_worker_status.json',
        'canonical_fields_preserved_during_tracking_write':True,'exact_input_horizon_contract_v2206':True}
    outcome.update({'version':VERSION,'build':BUILD_LABEL,'prediction_validation_v2202_runtime':runtime,
        'prediction_analysis_owner_v2202':'review_worker_v2.087 -> strategy_v2_outcome_status_v2133.json',
        'clean_review_worker_status_role_v2202':'health_only','main_direct_ledger_scan_v2202':False,'auto_buy':False})
    _atomic_json(OUTCOME_STATUS,outcome);return runtime


_v2202_publish=_v2206_publish
_v2203_publish=_v2206_publish


def run_once__v2206():
    if not _V2202_CACHE.get('ready') and not _V2202_CACHE.get('building'):_v2202_start_build()
    result=_V2203_TRACKING_RUN();result=dict(result) if isinstance(result,dict) else {}
    runtime_state=_v2202_refresh_snapshot()
    outcome=load_json(OUTCOME_STATUS,{}) or {};health=load_json(STATUS,{}) or {}
    snapshot=_V2202_CACHE.get('snapshot') if isinstance(_V2202_CACHE.get('snapshot'),dict) else outcome.get('prediction_validation_v2202') if isinstance(outcome.get('prediction_validation_v2202'),dict) else None
    runtime=_v2206_publish(snapshot,runtime_state)
    health.update({'schema':'clean_review_worker_status_v2206','version':VERSION,'build':BUILD_LABEL,'state':'running','phase':'canonical_tracking_exact_input_horizon_contract',
        'prediction_review_runtime_v2202':runtime,'prediction_review_snapshot_id_v2206':snapshot.get('snapshot_id') if isinstance(snapshot,dict) else None,
        'analysis_owner_v2206':'strategy_v2_outcome_status_v2133.json','health_only_status_v2206':True,'main_direct_ledger_scan_v2206':False,
        'exact_input_horizon_contract_v2206':True,'cycle_complete_v2206':True,'auto_buy':False})
    _atomic_json(STATUS,health)
    result.update({'version':VERSION,'build':BUILD_LABEL,'state':'running','prediction_validation_v2202':snapshot,'prediction_validation_v2202_runtime':runtime,'auto_buy':False})
    return result


run_once=run_once__v2206
run_once.__name__='run_once';run_once.__qualname__='run_once'


def _v2206_review_ledger_once():
    marker=BASE_DIR/'runtime'/'review_v2206_prediction_input_horizon_contract.seeded'
    if marker.exists():return
    ts=now_ts();txt=now_text(ts)
    try:
        append_jsonl(CHANGE_LEDGER,{'schema':'change_verify_ledger_v870','change_id':'V2206-PREDICTION-INPUT-HORIZON-CONTRACT','issue_id':'V2205-LEGACY-PRESEAL-AND-HORIZON-TIME-MIXED-IN-REVIEW','version':'v2206','verify_result':'LOCAL_PASS_SERVER_CHECK','created_ts':ts,'created_at':txt,'writer':VERSION,
            'cause':'The canonical Review snapshot mixed all historical price-result rows with the small exact input-sealed model sample. Legacy pre-seal rises appeared beside formula misses, and horizon rows with sampled time earlier than the required boundary were reused as 3h/6h truth.',
            'fix':'Keep all history visible, but evaluate v2193/v2198 only on exact candidate-time axes+connections seals. Resolve current compact-contract aliases once when the event is created, require independent horizon close and sampled time, and separate legacy/no-time rows instead of guessing.',
            'not_touched':['prediction formula/pass threshold','candidate/S1/Paper','structure/Trigger/Invalid/Target/RR','Paper cost/exit','historical ledgers','new file/command/Shadow','auto-buy OFF'],'auto_buy':False})
        marker.parent.mkdir(parents=True,exist_ok=True);marker.write_text(txt,encoding='utf-8')
    except Exception as exc:append_error('v2206_review_ledger',exc)
# v2245 deferred module-level call: _v2206_review_ledger_once runs after runtime identity publication.



# v2207 is a deployment-safe reissue of the v2206 Review contract.
def _v2207_review_deploy_ledger_once():
    marker=BASE_DIR/'runtime'/'review_v2207_isolated_compile_deploy.seeded'
    if marker.exists():return
    ts=now_ts();txt=now_text(ts)
    try:
        append_jsonl(CHANGE_LEDGER,{'schema':'change_verify_ledger_v870','change_id':'V2207-WORKER-ISOLATED-COMPILE-DEPLOY-VERIFY','issue_id':'V2206-REVIEW-PYCOMPILE-DEPLOY-PATH-FAIL','version':'v2207','verify_result':'LOCAL_PASS_SERVER_CHECK','created_ts':ts,'created_at':txt,'writer':VERSION,
            'cause':'The v2206 Review source itself passes source compile and import. Deployment stopped before copy because Guard worker apply used a separate subprocess py_compile path that writes bytecode and hid the exact stderr.',
            'fix':'Reuse the unchanged v2206 exact prediction-input/horizon contract under Review v2.087. Guard v2.6.45 now compiles workers in-process without pyc, displays exact errors, proves target/active SHA256, and only then restarts.',
            'not_touched':['prediction formula/pass threshold','candidate/S1/Paper','structure/Trigger/Invalid/Target/RR','Paper cost/exit','historical ledgers','new file/command/Shadow','auto-buy OFF'],'auto_buy':False})
        marker.parent.mkdir(parents=True,exist_ok=True);marker.write_text(txt,encoding='utf-8')
    except Exception as exc:append_error('v2207_review_deploy_ledger',exc)
# v2245 deferred module-level call: _v2207_review_deploy_ledger_once runs after runtime identity publication.


# =============================================================================
# review_worker v2.088 / v2208: current-process exact snapshot freshness.
# A restart immediately publishes a BUILDING marker for this producer instance,
# so the previous process snapshot cannot be shown as current. The completed
# snapshot carries one stable contract id and the same producer instance id.
# No formula, threshold, candidate, structure, Paper, exit or ledger change.
# =============================================================================
VERSION='review_worker_v2.088'
BUILD_LABEL='v2208_fresh_review_instance_exact_contract_2026-07-26'
MAIN_DEPLOY_VERSION=BUILD_LABEL
V2208_CONTRACT_ID='prediction_input_horizon_exact_v1'
V2208_PROCESS_STARTED_TS=now_ts()
V2208_PROCESS_INSTANCE_ID=f"review-{os.getpid()}-{int(V2208_PROCESS_STARTED_TS*1000000)}"
_V2208_BOOT_MARKED=False
_V2208_BASE_BUILD_SNAPSHOT=_v2206_build_snapshot


def _v2208_build_snapshot(final_selected,base_diag,source_info):
    snap=_V2208_BASE_BUILD_SNAPSHOT(final_selected,base_diag,source_info)
    snap=dict(snap) if isinstance(snap,dict) else {}
    d=snap.get('diagnostics') if isinstance(snap.get('diagnostics'),dict) else {}
    h=snap.get('horizons') if isinstance(snap.get('horizons'),dict) else {}
    exact=int(_v2202_num(d.get('exact_sealed_events_v2206')) or 0)
    horizon_exact=sum(int(_v2202_num((h.get(label) or {}).get('exact_samples')) or 0) for label in ('3h','6h'))
    snap.update({'schema':'prediction_review_snapshot_v2208','owner':VERSION,'state':'PASS',
        'contract_id_v2208':V2208_CONTRACT_ID,'producer_instance_id_v2208':V2208_PROCESS_INSTANCE_ID,
        'producer_started_ts_v2208':V2208_PROCESS_STARTED_TS,'producer_started_text_v2208':now_text(V2208_PROCESS_STARTED_TS),
        'formula_ready_v2208':bool(exact>0 and horizon_exact>0),'fresh_process_snapshot_v2208':True})
    return snap


_v2202_build_snapshot=_v2208_build_snapshot


def _v2208_building_snapshot(state='BUILDING'):
    return {'schema':'prediction_review_snapshot_v2208','owner':VERSION,'state':state,'snapshot_id':None,'calculated_ts':None,
        'contract_id_v2208':V2208_CONTRACT_ID,'producer_instance_id_v2208':V2208_PROCESS_INSTANCE_ID,
        'producer_started_ts_v2208':V2208_PROCESS_STARTED_TS,'producer_started_text_v2208':now_text(V2208_PROCESS_STARTED_TS),
        'formula_ready_v2208':False,'fresh_process_snapshot_v2208':False,
        'diagnostics':{'unique_event_keys':0,'outcome_events_with_horizon':0,'valid_events':0,'exact_sealed_events_v2206':0,
            'legacy_preseal_events_v2206':0,'current_model_exact_events_v2206':0,'exact_seal_coverage_pct_v2206':0.0,
            'score_error_events':0,'ledger_json_errors':0},
        'horizons':{label:{'samples':0,'exact_samples':0,'legacy_samples':0,'time_invalid':0,'time_missing':0,'close_missing':0} for label in ('30m','1h','3h','6h')},
        'recent_24h':{},'main_recalculation_count':0,'historical_ledgers_rewritten':False,'historical_ledgers_deleted':False,'new_shadow_created':False,'auto_buy':False}


def _v2208_publish(snapshot,runtime_state=None):
    outcome=load_json(OUTCOME_STATUS,{}) or {};outcome=dict(outcome) if isinstance(outcome,dict) else {}
    current=bool(isinstance(snapshot,dict) and str(snapshot.get('contract_id_v2208') or '')==V2208_CONTRACT_ID and str(snapshot.get('producer_instance_id_v2208') or '')==V2208_PROCESS_INSTANCE_ID and snapshot.get('state')=='PASS')
    state=str(runtime_state or ('READY' if current else 'BUILDING'))
    if not current and state not in ('ERROR','WAITING'):state='BUILDING'
    canonical=snapshot if current else _v2208_building_snapshot('ERROR' if state=='ERROR' else 'BUILDING')
    previous_runtime=outcome.get('prediction_validation_v2202_runtime') if isinstance(outcome.get('prediction_validation_v2202_runtime'),dict) else {}
    started=_V2202_CACHE.get('build_started_ts') or V2208_PROCESS_STARTED_TS
    runtime={'schema':'prediction_review_runtime_v2208','owner':VERSION,'state':state,'updated_ts':now_ts(),'updated_text':now_text(),
        'building':bool(_V2202_CACHE.get('building')),'error':_V2202_CACHE.get('error'),'build_started_ts':started,
        'build_elapsed_sec':round(max(0.0,now_ts()-float(started)),3) if started else 0.0,
        'last_completed_snapshot_id':canonical.get('snapshot_id') if current else None,'main_recalculation_count':0,
        'analysis_status_file':'strategy_v2_outcome_status_v2133.json','health_status_file':'clean_review_worker_status.json',
        'canonical_fields_preserved_during_tracking_write':True,'exact_input_horizon_contract_v2206':True,
        'contract_id_v2208':V2208_CONTRACT_ID,'producer_instance_id_v2208':V2208_PROCESS_INSTANCE_ID,
        'producer_started_ts_v2208':V2208_PROCESS_STARTED_TS,'previous_process_snapshot_reused_v2208':False}
    outcome.update({'version':VERSION,'build':BUILD_LABEL,'prediction_validation_v2202':canonical,
        'prediction_validation_v2202_runtime':runtime,'prediction_analysis_owner_v2202':f'{VERSION} -> strategy_v2_outcome_status_v2133.json',
        'clean_review_worker_status_role_v2202':'health_only','main_direct_ledger_scan_v2202':False,'auto_buy':False})
    _atomic_json(OUTCOME_STATUS,outcome);return runtime


_v2202_publish=_v2208_publish
_v2203_publish=_v2208_publish


def run_once__v2208():
    global _V2208_BOOT_MARKED
    if not _V2208_BOOT_MARKED:
        _v2208_publish(None,'BUILDING');_V2208_BOOT_MARKED=True
    if not _V2202_CACHE.get('ready') and not _V2202_CACHE.get('building'):_v2202_start_build()
    result=_V2203_TRACKING_RUN();result=dict(result) if isinstance(result,dict) else {}
    runtime_state=_v2202_refresh_snapshot()
    health=load_json(STATUS,{}) or {}
    cached=_V2202_CACHE.get('snapshot') if isinstance(_V2202_CACHE.get('snapshot'),dict) else None
    snapshot=cached if isinstance(cached,dict) and str(cached.get('producer_instance_id_v2208') or '')==V2208_PROCESS_INSTANCE_ID else None
    runtime=_v2208_publish(snapshot,runtime_state)
    health.update({'schema':'clean_review_worker_status_v2208','version':VERSION,'build':BUILD_LABEL,'state':'running','phase':'canonical_tracking_fresh_instance_exact_contract',
        'prediction_review_runtime_v2202':runtime,'prediction_review_snapshot_id_v2208':snapshot.get('snapshot_id') if isinstance(snapshot,dict) else None,
        'analysis_owner_v2208':'strategy_v2_outcome_status_v2133.json','health_only_status_v2208':True,'main_direct_ledger_scan_v2208':False,
        'exact_input_horizon_contract_v2206':True,'contract_id_v2208':V2208_CONTRACT_ID,
        'producer_instance_id_v2208':V2208_PROCESS_INSTANCE_ID,'producer_started_ts_v2208':V2208_PROCESS_STARTED_TS,
        'previous_process_snapshot_reused_v2208':False,'cycle_complete_v2208':True,'auto_buy':False})
    _atomic_json(STATUS,health)
    result.update({'version':VERSION,'build':BUILD_LABEL,'state':'running','prediction_validation_v2202':snapshot or _v2208_building_snapshot(),
        'prediction_validation_v2202_runtime':runtime,'auto_buy':False})
    return result


run_once=run_once__v2208
run_once.__name__='run_once';run_once.__qualname__='run_once'


def _v2208_review_ledger_once():
    marker=BASE_DIR/'runtime'/'review_v2208_fresh_instance_exact_contract.seeded'
    if marker.exists():return
    ts=now_ts();txt=now_text(ts)
    try:
        append_jsonl(CHANGE_LEDGER,{'schema':'change_verify_ledger_v870','change_id':'V2208-FRESH-REVIEW-INSTANCE-EXACT-CONTRACT','issue_id':'V2207-OLD-REVIEW-SNAPSHOT-ACCEPTED-AS-NEW-EXACT','version':'v2208','verify_result':'LOCAL_PASS_SERVER_CHECK','created_ts':ts,'created_at':txt,'writer':VERSION,
            'cause':'After Review restart the shared status still contained the previous v2.084 completed snapshot. Main silently used legacy valid_events as exact count and rendered old accuracy/TOP metrics even though the new exact contract had not completed.',
            'fix':'Publish a current-process BUILDING marker immediately, stamp completed snapshots and health/runtime with one producer instance id and stable contract id, and never republish a previous-process snapshot as current.',
            'not_touched':['prediction formula/pass threshold','candidate/S1/Paper','structure/Trigger/Invalid/Target/RR','Paper cost/exit','historical ledgers','new command/Shadow','auto-buy OFF'],'auto_buy':False})
        marker.parent.mkdir(parents=True,exist_ok=True);marker.write_text(txt,encoding='utf-8')
    except Exception as exc:append_error('v2208_review_ledger',exc)
# v2245 deferred module-level call: _v2208_review_ledger_once runs after runtime identity publication.


# =============================================================================
# review_worker v2.089 / v2209: one-shot full scan lifecycle with visible
# progress, latched errors, verified completion and append-only incremental
# refresh. No prediction formula, pass threshold, candidate, Paper, structure,
# exit, historical ledger, command, Shadow or auto-buy change.
# =============================================================================
import traceback
VERSION='review_worker_v2.089'
BUILD_LABEL='v2209_review_single_scan_progress_latched_error_2026-07-26'
MAIN_DEPLOY_VERSION=BUILD_LABEL
V2209_PROCESS_STARTED_TS=V2208_PROCESS_STARTED_TS
V2209_PROCESS_INSTANCE_ID=V2208_PROCESS_INSTANCE_ID
V2209_PROGRESS_PUBLISH_SEC=2.0
V2209_PROGRESS_ROW_STEP=5000
V2209_SNAPSHOT_REFRESH_MIN_SEC=30.0
_V2209_PUBLISH_LOCK=threading.RLock()
_V2202_CACHE.update({
    'build_attempted_v2209':False,
    'error_latched_v2209':False,
    'error_stage_v2209':None,
    'error_trace_v2209':None,
    'stage_v2209':'BOOT',
    'progress_rows_v2209':0,
    'progress_bytes_v2209':0,
    'progress_total_bytes_v2209':0,
    'progress_pct_v2209':0.0,
    'last_progress_ts_v2209':None,
    'full_scan_count_v2209':0,
    'incremental_scan_count_v2209':0,
    'cycle_complete_v2209':False,
    'last_snapshot_refresh_ts_v2209':0.0,
})


def _v2209_cache_view():
    with _V2202_LOCK:
        return {
            'building':bool(_V2202_CACHE.get('building')),
            'ready':bool(_V2202_CACHE.get('ready')),
            'error':_V2202_CACHE.get('error'),
            'error_stage':_V2202_CACHE.get('error_stage_v2209'),
            'error_trace':_V2202_CACHE.get('error_trace_v2209'),
            'stage':str(_V2202_CACHE.get('stage_v2209') or 'WAITING'),
            'rows':int(_V2202_CACHE.get('progress_rows_v2209') or 0),
            'bytes':int(_V2202_CACHE.get('progress_bytes_v2209') or 0),
            'total_bytes':int(_V2202_CACHE.get('progress_total_bytes_v2209') or 0),
            'pct':float(_V2202_CACHE.get('progress_pct_v2209') or 0.0),
            'last_progress_ts':_V2202_CACHE.get('last_progress_ts_v2209'),
            'full_scan_count':int(_V2202_CACHE.get('full_scan_count_v2209') or 0),
            'incremental_scan_count':int(_V2202_CACHE.get('incremental_scan_count_v2209') or 0),
            'cycle_complete':bool(_V2202_CACHE.get('cycle_complete_v2209')),
            'build_started_ts':_V2202_CACHE.get('build_started_ts'),
            'build_finished_ts':_V2202_CACHE.get('build_finished_ts'),
        }


def _v2209_runtime_state_name(view=None):
    v=view or _v2209_cache_view()
    if v.get('error'):return 'ERROR'
    if v.get('ready') and v.get('cycle_complete'):return 'READY'
    if v.get('building'):return 'SCANNING'
    return 'WAITING'


def _v2209_placeholder_snapshot(state,view=None):
    v=view or _v2209_cache_view()
    snap=_v2208_building_snapshot('ERROR' if state=='ERROR' else 'BUILDING')
    snap.update({
        'owner':VERSION,
        'producer_instance_id_v2208':V2209_PROCESS_INSTANCE_ID,
        'producer_started_ts_v2208':V2209_PROCESS_STARTED_TS,
        'producer_started_text_v2208':now_text(V2209_PROCESS_STARTED_TS),
        'scan_state_v2209':state,
        'scan_stage_v2209':v.get('stage'),
        'scan_progress_rows_v2209':v.get('rows'),
        'scan_progress_bytes_v2209':v.get('bytes'),
        'scan_total_bytes_v2209':v.get('total_bytes'),
        'scan_progress_pct_v2209':v.get('pct'),
        'scan_error_stage_v2209':v.get('error_stage'),
        'scan_error_v2209':v.get('error'),
        'full_scan_count_v2209':v.get('full_scan_count'),
        'incremental_scan_count_v2209':v.get('incremental_scan_count'),
        'cycle_complete_v2209':False,
    })
    return snap


def _v2209_publish(snapshot=None,runtime_state=None):
    view=_v2209_cache_view()
    requested=str(runtime_state or _v2209_runtime_state_name(view))
    current=bool(isinstance(snapshot,dict) and snapshot.get('state')=='PASS' and str(snapshot.get('snapshot_id') or '').strip())
    canonical=dict(snapshot) if current else _v2209_placeholder_snapshot(requested,view)
    canonical.update({
        'owner':VERSION,'version':VERSION,'build':BUILD_LABEL,
        'producer_instance_id_v2208':V2209_PROCESS_INSTANCE_ID,
        'producer_started_ts_v2208':V2209_PROCESS_STARTED_TS,
        'contract_id_v2208':V2208_CONTRACT_ID,
    })
    window=canonical.get('review_window_v2220') if isinstance(canonical.get('review_window_v2220'),dict) else {}
    diagnostics=canonical.get('diagnostics') if isinstance(canonical.get('diagnostics'),dict) else {}
    decomp=canonical.get('factor_role_influence_decomposition_v2219') if isinstance(canonical.get('factor_role_influence_decomposition_v2219'),dict) else {}
    score_contract=canonical.get('sealed_mainline_score_contract_v2233') if isinstance(canonical.get('sealed_mainline_score_contract_v2233'),dict) else {}
    quality=canonical.get('trade_outcome_compare_v2210') if isinstance(canonical.get('trade_outcome_compare_v2210'),dict) else {}
    recent_ready=bool(current and window.get('recent_ready') is True)
    full_complete=bool(current and window.get('full_ready') is True and str(window.get('scope') or '')=='FULL_HISTORY')
    sealed_ready=int(score_contract.get('sealed_score_ready') or 0)
    sealed_missing=int(score_contract.get('sealed_score_missing') or 0)
    exact=int(decomp.get('usable_mainline_score_events_v2233') or decomp.get('exact_events_seen') or diagnostics.get('exact_sealed_events_v2206') or diagnostics.get('valid_events') or 0)
    price=int(diagnostics.get('outcome_events_with_horizon') or 0)
    decomp_ready=bool(str(decomp.get('state') or '') in {'READY','PASS'} and exact>0)
    score_ready=bool(score_contract.get('state')=='PASS' and sealed_ready>0)
    analysis_ready=bool(recent_ready and decomp_ready and score_ready)
    lifecycle='COMPLETE' if full_complete else ('RECENT_7D_READY' if analysis_ready else ('BUILDING' if requested in {'SCANNING','BUILDING'} or view.get('building') else requested))
    canonical.update({
        'scan_state_v2209':'READY' if full_complete else lifecycle,
        'scan_stage_v2209':'COMPLETE' if full_complete else view.get('stage'),
        'scan_progress_rows_v2209':view.get('rows'),'scan_progress_bytes_v2209':view.get('bytes'),
        'scan_total_bytes_v2209':view.get('total_bytes'),'scan_progress_pct_v2209':100.0 if full_complete else view.get('pct'),
        'scan_error_stage_v2209':view.get('error_stage'),'scan_error_v2209':view.get('error'),
        'full_scan_count_v2209':view.get('full_scan_count'),'incremental_scan_count_v2209':view.get('incremental_scan_count'),
        'cycle_complete_v2209':full_complete,
    })
    started=view.get('build_started_ts') or V2209_PROCESS_STARTED_TS
    runtime={
        'schema':'prediction_review_runtime_v2238','owner':VERSION,'state':lifecycle,
        'updated_ts':now_ts(),'updated_text':now_text(),'building':not full_complete and bool(view.get('building')),
        'error':view.get('error'),'error_stage_v2209':view.get('error_stage'),'error_trace_v2209':view.get('error_trace'),
        'build_started_ts':started,'build_elapsed_sec':round(max(0.0,now_ts()-float(started)),3) if started else 0.0,
        'last_completed_snapshot_id':canonical.get('snapshot_id') if full_complete else None,
        'scan_stage_v2209':canonical.get('scan_stage_v2209'),'scan_progress_rows_v2209':view.get('rows'),
        'scan_progress_bytes_v2209':view.get('bytes'),'scan_total_bytes_v2209':view.get('total_bytes'),
        'scan_progress_pct_v2209':canonical.get('scan_progress_pct_v2209'),'last_progress_ts_v2209':view.get('last_progress_ts'),
        'full_scan_count_v2209':view.get('full_scan_count'),'incremental_scan_count_v2209':view.get('incremental_scan_count'),
        'cycle_complete_v2209':full_complete,'analysis_ready_v2238':analysis_ready,
        'recent_7d_ready_v2238':recent_ready,'full_history_ready_v2238':full_complete,
        'main_recalculation_count':0,'analysis_status_file':'strategy_v2_outcome_status_v2133.json',
        'health_status_file':'clean_review_worker_status.json','canonical_fields_preserved_during_tracking_write':True,
        'exact_input_horizon_contract_v2206':True,'contract_id_v2208':V2208_CONTRACT_ID,
        'producer_instance_id_v2208':V2209_PROCESS_INSTANCE_ID,'producer_started_ts_v2208':V2209_PROCESS_STARTED_TS,
        'previous_process_snapshot_reused_v2208':False,'auto_buy':False,
    }
    analysis={
        'schema':'review_analysis_v2238','owner':VERSION,'version':VERSION,'build':BUILD_LABEL,
        'publisher':'_v2209_publish','single_publisher':True,'state':lifecycle,
        'updated_ts':runtime['updated_ts'],'updated_text':runtime['updated_text'],
        'producer_instance_id':V2209_PROCESS_INSTANCE_ID,'producer_started_ts':V2209_PROCESS_STARTED_TS,
        'snapshot_id':canonical.get('snapshot_id'),'cycle_complete':full_complete,
        'recent_7d_ready':recent_ready,'full_history_ready':full_complete,'analysis_ready':analysis_ready,
        'exact_events':exact,'price_result_events':price,
        'sealed_score_ready':sealed_ready,'sealed_score_missing':sealed_missing,
        'candidate_quality_sample_count':int(quality.get('sample_count') or 0),
        'candidate_quality_wins':int(quality.get('wins') or 0),'candidate_quality_losses':int(quality.get('losses') or 0),
        'snapshot':canonical,'runtime':runtime,
        'canonical_source':'strategy_v2_outcome_status_v2133.json.review_analysis_v2238',
        'historical_ledgers_rewritten':False,'historical_ledgers_deleted':False,
        'live_formula_changed':False,'candidate_filter_changed':False,'new_shadow_created':False,'auto_buy':False,
    }
    with _V2209_PUBLISH_LOCK:
        outcome=load_json(OUTCOME_STATUS,{}) or {};outcome=dict(outcome) if isinstance(outcome,dict) else {}
        outcome.update({
            'version':VERSION,'build':BUILD_LABEL,'review_analysis_v2238':analysis,
            'prediction_validation_v2202':canonical,'prediction_validation_v2202_runtime':runtime,
            'prediction_analysis_owner_v2202':f'{VERSION} -> review_analysis_v2238',
            'clean_review_worker_status_role_v2202':'health_only','main_direct_ledger_scan_v2202':False,'auto_buy':False,
        })
        _atomic_json(OUTCOME_STATUS,outcome)
    return runtime


def _v2209_progress(stage,rows=None,read_bytes=None,total_bytes=None,force=False):
    nowv=now_ts()
    with _V2202_LOCK:
        if stage:_V2202_CACHE['stage_v2209']=str(stage)
        if rows is not None:_V2202_CACHE['progress_rows_v2209']=int(rows)
        if read_bytes is not None:_V2202_CACHE['progress_bytes_v2209']=int(read_bytes)
        if total_bytes is not None:_V2202_CACHE['progress_total_bytes_v2209']=int(total_bytes)
        total=int(_V2202_CACHE.get('progress_total_bytes_v2209') or 0)
        done=int(_V2202_CACHE.get('progress_bytes_v2209') or 0)
        _V2202_CACHE['progress_pct_v2209']=round(min(100.0,max(0.0,done/total*100.0)),2) if total>0 else 0.0
        last=float(_V2202_CACHE.get('last_progress_ts_v2209') or 0.0)
        due=bool(force or nowv-last>=V2209_PROGRESS_PUBLISH_SEC)
        if due:_V2202_CACHE['last_progress_ts_v2209']=nowv
    if due:_v2209_publish(None,'SCANNING')


def _v2209_scan_full():
    started=time.monotonic()
    diagnostics={'ledger_raw_rows':0,'ledger_json_errors':0,'wrong_generation_raw':0,'missing_event_key_raw':0,'duplicates_removed':0}
    selected={};inode=None;offset=0;size=0;mtime_ns=0
    _v2209_progress('STAT_LEDGER',0,0,0,True)
    if OUTCOME_LEDGER.exists():
        st=OUTCOME_LEDGER.stat();inode=getattr(st,'st_ino',None);size=int(st.st_size);mtime_ns=st.st_mtime_ns
        _v2209_progress('SCAN_LEDGER',0,0,size,True)
        last_rows=0
        with OUTCOME_LEDGER.open('rb') as handle:
            for raw in handle:
                diagnostics['ledger_raw_rows']+=1
                try:row=json.loads(raw.decode('utf-8','replace'))
                except Exception:
                    diagnostics['ledger_json_errors']+=1;row=None
                if isinstance(row,dict):_v2202_accept_raw(selected,row,1,diagnostics)
                rows=diagnostics['ledger_raw_rows']
                if rows-last_rows>=V2209_PROGRESS_ROW_STEP:
                    last_rows=rows;_v2209_progress('SCAN_LEDGER',rows,handle.tell(),size,False)
            offset=handle.tell()
        _v2209_progress('SCAN_LEDGER_DONE',diagnostics['ledger_raw_rows'],offset,size,True)
    diagnostics['ledger_unique_keys']=len(selected)
    return selected,diagnostics,{'inode':inode,'offset':offset,'size':size,'mtime_ns':mtime_ns,'scan_sec':round(time.monotonic()-started,3)}


def _v2209_verify_snapshot(snapshot):
    if not isinstance(snapshot,dict):raise RuntimeError('snapshot_not_object')
    if snapshot.get('state')!='PASS':raise RuntimeError('snapshot_state_not_pass')
    if str(snapshot.get('contract_id_v2208') or '')!=V2208_CONTRACT_ID:raise RuntimeError('snapshot_contract_mismatch')
    if str(snapshot.get('producer_instance_id_v2208') or '')!=V2209_PROCESS_INSTANCE_ID:raise RuntimeError('snapshot_instance_mismatch')
    if not str(snapshot.get('snapshot_id') or '').strip():raise RuntimeError('snapshot_id_missing')
    d=snapshot.get('diagnostics') if isinstance(snapshot.get('diagnostics'),dict) else None
    h=snapshot.get('horizons') if isinstance(snapshot.get('horizons'),dict) else None
    if d is None or h is None:raise RuntimeError('snapshot_diagnostics_or_horizons_missing')
    if 'exact_sealed_events_v2206' not in d or 'outcome_events_with_horizon' not in d:raise RuntimeError('snapshot_exact_contract_fields_missing')
    for label in ('30m','1h','3h','6h'):
        if not isinstance(h.get(label),dict):raise RuntimeError(f'snapshot_horizon_missing:{label}')
    return True


def _v2209_latch_error(stage,exc):
    text=f'{type(exc).__name__}: {exc}'
    trace=''.join(traceback.format_exception(type(exc),exc,exc.__traceback__))[-4000:]
    with _V2202_LOCK:
        _V2202_CACHE.update({
            'building':False,'ready':False,'error':text,'error_latched_v2209':True,
            'error_stage_v2209':str(stage),'error_trace_v2209':trace,
            'stage_v2209':'ERROR','build_finished_ts':now_ts(),'cycle_complete_v2209':False,
        })
    try:append_error(f'v2209_review_{stage}',exc)
    except Exception:pass
    _v2209_publish(None,'ERROR')


def _v2209_full_build_thread():
    try:
        _v2209_progress('SCAN_LEDGER',force=True)
        selected,diag,info=_v2209_scan_full()
        _v2209_progress('BUILD_SNAPSHOT',diag.get('ledger_raw_rows'),info.get('offset'),info.get('size'),True)
        snapshot=_v2202_build_snapshot(selected,diag,info)
        _v2209_progress('VERIFY_SNAPSHOT',diag.get('ledger_raw_rows'),info.get('offset'),info.get('size'),True)
        _v2209_verify_snapshot(snapshot)
        with _V2202_LOCK:
            _V2202_CACHE.update({
                'building':False,'ready':True,'error':None,'error_latched_v2209':False,
                'error_stage_v2209':None,'error_trace_v2209':None,'stage_v2209':'COMPLETE',
                'by_key':selected,'ledger_inode':info.get('inode'),'ledger_offset':info.get('offset'),
                'ledger_size':info.get('size'),'ledger_mtime_ns':info.get('mtime_ns'),
                'state_mtime_ns':snapshot.get('source_info',{}).get('state_mtime_ns',0),
                'snapshot':snapshot,'build_finished_ts':now_ts(),'diagnostics':diag,
                'progress_rows_v2209':int(diag.get('ledger_raw_rows') or 0),
                'progress_bytes_v2209':int(info.get('offset') or 0),'progress_total_bytes_v2209':int(info.get('size') or 0),
                'progress_pct_v2209':100.0,'cycle_complete_v2209':True,
                'last_snapshot_refresh_ts_v2209':now_ts(),
            })
        _v2209_publish(snapshot,'READY')
    except Exception as exc:_v2209_latch_error(str(_V2202_CACHE.get('stage_v2209') or 'FULL_BUILD'),exc)


def _v2209_start_build():
    with _V2202_LOCK:
        if _V2202_CACHE.get('building') or _V2202_CACHE.get('ready') or _V2202_CACHE.get('build_attempted_v2209') or _V2202_CACHE.get('error_latched_v2209'):return False
        _V2202_CACHE.update({
            'building':True,'ready':False,'error':None,'build_attempted_v2209':True,
            'build_started_ts':now_ts(),'build_finished_ts':None,'stage_v2209':'STARTING',
            'progress_rows_v2209':0,'progress_bytes_v2209':0,'progress_total_bytes_v2209':0,
            'progress_pct_v2209':0.0,'cycle_complete_v2209':False,
            'full_scan_count_v2209':int(_V2202_CACHE.get('full_scan_count_v2209') or 0)+1,
        })
    _v2209_publish(None,'SCANNING')
    thread=threading.Thread(target=_v2209_full_build_thread,name='review-v2209-single-full-scan',daemon=True);thread.start();return True


def _v2209_incremental_ledger():
    with _V2202_LOCK:
        if not _V2202_CACHE.get('ready') or _V2202_CACHE.get('building'):return False
        inode=_V2202_CACHE.get('ledger_inode');offset=int(_V2202_CACHE.get('ledger_offset') or 0)
        selected=_V2202_CACHE.get('by_key');diag=_V2202_CACHE.get('diagnostics')
    try:st=OUTCOME_LEDGER.stat()
    except FileNotFoundError:return False
    if getattr(st,'st_ino',None)!=inode or st.st_size<offset:
        raise RuntimeError('outcome_ledger_rotated_or_truncated_restart_required')
    if st.st_size==offset:return False
    changed=False
    with OUTCOME_LEDGER.open('rb') as handle:
        handle.seek(offset)
        for raw in handle:
            diag['ledger_raw_rows']=int(diag.get('ledger_raw_rows') or 0)+1
            try:row=json.loads(raw.decode('utf-8','replace'))
            except Exception:
                diag['ledger_json_errors']=int(diag.get('ledger_json_errors') or 0)+1;continue
            old=selected.get(str(row.get('event_key') or '').strip()) if isinstance(row,dict) else None
            _v2202_accept_raw(selected,row,1,diag)
            key=str(row.get('event_key') or '').strip() if isinstance(row,dict) else ''
            changed=changed or (key and selected.get(key)!=old)
        new_offset=handle.tell()
    with _V2202_LOCK:
        _V2202_CACHE.update({
            'ledger_offset':new_offset,'ledger_size':st.st_size,'ledger_mtime_ns':st.st_mtime_ns,
            'progress_rows_v2209':int(diag.get('ledger_raw_rows') or 0),'progress_bytes_v2209':int(new_offset),
            'progress_total_bytes_v2209':int(st.st_size),'progress_pct_v2209':100.0,
            'incremental_scan_count_v2209':int(_V2202_CACHE.get('incremental_scan_count_v2209') or 0)+1,
        })
    return bool(changed)


def _v2209_refresh_snapshot(force=False):
    view=_v2209_cache_view()
    if view.get('error'):return 'ERROR'
    if not view.get('ready'):
        _v2209_start_build();return 'SCANNING'
    try:
        changed=_v2209_incremental_ledger()
        try:state_mtime=OUTCOME_STATE.stat().st_mtime_ns
        except Exception:state_mtime=0
        source_changed=bool(changed or state_mtime!=_V2202_CACHE.get('state_mtime_ns'))
        last_refresh=float(_V2202_CACHE.get('last_snapshot_refresh_ts_v2209') or 0.0)
        if not source_changed:
            _v2209_publish(_V2202_CACHE.get('snapshot'),'READY');return 'READY'
        if not force and last_refresh>0 and now_ts()-last_refresh<V2209_SNAPSHOT_REFRESH_MIN_SEC:
            _v2209_publish(_V2202_CACHE.get('snapshot'),'READY');return 'READY'
        with _V2202_LOCK:
            _V2202_CACHE['stage_v2209']='INCREMENTAL_SNAPSHOT'
            selected=dict(_V2202_CACHE.get('by_key') or {});diag=dict(_V2202_CACHE.get('diagnostics') or {})
            info={'inode':_V2202_CACHE.get('ledger_inode'),'offset':_V2202_CACHE.get('ledger_offset'),
                  'size':_V2202_CACHE.get('ledger_size'),'mtime_ns':_V2202_CACHE.get('ledger_mtime_ns')}
        snapshot=_v2202_build_snapshot(selected,diag,info);_v2209_verify_snapshot(snapshot)
        with _V2202_LOCK:
            _V2202_CACHE.update({'snapshot':snapshot,'state_mtime_ns':state_mtime,'stage_v2209':'COMPLETE','cycle_complete_v2209':True,'last_snapshot_refresh_ts_v2209':now_ts()})
        _v2209_publish(snapshot,'READY');return 'READY'
    except Exception as exc:
        _v2209_latch_error('INCREMENTAL_REFRESH',exc);return 'ERROR'


# Route every later caller through the v2209 lifecycle owner.
_v2202_scan_full=_v2209_scan_full
_v2202_start_build=_v2209_start_build
_v2202_full_build_thread=_v2209_full_build_thread
_v2202_incremental_ledger=_v2209_incremental_ledger
_v2202_refresh_snapshot=_v2209_refresh_snapshot
_v2202_publish=_v2209_publish
_v2203_publish=_v2209_publish


def run_once__v2209():
    if not _V2202_CACHE.get('build_attempted_v2209'):_v2209_start_build()
    result=_V2203_TRACKING_RUN();result=dict(result) if isinstance(result,dict) else {}
    runtime_state=_v2209_refresh_snapshot()
    view=_v2209_cache_view();snapshot=_V2202_CACHE.get('snapshot') if view.get('ready') and isinstance(_V2202_CACHE.get('snapshot'),dict) else None
    runtime=_v2209_publish(snapshot,runtime_state)
    health=load_json(STATUS,{}) or {};health=dict(health) if isinstance(health,dict) else {}
    health.update({
        'schema':'clean_review_worker_status_v2209','version':VERSION,'build':BUILD_LABEL,'state':'running',
        'phase':str(view.get('stage') or runtime_state),'prediction_review_runtime_v2202':runtime,
        'prediction_review_snapshot_id_v2209':snapshot.get('snapshot_id') if isinstance(snapshot,dict) else None,
        'analysis_owner_v2209':'strategy_v2_outcome_status_v2133.json','health_only_status_v2209':True,
        'main_direct_ledger_scan_v2209':False,'exact_input_horizon_contract_v2206':True,
        'contract_id_v2208':V2208_CONTRACT_ID,'producer_instance_id_v2208':V2209_PROCESS_INSTANCE_ID,
        'producer_started_ts_v2208':V2209_PROCESS_STARTED_TS,'previous_process_snapshot_reused_v2208':False,
        'scan_stage_v2209':view.get('stage'),'scan_progress_rows_v2209':view.get('rows'),
        'scan_progress_bytes_v2209':view.get('bytes'),'scan_total_bytes_v2209':view.get('total_bytes'),
        'scan_progress_pct_v2209':view.get('pct'),'scan_error_stage_v2209':view.get('error_stage'),
        'scan_error_v2209':view.get('error'),'full_scan_count_v2209':view.get('full_scan_count'),
        'incremental_scan_count_v2209':view.get('incremental_scan_count'),
        'cycle_complete_v2209':bool(view.get('ready') and view.get('cycle_complete')),'cycle_complete_v2208':False,
        'auto_buy':False,
    })
    _atomic_json(STATUS,health)
    result.update({'version':VERSION,'build':BUILD_LABEL,'state':'running',
        'prediction_validation_v2202':snapshot or _v2209_placeholder_snapshot(runtime_state,view),
        'prediction_validation_v2202_runtime':runtime,'auto_buy':False})
    return result


run_once=run_once__v2209
run_once.__name__='run_once';run_once.__qualname__='run_once'


def _v2209_review_ledger_once():
    marker=BASE_DIR/'runtime'/'review_v2209_single_scan_progress_latched_error.seeded'
    if marker.exists():return
    ts=now_ts();txt=now_text(ts)
    try:
        append_jsonl(CHANGE_LEDGER,{
            'schema':'change_verify_ledger_v870','change_id':'V2209-REVIEW-SINGLE-SCAN-LIFECYCLE',
            'issue_id':'V2208-REVIEW-BUILDING-WITHOUT-PROGRESS-OR-LATCHED-ERROR','version':'v2209',
            'verify_result':'LOCAL_PASS_SERVER_CHECK','created_ts':ts,'created_at':txt,'writer':VERSION,
            'cause':'Review rebuilt the full outcome ledger after restart without publishing scan progress. A build exception was cleared by the next automatic retry, and cycle_complete stayed true while the exact snapshot was still BUILDING.',
            'fix':'Attempt one full scan per Review process, publish row/byte progress and exact failure stage, latch errors until process restart, verify the completed snapshot before PASS, set cycle_complete only after verified atomic publication, then consume appended rows incrementally.',
            'not_touched':['prediction formula/pass threshold','candidate/S1/Paper','structure/Trigger/Invalid/Target/RR','Paper execution/exit','historical ledgers','new command/Shadow','auto-buy OFF'],'auto_buy':False,
        })
        marker.parent.mkdir(parents=True,exist_ok=True);marker.write_text(txt,encoding='utf-8')
    except Exception as exc:
        try:append_error('v2209_review_ledger',exc)
        except Exception:pass
# v2245 deferred module-level call: _v2209_review_ledger_once runs after runtime identity publication.


import bisect as _v2210_bisect

# =============================================================================
# review_worker v2.090 / v2210: exact candle-time horizons and one existing
# trade_review profit/loss comparison. Recorded "first cycle after horizon"
# prices are reference-only; formula truth comes from completed candle history.
# =============================================================================
VERSION='review_worker_v2.090'
BUILD_LABEL='v2210_exact_candle_horizon_profit_loss_compare_2026-07-26'
MAIN_DEPLOY_VERSION=BUILD_LABEL
V2188_EXPECTED_CORE='strategy_v2_core_v2175'
V2188_EXPECTED_MODEL='FULL_INPUT_V2210_GRADUAL_QUALITY'
V2202_PREVIOUS_MODEL='FULL_INPUT_V2198_CONTINUATION'
V2202_CURRENT_MODEL='FULL_INPUT_V2210_GRADUAL_QUALITY'
V2210_CANDLE_CACHE=BASE_DIR/'clean_candle_cache.json'
V2210_PERFORMANCE_EPOCH=BASE_DIR/'paper_quality_rebuild_epoch_v1095.json'
V2210_FRAME_SEC={'m1':60.0,'m3':180.0,'m5':300.0,'m30':1800.0,'h1':3600.0}
V2210_HORIZON_FRAME_ORDER={
    '30m':('m1','m3','m5','m30'),
    '1h':('m1','m3','m5','m30','h1'),
    '3h':('m5','m30','h1'),
    '6h':('m5','m30','h1'),
}
_V2210_CANDLE_INDEX_CACHE={'mtime_ns':None,'index':{},'rows':0}
_V2210_ACTIVE_CANDLE_INDEX={}
_V2210_BASE_COMPACT_ROW=_v2203_compact_row
_V2210_BASE_PREPARE_ROW=_v2206_prepare_row
_V2210_BASE_BUILD_SNAPSHOT=_v2202_build_snapshot

try:
    from strategy_v2_core_v2174 import score_prediction_axes_v2198 as _v2198_score_previous
except Exception:
    _v2198_score_previous=None
try:
    from strategy_v2_core_v2175 import score_prediction_axes_v2210 as _v2198_score_current
except Exception:
    _v2198_score_current=None


def _v2203_compact_row(row):  # type: ignore[override]
    out=dict(_V2210_BASE_COMPACT_ROW(row) or {})
    if isinstance(row,dict):
        out['reference_entry']=row.get('reference_entry')
        out['entry_price']=row.get('entry_price')
        out['open_price']=row.get('open_price')
    return out


def _v2210_cache_rows(obj):
    if isinstance(obj,dict):
        for key in ('rows','items','data','cache','tickers'):
            if isinstance(obj.get(key),dict):return obj.get(key)
        return obj
    return {}


def _v2210_candle_index():
    try:mtime=V2210_CANDLE_CACHE.stat().st_mtime_ns
    except Exception:return {},0
    if _V2210_CANDLE_INDEX_CACHE.get('mtime_ns')==mtime:return _V2210_CANDLE_INDEX_CACHE.get('index') or {},int(_V2210_CANDLE_INDEX_CACHE.get('rows') or 0)
    obj=load_json(V2210_CANDLE_CACHE,{}) or {};source=_v2210_cache_rows(obj);index={};total=0
    for raw_ticker,row in source.items():
        if not isinstance(row,dict):continue
        lab=row.get('structure_lab_candles') if isinstance(row.get('structure_lab_candles'),dict) else {}
        frames=lab.get('frames') if isinstance(lab.get('frames'),dict) else {}
        t=ticker(raw_ticker or row.get('ticker'))
        if not t:continue
        parsed={}
        for frame,sec in V2210_FRAME_SEC.items():
            rows=[]
            for item in frames.get(frame) if isinstance(frames.get(frame),list) else []:
                if not isinstance(item,(list,tuple)) or len(item)<5:continue
                ts=_v2202_num(item[0]);op=_v2202_num(item[1]);cl=_v2202_num(item[2]);hi=_v2202_num(item[3]);lo=_v2202_num(item[4])
                if ts is None or None in (op,cl,hi,lo) or min(op,cl,hi,lo)<=0:continue
                if ts>10_000_000_000:ts/=1000.0
                rows.append((float(ts),float(op),float(cl),float(hi),float(lo)))
            rows.sort(key=lambda x:x[0])
            if rows:
                parsed[frame]={'rows':rows,'starts':[item[0] for item in rows],'closes':[item[0]+sec for item in rows]}
                total+=len(rows)
        if parsed:index[t]=parsed
    _V2210_CANDLE_INDEX_CACHE.update({'mtime_ns':mtime,'index':index,'rows':total})
    return index,total


def _v2210_entry_price(row):
    for value in (row.get('reference_entry'),row.get('entry_price'),row.get('open_price')):
        x=_v2202_num(value)
        if x is not None and x>0:return x
    return None


def _v2210_resolve_horizon(row,label,entry_ts):
    if entry_ts is None:return {'state':'INVALID','invalid_reason':'TIME_MISSING','source_v2210':'completed_candle_cache'}
    entry=_v2210_entry_price(row)
    if entry is None:return {'state':'INVALID','invalid_reason':'ENTRY_PRICE_MISSING','source_v2210':'completed_candle_cache'}
    frames=(_V2210_ACTIVE_CANDLE_INDEX.get(ticker(row.get('ticker'))) or {})
    target=float(entry_ts)+float(V2206_HORIZON_SEC[label])
    best_reason='CANDLE_HISTORY_MISSING'
    for frame in V2210_HORIZON_FRAME_ORDER[label]:
        frame_obj=frames.get(frame)
        if isinstance(frame_obj,dict):
            rows=frame_obj.get('rows') if isinstance(frame_obj.get('rows'),list) else []
            starts=frame_obj.get('starts') if isinstance(frame_obj.get('starts'),list) else []
            closes=frame_obj.get('closes') if isinstance(frame_obj.get('closes'),list) else []
        else:
            rows=frame_obj if isinstance(frame_obj,list) else []
            starts=[item[0] for item in rows]
            closes=[item[0]+V2210_FRAME_SEC[frame] for item in rows]
        if not rows or len(closes)!=len(rows):continue
        sec=V2210_FRAME_SEC[frame]
        selected_index=_v2210_bisect.bisect_left(closes,target)
        if selected_index>=len(rows):best_reason='TARGET_CANDLE_MISSING';continue
        selected=rows[selected_index];sampled_ts=closes[selected_index];lateness=sampled_ts-target
        if lateness>max(90.0,sec*1.50):best_reason='TARGET_CANDLE_GAP_TOO_LARGE';continue
        # Require history from the first full candle after entry through target.
        first_index=_v2210_bisect.bisect_left(starts,float(entry_ts)) if len(starts)==len(rows) else 0
        path=rows[first_index:selected_index+1]
        if not path:
            # Coarser fallback may contain the entry inside its first candle. It
            # can provide the exact horizon close, but not a fabricated path.
            close_pct=(selected[2]/entry-1.0)*100.0
            return {'state':'READY','invalid_reason':None,'close_pct':close_pct,'truth':_v2202_truth(close_pct),
                    'sampled_ts':sampled_ts,'target_ts_v2210':target,'elapsed_sec':sampled_ts-entry_ts,
                    'expected_horizon_sec':V2206_HORIZON_SEC[label],'mfe_pct':None,'mae_pct':None,'path_ready':False,
                    'source_v2210':'clean_candle_cache.completed','frame_v2210':frame,'sample_lateness_sec_v2210':lateness,
                    'entry_partial_candle_excluded_v2210':True,'recorded_tracking_sample_used_v2210':False}
        close_pct=(selected[2]/entry-1.0)*100.0
        mfe=max(0.0,max((item[3]/entry-1.0)*100.0 for item in path))
        mae=min(0.0,min((item[4]/entry-1.0)*100.0 for item in path))
        return {'state':'READY','invalid_reason':None,'close_pct':close_pct,'truth':_v2202_truth(close_pct),
                'sampled_ts':sampled_ts,'target_ts_v2210':target,'elapsed_sec':sampled_ts-entry_ts,
                'expected_horizon_sec':V2206_HORIZON_SEC[label],'mfe_pct':mfe,'mae_pct':mae,'path_ready':True,
                'source_v2210':'clean_candle_cache.completed','frame_v2210':frame,'sample_lateness_sec_v2210':lateness,
                'entry_partial_candle_excluded_v2210':True,'recorded_tracking_sample_used_v2210':False}
    return {'state':'INVALID','invalid_reason':best_reason,'close_pct':None,'truth':None,'sampled_ts':None,
            'expected_horizon_sec':V2206_HORIZON_SEC[label],'mfe_pct':None,'mae_pct':None,'path_ready':False,
            'source_v2210':'clean_candle_cache.completed','recorded_tracking_sample_used_v2210':False}


def _v2206_horizon_raw(row,label,entry_ts):  # type: ignore[override]
    return _v2210_resolve_horizon(row,label,entry_ts)


def _v2206_prepare_row(row,previous_fn,current_fn):
    if not isinstance(row,dict):return None,'ROW_NOT_OBJECT'
    key=str(row.get('event_key') or '').strip()
    if not key:return None,'EVENT_KEY_MISSING'
    seal=row.get('prediction_input_seal_v2188') if isinstance(row.get('prediction_input_seal_v2188'),dict) else {}
    axes=_v2206_dict(seal.get('axes'));conns=_v2206_dict(seal.get('connections'));exact=bool(axes and conns)
    entry_ts,entry_source=_v2206_exact_entry_ts(row,seal)
    horizons={label:_v2206_horizon_raw(row,label,entry_ts) for label in ('30m','1h','3h','6h')}
    if not any(isinstance(v,dict) for v in horizons.values()):return None,'HORIZON_RESULT_MISSING'
    model=str(row.get('prediction_model_generation') or seal.get('model_generation') or 'UNKNOWN')
    base={'event_key':key,'event_key_short':hashlib.sha256(key.encode()).hexdigest()[:10],'ticker':ticker(row.get('ticker')) or '-',
          'entry_ts':entry_ts,'entry_time_source_v2206':entry_source,'model_generation':model,
          'exact_input_ready_v2206':exact,'legacy_preseal_v2206':not exact,
          'previous_score':None,'current_score':None,'current_formula_state':None,'current_formula_pass':None,
          'current_model_generation':None,'current_contract_hash':None,'sealed_live_score':_v2202_num(seal.get('continuation_score')),
          'current_axes':{},'horizons':horizons,'score_error':None,'input_state':'READY' if exact else 'LEGACY_PRESEAL'}
    if not exact:return base,'LEGACY_PRESEAL'
    score_error=None
    try:previous=previous_fn(axes,conns) if callable(previous_fn) else {}
    except Exception as exc:previous={};score_error=f'previous:{type(exc).__name__}'
    try:current=current_fn(axes,conns) if callable(current_fn) else {}
    except Exception as exc:current={};score_error=(score_error+';' if score_error else '')+f'current:{type(exc).__name__}'
    previous=previous if isinstance(previous,dict) else {};current=current if isinstance(current,dict) else {}
    current_axes=current.get('axes') if isinstance(current.get('axes'),dict) else axes
    current_state=str(current.get('state') or '')
    current_score=_v2202_num(current.get('continuation_score'))
    current_pass=True if current_state=='CONTINUATION_FAVORED' else False if current_state else (current_score>0 if current_score is not None else None)
    base.update({'previous_score':_v2202_num(previous.get('continuation_score')),'current_score':current_score,
                 'current_formula_state':current_state or None,'current_formula_pass':current_pass,
                 'current_model_generation':str(current.get('model_generation') or V2202_CURRENT_MODEL),
                 'current_contract_hash':str(current.get('prediction_contract_hash') or current.get('contract_hash') or ''),
                 'current_axes':{str(k):_v2202_num(v) for k,v in current_axes.items()},'score_error':score_error,
                 'input_state':'SCORE_ERROR' if score_error else 'READY'})
    return base,('SCORE_ERROR' if score_error else None)



def _v2210_read_tail(path,max_bytes=12*1024*1024,max_rows=30000):
    if not path.exists():return []
    try:
        size=path.stat().st_size
        with path.open('rb') as handle:
            handle.seek(max(0,size-max_bytes));raw=handle.read()
        lines=raw.splitlines()
        if size>max_bytes and lines:lines=lines[1:]
        out=[]
        for line in lines[-max_rows:]:
            try:
                row=json.loads(line.decode('utf-8','replace'))
                if isinstance(row,dict):out.append(row)
            except Exception:pass
        return out
    except Exception:return []


def _v2210_nested(row,*paths):
    for path in paths:
        cur=row
        for key in path:
            cur=cur.get(key) if isinstance(cur,dict) else None
        if cur not in (None,''):return cur
    return None


def _v2210_trade_compare():
    rows=_v2210_read_tail(CLOSED_PATH)
    epoch=load_json(V2210_PERFORMANCE_EPOCH,{}) or {}
    epoch_id=str(epoch.get('epoch_id') or '').strip() if isinstance(epoch,dict) else ''
    samples=[]
    for row in rows:
        if str(row.get('paper_v2_generation') or row.get('strategy_generation_v2149') or '') not in ('',GENERATION):continue
        if epoch_id and str(row.get('performance_epoch_id') or '').strip()!=epoch_id:continue
        pnl=_v2202_num(row.get('pnl_pct'))
        if pnl is None:continue
        contract=row.get('trade_path_contract_v2149_at_open') if isinstance(row.get('trade_path_contract_v2149_at_open'),dict) else row.get('trade_path_contract_v2149') if isinstance(row.get('trade_path_contract_v2149'),dict) else {}
        pred=contract.get('prediction') if isinstance(contract.get('prediction'),dict) else {}
        evidence=contract.get('prediction_evidence') if isinstance(contract.get('prediction_evidence'),dict) else pred.get('evidence') if isinstance(pred.get('evidence'),dict) else {}
        fam=evidence.get('families_v2198') if isinstance(evidence.get('families_v2198'),dict) else {}
        preview=row.get('paper_execution_preview_v2149_at_open') if isinstance(row.get('paper_execution_preview_v2149_at_open'),dict) else {}
        structure=contract.get('structure') if isinstance(contract.get('structure'),dict) else {}
        entry=_v2202_num(row.get('entry_price'));invalid=_v2202_num(structure.get('execution_invalid'))
        invalid_dist=((entry-invalid)/entry*100.0) if entry and invalid and entry>invalid else None
        family_scores={name:_v2202_num((fam.get(name) or {}).get('score')) if isinstance(fam.get(name),dict) else None for name in ('trend','capital','persistence')}
        positive=sum(1 for value in family_scores.values() if value is not None and value>0.03)
        samples.append({'ticker':ticker(row.get('ticker')),'pnl':pnl,'win':pnl>0,'exit_reason':row.get('exit_reason'),
                        'score':_v2202_num(pred.get('continuation_score')),'trend':family_scores['trend'],'capital':family_scores['capital'],
                        'persistence':family_scores['persistence'],'positive_families':positive,
                        'after_cost_rr':_v2202_num(preview.get('after_cost_rr')),'entry_fraction':_v2202_num(preview.get('entry_fraction_to_t1')),
                        'roundtrip_cost':_v2202_num(preview.get('roundtrip_cost_pct')),'invalid_distance':invalid_dist,
                        'mfe':(_v2202_num(row.get('mfe_pct_v983')) if _v2202_num(row.get('mfe_pct_v983')) is not None else _v2202_num(row.get('peak_pct'))),'mae':(_v2202_num(row.get('mae_pct_v983')) if _v2202_num(row.get('mae_pct_v983')) is not None else _v2202_num(row.get('trough_pct'))),
                        'reentry':bool(row.get('reentry_after_2pct_stop_v2210'))})
    wins=[x for x in samples if x['win']];losses=[x for x in samples if not x['win']]
    def avg(group,key):
        vals=[x[key] for x in group if x.get(key) is not None]
        return round(sum(vals)/len(vals),4) if vals else None
    keys=('score','trend','capital','persistence','positive_families','after_cost_rr','entry_fraction','roundtrip_cost','invalid_distance','mfe','mae')
    win_avg={k:avg(wins,k) for k in keys};loss_avg={k:avg(losses,k) for k in keys}
    differences=[]
    for key in keys:
        if win_avg.get(key) is None or loss_avg.get(key) is None:continue
        differences.append({'factor':key,'win_avg':win_avg[key],'loss_avg':loss_avg[key],'win_minus_loss':round(win_avg[key]-loss_avg[key],4)})
    differences.sort(key=lambda x:abs(x['win_minus_loss']),reverse=True)
    def condition(name,fn):
        group=[x for x in samples if fn(x)];w=sum(1 for x in group if x['win'])
        return {'condition':name,'count':len(group),'wins':w,'losses':len(group)-w,'win_rate_pct':round(w/len(group)*100.0,2) if group else None}
    conditions=[
        condition('long_families_under_2',lambda x:x.get('positive_families',0)<2),
        condition('entry_fraction_over_0_35',lambda x:x.get('entry_fraction') is not None and x['entry_fraction']>0.35),
        condition('after_cost_rr_under_1_2',lambda x:x.get('after_cost_rr') is not None and x['after_cost_rr']<1.2),
        condition('invalid_distance_over_4pct',lambda x:x.get('invalid_distance') is not None and x['invalid_distance']>4.0),
        condition('mfe_nonpositive',lambda x:x.get('mfe') is not None and x['mfe']<=0.0),
    ]
    return {'schema':'trade_profit_loss_compare_v2210','source':'paper_v2_exact_closed_v2135 tail; Review owner',
            'performance_epoch_id':epoch_id or None,'performance_epoch_filter_applied':bool(epoch_id),
            'sample_count':len(samples),'wins':len(wins),'losses':len(losses),'win_rate_pct':round(len(wins)/len(samples)*100.0,2) if samples else None,
            'win_avg_pnl_pct':avg(wins,'pnl'),'loss_avg_pnl_pct':avg(losses,'pnl'),
            'win_averages':win_avg,'loss_averages':loss_avg,'largest_differences':differences[:8],
            'condition_results':conditions,'active_gradual_exclusions_v2210':['long_families_under_2','exact_input_missing','reentry_without_new_trigger_after_temp_stop'],
            'candidate_count_cap_used':False,'candidate_deleted':False,'auto_buy':False}


def _v2210_build_snapshot(final_selected,base_diag,source_info):
    global _V2210_ACTIVE_CANDLE_INDEX
    _V2210_ACTIVE_CANDLE_INDEX,candle_rows=_v2210_candle_index()
    snap=dict(_V2210_BASE_BUILD_SNAPSHOT(final_selected,base_diag,source_info) or {})
    h=snap.get('horizons') if isinstance(snap.get('horizons'),dict) else {}
    snap.update({'schema':'prediction_review_snapshot_v2210','owner':VERSION,'current_model':V2202_CURRENT_MODEL,
                 'previous_model':V2202_PREVIOUS_MODEL,'horizon_truth_contract_v2210':'completed candle at exact 30m/1h/3h/6h boundary; no current-price fallback',
                 'horizon_path_contract_v2210':'MFE/MAE only from completed candles inside each independent horizon',
                 'candle_cache_rows_indexed_v2210':candle_rows,'candle_cache_tickers_v2210':len(_V2210_ACTIVE_CANDLE_INDEX),
                 'recorded_first_cycle_horizon_used_for_formula_v2210':False,
                 'trade_outcome_compare_v2210':_v2210_trade_compare(),'candidate_count_cap_used_v2210':False,
                 'temporary_loss_cap_net_pct_v2210':-2.0,'auto_buy':False})
    snap['formula_ready_v2208']=bool(sum(int((h.get(label) or {}).get('exact_samples') or 0) for label in ('3h','6h'))>0)
    return snap

_v2202_build_snapshot=_v2210_build_snapshot


def _v2210_review_ledger_once():
    marker=BASE_DIR/'runtime'/'review_v2210_exact_candle_profit_loss_compare.seeded'
    if marker.exists():return
    ts=now_ts();txt=now_text(ts)
    try:
        append_jsonl(CHANGE_LEDGER,{'schema':'change_verify_ledger_v870','change_id':'V2210-EXACT-CANDLE-HORIZON-PROFIT-LOSS-COMPARE',
            'issue_id':'V2209-HORIZON-CURRENT-PRICE-AND-PROFIT-LOSS-COMPARISON-MISSING','version':'v2210','verify_result':'LOCAL_PASS_SERVER_CHECK',
            'created_ts':ts,'created_at':txt,'writer':VERSION,
            'cause':'Recorded horizon samples used the first Review cycle after a boundary, so events revisited days later reused the latest price and cumulative path as 3h/6h truth. Public metrics repeated across horizons.',
            'fix':'Resolve each horizon from completed candle history at its own boundary, calculate interval-only MFE/MAE, never fall back to current price, and append profit-vs-loss candidate traits to the existing trade_review snapshot.',
            'not_touched':['historical outcome rows','candidate deletion/count cap','new command/Shadow','structure numbers','auto-buy OFF'],'auto_buy':False})
        marker.parent.mkdir(parents=True,exist_ok=True);marker.write_text(txt,encoding='utf-8')
    except Exception as exc:append_error('v2210_review_ledger',exc)
# v2245 deferred module-level call: _v2210_review_ledger_once runs after runtime identity publication.

# =============================================================================
# review_worker v2.091 / v2211: collision-free canonical JSON publication and
# comparison-only multi-factor loss-pattern ranking. No single sign or family
# count becomes a hard candidate gate in this version.
# =============================================================================
VERSION='review_worker_v2.091'
BUILD_LABEL='v2211_atomic_status_loss_pattern_compare_2026-07-26'
MAIN_DEPLOY_VERSION=BUILD_LABEL
V2188_EXPECTED_CORE='strategy_v2_core_v2176'
V2188_EXPECTED_MODEL='FULL_INPUT_V2211_LOSS_PATTERN_COMPARE'
V2202_CURRENT_MODEL='FULL_INPUT_V2211_LOSS_PATTERN_COMPARE'
_V2211_JSON_WRITE_LOCK=threading.RLock()
_V2211_BASE_BUILD_SNAPSHOT=_v2202_build_snapshot

try:
    from strategy_v2_core_v2176 import score_prediction_axes_v2211 as _v2198_score_current
except Exception:
    _v2198_score_current=None


def _atomic_json(path:Path,obj:Any)->None:  # type: ignore[override]
    """One canonical writer lock plus a unique temp name per call.

    v2210 used only PID in the temp name, so the tracking writer and background
    scan thread could replace the same temp file. v2211 serializes publication
    and includes thread/time identity. The final file is still atomically
    replaced and no extra persistent cache or ledger is created.
    """
    path.parent.mkdir(parents=True,exist_ok=True)
    tmp=path.with_name(f'{path.name}.tmp.{os.getpid()}.{threading.get_ident()}.{time.time_ns()}')
    data=json.dumps(obj,ensure_ascii=False,separators=(',',':'))
    with _V2211_JSON_WRITE_LOCK:
        try:
            with tmp.open('x',encoding='utf-8') as handle:
                handle.write(data);handle.flush();os.fsync(handle.fileno())
            os.replace(tmp,path)
            try:
                dir_fd=os.open(str(path.parent),os.O_RDONLY)
                try:os.fsync(dir_fd)
                finally:os.close(dir_fd)
            except Exception:pass
        finally:
            try:
                if tmp.exists():tmp.unlink()
            except Exception:pass


def _v2211_trade_samples():
    rows=_v2210_read_tail(CLOSED_PATH)
    epoch=load_json(V2210_PERFORMANCE_EPOCH,{}) or {}
    epoch_id=str(epoch.get('epoch_id') or '').strip() if isinstance(epoch,dict) else ''
    samples=[]
    for row in rows:
        if not isinstance(row,dict):continue
        if str(row.get('paper_v2_generation') or row.get('strategy_generation_v2149') or '') not in ('',GENERATION):continue
        if epoch_id and str(row.get('performance_epoch_id') or '').strip()!=epoch_id:continue
        pnl=_v2202_num(row.get('pnl_pct'))
        if pnl is None:continue
        contract=row.get('trade_path_contract_v2149_at_open') if isinstance(row.get('trade_path_contract_v2149_at_open'),dict) else row.get('trade_path_contract_v2149') if isinstance(row.get('trade_path_contract_v2149'),dict) else {}
        pred=contract.get('prediction') if isinstance(contract.get('prediction'),dict) else {}
        evidence=contract.get('prediction_evidence') if isinstance(contract.get('prediction_evidence'),dict) else pred.get('evidence') if isinstance(pred.get('evidence'),dict) else {}
        fam=evidence.get('families_v2198') if isinstance(evidence.get('families_v2198'),dict) else {}
        preview=row.get('paper_execution_preview_v2149_at_open') if isinstance(row.get('paper_execution_preview_v2149_at_open'),dict) else {}
        structure=contract.get('structure') if isinstance(contract.get('structure'),dict) else {}
        entry=_v2202_num(row.get('entry_price'));invalid=_v2202_num(structure.get('execution_invalid'))
        invalid_dist=((entry-invalid)/entry*100.0) if entry and invalid and entry>invalid else None
        fs={name:_v2202_num((fam.get(name) or {}).get('score')) if isinstance(fam.get(name),dict) else None for name in ('trend','capital','persistence')}
        positive=sum(1 for value in fs.values() if value is not None and value>0.03)
        mfe=_v2202_num(row.get('mfe_pct_v983'))
        if mfe is None:mfe=_v2202_num(row.get('peak_pct'))
        mae=_v2202_num(row.get('mae_pct_v983'))
        if mae is None:mae=_v2202_num(row.get('trough_pct'))
        samples.append({'ticker':ticker(row.get('ticker')),'pnl':float(pnl),'win':float(pnl)>0,'score':_v2202_num(pred.get('continuation_score')),
                        'trend':fs['trend'],'capital':fs['capital'],'persistence':fs['persistence'],'positive_families':positive,
                        'after_cost_rr':_v2202_num(preview.get('after_cost_rr')),'entry_fraction':_v2202_num(preview.get('entry_fraction_to_t1')),
                        'roundtrip_cost':_v2202_num(preview.get('roundtrip_cost_pct')),'invalid_distance':invalid_dist,
                        'mfe':mfe,'mae':mae,'reentry':bool(row.get('reentry_after_2pct_stop_v2210') or row.get('reentry_after_2pct_stop_v2211')),
                        'exit_reason':str(row.get('exit_reason') or '')})
    return samples


def _v2211_pattern_stats(samples,name,label,fn,pre_entry_only=True):
    group=[x for x in samples if fn(x)]
    other=[x for x in samples if not fn(x)]
    wins=[x for x in group if x['win']];losses=[x for x in group if not x['win']]
    all_wins=sum(1 for x in samples if x['win']);all_losses=len(samples)-all_wins
    def avg(rows,key):
        vals=[float(x[key]) for x in rows if x.get(key) is not None]
        return round(sum(vals)/len(vals),4) if vals else None
    wr=(len(wins)/len(group)*100.0) if group else None
    other_wr=(sum(1 for x in other if x['win'])/len(other)*100.0) if other else None
    overall_wr=(all_wins/len(samples)*100.0) if samples else None
    winner_share=(len(wins)/all_wins*100.0) if all_wins else 0.0
    loser_share=(len(losses)/all_losses*100.0) if all_losses else 0.0
    avg_pnl=avg(group,'pnl')
    gap=(wr-overall_wr) if wr is not None and overall_wr is not None else None
    # A comparison candidate only. It is never applied automatically.
    evidence_ready=bool(len(group)>=8 and avg_pnl is not None and avg_pnl<0 and gap is not None and gap<=-5.0 and loser_share>winner_share)
    badness=0.0
    if evidence_ready:
        badness=round(abs(float(gap))+max(0.0,loser_share-winner_share)+min(20.0,abs(float(avg_pnl))*4.0),4)
    return {'pattern':name,'label':label,'count':len(group),'wins':len(wins),'losses':len(losses),
            'win_rate_pct':round(wr,2) if wr is not None else None,'other_win_rate_pct':round(other_wr,2) if other_wr is not None else None,
            'overall_win_rate_pct':round(overall_wr,2) if overall_wr is not None else None,
            'win_rate_gap_vs_overall_pctp':round(gap,2) if gap is not None else None,
            'avg_pnl_pct':avg_pnl,'avg_mfe_pct':avg(group,'mfe'),'avg_mae_pct':avg(group,'mae'),
            'winner_share_pct':round(winner_share,2),'loser_share_pct':round(loser_share,2),
            'pre_entry_condition_only':bool(pre_entry_only),'evidence_ready_for_user_review':evidence_ready,
            'badness_score':badness,'active_exclusion':False}


def _v2211_trade_compare():
    samples=_v2211_trade_samples()
    patterns=[
        _v2211_pattern_stats(samples,'chase_plus_low_rr','과추격 + 비용 후 RR 부족',lambda x:x.get('entry_fraction') is not None and x['entry_fraction']>0.35 and x.get('after_cost_rr') is not None and x['after_cost_rr']<1.20),
        _v2211_pattern_stats(samples,'wide_invalid_plus_low_rr','손실거리 과대 + 비용 후 RR 부족',lambda x:x.get('invalid_distance') is not None and x['invalid_distance']>4.0 and x.get('after_cost_rr') is not None and x['after_cost_rr']<1.20),
        _v2211_pattern_stats(samples,'trend_without_persistence','순간 추세 강함 + 매수 지속 약함',lambda x:x.get('trend') is not None and x['trend']>0.03 and (x.get('persistence') is None or x['persistence']<=0.03)),
        _v2211_pattern_stats(samples,'capital_without_persistence','자금유입 강함 + 매수 지속 약함',lambda x:x.get('capital') is not None and x['capital']>0.03 and (x.get('persistence') is None or x['persistence']<=0.03)),
        _v2211_pattern_stats(samples,'single_family_plus_chase','장기흐름 1개 이하 + 추격 진입',lambda x:x.get('positive_families',0)<2 and x.get('entry_fraction') is not None and x['entry_fraction']>0.25),
        _v2211_pattern_stats(samples,'weak_reentry_combo','재진입 + 지속 약함 또는 RR 부족',lambda x:x.get('reentry') and ((x.get('persistence') is None or x['persistence']<=0.03) or (x.get('after_cost_rr') is not None and x['after_cost_rr']<1.20))),
        _v2211_pattern_stats(samples,'positive_score_no_followthrough','양수 예측점수 + 수익구간 거의 없음',lambda x:x.get('score') is not None and x['score']>0 and x.get('mfe') is not None and x['mfe']<=0.10,pre_entry_only=False),
    ]
    ranked=sorted(patterns,key=lambda x:(bool(x.get('evidence_ready_for_user_review')),float(x.get('badness_score') or 0.0),int(x.get('count') or 0)),reverse=True)
    wins=sum(1 for x in samples if x['win'])
    return {'schema':'trade_profit_loss_pattern_compare_v2211','source':'current performance epoch exact CLOSED tail; Review owner',
            'sample_count':len(samples),'wins':wins,'losses':len(samples)-wins,
            'overall_win_rate_pct':round(wins/len(samples)*100.0,2) if samples else None,
            'patterns':ranked,'evidence_ready_patterns':[x.get('pattern') for x in ranked if x.get('evidence_ready_for_user_review')],
            'next_exclusion_candidate':next((x.get('pattern') for x in ranked if x.get('evidence_ready_for_user_review')),None),
            'active_candidate_exclusions_v2211':[], 'active_candidate_exclusion_count_v2211':0,
            'comparison_policy_v2211':'no single positive/negative sign gate; compare losing multi-factor combinations; user approval before activation',
            'candidate_count_cap_used_v2211':False,'candidate_rows_deleted_v2211':0,'auto_buy':False}


def _v2211_build_snapshot(final_selected,base_diag,source_info):
    snap=dict(_V2211_BASE_BUILD_SNAPSHOT(final_selected,base_diag,source_info) or {})
    snap.update({'schema':'prediction_review_snapshot_v2211','owner':VERSION,'current_model':V2202_CURRENT_MODEL,
                 'atomic_status_writer_v2211':'global lock + pid/thread/time unique temp + os.replace',
                 'status_temp_collision_fixed_v2211':True,
                 'trade_outcome_compare_v2211':_v2211_trade_compare(),
                 'active_candidate_exclusion_count_v2211':0,
                 'single_sign_candidate_gate_active_v2211':False,
                 'candidate_count_cap_used_v2211':False,'candidate_rows_deleted_v2211':0,'auto_buy':False})
    return snap


_v2202_build_snapshot=_v2211_build_snapshot


def _v2211_review_ledger_once():
    marker=BASE_DIR/'runtime'/'review_v2211_atomic_loss_pattern_compare.seeded'
    if marker.exists():return
    ts=now_ts();txt=now_text(ts)
    try:
        append_jsonl(CHANGE_LEDGER,{'schema':'change_verify_ledger_v870','change_id':'V2211-ATOMIC-STATUS-LOSS-PATTERN-COMPARE',
            'issue_id':'V2210-REVIEW-STATUS-TEMP-COLLISION','version':'v2211','verify_result':'LOCAL_PASS_SERVER_CHECK',
            'created_ts':ts,'created_at':txt,'writer':VERSION,
            'cause':'The tracking writer and background full-scan progress writer used the same OUTCOME_STATUS temp name based only on PID. One thread replaced it while the other still expected it, causing FileNotFoundError at os.replace.',
            'fix':'Serialize canonical JSON publication and use a unique PID/thread/time temp name. Keep the same final status file. Rank multi-factor losing patterns but activate zero new candidate exclusions.',
            'not_touched':['prediction weights/positive threshold','candidate deletion/count cap','structure and exit numbers','historical ledgers','new command/Shadow','auto-buy OFF'],'auto_buy':False})
        append_jsonl(ISSUE_LEDGER,{'schema':'coinbot_single_work_ledger_v870','event_type':'ISSUE','issue_id':'V2210-REVIEW-STATUS-TEMP-COLLISION',
            'status':'CHECK','title':'Review 상태파일 동시쓰기 충돌 수리','detail':'같은 PID temp를 공유하던 두 writer를 공통 잠금과 고유 temp로 수리. 서버 PASS와 단일 snapshot 확인 필요.',
            'version':'v2211','created_ts':ts,'created_at':txt,'auto_buy':False})
        marker.parent.mkdir(parents=True,exist_ok=True);marker.write_text(txt,encoding='utf-8')
    except Exception as exc:append_error('v2211_review_ledger',exc)
# v2245 deferred module-level call: _v2211_review_ledger_once runs after runtime identity publication.



# =============================================================================
# review_worker v2.092 / v2213: completed-candle list parser repair,
# preserved exact-horizon fallback, data-derived two-factor loss analysis and
# one canonical forward exclusion Shadow slot inside the existing Review owner.
# No candidate/entry/exit formula changes and no new worker/command/ledger.
# =============================================================================
VERSION='review_worker_v2.092'
BUILD_LABEL='v2213_horizon_connection_repair_single_forward_shadow_2026-07-26'
MAIN_DEPLOY_VERSION=BUILD_LABEL
V2213_SHADOW_SCHEMA='rise_prediction_single_forward_shadow_v2213'
V2213_SHADOW_STATE_KEY='rise_prediction_shadow_v2213'
V2213_RECORDED_LATE_TOLERANCE_SEC=300.0
V2213_SHADOW_MIN_GROUP=max(8,int(os.getenv('V2213_SHADOW_MIN_GROUP','8')))
_V2213_BASE_BUILD_SNAPSHOT=_v2202_build_snapshot
_V2213_BASE_RUN_ONCE=run_once
_V2213_BASE_REFRESH=_v2209_refresh_snapshot
_V2213_CANDLE_RESOLVER=_v2210_resolve_horizon
_V2213_HORIZON_SOURCE_COUNTS=Counter()
_V2213_CANDLE_PARSE_DIAG={}
_V2213_TRADE_SAMPLE_CACHE={'signature':None,'samples':[],'scan_count':0,'cache_hits':0}


def _v2213_file_sig(path:Path):
    try:
        st=path.stat();return (int(st.st_mtime_ns),int(st.st_size))
    except Exception:return (0,0)


def _v2213_cache_row_pairs(obj):
    """Accept the actual Candle writer schema: top-level rows is a list.

    Older readers also accepted ticker-keyed dicts, so both shapes remain
    readable. This repairs the v2210 zero-index bug without changing Candle.
    """
    container=obj
    if isinstance(obj,dict) and 'rows' in obj:
        container=obj.get('rows')
    if isinstance(container,list):
        out=[]
        for idx,row in enumerate(container):
            if not isinstance(row,dict):continue
            raw=row.get('ticker') or row.get('symbol') or row.get('market') or row.get('code') or idx
            out.append((raw,row))
        return out,'LIST_ROWS'
    if isinstance(container,dict):
        for key in ('items','data','cache','tickers'):
            nested=container.get(key)
            if isinstance(nested,list):
                return _v2213_cache_row_pairs({'rows':nested})[0],f'{key.upper()}_LIST'
            if isinstance(nested,dict):
                return [(k,v) for k,v in nested.items() if isinstance(v,dict)],f'{key.upper()}_DICT'
        return [(k,v) for k,v in container.items() if isinstance(v,dict)],'TICKER_DICT'
    return [],'UNSUPPORTED'


def _v2210_candle_index():  # type: ignore[override]
    global _V2213_CANDLE_PARSE_DIAG
    try:mtime=V2210_CANDLE_CACHE.stat().st_mtime_ns
    except Exception:
        _V2213_CANDLE_PARSE_DIAG={'state':'SOURCE_MISSING','shape':'MISSING','rows_seen':0,'tickers_indexed':0,'candles_indexed':0}
        return {},0
    if _V2210_CANDLE_INDEX_CACHE.get('mtime_ns')==mtime:
        return _V2210_CANDLE_INDEX_CACHE.get('index') or {},int(_V2210_CANDLE_INDEX_CACHE.get('rows') or 0)
    obj=load_json(V2210_CANDLE_CACHE,{}) or {}
    pairs,shape=_v2213_cache_row_pairs(obj)
    index={};total=0;rows_seen=0;rows_with_lab=0
    for raw_ticker,row in pairs:
        rows_seen+=1
        lab=row.get('structure_lab_candles') if isinstance(row.get('structure_lab_candles'),dict) else {}
        frames=lab.get('frames') if isinstance(lab.get('frames'),dict) else {}
        t=ticker(raw_ticker or row.get('ticker'))
        if not t or not frames:continue
        rows_with_lab+=1;parsed={}
        for frame,sec in V2210_FRAME_SEC.items():
            items=[]
            for item in frames.get(frame) if isinstance(frames.get(frame),list) else []:
                if not isinstance(item,(list,tuple)) or len(item)<5:continue
                ts=_v2202_num(item[0]);op=_v2202_num(item[1]);cl=_v2202_num(item[2]);hi=_v2202_num(item[3]);lo=_v2202_num(item[4]);vol=_v2202_num(item[5]) if len(item)>=6 else 0.0
                if ts is None or None in (op,cl,hi,lo) or min(op,cl,hi,lo)<=0:continue
                if ts>10_000_000_000:ts/=1000.0
                items.append((float(ts),float(op),float(cl),float(hi),float(lo),max(0.0,float(vol or 0.0))))
            items.sort(key=lambda x:x[0])
            if items:
                parsed[frame]={'rows':items,'starts':[item[0] for item in items],'closes':[item[0]+sec for item in items]}
                total+=len(items)
        if parsed:index[t]=parsed
    _V2210_CANDLE_INDEX_CACHE.update({'mtime_ns':mtime,'index':index,'rows':total})
    _V2213_CANDLE_PARSE_DIAG={'state':'PASS' if index else 'CHECK','shape':shape,'rows_seen':rows_seen,
        'rows_with_structure_lab':rows_with_lab,'tickers_indexed':len(index),'candles_indexed':total,
        'source_schema':obj.get('schema') if isinstance(obj,dict) else None,'rows_is_list':bool(isinstance(obj,dict) and isinstance(obj.get('rows'),list))}
    return index,total


try:_V2210_CANDLE_INDEX_CACHE.clear()
except Exception:pass


def _v2213_recorded_horizon(row,label,entry_ts):
    results=row.get('prediction_factor_results_v2188') if isinstance(row.get('prediction_factor_results_v2188'),dict) else {}
    samples=row.get('samples') if isinstance(row.get('samples'),dict) else {}
    block=results.get(label) if isinstance(results.get(label),dict) else {}
    sample=samples.get(label) if isinstance(samples.get(label),dict) else {}
    if not block and not sample:return {'state':'INVALID','invalid_reason':'RECORDED_RESULT_MISSING','source_v2213':'sealed_recorded_horizon'}
    close=_v2202_num(block.get('close_pct'))
    if close is None:close=_v2202_num(sample.get('pct'))
    sampled=_v2202_num(block.get('sampled_ts'))
    if sampled is None:sampled=_v2202_num(sample.get('sampled_ts'))
    if close is None:return {'state':'INVALID','invalid_reason':'CLOSE_MISSING','source_v2213':'sealed_recorded_horizon'}
    if entry_ts is None or sampled is None:return {'state':'INVALID','invalid_reason':'TIME_MISSING','source_v2213':'sealed_recorded_horizon'}
    expected=float(V2206_HORIZON_SEC[label]);elapsed=float(sampled)-float(entry_ts);lateness=elapsed-expected
    if elapsed<expected-2.0:
        return {'state':'INVALID','invalid_reason':'HORIZON_TIME_TOO_EARLY','sampled_ts':sampled,'elapsed_sec':elapsed,
            'source_v2213':'sealed_recorded_horizon'}
    if lateness>V2213_RECORDED_LATE_TOLERANCE_SEC:
        return {'state':'INVALID','invalid_reason':'HORIZON_TIME_TOO_LATE','sampled_ts':sampled,'elapsed_sec':elapsed,
            'sample_lateness_sec_v2213':lateness,'source_v2213':'sealed_recorded_horizon'}
    mfe=_v2202_num(block.get('mfe_pct'))
    if mfe is None:mfe=_v2202_num(sample.get('max_pct'))
    mae=_v2202_num(block.get('mae_pct'))
    if mae is None:mae=_v2202_num(sample.get('min_pct'))
    return {'state':'READY','invalid_reason':None,'close_pct':close,'truth':_v2202_truth(close),'sampled_ts':sampled,
        'elapsed_sec':elapsed,'expected_horizon_sec':expected,'mfe_pct':max(0.0,mfe) if mfe is not None else None,
        'mae_pct':min(0.0,mae) if mae is not None else None,'path_ready':bool(mfe is not None and mae is not None),
        'sample_lateness_sec_v2213':lateness,'source_v2210':'sealed_recorded_horizon_exact',
        'source_v2213':'sealed_recorded_horizon_exact','recorded_tracking_sample_used_v2210':True,
        'recorded_result_time_verified_v2213':True}


def _v2206_horizon_raw(row,label,entry_ts):  # type: ignore[override]
    candle=_V2213_CANDLE_RESOLVER(row,label,entry_ts)
    if isinstance(candle,dict) and candle.get('state')=='READY':
        _V2213_HORIZON_SOURCE_COUNTS[f'{label}:completed_candle']+=1
        return candle
    recorded=_v2213_recorded_horizon(row,label,entry_ts)
    if isinstance(recorded,dict) and recorded.get('state')=='READY':
        _V2213_HORIZON_SOURCE_COUNTS[f'{label}:sealed_recorded']+=1
        recorded['candle_fallback_reason_v2213']=candle.get('invalid_reason') if isinstance(candle,dict) else 'CANDLE_RESULT_MISSING'
        return recorded
    reason=(candle.get('invalid_reason') if isinstance(candle,dict) else None) or (recorded.get('invalid_reason') if isinstance(recorded,dict) else None) or 'HORIZON_RESULT_MISSING'
    _V2213_HORIZON_SOURCE_COUNTS[f'{label}:invalid:{reason}']+=1
    out=dict(candle) if isinstance(candle,dict) else {}
    out.update({'state':'INVALID','invalid_reason':reason,'recorded_fallback_reason_v2213':recorded.get('invalid_reason') if isinstance(recorded,dict) else None,
        'source_v2213':'completed_candle_then_time_verified_recorded'})
    return out


def _v2213_row_contract(row):
    return row.get('trade_path_contract_v2149_at_open') if isinstance(row.get('trade_path_contract_v2149_at_open'),dict) else row.get('trade_path_contract_v2149') if isinstance(row.get('trade_path_contract_v2149'),dict) else {}


def _v2213_first_num(row,*keys):
    for key in keys:
        value=_v2202_num(row.get(key))
        if value is not None:return value
    return None


def _v2213_first_ts(row,*keys):
    value=_v2213_first_num(row,*keys)
    if value is not None and value>10_000_000_000:value/=1000.0
    return value


def _v2213_trade_sample(row,closed=True):
    if not isinstance(row,dict):return None
    contract=_v2213_row_contract(row)
    pred=contract.get('prediction') if isinstance(contract.get('prediction'),dict) else {}
    evidence=contract.get('prediction_evidence') if isinstance(contract.get('prediction_evidence'),dict) else pred.get('evidence') if isinstance(pred.get('evidence'),dict) else {}
    fam=evidence.get('families_v2198') if isinstance(evidence.get('families_v2198'),dict) else {}
    preview=row.get('paper_execution_preview_v2149_at_open') if isinstance(row.get('paper_execution_preview_v2149_at_open'),dict) else {}
    structure=contract.get('structure') if isinstance(contract.get('structure'),dict) else {}
    entry=_v2202_num(row.get('entry_price'));invalid=_v2202_num(structure.get('execution_invalid'))
    invalid_dist=((entry-invalid)/entry*100.0) if entry and invalid and entry>invalid else None
    fs={name:_v2202_num((fam.get(name) or {}).get('score')) if isinstance(fam.get(name),dict) else None for name in ('trend','capital','persistence')}
    available_family_scores=[value for value in fs.values() if value is not None]
    positive=sum(1 for value in available_family_scores if value>0.03) if available_family_scores else None
    pnl=_v2213_first_num(row,'pnl_pct','net_pnl_pct','current_net_pnl_pct','current_pnl_pct','unrealized_pnl_pct')
    if closed and pnl is None:return None
    opened=_v2213_first_ts(row,'paper_v2_exact_opened_ts','opened_at','open_ts','entry_ts','created_ts')
    closed_ts=_v2213_first_ts(row,'paper_v2_exact_closed_ts','closed_at','close_ts','exit_ts','updated_ts')
    mfe=_v2213_first_num(row,'mfe_pct_v983','peak_pct','mfe_pct')
    mae=_v2213_first_num(row,'mae_pct_v983','trough_pct','mae_pct')
    decision=str(row.get('direct_decision_key') or row.get('decision_key') or row.get('candidate_decision_key') or '')
    return {'ticker':ticker(row.get('ticker')),'pnl':float(pnl) if pnl is not None else None,'win':bool(pnl is not None and pnl>0),
        'score':_v2202_num(pred.get('continuation_score')),'trend':fs['trend'],'capital':fs['capital'],'persistence':fs['persistence'],
        'positive_families':positive,'after_cost_rr':_v2202_num(preview.get('after_cost_rr')),
        'entry_fraction':_v2202_num(preview.get('entry_fraction_to_t1')),'roundtrip_cost':_v2202_num(preview.get('roundtrip_cost_pct')),
        'invalid_distance':invalid_dist,'mfe':mfe,'mae':mae,
        'reentry':bool(row.get('reentry_after_2pct_stop_v2210') or row.get('reentry_after_2pct_stop_v2211') or row.get('reentry_after_2pct_stop_v2212')),
        'opened_ts':opened,'closed_ts':closed_ts,'decision_key':decision,'exit_reason':str(row.get('exit_reason') or '')}


def _v2213_trade_samples():
    signature=(_v2213_file_sig(CLOSED_PATH),_v2213_file_sig(V2210_PERFORMANCE_EPOCH))
    if _V2213_TRADE_SAMPLE_CACHE.get('signature')==signature:
        _V2213_TRADE_SAMPLE_CACHE['cache_hits']=int(_V2213_TRADE_SAMPLE_CACHE.get('cache_hits') or 0)+1
        return _V2213_TRADE_SAMPLE_CACHE.get('samples') or []
    rows=_v2210_read_tail(CLOSED_PATH,max_bytes=64*1024*1024,max_rows=120000)
    epoch=load_json(V2210_PERFORMANCE_EPOCH,{}) or {}
    epoch_id=str(epoch.get('epoch_id') or '').strip() if isinstance(epoch,dict) else ''
    out=[]
    for row in rows:
        if not isinstance(row,dict):continue
        if str(row.get('paper_v2_generation') or row.get('strategy_generation_v2149') or '') not in ('',GENERATION):continue
        if epoch_id and str(row.get('performance_epoch_id') or '').strip()!=epoch_id:continue
        sample=_v2213_trade_sample(row,True)
        if sample:out.append(sample)
    _V2213_TRADE_SAMPLE_CACHE.update({'signature':signature,'samples':out,
        'scan_count':int(_V2213_TRADE_SAMPLE_CACHE.get('scan_count') or 0)+1,'cache_hits':0})
    return out


_v2211_trade_samples=_v2213_trade_samples


def _v2213_percentile(values,p):
    vals=sorted(float(x) for x in values if x is not None and math.isfinite(float(x)))
    if not vals:return None
    if len(vals)==1:return vals[0]
    pos=(len(vals)-1)*float(p);lo=int(math.floor(pos));hi=int(math.ceil(pos))
    if lo==hi:return vals[lo]
    return vals[lo]+(vals[hi]-vals[lo])*(pos-lo)


_V2213_FEATURE_LABELS={'score':'상승예측 점수','trend':'현재 추세','capital':'자금유입','persistence':'매수 지속',
    'positive_families':'양수 흐름 수','after_cost_rr':'비용 후 RR','entry_fraction':'추격률','roundtrip_cost':'왕복비용',
    'invalid_distance':'invalid 거리','reentry':'재진입'}


def _v2213_predicate_label(pred):
    feature=str(pred.get('feature') or '');op=str(pred.get('op') or '')
    if op=='true':return f"{_V2213_FEATURE_LABELS.get(feature,feature)} 있음"
    threshold=pred.get('threshold')
    return f"{_V2213_FEATURE_LABELS.get(feature,feature)} {op} {float(threshold):.4f}"


def _v2213_match_pred(sample,pred):
    feature=str(pred.get('feature') or '');op=str(pred.get('op') or '')
    value=sample.get(feature)
    if op=='true':return bool(value)
    if value is None:return False
    try:value=float(value);threshold=float(pred.get('threshold'))
    except Exception:return False
    if op=='<=':return value<=threshold
    if op=='>=':return value>=threshold
    return False


def _v2213_pattern_classifiable(sample,pattern):
    preds=pattern.get('predicates') if isinstance(pattern,dict) and isinstance(pattern.get('predicates'),list) else []
    if not preds:return False
    for pred in preds:
        if not isinstance(pred,dict):return False
        feature=str(pred.get('feature') or '')
        if str(pred.get('op') or '')!='true' and sample.get(feature) is None:return False
    return True


def _v2213_match_pattern(sample,pattern):
    preds=pattern.get('predicates') if isinstance(pattern,dict) and isinstance(pattern.get('predicates'),list) else []
    return bool(preds and _v2213_pattern_classifiable(sample,pattern) and all(_v2213_match_pred(sample,p) for p in preds if isinstance(p,dict)))

def _v2213_candidate_predicates(samples):
    wins=[x for x in samples if x.get('pnl') is not None and x['pnl']>0]
    losses=[x for x in samples if x.get('pnl') is not None and x['pnl']<=0]
    features=('score','trend','capital','persistence','positive_families','after_cost_rr','entry_fraction','roundtrip_cost','invalid_distance')
    out=[]
    for feature in features:
        values=[x.get(feature) for x in samples if x.get(feature) is not None]
        if len(values)<V2213_SHADOW_MIN_GROUP:continue
        wa=[x.get(feature) for x in wins if x.get(feature) is not None];la=[x.get(feature) for x in losses if x.get(feature) is not None]
        if not wa or not la:continue
        wavg=sum(float(x) for x in wa)/len(wa);lavg=sum(float(x) for x in la)/len(la)
        if abs(wavg-lavg)<1e-9:continue
        direction='high' if lavg>wavg else 'low'
        ps=(0.50,0.75) if direction=='high' else (0.50,0.25)
        op='>=' if direction=='high' else '<='
        for p in ps:
            threshold=_v2213_percentile(values,p)
            if threshold is None:continue
            pred={'feature':feature,'op':op,'threshold':round(float(threshold),6),'source_quantile':p,'direction_from_actual_loss_group_v2213':direction}
            if pred not in out:out.append(pred)
    reentry=[x for x in samples if x.get('reentry')]
    non_reentry=[x for x in samples if not x.get('reentry')]
    if len(reentry)>=V2213_SHADOW_MIN_GROUP and non_reentry:
        r_pnl=sum(float(x.get('pnl') or 0.0) for x in reentry)/len(reentry)
        n_pnl=sum(float(x.get('pnl') or 0.0) for x in non_reentry)/len(non_reentry)
        r_wr=sum(1 for x in reentry if (x.get('pnl') or 0)>0)/len(reentry)
        n_wr=sum(1 for x in non_reentry if (x.get('pnl') or 0)>0)/len(non_reentry)
        if r_pnl<n_pnl and r_wr<n_wr:
            out.append({'feature':'reentry','op':'true','threshold':None,'source_quantile':None,
                'direction_from_actual_loss_group_v2213':'true_when_reentry_actual_pnl_and_win_rate_worse'})
    return out


def _v2213_stats(rows):
    pnl=[float(x.get('pnl')) for x in rows if x.get('pnl') is not None]
    wins=[x for x in pnl if x>0];losses=[x for x in pnl if x<=0]
    return {'count':len(pnl),'wins':len(wins),'losses':len(losses),'pnl_sum_pct':round(sum(pnl),4),
        'win_rate_pct':round(len(wins)/len(pnl)*100.0,2) if pnl else None,
        'profit_sum_pct':round(sum(wins),4),'loss_sum_pct':round(sum(losses),4)}


def _v2213_evaluate_pattern(samples,preds,recent_cutoff):
    pattern={'predicates':preds}
    group=[x for x in samples if _v2213_match_pattern(x,pattern)]
    accepted=[x for x in samples if not _v2213_match_pattern(x,pattern)]
    total=_v2213_stats(samples);g=_v2213_stats(group);a=_v2213_stats(accepted)
    avoided_loss=-sum(float(x['pnl']) for x in group if x.get('pnl') is not None and x['pnl']<=0)
    harmed_profit=sum(float(x['pnl']) for x in group if x.get('pnl') is not None and x['pnl']>0)
    big_winners=[x for x in group if x.get('pnl') is not None and x['pnl']>=5.0]
    recent=[x for x in samples if (x.get('closed_ts') or x.get('opened_ts') or 0)>=recent_cutoff] if recent_cutoff else samples[-50:]
    recent_group=[x for x in recent if _v2213_match_pattern(x,pattern)]
    r_improvement=-sum(float(x['pnl']) for x in recent_group if x.get('pnl') is not None)
    total_profit=max(0.0001,float(total.get('profit_sum_pct') or 0.0))
    harm_share=harmed_profit/total_profit*100.0
    net=avoided_loss-harmed_profit
    eligible=bool(g['count']>=V2213_SHADOW_MIN_GROUP and g['losses']>=5 and net>0 and harm_share<=20.0 and len(big_winners)==0 and a['count']>=V2213_SHADOW_MIN_GROUP)
    recent_ok=bool(len(recent_group)<4 or r_improvement>=0)
    material={'predicates':preds}
    pid=hashlib.sha256(json.dumps(material,sort_keys=True,separators=(',',':')).encode()).hexdigest()[:16]
    score=net-(harmed_profit*1.5)+(max(0.0,(a.get('win_rate_pct') or 0)-(total.get('win_rate_pct') or 0))*0.15)
    return {'pattern_id':'shadow-'+pid,'label':' + '.join(_v2213_predicate_label(p) for p in preds),'predicates':preds,
        'group':g,'accepted':a,'baseline':total,'avoided_loss_pct':round(avoided_loss,4),'harmed_profit_pct':round(harmed_profit,4),
        'net_improvement_pct':round(net,4),'harmed_profit_share_pct':round(harm_share,2),'large_winner_harmed_count':len(big_winners),
        'large_winner_harmed_top':[{'ticker':x.get('ticker'),'pnl':x.get('pnl')} for x in sorted(big_winners,key=lambda x:x.get('pnl') or 0,reverse=True)[:3]],
        'recent_sample_count':len(recent),'recent_matched_count':len(recent_group),'recent_net_improvement_pct':round(r_improvement,4),
        'recent_non_worsening':recent_ok,'eligible_for_forward_shadow':eligible,'promotion_evidence_ready':bool(eligible and recent_ok),
        'rank_score_v2213':round(score,4),'active_exclusion':False,'auto_buy':False}


def _v2213_loss_pattern_analysis():
    samples=_v2213_trade_samples();wins=sum(1 for x in samples if x.get('pnl') is not None and x['pnl']>0)
    closed_times=[float(x.get('closed_ts')) for x in samples if x.get('closed_ts')]
    recent_cutoff=max(closed_times)-86400.0 if closed_times else None
    predicates=_v2213_candidate_predicates(samples);patterns=[]
    for i,left in enumerate(predicates):
        for right in predicates[i+1:]:
            if left.get('feature')==right.get('feature'):continue
            patterns.append(_v2213_evaluate_pattern(samples,[left,right],recent_cutoff))
    patterns.sort(key=lambda x:(bool(x.get('eligible_for_forward_shadow')),bool(x.get('promotion_evidence_ready')),float(x.get('rank_score_v2213') or -1e9),float(x.get('net_improvement_pct') or -1e9)),reverse=True)
    selected=next((x for x in patterns if x.get('promotion_evidence_ready')),None)
    return {'schema':'data_derived_loss_pattern_analysis_v2213','source':'current performance epoch exact CLOSED; pre-entry fields only',
        'sample_count':len(samples),'wins':wins,'losses':len(samples)-wins,'candidate_predicate_count':len(predicates),
        'tested_two_factor_patterns':len(patterns),'top_patterns':patterns[:8],
        'selected_shadow_candidate':selected,'selection_policy':'actual win/loss direction -> data quantiles -> two pre-entry factors -> avoided loss minus harmed profit',
        'post_entry_mfe_mae_used_for_selection':False,'single_factor_gate_used':False,'active_candidate_exclusions':[],
        'closed_sample_scan_count_v2213':int(_V2213_TRADE_SAMPLE_CACHE.get('scan_count') or 0),
        'closed_sample_cache_hits_v2213':int(_V2213_TRADE_SAMPLE_CACHE.get('cache_hits') or 0),
        'closed_sample_single_material_scan_v2213':True,
        'candidate_rows_deleted':0,'auto_buy':False}


def _v2213_load_shadow_state():
    state=load_json(OUTCOME_STATE,{}) or {}
    shadow=state.get(V2213_SHADOW_STATE_KEY) if isinstance(state,dict) and isinstance(state.get(V2213_SHADOW_STATE_KEY),dict) else {}
    return state,dict(shadow)


def _v2213_shadow_report(analysis,shadow):
    selected=shadow.get('contract') if isinstance(shadow.get('contract'),dict) else None
    if not selected:
        candidate=analysis.get('selected_shadow_candidate') if isinstance(analysis,dict) and isinstance(analysis.get('selected_shadow_candidate'),dict) else None
        return {'schema':V2213_SHADOW_SCHEMA,'state':'WAIT_SAFE_PATTERN' if not candidate else 'PENDING_PERSIST',
            'contract':candidate,'forward':{},'actual_entry_changed':False,'actual_exit_changed':False,'active_candidate_exclusions':[],
            'one_shadow_slot_only':True,'new_worker_created':False,'new_command_created':False,'new_ledger_created':False,'auto_buy':False}
    start=_v2202_num(shadow.get('start_ts')) or 0.0
    all_closed=_v2213_trade_samples()
    closed_missing_open_ts=sum(1 for x in all_closed if not x.get('opened_ts'))
    closed=[x for x in all_closed if x.get('opened_ts') and float(x.get('opened_ts'))>=start]
    closed_unclassifiable=[x for x in closed if not _v2213_pattern_classifiable(x,selected)]
    excluded=[x for x in closed if _v2213_match_pattern(x,selected)]
    accepted=[x for x in closed if not _v2213_match_pattern(x,selected)]
    all_open=[]
    try:
        for row in iter_open_rows():
            sample=_v2213_trade_sample(row,False)
            if sample:all_open.append(sample)
    except Exception:all_open=[]
    open_missing_open_ts=sum(1 for x in all_open if not x.get('opened_ts'))
    open_samples=[x for x in all_open if x.get('opened_ts') and float(x.get('opened_ts'))>=start]
    open_unclassifiable=[x for x in open_samples if not _v2213_pattern_classifiable(x,selected)]
    open_excluded=[x for x in open_samples if _v2213_match_pattern(x,selected)]
    base=_v2213_stats(closed);shadow_stats=_v2213_stats(accepted);excluded_stats=_v2213_stats(excluded)
    avoided=-sum(float(x['pnl']) for x in excluded if x.get('pnl') is not None and x['pnl']<=0)
    harmed=sum(float(x['pnl']) for x in excluded if x.get('pnl') is not None and x['pnl']>0)
    open_eval=[float(x['pnl']) for x in open_excluded if x.get('pnl') is not None]
    forward={'start_ts':start,'start_text':shadow.get('start_text'),'baseline_closed':base,'shadow_closed':shadow_stats,
        'decision_difference_closed':len(excluded),'excluded_actual':excluded_stats,'avoided_loss_pct':round(avoided,4),
        'harmed_profit_pct':round(harmed,4),'net_improvement_pct':round(avoided-harmed,4),
        'decision_difference_open':len(open_excluded),'excluded_open_eval_sum_pct':round(sum(open_eval),4) if open_eval else 0.0,
        'excluded_open_tickers':[x.get('ticker') for x in open_excluded[:12]],
        'closed_missing_open_ts':closed_missing_open_ts,'closed_unclassifiable':len(closed_unclassifiable),
        'open_missing_open_ts':open_missing_open_ts,'open_unclassifiable':len(open_unclassifiable),
        'classification_complete':not any((closed_missing_open_ts,len(closed_unclassifiable),open_missing_open_ts,len(open_unclassifiable))),
        'unclassifiable_policy':'count_and_keep_in_baseline_not_silently_exclude',
        'promotion_sample_ready':bool(len(excluded)>=3),'large_winner_harmed_count':sum(1 for x in excluded if (x.get('pnl') or 0)>=5.0)}
    return {'schema':V2213_SHADOW_SCHEMA,'state':'ACTIVE','contract_id':shadow.get('contract_id'),'contract':selected,
        'selected_from_snapshot_id':shadow.get('selected_from_snapshot_id'),'historical_selection':shadow.get('historical_selection'),
        'forward':forward,'actual_entry_changed':False,'actual_exit_changed':False,'active_candidate_exclusions':[],
        'one_shadow_slot_only':True,'new_worker_created':False,'new_command_created':False,'new_ledger_created':False,
        'historical_ledgers_rewritten':False,'candidate_records_preserved':True,'auto_buy':False}


def _v2210_trade_compare():  # type: ignore[override]
    samples=_v2213_trade_samples();wins=[x for x in samples if x['pnl']>0];losses=[x for x in samples if x['pnl']<=0]
    def avg(group,key):
        vals=[float(x[key]) for x in group if x.get(key) is not None]
        return round(sum(vals)/len(vals),4) if vals else None
    keys=('score','trend','capital','persistence','positive_families','after_cost_rr','entry_fraction','roundtrip_cost','invalid_distance','mfe','mae')
    win_avg={k:avg(wins,k) for k in keys};loss_avg={k:avg(losses,k) for k in keys};differences=[]
    for key in keys:
        if win_avg.get(key) is None or loss_avg.get(key) is None:continue
        differences.append({'factor':key,'win_avg':win_avg[key],'loss_avg':loss_avg[key],'win_minus_loss':round(win_avg[key]-loss_avg[key],4)})
    differences.sort(key=lambda x:abs(x['win_minus_loss']),reverse=True)
    return {'schema':'trade_profit_loss_compare_v2213','source':'paper_v2_exact_closed_v2135 current epoch; Review owner',
        'sample_count':len(samples),'wins':len(wins),'losses':len(losses),'win_rate_pct':round(len(wins)/len(samples)*100.0,2) if samples else None,
        'win_avg_pnl_pct':avg(wins,'pnl'),'loss_avg_pnl_pct':avg(losses,'pnl'),'win_averages':win_avg,'loss_averages':loss_avg,
        'largest_differences':differences[:8],'active_gradual_exclusions_v2210':[],
        'candidate_count_cap_used':False,'candidate_deleted':False,'auto_buy':False}


def _v2211_trade_compare():  # type: ignore[override]
    analysis=_v2213_loss_pattern_analysis();selected=analysis.get('selected_shadow_candidate') if isinstance(analysis,dict) else None
    return {'schema':'trade_profit_loss_pattern_compare_v2213','source':analysis.get('source'),'sample_count':analysis.get('sample_count'),
        'wins':analysis.get('wins'),'losses':analysis.get('losses'),'overall_win_rate_pct':round((analysis.get('wins') or 0)/max(1,analysis.get('sample_count') or 0)*100.0,2),
        'patterns':analysis.get('top_patterns') or [],'evidence_ready_patterns':[x.get('pattern_id') for x in (analysis.get('top_patterns') or []) if x.get('promotion_evidence_ready')],
        'next_exclusion_candidate':selected.get('pattern_id') if isinstance(selected,dict) else None,
        'active_candidate_exclusions_v2211':[],'active_candidate_exclusion_count_v2211':0,
        'comparison_policy_v2211':'data-derived two-factor pre-entry comparison; one forward Shadow; user approval before mainline activation',
        'candidate_count_cap_used_v2211':False,'candidate_rows_deleted_v2211':0,'auto_buy':False}


def _v2213_build_snapshot(final_selected,base_diag,source_info):
    _V2213_HORIZON_SOURCE_COUNTS.clear()
    snap=dict(_V2213_BASE_BUILD_SNAPSHOT(final_selected,base_diag,source_info) or {})
    analysis=_v2213_loss_pattern_analysis();state,shadow=_v2213_load_shadow_state();report=_v2213_shadow_report(analysis,shadow)
    h=snap.get('horizons') if isinstance(snap.get('horizons'),dict) else {}
    exact_3h=int((h.get('3h') or {}).get('exact_samples') or 0);exact_6h=int((h.get('6h') or {}).get('exact_samples') or 0)
    snap.update({'schema':'prediction_review_snapshot_v2213','owner':VERSION,'version':VERSION,'build':BUILD_LABEL,
        'horizon_connection_repair_v2213':{'state':'PASS' if (_V2213_CANDLE_PARSE_DIAG.get('tickers_indexed') or any('sealed_recorded' in k for k in _V2213_HORIZON_SOURCE_COUNTS)) else 'CHECK',
            'root_cause':'Candle writer rows is list; v2210 reader accepted dict only','candle_parse':dict(_V2213_CANDLE_PARSE_DIAG),
            'horizon_source_counts':dict(_V2213_HORIZON_SOURCE_COUNTS),'exact_3h':exact_3h,'exact_6h':exact_6h,
            'recorded_fallback_time_tolerance_sec':V2213_RECORDED_LATE_TOLERANCE_SEC,
            'current_price_fallback_used':False,'historical_rows_rewritten':False},
        'loss_pattern_analysis_v2213':analysis,'rise_prediction_shadow_v2213':report,
        'active_candidate_exclusion_count_v2213':0,'single_shadow_slot_v2213':True,
        'new_shadow_worker_created_v2213':False,'new_shadow_command_created_v2213':False,'new_shadow_ledger_created_v2213':False,
        'candidate_rows_deleted_v2213':0,'candidate_count_cap_used_v2213':False,'auto_buy':False})
    snap['formula_ready_v2208']=bool(exact_3h+exact_6h>0)
    return snap


_v2202_build_snapshot=_v2213_build_snapshot


def _v2213_persist_once(snapshot):
    if not isinstance(snapshot,dict):return False
    state,shadow=_v2213_load_shadow_state();changed=False
    analysis=snapshot.get('loss_pattern_analysis_v2213') if isinstance(snapshot.get('loss_pattern_analysis_v2213'),dict) else {}
    selected=analysis.get('selected_shadow_candidate') if isinstance(analysis.get('selected_shadow_candidate'),dict) else None
    if not shadow.get('contract') and selected:
        ts=now_ts();shadow={'schema':V2213_SHADOW_SCHEMA,'state':'ACTIVE','contract_id':selected.get('pattern_id'),
            'contract':selected,'selected_from_snapshot_id':snapshot.get('snapshot_id'),'historical_selection':selected,
            'start_ts':ts,'start_text':now_text(ts),'frozen_contract':True,'actual_entry_changed':False,
            'actual_exit_changed':False,'active_candidate_exclusions':[],'auto_buy':False};changed=True
    if not state.get('v2213_ledger_seeded'):
        ts=now_ts();txt=now_text(ts);ledger_ok=False
        try:
            append_jsonl(CHANGE_LEDGER,{'schema':'change_verify_ledger_v870','change_id':'V2213-HORIZON-CONNECTION-SINGLE-FORWARD-SHADOW',
                'issue_id':'V2210-CANDLE-LIST-PARSER-ZERO-INDEX','version':'v2213','verify_result':'LOCAL_PASS_SERVER_CHECK',
                'created_ts':ts,'created_at':txt,'writer':VERSION,
                'cause':'clean_candle_cache publishes rows as a list, but the v2210 Review reader only accepted a dict, producing 0 indexed candles and hiding valid 3h/6h evidence. Named hypotheses also lacked one forward real-trade comparison.',
                'fix':'Read the actual list schema, fall back only to already sealed horizon rows whose timestamps are within five minutes of the exact boundary, derive two-factor candidates from actual win/loss directions and quantiles, then freeze one forward exclusion Shadow inside the existing Review state. Mainline candidates and trades remain unchanged.',
                'not_touched':['prediction formula/weights/positive threshold','candidate/S1/Paper entry','Trigger/Invalid/Target/RR','exit contract','historical ledgers','new worker/command/ledger','auto-buy OFF'],'auto_buy':False})
            append_jsonl(ISSUE_LEDGER,{'schema':'coinbot_single_work_ledger_v870','event_type':'ISSUE','issue_id':'V2210-CANDLE-LIST-PARSER-ZERO-INDEX',
                'status':'CHECK','title':'상승예측 완료봉 0행 연결 수리와 단일 Shadow','detail':'리스트형 완료봉을 정상 인덱싱하고 시간검증된 기존 결과를 복구한다. 실제 거래를 바꾸지 않는 수정안 1개 Shadow는 서버 표본 확인 후 판정한다.',
                'version':'v2213','created_ts':ts,'created_at':txt,'auto_buy':False})
            ledger_ok=True
        except Exception as exc:append_error('v2213_ledger_seed',exc)
        if ledger_ok:
            state['v2213_ledger_seeded']=True;changed=True
    if shadow:
        state[V2213_SHADOW_STATE_KEY]=shadow
    if changed:
        state['version_v2213']=VERSION;state['build_v2213']=BUILD_LABEL;state['updated_ts_v2213']=now_ts();state['auto_buy']=False
        _atomic_json(OUTCOME_STATE,state)
    return changed


def _v2213_refresh_snapshot(force=False):
    sig=(_v2213_file_sig(CLOSED_PATH),_v2213_file_sig(OPEN_PATH),_v2213_file_sig(V2210_CANDLE_CACHE))
    with _V2202_LOCK:
        if _V2202_CACHE.get('material_signature_v2213')!=sig:
            _V2202_CACHE['material_signature_v2213']=sig
            _V2202_CACHE['state_mtime_ns']=-1
    return _V2213_BASE_REFRESH(force)


_v2202_refresh_snapshot=_v2213_refresh_snapshot


def run_once__v2213():
    result=_V2213_BASE_RUN_ONCE();result=dict(result) if isinstance(result,dict) else {}
    snap=_V2202_CACHE.get('snapshot') if isinstance(_V2202_CACHE.get('snapshot'),dict) else None
    changed=_v2213_persist_once(snap)
    if changed and isinstance(snap,dict):
        state,shadow=_v2213_load_shadow_state();analysis=snap.get('loss_pattern_analysis_v2213') if isinstance(snap.get('loss_pattern_analysis_v2213'),dict) else {}
        snap=dict(snap);snap['rise_prediction_shadow_v2213']=_v2213_shadow_report(analysis,shadow)
        with _V2202_LOCK:_V2202_CACHE['snapshot']=snap
        try:_v2209_publish(snap,'READY')
        except Exception:pass
    health=load_json(STATUS,{}) or {};health=dict(health) if isinstance(health,dict) else {}
    report=(snap or {}).get('rise_prediction_shadow_v2213') if isinstance((snap or {}).get('rise_prediction_shadow_v2213'),dict) else {}
    health.update({'schema':'clean_review_worker_status_v2213','version':VERSION,'build':BUILD_LABEL,'phase':'horizon_connection_repair_single_forward_shadow',
        'horizon_connection_repair_v2213':(snap or {}).get('horizon_connection_repair_v2213'),
        'rise_prediction_shadow_state_v2213':report.get('state'),'rise_prediction_shadow_contract_v2213':report.get('contract_id') or ((report.get('contract') or {}).get('pattern_id') if isinstance(report.get('contract'),dict) else None),
        'active_candidate_exclusions_v2213':0,'actual_entry_changed_v2213':False,'actual_exit_changed_v2213':False,'auto_buy':False})
    _atomic_json(STATUS,health)
    result.update({'version':VERSION,'build':BUILD_LABEL,'prediction_validation_v2202':snap,'auto_buy':False})
    return result


run_once=run_once__v2213
run_once.__name__='run_once';run_once.__qualname__='run_once'


# =============================================================================
# Review v2.093 / v2214: exact factor material-vs-interpretation audit.
# Compare the sealed raw axis with the currently corrected axis on the same
# exact event and same 30m/1h/3h/6h completed-candle truth. Classify direct,
# reversed, overheat, delayed/horizon-split and materially weak inputs.
# Existing v2213 Shadow is preserved; no formula, gate, candidate or trade change.
# =============================================================================
VERSION='review_worker_v2.093'
BUILD_LABEL='v2214_factor_material_interpretation_shape_audit_2026-07-26'
MAIN_DEPLOY_VERSION=BUILD_LABEL
_V2214_BASE_BUILD_SNAPSHOT=_v2202_build_snapshot
_V2214_BASE_PREPARE_ROW=_v2206_prepare_row
_V2214_BASE_RUN_ONCE=run_once
_V2214_FACTOR_COLLECTOR=None
V2214_FACTOR_MIN_SIDE=max(30,int(os.getenv('V2214_FACTOR_MIN_SIDE','30')))
V2214_FACTOR_LABELS={
    'relative_strength_level':'상대강도','relative_strength_delta':'상대강도 변화',
    'relative_strength_velocity':'상대강도 속도','money_flow_level':'자금유입',
    'money_flow_delta':'자금유입 변화','money_flow_velocity':'자금유입 속도',
    'buy_sustain_level':'매수 지속','trade_intensity_delta':'체결 변화',
    'orderflow_velocity':'체결 속도','sell_pressure_level':'매도압력',
    'sell_pressure':'매도압력','ask_wall_pressure':'매도벽 압력',
    'leader_persistence':'주도 알트 지속','market_liquidity_regime':'시장 유동성',
    'buy_ratio_level':'공격매수 비율','momentum_level':'현재 모멘텀',
    'momentum_consistency':'모멘텀 지속','micro_acceleration':'초단기 가속',
    'market_breadth_velocity':'시장 확산 속도','market_risk':'시장 위험',
    'btc_direction':'비트코인 방향','market_breadth':'시장 확산',
}
V2214_FACTOR_ORDER=tuple(V2214_FACTOR_LABELS)
V2214_BIN_ORDER=('NEG_STRONG','NEG','NEUTRAL','POS','POS_STRONG')
V2214_BIN_LABELS={'NEG_STRONG':'강한 음수','NEG':'음수','NEUTRAL':'중립','POS':'양수','POS_STRONG':'강한 양수'}


def _v2214_bin(value):
    value=_v2202_num(value)
    if value is None:return None
    if value<=-0.30:return 'NEG_STRONG'
    if value<=-0.12:return 'NEG'
    if value<0.12:return 'NEUTRAL'
    if value<0.30:return 'POS'
    return 'POS_STRONG'


def _v2214_empty_stat():
    return {'n':0,'up':0,'down':0,'flat':0,'close_sum':0.0,'close_n':0,'mfe_sum':0.0,'mfe_n':0,'mae_sum':0.0,'mae_n':0}


def _v2214_add_stat(stat,block):
    stat['n']+=1
    truth=str(block.get('truth') or '')
    if truth=='UP':stat['up']+=1
    elif truth=='DOWN':stat['down']+=1
    else:stat['flat']+=1
    close=_v2202_num(block.get('close_pct'))
    if close is not None:stat['close_sum']+=float(close);stat['close_n']+=1
    mfe=_v2202_num(block.get('mfe_pct'))
    if mfe is not None:stat['mfe_sum']+=float(mfe);stat['mfe_n']+=1
    mae=_v2202_num(block.get('mae_pct'))
    if mae is not None:stat['mae_sum']+=float(mae);stat['mae_n']+=1


def _v2214_merge_stats(items):
    out=_v2214_empty_stat()
    for item in items:
        for key in out:out[key]+=item.get(key,0)
    return out


def _v2214_rate(stat):
    den=int(stat.get('up') or 0)+int(stat.get('down') or 0)
    return round(int(stat.get('up') or 0)/den*100.0,2) if den else None


def _v2214_avg(stat,key,nkey):
    n=int(stat.get(nkey) or 0)
    return round(float(stat.get(key) or 0.0)/n,4) if n else None


def _v2214_public_stat(stat):
    return {'n':int(stat.get('n') or 0),'up':int(stat.get('up') or 0),'down':int(stat.get('down') or 0),'flat':int(stat.get('flat') or 0),
        'up_rate_pct':_v2214_rate(stat),'avg_close_pct':_v2214_avg(stat,'close_sum','close_n'),
        'avg_mfe_pct':_v2214_avg(stat,'mfe_sum','mfe_n'),'avg_mae_pct':_v2214_avg(stat,'mae_sum','mae_n')}


class _V2214FactorCollector:
    def __init__(self):
        self.events=0;self.exact_events=0;self.score_errors=0
        self.raw_missing=Counter();self.corrected_missing=Counter()
        self.stats={kind:{name:{h:{b:_v2214_empty_stat() for b in V2214_BIN_ORDER} for h in ('30m','1h','3h','6h')}
                          for name in V2214_FACTOR_ORDER} for kind in ('raw','corrected')}
    def consume(self,row,event):
        self.events+=1
        if not isinstance(event,dict) or not event.get('exact_input_ready_v2206'):return
        self.exact_events+=1
        if event.get('score_error'):self.score_errors+=1
        seal=row.get('prediction_input_seal_v2188') if isinstance(row,dict) and isinstance(row.get('prediction_input_seal_v2188'),dict) else {}
        raw=seal.get('axes') if isinstance(seal.get('axes'),dict) else {}
        corrected=event.get('current_axes') if isinstance(event.get('current_axes'),dict) else {}
        horizons=event.get('horizons') if isinstance(event.get('horizons'),dict) else {}
        for kind,axes in (('raw',raw),('corrected',corrected)):
            for name in V2214_FACTOR_ORDER:
                value=_v2202_num(axes.get(name))
                bucket=_v2214_bin(value)
                if bucket is None:
                    (self.raw_missing if kind=='raw' else self.corrected_missing)[name]+=1;continue
                for h in ('30m','1h','3h','6h'):
                    block=horizons.get(h) if isinstance(horizons.get(h),dict) else None
                    if not isinstance(block,dict) or block.get('state')!='READY' or block.get('truth') not in ('UP','DOWN','FLAT'):continue
                    _v2214_add_stat(self.stats[kind][name][h][bucket],block)


def _v2214_monotonic_score(bin_rows):
    vals=[]
    for i,key in enumerate(V2214_BIN_ORDER):
        row=bin_rows.get(key) or {};rate=row.get('up_rate_pct')
        if rate is not None and int(row.get('n') or 0)>=V2214_FACTOR_MIN_SIDE:vals.append((i,float(rate)))
    if len(vals)<2:return None
    pos=neg=0
    for i in range(len(vals)):
        for j in range(i+1,len(vals)):
            delta=vals[j][1]-vals[i][1]
            if delta>1.0:pos+=1
            elif delta<-1.0:neg+=1
    den=pos+neg
    return round((pos-neg)/den,3) if den else 0.0


def _v2214_shape(raw_bins):
    bins={key:_v2214_public_stat(raw_bins[key]) for key in V2214_BIN_ORDER}
    low=_v2214_public_stat(_v2214_merge_stats([raw_bins['NEG_STRONG'],raw_bins['NEG']]))
    high=_v2214_public_stat(_v2214_merge_stats([raw_bins['POS'],raw_bins['POS_STRONG']]))
    neutral=bins['NEUTRAL'];moderate=bins['POS'];extreme=bins['POS_STRONG']
    comparable=bool(low['n']>=V2214_FACTOR_MIN_SIDE and high['n']>=V2214_FACTOR_MIN_SIDE and low['up_rate_pct'] is not None and high['up_rate_pct'] is not None)
    uplift=round(float(high['up_rate_pct'])-float(low['up_rate_pct']),2) if comparable else None
    close_delta=round(float(high['avg_close_pct'])-float(low['avg_close_pct']),4) if comparable and high['avg_close_pct'] is not None and low['avg_close_pct'] is not None else None
    monotonic=_v2214_monotonic_score(bins)
    overheat=False
    if moderate['n']>=V2214_FACTOR_MIN_SIDE and extreme['n']>=V2214_FACTOR_MIN_SIDE and moderate['up_rate_pct'] is not None and extreme['up_rate_pct'] is not None:
        overheat=bool(float(moderate['up_rate_pct'])-float(extreme['up_rate_pct'])>=5.0 or
                      (moderate['avg_close_pct'] is not None and extreme['avg_close_pct'] is not None and float(moderate['avg_close_pct'])-float(extreme['avg_close_pct'])>=0.40))
    if not comparable:shape='SOURCE_MISSING'
    elif overheat and uplift>-6.0:shape='OVERHEAT'
    elif uplift>=5.0 and (close_delta is None or close_delta>=0.20) and (monotonic is None or monotonic>=0):shape='DIRECT'
    elif uplift<=-5.0 and (close_delta is None or close_delta<=-0.20) and (monotonic is None or monotonic<=0):shape='REVERSED'
    elif abs(uplift)<3.0 and (close_delta is None or abs(close_delta)<0.20):shape='WEAK'
    else:shape='MIXED'
    return {'shape':shape,'bins':bins,'low':low,'high':high,'high_minus_low_up_rate_pp':uplift,
        'high_minus_low_avg_close_pct':close_delta,'monotonic_score':monotonic,'overheat_detected':overheat,
        'minimum_side_sample':V2214_FACTOR_MIN_SIDE}


def _v2214_long_shape(shapes):
    s3=str((shapes.get('3h') or {}).get('shape') or 'SOURCE_MISSING');s6=str((shapes.get('6h') or {}).get('shape') or 'SOURCE_MISSING')
    if s3==s6:return s3
    if 'SOURCE_MISSING' in (s3,s6):return s6 if s3=='SOURCE_MISSING' else s3
    if {s3,s6}<={'DIRECT','OVERHEAT'}:return 'OVERHEAT' if 'OVERHEAT' in (s3,s6) else 'DIRECT'
    if {s3,s6}<={'WEAK','MIXED'}:return 'WEAK'
    return 'HORIZON_SPLIT'


def _v2214_effect(shapes,h):
    value=(shapes.get(h) or {}).get('high_minus_low_up_rate_pp')
    return float(value) if value is not None else None


def _v2214_factor_verdict(raw_shapes,corr_shapes):
    raw_long=_v2214_long_shape(raw_shapes);corr_long=_v2214_long_shape(corr_shapes)
    raw_eff=[x for x in (_v2214_effect(raw_shapes,'3h'),_v2214_effect(raw_shapes,'6h')) if x is not None]
    cor_eff=[x for x in (_v2214_effect(corr_shapes,'3h'),_v2214_effect(corr_shapes,'6h')) if x is not None]
    raw_mean=sum(raw_eff)/len(raw_eff) if raw_eff else None;cor_mean=sum(cor_eff)/len(cor_eff) if cor_eff else None
    short=[x for x in (_v2214_effect(corr_shapes,'30m'),_v2214_effect(corr_shapes,'1h')) if x is not None]
    short_mean=sum(short)/len(short) if short else None
    delayed=bool(short_mean is not None and cor_mean is not None and short_mean<=1.0 and cor_mean>=5.0)
    short_only=bool(short_mean is not None and cor_mean is not None and short_mean>=5.0 and cor_mean<=1.0)
    if raw_long in ('DIRECT','OVERHEAT') and corr_long in ('REVERSED','WEAK','MIXED','HORIZON_SPLIT') and raw_mean is not None and cor_mean is not None and raw_mean-cor_mean>=5.0:
        verdict='INTERPRETATION_DAMAGED';easy='원재료는 의미가 있는데 현재 보정·해석이 약화시킴';priority=100
    elif raw_long in ('WEAK','MIXED','HORIZON_SPLIT') and corr_long in ('WEAK','MIXED','HORIZON_SPLIT'):
        verdict='MATERIAL_WEAK';easy='원재료와 보정값 모두 예측력이 약함';priority=90
    elif raw_long=='REVERSED' and corr_long=='REVERSED':
        verdict='DIRECTION_REVERSED';easy='원재료부터 현재 예상 방향과 반대로 움직임';priority=95
    elif corr_long=='OVERHEAT':
        verdict='OVERHEAT_NONLINEAR';easy='강할수록 좋은 값이 아니라 중간은 좋고 과도하면 나빠짐';priority=85
    elif delayed:
        verdict='DELAYED_LONG_ONLY';easy='짧게는 약하지만 3~6시간에서 뒤늦게 의미가 생김';priority=75
    elif short_only:
        verdict='SHORT_ONLY';easy='30분·1시간에는 의미가 있지만 3~6시간 재료로는 약함';priority=80
    elif raw_long in ('REVERSED','WEAK','MIXED') and corr_long in ('DIRECT','OVERHEAT'):
        verdict='CORRECTION_HELPED';easy='원재료는 약하지만 현재 보정이 예측력을 살림';priority=30
    elif corr_long=='DIRECT':
        verdict='DIRECT_USEFUL';easy='현재 방향대로 높을수록 3~6시간 결과가 좋아짐';priority=20
    elif corr_long=='REVERSED':
        verdict='CORRECTED_REVERSED';easy='보정된 값이 현재 예상과 반대로 움직임';priority=92
    elif corr_long=='SOURCE_MISSING':
        verdict='SOURCE_MISSING';easy='판정할 표본이 부족함';priority=10
    else:
        verdict='HORIZON_MIXED';easy='3시간과 6시간의 작동 방향이 서로 다름';priority=70
    action={'INTERPRETATION_DAMAGED':'보정식·부호·결합순서 우선 점검','MATERIAL_WEAK':'가중치 제외 또는 진단전용 검토',
        'DIRECTION_REVERSED':'원천값 의미·부호·기준점 점검','OVERHEAT_NONLINEAR':'단순 양수 가점 대신 적정구간/과열구간 분리',
        'DELAYED_LONG_ONLY':'3~6시간 전용으로 분리','SHORT_ONLY':'진입 타이밍 보조로만 분리','CORRECTION_HELPED':'현 보정 유지 후보',
        'DIRECT_USEFUL':'현 방향 유지 후보','CORRECTED_REVERSED':'보정 부호·임계값 우선 점검','HORIZON_MIXED':'시간대별 분리 필요',
        'SOURCE_MISSING':'자료 owner/source 확인'}[verdict]
    return {'verdict':verdict,'easy_reason':easy,'recommended_action':action,'priority':priority,
        'raw_long_shape':raw_long,'corrected_long_shape':corr_long,
        'raw_long_effect_pp':round(raw_mean,2) if raw_mean is not None else None,
        'corrected_long_effect_pp':round(cor_mean,2) if cor_mean is not None else None,
        'corrected_short_effect_pp':round(short_mean,2) if short_mean is not None else None,
        'delayed_long_only':delayed,'short_only':short_only}


def _v2214_finalize_factor_audit(collector):
    rows=[];counts=Counter()
    for name in V2214_FACTOR_ORDER:
        raw_shapes={h:_v2214_shape(collector.stats['raw'][name][h]) for h in ('30m','1h','3h','6h')}
        corr_shapes={h:_v2214_shape(collector.stats['corrected'][name][h]) for h in ('30m','1h','3h','6h')}
        verdict=_v2214_factor_verdict(raw_shapes,corr_shapes);counts[verdict['verdict']]+=1
        rows.append({'name':name,'label':V2214_FACTOR_LABELS.get(name,name),'raw':raw_shapes,'corrected':corr_shapes,
            **verdict,'raw_missing_events':int(collector.raw_missing.get(name) or 0),
            'corrected_missing_events':int(collector.corrected_missing.get(name) or 0)})
    rows.sort(key=lambda x:(int(x.get('priority') or 0),abs(float(x.get('corrected_long_effect_pp') or 0.0))),reverse=True)
    actionable=[x for x in rows if x.get('verdict') in ('INTERPRETATION_DAMAGED','MATERIAL_WEAK','DIRECTION_REVERSED','CORRECTED_REVERSED','OVERHEAT_NONLINEAR','SHORT_ONLY','HORIZON_MIXED')]
    return {'schema':'factor_material_interpretation_shape_audit_v2214','state':'READY' if collector.exact_events else 'SOURCE_MISSING',
        'owner':VERSION,'event_rows_seen':collector.events,'exact_events_seen':collector.exact_events,'score_error_events':collector.score_errors,
        'truth_contract':'same exact event + same completed candle close/MFE/MAE; raw sealed axis vs current corrected axis',
        'bin_contract':'<=-0.30, -0.30~-0.12, -0.12~0.12, 0.12~0.30, >=0.30; no current-price substitution',
        'classification_contract':'direct/reversed/overheat/weak/horizon split; descriptive audit only, no formula change',
        'verdict_counts':dict(counts),'factors':rows,'top_actionable':actionable[:8],
        'formula_changed':False,'weights_changed':False,'positive_threshold_changed':False,'shadow_contract_reset':False,
        'candidate_rows_deleted':0,'active_candidate_exclusions':[],'historical_rows_rewritten':False,'auto_buy':False}


def _v2214_prepare_row(row,previous_fn,current_fn):
    event,reason=_V2214_BASE_PREPARE_ROW(row,previous_fn,current_fn)
    collector=_V2214_FACTOR_COLLECTOR
    if collector is not None:
        try:collector.consume(row,event)
        except Exception as exc:append_error('v2214_factor_collect',exc)
    return event,reason


_v2206_prepare_row=_v2214_prepare_row


def _v2214_build_snapshot(final_selected,base_diag,source_info):
    global _V2214_FACTOR_COLLECTOR
    collector=_V2214FactorCollector();_V2214_FACTOR_COLLECTOR=collector
    try:snap=dict(_V2214_BASE_BUILD_SNAPSHOT(final_selected,base_diag,source_info) or {})
    finally:_V2214_FACTOR_COLLECTOR=None
    audit=_v2214_finalize_factor_audit(collector)
    snap.update({'schema':'prediction_review_snapshot_v2214','owner':VERSION,'version':VERSION,'build':BUILD_LABEL,
        'factor_material_audit_v2214':audit,'factor_formula_change_v2214':False,'factor_shadow_reset_v2214':False,
        'active_candidate_exclusion_count_v2214':0,'candidate_rows_deleted_v2214':0,'auto_buy':False})
    return snap


_v2202_build_snapshot=_v2214_build_snapshot


def _v2214_seed_ledger(snapshot):
    state=load_json(OUTCOME_STATE,{}) or {};state=dict(state) if isinstance(state,dict) else {}
    if state.get('v2214_ledger_seeded'):return False
    ts=now_ts();txt=now_text(ts);ok=False
    try:
        append_jsonl(CHANGE_LEDGER,{'schema':'change_verify_ledger_v870','change_id':'V2214-FACTOR-MATERIAL-INTERPRETATION-SHAPE-AUDIT',
            'issue_id':'RISE-PREDICTION-MATERIAL-VS-INTERPRETATION-2214','version':'v2214','verify_result':'LOCAL_PASS_SERVER_CHECK',
            'created_ts':ts,'created_at':txt,'writer':VERSION,
            'cause':'Exact results proved that a higher aggregate score did not monotonically improve 3h/6h outcomes, but prior output could not distinguish weak source material from a damaged correction, reversed meaning, overheat or horizon mismatch.',
            'fix':'On the same exact event and completed-candle truth, compare each sealed raw axis with its current corrected axis across fixed sign/strength bins and 30m/1h/3h/6h. Classify direct, reversed, overheat, weak, delayed and horizon-split behavior without changing the formula or the existing v2213 Shadow.',
            'not_touched':['prediction formula/weights/positive threshold','v2213 Shadow contract/start/sample','candidate/S1/Paper','structure/Trigger/Invalid/Target/RR','entry/exit','historical ledgers','new worker/command/ledger','auto-buy OFF'],'auto_buy':False})
        append_jsonl(ISSUE_LEDGER,{'schema':'coinbot_single_work_ledger_v870','event_type':'ISSUE','issue_id':'RISE-PREDICTION-MATERIAL-VS-INTERPRETATION-2214',
            'status':'CHECK','title':'상승예측 재료 자체와 해석 오류 분리','detail':'원시 봉인값과 현재 보정값을 같은 exact 결과로 비교해 반전·과열·지연·무효 재료를 구분한다. 본선과 기존 Shadow는 변경하지 않는다.',
            'version':'v2214','created_ts':ts,'created_at':txt,'auto_buy':False});ok=True
    except Exception as exc:append_error('v2214_ledger_seed',exc)
    if ok:
        state['v2214_ledger_seeded']=True;state['version_v2214']=VERSION;state['build_v2214']=BUILD_LABEL;state['updated_ts_v2214']=ts;state['auto_buy']=False
        _atomic_json(OUTCOME_STATE,state)
    return ok


def run_once__v2214():
    result=_V2214_BASE_RUN_ONCE();result=dict(result) if isinstance(result,dict) else {}
    snap=_V2202_CACHE.get('snapshot') if isinstance(_V2202_CACHE.get('snapshot'),dict) else None
    if isinstance(snap,dict):_v2214_seed_ledger(snap)
    health=load_json(STATUS,{}) or {};health=dict(health) if isinstance(health,dict) else {}
    audit=(snap or {}).get('factor_material_audit_v2214') if isinstance((snap or {}).get('factor_material_audit_v2214'),dict) else {}
    health.update({'schema':'clean_review_worker_status_v2214','version':VERSION,'build':BUILD_LABEL,
        'phase':'factor_material_interpretation_shape_audit','factor_material_audit_state_v2214':audit.get('state'),
        'factor_exact_events_v2214':int(audit.get('exact_events_seen') or 0),'v2213_shadow_preserved_v2214':True,
        'active_candidate_exclusions_v2214':0,'actual_entry_changed_v2214':False,'actual_exit_changed_v2214':False,'auto_buy':False})
    _atomic_json(STATUS,health)
    result.update({'version':VERSION,'build':BUILD_LABEL,'prediction_validation_v2202':snap,'auto_buy':False})
    return result


run_once=run_once__v2214
run_once.__name__='run_once';run_once.__qualname__='run_once'



# =============================================================================
# Review v2.094 / v2215: canonical role relocation exact replay.
# One existing Review scan compares unchanged mainline vs Core v2177 relocated
# replay on the same sealed raw axes and same completed-candle truth.
# Existing v2213 Shadow remains untouched; no live formula or gate activation.
# =============================================================================
VERSION='review_worker_v2.094'
BUILD_LABEL='v2215_canonical_factor_role_relocation_exact_replay_2026-07-26'
MAIN_DEPLOY_VERSION=BUILD_LABEL
V2188_EXPECTED_CORE='strategy_v2_core_v2177'
V2188_EXPECTED_MODEL='FULL_INPUT_V2211_LOSS_PATTERN_COMPARE'
V2202_CURRENT_MODEL='FULL_INPUT_V2211_LOSS_PATTERN_COMPARE'
_V2215_BASE_BUILD_SNAPSHOT=_v2202_build_snapshot
_V2215_BASE_PREPARE_ROW=_v2206_prepare_row
_V2215_BASE_RUN_ONCE=run_once
_V2215_REPLAY_COLLECTOR=None

try:
    from strategy_v2_core_v2177 import (score_prediction_axes_v2211 as _v2198_score_current,
        score_prediction_axes_v2215_relocated_replay as _v2215_relocated_score,
        validate_factor_role_contract_v2215 as _v2215_validate_role_contract,
        V2215_FACTOR_ROLE_CONTRACT as _V2215_ROLE_CONTRACT)
except Exception:
    _v2215_relocated_score=None;_v2215_validate_role_contract=None;_V2215_ROLE_CONTRACT={}


class _V2215ReplayCollector:
    def __init__(self):
        self.events=0;self.exact_events=0;self.replay_errors=0;self.score_missing=0
        self.h={label:{'current_pass':_v2214_empty_stat(),'relocated_pass':_v2214_empty_stat(),
            'current_only':_v2214_empty_stat(),'relocated_only':_v2214_empty_stat(),'both':_v2214_empty_stat(),'neither':_v2214_empty_stat(),
            'saved_downs':0,'lost_ups':0,'recovered_ups':0,'new_downs':0} for label in ('30m','1h','3h','6h')}
    def consume(self,row,event):
        self.events+=1
        if not isinstance(event,dict) or not event.get('exact_input_ready_v2206'):return
        self.exact_events+=1
        seal=row.get('prediction_input_seal_v2188') if isinstance(row,dict) and isinstance(row.get('prediction_input_seal_v2188'),dict) else {}
        axes=seal.get('axes') if isinstance(seal.get('axes'),dict) else {}
        connections=seal.get('connections') if isinstance(seal.get('connections'),dict) else {}
        try:replay=_v2215_relocated_score(axes,connections) if callable(_v2215_relocated_score) else {}
        except Exception:
            self.replay_errors+=1;return
        current=_v2202_num(event.get('current_score'));relocated=_v2202_num(replay.get('continuation_score')) if isinstance(replay,dict) else None
        if current is None or relocated is None:self.score_missing+=1;return
        cp=current>0.0;rp=relocated>0.0
        horizons=event.get('horizons') if isinstance(event.get('horizons'),dict) else {}
        for label in ('30m','1h','3h','6h'):
            block=horizons.get(label) if isinstance(horizons.get(label),dict) else None
            if not isinstance(block,dict) or block.get('state')!='READY' or block.get('truth') not in ('UP','DOWN','FLAT'):continue
            if cp:_v2214_add_stat(self.h[label]['current_pass'],block)
            if rp:_v2214_add_stat(self.h[label]['relocated_pass'],block)
            bucket='both' if cp and rp else 'current_only' if cp else 'relocated_only' if rp else 'neither'
            _v2214_add_stat(self.h[label][bucket],block)
            truth=str(block.get('truth') or '')
            if cp and not rp:
                if truth=='DOWN':self.h[label]['saved_downs']+=1
                elif truth=='UP':self.h[label]['lost_ups']+=1
            elif rp and not cp:
                if truth=='UP':self.h[label]['recovered_ups']+=1
                elif truth=='DOWN':self.h[label]['new_downs']+=1


def _v2215_finalize_replay(collector):
    validation=_v2215_validate_role_contract() if callable(_v2215_validate_role_contract) else {'state':'FAIL','errors':['CORE_IMPORT_FAILED']}
    horizons={}
    for label,data in collector.h.items():
        current=_v2214_public_stat(data['current_pass']);relocated=_v2214_public_stat(data['relocated_pass'])
        saved=int(data['saved_downs']);lost=int(data['lost_ups']);recovered=int(data['recovered_ups']);new_down=int(data['new_downs'])
        horizons[label]={'current_pass':current,'relocated_pass':relocated,
            'current_only':_v2214_public_stat(data['current_only']),'relocated_only':_v2214_public_stat(data['relocated_only']),
            'both':_v2214_public_stat(data['both']),'neither':_v2214_public_stat(data['neither']),
            'saved_downs':saved,'lost_ups':lost,'recovered_ups':recovered,'new_downs':new_down,
            'net_direction_error_reduction_count':saved+recovered-lost-new_down,
            'pass_count_change':int(relocated.get('n') or 0)-int(current.get('n') or 0),
            'up_rate_change_pp':round(float(relocated.get('up_rate_pct') or 0.0)-float(current.get('up_rate_pct') or 0.0),2) if current.get('up_rate_pct') is not None and relocated.get('up_rate_pct') is not None else None,
            'avg_close_change_pct':round(float(relocated.get('avg_close_pct') or 0.0)-float(current.get('avg_close_pct') or 0.0),4) if current.get('avg_close_pct') is not None and relocated.get('avg_close_pct') is not None else None}
    long_ok=[]
    for label in ('3h','6h'):
        h=horizons[label]
        long_ok.append(bool(h.get('up_rate_change_pp') is not None and h.get('avg_close_change_pct') is not None and
            float(h['up_rate_change_pp'])>=0.0 and float(h['avg_close_change_pct'])>=0.0 and int(h['net_direction_error_reduction_count'])>=0))
    state='READY' if collector.exact_events and validation.get('state')=='PASS' and collector.replay_errors==0 else 'CHECK'
    return {'schema':'canonical_factor_role_relocation_exact_replay_v2215','state':state,
        'owner':VERSION,'exact_events_seen':collector.exact_events,'event_rows_seen':collector.events,
        'score_missing_events':collector.score_missing,'replay_error_events':collector.replay_errors,
        'role_contract_validation':validation,'role_contract_hash':validation.get('contract_hash'),
        'role_contract_factor_count':len(_V2215_ROLE_CONTRACT),'horizons':horizons,
        'long_horizons_nonworse':bool(all(long_ok)) if len(long_ok)==2 else False,
        'comparison_contract':'same exact sealed raw axes + same completed candle truth; current v2211 pass score>0 vs canonical relocated replay score>0',
        'activation_state':'REPLAY_ONLY_USER_APPROVAL_REQUIRED','mainline_formula_changed':False,
        'weights_activated':False,'positive_boundary_changed':False,'existing_v2213_shadow_preserved':True,
        'new_shadow_created':False,'candidate_rows_deleted':0,'auto_buy':False}


def _v2215_prepare_row(row,previous_fn,current_fn):
    event,reason=_V2215_BASE_PREPARE_ROW(row,previous_fn,current_fn)
    collector=_V2215_REPLAY_COLLECTOR
    if collector is not None:
        try:collector.consume(row,event)
        except Exception as exc:append_error('v2215_relocation_replay_collect',exc)
    return event,reason

_v2206_prepare_row=_v2215_prepare_row


def _v2215_build_snapshot(final_selected,base_diag,source_info):
    global _V2215_REPLAY_COLLECTOR
    collector=_V2215ReplayCollector();_V2215_REPLAY_COLLECTOR=collector
    try:snap=dict(_V2215_BASE_BUILD_SNAPSHOT(final_selected,base_diag,source_info) or {})
    finally:_V2215_REPLAY_COLLECTOR=None
    replay=_v2215_finalize_replay(collector)
    snap.update({'schema':'prediction_review_snapshot_v2215','owner':VERSION,'version':VERSION,'build':BUILD_LABEL,
        'factor_role_relocation_replay_v2215':replay,'factor_role_contract_state_v2215':(replay.get('role_contract_validation') or {}).get('state'),
        'factor_role_contract_hash_v2215':replay.get('role_contract_hash'),'factor_relocation_live_active_v2215':False,
        'factor_relocation_replay_only_v2215':True,'existing_v2213_shadow_preserved_v2215':True,
        'active_candidate_exclusion_count_v2215':0,'candidate_rows_deleted_v2215':0,'auto_buy':False})
    return snap

_v2202_build_snapshot=_v2215_build_snapshot


def _v2215_seed_ledger(snapshot):
    state=load_json(OUTCOME_STATE,{}) or {};state=dict(state) if isinstance(state,dict) else {}
    if state.get('v2215_ledger_seeded'):return False
    ts=now_ts();txt=now_text(ts);ok=False
    try:
        append_jsonl(CHANGE_LEDGER,{'schema':'change_verify_ledger_v870','change_id':'V2215-CANONICAL-FACTOR-ROLE-RELOCATION-REPLAY',
            'issue_id':'RISE-PREDICTION-FACTOR-ROLE-MISPLACEMENT-2215','version':'v2215','verify_result':'LOCAL_PASS_SERVER_CHECK',
            'created_ts':ts,'created_at':txt,'writer':VERSION,
            'cause':'Code inspection found market context overwritten by ticker flow, short timing copied into long direction and the same persistence material reused under multiple names.',
            'fix':'Seal one Core role contract and replay the canonical placement on the same exact events. Long direction uses only relative-strength velocity, money-flow velocity, buy persistence and orderflow velocity. Levels, timing, market and risk remain separate.',
            'not_touched':['live mainline formula/weights/positive threshold','candidate/S1/Paper','structure/trigger/invalid/target/RR','entry/exit','historical exact and trade ledgers','existing v2213 Shadow','auto-buy OFF'],'auto_buy':False})
        append_jsonl(ISSUE_LEDGER,{'schema':'coinbot_single_work_ledger_v870','event_type':'ISSUE','issue_id':'RISE-PREDICTION-FACTOR-ROLE-MISPLACEMENT-2215',
            'status':'CHECK','title':'상승예측 재료 제자리 재배치 exact 검증','detail':'Core 단일 역할계약 PASS와 동일 exact 재생에서 현재식 대비 3h/6h 개선을 확인한 뒤 사용자 승인으로만 본선 전환한다.',
            'version':'v2215','created_ts':ts,'created_at':txt,'auto_buy':False});ok=True
    except Exception as exc:append_error('v2215_ledger_seed',exc)
    if ok:
        state['v2215_ledger_seeded']=True;state['version_v2215']=VERSION;state['build_v2215']=BUILD_LABEL;state['updated_ts_v2215']=ts;state['auto_buy']=False
        _atomic_json(OUTCOME_STATE,state)
    return ok


def run_once__v2215():
    result=_V2215_BASE_RUN_ONCE();result=dict(result) if isinstance(result,dict) else {}
    snap=_V2202_CACHE.get('snapshot') if isinstance(_V2202_CACHE.get('snapshot'),dict) else None
    if isinstance(snap,dict):_v2215_seed_ledger(snap)
    health=load_json(STATUS,{}) or {};health=dict(health) if isinstance(health,dict) else {}
    replay=(snap or {}).get('factor_role_relocation_replay_v2215') if isinstance((snap or {}).get('factor_role_relocation_replay_v2215'),dict) else {}
    health.update({'schema':'clean_review_worker_status_v2215','version':VERSION,'build':BUILD_LABEL,
        'phase':'canonical_factor_role_relocation_exact_replay','factor_role_replay_state_v2215':replay.get('state'),
        'factor_role_contract_state_v2215':(replay.get('role_contract_validation') or {}).get('state'),
        'factor_role_contract_hash_v2215':replay.get('role_contract_hash'),'factor_exact_events_v2215':int(replay.get('exact_events_seen') or 0),
        'factor_relocation_live_active_v2215':False,'existing_v2213_shadow_preserved_v2215':True,
        'active_candidate_exclusions_v2215':0,'actual_entry_changed_v2215':False,'actual_exit_changed_v2215':False,'auto_buy':False})
    _atomic_json(STATUS,health)
    result.update({'version':VERSION,'build':BUILD_LABEL,'prediction_validation_v2202':snap,'auto_buy':False})
    return result

run_once=run_once__v2215
run_once.__name__='run_once';run_once.__qualname__='run_once'


# =============================================================================
# Review v2.095 / v2216: final-entrypoint runtime identity repair.
# v2215 definitions were appended after the old main() invocation, so the new
# file hash was active while runtime status/lock remained v2.093.  The only
# active entrypoint now lives at the physical file tail after every override.
# =============================================================================
VERSION='review_worker_v2.095'
BUILD_LABEL='v2216_final_entrypoint_runtime_identity_repair_2026-07-26'
MAIN_DEPLOY_VERSION=BUILD_LABEL


def _v2216_runtime_fix_ledger_once():
    marker=BASE_DIR/'runtime'/'review_v2216_final_entrypoint_runtime_identity.seeded'
    if marker.exists():return
    ts=now_ts();txt=now_text(ts)
    try:
        append_jsonl(CHANGE_LEDGER,{
            'schema':'change_verify_ledger_v870','change_id':'V2216-FINAL-ENTRYPOINT-RUNTIME-IDENTITY-REPAIR',
            'issue_id':'V2215-APPENDED-AFTER-MAIN-RUNTIME-IDENTITY','version':'v2216',
            'verify_result':'LOCAL_PASS_SERVER_CHECK','created_ts':ts,'created_at':txt,'writer':VERSION,
            'cause':'v2215 Review/Main/Strategy overrides were physically appended after the existing top-level main() call. Python entered the long-running v2214 loop before reaching v2215 definitions, so active file hash was new but status/lock versions stayed old.',
            'fix':'Move the sole active entrypoint to the physical tail of all three files. Review now acquires the existing singleton with final v2.095 globals and immediately writes current PID/version to lock and status before the first heavy scan.',
            'not_touched':['factor-role contract/hash','relocation replay formula','live prediction weights/positive boundary','candidate/S1/Paper','structure/trigger/invalid/target/RR','entry/exit','historical ledgers','existing v2213 Shadow','auto-buy OFF'],
            'auto_buy':False})
        append_jsonl(ISSUE_LEDGER,{
            'schema':'coinbot_single_work_ledger_v870','event_type':'ISSUE','issue_id':'V2215-APPENDED-AFTER-MAIN-RUNTIME-IDENTITY',
            'status':'CHECK','title':'v2215 최종 실행문 앞뒤 순서 오류','detail':'새 코드가 main() 뒤에 붙어 hash만 최신이고 실제 Review status·lock은 v2.093으로 실행된 문제. v2216에서 Main·Strategy·Review 실행문을 모두 파일 끝으로 이동하고 fresh boot PID/version 일치를 검증한다.',
            'version':'v2216','created_ts':ts,'created_at':txt,'auto_buy':False})
        marker.parent.mkdir(parents=True,exist_ok=True);marker.write_text(txt,encoding='utf-8')
    except Exception as exc:append_error('v2216_runtime_fix_ledger',exc)


# This call is before main(), but after all final globals and overrides.
# v2245 deferred module-level call: _v2216_runtime_fix_ledger_once runs after runtime identity publication.



# =============================================================================
# Review v2.096 / v2219: canonical role influence decomposition.
# The v2215 role placement contract/hash remains unchanged.  This release only
# decomposes why the relocated replay admitted extra DOWN events and measures
# each role's counterfactual influence on the same exact events.  No live
# formula, weight, boundary, candidate, entry, exit or Shadow is changed.
# =============================================================================
VERSION='review_worker_v2.096'
BUILD_LABEL='v2219_role_influence_decomposition_same_exact_replay_2026-07-26'
MAIN_DEPLOY_VERSION=BUILD_LABEL
_V2219_BASE_BUILD_SNAPSHOT=_v2202_build_snapshot
_V2219_BASE_PREPARE_ROW=_v2206_prepare_row
_V2219_BASE_RUN_ONCE=run_once
_V2219_COLLECTOR=None
V2219_ROLE_NAMES=('continuation_velocity','continuation_persistence','entry_timing','market_context','execution_risk','participation_level')
V2219_DIRECT_FACTORS=('relative_strength_velocity','money_flow_velocity','buy_sustain_level','orderflow_velocity')
V2219_HORIZONS=('3h','6h')
V2219_RECENT_SEC=86400.0


def _v2219_value_empty():
    return {'n':0,'sum':0.0,'sum_sq':0.0}


def _v2219_value_add(stat,value):
    value=_v2202_num(value)
    if value is None:return
    stat['n']+=1;stat['sum']+=float(value);stat['sum_sq']+=float(value)*float(value)


def _v2219_value_public(stat):
    n=int(stat.get('n') or 0)
    if not n:return {'n':0,'avg':None,'std':None}
    avg=float(stat.get('sum') or 0.0)/n
    var=max(0.0,float(stat.get('sum_sq') or 0.0)/n-avg*avg)
    return {'n':n,'avg':round(avg,6),'std':round(math.sqrt(var),6)}


def _v2219_scenario_meta():
    out={
        'current_mainline':{'role':'current','method':'sealed current v2211 score > 0','influence_pct':0},
        'relocated_50_50':{'role':'direction_balance','method':'velocity 50% + persistence 50%','influence_pct':50},
        'velocity_only':{'role':'direction_balance','method':'velocity only','influence_pct':100},
        'persistence_only':{'role':'direction_balance','method':'persistence only','influence_pct':100},
        'both_positive':{'role':'direction_balance','method':'velocity > 0 and persistence > 0','influence_pct':0},
    }
    for pct in (25,40,60,75):
        out[f'velocity_weight_{pct}']={'role':'direction_balance','method':f'velocity {pct}% + persistence {100-pct}%','influence_pct':pct}
    for role,prefix in (('entry_timing','timing'),('market_context','market'),('execution_risk','risk')):
        for pct in (10,20,30):
            out[f'{prefix}_add_{pct}']={'role':role,'method':f'base direction {100-pct}% + {role} {pct}%','influence_pct':pct}
        out[f'{prefix}_nonnegative_gate']={'role':role,'method':f'base direction > 0 and {role} >= 0','influence_pct':0}
    out['level_cap_030']={'role':'participation_level','method':'base direction > 0 and current level <= 0.30','influence_pct':0}
    out['level_cap_050']={'role':'participation_level','method':'base direction > 0 and current level <= 0.50','influence_pct':0}
    return out

V2219_SCENARIO_META=_v2219_scenario_meta()


def _v2219_family_score(replay,name):
    fam=(replay.get('families') or {}).get(name) if isinstance(replay,dict) else None
    return _v2202_num(fam.get('score')) if isinstance(fam,dict) else None


def _v2219_scenario_passes(current_score,replay):
    current=_v2202_num(current_score);base=_v2202_num((replay or {}).get('continuation_score'))
    velocity=_v2219_family_score(replay,'continuation_velocity')
    persistence=_v2219_family_score(replay,'continuation_persistence')
    timing=_v2219_family_score(replay,'entry_timing')
    market=_v2219_family_score(replay,'market_context')
    risk=_v2219_family_score(replay,'execution_risk')
    level=_v2219_family_score(replay,'participation_level')
    out={'current_mainline':bool(current is not None and current>0.0),'relocated_50_50':bool(base is not None and base>0.0)}
    out['velocity_only']=bool(velocity is not None and velocity>0.0)
    out['persistence_only']=bool(persistence is not None and persistence>0.0)
    out['both_positive']=bool(velocity is not None and persistence is not None and velocity>0.0 and persistence>0.0)
    for pct in (25,40,60,75):
        score=None if velocity is None or persistence is None else (pct/100.0)*velocity+(1.0-pct/100.0)*persistence
        out[f'velocity_weight_{pct}']=bool(score is not None and score>0.0)
    for role,prefix,value in (('entry_timing','timing',timing),('market_context','market',market),('execution_risk','risk',risk)):
        for pct in (10,20,30):
            score=None if base is None or value is None else (1.0-pct/100.0)*base+(pct/100.0)*value
            out[f'{prefix}_add_{pct}']=bool(score is not None and score>0.0)
        out[f'{prefix}_nonnegative_gate']=bool(base is not None and value is not None and base>0.0 and value>=0.0)
    out['level_cap_030']=bool(base is not None and level is not None and base>0.0 and level<=0.30)
    out['level_cap_050']=bool(base is not None and level is not None and base>0.0 and level<=0.50)
    values={'continuation_velocity':velocity,'continuation_persistence':persistence,'entry_timing':timing,
            'market_context':market,'execution_risk':risk,'participation_level':level}
    return out,values


def _v2219_scenario_empty():
    return {'stat':_v2214_empty_stat(),'saved_downs':0,'lost_ups':0,'recovered_ups':0,'new_downs':0}


def _v2219_transition(cp,rp,truth):
    if cp and not rp:return 'saved_down' if truth=='DOWN' else 'lost_up' if truth=='UP' else 'current_only_flat'
    if rp and not cp:return 'recovered_up' if truth=='UP' else 'new_down' if truth=='DOWN' else 'relocated_only_flat'
    if rp and cp:return 'both_up' if truth=='UP' else 'both_down' if truth=='DOWN' else 'both_flat'
    return 'neither_up' if truth=='UP' else 'neither_down' if truth=='DOWN' else 'neither_flat'


class _V2219RoleInfluenceCollector:
    def __init__(self):
        self.events=0;self.exact_events=0;self.errors=0;self.score_missing=0
        self.recent_cutoff=now_ts()-V2219_RECENT_SEC
        self.scenarios={scope:{h:{name:_v2219_scenario_empty() for name in V2219_SCENARIO_META} for h in V2219_HORIZONS} for scope in ('all','recent24h')}
        groups=('new_down','recovered_up','saved_down','lost_up','both_up','both_down')
        self.role_values={h:{g:{name:_v2219_value_empty() for name in V2219_ROLE_NAMES} for g in groups} for h in V2219_HORIZONS}
        self.factor_values={h:{g:{name:_v2219_value_empty() for name in V2219_DIRECT_FACTORS} for g in groups} for h in V2219_HORIZONS}
        self.transition_counts={h:Counter() for h in V2219_HORIZONS}
    def consume(self,row,event):
        self.events+=1
        if not isinstance(event,dict) or not event.get('exact_input_ready_v2206'):return
        self.exact_events+=1
        seal=row.get('prediction_input_seal_v2188') if isinstance(row,dict) and isinstance(row.get('prediction_input_seal_v2188'),dict) else {}
        axes=seal.get('axes') if isinstance(seal.get('axes'),dict) else {}
        connections=seal.get('connections') if isinstance(seal.get('connections'),dict) else {}
        try:replay=_v2215_relocated_score(axes,connections) if callable(_v2215_relocated_score) else {}
        except Exception:
            self.errors+=1;return
        if not isinstance(replay,dict) or _v2202_num(replay.get('continuation_score')) is None or _v2202_num(event.get('current_score')) is None:
            self.score_missing+=1;return
        passes,role_scores=_v2219_scenario_passes(event.get('current_score'),replay)
        cp=passes.get('current_mainline',False);rp=passes.get('relocated_50_50',False)
        entry_ts=_v2202_num(event.get('entry_ts'));is_recent=bool(entry_ts is not None and entry_ts>=self.recent_cutoff)
        horizons=event.get('horizons') if isinstance(event.get('horizons'),dict) else {}
        for h in V2219_HORIZONS:
            block=horizons.get(h) if isinstance(horizons.get(h),dict) else None
            if not isinstance(block,dict) or block.get('state')!='READY' or block.get('truth') not in ('UP','DOWN','FLAT'):continue
            truth=str(block.get('truth') or '')
            transition=_v2219_transition(cp,rp,truth);self.transition_counts[h][transition]+=1
            for scope in (('all','recent24h') if is_recent else ('all',)):
                baseline=passes.get('current_mainline',False)
                for name,did_pass in passes.items():
                    if not did_pass:continue
                    cell=self.scenarios[scope][h][name];_v2214_add_stat(cell['stat'],block)
                    if baseline and not did_pass:
                        pass
                    if baseline and not passes.get(name,False):
                        if truth=='DOWN':cell['saved_downs']+=1
                        elif truth=='UP':cell['lost_ups']+=1
                    elif passes.get(name,False) and not baseline:
                        if truth=='UP':cell['recovered_ups']+=1
                        elif truth=='DOWN':cell['new_downs']+=1
                # The loop above cannot count removed baseline events because they do not pass.
                for name,did_pass in passes.items():
                    if did_pass or not baseline:continue
                    cell=self.scenarios[scope][h][name]
                    if truth=='DOWN':cell['saved_downs']+=1
                    elif truth=='UP':cell['lost_ups']+=1
            if transition in self.role_values[h]:
                for name,value in role_scores.items():_v2219_value_add(self.role_values[h][transition][name],value)
                for name in V2219_DIRECT_FACTORS:_v2219_value_add(self.factor_values[h][transition][name],axes.get(name))


def _v2219_public_scenario(cell,baseline):
    stat=_v2214_public_stat(cell.get('stat') or {})
    base_stat=_v2214_public_stat((baseline or {}).get('stat') or {})
    up_change=None if stat.get('up_rate_pct') is None or base_stat.get('up_rate_pct') is None else round(float(stat['up_rate_pct'])-float(base_stat['up_rate_pct']),2)
    close_change=None if stat.get('avg_close_pct') is None or base_stat.get('avg_close_pct') is None else round(float(stat['avg_close_pct'])-float(base_stat['avg_close_pct']),4)
    mfe_change=None if stat.get('avg_mfe_pct') is None or base_stat.get('avg_mfe_pct') is None else round(float(stat['avg_mfe_pct'])-float(base_stat['avg_mfe_pct']),4)
    mae_change=None if stat.get('avg_mae_pct') is None or base_stat.get('avg_mae_pct') is None else round(float(stat['avg_mae_pct'])-float(base_stat['avg_mae_pct']),4)
    saved=int(cell.get('saved_downs') or 0);lost=int(cell.get('lost_ups') or 0);recovered=int(cell.get('recovered_ups') or 0);new=int(cell.get('new_downs') or 0)
    return {'result':stat,'pass_count_change':int(stat.get('n') or 0)-int(base_stat.get('n') or 0),
            'up_rate_change_pp':up_change,'avg_close_change_pct':close_change,'avg_mfe_change_pct':mfe_change,'avg_mae_change_pct':mae_change,
            'saved_downs':saved,'lost_ups':lost,'recovered_ups':recovered,'new_downs':new,
            'net_direction_error_reduction_count':saved+recovered-lost-new}


def _v2219_scenario_consistency(all_rows,recent_rows,name):
    full=[];recent=[]
    for h in V2219_HORIZONS:
        row=(all_rows.get(h) or {}).get(name) or {};full.append(bool(row.get('up_rate_change_pp') is not None and row.get('avg_close_change_pct') is not None and float(row['up_rate_change_pp'])>=0 and float(row['avg_close_change_pct'])>=0 and int(row.get('net_direction_error_reduction_count') or 0)>=0))
        rr=(recent_rows.get(h) or {}).get(name) or {};base=((recent_rows.get(h) or {}).get('current_mainline') or {}).get('result') or {};res=rr.get('result') or {}
        enough=int(base.get('n') or 0)>=10 and int(res.get('n') or 0)>=5
        recent.append(None if not enough else bool(rr.get('up_rate_change_pp') is not None and rr.get('avg_close_change_pct') is not None and float(rr['up_rate_change_pp'])>=0 and float(rr['avg_close_change_pct'])>=0 and int(rr.get('net_direction_error_reduction_count') or 0)>=0))
    if all(full) and all(x is True for x in recent):return 'FULL_AND_RECENT_NONWORSE'
    if all(full) and any(x is None for x in recent):return 'FULL_NONWORSE_RECENT_INSUFFICIENT'
    if all(full):return 'FULL_NONWORSE_RECENT_WORSE'
    return 'WORSE'


def _v2219_finalize(collector):
    scopes={}
    for scope in ('all','recent24h'):
        rows={}
        for h in V2219_HORIZONS:
            base=collector.scenarios[scope][h]['current_mainline']
            rows[h]={name:_v2219_public_scenario(cell,base) for name,cell in collector.scenarios[scope][h].items()}
        scopes[scope]=rows
    scenario_rows={}
    for name,meta in V2219_SCENARIO_META.items():
        if name=='current_mainline':continue
        full=scopes['all'];recent=scopes['recent24h']
        net=sum(int(((full.get(h) or {}).get(name) or {}).get('net_direction_error_reduction_count') or 0) for h in V2219_HORIZONS)
        up=sum(float(((full.get(h) or {}).get(name) or {}).get('up_rate_change_pp') or 0.0) for h in V2219_HORIZONS)
        close=sum(float(((full.get(h) or {}).get(name) or {}).get('avg_close_change_pct') or 0.0) for h in V2219_HORIZONS)
        scenario_rows[name]={'meta':meta,'all':{h:(full.get(h) or {}).get(name) for h in V2219_HORIZONS},
            'recent24h':{h:(recent.get(h) or {}).get(name) for h in V2219_HORIZONS},
            'consistency':_v2219_scenario_consistency(full,recent,name),'rank_key':[net,round(up,4),round(close,6)]}
    ranked=sorted(scenario_rows,key=lambda n:(scenario_rows[n]['rank_key'][0],scenario_rows[n]['rank_key'][1],scenario_rows[n]['rank_key'][2]),reverse=True)
    role_effects={}
    roles=sorted({str(v.get('role')) for k,v in V2219_SCENARIO_META.items() if k not in ('current_mainline','relocated_50_50')})
    for role in roles:
        names=[n for n,row in scenario_rows.items() if str((row.get('meta') or {}).get('role'))==role]
        names.sort(key=lambda n:(scenario_rows[n]['rank_key'][0],scenario_rows[n]['rank_key'][1],scenario_rows[n]['rank_key'][2]),reverse=True)
        if names:role_effects[role]={'best_scenario':names[0],'best':scenario_rows[names[0]],'tested_scenarios':names}
    attribution={}
    for h in V2219_HORIZONS:
        role_rows=[];factor_rows=[]
        for name in V2219_ROLE_NAMES:
            bad=_v2219_value_public(collector.role_values[h]['new_down'][name]);good=_v2219_value_public(collector.role_values[h]['recovered_up'][name])
            bias=None if bad.get('avg') is None or good.get('avg') is None else round(float(bad['avg'])-float(good['avg']),6)
            role_rows.append({'name':name,'new_down':bad,'recovered_up':good,'bad_bias_new_minus_recovered':bias})
        for name in V2219_DIRECT_FACTORS:
            bad=_v2219_value_public(collector.factor_values[h]['new_down'][name]);good=_v2219_value_public(collector.factor_values[h]['recovered_up'][name])
            bias=None if bad.get('avg') is None or good.get('avg') is None else round(float(bad['avg'])-float(good['avg']),6)
            factor_rows.append({'name':name,'new_down':bad,'recovered_up':good,'bad_bias_new_minus_recovered':bias})
        role_rows.sort(key=lambda x:abs(float(x.get('bad_bias_new_minus_recovered') or 0.0)),reverse=True)
        factor_rows.sort(key=lambda x:abs(float(x.get('bad_bias_new_minus_recovered') or 0.0)),reverse=True)
        attribution[h]={'transition_counts':dict(collector.transition_counts[h]),'roles':role_rows,'direct_factors':factor_rows}
    state='READY' if collector.exact_events and collector.errors==0 else 'CHECK'
    return {'schema':'factor_role_influence_decomposition_v2219','state':state,'owner':VERSION,
        'exact_events_seen':collector.exact_events,'event_rows_seen':collector.events,'replay_errors':collector.errors,'score_missing_events':collector.score_missing,
        'role_contract_hash':'9ee5b3164805bec8936491aa11c0266c5a8ed131f13c7b3a2a10bcb2a4817e61',
        'role_contract_changed':False,'scopes':scopes,'scenario_results':scenario_rows,'ranked_scenarios':ranked,
        'role_effects':role_effects,'attribution':attribution,
        'method':'same exact sealed axes and same completed-candle truth; decompose relocated-only extra DOWN versus recovered UP; sweep one role influence at a time without activating any formula',
        'activation_state':'ANALYSIS_ONLY_USER_APPROVAL_REQUIRED','mainline_formula_changed':False,'weights_activated':False,'positive_boundary_changed':False,
        'candidate_rows_deleted':0,'new_shadow_created':False,'existing_v2213_shadow_preserved':True,'auto_buy':False}


def _v2219_prepare_row(row,previous_fn,current_fn):
    event,reason=_V2219_BASE_PREPARE_ROW(row,previous_fn,current_fn)
    if _V2219_COLLECTOR is not None:
        try:_V2219_COLLECTOR.consume(row,event)
        except Exception as exc:append_error('v2219_role_influence_collect',exc)
    return event,reason

_v2206_prepare_row=_v2219_prepare_row


def _v2219_build_snapshot(final_selected,base_diag,source_info):
    global _V2219_COLLECTOR
    collector=_V2219RoleInfluenceCollector();_V2219_COLLECTOR=collector
    try:snap=dict(_V2219_BASE_BUILD_SNAPSHOT(final_selected,base_diag,source_info) or {})
    finally:_V2219_COLLECTOR=None
    decomp=_v2219_finalize(collector)
    snap.update({'schema':'prediction_review_snapshot_v2219','owner':VERSION,'version':VERSION,'build':BUILD_LABEL,
        'factor_role_influence_decomposition_v2219':decomp,'factor_role_contract_hash_v2219':decomp.get('role_contract_hash'),
        'factor_role_contract_changed_v2219':False,'role_influence_live_active_v2219':False,
        'existing_v2213_shadow_preserved_v2219':True,'new_shadow_created_v2219':False,
        'active_candidate_exclusion_count_v2219':0,'candidate_rows_deleted_v2219':0,'auto_buy':False})
    return snap

_v2202_build_snapshot=_v2219_build_snapshot


def _v2219_seed_ledger(snapshot):
    state=load_json(OUTCOME_STATE,{}) or {};state=dict(state) if isinstance(state,dict) else {}
    if state.get('v2219_ledger_seeded'):return False
    ts=now_ts();txt=now_text(ts);ok=False
    try:
        append_jsonl(CHANGE_LEDGER,{'schema':'change_verify_ledger_v870','change_id':'V2219-ROLE-INFLUENCE-DECOMPOSITION',
            'issue_id':'RISE-PREDICTION-RELOCATED-EXTRA-DOWN-2219','version':'v2219','verify_result':'LOCAL_PASS_SERVER_CHECK',
            'created_ts':ts,'created_at':txt,'writer':VERSION,
            'cause':'The canonical v2215 placement contract passed, but the replay admitted 30 extra 3h DOWN and 29 extra 6h DOWN events. Placement is fixed; influence and confirmation strength were not yet measured.',
            'fix':'On the same exact scan, decompose velocity/persistence/timing/market/risk/level roles and test one-role-at-a-time influence sweeps. Report saved losses, lost rises, recovered rises, new declines, close/MFE/MAE and recent-24h consistency. No activation.',
            'not_touched':['v2215 role contract/hash','live formula/weights/positive boundary','candidate/S1/Paper','structure/trigger/invalid/target/RR','entry/exit','historical ledgers','existing v2213 Shadow','auto-buy OFF'],'auto_buy':False})
        append_jsonl(ISSUE_LEDGER,{'schema':'coinbot_single_work_ledger_v870','event_type':'ISSUE','issue_id':'RISE-PREDICTION-RELOCATED-EXTRA-DOWN-2219',
            'status':'CHECK','title':'재배치 역할별 영향력 분해','detail':'재료 위치는 고정하고 새 하락을 만든 역할과 적정 보조 영향력을 동일 exact 사건에서 분해한다. 전체·최근 모두 악화 없는 한 안만 다음 단일 Shadow 후보가 된다.',
            'version':'v2219','created_ts':ts,'created_at':txt,'auto_buy':False});ok=True
    except Exception as exc:append_error('v2219_ledger_seed',exc)
    if ok:
        state['v2219_ledger_seeded']=True;state['version_v2219']=VERSION;state['build_v2219']=BUILD_LABEL;state['updated_ts_v2219']=ts;state['auto_buy']=False
        _atomic_json(OUTCOME_STATE,state)
    return ok


def run_once__v2219():
    result=_V2219_BASE_RUN_ONCE();result=dict(result) if isinstance(result,dict) else {}
    snap=_V2202_CACHE.get('snapshot') if isinstance(_V2202_CACHE.get('snapshot'),dict) else None
    if isinstance(snap,dict):_v2219_seed_ledger(snap)
    decomp=(snap or {}).get('factor_role_influence_decomposition_v2219') if isinstance((snap or {}).get('factor_role_influence_decomposition_v2219'),dict) else {}
    health=load_json(STATUS,{}) or {};health=dict(health) if isinstance(health,dict) else {}
    health.update({'schema':'clean_review_worker_status_v2219','version':VERSION,'build':BUILD_LABEL,
        'phase':'factor_role_influence_decomposition','factor_role_influence_state_v2219':decomp.get('state'),
        'factor_role_contract_hash_v2219':decomp.get('role_contract_hash'),'factor_role_contract_changed_v2219':False,
        'factor_exact_events_v2219':int(decomp.get('exact_events_seen') or 0),'role_influence_live_active_v2219':False,
        'existing_v2213_shadow_preserved_v2219':True,'active_candidate_exclusions_v2219':0,
        'actual_entry_changed_v2219':False,'actual_exit_changed_v2219':False,'auto_buy':False})
    _atomic_json(STATUS,health)
    result.update({'version':VERSION,'build':BUILD_LABEL,'prediction_validation_v2202':snap,'auto_buy':False})
    return result

run_once=run_once__v2219
run_once.__name__='run_once';run_once.__qualname__='run_once'


# =============================================================================
# Review v2.097 / v2220: recent-7d first, date-indexed persistent exact cache,
# and full-history incremental backfill.  The canonical outcome ledger remains
# append-only and untouched.  The cache is derived/rebuildable and owned by the
# existing single Review process; no new worker, command, Shadow, gate or live
# trading rule is introduced.
# =============================================================================
import sqlite3
from datetime import timezone,timedelta
VERSION='review_worker_v2.097'
BUILD_LABEL='v2220_recent7d_date_index_full_incremental_review_2026-07-26'
MAIN_DEPLOY_VERSION=BUILD_LABEL
V2220_RECENT_DAYS=7
V2220_RECENT_SEC=V2220_RECENT_DAYS*86400.0
V2220_CACHE_DB=BASE_DIR/'runtime'/'review_exact_day_cache_v2220.sqlite3'
V2220_CACHE_SCHEMA='review_exact_day_cache_v2220'
V2220_CACHE_VERSION=2
V2220_REVERSE_BLOCK=4*1024*1024
V2220_REVERSE_MAX_BYTES=1536*1024*1024
V2220_OLD_STREAK_STOP=12000
V2220_KST=timezone(timedelta(hours=9))
_V2220_BASE_BUILD_SNAPSHOT=_v2202_build_snapshot
_V2220_BASE_PUBLISH=_v2209_publish
_V2220_BASE_RUN_ONCE=run_once
_V2220_CACHE_LOCK=threading.RLock()
_V2220_CACHE_STATE={'mode':'BOOT','recent_rows':0,'full_rows':0,'cache_hits':0,'source':'NONE','full_complete':False,'backfill_pct':0.0,'last_error':None}


def _v2220_db():
    V2220_CACHE_DB.parent.mkdir(parents=True,exist_ok=True)
    conn=sqlite3.connect(str(V2220_CACHE_DB),timeout=30.0)
    conn.execute('PRAGMA journal_mode=WAL')
    conn.execute('PRAGMA synchronous=NORMAL')
    conn.execute('PRAGMA temp_store=MEMORY')
    conn.execute('CREATE TABLE IF NOT EXISTS events(event_key TEXT PRIMARY KEY,event_ts REAL,event_day TEXT,rank_json TEXT,row_json TEXT,updated_ts REAL)')
    conn.execute('CREATE INDEX IF NOT EXISTS idx_events_day ON events(event_day,event_ts)')
    conn.execute('CREATE TABLE IF NOT EXISTS meta(key TEXT PRIMARY KEY,value TEXT)')
    conn.commit();return conn


def _v2220_meta_get(conn,key,default=None):
    row=conn.execute('SELECT value FROM meta WHERE key=?',(str(key),)).fetchone()
    if not row:return default
    try:return json.loads(row[0])
    except Exception:return row[0]


def _v2220_meta_set(conn,key,value):
    text=json.dumps(value,ensure_ascii=False,separators=(',',':'),default=str)
    conn.execute('INSERT INTO meta(key,value) VALUES(?,?) ON CONFLICT(key) DO UPDATE SET value=excluded.value',(str(key),text))


def _v2220_day(ts):
    try:return datetime.fromtimestamp(float(ts),V2220_KST).strftime('%Y-%m-%d')
    except Exception:return 'UNKNOWN'


def _v2220_compact_row(row):
    if not isinstance(row,dict):return None
    keep=('event_key','generation','ticker','start_ts','created_ts','finalized_ts','last_seen_ts',
          'prediction_model_generation','prediction_input_seal_v2188','prediction_factor_results_v2188','samples',
          'current_formula_pass_v2210','prediction_formula_pass_v2210','paper_decision_key_v926','decision_key',
          'source_decision_key','direct_decision_key_v2149','candidate_commit_id','s1_generation_id')
    out={k:row.get(k) for k in keep if k in row}
    # Preserve scalar identity/timing fields that later audits may consume while
    # excluding bulky unrelated nested traces.
    for k,v in row.items():
        if k in out:continue
        if isinstance(v,(str,int,float,bool)) or v is None:
            if k.endswith(('_ts','_at','_id','_key')) or k in {'model_generation','paper_v2_generation'}:
                out[k]=v
    return out


def _v2220_upsert(conn,row,priority=1):
    compact=_v2220_compact_row(row)
    if not compact:return False
    key=str(compact.get('event_key') or '').strip()
    if not key:return False
    rank=tuple(_v2202_rank(compact,priority))
    old=conn.execute('SELECT rank_json FROM events WHERE event_key=?',(key,)).fetchone()
    if old:
        try:old_rank=tuple(json.loads(old[0]))
        except Exception:old_rank=()
        if rank<=old_rank:return False
    ts=_v2202_event_time(compact) or _v2202_num(compact.get('finalized_ts')) or 0.0
    conn.execute('INSERT INTO events(event_key,event_ts,event_day,rank_json,row_json,updated_ts) VALUES(?,?,?,?,?,?) '
                 'ON CONFLICT(event_key) DO UPDATE SET event_ts=excluded.event_ts,event_day=excluded.event_day,rank_json=excluded.rank_json,row_json=excluded.row_json,updated_ts=excluded.updated_ts',
                 (key,float(ts or 0.0),_v2220_day(ts),json.dumps(list(rank),separators=(',',':')),
                  json.dumps(compact,ensure_ascii=False,separators=(',',':'),default=str),now_ts()))
    return True


def _v2220_load_selected(conn,recent_only=False):
    cutoff=now_ts()-V2220_RECENT_SEC
    sql='SELECT event_key,rank_json,row_json FROM events'
    args=()
    if recent_only:
        sql+=' WHERE event_ts>=?';args=(cutoff,)
    selected={};bad=0
    for key,rj,obj in conn.execute(sql,args):
        try:selected[str(key)]=(tuple(json.loads(rj)),json.loads(obj))
        except Exception:bad+=1
    return selected,bad


def _v2220_reverse_lines(path,block_size=V2220_REVERSE_BLOCK,max_bytes=V2220_REVERSE_MAX_BYTES):
    size=path.stat().st_size
    with path.open('rb') as f:
        pos=size;buf=b'';read_bytes=0
        while pos>0 and read_bytes<max_bytes:
            step=min(block_size,pos,max_bytes-read_bytes);pos-=step;f.seek(pos);chunk=f.read(step);read_bytes+=len(chunk)
            buf=chunk+buf;parts=buf.split(b'\n');buf=parts[0]
            for line in reversed(parts[1:]):
                if line.strip():yield line,read_bytes,size
        if buf.strip():yield buf,read_bytes,size


def _v2220_recent_tail_scan(conn):
    selected={};diag={'ledger_raw_rows':0,'ledger_json_errors':0,'wrong_generation_raw':0,'missing_event_key_raw':0,'duplicates_removed':0,
                      'recent_tail_scan_v2220':True,'recent_days_v2220':V2220_RECENT_DAYS}
    cutoff=now_ts()-V2220_RECENT_SEC;old_streak=0;read_bytes=0;size=0;recent_rows=0
    if not OUTCOME_LEDGER.exists():return selected,diag,{'inode':None,'offset':0,'size':0,'mtime_ns':0,'tail_bytes':0}
    st=OUTCOME_LEDGER.stat();size=int(st.st_size)
    conn.execute('BEGIN')
    try:
        for raw,read_bytes,size in _v2220_reverse_lines(OUTCOME_LEDGER):
            diag['ledger_raw_rows']+=1
            try:row=json.loads(raw.decode('utf-8','replace'))
            except Exception:
                diag['ledger_json_errors']+=1;continue
            if not isinstance(row,dict):continue
            ts=_v2202_event_time(row) or _v2202_num(row.get('finalized_ts')) or 0.0
            if ts>=cutoff:
                old_streak=0;recent_rows+=1;_v2202_accept_raw(selected,row,1,diag);_v2220_upsert(conn,row,1)
            else:old_streak+=1
            if old_streak>=V2220_OLD_STREAK_STOP and recent_rows>0:break
        conn.commit()
    except Exception:
        conn.rollback();raise
    complete=bool(size<=read_bytes or (recent_rows>0 and old_streak>=V2220_OLD_STREAK_STOP))
    diag['ledger_unique_keys']=len(selected);diag['tail_rows_recent_v2220']=recent_rows;diag['tail_bytes_read_v2220']=read_bytes
    diag['recent_tail_complete_v2220']=complete;diag['recent_tail_incomplete_v2220']=not complete
    _v2220_meta_set(conn,'recent_tail_complete',complete);conn.commit()
    return selected,diag,{'inode':getattr(st,'st_ino',None),'offset':0,'size':size,'mtime_ns':st.st_mtime_ns,'tail_bytes':read_bytes,'recent_cutoff':cutoff}


def _v2220_full_scan_to_cache(conn):
    started=time.monotonic();diag={'ledger_raw_rows':0,'ledger_json_errors':0,'wrong_generation_raw':0,'missing_event_key_raw':0,'duplicates_removed':0,
                                  'date_cache_backfill_v2220':True};inode=None;offset=0;size=0;mtime_ns=0
    if OUTCOME_LEDGER.exists():
        st=OUTCOME_LEDGER.stat();inode=getattr(st,'st_ino',None);size=int(st.st_size);mtime_ns=st.st_mtime_ns
        _v2209_progress('V2220_FULL_BACKFILL',0,0,size,True);last=0
        with OUTCOME_LEDGER.open('rb') as handle:
            conn.execute('BEGIN')
            try:
                for raw in handle:
                    diag['ledger_raw_rows']+=1
                    try:row=json.loads(raw.decode('utf-8','replace'))
                    except Exception:
                        diag['ledger_json_errors']+=1;row=None
                    if isinstance(row,dict):_v2220_upsert(conn,row,1)
                    if diag['ledger_raw_rows']-last>=5000:
                        conn.commit();conn.execute('BEGIN');last=diag['ledger_raw_rows']
                        _v2209_progress('V2220_FULL_BACKFILL',last,handle.tell(),size,False)
                offset=handle.tell();conn.commit()
            except Exception:
                conn.rollback();raise
        _v2209_progress('V2220_FULL_BACKFILL_DONE',diag['ledger_raw_rows'],offset,size,True)
    count=int(conn.execute('SELECT COUNT(*) FROM events').fetchone()[0])
    diag['ledger_unique_keys']=count
    _v2220_meta_set(conn,'schema',V2220_CACHE_SCHEMA);_v2220_meta_set(conn,'version',V2220_CACHE_VERSION)
    _v2220_meta_set(conn,'full_complete',True);_v2220_meta_set(conn,'recent_tail_complete',True);_v2220_meta_set(conn,'ledger_inode',inode);_v2220_meta_set(conn,'ledger_offset',offset)
    _v2220_meta_set(conn,'ledger_size',size);_v2220_meta_set(conn,'ledger_mtime_ns',mtime_ns);_v2220_meta_set(conn,'completed_ts',now_ts());conn.commit()
    return diag,{'inode':inode,'offset':offset,'size':size,'mtime_ns':mtime_ns,'scan_sec':round(time.monotonic()-started,3)}


def _v2220_snapshot(selected,diag,info,scope,full_state,recent_compact=None):
    snap=dict(_V2220_BASE_BUILD_SNAPSHOT(selected,diag,info) or {})
    recent_complete=not bool((diag or {}).get('recent_tail_incomplete_v2220'))
    window={'schema':'review_window_v2220','primary_days':V2220_RECENT_DAYS,'scope':scope,'full_history_state':full_state,
            'recent_ready':bool(scope=='FULL_HISTORY' or (scope=='RECENT_7D' and recent_complete)),'recent_partial':bool(scope=='RECENT_7D' and not recent_complete),
            'full_ready':scope=='FULL_HISTORY' and full_state=='READY',
            'activation_allowed':scope=='FULL_HISTORY' and full_state=='READY','date_index_cache':V2220_CACHE_DB.name,
            'canonical_ledger_rewritten':False,'canonical_ledger_deleted':False,'auto_buy':False}
    snap.update({'schema':'prediction_review_snapshot_v2220','owner':VERSION,'version':VERSION,'build':BUILD_LABEL,
                 'review_window_v2220':window,'recent_7d_primary_v2220':True,'full_history_activation_required_v2220':True,
                 'date_index_cache_v2220':{'path':str(V2220_CACHE_DB),'derived_cache_only':True,'single_owner':VERSION},'auto_buy':False})
    if isinstance(recent_compact,dict):snap['recent_7d_comparison_v2220']=recent_compact
    return snap


def _v2220_recent_compact(snap):
    if not isinstance(snap,dict):return {}
    return {'snapshot_id':snap.get('snapshot_id'),'calculated_ts':snap.get('calculated_ts'),'diagnostics':snap.get('diagnostics'),
            'horizons':snap.get('horizons'),'factor_role_influence_decomposition_v2219':snap.get('factor_role_influence_decomposition_v2219'),
            'factor_role_contract_hash_v2219':snap.get('factor_role_contract_hash_v2219'),'scope':'RECENT_7D'}


def _v2220_publish_cache_snapshot(snapshot,state):
    # Resolve the final global publisher at call time; do not use the captured
    # pre-v2238 function object.
    return _v2209_publish(snapshot,state)


def _v2220_set_cache(snapshot,selected,diag,info,*,building,ready,cycle_complete,stage):
    with _V2202_LOCK:
        _V2202_CACHE.update({'snapshot':snapshot,'by_key':selected,'diagnostics':diag,'ledger_inode':info.get('inode'),
            'ledger_offset':info.get('offset'),'ledger_size':info.get('size'),'ledger_mtime_ns':info.get('mtime_ns'),
            'building':building,'ready':ready,'cycle_complete_v2209':cycle_complete,'stage_v2209':stage,
            'progress_rows_v2209':int(diag.get('ledger_raw_rows') or 0),'progress_bytes_v2209':int(info.get('offset') or info.get('tail_bytes') or 0),
            'progress_total_bytes_v2209':int(info.get('size') or 0),'progress_pct_v2209':100.0 if cycle_complete else float(_V2202_CACHE.get('progress_pct_v2209') or 0.0),
            'error':None,'error_latched_v2209':False,'last_snapshot_refresh_ts_v2209':now_ts()})


def _v2220_incremental_cache(conn):
    inode=_v2220_meta_get(conn,'ledger_inode');offset=int(_v2220_meta_get(conn,'ledger_offset',0) or 0)
    try:st=OUTCOME_LEDGER.stat()
    except FileNotFoundError:return False,{'inode':inode,'offset':offset,'size':0,'mtime_ns':0}
    if inode not in (None,getattr(st,'st_ino',None)) or st.st_size<offset:
        _v2220_meta_set(conn,'full_complete',False);conn.commit();raise RuntimeError('outcome ledger rotated/truncated; date cache full backfill required')
    if st.st_size==offset:return False,{'inode':getattr(st,'st_ino',None),'offset':offset,'size':st.st_size,'mtime_ns':st.st_mtime_ns}
    changed=False;conn.execute('BEGIN')
    try:
        with OUTCOME_LEDGER.open('rb') as h:
            h.seek(offset)
            for raw in h:
                try:row=json.loads(raw.decode('utf-8','replace'))
                except Exception:continue
                if isinstance(row,dict):changed=_v2220_upsert(conn,row,1) or changed
            new_offset=h.tell()
        _v2220_meta_set(conn,'ledger_inode',getattr(st,'st_ino',None));_v2220_meta_set(conn,'ledger_offset',new_offset)
        _v2220_meta_set(conn,'ledger_size',st.st_size);_v2220_meta_set(conn,'ledger_mtime_ns',st.st_mtime_ns);conn.commit()
    except Exception:conn.rollback();raise
    return changed,{'inode':getattr(st,'st_ino',None),'offset':new_offset,'size':st.st_size,'mtime_ns':st.st_mtime_ns}


def _v2220_full_build_thread():
    conn=None
    try:
        conn=_v2220_db()
        cache_version=int(_v2220_meta_get(conn,'version',0) or 0)
        if cache_version!=V2220_CACHE_VERSION:
            # Derived cache only. Canonical exact/trade ledgers are untouched.
            # v1 omitted candidate-time continuation_score/prediction_state, so
            # equal-rank rows cannot be safely patched without one source replay.
            conn.execute('DELETE FROM events')
            _v2220_meta_set(conn,'schema',V2220_CACHE_SCHEMA)
            _v2220_meta_set(conn,'version',V2220_CACHE_VERSION)
            _v2220_meta_set(conn,'full_complete',False)
            _v2220_meta_set(conn,'recent_tail_complete',False)
            _v2220_meta_set(conn,'migration_reason','v2238_restore_sealed_score_and_state')
            conn.commit()
            _V2220_CACHE_STATE.update({'mode':'CACHE_V2_REBUILD','source':'CANONICAL_LEDGER_ONCE','full_complete':False,'backfill_pct':0.0})
        count=int(conn.execute('SELECT COUNT(*) FROM events').fetchone()[0]);full_complete=bool(_v2220_meta_get(conn,'full_complete',False))
        # Publish recent 7-day exact results first. Existing cache is preferred;
        # on first use only the chronological ledger tail is read.
        if count>0:
            recent,bad=_v2220_load_selected(conn,True);recent_complete=bool(_v2220_meta_get(conn,'recent_tail_complete',False) or full_complete)
            rdiag={'ledger_raw_rows':len(recent),'ledger_unique_keys':len(recent),'cache_json_errors_v2220':bad,'recent_cache_hit_v2220':True,
                   'recent_tail_complete_v2220':recent_complete,'recent_tail_incomplete_v2220':not recent_complete}
            rinfo={'inode':_v2220_meta_get(conn,'ledger_inode'),'offset':int(_v2220_meta_get(conn,'ledger_offset',0) or 0),'size':int(_v2220_meta_get(conn,'ledger_size',0) or 0),'mtime_ns':int(_v2220_meta_get(conn,'ledger_mtime_ns',0) or 0)}
            recent_snap=_v2220_snapshot(recent,rdiag,rinfo,'RECENT_7D','BACKFILL' if not full_complete else 'CACHE_READY')
            _v2220_set_cache(recent_snap,recent,rdiag,rinfo,building=True,ready=True,cycle_complete=False,stage='RECENT_7D_READY')
            _v2220_publish_cache_snapshot(recent_snap,'RECENT_7D_READY')
            _V2220_CACHE_STATE.update({'mode':'RECENT_7D_READY','recent_rows':len(recent),'cache_hits':1,'source':'DATE_CACHE','full_complete':full_complete})
        else:
            recent,rdiag,rinfo=_v2220_recent_tail_scan(conn)
            recent_snap=_v2220_snapshot(recent,rdiag,rinfo,'RECENT_7D','BACKFILL')
            _v2220_set_cache(recent_snap,recent,rdiag,rinfo,building=True,ready=True,cycle_complete=False,stage='RECENT_7D_READY')
            _v2220_publish_cache_snapshot(recent_snap,'RECENT_7D_READY')
            _V2220_CACHE_STATE.update({'mode':'RECENT_7D_READY','recent_rows':len(recent),'source':'LEDGER_TAIL','full_complete':False})
        if not full_complete:
            diag,info=_v2220_full_scan_to_cache(conn)
        else:
            changed,info=_v2220_incremental_cache(conn)
            diag={'ledger_raw_rows':int(conn.execute('SELECT COUNT(*) FROM events').fetchone()[0]),'ledger_unique_keys':int(conn.execute('SELECT COUNT(*) FROM events').fetchone()[0]),
                  'cache_full_load_v2220':True,'incremental_changed_v2220':bool(changed)}
        selected,bad=_v2220_load_selected(conn,False);diag['cache_json_errors_v2220']=bad;diag['ledger_unique_keys']=len(selected)
        recent,bad_recent=_v2220_load_selected(conn,True);rdiag={'ledger_raw_rows':len(recent),'ledger_unique_keys':len(recent),'cache_json_errors_v2220':bad_recent,'recent_cache_hit_v2220':True}
        recent_snap=_v2220_snapshot(recent,rdiag,info,'RECENT_7D','READY')
        full_snap=_v2220_snapshot(selected,diag,info,'FULL_HISTORY','READY',_v2220_recent_compact(recent_snap))
        _v2209_verify_snapshot(full_snap)
        _v2220_set_cache(full_snap,selected,diag,info,building=False,ready=True,cycle_complete=True,stage='COMPLETE')
        with _V2202_LOCK:_V2202_CACHE.update({'build_finished_ts':now_ts(),'progress_pct_v2209':100.0,'full_scan_count_v2209':int(_V2202_CACHE.get('full_scan_count_v2209') or 0)+int(not full_complete)})
        _v2220_publish_cache_snapshot(full_snap,'READY')
        _V2220_CACHE_STATE.update({'mode':'FULL_READY','recent_rows':len(recent),'full_rows':len(selected),'source':'DATE_CACHE','full_complete':True,'backfill_pct':100.0})
    except Exception as exc:
        _V2220_CACHE_STATE.update({'mode':'ERROR','last_error':f'{type(exc).__name__}: {exc}'})
        _v2209_latch_error('V2220_DATE_CACHE',exc)
    finally:
        if conn is not None:
            try:conn.close()
            except Exception:pass


def _v2220_start_build():
    with _V2202_LOCK:
        if _V2202_CACHE.get('building') or _V2202_CACHE.get('build_attempted_v2209'):return False
        _V2202_CACHE.update({'building':True,'ready':False,'error':None,'build_attempted_v2209':True,'build_started_ts':now_ts(),
            'build_finished_ts':None,'stage_v2209':'V2220_STARTING','cycle_complete_v2209':False,'progress_rows_v2209':0,'progress_bytes_v2209':0,
            'progress_total_bytes_v2209':OUTCOME_LEDGER.stat().st_size if OUTCOME_LEDGER.exists() else 0,'progress_pct_v2209':0.0})
    _v2209_publish(None,'SCANNING')
    threading.Thread(target=_v2220_full_build_thread,name='review-v2220-date-cache-build',daemon=True).start();return True


def _v2220_refresh_snapshot(force=False):
    if not _V2202_CACHE.get('build_attempted_v2209'):_v2220_start_build()
    if _V2202_CACHE.get('building'):
        snap=_V2202_CACHE.get('snapshot') if isinstance(_V2202_CACHE.get('snapshot'),dict) else None
        if snap:
            _v2220_publish_cache_snapshot(snap,'RECENT_7D_READY_FULL_BACKFILL')
            return 'RECENT_7D_READY_FULL_BACKFILL'
        return 'SCANNING'
    if _V2202_CACHE.get('error'):return 'ERROR'
    # Fast steady state: only appended ledger bytes are indexed. Rebuild the
    # compact snapshots when new exact rows arrived or when explicitly forced.
    try:
        conn=_v2220_db();changed,info=_v2220_incremental_cache(conn)
        if changed or force:
            selected,bad=_v2220_load_selected(conn,False);diag={'ledger_raw_rows':len(selected),'ledger_unique_keys':len(selected),'cache_json_errors_v2220':bad,'incremental_snapshot_v2220':True}
            recent,badr=_v2220_load_selected(conn,True);rdiag={'ledger_raw_rows':len(recent),'ledger_unique_keys':len(recent),'cache_json_errors_v2220':badr}
            recent_snap=_v2220_snapshot(recent,rdiag,info,'RECENT_7D','READY')
            full_snap=_v2220_snapshot(selected,diag,info,'FULL_HISTORY','READY',_v2220_recent_compact(recent_snap));_v2209_verify_snapshot(full_snap)
            _v2220_set_cache(full_snap,selected,diag,info,building=False,ready=True,cycle_complete=True,stage='COMPLETE')
            _v2220_publish_cache_snapshot(full_snap,'READY')
        else:_v2220_publish_cache_snapshot(_V2202_CACHE.get('snapshot'),'READY')
        conn.close();return 'READY'
    except Exception as exc:
        _v2209_latch_error('V2220_INCREMENTAL',exc);return 'ERROR'


# Route the existing lifecycle through the date-cache owner.
_v2209_start_build=_v2220_start_build
_v2202_start_build=_v2220_start_build
_v2209_full_build_thread=_v2220_full_build_thread
_v2202_full_build_thread=_v2220_full_build_thread
_v2209_refresh_snapshot=_v2220_refresh_snapshot
_v2202_refresh_snapshot=_v2220_refresh_snapshot


def _v2220_seed_ledger():
    marker=BASE_DIR/'runtime'/'review_v2220_recent7d_date_cache.seeded'
    if marker.exists():return
    ts=now_ts();txt=now_text(ts)
    try:
        append_jsonl(CHANGE_LEDGER,{'schema':'change_verify_ledger_v870','change_id':'V2220-REVIEW-RECENT7D-DATE-CACHE-INCREMENTAL',
            'issue_id':'REVIEW-RESTART-REPEATS-4P5GB-FULL-SCAN-2220','version':'v2220','verify_result':'LOCAL_PASS_SERVER_CHECK','created_ts':ts,'created_at':txt,'writer':VERSION,
            'cause':'Review reread about 4.5GB and hundreds of thousands of duplicate JSONL rows after every restart, delaying the 40k+ exact formula review. Recent market relevance and full-history stability were not separated.',
            'fix':'Publish a recent-7-day exact result first, persist compact exact rows in one date-indexed SQLite cache, backfill the append-only ledger once, and thereafter read only appended bytes. Full-history remains mandatory before live activation.',
            'not_touched':['canonical outcome/trade ledgers','v2215 role contract/hash','live prediction formula/weights/boundary','candidate/S1/Paper','entry/exit','existing v2213 Shadow','auto-buy OFF'],'auto_buy':False})
        append_jsonl(ISSUE_LEDGER,{'schema':'coinbot_single_work_ledger_v870','event_type':'ISSUE','issue_id':'REVIEW-RESTART-REPEATS-4P5GB-FULL-SCAN-2220','status':'CHECK',
            'title':'Review 재시작 때 4.5GB 전체 재독','detail':'최근 7일을 먼저 계산하고 날짜 인덱스 캐시로 전체 누적을 증분화한다. 첫 백필 뒤 재시작 전체 원장 재독을 제거한다.',
            'version':'v2220','created_ts':ts,'created_at':txt,'auto_buy':False})
        marker.parent.mkdir(parents=True,exist_ok=True);marker.write_text(txt,encoding='utf-8')
    except Exception as exc:append_error('v2220_review_ledger_seed',exc)
# v2245 deferred module-level call: _v2220_seed_ledger runs after runtime identity publication.


def run_once__v2220():
    result=_V2220_BASE_RUN_ONCE();result=dict(result) if isinstance(result,dict) else {}
    health=load_json(STATUS,{}) or {};health=dict(health) if isinstance(health,dict) else {}
    snap=_V2202_CACHE.get('snapshot') if isinstance(_V2202_CACHE.get('snapshot'),dict) else {}
    window=snap.get('review_window_v2220') if isinstance(snap.get('review_window_v2220'),dict) else {}
    health.update({'schema':'clean_review_worker_status_v2220','version':VERSION,'build':BUILD_LABEL,
        'phase':'recent7d_ready_full_incremental' if window.get('recent_ready') else 'date_cache_starting',
        'review_window_v2220':window,'review_cache_state_v2220':dict(_V2220_CACHE_STATE),
        'recent_7d_ready_v2220':bool(window.get('recent_ready')),'full_history_ready_v2220':bool(window.get('full_ready')),
        'full_history_activation_required_v2220':True,'historical_ledgers_rewritten':False,'historical_ledgers_deleted':False,'auto_buy':False})
    _atomic_json(STATUS,health)
    result.update({'version':VERSION,'build':BUILD_LABEL,'prediction_validation_v2202':snap,'review_window_v2220':window,'auto_buy':False})
    return result

run_once=run_once__v2220
run_once.__name__='run_once';run_once.__qualname__='run_once'




# =============================================================================
# Review v2.098 / v2227: seal full-cache completion into both canonical runtime
# and health status. v2220 completed the 4.7GB backfill and published a READY
# snapshot, but its final health wrapper did not copy cycle_complete/runtime
# fields, so Main kept rejecting the completed v2219 decomposition.
# No prediction formula, weight, role, candidate, Shadow, entry or exit changes.
# =============================================================================
VERSION='review_worker_v2.098'
BUILD_LABEL='v2227_review_complete_owner_link_2026-07-27'
MAIN_DEPLOY_VERSION=BUILD_LABEL
_V2227_REVIEW_BASE_RUN_ONCE=run_once


def _v2227_full_ready_snapshot():
    snap=_V2202_CACHE.get('snapshot') if isinstance(_V2202_CACHE.get('snapshot'),dict) else {}
    window=snap.get('review_window_v2220') if isinstance(snap.get('review_window_v2220'),dict) else {}
    full_ready=bool(
        snap.get('state')=='PASS' and str(snap.get('snapshot_id') or '').strip() and
        window.get('full_ready') is True and window.get('activation_allowed') is True and
        str(window.get('scope') or '')=='FULL_HISTORY'
    )
    return snap,window,full_ready


def run_once__v2227():
    result=_V2227_REVIEW_BASE_RUN_ONCE()
    result=dict(result) if isinstance(result,dict) else {}
    snap,window,full_ready=_v2227_full_ready_snapshot()
    if full_ready:
        with _V2202_LOCK:
            _V2202_CACHE.update({
                'building':False,'ready':True,'error':None,
                'stage_v2209':'COMPLETE','progress_pct_v2209':100.0,
                'cycle_complete_v2209':True,'build_finished_ts':_V2202_CACHE.get('build_finished_ts') or now_ts(),
                'last_snapshot_refresh_ts_v2209':now_ts(),
            })
    view=_v2209_cache_view()
    runtime=_v2220_publish_cache_snapshot(
        snap if isinstance(snap,dict) and snap else None,
        'READY' if full_ready else _v2209_runtime_state_name(view),
    )
    cycle_complete=bool(full_ready and view.get('ready') and view.get('cycle_complete'))
    decomp=snap.get('factor_role_influence_decomposition_v2219') if isinstance(snap.get('factor_role_influence_decomposition_v2219'),dict) else {}
    health=load_json(STATUS,{}) or {}
    health=dict(health) if isinstance(health,dict) else {}
    health.update({
        'schema':'clean_review_worker_status_v2227','version':VERSION,'build':BUILD_LABEL,'state':'running',
        'phase':'COMPLETE' if cycle_complete else str(view.get('stage') or 'WAITING'),
        'prediction_review_runtime_v2202':runtime,
        'prediction_review_snapshot_id_v2227':snap.get('snapshot_id') if isinstance(snap,dict) else None,
        'analysis_owner_v2227':'strategy_v2_outcome_status_v2133.json',
        'health_only_status_v2227':True,'main_direct_ledger_scan_v2227':False,
        'producer_instance_id_v2208':V2209_PROCESS_INSTANCE_ID,
        'producer_started_ts_v2208':V2209_PROCESS_STARTED_TS,
        'scan_stage_v2209':view.get('stage'),'scan_progress_rows_v2209':view.get('rows'),
        'scan_progress_bytes_v2209':view.get('bytes'),'scan_total_bytes_v2209':view.get('total_bytes'),
        'scan_progress_pct_v2209':100.0 if cycle_complete else view.get('pct'),
        'cycle_complete_v2209':cycle_complete,'cycle_complete_v2227':cycle_complete,
        'review_window_v2220':window,
        'recent_7d_ready_v2220':bool(window.get('recent_ready')),
        'full_history_ready_v2220':bool(window.get('full_ready')),
        'factor_role_influence_state_v2219':decomp.get('state'),
        'factor_exact_events_v2219':int(decomp.get('exact_events_seen') or 0),
        'role_influence_live_active_v2219':False,
        'existing_v2213_shadow_preserved_v2219':True,
        'historical_ledgers_rewritten':False,'historical_ledgers_deleted':False,
        'actual_entry_changed_v2227':False,'actual_exit_changed_v2227':False,'auto_buy':False,
    })
    _atomic_json(STATUS,health)
    result.update({
        'version':VERSION,'build':BUILD_LABEL,'state':'running',
        'prediction_validation_v2202':snap,'prediction_validation_v2202_runtime':runtime,
        'review_window_v2220':window,'cycle_complete_v2227':cycle_complete,'auto_buy':False,
    })
    return result

run_once=run_once__v2227
run_once.__name__='run_once';run_once.__qualname__='run_once'


def _v2227_review_ledger_once():
    marker=BASE_DIR/'runtime'/'review_v2227_complete_owner_link.seeded'
    if marker.exists():return
    ts=now_ts();txt=now_text(ts)
    try:
        append_jsonl(CHANGE_LEDGER,{
            'schema':'change_verify_ledger_v870','change_id':'V2227-REVIEW-COMPLETE-OWNER-LINK',
            'issue_id':'V2220-REVIEW-100PCT-CYCLE-COMPLETE-FALSE','version':'v2227',
            'verify_result':'LOCAL_PASS_SERVER_CHECK','created_ts':ts,'created_at':txt,'writer':VERSION,
            'cause':'The v2220 date-cache full backfill reached COMPLETE/100%, but the final health wrapper omitted the verified cycle_complete/runtime fields. Main therefore rejected the current snapshot and kept v2219 importance results hidden.',
            'fix':'After the verified FULL_HISTORY snapshot is published, seal cycle_complete into the same Review cache, canonical runtime and health status and preserve the producer-instance contract.',
            'not_touched':['prediction formula/weights/positive boundary','role positions/hash','candidate/S1/Paper','structure/trigger/invalid/target/RR','entry/exit','historical ledgers','existing v2213 Shadow','auto-buy OFF'],
            'auto_buy':False,
        })
        append_jsonl(ISSUE_LEDGER,{
            'schema':'coinbot_single_work_ledger_v870','event_type':'ISSUE','issue_id':'V2220-REVIEW-100PCT-CYCLE-COMPLETE-FALSE',
            'status':'DONE','title':'Review 100% 완료본 연결 누락','detail':'완료 snapshot·runtime·health의 cycle_complete와 producer instance를 같은 값으로 봉인했다.',
            'version':'v2227','created_ts':ts,'created_at':txt,'auto_buy':False,
        })
        marker.parent.mkdir(parents=True,exist_ok=True);marker.write_text(txt,encoding='utf-8')
    except Exception as exc:
        try:append_error('v2227_review_ledger',exc)
        except Exception:pass
# v2245 deferred module-level call: _v2227_review_ledger_once runs after runtime identity publication.



# =============================================================================
# Review v2.099 / v2233: restore the actual sealed mainline score contract.
# Historical events already preserve the score/state that existed at candidate
# time.  Earlier analysis stored that value as sealed_live_score but then used
# a replay through the current scorer as the "current" score.  Rows whose old
# connection metadata cannot be replayed therefore appeared as pass=0 even
# though their candidate-time score was sealed.  Use the sealed score/state for
# actual-mainline performance and keep replay only for counterfactual analysis.
# No live formula, weight, boundary, candidate, structure, entry, exit or Shadow
# is changed.  The existing v2220 SQLite date cache is reused.
# =============================================================================
VERSION='review_worker_v2.101'
BUILD_LABEL='v2239_boot_identity_before_ledger_io_2026-07-27'
MAIN_DEPLOY_VERSION=BUILD_LABEL
_V2233_PRE_ROLE_BASE=_V2215_BASE_PREPARE_ROW
_V2233_BASE_FINALIZE=_v2219_finalize
_V2233_BASE_AGGREGATE=_v2206_aggregate
_V2233_BASE_BUILD_SNAPSHOT=_V2220_BASE_BUILD_SNAPSHOT
_V2233_BASE_RUN_ONCE=run_once
_V2233_SCORE_SOURCE_COLLECTOR=None


class _V2233ScoreSourceCollector:
    def __init__(self):
        self.exact=0;self.sealed_score_ready=0;self.sealed_state_ready=0
        self.score_missing=0;self.replay_score_ready=0;self.replay_diff=0
    def add(self,event):
        if not isinstance(event,dict) or not event.get('exact_input_ready_v2206'):return
        self.exact+=1
        source=str(event.get('current_score_source_v2233') or '')
        if source=='SEALED_CANDIDATE_SCORE':self.sealed_score_ready+=1
        else:self.score_missing+=1
        if event.get('sealed_prediction_state_ready_v2233'):self.sealed_state_ready+=1
        if _v2202_num(event.get('replayed_current_score_v2233')) is not None:self.replay_score_ready+=1
        delta=_v2202_num(event.get('sealed_vs_replay_delta_v2233'))
        if delta is not None and abs(delta)>1e-9:self.replay_diff+=1


def _v2233_actual_formula_pass(score,state):
    score=_v2202_num(score);state=str(state or '').strip().upper()
    if score is None:return None
    if state:
        if state=='CONTINUATION_FAVORED':return True
        if state in {'CONTINUATION_UNCLEAR','INVALID_RISK_FAVORED','DATA_MISSING','WAIT_DATA','SOURCE_MISSING','ROLE_CONTRACT_FAIL'}:return False
    return bool(score>0.0)


def _v2233_prepare_before_role(row,previous_fn,current_fn):
    event,reason=_V2233_PRE_ROLE_BASE(row,previous_fn,current_fn)
    if not isinstance(event,dict) or not event.get('exact_input_ready_v2206'):
        return event,reason
    seal=row.get('prediction_input_seal_v2188') if isinstance(row,dict) and isinstance(row.get('prediction_input_seal_v2188'),dict) else {}
    sealed_score=_v2202_num(seal.get('continuation_score'));sealed_state=str(seal.get('prediction_state') or '').strip()
    replay_score=_v2202_num(event.get('current_score'))
    event['replayed_current_score_v2233']=replay_score
    event['replayed_current_state']=event.get('current_formula_state')
    event['replayed_current_formula_pass']=event.get('current_formula_pass')
    event['replayed_current_model_generation']=event.get('current_model_generation')
    event['replayed_current_contract_hash']=event.get('current_contract_hash')
    event['sealed_prediction_state_v2233']=sealed_state or None
    event['sealed_prediction_state_ready_v2233']=bool(sealed_state)
    if sealed_score is not None:
        event['current_score']=sealed_score
        event['current_formula_state_v2210']=sealed_state or 'SEALED_SCORE_STATE_MISSING'
        event['current_formula_pass_v2210']=_v2233_actual_formula_pass(sealed_score,sealed_state)
        event['current_score_source_v2233']='SEALED_CANDIDATE_SCORE'
        event['sealed_vs_replay_delta_v2233']=round(sealed_score-replay_score,9) if replay_score is not None else None
    else:
        event['current_score']=None;event['current_formula_state_v2210']='SOURCE_MISSING';event['current_formula_pass_v2210']=None
        event['current_score_source_v2233']='SOURCE_MISSING';event['sealed_vs_replay_delta_v2233']=None
    collector=_V2233_SCORE_SOURCE_COLLECTOR
    if collector is not None:
        try:collector.add(event)
        except Exception as exc:append_error('v2233_score_source_collect',exc)
    return event,reason



# v2215 and v2219 collectors call this base before consuming the event, so both
# comparisons now see the candidate-time sealed mainline score.
_V2215_BASE_PREPARE_ROW=_v2233_prepare_before_role


def _v2233_aggregate(events,recent_cutoff=None):
    out=_V2233_BASE_AGGREGATE(events,recent_cutoff)
    for label,row in out.items():
        ready=missing=0
        replay={'scored':0,'correct':0,'wrong':0,'pass_count':0,'pass_up':0,'pass_down':0,'false_positive':0,'missed_up':0,
                'pass_close':[],'pass_mfe':[],'pass_mae':[]}
        models=Counter();contracts=Counter()
        for event in events:
            block=(event.get('horizons') or {}).get(label) if isinstance(event,dict) else None
            if not isinstance(block,dict) or block.get('state')!='READY':continue
            if recent_cutoff is not None:
                sampled=_v2202_num(block.get('sampled_ts'))
                if sampled is None or sampled<recent_cutoff:continue
            if not event.get('exact_input_ready_v2206'):continue
            if str(event.get('current_score_source_v2233') or '')=='SEALED_CANDIDATE_SCORE':ready+=1
            else:missing+=1
            replay_pass=event.get('replayed_current_formula_pass')
            replay_score=_v2202_num(event.get('replayed_current_score_v2233'))
            truth=block.get('truth')
            if replay_pass is None or replay_score is None or truth not in ('UP','DOWN','FLAT'):continue
            replay['scored']+=1;models[str(event.get('replayed_current_model_generation') or 'UNKNOWN')]+=1
            contract_hash=str(event.get('replayed_current_contract_hash') or '').strip()
            if contract_hash:contracts[contract_hash]+=1
            direction='UP' if replay_pass else 'DOWN'
            if truth in ('UP','DOWN'):
                replay['correct' if direction==truth else 'wrong']+=1
            if replay_pass:
                replay['pass_count']+=1;replay['pass_up']+=int(truth=='UP');replay['pass_down']+=int(truth=='DOWN')
                close=_v2202_num(block.get('close_pct'));mfe=_v2202_num(block.get('mfe_pct'));mae=_v2202_num(block.get('mae_pct'))
                if close is not None:replay['pass_close'].append(close)
                if mfe is not None:replay['pass_mfe'].append(mfe)
                if mae is not None:replay['pass_mae'].append(mae)
                if truth=='DOWN':replay['false_positive']+=1
            elif truth=='UP':replay['missed_up']+=1
        row['sealed_mainline_score_ready_v2233']=ready
        row['sealed_mainline_score_missing_v2233']=missing
        row['mainline_score_contract_v2233']='candidate-time sealed continuation_score + prediction_state; no historical performance rewrite'
        classification_accuracy=_v2202_pct(replay['correct'],replay['wrong'])
        row['active_formula_replay']={
            'schema':'active_formula_replay','model_generation_counts':dict(models),
            'prediction_contract_hash':next(iter(contracts)) if len(contracts)==1 else None,
            'prediction_contract_hash_counts':dict(contracts),
            'contract_state':'PASS' if len(contracts)==1 else 'CHECK',
            'scored':replay['scored'],'classification_accuracy_pct':classification_accuracy,'accuracy_pct':classification_accuracy,
            'accuracy_meaning':'all pass and hold classifications; not trade win rate',
            'pass_count':replay['pass_count'],'pass_win_rate_pct':_v2202_pct(replay['pass_up'],replay['pass_down']),
            'pass_up':replay['pass_up'],'pass_down':replay['pass_down'],
            'pass_avg_close_pct':_v2202_avg(replay['pass_close']),
            'pass_avg_mfe_pct':_v2202_avg(replay['pass_mfe']),
            'pass_avg_mae_pct':_v2202_avg(replay['pass_mae']),
            'false_positive_count':replay['false_positive'],'missed_up_count':replay['missed_up'],
            'analysis_only':True,'historical_performance_rewritten':False,'new_shadow_created':False,'auto_buy':False,
        }
    return out


_v2206_aggregate=_v2233_aggregate
_v2202_aggregate=_v2233_aggregate


def _v2233_finalize(collector):
    out=dict(_V2233_BASE_FINALIZE(collector) or {})
    usable=max(0,int(collector.exact_events or 0)-int(collector.score_missing or 0))
    out.update({'usable_mainline_score_events_v2233':usable,
                'mainline_score_missing_events_v2233':int(collector.score_missing or 0),
                'mainline_score_contract_v2233':'candidate-time sealed score/state versus relocated replay on same exact axes',
                'historical_current_score_recalculation_v2233':False})
    if int(collector.errors or 0)>0:out['state']='CHECK'
    elif usable<=0:out['state']='SOURCE_MISSING'
    else:out['state']='READY'
    return out

_v2219_finalize=_v2233_finalize


def _v2233_build_snapshot(final_selected,base_diag,source_info):
    global _V2233_SCORE_SOURCE_COLLECTOR
    collector=_V2233ScoreSourceCollector();_V2233_SCORE_SOURCE_COLLECTOR=collector
    try:snap=dict(_V2233_BASE_BUILD_SNAPSHOT(final_selected,base_diag,source_info) or {})
    finally:_V2233_SCORE_SOURCE_COLLECTOR=None
    contract={'schema':'sealed_mainline_score_contract_v2233','state':'PASS' if collector.sealed_score_ready>0 else 'SOURCE_MISSING',
        'exact_events_seen':collector.exact,'sealed_score_ready':collector.sealed_score_ready,
        'sealed_score_missing':collector.score_missing,'sealed_state_ready':collector.sealed_state_ready,
        'replay_score_ready_reference_only':collector.replay_score_ready,
        'sealed_vs_replay_different':collector.replay_diff,
        'actual_mainline_source':'prediction_input_seal_v2188.continuation_score + prediction_state',
        'replay_role':'counterfactual comparison only','past_rows_recalculated_as_current':False,
        'historical_rows_rewritten':False,'historical_rows_deleted':False,'auto_buy':False}
    snap.update({'schema':'prediction_review_snapshot_v2233','owner':VERSION,'version':VERSION,'build':BUILD_LABEL,
        'sealed_mainline_score_contract_v2233':contract,'rise_prediction_live_changed_v2233':False,
        'existing_v2213_shadow_preserved_v2233':True,'new_shadow_created_v2233':False,
        'candidate_rows_deleted_v2233':0,'auto_buy':False})
    return snap

# v2220 date-cache lifecycle calls its captured base builder. Replace that one
# owner so a restart recalculates from the existing compact SQLite rows without
# rereading the 4.7GB canonical ledger.
_V2220_BASE_BUILD_SNAPSHOT=_v2233_build_snapshot
_v2202_build_snapshot=_v2233_build_snapshot


def run_once__v2238():
    result=_V2233_BASE_RUN_ONCE();result=dict(result) if isinstance(result,dict) else {}
    snap=_V2202_CACHE.get('snapshot') if isinstance(_V2202_CACHE.get('snapshot'),dict) else None
    runtime=_v2209_publish(snap,_v2209_runtime_state_name())
    published=load_json(OUTCOME_STATUS,{}) or {}
    analysis=published.get('review_analysis_v2238') if isinstance(published.get('review_analysis_v2238'),dict) else {}
    canonical=analysis.get('snapshot') if isinstance(analysis.get('snapshot'),dict) else {}
    health=load_json(STATUS,{}) or {};health=dict(health) if isinstance(health,dict) else {}
    health.update({
        'schema':'clean_review_worker_status_v2238','version':VERSION,'build':BUILD_LABEL,'state':'running',
        'phase':analysis.get('state') or runtime.get('state') or 'WAITING',
        'prediction_review_runtime_v2202':runtime,'prediction_review_snapshot_id_v2238':analysis.get('snapshot_id'),
        'analysis_owner_v2238':'strategy_v2_outcome_status_v2133.json.review_analysis_v2238',
        'single_analysis_publisher_v2238':True,'health_only_status_v2238':True,'main_direct_ledger_scan_v2238':False,
        'producer_instance_id_v2208':analysis.get('producer_instance_id'),'producer_started_ts_v2208':analysis.get('producer_started_ts'),
        'cycle_complete_v2209':bool(analysis.get('cycle_complete')),'cycle_complete_v2238':bool(analysis.get('cycle_complete')),
        'recent_7d_ready_v2238':bool(analysis.get('recent_7d_ready')),'full_history_ready_v2238':bool(analysis.get('full_history_ready')),
        'analysis_ready_v2238':bool(analysis.get('analysis_ready')),
        'factor_exact_events_v2238':int(analysis.get('exact_events') or 0),
        'price_result_events_v2238':int(analysis.get('price_result_events') or 0),
        'sealed_mainline_score_ready_v2238':int(analysis.get('sealed_score_ready') or 0),
        'sealed_mainline_score_missing_v2238':int(analysis.get('sealed_score_missing') or 0),
        'candidate_quality_sample_count_v2238':int(analysis.get('candidate_quality_sample_count') or 0),
        'historical_current_score_recalculation_v2233':False,'rise_prediction_live_changed_v2238':False,
        'existing_v2213_shadow_preserved_v2238':True,'auto_buy':False,
    })
    _atomic_json(STATUS,health)
    result.update({'version':VERSION,'build':BUILD_LABEL,'prediction_validation_v2202':canonical,
        'prediction_validation_v2202_runtime':runtime,'review_analysis_v2238':analysis,'auto_buy':False})
    return result


run_once=run_once__v2238
run_once.__name__='run_once';run_once.__qualname__='run_once'


def _v2233_review_ledger_once():
    marker=BASE_DIR/'runtime'/'review_v2233_sealed_live_score_contract.seeded'
    if marker.exists():return
    ts=now_ts();txt=now_text(ts)
    try:
        append_jsonl(CHANGE_LEDGER,{'schema':'change_verify_ledger_v870','change_id':'V2233-SEALED-LIVE-SCORE-EXACT-ANALYSIS-RESTORE',
            'issue_id':'V2230-EXACT-READY-BUT-FORMULA-PASS-ZERO','version':'v2233','verify_result':'LOCAL_PASS_SERVER_CHECK',
            'created_ts':ts,'created_at':txt,'writer':VERSION,
            'cause':'Review preserved candidate-time continuation_score as sealed_live_score but ignored it and treated a replay through the current scorer as the actual mainline score. Old exact connection metadata could not always replay, so 56,108 exact events rendered pass=0 and role influence=0.',
            'fix':'Use the candidate-time sealed continuation_score and prediction_state as actual mainline truth. Keep the relocated scorer only as a counterfactual on the same sealed axes. Missing sealed score remains SOURCE_MISSING, never zero. Reuse the existing v2220 SQLite cache.',
            'not_touched':['live rise formula/weights/positive boundary','candidate/S1/Paper','structure/trigger/invalid/target/RR','entry/exit','historical ledgers','existing v2213 Shadow','auto-buy OFF'],'auto_buy':False})
        append_jsonl(ISSUE_LEDGER,{'schema':'coinbot_single_work_ledger_v870','event_type':'ISSUE','issue_id':'V2230-EXACT-READY-BUT-FORMULA-PASS-ZERO',
            'status':'CHECK','title':'exact 표본은 있는데 상승예측 통과가 0으로 표시됨',
            'detail':'진입 당시 봉인 점수 대신 현재 코드 재생값을 실제 본선 점수로 읽은 오류. v2233에서 봉인 점수·상태를 실제값으로 복구하고 기존 cache로 다시 집계한다.',
            'version':'v2233','created_ts':ts,'created_at':txt,'auto_buy':False})
        marker.parent.mkdir(parents=True,exist_ok=True);marker.write_text(txt,encoding='utf-8')
    except Exception as exc:append_error('v2233_review_ledger',exc)
# v2238: close the repeated split-writer/source-loss issue without changing live trading.
def _v2238_review_ledger_once():
    marker=BASE_DIR/'runtime'/'review_v2238_single_publisher_cache_truth.seeded'
    if marker.exists():return
    ts=now_ts();txt=now_text(ts)
    try:
        append_jsonl(CHANGE_LEDGER,{'schema':'change_verify_ledger_v870','change_id':'V2238-REVIEW-SINGLE-PUBLISHER-CACHE-TRUTH',
            'issue_id':'V2213-V2233-REVIEW-READY-EXACT-ZERO-REPEAT','version':'v2238','verify_result':'LOCAL_PASS_SERVER_CHECK',
            'created_ts':ts,'created_at':txt,'writer':VERSION,
            'cause':'The compact Review cache omitted candidate-time continuation_score/prediction_state, and snapshot/runtime/health completion were published by separate wrappers. A 100% cache could therefore show cycle_complete false and exact pass zero.',
            'fix':'Preserve sealed score/state in cache schema v2, rebuild only the derived cache once from the append-only canonical source, and publish snapshot/runtime/completion/quality counts as one atomic review_analysis_v2238 block. Health mirrors that block; Main reads only it.',
            'not_touched':['canonical exact/trade ledgers','live prediction formula/weights/boundary','candidate/S1/Paper','structure/trigger/invalid/target/RR','entry/exit','existing v2213 Shadow','auto-buy OFF'],'auto_buy':False})
        append_jsonl(ISSUE_LEDGER,{'schema':'coinbot_single_work_ledger_v870','event_type':'ISSUE','issue_id':'V2213-V2233-REVIEW-READY-EXACT-ZERO-REPEAT',
            'status':'DONE','title':'Review 100%인데 exact 0 반복 원인 단일수리',
            'detail':'파생 cache가 진입 당시 점수·상태를 버린 원인과 상태 writer 분리를 함께 종료. cache v2 1회 복구 후 증분만 사용.',
            'version':'v2238','created_ts':ts,'created_at':txt,'auto_buy':False})
        marker.parent.mkdir(parents=True,exist_ok=True);marker.write_text(txt,encoding='utf-8')
    except Exception as exc:append_error('v2238_review_ledger',exc)


# =============================================================================
# Review v2.102 / v2243: bounded recent-500 exact analysis and oversized
# derived-cache cleanup. Canonical append-only ledgers remain untouched.
# =============================================================================
VERSION='review_worker_v2.102'
BUILD_LABEL='v2243_recent500_exact_bounded_review_cache_cleanup_2026-07-27'
MAIN_DEPLOY_VERSION=BUILD_LABEL
V2243_SAMPLE_CAP=500
V2243_SCAN_MAX_RAW_ROWS=20000
V2243_SCAN_MAX_BYTES=128*1024*1024
V2243_REFRESH_MIN_SEC=20.0
V2243_CACHE_CLEAN_STATUS=BASE_DIR/'runtime'/'review_v2243_cache_cleanup.json'
V2243_OLD_DERIVED_CACHE=BASE_DIR/'runtime'/'review_exact_day_cache_v2220.sqlite3'
_V2243_SELECTED_KEYS=set()
_V2243_BASE_READ_STATE_ROWS=_v2202_read_state_rows
_V2243_BASE_APPEND_ERROR=append_error


def append_error(where:str,exc:BaseException)->None:  # type: ignore[override]
    # Error reporting must never recursively terminate Review when the disk is
    # full. The next health write can report the original error after space is
    # available.
    try:_V2243_BASE_APPEND_ERROR(where,exc)
    except OSError:pass
    except Exception:pass


def _v2243_atomic_status(path,obj):
    try:_atomic_json(path,obj);return True
    except OSError:return False
    except Exception:return False


def _v2243_tail_keep(path:Path,keep_bytes:int=1024*1024):
    try:
        old=int(path.stat().st_size)
        if old<=keep_bytes:return 0
        with path.open('rb') as handle:
            handle.seek(max(0,old-keep_bytes));data=handle.read()
        cut=data.find(b'\n')
        if cut>=0 and cut+1<len(data):data=data[cut+1:]
        tmp=path.with_name(path.name+f'.v2243.tmp.{os.getpid()}')
        with tmp.open('wb') as handle:
            handle.write(data);handle.flush();os.fsync(handle.fileno())
        os.replace(tmp,path);return max(0,old-len(data))
    except Exception:
        try:tmp.unlink(missing_ok=True)
        except Exception:pass
        return 0


def _v2243_cleanup_derived_cache_once():
    marker=BASE_DIR/'runtime'/'review_v2243_oversized_cache_removed.seeded'
    rows=[];freed=0;errors=[]
    targets=[V2243_OLD_DERIVED_CACHE,
             Path(str(V2243_OLD_DERIVED_CACHE)+'-wal'),
             Path(str(V2243_OLD_DERIVED_CACHE)+'-shm'),
             Path(str(V2243_OLD_DERIVED_CACHE)+'-journal')]
    try:
        for p in (BASE_DIR/'runtime').glob('review_exact_day_cache_v2220.sqlite3.tmp*'):
            targets.append(p)
    except Exception:pass
    seen=set()
    for path in targets:
        if str(path) in seen:continue
        seen.add(str(path))
        try:size=int(path.stat().st_size)
        except FileNotFoundError:continue
        except Exception as exc:
            errors.append({'path':str(path),'error':f'{type(exc).__name__}: {exc}'});continue
        try:path.unlink(missing_ok=True);freed+=size;rows.append({'path':str(path.relative_to(BASE_DIR)),'bytes':size,'state':'DELETED'})
        except Exception as exc:errors.append({'path':str(path),'error':f'{type(exc).__name__}: {exc}'})
    # Repeated ENOSPC tracebacks are diagnostics, not ledgers. Preserve only the
    # newest 1 MiB so the failure proof remains visible without growing again.
    error_freed=_v2243_tail_keep(ERROR,1024*1024) if ERROR.exists() else 0
    if error_freed:
        freed+=error_freed;rows.append({'path':str(ERROR.relative_to(BASE_DIR)),'bytes':error_freed,'state':'TAIL_1MB'})
    payload={'schema':'review_cache_cleanup_v2243','version':VERSION,'build':BUILD_LABEL,
             'updated_ts':now_ts(),'updated_text':now_text(),'freed_bytes':freed,
             'removed':rows,'errors':errors,'canonical_ledgers_deleted':0,
             'historical_ledgers_rewritten':False,'shadow_deleted':0,'auto_buy':False}
    _v2243_atomic_status(V2243_CACHE_CLEAN_STATUS,payload)
    try:
        marker.parent.mkdir(parents=True,exist_ok=True);marker.write_text(now_text(),encoding='utf-8')
    except Exception:pass
    return payload


def _v2243_row_is_exact_result(row):
    if not isinstance(row,dict):return False
    generation=str(row.get('generation') or '')
    if generation and generation!=GENERATION:return False
    if not str(row.get('event_key') or '').strip():return False
    seal=row.get('prediction_input_seal_v2188') if isinstance(row.get('prediction_input_seal_v2188'),dict) else {}
    if not (isinstance(seal.get('axes'),dict) and seal.get('axes') and isinstance(seal.get('connections'),dict) and seal.get('connections')):return False
    return any(_v2202_horizon_raw(row,label) is not None for label in ('30m','1h','3h','6h'))


def _v2243_row_sort_value(row):
    return max(_v2202_num(row.get('finalized_ts')) or 0.0,
               _v2202_num(row.get('last_seen_ts')) or 0.0,
               _v2202_event_time(row) or 0.0)


def _v2243_prune(selected):
    if len(selected)<=V2243_SAMPLE_CAP:return selected
    ordered=sorted(selected.items(),key=lambda kv:(_v2243_row_sort_value(kv[1][1]),kv[1][0]),reverse=True)[:V2243_SAMPLE_CAP]
    return dict(ordered)


def _v2243_scan_recent500():
    started=time.monotonic();selected={};diag={'ledger_raw_rows':0,'ledger_json_errors':0,
        'wrong_generation_raw':0,'missing_event_key_raw':0,'duplicates_removed':0,
        'bounded_recent_exact_v2243':True,'sample_cap_v2243':V2243_SAMPLE_CAP,
        'scan_max_raw_rows_v2243':V2243_SCAN_MAX_RAW_ROWS,'scan_max_bytes_v2243':V2243_SCAN_MAX_BYTES}
    inode=None;size=0;mtime_ns=0;read_bytes=0
    if OUTCOME_LEDGER.exists():
        st=OUTCOME_LEDGER.stat();inode=getattr(st,'st_ino',None);size=int(st.st_size);mtime_ns=int(st.st_mtime_ns)
        for raw,read_bytes,_ in _v2220_reverse_lines(OUTCOME_LEDGER,max_bytes=V2243_SCAN_MAX_BYTES):
            diag['ledger_raw_rows']+=1
            if diag['ledger_raw_rows']>V2243_SCAN_MAX_RAW_ROWS:break
            try:row=json.loads(raw.decode('utf-8','replace'))
            except Exception:
                diag['ledger_json_errors']+=1;continue
            if not isinstance(row,dict):continue
            generation=str(row.get('generation') or '')
            if generation and generation!=GENERATION:
                diag['wrong_generation_raw']+=1;continue
            if not str(row.get('event_key') or '').strip():
                diag['missing_event_key_raw']+=1;continue
            if not _v2243_row_is_exact_result(row):continue
            _v2202_accept_raw(selected,row,1,diag)
            if len(selected)>=V2243_SAMPLE_CAP:
                break
    selected=_v2243_prune(selected)
    diag.update({'ledger_unique_keys':len(selected),'selected_exact_events_v2243':len(selected),
        'tail_bytes_read_v2243':int(read_bytes),'canonical_ledger_size_bytes_v2243':int(size),
        'full_history_scan_v2243':False,'full_history_activation_required_v2220':False,
        'scan_sec':round(time.monotonic()-started,3)})
    info={'inode':inode,'offset':size,'size':size,'mtime_ns':mtime_ns,
          'tail_bytes':int(read_bytes),'scan_sec':diag['scan_sec'],'sample_cap':V2243_SAMPLE_CAP}
    return selected,diag,info


def _v2202_read_state_rows():  # type: ignore[override]
    rows,mtime=_V2243_BASE_READ_STATE_ROWS()
    if _V2243_SELECTED_KEYS:
        rows=[r for r in rows if str(r.get('event_key') or '') in _V2243_SELECTED_KEYS]
    rows.sort(key=_v2243_row_sort_value,reverse=True)
    return rows[:V2243_SAMPLE_CAP],mtime


def _v2243_build_snapshot(selected,diag,info):
    global _V2243_SELECTED_KEYS
    _V2243_SELECTED_KEYS=set(selected.keys())
    try:snap=dict(_v2202_build_snapshot(selected,diag,info) or {})
    finally:_V2243_SELECTED_KEYS=set()
    window={'schema':'review_window_v2243','scope':'RECENT_EXACT_500','sample_cap':V2243_SAMPLE_CAP,
            'sample_count':len(selected),'complete':True,'recent_ready':True,'full_ready':False,
            'full_history_scanned':False,'source':'canonical outcome ledger tail + append-only incremental',
            'derived_sqlite_cache_used':False,'canonical_ledger_rewritten':False,
            'canonical_ledger_deleted':False,'auto_buy':False}
    snap.update({'schema':'prediction_review_snapshot_v2243','owner':VERSION,'version':VERSION,'build':BUILD_LABEL,
        'review_window_v2243':window,
        'review_window_v2220':{'schema':'review_window_v2243_compat','primary_days':None,'scope':'RECENT_EXACT_500',
            'full_history_state':'NOT_REQUESTED','recent_ready':True,'recent_partial':False,'full_ready':False,
            'activation_allowed':False,'date_index_cache':None,'canonical_ledger_rewritten':False,
            'canonical_ledger_deleted':False,'auto_buy':False},
        'bounded_sample_policy_v2243':'latest max 500 exact events by sealed decision event; append-only incremental; no full replay',
        'date_index_cache_v2220':{'path':None,'derived_cache_only':True,'deleted_v2243':True,'single_owner':VERSION},
        'historical_ledgers_rewritten':False,'historical_ledgers_deleted':False,'new_shadow_created':False,'auto_buy':False})
    return snap


def _v2243_publish(snapshot=None,runtime_state=None):
    view=_v2209_cache_view();requested=str(runtime_state or _v2209_runtime_state_name(view))
    current=bool(isinstance(snapshot,dict) and snapshot.get('state')=='PASS' and str(snapshot.get('snapshot_id') or '').strip())
    canonical=dict(snapshot) if current else _v2209_placeholder_snapshot(requested,view)
    canonical.update({'owner':VERSION,'version':VERSION,'build':BUILD_LABEL,
        'producer_instance_id_v2208':V2209_PROCESS_INSTANCE_ID,'producer_started_ts_v2208':V2209_PROCESS_STARTED_TS,
        'contract_id_v2208':V2208_CONTRACT_ID})
    window=canonical.get('review_window_v2243') if isinstance(canonical.get('review_window_v2243'),dict) else {}
    diagnostics=canonical.get('diagnostics') if isinstance(canonical.get('diagnostics'),dict) else {}
    decomp=canonical.get('factor_role_influence_decomposition_v2219') if isinstance(canonical.get('factor_role_influence_decomposition_v2219'),dict) else {}
    score_contract=canonical.get('sealed_mainline_score_contract_v2233') if isinstance(canonical.get('sealed_mainline_score_contract_v2233'),dict) else {}
    quality=canonical.get('trade_outcome_compare_v2210') if isinstance(canonical.get('trade_outcome_compare_v2210'),dict) else {}
    bounded_complete=bool(current and window.get('complete') is True and int(window.get('sample_count') or 0)>0)
    sealed_ready=int(score_contract.get('sealed_score_ready') or 0);sealed_missing=int(score_contract.get('sealed_score_missing') or 0)
    exact=int(decomp.get('usable_mainline_score_events_v2233') or decomp.get('exact_events_seen') or diagnostics.get('exact_sealed_events_v2206') or diagnostics.get('valid_events') or 0)
    price=int(diagnostics.get('outcome_events_with_horizon') or 0)
    decomp_ready=bool(str(decomp.get('state') or '') in {'READY','PASS'} and exact>0)
    score_ready=bool(score_contract.get('state')=='PASS' and sealed_ready>0)
    analysis_ready=bool(bounded_complete and decomp_ready and score_ready)
    lifecycle='COMPLETE_500' if bounded_complete else ('BUILDING' if requested in {'SCANNING','BUILDING'} or view.get('building') else requested)
    canonical.update({'scan_state_v2209':lifecycle,'scan_stage_v2209':'COMPLETE_500' if bounded_complete else view.get('stage'),
        'scan_progress_rows_v2209':view.get('rows'),'scan_progress_bytes_v2209':view.get('bytes'),
        'scan_total_bytes_v2209':view.get('total_bytes'),'scan_progress_pct_v2209':100.0 if bounded_complete else view.get('pct'),
        'scan_error_stage_v2209':view.get('error_stage'),'scan_error_v2209':view.get('error'),
        'full_scan_count_v2209':0,'incremental_scan_count_v2209':view.get('incremental_scan_count'),
        'cycle_complete_v2209':bounded_complete})
    started=view.get('build_started_ts') or V2209_PROCESS_STARTED_TS
    runtime={'schema':'prediction_review_runtime_v2243','owner':VERSION,'state':lifecycle,'updated_ts':now_ts(),'updated_text':now_text(),
        'building':not bounded_complete and bool(view.get('building')),'error':view.get('error'),'error_stage_v2209':view.get('error_stage'),
        'error_trace_v2209':view.get('error_trace'),'build_started_ts':started,
        'build_elapsed_sec':round(max(0.0,now_ts()-float(started)),3) if started else 0.0,
        'last_completed_snapshot_id':canonical.get('snapshot_id') if bounded_complete else None,
        'scan_stage_v2209':canonical.get('scan_stage_v2209'),'scan_progress_rows_v2209':view.get('rows'),
        'scan_progress_bytes_v2209':view.get('bytes'),'scan_total_bytes_v2209':view.get('total_bytes'),
        'scan_progress_pct_v2209':canonical.get('scan_progress_pct_v2209'),'last_progress_ts_v2209':view.get('last_progress_ts'),
        'full_scan_count_v2209':0,'incremental_scan_count_v2209':view.get('incremental_scan_count'),
        'cycle_complete_v2209':bounded_complete,'analysis_ready_v2238':analysis_ready,
        'recent_7d_ready_v2238':bounded_complete,'full_history_ready_v2238':False,
        'bounded_recent500_ready_v2243':bounded_complete,'sample_cap_v2243':V2243_SAMPLE_CAP,
        'main_recalculation_count':0,'analysis_status_file':'strategy_v2_outcome_status_v2133.json',
        'health_status_file':'clean_review_worker_status.json','canonical_fields_preserved_during_tracking_write':True,
        'exact_input_horizon_contract_v2206':True,'contract_id_v2208':V2208_CONTRACT_ID,
        'producer_instance_id_v2208':V2209_PROCESS_INSTANCE_ID,'producer_started_ts_v2208':V2209_PROCESS_STARTED_TS,
        'previous_process_snapshot_reused_v2208':False,'auto_buy':False}
    analysis={'schema':'review_analysis_v2238','owner':VERSION,'version':VERSION,'build':BUILD_LABEL,
        'publisher':'_v2243_publish','single_publisher':True,'state':lifecycle,
        'updated_ts':runtime['updated_ts'],'updated_text':runtime['updated_text'],
        'producer_instance_id':V2209_PROCESS_INSTANCE_ID,'producer_started_ts':V2209_PROCESS_STARTED_TS,
        'snapshot_id':canonical.get('snapshot_id'),'cycle_complete':bounded_complete,
        'recent_7d_ready':bounded_complete,'full_history_ready':False,'analysis_ready':analysis_ready,
        'bounded_recent500_ready':bounded_complete,'sample_cap':V2243_SAMPLE_CAP,'selected_events':int(window.get('sample_count') or 0),
        'exact_events':exact,'price_result_events':price,'sealed_score_ready':sealed_ready,'sealed_score_missing':sealed_missing,
        'candidate_quality_sample_count':int(quality.get('sample_count') or 0),
        'candidate_quality_wins':int(quality.get('wins') or 0),'candidate_quality_losses':int(quality.get('losses') or 0),
        'snapshot':canonical,'runtime':runtime,'canonical_source':'strategy_v2_outcome_status_v2133.json.review_analysis_v2238',
        'historical_ledgers_rewritten':False,'historical_ledgers_deleted':False,'live_formula_changed':False,
        'candidate_filter_changed':False,'new_shadow_created':False,'auto_buy':False}
    with _V2209_PUBLISH_LOCK:
        outcome=load_json(OUTCOME_STATUS,{}) or {};outcome=dict(outcome) if isinstance(outcome,dict) else {}
        outcome.update({'version':VERSION,'build':BUILD_LABEL,'review_analysis_v2238':analysis,
            'prediction_validation_v2202':canonical,'prediction_validation_v2202_runtime':runtime,
            'prediction_analysis_owner_v2202':f'{VERSION} -> review_analysis_v2238',
            'clean_review_worker_status_role_v2202':'health_only','main_direct_ledger_scan_v2202':False,'auto_buy':False})
        _atomic_json(OUTCOME_STATUS,outcome)
    return runtime


def _v2243_build_thread():
    try:
        selected,diag,info=_v2243_scan_recent500();snapshot=_v2243_build_snapshot(selected,diag,info);_v2209_verify_snapshot(snapshot)
        tail=int(info.get('tail_bytes') or 0)
        try:state_mtime=OUTCOME_STATE.stat().st_mtime_ns
        except Exception:state_mtime=0
        with _V2202_LOCK:
            _V2202_CACHE.update({'building':False,'ready':True,'error':None,'error_latched_v2209':False,
                'by_key':selected,'diagnostics':diag,'ledger_inode':info.get('inode'),'ledger_offset':info.get('offset'),
                'ledger_size':info.get('size'),'ledger_mtime_ns':info.get('mtime_ns'),'state_mtime_ns':state_mtime,
                'snapshot':snapshot,'build_finished_ts':now_ts(),'stage_v2209':'COMPLETE_500','cycle_complete_v2209':True,
                'progress_rows_v2209':len(selected),'progress_bytes_v2209':tail,'progress_total_bytes_v2209':tail,
                'progress_pct_v2209':100.0,'full_scan_count_v2209':0,'last_snapshot_refresh_ts_v2209':now_ts()})
        _v2243_publish(snapshot,'READY')
    except Exception as exc:_v2209_latch_error('V2243_RECENT500_BUILD',exc)


def _v2243_start_build():
    with _V2202_LOCK:
        if _V2202_CACHE.get('building') or _V2202_CACHE.get('build_attempted_v2209'):return False
        _V2202_CACHE.update({'building':True,'ready':False,'error':None,'build_attempted_v2209':True,
            'build_started_ts':now_ts(),'build_finished_ts':None,'stage_v2209':'RECENT_500_TAIL_SCAN',
            'cycle_complete_v2209':False,'progress_rows_v2209':0,'progress_bytes_v2209':0,
            'progress_total_bytes_v2209':V2243_SCAN_MAX_BYTES,'progress_pct_v2209':0.0,'full_scan_count_v2209':0})
    _v2243_publish(None,'SCANNING')
    threading.Thread(target=_v2243_build_thread,name='review-v2243-recent500',daemon=True).start();return True


def _v2243_incremental():
    with _V2202_LOCK:
        if not _V2202_CACHE.get('ready') or _V2202_CACHE.get('building'):return False,None
        selected=dict(_V2202_CACHE.get('by_key') or {});diag=dict(_V2202_CACHE.get('diagnostics') or {})
        inode=_V2202_CACHE.get('ledger_inode');offset=int(_V2202_CACHE.get('ledger_offset') or 0)
    try:st=OUTCOME_LEDGER.stat()
    except FileNotFoundError:return False,None
    if inode not in (None,getattr(st,'st_ino',None)) or st.st_size<offset:
        # Rotation does not trigger a full replay. Rebuild the same bounded tail.
        with _V2202_LOCK:_V2202_CACHE.update({'build_attempted_v2209':False,'ready':False,'building':False})
        _v2243_start_build();return False,None
    if st.st_size==offset:return False,{'inode':getattr(st,'st_ino',None),'offset':offset,'size':st.st_size,'mtime_ns':st.st_mtime_ns}
    changed=False;raw_added=0;bad_added=0
    with OUTCOME_LEDGER.open('rb') as handle:
        handle.seek(offset)
        for raw in handle:
            raw_added+=1
            try:row=json.loads(raw.decode('utf-8','replace'))
            except Exception:bad_added+=1;continue
            if not _v2243_row_is_exact_result(row):continue
            key=str(row.get('event_key') or '').strip();old=selected.get(key)
            local={'wrong_generation_raw':0,'missing_event_key_raw':0,'duplicates_removed':0}
            _v2202_accept_raw(selected,row,1,local)
            if selected.get(key)!=old:changed=True
        new_offset=handle.tell()
    selected=_v2243_prune(selected)
    diag['ledger_raw_rows']=int(diag.get('ledger_raw_rows') or 0)+raw_added
    diag['ledger_json_errors']=int(diag.get('ledger_json_errors') or 0)+bad_added
    diag['ledger_unique_keys']=len(selected);diag['selected_exact_events_v2243']=len(selected)
    info={'inode':getattr(st,'st_ino',None),'offset':new_offset,'size':st.st_size,'mtime_ns':st.st_mtime_ns,'tail_bytes':int(diag.get('tail_bytes_read_v2243') or 0)}
    with _V2202_LOCK:
        _V2202_CACHE.update({'by_key':selected,'diagnostics':diag,'ledger_inode':info['inode'],'ledger_offset':new_offset,
            'ledger_size':st.st_size,'ledger_mtime_ns':st.st_mtime_ns,
            'incremental_scan_count_v2209':int(_V2202_CACHE.get('incremental_scan_count_v2209') or 0)+1})
    return changed,info


def _v2243_refresh_snapshot(force=False):
    if not _V2202_CACHE.get('build_attempted_v2209'):_v2243_start_build()
    if _V2202_CACHE.get('building'):return 'SCANNING'
    if _V2202_CACHE.get('error'):return 'ERROR'
    try:
        changed,info=_v2243_incremental()
        if info is None:return 'SCANNING' if _V2202_CACHE.get('building') else 'READY'
        try:state_mtime=OUTCOME_STATE.stat().st_mtime_ns
        except Exception:state_mtime=0
        state_changed=state_mtime!=_V2202_CACHE.get('state_mtime_ns')
        last=float(_V2202_CACHE.get('last_snapshot_refresh_ts_v2209') or 0.0)
        if not (changed or state_changed or force) or (not force and now_ts()-last<V2243_REFRESH_MIN_SEC):
            _v2243_publish(_V2202_CACHE.get('snapshot'),'READY');return 'READY'
        with _V2202_LOCK:
            selected=dict(_V2202_CACHE.get('by_key') or {});diag=dict(_V2202_CACHE.get('diagnostics') or {})
            if info is None:info={'inode':_V2202_CACHE.get('ledger_inode'),'offset':_V2202_CACHE.get('ledger_offset'),'size':_V2202_CACHE.get('ledger_size'),'mtime_ns':_V2202_CACHE.get('ledger_mtime_ns'),'tail_bytes':int(diag.get('tail_bytes_read_v2243') or 0)}
        snapshot=_v2243_build_snapshot(selected,diag,info);_v2209_verify_snapshot(snapshot)
        with _V2202_LOCK:
            _V2202_CACHE.update({'snapshot':snapshot,'state_mtime_ns':state_mtime,'stage_v2209':'COMPLETE_500',
                'cycle_complete_v2209':True,'last_snapshot_refresh_ts_v2209':now_ts()})
        _v2243_publish(snapshot,'READY');return 'READY'
    except Exception as exc:_v2209_latch_error('V2243_INCREMENTAL',exc);return 'ERROR'


# Route all existing later callers through the bounded owner.
_v2209_publish=_v2243_publish
_v2202_publish=_v2243_publish
_v2203_publish=_v2243_publish
_v2209_start_build=_v2243_start_build
_v2202_start_build=_v2243_start_build
_v2209_full_build_thread=_v2243_build_thread
_v2202_full_build_thread=_v2243_build_thread
_v2209_refresh_snapshot=_v2243_refresh_snapshot
_v2202_refresh_snapshot=_v2243_refresh_snapshot


def _v2243_review_ledger_once():
    marker=BASE_DIR/'runtime'/'review_v2243_recent500_bounded.seeded'
    if marker.exists():return
    ts=now_ts();txt=now_text(ts)
    append_jsonl(CHANGE_LEDGER,{'schema':'change_verify_ledger_v870','change_id':'V2243-RECENT500-BOUNDED-REVIEW',
        'issue_id':'V2243-REVIEW-501675-ROWS-DISK-FULL','version':'v2243','verify_result':'LOCAL_PASS_SERVER_CHECK',
        'created_ts':ts,'created_at':txt,'writer':VERSION,
        'cause':'Review replayed 501,675 raw outcome rows and built a multi-GB derived SQLite cache. The filesystem reached ENOSPC, so outcome append, fsync, error log and health status all failed.',
        'fix':'Delete only the rebuildable v2220 SQLite cache/WAL/SHM, keep the latest maximum 500 sealed exact events, scan at most 20,000 tail rows/128MiB on restart, and thereafter consume only appended bytes. Error log is capped to the newest 1MiB.',
        'not_touched':['OPEN/CLOSED/trade/decision/exact/change/issue canonical ledgers','historical rows','prediction formula/weights','candidate/S1/Paper','entry/exit','existing v2213 Shadow','auto-buy OFF'],'auto_buy':False})
    append_jsonl(ISSUE_LEDGER,{'schema':'coinbot_single_work_ledger_v870','event_type':'ISSUE',
        'issue_id':'V2243-REVIEW-501675-ROWS-DISK-FULL','status':'DONE','title':'Review 50만행 파생 cache로 디스크 가득 참',
        'detail':'원본 원장은 보존하고 과대 파생 cache만 삭제. 후보품질은 최근 exact 최대 500건으로 제한하고 이후 append만 증분 처리.',
        'version':'v2243','created_ts':ts,'created_at':txt,'auto_buy':False})
    marker.parent.mkdir(parents=True,exist_ok=True);marker.write_text(txt,encoding='utf-8')


def main()->None:  # type: ignore[override]
    acquire_lock();boot_ts=now_ts()
    _v2243_atomic_status(STATUS,{'schema':'clean_review_worker_status_v2243','version':VERSION,'build':BUILD_LABEL,
        'state':'booting','pid':os.getpid(),'active_owner':VERSION,'writer_count':1,'updated_ts':boot_ts,
        'updated_text':now_text(boot_ts),'phase':'BOOT_IDENTITY_THEN_DELETE_DERIVED_CACHE_V2243',
        'cycle_complete_v2164':False,'sample_cap_v2243':V2243_SAMPLE_CAP,
        'shadow_active_writers_v2163':0,'shadow_historical_files_deleted_v2163':False,'auto_buy':False})
    cleanup=_v2243_cleanup_derived_cache_once()
    for fn in (ledger_once,ledger_v2164_once,ledger_v2165_once,ledger_v2166_once,ledger_v2167_once,
               _v2233_review_ledger_once,_v2238_review_ledger_once,_v2243_review_ledger_once):
        try:fn()
        except Exception as exc:append_error(f'boot_ledger_{getattr(fn,"__name__","unknown")}',exc)
    while True:
        try:
            result=run_once()
            health=load_json(STATUS,{}) or {};health=dict(health) if isinstance(health,dict) else {}
            health.update({'version':VERSION,'build':BUILD_LABEL,'sample_cap_v2243':V2243_SAMPLE_CAP,
                'oversized_derived_cache_deleted_v2243':True,'derived_cache_freed_bytes_v2243':int(cleanup.get('freed_bytes') or 0),
                'canonical_ledgers_deleted_v2243':0,'full_history_scan_v2243':False,'auto_buy':False})
            _v2243_atomic_status(STATUS,health)
        except Exception as exc:
            append_error('run_once',exc)
            _v2243_atomic_status(STATUS,{'schema':'clean_review_worker_status_v2243','version':VERSION,'build':BUILD_LABEL,
                'state':'ERROR','pid':os.getpid(),'updated_ts':now_ts(),'updated_text':now_text(),
                'error':f'{type(exc).__name__}: {exc}','sample_cap_v2243':V2243_SAMPLE_CAP,
                'shadow_active_writers_v2163':0,'auto_buy':False})
        time.sleep(INTERVAL_SEC)



# =============================================================================
# Review v2.103 / v2244
# ENOSPC-safe boot: remove only the rebuildable oversized v2220 SQLite cache
# before any singleton/status/ledger write. Canonical ledgers remain untouched.
# =============================================================================
VERSION='review_worker_v2.103'
BUILD_LABEL='v2244_enospc_prelock_cache_cleanup_recent500_2026-07-27'
MAIN_DEPLOY_VERSION=BUILD_LABEL


def _v2244_unlink_derived_cache_before_any_write():
    targets=[
        BASE_DIR/'runtime'/'review_exact_day_cache_v2220.sqlite3',
        BASE_DIR/'runtime'/'review_exact_day_cache_v2220.sqlite3-wal',
        BASE_DIR/'runtime'/'review_exact_day_cache_v2220.sqlite3-shm',
        BASE_DIR/'runtime'/'review_exact_day_cache_v2220.sqlite3-journal',
    ]
    try:
        targets.extend((BASE_DIR/'runtime').glob('review_exact_day_cache_v2220.sqlite3.tmp*'))
    except Exception:
        pass
    freed=0
    for path in targets:
        try:
            size=int(path.stat().st_size)
        except Exception:
            size=0
        try:
            path.unlink(missing_ok=True)
            freed+=max(0,size)
        except Exception:
            pass
    return freed


def _v2244_review_ledger_once():
    marker=BASE_DIR/'runtime'/'review_v2244_enospc_prelock_cleanup.seeded'
    if marker.exists():return
    ts=now_ts();txt=now_text(ts)
    append_jsonl(CHANGE_LEDGER,{'schema':'change_verify_ledger_v870',
        'change_id':'V2244-REVIEW-ENOSPC-PRELOCK-CACHE-CLEANUP',
        'issue_id':'V2243-REVIEW-RUNTIME-IDENTITY-FAIL-BEFORE-CLEANUP',
        'version':'v2244','verify_result':'LOCAL_PASS_SERVER_CHECK',
        'created_ts':ts,'created_at':txt,'writer':VERSION,
        'cause':'v2243 attempted singleton/status writes before deleting the oversized derived SQLite cache. At ENOSPC the process could exit before cleanup, leaving the old status and lock identity.',
        'fix':'Unlink only the rebuildable v2220 SQLite cache/WAL/SHM/journal before any write, then acquire the existing singleton, publish v2.103 identity, and run the same recent exact maximum-500 incremental analysis.',
        'not_touched':['OPEN','CLOSED','trade_log','decision','exact','change/issue history','existing Shadow','prediction formula/weights','candidate/S1/Paper','entry/exit','auto-buy OFF'],
        'auto_buy':False})
    append_jsonl(ISSUE_LEDGER,{'schema':'coinbot_single_work_ledger_v870',
        'event_type':'ISSUE','issue_id':'V2243-REVIEW-RUNTIME-IDENTITY-FAIL-BEFORE-CLEANUP',
        'status':'DONE','title':'디스크 가득 찬 상태에서 Review가 cache 삭제 전 종료',
        'detail':'파생 SQLite만 첫 쓰기 전에 삭제하고 원본 장부와 최근 500건 분석 계약은 유지.',
        'version':'v2244','created_ts':ts,'created_at':txt,'auto_buy':False})
    marker.parent.mkdir(parents=True,exist_ok=True)
    marker.write_text(txt,encoding='utf-8')


def main()->None:  # type: ignore[override]
    # This unlink-only phase must run before lock/status writes. It writes
    # nothing and touches no canonical ledger.
    prefreed=_v2244_unlink_derived_cache_before_any_write()

    acquire_lock()
    boot_ts=now_ts()
    _v2243_atomic_status(STATUS,{'schema':'clean_review_worker_status_v2244',
        'version':VERSION,'build':BUILD_LABEL,'state':'booting','pid':os.getpid(),
        'active_owner':VERSION,'writer_count':1,'updated_ts':boot_ts,
        'updated_text':now_text(boot_ts),
        'phase':'PRELOCK_DERIVED_CACHE_REMOVED_THEN_IDENTITY_V2244',
        'cycle_complete_v2164':False,'sample_cap_v2243':V2243_SAMPLE_CAP,
        'prefreed_derived_bytes_v2244':int(prefreed),
        'canonical_ledgers_deleted_v2244':0,
        'shadow_active_writers_v2163':0,
        'shadow_historical_files_deleted_v2163':False,'auto_buy':False})

    cleanup=_v2243_cleanup_derived_cache_once()
    for fn in (ledger_once,ledger_v2164_once,ledger_v2165_once,ledger_v2166_once,
               ledger_v2167_once,_v2233_review_ledger_once,_v2238_review_ledger_once,
               _v2243_review_ledger_once,_v2244_review_ledger_once):
        try:fn()
        except Exception as exc:append_error(f'boot_ledger_{getattr(fn,"__name__","unknown")}',exc)

    while True:
        try:
            result=run_once()
            health=load_json(STATUS,{}) or {}
            health=dict(health) if isinstance(health,dict) else {}
            health.update({'version':VERSION,'build':BUILD_LABEL,
                'sample_cap_v2243':V2243_SAMPLE_CAP,
                'prefreed_derived_bytes_v2244':int(prefreed),
                'oversized_derived_cache_deleted_v2244':True,
                'derived_cache_freed_bytes_v2244':int(prefreed)+int(cleanup.get('freed_bytes') or 0),
                'canonical_ledgers_deleted_v2244':0,
                'full_history_scan_v2244':False,'auto_buy':False})
            _v2243_atomic_status(STATUS,health)
        except Exception as exc:
            append_error('run_once',exc)
            _v2243_atomic_status(STATUS,{'schema':'clean_review_worker_status_v2244',
                'version':VERSION,'build':BUILD_LABEL,'state':'ERROR','pid':os.getpid(),
                'updated_ts':now_ts(),'updated_text':now_text(),
                'error':f'{type(exc).__name__}: {exc}',
                'sample_cap_v2243':V2243_SAMPLE_CAP,
                'canonical_ledgers_deleted_v2244':0,
                'shadow_active_writers_v2163':0,'auto_buy':False})
        time.sleep(INTERVAL_SEC)

# =============================================================================
# Review v2.104 / v2245
# Restore the proven runtime order: final module load -> singleton/status identity
# -> ledger seeding -> analysis. No module-level ledger fsync is allowed before
# the final physical entrypoint reaches main().
# =============================================================================
VERSION='review_worker_v2.104'
BUILD_LABEL='v2245_defer_module_ledger_io_identity_first_2026-07-27'
MAIN_DEPLOY_VERSION=BUILD_LABEL


def _v2245_review_ledger_once():
    marker=BASE_DIR/'runtime'/'review_v2245_defer_module_ledger_io.seeded'
    if marker.exists():return
    ts=now_ts();txt=now_text(ts)
    append_jsonl(CHANGE_LEDGER,{
        'schema':'change_verify_ledger_v870',
        'change_id':'V2245-REVIEW-DEFER-MODULE-LEDGER-IO-IDENTITY-FIRST',
        'issue_id':'V2244-REVIEW-MAINPID-WITHOUT-STATUS-LOCK',
        'version':'v2245','verify_result':'LOCAL_PASS_SERVER_CHECK',
        'created_ts':ts,'created_at':txt,'writer':VERSION,
        'cause':'v2244 removed the derived SQLite cache before start, but 24 historical ledger seed calls still executed at module import before main(). On the live server those fsync paths could exceed the finite runtime check, leaving one Review MainPID with statusPID=0 and lockPID=0.',
        'fix':'Keep every historical ledger function and marker, but defer all 24 module-level calls until after the final v2.104 singleton lock and BOOTING status are written. Preserve the v2244 cache cleanup and recent exact maximum-500 analysis.',
        'not_touched':['OPEN','CLOSED','trade_log','decision','exact','change/issue history','existing Shadow','prediction formula/weights','candidate/S1/Paper','entry/exit','auto-buy OFF'],
        'auto_buy':False})
    append_jsonl(ISSUE_LEDGER,{
        'schema':'coinbot_single_work_ledger_v870','event_type':'ISSUE',
        'issue_id':'V2244-REVIEW-MAINPID-WITHOUT-STATUS-LOCK','status':'DONE',
        'title':'Review 프로세스는 떴지만 시작 전 장부 실행으로 신분파일이 0인 문제',
        'detail':'과거 장부 seed 호출 24개를 삭제하지 않고 lock/status 기록 뒤로 이동. 분석식과 원본 원장은 그대로 유지.',
        'version':'v2245','created_ts':ts,'created_at':txt,'auto_buy':False})
    marker.parent.mkdir(parents=True,exist_ok=True)
    marker.write_text(txt,encoding='utf-8')


def _v2245_boot_ledgers_after_identity():
    for fn in (
        ledger_once,
        ledger_v2164_once,
        ledger_v2165_once,
        ledger_v2166_once,
        ledger_v2167_once,
        ledger_v2168_once,
        ledger_v2169_once,
        _v2170_ledger_once,
        _v2171_ledger_once,
        _v2176_ledger_once,
        _v2187_ledger_once,
        _v2188_review_ledger_once,
        _v2189_review_ledger_once,
        _v2191_review_ledger_once,
        _v2192_review_ledger_once,
        _v2193_review_ledger_once,
        _v2198_review_ledger_once,
        _v2202_review_ledger_once,
        _v2203_review_ledger_once,
        _v2204_review_ledger_once,
        _v2206_review_ledger_once,
        _v2207_review_deploy_ledger_once,
        _v2208_review_ledger_once,
        _v2209_review_ledger_once,
        _v2210_review_ledger_once,
        _v2211_review_ledger_once,
        _v2216_runtime_fix_ledger_once,
        _v2220_seed_ledger,
        _v2227_review_ledger_once,
        _v2233_review_ledger_once,
        _v2238_review_ledger_once,
        _v2243_review_ledger_once,
        _v2244_review_ledger_once,
        _v2245_review_ledger_once,
    ):
        try:fn()
        except Exception as exc:append_error(f'boot_ledger_{getattr(fn,"__name__","unknown")}',exc)


def main()->None:  # type: ignore[override]
    # v2244 guard already removes the rebuildable cache before start. Keep the
    # worker-side unlink as a second idempotent ENOSPC protection; it touches no
    # canonical ledger.
    prefreed=_v2244_unlink_derived_cache_before_any_write()

    # Proven old order restored: singleton and status are the first writes after
    # final module loading. Historical ledger fsync and analysis follow later.
    acquire_lock()
    boot_ts=now_ts()
    _v2243_atomic_status(STATUS,{
        'schema':'clean_review_worker_status_v2245','version':VERSION,'build':BUILD_LABEL,
        'state':'booting','pid':os.getpid(),'active_owner':VERSION,'writer_count':1,
        'updated_ts':boot_ts,'updated_text':now_text(boot_ts),
        'phase':'FINAL_MODULE_LOADED_IDENTITY_FIRST_V2245',
        'module_ready_v2245':True,'ledger_io_started_v2245':False,
        'cycle_complete_v2164':False,'sample_cap_v2243':V2243_SAMPLE_CAP,
        'prefreed_derived_bytes_v2245':int(prefreed),
        'canonical_ledgers_deleted_v2245':0,'deferred_module_ledger_calls_v2245':24,
        'shadow_active_writers_v2163':0,'shadow_historical_files_deleted_v2163':False,
        'auto_buy':False})

    _v2245_boot_ledgers_after_identity()
    health=load_json(STATUS,{}) or {}
    health=dict(health) if isinstance(health,dict) else {}
    health.update({'version':VERSION,'build':BUILD_LABEL,'state':'booting','pid':os.getpid(),
        'phase':'IDENTITY_DONE_LEDGER_DONE_ANALYSIS_START_V2245','module_ready_v2245':True,
        'ledger_io_started_v2245':True,'ledger_io_finished_v2245':True,
        'deferred_module_ledger_calls_v2245':24,'canonical_ledgers_deleted_v2245':0,
        'auto_buy':False})
    _v2243_atomic_status(STATUS,health)

    cleanup=_v2243_cleanup_derived_cache_once()
    while True:
        try:
            run_once()
            health=load_json(STATUS,{}) or {}
            health=dict(health) if isinstance(health,dict) else {}
            health.update({'version':VERSION,'build':BUILD_LABEL,
                'module_ready_v2245':True,'ledger_io_finished_v2245':True,
                'deferred_module_ledger_calls_v2245':24,
                'sample_cap_v2243':V2243_SAMPLE_CAP,
                'prefreed_derived_bytes_v2245':int(prefreed),
                'oversized_derived_cache_deleted_v2245':True,
                'derived_cache_freed_bytes_v2245':int(prefreed)+int(cleanup.get('freed_bytes') or 0),
                'canonical_ledgers_deleted_v2245':0,
                'full_history_scan_v2245':False,'auto_buy':False})
            _v2243_atomic_status(STATUS,health)
        except Exception as exc:
            append_error('run_once',exc)
            _v2243_atomic_status(STATUS,{
                'schema':'clean_review_worker_status_v2245','version':VERSION,'build':BUILD_LABEL,
                'state':'ERROR','pid':os.getpid(),'updated_ts':now_ts(),'updated_text':now_text(),
                'phase':'ANALYSIS_ERROR_AFTER_IDENTITY_V2245','module_ready_v2245':True,
                'ledger_io_finished_v2245':True,'error':f'{type(exc).__name__}: {exc}',
                'sample_cap_v2243':V2243_SAMPLE_CAP,'canonical_ledgers_deleted_v2245':0,
                'shadow_active_writers_v2163':0,'auto_buy':False})
        time.sleep(INTERVAL_SEC)


# =============================================================================
# Review v2.105 / v2246
# Canonical ownership repair:
# - Guard alone owns stop/drain/derived-cache cleanup/stale-identity removal.
# - Review alone owns singleton lock, health status and analysis publication.
# - Main remains read-only for Review output.
# =============================================================================
VERSION='review_worker_v2.105'
BUILD_LABEL='v2246_review_single_runtime_owner_no_dual_cleanup_2026-07-27'
MAIN_DEPLOY_VERSION=BUILD_LABEL


def _v2246_cache_presence_read_only():
    rows=[]
    for path in (
        BASE_DIR/'runtime'/'review_exact_day_cache_v2220.sqlite3',
        BASE_DIR/'runtime'/'review_exact_day_cache_v2220.sqlite3-wal',
        BASE_DIR/'runtime'/'review_exact_day_cache_v2220.sqlite3-shm',
        BASE_DIR/'runtime'/'review_exact_day_cache_v2220.sqlite3-journal',
    ):
        try:
            if path.exists(): rows.append({'name':path.name,'size':int(path.stat().st_size)})
        except Exception: pass
    return rows


def _v2246_review_ledger_once():
    marker=BASE_DIR/'runtime'/'review_v2246_single_owner.seeded'
    if marker.exists(): return
    ts=now_ts();txt=now_text(ts)
    append_jsonl(CHANGE_LEDGER,{
        'schema':'change_verify_ledger_v870',
        'change_id':'V2246-REVIEW-SINGLE-RUNTIME-OWNER',
        'issue_id':'V2245-GUARD-REVIEW-DUAL-CACHE-OWNER-AND-IDENTITY-CHECK',
        'version':'v2246','verify_result':'LOCAL_PASS_SERVER_CHECK',
        'created_ts':ts,'created_at':txt,'writer':VERSION,
        'cause':'Guard and Review both owned derived-cache deletion. Runtime identity and analysis readiness were also mixed in one deployment verdict, which made a healthy fresh process look failed while historical ledger seeding or analysis was still starting.',
        'fix':'Guard exclusively owns stop/drain/cache cleanup/stale identity removal. Review performs no boot cleanup and publishes its singleton lock and running status as its first writes, then seeds preserved ledgers and starts the existing recent-exact maximum-500 analysis.',
        'not_touched':['OPEN','CLOSED','trade_log','decision','exact','change/issue history','existing Shadow','prediction formula/weights','candidate/S1/Paper','entry/exit','auto-buy OFF'],
        'auto_buy':False})
    append_jsonl(ISSUE_LEDGER,{
        'schema':'coinbot_single_work_ledger_v870','event_type':'ISSUE',
        'issue_id':'V2245-GUARD-REVIEW-DUAL-CACHE-OWNER-AND-IDENTITY-CHECK',
        'status':'DONE','title':'Review 정리 주인 중복과 실행신분·분석완료 혼합 판정',
        'detail':'Guard는 정리·재시작만, Review는 lock/status/분석만 맡도록 기존 흐름 안에서 단일화.',
        'version':'v2246','created_ts':ts,'created_at':txt,'auto_buy':False})
    marker.parent.mkdir(parents=True,exist_ok=True)
    marker.write_text(txt,encoding='utf-8')


def main()->None:  # type: ignore[override]
    # The old stable contract is restored exactly: lock and status are the first
    # Review-owned writes. Cache deletion is not duplicated here.
    acquire_lock()
    try:
        os.fsync(_LOCK_FH.fileno())
    except Exception:
        pass
    boot_ts=now_ts()
    _v2243_atomic_status(STATUS,{
        'schema':'clean_review_worker_status_v2246','version':VERSION,'build':BUILD_LABEL,
        'state':'running','pid':os.getpid(),'active_owner':VERSION,'writer_count':1,
        'updated_ts':boot_ts,'updated_text':now_text(boot_ts),
        'phase':'RUNTIME_IDENTITY_OWNER_READY_V2246',
        'runtime_identity_ready_v2246':True,'analysis_ready_v2246':False,
        'runtime_owner_v2246':'review_worker_singleton_lock_and_health_status',
        'derived_cache_cleanup_owner_v2246':'guard_after_zero_process_proof',
        'main_reader_only_v2246':True,'ledger_io_started_v2246':False,
        'sample_cap_v2243':V2243_SAMPLE_CAP,'canonical_ledgers_deleted_v2246':0,
        'shadow_active_writers_v2163':0,'shadow_historical_files_deleted_v2163':False,
        'auto_buy':False})

    # v2291: historical ledgers stay append-only and untouched, but old boot-time
    # seed calls no longer sit in front of the live Review loop.

    health=load_json(STATUS,{}) or {}
    health=dict(health) if isinstance(health,dict) else {}
    health.update({'version':VERSION,'build':BUILD_LABEL,'state':'running','pid':os.getpid(),
        'phase':'LEDGER_SEED_DONE_ANALYSIS_START_V2246','runtime_identity_ready_v2246':True,
        'analysis_ready_v2246':False,'ledger_io_started_v2246':True,'ledger_io_finished_v2246':True,
        'derived_cache_cleanup_owner_v2246':'guard_after_zero_process_proof',
        'derived_cache_present_after_guard_v2246':_v2246_cache_presence_read_only(),
        'canonical_ledgers_deleted_v2246':0,'auto_buy':False})
    _v2243_atomic_status(STATUS,health)

    while True:
        try:
            run_once()
            health=load_json(STATUS,{}) or {}
            health=dict(health) if isinstance(health,dict) else {}
            health.update({'version':VERSION,'build':BUILD_LABEL,'state':'running','pid':os.getpid(),
                'runtime_identity_ready_v2246':True,'analysis_ready_v2246':True,
                'runtime_owner_v2246':'review_worker_singleton_lock_and_health_status',
                'derived_cache_cleanup_owner_v2246':'guard_after_zero_process_proof',
                'main_reader_only_v2246':True,'sample_cap_v2243':V2243_SAMPLE_CAP,
                'full_history_scan_v2246':False,'canonical_ledgers_deleted_v2246':0,
                'auto_buy':False})
            _v2243_atomic_status(STATUS,health)
        except Exception as exc:
            append_error('run_once',exc)
            _v2243_atomic_status(STATUS,{
                'schema':'clean_review_worker_status_v2246','version':VERSION,'build':BUILD_LABEL,
                'state':'ERROR','pid':os.getpid(),'updated_ts':now_ts(),'updated_text':now_text(),
                'phase':'ANALYSIS_ERROR_RUNTIME_OWNER_ALIVE_V2246',
                'runtime_identity_ready_v2246':True,'analysis_ready_v2246':False,
                'runtime_owner_v2246':'review_worker_singleton_lock_and_health_status',
                'derived_cache_cleanup_owner_v2246':'guard_after_zero_process_proof',
                'error':f'{type(exc).__name__}: {exc}','sample_cap_v2243':V2243_SAMPLE_CAP,
                'canonical_ledgers_deleted_v2246':0,'shadow_active_writers_v2163':0,
                'auto_buy':False})
        time.sleep(INTERVAL_SEC)




# =============================================================================
# Canonical Review owner
#
# One exact window, one state overlay, one bounded candle index and one public
# result contract. Input selection and matured horizon completion are reported
# separately; selecting 500 inputs never implies 500 completed results.
# =============================================================================
VERSION='review_worker_v2.113'
BUILD_LABEL='canonical_event_time_direction_replay_owner_2026-07-28'
MAIN_DEPLOY_VERSION=BUILD_LABEL
CURRENT_PERFORMANCE=BASE_DIR/'paper_current_epoch_performance_v2074.json'
CANDLE_DELTA=BASE_DIR/'clean_candle_delta_v1014.jsonl'
CANDLE_INDEX_REFRESH_MIN_SEC=300.0
_CANDLE_INDEX_REFRESH_TS=0.0
_BASE_REVIEW_RUN_ONCE=run_once


def _apply_candle_delta_ops(row,ops):
    import copy
    out=copy.deepcopy(row) if isinstance(row,dict) else {}
    for op in ops if isinstance(ops,list) else []:
        if not isinstance(op,dict):continue
        kind=str(op.get('op') or '');path=[str(x) for x in (op.get('path') or [])]
        if not path:continue
        cur=out
        valid=True
        for key in path[:-1]:
            if not isinstance(cur,dict):valid=False;break
            nxt=cur.get(key)
            if not isinstance(nxt,dict):
                if kind=='remove':valid=False;break
                nxt={};cur[key]=nxt
            cur=nxt
        if not valid or not isinstance(cur,dict):continue
        key=path[-1]
        if kind=='remove':cur.pop(key,None)
        elif kind=='set':cur[key]=copy.deepcopy(op.get('value'))
        elif kind=='list_roll':
            current=cur.get(key) if isinstance(cur.get(key),list) else []
            drop=max(0,int(num(op.get('drop_front'),0.0) or 0));append_rows=op.get('append') if isinstance(op.get('append'),list) else []
            cur[key]=copy.deepcopy(current[drop:]+append_rows)
    return out


def _canonical_candle_rows():
    base_obj=load_json(V2210_CANDLE_CACHE,{}) or {}
    pairs,shape=_v2213_cache_row_pairs(base_obj)
    rows={}
    for raw_ticker,row in pairs:
        symbol=ticker(raw_ticker or (row.get('ticker') if isinstance(row,dict) else ''))
        if symbol and isinstance(row,dict):rows[symbol]=dict(row,ticker=symbol)
    checkpoint=str(base_obj.get('delta_checkpoint_id_v1016') or '') if isinstance(base_obj,dict) else ''
    delta_rows=0;delta_applied=0
    if CANDLE_DELTA.exists():
        try:
            with CANDLE_DELTA.open('r',encoding='utf-8',errors='ignore') as handle:
                for line in handle:
                    try:item=json.loads(line)
                    except Exception:continue
                    if not isinstance(item,dict):continue
                    delta_rows+=1;symbol=ticker(item.get('ticker'))
                    if not symbol:continue
                    schema=str(item.get('schema') or '')
                    if schema=='candle_delta_ops_v1016':
                        item_checkpoint=str(item.get('base_checkpoint_id_v1016') or '')
                        if checkpoint and item_checkpoint and item_checkpoint!=checkpoint:continue
                        seed=rows.get(symbol) or {};merged=_apply_candle_delta_ops(seed,item.get('ops') if isinstance(item.get('ops'),list) else [])
                    elif schema=='candle_delta_patch_v1015':
                        merged=dict(rows.get(symbol) or {});merged.update(item.get('patch') if isinstance(item.get('patch'),dict) else {})
                        for key in item.get('remove') or []:merged.pop(str(key),None)
                    else:
                        raw=item.get('row') if isinstance(item.get('row'),dict) else item
                        if not isinstance(raw,dict):continue
                        merged=dict(raw)
                    merged['ticker']=symbol;rows[symbol]=merged;delta_applied+=1
        except OSError:pass
    return rows,{'shape':shape,'base_rows':len(pairs),'merged_rows':len(rows),'delta_rows_seen':delta_rows,'delta_rows_applied':delta_applied,'checkpoint_id':checkpoint}


def read_candle_index(force=False):
    """Build the bounded completed-candle index from the canonical base+delta truth."""
    global _V2213_CANDLE_PARSE_DIAG,_CANDLE_INDEX_REFRESH_TS
    now=now_ts()
    def sig(path):
        try:st=path.stat();return (int(st.st_mtime_ns),int(st.st_size))
        except Exception:return (0,0)
    signature=(sig(V2210_CANDLE_CACHE),sig(CANDLE_DELTA))
    cached=_V2210_CANDLE_INDEX_CACHE.get('index') or {}
    if cached and not force and now-_CANDLE_INDEX_REFRESH_TS<CANDLE_INDEX_REFRESH_MIN_SEC:
        return cached,int(_V2210_CANDLE_INDEX_CACHE.get('rows') or 0)
    if cached and _V2210_CANDLE_INDEX_CACHE.get('signature')==signature:
        _CANDLE_INDEX_REFRESH_TS=now
        return cached,int(_V2210_CANDLE_INDEX_CACHE.get('rows') or 0)
    rows,source_diag=_canonical_candle_rows()
    index={};total=0;rows_seen=0;rows_with_lab=0
    for raw_ticker,row in rows.items():
        rows_seen+=1
        lab=row.get('structure_lab_candles') if isinstance(row.get('structure_lab_candles'),dict) else {}
        frames=lab.get('frames') if isinstance(lab.get('frames'),dict) else {}
        symbol=ticker(raw_ticker or row.get('ticker'))
        if not symbol or not frames:continue
        rows_with_lab+=1;parsed={}
        for frame,sec in V2210_FRAME_SEC.items():
            items=[];source_rows=frames.get(frame) if isinstance(frames.get(frame),list) else []
            for item in source_rows:
                if not isinstance(item,(list,tuple)) or len(item)<5:continue
                ts=_v2202_num(item[0]);op=_v2202_num(item[1]);cl=_v2202_num(item[2]);hi=_v2202_num(item[3]);lo=_v2202_num(item[4]);vol=_v2202_num(item[5]) if len(item)>=6 else 0.0
                if ts is None or None in (op,cl,hi,lo) or min(op,cl,hi,lo)<=0:continue
                if ts>10_000_000_000:ts/=1000.0
                items.append((float(ts),float(op),float(cl),float(hi),float(lo),max(0.0,float(vol or 0.0))))
            dedup={round(item[0],3):item for item in items};items=[dedup[k] for k in sorted(dedup)]
            if items:
                parsed[frame]={'rows':items,'starts':[item[0] for item in items],'closes':[item[0]+sec for item in items]};total+=len(items)
        if parsed:index[symbol]=parsed
    _V2210_CANDLE_INDEX_CACHE.update({'signature':signature,'index':index,'rows':total})
    _CANDLE_INDEX_REFRESH_TS=now
    _V2213_CANDLE_PARSE_DIAG={'state':'PASS' if index else 'CHECK','shape':source_diag.get('shape'),'rows_seen':rows_seen,
        'rows_with_structure_lab':rows_with_lab,'tickers_indexed':len(index),'candles_indexed':total,
        'base_rows':source_diag.get('base_rows'),'merged_rows':source_diag.get('merged_rows'),
        'delta_rows_seen':source_diag.get('delta_rows_seen'),'delta_rows_applied':source_diag.get('delta_rows_applied'),
        'source':'clean_candle_cache + clean_candle_delta_v1014','refresh_min_sec':CANDLE_INDEX_REFRESH_MIN_SEC,'full_rescan_each_cycle':False}
    return index,total


# Existing resolvers call this global name; point it at the single owner.
_v2210_candle_index=read_candle_index


def _all_state_rows():
    state=load_json(OUTCOME_STATE,{}) or {}
    rows=(state.get(STATE_KEY) or {}) if isinstance(state.get(STATE_KEY),dict) else {}
    try:mtime=OUTCOME_STATE.stat().st_mtime_ns
    except Exception:mtime=0
    return [dict(row) for row in rows.values() if isinstance(row,dict)],mtime


def read_state_rows():
    rows,mtime=_all_state_rows()
    selected_keys=set(_V2243_SELECTED_KEYS or ())
    if selected_keys:
        rows=[row for row in rows if str(row.get('event_key') or '') in selected_keys]
    rows.sort(key=_v2243_row_sort_value,reverse=True)
    return rows[:V2243_SAMPLE_CAP],mtime


_v2202_read_state_rows=read_state_rows


def read_trade_samples():
    signature=_v2213_file_sig(CURRENT_PERFORMANCE)
    if _V2213_TRADE_SAMPLE_CACHE.get('signature')==signature:
        _V2213_TRADE_SAMPLE_CACHE['cache_hits']=int(_V2213_TRADE_SAMPLE_CACHE.get('cache_hits') or 0)+1
        return list(_V2213_TRADE_SAMPLE_CACHE.get('samples') or [])
    obj=load_json(CURRENT_PERFORMANCE,{}) or {}
    rows=obj.get('closed_rows') if isinstance(obj,dict) and isinstance(obj.get('closed_rows'),list) else []
    rows=sorted((row for row in rows if isinstance(row,dict)),
        key=lambda row:(_v2213_first_ts(row,'paper_v2_exact_closed_ts','closed_at','close_ts','exit_ts','updated_ts') or 0.0,
                        str(row.get('direct_decision_key') or row.get('decision_key') or '')),reverse=True)[:V2243_SAMPLE_CAP]
    samples=[]
    for row in rows:
        sample=_v2213_trade_sample(row,True)
        if sample:samples.append(sample)
    _V2213_TRADE_SAMPLE_CACHE.update({'signature':signature,'samples':samples,
        'scan_count':int(_V2213_TRADE_SAMPLE_CACHE.get('scan_count') or 0)+1,'cache_hits':0,
        'source':'paper_current_epoch_performance.closed_rows','sample_cap':V2243_SAMPLE_CAP})
    return samples


_v2213_trade_samples=read_trade_samples
_v2211_trade_samples=read_trade_samples


def _merged_selected_rows(selected):
    """Overlay current state only for the selected recent-exact keys.

    Never add historical keys outside the bounded window; every horizon
    denominator therefore remains <= the selected count (max 500).
    """
    merged = dict(selected or {})
    allowed = set(merged)
    diag = {'wrong_generation_raw': 0, 'missing_event_key_raw': 0, 'duplicates_removed': 0}
    rows, _ = _all_state_rows()
    for row in rows:
        key = str(row.get('event_key') or '').strip() if isinstance(row, dict) else ''
        if not key or key not in allowed:
            continue
        one = {}
        _v2202_accept_raw(one, row, 2, diag)
        if key in one:
            merged[key] = one[key]
    return merged


def _result_contract(selected,snapshot):
    merged=_merged_selected_rows(selected)
    now=now_ts();expected={};actual={};missing={}
    horizons=snapshot.get('horizons') if isinstance(snapshot.get('horizons'),dict) else {}
    for label in ('30m','1h','3h','6h'):
        sec=float(V2206_HORIZON_SEC[label]);mature=0
        for _,row in merged.values():
            entry=_v2202_event_time(row)
            if entry is not None and now-float(entry)>=sec-2.0:mature+=1
        expected[label]=mature
        block=horizons.get(label) if isinstance(horizons.get(label),dict) else {}
        actual[label]=int(block.get('samples') or 0)
        missing[label]=max(0,expected[label]-actual[label])
    selected_count=len(selected or {})
    input_state='INPUT_READY' if selected_count>0 else 'INPUT_WAITING'
    result_complete=bool(selected_count>0 and missing['3h']==0 and missing['6h']==0)
    state='COMPLETE' if result_complete else ('RESULT_PARTIAL' if selected_count>0 else 'INPUT_WAITING')
    return {'schema':'review_result_status','owner':'review','state':state,'input_state':input_state,
        'selected_exact_count':selected_count,'sample_cap':V2243_SAMPLE_CAP,
        'result_count':actual,'matured_expected_count':expected,'missing_matured_count':missing,
        'result_complete':result_complete,'current_price_substitution_count':0,
        'completed_candle_index':dict(_V2213_CANDLE_PARSE_DIAG or {}),'updated_ts':now,
        'historical_ledgers_rewritten':False,'historical_ledgers_deleted':False,'auto_buy':False}


def _selected_event_row(value):
    if isinstance(value,dict):return value
    if isinstance(value,(list,tuple)):
        for item in reversed(value):
            if isinstance(item,dict):return item
    return {}


def _index_lab(index,symbol,cutoff):
    frames={};src=index.get(ticker(symbol)) if isinstance(index.get(ticker(symbol)),dict) else {}
    for frame,data in src.items():
        rows=data.get('rows') if isinstance(data,dict) and isinstance(data.get('rows'),list) else []
        sec=float(V2210_FRAME_SEC.get(frame) or 0.0)
        selected=[list(item) for item in rows if isinstance(item,(list,tuple)) and len(item)>=5 and (sec<=0 or float(item[0])+sec<=float(cutoff)+1e-6)]
        if selected:frames[frame]=selected
    return {'frames':frames,'completed_candles_only':True,'cutoff_ts':cutoff}


def _timeaxis_missing_reasons(result):
    context=result.get('timeaxis_context') if isinstance(result,dict) and isinstance(result.get('timeaxis_context'),dict) else {}
    reasons=[]
    for prefix,key in (('TICKER','timeframe_truth'),('BTC','benchmark_timeframe_truth')):
        truth=context.get(key) if isinstance(context.get(key),dict) else {}
        for item in truth.get('direction_missing') or truth.get('missing') or []:reasons.append(f'{prefix}_INSUFFICIENT:{item}')
        for item in truth.get('direction_stale') or truth.get('stale') or []:reasons.append(f'{prefix}_EVENT_STALE:{item}')
    return reasons or [str(result.get('hold_reason_code') or 'DATA_MISSING')]


def build_timeaxis_replay(selected):
    try:
        from strategy_v2_core import evaluate_timeaxis_prediction, PREDICTION_MODEL_GENERATION
    except Exception as exc:
        return {'schema':'timeaxis_formula_replay','state':'IMPORT_ERROR','error':f'{type(exc).__name__}: {exc}','horizons':{},'auto_buy':False}
    index,_=read_candle_index(force=False)
    blocks={label:{'samples':0,'evaluated':0,'data_missing':0,'correct':0,'wrong':0,'pass_count':0,'pass_up':0,'pass_down':0,
        'false_positive_count':0,'missed_up_count':0,'pass_close':[],'pass_mfe':[],'pass_mae':[],'missing_reasons':Counter(),'false_positive_examples':[]} for label in ('3h','6h')}
    hashes=set();events=0;events_with_candles=0;diagnostics=Counter()
    for value in (selected or {}).values():
        row=_selected_event_row(value)
        if not row:diagnostics['SELECTED_ROW_MISSING']+=1;continue
        seal=row.get('prediction_input_seal_v2188') if isinstance(row.get('prediction_input_seal_v2188'),dict) else {}
        entry_ts,_=_v2206_exact_entry_ts(row,seal);symbol=ticker(row.get('ticker'))
        if entry_ts is None:diagnostics['ENTRY_TS_MISSING']+=1;continue
        if not symbol:diagnostics['TICKER_MISSING']+=1;continue
        if symbol not in index:diagnostics['TICKER_INDEX_MISSING']+=1;continue
        if symbol!='BTC' and 'BTC' not in index:diagnostics['BTC_INDEX_MISSING']+=1;continue
        lab=_index_lab(index,symbol,entry_ts);btc_lab=_index_lab(index,'BTC',entry_ts)
        if not (lab.get('frames') or {}):diagnostics['TICKER_NO_COMPLETED_CANDLES_BEFORE_ENTRY']+=1;continue
        if symbol!='BTC' and not (btc_lab.get('frames') or {}):diagnostics['BTC_NO_COMPLETED_CANDLES_BEFORE_ENTRY']+=1;continue
        events_with_candles+=1
        try:
            result=evaluate_timeaxis_prediction(lab,btc_lab,entry_ts,symbol,seal.get('axes') if isinstance(seal.get('axes'),dict) else {},seal.get('connections') if isinstance(seal.get('connections'),dict) else {})
        except Exception as exc:
            diagnostics[f'EVALUATION_ERROR:{type(exc).__name__}']+=1
            for b in blocks.values():b['data_missing']+=1;b['missing_reasons'][f'EVAL:{type(exc).__name__}']+=1
            continue
        events+=1;contract_hash=str(result.get('prediction_contract_hash') or '')
        if contract_hash:hashes.add(contract_hash)
        passed=str(result.get('state') or '')=='CONTINUATION_FAVORED';ready=result.get('input_state')=='READY'
        missing_reasons=_timeaxis_missing_reasons(result) if not ready else []
        if ready:diagnostics['EVALUATED_READY']+=1
        else:
            diagnostics['DIRECTION_INPUT_NOT_READY']+=1
            for reason in missing_reasons:diagnostics[reason]+=1
        for label,b in blocks.items():
            horizon=_v2206_horizon_raw(row,label,entry_ts)
            if not isinstance(horizon,dict) or horizon.get('state')!='READY':continue
            truth=horizon.get('truth')
            if truth not in ('UP','DOWN','FLAT'):continue
            b['samples']+=1
            if not ready:
                b['data_missing']+=1
                for reason in missing_reasons:b['missing_reasons'][reason]+=1
                continue
            b['evaluated']+=1;pred='UP' if passed else 'DOWN';actual='UP' if truth=='UP' else 'DOWN'
            if pred==actual:b['correct']+=1
            else:b['wrong']+=1
            if passed:
                b['pass_count']+=1;b['pass_up']+=int(truth=='UP');b['pass_down']+=int(truth!='UP')
                b['pass_close'].append(horizon.get('close_pct'))
                if horizon.get('mfe_pct') is not None:b['pass_mfe'].append(horizon.get('mfe_pct'))
                if horizon.get('mae_pct') is not None:b['pass_mae'].append(horizon.get('mae_pct'))
                if truth!='UP':
                    b['false_positive_count']+=1
                    if len(b['false_positive_examples'])<12:b['false_positive_examples'].append({'ticker':symbol,'entry_ts':entry_ts,'close_pct':horizon.get('close_pct'),'hold_reason':result.get('hold_reason_code'),'timeaxis':(result.get('timeaxis_context') or {}).get('trend_metrics')})
            elif truth=='UP':b['missed_up_count']+=1
    out_h={}
    for label,b in blocks.items():
        ev=b['evaluated'];pc=b['pass_count']
        out_h[label]={'samples':b['samples'],'evaluated_count':ev,'data_missing_count':b['data_missing'],
            'classification_accuracy_pct':round(b['correct']/ev*100.0,2) if ev else None,'correct_count':b['correct'],'wrong_count':b['wrong'],
            'pass_count':pc,'pass_up_count':b['pass_up'],'pass_down_count':b['pass_down'],'pass_rise_rate_pct':round(b['pass_up']/pc*100.0,2) if pc else None,'pass_win_rate_pct':round(b['pass_up']/pc*100.0,2) if pc else None,
            'false_positive_count':b['false_positive_count'],'missed_up_count':b['missed_up_count'],'pass_avg_close_pct':_v2202_avg(b['pass_close']),
            'pass_avg_mfe_pct':_v2202_avg(b['pass_mfe']),'pass_avg_mae_pct':_v2202_avg(b['pass_mae']),
            'missing_reason_counts':dict(b['missing_reasons']),'false_positive_examples':b['false_positive_examples']}
    evaluated_total=sum(int(x.get('evaluated_count') or 0) for x in out_h.values())
    return {'schema':'timeaxis_formula_replay','state':'READY' if events and evaluated_total>0 and len(hashes)==1 else 'CHECK','model_generation':PREDICTION_MODEL_GENERATION,
        'prediction_contract_hash':next(iter(hashes)) if len(hashes)==1 else None,'contract_hash_count':len(hashes),'selected_event_count':len(selected or {}),
        'events_with_entry_and_candles':events_with_candles,'events_evaluator_called':events,'evaluated_horizon_total':evaluated_total,
        'input_diagnostics':dict(diagnostics),'horizons':out_h,'same_core_evaluator':True,'completed_candle_cutoff_at_entry':True,
        'freshness_reference':'entry_ts_minus_last_completed_close','timing_frames_optional_for_long_direction':True,
        'seconds_axis_used_for_long_direction':False,'historical_performance_rewritten':False,'new_shadow_created':False,'auto_buy':False}


def build_review_snapshot(selected,diag,info):
    global _V2243_SELECTED_KEYS
    _V2243_SELECTED_KEYS=set((selected or {}).keys())
    try:snapshot=dict(_v2202_build_snapshot(selected,diag,info) or {})
    finally:_V2243_SELECTED_KEYS=set()
    contract=_result_contract(selected,snapshot)
    timeaxis_replay=build_timeaxis_replay(selected)
    window={'schema':'review_window','scope':'RECENT_EXACT_MAX_500','sample_cap':V2243_SAMPLE_CAP,
        'sample_count':len(selected or {}),'input_complete':len(selected or {})>0,
        'complete':contract['result_complete'],'recent_ready':contract['result_complete'],
        'full_ready':False,'full_history_scanned':False,
        'source':'canonical outcome ledger tail + current state overlay + bounded completed-candle index',
        'derived_sqlite_cache_used':False,'canonical_ledger_rewritten':False,'canonical_ledger_deleted':False,'auto_buy':False}
    snapshot.update({'schema':'prediction_review_snapshot','owner':VERSION,'version':VERSION,'build':BUILD_LABEL,
        'review_window':window,'review_window_v2243':window,'review_result_status':contract,'timeaxis_formula_replay':timeaxis_replay,
        'bounded_sample_policy':'latest maximum 500 exact events; append-only outcome ledger; state overlay; no current-price result',
        'historical_ledgers_rewritten':False,'historical_ledgers_deleted':False,'new_shadow_created':False,'auto_buy':False})
    return snapshot


def refresh_review_snapshot(force=False):
    if not _V2202_CACHE.get('build_attempted_v2209'):_v2243_start_build()
    if _V2202_CACHE.get('building'):return 'SCANNING'
    if _V2202_CACHE.get('error'):return 'ERROR'
    try:
        changed,info=_v2243_incremental()
        if info is None:return 'SCANNING' if _V2202_CACHE.get('building') else 'READY'
        last=float(_V2202_CACHE.get('last_snapshot_refresh_ts_v2209') or 0.0)
        # Exact append/rotation triggers calculation. A forced refresh is also
        # allowed when the bounded candle index reaches a new five-minute slot.
        candle_due=bool(now_ts()-_CANDLE_INDEX_REFRESH_TS>=CANDLE_INDEX_REFRESH_MIN_SEC)
        should_build=bool(changed or force or candle_due)
        if not should_build or (not force and not changed and not candle_due and now_ts()-last<V2243_REFRESH_MIN_SEC):
            _v2243_publish(_V2202_CACHE.get('snapshot'),'READY');return 'READY'
        with _V2202_LOCK:
            selected=dict(_V2202_CACHE.get('by_key') or {});diag=dict(_V2202_CACHE.get('diagnostics') or {})
            if info is None:info={'inode':_V2202_CACHE.get('ledger_inode'),'offset':_V2202_CACHE.get('ledger_offset'),
                'size':_V2202_CACHE.get('ledger_size'),'mtime_ns':_V2202_CACHE.get('ledger_mtime_ns'),
                'tail_bytes':int(diag.get('tail_bytes_read_v2243') or 0)}
        if candle_due:read_candle_index(force=True)
        started=time.monotonic();snapshot=build_review_snapshot(selected,diag,info);_v2209_verify_snapshot(snapshot)
        elapsed=round(time.monotonic()-started,3)
        snapshot['review_build_sec']=elapsed;snapshot['full_candle_cache_scan_each_cycle']=False
        snapshot['candidate_quality_sample_cap']=V2243_SAMPLE_CAP
        state=str((snapshot.get('review_result_status') or {}).get('state') or 'RESULT_PARTIAL')
        with _V2202_LOCK:
            _V2202_CACHE.update({'snapshot':snapshot,'stage_v2209':state,'cycle_complete_v2209':state=='COMPLETE',
                'last_snapshot_refresh_ts_v2209':now_ts(),'last_build_sec':elapsed})
        _v2243_publish(snapshot,state);return state
    except Exception as exc:
        _v2209_latch_error('CANONICAL_INCREMENTAL',exc);return 'ERROR'


_v2209_refresh_snapshot=refresh_review_snapshot
_v2202_refresh_snapshot=refresh_review_snapshot


def publish_canonical_review_status():
    outcome=load_json(OUTCOME_STATUS,{}) or {};outcome=dict(outcome) if isinstance(outcome,dict) else {}
    analysis=outcome.get('review_analysis_v2238') if isinstance(outcome.get('review_analysis_v2238'),dict) else {}
    snapshot=analysis.get('snapshot') if isinstance(analysis.get('snapshot'),dict) else outcome.get('prediction_validation_v2202') if isinstance(outcome.get('prediction_validation_v2202'),dict) else {}
    contract=snapshot.get('review_result_status') if isinstance(snapshot.get('review_result_status'),dict) else {}
    if not contract:
        contract={'schema':'review_result_status','owner':'review','state':'INPUT_WAITING','input_state':'INPUT_WAITING',
            'selected_exact_count':0,'sample_cap':V2243_SAMPLE_CAP,'result_count':{k:0 for k in ('30m','1h','3h','6h')},
            'matured_expected_count':{k:0 for k in ('30m','1h','3h','6h')},'missing_matured_count':{k:0 for k in ('30m','1h','3h','6h')},
            'result_complete':False,'current_price_substitution_count':0,'updated_ts':now_ts(),'auto_buy':False}
    state=str(contract.get('state') or 'RESULT_PARTIAL');horizons=snapshot.get('horizons') if isinstance(snapshot.get('horizons'),dict) else {}
    legacy_replay={label:dict((horizons.get(label) or {}).get('active_formula_replay') or {}) for label in ('3h','6h')}
    timeaxis=snapshot.get('timeaxis_formula_replay') if isinstance(snapshot.get('timeaxis_formula_replay'),dict) else {}
    replay={label:dict((timeaxis.get('horizons') or {}).get(label) or {}) for label in ('3h','6h')}
    review_contract_hash=str(timeaxis.get('prediction_contract_hash') or '') or None
    strategy_snapshot=load_json(BASE_DIR/'runtime'/'current_candidate_snapshot_v2176.json',{}) or {}
    strategy_summary=strategy_snapshot.get('summary') if isinstance(strategy_snapshot,dict) and isinstance(strategy_snapshot.get('summary'),dict) else {}
    strategy_diag=strategy_summary.get('prediction_gate_diagnostics') if isinstance(strategy_summary.get('prediction_gate_diagnostics'),dict) else {}
    strategy_contract_hash=str(strategy_diag.get('prediction_contract_hash') or '') or None
    contract_match=bool(review_contract_hash and strategy_contract_hash and review_contract_hash==strategy_contract_hash)
    canonical={'schema':'review_status','owner':'review','version':VERSION,'build':BUILD_LABEL,'state':state,
        'input':{'state':contract.get('input_state'),'selected_exact_count':int(contract.get('selected_exact_count') or 0),'sample_cap':V2243_SAMPLE_CAP},
        'results':{'count':dict(contract.get('result_count') or {}),'matured_expected':dict(contract.get('matured_expected_count') or {}),
                   'missing_matured':dict(contract.get('missing_matured_count') or {}),'complete':bool(contract.get('result_complete')),
                   'current_price_substitution_count':int(contract.get('current_price_substitution_count') or 0)},
        'active_formula_replay':{'model_generation':str(timeaxis.get('model_generation') or V2202_CURRENT_MODEL),'prediction_contract_hash':review_contract_hash,
            'strategy_contract_hash':strategy_contract_hash,'contract_match':contract_match,
            'contract_state':'PASS' if contract_match else 'CHECK','horizons':replay,
            'analysis_only':True,'same_core_evaluator':bool(timeaxis.get('same_core_evaluator')),'completed_candle_cutoff_at_entry':True,'historical_performance_rewritten':False,'new_shadow_created':False},
        'legacy_seconds_axis_replay':{'model_generation':V2202_CURRENT_MODEL,'horizons':legacy_replay,'used_for_current_contract_proof':False},
        'candle_index':dict(contract.get('completed_candle_index') or {}),
        'candidate_quality':{'sample_count':len(read_trade_samples()),'sample_cap':V2243_SAMPLE_CAP,'source':'paper_current_epoch_performance.closed_rows'},
        'historical_ledgers_rewritten':False,'historical_ledgers_deleted':False,'new_shadow_created':False,'auto_buy':False}
    analysis=dict(analysis);analysis.update({'state':state,'cycle_complete':bool(canonical['results']['complete']),
        'bounded_recent500_ready':bool(canonical['results']['complete']),'selected_events':canonical['input']['selected_exact_count'],
        'review_status':canonical,'version':VERSION,'build':BUILD_LABEL})
    outcome.update({'version':VERSION,'build':BUILD_LABEL,'review_status':canonical,'review_analysis_v2238':analysis,'auto_buy':False})
    _atomic_json(OUTCOME_STATUS,outcome);return canonical



def run_once():
    """One bounded Review cycle; the historical full-chain runner is inactive."""
    started = time.monotonic()
    state = refresh_review_snapshot(force=False)
    canonical = publish_canonical_review_status()
    elapsed = round(time.monotonic() - started, 3)
    health = load_json(STATUS, {}) or {}
    health = dict(health) if isinstance(health, dict) else {}
    health.update({'version': VERSION, 'build': BUILD_LABEL,
        'cycle_sec': elapsed, 'cycle_elapsed_sec': elapsed,
        'phase': canonical.get('state') or state, 'review_status': canonical,
        'candidate_quality_sample_count': canonical['candidate_quality']['sample_count'],
        'candidate_quality_sample_cap': V2243_SAMPLE_CAP,
        'full_history_runner_active': False, 'full_candle_cache_scan_each_cycle': False,
        'canonical_ledgers_deleted': 0, 'rise_prediction_live_changed': True,
        'existing_shadow_preserved': True, 'new_shadow_created': False, 'auto_buy': False})
    _v2243_atomic_status(STATUS, health)
    return canonical


def seed_canonical_review_change():
    marker=BASE_DIR/'runtime'/'review_canonical_owner.seeded'
    if marker.exists():return
    ts=now_ts();txt=now_text(ts)
    append_jsonl(CHANGE_LEDGER,{'schema':'change_verify_ledger_v870','change_id':'V2254-REVIEW-CANONICAL-INPUT-RESULT-OWNER',
        'issue_id':'REVIEW-INPUT-500-RESULT-ONE-ZERO-FALSE-COMPLETE','version':'v2254','verify_result':'LOCAL_PASS_SERVER_CHECK',
        'created_ts':ts,'created_at':txt,'writer':VERSION,
        'cause':'The latest wrapper disabled the state overlay and completed-candle index, then marked the window complete from selected input count alone. Review displayed exact input 500 while 3h result was 1 and 6h result was 0.',
        'fix':'Restore current state overlay, use a bounded in-memory completed-candle index refreshed at most every five minutes, separate selected input from matured horizon result counts, and publish RESULT_PARTIAL until all matured 3h/6h events are resolved. Current price remains prohibited.',
        'not_touched':['prediction formula/weights/threshold','candidate/S1/Paper','entry/exit','canonical ledgers','existing Shadow','auto-buy OFF'],'auto_buy':False})
    append_jsonl(ISSUE_LEDGER,{'schema':'issue_ledger_event_v1','event_type':'ISSUE',
        'issue_id':'REVIEW-INPUT-500-RESULT-ONE-ZERO-FALSE-COMPLETE','status':'DONE',
        'title':'Review 입력 500을 결과 완료로 오판','detail':'입력과 30m/1h/3h/6h 결과를 분리하고 성숙 결과 누락 시 RESULT_PARTIAL 표시.',
        'version':'v2254','created_ts':ts,'created_at':txt,'auto_buy':False})
    marker.parent.mkdir(parents=True,exist_ok=True);marker.write_text(txt,encoding='utf-8')


_BASE_BOOT_LEDGERS=_v2245_boot_ledgers_after_identity
def _v2245_boot_ledgers_after_identity():
    _BASE_BOOT_LEDGERS()
    try:seed_canonical_review_change()
    except Exception as exc:append_error('seed_canonical_review_change',exc)



# Stable current prediction scorer. Historical replay imports remain evidence only.
try:
    from strategy_v2_core import score_rise_prediction as _v2198_score_current
except Exception:
    pass


V2202_CURRENT_MODEL='CANONICAL_TIMEAXIS_CONTINUATION'

# =============================================================================
# Review v2.114 / release v2265
# Compare material values across passed-up / passed-down / missed-up groups.
# Analysis only: no mainline condition or historical trade reclassification.
# =============================================================================
_V2265_BASE_BUILD_REVIEW_SNAPSHOT=build_review_snapshot
_V2265_BASE_PUBLISH_CANONICAL=publish_canonical_review_status


def _v2265_mean(values):
    vals=[float(x) for x in values if isinstance(x,(int,float)) and math.isfinite(float(x))]
    return sum(vals)/len(vals) if vals else None


def _v2265_std(values):
    vals=[float(x) for x in values if isinstance(x,(int,float)) and math.isfinite(float(x))]
    if len(vals)<2:return None
    avg=sum(vals)/len(vals);return math.sqrt(sum((x-avg)**2 for x in vals)/(len(vals)-1))


def build_material_comparison_v2265(selected):
    try:
        from strategy_v2_core import evaluate_timeaxis_prediction, PREDICTION_MODEL_GENERATION
    except Exception as exc:
        return {'schema':'material_group_comparison_v2265','state':'IMPORT_ERROR','error':f'{type(exc).__name__}: {exc}','analysis_only':True,'auto_buy':False}
    index,_=read_candle_index(force=False)
    groups={label:{name:{} for name in ('passed_up','passed_down','missed_up')} for label in ('3h','6h')}
    event_counts={label:Counter() for label in ('3h','6h')};diag=Counter()
    for value in (selected or {}).values():
        row=_selected_event_row(value)
        if not row:continue
        seal=row.get('prediction_input_seal_v2188') if isinstance(row.get('prediction_input_seal_v2188'),dict) else {}
        entry_ts,_=_v2206_exact_entry_ts(row,seal);symbol=ticker(row.get('ticker'))
        if entry_ts is None or not symbol or symbol not in index or (symbol!='BTC' and 'BTC' not in index):diag['SOURCE_MISSING']+=1;continue
        lab=_index_lab(index,symbol,entry_ts);btc_lab=_index_lab(index,'BTC',entry_ts)
        try:result=evaluate_timeaxis_prediction(lab,btc_lab,entry_ts,symbol,seal.get('axes') if isinstance(seal.get('axes'),dict) else {},seal.get('connections') if isinstance(seal.get('connections'),dict) else {})
        except Exception as exc:diag[f'EVAL:{type(exc).__name__}']+=1;continue
        context=result.get('timeaxis_context') if isinstance(result.get('timeaxis_context'),dict) else {}
        start=context.get('rise_start_materials_v2265') if isinstance(context.get('rise_start_materials_v2265'),dict) else {}
        values=start.get('values') if isinstance(start.get('values'),dict) else {}
        if not values:diag['MATERIAL_VALUES_MISSING']+=1;continue
        passed=str(result.get('state') or '')=='CONTINUATION_FAVORED'
        for label in ('3h','6h'):
            horizon=_v2206_horizon_raw(row,label,entry_ts)
            if not isinstance(horizon,dict) or horizon.get('state')!='READY':continue
            truth=str(horizon.get('truth') or '')
            group='passed_up' if passed and truth=='UP' else 'passed_down' if passed and truth!='UP' else 'missed_up' if (not passed and truth=='UP') else None
            if not group:continue
            event_counts[label][group]+=1
            for name,val in values.items():
                num=_v2202_num(val)
                if num is None:continue
                groups[label][group].setdefault(str(name),[]).append(float(num))
    horizons={}
    for label in ('3h','6h'):
        all_features=sorted(set().union(*(set(groups[label][g]) for g in groups[label])))
        means={g:{name:round(_v2265_mean(groups[label][g].get(name,[])),6) for name in all_features if _v2265_mean(groups[label][g].get(name,[])) is not None} for g in groups[label]}
        effects=[]
        for name in all_features:
            a=groups[label]['passed_up'].get(name,[]);b=groups[label]['passed_down'].get(name,[]);c=groups[label]['missed_up'].get(name,[])
            ma=_v2265_mean(a);mb=_v2265_mean(b);mc=_v2265_mean(c);scale=_v2265_std(list(a)+list(b)+list(c))
            if ma is None:continue
            effects.append({'material':name,'passed_up_mean':round(ma,6),'passed_down_mean':round(mb,6) if mb is not None else None,
                'missed_up_mean':round(mc,6) if mc is not None else None,
                'passed_down_minus_passed_up':round(mb-ma,6) if mb is not None else None,
                'missed_up_minus_passed_up':round(mc-ma,6) if mc is not None else None,
                'standardized_passed_down_gap':round((mb-ma)/scale,4) if mb is not None and scale and scale>0 else None,
                'standardized_missed_up_gap':round((mc-ma)/scale,4) if mc is not None and scale and scale>0 else None,
                'used_in_final_decision':False})
        effects.sort(key=lambda x:max(abs(float(x.get('standardized_passed_down_gap') or 0.0)),abs(float(x.get('standardized_missed_up_gap') or 0.0))),reverse=True)
        horizons[label]={'event_counts':dict(event_counts[label]),'group_means':means,'material_differences':effects,
            'top_differences':effects[:8],'conditions_changed':False,'analysis_only':True}
    return {'schema':'material_group_comparison_v2265','state':'READY' if any(event_counts[x] for x in event_counts) else 'CHECK',
        'model_generation':PREDICTION_MODEL_GENERATION,'groups':{'A':'passed_up','B':'passed_down','C':'missed_up'},
        'horizons':horizons,'diagnostics':dict(diag),'same_core_evaluator':True,'event_time_completed_candles':True,
        'new_gate_added':False,'threshold_changed':False,'historical_performance_rewritten':False,'new_shadow_created':False,'auto_buy':False}


def build_review_snapshot(selected,diag,info):  # type: ignore[override]
    snapshot=dict(_V2265_BASE_BUILD_REVIEW_SNAPSHOT(selected,diag,info) or {})
    snapshot['material_group_comparison_v2265']=build_material_comparison_v2265(selected)
    snapshot['material_comparison_analysis_only_v2265']=True
    return snapshot


def publish_canonical_review_status():  # type: ignore[override]
    canonical=dict(_V2265_BASE_PUBLISH_CANONICAL() or {})
    try:
        outcome=load_json(OUTCOME_STATUS,{}) or {};analysis=outcome.get('review_analysis_v2238') if isinstance(outcome.get('review_analysis_v2238'),dict) else {}
        snapshot=analysis.get('snapshot') if isinstance(analysis.get('snapshot'),dict) else outcome.get('prediction_validation_v2202') if isinstance(outcome.get('prediction_validation_v2202'),dict) else {}
        comparison=snapshot.get('material_group_comparison_v2265') if isinstance(snapshot.get('material_group_comparison_v2265'),dict) else {}
        canonical['material_group_comparison_v2265']=comparison;canonical['new_gate_added_v2265']=False
        outcome['review_status']=canonical
        if isinstance(analysis,dict):analysis=dict(analysis);analysis['review_status']=canonical;outcome['review_analysis_v2238']=analysis
        _atomic_json(OUTCOME_STATUS,outcome)
    except Exception as exc:append_error('publish_material_comparison_v2265',exc)
    return canonical

VERSION='review_worker_v2.114'
BUILD_LABEL='v2265_material_group_comparison_no_gate_2026-07-28'
MAIN_DEPLOY_VERSION=BUILD_LABEL



# =============================================================================
# Review v2.115 / release v2267
# Existing exact-result regrouping only.  This is not a Shadow: no hypothetical
# entry, OPEN, exit, PnL ledger, candidate, gate, score or threshold is created.
# =============================================================================
_V2267_BASE_BUILD_REVIEW_SNAPSHOT = build_review_snapshot
_V2267_BASE_PUBLISH_CANONICAL = publish_canonical_review_status
_V2267_BASE_RUN_ONCE = run_once


def _v2267_num(value):
    try:
        value=float(value)
        return value if math.isfinite(value) else None
    except Exception:
        return None


def _v2267_state(long3,long6,short30,short1h):
    # Zero is kept as neutral.  No tunable percentage threshold is introduced.
    if long3 is None or long6 is None:
        long_state='DATA_MISSING'
    elif long3>0 and long6>0:
        long_state='RISING'
    elif long3<0 and long6<0:
        long_state='FALLING'
    else:
        long_state='SIDEWAYS_OR_DISAGREE'
    if short30 is None or short1h is None:
        short_state='DATA_MISSING'
    elif short30>0 and short1h>0:
        short_state='RISING'
    elif short30<0 and short1h<0:
        short_state='FALLING'
    else:
        short_state='MIXED_OR_FLAT'
    return long_state,short_state


def _v2267_empty():
    return {'n':0,'up':0,'down':0,'flat':0,'pass':0,'hold':0,'close_sum':0.0,'close_n':0,
            'mfe_sum':0.0,'mfe_n':0,'mae_sum':0.0,'mae_n':0,'fade_sum':0.0,'fade_n':0}


def _v2267_add(cell,horizon,passed):
    cell['n']+=1
    truth=str(horizon.get('truth') or '')
    if truth=='UP':cell['up']+=1
    elif truth=='DOWN':cell['down']+=1
    else:cell['flat']+=1
    cell['pass' if passed else 'hold']+=1
    close=_v2267_num(horizon.get('close_pct'))
    mfe=_v2267_num(horizon.get('mfe_pct'))
    mae=_v2267_num(horizon.get('mae_pct'))
    if close is not None:cell['close_sum']+=close;cell['close_n']+=1
    if mfe is not None:cell['mfe_sum']+=mfe;cell['mfe_n']+=1
    if mae is not None:cell['mae_sum']+=mae;cell['mae_n']+=1
    if close is not None and mfe is not None:
        cell['fade_sum']+=max(0.0,mfe-close);cell['fade_n']+=1


def _v2267_public(cell):
    n=int(cell.get('n') or 0)
    def avg(sum_key,n_key):
        count=int(cell.get(n_key) or 0)
        return round(float(cell.get(sum_key) or 0.0)/count,6) if count else None
    return {'n':n,'up':int(cell.get('up') or 0),'down':int(cell.get('down') or 0),'flat':int(cell.get('flat') or 0),
        'up_rate_pct':round(int(cell.get('up') or 0)/n*100.0,2) if n else None,
        'pass_count':int(cell.get('pass') or 0),'hold_count':int(cell.get('hold') or 0),
        'avg_close_pct':avg('close_sum','close_n'),'avg_mfe_pct':avg('mfe_sum','mfe_n'),
        'avg_mae_pct':avg('mae_sum','mae_n'),'avg_fade_from_mfe_pct':avg('fade_sum','fade_n')}


def build_timeaxis_state_outcome_comparison_v2267(selected):
    try:
        from strategy_v2_core import evaluate_timeaxis_prediction, PREDICTION_MODEL_GENERATION
    except Exception as exc:
        return {'schema':'timeaxis_state_outcome_comparison_v2267','state':'IMPORT_ERROR',
            'error':f'{type(exc).__name__}: {exc}','analysis_only':True,'new_shadow_created':False,'auto_buy':False}
    index,_=read_candle_index(force=False)
    cells={h:{k:_v2267_empty() for k in (
        'long_rising_short_rising','long_sideways_short_rising','long_falling_short_rising',
        'long_rising_short_not_rising','long_sideways_short_not_rising','long_falling_short_not_rising')}
        for h in ('3h','6h')}
    diag=Counter()
    for value in (selected or {}).values():
        row=_selected_event_row(value)
        if not row:continue
        seal=row.get('prediction_input_seal_v2188') if isinstance(row.get('prediction_input_seal_v2188'),dict) else {}
        entry_ts,_=_v2206_exact_entry_ts(row,seal);symbol=ticker(row.get('ticker'))
        if entry_ts is None or not symbol or symbol not in index or (symbol!='BTC' and 'BTC' not in index):
            diag['SOURCE_MISSING']+=1;continue
        lab=_index_lab(index,symbol,entry_ts);btc_lab=_index_lab(index,'BTC',entry_ts)
        try:
            result=evaluate_timeaxis_prediction(lab,btc_lab,entry_ts,symbol,
                seal.get('axes') if isinstance(seal.get('axes'),dict) else {},
                seal.get('connections') if isinstance(seal.get('connections'),dict) else {})
        except Exception as exc:
            diag[f'EVAL:{type(exc).__name__}']+=1;continue
        context=result.get('timeaxis_context') if isinstance(result.get('timeaxis_context'),dict) else {}
        start=context.get('rise_start_materials_v2265') if isinstance(context.get('rise_start_materials_v2265'),dict) else {}
        vals=start.get('values') if isinstance(start.get('values'),dict) else {}
        long3=_v2267_num(vals.get('price_return_3h_pct'));long6=_v2267_num(vals.get('price_return_6h_pct'))
        short30=_v2267_num(vals.get('price_return_30m_pct'));short1h=_v2267_num(vals.get('price_return_1h_pct'))
        long_state,short_state=_v2267_state(long3,long6,short30,short1h)
        if 'DATA_MISSING' in (long_state,short_state):diag['MATERIAL_DATA_MISSING']+=1;continue
        long_key='rising' if long_state=='RISING' else 'falling' if long_state=='FALLING' else 'sideways'
        short_key='rising' if short_state=='RISING' else 'not_rising'
        key=f'long_{long_key}_short_{short_key}'
        passed=str(result.get('state') or '')=='CONTINUATION_FAVORED'
        for h in ('3h','6h'):
            horizon=_v2206_horizon_raw(row,h,entry_ts)
            if not isinstance(horizon,dict) or horizon.get('state')!='READY':continue
            _v2267_add(cells[h][key],horizon,passed)
    horizons={h:{k:_v2267_public(v) for k,v in cells[h].items()} for h in cells}
    target_keys=('long_rising_short_rising','long_sideways_short_rising','long_falling_short_rising')
    return {'schema':'timeaxis_state_outcome_comparison_v2267',
        'state':'READY' if any(horizons[h][k]['n'] for h in horizons for k in target_keys) else 'CHECK',
        'model_generation':PREDICTION_MODEL_GENERATION,
        'classification_contract':{
            'long_rising':'3h>0 and 6h>0','long_falling':'3h<0 and 6h<0',
            'long_sideways':'remaining sign combination including zero/disagreement',
            'short_rising':'30m>0 and 1h>0','short_not_rising':'remaining sign combination including zero/disagreement',
            'percentage_threshold_added':False},
        'horizons':horizons,'diagnostics':dict(diag),'same_exact_events':True,
        'same_event_time_completed_candles':True,'hypothetical_entry_created':False,
        'virtual_open_created':False,'virtual_exit_created':False,'virtual_pnl_ledger_created':False,
        'candidate_or_gate_changed':False,'historical_performance_rewritten':False,
        'analysis_only':True,'new_shadow_created':False,'auto_buy':False}


def build_review_snapshot(selected,diag,info):  # type: ignore[override]
    snapshot=dict(_V2267_BASE_BUILD_REVIEW_SNAPSHOT(selected,diag,info) or {})
    snapshot['timeaxis_state_outcome_comparison_v2267']=build_timeaxis_state_outcome_comparison_v2267(selected)
    snapshot['timeaxis_state_comparison_analysis_only_v2267']=True
    return snapshot


def publish_canonical_review_status():  # type: ignore[override]
    canonical=dict(_V2267_BASE_PUBLISH_CANONICAL() or {})
    try:
        outcome=load_json(OUTCOME_STATUS,{}) or {}
        analysis=outcome.get('review_analysis_v2238') if isinstance(outcome.get('review_analysis_v2238'),dict) else {}
        snapshot=analysis.get('snapshot') if isinstance(analysis.get('snapshot'),dict) else outcome.get('prediction_validation_v2202') if isinstance(outcome.get('prediction_validation_v2202'),dict) else {}
        comparison=snapshot.get('timeaxis_state_outcome_comparison_v2267') if isinstance(snapshot.get('timeaxis_state_outcome_comparison_v2267'),dict) else {}
        canonical['timeaxis_state_outcome_comparison_v2267']=comparison
        canonical['new_shadow_created_v2267']=False
        outcome['review_status']=canonical
        if isinstance(analysis,dict):
            analysis=dict(analysis);analysis['review_status']=canonical;outcome['review_analysis_v2238']=analysis
        _atomic_json(OUTCOME_STATUS,outcome)
    except Exception as exc:append_error('publish_timeaxis_state_comparison_v2267',exc)
    return canonical


def _v2267_seed_ledgers():
    marker=BASE_DIR/'runtime'/'review_timeaxis_state_compare_v2267.seeded'
    if marker.exists():return
    ts=now_ts();txt=now_text(ts)
    append_jsonl(CHANGE_LEDGER,{'schema':'change_verify_ledger_v870','change_id':'V2267-REVIEW-TIMEAXIS-STATE-OUTCOME-COMPARE',
        'issue_id':'RISE-PREDICTION-LONG-SIDEWAYS-SHORT-RISE-NOT-SEPARATED','version':'v2267',
        'verify_result':'LOCAL_PASS_SERVER_CHECK','created_ts':ts,'created_at':txt,'writer':'review_worker_v2.115',
        'cause':'TARGET_WINDOWS_DISAGREE grouped long-window sideways/disagreement together without showing whether 30m/1h had already turned upward and whether those events later rose or fell.',
        'fix':'Regroup the same preserved exact events by 3h/6h state and 30m/1h state, then report count, UP rate, close, MFE, MAE and giveback. This is retrospective aggregation only; no hypothetical trade or virtual ledger is created.',
        'not_touched':['prediction formula/condition/weight/threshold','candidate/S1/Paper','trigger/invalid/target/RR','entry/exit','historical ledgers','new Shadow','auto-buy OFF'],'auto_buy':False})
    append_jsonl(ISSUE_LEDGER,{'schema':'issue_ledger_event_v1','event_type':'ISSUE',
        'issue_id':'RISE-PREDICTION-LONG-SIDEWAYS-SHORT-RISE-NOT-SEPARATED','status':'CHECK',
        'title':'장기횡보·단기상승 결과분리','detail':'기존 exact 결과만 장기상승/횡보·불일치/하락 × 단기상승 여부로 나눠 성과 비교. 가상 OPEN/CLOSED 없음.',
        'version':'v2267','created_ts':ts,'created_at':txt,'auto_buy':False})
    marker.parent.mkdir(parents=True,exist_ok=True);marker.write_text(txt,encoding='utf-8')


def run_once():  # type: ignore[override]
    result=_V2267_BASE_RUN_ONCE()
    try:_v2267_seed_ledgers()
    except Exception as exc:append_error('v2267_seed_ledgers',exc)
    return result

VERSION='review_worker_v2.115'
BUILD_LABEL='v2267_timeaxis_state_outcome_compare_no_shadow_2026-07-28'
MAIN_DEPLOY_VERSION=BUILD_LABEL

# =============================================================================
# Review v2.116 / release v2268
# One approved forward time-axis Shadow inside the existing Review owner.
# Three fixed arms; no candidate/entry/exit changes and no separate worker/service.
# =============================================================================
_V2268_BASE_BUILD_REVIEW_SNAPSHOT = build_review_snapshot
_V2268_BASE_PUBLISH_CANONICAL = publish_canonical_review_status
_V2268_BASE_RUN_ONCE = run_once
V2268_SHADOW_KEY='timeaxis_forward_shadow_v2268'
V2268_GROUPS=('long_rising_short_rising','long_sideways_short_rising','long_falling_short_rising')


def _v2268_shadow_state():
    state=load_json(OUTCOME_STATE,{}) or {}
    shadow=state.get(V2268_SHADOW_KEY) if isinstance(state,dict) and isinstance(state.get(V2268_SHADOW_KEY),dict) else {}
    if not shadow:
        ts=now_ts()
        shadow={'schema':'timeaxis_forward_shadow_v2268','state':'ACTIVE','start_ts':ts,'start_text':now_text(ts),
            'owner':'review_worker','single_shadow':True,'arms':list(V2268_GROUPS),'frozen_contract':True,
            'entry_rule':'same exact event-time price; observational only','exit_rule':'sealed 3h and 6h horizon outcomes',
            'new_worker_created':False,'new_service_created':False,'separate_ledger_created':False,
            'candidate_changed':False,'actual_entry_changed':False,'actual_exit_changed':False,'auto_buy':False}
        state[V2268_SHADOW_KEY]=shadow;state['version_v2268']='review_worker_v2.116';state['auto_buy']=False
        _atomic_json(OUTCOME_STATE,state)
    return shadow


def build_timeaxis_forward_shadow_v2268(selected):
    shadow=_v2268_shadow_state();start=float(_v2267_num(shadow.get('start_ts')) or 0.0)
    forward_selected={}
    for key,value in (selected or {}).items():
        row=_selected_event_row(value)
        if not row:continue
        seal=row.get('prediction_input_seal_v2188') if isinstance(row.get('prediction_input_seal_v2188'),dict) else {}
        entry_ts,_=_v2206_exact_entry_ts(row,seal)
        if entry_ts is not None and float(entry_ts)>=start:
            forward_selected[key]=value
    comp=build_timeaxis_state_outcome_comparison_v2267(forward_selected)
    # The exact-event engine uses preserved event-time inputs and sealed horizon outcomes.
    # Only events whose sealed entry time is at or after the frozen Shadow start are included.
    comp=dict(comp) if isinstance(comp,dict) else {}
    comp.update({'schema':'timeaxis_forward_shadow_v2268','shadow_state':'ACTIVE','shadow_start_ts':start,
        'shadow_start_text':shadow.get('start_text'),'forward_event_count':len(forward_selected),'single_shadow':True,'arms':list(V2268_GROUPS),
        'baseline_arm':'long_rising_short_rising','test_arms':['long_sideways_short_rising','long_falling_short_rising'],
        'cost_after_expectancy_required_before_promotion':True,'promotion_applied':False,
        'candidate_changed':False,'actual_entry_changed':False,'actual_exit_changed':False,
        'new_worker_created':False,'new_service_created':False,'separate_ledger_created':False,'auto_buy':False})
    return comp


def build_review_snapshot(selected,diag,info):  # type: ignore[override]
    snapshot=dict(_V2268_BASE_BUILD_REVIEW_SNAPSHOT(selected,diag,info) or {})
    snapshot['timeaxis_forward_shadow_v2268']=build_timeaxis_forward_shadow_v2268(selected)
    snapshot['approved_single_shadow_v2268']=True
    return snapshot


def publish_canonical_review_status():  # type: ignore[override]
    canonical=dict(_V2268_BASE_PUBLISH_CANONICAL() or {})
    try:
        outcome=load_json(OUTCOME_STATUS,{}) or {}
        analysis=outcome.get('review_analysis_v2238') if isinstance(outcome.get('review_analysis_v2238'),dict) else {}
        snapshot=analysis.get('snapshot') if isinstance(analysis.get('snapshot'),dict) else outcome.get('prediction_validation_v2202') if isinstance(outcome.get('prediction_validation_v2202'),dict) else {}
        shadow=snapshot.get('timeaxis_forward_shadow_v2268') if isinstance(snapshot.get('timeaxis_forward_shadow_v2268'),dict) else {}
        canonical['timeaxis_forward_shadow_v2268']=shadow
        canonical['approved_single_shadow_v2268']=True
        outcome['review_status']=canonical
        if isinstance(analysis,dict):
            analysis=dict(analysis);analysis['review_status']=canonical;outcome['review_analysis_v2238']=analysis
        _atomic_json(OUTCOME_STATUS,outcome)
    except Exception as exc:append_error('publish_timeaxis_forward_shadow_v2268',exc)
    return canonical


def _v2268_seed_ledgers():
    marker=BASE_DIR/'runtime'/'review_timeaxis_forward_shadow_v2268.seeded'
    if marker.exists():return
    ts=now_ts();txt=now_text(ts)
    append_jsonl(CHANGE_LEDGER,{'schema':'change_verify_ledger_v870','change_id':'V2268-MATERIAL-RECOVERY-TIMEAXIS-SINGLE-SHADOW',
        'issue_id':'TARGET-WINDOWS-DISAGREE-AND-MATERIAL-STALE','version':'v2268','verify_result':'LOCAL_PASS_SERVER_CHECK',
        'created_ts':ts,'created_at':txt,'writer':'review_worker_v2.116',
        'cause':'TARGET_WINDOWS_DISAGREE was dominant while many m30/h1/h4 materials were stale, and retrospective Review grouping alone could not provide a persistent forward comparison.',
        'fix':'Use one approved forward Shadow inside the existing Review owner with three frozen time-axis arms. Candle recovery throughput is repaired in the same release. Mainline candidates and trades remain unchanged.',
        'not_touched':['strategy thresholds/weights','candidate rank/count','trigger/invalid/target/RR','Paper OPEN/CLOSED','historical ledgers','auto-buy OFF'],
        'remaining':'Server prove stale count decreases, Review exact input becomes READY, and each Shadow arm accumulates sealed 3h/6h results.','auto_buy':False})
    append_jsonl(ISSUE_LEDGER,{'schema':'issue_ledger_event_v1','event_type':'ISSUE','issue_id':'TARGET-WINDOWS-DISAGREE-AND-MATERIAL-STALE',
        'status':'CHECK','title':'자료지연 수리와 시간축 단일 Shadow','detail':'기존 Candle 재수집 처리량을 높이고 Review 안의 단일 Shadow로 장기상승/횡보/하락+단기상승을 같은 exact 기준으로 비교한다.',
        'version':'v2268','created_ts':ts,'created_at':txt,'auto_buy':False})
    marker.parent.mkdir(parents=True,exist_ok=True);marker.write_text(txt,encoding='utf-8')


def run_once():  # type: ignore[override]
    result=_V2268_BASE_RUN_ONCE()
    try:_v2268_seed_ledgers()
    except Exception as exc:append_error('v2268_seed_ledgers',exc)
    return result

VERSION='review_worker_v2.116'
BUILD_LABEL='v2268_material_recovery_single_timeaxis_shadow_2026-07-28'
MAIN_DEPLOY_VERSION=BUILD_LABEL


# Review v2.117 / v2269: canonical state overlay is also an exact-input owner.
def _v2269_row_is_exact_input(row):
    if not isinstance(row,dict): return False
    generation=str(row.get('generation') or '')
    if generation and generation!=GENERATION: return False
    if not str(row.get('event_key') or '').strip(): return False
    seal=row.get('prediction_input_seal_v2188') if isinstance(row.get('prediction_input_seal_v2188'),dict) else {}
    if not (isinstance(seal.get('axes'),dict) and seal.get('axes') and isinstance(seal.get('connections'),dict) and seal.get('connections')): return False
    entry_ts,_=_v2206_exact_entry_ts(row,seal)
    return entry_ts is not None

def _v2269_scan_recent500():
    started=time.monotonic(); selected={}; read_bytes=0; inode=None; size=0; mtime_ns=0
    diag={'ledger_raw_rows':0,'ledger_json_errors':0,'state_raw_rows':0,'state_exact_inputs':0,'ledger_exact_inputs':0,
          'wrong_generation_raw':0,'missing_event_key_raw':0,'duplicates_removed':0,'state_overlay_input_owner_v2269':True,
          'sample_cap_v2243':V2243_SAMPLE_CAP,'scan_max_raw_rows_v2243':V2243_SCAN_MAX_RAW_ROWS,'scan_max_bytes_v2243':V2243_SCAN_MAX_BYTES}
    state=load_json(OUTCOME_STATE,{}) or {}; records=state.get(STATE_KEY) if isinstance(state.get(STATE_KEY),dict) else {}
    try: state_mtime_ns=int(OUTCOME_STATE.stat().st_mtime_ns)
    except Exception: state_mtime_ns=0
    for row in records.values():
        diag['state_raw_rows']+=1
        if _v2269_row_is_exact_input(row):
            diag['state_exact_inputs']+=1; _v2202_accept_raw(selected,row,2,diag)
    if OUTCOME_LEDGER.exists():
        st=OUTCOME_LEDGER.stat(); inode=getattr(st,'st_ino',None); size=int(st.st_size); mtime_ns=int(st.st_mtime_ns)
        for raw,read_bytes,_ in _v2220_reverse_lines(OUTCOME_LEDGER,max_bytes=V2243_SCAN_MAX_BYTES):
            diag['ledger_raw_rows']+=1
            if diag['ledger_raw_rows']>V2243_SCAN_MAX_RAW_ROWS: break
            try: row=json.loads(raw.decode('utf-8','replace'))
            except Exception: diag['ledger_json_errors']+=1; continue
            if not _v2269_row_is_exact_input(row): continue
            diag['ledger_exact_inputs']+=1; _v2202_accept_raw(selected,row,1,diag)
    selected=_v2243_prune(selected)
    diag.update({'ledger_unique_keys':len(selected),'selected_exact_events_v2243':len(selected),'selected_exact_inputs_v2269':len(selected),
                 'tail_bytes_read_v2243':int(read_bytes),'canonical_ledger_size_bytes_v2243':size,'state_mtime_ns_v2269':state_mtime_ns,
                 'full_history_scan_v2243':False,'scan_sec':round(time.monotonic()-started,3)})
    return selected,diag,{'inode':inode,'offset':size,'size':size,'mtime_ns':mtime_ns,'state_mtime_ns':state_mtime_ns,'tail_bytes':int(read_bytes),'scan_sec':diag['scan_sec'],'sample_cap':V2243_SAMPLE_CAP}

_v2243_scan_recent500=_v2269_scan_recent500

_V2269_REVIEW_RUN=run_once
def run_once():
    result=_V2269_REVIEW_RUN()
    marker=BASE_DIR/'runtime'/'review_exact_state_overlay_input_v2269.seeded'
    if not marker.exists():
        ts=now_ts(); txt=now_text(ts)
        append_jsonl(CHANGE_LEDGER,{'schema':'change_verify_ledger_v870','change_id':'V2269-REVIEW-EXACT-STATE-OVERLAY-INPUT','issue_id':'REVIEW-INPUT-WAITING-ZERO-STATE-OVERLAY','version':'v2269','verify_result':'LOCAL_PASS_SERVER_CHECK','created_ts':ts,'created_at':txt,'writer':'review_worker_v2.117','cause':'Recent-500 input selection required finalized rows with a horizon, hiding current sealed exact inputs in canonical state.','fix':'Merge canonical state sealed inputs first and finalized ledger rows second; keep result maturity separate.','not_touched':['prediction formula/weights/threshold','candidate/S1/Paper','entry/exit','canonical ledgers','Shadow start/data','auto-buy OFF'],'remaining':'Server prove input >0, contract match and Shadow growth.','auto_buy':False})
        append_jsonl(ISSUE_LEDGER,{'schema':'issue_ledger_event_v1','event_type':'ISSUE','issue_id':'REVIEW-INPUT-WAITING-ZERO-STATE-OVERLAY','status':'CHECK','title':'Review exact 입력 0/500 원천수리','detail':'현재 canonical state의 봉인 exact 입력을 결과 성숙 전에도 입력으로 인정한다.','version':'v2269','created_ts':ts,'created_at':txt,'auto_buy':False})
        marker.parent.mkdir(parents=True,exist_ok=True); marker.write_text(txt,encoding='utf-8')
    return result

VERSION='review_worker_v2.117'
BUILD_LABEL='v2269_review_exact_state_overlay_daily_safe_rotation_2026-07-28'
MAIN_DEPLOY_VERSION=BUILD_LABEL




# Review v2.118 / v2270: seed exact input from the existing canonical Strategy snapshot.
# This repairs INPUT_WAITING without creating another decision owner or Shadow.
def _v2270_event_ts(row, contract, snapshot):
    for obj in (row, contract, snapshot):
        if not isinstance(obj, dict):
            continue
        for key in ('event_ts','candidate_event_ts','sealed_ts','published_ts','updated_ts','created_ts','ts'):
            try:
                value=float(obj.get(key) or 0.0)
            except Exception:
                value=0.0
            if value>0:
                return value
    return now_ts()

def _v2270_seed_from_canonical_snapshot():
    snapshot, rows=_v2171_snapshot()
    if not isinstance(snapshot,dict) or not rows:
        return {'state':'WAITING_SNAPSHOT','rows':0,'created':0}
    state=load_json(OUTCOME_STATE,{}) or {}
    state=dict(state) if isinstance(state,dict) else {}
    records=state.get(STATE_KEY) if isinstance(state.get(STATE_KEY),dict) else {}
    records={str(k):v for k,v in records.items() if isinstance(v,dict)}
    created=0; accepted=0
    for row in rows:
        if not isinstance(row,dict):
            continue
        contract=contract_of(row)
        price=row_price(row)
        key=stable_key(row,contract) if isinstance(contract,dict) else ''
        if not contract or not key or not price or price<=0:
            continue
        accepted+=1
        if key in records:
            continue
        event_ts=_v2270_event_ts(row,contract,snapshot)
        rec=create_record(row,contract,price,event_ts,key)
        rec['canonical_snapshot_seed_v2270']=True
        rec['candidate_snapshot_id_v2270']=snapshot.get('snapshot_id')
        rec['candidate_commit_id_v2270']=snapshot.get('candidate_commit_id')
        rec['cycle_id_v2270']=snapshot.get('cycle_id')
        rec['generation']=GENERATION
        records[key]=rec
        created+=1
    if created:
        state.update({'schema':'strategy_v2_outcome_state_v2270','version':'review_worker_v2.118',
                      'updated_ts':now_ts(),'updated_text':now_text(),STATE_KEY:records,
                      'active_generation':GENERATION,'canonical_snapshot_seed_owner_v2270':'review',
                      'historical_ledgers_rewritten':False,'auto_buy':False})
        _atomic_json(OUTCOME_STATE,state)
    return {'state':'READY' if accepted else 'WAITING_ROWS','rows':accepted,'created':created,
            'snapshot_id':snapshot.get('snapshot_id'),'candidate_commit_id':snapshot.get('candidate_commit_id')}

_V2270_BASE_RUN_ONCE=run_once
def run_once():  # type: ignore[override]
    # v2293 root repair: the historical v2270 snapshot seed is no longer part
    # of the live cycle. It rewrote the full canonical outcome state after every
    # bounded Review pass and could hold the only Review process before the next
    # health write. Existing state/ledger rows remain intact and are read by the
    # already-active v2269 state-overlay + bounded-ledger owner.
    try:
        status=load_json(STATUS,{}) or {}; status=dict(status) if isinstance(status,dict) else {}
        ts=now_ts()
        status.update({'version':'review_worker_v2.121','build':'v2293_review_live_cycle_without_legacy_state_reseed_2026-07-29',
            'state':'running','pid':os.getpid(),'updated_ts':ts,'updated_text':now_text(ts),
            'phase':'ANALYSIS_CYCLE_START_V2293','legacy_snapshot_reseed_active_v2293':False,
            'historical_ledgers_rewritten':False,'historical_ledgers_deleted':False,'auto_buy':False})
        _v2243_atomic_status(STATUS,status)
    except Exception as exc:
        append_error('v2293_cycle_start_status',exc)
    result = _V2270_BASE_RUN_ONCE()
    # v2294: publish one completion receipt from the existing bounded Review
    # result. This is the sole health status owner after a completed cycle; no
    # ledger, Shadow, prediction formula, or trading contract is changed.
    try:
        samples = read_trade_samples()
        def _pnl(row):
            for key in ('net_pnl_pct','realized_pnl_pct','pnl_pct','return_pct','profit_pct'):
                try:
                    if row.get(key) is not None: return float(row.get(key))
                except Exception:
                    pass
            return None
        pnls=[v for v in (_pnl(x) for x in samples if isinstance(x,dict)) if v is not None]
        status=load_json(STATUS,{}) or {}; status=dict(status) if isinstance(status,dict) else {}
        ts=now_ts()
        result_count=((result.get('results') or {}).get('count') or {}) if isinstance(result,dict) else {}
        status.update({
            'version':'review_worker_v2.122','build':'v2294_review_cycle_completion_receipt_owner_2026-07-29',
            'state':'running','pid':os.getpid(),'updated_ts':ts,'updated_text':now_text(ts),
            'phase':'ANALYSIS_CYCLE_COMPLETE_V2294','last_completed_ts':ts,
            'last_sec':float(status.get('cycle_sec') or status.get('cycle_elapsed_sec') or 0.0),
            'closed_recent':len(samples),'big_loss':sum(1 for v in pnls if v<=-2.0),
            'good_win':sum(1 for v in pnls if v>=2.0),'result_count':result_count,
            'cycle_complete_v2294':True,'legacy_snapshot_reseed_active_v2293':False,
            'historical_ledgers_rewritten':False,'historical_ledgers_deleted':False,'auto_buy':False})
        _v2243_atomic_status(STATUS,status)
    except Exception as exc:
        append_error('v2294_cycle_complete_status',exc)
    return result

# v2294 final active identity. Historical code remains as evidence but only the
# bounded live cycle and its single completion receipt are active.
VERSION='review_worker_v2.122'
BUILD_LABEL='v2294_review_cycle_completion_receipt_owner_2026-07-29'
MAIN_DEPLOY_VERSION=BUILD_LABEL

# =============================================================================
# Review v2.123 / release v2313
# Extend the already-approved single Review Shadow with observation-only
# short-force, material-separation and volume-damage evidence.
# No gate, rank, candidate, entry, exit, OPEN/CLOSED or auto-buy change.
# =============================================================================
_V2313_BASE_BUILD_REVIEW_SNAPSHOT = build_review_snapshot
_V2313_BASE_PUBLISH_CANONICAL = publish_canonical_review_status
_V2313_BASE_RUN_ONCE = run_once

def _v2313_num(value):
    try:
        value=float(value)
        return value if math.isfinite(value) else None
    except Exception:
        return None

def _v2313_group(passed, horizon):
    truth=str((horizon or {}).get('truth') or '')
    if passed and truth=='UP': return 'A_PASS_UP'
    if passed and truth=='DOWN': return 'B_PASS_DOWN'
    if (not passed) and truth=='UP': return 'C_HOLD_UP'
    if (not passed) and truth=='DOWN': return 'D_HOLD_DOWN'
    return None

def _v2313_empty_cell():
    return {'n':0,'values':{},'volume_damage_n':0,'volume_damage_close_sum':0.0,
            'mfe_sum':0.0,'mae_sum':0.0,'close_sum':0.0}

def _v2313_add_value(cell,key,value):
    value=_v2313_num(value)
    if value is None:return
    slot=cell['values'].setdefault(key,{'n':0,'sum':0.0})
    slot['n']+=1;slot['sum']+=value

def _v2313_public(cell):
    n=int(cell.get('n') or 0)
    values={}
    for key,slot in (cell.get('values') or {}).items():
        c=int(slot.get('n') or 0)
        values[key]=round(float(slot.get('sum') or 0.0)/c,6) if c else None
    return {'n':n,'avg':values,
        'volume_damage_n':int(cell.get('volume_damage_n') or 0),
        'volume_damage_rate_pct':round(int(cell.get('volume_damage_n') or 0)/n*100.0,2) if n else None,
        'avg_close_pct':round(float(cell.get('close_sum') or 0.0)/n,6) if n else None,
        'avg_mfe_pct':round(float(cell.get('mfe_sum') or 0.0)/n,6) if n else None,
        'avg_mae_pct':round(float(cell.get('mae_sum') or 0.0)/n,6) if n else None}

def build_material_volume_shadow_v2313(selected):
    try:
        from strategy_v2_core import evaluate_timeaxis_prediction
    except Exception as exc:
        return {'schema':'material_volume_shadow_v2313','state':'IMPORT_ERROR',
                'error':f'{type(exc).__name__}: {exc}','analysis_only':True,'auto_buy':False}
    shadow=_v2268_shadow_state()
    start=float(_v2313_num(shadow.get('start_ts')) or 0.0)
    index,_=read_candle_index(force=False)
    cells={h:{g:_v2313_empty_cell() for g in ('A_PASS_UP','B_PASS_DOWN','C_HOLD_UP','D_HOLD_DOWN')}
           for h in ('3h','6h')}
    coverage=Counter();events=0
    for value in (selected or {}).values():
        row=_selected_event_row(value)
        if not row:continue
        seal=row.get('prediction_input_seal_v2188') if isinstance(row.get('prediction_input_seal_v2188'),dict) else {}
        entry_ts,_=_v2206_exact_entry_ts(row,seal);symbol=ticker(row.get('ticker'))
        if entry_ts is None or float(entry_ts)<start or not symbol or symbol not in index or (symbol!='BTC' and 'BTC' not in index):
            continue
        lab=_index_lab(index,symbol,entry_ts);btc_lab=_index_lab(index,'BTC',entry_ts)
        try:
            result=evaluate_timeaxis_prediction(lab,btc_lab,entry_ts,symbol,
                seal.get('axes') if isinstance(seal.get('axes'),dict) else {},
                seal.get('connections') if isinstance(seal.get('connections'),dict) else {})
        except Exception:
            continue
        context=result.get('timeaxis_context') if isinstance(result.get('timeaxis_context'),dict) else {}
        startm=context.get('rise_start_materials_v2265') if isinstance(context.get('rise_start_materials_v2265'),dict) else {}
        vals=startm.get('values') if isinstance(startm.get('values'),dict) else {}
        passed=str(result.get('state') or '')=='CONTINUATION_FAVORED'
        events+=1
        observe={
            'price_return_30m_pct':vals.get('price_return_30m_pct'),
            'price_return_1h_pct':vals.get('price_return_1h_pct'),
            'price_return_3h_pct':vals.get('price_return_3h_pct'),
            'price_return_6h_pct':vals.get('price_return_6h_pct'),
            'price_acceleration_1h_vs_prior1h_pct':vals.get('price_acceleration_1h_vs_prior1h_pct'),
            'relative_strength_1h_pct':vals.get('relative_strength_1h_pct'),
            'relative_strength_3h_pct':vals.get('relative_strength_3h_pct'),
            'relative_strength_acceleration_pct':vals.get('relative_strength_acceleration_pct'),
            'turnover_growth_recent1h_vs_prior3h_pct':vals.get('turnover_growth_recent1h_vs_prior3h_pct'),
            'higher_low_ratio_recent3h':vals.get('higher_low_ratio_recent3h'),
            'range_compression_ratio_recent3h':vals.get('range_compression_ratio_recent3h'),
            'distance_from_recent_high_pct':vals.get('distance_from_recent_high_pct'),
        }
        for k,v in observe.items():
            if _v2313_num(v) is not None:coverage[k]+=1
        price1=_v2313_num(observe.get('price_return_1h_pct'))
        turn=_v2313_num(observe.get('turnover_growth_recent1h_vs_prior3h_pct'))
        accel=_v2313_num(observe.get('price_acceleration_1h_vs_prior1h_pct'))
        # Observation label only: price is positive while participation or acceleration is already weakening.
        volume_damage=bool(price1 is not None and price1>0 and (
            (turn is not None and turn<0) or (accel is not None and accel<0)))
        for h in ('3h','6h'):
            horizon=_v2206_horizon_raw(row,h,entry_ts)
            if not isinstance(horizon,dict) or horizon.get('state')!='READY':continue
            group=_v2313_group(passed,horizon)
            if not group:continue
            cell=cells[h][group];cell['n']+=1
            for k,v in observe.items():_v2313_add_value(cell,k,v)
            close=_v2313_num(horizon.get('close_pct')) or 0.0
            mfe=_v2313_num(horizon.get('mfe_pct')) or 0.0
            mae=_v2313_num(horizon.get('mae_pct')) or 0.0
            cell['close_sum']+=close;cell['mfe_sum']+=mfe;cell['mae_sum']+=mae
            if volume_damage:
                cell['volume_damage_n']+=1;cell['volume_damage_close_sum']+=close
    public={h:{g:_v2313_public(c) for g,c in groups.items()} for h,groups in cells.items()}
    coverage_public={k:{'ready':int(v),'missing':max(0,events-int(v)),
                        'coverage_pct':round(int(v)/events*100.0,2) if events else None}
                     for k,v in coverage.items()}
    return {'schema':'material_volume_shadow_v2313',
        'state':'ACTIVE' if events else 'WAITING','owner':'review_worker',
        'extends_existing_single_shadow':True,'new_shadow_created':False,
        'forward_event_count':events,'groups':public,'material_coverage':coverage_public,
        'volume_damage_contract':'observation only: 1h price>0 and (turnover growth<0 or 1h acceleration<0)',
        'missing_material_is_not_zero':True,'candidate_changed':False,'gate_changed':False,
        'actual_entry_changed':False,'actual_exit_changed':False,'historical_ledgers_rewritten':False,
        'promotion_applied':False,'auto_buy':False}

def build_review_snapshot(selected,diag,info):  # type: ignore[override]
    snapshot=dict(_V2313_BASE_BUILD_REVIEW_SNAPSHOT(selected,diag,info) or {})
    snapshot['material_volume_shadow_v2313']=build_material_volume_shadow_v2313(selected)
    snapshot['single_shadow_extended_v2313']=True
    return snapshot

def publish_canonical_review_status():  # type: ignore[override]
    canonical=dict(_V2313_BASE_PUBLISH_CANONICAL() or {})
    try:
        outcome=load_json(OUTCOME_STATUS,{}) or {}
        analysis=outcome.get('review_analysis_v2238') if isinstance(outcome.get('review_analysis_v2238'),dict) else {}
        snapshot=analysis.get('snapshot') if isinstance(analysis.get('snapshot'),dict) else {}
        block=snapshot.get('material_volume_shadow_v2313') if isinstance(snapshot.get('material_volume_shadow_v2313'),dict) else {}
        canonical['material_volume_shadow_v2313']=block
        canonical['single_shadow_extended_v2313']=True
        outcome['review_status']=canonical
        if isinstance(analysis,dict):
            analysis=dict(analysis);analysis['review_status']=canonical;outcome['review_analysis_v2238']=analysis
        _atomic_json(OUTCOME_STATUS,outcome)
    except Exception as exc:append_error('publish_material_volume_shadow_v2313',exc)
    return canonical

def _v2313_seed_ledgers():
    marker=BASE_DIR/'runtime'/'review_material_volume_shadow_v2313.seeded'
    if marker.exists():return
    ts=now_ts();txt=now_text(ts)
    append_jsonl(CHANGE_LEDGER,{'schema':'change_verify_ledger_v870','change_id':'V2313-REVIEW-SINGLE-SHADOW-MATERIAL-VOLUME',
        'issue_id':'PREDICTION-WIN-LOSS-SEPARATION-AND-PROFIT-GIVEBACK','version':'v2313',
        'verify_result':'LOCAL_PASS_SERVER_CHECK','created_ts':ts,'created_at':txt,'writer':'review_worker_v2.123',
        'cause':'Current positive direction/material levels do not separate continuation from late-stage fade, and profit giveback is large. Adding a live gate now could again kill valid candidates.',
        'fix':'Extend the existing approved single Review Shadow only. Compare A pass-up, B pass-down, C hold-up and D hold-down using short-force acceleration, relative-strength change, turnover growth, higher lows, compression and distance from high. Mark volume damage observation without changing candidates or exits.',
        'not_touched':['strategy conditions/weights/thresholds','candidate count/rank','S1/Paper','trigger/invalid/target/RR','entry/exit','OPEN/CLOSED','new worker/service/ledger','auto-buy OFF'],
        'auto_buy':False})
    append_jsonl(ISSUE_LEDGER,{'schema':'issue_ledger_event_v1','event_type':'ISSUE',
        'issue_id':'PREDICTION-WIN-LOSS-SEPARATION-AND-PROFIT-GIVEBACK','status':'CHECK',
        'title':'상승예측 승패분리·거래량훼손 단일 Shadow 관찰',
        'detail':'기존 단일 Shadow 안에서 A/B/C/D와 단기힘·거래대금 훼손·수익반납 연계를 관찰. 본선 조건/청산 미적용.',
        'version':'v2313','created_ts':ts,'created_at':txt,'auto_buy':False})
    marker.parent.mkdir(parents=True,exist_ok=True);marker.write_text(txt,encoding='utf-8')

def run_once():  # type: ignore[override]
    result=_V2313_BASE_RUN_ONCE()
    try:_v2313_seed_ledgers()
    except Exception as exc:append_error('v2313_seed_ledgers',exc)
    return result

VERSION='review_worker_v2.123'
BUILD_LABEL='v2313_single_shadow_material_volume_damage_observation_2026-07-30'
MAIN_DEPLOY_VERSION=BUILD_LABEL


# =============================================================================
# Review v2.124 / release v2314
# Runtime recovery: compute the material/volume Shadow in the already-existing
# exact-event pass instead of a second full 500-event candle/evaluation scan.
# =============================================================================
_V2314_ORIGINAL_TIMEAXIS_COMPARE = build_timeaxis_state_outcome_comparison_v2267
_V2314_MATERIAL_CACHE = {}

def build_timeaxis_state_outcome_comparison_v2267(selected):  # type: ignore[override]
    global _V2314_MATERIAL_CACHE
    try:
        from strategy_v2_core import evaluate_timeaxis_prediction, PREDICTION_MODEL_GENERATION
    except Exception as exc:
        _V2314_MATERIAL_CACHE={'schema':'material_volume_shadow_v2313','state':'IMPORT_ERROR',
            'error':f'{type(exc).__name__}: {exc}','analysis_only':True,'auto_buy':False}
        return {'schema':'timeaxis_state_outcome_comparison_v2267','state':'IMPORT_ERROR',
            'error':f'{type(exc).__name__}: {exc}','analysis_only':True,'new_shadow_created':False,'auto_buy':False}

    index,_=read_candle_index(force=False)
    cells={h:{k:_v2267_empty() for k in (
        'long_rising_short_rising','long_sideways_short_rising','long_falling_short_rising',
        'long_rising_short_not_rising','long_sideways_short_not_rising','long_falling_short_not_rising')}
        for h in ('3h','6h')}
    material_cells={h:{g:_v2313_empty_cell() for g in ('A_PASS_UP','B_PASS_DOWN','C_HOLD_UP','D_HOLD_DOWN')}
                    for h in ('3h','6h')}
    coverage=Counter();diag=Counter();events=0
    shadow=_v2268_shadow_state()
    shadow_start=float(_v2313_num(shadow.get('start_ts')) or 0.0)

    for value in (selected or {}).values():
        row=_selected_event_row(value)
        if not row:continue
        seal=row.get('prediction_input_seal_v2188') if isinstance(row.get('prediction_input_seal_v2188'),dict) else {}
        entry_ts,_=_v2206_exact_entry_ts(row,seal);symbol=ticker(row.get('ticker'))
        if entry_ts is None or not symbol or symbol not in index or (symbol!='BTC' and 'BTC' not in index):
            diag['SOURCE_MISSING']+=1;continue
        lab=_index_lab(index,symbol,entry_ts);btc_lab=_index_lab(index,'BTC',entry_ts)
        try:
            result=evaluate_timeaxis_prediction(lab,btc_lab,entry_ts,symbol,
                seal.get('axes') if isinstance(seal.get('axes'),dict) else {},
                seal.get('connections') if isinstance(seal.get('connections'),dict) else {})
        except Exception as exc:
            diag[f'EVAL:{type(exc).__name__}']+=1;continue

        context=result.get('timeaxis_context') if isinstance(result.get('timeaxis_context'),dict) else {}
        startm=context.get('rise_start_materials_v2265') if isinstance(context.get('rise_start_materials_v2265'),dict) else {}
        vals=startm.get('values') if isinstance(startm.get('values'),dict) else {}
        long3=_v2267_num(vals.get('price_return_3h_pct'));long6=_v2267_num(vals.get('price_return_6h_pct'))
        short30=_v2267_num(vals.get('price_return_30m_pct'));short1h=_v2267_num(vals.get('price_return_1h_pct'))
        long_state,short_state=_v2267_state(long3,long6,short30,short1h)
        if 'DATA_MISSING' in (long_state,short_state):diag['MATERIAL_DATA_MISSING']+=1;continue
        long_key='rising' if long_state=='RISING' else 'falling' if long_state=='FALLING' else 'sideways'
        short_key='rising' if short_state=='RISING' else 'not_rising'
        key=f'long_{long_key}_short_{short_key}'
        passed=str(result.get('state') or '')=='CONTINUATION_FAVORED'

        observe={
            'price_return_30m_pct':vals.get('price_return_30m_pct'),
            'price_return_1h_pct':vals.get('price_return_1h_pct'),
            'price_return_3h_pct':vals.get('price_return_3h_pct'),
            'price_return_6h_pct':vals.get('price_return_6h_pct'),
            'price_acceleration_1h_vs_prior1h_pct':vals.get('price_acceleration_1h_vs_prior1h_pct'),
            'relative_strength_1h_pct':vals.get('relative_strength_1h_pct'),
            'relative_strength_3h_pct':vals.get('relative_strength_3h_pct'),
            'relative_strength_acceleration_pct':vals.get('relative_strength_acceleration_pct'),
            'turnover_growth_recent1h_vs_prior3h_pct':vals.get('turnover_growth_recent1h_vs_prior3h_pct'),
            'higher_low_ratio_recent3h':vals.get('higher_low_ratio_recent3h'),
            'range_compression_ratio_recent3h':vals.get('range_compression_ratio_recent3h'),
            'distance_from_recent_high_pct':vals.get('distance_from_recent_high_pct'),
        }
        in_forward=float(entry_ts)>=shadow_start
        if in_forward:
            events+=1
            for k,v in observe.items():
                if _v2313_num(v) is not None:coverage[k]+=1
        price1=_v2313_num(observe.get('price_return_1h_pct'))
        turn=_v2313_num(observe.get('turnover_growth_recent1h_vs_prior3h_pct'))
        accel=_v2313_num(observe.get('price_acceleration_1h_vs_prior1h_pct'))
        volume_damage=bool(price1 is not None and price1>0 and (
            (turn is not None and turn<0) or (accel is not None and accel<0)))

        for h in ('3h','6h'):
            horizon=_v2206_horizon_raw(row,h,entry_ts)
            if not isinstance(horizon,dict) or horizon.get('state')!='READY':continue
            _v2267_add(cells[h][key],horizon,passed)
            if not in_forward:continue
            group=_v2313_group(passed,horizon)
            if not group:continue
            cell=material_cells[h][group];cell['n']+=1
            for k,v in observe.items():_v2313_add_value(cell,k,v)
            close=_v2313_num(horizon.get('close_pct')) or 0.0
            mfe=_v2313_num(horizon.get('mfe_pct')) or 0.0
            mae=_v2313_num(horizon.get('mae_pct')) or 0.0
            cell['close_sum']+=close;cell['mfe_sum']+=mfe;cell['mae_sum']+=mae
            if volume_damage:
                cell['volume_damage_n']+=1;cell['volume_damage_close_sum']+=close

    horizons={h:{k:_v2267_public(v) for k,v in cells[h].items()} for h in cells}
    target_keys=('long_rising_short_rising','long_sideways_short_rising','long_falling_short_rising')
    material_public={h:{g:_v2313_public(c) for g,c in groups.items()} for h,groups in material_cells.items()}
    coverage_public={k:{'ready':int(v),'missing':max(0,events-int(v)),
                        'coverage_pct':round(int(v)/events*100.0,2) if events else None}
                     for k,v in coverage.items()}
    _V2314_MATERIAL_CACHE={'schema':'material_volume_shadow_v2313',
        'state':'ACTIVE' if events else 'WAITING','owner':'review_worker',
        'extends_existing_single_shadow':True,'new_shadow_created':False,
        'forward_event_count':events,'groups':material_public,'material_coverage':coverage_public,
        'volume_damage_contract':'observation only: 1h price>0 and (turnover growth<0 or 1h acceleration<0)',
        'missing_material_is_not_zero':True,'candidate_changed':False,'gate_changed':False,
        'actual_entry_changed':False,'actual_exit_changed':False,'historical_ledgers_rewritten':False,
        'promotion_applied':False,'single_pass_runtime_recovery_v2314':True,'auto_buy':False}

    return {'schema':'timeaxis_state_outcome_comparison_v2267',
        'state':'READY' if any(horizons[h][k]['n'] for h in horizons for k in target_keys) else 'CHECK',
        'model_generation':PREDICTION_MODEL_GENERATION,
        'classification_contract':{
            'long_rising':'3h>0 and 6h>0','long_falling':'3h<0 and 6h<0',
            'long_sideways':'remaining sign combination including zero/disagreement',
            'short_rising':'30m>0 and 1h>0','short_not_rising':'remaining sign combination including zero/disagreement',
            'percentage_threshold_added':False},
        'horizons':horizons,'diagnostics':dict(diag),'same_exact_events':True,
        'same_event_time_completed_candles':True,'hypothetical_entry_created':False,
        'virtual_open_created':False,'virtual_exit_created':False,'virtual_pnl_ledger_created':False,
        'candidate_or_gate_changed':False,'historical_performance_rewritten':False,
        'analysis_only':True,'new_shadow_created':False,'auto_buy':False}

def build_material_volume_shadow_v2313(selected):  # type: ignore[override]
    return dict(_V2314_MATERIAL_CACHE or {
        'schema':'material_volume_shadow_v2313','state':'WAITING',
        'single_pass_runtime_recovery_v2314':True,'analysis_only':True,'auto_buy':False})

def _v2314_seed_ledgers():
    marker=BASE_DIR/'runtime'/'review_material_volume_shadow_v2314.seeded'
    if marker.exists():return
    ts=now_ts();txt=now_text(ts)
    append_jsonl(CHANGE_LEDGER,{'schema':'change_verify_ledger_v870','change_id':'V2314-REVIEW-FRESH-RUNTIME-RECOVERY',
        'issue_id':'V2313-REVIEW-FRESH-RUNTIME-PROOF-FAILED','version':'v2314',
        'verify_result':'LOCAL_PASS_SERVER_CHECK','created_ts':ts,'created_at':txt,'writer':'review_worker_v2.124',
        'cause':'v2313 evaluated the same recent 500 exact events a second time for the material/volume extension. Review did not publish a fresh runtime proof within the Guard window.',
        'fix':'Collect the material/volume A/B/C/D aggregates inside the already-existing exact-event evaluation pass and publish the cached aggregate. No second full candle/evaluation scan.',
        'not_touched':['strategy conditions/weights/thresholds','candidate/S1/Paper','entry/exit','OPEN/CLOSED','Shadow contract','auto-buy OFF'],
        'auto_buy':False})
    append_jsonl(ISSUE_LEDGER,{'schema':'issue_ledger_event_v1','event_type':'ISSUE',
        'issue_id':'V2313-REVIEW-FRESH-RUNTIME-PROOF-FAILED','status':'CHECK',
        'title':'Review fresh runtime 지연 수리',
        'detail':'같은 500건을 두 번 평가하던 중복 계산을 제거하고 기존 exact 평가 1회 안에서 단일 Shadow 관찰값을 함께 집계.',
        'version':'v2314','created_ts':ts,'created_at':txt,'auto_buy':False})
    marker.parent.mkdir(parents=True,exist_ok=True);marker.write_text(txt,encoding='utf-8')

_V2314_BASE_RUN_ONCE = run_once
def run_once():  # type: ignore[override]
    result=_V2314_BASE_RUN_ONCE()
    try:_v2314_seed_ledgers()
    except Exception as exc:append_error('v2314_seed_ledgers',exc)
    return result

VERSION='review_worker_v2.124'
BUILD_LABEL='v2314_single_pass_material_volume_shadow_runtime_recovery_2026-07-30'
MAIN_DEPLOY_VERSION=BUILD_LABEL


# =============================================================================
# Review v2.125 / release v2317
# v2313-v2314 observation blocks are now loaded before main() starts.
# Existing exact/Shadow state is preserved; only new events are added.
# =============================================================================
VERSION='review_worker_v2.125'
BUILD_LABEL='v2317_pre_main_single_shadow_material_volume_runtime_2026-07-30'
MAIN_DEPLOY_VERSION=BUILD_LABEL

if __name__ == '__main__':
    main()


