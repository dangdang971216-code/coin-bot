v2218 changes Guard only.
- Removes the obsolete post-restart continuation progress message that appeared four times for one request/PID.
- Keeps exact Paper PID/version/writer checks.
- When Paper is unchanged, status age 120-180 seconds is a freshness warning instead of a false whole-release failure.
- A changed Paper component remains under the previous strict verification.
- Main, Paper, Strategy and Review are not restarted.
- Trading rules, ledgers, Shadow and auto-buy OFF are unchanged.
