from pathlib import Path
import ast, re, hashlib

ROOT=Path(__file__).resolve().parent
NEW=(ROOT/"strategy_worker_v1.028.py").read_text(encoding="utf-8",errors="ignore")

def func_node(src,name):
    tree=ast.parse(src)
    nodes=[n for n in tree.body if isinstance(n,(ast.FunctionDef,ast.AsyncFunctionDef)) and n.name==name]
    assert nodes, name
    return nodes[-1]

def func_hash(src,name):
    node=func_node(src,name)
    return hashlib.sha256(ast.dump(node,include_attributes=False).encode()).hexdigest()

EXPECTED={'_swing_quality_gate': '1d97ab0738d5eb0bab21979aecce9161603c8dc166c4c03d4549758f21ee00f1', '_trigger_path_points': '8a8c44e671c05f3dd63fbf458dea021a79ec7a4b7df399dc75137ad83223cf8d', '_latest_trigger_rebreak': '6d56857df116dcd0968e68863ee70f5d36cce439165c25c8c7cc3fab3bfb37dd', '_trigger_occurrence': '5f1a4bb2528c125ec0901d500efb99c4902c9bb137dae8737f8f03110256ee8b', '_v925_current_actual_plan': '52861f3e88b72c5e25cbad38f2b2d156bcbf444cb4bdf13f1669fa5f15ef6995', '_v1039_execution_freshness': '4c711c95e8e8912f2fc4a38ba1da95e5b225edc68f6e64b75ba27f8e63138481', '_v925_slippage_confirmed': 'ca3049cff2e4eec558e438f0631e5db1ac4edf2398c6b8de3d50ef5bde2ce716'}

assert "VERSION = 'strategy_worker_v1.028'" in NEW
assert "BUILD_LABEL = 'v1169_restore_quality_safety_keep_runtime_cleanup_2026-07-01'" in NEW

for name,digest in EXPECTED.items():
    assert func_hash(NEW,name)==digest,(name,func_hash(NEW,name),digest)

gate=ast.get_source_segment(NEW,func_node(NEW,"apply_swing_entry_gate"))
assert "if quality_gate.get('hard_pass') is not True:" in gate
assert "hard.extend(list(quality_gate.get('block_reasons') or []))" in gate
assert "'quality_final_hard_block_v1039':bool(quality_gate.get('hard_pass') is not True)" in gate
assert "'quality_metric_hard_block_count_v1039':int(quality_gate_block_count)" in gate

for forbidden in (
    "def _v1119_record_io",
    "def _v1119_io_cycle_reset",
    "V1153_STRATEGY_PATH_LEDGER",
    "def _v1153_strategy_event_once",
    "def _v1153_capture_strategy_gate_path",
):
    assert forbidden not in NEW, forbidden

for const,val in (
    ("V925_UNTRADABLE_SPREAD_PCT",1.2),
    ("V925_MIN_RR",1.5),
    ("V925_MIN_TARGET_ROOM_PCT",1.2),
    ("V977_MAX_TRIGGER_OVERSHOOT_PCT",0.6),
):
    pats=re.findall(rf"^{const}\s*=\s*([0-9.]+)",NEW,flags=re.M)
    assert pats and abs(float(pats[-1])-val)<1e-12,(const,pats[-3:])

assert "paper_bot_v1.037" not in NEW
assert "bithumb_micro_sidecar_v0.16" not in NEW
print("PASS v1169 contract")
