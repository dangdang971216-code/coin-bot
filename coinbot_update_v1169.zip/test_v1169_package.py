
from pathlib import Path
import json, hashlib, sys

ROOT=Path(__file__).resolve().parent
required=[
 "strategy_worker_v1.028.py","APPLY_V1169.txt","CHANGE_VERIFY_EVENT_V1169.json",
 "DEPLOY_BUNDLE.json","ISSUE_EVENT_V1169.json","ISSUE_EVENT_V1168_FAIL.json",
 "SOURCE_DIFF_SUMMARY_V1169.json","TRADING_RULES_INVARIANT_V1169.json",
 "diff/strategy_v1.027_to_v1.028.diff","docs/V1169_WORK_LOCK.md",
 "docs/V1169_SCOPE_AND_VERIFY.md","NO_LIVE_LEDGER_INCLUDED.txt","LOCAL_TEST_RESULT_V1169.txt","PACKAGE_VERIFY_V1169.txt","FILES_SHA256_v1169.tsv"
]
for rel in required:
    assert (ROOT/rel).exists(),rel
d=json.loads((ROOT/"DEPLOY_BUNDLE.json").read_text(encoding="utf-8"))
p=ROOT/"strategy_worker_v1.028.py"
assert d["source_sha256"][p.name]==hashlib.sha256(p.read_bytes()).hexdigest()
assert d["auto_buy"] is False
assert d["paper_source_change"] is False
assert d["strategy_source_change"] is True
print("PASS v1169 package")
