# v1169 작업 잠금

- 증상: v1168 적용 후 Strategy 14초로 빨라졌지만 OPEN 28, OPEN -27.840%, 합산 -46.427%
- 실제 원인: final quality safety gate를 advisory-only로 바꾼 v1168 전략 회귀
- owner: Strategy `_swing_quality_gate -> apply_swing_entry_gate`
- 수정 파일: `strategy_worker_v1.028.py` 하나
- 되돌릴 변경: v1168 quality advisory-only override만
- 유지할 변경: v1153/v1119/중간 writer 제거와 현재 가격경로 trigger
- 새 본선: 현재 runtime cleanup + 기존 quality hard safety + 현재 trigger/commit
- 전략 영향: 새 기준 추가 없음. v1167 기존 안전계약 복구
- 지도·Main·Guard·Paper·Micro 변경 금지
- 자동매수 OFF
