v1328 bundle ledger schema fix + rebreak writer row budget fix

Purpose:
- Fix v1327 /gupgrade_bundle stop before runtime apply: packaged issue ledger event missed issue_id.
- Also fix packaged change_verify event by adding change_id and issue_id.
- Keep the same runtime code intent as v1327: Strategy writer row budget fix for rebreak restoration.

No strategy value changes:
- candidate formula: unchanged
- trigger/invalid/target/RR: unchanged
- exit contract: unchanged
- auto-buy: OFF
- live ledgers: not included

Apply first in guard bot: /gupgrade_bundle
Verify: /grelease_verify, then main bot /flow_map_full /version_score /candidate_standard
