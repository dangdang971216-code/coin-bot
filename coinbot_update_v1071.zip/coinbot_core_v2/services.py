"""Compatibility marker for the v1067 staging verifier.
The v1067 simplified recalculation engine is retired. Active v1068 workers are standalone exact-spine files.
"""
ACTIVE_RUNTIME = False
RETIRED_SIMPLIFIED_RECALCULATION = True
