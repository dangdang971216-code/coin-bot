# CORE V2 v1071 전체 점검표

## 서버 검증
- [x] active source SHA256 exact
- [x] staged source SHA256 exact
- [x] immutable pair proof digest exact
- [x] local isolated function mismatch 0
- [x] local missing function 0
- [x] Main command contract preserved
- [x] Paper final handle_command parity
- [x] staged top-level duplicate definition 0
- [x] staged Python compile PASS
- [x] verifier worker source execution 0
- [x] verifier live ledger access 0
- [x] automatic buy OFF

## 전환 뒤 runtime 증명
- [ ] Risk v0.11 status fresh
- [ ] Strategy v0.992 status fresh
- [ ] Paper v0.999 status fresh
- [ ] Review v0.995 status fresh
- [ ] Main v2.13.1071 status fresh
- [ ] Risk–Paper READY and signature true
- [ ] candidate writer fresh and OK
- [ ] exact duplicate/key missing/unlinked 0/0/0
- [ ] auto-buy OFF
- [ ] failure triggers full rollback
