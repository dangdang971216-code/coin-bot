# 코인봇 v1059 실제 흐름도 및 CORE V2 재구축 설계 v1060

- 작성 기준: 서버 적용 v1059
- 전략모드: `ALT_SWING_V977`
- 자동매수: `OFF`
- 목적: 현재 코인 1개의 전체 생명주기를 실제 코드·파일·key 기준으로 해부하고, 새 CORE V2의 단일 본선 계약을 확정한다.
- 원칙: 라이브 OPEN/CLOSED/decision 원장과 전략 수치는 이 단계에서 변경하지 않는다.

---

## 1. 전체 시스템 현재 흐름

```text
빗썸 전체 티커 ALL_KRW
        │
        ▼
[scanner_worker]
- 현재가/24h등락/거래대금/일중위치
- 1m·3m 변화 추적
- hot-rank / hot occurrence
        │
        ├──────────────┐
        ▼              ▼
[candle_worker]   [market_regime_worker]
- 1m/3m/5m/30m   - 시장 폭·강도·거래대금
- 1h/2h/4h       - 강함/보통/약함
- 완료봉 구조재료       │
        │              │
        └──────┬───────┘
               ▼
        [feature_worker]
- 가격반응, 변화율, VWAP·EMA
- 상대강도, 거래대금, 구조 힌트
               │
               ├───────────────────┐
               ▼                   ▼
      [target_router]        [WS / micro]
- 수집 우선순위·target       - 실시간 가격
- WS/micro/candle 배차        - 호가·체결
               │                   │
               └────────┬──────────┘
                        ▼
                [orderflow_worker]
- quote freshness
- spread / buy ratio / buy sustain
- 5·10·20·30·60초 가격·체결 변화
                        │
                        ▼
                 [strategy_worker]
- base lane + spike/hot lane
- 구조선, trigger, invalid, target
- RR, 목표공간, 추격률
- S3/S2/S1 및 candidate/decision key
                        │
             paper_s1_hold_cache.json
                        │
                        ▼
                    [paper_bot]
- S1/TTL/micro/WS 재검증
- 실제 현재가격·spread·slippage 확인
- Risk 최근손실 계약·재돌파 검증
- OPEN append/decision 봉인
                        │
                        ▼
             [독립 exact exit monitor]
- 현재가, MFE, MAE, peak/giveback
- target / invalid / trailing / 시간정리
                        │
                        ▼
CLOSED append+fsync → decision CLOSED → OPEN 제거
                        │
                        ▼
         [canonical performance snapshot]
                        │
            ┌───────────┼───────────┐
            ▼           ▼           ▼
          [main]      [review]     [guard]
         명령화면     복기·감사     runtime·배포
```

---

## 2. 코인 1개 생명주기: 실제 코드·파일·key

### 단계 A. 전체시장 발견

**주인:** `scanner_worker.py::run_once`

**입력**
- 빗썸 `ALL_KRW` REST ticker

**계산**
- 현재가, 고가, 저가, 거래대금, 24h 변화율, 일중 위치
- scanner 자체 1분·3분 가격 history
- hot rank와 hot occurrence
- 우선순위 점수: 거래대금 + 변동 + 일중위치 + 1m/3m 상승

**출력**
- `clean_scanner_market_cache.json`
- `clean_scanner_candidate_pool.json`
- `clean_scanner_hot_rank_cache.json`
- `clean_hot_watch_scanner_snapshot.json`
- `clean_hot_watch_scanner_events.jsonl`

**최초 사건 key**
- hot occurrence 관련 key와 scanner timestamps가 이후 candidate identity의 재료가 된다.

---

### 단계 B. 완료봉·구조 재료 수집

**주인:** `candle_worker.py::run_once`

**입력**
- scanner 전체시장·후보
- strategy priority requests
- target router queue
- candle urgent targets
- 기존 candle cache와 delta

**계산**
- 1m·3m·5m·30m 빠른 변화
- 1h·2h·4h 큰 구조 재료
- 최근 고저점, swing high/low, box high/low
- VWAP·EMA·volume·wick·돌파/회복 힌트
- 완료봉 identity와 source readiness

**출력**
- `clean_candle_cache.json`: bounded checkpoint
- `clean_candle_delta_v1014.jsonl`: cycle delta
- `clean_candle_urgent_result.json`
- `clean_candle_status.json`

**주의**
- Strategy는 base checkpoint와 delta를 결합해서 최신 candle map을 만든다.
- source_missing은 0으로 보정하지 않고 구조 후보의 누락 근거로 남겨야 한다.

---

### 단계 C. 시장 장세 계산

**주인:** `market_regime_worker.py::run_once`

**입력**
- `clean_scanner_market_cache.json`

**계산**
- 상승 종목 비율
- 24h +2% 이상 강한 종목 수
- 상위 60개 평균 변화
- 상위 30개 거래대금
- 결과: `강함 / 보통 / 약함`

**출력**
- `clean_market_regime_cache.json`

**현재 실제 역할**
- Feature와 OPEN 당시 기록·성과 분류에 사용한다.
- **현재 S1 진입 하드차단에는 사용하지 않는다.**

---

### 단계 D. 가격·상대강도 특징 생성

**주인:** `feature_worker.py::run_once`

**입력**
- scanner candidate pool
- candle cache
- market regime
- scanner hot cache

**계산**
- 1m·3m·5m·15m·30m 변화율
- VWAP gap, EMA gap
- 상대강도 = 종목 24h 변화 - 시장 평균 변화
- 돌파, sweep/reclaim, 거래량 확장, 윗꼬리 등

**출력**
- `clean_feature_cache.json`

**현재 확인된 위험**
- 공식 VWAP/EMA가 없으면 다른 값으로 fallback 계산한다.
- source 표시는 남지만 값 자체가 `missing`이 아니라 파생값으로 채워질 수 있다.
- CORE V2에서는 공식값과 파생 관찰값을 별도 필드로 분리해야 한다.

---

### 단계 E. WS·호가·체결 수집 배차

**주인**
- `target_router_worker.py`
- `ws_sidecar.py`
- `bithumb_micro_sidecar.py`

**입력**
- strategy priority request
- candidate lite snapshot
- S1 hold
- 현재 OPEN
- hot rank / recheck candidates

**출력**
- `clean_target_router_queue.json`
- `clean_ws_targets.json`
- `clean_micro_targets.json`
- `clean_micro_urgent_targets.json`
- `clean_ws_live_cache.json`
- `clean_bithumb_micro_cache.json`

**역할**
- 후보를 탈락시키는 worker가 아니다.
- 필요한 실시간 자료를 먼저 수집하도록 우선순위를 정한다.

---

### 단계 F. 실행재료 표준화

**주인:** `orderflow_worker.py::run_once`

**입력**
- feature cache
- WS live cache
- micro cache
- target router queue

**계산**
- quote source: WS 우선, 없으면 fresh scanner REST
- spread
- buy ratio
- 1분 buy sustain
- 5·10·20·30·60초 가격 변화와 체결 가속
- freshness와 source age

**출력**
- `clean_orderflow_summary_cache.json`

---

### 단계 G. 후보·구조·S등급 판정

**주인:** `strategy_worker.py::run_once`

#### G-1. 입력 결합

```text
feature + candle map + scanner hot + orderflow + risk cache
```

#### G-2. base lane

**함수:** `_v510_base_lane`

- 돈흐름 재가속
- 주도추세
- 돌파 초입
- 저점/VWAP 회복
- 급등 후 재돌파
- 공통 hard risk 적용

**공통 hard risk**
- Risk cooldown
- 이미 OPEN
- 거래대금 부족
- fresh micro일 때 spread·buy ratio·매도압력
- 윗꼬리·고점 끝물

#### G-3. spike/hot lane

**함수:** `_v510_spike_lane`

- 1m·3m·초단기 가격 가속 기반 넓은 prefilter
- hot-rank 급등 재확인
- spread/buy/sustain은 점수·사유로 기록

**현재 확인된 구조 문제**
- spike lane은 `_v510_base_lane`의 `common_hard()`를 호출하지 않는다.
- 따라서 Risk cooldown·이미 OPEN 등 공통 hard 경로를 동일하게 소비하지 않는다.
- 이후 same-ticker OPEN은 Paper에서 막지만, **최근 반복손실 cooldown은 hot lane에서 우회될 수 있다.**

#### G-4. 구조계획과 최종 swing gate

**주인:** `apply_swing_entry_gate`

**시간축 계약**
- major: 4h·2h
- setup/invalid: 1h·30m
- trigger: 15m·5m
- execution: 1m·quote

**봉인값**
- `swing_entry_gate_v977`
- `swing_gate_decision_key_v977`
- `swing_structure_plan_v977`
- `trigger_occurrence_v1037`
- trigger / invalid / target
- RR / 목표공간 / 추격률 / spread

**현재 하드 조건**
- spread ≤ 1.2%
- RR ≥ 1.5
- 목표공간 ≥ 1.2%
- trigger 추격 ≤ 0.6%
- 구조 source·role complete
- S3 observation-only OPEN 금지

**현재 soft/관찰 조건**
- 가격반응
- 상대강도
- 돈흐름
- buy ratio / buy sustain
- 시장 장세
- 전략명

**출력**
- `paper_candidates_latest.jsonl`: 전체 compact 후보판
- `paper_s1_hold_cache.json`: Paper 신규 OPEN의 유일한 소비원
- `clean_strategy_swing_gate_status_v977.json`
- `clean_strategy_key_spine_status.json`

---

### 단계 H. Risk 최근손실 계약

**주인:** `risk_worker.py::run_once`

**입력**
- `paper_bot_closed.jsonl`
- `paper_bot_open.json`

**계산**
- ticker별 recent losses / hard losses
- cooldown map
- ticker별 최신 ALT_SWING 손실 사건
- 최신 손실은 bounded tail 안의 최대 숫자형 `closed_ts`
- CLOSED signature

**출력**
- `clean_risk_filter_cache.json`
- contract: `loss_reentry_source_contract_v1057`

**중요**
- Risk worker는 CLOSED를 읽기만 한다.
- deep audit의 writer PID 표시는 파일 활동 추정치일 수 있으며 실제 append owner 증명으로 사용하면 안 된다.

---

### 단계 I. Paper 최종 선택

**주인:** `paper_bot.py::select_candidates`

**유일한 입력 후보 파일**
- `paper_s1_hold_cache.json`

**순서**
1. S3 observation 후보 제거
2. S1 여부 확인
3. candidate TTL 확인
4. OPEN 총량·cycle 신규한도 확인
5. 신규 OPEN pause 확인
6. micro/WS freshness 확인
7. ticker·price 확인
8. exact decision key 중복 확인
9. same ticker OPEN 확인
10. `paper_final_safety`
11. Risk contract READY와 CLOSED signature 확인
12. 이전 손실 뒤 새 candidate·decision·reset·rebreak 확인
13. 선택 후 OPEN 당시 시장·risk·quality 근거 봉인

**현재 실제 한도**
- `max_open_strict = 0`
- `max_new_per_cycle = 0`
- 의미: **무제한**

---

### 단계 J. Paper OPEN 직전 재검증

**주인:** `paper_final_safety`

**재확인**
- ALT_SWING gate schema와 decision key
- S1 hard pass
- gate RR·target room
- frozen trigger 도달
- trigger chase
- micro/WS freshness
- spread
- confirmed slippage

**중요한 현재 계약 위반 가능성**
- Paper는 strategy gate의 trigger 기준 RR을 다시 확인한다.
- 실제 entry price로 계산한 `actual_entry_rr_v1034`는 OPEN 뒤 evidence로 기록한다.
- `actual_entry_rr < 1.5`여도 현재 OPEN을 차단하지 않는다.
- 프로젝트 원칙상 실제 진입 예정가 기준 RR 미달이면 진입하면 안 되므로 CORE V2에서 반드시 수정해야 한다.

---

### 단계 K. OPEN 생성·commit

**주인:** `paper_bot.py::open_position` + `run_cycle`

**pos_id**
```text
decision:{swing_gate_decision_key_v977}
```

**OPEN 봉인값**
- pos_id / candidate key / decision key
- strategy mode / 실제 진입방식
- entry price / opened_at
- trigger / invalid / target
- trigger RR / actual RR
- spread / slippage / 비용
- market regime / risk cooldown / quality
- exit_contract_v1038
- trigger occurrence / loss reentry gate

**commit 순서**
1. `open_pos[pos_id] = position`
2. `paper_bot_open.json` verified persistence
3. decision state를 `OPEN`으로 봉인
4. decision 봉인 실패 시 OPEN rollback

---

### 단계 L. 보유 중 감시·청산 판정

**주인:** 독립 `run_exact_exit_monitor`

**현재가 source**
- Paper live price path와 각 OPEN current price 갱신

**갱신**
- current price
- peak / trough
- MFE / MAE
- giveback
- target·invalid 최초 접촉 관련 근거

**청산 우선순위**
1. 구조 invalid
2. 구조 target
3. v1038 trailing: 최고 +2.0% 이후 0.8%p 반납, 현재 수익권
4. 6시간 무반응
5. 72시간 약한 흐름

**주의**
- strategy의 현재 구조선을 다시 읽어 OPEN 계약을 바꾸면 안 된다.
- OPEN 당시 봉인된 계약만 사용해야 한다.

---

### 단계 M. CLOSED exact commit

**주인:** `commit_closed_position_exact`

**필수 순서**
1. CLOSED row 완성
2. `paper_bot_closed.jsonl` append
3. fsync·tail key 검증
4. decision `CLOSED` 저장
5. OPEN에서 해당 pos 제거
6. `paper_bot_open.json` verified persistence
7. 알림·성과 갱신

**실패 원칙**
- CLOSED append 또는 decision 저장 실패 시 OPEN 유지
- OPEN 선삭제 금지

---

### 단계 N. 성과·복기·명령화면

**canonical 성과 주인**
- Paper embedded performance writer
- `canonical_performance_snapshot_v987.json`

**Main**
- `/health`: runtime + Paper status + 원장상태
- `/swing_status`: 실제 전략·시간축 계약
- `/version_score`: canonical performance + 현재 OPEN
- `/batch`, `/batch_full`: 여러 canonical source 묶음
- `/trade_review`: canonical CLOSED 기반 복기

**Paper**
- `/pstatus`: Paper cycle, OPEN/CLOSED, selection reason
- `/popen`: 현재 OPEN
- `/perror`: runtime 오류

**Guard**
- `/gworker_state`: worker identity와 cycle
- `/gdeep_audit`: 자원·디스크·파일 증가
- `/gupgrade_bundle`: 배포

---

## 3. 현재 key 흐름

```text
scanner hot occurrence
  → strategy candidate/event identity
  → canonical_candidate_exact_key
  → trigger_occurrence_v1037.candidate_key
  → swing_gate_decision_key_v977
  → Paper paper_decision_key_v926
  → pos_id = decision:{decision_key}
  → CLOSED에 같은 pos_id / decision key
  → canonical performance exact 연결
```

**CORE V2 규칙**
- ticker·시간근접으로 연결 금지
- candidate key / decision key / pos_id를 단계별로 새로 추정하지 않음
- 한 번 발급된 identity를 그대로 전달

---

## 4. 현재 코드 구조 감사 결과

| 구성 | 파일 크기/함수 | 같은 이름 재정의 | 핵심 문제 |
|---|---:|---:|---|
| Main | 약 47,420줄 / top-level 함수 2,349개 | 166개 추가 재정의 | 명령 handler가 버전별 bind로 누적 |
| Strategy | 약 24,532줄 / top-level 함수 789개 | 109개 추가 재정의 | 구조·후보·감사·storage가 한 process에 혼재 |
| Paper | 약 24,268줄 / top-level 함수 1,069개 | 142개 추가 재정의 | 실행·원장·성과·알림·복기·status가 한 파일에 혼재 |
| Guard | 약 7,759줄 | 중복 함수명 0 | 배포·감사·명령이 크지만 덮어쓰기는 상대적으로 적음 |

**대표 재정의**
- Paper `write_status` 6회
- Paper `run_cycle` 4회
- Paper `notify_opened` 8회
- Strategy `_v861_compact_row_for_latest` 15회
- Main `batch_handler` 57회

**판정**
- 지금 문제는 함수 하나의 버그가 아니라, 최종 정의와 wrapper chain을 알아야만 실제 본선을 알 수 있는 구조다.
- CORE V2에서는 top-level monkey patch·후반 재정의를 금지한다.

---

## 5. 수익성과 연결되는 현재 본선 문제

### P1. hot/spike lane 공통 Risk 우회
- base lane은 `common_hard → risk_bad`를 거친다.
- spike lane은 같은 공통 hard gate를 거치지 않는다.
- 최근 손실 cooldown이 hot-rank 후보에서 동일하게 적용되지 않을 수 있다.

### P2. 장세 미사용
- 장세 worker는 정상 동작한다.
- OPEN에 봉인하고 성과분류에는 사용한다.
- 진입 차단이나 size 조절에는 사용하지 않는다.

### P3. actual RR 미차단
- trigger RR은 확인한다.
- 실제 entry price RR은 기록만 한다.
- 프로젝트 진입 계약과 불일치한다.

### P4. OPEN 무제한
- 전체 OPEN·cycle 신규 OPEN 기본값이 모두 0(무제한).
- 현재 100개 이상 동시 OPEN과 성과 악화가 동시에 나타난다.

### P5. 품질값의 역할 불일치
- 가격반응·상대강도·돈흐름·buy sustain은 생산·기록된다.
- 최종 swing gate에서 관찰 전용이다.
- “계산만 하고 selector가 사용하지 않는 상태”에 해당할 가능성이 높다.

### P6. source missing의 파생값 보정
- Feature 일부 값은 공식 source가 없을 때 다른 값으로 계산된다.
- missing과 derived observation을 명확히 분리해야 한다.

---

## 6. CORE V2 목표 흐름

```text
MarketInputSnapshot
  ↓
FeatureSnapshot
  ↓
StructurePlan
  ↓
CandidateDecision
  ↓
RiskDecision
  ↓
ExecutionDecision
  ↓
PositionOpened
  ↓
PositionMark
  ↓
ExitDecision
  ↓
ClosedCommit
  ↓
PerformanceSnapshot
  ↓
CommandSnapshot
```

각 단계는 아래만 허용한다.

- 입력 contract 1개
- 출력 contract 1개
- writer 1개
- 상태 writer 1개
- 버전 문자열이 아니라 schema/capability 검증
- 과거 단계 값을 다시 계산하지 않음
- 오류 시 `CHECK`, 누락 시 `source_missing`

---

## 7. 새 CORE V2 모듈 경계

```text
coinbot_core_v2/
├── contracts.py          # 모든 immutable contract
├── source_reader.py      # 기존 worker snapshot 읽기 전용
├── candidate_engine.py   # 구조계획·S등급·candidate decision
├── risk_engine.py        # 중복·cooldown·재진입·시장위험
├── execution_engine.py   # 실제 entry RR·spread·slippage
├── position_store.py     # OPEN/CLOSED exact commit
├── exit_engine.py        # target/invalid/trailing/time
├── performance.py        # canonical snapshot 단일 writer
├── status.py             # canonical runtime status
├── commands.py           # 기존 명령어 화면 유지·정리
└── shadow_runner.py      # 라이브 write 금지 비교 실행
```

---

## 8. 기존 명령어 화면 유지 계약

명령어 이름은 유지한다.

### `/health`
1. 현재 상태
2. 전회 대비
3. runtime identity
4. worker freshness
5. OPEN/CLOSED·원장
6. 현재 문제

### `/swing_status`
1. 전략모드
2. 시간축
3. 진입계약
4. 청산계약
5. 실제 사용/관찰 전용 재료

### `/version_score`
1. 기간별 CLOSED
2. 현재 OPEN 포함
3. 비용·MFE·MAE·반납
4. 경로·장세·동시 OPEN·반복진입
5. snapshot identity

### `/pstatus`
1. cycle
2. 후보→선택→OPEN 수
3. 최종 차단 이유
4. Risk/Execution 계약
5. OPEN writer·exit monitor

### `/popen`
- OPEN 당시 계약과 현재 mark를 분리 표시

### `/trade_review`
- 진입 당시 재료, 경로, 종료 이유, 비용, MFE/MAE

Main/Paper/Guard는 모두 같은 `CommandSnapshot`을 읽고 독립 재계산하지 않는다.

---

## 9. 전환 순서

### Phase 0 · 현재 흐름 봉인
- 이 문서
- static spine audit
- ticker 1개 lineage probe
- 기존 라이브 write 없음

### Phase 1 · Contract + shadow reader
- 기존 snapshot을 strict contract로 변환
- source_missing과 derived 분리

### Phase 2 · Candidate/Risk/Execution shadow
- 현재 Strategy/Paper 결과와 같은 key로 비교
- 차이 발생 이유를 필드 단위로 기록

### Phase 3 · Position/Exit shadow
- 별도 shadow OPEN/CLOSED
- 라이브 원장 접근은 read-only

### Phase 4 · Command snapshot
- 기존 명령 화면을 새 canonical source에 연결

### Phase 5 · 일괄 전환
- 새 core 전체 PASS 후 한 번에 active 전환
- 구 Strategy→Risk→Paper→성과→status active path 삭제
- 원장은 그대로 인계

---

## 10. 전환 PASS 기준

- 같은 candidate key / decision key / pos_id
- 같은 trigger / invalid / target
- 실제 entry RR 차이가 설명 가능
- 동일 시장입력에서 선택·차단 이유가 deterministic
- OPEN/CLOSED commit 순서 fixture PASS
- 재시작 후 동일 상태 복구
- 모든 명령이 같은 snapshot ID 표시
- 구 writer/reader active 0
- 자동매수 OFF

---

## 11. 바로 다음 수정 대상

이 흐름도 작성 직후 시작할 코드는 `CORE V2 Phase 0`이다.

1. strict contract 정의
2. 라이브 파일 read-only lineage probe
3. 한 코인의 모든 단계 row를 하나의 trace로 연결
4. duplicate function/writer/reader static audit
5. 별도 shadow 출력

이 단계에서는 전략 수치와 원장을 건드리지 않는다.
