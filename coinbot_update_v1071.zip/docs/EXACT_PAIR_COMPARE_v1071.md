# CORE V2 v1071 exact-pair 비교

## v1070 CHECK 원인
v1070 검증기는 active와 staged 모듈을 서로 다른 시점에 별도 프로세스로 실행했다. 일부 구 코드가 import 시점의 live 상태와 `_PREV_` 별칭을 읽으므로, 움직이는 서버 상태에 따라 같은 source pair가 다르게 묶였다. 또한 검증 전후 원장 hash 비교는 정상 실행 중인 Paper의 append까지 검증기 write로 오인했다.

## v1071 검증 본선
- active worker source를 실행하지 않는다.
- staged worker source를 실행하지 않는다.
- live OPEN/CLOSED/decision/change/issue 원장을 열지 않는다.
- 현재 active alias SHA256이 동결 source와 정확히 같은지 확인한다.
- staged source SHA256이 로컬 검증 완료본과 정확히 같은지 확인한다.
- 고정 복사본 isolated semantic parity 결과가 mismatch 0인지 proof digest로 확인한다.
- staged source syntax, release identity, top-level duplicate definition 0을 서버에서 다시 확인한다.

## 전략 영향
없음. trigger, invalid, target, RR, spread, slippage, trailing, 시간청산, OPEN 한도, 자동매수 상태를 변경하지 않는다.
