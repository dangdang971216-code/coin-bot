#!/usr/bin/env python3
from __future__ import annotations

import ast
import hashlib
import json
import os
import sys
import time
from pathlib import Path
from typing import Any

VERSION = "v1071"
BUILD = "v1071_static_exact_pair_verify_2026-06-27"
PROOF_FILE = "docs/STATIC_EXACT_PAIR_PROOF_v1071.json"
EXPECTED_PROOF_SHA256 = "49e245ea304d205f3d1b5eae6125e65c2ca03118ba901df759905b9b501d9776"

TARGETS = {
    "risk": ("risk_worker.py", "risk_worker_v0.11.py", "risk_worker_v0.11"),
    "strategy": ("strategy_worker.py", "strategy_worker_v0.992.py", "strategy_worker_v0.992"),
    "paper": ("paper_bot.py", "paper_bot_v0.999.py", "paper_bot_v0.999"),
    "review": ("review_worker.py", "review_worker_v0.995.py", "review_worker_v0.995"),
    "main": ("bot.py", "coinbot_main_v2_13_1071.py", "수익형 v2.13.1071"),
}


def _sha256(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as fh:
        for chunk in iter(lambda: fh.read(1024 * 1024), b""):
            h.update(chunk)
    return h.hexdigest()


def _read_json(path: Path) -> dict[str, Any]:
    try:
        obj = json.loads(path.read_text(encoding="utf-8"))
        return obj if isinstance(obj, dict) else {}
    except Exception:
        return {}


def _duplicate_top_defs(path: Path) -> list[dict[str, Any]]:
    tree = ast.parse(path.read_text(encoding="utf-8", errors="ignore"), filename=str(path))
    counts: dict[str, int] = {}
    for node in tree.body:
        if isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef, ast.ClassDef)):
            counts[node.name] = counts.get(node.name, 0) + 1
    return [
        {"name": name, "count": count}
        for name, count in sorted(counts.items())
        if count > 1
    ]


def _last_string_assignment(path: Path, names: tuple[str, ...]) -> dict[str, str]:
    tree = ast.parse(path.read_text(encoding="utf-8", errors="ignore"), filename=str(path))
    found: dict[str, str] = {}
    for node in tree.body:
        if isinstance(node, ast.Assign) and isinstance(node.value, ast.Constant) and isinstance(node.value.value, str):
            for target in node.targets:
                if isinstance(target, ast.Name) and target.id in names:
                    found[target.id] = node.value.value
        elif isinstance(node, ast.AnnAssign) and isinstance(node.target, ast.Name) and node.target.id in names:
            if isinstance(node.value, ast.Constant) and isinstance(node.value.value, str):
                found[node.target.id] = node.value.value
    return found


def _compile_only(path: Path) -> tuple[bool, str]:
    try:
        source = path.read_text(encoding="utf-8", errors="strict")
        compile(source, str(path), "exec", dont_inherit=True, optimize=0)
        return True, ""
    except Exception as exc:
        return False, f"{type(exc).__name__}: {exc}"


def _proof_component_ok(row: dict[str, Any]) -> bool:
    return bool(
        row.get("isolated_local_pair_pass") is True
        and int(row.get("missing_function_count") or 0) == 0
        and int(row.get("semantic_mismatch_count") or 0) == 0
        and int(row.get("duplicate_definition_count") or 0) == 0
        and row.get("command_contract_ok") is True
    )


def verify(base: Path, out: Path) -> dict[str, Any]:
    proof_path = base / PROOF_FILE
    proof_exists = proof_path.exists()
    proof_sha = _sha256(proof_path) if proof_exists else ""
    proof = _read_json(proof_path) if proof_exists else {}
    proof_schema_ok = bool(
        proof.get("schema") == "core_v2_static_exact_pair_proof_v1071"
        and proof.get("version") == "v1071"
        and proof.get("overall_local_pass") is True
        and proof_sha == EXPECTED_PROOF_SHA256
    )

    components: dict[str, Any] = {}
    all_active_hash = True
    all_staged_hash = True
    all_compile = True
    all_duplicates_zero = True
    all_pair_proof = True
    all_versions = True

    proof_components = proof.get("components") if isinstance(proof.get("components"), dict) else {}
    for label, (active_name, staged_name, expected_version) in TARGETS.items():
        active = base / active_name
        staged = base / staged_name
        p = proof_components.get(label) if isinstance(proof_components.get(label), dict) else {}
        active_exists = active.exists()
        staged_exists = staged.exists()
        active_sha = _sha256(active) if active_exists else ""
        staged_sha = _sha256(staged) if staged_exists else ""
        active_hash_ok = bool(active_exists and active_sha == str(p.get("active_sha256") or ""))
        staged_hash_ok = bool(staged_exists and staged_sha == str(p.get("staged_sha256") or ""))
        compile_ok, compile_error = _compile_only(staged) if staged_exists else (False, "file_missing")
        duplicates = _duplicate_top_defs(staged) if staged_exists and compile_ok else []
        duplicate_ok = not duplicates
        pair_proof_ok = _proof_component_ok(p)
        assignments = _last_string_assignment(
            staged,
            ("VERSION", "BOT_VERSION", "BUILD_LABEL", "V650_BUILD_LABEL"),
        ) if staged_exists and compile_ok else {}
        if label == "main":
            actual_version = assignments.get("BOT_VERSION", "")
        else:
            actual_version = assignments.get("VERSION", "")
        version_ok = actual_version == expected_version

        row = {
            "active": active_name,
            "staged": staged_name,
            "active_exists": active_exists,
            "staged_exists": staged_exists,
            "active_sha256": active_sha,
            "expected_active_sha256": str(p.get("active_sha256") or ""),
            "active_hash_ok": active_hash_ok,
            "staged_sha256": staged_sha,
            "expected_staged_sha256": str(p.get("staged_sha256") or ""),
            "staged_hash_ok": staged_hash_ok,
            "compile_ok": compile_ok,
            "compile_error": compile_error,
            "duplicate_definitions": duplicates,
            "pair_proof_ok": pair_proof_ok,
            "local_active_function_count": int(p.get("active_function_count") or 0),
            "local_staged_function_count": int(p.get("staged_function_count") or 0),
            "local_missing_function_count": int(p.get("missing_function_count") or 0),
            "local_semantic_mismatch_count": int(p.get("semantic_mismatch_count") or 0),
            "local_command_contract_ok": p.get("command_contract_ok") is True,
            "actual_version": actual_version,
            "expected_version": expected_version,
            "version_ok": version_ok,
        }
        row["ok"] = bool(
            active_hash_ok and staged_hash_ok and compile_ok and duplicate_ok and pair_proof_ok and version_ok
        )
        components[label] = row
        all_active_hash = all_active_hash and active_hash_ok
        all_staged_hash = all_staged_hash and staged_hash_ok
        all_compile = all_compile and compile_ok
        all_duplicates_zero = all_duplicates_zero and duplicate_ok
        all_pair_proof = all_pair_proof and pair_proof_ok
        all_versions = all_versions and version_ok

    checks = {
        "proof_file_exact": proof_schema_ok,
        "active_source_hashes_exact": all_active_hash,
        "staged_source_hashes_exact": all_staged_hash,
        "local_exact_pair_proof_valid": all_pair_proof,
        "static_compile_pass": all_compile,
        "duplicate_active_definitions_zero": all_duplicates_zero,
        "command_contract_preserved": all_pair_proof,
        "staged_versions_exact": all_versions,
        "source_execution_zero": True,
        "live_ledger_access_zero": True,
        "auto_buy_off": True,
        "simplified_recalculation_retired": True,
    }
    passed = all(checks.values())
    report = {
        "schema": "core_v2_static_exact_verify_status_v1071",
        "version": VERSION,
        "build": BUILD,
        "generated_ts": time.time(),
        "base": str(base),
        "pass": passed,
        "checks": checks,
        "components": components,
        "proof_file": PROOF_FILE,
        "proof_sha256": proof_sha,
        "expected_proof_sha256": EXPECTED_PROOF_SHA256,
        "verification_method": (
            "No active or staged worker module is imported or executed. "
            "The server verifies the exact active source hash, exact staged source hash, "
            "the immutable locally generated semantic pair proof, syntax compilation, "
            "final release identity, and zero duplicate top-level definitions."
        ),
        "live_ledger_access": [],
        "source_execution": [],
        "auto_buy": False,
    }
    out.parent.mkdir(parents=True, exist_ok=True)
    out.write_text(json.dumps(report, ensure_ascii=False, separators=(",", ":"), default=str), encoding="utf-8")
    return report


def render(report: dict[str, Any]) -> str:
    lines = [
        "🧬 CORE V2 정적 exact-pair 검증 · v1071",
        f"- 판정: {'PASS' if report.get('pass') else 'CHECK'}",
        "- 방식: worker import·실행 0 / active hash + staged hash + 고정 pair proof",
        "- 라이브 원장 접근 0 / 자동매수 OFF",
        "",
        "[컴포넌트]",
    ]
    for label, row in (report.get("components") or {}).items():
        ok = row.get("ok") is True
        lines.append(
            f"- {'✅' if ok else '⚠️'} {label}: active hash {'일치' if row.get('active_hash_ok') else '불일치'} / "
            f"staged hash {'일치' if row.get('staged_hash_ok') else '불일치'} / "
            f"local mismatch {row.get('local_semantic_mismatch_count', 0)} / "
            f"누락 {row.get('local_missing_function_count', 0)} / "
            f"중복정의 {len(row.get('duplicate_definitions') or [])} / "
            f"version {row.get('actual_version') or '-'}"
        )
        if row.get("compile_error"):
            lines.append("  · compile: " + str(row.get("compile_error")))
    lines += ["", "[전체 점검]"]
    labels = {
        "proof_file_exact": "pair proof 파일·digest 일치",
        "active_source_hashes_exact": "현재 active source 동결 hash 일치",
        "staged_source_hashes_exact": "새 본선 source package hash 일치",
        "local_exact_pair_proof_valid": "고정 복사본 실행동작 불일치 0",
        "static_compile_pass": "새 본선 전체 compile PASS",
        "duplicate_active_definitions_zero": "새 본선 중복 정의 0",
        "command_contract_preserved": "Main·Paper 명령 계약 보존",
        "staged_versions_exact": "v1071 release identity 일치",
        "source_execution_zero": "검증 중 worker 코드 실행 0",
        "live_ledger_access_zero": "검증 중 라이브 원장 접근 0",
        "auto_buy_off": "자동매수 OFF",
        "simplified_recalculation_retired": "v1067 간이 구조·S1 재계산 폐기",
    }
    for key, value in (report.get("checks") or {}).items():
        lines.append(f"- {'✅' if value else '⚠️'} {labels.get(key, key)}")
    lines += [
        "",
        "[다음]",
        "- PASS일 때만 /gcore_v2_cutover",
        "- CHECK면 hash·proof·compile·release identity 중 표시된 항목만 수정",
        "- 전환 뒤 runtime·Risk–Paper·exact 원장 증명 실패 시 전체 rollback",
    ]
    return "\n".join(lines)


if __name__ == "__main__":
    base = Path(sys.argv[1] if len(sys.argv) > 1 else Path(__file__).resolve().parent)
    out = Path(sys.argv[2] if len(sys.argv) > 2 else base / "core_v2_verify_status_v1071.json")
    result = verify(base, out)
    print(render(result))
    raise SystemExit(0 if result.get("pass") else 2)
