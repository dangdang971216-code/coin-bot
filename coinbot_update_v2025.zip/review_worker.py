#!/usr/bin/env python3
# -*- coding: utf-8 -*-
from __future__ import annotations
import json, os, time, traceback, gzip, math, resource, gc, ctypes, threading, hashlib, heapq, sys, subprocess, sqlite3, fcntl, atexit
from pathlib import Path
from typing import Any, Dict, List, Optional
from collections import Counter, deque

BASE_DIR = Path(os.getenv("TRADING_BOT_DIR", "/home/dangdang971216/trading_bot"))
VERSION = "review_worker_v1.011"
BUILD_LABEL = 'v1144_candidate_standard_truth_owner_cleanup_2026-06-29'
INTERVAL_SEC = float(os.getenv("REVIEW_WORKER_INTERVAL_SEC", "30"))
RETENTION_DAYS = float(os.getenv("REVIEW_RETENTION_DAYS", "0.25"))
ACTIVE_REVIEW_MAX = int(os.getenv("REVIEW_ACTIVE_MAX", "180"))
TRIGGER_SHADOW_PENDING_TTL_SEC = float(os.getenv("TRIGGER_SHADOW_PENDING_TTL_SEC", "900"))
TRIGGER_SHADOW_ENTERED_TTL_SEC = float(os.getenv("TRIGGER_SHADOW_ENTERED_TTL_SEC", "3600"))
TRIGGER_SHADOW_ACTIVE_MAX = int(os.getenv("TRIGGER_SHADOW_ACTIVE_MAX", "900"))
SOURCE_SNAPSHOT_LINES = int(os.getenv("REVIEW_SOURCE_SNAPSHOT_LINES", "700"))
HEARTBEAT_SEC = max(5.0, float(os.getenv("REVIEW_HEARTBEAT_SEC", "10")))
_REVIEW_HEARTBEAT_SEQ = 0
_STATUS_WRITE_LOCK = threading.RLock()
_CURRENT_PHASE = "boot"
_CURRENT_PHASE_STARTED_MONO = time.monotonic()
_CURRENT_PHASE_STARTED_TS = time.time()
_LAST_COMPLETED_PHASE_TIMINGS: Dict[str, float] = {}
_PHASE_MEMORY_SAMPLES: Dict[str, float] = {}
_LAST_PHASE_MEMORY_TOP: List[tuple[str, float]] = []
_LAST_RSS_SAMPLE: Dict[str, Any] = {}
_LAST_MEMORY_RECLAIM: Dict[str, Any] = {}
_HEARTBEAT_STOP = threading.Event()

STATUS = BASE_DIR / "clean_review_worker_status.json"
ERROR = BASE_DIR / "clean_review_worker_error.log"
CLOSED = BASE_DIR / "paper_bot_closed.jsonl"
OPEN = BASE_DIR / "paper_bot_open.json"
PAPER_LATEST = BASE_DIR / "paper_candidates_latest.jsonl"
GOOD_S2_OBSERVATION_LEDGER = BASE_DIR / "good_s2_observation_ledger.jsonl"
GOOD_S2_RESULT_STATE = BASE_DIR / "good_s2_result_state_v923.json"
GOOD_S2_RESULT_SNAPSHOT = BASE_DIR / "good_s2_result_snapshot.json"
GOOD_S2_RESULT_LEDGER = BASE_DIR / "good_s2_result_ledger.jsonl"
GOOD_S2_RESULT_HORIZON_SEC = 6 * 3600.0
GOOD_S2_RESULT_RETENTION_SEC = 7 * 86400.0
GOOD_S2_RESULT_RESET_META_V925 = BASE_DIR / 'quarantine' / 'good_s2_result_state_reset_meta_v925.json'
GOOD_S2_RESULT_RESET_META_V926 = BASE_DIR / 'quarantine' / 'good_s2_result_source_spine_reset_meta_v926.json'
FEATURE = BASE_DIR / "clean_feature_cache.json"
ORDERFLOW = BASE_DIR / "clean_orderflow_summary_cache.json"
REGIME = BASE_DIR / "clean_market_regime_cache.json"
QUEUE = BASE_DIR / "clean_missed_review_queue.json"
STATE = BASE_DIR / "clean_missed_review_state.json"
SUMMARY = BASE_DIR / "clean_missed_review_summary.json"
OLD_SUMMARY = BASE_DIR / "clean_review_summary.json"
TRIGGER_SHADOW_CANDIDATES = BASE_DIR / "clean_trigger_shadow_candidates_v665.json"
TRIGGER_SHADOW_STATE = BASE_DIR / "clean_trigger_shadow_state_v665.json"
TRIGGER_SHADOW_SUMMARY = BASE_DIR / "clean_trigger_shadow_review_v665.json"
MARKET_MISS_CANDIDATES = BASE_DIR / "clean_market_miss_candidates_v667.json"
MARKET_MISS_STATE = BASE_DIR / "clean_market_miss_state_v667.json"
MARKET_MISS_SUMMARY = BASE_DIR / "clean_market_miss_review_v667.json"
QUALITY_SHADOW_STATE = BASE_DIR / "clean_quality_shadow_state_v1125.json"
QUALITY_SHADOW_STATUS = BASE_DIR / "clean_quality_shadow_status_v1125.json"
QUALITY_POLICY_COMPARISON_STATUS_V1120 = BASE_DIR / "clean_quality_policy_comparison_status_v1125.json"
QUALITY_EYE_STATUS_V1124 = BASE_DIR / "clean_quality_eye_status_v1125.json"
QUALITY_EYE_EPOCH_STATE_V1124 = BASE_DIR / "clean_quality_eye_epoch_v1125.json"
QUALITY_EYE_AGG_STATE_V1124 = BASE_DIR / "clean_quality_eye_aggregate_v1125.json"
QUALITY_EYE_MIN_60M_SAMPLE_V1124 = max(10, int(os.getenv("QUALITY_EYE_MIN_60M_SAMPLE_V1124", "30")))
QUALITY_SHADOW_LEDGER = BASE_DIR / "quality_shadow_result_ledger_v1125.jsonl"
QUALITY_SHADOW_RETENTION_SEC = float(os.getenv("QUALITY_SHADOW_RETENTION_SEC", str(75 * 60)))
QUALITY_SHADOW_FINAL_GRACE_SEC = float(os.getenv("QUALITY_SHADOW_FINAL_GRACE_SEC", "300"))
# Safety ceiling only. Unfinished records are retained by time until the 60m horizon,
# so a busy market cannot evict them merely because a count cap was reached.
QUALITY_SHADOW_SAFETY_MAX_RECORDS = int(os.getenv("QUALITY_SHADOW_SAFETY_MAX_RECORDS", "8000"))
QUALITY_SHADOW_ARCHIVE = BASE_DIR / "quality_shadow_archive_v1125"
QUALITY_SHADOW_LEDGER_MAX_BYTES = int(os.getenv("QUALITY_SHADOW_LEDGER_MAX_BYTES", str(50 * 1024 * 1024)))
QUALITY_SHADOW_LEDGER_KEEP_LINES = int(os.getenv("QUALITY_SHADOW_LEDGER_KEEP_LINES", "5000"))
_QUALITY_FINAL_KEYS_CACHE: Optional[set[str]] = None
QUALITY_SHADOW_CHECKPOINT_SEC = max(120.0, float(os.getenv("QUALITY_SHADOW_CHECKPOINT_SEC", "300")))
QUALITY_SHADOW_SUMMARY_SEC = max(120.0, float(os.getenv("QUALITY_SHADOW_SUMMARY_SEC", "300")))
GOOD_S2_CHECKPOINT_SEC = max(120.0, float(os.getenv("GOOD_S2_CHECKPOINT_SEC", "300")))
STRUCTURE_STATE_CHECKPOINT_SEC = max(120.0, float(os.getenv("STRUCTURE_STATE_CHECKPOINT_SEC", "300")))
STRUCTURE_METHOD_STATS_SEC = max(120.0, float(os.getenv("STRUCTURE_METHOD_STATS_SEC", "300")))
STRUCTURE_MISSED_UPDATE_BUDGET = max(24, int(os.getenv("STRUCTURE_MISSED_UPDATE_BUDGET", "96")))
_QUALITY_LAST_CHECKPOINT_V1010 = 0.0
_QUALITY_STATE_CACHE_V1011: Optional[Dict[str, Dict[str, Any]]] = None
_QUALITY_STATE_META_V1011: Dict[str, Any] = {}
_QUALITY_STATUS_CACHE_V1011: Dict[str, Any] = {}
_QUALITY_LAST_SUMMARY_V1011 = 0.0
_QUALITY_LAST_ROTATION_V1011 = 0.0
_QUALITY_EXTERNAL_MIGRATION_V1012: Dict[str, Any] = {}
_QUALITY_EYE_EPOCH_CACHE_V1124: Dict[str, Any] = {}
_QUALITY_EYE_AGG_CACHE_V1124: Optional[Dict[str, Any]] = None
_QUALITY_EYE_PENDING_FINAL_ROWS_V1124: List[Dict[str, Any]] = []
_QUALITY_EYE_SNAPSHOT_CACHE_V1124: Dict[str, Dict[str, Any]] = {}
_GOOD_S2_STATE_CACHE_V1011: Optional[Dict[str, Dict[str, Any]]] = None
_GOOD_S2_STATE_META_V1011: Dict[str, Any] = {}
_GOOD_S2_LAST_CHECKPOINT_V1011 = 0.0
_GOOD_S2_OBSERVATION_CACHE_V1011: Dict[str, Any] = {"signature": None, "rows": []}
_GOOD_S2_FINAL_KEYS_V1011: Optional[set[str]] = None
_STRUCTURE_ACTIVE_CACHE_V1011: Optional[Dict[str, Dict[str, Any]]] = None
_STRUCTURE_ACTIVE_META_V1011: Dict[str, Any] = {}
_STRUCTURE_MISSED_CACHE_V1011: Optional[Dict[str, Dict[str, Any]]] = None
_STRUCTURE_MISSED_META_V1011: Dict[str, Any] = {}
_STRUCTURE_ACTIVE_LAST_CHECKPOINT_V1011 = 0.0
_STRUCTURE_MISSED_LAST_CHECKPOINT_V1011 = 0.0
_STRUCTURE_METHOD_STATS_CACHE_V1011: Dict[str, Any] = {}
_STRUCTURE_METHOD_STATS_AT_V1011 = 0.0
_PERFORMANCE_STATUS_CACHE_V1011: Dict[str, Any] = {}
# v1079: Review is the sole writer of these derived indexes.  Keep the parsed
# canonical checkpoint in-process so the scheduled 300-second refresh consumes
# only the JSONL delta instead of reopening and decoding the full index files.
_PERFORMANCE_STRUCTURE_INDEX_MEM_V1079: Optional[Dict[str, Any]] = None
_PERFORMANCE_COST_INDEX_MEM_V1079: Optional[Dict[str, Any]] = None
_PERFORMANCE_C_SHADOW_INDEX_MEM_V1079: Optional[Dict[str, Any]] = None
_PERFORMANCE_INDEX_MEMORY_STATS_V1079: Dict[str, int] = {
    'structure_disk_loads':0,'structure_memory_hits':0,
    'cost_disk_loads':0,'cost_memory_hits':0,
    'c_shadow_disk_loads':0,'c_shadow_memory_hits':0,
}
_PERSISTENT_JSONL_TAIL_CACHE_V1011: Dict[tuple[str, int], Dict[str, Any]] = {}

# v1050: CLOSED-derived profitability axes are immutable until canonical membership changes.
# Keep one compact analysis cache instead of rebuilding O(n^2) concurrency/reentry groups every cycle.
_PROFITABILITY_CLOSED_AXES_CACHE_V1050: Dict[str, Any] = {}
_PROFITABILITY_CLOSED_SEMANTIC_V1050: tuple[Any, ...] = ()
_PROFITABILITY_CLOSED_RECOMPUTE_COUNT_V1050 = 0

# v1013: append-once dedup keys live in a small SQLite index, not giant Python sets.
# The JSONL ledgers remain canonical.  A short-lived helper rebuilds the index so
# 50~200MB ledgers never expand into a >1GB heap in the long-lived review worker.
REVIEW_DEDUP_DB_V1013 = BASE_DIR / "review_append_dedup_v1013.sqlite3"
_DEDUP_CONN_V1013: Optional[sqlite3.Connection] = None
QUALITY_DEDUP_KIND_V1125 = "quality_v1125"
_DEDUP_PENDING_V1013: Dict[str, set[str]] = {QUALITY_DEDUP_KIND_V1125:set(),"good_s2":set(),"structure_detail":set(),"structure_horizon":set(),"structure_final":set()}
_DEDUP_PREPARE_STATUS_V1013: Dict[str, Any] = {}

# v1128 exact append accounting.
_QUALITY_FINAL_APPEND_CYCLE_V1128: Dict[str, int] = {'attempts':0,'appended':0,'duplicate_blocked':0,'bytes_appended':0}
_QUALITY_FINAL_APPEND_LIFETIME_V1128: Dict[str, int] = {'attempts':0,'appended':0,'duplicate_blocked':0,'bytes_appended':0}


# v1014: finalized good-S2 rows are durable in the append-only result ledger.
# Keep only live/nonterminal rows in the long-lived process and maintain a small
# aggregate snapshot rebuilt in a short-lived helper.
GOOD_S2_FINAL_SUMMARY_V1014 = BASE_DIR / "good_s2_final_summary_v1014.json"
_GOOD_S2_FINAL_AGG_V1014: Dict[str, Any] = {}
_GOOD_S2_FINAL_PREPARE_V1014: Dict[str, Any] = {}

# v1080: non-core observation traces are bounded as active segments plus a
# small, size-capped gzip archive set.  Core OPEN/CLOSED/decision/exact ledgers
# are deliberately outside this policy.
REVIEW_TRACE_ROTATION_STATUS_V1080 = BASE_DIR / 'clean_review_trace_rotation_status_v1080.json'
REVIEW_TRACE_ARCHIVE_ROOT_V1080 = BASE_DIR / 'trace_archive_v1080'
STRUCTURE_DETAIL_ARCHIVE_V1080 = REVIEW_TRACE_ARCHIVE_ROOT_V1080 / 'structure_detail'
STRUCTURE_HORIZON_ARCHIVE_V1080 = REVIEW_TRACE_ARCHIVE_ROOT_V1080 / 'structure_horizon'
STRUCTURE_FINAL_ARCHIVE_V1080 = REVIEW_TRACE_ARCHIVE_ROOT_V1080 / 'structure_final'
GOOD_S2_RESULT_ARCHIVE_V1080 = REVIEW_TRACE_ARCHIVE_ROOT_V1080 / 'good_s2_result'
STRUCTURE_DETAIL_MAX_BYTES_V1080 = int(os.getenv('STRUCTURE_DETAIL_MAX_BYTES_V1080', str(32 * 1024 * 1024)))
STRUCTURE_HORIZON_MAX_BYTES_V1080 = int(os.getenv('STRUCTURE_HORIZON_MAX_BYTES_V1080', str(32 * 1024 * 1024)))
STRUCTURE_FINAL_MAX_BYTES_V1080 = int(os.getenv('STRUCTURE_FINAL_MAX_BYTES_V1080', str(16 * 1024 * 1024)))
GOOD_S2_RESULT_MAX_BYTES_V1080 = int(os.getenv('GOOD_S2_RESULT_MAX_BYTES_V1080', str(16 * 1024 * 1024)))
QUALITY_SHADOW_ARCHIVE_MAX_FILES_V1080 = int(os.getenv('QUALITY_SHADOW_ARCHIVE_MAX_FILES_V1080', '2'))
QUALITY_SHADOW_ARCHIVE_MAX_BYTES_V1080 = int(os.getenv('QUALITY_SHADOW_ARCHIVE_MAX_BYTES_V1080', str(64 * 1024 * 1024)))
STRUCTURE_ARCHIVE_MAX_FILES_V1080 = int(os.getenv('STRUCTURE_ARCHIVE_MAX_FILES_V1080', '2'))
STRUCTURE_ARCHIVE_MAX_BYTES_V1080 = int(os.getenv('STRUCTURE_ARCHIVE_MAX_BYTES_V1080', str(160 * 1024 * 1024)))
GOOD_S2_RESULT_ARCHIVE_MAX_FILES_V1080 = int(os.getenv('GOOD_S2_RESULT_ARCHIVE_MAX_FILES_V1080', '2'))
GOOD_S2_RESULT_ARCHIVE_MAX_BYTES_V1080 = int(os.getenv('GOOD_S2_RESULT_ARCHIVE_MAX_BYTES_V1080', str(64 * 1024 * 1024)))
_V1080_STARTUP_ROTATION_OCCURRED = False
_V1080_LAST_REVIEW_TRACE_STATUS: Dict[str, Any] = {}


def _good_s2_final_signature_v1014() -> Dict[str, int]:
    try:
        st=GOOD_S2_RESULT_LEDGER.stat()
        return {'inode':int(st.st_ino),'size':int(st.st_size),'mtime_ns':int(st.st_mtime_ns)}
    except OSError:
        return {'inode':0,'size':0,'mtime_ns':0}


def _good_s2_empty_agg_v1014() -> Dict[str, Any]:
    return {
        'schema':'good_s2_final_summary_v1014','version':VERSION,'build':BUILD_LABEL,
        'source_signature':_good_s2_final_signature_v1014(),'total_rows':0,
        'open_linked':0,'closed_linked':0,'horizon_complete':0,'unmatched_exact':0,
        'max_sum':0.0,'min_sum':0.0,'giveback_sum':0.0,'metric_rows':0,
        'closed_wins':0,'closed_losses':0,'closed_pnl_sum':0.0,
        'samples_ready':{},'link_mode_counts':{},'recent_rows':[],
        'updated_ts':time.time(),'updated_text':now_text(),
    }


def _good_s2_agg_add_v1014(agg: Dict[str, Any], row: Dict[str, Any]) -> None:
    if not isinstance(row,dict): return
    agg['total_rows']=int(agg.get('total_rows') or 0)+1
    opened=bool(row.get('open_linked')); closed=bool(row.get('closed_linked')); horizon=bool(row.get('horizon_complete'))
    agg['open_linked']=int(agg.get('open_linked') or 0)+(1 if opened else 0)
    agg['closed_linked']=int(agg.get('closed_linked') or 0)+(1 if closed else 0)
    agg['horizon_complete']=int(agg.get('horizon_complete') or 0)+(1 if horizon else 0)
    agg['unmatched_exact']=int(agg.get('unmatched_exact') or 0)+(1 if not opened and not closed else 0)
    maxv=fnum(row.get('max_pct'),default=0.0); minv=fnum(row.get('min_pct'),default=0.0); give=fnum(row.get('giveback_pct'),default=0.0)
    agg['max_sum']=float(agg.get('max_sum') or 0.0)+maxv
    agg['min_sum']=float(agg.get('min_sum') or 0.0)+minv
    agg['giveback_sum']=float(agg.get('giveback_sum') or 0.0)+give
    agg['metric_rows']=int(agg.get('metric_rows') or 0)+1
    if closed:
        pnl=fnum(row.get('closed_pnl_pct'),default=0.0)
        agg['closed_pnl_sum']=float(agg.get('closed_pnl_sum') or 0.0)+pnl
        if pnl>0: agg['closed_wins']=int(agg.get('closed_wins') or 0)+1
        else: agg['closed_losses']=int(agg.get('closed_losses') or 0)+1
    samples=row.get('samples') if isinstance(row.get('samples'),dict) else {}
    sc=Counter(agg.get('samples_ready') or {})
    for label in ('3m','5m','10m','20m','60m'):
        if label in samples: sc[label]+=1
    agg['samples_ready']=dict(sc)
    lc=Counter(agg.get('link_mode_counts') or {})
    if opened: lc['open:'+str(row.get('open_match_mode') or 'exact')]+=1
    if closed: lc['closed:'+str(row.get('closed_match_mode') or 'exact')]+=1
    agg['link_mode_counts']=dict(lc)
    recent=list(agg.get('recent_rows') or [])
    compact={k:row.get(k) for k in ('occurrence_key','ticker','observed_ts','first_price','latest_price','current_pct','max_pct','min_pct','giveback_pct','open_linked','open_match_mode','closed_linked','closed_match_mode','closed_pnl_pct','horizon_complete','result_state','samples') if row.get(k) not in (None,'',[],{})}
    recent.append(compact)
    recent=sorted((x for x in recent if isinstance(x,dict)),key=lambda x:fnum(x.get('observed_ts'),default=0.0),reverse=True)[:80]
    agg['recent_rows']=recent
    agg['updated_ts']=time.time(); agg['updated_text']=now_text()


def _good_s2_rebuild_summary_v1014(target: Path) -> Dict[str, Any]:
    started=time.time(); agg=_good_s2_empty_agg_v1014(); bad=0
    if GOOD_S2_RESULT_LEDGER.exists():
        with GOOD_S2_RESULT_LEDGER.open('r',encoding='utf-8',errors='ignore') as handle:
            for line in handle:
                try: row=json.loads(line)
                except Exception: bad+=1; continue
                if not isinstance(row,dict): bad+=1; continue
                _good_s2_agg_add_v1014(agg,row)
    agg['source_signature']=_good_s2_final_signature_v1014(); agg['bad_json']=bad
    agg['rebuilt_in_short_lived_helper']=True; agg['elapsed_sec']=round(time.time()-started,3)
    save_json(target,agg)
    return {'ok':True,'rows':int(agg.get('total_rows') or 0),'bad_json':bad,'elapsed_sec':agg['elapsed_sec']}


def _prepare_good_s2_summary_v1014() -> Dict[str, Any]:
    global _GOOD_S2_FINAL_AGG_V1014, _GOOD_S2_FINAL_PREPARE_V1014
    if _GOOD_S2_FINAL_AGG_V1014:
        return _GOOD_S2_FINAL_AGG_V1014
    current=load_json(GOOD_S2_FINAL_SUMMARY_V1014,{}) or {}
    sig=_good_s2_final_signature_v1014()
    same=isinstance(current,dict) and current.get('source_signature')==sig and str(current.get('schema') or '')=='good_s2_final_summary_v1014'
    if not same:
        env=dict(os.environ); env['REVIEW_GOOD_S2_SUMMARY_CHILD_V1014']='1'
        proc=subprocess.run([sys.executable,str(Path(__file__).resolve()),'--build-good-s2-summary-v1014',str(GOOD_S2_FINAL_SUMMARY_V1014)],stdout=subprocess.PIPE,stderr=subprocess.PIPE,text=True,timeout=240,env=env,check=False)
        payload={}
        try: payload=json.loads(proc.stdout.strip().splitlines()[-1]) if proc.stdout.strip() else {}
        except Exception: payload={'stdout_tail':proc.stdout[-500:]}
        _GOOD_S2_FINAL_PREPARE_V1014={'ok':proc.returncode==0 and bool(payload.get('ok')),'returncode':proc.returncode,'payload':payload,'stderr_tail':proc.stderr[-500:]}
        current=load_json(GOOD_S2_FINAL_SUMMARY_V1014,{}) or {}
    else:
        _GOOD_S2_FINAL_PREPARE_V1014={'ok':True,'reused':True,'rows':int(current.get('total_rows') or 0)}
    if not isinstance(current,dict) or str(current.get('schema') or '')!='good_s2_final_summary_v1014':
        current=_good_s2_empty_agg_v1014(); _GOOD_S2_FINAL_PREPARE_V1014={'ok':False,'fallback_empty':True}
    _GOOD_S2_FINAL_AGG_V1014=current
    return _GOOD_S2_FINAL_AGG_V1014


def _commit_good_s2_aggregate_v1014(final_row: Dict[str, Any]) -> None:
    global _GOOD_S2_FINAL_AGG_V1014
    agg=_prepare_good_s2_summary_v1014()
    _good_s2_agg_add_v1014(agg,final_row)
    agg['source_signature']=_good_s2_final_signature_v1014()
    save_json(GOOD_S2_FINAL_SUMMARY_V1014,agg)
    _GOOD_S2_FINAL_AGG_V1014=agg


def _quality_status_runtime_v1014(nowv: float, state: str, error: str='') -> Dict[str, Any]:
    prev=load_json(QUALITY_SHADOW_STATUS,{}) or {}
    obj=dict(prev) if isinstance(prev,dict) else {}
    obj.update({'schema':'quality_shadow_status_v1014_runtime_single_writer','version':VERSION,'build':BUILD_LABEL,'state':state,'updated_ts':nowv,'updated_text':now_text(nowv),'runtime_writer_pid_v1014':os.getpid(),'runtime_phase_v1014':state.lower()})
    if error: obj['error_v1014']=error[:500]
    elif 'error_v1014' in obj: obj.pop('error_v1014',None)
    save_json(QUALITY_SHADOW_STATUS,obj)
    return obj

def _dedup_source_specs_v1013() -> List[tuple[str, Path, tuple[str, ...], bool]]:
    specs: List[tuple[str, Path, tuple[str, ...], bool]] = [
        (QUALITY_DEDUP_KIND_V1125, QUALITY_SHADOW_LEDGER, ('quality_event_key_v946',), False),
        ('good_s2', GOOD_S2_RESULT_LEDGER, ('final_result_key',), False),
        ('structure_detail', STRUCTURE_LAB_EVENT_DETAIL_LEDGER_LEGACY, ('event_key','plan_key'), False),
        ('structure_detail', STRUCTURE_LAB_EVENT_DETAIL_LEDGER, ('event_key','plan_key'), False),
        ('structure_horizon', STRUCTURE_LAB_HORIZON_LEDGER, ('result_key',), False),
        ('structure_final', STRUCTURE_LAB_FINAL_LEDGER, ('event_key',), False),
    ]
    archive_specs = [
        (QUALITY_DEDUP_KIND_V1125, QUALITY_SHADOW_ARCHIVE, 'quality_shadow_result_*.jsonl.gz', ('quality_event_key_v946',)),
        ('good_s2', GOOD_S2_RESULT_ARCHIVE_V1080, 'good_s2_result_*.jsonl.gz', ('final_result_key',)),
        ('structure_detail', STRUCTURE_DETAIL_ARCHIVE_V1080, 'structure_detail_*.jsonl.gz', ('event_key','plan_key')),
        ('structure_horizon', STRUCTURE_HORIZON_ARCHIVE_V1080, 'structure_horizon_*.jsonl.gz', ('result_key',)),
        ('structure_final', STRUCTURE_FINAL_ARCHIVE_V1080, 'structure_final_*.jsonl.gz', ('event_key',)),
    ]
    for kind,directory,pattern,key_fields in archive_specs:
        if not directory.exists():
            continue
        archives=sorted((path for path in directory.glob(pattern) if path.is_file()), key=lambda x:x.stat().st_mtime_ns, reverse=True)[:2]
        specs.extend((kind,path,key_fields,True) for path in archives)
    return specs

def _dedup_source_signature_v1013() -> List[Dict[str, Any]]:
    out=[]
    for kind,path,_keys,is_gzip in _dedup_source_specs_v1013():
        try:
            st=path.stat(); out.append({"kind":kind,"path":str(path),"inode":int(st.st_ino),"size":int(st.st_size),"mtime_ns":int(st.st_mtime_ns),"gzip":bool(is_gzip)})
        except OSError:
            out.append({"kind":kind,"path":str(path),"inode":0,"size":0,"mtime_ns":0,"gzip":bool(is_gzip)})
    return out

def _dedup_rebuild_v1013(target: Path) -> Dict[str, Any]:
    started=time.time(); tmp=target.with_name(target.name+f".tmp.{os.getpid()}.{time.time_ns()}")
    try: tmp.unlink(missing_ok=True)
    except OSError: pass
    conn=sqlite3.connect(str(tmp), timeout=60)
    conn.execute("PRAGMA journal_mode=DELETE")
    conn.execute("PRAGMA synchronous=FULL")
    conn.execute("CREATE TABLE keys(kind TEXT NOT NULL, key TEXT NOT NULL, PRIMARY KEY(kind,key)) WITHOUT ROWID")
    conn.execute("CREATE TABLE meta(name TEXT PRIMARY KEY, value TEXT NOT NULL) WITHOUT ROWID")
    counts=Counter(); bad=0
    for kind,path,key_fields,is_gzip in _dedup_source_specs_v1013():
        if not path.exists(): continue
        opener=(lambda: gzip.open(path,'rt',encoding='utf-8',errors='ignore')) if is_gzip else (lambda: path.open('r',encoding='utf-8',errors='ignore'))
        batch=[]
        with opener() as handle:
            for line in handle:
                try: row=json.loads(line)
                except Exception: bad+=1; continue
                if not isinstance(row,dict): continue
                key=''
                for field in key_fields:
                    value=str(row.get(field) or '').strip()
                    if value: key=value; break
                if not key: continue
                batch.append((kind,key))
                if len(batch)>=5000:
                    conn.executemany("INSERT OR IGNORE INTO keys(kind,key) VALUES(?,?)",batch); batch.clear()
            if batch: conn.executemany("INSERT OR IGNORE INTO keys(kind,key) VALUES(?,?)",batch)
    for kind,count in conn.execute("SELECT kind,COUNT(*) FROM keys GROUP BY kind"):
        counts[str(kind)]=int(count)
    signature=_dedup_source_signature_v1013()
    conn.execute("INSERT INTO meta(name,value) VALUES(?,?)",("source_signature",json.dumps(signature,ensure_ascii=False,separators=(',',':'))))
    conn.execute("INSERT INTO meta(name,value) VALUES(?,?)",("built_at",str(time.time())))
    conn.commit(); conn.close(); os.replace(tmp,target)
    return {"ok":True,"counts":dict(counts),"bad_json":bad,"db_bytes":target.stat().st_size if target.exists() else 0,"sec":round(time.time()-started,3),"source_signature":signature}

def _dedup_db_signature_v1013() -> Any:
    if not REVIEW_DEDUP_DB_V1013.exists(): return None
    try:
        conn=sqlite3.connect(f"file:{REVIEW_DEDUP_DB_V1013}?mode=ro",uri=True,timeout=5)
        row=conn.execute("SELECT value FROM meta WHERE name='source_signature'").fetchone(); conn.close()
        return json.loads(row[0]) if row else None
    except Exception: return None

def _dedup_prepare_v1013() -> Dict[str, Any]:
    global _DEDUP_CONN_V1013, _DEDUP_PREPARE_STATUS_V1013
    current=_dedup_source_signature_v1013(); stored=_dedup_db_signature_v1013()
    if REVIEW_DEDUP_DB_V1013.exists():
        try:
            conn=sqlite3.connect(str(REVIEW_DEDUP_DB_V1013),timeout=30,check_same_thread=False)
            quick=conn.execute('PRAGMA quick_check').fetchone()
            tables={str(row[0]) for row in conn.execute("SELECT name FROM sqlite_master WHERE type='table'")}
            healthy=bool(quick and str(quick[0]).lower()=='ok' and {'keys','meta'}.issubset(tables))
            if healthy:
                conn.execute('PRAGMA journal_mode=DELETE'); conn.execute('PRAGMA synchronous=FULL')
                rebased=stored!=current
                if rebased:
                    conn.execute("INSERT OR REPLACE INTO meta(name,value) VALUES(?,?)",('source_signature',json.dumps(current,ensure_ascii=False,separators=(',',':'))))
                    conn.execute("INSERT OR REPLACE INTO meta(name,value) VALUES(?,?)",('signature_rebased_v1080',str(time.time())))
                    conn.commit()
                _DEDUP_CONN_V1013=conn
                _DEDUP_PREPARE_STATUS_V1013={'ok':True,'rebuilt':False,'db_reused_v1080':True,'source_signature_rebased_v1080':rebased,'source_count':len(current),'quick_check':'ok'}
                return _DEDUP_PREPARE_STATUS_V1013
            conn.close()
        except Exception:
            try: conn.close()
            except Exception: pass
    env=dict(os.environ); env['REVIEW_V1013_DEDUP_CHILD']='1'
    proc=subprocess.run([sys.executable,str(Path(__file__).resolve()),'--build-dedup-index-v1013',str(REVIEW_DEDUP_DB_V1013)],stdout=subprocess.PIPE,stderr=subprocess.PIPE,text=True,timeout=420,env=env,check=False)
    payload={}
    try: payload=json.loads(proc.stdout.strip().splitlines()[-1]) if proc.stdout.strip() else {}
    except Exception: payload={'stdout_tail':proc.stdout[-500:]}
    _DEDUP_PREPARE_STATUS_V1013={'ok':proc.returncode==0 and bool(payload.get('ok')),'rebuilt':True,'payload':payload,'stderr_tail':proc.stderr[-500:]}
    if not _DEDUP_PREPARE_STATUS_V1013['ok']: raise RuntimeError(f'review dedup index build failed: {_DEDUP_PREPARE_STATUS_V1013}')
    _DEDUP_CONN_V1013=sqlite3.connect(str(REVIEW_DEDUP_DB_V1013),timeout=30,check_same_thread=False)
    _DEDUP_CONN_V1013.execute('PRAGMA journal_mode=DELETE'); _DEDUP_CONN_V1013.execute('PRAGMA synchronous=FULL')
    return _DEDUP_PREPARE_STATUS_V1013


def _dedup_sync_source_signature_v1080() -> Dict[str, Any]:
    try:
        current=_dedup_source_signature_v1013(); conn=_dedup_conn_v1013()
        conn.execute("INSERT OR REPLACE INTO meta(name,value) VALUES(?,?)",('source_signature',json.dumps(current,ensure_ascii=False,separators=(',',':'))))
        conn.execute("INSERT OR REPLACE INTO meta(name,value) VALUES(?,?)",('source_signature_synced_at_v1080',str(time.time())))
        conn.commit(); return {'ok':True,'source_count':len(current)}
    except Exception as exc:
        return {'ok':False,'error':f'{type(exc).__name__}: {exc}'}

def _dedup_conn_v1013() -> sqlite3.Connection:
    global _DEDUP_CONN_V1013
    if _DEDUP_CONN_V1013 is None: _dedup_prepare_v1013()
    assert _DEDUP_CONN_V1013 is not None
    return _DEDUP_CONN_V1013

def _dedup_contains_v1013(kind: str, key: str) -> bool:
    if not key: return False
    if key in _DEDUP_PENDING_V1013.setdefault(kind,set()): return True
    row=_dedup_conn_v1013().execute("SELECT 1 FROM keys WHERE kind=? AND key=? LIMIT 1",(kind,key)).fetchone()
    return row is not None

def _dedup_mark_pending_v1013(kind: str, key: str) -> None:
    if key: _DEDUP_PENDING_V1013.setdefault(kind,set()).add(key)

def _dedup_commit_v1013(kind: str, key: str) -> None:
    if not key: return
    conn=_dedup_conn_v1013(); conn.execute("INSERT OR IGNORE INTO keys(kind,key) VALUES(?,?)",(kind,key)); conn.commit()
    _DEDUP_PENDING_V1013.setdefault(kind,set()).discard(key)

def _dedup_commit_many_v1013(kind: str, keys: List[str]) -> None:
    vals=[(kind,key) for key in keys if key]
    if vals:
        conn=_dedup_conn_v1013(); conn.executemany("INSERT OR IGNORE INTO keys(kind,key) VALUES(?,?)",vals); conn.commit()
    pending=_DEDUP_PENDING_V1013.setdefault(kind,set())
    for _kind,key in vals: pending.discard(key)

def _dedup_count_v1013(kind: str) -> int:
    row=_dedup_conn_v1013().execute("SELECT COUNT(*) FROM keys WHERE kind=?",(kind,)).fetchone()
    return int(row[0] if row else 0)
_PHASE_IO_SAMPLES_V1011: Dict[str, Dict[str, float]] = {}
_CURRENT_PHASE_IO_START_V1011: Dict[str, int] = {}
QUALITY_SHADOW_HORIZONS = (("1m",60.0),("3m",180.0),("5m",300.0),("10m",600.0),("20m",1200.0),("60m",3600.0))
LATE_PATH_STATUS = BASE_DIR / "clean_late_path_status_v947.json"
PAPER_DECISION_STATE = BASE_DIR / "paper_decision_state_v926.json"
SAMPLE_BOARD_STATUS = BASE_DIR / 'clean_sample_board_status_v948.json'
SMART_STRUCTURE_CANDIDATES = BASE_DIR / 'clean_smart_structure_shadow_candidates_v948.json'
SMART_STRUCTURE_STATE = BASE_DIR / 'clean_smart_structure_shadow_state_v948.json'
SMART_STRUCTURE_STATUS = BASE_DIR / 'clean_smart_structure_shadow_review_status_v948.json'
SMART_STRUCTURE_HORIZONS = (('1m',60.0),('3m',180.0),('5m',300.0),('10m',600.0),('20m',1200.0),('60m',3600.0))
STRUCTURE_LAB_CANDIDATES = BASE_DIR / 'clean_structure_lab_candidates_v956.json'
STRUCTURE_LAB_STRATEGY_STATUS = BASE_DIR / 'clean_structure_lab_strategy_status_v956.json'
STRUCTURE_LAB_STATE_V952 = BASE_DIR / 'clean_structure_lab_state_v952.json'
STRUCTURE_LAB_STATE_V955 = BASE_DIR / 'clean_structure_lab_state_v955.json'
STRUCTURE_LAB_ACTIVE_STATE = BASE_DIR / 'clean_structure_lab_active_state_v956.json'
STRUCTURE_LAB_REVIEW_STATUS = BASE_DIR / 'clean_structure_lab_review_status_v956.json'
STRUCTURE_MISSED_STATE_V952 = BASE_DIR / 'clean_structure_missed_state_v952.json'
STRUCTURE_MISSED_STATE_V955 = BASE_DIR / 'clean_structure_missed_state_v955.json'
STRUCTURE_MISSED_STATE = BASE_DIR / 'clean_structure_missed_state_v956.json'
STRUCTURE_MISSED_STATUS = BASE_DIR / 'clean_structure_missed_status_v956.json'
STRUCTURE_LAB_EVENT_DETAIL_LEDGER_LEGACY = BASE_DIR / 'structure_lab_event_detail_ledger_v955.jsonl'
STRUCTURE_LAB_EVENT_DETAIL_LEDGER = BASE_DIR / 'structure_lab_event_detail_ledger_v956.jsonl'
STRUCTURE_LAB_HORIZON_LEDGER = BASE_DIR / 'structure_lab_horizon_result_ledger_v956.jsonl'
STRUCTURE_LAB_HORIZON_SUMMARY = BASE_DIR / 'clean_structure_lab_horizon_summary_v956.json'
STRUCTURE_LAB_FINAL_LEDGER = BASE_DIR / 'structure_lab_event_final_ledger_v956.jsonl'
STRUCTURE_REVIEW_UPDATE_BUDGET = max(48, int(os.getenv('STRUCTURE_REVIEW_UPDATE_BUDGET', '96')))
STRUCTURE_REVIEW_FAST_SEC = float(os.getenv('STRUCTURE_REVIEW_FAST_SEC', '30'))
STRUCTURE_REVIEW_MID_SEC = float(os.getenv('STRUCTURE_REVIEW_MID_SEC', '60'))
STRUCTURE_REVIEW_SLOW_SEC = float(os.getenv('STRUCTURE_REVIEW_SLOW_SEC', '180'))
STRUCTURE_LAB_HORIZONS = (('1m',60.0),('3m',180.0),('5m',300.0),('10m',600.0),('20m',1200.0),('60m',3600.0),('120m',7200.0),('240m',14400.0),('720m',43200.0),('1440m',86400.0))
STRUCTURE_LAB_RETENTION_SEC = 36 * 3600.0  # keep enough history for 12h/24h horizons plus processing delay
PERFORMANCE_LAB_STATUS = BASE_DIR / 'clean_performance_lab_status_v959.json'
CANONICAL_PERFORMANCE_V987 = BASE_DIR / 'canonical_performance_snapshot_v987.json'
PROFITABILITY_DIAGNOSTIC_V1034 = BASE_DIR / 'profitability_diagnostic_snapshot_v1034.json'
PROFITABILITY_DIAGNOSTIC_STATUS_V1034 = BASE_DIR / 'clean_profitability_diagnostic_status_v1034.json'
EARLY_REGRESSION_AUDIT_V1035 = BASE_DIR / 'early_regression_audit_snapshot_v1035.json'
EARLY_REGRESSION_STATUS_V1035 = BASE_DIR / 'clean_early_regression_audit_status_v1035.json'
EARLY_REGRESSION_STATE_V1035 = BASE_DIR / 'early_regression_audit_state_v1035.json'
EARLY_REGRESSION_INTERVAL_SEC_V1035 = max(3600.0, float(os.getenv('EARLY_REGRESSION_INTERVAL_SEC_V1035', '21600')))
PERFORMANCE_STRUCTURE_INDEX = BASE_DIR / 'clean_performance_structure_index_v959.json'
PAPER_EXECUTION_COST_LEDGER = BASE_DIR / 'paper_execution_cost_ledger.jsonl'
PERFORMANCE_COST_INDEX = BASE_DIR / 'clean_performance_cost_index.json'
PERFORMANCE_C_SHADOW_INDEX = BASE_DIR / 'clean_performance_c_break_retest_shadow_index_v962.json'
QUALITY_EVENT_CONTEXT_SCHEMA = 'quality_event_context_v965'
QUALITY_EVENT_CONTEXT_MIGRATION_SCHEMA = 'quality_event_context_migration_v965'
PERFORMANCE_STRUCTURE_METHODS = ('A_SWING','B_REACTION_ZONE','C_BREAK_RETEST','D_SUPPLY_DEMAND','E_VOLUME_PROFILE')
PERFORMANCE_STRUCTURE_HORIZONS = tuple(label for label,_sec in STRUCTURE_LAB_HORIZONS)
PERFORMANCE_FEE_SOURCE_STATUS = 'WAITING_EXACT_FEE_SOURCE'
REVIEW_DEDUP_INDEX = BASE_DIR / 'clean_review_dedup_index_v1007.json'
REVIEW_RETENTION_STATUS = BASE_DIR / 'clean_review_retention_status_v1007.json'

def now_ts() -> float: return time.time()
def now_text(ts: Optional[float]=None) -> str: return time.strftime("%Y-%m-%d %H:%M:%S", time.localtime(ts or now_ts()))
def fnum(*vals: Any, default: float=0.0) -> float:
    for v in vals:
        try:
            if v is None or v == "": continue
            return float(str(v).replace(",", "").replace("%", ""))
        except Exception: continue
    return default

_JSON_CYCLE_CACHE: Dict[tuple, Any] = {}
_JSONL_LINE_COUNT_CACHE: Dict[str, Dict[str, int]] = {}

def _drop_json_cache(path: Path) -> None:
    key_path = str(path)
    for key in [k for k in _JSON_CYCLE_CACHE if k and k[0] == key_path]:
        _JSON_CYCLE_CACHE.pop(key, None)

def load_json(path: Path, default: Any=None) -> Any:
    """Read JSON through a streaming decoder and cache only one object per file signature."""
    try:
        if not path.exists():
            return default
        stat = path.stat()
        key = (str(path), int(stat.st_mtime_ns), int(stat.st_size))
        if key in _JSON_CYCLE_CACHE:
            return _JSON_CYCLE_CACHE[key]
        with path.open("r", encoding="utf-8", errors="ignore") as f:
            obj = json.load(f)
        _JSON_CYCLE_CACHE[key] = obj
        return obj
    except Exception:
        return default

def save_json(path: Path, obj: Any) -> None:
    """Atomic streaming JSON writer; never builds a second full serialized string."""
    path.parent.mkdir(parents=True, exist_ok=True)
    tmp = path.with_name(path.name + f".tmp.{os.getpid()}.{time.time_ns()}")
    try:
        with tmp.open("w", encoding="utf-8") as f:
            json.dump(obj, f, ensure_ascii=False, separators=(",", ":"), default=str)
            f.flush()
            os.fsync(f.fileno())
        os.replace(tmp, path)
        _drop_json_cache(path)
    finally:
        try:
            tmp.unlink(missing_ok=True)
        except OSError:
            pass

_JSONL_CYCLE_CACHE: Dict[tuple, List[Dict[str, Any]]] = {}

def _tail_text_lines(path: Path, max_lines: int) -> List[str]:
    if max_lines <= 0:
        with path.open("r", encoding="utf-8", errors="ignore") as f:
            return [line.rstrip("\n") for line in f]
    chunks: List[bytes] = []
    newline_count = 0
    with path.open("rb") as f:
        f.seek(0, os.SEEK_END)
        pos = f.tell()
        while pos > 0 and newline_count <= max_lines:
            size = min(65536, pos)
            pos -= size
            f.seek(pos)
            block = f.read(size)
            chunks.append(block)
            newline_count += block.count(b"\n")
    data = b"".join(reversed(chunks)).decode("utf-8", errors="ignore")
    return data.splitlines()[-max_lines:]

def read_jsonl(path: Path, max_lines: int=1000) -> List[Dict[str, Any]]:
    if not path.exists():
        return []
    try:
        stat = path.stat()
        key = (str(path), int(max_lines), int(stat.st_mtime_ns), int(stat.st_size))
        cached = _JSONL_CYCLE_CACHE.get(key)
        if cached is not None:
            return cached
        lines = _tail_text_lines(path, int(max_lines))
        out: List[Dict[str, Any]] = []
        for ln in lines:
            try:
                if ln.strip():
                    obj = json.loads(ln)
                    if isinstance(obj, dict):
                        out.append(obj)
            except Exception:
                continue
        _JSONL_CYCLE_CACHE[key] = out
        return out
    except Exception as exc:
        append_error(ERROR, "read_jsonl_v929", exc)
        return []




def _v1080_size(path: Path) -> int:
    try: return int(path.stat().st_size)
    except OSError: return 0


def _v1080_archive_inventory(directory: Path, pattern: str) -> List[Path]:
    try:
        return sorted((x for x in directory.glob(pattern) if x.is_file()), key=lambda x:(x.stat().st_mtime_ns,x.name), reverse=True) if directory.exists() else []
    except OSError:
        return []


def _v1080_prune_archives(directory: Path, pattern: str, max_files: int, max_total_bytes: int) -> Dict[str, Any]:
    files=_v1080_archive_inventory(directory,pattern)
    before_count=len(files); before_bytes=sum(_v1080_size(x) for x in files)
    kept=[]; kept_bytes=0; deleted=[]
    for index,path in enumerate(files):
        size=_v1080_size(path)
        keep=bool(index < max(1,int(max_files)) and (not kept or kept_bytes+size <= max(1,int(max_total_bytes))))
        if keep:
            kept.append(path); kept_bytes+=size; continue
        try:
            path.unlink(); deleted.append({'name':path.name,'bytes':size})
        except OSError:
            kept.append(path); kept_bytes+=size
    return {'before_count':before_count,'before_bytes':before_bytes,'after_count':len(kept),'after_bytes':kept_bytes,'deleted_count':len(deleted),'deleted_bytes':sum(x['bytes'] for x in deleted),'deleted_sample':deleted[:8]}


def _v1080_gzip_file(source: Path, target: Path) -> int:
    tmp=target.with_name(target.name+f'.tmp.{os.getpid()}.{time.time_ns()}')
    try:
        with source.open('rb') as src, gzip.open(tmp,'wb',compresslevel=1) as dst:
            while True:
                block=src.read(1024*1024)
                if not block: break
                dst.write(block)
        os.replace(tmp,target)
        return _v1080_size(target)
    finally:
        try: tmp.unlink(missing_ok=True)
        except OSError: pass


def _v1080_recover_pending(path: Path, archive_dir: Path, prefix: str, max_archive_files: int, max_archive_bytes: int) -> Dict[str, Any]:
    """Recover only v1080 non-core trace segments left by an interrupted rollover."""
    archive_dir.mkdir(parents=True,exist_ok=True)
    recovered=[]; errors=[]
    try:
        pending_files=sorted((x for x in path.parent.glob(path.name+'.rotate_pending_v1080.*') if x.is_file()),key=lambda x:(x.stat().st_mtime_ns,x.name))
    except OSError:
        pending_files=[]
    for pending in pending_files:
        stamp=time.strftime('%Y%m%d_%H%M%S',time.localtime())+f'_recovered_{time.time_ns()}'
        archive=archive_dir/f'{prefix}_{stamp}.jsonl.gz'
        try:
            archive_bytes=_v1080_gzip_file(pending,archive)
            pending.unlink(missing_ok=True)
            recovered.append({'pending':pending.name,'archive':archive.name,'archive_bytes':archive_bytes})
        except Exception as exc:
            errors.append({'pending':pending.name,'error':f'{type(exc).__name__}: {exc}'})
    prune=_v1080_prune_archives(archive_dir,f'{prefix}_*.jsonl.gz',max_archive_files,max_archive_bytes)
    return {'recovered_count':len(recovered),'recovered':recovered[:8],'error_count':len(errors),'errors':errors[:8],'archive_prune':prune}


def _v1080_cleanup_stale_quality_tmp(nowv: float) -> Dict[str, Any]:
    """Remove only abandoned atomic temp files for the non-core quality state."""
    deleted=[]; skipped=[]; min_age=1800.0
    for path in BASE_DIR.glob(QUALITY_SHADOW_STATE.name+'.tmp.*'):
        try:
            age=max(0.0,nowv-path.stat().st_mtime)
            parts=path.name.split('.tmp.',1)[1].split('.') if '.tmp.' in path.name else []
            owner_pid=int(parts[0]) if parts and parts[0].isdigit() else 0
            owner_alive=bool(owner_pid>0 and Path(f'/proc/{owner_pid}').exists())
            if age < min_age or owner_alive:
                skipped.append({'name':path.name,'bytes':_v1080_size(path),'age_sec':round(age,1),'owner_alive':owner_alive}); continue
            size=_v1080_size(path); path.unlink(); deleted.append({'name':path.name,'bytes':size,'age_sec':round(age,1)})
        except OSError as exc:
            skipped.append({'name':path.name,'error':f'{type(exc).__name__}: {exc}'})
    return {'deleted_count':len(deleted),'deleted_bytes':sum(x.get('bytes',0) for x in deleted),'deleted':deleted[:8],'skipped_count':len(skipped),'skipped':skipped[:8],'scope':QUALITY_SHADOW_STATE.name+'.tmp.*','min_age_sec':min_age}


def _v1080_rotate_whole_jsonl(path: Path, archive_dir: Path, prefix: str, max_active_bytes: int, max_archive_files: int, max_archive_bytes: int, *, force: bool=False) -> Dict[str, Any]:
    archive_dir.mkdir(parents=True,exist_ok=True)
    recovery=_v1080_recover_pending(path,archive_dir,prefix,max_archive_files,max_archive_bytes)
    before=_v1080_size(path)
    prune_before=_v1080_prune_archives(archive_dir,f'{prefix}_*.jsonl.gz',max_archive_files,max_archive_bytes)
    if not force and before <= max_active_bytes:
        return {'rotated':False,'active_before_bytes':before,'active_after_bytes':before,'max_active_bytes':max_active_bytes,'pending_recovery':recovery,'archive_prune':prune_before}
    if before <= 0 or not path.exists():
        return {'rotated':False,'active_before_bytes':before,'active_after_bytes':before,'max_active_bytes':max_active_bytes,'pending_recovery':recovery,'archive_prune':prune_before}
    stamp=time.strftime('%Y%m%d_%H%M%S',time.localtime())+f'_{time.time_ns()}'
    pending=path.with_name(path.name+f'.rotate_pending_v1080.{os.getpid()}.{time.time_ns()}')
    archive=archive_dir/f'{prefix}_{stamp}.jsonl.gz'
    try:
        os.replace(path,pending)
        empty=path.with_name(path.name+f'.tmp.empty.{os.getpid()}.{time.time_ns()}')
        with empty.open('wb') as handle:
            handle.flush(); os.fsync(handle.fileno())
        os.replace(empty,path)
        archive_bytes=_v1080_gzip_file(pending,archive)
        pending.unlink(missing_ok=True)
        prune_after=_v1080_prune_archives(archive_dir,f'{prefix}_*.jsonl.gz',max_archive_files,max_archive_bytes)
        return {'rotated':True,'active_before_bytes':before,'active_after_bytes':_v1080_size(path),'max_active_bytes':max_active_bytes,'archive_file':archive.name,'archive_bytes':archive_bytes,'pending_recovery':recovery,'archive_prune_before':prune_before,'archive_prune':prune_after}
    except Exception as exc:
        if not path.exists() and pending.exists():
            try: os.replace(pending,path)
            except OSError: pass
        return {'rotated':False,'active_before_bytes':before,'active_after_bytes':_v1080_size(path),'max_active_bytes':max_active_bytes,'error':f'{type(exc).__name__}: {exc}','pending_file':pending.name if pending.exists() else None,'pending_recovery':recovery,'archive_prune':prune_before}


def _v1080_archive_status(directory: Path, pattern: str) -> Dict[str, Any]:
    files=_v1080_archive_inventory(directory,pattern)
    return {'files':len(files),'bytes':sum(_v1080_size(x) for x in files),'sample':[x.name for x in files[:4]]}

def count_jsonl_lines(path: Path) -> int:
    """Incrementally count appended JSONL rows; reset only when inode/size proves rotation."""
    if not path.exists():
        _JSONL_LINE_COUNT_CACHE.pop(str(path), None)
        return 0
    try:
        stat = path.stat()
        cache = _JSONL_LINE_COUNT_CACHE.get(str(path))
        inode = int(stat.st_ino)
        size = int(stat.st_size)
        offset = 0
        count = 0
        if isinstance(cache, dict) and cache.get("inode") == inode and 0 <= cache.get("offset", -1) <= size:
            offset = int(cache["offset"])
            count = int(cache.get("count", 0))
        with path.open("rb") as f:
            f.seek(offset)
            while True:
                block = f.read(1024 * 1024)
                if not block:
                    break
                count += block.count(b"\n")
            offset = f.tell()
        _JSONL_LINE_COUNT_CACHE[str(path)] = {"inode": inode, "offset": offset, "count": count}
        return count
    except Exception as exc:
        append_error(ERROR, "count_jsonl_lines_v1008", exc)
        return 0

def append_error(path: Path, where: str, exc: BaseException) -> None:
    try:
        path.parent.mkdir(parents=True, exist_ok=True)
        with path.open("a", encoding="utf-8") as f:
            f.write(f"[{now_text()}] {where}: {exc.__class__.__name__}: {exc}\n")
            f.write(traceback.format_exc()[-1500:] + "\n")
    except Exception: pass

def ticker_norm(x: Any) -> str:
    t = str(x or "").strip().upper().replace("/", "-").replace("_", "-")
    parts = [p for p in t.split("-") if p]
    if len(parts) >= 2:
        non = [p for p in parts if p != "KRW"]
        t = non[-1] if non else parts[-1]
    if t.endswith("KRW") and len(t) > 3: t = t[:-3]
    return t.strip().upper()

def map_rows(obj: Any) -> Dict[str, Dict[str, Any]]:
    if isinstance(obj, dict) and isinstance(obj.get("rows"), list): obj = obj.get("rows")
    elif isinstance(obj, dict) and isinstance(obj.get("rows"), dict): obj = obj.get("rows")
    elif isinstance(obj, dict) and isinstance(obj.get("cache"), dict): obj = obj.get("cache")
    out: Dict[str, Dict[str, Any]] = {}
    if isinstance(obj, list):
        for r in obj:
            if isinstance(r, dict):
                t = ticker_norm(r.get("ticker") or r.get("symbol") or r.get("market"))
                if t: out[t] = r
    elif isinstance(obj, dict):
        for k, v in obj.items():
            t = ticker_norm(k)
            if t and isinstance(v, dict):
                vv = dict(v); vv.setdefault("ticker", t); out[t] = vv
    return out


def _proc_io_counters_v1011() -> Dict[str, int]:
    out = {"read_bytes": 0, "write_bytes": 0, "rchar": 0, "wchar": 0}
    try:
        for line in Path("/proc/self/io").read_text(encoding="utf-8", errors="ignore").splitlines():
            if ":" not in line:
                continue
            key, value = line.split(":", 1)
            if key in out:
                out[key] = int(value.strip() or 0)
    except Exception:
        pass
    return out


def _persistent_jsonl_tail_v1011(path: Path, max_lines: int) -> List[Dict[str, Any]]:
    """Cross-cycle stat-keyed tail cache. Stable ledgers are not reparsed each cycle."""
    cache_key = (str(path), int(max_lines))
    try:
        stat = path.stat()
        signature = (int(stat.st_ino), int(stat.st_size), int(stat.st_mtime_ns))
    except OSError:
        _PERSISTENT_JSONL_TAIL_CACHE_V1011.pop(cache_key, None)
        return []
    cached = _PERSISTENT_JSONL_TAIL_CACHE_V1011.get(cache_key)
    if isinstance(cached, dict) and cached.get("signature") == signature:
        rows = cached.get("rows")
        return rows if isinstance(rows, list) else []
    rows = read_jsonl(path, max_lines=max_lines)
    _PERSISTENT_JSONL_TAIL_CACHE_V1011[cache_key] = {"signature": signature, "rows": rows}
    return rows


def _file_size_signature_v1011(path: Path) -> tuple[int, int]:
    try:
        stat = path.stat()
        return int(stat.st_ino), int(stat.st_size)
    except OSError:
        return 0, 0


def _canonical_performance_semantic_v1011(snapshot: Any, nowv: float) -> tuple[Any, ...]:
    """Only immutable membership/error counters invalidate exact performance analysis.

    generated_at, file mtime and arbitrary time buckets are intentionally excluded.
    Window boundary refreshes are owned by the paper canonical snapshot writer.
    """
    obj = snapshot if isinstance(snapshot, dict) else {}
    counts = obj.get("counts") if isinstance(obj.get("counts"), dict) else {}
    windows = obj.get("window_counts") if isinstance(obj.get("window_counts"), dict) else {}
    return (
        str(obj.get("membership_digest") or ""),
        int(counts.get("exact_unique_closed") or 0),
        int(counts.get("duplicate_closed_rows") or 0),
        int(counts.get("missing_decision_key") or 0),
        int(counts.get("decision_not_closed_or_missing") or 0),
        int(windows.get("today") or 0),
        int(windows.get("recent_3h") or 0),
        int(windows.get("recent_6h") or 0),
        int(windows.get("recent_24h") or 0),
    )



def _runtime_memory_mb() -> tuple[float, float]:
    """Use the same /proc VmRSS source as guard audit so status and process RSS are comparable."""
    rss_mb = 0.0
    hwm_mb = 0.0
    try:
        for line in Path('/proc/self/status').read_text(encoding='utf-8', errors='ignore').splitlines():
            if line.startswith('VmRSS:'):
                rss_mb = float(line.split()[1]) / 1024.0
            elif line.startswith('VmHWM:'):
                hwm_mb = float(line.split()[1]) / 1024.0
    except Exception:
        pass
    if rss_mb <= 0:
        try:
            statm = Path('/proc/self/statm').read_text(encoding='utf-8', errors='ignore').split()
            if len(statm) >= 2:
                rss_mb = float(statm[1]) * float(os.sysconf('SC_PAGE_SIZE')) / 1048576.0
        except Exception:
            pass
    try:
        peak_raw = float(resource.getrusage(resource.RUSAGE_SELF).ru_maxrss)
        peak_mb = peak_raw / 1024.0 if peak_raw > 1024 else peak_raw / 1048576.0
    except Exception:
        peak_mb = rss_mb
    return round(rss_mb, 2), round(max(rss_mb, hwm_mb, peak_mb), 2)


def _release_cycle_memory() -> Dict[str, Any]:
    global _LAST_MEMORY_RECLAIM
    before, _peak = _runtime_memory_mb()
    _JSON_CYCLE_CACHE.clear()
    _JSONL_CYCLE_CACHE.clear()
    collected = gc.collect()
    trimmed = False
    try:
        libc = ctypes.CDLL("libc.so.6")
        trimmed = bool(libc.malloc_trim(0))
    except Exception:
        trimmed = False
    after, peak = _runtime_memory_mb()
    _LAST_MEMORY_RECLAIM = {
        "rss_before_mb": before, "rss_after_mb": after, "peak_rss_mb": peak,
        "gc_collected": int(collected), "malloc_trim": trimmed,
        "released_mb": round(max(0.0, before-after), 2),
    }
    return dict(_LAST_MEMORY_RECLAIM)


def set_review_phase(name: str) -> None:
    """Set active phase and take comparable RSS and /proc I/O boundary samples."""
    global _CURRENT_PHASE, _CURRENT_PHASE_STARTED_MONO, _CURRENT_PHASE_STARTED_TS, _LAST_RSS_SAMPLE, _CURRENT_PHASE_IO_START_V1011
    _CURRENT_PHASE = str(name or "unknown")
    _CURRENT_PHASE_STARTED_MONO = time.monotonic()
    _CURRENT_PHASE_STARTED_TS = time.time()
    _CURRENT_PHASE_IO_START_V1011 = _proc_io_counters_v1011()
    rss_mb, peak_mb = _runtime_memory_mb()
    previous = float(_PHASE_MEMORY_SAMPLES.get(_CURRENT_PHASE, 0.0))
    _PHASE_MEMORY_SAMPLES[_CURRENT_PHASE] = max(previous, rss_mb)
    _LAST_RSS_SAMPLE = {
        "rss_mb": rss_mb,
        "peak_rss_mb": peak_mb,
        "phase": _CURRENT_PHASE,
        "sample_ts": _CURRENT_PHASE_STARTED_TS,
    }


def _finish_review_phase_v1009(name: str, started_mono: float, timings: Dict[str, float]) -> None:
    """Close one phase with time, RSS, and physical/logical I/O deltas."""
    global _LAST_RSS_SAMPLE
    timings[name] = round(max(0.0, time.monotonic() - started_mono), 3)
    rss_mb, peak_mb = _runtime_memory_mb()
    _PHASE_MEMORY_SAMPLES[name] = max(float(_PHASE_MEMORY_SAMPLES.get(name, 0.0)), rss_mb)
    _LAST_RSS_SAMPLE = {'rss_mb': rss_mb, 'peak_rss_mb': peak_mb, 'phase': name, 'sample_ts': time.time()}
    end_io = _proc_io_counters_v1011()
    start_io = _CURRENT_PHASE_IO_START_V1011 if isinstance(_CURRENT_PHASE_IO_START_V1011, dict) else {}
    delta = {key: max(0, int(end_io.get(key, 0))-int(start_io.get(key, 0))) for key in ("read_bytes","write_bytes","rchar","wchar")}
    _PHASE_IO_SAMPLES_V1011[name] = {
        "read_mb": round(delta["read_bytes"]/1048576.0, 3),
        "write_mb": round(delta["write_bytes"]/1048576.0, 3),
        "logical_read_mb": round(delta["rchar"]/1048576.0, 3),
        "logical_write_mb": round(delta["wchar"]/1048576.0, 3),
    }


def _path_signature_v1009(path: Path) -> tuple[int, int, int]:
    try:
        st = path.stat()
        return int(st.st_ino), int(st.st_size), int(st.st_mtime_ns)
    except OSError:
        return 0, 0, 0


def _compact_phase_ref_v1009(obj: Any, *, count_keys: tuple[str, ...]=()) -> Dict[str, Any]:
    src = obj if isinstance(obj, dict) else {}
    out = {
        'schema': src.get('schema'), 'state': src.get('state'),
        'updated_ts': src.get('updated_ts'), 'version': src.get('version'),
    }
    for key in count_keys:
        if key in src:
            out[key] = src.get(key)
    return {k: v for k, v in out.items() if v not in (None, '', [], {})}

def write_status(state: str, **extra: Any) -> None:
    """Single Review status writer with explicit current-error lifecycle.

    Historical error text is preserved under last_error_* fields, while the
    current error is cleared only after a completed successful run_once.
    Generic heartbeats cannot resurrect a resolved error.
    """
    global _REVIEW_HEARTBEAT_SEQ, _LAST_RSS_SAMPLE
    clear_current_error_v1144 = bool(extra.pop('_clear_current_error_v1144', False))
    incoming_error_v1144 = extra.get('error')
    with _STATUS_WRITE_LOCK:
        _REVIEW_HEARTBEAT_SEQ += 1
        try:
            if STATUS.exists():
                with STATUS.open("r", encoding="utf-8", errors="ignore") as f:
                    prev = json.load(f)
            else:
                prev = {}
        except (OSError, ValueError, TypeError):
            prev = {}
        if not isinstance(prev, dict):
            prev = {}
        sample_ts = now_ts()
        rss_mb, peak_rss_mb = _runtime_memory_mb()
        _LAST_RSS_SAMPLE = {"rss_mb": rss_mb, "peak_rss_mb": peak_rss_mb, "phase": _CURRENT_PHASE, "sample_ts": sample_ts}
        payload = dict(prev)
        _lock_fh_v1123 = globals().get('_REVIEW_SINGLETON_FH_V1122')
        _lock_held_v1123 = bool(_lock_fh_v1123 is not None and not getattr(_lock_fh_v1123, 'closed', True))
        payload.update({
            "version": VERSION, "build": BUILD_LABEL, "state": state, "pid": os.getpid(),
            "active_owner": "review_worker_single_main", "writer_count": 1,
            "review_singleton_lock_pid_v1123": os.getpid() if _lock_held_v1123 else 0,
            "review_singleton_lock_held_v1123": _lock_held_v1123,
            "review_singleton_lock_path_v1123": str(globals().get('REVIEW_SINGLETON_LOCK_V1122') or ''),
            "rss_mb": rss_mb, "proc_rss_mb": rss_mb, "proc_rss_mb_v1008": rss_mb,
            "peak_rss_mb": peak_rss_mb, "rss_sample_ts": sample_ts,
            "rss_sample_text": now_text(sample_ts), "rss_sample_phase": _CURRENT_PHASE,
            "heartbeat_seq": _REVIEW_HEARTBEAT_SEQ,
            "phase": _CURRENT_PHASE,
            "phase_started_ts_v1008": _CURRENT_PHASE_STARTED_TS,
            "phase_elapsed_sec_v1008": round(max(0.0, time.monotonic()-_CURRENT_PHASE_STARTED_MONO), 3),
            "updated_ts": sample_ts, "updated_text": now_text(sample_ts),
        })
        if _LAST_COMPLETED_PHASE_TIMINGS:
            payload["phase_timings_sec"] = dict(_LAST_COMPLETED_PHASE_TIMINGS)
            payload["phase_top"] = sorted(_LAST_COMPLETED_PHASE_TIMINGS.items(), key=lambda x:x[1], reverse=True)[:5]
        if _PHASE_MEMORY_SAMPLES:
            payload["phase_memory_mb"] = dict(_PHASE_MEMORY_SAMPLES)
            payload["phase_memory_top"] = sorted(_PHASE_MEMORY_SAMPLES.items(), key=lambda x:x[1], reverse=True)[:5]
        if _LAST_MEMORY_RECLAIM:
            payload["memory_reclaim_v1008"] = dict(_LAST_MEMORY_RECLAIM)
        if _PHASE_IO_SAMPLES_V1011:
            payload["phase_io_mb_v1011"] = {key: dict(value) for key, value in _PHASE_IO_SAMPLES_V1011.items()}
            payload["phase_io_top_v1011"] = sorted(
                ((name, round(float(item.get("read_mb",0.0))+float(item.get("write_mb",0.0)),3))
                 for name,item in _PHASE_IO_SAMPLES_V1011.items()),
                key=lambda pair: pair[1], reverse=True
            )[:5]
        payload.update(extra)
        if incoming_error_v1144:
            err_text_v1144 = str(incoming_error_v1144)
            same_active_v1144 = bool(payload.get('current_error_active_v1144')) and str(payload.get('current_error_v1144') or '')==err_text_v1144
            payload['current_error_active_v1144'] = True
            payload['current_error_v1144'] = err_text_v1144
            if not same_active_v1144:
                payload['current_error_started_ts_v1144'] = sample_ts
            payload['last_error_text_v1144'] = err_text_v1144
            payload['last_error_ts_v1144'] = sample_ts
        elif clear_current_error_v1144:
            historical_error_v1144 = payload.get('current_error_v1144') or payload.get('error')
            if historical_error_v1144:
                payload['last_error_text_v1144'] = str(historical_error_v1144)
                payload['last_error_ts_v1144'] = sample_ts
            payload.pop('error', None)
            payload['current_error_active_v1144'] = False
            payload['current_error_v1144'] = None
            payload['current_error_cleared_ts_v1144'] = sample_ts
        save_json(STATUS, payload)

def _review_heartbeat_loop_v1008() -> None:
    while not _HEARTBEAT_STOP.wait(max(3.0, min(10.0, HEARTBEAT_SEC))):
        try:
            write_status('running', live_heartbeat_v1007=True)
        except Exception as exc:
            append_error(ERROR, 'heartbeat_v1008', exc)

def profit(row: Dict[str, Any]) -> float:
    return fnum(row.get("profit_pct"), row.get("return_pct"), row.get("pnl_pct"), row.get("profit_rate"), default=0.0)

def _current_price(ticker: str, fmap: Dict[str, Dict[str, Any]], ofmap: Dict[str, Dict[str, Any]]) -> float:
    f = fmap.get(ticker, {}) or {}
    o = ofmap.get(ticker, {}) or {}
    return fnum(o.get("quote_price"), o.get("current_price"), o.get("price"), f.get("current_price"), f.get("price"), f.get("last_price"), f.get("close"), default=0.0)

STRUCTURE_REVIEW_PRICE_TTL_SEC = float(os.environ.get('STRUCTURE_REVIEW_PRICE_TTL_SEC', '45'))


def _review_path_age(path: Path, nowv: float) -> Optional[float]:
    try:
        return max(0.0, nowv - path.stat().st_mtime)
    except OSError:
        return None


def _review_row_age(row: Dict[str,Any], path: Path, nowv: float) -> tuple[Optional[float],str]:
    for key in ('quote_age_sec','micro_age_sec','orderflow_age_sec','price_age_sec','feature_age_sec','age_sec'):
        raw=row.get(key)
        if raw in (None,''): continue
        try: age=float(str(raw).replace(',',''))
        except Exception: continue
        if math.isfinite(age) and 0<=age<999998: return age,key
    for key in ('updated_ts','quote_ts','price_ts','last_update_ts','timestamp','ts'):
        raw=row.get(key)
        if raw in (None,''): continue
        try: ts=float(str(raw).replace(',',''))
        except Exception: continue
        if ts>1e12: ts/=1000.0
        if ts>1e9 and math.isfinite(ts): return max(0.0,nowv-ts),key
    age=_review_path_age(path,nowv)
    return age,'file_mtime' if age is not None else ''


def _structure_review_price_state(ticker: str, fmap: Dict[str,Dict[str,Any]], ofmap: Dict[str,Dict[str,Any]], nowv: float) -> Dict[str,Any]:
    f=fmap.get(ticker,{}) or {}; o=ofmap.get(ticker,{}) or {}
    choices=[]
    op=fnum(o.get('quote_price'),o.get('current_price'),o.get('price'),default=0.0)
    oa,osrc=_review_row_age(o,ORDERFLOW,nowv)
    if op>0: choices.append(('orderflow',op,oa,osrc))
    fp=fnum(f.get('current_price'),f.get('price'),f.get('last_price'),f.get('close'),default=0.0)
    fa,fsrc=_review_row_age(f,FEATURE,nowv)
    if fp>0: choices.append(('feature',fp,fa,fsrc))
    for source,price,age,age_source in choices:
        if age is not None and age<=STRUCTURE_REVIEW_PRICE_TTL_SEC:
            return {'fresh':True,'price':price,'source':source,'age_sec':round(age,3),'age_source':age_source,'ttl_sec':STRUCTURE_REVIEW_PRICE_TTL_SEC,'reason':None}
    best=min(choices,key=lambda x:x[2] if x[2] is not None else 1e18) if choices else None
    return {'fresh':False,'price':0.0,'source':best[0] if best else None,'age_sec':round(best[2],3) if best and best[2] is not None else None,'age_source':best[3] if best else None,'ttl_sec':STRUCTURE_REVIEW_PRICE_TTL_SEC,'reason':'review_price_stale_or_missing'}

def _pct(cur: float, base: float) -> float:
    return round((cur - base) / base * 100.0, 3) if cur and base else 0.0

def _risk_profile(rec: Dict[str, Any]) -> Dict[str, Any]:
    """결과만 오른 위험 후보와 진짜 놓친 후보를 분리하기 위한 표시용 판정.
    조건/S1/S2/S3 기준은 바꾸지 않고 review 분류만 정리한다.
    """
    m = rec.get("metrics") if isinstance(rec.get("metrics"), dict) else {}
    spread = fnum(m.get("spread_pct"), default=0.0)
    slip = fnum(m.get("slippage_pct"), default=0.0)
    buy = fnum(m.get("buy_ratio"), default=0.0)
    sustain = fnum(m.get("buy_sustain_1m"), default=0.0)
    cur_pct = fnum(rec.get("current_pct"), default=0.0)
    reasons = " / ".join(str(x) for x in (rec.get("block_reasons") or []) if str(x).strip())
    risk: List[str] = []
    mild: List[str] = []
    if spread >= 0.30: risk.append(f"스프레드 {spread:.2f}%")
    elif spread >= 0.20: mild.append(f"스프레드 {spread:.2f}%")
    if slip >= 0.30: risk.append(f"미끄러짐 {slip:.2f}%")
    elif slip >= 0.20: mild.append(f"미끄러짐 {slip:.2f}%")
    if buy and buy < 0.55: risk.append(f"매수체결 {buy:.2f}")
    elif buy and buy < 0.68: mild.append(f"매수체결 {buy:.2f}")
    if sustain and sustain < 0.55: risk.append(f"1분지속 {sustain:.2f}")
    elif sustain and sustain < 0.64: mild.append(f"1분지속 {sustain:.2f}")
    for word in ("매도벽", "매도압력", "EMA5 아래", "추세 부담"):
        if word in reasons:
            risk.append(word)
    if cur_pct <= -1.00:
        risk.append(f"현재 되돌림 {cur_pct:+.2f}%")
    return {"risk": risk, "mild": mild, "is_high_risk": bool(risk), "risk_note": " / ".join(risk[:4]) if risk else (" / ".join(mild[:4]) if mild else "위험 낮음")}

def _sample_pct(rec: Dict[str, Any], label: str) -> Optional[float]:
    # label: 5m/10m/20m. direct value가 없으면 samples[label].pct를 본다.
    key = f"after_{label}_pct"
    v = rec.get(key)
    if v not in (None, ""):
        return fnum(v, default=0.0)
    samples = rec.get("samples") if isinstance(rec.get("samples"), dict) else {}
    sample = samples.get(label) if isinstance(samples.get(label), dict) else {}
    if sample.get("pct") not in (None, ""):
        return fnum(sample.get("pct"), default=0.0)
    return None

def _timing_profile(rec: Dict[str, Any]) -> Dict[str, Any]:
    """v457: 최고수익 착시를 분리한다.
    S1 완화/승격 근거는 5/10/20분 안에 오른 후보만 쓰기 위함이다.
    """
    a5 = _sample_pct(rec, "5m")
    a10 = _sample_pct(rec, "10m")
    a20 = _sample_pct(rec, "20m")
    vals = {"5m": a5, "10m": a10, "20m": a20}
    # 초반에 명확히 간 후보만 진짜놓침 근거로 둔다.
    early_hit = (a5 is not None and a5 >= 0.30) or (a10 is not None and a10 >= 0.50) or (a20 is not None and a20 >= 0.70)
    mild_hit = (a5 is not None and a5 >= 0.10) or (a10 is not None and a10 >= 0.20) or (a20 is not None and a20 >= 0.30)
    sample_ready = any(v is not None for v in vals.values())
    note = " / ".join(f"{k} {v:+.2f}%" for k, v in vals.items() if v is not None) or "시간표 부족"
    return {"early_hit": early_hit, "mild_hit": mild_hit, "sample_ready": sample_ready, "note": note, "samples": vals}

def _decision(rec: Dict[str, Any], elapsed: float) -> str:
    max_pct = fnum(rec.get("max_pct"), default=0.0)
    cur_pct = fnum(rec.get("current_pct"), default=0.0)
    rp = _risk_profile(rec)
    tp = _timing_profile(rec)
    rec["risk_reasons"] = rp.get("risk", [])
    rec["risk_note"] = rp.get("risk_note", "")
    rec["timing_note"] = tp.get("note", "")
    rec["timing_samples"] = tp.get("samples", {})
    if max_pct >= 1.20:
        if rp.get("is_high_risk"):
            rec["timing_class"] = "위험상승"
            return "🔥 결과만 오른 위험 후보"
        if tp.get("early_hit"):
            rec["timing_class"] = "초반상승"
            return "❌ 진짜 놓친 후보"
        # 최고수익만 큰 후보는 S1 완화 근거로 쓰지 않는다.
        rec["timing_class"] = "늦게오름"
        return "⏳ 늦게 오른 후보"
    if max_pct >= 0.70:
        if rp.get("is_high_risk"):
            rec["timing_class"] = "위험상승"
            return "🔥 결과만 오른 위험 후보"
        if tp.get("mild_hit"):
            rec["timing_class"] = "아까움"
            return "⚠️ 아까운 후보"
        rec["timing_class"] = "늦게오름"
        return "⏳ 늦게 오른 후보"
    if elapsed >= 1200 and max_pct < 0.30:
        rec["timing_class"] = "초반무반응"
        return "✅ 안 산 게 맞음"
    if elapsed >= 300 and cur_pct <= -0.30 and max_pct < 0.50:
        rec["timing_class"] = "빠른약세"
        return "✅ 안 산 게 맞음"
    rec["timing_class"] = "추적중"
    return "❔ 추적중"

def _short_reasons(rec: Dict[str, Any]) -> str:
    reasons = rec.get("block_reasons") if isinstance(rec.get("block_reasons"), list) else []
    missing = rec.get("missing_info") if isinstance(rec.get("missing_info"), list) else []
    arr = [str(x) for x in (reasons + missing) if str(x).strip()]
    return " / ".join(arr[:3]) if arr else "-"


def _has_structure(rec: Dict[str, Any]) -> bool:
    if not isinstance(rec, dict):
        return False
    tags = rec.get("structure_tags")
    risk = rec.get("structure_risk_tags")
    fit = rec.get("structure_fit")
    return (isinstance(tags, list) and bool(tags)) or (isinstance(risk, list) and bool(risk)) or bool(str(fit or "").strip())

def _copy_structure(dst: Dict[str, Any], src: Dict[str, Any]) -> bool:
    if not isinstance(dst, dict) or not isinstance(src, dict) or not _has_structure(src):
        return False
    st = src.get("chart_structure") if isinstance(src.get("chart_structure"), dict) else {}
    dst["structure_tags"] = src.get("structure_tags") if isinstance(src.get("structure_tags"), list) else st.get("tags", [])
    dst["structure_good_tags"] = src.get("structure_good_tags") if isinstance(src.get("structure_good_tags"), list) else st.get("good_tags", [])
    dst["structure_risk_tags"] = src.get("structure_risk_tags") if isinstance(src.get("structure_risk_tags"), list) else st.get("risk_tags", [])
    dst["structure_fit"] = str(src.get("structure_fit") or st.get("strategy_fit") or "")
    dst["structure_summary"] = str(src.get("structure_summary") or st.get("summary") or "")
    dst["chart_structure"] = st
    dst["structure_source"] = "candidate_snapshot"
    return True


def _has_market(rec: Dict[str, Any]) -> bool:
    return isinstance(rec, dict) and (isinstance(rec.get("market_regime_tags"), list) and bool(rec.get("market_regime_tags")) or bool(str(rec.get("market_regime_summary") or "").strip()))

def _copy_market(dst: Dict[str, Any], src: Dict[str, Any]) -> bool:
    if not isinstance(dst, dict) or not isinstance(src, dict) or not _has_market(src):
        return False
    mr = src.get("market_regime") if isinstance(src.get("market_regime"), dict) else {}
    dst["market_regime_tags"] = src.get("market_regime_tags") if isinstance(src.get("market_regime_tags"), list) else mr.get("tags", [])
    dst["market_risk_tags"] = src.get("market_risk_tags") if isinstance(src.get("market_risk_tags"), list) else mr.get("risk_tags", [])
    dst["market_regime_summary"] = str(src.get("market_regime_summary") or mr.get("summary") or "")
    dst["market_regime"] = mr
    dst["market_source"] = "candidate_snapshot"
    return True

def _derive_market_from_rec(rec: Dict[str, Any], fmap: Dict[str, Dict[str, Any]], ofmap: Dict[str, Dict[str, Any]], regime: Dict[str, Any]) -> Dict[str, Any]:
    t = ticker_norm(rec.get("ticker"))
    row = fmap.get(t, {}) if t else {}
    of = ofmap.get(t, {}) if t else {}
    tags: List[str] = []
    risks: List[str] = []
    mode = str((regime or {}).get("market_mode") or (regime or {}).get("mode") or row.get("market_mode") or of.get("market_mode") or "")
    def add(arr: List[str], x: str) -> None:
        if x and x not in arr:
            arr.append(x)
    if "강" in mode:
        add(tags, "시장강함")
    elif "약" in mode:
        add(tags, "시장약함")
    elif mode:
        add(tags, "시장보통")
    else:
        add(tags, "장세정보부족")
    pressure = str((regime or {}).get("market_pressure") or row.get("market_pressure") or of.get("market_pressure") or "")
    if "급락" in mode or "급락" in pressure:
        add(risks, "시장급락위험")
    if "과열" in mode or "과열" in pressure:
        add(risks, "시장과열")
    if "횡보" in mode or "횡보" in pressure:
        add(tags, "시장횡보")
    return {"schema":"market_regime_tags_v447_review_only", "tags":tags[:8], "risk_tags":risks[:6], "summary":(", ".join(tags[:3]) if tags else "-") + (" / 위험 " + ", ".join(risks[:2]) if risks else "")}

def _ensure_market(rec: Dict[str, Any], sources: Dict[str, Dict[str, Any]], fmap: Dict[str, Dict[str, Any]], ofmap: Dict[str, Dict[str, Any]], regime: Dict[str, Any]) -> None:
    if not isinstance(rec, dict) or _has_market(rec):
        return
    t = ticker_norm(rec.get("ticker"))
    if t and _copy_market(rec, sources.get(t, {}) or {}):
        return
    mt = _derive_market_from_rec(rec, fmap, ofmap, regime)
    rec["market_regime"] = mt
    rec["market_regime_tags"] = mt.get("tags", [])
    rec["market_risk_tags"] = mt.get("risk_tags", [])
    rec["market_regime_summary"] = mt.get("summary", "")
    rec["market_source"] = "review_derived_display"

def _unique(items: List[str]) -> List[str]:
    out: List[str] = []
    for x in items:
        t = str(x or "").strip()
        if t and t not in out:
            out.append(t)
    return out

def _derive_structure_from_rec(rec: Dict[str, Any]) -> Dict[str, Any]:
    """기존 active review state처럼 구조태그가 없던 기록에 붙이는 표시용 보강.
    후보 차단·S1 승격·청산에는 쓰지 않는다.
    """
    text = " / ".join(str(x) for x in (rec.get("block_reasons") or []) if str(x).strip())
    strat = str(rec.get("strategy") or rec.get("strategy_key") or "")
    m = rec.get("metrics") if isinstance(rec.get("metrics"), dict) else {}
    spread = fnum(m.get("spread_pct"), default=0.0)
    slip = fnum(m.get("slippage_pct"), default=0.0)
    buy = fnum(m.get("buy_ratio"), default=0.0)
    cur = fnum(rec.get("current_pct"), default=0.0)
    maxp = fnum(rec.get("max_pct"), default=0.0)
    tags: List[str] = []
    risks: List[str] = []

    if "돈흐름" in strat or "reaccel" in strat:
        tags += ["눌림후재가속", "돈흐름재유입"]
        if "VWAP" not in text and "EMA" not in text:
            tags.append("VWAP방어")
    if "돌파" in strat or "breakout" in strat:
        tags += ["저항돌파", "저항돌파후재테스트"]
        if "돌파 후" in text or "돌파선" in text:
            tags.append("지지전환확인")
    if "저점" in strat or "VWAP 회복" in strat or "sweep" in strat:
        tags += ["저점유동성쓸림", "쓸림후빠른회복", "VWAP재회복"]
    if "주도흐름" in strat or "유동보유" in strat or "adaptive_hold" in strat:
        tags += ["얕은눌림", "VWAP방어", "EMA방어", "상대강도유지"]
    if "주도추세" in strat or "momentum" in strat:
        tags += ["고점저점상승", "추세지속", "채널하단방어"]
    if "급등" in strat or "재돌파" in strat or "rebreak" in strat:
        tags += ["급등후눌림", "고점재돌파", "돈흐름재유입"]

    if "고점권" in text and "가격반응" in text:
        risks.append("고점권가격반응약함")
    if "스프레드" in text or spread >= 0.30:
        risks.append("스프레드부담")
    if "미끄" in text or slip >= 0.30:
        risks.append("미끄러짐부담")
    if "매도벽" in text or "매도압력" in text:
        risks.append("매도압력부담")
    if "돌파 후" in text and "부족" in text:
        risks.append("가짜돌파위험")
    if cur <= -1.0 or (maxp >= 1.2 and cur < 0):
        risks.append("되돌림위험")
    if buy and buy < 0.55:
        risks.append("매수체결약함")

    if not tags:
        tags = ["구조정보부족"]
    tags = _unique(tags)[:10]
    risks = _unique(risks)[:8]
    fit = "구조좋음" if tags and tags != ["구조정보부족"] else "구조정보부족"
    severe = any(x in risks for x in ["스프레드부담", "미끄러짐부담", "매도압력부담", "되돌림위험", "매수체결약함", "가짜돌파위험"])
    if risks and fit == "구조좋음":
        fit = "구조좋음 · 위험동반" if severe else "구조관찰"
    elif risks:
        fit = "구조위험"
    return {
        "schema": "review_structure_derived_display_v447",
        "tags": tags,
        "good_tags": [t for t in tags if t != "구조정보부족"],
        "risk_tags": risks,
        "strategy_fit": fit,
        "summary": f"{fit} · 좋음 {', '.join(tags[:3]) if tags else '-'} / 위험 {', '.join(risks[:3]) if risks else '-'}",
    }

def _ensure_structure(rec: Dict[str, Any], sources: Dict[str, Dict[str, Any]]) -> None:
    if not isinstance(rec, dict) or _has_structure(rec):
        return
    t = ticker_norm(rec.get("ticker"))
    if t and _copy_structure(rec, sources.get(t, {}) or {}):
        return
    st = _derive_structure_from_rec(rec)
    rec["chart_structure"] = st
    rec["structure_tags"] = st.get("tags", [])
    rec["structure_good_tags"] = st.get("good_tags", [])
    rec["structure_risk_tags"] = st.get("risk_tags", [])
    rec["structure_fit"] = st.get("strategy_fit", "")
    rec["structure_summary"] = st.get("summary", "")
    rec["structure_source"] = "review_derived_display"

def _summ_rows(rows: List[Dict[str, Any]], limit: int = 8) -> List[Dict[str, Any]]:
    rows = sorted(rows, key=lambda r: (fnum(r.get("max_pct"), default=0.0), fnum(r.get("score"), default=0.0)), reverse=True)
    out = []
    for r in rows[:limit]:
        out.append({
            "ticker": r.get("ticker"), "stage": r.get("stage"), "strategy": r.get("strategy"),
            "score": r.get("score"), "decision": r.get("decision"),
            "first_price": r.get("first_price"), "current_price": r.get("current_price"),
            "current_pct": r.get("current_pct"), "max_pct": r.get("max_pct"),
            "after_5m_pct": r.get("after_5m_pct"), "after_10m_pct": r.get("after_10m_pct"), "after_20m_pct": r.get("after_20m_pct"),
            "first_seen_ts": r.get("first_seen_ts"), "first_seen_text": r.get("first_seen_text"),
            "last_seen_ts": r.get("last_seen_ts"), "last_seen_text": r.get("last_seen_text"),
            "max_seen_ts": r.get("max_seen_ts"), "max_seen_text": r.get("max_seen_text"),
            "reasons": _short_reasons(r),
            "risk_note": r.get("risk_note", ""),
            "risk_reasons": r.get("risk_reasons", []),
            "structure_tags": r.get("structure_tags", []),
            "structure_good_tags": r.get("structure_good_tags", []),
            "structure_risk_tags": r.get("structure_risk_tags", []),
            "structure_fit": r.get("structure_fit", ""),
            "structure_summary": r.get("structure_summary", ""),
            "chart_structure": r.get("chart_structure", {}),
            "market_regime_tags": r.get("market_regime_tags", []),
            "market_risk_tags": r.get("market_risk_tags", []),
            "market_regime_summary": r.get("market_regime_summary", ""),
            "market_regime": r.get("market_regime", {}),
            "review_class": r.get("decision", ""),
            "timing_class": r.get("timing_class", ""),
            "timing_note": r.get("timing_note", ""),
            "timing_samples": r.get("timing_samples", {}),
        })
    return out

def _reason_top(rows: List[Dict[str, Any]], limit: int = 8) -> List[Dict[str, Any]]:
    cnt: Dict[str, int] = {}
    for r in rows:
        for x in (r.get("block_reasons") or []):
            key = str(x).split()[0].strip() or str(x).strip()
            if key: cnt[key] = cnt.get(key, 0) + 1
    return [{"reason": k, "count": v} for k, v in sorted(cnt.items(), key=lambda kv: kv[1], reverse=True)[:limit]]

def _close_item_from_trade(r: Dict[str, Any], tag: str, give: float, sources: Dict[str, Dict[str, Any]], fmap: Dict[str, Dict[str, Any]], ofmap: Dict[str, Dict[str, Any]], regime: Dict[str, Any]) -> Dict[str, Any]:
    item = {"ticker": ticker_norm(r.get("ticker")), "peak_pct": fnum(r.get("peak_pct"), r.get("max_profit_pct"), default=0.0), "pnl_pct": fnum(r.get("pnl_pct"), r.get("profit_pct"), default=0.0), "giveback_pct": round(give,3), "reason": r.get("exit_reason"), "tag": r.get("close_review_tag") or tag}
    # closed row 자체의 entry_context/snapshot 구조를 우선 복사하고, 없으면 현재 후보 snapshot 또는 표시용 파생값을 붙인다.
    ctx = r.get("entry_context") if isinstance(r.get("entry_context"), dict) else {}
    snap = r.get("entry_snapshot") if isinstance(r.get("entry_snapshot"), dict) else {}
    flat = snap.get("flat") if isinstance(snap.get("flat"), dict) else {}
    src = dict(r)
    for k in ("chart_structure", "structure_tags", "structure_good_tags", "structure_risk_tags", "structure_fit", "structure_summary", "market_regime", "market_regime_tags", "market_risk_tags", "market_regime_summary"):
        if k not in src and k in ctx: src[k] = ctx[k]
        if k not in src and k in flat: src[k] = flat[k]
    if _has_structure(src):
        _copy_structure(item, src)
    else:
        t = ticker_norm(item.get("ticker"))
        if t:
            _copy_structure(item, sources.get(t, {}) or {})
        _ensure_structure(item, sources)
    if _has_market(src):
        _copy_market(item, src)
    else:
        t = ticker_norm(item.get("ticker"))
        if t:
            _copy_market(item, sources.get(t, {}) or {})
        _ensure_market(item, sources, fmap, ofmap, regime)
    return item


def _legacy_closed_summary(sources: Optional[Dict[str, Dict[str, Any]]]=None, fmap: Optional[Dict[str, Dict[str, Any]]]=None, ofmap: Optional[Dict[str, Dict[str, Any]]]=None, regime: Optional[Dict[str, Any]]=None, closed_rows: Optional[List[Dict[str, Any]]]=None) -> Dict[str, Any]:
    sources = sources or {}; fmap = fmap or {}; ofmap = ofmap or {}; regime = regime or {}
    rows = [r for r in (closed_rows if closed_rows is not None else read_jsonl(CLOSED, max_lines=360)) if isinstance(r, dict)]
    def pnl(row: Dict[str, Any]) -> float: return fnum(row.get('pnl_pct'), row.get('profit_pct'), default=0.0)
    def peak(row: Dict[str, Any]) -> float: return fnum(row.get('peak_pct'), row.get('max_profit_pct'), default=0.0)
    protect_needed=[]; fast_fail=[]; good_keep=[]
    for row in rows[-80:]:
        pk=peak(row); pn=pnl(row); give=max(0.0, pk-pn)
        if pk >= 0.70 and (pn < 0 or give >= 0.55):
            protect_needed.append(_close_item_from_trade(row, '보호익절 필요 후보', give, sources, fmap, ofmap, regime))
        elif pn <= -0.60 and pk < 0.25:
            fast_fail.append(_close_item_from_trade(row, '빠른실패 정리 후보', give, sources, fmap, ofmap, regime))
        elif pn > 0 and pk-pn <= 0.35:
            good_keep.append(_close_item_from_trade(row, '수익 보존 양호', give, sources, fmap, ofmap, regime))
    big_loss = heapq.nsmallest(10, (row for row in rows if profit(row) <= -0.8), key=profit)
    good_win = heapq.nlargest(10, (row for row in rows if profit(row) >= 1.0), key=profit)
    return {'closed_recent':len(rows),'big_loss':len(big_loss),'good_win':len(good_win),'close_review':{'protect_needed_count':len(protect_needed),'fast_fail_count':len(fast_fail),'good_keep_count':len(good_keep),'protect_needed':protect_needed[-5:],'fast_fail':fast_fail[-5:],'good_keep':good_keep[-5:]}}




# v655: review_worker는 후보판단/장부 주인이 아니라 복기 요약 주인이다.
# paper CLOSED 장부는 삭제하지 않고, active missed-review state에서 의미 낮은 추적만 빨리 순환한다.
def _v655_keep_active_review(rec: Dict[str, Any], nowv: float, base_ttl: float) -> bool:
    if not isinstance(rec, dict):
        return False
    first = fnum(rec.get("first_seen_ts"), default=nowv)
    age = max(0.0, nowv - first)
    cls = str(rec.get("decision") or rec.get("review_class") or rec.get("review_hint") or "")
    maxp = fnum(rec.get("max_pct"), default=0.0)
    curp = fnum(rec.get("current_pct"), default=0.0)
    # 중요한 복기 후보는 기존 보관기한 유지.
    if any(w in cls for w in ("진짜 놓친", "아까운", "위험 후보", "위험상승")):
        return age <= base_ttl
    # 늦게 오른 후보/큰 변동 후보는 전략 보정 참고용으로 몇 시간만 유지.
    if "늦게 오른" in cls or maxp >= 0.70 or abs(curp) >= 1.00:
        return age <= min(base_ttl, 6 * 3600.0)
    # 추적중/안 산 게 맞음은 디스크·CPU를 잡아먹지 않게 짧게 순환.
    if "추적중" in cls or not cls:
        return age <= min(base_ttl, 90 * 60.0)
    if "안 산 게 맞음" in cls:
        return age <= min(base_ttl, 45 * 60.0)
    return age <= min(base_ttl, 2 * 3600.0)



def _v664_prune_active_size(active: Dict[str, Dict[str, Any]], nowv: float, max_keep: int = ACTIVE_REVIEW_MAX) -> Dict[str, Dict[str, Any]]:
    """v664: active missed-review state 크기 제한.
    paper CLOSED 장부는 손대지 않고, 상태 추적용 active dict만 핵심/최근 후보 위주로 유지한다.
    """
    if not isinstance(active, dict) or len(active) <= max_keep:
        return active
    important_words = ("진짜 놓친", "아까운", "위험 후보", "위험상승", "늦게 오른")
    rows = []
    for k, v in active.items():
        if not isinstance(v, dict):
            continue
        cls = str(v.get('decision') or v.get('review_class') or v.get('review_hint') or '')
        imp = 1 if any(w in cls for w in important_words) else 0
        maxp = fnum(v.get('max_pct'), default=0.0)
        curp = abs(fnum(v.get('current_pct'), default=0.0))
        last = fnum(v.get('last_seen_ts'), v.get('first_seen_ts'), default=0.0)
        score = imp * 1000000.0 + maxp * 1000.0 + curp * 300.0 + last / 100000.0
        rows.append((score, k, v))
    rows.sort(key=lambda x: x[0], reverse=True)
    kept = {k: v for _, k, v in rows[:max_keep]}
    return kept


# =============================================================================
# review_worker v0.14 / v665: trigger shadow benchmark 추적
# - strategy_worker가 만든 shadow 후보를 읽어 이후 가격 경로를 비교한다.
# - 실제 paper OPEN/장부/청산은 바꾸지 않는다.
# =============================================================================

def _v665_variant_key(c: Dict[str, Any], variant: Dict[str, Any]) -> str:
    return '|'.join(str(x or '-') for x in (c.get('shadow_key_base'), variant.get('key')))



def _v678_trigger_shadow_score(rec: Dict[str, Any], nowv: float) -> float:
    try:
        entered = 1 if bool(rec.get('entered')) else 0
        maxp = fnum(rec.get('max_pct'), default=0.0)
        curp = abs(fnum(rec.get('current_pct'), default=0.0))
        last = fnum(rec.get('last_seen_ts'), rec.get('first_seen_ts'), default=nowv)
        sampled = len(rec.get('samples') if isinstance(rec.get('samples'), dict) else {})
        return entered * 1000000.0 + sampled * 200000.0 + maxp * 1000.0 + curp * 200.0 + last / 100000.0
    except Exception:
        return 0.0


def _v678_prune_trigger_shadow_active(active: Dict[str, Dict[str, Any]], nowv: float) -> Dict[str, Dict[str, Any]]:
    """trigger shadow는 검증용 state라 오래 들고 있지 않는다. touched라고 TTL을 무시하지 않는다."""
    ttl_entered = max(600.0, TRIGGER_SHADOW_ENTERED_TTL_SEC)
    ttl_pending = max(300.0, TRIGGER_SHADOW_PENDING_TTL_SEC)
    max_keep = max(100, TRIGGER_SHADOW_ACTIVE_MAX)
    kept = {}
    for k, rec in (active or {}).items():
        if not isinstance(rec, dict):
            continue
        first = fnum(rec.get('first_seen_ts'), default=nowv)
        age = max(0.0, nowv - first)
        entered = bool(rec.get('entered'))
        if entered and age <= ttl_entered:
            kept[k] = rec
        elif (not entered) and age <= ttl_pending:
            kept[k] = rec
    if len(kept) <= max_keep:
        return kept
    ranked = sorted(kept.items(), key=lambda kv: _v678_trigger_shadow_score(kv[1], nowv), reverse=True)
    return {k: v for k, v in ranked[:max_keep]}

def _v665_trigger_shadow_update(nowv: float, fmap: Dict[str, Dict[str, Any]], ofmap: Dict[str, Dict[str, Any]]) -> Dict[str, Any]:
    cand_obj = load_json(TRIGGER_SHADOW_CANDIDATES, {}) or {}
    candidates = cand_obj.get('rows') if isinstance(cand_obj, dict) and isinstance(cand_obj.get('rows'), list) else []
    state_obj = load_json(TRIGGER_SHADOW_STATE, {}) or {}
    active = state_obj.get('active') if isinstance(state_obj, dict) and isinstance(state_obj.get('active'), dict) else {}
    touched = set()
    # 기존 state 정리 TTL: 미진입 30분, 진입 40분 이후 요약만 남김
    for c in candidates:
        if not isinstance(c, dict):
            continue
        t = ticker_norm(c.get('ticker'))
        if not t:
            continue
        cur = _current_price(t, fmap, ofmap)
        if not cur:
            cur = fnum(c.get('current_price'), default=0.0)
        for var in c.get('variants') or []:
            if not isinstance(var, dict):
                continue
            k = _v665_variant_key(c, var)
            touched.add(k)
            threshold = fnum(var.get('threshold_price'), default=0.0)
            rec = active.get(k) if isinstance(active.get(k), dict) else None
            if not rec:
                rec = {
                    'schema': 'trigger_shadow_variant_state_v665',
                    'key': k,
                    'ticker': t,
                    'variant': var.get('key'),
                    'variant_label': var.get('label'),
                    'entry_mode': var.get('entry_mode'),
                    'threshold_price': threshold,
                    'first_seen_ts': nowv,
                    'first_seen_text': now_text(nowv),
                    'source': c.get('trigger_source'),
                    'stage': c.get('stage'),
                    'coin_quality_score': c.get('coin_quality_score'),
                    'trigger_price': c.get('trigger_price'),
                    'trigger_gap_pct': c.get('trigger_gap_pct'),
                    'entered': False,
                    'samples': {},
                    'max_pct': 0.0,
                    'min_pct': 0.0,
                    'policy': 'v665 shadow only. 실제 주문/장부 변경 없음.',
                }
            rec['last_seen_ts'] = nowv
            rec['last_seen_text'] = now_text(nowv)
            rec['latest_price'] = cur
            # 진입 판정: immediate는 첫 가격, threshold는 해당 가격 이상 도달 시 가상진입.
            if not rec.get('entered') and cur:
                if str(var.get('entry_mode')) == 'immediate' or (threshold and cur >= threshold):
                    rec['entered'] = True
                    rec['entry_ts'] = nowv
                    rec['entry_text'] = now_text(nowv)
                    rec['entry_price'] = cur
                    rec['entry_reason'] = 'immediate_current' if str(var.get('entry_mode')) == 'immediate' else 'threshold_reached'
            if rec.get('entered') and cur:
                entry = fnum(rec.get('entry_price'), default=0.0)
                pct = _pct(cur, entry)
                rec['current_pct'] = pct
                rec['max_pct'] = max(fnum(rec.get('max_pct'), default=pct), pct)
                rec['min_pct'] = min(fnum(rec.get('min_pct'), default=pct), pct)
                elapsed = max(0.0, nowv - fnum(rec.get('entry_ts'), default=nowv))
                samples = rec.get('samples') if isinstance(rec.get('samples'), dict) else {}
                for label, sec in (('3m',180),('5m',300),('10m',600),('20m',1200)):
                    if elapsed >= sec and label not in samples:
                        samples[label] = {'ts': nowv, 'text': now_text(nowv), 'price': cur, 'pct': pct, 'max_pct': rec.get('max_pct'), 'min_pct': rec.get('min_pct')}
                rec['samples'] = samples
            else:
                wait = max(0.0, nowv - fnum(rec.get('first_seen_ts'), default=nowv))
                rec['wait_sec'] = round(wait, 1)
                if wait >= 1200:
                    rec['not_entered_timeout'] = True
            active[k] = rec
    # v678 active pruning owner
    # 이전 구경로는 k in touched면 TTL을 넘어도 계속 살려 active가 수천 개로 누적됐다.
    # touched 예외를 삭제하고, entered/pending TTL + 서버보호 safety cap으로 단일화한다.
    before_shadow_active = len(active)
    active = _v678_prune_trigger_shadow_active(active, nowv)
    pruned_shadow_active = max(0, before_shadow_active - len(active))
    rows = list(active.values())
    entered = [r for r in rows if r.get('entered')]
    pending = [r for r in rows if not r.get('entered')]
    by_variant: Dict[str, List[Dict[str, Any]]] = {}
    for r in rows:
        by_variant.setdefault(str(r.get('variant') or '-'), []).append(r)
    variant_summary = {}
    for vk, arr in by_variant.items():
        ent = [r for r in arr if r.get('entered')]
        variant_summary[vk] = {
            'total': len(arr),
            'entered': len(ent),
            'pending': len(arr) - len(ent),
            'avg_max_pct': round(sum(fnum(r.get('max_pct'), default=0.0) for r in ent) / len(ent), 3) if ent else 0.0,
            'win_0_3_count': sum(1 for r in ent if fnum(r.get('max_pct'), default=0.0) >= 0.30),
            'loss_0_3_count': sum(1 for r in ent if fnum(r.get('min_pct'), default=0.0) <= -0.30),
        }
    top = sorted(entered, key=lambda r: fnum(r.get('max_pct'), default=0.0), reverse=True)[:8]
    summary = {
        'schema': 'trigger_shadow_review_v665',
        'version': VERSION,
        'updated_ts': nowv,
        'updated_text': now_text(nowv),
        'candidate_source_age_sec': round(nowv - fnum(cand_obj.get('updated_ts'), default=nowv), 1) if isinstance(cand_obj, dict) else None,
        'active_count': len(rows),
        'entered_count': len(entered),
        'pending_count': len(pending),
        'pruned_count_v678': pruned_shadow_active,
        'active_max_v678': TRIGGER_SHADOW_ACTIVE_MAX,
        'ttl_entered_sec_v678': TRIGGER_SHADOW_ENTERED_TTL_SEC,
        'ttl_pending_sec_v678': TRIGGER_SHADOW_PENDING_TTL_SEC,
        'variant_summary': variant_summary,
        'top_entered': [{k:r.get(k) for k in ('ticker','variant','variant_label','source','stage','coin_quality_score','entry_price','latest_price','current_pct','max_pct','min_pct')} for r in top],
        'policy': 'v678 trigger shadow hot/cold. 실제 S1/paper OPEN/청산/자동매수 변경 없음. touched TTL 예외 삭제.',
    }
    save_json(TRIGGER_SHADOW_STATE, {'schema':'trigger_shadow_state_v665', 'version':VERSION, 'updated_ts':nowv, 'updated_text':now_text(nowv), 'active':active})
    save_json(TRIGGER_SHADOW_SUMMARY, summary)
    return summary



# =============================================================================
# review_worker v0.15 / v667: whole-market missed-scan review
# - strategy_worker가 저장한 전체 canonical snapshot을 추적해 3/5/10분 뒤 상승 후보가 어디서 묻혔는지 본다.
# - 실제 paper 장부/OPEN/청산/자동매수는 변경하지 않는다.
# =============================================================================

def _review_market_miss_base_key(c: Dict[str, Any]) -> str:
    return ticker_norm(c.get('ticker'))


def _review_market_miss_base_update(nowv: float, fmap: Dict[str, Dict[str, Any]], ofmap: Dict[str, Dict[str, Any]]) -> Dict[str, Any]:
    cand_obj = load_json(MARKET_MISS_CANDIDATES, {}) or {}
    candidates = cand_obj.get('rows') if isinstance(cand_obj, dict) and isinstance(cand_obj.get('rows'), list) else []
    # v668: always publish a visible summary, even before 3/5/10m maturity.
    state = load_json(MARKET_MISS_STATE, {}) or {}
    active = state.get('active') if isinstance(state, dict) and isinstance(state.get('active'), dict) else {}
    # TTL: 최근 35분만 추적. 전체 456개를 보되 ticker별 1개 state만 유지한다.
    ttl = 35 * 60.0
    active = {k:v for k,v in active.items() if isinstance(v, dict) and nowv - fnum(v.get('first_seen_ts'), default=nowv) <= ttl}
    for c in candidates:
        if not isinstance(c, dict):
            continue
        t = _v667_miss_key(c)
        if not t:
            continue
        cur = _current_price(t, fmap, ofmap)
        base = fnum(c.get('snapshot_price'), default=0.0) or cur
        if not base:
            continue
        rec = active.get(t)
        if not isinstance(rec, dict):
            rec = {
                'schema': 'market_miss_state_row_v667',
                'ticker': t,
                'first_seen_ts': nowv,
                'first_seen_text': now_text(nowv),
                'first_price': base,
                'min_pct': 0.0,
                'max_pct': 0.0,
                'samples': {},
            }
        rec.update({
            'last_seen_ts': nowv,
            'last_seen_text': now_text(nowv),
            'initial_stage': c.get('initial_stage'),
            'coin_quality_score': c.get('coin_quality_score'),
            'execution_risk_score': c.get('execution_risk_score'),
            'miss_bucket': c.get('miss_bucket'),
            'initial_reason': c.get('initial_reason'),
            'trigger_source': c.get('trigger_source'),
            'trigger_gap_pct': c.get('trigger_gap_pct'),
            'coverage_only': c.get('coverage_only'),
        })
        if cur:
            rec['latest_price'] = cur
            cp = _pct(cur, fnum(rec.get('first_price'), default=base))
            rec['current_pct'] = cp
            rec['max_pct'] = max(fnum(rec.get('max_pct'), default=cp), cp)
            rec['min_pct'] = min(fnum(rec.get('min_pct'), default=cp), cp)
            elapsed = nowv - fnum(rec.get('first_seen_ts'), default=nowv)
            rec['age_sec'] = round(elapsed, 1)
            samples = rec.get('samples') if isinstance(rec.get('samples'), dict) else {}
            for label, sec in (('3m',180),('5m',300),('10m',600)):
                if elapsed >= sec and label not in samples:
                    samples[label] = {'ts': nowv, 'text': now_text(nowv), 'price': cur, 'pct': cp, 'max_pct': rec.get('max_pct'), 'min_pct': rec.get('min_pct')}
            rec['samples'] = samples
            # 분류: 오른 후보가 왜 안 샀는지. 위험 낮고 품질 높으면 진짜 놓침 가능성.
            maxp = fnum(rec.get('max_pct'), default=0.0)
            risk = fnum(rec.get('execution_risk_score'), default=0.0)
            q = fnum(rec.get('coin_quality_score'), default=0.0)
            bucket = str(rec.get('miss_bucket') or '-')
            if maxp >= 0.70 and q >= 60 and risk <= 40 and bucket not in ('risk_filter_candidate',):
                rec['miss_decision'] = '❌ 진짜놓침_후보'
            elif maxp >= 0.70 and bucket == 'risk_filter_candidate':
                rec['miss_decision'] = '✅ 위험필터_성공검토'
            elif maxp >= 0.40:
                rec['miss_decision'] = '⚠️ 아까운상승'
            else:
                rec['miss_decision'] = '관찰중'
        active[t] = rec
    rows = list(active.values())
    matured = [r for r in rows if fnum(r.get('age_sec'), default=0) >= 180]
    risers = [r for r in rows if fnum(r.get('max_pct'), default=0) >= 0.40]
    true_missed = [r for r in rows if str(r.get('miss_decision')) == '❌ 진짜놓침_후보']
    buckets = Counter(str(r.get('miss_bucket') or '-') for r in risers)
    stages = Counter(str(r.get('initial_stage') or '-') for r in rows)
    decisions = Counter(str(r.get('miss_decision') or '-') for r in rows)
    top = sorted(risers, key=lambda r: fnum(r.get('max_pct'), default=0.0), reverse=True)[:12]
    true_top = sorted(true_missed, key=lambda r: fnum(r.get('max_pct'), default=0.0), reverse=True)[:10]
    def slim(r: Dict[str, Any]) -> Dict[str, Any]:
        return {k:r.get(k) for k in ('ticker','initial_stage','miss_bucket','miss_decision','coin_quality_score','execution_risk_score','first_price','latest_price','current_pct','max_pct','min_pct','age_sec','initial_reason','trigger_source','trigger_gap_pct')}
    summary = {
        'schema': 'market_miss_review_v671_tracking_fixed',
        'version': VERSION,
        'updated_ts': nowv,
        'updated_text': now_text(nowv),
        'candidate_source_age_sec': round(nowv - fnum(cand_obj.get('updated_ts'), default=nowv), 1) if isinstance(cand_obj, dict) else None,
        'tracking_total': len(rows),
        'matured_count': len(matured),
        'rise_count': len(risers),
        'true_missed_count': len(true_missed),
        'candidate_source_count': len(candidates),
        'active_saved_count': len(rows),
        'price_source': 'orderflow/feature current price + snapshot fallback',
        'tracking_waiting_3m': sum(1 for r in rows if fnum(r.get('age_sec'), default=0) < 180),
        'miss_bucket_counts': dict(buckets.most_common(10)),
        'initial_stage_counts': dict(stages.most_common(6)),
        'decision_counts': dict(decisions.most_common(8)),
        'recheck_lane_counts': dict(Counter(str(r.get('miss_bucket') or '-') for r in rows if str(r.get('miss_decision')) in ('❌ 진짜놓침_후보','⚠️ 아까운상승')).most_common(10)),
        'top_risers': [slim(r) for r in top],
        'true_missed_top': [slim(r) for r in true_top],
        'policy': 'v671: Counter import/runtime error 복구 + 전체 456 놓침검증 추적 상태를 항상 저장/표시. 실제 S1/paper OPEN/청산/자동매수 변경 없음.',
    }
    save_json(MARKET_MISS_STATE, {'schema':'market_miss_state_v671_tracking_fixed', 'version':VERSION, 'updated_ts':nowv, 'updated_text':now_text(nowv), 'active':active})
    save_json(MARKET_MISS_SUMMARY, summary)
    return summary

def _v923_append_jsonl(path: Path, row: Dict[str, Any]) -> None:
    if path == GOOD_S2_RESULT_LEDGER:
        _v1080_rotate_good_s2_result()
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open('a', encoding='utf-8') as f:
        f.write(json.dumps(row, ensure_ascii=False, separators=(',', ':'), default=str) + '\n')
        f.flush()
        os.fsync(f.fileno())


def _v923_open_rows() -> List[Dict[str, Any]]:
    obj = load_json(OPEN, {}) or {}
    if isinstance(obj, dict) and isinstance(obj.get('positions'), dict):
        return [dict(v) for v in obj.get('positions', {}).values() if isinstance(v, dict)]
    if isinstance(obj, dict):
        rows = []
        for k, v in obj.items():
            if isinstance(v, dict) and (v.get('ticker') or v.get('pos_id') or v.get('event_id')):
                rr = dict(v); rr.setdefault('pos_id', k); rows.append(rr)
        return rows
    if isinstance(obj, list):
        return [dict(v) for v in obj if isinstance(v, dict)]
    return []


def _v923_candidate_key_from_paper(row: Dict[str, Any]) -> str:
    if not isinstance(row, dict):
        return ''
    for k in ('candidate_entry_build_key_v923', 'candidate_entry_build_key', 'entry_build_key'):
        v = row.get(k)
        if v not in (None, '', '-', [], {}):
            return str(v)
    cost = row.get('paper_execution_cost_v917') if isinstance(row.get('paper_execution_cost_v917'), dict) else {}
    v = cost.get('candidate_entry_build_key')
    return str(v) if v not in (None, '', '-', [], {}) else ''


def _v923_occurrence_from_paper(row: Dict[str, Any]) -> str:
    if not isinstance(row, dict):
        return ''
    v = row.get('good_s2_occurrence_key_v923')
    if v not in (None, '', '-', [], {}):
        return str(v)
    cost = row.get('paper_execution_cost_v917') if isinstance(row.get('paper_execution_cost_v917'), dict) else {}
    v = cost.get('good_s2_occurrence_key_v923')
    return str(v) if v not in (None, '', '-', [], {}) else ''


def _v923_exact_maps(rows: List[Dict[str, Any]]) -> Dict[str, Dict[str, Any]]:
    by_occ: Dict[str, Dict[str, Any]] = {}
    candidate_lists: Dict[str, List[Dict[str, Any]]] = {}
    for row in rows or []:
        if not isinstance(row, dict):
            continue
        occ = _v923_occurrence_from_paper(row)
        if occ:
            by_occ[occ] = row
        ck = _v923_candidate_key_from_paper(row)
        if ck:
            candidate_lists.setdefault(ck, []).append(row)
    by_candidate = {k: v[0] for k, v in candidate_lists.items() if len(v) == 1}
    ambiguous = {k: len(v) for k, v in candidate_lists.items() if len(v) > 1}
    return {'by_occurrence': by_occ, 'by_candidate': by_candidate, 'ambiguous_candidate': ambiguous}


def _good_s2_compact_observation_v1013(obs: Dict[str, Any]) -> Dict[str, Any]:
    metrics=obs.get('metrics') if isinstance(obs.get('metrics'),dict) else {}
    structure=obs.get('structure') if isinstance(obs.get('structure'),dict) else {}
    metric_keys=('spread_pct','slippage_pct','price_reaction_pct','relative_strength','turnover_24h','volume_ratio')
    structure_keys=('trigger','invalid','target','major_tf','setup_tf','execution_tf','rr','target_room_pct')
    return {
        'schema':'good_s2_observation_compact_v1013','occurrence_key':obs.get('occurrence_key'),'observation_key':obs.get('observation_key'),
        'ticker':obs.get('ticker'),'observed_ts':obs.get('observed_ts'),'observed_text':obs.get('observed_text'),'price':obs.get('price'),
        'entry_build_key':obs.get('entry_build_key'),'stable_event_key':obs.get('stable_event_key'),'candidate_follow_key':obs.get('candidate_follow_key'),
        'score_patch_version':obs.get('score_patch_version'),'metrics':{k:metrics.get(k) for k in metric_keys if metrics.get(k) not in (None,'',[],{})},
        'structure':{k:structure.get(k) for k in structure_keys if structure.get(k) not in (None,'',[],{})},
        'structure_tags':list(obs.get('structure_tags') or [])[:8],'quality_tags':list(obs.get('quality_tags') or [])[:8],
    }

def _v923_result_record_from_observation(obs: Dict[str, Any]) -> Dict[str, Any]:
    occurrence = str(obs.get('occurrence_key') or '')
    price = fnum(obs.get('price'), default=0.0)
    ts = fnum(obs.get('observed_ts'), default=0.0)
    return {
        'schema': 'good_s2_result_state_row_v923',
        'version': VERSION,
        'build': 'good_s2_source_exact_result_v926_2026-06-18',
        'occurrence_key': occurrence,
        'observation_key': obs.get('observation_key'),
        'ticker': ticker_norm(obs.get('ticker')),
        'observed_ts': ts,
        'observed_text': obs.get('observed_text') or now_text(ts),
        'first_price': price,
        'latest_price': price,
        'current_pct': 0.0,
        'max_pct': 0.0,
        'min_pct': 0.0,
        'giveback_pct': 0.0,
        'max_seen_ts': ts,
        'min_seen_ts': ts,
        'samples': {},
        'entry_build_key': obs.get('entry_build_key'),
        'stable_event_key': obs.get('stable_event_key'),
        'candidate_follow_key': obs.get('candidate_follow_key'),
        'score_patch_version': obs.get('score_patch_version'),
        'initial_metrics': obs.get('metrics') if isinstance(obs.get('metrics'), dict) else {},
        'structure': obs.get('structure') if isinstance(obs.get('structure'), dict) else {},
        'structure_tags': list(obs.get('structure_tags') or [])[:12],
        'quality_tags': list(obs.get('quality_tags') or [])[:12],
        'open_linked': False,
        'closed_linked': False,
        'terminal': False,
        'result_state': 'tracking',
        'link_policy': 'occurrence key exact first; unique candidate event exact second; ticker never final',
    }


def _v923_result_final_key(rec: Dict[str, Any]) -> str:
    occ = str(rec.get('occurrence_key') or '')
    if rec.get('closed_linked') and rec.get('closed_result_key'):
        return f"{occ}|closed:{rec.get('closed_result_key')}"
    if rec.get('horizon_complete'):
        return f'{occ}|horizon:{int(GOOD_S2_RESULT_HORIZON_SEC)}'
    return ''



def _v925_reset_overcount_result_state_if_needed(nowv: float, valid_occurrences: set[str]) -> Dict[str, Any]:
    """One-time source-spine cleanup using streaming ledger I/O; core trade ledgers are untouched."""
    completed_meta = load_json(GOOD_S2_RESULT_RESET_META_V926, {})
    if isinstance(completed_meta, dict) and completed_meta.get("completed") is True:
        return completed_meta
    qdir = BASE_DIR / "quarantine"
    qdir.mkdir(parents=True, exist_ok=True)
    stamp = time.strftime("%Y%m%d_%H%M%S", time.localtime(nowv))
    state = load_json(GOOD_S2_RESULT_STATE, {})
    if not isinstance(state, dict):
        state = {}
    records_obj = state.get("records")
    records = records_obj if isinstance(records_obj, dict) else {}
    stale_state = {str(k): v for k, v in records.items() if str(k) not in valid_occurrences and isinstance(v, dict)}
    kept_state = {str(k): v for k, v in records.items() if str(k) in valid_occurrences and isinstance(v, dict)}
    state_quarantine = ""
    if stale_state:
        state_dest = qdir / f"good_s2_result_state_non_source_{stamp}.json.gz"
        with gzip.open(state_dest, "wt", encoding="utf-8", compresslevel=6) as f:
            json.dump({"schema":"good_s2_result_state_quarantine_v926","removed_records":stale_state,"source_state_meta":{k:v for k,v in state.items() if k!="records"}}, f, ensure_ascii=False, separators=(",", ":"), default=str)
        state_quarantine = state_dest.name
        save_json(GOOD_S2_RESULT_STATE, {"schema":"good_s2_result_state_v923","version":VERSION,"build":"good_s2_source_exact_result_v926_2026-06-18","updated_ts":nowv,"updated_text":now_text(nowv),"records":kept_state,"retention_sec":GOOD_S2_RESULT_RETENTION_SEC})
    ledger_before = ledger_kept = ledger_removed = 0
    ledger_quarantine = ""
    if GOOD_S2_RESULT_LEDGER.exists():
        kept_tmp = GOOD_S2_RESULT_LEDGER.with_name(GOOD_S2_RESULT_LEDGER.name + f".tmp.{os.getpid()}.{time.time_ns()}")
        ledger_dest = qdir / f"good_s2_result_ledger_non_source_{stamp}.jsonl.gz"
        with GOOD_S2_RESULT_LEDGER.open("r", encoding="utf-8", errors="ignore") as src, kept_tmp.open("w", encoding="utf-8") as kept, gzip.open(ledger_dest, "wt", encoding="utf-8", compresslevel=6) as removed:
            for line in src:
                try:
                    row = json.loads(line)
                except (ValueError, TypeError):
                    continue
                if not isinstance(row, dict):
                    continue
                ledger_before += 1
                if str(row.get("occurrence_key") or "") in valid_occurrences:
                    kept.write(json.dumps(row, ensure_ascii=False, separators=(",", ":"), default=str) + "\n")
                    ledger_kept += 1
                else:
                    removed.write(json.dumps(row, ensure_ascii=False, separators=(",", ":"), default=str) + "\n")
                    ledger_removed += 1
            kept.flush()
            os.fsync(kept.fileno())
        if ledger_removed:
            os.replace(kept_tmp, GOOD_S2_RESULT_LEDGER)
            ledger_quarantine = ledger_dest.name
        else:
            kept_tmp.unlink(missing_ok=True)
            ledger_dest.unlink(missing_ok=True)
    meta = {"schema":"good_s2_result_source_spine_reset_v926","completed":True,"state":"QUARANTINED_NON_SOURCE" if (stale_state or ledger_removed) else "SOURCE_BACKED","records_before":len(records),"records_kept":len(kept_state),"valid_occurrence_count":len(valid_occurrences),"removed_state_records":len(stale_state),"ledger_rows_before":ledger_before,"ledger_rows_kept":ledger_kept,"removed_ledger_rows":ledger_removed,"state_quarantine_file":state_quarantine,"ledger_quarantine_file":ledger_quarantine,"performance_excluded":True,"updated_ts":nowv,"updated_text":now_text(nowv),"policy":"only strategy observation occurrence keys remain; streaming migration; OPEN/CLOSED/trade_log/decision/exact ledgers untouched"}
    save_json(GOOD_S2_RESULT_RESET_META_V926, meta)
    save_json(GOOD_S2_RESULT_RESET_META_V925, meta)
    return meta

def _v923_update_good_s2_results(nowv: float, fmap: Dict[str, Dict[str, Any]], ofmap: Dict[str, Dict[str, Any]], closed_rows_input: Optional[List[Dict[str, Any]]]=None) -> Dict[str, Any]:
    """Exact good-S2 tracker with one in-process state and bounded checkpoints."""
    global _GOOD_S2_STATE_CACHE_V1011, _GOOD_S2_STATE_META_V1011, _GOOD_S2_LAST_CHECKPOINT_V1011
    global _GOOD_S2_OBSERVATION_CACHE_V1011, _GOOD_S2_FINAL_KEYS_V1011

    aggregate_v1014=_prepare_good_s2_summary_v1014()
    obs_sig=_file_size_signature_v1011(GOOD_S2_OBSERVATION_LEDGER)
    if _GOOD_S2_OBSERVATION_CACHE_V1011.get('signature')!=obs_sig:
        observations=[_good_s2_compact_observation_v1013(r) for r in _persistent_jsonl_tail_v1011(GOOD_S2_OBSERVATION_LEDGER,5000)
                      if isinstance(r,dict) and str(r.get('schema') or '')=='good_s2_observation_v923'
                      and str(r.get('version') or '') in {'strategy_worker_v0.923','strategy_worker_v0.925'}
                      and not bool(r.get('performance_excluded')) and str(r.get('occurrence_key') or '')]
        _GOOD_S2_OBSERVATION_CACHE_V1011={'signature':obs_sig,'rows':observations}
    else:
        observations=_GOOD_S2_OBSERVATION_CACHE_V1011.get('rows') if isinstance(_GOOD_S2_OBSERVATION_CACHE_V1011.get('rows'),list) else []
    valid_occurrences={str(r.get('occurrence_key') or '') for r in observations if str(r.get('occurrence_key') or '')}

    loaded_from_disk=False
    reset_meta_v925={}
    if _GOOD_S2_STATE_CACHE_V1011 is None:
        reset_meta_v925=_v925_reset_overcount_result_state_if_needed(nowv,valid_occurrences)
        state_obj=load_json(GOOD_S2_RESULT_STATE,{}) or {}
        raw=state_obj.get('records') if isinstance(state_obj,dict) and isinstance(state_obj.get('records'),dict) else {}
        _GOOD_S2_STATE_CACHE_V1011={str(k):dict(v) for k,v in raw.items() if isinstance(v,dict) and (str(k) in valid_occurrences or bool(v.get('closed_linked')) or bool(v.get('final_result_key')))}
        _GOOD_S2_STATE_META_V1011={'reset_meta':reset_meta_v925}
        _GOOD_S2_LAST_CHECKPOINT_V1011=float(state_obj.get('updated_ts') or 0.0) if isinstance(state_obj,dict) else 0.0
        loaded_from_disk=True
    records=_GOOD_S2_STATE_CACHE_V1011
    reset_meta_v925=_GOOD_S2_STATE_META_V1011.get('reset_meta') if isinstance(_GOOD_S2_STATE_META_V1011.get('reset_meta'),dict) else {}

    new_records=0
    for obs in observations:
        occ=str(obs.get('occurrence_key') or '')
        if occ not in records:
            rec=_v923_result_record_from_observation(obs)
            rec['next_review_due_ts_v1011']=nowv
            records[occ]=rec; new_records+=1

    open_rows=_v923_open_rows()
    if closed_rows_input is None:
        _canonical_closed = load_json(CANONICAL_PERFORMANCE_V987, {}) or {}
        closed_rows_input = _canonical_closed.get('rows') if isinstance(_canonical_closed, dict) and isinstance(_canonical_closed.get('rows'), list) else []
    closed_rows=[r for r in closed_rows_input if isinstance(r,dict)]
    open_maps=_v923_exact_maps(open_rows); closed_maps=_v923_exact_maps(closed_rows)
    final_existing=None  # v1013 SQLite-backed exact key index; no in-memory ledger key set

    link_modes=Counter(); samples_ready=Counter(); appended_final=0; ticker_audit_open=0; ticker_audit_closed=0
    open_tickers={ticker_norm(r.get('ticker')) for r in open_rows if isinstance(r,dict)}
    closed_tickers={ticker_norm(r.get('ticker')) for r in closed_rows if isinstance(r,dict)}
    due_processed=0; due_deferred=0; state_changed=bool(new_records)

    for occ,rec in list(records.items()):
        if not isinstance(rec,dict): continue
        ticker=ticker_norm(rec.get('ticker')); age=max(0.0,nowv-fnum(rec.get('observed_ts'),default=nowv))
        due_ts=fnum(rec.get('next_review_due_ts_v1011'),default=0.0)
        if due_ts<=nowv and not rec.get('terminal'):
            due_processed+=1
            first_price=fnum(rec.get('first_price'),default=0.0)
            cur=_current_price(ticker,fmap,ofmap) if ticker else 0.0
            if cur<=0: cur=fnum(rec.get('latest_price'),default=first_price)
            if cur>0 and first_price>0:
                pct=_pct(cur,first_price); rec['latest_price']=cur; rec['current_pct']=pct
                old_max=fnum(rec.get('max_pct'),default=pct); old_min=fnum(rec.get('min_pct'),default=pct)
                if pct>=old_max: rec['max_seen_ts']=nowv; rec['max_seen_text']=now_text(nowv)
                if pct<=old_min: rec['min_seen_ts']=nowv; rec['min_seen_text']=now_text(nowv)
                rec['max_pct']=max(old_max,pct); rec['min_pct']=min(old_min,pct); rec['giveback_pct']=round(max(0.0,fnum(rec.get('max_pct'),default=0.0)-pct),3)
            rec['age_sec']=round(age,1); rec['last_updated_ts']=nowv; rec['last_updated_text']=now_text(nowv)
            samples=rec.get('samples') if isinstance(rec.get('samples'),dict) else {}
            for label,sec in (('3m',180),('5m',300),('10m',600),('20m',1200),('60m',3600)):
                if age>=sec and label not in samples:
                    samples[label]={'ts':nowv,'text':now_text(nowv),'price':rec.get('latest_price'),'pct':rec.get('current_pct'),'max_pct':rec.get('max_pct'),'min_pct':rec.get('min_pct'),'giveback_pct':rec.get('giveback_pct')}
                    state_changed=True
            rec['samples']=samples
            rec['next_review_due_ts_v1011']=nowv+(30.0 if age<=600 else (60.0 if age<=3600 else 180.0))
        elif not rec.get('terminal'):
            due_deferred+=1
        for label in ('3m','5m','10m','20m','60m'):
            if label in (rec.get('samples') if isinstance(rec.get('samples'),dict) else {}): samples_ready[label]+=1

        exact=str(rec.get('entry_build_key') or '')
        open_row=open_maps['by_occurrence'].get(occ); open_mode='occurrence_exact' if isinstance(open_row,dict) else ''
        if open_row is None and exact:
            open_row=open_maps['by_candidate'].get(exact); open_mode='candidate_event_exact' if isinstance(open_row,dict) else ''
        if isinstance(open_row,dict) and not rec.get('open_linked'):
            rec['open_linked']=True; rec['open_match_mode']=open_mode; rec['open_pos_id']=open_row.get('pos_id') or open_row.get('event_id')
            rec['opened_at']=fnum(open_row.get('opened_at'),default=0.0) or None; rec['open_entry_price']=fnum(open_row.get('entry_price'),default=0.0) or None
            rec['open_score_patch_version']=open_row.get('score_patch_version') or open_row.get('entry_build_key'); state_changed=True
        if isinstance(open_row,dict): link_modes[f'open:{open_mode}']+=1
        elif ticker and ticker in open_tickers: ticker_audit_open+=1

        closed_row=closed_maps['by_occurrence'].get(occ); closed_mode='occurrence_exact' if isinstance(closed_row,dict) else ''
        if closed_row is None and exact:
            closed_row=closed_maps['by_candidate'].get(exact); closed_mode='candidate_event_exact' if isinstance(closed_row,dict) else ''
        if isinstance(closed_row,dict) and not rec.get('closed_linked'):
            rec['closed_linked']=True; rec['closed_match_mode']=closed_mode; rec['closed_result_key']=closed_row.get('closed_result_key')
            rec['closed_ts']=fnum(closed_row.get('closed_ts'),closed_row.get('closed_at'),default=0.0) or None; rec['closed_pnl_pct']=fnum(closed_row.get('pnl_pct'),closed_row.get('profit_pct'),default=0.0)
            rec['closed_peak_pct']=fnum(closed_row.get('peak_pct'),default=0.0); rec['closed_trough_pct']=fnum(closed_row.get('trough_pct'),default=0.0)
            rec['closed_giveback_pct']=fnum(closed_row.get('giveback_pct'),closed_row.get('missed_profit_pct'),default=0.0); rec['exit_reason']=closed_row.get('exit_reason') or closed_row.get('exit_rule')
            rec['terminal']=True; rec['result_state']='closed_exact'; state_changed=True
        if isinstance(closed_row,dict): link_modes[f'closed:{closed_mode}']+=1
        elif ticker and ticker in closed_tickers: ticker_audit_closed+=1

        if not rec.get('closed_linked') and age>=GOOD_S2_RESULT_HORIZON_SEC and not rec.get('horizon_complete'):
            rec['horizon_complete']=True; rec['terminal']=True; rec['result_state']='review_horizon_6h'; state_changed=True
        final_key=_v923_result_final_key(rec)
        if final_key and not _dedup_contains_v1013('good_s2',final_key):
            final_row={'schema':'good_s2_final_result_v923','version':VERSION,'build':BUILD_LABEL,'final_result_key':final_key,'finalized_ts':nowv,'finalized_text':now_text(nowv),
                       **{k:rec.get(k) for k in ('occurrence_key','observation_key','ticker','observed_ts','first_price','latest_price','current_pct','max_pct','min_pct','giveback_pct','entry_build_key','stable_event_key','candidate_follow_key','score_patch_version','open_linked','open_match_mode','open_pos_id','opened_at','open_entry_price','closed_linked','closed_match_mode','closed_result_key','closed_ts','closed_pnl_pct','closed_peak_pct','closed_trough_pct','closed_giveback_pct','exit_reason','horizon_complete','result_state','samples','initial_metrics','structure','structure_tags','quality_tags')},
                       'performance_eligible':True,'join_policy':'exact occurrence or unique candidate event only; no ticker final join'}
            _v923_append_jsonl(GOOD_S2_RESULT_LEDGER,final_row); _dedup_commit_v1013('good_s2',final_key)
            _commit_good_s2_aggregate_v1014(final_row)
            aggregate_v1014=_GOOD_S2_FINAL_AGG_V1014
            rec['final_result_key']=final_key; rec['finalized_ts']=nowv; appended_final+=1; state_changed=True

    kept={}; pruned=0; terminal_offloaded_v1014=0
    for occ,rec in records.items():
        ref=fnum(rec.get('closed_ts'),rec.get('finalized_ts'),rec.get('last_updated_ts'),rec.get('observed_ts'),default=nowv)
        if rec.get('terminal') and rec.get('final_result_key') and _dedup_contains_v1013('good_s2',str(rec.get('final_result_key'))):
            terminal_offloaded_v1014+=1
            continue
        if rec.get('terminal') and nowv-ref>GOOD_S2_RESULT_RETENTION_SEC: pruned+=1; continue
        kept[occ]=rec
    records=kept; _GOOD_S2_STATE_CACHE_V1011=records
    rows=list(records.values()); active_closed=[r for r in rows if r.get('closed_linked')]; active_opened=[r for r in rows if r.get('open_linked')]; tracking=[r for r in rows if not r.get('terminal')]
    aggregate_v1014=_GOOD_S2_FINAL_AGG_V1014 or aggregate_v1014 or _good_s2_empty_agg_v1014()
    agg_total=int(aggregate_v1014.get('total_rows') or 0); active_total=len(rows); combined_total=agg_total+active_total
    max_sum=float(aggregate_v1014.get('max_sum') or 0.0)+sum(fnum(r.get('max_pct'),default=0.0) for r in rows)
    min_sum=float(aggregate_v1014.get('min_sum') or 0.0)+sum(fnum(r.get('min_pct'),default=0.0) for r in rows)
    give_sum=float(aggregate_v1014.get('giveback_sum') or 0.0)+sum(fnum(r.get('giveback_pct'),default=0.0) for r in rows)
    metric_n=int(aggregate_v1014.get('metric_rows') or 0)+len(rows)
    active_closed_pnls=[fnum(r.get('closed_pnl_pct'),default=0.0) for r in active_closed]
    closed_wins=int(aggregate_v1014.get('closed_wins') or 0)+sum(1 for x in active_closed_pnls if x>0)
    closed_losses=int(aggregate_v1014.get('closed_losses') or 0)+sum(1 for x in active_closed_pnls if x<=0)
    closed_sum=float(aggregate_v1014.get('closed_pnl_sum') or 0.0)+sum(active_closed_pnls)
    closed_n=closed_wins+closed_losses
    combined_samples=Counter(aggregate_v1014.get('samples_ready') or {}); combined_samples.update(samples_ready)
    combined_links=Counter(aggregate_v1014.get('link_mode_counts') or {}); combined_links.update(link_modes)
    recent_pool=list(aggregate_v1014.get('recent_rows') or [])+rows
    recent=sorted((r for r in recent_pool if isinstance(r,dict)),key=lambda r:fnum(r.get('observed_ts'),default=0.0),reverse=True)[:80]
    opened_exact=int(aggregate_v1014.get('open_linked') or 0)+len(active_opened)
    closed_exact=int(aggregate_v1014.get('closed_linked') or 0)+len(active_closed)
    horizon_complete=int(aggregate_v1014.get('horizon_complete') or 0)+sum(1 for r in rows if r.get('horizon_complete'))
    unmatched_exact=int(aggregate_v1014.get('unmatched_exact') or 0)+sum(1 for r in rows if not r.get('open_linked') and not r.get('closed_linked'))
    snapshot={'schema':'good_s2_result_snapshot_canonical','version':VERSION,'build':BUILD_LABEL,'updated_ts':nowv,'updated_text':now_text(nowv),
              'source_observation_rows_v923':len(observations),'state_reset_v925':reset_meta_v925,'new_records_this_cycle':new_records,'tracked_total':combined_total,'tracking_active':len(tracking),
              'opened_exact':opened_exact,'closed_exact':closed_exact,'horizon_complete':horizon_complete,'unmatched_exact':unmatched_exact,
              'ticker_audit_only_open':ticker_audit_open,'ticker_audit_only_closed':ticker_audit_closed,'link_mode_counts':dict(combined_links),'samples_ready':dict(combined_samples),
              'avg_max_pct':round(max_sum/metric_n,4) if metric_n else None,'avg_min_pct':round(min_sum/metric_n,4) if metric_n else None,'avg_giveback_pct':round(give_sum/metric_n,4) if metric_n else None,
              'closed_wins':closed_wins,'closed_losses':closed_losses,'closed_avg_pnl_pct':round(closed_sum/closed_n,4) if closed_n else None,'closed_sum_pnl_pct':round(closed_sum,4) if closed_n else None,
              'final_appended_this_cycle':appended_final,'final_ledger_rows':agg_total,'final_ledger_bytes':GOOD_S2_RESULT_LEDGER.stat().st_size if GOOD_S2_RESULT_LEDGER.exists() else 0,
              'state_pruned_this_cycle':pruned,'terminal_offloaded_from_heap_v1014':terminal_offloaded_v1014,'active_memory_records_v1014':len(records),'final_aggregate_rows_v1014':agg_total,
              'final_aggregate_prepare_v1014':dict(_GOOD_S2_FINAL_PREPARE_V1014),'review_horizon_sec':GOOD_S2_RESULT_HORIZON_SEC,'rows':recent,'last_row':recent[0] if recent else None,
              'due_processed_v1011':due_processed,'due_deferred_v1011':due_deferred,'state_memory_reused_v1011':not loaded_from_disk,
              'closed_source_v1015':'canonical_performance_snapshot_v987.rows','closed_source_rows_v1015':len(closed_rows),
              'policy':'terminal rows live only in append-only final ledger + compact aggregate; long-lived heap keeps active rows only; CLOSED evidence comes only from the paper canonical performance snapshot','conditions_changed':False,'paper_open_changed':False,'exit_changed':False}

    checkpoint_due=bool(not GOOD_S2_RESULT_STATE.exists() or _GOOD_S2_LAST_CHECKPOINT_V1011<=0 or nowv-_GOOD_S2_LAST_CHECKPOINT_V1011>=GOOD_S2_CHECKPOINT_SEC)
    snapshot['state_checkpoint_v1011']={'due':checkpoint_due,'interval_sec':GOOD_S2_CHECKPOINT_SEC,'state_changed':state_changed,'memory_records':len(records)}
    if checkpoint_due:
        save_json(GOOD_S2_RESULT_STATE,{'schema':'good_s2_result_state_v1014_active_only','version':VERSION,'build':BUILD_LABEL,'updated_ts':nowv,'updated_text':now_text(nowv),'records':records,'retention_sec':GOOD_S2_RESULT_RETENTION_SEC,'terminal_rows_offloaded':True,'final_summary_file':GOOD_S2_FINAL_SUMMARY_V1014.name})
        _GOOD_S2_LAST_CHECKPOINT_V1011=nowv; snapshot['state_checkpoint_v1011']['written']=True
    else:
        snapshot['state_checkpoint_v1011']['written']=False
    save_json(GOOD_S2_RESULT_SNAPSHOT,snapshot)
    return snapshot



def _quality_optional_num(*values: Any) -> Optional[float]:
    for value in values:
        if value in (None, '', '-', [], {}):
            continue
        try:
            number = float(str(value).replace(',', '').replace('%', ''))
        except Exception:
            continue
        if number == number and number not in (float('inf'), float('-inf')):
            return number
    return None


def _quality_direct_decision_key_v1124(row: Dict[str, Any]) -> str:
    if not isinstance(row, dict):
        return ''
    swing_gate = row.get('swing_entry_gate_v977') if isinstance(row.get('swing_entry_gate_v977'), dict) else {}
    minimal_gate = row.get('minimal_entry_gate_v925') if isinstance(row.get('minimal_entry_gate_v925'), dict) else {}
    value = row.get('swing_gate_decision_key_v977') or swing_gate.get('decision_key') or row.get('minimal_gate_decision_key_v925') or minimal_gate.get('decision_key')
    return str(value or '').strip()


def _quality_exact_identity(row: Dict[str, Any]) -> tuple[str, str]:
    """Return only the frozen-plan trigger occurrence owner.

    Candidate/scanner/direct keys are audit evidence.  They must never create a
    quality sample when the canonical trigger occurrence decision key is absent.
    """
    if not isinstance(row, dict):
        return '', 'missing_owner_key_v1126'
    swing_gate = row.get('swing_entry_gate_v977') if isinstance(row.get('swing_entry_gate_v977'), dict) else {}
    trigger_obj = row.get('trigger_occurrence_v1037') if isinstance(row.get('trigger_occurrence_v1037'), dict) else {}
    if not trigger_obj and isinstance(swing_gate.get('trigger_occurrence_v1037'), dict):
        trigger_obj = swing_gate.get('trigger_occurrence_v1037')
    occurrence_decision = trigger_obj.get('decision_key') if isinstance(trigger_obj, dict) else None
    if occurrence_decision not in (None, '', '-', [], {}):
        return 'trigger_decision:' + str(occurrence_decision).strip(), 'trigger_occurrence_v1037.decision_key'
    return '', 'missing_owner_key_v1126'


def _quality_gate(row: Dict[str, Any]) -> Dict[str, Any]:
    swing = row.get('swing_entry_gate_v977')
    if isinstance(swing, dict):
        return swing
    gate = row.get('minimal_entry_gate_v925')
    return gate if isinstance(gate, dict) else {}


def _quality_block_reasons(row: Dict[str, Any], gate: Dict[str, Any]) -> List[str]:
    values = gate.get('hard_block_reasons') if isinstance(gate.get('hard_block_reasons'), list) else row.get('final_trade_reasons')
    seq = values if isinstance(values, list) else ([values] if values not in (None, '', '-', [], {}) else [])
    out: List[str] = []
    for item in seq:
        text = str(item or '').strip()
        if text and text not in out:
            out.append(text)
    return out


def _quality_cohort(hard_pass: bool, reasons: List[str]) -> str:
    if hard_pass:
        return 's1_pass'
    priority = (
        'frozen_trigger_not_reached',
        'risk_reward_below_minimum',
        'target_room_below_minimum',
        'coherent_structure_plan_incomplete',
        'actual_structural_invalid_missing',
        'next_structural_target_missing',
        'candidate_sources_not_fresh',
        'untradable_spread',
        'untradable_liquidity',
    )
    for reason in priority:
        if reason in reasons:
            return reason
    return reasons[0] if reasons else 'other_blocked'


def _seal_quality_event_context(row: Dict[str, Any], feature_row: Dict[str, Any], regime_snapshot: Dict[str, Any], observed_ts: float) -> Dict[str, Any]:
    """Create immutable event-time market and turnover context exactly once."""
    row = row if isinstance(row, dict) else {}
    feature_row = feature_row if isinstance(feature_row, dict) else {}
    regime_snapshot = regime_snapshot if isinstance(regime_snapshot, dict) else {}
    market_obj = row.get('market_regime') if isinstance(row.get('market_regime'), dict) else {}
    tags = row.get('market_regime_tags') if isinstance(row.get('market_regime_tags'), list) else market_obj.get('tags') if isinstance(market_obj.get('tags'), list) else []
    risks = row.get('market_risk_tags') if isinstance(row.get('market_risk_tags'), list) else market_obj.get('risk_tags') if isinstance(market_obj.get('risk_tags'), list) else []
    summary = str(row.get('market_regime_summary') or market_obj.get('summary') or '').strip()

    row_mode = str(row.get('market_mode') or row.get('market_state') or row.get('regime') or market_obj.get('mode') or '').strip()
    feature_mode = str(feature_row.get('market_mode') or feature_row.get('market_state') or feature_row.get('regime') or '').strip()
    regime_mode = str(regime_snapshot.get('market_mode') or regime_snapshot.get('mode') or '').strip()
    mode = row_mode or feature_mode or regime_mode

    row_strength = _quality_optional_num(row.get('market_strength'), row.get('market_breadth'), row.get('regime_strength'))
    feature_strength = _quality_optional_num(feature_row.get('market_strength'), feature_row.get('market_breadth'), feature_row.get('regime_strength'))
    regime_strength = _quality_optional_num(regime_snapshot.get('market_strength'), regime_snapshot.get('market_breadth'), regime_snapshot.get('regime_strength'))
    strength = row_strength if row_strength is not None else feature_strength if feature_strength is not None else regime_strength

    text = ' / '.join([mode, summary, *[str(x) for x in tags], *[str(x) for x in risks]]).lower()
    if any(x in text for x in ('상승','강함','bull','strong')) or (strength is not None and strength >= 0.2):
        label = 'up_or_strong'
    elif any(x in text for x in ('하락','약함','bear','weak','급락')) or (strength is not None and strength <= -0.2):
        label = 'down_or_weak'
    elif any(x in text for x in ('횡보','side','neutral','보통')):
        label = 'sideways_or_neutral'
    else:
        label = 'context_missing'

    if row_mode or tags or summary or row_strength is not None:
        market_source = 'candidate_snapshot_at_event'
    elif feature_mode or feature_strength is not None:
        market_source = 'feature_snapshot_at_event'
    elif regime_mode or regime_strength is not None:
        market_source = 'regime_snapshot_at_event'
    else:
        market_source = 'legacy_context_missing'

    row_turnover = _quality_optional_num(row.get('turnover_24h'), row.get('trade_value_24h'), row.get('acc_trade_price_24h'))
    feature_turnover = _quality_optional_num(feature_row.get('turnover_24h'), feature_row.get('trade_value_24h'), feature_row.get('acc_trade_price_24h'))
    turnover = row_turnover if row_turnover is not None else feature_turnover
    row_volume_ratio = _quality_optional_num(row.get('volume_ratio'), row.get('trade_value_ratio'), row.get('volume_expansion_ratio'))
    feature_volume_ratio = _quality_optional_num(feature_row.get('volume_ratio'), feature_row.get('trade_value_ratio'), feature_row.get('volume_expansion_ratio'))
    volume_ratio = row_volume_ratio if row_volume_ratio is not None else feature_volume_ratio
    turnover_change = _quality_optional_num(
        row.get('turnover_change_pct'), row.get('trade_value_change_pct'), row.get('volume_expansion_pct'),
        feature_row.get('turnover_change_pct'), feature_row.get('trade_value_change_pct'), feature_row.get('volume_expansion_pct')
    )
    if row_turnover is not None or row_volume_ratio is not None:
        turnover_source = 'candidate_snapshot_at_event'
    elif feature_turnover is not None or feature_volume_ratio is not None:
        turnover_source = 'feature_snapshot_at_event'
    else:
        turnover_source = 'legacy_context_missing'

    return {
        'schema': QUALITY_EVENT_CONTEXT_SCHEMA,
        'sealed_at_ts': observed_ts,
        'sealed_at_text': now_text(observed_ts),
        'market_regime': label,
        'market_mode': mode or None,
        'market_summary': summary or None,
        'market_tags': [str(x) for x in tags[:8]],
        'market_risk_tags': [str(x) for x in risks[:6]],
        'market_strength': strength,
        'market_context_source': market_source,
        'market_context_sealed': label != 'context_missing',
        'turnover_24h': turnover,
        'volume_ratio': volume_ratio,
        'turnover_change_pct': turnover_change,
        'turnover_context_source': turnover_source,
        'turnover_context_sealed': turnover is not None or volume_ratio is not None,
        'immutable_event_time_context': True,
        'context_cutover':'v965_new_event_only',
    }


def _legacy_missing_event_context() -> Dict[str, Any]:
    return {
        'schema': QUALITY_EVENT_CONTEXT_SCHEMA,
        'sealed_at_ts': None,
        'sealed_at_text': None,
        'market_regime': 'context_missing',
        'market_mode': None,
        'market_summary': None,
        'market_tags': [],
        'market_risk_tags': [],
        'market_strength': None,
        'market_context_source': 'legacy_context_missing',
        'market_context_sealed': False,
        'turnover_24h': None,
        'volume_ratio': None,
        'turnover_change_pct': None,
        'turnover_context_source': 'legacy_context_missing',
        'turnover_context_sealed': False,
        'immutable_event_time_context': True,
        'legacy_before_v965_context_spine': True,
    }


def _quality_initial_metrics(row: Dict[str, Any], gate: Dict[str, Any]) -> Dict[str, Any]:
    """Persist only metrics consumed by active quality/performance readers.

    The former row copied smart_structure_shadow_v948 and many unused candidate
    fields into up to 8,000 records.  That duplicated a large nested object and
    expanded an 83MB JSON state into a >1GB Python heap.
    """
    hot = row.get('hot_watch_timing_v945') if isinstance(row.get('hot_watch_timing_v945'), dict) else {}
    quality_gate = gate.get('swing_quality_gate') if isinstance(gate.get('swing_quality_gate'), dict) else row.get('swing_quality_gate') if isinstance(row.get('swing_quality_gate'), dict) else {}
    current_price = _quality_optional_num(row.get('current_price'), row.get('entry_price'), row.get('price'), row.get('detected_price'))
    invalid_price = _quality_optional_num(gate.get('invalid_price'), row.get('invalid_price'), row.get('swing_invalid_price_v977'), row.get('stop_loss_price'))
    invalid_distance = ((current_price-invalid_price)/current_price*100.0) if current_price and invalid_price and current_price>0 else None
    return {
        'spread_pct': _quality_optional_num(gate.get('spread_pct'), row.get('spread_pct'), row.get('micro_spread_pct')),
        'scanner_to_candidate_sec': _quality_optional_num(hot.get('scanner_to_strategy_sec')),
        'scanner_to_s2_sec': _quality_optional_num(hot.get('scanner_to_s2_sec')),
        'scanner_to_s1_sec': _quality_optional_num(hot.get('scanner_to_s1_sec')),
        'first_price': current_price,
        'confirmed_slippage_pct': _quality_optional_num(gate.get('confirmed_slippage_pct'), row.get('slippage_pct_confirmed'), row.get('entry_slippage_est_pct')),
        'confirmed_slippage_source': str(gate.get('confirmed_slippage_source') or row.get('slippage_pct_source_v903') or row.get('slippage_pct_source') or row.get('entry_slippage_source') or '').strip() or None,
        'risk_reward': _quality_optional_num(gate.get('risk_reward'), row.get('risk_reward'), row.get('risk_reward_ratio'), row.get('rr_ratio')),
        'target_room_pct': _quality_optional_num(gate.get('target_room_pct'), row.get('target_room_pct')),
        'invalid_distance_pct': invalid_distance,
        'trigger_gap_pct': _quality_optional_num(row.get('trigger_gap_pct'), (gate.get('structure_plan') or {}).get('distance_pct') if isinstance(gate.get('structure_plan'),dict) else None),
        'price_reaction_pct': _quality_optional_num(row.get('price_reaction_pct'), row.get('reaction_pct'), row.get('change_1m_pct'), row.get('change_1m')),
        'relative_strength_pct': _quality_optional_num(row.get('relative_strength_pct'), row.get('relative_strength')),
        'relative_strength_rank_pct': _quality_optional_num(row.get('relative_strength_rank_pct_v1095')),
        'money_flow_score': _quality_optional_num(row.get('money_flow_score')),
        'buy_ratio': _quality_optional_num(row.get('buy_ratio'), row.get('micro_buy_ratio')),
        'buy_sustain_1m': _quality_optional_num(row.get('buy_sustain_1m'), row.get('buy_sustain_60s'), row.get('micro_buy_ratio_sustain_1m')),
        'turnover_24h': _quality_optional_num(row.get('turnover_24h'), row.get('trade_value_24h'), row.get('acc_trade_price_24h')),
        'volume_ratio': _quality_optional_num(row.get('volume_ratio'), row.get('trade_value_ratio'), row.get('volume_expansion_ratio')),
        'current_quality_rank_score': _quality_optional_num(gate.get('swing_quality_rank_score'), quality_gate.get('rank_score'), row.get('swing_quality_rank_score')),
        'current_quality_tier': str(quality_gate.get('quality_tier') or '').strip() or None,
    }



def _quality_reason_is_quality_v1120(reason: Any) -> bool:
    text=str(reason or '').strip().lower()
    return bool(text.startswith('quality_') or text.startswith('extreme_quality_risk'))


def _quality_clip_v1120(value: float, low: float, high: float) -> float:
    return max(low,min(high,float(value)))


def _quality_policy_variants_v1120(row: Dict[str, Any], gate: Dict[str, Any], metrics: Dict[str, Any]) -> Dict[str, Any]:
    """Seal three observation-only policy decisions at the event time.

    safety_only removes quality-only reasons but never removes structure, trigger,
    RR, target-room, freshness, spread, slippage, liquidity or observation-only
    blocks. current_quality mirrors the live gate. improved_quality is a
    provisional multi-axis selector used only for forward comparison.
    """
    all_reasons=_quality_block_reasons(row,gate)
    safety_reasons=[reason for reason in all_reasons if not _quality_reason_is_quality_v1120(reason)]
    safety_pass=not safety_reasons
    current_pass=bool(gate.get('hard_pass'))
    rr=_quality_optional_num(metrics.get('risk_reward'))
    room=_quality_optional_num(metrics.get('target_room_pct'))
    reaction=_quality_optional_num(metrics.get('price_reaction_pct'))
    relative_rank=_quality_optional_num(metrics.get('relative_strength_rank_pct'))
    relative=_quality_optional_num(metrics.get('relative_strength_pct'))
    money=_quality_optional_num(metrics.get('money_flow_score'))
    buy=_quality_optional_num(metrics.get('buy_ratio'))
    sustain=_quality_optional_num(metrics.get('buy_sustain_1m'))
    spread=_quality_optional_num(metrics.get('spread_pct'))
    slip=_quality_optional_num(metrics.get('confirmed_slippage_pct'))
    chase=_quality_optional_num(metrics.get('trigger_gap_pct'))
    cost=max(0.0,spread or 0.0)+max(0.0,slip or 0.0)

    rr_score=20.0*_quality_clip_v1120(((rr if rr is not None else 1.5)-1.5)/2.5,0.0,1.0)
    room_score=15.0*_quality_clip_v1120(((room if room is not None else 5.0)-5.0)/10.0,0.0,1.0)
    if reaction is None:
        reaction_score=5.0
    elif reaction < -0.20 or reaction > 1.50:
        reaction_score=0.0
    elif reaction <= 0.60:
        reaction_score=15.0*_quality_clip_v1120((reaction+0.20)/0.80,0.0,1.0)
    else:
        reaction_score=15.0*_quality_clip_v1120((1.50-reaction)/0.90,0.0,1.0)
    rel_basis=relative_rank if relative_rank is not None else (50.0+_quality_clip_v1120(relative or 0.0,-2.0,2.0)*15.0)
    relative_score=15.0*_quality_clip_v1120(rel_basis/100.0,0.0,1.0)
    money_score=15.0*_quality_clip_v1120((money if money is not None else 35.0)/100.0,0.0,1.0)
    buy_basis=((buy or 0.0)+(sustain or 0.0))/2.0 if buy is not None and sustain is not None else 0.35
    buy_score=10.0*_quality_clip_v1120((buy_basis-0.35)/0.40,0.0,1.0)
    cost_score=10.0*_quality_clip_v1120((1.20-cost)/1.20,0.0,1.0)
    score=round(rr_score+room_score+reaction_score+relative_score+money_score+buy_score+cost_score,4)

    confirmation_count=sum((
        bool((relative_rank is not None and relative_rank>=60.0) or (relative is not None and relative>0.0)),
        bool(money is not None and money>=55.0),
        bool(buy is not None and sustain is not None and buy>=0.55 and sustain>=0.50),
        bool(reaction is not None and -0.20<=reaction<=0.80),
    ))
    known_axes=sum(value is not None for value in (rr,room,reaction,money,spread))+int(relative_rank is not None or relative is not None)+int(buy is not None and sustain is not None)
    improved_reasons=[]
    if not safety_pass: improved_reasons.append('safety_contract_blocked')
    if known_axes<5: improved_reasons.append('improved_evidence_axes_below_5')
    if confirmation_count<2: improved_reasons.append('improved_confirmation_below_2')
    if reaction is not None and not (-0.20<=reaction<=1.50): improved_reasons.append('improved_reaction_outside_safe_band')
    if chase is not None and chase>0.80: improved_reasons.append('improved_chase_above_0_80')
    if cost>1.20: improved_reasons.append('improved_execution_cost_above_1_20')
    if score<62.0: improved_reasons.append('improved_score_below_62')
    improved_pass=not improved_reasons
    return {
        'schema':'quality_policy_variants_v1120_event_sealed',
        'safety_only':{'selected':safety_pass,'block_reasons':safety_reasons},
        'current_quality':{'selected':current_pass,'block_reasons':all_reasons,'rank_score':metrics.get('current_quality_rank_score'),'tier':metrics.get('current_quality_tier')},
        'improved_quality':{'selected':improved_pass,'block_reasons':improved_reasons,'score':score,'known_axes':known_axes,'confirmation_count':confirmation_count,
            'components':{'rr':round(rr_score,4),'room':round(room_score,4),'reaction':round(reaction_score,4),'relative':round(relative_score,4),'money':round(money_score,4),'buyflow':round(buy_score,4),'cost':round(cost_score,4)}},
        'shared_contract':'same exact candidate event, first executable observed price and unchanged forward price path; no OPEN/cycle limit applied',
        'observation_only':True,'trading_rules_changed':False,'auto_buy':False,
    }


def _quality_eye_epoch_v1124(nowv: float) -> Dict[str, Any]:
    global _QUALITY_EYE_EPOCH_CACHE_V1124
    if _QUALITY_EYE_EPOCH_CACHE_V1124:
        return dict(_QUALITY_EYE_EPOCH_CACHE_V1124)
    obj=load_json(QUALITY_EYE_EPOCH_STATE_V1124,{}) or {}
    if not isinstance(obj,dict) or str(obj.get('schema') or '')!='quality_eye_epoch_v1125' or not obj.get('epoch_id'):
        obj={
            'schema':'quality_eye_epoch_v1125','version':VERSION,'build':BUILD_LABEL,
            'epoch_id':f'quality-eye-v1125-{int(nowv)}','epoch_start_ts':float(nowv),'epoch_start_text':now_text(nowv),
            'identity_contract':'trigger_occurrence_v1037.decision_key exact first; candidate/direct keys audit-only fallbacks',
            'previous_epochs_preserved':True,'observation_only':True,'trading_rules_changed':False,'auto_buy':False,
        }
        save_json(QUALITY_EYE_EPOCH_STATE_V1124,obj)
    _QUALITY_EYE_EPOCH_CACHE_V1124=dict(obj)
    return dict(obj)


def _quality_semantic_snapshot_write_v1124(path: Path, obj: Dict[str, Any], heartbeat_sec: float=60.0) -> bool:
    nowv=float(obj.get('updated_ts') or time.time()) if isinstance(obj,dict) else time.time()
    volatile={'updated_ts','updated_text','age_sec','cycle_sec','heartbeat_due_v1124'}
    stable={str(k):v for k,v in (obj.items() if isinstance(obj,dict) else []) if str(k) not in volatile}
    digest=hashlib.sha256(json.dumps(stable,ensure_ascii=False,sort_keys=True,separators=(',',':'),default=str).encode('utf-8')).hexdigest()
    state=_QUALITY_EYE_SNAPSHOT_CACHE_V1124.setdefault(str(path),{'digest':'','ts':0.0})
    due=(not path.exists()) or nowv-float(state.get('ts') or 0.0)>=heartbeat_sec
    changed=digest!=str(state.get('digest') or '')
    if changed or due:
        payload=dict(obj); payload['semantic_digest_v1124']=digest; payload['semantic_changed_v1124']=changed; payload['heartbeat_due_v1124']=due
        save_json(path,payload); state.update({'digest':digest,'ts':nowv}); return True
    return False



def _quality_identity_evidence_v1126(row: Dict[str, Any]) -> Dict[str, Any]:
    swing_gate = row.get('swing_entry_gate_v977') if isinstance(row.get('swing_entry_gate_v977'), dict) else {}
    trigger_obj = row.get('trigger_occurrence_v1037') if isinstance(row.get('trigger_occurrence_v1037'), dict) else {}
    if not trigger_obj and isinstance(swing_gate.get('trigger_occurrence_v1037'), dict):
        trigger_obj = swing_gate.get('trigger_occurrence_v1037')
    decision = trigger_obj.get('decision_key') if isinstance(trigger_obj, dict) else None
    base_plan = trigger_obj.get('base_plan_decision_key') if isinstance(trigger_obj, dict) else None
    kind = str(trigger_obj.get('kind') or '').strip().upper() if isinstance(trigger_obj, dict) else ''
    sequence = int(_quality_optional_num(trigger_obj.get('sequence')) or 0) if isinstance(trigger_obj, dict) else 0
    audit = {
        'entry_build_key': row.get('entry_build_key'),
        'trigger_occurrence_candidate_key_v1037': row.get('trigger_occurrence_candidate_key_v1037') or (trigger_obj.get('candidate_key') if isinstance(trigger_obj, dict) else None),
        'direct_decision_key_v1124': _quality_direct_decision_key_v1124(row),
    }
    audit_signature = hashlib.sha256(json.dumps(audit, ensure_ascii=False, sort_keys=True, default=str).encode('utf-8')).hexdigest()[:20]
    return {
        'owner_field': 'trigger_occurrence_v1037.decision_key',
        'owner_value': str(decision).strip() if decision not in (None, '', '-', [], {}) else None,
        'base_plan_decision_key': str(base_plan).strip() if base_plan not in (None, '', '-', [], {}) else None,
        'kind': kind or None,
        'sequence': sequence,
        'reset_ts': trigger_obj.get('reset_ts') if isinstance(trigger_obj, dict) else None,
        'rebreak_ts': trigger_obj.get('rebreak_ts') if isinstance(trigger_obj, dict) else None,
        'audit_keys': audit,
        'audit_signature': audit_signature,
    }


def _quality_missing_owner_class_v1128(row: Dict[str, Any], evidence: Dict[str, Any]) -> tuple[str, str, Dict[str, Any]]:
    """Split expected S3 pre-contract rows from actual canonical-owner gaps."""
    swing_gate = row.get('swing_entry_gate_v977') if isinstance(row.get('swing_entry_gate_v977'), dict) else {}
    trigger_obj = row.get('trigger_occurrence_v1037') if isinstance(row.get('trigger_occurrence_v1037'), dict) else {}
    trigger_source = 'row.trigger_occurrence_v1037'
    if not trigger_obj and isinstance(swing_gate.get('trigger_occurrence_v1037'), dict):
        trigger_obj = swing_gate.get('trigger_occurrence_v1037')
        trigger_source = 'swing_entry_gate_v977.trigger_occurrence_v1037'
    stage = str(row.get('s_stage') or row.get('candidate_stage') or row.get('stage') or swing_gate.get('stage') or '-').strip().upper() or '-'
    ticker = ticker_norm(row.get('ticker') or row.get('market') or row.get('symbol'))
    owner_state = str(row.get('trigger_occurrence_owner_state_v1128') or swing_gate.get('trigger_occurrence_owner_state_v1128') or '').strip().upper()
    owner_reason = str(row.get('trigger_occurrence_owner_reason_v1128') or swing_gate.get('trigger_occurrence_owner_reason_v1128') or '').strip()
    trade_capable = bool(row.get('open_eligible') is True or row.get('paper_bot_open') is True or row.get('trade_ready') is True or swing_gate.get('hard_pass') is True or stage in {'S1','S2'})
    trigger_keys = {str(key) for key,value in trigger_obj.items() if value not in (None,'',[],{})} if isinstance(trigger_obj,dict) else set()
    candidate_only_legacy = bool(trigger_obj) and trigger_keys.issubset({'candidate_key','schema'})
    expected_rebreak_v1133 = owner_state == 'EXPECTED_TRIGGER_REBREAK_PRECONTRACT_NO_OWNER_V1133'
    expected_precontract = bool(expected_rebreak_v1133 or owner_state == 'EXPECTED_S3_PRECONTRACT_NO_OWNER' or (stage == 'S3' and not trade_capable and (not trigger_obj or candidate_only_legacy)))
    if expected_precontract:
        code = 'EXPECTED_TRIGGER_REBREAK_PRECONTRACT_NO_OWNER_V1133' if expected_rebreak_v1133 else 'EXPECTED_S3_PRECONTRACT_NO_OWNER'; severity = 'EXPECTED'
    elif not trigger_obj:
        code = 'TRADE_PATH_NO_TRIGGER_OBJECT' if trade_capable else 'NO_TRIGGER_OBJECT'; severity = 'GAP'
    elif trigger_obj.get('decision_key') in (None, '', '-', [], {}):
        code = 'TRIGGER_OBJECT_NO_DECISION_KEY'; severity = 'GAP'
    else:
        code = 'OWNER_VALUE_INVALID'; severity = 'GAP'
    return code, severity, {
        'code': code, 'severity': severity, 'ticker': ticker, 'stage': stage, 'trigger_source': trigger_source,
        'owner_state_v1128': owner_state or None, 'owner_reason_v1128': owner_reason or None,
        'trade_capable': trade_capable, 'trigger_keys': sorted(trigger_keys),
        'trigger_kind': str(trigger_obj.get('kind') or '-') if isinstance(trigger_obj, dict) else '-',
        'trigger_sequence': int(_quality_optional_num(trigger_obj.get('sequence')) or 0) if isinstance(trigger_obj, dict) else 0,
        'entry_build_key': row.get('entry_build_key'),
        'candidate_key': row.get('trigger_occurrence_candidate_key_v1037') or (trigger_obj.get('candidate_key') if isinstance(trigger_obj, dict) else None),
        'direct_decision_key': _quality_direct_decision_key_v1124(row),
        'owner_field': evidence.get('owner_field'),
    }


def _quality_new_event_class_v1126(evidence: Dict[str, Any]) -> str:
    owner = str(evidence.get('owner_value') or '')
    kind = str(evidence.get('kind') or '').upper()
    sequence = int(evidence.get('sequence') or 0)
    if kind == 'REBREAK' or sequence > 0 or '|rebreak:' in owner:
        return 'NEW_RESET_REBREAK'
    return 'NEW_PLAN'


def _quality_eye_empty_aggregate_v1124(epoch: Dict[str, Any]) -> Dict[str, Any]:
    return {
        'schema':'quality_eye_aggregate_v1126','version':VERSION,'build':BUILD_LABEL,
        'epoch_id':epoch.get('epoch_id'),'epoch_start_ts':epoch.get('epoch_start_ts'),
        'final_event_count':0,'ten_minute_completed_event_count':0,'policies':{},'selection_patterns':Counter(),
        'false_pass_10m_provisional':{'no_positive_mfe':0,'negative_after_cost':0,'caught_by_improved':0,'improved_block_reasons':Counter(),'examples':[]},
        'false_pass_60m_final':{'no_positive_mfe':0,'negative_after_cost':0,'caught_by_improved':0,'improved_block_reasons':Counter(),'examples':[]},
        'false_block_60m_final':{'hit_1':0,'hit_5':0,'hit_8':0,'hit_10':0,'recovered_by_improved_hit_1':0,'current_block_reasons':Counter(),'examples':[]},
        'excluded_missing_or_fallback_identity':0,
        'source_signature':[],
    }



def _quality_eye_source_paths_v1124() -> List[tuple[Path,bool]]:
    paths=[(QUALITY_SHADOW_LEDGER,False)]
    if QUALITY_SHADOW_ARCHIVE.exists():
        paths.extend((path,True) for path in sorted(QUALITY_SHADOW_ARCHIVE.glob('quality_shadow_result_*.jsonl.gz')) if path.is_file())
    return paths


def _quality_eye_source_signature_v1124() -> List[Dict[str, Any]]:
    out=[]
    for path,is_gzip in _quality_eye_source_paths_v1124():
        try:
            st=path.stat(); out.append({'path':str(path),'inode':int(st.st_ino),'size':int(st.st_size),'mtime_ns':int(st.st_mtime_ns),'gzip':bool(is_gzip)})
        except OSError:
            out.append({'path':str(path),'inode':0,'size':0,'mtime_ns':0,'gzip':bool(is_gzip)})
    return out


def _quality_eye_policy_bucket_v1124(agg: Dict[str, Any], horizon: str, variant: str) -> Dict[str, Any]:
    policies=agg.setdefault('policies',{})
    hrow=policies.setdefault(horizon,{})
    return hrow.setdefault(variant,{
        'n':0,'raw_n':0,'adjusted_n':0,'mfe_n':0,'mae_n':0,'giveback_n':0,'comparison_ready_n':0,
        'wins':0,'losses':0,'sum_raw_pct':0.0,'sum_cost_adjusted_pct':0.0,
        'sum_mfe_pct':0.0,'sum_mae_pct':0.0,'sum_giveback_pct':0.0,
        'raw_missing':0,'cost_missing':0,'mfe_missing':0,'mae_missing':0,'giveback_missing':0,
        'no_positive_mfe_count':0,'hit_1_count':0,'hit_5_count':0,'hit_8_count':0,'hit_10_count':0,
        'ticker_counts':Counter(),
    })



def _quality_eye_add_example_v1124(items: List[Dict[str, Any]], row: Dict[str, Any], score_key: str, reverse: bool) -> None:
    items.append(row)
    items.sort(key=lambda x:float(_quality_optional_num(x.get(score_key)) or 0.0),reverse=reverse)
    del items[8:]


def _quality_eye_aggregate_add_row_v1124(agg: Dict[str, Any], rec: Dict[str, Any]) -> None:
    epoch_id=str(agg.get('epoch_id') or '')
    if not isinstance(rec,dict) or str(rec.get('quality_eye_epoch_id_v1124') or '')!=epoch_id:
        return
    identity_mode=str(rec.get('identity_mode_v946') or '')
    if identity_mode not in ('trigger_occurrence_decision_exact_v1125','trigger_occurrence_v1037.decision_key'):
        agg['excluded_missing_or_fallback_identity']=int(agg.get('excluded_missing_or_fallback_identity') or 0)+1
        return
    variants=rec.get('policy_variants_v1120') if isinstance(rec.get('policy_variants_v1120'),dict) else {}
    samples=rec.get('samples') if isinstance(rec.get('samples'),dict) else {}
    metrics=rec.get('initial_metrics') if isinstance(rec.get('initial_metrics'),dict) else {}
    spread=_quality_optional_num(metrics.get('spread_pct'))
    slippage=_quality_optional_num(metrics.get('confirmed_slippage_pct'))
    cost=(max(0.0,float(spread))+max(0.0,float(slippage))) if spread is not None and slippage is not None else None
    ticker=ticker_norm(rec.get('ticker'))
    for horizon,_sec in QUALITY_SHADOW_HORIZONS:
        sample=samples.get(horizon) if isinstance(samples.get(horizon),dict) else None
        if not isinstance(sample,dict):
            continue
        raw=_quality_optional_num(sample.get('pct'))
        mfe=_quality_optional_num(sample.get('max_pct'))
        mae=_quality_optional_num(sample.get('min_pct'))
        give=_quality_optional_num(sample.get('giveback_pct'))
        adjusted=(float(raw)-float(cost)) if raw is not None and cost is not None else None
        for variant in ('safety_only','current_quality','improved_quality'):
            decision=variants.get(variant) if isinstance(variants.get(variant),dict) else {}
            if decision.get('selected') is not True:
                continue
            bucket=_quality_eye_policy_bucket_v1124(agg,horizon,variant)
            if raw is None:
                bucket['raw_missing']+=1
            else:
                bucket['n']+=1; bucket['raw_n']+=1; bucket['sum_raw_pct']+=float(raw)
                if ticker: bucket['ticker_counts'][ticker]+=1
            if adjusted is None:
                bucket['cost_missing']+=1
            else:
                bucket['adjusted_n']+=1; bucket['sum_cost_adjusted_pct']+=float(adjusted)
                bucket['wins']+=int(adjusted>0); bucket['losses']+=int(adjusted<0)
            if mfe is None:
                bucket['mfe_missing']+=1
            else:
                bucket['mfe_n']+=1; bucket['sum_mfe_pct']+=float(mfe)
                bucket['no_positive_mfe_count']+=int(mfe<=0.0)
                bucket['hit_1_count']+=int(mfe>=1.0); bucket['hit_5_count']+=int(mfe>=5.0); bucket['hit_8_count']+=int(mfe>=8.0); bucket['hit_10_count']+=int(mfe>=10.0)
            if mae is None:
                bucket['mae_missing']+=1
            else:
                bucket['mae_n']+=1; bucket['sum_mae_pct']+=float(mae)
            if give is None:
                bucket['giveback_missing']+=1
            else:
                bucket['giveback_n']+=1; bucket['sum_giveback_pct']+=float(give)
            if raw is not None and adjusted is not None and mfe is not None and mae is not None:
                bucket['comparison_ready_n']+=1
    s=bool((variants.get('safety_only') or {}).get('selected')) if isinstance(variants.get('safety_only'),dict) else False
    c=bool((variants.get('current_quality') or {}).get('selected')) if isinstance(variants.get('current_quality'),dict) else False
    i=bool((variants.get('improved_quality') or {}).get('selected')) if isinstance(variants.get('improved_quality'),dict) else False
    pattern=f's{int(s)}c{int(c)}i{int(i)}'; agg.setdefault('selection_patterns',Counter())[pattern]+=1

    def add_false_pass(section: Dict[str, Any], sample: Any, horizon: str) -> None:
        if not isinstance(sample,dict):
            return
        maxv=_quality_optional_num(sample.get('max_pct')); minv=_quality_optional_num(sample.get('min_pct')); rawv=_quality_optional_num(sample.get('pct'))
        adjusted=(float(rawv)-float(cost)) if rawv is not None and cost is not None else None
        if c and maxv is not None and maxv<=0.0:
            section['no_positive_mfe']+=1
            improved_reasons=((variants.get('improved_quality') or {}).get('block_reasons') or []) if isinstance(variants.get('improved_quality'),dict) else []
            if not i: section['caught_by_improved']+=1
            for reason in improved_reasons: section['improved_block_reasons'][str(reason)]+=1
            _quality_eye_add_example_v1124(section['examples'],{'ticker':ticker,'event_key':rec.get('quality_event_key_v946'),'horizon':horizon,'max_pct':maxv,'min_pct':minv,'adjusted_pct':adjusted,'improved_selected':i,'improved_block_reasons':list(improved_reasons)[:6]},'min_pct',False)
        if c and adjusted is not None and adjusted<0.0:
            section['negative_after_cost']+=1

    sm10=samples.get('10m') if isinstance(samples.get('10m'),dict) else None
    if isinstance(sm10,dict):
        agg['ten_minute_completed_event_count']=int(agg.get('ten_minute_completed_event_count') or 0)+1
        add_false_pass(agg['false_pass_10m_provisional'],sm10,'10m')

    sm60=samples.get('60m') if isinstance(samples.get('60m'),dict) else None
    if not isinstance(sm60,dict):
        return
    agg['final_event_count']=int(agg.get('final_event_count') or 0)+1
    add_false_pass(agg['false_pass_60m_final'],sm60,'60m')
    maxv=_quality_optional_num(sm60.get('max_pct')); minv=_quality_optional_num(sm60.get('min_pct')); raw60=_quality_optional_num(sm60.get('pct'))
    adjusted60=(float(raw60)-float(cost)) if raw60 is not None and cost is not None else None
    if s and not c and maxv is not None and maxv>=1.0:
        fb=agg['false_block_60m_final']; fb['hit_1']+=1; fb['hit_5']+=int(maxv>=5.0); fb['hit_8']+=int(maxv>=8.0); fb['hit_10']+=int(maxv>=10.0)
        if i: fb['recovered_by_improved_hit_1']+=1
        reasons=((variants.get('current_quality') or {}).get('block_reasons') or []) if isinstance(variants.get('current_quality'),dict) else []
        for reason in reasons: fb['current_block_reasons'][str(reason)]+=1
        _quality_eye_add_example_v1124(fb['examples'],{'ticker':ticker,'event_key':rec.get('quality_event_key_v946'),'horizon':'60m','max_pct':maxv,'min_pct':minv,'adjusted_pct':adjusted60,'improved_selected':i,'current_block_reasons':list(reasons)[:6]},'max_pct',True)



def _quality_eye_jsonable_v1124(value: Any) -> Any:
    if isinstance(value,Counter): return dict(value)
    if isinstance(value,dict): return {str(k):_quality_eye_jsonable_v1124(v) for k,v in value.items()}
    if isinstance(value,list): return [_quality_eye_jsonable_v1124(v) for v in value]
    return value


def _quality_eye_restore_counters_v1124(agg: Dict[str, Any]) -> Dict[str, Any]:
    agg=dict(agg) if isinstance(agg,dict) else {}
    agg['selection_patterns']=Counter(agg.get('selection_patterns') or {})
    for hrow in (agg.get('policies') or {}).values():
        if isinstance(hrow,dict):
            for bucket in hrow.values():
                if isinstance(bucket,dict): bucket['ticker_counts']=Counter(bucket.get('ticker_counts') or {})
    for section,key in (
        ('false_pass_10m_provisional','improved_block_reasons'),
        ('false_pass_60m_final','improved_block_reasons'),
        ('false_block_60m_final','current_block_reasons'),
    ):
        row=agg.get(section) if isinstance(agg.get(section),dict) else {}
        row[key]=Counter(row.get(key) or {}); agg[section]=row
    return agg



def _quality_eye_rebuild_aggregate_v1124(epoch: Dict[str, Any]) -> Dict[str, Any]:
    agg=_quality_eye_empty_aggregate_v1124(epoch); bad=0
    for path,is_gzip in _quality_eye_source_paths_v1124():
        if not path.exists(): continue
        opener=(lambda p=path:gzip.open(p,'rt',encoding='utf-8',errors='ignore')) if is_gzip else (lambda p=path:p.open('r',encoding='utf-8',errors='ignore'))
        with opener() as handle:
            for line in handle:
                try: row=json.loads(line)
                except Exception: bad+=1; continue
                _quality_eye_aggregate_add_row_v1124(agg,row)
    agg['source_signature']=_quality_eye_source_signature_v1124(); agg['rebuilt_at_ts']=time.time(); agg['rebuild_bad_json']=bad
    return agg


def _quality_eye_prepare_aggregate_v1124(epoch: Dict[str, Any]) -> tuple[Dict[str, Any], bool]:
    """Use only a v1126 aggregate; older aggregate schemas rebuild from append-only final rows."""
    global _QUALITY_EYE_AGG_CACHE_V1124
    if _QUALITY_EYE_AGG_CACHE_V1124 is not None:
        return _QUALITY_EYE_AGG_CACHE_V1124, False
    state=load_json(QUALITY_EYE_AGG_STATE_V1124,{}) or {}
    expected_sig=_quality_eye_source_signature_v1124()
    valid=isinstance(state,dict) and str(state.get('schema') or '')=='quality_eye_aggregate_v1126' and str(state.get('epoch_id') or '')==str(epoch.get('epoch_id') or '') and state.get('source_signature')==expected_sig
    rebuilt=not valid
    agg=_quality_eye_restore_counters_v1124(state) if valid else _quality_eye_rebuild_aggregate_v1124(epoch)
    _QUALITY_EYE_AGG_CACHE_V1124=agg
    return agg, rebuilt



def _quality_eye_finalize_bucket_v1124(bucket: Dict[str, Any]) -> Dict[str, Any]:
    n=int(bucket.get('n') or 0); raw_n=int(bucket.get('raw_n') or n); adjusted_n=int(bucket.get('adjusted_n') or 0)
    mfe_n=int(bucket.get('mfe_n') or 0); mae_n=int(bucket.get('mae_n') or 0); give_n=int(bucket.get('giveback_n') or 0)
    ready_n=int(bucket.get('comparison_ready_n') or 0); tickers=Counter(bucket.get('ticker_counts') or {})
    def avg(sum_name: str, count: int) -> Optional[float]:
        return round(float(bucket.get(sum_name) or 0.0)/count,4) if count else None
    return {
        'n':n,'raw_n':raw_n,'adjusted_n':adjusted_n,'mfe_n':mfe_n,'mae_n':mae_n,'giveback_n':give_n,'comparison_ready_n':ready_n,
        'wins':int(bucket.get('wins') or 0),'losses':int(bucket.get('losses') or 0),
        'win_rate_pct':round(int(bucket.get('wins') or 0)/adjusted_n*100.0,2) if adjusted_n else None,
        'raw_avg_pct':avg('sum_raw_pct',raw_n),'cost_adjusted_avg_pct':avg('sum_cost_adjusted_pct',adjusted_n),
        'avg_mfe_pct':avg('sum_mfe_pct',mfe_n),'avg_mae_pct':avg('sum_mae_pct',mae_n),'avg_giveback_pct':avg('sum_giveback_pct',give_n),
        'raw_missing':int(bucket.get('raw_missing') or 0),'cost_missing':int(bucket.get('cost_missing') or 0),'mfe_missing':int(bucket.get('mfe_missing') or 0),'mae_missing':int(bucket.get('mae_missing') or 0),'giveback_missing':int(bucket.get('giveback_missing') or 0),
        'no_positive_mfe_count':int(bucket.get('no_positive_mfe_count') or 0),
        'no_positive_mfe_rate_pct':round(int(bucket.get('no_positive_mfe_count') or 0)/mfe_n*100.0,2) if mfe_n else None,
        'hit_1_count':int(bucket.get('hit_1_count') or 0),'hit_5_count':int(bucket.get('hit_5_count') or 0),'hit_8_count':int(bucket.get('hit_8_count') or 0),'hit_10_count':int(bucket.get('hit_10_count') or 0),
        'unique_tickers':len(tickers),'top_ticker_share_pct':round((tickers.most_common(1)[0][1]/raw_n*100.0),2) if raw_n and tickers else 0.0,
    }



def _quality_eye_status_from_aggregate_v1124(nowv: float, agg: Dict[str, Any], active_rows: List[Dict[str, Any]], epoch: Dict[str, Any]) -> Dict[str, Any]:
    combined=_quality_eye_restore_counters_v1124(_quality_eye_jsonable_v1124(agg))
    active_count=0
    for rec in active_rows:
        if str(rec.get('quality_eye_epoch_id_v1124') or '')!=str(epoch.get('epoch_id') or '') or rec.get('final_appended'):
            continue
        _quality_eye_aggregate_add_row_v1124(combined,rec); active_count+=1
    horizons={}
    for horizon,_sec in QUALITY_SHADOW_HORIZONS:
        hrow={}
        for variant in ('safety_only','current_quality','improved_quality'):
            hrow[variant]=_quality_eye_finalize_bucket_v1124((((combined.get('policies') or {}).get(horizon) or {}).get(variant) or {}))
        horizons[horizon]=hrow
    h60=horizons.get('60m') or {}
    ranked=[]
    for variant,row in h60.items():
        ready_n=int(row.get('comparison_ready_n') or 0); adjusted=_quality_optional_num(row.get('cost_adjusted_avg_pct')); no_mfe=_quality_optional_num(row.get('no_positive_mfe_rate_pct')); hit5=int(row.get('hit_5_count') or 0)
        ranked.append((variant,ready_n,adjusted if adjusted is not None else -999.0,-(no_mfe if no_mfe is not None else 999.0),hit5))
    ranked.sort(key=lambda x:(x[2],x[3],x[4],x[1]),reverse=True)
    min_ready=min([int((h60.get(v) or {}).get('comparison_ready_n') or 0) for v in ('safety_only','current_quality','improved_quality')] or [0])
    ready=min_ready>=QUALITY_EYE_MIN_60M_SAMPLE_V1124
    leader=ranked[0][0] if ranked and ready else None
    fp10=combined.get('false_pass_10m_provisional') if isinstance(combined.get('false_pass_10m_provisional'),dict) else {}
    fp60=combined.get('false_pass_60m_final') if isinstance(combined.get('false_pass_60m_final'),dict) else {}
    fb60=combined.get('false_block_60m_final') if isinstance(combined.get('false_block_60m_final'),dict) else {}
    current60=h60.get('current_quality') or {}; improved60=h60.get('improved_quality') or {}; safety60=h60.get('safety_only') or {}
    shadow_status=_QUALITY_STATUS_CACHE_V1011 if isinstance(_QUALITY_STATUS_CACHE_V1011,dict) else {}
    def delta(a: Any,b: Any) -> Optional[float]:
        av=_quality_optional_num(a); bv=_quality_optional_num(b)
        return round(av-bv,4) if av is not None and bv is not None else None
    def false_pass_view(row: Dict[str, Any]) -> Dict[str, Any]:
        return {'no_positive_mfe':int(row.get('no_positive_mfe') or 0),'negative_after_cost':int(row.get('negative_after_cost') or 0),'caught_by_improved':int(row.get('caught_by_improved') or 0),'improved_block_reason_top':Counter(row.get('improved_block_reasons') or {}).most_common(10),'examples':list(row.get('examples') or [])[:8]}
    false_block_view={'hit_1':int(fb60.get('hit_1') or 0),'hit_5':int(fb60.get('hit_5') or 0),'hit_8':int(fb60.get('hit_8') or 0),'hit_10':int(fb60.get('hit_10') or 0),'recovered_by_improved_hit_1':int(fb60.get('recovered_by_improved_hit_1') or 0),'current_block_reason_top':Counter(fb60.get('current_block_reasons') or {}).most_common(10),'examples':list(fb60.get('examples') or [])[:8]}
    return {
        'schema':'quality_eye_status_v1126','version':VERSION,'build':BUILD_LABEL,'state':'READY_FOR_REVIEW' if ready else 'COLLECTING','updated_ts':nowv,'updated_text':now_text(nowv),
        'epoch_id':epoch.get('epoch_id'),'epoch_start_ts':epoch.get('epoch_start_ts'),'epoch_start_text':epoch.get('epoch_start_text'),
        'identity_owner_field':'trigger_occurrence_v1037.decision_key','identity_contract':'one row per frozen-plan trigger occurrence decision; candidate/scanner/direct keys are audit evidence only; missing owner creates no sample',
        'identity_event_counts_v1126':dict(shadow_status.get('identity_event_counts_v1126') or {}),'identity_owner_missing_this_cycle':int(shadow_status.get('identity_owner_missing_this_cycle_v1126') or 0),
        'finalized_events':int(agg.get('final_event_count') or 0),'ten_minute_completed_events':int(combined.get('ten_minute_completed_event_count') or 0),'active_unfinalized_events':active_count,'minimum_60m_samples_per_policy':QUALITY_EYE_MIN_60M_SAMPLE_V1124,'minimum_ready_n':min_ready,
        'horizons':horizons,'leader_60m':leader,'leader_state':'EVIDENCE_READY' if ready else 'INSUFFICIENT_60M_SAMPLE',
        'delta_improved_vs_current_60m':{'cost_adjusted_avg_pct':delta(improved60.get('cost_adjusted_avg_pct'),current60.get('cost_adjusted_avg_pct')),'avg_mfe_pct':delta(improved60.get('avg_mfe_pct'),current60.get('avg_mfe_pct')),'avg_mae_pct':delta(improved60.get('avg_mae_pct'),current60.get('avg_mae_pct')),'no_positive_mfe_rate_pct':delta(improved60.get('no_positive_mfe_rate_pct'),current60.get('no_positive_mfe_rate_pct'))},
        'delta_current_vs_no_quality_60m':{'cost_adjusted_avg_pct':delta(current60.get('cost_adjusted_avg_pct'),safety60.get('cost_adjusted_avg_pct')),'avg_mfe_pct':delta(current60.get('avg_mfe_pct'),safety60.get('avg_mfe_pct')),'avg_mae_pct':delta(current60.get('avg_mae_pct'),safety60.get('avg_mae_pct')),'no_positive_mfe_rate_pct':delta(current60.get('no_positive_mfe_rate_pct'),safety60.get('no_positive_mfe_rate_pct'))},
        'false_pass_10m_provisional':false_pass_view(fp10),'false_pass_60m_final':false_pass_view(fp60),'false_pass':false_pass_view(fp60),
        'false_block_60m_final':false_block_view,'false_block':false_block_view,
        'selection_patterns':dict(Counter(combined.get('selection_patterns') or {})),
        'missing_value_contract':'MFE/MAE/cost-adjusted values keep separate denominators; missing is PENDING/MISSING and never zero-filled',
        'excluded_missing_or_fallback_identity':int(combined.get('excluded_missing_or_fallback_identity') or 0),
        'comparison_contract':'10m completed rows only for provisional false-pass; 60m completed and comparison-ready rows only for final win rate/averages/leader',
        'actual_quality_gate_changed':False,'actual_rank_changed':False,'open_limit_changed':False,'cycle_limit_changed':False,'exit_changed':False,'auto_buy':False,
    }


def _quality_policy_group_stats_v1120(rows: List[Dict[str, Any]], horizon: str, variant: str) -> Dict[str, Any]:
    selected=[]
    for rec in rows:
        variants=rec.get('policy_variants_v1120') if isinstance(rec.get('policy_variants_v1120'),dict) else {}
        decision=variants.get(variant) if isinstance(variants.get(variant),dict) else {}
        sample=(rec.get('samples') or {}).get(horizon) if isinstance(rec.get('samples'),dict) else None
        if decision.get('selected') is True and isinstance(sample,dict) and _quality_optional_num(sample.get('pct')) is not None:
            selected.append((rec,sample))
    pct_values=[float(_quality_optional_num(sm.get('pct')) or 0.0) for _rec,sm in selected]
    max_values=[float(_quality_optional_num(sm.get('max_pct')) or 0.0) for _rec,sm in selected]
    min_values=[float(_quality_optional_num(sm.get('min_pct')) or 0.0) for _rec,sm in selected]
    give_values=[float(_quality_optional_num(sm.get('giveback_pct')) or 0.0) for _rec,sm in selected]
    adjusted=[]
    for rec,sm in selected:
        metrics=rec.get('initial_metrics') if isinstance(rec.get('initial_metrics'),dict) else {}
        cost=max(0.0,_quality_optional_num(metrics.get('spread_pct')) or 0.0)+max(0.0,_quality_optional_num(metrics.get('confirmed_slippage_pct')) or 0.0)
        adjusted.append(float(_quality_optional_num(sm.get('pct')) or 0.0)-cost)
    tickers=Counter(ticker_norm(rec.get('ticker')) for rec,_sm in selected)
    return {
        'n':len(selected),'unique_tickers':len([t for t in tickers if t]),
        'wins':sum(1 for v in adjusted if v>0),'losses':sum(1 for v in adjusted if v<0),
        'raw_avg_pct':round(sum(pct_values)/len(pct_values),4) if pct_values else None,
        'cost_adjusted_avg_pct':round(sum(adjusted)/len(adjusted),4) if adjusted else None,
        'avg_mfe_pct':round(sum(max_values)/len(max_values),4) if max_values else None,
        'avg_mae_pct':round(sum(min_values)/len(min_values),4) if min_values else None,
        'avg_giveback_pct':round(sum(give_values)/len(give_values),4) if give_values else None,
        'no_positive_mfe_count':sum(1 for v in max_values if v<=0.0),
        'hit_5_count':sum(1 for v in max_values if v>=5.0),'hit_8_count':sum(1 for v in max_values if v>=8.0),'hit_10_count':sum(1 for v in max_values if v>=10.0),
        'top_ticker_share_pct':round((tickers.most_common(1)[0][1]/len(selected)*100.0),2) if selected and tickers else 0.0,
    }


def update_quality_policy_comparison_v1120(nowv: float, records: List[Dict[str, Any]]) -> Dict[str, Any]:
    global _QUALITY_EYE_PENDING_FINAL_ROWS_V1124, _QUALITY_EYE_AGG_CACHE_V1124
    epoch=_quality_eye_epoch_v1124(nowv)
    agg, rebuilt_now=_quality_eye_prepare_aggregate_v1124(epoch)
    pending=list(_QUALITY_EYE_PENDING_FINAL_ROWS_V1124); _QUALITY_EYE_PENDING_FINAL_ROWS_V1124.clear()
    # When the aggregate was rebuilt now, the current ledger scan already included
    # every just-appended pending row.  Applying pending again would double-count it.
    if not rebuilt_now:
        for row in pending:
            _quality_eye_aggregate_add_row_v1124(agg,row)
    if pending or rebuilt_now:
        agg['source_signature']=_quality_eye_source_signature_v1124()
        agg['updated_ts']=nowv; agg['updated_text']=now_text(nowv)
        save_json(QUALITY_EYE_AGG_STATE_V1124,_quality_eye_jsonable_v1124(agg))
    _QUALITY_EYE_AGG_CACHE_V1124=agg
    status=_quality_eye_status_from_aggregate_v1124(nowv,agg,list(records or []),epoch)
    _quality_semantic_snapshot_write_v1124(QUALITY_EYE_STATUS_V1124,status,heartbeat_sec=60.0)
    compat=dict(status)
    compat['schema']='quality_policy_comparison_status_v1126_horizon_identity_truth'
    compat['quality_eye_status_file_v1124']=str(QUALITY_EYE_STATUS_V1124)
    compat['tracked_records']=int(status.get('finalized_events') or 0)+int(status.get('active_unfinalized_events') or 0)
    compat['false_pass_10m_provisional_count']=int((status.get('false_pass_10m_provisional') or {}).get('no_positive_mfe') or 0)
    compat['false_pass_60m_count']=int((status.get('false_pass_60m_final') or {}).get('no_positive_mfe') or 0)
    compat['false_block_60m_count']=int((status.get('false_block_60m_final') or {}).get('hit_1') or 0)
    compat['quality_epoch_id_v1124']=epoch.get('epoch_id'); compat['quality_epoch_start_ts_v1124']=epoch.get('epoch_start_ts')
    _quality_semantic_snapshot_write_v1124(QUALITY_POLICY_COMPARISON_STATUS_V1120,compat,heartbeat_sec=60.0)
    return compat

def _quality_load_final_keys() -> Any:
    class _QualityDedupProxy:
        def __contains__(self, key: object) -> bool: return _dedup_contains_v1013(QUALITY_DEDUP_KIND_V1125,str(key or ''))
        def add(self, key: str) -> None: _dedup_commit_v1013(QUALITY_DEDUP_KIND_V1125,str(key or ''))
        def __len__(self) -> int: return _dedup_count_v1013(QUALITY_DEDUP_KIND_V1125)
    return _QualityDedupProxy()

def _quality_append_final(row: Dict[str, Any]) -> bool:
    global _QUALITY_FINAL_APPEND_CYCLE_V1128, _QUALITY_FINAL_APPEND_LIFETIME_V1128
    key=str(row.get('quality_event_key_v946') or '')
    if not key: raise ValueError('quality_event_key_v946 missing on final append')
    for target in (_QUALITY_FINAL_APPEND_CYCLE_V1128,_QUALITY_FINAL_APPEND_LIFETIME_V1128): target['attempts']=int(target.get('attempts') or 0)+1
    if _dedup_contains_v1013(QUALITY_DEDUP_KIND_V1125,key):
        for target in (_QUALITY_FINAL_APPEND_CYCLE_V1128,_QUALITY_FINAL_APPEND_LIFETIME_V1128): target['duplicate_blocked']=int(target.get('duplicate_blocked') or 0)+1
        return False
    compact_row=_quality_final_compact_v1123(row, _quality_optional_num(row.get('finalized_ts')) or time.time())
    line=(json.dumps(compact_row,ensure_ascii=False,separators=(',',':'),default=str)+'\n').encode('utf-8')
    QUALITY_SHADOW_LEDGER.parent.mkdir(parents=True,exist_ok=True)
    with QUALITY_SHADOW_LEDGER.open('ab') as handle:
        handle.write(line); handle.flush(); os.fsync(handle.fileno())
    _QUALITY_EYE_PENDING_FINAL_ROWS_V1124.append(dict(compact_row))
    _dedup_commit_v1013(QUALITY_DEDUP_KIND_V1125,key)
    for target in (_QUALITY_FINAL_APPEND_CYCLE_V1128,_QUALITY_FINAL_APPEND_LIFETIME_V1128):
        target['appended']=int(target.get('appended') or 0)+1
        target['bytes_appended']=int(target.get('bytes_appended') or 0)+len(line)
    return True

def _quality_rotate_ledger(nowv: float) -> Dict[str, Any]:
    result=_v1080_rotate_whole_jsonl(
        QUALITY_SHADOW_LEDGER, QUALITY_SHADOW_ARCHIVE, 'quality_shadow_result',
        QUALITY_SHADOW_LEDGER_MAX_BYTES, QUALITY_SHADOW_ARCHIVE_MAX_FILES_V1080, QUALITY_SHADOW_ARCHIVE_MAX_BYTES_V1080,
    )
    result['policy_v1080']='whole active segment rollover; archive count and total bytes bounded'
    return result

def _quality_percentile(values: List[float], q: float) -> Optional[float]:
    vals=sorted(float(v) for v in values if isinstance(v,(int,float)))
    if not vals: return None
    pos=(len(vals)-1)*max(0.0,min(1.0,float(q)))
    lo=int(pos); hi=min(len(vals)-1,lo+1); frac=pos-lo
    return vals[lo]*(1.0-frac)+vals[hi]*frac


def _quality_metric_stats(vals: List[float], peaks: List[float], troughs: List[float], givebacks: List[float]) -> Dict[str, Any]:
    if not vals: return {}
    return {
        'n':len(vals),
        'avg_pct':round(sum(vals)/len(vals),4),
        'median_pct':round(_quality_percentile(vals,0.50),4),
        'p10_pct':round(_quality_percentile(vals,0.10),4),
        'p90_pct':round(_quality_percentile(vals,0.90),4),
        'positive_0_1_count':sum(1 for v in vals if v>=0.10),
        'negative_0_1_count':sum(1 for v in vals if v<=-0.10),
        'avg_max_pct':round(sum(peaks)/len(peaks),4) if peaks else None,
        'avg_min_pct':round(sum(troughs)/len(troughs),4) if troughs else None,
        'avg_giveback_pct':round(sum(givebacks)/len(givebacks),4) if givebacks else None,
    }



def _quality_summary_stats(rows: List[Dict[str, Any]]) -> Dict[str, Any]:
    """One pass over records/horizons; the old code rescanned every cohort 12 times."""
    cohorts: Dict[str, Dict[str, Any]] = {}
    occurrence_first: Dict[str, Dict[str, Dict[str, Any]]] = {}
    for row in rows:
        cohort = str(row.get('cohort') or 'unknown')
        bucket = cohorts.setdefault(cohort, {'tracked': 0, '_metric': {}, '_occ_metric': {}})
        bucket['tracked'] += 1
        occ = str(row.get('hot_watch_occurrence_key_v945') or '').strip()
        if occ:
            occ_map = occurrence_first.setdefault(cohort, {})
            prior = occ_map.get(occ)
            if prior is None or (_quality_optional_num(row.get('first_seen_ts')) or 0.0) < (_quality_optional_num(prior.get('first_seen_ts')) or 0.0):
                occ_map[occ] = row
        samples = row.get('samples') if isinstance(row.get('samples'), dict) else {}
        for label, _sec in QUALITY_SHADOW_HORIZONS:
            sample = samples.get(label)
            if not isinstance(sample, dict):
                continue
            metric = bucket['_metric'].setdefault(label, [[], [], [], []])
            for index, key in enumerate(('pct','max_pct','min_pct','giveback_pct')):
                value = _quality_optional_num(sample.get(key))
                if value is not None:
                    metric[index].append(value)
    out: Dict[str, Any] = {}
    for cohort, bucket in cohorts.items():
        item: Dict[str, Any] = {'tracked': int(bucket['tracked'])}
        occ_rows = list(occurrence_first.get(cohort, {}).values())
        item['unique_hot_occurrences'] = len(occ_rows)
        for label, _sec in QUALITY_SHADOW_HORIZONS:
            metric = bucket['_metric'].get(label)
            if metric:
                stats = _quality_metric_stats(*metric)
                if stats:
                    item[label] = stats
            occ_metric = [[], [], [], []]
            for row in occ_rows:
                samples = row.get('samples') if isinstance(row.get('samples'), dict) else {}
                sample = samples.get(label)
                if not isinstance(sample, dict):
                    continue
                for index, key in enumerate(('pct','max_pct','min_pct','giveback_pct')):
                    value = _quality_optional_num(sample.get(key))
                    if value is not None:
                        occ_metric[index].append(value)
            occ_stats = _quality_metric_stats(*occ_metric)
            if occ_stats:
                item[label + '_occurrence'] = occ_stats
        out[cohort] = item
    return out




def _late_num(value: Any) -> Optional[float]:
    return _quality_optional_num(value)


def _late_nested_values(row: Dict[str, Any]) -> List[Dict[str, Any]]:
    out=[row]
    for key in ('paper_timing_spine_v940','quality_evidence_v938','quality_evidence_v936','entry_diagnostics'):
        obj=row.get(key) if isinstance(row,dict) else None
        if isinstance(obj,dict): out.append(obj)
    diag=row.get('entry_diagnostics') if isinstance(row,dict) and isinstance(row.get('entry_diagnostics'),dict) else {}
    for key in ('paper_timing_spine_v940','quality_evidence_v938','quality_evidence_v936'):
        obj=diag.get(key) if isinstance(diag,dict) else None
        if isinstance(obj,dict): out.append(obj)
    return out


def _late_first(row: Dict[str, Any], keys: tuple[str,...]) -> Any:
    for obj in _late_nested_values(row):
        for key in keys:
            value=obj.get(key)
            if value not in (None,'',[],{}): return value
    return None


def _late_stage_stats(values: List[float]) -> Dict[str, Any]:
    vals=[float(v) for v in values if isinstance(v,(int,float)) and v>=0]
    if not vals: return {'n':0}
    return {
        'n':len(vals),'avg_sec':round(sum(vals)/len(vals),3),'median_sec':round(_quality_percentile(vals,0.50),3),
        'p90_sec':round(_quality_percentile(vals,0.90),3),'max_sec':round(max(vals),3),
        'gt60_count':sum(1 for v in vals if v>=60.0),'gt180_count':sum(1 for v in vals if v>=180.0),
    }


def _late_outcome_quartiles(rows: List[Dict[str, Any]], delay_key: str, sample_label: str='10m') -> Dict[str, Any]:
    pairs=[]
    for rec in rows:
        delay=_late_num((rec.get('initial_metrics') or {}).get(delay_key) if isinstance(rec.get('initial_metrics'),dict) else None)
        sample=(rec.get('samples') or {}).get(sample_label) if isinstance(rec.get('samples'),dict) else None
        pct=_late_num(sample.get('pct')) if isinstance(sample,dict) else None
        if delay is not None and pct is not None: pairs.append((delay,pct,rec))
    if len(pairs)<4: return {'n':len(pairs),'sample_label':sample_label}
    delays=[x[0] for x in pairs]; q25=_quality_percentile(delays,0.25); q75=_quality_percentile(delays,0.75)
    def bundle(selected):
        vals=[x[1] for x in selected]
        return {'n':len(vals),'avg_pct':round(sum(vals)/len(vals),4) if vals else None,'median_pct':round(_quality_percentile(vals,0.50),4) if vals else None,'positive_0_1_count':sum(1 for v in vals if v>=0.1),'negative_0_1_count':sum(1 for v in vals if v<=-0.1)}
    fast=[x for x in pairs if x[0]<=q25]; slow=[x for x in pairs if x[0]>=q75]
    return {'n':len(pairs),'sample_label':sample_label,'q25_sec':round(q25,3),'q75_sec':round(q75,3),'fast':bundle(fast),'slow':bundle(slow)}


def _late_occurrence_rows(records: List[Dict[str, Any]]) -> List[Dict[str, Any]]:
    by_occ: Dict[str, Dict[str, Any]]={}
    no_occ=[]
    timing_names=('scanner_to_candidate_sec','scanner_to_s2_sec','scanner_to_s1_sec')
    for rec in records:
        occ=str(rec.get('hot_watch_occurrence_key_v945') or '').strip()
        if not occ:
            no_occ.append(rec); continue
        cur=by_occ.get(occ)
        if cur is None:
            by_occ[occ]=dict(rec); continue
        cur_ts=_late_num(cur.get('first_seen_ts')) or 0.0; new_ts=_late_num(rec.get('first_seen_ts')) or 0.0
        if new_ts and (not cur_ts or new_ts<cur_ts):
            base=dict(rec); prior=cur
        else:
            base=cur; prior=rec
        merged=base.get('initial_metrics') if isinstance(base.get('initial_metrics'),dict) else {}
        other=prior.get('initial_metrics') if isinstance(prior.get('initial_metrics'),dict) else {}
        for name in timing_names:
            values=[v for v in (_late_num(merged.get(name)),_late_num(other.get(name))) if v is not None]
            if values: merged[name]=min(values)
        base['initial_metrics']=merged
        by_occ[occ]=base
    return list(by_occ.values())+no_occ


def update_late_path_status(nowv: float, quality_records: List[Dict[str, Any]]) -> Dict[str, Any]:
    """Review-owned latency decomposition. Read-only observation; never used by entry/exit."""
    occurrence_rows=_late_occurrence_rows(quality_records)
    stage_values={'scanner_to_candidate_sec':[],'scanner_to_s2_sec':[],'scanner_to_s1_sec':[],'candidate_to_s2_sec':[],'s2_to_s1_sec':[]}
    samples=[]
    for rec in occurrence_rows:
        metrics=rec.get('initial_metrics') if isinstance(rec.get('initial_metrics'),dict) else {}
        c=_late_num(metrics.get('scanner_to_candidate_sec')); s2=_late_num(metrics.get('scanner_to_s2_sec')); s1=_late_num(metrics.get('scanner_to_s1_sec'))
        if c is not None: stage_values['scanner_to_candidate_sec'].append(c)
        if s2 is not None: stage_values['scanner_to_s2_sec'].append(s2)
        if s1 is not None: stage_values['scanner_to_s1_sec'].append(s1)
        if c is not None and s2 is not None and s2>=c: stage_values['candidate_to_s2_sec'].append(s2-c)
        if s2 is not None and s1 is not None and s1>=s2: stage_values['s2_to_s1_sec'].append(s1-s2)
        if any(v is not None and v>=60 for v in (c,s2,s1)):
            samples.append({'ticker':rec.get('ticker'),'occurrence_key':rec.get('hot_watch_occurrence_key_v945'),'scanner_to_candidate_sec':c,'scanner_to_s2_sec':s2,'scanner_to_s1_sec':s1,'cohort':rec.get('cohort'),'m10_pct':_late_num(((rec.get('samples') or {}).get('10m') or {}).get('pct')) if isinstance(rec.get('samples'),dict) else None})
    decision_obj=load_json(PAPER_DECISION_STATE,{}) or {}
    decision_records=decision_obj.get('records') if isinstance(decision_obj,dict) and isinstance(decision_obj.get('records'),dict) else {}
    paper_values={'first_to_open_sec':[],'s1_to_selected_sec':[],'trigger_to_selected_sec':[],'selected_to_open_sec':[],'trigger_to_open_sec':[]}
    for raw in decision_records.values():
        if not isinstance(raw,dict): continue
        mappings={
            'first_to_open_sec':('first_to_open_delay_sec','first_to_paper_delay_sec'),
            's1_to_selected_sec':('s1_to_selected_delay_sec',),
            'trigger_to_selected_sec':('trigger_to_selected_delay_sec',),
            'selected_to_open_sec':('selected_to_open_delay_sec','selected_delay_sec'),
            'trigger_to_open_sec':('trigger_to_open_delay_sec',),
        }
        for name,keys in mappings.items():
            value=_late_num(_late_first(raw,keys))
            if value is not None and value>=0: paper_values[name].append(value)
    stages={name:_late_stage_stats(vals) for name,vals in stage_values.items()}
    paper={name:_late_stage_stats(vals) for name,vals in paper_values.items()}
    outcome={name:_late_outcome_quartiles(occurrence_rows,name,'10m') for name in ('scanner_to_candidate_sec','scanner_to_s2_sec','scanner_to_s1_sec')}
    bottlenecks=[]
    for name,stats in stages.items():
        if stats.get('n'):
            bottlenecks.append({'stage':name,**stats})
    bottlenecks.sort(key=lambda x:(x.get('p90_sec') or 0.0,x.get('max_sec') or 0.0),reverse=True)
    status={
        'schema':'late_path_status_v947','version':'review_worker_v0.948','build':'late_exact_stage_decomposition_v947_2026-06-19','state':'ACTIVE',
        'updated_ts':nowv,'updated_text':now_text(nowv),'quality_exact_records':len(quality_records),'occurrence_normalized_records':len(occurrence_rows),
        'stages':stages,'paper_stages':paper,'outcome_quartiles_10m':outcome,'bottleneck_order':bottlenecks[:5],
        'slow_samples':sorted(samples,key=lambda x:max([v for v in (x.get('scanner_to_candidate_sec'),x.get('scanner_to_s2_sec'),x.get('scanner_to_s1_sec')) if isinstance(v,(int,float))] or [0]),reverse=True)[:8],
        'identity_policy':'hot occurrence normalized for latency distribution; exact candidate records remain source evidence; ticker never joins final results',
        'policy':'observation only; no S grade, trigger, entry, exit, protection or cost criteria change',
        'conditions_changed':False,'trigger_changed':False,'paper_open_changed':False,'exit_changed':False,'auto_buy':False,
    }
    save_json(LATE_PATH_STATUS,status)
    return status


def _migrate_quality_event_context_once(records: Dict[str, Dict[str, Any]], state_obj: Dict[str, Any], nowv: float) -> tuple[int, Dict[str, Any]]:
    """One-time v965 cutover: distrust all prior context, preserve price paths, then trust only events created after this cutover."""
    marker = state_obj.get('event_context_migration') if isinstance(state_obj, dict) and isinstance(state_obj.get('event_context_migration'), dict) else {}
    if marker.get('schema') == QUALITY_EVENT_CONTEXT_MIGRATION_SCHEMA and marker.get('done') is True:
        return 0, marker
    removed_fields = (
        'turnover_24h','volume_ratio','turnover_change_pct','market_strength','market_regime',
        'market_regime_mode','market_regime_summary','market_regime_tags','market_risk_tags',
        'market_context_source','market_context_sealed',
    )
    changed = 0
    for rec in records.values():
        if not isinstance(rec, dict):
            continue
        metrics = rec.get('initial_metrics') if isinstance(rec.get('initial_metrics'), dict) else {}
        for key in removed_fields:
            metrics.pop(key, None)
        rec['initial_metrics'] = metrics
        rec['event_context'] = _legacy_missing_event_context()
        changed += 1
    marker = {
        'schema': QUALITY_EVENT_CONTEXT_MIGRATION_SCHEMA,
        'done': True,
        'migrated_at_ts': nowv,
        'migrated_at_text': now_text(nowv),
        'records_reset_to_legacy_missing': changed,
        'policy': 'v965 one-time cutover; every existing event becomes legacy missing; only newly created events receive immutable context',
    }
    return changed, marker


def _quality_policy_variants_compact_v1123(value: Any) -> Dict[str, Any]:
    """Remove repeated prose while preserving every comparison decision/score."""
    src=value if isinstance(value,dict) else {}
    out={'schema':'quality_policy_variants_v1123_compact'}
    for name in ('safety_only','current_quality','improved_quality'):
        row=src.get(name) if isinstance(src.get(name),dict) else {}
        if not row:
            continue
        item={}
        for key in ('selected','score','known_axes','confirmation_count','rank_score','tier'):
            if row.get(key) not in (None,'',[],{}): item[key]=row.get(key)
        reasons=row.get('block_reasons') if isinstance(row.get('block_reasons'),list) else []
        if reasons: item['block_reasons']=[str(x) for x in reasons[:12]]
        comps=row.get('components') if isinstance(row.get('components'),dict) else {}
        if comps: item['components']={str(k):v for k,v in comps.items() if v not in (None,'',[],{})}
        out[name]=item
    return out


def _quality_final_compact_v1123(rec: Dict[str, Any], nowv: Optional[float]=None) -> Dict[str, Any]:
    """Append only fields required by the three-policy forward comparison."""
    nowv=float(nowv or time.time())
    active=_quality_active_compact_v1007(rec)
    keep=(
        'quality_event_key_v946','identity_mode_v946','identity_owner_field_v1126','identity_owner_value_v1126','identity_event_class_v1126','identity_base_plan_decision_key_v1126','identity_kind_v1126','identity_sequence_v1126','identity_audit_signature_first_v1126','identity_audit_signature_last_v1126','entry_build_key','minimal_gate_decision_key_v925','direct_decision_key_v1124','trigger_occurrence_candidate_key_v1037','quality_eye_epoch_id_v1124','quality_eye_epoch_start_ts_v1124',
        'ticker','hot_watch_occurrence_key_v945','first_seen_ts','first_price','cohort','hard_block_reasons',
        'max_pct','min_pct','giveback_pct','current_pct','initial_metrics','event_context','samples','policy_variants_v1120',
    )
    out={k:active.get(k) for k in keep if active.get(k) not in (None,'',[],{})}
    out.update({'schema':'quality_shadow_result_v1125_compact','version':VERSION,'build':BUILD_LABEL,
                'finalized_ts':nowv,'finalized_text':now_text(nowv),
                'storage_compact_v1125':True,'observation_only':True,'trading_rules_changed':False,'auto_buy':False})
    return out


def _quality_active_compact_v1007(rec: Dict[str, Any]) -> Dict[str, Any]:
    """Canonical compact in-memory and durable row for active quality tracking."""
    metric_keep=(
        'spread_pct','scanner_to_candidate_sec','scanner_to_s2_sec','scanner_to_s1_sec',
        'first_price','confirmed_slippage_pct','confirmed_slippage_source',
        'risk_reward','target_room_pct','invalid_distance_pct','trigger_gap_pct','price_reaction_pct',
        'relative_strength_pct','relative_strength_rank_pct','money_flow_score','buy_ratio','buy_sustain_1m',
        'turnover_24h','volume_ratio','current_quality_rank_score','current_quality_tier',
    )
    context_keep=(
        'schema','sealed_at_ts','market_regime','market_mode','market_strength',
        'market_context_source','market_context_sealed','turnover_24h','volume_ratio',
        'turnover_change_pct','turnover_context_source','turnover_context_sealed',
        'immutable_event_time_context','legacy_before_v965_context_spine',
    )
    sample_keep=('ts','price','pct','max_pct','min_pct','giveback_pct')
    metrics=rec.get('initial_metrics') if isinstance(rec.get('initial_metrics'),dict) else {}
    context=rec.get('event_context') if isinstance(rec.get('event_context'),dict) else {}
    samples=rec.get('samples') if isinstance(rec.get('samples'),dict) else {}
    compact_samples={}
    for label,sample in samples.items():
        if not isinstance(sample,dict):
            continue
        compact={k:sample.get(k) for k in sample_keep if sample.get(k) not in (None,'',[],{})}
        if compact: compact_samples[str(label)]=compact
    keep=(
        'quality_event_key_v946','identity_mode_v946','identity_owner_field_v1126','identity_owner_value_v1126','identity_event_class_v1126','identity_base_plan_decision_key_v1126','identity_kind_v1126','identity_sequence_v1126','identity_audit_signature_first_v1126','identity_audit_signature_last_v1126','entry_build_key','minimal_gate_decision_key_v925','direct_decision_key_v1124','trigger_occurrence_candidate_key_v1037','quality_eye_epoch_id_v1124','quality_eye_epoch_start_ts_v1124',
        'ticker','hot_watch_occurrence_key_v945','first_seen_ts','first_price','stage_at_first','hard_pass_at_first',
        'ever_hard_pass','first_pass_ts','cohort','hard_block_reasons','max_pct','min_pct','giveback_pct',
        'last_price','last_seen_ts','last_candidate_seen_ts','final_appended','finalized_ts','last_hard_pass','last_stage',
        'last_hard_block_reasons','current_pct','age_sec','observation_only','used_for_entry_gate','used_for_exit',
        'next_review_due_ts_v1011',
    )
    out={k:rec.get(k) for k in keep if rec.get(k) not in (None,'',[],{})}
    compact_metrics={k:metrics.get(k) for k in metric_keep if metrics.get(k) not in (None,'',[],{})}
    compact_context={k:context.get(k) for k in context_keep if context.get(k) not in (None,'',[],{})}
    if compact_metrics: out['initial_metrics']=compact_metrics
    if compact_context: out['event_context']=compact_context
    if compact_samples: out['samples']=compact_samples
    compact_variants=_quality_policy_variants_compact_v1123(rec.get('policy_variants_v1120'))
    if len(compact_variants)>1: out['policy_variants_v1120']=compact_variants
    out['schema']='quality_shadow_state_row_v1012_compact'
    out['quality_active_compact_v1012']=True
    return out


# v1127 durable active-state contract: unfinished rows only, packed arrays,
# no repeated constant keys. The append-only final ledger and aggregate remain
# the only owners of completed 60m rows.
_QUALITY_STATE_PACK_FIELDS_V1127 = (
    'identity_mode_v946','identity_owner_value_v1126','identity_event_class_v1126',
    'identity_base_plan_decision_key_v1126','identity_kind_v1126','identity_sequence_v1126',
    'identity_audit_signature_first_v1126','identity_audit_signature_last_v1126',
    'entry_build_key','minimal_gate_decision_key_v925','direct_decision_key_v1124',
    'trigger_occurrence_candidate_key_v1037','quality_eye_epoch_id_v1124','quality_eye_epoch_start_ts_v1124',
    'ticker','hot_watch_occurrence_key_v945','first_seen_ts','first_price','stage_at_first',
    'hard_pass_at_first','ever_hard_pass','first_pass_ts','cohort','hard_block_reasons',
    'max_pct','min_pct','giveback_pct','last_price','last_seen_ts','last_candidate_seen_ts',
    'last_hard_pass','last_stage','last_hard_block_reasons','current_pct','age_sec',
    'next_review_due_ts_v1011','initial_metrics','event_context','samples','policy_variants_v1120',
)


def _quality_state_pack_record_v1127(key: str, rec: Dict[str, Any]) -> List[Any]:
    compact=_quality_active_compact_v1007(rec)
    values=[compact.get(field) for field in _QUALITY_STATE_PACK_FIELDS_V1127]
    while values and values[-1] is None:
        values.pop()
    return [str(key), values]


def _quality_state_unpack_record_v1127(item: Any) -> tuple[Optional[str], Optional[Dict[str, Any]]]:
    if not isinstance(item,list) or len(item)<2 or not isinstance(item[1],list):
        return None,None
    key=str(item[0] or '').strip()
    if not key:
        return None,None
    values=item[1]
    rec={field:values[index] for index,field in enumerate(_QUALITY_STATE_PACK_FIELDS_V1127) if index<len(values) and values[index] is not None}
    rec.update({
        'quality_event_key_v946':key,
        'identity_owner_field_v1126':'trigger_occurrence_v1037.decision_key',
        'final_appended':False,
        'observation_only':True,
        'used_for_entry_gate':False,
        'used_for_exit':False,
        'schema':'quality_shadow_state_row_v1127_packed_active',
        'quality_active_compact_v1012':True,
    })
    return key,rec


def _quality_state_records_from_obj_v1127(obj: Any) -> tuple[Dict[str, Dict[str, Any]], Dict[str, Any]]:
    if not isinstance(obj,dict):
        return {},{'schema':'missing','packed':False,'raw_rows':0}
    if obj.get('schema')=='quality_shadow_state_v1127_packed_active':
        rows=obj.get('records_packed_v1127') if isinstance(obj.get('records_packed_v1127'),list) else []
        out={}
        invalid=0
        for item in rows:
            key,rec=_quality_state_unpack_record_v1127(item)
            if key and isinstance(rec,dict): out[key]=rec
            else: invalid+=1
        return out,{'schema':obj.get('schema'),'packed':True,'raw_rows':len(rows),'invalid_rows':invalid}
    records_obj=obj.get('records') if isinstance(obj.get('records'),dict) else {}
    out={str(key):_quality_active_compact_v1007(value) for key,value in records_obj.items() if isinstance(value,dict) and not value.get('final_appended')}
    return out,{'schema':str(obj.get('schema') or 'legacy_dict'),'packed':False,'raw_rows':len(records_obj),'terminal_rows_dropped_on_load':sum(1 for value in records_obj.values() if isinstance(value,dict) and value.get('final_appended'))}


def _quality_state_payload_v1127(records: Dict[str, Dict[str, Any]], nowv: float, revision: int, ledger_rows: int, event_context_migration: Dict[str, Any]) -> Dict[str, Any]:
    packed=[_quality_state_pack_record_v1127(key,value) for key,value in records.items() if isinstance(value,dict) and not value.get('final_appended')]
    return {
        'schema':'quality_shadow_state_v1127_packed_active','version':VERSION,'build':BUILD_LABEL,
        'updated_ts':nowv,'updated_text':now_text(nowv),
        'analysis_revision_v1009':revision,'analysis_revision_v1010':revision,
        'final_ledger_rows':ledger_rows,'event_context_migration':event_context_migration,
        'retention_sec_v1007':QUALITY_SHADOW_RETENTION_SEC,
        'safety_max_v1007':QUALITY_SHADOW_SAFETY_MAX_RECORDS,
        'checkpoint_interval_sec_v1011':QUALITY_SHADOW_CHECKPOINT_SEC,
        'storage_contract_v1127':'unfinished active rows only; packed arrays; completed rows only in append-only final ledger and cumulative aggregate',
        'record_fields_v1127':list(_QUALITY_STATE_PACK_FIELDS_V1127),
        'active_unfinished_rows_v1127':len(packed),
        'terminal_rows_in_state_v1127':0,
        'records_packed_v1127':packed,
    }


def _quality_compact_state_file_v1012(path: Path) -> Dict[str, Any]:
    """One-time legacy-state compaction owner.

    This function is intended to run in a short-lived helper process.  Loading
    the legacy 83MB nested JSON in the long-lived review worker caused Python's
    allocator to retain a >1GB heap even after the records were compacted.
    The helper absorbs that one-time peak, writes the compact state atomically,
    and exits; the real worker then loads only the compact file.
    """
    started=time.time(); before_bytes=path.stat().st_size if path.exists() else 0
    obj=load_json(path,{}) or {}
    records,load_meta=_quality_state_records_from_obj_v1127(obj)
    nowv=time.time()
    out=_quality_state_payload_v1127(
        records,nowv,
        int(obj.get('analysis_revision_v1010') or obj.get('analysis_revision_v1009') or 0) if isinstance(obj,dict) else 0,
        int(obj.get('final_ledger_rows') or 0) if isinstance(obj,dict) else 0,
        obj.get('event_context_migration') if isinstance(obj,dict) and isinstance(obj.get('event_context_migration'),dict) else {},
    )
    out['external_migration_v1012']=True
    out['source_storage_v1127']=load_meta
    save_json(path,out)
    after_bytes=path.stat().st_size if path.exists() else 0
    return {'ok':True,'records':len(records),'before_bytes':before_bytes,'after_bytes':after_bytes,'saved_bytes':max(0,before_bytes-after_bytes),'sec':round(time.time()-started,3)}


def _quality_prepare_state_file_v1012() -> Dict[str, Any]:
    """Compact a large legacy state outside the long-lived process."""
    global _QUALITY_EXTERNAL_MIGRATION_V1012
    if _QUALITY_EXTERNAL_MIGRATION_V1012:
        return _QUALITY_EXTERNAL_MIGRATION_V1012
    try:
        if not QUALITY_SHADOW_STATE.exists():
            result={'ok':True,'needed':False,'reason':'state_missing'}
        else:
            size=QUALITY_SHADOW_STATE.stat().st_size
            head=''
            try:
                with QUALITY_SHADOW_STATE.open('r',encoding='utf-8',errors='ignore') as handle:
                    head=handle.read(512)
            except OSError:
                head=''
            already_compact='quality_shadow_state_v1012_compact_semantic_incremental' in head
            if already_compact or size <= 16*1024*1024:
                result={'ok':True,'needed':False,'reason':'already_compact_or_small','bytes':size}
            elif os.getenv('REVIEW_V1012_COMPACTOR_CHILD')=='1':
                result=_quality_compact_state_file_v1012(QUALITY_SHADOW_STATE); result['needed']=True; result['mode']='child_direct'
            else:
                env=dict(os.environ); env['REVIEW_V1012_COMPACTOR_CHILD']='1'
                proc=subprocess.run([sys.executable,str(Path(__file__).resolve()),'--compact-quality-state-v1012',str(QUALITY_SHADOW_STATE)],
                                    stdout=subprocess.PIPE,stderr=subprocess.PIPE,text=True,timeout=240,env=env,check=False)
                payload={}
                if proc.stdout.strip():
                    try: payload=json.loads(proc.stdout.strip().splitlines()[-1])
                    except Exception: payload={'stdout_tail':proc.stdout.strip()[-500:]}
                result={'ok':proc.returncode==0 and bool(payload.get('ok')),'needed':True,'mode':'short_lived_helper','returncode':proc.returncode,
                        'payload':payload,'stderr_tail':proc.stderr.strip()[-500:]}
                if not result['ok']:
                    append_error(ERROR,'quality_external_compactor_v1012',RuntimeError(str(result)))
        _QUALITY_EXTERNAL_MIGRATION_V1012=result
        return result
    except Exception as exc:
        append_error(ERROR,'quality_prepare_state_v1012',exc)
        result={'ok':False,'needed':None,'error':f'{exc.__class__.__name__}: {exc}'}
        _QUALITY_EXTERNAL_MIGRATION_V1012=result
        return result


def update_quality_shadow(nowv: float, fmap: Dict[str, Dict[str, Any]], ofmap: Dict[str, Dict[str, Any]], source_rows_input: Optional[List[Dict[str, Any]]]=None, regime_snapshot_input: Optional[Dict[str, Any]]=None) -> tuple[Dict[str, Any], List[Dict[str, Any]]]:
    """Incremental observation state: one process cache, due-only price work, bounded durable checkpoints."""
    global _QUALITY_LAST_CHECKPOINT_V1010, _QUALITY_STATE_CACHE_V1011, _QUALITY_STATE_META_V1011
    global _QUALITY_STATUS_CACHE_V1011, _QUALITY_LAST_SUMMARY_V1011, _QUALITY_LAST_ROTATION_V1011
    global _QUALITY_FINAL_APPEND_CYCLE_V1128
    _QUALITY_FINAL_APPEND_CYCLE_V1128={'attempts':0,'appended':0,'duplicate_blocked':0,'bytes_appended':0}
    try: ledger_size_before_cycle_v1128=QUALITY_SHADOW_LEDGER.stat().st_size
    except OSError: ledger_size_before_cycle_v1128=0

    quality_eye_epoch_v1124=_quality_eye_epoch_v1124(nowv)
    source_rows = [row for row in (source_rows_input if source_rows_input is not None else _persistent_jsonl_tail_v1011(PAPER_LATEST, SOURCE_SNAPSHOT_LINES)) if isinstance(row, dict)]
    regime_snapshot = regime_snapshot_input if isinstance(regime_snapshot_input, dict) else (load_json(REGIME,{}) or {})

    loaded_from_disk = False
    loaded_records_raw = len(_QUALITY_STATE_CACHE_V1011 or {})
    loaded_storage_v1127={'schema':'memory_cache','packed':None,'raw_rows':loaded_records_raw}
    if _QUALITY_STATE_CACHE_V1011 is None:
        migration_v1012=_quality_prepare_state_file_v1012()
        state_obj=load_json(QUALITY_SHADOW_STATE,{}) or {}
        unpacked_records_v1127,loaded_storage_v1127=_quality_state_records_from_obj_v1127(state_obj)
        _QUALITY_STATE_CACHE_V1011=unpacked_records_v1127
        # Release parsed durable state immediately; only active unfinished rows remain resident.
        loaded_records_raw=int(loaded_storage_v1127.get('raw_rows') or len(unpacked_records_v1127))
        # Read compact metadata before dropping the parsed JSON object.  v1012
        # cleared state_obj first, which reset checkpoint/revision to zero and
        # made the quality publisher look stale or checkpoint-due again.
        state_meta_v1013={
            'analysis_revision':int(state_obj.get('analysis_revision_v1010') or state_obj.get('analysis_revision_v1009') or 0) if isinstance(state_obj,dict) else 0,
            'event_context_migration':state_obj.get('event_context_migration') if isinstance(state_obj,dict) else {},
            'updated_ts':float(state_obj.get('updated_ts') or 0.0) if isinstance(state_obj,dict) else 0.0,
        }
        if isinstance(state_obj,dict): state_obj.clear()
        _drop_json_cache(QUALITY_SHADOW_STATE)
        gc.collect()
        _QUALITY_STATE_META_V1011={
            'analysis_revision':state_meta_v1013['analysis_revision'],
            'event_context_migration':state_meta_v1013['event_context_migration'],
        }
        _QUALITY_LAST_CHECKPOINT_V1010=state_meta_v1013['updated_ts']
        previous_status=load_json(QUALITY_SHADOW_STATUS,{}) or {}
        _QUALITY_STATUS_CACHE_V1011=dict(previous_status) if isinstance(previous_status,dict) else {}
        _QUALITY_LAST_SUMMARY_V1011=float(_QUALITY_STATUS_CACHE_V1011.get('summary_calculated_at_v1011') or _QUALITY_STATUS_CACHE_V1011.get('updated_ts') or 0.0)
        loaded_from_disk=True
    records=_QUALITY_STATE_CACHE_V1011
    prior_revision=int(_QUALITY_STATE_META_V1011.get('analysis_revision') or 0)

    event_context_migrated=0
    event_context_migration=_QUALITY_STATE_META_V1011.get('event_context_migration') if isinstance(_QUALITY_STATE_META_V1011.get('event_context_migration'),dict) else {}
    if not _QUALITY_STATE_META_V1011.get('migration_checked'):
        holder={'records':records,'event_context_migration':event_context_migration}
        event_context_migrated,event_context_migration=_migrate_quality_event_context_once(records,holder,nowv)
        _QUALITY_STATE_META_V1011['migration_checked']=True
        _QUALITY_STATE_META_V1011['event_context_migration']=event_context_migration

    exact_ready=0; exact_missing=0; created=0; finalized=0; sample_added=0
    reason_counts=Counter(); cohort_counts=Counter(); source_keys:set[str]=set()
    source_unique: Dict[str, tuple[Dict[str,Any],str,Dict[str,Any]]] = {}
    source_duplicate_identity_rows_v1124=0
    identity_event_counts_v1126=Counter({'NEW_PLAN':0,'NEW_RESET_REBREAK':0,'SAME_PLAN_KEY_CHURN_BLOCKED':0,'MISSING_OWNER_KEY':0,'FINAL_OWNER_RESEEN_BLOCKED':0})
    missing_owner_reason_counts_v1127=Counter()
    missing_owner_expected_counts_v1128=Counter()
    missing_owner_gap_counts_v1128=Counter()
    missing_owner_samples_v1127=[]
    for _row in source_rows:
        _evidence=_quality_identity_evidence_v1126(_row)
        _key,_mode=_quality_exact_identity(_row)
        if not _key:
            exact_missing += 1
            identity_event_counts_v1126['MISSING_OWNER_KEY'] += 1
            missing_code_v1128,missing_severity_v1128,missing_sample_v1128=_quality_missing_owner_class_v1128(_row,_evidence)
            missing_owner_reason_counts_v1127[missing_code_v1128] += 1
            (missing_owner_expected_counts_v1128 if missing_severity_v1128=='EXPECTED' else missing_owner_gap_counts_v1128)[missing_code_v1128] += 1
            if len(missing_owner_samples_v1127)<8:
                missing_owner_samples_v1127.append(missing_sample_v1128)
            continue
        if _key in source_unique:
            source_duplicate_identity_rows_v1124 += 1
            if source_unique[_key][2].get('audit_signature') != _evidence.get('audit_signature'):
                identity_event_counts_v1126['SAME_PLAN_KEY_CHURN_BLOCKED'] += 1
            continue
        source_unique[_key]=(_row,_mode,_evidence)

    for exact_key,(row,identity_mode,identity_evidence_v1126) in source_unique.items():
        exact_ready += 1; source_keys.add(exact_key)
        ticker = ticker_norm(row.get('ticker') or row.get('market') or row.get('symbol'))
        gate = _quality_gate(row); reasons = _quality_block_reasons(row, gate)
        hard_pass = bool(gate.get('hard_pass')); cohort = _quality_cohort(hard_pass, reasons)
        reason_counts.update(reasons); cohort_counts[cohort] += 1
        current = _current_price(ticker, fmap, ofmap) or _quality_optional_num(row.get('current_price'), row.get('entry_price'), row.get('price'), row.get('detected_price')) or 0.0
        rec = records.get(exact_key)
        if rec is None and _dedup_contains_v1013(QUALITY_DEDUP_KIND_V1125,exact_key):
            identity_event_counts_v1126['FINAL_OWNER_RESEEN_BLOCKED'] += 1
            continue
        if rec is None:
            if current <= 0: continue
            rec = {
                'schema':'quality_shadow_state_row_v1011','version':VERSION,'build':BUILD_LABEL,
                'quality_event_key_v946':exact_key,'identity_mode_v946':identity_mode,
                'identity_owner_field_v1126':identity_evidence_v1126.get('owner_field'),'identity_owner_value_v1126':identity_evidence_v1126.get('owner_value'),'identity_event_class_v1126':_quality_new_event_class_v1126(identity_evidence_v1126),'identity_base_plan_decision_key_v1126':identity_evidence_v1126.get('base_plan_decision_key'),'identity_kind_v1126':identity_evidence_v1126.get('kind'),'identity_sequence_v1126':identity_evidence_v1126.get('sequence'),'identity_audit_signature_first_v1126':identity_evidence_v1126.get('audit_signature'),'identity_audit_signature_last_v1126':identity_evidence_v1126.get('audit_signature'),
                'entry_build_key':row.get('entry_build_key'),'minimal_gate_decision_key_v925':row.get('minimal_gate_decision_key_v925'),'direct_decision_key_v1124':_quality_direct_decision_key_v1124(row),'trigger_occurrence_candidate_key_v1037':row.get('trigger_occurrence_candidate_key_v1037'),'quality_eye_epoch_id_v1124':quality_eye_epoch_v1124.get('epoch_id'),'quality_eye_epoch_start_ts_v1124':quality_eye_epoch_v1124.get('epoch_start_ts'),
                'ticker':ticker,'hot_watch_occurrence_key_v945':str((row.get('hot_watch_timing_v945') or {}).get('hot_watch_occurrence_key_v945') or row.get('hot_watch_occurrence_key_v945') or ''),'first_seen_ts':nowv,'first_seen_text':now_text(nowv),'first_price':current,
                'stage_at_first':str(gate.get('stage') or row.get('s_stage') or row.get('candidate_stage') or '-'),'hard_pass_at_first':hard_pass,'ever_hard_pass':hard_pass,'first_pass_ts':nowv if hard_pass else None,'cohort':cohort,'hard_block_reasons':reasons,
                'initial_metrics':_quality_initial_metrics(row,gate),'event_context':_seal_quality_event_context(row,fmap.get(ticker),regime_snapshot,nowv),'samples':{},'max_pct':0.0,'min_pct':0.0,'giveback_pct':0.0,
                'last_price':current,'last_seen_ts':nowv,'last_candidate_seen_ts':nowv,'final_appended':False,'next_review_due_ts_v1011':nowv,
                'identity_policy':'trigger occurrence decision exact first; candidate/direct keys audit evidence only; ticker is price-source lookup only','observation_only':True,'used_for_entry_gate':False,'used_for_exit':False,
            }
            rec['policy_variants_v1120']=_quality_policy_variants_v1120(row,gate,rec.get('initial_metrics') if isinstance(rec.get('initial_metrics'),dict) else {})
            records[exact_key]=rec; created += 1
            identity_event_counts_v1126[_quality_new_event_class_v1126(identity_evidence_v1126)] += 1
        else:
            prior_audit_signature_v1126=rec.get('identity_audit_signature_last_v1126')
            if not prior_audit_signature_v1126:
                prior_audit_v1126={
                    'entry_build_key':rec.get('entry_build_key'),
                    'trigger_occurrence_candidate_key_v1037':rec.get('trigger_occurrence_candidate_key_v1037'),
                    'direct_decision_key_v1124':rec.get('direct_decision_key_v1124'),
                }
                prior_audit_signature_v1126=hashlib.sha256(json.dumps(prior_audit_v1126,ensure_ascii=False,sort_keys=True,default=str).encode('utf-8')).hexdigest()[:20]
            if prior_audit_signature_v1126 != identity_evidence_v1126.get('audit_signature'):
                identity_event_counts_v1126['SAME_PLAN_KEY_CHURN_BLOCKED'] += 1
            rec.setdefault('identity_owner_field_v1126',identity_evidence_v1126.get('owner_field'))
            rec.setdefault('identity_owner_value_v1126',identity_evidence_v1126.get('owner_value'))
            rec.setdefault('identity_event_class_v1126',_quality_new_event_class_v1126(identity_evidence_v1126))
            rec.setdefault('identity_base_plan_decision_key_v1126',identity_evidence_v1126.get('base_plan_decision_key'))
            rec.setdefault('identity_kind_v1126',identity_evidence_v1126.get('kind'))
            rec.setdefault('identity_sequence_v1126',identity_evidence_v1126.get('sequence'))
            rec.setdefault('identity_audit_signature_first_v1126',prior_audit_signature_v1126)
            rec['identity_audit_signature_last_v1126']=identity_evidence_v1126.get('audit_signature')
            rec['last_candidate_seen_ts']=nowv; rec['last_hard_pass']=hard_pass
            if hard_pass and not rec.get('ever_hard_pass'):
                rec['ever_hard_pass']=True; rec['first_pass_ts']=nowv
            rec['last_stage']=str(gate.get('stage') or row.get('s_stage') or row.get('candidate_stage') or rec.get('last_stage') or '-')
            rec['last_hard_block_reasons']=reasons
            hot_key=str((row.get('hot_watch_timing_v945') or {}).get('hot_watch_occurrence_key_v945') or row.get('hot_watch_occurrence_key_v945') or '')
            if hot_key and not rec.get('hot_watch_occurrence_key_v945'): rec['hot_watch_occurrence_key_v945']=hot_key
            existing_metrics=rec.get('initial_metrics') if isinstance(rec.get('initial_metrics'),dict) else {}
            for metric_name,metric_value in _quality_initial_metrics(row,gate).items():
                if metric_value is not None and existing_metrics.get(metric_name) is None: existing_metrics[metric_name]=metric_value
            rec['initial_metrics']=existing_metrics
            if not rec.get('direct_decision_key_v1124'):
                rec['direct_decision_key_v1124']=_quality_direct_decision_key_v1124(row) or None
            if not rec.get('trigger_occurrence_candidate_key_v1037') and row.get('trigger_occurrence_candidate_key_v1037'):
                rec['trigger_occurrence_candidate_key_v1037']=row.get('trigger_occurrence_candidate_key_v1037')
            if not isinstance(rec.get('policy_variants_v1120'),dict):
                rec['policy_variants_v1120']=_quality_policy_variants_v1120(row,gate,existing_metrics)

    final_horizon=QUALITY_SHADOW_HORIZONS[-1][1]
    due_total=0; due_processed=0; due_deferred=0
    for key,rec in list(records.items()):
        due_ts=_quality_optional_num(rec.get('next_review_due_ts_v1011')) or 0.0
        due=due_ts<=nowv
        if not due:
            due_deferred += 1
            continue
        due_total += 1
        ticker=ticker_norm(rec.get('ticker')); current=_current_price(ticker,fmap,ofmap); base=_quality_optional_num(rec.get('first_price')) or 0.0
        if current <= 0 or base <= 0:
            rec['next_review_due_ts_v1011']=nowv+60.0
            continue
        due_processed += 1
        pct=round((current-base)/base*100.0,6)
        rec['last_price']=current; rec['last_seen_ts']=nowv; rec['current_pct']=pct
        rec['max_pct']=max(_quality_optional_num(rec.get('max_pct')) or pct,pct); rec['min_pct']=min(_quality_optional_num(rec.get('min_pct')) or pct,pct)
        rec['giveback_pct']=round((_quality_optional_num(rec.get('max_pct')) or pct)-pct,6)
        elapsed=max(0.0,nowv-(_quality_optional_num(rec.get('first_seen_ts')) or nowv)); rec['age_sec']=round(elapsed,3)
        samples=rec.get('samples') if isinstance(rec.get('samples'),dict) else {}
        for label,sec in QUALITY_SHADOW_HORIZONS:
            if elapsed >= sec and label not in samples:
                samples[label]={'ts':nowv,'text':now_text(nowv),'price':current,'pct':pct,'max_pct':rec.get('max_pct'),'min_pct':rec.get('min_pct'),'giveback_pct':rec.get('giveback_pct')}; sample_added += 1
        rec['samples']=samples
        interval=30.0 if elapsed<=600.0 else (60.0 if elapsed<=3600.0 else 180.0)
        rec['next_review_due_ts_v1011']=nowv+interval
        if elapsed >= final_horizon and not rec.get('final_appended'):
            final=dict(rec); final['schema']='quality_shadow_result_v947'; final['finalized_ts']=nowv; final['finalized_text']=now_text(nowv)
            appended=_quality_append_final(final); rec['final_appended']=True; rec['finalized_ts']=nowv
            if appended: finalized += 1

    kept: Dict[str, Dict[str, Any]] = {}; stale_unfinished_pruned=0; finalized_pruned=0
    for key,rec in records.items():
        rec_age=max(0.0,nowv-(_quality_optional_num(rec.get('first_seen_ts')) or nowv))
        if rec.get('final_appended'):
            finalized_pruned += 1
            continue
        if not rec.get('final_appended') and rec_age > QUALITY_SHADOW_RETENTION_SEC: stale_unfinished_pruned += 1; continue
        kept[key]=_quality_active_compact_v1007(rec)
    safety_pruned=0; premature_unfinished_pruned=0
    if len(kept)>QUALITY_SHADOW_SAFETY_MAX_RECORDS:
        ranked=sorted(kept.items(),key=lambda item:(bool(item[1].get('final_appended')),-(_quality_optional_num(item[1].get('first_seen_ts')) or 0.0)))
        dropped=ranked[QUALITY_SHADOW_SAFETY_MAX_RECORDS:]; safety_pruned=len(dropped)
        premature_unfinished_pruned=sum(1 for _key,rec in dropped if not rec.get('final_appended') and max(0.0,nowv-(_quality_optional_num(rec.get('first_seen_ts')) or nowv))<final_horizon)
        kept=dict(ranked[:QUALITY_SHADOW_SAFETY_MAX_RECORDS])
    records=kept; _QUALITY_STATE_CACHE_V1011=records
    rows=list(records.values())

    summary_due=bool(not _QUALITY_STATUS_CACHE_V1011 or nowv-_QUALITY_LAST_SUMMARY_V1011>=QUALITY_SHADOW_SUMMARY_SEC or created or finalized or stale_unfinished_pruned or finalized_pruned or safety_pruned)
    if summary_due:
        cohorts=_quality_summary_stats(rows)
        sample_candidates=heapq.nlargest(4,rows,key=lambda rec:_quality_optional_num(rec.get('max_pct')) or -999.0)+heapq.nsmallest(4,rows,key=lambda rec:_quality_optional_num(rec.get('min_pct')) or 999.0)
        compact_samples=[]; seen=set()
        for rec in sample_candidates:
            key=str(rec.get('quality_event_key_v946') or '')
            if not key or key in seen: continue
            seen.add(key); compact_samples.append({k:rec.get(k) for k in ('ticker','quality_event_key_v946','identity_mode_v946','entry_build_key','minimal_gate_decision_key_v925','cohort','hard_block_reasons','age_sec','current_pct','max_pct','min_pct','giveback_pct','samples')})
        _QUALITY_LAST_SUMMARY_V1011=nowv
    else:
        cohorts=_QUALITY_STATUS_CACHE_V1011.get('cohorts') if isinstance(_QUALITY_STATUS_CACHE_V1011.get('cohorts'),dict) else {}
        compact_samples=_QUALITY_STATUS_CACHE_V1011.get('samples') if isinstance(_QUALITY_STATUS_CACHE_V1011.get('samples'),list) else []

    rotation={'rotated':False,'reason':'interval_not_due_v1011'}
    if _QUALITY_LAST_ROTATION_V1011<=0 or nowv-_QUALITY_LAST_ROTATION_V1011>=QUALITY_SHADOW_SUMMARY_SEC:
        rotation=_quality_rotate_ledger(nowv); _QUALITY_LAST_ROTATION_V1011=nowv
    ledger_rows=len(_quality_load_final_keys()); ledger_bytes=0; archive_files=0; archive_bytes=0
    try: ledger_bytes=QUALITY_SHADOW_LEDGER.stat().st_size if QUALITY_SHADOW_LEDGER.exists() else 0
    except OSError: pass
    try:
        archives=[path for path in QUALITY_SHADOW_ARCHIVE.glob('quality_shadow_result_*.jsonl.gz') if path.is_file()] if QUALITY_SHADOW_ARCHIVE.exists() else []
        archive_files=len(archives); archive_bytes=sum(path.stat().st_size for path in archives)
    except OSError: pass

    try: ledger_size_after_cycle_v1128=QUALITY_SHADOW_LEDGER.stat().st_size
    except OSError: ledger_size_after_cycle_v1128=0
    rotation_occurred_v1128=bool(rotation.get('rotated'))
    cycle_attempts_v1128=int(_QUALITY_FINAL_APPEND_CYCLE_V1128.get('attempts') or 0)
    cycle_appended_v1128=int(_QUALITY_FINAL_APPEND_CYCLE_V1128.get('appended') or 0)
    cycle_duplicate_v1128=int(_QUALITY_FINAL_APPEND_CYCLE_V1128.get('duplicate_blocked') or 0)
    cycle_append_bytes_v1128=int(_QUALITY_FINAL_APPEND_CYCLE_V1128.get('bytes_appended') or 0)
    cycle_file_delta_v1128=int(ledger_size_after_cycle_v1128-ledger_size_before_cycle_v1128)
    cycle_file_delta_comparable_v1128=not rotation_occurred_v1128
    cycle_bytes_match_file_delta_v1128=(cycle_append_bytes_v1128==max(0,cycle_file_delta_v1128)) if cycle_file_delta_comparable_v1128 else None
    exact_append_accounting_ok_v1128=(
        cycle_attempts_v1128==cycle_appended_v1128+cycle_duplicate_v1128
        and cycle_append_bytes_v1128>=0
        and (not cycle_file_delta_comparable_v1128 or cycle_bytes_match_file_delta_v1128 is True)
    )
    append_truth_v1128={
        'schema':'quality_final_append_truth_v1128','owner':'review_worker._quality_append_final',
        'dedup_key':'quality_event_key_v946 / trigger_occurrence_v1037.decision_key',
        'cycle':dict(_QUALITY_FINAL_APPEND_CYCLE_V1128),'process':dict(_QUALITY_FINAL_APPEND_LIFETIME_V1128),
        'ledger_size_before_cycle':int(ledger_size_before_cycle_v1128),'ledger_size_after_cycle':int(ledger_size_after_cycle_v1128),
        'ledger_size_delta_cycle':cycle_file_delta_v1128,
        'rotation_occurred_this_cycle':rotation_occurred_v1128,
        'cycle_file_delta_comparable':cycle_file_delta_comparable_v1128,
        'cycle_bytes_match_file_delta':cycle_bytes_match_file_delta_v1128,
        'exact_append_accounting_ok':exact_append_accounting_ok_v1128,
        'final_owner_reseen_blocked_this_cycle':int(identity_event_counts_v1126.get('FINAL_OWNER_RESEEN_BLOCKED') or 0),
        'append_once':True,'protected_trade_ledgers_changed':False,
    }
    revision=prior_revision + (1 if created or finalized or sample_added or event_context_migrated or stale_unfinished_pruned or finalized_pruned or safety_pruned else 0)
    _QUALITY_STATE_META_V1011['analysis_revision']=revision
    status={
        'schema':'quality_shadow_status_v1011_semantic_incremental','version':VERSION,'build':BUILD_LABEL,'state':'ACTIVE','updated_ts':nowv,'updated_text':now_text(nowv),'candidate_rows':len(source_rows),
        'exact_key_ready':exact_ready,'exact_key_missing':exact_missing,'source_rows_raw_v1124':len(source_rows),'source_unique_candidate_occurrences_v1124':len(source_unique),'source_duplicate_identity_rows_v1124':source_duplicate_identity_rows_v1124,'source_rows_raw_v1125':len(source_rows),'source_unique_trigger_decisions_v1125':len(source_unique),'source_duplicate_trigger_decision_rows_v1125':source_duplicate_identity_rows_v1124,'tracked_records':len(rows),'new_records_this_cycle':created,'new_horizon_samples_this_cycle_v1009':sample_added,'analysis_revision_v1009':revision,'analysis_revision_v1010':revision,
        'identity_owner_field_v1126':'trigger_occurrence_v1037.decision_key','identity_owner_values_sample_v1126':[str(key).split('trigger_decision:',1)[-1] for key in list(source_unique.keys())[:8]],'identity_owner_missing_this_cycle_v1126':exact_missing,'identity_event_counts_v1126':dict(identity_event_counts_v1126),'same_plan_key_churn_blocked_this_cycle_v1126':int(identity_event_counts_v1126.get('SAME_PLAN_KEY_CHURN_BLOCKED') or 0),
        'missing_owner_reason_counts_v1127':dict(missing_owner_reason_counts_v1127),'missing_owner_expected_counts_v1128':dict(missing_owner_expected_counts_v1128),'missing_owner_gap_counts_v1128':dict(missing_owner_gap_counts_v1128),'missing_owner_samples_v1127':missing_owner_samples_v1127,'missing_owner_contract_v1127':'no missing owner creates a sample','missing_owner_contract_v1128':'S3 observation and v1133 wait-reset/rebreak pre-contract rows are expected no-owner states; only trade-capable rows or malformed occurrence owners are gaps',
        'event_context_migrated_this_cycle':event_context_migrated,'event_context_migration':event_context_migration,'finalized_this_cycle':finalized,'final_ledger_rows':ledger_rows,'final_ledger_bytes':ledger_bytes,'final_append_truth_v1128':append_truth_v1128,'rotation':rotation,'archive_files':archive_files,'archive_bytes':archive_bytes,
        'current_cohort_counts':dict(cohort_counts),'current_block_reason_counts':dict(reason_counts),'cohorts':cohorts,'samples':compact_samples,'horizons':[label for label,_ in QUALITY_SHADOW_HORIZONS],
        'oldest_unfinished_age_sec':round(max([max(0.0,nowv-(_quality_optional_num(rec.get('first_seen_ts')) or nowv)) for rec in rows if not rec.get('final_appended')] or [0.0]),3),'unfinished_records':sum(1 for rec in rows if not rec.get('final_appended')),
        'stale_unfinished_pruned':stale_unfinished_pruned,'finalized_pruned':finalized_pruned,'safety_pruned':safety_pruned,'premature_unfinished_pruned':premature_unfinished_pruned,
        'summary_recomputed_v1011':summary_due,'summary_calculated_at_v1011':_QUALITY_LAST_SUMMARY_V1011,
        'due_total_v1011':due_total,'due_processed_v1011':due_processed,'due_deferred_v1011':due_deferred,
        'retention_policy':'unfinished active rows only through 60m; completed owners are blocked from re-entering active state after one final append; count ceiling safety-only','identity_contract_v1124':'retired candidate/direct fallback identity; audit evidence only','identity_contract_v1125':'trigger_occurrence_v1037.decision_key exact; no ticker/time-near inference','identity_contract_v1126':'missing canonical owner creates no sample; reset/rebreak is new only when Strategy seals a new trigger decision key','quality_eye_epoch_id_v1124':quality_eye_epoch_v1124.get('epoch_id'),'quality_eye_epoch_start_ts_v1124':quality_eye_epoch_v1124.get('epoch_start_ts'),'conditions_changed':False,'trigger_changed':False,'paper_open_changed':False,'exit_changed':False,'auto_buy':False,'legacy_v946_v1124_artifacts_preserved_v1125':True,'legacy_quality_artifacts_read_by_v1125':False,
    }
    storage_migration_due_v1127=bool(loaded_from_disk and loaded_storage_v1127.get('packed') is not True)
    checkpoint_due=bool(storage_migration_due_v1127 or not QUALITY_SHADOW_STATE.exists() or _QUALITY_LAST_CHECKPOINT_V1010<=0 or nowv-_QUALITY_LAST_CHECKPOINT_V1010>=QUALITY_SHADOW_CHECKPOINT_SEC)
    status['state_cache_v1011']={
        'loaded_from_disk_this_cycle':loaded_from_disk,'memory_cache_reused':not loaded_from_disk,'checkpoint_due':checkpoint_due,
        'checkpoint_interval_sec':QUALITY_SHADOW_CHECKPOINT_SEC,'last_checkpoint_age_sec':round(max(0.0,nowv-_QUALITY_LAST_CHECKPOINT_V1010),3) if _QUALITY_LAST_CHECKPOINT_V1010 else None,'storage_migration_due_v1127':storage_migration_due_v1127,
        'records_in_memory':len(records),'semantic_change':bool(revision!=prior_revision),
        'loaded_records_raw_v1012':loaded_records_raw,
        'compact_schema_v1012':'quality_shadow_state_row_v1012_compact',
        'compact_policy_variants_v1123':True,
        'compact_final_ledger_v1123':True,
        'candidate_occurrence_identity_v1124':False,
        'trigger_decision_identity_v1125':True,
        'clean_epoch_files_v1125':True,
        'direct_decision_preserved_as_audit_v1124':True,
        'large_nested_smart_structure_retained':0,
        'external_compaction_v1012':dict(_QUALITY_EXTERNAL_MIGRATION_V1012),
        'loaded_storage_v1127':dict(loaded_storage_v1127),
        'durable_schema_v1127':'quality_shadow_state_v1127_packed_active',
        'active_only_unfinished_v1127':True,
        'terminal_rows_in_active_state_v1127':0,
    }
    if checkpoint_due:
        persisted=_quality_state_payload_v1127(records,nowv,revision,ledger_rows,event_context_migration)
        before_state_bytes_v1127=QUALITY_SHADOW_STATE.stat().st_size if QUALITY_SHADOW_STATE.exists() else 0
        save_json(QUALITY_SHADOW_STATE,persisted)
        after_state_bytes_v1127=QUALITY_SHADOW_STATE.stat().st_size if QUALITY_SHADOW_STATE.exists() else 0
        _QUALITY_LAST_CHECKPOINT_V1010=nowv
        status['state_cache_v1011'].update({
            'checkpoint_written':True,
            'state_bytes_before_v1127':before_state_bytes_v1127,
            'state_bytes_after_v1127':after_state_bytes_v1127,
            'state_bytes_delta_v1127':after_state_bytes_v1127-before_state_bytes_v1127,
            'packed_active_rows_v1127':len(persisted.get('records_packed_v1127') or []),
        })
    else:
        status['state_cache_v1011']['checkpoint_written']=False
        status['state_cache_v1011']['state_bytes_after_v1127']=QUALITY_SHADOW_STATE.stat().st_size if QUALITY_SHADOW_STATE.exists() else 0
        status['state_cache_v1011']['packed_active_rows_v1127']=len(records)
    _QUALITY_STATUS_CACHE_V1011=dict(status)
    status['storage_truth_v1127']={
        'active_state_file':QUALITY_SHADOW_STATE.name,
        'active_state_schema':'quality_shadow_state_v1127_packed_active',
        'active_unfinished_rows':len(records),
        'terminal_rows_in_active_state':0,
        'state_bytes':QUALITY_SHADOW_STATE.stat().st_size if QUALITY_SHADOW_STATE.exists() else 0,
        'final_ledger_file':QUALITY_SHADOW_LEDGER.name,
        'final_ledger_append_only':True,
        'aggregate_file':QUALITY_EYE_AGG_STATE_V1124.name,
        'protected_trade_ledgers_changed':False,
        'final_owner_reseen_blocked_v1128':int(identity_event_counts_v1126.get('FINAL_OWNER_RESEEN_BLOCKED') or 0),
        'final_append_truth_v1128':append_truth_v1128,
    }
    status['dedup_index_v1013']={'db':REVIEW_DEDUP_DB_V1013.name,'quality_keys':_dedup_count_v1013(QUALITY_DEDUP_KIND_V1125),'quality_namespace_v1125':QUALITY_DEDUP_KIND_V1125,'db_bytes':REVIEW_DEDUP_DB_V1013.stat().st_size if REVIEW_DEDUP_DB_V1013.exists() else 0}
    save_json(QUALITY_SHADOW_STATUS,status)
    try:
        _verify=load_json(QUALITY_SHADOW_STATUS,{}) or {}
        if abs(float(_verify.get('updated_ts') or 0.0)-float(nowv))>0.001: raise RuntimeError('quality status post-write timestamp mismatch')
        status['status_write_verified_v1013']=True
    except Exception as exc:
        append_error(ERROR,'quality_status_post_write_verify_v1013',exc); status['status_write_verified_v1013']=False
    return status, rows




def _sample_price_unit(price: float) -> float:
    if price >= 100000: return 100.0
    if price >= 10000: return 10.0
    if price >= 1000: return 1.0
    if price >= 100: return 0.1
    if price >= 10: return 0.01
    if price >= 1: return 0.001
    return 0.00001


def _sample_trimmed_mean(values: List[float], trim_ratio: float=0.05) -> Optional[float]:
    vals=sorted(float(v) for v in values if isinstance(v,(int,float)))
    if not vals: return None
    cut=int(len(vals)*trim_ratio)
    core=vals[cut:len(vals)-cut] if cut>0 and len(vals)>cut*2 else vals
    return sum(core)/len(core) if core else None


def _sample_result_rows(records: List[Dict[str,Any]], horizon: str) -> List[Dict[str,Any]]:
    out=[]
    for rec in records:
        sample=(rec.get('samples') or {}).get(horizon) if isinstance(rec.get('samples'),dict) else None
        if not isinstance(sample,dict): continue
        pctv=_quality_optional_num(sample.get('pct'))
        if pctv is None: continue
        metrics=rec.get('initial_metrics') if isinstance(rec.get('initial_metrics'),dict) else {}
        event_context=rec.get('event_context') if isinstance(rec.get('event_context'),dict) else _legacy_missing_event_context()
        price=_quality_optional_num(rec.get('first_price'),metrics.get('first_price')) or 0.0
        tick_pct=_sample_price_unit(price)/price*100.0 if price>0 else 0.0
        spread=_quality_optional_num(metrics.get('spread_pct'))
        slip=_quality_optional_num(metrics.get('confirmed_slippage_pct'))
        source=str(metrics.get('confirmed_slippage_source') or '').lower()
        slip_confirmed=slip is not None and any(x in source for x in ('confirmed','exchange','average_fill','paper_reference','best_ask_reference')) and 'derived_from_spread' not in source
        cost=(spread or 0.0)+(slip if slip_confirmed else 0.0)
        out.append({'ticker':ticker_norm(rec.get('ticker')),'cohort':str(rec.get('cohort') or 'unknown'),'pct':pctv,'max_pct':_quality_optional_num(sample.get('max_pct')),'min_pct':_quality_optional_num(sample.get('min_pct')),'giveback_pct':_quality_optional_num(sample.get('giveback_pct')),'price':price,'tick_pct':tick_pct,'distortion':bool(tick_pct>=0.50 or abs(pctv)>=15.0),'spread_pct':spread,'confirmed_slippage_pct':slip if slip_confirmed else None,'cost_adjusted_pct':pctv-cost,'market_regime':event_context.get('market_regime'),'market_strength':_quality_optional_num(event_context.get('market_strength')),'volume_ratio':_quality_optional_num(event_context.get('volume_ratio')),'scanner_to_s2_sec':_quality_optional_num(metrics.get('scanner_to_s2_sec')),'scanner_to_s1_sec':_quality_optional_num(metrics.get('scanner_to_s1_sec')),'event_key':rec.get('quality_event_key_v946'),'occurrence':rec.get('hot_watch_occurrence_key_v945')})
    return out


def _sample_group_stats(rows: List[Dict[str,Any]]) -> Dict[str,Any]:
    vals=[float(r['pct']) for r in rows if isinstance(r.get('pct'),(int,float))]
    clean=[float(r['pct']) for r in rows if isinstance(r.get('pct'),(int,float)) and not r.get('distortion')]
    costs=[float(r['cost_adjusted_pct']) for r in rows if isinstance(r.get('cost_adjusted_pct'),(int,float))]
    tickers=Counter(str(r.get('ticker') or '-') for r in rows)
    unique_occ={str(r.get('occurrence')) for r in rows if str(r.get('occurrence') or '').strip()}
    unique_ticker_rows=[]
    seen=set()
    for r in sorted(rows,key=lambda x:str(x.get('event_key') or '')):
        t=str(r.get('ticker') or '')
        if t and t not in seen: seen.add(t); unique_ticker_rows.append(r)
    unique_vals=[float(r['pct']) for r in unique_ticker_rows if isinstance(r.get('pct'),(int,float))]
    top_share=(tickers.most_common(1)[0][1]/len(rows)) if rows and tickers else 0.0
    trust='판단대기'
    if len(clean)>=30 and len(tickers)>=20 and top_share<=0.20: trust='참고가능'
    if len(clean)>=100 and len(tickers)>=40 and top_share<=0.12: trust='신뢰권'
    return {'n':len(vals),'unique_tickers':len(tickers),'unique_occurrences':len(unique_occ),'raw_avg_pct':round(sum(vals)/len(vals),4) if vals else None,'median_pct':round(_quality_percentile(vals,0.5),4) if vals else None,'trimmed_avg_pct':round(_sample_trimmed_mean(vals) or 0.0,4) if vals else None,'distortion_excluded_n':len(clean),'distortion_excluded_avg_pct':round(sum(clean)/len(clean),4) if clean else None,'unique_ticker_avg_pct':round(sum(unique_vals)/len(unique_vals),4) if unique_vals else None,'cost_adjusted_avg_pct':round(sum(costs)/len(costs),4) if costs else None,'distortion_count':sum(1 for r in rows if r.get('distortion')),'top_ticker_share_pct':round(top_share*100.0,2),'top_tickers':[{'ticker':k,'n':v} for k,v in tickers.most_common(5)],'positive_0_1':sum(1 for v in vals if v>=0.1),'negative_0_1':sum(1 for v in vals if v<=-0.1),'trust':trust}


def update_sample_board(nowv: float, records: List[Dict[str,Any]]) -> Dict[str,Any]:
    cohorts=('s1_pass','frozen_trigger_not_reached','risk_reward_below_minimum','target_room_below_minimum','coherent_structure_plan_incomplete','actual_structural_invalid_missing','next_structural_target_missing','candidate_sources_not_fresh','untradable_spread','untradable_liquidity','other_blocked')
    horizon_results={}
    for horizon in ('10m','60m'):
        rows=_sample_result_rows(records,horizon)
        by={c:_sample_group_stats([r for r in rows if r.get('cohort')==c]) for c in cohorts}
        by={k:v for k,v in by.items() if v.get('n')}
        narrow=_sample_group_stats([r for r in rows if (_quality_optional_num(r.get('spread_pct')) or 999)<0.20])
        wide=_sample_group_stats([r for r in rows if (_quality_optional_num(r.get('spread_pct')) or 0)>=0.20])
        high_vol=_sample_group_stats([r for r in rows if (_quality_optional_num(r.get('volume_ratio')) or 0)>=1.2])
        normal_vol=_sample_group_stats([r for r in rows if (_quality_optional_num(r.get('volume_ratio')) or 0)<1.2])
        fast_s2=_sample_group_stats([r for r in rows if (_quality_optional_num(r.get('scanner_to_s2_sec')) is not None and (_quality_optional_num(r.get('scanner_to_s2_sec')) or 0)<=30)])
        slow_s2=_sample_group_stats([r for r in rows if (_quality_optional_num(r.get('scanner_to_s2_sec')) or 0)>120])
        horizon_results[horizon]={'total':_sample_group_stats(rows),'cohorts':by,'market_splits':{'spread_narrow':narrow,'spread_wide':wide,'volume_high':high_vol,'volume_normal':normal_vol,'s2_fast_30s':fast_s2,'s2_slow_120s':slow_s2}}
    status={'schema':'sample_board_status_v948','version':VERSION,'build':BUILD_LABEL,'state':'ACTIVE','updated_ts':nowv,'updated_text':now_text(nowv),'tracked_records':len(records),'horizons':horizon_results,'rules':{'distortion':'tick_pct>=0.50% or abs(return)>=15%','dedup':'raw exact + unique ticker + unique occurrence shown together','cost':'spread + confirmed/reference slippage only; legacy spread-copy excluded','trust':'sample count + unique tickers + concentration'} ,'policy':'observation only; no gate/trigger/open/exit change','trading_rules_changed':False}
    save_json(SAMPLE_BOARD_STATUS,status); return status


def _structure_variant_stats(records: List[Dict[str,Any]], variant: str) -> Dict[str,Any]:
    reached=[]
    for rec in records:
        v=(rec.get('variants') or {}).get(variant) if isinstance(rec.get('variants'),dict) else None
        if isinstance(v,dict) and v.get('reached_ts'): reached.append(v)
    out={'tracked':len(records),'reached':len(reached),'reach_rate_pct':round(len(reached)/len(records)*100.0,2) if records else 0.0}
    for label,_ in SMART_STRUCTURE_HORIZONS:
        vals=[]; peaks=[]; troughs=[]; give=[]
        for v in reached:
            sm=(v.get('samples') or {}).get(label) if isinstance(v.get('samples'),dict) else None
            if not isinstance(sm,dict): continue
            x=_quality_optional_num(sm.get('pct')); p=_quality_optional_num(sm.get('max_pct')); t=_quality_optional_num(sm.get('min_pct')); g=_quality_optional_num(sm.get('giveback_pct'))
            if x is not None: vals.append(x)
            if p is not None: peaks.append(p)
            if t is not None: troughs.append(t)
            if g is not None: give.append(g)
        out[label]=_quality_metric_stats(vals,peaks,troughs,give)
    out['invalid_breach_count']=sum(1 for v in reached if v.get('invalid_breached'))
    out['target_hit_count']=sum(1 for v in reached if v.get('target_hit'))
    return out


def update_smart_structure_shadow(nowv: float, fmap: Dict[str,Dict[str,Any]], ofmap: Dict[str,Dict[str,Any]]) -> Dict[str,Any]:
    source=load_json(SMART_STRUCTURE_CANDIDATES,{}) or {}
    rows=source.get('rows') if isinstance(source,dict) and isinstance(source.get('rows'),list) else []
    state=load_json(SMART_STRUCTURE_STATE,{}) or {}; records=state.get('records') if isinstance(state,dict) and isinstance(state.get('records'),dict) else {}
    records={str(k):dict(v) for k,v in records.items() if isinstance(v,dict)}; new=0
    for row in rows:
        if not isinstance(row,dict): continue
        key=str(row.get('shadow_key') or '').strip(); ticker=ticker_norm(row.get('ticker'))
        if not key or not ticker: continue
        rec=records.get(key)
        ex=row.get('existing') if isinstance(row.get('existing'),dict) else {}; sm=row.get('smart') if isinstance(row.get('smart'),dict) else {}
        if rec is None:
            rec={'schema':'smart_structure_shadow_state_row_v948','key':key,'ticker':ticker,'first_seen_ts':nowv,'first_seen_text':now_text(nowv),'low_price_tick_risk':bool(row.get('low_price_tick_risk')),'dynamic_zone_tolerance_pct':row.get('dynamic_zone_tolerance_pct'),'variants':{},'observation_only':True}; new+=1
        for name,plan in (('existing',ex),('smart',sm)):
            variant=(rec.get('variants') or {}).get(name) if isinstance(rec.get('variants'),dict) else None
            if not isinstance(variant,dict): variant={'trigger':plan.get('trigger'),'invalid':plan.get('invalid'),'target':plan.get('target'),'samples':{},'max_pct':0.0,'min_pct':0.0,'giveback_pct':0.0}
            variants=rec.get('variants') if isinstance(rec.get('variants'),dict) else {}; variants[name]=variant; rec['variants']=variants
        rec['last_seen_ts']=nowv; records[key]=rec
    for key,rec in list(records.items()):
        ticker=ticker_norm(rec.get('ticker')); price_state=_structure_review_price_state(ticker,fmap,ofmap,nowv)
        rec['review_price_state']=price_state; rec['review_price_checked_ts']=nowv
        if not price_state.get('fresh'):
            rec['line_state']='stale_price_wait'; rec['review_price_stale_skip_count']=int(rec.get('review_price_stale_skip_count') or 0)+1; review_price_stale_skips+=1; records[key]=rec; continue
        cur=float(price_state.get('price') or 0.0); review_price_fresh_samples+=1
        if cur<=0: continue
        for name,v in list((rec.get('variants') or {}).items()):
            if not isinstance(v,dict): continue
            trigger=_quality_optional_num(v.get('trigger')) or 0.0
            if not v.get('reached_ts') and trigger>0 and cur>=trigger*0.999:
                v['reached_ts']=nowv; v['reached_text']=now_text(nowv); v['entry_price']=cur; v['max_pct']=0.0; v['min_pct']=0.0; v['giveback_pct']=0.0
            if v.get('reached_ts') and (_quality_optional_num(v.get('entry_price')) or 0)>0:
                base=float(v['entry_price']); pctv=(cur-base)/base*100.0; v['current_pct']=round(pctv,6); v['max_pct']=max(_quality_optional_num(v.get('max_pct')) or pctv,pctv); v['min_pct']=min(_quality_optional_num(v.get('min_pct')) or pctv,pctv); v['giveback_pct']=round(float(v['max_pct'])-pctv,6)
                invalid=_quality_optional_num(v.get('invalid')); target=_quality_optional_num(v.get('target'))
                if invalid and cur<=invalid*1.001: v['invalid_breached']=True
                if target and cur>=target*0.999: v['target_hit']=True
                elapsed=max(0.0,nowv-float(v['reached_ts'])); samples=v.get('samples') if isinstance(v.get('samples'),dict) else {}
                for label,sec in SMART_STRUCTURE_HORIZONS:
                    if elapsed>=sec and label not in samples: samples[label]={'ts':nowv,'pct':v['current_pct'],'max_pct':v['max_pct'],'min_pct':v['min_pct'],'giveback_pct':v['giveback_pct']}
                v['samples']=samples
            rec['variants'][name]=v
        records[key]=rec
    records={k:v for k,v in records.items() if nowv-(_quality_optional_num(v.get('first_seen_ts')) or nowv)<=3*3600}
    vals=list(records.values()); exstats=_structure_variant_stats(vals,'existing'); smstats=_structure_variant_stats(vals,'smart')
    def delta(label,key='avg_pct'):
        a=((smstats.get(label) or {}).get(key)); b=((exstats.get(label) or {}).get(key)); return round(float(a)-float(b),4) if isinstance(a,(int,float)) and isinstance(b,(int,float)) else None
    status={'schema':'smart_structure_shadow_review_status_v948','version':VERSION,'build':BUILD_LABEL,'state':'ACTIVE' if rows else 'WAITING','updated_ts':nowv,'updated_text':now_text(nowv),'source_rows':len(rows),'tracked_records':len(vals),'new_records_this_cycle':new,'existing':exstats,'smart':smstats,'smart_minus_existing':{'10m_avg_pct':delta('10m'),'60m_avg_pct':delta('60m'),'10m_avg_min_pct':delta('10m','avg_min_pct'),'10m_avg_giveback_pct':delta('10m','avg_giveback_pct')},'low_price_tick_risk_records':sum(1 for r in vals if r.get('low_price_tick_risk')),'policy':'smart zones are review-only; existing v925 lines remain the only trading lines','trading_rules_changed':False}
    save_json(SMART_STRUCTURE_STATE,{'schema':'smart_structure_shadow_state_v948','version':VERSION,'updated_ts':nowv,'records':records}); save_json(SMART_STRUCTURE_STATUS,status); return status



# =============================================================================
# review_worker v0.950: structure discovery, method event, and plan outcome review
# =============================================================================

def _structure_plan_stats(records: List[Dict[str,Any]], method: str) -> Dict[str,Any]:
    rows=[r for r in records if str(r.get('method') or '')==method]
    reached=[r for r in rows if r.get('trigger_reached_ts')]
    state_counts=Counter(str(r.get('structure_state') or 'unknown') for r in rows)
    activation_counts=Counter(str(r.get('trigger_activation_mode') or 'unknown') for r in rows)
    out={'tracked':len(rows),'complete_tracked':sum(1 for r in rows if r.get('source_plan_complete')),'partial_tracked':sum(1 for r in rows if not r.get('source_plan_complete')),'trigger_reached':len(reached),'support_touched':sum(1 for r in rows if r.get('support_touch_count',0)>0),'target_first':sum(1 for r in reached if r.get('first_terminal')=='target'),'invalid_first':sum(1 for r in reached if r.get('first_terminal')=='invalid'),'terminal_unknown':sum(1 for r in reached if r.get('first_terminal') in (None,'','ambiguous')),'weakened_lines':sum(1 for r in rows if r.get('line_weakened')),'role_flip_confirmed':sum(1 for r in rows if r.get('role_flip_confirmed_ts')),'stale_unreached':sum(1 for r in rows if r.get('line_state')=='stale_unreached'),'confirmed_event_started':sum(1 for r in rows if r.get('activation_source')=='confirmed_completed_candle_event_seen_by_review'),'structure_state_counts':dict(state_counts),'activation_mode_counts':dict(activation_counts)}
    for label,_sec in STRUCTURE_LAB_HORIZONS:
        vals=[]; peaks=[]; mins=[]; give=[]; rel=[]
        for r in reached:
            sample_map=r.get('samples'); sm=sample_map.get(label) if isinstance(sample_map,dict) else None
            if not isinstance(sm,dict): continue
            for arr,key in ((vals,'pct'),(peaks,'max_pct'),(mins,'min_pct'),(give,'giveback_pct'),(rel,'relative_to_btc_pct')):
                v=_quality_optional_num(sm.get(key))
                if v is not None: arr.append(v)
        out[label]={'n':len(vals),'avg_pct':round(sum(vals)/len(vals),4) if vals else None,'median_pct':round(_quality_percentile(vals,0.5),4) if vals else None,'avg_max_pct':round(sum(peaks)/len(peaks),4) if peaks else None,'avg_min_pct':round(sum(mins)/len(mins),4) if mins else None,'avg_giveback_pct':round(sum(give)/len(give),4) if give else None,'avg_relative_to_btc_pct':round(sum(rel)/len(rel),4) if rel else None}
    return out


def _structure_missed_stats(records: List[Dict[str,Any]]) -> Dict[str,Any]:
    rows=list(records); reasons=Counter(str(r.get('reason') or 'unknown') for r in rows); sources=Counter(str(r.get('source') or 'unknown') for r in rows)
    discovery=Counter(); incomplete=Counter(); method_states={m:Counter() for m in ('A_SWING','B_REACTION_ZONE','C_BREAK_RETEST','D_SUPPLY_DEMAND','E_VOLUME_PROFILE')}
    for r in rows:
        diagnostics=r.get('method_diagnostics') if isinstance(r.get('method_diagnostics'),dict) else {}
        for method,diag in diagnostics.items():
            if method not in method_states or not isinstance(diag,dict): continue
            method_states[method][str(diag.get('structure_state') or 'unknown')]+=1
            discovery_reasons=diag.get('discovery_reasons') if isinstance(diag.get('discovery_reasons'),list) else []
            incomplete_reasons=diag.get('incomplete_reasons') if isinstance(diag.get('incomplete_reasons'),list) else []
            for reason in discovery_reasons: discovery[f'{method}:{reason}']+=1
            for reason in incomplete_reasons: incomplete[f'{method}:{reason}']+=1
    out={'tracked':len(rows),'reason_top':[{'reason':k,'count':v} for k,v in reasons.most_common(15)],'source_counts':dict(sources),'method_discovery_reason_top':[{'reason':k,'count':v} for k,v in discovery.most_common(20)],'method_incomplete_reason_top':[{'reason':k,'count':v} for k,v in incomplete.most_common(20)],'method_state_counts':{m:dict(v) for m,v in method_states.items()},'later_structure_created':sum(1 for r in rows if r.get('later_structure_created_ts')),'later_complete_plan_created':sum(1 for r in rows if r.get('later_complete_plan_created_ts'))}
    for label,_sec in STRUCTURE_LAB_HORIZONS:
        vals=[]; peaks=[]; mins=[]
        for r in rows:
            sample_map=r.get('samples'); sm=sample_map.get(label) if isinstance(sample_map,dict) else None
            if not isinstance(sm,dict): continue
            v=_quality_optional_num(sm.get('pct')); p=_quality_optional_num(sm.get('max_pct')); m=_quality_optional_num(sm.get('min_pct'))
            if v is not None: vals.append(v)
            if p is not None: peaks.append(p)
            if m is not None: mins.append(m)
        out[label]={'n':len(vals),'avg_pct':round(sum(vals)/len(vals),4) if vals else None,'median_pct':round(_quality_percentile(vals,0.5),4) if vals else None,'avg_max_pct':round(sum(peaks)/len(peaks),4) if peaks else None,'avg_min_pct':round(sum(mins)/len(mins),4) if mins else None,'rise_0_5_count':sum(1 for v in peaks if v>=0.5),'rise_1_0_count':sum(1 for v in peaks if v>=1.0)}
    return out


def _structure_zone_bounds(zone: Any) -> tuple[Optional[float],Optional[float]]:
    if isinstance(zone,(list,tuple)) and len(zone)>=2:
        low=_quality_optional_num(zone[0]); high=_quality_optional_num(zone[1])
    else:
        z=zone if isinstance(zone,dict) else {}
        low=_quality_optional_num(z.get('low_raw'),z.get('low')); high=_quality_optional_num(z.get('high_raw'),z.get('high'))
    if low is None or high is None: return None,None
    return min(low,high),max(low,high)


_STRUCTURE_DETAIL_KEYS_CACHE: Optional[set[str]] = None


def _v1080_rotate_structure_horizon() -> Dict[str, Any]:
    global _STRUCTURE_HORIZON_SUMMARY_CACHE, _STRUCTURE_HORIZON_SUMMARY_LEDGER_SIZE
    before=_v1080_size(STRUCTURE_LAB_HORIZON_LEDGER)
    if before > STRUCTURE_HORIZON_MAX_BYTES_V1080:
        summary,_meta=_load_structure_horizon_summary()
    else:
        summary=_STRUCTURE_HORIZON_SUMMARY_CACHE if isinstance(_STRUCTURE_HORIZON_SUMMARY_CACHE,dict) else load_json(STRUCTURE_LAB_HORIZON_SUMMARY,{}) or {}
    result=_v1080_rotate_whole_jsonl(STRUCTURE_LAB_HORIZON_LEDGER,STRUCTURE_HORIZON_ARCHIVE_V1080,'structure_horizon',STRUCTURE_HORIZON_MAX_BYTES_V1080,STRUCTURE_ARCHIVE_MAX_FILES_V1080,STRUCTURE_ARCHIVE_MAX_BYTES_V1080)
    if result.get('rotated') and isinstance(summary,dict):
        summary=dict(summary); summary['ledger_size_bytes']=0; summary['active_segment_rotated_ts_v1080']=time.time(); summary['active_segment_generation_v1080']=int(summary.get('active_segment_generation_v1080') or 0)+1
        save_json(STRUCTURE_LAB_HORIZON_SUMMARY,summary); _STRUCTURE_HORIZON_SUMMARY_CACHE=summary; _STRUCTURE_HORIZON_SUMMARY_LEDGER_SIZE=0
    return result


def _v1080_rotate_good_s2_result() -> Dict[str, Any]:
    global _GOOD_S2_FINAL_AGG_V1014
    before=_v1080_size(GOOD_S2_RESULT_LEDGER)
    agg=_prepare_good_s2_summary_v1014() if before > GOOD_S2_RESULT_MAX_BYTES_V1080 else (_GOOD_S2_FINAL_AGG_V1014 or load_json(GOOD_S2_FINAL_SUMMARY_V1014,{}) or {})
    result=_v1080_rotate_whole_jsonl(GOOD_S2_RESULT_LEDGER,GOOD_S2_RESULT_ARCHIVE_V1080,'good_s2_result',GOOD_S2_RESULT_MAX_BYTES_V1080,GOOD_S2_RESULT_ARCHIVE_MAX_FILES_V1080,GOOD_S2_RESULT_ARCHIVE_MAX_BYTES_V1080)
    if result.get('rotated') and isinstance(agg,dict):
        agg=dict(agg); agg['source_signature']=_good_s2_final_signature_v1014(); agg['active_segment_rotated_ts_v1080']=time.time(); agg['active_segment_generation_v1080']=int(agg.get('active_segment_generation_v1080') or 0)+1
        save_json(GOOD_S2_FINAL_SUMMARY_V1014,agg); _GOOD_S2_FINAL_AGG_V1014=agg
    return result


def _v1080_review_trace_maintenance(nowv: float, *, startup: bool=False) -> Dict[str, Any]:
    global _V1080_STARTUP_ROTATION_OCCURRED, _V1080_LAST_REVIEW_TRACE_STATUS
    stale_tmp_cleanup=_v1080_cleanup_stale_quality_tmp(nowv) if startup else {'deleted_count':0,'deleted_bytes':0,'scope':'startup_only'}
    results={
        'structure_detail':_v1080_rotate_whole_jsonl(STRUCTURE_LAB_EVENT_DETAIL_LEDGER,STRUCTURE_DETAIL_ARCHIVE_V1080,'structure_detail',STRUCTURE_DETAIL_MAX_BYTES_V1080,STRUCTURE_ARCHIVE_MAX_FILES_V1080,STRUCTURE_ARCHIVE_MAX_BYTES_V1080),
        'structure_horizon':_v1080_rotate_structure_horizon(),
        'structure_final':_v1080_rotate_whole_jsonl(STRUCTURE_LAB_FINAL_LEDGER,STRUCTURE_FINAL_ARCHIVE_V1080,'structure_final',STRUCTURE_FINAL_MAX_BYTES_V1080,STRUCTURE_ARCHIVE_MAX_FILES_V1080,STRUCTURE_ARCHIVE_MAX_BYTES_V1080),
        'good_s2_result':_v1080_rotate_good_s2_result(),
        'quality_shadow':_quality_rotate_ledger(nowv),
    }
    rotated=any(bool(x.get('rotated')) for x in results.values() if isinstance(x,dict))
    if startup and rotated: _V1080_STARTUP_ROTATION_OCCURRED=True
    status={'schema':'review_trace_rotation_status_v1080','version':VERSION,'build':BUILD_LABEL,'updated_ts':nowv,'updated_text':now_text(nowv),'startup':startup,'rotated_any':rotated,'stale_tmp_cleanup':stale_tmp_cleanup,'results':results,'active_sizes':{
        'structure_detail':_v1080_size(STRUCTURE_LAB_EVENT_DETAIL_LEDGER),'structure_horizon':_v1080_size(STRUCTURE_LAB_HORIZON_LEDGER),'structure_final':_v1080_size(STRUCTURE_LAB_FINAL_LEDGER),'good_s2_result':_v1080_size(GOOD_S2_RESULT_LEDGER),'quality_shadow':_v1080_size(QUALITY_SHADOW_LEDGER)},'archive_status':{
        'structure_detail':_v1080_archive_status(STRUCTURE_DETAIL_ARCHIVE_V1080,'structure_detail_*.jsonl.gz'),'structure_horizon':_v1080_archive_status(STRUCTURE_HORIZON_ARCHIVE_V1080,'structure_horizon_*.jsonl.gz'),'structure_final':_v1080_archive_status(STRUCTURE_FINAL_ARCHIVE_V1080,'structure_final_*.jsonl.gz'),'good_s2_result':_v1080_archive_status(GOOD_S2_RESULT_ARCHIVE_V1080,'good_s2_result_*.jsonl.gz'),'quality_shadow':_v1080_archive_status(QUALITY_SHADOW_ARCHIVE,'quality_shadow_result_*.jsonl.gz')},'policy':'non-core observation traces only; active and archive total bounded; core ledgers untouched','core_ledgers_changed':False,'strategy_rules_changed':False,'auto_buy':False}
    save_json(REVIEW_TRACE_ROTATION_STATUS_V1080,status); _V1080_LAST_REVIEW_TRACE_STATUS=status
    return status


def _append_structure_detail_once(rec: Dict[str,Any]) -> bool:
    key=str(rec.get('event_key') or rec.get('plan_key') or '').strip()
    if not key or _dedup_contains_v1013('structure_detail',key): return False
    _v1080_rotate_whole_jsonl(STRUCTURE_LAB_EVENT_DETAIL_LEDGER,STRUCTURE_DETAIL_ARCHIVE_V1080,'structure_detail',STRUCTURE_DETAIL_MAX_BYTES_V1080,STRUCTURE_ARCHIVE_MAX_FILES_V1080,STRUCTURE_ARCHIVE_MAX_BYTES_V1080)
    STRUCTURE_LAB_EVENT_DETAIL_LEDGER.parent.mkdir(parents=True,exist_ok=True)
    with STRUCTURE_LAB_EVENT_DETAIL_LEDGER.open('a',encoding='utf-8') as handle:
        handle.write(json.dumps(rec,ensure_ascii=False,separators=(',',':'),default=str)+'\n'); handle.flush(); os.fsync(handle.fileno())
    _dedup_commit_v1013('structure_detail',key)
    return True


_STRUCTURE_HORIZON_KEYS_CACHE: Optional[set[str]] = None
_STRUCTURE_FINAL_KEYS_CACHE: Optional[set[str]] = None
_STRUCTURE_HORIZON_SUMMARY_CACHE: Optional[Dict[str,Any]] = None
_STRUCTURE_HORIZON_SUMMARY_LEDGER_SIZE = -1
_STRUCTURE_HORIZON_SUMMARY_MEMORY_HITS = 0
_STRUCTURE_HORIZON_SUMMARY_DISK_HITS = 0
_STRUCTURE_HORIZON_SUMMARY_FULL_SCANS = 0
_STRUCTURE_HORIZON_KEY_INDEX_LOADS = 0
_STRUCTURE_FINAL_KEY_INDEX_LOADS = 0
_STRUCTURE_HORIZON_BITS = {label:(1 << idx) for idx,(label,_sec) in enumerate(STRUCTURE_LAB_HORIZONS)}
_STRUCTURE_ALL_HORIZONS_MASK = sum(_STRUCTURE_HORIZON_BITS.values())


def _structure_zone_pair(zone: Any) -> Optional[List[float]]:
    low,high=_structure_zone_bounds(zone)
    if low is None or high is None: return None
    return [float(low),float(high)]


def _structure_active_record(rec: Dict[str,Any]) -> Dict[str,Any]:
    support=_structure_zone_pair(rec.get('support_zone'))
    trigger_zone=_structure_zone_pair(rec.get('trigger_zone'))
    out={
        'schema':'structure_lab_active_row_v956',
        'event_key':str(rec.get('event_key') or rec.get('plan_key') or ''),
        'method':str(rec.get('method') or ''),
        'ticker':ticker_norm(rec.get('ticker')),
        'candidate_exact_identity':rec.get('candidate_exact_identity') or rec.get('candidate_exact_identity_last'),
        'candidate_exact_identity_last':rec.get('candidate_exact_identity_last') or rec.get('candidate_exact_identity'),
        'first_seen_ts':_quality_optional_num(rec.get('first_seen_ts')),
        'first_price':_quality_optional_num(rec.get('first_price')),
        'structure_state':rec.get('structure_state'),
        'source_plan_complete':bool(rec.get('source_plan_complete')),
        'trigger_activation_mode':rec.get('trigger_activation_mode'),
        'trigger':_quality_optional_num(rec.get('trigger')),
        'invalid':_quality_optional_num(rec.get('invalid')),
        'target':_quality_optional_num(rec.get('target')),
        'support_zone':support,
        'trigger_zone':trigger_zone,
        'primary_tf':rec.get('primary_tf'),
        'source_event_ts':_quality_optional_num(rec.get('source_event_ts')),
        'source_event_price':_quality_optional_num(rec.get('source_event_price')),
        'source_to_review_lag_sec':_quality_optional_num(rec.get('source_to_review_lag_sec')),
        'line_state':rec.get('line_state'),
        'support_touch_count':int(rec.get('support_touch_count') or 0),
        'trigger_retest_count':int(rec.get('trigger_retest_count') or 0),
        'max_pct':_quality_optional_num(rec.get('max_pct')) or 0.0,
        'min_pct':_quality_optional_num(rec.get('min_pct')) or 0.0,
        'giveback_pct':_quality_optional_num(rec.get('giveback_pct')) or 0.0,
        'btc_start_price':_quality_optional_num(rec.get('btc_start_price')),
        'trigger_reached_ts':_quality_optional_num(rec.get('trigger_reached_ts')),
        'entry_price':_quality_optional_num(rec.get('entry_price')),
        'activation_source':rec.get('activation_source'),
        'source_current_state_fresh':bool(rec.get('source_current_state_fresh')),
        'source_map_refresh_pending':bool(rec.get('source_map_refresh_pending')),
        'source_priority_lane':rec.get('source_priority_lane'),
        'last_source_seen_ts':_quality_optional_num(rec.get('last_source_seen_ts')),
        'review_price_source':rec.get('review_price_source'),
        'review_price_age_sec':_quality_optional_num(rec.get('review_price_age_sec')),
        'review_price_stale_skip_count':int(rec.get('review_price_stale_skip_count') or 0),
        'line_age_sec':_quality_optional_num(rec.get('line_age_sec')),
        'last_support_touch_ts':_quality_optional_num(rec.get('last_support_touch_ts')),
        'line_weakened':bool(rec.get('line_weakened')),
        'weakening_reason':rec.get('weakening_reason'),
        'last_trigger_retest_ts':_quality_optional_num(rec.get('last_trigger_retest_ts')),
        'role_flip_confirmed_ts':_quality_optional_num(rec.get('role_flip_confirmed_ts')),
        'current_price':_quality_optional_num(rec.get('current_price')),
        'current_pct':_quality_optional_num(rec.get('current_pct')),
        'invalid_ts':_quality_optional_num(rec.get('invalid_ts')),
        'target_ts':_quality_optional_num(rec.get('target_ts')),
        'first_terminal':rec.get('first_terminal'),
        'next_review_due_ts':_quality_optional_num(rec.get('next_review_due_ts')),
        'last_review_update_ts':_quality_optional_num(rec.get('last_review_update_ts')),
        'last_review_interval_sec':_quality_optional_num(rec.get('last_review_interval_sec')),
        'review_update_count':int(rec.get('review_update_count') or 0),
        'horizon_mask':int(rec.get('horizon_mask') or 0),
    }
    return {k:v for k,v in out.items() if v is not None and v!=''}


def _load_jsonl_key_set(paths: List[Path], key_builder) -> set[str]:
    # v1007: recent bounded dedup index; active rows also carry horizon/final masks.
    keys:set[str]=set()
    for path in paths:
        if not path.exists(): continue
        try:
            for line in _tail_text_lines(path, 120000):
                try:
                    row=json.loads(line)
                except Exception:
                    continue
                if not isinstance(row,dict): continue
                key=key_builder(row)
                if key: keys.add(key)
        except Exception:
            continue
    return keys


def _structure_horizon_key(row: Dict[str,Any]) -> str:
    event_key=str(row.get('event_key') or '').strip(); label=str(row.get('horizon') or '').strip()
    return f'{event_key}|{label}' if event_key and label else ''


def _structure_summary_empty() -> Dict[str,Any]:
    return {'schema':'structure_lab_horizon_summary_v956','version':VERSION,'updated_ts':0.0,'ledger_size_bytes':0,'total_rows':0,'methods':{}}


def _structure_summary_add(summary: Dict[str,Any], row: Dict[str,Any]) -> None:
    method=str(row.get('method') or 'unknown'); label=str(row.get('horizon') or '')
    if not label: return
    methods=summary.setdefault('methods',{}); m=methods.setdefault(method,{}); bucket=m.setdefault(label,{'n':0,'sum_pct':0.0,'sum_max_pct':0.0,'sum_min_pct':0.0,'sum_giveback_pct':0.0,'sum_relative_to_btc_pct':0.0,'relative_n':0})
    bucket['n']=int(bucket.get('n') or 0)+1
    for source_key,sum_key in (('pct','sum_pct'),('max_pct','sum_max_pct'),('min_pct','sum_min_pct'),('giveback_pct','sum_giveback_pct')):
        val=_quality_optional_num(row.get(source_key))
        if val is not None: bucket[sum_key]=float(bucket.get(sum_key) or 0.0)+float(val)
    rel=_quality_optional_num(row.get('relative_to_btc_pct'))
    if rel is not None:
        bucket['sum_relative_to_btc_pct']=float(bucket.get('sum_relative_to_btc_pct') or 0.0)+float(rel)
        bucket['relative_n']=int(bucket.get('relative_n') or 0)+1
    summary['total_rows']=int(summary.get('total_rows') or 0)+1


def _load_structure_horizon_summary() -> tuple[Dict[str,Any],Dict[str,Any]]:
    global _STRUCTURE_HORIZON_SUMMARY_CACHE, _STRUCTURE_HORIZON_SUMMARY_LEDGER_SIZE
    global _STRUCTURE_HORIZON_SUMMARY_MEMORY_HITS, _STRUCTURE_HORIZON_SUMMARY_DISK_HITS, _STRUCTURE_HORIZON_SUMMARY_FULL_SCANS
    global _STRUCTURE_HORIZON_KEYS_CACHE, _STRUCTURE_HORIZON_KEY_INDEX_LOADS
    ledger_size=STRUCTURE_LAB_HORIZON_LEDGER.stat().st_size if STRUCTURE_LAB_HORIZON_LEDGER.exists() else 0
    if isinstance(_STRUCTURE_HORIZON_SUMMARY_CACHE,dict) and _STRUCTURE_HORIZON_SUMMARY_LEDGER_SIZE==ledger_size:
        _STRUCTURE_HORIZON_SUMMARY_MEMORY_HITS+=1
        return _STRUCTURE_HORIZON_SUMMARY_CACHE,{'memory_reused':True,'disk_summary_reused':False,'rebuilt_from_ledger':False,'ledger_size_bytes':ledger_size}
    obj=load_json(STRUCTURE_LAB_HORIZON_SUMMARY,{})
    if isinstance(obj,dict) and isinstance(obj.get('methods'),dict):
        old_size=int(obj.get('ledger_size_bytes') or 0)
        if old_size==ledger_size:
            _STRUCTURE_HORIZON_SUMMARY_CACHE=obj
            _STRUCTURE_HORIZON_SUMMARY_LEDGER_SIZE=ledger_size
            _STRUCTURE_HORIZON_SUMMARY_DISK_HITS+=1
            return obj,{'memory_reused':False,'disk_summary_reused':True,'rebuilt_from_ledger':False,'incremental_rows':0,'ledger_size_bytes':ledger_size}
        if 0 <= old_size < ledger_size and STRUCTURE_LAB_HORIZON_LEDGER.exists():
            summary=dict(obj); rows_added=0; consumed=old_size
            try:
                with STRUCTURE_LAB_HORIZON_LEDGER.open('rb') as handle:
                    handle.seek(old_size); data=handle.read()
                complete=data if data.endswith(b'\n') else data[:data.rfind(b'\n')+1] if b'\n' in data else b''
                consumed=old_size+len(complete)
                for raw in complete.splitlines():
                    try: row=json.loads(raw.decode('utf-8','ignore'))
                    except Exception: continue
                    if isinstance(row,dict): _structure_summary_add(summary,row); rows_added+=1
                summary['ledger_size_bytes']=consumed
                _STRUCTURE_HORIZON_SUMMARY_CACHE=summary
                _STRUCTURE_HORIZON_SUMMARY_LEDGER_SIZE=consumed
                _STRUCTURE_HORIZON_SUMMARY_DISK_HITS+=1
                return summary,{'memory_reused':False,'disk_summary_reused':False,'rebuilt_from_ledger':False,'incremental_rows':rows_added,'ledger_size_bytes':consumed}
            except Exception:
                pass
    summary=_structure_summary_empty()
    if STRUCTURE_LAB_HORIZON_LEDGER.exists():
        try:
            with STRUCTURE_LAB_HORIZON_LEDGER.open('r',encoding='utf-8',errors='ignore') as handle:
                for line in handle:
                    try: row=json.loads(line)
                    except Exception: continue
                    if isinstance(row,dict): _structure_summary_add(summary,row)
        except Exception: pass
    summary['ledger_size_bytes']=ledger_size
    _STRUCTURE_HORIZON_KEYS_CACHE=None
    _STRUCTURE_HORIZON_SUMMARY_CACHE=summary
    _STRUCTURE_HORIZON_SUMMARY_LEDGER_SIZE=ledger_size
    _STRUCTURE_HORIZON_SUMMARY_FULL_SCANS+=1
    return summary,{'memory_reused':False,'disk_summary_reused':False,'rebuilt_from_ledger':True,'incremental_rows':0,'ledger_size_bytes':ledger_size}


def _append_jsonl_batch_fsync(path: Path, rows: List[Dict[str,Any]]) -> int:
    if not rows: return 0
    payload=''.join(json.dumps(row,ensure_ascii=False,separators=(',',':'),default=str)+'\n' for row in rows)
    if path == STRUCTURE_LAB_HORIZON_LEDGER and _v1080_size(path)+len(payload.encode('utf-8')) > STRUCTURE_HORIZON_MAX_BYTES_V1080:
        _v1080_rotate_structure_horizon()
    elif path == STRUCTURE_LAB_FINAL_LEDGER and _v1080_size(path)+len(payload.encode('utf-8')) > STRUCTURE_FINAL_MAX_BYTES_V1080:
        _v1080_rotate_whole_jsonl(path,STRUCTURE_FINAL_ARCHIVE_V1080,'structure_final',STRUCTURE_FINAL_MAX_BYTES_V1080,STRUCTURE_ARCHIVE_MAX_FILES_V1080,STRUCTURE_ARCHIVE_MAX_BYTES_V1080)
    path.parent.mkdir(parents=True,exist_ok=True)
    original_size=path.stat().st_size if path.exists() else 0
    try:
        with path.open('a',encoding='utf-8') as handle:
            handle.write(payload)
            handle.flush()
            os.fsync(handle.fileno())
    except Exception:
        try:
            with path.open('r+b') as rollback:
                rollback.truncate(original_size)
                rollback.flush()
                os.fsync(rollback.fileno())
        except Exception:
            pass
        raise
    if path == STRUCTURE_LAB_HORIZON_LEDGER:
        _dedup_commit_many_v1013('structure_horizon',[str(row.get('result_key') or '') for row in rows])
    elif path == STRUCTURE_LAB_FINAL_LEDGER:
        _dedup_commit_many_v1013('structure_final',[str(row.get('event_key') or '') for row in rows])
    return len(rows)

def _append_structure_horizon_once(rec: Dict[str,Any], label: str, sample: Dict[str,Any], summary: Dict[str,Any], *, migrated: bool=False, batch_rows: Optional[List[Dict[str,Any]]]=None) -> bool:
    global _STRUCTURE_HORIZON_KEYS_CACHE
    event_key=str(rec.get('event_key') or '').strip()
    if not event_key or label not in _STRUCTURE_HORIZON_BITS: return False
    bit=_STRUCTURE_HORIZON_BITS[label]
    if int(rec.get('horizon_mask') or 0) & bit:
        return False
    key=f'{event_key}|{label}'
    if _dedup_contains_v1013('structure_horizon',key):
        rec['horizon_mask']=int(rec.get('horizon_mask') or 0)|_STRUCTURE_HORIZON_BITS[label]
        return False
    row={
        'schema':'structure_lab_horizon_result_v956','version':VERSION,'result_key':key,
        'event_key':event_key,'method':rec.get('method'),'ticker':rec.get('ticker'),'horizon':label,
        'candidate_exact_identity':rec.get('candidate_exact_identity') or rec.get('candidate_exact_identity_last'),
        'event_ts':rec.get('trigger_reached_ts') or rec.get('first_seen_ts'),'entry_price':rec.get('entry_price') or rec.get('first_price'),
        'sample_ts':_quality_optional_num(sample.get('ts')) or now_ts(),'pct':_quality_optional_num(sample.get('pct')),
        'max_pct':_quality_optional_num(sample.get('max_pct')),'min_pct':_quality_optional_num(sample.get('min_pct')),
        'giveback_pct':_quality_optional_num(sample.get('giveback_pct')),'btc_pct':_quality_optional_num(sample.get('btc_pct')),
        'relative_to_btc_pct':_quality_optional_num(sample.get('relative_to_btc_pct')),'sample_lag_sec':_quality_optional_num(sample.get('sample_lag_sec')),
        'first_terminal':rec.get('first_terminal'),'invalid_ts':rec.get('invalid_ts'),'target_ts':rec.get('target_ts'),
        'migrated_from_v955':bool(migrated),'observation_only':True,
    }
    if batch_rows is not None:
        batch_rows.append(row)
    else:
        _v1080_rotate_structure_horizon()
        STRUCTURE_LAB_HORIZON_LEDGER.parent.mkdir(parents=True,exist_ok=True)
        with STRUCTURE_LAB_HORIZON_LEDGER.open('a',encoding='utf-8') as handle:
            handle.write(json.dumps(row,ensure_ascii=False,separators=(',',':'),default=str)+'\n'); handle.flush(); os.fsync(handle.fileno())
        _dedup_commit_v1013('structure_horizon',key)
    _dedup_mark_pending_v1013('structure_horizon',key); _structure_summary_add(summary,row)
    rec['horizon_mask']=int(rec.get('horizon_mask') or 0)|_STRUCTURE_HORIZON_BITS[label]
    return True


def _structure_final_key(row: Dict[str,Any]) -> str:
    return str(row.get('event_key') or '').strip()


def _append_structure_final_once(rec: Dict[str,Any], nowv: float, *, migrated: bool=False, batch_rows: Optional[List[Dict[str,Any]]]=None) -> bool:
    global _STRUCTURE_FINAL_KEYS_CACHE
    key=str(rec.get('event_key') or '').strip()
    if not key: return False
    if _dedup_contains_v1013('structure_final',key): return False
    row={'schema':'structure_lab_event_final_v956','version':VERSION,'event_key':key,'method':rec.get('method'),'ticker':rec.get('ticker'),'event_ts':rec.get('trigger_reached_ts') or rec.get('first_seen_ts'),'entry_price':rec.get('entry_price') or rec.get('first_price'),'completed_ts':nowv,'max_pct':rec.get('max_pct'),'min_pct':rec.get('min_pct'),'giveback_pct':rec.get('giveback_pct'),'current_pct':rec.get('current_pct'),'first_terminal':rec.get('first_terminal'),'invalid_ts':rec.get('invalid_ts'),'target_ts':rec.get('target_ts'),'horizon_mask':int(rec.get('horizon_mask') or 0),'migrated_from_v955':bool(migrated),'observation_only':True}
    if batch_rows is not None:
        batch_rows.append(row)
    else:
        _v1080_rotate_whole_jsonl(STRUCTURE_LAB_FINAL_LEDGER,STRUCTURE_FINAL_ARCHIVE_V1080,'structure_final',STRUCTURE_FINAL_MAX_BYTES_V1080,STRUCTURE_ARCHIVE_MAX_FILES_V1080,STRUCTURE_ARCHIVE_MAX_BYTES_V1080)
        STRUCTURE_LAB_FINAL_LEDGER.parent.mkdir(parents=True,exist_ok=True)
        with STRUCTURE_LAB_FINAL_LEDGER.open('a',encoding='utf-8') as handle:
            handle.write(json.dumps(row,ensure_ascii=False,separators=(',',':'),default=str)+'\n'); handle.flush(); os.fsync(handle.fileno())
        _dedup_commit_v1013('structure_final',key)
    _dedup_mark_pending_v1013('structure_final',key)
    return True


def _migrate_structure_record(rec: Dict[str,Any], nowv: float, summary: Dict[str,Any], horizon_batch: List[Dict[str,Any]], final_batch: List[Dict[str,Any]]) -> tuple[Optional[Dict[str,Any]],int,bool]:
    active=_structure_active_record(rec); migrated_samples=0
    samples=rec.get('samples') if isinstance(rec.get('samples'),dict) else {}
    for label,sample in samples.items():
        if label in _STRUCTURE_HORIZON_BITS and isinstance(sample,dict):
            if _append_structure_horizon_once(active,label,sample,summary,migrated=True,batch_rows=horizon_batch): migrated_samples+=1
    if int(active.get('horizon_mask') or 0)==_STRUCTURE_ALL_HORIZONS_MASK:
        _append_structure_final_once(active,nowv,migrated=True,batch_rows=final_batch)
        return None,migrated_samples,True
    if _quality_optional_num(active.get('next_review_due_ts')) is None:
        interval=_structure_review_interval(active,nowv); active['next_review_due_ts']=nowv+(abs(hash(str(active.get('event_key'))))%max(1,int(interval)))
    return active,migrated_samples,False


def _load_structure_state_v956(nowv: float, summary: Dict[str,Any]) -> tuple[Dict[str,Dict[str,Any]],Dict[str,int]]:
    """Load active structure state once per process; append-only ledgers remain the durable source."""
    global _STRUCTURE_ACTIVE_CACHE_V1011, _STRUCTURE_ACTIVE_META_V1011, _STRUCTURE_ACTIVE_LAST_CHECKPOINT_V1011
    if _STRUCTURE_ACTIVE_CACHE_V1011 is not None:
        return _STRUCTURE_ACTIVE_CACHE_V1011, {'migrated_records':0,'migrated_samples':0,'finalized_on_migration':0,'memory_reused':1}
    if STRUCTURE_LAB_ACTIVE_STATE.exists():
        obj=load_json(STRUCTURE_LAB_ACTIVE_STATE,{}) or {}
        raw=obj.get('records') if isinstance(obj,dict) else {}
        records={str(k):_structure_active_record(v) for k,v in raw.items() if isinstance(v,dict)} if isinstance(raw,dict) else {}
        _STRUCTURE_ACTIVE_CACHE_V1011=records
        _STRUCTURE_ACTIVE_META_V1011={'loaded_from':STRUCTURE_LAB_ACTIVE_STATE.name,'loaded_ts':nowv}
        _STRUCTURE_ACTIVE_LAST_CHECKPOINT_V1011=float(obj.get('updated_ts') or nowv) if isinstance(obj,dict) else nowv
        return records,{'migrated_records':0,'migrated_samples':0,'finalized_on_migration':0,'memory_reused':0}
    source_path=None
    for path in (STRUCTURE_LAB_STATE_V955,STRUCTURE_LAB_STATE_V952):
        if path.exists(): source_path=path; break
    raw={}
    if source_path is not None:
        obj=load_json(source_path,{}) or {}; raw=obj.get('records') if isinstance(obj,dict) else {}
    out:Dict[str,Dict[str,Any]]={}; migrated_records=0; migrated_samples=0; finalized=0; horizon_batch:List[Dict[str,Any]]=[]; final_batch:List[Dict[str,Any]]=[]
    if isinstance(raw,dict):
        for key,val in raw.items():
            if not isinstance(val,dict): continue
            active,sample_count,was_final=_migrate_structure_record(dict(val),nowv,summary,horizon_batch,final_batch)
            migrated_records+=1; migrated_samples+=sample_count; finalized+=int(was_final)
            if active is not None: out[str(active.get('event_key') or key)]=active
    _append_jsonl_batch_fsync(STRUCTURE_LAB_HORIZON_LEDGER,horizon_batch)
    _append_jsonl_batch_fsync(STRUCTURE_LAB_FINAL_LEDGER,final_batch)
    _STRUCTURE_ACTIVE_CACHE_V1011=out
    _STRUCTURE_ACTIVE_META_V1011={'loaded_from':str(source_path.name if source_path else 'empty'),'loaded_ts':nowv}
    _STRUCTURE_ACTIVE_LAST_CHECKPOINT_V1011=0.0
    return out,{'migrated_records':migrated_records,'migrated_samples':migrated_samples,'finalized_on_migration':finalized,'migration_horizon_batch_rows':len(horizon_batch),'migration_final_batch_rows':len(final_batch),'memory_reused':0}


def _load_structure_missed_state_v956() -> tuple[Dict[str,Dict[str,Any]],int]:
    global _STRUCTURE_MISSED_CACHE_V1011, _STRUCTURE_MISSED_META_V1011, _STRUCTURE_MISSED_LAST_CHECKPOINT_V1011
    if _STRUCTURE_MISSED_CACHE_V1011 is not None:
        return _STRUCTURE_MISSED_CACHE_V1011,0
    if STRUCTURE_MISSED_STATE.exists():
        obj=load_json(STRUCTURE_MISSED_STATE,{}) or {}; raw=obj.get('records') if isinstance(obj,dict) else {}
        out={str(k):dict(v) for k,v in raw.items() if isinstance(v,dict)} if isinstance(raw,dict) else {}
        _STRUCTURE_MISSED_CACHE_V1011=out
        _STRUCTURE_MISSED_META_V1011={'loaded_from':STRUCTURE_MISSED_STATE.name,'loaded_ts':time.time()}
        _STRUCTURE_MISSED_LAST_CHECKPOINT_V1011=float(obj.get('updated_ts') or time.time()) if isinstance(obj,dict) else time.time()
        return out,0
    for path in (STRUCTURE_MISSED_STATE_V955,STRUCTURE_MISSED_STATE_V952):
        if not path.exists(): continue
        obj=load_json(path,{}) or {}; raw=obj.get('records') if isinstance(obj,dict) else {}
        out={str(k):dict(v) for k,v in raw.items() if isinstance(v,dict)} if isinstance(raw,dict) else {}
        _STRUCTURE_MISSED_CACHE_V1011=out
        _STRUCTURE_MISSED_META_V1011={'loaded_from':path.name,'loaded_ts':time.time()}
        _STRUCTURE_MISSED_LAST_CHECKPOINT_V1011=0.0
        return out,len(out)
    _STRUCTURE_MISSED_CACHE_V1011={}
    _STRUCTURE_MISSED_META_V1011={'loaded_from':'empty','loaded_ts':time.time()}
    _STRUCTURE_MISSED_LAST_CHECKPOINT_V1011=0.0
    return _STRUCTURE_MISSED_CACHE_V1011,0


def _structure_review_interval(rec: Dict[str,Any], nowv: float) -> float:
    if int(rec.get('horizon_mask') or 0)==_STRUCTURE_ALL_HORIZONS_MASK: return 300.0
    age=max(0.0,nowv-(_quality_optional_num(rec.get('trigger_reached_ts'),rec.get('first_seen_ts')) or nowv))
    if age<=600.0: return STRUCTURE_REVIEW_FAST_SEC
    if age<=3600.0: return STRUCTURE_REVIEW_MID_SEC
    return STRUCTURE_REVIEW_SLOW_SEC


def _structure_due_selection(records: Dict[str,Dict[str,Any]], nowv: float) -> tuple[List[str],Dict[str,Any]]:
    due=[]; future=0; recent_due=[]; overdue=0; oldest_overdue=0.0
    for key,rec in records.items():
        due_ts=_quality_optional_num(rec.get('next_review_due_ts'))
        if due_ts is None:
            interval=_structure_review_interval(rec,nowv); due_ts=nowv+(abs(hash(key))%max(1,int(interval))); rec['next_review_due_ts']=due_ts
        if due_ts<=nowv:
            age=max(0.0,nowv-(_quality_optional_num(rec.get('trigger_reached_ts'),rec.get('first_seen_ts')) or nowv))
            item=(float(due_ts),key); due.append(item)
            if age<=600.0: recent_due.append(item)
            lateness=max(0.0,nowv-float(due_ts)); cadence=_quality_optional_num(rec.get('last_review_interval_sec')) or _structure_review_interval(rec,nowv)
            if lateness>cadence:
                overdue+=1; oldest_overdue=max(oldest_overdue,lateness)
        else:
            future+=1
    recent_due.sort(); recent_keys=[k for _d,k in recent_due]; recent_set=set(recent_keys)
    older=sorted((d,k) for d,k in due if k not in recent_set); remaining=max(0,STRUCTURE_REVIEW_UPDATE_BUDGET-len(recent_keys)); selected=recent_keys+[k for _d,k in older[:remaining]]
    return selected,{'due_total':len(due),'recent_due':len(recent_keys),'deferred_due':max(0,len(due)-len(selected)),'scheduled_future':future,'overdue_total':overdue,'oldest_overdue_sec':round(oldest_overdue,3)}


def _structure_plan_stats_v956(records: List[Dict[str,Any]], method: str, summary: Dict[str,Any]) -> Dict[str,Any]:
    rows=[r for r in records if str(r.get('method') or '')==method]; reached=[r for r in rows if r.get('trigger_reached_ts')]
    state_counts=Counter(str(r.get('structure_state') or 'unknown') for r in rows); activation_counts=Counter(str(r.get('trigger_activation_mode') or 'unknown') for r in rows)
    out={'tracked':len(rows),'complete_tracked':sum(1 for r in rows if r.get('source_plan_complete')),'partial_tracked':sum(1 for r in rows if not r.get('source_plan_complete')),'trigger_reached':len(reached),'support_touched':sum(1 for r in rows if r.get('support_touch_count',0)>0),'target_first':sum(1 for r in reached if r.get('first_terminal')=='target'),'invalid_first':sum(1 for r in reached if r.get('first_terminal')=='invalid'),'terminal_unknown':sum(1 for r in reached if r.get('first_terminal') in (None,'','ambiguous')),'weakened_lines':sum(1 for r in rows if r.get('line_weakened')),'role_flip_confirmed':sum(1 for r in rows if r.get('role_flip_confirmed_ts')),'stale_unreached':sum(1 for r in rows if r.get('line_state')=='stale_unreached'),'confirmed_event_started':sum(1 for r in rows if r.get('activation_source')=='confirmed_completed_candle_event_seen_by_review'),'structure_state_counts':dict(state_counts),'activation_mode_counts':dict(activation_counts)}
    method_summary=((summary.get('methods') or {}).get(method) or {}) if isinstance(summary,dict) else {}
    for label,_sec in STRUCTURE_LAB_HORIZONS:
        bucket=method_summary.get(label) if isinstance(method_summary,dict) else None; bucket=bucket if isinstance(bucket,dict) else {}; n=int(bucket.get('n') or 0)
        out[label]={'n':n,'avg_pct':round(float(bucket.get('sum_pct') or 0.0)/n,4) if n else None,'median_pct':None,'avg_max_pct':round(float(bucket.get('sum_max_pct') or 0.0)/n,4) if n else None,'avg_min_pct':round(float(bucket.get('sum_min_pct') or 0.0)/n,4) if n else None,'avg_giveback_pct':round(float(bucket.get('sum_giveback_pct') or 0.0)/n,4) if n else None,'avg_relative_to_btc_pct':round(float(bucket.get('sum_relative_to_btc_pct') or 0.0)/int(bucket.get('relative_n') or 1),4) if int(bucket.get('relative_n') or 0) else None}
    return out

def update_structure_laboratory(nowv: float, fmap: Dict[str,Dict[str,Any]], ofmap: Dict[str,Dict[str,Any]]) -> tuple[Dict[str,Any],Dict[str,Any]]:
    global _STRUCTURE_HORIZON_SUMMARY_CACHE, _STRUCTURE_HORIZON_SUMMARY_LEDGER_SIZE
    global _STRUCTURE_HORIZON_KEYS_CACHE, _STRUCTURE_FINAL_KEYS_CACHE, _STRUCTURE_FINAL_KEY_INDEX_LOADS
    global _STRUCTURE_ACTIVE_CACHE_V1011, _STRUCTURE_MISSED_CACHE_V1011
    global _STRUCTURE_ACTIVE_LAST_CHECKPOINT_V1011, _STRUCTURE_MISSED_LAST_CHECKPOINT_V1011
    global _STRUCTURE_METHOD_STATS_CACHE_V1011, _STRUCTURE_METHOD_STATS_AT_V1011
    started=time.time(); summary,summary_load=_load_structure_horizon_summary()
    horizon_index_memory_reused=_STRUCTURE_HORIZON_KEYS_CACHE is not None
    final_index_memory_reused=_STRUCTURE_FINAL_KEYS_CACHE is not None
    source_raw=load_json(STRUCTURE_LAB_CANDIDATES,{})
    source=source_raw if isinstance(source_raw,dict) else {}
    current_raw=load_json(STRUCTURE_LAB_STRATEGY_STATUS,{})
    current=current_raw if isinstance(current_raw,dict) else {}
    detail_snapshot_key=str(source.get('snapshot_key') or '').strip()
    current_snapshot_key=str(current.get('snapshot_key') or '').strip()
    snapshot_match=bool(detail_snapshot_key and current_snapshot_key and detail_snapshot_key==current_snapshot_key)
    if snapshot_match:
        lab_rows=source.get('rows') if isinstance(source.get('rows'),list) else []
        missed_rows=source.get('missed_rows') if isinstance(source.get('missed_rows'),list) else []
        snapshot_state='MATCHED'
    else:
        lab_rows=[]
        missed_rows=[]
        snapshot_state='WAITING_DETAIL_SYNC' if current else 'WAITING_CURRENT_STATUS'
    try:
        records,migration=_load_structure_state_v956(nowv,summary)
    except Exception:
        _STRUCTURE_HORIZON_KEYS_CACHE=None; _STRUCTURE_FINAL_KEYS_CACHE=None
        _STRUCTURE_HORIZON_SUMMARY_CACHE=None; _STRUCTURE_HORIZON_SUMMARY_LEDGER_SIZE=-1
        raise
    missed,migrated_missed=_load_structure_missed_state_v956()
    new_plans=0; new_missed=0; detail_appended=0; horizon_appended=0; finalized_this_cycle=0; current_found_by_ticker={}; current_complete_by_ticker={}; review_price_fresh_samples=0; review_price_stale_skips=0
    state_dirty=bool(migration.get('migrated_records')); missed_dirty=bool(migrated_missed); summary_dirty=bool(migration.get('migrated_samples')) or bool(summary_load.get('rebuilt_from_ledger'))
    horizon_cycle_rows:List[Dict[str,Any]]=[]; final_cycle_rows:List[Dict[str,Any]]=[]
    btc_state=_structure_review_price_state('BTC',fmap,ofmap,nowv); btc_now=btc_state.get('price') if btc_state.get('fresh') else 0.0
    for lab in lab_rows:
        if not isinstance(lab,dict): continue
        ticker=ticker_norm(lab.get('ticker')); methods=lab.get('methods') if isinstance(lab.get('methods'),dict) else {}
        found_methods=lab.get('found_methods') if isinstance(lab.get('found_methods'),list) else []; complete_methods=lab.get('complete_methods') if isinstance(lab.get('complete_methods'),list) else []
        if ticker:
            current_found_by_ticker[ticker]=set(str(x) for x in found_methods); current_complete_by_ticker[ticker]=set(str(x) for x in complete_methods)
        for method,plan in methods.items():
            if not isinstance(plan,dict) or not plan.get('trackable') or plan.get('signal_state') not in ('new_signal','active_signal_delivery') or not plan.get('structure_found'): continue
            key=str(plan.get('event_key') or '').strip()
            if not key or not ticker: continue
            rec=records.get(key)
            if rec is None:
                event_ts=_quality_optional_num(plan.get('event_source_ts')) or nowv; start_price=_quality_optional_num(plan.get('event_source_price')) or _quality_optional_num(plan.get('current_price')) or _current_price(ticker,fmap,ofmap)
                full={'schema':'structure_lab_event_detail_v956','plan_key':key,'event_key':key,'method':str(method),'method_label':plan.get('method_label'),'ticker':ticker,'candidate_exact_identity':plan.get('candidate_exact_identity'),'first_seen_ts':event_ts,'first_seen_text':now_text(event_ts),'first_price':start_price,'structure_state':plan.get('structure_state'),'signal_state':plan.get('signal_state'),'event_kind':plan.get('event_kind'),'event_lifecycle_state':plan.get('event_lifecycle_state'),'source_plan_complete':bool(plan.get('plan_complete')),'component_status':plan.get('component_status'),'discovery_reasons':plan.get('discovery_reasons'),'incomplete_reasons':plan.get('incomplete_reasons'),'trigger_activation_mode':plan.get('trigger_activation_mode'),'trigger_source_state':plan.get('trigger_source_state'),'trigger':plan.get('trigger'),'invalid':plan.get('invalid'),'target':plan.get('target'),'support_zone':plan.get('support_zone'),'trigger_zone':plan.get('trigger_zone'),'target_zone':plan.get('target_zone'),'anchor_zone':plan.get('anchor_zone'),'primary_tf':plan.get('primary_tf'),'evidence':plan.get('evidence'),'method_contract_version':plan.get('method_contract_version'),'market_context':plan.get('market_context'),'execution_snapshot':plan.get('execution_snapshot'),'tick_pct':plan.get('tick_pct'),'low_price_tick_risk':plan.get('low_price_tick_risk'),'source_event_ts':event_ts,'source_event_price':start_price,'source_to_review_lag_sec':round(max(0.0,nowv-event_ts),3),'line_state':'fresh_completed_candle_signal','support_touch_count':0,'trigger_retest_count':0,'max_pct':0.0,'min_pct':0.0,'giveback_pct':0.0,'btc_start_price':btc_now or None,'observation_only':True,'trigger_reached_ts':event_ts,'entry_price':start_price,'activation_source':'strategy_exact_completed_candle_event','source_current_state_fresh':bool(plan.get('current_state_fresh')),'source_map_refresh_pending':bool(plan.get('map_refresh_pending')),'source_priority_lane':plan.get('priority_lane'),'next_review_due_ts':nowv,'horizon_mask':0}
                if _append_structure_detail_once(full): detail_appended+=1
                rec=_structure_active_record(full); new_plans+=1; state_dirty=True
            source_values={
                'candidate_exact_identity_last':plan.get('candidate_exact_identity'),
                'source_plan_complete':bool(plan.get('plan_complete')),
                'structure_state':plan.get('structure_state'),
                'source_current_state_fresh':bool(plan.get('current_state_fresh')),
                'source_map_refresh_pending':bool(plan.get('map_refresh_pending')),
                'source_priority_lane':plan.get('priority_lane'),
                'last_source_snapshot_key_v1011':detail_snapshot_key,
            }
            source_changed=any(rec.get(field)!=value for field,value in source_values.items())
            if source_changed:
                rec.update(source_values); rec['last_source_seen_ts']=nowv; state_dirty=True
            records[key]=rec

    selected_keys,due_meta=_structure_due_selection(records,nowv); recent_processed=0; finalize_keys=[]
    for key in selected_keys:
        rec=records.get(key)
        if not isinstance(rec,dict): continue
        age0=max(0.0,nowv-(_quality_optional_num(rec.get('trigger_reached_ts'),rec.get('first_seen_ts')) or nowv))
        if age0<=600: recent_processed+=1
        ticker=ticker_norm(rec.get('ticker')); price_state=_structure_review_price_state(ticker,fmap,ofmap,nowv); rec['review_price_source']=price_state.get('source'); rec['review_price_age_sec']=price_state.get('age_sec')
        if not price_state.get('fresh'):
            rec['line_state']='stale_price_wait'; rec['review_price_stale_skip_count']=int(rec.get('review_price_stale_skip_count') or 0)+1; review_price_stale_skips+=1
            interval=_structure_review_interval(rec,nowv); rec['next_review_due_ts']=nowv+interval; rec['last_review_interval_sec']=interval; rec['last_review_update_ts']=nowv; rec['review_update_count']=int(rec.get('review_update_count') or 0)+1; records[key]=rec; state_dirty=True; continue
        cur=float(price_state.get('price') or 0.0); review_price_fresh_samples+=1
        if cur<=0: continue
        age=max(0.0,nowv-float(rec.get('first_seen_ts') or nowv)); rec['line_age_sec']=round(age,1)
        tf=str(rec.get('primary_tf') or 'm1'); stale_limit={'h4':14400.0,'h2':10800.0,'h1':7200.0,'m30':5400.0,'m15':3600.0,'m5':2400.0,'m3':1800.0,'m1':1200.0}.get(tf,1800.0)
        if not rec.get('trigger_reached_ts') and age>=stale_limit: rec['line_state']='stale_unreached'
        sl,sh=_structure_zone_bounds(rec.get('support_zone')); zone_eps=max(1e-12,max(abs(sl or 0.0),abs(sh or 0.0),abs(cur))*1e-12)
        if sl is not None and sh is not None and sl-zone_eps<=cur<=sh+zone_eps:
            last=_quality_optional_num(rec.get('last_support_touch_ts')) or 0.0
            if nowv-last>=30.0:
                rec['support_touch_count']=int(rec.get('support_touch_count') or 0)+1; rec['last_support_touch_ts']=nowv; rec['line_state']='support_touched'
                if rec['support_touch_count']>=3: rec['line_weakened']=True; rec['weakening_reason']='support_zone_reused_three_or_more_times'; rec['line_state']='weakened_multi_touch'
        trigger=_quality_optional_num(rec.get('trigger')) or 0.0; mode=str(rec.get('trigger_activation_mode') or ''); can_activate=False
        if mode=='swing_resistance_breakout': can_activate=trigger>0 and cur>=trigger
        elif mode in ('support_recovery_after_touch','demand_recovery_after_touch','volume_node_reclaim_after_touch'): can_activate=bool(rec.get('support_touch_count',0)>0 and trigger>0 and cur>=trigger)
        elif mode=='confirmed_break_retest_event': can_activate=bool(rec.get('trigger_reached_ts'))
        if not rec.get('trigger_reached_ts') and can_activate:
            rec['trigger_reached_ts']=nowv; rec['entry_price']=cur; rec['line_state']='trigger_reached'; rec['activation_source']='live_review_condition'; rec['max_pct']=0.0; rec['min_pct']=0.0; rec['giveback_pct']=0.0
        if rec.get('trigger_reached_ts') and (_quality_optional_num(rec.get('entry_price')) or 0)>0:
            tl,th=_structure_zone_bounds(rec.get('trigger_zone'))
            if tl is not None and th is not None and tl<=cur<=th and nowv-float(rec.get('trigger_reached_ts') or nowv)>=30.0:
                last=_quality_optional_num(rec.get('last_trigger_retest_ts')) or 0.0
                if nowv-last>=30.0:
                    rec['trigger_retest_count']=int(rec.get('trigger_retest_count') or 0)+1; rec['last_trigger_retest_ts']=nowv
                    if mode=='swing_resistance_breakout': rec['role_flip_confirmed_ts']=nowv; rec['line_state']='resistance_to_support_confirmed'
            base=float(rec['entry_price']); pctv=(cur-base)/base*100.0; rec['current_price']=cur; rec['current_pct']=round(pctv,6); rec['max_pct']=max(_quality_optional_num(rec.get('max_pct')) or pctv,pctv); rec['min_pct']=min(_quality_optional_num(rec.get('min_pct')) or pctv,pctv); rec['giveback_pct']=round(float(rec['max_pct'])-pctv,6)
            inv=_quality_optional_num(rec.get('invalid')); tgt=_quality_optional_num(rec.get('target')); terminal=[]
            if inv and cur<=inv:
                if not rec.get('invalid_ts'): rec['invalid_ts']=nowv
                terminal.append('invalid')
            if tgt and cur>=tgt:
                if not rec.get('target_ts'): rec['target_ts']=nowv
                terminal.append('target')
            if not rec.get('first_terminal'):
                if len(terminal)==1: rec['first_terminal']=terminal[0]; rec['line_state']=terminal[0]+'_first'
                elif len(terminal)>1: rec['first_terminal']='ambiguous'; rec['line_state']='terminal_order_unknown'
            elapsed=max(0.0,nowv-float(rec['trigger_reached_ts'])); btc_start=_quality_optional_num(rec.get('btc_start_price')); btc_ret=(btc_now-btc_start)/btc_start*100.0 if btc_start and btc_now else None
            for label,sec in STRUCTURE_LAB_HORIZONS:
                if elapsed<sec or int(rec.get('horizon_mask') or 0)&_STRUCTURE_HORIZON_BITS[label]: continue
                sample={'ts':nowv,'pct':rec['current_pct'],'max_pct':rec['max_pct'],'min_pct':rec['min_pct'],'giveback_pct':rec['giveback_pct'],'btc_pct':round(btc_ret,6) if btc_ret is not None else None,'relative_to_btc_pct':round(rec['current_pct']-btc_ret,6) if btc_ret is not None else None,'sample_lag_sec':round(max(0.0,elapsed-sec),3)}
                if _append_structure_horizon_once(rec,label,sample,summary,batch_rows=horizon_cycle_rows): horizon_appended+=1; summary_dirty=True
        interval=_structure_review_interval(rec,nowv); rec['next_review_due_ts']=nowv+interval; rec['last_review_interval_sec']=interval; rec['last_review_update_ts']=nowv; rec['review_update_count']=int(rec.get('review_update_count') or 0)+1; records[key]=rec; state_dirty=True
        if int(rec.get('horizon_mask') or 0)==_STRUCTURE_ALL_HORIZONS_MASK:
            if _append_structure_final_once(rec,nowv,batch_rows=final_cycle_rows): finalized_this_cycle+=1
            finalize_keys.append(key)
    try:
        horizon_batch_written=_append_jsonl_batch_fsync(STRUCTURE_LAB_HORIZON_LEDGER,horizon_cycle_rows)
    except Exception:
        _STRUCTURE_HORIZON_KEYS_CACHE=None
        _STRUCTURE_HORIZON_SUMMARY_CACHE=None; _STRUCTURE_HORIZON_SUMMARY_LEDGER_SIZE=-1
        raise
    try:
        final_batch_written=_append_jsonl_batch_fsync(STRUCTURE_LAB_FINAL_LEDGER,final_cycle_rows)
    except Exception:
        _STRUCTURE_FINAL_KEYS_CACHE=None
        raise
    for key in finalize_keys: records.pop(key,None)
    if finalize_keys: state_dirty=True

    current_missed_keys=set()
    for item in missed_rows:
        if not isinstance(item,dict): continue
        key=str(item.get('miss_key') or '').strip(); ticker=ticker_norm(item.get('ticker'))
        if not key or not ticker: continue
        current_missed_keys.add(key)
        rec=missed.get(key)
        if rec is None:
            first=_quality_optional_num(item.get('first_price')) or _current_price(ticker,fmap,ofmap)
            rec={'schema':'structure_missed_state_row_v1011','miss_key':key,'ticker':ticker,'source':item.get('source'),'reason':item.get('reason'),'method_diagnostics':item.get('method_diagnostics'),'found_methods':item.get('found_methods'),'candidate_exact_identity':item.get('candidate_exact_identity'),'structure_occurrence_key':item.get('structure_occurrence_key'),'scanner_occurrence':item.get('scanner_occurrence'),'first_seen_ts':_quality_optional_num(item.get('first_seen_ts')) or nowv,'first_price':first,'samples':{},'max_pct':0.0,'min_pct':0.0,'btc_start_price':btc_now or None,'observation_only':True,'next_review_due_ts_v1011':nowv}
            new_missed+=1; missed_dirty=True
        identity=item.get('candidate_exact_identity')
        if rec.get('candidate_exact_identity_last')!=identity or rec.get('last_source_snapshot_key_v1011')!=detail_snapshot_key:
            rec['candidate_exact_identity_last']=identity; rec['last_source_snapshot_key_v1011']=detail_snapshot_key; rec['last_source_seen_ts']=nowv; missed_dirty=True
        missed[key]=rec

    missed_due=sorted(
        ((float(_quality_optional_num(rec.get('next_review_due_ts_v1011')) or 0.0),key)
         for key,rec in missed.items()
         if (_quality_optional_num(rec.get('next_review_due_ts_v1011')) or 0.0)<=nowv),
        key=lambda item:item[0]
    )
    missed_selected_keys=[key for _due,key in missed_due[:STRUCTURE_MISSED_UPDATE_BUDGET]]
    for key in missed_selected_keys:
        rec=missed.get(key)
        if not isinstance(rec,dict): continue
        ticker=ticker_norm(rec.get('ticker')); price_state=_structure_review_price_state(ticker,fmap,ofmap,nowv); base=_quality_optional_num(rec.get('first_price')) or 0.0
        elapsed=max(0.0,nowv-float(rec.get('first_seen_ts') or nowv))
        if not price_state.get('fresh'):
            rec['review_price_stale_skip_count']=int(rec.get('review_price_stale_skip_count') or 0)+1; review_price_stale_skips+=1
            rec['next_review_due_ts_v1011']=nowv+(30.0 if elapsed<=600.0 else (60.0 if elapsed<=3600.0 else 180.0)); missed[key]=rec; missed_dirty=True; continue
        cur=float(price_state.get('price') or 0.0); review_price_fresh_samples+=1
        if cur>0 and base>0:
            pctv=(cur-base)/base*100.0; rec['current_price']=cur; rec['current_pct']=round(pctv,6); rec['max_pct']=max(_quality_optional_num(rec.get('max_pct')) or pctv,pctv); rec['min_pct']=min(_quality_optional_num(rec.get('min_pct')) or pctv,pctv)
            samples=rec.get('samples') if isinstance(rec.get('samples'),dict) else {}
            for label,sec in STRUCTURE_LAB_HORIZONS:
                if elapsed>=sec and label not in samples: samples[label]={'ts':nowv,'pct':rec['current_pct'],'max_pct':rec['max_pct'],'min_pct':rec['min_pct']}
            rec['samples']=samples
        if current_found_by_ticker.get(ticker) and not rec.get('later_structure_created_ts'):
            rec['later_structure_created_ts']=nowv; rec['later_found_methods']=sorted(current_found_by_ticker[ticker])
        if current_complete_by_ticker.get(ticker) and not rec.get('later_complete_plan_created_ts'):
            rec['later_complete_plan_created_ts']=nowv; rec['later_complete_methods']=sorted(current_complete_by_ticker[ticker])
        rec['next_review_due_ts_v1011']=nowv+(30.0 if elapsed<=600.0 else (60.0 if elapsed<=3600.0 else 180.0))
        missed[key]=rec; missed_dirty=True

    records_before=len(records); missed_before=len(missed)
    records={k:v for k,v in records.items() if nowv-(_quality_optional_num(v.get('first_seen_ts')) or nowv)<=STRUCTURE_LAB_RETENTION_SEC}
    missed={k:v for k,v in missed.items() if nowv-(_quality_optional_num(v.get('first_seen_ts')) or nowv)<=STRUCTURE_LAB_RETENTION_SEC}
    if len(records)!=records_before: state_dirty=True
    if len(missed)!=missed_before: missed_dirty=True
    _STRUCTURE_ACTIVE_CACHE_V1011=records; _STRUCTURE_MISSED_CACHE_V1011=missed
    vals=list(records.values()); miss_vals=list(missed.values())
    method_stats_due=bool(not _STRUCTURE_METHOD_STATS_CACHE_V1011 or state_dirty or summary_dirty or nowv-_STRUCTURE_METHOD_STATS_AT_V1011>=STRUCTURE_METHOD_STATS_SEC)
    if method_stats_due:
        _STRUCTURE_METHOD_STATS_CACHE_V1011={m:_structure_plan_stats_v956(vals,m,summary) for m in ('A_SWING','B_REACTION_ZONE','C_BREAK_RETEST','D_SUPPLY_DEMAND','E_VOLUME_PROFILE')}
        _STRUCTURE_METHOD_STATS_AT_V1011=nowv
    method_stats=_STRUCTURE_METHOD_STATS_CACHE_V1011
    active_write=False; missed_write=False
    active_checkpoint_due=bool(not STRUCTURE_LAB_ACTIVE_STATE.exists() or _STRUCTURE_ACTIVE_LAST_CHECKPOINT_V1011<=0 or nowv-_STRUCTURE_ACTIVE_LAST_CHECKPOINT_V1011>=STRUCTURE_STATE_CHECKPOINT_SEC)
    missed_checkpoint_due=bool(not STRUCTURE_MISSED_STATE.exists() or _STRUCTURE_MISSED_LAST_CHECKPOINT_V1011<=0 or nowv-_STRUCTURE_MISSED_LAST_CHECKPOINT_V1011>=STRUCTURE_STATE_CHECKPOINT_SEC)
    if active_checkpoint_due:
        save_json(STRUCTURE_LAB_ACTIVE_STATE,{'schema':'structure_lab_active_state_v1011_semantic_incremental','version':VERSION,'updated_ts':nowv,'records':records,'static_detail_ledgers':[STRUCTURE_LAB_EVENT_DETAIL_LEDGER_LEGACY.name,STRUCTURE_LAB_EVENT_DETAIL_LEDGER.name],'horizon_ledger':STRUCTURE_LAB_HORIZON_LEDGER.name,'final_ledger':STRUCTURE_LAB_FINAL_LEDGER.name})
        _STRUCTURE_ACTIVE_LAST_CHECKPOINT_V1011=nowv; active_write=True
    if missed_checkpoint_due:
        save_json(STRUCTURE_MISSED_STATE,{'schema':'structure_missed_state_v1011_semantic_incremental','version':VERSION,'updated_ts':nowv,'records':missed})
        _STRUCTURE_MISSED_LAST_CHECKPOINT_V1011=nowv; missed_write=True
    summary_write=False
    current_horizon_size=STRUCTURE_LAB_HORIZON_LEDGER.stat().st_size if STRUCTURE_LAB_HORIZON_LEDGER.exists() else 0
    if summary_dirty or not STRUCTURE_LAB_HORIZON_SUMMARY.exists() or int(summary.get('ledger_size_bytes') or 0)!=current_horizon_size:
        summary['updated_ts']=nowv; summary['ledger_size_bytes']=current_horizon_size; save_json(STRUCTURE_LAB_HORIZON_SUMMARY,summary); summary_write=True
    _STRUCTURE_HORIZON_SUMMARY_CACHE=summary; _STRUCTURE_HORIZON_SUMMARY_LEDGER_SIZE=current_horizon_size
    active_bytes=STRUCTURE_LAB_ACTIVE_STATE.stat().st_size if STRUCTURE_LAB_ACTIVE_STATE.exists() else 0; horizon_bytes=STRUCTURE_LAB_HORIZON_LEDGER.stat().st_size if STRUCTURE_LAB_HORIZON_LEDGER.exists() else 0; final_bytes=STRUCTURE_LAB_FINAL_LEDGER.stat().st_size if STRUCTURE_LAB_FINAL_LEDGER.exists() else 0
    status={'schema':'structure_lab_review_status_v960','version':VERSION,'build':'performance_cost_exact_identity_v961_2026-06-21','state':'ACTIVE' if vals else ('WAITING_FRESH_SIGNAL' if lab_rows else 'WAITING_SOURCE'),'updated_ts':nowv,'updated_text':now_text(nowv),'source_candidate_rows':len(lab_rows),'source_candidate_unique_tickers':current.get('candidate_unique_tickers') if isinstance(current,dict) else 0,'source_total_candidate_rows':current.get('candidate_rows',0) if isinstance(current,dict) else 0,'source_analysis_ready_rows':current.get('analysis_ready_rows',0) if isinstance(current,dict) else 0,'source_partial_rows':current.get('source_partial_rows',0) if isinstance(current,dict) else 0,'source_not_ready_rows':current.get('source_not_ready_rows_count',0) if isinstance(current,dict) else 0,'source_frame_ready_counts':current.get('source_frame_ready_counts',{}) if isinstance(current,dict) else {},'source_snapshot_state':snapshot_state,'source_snapshot_match':snapshot_match,'source_snapshot_key':current_snapshot_key,'detail_snapshot_key':detail_snapshot_key,'detail_rows_processed':len(lab_rows),'tracked_structures':len(vals),'completed_events_total':_dedup_count_v1013('structure_final'),'finalized_this_cycle':finalized_this_cycle,'new_structures_this_cycle':new_plans,'review_price_fresh_samples':review_price_fresh_samples,'review_price_stale_skips':review_price_stale_skips,'review_price_ttl_sec':STRUCTURE_REVIEW_PRICE_TTL_SEC,'review_update_budget':STRUCTURE_REVIEW_UPDATE_BUDGET,'review_due_processed':len(selected_keys),'review_recent_fast_processed':recent_processed,'review_due_total':due_meta.get('due_total',0),'review_deferred_due':due_meta.get('deferred_due',0),'review_scheduled_future':due_meta.get('scheduled_future',0),'review_overdue_total':due_meta.get('overdue_total',0),'review_oldest_overdue_sec':due_meta.get('oldest_overdue_sec',0.0),'legacy_state_migrated_records':migration.get('migrated_records',0),'legacy_horizon_samples_migrated':migration.get('migrated_samples',0),'legacy_finalized_on_migration':migration.get('finalized_on_migration',0),'migration_horizon_batch_rows':migration.get('migration_horizon_batch_rows',0),'migration_final_batch_rows':migration.get('migration_final_batch_rows',0),'missed_migrated':migrated_missed,'detail_ledger_appended_this_cycle':detail_appended,'horizon_appended_this_cycle':horizon_appended,'horizon_batch_rows_this_cycle':horizon_batch_written,'horizon_fsync_count_this_cycle':1 if horizon_batch_written else 0,'final_batch_rows_this_cycle':final_batch_written,'final_fsync_count_this_cycle':1 if final_batch_written else 0,'horizon_summary_memory_reused':bool(summary_load.get('memory_reused')),'horizon_summary_disk_reused':bool(summary_load.get('disk_summary_reused')),'horizon_summary_rebuilt_this_cycle':bool(summary_load.get('rebuilt_from_ledger')),'horizon_summary_write_this_cycle':summary_write,'horizon_summary_full_scans_process':_STRUCTURE_HORIZON_SUMMARY_FULL_SCANS,'horizon_summary_memory_hits_process':_STRUCTURE_HORIZON_SUMMARY_MEMORY_HITS,'horizon_key_index_memory_reused':horizon_index_memory_reused,'final_key_index_memory_reused':final_index_memory_reused,'horizon_key_index_loads_process':_STRUCTURE_HORIZON_KEY_INDEX_LOADS,'final_key_index_loads_process':_STRUCTURE_FINAL_KEY_INDEX_LOADS,'horizon_key_index_size':_dedup_count_v1013('structure_horizon'),'final_key_index_size':_dedup_count_v1013('structure_final'),'active_state_bytes':active_bytes,'horizon_ledger_bytes':horizon_bytes,'horizon_result_rows':int(summary.get('total_rows') or 0),'final_ledger_bytes':final_bytes,'active_state_write_this_cycle':active_write,'missed_state_write_this_cycle_v1011':missed_write,
    'active_state_semantic_dirty_v1011':state_dirty,'missed_state_semantic_dirty_v1011':missed_dirty,
    'active_checkpoint_due_v1011':active_checkpoint_due,'missed_checkpoint_due_v1011':missed_checkpoint_due,
    'state_checkpoint_interval_sec_v1011':STRUCTURE_STATE_CHECKPOINT_SEC,
    'active_memory_cache_reused_v1011':bool(migration.get('memory_reused')),'method_stats_recomputed_v1011':method_stats_due,
    'missed_due_total_v1011':len(missed_due),'missed_due_processed_v1011':len(missed_selected_keys),'missed_due_deferred_v1011':max(0,len(missed_due)-len(missed_selected_keys)),'review_cycle_sec':round(time.time()-started,3),'btc_price_fresh':bool(btc_state.get('fresh')),'method_stats':method_stats,'source_method_found_counts':current.get('method_found_counts') if isinstance(current,dict) else {},'source_method_complete_counts':current.get('method_complete_counts') if isinstance(current,dict) else {},'source_method_partial_counts':current.get('method_partial_counts') if isinstance(current,dict) else {},'source_method_no_structure_counts':current.get('method_no_structure_counts') if isinstance(current,dict) else {},'source_method_component_counts':current.get('method_component_counts') if isinstance(current,dict) else {},'source_method_signal_state_counts':current.get('method_signal_state_counts') if isinstance(current,dict) else {},'source_event_scan_same_frame_skipped':int(current.get('event_scan_same_frame_skipped') or 0) if isinstance(current,dict) else 0,'source_event_scan_executed':int(current.get('event_scan_executed') or 0) if isinstance(current,dict) else 0,'source_fresh_signal_count':int(current.get('fresh_signal_count') or 0) if isinstance(current,dict) else 0,'source_active_signal_delivery_count':int(current.get('active_signal_delivery_count') or 0) if isinstance(current,dict) else 0,'source_historical_baseline_event_count':int(current.get('historical_baseline_event_count') or 0) if isinstance(current,dict) else 0,'source_waiting_new_event_count':int(current.get('waiting_new_event_count') or 0) if isinstance(current,dict) else 0,'source_invalid_or_completed_event_count':int(current.get('invalid_or_completed_event_count') or 0) if isinstance(current,dict) else 0,'source_age_sec':round(max(0.0,nowv-(_quality_optional_num(current.get('updated_ts')) or nowv)),3) if isinstance(current,dict) else None,'source_broad_scan_unique_tickers':int(current.get('broad_scan_unique_tickers') or 0) if isinstance(current,dict) else 0,'source_priority_lane_counts':current.get('priority_lane_counts',{}) if isinstance(current,dict) else {},'source_reused_historical_map':int(current.get('reused_historical_map') or 0) if isinstance(current,dict) else 0,'source_recomputed_this_cycle':int(current.get('recomputed_this_cycle') or 0) if isinstance(current,dict) else 0,'source_map_refresh_pending_count':int(current.get('map_refresh_pending_count') or 0) if isinstance(current,dict) else 0,'source_live_state_fresh_count':int(current.get('live_state_fresh_count') or 0) if isinstance(current,dict) else 0,'source_live_state_stale_count':int(current.get('live_state_stale_count') or 0) if isinstance(current,dict) else 0,'source_map_source_fresh_count':int(current.get('map_source_fresh_count') or 0) if isinstance(current,dict) else 0,'source_map_source_stale_count':int(current.get('map_source_stale_count') or 0) if isinstance(current,dict) else 0,'source_refresh_request_count':int(current.get('refresh_request_count') or 0) if isinstance(current,dict) else 0,'source_stale_current_state_wait_count':int(current.get('stale_current_state_wait_count') or 0) if isinstance(current,dict) else 0,'source_stale_event_source_wait_count':int(current.get('stale_event_source_wait_count') or 0) if isinstance(current,dict) else 0,'discovery_reason_top':current.get('discovery_reason_top') if isinstance(current,dict) else [],'incomplete_reason_top':current.get('incomplete_reason_top') if isinstance(current,dict) else [],'completed_candles_only':True,'forming_candle_excluded':True,'policy':'static detail append-once; each horizon append-once; live state stores dynamic fields only; full 1440m completion moves to final ledger and leaves active state; due/overdue/scheduled are separately measured; stale prices are skipped','trading_rules_changed':False}
    missed_status={'schema':'structure_missed_status_v960','version':VERSION,'build':'performance_cost_exact_identity_v961_2026-06-21','state':'ACTIVE' if miss_vals else ('WAITING_DETAIL_SYNC' if current else 'WAITING_CURRENT_STATUS'),'updated_ts':nowv,'updated_text':now_text(nowv),'new_missed_this_cycle':new_missed,'current_snapshot_state':snapshot_state,'current_snapshot_match':snapshot_match,'current_snapshot_key':current_snapshot_key,'detail_snapshot_key':detail_snapshot_key,'detail_rows_processed':len(lab_rows),'source_not_ready_excluded':int(current.get('source_not_ready_rows_count') or 0) if isinstance(current,dict) else 0,'source_analysis_ready_rows':int(current.get('analysis_ready_rows') or 0) if isinstance(current,dict) else 0,'source_all_methods_no_structure':int(current.get('all_methods_no_structure_count') or 0) if isinstance(current,dict) else 0,'source_structure_found_no_complete':int(current.get('structure_found_no_complete_count') or 0) if isinstance(current,dict) else 0,'source_scanner_not_candidate':int(current.get('scanner_seen_not_candidate_count') or 0) if isinstance(current,dict) else 0,'source_scanner_not_candidate_unique':int(current.get('scanner_seen_not_candidate_unique_tickers') or 0) if isinstance(current,dict) else 0,'source_scanner_pool_not_candidate':int(current.get('scanner_pool_not_candidate_count') or 0) if isinstance(current,dict) else 0,'source_scanner_pool_not_candidate_unique':int(current.get('scanner_pool_not_candidate_unique_tickers') or 0) if isinstance(current,dict) else 0,'market_counts':{'candidate_rows':current.get('candidate_rows',0),'candidate_unique_tickers':current.get('candidate_unique_tickers',0),'scanner_hot_rows':current.get('scanner_hot_rows',0),'scanner_hot_unique_tickers':current.get('scanner_hot_unique_tickers',0),'scanner_pool_rows':current.get('scanner_pool_rows',0),'scanner_pool_unique_tickers':current.get('scanner_pool_unique_tickers',0)},'stats':_structure_missed_stats(miss_vals),'samples':sorted(miss_vals,key=lambda r:_quality_optional_num(r.get('max_pct')) or -999,reverse=True)[:12],'missed_state_write_this_cycle_v1011':missed_write,'missed_due_total_v1011':len(missed_due),'missed_due_processed_v1011':len(missed_selected_keys),'missed_due_deferred_v1011':max(0,len(missed_due)-len(missed_selected_keys)),'policy':'current market counts come only from strategy compact status; missed detail rows are consumed only when both files share the exact snapshot key; old missed records stay preserved','trading_rules_changed':False}
    save_json(STRUCTURE_LAB_REVIEW_STATUS,status); save_json(STRUCTURE_MISSED_STATUS,missed_status)
    return status,missed_status



def _performance_empty_structure_index() -> Dict[str, Any]:
    return {
        'schema':'performance_structure_index_v959','ledger_size_bytes':0,'ledger_rows':0,
        'methods':{},'updated_ts':0.0,
    }


def _performance_bucket(index: Dict[str, Any], method: str, horizon: str) -> Dict[str, Any]:
    methods=index.setdefault('methods',{})
    method_obj=methods.setdefault(method,{})
    return method_obj.setdefault(horizon,{
        'n':0,'sum_pct':0.0,'values':[],'clean_n':0,'clean_sum_pct':0.0,
        'max_n':0,'sum_max_pct':0.0,'min_n':0,'sum_min_pct':0.0,
        'giveback_n':0,'sum_giveback_pct':0.0,'relative_n':0,'sum_relative_pct':0.0,
        'distortion_count':0,'ticker_stats':{},'terminal_counts':{},
    })


def _performance_tick_pct(price: Optional[float]) -> float:
    if price is None or price <= 0: return 0.0
    return _sample_price_unit(float(price))/float(price)*100.0


def _performance_add_structure_row(index: Dict[str, Any], row: Dict[str, Any]) -> bool:
    method=str(row.get('method') or '').strip(); horizon=str(row.get('horizon') or '').strip()
    if method not in PERFORMANCE_STRUCTURE_METHODS or horizon not in PERFORMANCE_STRUCTURE_HORIZONS:
        return False
    pct=_quality_optional_num(row.get('pct'))
    if pct is None: return False
    bucket=_performance_bucket(index,method,horizon)
    bucket['n']=int(bucket.get('n') or 0)+1
    bucket['sum_pct']=float(bucket.get('sum_pct') or 0.0)+pct
    values=bucket.get('values') if isinstance(bucket.get('values'),list) else []
    values.append(round(pct,6)); bucket['values']=values
    price=_quality_optional_num(row.get('entry_price'))
    distortion=bool(_performance_tick_pct(price)>=0.50 or abs(pct)>=15.0)
    if distortion:
        bucket['distortion_count']=int(bucket.get('distortion_count') or 0)+1
    else:
        bucket['clean_n']=int(bucket.get('clean_n') or 0)+1
        bucket['clean_sum_pct']=float(bucket.get('clean_sum_pct') or 0.0)+pct
    for field,nkey,skey in (
        ('max_pct','max_n','sum_max_pct'),('min_pct','min_n','sum_min_pct'),
        ('giveback_pct','giveback_n','sum_giveback_pct'),('relative_to_btc_pct','relative_n','sum_relative_pct')):
        value=_quality_optional_num(row.get(field))
        if value is not None:
            bucket[nkey]=int(bucket.get(nkey) or 0)+1
            bucket[skey]=float(bucket.get(skey) or 0.0)+value
    ticker=ticker_norm(row.get('ticker'))
    if ticker:
        ticker_stats=bucket.get('ticker_stats') if isinstance(bucket.get('ticker_stats'),dict) else {}
        pair=ticker_stats.get(ticker) if isinstance(ticker_stats.get(ticker),list) else [0.0,0]
        pair=[float(pair[0])+pct,int(pair[1])+1]; ticker_stats[ticker]=pair; bucket['ticker_stats']=ticker_stats
    terminal=str(row.get('first_terminal') or 'unknown')
    terminal_counts=bucket.get('terminal_counts') if isinstance(bucket.get('terminal_counts'),dict) else {}
    terminal_counts[terminal]=int(terminal_counts.get(terminal) or 0)+1; bucket['terminal_counts']=terminal_counts
    index['ledger_rows']=int(index.get('ledger_rows') or 0)+1
    return True


def _performance_refresh_structure_index(nowv: float) -> tuple[Dict[str, Any],Dict[str, Any]]:
    global _PERFORMANCE_STRUCTURE_INDEX_MEM_V1079
    current_size=STRUCTURE_LAB_HORIZON_LEDGER.stat().st_size if STRUCTURE_LAB_HORIZON_LEDGER.exists() else 0
    memory_reused=isinstance(_PERFORMANCE_STRUCTURE_INDEX_MEM_V1079,dict) and _PERFORMANCE_STRUCTURE_INDEX_MEM_V1079.get('schema')=='performance_structure_index_v959'
    if memory_reused:
        saved=_PERFORMANCE_STRUCTURE_INDEX_MEM_V1079
        _PERFORMANCE_INDEX_MEMORY_STATS_V1079['structure_memory_hits']+=1
    else:
        saved=load_json(PERFORMANCE_STRUCTURE_INDEX,{}) or {}
        _PERFORMANCE_INDEX_MEMORY_STATS_V1079['structure_disk_loads']+=1
    valid=isinstance(saved,dict) and saved.get('schema')=='performance_structure_index_v959'
    old_size=int(saved.get('ledger_size_bytes') or 0) if valid else 0
    rebuild=(not valid) or old_size<0 or old_size>current_size
    index=_performance_empty_structure_index() if rebuild else saved
    start=0 if rebuild else old_size
    rows_read=0
    if current_size>start:
        with STRUCTURE_LAB_HORIZON_LEDGER.open('rb') as handle:
            handle.seek(start)
            data=handle.read()
        # Writer commits complete newline-terminated batches. Ignore a partial tail defensively.
        complete=data.rsplit(b'\n',1)[0] if data and not data.endswith(b'\n') else data
        for raw in complete.splitlines():
            if not raw.strip(): continue
            try: row=json.loads(raw.decode('utf-8','ignore'))
            except Exception: continue
            if isinstance(row,dict) and _performance_add_structure_row(index,row): rows_read+=1
    index_write=bool(rebuild or rows_read or not PERFORMANCE_STRUCTURE_INDEX.exists())
    index['ledger_size_bytes']=current_size
    if index_write:
        index['updated_ts']=nowv
        save_json(PERFORMANCE_STRUCTURE_INDEX,index)
    _PERFORMANCE_STRUCTURE_INDEX_MEM_V1079=index
    return index,{
        'rebuilt':rebuild,'incremental_rows':rows_read,'ledger_size_bytes':current_size,
        'ledger_rows':int(index.get('ledger_rows') or 0),'start_offset':start,'index_write_this_cycle':index_write,
        'memory_reused_v1079':memory_reused,'disk_loads_v1079':_PERFORMANCE_INDEX_MEMORY_STATS_V1079['structure_disk_loads'],
        'memory_hits_v1079':_PERFORMANCE_INDEX_MEMORY_STATS_V1079['structure_memory_hits'],
    }

def _performance_structure_stats(index: Dict[str, Any]) -> Dict[str, Any]:
    out={}
    methods=index.get('methods') if isinstance(index.get('methods'),dict) else {}
    for method in PERFORMANCE_STRUCTURE_METHODS:
        method_out={}
        raw_method=methods.get(method) if isinstance(methods.get(method),dict) else {}
        for horizon in PERFORMANCE_STRUCTURE_HORIZONS:
            bucket=raw_method.get(horizon) if isinstance(raw_method.get(horizon),dict) else {}
            n=int(bucket.get('n') or 0)
            if not n: continue
            values=[float(x) for x in (bucket.get('values') or []) if isinstance(x,(int,float))]
            ticker_stats=bucket.get('ticker_stats') if isinstance(bucket.get('ticker_stats'),dict) else {}
            ticker_avgs=[float(v[0])/int(v[1]) for v in ticker_stats.values() if isinstance(v,list) and len(v)>=2 and int(v[1])>0]
            def avg(sum_key: str,n_key: str) -> Optional[float]:
                count=int(bucket.get(n_key) or 0)
                return round(float(bucket.get(sum_key) or 0.0)/count,4) if count else None
            clean_n=int(bucket.get('clean_n') or 0)
            method_out[horizon]={
                'n':n,'avg_pct':round(float(bucket.get('sum_pct') or 0.0)/n,4),
                'median_pct':round(_quality_percentile(values,0.50),4) if values else None,
                'p10_pct':round(_quality_percentile(values,0.10),4) if values else None,
                'p90_pct':round(_quality_percentile(values,0.90),4) if values else None,
                'clean_n':clean_n,'clean_avg_pct':round(float(bucket.get('clean_sum_pct') or 0.0)/clean_n,4) if clean_n else None,
                'unique_tickers':len(ticker_stats),'unique_ticker_avg_pct':round(sum(ticker_avgs)/len(ticker_avgs),4) if ticker_avgs else None,
                'avg_max_pct':avg('sum_max_pct','max_n'),'avg_min_pct':avg('sum_min_pct','min_n'),
                'avg_giveback_pct':avg('sum_giveback_pct','giveback_n'),'avg_relative_to_btc_pct':avg('sum_relative_pct','relative_n'),
                'distortion_count':int(bucket.get('distortion_count') or 0),
                'terminal_counts':dict(bucket.get('terminal_counts') or {}),
            }
        out[method]=method_out
    return out


def _performance_cost_state_rank(row: Dict[str, Any]) -> int:
    if not isinstance(row, dict):
        return 0
    state=str(row.get('measurement_state') or '').strip().lower()
    if row.get('exchange_confirmed') is True or state in {'exchange_confirmed','average_fill_confirmed','actual_fill_confirmed'}:
        return 40
    if state=='paper_reference_confirmed':
        return 30
    if state=='paper_reference_stale':
        return 20
    if state:
        return 10
    return 0


def _performance_cost_exact_identity(row: Dict[str, Any]) -> Dict[str, Any]:
    """Read only identities sealed by paper's execution-cost writer.

    Writer contract:
      execution_cost_key = ticker|candidate_entry_build_key|pos_id
      pos_id = decision:<minimal_gate_decision_key> for v926 exact OPEN rows.
    No ticker/time-near reconstruction is permitted.
    """
    if not isinstance(row,dict):
        return {'candidate':'','decision':'','pos_id':'','conflict':True,'conflict_reasons':['row_not_dict']}
    execution=str(row.get('execution_cost_key') or '').strip()
    explicit_candidate=str(row.get('candidate_entry_build_key') or '').strip()
    explicit_pos=str(row.get('pos_id') or '').strip()
    parsed_candidate=''; parsed_pos=''
    if execution:
        parts=execution.split('|',2)
        if len(parts)==3:
            parsed_candidate=str(parts[1] or '').strip()
            parsed_pos=str(parts[2] or '').strip()
    conflicts=[]
    if explicit_candidate and parsed_candidate and explicit_candidate!=parsed_candidate:
        conflicts.append('candidate_vs_execution_key')
    if explicit_pos and parsed_pos and explicit_pos!=parsed_pos:
        conflicts.append('pos_vs_execution_key')
    candidate=explicit_candidate
    pos=explicit_pos or parsed_pos
    explicit_decision=str(_performance_first(row,('paper_decision_key_v926','minimal_gate_decision_key_v925','decision_key')) or '').strip()
    decision=''; decision_source='missing'
    if explicit_decision:
        decision=explicit_decision; decision_source='explicit_decision_key'
    elif pos.startswith('decision:') and len(pos)>len('decision:'):
        decision=pos[len('decision:'):].strip(); decision_source='pos_id_decision_prefix'
    elif pos.startswith('market:') and '|plan:' in pos:
        decision=pos; decision_source='pos_id_direct_decision'
    if decision.startswith('decision:'):
        decision=decision[len('decision:'):].strip()
    return {
        'candidate':candidate,'decision':decision,'pos_id':pos,
        'parsed_candidate':parsed_candidate,'parsed_pos_id':parsed_pos,
        'decision_source':decision_source,'conflict':bool(conflicts),'conflict_reasons':conflicts,
    }


def _performance_normalize_cost_observation(row: Dict[str, Any]) -> Dict[str, Any]:
    """Normalize raw cost ledger numbers once at the index boundary."""
    signed=_quality_optional_num(row.get('signed_slippage_pct'))
    cost=_quality_optional_num(row.get('cost_slippage_pct'))
    if cost is None and signed is not None:
        cost=max(0.0,float(signed))
    ready=bool(signed is not None or cost is not None)
    return {
        'canonical_signed_pct':signed,
        'canonical_cost_pct':cost,
        'canonical_numeric_ready':ready,
        'canonical_numeric_source':'paper_execution_cost_ledger',
    }


def _performance_cost_prefer(new_row: Dict[str, Any], prior_row: Optional[Dict[str, Any]]) -> bool:
    """Prefer stronger measurement state, then an actual numeric row, then recency."""
    if not isinstance(prior_row,dict):
        return True
    new_rank=_performance_cost_state_rank(new_row); prior_rank=_performance_cost_state_rank(prior_row)
    if new_rank!=prior_rank:
        return new_rank>prior_rank
    new_ready=bool(new_row.get('canonical_numeric_ready'))
    prior_ready=bool(prior_row.get('canonical_numeric_ready'))
    if new_ready!=prior_ready:
        return new_ready
    new_ts=_quality_optional_num(new_row.get('paper_opened_at')) or 0.0
    prior_ts=_quality_optional_num(prior_row.get('paper_opened_at')) or 0.0
    return new_ts>=prior_ts



def _performance_refresh_cost_index(nowv: float) -> tuple[Dict[str, Any], Dict[str, Any]]:
    """Increment the exact cost index; keep the sole-writer checkpoint parsed in memory."""
    global _PERFORMANCE_COST_INDEX_MEM_V1079
    if PAPER_EXECUTION_COST_LEDGER.exists():
        stat=PAPER_EXECUTION_COST_LEDGER.stat(); current_size=stat.st_size; current_inode=stat.st_ino; current_mtime_ns=stat.st_mtime_ns
    else:
        current_size=0; current_inode=0; current_mtime_ns=0
    memory_reused=isinstance(_PERFORMANCE_COST_INDEX_MEM_V1079,dict) and _PERFORMANCE_COST_INDEX_MEM_V1079.get('schema')=='performance_cost_index_v1009'
    if memory_reused:
        loaded=_PERFORMANCE_COST_INDEX_MEM_V1079
        _PERFORMANCE_INDEX_MEMORY_STATS_V1079['cost_memory_hits']+=1
    else:
        loaded=load_json(PERFORMANCE_COST_INDEX,{})
        _PERFORMANCE_INDEX_MEMORY_STATS_V1079['cost_disk_loads']+=1
    index=loaded if isinstance(loaded,dict) else {}
    valid=(index.get('schema')=='performance_cost_index_v1009' and index.get('numeric_contract')=='canonical_numeric_v967' and isinstance(index.get('observations'),dict) and isinstance(index.get('by_identity_v1009'),dict))
    start=int(index.get('ledger_size_bytes') or 0) if valid else 0; saved_inode=int(index.get('ledger_inode') or 0) if valid else 0; saved_mtime_ns=int(index.get('ledger_mtime_ns') or 0) if valid else 0
    replaced=bool(valid and saved_inode and current_inode and saved_inode!=current_inode); same_size_rewritten=bool(valid and current_size==start and saved_mtime_ns and current_mtime_ns!=saved_mtime_ns)
    rebuild=(not valid) or start<0 or start>current_size or replaced or same_size_rewritten
    observations={} if rebuild else index.get('observations',{}); by_identity={} if rebuild else index.get('by_identity_v1009',{})
    if rebuild: start=0
    rows_read=0; consumed_size=start; partial_tail_bytes=0
    changed_rows=[]
    keep_fields=('execution_cost_key','candidate_entry_build_key','candidate_entry_build_key_source','pos_id','event_id','paper_decision_key_v926','minimal_gate_decision_key_v925','decision_key','paper_score_patch_version','measurement_state','measurement_type','paper_opened_at','quote_age_sec','exchange_confirmed','ticker')
    if current_size>start:
        with PAPER_EXECUTION_COST_LEDGER.open('rb') as handle: handle.seek(start); data=handle.read()
        if data.endswith(b'\n'): complete=data
        else:
            last_newline=data.rfind(b'\n'); complete=data[:last_newline+1] if last_newline>=0 else b''; partial_tail_bytes=len(data)-len(complete)
        consumed_size=start+len(complete)
        for raw in complete.splitlines():
            if not raw.strip(): continue
            try: row=json.loads(raw.decode('utf-8','ignore'))
            except Exception: continue
            if not isinstance(row,dict): continue
            execution=str(row.get('execution_cost_key') or '').strip()
            if not execution: continue
            sealed={key:row.get(key) for key in keep_fields}; sealed.update(_performance_normalize_cost_observation(row))
            observations[execution]=sealed; changed_rows.append(sealed); rows_read+=1
    if rebuild: changed_rows=list(observations.values())
    for row in changed_rows:
        if not isinstance(row,dict): continue
        state=str(row.get('measurement_state') or 'unknown'); exact=_performance_cost_exact_identity(row)
        if exact.get('conflict'): continue
        candidate=str(exact.get('candidate') or '').strip(); decision=str(exact.get('decision') or '').strip(); pos=str(exact.get('pos_id') or '').strip(); aliases=[]
        if candidate: aliases.append(('candidate:'+candidate.removeprefix('candidate:'),'candidate_entry_build_key'))
        if decision: aliases.append(('decision:'+decision.removeprefix('decision:'),str(exact.get('decision_source') or 'decision_exact')))
        if pos: aliases.append(('pos:'+pos,'pos_id_exact'))
        for key,source in aliases:
            canonical={'measurement_state':state,'exchange_confirmed':bool(row.get('exchange_confirmed')),'canonical_signed_pct':_quality_optional_num(row.get('canonical_signed_pct')),'canonical_cost_pct':_quality_optional_num(row.get('canonical_cost_pct')),'canonical_numeric_ready':bool(row.get('canonical_numeric_ready')),'paper_opened_at':_quality_optional_num(row.get('paper_opened_at')),'_performance_identity_key':key,'_performance_identity_source':source,'_performance_decision_key':decision or None,'_performance_candidate_key':candidate or None}
            if canonical['canonical_cost_pct'] is None and canonical['canonical_signed_pct'] is not None: canonical['canonical_cost_pct']=max(0.0,float(canonical['canonical_signed_pct']))
            canonical['canonical_numeric_ready']=bool(canonical['canonical_signed_pct'] is not None or canonical['canonical_cost_pct'] is not None)
            if _performance_cost_prefer(canonical,by_identity.get(key)): by_identity[key]=canonical
    state_counts=Counter(str(row.get('measurement_state') or 'unknown') for row in observations.values() if isinstance(row,dict))
    identity_state_counts=Counter(str(row.get('measurement_state') or 'unknown') for row in by_identity.values() if isinstance(row,dict)); identity_numeric_counts=Counter('ready' if bool(row.get('canonical_numeric_ready')) else 'missing' for row in by_identity.values() if isinstance(row,dict))
    contract_errors=sum(1 for row in observations.values() if isinstance(row,dict) and _performance_cost_state_rank(row)>=30 and not bool(row.get('canonical_numeric_ready')))
    write=bool(rebuild or rows_read or not PERFORMANCE_COST_INDEX.exists())
    persisted={'schema':'performance_cost_index_v1009','version':VERSION,'numeric_contract':'canonical_numeric_v967','updated_ts':nowv if write else index.get('updated_ts'),'ledger_size_bytes':consumed_size,'ledger_file_size_bytes':current_size,'ledger_inode':current_inode,'ledger_mtime_ns':current_mtime_ns,'ledger_rows':len(observations),'observations':observations,'by_identity_v1009':by_identity,'identity_contract':'single persisted exact alias index; unchanged ledger reuses aliases without full rebuild'}
    if write:
        save_json(PERFORMANCE_COST_INDEX,persisted)
    _PERFORMANCE_COST_INDEX_MEM_V1079=persisted
    meta={'rebuilt':rebuild,'incremental_rows':rows_read,'ledger_rows':len(observations),'ledger_size_bytes':consumed_size,'ledger_file_size_bytes':current_size,'partial_tail_bytes':partial_tail_bytes,'index_write_this_cycle':write,'index_reused_v1009':bool(valid and not rebuild and rows_read==0),'state_counts':dict(state_counts),'exact_identity_rows':len(by_identity),'confirmed_exact_identity_rows':sum(1 for row in by_identity.values() if _performance_cost_state_rank(row)>=30),'identity_state_counts':dict(identity_state_counts),'identity_numeric_counts':dict(identity_numeric_counts),'numeric_contract_errors':contract_errors,'numeric_join_policy':'persisted exact aliases; no ticker join','memory_reused_v1079':memory_reused,'disk_loads_v1079':_PERFORMANCE_INDEX_MEMORY_STATS_V1079['cost_disk_loads'],'memory_hits_v1079':_PERFORMANCE_INDEX_MEMORY_STATS_V1079['cost_memory_hits']}
    return {'by_identity':by_identity,'state_counts':dict(state_counts),'ledger_rows':len(observations)},meta

def _performance_canonical_cost_values(cost_row: Optional[Dict[str, Any]]) -> Dict[str, Any]:
    """The only downstream numeric cost consumer."""
    if not isinstance(cost_row,dict):
        return {'ready':False,'signed':None,'cost':None,'state':'','reason':'no_exact_cost'}
    signed=_quality_optional_num(cost_row.get('canonical_signed_pct'))
    cost=_quality_optional_num(cost_row.get('canonical_cost_pct'))
    if cost is None and signed is not None:
        cost=max(0.0,float(signed))
    ready=bool(cost_row.get('canonical_numeric_ready') and (signed is not None or cost is not None))
    return {
        'ready':ready,'signed':signed,'cost':cost,
        'state':str(cost_row.get('measurement_state') or ''),
        'reason':'canonical_numeric_ready' if ready else 'canonical_numeric_missing',
    }


def _performance_cost_for_record(rec: Dict[str, Any], cost_context: Dict[str, Any]) -> tuple[Optional[Dict[str, Any]], str]:
    by_identity=cost_context.get('by_identity') if isinstance(cost_context,dict) and isinstance(cost_context.get('by_identity'),dict) else {}
    candidates=[]
    event=str(rec.get('quality_event_key_v946') or '').strip()
    decision=str(rec.get('minimal_gate_decision_key_v925') or '').strip()
    candidate=str(rec.get('entry_build_key') or '').strip()
    if event.startswith('decision:') or event.startswith('candidate:'):
        candidates.append((event,'quality_event_exact'))
    if decision:
        key='decision:'+decision.removeprefix('decision:')
        if key not in [x[0] for x in candidates]: candidates.append((key,'decision_key_exact'))
    if candidate:
        key='candidate:'+candidate.removeprefix('candidate:')
        if key not in [x[0] for x in candidates]: candidates.append((key,'candidate_key_exact'))
    matched_missing=[]
    for key,mode in candidates:
        row=by_identity.get(key)
        if not isinstance(row,dict):
            continue
        canonical=_performance_canonical_cost_values(row)
        if not canonical.get('ready'):
            matched_missing.append(key)
            continue
        matched=dict(row); matched['_performance_match_key']=key; matched['_performance_match_mode']=mode
        return matched,mode
    if not candidates:
        return None,'quality_record_exact_key_missing'
    if matched_missing:
        return None,'exact_key_numeric_missing:'+'|'.join(matched_missing[:3])
    return None,'missing_exact_cost_key'


def _performance_quality_rows(records: List[Dict[str, Any]], horizon: str, cost_context: Optional[Dict[str, Any]]=None) -> List[Dict[str, Any]]:
    rows=[]
    for rec in records:
        if not isinstance(rec,dict): continue
        sample=(rec.get('samples') or {}).get(horizon) if isinstance(rec.get('samples'),dict) else None
        if not isinstance(sample,dict): continue
        pct=_quality_optional_num(sample.get('pct'))
        if pct is None: continue
        metrics=rec.get('initial_metrics') if isinstance(rec.get('initial_metrics'),dict) else {}
        event_context=rec.get('event_context') if isinstance(rec.get('event_context'),dict) else _legacy_missing_event_context()
        price=_quality_optional_num(rec.get('first_price'),metrics.get('first_price')) or 0.0
        spread=_quality_optional_num(metrics.get('spread_pct'))
        slip=_quality_optional_num(metrics.get('confirmed_slippage_pct'))
        slip_source=str(metrics.get('confirmed_slippage_source') or '').lower()
        cost_row,cost_join_mode=_performance_cost_for_record(rec,cost_context if isinstance(cost_context,dict) else {})
        signed_reference=None
        canonical_cost=_performance_canonical_cost_values(cost_row)
        # Exact canonical cost has priority over every legacy row-local slippage field.
        # The old order classified derived_from_spread first, so an exact numeric match
        # was counted as connected while its numeric value was deliberately discarded.
        if isinstance(cost_row,dict) and str(cost_row.get('measurement_state') or '')=='paper_reference_confirmed' and canonical_cost.get('ready'):
            slip_class='paper_reference'
            signed_reference=canonical_cost.get('signed')
            usable_slip=canonical_cost.get('cost')
            slip_source='paper_execution_cost_ledger_canonical'
        elif slip is not None and any(x in slip_source for x in ('exchange','average_fill','actual_fill')):
            slip_class='exchange_confirmed'; usable_slip=slip
        elif 'derived_from_spread' in slip_source:
            slip_class='legacy_derived'; usable_slip=None
        elif slip is not None and any(x in slip_source for x in ('paper_reference','best_ask_reference')):
            slip_class='paper_reference'; signed_reference=slip; usable_slip=max(0.0,float(slip))
        else:
            slip_class='missing'; usable_slip=None
        occurrence=str(rec.get('hot_watch_occurrence_key_v945') or '').strip()
        regime=str(event_context.get('market_regime') or 'context_missing')
        if regime not in ('up_or_strong','down_or_weak','sideways_or_neutral','context_missing'): regime='context_missing'
        turnover=_quality_optional_num(event_context.get('turnover_24h'))
        volume_ratio=_quality_optional_num(event_context.get('volume_ratio'))
        if turnover is None and volume_ratio is None: volume_state='context_missing'
        elif (volume_ratio is not None and volume_ratio>=1.2) or (turnover is not None and turnover>=400_000_000): volume_state='strong_or_high'
        elif turnover is not None and turnover<250_000_000: volume_state='low_turnover'
        else: volume_state='normal'
        if price<100: price_band='low_under_100'
        elif price<1000: price_band='mid_100_999'
        else: price_band='high_1000_plus'
        tick_pct=_performance_tick_pct(price)
        rows.append({
            'event_key':str(rec.get('quality_event_key_v946') or ''),'identity_mode':str(rec.get('identity_mode_v946') or ''),
            'ticker':ticker_norm(rec.get('ticker')),'occurrence':occurrence,'cohort':str(rec.get('cohort') or 'unknown'),
            'pct':pct,'max_pct':_quality_optional_num(sample.get('max_pct')),'min_pct':_quality_optional_num(sample.get('min_pct')),
            'giveback_pct':_quality_optional_num(sample.get('giveback_pct')),'first_seen_ts':_quality_optional_num(rec.get('first_seen_ts')),
            'spread_pct':spread,'slippage_pct':usable_slip,'paper_reference_signed_pct':signed_reference,'slippage_class':slip_class,'slippage_source':slip_source,'cost_join_mode':cost_join_mode,
            'cost_measurement_state':str(cost_row.get('measurement_state') or 'no_exact_cost') if isinstance(cost_row,dict) else 'no_exact_cost',
            'cost_identity_source':str(cost_row.get('_performance_identity_source') or 'none') if isinstance(cost_row,dict) else 'none',
            'cost_numeric_reason':(_performance_canonical_cost_values(cost_row).get('reason') if isinstance(cost_row,dict) else 'no_exact_cost'),
            'spread_net_pct':pct-(spread or 0.0),
            'reference_net_pct':pct-(spread or 0.0)-(usable_slip or 0.0) if slip_class in ('exchange_confirmed','paper_reference') else None,
            'confirmed_net_pct':pct-(spread or 0.0)-(usable_slip or 0.0) if slip_class=='exchange_confirmed' else None,
            'fee_pct':None,'regime':regime,'market_context_source':event_context.get('market_context_source') or 'legacy_context_missing','hot_state':'hot_occurrence' if occurrence else 'general_market',
            'volume_state':volume_state,'turnover_24h':turnover,'volume_ratio':volume_ratio,
            'price_band':price_band,'distortion':bool(tick_pct>=0.50 or abs(pct)>=15.0),'tick_pct':tick_pct,
            'scanner_to_candidate_sec':_quality_optional_num(metrics.get('scanner_to_candidate_sec')),
            'scanner_to_s2_sec':_quality_optional_num(metrics.get('scanner_to_s2_sec')),
            'scanner_to_s1_sec':_quality_optional_num(metrics.get('scanner_to_s1_sec')),
        })
    return rows


def _performance_group_stats(rows: List[Dict[str, Any]]) -> Dict[str, Any]:
    vals=[float(r['pct']) for r in rows if isinstance(r.get('pct'),(int,float))]
    if not vals: return {'n':0}
    clean=[float(r['pct']) for r in rows if isinstance(r.get('pct'),(int,float)) and not r.get('distortion')]
    spread_net=[float(r['spread_net_pct']) for r in rows if isinstance(r.get('spread_net_pct'),(int,float))]
    ref_net=[float(r['reference_net_pct']) for r in rows if isinstance(r.get('reference_net_pct'),(int,float))]
    confirmed_net=[float(r['confirmed_net_pct']) for r in rows if isinstance(r.get('confirmed_net_pct'),(int,float))]
    tickers=Counter(str(r.get('ticker') or '-') for r in rows)
    occurrences={str(r.get('occurrence')) for r in rows if str(r.get('occurrence') or '').strip()}
    by_ticker={}
    by_occ={}
    for row in sorted(rows,key=lambda r:(_quality_optional_num(r.get('first_seen_ts')) or 0.0,str(r.get('event_key') or ''))):
        ticker=str(row.get('ticker') or '')
        occ=str(row.get('occurrence') or '')
        if ticker and ticker not in by_ticker: by_ticker[ticker]=row
        if occ and occ not in by_occ: by_occ[occ]=row
    ticker_vals=[float(r['pct']) for r in by_ticker.values() if isinstance(r.get('pct'),(int,float))]
    occ_vals=[float(r['pct']) for r in by_occ.values() if isinstance(r.get('pct'),(int,float))]
    top_share=tickers.most_common(1)[0][1]/len(rows) if rows and tickers else 0.0
    trust='WAITING'
    if len(clean)>=30 and len(tickers)>=20 and top_share<=0.20: trust='REFERENCE'
    if len(clean)>=100 and len(tickers)>=40 and top_share<=0.12: trust='TRUSTED'
    return {
        'n':len(vals),'avg_pct':round(sum(vals)/len(vals),4),'median_pct':round(_quality_percentile(vals,0.50),4),
        'trimmed_avg_pct':round(_sample_trimmed_mean(vals) or 0.0,4),
        'clean_n':len(clean),'clean_avg_pct':round(sum(clean)/len(clean),4) if clean else None,
        'unique_tickers':len(tickers),'unique_occurrences':len(occurrences),
        'unique_ticker_avg_pct':round(sum(ticker_vals)/len(ticker_vals),4) if ticker_vals else None,
        'unique_occurrence_avg_pct':round(sum(occ_vals)/len(occ_vals),4) if occ_vals else None,
        'spread_net_avg_pct':round(sum(spread_net)/len(spread_net),4) if spread_net else None,
        'reference_net_n':len(ref_net),'reference_net_avg_pct':round(sum(ref_net)/len(ref_net),4) if ref_net else None,
        'confirmed_net_n':len(confirmed_net),'confirmed_net_avg_pct':round(sum(confirmed_net)/len(confirmed_net),4) if confirmed_net else None,
        'winner_0_5_count':sum(1 for v in vals if v>=0.5),'loser_minus_0_1_count':sum(1 for v in vals if v<=-0.1),
        'distortion_count':sum(1 for r in rows if r.get('distortion')),'top_ticker_share_pct':round(top_share*100.0,2),
        'trust':trust,
    }


def _performance_quality_analysis(records: List[Dict[str, Any]], quality_status: Dict[str, Any], cost_context: Optional[Dict[str, Any]]=None) -> Dict[str, Any]:
    horizon_rows={label:_performance_quality_rows(records,label,cost_context) for label in ('1m','3m','5m','10m','20m','60m')}
    blocked={}
    cohorts=sorted({str(r.get('cohort') or 'unknown') for r in records if str(r.get('cohort') or '')!='s1_pass'})
    for cohort in cohorts:
        item={}
        for horizon in ('10m','60m'):
            rows=[r for r in horizon_rows[horizon] if r.get('cohort')==cohort]
            stats=_performance_group_stats(rows)
            if stats.get('n'): item[horizon]=stats
        if item: blocked[cohort]=item
    s1_1=[r for r in horizon_rows['1m'] if r.get('cohort')=='s1_pass']
    s1_10=[r for r in horizon_rows['10m'] if r.get('cohort')=='s1_pass']
    m10_by_key={r.get('event_key'):r for r in s1_10}
    adverse=[r for r in s1_1 if float(r.get('pct') or 0.0)<=-0.1]
    recovered=sum(1 for r in adverse if isinstance((m10_by_key.get(r.get('event_key')) or {}).get('pct'),(int,float)) and float((m10_by_key.get(r.get('event_key')) or {}).get('pct'))>=0.1)
    persistent=sum(1 for r in adverse if isinstance((m10_by_key.get(r.get('event_key')) or {}).get('pct'),(int,float)) and float((m10_by_key.get(r.get('event_key')) or {}).get('pct'))<=-0.1)
    giveback=[r for r in s1_10 if isinstance(r.get('max_pct'),(int,float)) and isinstance(r.get('pct'),(int,float)) and float(r.get('max_pct'))-float(r.get('pct'))>=0.5]
    passed={
        's1_1m':_performance_group_stats(s1_1),'s1_10m':_performance_group_stats(s1_10),
        'immediate_adverse_count':len(adverse),'recovered_positive_by_10m':recovered,'persistent_negative_10m':persistent,
        'giveback_0_5_count':len(giveback),'positive_to_negative_count':sum(1 for r in giveback if float(r.get('max_pct') or 0)>0.2 and float(r.get('pct') or 0)<0),
        'adverse_samples':[{k:r.get(k) for k in ('ticker','event_key','pct','min_pct','occurrence')} for r in sorted(adverse,key=lambda x:float(x.get('pct') or 0))[:5]],
        'giveback_samples':[{**{k:r.get(k) for k in ('ticker','event_key','pct','max_pct','giveback_pct')},'observed_giveback_pct':round(float(r.get('max_pct'))-float(r.get('pct')),4)} for r in sorted(giveback,key=lambda x:float(x.get('max_pct') or 0)-float(x.get('pct') or 0),reverse=True)[:5]],
    }
    market={}
    for horizon in ('10m','60m'):
        rows=horizon_rows[horizon]; splits={}
        for field in ('regime','hot_state','volume_state','price_band'):
            split={}
            for value in sorted({str(r.get(field) or 'unknown') for r in rows}):
                stats=_performance_group_stats([r for r in rows if str(r.get(field) or 'unknown')==value])
                if stats.get('n'): split[value]=stats
            splits[field]=split
        market[horizon]=splits
    all10=horizon_rows['10m']; slip_counts=Counter(str(r.get('slippage_class') or 'missing') for r in all10)
    exact_modes=Counter(str(r.get('identity_mode_v946') or 'unknown') for r in records)
    market_context_counts=Counter(str(r.get('regime') or 'context_missing') for r in all10)
    market_source_counts=Counter(str(r.get('market_context_source') or 'legacy_context_missing') for r in all10)
    volume_context_counts=Counter(str(r.get('volume_state') or 'context_missing') for r in all10)
    cost_join_counts=Counter(str(r.get('cost_join_mode') or 'missing_exact_cost_key') for r in all10)
    cost_measurement_state_counts=Counter(str(r.get('cost_measurement_state') or 'no_exact_cost') for r in all10)
    cost_identity_source_counts=Counter(str(r.get('cost_identity_source') or 'none') for r in all10)
    cost_numeric_state_counts=Counter(str(r.get('cost_numeric_reason') or 'no_exact_cost') for r in all10)
    paper_reference_numeric_rows=sum(1 for r in all10 if str(r.get('slippage_class') or '')=='paper_reference' and isinstance(r.get('reference_net_pct'),(int,float)))
    # A cost connection exists only when the same canonical row supplied a number.
    # State-only alias matches remain diagnostics and are never reported as connected.
    paper_reference_connected_rows=paper_reference_numeric_rows
    tracked_market_sealed=0; tracked_turnover_sealed=0
    for rec in records:
        event_context=rec.get('event_context') if isinstance(rec,dict) and isinstance(rec.get('event_context'),dict) else _legacy_missing_event_context()
        if event_context.get('market_context_sealed') is True: tracked_market_sealed+=1
        if event_context.get('turnover_context_sealed') is True: tracked_turnover_sealed+=1
    return {
        'tracked_records':len(records),'quality_exact_ready':int(quality_status.get('exact_key_ready') or 0),
        'quality_exact_missing':int(quality_status.get('exact_key_missing') or 0),'identity_modes':dict(exact_modes),
        'blocked_winners':blocked,'passed_losers':passed,'market_splits':market,'context_connection':{'tracked_records':len(records),'tracked_market_sealed':tracked_market_sealed,'tracked_market_missing':max(0,len(records)-tracked_market_sealed),'tracked_turnover_sealed':tracked_turnover_sealed,'tracked_turnover_missing':max(0,len(records)-tracked_turnover_sealed),'market_counts':dict(market_context_counts),'market_source_counts':dict(market_source_counts),'volume_counts':dict(volume_context_counts),'cost_join_counts':dict(cost_join_counts),'cost_measurement_state_counts':dict(cost_measurement_state_counts),'cost_identity_source_counts':dict(cost_identity_source_counts),'cost_numeric_state_counts':dict(cost_numeric_state_counts),'paper_reference_connected_rows':paper_reference_connected_rows,'paper_reference_numeric_rows':paper_reference_numeric_rows,'paper_reference_missing_numeric_rows':max(0,paper_reference_connected_rows-paper_reference_numeric_rows),'legacy_market_context_missing':market_context_counts.get('context_missing',0),'legacy_volume_context_missing':volume_context_counts.get('context_missing',0),'event_context_migrated_this_cycle':int(quality_status.get('event_context_migrated_this_cycle') or 0),'event_context_migration':quality_status.get('event_context_migration') if isinstance(quality_status.get('event_context_migration'),dict) else {}},
        'cost':{
            'ten_minute':_performance_group_stats(all10),'slippage_source_counts':dict(slip_counts),
            'exchange_confirmed_slippage_rows':slip_counts.get('exchange_confirmed',0),
            'paper_reference_slippage_rows':slip_counts.get('paper_reference',0),
            'paper_reference_connected_rows':paper_reference_connected_rows,
            'paper_reference_numeric_rows':paper_reference_numeric_rows,
            'paper_reference_missing_numeric_rows':max(0,paper_reference_connected_rows-paper_reference_numeric_rows),
            'legacy_derived_rows':slip_counts.get('legacy_derived',0),'missing_slippage_rows':slip_counts.get('missing',0),
            'fee_source_status':PERFORMANCE_FEE_SOURCE_STATUS,'confirmed_net_ready':bool(slip_counts.get('exchange_confirmed',0)) and False,
            'policy':'gross, spread-only and paper-reference cost are separated; confirmed net waits for exchange fill slippage and exact fee source',
        },
        'blocked_samples':[
            {k:r.get(k) for k in ('ticker','event_key','cohort','pct','max_pct','min_pct','giveback_pct','occurrence')}
            for r in sorted([r for r in all10 if r.get('cohort')!='s1_pass' and float(r.get('pct') or 0)>=0.5],key=lambda x:float(x.get('pct') or 0),reverse=True)[:8]
        ],
    }


def _performance_sources(row: Dict[str, Any]) -> List[Dict[str, Any]]:
    if not isinstance(row,dict): return []
    out=[row]
    for key in ('quality_evidence_v938','quality_evidence_v936','entry_diagnostics','paper_timing_spine_v940','closed_exact_v926'):
        obj=row.get(key)
        if isinstance(obj,dict):
            out.append(obj)
            for nested_key in ('quality_evidence_v938','quality_evidence_v936','paper_timing_spine_v940'):
                nested=obj.get(nested_key)
                if isinstance(nested,dict): out.append(nested)
    return out


def _performance_first(row: Dict[str, Any], keys: tuple[str,...]) -> Any:
    for source in _performance_sources(row):
        for key in keys:
            value=source.get(key)
            if value not in (None,'',[],{}): return value
    return None


def _performance_exact_key(row: Dict[str, Any]) -> str:
    value=_performance_first(row,('paper_decision_key_v926','minimal_gate_decision_key_v925','decision_key'))
    return str(value or '').strip()


def _performance_pos_id(row: Dict[str, Any]) -> str:
    value=_performance_first(row,('pos_id','paper_pos_id_v926'))
    return str(value or '').strip()


CLEAN_SCORE_CUTOVER_TS = 1782093476.0  # 2026-06-22 10:57:56 Asia/Seoul
CLEAN_SCORE_CUTOVER_LABEL = 'v977_alt_swing_mode_only'
CLEAN_SCORE_STRATEGY_MODE = 'ALT_SWING_V977'
CLEAN_SCORE_ALLOWED_EXIT_REASONS = {'structure_target','structure_invalid','swing_no_progress','swing_max_weak_hold'}


def performance_open_timestamp(row: Dict[str, Any]) -> float:
    for source in _performance_sources(row):
        for key in ('opened_at', 'opened_ts', 'open_ts', 'entry_open_ts'):
            try:
                value = source.get(key)
                if value not in (None, '', [], {}):
                    ts = float(value)
                    if ts > 10_000_000_000:
                        ts /= 1000.0
                    if ts > 0:
                        return ts
            except Exception:
                continue
    return 0.0


def performance_strategy_mode(row: Dict[str, Any]) -> str:
    for source in _performance_sources(row):
        value = source.get('strategy_mode') or source.get('strategy_mode_v977')
        if value:
            return str(value)
    return ''


def performance_exit_contract_ok(row: Dict[str, Any]) -> bool:
    reason = str(_performance_first(row, ('exit_reason','exit_rule','close_reason')) or '').strip()
    return reason in CLEAN_SCORE_ALLOWED_EXIT_REASONS


def performance_row_is_clean(row: Dict[str, Any]) -> bool:
    # Historical score membership is fixed by OPEN-time strategy mode.
    # Current exit contract is analysis-only and cannot erase prior CLOSED rows.
    return performance_open_timestamp(row) >= CLEAN_SCORE_CUTOVER_TS and performance_strategy_mode(row) == CLEAN_SCORE_STRATEGY_MODE



def _closed_value(row: Dict[str, Any], decision: Dict[str, Any], keys: tuple[str, ...]) -> Any:
    value = _performance_first(row, keys)
    if value not in (None, '', [], {}):
        return value
    return _performance_first(decision, keys) if isinstance(decision, dict) else None


def _closed_reaction_point(row: Dict[str, Any], decision: Dict[str, Any], key: str) -> Dict[str, Any]:
    for source in (row, decision):
        if not isinstance(source, dict):
            continue
        for field in ('post_entry_reaction_v800', 'post_entry_reaction_v793'):
            obj = source.get(field)
            if isinstance(obj, dict) and isinstance(obj.get(key), dict):
                return obj.get(key) or {}
        for nested_key in ('quality_evidence_v938', 'quality_evidence_v936', 'entry_diagnostics', 'closed_exact_v926'):
            nested = source.get(nested_key)
            if not isinstance(nested, dict):
                continue
            for field in ('post_entry_reaction_v800', 'post_entry_reaction_v793'):
                obj = nested.get(field)
                if isinstance(obj, dict) and isinstance(obj.get(key), dict):
                    return obj.get(key) or {}
    return {}


def _closed_exact_record(row: Dict[str, Any], decision: Dict[str, Any], key: str, pos: str, mode: str) -> Dict[str, Any]:
    raw_key = str(key or _performance_exact_key(decision) or '').strip()
    identity = 'decision:' + raw_key.removeprefix('decision:') if raw_key else ''
    pnl = _quality_optional_num(_closed_value(row, decision, ('net_pct','result_pct','pnl_pct','return_pct','profit_pct')))
    gross_close = _quality_optional_num(_closed_value(row, decision, ('last_gross_pct_v804','gross_pct','current_gross_pct','price_move_pct')))
    peak = _quality_optional_num(_closed_value(row, decision, ('peak_pct','net_peak_pct','max_net_profit_pct')))
    gross_peak = _quality_optional_num(_closed_value(row, decision, ('gross_peak_pct','peak_profit_pct','max_profit_pct')))
    trough = _quality_optional_num(_closed_value(row, decision, ('trough_pct','net_trough_pct','max_net_loss_pct')))
    gross_trough = _quality_optional_num(_closed_value(row, decision, ('gross_trough_pct','min_profit_pct','max_loss_pct')))
    explicit_giveback = _quality_optional_num(_closed_value(row, decision, ('giveback_pct','missed_profit_pct')))
    giveback = explicit_giveback
    if giveback is None and peak is not None and pnl is not None:
        giveback = max(0.0, peak - pnl)
    m1 = _closed_reaction_point(row, decision, 'm1')
    return {
        'identity': identity,
        'key': raw_key,
        'pos_id': pos,
        'match_mode': mode,
        'ticker': ticker_norm(_closed_value(row, decision, ('ticker','market','symbol'))),
        'pnl_pct': pnl,
        'gross_close_pct': gross_close,
        'peak_pct': peak,
        'gross_peak_pct': gross_peak,
        'trough_pct': trough,
        'gross_trough_pct': gross_trough,
        'giveback_pct': giveback,
        'm1_label': str(m1.get('label') or ''),
        'm1_gross_pct': _quality_optional_num(m1.get('gross_pct')),
        'm1_gross_trough_pct': _quality_optional_num(m1.get('gross_trough_pct')),
        'exit_reason': str(_closed_value(row, decision, ('exit_reason','exit_rule','close_reason')) or 'unknown'),
        'age_min': _quality_optional_num(_closed_value(row, decision, ('age_min','hold_minutes'))),
        'hold_sec': _quality_optional_num(_closed_value(row, decision, ('hold_sec','holding_sec'))),
        'first_delay_sec': _quality_optional_num(_closed_value(row, decision, ('first_to_paper_delay_sec','first_to_open_delay_sec'))),
        's1_delay_sec': _quality_optional_num(_closed_value(row, decision, ('s1_to_paper_delay_sec','s1_to_open_delay_sec'))),
        'trigger_delay_sec': _quality_optional_num(_closed_value(row, decision, ('trigger_to_open_delay_sec',))),
        'selected_delay_sec': _quality_optional_num(_closed_value(row, decision, ('selected_to_open_delay_sec',))),
        'time_exit_extension_count': int(fnum(_closed_value(row, decision, ('time_exit_extension_count',)), default=0.0)),
        'went_negative_after_profit': bool(_closed_value(row, decision, ('went_negative_after_profit',))),
    }


def _closed_exit_bucket(reason: Any) -> str:
    value = str(reason or '').lower()
    if 'fast_fail' in value or '빠른실패' in value:
        return 'fast_fail'
    if 'stop_loss' in value or value in ('stop','loss_cut') or '손절' in value:
        return 'stop_loss'
    if 'time_exit' in value or '시간' in value:
        return 'time_exit'
    if 'protect' in value or '보호' in value:
        return 'protection'
    if 'take_profit' in value or value == 'tp' or '익절' in value:
        return 'take_profit'
    return 'other'


def _closed_group_stats(rows: List[Dict[str, Any]]) -> Dict[str, Any]:
    pnl = [float(r['pnl_pct']) for r in rows if isinstance(r.get('pnl_pct'), (int, float))]
    losses = [v for v in pnl if v <= 0]
    wins = [v for v in pnl if v > 0]
    return {
        'n': len(rows),
        'pnl_n': len(pnl),
        'wins': len(wins),
        'losses': len(losses),
        'total_pnl_pct': round(sum(pnl), 4) if pnl else None,
        'avg_pnl_pct': round(sum(pnl) / len(pnl), 4) if pnl else None,
        'loss_sum_pct': round(sum(losses), 4) if losses else 0.0,
        'abs_loss_pct': round(-sum(losses), 4) if losses else 0.0,
        'avg_loss_pct': round(sum(losses) / len(losses), 4) if losses else None,
    }


def _c_exact_closed_loss_analysis(exact_identity_keys: set[str], closed: Dict[str, Any]) -> Dict[str, Any]:
    matched = closed.get('_matched_rows_internal') if isinstance(closed, dict) and isinstance(closed.get('_matched_rows_internal'), list) else []
    rows = [dict(r) for r in matched if isinstance(r, dict) and str(r.get('identity') or '') in exact_identity_keys]
    if not rows:
        return {
            'schema': 'c_exact_closed_loss_analysis_v976',
            'state': 'WAITING_EXACT_C_CLOSED_ROWS',
            'exact_closed_rows': 0,
            'policy': 'decision exact identity only; ticker and time-near joins forbidden; analysis only',
        }

    def is_loss(r: Dict[str, Any]) -> bool:
        return isinstance(r.get('pnl_pct'), (int, float)) and float(r.get('pnl_pct')) <= 0

    def is_immediate_adverse(r: Dict[str, Any]) -> bool:
        label = str(r.get('m1_label') or '')
        m1_gross = r.get('m1_gross_pct')
        m1_trough = r.get('m1_gross_trough_pct')
        gross_trough = r.get('gross_trough_pct')
        return bool(
            label in ('바로역행', '역행주의')
            or (isinstance(m1_gross, (int, float)) and float(m1_gross) <= -0.18)
            or (isinstance(m1_trough, (int, float)) and float(m1_trough) <= -0.30)
            or (not label and isinstance(gross_trough, (int, float)) and float(gross_trough) <= -0.30)
        )

    def is_giveback(r: Dict[str, Any]) -> bool:
        giveback = r.get('giveback_pct')
        peak = r.get('peak_pct')
        return bool(
            isinstance(giveback, (int, float)) and float(giveback) >= 0.50
            and (not isinstance(peak, (int, float)) or float(peak) > 0.20)
        )

    def is_late(r: Dict[str, Any]) -> bool:
        return any(isinstance(r.get(k), (int, float)) and float(r.get(k)) >= 60.0 for k in ('first_delay_sec','s1_delay_sec','trigger_delay_sec'))

    def is_fee_flip(r: Dict[str, Any]) -> bool:
        gross = r.get('gross_close_pct'); pnl = r.get('pnl_pct')
        return bool(isinstance(gross, (int, float)) and isinstance(pnl, (int, float)) and float(gross) > 0 and float(pnl) <= 0)

    overlap_rows = {
        'immediate_adverse': [r for r in rows if is_immediate_adverse(r)],
        'giveback': [r for r in rows if is_giveback(r)],
        'late_entry': [r for r in rows if is_late(r)],
        'fixed_fee_flip': [r for r in rows if is_fee_flip(r)],
    }
    overlap = {name: _closed_group_stats(group) for name, group in overlap_rows.items()}

    primary_groups: Dict[str, List[Dict[str, Any]]] = {}
    annotated = []
    for row in rows:
        primary = 'profit' if not is_loss(row) else ''
        if not primary:
            if is_giveback(row):
                primary = 'giveback'
            elif is_fee_flip(row):
                primary = 'fixed_fee_flip'
            elif is_immediate_adverse(row):
                primary = 'immediate_adverse'
            elif is_late(row):
                primary = 'late_entry'
            else:
                primary = _closed_exit_bucket(row.get('exit_reason'))
        primary_groups.setdefault(primary, []).append(row)
        rr = dict(row); rr['primary_cause'] = primary; annotated.append(rr)

    primary_stats = {name: _closed_group_stats(group) for name, group in primary_groups.items() if name != 'profit'}
    ranked = sorted(
        ((float(stats.get('abs_loss_pct') or 0.0), int(stats.get('losses') or 0), name, stats) for name, stats in primary_stats.items()),
        reverse=True,
    )
    biggest = {'cause': ranked[0][2], **ranked[0][3]} if ranked else {}

    exit_groups: Dict[str, List[Dict[str, Any]]] = {}
    raw_reasons: Dict[str, List[Dict[str, Any]]] = {}
    for row in rows:
        exit_groups.setdefault(_closed_exit_bucket(row.get('exit_reason')), []).append(row)
        raw_reasons.setdefault(str(row.get('exit_reason') or 'unknown'), []).append(row)
    exit_stats = {name: _closed_group_stats(group) for name, group in exit_groups.items()}
    raw_exit_stats = {name: _closed_group_stats(group) for name, group in raw_reasons.items()}

    worst = sorted(
        [r for r in annotated if is_loss(r)],
        key=lambda r: float(r.get('pnl_pct') or 0.0),
    )[:8]
    worst_rows = [{
        'ticker': r.get('ticker'), 'pnl_pct': r.get('pnl_pct'), 'gross_close_pct': r.get('gross_close_pct'),
        'peak_pct': r.get('peak_pct'), 'gross_trough_pct': r.get('gross_trough_pct'),
        'giveback_pct': r.get('giveback_pct'), 'exit_reason': r.get('exit_reason'),
        'primary_cause': r.get('primary_cause'), 'age_min': r.get('age_min'),
    } for r in worst]

    return {
        'schema': 'c_exact_closed_loss_analysis_v976',
        'state': 'ACTIVE',
        'exact_closed_rows': len(rows),
        'summary': _closed_group_stats(rows),
        'overlap_causes': overlap,
        'primary_causes': primary_stats,
        'biggest_primary_cause': biggest,
        'exit_buckets': exit_stats,
        'raw_exit_reasons': raw_exit_stats,
        'worst_losses': worst_rows,
        'fixed_fee_flip_definition': 'gross close > 0 and paper pnl <= 0; fixed roundtrip fee only, not exchange-confirmed spread/slippage',
        'primary_precedence': ['giveback','fixed_fee_flip','immediate_adverse','late_entry','exit_reason_bucket'],
        'policy': 'C exact CLOSED matched by decision identity only; ticker is display only; overlapping evidence and one non-overlapping primary cause are both reported; no trading rule changes',
    }




def _performance_normalize_structure_identity_v962(value: Any) -> str:
    text=str(value or '').strip()
    if not text:
        return ''
    if text.startswith('decision:') or text.startswith('candidate:'):
        return text
    if text.startswith('market:') or '|plan:' in text:
        return 'decision:'+text
    return 'candidate:'+text

def _performance_refresh_c_shadow_index_v962(nowv: float) -> tuple[Dict[str, Any], Dict[str, Any]]:
    global _PERFORMANCE_C_SHADOW_INDEX_MEM_V1079
    if STRUCTURE_LAB_HORIZON_LEDGER.exists():
        stat=STRUCTURE_LAB_HORIZON_LEDGER.stat(); current_size=stat.st_size; current_inode=stat.st_ino; current_mtime_ns=stat.st_mtime_ns
    else:
        current_size=0; current_inode=0; current_mtime_ns=0
    memory_reused=isinstance(_PERFORMANCE_C_SHADOW_INDEX_MEM_V1079,dict) and _PERFORMANCE_C_SHADOW_INDEX_MEM_V1079.get('schema')=='performance_c_break_retest_shadow_index_v962'
    if memory_reused:
        loaded=_PERFORMANCE_C_SHADOW_INDEX_MEM_V1079
        _PERFORMANCE_INDEX_MEMORY_STATS_V1079['c_shadow_memory_hits']+=1
    else:
        loaded=load_json(PERFORMANCE_C_SHADOW_INDEX,{})
        _PERFORMANCE_INDEX_MEMORY_STATS_V1079['c_shadow_disk_loads']+=1
    valid=isinstance(loaded,dict) and loaded.get('schema')=='performance_c_break_retest_shadow_index_v962' and isinstance(loaded.get('observations'),dict)
    start=int(loaded.get('ledger_size_bytes') or 0) if valid else 0
    replaced=bool(valid and int(loaded.get('ledger_inode') or 0) and current_inode and int(loaded.get('ledger_inode') or 0)!=current_inode)
    same_size_rewritten=bool(valid and current_size==start and int(loaded.get('ledger_mtime_ns') or 0) and int(loaded.get('ledger_mtime_ns') or 0)!=current_mtime_ns)
    rebuild=(not valid) or start<0 or start>current_size or replaced or same_size_rewritten
    observations={} if rebuild else loaded.get('observations',{})
    legacy_missing=0 if rebuild else int(loaded.get('legacy_identity_missing_rows') or 0)
    if rebuild:
        start=0
    rows_read=0; c_rows_read=0; exact_rows_added=0; consumed_size=start; partial_tail_bytes=0
    if current_size>start:
        with STRUCTURE_LAB_HORIZON_LEDGER.open('rb') as handle:
            handle.seek(start); data=handle.read()
        if data.endswith(b'\n'):
            complete=data
        else:
            last=data.rfind(b'\n'); complete=data[:last+1] if last>=0 else b''; partial_tail_bytes=len(data)-len(complete)
        consumed_size=start+len(complete)
        for raw in complete.splitlines():
            if not raw.strip():
                continue
            try:
                row=json.loads(raw.decode('utf-8','ignore'))
            except Exception:
                continue
            if not isinstance(row,dict):
                continue
            rows_read+=1
            if str(row.get('method') or '')!='C_BREAK_RETEST':
                continue
            c_rows_read+=1
            identity=_performance_normalize_structure_identity_v962(row.get('candidate_exact_identity'))
            if not identity:
                legacy_missing+=1
                continue
            result_key=str(row.get('result_key') or (str(row.get('event_key') or '')+'|'+str(row.get('horizon') or ''))).strip()
            if not result_key:
                continue
            observations[result_key]={
                'result_key':result_key,'event_key':row.get('event_key'),'ticker':row.get('ticker'),'horizon':row.get('horizon'),
                'candidate_exact_identity':identity,'event_ts':row.get('event_ts'),'entry_price':row.get('entry_price'),
                'pct':row.get('pct'),'max_pct':row.get('max_pct'),'min_pct':row.get('min_pct'),'giveback_pct':row.get('giveback_pct'),
                'first_terminal':row.get('first_terminal'),'invalid_ts':row.get('invalid_ts'),'target_ts':row.get('target_ts'),
            }
            exact_rows_added+=1
    write=bool(rebuild or rows_read or not PERFORMANCE_C_SHADOW_INDEX.exists())
    index={
        'schema':'performance_c_break_retest_shadow_index_v962','version':VERSION,'updated_ts':nowv if write else loaded.get('updated_ts'),
        'ledger_size_bytes':consumed_size,'ledger_file_size_bytes':current_size,'ledger_inode':current_inode,'ledger_mtime_ns':current_mtime_ns,
        'observations':observations,'legacy_identity_missing_rows':legacy_missing,
        'policy':'C_BREAK_RETEST only; future structure horizon rows carry candidate exact identity; legacy missing is never ticker/time-near joined',
    }
    if write:
        save_json(PERFORMANCE_C_SHADOW_INDEX,index)
    _PERFORMANCE_C_SHADOW_INDEX_MEM_V1079=index
    return index,{
        'rebuilt':rebuild,'incremental_rows':rows_read,'c_rows_read':c_rows_read,'exact_rows_added':exact_rows_added,
        'exact_observation_rows':len(observations),'legacy_identity_missing_rows':legacy_missing,'index_write_this_cycle':write,
        'ledger_size_bytes':consumed_size,'partial_tail_bytes':partial_tail_bytes,'memory_reused_v1079':memory_reused,
        'disk_loads_v1079':_PERFORMANCE_INDEX_MEMORY_STATS_V1079['c_shadow_disk_loads'],'memory_hits_v1079':_PERFORMANCE_INDEX_MEMORY_STATS_V1079['c_shadow_memory_hits'],
    }

def _performance_quality_alias_map_v962(records: List[Dict[str, Any]]) -> Dict[str, Dict[str, Any]]:
    aliases={}
    for rec in records:
        if not isinstance(rec,dict):
            continue
        keys=[]
        event=str(rec.get('quality_event_key_v946') or '').strip()
        if event:
            keys.append(event)
        decision=str(rec.get('minimal_gate_decision_key_v925') or '').strip()
        candidate=str(rec.get('entry_build_key') or '').strip()
        if decision:
            keys.append('decision:'+decision.removeprefix('decision:'))
        if candidate:
            keys.append('candidate:'+candidate.removeprefix('candidate:'))
        for key in keys:
            if key and key not in aliases:
                aliases[key]=rec
    return aliases

def _performance_c_shadow_analysis_v962(index: Dict[str, Any], quality_records: List[Dict[str, Any]], cost_context: Dict[str, Any], structure: Dict[str, Any], closed: Dict[str, Any]) -> Dict[str, Any]:
    observations=index.get('observations') if isinstance(index,dict) and isinstance(index.get('observations'),dict) else {}
    quality_map=_performance_quality_alias_map_v962(quality_records)
    exact_rows=[]; s1_rows=[]; quality_joined=0; terminal_counts=Counter(); identity_modes=Counter()
    exact_identity_keys=set(); quality_joined_identities=set(); s1_identity_keys=set(); cost_connected_identities=set(); exchange_connected_identities=set(); terminal_seen_events=set()
    for obs in observations.values():
        if not isinstance(obs,dict):
            continue
        identity=str(obs.get('candidate_exact_identity') or '').strip()
        if not identity:
            continue
        exact_identity_keys.add(identity)
        quality_rec=quality_map.get(identity)
        if isinstance(quality_rec,dict):
            quality_joined+=1
            quality_joined_identities.add(identity)
            identity_modes[str(quality_rec.get('identity_mode_v946') or 'unknown')]+=1
        pct=_quality_optional_num(obs.get('pct'))
        if pct is None:
            continue
        price=_quality_optional_num(obs.get('entry_price')) or 0.0
        row={
            'event_key':obs.get('event_key'),'ticker':ticker_norm(obs.get('ticker')),'occurrence':obs.get('event_key'),
            'pct':pct,'max_pct':_quality_optional_num(obs.get('max_pct')),'min_pct':_quality_optional_num(obs.get('min_pct')),
            'giveback_pct':_quality_optional_num(obs.get('giveback_pct')),'first_seen_ts':_quality_optional_num(obs.get('event_ts')),
            'distortion':bool(_performance_tick_pct(price)>=0.50 or abs(pct)>=15.0),'horizon':str(obs.get('horizon') or ''),
            'reference_net_pct':None,'confirmed_net_pct':None,'spread_net_pct':pct,
        }
        exact_rows.append(row)
        terminal_event=str(obs.get('event_key') or '')
        if terminal_event not in terminal_seen_events:
            terminal_seen_events.add(terminal_event)
            terminal_counts[str(obs.get('first_terminal') or 'unknown')]+=1
        if isinstance(quality_rec,dict) and str(quality_rec.get('cohort') or '')=='s1_pass':
            s1_identity_keys.add(identity)
            metrics=quality_rec.get('initial_metrics') if isinstance(quality_rec.get('initial_metrics'),dict) else {}
            spread=_quality_optional_num(metrics.get('spread_pct')) or 0.0
            row=dict(row); row['spread_net_pct']=pct-spread
            cost_row,_mode=_performance_cost_for_record(quality_rec,cost_context)
            canonical_cost=_performance_canonical_cost_values(cost_row)
            if isinstance(cost_row,dict) and str(cost_row.get('measurement_state') or '')=='paper_reference_confirmed' and canonical_cost.get('ready'):
                usable=float(canonical_cost.get('cost') or 0.0)
                row['reference_net_pct']=pct-spread-usable; cost_connected_identities.add(identity)
            elif isinstance(cost_row,dict) and _performance_cost_state_rank(cost_row)>=40 and canonical_cost.get('ready'):
                usable=float(canonical_cost.get('cost') or 0.0)
                row['confirmed_net_pct']=pct-spread-max(0.0,usable); exchange_connected_identities.add(identity)
            s1_rows.append(row)
    def by_horizon(rows: List[Dict[str, Any]]) -> Dict[str, Any]:
        return {h:_performance_group_stats([r for r in rows if r.get('horizon')==h]) for h in PERFORMANCE_STRUCTURE_HORIZONS}
    exact_stats=by_horizon(exact_rows); s1_stats=by_horizon(s1_rows)
    c_all=structure.get('C_BREAK_RETEST') if isinstance(structure.get('C_BREAK_RETEST'),dict) else {}
    matched_closed=set(str(x) for x in (closed.get('matched_exact_keys') or []) if str(x))
    loss_analysis=_c_exact_closed_loss_analysis(exact_identity_keys, closed)
    closed_exact=int(loss_analysis.get('exact_closed_rows') or len(exact_identity_keys & matched_closed))
    checks={
        's1_10m_n_30':int((s1_stats.get('10m') or {}).get('clean_n') or 0)>=30,
        's1_60m_n_30':int((s1_stats.get('60m') or {}).get('clean_n') or 0)>=30,
        's1_240m_n_30':int((s1_stats.get('240m') or {}).get('clean_n') or 0)>=30,
        's1_10m_positive':((_performance_num_v962((s1_stats.get('10m') or {}).get('clean_avg_pct')) or -999)>0),
        's1_60m_positive':((_performance_num_v962((s1_stats.get('60m') or {}).get('clean_avg_pct')) or -999)>0),
        's1_240m_positive':((_performance_num_v962((s1_stats.get('240m') or {}).get('clean_avg_pct')) or -999)>0),
        'target_more_than_invalid':int(terminal_counts.get('target') or 0)>int(terminal_counts.get('invalid') or 0),
        'paper_reference_cost_n_30':len(cost_connected_identities)>=30,
        'exchange_cost_n_30':len(exchange_connected_identities)>=30,
        'exact_closed_n_30':closed_exact>=30,
        'user_approval':False,
    }
    return {
        'schema':'c_break_retest_shadow_status_v962','target_method':'C_BREAK_RETEST','label':'C 돌파 재확인',
        'state':'COLLECTING_EXACT_C_SHADOW','observation_only':True,'same_existing_gate_only':True,
        'legacy_all_c':c_all,'exact_structure_rows':len(exact_rows),'exact_identity_count':len(exact_identity_keys),
        'quality_joined_rows':quality_joined,'quality_joined_identity_count':len(quality_joined_identities),
        's1_pass_rows':len(s1_rows),'s1_pass_identity_count':len(s1_identity_keys),'identity_modes':dict(identity_modes),
        'exact_horizons':exact_stats,'s1_same_gate_horizons':s1_stats,'terminal_counts':dict(terminal_counts),
        'paper_reference_cost_rows':sum(1 for r in s1_rows if isinstance(r.get('reference_net_pct'),(int,float))),
        'paper_reference_cost_identity_count':len(cost_connected_identities),
        'exchange_confirmed_cost_rows':sum(1 for r in s1_rows if isinstance(r.get('confirmed_net_pct'),(int,float))),
        'exchange_confirmed_cost_identity_count':len(exchange_connected_identities),'exact_closed_rows':closed_exact,
        'closed_loss_analysis':loss_analysis,
        'readiness_checks':checks,'ready_for_rule_change':False,
        'blockers':[k for k,v in checks.items() if not v],
        'policy':'C only. Existing S1 gate/trigger/RR/target room/spread/freshness are unchanged; future exact C events are compared separately from legacy C aggregate; ticker/time-near join forbidden',
    }

def _performance_num_v962(value: Any) -> Optional[float]:
    try:
        if value in (None,'','-',[],{}):
            return None
        number=float(value)
        return number if math.isfinite(number) else None
    except Exception:
        return None

def _performance_shadow_candidates(structure: Dict[str, Any], quality: Dict[str, Any], late_path: Dict[str, Any], closed: Dict[str, Any]) -> Dict[str, Any]:
    items=[]
    blocked=quality.get('blocked_winners') if isinstance(quality.get('blocked_winners'),dict) else {}
    for cohort,data in blocked.items():
        ten=data.get('10m') if isinstance(data,dict) and isinstance(data.get('10m'),dict) else {}
        if int(ten.get('clean_n') or 0)>=30 and (ten.get('clean_avg_pct') is not None) and float(ten.get('clean_avg_pct'))>=0.15:
            items.append({'type':'relax_shadow_candidate','target':cohort,'evidence':ten,'ready':False,'blocker':'confirmed cost + exact CLOSED required'})
    passed=quality.get('passed_losers') if isinstance(quality.get('passed_losers'),dict) else {}
    s1=passed.get('s1_10m') if isinstance(passed.get('s1_10m'),dict) else {}
    if int(s1.get('clean_n') or 0)>=30 and s1.get('clean_avg_pct') is not None and float(s1.get('clean_avg_pct'))<=-0.10:
        items.append({'type':'strengthen_shadow_candidate','target':'s1_pass_entry_quality','evidence':s1,'ready':False,'blocker':'first exact CLOSED required'})
    outcome=late_path.get('outcome_comparison') if isinstance(late_path,dict) and isinstance(late_path.get('outcome_comparison'),dict) else {}
    for stage,stats in outcome.items():
        if not isinstance(stats,dict): continue
        fast=stats.get('fast') if isinstance(stats.get('fast'),dict) else {}; slow=stats.get('slow') if isinstance(stats.get('slow'),dict) else {}
        if int(fast.get('n') or 0)>=20 and int(slow.get('n') or 0)>=20 and fast.get('avg_pct') is not None and slow.get('avg_pct') is not None and float(slow.get('avg_pct'))<=float(fast.get('avg_pct'))-0.15:
            items.append({'type':'delay_shadow_candidate','target':stage,'evidence':stats,'ready':False,'blocker':'occurrence age/outlier audit + exact CLOSED required'})
    # Current experiment owner is fixed to C_BREAK_RETEST. Do not auto-switch to A/B/D/E by recent average.
    c_horizons=structure.get('C_BREAK_RETEST') if isinstance(structure.get('C_BREAK_RETEST'),dict) else {}
    c_sixty=c_horizons.get('60m') if isinstance(c_horizons.get('60m'),dict) else {}
    items.append({'type':'structure_method_shadow_candidate','target':'C_BREAK_RETEST','evidence':c_sixty,'ready':False,'blocker':'C exact cost + exact CLOSED + user approval required'})
    return {
        'candidates':items[:8],'ready_for_rule_change':False,
        'global_blockers':[
            'first exact CLOSED missing' if closed.get('state')!='ACTIVE' else None,
            'exchange-confirmed slippage missing' if not bool((quality.get('cost') or {}).get('exchange_confirmed_slippage_rows')) else None,
            'exact fee source missing',
            'user approval required',
        ],
        'policy':'suggest shadow experiments only; never auto-change S grade, trigger, entry, exit, protection or cost rules',
    }



def _v1053_refresh_c_shadow_closed_only(previous_c: Dict[str, Any], closed: Dict[str, Any]) -> Dict[str, Any]:
    """Refresh only exact CLOSED-dependent C-shadow fields from compact identity keys.

    The heavy structure horizon index does not change when Paper appends a CLOSED row.
    Keep the previously derived C observation set and update its exact CLOSED overlap only.
    """
    out=dict(previous_c) if isinstance(previous_c,dict) else {}
    keys={str(x) for x in (out.get('exact_identity_keys_v1053') or []) if str(x)}
    loss=_c_exact_closed_loss_analysis(keys,closed)
    out['closed_loss_analysis']=loss
    out['exact_closed_rows']=int(loss.get('exact_closed_rows') or 0)
    checks=dict(out.get('readiness_checks') or {})
    checks['exact_closed_n_30']=int(out.get('exact_closed_rows') or 0)>=30
    out['readiness_checks']=checks
    out['blockers']=[k for k,v in checks.items() if not v]
    out['closed_only_refresh_v1053']=True
    return out


def update_performance_lab(nowv: float, quality_records: List[Dict[str, Any]], quality_status: Dict[str, Any], late_path: Dict[str, Any], structure_lab: Dict[str, Any], structure_missed: Dict[str, Any]) -> Dict[str, Any]:
    """Refresh exact CLOSED immediately without rereading immutable 50MB derived indexes.

    v1053 splits canonical membership from execution-cost/derived observation changes.
    A new CLOSED row recalculates only CLOSED axes and C exact overlap. Structure, quality
    and C observation summaries remain the prior canonical derived snapshot until their
    own 300-second refresh or cost evidence change.
    """
    global _PERFORMANCE_STATUS_CACHE_V1011
    started=time.time()
    revision=int(quality_status.get('analysis_revision_v1009') or quality_status.get('analysis_revision_v1010') or 0) if isinstance(quality_status,dict) else 0
    canonical=load_json(CANONICAL_PERFORMANCE_V987,{}) or {}
    canonical_semantic=_canonical_performance_semantic_v1011(canonical,nowv)
    canonical_signature=hashlib.sha256(repr(canonical_semantic).encode('utf-8')).hexdigest()
    cost_sig=_file_size_signature_v1011(PAPER_EXECUTION_COST_LEDGER)
    cost_signature=hashlib.sha256(repr(cost_sig).encode('utf-8')).hexdigest()
    immediate_signature=hashlib.sha256(repr((canonical_semantic,cost_sig)).encode('utf-8')).hexdigest()

    if not _PERFORMANCE_STATUS_CACHE_V1011:
        previous=load_json(PERFORMANCE_LAB_STATUS,{}) or {}
        _PERFORMANCE_STATUS_CACHE_V1011=dict(previous) if isinstance(previous,dict) else {}
    previous=_PERFORMANCE_STATUS_CACHE_V1011
    previous_good=isinstance(previous,dict) and previous.get('state') not in ('ERROR','ERROR_COST_CONSUMER_DIVERGENCE')
    previous_calc=float(previous.get('full_calculated_at_v1011') or 0.0) if previous_good else 0.0
    derived_due=(not previous_good) or (nowv-previous_calc>=300.0)
    prev_canonical=str(previous.get('canonical_signature_v1053') or '')
    prev_cost=str(previous.get('cost_signature_v1053') or '')
    canonical_changed=(not previous_good) or prev_canonical!=canonical_signature
    cost_changed=(not previous_good) or prev_cost!=cost_signature

    if previous_good and canonical_changed and not cost_changed and not derived_due:
        closed=_performance_closed_analysis(canonical)
        structure=previous.get('structure_methods') if isinstance(previous.get('structure_methods'),dict) else {}
        quality=previous.get('quality') if isinstance(previous.get('quality'),dict) else {}
        c_shadow=_v1053_refresh_c_shadow_closed_only(previous.get('c_break_retest_shadow') if isinstance(previous.get('c_break_retest_shadow'),dict) else {},closed)
        shadow=_performance_shadow_candidates(structure,quality,late_path,closed)
        closed_public=dict(closed); closed_public.pop('_matched_rows_internal',None)
        status=dict(previous)
        status.update({
            'schema':'performance_lab_status_v1053_canonical_delta_recompute','version':VERSION,'build':BUILD_LABEL,
            'updated_ts':nowv,'updated_text':now_text(nowv),'cycle_sec':round(time.time()-started,3),
            'immediate_signature_v1012':immediate_signature,'canonical_signature_v1053':canonical_signature,'cost_signature_v1053':cost_signature,
            'canonical_semantic_signature_v1011':list(canonical_semantic),'cache_reused_v1011':True,'cache_reused_v1012':True,
            'canonical_only_recompute_v1053':True,'heavy_index_read_skipped_v1053':True,
            'recompute_reason_v1011':['canonical_exact_membership_changed_only'],
            'next_derived_refresh_in_sec_v1012':round(max(0.0,300.0-(nowv-previous_calc)),3),
            'closed_exact':closed_public,'c_break_retest_shadow':c_shadow,'shadow_candidates':shadow,
        })
        save_json(PERFORMANCE_LAB_STATUS,status)
        _PERFORMANCE_STATUS_CACHE_V1011=dict(status)
        return status

    recompute=bool((not previous_good) or cost_changed or derived_due)
    if not recompute and not canonical_changed:
        cached=dict(previous)
        cached['cache_reused_v1012']=True
        cached['cache_reused_v1011']=True
        cached['canonical_only_recompute_v1053']=False
        cached['heavy_index_read_skipped_v1053']=True
        cached['recompute_reason_v1011']='membership/cost unchanged; derived review refresh not due'
        cached['next_derived_refresh_in_sec_v1012']=round(max(0.0,300.0-(nowv-previous_calc)),3)
        cached['cycle_sec']=round(time.time()-started,3); cached['updated_ts']=nowv; cached['updated_text']=now_text(nowv)
        return cached

    reasons=[]
    if not previous_good: reasons.append('no_valid_previous_status')
    if cost_changed: reasons.append('execution_cost_evidence_changed')
    if derived_due: reasons.append('derived_review_300s_refresh_due')
    if canonical_changed: reasons.append('canonical_exact_membership_changed_with_full_refresh')
    index,index_io=_performance_refresh_structure_index(nowv)
    cost_context,cost_index_io=_performance_refresh_cost_index(nowv)
    c_shadow_index,c_shadow_index_io=_performance_refresh_c_shadow_index_v962(nowv)
    structure=_performance_structure_stats(index)
    quality=_performance_quality_analysis(quality_records,quality_status,cost_context)
    closed=_performance_closed_analysis(canonical)
    c_shadow=_performance_c_shadow_analysis_v962(c_shadow_index,quality_records,cost_context,structure,closed)
    # Persist a compact identity set so later CLOSED-only updates never reopen the large C index.
    observations=c_shadow_index.get('observations') if isinstance(c_shadow_index,dict) and isinstance(c_shadow_index.get('observations'),dict) else {}
    c_shadow['exact_identity_keys_v1053']=sorted({str(v.get('candidate_exact_identity') or '') for v in observations.values() if isinstance(v,dict) and str(v.get('candidate_exact_identity') or '')})
    c_shadow['closed_only_refresh_v1053']=False
    shadow=_performance_shadow_candidates(structure,quality,late_path,closed)
    closed_public=dict(closed); closed_public.pop('_matched_rows_internal',None)
    quality_cost=quality.get('cost') if isinstance(quality.get('cost'),dict) else {}
    overall_numeric=int(quality_cost.get('paper_reference_numeric_rows') or 0); c_numeric=int(c_shadow.get('paper_reference_cost_rows') or 0); connected=int(quality_cost.get('paper_reference_connected_rows') or 0)
    contradiction=bool((connected>0 and overall_numeric==0) or (c_numeric>0 and overall_numeric==0))
    state='ERROR_COST_CONSUMER_DIVERGENCE' if contradiction or int(cost_index_io.get('numeric_contract_errors') or 0)>0 else 'ACTIVE'
    if contradiction: append_error(ERROR,'v968_cost_consumer_divergence',RuntimeError(f'connected={connected} overall_numeric={overall_numeric} c_numeric={c_numeric}'))
    derived_signature=hashlib.sha256(repr((revision,_file_size_signature_v1011(STRUCTURE_LAB_HORIZON_LEDGER))).encode('utf-8')).hexdigest()
    status={
        'schema':'performance_lab_status_v1053_canonical_delta_recompute','version':VERSION,'build':BUILD_LABEL,'state':state,
        'updated_ts':nowv,'updated_text':now_text(nowv),'cycle_sec':round(time.time()-started,3),
        'immediate_signature_v1012':immediate_signature,'canonical_signature_v1053':canonical_signature,'cost_signature_v1053':cost_signature,
        'derived_signature_v1012':derived_signature,'canonical_semantic_signature_v1011':list(canonical_semantic),'full_calculated_at_v1011':nowv,
        'quality_revision_v1010':revision,'cache_reused_v1011':False,'cache_reused_v1012':False,'canonical_only_recompute_v1053':False,
        'heavy_index_read_skipped_v1053':False,'recompute_reason_v1011':reasons,'derived_refresh_interval_sec_v1012':300.0,
        'structure_index_io':index_io,'cost_index_io':cost_index_io,'c_shadow_index_io':c_shadow_index_io,
        'performance_index_memory_cache_v1079':dict(_PERFORMANCE_INDEX_MEMORY_STATS_V1079),
        'structure_methods':structure,'quality':quality,'c_break_retest_shadow':c_shadow,
        'delay':{'stages':late_path.get('stages',{}) if isinstance(late_path,dict) else {},'paper_execution':late_path.get('paper_stages',{}) if isinstance(late_path,dict) else {},'outcome_comparison':late_path.get('outcome_quartiles_10m',{}) if isinstance(late_path,dict) else {},'source_schema':late_path.get('schema') if isinstance(late_path,dict) else None,'source_state':late_path.get('state') if isinstance(late_path,dict) else None,'occurrence_normalized_records':late_path.get('occurrence_normalized_records',0) if isinstance(late_path,dict) else 0},
        'closed_exact':closed_public,'shadow_candidates':shadow,
        'cost_consistency_v967':{'connected_rows':connected,'overall_numeric_rows':overall_numeric,'c_shadow_numeric_rows':c_numeric,'contradiction':contradiction,'consumer':'_performance_canonical_cost_values','numeric_contract_errors':int(cost_index_io.get('numeric_contract_errors') or 0),'source_priority':'exact canonical cost before legacy row-local slippage'},
        'source_state':{'structure_snapshot':structure_lab.get('source_snapshot_state') if isinstance(structure_lab,dict) else None,'structure_analysis_ready_rows':structure_lab.get('source_analysis_ready_rows') if isinstance(structure_lab,dict) else None,'missed_tracked':((structure_missed.get('stats') or {}).get('tracked') if isinstance(structure_missed,dict) else None)},
        'locks':{'trading_rules_changed':False,'s_grades_changed':False,'trigger_changed':False,'entry_changed':False,'exit_changed':False,'cost_rules_changed':False,'auto_buy':False},
        'policy':'canonical CLOSED delta refreshes only CLOSED axes; heavy derived indexes refresh on own cost/300s schedule; main read-only',
    }
    save_json(PERFORMANCE_LAB_STATUS,status)
    _PERFORMANCE_STATUS_CACHE_V1011=dict(status)
    return status




# =============================================================================
# v1034 profitability exact replay diagnostic
# - Review owns one derived diagnostic snapshot from Paper canonical exact rows.
# - Historical values are never guessed: exact/reconstructed/unavailable are split.
# - No entry/exit/gate threshold is changed here.
# =============================================================================

def _pa_num(value: Any, default: Optional[float]=None) -> Optional[float]:
    try:
        if value in (None,'','-'): return default
        out=float(str(value).replace(',',''))
        return out if math.isfinite(out) else default
    except Exception:
        return default

def _pa_bool(value: Any) -> Optional[bool]:
    if value is None: return None
    if isinstance(value,bool): return value
    if isinstance(value,(int,float)): return bool(value)
    text=str(value).strip().lower()
    if text in ('true','1','yes','y','on'): return True
    if text in ('false','0','no','n','off'): return False
    return None

def _pa_stats(rows: List[Dict[str,Any]]) -> Dict[str,Any]:
    vals=[_pa_num(r.get('pnl_pct')) for r in rows]
    vals=[v for v in vals if v is not None]
    wins=sum(1 for v in vals if v>0)
    return {'n':len(vals),'wins':wins,'losses':len(vals)-wins,'win_rate_pct':round(100*wins/len(vals),2) if vals else None,'sum_pnl_pct':round(sum(vals),4) if vals else 0.0,'avg_pnl_pct':round(sum(vals)/len(vals),4) if vals else None,'avg_mfe_pct':round(sum(v for v in (_pa_num(r.get('mfe_pct')) for r in rows) if v is not None)/max(1,sum(1 for r in rows if _pa_num(r.get('mfe_pct')) is not None)),4) if rows else None}

def _pa_group(rows: List[Dict[str,Any]], key_fn, order: Optional[List[str]]=None) -> List[Dict[str,Any]]:
    groups: Dict[str,List[Dict[str,Any]]]={}
    for row in rows:
        key=str(key_fn(row) or 'missing')
        groups.setdefault(key,[]).append(row)
    keys=order or sorted(groups)
    out=[]
    for key in keys:
        if key in groups:
            out.append({'bucket':key,**_pa_stats(groups[key])})
    for key in groups:
        if key not in keys:
            out.append({'bucket':key,**_pa_stats(groups[key])})
    return out

def _pa_release_num(row: Dict[str,Any]) -> Optional[int]:
    import re
    text=' '.join(str(row.get(k) or '') for k in ('paper_build_label','entry_build_key','opened_paper_version'))
    nums=[int(x) for x in re.findall(r'(?<![0-9])v(\d{3,4})(?![0-9])',text)]
    return max(nums) if nums else None

def _pa_version_cohorts(rows: List[Dict[str,Any]]) -> Dict[str,Any]:
    by_release=_pa_group(rows,lambda r: f"v{_pa_release_num(r)}" if _pa_release_num(r) is not None else 'release_missing')
    ordered=sorted(rows,key=lambda r:(_pa_num(r.get('opened_at'),0.0) or 0.0,str(r.get('decision_key') or '')))
    seq=[]
    for idx in range(0,len(ordered),25):
        chunk=ordered[idx:idx+25]
        seq.append({'bucket':f'{idx+1}-{idx+len(chunk)}','start_opened_at':chunk[0].get('opened_at') if chunk else None,'end_opened_at':chunk[-1].get('opened_at') if chunk else None,**_pa_stats(chunk)})
    pivots=[]
    for label,pred in [
        ('pre_v981_or_missing',lambda r: _pa_release_num(r) is None or _pa_release_num(r)<981),
        ('v981_v982_writer_restored',lambda r: _pa_release_num(r) is not None and 981<=_pa_release_num(r)<=982),
        ('v983_plus_trailing_removed',lambda r: _pa_release_num(r) is not None and _pa_release_num(r)>=983),
    ]:
        part=[r for r in rows if pred(r)]
        pivots.append({'bucket':label,**_pa_stats(part)})
    early=[]
    for cut in (10,25,50,100):
        if ordered:
            early.append({'bucket':f'first_{cut}',**_pa_stats(ordered[:cut])})
            early.append({'bucket':f'after_{cut}',**_pa_stats(ordered[cut:])})
    rolling=[]
    if len(ordered)>=25:
        for i in range(0,len(ordered)-24):
            chunk=ordered[i:i+25]; st=_pa_stats(chunk); rolling.append({'start_index':i+1,'end_index':i+25,**st})
    best=max(rolling,key=lambda x:x.get('sum_pnl_pct',-1e99)) if rolling else None
    worst=min(rolling,key=lambda x:x.get('sum_pnl_pct',1e99)) if rolling else None
    by_day=_pa_group(rows,lambda r: time.strftime('%Y-%m-%d',time.localtime(_pa_num(r.get('closed_at'),0) or 0)))
    return {'by_release':by_release,'by_day':by_day,'sequence_25':seq,'early_vs_later':early,'rolling25_best':best,'rolling25_worst':worst,'known_code_pivots':pivots,'interpretation':'v981 is writer restoration, not trigger relaxation; v983+ active swing trailing removed. Cohorts are evidence, not causation proof.'}

def _pa_trailing(rows: List[Dict[str,Any]]) -> Dict[str,Any]:
    scenarios=[]
    for trigger,giveback in ((1.0,0.5),(1.5,0.6),(2.0,0.8),(2.5,1.0),(3.0,1.2)):
        eligible=[]; path_consistent=[]; exact=[]
        model_deltas=[]
        for r in rows:
            peak=_pa_num(r.get('mfe_pct')); final=_pa_num(r.get('pnl_pct'))
            sh=r.get('shadow_trailing_v1034') if isinstance(r.get('shadow_trailing_v1034'),dict) else {}
            if abs(trigger-2.0)<1e-9 and abs(giveback-0.8)<1e-9 and sh.get('triggered'):
                exact.append(r)
            if peak is None or final is None or peak<trigger: continue
            eligible.append(r)
            nominal=max(0.0,peak-giveback)
            if final <= nominal and nominal>0:
                path_consistent.append(r)
                model_deltas.append(nominal-final)
        scenarios.append({'trigger_pct':trigger,'giveback_pct':giveback,'eligible_peak_count':len(eligible),'path_consistent_protection_count':len(path_consistent),'exact_forward_trigger_count':len(exact),'historical_exact_exit_count':0,'nominal_model_sum_improvement_pct':round(sum(model_deltas),4),'nominal_model_avg_improvement_pct':round(sum(model_deltas)/len(model_deltas),4) if model_deltas else None,'evidence_state':'exact_forward_only; historical path-consistent model from sealed MFE/final, not an exact exit replay'})
    positive_then_loss=[r for r in rows if (_pa_num(r.get('mfe_pct'),0) or 0)>0 and (_pa_num(r.get('pnl_pct'),0) or 0)<=0]
    def mfe_bucket(r):
        v=_pa_num(r.get('mfe_pct'))
        if v is None:return 'missing'
        if v<=0:return '<=0'
        if v<0.5:return '0-0.49'
        if v<1:return '0.5-0.99'
        if v<2:return '1.0-1.99'
        if v<3:return '2.0-2.99'
        return '>=3.0'
    def touch_order(r):
        tt=_pa_num(r.get('target_first_touch_ts')); it=_pa_num(r.get('invalid_first_touch_ts'))
        if tt is not None and it is not None:return 'target_first' if tt<=it else 'invalid_first'
        if tt is not None:return 'target_only'
        if it is not None:return 'invalid_only'
        return 'missing'
    return {'scenarios':scenarios,'positive_mfe_then_loss':_pa_stats(positive_then_loss),'exit_reason':_pa_group(rows,lambda r:r.get('exit_reason') or 'missing'),'mfe_buckets':_pa_group(rows,mfe_bucket,['<=0','0-0.49','0.5-0.99','1.0-1.99','2.0-2.99','>=3.0','missing']),'target_invalid_touch_order':_pa_group(rows,touch_order,['target_first','invalid_first','target_only','invalid_only','missing']),'historical_limit':'CLOSED seals MFE/final but not every intermediate tick; historical exit time/price cannot be exact. v1034 forward shadow seals first trigger event without changing exit.'}

def _pa_actual_rr(rows: List[Dict[str,Any]]) -> Dict[str,Any]:
    usable=[]; missing=[]; contract_leak=[]
    for r in rows:
        actual=_pa_num(r.get('actual_entry_rr'))
        if actual is None:
            entry=_pa_num(r.get('entry_price')); target=_pa_num((r.get('target') or {}).get('price') if isinstance(r.get('target'),dict) else None); invalid=_pa_num((r.get('invalid') or {}).get('price') if isinstance(r.get('invalid'),dict) else None)
            if entry is not None and target is not None and invalid is not None and target>entry>invalid:
                actual=(target-entry)/(entry-invalid); r=dict(r); r['_pa_actual_rr']=actual
            else:
                missing.append(r); continue
        else:
            r=dict(r); r['_pa_actual_rr']=actual
        usable.append(r)
        trigger=_pa_num(r.get('trigger_rr'))
        if trigger is not None and trigger>=1.5 and actual<1.5: contract_leak.append(r)
    def bucket(r):
        v=_pa_num(r.get('_pa_actual_rr'),_pa_num(r.get('actual_entry_rr')))
        if v is None:return 'missing'
        if v<1:return '<1.0'
        if v<1.5:return '1.0-1.49'
        if v<2:return '1.5-1.99'
        return '>=2.0'
    def geom(r,kind):
        entry=_pa_num(r.get('entry_price')); line=r.get(kind) if isinstance(r.get(kind),dict) else {}; price=_pa_num(line.get('price'))
        if entry is None or price is None or entry<=0:return None
        return ((price-entry)/entry*100.0) if kind=='target' else ((entry-price)/entry*100.0)
    def pct_bucket(v):
        if v is None:return 'missing'
        if v<1:return '<1%'
        if v<2:return '1-1.99%'
        if v<3:return '2-2.99%'
        if v<5:return '3-4.99%'
        if v<10:return '5-9.99%'
        return '>=10%'
    target_rows=[]; invalid_rows=[]
    for r in rows:
        a=dict(r); a['_pa_geom']=geom(r,'target'); target_rows.append(a)
        b=dict(r); b['_pa_geom']=geom(r,'invalid'); invalid_rows.append(b)
    chase=[]
    for r in rows:
        x=dict(r); x['_pa_chase']=_pa_num(r.get('trigger_chase_pct')); chase.append(x)
    def chase_bucket(r):
        v=_pa_num(r.get('_pa_chase'))
        if v is None:return 'missing'
        if v<=0:return '<=0'
        if v<=0.2:return '0-0.2%'
        if v<=0.4:return '0.2-0.4%'
        if v<=0.6:return '0.4-0.6%'
        return '>0.6%'
    return {'usable':len(usable),'missing':len(missing),'buckets':_pa_group(usable,bucket,['<1.0','1.0-1.49','1.5-1.99','>=2.0']),'trigger_pass_actual_fail':_pa_stats(contract_leak),'target_distance_buckets':_pa_group(target_rows,lambda r:pct_bucket(_pa_num(r.get('_pa_geom'))),['<1%','1-1.99%','2-2.99%','3-4.99%','5-9.99%','>=10%','missing']),'invalid_distance_buckets':_pa_group(invalid_rows,lambda r:pct_bucket(_pa_num(r.get('_pa_geom'))),['<1%','1-1.99%','2-2.99%','3-4.99%','5-9.99%','>=10%','missing']),'trigger_chase_buckets':_pa_group(chase,chase_bucket,['<=0','0-0.2%','0.2-0.4%','0.4-0.6%','>0.6%','missing']),'source':'sealed entry/invalid/target reconstruction or forward actual_entry_rr seal'}

def _pa_repeat(rows: List[Dict[str,Any]]) -> Dict[str,Any]:
    by_ticker: Dict[str,List[Dict[str,Any]]]={}
    for r in rows: by_ticker.setdefault(str(r.get('ticker') or '-'),[]).append(r)
    events=[]
    for ticker,items in by_ticker.items():
        items.sort(key=lambda r:(_pa_num(r.get('opened_at'),0) or 0))
        for prev,cur in zip(items,items[1:]):
            gap=(_pa_num(cur.get('opened_at')) or 0)-(_pa_num(prev.get('closed_at')) or 0)
            if gap<0: gap=0
            x=dict(cur); x['_pa_gap']=gap; x['_pa_prior_loss']=(_pa_num(prev.get('pnl_pct'),0) or 0)<=0; x['_pa_same_plan']=bool(prev.get('trigger_frozen_ts') and prev.get('trigger_frozen_ts')==cur.get('trigger_frozen_ts')); events.append(x)
    def bucket(r):
        g=_pa_num(r.get('_pa_gap'),0) or 0
        if g<=300:return '<=5m'
        if g<=1800:return '5-30m'
        if g<=7200:return '30m-2h'
        if g<=21600:return '2-6h'
        if g<=86400:return '6-24h'
        return '>24h'
    prior_loss=[r for r in events if r.get('_pa_prior_loss')]
    quick_loss=[r for r in prior_loss if (_pa_num(r.get('_pa_gap'),1e99) or 1e99)<=21600]
    return {'repeat_events':len(events),'buckets':_pa_group(events,bucket,['<=5m','5-30m','30m-2h','2-6h','6-24h','>24h']),'after_prior_loss':_pa_stats(prior_loss),'after_prior_loss_within_6h':_pa_stats(quick_loss),'same_frozen_plan':_pa_stats([r for r in events if r.get('_pa_same_plan')]),'hot_rank_repeat':_pa_stats([r for r in events if r.get('hot_rank_lane')]),'source':'exact OPEN/CLOSED timestamps and ticker; current OPEN not used in historical outcome'}

def _pa_quality(rows: List[Dict[str,Any]]) -> Dict[str,Any]:
    specs={
      'price_reaction_pct':([-1e99,0,0.1,0.35,1e99],['<0','0-0.09','0.10-0.34','>=0.35']),
      'buy_ratio':([-1e99,0.45,0.70,0.78,1e99],['<0.45','0.45-0.69','0.70-0.77','>=0.78']),
      'buy_sustain_1m':([-1e99,0.45,0.70,0.78,1e99],['<0.45','0.45-0.69','0.70-0.77','>=0.78']),
      'relative_strength':([-1e99,0,0.3,1e99],['<0','0-0.29','>=0.30']),
      'spread_pct':([-1e99,0.18,0.35,0.85,1e99],['<=0.18','0.19-0.35','0.36-0.85','>0.85']),
    }
    out={}; completeness={}
    for field,(cuts,labels) in specs.items():
        have=[r for r in rows if _pa_num(r.get(field)) is not None]; completeness[field]={'have':len(have),'missing':len(rows)-len(have)}
        def bf(r,field=field,cuts=cuts,labels=labels):
            v=_pa_num(r.get(field))
            if v is None:return 'missing'
            for i,label in enumerate(labels):
                lo,hi=cuts[i],cuts[i+1]
                if (i==len(labels)-1 and v>=lo) or (lo<=v<hi): return label
            return labels[-1]
        out[field]=_pa_group(rows,bf,labels+['missing'])
    out['late_risk_audit']=_pa_group(rows,lambda r:'true' if _pa_bool(r.get('quality_late_risk_audit')) is True else ('false' if _pa_bool(r.get('quality_late_risk_audit')) is False else 'missing'),['true','false','missing'])
    return {'completeness':completeness,'buckets':out,'note':'quality values remain diagnostic-only in v1034'}

def _pa_lane_risk(rows: List[Dict[str,Any]], repeat: Dict[str,Any]) -> Dict[str,Any]:
    hot=[r for r in rows if r.get('hot_rank_lane') or 'hot-rank' in str(r.get('entry_method') or '').lower()]
    base=[r for r in rows if r not in hot]
    cd_exact=[r for r in rows if _pa_bool(r.get('risk_cooldown_at_open')) is True]
    cd_missing=[r for r in rows if _pa_bool(r.get('risk_cooldown_at_open')) is None]
    late=[r for r in rows if _pa_bool(r.get('quality_late_risk_audit')) is True]
    return {'hot_rank':_pa_stats(hot),'non_hot_rank':_pa_stats(base),'risk_cooldown_exact':_pa_stats(cd_exact),'risk_cooldown_missing':len(cd_missing),'late_risk_true':_pa_stats(late),'code_audit':'hot-rank lane bypasses common risk/cooldown; v1034 records exact forward evidence but does not change selection'}

def _pa_concurrency(rows: List[Dict[str,Any]]) -> Dict[str,Any]:
    clean=[r for r in rows if _pa_num(r.get('opened_at')) is not None and _pa_num(r.get('closed_at')) is not None]
    enriched=[]
    for cur in clean:
        t=_pa_num(cur.get('opened_at')) or 0
        n=sum(1 for other in clean if (_pa_num(other.get('opened_at')) or 0)<=t<(_pa_num(other.get('closed_at')) or 0) and other is not cur)
        x=dict(cur); x['_pa_concurrent']=n; enriched.append(x)
    def b(r):
        n=int(_pa_num(r.get('_pa_concurrent'),0) or 0)
        if n<5:return '0-4'
        if n<10:return '5-9'
        if n<20:return '10-19'
        if n<50:return '20-49'
        return '50+'
    exact_forward=[r for r in rows if _pa_num(r.get('open_count_before')) is not None]
    return {'historical_lower_bound_buckets':_pa_group(enriched,b,['0-4','5-9','10-19','20-49','50+']),'forward_exact_open_count_rows':len(exact_forward),'historical_limit':'Only exact CLOSED membership is available, so historical concurrency is a lower bound. v1034 seals exact open_count_before forward.'}

def _pa_frozen(rows: List[Dict[str,Any]]) -> Dict[str,Any]:
    def b(r):
        a=_pa_num(r.get('frozen_plan_age_sec'))
        if a is None:return 'missing'
        if a<300:return '<5m'
        if a<1800:return '5-30m'
        if a<7200:return '30m-2h'
        if a<43200:return '2-12h'
        if a<172800:return '12-48h'
        return '>=48h'
    return {'age_buckets':_pa_group(rows,b,['<5m','5-30m','30m-2h','2-12h','12-48h','>=48h','missing']),'source_move_detected':_pa_stats([r for r in rows if _pa_bool(r.get('source_plan_move_detected')) is True]),'frozen_plan_held':_pa_stats([r for r in rows if _pa_bool(r.get('frozen_plan_held')) is True]),'missing_age':sum(1 for r in rows if _pa_num(r.get('frozen_plan_age_sec')) is None)}

def _pa_market(rows: List[Dict[str,Any]]) -> Dict[str,Any]:
    sealed=[r for r in rows if str(r.get('market_regime_evidence_state') or '')=='sealed_exact_v1034']
    legacy=[r for r in rows if r.get('market_mode_at_open') and r not in sealed]
    missing=[r for r in rows if not r.get('market_mode_at_open')]
    return {'sealed_exact':len(sealed),'legacy_context':len(legacy),'missing':len(missing),'by_mode':_pa_group([r for r in rows if r.get('market_mode_at_open')],lambda r:r.get('market_mode_at_open')),'historical_limit':'Past market regime is not backfilled from current data. v1034 Paper seals market worker snapshot at OPEN forward.'}

def _pa_open_rows(obj: Any) -> List[Dict[str,Any]]:
    if isinstance(obj,list): return [dict(r) for r in obj if isinstance(r,dict)]
    if isinstance(obj,dict):
        for key in ('positions','open','rows','items'):
            if isinstance(obj.get(key),list): return [dict(r) for r in obj[key] if isinstance(r,dict)]
        vals=[dict(v) for v in obj.values() if isinstance(v,dict) and (v.get('ticker') or v.get('symbol'))]
        if vals:return vals
    return []

def _pa_current_open(open_rows: List[Dict[str,Any]]) -> Dict[str,Any]:
    normalized=[]
    for r in open_rows:
        entry=_pa_num(r.get('entry_price')); target=_pa_num(r.get('swing_target_price_v977'),_pa_num(r.get('target_price'))); invalid=_pa_num(r.get('swing_invalid_price_v977'),_pa_num(r.get('invalid_price'))); actual=None
        pe=r.get('profitability_entry_evidence_v1034') if isinstance(r.get('profitability_entry_evidence_v1034'),dict) else {}
        actual=_pa_num(pe.get('actual_entry_rr'),_pa_num(r.get('actual_entry_rr_v1034')))
        if actual is None and entry is not None and target is not None and invalid is not None and target>entry>invalid: actual=(target-entry)/(entry-invalid)
        x={'ticker':r.get('ticker') or r.get('symbol'),'entry_price':entry,'actual_entry_rr':actual,'current_pnl_pct':_pa_num(r.get('profit_pct'),_pa_num(r.get('current_profit_pct'),_pa_num(r.get('pnl_pct')))),'mfe_pct':_pa_num(r.get('max_profit_pct'),_pa_num(r.get('mfe_pct'))),'mae_pct':_pa_num(r.get('min_profit_pct'),_pa_num(r.get('mae_pct'))),'opened_at':_pa_num(r.get('opened_at'),_pa_num(r.get('entry_ts'))),'hot_rank_lane':bool(pe.get('hot_rank_lane')) if pe else ('hot-rank' in str(r.get('strategy') or '').lower()),'risk_cooldown_at_open':(pe.get('risk') or {}).get('cooldown_active') if isinstance(pe.get('risk'),dict) else None,'market_mode_at_open':(pe.get('market_regime') or {}).get('mode') if isinstance(pe.get('market_regime'),dict) else None,'shadow_triggered':bool((r.get('profitability_shadow_trailing_v1034') or {}).get('triggered')) if isinstance(r.get('profitability_shadow_trailing_v1034'),dict) else False}
        normalized.append(x)
    return {'count':len(normalized),'actual_rr_below_1_5':sum(1 for r in normalized if r.get('actual_entry_rr') is not None and r['actual_entry_rr']<1.5),'actual_rr_missing':sum(1 for r in normalized if r.get('actual_entry_rr') is None),'hot_rank_count':sum(1 for r in normalized if r.get('hot_rank_lane')),'risk_cooldown_exact_count':sum(1 for r in normalized if r.get('risk_cooldown_at_open') is True),'market_exact_count':sum(1 for r in normalized if r.get('market_mode_at_open')),'shadow_trailing_triggered':sum(1 for r in normalized if r.get('shadow_triggered')),'positive_mfe_now_count':sum(1 for r in normalized if (_pa_num(r.get('mfe_pct'),0) or 0)>0),'sample':sorted(normalized,key=lambda r:((r.get('actual_entry_rr') is None),r.get('actual_entry_rr') if r.get('actual_entry_rr') is not None else 999, r.get('current_pnl_pct') if r.get('current_pnl_pct') is not None else 0))[:20]}

def _profitability_closed_semantic_v1050(snapshot: Dict[str,Any], rows: List[Dict[str,Any]]) -> tuple[Any, ...]:
    counts=snapshot.get('counts') if isinstance(snapshot.get('counts'),dict) else {}
    return (
        str(snapshot.get('membership_digest') or ''),
        str(snapshot.get('source_digest') or ''),
        int(counts.get('exact_unique_closed') or len(rows)),
        int(counts.get('duplicate_closed_rows') or 0),
        int(counts.get('missing_decision_key') or 0),
        int(counts.get('decision_not_closed_or_missing') or 0),
    )

def update_profitability_diagnostic_v1034(nowv: float, canonical_snapshot: Dict[str,Any], closed_rows: List[Dict[str,Any]]) -> Dict[str,Any]:
    global _PROFITABILITY_CLOSED_AXES_CACHE_V1050, _PROFITABILITY_CLOSED_SEMANTIC_V1050
    global _PROFITABILITY_CLOSED_RECOMPUTE_COUNT_V1050
    rows=[r for r in closed_rows if isinstance(r,dict)]
    closed_semantic=_profitability_closed_semantic_v1050(canonical_snapshot,rows)
    closed_recomputed=closed_semantic!=_PROFITABILITY_CLOSED_SEMANTIC_V1050 or not _PROFITABILITY_CLOSED_AXES_CACHE_V1050
    if closed_recomputed:
        repeat=_pa_repeat(rows)
        _PROFITABILITY_CLOSED_AXES_CACHE_V1050={
          'version_pivots':_pa_version_cohorts(rows),
          'trailing_replay':_pa_trailing(rows),
          'actual_entry_rr':_pa_actual_rr(rows),
          'repeat_reentry':repeat,
          'quality_observation':_pa_quality(rows),
          'lane_and_risk_bypass':_pa_lane_risk(rows,repeat),
          'concurrent_open_exposure':_pa_concurrency(rows),
          'frozen_plan':_pa_frozen(rows),
          'market_regime':_pa_market(rows),
        }
        _PROFITABILITY_CLOSED_SEMANTIC_V1050=closed_semantic
        _PROFITABILITY_CLOSED_RECOMPUTE_COUNT_V1050+=1
    axes=_PROFITABILITY_CLOSED_AXES_CACHE_V1050
    open_obj=load_json(OPEN,{}) or {}
    open_rows=_pa_open_rows(open_obj)
    current_open_risk=_pa_current_open(open_rows)
    result={
      'schema':'profitability_diagnostic_snapshot_v1050_closed_axes_cached','version':VERSION,'build':BUILD_LABEL,'state':'ACTIVE' if rows else 'WAITING_EXACT_ROWS','updated_ts':nowv,'updated_text':now_text(nowv),
      'source':{'owner':'review_worker.update_profitability_diagnostic_v1034','canonical_performance_owner':canonical_snapshot.get('owner'),'snapshot_id':canonical_snapshot.get('snapshot_id'),'source_digest':canonical_snapshot.get('source_digest'),'membership_digest':canonical_snapshot.get('membership_digest'),'exact_closed':len(rows),'current_open':len(open_rows),'raw_count':canonical_snapshot.get('raw_count'),'duplicate_count':canonical_snapshot.get('duplicate_count'),'missing_key_count':canonical_snapshot.get('missing_key_count'),'unlinked_count':canonical_snapshot.get('unlinked_count')},
      **axes,
      'current_open_risk':current_open_risk,
      'system_cleanup_v1050':{'closed_axes_cache_reused':not closed_recomputed,'closed_axes_recomputed':closed_recomputed,'closed_axes_recompute_count':_PROFITABILITY_CLOSED_RECOMPUTE_COUNT_V1050,'closed_semantic':list(closed_semantic),'canonical_rows_copied':False,'open_risk_live_recomputed':True},
      'locks':{'auto_buy':False,'entry_rule_changed':False,'exit_rule_changed':False,'threshold_changed':False,'ledger_rewritten':False,'historical_market_backfill':False},
      'evidence_contract':{'exact':'decision-key canonical CLOSED and forward Paper OPEN seals','reconstructed':'actual RR from sealed entry/invalid/target; concurrency lower bound; repeat interval from exact timestamps','model_only':'historical trailing path-consistent model','unavailable':'historical exact trailing touch time and historical market/cooldown when not sealed'},
    }
    completeness={
      'actual_rr_have':result['actual_entry_rr']['usable'],'actual_rr_missing':result['actual_entry_rr']['missing'],
      'market_have':result['market_regime']['sealed_exact']+result['market_regime']['legacy_context'],'market_missing':result['market_regime']['missing'],
      'risk_cooldown_exact_have':len(rows)-result['lane_and_risk_bypass']['risk_cooldown_missing'],'risk_cooldown_missing':result['lane_and_risk_bypass']['risk_cooldown_missing'],
      'frozen_age_missing':result['frozen_plan']['missing_age'],
    }
    result['data_completeness']=completeness
    digest=hashlib.sha256(json.dumps(result,ensure_ascii=False,sort_keys=True,default=str,separators=(',',':')).encode()).hexdigest()
    result['diagnostic_digest']=digest
    save_json(PROFITABILITY_DIAGNOSTIC_V1034,result)
    status={'schema':'profitability_diagnostic_status_v1050_closed_axes_cached','version':VERSION,'build':BUILD_LABEL,'state':result['state'],'updated_ts':nowv,'snapshot_file':PROFITABILITY_DIAGNOSTIC_V1034.name,'diagnostic_digest':digest,'exact_closed':len(rows),'current_open':len(open_rows),'axes':10,'data_completeness':completeness,'closed_axes_cache_reused_v1050':not closed_recomputed,'closed_axes_recomputed_v1050':closed_recomputed,'closed_axes_recompute_count_v1050':_PROFITABILITY_CLOSED_RECOMPUTE_COUNT_V1050,'canonical_rows_copied_v1050':False,'trading_rules_changed':False,'auto_buy':False}
    save_json(PROFITABILITY_DIAGNOSTIC_STATUS_V1034,status)
    return status


# =============================================================================
# review_worker v0.991 / v1050 system cleanup; v1035 early audit retained unchanged
# - Reads preserved raw CLOSED/trade/close-alert and targeted historical score artifacts.
# - Never inserts legacy rows into canonical performance and never rewrites a ledger.
# - Separates exact, legacy raw, score-display and unavailable evidence.
# =============================================================================
import datetime as _er_dt
import re as _er_re

_ER_ALT_SWING_CUTOVER_TS_V1035 = 1782093476.0
_ER_KST_V1035 = _er_dt.timezone(_er_dt.timedelta(hours=9))
_ER_ARTIFACT_MAX_FILES_V1035 = 600
_ER_ARTIFACT_MAX_READ_BYTES_V1035 = 4 * 1024 * 1024
_ER_ARTIFACT_TOTAL_READ_BYTES_V1035 = 96 * 1024 * 1024
_ER_CODE_TIMELINE_V1035 = [
    {'version':'pre-v977','source_available':False,'note':'현재 제공된 코드 묶음에는 v977 이전 source가 없음. 서버 원장·score/cache·알림 흔적으로만 복원.'},
    {'version':'v977','source_available':True,'note':'ALT_SWING 시작. +2.0%/0.8% 수익보호 active, 품질 관찰전용, OPEN 한도 0=무제한.'},
    {'version':'v981','source_available':True,'note':'OPEN writer 복구. trigger 완화가 아니라 막힌 기존 계약의 실제 실행량 증가.'},
    {'version':'v983','source_available':True,'note':'active swing_trailing 제거.'},
    {'version':'v987','source_available':True,'note':'canonical exact 성과 writer 도입. 과거 raw 전체가 아니라 OPEN-time ALT_SWING + CLOSED decision exact만 본선.'},
]

def _er_num_v1035(value: Any, default: Optional[float]=None) -> Optional[float]:
    if value in (None,'',[],{}): return default
    try:
        x=float(value)
        if math.isfinite(x): return x
    except Exception:
        pass
    return default

def _er_first_num_v1035(row: Dict[str,Any], keys: tuple[str,...]) -> Optional[float]:
    for key in keys:
        val=_er_num_v1035(row.get(key))
        if val is not None: return val
    for subkey in ('closed_evidence','open_evidence','canonical_entry_snapshot','entry_snapshot','trade','result'):
        sub=row.get(subkey)
        if isinstance(sub,dict):
            for key in keys:
                val=_er_num_v1035(sub.get(key))
                if val is not None: return val
    return None

def _er_ts_v1035(row: Dict[str,Any], opened: bool=False) -> float:
    keys=(('opened_at','entry_ts','open_ts','opened_ts','entry_time','created_at') if opened else ('closed_at','closed_ts','exit_ts','exited_at','exit_time','timestamp','ts','updated_at'))
    val=_er_first_num_v1035(row,keys)
    if val is not None and val>0:
        return val/1000.0 if val>100000000000 else val
    text_keys=(('opened_at_text','entry_time_text','open_time_text') if opened else ('closed_at_text','exit_time_text','closed_time','ts_text'))
    for key in text_keys:
        raw=row.get(key)
        if not isinstance(raw,str) or not raw.strip(): continue
        s=raw.strip().replace(' KST','+09:00').replace('Z','+00:00')
        try:
            dt=_er_dt.datetime.fromisoformat(s.replace('T',' '))
            if dt.tzinfo is None: dt=dt.replace(tzinfo=_ER_KST_V1035)
            return dt.timestamp()
        except Exception:
            continue
    return 0.0

def _er_pnl_v1035(row: Dict[str,Any]) -> Optional[float]:
    return _er_first_num_v1035(row,('pnl_pct','profit_pct','net_pnl_pct','realized_pnl_pct','final_pnl_pct','return_pct'))

def _er_ticker_v1035(row: Dict[str,Any]) -> str:
    return str(row.get('ticker') or row.get('symbol') or row.get('market') or '').upper().replace('_KRW','').strip()

def _er_decision_key_v1035(row: Dict[str,Any]) -> str:
    for key in ('paper_decision_key_v926','paper_decision_key','direct_decision_key','decision_key'):
        val=str(row.get(key) or '').strip()
        if val.startswith('decision:'): val=val[len('decision:'):]
        if val: return val
    for subkey in ('closed_evidence','open_evidence','canonical_entry_snapshot','entry_snapshot'):
        sub=row.get(subkey)
        if isinstance(sub,dict):
            for key in ('paper_decision_key_v926','paper_decision_key','direct_decision_key','decision_key'):
                val=str(sub.get(key) or '').strip()
                if val.startswith('decision:'): val=val[len('decision:'):]
                if val: return val
    return ''

def _er_identity_v1035(row: Dict[str,Any]) -> str:
    dk=_er_decision_key_v1035(row)
    if dk: return 'decision:'+dk
    pid=str(row.get('pos_id') or row.get('event_id') or row.get('entry_id') or row.get('trade_id') or '').strip()
    if pid: return 'id:'+pid
    t=_er_ticker_v1035(row); o=_er_ts_v1035(row,True); c=_er_ts_v1035(row,False)
    ep=_er_first_num_v1035(row,('entry_price','open_price')); xp=_er_first_num_v1035(row,('exit_price','close_price'))
    if t and (o or c): return f"tc:{t}:{round(o,1)}:{round(c,1)}:{round(ep or 0,8)}:{round(xp or 0,8)}"
    return ''

def _er_compact_trade_v1035(row: Dict[str,Any], source: str, index: int) -> Optional[Dict[str,Any]]:
    pnl=_er_pnl_v1035(row); closed=_er_ts_v1035(row,False); opened=_er_ts_v1035(row,True)
    if pnl is None or closed<=0: return None
    mode=str(row.get('strategy_mode') or row.get('strategy_mode_v977') or '').strip()
    strategy=str(row.get('strategy_label') or row.get('strategy_key') or row.get('strategy') or row.get('route') or '').strip()
    version=str(row.get('opened_paper_version') or row.get('closed_paper_version') or row.get('paper_version') or row.get('version') or '').strip()
    build=str(row.get('entry_build_key') or row.get('open_build_key') or row.get('score_patch_version') or row.get('opened_patch_version') or row.get('build') or '').strip()
    return {'source':source,'index':index,'identity':_er_identity_v1035(row),'ticker':_er_ticker_v1035(row),'opened_at':opened,'closed_at':closed,'pnl_pct':pnl,'strategy_mode':mode,'strategy':strategy,'paper_version':version,'build':build,'exit_reason':str(row.get('exit_reason') or row.get('exit_rule') or '').strip(),'decision_key':_er_decision_key_v1035(row)}

def _er_stream_jsonl_v1035(path: Path, source: str, predicate=None) -> tuple[List[Dict[str,Any]],Dict[str,Any]]:
    rows=[]; total=0; bad=0; nontrade=0; oversize=0
    if not path.exists(): return rows,{'exists':False,'path':path.name,'total_lines':0,'bad_json':0,'trade_rows':0}
    try:
        with path.open('rb') as fh:
            for idx,raw in enumerate(fh):
                total+=1
                if len(raw)>8*1024*1024: oversize+=1; continue
                try: obj=json.loads(raw.decode('utf-8'))
                except Exception: bad+=1; continue
                if not isinstance(obj,dict): nontrade+=1; continue
                if predicate is not None and not predicate(obj): nontrade+=1; continue
                compact=_er_compact_trade_v1035(obj,source,idx)
                if compact is None: nontrade+=1; continue
                rows.append(compact)
    except Exception as exc:
        return rows,{'exists':True,'path':path.name,'total_lines':total,'bad_json':bad,'trade_rows':len(rows),'error':f'{exc.__class__.__name__}: {exc}'}
    return rows,{'exists':True,'path':path.name,'size':path.stat().st_size,'total_lines':total,'bad_json':bad,'nontrade':nontrade,'oversize':oversize,'trade_rows':len(rows)}

def _er_dedupe_v1035(rows: List[Dict[str,Any]]) -> tuple[List[Dict[str,Any]],int,int]:
    kept=[]; seen=set(); noid=0; dup=0
    for row in sorted(rows,key=lambda x:(float(x.get('closed_at') or 0),int(x.get('index') or 0))):
        key=str(row.get('identity') or '')
        if not key:
            noid+=1; key=f"fallback:{row.get('source')}:{row.get('index')}"
        if key in seen: dup+=1; continue
        seen.add(key); kept.append(row)
    return kept,dup,noid

def _er_stats_v1035(rows: List[Dict[str,Any]]) -> Dict[str,Any]:
    pnls=[float(r.get('pnl_pct') or 0.0) for r in rows]
    wins=sum(1 for x in pnls if x>0); losses=sum(1 for x in pnls if x<0); flat=sum(1 for x in pnls if x==0); n=len(pnls); total=sum(pnls)
    return {'n':n,'wins':wins,'losses':losses,'flat':flat,'win_rate_pct':round(wins/n*100,2) if n else None,'sum_pnl_pct':round(total,4),'avg_pnl_pct':round(total/n,4) if n else 0.0}

def _er_row_sample_v1035(row: Optional[Dict[str,Any]]) -> Dict[str,Any]:
    if not isinstance(row,dict): return {}
    ts=float(row.get('closed_at') or 0)
    return {'ticker':row.get('ticker'),'pnl_pct':row.get('pnl_pct'),'closed_at':ts,'closed_text':_er_dt.datetime.fromtimestamp(ts,_ER_KST_V1035).strftime('%Y-%m-%d %H:%M:%S KST') if ts else '', 'strategy':row.get('strategy'),'strategy_mode':row.get('strategy_mode'),'paper_version':row.get('paper_version'),'build':row.get('build'),'exit_reason':row.get('exit_reason'),'source':row.get('source'),'identity':row.get('identity')}

def _er_streak_v1035(rows: List[Dict[str,Any]]) -> Dict[str,Any]:
    ordered=sorted(rows,key=lambda x:(float(x.get('closed_at') or 0),int(x.get('index') or 0)))
    initial_positive=0; first_nonpositive=None; first_negative=None; longest=0; cur=0; longest_end=-1
    for i,row in enumerate(ordered):
        pnl=float(row.get('pnl_pct') or 0.0)
        if pnl>0:
            if first_nonpositive is None: initial_positive+=1
            cur+=1
            if cur>longest: longest=cur; longest_end=i
        else:
            if first_nonpositive is None: first_nonpositive=row
            cur=0
        if pnl<0 and first_negative is None: first_negative=row
    start=max(0,longest_end-longest+1) if longest_end>=0 else 0
    return {'ordered_rows':len(ordered),'initial_positive_streak':initial_positive,'longest_positive_streak':longest,'longest_streak_start_index':start+1 if longest else None,'longest_streak_end_index':longest_end+1 if longest else None,'first_nonpositive':_er_row_sample_v1035(first_nonpositive),'first_negative_loss':_er_row_sample_v1035(first_negative),'first_5':_er_stats_v1035(ordered[:5]),'first_10':_er_stats_v1035(ordered[:10]),'first_25':_er_stats_v1035(ordered[:25])}

def _er_group_top_v1035(rows: List[Dict[str,Any]], key_name: str, limit: int=20) -> List[Dict[str,Any]]:
    groups={}
    for row in rows:
        key=str(row.get(key_name) or 'missing')
        groups.setdefault(key,[]).append(row)
    result=[]
    for key,vals in groups.items():
        st=_er_stats_v1035(vals); st['bucket']=key; result.append(st)
    return sorted(result,key=lambda x:(-int(x.get('n') or 0),str(x.get('bucket'))))[:limit]

def _er_is_trade_log_close_v1035(row: Dict[str,Any]) -> bool:
    text=' '.join(str(row.get(k) or '') for k in ('kind','event','event_type','action','status','phase','type')).lower()
    if any(tok in text for tok in ('closed','close','exit','sell','청산')): return True
    return _er_pnl_v1035(row) is not None and _er_ts_v1035(row,False)>0 and _er_first_num_v1035(row,('exit_price','close_price')) is not None

def _er_is_close_alert_v1035(row: Dict[str,Any]) -> bool:
    kind=str(row.get('kind') or row.get('event_type') or '').lower()
    phase=str(row.get('phase') or '').lower()
    return kind in ('closed','close','exit') and phase not in ('send_error','message_build_error')

def _er_artifact_candidate_v1035(path: Path) -> bool:
    name=path.name.lower()
    if name in {'paper_bot_closed.jsonl','paper_bot_trade_log.jsonl','paper_bot_close_alert_trace.jsonl'}: return False
    if path.suffix.lower() in {'.py','.zip','.sqlite','.sqlite3','.db'}: return False
    tokens=('score','version_score','performance','trade_review','review_spine','batch_summary','closed_summary','current_score_anchor')
    return any(t in name for t in tokens)

def _er_artifact_paths_v1035() -> tuple[List[Path],Dict[str,Any]]:
    found=[]; visited=0; skipped_depth=0
    skip_dirs={'.git','__pycache__','.venv','venv','node_modules'}
    root_depth=len(BASE_DIR.parts)
    for root,dirs,files in os.walk(BASE_DIR):
        visited+=len(files)
        depth=len(Path(root).parts)-root_depth
        dirs[:]=[d for d in dirs if d not in skip_dirs and depth<5]
        if depth>=5: skipped_depth+=len(dirs); dirs[:]=[]
        for name in files:
            p=Path(root)/name
            try:
                if _er_artifact_candidate_v1035(p) and p.stat().st_size<=16*1024*1024: found.append(p)
            except OSError: continue
    found=sorted(set(found),key=lambda p:(p.stat().st_mtime if p.exists() else 0,str(p)))
    if len(found)>_ER_ARTIFACT_MAX_FILES_V1035: found=found[-_ER_ARTIFACT_MAX_FILES_V1035:]
    return found,{'visited_files':visited,'candidate_files':len(found),'depth_limit':5,'max_files':_ER_ARTIFACT_MAX_FILES_V1035,'skipped_depth_dirs':skipped_depth}

def _er_read_artifact_v1035(path: Path) -> tuple[str,Dict[str,Any]]:
    meta={'path':str(path.relative_to(BASE_DIR)) if path.is_relative_to(BASE_DIR) else str(path),'mtime':path.stat().st_mtime,'size':path.stat().st_size}
    try:
        with path.open('rb') as fh: head=fh.read(2)
        opener=gzip.open if head==b'\x1f\x8b' or path.suffix.lower()=='.gz' else open
        with opener(path,'rb') as fh: data=fh.read(_ER_ARTIFACT_MAX_READ_BYTES_V1035+1)
        meta['truncated']=len(data)>_ER_ARTIFACT_MAX_READ_BYTES_V1035
        data=data[:_ER_ARTIFACT_MAX_READ_BYTES_V1035]
        return data.decode('utf-8','replace'),meta
    except Exception as exc:
        meta['error']=f'{exc.__class__.__name__}: {exc}'; return '',meta

def _er_infer_scope_v1035(path_text: str) -> str:
    s=path_text.lower()
    if 'recent_24' in s or '24h' in s: return 'recent_24h'
    if 'today' in s or '오늘' in s: return 'today'
    if any(x in s for x in ('global','overall','all_stats','all]','.all','전체')): return 'all'
    return 'unknown'

def _er_is_overall_path_v1035(path_text: str) -> bool:
    s=path_text.lower()
    blocked=('exit','target','winner','strategy_stats','by_strategy','bucket','grade','profile','reason','structure_target','take_profit')
    if any(x in s for x in blocked): return False
    return any(x in s for x in ('global','overall','today_global','recent_24','version_score','score_cache','all_stats','전체'))

def _er_stat_from_dict_v1035(obj: Dict[str,Any]) -> Optional[Dict[str,Any]]:
    n=None; wins=None; losses=None; flat=None; total=None; wr=None
    for key in ('n','count','trades','total_trades','closed_count','current_closed_count','today_closed_count','total_closed'):
        if key in obj and _er_num_v1035(obj.get(key)) is not None: n=int(_er_num_v1035(obj.get(key)) or 0); break
    for key in ('wins','win_count','win'):
        if key in obj and _er_num_v1035(obj.get(key)) is not None: wins=int(_er_num_v1035(obj.get(key)) or 0); break
    for key in ('losses','loss_count','loss'):
        if key in obj and _er_num_v1035(obj.get(key)) is not None: losses=int(_er_num_v1035(obj.get(key)) or 0); break
    for key in ('flat','flats','flat_count'):
        if key in obj and _er_num_v1035(obj.get(key)) is not None: flat=int(_er_num_v1035(obj.get(key)) or 0); break
    for key in ('total_pct','sum_pct','total_pnl_pct','sum_pnl_pct','total'):
        if key in obj and _er_num_v1035(obj.get(key)) is not None: total=float(_er_num_v1035(obj.get(key)) or 0); break
    for key in ('win_rate_pct','win_rate','winrate'):
        if key in obj and _er_num_v1035(obj.get(key)) is not None: wr=float(_er_num_v1035(obj.get(key)) or 0); break
    if wins is None and losses is None: return None
    if n is None and wins is not None and losses is not None: n=wins+losses+(flat or 0)
    if n is None or n<=0 or wins is None: return None
    if losses is None and n>=wins: losses=n-wins-(flat or 0)
    if losses is None or losses<0 or wins<0 or wins>n: return None
    return {'n':n,'wins':wins,'losses':losses,'flat':flat or max(0,n-wins-losses),'win_rate_pct':wr if wr is not None else round(wins/n*100,2),'sum_pnl_pct':total}

def _er_nearest_ts_v1035(obj: Dict[str,Any], inherited: Optional[float], file_mtime: float) -> tuple[float,str]:
    for key in ('generated_at','updated_at','updated_ts','created_ts','ts','timestamp'):
        val=_er_num_v1035(obj.get(key))
        if val is not None and val>0: return (val/1000 if val>100000000000 else val),'content'
    return (inherited if inherited else file_mtime),('inherited' if inherited else 'file_mtime')

def _er_extract_json_stats_v1035(root: Any, file_meta: Dict[str,Any]) -> List[Dict[str,Any]]:
    out=[]; seen=set(); nodes=0
    def walk(obj: Any, path: str, inherited_ts: Optional[float], depth: int):
        nonlocal nodes
        if depth>9 or nodes>25000: return
        nodes+=1
        if isinstance(obj,dict):
            ts,ts_source=_er_nearest_ts_v1035(obj,inherited_ts,float(file_meta.get('mtime') or 0))
            stat=_er_stat_from_dict_v1035(obj)
            if stat:
                scope=_er_infer_scope_v1035(path)
                rec={**stat,'file':file_meta.get('path'),'path':path or '$','ts':ts,'ts_source':ts_source,'scope':scope,'overall_candidate':_er_is_overall_path_v1035(path+' '+str(file_meta.get('path') or '')),'source_type':'json'}
                key=(rec['file'],rec['path'],rec['n'],rec['wins'],rec['losses'])
                if key not in seen: seen.add(key); out.append(rec)
            for k,v in obj.items(): walk(v,(path+'.'+str(k)) if path else str(k),ts,depth+1)
        elif isinstance(obj,list):
            for i,v in enumerate(obj[:5000]): walk(v,f'{path}[{i}]',inherited_ts,depth+1)
    walk(root,'',None,0)
    return out

def _er_extract_text_stats_v1035(text: str, file_meta: Dict[str,Any]) -> List[Dict[str,Any]]:
    out=[]; seen=set(); pattern=_er_re.compile(r'(\d+)\s*전\s*(\d+)\s*승\s*(\d+)\s*패')
    for lineno,line in enumerate(text.splitlines(),1):
        for m in pattern.finditer(line):
            n,w,l=map(int,m.groups()); prefix=line[:m.start()].strip(); context=(prefix+' '+line).strip()[:260]
            scope=_er_infer_scope_v1035(context+' '+str(file_meta.get('path') or ''))
            overall=_er_is_overall_path_v1035(context+' '+str(file_meta.get('path') or ''))
            rec={'n':n,'wins':w,'losses':l,'flat':max(0,n-w-l),'win_rate_pct':round(w/n*100,2) if n else None,'sum_pnl_pct':None,'file':file_meta.get('path'),'path':f'line:{lineno}','ts':file_meta.get('mtime'),'ts_source':'file_mtime','scope':scope,'overall_candidate':overall,'source_type':'text','context':context}
            key=(rec['file'],rec['path'],n,w,l)
            if key not in seen: seen.add(key); out.append(rec)
    return out

def _er_scan_artifacts_v1035() -> Dict[str,Any]:
    paths,inventory=_er_artifact_paths_v1035(); records=[]; files=[]; total_read=0; skipped_budget=0
    for path in paths:
        if total_read>=_ER_ARTIFACT_TOTAL_READ_BYTES_V1035: skipped_budget+=1; continue
        text,meta=_er_read_artifact_v1035(path); files.append(meta); total_read+=min(int(meta.get('size') or 0),_ER_ARTIFACT_MAX_READ_BYTES_V1035)
        if not text: continue
        stripped=text.lstrip()
        parsed=None
        if stripped.startswith('{') or stripped.startswith('['):
            try: parsed=json.loads(text)
            except Exception: parsed=None
        if parsed is not None: records.extend(_er_extract_json_stats_v1035(parsed,meta))
        records.extend(_er_extract_text_stats_v1035(text,meta))
    uniq=[]; seen=set()
    for rec in records:
        key=(rec.get('file'),rec.get('path'),rec.get('n'),rec.get('wins'),rec.get('losses'))
        if key in seen: continue
        seen.add(key); uniq.append(rec)
    zero=[r for r in uniq if int(r.get('n') or 0)>0 and int(r.get('losses') or 0)==0]
    overall=[r for r in zero if r.get('overall_candidate')]
    subgroup=[r for r in zero if not r.get('overall_candidate')]
    inventory.update({'read_files':len(files),'read_bytes_budgeted':total_read,'skipped_budget':skipped_budget,'extracted_stat_records':len(uniq),'zero_loss_records':len(zero),'zero_loss_overall_candidates':len(overall)})
    return {'inventory':inventory,'records':sorted(uniq,key=lambda r:(float(r.get('ts') or 0),str(r.get('file')),str(r.get('path')))),'zero_loss_overall':sorted(overall,key=lambda r:(float(r.get('ts') or 0),int(r.get('n') or 0))),'zero_loss_subgroup':sorted(subgroup,key=lambda r:(float(r.get('ts') or 0),int(r.get('n') or 0))),'files_with_errors':[m for m in files if m.get('error')][:20]}

def _er_scope_rows_v1035(rows: List[Dict[str,Any]], ts: float, scope: str) -> List[Dict[str,Any]]:
    eligible=[r for r in rows if float(r.get('closed_at') or 0)<=ts+5]
    if scope=='recent_24h': return [r for r in eligible if float(r.get('closed_at') or 0)>=ts-86400]
    if scope=='today':
        day=_er_dt.datetime.fromtimestamp(ts,_ER_KST_V1035).date()
        return [r for r in eligible if _er_dt.datetime.fromtimestamp(float(r.get('closed_at') or 0),_ER_KST_V1035).date()==day]
    if scope=='all': return eligible
    return []

def _er_score_crosscheck_v1035(zero_records: List[Dict[str,Any]], raw_rows: List[Dict[str,Any]]) -> List[Dict[str,Any]]:
    out=[]
    for rec in zero_records[-50:]:
        scope=str(rec.get('scope') or 'unknown'); ts=float(rec.get('ts') or 0)
        scoped=_er_scope_rows_v1035(raw_rows,ts,scope) if ts>0 else []
        raw_stat=_er_stats_v1035(scoped) if scoped else {'n':0,'wins':0,'losses':0,'flat':0,'win_rate_pct':None,'sum_pnl_pct':0.0,'avg_pnl_pct':0.0}
        if scope=='unknown': verdict='SCOPE_UNKNOWN'
        elif raw_stat.get('losses',0)>0: verdict='DISPLAY_ZERO_LOSS_BUT_RAW_LOSS_EXISTS'
        elif int(raw_stat.get('n') or 0)>=int(rec.get('n') or 0) and int(raw_stat.get('losses') or 0)==0: verdict='RAW_CONSISTENT_ZERO_LOSS_AT_TIME'
        elif int(raw_stat.get('n') or 0)==0: verdict='RAW_NOT_AVAILABLE_FOR_SNAPSHOT_TIME'
        else: verdict='PARTIAL_COUNT_MISMATCH'
        out.append({'score_record':rec,'raw_scope_stats':raw_stat,'verdict':verdict})
    return out

def _er_source_overlap_v1035(closed_rows: List[Dict[str,Any]], trade_rows: List[Dict[str,Any]], alert_rows: List[Dict[str,Any]]) -> Dict[str,Any]:
    def ids(rows): return {str(r.get('identity')) for r in rows if r.get('identity')}
    c,t,a=ids(closed_rows),ids(trade_rows),ids(alert_rows)
    return {'closed_ids':len(c),'trade_ids':len(t),'alert_ids':len(a),'closed_trade_overlap':len(c&t),'closed_alert_overlap':len(c&a),'trade_only':len(t-c),'alert_only':len(a-c),'all_three':len(c&t&a),'note':'legacy identity may be pos_id or ticker/time/price fallback; counts are audit evidence, not canonical membership'}

def _er_final_verdict_v1035(pre_rows: List[Dict[str,Any]], artifact: Dict[str,Any], cross: List[Dict[str,Any]]) -> Dict[str,Any]:
    streak=_er_streak_v1035(pre_rows); raw_initial=int(streak.get('initial_positive_streak') or 0)
    consistent=[x for x in cross if x.get('verdict')=='RAW_CONSISTENT_ZERO_LOSS_AT_TIME']
    mismatch=[x for x in cross if x.get('verdict')=='DISPLAY_ZERO_LOSS_BUT_RAW_LOSS_EXISTS']
    max_confirmed=max([int((x.get('score_record') or {}).get('n') or 0) for x in consistent]+[raw_initial])
    max_display=max([int(r.get('n') or 0) for r in artifact.get('zero_loss_overall',[])]+[0])
    if consistent or raw_initial>0:
        code='EARLY_ZERO_LOSS_EVIDENCE_FOUND'
        summary=f'초기 무패 구간 증거가 확인됨. 원장 초기 연승 {raw_initial}건, score/raw 일치 최대 {max_confirmed}건.'
    elif mismatch:
        code='DISPLAY_SELECTION_BIAS_EVIDENCE'
        summary='0패 score 흔적은 있으나 같은 범위 raw 원장에는 이미 손실이 있어 표시 선택편향 가능성이 큼.'
    elif artifact.get('zero_loss_overall'):
        code='ZERO_LOSS_DISPLAY_FOUND_RAW_UNPROVEN'
        summary='0패 score 흔적은 찾았지만 scope/timestamp 또는 raw 원장 연결이 부족해 실제 전체 무패로 확정할 수 없음.'
    elif pre_rows:
        code='LEGACY_RAW_FOUND_NO_ZERO_LOSS_SNAPSHOT'
        summary='v977 이전 raw 거래는 찾았지만 보존된 전체 score snapshot에서 0패 표시 증거는 아직 없음.'
    else:
        code='INSUFFICIENT_PRE_V977_SERVER_EVIDENCE'
        summary='현재 서버 보존자료에서 v977 이전 거래·0패 score를 충분히 복원하지 못함.'
    return {'code':code,'summary':summary,'raw_initial_positive_streak':raw_initial,'max_confirmed_zero_loss_n':max_confirmed,'max_displayed_zero_loss_n':max_display,'consistent_snapshot_count':len(consistent),'display_mismatch_count':len(mismatch),'can_restore_initial_strategy_now':False,'restore_blocker':'v977 이전 code source와 당시 전체 membership/market evidence가 확인되기 전 과거 버전 복귀 금지'}

def update_early_regression_audit_v1035(nowv: float, canonical_snapshot: Dict[str,Any]) -> Dict[str,Any]:
    previous=load_json(EARLY_REGRESSION_AUDIT_V1035,{}) or {}
    last=float(previous.get('updated_ts') or 0) if isinstance(previous,dict) else 0.0
    if previous and nowv-last<EARLY_REGRESSION_INTERVAL_SEC_V1035:
        status={'schema':'early_regression_audit_status_v1035','version':VERSION,'build':BUILD_LABEL,'state':previous.get('state','ACTIVE'),'updated_ts':nowv,'snapshot_updated_ts':last,'scan_skipped':True,'next_due_sec':round(EARLY_REGRESSION_INTERVAL_SEC_V1035-(nowv-last),1),'verdict':previous.get('verdict'),'trading_rules_changed':False,'auto_buy':False}
        save_json(EARLY_REGRESSION_STATUS_V1035,status); return status
    closed_rows,closed_meta=_er_stream_jsonl_v1035(CLOSED,'closed_ledger')
    trade_path=BASE_DIR/'paper_bot_trade_log.jsonl'
    trade_rows,trade_meta=_er_stream_jsonl_v1035(trade_path,'trade_log',_er_is_trade_log_close_v1035)
    alert_path=BASE_DIR/'paper_bot_close_alert_trace.jsonl'
    alert_rows,alert_meta=_er_stream_jsonl_v1035(alert_path,'close_alert',_er_is_close_alert_v1035)
    closed_dedup,closed_dup,closed_noid=_er_dedupe_v1035(closed_rows)
    trade_dedup,trade_dup,trade_noid=_er_dedupe_v1035(trade_rows)
    alert_dedup,alert_dup,alert_noid=_er_dedupe_v1035(alert_rows)
    pre_open_exact=[r for r in closed_dedup if float(r.get('opened_at') or 0)>0 and float(r.get('opened_at') or 0)<_ER_ALT_SWING_CUTOVER_TS_V1035]
    pre_closed_inferred=[r for r in closed_dedup if float(r.get('opened_at') or 0)<=0 and 0<float(r.get('closed_at') or 0)<_ER_ALT_SWING_CUTOVER_TS_V1035]
    pre=sorted(pre_open_exact+pre_closed_inferred,key=lambda x:(float(x.get('closed_at') or 0),int(x.get('index') or 0)))
    post_open_exact=[r for r in closed_dedup if float(r.get('opened_at') or 0)>=_ER_ALT_SWING_CUTOVER_TS_V1035]
    post_closed_inferred=[r for r in closed_dedup if float(r.get('opened_at') or 0)<=0 and float(r.get('closed_at') or 0)>=_ER_ALT_SWING_CUTOVER_TS_V1035]
    post=sorted(post_open_exact+post_closed_inferred,key=lambda x:(float(x.get('closed_at') or 0),int(x.get('index') or 0)))
    missing_open=[r for r in closed_dedup if float(r.get('opened_at') or 0)<=0]
    artifact=_er_scan_artifacts_v1035()
    cross=_er_score_crosscheck_v1035(artifact.get('zero_loss_overall',[]),closed_dedup)
    verdict=_er_final_verdict_v1035(pre,artifact,cross)
    result={'schema':'early_regression_audit_snapshot_v1035','version':VERSION,'build':BUILD_LABEL,'state':'ACTIVE' if (closed_dedup or artifact.get('records')) else 'PARTIAL_NO_EVIDENCE','updated_ts':nowv,'updated_text':now_text(nowv),'cutover':{'alt_swing_cutover_ts':_ER_ALT_SWING_CUTOVER_TS_V1035,'alt_swing_cutover_text':_er_dt.datetime.fromtimestamp(_ER_ALT_SWING_CUTOVER_TS_V1035,_ER_KST_V1035).strftime('%Y-%m-%d %H:%M:%S KST'),'policy':'v977 이전 legacy raw와 v977 이후 canonical exact를 절대 합치지 않고 비교만 함'},'verdict':verdict,'raw_closed':{'source_meta':closed_meta,'deduped_rows':len(closed_dedup),'duplicate_rows':closed_dup,'identity_missing_rows':closed_noid,'all_stats':_er_stats_v1035(closed_dedup),'pre_v977_stats':_er_stats_v1035(pre),'pre_v977_open_exact_rows':len(pre_open_exact),'pre_v977_closed_time_inferred_rows':len(pre_closed_inferred),'post_cutover_raw_stats':_er_stats_v1035(post),'post_cutover_open_exact_rows':len(post_open_exact),'post_cutover_closed_time_inferred_rows':len(post_closed_inferred),'missing_open_ts_stats':_er_stats_v1035(missing_open),'pre_v977_streak':_er_streak_v1035(pre),'pre_v977_by_strategy':_er_group_top_v1035(pre,'strategy',20),'pre_v977_by_paper_version':_er_group_top_v1035(pre,'paper_version',20),'pre_v977_by_build':_er_group_top_v1035(pre,'build',20),'first_pre_v977_rows':[_er_row_sample_v1035(x) for x in sorted(pre,key=lambda y:float(y.get('closed_at') or 0))[:20]]},'trade_log':{'source_meta':trade_meta,'deduped_rows':len(trade_dedup),'duplicate_rows':trade_dup,'identity_missing_rows':trade_noid,'stats':_er_stats_v1035(trade_dedup),'streak':_er_streak_v1035(trade_dedup),'first_rows':[_er_row_sample_v1035(x) for x in trade_dedup[:10]]},'close_alert':{'source_meta':alert_meta,'deduped_rows':len(alert_dedup),'duplicate_rows':alert_dup,'identity_missing_rows':alert_noid,'stats':_er_stats_v1035(alert_dedup),'streak':_er_streak_v1035(alert_dedup),'first_rows':[_er_row_sample_v1035(x) for x in alert_dedup[:10]]},'source_crosscheck':_er_source_overlap_v1035(closed_dedup,trade_dedup,alert_dedup),'score_artifacts':{'inventory':artifact.get('inventory'),'zero_loss_overall_count':len(artifact.get('zero_loss_overall',[])),'zero_loss_subgroup_count':len(artifact.get('zero_loss_subgroup',[])),'max_overall_zero_loss_n':max([int(x.get('n') or 0) for x in artifact.get('zero_loss_overall',[])]+[0]),'overall_zero_loss_records':artifact.get('zero_loss_overall',[])[-30:],'subgroup_zero_loss_samples':artifact.get('zero_loss_subgroup',[])[-20:],'crosscheck':cross,'files_with_errors':artifact.get('files_with_errors',[])},'canonical_reference':{'snapshot_id':canonical_snapshot.get('snapshot_id'),'exact_rows':len(canonical_snapshot.get('rows') or []) if isinstance(canonical_snapshot.get('rows'),list) else None,'counts':canonical_snapshot.get('counts'),'membership_digest':canonical_snapshot.get('membership_digest'),'note':'canonical exact는 변경하지 않고 초기 legacy evidence와 옆에서만 비교'},'code_history':{'coverage_start':'v977','pre_v977_source_available':False,'timeline':_ER_CODE_TIMELINE_V1035,'critical_limit':'완전 초기 코드 source가 없으므로 서버 보존 원장과 score 흔적만으로 당시 selection/exit 전체를 복원할 수 없음'},'locks':{'auto_buy':False,'entry_rule_changed':False,'exit_rule_changed':False,'threshold_changed':False,'canonical_membership_changed':False,'ledger_rewritten':False,'legacy_rows_promoted_to_exact':False},'evidence_levels':{'canonical_exact':'현재 v977+ OPEN-time mode + CLOSED decision key','legacy_raw':'보존 raw CLOSED/trade/alert. identity가 없을 수 있어 canonical 성과로 사용 금지','score_snapshot':'당시 화면 writer 흔적. scope와 raw 교차검증 후에만 무패 증거','unavailable':'v977 이전 source와 삭제된 과거 cache/시장상태'}}
    digest=hashlib.sha256(json.dumps(result,ensure_ascii=False,sort_keys=True,default=str,separators=(',',':')).encode()).hexdigest(); result['audit_digest']=digest
    save_json(EARLY_REGRESSION_AUDIT_V1035,result)
    save_json(EARLY_REGRESSION_STATE_V1035,{'schema':'early_regression_audit_state_v1035','last_scan_ts':nowv,'audit_digest':digest,'closed_size':closed_meta.get('size',0),'artifact_files':(artifact.get('inventory') or {}).get('read_files',0)})
    status={'schema':'early_regression_audit_status_v1035','version':VERSION,'build':BUILD_LABEL,'state':result['state'],'updated_ts':nowv,'scan_skipped':False,'audit_digest':digest,'verdict':verdict,'pre_v977_rows':len(pre),'zero_loss_overall_records':len(artifact.get('zero_loss_overall',[])),'scanned_artifact_files':(artifact.get('inventory') or {}).get('read_files',0),'trading_rules_changed':False,'auto_buy':False}
    save_json(EARLY_REGRESSION_STATUS_V1035,status); return status


# =============================================================================
# Review v2.010 / unified /shadow owner
# Single status owner for exact 3-price/timeframe structure shadow, candidate-quality
# subsets, prospective profit-giveback virtual exits, no-progress evidence and buried
# candidate summaries. Read-only with respect to actual Strategy/Paper/OPEN/exit.
# =============================================================================
UNIFIED_SHADOW_STATUS_V2010 = BASE_DIR / 'shadow_status_v2010.json'
UNIFIED_SHADOW_STATE_V2010 = BASE_DIR / 'shadow_active_state_v2010.json'
UNIFIED_SHADOW_STRUCTURE_LEDGER_V2010 = BASE_DIR / 'shadow_structure_events_v2010.jsonl'
UNIFIED_SHADOW_PROFIT_LEDGER_V2010 = BASE_DIR / 'shadow_profit_exit_events_v2010.jsonl'
UNIFIED_SHADOW_SNAPSHOT_LEDGER_V2010 = BASE_DIR / 'shadow_snapshot_events_v2010.jsonl'
UNIFIED_SHADOW_STATE_RETENTION_SEC_V2010 = 7 * 86400.0
UNIFIED_SHADOW_STATE_MAX_V2010 = 3000
UNIFIED_SHADOW_STATE_CHECKPOINT_SEC_V2010 = 120.0
UNIFIED_SHADOW_SNAPSHOT_LEDGER_CADENCE_SEC_V2010 = 300.0
_V2010_SHADOW_STATE_MEMORY = None
_V2010_SHADOW_STATE_LAST_SAVE_MONO = 0.0
_V2010_SHADOW_EVENT_BATCH: Dict[str,List[Dict[str,Any]]] = {}
UNIFIED_SHADOW_HORIZONS_V2010 = (('3h',10800.0),('6h',21600.0),('12h',43200.0),('24h',86400.0))


def _v2010_append_jsonl(path: Path, row: Dict[str, Any]) -> None:
    shadow_paths={str(UNIFIED_SHADOW_STRUCTURE_LEDGER_V2010),str(UNIFIED_SHADOW_PROFIT_LEDGER_V2010),str(UNIFIED_SHADOW_SNAPSHOT_LEDGER_V2010)}
    if str(path) in shadow_paths:
        _V2010_SHADOW_EVENT_BATCH.setdefault(str(path),[]).append(dict(row)); return
    path.parent.mkdir(parents=True,exist_ok=True)
    with path.open('a',encoding='utf-8') as fh:
        fh.write(json.dumps(row,ensure_ascii=False,separators=(',',':'),default=str)+'\n')
        fh.flush(); os.fsync(fh.fileno())


def _v2010_flush_shadow_event_batches() -> Dict[str,Any]:
    flushed=0; events=0; failures=[]
    for raw_path,rows in list(_V2010_SHADOW_EVENT_BATCH.items()):
        if not rows: continue
        path=Path(raw_path); batch=list(rows)
        try:
            path.parent.mkdir(parents=True,exist_ok=True)
            blob=''.join(json.dumps(row,ensure_ascii=False,separators=(',',':'),default=str)+'\n' for row in batch)
            with path.open('a',encoding='utf-8') as fh:
                fh.write(blob); fh.flush(); os.fsync(fh.fileno())
            del rows[:len(batch)]; flushed+=1; events+=len(batch)
        except Exception as exc:
            failures.append({'path':path.name,'error':f'{type(exc).__name__}: {exc}'})
    return {'files_flushed':flushed,'events_flushed':events,'failures':failures,'single_fsync_per_file_per_cycle':True}


def _v2010_shadow_state() -> Dict[str,Any]:
    global _V2010_SHADOW_STATE_MEMORY
    if not isinstance(_V2010_SHADOW_STATE_MEMORY,dict):
        _V2010_SHADOW_STATE_MEMORY=load_json(UNIFIED_SHADOW_STATE_V2010,{}) or {}
    return _V2010_SHADOW_STATE_MEMORY


def _v2010_checkpoint_shadow_state(state: Dict[str,Any], force: bool=False) -> bool:
    global _V2010_SHADOW_STATE_LAST_SAVE_MONO
    mono=time.monotonic()
    due=force or (not UNIFIED_SHADOW_STATE_V2010.exists()) or (mono-_V2010_SHADOW_STATE_LAST_SAVE_MONO>=UNIFIED_SHADOW_STATE_CHECKPOINT_SEC_V2010)
    if not due: return False
    save_json(UNIFIED_SHADOW_STATE_V2010,state); _V2010_SHADOW_STATE_LAST_SAVE_MONO=mono; return True


def _v2010_exact_event_key(row: Dict[str,Any]) -> str:
    key=_cs_decision_key_v1141(row)
    if key: return key
    gate=_cs_gate_v1141(row); occ=_cs_occurrence_v1141(row)
    return str(row.get('candidate_exact_identity') or gate.get('direct_decision_key') or occ.get('candidate_key') or '').strip()


def _v2010_exact_pos_key(row: Dict[str,Any]) -> str:
    return str(row.get('pos_id') or row.get('position_id') or '').strip()


def _v2010_price(item: Any) -> Optional[float]:
    if isinstance(item,dict): return _cs_num_v1141(item.get('price'))
    return _cs_num_v1141(item)


def _v2010_truth_options(row: Dict[str,Any]) -> Dict[str,List[Dict[str,Any]]]:
    truth=row.get('structure_source_truth_v2010') if isinstance(row.get('structure_source_truth_v2010'),dict) else {}
    out={'trigger':[],'invalid':[],'target':[]}
    for role in out:
        src=truth.get(role) if isinstance(truth.get(role),dict) else {}
        for key,item in src.items():
            if not isinstance(item,dict): continue
            price=_v2010_price(item)
            if price is None: continue
            tf,source_key=(str(key).split(':',1)+[''])[:2]
            out[role].append({'tf':tf,'source_key':source_key,'price':price,'source':item.get('source'),'age_sec':_cs_num_v1141(item.get('age_sec'),item.get('candle_age_sec'))})
    return out


def _v2010_current_contract(row: Dict[str,Any]) -> Dict[str,Any]:
    plan=_cs_plan_v1141(row); gate=_cs_gate_v1141(row)
    def role(name: str, price_keys: tuple[str,...]):
        obj=plan.get(name) if isinstance(plan.get(name),dict) else {}
        vals=[obj.get('price')]
        for k in price_keys: vals.append(gate.get(k)); vals.append(row.get(k))
        return {'price':_cs_num_v1141(*vals),'tf':obj.get('tf'),'source':obj.get('source') or obj.get('source_key')}
    return {
        'trigger':role('trigger',('trigger_price','swing_trigger_price_v977')),
        'invalid':role('invalid',('invalid_price','swing_invalid_price_v977')),
        'target':role('target',('target_price','swing_target_price_v977')),
    }


def _v2010_shadow_select(options: Dict[str,List[Dict[str,Any]]], ref_price: float) -> Dict[str,Any]:
    triggers=list(options.get('trigger') or [])
    invalids=[x for x in (options.get('invalid') or []) if (_cs_num_v1141(x.get('price')) or 0)<ref_price]
    targets=[x for x in (options.get('target') or []) if (_cs_num_v1141(x.get('price')) or 0)>ref_price]
    trigger=min(triggers,key=lambda x:abs(float(x.get('price') or 0)-ref_price),default=None)
    invalid=max(invalids,key=lambda x:float(x.get('price') or 0),default=None)
    target=None
    # Experimental target selection: prefer genuine higher-timeframe resistance evidence,
    # not the nearest low-timeframe line across all frames.
    for tf in ('h4','h2','h1','m30'):
        bucket=[x for x in targets if x.get('tf')==tf]
        if bucket:
            target=min(bucket,key=lambda x:float(x.get('price') or 0)); break
    return {'trigger':dict(trigger) if trigger else None,'invalid':dict(invalid) if invalid else None,'target':dict(target) if target else None,'selection_policy':'experimental exact-source only: trigger nearest source line; invalid nearest support below reference; target higher-timeframe priority h4>h2>h1>m30','proxy_used':False}


def _v2010_contract_metrics(contract: Dict[str,Any], ref_price: float) -> Dict[str,Any]:
    trig=_v2010_price(contract.get('trigger')); inv=_v2010_price(contract.get('invalid')); target=_v2010_price(contract.get('target'))
    risk=abs(_cs_pct_between_v1141(inv,ref_price)) if inv and ref_price else None
    room=_cs_pct_between_v1141(target,ref_price) if target and ref_price else None
    rr=((target-ref_price)/(ref_price-inv)) if target and inv and target>ref_price>inv else None
    return {'trigger':trig,'invalid':inv,'target':target,'risk_pct':round(risk,6) if risk is not None else None,'target_room_pct':round(room,6) if room is not None else None,'rr':round(rr,6) if rr is not None else None,'target_smaller_than_risk':bool(room is not None and risk is not None and room<risk)}


def _v2010_touch_update(rec: Dict[str,Any], price: float, nowv: float) -> None:
    rec['last_price']=price; rec['last_seen_ts']=nowv
    rec['max_price']=max(float(rec.get('max_price') or price),price)
    rec['min_price']=min(float(rec.get('min_price') or price),price)
    for label,contract in (('current',rec.get('current_contract')),('shadow',rec.get('shadow_selected'))):
        if not isinstance(contract,dict): continue
        for role in ('trigger','target'):
            level=_v2010_price(contract.get(role))
            key=f'{label}_{role}_first_touch_ts'
            if level and price>=level and not rec.get(key): rec[key]=nowv
        level=_v2010_price(contract.get('invalid')); key=f'{label}_invalid_first_touch_ts'
        if level and price<=level and not rec.get(key): rec[key]=nowv


def _v2010_structure_shadow(nowv: float, candidate_rows: List[Dict[str,Any]], fmap: Dict[str,Dict[str,Any]], ofmap: Dict[str,Dict[str,Any]], state: Dict[str,Any]) -> Dict[str,Any]:
    active=state.get('structure_active') if isinstance(state.get('structure_active'),dict) else {}
    input_rows=len(candidate_rows)
    candidate_rows=[r for r in candidate_rows if isinstance(r,dict) and isinstance(r.get('structure_source_truth_v2010'),dict)]
    missing_key=0; source_missing=0; new_events=0; horizon_events=0; current_tf=Counter(); shadow_tf=Counter(); samples=[]
    for row in candidate_rows:
        if not isinstance(row,dict): continue
        event_key=_v2010_exact_event_key(row)
        if not event_key: missing_key+=1; continue
        ticker=_cs_ticker_v1141(row); price=_current_price(ticker,fmap,ofmap) or _cs_num_v1141(row.get('current_price'),row.get('price'),row.get('entry_price'))
        if not ticker or not price: continue
        options=_v2010_truth_options(row)
        if not options['trigger'] or not options['invalid'] or not options['target']: source_missing+=1
        current=_v2010_current_contract(row); selected=_v2010_shadow_select(options,float(price))
        rec=active.get(event_key) if isinstance(active.get(event_key),dict) else None
        if rec is None:
            rec={'event_key':event_key,'ticker':ticker,'observed_ts':nowv,'observed_text':now_text(nowv),'reference_price':float(price),'current_contract':current,'shadow_selected':selected,'horizons':{},'max_price':float(price),'min_price':float(price),'last_price':float(price),'auto_buy':False}
            active[event_key]=rec; new_events+=1
            _v2010_append_jsonl(UNIFIED_SHADOW_STRUCTURE_LEDGER_V2010,{'schema':'shadow_structure_event_v2010','event':'OBSERVED','ts':nowv,'time':now_text(nowv),**{k:rec.get(k) for k in ('event_key','ticker','reference_price','current_contract','shadow_selected','source_options')},'proxy_used':False,'actual_contract_changed':False,'auto_buy':False})
        _v2010_touch_update(rec,float(price),nowv)
        elapsed=nowv-float(rec.get('observed_ts') or nowv)
        for label,sec in UNIFIED_SHADOW_HORIZONS_V2010:
            horizons=rec.get('horizons') if isinstance(rec.get('horizons'),dict) else {}; rec['horizons']=horizons
            if elapsed>=sec and label not in horizons:
                base=float(rec.get('reference_price') or price); maxp=float(rec.get('max_price') or price); minp=float(rec.get('min_price') or price)
                outcome={'completed_ts':nowv,'elapsed_sec':round(elapsed,3),'end_price':float(price),'max_gain_pct':round((maxp/base-1)*100,6) if base else None,'max_drawdown_pct':round((minp/base-1)*100,6) if base else None}
                for prefix in ('current','shadow'):
                    contract=rec.get('current_contract') if prefix=='current' else rec.get('shadow_selected')
                    outcome[prefix]={'trigger_touched':bool(rec.get(f'{prefix}_trigger_first_touch_ts')),'invalid_touched':bool(rec.get(f'{prefix}_invalid_first_touch_ts')),'target_touched':bool(rec.get(f'{prefix}_target_first_touch_ts')),'metrics':_v2010_contract_metrics(contract if isinstance(contract,dict) else {},base)}
                horizons[label]=outcome; horizon_events+=1
                _v2010_append_jsonl(UNIFIED_SHADOW_STRUCTURE_LEDGER_V2010,{'schema':'shadow_structure_event_v2010','event':'HORIZON','event_key':event_key,'ticker':ticker,'horizon':label,'ts':nowv,'time':now_text(nowv),'outcome':outcome,'actual_contract_changed':False,'auto_buy':False})
        for role in ('trigger','invalid','target'):
            c=current.get(role) if isinstance(current.get(role),dict) else {}; sh=selected.get(role) if isinstance(selected.get(role),dict) else {}
            if c.get('tf'): current_tf[f'{role}:{c.get("tf")}']+=1
            if sh.get('tf'): shadow_tf[f'{role}:{sh.get("tf")}']+=1
        if len(samples)<5:
            samples.append({'ticker':ticker,'event_key':event_key,'current':current,'shadow':selected,'current_metrics':_v2010_contract_metrics(current,float(price)),'shadow_metrics':_v2010_contract_metrics(selected,float(price)),'source_missing':not (options['trigger'] and options['invalid'] and options['target'])})
    cutoff=nowv-UNIFIED_SHADOW_STATE_RETENTION_SEC_V2010
    active={k:v for k,v in active.items() if float(v.get('last_seen_ts') or v.get('observed_ts') or 0)>=cutoff or any(label not in (v.get('horizons') or {}) for label,_ in UNIFIED_SHADOW_HORIZONS_V2010)}
    if len(active)>UNIFIED_SHADOW_STATE_MAX_V2010:
        active=dict(sorted(active.items(),key=lambda kv:float(kv[1].get('last_seen_ts') or kv[1].get('observed_ts') or 0),reverse=True)[:UNIFIED_SHADOW_STATE_MAX_V2010])
    state['structure_active']=active
    horizon_counts={label:sum(1 for v in active.values() if label in (v.get('horizons') or {})) for label,_ in UNIFIED_SHADOW_HORIZONS_V2010}
    smaller_current=sum(1 for s in samples if (s.get('current_metrics') or {}).get('target_smaller_than_risk'))
    smaller_shadow=sum(1 for s in samples if (s.get('shadow_metrics') or {}).get('target_smaller_than_risk'))
    return {'state':'ACTIVE','tracked':len(active),'input_candidate_rows':input_rows,'shadow_scope_rows':len(candidate_rows),'candidate_rows':len(candidate_rows),'exact_event_key_missing':missing_key,'source_missing_rows':source_missing,'new_events':new_events,'new_horizon_events':horizon_events,'horizon_completed':horizon_counts,'current_timeframe_top':dict(current_tf.most_common(12)),'shadow_timeframe_top':dict(shadow_tf.most_common(12)),'sample':samples,'sample_target_smaller_than_risk_current':smaller_current,'sample_target_smaller_than_risk_shadow':smaller_shadow,'policy':'3 exact prices + selected timeframe comparison only; no proxy; actual trigger/invalid/target unchanged'}


def _v2010_perf(rows: List[Dict[str,Any]]) -> Dict[str,Any]:
    pnls=[_cs_row_pnl_v1141(r) for r in rows]; pnls=[float(x) for x in pnls if x is not None]
    mfe=[_cs_num_v1141(r.get('mfe_pct'),r.get('max_profit_pct'),r.get('max_pnl_pct')) for r in rows]; mfe=[float(x) for x in mfe if x is not None]
    mae=[_cs_num_v1141(r.get('mae_pct'),r.get('min_profit_pct'),r.get('min_pnl_pct')) for r in rows]; mae=[float(x) for x in mae if x is not None]
    wins=sum(1 for x in pnls if x>0)
    return {'n':len(pnls),'wins':wins,'win_rate_pct':round(wins/len(pnls)*100,2) if pnls else None,'sum_pnl_pct':round(sum(pnls),4) if pnls else 0.0,'avg_pnl_pct':round(sum(pnls)/len(pnls),4) if pnls else None,'mfe_median_pct':_cs_median_v1141(mfe),'mae_median_pct':_cs_median_v1141(mae)}


def _v2010_row_metrics(row: Dict[str,Any]) -> Dict[str,Optional[float]]:
    vals=_cs_metric_values_v1141([row]); return {k:(v[0] if v else None) for k,v in vals.items()}


def _v2010_quality_shadow(closed_rows: List[Dict[str,Any]]) -> Dict[str,Any]:
    enriched=[]
    for row in closed_rows:
        if not isinstance(row,dict): continue
        enriched.append((row,_v2010_row_metrics(row),_cs_source_lane_v1141(row)))
    tests={
        '돈흐름+주도흐름':lambda r,m,l:l in ('돈흐름','주도흐름'),
        '전체커버':lambda r,m,l:l=='전체커버',
        '돌파초입':lambda r,m,l:l=='돌파초입',
        'hot-rank':lambda r,m,l:l=='hot-rank',
        '가격반응>0':lambda r,m,l:m.get('reaction') is not None and m['reaction']>0,
        '가격반응>=0.2':lambda r,m,l:m.get('reaction') is not None and m['reaction']>=0.2,
        '가격반응>=0.38':lambda r,m,l:m.get('reaction') is not None and m['reaction']>=0.38,
        'money>=60':lambda r,m,l:m.get('money_flow') is not None and m['money_flow']>=60,
        '지속>=0.50':lambda r,m,l:m.get('buy_sustain') is not None and m['buy_sustain']>=0.50,
        'money60+지속0.50':lambda r,m,l:m.get('money_flow') is not None and m['money_flow']>=60 and m.get('buy_sustain') is not None and m['buy_sustain']>=0.50,
        'RS양수+money60+지속0.50':lambda r,m,l:m.get('relative_strength') is not None and m['relative_strength']>0 and m.get('money_flow') is not None and m['money_flow']>=60 and m.get('buy_sustain') is not None and m['buy_sustain']>=0.50,
    }
    items=[]
    for name,fn in tests.items():
        bucket=[row for row,m,lane in enriched if fn(row,m,lane)]; items.append({'name':name,**_v2010_perf(bucket)})
    invalid_buckets=(('<1.5',lambda x:x<1.5),('1.5~2.0',lambda x:1.5<=x<2.0),('2.0~2.5',lambda x:2<=x<2.5),('2.5~3.0',lambda x:2.5<=x<3),('3.0+',lambda x:x>=3))
    invalid=[]
    for name,fn in invalid_buckets:
        bucket=[row for row,m,lane in enriched if m.get('invalid_distance') is not None and fn(float(m['invalid_distance']))]; invalid.append({'name':name,**_v2010_perf(bucket)})
    eligible=[x for x in items if x.get('n',0)>=3]
    best=max(eligible,key=lambda x:x.get('avg_pnl_pct') if x.get('avg_pnl_pct') is not None else -1e99,default=None)
    worst=min(eligible,key=lambda x:x.get('avg_pnl_pct') if x.get('avg_pnl_pct') is not None else 1e99,default=None)
    return {'state':'ACTIVE' if closed_rows else 'COLLECTING','closed_rows':len(closed_rows),'tests':items,'invalid_distance_buckets':invalid,'best_min_n3':best,'worst_min_n3':worst,'policy':'read-only subset comparison; no candidate count cap, no S1/Paper block'}


_V2010_PROFIT_POLICIES={
    'P1_1P_TO_NONPOS':{'peak':1.0,'giveback':None,'floor':0.0,'label':'+1% 뒤 0% 이하 방어'},
    'P2_2P_GIVEBACK_1':{'peak':2.0,'giveback':1.0,'floor':None,'label':'+2% 뒤 1%p 반납 방어'},
    'P3_3P_GIVEBACK_1_5':{'peak':3.0,'giveback':1.5,'floor':None,'label':'+3% 뒤 1.5%p 반납 방어'},
    'P3B_3P_GIVEBACK_2':{'peak':3.0,'giveback':2.0,'floor':None,'label':'+3% 뒤 2%p 반납 방어'},
    'P4_5P_GIVEBACK_2':{'peak':5.0,'giveback':2.0,'floor':None,'label':'+5% 뒤 2%p 반납 방어'},
}


def _v2010_profit_shadow(nowv: float, closed_rows: List[Dict[str,Any]], state: Dict[str,Any]) -> Dict[str,Any]:
    active=state.get('profit_active') if isinstance(state.get('profit_active'),dict) else {}
    finalized=state.get('profit_finalized') if isinstance(state.get('profit_finalized'),dict) else {}
    open_rows=_v923_open_rows()
    open_exact={}
    for row in open_rows:
        pos=_v2010_exact_pos_key(row); decision=_v2010_exact_event_key(row)
        ident=('pos:'+pos) if pos else (('decision:'+decision) if decision else '')
        if not ident: continue
        pnl=_cs_row_pnl_v1141(row)
        if pnl is None: continue
        open_exact[ident]=row
        rec=active.get(ident) if isinstance(active.get(ident),dict) else None
        if rec is None:
            rec={'identity':ident,'pos_id':pos or None,'decision_key':decision or None,'ticker':_cs_ticker_v1141(row),'observed_ts':nowv,'observed_text':now_text(nowv),'shadow_peak_pct':float(pnl),'prior_pnl_pct':float(pnl),'policies':{},'first_cycle_seed_only':True,'auto_buy':False}
            active[ident]=rec
            continue
        rec['first_cycle_seed_only']=False
        rec['shadow_peak_pct']=max(float(rec.get('shadow_peak_pct') or pnl),float(pnl))
        peak=float(rec.get('shadow_peak_pct') or pnl); giveback=peak-float(pnl)
        for code,cfg in _V2010_PROFIT_POLICIES.items():
            policies=rec.get('policies') if isinstance(rec.get('policies'),dict) else {}; rec['policies']=policies
            if code in policies: continue
            if peak<float(cfg['peak']): continue
            hit=(float(pnl)<=float(cfg['floor'])) if cfg.get('floor') is not None else (giveback>=float(cfg['giveback']))
            if hit:
                event={'triggered_ts':nowv,'triggered_text':now_text(nowv),'virtual_exit_pnl_pct':round(float(pnl),6),'shadow_peak_pct':round(peak,6),'giveback_pct':round(giveback,6),'label':cfg['label']}
                policies[code]=event
                _v2010_append_jsonl(UNIFIED_SHADOW_PROFIT_LEDGER_V2010,{'schema':'shadow_profit_exit_event_v2010','event':'VIRTUAL_EXIT','identity':ident,'pos_id':pos or None,'decision_key':decision or None,'ticker':rec.get('ticker'),'policy':code,'ts':nowv,'time':now_text(nowv),**event,'actual_exit_changed':False,'auto_buy':False})
        rec['prior_pnl_pct']=float(pnl); rec['last_seen_ts']=nowv
    closed_by_pos={}; closed_by_decision={}
    for row in closed_rows:
        pos=_v2010_exact_pos_key(row); dec=_v2010_exact_event_key(row)
        if pos: closed_by_pos[pos]=row
        if dec: closed_by_decision[dec]=row
    for ident,rec in list(active.items()):
        if ident in open_exact: continue
        row=None
        if rec.get('pos_id'): row=closed_by_pos.get(str(rec.get('pos_id')))
        if row is None and rec.get('decision_key'): row=closed_by_decision.get(str(rec.get('decision_key')))
        if row is None: continue
        actual=_cs_row_pnl_v1141(row)
        if actual is None: continue
        results={}
        for code,event in (rec.get('policies') or {}).items():
            virtual=_cs_num_v1141(event.get('virtual_exit_pnl_pct'))
            if virtual is None: continue
            results[code]={'actual_pnl_pct':round(float(actual),6),'virtual_exit_pnl_pct':round(float(virtual),6),'improvement_pct':round(float(virtual)-float(actual),6),'winner_damage':bool(float(actual)>0 and float(virtual)<float(actual))}
        rec['actual_closed_pnl_pct']=round(float(actual),6); rec['closed_match']='EXACT_POS_ID' if rec.get('pos_id') and rec.get('pos_id') in closed_by_pos else 'EXACT_DECISION_KEY'; rec['policy_results']=results; rec['finalized_ts']=nowv
        finalized[ident]=rec; active.pop(ident,None)
        _v2010_append_jsonl(UNIFIED_SHADOW_PROFIT_LEDGER_V2010,{'schema':'shadow_profit_exit_event_v2010','event':'ACTUAL_CLOSE_COMPARE','identity':ident,'ticker':rec.get('ticker'),'ts':nowv,'time':now_text(nowv),'actual_pnl_pct':actual,'closed_match':rec.get('closed_match'),'policy_results':results,'actual_exit_changed':False,'auto_buy':False})
    cutoff=nowv-UNIFIED_SHADOW_STATE_RETENTION_SEC_V2010
    finalized={k:v for k,v in finalized.items() if float(v.get('finalized_ts') or 0)>=cutoff}
    state['profit_active']=active; state['profit_finalized']=finalized
    policy_stats=[]
    for code,cfg in _V2010_PROFIT_POLICIES.items():
        triggered=sum(1 for r in list(active.values())+list(finalized.values()) if code in (r.get('policies') or {}))
        matched=[(r.get('policy_results') or {}).get(code) for r in finalized.values() if isinstance((r.get('policy_results') or {}).get(code),dict)]
        imp=[float(x.get('improvement_pct') or 0) for x in matched]; damage=sum(1 for x in matched if x.get('winner_damage'))
        policy_stats.append({'policy':code,'label':cfg['label'],'triggered':triggered,'matched_closed':len(matched),'improvement_sum_pct':round(sum(imp),4),'improvement_avg_pct':round(sum(imp)/len(imp),4) if imp else None,'winner_damage_count':damage})
    perf=_cs_performance_summary_v1141(closed_rows)
    def expansion_watch(lo: float, hi: float) -> Dict[str,Any]:
        rows=[]; gaps=[]
        for rr in closed_rows:
            mfe=_cs_num_v1141(rr.get('mfe_pct'),rr.get('max_profit_pct'),rr.get('max_pnl_pct')); pnl=_cs_row_pnl_v1141(rr)
            if mfe is None or pnl is None or not (lo<=float(mfe)<hi): continue
            rows.append(rr); gaps.append(max(0.0,float(mfe)-float(pnl)))
        return {**_v2010_perf(rows),'capture_gap_median_pct':_cs_median_v1141(gaps),'capture_gap_mean_pct':_cs_mean_v1141(gaps)}
    three_to_one_like=[rr for rr in closed_rows if (_cs_num_v1141(rr.get('mfe_pct'),rr.get('max_profit_pct'),0) or 0)>=3.0 and (_cs_row_pnl_v1141(rr) is not None and float(_cs_row_pnl_v1141(rr))<=1.5)]
    expansion={'three_to_one_like_count':len(three_to_one_like),'mfe_3_5':expansion_watch(3.0,5.0),'mfe_5_plus':expansion_watch(5.0,1e99)}
    bucket_defs=(('MFE 1~2',1,2),('MFE 2~4',2,4),('MFE 4~8',4,8),('MFE 8+',8,1e99))
    mfe_buckets=[]
    for name,lo,hi in bucket_defs:
        bucket=[r for r in closed_rows if (lambda m:m is not None and lo<=m<hi)(_cs_num_v1141(r.get('mfe_pct'),r.get('max_profit_pct'),r.get('max_pnl_pct')))]
        ptl=sum(1 for r in bucket if (_cs_num_v1141(r.get('mfe_pct'),r.get('max_profit_pct'),0) or 0)>0 and (_cs_row_pnl_v1141(r) or 0)<0)
        give=[max(0.0,float(_cs_num_v1141(r.get('mfe_pct'),r.get('max_profit_pct'),0) or 0)-float(_cs_row_pnl_v1141(r) or 0)) for r in bucket]
        mfe_buckets.append({'name':name,**_v2010_perf(bucket),'profit_to_loss_count':ptl,'giveback_median_pct':_cs_median_v1141(give)})
    return {'state':'ACTIVE','current_open_tracked':len(active),'finalized_shadow_positions':len(finalized),'fresh_closed_summary':perf,'profit_to_loss_count':perf.get('profit_to_loss_count'),'giveback_median_pct':perf.get('giveback_median_pct'),'expansion_watch':expansion,'policies':policy_stats,'mfe_buckets':mfe_buckets,'historical_reference':{'v1436_3_5_runner_actual_sum_pct':6.12,'v1436_3_5_runner_shadow_sum_pct':7.81,'v1436_improvement_pct':1.69,'v1436_winner_damage':0,'reference_only':True},'policy':'prospective virtual exits use shadow-local observed PnL peak only; actual trailing/target/exit unchanged'}



# =============================================================================
# Review v2.011: structure + strength profit-protection shadow
# Prospective only. The fixed giveback policies above stay as statistics/benchmarks.
# A virtual exit is emitted only after exact structure support is linked by the same
# direct decision key and weakness persists across consecutive Review observations.
# =============================================================================

def _v2011_metric_from_sources(row: Dict[str,Any], feature: Dict[str,Any], orderflow: Dict[str,Any], keys: tuple[str,...]) -> Optional[float]:
    for source in (orderflow, feature, row):
        if not isinstance(source,dict):
            continue
        for key in keys:
            value=_cs_num_v1141(source.get(key))
            if value is not None:
                return float(value)
    return None


def _v2011_strength_metrics(row: Dict[str,Any], feature: Dict[str,Any], orderflow: Dict[str,Any]) -> Dict[str,Optional[float]]:
    return {
        'vwap_gap_pct':_v2011_metric_from_sources(row,feature,orderflow,('vwap_gap_pct',)),
        'ema_gap_pct':_v2011_metric_from_sources(row,feature,orderflow,('ema5_gap_pct','ma5_gap_pct','ema10_gap_pct')),
        'relative_strength':_v2011_metric_from_sources(row,feature,orderflow,('relative_strength_pct','relative_strength')),
        'money_flow':_v2011_metric_from_sources(row,feature,orderflow,('money_flow_score','money_flow')),
        'buy_ratio':_v2011_metric_from_sources(row,feature,orderflow,('buy_ratio','micro_trade_buy_ratio_30','buy_strength')),
        'buy_sustain':_v2011_metric_from_sources(row,feature,orderflow,('buy_sustain_1m','buy_sustain_60s','micro_buy_ratio_sustain_1m')),
        'orderflow_score':_v2011_metric_from_sources(row,feature,orderflow,('orderflow_score','trade_flow_score')),
    }


def _v2011_metric_drop(current: Optional[float], baseline: Optional[float], previous: Optional[float]) -> bool:
    return current is not None and baseline is not None and previous is not None and current < baseline and current < previous


def _v2011_metric_recover(current: Optional[float], previous: Optional[float]) -> bool:
    return current is not None and previous is not None and current > previous


def _v2011_exact_support_for_decision(state: Dict[str,Any], decision_key: str, row: Optional[Dict[str,Any]]=None) -> Optional[Dict[str,Any]]:
    if not decision_key:
        return None
    # v2024: the OPEN row already seals the exact invalid/structure line under the same
    # direct decision key. Read it before the separate structure Shadow state.
    sealed=row if isinstance(row,dict) else {}
    row_decision=_v2010_exact_event_key(sealed) if sealed else ''
    if sealed and (not row_decision or row_decision==decision_key):
        gate=_cs_gate_v1141(sealed)
        plans=[]
        for candidate,source_name in (
            (sealed.get('swing_structure_plan_v977'),'OPEN.swing_structure_plan_v977.invalid'),
            (gate.get('structure_plan') if isinstance(gate,dict) else None,'OPEN.swing_entry_gate_v977.structure_plan.invalid'),
        ):
            if isinstance(candidate,dict): plans.append((candidate,source_name))
        for plan,source_name in plans:
            support=plan.get('invalid') if isinstance(plan.get('invalid'),dict) else None
            price=_v2010_price(support)
            if price is not None:
                return {'price':float(price),'tf':support.get('tf') or support.get('timeframe'),'source':support.get('source') or support.get('source_key') or source_name,'event_key':decision_key,'proxy_used':False,'sealed_open_source_v2024':True}
        evidence=sealed.get('entry_evidence_v983') if isinstance(sealed.get('entry_evidence_v983'),dict) else {}
        support=evidence.get('invalid') if isinstance(evidence.get('invalid'),dict) else None
        price=_v2010_price(support)
        if price is not None:
            return {'price':float(price),'tf':support.get('timeframe') or support.get('tf'),'source':support.get('source') or 'OPEN.entry_evidence_v983.invalid','event_key':decision_key,'proxy_used':False,'sealed_open_source_v2024':True}
        profitability=sealed.get('profitability_entry_evidence_v1034') if isinstance(sealed.get('profitability_entry_evidence_v1034'),dict) else {}
        price=_cs_num_v1141(profitability.get('invalid_price'))
        if price is not None and price>0:
            return {'price':float(price),'tf':None,'source':'OPEN.profitability_entry_evidence_v1034.invalid_price','event_key':decision_key,'proxy_used':False,'sealed_open_source_v2024':True}
    structures=state.get('structure_active') if isinstance(state.get('structure_active'),dict) else {}
    rec=structures.get(decision_key) if isinstance(structures.get(decision_key),dict) else None
    if not isinstance(rec,dict):
        return None
    selected=rec.get('shadow_selected') if isinstance(rec.get('shadow_selected'),dict) else {}
    support=selected.get('invalid') if isinstance(selected.get('invalid'),dict) else None
    price=_v2010_price(support)
    if price is None:
        return None
    return {'price':float(price),'tf':support.get('tf'),'source':support.get('source') or support.get('source_key'),'event_key':decision_key,'proxy_used':False,'sealed_open_source_v2024':False}


def _v2011_structure_strength_protection_shadow(nowv: float, closed_rows: List[Dict[str,Any]], fmap: Dict[str,Dict[str,Any]], ofmap: Dict[str,Dict[str,Any]], state: Dict[str,Any]) -> Dict[str,Any]:
    active=state.get('strength_protection_active_v2011') if isinstance(state.get('strength_protection_active_v2011'),dict) else {}
    finalized=state.get('strength_protection_finalized_v2011') if isinstance(state.get('strength_protection_finalized_v2011'),dict) else {}
    open_rows=_v923_open_rows()
    current_ids=set()
    transition_events=0
    virtual_exit_events=0

    for row in open_rows:
        if not isinstance(row,dict):
            continue
        pos=_v2010_exact_pos_key(row); decision=_v2010_exact_event_key(row)
        ident=('pos:'+pos) if pos else (('decision:'+decision) if decision else '')
        if not ident:
            continue
        current_ids.add(ident)
        ticker=_cs_ticker_v1141(row)
        feature=fmap.get(ticker,{}) if ticker else {}
        orderflow=ofmap.get(ticker,{}) if ticker else {}
        pnl=_cs_row_pnl_v1141(row)
        price=_current_price(ticker,fmap,ofmap) if ticker else None
        if price is None or float(price)<=0:
            price=_cs_num_v1141(row.get('current_price'),row.get('price'),row.get('last_price'))
        if pnl is None or price is None or float(price)<=0:
            continue
        metrics=_v2011_strength_metrics(row,feature if isinstance(feature,dict) else {},orderflow if isinstance(orderflow,dict) else {})
        support=_v2011_exact_support_for_decision(state,decision,row)
        rec=active.get(ident) if isinstance(active.get(ident),dict) else None
        if rec is None:
            rec={
                'identity':ident,'pos_id':pos or None,'decision_key':decision or None,'ticker':ticker,
                'observed_ts':nowv,'observed_text':now_text(nowv),'shadow_peak_pct':float(pnl),
                'baseline_metrics':dict(metrics),'prior_metrics':dict(metrics),'last_pnl_pct':float(pnl),
                'weak_streak':0,'recovery_streak':0,'had_weakness_watch':False,
                'fake_shake_recovery_count':0,'classification':'SEED','support':support,
                'virtual_exit':None,'actual_exit_changed':False,'auto_buy':False,
            }
            active[ident]=rec
            continue

        # Fill only previously missing baseline values; never replace an observed baseline value.
        baseline=rec.get('baseline_metrics') if isinstance(rec.get('baseline_metrics'),dict) else {}
        for key,value in metrics.items():
            if baseline.get(key) is None and value is not None:
                baseline[key]=value
        rec['baseline_metrics']=baseline
        prior=rec.get('prior_metrics') if isinstance(rec.get('prior_metrics'),dict) else {}
        if support is not None:
            rec['support']=support
        support_obj=rec.get('support') if isinstance(rec.get('support'),dict) else None
        support_price=_v2010_price(support_obj)
        vwap=metrics.get('vwap_gap_pct'); ema=metrics.get('ema_gap_pct')
        rs=metrics.get('relative_strength')
        location_available=bool(vwap is not None and ema is not None)
        rs_available=bool(rs is not None)
        flow_available=sum(1 for k in ('money_flow','buy_sustain','buy_ratio','orderflow_score') if metrics.get(k) is not None and prior.get(k) is not None)
        strength_source_groups=sum((1 if location_available else 0,1 if rs_available else 0,1 if flow_available>=2 else 0))
        source_ready=bool(support_price is not None and strength_source_groups>=2)

        peak=max(float(rec.get('shadow_peak_pct') or pnl),float(pnl))
        rec['shadow_peak_pct']=peak
        pullback=bool(peak>0 and float(pnl)<peak)
        structure_broken=bool(source_ready and float(price)<float(support_price))
        structure_reclaimed=bool(source_ready and float(price)>=float(support_price))
        location_weak=bool(vwap is not None and ema is not None and vwap<0 and ema<0)
        location_recovered=bool(vwap is not None and ema is not None and vwap>=0 and ema>=0)
        rs_weak=bool(_v2011_metric_drop(rs,baseline.get('relative_strength'),prior.get('relative_strength')) and rs is not None and rs<=0)

        flow_votes=[]
        flow_votes.append(_v2011_metric_drop(metrics.get('money_flow'),baseline.get('money_flow'),prior.get('money_flow')))
        flow_votes.append(_v2011_metric_drop(metrics.get('buy_sustain'),baseline.get('buy_sustain'),prior.get('buy_sustain')))
        buy=metrics.get('buy_ratio')
        flow_votes.append(bool(buy is not None and prior.get('buy_ratio') is not None and buy<0.5 and buy<float(prior.get('buy_ratio'))))
        ofscore=metrics.get('orderflow_score')
        flow_votes.append(bool(ofscore is not None and prior.get('orderflow_score') is not None and ofscore<0 and ofscore<float(prior.get('orderflow_score'))))
        flow_weak=bool(flow_available>=2 and sum(1 for vote in flow_votes if vote)>=2)
        strength_weak_count=sum((1 if location_weak else 0,1 if rs_weak else 0,1 if flow_weak else 0))
        weakness_candidate=bool(pullback and source_ready and structure_broken and strength_weak_count>=2)

        recovery_votes=[
            _v2011_metric_recover(metrics.get('relative_strength'),prior.get('relative_strength')),
            _v2011_metric_recover(metrics.get('money_flow'),prior.get('money_flow')),
            _v2011_metric_recover(metrics.get('buy_sustain'),prior.get('buy_sustain')),
            _v2011_metric_recover(metrics.get('buy_ratio'),prior.get('buy_ratio')),
            _v2011_metric_recover(metrics.get('orderflow_score'),prior.get('orderflow_score')),
        ]
        strength_recovering=bool(sum(1 for vote in recovery_votes if vote)>=2)
        recovery_candidate=bool(source_ready and (structure_reclaimed or location_recovered) and strength_recovering)

        if weakness_candidate:
            rec['weak_streak']=int(rec.get('weak_streak') or 0)+1
            rec['recovery_streak']=0
            rec['had_weakness_watch']=True
        elif recovery_candidate and rec.get('had_weakness_watch'):
            rec['recovery_streak']=int(rec.get('recovery_streak') or 0)+1
            rec['weak_streak']=0
        else:
            rec['weak_streak']=0
            rec['recovery_streak']=0

        if not source_ready:
            classification='SOURCE_MISSING'
        elif rec.get('virtual_exit'):
            classification='TRUE_WEAKNESS_EXIT_SEALED'
        elif int(rec.get('weak_streak') or 0)>=2:
            classification='TRUE_WEAKNESS'
        elif int(rec.get('recovery_streak') or 0)>=2:
            classification='FAKE_SHAKE_RECOVERED'
        elif weakness_candidate:
            classification='WEAKNESS_WATCH'
        elif pullback:
            classification='NORMAL_SHAKE'
        else:
            classification='UP_OR_FLAT'

        previous_classification=str(rec.get('classification') or '')
        if classification=='FAKE_SHAKE_RECOVERED' and previous_classification!='FAKE_SHAKE_RECOVERED':
            rec['fake_shake_recovery_count']=int(rec.get('fake_shake_recovery_count') or 0)+1
            rec['had_weakness_watch']=False
        if classification!=previous_classification:
            transition_events+=1
            _v2010_append_jsonl(UNIFIED_SHADOW_PROFIT_LEDGER_V2010,{
                'schema':'shadow_structure_strength_event_v2011','event':'STATE_TRANSITION','identity':ident,
                'pos_id':pos or None,'decision_key':decision or None,'ticker':ticker,'ts':nowv,'time':now_text(nowv),
                'from_state':previous_classification or None,'to_state':classification,'pnl_pct':round(float(pnl),6),
                'shadow_peak_pct':round(float(peak),6),'price':float(price),'support':support_obj,
                'evidence':{'structure_broken':structure_broken,'structure_reclaimed':structure_reclaimed,'location_weak':location_weak,'location_recovered':location_recovered,'rs_weak':rs_weak,'flow_weak':flow_weak,'strength_weak_count':strength_weak_count,'strength_recovering':strength_recovering,'strength_source_groups':strength_source_groups,'weak_streak':rec.get('weak_streak'),'recovery_streak':rec.get('recovery_streak')},
                'metrics':metrics,'proxy_used':False,'actual_exit_changed':False,'auto_buy':False,
            })
        rec['classification']=classification

        if classification=='TRUE_WEAKNESS' and not rec.get('virtual_exit'):
            event={'triggered_ts':nowv,'triggered_text':now_text(nowv),'virtual_exit_pnl_pct':round(float(pnl),6),'shadow_peak_pct':round(float(peak),6),'price':float(price),'support':support_obj,'reason':'exact support break + persistent weakness across location/relative-strength/flow evidence'}
            rec['virtual_exit']=event; virtual_exit_events+=1
            _v2010_append_jsonl(UNIFIED_SHADOW_PROFIT_LEDGER_V2010,{
                'schema':'shadow_structure_strength_event_v2011','event':'VIRTUAL_EXIT','identity':ident,
                'pos_id':pos or None,'decision_key':decision or None,'ticker':ticker,'ts':nowv,'time':now_text(nowv),
                **event,'proxy_used':False,'actual_exit_changed':False,'auto_buy':False,
            })
            rec['classification']='TRUE_WEAKNESS_EXIT_SEALED'

        rec['prior_metrics']=dict(metrics); rec['last_pnl_pct']=float(pnl); rec['last_price']=float(price); rec['last_seen_ts']=nowv

    closed_by_pos={}; closed_by_decision={}
    for row in closed_rows:
        pos=_v2010_exact_pos_key(row); decision=_v2010_exact_event_key(row)
        if pos: closed_by_pos[pos]=row
        if decision: closed_by_decision[decision]=row
    for ident,rec in list(active.items()):
        if ident in current_ids:
            continue
        closed=None
        if rec.get('pos_id'): closed=closed_by_pos.get(str(rec.get('pos_id')))
        if closed is None and rec.get('decision_key'): closed=closed_by_decision.get(str(rec.get('decision_key')))
        if closed is None:
            continue
        actual=_cs_row_pnl_v1141(closed)
        if actual is None:
            continue
        virtual=rec.get('virtual_exit') if isinstance(rec.get('virtual_exit'),dict) else None
        comparison=None
        if virtual and _cs_num_v1141(virtual.get('virtual_exit_pnl_pct')) is not None:
            vp=float(_cs_num_v1141(virtual.get('virtual_exit_pnl_pct')))
            comparison={'actual_pnl_pct':round(float(actual),6),'virtual_exit_pnl_pct':round(vp,6),'improvement_pct':round(vp-float(actual),6),'winner_damage':bool(float(actual)>0 and vp<float(actual))}
        rec['actual_closed_pnl_pct']=round(float(actual),6); rec['comparison']=comparison
        rec['closed_match']='EXACT_POS_ID' if rec.get('pos_id') and rec.get('pos_id') in closed_by_pos else 'EXACT_DECISION_KEY'
        rec['finalized_ts']=nowv; finalized[ident]=rec; active.pop(ident,None)
        _v2010_append_jsonl(UNIFIED_SHADOW_PROFIT_LEDGER_V2010,{
            'schema':'shadow_structure_strength_event_v2011','event':'ACTUAL_CLOSE_COMPARE','identity':ident,
            'pos_id':rec.get('pos_id'),'decision_key':rec.get('decision_key'),'ticker':rec.get('ticker'),'ts':nowv,'time':now_text(nowv),
            'actual_pnl_pct':round(float(actual),6),'closed_match':rec.get('closed_match'),'comparison':comparison,
            'fake_shake_recovery_count':rec.get('fake_shake_recovery_count',0),'proxy_used':False,'actual_exit_changed':False,'auto_buy':False,
        })

    cutoff=nowv-UNIFIED_SHADOW_STATE_RETENTION_SEC_V2010
    finalized={k:v for k,v in finalized.items() if float(v.get('finalized_ts') or 0)>=cutoff}
    state['strength_protection_active_v2011']=active; state['strength_protection_finalized_v2011']=finalized
    comparisons=[r.get('comparison') for r in finalized.values() if isinstance(r.get('comparison'),dict)]
    improvements=[float(r.get('improvement_pct') or 0) for r in comparisons]
    current_counts=Counter(str(r.get('classification') or 'UNKNOWN') for r in active.values())
    fake_total=sum(int(r.get('fake_shake_recovery_count') or 0) for r in list(active.values())+list(finalized.values()))
    virtual_total=sum(1 for r in list(active.values())+list(finalized.values()) if isinstance(r.get('virtual_exit'),dict))
    samples=[]
    for rec in sorted(active.values(),key=lambda r:float(r.get('last_seen_ts') or 0),reverse=True):
        if len(samples)>=5: break
        samples.append({'ticker':rec.get('ticker'),'classification':rec.get('classification'),'pnl_pct':rec.get('last_pnl_pct'),'peak_pct':rec.get('shadow_peak_pct'),'support':rec.get('support'),'weak_streak':rec.get('weak_streak'),'recovery_streak':rec.get('recovery_streak')})
    return {
        'state':'ACTIVE' if open_rows or finalized else 'COLLECTING','current_open_tracked':len(active),'source_ready_current':sum(1 for r in active.values() if str(r.get('classification') or '')!='SOURCE_MISSING'),
        'source_missing_current':sum(1 for r in active.values() if str(r.get('classification') or '')=='SOURCE_MISSING'),'current_state_counts':dict(current_counts),
        'fake_shake_recovered_total':fake_total,'true_weakness_virtual_exit_total':virtual_total,'matched_closed':len(comparisons),
        'improvement_sum_pct':round(sum(improvements),6),'improvement_avg_pct':round(sum(improvements)/len(improvements),6) if improvements else None,
        'winner_damage_count':sum(1 for r in comparisons if r.get('winner_damage')),'transition_events_this_cycle':transition_events,'virtual_exit_events_this_cycle':virtual_exit_events,
        'sample':samples,'policy':'prospective structure+strength protection: exact linked support required; weakness must persist for 2 consecutive Review observations with support broken plus at least 2 independent strength groups weak. Recovery requires support/VWAP-EMA recovery plus improving strength. Fixed giveback percentages remain statistics only; actual exit unchanged.',
        'locks':{'ticker_time_proximity_match':False,'proxy_structure':False,'actual_exit_changed':False,'auto_buy':False},
    }


def _v2010_no_progress_shadow(closed_rows: List[Dict[str,Any]]) -> Dict[str,Any]:
    rows=[]
    for r in closed_rows:
        reason=str(r.get('exit_reason') or r.get('close_reason') or r.get('reason') or '').lower()
        if 'no_progress' in reason or '6h' in reason or '무반응' in reason or '약세' in reason: rows.append(r)
    zero_positive=sum(1 for r in rows if (_cs_num_v1141(r.get('mfe_pct'),r.get('max_profit_pct'),0) or 0)<=0)
    return {'state':'ACTIVE' if closed_rows else 'COLLECTING','current_no_progress':_v2010_perf(rows),'zero_positive_mfe_count':zero_positive,'historical_reference':{'v1438_no_progress_trades':18,'actual_sum_pct':-33.46,'early_1_3h_shadow_sum_pct':-13.59,'improvement_pct':19.87,'winner_damage_count':0,'pre_entry_filter_similar_winner_damage':29,'reference_only':True},'policy':'cause/replay shadow only; fixed quick stop and entry block remain disabled'}


def _v2010_buried_shadow(summary: Dict[str,Any], good_s2: Dict[str,Any], quality_shadow: Dict[str,Any]) -> Dict[str,Any]:
    return {'state':'ACTIVE','tracking_total':summary.get('tracking_total'),'missed_count':summary.get('missed_count'),'regret_count':summary.get('regret_count'),'late_rise_count':summary.get('late_rise_count'),'risk_rise_count':summary.get('risk_rise_count'),'pending_count':summary.get('pending_count'),'good_s2_tracked':good_s2.get('tracked_total') if isinstance(good_s2,dict) else None,'good_s2_opened_exact':good_s2.get('opened_exact') if isinstance(good_s2,dict) else None,'quality_shadow_tracked':quality_shadow.get('tracked_records') if isinstance(quality_shadow,dict) else None,'policy':'observation only; no forced S1/Paper/OPEN promotion'}


def _v2010_unified_shadow_cycle_update(nowv: float, candidate_rows: List[Dict[str,Any]], closed_rows: List[Dict[str,Any]], fmap: Dict[str,Dict[str,Any]], ofmap: Dict[str,Dict[str,Any]], summary: Dict[str,Any], good_s2: Dict[str,Any], quality_shadow: Dict[str,Any]) -> Dict[str,Any]:
    _v2010_flush_shadow_event_batches()  # retry a prior failed shadow batch before new events
    state=_v2010_shadow_state()
    structure=_v2010_structure_shadow(nowv,candidate_rows,fmap,ofmap,state)
    quality=_v2010_quality_shadow(closed_rows)
    profit=_v2010_profit_shadow(nowv,closed_rows,state)
    strength_protection=_v2011_structure_strength_protection_shadow(nowv,closed_rows,fmap,ofmap,state)
    profit['structure_strength_protection']=strength_protection
    no_progress=_v2010_no_progress_shadow(closed_rows)
    buried=_v2010_buried_shadow(summary,good_s2,quality_shadow)
    board={'schema':'unified_shadow_status_v2011','version':VERSION,'build':BUILD_LABEL,'updated_ts':nowv,'updated_text':now_text(nowv),'state':'ACTIVE','structure_3price':structure,'candidate_quality':quality,'profit_giveback':profit,'no_progress':no_progress,'buried_candidates':buried,'promotion_locks':{'minimum_snapshots':3,'minimum_target_sample':30,'max_winner_damage_count':1,'recent_and_full_no_worse':True,'user_approval_required':True},'locks':{'actual_candidate_flow_changed':False,'actual_s1_changed':False,'actual_paper_selector_changed':False,'actual_open_changed':False,'actual_trigger_changed':False,'actual_invalid_changed':False,'actual_target_changed':False,'actual_exit_changed':False,'auto_buy':False}}
    state.update({'schema':'unified_shadow_active_state_v2010','version':VERSION,'build':BUILD_LABEL,'updated_ts':nowv,'updated_text':now_text(nowv)})
    state_checkpointed=_v2010_checkpoint_shadow_state(state)
    save_json(UNIFIED_SHADOW_STATUS_V2010,board)
    snapshot_sig=hashlib.sha256(json.dumps({'structure_h':structure.get('horizon_completed'),'quality_best':quality.get('best_min_n3'),'profit':profit.get('policies'),'strength_protection':profit.get('structure_strength_protection'),'no_progress':no_progress.get('current_no_progress'),'buried':buried},ensure_ascii=False,sort_keys=True,default=str,separators=(',',':')).encode('utf-8')).hexdigest()[:20]
    prev=str(state.get('last_snapshot_signature') or '')
    last_snapshot=float(state.get('last_snapshot_event_ts') or 0)
    if snapshot_sig!=prev and (nowv-last_snapshot>=UNIFIED_SHADOW_SNAPSHOT_LEDGER_CADENCE_SEC_V2010 or not UNIFIED_SHADOW_SNAPSHOT_LEDGER_V2010.exists()):
        _v2010_append_jsonl(UNIFIED_SHADOW_SNAPSHOT_LEDGER_V2010,{'schema':'unified_shadow_snapshot_event_v2010','ts':nowv,'time':now_text(nowv),'signature':snapshot_sig,'structure_horizon_completed':structure.get('horizon_completed'),'quality_best_min_n3':quality.get('best_min_n3'),'profit_policies':profit.get('policies'),'strength_protection':profit.get('structure_strength_protection'),'no_progress':no_progress.get('current_no_progress'),'buried':buried,'locks':board['locks']})
        state['last_snapshot_signature']=snapshot_sig; state['last_snapshot_event_ts']=nowv
    batch_flush=_v2010_flush_shadow_event_batches()
    board['writer_runtime_v2010']={'state_checkpointed':state_checkpointed,'state_checkpoint_sec':UNIFIED_SHADOW_STATE_CHECKPOINT_SEC_V2010,'snapshot_ledger_cadence_sec':UNIFIED_SHADOW_SNAPSHOT_LEDGER_CADENCE_SEC_V2010,'event_batch_flush':batch_flush}
    save_json(UNIFIED_SHADOW_STATUS_V2010,board)
    return board



def _v2011_review_issue_once() -> None:
    marker=BASE_DIR/'runtime'/'v2011_structure_strength_profit_protection.seeded'
    if marker.exists(): return
    ts=now_ts(); text=now_text(ts)
    try:
        _v2010_append_jsonl(BASE_DIR/'runtime'/'change_verify_ledger.jsonl',{'schema':'change_verify_ledger_v870','change_id':'v2011-structure-strength-profit-protection-001','issue_id':'SHADOW-PROFIT-PROTECTION-2011','version':'v2011','verify_result':'CHECK','created_ts':ts,'created_at':text,'created_text':text,'writer':'review_v2011_lifecycle_writer','symptom':'Fixed giveback thresholds can confuse normal/fake pullbacks with genuine trend failure and may protect profit too early or too late.','cause':'v2010 prospective profit policies observe only peak and giveback magnitude; they do not combine exact linked support, VWAP/EMA recovery, relative strength, money flow, buy sustain and orderflow persistence.','files_changed':['review_worker_v2.011.py','coinbot_main_v2_13_2011.py'],'new_mainline':'Keep v2010 fixed policies as statistics. Add a prospective structure+strength protection shadow under the same /shadow status. Exact decision-key linked support is mandatory; weakness must persist across consecutive Review observations and recovery is tracked separately as fake-shake recovery.','not_touched':['actual exit/trailing','actual candidate/S1/Paper/OPEN','trigger/invalid/target','RR/room/chase/cost gates','protected ledgers','Guard v2008','Paper v2009','Strategy v2010','auto-buy OFF'],'remaining':'Server must collect at least 3 snapshots and enough exact-linked OPEN/CLOSED samples; compare improvement and winner damage before any promotion.','auto_buy':False})
        _v2010_append_jsonl(BASE_DIR/'ledger'/'issue_ledger_events.jsonl',{'schema':'coinbot_single_work_ledger_v870','event_type':'ISSUE','issue_id':'SHADOW-PROFIT-PROTECTION-2011','status':'CHECK','title':'가짜 흔들림과 진짜 약세 수익보호 shadow','detail':'정확 지지선 + 힘 약화 지속/회복을 prospective shadow로만 비교. 실제 청산 무변경.','version':'v2011','created_ts':ts,'created_at':text,'created_text':text,'auto_buy':False})
        marker.parent.mkdir(parents=True,exist_ok=True); marker.write_text(text,encoding='utf-8')
    except Exception: pass

try: _v2011_review_issue_once()
except Exception: pass


def _v2010_review_issue_once() -> None:
    marker=BASE_DIR/'runtime'/'v2010_unified_shadow.seeded'
    if marker.exists(): return
    ts=now_ts(); text=now_text(ts)
    try:
        _v2010_append_jsonl(BASE_DIR/'runtime'/'change_verify_ledger.jsonl',{'schema':'change_verify_ledger_v870','change_id':'v2010-unified-shadow-001','issue_id':'UNIFIED-SHADOW-2010','version':'v2010','verify_result':'CHECK','created_ts':ts,'created_at':text,'created_text':text,'writer':'review_v2010_lifecycle_writer','symptom':'Structure, quality, profit giveback, no-progress and buried-candidate shadows were split across old commands or absent from the current rebuilt lineage. Current fresh CLOSED also shows large giveback and profit-to-loss transitions.','cause':'v1400-era shadow writers were not carried into the v1401-based current lineage; structure comparison also lacked exact unselected timeframe source scalars.','files_changed':['review_worker_v2.010.py','strategy_worker_v2.010.py','coinbot_main_v2_13_2010.py'],'new_mainline':'Review single owner writes one unified shadow status and append-only event ledgers. Main /shadow reads one status file only. Structure compares exact 3 prices/timeframes without proxy; profit policies are prospective virtual exits using shadow-local observed peaks.','not_touched':['actual candidate flow','actual S1/Paper selector','actual OPEN','trigger/invalid/target','RR/room/chase/cost gates','actual exit/trailing','protected ledgers','auto-buy OFF'],'remaining':'Server must prove /shadow writer/status freshness, exact-source coverage, prospective policy sample growth, no winner damage promotion and no Review-cycle regression.','auto_buy':False})
        _v2010_append_jsonl(BASE_DIR/'ledger'/'issue_ledger_events.jsonl',{'schema':'coinbot_single_work_ledger_v870','event_type':'ISSUE','issue_id':'UNIFIED-SHADOW-2010','status':'CHECK','title':'통합 /shadow 정확정보·후보품질·수익반납 비교','detail':'Review 단일 writer. 본선 매매계약 무변경. 서버 표본 수집 필요.','version':'v2010','created_ts':ts,'created_at':text,'created_text':text,'auto_buy':False})
        marker.parent.mkdir(parents=True,exist_ok=True); marker.write_text(text,encoding='utf-8')
    except Exception: pass

try: _v2010_review_issue_once()
except Exception: pass

def run_once() -> Dict[str, Any]:
    for _pending in _DEDUP_PENDING_V1013.values(): _pending.clear()
    _JSON_CYCLE_CACHE.clear()
    _JSONL_CYCLE_CACHE.clear()
    _PHASE_MEMORY_SAMPLES.clear()
    _PHASE_IO_SAMPLES_V1011.clear()
    phase_timings: Dict[str, float] = {}
    st = now_ts(); set_review_phase("refreshing"); write_status("running", phase="refreshing", last_sec=0, json_reader_v1008="streaming_stat_keyed_single_cycle", jsonl_reader_v1008="tail_and_incremental_count")
    queue = load_json(QUEUE, {}) or {}
    qrows = queue.get("review_candidates") if isinstance(queue, dict) and isinstance(queue.get("review_candidates"), list) else []
    # v446: review state에 이미 들어간 구 후보도 구조태그가 보이도록 현재 후보 snapshot/queue와 표시용 파생값으로 보강한다.
    paper_source_rows = [r for r in read_jsonl(PAPER_LATEST, max_lines=SOURCE_SNAPSHOT_LINES) if isinstance(r, dict)]
    canonical_closed_snapshot_v1015 = load_json(CANONICAL_PERFORMANCE_V987, {}) or {}
    closed_rows_cycle = [r for r in (canonical_closed_snapshot_v1015.get('rows') if isinstance(canonical_closed_snapshot_v1015, dict) and isinstance(canonical_closed_snapshot_v1015.get('rows'), list) else []) if isinstance(r, dict)]
    source_rows = paper_source_rows + [r for r in qrows if isinstance(r, dict)]
    structure_sources: Dict[str, Dict[str, Any]] = {}
    for sr in source_rows:
        tt = ticker_norm(sr.get("ticker") or sr.get("symbol") or sr.get("market"))
        if tt and (_has_structure(sr) or _has_market(sr)):
            structure_sources[tt] = sr
    state = load_json(STATE, {}) or {}
    active = state.get("active") if isinstance(state.get("active"), dict) else {}
    fmap = map_rows(load_json(FEATURE, {}) or {})
    ofmap = map_rows(load_json(ORDERFLOW, {}) or {})
    regime = load_json(REGIME, {}) or {}
    nowv = now_ts()
    set_review_phase('trigger_shadow')
    _phase_t = time.monotonic()
    try:
        trigger_shadow_v665 = _v665_trigger_shadow_update(nowv, fmap, ofmap)
    except Exception as exc:
        append_error(ERROR, "v665_trigger_shadow_update", exc)
        trigger_shadow_v665 = {"schema":"trigger_shadow_review_v665_error", "error": f"{exc.__class__.__name__}: {exc}"}
    _finish_review_phase_v1009('trigger_shadow', _phase_t, phase_timings)
    set_review_phase('market_miss')
    _phase_t = time.monotonic()
    try:
        market_miss_v667 = _v667_market_miss_update(nowv, fmap, ofmap)
    except Exception as exc:
        append_error(ERROR, "v667_market_miss_update", exc)
        market_miss_v667 = {"schema":"market_miss_review_v667_error", "error": f"{exc.__class__.__name__}: {exc}"}
    _finish_review_phase_v1009('market_miss', _phase_t, phase_timings)
    set_review_phase('good_s2_result')
    _phase_t = time.monotonic()
    try:
        good_s2_result_v923 = _v923_update_good_s2_results(nowv, fmap, ofmap, closed_rows_cycle)
    except Exception as exc:
        append_error(ERROR, 'v923_good_s2_result_update', exc)
        good_s2_result_v923 = {'schema':'good_s2_result_snapshot_v923_error','error':f'{exc.__class__.__name__}: {exc}'}
    _finish_review_phase_v1009('good_s2_result', _phase_t, phase_timings)
    set_review_phase('quality_shadow')
    _phase_t = time.monotonic()
    _quality_status_runtime_v1014(nowv,'RUNNING')
    try:
        quality_shadow, qrecords = update_quality_shadow(nowv, fmap, ofmap, paper_source_rows, regime if isinstance(regime,dict) else {})
    except Exception as exc:
        append_error(ERROR, 'quality_shadow_update', exc)
        err_text=f'{exc.__class__.__name__}: {exc}'
        quality_shadow = _quality_status_runtime_v1014(nowv,'ERROR',err_text); quality_shadow['error']=err_text; qrecords=[]
    _finish_review_phase_v1009('quality_shadow', _phase_t, phase_timings)
    set_review_phase('quality_policy_comparison_v1120')
    _phase_t = time.monotonic()
    try:
        quality_policy_comparison_v1120 = update_quality_policy_comparison_v1120(nowv,qrecords)
    except Exception as exc:
        append_error(ERROR,'quality_policy_comparison_v1120',exc)
        quality_policy_comparison_v1120={'schema':'quality_policy_comparison_status_v1120_error','state':'ERROR','error':f'{exc.__class__.__name__}: {exc}'}
    _finish_review_phase_v1009('quality_policy_comparison_v1120', _phase_t, phase_timings)
    set_review_phase('late_path')
    _phase_t = time.monotonic()
    try:
        late_path = update_late_path_status(nowv, qrecords)
    except Exception as exc:
        append_error(ERROR, 'late_path_update', exc)
        late_path = {'schema':'late_path_status_v947_error','state':'ERROR','error':f'{exc.__class__.__name__}: {exc}'}
    _finish_review_phase_v1009('late_path', _phase_t, phase_timings)
    set_review_phase('sample_board')
    _phase_t = time.monotonic()
    try:
        sample_board = update_sample_board(nowv,qrecords)
    except Exception as exc:
        append_error(ERROR,'sample_board_update',exc); sample_board={'schema':'sample_board_status_v948_error','state':'ERROR','error':f'{exc.__class__.__name__}: {exc}'}
    _finish_review_phase_v1009('sample_board', _phase_t, phase_timings)
    set_review_phase('smart_structure')
    _phase_t = time.monotonic()
    try:
        smart_structure = update_smart_structure_shadow(nowv,fmap,ofmap)
    except Exception as exc:
        append_error(ERROR,'smart_structure_shadow_update',exc); smart_structure={'schema':'smart_structure_shadow_review_status_v948_error','state':'ERROR','error':f'{exc.__class__.__name__}: {exc}'}
    _finish_review_phase_v1009('smart_structure', _phase_t, phase_timings)
    set_review_phase('structure_lab')
    _phase_t = time.monotonic()
    try:
        structure_lab, structure_missed = update_structure_laboratory(nowv,fmap,ofmap)
    except Exception as exc:
        append_error(ERROR,'structure_laboratory_update',exc)
        structure_lab={'schema':'structure_lab_review_status_v957_error','state':'ERROR','error':f'{exc.__class__.__name__}: {exc}'}
        structure_missed={'schema':'structure_missed_status_v957_error','state':'ERROR','error':f'{exc.__class__.__name__}: {exc}'}
    _finish_review_phase_v1009('structure_lab', _phase_t, phase_timings)
    set_review_phase('performance_lab')
    _phase_t = time.monotonic()
    try:
        performance_lab = update_performance_lab(nowv,qrecords,quality_shadow,late_path,structure_lab,structure_missed)
    except Exception as exc:
        append_error(ERROR,'performance_lab_update',exc)
        performance_lab={'schema':'performance_lab_status_v960_error','state':'ERROR','error':f'{exc.__class__.__name__}: {exc}'}
    _finish_review_phase_v1009('performance_lab', _phase_t, phase_timings)
    set_review_phase('profitability_diagnostic')
    _phase_t = time.monotonic()
    try:
        profitability_diagnostic_v1034 = update_profitability_diagnostic_v1034(nowv, canonical_closed_snapshot_v1015 if isinstance(canonical_closed_snapshot_v1015,dict) else {}, closed_rows_cycle)
    except Exception as exc:
        append_error(ERROR,'profitability_diagnostic_v1034',exc)
        profitability_diagnostic_v1034={'schema':'profitability_diagnostic_status_v1034_error','state':'ERROR','error':f'{exc.__class__.__name__}: {exc}'}
    _finish_review_phase_v1009('profitability_diagnostic', _phase_t, phase_timings)
    set_review_phase('early_regression_audit')
    _phase_t = time.monotonic()
    try:
        early_regression_audit_v1035 = update_early_regression_audit_v1035(nowv, canonical_closed_snapshot_v1015 if isinstance(canonical_closed_snapshot_v1015,dict) else {})
    except Exception as exc:
        append_error(ERROR,'early_regression_audit_v1035',exc)
        early_regression_audit_v1035={'schema':'early_regression_audit_status_v1035_error','state':'ERROR','error':f'{exc.__class__.__name__}: {exc}'}
    _finish_review_phase_v1009('early_regression_audit', _phase_t, phase_timings)
    set_review_phase('missed_review_state')
    ttl = max(3600.0, RETENTION_DAYS * 86400.0)
    # 오래된 비핵심 복기 state만 제거. paper 장부는 삭제하지 않음.
    before_active = len(active)
    active = {k:v for k,v in active.items() if _v655_keep_active_review(v, nowv, ttl)}
    active = _v664_prune_active_size(active, nowv, ACTIVE_REVIEW_MAX)
    pruned_active = max(0, before_active - len(active))

    for c in qrows:
        if not isinstance(c, dict): continue
        stage = str(c.get("stage") or "").upper()
        if stage not in ("S2", "S3"): continue
        t = ticker_norm(c.get("ticker"))
        if not t: continue
        cur = _current_price(t, fmap, ofmap)
        base = fnum(c.get("snapshot_price"), c.get("price"), default=0.0) or cur
        rec = active.get(t) or {
            "ticker": t, "first_seen_ts": nowv, "first_seen_text": now_text(nowv),
            "first_price": base, "min_pct": 0.0, "max_pct": 0.0,
            "max_seen_ts": nowv, "max_seen_text": now_text(nowv), "samples": {},
        }
        rec.update({
            "stage": stage, "strategy": c.get("strategy"), "strategy_key": c.get("strategy_key"),
            "score": c.get("score"), "block_reasons": c.get("block_reasons", []),
            "missing_info": c.get("missing_info", []), "metrics": c.get("metrics", {}),
            "structure_tags": c.get("structure_tags", []),
            "structure_good_tags": c.get("structure_good_tags", []),
            "structure_risk_tags": c.get("structure_risk_tags", []),
            "structure_fit": c.get("structure_fit", ""),
            "structure_summary": c.get("structure_summary", ""),
            "chart_structure": c.get("chart_structure", {}),
            "last_seen_ts": nowv, "last_seen_text": now_text(nowv),
        })
        if not fnum(rec.get("first_price"), default=0.0) and base:
            rec["first_price"] = base
        if cur:
            rec["current_price"] = cur
            cp = _pct(cur, fnum(rec.get("first_price"), default=0.0))
            rec["current_pct"] = cp
            prev_max = fnum(rec.get("max_pct"), default=cp)
            if cp >= prev_max:
                rec["max_seen_ts"] = nowv
                rec["max_seen_text"] = now_text(nowv)
            rec["max_pct"] = max(prev_max, cp)
            rec["min_pct"] = min(fnum(rec.get("min_pct"), default=cp), cp)
            elapsed = nowv - fnum(rec.get("first_seen_ts"), default=nowv)
            samples = rec.get("samples") if isinstance(rec.get("samples"), dict) else {}
            for label, sec in (("5m",300),("10m",600),("20m",1200)):
                if elapsed >= sec and label not in samples:
                    samples[label] = {"ts": nowv, "text": now_text(nowv), "price": cur, "pct": cp}
                    rec[f"after_{label}_pct"] = cp
            rec["samples"] = samples
            rec["decision"] = _decision(rec, elapsed)
        active[t] = rec

    # v441: active state에 남은 구 decision/review_hint를 그대로 쓰지 않는다.
    # 현재 max/current/위험프로필 기준으로 다시 분류해 /review 상단 count와 후보별 문구가 어긋나지 않게 한다.
    for rec in active.values():
        if not isinstance(rec, dict):
            continue
        _ensure_structure(rec, structure_sources)
        _ensure_market(rec, structure_sources, fmap, ofmap, regime if isinstance(regime, dict) else {})
        elapsed = nowv - fnum(rec.get("first_seen_ts"), default=nowv)
        rec["decision"] = _decision(rec, elapsed)
        rec["review_class"] = rec["decision"]
        rec["review_hint"] = rec["decision"]
    all_rows = list(active.values())
    missed = [r for r in all_rows if str(r.get("decision")) == "❌ 진짜 놓친 후보"]
    regret = [r for r in all_rows if str(r.get("decision")) == "⚠️ 아까운 후보"]
    late_rise = [r for r in all_rows if str(r.get("decision")) == "⏳ 늦게 오른 후보"]
    risk_rise = [r for r in all_rows if str(r.get("decision")) == "🔥 결과만 오른 위험 후보"]
    correct = [r for r in all_rows if str(r.get("decision")) == "✅ 안 산 게 맞음"]
    done = {"❌ 진짜 놓친 후보", "⚠️ 아까운 후보", "⏳ 늦게 오른 후보", "🔥 결과만 오른 위험 후보", "✅ 안 산 게 맞음"}
    pending = [r for r in all_rows if str(r.get("decision")) not in done]
    legacy = _legacy_closed_summary(structure_sources, fmap, ofmap, regime if isinstance(regime, dict) else {}, closed_rows_cycle[-360:])
    summary = {
        "schema": "missed_review_summary_v457_timing_split",
        "version": VERSION,
        "updated_ts": nowv, "updated_text": now_text(nowv),
        "queue_age_sec": round(nowv - fnum(queue.get("updated_ts"), default=nowv), 1) if isinstance(queue, dict) else None,
        "tracking_total": len(all_rows), "queue_candidates": len(qrows),
        "missed_count": len(missed), "regret_count": len(regret), "late_rise_count": len(late_rise), "risk_rise_count": len(risk_rise), "correct_count": len(correct), "pending_count": len(pending),
        "missed": _summ_rows(missed, 8), "regret": _summ_rows(regret, 8), "late_rise": _summ_rows(late_rise, 8), "risk_rise": _summ_rows(risk_rise, 8), "correct": _summ_rows(correct, 5), "pending": _summ_rows(pending, 8),
        "missed_reason_top": _reason_top(missed + regret, 8),
        "v655_active_pruned": pruned_active,
        "v655_policy": "중요 복기 후보는 유지하고 추적중/안산게맞음 active state만 짧게 순환해 CPU를 줄임. paper 장부 삭제 없음.",
        "v664_active_max": ACTIVE_REVIEW_MAX,
        "v664_source_snapshot_lines": SOURCE_SNAPSHOT_LINES,
        "v664_policy": "review_worker는 paper 장부를 지우지 않고 active missed-review 상태만 핵심/최근 후보 중심으로 제한해 CPU를 줄임.",
        "trigger_shadow_v665": _compact_phase_ref_v1009(trigger_shadow_v665, count_keys=("active_count","entered_count","pruned_count_v678")),
        "market_miss_v667": _compact_phase_ref_v1009(market_miss_v667, count_keys=("tracking_total","rise_count")),
        "good_s2_result_v923": _compact_phase_ref_v1009(good_s2_result_v923, count_keys=("tracked_total","opened_exact","closed_exact","final_ledger_rows")),
        "quality_shadow_v946": _compact_phase_ref_v1009(quality_shadow, count_keys=("tracked_records","final_ledger_rows","analysis_revision_v1009")),
        "quality_policy_comparison_v1120": _compact_phase_ref_v1009(quality_policy_comparison_v1120, count_keys=("tracked_records","false_pass_60m_count","false_block_60m_count")),
        "late_path_v947": _compact_phase_ref_v1009(late_path, count_keys=("occurrence_normalized_records",)),
        "sample_board_v948": _compact_phase_ref_v1009(sample_board, count_keys=("tracked_records",)),
        "smart_structure_shadow_v948": _compact_phase_ref_v1009(smart_structure, count_keys=("tracked_records",)),
        "structure_lab_v956": _compact_phase_ref_v1009(structure_lab, count_keys=("tracked_structures","source_analysis_ready_rows")),
        "structure_missed_v956": _compact_phase_ref_v1009(structure_missed),
        "performance_lab_v960": _compact_phase_ref_v1009(performance_lab, count_keys=("cycle_sec","cache_reused_v1009")),
        "profitability_diagnostic_v1034": _compact_phase_ref_v1009(profitability_diagnostic_v1034, count_keys=("exact_closed","current_open","axes")),
        "late_rise_reason_top": _reason_top(late_rise, 8),
        "risk_rise_reason_top": _reason_top(risk_rise, 8),
        "policy": "v457: 최고수익 착시를 분리한다. 진짜놓침은 5/10/20분 안에 상승한 후보만 남기고, 늦게 오른 후보는 S1 완화 근거에서 제외한다. 조건/청산숫자/paper 장부 변경 없음.",
        **legacy,
    }
    save_json(STATE, {"schema":"missed_review_state_v457_timing_split", "version":VERSION, "updated_ts":nowv, "active":active})
    save_json(SUMMARY, summary)
    save_json(OLD_SUMMARY, {"schema":"clean_review_summary_reference_v1009","version":VERSION,"updated_ts":nowv,"updated_text":now_text(nowv),**legacy,"missed_review_ref":{"path":SUMMARY.name,"schema":summary.get("schema"),"tracking_total":summary.get("tracking_total")}})
    trace_rotation_v1080=_v1080_review_trace_maintenance(now_ts(),startup=False)
    dedup_signature_sync_v1080=_dedup_sync_source_signature_v1080()
    # v1143: candidate standard is part of the canonical Review cycle.
    # No tail wrapper or recursive run_once alias is allowed.
    candidate_standard_cycle = _candidate_standard_cycle_update()
    set_review_phase('unified_shadow_v2010')
    _phase_t = time.monotonic()
    try:
        unified_shadow_v2010 = _v2010_unified_shadow_cycle_update(nowv,paper_source_rows,closed_rows_cycle,fmap,ofmap,summary,good_s2_result_v923,quality_shadow)
    except Exception as exc:
        append_error(ERROR,'unified_shadow_v2010',exc)
        unified_shadow_v2010={'schema':'unified_shadow_status_v2010_error','state':'ERROR','error':f'{exc.__class__.__name__}: {exc}'}
    _finish_review_phase_v1009('unified_shadow_v2010', _phase_t, phase_timings)
    sec = now_ts() - st
    global _LAST_COMPLETED_PHASE_TIMINGS, _LAST_PHASE_MEMORY_TOP
    phase_timings['missed_review_state'] = round(max(0.0, sec-sum(phase_timings.values())),3)
    _LAST_COMPLETED_PHASE_TIMINGS = dict(phase_timings)
    _LAST_PHASE_MEMORY_TOP = sorted(_PHASE_MEMORY_SAMPLES.items(), key=lambda x:x[1], reverse=True)[:5]
    set_review_phase('cycle_finalize')
    write_status("running", trace_rotation_v1080=trace_rotation_v1080, dedup_signature_sync_v1080=dedup_signature_sync_v1080, candidate_standard_v1143=candidate_standard_cycle, unified_shadow_v2010={'state':unified_shadow_v2010.get('state'),'structure_tracked':(unified_shadow_v2010.get('structure_3price') or {}).get('tracked'),'profit_open':(unified_shadow_v2010.get('profit_giveback') or {}).get('current_open_tracked')}, tracked=len(all_rows), missed=len(missed), regret=len(regret), late_rise=len(late_rise), risk_rise=len(risk_rise), correct=len(correct), pending=len(pending), closed_recent=legacy.get("closed_recent",0), big_loss=legacy.get("big_loss",0), good_win=legacy.get("good_win",0), active_pruned=pruned_active, active_max=ACTIVE_REVIEW_MAX, source_snapshot_lines=SOURCE_SNAPSHOT_LINES, trigger_shadow_active=(trigger_shadow_v665 or {}).get("active_count",0), trigger_shadow_entered=(trigger_shadow_v665 or {}).get("entered_count",0), trigger_shadow_pruned=(trigger_shadow_v665 or {}).get("pruned_count_v678",0), market_miss_tracking=(market_miss_v667 or {}).get("tracking_total",0), market_miss_rise=(market_miss_v667 or {}).get("rise_count",0), good_s2_result_total=(good_s2_result_v923 or {}).get("tracked_total",0), good_s2_result_opened=(good_s2_result_v923 or {}).get("opened_exact",0), good_s2_result_closed=(good_s2_result_v923 or {}).get("closed_exact",0), good_s2_result_final=(good_s2_result_v923 or {}).get("final_ledger_rows",0), good_s2_closed_source_v1015=(good_s2_result_v923 or {}).get("closed_source_v1015"), quality_shadow_tracked=(quality_shadow or {}).get("tracked_records",0), quality_shadow_final=(quality_shadow or {}).get("final_ledger_rows",0), quality_policy_shadow_records_v1120=(quality_policy_comparison_v1120 or {}).get("tracked_records",0), quality_policy_false_pass_60m_v1120=(quality_policy_comparison_v1120 or {}).get("false_pass_60m_count",0), quality_policy_false_block_60m_v1120=(quality_policy_comparison_v1120 or {}).get("false_block_60m_count",0), quality_eye_state_v1124=(quality_policy_comparison_v1120 or {}).get('state'), quality_eye_leader_60m_v1124=(quality_policy_comparison_v1120 or {}).get('leader_60m'), quality_eye_min_ready_n_v1124=(quality_policy_comparison_v1120 or {}).get('minimum_ready_n',0), quality_eye_epoch_id_v1124=(quality_policy_comparison_v1120 or {}).get('quality_epoch_id_v1124'), late_path_occurrences=(late_path or {}).get("occurrence_normalized_records",0), sample_board_records=(sample_board or {}).get("tracked_records",0), smart_structure_records=(smart_structure or {}).get("tracked_records",0), structure_lab_plans=(structure_lab or {}).get("tracked_structures",0), structure_missed_records=((structure_missed or {}).get("stats") or {}).get("tracked",0), performance_lab_cycle_sec=(performance_lab or {}).get("cycle_sec",0), performance_lab_state=(performance_lab or {}).get("state","-"), performance_lab_cache_reused_v1011=bool((performance_lab or {}).get("cache_reused_v1011")), performance_lab_recompute_reason_v1011=(performance_lab or {}).get("recompute_reason_v1011"), profitability_diagnostic_state_v1034=(profitability_diagnostic_v1034 or {}).get('state'), profitability_diagnostic_exact_v1034=(profitability_diagnostic_v1034 or {}).get('exact_closed',0), profitability_diagnostic_open_v1034=(profitability_diagnostic_v1034 or {}).get('current_open',0), phase_timings_sec=phase_timings, phase_top=sorted(phase_timings.items(), key=lambda x:x[1], reverse=True)[:5], phase_memory_top=_LAST_PHASE_MEMORY_TOP, phase_io_top_v1011=sorted(((name,round(float(item.get('read_mb',0.0))+float(item.get('write_mb',0.0)),3)) for name,item in _PHASE_IO_SAMPLES_V1011.items()),key=lambda pair:pair[1],reverse=True)[:5], last_sec=round(sec,3), structure_enriched=sum(1 for r in active.values() if isinstance(r, dict) and _has_structure(r)))
    return {"tracked":len(all_rows),"missed":len(missed),"regret":len(regret),"late_rise":len(late_rise),"correct":len(correct),"candidate_standard_v1143":candidate_standard_cycle,"phase_timings_sec":dict(phase_timings),"phase_top":sorted(phase_timings.items(),key=lambda item:item[1],reverse=True)[:5],"phase_memory_top":list(_LAST_PHASE_MEMORY_TOP),"phase_io_top_v1011":sorted(((name,round(float(item.get("read_mb",0.0))+float(item.get("write_mb",0.0)),3)) for name,item in _PHASE_IO_SAMPLES_V1011.items()),key=lambda pair:pair[1],reverse=True)[:5],"cycle_sec":round(sec,3)}


# =============================================================================
# review_worker v0.19 / v675: preserve canonical values in missed-review state
# =============================================================================

def _v675_first(*vals: Any, default: Any=None) -> Any:
    for v in vals:
        if v not in (None, '', '-', [], {}): return v
    return default


def _review_market_miss_value_enrich(nowv: float, fmap: Dict[str, Dict[str, Any]], ofmap: Dict[str, Dict[str, Any]]) -> Dict[str, Any]:  # type: ignore[override]
    summary = _review_market_miss_base_update(nowv, fmap, ofmap)
    try:
        cand_obj = load_json(MARKET_MISS_CANDIDATES, {}) or {}; candidates = cand_obj.get('rows') if isinstance(cand_obj, dict) and isinstance(cand_obj.get('rows'), list) else []
        by_ticker = {ticker_norm(c.get('ticker')): c for c in candidates if isinstance(c, dict) and ticker_norm(c.get('ticker'))}
        state = load_json(MARKET_MISS_STATE, {}) or {}; active = state.get('active') if isinstance(state, dict) and isinstance(state.get('active'), dict) else {}
        for t, rec in list(active.items()):
            if not isinstance(rec, dict): continue
            c = by_ticker.get(t) or {}
            rec['coin_quality_score'] = fnum(_v675_first(c.get('coin_quality_score'), c.get('q'), rec.get('coin_quality_score')), default=0.0); rec['q'] = rec['coin_quality_score']
            rec['execution_risk_score'] = fnum(_v675_first(c.get('execution_risk_score'), c.get('risk'), rec.get('execution_risk_score')), default=0.0); rec['risk'] = rec['execution_risk_score']
            for k in ('trigger_source','trigger_confidence','trigger_gap_pct','price_reaction_pct','buy_ratio','buy_sustain_1m','spread_pct','slippage_pct','candle_age_sec'):
                if c.get(k) not in (None, '', '-'): rec[k] = c.get(k)
            maxp = fnum(rec.get('max_pct'), default=0.0); q=fnum(rec.get('coin_quality_score'), default=0.0); risk=fnum(rec.get('execution_risk_score'), default=0.0); bucket=str(rec.get('miss_bucket') or '-')
            if maxp >= 0.70 and q >= 60 and risk <= 40 and bucket not in ('risk_filter_candidate',): rec['miss_decision']='❌ 진짜놓침_후보'
            elif maxp >= 0.70 and bucket == 'risk_filter_candidate': rec['miss_decision']='✅ 위험필터_성공검토'
            elif maxp >= 0.40: rec['miss_decision']='⚠️ 아까운상승'
            else: rec['miss_decision']='관찰중'
            active[t]=rec
        rows=list(active.values()); matured=[r for r in rows if fnum(r.get('age_sec'), default=0)>=180]; risers=[r for r in rows if fnum(r.get('max_pct'), default=0)>=0.40]; true_missed=[r for r in rows if str(r.get('miss_decision'))=='❌ 진짜놓침_후보']
        buckets=Counter(str(r.get('miss_bucket') or '-') for r in risers); decisions=Counter(str(r.get('miss_decision') or '-') for r in rows)
        def slim(r: Dict[str, Any]) -> Dict[str, Any]:
            return {k:r.get(k) for k in ('ticker','initial_stage','miss_bucket','miss_decision','coin_quality_score','q','execution_risk_score','risk','first_price','latest_price','current_pct','max_pct','min_pct','age_sec','initial_reason','trigger_source','trigger_confidence','trigger_gap_pct','price_reaction_pct','buy_ratio','buy_sustain_1m','spread_pct','slippage_pct','candle_age_sec')}
        top=sorted(risers, key=lambda r:fnum(r.get('max_pct'), default=0.0), reverse=True)[:12]; true_top=sorted(true_missed, key=lambda r:fnum(r.get('max_pct'), default=0.0), reverse=True)[:10]
        summary=dict(summary or {}); summary.update({'schema':'market_miss_review_v675_value_enriched','version':VERSION,'updated_ts':nowv,'updated_text':now_text(nowv),'tracking_total':len(rows),'matured_count':len(matured),'rise_count':len(risers),'true_missed_count':len(true_missed),'miss_bucket_counts':dict(buckets.most_common(10)),'decision_counts':dict(decisions.most_common(8)),'top_risers':[slim(r) for r in top],'true_missed_top':[slim(r) for r in true_top],'value_enriched_v675':True,'policy':'v675: missed candidates keep Q/R/trigger/execution values from canonical candidate snapshot. 실제 S1/paper OPEN/청산/자동매수 변경 없음.'})
        save_json(MARKET_MISS_STATE, {'schema':'market_miss_state_v675_value_enriched','version':VERSION,'updated_ts':nowv,'updated_text':now_text(nowv),'active':active}); save_json(MARKET_MISS_SUMMARY, summary)
    except Exception as exc: append_error(ERROR, 'v675_market_miss_value_enrich', exc)
    return summary


# =============================================================================
# review_worker v0.20 / v676: market-miss CPU cache guard
# - Keep whole-market review, but do not rebuild the expensive 456-row maturity
#   summary every loop when the cache is still fresh.
# =============================================================================
V676_MARKET_MISS_MIN_REFRESH_SEC = float(os.getenv('REVIEW_MARKET_MISS_MIN_REFRESH_SEC', '25'))

def _review_market_miss_cached_update(nowv: float, fmap: Dict[str, Dict[str, Any]], ofmap: Dict[str, Dict[str, Any]]) -> Dict[str, Any]:  # type: ignore[override]
    try:
        if MARKET_MISS_SUMMARY.exists():
            age = max(0.0, nowv - MARKET_MISS_SUMMARY.stat().st_mtime)
            if age < V676_MARKET_MISS_MIN_REFRESH_SEC:
                cached = load_json(MARKET_MISS_SUMMARY, {}) or {}
                if isinstance(cached, dict) and cached.get('tracking_total'):
                    cached = dict(cached)
                    cached['cache_reused_v676'] = True
                    cached['cache_age_sec_v676'] = round(age, 3)
                    return cached
    except Exception:
        pass
    out = _review_market_miss_value_enrich(nowv, fmap, ofmap)
    try:
        if isinstance(out, dict):
            out['cache_reused_v676'] = False
            out['min_refresh_sec_v676'] = V676_MARKET_MISS_MIN_REFRESH_SEC
            save_json(MARKET_MISS_SUMMARY, out)
    except Exception as exc:
        append_error(ERROR, 'v676_market_miss_cache_mark', exc)
    return out




# =============================================================================
# review_worker v0.721 / v895: same-number seal for market-miss after review
# - 후보 row의 stable_event_key/candidate_follow_key/entry_build_key를 market-miss 결과에 보존한다.
# - 실제 S1/paper OPEN/청산/자동매수/조건은 변경하지 않는다.
# =============================================================================


def _v895_present(v: Any) -> bool:
    return v not in (None, '', '-', [], {})


def _v895_event_prefix_bucket(value: Any) -> tuple[str, Optional[int]]:
    s = str(value or '').strip()
    if not s or s == '-': return '', None
    parts = s.split(':')
    if len(parts) >= 2 and parts[-1].isdigit():
        try: return ':'.join(parts[:-1]), int(parts[-1])
        except Exception: return ':'.join(parts[:-1]), None
    return s, None


def _v895_stable_fields(c: Dict[str, Any]) -> Dict[str, Any]:
    if not isinstance(c, dict): return {}
    eid = None
    for k in ('event_id','event_key','trace_id','handoff_id','candidate_uid','candidate_id','scan_id','source_scan_id','entry_build_key','build_key'):
        if _v895_present(c.get(k)):
            eid = c.get(k); break
    stable = None
    for k in ('stable_event_key_v894','candidate_follow_key_v894','stable_event_key_v895','candidate_follow_key_v895'):
        if _v895_present(c.get(k)):
            stable = c.get(k); break
    bucket = None
    for k in ('stable_event_bucket_v894','candidate_event_bucket_v894','stable_event_bucket_v895','candidate_event_bucket_v895'):
        if _v895_present(c.get(k)):
            bucket = c.get(k); break
    if not _v895_present(stable) and _v895_present(eid):
        stable, bucket2 = _v895_event_prefix_bucket(eid)
        if not _v895_present(bucket): bucket = bucket2
    out = {
        'event_id': eid,
        'stable_event_key_v894': stable,
        'candidate_follow_key_v894': stable,
        'stable_event_key_v895': stable,
        'candidate_follow_key_v895': stable,
        'entry_build_key': c.get('entry_build_key') or c.get('build_key') or eid,
        'score_patch_version': c.get('score_patch_version') or c.get('patch_version') or VERSION,
        'signal_ts': c.get('signal_ts') or c.get('created_at') or c.get('candidate_created_at') or c.get('source_created_at'),
        'same_key_sealed_v895': bool(_v895_present(stable) or _v895_present(eid)),
        'same_key_owner_v895': 'review_worker_market_miss_writer',
        'same_key_policy_v895': 'use candidate stable key for after metric review; no trading condition change',
    }
    if _v895_present(bucket):
        try: out['stable_event_bucket_v894'] = int(float(bucket)); out['stable_event_bucket_v895'] = int(float(bucket))
        except Exception: out['stable_event_bucket_v894'] = bucket; out['stable_event_bucket_v895'] = bucket
    return {k:v for k,v in out.items() if _v895_present(v) or k == 'same_key_sealed_v895'}



def _review_market_miss_v895_key(c: Dict[str, Any]) -> str:  # type: ignore[override]
    fields = _v895_stable_fields(c)
    return str(fields.get('stable_event_key_v895') or fields.get('stable_event_key_v894') or fields.get('entry_build_key') or _review_market_miss_base_key(c))


def _v895_enrich_market_miss_outputs(summary: Dict[str, Any], nowv: float) -> Dict[str, Any]:
    cand_obj = load_json(MARKET_MISS_CANDIDATES, {}) or {}
    candidates = cand_obj.get('rows') if isinstance(cand_obj, dict) and isinstance(cand_obj.get('rows'), list) else []
    by_key: Dict[str, Dict[str, Any]] = {}
    by_ticker: Dict[str, Dict[str, Any]] = {}
    for c in candidates:
        if not isinstance(c, dict): continue
        fields = _v895_stable_fields(c)
        key = str(fields.get('stable_event_key_v895') or fields.get('entry_build_key') or '')
        t = ticker_norm(c.get('ticker') or c.get('symbol') or c.get('market'))
        cc = dict(c); cc.update(fields)
        if key: by_key[key] = cc
        if t: by_ticker[t] = cc
    state = load_json(MARKET_MISS_STATE, {}) or {}
    active = state.get('active') if isinstance(state, dict) and isinstance(state.get('active'), dict) else {}
    sealed = 0
    rows = []
    for k, rec in list(active.items()):
        if not isinstance(rec, dict): continue
        t = ticker_norm(rec.get('ticker'))
        c = by_key.get(str(k)) or by_key.get(str(rec.get('stable_event_key_v895') or rec.get('stable_event_key_v894') or '')) or by_ticker.get(t)
        if isinstance(c, dict):
            fields = _v895_stable_fields(c)
            rec.update(fields)
        if rec.get('same_key_sealed_v895'): sealed += 1
        rows.append(rec)
    if isinstance(active, dict):
        save_json(MARKET_MISS_STATE, {'schema':'market_miss_state_v895_same_key','version':VERSION,'build':BUILD_LABEL,'updated_ts':nowv,'updated_text':now_text(nowv),'active':active})
    def enrich_arr(arr: Any) -> list:
        out=[]
        for r in arr if isinstance(arr, list) else []:
            if not isinstance(r, dict): continue
            t = ticker_norm(r.get('ticker'))
            c = by_key.get(str(r.get('stable_event_key_v895') or r.get('stable_event_key_v894') or '')) or by_ticker.get(t)
            rr = dict(r)
            if isinstance(c, dict): rr.update(_v895_stable_fields(c))
            out.append(rr)
        return out
    summary = dict(summary or {})
    for key in ('top_risers','true_missed_top','rows','items','missed','regret','late_rise'):
        if isinstance(summary.get(key), list):
            summary[key] = enrich_arr(summary.get(key))
    # main v889 reads rows too; publish a compact stable-key rows list without replacing existing summaries.
    summary['rows'] = sorted(rows, key=lambda x: fnum(x.get('max_pct'), default=0.0), reverse=True)[:240]
    summary['same_key_seal_v895'] = {'candidate_rows': len(candidates), 'active_rows': len(rows), 'sealed_rows': sealed, 'version': VERSION, 'build': BUILD_LABEL}
    summary['version'] = VERSION; summary['build'] = BUILD_LABEL
    save_json(MARKET_MISS_SUMMARY, summary)
    return summary



def _review_market_miss_v895_enrich_update(nowv: float, fmap: Dict[str, Dict[str, Any]], ofmap: Dict[str, Dict[str, Any]]) -> Dict[str, Any]:  # type: ignore[override]
    summary = _review_market_miss_cached_update(nowv, fmap, ofmap)
    try:
        return _v895_enrich_market_miss_outputs(summary if isinstance(summary, dict) else {}, nowv)
    except Exception as exc:
        append_error(ERROR, 'v895_market_miss_same_key_seal', exc)
        return summary


# =============================================================================
# review_worker v0.722 / v896: same-key alias for market-miss performance prep
# - Adds v896 aliases and match mode into market-miss result rows.
# - No trading condition, trigger, exit, paper OPEN/CLOSED, auto-buy change.
# =============================================================================


def _v896_present(v: Any) -> bool:
    return v not in (None, '', '-', [], {})


def _v896_stable_fields(c: Dict[str, Any], mode: str = 'candidate_key') -> Dict[str, Any]:
    if not isinstance(c, dict): return {}
    stable = c.get('stable_event_key_v896') or c.get('candidate_follow_key_v896') or c.get('stable_event_key_v895') or c.get('candidate_follow_key_v895') or c.get('stable_event_key_v894') or c.get('candidate_follow_key_v894')
    bucket = c.get('stable_event_bucket_v896') or c.get('candidate_event_bucket_v896') or c.get('stable_event_bucket_v895') or c.get('candidate_event_bucket_v895') or c.get('stable_event_bucket_v894') or c.get('candidate_event_bucket_v894')
    eid = c.get('entry_build_key') or c.get('event_id') or c.get('event_key') or c.get('trace_id')
    if not _v896_present(stable) and _v896_present(eid):
        try:
            stable, b2 = _v895_event_prefix_bucket(eid)
            if not _v896_present(bucket): bucket = b2
        except Exception:
            stable = eid
    out = {
        'event_id': c.get('event_id') or eid,
        'stable_event_key_v896': stable,
        'candidate_follow_key_v896': stable,
        'stable_event_key_v895': stable,
        'candidate_follow_key_v895': stable,
        'stable_event_key_v894': stable,
        'candidate_follow_key_v894': stable,
        'same_number_key_v896': stable,
        'entry_build_key': c.get('entry_build_key') or eid,
        'score_patch_version': c.get('score_patch_version') or c.get('patch_version') or VERSION,
        'signal_ts': c.get('signal_ts') or c.get('created_at') or c.get('candidate_created_at') or c.get('source_created_at'),
        'same_key_sealed_v896': bool(stable or eid),
        'same_key_owner_v896': 'review_worker_market_miss_writer',
        'same_key_match_mode_v896': mode,
        'same_key_policy_v896': 'same key for quality tag performance prep; no trading condition change',
    }
    if _v896_present(bucket):
        try:
            out['stable_event_bucket_v896'] = int(float(bucket)); out['candidate_event_bucket_v896'] = int(float(bucket))
        except Exception:
            out['stable_event_bucket_v896'] = bucket; out['candidate_event_bucket_v896'] = bucket
    return {k:v for k,v in out.items() if _v896_present(v) or k == 'same_key_sealed_v896'}


def _v667_miss_key(c: Dict[str, Any]) -> str:  # type: ignore[override]
    fields = _v896_stable_fields(c, 'exact_candidate_key')
    return str(fields.get('same_number_key_v896') or fields.get('stable_event_key_v896') or fields.get('entry_build_key') or _review_market_miss_v895_key(c))


def _v667_market_miss_update(nowv: float, fmap: Dict[str, Dict[str, Any]], ofmap: Dict[str, Dict[str, Any]]) -> Dict[str, Any]:  # type: ignore[override]
    summary = _review_market_miss_v895_enrich_update(nowv, fmap, ofmap)
    try:
        cand_obj = load_json(MARKET_MISS_CANDIDATES, {}) or {}
        candidates = cand_obj.get('rows') if isinstance(cand_obj, dict) and isinstance(cand_obj.get('rows'), list) else []
        by_key: Dict[str, Dict[str, Any]] = {}; by_ticker: Dict[str, Dict[str, Any]] = {}
        for c in candidates:
            if not isinstance(c, dict): continue
            fields = _v896_stable_fields(c, 'exact_candidate_key')
            cc = dict(c); cc.update(fields)
            for k in ('same_number_key_v896','stable_event_key_v896','candidate_follow_key_v896','entry_build_key','event_id'):
                if _v896_present(cc.get(k)): by_key[str(cc.get(k))] = cc
            t = ticker_norm(c.get('ticker') or c.get('symbol') or c.get('market'))
            if t: by_ticker[t] = cc
        state = load_json(MARKET_MISS_STATE, {}) or {}
        active = state.get('active') if isinstance(state, dict) and isinstance(state.get('active'), dict) else {}
        rows=[]; sealed=0; exact=0; near=0
        for k, rec in list(active.items()):
            if not isinstance(rec, dict): continue
            c = by_key.get(str(k)) or by_key.get(str(rec.get('same_number_key_v896') or rec.get('stable_event_key_v896') or rec.get('stable_event_key_v895') or rec.get('entry_build_key') or rec.get('event_id') or ''))
            mode = 'exact_candidate_key' if isinstance(c, dict) else ''
            if c is None:
                t = ticker_norm(rec.get('ticker'))
                c = by_ticker.get(t); mode = 'ticker_time_near_audit' if isinstance(c, dict) else ''
            rr = dict(rec)
            if isinstance(c, dict): rr.update(_v896_stable_fields(c, mode))
            if rr.get('same_key_sealed_v896'): sealed += 1
            if rr.get('same_key_match_mode_v896') == 'exact_candidate_key': exact += 1
            if rr.get('same_key_match_mode_v896') == 'ticker_time_near_audit': near += 1
            rows.append(rr)
        summary = dict(summary or {})
        summary['rows'] = sorted(rows, key=lambda x: fnum(x.get('max_pct'), default=0.0), reverse=True)[:240]
        summary['same_key_seal_v896'] = {'candidate_rows':len(candidates),'active_rows':len(rows),'sealed_rows':sealed,'exact_rows':exact,'near_rows':near,'version':VERSION,'build':BUILD_LABEL,'updated_ts':nowv}
        summary['version']=VERSION; summary['build']=BUILD_LABEL
        save_json(MARKET_MISS_SUMMARY, summary)
        return summary
    except Exception as exc:
        append_error(ERROR, 'v896_market_miss_same_key_alias', exc)
        return summary


# =============================================================================
# v987 canonical CLOSED consumer
# - review no longer scans CLOSED or decision ledgers for public performance counts
# - the paper-owned atomic snapshot is the only source
# =============================================================================
def _performance_closed_analysis(snapshot_input: Optional[Dict[str, Any]]=None) -> Dict[str, Any]:  # type: ignore[override]
    snapshot = snapshot_input if isinstance(snapshot_input,dict) else (load_json(CANONICAL_PERFORMANCE_V987, {}) or {})
    if not isinstance(snapshot, dict) or snapshot.get('schema') != 'canonical_alt_swing_performance_snapshot_v987':
        return {
            'state':'WAITING_CANONICAL_PERFORMANCE_SNAPSHOT','snapshot_id':None,'matched_results':0,
            'raw_closed_rows_seen':0,'decision_key_exact':0,'sealed_pos_id':0,'ticker_match_used':0,
            '_matched_rows_internal':[],'policy':'read canonical_performance_snapshot_v987.json only; no CLOSED/decision fallback',
        }
    rows = snapshot.get('rows') if isinstance(snapshot.get('rows'),list) else []
    counts = snapshot.get('counts') if isinstance(snapshot.get('counts'), dict) else {}
    windows = snapshot.get('windows') if isinstance(snapshot.get('windows'), dict) else {}
    all_stats = windows.get('all') if isinstance(windows.get('all'), dict) else {}
    contract = snapshot.get('current_exit_contract') if isinstance(snapshot.get('current_exit_contract'), dict) else {}
    matched=[]
    for row in rows:
        if not isinstance(row,dict): continue
        key=str(row.get('decision_key') or '').strip()
        rr=dict(row)
        rr['key']=key; rr['identity']=str(row.get('identity') or ('decision:'+key if key else ''))
        rr['match_mode']=str(row.get('match_mode') or 'decision_key_exact')
        rr['age_min']=(float(row.get('hold_sec'))/60.0) if isinstance(row.get('hold_sec'),(int,float)) else None
        matched.append(rr)
    return {
        'state':'ACTIVE' if rows else 'WAITING_FIRST_CLEAN_EXACT_CLOSED','snapshot_id':snapshot.get('snapshot_id'),
        'snapshot_generated_at':snapshot.get('generated_at'),'snapshot_source_digest':snapshot.get('source_digest'),
        'snapshot_membership_digest':snapshot.get('membership_digest'),
        'decision_records':int((snapshot.get('source_meta') or {}).get('decision_records') or 0),
        'closed_rows_seen':int(counts.get('alt_swing_ledger_rows') or 0),'raw_closed_rows_seen':int(counts.get('raw_ledger_rows') or 0),
        'matched_results':len(matched),'decision_key_exact':int(counts.get('decision_key_exact') or 0),'sealed_pos_id':0,'ticker_match_used':0,
        'duplicate_closed_rows':int(counts.get('duplicate_closed_rows') or 0),'missing_decision_key':int(counts.get('missing_decision_key') or 0),
        'decision_not_closed_or_missing':int(counts.get('decision_not_closed_or_missing') or 0),
        'current_contract_matched_results':int(contract.get('contract_ok_rows') or 0),'current_contract_outside_results':int(contract.get('contract_outside_rows') or 0),
        'current_contract_outside_match_reasons':contract.get('outside_reason_counts') or {},
        'wins':int(all_stats.get('wins') or 0),'losses':int(all_stats.get('losses') or 0),'win_rate_pct':all_stats.get('win_rate'),
        'avg_pnl_pct':all_stats.get('avg'),'avg_win_pct':all_stats.get('avg_win'),'avg_loss_pct':all_stats.get('avg_loss'),'expectancy_pct':all_stats.get('avg'),
        'matched_exact_keys':[str(r.get('identity') or '') for r in matched],'_matched_rows_internal':matched,
        'membership_policy':snapshot.get('membership_policy'),'source_owner':snapshot.get('source_owner'),
        'policy':'paper-owned atomic canonical snapshot only; no CLOSED ledger scan, no decision-state recomputation, no ticker join',
    }



# =============================================================================
# review_worker v1.000 / v1122: atomic single writer + persistent clean epoch
# =============================================================================
_REVIEW_SINGLETON_FH_V1122 = None
# Keep the v1121 lock path so an already-running v1121 process and v1122 contend
# for the same kernel lock during upgrade.  The filename is now a stable contract.
REVIEW_SINGLETON_LOCK_V1122 = BASE_DIR / "runtime" / "review_worker_singleton_v1121.lock"
REVIEW_SINGLETON_STATUS_V1122 = BASE_DIR / "clean_review_singleton_status_v1122.json"
QUALITY_POLICY_EPOCH_STATUS_V1122 = BASE_DIR / "clean_quality_policy_epoch_v1122.json"
_QUALITY_POLICY_EPOCH_START_V1121 = 0.0
_QUALITY_POLICY_EPOCH_ID_V1121 = ""
_REVIEW_HELPER_FLAGS_V1122 = {
    '--build-dedup-index-v1013',
    '--compact-quality-state-v1012',
    '--build-good-s2-summary-v1014',
}


def _review_process_family_v1122(include_helpers: bool=False) -> list[int]:
    """Find every long-lived Review runtime, including old versioned filenames.

    Older deployment code matched only review_worker.py and the newest versioned
    file.  A direct process running review_worker_v0.998.py therefore survived a
    restart and kept the SQLite dedup database open.  Match the stable filename
    family instead, while excluding intentional short-lived helper modes from
    the long-lived runtime count.
    """
    out=[]
    for entry in Path('/proc').iterdir():
        if not entry.name.isdigit():
            continue
        pid=int(entry.name)
        try:
            raw=(entry/'cmdline').read_bytes().decode('utf-8',errors='ignore').replace('\x00',' ').strip()
        except Exception:
            continue
        low=raw.lower()
        if 'python' not in low or 'review_worker' not in low or '.py' not in low:
            continue
        tokens=raw.split()
        script_names=[Path(tok).name.lower() for tok in tokens if tok.lower().endswith('.py')]
        if not any(name == 'review_worker.py' or (name.startswith('review_worker_v') and name.endswith('.py')) for name in script_names):
            continue
        if not include_helpers and any(flag in tokens for flag in _REVIEW_HELPER_FLAGS_V1122):
            continue
        out.append(pid)
    return sorted(set(out))


def _write_review_singleton_status_v1122(event: str, held: bool=True, siblings: Optional[List[int]]=None) -> None:
    fd=-1; inode=0
    try:
        if _REVIEW_SINGLETON_FH_V1122 is not None and not _REVIEW_SINGLETON_FH_V1122.closed:
            fd=_REVIEW_SINGLETON_FH_V1122.fileno(); inode=os.fstat(fd).st_ino
    except Exception:
        held=False
    family=_review_process_family_v1122(include_helpers=False)
    sibling_list=list(siblings if siblings is not None else [pid for pid in family if pid != os.getpid()])
    save_json(REVIEW_SINGLETON_STATUS_V1122,{
        'schema':'review_singleton_status_v1122','version':VERSION,'build':BUILD_LABEL,
        'state':'LOCKED_SINGLE_INSTANCE' if held and not sibling_list else ('BLOCKED_OLD_REVIEW_RUNTIME' if sibling_list else 'LOCK_PROOF_MISSING'),
        'pid':os.getpid(),'lock_pid':os.getpid() if held else 0,
        'lock_path':str(REVIEW_SINGLETON_LOCK_V1122),'lock_fd':fd,'lock_inode':inode,
        'lock_held':bool(held),'event':event,'review_family_pids_v1122':family,
        'sibling_review_pids_v1122':sibling_list,'exact_one_long_lived_v1122':bool(held and family == [os.getpid()]),
        'updated_ts':time.time(),'updated_text':now_text(),'auto_buy':False,
        'policy':'one long-lived Review process owns SQLite dedup and every quality-shadow writer; old versioned filenames are included'})


def _load_or_start_quality_epoch_v1122() -> None:
    """Create one clean epoch after singleton proof and reuse it across restarts."""
    global _QUALITY_POLICY_EPOCH_START_V1121, _QUALITY_POLICY_EPOCH_ID_V1121
    previous=load_json(QUALITY_POLICY_EPOCH_STATUS_V1122,{}) or {}
    reusable=(
        isinstance(previous,dict)
        and previous.get('schema')=='quality_policy_epoch_v1122'
        and previous.get('state')=='ACTIVE_CLEAN_SINGLE_WRITER'
        and float(previous.get('epoch_start_ts') or 0.0)>0
        and str(previous.get('epoch_id') or '').strip()
    )
    if reusable:
        start=float(previous['epoch_start_ts']); epoch_id=str(previous['epoch_id']); event='REUSED_AFTER_CLEAN_RESTART'
    else:
        start=time.time(); epoch_id=f"quality-v1122-{int(start)}"; event='STARTED_AFTER_ATOMIC_SINGLETON_PROOF'
    _QUALITY_POLICY_EPOCH_START_V1121=start
    _QUALITY_POLICY_EPOCH_ID_V1121=epoch_id
    save_json(QUALITY_POLICY_EPOCH_STATUS_V1122,{
        'schema':'quality_policy_epoch_v1122','epoch_id':epoch_id,
        'epoch_start_ts':start,'epoch_start_text':now_text(start),
        'state':'ACTIVE_CLEAN_SINGLE_WRITER','event':event,
        'previous_v1120_v1121_rows_state':'PRESERVED_EXCLUDED_BEFORE_EPOCH',
        'old_rows_deleted':False,'old_ledgers_rewritten':False,
        'version':VERSION,'build':BUILD_LABEL,'review_pid':os.getpid(),
        'review_family_pids_v1122':_review_process_family_v1122(False),
        'persistent_across_clean_restarts_v1122':True,'auto_buy':False})


def _acquire_review_singleton_v1122() -> None:
    global _REVIEW_SINGLETON_FH_V1122
    REVIEW_SINGLETON_LOCK_V1122.parent.mkdir(parents=True,exist_ok=True)
    fh=REVIEW_SINGLETON_LOCK_V1122.open('a+',encoding='utf-8')
    try:
        fcntl.flock(fh.fileno(),fcntl.LOCK_EX|fcntl.LOCK_NB)
    except BlockingIOError:
        try: fh.seek(0); owner=fh.read().strip()
        except Exception: owner='unknown'
        print(f'review singleton lock busy; owner={owner}',flush=True)
        fh.close(); raise SystemExit(73)
    fh.seek(0); fh.truncate(0)
    fh.write(json.dumps({'schema':'review_singleton_lock_v1122','pid':os.getpid(),'version':VERSION,'build':BUILD_LABEL,'acquired_ts':time.time()},ensure_ascii=False,separators=(',',':')))
    fh.flush(); os.fsync(fh.fileno()); _REVIEW_SINGLETON_FH_V1122=fh
    siblings=[pid for pid in _review_process_family_v1122(include_helpers=False) if pid != os.getpid()]
    if siblings:
        _write_review_singleton_status_v1122('blocked_old_review_runtime',True,siblings)
        print(f'old review runtime still alive; siblings={siblings}',flush=True)
        fh.close(); _REVIEW_SINGLETON_FH_V1122=None
        raise SystemExit(74)
    _write_review_singleton_status_v1122('acquired_exact_one',True,[])
    _load_or_start_quality_epoch_v1122()


def _release_review_singleton_v1122() -> None:
    global _REVIEW_SINGLETON_FH_V1122, _DEDUP_CONN_V1013
    try:
        if _DEDUP_CONN_V1013 is not None:
            try: _DEDUP_CONN_V1013.commit()
            except Exception: pass
            try: _DEDUP_CONN_V1013.close()
            except Exception: pass
            _DEDUP_CONN_V1013=None
    except Exception:
        pass
    try:
        if _REVIEW_SINGLETON_FH_V1122 is not None:
            _write_review_singleton_status_v1122('release',False,[])
            _REVIEW_SINGLETON_FH_V1122.close()
    except Exception:
        pass
    _REVIEW_SINGLETON_FH_V1122=None


def main() -> None:
    _acquire_review_singleton_v1122()
    atexit.register(_release_review_singleton_v1122)
    set_review_phase('boot')
    heartbeat=threading.Thread(target=_review_heartbeat_loop_v1008, name='review-heartbeat-v1080', daemon=True)
    heartbeat.start()
    set_review_phase('trace_rotation_v1080')
    write_status('initializing', phase='trace_rotation_v1080', trace_rotation_v1080={'state':'PREPARING'})
    try:
        trace_startup=_v1080_review_trace_maintenance(time.time(),startup=True)
    except Exception as exc:
        append_error(ERROR,'trace_rotation_startup_v1080',exc)
        trace_startup={'schema':'review_trace_rotation_status_v1080','state':'ERROR','error':f'{type(exc).__name__}: {exc}','core_ledgers_changed':False,'strategy_rules_changed':False,'auto_buy':False}
    set_review_phase('dedup_index_build')
    write_status("initializing", phase="dedup_index_build", dedup_index_v1013={'state':'PREPARING'}, trace_rotation_v1080=trace_startup)
    dedup_prepare=_dedup_prepare_v1013()
    write_status("initializing", phase="boot", dedup_index_v1013=dedup_prepare, trace_rotation_v1080=trace_startup)
    next_run = time.monotonic(); cycle_count = 0; last_success_ts = 0.0; last_cycle_sec = None; last_cycle_error = None
    try:
        while True:
            cycle_started = time.monotonic()
            try:
                siblings=[pid for pid in _review_process_family_v1122(False) if pid != os.getpid()]
                if siblings:
                    _write_review_singleton_status_v1122('runtime_sibling_detected',True,siblings)
                    raise SystemExit(75)
                result=run_once(); cycle_count += 1; last_success_ts = now_ts(); last_cycle_error = None
                last_cycle_sec = round(time.monotonic() - cycle_started, 3)
                _write_review_singleton_status_v1122('cycle_end_exact_one',True,[])
                reclaim = _release_cycle_memory(); set_review_phase('idle')
                write_status("running", phase="idle", cycle_count=cycle_count, last_success_ts=last_success_ts, last_success_text=now_text(last_success_ts), last_cycle_sec=last_cycle_sec, last_sec=last_cycle_sec, phase_timings_sec=result.get('phase_timings_sec') if isinstance(result,dict) else {}, phase_top=result.get('phase_top') if isinstance(result,dict) else [], phase_memory_top=result.get('phase_memory_top') if isinstance(result,dict) else [], memory_reclaim_v1008=reclaim, json_cache_owner="review_worker_material_change_cache_v1009", review_singleton_exact_one_v1122=True, quality_epoch_id_v1122=_QUALITY_POLICY_EPOCH_ID_V1121, _clear_current_error_v1144=True)
            except KeyboardInterrupt:
                set_review_phase('shutdown'); write_status("stopping", phase="shutdown", cycle_count=cycle_count, last_success_ts=last_success_ts, last_cycle_sec=last_cycle_sec); raise
            except Exception as exc:
                append_error(ERROR, "loop", exc); reclaim = _release_cycle_memory(); set_review_phase('idle_after_error')
                last_cycle_error=f"{exc.__class__.__name__}: {exc}"
                write_status("error", phase="idle_after_error", error=last_cycle_error, cycle_count=cycle_count, last_success_ts=last_success_ts, last_cycle_sec=last_cycle_sec, memory_reclaim_v1008=reclaim)
            next_run += max(10.0, INTERVAL_SEC)
            if next_run < time.monotonic(): next_run = time.monotonic()
            while True:
                remain = next_run - time.monotonic()
                if remain <= 0: break
                time.sleep(min(HEARTBEAT_SEC, max(0.2, remain)))
                remain2 = max(0.0, next_run - time.monotonic())
                if last_cycle_error:
                    set_review_phase('idle_after_error')
                    write_status("error", phase="idle_after_error", heartbeat=True, error=last_cycle_error, cycle_count=cycle_count, last_success_ts=last_success_ts, last_success_text=now_text(last_success_ts) if last_success_ts else None, last_cycle_sec=last_cycle_sec, next_cycle_in_sec=round(remain2, 2), review_singleton_exact_one_v1122=True, quality_epoch_id_v1122=_QUALITY_POLICY_EPOCH_ID_V1121)
                else:
                    set_review_phase('idle')
                    write_status("running", phase="idle", heartbeat=True, cycle_count=cycle_count, last_success_ts=last_success_ts, last_success_text=now_text(last_success_ts) if last_success_ts else None, last_cycle_sec=last_cycle_sec, next_cycle_in_sec=round(remain2, 2), review_singleton_exact_one_v1122=True, quality_epoch_id_v1122=_QUALITY_POLICY_EPOCH_ID_V1121)
    finally:
        _HEARTBEAT_STOP.set()
        _release_review_singleton_v1122()


# v1122: top-level VERSION/BUILD are canonical; helper CLI modes remain outside the long-lived singleton.

# =============================================================================
# v1141: full candidate/structure/market/performance standard board
# Read-only aggregation. No gate/rank/entry/exit changes.
# =============================================================================
CANDIDATE_STANDARD_CONTRACT_V1141 = BASE_DIR / 'clean_candidate_standard_contract_v1141.json'
CANDIDATE_STANDARD_STATUS_V1141 = BASE_DIR / 'candidate_standard_status_v1141.json'
CANDIDATE_STANDARD_BASELINE_STATE_V1141 = BASE_DIR / 'candidate_standard_baseline_state_v1141.json'
CANDIDATE_STANDARD_BASELINE_LEDGER_V1141 = BASE_DIR / 'candidate_standard_baseline_ledger_v1141.jsonl'
CANDIDATE_STANDARD_DECISION_LEDGER_V1141 = BASE_DIR / 'candidate_standard_decision_ledger_v1141.jsonl'
PAPER_CONTROL_V1141 = BASE_DIR / 'paper_bot_control.json'
PAPER_STATUS_V1141 = BASE_DIR / 'paper_bot_status.json'
STRATEGY_STATUS_V1141 = BASE_DIR / 'clean_strategy_worker_status.json'
PERFORMANCE_EPOCH_V1141 = BASE_DIR / 'paper_quality_rebuild_epoch_v1095.json'
QUALITY_POLICY_V1141 = BASE_DIR / 'clean_quality_policy_comparison_status_v1125.json'
STRUCTURE_REVIEW_V1141 = BASE_DIR / 'clean_structure_lab_review_status_v956.json'
CANDIDATE_STANDARD_REFERENCE_STATE_V1142 = BASE_DIR / 'candidate_standard_reference_state_v1142.json'
CANDIDATE_STANDARD_REFERENCE_LEDGER_V1142 = BASE_DIR / 'candidate_standard_reference_ledger_v1142.jsonl'
PAPER_EXIT_MONITOR_STATUS_V1142 = BASE_DIR / 'paper_exit_monitor_status.json'


def _cs_num_v1141(*values: Any, default=None):
    for value in values:
        if value in (None,'',[],{}): continue
        try:
            out=float(str(value).replace(',','').replace('%','').strip())
            if math.isfinite(out): return out
        except Exception: pass
    return default


def _cs_dict_v1141(*values: Any) -> Dict[str,Any]:
    for value in values:
        if isinstance(value,dict): return value
    return {}


def _cs_rows_v1141(obj: Any) -> List[Dict[str,Any]]:
    if isinstance(obj,list): return [x for x in obj if isinstance(x,dict)]
    if not isinstance(obj,dict): return []
    for key in ('rows','items','positions','open_positions','active','records'):
        value=obj.get(key)
        if isinstance(value,list): return [x for x in value if isinstance(x,dict)]
        if isinstance(value,dict):
            out=[]
            for k,v in value.items():
                if isinstance(v,dict):
                    row=dict(v); row.setdefault('pos_id',k); out.append(row)
            return out
    if obj and all(isinstance(v,dict) for v in obj.values()):
        return [dict(v,**({'pos_id':k} if 'pos_id' not in v else {})) for k,v in obj.items()]
    return []


def _cs_median_v1141(values: List[float]):
    vals=sorted(float(x) for x in values if isinstance(x,(int,float)) and math.isfinite(float(x)))
    if not vals: return None
    n=len(vals); mid=n//2
    return round(vals[mid] if n%2 else (vals[mid-1]+vals[mid])/2.0,6)


def _cs_mean_v1141(values: List[float]):
    vals=[float(x) for x in values if isinstance(x,(int,float)) and math.isfinite(float(x))]
    return round(sum(vals)/len(vals),6) if vals else None


def _cs_pct_between_v1141(a, b):
    av=_cs_num_v1141(a); bv=_cs_num_v1141(b)
    if av is None or bv in (None,0): return None
    return (av/bv-1.0)*100.0


def _cs_ticker_v1141(row: Dict[str,Any]) -> str:
    value=str(row.get('ticker') or row.get('market') or row.get('symbol') or '').upper().replace('_','-')
    parts=[x for x in value.split('-') if x and x!='KRW']
    return parts[-1] if parts else value


def _cs_occurrence_v1141(row: Dict[str,Any]) -> Dict[str,Any]:
    gate=_cs_dict_v1141(row.get('swing_entry_gate_v977'))
    return _cs_dict_v1141(row.get('trigger_occurrence_v1037'),gate.get('trigger_occurrence_v1037'))


def _cs_gate_v1141(row: Dict[str,Any]) -> Dict[str,Any]:
    return _cs_dict_v1141(row.get('swing_entry_gate_v977'),(_cs_dict_v1141(row.get('canonical_entry_decision'))).get('metrics'))


def _cs_plan_v1141(row: Dict[str,Any]) -> Dict[str,Any]:
    return _cs_dict_v1141(row.get('swing_structure_plan_v977'),(_cs_gate_v1141(row)).get('structure_plan'))


def _cs_decision_key_v1141(row: Dict[str,Any]) -> str:
    gate=_cs_gate_v1141(row)
    return str(row.get('paper_decision_key_v926') or row.get('swing_gate_decision_key_v977') or gate.get('decision_key') or row.get('decision_key') or '')


def _cs_source_lane_v1141(row: Dict[str,Any]) -> str:
    blob=' '.join(str(row.get(k) or '') for k in ('strategy','strategy_key','strategy_label','source','candidate_source','lane','matched_strategy_labels','strategy_tags')).lower()
    if 'hot' in blob or '급등' in blob: return 'hot-rank'
    if 'rebreak' in blob or '재돌파' in blob: return 'reset-rebreak'
    if 'breakout' in blob or '돌파' in blob: return '돌파초입'
    if 'coverage' in blob or '전체' in blob: return '전체커버'
    if 'leader' in blob or '주도' in blob: return '주도흐름'
    if 'vwap' in blob or '저점' in blob: return '저점회복'
    if 'flow' in blob or '돈흐름' in blob: return '돈흐름'
    return '기타'



def _cs_occurrence_event_ts_v1142(row: Dict[str,Any]) -> Optional[float]:
    occurrence=_cs_occurrence_v1141(row)
    return _cs_num_v1141(
        occurrence.get('event_ts'), occurrence.get('rebreak_ts'),
        row.get('trigger_event_ts_v1133'), row.get('trigger_rebreak_ts_v1037')
    )


def _cs_opened_ts_v1142(row: Dict[str,Any]) -> Optional[float]:
    return _cs_nested_ts_v1141(
        row,
        ('opened_at','opened_ts','entry_ts','open_ts'),
        ('paper_timing_spine_v940','entry_timing_trace','canonical_entry_snapshot')
    ) or None


def _cs_metric_values_v1141(rows: List[Dict[str,Any]]) -> Dict[str,List[float]]:
    """Metric reader with sealed-time semantics.

    Candidate snapshots may keep living while price and wall-clock time move.  Those
    mutable values are useful for the current screen but must not be compared as a
    frozen baseline.  OPEN/CLOSED rows therefore use OPEN time and actual entry price;
    baseline comparisons use first-seen occurrence samples stored by v1142.
    """
    out={k:[] for k in ('reaction','relative_strength','money_flow','buy_ratio','buy_sustain','confirmation_count','rank_score','actual_rr','target_room','invalid_distance','chase','spread','slippage','occurrence_age')}
    nowv=now_ts()
    for row in rows:
        gate=_cs_gate_v1141(row); plan=_cs_plan_v1141(row); occurrence=_cs_occurrence_v1141(row)
        quality=_cs_dict_v1141(row.get('swing_quality_gate'),gate.get('swing_quality_gate'))
        qm=_cs_dict_v1141(quality.get('metrics'),(_cs_dict_v1141(row.get('quality_observation_v925'))).get('metrics'))
        opened_ts=_cs_opened_ts_v1142(row)
        price=_cs_num_v1141(
            row.get('actual_entry_price'), row.get('entry_price'),
            (_cs_dict_v1141(row.get('canonical_entry_snapshot'))).get('actual_entry_price'),
            row.get('current_price'), row.get('price')
        )
        invalid=_cs_num_v1141(gate.get('invalid_price'),row.get('swing_invalid_price_v977'),row.get('invalid_price'))
        trigger=_cs_num_v1141(
            row.get('swing_trigger_price_v977'),row.get('trigger_price'),
            gate.get('trigger_price'), occurrence.get('trigger_price')
        )
        rr=_cs_num_v1141(gate.get('risk_reward'),row.get('risk_reward'),(_cs_dict_v1141(row.get('risk_reward'))).get('rr_ratio'))
        event_ts=_cs_occurrence_event_ts_v1142(row)
        age_end=opened_ts or _cs_num_v1141(
            row.get('paper_received_ts'), row.get('selected_ts'),
            gate.get('updated_ts'), row.get('updated_ts'), default=nowv
        )
        values={
            'reaction':_cs_num_v1141(row.get('price_reaction_pct'),qm.get('price_reaction_pct')),
            'relative_strength':_cs_num_v1141(row.get('relative_strength_pct'),row.get('relative_strength'),qm.get('relative_strength')),
            'money_flow':_cs_num_v1141(row.get('money_flow_score'),qm.get('money_flow')),
            'buy_ratio':_cs_num_v1141(row.get('buy_ratio'),row.get('buy_strength'),qm.get('buy_ratio')),
            'buy_sustain':_cs_num_v1141(row.get('buy_sustain_1m'),row.get('buy_sustain_60s'),qm.get('buy_sustain_1m')),
            'confirmation_count':_cs_num_v1141(quality.get('confirmation_count'),quality.get('confirm_count'),len(quality.get('confirmations') or []) if isinstance(quality.get('confirmations'),list) else None),
            'rank_score':_cs_num_v1141(row.get('swing_quality_rank_score'),quality.get('rank_score')),
            'actual_rr':rr,
            'target_room':_cs_num_v1141(gate.get('target_room_pct'),row.get('target_room_pct')),
            'invalid_distance':abs(_cs_pct_between_v1141(invalid,price)) if price and invalid else None,
            'chase':abs(_cs_pct_between_v1141(price,trigger)) if price and trigger else None,
            'spread':_cs_num_v1141(gate.get('spread_pct'),row.get('spread_pct'),row.get('micro_spread_pct')),
            'slippage':_cs_num_v1141(gate.get('confirmed_slippage_pct'),row.get('entry_slippage_est_pct')),
            'occurrence_age':max(0.0,float(age_end)-float(event_ts)) if event_ts and age_end and age_end>=event_ts else None,
        }
        for key,value in values.items():
            if isinstance(value,(int,float)) and math.isfinite(float(value)): out[key].append(float(value))
    return out

def _cs_metric_summary_v1141(rows: List[Dict[str,Any]]) -> Dict[str,Any]:
    values=_cs_metric_values_v1141(rows)
    return {key:{'n':len(vals),'median':_cs_median_v1141(vals),'mean':_cs_mean_v1141(vals)} for key,vals in values.items()}


def _cs_structure_summary_v1141(rows: List[Dict[str,Any]]) -> Dict[str,Any]:
    tf=Counter(); source=Counter(); complete=0; missing=[]; active=0; observation=0
    samples=[]
    for row in rows:
        plan=_cs_plan_v1141(row); gate=_cs_gate_v1141(row)
        if plan: active+=1
        trig=_cs_dict_v1141(plan.get('trigger')); inv=_cs_dict_v1141(plan.get('invalid')); target=_cs_dict_v1141(plan.get('target'))
        ok=bool(trig.get('source') and inv.get('source') and target.get('source') and trig.get('tf') and inv.get('tf') and target.get('tf'))
        if ok: complete+=1
        else:
            if len(missing)<10: missing.append(_cs_ticker_v1141(row))
        for obj in (trig,inv,target):
            if obj.get('tf'): tf[str(obj.get('tf'))]+=1
            if obj.get('source'): source[str(obj.get('source'))]+=1
        lab=_cs_dict_v1141(row.get('structure_lab_v956'),row.get('structure_lab'))
        methods=lab.get('methods') if isinstance(lab.get('methods'),dict) else {}
        if methods: observation+=1
        if len(samples)<6 and plan:
            samples.append({'ticker':_cs_ticker_v1141(row),'trigger':trig,'invalid':inv,'target':target,'frozen_ts':plan.get('frozen_ts'),'integrity':plan.get('structure_integrity_v1048')})
    total=len(rows)
    return {'rows':total,'active_plan_rows':active,'complete_proof_rows':complete,'complete_proof_pct':round(complete/total*100,2) if total else None,
            'source_missing_rows':max(0,total-complete),'source_missing_samples':missing,'timeframe_top':dict(tf.most_common(12)),'source_top':dict(source.most_common(12)),
            'observation_method_rows':observation,'active_method':'ALT_SWING_V977_FROZEN_PLAN','observation_methods':['A_SWING','B_REACTION_ZONE','C_BREAK_RETEST','D_SUPPLY_DEMAND','E_VOLUME_PROFILE'],'samples':samples}


def _cs_percentile_v1141(values: List[float], q: float):
    vals=sorted(float(x) for x in values if isinstance(x,(int,float)) and math.isfinite(float(x)))
    if not vals: return None
    q=min(1.0,max(0.0,float(q))); idx=(len(vals)-1)*q; lo=int(math.floor(idx)); hi=int(math.ceil(idx))
    if lo==hi: return round(vals[lo],6)
    return round(vals[lo]+(vals[hi]-vals[lo])*(idx-lo),6)


def _cs_nested_ts_v1141(row: Dict[str,Any], keys: tuple[str,...], nested: tuple[str,...]=()) -> Optional[float]:
    sources=[row]
    for name in nested:
        obj=row.get(name)
        if isinstance(obj,dict): sources.append(obj)
    gate=_cs_gate_v1141(row); plan=_cs_plan_v1141(row); occ=_cs_occurrence_v1141(row)
    sources.extend([gate,plan,occ])
    for source in sources:
        if not isinstance(source,dict): continue
        for key in keys:
            value=_cs_num_v1141(source.get(key))
            if value is not None:
                if value>100_000_000_000: value/=1000.0
                if value>0: return value
    return None



def _cs_segment_stats_v1141(values: List[float]) -> Dict[str,Any]:
    vals=[float(x) for x in values if isinstance(x,(int,float)) and math.isfinite(float(x)) and float(x)>=0]
    if not vals:
        state='SOURCE_MISSING'
    elif len(vals)<50:
        state='COLLECTING'
    else:
        state='NORMAL'
    return {'n':len(vals),'median':_cs_median_v1141(vals),'mean':_cs_mean_v1141(vals),'p90':_cs_percentile_v1141(vals,0.90),'state':state,'min_review_sample':50}


def _cs_timing_summary_v1141(candidate_rows: List[Dict[str,Any]], open_rows: List[Dict[str,Any]], closed_rows: List[Dict[str,Any]]) -> Dict[str,Any]:
    nowv=now_ts(); occurrence_ages=[]
    segments={k:[] for k in ('structure_to_trigger','trigger_to_quality','quality_to_s1','s1_to_paper','paper_to_open','trigger_to_open','s1_to_open')}
    rows=candidate_rows+open_rows+closed_rows
    for row in rows:
        plan=_cs_plan_v1141(row); occ=_cs_occurrence_v1141(row)
        structure=_cs_num_v1141(plan.get('frozen_ts'))
        trigger=_cs_num_v1141(occ.get('event_ts'),row.get('trigger_reached_ts'),row.get('paper_confirmed_trigger_reached_ts_v938'),row.get('occurrence_event_ts'))
        quality=_cs_nested_ts_v1141(row,('quality_pass_ts','quality_gate_pass_ts','quality_ready_ts','quality_qualified_ts'),('swing_quality_gate','entry_context','entry_diagnostics'))
        s1=_cs_nested_ts_v1141(row,('s1_first_ts','s1_seen_ts','s1_ts','s1_promotion_ts','promoted_ts','hold_ts'),('paper_timing_spine_v940','entry_context','entry_diagnostics','hot_watch_timing_v945'))
        paper=_cs_nested_ts_v1141(row,('paper_handoff_ts','paper_received_ts','paper_intake_ts','paper_selected_ts','paper_selected_ts_v940'),('paper_timing_spine_v940','entry_context','entry_diagnostics'))
        opened=_cs_opened_ts_v1142(row)
        age_end=opened or paper or s1 or quality or _cs_num_v1141(row.get('updated_ts'),row.get('ts'),default=nowv)
        if trigger and age_end and age_end>=trigger:
            occurrence_ages.append(max(0.0,age_end-trigger))
        pairs=(('structure_to_trigger',structure,trigger),('trigger_to_quality',trigger,quality),('quality_to_s1',quality,s1),('s1_to_paper',s1,paper),('paper_to_open',paper,opened),('trigger_to_open',trigger,opened),('s1_to_open',s1,opened))
        for name,a,b in pairs:
            if a and b and b>=a and b-a<=7*86400:
                segments[name].append(b-a)
    stats={k:_cs_segment_stats_v1141(v) for k,v in segments.items()}
    missing=[k for k,v in stats.items() if v.get('state')=='SOURCE_MISSING']
    return {
        'candidate_occurrence_age_sec':_cs_segment_stats_v1141(occurrence_ages),
        'segments':stats,
        'trigger_to_open_delay_sec':stats['trigger_to_open'],
        'path':['structure_created','trigger_event','quality_pass','S1_hold','Paper_received_or_selected','OPEN_commit'],
        'rows_examined':len(rows),
        'source_missing_segments':missing,
        'missing_policy':'missing timestamps remain SOURCE_MISSING; no zero fill; timing is COLLECTING until 50 comparable events',
    }

def _cs_source_mix_v1141(rows: List[Dict[str,Any]]) -> Dict[str,Any]:
    c=Counter(_cs_source_lane_v1141(r) for r in rows)
    total=sum(c.values()); top=c.most_common(10); share=round((top[0][1]/total),4) if top and total else 0.0
    return {'total':total,'counts':dict(top),'top_source':top[0][0] if top else None,'top_share':share,'concentrated':bool(total>=20 and share>=0.65),'warning_threshold':0.65}


def _cs_row_pnl_v1141(row: Dict[str,Any]) -> Optional[float]:
    direct=_cs_num_v1141(row.get('net_pnl_pct'),row.get('unrealized_pnl_pct'),row.get('current_pnl_pct'),row.get('profit_pct'),row.get('pnl_pct'),row.get('return_pct'))
    if direct is not None: return direct
    entry=_cs_num_v1141(row.get('entry_price'),row.get('opened_price'),row.get('buy_price'))
    current=_cs_num_v1141(row.get('current_price'),row.get('mark_price'),row.get('price'),row.get('exit_price'))
    return _cs_pct_between_v1141(current,entry) if entry and current else None


def _cs_performance_summary_v1141(rows: List[Dict[str,Any]]) -> Dict[str,Any]:
    pnl=[]; mfe=[]; mae=[]; give=[]; hold=[]; wins=0; losses=0; no_positive=0; profit_to_loss=0
    nowv=now_ts()
    for row in rows:
        p=_cs_row_pnl_v1141(row); m=_cs_num_v1141(row.get('mfe_pct'),row.get('max_profit_pct'),row.get('max_pnl_pct')); a=_cs_num_v1141(row.get('mae_pct'),row.get('min_profit_pct'),row.get('min_pnl_pct'))
        g=_cs_num_v1141(row.get('giveback_pct'),row.get('profit_giveback_pct')); h=_cs_num_v1141(row.get('hold_sec'),row.get('holding_sec'),row.get('duration_sec'))
        if h is None:
            opened=_cs_nested_ts_v1141(row,('opened_at','opened_ts','entry_ts','open_ts'),('paper_timing_spine_v940',)); closed=_cs_nested_ts_v1141(row,('closed_at','closed_ts','exit_ts'),())
            end=closed or nowv
            if opened and end>=opened: h=end-opened
        if p is not None:
            pnl.append(p); wins+=int(p>0); losses+=int(p<0)
        if m is not None: mfe.append(m); no_positive+=int(m<=0)
        if a is not None: mae.append(a)
        if g is not None: give.append(g)
        elif m is not None and p is not None: give.append(max(0.0,m-p))
        if h is not None: hold.append(h)
        if m is not None and m>0 and p is not None and p<0: profit_to_loss+=1
    decided=wins+losses
    return {'n':len(rows),'pnl_n':len(pnl),'wins':wins,'losses':losses,'win_rate_pct':round(wins/decided*100,3) if decided else None,
            'simple_pct_sum':round(sum(pnl),6) if pnl else None,'mean_pnl_pct':_cs_mean_v1141(pnl),'mfe_median_pct':_cs_median_v1141(mfe),'mae_median_pct':_cs_median_v1141(mae),
            'giveback_median_pct':_cs_median_v1141(give),'hold_median_sec':_cs_median_v1141(hold),'no_positive_mfe_count':no_positive,'profit_to_loss_count':profit_to_loss,
            'account_weighted_return':'SOURCE_MISSING','sum_policy':'simple percentage sum is not account compounded return'}



def _cs_source_performance_v1141(rows: List[Dict[str,Any]]) -> Dict[str,Any]:
    groups: Dict[str,List[Dict[str,Any]]]={}
    for row in rows:
        groups.setdefault(_cs_source_lane_v1141(row),[]).append(row)
    items=[]
    for key,bucket in sorted(groups.items(),key=lambda kv:(-len(kv[1]),kv[0])):
        items.append({'source':key,**_cs_performance_summary_v1141(bucket)})
    if not rows:
        state='COLLECTING'
    elif len(rows)<30:
        state='CHECK_SAMPLE'
    else:
        state='NORMAL'
    return {'scope':'fresh_epoch_exact_closed','groups':items[:12],'group_count':len(items),'state':state,'fresh_closed_count':len(rows),'min_review_sample':30}

def _cs_structure_combo_v1141(row: Dict[str,Any]) -> str:
    plan=_cs_plan_v1141(row); trig=_cs_dict_v1141(plan.get('trigger')); inv=_cs_dict_v1141(plan.get('invalid')); target=_cs_dict_v1141(plan.get('target'))
    def part(obj): return f"{obj.get('tf') or '?'}:{obj.get('source_key') or obj.get('source') or '?'}"
    return f"T[{part(trig)}]|I[{part(inv)}]|G[{part(target)}]"



def _cs_structure_outcomes_v1141(rows: List[Dict[str,Any]], structure_review: Dict[str,Any]) -> Dict[str,Any]:
    groups: Dict[str,List[Dict[str,Any]]]={}
    missing_rows=0
    for row in rows:
        key=_cs_structure_combo_v1141(row)
        if '?' in key:
            missing_rows+=1
            continue
        groups.setdefault(key,[]).append(row)
    active=[]
    for key,bucket in sorted(groups.items(),key=lambda kv:(-len(kv[1]),kv[0])):
        active.append({'combination':key,**_cs_performance_summary_v1141(bucket)})
    observation_state=str(structure_review.get('state') or structure_review.get('status') or ('SOURCE_MISSING' if not structure_review else 'COLLECTING'))
    if rows and not active:
        state='SOURCE_MISSING'
    elif rows and missing_rows:
        state='PARTIAL_SOURCE'
    else:
        state='NORMAL' if rows else 'COLLECTING'
    return {
        'active_method':'ALT_SWING_V977_FROZEN_PLAN',
        'scope':'fresh_epoch_exact_closed',
        'active_combinations':active[:12],
        'combination_count':len(active),
        'structure_source_missing_rows':missing_rows,
        'observation_methods':{
            'methods':['A_SWING','B_REACTION_ZONE','C_BREAK_RETEST','D_SUPPLY_DEMAND','E_VOLUME_PROFILE'],
            'state':observation_state,
            'source':'clean_structure_lab_review_status_v956.json',
            'used_for_entry_gate':False
        },
        'state':state
    }

def _cs_book_performance_v1141(all_open: List[Dict[str,Any]], fresh_open: List[Dict[str,Any]], fresh_closed: List[Dict[str,Any]]) -> Dict[str,Any]:
    all_open_summary=_cs_performance_summary_v1141(all_open); fresh_open_summary=_cs_performance_summary_v1141(fresh_open); fresh_closed_summary=_cs_performance_summary_v1141(fresh_closed)
    combined=fresh_open+fresh_closed; combined_summary=_cs_performance_summary_v1141(combined)
    return {'current_open':len(all_open),'fresh_open':len(fresh_open),'fresh_closed':len(fresh_closed),'all_current_open':all_open_summary,'fresh_current_open':fresh_open_summary,
            'fresh_closed_summary':fresh_closed_summary,'fresh_closed_plus_open':combined_summary,'closed_plus_open_scope':'fresh epoch exact identity only',
            'historical_windows':'REFERENCE_ONLY','account_compounded_return':'SOURCE_MISSING'}


def _cs_entry_exit_v1141(open_rows: List[Dict[str,Any]], closed_rows: List[Dict[str,Any]], epoch_id: str) -> tuple[Dict[str,Any],Dict[str,Any],List[Dict[str,Any]]]:
    def is_fresh(row):
        rid=str(row.get('performance_epoch_id') or row.get('entry_epoch_id') or row.get('epoch_id') or (_cs_dict_v1141(row.get('canonical_entry_snapshot'))).get('performance_epoch_id') or '')
        return bool(epoch_id and rid==epoch_id)
    fresh_open=[r for r in open_rows if is_fresh(r)]
    fresh_closed=[r for r in closed_rows if is_fresh(r)]
    # If exact epoch field is absent, do not silently treat all history as fresh.
    scoped=fresh_open+fresh_closed
    values=_cs_metric_summary_v1141(scoped)
    mfe=[]; mae=[]; realized=[]; giveback=[]; hold=[]; no_positive=0; profit_to_loss=0; target_touch=[]; invalid_touch=[]
    for row in fresh_closed:
        m=_cs_num_v1141(row.get('mfe_pct'),row.get('max_profit_pct'),row.get('max_pnl_pct'))
        a=_cs_num_v1141(row.get('mae_pct'),row.get('min_profit_pct'),row.get('min_pnl_pct'))
        p=_cs_num_v1141(row.get('net_pnl_pct'),row.get('profit_pct'),row.get('pnl_pct'),row.get('return_pct'))
        g=_cs_num_v1141(row.get('giveback_pct'),row.get('profit_giveback_pct'))
        h=_cs_num_v1141(row.get('hold_sec'),row.get('holding_sec'),row.get('duration_sec'))
        if m is not None: mfe.append(m)
        if a is not None: mae.append(a)
        if p is not None: realized.append(p)
        if g is not None: giveback.append(g)
        elif m is not None and p is not None: giveback.append(max(0.0,m-p))
        if h is not None: hold.append(h)
        if m is not None and m<=0: no_positive+=1
        if m is not None and m>0 and p is not None and p<0: profit_to_loss+=1
        td=_cs_num_v1141(row.get('target_first_touch_ts')); ct=_cs_num_v1141(row.get('closed_at'),row.get('exit_ts'))
        idt=_cs_num_v1141(row.get('invalid_first_touch_ts'))
        if td and ct and ct>=td: target_touch.append(ct-td)
        if idt and ct and ct>=idt: invalid_touch.append(ct-idt)
    entry={'scope':'fresh_epoch_exact_only','epoch_id':epoch_id or None,'fresh_open':len(fresh_open),'fresh_closed':len(fresh_closed),'metrics':values,
           'sample_state':'REVIEWABLE' if len(fresh_closed)>=60 else ('CHECK_SMALL_SAMPLE' if len(fresh_closed)>=30 else 'COLLECTING'),
           'historical_reference':{'normal_trigger_to_open_sec':0.12,'normal_mfe_median_pct':2.4,'normal_invalid_mean_pct':1.6,'regression_mfe_median_pct':0.4,'regression_invalid_mean_pct':2.75,'policy':'reference only; never an automatic gate'}}
    exitq={'scope':'fresh_epoch_exact_only','fresh_closed':len(fresh_closed),'mfe_median_pct':_cs_median_v1141(mfe),'mae_median_pct':_cs_median_v1141(mae),'realized_mean_pct':_cs_mean_v1141(realized),
           'giveback_median_pct':_cs_median_v1141(giveback),'hold_median_sec':_cs_median_v1141(hold),'no_positive_mfe_count':no_positive,'profit_to_loss_count':profit_to_loss,
           'target_touch_to_close_median_sec':_cs_median_v1141(target_touch),'invalid_touch_to_close_median_sec':_cs_median_v1141(invalid_touch),
           'sample_state':'REVIEWABLE' if len(fresh_closed)>=60 else ('CHECK_SMALL_SAMPLE' if len(fresh_closed)>=30 else 'COLLECTING')}
    return entry,exitq,fresh_open,fresh_closed



def _cs_market_v1141(regime: Dict[str,Any], candidates: List[Dict[str,Any]]) -> Dict[str,Any]:
    breadth=_cs_num_v1141(regime.get('breadth_pct'),regime.get('market_breadth'),regime.get('breadth'))
    strength=_cs_num_v1141(regime.get('market_strength'),regime.get('strength'),regime.get('score'))
    mode=str(regime.get('mode') or regime.get('market_mode') or regime.get('regime') or regime.get('summary') or '')
    mode_low=mode.lower(); weak_tokens=('bear','weak','downtrend','risk_off','약세','하락장','위험회피')
    weak=any(t in mode_low for t in weak_tokens)
    missing=[]
    if breadth is None: missing.append('market_breadth')
    if strength is None: missing.append('market_strength')
    if not mode: missing.append('market_mode')
    if not regime:
        state='SOURCE_MISSING'
    elif missing:
        state='PARTIAL_SOURCE'
    else:
        state='WEAK' if weak else 'NORMAL'
    return {
        'state':state,'mode':mode or None,'breadth':breadth,'market_strength':strength,
        'candidate_rows':len(candidates),'source_missing':missing,
        'evidence_source':'clean_market_regime_cache.json',
        'weak_evidence':'explicit regime label only' if weak else None,
        'preliminary_mode_state':'WEAK' if weak else ('NORMAL' if mode else 'CHECK'),
        'policy':'market verdict requires mode+breadth+strength after system truth; partial evidence never becomes NORMAL'
    }


def _cs_shadow_v1141(policy: Dict[str,Any]) -> Dict[str,Any]:
    if not policy:
        return {'state':'SOURCE_MISSING','policy':'same-market observation only; no selector change'}
    current=_cs_dict_v1141(policy.get('current'),policy.get('current_policy'),policy.get('current_result'))
    improved=_cs_dict_v1141(policy.get('improved'),policy.get('improved_policy'),policy.get('improved_result'))
    raw_state=str(policy.get('state') or 'COLLECTING')
    comparison_ready=bool(current and improved)
    state=raw_state if comparison_ready else 'COLLECTING'
    return {
        'state':state,'raw_state':raw_state,'comparison_ready':comparison_ready,
        'tracked_records':policy.get('tracked_records'),
        'false_pass_60m_count':policy.get('false_pass_60m_count'),
        'false_block_60m_count':policy.get('false_block_60m_count'),
        'current':current,'improved':improved,
        'verdict':policy.get('verdict') or policy.get('final_verdict'),
        'policy':'same-market observation only; current+improved payload required; no selector change'
    }

def _cs_compare_metrics_v1141(base_metrics: Dict[str,Any], current_metrics: Dict[str,Any]) -> Dict[str,Any]:
    higher_good={'reaction','relative_strength','money_flow','buy_ratio','buy_sustain','confirmation_count','rank_score','actual_rr','target_room'}
    lower_good={'invalid_distance','chase','spread','slippage','occurrence_age'}
    rows=[]; degraded=[]; improved=[]
    for key in sorted(set(higher_good)|set(lower_good)):
        b=_cs_num_v1141((_cs_dict_v1141(base_metrics.get(key))).get('median'))
        c=_cs_num_v1141((_cs_dict_v1141(current_metrics.get(key))).get('median'))
        change=None; state='CHECK_SOURCE'
        if b is not None and c is not None:
            if abs(b)<1e-9:
                state='CHECK_BASELINE_ZERO'
            else:
                change=(c-b)/abs(b)*100.0
                if key in higher_good:
                    state='DEGRADED' if change<=-20 else ('IMPROVED' if change>=20 else 'NORMAL')
                else:
                    state='DEGRADED' if change>=20 else ('IMPROVED' if change<=-20 else 'NORMAL')
        row={'axis':key,'baseline':b,'current':c,'change_pct':round(change,2) if change is not None else None,'state':state}
        rows.append(row)
        if state=='DEGRADED': degraded.append(key)
        if state=='IMPROVED': improved.append(key)
    return {'axes':rows,'degraded_axes':degraded,'improved_axes':improved,'degraded_count':len(degraded),'warning_rule':'3+ axes degraded by >=20% is candidate-quality warning only; never automatic gate'}


def _cs_append_event_v1141(path: Path, row: Dict[str,Any]) -> None:
    _append_jsonl_batch_fsync(path,[row])



def _cs_candidate_identity_v1142(row: Dict[str,Any]) -> str:
    gate=_cs_gate_v1141(row); occ=_cs_occurrence_v1141(row); plan=_cs_plan_v1141(row)
    for value in (
        row.get('swing_gate_decision_key_v977'),
        gate.get('decision_key'),
        occ.get('decision_key'),
        row.get('trigger_occurrence_candidate_key_v1037'),
        row.get('candidate_key'),
        row.get('event_id'),
        row.get('event_key'),
    ):
        text=str(value or '').strip()
        if text:
            return text
    ticker=str(row.get('ticker') or row.get('market') or row.get('symbol') or '').strip().upper()
    event_ts=_cs_occurrence_event_ts_v1142(row)
    frozen=_cs_num_v1141(plan.get('frozen_ts'),row.get('swing_trigger_frozen_ts_v977'))
    if ticker and event_ts:
        return f'{ticker}|event:{int(event_ts*1000)}|frozen:{int((frozen or 0)*1000)}'
    return ''


def _cs_metric_sample_v1142(row: Dict[str,Any], captured_ts: float) -> Dict[str,Any]:
    values=_cs_metric_values_v1141([row])
    sample={key:(vals[0] if vals else None) for key,vals in values.items()}
    event_ts=_cs_occurrence_event_ts_v1142(row)
    if event_ts:
        sample['occurrence_age']=max(0.0,captured_ts-event_ts)
    sample['candidate_identity']=_cs_candidate_identity_v1142(row)
    sample['ticker']=str(row.get('ticker') or row.get('market') or row.get('symbol') or '').strip().upper() or None
    sample['event_ts']=event_ts
    sample['captured_ts']=captured_ts
    sample['source_lane']=_cs_source_lane_v1141(row)
    return sample


def _cs_metric_summary_from_samples_v1142(samples: List[Dict[str,Any]]) -> Dict[str,Any]:
    keys=('reaction','relative_strength','money_flow','buy_ratio','buy_sustain','confirmation_count','rank_score','actual_rr','target_room','invalid_distance','chase','spread','slippage','occurrence_age')
    out={}
    for key in keys:
        vals=[float(x.get(key)) for x in samples if isinstance(x,dict) and isinstance(x.get(key),(int,float)) and math.isfinite(float(x.get(key)))]
        out[key]={'n':len(vals),'median':_cs_median_v1141(vals),'mean':_cs_mean_v1141(vals)}
    return out



def _cs_update_candidate_reference_v1142(nowv: float, baseline_id: str, gate_pass: List[Dict[str,Any]], ttl_sec: float) -> Dict[str,Any]:
    state=load_json(CANDIDATE_STANDARD_REFERENCE_STATE_V1142,{}) or {}
    if str(state.get('baseline_id') or '') != str(baseline_id or ''):
        state={
            'schema':'candidate_standard_reference_state_v1142',
            'baseline_id':baseline_id or None,
            'seen':{},
            'baseline_samples':[],
            'recent_samples':[],
            'total_unique_count':0,
            'ready_event_written':False,
            'created_ts':nowv,
        }
    seen=state.get('seen') if isinstance(state.get('seen'),dict) else {}
    # One-time local migration from pre-final v1142 test state; live v1141 has no such file.
    legacy_samples=state.get('samples') if isinstance(state.get('samples'),list) else []
    baseline_samples=state.get('baseline_samples') if isinstance(state.get('baseline_samples'),list) else list(legacy_samples[:30])
    recent_samples=state.get('recent_samples') if isinstance(state.get('recent_samples'),list) else list(legacy_samples[-30:])
    total_unique=int(state.get('total_unique_count') or len(legacy_samples) or len(seen))
    added=0; skipped_missing=0; skipped_stale=0
    for row in gate_pass:
        key=_cs_candidate_identity_v1142(row)
        event_ts=_cs_occurrence_event_ts_v1142(row)
        if not key or not event_ts:
            skipped_missing+=1
            continue
        age=max(0.0,nowv-event_ts)
        if age>max(1.0,float(ttl_sec or 120.0)):
            skipped_stale+=1
            continue
        if key in seen:
            continue
        sample=_cs_metric_sample_v1142(row,nowv)
        if len(baseline_samples)<30:
            baseline_samples.append(sample)
        recent_samples.append(sample)
        recent_samples=recent_samples[-30:]
        seen[key]=nowv
        total_unique+=1
        added+=1
    # Bound only the duplicate-detection index. The first 30 baseline samples are immutable.
    if len(seen)>2000:
        keep=sorted(seen.items(),key=lambda kv:float(kv[1] or 0),reverse=True)[:2000]
        seen=dict(keep)
    reference_ready=len(baseline_samples)>=30
    current_ready=len(recent_samples)>=30
    baseline_metrics=_cs_metric_summary_from_samples_v1142(baseline_samples[:30]) if reference_ready else {}
    current_metrics=_cs_metric_summary_from_samples_v1142(recent_samples[-30:]) if current_ready else {}
    comparison=_cs_compare_metrics_v1141(baseline_metrics,current_metrics) if reference_ready and current_ready else {
        'axes':[],'degraded_axes':[],'improved_axes':[],'degraded_count':0,
        'state':'COLLECTING','warning_rule':'requires 30 unique fresh qualified occurrences'
    }
    if isinstance(comparison,dict):
        comparison['state']='READY' if reference_ready and current_ready else 'COLLECTING'
        comparison['baseline_n']=min(30,len(baseline_samples))
        comparison['current_n']=min(30,len(recent_samples))
    state.pop('samples',None)
    state.update({
        'seen':seen,
        'baseline_samples':baseline_samples[:30],
        'recent_samples':recent_samples[-30:],
        'total_unique_count':total_unique,
        'updated_ts':nowv,'added_this_cycle':added,
        'skipped_missing_identity_or_event':skipped_missing,'skipped_stale':skipped_stale,
        'unique_sample_count':total_unique,
        'baseline_sample_count':min(30,len(baseline_samples)),
        'current_window_count':min(30,len(recent_samples)),
        'reference_state':'READY' if reference_ready else 'COLLECTING',
        'baseline_metrics':baseline_metrics,'current_metrics':current_metrics,
        'comparison':comparison,
        'policy':'contract baseline is immediate; first 30 unique fresh qualified occurrences are immutable reference; only latest 30 rotate as comparison window'
    })
    if reference_ready and not state.get('ready_event_written'):
        first30=baseline_samples[:30]
        event={
            'schema':'candidate_standard_reference_event_v1142','event':'CANDIDATE_REFERENCE_READY',
            'ts':nowv,'time':now_text(nowv),'baseline_id':baseline_id,
            'sample_count':len(first30),
            'reference_digest':hashlib.sha256(json.dumps(first30,sort_keys=True,ensure_ascii=False,separators=(',',':')).encode()).hexdigest(),
            'policy':state['policy']
        }
        _cs_append_event_v1141(CANDIDATE_STANDARD_REFERENCE_LEDGER_V1142,event)
        state['ready_event_written']=True
    save_json(CANDIDATE_STANDARD_REFERENCE_STATE_V1142,state)
    return state

def _cs_paper_contract_v1142(paper_status: Dict[str,Any]) -> Dict[str,Any]:
    effective=paper_status.get('effective_control_contract_v1142') if isinstance(paper_status.get('effective_control_contract_v1142'),dict) else {}
    if not effective:
        return {
            'state':'CHECK_SOURCE','owner':'paper_bot.load_control -> paper status',
            'candidate_ttl_sec':None,'max_open_strict':None,'max_new_per_cycle':None,
            'new_open_paused':None,'paper_version':paper_status.get('version'),
            'exit_contract':{},'source_missing':['effective_control_contract_v1142']
        }
    out=dict(effective)
    out['paper_version']=paper_status.get('version')
    out.setdefault('state','NORMAL')
    return out


def _cs_source_gaps_v1142(timing: Dict[str,Any], structure_outcomes: Dict[str,Any], market: Dict[str,Any], shadow: Dict[str,Any], paper_contract: Dict[str,Any], metrics_pass: Dict[str,Any]) -> List[str]:
    gaps=[]
    segments=timing.get('segments') if isinstance(timing.get('segments'),dict) else {}
    for key in ('trigger_to_quality','quality_to_s1','s1_to_paper'):
        seg=segments.get(key) if isinstance(segments.get(key),dict) else {}
        if int(seg.get('n') or 0)<=0:
            gaps.append(f'time_path:{key}')
    if structure_outcomes.get('state') in ('SOURCE_MISSING','PARTIAL_SOURCE'):
        gaps.append('fresh_closed:structure_combination')
    for item in (market.get('source_missing') or []):
        gaps.append(f'market:{item}')
    if not shadow.get('comparison_ready'):
        gaps.append('same_market_shadow:current_improved_payload')
    for item in (paper_contract.get('source_missing') or []):
        gaps.append(f'paper_contract:{item}')
    conf=metrics_pass.get('confirmation_count') if isinstance(metrics_pass.get('confirmation_count'),dict) else {}
    if int(conf.get('n') or 0)<=0:
        gaps.append('candidate_quality:confirmation_count')
    return sorted(set(gaps))



def _cs_contract_identity_v1144(baseline: Dict[str,Any], contract: Dict[str,Any]) -> Dict[str,Any]:
    """Separate semantic trading contract from release/source identity.

    A status-writer or instrumentation-only release may change VERSION and the
    whole-file SHA without changing the active structure/Gate/entry contract.
    Only the semantic contract digest owns SYSTEM_REGRESSION.
    """
    baseline_ready=bool(baseline.get('baseline_id') and baseline.get('strategy_contract_digest'))
    current_digest=str(contract.get('contract_digest') or '')
    baseline_digest=str(baseline.get('strategy_contract_digest') or '')
    digest_match=bool(baseline_ready and current_digest and current_digest==baseline_digest)
    current_hash=str(contract.get('strategy_source_sha256') or '')
    baseline_hash=str(baseline.get('strategy_source_sha256') or '')
    source_hash_match=bool(baseline_ready and current_hash and current_hash==baseline_hash)
    version_match=bool(baseline_ready and str(contract.get('version') or '')==str(baseline.get('strategy_version') or ''))
    release_identity_match=bool(source_hash_match and version_match)
    if not baseline_ready:
        state='PENDING_BASELINE'
    elif digest_match and release_identity_match:
        state='SAME'
    elif digest_match:
        state='SAME_SEMANTIC_RELEASE_CHANGED'
    else:
        state='CHANGED_OR_MISSING'
    return {
        'baseline_ready':baseline_ready,
        'semantic_match':digest_match,
        'source_hash_match':source_hash_match,
        'version_match':version_match,
        'release_identity_match':release_identity_match,
        'release_identity_changed':bool(baseline_ready and digest_match and not release_identity_match),
        'state':state,
    }


def update_candidate_standard(nowv: float, candidate_rows: Optional[List[Dict[str,Any]]]=None, closed_rows: Optional[List[Dict[str,Any]]]=None) -> Dict[str,Any]:
    candidate_source=read_jsonl(PAPER_LATEST,max_lines=SOURCE_SNAPSHOT_LINES) if candidate_rows is None else candidate_rows
    candidates=[r for r in (candidate_source or []) if isinstance(r,dict)]
    if closed_rows is None:
        canonical=load_json(CANONICAL_PERFORMANCE_V987,{}) or {}
        closed_source=_cs_rows_v1141(canonical.get('rows') if isinstance(canonical,dict) else [])
    else:
        canonical={}; closed_source=closed_rows
    closed=[r for r in (closed_source or []) if isinstance(r,dict)]
    opens=_cs_rows_v1141(load_json(OPEN,{}) or {})
    contract=load_json(CANDIDATE_STANDARD_CONTRACT_V1141,{}) or {}
    paper_status=load_json(PAPER_STATUS_V1141,{}) or {}
    paper_contract=_cs_paper_contract_v1142(paper_status)
    epoch=load_json(PERFORMANCE_EPOCH_V1141,{}) or {}
    regime=load_json(REGIME,{}) or {}
    quality_policy=load_json(QUALITY_POLICY_V1141,{}) or {}
    structure_review=load_json(STRUCTURE_REVIEW_V1141,{}) or {}
    contract_digest=str(contract.get('contract_digest') or '')
    gate_pass=[r for r in candidates if _cs_gate_v1141(r).get('hard_pass') is True or r.get('open_eligible') is True]
    metrics_all=_cs_metric_summary_v1141(candidates)
    metrics_pass=_cs_metric_summary_v1141(gate_pass)
    structure=_cs_structure_summary_v1141(gate_pass or candidates)
    timing=_cs_timing_summary_v1141(candidates,opens,closed)
    source_mix=_cs_source_mix_v1141(gate_pass or candidates)
    epoch_id=str(epoch.get('epoch_id') or epoch.get('id') or '')
    entry_quality,exit_quality,fresh_open,fresh_closed=_cs_entry_exit_v1141(opens,closed,epoch_id)
    source_performance=_cs_source_performance_v1141(fresh_closed)
    structure_outcomes=_cs_structure_outcomes_v1141(fresh_closed,structure_review)
    book_performance=_cs_book_performance_v1141(opens,fresh_open,fresh_closed)
    market=_cs_market_v1141(regime,candidates)
    shadow=_cs_shadow_v1141(quality_policy)

    baseline_state=load_json(CANDIDATE_STANDARD_BASELINE_STATE_V1141,{}) or {}
    existing_active_baseline=_cs_dict_v1141(baseline_state.get('active_baseline'))
    # Contract baseline is allowed immediately once the full board exists. Candidate-quality
    # reference is a separate v1142 cohort and never borrows a single mutable snapshot.
    baseline_create_ready=bool(contract_digest and len(candidates)>=30)
    if not existing_active_baseline and baseline_create_ready:
        created={
            'schema':'candidate_standard_baseline_event_v1141','event':'BASELINE_CREATED','created_ts':nowv,'created_text':now_text(nowv),
            'baseline_id':f"ALT_SWING_BASELINE_{time.strftime('%Y%m%d_%H%M%S',time.localtime(nowv))}_{contract_digest[:8]}",
            'strategy_contract_digest':contract_digest,'strategy_version':contract.get('version'),'strategy_source_sha256':contract.get('strategy_source_sha256'),
            'contract':contract,
            'candidate_reference':{
                'all_rows':len(candidates),'gate_pass_rows':len(gate_pass),
                'all_metrics':metrics_all,'gate_pass_metrics':metrics_pass,
                'structure':structure,'source_mix':source_mix,'timing':timing,'market':market,
                'state':'LEGACY_SINGLE_SNAPSHOT_REFERENCE_ONLY'
            },
            'approval_state':'USER_REQUESTED_LOCK_V1141','performance_state':'COLLECTING',
            'policy':'append-only contract baseline; candidate-quality reference is separately accumulated from 30 unique fresh qualified occurrences',
        }
        _cs_append_event_v1141(CANDIDATE_STANDARD_BASELINE_LEDGER_V1141,created)
        baseline_state={'schema':'candidate_standard_baseline_state_v1141','active_baseline':created,'last_decision_state':None,'last_contract_digest':contract_digest,'updated_ts':nowv}
        save_json(CANDIDATE_STANDARD_BASELINE_STATE_V1141,baseline_state)
    baseline=_cs_dict_v1141(baseline_state.get('active_baseline'))
    baseline_ready=bool(baseline.get('baseline_id') and baseline.get('strategy_contract_digest'))

    ttl=_cs_num_v1141(paper_contract.get('candidate_ttl_sec'),default=120.0) or 120.0
    reference=_cs_update_candidate_reference_v1142(nowv,str(baseline.get('baseline_id') or ''),gate_pass,ttl) if baseline_ready else {
        'reference_state':'COLLECTING','unique_sample_count':0,'baseline_sample_count':0,'current_window_count':0,
        'comparison':{'state':'COLLECTING','axes':[],'degraded_axes':[],'improved_axes':[],'degraded_count':0}
    }
    comparison=reference.get('comparison') if isinstance(reference.get('comparison'),dict) else {}
    baseline_ref=_cs_dict_v1141(baseline.get('candidate_reference'))
    legacy_gate_pass_count=int(baseline_ref.get('gate_pass_rows') or 0)

    critical_source_missing=[]
    if not contract_digest: critical_source_missing.append('strategy_contract')
    if not candidates: critical_source_missing.append('candidate_snapshot')
    if structure.get('complete_proof_rows',0)==0: critical_source_missing.append('structure_selection_proof')
    if paper_contract.get('state')!='NORMAL': critical_source_missing.append('paper_effective_control_contract')

    contract_identity_v1144=_cs_contract_identity_v1144(baseline,contract)
    digest_match=bool(contract_identity_v1144.get('semantic_match'))
    source_hash_match=bool(contract_identity_v1144.get('source_hash_match'))
    version_match=bool(contract_identity_v1144.get('version_match'))
    release_identity_match=bool(contract_identity_v1144.get('release_identity_match'))
    release_identity_changed=bool(contract_identity_v1144.get('release_identity_changed'))
    contract_match=digest_match

    source_gaps=_cs_source_gaps_v1142(timing,structure_outcomes,market,shadow,paper_contract,metrics_pass)
    trigger_open=timing.get('trigger_to_open_delay_sec') if isinstance(timing.get('trigger_to_open_delay_sec'),dict) else {}
    candidate_reference_ready=reference.get('reference_state')=='READY' and int(reference.get('baseline_sample_count') or 0)>=30 and int(reference.get('current_window_count') or 0)>=30
    timing_ready=int(trigger_open.get('n') or 0)>=50
    closed_ready=len(fresh_closed)>=30
    market_ready=market.get('state') in ('NORMAL','WEAK')
    source_performance_ready=len(fresh_closed)>=30
    structure_outcome_ready=structure_outcomes.get('state')=='NORMAL' and len(fresh_closed)>=30

    structure_bad=bool((structure.get('complete_proof_pct') or 0)<80 and len(gate_pass or candidates)>=30)
    candidate_bad=bool(candidate_reference_ready and comparison.get('degraded_count',0)>=3)
    execution_bad=bool(candidate_reference_ready and any(x in comparison.get('degraded_axes',[]) for x in ('chase','spread','slippage','actual_rr','target_room','invalid_distance','occurrence_age')))
    source_concentrated=bool(source_mix.get('concentrated') and source_mix.get('total',0)>=30)
    market_bad=market.get('state')=='WEAK'
    exit_bad=bool(len(fresh_closed)>=30 and ((exit_quality.get('no_positive_mfe_count') or 0)/max(1,len(fresh_closed))>=0.50 or (exit_quality.get('profit_to_loss_count') or 0)/max(1,len(fresh_closed))>=0.25))

    preliminary=[]
    trig_med=_cs_num_v1141(trigger_open.get('median'))
    if int(trigger_open.get('n') or 0)>0 and trig_med is not None and trig_med>0.36:
        preliminary.append({'code':'PRELIM_TRIGGER_TO_OPEN_DELAY','n':int(trigger_open.get('n') or 0),'median_sec':trig_med,'state':'COLLECTING' if not timing_ready else 'REVIEWABLE'})
    if not candidate_reference_ready:
        preliminary.append({'code':'CANDIDATE_REFERENCE_COLLECTING','n':int(reference.get('unique_sample_count') or 0),'need':30})
    if source_mix.get('concentrated'):
        preliminary.append({'code':'PRELIM_SOURCE_CONCENTRATION','share':source_mix.get('top_share'),'n':source_mix.get('total')})
    if market.get('preliminary_mode_state')=='WEAK':
        preliminary.append({'code':'PRELIM_MARKET_WEAK_LABEL','mode':market.get('mode'),'state':market.get('state')})

    reasons=[]
    confirmed_flags=[]
    if structure_bad: confirmed_flags.append('STRUCTURE_DEGRADED')
    if candidate_bad: confirmed_flags.append('CANDIDATE_DEGRADED')
    if execution_bad: confirmed_flags.append('EXECUTION_DEGRADED')
    if exit_bad: confirmed_flags.append('EXIT_DEGRADED')
    if source_concentrated: confirmed_flags.append('SOURCE_CONCENTRATED')
    if market_bad: confirmed_flags.append('MARKET_BAD')

    if not baseline_ready:
        if not contract_digest:
            verdict='CHECK_SOURCE'; reasons.append('strategy_contract_missing')
        else:
            verdict='CHECK_SAMPLE'; reasons.append(f'contract_baseline_waiting_{len(candidates)}_of_30')
    elif not contract_match:
        verdict='SYSTEM_REGRESSION'
        reasons.append('strategy_semantic_contract_digest_changed_or_missing')
    elif critical_source_missing:
        verdict='CHECK_SOURCE'; reasons.extend(critical_source_missing)
    elif len(confirmed_flags)>=2:
        verdict='MIXED'; reasons.extend(confirmed_flags)
    elif confirmed_flags:
        verdict=confirmed_flags[0]; reasons.extend(confirmed_flags)
    elif not (candidate_reference_ready and timing_ready and closed_ready and market_ready and source_performance_ready and structure_outcome_ready):
        verdict='CHECK_SAMPLE'
        if not candidate_reference_ready: reasons.append(f"candidate_reference_{int(reference.get('unique_sample_count') or 0)}_of_30")
        if not timing_ready: reasons.append(f"trigger_to_open_path_{int(trigger_open.get('n') or 0)}_of_50")
        if not closed_ready: reasons.append(f"fresh_epoch_closed_{len(fresh_closed)}_of_30")
        if not market_ready: reasons.append(f"market_evidence_{market.get('state')}")
        if not source_performance_ready: reasons.append(f"source_performance_closed_{len(fresh_closed)}_of_30")
        if not structure_outcome_ready: reasons.append(f"structure_outcome_{structure_outcomes.get('state')}_closed_{len(fresh_closed)}_of_30")
    elif source_gaps:
        verdict='CHECK_SOURCE'; reasons.extend(source_gaps)
    else:
        verdict='NORMAL'

    readiness={
        'candidate_reference':{'state':'READY' if candidate_reference_ready else 'COLLECTING','n':int(reference.get('unique_sample_count') or 0),'need':30},
        'trigger_to_open_path':{'state':'READY' if timing_ready else 'COLLECTING','n':int(trigger_open.get('n') or 0),'need':50},
        'fresh_closed':{'state':'READY' if closed_ready else 'COLLECTING','n':len(fresh_closed),'need':30},
        'market_evidence':{'state':'READY' if market_ready else market.get('state'),'missing':market.get('source_missing') or []},
        'source_performance':{'state':'READY' if source_performance_ready else 'COLLECTING','n':len(fresh_closed),'need':30},
        'structure_outcome':{'state':'READY' if structure_outcome_ready else structure_outcomes.get('state'),'n':len(fresh_closed),'need':30},
    }

    board={
        'schema':'candidate_standard_status_v1142','version':VERSION,'build':BUILD_LABEL,'updated_ts':nowv,'updated_text':now_text(nowv),
        'baseline_identity':{
            'baseline_id':baseline.get('baseline_id'),'approval_state':baseline.get('approval_state'),
            'created_ts':baseline.get('created_ts'),'strategy_contract_digest':baseline.get('strategy_contract_digest'),
            'performance_state':baseline.get('performance_state'),
            'contract_baseline_state':'LOCKED' if baseline_ready else 'COLLECTING',
            'candidate_reference_state':reference.get('reference_state'),
            'candidate_reference_unique_n':reference.get('unique_sample_count'),
            'legacy_single_snapshot_gate_pass_n':legacy_gate_pass_count,
            'legacy_single_snapshot_reference':'REFERENCE_ONLY'
        },
        'contract_identity':{
            'state':contract_identity_v1144.get('state'),
            'semantic_state':'SAME' if digest_match else ('PENDING_BASELINE' if not baseline_ready else 'CHANGED_OR_MISSING'),
            'current_digest':contract_digest or None,'baseline_digest':baseline.get('strategy_contract_digest'),
            'strategy_version':contract.get('version'),'baseline_strategy_version':baseline.get('strategy_version'),
            'strategy_source_sha256':contract.get('strategy_source_sha256'),
            'baseline_strategy_source_sha256':baseline.get('strategy_source_sha256'),
            'digest_match':digest_match,'semantic_match':digest_match,
            'source_hash_match':source_hash_match,'version_match':version_match,
            'release_identity_match':release_identity_match,'release_identity_changed':release_identity_changed,
            'release_identity_policy':'version/source hash changes are audit evidence; only semantic contract digest owns SYSTEM_REGRESSION',
            'auto_buy':False
        },
        'structure_contract':contract.get('timeframe_contract') or {},
        'structure_methods':{'active':contract.get('active_structure_method') or {},'observation_only':contract.get('observation_only_structure_methods') or []},
        'structure_selection_evidence':structure,
        'timing_path':timing,
        'candidate_quality':{
            'all_rows':len(candidates),'gate_pass_rows':len(gate_pass),'all_metrics':metrics_all,'gate_pass_metrics':metrics_pass,
            'baseline_comparison':comparison,
            'reference_state':{
                'state':reference.get('reference_state'),'unique_sample_count':reference.get('unique_sample_count'),
                'baseline_sample_count':reference.get('baseline_sample_count'),'current_window_count':reference.get('current_window_count'),
                'added_this_cycle':reference.get('added_this_cycle'),'skipped_stale':reference.get('skipped_stale'),
                'policy':reference.get('policy')
            },
            'legacy_v1141_snapshot_reference':{
                'state':'REFERENCE_ONLY','gate_pass_rows':legacy_gate_pass_count,
                'reason':'single mutable snapshot and wall-clock occurrence age must not own degradation verdict'
            }
        },
        'source_mix':source_mix,
        'source_performance':source_performance,
        'structure_outcomes':structure_outcomes,
        'gate_accuracy':{
            'source':'clean_quality_policy_comparison_status_v1125.json',
            'state':shadow.get('state'),
            'false_pass_60m_count':shadow.get('false_pass_60m_count'),
            'false_block_60m_count':shadow.get('false_block_60m_count'),
            'comparison_ready':shadow.get('comparison_ready'),
            'policy':'reference-only until current+improved same-market payload exists'
        },
        'entry_quality':entry_quality,
        'exit_quality':exit_quality,
        'book_performance':book_performance,
        'market_context':market,
        'same_market_shadow':shadow,
        'paper_contract':paper_contract,
        'sample_contract':{
            'candidate_reference_min':30,'path_min':50,'fresh_closed_check':30,
            'fresh_closed_directional':60,'baseline_replacement_review':100,
            'policy':'sample thresholds affect display confidence only; never entry generation'
        },
        'readiness':readiness,
        'source_gaps':source_gaps,
        'preliminary_signals':preliminary,
        'operations_separate':{
            'strategy_cycle_sec':(load_json(STRATEGY_STATUS_V1141,{}) or {}).get('last_sec'),
            'paper_status_age_sec':max(0.0,nowv-PAPER_STATUS_V1141.stat().st_mtime) if PAPER_STATUS_V1141.exists() else None,
            'policy':'runtime/resource problems never become candidate/market verdict silently'
        },
        'final_judgement':{
            'state':verdict,'reasons':reasons,
            'confirmed_flags':confirmed_flags,'preliminary_signals':[x.get('code') for x in preliminary],
            'system_regression_blocks_market_blame':bool(baseline_ready and not digest_match),
            'critical_source_missing':critical_source_missing,'source_gaps':source_gaps,
            'fresh_closed_count':len(fresh_closed)
        },
        'change_history':{
            'baseline_ledger':CANDIDATE_STANDARD_BASELINE_LEDGER_V1141.name,
            'decision_ledger':CANDIDATE_STANDARD_DECISION_LEDGER_V1141.name,
            'reference_ledger':CANDIDATE_STANDARD_REFERENCE_LEDGER_V1142.name,
            'append_only':True
        },
        'invariants':{
            'gate_changed':False,'rank_changed':False,'trigger_invalid_target_changed':False,
            'exit_changed':False,'open_limit_changed':False,'auto_buy':False
        },
    }

    time_state='PARTIAL_SOURCE' if timing.get('source_missing_segments') else ('NORMAL' if timing_ready else 'COLLECTING')
    structure_outcome_section=structure_outcomes.get('state') or 'COLLECTING'
    market_section=market.get('state') or 'SOURCE_MISSING'
    shadow_section=shadow.get('state') or 'SOURCE_MISSING'
    sections=[
        ('01_baseline_identity','NORMAL' if baseline_ready else 'COLLECTING'),
        ('02_structure_generation','NORMAL' if contract.get('timeframe_contract') and structure.get('complete_proof_rows',0)>0 else 'SOURCE_MISSING'),
        ('03_time_path',time_state),
        ('04_candidate_quality','NORMAL' if candidate_reference_ready else 'COLLECTING'),
        ('05_source_inflow_performance',source_performance.get('state') or 'COLLECTING'),
        ('06_gate_false_pass_block',shadow_section),
        ('07_actual_entry_quality',entry_quality.get('sample_state') or 'COLLECTING'),
        ('08_exit_quality',exit_quality.get('sample_state') or 'COLLECTING'),
        ('09_closed_plus_open','NORMAL' if closed_ready else 'COLLECTING'),
        ('10_market_state',market_section),
        ('11_same_market_shadow',shadow_section),
        ('12_final_cause','NORMAL' if verdict=='NORMAL' else verdict),
        ('13_change_history','NORMAL'),
    ]
    source_states=('SOURCE_MISSING','CHECK_SOURCE','PARTIAL_SOURCE')
    board['section_completeness']={
        'total':13,'items':[{'section':a,'state':b} for a,b in sections],
        'normal_count':sum(1 for _a,b in sections if b=='NORMAL'),
        'collecting_count':sum(1 for _a,b in sections if b in ('COLLECTING','CHECK_SMALL_SAMPLE','CHECK_SAMPLE')),
        'source_missing_count':sum(1 for _a,b in sections if b in source_states),
        'source_gap_count':len(source_gaps),
        'all_sections_present':len(sections)==13,
        'policy':'all 13 sections are emitted; nested missing evidence is counted and shown'
    }

    last_state=str(baseline_state.get('last_decision_state') or '')
    last_digest=str(baseline_state.get('last_contract_digest') or '')
    if verdict!=last_state or contract_digest!=last_digest:
        event={
            'schema':'candidate_standard_decision_event_v1142','ts':nowv,'time':now_text(nowv),
            'baseline_id':baseline.get('baseline_id'),'state':verdict,'reasons':reasons,
            'confirmed_flags':confirmed_flags,'preliminary_signals':[x.get('code') for x in preliminary],
            'contract_digest':contract_digest,'previous_state':last_state or None,
            'critical_source_missing':critical_source_missing,'source_gaps':source_gaps,
            'candidate_rows':len(candidates),'gate_pass_rows':len(gate_pass),
            'candidate_reference_n':reference.get('unique_sample_count'),
            'trigger_to_open_n':trigger_open.get('n'),'fresh_closed':len(fresh_closed)
        }
        _cs_append_event_v1141(CANDIDATE_STANDARD_DECISION_LEDGER_V1141,event)
        baseline_state['last_decision_state']=verdict
        baseline_state['last_contract_digest']=contract_digest
        baseline_state['updated_ts']=nowv
        save_json(CANDIDATE_STANDARD_BASELINE_STATE_V1141,baseline_state)
    save_json(CANDIDATE_STANDARD_STATUS_V1141,board)
    return board

def _v1141_standard_source_signature() -> str:
    parts=[]
    for path in (CANDIDATE_STANDARD_CONTRACT_V1141,PAPER_LATEST,OPEN,CANONICAL_PERFORMANCE_V987,REGIME,QUALITY_POLICY_V1141,PERFORMANCE_EPOCH_V1141,PAPER_CONTROL_V1141):
        try:
            st=path.stat(); parts.append(f'{path.name}:{st.st_size}:{st.st_mtime_ns}')
        except Exception: parts.append(f'{path.name}:MISSING')
    return hashlib.sha256('|'.join(parts).encode()).hexdigest()


_CANDIDATE_STANDARD_LAST_RUN_MONO = 0.0
_CANDIDATE_STANDARD_LAST_SOURCE_SIG = ''

def _candidate_standard_cycle_update() -> Dict[str,Any]:
    """Canonical Review-owned candidate standard update.

    This is called directly by the single active run_once. It never wraps or
    aliases run_once, so a missing legacy variable cannot stop Review.
    """
    global _CANDIDATE_STANDARD_LAST_RUN_MONO, _CANDIDATE_STANDARD_LAST_SOURCE_SIG
    mono=time.monotonic()
    sig=_v1141_standard_source_signature()
    due=(mono-_CANDIDATE_STANDARD_LAST_RUN_MONO>=60.0) or (not CANDIDATE_STANDARD_STATUS_V1141.exists())
    if not due:
        return {
            'state':'CADENCE_SKIP',
            'source_changed':sig!=_CANDIDATE_STANDARD_LAST_SOURCE_SIG,
            'cadence_sec':60,
            'writer_owner':'review_worker.run_once',
        }
    try:
        board=update_candidate_standard(now_ts(),None,None)
    except Exception as exc:
        append_error(ERROR,'candidate_standard',exc)
        return {
            'state':'ERROR',
            'error':f'{exc.__class__.__name__}: {exc}',
            'cadence_sec':60,
            'writer_owner':'review_worker.run_once',
        }
    _CANDIDATE_STANDARD_LAST_RUN_MONO=mono
    _CANDIDATE_STANDARD_LAST_SOURCE_SIG=sig
    return {
        'state':(board.get('final_judgement') or {}).get('state'),
        'baseline_id':(board.get('baseline_identity') or {}).get('baseline_id'),
        'candidate_rows':(board.get('candidate_quality') or {}).get('all_rows'),
        'reference_state':((board.get('candidate_quality') or {}).get('reference_state') or {}).get('state'),
        'cadence_sec':60,
        'writer_owner':'review_worker.run_once',
    }





# =============================================================================
# Review v2.014 / release v2014: prospective 1h/3h entry-survival cause shadow
# Observation only. No fixed early-stop threshold and no candidate/exit change.
# Only OPENs created after this shadow starts are enrolled, so 1h/3h paths are
# never backfilled from current values or ticker/time proximity.
# =============================================================================
ENTRY_SURVIVAL_LEDGER_V2014 = BASE_DIR / 'shadow_entry_survival_events_v2014.jsonl'
ENTRY_SURVIVAL_HORIZONS_V2014 = (('1h',3600.0),('3h',10800.0),('6h',21600.0))


def _v2014_entry_survival_event(row: Dict[str,Any], pos: str, decision: str) -> str:
    if pos:
        return 'pos:'+pos
    if decision:
        return 'decision:'+decision
    return ''


def _v2014_entry_metrics(row: Dict[str,Any]) -> Dict[str,Optional[float]]:
    """Read entry-time candidate/OPEN sealed fields only; no live fmap/ofmap."""
    gate=_cs_gate_v1141(row)
    quality=_cs_dict_v1141(row.get('swing_quality_gate'),gate.get('swing_quality_gate'))
    qm=_cs_dict_v1141(quality.get('metrics'),(_cs_dict_v1141(row.get('quality_observation_v925'))).get('metrics'))
    return {
        'reaction':_cs_num_v1141(row.get('price_reaction_pct'),qm.get('price_reaction_pct')),
        'relative_strength_rank':_cs_num_v1141(row.get('relative_strength_rank_pct_v1095'),row.get('relative_strength_rank_pct'),qm.get('relative_strength_rank_pct')),
        'relative_strength':_cs_num_v1141(row.get('relative_strength_pct'),row.get('relative_strength'),qm.get('relative_strength')),
        'money_flow':_cs_num_v1141(row.get('money_flow_score'),qm.get('money_flow')),
        'buy_sustain':_cs_num_v1141(row.get('buy_sustain_1m'),row.get('buy_sustain_60s'),qm.get('buy_sustain_1m')),
    }


def _v2014_entry_geometry(row: Dict[str,Any]) -> Dict[str,Optional[float]]:
    gate=_cs_gate_v1141(row); occ=_cs_occurrence_v1141(row)
    entry=_cs_num_v1141(row.get('actual_entry_price'),row.get('entry_price'),(_cs_dict_v1141(row.get('canonical_entry_snapshot'))).get('actual_entry_price'))
    trigger=_cs_num_v1141(row.get('swing_trigger_price_v977'),row.get('trigger_price'),gate.get('trigger_price'),occ.get('trigger_price'))
    invalid=_cs_num_v1141(gate.get('invalid_price'),row.get('swing_invalid_price_v977'),row.get('invalid_price'))
    target=_cs_num_v1141(gate.get('target_price'),row.get('swing_target_price_v977'),row.get('target_price'))
    return {
        'entry_price':entry,
        'trigger_chase_pct':abs(_cs_pct_between_v1141(entry,trigger)) if entry and trigger else None,
        'invalid_distance_pct':abs(_cs_pct_between_v1141(invalid,entry)) if entry and invalid else None,
        'target_room_pct':_cs_pct_between_v1141(target,entry) if entry and target else None,
    }


def _v2014_live_strength(row: Dict[str,Any], fmap: Dict[str,Dict[str,Any]], ofmap: Dict[str,Dict[str,Any]]) -> Dict[str,Optional[float]]:
    ticker=_cs_ticker_v1141(row)
    feature=fmap.get(ticker,{}) if ticker else {}
    orderflow=ofmap.get(ticker,{}) if ticker else {}
    metrics=_v2011_strength_metrics(row,feature if isinstance(feature,dict) else {},orderflow if isinstance(orderflow,dict) else {})
    return {
        'relative_strength_rank':_v2011_metric_from_sources(row,feature if isinstance(feature,dict) else {},orderflow if isinstance(orderflow,dict) else {},('relative_strength_rank_pct_v1095','relative_strength_rank_pct')),
        'relative_strength':metrics.get('relative_strength'),
        'money_flow':metrics.get('money_flow'),
        'buy_sustain':metrics.get('buy_sustain'),
        'buy_ratio':metrics.get('buy_ratio'),
        'orderflow_score':metrics.get('orderflow_score'),
    }


def _v2014_weak_recover_votes(current: Dict[str,Optional[float]], baseline: Dict[str,Optional[float]], previous: Dict[str,Optional[float]]) -> tuple[int,int,int]:
    weak=0; recover=0; comparable=0
    # v2024: the relative-strength axis uses the Feature-owned whole-alt rank when sealed.
    # Raw relative strength remains a fallback, never a zero-filled substitute.
    rel_key='relative_strength_rank' if baseline.get('relative_strength_rank') is not None else 'relative_strength'
    for key in (rel_key,'money_flow','buy_sustain'):
        cur=current.get(key); base=baseline.get(key); prev=previous.get(key)
        if cur is None or base is None or prev is None:
            continue
        comparable+=1
        if cur < base and cur < prev:
            weak+=1
        if cur > prev:
            recover+=1
    return weak,recover,comparable


def _v2014_live_mfe_mae(row: Dict[str,Any], pnl: float, rec: Dict[str,Any]) -> tuple[float,float]:
    mfe=_cs_num_v1141(row.get('mfe_pct'),row.get('max_profit_pct'),row.get('max_pnl_pct'))
    mae=_cs_num_v1141(row.get('mae_pct'),row.get('min_profit_pct'),row.get('min_pnl_pct'))
    prior_peak=_cs_num_v1141(rec.get('observed_peak_pct'),pnl) or pnl
    prior_low=_cs_num_v1141(rec.get('observed_low_pct'),pnl) or pnl
    peak=max(float(prior_peak),float(pnl),float(mfe) if mfe is not None else float(pnl))
    low=min(float(prior_low),float(pnl),float(mae) if mae is not None else float(pnl))
    return peak,low


def _v2014_horizon_classify(label: str, rec: Dict[str,Any], pnl: float, peak: float, weak_votes: int, recover_votes: int, comparable: int) -> str:
    entry_metrics=rec.get('entry_metrics') if isinstance(rec.get('entry_metrics'),dict) else {}
    known_axes=sum((
        1 if entry_metrics.get('reaction') is not None else 0,
        1 if entry_metrics.get('relative_strength_rank') is not None or entry_metrics.get('relative_strength') is not None else 0,
        1 if entry_metrics.get('money_flow') is not None else 0,
        1 if entry_metrics.get('buy_sustain') is not None else 0,
    ))
    entry_ready=known_axes>=3
    if not entry_ready or comparable<2:
        return 'SOURCE_MISSING'
    no_positive=bool(peak<=0.0)
    if label=='1h':
        if no_positive:
            return 'NO_PROGRESS'
        if pnl<=0 and weak_votes>=2:
            return 'WEAKENING'
        return 'ALIVE'
    one=((rec.get('horizons') or {}).get('1h') or {}) if isinstance(rec.get('horizons'),dict) else {}
    one_state=str(one.get('classification') or '')
    if one_state in ('NO_PROGRESS','WEAKENING') and (peak>0 or pnl>0 or recover_votes>=2):
        return 'RECOVERED'
    if no_positive:
        return 'NO_PROGRESS'
    if pnl<=0 and weak_votes>=2:
        return 'PERSISTENT_WEAK'
    return 'ALIVE'


def _v2014_median_metric(records: List[Dict[str,Any]], key: str) -> Optional[float]:
    values=[]
    for rec in records:
        metrics=rec.get('entry_metrics') if isinstance(rec.get('entry_metrics'),dict) else {}
        value=_cs_num_v1141(metrics.get(key))
        if value is not None:
            values.append(float(value))
    return _cs_median_v1141(values)


def _v2014_entry_compare(records: List[Dict[str,Any]], horizon: str) -> Dict[str,Any]:
    weak_states={'1h':{'NO_PROGRESS','WEAKENING'},'3h':{'NO_PROGRESS','PERSISTENT_WEAK'}}.get(horizon,{'NO_PROGRESS','PERSISTENT_WEAK'})
    alive_states={'1h':{'ALIVE'},'3h':{'ALIVE','RECOVERED'}}.get(horizon,{'ALIVE','RECOVERED'})
    weak=[]; alive=[]
    for rec in records:
        h=(rec.get('horizons') or {}).get(horizon) if isinstance(rec.get('horizons'),dict) else None
        if not isinstance(h,dict): continue
        state=str(h.get('classification') or '')
        if state in weak_states: weak.append(rec)
        elif state in alive_states: alive.append(rec)
    axes={}
    for key in ('reaction','relative_strength_rank','relative_strength','money_flow','buy_sustain'):
        w=_v2014_median_metric(weak,key); a=_v2014_median_metric(alive,key)
        axes[key]={'weak_median':w,'alive_median':a,'delta_alive_minus_weak':round(float(a)-float(w),6) if a is not None and w is not None else None}
    return {'horizon':horizon,'weak_n':len(weak),'alive_n':len(alive),'axes':axes,'policy':'descriptive cohort medians only; no threshold or gate'}


def _v2014_entry_survival_shadow(nowv: float, closed_rows: List[Dict[str,Any]], fmap: Dict[str,Dict[str,Any]], ofmap: Dict[str,Dict[str,Any]], state: Dict[str,Any]) -> Dict[str,Any]:
    start_ts=_cs_num_v1141(state.get('entry_survival_start_ts_v2014'))
    start_initialized=False
    if start_ts is None:
        start_ts=float(nowv); state['entry_survival_start_ts_v2014']=float(nowv); state['entry_survival_start_text_v2014']=now_text(nowv); start_initialized=True
    active=state.get('entry_survival_active_v2014') if isinstance(state.get('entry_survival_active_v2014'),dict) else {}
    finalized=state.get('entry_survival_finalized_v2014') if isinstance(state.get('entry_survival_finalized_v2014'),dict) else {}
    open_rows=_v923_open_rows(); current_ids=set(); events=0
    for row in open_rows:
        if not isinstance(row,dict): continue
        pos=_v2010_exact_pos_key(row); decision=_v2010_exact_event_key(row)
        ident=_v2014_entry_survival_event(row,pos,decision)
        opened=_cs_opened_ts_v1142(row)
        if not ident or opened is None or float(opened)<float(start_ts):
            continue
        current_ids.add(ident)
        pnl=_cs_row_pnl_v1141(row)
        if pnl is None: continue
        ticker=_cs_ticker_v1141(row)
        rec=active.get(ident) if isinstance(active.get(ident),dict) else None
        if rec is None:
            rec={'identity':ident,'pos_id':pos or None,'decision_key':decision or None,'ticker':ticker,'opened_at':float(opened),'opened_text':now_text(float(opened)),'enrolled_ts':nowv,'entry_metrics':_v2014_entry_metrics(row),'entry_geometry':_v2014_entry_geometry(row),'prior_live_metrics':_v2014_live_strength(row,fmap,ofmap),'observed_peak_pct':float(pnl),'observed_low_pct':float(pnl),'horizons':{},'auto_buy':False,'actual_entry_changed':False,'actual_exit_changed':False}
            active[ident]=rec
            _V2010_SHADOW_EVENT_BATCH.setdefault(str(ENTRY_SURVIVAL_LEDGER_V2014),[]).append({'schema':'shadow_entry_survival_event_v2014','event':'ENROLLED','identity':ident,'pos_id':pos or None,'decision_key':decision or None,'ticker':ticker,'ts':nowv,'time':now_text(nowv),'opened_at':opened,'entry_metrics':rec['entry_metrics'],'entry_geometry':rec['entry_geometry'],'forward_only_after_start_ts':start_ts,'auto_buy':False,'actual_entry_changed':False,'actual_exit_changed':False})
            events+=1
        live=_v2014_live_strength(row,fmap,ofmap)
        prior=rec.get('prior_live_metrics') if isinstance(rec.get('prior_live_metrics'),dict) else {}
        baseline=rec.get('entry_metrics') if isinstance(rec.get('entry_metrics'),dict) else {}
        weak_votes,recover_votes,comparable=_v2014_weak_recover_votes(live,baseline,prior)
        peak,low=_v2014_live_mfe_mae(row,float(pnl),rec); rec['observed_peak_pct']=peak; rec['observed_low_pct']=low
        elapsed=max(0.0,float(nowv)-float(rec.get('opened_at') or nowv))
        horizons=rec.get('horizons') if isinstance(rec.get('horizons'),dict) else {}; rec['horizons']=horizons
        for label,sec in ENTRY_SURVIVAL_HORIZONS_V2014:
            if label in horizons or elapsed<sec: continue
            classification=_v2014_horizon_classify(label,rec,float(pnl),peak,weak_votes,recover_votes,comparable)
            snapshot={'completed_ts':nowv,'completed_text':now_text(nowv),'elapsed_sec':round(elapsed,3),'pnl_pct':round(float(pnl),6),'observed_peak_pct':round(float(peak),6),'observed_low_pct':round(float(low),6),'classification':classification,'weak_votes':weak_votes,'recover_votes':recover_votes,'comparable_strength_axes':comparable,'live_metrics':dict(live)}
            horizons[label]=snapshot
            _V2010_SHADOW_EVENT_BATCH.setdefault(str(ENTRY_SURVIVAL_LEDGER_V2014),[]).append({'schema':'shadow_entry_survival_event_v2014','event':'HORIZON','identity':ident,'pos_id':rec.get('pos_id'),'decision_key':rec.get('decision_key'),'ticker':ticker,'horizon':label,'ts':nowv,'time':now_text(nowv),**snapshot,'entry_metrics':rec.get('entry_metrics'),'entry_geometry':rec.get('entry_geometry'),'auto_buy':False,'actual_entry_changed':False,'actual_exit_changed':False})
            events+=1
        rec['prior_live_metrics']=dict(live); rec['last_pnl_pct']=round(float(pnl),6); rec['last_seen_ts']=nowv

    closed_by_pos={}; closed_by_decision={}
    for row in closed_rows:
        pos=_v2010_exact_pos_key(row); dec=_v2010_exact_event_key(row)
        if pos: closed_by_pos[pos]=row
        if dec: closed_by_decision[dec]=row
    for ident,rec in list(active.items()):
        if ident in current_ids: continue
        closed=closed_by_pos.get(str(rec.get('pos_id'))) if rec.get('pos_id') else None
        if closed is None and rec.get('decision_key'): closed=closed_by_decision.get(str(rec.get('decision_key')))
        if closed is None: continue
        actual=_cs_row_pnl_v1141(closed)
        if actual is None: continue
        mfe=_cs_num_v1141(closed.get('mfe_pct'),closed.get('max_profit_pct'),closed.get('max_pnl_pct'))
        mae=_cs_num_v1141(closed.get('mae_pct'),closed.get('min_profit_pct'),closed.get('min_pnl_pct'))
        reason=str(closed.get('exit_reason') or closed.get('close_reason') or closed.get('reason') or '').strip()
        rec['actual_close']={'pnl_pct':round(float(actual),6),'mfe_pct':mfe,'mae_pct':mae,'exit_reason':reason,'no_positive_mfe':bool(mfe is not None and float(mfe)<=0),'closed_match':'EXACT_POS_ID' if rec.get('pos_id') and rec.get('pos_id') in closed_by_pos else 'EXACT_DECISION_KEY','closed_ts':nowv}
        rec['finalized_ts']=nowv; finalized[ident]=rec; active.pop(ident,None)
        _V2010_SHADOW_EVENT_BATCH.setdefault(str(ENTRY_SURVIVAL_LEDGER_V2014),[]).append({'schema':'shadow_entry_survival_event_v2014','event':'ACTUAL_CLOSE','identity':ident,'pos_id':rec.get('pos_id'),'decision_key':rec.get('decision_key'),'ticker':rec.get('ticker'),'ts':nowv,'time':now_text(nowv),'actual_close':rec.get('actual_close'),'horizons':rec.get('horizons'),'entry_metrics':rec.get('entry_metrics'),'entry_geometry':rec.get('entry_geometry'),'auto_buy':False,'actual_entry_changed':False,'actual_exit_changed':False})
        events+=1
    cutoff=float(nowv)-UNIFIED_SHADOW_STATE_RETENTION_SEC_V2010
    finalized={k:v for k,v in finalized.items() if float(v.get('finalized_ts') or 0)>=cutoff}
    state['entry_survival_active_v2014']=active; state['entry_survival_finalized_v2014']=finalized
    if start_initialized:
        _v2010_checkpoint_shadow_state(state,force=True)
    all_records=list(active.values())+list(finalized.values())
    horizon_counts={}
    for label,_sec in ENTRY_SURVIVAL_HORIZONS_V2014:
        counter=Counter()
        for rec in all_records:
            h=(rec.get('horizons') or {}).get(label) if isinstance(rec.get('horizons'),dict) else None
            if isinstance(h,dict): counter[str(h.get('classification') or 'UNKNOWN')]+=1
        horizon_counts[label]=dict(counter)
    closed_records=[rec for rec in finalized.values() if isinstance(rec.get('actual_close'),dict)]
    actual_pnls=[float((rec.get('actual_close') or {}).get('pnl_pct') or 0) for rec in closed_records]
    samples=[]
    for rec in sorted(all_records,key=lambda r:float(r.get('opened_at') or 0),reverse=True):
        if len(samples)>=5: break
        samples.append({'ticker':rec.get('ticker'),'one_hour':((rec.get('horizons') or {}).get('1h') or {}).get('classification') if isinstance(rec.get('horizons'),dict) else None,'three_hour':((rec.get('horizons') or {}).get('3h') or {}).get('classification') if isinstance(rec.get('horizons'),dict) else None,'last_pnl_pct':rec.get('last_pnl_pct'),'entry_metrics':rec.get('entry_metrics')})
    return {'state':'ACTIVE' if all_records else 'COLLECTING','forward_start_ts':start_ts,'forward_start_text':state.get('entry_survival_start_text_v2014'),'tracked':len(all_records),'active_open':len(active),'finalized_closed':len(closed_records),'horizon_counts':horizon_counts,'entry_compare_1h':_v2014_entry_compare(all_records,'1h'),'entry_compare_3h':_v2014_entry_compare(all_records,'3h'),'actual_closed':{'n':len(closed_records),'sum_pnl_pct':round(sum(actual_pnls),6),'avg_pnl_pct':round(sum(actual_pnls)/len(actual_pnls),6) if actual_pnls else None,'loss_count':sum(1 for p in actual_pnls if p<0),'no_positive_mfe_count':sum(1 for rec in closed_records if bool((rec.get('actual_close') or {}).get('no_positive_mfe')))},'events_this_cycle':events,'sample':samples,'policy':'forward-only cause shadow: compare sealed entry reaction/relative-strength/money-flow/buy-sustain between 1h/3h weak and alive cohorts; horizons observe actual OPEN path and exact close only. Descriptive comparison only; no fixed early stop, gate, selector or exit change.','locks':{'retroactive_recalc':False,'ticker_time_proximity_match':False,'actual_candidate_changed':False,'actual_entry_changed':False,'actual_exit_changed':False,'auto_buy':False}}


_V2014_PREV_UNIFIED_SHADOW_UPDATE = _v2010_unified_shadow_cycle_update

def _v2010_unified_shadow_cycle_update(nowv: float, candidate_rows: List[Dict[str,Any]], closed_rows: List[Dict[str,Any]], fmap: Dict[str,Dict[str,Any]], ofmap: Dict[str,Dict[str,Any]], summary: Dict[str,Any], good_s2: Dict[str,Any], quality_shadow: Dict[str,Any]) -> Dict[str,Any]:  # type: ignore[override]
    board=_V2014_PREV_UNIFIED_SHADOW_UPDATE(nowv,candidate_rows,closed_rows,fmap,ofmap,summary,good_s2,quality_shadow)
    state=_v2010_shadow_state()
    survival=_v2014_entry_survival_shadow(nowv,closed_rows,fmap,ofmap,state)
    board=dict(board) if isinstance(board,dict) else {}
    board['schema']='unified_shadow_status_v2014'; board['version']=VERSION; board['build']=BUILD_LABEL
    board['entry_survival']=survival
    runtime=board.get('writer_runtime_v2010') if isinstance(board.get('writer_runtime_v2010'),dict) else {}
    runtime['entry_survival_v2014']={'events_this_cycle':survival.get('events_this_cycle',0),'forward_start_ts':survival.get('forward_start_ts'),'state_save_lag_max_sec':UNIFIED_SHADOW_STATE_CHECKPOINT_SEC_V2010}
    runtime['event_batch_flush_v2014']=_v2010_flush_shadow_event_batches()
    board['writer_runtime_v2010']=runtime
    save_json(UNIFIED_SHADOW_STATUS_V2010,board)
    return board


def _v2014_review_issue_once() -> None:
    marker=BASE_DIR/'runtime'/'v2014_entry_survival_cause_shadow.seeded'
    if marker.exists(): return
    ts=now_ts(); text=now_text(ts)
    try:
        _v2010_append_jsonl(BASE_DIR/'runtime'/'change_verify_ledger.jsonl',{'schema':'change_verify_ledger_v870','change_id':'v2014-entry-survival-cause-shadow-001','issue_id':'EARLY-DEATH-CAUSE-SHADOW-2014','version':'v2014','verify_result':'CHECK','created_ts':ts,'created_at':text,'created_text':text,'writer':'review_v2014_lifecycle_writer','symptom':'Many positions finish with no positive MFE or remain deeply negative; exit-only analysis cannot tell whether they were weak before entry, died within 1h, or failed to recover by 3h.','cause':'The unified shadow had 6h no-progress totals but no forward-only per-position 1h/3h survival path joined to sealed entry reaction/relative-strength/money-flow/buy-sustain.','files_changed':['review_worker_v2.014.py','coinbot_main_v2_13_2014.py'],'new_mainline':'Enroll only OPENs created after v2014 shadow start. Compare sealed entry metrics between weak and alive cohorts, record 1h/3h/6h prospective path and exact actual close. No hard threshold or virtual early exit is created.','not_touched':['candidate/S1/Paper/OPEN flow','candidate count','trigger/invalid/target','RR/room/chase/cost gates','actual exit/trailing','protected ledgers','Guard v2008','Paper v2009','Strategy v2010','auto-buy OFF'],'remaining':'Collect 1h then 3h forward cohorts; inspect which sealed entry axes separate no-progress/persistent-weak from alive/recovered before designing any new protection or quality rule.','auto_buy':False})
        _v2010_append_jsonl(BASE_DIR/'ledger'/'issue_ledger_events.jsonl',{'schema':'coinbot_single_work_ledger_v870','event_type':'ISSUE','issue_id':'EARLY-DEATH-CAUSE-SHADOW-2014','status':'CHECK','title':'진입 후 1~3시간 죽는 거래 원인 shadow','detail':'신규 OPEN만 forward 추적. 진입 당시 반응·상대강도·돈흐름·매수지속과 1h/3h 생존상태를 비교. 본선 변경 없음.','version':'v2014','created_ts':ts,'created_at':text,'created_text':text,'auto_buy':False})
        marker.parent.mkdir(parents=True,exist_ok=True); marker.write_text(text,encoding='utf-8')
    except Exception: pass

try: _v2014_review_issue_once()
except Exception: pass


# v1401 identity unification override (no trading-rule changes)
VERSION = 'review_worker_v2.014'
BUILD_LABEL = 'v2014_entry_survival_cause_shadow_2026-07-15'
MAIN_DEPLOY_VERSION = BUILD_LABEL


# =============================================================================
# review_worker v2.015: 10-slot selector x cycle-intake forward shadow
# - Input is Paper's exact final-passed pre-OPEN cycle feed.
# - 4 selectors x cycle intake 1/2/3/unlimited, all with max virtual OPEN 10.
# - Uses exact actual OPEN/CLOSED path only; no proxy and no retroactive reconstruction.
# =============================================================================
TOP10_SHADOW_FEED_V2015 = BASE_DIR / 'paper_top10_shadow_candidate_events_v2015.jsonl'
TOP10_SHADOW_LEDGER_V2015 = BASE_DIR / 'shadow_top10_selection_events_v2015.jsonl'
TOP10_SHADOW_HORIZONS_V2015 = (('3h',10800.0),('6h',21600.0),('12h',43200.0),('24h',86400.0))
TOP10_SHADOW_SELECTORS_V2015 = ('CURRENT_RANK','TRIGGER_REACTION','FLOW_SUSTAIN','BALANCED')
TOP10_SHADOW_CAPS_V2015 = (1,2,3,0)
TOP10_SHADOW_MAX_OPEN_V2015 = 10
TOP10_SHADOW_FEED_TAIL_V2015 = 6000
_V2015_PREV_UNIFIED_SHADOW_UPDATE = _v2010_unified_shadow_cycle_update


def _v2015n(value: Any, default: Optional[float]=None) -> Optional[float]:
    try:
        if value in (None,''): return default
        out=float(value)
        if math.isfinite(out): return out
    except Exception: pass
    return default


def _v2015_candidate_identity(row: Dict[str,Any]) -> str:
    pos=str(row.get('pos_id') or '').strip(); dec=str(row.get('decision_key') or '').strip()
    return ('pos:'+pos) if pos else (('decision:'+dec) if dec else '')


def _v2015_selector_key(row: Dict[str,Any], selector: str):
    rank=_v2015n(row.get('rank'),1e9); rank_score=_v2015n(row.get('rank_score'),-1e9)
    reaction=_v2015n(row.get('reaction'),-1e9); rs=_v2015n(row.get('relative_strength'),-1e9)
    money=_v2015n(row.get('money_flow'),-1e9); sustain=_v2015n(row.get('buy_sustain'),-1e9); buy=_v2015n(row.get('buy_ratio'),-1e9)
    rr=_v2015n(row.get('actual_rr'),-1e9); room=_v2015n(row.get('target_room'),-1e9); spread=_v2015n(row.get('spread'),1e9); slip=_v2015n(row.get('slippage'),1e9); age=_v2015n(row.get('occurrence_age'),1e9)
    lane=str(row.get('source_lane') or '')
    fresh_bonus=1 if ('FRESH' in str(row.get('occurrence_state') or '').upper() or 'REBREAK' in str(row.get('reentry_state') or '').upper()) else 0
    if selector=='CURRENT_RANK':
        return (rank, -rank_score, str(row.get('ticker') or ''))
    if selector=='TRIGGER_REACTION':
        return (-fresh_bonus, -reaction, age, -rank_score, str(row.get('ticker') or ''))
    if selector=='FLOW_SUSTAIN':
        return (-money, -sustain, -buy, -rs, -rank_score, str(row.get('ticker') or ''))
    good_lane=1 if lane in ('돈흐름','주도흐름') else 0
    positive_reaction=1 if reaction>0 else 0
    healthy_invalid=1 if _v2015n(row.get('invalid_distance')) is not None and 1.5<=float(row.get('invalid_distance'))<3.0 else 0
    return (-good_lane,-positive_reaction,-sustain,-money,-rs,-healthy_invalid,-rr,-room,spread,slip,rank,-rank_score,str(row.get('ticker') or ''))


def _v2015_feed_cycles() -> List[Dict[str,Any]]:
    rows=read_jsonl(TOP10_SHADOW_FEED_V2015,max_lines=TOP10_SHADOW_FEED_TAIL_V2015)
    dedup={}
    for row in rows:
        if not isinstance(row,dict) or row.get('event')!='PREOPEN_ELIGIBLE_CYCLE': continue
        eid=str(row.get('event_id') or '').strip()
        if eid: dedup[eid]=row
    return sorted(dedup.values(),key=lambda r:float(r.get('ts') or 0))


def _v2015_live_maps(closed_rows: List[Dict[str,Any]]):
    open_pos={}; open_dec={}
    for row in _v923_open_rows():
        pos=_v2010_exact_pos_key(row); dec=_v2010_exact_event_key(row)
        if pos: open_pos[pos]=row
        if dec: open_dec[dec]=row
    closed_pos={}; closed_dec={}
    for row in closed_rows:
        pos=_v2010_exact_pos_key(row); dec=_v2010_exact_event_key(row)
        if pos: closed_pos[pos]=row
        if dec: closed_dec[dec]=row
    return open_pos,open_dec,closed_pos,closed_dec


def _v2015_actual_row(rec: Dict[str,Any], open_pos,open_dec,closed_pos,closed_dec):
    pos=str(rec.get('pos_id') or ''); dec=str(rec.get('decision_key') or '')
    opened=open_pos.get(pos) if pos else None
    if opened is None and dec: opened=open_dec.get(dec)
    closed=closed_pos.get(pos) if pos else None
    if closed is None and dec: closed=closed_dec.get(dec)
    return opened,closed


def _v2015_portfolio_perf(port: Dict[str,Any]) -> Dict[str,Any]:
    active=port.get('active') if isinstance(port.get('active'),dict) else {}
    closed=port.get('closed') if isinstance(port.get('closed'),dict) else {}
    closed_pnls=[]; open_pnls=[]; mfes=[]; maes=[]
    for rec in closed.values():
        p=_v2015n((rec.get('actual_close') or {}).get('pnl_pct'))
        if p is not None: closed_pnls.append(p)
        m=_v2015n((rec.get('actual_close') or {}).get('mfe_pct'))
        a=_v2015n((rec.get('actual_close') or {}).get('mae_pct'))
        if m is not None: mfes.append(m)
        if a is not None: maes.append(a)
    for rec in active.values():
        p=_v2015n(rec.get('last_pnl_pct'))
        if p is not None: open_pnls.append(p)
        m=_v2015n(rec.get('observed_peak_pct'))
        a=_v2015n(rec.get('observed_low_pct'))
        if m is not None: mfes.append(m)
        if a is not None: maes.append(a)
    combined=closed_pnls+open_pnls
    wins=sum(1 for x in closed_pnls if x>0)
    bad=sum(1 for x in combined if x<=-2.0)
    unresolved=sum(1 for rec in active.values() if _v2015n(rec.get('last_pnl_pct')) is None)
    return {'closed_n':len(closed_pnls),'open_n':len(open_pnls),'n':len(combined),'closed_win_rate_pct':round(wins/len(closed_pnls)*100,2) if closed_pnls else None,
            'sum_pnl_pct':round(sum(combined),6),'avg_pnl_pct':round(sum(combined)/len(combined),6) if combined else None,
            'mfe_median_pct':_cs_median_v1141(mfes),'mae_median_pct':_cs_median_v1141(maes),'large_loss_count':bad,
            'worst_pnl_pct':round(min(combined),6) if combined else None,'unresolved_path_count':unresolved}


def _v2015_horizon_perf(port: Dict[str,Any]) -> Dict[str,Any]:
    records=list((port.get('active') or {}).values())+list((port.get('closed') or {}).values())
    out={}
    for label,sec in TOP10_SHADOW_HORIZONS_V2015:
        vals=[]
        for rec in records:
            h=(rec.get('horizons') or {}).get(label) if isinstance(rec.get('horizons'),dict) else None
            if isinstance(h,dict):
                p=_v2015n(h.get('pnl_pct'))
                if p is not None: vals.append(p); continue
            close=rec.get('actual_close') if isinstance(rec.get('actual_close'),dict) else {}
            hold=_v2015n(close.get('hold_sec')); p=_v2015n(close.get('pnl_pct'))
            if p is not None and hold is not None and hold<=sec: vals.append(p)
        out[label]={'n':len(vals),'sum_pnl_pct':round(sum(vals),6),'avg_pnl_pct':round(sum(vals)/len(vals),6) if vals else None,'positive_rate_pct':round(sum(1 for x in vals if x>0)/len(vals)*100,2) if vals else None}
    return out


def _v2015_top10_shadow(nowv: float, closed_rows: List[Dict[str,Any]], state: Dict[str,Any]) -> Dict[str,Any]:
    cycles=_v2015_feed_cycles()
    root=state.get('top10_selection_v2015') if isinstance(state.get('top10_selection_v2015'),dict) else {}
    start_ts=float(root.get('forward_start_ts') or nowv)
    if not root:
        first_feed_ts=min((float(x.get('ts') or nowv) for x in cycles),default=nowv)
        start_ts=min(nowv,first_feed_ts)
        root={'forward_start_ts':start_ts,'forward_start_text':now_text(start_ts),'processed_event_ids':{},'portfolios':{},'candidate_outcomes':{}}
    processed=root.get('processed_event_ids') if isinstance(root.get('processed_event_ids'),dict) else {}
    portfolios=root.get('portfolios') if isinstance(root.get('portfolios'),dict) else {}
    outcomes=root.get('candidate_outcomes') if isinstance(root.get('candidate_outcomes'),dict) else {}
    open_pos,open_dec,closed_pos,closed_dec=_v2015_live_maps(closed_rows)
    events=0
    # exact actual outcome cache for every candidate that entered the feed, including skipped candidates
    for cycle in cycles:
        if float(cycle.get('ts') or 0)<start_ts: continue
        for cand in cycle.get('candidates') or []:
            if not isinstance(cand,dict): continue
            ident=_v2015_candidate_identity(cand)
            if ident and ident not in outcomes: outcomes[ident]={'candidate':cand,'cycle_id':cycle.get('cycle_id'),'first_seen_ts':cycle.get('ts')}
    for ident,out in outcomes.items():
        cand=out.get('candidate') if isinstance(out.get('candidate'),dict) else {}
        opened,closed=_v2015_actual_row(cand,open_pos,open_dec,closed_pos,closed_dec)
        if opened is not None:
            p=_cs_row_pnl_v1141(opened)
            if p is not None: out['last_pnl_pct']=round(float(p),6); prev_max=_v2015n(out.get('max_seen_pct')); prev_min=_v2015n(out.get('min_seen_pct')); out['max_seen_pct']=float(p) if prev_max is None else max(prev_max,float(p)); out['min_seen_pct']=float(p) if prev_min is None else min(prev_min,float(p))
        if closed is not None and 'actual_close' not in out:
            p=_cs_row_pnl_v1141(closed); mfe=_cs_num_v1141(closed.get('mfe_pct'),closed.get('max_profit_pct'),closed.get('max_pnl_pct')); mae=_cs_num_v1141(closed.get('mae_pct'),closed.get('min_profit_pct'),closed.get('min_pnl_pct'))
            if p is not None: out['actual_close']={'pnl_pct':round(float(p),6),'mfe_pct':mfe,'mae_pct':mae,'closed_ts':nowv}
    # enroll new cycle events into 16 virtual portfolios
    for cycle in cycles:
        eid=str(cycle.get('event_id') or '')
        if not eid or eid in processed or float(cycle.get('ts') or 0)<start_ts: continue
        candidates=[dict(x) for x in (cycle.get('candidates') or []) if isinstance(x,dict) and _v2015_candidate_identity(x)]
        for selector in TOP10_SHADOW_SELECTORS_V2015:
            ordered=sorted(candidates,key=lambda r:_v2015_selector_key(r,selector))
            for cap in TOP10_SHADOW_CAPS_V2015:
                key=f'{selector}|CYCLE_{cap if cap else "UNLIMITED"}'
                port=portfolios.get(key) if isinstance(portfolios.get(key),dict) else {'selector':selector,'cycle_cap':cap,'max_open':10,'active':{},'closed':{},'chosen_count':0,'skipped_count':0,'cycles_seen':0}
                active=port.get('active') if isinstance(port.get('active'),dict) else {}; closed_book=port.get('closed') if isinstance(port.get('closed'),dict) else {}
                slots=max(0,TOP10_SHADOW_MAX_OPEN_V2015-len(active)); limit=min(slots,(cap if cap>0 else slots)); chosen=0
                active_tickers={str(x.get('ticker') or '') for x in active.values()}
                for cand in ordered:
                    ident=_v2015_candidate_identity(cand); ticker=str(cand.get('ticker') or '')
                    if ident in active or ident in closed_book or ticker in active_tickers: continue
                    if chosen>=limit: port['skipped_count']=int(port.get('skipped_count') or 0)+1; continue
                    rec={'identity':ident,'pos_id':cand.get('pos_id'),'decision_key':cand.get('decision_key'),'ticker':ticker,'cycle_id':cycle.get('cycle_id'),'event_id':eid,
                         'selected_ts':float(cycle.get('ts') or nowv),'selected_text':cycle.get('time'),'candidate':cand,'horizons':{},'observed_peak_pct':None,'observed_low_pct':None,'last_pnl_pct':None,'path_state':'WAIT_EXACT_OPEN'}
                    active[ident]=rec; active_tickers.add(ticker); chosen+=1; port['chosen_count']=int(port.get('chosen_count') or 0)+1
                    if not port.get('first_selected_ts'): port['first_selected_ts']=rec['selected_ts']
                    if len(active)>=10 and not port.get('first_full_ts'): port['first_full_ts']=float(cycle.get('ts') or nowv)
                    _V2010_SHADOW_EVENT_BATCH.setdefault(str(TOP10_SHADOW_LEDGER_V2015),[]).append({'schema':'shadow_top10_selection_event_v2015','event':'VIRTUAL_SELECT','portfolio':key,'selector':selector,'cycle_cap':cap,'identity':ident,'ticker':ticker,'cycle_id':cycle.get('cycle_id'),'candidate':cand,'ts':nowv,'time':now_text(nowv),'actual_selector_changed':False,'actual_open_changed':False,'auto_buy':False}); events+=1
                port['active']=active; port['closed']=closed_book; port['cycles_seen']=int(port.get('cycles_seen') or 0)+1; portfolios[key]=port
        processed[eid]=float(cycle.get('ts') or nowv)
    # update all virtual positions against exact actual path and finalize exact close
    for key,port in portfolios.items():
        active=port.get('active') if isinstance(port.get('active'),dict) else {}; closed_book=port.get('closed') if isinstance(port.get('closed'),dict) else {}
        for ident,rec in list(active.items()):
            cand=rec.get('candidate') if isinstance(rec.get('candidate'),dict) else {}
            opened,closed=_v2015_actual_row(cand,open_pos,open_dec,closed_pos,closed_dec)
            live=opened or closed
            if live is not None:
                pnl=_cs_row_pnl_v1141(live)
                if pnl is not None:
                    rec['last_pnl_pct']=round(float(pnl),6); prev_peak=_v2015n(rec.get('observed_peak_pct')); prev_low=_v2015n(rec.get('observed_low_pct')); rec['observed_peak_pct']=float(pnl) if prev_peak is None else max(prev_peak,float(pnl)); rec['observed_low_pct']=float(pnl) if prev_low is None else min(prev_low,float(pnl)); rec['path_state']='EXACT_OPEN' if opened is not None else 'EXACT_CLOSED'
            elapsed=max(0.0,nowv-float(rec.get('selected_ts') or nowv)); horizons=rec.get('horizons') if isinstance(rec.get('horizons'),dict) else {}; rec['horizons']=horizons
            for label,sec in TOP10_SHADOW_HORIZONS_V2015:
                if label in horizons or elapsed<sec: continue
                horizons[label]={'completed_ts':nowv,'pnl_pct':rec.get('last_pnl_pct'),'peak_pct':rec.get('observed_peak_pct'),'low_pct':rec.get('observed_low_pct'),'closed_before_horizon':bool(closed is not None)}
                _V2010_SHADOW_EVENT_BATCH.setdefault(str(TOP10_SHADOW_LEDGER_V2015),[]).append({'schema':'shadow_top10_selection_event_v2015','event':'HORIZON','portfolio':key,'identity':ident,'ticker':rec.get('ticker'),'horizon':label,'snapshot':horizons[label],'ts':nowv,'time':now_text(nowv),'auto_buy':False}); events+=1
            if closed is not None:
                p=_cs_row_pnl_v1141(closed)
                if p is None: continue
                mfe=_cs_num_v1141(closed.get('mfe_pct'),closed.get('max_profit_pct'),closed.get('max_pnl_pct')); mae=_cs_num_v1141(closed.get('mae_pct'),closed.get('min_profit_pct'),closed.get('min_pnl_pct'))
                hold=_cs_num_v1141(closed.get('hold_sec'),closed.get('holding_sec'),closed.get('duration_sec')); rec['actual_close']={'pnl_pct':round(float(p),6),'mfe_pct':mfe,'mae_pct':mae,'closed_ts':nowv,'hold_sec':hold,'match':'EXACT_POS_ID' if cand.get('pos_id') and str(cand.get('pos_id')) in closed_pos else 'EXACT_DECISION_KEY'}
                rec['finalized_ts']=nowv; closed_book[ident]=rec; active.pop(ident,None)
                _V2010_SHADOW_EVENT_BATCH.setdefault(str(TOP10_SHADOW_LEDGER_V2015),[]).append({'schema':'shadow_top10_selection_event_v2015','event':'ACTUAL_CLOSE','portfolio':key,'identity':ident,'ticker':rec.get('ticker'),'actual_close':rec['actual_close'],'ts':nowv,'time':now_text(nowv),'auto_buy':False}); events+=1
        if len(closed_book)>500:
            closed_book=dict(sorted(closed_book.items(),key=lambda kv:float(kv[1].get('finalized_ts') or 0),reverse=True)[:500])
        port['active']=active; port['closed']=closed_book
        perf=_v2015_portfolio_perf(port); port['performance']=perf
        if port.get('first_selected_ts') and port.get('first_full_ts'): port['hours_to_fill_10']=round((float(port['first_full_ts'])-float(port['first_selected_ts']))/3600.0,3)
    # missed winners: exact feed candidates not chosen by portfolio, actual close >=3% or exact MFE >=5%
    rows=[]
    for key,port in portfolios.items():
        chosen=set(port.get('active',{}))|set(port.get('closed',{})); missed_big=0; bad_picks=0
        for ident,out in outcomes.items():
            close=out.get('actual_close') if isinstance(out.get('actual_close'),dict) else {}
            pnl=_v2015n(close.get('pnl_pct')); mfe=_v2015n(close.get('mfe_pct'))
            if ident not in chosen and ((pnl is not None and pnl>=3.0) or (mfe is not None and mfe>=5.0)): missed_big+=1
        for rec in list((port.get('active') or {}).values())+list((port.get('closed') or {}).values()):
            p=_v2015n((rec.get('actual_close') or {}).get('pnl_pct'),_v2015n(rec.get('last_pnl_pct')))
            if p is not None and p<=-2.0: bad_picks+=1
        perf=dict(port.get('performance') or {}); perf['missed_big_winner_count']=missed_big; perf['bad_pick_count']=bad_picks
        rows.append({'portfolio':key,'selector':port.get('selector'),'cycle_cap':port.get('cycle_cap'),'cycles_seen':port.get('cycles_seen'),'chosen_count':port.get('chosen_count'),'hours_to_fill_10':port.get('hours_to_fill_10'),'horizons':_v2015_horizon_perf(port),**perf})
    eligible=[r for r in rows if int(r.get('n') or 0)>=3]
    leader=max(eligible,key=lambda r:(float(r.get('avg_pnl_pct') if r.get('avg_pnl_pct') is not None else -1e99),float(r.get('sum_pnl_pct') or -1e99)),default=None)
    root.update({'schema':'shadow_top10_selection_state_v2015','updated_ts':nowv,'processed_event_ids':processed,'portfolios':portfolios,'candidate_outcomes':outcomes,'forward_start_ts':start_ts,'forward_start_text':root.get('forward_start_text') or now_text(start_ts)})
    # bounded current state only; append ledger stays untouched
    if len(processed)>12000: root['processed_event_ids']=dict(sorted(processed.items(),key=lambda kv:float(kv[1] or 0),reverse=True)[:8000])
    if len(outcomes)>20000: root['candidate_outcomes']=dict(sorted(outcomes.items(),key=lambda kv:float(kv[1].get('first_seen_ts') or 0),reverse=True)[:12000])
    state['top10_selection_v2015']=root
    return {'state':'ACTIVE' if cycles else 'COLLECTING','forward_start_ts':start_ts,'forward_start_text':root.get('forward_start_text'),'feed_cycles_total':len(cycles),'processed_cycles':len(processed),'candidate_events':len(outcomes),'portfolio_count':len(rows),'max_virtual_open':10,
            'selectors':list(TOP10_SHADOW_SELECTORS_V2015),'cycle_caps':[1,2,3,'UNLIMITED'],'leader_min_n3':leader,'portfolios':rows,'events_this_cycle':events,
            'policy':'Paper exact final-passed pre-OPEN cycle pool -> forward-only 10-slot virtual portfolios. Compare selector ordering and cycle intake 1/2/3/unlimited using exact actual OPEN/CLOSED path. No proxy, no retroactive replay, actual limits/selector unchanged.',
            'locks':{'retroactive_recalc':False,'proxy':False,'actual_selector_changed':False,'actual_open_limit_changed':False,'actual_cycle_limit_changed':False,'actual_open_changed':False,'actual_exit_changed':False,'auto_buy':False}}


def _v2010_unified_shadow_cycle_update(nowv: float, candidate_rows: List[Dict[str,Any]], closed_rows: List[Dict[str,Any]], fmap: Dict[str,Dict[str,Any]], ofmap: Dict[str,Dict[str,Any]], summary: Dict[str,Any], good_s2: Dict[str,Any], quality_shadow: Dict[str,Any]) -> Dict[str,Any]:  # type: ignore[override]
    board=_V2015_PREV_UNIFIED_SHADOW_UPDATE(nowv,candidate_rows,closed_rows,fmap,ofmap,summary,good_s2,quality_shadow)
    state=_v2010_shadow_state()
    top10=_v2015_top10_shadow(nowv,closed_rows,state)
    board=dict(board) if isinstance(board,dict) else {}
    board['schema']='unified_shadow_status_v2015'; board['version']='review_worker_v2.015'; board['build']='v2015_top10_selector_cycle_shadow_2026-07-15'; board['top10_selection']=top10
    _v2010_checkpoint_shadow_state(state,force=False)
    runtime=board.get('writer_runtime_v2010') if isinstance(board.get('writer_runtime_v2010'),dict) else {}
    runtime['top10_selection_v2015']={'events_this_cycle':top10.get('events_this_cycle',0),'feed_cycles_total':top10.get('feed_cycles_total',0),'portfolio_count':top10.get('portfolio_count',0)}
    runtime['event_batch_flush_v2015']=_v2010_flush_shadow_event_batches(); board['writer_runtime_v2010']=runtime
    save_json(UNIFIED_SHADOW_STATUS_V2010,board)
    return board


def _v2015_review_issue_once() -> None:
    marker=BASE_DIR/'runtime'/'v2015_top10_selector_cycle_shadow.seeded'
    if marker.exists(): return
    ts=now_ts(); text=now_text(ts)
    try:
        _v2010_append_jsonl(BASE_DIR/'runtime'/'change_verify_ledger.jsonl',{'schema':'change_verify_ledger_v870','change_id':'v2015-top10-selector-cycle-shadow-001','issue_id':'TOP10-SELECTION-SHADOW-2015','version':'v2015','verify_result':'CHECK','created_ts':ts,'created_at':text,'created_text':text,'writer':'review_v2015_lifecycle_writer','symptom':'The planned real book is 10 positions, but current unlimited Paper flow does not prove which 10 final-passed candidates and what per-cycle intake produce the best exact outcome.','cause':'Historical TOP/rank experiments cannot replace a same-cycle forward comparison on the current final-passed Paper candidate pool.','files_changed':['paper_bot_v2.015.py','review_worker_v2.015.py','coinbot_main_v2_13_2015.py'],'new_mainline':'Run 16 forward virtual portfolios: current rank, trigger+reaction, money-flow+sustain and balanced ordering x cycle 1/2/3/unlimited, each max 10 OPEN. Follow exact actual OPEN/CLOSED path and 3h/6h/12h/24h horizons.','not_touched':['actual candidate/S1 flow','actual Paper selector','actual OPEN limit','actual per-cycle entry limit','trigger/invalid/target','actual exit','existing shadows/history','protected ledgers','auto-buy OFF'],'remaining':'2-3 day priority: compare 3h/6h/12h and exact CLOSED. Promotion still requires Paper exact positive expectation, recent/full no worse, ledger/decision integrity and user final approval.','auto_buy':False})
        _v2010_append_jsonl(BASE_DIR/'ledger'/'issue_ledger_events.jsonl',{'schema':'coinbot_single_work_ledger_v870','event_type':'ISSUE','issue_id':'TOP10-SELECTION-SHADOW-2015','status':'CHECK','title':'실전 10자리 TOP10·cycle 1/2/3 shadow','detail':'Paper OPEN 직전 정확 후보판을 16개 가상 포트폴리오로 forward 비교. 기존 shadow 기록 보존.','version':'v2015','created_ts':ts,'created_at':text,'created_text':text,'auto_buy':False})
        marker.parent.mkdir(parents=True,exist_ok=True); marker.write_text(text,encoding='utf-8')
    except Exception: pass

try: _v2015_review_issue_once()
except Exception: pass

VERSION='review_worker_v2.015'
BUILD_LABEL='v2015_top10_selector_cycle_shadow_2026-07-15'
MAIN_DEPLOY_VERSION=BUILD_LABEL


# =============================================================================
# Review v2.016 / release v2016
# 1) Repair v2014 entry-survival metrics from exact OPEN-time sealed evidence only.
# 2) Primary TOP10 shadow is one global all-alt relative selector, not strategy lanes.
#    Four virtual books compare cycle intake 1/2/3/unlimited, max OPEN 10.
# Existing v2010-v2015 shadow state/append ledgers remain preserved.
# =============================================================================
TOP10_GLOBAL_LEDGER_V2016 = BASE_DIR / 'shadow_top10_global_relative_events_v2016.jsonl'
TOP10_GLOBAL_START_V2016 = BASE_DIR / 'paper_top10_global_relative_start_v2016.json'
TOP10_GLOBAL_FEED_STATUS_V2016 = BASE_DIR / 'paper_top10_global_relative_candidate_status_v2016.json'
TOP10_GLOBAL_CAPS_V2016 = (1,2,3,0)
TOP10_GLOBAL_MAX_OPEN_V2016 = 10
TOP10_GLOBAL_HORIZONS_V2016 = (('3h',10800.0),('6h',21600.0),('12h',43200.0),('24h',86400.0))
_V2016_PREV_ENTRY_SURVIVAL_SHADOW = _v2014_entry_survival_shadow
_V2016_PREV_UNIFIED_SHADOW_UPDATE = _v2010_unified_shadow_cycle_update


def _v2016_entry_metric_sources(row: Dict[str,Any]) -> List[Dict[str,Any]]:
    """OPEN-time sealed evidence only. Never consult current feature/orderflow maps."""
    if not isinstance(row,dict): return []
    keys=('profitability_entry_evidence_v1034','profitability_preopen_evidence_v1034','quality','entry_evidence_v983','canonical_entry_snapshot','quality_observation_v925','swing_quality_gate','swing_entry_gate_v977','metrics','raw')
    queue=[row]; out=[]; seen=set()
    while queue and len(out)<28:
        obj=queue.pop(0)
        if not isinstance(obj,dict) or id(obj) in seen: continue
        seen.add(id(obj)); out.append(obj)
        for key in keys:
            value=obj.get(key)
            if isinstance(value,dict): queue.append(value)
    return out


def _v2016_entry_num(row: Dict[str,Any], *keys: str) -> Optional[float]:
    for source in _v2016_entry_metric_sources(row):
        for key in keys:
            value=_cs_num_v1141(source.get(key))
            if value is not None: return float(value)
    return None


def _v2024_entry_relative_rank(row: Dict[str,Any]) -> Optional[float]:
    for source in _v2016_entry_metric_sources(row):
        value=_cs_num_v1141(source.get('relative_strength_rank_pct_v1095'),source.get('relative_strength_rank_pct'))
        if value is not None:
            return float(value)
        axes=source.get('axes') if isinstance(source.get('axes'),dict) else {}
        rel=axes.get('relative_strength') if isinstance(axes.get('relative_strength'),dict) else {}
        src=str(rel.get('source') or '')
        axis_value=_cs_num_v1141(rel.get('value'))
        if axis_value is not None and 'rank_pct' in src:
            return float(axis_value)
    return None


def _v2014_entry_metrics(row: Dict[str,Any]) -> Dict[str,Optional[float]]:  # type: ignore[override]
    """v2024 exact owner repair: nested sealed entry evidence plus Feature-owned relative rank."""
    return {
        'reaction':_v2016_entry_num(row,'price_reaction_pct','entry_price_reaction_pct','reaction_pct'),
        'relative_strength_rank':_v2024_entry_relative_rank(row),
        'relative_strength':_v2016_entry_num(row,'relative_strength_pct','relative_strength','relative_strength_score'),
        'money_flow':_v2016_entry_num(row,'money_flow_score','money_flow','money_expand_score','turnover_change_pct'),
        'buy_sustain':_v2016_entry_num(row,'buy_sustain_1m','buy_sustain_60s','micro_buy_ratio_sustain_1m','buy_ratio_1m'),
    }


def _v2016_repair_survival_state(nowv: float, closed_rows: List[Dict[str,Any]], state: Dict[str,Any]) -> Dict[str,Any]:
    active=state.get('entry_survival_active_v2014') if isinstance(state.get('entry_survival_active_v2014'),dict) else {}
    finalized=state.get('entry_survival_finalized_v2014') if isinstance(state.get('entry_survival_finalized_v2014'),dict) else {}
    open_pos={}; open_dec={}; closed_pos={}; closed_dec={}
    for row in _v923_open_rows():
        pos=_v2010_exact_pos_key(row); dec=_v2010_exact_event_key(row)
        if pos: open_pos[pos]=row
        if dec: open_dec[dec]=row
    for row in closed_rows:
        pos=_v2010_exact_pos_key(row); dec=_v2010_exact_event_key(row)
        if pos: closed_pos[pos]=row
        if dec: closed_dec[dec]=row
    records=list(active.values())+list(finalized.values())
    repaired=0; filled=Counter(); exact_missing=0; safe_reclassified=0; events=0
    for rec in records:
        if not isinstance(rec,dict): continue
        metrics=rec.get('entry_metrics') if isinstance(rec.get('entry_metrics'),dict) else {}
        missing=[k for k in ('reaction','relative_strength_rank','relative_strength','money_flow','buy_sustain') if metrics.get(k) is None]
        if not missing: continue
        pos=str(rec.get('pos_id') or ''); dec=str(rec.get('decision_key') or '')
        row=(open_pos.get(pos) if pos else None) or (open_dec.get(dec) if dec else None) or (closed_pos.get(pos) if pos else None) or (closed_dec.get(dec) if dec else None)
        if not isinstance(row,dict): exact_missing+=1; continue
        exact=_v2014_entry_metrics(row); changed=[]
        merged=dict(metrics)
        for key in missing:
            if exact.get(key) is not None:
                merged[key]=exact[key]; filled[key]+=1; changed.append(key)
        if not changed: exact_missing+=1; continue
        rec['entry_metrics']=merged; rec['entry_metric_repair_v2016']={'ts':nowv,'time':now_text(nowv),'fields':changed,'source':'exact OPEN/CLOSED sealed entry evidence','live_market_fallback':False}
        repaired+=1
        _V2010_SHADOW_EVENT_BATCH.setdefault(str(ENTRY_SURVIVAL_LEDGER_V2014),[]).append({'schema':'shadow_entry_survival_event_v2016','event':'ENTRY_METRIC_REPAIR','identity':rec.get('identity'),'pos_id':rec.get('pos_id'),'decision_key':rec.get('decision_key'),'ticker':rec.get('ticker'),'fields':changed,'entry_metrics':merged,'ts':nowv,'time':now_text(nowv),'source':'exact sealed entry evidence only','retroactive_market_recalc':False,'actual_entry_changed':False,'actual_exit_changed':False,'auto_buy':False}); events+=1
        # A historical SOURCE_MISSING horizon can be safely reclassified only when its stored peak proves NO_PROGRESS.
        # We do not reconstruct old weak/recovery votes from today's market values.
        known_axes=sum((1 if merged.get('reaction') is not None else 0,1 if merged.get('relative_strength_rank') is not None or merged.get('relative_strength') is not None else 0,1 if merged.get('money_flow') is not None else 0,1 if merged.get('buy_sustain') is not None else 0))
        if known_axes>=3:
            horizons=rec.get('horizons') if isinstance(rec.get('horizons'),dict) else {}
            for label,h in horizons.items():
                if not isinstance(h,dict) or str(h.get('classification') or '')!='SOURCE_MISSING': continue
                peak=_cs_num_v1141(h.get('observed_peak_pct'),h.get('peak_pct'))
                if peak is None or float(peak)>0: continue
                h['classification']='NO_PROGRESS'; h['safe_reclassified_v2016']=True; h['safe_reclass_reason_v2016']='stored horizon peak <= 0 after exact sealed entry-metric repair'
                safe_reclassified+=1
                _V2010_SHADOW_EVENT_BATCH.setdefault(str(ENTRY_SURVIVAL_LEDGER_V2014),[]).append({'schema':'shadow_entry_survival_event_v2016','event':'HORIZON_SAFE_RECLASS','identity':rec.get('identity'),'pos_id':rec.get('pos_id'),'decision_key':rec.get('decision_key'),'ticker':rec.get('ticker'),'horizon':label,'classification':'NO_PROGRESS','stored_peak_pct':peak,'ts':nowv,'time':now_text(nowv),'current_market_replay':False,'auto_buy':False}); events+=1
    return {'records_checked':len(records),'records_repaired':repaired,'fields_filled':dict(filled),'exact_source_still_missing':exact_missing,'safe_source_missing_to_no_progress':safe_reclassified,'events_appended':events,'policy':'fill only missing entry metrics from exact sealed OPEN/CLOSED evidence; historical horizon weakness is never reconstructed from current market values'}


def _v2014_entry_survival_shadow(nowv: float, closed_rows: List[Dict[str,Any]], fmap: Dict[str,Dict[str,Any]], ofmap: Dict[str,Dict[str,Any]], state: Dict[str,Any]) -> Dict[str,Any]:  # type: ignore[override]
    repair=_v2016_repair_survival_state(nowv,closed_rows,state)
    out=_V2016_PREV_ENTRY_SURVIVAL_SHADOW(nowv,closed_rows,fmap,ofmap,state)
    out=dict(out) if isinstance(out,dict) else {}
    out['entry_metric_repair_v2016']=repair
    out['entry_metric_reader_v2016']='profitability_entry_evidence_v1034.quality + sealed entry evidence; no current fmap/ofmap fallback'
    return out


def _v2016_pct(values: List[float], value: Optional[float], high_better: bool=True) -> Optional[float]:
    if value is None or not values: return None
    vals=[float(x) for x in values if x is not None and math.isfinite(float(x))]
    if not vals: return None
    v=float(value); less=sum(1 for x in vals if x<v); equal=sum(1 for x in vals if x==v)
    pct=(less+0.5*equal)/len(vals)*100.0
    return round(pct if high_better else 100.0-pct,6)


def _v2016_candidate_axes(row: Dict[str,Any]) -> Dict[str,Optional[float]]:
    invalid=_v2015n(row.get('invalid_distance')); room=_v2015n(row.get('target_room'))
    efficiency=(room/invalid) if room is not None and invalid is not None and invalid>0 else None
    return {
        'actual_rr':_v2015n(row.get('actual_rr')),'target_room':room,'risk_efficiency':efficiency,
        'reaction':_v2015n(row.get('reaction')),'occurrence_age':_v2015n(row.get('occurrence_age')),'trigger_chase':_v2015n(row.get('trigger_chase')),
        'relative_strength':_v2015n(row.get('relative_strength')),'money_flow':_v2015n(row.get('money_flow')),'buy_sustain':_v2015n(row.get('buy_sustain')),'buy_ratio':_v2015n(row.get('buy_ratio')),
        'spread':_v2015n(row.get('spread')),'slippage':_v2015n(row.get('slippage')),
    }


def _v2016_score_cycle(candidates: List[Dict[str,Any]]) -> List[Dict[str,Any]]:
    rows=[]
    for cand in candidates:
        row=dict(cand); row['_axes_v2016']=_v2016_candidate_axes(row); rows.append(row)
    axis_direction={'actual_rr':True,'target_room':True,'risk_efficiency':True,'reaction':True,'occurrence_age':False,'trigger_chase':False,'relative_strength':True,'money_flow':True,'buy_sustain':True,'buy_ratio':True,'spread':False,'slippage':False}
    pools={k:[r['_axes_v2016'][k] for r in rows if r['_axes_v2016'].get(k) is not None] for k in axis_direction}
    groups={'structure':('actual_rr','target_room','risk_efficiency'),'trigger':('reaction','occurrence_age','trigger_chase'),'strength':('relative_strength','money_flow','buy_sustain','buy_ratio'),'execution':('spread','slippage')}
    out=[]
    for row in rows:
        axis_pct={}
        for key,high in axis_direction.items(): axis_pct[key]=_v2016_pct(pools[key],row['_axes_v2016'].get(key),high)
        group_scores={}
        for group,keys in groups.items():
            vals=[axis_pct[k] for k in keys if axis_pct.get(k) is not None]
            group_scores[group]=round(sum(vals)/len(vals),6) if vals else None
        known_axes=sum(1 for v in axis_pct.values() if v is not None); known_groups=sum(1 for v in group_scores.values() if v is not None)
        valid=known_axes>=6 and known_groups>=3
        vals=[v for v in group_scores.values() if v is not None]
        score=round(sum(vals)/len(vals),6) if valid and vals else None
        row['relative_selection_v2016']={'score':score,'rankable':valid,'known_axes':known_axes,'known_groups':known_groups,'group_scores':group_scores,'axis_percentiles':axis_pct,'source_lane':row.get('source_lane'),'source_lane_used_in_score':False,'strategy_name_used_in_score':False,'current_rank_used_as_score':False,'policy':'same actual cycle pool percentile comparison; equal group average across structure/trigger/strength/execution; missing is not zero'}
        row.pop('_axes_v2016',None); out.append(row)
    return sorted(out,key=lambda r:(r['relative_selection_v2016'].get('score') is None,-float(r['relative_selection_v2016'].get('score') or -1e99),-int(r['relative_selection_v2016'].get('known_axes') or 0),-float(_v2015n(r.get('rank_score'),-1e99) or -1e99),str(r.get('ticker') or '')))


def _v2016_group_feed_cycles(start_ts: float) -> List[Dict[str,Any]]:
    rows=read_jsonl(TOP10_SHADOW_FEED_V2015,max_lines=TOP10_SHADOW_FEED_TAIL_V2015)
    grouped={}
    for row in rows:
        if not isinstance(row,dict) or row.get('event')!='PREOPEN_ELIGIBLE_CYCLE': continue
        ts=float(row.get('ts') or 0)
        if ts<start_ts: continue
        cycle_id=str(row.get('cycle_id') or '').strip()
        if not cycle_id: continue
        g=grouped.setdefault(cycle_id,{'cycle_id':cycle_id,'first_ts':ts,'last_ts':ts,'event_ids':set(),'candidates':{}})
        g['first_ts']=min(float(g['first_ts']),ts); g['last_ts']=max(float(g['last_ts']),ts)
        eid=str(row.get('event_id') or '').strip()
        if eid: g['event_ids'].add(eid)
        for cand in row.get('candidates') or []:
            if not isinstance(cand,dict): continue
            ident=_v2015_candidate_identity(cand)
            if ident: g['candidates'][ident]=dict(cand)
    out=[]
    for g in grouped.values():
        out.append({'cycle_id':g['cycle_id'],'first_ts':g['first_ts'],'last_ts':g['last_ts'],'event_ids':sorted(g['event_ids']),'raw_event_count':len(g['event_ids']),'candidates':list(g['candidates'].values())})
    return sorted(out,key=lambda x:(float(x.get('first_ts') or 0),str(x.get('cycle_id') or '')))


def _v2016_global_top10_shadow(nowv: float, closed_rows: List[Dict[str,Any]], state: Dict[str,Any]) -> Dict[str,Any]:
    root=state.get('top10_global_relative_v2016') if isinstance(state.get('top10_global_relative_v2016'),dict) else {}
    if not root:
        start_meta=load_json(TOP10_GLOBAL_START_V2016,{}) or {}
        start_ts=_cs_num_v1141(start_meta.get('started_ts')) or float(nowv)
        root={'forward_start_ts':float(start_ts),'forward_start_text':now_text(float(start_ts)),'processed_cycle_candidates':{},'portfolios':{},'candidate_outcomes':{}}
    start_ts=float(root.get('forward_start_ts') or nowv)
    cycles=_v2016_group_feed_cycles(start_ts)
    processed=root.get('processed_cycle_candidates') if isinstance(root.get('processed_cycle_candidates'),dict) else {}
    portfolios=root.get('portfolios') if isinstance(root.get('portfolios'),dict) else {}
    outcomes=root.get('candidate_outcomes') if isinstance(root.get('candidate_outcomes'),dict) else {}
    open_pos,open_dec,closed_pos,closed_dec=_v2015_live_maps(closed_rows)
    events=0; new_candidate_events=0; unrankable_seen=0
    for cycle in cycles:
        for cand in cycle.get('candidates') or []:
            ident=_v2015_candidate_identity(cand)
            if ident and ident not in outcomes:
                outcomes[ident]={'candidate':dict(cand),'cycle_id':cycle.get('cycle_id'),'first_seen_ts':cycle.get('first_ts')}; new_candidate_events+=1
    for ident,outcome in outcomes.items():
        cand=outcome.get('candidate') if isinstance(outcome.get('candidate'),dict) else {}
        opened,closed=_v2015_actual_row(cand,open_pos,open_dec,closed_pos,closed_dec)
        live=opened or closed
        if live is not None:
            p=_cs_row_pnl_v1141(live)
            if p is not None:
                outcome['last_pnl_pct']=round(float(p),6); mx=_v2015n(outcome.get('max_seen_pct')); mn=_v2015n(outcome.get('min_seen_pct')); outcome['max_seen_pct']=float(p) if mx is None else max(mx,float(p)); outcome['min_seen_pct']=float(p) if mn is None else min(mn,float(p))
            opened_at=_cs_opened_ts_v1142(live)
            if opened_at is not None: outcome['exact_opened_at']=float(opened_at)
        if closed is not None and 'actual_close' not in outcome:
            p=_cs_row_pnl_v1141(closed); mfe=_cs_num_v1141(closed.get('mfe_pct'),closed.get('max_profit_pct'),closed.get('max_pnl_pct')); mae=_cs_num_v1141(closed.get('mae_pct'),closed.get('min_profit_pct'),closed.get('min_pnl_pct')); hold=_cs_num_v1141(closed.get('hold_sec'),closed.get('holding_sec'),closed.get('duration_sec'))
            if p is not None: outcome['actual_close']={'pnl_pct':round(float(p),6),'mfe_pct':mfe,'mae_pct':mae,'hold_sec':hold,'closed_ts':nowv}
    for cycle in cycles:
        cid=str(cycle.get('cycle_id') or '')
        done=set(str(x) for x in (processed.get(cid) or []))
        full=[dict(x) for x in (cycle.get('candidates') or []) if isinstance(x,dict) and _v2015_candidate_identity(x)]
        ranked=_v2016_score_cycle(full)
        new_ranked=[x for x in ranked if _v2015_candidate_identity(x) not in done]
        rankable_new=[x for x in new_ranked if (x.get('relative_selection_v2016') or {}).get('score') is not None]
        unrankable_new=[x for x in new_ranked if (x.get('relative_selection_v2016') or {}).get('score') is None]
        unrankable_seen+=len(unrankable_new)
        if not rankable_new and not unrankable_new: continue
        for cap in TOP10_GLOBAL_CAPS_V2016:
            key=f'GLOBAL_RELATIVE|CYCLE_{cap if cap else "UNLIMITED"}'
            port=portfolios.get(key) if isinstance(portfolios.get(key),dict) else {'selector':'GLOBAL_RELATIVE','cycle_cap':cap,'max_open':10,'active':{},'closed':{},'chosen_count':0,'skipped_count':0,'cycles_seen':0,'cycle_selected_counts':{}}
            active=port.get('active') if isinstance(port.get('active'),dict) else {}; closed_book=port.get('closed') if isinstance(port.get('closed'),dict) else {}; counts=port.get('cycle_selected_counts') if isinstance(port.get('cycle_selected_counts'),dict) else {}
            already=int(counts.get(cid) or 0); slots=max(0,TOP10_GLOBAL_MAX_OPEN_V2016-len(active)); cycle_left=slots if cap<=0 else max(0,cap-already); limit=min(slots,cycle_left); chosen=0
            active_tickers={str(x.get('ticker') or '') for x in active.values()}
            for cand in rankable_new:
                ident=_v2015_candidate_identity(cand); ticker=str(cand.get('ticker') or ''); score=(cand.get('relative_selection_v2016') or {}).get('score')
                if score is None: continue
                if ident in active or ident in closed_book or ticker in active_tickers: continue
                if chosen>=limit: port['skipped_count']=int(port.get('skipped_count') or 0)+1; continue
                rec={'identity':ident,'pos_id':cand.get('pos_id'),'decision_key':cand.get('decision_key'),'ticker':ticker,'cycle_id':cid,'selected_ts':float(cycle.get('last_ts') or nowv),'selected_text':now_text(float(cycle.get('last_ts') or nowv)),'candidate':cand,'relative_selection_v2016':cand.get('relative_selection_v2016'),'horizons':{},'observed_peak_pct':None,'observed_low_pct':None,'last_pnl_pct':None,'path_state':'WAIT_EXACT_OPEN'}
                active[ident]=rec; active_tickers.add(ticker); chosen+=1; port['chosen_count']=int(port.get('chosen_count') or 0)+1
                if not port.get('first_selected_ts'): port['first_selected_ts']=rec['selected_ts']
                _V2010_SHADOW_EVENT_BATCH.setdefault(str(TOP10_GLOBAL_LEDGER_V2016),[]).append({'schema':'shadow_top10_global_relative_event_v2016','event':'VIRTUAL_SELECT','portfolio':key,'cycle_cap':cap,'identity':ident,'ticker':ticker,'cycle_id':cid,'relative_selection_v2016':cand.get('relative_selection_v2016'),'candidate':cand,'ts':nowv,'time':now_text(nowv),'source_lane_used_in_score':False,'strategy_name_used_in_score':False,'actual_selector_changed':False,'actual_open_changed':False,'auto_buy':False}); events+=1
            counts[cid]=already+chosen; port['cycle_selected_counts']=counts; port['active']=active; port['closed']=closed_book; port['cycles_seen']=len(set(list(counts.keys()))); portfolios[key]=port
        processed[cid]=sorted(done|{_v2015_candidate_identity(x) for x in rankable_new if _v2015_candidate_identity(x)})
    for key,port in portfolios.items():
        active=port.get('active') if isinstance(port.get('active'),dict) else {}; closed_book=port.get('closed') if isinstance(port.get('closed'),dict) else {}
        for ident,rec in list(active.items()):
            cand=rec.get('candidate') if isinstance(rec.get('candidate'),dict) else {}; opened,closed=_v2015_actual_row(cand,open_pos,open_dec,closed_pos,closed_dec); live=opened or closed
            if live is not None:
                pnl=_cs_row_pnl_v1141(live)
                if pnl is not None:
                    rec['last_pnl_pct']=round(float(pnl),6); mx=_v2015n(rec.get('observed_peak_pct')); mn=_v2015n(rec.get('observed_low_pct')); rec['observed_peak_pct']=float(pnl) if mx is None else max(mx,float(pnl)); rec['observed_low_pct']=float(pnl) if mn is None else min(mn,float(pnl)); rec['path_state']='EXACT_OPEN' if opened is not None else 'EXACT_CLOSED'
                exact_opened=_cs_opened_ts_v1142(live)
                if exact_opened is not None: rec['exact_opened_at']=float(exact_opened)
            basis_ts=float(rec.get('exact_opened_at') or rec.get('selected_ts') or nowv); elapsed=max(0.0,nowv-basis_ts); horizons=rec.get('horizons') if isinstance(rec.get('horizons'),dict) else {}; rec['horizons']=horizons
            for label,sec in TOP10_GLOBAL_HORIZONS_V2016:
                if label in horizons or elapsed<sec: continue
                horizons[label]={'completed_ts':nowv,'pnl_pct':rec.get('last_pnl_pct'),'peak_pct':rec.get('observed_peak_pct'),'low_pct':rec.get('observed_low_pct'),'closed_before_horizon':bool(closed is not None),'time_basis':'EXACT_OPENED_AT' if rec.get('exact_opened_at') else 'PREOPEN_SELECTED_TS'}
                _V2010_SHADOW_EVENT_BATCH.setdefault(str(TOP10_GLOBAL_LEDGER_V2016),[]).append({'schema':'shadow_top10_global_relative_event_v2016','event':'HORIZON','portfolio':key,'identity':ident,'ticker':rec.get('ticker'),'horizon':label,'snapshot':horizons[label],'ts':nowv,'time':now_text(nowv),'auto_buy':False}); events+=1
            if closed is not None:
                p=_cs_row_pnl_v1141(closed)
                if p is None: continue
                mfe=_cs_num_v1141(closed.get('mfe_pct'),closed.get('max_profit_pct'),closed.get('max_pnl_pct')); mae=_cs_num_v1141(closed.get('mae_pct'),closed.get('min_profit_pct'),closed.get('min_pnl_pct')); hold=_cs_num_v1141(closed.get('hold_sec'),closed.get('holding_sec'),closed.get('duration_sec'))
                rec['actual_close']={'pnl_pct':round(float(p),6),'mfe_pct':mfe,'mae_pct':mae,'hold_sec':hold,'closed_ts':nowv,'match':'EXACT_POS_ID' if cand.get('pos_id') and str(cand.get('pos_id')) in closed_pos else 'EXACT_DECISION_KEY'}; rec['finalized_ts']=nowv; closed_book[ident]=rec; active.pop(ident,None)
                _V2010_SHADOW_EVENT_BATCH.setdefault(str(TOP10_GLOBAL_LEDGER_V2016),[]).append({'schema':'shadow_top10_global_relative_event_v2016','event':'ACTUAL_CLOSE','portfolio':key,'identity':ident,'ticker':rec.get('ticker'),'actual_close':rec['actual_close'],'ts':nowv,'time':now_text(nowv),'auto_buy':False}); events+=1
        if len(closed_book)>500: closed_book=dict(sorted(closed_book.items(),key=lambda kv:float(kv[1].get('finalized_ts') or 0),reverse=True)[:500])
        if len(port.get('cycle_selected_counts') or {})>12000: port['cycle_selected_counts']=dict(list((port.get('cycle_selected_counts') or {}).items())[-8000:])
        port['active']=active; port['closed']=closed_book; port['performance']=_v2015_portfolio_perf(port)
        if port.get('first_selected_ts') and len(active)>=10 and not port.get('first_full_ts'): port['first_full_ts']=nowv
        if port.get('first_selected_ts') and port.get('first_full_ts'): port['hours_to_fill_10']=round((float(port['first_full_ts'])-float(port['first_selected_ts']))/3600.0,3)
    rows=[]
    for key,port in portfolios.items():
        chosen=set(port.get('active',{}))|set(port.get('closed',{})); missed_big=0; bad=0
        for ident,outcome in outcomes.items():
            close=outcome.get('actual_close') if isinstance(outcome.get('actual_close'),dict) else {}; pnl=_v2015n(close.get('pnl_pct')); mfe=_v2015n(close.get('mfe_pct'))
            if ident not in chosen and ((pnl is not None and pnl>=3.0) or (mfe is not None and mfe>=5.0)): missed_big+=1
        for rec in list((port.get('active') or {}).values())+list((port.get('closed') or {}).values()):
            p=_v2015n((rec.get('actual_close') or {}).get('pnl_pct'),_v2015n(rec.get('last_pnl_pct')))
            if p is not None and p<=-2.0: bad+=1
        perf=dict(port.get('performance') or {}); perf['missed_big_winner_count']=missed_big; perf['bad_pick_count']=bad
        rows.append({'portfolio':key,'selector':'GLOBAL_RELATIVE','cycle_cap':port.get('cycle_cap'),'cycles_seen':port.get('cycles_seen'),'chosen_count':port.get('chosen_count'),'hours_to_fill_10':port.get('hours_to_fill_10'),'horizons':_v2015_horizon_perf(port),**perf})
    eligible=[r for r in rows if int(r.get('n') or 0)>=3]
    leader=max(eligible,key=lambda r:(float(r.get('avg_pnl_pct') if r.get('avg_pnl_pct') is not None else -1e99),-int(r.get('large_loss_count') or 0),float(r.get('sum_pnl_pct') or -1e99)),default=None)
    raw_event_count=sum(int(c.get('raw_event_count') or 0) for c in cycles); latest_ts=max([float(c.get('last_ts') or 0) for c in cycles]+[0.0]); paper_status=load_json(TOP10_GLOBAL_FEED_STATUS_V2016,{}) or {}
    feed_diag={'raw_feed_events':raw_event_count,'actual_cycle_groups':len(cycles),'merged_same_cycle_events':max(0,raw_event_count-len(cycles)),'max_events_per_cycle':max([int(c.get('raw_event_count') or 0) for c in cycles]+[0]),'last_feed_age_sec':round(max(0.0,nowv-latest_ts),3) if latest_ts>0 else None,'paper_missing_identity_or_cycle_count':paper_status.get('missing_identity_or_cycle_count'),'paper_last_cycle_id':paper_status.get('last_cycle_id'),'paper_exact_feed_rows':paper_status.get('exact_feed_rows')}
    root.update({'schema':'shadow_top10_global_relative_state_v2016','updated_ts':nowv,'processed_cycle_candidates':processed,'portfolios':portfolios,'candidate_outcomes':outcomes,'forward_start_ts':start_ts,'forward_start_text':root.get('forward_start_text') or now_text(start_ts)})
    if len(processed)>12000: root['processed_cycle_candidates']=dict(list(processed.items())[-8000:])
    if len(outcomes)>20000: root['candidate_outcomes']=dict(sorted(outcomes.items(),key=lambda kv:float(kv[1].get('first_seen_ts') or 0),reverse=True)[:12000])
    state['top10_global_relative_v2016']=root
    return {'state':'ACTIVE' if cycles else 'COLLECTING','forward_start_ts':start_ts,'forward_start_text':root.get('forward_start_text'),'candidate_events':len(outcomes),'actual_cycle_groups':len(cycles),'portfolio_count':len(rows),'max_virtual_open':10,'selector':'GLOBAL_RELATIVE','cycle_caps':[1,2,3,'UNLIMITED'],'leader_min_n3':leader,'portfolios':rows,'unrankable_source_missing_seen':unrankable_seen,'new_candidate_events_this_cycle':new_candidate_events,'events_this_cycle':events,'feed_diagnostics':feed_diag,'score_contract':{'groups':['structure','trigger','strength','execution'],'group_weight':'equal mean of available groups','minimum_known_axes':6,'minimum_known_groups':3,'source_lane_used_in_score':False,'strategy_name_used_in_score':False,'current_rank_used_as_score':False,'missing_value_policy':'CHECK_SOURCE; never 0-fill','comparison_scope':'same actual Paper final-passed pre-OPEN cycle pool'},'policy':'all-alt final-passed candidates compete on same-cycle relative percentiles; strategy/lane is audit tag only. Four 10-slot books compare cycle 1/2/3/unlimited. Forward exact OPEN/CLOSED path only; no proxy and no actual trading change.','locks':{'retroactive_recalc':False,'proxy':False,'actual_selector_changed':False,'actual_open_limit_changed':False,'actual_cycle_limit_changed':False,'actual_open_changed':False,'actual_exit_changed':False,'auto_buy':False}}


def _v2010_unified_shadow_cycle_update(nowv: float, candidate_rows: List[Dict[str,Any]], closed_rows: List[Dict[str,Any]], fmap: Dict[str,Dict[str,Any]], ofmap: Dict[str,Dict[str,Any]], summary: Dict[str,Any], good_s2: Dict[str,Any], quality_shadow: Dict[str,Any]) -> Dict[str,Any]:  # type: ignore[override]
    board=_V2016_PREV_UNIFIED_SHADOW_UPDATE(nowv,candidate_rows,closed_rows,fmap,ofmap,summary,good_s2,quality_shadow)
    state=_v2010_shadow_state(); global_top10=_v2016_global_top10_shadow(nowv,closed_rows,state)
    board=dict(board) if isinstance(board,dict) else {}; board['schema']='unified_shadow_status_v2016'; board['version']='review_worker_v2.016'; board['build']='v2016_global_relative_top10_survival_exact_repair_2026-07-15'; board['top10_selection_v2015_reference_only']=board.get('top10_selection'); board['top10_global_relative']=global_top10
    _v2010_checkpoint_shadow_state(state,force=False)
    runtime=board.get('writer_runtime_v2010') if isinstance(board.get('writer_runtime_v2010'),dict) else {}; runtime['top10_global_relative_v2016']={'events_this_cycle':global_top10.get('events_this_cycle',0),'actual_cycle_groups':global_top10.get('actual_cycle_groups',0),'portfolio_count':global_top10.get('portfolio_count',0),'feed_diagnostics':global_top10.get('feed_diagnostics')}; runtime['event_batch_flush_v2016']=_v2010_flush_shadow_event_batches(); board['writer_runtime_v2010']=runtime
    save_json(UNIFIED_SHADOW_STATUS_V2010,board); return board


def _v2016_review_issue_once() -> None:
    marker=BASE_DIR/'runtime'/'v2016_global_relative_top10_survival_exact_repair.seeded'
    if marker.exists(): return
    ts=now_ts(); text=now_text(ts)
    try:
        _v2010_append_jsonl(BASE_DIR/'runtime'/'change_verify_ledger.jsonl',{'schema':'change_verify_ledger_v870','change_id':'v2016-global-relative-top10-survival-repair-001','issue_id':'GLOBAL-TOP10-SURVIVAL-2016','version':'v2016','verify_result':'CHECK','created_ts':ts,'created_at':text,'created_text':text,'writer':'review_v2016_lifecycle_writer','symptom':'v2015 TOP10 selector families narrowed the all-alt search by strategy-like lanes, and v2014 1h survival reached 20/20 SOURCE_MISSING despite OPEN-time quality evidence being sealed under profitability_entry_evidence_v1034.quality.','cause':'Survival reader did not walk the nested sealed profitability evidence. TOP10 comparison also applied lane-specific orderings and counted feed events rather than actual cycle groups.','files_changed':['review_worker_v2.016.py','paper_bot_v2.016.py','coinbot_main_v2_13_2016.py'],'new_mainline':'Repair missing survival entry metrics from exact sealed OPEN/CLOSED evidence only. Primary TOP10 is one all-alt same-cycle relative selector across structure/trigger/strength/execution, with strategy/lane excluded from score. Compare cycle 1/2/3/unlimited at max OPEN 10; same cycle feed events are merged for cap accounting.','not_touched':['actual candidate/S1 flow','actual Paper selector','actual OPEN limit','actual per-cycle entry limit','trigger/invalid/target','RR/room/chase/cost hard safety','actual exit/trailing','existing v2010-v2015 shadow state and append ledgers','protected ledgers','auto-buy OFF'],'remaining':'Server must prove survival exact repairs/new 1h classifications, Paper feed missing identity 0, actual cycle groups grow, GLOBAL_RELATIVE four books accumulate 3h/6h/12h/exact CLOSED, and existing shadows continue without reset.','auto_buy':False})
        _v2010_append_jsonl(BASE_DIR/'ledger'/'issue_ledger_events.jsonl',{'schema':'coinbot_single_work_ledger_v870','event_type':'ISSUE','issue_id':'GLOBAL-TOP10-SURVIVAL-2016','status':'CHECK','title':'전체 알트 통합 TOP10 상대선발 + 생존 Shadow exact 연결 수리','detail':'전략/유입경로는 꼬리표만 유지. 전체 OPEN직전 후보를 같은 cycle에서 상대비교. 기존 Shadow 기록 보존.','version':'v2016','created_ts':ts,'created_at':text,'created_text':text,'auto_buy':False})
        marker.parent.mkdir(parents=True,exist_ok=True); marker.write_text(text,encoding='utf-8')
    except Exception: pass

try: _v2016_review_issue_once()
except Exception: pass

VERSION='review_worker_v2.016'
BUILD_LABEL='v2016_global_relative_top10_survival_exact_repair_2026-07-15'
MAIN_DEPLOY_VERSION=BUILD_LABEL




# =============================================================================
# review_worker v2.017: simultaneous genuine fresh-event cluster comparison.
# - Review drains Paper's transient async spool and appends canonical feed in one
#   batch/fsync outside the Paper hot path.
# - Same exact candidate pool compares GLOBAL_RELATIVE versus GLOBAL_RELATIVE_SYNC.
# - The sync arm adds one fifth relative group: distinct-alt fresh-event density
#   at 30s/60s/120s as known at that decision time. No hard block or strategy bias.
# - Existing v2010-v2016 shadow state remains preserved and continues.
# =============================================================================
TOP10_ASYNC_SPOOL_DIR_V2017 = BASE_DIR / 'runtime' / 'top10_shadow_spool_v2017'
TOP10_ASYNC_PAPER_STATUS_V2017 = BASE_DIR / 'paper_top10_async_spool_status_v2017.json'
TOP10_ASYNC_START_V2017 = BASE_DIR / 'paper_top10_async_start_v2017.json'
TOP10_ASYNC_REVIEW_STATUS_V2017 = BASE_DIR / 'review_top10_async_spool_status_v2017.json'
TOP10_SYNC_LEDGER_V2017 = BASE_DIR / 'shadow_top10_sync_fresh_cluster_events_v2017.jsonl'
TOP10_RANK_ORDER_LEDGER_V2019 = BASE_DIR / 'shadow_top10_rank_selection_exact_events_v2019.jsonl'
TOP10_SYNC_CAPS_V2017 = (1,2,3,0)
TOP10_SYNC_MAX_OPEN_V2017 = 10
TOP10_SYNC_HORIZONS_V2017 = TOP10_GLOBAL_HORIZONS_V2016
TOP10_SYNC_SELECTORS_V2017 = ('GLOBAL_RELATIVE','GLOBAL_RELATIVE_SYNC')
_V2017_REVIEW_MODULE_START_TS = time.time()
_V2017_PREV_GROUP_FEED_CYCLES = _v2016_group_feed_cycles
_V2017_PREV_UNIFIED_SHADOW_UPDATE = _v2010_unified_shadow_cycle_update


def _v2017_append_feed_batch(events: List[Dict[str,Any]]) -> int:
    if not events: return 0
    TOP10_SHADOW_FEED_V2015.parent.mkdir(parents=True,exist_ok=True)
    raw=''.join(json.dumps(e,ensure_ascii=False,separators=(',',':'))+'\n' for e in events).encode('utf-8')
    with TOP10_SHADOW_FEED_V2015.open('ab') as fp:
        fp.write(raw); fp.flush(); os.fsync(fp.fileno())
    return len(raw)


def _v2017_drain_async_spool() -> Dict[str,Any]:
    started=time.monotonic(); paper_status=load_json(TOP10_ASYNC_PAPER_STATUS_V2017,{}) or {}
    try: files=sorted(TOP10_ASYNC_SPOOL_DIR_V2017.glob('*.json'))[:4096]
    except Exception: files=[]
    existing={str(r.get('event_id') or '') for r in read_jsonl(TOP10_SHADOW_FEED_V2015,max_lines=TOP10_SHADOW_FEED_TAIL_V2015) if isinstance(r,dict) and str(r.get('event_id') or '')}
    batch=[]; consumed=[]; bad=0; duplicate=0
    for path in files:
        try:
            row=json.loads(path.read_text(encoding='utf-8',errors='ignore'))
            if not isinstance(row,dict) or row.get('event')!='PREOPEN_ELIGIBLE_CYCLE' or not str(row.get('event_id') or '') or not str(row.get('cycle_id') or ''):
                bad+=1; continue
            eid=str(row.get('event_id'))
            if eid in existing: duplicate+=1
            else:
                batch.append(row); existing.add(eid)
            consumed.append(path)
        except Exception:
            bad+=1
    appended=0; bytes_written=0; append_error_text=None
    try:
        if batch:
            bytes_written=_v2017_append_feed_batch(batch); appended=len(batch)
        # Transient spool files are deleted only after canonical append succeeded.
        for path in consumed:
            try: path.unlink()
            except Exception: pass
    except Exception as exc:
        append_error_text=f'{type(exc).__name__}: {exc}'
        try: append_error(ERROR,'v2017_drain_async_spool',exc)
        except Exception: pass
    try: pending_after=len(list(TOP10_ASYNC_SPOOL_DIR_V2017.glob('*.json')))
    except Exception: pending_after=-1
    status={'schema':'review_top10_async_spool_status_v2017','version':'review_worker_v2.017','build':'v2017_sync_fresh_cluster_async_shadow_2026-07-15','updated_ts':time.time(),'updated_text':now_text(),'spool_files_seen':len(files),'canonical_events_appended':appended,'canonical_bytes_written':bytes_written,'duplicate_spool_events':duplicate,'bad_spool_files':bad,'append_error':append_error_text,'pending_spool_files_after':pending_after,'paper_queue_drop':paper_status.get('queue_drop',0),'paper_spool_errors':paper_status.get('spool_errors',0),'paper_pending_ram_events':paper_status.get('pending_ram_events'),'paper_hot_path_jsonl_read':paper_status.get('hot_path_jsonl_read'),'paper_hot_path_jsonl_fsync':paper_status.get('hot_path_jsonl_fsync'),'elapsed_sec':round(time.monotonic()-started,6),'owner':'Review drains transient spool -> one batch append/fsync -> then removes transient spool files','actual_selector_changed':False,'actual_open_changed':False,'auto_buy':False}
    save_json(TOP10_ASYNC_REVIEW_STATUS_V2017,status)
    return status


def _v2016_group_feed_cycles(start_ts: float) -> List[Dict[str,Any]]:  # type: ignore[override]
    _v2017_drain_async_spool()
    return _V2017_PREV_GROUP_FEED_CYCLES(start_ts)


def _v2017_event_ts(cand: Dict[str,Any]) -> Optional[float]:
    ts=_v2015n(cand.get('trigger_event_ts'))
    if ts is not None: return float(ts)
    selected=_v2015n(cand.get('selected_ts')); age=_v2015n(cand.get('occurrence_age'))
    if selected is not None and age is not None and age>=0: return float(selected)-float(age)
    return None


def _v2024_trigger_event_source_state(cand: Dict[str,Any]) -> str:
    state=str(cand.get('trigger_event_source_state_v2024') or '').strip().upper()
    if state in {'GENUINE_TRIGGER_EVENT','EXACT_NO_NEW_TRIGGER_EVENT','SOURCE_MISSING'}:
        return state
    # Rows written before v2024 are preserved as historical reference, not presented as a current connection failure.
    return 'LEGACY_REFERENCE_ONLY'


def _v2017_density_contexts(cycles: List[Dict[str,Any]]) -> Dict[str,Dict[str,Dict[str,Any]]]:
    """Precompute decision-time-safe density with a sorted delivered-event index."""
    import bisect as _bisect
    delivered_ts=[]; delivered_rows=[]; contexts={}
    for cycle in cycles:
        decision_ts=float(cycle.get('last_ts') or cycle.get('first_ts') or 0)
        current=[]
        for cand in cycle.get('candidates') or []:
            if not isinstance(cand,dict): continue
            source_state=_v2024_trigger_event_source_state(cand)
            ets=_v2017_event_ts(cand); ticker=str(cand.get('ticker') or '')
            if source_state!='GENUINE_TRIGGER_EVENT' or ets is None or not ticker or ets>decision_ts: continue
            current.append((float(ets),ticker))
        for ets,ticker in current:
            idx=_bisect.bisect_right(delivered_ts,ets)
            delivered_ts.insert(idx,ets); delivered_rows.insert(idx,(ets,ticker))
        cmap={}
        for cand in cycle.get('candidates') or []:
            if not isinstance(cand,dict): continue
            ident=_v2015_candidate_identity(cand); ets=_v2017_event_ts(cand); source_state=_v2024_trigger_event_source_state(cand)
            if not ident: continue
            if source_state=='EXACT_NO_NEW_TRIGGER_EVENT':
                cmap[ident]={'event_ts':None,'decision_ts':decision_ts,'distinct_alt_events_30s':0,'distinct_alt_events_60s':0,'distinct_alt_events_120s':0,'hindsight_guard':'exact no-new-trigger-event is zero density, not missing','source':'Paper exact trigger_event_source_state_v2024','source_state_v2024':source_state}
                continue
            if source_state!='GENUINE_TRIGGER_EVENT' or ets is None:
                continue
            counts={}
            for label,window in (('30s',30.0),('60s',60.0),('120s',120.0)):
                lo=_bisect.bisect_left(delivered_ts,float(ets)-window)
                hi=_bisect.bisect_right(delivered_ts,min(decision_ts,float(ets)+window))
                counts[label]=len({ticker for _ts,ticker in delivered_rows[lo:hi]})
            cmap[ident]={'event_ts':float(ets),'decision_ts':decision_ts,'distinct_alt_events_30s':counts['30s'],'distinct_alt_events_60s':counts['60s'],'distinct_alt_events_120s':counts['120s'],'hindsight_guard':'only feed events delivered by decision_ts are counted','source':'genuine trigger event timestamps already sealed in Paper pre-OPEN feed','source_state_v2024':source_state}
        contexts[str(cycle.get('cycle_id') or '')]=cmap
    return contexts


def _v2017_score_cycle(cycle: Dict[str,Any], density: Dict[str,Dict[str,Any]]) -> Dict[str,List[Dict[str,Any]]]:
    full=[dict(x) for x in (cycle.get('candidates') or []) if isinstance(x,dict) and _v2015_candidate_identity(x)]
    baseline=_v2016_score_cycle(full)
    density_axes=('distinct_alt_events_30s','distinct_alt_events_60s','distinct_alt_events_120s')
    pools={key:[float(ctx[key]) for ctx in density.values() if ctx.get(key) is not None] for key in density_axes}
    baseline_out=[]; sync_out=[]
    for row in baseline:
        ident=_v2015_candidate_identity(row); ctx=density.get(ident)
        base_score=_v2015n((row.get('relative_selection_v2016') or {}).get('score'))
        base=dict(row); base['selection_v2017']={'selector':'GLOBAL_RELATIVE','score':base_score,'rankable':base_score is not None,'base_score':base_score,'sync_group_score':None,'density_context':ctx,'sync_density_used_in_score':False,'strategy_name_used_in_score':False,'source_lane_used_in_score':False}
        baseline_out.append(base)
        sync=dict(row); pct={}
        if ctx:
            for key in density_axes: pct[key]=_v2016_pct(pools[key],_v2015n(ctx.get(key)),True)
        vals=[v for v in pct.values() if v is not None]
        sync_group=round(sum(vals)/len(vals),6) if vals else None
        groups=(row.get('relative_selection_v2016') or {}).get('group_scores') if isinstance((row.get('relative_selection_v2016') or {}).get('group_scores'),dict) else {}
        base_groups=[_v2015n(groups.get(k)) for k in ('structure','trigger','strength','execution')]
        base_groups=[v for v in base_groups if v is not None]
        rankable=base_score is not None and sync_group is not None
        score=round((sum(base_groups)+sync_group)/(len(base_groups)+1),6) if rankable and base_groups else None
        sync['selection_v2017']={'selector':'GLOBAL_RELATIVE_SYNC','score':score,'rankable':rankable,'base_score':base_score,'sync_group_score':sync_group,'density_percentiles':pct,'density_context':ctx,'sync_density_used_in_score':True,'sync_group_weight':'one equal comparison group beside structure/trigger/strength/execution','strategy_name_used_in_score':False,'source_lane_used_in_score':False,'hard_block':False}
        sync_out.append(sync)
    def sort_rows(rows):
        return sorted(rows,key=lambda r:((r.get('selection_v2017') or {}).get('score') is None,-float((r.get('selection_v2017') or {}).get('score') or -1e99),-int((r.get('relative_selection_v2016') or {}).get('known_axes') or 0),str(r.get('ticker') or '')))
    return {'GLOBAL_RELATIVE':sort_rows(baseline_out),'GLOBAL_RELATIVE_SYNC':sort_rows(sync_out)}


def _v2019_rank_snapshot_payload(selector: str, cycle: Dict[str,Any], ranked: List[Dict[str,Any]]) -> Dict[str,Any]:
    """Seal the exact selector order visible at this Review decision snapshot."""
    ranking=[]; rankable_rank=0
    for ordered_position,cand in enumerate(ranked,1):
        selection=cand.get('selection_v2017') if isinstance(cand.get('selection_v2017'),dict) else {}
        score=_v2015n(selection.get('score')); rankable=score is not None
        if rankable: rankable_rank+=1
        ranking.append({
            'ordered_position':ordered_position,
            'selector_rank':rankable_rank if rankable else None,
            'rankable':rankable,
            'identity':_v2015_candidate_identity(cand),
            'ticker':str(cand.get('ticker') or ''),
            'decision_key':cand.get('decision_key'),
            'pos_id':cand.get('pos_id'),
            'score':score,
            'base_score':_v2015n(selection.get('base_score')),
            'sync_group_score':_v2015n(selection.get('sync_group_score')),
            'trigger_event_ts':_v2017_event_ts(cand),
            'density_context':selection.get('density_context'),
        })
    fingerprint=json.dumps({
        'selector':selector,
        'cycle_id':str(cycle.get('cycle_id') or ''),
        'decision_ts':float(cycle.get('last_ts') or cycle.get('first_ts') or 0),
        'ranking':ranking,
    },ensure_ascii=False,sort_keys=True,separators=(',',':'))
    snapshot_id=hashlib.sha256(fingerprint.encode('utf-8')).hexdigest()[:24]
    return {
        'schema':'shadow_top10_rank_selection_exact_event_v2019',
        'event':'RANK_SNAPSHOT',
        'rank_snapshot_id':snapshot_id,
        'selector':selector,
        'cycle_id':str(cycle.get('cycle_id') or ''),
        'cycle_first_ts':cycle.get('first_ts'),
        'cycle_last_ts':cycle.get('last_ts'),
        'raw_event_count':cycle.get('raw_event_count'),
        'candidate_count':len(ranking),
        'rankable_count':sum(1 for row in ranking if row.get('rankable')),
        'unrankable_count':sum(1 for row in ranking if not row.get('rankable')),
        'ranking':ranking,
        'score_formula_changed':False,
        'actual_selector_changed':False,
        'actual_open_changed':False,
        'auto_buy':False,
    }


def _v2017_sync_compare_shadow(nowv: float, closed_rows: List[Dict[str,Any]], state: Dict[str,Any]) -> Dict[str,Any]:
    root=state.get('top10_sync_fresh_compare_v2017') if isinstance(state.get('top10_sync_fresh_compare_v2017'),dict) else {}
    if not root:
        start_meta=load_json(TOP10_ASYNC_START_V2017,{}) or {}; seeded=_cs_num_v1141(start_meta.get('started_ts')) or float(_V2017_REVIEW_MODULE_START_TS)
        root={'forward_start_ts':float(seeded),'forward_start_text':now_text(float(seeded)),'processed_cycle_candidates':{},'portfolios':{},'candidate_outcomes':{}}
    start_ts=float(root.get('forward_start_ts') or _V2017_REVIEW_MODULE_START_TS)
    cycles=_v2016_group_feed_cycles(start_ts)
    processed=root.get('processed_cycle_candidates') if isinstance(root.get('processed_cycle_candidates'),dict) else {}
    portfolios=root.get('portfolios') if isinstance(root.get('portfolios'),dict) else {}
    outcomes=root.get('candidate_outcomes') if isinstance(root.get('candidate_outcomes'),dict) else {}
    open_pos,open_dec,closed_pos,closed_dec=_v2015_live_maps(closed_rows)
    density_contexts=_v2017_density_contexts(cycles)
    rank_snapshot_ids=root.get('rank_snapshot_ids_v2019') if isinstance(root.get('rank_snapshot_ids_v2019'),dict) else {}
    events=0; new_candidate_events=0; unrankable=Counter(); legacy_unrankable=Counter(); exact_no_event=Counter(); rank_snapshot_events=0; selection_order_events=0

    for cycle in cycles:
        for cand in cycle.get('candidates') or []:
            ident=_v2015_candidate_identity(cand)
            if ident and ident not in outcomes:
                outcomes[ident]={'candidate':dict(cand),'cycle_id':cycle.get('cycle_id'),'first_seen_ts':cycle.get('first_ts')}; new_candidate_events+=1
    for ident,outcome in outcomes.items():
        cand=outcome.get('candidate') if isinstance(outcome.get('candidate'),dict) else {}
        opened,closed=_v2015_actual_row(cand,open_pos,open_dec,closed_pos,closed_dec); live=opened or closed
        if live is not None:
            p=_cs_row_pnl_v1141(live)
            if p is not None:
                outcome['last_pnl_pct']=round(float(p),6); mx=_v2015n(outcome.get('max_seen_pct')); mn=_v2015n(outcome.get('min_seen_pct')); outcome['max_seen_pct']=float(p) if mx is None else max(mx,float(p)); outcome['min_seen_pct']=float(p) if mn is None else min(mn,float(p))
            opened_at=_cs_opened_ts_v1142(live)
            if opened_at is not None: outcome['exact_opened_at']=float(opened_at)
        if closed is not None and 'actual_close' not in outcome:
            p=_cs_row_pnl_v1141(closed); mfe=_cs_num_v1141(closed.get('mfe_pct'),closed.get('max_profit_pct'),closed.get('max_pnl_pct')); mae=_cs_num_v1141(closed.get('mae_pct'),closed.get('min_profit_pct'),closed.get('min_pnl_pct')); hold=_cs_num_v1141(closed.get('hold_sec'),closed.get('holding_sec'),closed.get('duration_sec'))
            if p is not None: outcome['actual_close']={'pnl_pct':round(float(p),6),'mfe_pct':mfe,'mae_pct':mae,'hold_sec':hold,'closed_ts':nowv}

    for cycle in cycles:
        cid=str(cycle.get('cycle_id') or '')
        scored_by_selector=_v2017_score_cycle(cycle,density_contexts.get(cid,{}) )
        for selector,ranked in scored_by_selector.items():
            rank_snapshot=_v2019_rank_snapshot_payload(selector,cycle,ranked)
            rank_snapshot_id=str(rank_snapshot.get('rank_snapshot_id') or '')
            if rank_snapshot_id and rank_snapshot_id not in rank_snapshot_ids:
                sealed=dict(rank_snapshot); sealed['ts']=nowv; sealed['time']=now_text(nowv)
                _V2010_SHADOW_EVENT_BATCH.setdefault(str(TOP10_RANK_ORDER_LEDGER_V2019),[]).append(sealed)
                rank_snapshot_ids[rank_snapshot_id]=nowv; rank_snapshot_events+=1; events+=1
            rank_meta_by_ident={str(row.get('identity') or ''):row for row in (rank_snapshot.get('ranking') or []) if str(row.get('identity') or '')}
            done_key=f'{selector}|{cid}'; done=set(str(x) for x in (processed.get(done_key) or []))
            new_ranked=[x for x in ranked if _v2015_candidate_identity(x) not in done]
            rankable_new=[x for x in new_ranked if (x.get('selection_v2017') or {}).get('score') is not None]
            for x in new_ranked:
                if (x.get('selection_v2017') or {}).get('score') is not None:
                    if _v2024_trigger_event_source_state(x)=='EXACT_NO_NEW_TRIGGER_EVENT': exact_no_event[selector]+=1
                    continue
                source_state=_v2024_trigger_event_source_state(x)
                if source_state=='LEGACY_REFERENCE_ONLY': legacy_unrankable[selector]+=1
                else: unrankable[selector]+=1
            for cap in TOP10_SYNC_CAPS_V2017:
                key=f'{selector}|CYCLE_{cap if cap else "UNLIMITED"}'
                port=portfolios.get(key) if isinstance(portfolios.get(key),dict) else {'selector':selector,'cycle_cap':cap,'max_open':10,'active':{},'closed':{},'chosen_count':0,'skipped_count':0,'cycles_seen':0,'cycle_selected_counts':{}}
                active=port.get('active') if isinstance(port.get('active'),dict) else {}; closed_book=port.get('closed') if isinstance(port.get('closed'),dict) else {}; counts=port.get('cycle_selected_counts') if isinstance(port.get('cycle_selected_counts'),dict) else {}
                already=int(counts.get(cid) or 0); slots=max(0,TOP10_SYNC_MAX_OPEN_V2017-len(active)); cycle_left=slots if cap<=0 else max(0,cap-already); limit=min(slots,cycle_left); chosen=0
                active_tickers={str(x.get('ticker') or '') for x in active.values()}
                for cand in rankable_new:
                    ident=_v2015_candidate_identity(cand); ticker=str(cand.get('ticker') or ''); score=(cand.get('selection_v2017') or {}).get('score')
                    if score is None or ident in active or ident in closed_book or ticker in active_tickers: continue
                    if chosen>=limit: port['skipped_count']=int(port.get('skipped_count') or 0)+1; continue
                    rank_meta=rank_meta_by_ident.get(ident) if isinstance(rank_meta_by_ident.get(ident),dict) else {}
                    rec={'identity':ident,'pos_id':cand.get('pos_id'),'decision_key':cand.get('decision_key'),'ticker':ticker,'cycle_id':cid,'selected_ts':float(cycle.get('last_ts') or nowv),'selected_text':now_text(float(cycle.get('last_ts') or nowv)),'candidate':cand,'selection_v2017':cand.get('selection_v2017'),'rank_trace_v2019':{'rank_snapshot_id':rank_snapshot_id,'selector_rank':rank_meta.get('selector_rank'),'ordered_position':rank_meta.get('ordered_position')},'horizons':{},'observed_peak_pct':None,'observed_low_pct':None,'last_pnl_pct':None,'path_state':'WAIT_EXACT_OPEN'}
                    active[ident]=rec; active_tickers.add(ticker); chosen+=1; port['chosen_count']=int(port.get('chosen_count') or 0)+1
                    selected_order_in_cycle=already+chosen; portfolio_selected_order_total=int(port.get('chosen_count') or 0)
                    if not port.get('first_selected_ts'): port['first_selected_ts']=rec['selected_ts']
                    _V2010_SHADOW_EVENT_BATCH.setdefault(str(TOP10_SYNC_LEDGER_V2017),[]).append({'schema':'shadow_top10_sync_fresh_cluster_event_v2017','event':'VIRTUAL_SELECT','portfolio':key,'selector':selector,'cycle_cap':cap,'identity':ident,'ticker':ticker,'cycle_id':cid,'selection_v2017':cand.get('selection_v2017'),'candidate':cand,'ts':nowv,'time':now_text(nowv),'actual_selector_changed':False,'actual_open_changed':False,'auto_buy':False}); events+=1
                    _V2010_SHADOW_EVENT_BATCH.setdefault(str(TOP10_RANK_ORDER_LEDGER_V2019),[]).append({'schema':'shadow_top10_rank_selection_exact_event_v2019','event':'VIRTUAL_SELECT_ORDER','rank_snapshot_id':rank_snapshot_id,'portfolio':key,'selector':selector,'cycle_cap':cap,'cycle_id':cid,'identity':ident,'ticker':ticker,'decision_key':cand.get('decision_key'),'pos_id':cand.get('pos_id'),'selector_rank_at_selection':rank_meta.get('selector_rank'),'ordered_position_at_selection':rank_meta.get('ordered_position'),'selected_order_in_cycle':selected_order_in_cycle,'portfolio_selected_order_total':portfolio_selected_order_total,'score_at_selection':(cand.get('selection_v2017') or {}).get('score'),'ts':nowv,'time':now_text(nowv),'score_formula_changed':False,'actual_selector_changed':False,'actual_open_changed':False,'auto_buy':False}); selection_order_events+=1; events+=1
                counts[cid]=already+chosen; port['cycle_selected_counts']=counts; port['active']=active; port['closed']=closed_book; port['cycles_seen']=len(counts); portfolios[key]=port
            # Mark every observed candidate for this selector/cycle once. Legacy unrankable rows stay in append history as REFERENCE_ONLY and are not re-counted forever.
            processed[done_key]=sorted(done|{_v2015_candidate_identity(x) for x in new_ranked if _v2015_candidate_identity(x)})

    for key,port in portfolios.items():
        active=port.get('active') if isinstance(port.get('active'),dict) else {}; closed_book=port.get('closed') if isinstance(port.get('closed'),dict) else {}
        for ident,rec in list(active.items()):
            cand=rec.get('candidate') if isinstance(rec.get('candidate'),dict) else {}; opened,closed=_v2015_actual_row(cand,open_pos,open_dec,closed_pos,closed_dec); live=opened or closed
            if live is not None:
                pnl=_cs_row_pnl_v1141(live)
                if pnl is not None:
                    rec['last_pnl_pct']=round(float(pnl),6); mx=_v2015n(rec.get('observed_peak_pct')); mn=_v2015n(rec.get('observed_low_pct')); rec['observed_peak_pct']=float(pnl) if mx is None else max(mx,float(pnl)); rec['observed_low_pct']=float(pnl) if mn is None else min(mn,float(pnl)); rec['path_state']='EXACT_OPEN' if opened is not None else 'EXACT_CLOSED'
                exact_opened=_cs_opened_ts_v1142(live)
                if exact_opened is not None: rec['exact_opened_at']=float(exact_opened)
            basis_ts=float(rec.get('exact_opened_at') or rec.get('selected_ts') or nowv); elapsed=max(0.0,nowv-basis_ts); horizons=rec.get('horizons') if isinstance(rec.get('horizons'),dict) else {}; rec['horizons']=horizons
            for label,sec in TOP10_SYNC_HORIZONS_V2017:
                if label in horizons or elapsed<sec: continue
                horizons[label]={'completed_ts':nowv,'pnl_pct':rec.get('last_pnl_pct'),'peak_pct':rec.get('observed_peak_pct'),'low_pct':rec.get('observed_low_pct'),'closed_before_horizon':bool(closed is not None),'time_basis':'EXACT_OPENED_AT' if rec.get('exact_opened_at') else 'PREOPEN_SELECTED_TS'}
                _V2010_SHADOW_EVENT_BATCH.setdefault(str(TOP10_SYNC_LEDGER_V2017),[]).append({'schema':'shadow_top10_sync_fresh_cluster_event_v2017','event':'HORIZON','portfolio':key,'identity':ident,'ticker':rec.get('ticker'),'horizon':label,'snapshot':horizons[label],'ts':nowv,'time':now_text(nowv),'auto_buy':False}); events+=1
            if closed is not None:
                p=_cs_row_pnl_v1141(closed)
                if p is None: continue
                mfe=_cs_num_v1141(closed.get('mfe_pct'),closed.get('max_profit_pct'),closed.get('max_pnl_pct')); mae=_cs_num_v1141(closed.get('mae_pct'),closed.get('min_profit_pct'),closed.get('min_pnl_pct')); hold=_cs_num_v1141(closed.get('hold_sec'),closed.get('holding_sec'),closed.get('duration_sec'))
                rec['actual_close']={'pnl_pct':round(float(p),6),'mfe_pct':mfe,'mae_pct':mae,'hold_sec':hold,'closed_ts':nowv,'match':'EXACT_POS_ID' if cand.get('pos_id') and str(cand.get('pos_id')) in closed_pos else 'EXACT_DECISION_KEY'}; rec['finalized_ts']=nowv; closed_book[ident]=rec; active.pop(ident,None)
                _V2010_SHADOW_EVENT_BATCH.setdefault(str(TOP10_SYNC_LEDGER_V2017),[]).append({'schema':'shadow_top10_sync_fresh_cluster_event_v2017','event':'ACTUAL_CLOSE','portfolio':key,'selector':port.get('selector'),'identity':ident,'ticker':rec.get('ticker'),'actual_close':rec['actual_close'],'ts':nowv,'time':now_text(nowv),'auto_buy':False}); events+=1
        if len(closed_book)>500: closed_book=dict(sorted(closed_book.items(),key=lambda kv:float(kv[1].get('finalized_ts') or 0),reverse=True)[:500])
        if len(port.get('cycle_selected_counts') or {})>12000: port['cycle_selected_counts']=dict(list((port.get('cycle_selected_counts') or {}).items())[-8000:])
        port['active']=active; port['closed']=closed_book; port['performance']=_v2015_portfolio_perf(port)
        if port.get('first_selected_ts') and len(active)>=10 and not port.get('first_full_ts'): port['first_full_ts']=nowv
        if port.get('first_selected_ts') and port.get('first_full_ts'): port['hours_to_fill_10']=round((float(port['first_full_ts'])-float(port['first_selected_ts']))/3600.0,3)

    rows=[]
    for key,port in portfolios.items():
        chosen=set(port.get('active',{}))|set(port.get('closed',{})); missed_big=0; bad=0
        for ident,outcome in outcomes.items():
            close=outcome.get('actual_close') if isinstance(outcome.get('actual_close'),dict) else {}; pnl=_v2015n(close.get('pnl_pct')); mfe=_v2015n(close.get('mfe_pct'))
            if ident not in chosen and ((pnl is not None and pnl>=3.0) or (mfe is not None and mfe>=5.0)): missed_big+=1
        for rec in list((port.get('active') or {}).values())+list((port.get('closed') or {}).values()):
            p=_v2015n((rec.get('actual_close') or {}).get('pnl_pct'),_v2015n(rec.get('last_pnl_pct')))
            if p is not None and p<=-2.0: bad+=1
        perf=dict(port.get('performance') or {}); perf['missed_big_winner_count']=missed_big; perf['bad_pick_count']=bad
        rows.append({'portfolio':key,'selector':port.get('selector'),'cycle_cap':port.get('cycle_cap'),'cycles_seen':port.get('cycles_seen'),'chosen_count':port.get('chosen_count'),'hours_to_fill_10':port.get('hours_to_fill_10'),'horizons':_v2015_horizon_perf(port),**perf})
    eligible=[r for r in rows if int(r.get('n') or 0)>=3]
    leader=max(eligible,key=lambda r:(float(r.get('avg_pnl_pct') if r.get('avg_pnl_pct') is not None else -1e99),-int(r.get('large_loss_count') or 0),float(r.get('sum_pnl_pct') or -1e99)),default=None)
    drain=load_json(TOP10_ASYNC_REVIEW_STATUS_V2017,{}) or {}; paper=load_json(TOP10_ASYNC_PAPER_STATUS_V2017,{}) or {}
    root.update({'schema':'shadow_top10_sync_fresh_compare_state_v2019','updated_ts':nowv,'processed_cycle_candidates':processed,'portfolios':portfolios,'candidate_outcomes':outcomes,'rank_snapshot_ids_v2019':rank_snapshot_ids,'forward_start_ts':start_ts,'forward_start_text':root.get('forward_start_text') or now_text(start_ts)})
    if len(processed)>24000: root['processed_cycle_candidates']=dict(list(processed.items())[-16000:])
    if len(outcomes)>20000: root['candidate_outcomes']=dict(sorted(outcomes.items(),key=lambda kv:float(kv[1].get('first_seen_ts') or 0),reverse=True)[:12000])
    if len(rank_snapshot_ids)>24000: root['rank_snapshot_ids_v2019']=dict(sorted(rank_snapshot_ids.items(),key=lambda kv:float(kv[1] or 0),reverse=True)[:16000])
    state['top10_sync_fresh_compare_v2017']=root
    rank_exact={'schema':'top10_rank_selection_exact_status_v2019','ledger':TOP10_RANK_ORDER_LEDGER_V2019.name,'rank_snapshot_events_this_cycle':rank_snapshot_events,'selection_order_events_this_cycle':selection_order_events,'known_rank_snapshot_count':len(root.get('rank_snapshot_ids_v2019') or {}),'records_full_candidate_ranking':True,'records_shadow_selection_order':True,'score_formula_changed':False,'actual_selector_changed':False,'actual_open_changed':False,'auto_buy':False}
    return {'state':'ACTIVE' if cycles else 'COLLECTING','forward_start_ts':start_ts,'forward_start_text':root.get('forward_start_text'),'candidate_events':len(outcomes),'actual_cycle_groups':len(cycles),'portfolio_count':len(rows),'selectors':['GLOBAL_RELATIVE','GLOBAL_RELATIVE_SYNC'],'cycle_caps':[1,2,3,'UNLIMITED'],'leader_min_n3':leader,'portfolios':rows,'unrankable_by_selector':dict(unrankable),'legacy_unrankable_reference_by_selector_v2024':dict(legacy_unrankable),'exact_no_new_trigger_event_ranked_by_selector_v2024':dict(exact_no_event),'source_link_contract_v2024':'current source missing only; pre-v2024 rows are REFERENCE_ONLY; exact no-new-trigger-event is zero density','new_candidate_events_this_cycle':new_candidate_events,'events_this_cycle':events,'rank_order_exact_v2019':rank_exact,'transport':{'paper_hot_path':'RAM_ENQUEUE_ONLY','paper_hot_path_jsonl_read':paper.get('hot_path_jsonl_read'),'paper_hot_path_jsonl_fsync':paper.get('hot_path_jsonl_fsync'),'paper_queue_drop':paper.get('queue_drop',0),'paper_spool_errors':paper.get('spool_errors',0),'review_canonical_events_appended':drain.get('canonical_events_appended',0),'review_pending_spool_files':drain.get('pending_spool_files_after'),'review_drain_elapsed_sec':drain.get('elapsed_sec')},'sync_contract':{'feature':'simultaneous genuine fresh-event density','windows_sec':[30,60,120],'value':'distinct alt tickers with sealed trigger event timestamp near candidate event','decision_time_guard':'only events already delivered by candidate cycle decision_ts','score_role':'one fifth relative group in GLOBAL_RELATIVE_SYNC comparison arm only','hard_block':False,'strategy_or_lane_bonus':False,'additional_market_fetch':False,'paper_recheck':False,'proxy':False,'exact_no_event_policy_v2024':'proven no-new-trigger-event = density 0; unknown source stays SOURCE_MISSING'},'policy':'same final-passed all-alt candidate pool compares baseline relative selector against an experimental simultaneous-fresh-event density arm; both run OPEN10 x cycle1/2/3/unlimited forward exact. v2019 seals full selector ranking/order; v2024 repairs exact owner source linkage without replaying past rows.','locks':{'retroactive_recalc':False,'proxy':False,'actual_selector_changed':False,'actual_open_limit_changed':False,'actual_cycle_limit_changed':False,'actual_open_changed':False,'actual_exit_changed':False,'auto_buy':False}}


def _v2010_unified_shadow_cycle_update(nowv: float, candidate_rows: List[Dict[str,Any]], closed_rows: List[Dict[str,Any]], fmap: Dict[str,Dict[str,Any]], ofmap: Dict[str,Dict[str,Any]], summary: Dict[str,Any], good_s2: Dict[str,Any], quality_shadow: Dict[str,Any]) -> Dict[str,Any]:  # type: ignore[override]
    board=_V2017_PREV_UNIFIED_SHADOW_UPDATE(nowv,candidate_rows,closed_rows,fmap,ofmap,summary,good_s2,quality_shadow)
    state=_v2010_shadow_state(); sync_compare=_v2017_sync_compare_shadow(nowv,closed_rows,state)
    board=dict(board) if isinstance(board,dict) else {}; board['schema']='unified_shadow_status_v2019'; board['version']=VERSION; board['build']=BUILD_LABEL; board['top10_sync_fresh_compare']=sync_compare; board['top10_rank_selection_exact']=sync_compare.get('rank_order_exact_v2019')
    _v2010_checkpoint_shadow_state(state,force=False)
    runtime=board.get('writer_runtime_v2010') if isinstance(board.get('writer_runtime_v2010'),dict) else {}; runtime['top10_sync_fresh_compare_v2017']={'events_this_cycle':sync_compare.get('events_this_cycle',0),'actual_cycle_groups':sync_compare.get('actual_cycle_groups',0),'portfolio_count':sync_compare.get('portfolio_count',0),'transport':sync_compare.get('transport')}; runtime['top10_rank_selection_exact_v2019']=sync_compare.get('rank_order_exact_v2019'); runtime['event_batch_flush_v2019']=_v2010_flush_shadow_event_batches(); board['writer_runtime_v2010']=runtime
    save_json(UNIFIED_SHADOW_STATUS_V2010,board); return board


def _v2017_review_issue_once() -> None:
    marker=BASE_DIR/'runtime'/'v2017_sync_fresh_cluster_async_shadow.seeded'
    if marker.exists(): return
    ts=time.time(); text=now_text(ts)
    try:
        _v2010_append_jsonl(BASE_DIR/'runtime'/'change_verify_ledger.jsonl',{'schema':'change_verify_ledger_v870','change_id':'v2017-sync-fresh-cluster-shadow-001','issue_id':'SYNC-FRESH-TOP10-2017','version':'v2017','verify_result':'CHECK','created_ts':ts,'created_at':text,'created_text':text,'writer':'review_v2017_lifecycle_writer','symptom':'Exact reverse tracing found a 2026-07-09 10:12 cohort where five alts opened within 25.7 seconds and later closed 5W/0L, while the surrounding 24h entry cohort was negative. Later 1400/1700 flows added serial checks and delayed or eliminated OPENs.','cause':'The current selector compared coin quality but did not explicitly compare whether a genuine fresh-event cluster was occurring across distinct alts at the same market moment; shadow transport also performed synchronous I/O in Paper.','files_changed':['review_worker_v2.017.py','paper_bot_v2.017.py','coinbot_main_v2_13_2017.py'],'new_mainline':'Drain Paper async spool in Review and compare the same all-alt final-passed pool with baseline GLOBAL_RELATIVE versus GLOBAL_RELATIVE_SYNC, where distinct-alt fresh-event density at 30/60/120 seconds is one extra relative group only. No hard block, no strategy/source bonus, no extra market fetch.','not_touched':['actual candidate/S1 flow','actual Paper selector','actual OPEN/cycle limits','trigger/invalid/target','RR/room/chase/cost hard safety','actual exit/trailing','existing v2010-v2016 shadow state and append ledgers','protected ledgers','auto-buy OFF'],'remaining':'Collect forward 3h/6h/12h/exact CLOSED across 8 comparison books; prove queue_drop/spool_error 0 and compare baseline vs sync without Paper timing regression before any promotion.','auto_buy':False})
        _v2010_append_jsonl(BASE_DIR/'ledger'/'issue_ledger_events.jsonl',{'schema':'coinbot_single_work_ledger_v870','event_type':'ISSUE','issue_id':'SYNC-FRESH-TOP10-2017','status':'CHECK','title':'동시에 새로 움직이는 알트 묶음 TOP10 비교 Shadow','detail':'전체 알트 기본 상대선발과 동시 fresh-event 밀집 정보 추가판을 같은 후보판으로 비교. 차단/본선변경 없음.','version':'v2017','created_ts':ts,'created_at':text,'created_text':text,'auto_buy':False})
        marker.parent.mkdir(parents=True,exist_ok=True); marker.write_text(text,encoding='utf-8')
    except Exception: pass

try: _v2017_review_issue_once()
except Exception: pass


# =============================================================================
# review_worker v2.019: exact TOP10 ranking + virtual selection-order record only.
# - Preserve the v2017 selector formula and all existing Shadow books/state.
# - Append one exact rank snapshot whenever a selector/cycle ranking state changes.
# - Append the Shadow virtual selection order with rank-at-selection.
# - No Paper hot-path, actual selector, OPEN, exit, or auto-buy change.
# =============================================================================
def _v2019_review_issue_once() -> None:
    marker=BASE_DIR/'runtime'/'v2019_top10_exact_rank_selection_order.seeded'
    if marker.exists(): return
    ts=time.time(); text=now_text(ts)
    try:
        _v2010_append_jsonl(BASE_DIR/'runtime'/'change_verify_ledger.jsonl',{'schema':'change_verify_ledger_v870','change_id':'v2019-top10-exact-rank-order-record-001','issue_id':'TOP10-EXACT-RANK-ORDER-2019','version':'v2019','verify_result':'CHECK','created_ts':ts,'created_at':text,'created_text':text,'writer':'review_v2019_lifecycle_writer','symptom':'The 2026-07-09 success-five reverse trace could prove candidate creation timing and OPEN order, but historical rows did not seal the full selector ranking or Shadow selection order at the decision snapshot.','cause':'v2017 computes ranked candidate lists and virtual selections in memory, but its canonical events do not preserve the complete ranking snapshot plus rank-at-selection/order in one exact append-only trace.','files_changed':['review_worker_v2.019.py'],'new_mainline':'Keep the v2017 GLOBAL_RELATIVE and GLOBAL_RELATIVE_SYNC formulas unchanged. Review appends exact RANK_SNAPSHOT events for the full selector order and VIRTUAL_SELECT_ORDER events with rank-at-selection and selected order. Existing Shadow state and ledgers continue without reset.','not_touched':['Paper hot path or async spool transport','GLOBAL_RELATIVE formula','GLOBAL_RELATIVE_SYNC formula','strategy/source weighting','actual candidate/S1 flow','actual Paper selector','actual OPEN/cycle limits','trigger/invalid/target/RR/cost safety','actual exit/trailing','existing Shadow ledgers/state','auto-buy OFF'],'remaining':'Server prove Review v2.019 runtime/hash, new rank/order ledger append growth, score_formula_changed false, existing TOP10 candidate/cycle growth continues, and queue_drop/spool_error remain 0.','auto_buy':False})
        _v2010_append_jsonl(BASE_DIR/'ledger'/'issue_ledger_events.jsonl',{'schema':'coinbot_single_work_ledger_v870','event_type':'ISSUE','issue_id':'TOP10-EXACT-RANK-ORDER-2019','status':'CHECK','title':'TOP10 당시 전체순위와 Shadow 선택순서 exact 기록','detail':'선발식은 그대로 두고 같은 cycle 후보 전체 순위와 가상 선택 순서·선택 당시 순위를 새 append-only 장부에 봉인. 기존 Shadow 삭제·초기화 없음.','version':'v2019','created_ts':ts,'created_at':text,'created_text':text,'auto_buy':False})
        marker.parent.mkdir(parents=True,exist_ok=True); marker.write_text(text,encoding='utf-8')
    except Exception: pass

try: _v2019_review_issue_once()
except Exception: pass

def _v2024_review_shadow_source_link_issue_once() -> None:
    marker=BASE_DIR/'runtime'/'v2024_shadow_source_link_repair_review.seeded'
    if marker.exists(): return
    ts=now_ts(); text=now_text(ts)
    try:
        _v2010_append_jsonl(BASE_DIR/'runtime'/'change_verify_ledger.jsonl',{'schema':'change_verify_ledger_v870','change_id':'v2024-shadow-source-link-review-001','issue_id':'SHADOW-SOURCE-LINK-2024','version':'v2024','verify_result':'CHECK','created_ts':ts,'created_at':text,'created_text':text,'writer':'review_v2024_lifecycle_writer','symptom':'Current Shadow board showed TOP10 sync rank missing for all candidates, survival relative-strength medians as raw 0.000/0.000 despite a Feature cross-sectional rank owner, and 28 current protection rows as support source missing.','cause':'Review treated exact no-new-trigger-event as missing, did not consume the separately owned relative-strength rank, and support protection looked only in structure Shadow state even though the same OPEN row already sealed its exact invalid/structure line.','files_changed':['review_worker_v2.020.py'],'new_mainline':'TOP10 uses exact trigger-event source state: genuine events get density, proven no-new-event gets zero density, unknown remains missing, and pre-v2024 unrankable rows remain REFERENCE_ONLY. Survival reads exact sealed relative-strength rank. Protection reads the OPEN-sealed invalid structure by the same decision key before separate Shadow state.','not_touched':['actual candidate/S1/Paper selector/OPEN flow','GLOBAL_RELATIVE base formula','strategy/source weighting','trigger/invalid/target/RR/cost safety','actual exit/trailing','existing Shadow ledgers/state/history','retroactive market replay','auto-buy OFF'],'remaining':'Server prove current TOP10 source-missing 0 with sync portfolios beginning to rank, protection source_missing_current 0 when OPEN sealed invalid is present, survival new horizons use rank source without growing current source gaps, queue_drop/spool_error 0.','auto_buy':False})
        _v2010_append_jsonl(BASE_DIR/'ledger'/'issue_ledger_events.jsonl',{'schema':'coinbot_single_work_ledger_v870','event_type':'ISSUE','issue_id':'SHADOW-SOURCE-LINK-2024','status':'CHECK','title':'Shadow 자료연결 누락 0 수리','detail':'기존 exact 주인값만 연결. TOP10 새 trigger 없음=정확한 0-density, 상대강도는 Feature 전체알트 순위, 수익보호 구조선은 OPEN 봉인 invalid를 같은 decision key로 읽음. 과거 누락행은 REFERENCE_ONLY 보존.','version':'v2024','created_ts':ts,'created_at':text,'created_text':text,'auto_buy':False})
        marker.parent.mkdir(parents=True,exist_ok=True); marker.write_text(text,encoding='utf-8')
    except Exception: pass

try: _v2024_review_shadow_source_link_issue_once()
except Exception: pass

VERSION='review_worker_v2.020'
BUILD_LABEL='v2024_shadow_exact_owner_source_link_repair_2026-07-15'
MAIN_DEPLOY_VERSION=BUILD_LABEL

if __name__ == "__main__":
    if len(sys.argv) >= 2 and sys.argv[1] == '--build-dedup-index-v1013':
        target=Path(sys.argv[2]) if len(sys.argv)>=3 else REVIEW_DEDUP_DB_V1013
        try: print(json.dumps(_dedup_rebuild_v1013(target),ensure_ascii=False,separators=(',',':')))
        except Exception as exc:
            print(json.dumps({'ok':False,'error':f'{type(exc).__name__}: {exc}'},ensure_ascii=False,separators=(',',':'))); raise
    elif len(sys.argv) >= 2 and sys.argv[1] == "--compact-quality-state-v1012":
        target=Path(sys.argv[2]) if len(sys.argv) >= 3 else QUALITY_SHADOW_STATE
        try:
            print(json.dumps(_quality_compact_state_file_v1012(target),ensure_ascii=False,separators=(",",":")))
        except Exception as exc:
            print(json.dumps({"ok":False,"error":f"{exc.__class__.__name__}: {exc}"},ensure_ascii=False,separators=(",",":")))
            raise
    elif len(sys.argv) >= 2 and sys.argv[1] == '--build-good-s2-summary-v1014':
        target=Path(sys.argv[2]) if len(sys.argv)>=3 else GOOD_S2_FINAL_SUMMARY_V1014
        try: print(json.dumps(_good_s2_rebuild_summary_v1014(target),ensure_ascii=False,separators=(',',':')))
        except Exception as exc:
            print(json.dumps({'ok':False,'error':f'{type(exc).__name__}: {exc}'},ensure_ascii=False,separators=(',',':'))); raise
    else:
        main()
