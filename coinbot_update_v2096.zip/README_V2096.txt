코인봇 v2096 · 넓은 구조 무효선·수익보호 공백 검증판

목적
- 새 Shadow를 만들지 않는다.
- 현재 OPEN과 현재 epoch CLOSED의 기존 자료만 읽어, 구조 invalid가 멀어진 뒤 중간 안전막이 비어 있는지 확인한다.
- 수익보호를 단순 ON/OFF가 아니라 실제 계약 종류·arm 기준·반납 기준·현재 상태로 분리한다.
- 정확한 근거 없이 손절폭이나 수익보호 수치를 바로 변경하지 않는다.

/open_book_audit 추가
- 진입가 대비 invalid 거리: <2 / 2~4 / 4~6 / 6~10 / 10%+ / 누락
- 보호계약 종류: v2071 동적 / v2089 먼 목표 / fallback / OFF
- 실제 상태: WAIT_ARM / ARMED / PRE_ARM_TO_LOSS_GAP / ARMED_TO_LOSS_GAP / EXIT_READY
- 현재 위험 TOP: 현재손익·MFE·invalid 거리·arm·반납 기준
- 현재 OPEN 기준 최대손실 -2.5/-3/-4% 및 최고 +1/+1.5/+2% 후 0% 바닥 상한모델

/loss_defense_audit 추가
- current epoch CLOSED의 invalid 거리별 손실·MFE0·수익구간 경험 분해
- 최대손실 및 수익바닥 최종손익 상한모델
- 현재 OPEN 위험판을 같은 명령에 연결

중요 판독
- 구조 target이 멀수록 v2071 동적 수익보호 arm·반납폭도 넓어질 수 있다.
- 구조선이 논리적으로 맞아도 실제 수익보호가 늦어지는 문제는 별도다.
- 상한모델은 첫 접촉 체결가·비용·slippage를 모르는 진단값이며, 바로 본선 수치로 사용하지 않는다.

변경하지 않음
- Strategy 구조선·후보·S1/S2/S3
- trigger·invalid·target·RR·진입 조건
- Paper 청산·수익보호 공식과 기존 OPEN 계약
- v2086·v2089
- OPEN/CLOSED/decision/exact 원장
- 새 Shadow·generation·원장
- 자동매수 OFF

판정
- 로컬 py_compile·AST·synthetic import PASS
- Main public command 74개·output profile 74개 유지
- /open_book_audit와 /loss_defense_audit synthetic 실행 PASS
- 서버 적용·실제 MLK/ES/STAT 계약 판독 전 CHECK
