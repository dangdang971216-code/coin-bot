v936 적용본
- 누적 exact OPEN source를 decision state로 교체
- paper v0.931 exact 품질근거 봉인
- 적용: 가드봇 /gupgrade_bundle
- 검수: 메인봇 /batch
