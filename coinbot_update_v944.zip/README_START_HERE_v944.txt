v944 main 표시판 회귀 복구. docs 인수인계와 APPLY_AFTER_v944.txt 확인. guard 변경 없음: 1회 적용.
