# v1075 Paper v1.000 배포 검수 정정

## 증상

- Main v2.13.1074 적용 PASS
- Paper v1.000 적용 전 `paper 검수 실패`
- 기존 Paper v0.999 유지, 원장·매매 영향 없음

## 실제 원인

Guard의 `PaperVersion`은 정렬용 숫자 객체다. 파일명 `paper_bot_v1.000.py`를 숫자로 읽은 뒤 문자열로 다시 만들면서 `paper_bot_v1.0`으로 축약했다. 최종 내부 VERSION은 정확히 `paper_bot_v1.000`이었으나, 축약된 파일명 값과 비교되어 오판했다.

## 수정

- 배포 identity 비교는 정렬 객체 문자열이 아니라 파일명의 원문 version token을 사용
- `paper_bot_v1.000.py` ↔ `VERSION = paper_bot_v1.000` exact 비교
- 정렬 로직은 기존 숫자 비교 유지

## 변경하지 않은 영역

- Main v2.13.1074
- Paper v1.000 실행 코드
- Risk v0.11 / Strategy v0.992 / Review v0.995
- trigger·invalid·target·RR·spread·slippage
- 진입·청산·수익보호 계약
- OPEN/CLOSED/decision/exact 원장
- 자동매수 OFF

## 서버 닫는 기준

- Paper target/internal VERSION exact PASS
- Paper active alias/target hash 일치
- Paper runtime VERSION/BUILD/PID/writer 단일화
- Risk–Paper READY/signature true
- exact duplicate/key_missing/unlinked 0/0/0
- 신규 runtime 오류 0
