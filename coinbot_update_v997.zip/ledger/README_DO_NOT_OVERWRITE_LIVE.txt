Release seed only. Never overwrite live OPEN/CLOSED/trade_log/decision/change/issue ledgers.
