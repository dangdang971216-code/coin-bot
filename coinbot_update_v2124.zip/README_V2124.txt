v2124: Guard 원장 교체 uid/gid/mode 보존 및 Paper 권한 복구, Paper 상태/reset의 중복 retention 제거, Strategy 1.10% invalid 중복 선필터 제거. Paper 실제 예정진입가 1.073% 최종안전 기준은 그대로 유지. LOCAL DONE / SERVER CHECK / 자동매수 OFF.
