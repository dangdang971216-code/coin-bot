from pathlib import Path
import ast, importlib.util, os, tempfile, subprocess, sys, time, json
ROOT=Path(__file__).resolve().parent

def load(name,file,tmp):
    os.environ['TRADING_BOT_DIR']=tmp
    os.environ.setdefault('GUARD_BOT_TOKEN','test-token')
    os.environ.setdefault('GUARD_CHAT_ID','1')
    spec=importlib.util.spec_from_file_location(name,ROOT/file)
    m=importlib.util.module_from_spec(spec); spec.loader.exec_module(m); return m

# compile + duplicate top-level defs
for f in ROOT.glob('*.py'):
    tree=ast.parse(f.read_text())
    names={}; dups=[]
    for n in tree.body:
        if isinstance(n,(ast.FunctionDef,ast.AsyncFunctionDef,ast.ClassDef)):
            names[n.name]=names.get(n.name,0)+1
    dups=[k for k,v in names.items() if v>1]
    assert not dups,(f.name,dups[:20])

with tempfile.TemporaryDirectory() as td:
    review=load('review1121','review_worker_v0.999.py',td)
    assert review.VERSION=='review_worker_v0.999'
    review._acquire_review_singleton_v1121()
    assert review.REVIEW_SINGLETON_STATUS_V1121.exists()
    st=json.loads(review.REVIEW_SINGLETON_STATUS_V1121.read_text())
    assert st['lock_held'] and st['lock_pid']==os.getpid()
    # second process must fail 73 while first lock held
    code=f"""import os,importlib.util; os.environ['TRADING_BOT_DIR']={td!r}; p={str(ROOT/'review_worker_v0.999.py')!r}; s=importlib.util.spec_from_file_location('r2',p); m=importlib.util.module_from_spec(s); s.loader.exec_module(m); m._acquire_review_singleton_v1121()"""
    cp=subprocess.run([sys.executable,'-c',code],capture_output=True,text=True)
    assert cp.returncode==73,(cp.returncode,cp.stdout,cp.stderr)
    review._release_review_singleton_v1121()

with tempfile.TemporaryDirectory() as td:
    t=Path(td)
    (t/'paper_bot_closed.jsonl').write_text('',encoding='utf-8')
    (t/'paper_bot_open.json').write_text('{}',encoding='utf-8')
    risk=load('risk1121','risk_worker_v0.13.py',td)
    risk.run_once()
    st=json.loads((t/'clean_risk_status.json').read_text())
    hb=st.get('risk_semantic_heartbeat_v1121') or {}
    assert hb.get('state') in {'CURRENT_AFTER_COMMIT','CURRENT_EVENT_IDLE'}
    assert hb.get('semantic_current') is True

with tempfile.TemporaryDirectory() as td:
    paper=load('paper1121','paper_bot_v1.019.py',td)
    assert paper.VERSION=='paper_bot_v1.019'
    assert paper.run_cycle.__name__=='run_cycle'
    assert paper.run_exact_exit_monitor.__name__=='run_exact_exit_monitor'
    assert paper.write_status.__name__=='write_status'
    assert paper.globals if False else True
    # active wrappers should bypass the v1113 measurement wrappers
    assert paper.run_cycle.__code__.co_name=='run_cycle__v1121_no_heavy_probe'
    assert paper.run_exact_exit_monitor.__code__.co_name=='run_exact_exit_monitor__v1121_no_heavy_probe'
    assert paper.write_status.__code__.co_name=='write_status__v1121_no_heavy_probe'

with tempfile.TemporaryDirectory() as td:
    guard=load('guard1121','backga_guard_bot_v2_5_169.py',td)
    now=time.time()
    status={'updated_ts':now,'phase':'refreshing_source_v1121','cached':False,'loss_reentry_contract_ready_v1057':True,
            'risk_semantic_heartbeat_v1121':{'updated_ts':now,'state':'REFRESHING_SOURCE','previous_contract_ready':True}}
    root=guard._ops_risk_root_cause_v1106(status,now)
    assert root['diagnosis_state']=='PROVEN_EVENT_DRIVEN_IDLE',root

print(json.dumps({'ok':True,'tests':['compile','no_duplicate_top_level_defs','review_singleton_second_process_exit73','clean_quality_epoch','risk_semantic_heartbeat','guard_refresh_classifier','paper_heavy_probe_bypassed']},ensure_ascii=False))
