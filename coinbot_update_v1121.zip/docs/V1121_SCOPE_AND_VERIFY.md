# v1121 scope and verification

## Goal
Restore trustworthy forward quality-shadow sampling after v1120 without changing trading rules.

## Changes
1. Review single writer
   - Adds a process-level nonblocking flock.
   - One Review PID owns `review_append_dedup_v1013.sqlite3` and quality-shadow writers.
   - A second Review process exits with code 73.
2. Clean quality epoch
   - Existing rows and ledgers are preserved.
   - Rows created before the v1121 singleton boot are marked as a contaminated prior epoch and excluded from the new policy comparison.
3. Risk semantic freshness
   - Publishes current/event-idle/refresh-in-progress heartbeat evidence.
   - Guard no longer reports a normal bounded refresh as stale.
   - Paper's exact CLOSED signature validation remains unchanged.
4. Paper memory path
   - Removes the measurement-only v1113 smaps/helper probe from active cycle and exit-monitor calls.
   - Keeps safe-boundary GC/malloc_trim and all trading/ledger contracts.
5. Capacity evidence
   - Existing Paper raw/strict OPEN evidence remains canonical; no OPEN or cycle limit change.

## Explicitly unchanged
- Candidate quality formula and thresholds
- Rank formula
- trigger / invalid / target
- actual-entry RR / room / chase / spread / slippage / costs
- OPEN 30 / cycle 3
- exit contract
- OPEN/CLOSED/decision/performance ledgers
- auto-buy OFF

## Server DONE proof
- Review runtime PID exactly one and `MULTI_WRITER` for review SQLite is zero.
- Review reports version `review_worker_v0.999` and a fresh `quality_policy_epoch_v1121`.
- Risk edges to Strategy and Paper are NORMAL with fresh semantic evidence.
- Paper RSS drops after restart and does not show rapid sustained growth; v1113 active probe is false.
- Paper funnel accounting remains exact and new execution errors are zero.
- Runtime mismatch is zero.
