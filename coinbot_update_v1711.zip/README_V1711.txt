v1711 identity tail cleanup for main/guard. Paper/Strategy v1.710 unchanged. Auto-buy OFF. No trading rules changed.
