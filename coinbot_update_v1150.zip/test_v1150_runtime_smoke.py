from pathlib import Path
import ast, json, py_compile, tempfile
ROOT=Path(__file__).resolve().parent
files=[ROOT/'strategy_worker_v1.018.py',ROOT/'paper_bot_v1.027.py',ROOT/'backga_guard_bot_v2_5_188.py']
for f in files:
    py_compile.compile(str(f),doraise=True)
# Exact changed-function envelope check.
def funcs(path):
    t=ast.parse(path.read_text(encoding='utf-8')); return {n.name for n in ast.walk(t) if isinstance(n,ast.FunctionDef)}
s=files[0].read_text(encoding='utf-8')
assert "required_steps': ['S1_HOLD', 'CANDIDATE_SNAPSHOT', 'PRIORITY_REQUESTS']" in s
assert "complete': str(state or '').upper() == 'NORMAL'" in s
assert "pipeline_cycle_id_consistent_v1150" in s
p=files[1].read_text(encoding='utf-8')
assert "return [], stats, []" in p and "candidate_pipeline_blocked_v1150" in p
g=files[2].read_text(encoding='utf-8')
assert "pipeline_state_v1150='FAIL'" in g and "pipeline_state_v1150='PARTIAL'" in g
print(json.dumps({'status':'PASS','compiled':[x.name for x in files],'zero_candidate_pipeline_supported':True,'auto_buy':False},ensure_ascii=False))
