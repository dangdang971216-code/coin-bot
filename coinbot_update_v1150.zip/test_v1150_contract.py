from pathlib import Path
import ast, hashlib, json, tempfile

ROOT=Path(__file__).resolve().parent
S=ROOT/'strategy_worker_v1.018.py'; P=ROOT/'paper_bot_v1.027.py'; G=ROOT/'backga_guard_bot_v2_5_188.py'
texts={'strategy':S.read_text(encoding='utf-8'),'paper':P.read_text(encoding='utf-8'),'guard':G.read_text(encoding='utf-8')}
assert 'VERSION = "strategy_worker_v1.018"' in texts['strategy']
assert "VERSION = 'paper_bot_v1.027'" in texts['paper']
assert 'guard_v2.5.188_candidate_pipeline_completion_owner_v1150_2026-06-30' in texts['guard']
for token in ['S1_HOLD_COMMITTED','CANDIDATE_COMMITTED','all_required_commits_v1150','candidate_pipeline_cycle_id_v1150','candidate_commit_id_v1150']:
    assert token in texts['strategy'], token
assert "'candidate_pipeline_cycle_id_v1150'" in texts['strategy']
assert 'strategy_candidate_pipeline_ready_v1150' in texts['paper']
assert 'candidate_pipeline_blocked_v1150' in texts['paper']
assert 'CANDIDATE_PIPELINE_INCOMPLETE' in texts['guard']
assert 'plain_location' in texts['guard'] and '신규 진입을 자동 보류' in texts['guard']
assert "'auto_buy': False" in texts['paper'] and "'auto_buy': False" in texts['strategy']

# Verify core entry/quality/trigger functions are byte-for-byte semantic AST matches to v1149.
expected={"apply_swing_entry_gate": "6864270ce18984425899cb26c549c38a7d3aa4182a648e7a75e96c1b45af406c", "_swing_quality_gate": "1d97ab0738d5eb0bab21979aecce9161603c8dc166c4c03d4549758f21ee00f1", "_v554_apply_entry_plan": "81b6add7397a4cb5887f51d3d10593f91c02933ffaa17f3b91b9d95b10d7442c", "seal_canonical_candidate_keys": "1156566e4a6232a3a6fef3c2cda793c6f2497c227606c56d37758b922196491c", "_v620_trigger_gate": "f493cb39378d1d40f2b50f740597f74bb0ef3aa6f3d3ac5dbbc1f368aadcf7d1", "_v732_trigger_state_for_hold": "ad61b299ee6b2b69055acb839f04d7776331064a3ebde2b4dead490f2e305ab1"}
t=ast.parse(texts['strategy']); found={}
for n in ast.walk(t):
    if isinstance(n,(ast.FunctionDef,ast.AsyncFunctionDef)) and n.name in expected:
        found[n.name]=hashlib.sha256(ast.dump(n,include_attributes=False).encode()).hexdigest()
assert found==expected,(found,expected)

# Dynamic Paper fail-closed gate test using the real extracted helper.
pt=ast.parse(texts['paper'])
node=next(n for n in pt.body if isinstance(n,ast.FunctionDef) and n.name=='strategy_candidate_pipeline_ready_v1150')
mod=ast.Module(body=[node],type_ignores=[]); ast.fix_missing_locations(mod)
with tempfile.TemporaryDirectory() as td:
    base=Path(td); now=1000.0
    files={'s1_hold':base/'paper_s1_hold_cache.json'}
    def load_json(path,default):
        try:return json.loads(Path(path).read_text(encoding='utf-8'))
        except Exception:return default
    def fnum(v,default=0.0):
        try:return float(v)
        except Exception:return default
    ns={'Dict':dict,'Any':object,'BASE_DIR':base,'FILES':files,'STRATEGY_PIPELINE_COMMIT_V1150':base/'strategy_candidate_pipeline_commit_v1150.json','now_ts':lambda:now,'load_json':load_json,'fnum':fnum}
    exec(compile(mod,'paper_helper','exec'),ns)
    cid='strategy-1-999'; commit='candidate-abc'
    (base/'strategy_candidate_pipeline_commit_v1150.json').write_text(json.dumps({'state':'NORMAL','complete':True,'cycle_id':cid,'candidate_commit_id':commit,'updated_ts':950,'all_required_commits_v1150':True}),encoding='utf-8')
    files['s1_hold'].write_text(json.dumps({'candidate_pipeline_cycle_id_v1150':cid,'count':0,'rows':[]}),encoding='utf-8')
    (base/'clean_strategy_paper_latest_writer_status.json').write_text(json.dumps({'candidate_snapshot_scope':{'pipeline_cycle_id_v1150':cid,'rows_written':0}}),encoding='utf-8')
    (base/'clean_strategy_priority_requests.json').write_text(json.dumps({'candidate_pipeline_cycle_id_v1150':cid,'candidate_commit_id_v1150':commit,'request_count':0}),encoding='utf-8')
    ok=ns['strategy_candidate_pipeline_ready_v1150']({'candidate_ttl_sec':120})
    assert ok['ready'] is True and ok['state']=='NORMAL',ok
    (base/'clean_strategy_priority_requests.json').write_text(json.dumps({'candidate_pipeline_cycle_id_v1150':'wrong','candidate_commit_id_v1150':commit}),encoding='utf-8')
    bad=ns['strategy_candidate_pipeline_ready_v1150']({'candidate_ttl_sec':120})
    assert bad['ready'] is False and 'priority_cycle_match' in bad['failed_checks'],bad
print(json.dumps({'status':'PASS','core_strategy_functions_unchanged':list(expected),'paper_fail_closed_normal_case':True,'paper_fail_closed_mismatch_case':True},ensure_ascii=False))
