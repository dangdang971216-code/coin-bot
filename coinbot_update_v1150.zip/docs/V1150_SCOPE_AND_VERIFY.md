# v1150 범위·검수

## 정상 증명
1. strategy_candidate_pipeline_commit_v1150.json state=NORMAL
2. S1 hold, candidate snapshot, priority request의 cycle_id 동일
3. candidate commit_id가 priority와 동일
4. row/count 검증 통과
5. Paper pipeline gate NORMAL
6. Guard 쉬운 상태에서 후보 배관 정상

## 실패 증명
- 어느 단계에서 실패했는지 failed_step 표시
- Paper는 신규 후보 접수 보류
- 이전 파일을 최신 정상으로 간주하지 않음

## 서버 검수
Guard: /gops_refresh, /gdeploy
Main: /flow_map_full, /candidate_standard, /change_verify, /issue_ledger, /errorlog
