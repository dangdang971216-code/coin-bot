# v1150 작업 잠금

- 증상: Strategy heartbeat와 S1 파일은 갱신됐지만 전체 후보목록·priority 요청이 장시간 멈춰 Paper 후보가 stale로 폐기됨.
- 실제 원인: S1 이후 경로가 중단돼도 각 산출물이 동일 cycle에서 끝까지 commit됐는지 증명·차단하는 계약이 없었음.
- owner: Strategy pipeline writer → Paper fail-closed intake → Guard pipeline state.
- 변경 파일: Strategy, Paper, Guard.
- 새 본선: S1 Hold → 전체 후보 snapshot → priority requests가 같은 cycle_id/candidate_commit_id로 완료되어야 NORMAL.
- 실패 처리: 불일치·누락·stale이면 Paper 신규 후보 0건으로 보류하고 Guard에 쉬운 고장 위치·영향을 기록.
- 변경하지 않음: Gate/rank, trigger/invalid/target, RR/TTL 수치, exit/trailing, OPEN 30/cycle 3, 원장, 자동매수 OFF.
- 서버 검수 전 상태: CHECK.
