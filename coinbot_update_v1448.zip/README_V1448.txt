v1448 Paper exit-defense exact apply for new OPEN only. Auto-buy OFF. Existing OPEN contracts preserved.
