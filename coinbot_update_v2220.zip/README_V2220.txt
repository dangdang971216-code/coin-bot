코인봇 v2220 · 최근 7일 우선 Review + 전체 날짜증분 + 배관/손실방어/1분 업그레이드 수리

현재 목적
- v2219 재배치 역할별 중요도 분석은 그대로 유지한다.
- Review 재시작 때마다 약 4.5GB 전체 원장을 반복 스캔하는 구조를 날짜 index 파생 cache로 바꾼다.
- 최근 7일을 먼저 보여주되, 전체 누적이 끝나기 전에는 중요도 확정이나 본선 적용을 금지한다.
- 숫자와 commit이 일치하는데 흐름판이 CHECK인 표시 오류, OPEN이 있는데 -2% 검사 0회로 남는 오류를 함께 고친다.
- /gupgrade_bundle은 중요한 검사를 유지하면서 불필요한 중복만 제거해 성공/실패를 1분 안에 끝내는 계약으로 바꾼다.

Review
- 첫 적용: 최근 7일 tail을 먼저 읽어 결과를 표시하고, 기존 전체 원장은 한 번만 날짜 cache로 백필한다.
- 최근 tail이 읽기 상한 때문에 완전하지 않으면 PARTIAL로 표시하고 판단에 쓰지 않는다.
- 전체 백필 완료 뒤에는 ledger inode/offset 이후 추가 byte만 읽는다.
- 원본 exact 원장은 삭제·축소·재작성하지 않는다. SQLite는 파생 cache이며 손상 시 원본에서 재구축한다.

Main
- commit/generation/통과/S1/Paper 행수가 모두 같고 receipt가 명시적 실패가 아니면 PASS.
- FAIL/ERROR/CHECK/PARTIAL/REJECTED/STALE receipt는 숫자가 같아도 CHECK.
- 최근 7일 우선판은 화면 첫줄부터 임시판으로 표시하고 전체 READY 전 본선 적용을 금지한다.

Paper
- 모든 override 로딩 후 기존 canonical -2% exact OPEN monitor를 시작 시 1회 즉시 실행한다.
- exact OPEN, 성과 OPEN, checked 개수를 직접 비교한다.
- -2% 수치, target 우선, 기존 invalid, 재진입 key/trigger, CLOSED→decision→OPEN 순서는 변경하지 않는다.

Guard
- compile, manifest/hash, 원자교체, 변경 서비스 PID/version/hash, Paper writer, Main polling-ready를 유지한다.
- 변경 없는 재시작, 같은 파일 복사, 긴 고정대기, 중복알림, 전체 원장 검사를 제거한다.
- 55초 목표/60초 상한. 증명 미완료면 PASS로 숨기지 않고 CHECK/FAIL.
- 정상 PASS에는 핵심 runtime 통합검수가 포함되므로 /grelease_verify가 필요 없다. CHECK/FAIL일 때만 사용한다.

변경하지 않음
- Strategy v2.079, Core v2177와 역할계약 hash
- 상승예측 본선 식·가중치·양수선
- 후보·S1·trigger·invalid·target·RR·실제 진입/청산 수치
- 기존 v2213 Shadow, 과거 exact/거래원장, 자동매수 OFF
