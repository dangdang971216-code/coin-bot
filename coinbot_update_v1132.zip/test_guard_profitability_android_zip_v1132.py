#!/usr/bin/env python3
from __future__ import annotations
import hashlib, importlib.util, json, os, pathlib, shutil, tempfile, zipfile
SOURCE=pathlib.Path(__file__).with_name('backga_guard_bot_v2_5_177.py')
def sha(path):
    h=hashlib.sha256()
    with path.open('rb') as f:
        for chunk in iter(lambda:f.read(1024*1024), b''): h.update(chunk)
    return h.hexdigest()
def main():
    with tempfile.TemporaryDirectory() as td:
        root=pathlib.Path(td); bot=root/'bot'; bot.mkdir(); received=root/'received'; received.mkdir()
        line=b'{"pos_id":"abc","ticker":"AAA","pnl_pct":-1.2345,"reason":"structure_invalid"}\n'
        closed=line*((34*1024*1024)//len(line)+1)
        files={
            'paper_bot_closed.jsonl':closed,
            'paper_bot_open.json':json.dumps({'positions':[{'ticker':'AAA','invalid':98,'target':102}]}).encode(),
            'paper_decision_state_v926.json':json.dumps({'rows':[{'decision_key':'d1','state':'CLOSED'}]}).encode(),
            'canonical_performance_snapshot_v987.json':json.dumps({'closed_count':2}).encode(),
            'paper_bot_trade_detail_v798.jsonl':b'{"event":"open"}\n{"event":"close"}\n',
            'paper_bot_control.json':json.dumps({'auto_buy':False,'max_open':30}).encode(),
        }
        for n,d in files.items():(bot/n).write_bytes(d)
        before={n:(sha(bot/n),(bot/n).stat().st_size,(bot/n).stat().st_mtime_ns) for n in files}
        os.environ.update(GUARD_BOT_TOKEN='dummy',GUARD_CHAT_ID='123',BOT_DIR=str(bot))
        spec=importlib.util.spec_from_file_location('guard_v1132',SOURCE); mod=importlib.util.module_from_spec(spec); spec.loader.exec_module(mod)
        sent=[]
        def fake_send(chat_id,path,caption=''):
            target=received/path.name; shutil.copy2(path,target); sent.append(target); return True,'MOCK_OK'
        mod.telegram_send_document_v1129=fake_send; mod.progress_notify=lambda text:None
        text=mod.gexport_profitability_text_v1129(); assert 'DONE' in text,text; assert len(sent)==1
        assert before=={n:(sha(bot/n),(bot/n).stat().st_size,(bot/n).stat().st_mtime_ns) for n in files}
        assert not list(bot.glob(mod.GUARD_EXPORT_TMP_PREFIX_V1129+'*'))
        result=json.loads((bot/mod.GUARD_EXPORT_LAST_RESULT_V1129).read_text())
        assert result['archive']['compression']=='ZIP_DEFLATED_STANDARD',result
        assert result['archive']['compression_method_ids'] in ([8],[0,8]),result
        archive=sent[0]
        with zipfile.ZipFile(archive) as z:
            assert z.testzip() is None
            infos=z.infolist(); assert infos
            assert all(i.compress_type in (zipfile.ZIP_STORED,zipfile.ZIP_DEFLATED) for i in infos)
            assert all(not (i.flag_bits & 1) for i in infos)
            assert all(i.compress_type != zipfile.ZIP_LZMA for i in infos)
            assert 'data/paper_bot_trade_log.jsonl' in z.namelist()
            manifest=json.loads(z.read('EXPORT_MANIFEST.json'))
            assert manifest['zip_method']==8 and manifest['encrypted'] is False
        issue=(bot/'issue_ledger.jsonl').read_text(); change=(bot/'change_verify_ledger.jsonl').read_text()
        assert 'GUARD-PROFITABILITY-EXPORT-1132' in issue
        assert 'v1132-guard-android-standard-zip-server-proof-001' in change
        print(json.dumps({'ok':True,'zip_mb':round(archive.stat().st_size/1024/1024,2),'method_ids':result['archive']['compression_method_ids'],'crc':'PASS','original_unchanged':True,'temp_clean':True},sort_keys=True))
if __name__=='__main__':main()
