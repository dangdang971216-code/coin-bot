# V1132 scope and verify

- Fix Android/Samsung extraction failure caused by ZIP-LZMA method 14.
- Produce one classic ZIP DEFLATED archive (method 8).
- Pre-send CRC, compression-method and encryption checks.
- Successful send deletes temporary export files; failed send retains the temporary ZIP and reports the path.
- No trading, quality, OPEN limit, cycle limit, or exit contract changes.
