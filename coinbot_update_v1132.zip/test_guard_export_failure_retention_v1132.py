#!/usr/bin/env python3
from __future__ import annotations
import importlib.util, json, os, pathlib, tempfile
SOURCE=pathlib.Path(__file__).with_name('backga_guard_bot_v2_5_177.py')
def main():
    with tempfile.TemporaryDirectory() as td:
        bot=pathlib.Path(td)
        for name,data in {
            'paper_bot_closed.jsonl':b'{}\n','paper_bot_open.json':b'{}','paper_decision_state_v926.json':b'{}',
            'canonical_performance_snapshot_v987.json':b'{}','paper_bot_trade_log.jsonl':b'{}\n','paper_bot_control.json':b'{}'
        }.items():(bot/name).write_bytes(data)
        os.environ.update(GUARD_BOT_TOKEN='dummy',GUARD_CHAT_ID='123',BOT_DIR=str(bot))
        spec=importlib.util.spec_from_file_location('g',SOURCE); mod=importlib.util.module_from_spec(spec); spec.loader.exec_module(mod)
        mod.progress_notify=lambda text:None
        mod.telegram_send_document_v1129=lambda *a,**k:(False,'MOCK_FAIL')
        text=mod.gexport_profitability_text_v1129(); assert 'PARTIAL' in text or '실패' in text
        result=json.loads((bot/mod.GUARD_EXPORT_LAST_RESULT_V1129).read_text())
        p=pathlib.Path(result['retained_temp_path']); assert p.exists(),result
        print(json.dumps({'ok':True,'retained_on_send_failure':True,'path_exists':True},sort_keys=True))
if __name__=='__main__':main()
