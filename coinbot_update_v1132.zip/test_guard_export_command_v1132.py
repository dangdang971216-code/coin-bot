#!/usr/bin/env python3
from __future__ import annotations
import importlib.util, os, pathlib, tempfile
SOURCE=pathlib.Path(__file__).with_name('backga_guard_bot_v2_5_177.py')
def main():
    with tempfile.TemporaryDirectory() as td:
        os.environ.update(GUARD_BOT_TOKEN='dummy',GUARD_CHAT_ID='123',BOT_DIR=td)
        spec=importlib.util.spec_from_file_location('g',SOURCE); mod=importlib.util.module_from_spec(spec); spec.loader.exec_module(mod)
        mod.gexport_profitability_text_v1129=lambda:'EXPORT_SENTINEL'
        assert mod.handle_single_command('/gexport_profitability')=='EXPORT_SENTINEL'
        assert '/gexport_profitability' in mod.help_text()
        print('PASS')
if __name__=='__main__':main()
