#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
paper_bot_v0.129_score_cache_version_stamp_closed_count_2026-05-25

목적:
- v0.50/v389/v397 계열의 무거운 paper runtime을 더 이상 타지 않는다.
- paper 실행기는 S1 후보 읽기 → OPEN → 기존 OPEN 청산 → 장부 저장 → 알림만 담당한다.
- OPEN/CLOSED/trade_log 장부는 보존하고, 전체 CLOSED 재계산/복기/score full 계산은 실행 루프에서 제외한다.
- v416/v0.127: paper OPEN 직전 최종 안전문을 직접 확인하고, 약한 체결/넓은 스프레드/미끄러짐/무반응 후보를 장부 OPEN 전에 차단한다.
"""

from __future__ import annotations

import json
import os
import signal
import sys
import time
import traceback
import re
import urllib.parse
import urllib.request
from collections import Counter, deque
from pathlib import Path
from typing import Any, Dict, Iterable, List, Optional, Tuple

VERSION = "paper_bot_v0.129"
BUILD_LABEL = "v430_score_cache_current_main_stamp_closed_count_2026-05-25"
BASE_DIR = Path(__file__).resolve().parent

FILES: Dict[str, Path] = {
    "paper_latest": BASE_DIR / "paper_candidates_latest.jsonl",
    "paper_archive": BASE_DIR / "paper_candidates.jsonl",
    "paper_merged": BASE_DIR / "paper_candidates_handoff_merged.jsonl",
    "open": BASE_DIR / "paper_bot_open.json",
    "closed": BASE_DIR / "paper_bot_closed.jsonl",
    "status": BASE_DIR / "paper_bot_status.json",
    "control": BASE_DIR / "paper_bot_control.json",
    "pid": BASE_DIR / "paper_bot.pid",
    "trace": BASE_DIR / "paper_bot_candidate_handoff_trace.json",
    "handoff_status": BASE_DIR / "paper_bot_candidate_handoff_status.json",
    "score": BASE_DIR / "paper_bot_score_cache.json",
    "error": BASE_DIR / "paper_bot_error.log",
    "log": BASE_DIR / "paper_bot.log",
}

DEFAULT_CONTROL: Dict[str, Any] = {
    "running": True,
    "loop_seconds": 8,
    "open_monitor_interval_sec": 2.0,
    "max_open_strict": 0,
    "max_new_per_cycle": 0,
    "new_open_paused": False,
    "open_trade_ready_only": True,
    "notify_on_strict_open": True,
    "notify_on_strict_close": True,
    "notify_open_min_score": 4.45,
    "notify_open_require_micro_fresh": True,
    "notify_open_require_ws_fresh": False,
    "preopen_micro_recheck": True,
    "preopen_micro_urgent_ttl_sec": 35,
    "block_same_ticker_open": True,
    "candidate_ttl_sec": 120,
    "candidate_read_max_lines": 800,
    "consume_latest_scan_only": True,
    "write_score_cache": True,
    "latest_scan_window_sec": 8,
    "fee_pct_roundtrip": 0.10,
    "take_profit_pct": 1.20,
    "protect_trigger_pct": 0.70,
    "protect_floor_pct": 0.30,
    "stop_loss_pct": -0.55,
    "slow_minutes": 20,
    "slow_peak_under_pct": 0.25,
    "time_exit_minutes": 15,
}

TOKEN = os.getenv("PAPER_BOT_TOKEN", os.getenv("TELEGRAM_TOKEN", "")).strip()
ALLOWED_CHAT_ID = (
    os.getenv("PAPER_BOT_ALLOWED_CHAT_ID", "").strip()
    or os.getenv("PAPER_BOT_CHAT_ID", "").strip()
    or os.getenv("CHAT_ID", "").strip()
    or os.getenv("GUARD_CHAT_ID", "").strip()
)
NOTIFY_CHAT_ID = os.getenv("PAPER_BOT_NOTIFY_CHAT_ID", "").strip() or ALLOWED_CHAT_ID

_STOP = False
_STOP_REASON = "running"
_STARTED_TS = time.time()
_LAST_PRICE_CACHE: Dict[str, Any] = {"ts": 0.0, "prices": {}}
_LAST_STATUS: Dict[str, Any] = {}
_LAST_CLOSED_COUNT_CACHE: Dict[str, Any] = {"ts": 0.0, "count": 0}
_TG_OFFSET = 0


def now_ts() -> float:
    return time.time()


def iso_ts(ts: Optional[float] = None) -> str:
    import datetime as _dt
    return _dt.datetime.fromtimestamp(ts or now_ts()).strftime("%Y-%m-%d %H:%M:%S")


def fnum(*vals: Any, default: float = 0.0) -> float:
    for v in vals:
        try:
            if v is None or v == "":
                continue
            if isinstance(v, str):
                v = v.replace(",", "").replace("%", "").strip()
            return float(v)
        except Exception:
            continue
    return default


def log(msg: str) -> None:
    try:
        with FILES["log"].open("a", encoding="utf-8") as f:
            f.write(f"[{iso_ts()}] {msg}\n")
    except Exception:
        pass


def log_error(where: str, exc: BaseException) -> None:
    try:
        with FILES["error"].open("a", encoding="utf-8") as f:
            f.write(f"[{iso_ts()}] {where}: {type(exc).__name__}: {exc}\n")
            f.write(traceback.format_exc() + "\n")
    except Exception:
        pass


def atomic_write_text(path: Path, text: str) -> None:
    tmp = path.with_suffix(path.suffix + ".tmp")
    tmp.write_text(text, encoding="utf-8")
    os.replace(tmp, path)


def save_json(path: Path, obj: Any) -> None:
    try:
        atomic_write_text(path, json.dumps(obj, ensure_ascii=False, separators=(",", ":")))
    except Exception as exc:
        log_error(f"save_json:{path.name}", exc)


def load_json(path: Path, default: Any = None) -> Any:
    try:
        if not path.exists():
            return default
        return json.loads(path.read_text(encoding="utf-8", errors="ignore"))
    except Exception as exc:
        log_error(f"load_json:{path.name}", exc)
        return default


def append_jsonl(path: Path, obj: Dict[str, Any]) -> None:
    try:
        with path.open("a", encoding="utf-8") as f:
            f.write(json.dumps(obj, ensure_ascii=False, separators=(",", ":")) + "\n")
    except Exception as exc:
        log_error(f"append_jsonl:{path.name}", exc)


def tail_lines(path: Path, max_lines: int) -> List[str]:
    if not path.exists():
        return []
    dq: deque[str] = deque(maxlen=max_lines)
    try:
        with path.open("r", encoding="utf-8", errors="ignore") as f:
            for line in f:
                if line.strip():
                    dq.append(line.rstrip("\n"))
    except Exception as exc:
        log_error(f"tail_lines:{path.name}", exc)
    return list(dq)


def read_jsonl_tail(path: Path, max_lines: int) -> List[Dict[str, Any]]:
    out: List[Dict[str, Any]] = []
    for line in tail_lines(path, max_lines):
        try:
            row = json.loads(line)
            if isinstance(row, dict):
                out.append(row)
        except Exception:
            continue
    return out


def line_count_cached(path: Path, ttl: float = 60.0) -> int:
    ts = now_ts()
    if ts - float(_LAST_CLOSED_COUNT_CACHE.get("ts") or 0.0) < ttl:
        return int(_LAST_CLOSED_COUNT_CACHE.get("count") or 0)
    try:
        if not path.exists():
            cnt = 0
        else:
            with path.open("rb") as f:
                cnt = sum(1 for _ in f)
        _LAST_CLOSED_COUNT_CACHE.update({"ts": ts, "count": cnt})
        return cnt
    except Exception:
        return int(_LAST_CLOSED_COUNT_CACHE.get("count") or 0)


def normalize_ticker(v: Any) -> str:
    if v is None:
        return ""
    t = str(v).strip().upper().replace("/", "-").replace("_", "-")
    if not t:
        return ""
    parts = [p for p in t.split("-") if p]
    if len(parts) >= 2:
        non = [p for p in parts if p != "KRW"]
        return (non[-1] if non else parts[-1]).strip().upper()
    if t.endswith("KRW") and len(t) > 3:
        return t[:-3].strip().upper()
    return t


def row_ts(row: Dict[str, Any], *keys: str) -> float:
    for k in keys:
        v = row.get(k)
        x = fnum(v, default=0.0)
        if x > 1000000000:
            return x
        if isinstance(v, str) and v:
            try:
                import datetime as _dt
                return _dt.datetime.fromisoformat(v.replace("Z", "+00:00")).timestamp()
            except Exception:
                pass
    return 0.0


def event_time(row: Dict[str, Any]) -> float:
    return row_ts(row, "expires_at", "candidate_expires_at", "created_at", "candidate_created_at", "source_created_at", "detected_ts", "event_ts", "ts", "timestamp")


def event_created_ts(row: Dict[str, Any]) -> float:
    return row_ts(row, "created_at", "candidate_created_at", "source_created_at", "detected_ts", "event_ts", "ts", "timestamp")


def load_control() -> Dict[str, Any]:
    saved = load_json(FILES["control"], {})
    ctrl = dict(DEFAULT_CONTROL)
    if isinstance(saved, dict):
        ctrl.update(saved)
    # v400: paper 실행기는 기본 ON. 사용자가 명시적으로 running=false로 저장한 경우만 정지한다.
    if "running" not in ctrl:
        ctrl["running"] = True
    return ctrl


def write_pid() -> None:
    try:
        FILES["pid"].write_text(str(os.getpid()), encoding="utf-8")
    except Exception:
        pass


def load_open() -> Dict[str, Dict[str, Any]]:
    obj = load_json(FILES["open"], {})
    return obj if isinstance(obj, dict) else {}


def save_open(open_pos: Dict[str, Dict[str, Any]]) -> None:
    save_json(FILES["open"], open_pos if isinstance(open_pos, dict) else {})


def open_tickers(open_pos: Dict[str, Dict[str, Any]]) -> set[str]:
    return {normalize_ticker(p.get("ticker")) for p in open_pos.values() if isinstance(p, dict) and normalize_ticker(p.get("ticker"))}


def closed_recent_ids(limit: int = 2000) -> set[str]:
    ids: set[str] = set()
    for r in read_jsonl_tail(FILES["closed"], limit):
        for k in ("pos_id", "event_id", "trace_id", "handoff_id", "candidate_uid"):
            v = str(r.get(k) or "").strip()
            if v:
                ids.add(v)
    return ids


def event_id(ev: Dict[str, Any], lane: str = "strict") -> str:
    for k in ("event_id", "event_key", "trace_id", "handoff_id", "candidate_uid", "id"):
        v = str(ev.get(k) or "").strip()
        if v:
            return v
    t = normalize_ticker(ev.get("ticker") or ev.get("market") or ev.get("symbol")) or "UNKNOWN"
    scan = str(ev.get("scan_id") or ev.get("source_scan_id") or ev.get("strategy_scan_id") or "")[:40]
    created = int(event_created_ts(ev) or now_ts())
    score = fnum(ev.get("score"), ev.get("leader_score"), default=0.0)
    return f"{lane}:{t}:{scan}:{created}:{score:.3f}"


def get_event_price(ev: Dict[str, Any]) -> float:
    for k in ("live_price", "current_price", "price", "trade_price", "close", "last_price", "entry_price", "detected_price"):
        x = fnum(ev.get(k), default=0.0)
        if x > 0:
            return x
    ctx = ev.get("entry_context") if isinstance(ev.get("entry_context"), dict) else {}
    for k in ("live_price", "current_price", "price", "close"):
        x = fnum(ctx.get(k), default=0.0)
        if x > 0:
            return x
    return 0.0


def fetch_all_prices_cached(ttl: float = 4.0) -> Dict[str, float]:
    ts = now_ts()
    if ts - float(_LAST_PRICE_CACHE.get("ts") or 0.0) < ttl:
        return dict(_LAST_PRICE_CACHE.get("prices") or {})
    prices: Dict[str, float] = {}
    try:
        req = urllib.request.Request(
            "https://api.bithumb.com/public/ticker/ALL_KRW",
            headers={"Accept": "application/json", "User-Agent": VERSION},
        )
        with urllib.request.urlopen(req, timeout=4) as resp:
            data = json.loads(resp.read().decode("utf-8", errors="ignore"))
        raw = data.get("data") if isinstance(data, dict) else {}
        if isinstance(raw, dict):
            for k, v in raw.items():
                if not isinstance(v, dict):
                    continue
                t = normalize_ticker(k)
                p = fnum(v.get("closing_price"), v.get("close"), default=0.0)
                if t and p > 0:
                    prices[t] = p
    except Exception as exc:
        log_error("fetch_all_prices", exc)
    if prices:
        _LAST_PRICE_CACHE.update({"ts": ts, "prices": prices})
    return prices


def live_price(ticker: str, fallback: float = 0.0) -> float:
    t = normalize_ticker(ticker)
    prices = fetch_all_prices_cached()
    return float(prices.get(t) or fallback or 0.0)


def candidate_is_fresh(ev: Dict[str, Any], ctrl: Dict[str, Any]) -> bool:
    nowv = now_ts()
    exp = row_ts(ev, "expires_at", "candidate_expires_at")
    if exp > 0:
        return exp >= nowv
    created = event_created_ts(ev)
    if created > 0:
        return (nowv - created) <= fnum(ctrl.get("candidate_ttl_sec"), default=120.0)
    # latest 파일 자체가 방금 갱신된 경우에만 timestamp 없는 후보를 관찰 대상으로 둔다. OPEN은 하지 않는다.
    return False


def micro_fresh(ev: Dict[str, Any], ctrl: Dict[str, Any]) -> bool:
    ctx = ev.get("entry_context") if isinstance(ev.get("entry_context"), dict) else {}
    vals = [ev, ctx]
    for obj in vals:
        if bool(obj.get("micro_fresh")):
            return True
        if str(obj.get("micro_row_status") or "").lower() in {"fresh", "ok", "true", "1"}:
            return True
        age = fnum(obj.get("micro_age_sec"), default=999999.0)
        if age <= fnum(ctrl.get("preopen_micro_urgent_ttl_sec"), default=35.0):
            return True
    return False


def ws_fresh(ev: Dict[str, Any]) -> bool:
    ctx = ev.get("entry_context") if isinstance(ev.get("entry_context"), dict) else {}
    for obj in (ev, ctx):
        if bool(obj.get("ws_fresh")):
            return True
        if str(obj.get("ws_row_status") or "").lower() in {"fresh", "ok", "true", "1"}:
            return True
        if fnum(obj.get("ws_age_sec"), default=999999.0) <= 30:
            return True
    return False


def _pressure_is_bad(v: Any) -> bool:
    if v in (None, ""):
        return False
    if isinstance(v, bool):
        return bool(v)
    try:
        # 숫자형 압력값은 보수적으로 0.60 이상이면 부담으로 본다.
        return float(v) >= 0.60
    except Exception:
        s = str(v).strip().lower()
        if s in {"false", "0", "none", "no", "ok", "good", "low", "정상", "없음"}:
            return False
        return any(x in s for x in ("bad", "high", "pressure", "wall", "부담", "압력", "매도"))


def active_main_version() -> str:
    """DEPLOY_TARGET에서 현재 메인봇 버전을 읽어 CLOSED 장부가 최신판에 붙도록 한다."""
    try:
        txt = (BASE_DIR / "DEPLOY_TARGET.txt").read_text(encoding="utf-8", errors="ignore").strip()
        m = re.search(r"2[_\.]13[_\.](\d+)", txt)
        if m:
            return f"v2.13.{m.group(1)}"
    except Exception:
        pass
    return ""


def paper_final_safety(ev: Dict[str, Any], ctrl: Dict[str, Any]) -> Tuple[bool, List[str], Dict[str, Any]]:
    """paper OPEN 직전 최종 안전문.

    strategy가 S1이라고 넘겨도 paper가 마지막으로 실제 체결/호가/반응 값을 다시 본다.
    여기서 막힌 후보는 OPEN하지 않고 trace에 paper최종차단으로 남긴다.
    """
    ctx = copy_entry_context(ev)
    diag = build_entry_diagnostics(ev, ctx)
    reasons: List[str] = []
    min_buy = fnum(ctrl.get("paper_final_min_buy_ratio"), default=0.70)
    min_sustain = fnum(ctrl.get("paper_final_min_buy_sustain_1m"), default=0.64)
    max_spread = fnum(ctrl.get("paper_final_max_spread_pct"), default=0.18)
    max_slip = fnum(ctrl.get("paper_final_max_slippage_pct"), default=0.20)
    min_react = fnum(ctrl.get("paper_final_min_price_reaction_pct"), default=0.05)

    if not micro_fresh(ev, ctrl):
        reasons.append("호가·체결 신선정보 없음")
    if bool(ctrl.get("paper_final_require_ws_fresh", True)) and not ws_fresh(ev):
        reasons.append("실시간 시세 신선정보 없음")

    buy = fnum(diag.get("buy_ratio"), default=-1.0)
    sustain = fnum(diag.get("buy_sustain_1m"), default=-1.0)
    spread = fnum(diag.get("spread_pct"), default=-1.0)
    slip_raw = fnum(diag.get("slippage_pct"), default=-1.0)
    slip = slip_raw if slip_raw >= 0 else spread
    react = fnum(diag.get("price_reaction_pct"), default=0.0)
    f1 = fnum(diag.get("flow_1m_pct"), default=0.0)
    f3 = fnum(diag.get("flow_3m_pct"), default=0.0)

    if buy < 0:
        reasons.append("매수체결비 정보 없음")
    elif buy < min_buy:
        reasons.append(f"매수체결비 부족({buy:.2f} < {min_buy:.2f})")
    if sustain < 0:
        reasons.append("1분 매수지속 정보 없음")
    elif sustain < min_sustain:
        reasons.append(f"1분 매수지속 부족({sustain:.2f} < {min_sustain:.2f})")
    if spread < 0:
        reasons.append("스프레드 정보 없음")
    elif spread > max_spread:
        reasons.append(f"스프레드 부담({spread:.2f}% > {max_spread:.2f}%)")
    if slip < 0:
        reasons.append("예상 미끄러짐 정보 없음")
    elif slip > max_slip:
        reasons.append(f"예상 미끄러짐 부담({slip:.2f}% > {max_slip:.2f}%)")
    if react < min_react:
        reasons.append(f"가격반응 부족({react:+.2f}% < +{min_react:.2f}%)")
    if max(react, f1, f3) < min_react:
        reasons.append(f"진입 직전 단기반응 부족(1m {f1:+.2f} / 3m {f3:+.2f})")
    if _pressure_is_bad(diag.get("sell_pressure")):
        reasons.append("매도벽/매도압력 부담")

    diag["paper_final_safety_reasons"] = reasons[:10]
    return (len(reasons) == 0), reasons[:10], diag


def is_s1_candidate(ev: Dict[str, Any]) -> bool:
    # false 계열은 stage=S1보다 먼저 본다. 구 경로가 stage만 S1로 남긴 후보를 paper가 다시 열지 못하게 한다.
    if ev.get("paper_bot_open") is False or ev.get("open_eligible") is False:
        return False
    stage = str(ev.get("s_stage") or ev.get("candidate_stage") or ev.get("stage") or ev.get("candidate_grade") or ev.get("grade") or "").upper()
    if stage == "S1":
        return True
    return bool(ev.get("paper_bot_open") or ev.get("open_eligible") or ev.get("trade_ready"))


def candidate_sources(ctrl: Dict[str, Any]) -> List[Tuple[str, Path, List[Dict[str, Any]]]]:
    maxn = max(50, min(2000, int(fnum(ctrl.get("candidate_read_max_lines"), default=800))))
    sources: List[Tuple[str, Path, List[Dict[str, Any]]]] = []
    for name in ("paper_latest", "paper_merged", "paper_archive"):
        path = FILES[name]
        rows = read_jsonl_tail(path, maxn if name != "paper_archive" else min(maxn, 500))
        sources.append((name, path, rows))
    return sources


def latest_scan_filter(rows: List[Dict[str, Any]], ctrl: Dict[str, Any]) -> List[Dict[str, Any]]:
    if not rows or not bool(ctrl.get("consume_latest_scan_only", True)):
        return rows
    scan_ids = [str(r.get("scan_id") or r.get("source_scan_id") or "").strip() for r in rows if str(r.get("scan_id") or r.get("source_scan_id") or "").strip()]
    if scan_ids:
        latest = scan_ids[-1]
        same = [r for r in rows if str(r.get("scan_id") or r.get("source_scan_id") or "").strip() == latest]
        if same:
            return same
    latest_ts = max((event_created_ts(r) for r in rows), default=0.0)
    if latest_ts > 0:
        win = fnum(ctrl.get("latest_scan_window_sec"), default=8.0)
        return [r for r in rows if event_created_ts(r) >= latest_ts - win]
    return rows


def build_trace(rows: List[Dict[str, Any]], ctrl: Dict[str, Any], open_pos: Dict[str, Dict[str, Any]], picked_ids: set[str], opened_ids: set[str]) -> Dict[str, Any]:
    out: List[Dict[str, Any]] = []
    open_ids = set(open_pos.keys())
    open_ticks = open_tickers(open_pos)
    for ev in rows[-160:]:
        if not isinstance(ev, dict):
            continue
        t = normalize_ticker(ev.get("ticker") or ev.get("market") or ev.get("symbol"))
        eid = event_id(ev, "strict")
        reason: List[str] = []
        status = "observed"
        if eid in opened_ids:
            status = "open"
        elif eid in picked_ids:
            status = "selected_for_open"
        elif eid in open_ids or t in open_ticks:
            status = "already_open"
        elif not candidate_is_fresh(ev, ctrl):
            status = "expired"
            reason.append("후보오래됨")
        elif not is_s1_candidate(ev):
            status = "not_s1"
            reason.append("S1아님")
        elif ctrl.get("preopen_micro_recheck", True) and not micro_fresh(ev, ctrl):
            status = "micro_wait"
            reason.append("micro미확인")
        elif ev.get("paper_final_block_reasons"):
            status = "paper_final_block"
            reason.extend([str(x) for x in (ev.get("paper_final_block_reasons") or [])[:4]])
        else:
            status = "merged_waiting_pick"
        out.append({
            "event_id": eid,
            "trace_id": eid,
            "ticker": t,
            "status": status,
            "reason": ",".join(reason) if reason else "-",
            "s_stage": ev.get("s_stage") or ev.get("candidate_stage") or ev.get("candidate_grade") or ev.get("grade"),
            "score": ev.get("score") or ev.get("leader_score"),
            "strategy": ev.get("strategy_label") or ev.get("strategy_key") or ev.get("strategy") or ev.get("route"),
            "stage_policy_schema": _diag_first(ev, ("stage_policy_schema", "lifecycle_schema")),
            "entry_reasons": _diag_list(ev, ("final_entry_reasons", "trade_ready_reasons", "s_stage_reasons", "entry_reasons", "why", "reason"), limit=6),
            "missing_info": (list(ev.get("paper_final_block_reasons") or [])[:6] or _diag_list(ev, ("missing_info", "missing_fields", "info_missing", "info_needed", "s1_missing", "unmet_conditions", "block_reasons"), limit=6)),
            "created_at": ev.get("created_at") or ev.get("candidate_created_at") or ev.get("source_created_at"),
            "updated_at": now_ts(),
        })
    obj = {"version": VERSION, "trace_version": VERSION, "build": BUILD_LABEL, "updated_at": now_ts(), "updated_at_text": iso_ts(), "rows": out}
    save_json(FILES["trace"], obj)
    return obj


def write_handoff_status(latest_count: int, merged_fresh: int, pick_stats: Dict[str, Any]) -> None:
    save_json(FILES["handoff_status"], {
        "version": VERSION,
        "updated_at": now_ts(),
        "updated_at_text": iso_ts(),
        "latest_count": latest_count,
        "paper_latest_count": latest_count,
        "latest_lines": latest_count,
        "merged_fresh": merged_fresh,
        "archive_window": int(fnum(load_control().get("candidate_read_max_lines"), default=800)),
        "pick_stats": pick_stats,
        "note": "v416 light runner: bounded read + paper final S1 safety gate",
    })


def select_candidates(ctrl: Dict[str, Any], open_pos: Dict[str, Dict[str, Any]]) -> Tuple[List[Tuple[str, Dict[str, Any]]], Dict[str, Any], List[Dict[str, Any]]]:
    stats = Counter()
    all_rows: List[Dict[str, Any]] = []
    latest_count = 0
    for name, _path, rows in candidate_sources(ctrl):
        stats[f"{name}_read"] += len(rows)
        if name == "paper_latest":
            latest_count = len(rows)
        for r in rows:
            if isinstance(r, dict):
                rr = dict(r)
                rr.setdefault("_source_file", name)
                all_rows.append(rr)
    filtered = latest_scan_filter(all_rows, ctrl)
    stats["latest_scan_before"] = len(all_rows)
    stats["latest_scan_after"] = len(filtered)
    existing_ids = set(open_pos.keys()) | closed_recent_ids()
    blocked_tickers = open_tickers(open_pos) if ctrl.get("block_same_ticker_open", True) else set()
    picked: List[Tuple[str, Dict[str, Any]]] = []
    max_new = int(fnum(ctrl.get("max_new_per_cycle"), default=0))
    max_open = int(fnum(ctrl.get("max_open_strict"), default=0))
    for ev in filtered:
        if max_new > 0 and len(picked) >= max_new:
            stats["limit_skip"] += 1
            continue
        if max_open > 0 and len(open_pos) + len(picked) >= max_open:
            stats["limit_skip"] += 1
            continue
        if ctrl.get("new_open_paused", False):
            stats["new_open_paused"] += 1
            continue
        if not candidate_is_fresh(ev, ctrl):
            stats["stale_skip"] += 1
            continue
        if ctrl.get("open_trade_ready_only", True) and not is_s1_candidate(ev):
            stats["not_s1_skip"] += 1
            continue
        if ctrl.get("preopen_micro_recheck", True) and ctrl.get("notify_open_require_micro_fresh", True) and not micro_fresh(ev, ctrl):
            stats["micro_preopen_wait"] += 1
            continue
        if ctrl.get("notify_open_require_ws_fresh", False) and not ws_fresh(ev):
            stats["ws_preopen_wait"] += 1
            continue
        t = normalize_ticker(ev.get("ticker") or ev.get("market") or ev.get("symbol"))
        price = get_event_price(ev)
        if not t or price <= 0:
            stats["bad_skip"] += 1
            continue
        eid = event_id(ev, "strict")
        if eid in existing_ids:
            stats["dup_skip"] += 1
            continue
        if ctrl.get("block_same_ticker_open", True) and t in blocked_tickers:
            stats["same_ticker_skip"] += 1
            continue
        ok_final, final_reasons, final_diag = paper_final_safety(ev, ctrl)
        if not ok_final:
            ev["paper_final_block_reasons"] = final_reasons
            ev["paper_final_safety_diagnostics"] = final_diag
            stats["paper_final_block"] += 1
            continue
        ev = dict(ev)
        ev["lane"] = "strict"
        ev["paper_final_safety_passed"] = True
        ev["paper_final_safety_diagnostics"] = final_diag
        picked.append((eid, ev))
        existing_ids.add(eid)
        blocked_tickers.add(t)
        stats["selected_s1"] += 1
    stats["latest_count"] = latest_count
    stats["merged_fresh"] = sum(1 for r in filtered if candidate_is_fresh(r, ctrl))
    return picked, dict(stats), filtered


def copy_entry_context(ev: Dict[str, Any]) -> Dict[str, Any]:
    ctx: Dict[str, Any] = {}
    if isinstance(ev.get("entry_context"), dict):
        ctx.update(ev["entry_context"])
    for k, v in ev.items():
        if k.startswith("_"):
            continue
        if k not in ctx and k not in {"raw"}:
            ctx[k] = v
    return ctx


def _diag_sources(ev: Dict[str, Any], ctx: Optional[Dict[str, Any]] = None) -> List[Dict[str, Any]]:
    srcs: List[Dict[str, Any]] = []
    for obj in (ev, ctx, ev.get("entry_context"), ev.get("entry_snapshot"), ev.get("profile"), ev.get("raw")):
        if isinstance(obj, dict):
            srcs.append(obj)
            for kk in ("flat", "strategy", "orderflow", "feature", "price_flow", "money_flow", "position", "risk", "micro", "ws", "quote"):
                vv = obj.get(kk)
                if isinstance(vv, dict):
                    srcs.append(vv)
    return srcs


def _diag_first(ev: Dict[str, Any], keys: Iterable[str], default: Any = None, ctx: Optional[Dict[str, Any]] = None) -> Any:
    for src in _diag_sources(ev, ctx):
        for k in keys:
            if k in src and src.get(k) not in (None, "", [], {}):
                return src.get(k)
    return default


def _diag_list(ev: Dict[str, Any], keys: Iterable[str], ctx: Optional[Dict[str, Any]] = None, limit: int = 8) -> List[str]:
    out: List[str] = []
    for src in _diag_sources(ev, ctx):
        for k in keys:
            v = src.get(k)
            if v in (None, "", [], {}):
                continue
            vals: List[Any]
            if isinstance(v, list):
                vals = v
            elif isinstance(v, dict):
                vals = [f"{kk}:{vv}" for kk, vv in list(v.items())[:limit]]
            else:
                vals = [v]
            for item in vals:
                txt = str(item).strip()
                if txt and txt not in out:
                    out.append(txt)
                    if len(out) >= limit:
                        return out
    return out


def _fmt_bool(v: Any) -> str:
    if isinstance(v, str):
        if v.lower() in {"fresh", "ok", "true", "1", "yes"}:
            return "OK"
        if v.lower() in {"stale", "old", "false", "0", "no"}:
            return "부족"
    if v is True:
        return "OK"
    if v is False:
        return "부족"
    return "-" if v in (None, "") else str(v)


def _fmt_pct_value(v: Any, suffix: str = "%") -> str:
    if v in (None, ""):
        return "-"
    try:
        return f"{fnum(v):.2f}{suffix}"
    except Exception:
        return str(v)


def build_entry_diagnostics(ev: Dict[str, Any], ctx: Optional[Dict[str, Any]] = None) -> Dict[str, Any]:
    ctx = ctx if isinstance(ctx, dict) else {}
    reasons = _diag_list(ev, ("final_entry_reasons", "trade_ready_reasons", "s_stage_reasons", "entry_reasons", "why", "reason"), ctx, 10)
    missing = _diag_list(ev, ("missing_info", "missing_fields", "info_missing", "info_needed", "need_info", "entry_missing_info", "s1_missing", "s1_missing_conditions", "unmet_conditions", "block_reasons"), ctx, 10)
    matched = _diag_list(ev, ("matched_strategies", "strategy_matches", "strategy_tags", "tags"), ctx, 8)
    diag = {
        "stage_policy_schema": _diag_first(ev, ("stage_policy_schema", "lifecycle_schema"), ctx=ctx),
        "stage": _diag_first(ev, ("s_stage", "candidate_stage", "candidate_grade", "grade"), ctx=ctx),
        "strategy_key": _diag_first(ev, ("strategy_key", "paper_strategy_key", "strategy", "route", "section"), ctx=ctx),
        "strategy_label": _diag_first(ev, ("strategy_label", "paper_strategy_label", "final_entry_label"), ctx=ctx),
        "entry_reasons": reasons,
        "missing_info": missing,
        "matched_strategies": matched,
        "micro_fresh": _fmt_bool(_diag_first(ev, ("micro_fresh", "micro_row_status", "micro_status"), ctx=ctx)),
        "ws_fresh": _fmt_bool(_diag_first(ev, ("ws_fresh", "ws_row_status", "quote_fresh", "quote_status"), ctx=ctx)),
        "buy_ratio": fnum(_diag_first(ev, ("buy_ratio", "buy_ratio_30s", "buy_trade_ratio", "micro_buy_ratio"), ctx=ctx), default=-1.0),
        "buy_sustain_1m": fnum(_diag_first(ev, ("micro_buy_ratio_sustain_1m", "buy_ratio_1m", "buy_sustain_1m"), ctx=ctx), default=-1.0),
        "spread_pct": fnum(_diag_first(ev, ("spread_pct", "micro_spread_pct", "orderbook_spread_pct"), ctx=ctx), default=-1.0),
        "slippage_pct": fnum(_diag_first(ev, ("slippage_est_pct", "expected_slippage_pct", "slippage_pct"), ctx=ctx), default=-1.0),
        "price_reaction_pct": fnum(_diag_first(ev, ("price_reaction_pct", "price_reaction", "reaction_pct"), ctx=ctx), default=0.0),
        "flow_1m_pct": fnum(_diag_first(ev, ("chg_1m", "flow_1m", "change_1m_pct", "ret_1m_pct"), ctx=ctx), default=0.0),
        "flow_3m_pct": fnum(_diag_first(ev, ("chg_3m", "flow_3m", "change_3m_pct", "ret_3m_pct"), ctx=ctx), default=0.0),
        "flow_5m_pct": fnum(_diag_first(ev, ("chg_5m", "flow_5m", "change_5m_pct", "ret_5m_pct"), ctx=ctx), default=0.0),
        "flow_15m_pct": fnum(_diag_first(ev, ("chg_15m", "flow_15m", "change_15m_pct", "ret_15m_pct"), ctx=ctx), default=0.0),
        "flow_30m_pct": fnum(_diag_first(ev, ("chg_30m", "flow_30m", "change_30m_pct", "ret_30m_pct"), ctx=ctx), default=0.0),
        "vwap_pos_pct": fnum(_diag_first(ev, ("vwap_pos_pct", "vwap_gap_pct", "vwap_position_pct", "vwap"), ctx=ctx), default=0.0),
        "ema5_pos_pct": fnum(_diag_first(ev, ("ema5_pos_pct", "ema5_gap_pct", "ema5_position_pct", "ema5"), ctx=ctx), default=0.0),
        "relative_strength": fnum(_diag_first(ev, ("relative_strength", "relative", "market_relative_strength"), ctx=ctx), default=0.0),
        "turnover_krw": fnum(_diag_first(ev, ("turnover_krw", "trade_amount_krw", "value_krw", "acc_trade_price_24h"), ctx=ctx), default=0.0),
        "sell_pressure": _diag_first(ev, ("sell_pressure", "ask_wall_pressure", "sell_trade_pressure"), ctx=ctx),
    }
    passed: List[str] = []
    if diag["micro_fresh"] == "OK": passed.append("micro신선")
    if diag["ws_fresh"] == "OK": passed.append("WS신선")
    if diag["buy_ratio"] >= 0: passed.append(f"매수체결 {diag['buy_ratio']:.2f}")
    if diag["buy_sustain_1m"] >= 0: passed.append(f"1분지속 {diag['buy_sustain_1m']:.2f}")
    if diag["spread_pct"] >= 0: passed.append(f"스프레드 {diag['spread_pct']:.2f}%")
    if diag["slippage_pct"] >= 0: passed.append(f"슬리피지 {diag['slippage_pct']:.2f}%")
    if diag["price_reaction_pct"]: passed.append(f"가격반응 {diag['price_reaction_pct']:+.2f}%")
    diag["condition_pass_summary"] = passed[:8]
    return diag


def format_entry_diag_lines(diag: Dict[str, Any], prefix: str = "- ") -> List[str]:
    lines: List[str] = []
    reasons = diag.get("entry_reasons") if isinstance(diag.get("entry_reasons"), list) else []
    missing = diag.get("missing_info") if isinstance(diag.get("missing_info"), list) else []
    passed = diag.get("condition_pass_summary") if isinstance(diag.get("condition_pass_summary"), list) else []
    if reasons:
        lines.append(prefix + "진입근거: " + " / ".join(str(x) for x in reasons[:4]))
    if passed:
        lines.append(prefix + "통과정보: " + " / ".join(str(x) for x in passed[:5]))
    flow = f"1m {diag.get('flow_1m_pct',0):+.2f}% · 3m {diag.get('flow_3m_pct',0):+.2f}% · 5m {diag.get('flow_5m_pct',0):+.2f}% · 15m {diag.get('flow_15m_pct',0):+.2f}%"
    lines.append(prefix + "흐름: " + flow)
    pos = f"VWAP {diag.get('vwap_pos_pct',0):+.2f}% · EMA5 {diag.get('ema5_pos_pct',0):+.2f}% · 상대강도 {diag.get('relative_strength',0):+.2f}"
    lines.append(prefix + "위치: " + pos)
    if missing:
        lines.append(prefix + "부족/주의: " + " / ".join(str(x) for x in missing[:5]))
    else:
        lines.append(prefix + "부족/주의: 최종안전문 통과")
    return lines


def open_position(pos_id: str, ev: Dict[str, Any]) -> Dict[str, Any]:
    ticker = normalize_ticker(ev.get("ticker") or ev.get("market") or ev.get("symbol"))
    detected = get_event_price(ev)
    price = live_price(ticker, detected) or detected
    ts = now_ts()
    ctx = copy_entry_context(ev)
    diag = ev.get("paper_final_safety_diagnostics") if isinstance(ev.get("paper_final_safety_diagnostics"), dict) else build_entry_diagnostics(ev, ctx)
    grade = str(ev.get("s_stage") or ev.get("candidate_stage") or ev.get("candidate_grade") or ev.get("grade") or "S1").upper()
    current_main_version = active_main_version()
    event_main_version = ev.get("main_version") or ev.get("deploy_version") or ""
    stamped_main_version = current_main_version if current_main_version else event_main_version
    return {
        "pos_id": pos_id,
        "event_id": pos_id,
        "ticker": ticker,
        "lane": "strict",
        "opened_at": ts,
        "opened_at_text": iso_ts(ts),
        "opened_paper_version": VERSION,
        "opened_main_version": stamped_main_version,
        "main_version": stamped_main_version,
        "deploy_version": stamped_main_version,
        "strategy_worker_version": ev.get("strategy_worker_version") or ev.get("source_version") or ev.get("brain_version") or "",
        "paper_final_safety_passed": bool(ev.get("paper_final_safety_passed")),
        "entry_price": price,
        "detected_price": detected,
        "current_price": price,
        "peak_pct": 0.0,
        "trough_pct": 0.0,
        "last_pnl_pct": -fnum(DEFAULT_CONTROL.get("fee_pct_roundtrip"), default=0.10),
        "last_update": ts,
        "strategy": ev.get("strategy") or ev.get("strategy_key") or ev.get("route") or ev.get("section") or "unknown",
        "strategy_key": ev.get("strategy_key") or ev.get("paper_strategy_key") or ev.get("route") or ev.get("strategy"),
        "strategy_label": ev.get("strategy_label") or ev.get("paper_strategy_label") or ev.get("final_entry_label"),
        "candidate_grade": grade,
        "candidate_grade_label": ev.get("candidate_grade_label") or ev.get("s_stage_label") or "✅ S1 최종 paper OPEN",
        "trade_ready": bool(ev.get("trade_ready") or ev.get("paper_bot_open") or ev.get("open_eligible") or grade == "S1"),
        "trade_ready_label": ev.get("trade_ready_label") or ev.get("final_entry_label") or "S1 paper open",
        "final_entry_action": ev.get("final_entry_action") or "paper_open",
        "final_entry_label": ev.get("final_entry_label") or ev.get("trade_ready_label") or "S1 paper open",
        "final_entry_reasons": ev.get("final_entry_reasons") or ev.get("trade_ready_reasons") or [],
        "scan_id": ev.get("scan_id") or ev.get("source_scan_id") or "",
        "brain_version": ev.get("brain_version") or ev.get("source_version") or "",
        "score": fnum(ev.get("score"), ev.get("leader_score"), default=0.0),
        "edge": fnum(ev.get("edge"), ev.get("edge_score"), default=0.0),
        "reason": ev.get("reason") or ev.get("why") or ev.get("hold_reason") or "",
        "source_created_at": event_created_ts(ev),
        "source_created_at_text": ev.get("created_at_text") or ev.get("source_created_at_text") or "",
        "entry_context": ctx,
        "entry_diagnostics": diag,
        "entry_condition_reasons": diag.get("entry_reasons") or [],
        "entry_missing_info": diag.get("missing_info") or [],
        "entry_condition_pass_summary": diag.get("condition_pass_summary") or [],
        "raw": ev,
    }


EXIT_LABELS = {
    "take_profit": "익절 종료",
    "stop_loss": "손절 종료",
    "protect_stop_after_tp": "익절 후 보호청산",
    "slow_no_progress": "지지부진 종료",
    "time_exit": "시간 종료",
}


def update_position(pos: Dict[str, Any], ctrl: Dict[str, Any]) -> Tuple[Dict[str, Any], Optional[Dict[str, Any]]]:
    ticker = normalize_ticker(pos.get("ticker"))
    entry = fnum(pos.get("entry_price"), default=0.0)
    if not ticker or entry <= 0:
        return pos, None
    price = live_price(ticker, fnum(pos.get("current_price"), default=entry))
    gross = ((price / entry) - 1.0) * 100.0 if entry else 0.0
    net = gross - fnum(ctrl.get("fee_pct_roundtrip"), default=0.10)
    pos["current_price"] = price
    pos["last_pnl_pct"] = round(net, 4)
    pos["peak_pct"] = max(fnum(pos.get("peak_pct"), default=0.0), net)
    pos["trough_pct"] = min(fnum(pos.get("trough_pct"), default=0.0), net)
    pos["last_update"] = now_ts()
    opened_at = fnum(pos.get("opened_at"), default=now_ts())
    age_min = (now_ts() - opened_at) / 60.0
    peak = fnum(pos.get("peak_pct"), default=0.0)
    reason = ""
    detail = ""
    if net <= fnum(ctrl.get("stop_loss_pct"), default=-0.55):
        reason = "stop_loss"; detail = f"손절선 도달: 현재 {net:+.2f}%"
    elif peak >= fnum(ctrl.get("protect_trigger_pct"), default=0.70) and net <= fnum(ctrl.get("protect_floor_pct"), default=0.30):
        reason = "protect_stop_after_tp"; detail = f"익절권 후 보호선: 최고 {peak:+.2f}% / 현재 {net:+.2f}%"
    elif net >= fnum(ctrl.get("take_profit_pct"), default=1.20):
        reason = "take_profit"; detail = f"익절선 도달: 현재 {net:+.2f}%"
    elif age_min >= fnum(ctrl.get("slow_minutes"), default=20.0) and peak < fnum(ctrl.get("slow_peak_under_pct"), default=0.25) and net <= 0.10:
        reason = "slow_no_progress"; detail = f"지지부진: 보유 {age_min:.1f}분 / 최고 {peak:+.2f}% / 현재 {net:+.2f}%"
    elif age_min >= fnum(ctrl.get("time_exit_minutes"), default=15.0):
        reason = "time_exit"; detail = f"시간종료: 보유 {age_min:.1f}분"
    if not reason:
        return pos, None
    closed_ts = now_ts()
    hold_sec = max(0, int(closed_ts - opened_at))
    closed = dict(pos)
    closed.update({
        "closed_at": closed_ts,
        "closed_at_text": iso_ts(closed_ts),
        "exit_price": price,
        "pnl_pct": round(net, 4),
        "peak_pct": round(peak, 4),
        "trough_pct": round(fnum(pos.get("trough_pct"), default=0.0), 4),
        "age_min": round(age_min, 2),
        "hold_sec": hold_sec,
        "exit_reason": reason,
        "exit_rule": reason,
        "exit_rule_label": EXIT_LABELS.get(reason, reason),
        "exit_rule_reason": detail,
        "closed_paper_version": VERSION,
    })
    return pos, closed


def fmt_price(v: Any) -> str:
    x = fnum(v, default=0.0)
    if x >= 1000:
        return f"{x:,.0f}"
    if x >= 1:
        return f"{x:,.4f}"
    return f"{x:,.8f}"


def send_message(text: str) -> None:
    if not TOKEN or not NOTIFY_CHAT_ID:
        return
    try:
        data = urllib.parse.urlencode({"chat_id": NOTIFY_CHAT_ID, "text": text[:3900], "disable_web_page_preview": "true"}).encode("utf-8")
        req = urllib.request.Request(f"https://api.telegram.org/bot{TOKEN}/sendMessage", data=data)
        urllib.request.urlopen(req, timeout=5).read()
    except Exception as exc:
        log_error("send_message", exc)


def notify_opened(pos: Dict[str, Any]) -> None:
    t = normalize_ticker(pos.get("ticker"))
    link = f"https://www.bithumb.com/trade/order/{t}_KRW" if t else ""
    diag = pos.get("entry_diagnostics") if isinstance(pos.get("entry_diagnostics"), dict) else {}
    extra = "\n".join(format_entry_diag_lines(diag)) if diag else "- 진입근거: strategy 상세값 미전달"
    send_message(
        "🟢 paper OPEN\n"
        f"- 종목: {t}\n"
        f"- 진입가: {fmt_price(pos.get('entry_price'))}\n"
        f"- 등급: {pos.get('candidate_grade','S1')} / 점수 {fnum(pos.get('score'), default=0.0):.2f}\n"
        f"- 전략: {pos.get('strategy_label') or pos.get('strategy') or '-'}\n"
        f"{extra}\n"
        f"- 바로보기: {link}\n"
        f"- paper: {VERSION}"
    )


def notify_closed(row: Dict[str, Any]) -> None:
    t = normalize_ticker(row.get("ticker"))
    diag = row.get("entry_diagnostics") if isinstance(row.get("entry_diagnostics"), dict) else {}
    extra = "\n".join(format_entry_diag_lines(diag)) if diag else "- 진입근거: strategy 상세값 미전달"
    send_message(
        "🔴 paper CLOSED\n"
        f"- 종목: {t}\n"
        f"- 손익: {fnum(row.get('pnl_pct'), default=0.0):+.2f}%\n"
        f"- 이유: {row.get('exit_rule_label') or row.get('exit_reason')}\n"
        f"- 진입/청산: {fmt_price(row.get('entry_price'))} → {fmt_price(row.get('exit_price'))}\n"
        f"- 최고/최저: {fnum(row.get('peak_pct'), default=0.0):+.2f}% / {fnum(row.get('trough_pct'), default=0.0):+.2f}%\n"
        f"- 보유: {row.get('age_min','-')}분\n"
        f"- 전략: {row.get('strategy_label') or row.get('strategy') or '-'}\n"
        f"{extra}\n"
        f"- paper: {VERSION}"
    )




def _score_stat(rows: List[Dict[str, Any]]) -> Dict[str, Any]:
    n = len(rows)
    wins = sum(1 for r in rows if fnum(r.get("pnl_pct"), r.get("profit_pct"), default=0.0) > 0)
    losses = max(0, n - wins)
    total = sum(fnum(r.get("pnl_pct"), r.get("profit_pct"), default=0.0) for r in rows)
    return {"n": n, "wins": wins, "losses": losses, "win_rate": (wins / n * 100.0 if n else 0.0), "total": total, "avg": (total / n if n else 0.0)}


def _score_bucket(row: Dict[str, Any]) -> str:
    stage = str(row.get("candidate_grade") or row.get("s_stage") or row.get("stage") or row.get("grade") or "S1").upper()
    if stage in {"S", "STRICT", "OPEN"}:
        return "S1"
    if stage not in {"S1", "S2", "S3", "X"}:
        return "S1"
    return stage


def _strategy_key(row: Dict[str, Any]) -> str:
    for k in ("strategy_primary", "strategy_bucket_primary", "strategy_key", "strategy", "strategy_name"):
        v = row.get(k)
        if v:
            return str(v)
    return "unknown"


def _main_version_key(row: Dict[str, Any]) -> str:
    for k in ("opened_main_version", "main_version", "deploy_version", "entry_main_version", "brain_version"):
        v = row.get(k)
        if v:
            s = str(v)
            if "v2." in s:
                idx = s.find("v2.")
                return s[idx:].split()[0]
            return s
    return "unknown"


def write_score_cache(status: Optional[Dict[str, Any]] = None) -> None:
    """현재 활성 CLOSED tail만 읽어 메인봇 cache 성과판을 만든다.

    전체 장부 재계산은 하지 않는다. 가드봇이 활성 CLOSED를 최근분으로 줄이는 정책과 맞춘다.
    """
    try:
        rows = read_jsonl_tail(FILES["closed"], 300)
        by_grade: Dict[str, List[Dict[str, Any]]] = {}
        by_strategy: Dict[str, List[Dict[str, Any]]] = {}
        by_version: Dict[str, List[Dict[str, Any]]] = {}
        for r in rows:
            by_grade.setdefault(_score_bucket(r), []).append(r)
            by_strategy.setdefault(_strategy_key(r), []).append(r)
            by_version.setdefault(_main_version_key(r), []).append(r)
        grade_stats = {k: _score_stat(v) for k, v in by_grade.items()}
        grade_stats["ALL"] = _score_stat(rows)
        strategy_stats = {k: _score_stat(v) for k, v in by_strategy.items()}
        version_stats = {k: _score_stat(v) for k, v in by_version.items()}
        obj = {
            "schema": "paper_score_cache_v086",
            "version": VERSION,
            "paper_version": VERSION,
            "build": BUILD_LABEL,
            "score_scope": "current_version_anchor",
            "updated_at": now_ts(),
            "updated_at_text": iso_ts(),
            "current_closed_count": len(rows),
            "closed_count": len(rows),
            "source": "paper_bot_active_closed_tail",
            "global_stats": _score_stat(rows),
            "grade_stats": grade_stats,
            "strategy_primary_stats": strategy_stats,
            "strategy_stats": strategy_stats,
            "version_stats": version_stats,
            "status_open_count": (status or {}).get("open_count") if isinstance(status, dict) else None,
        }
        save_json(FILES["score"], obj)
    except Exception as exc:
        log_error("write_score_cache", exc)

def write_status(status: Dict[str, Any]) -> None:
    global _LAST_STATUS
    base = {
        "version": VERSION,
        "active_reader_version": VERSION,
        "build": BUILD_LABEL,
        "pid": os.getpid(),
        "self_pid": os.getpid(),
        "process_pid": os.getpid(),
        "process_alive": True,
        "updated_at": now_ts(),
        "updated_at_text": iso_ts(),
        "running": True,
        "stop_reason": "running",
    }
    base.update(status)
    _LAST_STATUS = base
    write_pid()
    save_json(FILES["status"], base)


def run_cycle() -> Dict[str, Any]:
    started = now_ts()
    ctrl = load_control()
    open_pos = load_open()
    opened_items: List[Dict[str, Any]] = []
    closed_items: List[Dict[str, Any]] = []
    picked_ids: set[str] = set()
    opened_ids: set[str] = set()
    pick_stats: Dict[str, Any] = {}
    latest_rows: List[Dict[str, Any]] = []
    if ctrl.get("running", True):
        picked, pick_stats, latest_rows = select_candidates(ctrl, open_pos)
        for pid, ev in picked:
            picked_ids.add(pid)
            if pid in open_pos:
                continue
            try:
                pos = open_position(pid, ev)
                open_pos[pid] = pos
                opened_items.append(pos)
                opened_ids.add(pid)
            except Exception as exc:
                log_error("open_position", exc)
        for pid, pos in list(open_pos.items()):
            try:
                updated, closed = update_position(pos, ctrl)
                if closed:
                    closed_items.append(closed)
                    open_pos.pop(pid, None)
                    append_jsonl(FILES["closed"], closed)
                    _LAST_CLOSED_COUNT_CACHE.update({"ts": 0.0, "count": 0})
                else:
                    open_pos[pid] = updated
            except Exception as exc:
                log_error("update_position", exc)
        save_open(open_pos)
        for pos in opened_items:
            if ctrl.get("notify_on_strict_open", True):
                notify_opened(pos)
        for row in closed_items:
            if ctrl.get("notify_on_strict_close", True):
                notify_closed(row)
    else:
        _, pick_stats, latest_rows = select_candidates(ctrl, open_pos)
        pick_stats["paused"] = 1
    trace_obj = build_trace(latest_rows, ctrl, open_pos, picked_ids, opened_ids)
    write_handoff_status(int(pick_stats.get("latest_count", 0)), int(pick_stats.get("merged_fresh", 0)), pick_stats)
    status = {
        "running": bool(ctrl.get("running", True)),
        "loop_seconds": ctrl.get("loop_seconds"),
        "opened_this_cycle": len(opened_items),
        "closed_this_cycle": len(closed_items),
        "open_total": len(open_pos),
        "open_count": len(open_pos),
        "open_strict": len(open_pos),
        "closed_total": line_count_cached(FILES["closed"], ttl=0 if closed_items else 60.0),
        "pick_stats": pick_stats,
        "trace_rows": len(trace_obj.get("rows") or []),
        "elapsed_sec": round(now_ts() - started, 3),
        "engine": "light_runner",
        "legacy_loop": False,
    }
    if ctrl.get("write_score_cache", True):
        write_score_cache(status)
    write_status(status)
    log(f"cycle opened={len(opened_items)} closed={len(closed_items)} open={len(open_pos)} elapsed={status['elapsed_sec']}s trace={status['trace_rows']}")
    return status


def pstatus_text() -> str:
    st = dict(_LAST_STATUS) if _LAST_STATUS else load_json(FILES["status"], {}) or {}
    op = load_open()
    pick = st.get("pick_stats") if isinstance(st.get("pick_stats"), dict) else {}
    return "\n".join([
        f"🧪 paper 상태 /pstatus ({VERSION})",
        f"- running: {st.get('running', '-')} / open {len(op)} / status age {max(0.0, now_ts()-fnum(st.get('updated_at'), default=now_ts())):.1f}s",
        f"- 이번 cycle: OPEN {st.get('opened_this_cycle',0)} / CLOSED {st.get('closed_this_cycle',0)} / elapsed {st.get('elapsed_sec','-')}s",
        f"- 후보: latest {pick.get('latest_count','-')} / fresh {pick.get('merged_fresh','-')} / S1선택 {pick.get('selected_s1',0)} / micro대기 {pick.get('micro_preopen_wait',0)}",
        "- 엔진: light_runner / legacy loop 사용 안 함",
    ])


def popen_text() -> str:
    op = load_open()
    lines = [f"📂 paper OPEN /popen ({VERSION})", f"- OPEN {len(op)}개"]
    for p in list(op.values())[:20]:
        if not isinstance(p, dict):
            continue
        diag = p.get("entry_diagnostics") if isinstance(p.get("entry_diagnostics"), dict) else {}
        rs = diag.get("entry_reasons") if isinstance(diag.get("entry_reasons"), list) else []
        lines.append(f"- {normalize_ticker(p.get('ticker'))} / {fnum(p.get('last_pnl_pct'), default=0):+.2f}% / 진입 {fmt_price(p.get('entry_price'))} / 최고 {fnum(p.get('peak_pct'), default=0):+.2f}% / {p.get('strategy_label') or p.get('strategy') or '-'}")
        if rs:
            lines.append("  · 근거: " + " / ".join(str(x) for x in rs[:3]))
    return "\n".join(lines)


def perror_text() -> str:
    lines = tail_lines(FILES["error"], 40)
    recent = "\n".join(lines[-40:])[-3500:]
    return "🧯 paper 오류 /perror\n\n" + (recent if recent else "✅ 오류로그 없음")


def plog_text() -> str:
    return "🧾 paper 로그 /plog\n\n" + ("\n".join(tail_lines(FILES["log"], 50))[-3500:] or "로그 없음")


def handle_command(cmd: str) -> str:
    c = cmd.strip().split()[0].lower()
    if c in {"/pstatus", "/status"}:
        return pstatus_text()
    if c in {"/popen", "/open"}:
        return popen_text()
    if c in {"/perror", "/error"}:
        return perror_text()
    if c in {"/plog", "/log"}:
        return plog_text()
    if c in {"/pbatch", "/batch"}:
        return "\n\n".join([pstatus_text(), popen_text(), perror_text()])
    if c in {"/pversion", "/version"}:
        return f"{VERSION} / {BUILD_LABEL}"
    if c in {"/ponce"}:
        st = run_cycle()
        return f"✅ run once: opened {st.get('opened_this_cycle')} closed {st.get('closed_this_cycle')} elapsed {st.get('elapsed_sec')}s"
    return "명령: /pstatus /popen /perror /plog /pbatch /pversion /ponce"


def poll_telegram_once() -> None:
    global _TG_OFFSET
    if not TOKEN or not ALLOWED_CHAT_ID:
        return
    try:
        params = urllib.parse.urlencode({"timeout": 0, "offset": _TG_OFFSET + 1})
        req = urllib.request.Request(f"https://api.telegram.org/bot{TOKEN}/getUpdates?{params}")
        with urllib.request.urlopen(req, timeout=3) as resp:
            data = json.loads(resp.read().decode("utf-8", errors="ignore"))
        for upd in data.get("result", []) if isinstance(data, dict) else []:
            _TG_OFFSET = max(_TG_OFFSET, int(upd.get("update_id") or 0))
            msg = upd.get("message") or upd.get("edited_message") or {}
            chat = msg.get("chat") or {}
            chat_id = str(chat.get("id") or "")
            text = str(msg.get("text") or "")
            if not text.startswith("/"):
                continue
            if ALLOWED_CHAT_ID and chat_id != str(ALLOWED_CHAT_ID):
                continue
            ans = handle_command(text)
            old_notify = globals().get("NOTIFY_CHAT_ID")
            try:
                globals()["NOTIFY_CHAT_ID"] = chat_id
                send_message(ans)
            finally:
                globals()["NOTIFY_CHAT_ID"] = old_notify
    except Exception as exc:
        log_error("poll_telegram_once", exc)


def signal_handler(signum: int, _frame: Any) -> None:
    global _STOP, _STOP_REASON
    _STOP = True
    _STOP_REASON = f"signal_{signum}"
    try:
        st = dict(_LAST_STATUS) if _LAST_STATUS else {}
        st.update({
            "version": VERSION,
            "running": False,
            "process_alive": False,
            "stop_reason": _STOP_REASON,
            "updated_at": now_ts(),
            "updated_at_text": iso_ts(),
            "open_count": len(load_open()),
        })
        save_json(FILES["status"], st)
        log(f"stop requested: {_STOP_REASON}")
    except Exception:
        pass


def main() -> None:
    signal.signal(signal.SIGTERM, signal_handler)
    signal.signal(signal.SIGINT, signal_handler)
    startup_status = {
        "running": True,
        "startup_status": True,
        "open_count": len(load_open()),
        "open_total": len(load_open()),
        "closed_total": line_count_cached(FILES["closed"], ttl=0),
        "engine": "light_runner",
        "legacy_loop": False,
    }
    write_score_cache(startup_status)
    write_status(startup_status)
    log(f"{VERSION} started pid={os.getpid()} build={BUILD_LABEL} token={'yes' if TOKEN else 'no'} chat={'yes' if ALLOWED_CHAT_ID else 'no'}")
    last_cycle = 0.0
    last_poll = 0.0
    while not _STOP:
        try:
            ctrl = load_control()
            loop_sec = max(2.0, fnum(ctrl.get("loop_seconds"), default=8.0))
            if now_ts() - last_cycle >= loop_sec:
                run_cycle()
                last_cycle = now_ts()
            elif now_ts() - fnum(_LAST_STATUS.get("updated_at"), default=0.0) >= 10:
                hb = dict(_LAST_STATUS)
                hb.update({"heartbeat": True})
                write_status(hb)
            if now_ts() - last_poll >= 3.0:
                poll_telegram_once()
                last_poll = now_ts()
        except Exception as exc:
            log_error("main_loop", exc)
            write_status({"running": True, "last_error": f"{type(exc).__name__}: {exc}", "engine": "light_runner"})
        time.sleep(0.5)
    log(f"{VERSION} stopped reason={_STOP_REASON}")


if __name__ == "__main__":
    if len(sys.argv) > 1 and sys.argv[1] == "--once":
        print(json.dumps(run_cycle(), ensure_ascii=False, indent=2))
    else:
        main()
