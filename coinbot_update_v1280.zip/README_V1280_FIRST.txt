v1280: active S1 structure gate cutover to v1073/v977 context-line selector. Dynamic/coherent/fallback gates are shadow only. Auto-buy OFF.
