v1343 candidate material capture completion + read-only merge candidate board. No strategy/selector/exit/autobuy changes. SERVER_CHECK until applied.
