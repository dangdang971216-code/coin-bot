coinbot_update_v1439

목적: 현재 매매흐름은 그대로 두고, 동적 구조선 재료만 shadow로 비교합니다.
- /dynamic_structure_shadow 상단에 3h/6h/24h 현재계약 vs 동적재료 가상 승률·손익 표시
- trigger / invalid / target / 전체계약 proxy를 분리 비교
- Paper shadow status/ledger/diag만 기록
- 실제 S1, Paper 진입, OPEN, trigger, invalid, target, trailing, 청산, 자동매수 변경 없음

적용 후 확인:
/dynamic_structure_shadow
/no_progress_shadow
/exit_shadow_contracts
/profit_shadow
/buried_shadow
/version_score
/errorlog
