코인봇 v2195

- 실제 Paper 알림 v2149 OPEN/CLOSED를 현재 reset epoch 성과 원본으로 사용
- stale 0전 snapshot을 0으로 표시하지 않음
- /version_score 기존 형식 유지
- 가드 업그레이드 exact 대기 60초 반복을 최대 24초로 단축
- exact PID/version/build/hash/single-writer 조건 유지
- 초기화/전략/진입/청산 변경 없음
- 자동매수 OFF

LOCAL PASS / SERVER CHECK
