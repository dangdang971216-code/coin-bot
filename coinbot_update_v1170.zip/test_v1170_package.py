from pathlib import Path
import hashlib,json
root=Path(__file__).resolve().parent
m=json.loads((root/'DEPLOY_BUNDLE.json').read_text())
for name,digest in m['source_sha256'].items(): assert hashlib.sha256((root/name).read_bytes()).hexdigest()==digest
for line in (root/'FILES_SHA256_v1170.tsv').read_text().splitlines():
    h,n,r=line.split('\t',2); p=root/r; assert p.exists() and p.stat().st_size==int(n) and hashlib.sha256(p.read_bytes()).hexdigest()==h
assert m['auto_buy'] is False and m['live_ledger_included'] is False
print('PASS')
