from pathlib import Path
import importlib.util, os, tempfile
root=Path(__file__).resolve().parent

def load(name,path):
    spec=importlib.util.spec_from_file_location(name,path); m=importlib.util.module_from_spec(spec); spec.loader.exec_module(m); return m
s=load('sv1170',root/'strategy_worker_v1.029.py')
assert s.VERSION=='strategy_worker_v1.029'
rec={'frozen_ts':10.0}
e1,k1=s._v1037_trigger_occurrence(rec,'KRW-TEST|plan',101.0,100.0,100.0)
assert e1['kind']=='INITIAL_OR_MIGRATED_ABOVE' and e1['event_ts']==100.0 and e1['contract_ready'] is True
e2,k2=s._v1037_trigger_occurrence(rec,'KRW-TEST|plan',102.0,100.0,110.0)
assert e2['event_ts']==100.0 and k2==k1
e3,k3=s._v1037_trigger_occurrence(rec,'KRW-TEST|plan',99.0,100.0,120.0)
assert e3['kind']=='RESET_BELOW' and e3['event_ts'] is None and e3['contract_ready'] is False
e4,k4=s._v1037_trigger_occurrence(rec,'KRW-TEST|plan',101.0,100.0,130.0)
assert e4['kind']=='REBREAK' and e4['event_ts']==130.0 and e4['contract_ready'] is True and k4!=k1
p=load('pv1170',root/'paper_bot_v1.037.py')
assert p.VERSION=='paper_bot_v1.037'
ev={'swing_entry_gate_v977':{'schema':'swing_entry_gate_v977_single_owner','trigger_occurrence':e4}}
fresh=p.trigger_occurrence_freshness(ev,{'candidate_ttl_sec':120},nowv=140.0)
stale=p.trigger_occurrence_freshness(ev,{'candidate_ttl_sec':5},nowv=140.0)
assert fresh['fresh'] is True and fresh['code']=='FRESH_QUALIFIED_TRIGGER_OCCURRENCE'
assert stale['fresh'] is False and stale['code']=='STALE_TRIGGER_OCCURRENCE'
fb=p._v1159_record_trigger_terminal_feedback(ev,stale)
assert fb['recorded'] is False and fb['recovery_mode_v1170'] is True
print('PASS')
