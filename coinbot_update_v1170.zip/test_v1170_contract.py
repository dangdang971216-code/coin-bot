from pathlib import Path
import ast
root=Path(__file__).resolve().parent
s=(root/'strategy_worker_v1.029.py').read_text(encoding='utf-8')
p=(root/'paper_bot_v1.037.py').read_text(encoding='utf-8')
assert "VERSION = 'strategy_worker_v1.029'" in s
assert "VERSION = 'paper_bot_v1.037'" in p
assert 'apply_swing_entry_gate__v1170_recovery' in s
assert '_v1037_trigger_occurrence__v1170_recovery' in s
assert "'quality_final_hard_block_v1039':False" in s
assert "'quality_metric_role_v1039':'score_priority_record_only'" in s
assert "quality_gate_v1170['enforced'] = False" in s
assert "quality_gate_v1170['hard_pass'] = True" in s
assert "'schema':'swing_entry_gate_v977_single_owner'" in s
assert "'recovery_mode_v1170':True" in s
assert "ctrl_effective['paper_final_reaction_proof_enabled']=False" in p
assert 'v1170_exact_event_expired_without_strategy_terminal_lock' in p
assert 'ACTUAL_ENTRY_RR_LOW' in p and 'SLIPPAGE_STALE' in p and 'SPREAD_OVER_LIMIT' in p
lock=(root/'docs/V1170_WORK_LOCK.json').read_text(encoding='utf-8')
assert 'OPEN 30/cycle 3' in lock and 'current Main/Guard map UI' in lock
ast.parse(s); ast.parse(p)
print('PASS')
