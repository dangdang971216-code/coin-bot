v2073: /version_score current epoch CLOSED connection + trade latency + Guard paper verify-scope repair. No strategy/entry/exit numeric change. Auto-buy OFF.
