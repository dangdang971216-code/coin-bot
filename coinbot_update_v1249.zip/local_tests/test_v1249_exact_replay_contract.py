import hashlib
import importlib.util
import json
import tempfile
import unittest
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))


def load_module(name: str, path: Path):
    spec = importlib.util.spec_from_file_location(name, path)
    module = importlib.util.module_from_spec(spec)
    assert spec.loader is not None
    spec.loader.exec_module(module)
    return module


worker = load_module("exact_replay_worker_v1249_test", ROOT / "exact_replay_worker_v0.1.py")
main = load_module("coinbot_main_v1249_test", ROOT / "coinbot_main_v2_13_1154.py")


def dump_json(path: Path, obj):
    path.write_text(json.dumps(obj, ensure_ascii=False, separators=(",", ":")), encoding="utf-8")


def append_jsonl(path: Path, obj):
    with path.open("a", encoding="utf-8") as handle:
        handle.write(json.dumps(obj, ensure_ascii=False, separators=(",", ":")) + "\n")


def digest(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


class Fixture:
    def __init__(self, base: Path):
        self.base = base
        dump_json(base / "paper_bot_open.json", {})
        dump_json(base / "paper_decision_state_v926.json", {"records": {}})
        dump_json(base / "paper_exit_replay_status_v1242.json", {
            "schema": "paper_exit_replay_status_v1242",
            "state": "NORMAL",
            "poll_records": 0,
            "close_commit_ok": 0,
            "evidence_append_failures": 0,
        })
        for name in (
            "paper_bot_closed.jsonl",
            "paper_exit_replay_close_v1242.jsonl",
            "paper_exit_replay_poll_v1242.jsonl",
        ):
            (base / name).write_text("", encoding="utf-8")

    def add_trade(
        self,
        key: str,
        prices,
        reason: str,
        current_invalid: float = 95.0,
        current_target: float = 110.0,
        previous_invalid: float = 92.0,
        previous_target: float = 115.0,
        previous_exact: bool = True,
        poll_target=None,
        poll_invalid=None,
        digest_value=None,
        timestamps=None,
        sealed_cost: float = 0.1,
        poll_cost: float = 0.1,
        include_poll: bool = True,
        include_closed_key: bool = True,
        close_action: str = "close",
        link_commit_ok: bool = True,
    ):
        digest_value = digest_value or f"CD-{key}"
        result_key = f"closed:{key}"
        timestamps = timestamps or [1000.0 + i * 10.0 for i in range(len(prices))]
        nets = [((float(price) / 100.0) - 1.0) * 100.0 - poll_cost for price in prices]
        mfes = []
        maes = []
        peak = -poll_cost
        trough = -poll_cost
        for value in nets:
            peak = max(peak, value)
            trough = min(trough, value)
            mfes.append(peak)
            maes.append(trough)
        pos_id = f"P-{key}"
        closed = {
            "paper_decision_key_v926": key if include_closed_key else "",
            "ticker": "AAA",
            "pos_id": pos_id,
            "opened_at": timestamps[0],
            "closed_ts": timestamps[-1],
            "entry_price": 100.0,
            "exit_price": prices[-1],
            "exit_reason": reason,
            "closed_result_key": result_key,
            "net_after_configured_fee_pct_v983": nets[-1],
            "gross_pnl_pct_v983": ((prices[-1] / 100.0) - 1.0) * 100.0,
            "mfe_pct_v983": mfes[-1],
            "mae_pct_v983": maes[-1],
            "giveback_pct_v983": max(0.0, mfes[-1] - nets[-1]),
            "hold_sec": timestamps[-1] - timestamps[0],
            "configured_roundtrip_fee_pct_v983": sealed_cost,
            "exit_replay_contract_digest_v1242": digest_value,
            "structure_contract_version": "v1212",
            "structure_contract_hash": f"H-{key}",
            "dynamic_structure_plan_v1212": {
                "schema": "plan",
                "trigger": {"price": 100.0},
                "invalid": {"price": current_invalid},
                "target": {"price": current_target},
            },
            "v1211_structure_shadow_v1222": {
                "schema": "plan",
                "trigger": {"price": 100.0},
                "invalid": {"price": previous_invalid},
                "target": {"price": previous_target},
                "source_exact": previous_exact,
            },
        }
        append_jsonl(self.base / "paper_bot_closed.jsonl", closed)
        append_jsonl(self.base / "paper_exit_replay_close_v1242.jsonl", {
            "schema": "paper_exit_replay_close_link_v1242",
            "decision_key": key,
            "poll_key": f"{key}-K{len(prices)-1}",
            "contract_digest": digest_value,
            "commit_ok": link_commit_ok,
            "exit_reason": reason,
            "closed_ts": timestamps[-1],
            "closed_result_key": result_key,
            "pnl_pct": nets[-1],
        })
        if include_poll:
            rows = []
            for index, (price, ts, net, mfe, mae) in enumerate(zip(prices, timestamps, nets, mfes, maes)):
                rows.append({
                    "k": f"{key}-K{index}",
                    "p": pos_id,
                    "t": "AAA",
                    "ts": ts,
                    "ot": timestamps[0],
                    "dk": key,
                    "cd": digest_value,
                    "pr": price,
                    "en": 100.0,
                    "net": net,
                    "mfe": mfe,
                    "mae": mae,
                    "age": (ts - timestamps[0]) / 60.0,
                    "a": close_action if index == len(prices)-1 else "hold",
                    "r": reason if index == len(prices)-1 else "hold",
                    "tg": current_target if poll_target is None else poll_target,
                    "iv": current_invalid if poll_invalid is None else poll_invalid,
                    "sp": 98.0,
                    "bs": 0,
                    "ws": 0 if index < len(prices)-1 else 3,
                    "st": 1,
                    "wk": 0 if index < len(prices)-1 else 4,
                    "scv": "v1212",
                    "sch": f"H-{key}",
                })
            append_jsonl(self.base / "paper_exit_replay_poll_v1242.jsonl", {"records": rows})
        state = json.loads((self.base / "paper_decision_state_v926.json").read_text(encoding="utf-8"))
        state["records"][key] = {"status": "CLOSED", "paper_decision_key_v926": key}
        dump_json(self.base / "paper_decision_state_v926.json", state)
        status = json.loads((self.base / "paper_exit_replay_status_v1242.json").read_text(encoding="utf-8"))
        status["poll_records"] += len(prices) if include_poll else 0
        status["close_commit_ok"] += 1 if link_commit_ok else 0
        dump_json(self.base / "paper_exit_replay_status_v1242.json", status)
        return closed

    def run(self, rebuild=True):
        return worker.process_once(self.base, rebuild=rebuild)["snapshot"]


class V1249ExactReplayContract(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.base = Path(self.tmp.name)
        self.fx = Fixture(self.base)

    def tearDown(self):
        self.tmp.cleanup()

    def row(self, snap, key):
        return next(row for row in snap["rows"] if row["decision_key"] == key)

    def test_generic_paper_close_transfers_exactly(self):
        self.fx.add_trade("D1", [100.0, 104.0, 101.0], "swing_dynamic_momentum_decay")
        row = self.row(self.fx.run(), "D1")
        self.assertEqual(row["replay_state"], "EXACT_REPLAYABLE")
        self.assertEqual(row["arms"]["previous_structure_same_paper"]["close_poll_key"], "D1-K2")
        self.assertEqual(row["arms"]["previous_structure_same_paper"]["metric_basis"], "PAPER_POLL_SEALED_STATE")

    def test_structure_close_is_censored_when_previous_line_not_touched(self):
        self.fx.add_trade("D2", [100.0, 106.0, 110.0], "structure_target")
        row = self.row(self.fx.run(), "D2")
        self.assertEqual(row["replay_state"], "PARTIAL_CURRENT_EXACT_PREVIOUS_CENSORED")
        self.assertEqual(row["comparison"]["winner"], "NOT_COMPARABLE")

    def test_previous_line_touch_before_actual_close_is_exact(self):
        self.fx.add_trade(
            "D3", [100.0, 94.0, 110.0], "structure_target",
            current_invalid=90.0, previous_invalid=96.0,
        )
        row = self.row(self.fx.run(), "D3")
        self.assertEqual(row["replay_state"], "EXACT_REPLAYABLE")
        arm = row["arms"]["previous_structure_same_paper"]
        self.assertEqual(arm["close_poll_key"], "D3-K1")
        self.assertEqual(arm["exit_reason"], "INVALID")
        self.assertAlmostEqual(arm["mfe_pct"], -0.1, places=6)
        self.assertAlmostEqual(arm["mae_pct"], -6.1, places=6)

    def test_missing_poll_remains_not_replayable(self):
        self.fx.add_trade("D4", [100.0, 101.0], "swing_dynamic_momentum_decay", include_poll=False)
        row = self.row(self.fx.run(), "D4")
        self.assertEqual(row["replay_state"], "NOT_REPLAYABLE")
        self.assertIn("POLL_SEQUENCE_MISSING", row["issues"])

    def test_duplicate_closed_and_close_link_are_ambiguous(self):
        closed = self.fx.add_trade("D5", [100.0, 101.0], "swing_dynamic_momentum_decay")
        append_jsonl(self.base / "paper_bot_closed.jsonl", closed)
        append_jsonl(self.base / "paper_exit_replay_close_v1242.jsonl", {
            "decision_key": "D5", "poll_key": "D5-K1", "contract_digest": "CD-D5",
            "commit_ok": True, "exit_reason": "swing_dynamic_momentum_decay", "closed_ts": 1010.0,
        })
        row = self.row(self.fx.run(), "D5")
        self.assertEqual(row["replay_state"], "AMBIGUOUS")
        self.assertIn("DUPLICATE_CLOSED_ROWS", row["issues"])
        self.assertIn("DUPLICATE_CLOSE_LINKS", row["issues"])

    def test_same_ticker_and_pos_do_not_replace_missing_decision_key(self):
        self.fx.add_trade("D6", [100.0, 101.0], "swing_dynamic_momentum_decay", include_closed_key=False)
        snap = self.fx.run()
        row = self.row(snap, "D6")
        self.assertEqual(row["replay_state"], "NOT_REPLAYABLE")
        self.assertIn("CLOSED_ROW_MISSING", row["issues"])
        self.assertEqual(snap["counts"]["closed_missing_decision_key"], 1)
        self.assertEqual(snap["counts"]["close_link_without_closed"], 1)
        self.assertTrue(snap["invariants"]["ticker_pos_time_join_used"] is False)

    def test_historical_closed_without_poll_link_is_visible_not_replayable(self):
        closed = self.fx.add_trade("DOLD", [100.0, 101.0], "swing_dynamic_momentum_decay")
        # Simulate a pre-v1242 CLOSED row: keep the CLOSED ledger but remove the
        # poll and close-link evidence files.
        (self.base / "paper_exit_replay_close_v1242.jsonl").write_text("", encoding="utf-8")
        (self.base / "paper_exit_replay_poll_v1242.jsonl").write_text("", encoding="utf-8")
        snap = self.fx.run()
        row = self.row(snap, "DOLD")
        self.assertEqual(row["replay_state"], "NOT_REPLAYABLE")
        self.assertIn("CLOSE_LINK_MISSING", row["issues"])
        self.assertEqual(snap["counts"]["closed_without_close_link"], 1)

    def test_digest_line_timestamp_and_cost_mismatches_fail_closed(self):
        self.fx.add_trade("D7", [100.0, 101.0], "swing_dynamic_momentum_decay", poll_target=111.0)
        self.fx.add_trade("D8", [100.0, 101.0], "swing_dynamic_momentum_decay", timestamps=[1000.0, 990.0])
        self.fx.add_trade("D9", [100.0, 101.0], "swing_dynamic_momentum_decay", sealed_cost=0.1, poll_cost=0.2)
        snap = self.fx.run()
        d7, d8, d9 = self.row(snap, "D7"), self.row(snap, "D8"), self.row(snap, "D9")
        self.assertEqual(d7["replay_state"], "AMBIGUOUS")
        self.assertIn("SEALED_CURRENT_LINE_POLL_MISMATCH", d7["issues"])
        self.assertEqual(d8["replay_state"], "AMBIGUOUS")
        self.assertIn("POLL_TS_REVERSED", d8["issues"])
        self.assertEqual(d9["replay_state"], "AMBIGUOUS")
        self.assertIn("SEALED_COST_POLL_NET_MISMATCH", d9["issues"])

    def test_inputs_are_read_only_and_incremental_second_run_adds_nothing(self):
        self.fx.add_trade("D10", [100.0, 102.0, 101.0], "swing_dynamic_momentum_decay")
        source_names = [
            "paper_bot_closed.jsonl", "paper_exit_replay_close_v1242.jsonl",
            "paper_exit_replay_poll_v1242.jsonl", "paper_bot_open.json",
            "paper_decision_state_v926.json", "paper_exit_replay_status_v1242.json",
        ]
        before = {name: digest(self.base / name) for name in source_names}
        first = self.fx.run(rebuild=True)
        second = self.fx.run(rebuild=False)
        after = {name: digest(self.base / name) for name in source_names}
        self.assertEqual(before, after)
        self.assertEqual(second["ingestion_this_cycle"]["closed_added"], 0)
        self.assertEqual(second["ingestion_this_cycle"]["close_links_added"], 0)
        self.assertEqual(second["ingestion_this_cycle"]["poll_records_added"], 0)
        self.assertEqual(first["counts"]["replay_results"], second["counts"]["replay_results"])

    def test_main_and_guard_expose_read_only_board(self):
        snapshot = {
            "state": "PARTIAL_EXACT_AND_UNRESOLVED",
            "source_status_v1242": {"poll_records": 10},
            "counts": {
                "close_links_indexed": 2, "replay_results": 2, "current_actual_exact": 2,
                "complete_current_previous_exact": 1, "unresolved_or_partial": 1,
                "state_counts": {"PARTIAL_CURRENT_EXACT_PREVIOUS_CENSORED": 1},
            },
            "metrics": {
                "current_structure_actual_paper": {"n": 2, "wins": 1, "losses": 1, "total_net_pct": 0.2, "avg_net_pct": 0.1},
                "previous_structure_same_paper_exact_only": {"n": 1, "wins": 1, "losses": 0, "total_net_pct": 0.3, "avg_net_pct": 0.3},
            },
            "comparability": {"winner_allowed": False, "exact_pair_rows": 1},
        }
        text = "\n".join(main._exact_replay_lines(snapshot))
        self.assertIn("승자 판정: 금지", text)
        self.assertIn("자동매수 OFF", text)
        self.assertIn("exact_replay", main.COMMANDS)
        guard_text = (ROOT / "backga_guard_bot_v2_5_228.py").read_text(encoding="utf-8")
        self.assertIn('"exact_replay": {"label": "정확청산복기"', guard_text)
        self.assertIn('tradingbot-exact-replay-worker', guard_text)
        self.assertIn('guard_v2.5.228_v1249_exact_replay_worker_delivery', guard_text)

    def test_no_live_trading_owner_changed_in_bundle(self):
        worker_text = (ROOT / "exact_replay_worker_v0.1.py").read_text(encoding="utf-8")
        main_text = (ROOT / "coinbot_main_v2_13_1154.py").read_text(encoding="utf-8")
        self.assertNotIn("AUTO_BUY = True", worker_text)
        self.assertIn('"paper_writer_changed": False', worker_text)
        self.assertNotIn("paper_bot_closed.jsonl\", \"w", worker_text)
        self.assertNotIn("paper_exit_replay_poll_v1242.jsonl\", \"w", worker_text)
        self.assertIn('BOT_VERSION = "수익형 v2.13.1154"', main_text)
        self.assertNotIn("append_jsonl", main_text)


if __name__ == "__main__":
    unittest.main(verbosity=2)
