import hashlib
import json
import unittest
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]


class V1249BundleContract(unittest.TestCase):
    def test_manifest_declared_files_exist(self):
        manifest = json.loads((ROOT / "DEPLOY_BUNDLE.json").read_text(encoding="utf-8"))
        declared = [manifest["guard"], manifest["main"]]
        declared += list(manifest["workers"].values())
        declared += list(manifest["support_files"])
        for values in manifest["ledger_event_files"].values():
            declared += list(values)
        missing = [name for name in declared if not (ROOT / name).is_file()]
        self.assertEqual(missing, [])

    def test_manifest_is_read_only_trading_contract(self):
        manifest = json.loads((ROOT / "DEPLOY_BUNDLE.json").read_text(encoding="utf-8"))
        for key in (
            "actual_trading_changed", "strategy_values_changed", "candidate_rank_changed",
            "s1_decision_changed", "entry_changed", "exit_changed",
            "existing_open_contract_changed", "paper_writer_changed",
            "review_writer_changed", "strategy_writer_changed",
        ):
            self.assertIs(manifest[key], False, key)
        self.assertIs(manifest["auto_buy"], False)
        self.assertEqual(manifest["workers"], {"exact_replay": "exact_replay_worker_v0.1.py"})

    def test_versions_and_owner_paths(self):
        worker = (ROOT / "exact_replay_worker_v0.1.py").read_text(encoding="utf-8")
        main = (ROOT / "coinbot_main_v2_13_1154.py").read_text(encoding="utf-8")
        guard = (ROOT / "backga_guard_bot_v2_5_228.py").read_text(encoding="utf-8")
        self.assertIn('VERSION = "exact_replay_worker_v0.1"', worker)
        self.assertIn('BOT_VERSION = "수익형 v2.13.1154"', main)
        self.assertIn('EXACT_REPLAY_PATH = BASE_DIR / "canonical_paper_exact_replay_v1249.json"', main)
        self.assertIn('VERSION = "guard_v2.5.228_v1249_exact_replay_worker_delivery_2026-07-05"', guard)
        self.assertIn('"active": "exact_replay_worker.py"', guard)
        self.assertIn('"service": "tradingbot-exact-replay-worker"', guard)

    def test_main_does_not_read_raw_exact_ledgers(self):
        main = (ROOT / "coinbot_main_v2_13_1154.py").read_text(encoding="utf-8")
        self.assertNotIn("paper_exit_replay_poll_v1242.jsonl", main)
        self.assertNotIn("paper_exit_replay_close_v1242.jsonl", main)
        self.assertNotIn("paper_bot_closed.jsonl", main)
        self.assertIn("canonical_paper_exact_replay_v1249.json", main)

    def test_pending_ledger_events_have_required_ids(self):
        manifest = json.loads((ROOT / "DEPLOY_BUNDLE.json").read_text(encoding="utf-8"))
        for kind, paths in manifest["ledger_event_files"].items():
            for rel in paths:
                rows = [json.loads(line) for line in (ROOT / rel).read_text(encoding="utf-8").splitlines() if line.strip()]
                self.assertTrue(rows, rel)
                for row in rows:
                    if kind == "issue":
                        self.assertTrue(str(row.get("issue_id") or "").strip(), (rel, row))
                    else:
                        self.assertTrue(str(row.get("change_id") or row.get("issue_id") or "").strip(), (rel, row))

    def test_no_live_ledgers_packaged(self):
        forbidden = {
            "paper_bot_open.json", "paper_bot_closed.jsonl", "paper_bot_trade_log.jsonl",
            "paper_decision_state_v926.json", "issue_ledger.jsonl", "change_verify_ledger.jsonl",
            "paper_exit_replay_poll_v1242.jsonl", "paper_exit_replay_close_v1242.jsonl",
        }
        present = {path.name for path in ROOT.rglob("*") if path.is_file()}
        self.assertEqual(sorted(forbidden & present), [])

    def test_hash_manifest(self):
        table = ROOT / "FILES_SHA256_v1249.tsv"
        if not table.exists():
            self.skipTest("hash table is generated after local test stage")
        for line in table.read_text(encoding="utf-8").splitlines():
            if not line.strip():
                continue
            expected, rel = line.split("\t", 1)
            path = ROOT / rel
            self.assertTrue(path.is_file(), rel)
            actual = hashlib.sha256(path.read_bytes()).hexdigest()
            self.assertEqual(actual, expected, rel)


if __name__ == "__main__":
    unittest.main(verbosity=2)
