v2122: existing direct handoff only. Sealed Strategy write proof, per-runtime build truth, inactive cleanup permission skip. No trading change. Auto-buy OFF.
