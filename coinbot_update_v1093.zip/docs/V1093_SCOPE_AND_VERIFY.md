# v1093 승률 코드원인·후보품질·OPEN 통합감사

## 목적
최근 승률 하락이 단순 시장 변화인지, 현재 본선 코드 계약과 후보/OPEN 과밀 구조에서 비롯됐는지 먼저 읽기 전용으로 증명한다.

## 변경 파일
- Guard v2.5.147: canonical audit snapshot 단일 writer 및 /gquality_open_audit_v1093
- Main v2.13.1080: snapshot read-only /quality_open_audit

## 감사 범위
1. 현재 active Paper/Strategy의 최종 selector 계약
2. canonical exact CLOSED 최근24h·최근20/50/100·전체
3. actual-entry RR, 진입 당시 OPEN 수, cycle 신규 순번, source lane, slippage/build cohort
4. 현재 OPEN의 actual RR, 중복 ticker/key, 품질·실행값 누락
5. 현재 S1 후보의 상대강도30·구조/반응30·돈흐름25·실행15 shadow 순위
6. 기록된 거래만 이용한 OPEN<20/30/50, cycle<=2/3 분석용 비교

## 절대 비변경
- Strategy/Paper/Risk/Review worker 코드 변경 없음
- trigger/invalid/target/RR/품질 threshold/OPEN 한도 변경 없음
- OPEN/CLOSED/trade_log/decision/exact/performance 원장 변경 없음
- 자동매수 OFF

## 적용 후
Guard: /gquality_open_audit_v1093
Main: /quality_open_audit /errorlog
Paper: /pstatus /perror
