coinbot_update_v1437.zip

목적: 후보수를 억지로 늘리지 않고, S3/관찰에 묻힌 좋은 상승 후보만 shadow로 회수 검증합니다.

변경:
- Strategy: Review에서 오른 S3/coverage_buried 후보를 읽고 hard risk와 회수관찰을 분리
- Strategy: 매매불가성 높은 후보는 제외, 살아남은 후보만 데이터 재확인 shadow 요청
- Main: /buried_shadow /s3_upside_shadow /candidate_buried_shadow /candidate_recovery_shadow /entry_shadow 추가
- /profit_shadow와 /version_score에 묻힌 후보 회수 요약 추가

금지/잠금:
- 후보수를 강제 증가하지 않음
- 실제 S1 승격 없음
- Paper 실제 진입/OPEN 생성 없음
- Gate/TTL/RR/trigger/invalid/target/청산계약 변경 없음
- OPEN/CLOSED/decision/exact 원장 재작성 없음
- 자동매수 OFF
