#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""target_router_worker_v0.2

정보배차 직원 v0.2.
목표:
- 정보부족 전체를 한꺼번에 WS/micro target으로 밀어넣지 않는다.
- 전체 후보 queue는 보존하되, sidecar가 실제 우선수집할 active target은 우선순위 높은 후보 중심으로 분리한다.
- 개수 고정 전략이 아니라, 우선순위/버킷/서버보호 active window를 분리한다.
"""
from __future__ import annotations
import json, os, time, traceback
from pathlib import Path
from typing import Any, Dict, List, Optional

BASE_DIR = Path(os.getenv("TRADING_BOT_DIR", "/home/dangdang971216/trading_bot"))
VERSION = "target_router_worker_v0.2"
INTERVAL_SEC = float(os.getenv("TARGET_ROUTER_INTERVAL_SEC", "1.5"))
# 서버보호용 active window. 후보 제한 조건이 아니라 sidecar에 한 번에 넘기는 처리창이다.
ACTIVE_WINDOW = int(float(os.getenv("TARGET_ROUTER_ACTIVE_WINDOW", "140")))
HIGH_PRIORITY_THRESHOLD = float(os.getenv("TARGET_ROUTER_HIGH_PRIORITY", "85"))
HOT_ROTATION_THRESHOLD = float(os.getenv("TARGET_ROUTER_HOT_ROTATION_PRIORITY", "72"))
STATUS = BASE_DIR / "clean_target_router_status.json"
ERROR = BASE_DIR / "clean_target_router_error.log"
STRATEGY_REQ = BASE_DIR / "clean_strategy_priority_requests.json"
FEATURE = BASE_DIR / "clean_feature_cache.json"
ORDERFLOW = BASE_DIR / "clean_orderflow_summary_cache.json"
PAPER_OPEN = BASE_DIR / "paper_bot_open.json"
QUEUE = BASE_DIR / "clean_target_router_queue.json"
WS_TARGETS = BASE_DIR / "clean_ws_targets.json"
MICRO_TARGETS = BASE_DIR / "clean_micro_targets.json"
MICRO_URGENT = BASE_DIR / "clean_micro_urgent_targets.json"

CRITICAL_BUCKETS = {"open_position", "s_candidate", "paper_handoff", "near_s_info_wait", "s_near_info"}
HIGH_BUCKETS = {"info_wait_high", "high_score_info_wait"}
LOW_BUCKETS = {"market_rotation", "normal_rotation", "normal_info_wait", "hard_blocked_info_wait"}


def now_ts() -> float:
    return time.time()

def now_text(ts: Optional[float] = None) -> str:
    return time.strftime("%Y-%m-%d %H:%M:%S", time.localtime(ts or now_ts()))

def fnum(*vals: Any, default: float = 0.0) -> float:
    for v in vals:
        try:
            if v is None or v == "":
                continue
            return float(str(v).replace(",", "").replace("%", ""))
        except Exception:
            continue
    return default

def ticker_norm(x: Any) -> str:
    t = str(x or "").strip().upper().replace("/", "-").replace("_", "-")
    parts = [p for p in t.split("-") if p]
    if len(parts) >= 2:
        non = [p for p in parts if p != "KRW"]
        t = non[-1] if non else parts[-1]
    if t.endswith("KRW") and len(t) > 3:
        t = t[:-3]
    return t.strip().upper()

def load_json(path: Path, default: Any = None) -> Any:
    try:
        if not path.exists():
            return default
        return json.loads(path.read_text(encoding="utf-8", errors="ignore"))
    except Exception:
        return default

def save_json(path: Path, obj: Any) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    tmp = path.with_suffix(path.suffix + ".tmp")
    tmp.write_text(json.dumps(obj, ensure_ascii=False, separators=(",", ":"), default=str), encoding="utf-8")
    os.replace(tmp, path)

def append_error(where: str, exc: BaseException) -> None:
    try:
        ERROR.parent.mkdir(parents=True, exist_ok=True)
        with ERROR.open("a", encoding="utf-8") as f:
            f.write(f"[{now_text()}] {where}: {exc.__class__.__name__}: {exc}\n")
            f.write(traceback.format_exc()[-1600:] + "\n")
    except Exception:
        pass

def write_status(state: str, **extra: Any) -> None:
    save_json(STATUS, {"version": VERSION, "state": state, "pid": os.getpid(), "updated_ts": now_ts(), "updated_text": now_text(), **extra})

def map_rows(obj: Any) -> Dict[str, Dict[str, Any]]:
    if isinstance(obj, dict) and isinstance(obj.get("rows"), list):
        obj = obj.get("rows")
    elif isinstance(obj, dict) and isinstance(obj.get("rows"), dict):
        obj = obj.get("rows")
    elif isinstance(obj, dict) and isinstance(obj.get("cache"), dict):
        obj = obj.get("cache")
    out: Dict[str, Dict[str, Any]] = {}
    if isinstance(obj, list):
        for r in obj:
            if isinstance(r, dict):
                t = ticker_norm(r.get("ticker") or r.get("symbol") or r.get("market"))
                if t:
                    vv = dict(r); vv.setdefault("ticker", t)
                    out[t] = vv
    elif isinstance(obj, dict):
        for k, v in obj.items():
            if isinstance(v, dict):
                t = ticker_norm(k)
                vv = dict(v); vv.setdefault("ticker", t)
                out[t] = vv
    return out

def _open_tickers() -> List[str]:
    obj = load_json(PAPER_OPEN, {}) or {}
    out: List[str] = []
    if isinstance(obj, dict):
        values = obj.get("positions") if isinstance(obj.get("positions"), list) else obj.values()
        for r in values:
            if isinstance(r, dict):
                t = ticker_norm(r.get("ticker") or r.get("market") or r.get("symbol"))
                if t:
                    out.append(t)
    return out

def _request_rows() -> List[Dict[str, Any]]:
    obj = load_json(STRATEGY_REQ, {}) or {}
    rows = obj.get("requests") if isinstance(obj, dict) else []
    return rows if isinstance(rows, list) else []

def _feature_priority(features: Dict[str, Dict[str, Any]]) -> List[Dict[str, Any]]:
    out = []
    for t, r in features.items():
        score = 6.0
        score += min(28.0, max(0.0, fnum(r.get("change_3m"), default=0.0) * 7))
        score += min(26.0, max(0.0, fnum(r.get("change_5m"), default=0.0) * 5))
        score += min(22.0, max(0.0, fnum(r.get("change_15m"), default=0.0) * 3))
        score += min(18.0, max(0.0, fnum(r.get("turnover_24h"), default=0.0) / 500_000_000))
        if r.get("volume_expanding"):
            score += 8
        if r.get("breakout_hint") or r.get("sweep_reclaim_hint"):
            score += 7
        bucket = "market_hot_rotation" if score >= HOT_ROTATION_THRESHOLD else "market_rotation"
        out.append({"ticker": t, "priority": round(score, 3), "bucket": bucket, "need": [], "source": "feature_rotation"})
    return out

def _bucket_counts(rows: List[Dict[str, Any]]) -> Dict[str, int]:
    d: Dict[str, int] = {}
    for r in rows:
        b = str(r.get("bucket") or "unknown")
        d[b] = d.get(b, 0) + 1
    return d

def build_queue() -> Dict[str, Any]:
    ts = now_ts()
    features = map_rows(load_json(FEATURE, {}) or {})
    orderflow = map_rows(load_json(ORDERFLOW, {}) or {})
    reqs = _request_rows()
    merged: Dict[str, Dict[str, Any]] = {}

    def add(row: Dict[str, Any], bonus: float = 0.0) -> None:
        t = ticker_norm(row.get("ticker") or row.get("market") or row.get("symbol"))
        if not t:
            return
        cur = dict(row)
        cur["ticker"] = t
        cur["priority"] = fnum(cur.get("priority"), default=0.0) + bonus
        cur["priority"] = round(cur["priority"], 3)
        of = orderflow.get(t, {})
        cur["ws_fresh"] = bool(of.get("ws_fresh"))
        cur["micro_fresh"] = bool(of.get("micro_fresh"))
        cur["fresh_ready"] = bool(cur["ws_fresh"] and cur["micro_fresh"])
        cur["updated_ts"] = ts
        old = merged.get(t)
        if old is None or fnum(cur.get("priority"), default=0) > fnum(old.get("priority"), default=0):
            merged[t] = cur

    # 1. OPEN은 항상 최상단.
    for t in _open_tickers():
        add({"ticker": t, "priority": 600, "bucket": "open_position", "need": ["ws", "micro"], "source": "paper_open"})

    # 2. strategy 요청은 이미 v0.7에서 S/S근접/high만 들어오게 줄인다.
    for r in reqs:
        bucket = str(r.get("bucket") or "strategy_request")
        base = fnum(r.get("priority"), default=50.0)
        if bucket in {"s_candidate", "paper_handoff"}:
            base += 500
        elif bucket in {"near_s_info_wait", "s_near_info"}:
            base += 420
        elif bucket in HIGH_BUCKETS:
            base += 180
        add({**r, "priority": base, "source": r.get("source") or "strategy"})

    # 3. 전체시장 순환은 queue에만 보존한다. active target에는 고점수/hot rotation만 일부 들어간다.
    for r in _feature_priority(features):
        add(r)

    rows = sorted(merged.values(), key=lambda x: (fnum(x.get("priority"), default=0.0), bool(x.get("fresh_ready"))), reverse=True)

    critical: List[Dict[str, Any]] = []
    high: List[Dict[str, Any]] = []
    rotation: List[Dict[str, Any]] = []
    for r in rows:
        b = str(r.get("bucket") or "")
        p = fnum(r.get("priority"), default=0.0)
        if b in CRITICAL_BUCKETS:
            critical.append(r)
        elif b in HIGH_BUCKETS or p >= HIGH_PRIORITY_THRESHOLD:
            high.append(r)
        elif b == "market_hot_rotation" and p >= HOT_ROTATION_THRESHOLD:
            rotation.append(r)

    # 서버 보호 active window. CRITICAL은 모두 포함하고, 나머지는 우선순위 순서대로 처리창에 태운다.
    active_rows: List[Dict[str, Any]] = []
    seen = set()
    for group in (critical, high, rotation):
        for r in group:
            t = str(r.get("ticker") or "")
            if not t or t in seen:
                continue
            if len(active_rows) >= ACTIVE_WINDOW and str(r.get("bucket")) not in CRITICAL_BUCKETS:
                continue
            rr = dict(r)
            rr["active_target"] = True
            active_rows.append(rr); seen.add(t)
    active_targets = [r.get("ticker") for r in active_rows if r.get("ticker")]
    urgent_rows = [r for r in active_rows if str(r.get("bucket")) in CRITICAL_BUCKETS]
    urgent_targets = [r.get("ticker") for r in urgent_rows if r.get("ticker")]

    def need_counts(rs: List[Dict[str, Any]]) -> tuple[int, int, int]:
        need_ws = need_micro = fresh_ready = 0
        for r in rs:
            need = r.get("need") if isinstance(r.get("need"), list) else []
            if "ws" in need and not r.get("ws_fresh"):
                need_ws += 1
            if "micro" in need and not r.get("micro_fresh"):
                need_micro += 1
            if r.get("fresh_ready"):
                fresh_ready += 1
        return need_ws, need_micro, fresh_ready

    need_ws, need_micro, fresh_recovered = need_counts(active_rows)
    near_s_count = sum(1 for r in active_rows if str(r.get("bucket")) in {"near_s_info_wait", "s_near_info"})
    payload = {
        "version": VERSION,
        "updated_ts": ts,
        "updated_text": now_text(ts),
        "queue_count": len(rows),
        "active_target_count": len(active_targets),
        "target_count": len(active_targets),  # 기존 화면 호환
        "backlog_count": max(0, len(rows) - len(active_rows)),
        "active_window": ACTIVE_WINDOW,
        "targets": active_targets,
        "active_targets": active_targets,
        "urgent_targets": urgent_targets,
        "rows": rows[:700],
        "active_rows": active_rows[:350],
        "urgent_rows": urgent_rows[:120],
        "buckets": _bucket_counts(rows),
        "active_buckets": _bucket_counts(active_rows),
        "fresh_recovered": fresh_recovered,
        "need_ws": need_ws,
        "need_micro": need_micro,
        "near_s_count": near_s_count,
        "critical_count": len(critical),
        "high_count": len(high),
        "rotation_count": len(rotation),
        "note": "v0.2: 전체 queue 보존 + sidecar active target 분리. active_window는 서버보호 처리창이며 전략 후보 개수 제한이 아님.",
    }
    save_json(QUEUE, payload)

    active_payload = {
        "version": VERSION,
        "updated_ts": ts,
        "updated_text": now_text(ts),
        "target_count": len(active_targets),
        "targets": active_targets,
        "rows": active_rows[:300],
        "queue_count": len(rows),
        "backlog_count": payload["backlog_count"],
        "active_buckets": payload["active_buckets"],
        "note": "active target only. 전체 queue는 clean_target_router_queue.json rows에 보존.",
    }
    urgent_payload = dict(active_payload)
    urgent_payload.update({"target_count": len(urgent_targets), "targets": urgent_targets, "rows": urgent_rows[:120], "note": "urgent: OPEN/S/S근접 후보 우선"})
    save_json(WS_TARGETS, active_payload)
    save_json(MICRO_TARGETS, active_payload)
    save_json(MICRO_URGENT, urgent_payload)

    write_status(
        "running",
        queue_count=len(rows), active_target_count=len(active_targets), target_count=len(active_targets),
        backlog_count=payload["backlog_count"], near_s_count=near_s_count, fresh_recovered=fresh_recovered,
        need_ws=need_ws, need_micro=need_micro, active_window=ACTIVE_WINDOW, last_sec=0,
    )
    return payload

def run_once() -> Dict[str, Any]:
    st = now_ts()
    p = build_queue()
    sec = now_ts() - st
    write_status(
        "running", queue_count=p.get("queue_count", 0), active_target_count=p.get("active_target_count", 0),
        target_count=p.get("target_count", 0), backlog_count=p.get("backlog_count", 0),
        near_s_count=p.get("near_s_count", 0), fresh_recovered=p.get("fresh_recovered", 0),
        need_ws=p.get("need_ws", 0), need_micro=p.get("need_micro", 0), active_window=p.get("active_window", ACTIVE_WINDOW),
        last_sec=round(sec, 3),
    )
    return p

def main() -> None:
    write_status("running", phase="boot", target_count=0, last_sec=0)
    while True:
        try:
            run_once()
        except KeyboardInterrupt:
            write_status("stopping")
            raise
        except Exception as exc:
            append_error("loop", exc)
            write_status("error", error=f"{exc.__class__.__name__}: {exc}")
        time.sleep(max(0.5, INTERVAL_SEC))

if __name__ == "__main__":
    main()
