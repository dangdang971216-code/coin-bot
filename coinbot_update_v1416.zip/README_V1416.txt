v1416 targeted strategy-only fix.
- Stops expired qualified trigger occurrences from reaching S1/Paper handoff.
- Same TTL value as Paper default; no threshold loosening.
- No guard/main/paper/micro/disk/full identity changes.
