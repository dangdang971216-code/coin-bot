from pathlib import Path
import importlib.util, json, os, tempfile, sys

def load(path,name):
    sys.path.insert(0, str(path.parent))
    try:
        spec=importlib.util.spec_from_file_location(name,path); m=importlib.util.module_from_spec(spec); spec.loader.exec_module(m); return m
    finally:
        if sys.path and sys.path[0] == str(path.parent): sys.path.pop(0)

def test_main_compact_renderer_exists_and_batch_builds():
    with tempfile.TemporaryDirectory() as td:
        os.environ['COINBOT_BASE_DIR']=td
        m=load(Path(__file__).parents[1]/'coinbot_main_v2_13_1160.py','main1258')
        assert callable(m.render_version_score_compact)
        text=m.build_summary_text([('version_score',[])],{'version_score':'ok'},[{'name':'version_score','sec':0.0,'ok':True}],0.1)
        assert '성과 요약' in text
        assert 'NameError' not in text

def test_paper_exact_generation_reader_has_no_scan_filter_or_tail_cap():
    text=(Path(__file__).parents[1]/'paper_bot_v1.075.py').read_text(encoding='utf-8')
    section=text.split('# v1258 - exact current-generation candidate confirmation',1)[1]
    assert 'latest_scan_filter(' not in section
    assert 'old_scan_id_filter_retired' in section
    assert 'old_tail_cap_retired' in section
    assert "paper_generation_candidate_count_v1158" in section

def test_versions_and_no_strategy_change_manifest():
    root=Path(__file__).parents[1]
    manifest=json.loads((root/'DEPLOY_BUNDLE.json').read_text(encoding='utf-8'))
    assert manifest['version']=='v1258'
    assert manifest['strategy_values_changed'] is False
    assert manifest['entry_changed'] is False
    assert manifest['exit_changed'] is False
    assert manifest['auto_buy'] is False
