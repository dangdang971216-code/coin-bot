from __future__ import annotations
import importlib.util, os, sys, tempfile, json
from pathlib import Path

BUILD=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(BUILD))

def load(name,file):
    spec=importlib.util.spec_from_file_location(name,BUILD/file)
    mod=importlib.util.module_from_spec(spec)
    sys.modules[name]=mod
    assert spec and spec.loader
    spec.loader.exec_module(mod)
    return mod

def strategy_row():
    return {
        'ticker':'TEST','open_eligible':True,'trigger_reached':True,'swing_gate_decision_key_v977':'d1',
        'structure_contract_version':'current','structure_contract_hash':'h1',
        'swing_entry_gate_v977':{'trigger_price':100.0,'invalid_price':95.0,'target_price':110.0},
        'swing_trigger_price_v977':100.0,'swing_invalid_price_v977':95.0,'swing_target_price_v977':110.0,
        'dynamic_structure_plan_v1212':{'target_reach_limit_pct':15.0},
        'v1211_structure_shadow_v1222':{
            'source_exact':True,'complete':True,
            'invalid':{'rounded_price':97.0,'source':'setup_support','tf':'30m'},
            'target':{'rounded_price':120.0,'source':'major_resistance','tf':'4h'},
        },
        'price_reaction_pct':0.1,'relative_strength_rank_pct_v1095':70.0,'money_flow_score':60.0,
        'buy_ratio':0.55,'buy_sustain_1m':0.50,'quality_observation_v925':{'extreme_quality_risk_tags':[]},
        'canonical_entry_decision':{},
    }

def test_strategy_contract_and_no_gate_change():
    m=load('strategy_v1257','strategy_worker_v1.060.py')
    row=strategy_row()
    m._V1257_BASE_APPLY_SWING_ENTRY_GATE=lambda rows,nowv:(rows,{'pass_s1':1})
    out,summary=m.apply_swing_entry_gate__v1257_unified([row],123.0)
    r=out[0]; c=r['unified_strategy_contract_v1257']; support=c['v1211_structural_support']
    assert r['open_eligible'] is True
    assert r['swing_entry_gate_v977']['trigger_price']==100.0
    assert r['swing_entry_gate_v977']['invalid_price']==95.0
    assert r['swing_entry_gate_v977']['target_price']==110.0
    assert support['early_failure_invalid_price']==97.0
    assert support['extension_target_price']==120.0
    assert c['entry_quality_support']['confirmed'] is True
    assert summary['candidate_pass_changed_v1257'] is False
    assert summary['global_rank_changed_v1257'] is False
    assert 'hybrid_entry_shadow_pass_v1234' not in r

def test_strategy_invalid_previous_lines_not_used():
    m=load('strategy_v1257_b','strategy_worker_v1.060.py')
    row=strategy_row(); row['v1211_structure_shadow_v1222']['invalid']['rounded_price']=94.0; row['v1211_structure_shadow_v1222']['target']['rounded_price']=108.0
    c=m._v1257_unified_contract(row,1.0)
    support=c['v1211_structural_support']
    assert support['early_failure_invalid_price'] is None
    assert support['extension_target_price'] is None

def test_paper_open_seals_new_only_and_existing_unchanged():
    m=load('paper_v1257','paper_bot_v1.075.py')
    base=strategy_row(); base['entry_price']=100.0
    sm=load('strategy_for_paper_v1257','strategy_worker_v1.060.py')
    base['unified_strategy_contract_v1257']=sm._v1257_unified_contract(base,1.0)
    m._V1257_PREV_OPEN_POSITION=lambda pos_id,ev:dict(ev)
    pos=m.open_position__v1257_unified('p1',base)
    assert pos['exit_contract_v1257']['schema']==m.V1257_EXIT_SCHEMA
    assert pos['exit_contract_v1257']['early_failure_line']['price']==97.0
    assert pos['exit_contract_v1257']['extension_target']['price']==120.0
    old={'ticker':'OLD','entry_price':100.0}
    pos2=m.open_position__v1257_unified('p2',old)
    assert 'exit_contract_v1257' not in pos2
    assert pos2['unified_contract_state_v1257']=='LEGACY_CANDIDATE_CONTRACT_PRESERVED'

def test_paper_early_failure_and_extension_paths():
    m=load('paper_v1257_paths','paper_bot_v1.075.py')
    contract={
        'schema':m.V1257_EXIT_SCHEMA,'original_invalid_price':95.0,'base_target_price':110.0,
        'early_failure_line':{'active':True,'price':97.0,'source':'x','timeframe':'30m'},
        'extension_target':{'active':True,'price':120.0},'strategy_contract_digest':'d',
    }
    # Early line
    pos={'entry_price':100.0,'current_price':96.5,'exit_contract_v1257':contract}
    m._V1257_PREV_EXIT_DECISION=lambda *a,**k:{'action':'hold','reason':''}
    d=m._exit_decision_spine__v1257(pos,1,0,-1,{})
    assert d['reason']=='swing_unified_entry_failure_v1257'
    # Base target with strong evidence arms extension
    pos={'entry_price':100.0,'current_price':111.0,'exit_contract_v1257':contract}
    m._V1257_PREV_EXIT_DECISION=lambda *a,**k:{'action':'close','reason':'structure_target'}
    m._v1257_extension_runtime=lambda *a,**k:{'state':{},'role':'general','usable':True,'strengths':3,'weaknesses':1,'support_intact':True,'keep':True,'evidence':{}}
    d=m._exit_decision_spine__v1257(pos,10,11,10,{})
    assert d['action']=='hold' and d['reason']=='unified_extension_armed_v1257'
    assert pos['extension_state_v1257']['armed'] is True
    # Extension target
    pos['current_price']=120.0
    d=m._exit_decision_spine__v1257(pos,11,20,19,{})
    assert d['action']=='close' and d['reason']=='structure_extension_target_v1257'

def test_paper_preserves_v1242_outer_owners_and_closed_contract():
    m=load('paper_v1257_owner','paper_bot_v1.075.py')
    assert m.process_open_positions_for_exit is m.process_open_positions_for_exit__v1242
    assert m.commit_closed_position_exact is m.commit_closed_position_exact__v1242
    m._V1257_PREV_FINALIZE_CLOSED=lambda pos,closed,ctrl,cycle,before:dict(closed)
    pos={'exit_contract_v1257':{'schema':m.V1257_EXIT_SCHEMA,'strategy_contract_digest':'d'},'unified_strategy_contract_v1257':{'schema':m.V1257_UNIFIED_SCHEMA},'extension_state_v1257':{'armed':True}}
    out=m.finalize_closed_position_metadata__v1257(pos,{'ticker':'X'},{},1,0)
    assert out['exit_contract_version_v1257']=='v1257'
    assert out['strategy_contract_digest_v1257']=='d'

def test_review_retires_experiment_writers():
    m=load('review_v1257','review_worker_v1.036.py')
    with tempfile.TemporaryDirectory() as td:
        base=Path(td)
        rows=[{'unified_strategy_contract_v1257':strategy_row()}]
        # use a correctly shaped contract
        rows=[{'unified_strategy_contract_v1257':{'schema':'unified_alt_swing_contract_v1257','ready':True,'v1211_structural_support':{'early_failure_invalid_price':97,'extension_target_price':120},'entry_quality_support':{'confirmed':True}}}]
        summary=m.update_version_score_review(base,rows,generation={'cycle_id':'c','candidate_commit_id':'k'},generation_integrity={'ok':True})
        assert summary['retired_experiments_v1257']['new_state_writes'] is False
        assert summary['unified_strategy_v1257']['contract_rows']==1
        assert not (base/'version_score_review_state_v1237.json').exists()
        saved=json.loads((base/'canonical_version_score_review_v1237.json').read_text())
        assert 'hybrid_surgery_v1234' not in saved

def test_main_public_commands_single_strategy():
    m=load('main_v1257','coinbot_main_v2_13_1160.py')
    for retired in ('hybrid_score','policy_score','pair_matchup','exact_replay','policy_matchup','structure_rebuild'):
        assert retired not in m.COMMANDS
    for required in ('strategy_final','version_score','flow_map_full','candidate_standard'):
        assert required in m.COMMANDS
    assert m.BOT_VERSION=='수익형 v2.13.1160'

def test_guard_retires_workers_from_required_specs():
    m=load('guard_v1257','backga_guard_bot_v2_5_236.py')
    assert 'policy_competition' not in m.WORKER_SPECS
    assert 'structure_rebuild' not in m.WORKER_SPECS
    calls=[]
    m.run=lambda cmd,timeout=0:(calls.append(cmd) or (0,''))
    m.is_service_active=lambda name:'inactive'
    ok,notes=m._retire_services_v1257(['tradingbot-policy-competition-worker','tradingbot-structure-rebuild-worker'])
    assert ok and len(notes)==2
    assert any('disable' in c for c in calls)

def test_main_default_bundle_has_no_retired_experiment_commands():
    m=load('main_v1257_batch','coinbot_main_v2_13_1160.py')
    retired={'hybrid_score','policy_score','pair_matchup','exact_replay','policy_matchup','structure_rebuild'}
    assert not (retired & set(m.BATCH_DEFAULT))
    assert not (retired & set(m.BATCH_FULL))
    assert {'strategy_final','version_score','flow_map_full','candidate_standard'} <= set(m.BATCH_DEFAULT)


def test_guard_deploy_board_and_continuation_retire_contract_present():
    source=(BUILD/'backga_guard_bot_v2_5_236.py').read_text(encoding='utf-8')
    assert '🧹 폐기 worker' in source
    assert "if manifest.get('retire_services'):\n            retire_ok, retire_notes = _retire_services_v1257" in source
    assert "retired_ok,retired_rows=_verify_retired_services_v1257" in source
    assert 'tradingbot-policy-competition-worker' in source
    assert 'tradingbot-structure-rebuild-worker' in source


def test_final_bindings_are_last_public_assignments():
    strategy=(BUILD/'strategy_worker_v1.060.py').read_text(encoding='utf-8')
    paper=(BUILD/'paper_bot_v1.075.py').read_text(encoding='utf-8')
    assert strategy.rfind('apply_swing_entry_gate = apply_swing_entry_gate__v1257_unified') > strategy.rfind('apply_swing_entry_gate = apply_swing_entry_gate__v1234')
    assert paper.rfind('open_position = open_position__v1257_unified') > paper.rfind('open_position = open_position__v1207_dynamic_exit')
    assert paper.rfind('_exit_decision_spine = _exit_decision_spine__v1257') > paper.rfind('_exit_decision_spine = _exit_decision_spine__v1207')
    assert paper.rfind('process_open_positions_for_exit = process_open_positions_for_exit__v1242') > -1
    assert paper.rfind('commit_closed_position_exact = commit_closed_position_exact__v1242') > -1

def test_main_and_review_have_single_public_writers_and_no_retired_pin():
    import ast
    main_source=(BUILD/'coinbot_main_v2_13_1160.py').read_text(encoding='utf-8')
    review_source=(BUILD/'review_worker_v1.036.py').read_text(encoding='utf-8')
    main_tree=ast.parse(main_source); review_tree=ast.parse(review_source)
    assert sum(isinstance(n,ast.FunctionDef) and n.name=='render_version_score' for n in main_tree.body)==1
    assert sum(isinstance(n,ast.FunctionDef) and n.name=='update_version_score_review' for n in review_tree.body)==1
    for retired_path in ('EXACT_REPLAY_PATH','POLICY_COMPETITION_PATH','STRUCTURE_REBUILD_PATH'):
        assert retired_path not in main_source
    assert 'hybrid_shadow_current_s1_block_v1234=' not in review_source
    assert 'probability_ev_positive_v1236=' not in review_source
    assert 'paired_matchup_ready_v1241=' not in review_source

def test_paper_active_contract_and_exact_capture_include_v1257():
    m=load('paper_v1257_active_contract','paper_bot_v1.075.py')
    m._V1257_PREV_ACTIVE_CONTRACT_PAYLOAD=lambda open_pos=None:{
        'contract_digest':'old','exit':{},'open_contract_seal':{'fields':[]},'integrity':{'ledger_commit_order_preserved':True}
    }
    book={
        'p1':{'exit_contract_v1257':{'schema':m.V1257_EXIT_SCHEMA},'extension_state_v1257':{'armed':True}},
        'p2':{'exit_contract_v1207':{'schema':'legacy'}},
    }
    out=m._v1208_active_contract_payload__v1257(book)
    assert out['unified_strategy_v1257']['contracted_open']==1
    assert out['unified_strategy_v1257']['existing_open_contracts_preserved']==1
    assert out['exit']['unified_schema']==m.V1257_EXIT_SCHEMA
    assert 'exit_contract_v1257' in out['open_contract_seal']['fields']
    assert out['snapshot_id'].startswith('contract-v1257-')
    source=(BUILD/'paper_bot_v1.075.py').read_text(encoding='utf-8')
    assert "'exit_contract_v1257':pos.get('exit_contract_v1257')" in source
    assert "decision.get('exit_contract_schema_v1257')" in source

def test_canonical_boards_report_v1257_exit_change_without_rewriting_existing_open():
    spine=load('spine1187_v1257','canonical_spine_v1187.py')
    paper_status={
        'active_contract_v1208':{
            'schema':'paper_active_trade_contract_v1208','version':'paper_bot_v1.074','snapshot_id':'x','contract_digest':'d',
            'entry':{'state':'ACTIVE'},
            'exit':{'state':'ACTIVE_FOR_NEW_OPEN','unified_schema':'paper_unified_exit_contract_v1257','existing_open_rewritten':False},
            'unified_strategy_v1257':{'schema':'paper_active_unified_contract_v1257','existing_open_contracts_preserved':3},
        }
    }
    out=spine._paper_contract_summary(paper_status)
    assert out['exit_contract_changed'] is True
    assert out['unified_strategy_v1257']['existing_open_contracts_preserved']==3
    assert out['exit_contract']['existing_open_rewritten_v1257'] is False
    source1190=(BUILD/'canonical_spine_v1190.py').read_text(encoding='utf-8')
    assert 'exit_contract_changed_v1257' in source1190
    assert '"existing_open_changed": False' in source1190

def test_deploy_manifest_is_one_bundle_and_preserves_ledgers():
    manifest=json.loads((BUILD/'DEPLOY_BUNDLE.json').read_text(encoding='utf-8'))
    assert manifest['release']=='v1258'
    assert manifest['guard']=='backga_guard_bot_v2_5_236.py'
    assert manifest['main']=='coinbot_main_v2_13_1160.py'
    assert manifest['paper']=='paper_bot_v1.075.py'
    assert manifest['workers']=={'strategy':'strategy_worker_v1.060.py','review':'review_worker_v1.036.py'}
    assert manifest['existing_open_contract_changed'] is False
    assert manifest['base_trigger_invalid_target_changed'] is False
    assert manifest['exit_changed'] is False
    assert manifest['auto_buy'] is False
    assert set(manifest['retire_services'])=={'tradingbot-policy-competition-worker','tradingbot-structure-rebuild-worker'}
    assert manifest['live_ledgers_included'] is False

