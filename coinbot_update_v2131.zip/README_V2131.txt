코인봇 v2131 · 대수술 검수 Paper 시간필드 호환 수리

원인
- Paper handoff는 updated_at을 사용한다.
- v2130 Guard는 updated_ts/ts만 읽어 정상 자료를 epoch zero로 오판했다.

수정
- updated_ts, updated_at, ts, heartbeat_ts, created_ts 지원
- 숫자/ISO-8601/밀리초 epoch 지원
- 값이 없거나 잘못되면 fail-closed CHECK 유지

변경 없음
- 전략·후보·구조선·상승예측·Paper 진입/청산·원장·Shadow·자동매수 OFF
