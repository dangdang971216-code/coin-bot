#!/usr/bin/env python3
from __future__ import annotations
import ast
import importlib.util
import json
import os
import tempfile
from pathlib import Path

HERE=Path(__file__).resolve().parent
NEW=HERE/'strategy_worker_v1.016.py'
OLD=Path('/mnt/data/v1147_inspect/strategy_worker_v1.015.py')


def load_module(path: Path, name: str, base: Path):
    old_env=os.environ.get('TRADING_BOT_DIR')
    os.environ['TRADING_BOT_DIR']=str(base)
    try:
        spec=importlib.util.spec_from_file_location(name,str(path))
        mod=importlib.util.module_from_spec(spec)
        assert spec and spec.loader
        spec.loader.exec_module(mod)
        return mod
    finally:
        if old_env is None: os.environ.pop('TRADING_BOT_DIR',None)
        else: os.environ['TRADING_BOT_DIR']=old_env


def tree(path: Path):
    return ast.parse(path.read_text(encoding='utf-8'))


def last_function(path: Path, name: str):
    matches=[n for n in tree(path).body if isinstance(n,(ast.FunctionDef,ast.AsyncFunctionDef)) and n.name==name]
    assert matches, name
    return matches[-1]


def function_dump(path: Path, name: str):
    return ast.dump(last_function(path,name),include_attributes=False)


def call_sequence(path: Path, function_name: str, selected: set[str]):
    fn=last_function(path,function_name)
    out=[]
    for node in ast.walk(fn):
        if not isinstance(node,ast.Call):
            continue
        name=None
        if isinstance(node.func,ast.Name): name=node.func.id
        elif isinstance(node.func,ast.Attribute): name=node.func.attr
        if name in selected:
            out.append((getattr(node,'lineno',0),name,ast.dump(node,include_attributes=False)))
    out.sort()
    return out


def assignment_value(path: Path, name: str):
    val=None
    for node in tree(path).body:
        if isinstance(node,(ast.Assign,ast.AnnAssign)):
            targets=node.targets if isinstance(node,ast.Assign) else [node.target]
            if any(isinstance(t,ast.Name) and t.id==name for t in targets):
                try: val=ast.literal_eval(node.value)
                except Exception: pass
    return val


def main():
    with tempfile.TemporaryDirectory() as td:
        base=Path(td)
        old=load_module(OLD,'strategy_v1147_baseline',base/'old')
        new=load_module(NEW,'strategy_v1148_test',base/'new')
        assert new.VERSION=='strategy_worker_v1.016'
        assert new.BUILD_LABEL=='v1148_strategy_s1_handoff_owner_timing_2026-06-30'

        # Trading formulas/contracts remain exact.
        critical_functions=(
            'apply_swing_entry_gate','_v925_current_actual_plan','_swing_quality_gate',
            '_v554_apply_entry_plan_state__v1115','seal_canonical_candidate_keys',
            'attach_smart_structure_shadow','attach_structure_lab','attach_hot_watch_timing',
            'observe_good_s2_lifecycle','write_s1_hold_cache','write_strategy_key_spine_status',
        )
        for name in critical_functions:
            assert function_dump(OLD,name)==function_dump(NEW,name),name
        critical_constants=(
            'V925_MIN_RR','V925_MIN_TARGET_ROOM_PCT','V925_UNTRADABLE_SPREAD_PCT',
            'V977_MAX_TRIGGER_OVERSHOOT_PCT','STRUCTURE_LAB_RECOMPUTE_BUDGET',
            'STRUCTURE_LAB_LIVE_METHOD_BUDGET','STRUCTURE_EVENT_DELIVERY_TTL_SEC',
        )
        for name in critical_constants:
            assert getattr(old,name)==getattr(new,name),(name,getattr(old,name),getattr(new,name))

        selected={
            'attach_smart_structure_shadow','attach_structure_lab','attach_hot_watch_timing',
            'observe_good_s2_lifecycle','write_s1_hold_cache','write_strategy_key_spine_status',
            '_v1021_publish_candidate_snapshot',
        }
        old_calls=call_sequence(OLD,'_v510_publish',selected)
        new_calls=call_sequence(NEW,'_v510_publish',selected)
        old_names=[x[1] for x in old_calls]
        new_names=[x[1] for x in new_calls]
        assert old_names==new_names,(old_names,new_names)
        # Call arguments are exact even though line numbers/timing wrappers changed.
        assert [x[2] for x in old_calls]==[x[2] for x in new_calls]
        assert new_names==[
            'attach_smart_structure_shadow','attach_structure_lab','attach_hot_watch_timing',
            'observe_good_s2_lifecycle','write_s1_hold_cache','write_strategy_key_spine_status',
            '_v1021_publish_candidate_snapshot',
        ],new_names

        src=NEW.read_text(encoding='utf-8')
        for phase in ('hot_watch_timing_v1148','good_s2_lifecycle_v1148','s1_hold_commit_v1148','key_spine_status_v1148'):
            assert src.count(repr(phase))>=2,phase
        assert "'observation_good_s2_and_s1_hold'" not in src
        assert "s1_hold_commit_elapsed_sec_v1148" in src
        assert "s1_handoff_measurement_policy_v1148" in src

        # The v1147 cache activation remains in place and unchanged.
        assert function_dump(OLD,'_lab_rows')==function_dump(NEW,'_lab_rows')
        assert function_dump(OLD,'_v1014_load_candle_map')==function_dump(NEW,'_v1014_load_candle_map')

        print(json.dumps({
            'result':'PASS',
            'version':new.VERSION,
            'build':new.BUILD_LABEL,
            'exact_call_order_unchanged':new_names,
            'critical_trade_functions_unchanged':list(critical_functions),
            'critical_constants_unchanged':list(critical_constants),
            'v1147_cache_path_unchanged':True,
            'measurement_phases':['hot_watch_timing_v1148','good_s2_lifecycle_v1148','s1_hold_commit_v1148','key_spine_status_v1148'],
            'auto_buy':False,
        },ensure_ascii=False,indent=2))

if __name__=='__main__': main()
