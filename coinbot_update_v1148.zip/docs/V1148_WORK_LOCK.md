# v1148 작업 잠금 — Strategy S1 handoff owner timing

- issue: `STRATEGY-S1-HANDOFF-OWNER-1148`
- 시작 상태: OPEN
- 대상 기준: 서버 적용 완료된 `strategy_worker_v1.015` (v1147)
- 전략모드: `ALT_SWING`
- 자동매수: OFF

## 증상

v1147 적용 후 Strategy cycle은 약 22~24초에서 14.497초로 감소했지만, 최신 cycle의 S1 4건 중 3건이 `STALE_TRIGGER_OCCURRENCE`로 종료되었다.

## 코드에서 확정된 흐름

Paper의 신규 OPEN 입력 owner는 `paper_s1_hold_cache.json`이다. Strategy는 이 파일을 쓰기 전에 아래 작업을 동기식으로 수행한다.

1. `attach_smart_structure_shadow`
2. `attach_structure_lab`
3. `attach_hot_watch_timing`
4. `observe_good_s2_lifecycle`
5. `write_s1_hold_cache`
6. `write_strategy_key_spine_status`

전체 candidate snapshot writer는 S1 hold commit 뒤에 실행되므로, candidate writer 2.8초는 현재 직접 S1 전달 지연 owner가 아니다.

## 아직 확정되지 않은 부분

기존 profile은 3~6번을 `observation_good_s2_and_s1_hold` 한 덩어리로 측정했다. 따라서 2초 안팎의 시간 중 hot-watch, Good-S2 ledger, 실제 S1 commit, key status가 각각 얼마를 소유하는지 확정할 수 없다.

## v1148 수정 범위

- 기존 호출 순서와 입력/출력은 그대로 유지한다.
- 기존 묶음 profile만 다음 4개로 분리한다.
  - `hot_watch_timing_v1148`
  - `good_s2_lifecycle_v1148`
  - `s1_hold_commit_v1148`
  - `key_spine_status_v1148`
- cycle 시작부터 S1 commit 완료까지 `s1_hold_commit_elapsed_sec_v1148`을 기록한다.
- Strategy phase group reader가 새 4개 leaf를 합산하도록 연결한다.

## 변경하지 않는 영역

Gate, rank, trigger, invalid, target, RR, TTL, spread/slippage, candidate key, direct decision key, OPEN 한도 30, cycle 신규 OPEN 3, trailing, exit, Paper/Risk/Main/Guard source, 후보 역할과 기준은 변경하지 않는다.

## 삭제 대상

없음. 이번 버전은 owner 확정을 위한 measurement-only 변경이며 구 기능·fallback을 덧대지 않는다.

## 완료 기준

서버에서 v1.016/hash/PID 일치 후 연속 cycle에서 4개 leaf 시간과 S1 handoff elapsed가 표시되고, candidate key/count 및 Paper terminal reason 흐름이 유지되며 신규 오류가 없어야 한다. 이 증거로 다음 수정 버전의 단일 owner를 결정한다.
