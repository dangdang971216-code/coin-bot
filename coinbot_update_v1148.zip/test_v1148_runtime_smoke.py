#!/usr/bin/env python3
from __future__ import annotations
import importlib.util
import json
import os
import tempfile
from pathlib import Path

SRC=Path(__file__).resolve().parent/'strategy_worker_v1.016.py'

def main():
    with tempfile.TemporaryDirectory() as td:
        os.environ['TRADING_BOT_DIR']=td
        spec=importlib.util.spec_from_file_location('strategy_v1148_smoke',str(SRC))
        mod=importlib.util.module_from_spec(spec); assert spec and spec.loader; spec.loader.exec_module(mod)
        profile={'phases':{
            'smart_structure_shadow':{'wall_sec':1.0,'cpu_sec':0.9},
            'structure_lab':{'wall_sec':1.1,'cpu_sec':1.0},
            'hot_watch_timing_v1148':{'wall_sec':0.2,'cpu_sec':0.2},
            'good_s2_lifecycle_v1148':{'wall_sec':0.4,'cpu_sec':0.4},
            's1_hold_commit_v1148':{'wall_sec':0.05,'cpu_sec':0.04},
            'key_spine_status_v1148':{'wall_sec':0.1,'cpu_sec':0.09},
            'row_aggregation_and_promotion_stats':{'wall_sec':0.3,'cpu_sec':0.3},
        }}
        result=mod._v1113_phase_group_totals(profile)
        row=next(x for x in result['groups'] if x['group']=='structure_and_observation')
        assert abs(row['wall_sec']-3.15)<1e-9,row
        assert row['phases']==[
            'smart_structure_shadow','structure_lab','hot_watch_timing_v1148',
            'good_s2_lifecycle_v1148','s1_hold_commit_v1148','key_spine_status_v1148',
            'row_aggregation_and_promotion_stats',
        ],row
        print(json.dumps({'result':'PASS','version':mod.VERSION,'structure_group_wall_sec':row['wall_sec'],'phase_count':len(row['phases'])},ensure_ascii=False,indent=2))

if __name__=='__main__': main()
