v1327 rebreak writer row budget fix

Purpose:
- Keep v1326/v1051 trigger reset-rebreak watch restoration.
- Fix Strategy writer ERROR_BEFORE_WRITE caused by v1021 candidate row hard ceiling.
- Compact display-only duplicated rebreak/context payload only.

No strategy value changes:
- candidate formula: unchanged
- trigger/invalid/target/RR: unchanged
- exit contract: unchanged
- auto-buy: OFF
- live ledgers: not included

Apply first in guard bot: /gupgrade_bundle
Verify: /grelease_verify, then main bot /flow_map_full /version_score /candidate_standard
