coinbot_update_v2104

목적
- 현재 손실 OPEN 43개 중 37개가 한때 양수였고, v2101 +2% 방어는 62개 중 6개만 발동권이어서 남은 공백을 수리
- 비용 후 MFE +0.70%부터 단계형 양수 바닥 적용
  · +0.70% → +0.10%
  · +1.00% → +0.30%
  · +1.50% → +0.50%
  · +2.00% → +0.80%
  · +5.00% 이상 Runner → 고점 대비 2.30%p 허용, 최소 +1.00%
- 신규 OPEN과 사용자 승인 시점 현재 OPEN에 overlay append
- 기존 trigger/invalid/target, v2071/v2089/v2100/v2101, 과거 원장 유지
- 자동매수 OFF

서버 기준
- Paper paper_bot_v2.060
- build v2104_progressive_profit_retention_floor_existing_open_2026-07-19
- /pstatus 단계형 수익보존 v2104 적용/발동권/의미있는 양수→음수/현재 청산조건 표시
- CLOSED reason progressive_profit_floor_v2104 forward 확인
