from __future__ import annotations

import importlib.util
import json
import sys
import tempfile
import zipfile
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))


def load_module(name: str, path: Path):
    spec = importlib.util.spec_from_file_location(name, path)
    module = importlib.util.module_from_spec(spec)
    assert spec and spec.loader
    sys.modules[name] = module
    spec.loader.exec_module(module)
    return module


def base_row(strategy):
    row = {
        'ticker': 'TEST',
        'open_eligible': True,
        'trigger_reached': True,
        'swing_gate_decision_key_v977': 'decision-1',
        'candidate_pipeline_cycle_id_v1150': 'cycle-1',
        'structure_contract_version': 'current',
        'structure_contract_hash': 'hash-1',
        'swing_entry_gate_v977': {
            'trigger_price': 100.0,
            'invalid_price': 95.0,
            'target_price': 110.0,
            'pass': True,
        },
        'swing_trigger_price_v977': 100.0,
        'swing_invalid_price_v977': 95.0,
        'swing_target_price_v977': 110.0,
        'dynamic_structure_plan_v1212': {
            'trigger_price': 100.0,
            'invalid_price': 95.0,
            'target_price': 110.0,
            'structure_contract_version': 'current',
            'structure_contract_hash': 'hash-1',
            'target_reach_limit_pct': 15.0,
        },
        'structure_contract_v1212': {
            'trigger_price': 100.0,
            'invalid_price': 95.0,
            'target_price': 110.0,
            'structure_contract_version': 'current',
            'structure_contract_hash': 'hash-1',
        },
        'v1211_structure_shadow_v1222': {
            'source_exact': True,
            'complete': True,
            'invalid': {'rounded_price': 97.0, 'source': 'setup_support', 'tf': '30m'},
            'target': {'rounded_price': 120.0, 'source': 'major_resistance', 'tf': '4h'},
        },
        'price_reaction_pct': 0.1,
        'relative_strength_rank_pct_v1095': 70.0,
        'money_flow_score': 60.0,
        'buy_ratio': 0.55,
        'buy_sustain_1m': 0.50,
        'quality_observation_v925': {'extreme_quality_risk_tags': []},
        'canonical_entry_decision': {},
    }
    row['unified_strategy_contract_v1257'] = strategy._v1257_unified_contract(row, 1.0)
    return row


def test_candidate_transport_single_owner_fixes_old_ceiling_without_raising_limit():
    new = load_module('strategy_v1260_transport', ROOT / 'strategy_worker_v1.062.py')
    old = load_module('strategy_v1259_transport', ROOT.parent / 'v1259' / 'strategy_worker_v1.061.py')
    row = base_row(new)
    contract = dict(row['unified_strategy_contract_v1257'])
    # Reproduce the class of failure seen on the server: verbose contract/audit
    # duplication plus the old top-level owner alias pushed a required row over
    # the unchanged 24 KiB hard ceiling.
    for idx in range(60):
        contract[f'verbose_audit_{idx:02d}'] = 'X' * 350
    row['unified_strategy_contract_v1257'] = contract
    row['unified_strategy_owner_v1257'] = 'Y' * 500
    row['unified_contract_digest_v1257'] = contract['contract_digest']

    old_failed = False
    try:
        old._v861_compact_row_for_latest(row)
    except ValueError as exc:
        old_failed = 'hard ceiling' in str(exc)
    assert old_failed is True

    compact = new._v861_compact_row_for_latest(row)
    blob = json.dumps(compact, ensure_ascii=False, separators=(',', ':')).encode('utf-8')
    assert new.V1020_ROW_HARD_CEILING_BYTES == old.V1020_ROW_HARD_CEILING_BYTES == 24576
    assert len(blob) <= 24576
    transport = compact['unified_strategy_contract_v1257']
    assert transport['contract_digest'] == contract['contract_digest']
    assert transport['primary_entry_structure']['trigger_price'] == 100.0
    assert transport['primary_entry_structure']['invalid_price'] == 95.0
    assert transport['primary_entry_structure']['base_target_price'] == 110.0
    assert transport['v1211_structural_support']['early_failure_invalid_price'] == 97.0
    assert transport['v1211_structural_support']['extension_target_price'] == 120.0
    assert 'unified_strategy_owner_v1257' not in compact
    assert 'unified_contract_digest_v1257' not in compact
    assert not any(k.startswith('verbose_audit_') for k in transport)


def test_paper_can_seal_v1260_transport_without_contract_recalculation():
    strategy = load_module('strategy_v1260_paper_fixture', ROOT / 'strategy_worker_v1.062.py')
    paper = load_module('paper_v1260_transport', ROOT / 'paper_bot_v1.075.py')
    row = base_row(strategy)
    row['entry_price'] = 100.0
    row['unified_strategy_contract_v1257'] = strategy._v1260_unified_contract_transport_view(
        row['unified_strategy_contract_v1257']
    )
    paper._V1257_PREV_OPEN_POSITION = lambda pos_id, ev: dict(ev)
    pos = paper.open_position__v1257_unified('pos-1', row)
    assert pos['exit_contract_v1257']['strategy_contract_digest'] == row['unified_strategy_contract_v1257']['contract_digest']
    assert pos['exit_contract_v1257']['early_failure_line']['price'] == 97.0
    assert pos['exit_contract_v1257']['extension_target']['price'] == 120.0


def test_strategy_success_status_clears_stale_live_error(tmp_path):
    strategy = load_module('strategy_v1260_status', ROOT / 'strategy_worker_v1.062.py')
    strategy.STATUS = tmp_path / 'status.json'
    strategy._STATUS_LAST_OBJ_V1022 = {
        'version': 'strategy_worker_v1.061',
        'state': 'error',
        'error': 'ValueError: old failure',
        'error_owner_v1165': 'run_once',
        'error_traceback_tail_v1165': ['old'],
        'updated_ts': 1.0,
    }
    strategy._STATUS_CANONICAL_PAYLOAD_V1023.clear()
    strategy._LATEST_PUBLISH_STATUS_V1008.clear()
    strategy._ROLE_SOURCE_STATUS_V1008.clear()
    strategy.write_status('normal', evaluated=3, target_count=3, s_count=1)
    saved = json.loads(strategy.STATUS.read_text(encoding='utf-8'))
    assert saved['state'] == 'normal'
    assert saved['version'] == 'strategy_worker_v1.062'
    assert saved.get('error') in (None, '')
    assert 'error_owner_v1165' not in saved
    assert 'error_traceback_tail_v1165' not in saved


def _healthy_strategy_fixture(version='strategy_worker_v1.062', build='v1260_candidate_transport_single_owner_and_release_truth_2026-07-06'):
    status = {'version': version, 'build': build, 'pid': 123, 'state': 'normal', 'error': ''}
    worker = {'ok': True, 'service_active': 'active', 'pid': 123, 'active_version': version, 'raw': status}
    writer = {
        'result': 'OK', 'rows_written': 10, 'updated_ts': 1000.0, 'version': version, 'build': build,
        'candidate_snapshot_scope': {'pipeline_cycle_id_v1150': 'cycle-1', 'commit_id': 'commit-1'},
    }
    pipeline = {
        'state': 'NORMAL', 'complete': True, 'all_required_commits_v1150': True,
        'cycle_id': 'cycle-1', 'candidate_commit_id': 'commit-1', 'updated_ts': 1000.0,
        'version': version, 'build': build,
    }
    return worker, writer, pipeline


def test_release_truth_fails_on_error_before_write_even_with_version_and_pid(monkeypatch):
    guard = load_module('guard_v1260_fail', ROOT / 'backga_guard_bot_v2_5_238.py')
    worker, writer, pipeline = _healthy_strategy_fixture()
    writer.update({'result': 'ERROR_BEFORE_WRITE', 'rows_written': None, 'error': 'row ceiling'})
    monkeypatch.setattr(guard, 'worker_state_dict', lambda name: worker)
    monkeypatch.setattr(guard.time, 'time', lambda: 1010.0)
    def fake_read(path):
        if str(path).endswith('clean_strategy_paper_latest_writer_status.json'):
            return writer
        if str(path).endswith('strategy_candidate_pipeline_commit_v1150.json'):
            return pipeline
        return {}
    monkeypatch.setattr(guard, 'read_json', fake_read)
    out = guard._v1260_strategy_release_health(worker['active_version'], worker['raw']['build'], wait_sec=0)
    assert out['ok'] is False
    assert out['writer_result'] == 'ERROR_BEFORE_WRITE'


def test_release_truth_passes_only_same_fresh_writer_and_pipeline(monkeypatch):
    guard = load_module('guard_v1260_pass', ROOT / 'backga_guard_bot_v2_5_238.py')
    worker, writer, pipeline = _healthy_strategy_fixture()
    monkeypatch.setattr(guard, 'worker_state_dict', lambda name: worker)
    monkeypatch.setattr(guard.time, 'time', lambda: 1010.0)
    def fake_read(path):
        if str(path).endswith('clean_strategy_paper_latest_writer_status.json'):
            return writer
        if str(path).endswith('strategy_candidate_pipeline_commit_v1150.json'):
            return pipeline
        return {}
    monkeypatch.setattr(guard, 'read_json', fake_read)
    out = guard._v1260_strategy_release_health(worker['active_version'], worker['raw']['build'], wait_sec=0)
    assert out['ok'] is True
    assert out['same_cycle_commit'] is True


def test_manual_release_verify_recovers_exact_last_bundle_manifest(monkeypatch, tmp_path):
    guard = load_module('guard_v1260_manifest', ROOT / 'backga_guard_bot_v2_5_238.py')
    bundle_name = 'coinbot_update_v1260.zip'
    manifest = {'release': 'v1260', 'workers': {'strategy': 'strategy_worker_v1.062.py'}}
    with zipfile.ZipFile(tmp_path / bundle_name, 'w', zipfile.ZIP_DEFLATED) as zf:
        zf.writestr('DEPLOY_BUNDLE.json', json.dumps(manifest))
    (tmp_path / guard.GUARD_RELEASE_RESULT_FILE).write_text(json.dumps({'bundle': bundle_name}), encoding='utf-8')
    monkeypatch.setattr(guard, 'BOT_DIR', tmp_path)
    got, source = guard._v1260_last_release_manifest()
    assert got == manifest
    assert source == f'last_release_bundle:{bundle_name}'


def test_versions_and_no_strategy_rule_change():
    strategy = load_module('strategy_v1260_version', ROOT / 'strategy_worker_v1.062.py')
    guard = load_module('guard_v1260_version', ROOT / 'backga_guard_bot_v2_5_238.py')
    assert strategy.VERSION == 'strategy_worker_v1.062'
    assert strategy.BUILD_LABEL.startswith('v1260_')
    assert guard.VERSION.startswith('guard_v2.5.238_')
    assert strategy.V1260_CANDIDATE_TRANSPORT_CONTRACT['hard_ceiling_raised'] is False
    assert strategy.V1260_CANDIDATE_TRANSPORT_CONTRACT['trigger_invalid_target_changed'] is False
    assert guard.V1260_RELEASE_TRUTH_CONTRACT['version_only_pass_forbidden'] is True
