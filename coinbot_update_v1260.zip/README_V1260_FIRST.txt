코인봇 v1260 적용 전 확인

1. 이 버전은 Strategy 후보 row 중복 저장과 Guard 거짓 PASS를 수리한다.
2. 후보식·S1·trigger·invalid·target·RR·진입·청산 수치는 바꾸지 않는다.
3. 기존 OPEN 계약과 모든 거래 원장은 건드리지 않는다.
4. 후보 row 최대크기 24,576바이트는 올리지 않는다.
5. 자동매수는 OFF다.
6. 서버 적용 후 Strategy 1.062의 새 writer cycle/commit이 증명되기 전까지 상태는 CHECK다.
