coinbot_update_v1322 · trigger wait watch S1 restore

목적:
- trigger 미도달은 구조 실패가 아니라 감시 대기다.
- Strategy는 구조·RR·목표공간·비용이 맞는 후보를 S1 감시풀에 남긴다.
- Paper는 실제 OPEN 직전에 현재가가 trigger에 닿았는지 다시 확인한다.

변경하지 않음:
- 후보식, trigger, invalid, target, RR, 청산조건, 자동매수 OFF, 원장.

서버 적용 후 확인:
- /grelease_verify
- /version_score /flow_map_full /candidate_standard
