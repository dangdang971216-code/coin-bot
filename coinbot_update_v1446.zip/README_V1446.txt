coinbot v1446 candidate_select bottleneck split

목적:
- candidate_select 7초대 병목을 내부 구간별로 분해해서 /bottleneck_map, /entry_latency_core, /pstatus, /candidate_summary, /version_score에 표시합니다.
- 조건 완화가 아니라 시스템 병목 원인 추적용입니다.

변경 없음:
- Gate / TTL / 35초 slippage 기준 / RR / trigger / invalid / target / 청산계약 / S1-S2-S3 기준 / OPEN 제한 / 자동매수
- 자동매수 OFF
