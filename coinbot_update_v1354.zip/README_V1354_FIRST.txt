v1354: Paper singleton + S1 source spine + body_ratio transport fix.
Run /gupgrade_bundle first, then /grelease_verify, then main /flow_map_full /material_flow_map /candidate_material_audit.
