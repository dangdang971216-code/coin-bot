v1374 Paper owner spine unification.
Apply with /gupgrade_bundle first. Then run guard: /grelease_verify /gpaper_selector_audit /gpaper_ttl_audit and main: /flow_map_full /version_score.
No trading thresholds changed. Auto-buy remains OFF.
