from pathlib import Path
import json,py_compile
p=Path(__file__).resolve().parent/'coinbot_main_v2_13_1112.py'
py_compile.compile(str(p),doraise=True)
s=p.read_text(encoding='utf-8')
assert '/flow_map_full' in s and '/candidate_standard' in s
assert '기준 변경과 후보 전달 고장은 서로 분리해서 판단함' in s
print(json.dumps({'status':'PASS','main_compile':True,'default_verification_commands':['/flow_map_full','/candidate_standard']},ensure_ascii=False))
