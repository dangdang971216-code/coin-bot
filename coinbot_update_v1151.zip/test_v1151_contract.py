from pathlib import Path
import ast, json, py_compile
ROOT=Path(__file__).resolve().parent
M=ROOT/'coinbot_main_v2_13_1112.py'; text=M.read_text(encoding='utf-8')
py_compile.compile(str(M),doraise=True)
assert "BOT_VERSION = '수익형 v2.13.1112'" in text
for token in ['🚰 후보 배관 상태','고장 위치: 전략봇이 후보를 만든 뒤','정상 흐름: S1 후보 저장','매매 영향:','🧱 후보 기준 고정판 · 쉬운 요약','후보를 고르는 핵심 기준','자동매수: OFF','[아래부터 개발용 전체 증거]']:
    assert token in text,token
assert "def render_candidate_standard_text" in text
assert "def render_flow_map_full_text__v1141" in text
# Missing/stale source branches must still show the easy pipeline first.
assert text.count('_v1151_plain_pipeline_lines()') >= 4
print(json.dumps({'status':'PASS','plain_flow_map':True,'plain_candidate_standard':True,'developer_details_retained':True,'auto_buy':False},ensure_ascii=False))
