# v1151 범위·검수

- /flow_map_full 상단: 쉬운 후보 배관 상태
- /candidate_standard 상단: 쉬운 후보 기준 고정판 + 후보 배관 상태
- 원천 누락·stale 상태에서도 쉬운 설명 우선
- 아래 개발용 전체 증거 유지
- 기본 Main 검수 명령: /flow_map_full, /candidate_standard
- 서버 runtime 확인 전 상태: CHECK
