# change_verify_ledger_utils.py
# 수정-검수 증거 장부 단일 writer/reader
# 원칙:
# - 여러 파일에서 직접 open하지 말고 이 함수만 통해 append/read 한다.
# - issue_ledger_live / next_work_queue_live / done_archive를 대체하지 않는다.
# - main_bot은 읽어서 표시만 한다. 후보/성과 재계산 금지.

from __future__ import annotations

import gzip
import json
import os
import time
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Dict, List, Optional


DEFAULT_LEDGER_DIR = "/home/dangdang971216/trading_bot/runtime"

LEDGER_DIR = Path(os.environ.get("COINBOT_LEDGER_DIR", DEFAULT_LEDGER_DIR))
CHANGE_VERIFY_LEDGER_PATH = LEDGER_DIR / "change_verify_ledger.jsonl"
CHANGE_VERIFY_ARCHIVE_DIR = LEDGER_DIR / "archive" / "change_verify"
CHANGE_VERIFY_MAX_ACTIVE_ROWS = int(os.environ.get("COINBOT_CHANGE_VERIFY_MAX_ACTIVE_ROWS", "300"))

VALID_VERIFY_RESULTS = {"PASS", "CHECK", "FAIL", "PARTIAL"}


def _utc_now_iso() -> str:
    return datetime.now(timezone.utc).isoformat()


def _normalize_str(value: Any, default: str = "") -> str:
    if value is None:
        return default
    return str(value)


def _normalize_list(value: Any) -> List[str]:
    if value is None:
        return []
    if isinstance(value, list):
        return [str(x) for x in value if x is not None]
    if isinstance(value, tuple):
        return [str(x) for x in value if x is not None]
    if isinstance(value, set):
        return [str(x) for x in value if x is not None]
    return [str(value)]


def _ensure_ledger_dir() -> None:
    LEDGER_DIR.mkdir(parents=True, exist_ok=True)


def _json_dumps(obj: Dict[str, Any]) -> str:
    return json.dumps(obj, ensure_ascii=False, sort_keys=True, separators=(",", ":"))


def _parse_jsonl_line(line: str) -> Optional[Dict[str, Any]]:
    line = (line or "").strip()
    if not line:
        return None
    try:
        obj = json.loads(line)
    except json.JSONDecodeError:
        return None
    if not isinstance(obj, dict):
        return None
    return obj


def _iter_jsonl(path: Path):
    if not path.exists():
        return
    with path.open("r", encoding="utf-8") as f:
        for line in f:
            obj = _parse_jsonl_line(line)
            if obj is not None:
                yield obj


def _tail_lines(path: Path, limit: int = 20, block_size: int = 8192) -> List[str]:
    if not path.exists():
        return []
    limit = max(1, int(limit or 20))
    lines: List[bytes] = []
    buffer = b""
    with path.open("rb") as f:
        f.seek(0, os.SEEK_END)
        position = f.tell()
        while position > 0 and len(lines) <= limit:
            read_size = min(block_size, position)
            position -= read_size
            f.seek(position)
            chunk = f.read(read_size)
            buffer = chunk + buffer
            lines = buffer.splitlines()
    if not lines:
        return []
    tail = lines[-limit:]
    return [x.decode("utf-8", errors="replace") for x in tail]


def _change_id_exists(change_id: str) -> bool:
    change_id = str(change_id or "").strip()
    if not change_id:
        return False

    for row in _iter_jsonl(CHANGE_VERIFY_LEDGER_PATH) or []:
        if str(row.get("change_id", "")).strip() == change_id:
            return True

    # Archived weekly gzip files are also part of the same change_verify ledger.
    # Duplicate change_id must stay blocked after old rows rotate out of active jsonl.
    try:
        if CHANGE_VERIFY_ARCHIVE_DIR.exists():
            for archive_path in CHANGE_VERIFY_ARCHIVE_DIR.glob("change_verify_ledger_*.jsonl.gz"):
                if change_id in _read_gzip_jsonl_change_ids(archive_path):
                    return True
    except Exception:
        pass

    return False



def _week_key_from_event(row: Dict[str, Any]) -> str:
    """Return ISO week key like 2026-W24 for weekly compressed archives."""
    created_at = str(row.get("created_at") or "").strip()
    dt = None
    if created_at:
        try:
            dt = datetime.fromisoformat(created_at.replace("Z", "+00:00"))
        except Exception:
            dt = None
    if dt is None:
        try:
            ts = float(row.get("created_ts") or 0)
            if ts > 0:
                dt = datetime.fromtimestamp(ts, tz=timezone.utc)
        except Exception:
            dt = None
    if dt is None:
        dt = datetime.now(timezone.utc)
    iso = dt.isocalendar()
    return f"{iso.year}-W{int(iso.week):02d}"


def _read_gzip_jsonl_change_ids(path: Path) -> set:
    ids = set()
    if not path.exists():
        return ids
    try:
        with gzip.open(path, "rt", encoding="utf-8") as f:
            for line in f:
                obj = _parse_jsonl_line(line)
                if obj is not None:
                    cid = str(obj.get("change_id", "")).strip()
                    if cid:
                        ids.add(cid)
    except Exception:
        # Archive read failure must not block active ledger writes.
        # The caller can still append old rows; gzip file remains append-safe.
        return ids
    return ids


def run_change_verify_retention(max_active_rows: Optional[int] = None) -> Dict[str, Any]:
    """
    Keep only recent max_active_rows in the active jsonl.
    Older rows are compressed by ISO week into runtime/archive/change_verify/*.jsonl.gz.

    This is the single retention path for change_verify_ledger.
    It does not touch issue_ledger_live, events, queue, done_archive, paper ledgers, or trade logs.
    """
    _ensure_ledger_dir()
    max_rows = int(max_active_rows or CHANGE_VERIFY_MAX_ACTIVE_ROWS or 300)
    max_rows = max(1, max_rows)

    if not CHANGE_VERIFY_LEDGER_PATH.exists():
        return {
            "ok": True,
            "skipped": True,
            "reason": "missing_active_ledger",
            "active_rows": 0,
            "max_active_rows": max_rows,
            "archived_rows": 0,
            "archive_dir": str(CHANGE_VERIFY_ARCHIVE_DIR),
        }

    rows = list(_iter_jsonl(CHANGE_VERIFY_LEDGER_PATH) or [])
    active_count = len(rows)
    if active_count <= max_rows:
        return {
            "ok": True,
            "skipped": True,
            "reason": "within_limit",
            "active_rows": active_count,
            "max_active_rows": max_rows,
            "archived_rows": 0,
            "archive_dir": str(CHANGE_VERIFY_ARCHIVE_DIR),
        }

    old_rows = rows[:-max_rows]
    keep_rows = rows[-max_rows:]
    CHANGE_VERIFY_ARCHIVE_DIR.mkdir(parents=True, exist_ok=True)

    archived_rows = 0
    archive_files = []
    by_week: Dict[str, List[Dict[str, Any]]] = {}
    for row in old_rows:
        by_week.setdefault(_week_key_from_event(row), []).append(row)

    for week_key, week_rows in sorted(by_week.items()):
        archive_path = CHANGE_VERIFY_ARCHIVE_DIR / f"change_verify_ledger_{week_key}.jsonl.gz"
        existing_ids = _read_gzip_jsonl_change_ids(archive_path)
        added = 0
        with gzip.open(archive_path, "at", encoding="utf-8") as f:
            for row in week_rows:
                cid = str(row.get("change_id", "")).strip()
                if cid and cid in existing_ids:
                    continue
                f.write(_json_dumps(row) + "\n")
                if cid:
                    existing_ids.add(cid)
                added += 1
        if added:
            archived_rows += added
            archive_files.append(str(archive_path))

    tmp_path = CHANGE_VERIFY_LEDGER_PATH.with_suffix(".jsonl.retain_tmp")
    with tmp_path.open("w", encoding="utf-8") as f:
        for row in keep_rows:
            f.write(_json_dumps(row) + "\n")
    os.replace(tmp_path, CHANGE_VERIFY_LEDGER_PATH)

    return {
        "ok": True,
        "skipped": False,
        "reason": "rotated_weekly_archive_keep_active_limit",
        "active_rows_before": active_count,
        "active_rows_after": len(keep_rows),
        "max_active_rows": max_rows,
        "archived_rows": archived_rows,
        "archive_files": archive_files[:20],
        "archive_dir": str(CHANGE_VERIFY_ARCHIVE_DIR),
    }

def append_change_verify_event(
    *,
    change_id: str,
    issue_id: str,
    version: str,
    symptom: str,
    owner_factory: str,
    files_changed: Optional[List[str]] = None,
    removed_old_paths: Optional[List[str]] = None,
    new_mainline: str = "",
    not_touched: Optional[List[str]] = None,
    verify_commands: Optional[List[str]] = None,
    verify_result: str = "CHECK",
    remaining: str = "",
    extra: Optional[Dict[str, Any]] = None,
) -> Dict[str, Any]:
    """
    수정-검수 장부 append 단일 진입점.

    verify_result:
    - PASS
    - CHECK
    - FAIL
    - PARTIAL

    중복 방지:
    - 같은 change_id는 재기록하지 않는다.
    """
    change_id = _normalize_str(change_id).strip()
    issue_id = _normalize_str(issue_id).strip()
    version = _normalize_str(version, "unknown").strip() or "unknown"
    owner_factory = _normalize_str(owner_factory, "unknown").strip() or "unknown"
    verify_result = _normalize_str(verify_result, "CHECK").upper().strip() or "CHECK"

    if not change_id:
        raise ValueError("change_id is required")
    if not issue_id:
        raise ValueError("issue_id is required")
    if verify_result not in VALID_VERIFY_RESULTS:
        raise ValueError(f"invalid verify_result: {verify_result}")

    _ensure_ledger_dir()

    if _change_id_exists(change_id):
        return {
            "ok": False,
            "skipped": True,
            "reason": "duplicate_change_id",
            "change_id": change_id,
            "path": str(CHANGE_VERIFY_LEDGER_PATH),
        }

    event: Dict[str, Any] = {
        "change_id": change_id,
        "issue_id": issue_id,
        "version": version,
        "symptom": _normalize_str(symptom),
        "owner_factory": owner_factory,
        "files_changed": _normalize_list(files_changed),
        "removed_old_paths": _normalize_list(removed_old_paths),
        "new_mainline": _normalize_str(new_mainline),
        "not_touched": _normalize_list(not_touched),
        "verify_commands": _normalize_list(verify_commands),
        "verify_result": verify_result,
        "remaining": _normalize_str(remaining),
        "created_at": _utc_now_iso(),
        "created_ts": time.time(),
    }

    if extra:
        event["extra"] = dict(extra)

    with CHANGE_VERIFY_LEDGER_PATH.open("a", encoding="utf-8") as f:
        f.write(_json_dumps(event) + "\n")

    retention_result = run_change_verify_retention(max_active_rows=CHANGE_VERIFY_MAX_ACTIVE_ROWS)

    return {
        "ok": True,
        "skipped": False,
        "change_id": change_id,
        "path": str(CHANGE_VERIFY_LEDGER_PATH),
        "retention": retention_result,
    }


def load_recent_change_verify_events(limit: int = 10) -> List[Dict[str, Any]]:
    limit = max(1, min(int(limit or 10), 100))
    rows: List[Dict[str, Any]] = []
    for line in _tail_lines(CHANGE_VERIFY_LEDGER_PATH, limit=limit * 3):
        obj = _parse_jsonl_line(line)
        if obj is not None:
            rows.append(obj)
    return rows[-limit:]


def load_change_verify_stats(limit: int = 200) -> Dict[str, Any]:
    rows = load_recent_change_verify_events(limit=limit)
    by_result: Dict[str, int] = {
        "PASS": 0,
        "CHECK": 0,
        "FAIL": 0,
        "PARTIAL": 0,
    }
    for row in rows:
        result = str(row.get("verify_result", "CHECK")).upper()
        if result not in by_result:
            by_result[result] = 0
        by_result[result] += 1
    latest = rows[-1] if rows else None
    return {
        "path": str(CHANGE_VERIFY_LEDGER_PATH),
        "archive_dir": str(CHANGE_VERIFY_ARCHIVE_DIR),
        "max_active_rows": CHANGE_VERIFY_MAX_ACTIVE_ROWS,
        "recent_count": len(rows),
        "by_result": by_result,
        "latest_change_id": latest.get("change_id") if latest else None,
        "latest_result": latest.get("verify_result") if latest else None,
        "latest_version": latest.get("version") if latest else None,
        "latest_at": latest.get("created_at") if latest else None,
    }


def format_change_verify_summary(limit: int = 3) -> str:
    rows = load_recent_change_verify_events(limit=limit)
    if not rows:
        return "🧾 수정-검수 장부: 기록 없음"
    lines = ["🧾 수정-검수 장부 최근 기록"]
    for row in reversed(rows):
        result = str(row.get("verify_result", "CHECK")).upper()
        change_id = row.get("change_id", "unknown")
        issue_id = row.get("issue_id", "unknown")
        version = row.get("version", "unknown")
        created_at = row.get("created_at", "")
        lines.append(f"- {result} {change_id} / issue={issue_id} / version={version}")
        if created_at:
            lines.append(f"  · at: {created_at}")
        symptom = str(row.get("symptom") or "")
        if symptom:
            lines.append(f"  · 증상: {symptom[:140]}")
        owner_factory = str(row.get("owner_factory") or "")
        if owner_factory:
            lines.append(f"  · 값 주인: {owner_factory[:80]}")
        removed_old_paths = row.get("removed_old_paths") or []
        if removed_old_paths:
            sample = " / ".join([str(x) for x in removed_old_paths[:3]])
            lines.append(f"  · 삭제/격리: {sample[:160]}")
        verify_commands = row.get("verify_commands") or []
        if verify_commands:
            lines.append(f"  · 검수: {' '.join([str(x) for x in verify_commands[:8]])}")
        remaining = str(row.get("remaining") or "")
        if remaining:
            lines.append(f"  · 남음: {remaining[:140]}")
    return "\n".join(lines)


def format_change_verify_stats() -> str:
    stats = load_change_verify_stats(limit=200)
    by_result = stats.get("by_result", {})
    return (
        "🧾 수정-검수 장부\n"
        f"- recent_count: {stats.get('recent_count', 0)}\n"
        f"- PASS: {by_result.get('PASS', 0)} / CHECK: {by_result.get('CHECK', 0)} / "
        f"PARTIAL: {by_result.get('PARTIAL', 0)} / FAIL: {by_result.get('FAIL', 0)}\n"
        f"- latest: {stats.get('latest_result') or '-'} "
        f"{stats.get('latest_change_id') or '-'} "
        f"/ version={stats.get('latest_version') or '-'}\n"
        f"- retention: active 최근 {stats.get('max_active_rows', 300)}건 유지 / 주단위 gzip 압축 보관"
    )


def build_change_verify_command_text(limit: int = 10) -> str:
    rows = load_recent_change_verify_events(limit=limit)
    if not rows:
        return "🧾 /change_verify\n- 기록 없음"
    lines = [f"🧾 /change_verify 최근 {len(rows)}건"]
    for row in reversed(rows):
        lines.append("")
        lines.append(f"✅ change_id: {row.get('change_id', 'unknown')}")
        lines.append(f"- result: {row.get('verify_result', 'CHECK')}")
        lines.append(f"- issue: {row.get('issue_id', 'unknown')}")
        lines.append(f"- version: {row.get('version', 'unknown')}")
        lines.append(f"- owner: {row.get('owner_factory', 'unknown')}")
        lines.append(f"- symptom: {str(row.get('symptom') or '')[:180]}")
        lines.append(f"- new_mainline: {str(row.get('new_mainline') or '')[:180]}")
        removed = row.get("removed_old_paths") or []
        if removed:
            lines.append("- removed_old_paths:")
            for item in removed[:5]:
                lines.append(f"  · {str(item)[:160]}")
        not_touched = row.get("not_touched") or []
        if not_touched:
            lines.append("- not_touched:")
            for item in not_touched[:5]:
                lines.append(f"  · {str(item)[:160]}")
        commands = row.get("verify_commands") or []
        if commands:
            lines.append(f"- verify_commands: {' '.join([str(x) for x in commands[:10]])}")
        remaining = str(row.get("remaining") or "")
        if remaining:
            lines.append(f"- remaining: {remaining[:180]}")
    return "\n".join(lines)


def append_change_verify_to_issue_ledger_text(issue_ledger_text: str) -> str:
    change_verify_text = format_change_verify_summary(limit=3)
    return str(issue_ledger_text or "") + "\n\n" + change_verify_text


def change_verify_command_text() -> str:
    return build_change_verify_command_text(limit=10)


def health_change_verify_line() -> str:
    stats = load_change_verify_stats(limit=200)
    by_result = stats.get("by_result", {})
    return (
        "🧾 change_verify "
        f"PASS={by_result.get('PASS', 0)} "
        f"CHECK={by_result.get('CHECK', 0)} "
        f"PARTIAL={by_result.get('PARTIAL', 0)} "
        f"FAIL={by_result.get('FAIL', 0)} "
        f"latest={stats.get('latest_change_id') or '-'} "
        f"keep={stats.get('max_active_rows', 300)} weekly_gz"
    )
