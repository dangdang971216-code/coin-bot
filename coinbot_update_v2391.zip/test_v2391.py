import ast
import hashlib
import importlib.util
import json
import os
import pathlib
import py_compile
import tempfile
import time

ROOT = pathlib.Path(__file__).resolve().parent
FILES = [
    'strategy_v2_core_v2198.py',
    'strategy_worker_v2.112.py',
    'review_worker_v2.161.py',
    'coinbot_main_v2_13_2236.py',
]
for name in FILES:
    py_compile.compile(str(ROOT / name), doraise=True)
    ast.parse((ROOT / name).read_text(encoding='utf-8'))


def load(name, filename):
    spec = importlib.util.spec_from_file_location(name, ROOT / filename)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


core = load('core_v2391', 'strategy_v2_core_v2198.py')


def item(value):
    return {'state': 'READY', 'source_state': 'READY', 'value': value}


positive = {
    'return_30m_atr_adjusted': item(.7),
    'price_acceleration_30m': item(.4),
    'price_acceleration_1h': item(.3),
    'relative_strength_1h': item(.8),
    'relative_strength_acceleration_1h': item(.4),
    'turnover_growth_recent1h_vs_prior3h': item(25),
    'turnover_acceleration_30m': item(30),
    'higher_low_strength_atr': item(.5),
    'pullback_recovery_ratio': item(.65),
    'btc_price_acceleration_1h': item(.2),
    'market_breadth_change': item(5),
    'market_liquidity_state': {
        'state': 'READY', 'source_state': 'READY',
        'value': {'risk_state': 'RISK_ON', 'context_state': 'BULL'},
    },
}
negative = {
    key: (item(-abs(value['value'])) if isinstance(value, dict) and isinstance(value.get('value'), (int, float)) else value)
    for key, value in positive.items()
}
negative['pullback_recovery_ratio'] = item(.2)
negative['market_liquidity_state'] = {
    'state': 'READY', 'source_state': 'READY',
    'value': {'risk_state': 'RISK_OFF', 'context_state': 'BEAR'},
}


def live_payload(materials):
    return core._apply_live_prediction(
        {
            'materials': materials,
            'pre_signal_rise_pct': .5,
            'explanation_tags': [],
            'price_volume_sequence': {'state': 'UNKNOWN'},
        },
        {'rise_prediction_model_snapshot': {'model_id': 'none', 'targets': {}}},
    )


up_payload = live_payload(positive)
down_payload = live_payload(negative)
up_selection = core._prediction_selection({'rise_prediction_input': up_payload})
down_selection = core._prediction_selection({'rise_prediction_input': down_payload})
assert up_payload['model_state'] == 'LIVE_RAW_MATERIAL'
assert up_selection['decision'] == 'UP'
assert down_selection['decision'] == 'DOWN'
assert 'PREDICTION_SAMPLE_MISSING' not in (ROOT / 'strategy_v2_core_v2198.py').read_text(encoding='utf-8')

# Prove that only UP reaches direct structure-frame access.
now = time.time()


def bars(step, count=140, start=100.0):
    rows = []
    for index in range(count):
        close = start * (1 + 0.0015 * index)
        rows.append({
            'ts': now - (count - index) * step,
            'o': close * .998,
            'h': close * 1.004,
            'l': close * .996,
            'c': close,
            'v': 1000 + index * 10,
        })
    return rows


class TrackingFrames(dict):
    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.direct_access = []

    def __getitem__(self, key):
        self.direct_access.append(key)
        return super().__getitem__(key)


frame_data = {tf: bars(sec) for tf, sec in (
    ('m5', 300), ('m15', 900), ('m30', 1800),
    ('h1', 3600), ('h2', 7200), ('h4', 14400),
)}
row = {'ticker': 'TEST', 'current_price': 120.0, 'price': 120.0}
core._prediction = lambda _row, _frames: {'state': 'LIVE_RAW_MATERIAL', 'rise_prediction_input': dict(up_payload)}
up_frames = TrackingFrames(frame_data)
up_contract = core.build_combined_v2_contract(row, up_frames, now_ts=now)
assert up_contract['prediction_selection']['decision'] == 'UP'
assert set(up_frames.direct_access) >= {'m5', 'm15', 'm30', 'h1', 'h2', 'h4'}
core._prediction = lambda _row, _frames: {'state': 'LIVE_RAW_MATERIAL', 'rise_prediction_input': dict(down_payload)}
down_frames = TrackingFrames(frame_data)
down_contract = core.build_combined_v2_contract(row, down_frames, now_ts=now)
assert down_contract['prediction_selection']['decision'] == 'DOWN'
assert down_frames.direct_access == []

# Review run_once must consume PRE_STRUCTURE_12 and write canonical without UnboundLocalError.
review_base = pathlib.Path(tempfile.mkdtemp(prefix='review_v2391_'))
os.environ['TRADING_BOT_DIR'] = str(review_base)
(review_base / 'runtime').mkdir(parents=True, exist_ok=True)
event_ts = time.time() - 60
review_payload = {
    'event_key': f'TEST:{int(event_ts)}',
    'event_bar_close_ts': event_ts,
    'ticker': 'TEST',
    'event_price': 100.0,
    'material_names': list(positive.keys()),
    'materials': positive,
    'material_values': {},
    'state': 'LIVE_RAW_MATERIAL',
    'model_state': 'LIVE_RAW_MATERIAL',
    'probability_3h': 70.0,
    'probability_6h': 68.0,
    'giveback_risk': 30.0,
    'late_capture_risk': 25.0,
    'predicted_direction_3h': 'UP',
    'predicted_direction_6h': 'UP',
    'primary_selection': {'decision': 'UP', 'reason': 'TEST'},
    'prediction_first': True,
    'target_path_used_by_primary_prediction': False,
    'input_coverage_pct': 100.0,
    'usable_input_count': 12,
    'price_volume_sequence': {'state': 'VOLUME_LEADS'},
    'explanation_tags': ['BEGINNING'],
    'explanation_tag_evidence': {},
    'signal_position': {},
    'execution_cost_observation': {},
}
snapshot = {
    'snapshot_id': 'snap-v2391',
    'candidate_commit_id': 'commit-v2391',
    'rows': [{'ticker': 'TEST', 'rise_prediction_input': review_payload}],
}
(review_base / 'runtime' / 'current_candidate_snapshot_v2176.json').write_text(
    json.dumps(snapshot, ensure_ascii=False), encoding='utf-8'
)
review = load('review_v2391', 'review_worker_v2.161.py')
review_status = review.run_once()
review_canonical = review_status.get('rise_prediction_canonical') or {}
assert review_status['state'] == 'running'
assert review_canonical['current_prediction_contract_event_count'] == 1
assert review_canonical['current_snapshot_contract_state'] == 'PASS'
assert review_canonical['current_snapshot_contract_complete_count'] == 1

# Main must expose Review ERROR as FAIL, not WAITING.
main = load('main_v2391', 'coinbot_main_v2_13_2236.py')
main_base = pathlib.Path(tempfile.mkdtemp(prefix='main_v2391_'))
(main_base / 'clean_review_worker_status.json').write_text(
    json.dumps({'state': 'ERROR', 'error': 'UnboundLocalError: current_prediction_contract_events'}),
    encoding='utf-8',
)
main.BASE_DIR = main_base
trade_review_text = main.render_trade_review()
assert '상태 FAIL' in trade_review_text
assert 'UnboundLocalError' in trade_review_text
assert '상태 WAITING' not in trade_review_text

worker_text = (ROOT / 'strategy_worker_v2.112.py').read_text(encoding='utf-8')
assert "V2176_CORE = 'strategy_v2_core_v2198'" in worker_text
assert "VERSION = 'strategy_worker_v2.112'" in worker_text

for alias, source in (
    ('strategy_v2_core.py', 'strategy_v2_core_v2198.py'),
    ('strategy_worker.py', 'strategy_worker_v2.112.py'),
    ('review_worker.py', 'review_worker_v2.161.py'),
    ('bot.py', 'coinbot_main_v2_13_2236.py'),
):
    assert hashlib.sha256((ROOT / alias).read_bytes()).hexdigest() == hashlib.sha256((ROOT / source).read_bytes()).hexdigest()

print(json.dumps({
    'compile_ast': 'PASS',
    'raw_up_probability_3h': up_payload['probability_3h'],
    'raw_up_decision': up_selection['decision'],
    'raw_down_probability_3h': down_payload['probability_3h'],
    'raw_down_decision': down_selection['decision'],
    'up_structure_called': bool(up_frames.direct_access),
    'down_structure_called': bool(down_frames.direct_access),
    'review_run_once': 'PASS',
    'review_contract_state': review_canonical['current_snapshot_contract_state'],
    'main_review_error_truth': 'PASS',
    'aliases': 'PASS',
    'auto_buy': False,
}, ensure_ascii=False))
