코인봇 v2254 오류 우선 통합 수리

핵심 원인
1. Paper writer와 Main reader가 서로 다른 버전 접미사 필드를 사용해 OPEN 15인데 손실방어 0으로 표시됨.
2. Review가 exact 입력 500을 골랐다는 사실만으로 COMPLETE_500을 표시하면서 상태 overlay와 완료봉 index를 끊어 3h 1건, 6h 0건으로 축소됨.
3. Main이 현재 canonical OPEN과 판단에 쓰지 않는 legacy OPEN을 비교해 거짓 CHECK를 표시함.
4. 새 버전마다 함수·필드·reader를 덧붙이는 구조가 공통 원인.

수정
- Main 공개 명령 최종 owner 이름을 render_status/render_trade_review/render_version_score/render_flow_map으로 고정.
- Paper 공개 status는 open/performance_current_epoch/loss_cap 단일 nested schema.
- Review는 input과 result를 분리하고 RESULT_PARTIAL/COMPLETE를 성숙 결과 수로 판정.
- Review 상태 overlay 복원, 완료봉 index는 메모리에서 최대 5분 간격 갱신, 현재가격 대체 0.
- -2% 접촉 net과 청산 net 차이를 status 표본에 추가. 수치·청산계약은 변경하지 않음.
- Guard는 단일 고정 배포 경로 유지, 배포 중 ZIP 정리 제거, post_apply 증명으로 명칭 정리.

변경하지 않음
상승예측 식·가중치·통과선, 후보 기준, trigger/invalid/target/RR, 진입·청산 수치, 기존 원장·Shadow, 자동매수 OFF.
