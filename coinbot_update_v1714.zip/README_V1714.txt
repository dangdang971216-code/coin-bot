v1714: preopen latency segment trace. Diagnostic only. Auto-buy OFF. No trading criteria changes.
