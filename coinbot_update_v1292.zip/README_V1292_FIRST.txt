v1292 is a correction of v1291 direction: no shadow preservation for failed later exit layers on NEW OPENs. Existing OPENs and ledgers are preserved.
