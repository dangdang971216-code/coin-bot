coinbot_update_v1438.zip

목적:
- 6시간 약세정리(swing_no_progress) 손실의 원인을 shadow로 분리한다.
- 진입 전 약세 신호, 1~3시간 무반응 proxy, 약세정리 몰림 신규진입정지 shadow를 본다.

중요:
- 실제 S1 차단 없음
- 실제 Paper 진입 변경 없음
- 실제 조기청산 없음
- 실제 자동정지 없음
- Gate/TTL/RR/trigger/invalid/target/trailing/청산계약 변경 없음
- OPEN/CLOSED/trade_log/decision/exact 원장 재작성 없음
- 자동매수 OFF

새 명령:
- /no_progress_shadow
- /pre_entry_weak_shadow
- /stall_entry_shadow
- /dead_entry_shadow
- /weak_entry_shadow
- /no_progress_shadow_diag

검수:
1. /gupgrade_bundle
2. main: /no_progress_shadow /exit_shadow_contracts /profit_shadow /buried_shadow /version_score

상태:
- LOCAL_DONE
- SERVER_CHECK 필요
