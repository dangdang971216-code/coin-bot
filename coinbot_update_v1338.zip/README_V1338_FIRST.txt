v1338 readable soft filter shadow. Audit/display only. Auto-buy OFF.
