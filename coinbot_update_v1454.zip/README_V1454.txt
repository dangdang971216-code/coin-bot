v1454 display-only: mobile-readable /shadow_board and /popen. No trading rule change. Auto-buy OFF.
