v1705: fast /gupgrade_bundle continuation + fast condition owner cache. No trading rule change. Auto-buy OFF.
