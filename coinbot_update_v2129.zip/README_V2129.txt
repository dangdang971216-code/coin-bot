현재 상태
- v2128 현재 배관은 후보를 조용히 삭제하지 않고 Strategy→Paper→Review로 직접 전달한다.
- 최신 운영자료는 후보 459개, S1 3~4개, Paper 선택 0이며 자동매수는 OFF다.
- 24시간 성과는 26전 2승 24패, 합 -51.10%로 전략 근본원인 확인이 필요하다.
- 최근 MET는 구조완성→Trigger가 약 1365초 걸렸다.

v2129 목적
- 구조선을 다시 조정하지 않고, 기존 자료만 읽어 근본원인을 한 판에서 구분한다.
- 새 명령: /root_strategy_audit
- 별칭: /strategy_root_audit, /root_audit

코드에서 확인한 근본 빈칸
- Strategy v2110의 market_regime은 전체시장/BTC가 아니라 각 코인의 4h·2h 완료봉 추세다.
- Trigger는 완료봉 지지회복·고점돌파·돌파재확인으로 만들며 호가·체결의 연속 강화는 방향 결정 주인이 아니다.
- Market worker는 24시간 상승폭·상승종목 수·TOP 거래대금을 제공하지만 BTC 단기방향, 거래대금 집중 변화, 주도순위 지속, 외부시장 선행은 제공하지 않는다.
- 따라서 현재 방식은 반응 위치와 계약 위험은 계산하지만 진입 뒤 매수 지속을 직접 예측하지 못할 수 있다.

/root_strategy_audit 표시
- 실제 v2110 구조유형별 CLOSED 성과
- 5개 구조방식의 4h·12h 관찰 결과
- 최초후보→Trigger→S1→Paper→OPEN 단계별 지연
- S1·S2·S3의 5m·15m·30m 비용 후 결과
- 매수세·돈흐름·상대강도·추격·비용·목표공간의 승패 구분력
- 전체시장 정보 누락과 현재 계약 하드/대기 이유
- CONFIRMED / REVIEW / CHECK / PASS 근본 판정

미변경
- Strategy/Paper/Review/Guard와 다른 worker 코드
- 후보수·S1/S2/S3·순위·BUY_READY
- trigger·invalid·target·RR·목표공간·추격·spread/slippage
- 실제 진입·청산·OPEN/CLOSED/decision/exact
- 기존 Shadow 공식·generation·자료
- 자동매수 OFF

서버 검수
1. Guard에서 /gupgrade_bundle 단독 실행
2. 메인봇에서 /root_strategy_audit /flow_map_full /version_score /errorlog 실행
3. 근본감사 핵심판 1회와 같은 봉인본 TXT 1개 확인
4. snapshot age와 표본이 현재인지 확인
5. CONFIRMED owner만 다음 버전에서 직접 수정

판정
- LOCAL_PASS_SERVER_CHECK
- v2129는 전략 개선을 주장하는 버전이 아니다.
- 서버 실제 자료로 구조선 자체·진입지연·정보부족·청산손상을 분리한 뒤 다음 본선 수술 범위를 확정한다.
