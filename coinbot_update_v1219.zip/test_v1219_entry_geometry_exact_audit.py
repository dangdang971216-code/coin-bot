import importlib.util
import json
import pathlib
import sys
import tempfile
import unittest
from unittest import mock

ROOT = pathlib.Path(__file__).resolve().parent


def load(name, filename):
    spec = importlib.util.spec_from_file_location(name, ROOT / filename)
    mod = importlib.util.module_from_spec(spec)
    assert spec and spec.loader
    sys.modules[name] = mod
    spec.loader.exec_module(mod)
    return mod


GUARD = load('guard_v1219_tests', 'backga_guard_bot_v2_5_216.py')


def line(price, tf='m15'):
    return {'rounded_price': price, 'raw_price': price, 'tf': tf, 'source': f'test.{tf}'}


def row(ticker, stage, price, trigger, invalid, target, rr, room, reasons, cycle='strategy-v1219-test', mode='nearest_actual_resistance'):
    plan = {
        'schema': 'alt_swing_dynamic_structure_plan_v1212',
        'current_price': price,
        'trigger': line(trigger, 'm15') if trigger else {},
        'invalid': line(invalid, 'h1') if invalid else {},
        'target': line(target, 'h4') if target else {},
        'target_mode_v1212': mode,
        'cost_inputs': {'estimated_roundtrip_cost_pct': 0.25},
    }
    return {
        'ticker': ticker,
        'candidate_pipeline_cycle_id_v1150': cycle,
        's_stage': stage,
        'current_price': price,
        'trigger_price': trigger,
        'invalid_price': invalid,
        'target_price': target,
        'target_room_pct': room,
        'risk_reward_ratio': rr,
        'dynamic_structure_plan_v1212': plan,
        'swing_entry_gate_v977': {
            'schema': 'swing_entry_gate_v977',
            'trigger_price': trigger,
            'invalid_price': invalid,
            'target_price': target,
            'risk_reward': rr,
            'target_room_pct': room,
            'hard_block_reasons': reasons,
        },
    }


class EntryGeometryAuditTests(unittest.TestCase):
    def write_json(self, path, obj):
        path.write_text(json.dumps(obj, ensure_ascii=False), encoding='utf-8')

    def write_jsonl(self, path, rows):
        with path.open('w', encoding='utf-8') as fh:
            for item in rows:
                fh.write(json.dumps(item, ensure_ascii=False) + '\n')

    def build_fixture(self, base):
        cycle = 'strategy-v1219-test'
        rows = [
            row('S1GOOD', 'S1', 101, 100, 98, 104, 2.0, 4.0, [], cycle),
            row('RRROOM', 'S2', 99, 100, 97, 101, 1/3, 1.0,
                ['risk_reward_below_minimum', 'target_room_below_minimum', 'frozen_trigger_not_reached'], cycle),
            row('RRONLY', 'S2', 99, 100, 95, 102, 0.4, 2.0,
                ['risk_reward_below_minimum', 'frozen_trigger_not_reached'], cycle, 'dynamic_atr_price_discovery_extension'),
            row('MISSING', 'S3', 100, None, 95, 105, 0.0, 0.0,
                ['dynamic_structure_source_missing', 'actual_structural_trigger_missing', 'coherent_structure_plan_incomplete',
                 'risk_reward_below_minimum', 'target_room_below_minimum', 'frozen_trigger_not_reached'], cycle),
            row('BADINVALID', 'S3', 100, 100, 100, 105, 0.0, 5.0,
                ['invalid_trigger_target_order_invalid', 'risk_reward_below_minimum'], cycle),
            row('BADTARGET', 'S3', 101, 100, 95, 99, 0.0, 0.0,
                ['invalid_trigger_target_order_invalid', 'risk_reward_below_minimum', 'target_room_below_minimum'], cycle),
        ]
        self.write_jsonl(base / 'paper_candidates_latest.jsonl', rows)
        self.write_json(base / 'clean_strategy_swing_gate_status_v977.json', {
            'rows': 6, 'pass_s1': 1, 'recheck_s2': 2, 'observe_s3': 3,
            'thresholds': {'minimum_risk_reward': 1.5, 'minimum_target_room_pct': 1.2},
        })
        self.write_json(base / 'clean_strategy_paper_latest_writer_status.json', {
            'rows_written': 6,
            'candidate_snapshot_scope': {'rows_written': 6, 'pipeline_cycle_id_v1150': cycle, 'commit_id': 'candidate-v1219-test'},
            'candidate_final_blob_schema_v1218': 'candidate_single_plan_compact_contract_exact_blob_v1218',
            'candidate_encoded_evidence_exact_v1218': True,
        })
        return rows

    def test_exact_scope_and_reason_balance(self):
        with tempfile.TemporaryDirectory() as td:
            base = pathlib.Path(td)
            self.build_fixture(base)
            with mock.patch.object(GUARD, 'BOT_DIR', base):
                report = GUARD.collect_entry_geometry_exact_audit_v1219()
            self.assertEqual(report['verdict'], 'PROVEN_MIXED_ORDER_CONFLICT')
            self.assertEqual(report['scope_counts']['incomplete'], 1)
            self.assertEqual(report['scope_counts']['complete'], 5)
            self.assertEqual(report['scope_counts']['order_valid'], 3)
            self.assertEqual(report['scope_counts']['order_invalid'], 2)
            self.assertEqual(report['valid_contract_failures']['rr_below'], 2)
            self.assertEqual(report['valid_contract_failures']['target_room_below'], 1)
            self.assertEqual(report['reason_balance']['rr_reason'], 5)
            self.assertEqual(report['reason_balance']['rr_metric_below'], 5)
            self.assertTrue(report['reason_balance']['rr_exact'])
            self.assertTrue(report['reason_balance']['room_exact'])
            self.assertTrue(report['reason_balance']['order_exact'])
            self.assertTrue(report['reason_balance']['trigger_exact'])
            self.assertTrue(report['source']['same_rows'])
            self.assertTrue(report['source']['same_stage'])
            self.assertTrue(report['source']['same_cycle'])
            self.assertTrue(report['source']['writer_exact_v1218'])

    def test_distribution_and_samples(self):
        with tempfile.TemporaryDirectory() as td:
            base = pathlib.Path(td)
            self.build_fixture(base)
            with mock.patch.object(GUARD, 'BOT_DIR', base):
                report = GUARD.collect_entry_geometry_exact_audit_v1219()
            rr = report['distributions']['order_valid_rr']
            self.assertEqual(rr['n'], 3)
            self.assertAlmostEqual(rr['max'], 2.0, places=6)
            self.assertEqual(report['scope_counts']['trigger_reached'], 1)
            self.assertEqual(report['scope_counts']['trigger_not_reached'], 2)
            self.assertEqual(report['order_invalid_reasons']['invalid_not_below_current_or_trigger'], 1)
            self.assertEqual(report['order_invalid_reasons']['target_not_above_trigger'], 1)
            self.assertEqual(report['samples']['s1'][0]['ticker'], 'S1GOOD')
            self.assertEqual(report['target_modes']['nearest_actual_resistance'], 2)

    def test_text_and_dispatch_are_read_only(self):
        with tempfile.TemporaryDirectory() as td:
            base = pathlib.Path(td)
            self.build_fixture(base)
            with mock.patch.object(GUARD, 'BOT_DIR', base):
                text = GUARD.gentry_geometry_audit_text_v1219()
                dispatched = GUARD.handle_command('/gentry_geometry_audit')
            self.assertIn('진입 구조값 정밀감사', text)
            self.assertIn('가격순서 정상 3', text)
            self.assertIn('자동매수 OFF', text)
            self.assertIn('진입 구조값 정밀감사', dispatched)

    def test_source_mismatch_fail_closed(self):
        with tempfile.TemporaryDirectory() as td:
            base = pathlib.Path(td)
            self.build_fixture(base)
            writer = json.loads((base / 'clean_strategy_paper_latest_writer_status.json').read_text(encoding='utf-8'))
            writer['candidate_snapshot_scope']['pipeline_cycle_id_v1150'] = 'other-cycle'
            self.write_json(base / 'clean_strategy_paper_latest_writer_status.json', writer)
            with mock.patch.object(GUARD, 'BOT_DIR', base):
                report = GUARD.collect_entry_geometry_exact_audit_v1219()
            self.assertEqual(report['verdict'], 'CHECK_SOURCE_MISMATCH')
            self.assertFalse(report['source']['same_cycle'])


if __name__ == '__main__':
    unittest.main(verbosity=2)
