코인봇 업데이트 v1219
======================
목적: v1218에서 구조자료·writer가 정상화된 뒤에도 RR 460건, 목표공간 427건,
가격순서 오류 136건이 섞여 보이는 문제를 같은 완료 cycle 실제 값으로 분리 증명.

이번 버전은 가드 읽기 전용 감사만 추가한다.
전략 수치·Trigger·Invalid·Target·ATR·RR 기준·순위·진입·청산은 변경하지 않는다.

적용 순서
1) 가드봇에서 /gupgrade_bundle 단독 실행
2) 가드 재시작 후 아래 명령 실행
   /gentry_geometry_audit
   /gstructure_missing_audit
   /gs1_zero_audit
   /gdeploy

정상 기준
- Guard: guard_v2.5.216_v1219_entry_geometry_exact_audit_2026-07-04
- Strategy: strategy_worker_v1.048 그대로 / evaluated 약 463 / err -
- /gentry_geometry_audit 원문 연결 stable·rows·stage·cycle·writer exact 모두 True
- 사유·값 일치 RR·목표·순서·Trigger 모두 True

주의
- 자동매수 OFF
- 결과 확인 전 ATR·RR·목표공간·청산조건 변경 금지
- 서버 결과 전 상태는 CHECK
