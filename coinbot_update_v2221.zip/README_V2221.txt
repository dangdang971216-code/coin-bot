코인봇 v2221

현재 복구 목적
- v2220 Review 파일 복사와 compile은 성공했지만 60초 deadline을 systemctl timeout으로 직접 사용해 stop 후 start가 rc=124로 잘렸다.
- 서버에는 review_worker_v2.097 프로세스 흔적이 있으나 systemd MainPID와 lock 신분이 완성되지 않아 FAIL 상태다.

수정
- 중요한 검사를 삭제하지 않는다.
- deadline은 단계 시작/최종 판정에만 사용하고, 시작한 systemctl stop/start를 1초로 잘라 중단하지 않는다.
- Review는 no-block stop/start 후 빠르게 PID=status=lock=버전을 증명한다.
- 전체 원장 스캔 완료는 배포 PASS 조건이 아니다. Review가 자기 신분을 먼저 쓴 뒤 최근 7일/전체 백필을 계속한다.
- Main/Paper/Review v2220 기능은 그대로 보존한다.
- Strategy/Core/후보/진입/청산/Shadow/원장은 변경하지 않는다.
- 자동매수 OFF.
