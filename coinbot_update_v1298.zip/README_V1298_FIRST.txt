Run /gupgrade_bundle first. Then /grelease_verify and main /version_score.
