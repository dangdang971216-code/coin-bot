#!/usr/bin/env python3
# -*- coding: utf-8 -*-

from __future__ import annotations
import json, os, time, math, traceback, urllib.request
from pathlib import Path
from typing import Any, Dict, List, Tuple, Optional
BASE_DIR = Path(os.getenv("TRADING_BOT_DIR", "/home/dangdang971216/trading_bot"))
def now_ts() -> float: return time.time()
def now_text(ts: Optional[float]=None) -> str: return time.strftime("%Y-%m-%d %H:%M:%S", time.localtime(ts or now_ts()))
def fnum(*vals: Any, default: float=0.0) -> float:
    for v in vals:
        try:
            if v is None or v == "": continue
            return float(str(v).replace(",", "").replace("%", ""))
        except Exception: continue
    return default
def load_json(path: Path, default: Any=None) -> Any:
    try:
        if not path.exists(): return default
        return json.loads(path.read_text(encoding="utf-8", errors="ignore"))
    except Exception: return default
def save_json(path: Path, obj: Any) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    tmp = path.with_suffix(path.suffix + ".tmp")
    tmp.write_text(json.dumps(obj, ensure_ascii=False, separators=(",", ":"), default=str), encoding="utf-8")
    os.replace(tmp, path)
def append_jsonl(path: Path, obj: Dict[str, Any]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("a", encoding="utf-8") as f:
        f.write(json.dumps(obj, ensure_ascii=False, separators=(",", ":"), default=str)+"\n")
def write_jsonl_atomic(path: Path, rows: List[Dict[str, Any]]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    tmp = path.with_suffix(path.suffix + ".tmp")
    with tmp.open("w", encoding="utf-8") as f:
        for r in rows:
            f.write(json.dumps(r, ensure_ascii=False, separators=(",", ":"), default=str)+"\n")
    os.replace(tmp, path)
def read_jsonl(path: Path, max_lines: int=1000) -> List[Dict[str, Any]]:
    if not path.exists(): return []
    try:
        lines = path.read_text(encoding="utf-8", errors="ignore").splitlines()
        if max_lines and len(lines) > max_lines: lines = lines[-max_lines:]
        out=[]
        for ln in lines:
            try:
                if ln.strip():
                    o=json.loads(ln)
                    if isinstance(o,dict): out.append(o)
            except Exception: pass
        return out
    except Exception: return []
def append_error(path: Path, where: str, exc: BaseException) -> None:
    try:
        path.parent.mkdir(parents=True, exist_ok=True)
        with path.open("a", encoding="utf-8") as f:
            f.write(f"[{now_text()}] {where}: {exc.__class__.__name__}: {exc}\n")
            f.write(traceback.format_exc()[-1500:]+"\n")
    except Exception: pass
def ticker_norm(x: Any) -> str:
    t = str(x or "").strip().upper().replace("/", "-").replace("_", "-")
    parts=[p for p in t.split("-") if p]
    if len(parts)>=2:
        non=[p for p in parts if p != "KRW"]
        t = non[-1] if non else parts[-1]
    if t.endswith("KRW") and len(t)>3: t=t[:-3]
    return t.strip().upper()
def pct(a: float, b: float) -> float: return ((a-b)/b*100.0) if b else 0.0
def age_sec(path: Path) -> float:
    try: return max(0.0, now_ts()-path.stat().st_mtime)
    except Exception: return 999999.0
def map_rows(obj: Any) -> Dict[str, Dict[str, Any]]:
    if isinstance(obj, dict) and isinstance(obj.get("rows"), list): obj = obj.get("rows")
    elif isinstance(obj, dict) and isinstance(obj.get("rows"), dict): obj = obj.get("rows")
    elif isinstance(obj, dict) and isinstance(obj.get("cache"), dict): obj = obj.get("cache")
    out: Dict[str, Dict[str, Any]] = {}
    if isinstance(obj, list):
        for r in obj:
            if isinstance(r, dict):
                t=ticker_norm(r.get("ticker") or r.get("symbol") or r.get("market"))
                if t: out[t]=r
    elif isinstance(obj, dict):
        for k,v in obj.items():
            t=ticker_norm(k)
            if t and isinstance(v, dict):
                vv=dict(v); vv.setdefault("ticker", t); out[t]=vv
    return out

VERSION="strategy_worker_v0.24"
INTERVAL_SEC=float(os.getenv("STRATEGY_WORKER_INTERVAL_SEC","2.0"))
STATUS=BASE_DIR/"clean_strategy_worker_status.json"; ERROR=BASE_DIR/"clean_strategy_worker_error.log"
FEATURE=BASE_DIR/"clean_feature_cache.json"; ORDERFLOW=BASE_DIR/"clean_orderflow_summary_cache.json"; REGIME=BASE_DIR/"clean_market_regime_cache.json"; RISK=BASE_DIR/"clean_risk_filter_cache.json"
PAPER=BASE_DIR/"paper_candidates.jsonl"; PAPER_LATEST=BASE_DIR/"paper_candidates_latest.jsonl"; SUMMARY=BASE_DIR/"clean_strategy_s_summary.json"; REJECT=BASE_DIR/"clean_strategy_s_reject_summary.json"; HANDOFF=BASE_DIR/"clean_strategy_paper_handoff_status.json"; WS_TARGETS=BASE_DIR/"clean_ws_targets.json"; MICRO_TARGETS=BASE_DIR/"clean_micro_targets.json"; MICRO_URGENT=BASE_DIR/"clean_micro_urgent_targets.json"; PRIORITY_REQ=BASE_DIR/"clean_strategy_priority_requests.json"; TARGET_ROUTER_QUEUE=BASE_DIR/"clean_target_router_queue.json"
CANDIDATE_TTL_SEC=float(os.getenv("STRATEGY_PAPER_CANDIDATE_TTL_SEC","120"))
STRATEGIES={"money_reaccel_s":"돈흐름 재가속 S","leader_momentum_s":"주도추세 지속 S","breakout_early_s":"돌파 초입 S","sweep_vwap_recovery_s":"저점 VWAP 회복 S","surge_rebreak_s":"급등 후 재돌파 S","leader_flow_adaptive_hold_s":"주도흐름 유동보유 S"}
MAIN_DEPLOY_VERSION="v2.13.369"
MAIN_BOT_VERSION="수익형 v2.13.369"
def write_status(state:str, **extra:Any)->None:
    # v0.13: 성공 사이클이 돌면 이전 error 표시가 남지 않게 상태를 매번 완전히 덮어쓴다.
    obj={"version":VERSION,"state":state,"pid":os.getpid(),"updated_ts":now_ts(),"updated_text":now_text(),"last_error":""}
    obj.update(extra)
    if state == "error" and "error" in extra:
        obj["last_error"] = str(extra.get("error") or "")[:240]
    save_json(STATUS,obj)

def _event_created_ts(ev: Dict[str, Any]) -> float:
    return fnum(ev.get("created_at"), ev.get("candidate_created_at"), ev.get("source_created_at"), ev.get("detected_ts"), ev.get("event_ts"), ev.get("ts"), ev.get("timestamp"), default=0.0)

def _normalize_paper_event(ev: Dict[str, Any], ttl_sec: float = CANDIDATE_TTL_SEC) -> Dict[str, Any]:
    row = dict(ev or {})
    ts = _event_created_ts(row) or now_ts()
    ticker = ticker_norm(row.get("ticker") or row.get("market") or row.get("symbol"))
    skey = str(row.get("strategy_key") or row.get("strategy_bucket_primary") or "strategy_s")
    scan_id = row.get("scan_id") or row.get("source_scan_id") or f"strategy_s_{int(ts // 60)}"
    eid = row.get("event_id") or row.get("id") or row.get("event_key") or f"{ticker}:{skey}:{int(ts // 60)}"
    row.update({
        "ticker": ticker,
        "market": f"KRW-{ticker}" if ticker else row.get("market"),
        "symbol": f"{ticker}_KRW" if ticker else row.get("symbol"),
        "created_at": ts,
        "candidate_created_at": ts,
        "source_created_at": ts,
        "detected_ts": ts,
        "event_ts": ts,
        "created_at_text": row.get("created_at_text") or now_text(ts),
        "detected_at_text": row.get("detected_at_text") or now_text(ts),
        "updated_ts": now_ts(),
        "expires_at": row.get("expires_at") or (ts + ttl_sec),
        "event_id": eid,
        "event_key": eid,
        "scan_id": scan_id,
        "lane": "strict",
        "paper_bot_open": True,
        "open_eligible": True,
        "trade_ready": True,
        "candidate_grade": "S",
        "grade": "S",
    })
    ctx = row.get("entry_context") if isinstance(row.get("entry_context"), dict) else {}
    # paper_bot의 pre-open check가 top-level 또는 entry_context를 모두 볼 수 있게 복제한다.
    for k in ("ws_fresh", "micro_fresh", "spread_pct", "buy_ratio", "sell_pressure", "orderflow_score"):
        if k in ctx and row.get(k) in (None, ""):
            row[k] = ctx.get(k)
    return row

def _paper_event_fresh(ev: Dict[str, Any], nowv: Optional[float] = None) -> bool:
    nowv = nowv or now_ts()
    exp = fnum(ev.get("expires_at"), default=0.0)
    ts = _event_created_ts(ev)
    if exp > 0:
        return exp >= nowv
    return ts > 0 and (nowv - ts) <= CANDIDATE_TTL_SEC

def _paper_dedupe_key(ev: Dict[str, Any]) -> str:
    t = ticker_norm(ev.get("ticker") or ev.get("market") or ev.get("symbol"))
    sk = str(ev.get("strategy_key") or ev.get("strategy_bucket_primary") or "strategy_s")
    return f"{t}:{sk}"

def persist_paper_handoff(events: List[Dict[str, Any]], evaluated: int = 0) -> Tuple[List[Dict[str, Any]], int]:
    """S 후보 handoff를 휘발성 latest 한 번으로 날리지 않는다.
    - 새 S 후보에는 created_at/detected_ts/expires_at/event_id를 고정한다.
    - 새 루프에서 S가 0이어도 TTL 내 기존 S 후보는 latest에 유지한다.
    - archive paper_candidates.jsonl에는 신규 event_id만 append한다.
    """
    nowv = now_ts()
    new_rows = [_normalize_paper_event(e) for e in (events or [])]
    old_latest = [_normalize_paper_event(e) for e in read_jsonl(PAPER_LATEST, max_lines=120)]
    old_archive = [_normalize_paper_event(e) for e in read_jsonl(PAPER, max_lines=500)]
    merged: Dict[str, Dict[str, Any]] = {}
    # 오래된 후보가 새 후보를 덮지 않게 old 먼저, new 나중에 넣는다.
    for ev in old_archive + old_latest + new_rows:
        if not _paper_event_fresh(ev, nowv):
            continue
        key = _paper_dedupe_key(ev)
        if not key:
            continue
        prev = merged.get(key)
        if (prev is None) or fnum(ev.get("score"), default=0.0) >= fnum(prev.get("score"), default=0.0) or _event_created_ts(ev) >= _event_created_ts(prev):
            merged[key] = ev
    latest = sorted(merged.values(), key=lambda e: (fnum(e.get("score"), default=0.0), _event_created_ts(e)), reverse=True)[:40]
    write_jsonl_atomic(PAPER_LATEST, latest)
    recent_ids = {str(r.get("event_id") or r.get("event_key") or "") for r in read_jsonl(PAPER, max_lines=800)}
    appended = 0
    for ev in new_rows:
        eid = str(ev.get("event_id") or ev.get("event_key") or "")
        if eid and eid not in recent_ids:
            append_jsonl(PAPER, ev)
            recent_ids.add(eid)
            appended += 1
    save_json(HANDOFF, {
        "version": VERSION,
        "updated_ts": nowv,
        "updated_text": now_text(nowv),
        "evaluated": evaluated,
        "new_s_count": len(new_rows),
        "paper_latest_count": len(latest),
        "archive_appended": appended,
        "latest_tickers": [e.get("ticker") for e in latest[:20]],
        "ttl_sec": CANDIDATE_TTL_SEC,
        "note": "v0.7: 정보요청은 S/S근접/high만 target_router에 넘김. 일반 정보부족은 queue 폭주 방지를 위해 요청하지 않음.",
    })
    return latest, appended

def risk_bad(t:str)->List[str]:
    r=load_json(RISK,{}) or {}; cd=(r.get("cooldown") or {}) if isinstance(r,dict) else {}
    out=[]
    if t in cd: out.append("최근반복손실/하드손실")
    if t in set(r.get("open_tickers",[]) if isinstance(r,dict) else []): out.append("이미OPEN중")
    return out
def common_hard(row:Dict[str,Any], of:Dict[str,Any])->List[str]:
    """cheap/기본 차단만 본다.
    WS/micro 부족은 여기서 붙이지 않는다.
    v0.8: 붙일 필요도 없는 후보까지 정보부족으로 보이는 문제를 막기 위해
    정보부족은 cheap gate 통과 후보에게만 별도 부여한다.
    """
    hard=[]; t=ticker_norm(row.get("ticker")); hard+=risk_bad(t)
    if row.get("major_watch"): hard.append("대형주는시장참고")
    if bool(of.get("micro_fresh")):
        spread=fnum(of.get("spread_pct"),default=0)
        buy=fnum(of.get("buy_ratio"),default=0)
        if spread>0.28: hard.append(f"스프레드넓음 {spread:.2f}%")
        if buy and buy<0.58: hard.append(f"매수체결약함 {buy:.2f}")
        if of.get("sell_pressure"): hard.append("매도벽/매도체결압력")
    if fnum(row.get("turnover_24h"))<250_000_000: hard.append("거래대금부족")
    if row.get("long_upper_wick"): hard.append("윗꼬리위험")
    if fnum(row.get("day_pos_pct"),default=50)>94 and fnum(row.get("change_5m"))<0.2: hard.append("고점끝물위험")
    return hard[:8]

def orderflow_info_bad(of:Dict[str,Any])->List[str]:
    """v0.9: strategy는 WS 단독 fresh가 아니라 표준 시세(quote_fresh)를 본다.
    quote_fresh는 orderflow_worker가 WS 또는 scanner/feature REST 현재가로 만든 canonical 시세다.
    micro는 호가·체결 판단 재료라 별도로 필요하다.
    """
    info=[]
    if not bool(of.get("quote_fresh") or of.get("ws_fresh")):
        info.append("시세정보보강대기")
    if not bool(of.get("micro_fresh")):
        info.append("micro정보보강대기")
    return info[:4]
def eval_money(r,o):
    no=[]
    if fnum(r.get("change_3m"))<0.25 or fnum(r.get("change_5m"))<0.35: no.append("3/5분재가속부족")
    if fnum(r.get("vwap_gap_pct"))<-0.05 or fnum(r.get("ema5_gap_pct"))<-0.08: no.append("VWAP/EMA유지부족")
    if not r.get("volume_expanding"): no.append("캔들거래량확장부족")
    # micro가 fresh일 때만 매수체결비를 전략 실패로 본다. fresh가 없으면 정보보강대기로 분리한다.
    if o.get("micro_fresh") and fnum(o.get("buy_ratio"))<0.65: no.append("매수체결우세부족")
    return (not no, ["돈흐름재가속","3/5분재가속","VWAP/EMA유지","체결우세"], no)
def eval_leader(r,o):
    no=[]
    if fnum(r.get("change_15m"))<0.65 or fnum(r.get("change_30m"))<0.65: no.append("15/30분주도부족")
    if fnum(r.get("relative_strength_pct"))<0.3: no.append("시장대비강도부족")
    if fnum(r.get("vwap_gap_pct"))<0 or fnum(r.get("ema5_gap_pct"))<0: no.append("VWAP/EMA위치부족")
    if r.get("market_mode") == "약함": no.append("장세약함")
    return (not no, ["15/30분주도","시장대비강함","VWAP/EMA위"], no)
def eval_breakout(r,o):
    no=[]
    if not r.get("breakout_hint"): no.append("돌파캔들미확인")
    if fnum(r.get("recent_high_gap_pct"))<-0.15: no.append("돌파후유지부족")
    if fnum(r.get("change_15m"))>5.0 and not r.get("volume_expanding"): no.append("끝물추격위험")
    return (not no, ["돌파초입","거래량확장","고점돌파유지"], no)
def eval_sweep(r,o):
    no=[]
    if not r.get("sweep_reclaim_hint"): no.append("저점쓸림회복미확인")
    if fnum(r.get("vwap_gap_pct"))<-0.05: no.append("VWAP회복부족")
    if fnum(r.get("recent_low_rebound_pct"))<0.4: no.append("저점방어반등부족")
    return (not no, ["저점이탈실패","VWAP회복","매수회복"], no)
def eval_surge(r,o):
    no=[]
    if fnum(r.get("change_15m"))<1.2: no.append("1차상승부족")
    if fnum(r.get("change_3m"))<0.15: no.append("재돌파시도부족")
    if fnum(r.get("recent_high_gap_pct"))<-0.25: no.append("고점재접근부족")
    if r.get("long_upper_wick"): no.append("윗꼬리반락위험")
    return (not no, ["급등후재돌파","얕은눌림","체결재상승"], no)


def eval_adaptive_hold(r,o):
    """v0.19/v367 주도흐름 유동보유 전략.
    시간 고정이 아니라 0~5분 검증, 5~30분 확인, 30~120분 확장으로 나눠 본다.
    """
    no=[]
    ch1=fnum(r.get("change_1m"), r.get("price_change_1m"), default=0.0)
    ch3=fnum(r.get("change_3m"), r.get("price_change_3m"), default=0.0)
    ch5=fnum(r.get("change_5m"), r.get("price_change_5m"), default=0.0)
    ch15=fnum(r.get("change_15m"), r.get("price_change_15m"), default=0.0)
    ch30=fnum(r.get("change_30m"), r.get("price_change_30m"), default=0.0)
    vwap=fnum(r.get("vwap_gap_pct"), default=-9.0)
    ema=fnum(r.get("ema5_gap_pct"), r.get("ma5_gap_pct"), default=-9.0)
    rel=fnum(r.get("relative_strength_pct"), r.get("relative_strength"), default=0.0)
    day=fnum(r.get("day_pos_pct"), r.get("current_close_pos_ratio"), default=50.0)
    high_gap=fnum(r.get("recent_high_gap_pct"), r.get("below_high_pct"), default=-9.0)
    money=fnum(r.get("turnover_24h"), default=0.0)
    buy=fnum(o.get("buy_ratio"), o.get("micro_trade_buy_ratio_30"), default=0.0)
    spread=fnum(o.get("spread_pct"), default=99.0)
    if not ((ch3 >= 0.20 and ch5 >= 0.25) or (ch15 >= 0.70 and ch30 >= 0.40) or (ch5 >= 0.80 and ch15 >= 0.40)):
        no.append("흐름유지부족")
    if vwap < -0.10 or ema < -0.15:
        no.append("VWAP/EMA유지부족")
    if rel < -1.0 and ch5 < 1.0:
        no.append("시장대비약함")
    if money < 300_000_000:
        no.append("거래대금부족")
    if o.get("micro_fresh") and buy < 0.58:
        no.append("매수체결최소부족")
    if o.get("micro_fresh") and spread > 0.30:
        no.append("스프레드과다")
    if day >= 97.0 and high_gap >= -0.05 and ch1 <= 0.05:
        no.append("고점끝물재확인필요")
    if ch5 >= 12.0 and ema >= 6.0:
        no.append("급등과열재확인필요")
    return (not no, ["주도흐름유지","유동보유","VWAP/EMA방어","시간확장후보"], no)

def _pickv(src: Dict[str, Any], *keys: str, default: Any = None) -> Any:
    for k in keys:
        if isinstance(src, dict) and src.get(k) not in (None, "", "-"):
            return src.get(k)
    return default

def _boolv(v: Any) -> bool:
    if isinstance(v, bool): return v
    return str(v).lower() in {"1", "true", "yes", "ok", "fresh", "신선"}

def _entry_snapshot(row: Dict[str, Any], of: Dict[str, Any], skey: str, reasons: List[str], ts: float, eid: str) -> Dict[str, Any]:
    """v0.11: 진입 당시 전략 판단/복기용 표준 스냅샷.
    조건을 바로 조이는 용도가 아니라, OPEN/CLOSED/score/review가 같은 근거를 보게 하는 저장 schema다.
    """
    t = ticker_norm(row.get("ticker") or row.get("market") or row.get("symbol"))
    snap = {
        "schema": "entry_snapshot_v1",
        "version": VERSION,
        "captured_ts": ts,
        "captured_text": now_text(ts),
        "event_id": eid,
        "ticker": t,
        "price": fnum(row.get("current_price"), row.get("price"), of.get("quote_price"), default=0.0),
        "strategy": {
            "primary_key": skey,
            "primary_label": STRATEGIES.get(skey, skey),
            "reasons": list(reasons or [])[:8],
            "decision_stage": "S1_immediate_candidate",
            "decision_note": "v0.11 정보스냅샷: 조건 변경 없이 S 진입 당시 재료를 보존",
        },
        "price_flow": {
            "change_30s": _pickv(row, "change_30s", "price_change_30s"),
            "change_1m": _pickv(row, "change_1m", "price_change_1m", "change_1"),
            "change_3m": _pickv(row, "change_3m", "price_change_3m", "change_3"),
            "change_5m": _pickv(row, "change_5m", "price_change_5m", "change_5"),
            "change_15m": _pickv(row, "change_15m", "price_change_15m", "change_15"),
            "change_30m": _pickv(row, "change_30m", "price_change_30m", "change_30"),
            "price_reaction_score": _pickv(row, "price_reaction_score", "price_recheck_pct"),
        },
        "position": {
            "vwap_gap_pct": _pickv(row, "vwap_gap_pct"),
            "ema5_gap_pct": _pickv(row, "ema5_gap_pct", "ma5_gap_pct"),
            "ema12_gap_pct": _pickv(row, "ema12_gap_pct"),
            "ema21_gap_pct": _pickv(row, "ema21_gap_pct"),
            "recent_high_gap_pct": _pickv(row, "recent_high_gap_pct", "below_high_pct", "below_30m_high_pct"),
            "recent_low_gap_pct": _pickv(row, "recent_low_gap_pct", "from_low_pct", "from_30m_low_pct"),
            "day_pos_pct": _pickv(row, "day_pos_pct", "current_close_pos_ratio"),
            "recent_low_rebound_pct": _pickv(row, "recent_low_rebound_pct", "low_defense_pct"),
            "breakout_hint": bool(row.get("breakout_hint")),
            "breakout_hold_hint": _pickv(row, "breakout_hold_hint", "breakout_retain_hint"),
            "sweep_reclaim_hint": bool(row.get("sweep_reclaim_hint")),
            "long_upper_wick": bool(row.get("long_upper_wick")),
            "upper_wick_pct": _pickv(row, "upper_wick_pct", "current_upper_wick_pct"),
        },
        "money_flow": {
            "turnover_24h": _pickv(row, "turnover_24h"),
            "turnover_1m": _pickv(row, "turnover_1m", "money_flow_1m"),
            "turnover_3m": _pickv(row, "turnover_3m", "money_flow_3m"),
            "turnover_5m": _pickv(row, "turnover_5m", "money_flow_5m"),
            "volume_expanding": bool(row.get("volume_expanding")),
            "volume_expansion_ratio": _pickv(row, "volume_expansion_ratio", "vol_ratio"),
            "relative_strength_pct": _pickv(row, "relative_strength_pct", "relative_strength"),
            "market_mode": _pickv(row, "market_mode"),
            "market_pressure": _pickv(row, "market_pressure"),
        },
        "orderflow": {
            "quote_fresh": _boolv(of.get("quote_fresh") or of.get("ws_fresh")),
            "quote_source": _pickv(of, "quote_source"),
            "quote_price": _pickv(of, "quote_price"),
            "quote_age_sec": _pickv(of, "quote_age_sec"),
            "ws_fresh": _boolv(of.get("ws_fresh")),
            "ws_age_sec": _pickv(of, "ws_age_sec"),
            "ws_gap_pct": _pickv(of, "ws_gap_pct", "quote_gap_pct", "current_price_ws_gap_pct"),
            "micro_fresh": _boolv(of.get("micro_fresh")),
            "micro_age_sec": _pickv(of, "micro_age_sec"),
            "spread_pct": _pickv(of, "spread_pct"),
            "buy_ratio": _pickv(of, "buy_ratio", "micro_trade_buy_ratio_30"),
            "buy_ratio_30s": _pickv(of, "buy_ratio_30s", "buy_ratio_30", "micro_trade_buy_ratio_30"),
            "buy_ratio_1m": _pickv(of, "buy_ratio_1m", "buy_ratio_60"),
            "bid_wall_ratio": _pickv(of, "bid_wall_ratio", "micro_bid_ask_wall_ratio"),
            "ask_wall_ratio": _pickv(of, "ask_wall_ratio"),
            "sell_pressure": bool(of.get("sell_pressure") or of.get("ask_wall_pressure") or of.get("sell_trade_pressure")),
            "ask_wall_pressure": bool(of.get("ask_wall_pressure")),
            "sell_trade_pressure": bool(of.get("sell_trade_pressure")),
            "slippage_est_pct": _pickv(of, "slippage_est_pct", "tick_pct_est"),
            "orderflow_score": _pickv(of, "orderflow_score"),
        },
        "risk": {
            "major_watch": bool(row.get("major_watch")),
            "quality_risk_tags": row.get("quality_risk_tags") if isinstance(row.get("quality_risk_tags"), list) else [],
            "hard_flags": common_hard(row, of),
            "recent_loss_or_hard": "최근반복손실/하드손실" in common_hard(row, of),
            "high_end_risk": bool(fnum(row.get("day_pos_pct"), default=50)>94 and fnum(row.get("change_5m"))<0.2),
            "sell_pressure": bool(of.get("sell_pressure") or of.get("ask_wall_pressure") or of.get("sell_trade_pressure")),
        },
        "review_after_entry": {
            "track_30s_peak_pct": None,
            "track_1m_peak_pct": None,
            "track_3m_peak_pct": None,
            "peak_reach_sec": None,
            "note": "paper_bot 청산감시가 진입 후 반응/최고수익 도달시간을 보강할 수 있는 자리",
        },
    }
    # 자주 쓰는 값은 flat alias도 같이 보존해 paper_bot 구/신 경로가 모두 읽게 한다.
    flat = {
        "entry_snapshot_schema": snap["schema"],
        "entry_snapshot_version": snap["version"],
                "change_30s": snap["price_flow"].get("change_30s"),
        "change_1m": snap["price_flow"].get("change_1m"),
        "change_3m": snap["price_flow"].get("change_3m"),
        "change_5m": snap["price_flow"].get("change_5m"),
        "change_15m": snap["price_flow"].get("change_15m"),
        "change_30m": snap["price_flow"].get("change_30m"),
        "price_change_3m": snap["price_flow"].get("change_3m"),
        "price_change_5m": snap["price_flow"].get("change_5m"),
        "vwap_gap_pct": snap["position"].get("vwap_gap_pct"),
        "ema5_gap_pct": snap["position"].get("ema5_gap_pct"),
        "recent_high_gap_pct": snap["position"].get("recent_high_gap_pct"),
        "recent_low_gap_pct": snap["position"].get("recent_low_gap_pct"),
        "day_pos_pct": snap["position"].get("day_pos_pct"),
        "relative_strength_pct": snap["money_flow"].get("relative_strength_pct"),
        "relative_strength": snap["money_flow"].get("relative_strength_pct"),
        "turnover_24h": snap["money_flow"].get("turnover_24h"),
        "money_flow_1m": snap["money_flow"].get("turnover_1m"),
        "money_flow_3m": snap["money_flow"].get("turnover_3m"),
        "money_flow_5m": snap["money_flow"].get("turnover_5m"),
        "volume_expanding": snap["money_flow"].get("volume_expanding"),
        "quote_fresh": snap["orderflow"].get("quote_fresh"),
        "quote_source": snap["orderflow"].get("quote_source"),
        "quote_price": snap["orderflow"].get("quote_price"),
        "quote_age_sec": snap["orderflow"].get("quote_age_sec"),
        "ws_fresh": snap["orderflow"].get("ws_fresh"),
        "ws_age_sec": snap["orderflow"].get("ws_age_sec"),
        "ws_gap_pct": snap["orderflow"].get("ws_gap_pct"),
        "current_price_ws_gap_pct": snap["orderflow"].get("ws_gap_pct"),
        "micro_fresh": snap["orderflow"].get("micro_fresh"),
        "micro_age_sec": snap["orderflow"].get("micro_age_sec"),
        "spread_pct": snap["orderflow"].get("spread_pct"),
        "micro_spread_pct": snap["orderflow"].get("spread_pct"),
        "buy_ratio": snap["orderflow"].get("buy_ratio"),
        "micro_trade_buy_ratio_30": snap["orderflow"].get("buy_ratio"),
        "micro_buy_ratio_sustain_1m": snap["orderflow"].get("buy_ratio_1m"),
        "bid_wall_ratio": snap["orderflow"].get("bid_wall_ratio"),
        "micro_bid_ask_wall_ratio": snap["orderflow"].get("bid_wall_ratio"),
        "ask_wall_ratio": snap["orderflow"].get("ask_wall_ratio"),
        "sell_pressure": snap["orderflow"].get("sell_pressure"),
        "micro_ask_wall_pressure": snap["orderflow"].get("ask_wall_pressure"),
        "micro_sell_trade_pressure": snap["orderflow"].get("sell_trade_pressure"),
        "slippage_est_pct": snap["orderflow"].get("slippage_est_pct"),
        "orderflow_score": snap["orderflow"].get("orderflow_score"),
        "quality_risk_tags": snap["risk"].get("quality_risk_tags"),
    }
    snap["flat"] = flat
    return snap

def _snapshot_flat_aliases(snap: Dict[str, Any]) -> Dict[str, Any]:
    if isinstance(snap, dict) and isinstance(snap.get("flat"), dict):
        # v0.13: flat alias 안에는 snapshot 본체를 넣지 않는다.
        # flat -> entry_snapshot -> flat 순환참조가 생기면 json 저장에서 Circular reference로 worker가 error 상태가 된다.
        out = dict(snap.get("flat") or {})
        out.pop("entry_snapshot", None)
        return out
    return {}

def _minimal_entry_snapshot(row: Dict[str, Any], of: Dict[str, Any], skey: str, reasons: List[str], ts: float, eid: str, err: str = "") -> Dict[str, Any]:
    t = ticker_norm(row.get("ticker") or of.get("ticker"))
    snap = {
        "schema": "entry_snapshot_v1", "version": VERSION, "snapshot_status": "partial",
        "snapshot_error": err[:180], "ticker": t, "event_id": eid, "created_at": ts, "created_at_text": now_text(ts),
        "price_flow": {}, "position": {}, "money_flow": {},
        "orderflow": {
            "quote_fresh": bool(of.get("quote_fresh") or of.get("ws_fresh")),
            "ws_fresh": bool(of.get("ws_fresh")), "micro_fresh": bool(of.get("micro_fresh")),
            "spread_pct": of.get("spread_pct"), "buy_ratio": of.get("buy_ratio"),
            "bid_wall_ratio": of.get("bid_wall_ratio"), "ask_wall_ratio": of.get("ask_wall_ratio"),
        },
        "risk": {"hard_flags": common_hard(row, of)},
        "strategy": {"primary_key": skey, "primary_label": STRATEGIES.get(skey, skey), "reasons": reasons[:8]},
        "review_after_entry": {},
    }
    snap["flat"] = {
        "entry_snapshot_schema": snap["schema"], "entry_snapshot_version": snap["version"],         "quote_fresh": snap["orderflow"].get("quote_fresh"), "ws_fresh": snap["orderflow"].get("ws_fresh"),
        "micro_fresh": snap["orderflow"].get("micro_fresh"), "spread_pct": snap["orderflow"].get("spread_pct"),
        "buy_ratio": snap["orderflow"].get("buy_ratio"), "bid_wall_ratio": snap["orderflow"].get("bid_wall_ratio"),
        "ask_wall_ratio": snap["orderflow"].get("ask_wall_ratio"),
        "snapshot_status": snap["snapshot_status"], "snapshot_error": snap["snapshot_error"],
    }
    return snap


def _v361_adaptive_hold_profile(row: Dict[str, Any], of: Dict[str, Any], skey: str) -> Dict[str, Any]:
    """유동 보유형 후보별 청산/복기 프로필."""
    ch5=fnum(row.get('change_5m'), row.get('price_change_5m'), default=0.0)
    ch15=fnum(row.get('change_15m'), row.get('price_change_15m'), default=0.0)
    ch30=fnum(row.get('change_30m'), row.get('price_change_30m'), default=0.0)
    rel=fnum(row.get('relative_strength_pct'), row.get('relative_strength'), default=0.0)
    vwap=fnum(row.get('vwap_gap_pct'), default=0.0)
    ema=fnum(row.get('ema5_gap_pct'), row.get('ma5_gap_pct'), default=0.0)
    strong = (ch15 >= 1.2 and ch30 >= 0.8 and rel >= 0.3) or (ch5 >= 1.2 and ch15 >= 0.8 and vwap >= 0 and ema >= 0)
    ext_tp = 2.20 if strong else 1.80
    max_min = 120 if strong else 75
    return {
        'strategy_family': 'adaptive_hold',
        'strategy_family_label': '주도흐름 유동보유',
        'hold_model': 'adaptive_0_5_30_120',
        'phase_1': '0~5분 진입검증: 가격반응/체결지속/VWAP 방어 없으면 빠른정리',
        'phase_2': '5~30분 수익확인: +0.5~1.2% 도달·VWAP/EMA 유지 시 보유',
        'phase_3': '30~120분 확장: +1.2% 이상 도달 후 추세 유지 시 보호익절로 연장',
        'take_profit_pct': 1.20,
        'extended_target_pct': ext_tp,
        'extended_take_profit_pct': ext_tp,
        'protect_trigger_pct': 0.70,
        'protect_floor_pct': 0.35,
        'stop_loss_pct': -0.60,
        'hard_loss_guard_pct': -0.90,
        'time_exit_minutes': max_min,
        'time_exit_min': max_min,
        'early_validation_minutes': 5,
        'mid_validation_minutes': 30,
        'adaptive_hold_note': '나쁜 후보는 0~5분 검증 실패로 빨리 정리하고, +1.2% 이상 간 후보만 30~120분 확장 관찰',
    }

def build_event(row, of, skey, reasons):
    ts = now_ts()
    t = ticker_norm(row.get("ticker"))
    price = fnum(row.get("current_price"), row.get("price"), of.get("quote_price"), default=0)
    label = STRATEGIES.get(skey, skey)
    eid = f"{t}:{skey}:{int(ts // 60)}"
    try:
        entry_snapshot = _entry_snapshot(row, of, skey, reasons, ts, eid)
    except Exception as exc:
        append_error(ERROR, "entry_snapshot_build", exc)
        entry_snapshot = _minimal_entry_snapshot(row, of, skey, reasons, ts, eid, f"{exc.__class__.__name__}: {exc}")
    aliases = _snapshot_flat_aliases(entry_snapshot)
    base_ctx = dict(aliases)
    base_ctx.update({
        "candidate_created_at": ts,
        "event_id": eid,
        "strategy_key": skey,
        "strategy_name": label,
        "strategy_bucket_primary": skey,
        "strategy_bucket_primary_label": label,
        "strategy_bucket_labels": [label],
        "final_entry_reasons": reasons[:6],
        "entry_snapshot": entry_snapshot,
        "main_version": MAIN_DEPLOY_VERSION,
        "main_bot_version": MAIN_BOT_VERSION,
        "deploy_version": MAIN_DEPLOY_VERSION,
    })
    ev = {
        "event_id": eid,
        "event_key": eid,
        "created_at": ts,
        "candidate_created_at": ts,
        "source_created_at": ts,
        "detected_ts": ts,
        "event_ts": ts,
        "updated_ts": ts,
        "expires_at": ts + CANDIDATE_TTL_SEC,
        "created_at_text": now_text(ts),
        "detected_at_text": now_text(ts),
        "scan_id": f"strategy_s_{int(ts // 60)}",
        "ticker": t,
        "market": f"KRW-{t}",
        "symbol": f"{t}_KRW",
        "strategy_key": skey,
        "strategy": label,
        "strategy_name": label,
        "paper_strategy_key": skey,
        "paper_strategy_label": label,
        "strategy_bucket_primary": skey,
        "strategy_bucket_primary_label": label,
        "strategy_bucket_labels": [label],
        "candidate_grade": "S",
        "grade": "S",
        "candidate_grade_label": "✅ S급 자동매매 상위",
        "paper_bot_open": True,
        "open_eligible": True,
        "trade_ready": True,
        "lane": "strict",
        "current_price": price,
        "entry_price": price,
        "detected_price": price,
        "score": round(13.0 + len(reasons) * 0.9 + fnum(of.get("orderflow_score")) * 0.15, 2),
        "take_profit_pct": 1.80,
        "extended_take_profit_pct": 2.80,
        "protect_trigger_pct": 1.00,
        "protect_floor_pct": 0.45,
        "stop_loss_pct": -0.45,
        "time_exit_minutes": 60,
        "reasons": reasons[:6],
        "quality_risk_tags": aliases.get("quality_risk_tags") or [],
        "entry_context": base_ctx,
        "entry_snapshot": entry_snapshot,
        "entry_snapshot_schema": "entry_snapshot_v1",
        "strategy_reasons": reasons[:6],
        "final_entry_reasons": reasons[:6],
        "brain_version": VERSION,
        "main_version": MAIN_DEPLOY_VERSION,
        "main_bot_version": MAIN_BOT_VERSION,
        "deploy_version": MAIN_DEPLOY_VERSION,
    }
    profile = _v361_adaptive_hold_profile(row, of, skey) if skey == "leader_flow_adaptive_hold_s" else {}
    if profile:
        ev["profile"] = profile
        ev["strategy_family"] = profile.get("strategy_family")
        ev["strategy_family_label"] = profile.get("strategy_family_label")
        ev["hold_model"] = profile.get("hold_model")
        ev["take_profit_pct"] = profile.get("take_profit_pct", ev.get("take_profit_pct"))
        ev["extended_target_pct"] = profile.get("extended_target_pct")
        ev["extended_take_profit_pct"] = profile.get("extended_take_profit_pct")
        ev["protect_trigger_pct"] = profile.get("protect_trigger_pct", ev.get("protect_trigger_pct"))
        ev["protect_floor_pct"] = profile.get("protect_floor_pct", ev.get("protect_floor_pct"))
        ev["stop_loss_pct"] = profile.get("stop_loss_pct", ev.get("stop_loss_pct"))
        ev["hard_loss_guard_pct"] = profile.get("hard_loss_guard_pct")
        ev["time_exit_minutes"] = profile.get("time_exit_minutes", ev.get("time_exit_minutes"))
        ev["time_exit_min"] = profile.get("time_exit_min")
        base_ctx.update(profile)
        if isinstance(entry_snapshot, dict):
            entry_snapshot.setdefault("adaptive_hold_profile", profile)
            strat = entry_snapshot.get("strategy") if isinstance(entry_snapshot.get("strategy"), dict) else {}
            strat.update({"hold_model": profile.get("hold_model"), "strategy_family": profile.get("strategy_family_label"), "decision_note": "v367 주도흐름 유동보유 후보"})
            entry_snapshot["strategy"] = strat
            ev["entry_snapshot"] = entry_snapshot
    ev.update(aliases)
    return ev
def _priority_score(row: Dict[str, Any], core_hits: List[Tuple[str, List[str]]], info_bad: List[str], hard_bad: List[str]) -> float:
    score = 0.0
    score += fnum(row.get("scanner_priority_score"), default=0.0)
    score += min(30.0, max(0.0, fnum(row.get("change_3m"), default=0.0) * 8))
    score += min(30.0, max(0.0, fnum(row.get("change_5m"), default=0.0) * 6))
    score += min(25.0, max(0.0, fnum(row.get("change_15m"), default=0.0) * 3))
    score += min(20.0, max(0.0, fnum(row.get("turnover_24h"), default=0.0) / 400_000_000))
    score += 25.0 * len(core_hits)
    if info_bad:
        score += 15.0
    if hard_bad:
        score -= 35.0
    return round(score, 3)


def _make_priority_request(t: str, row: Dict[str, Any], bucket: str, priority: float, need: List[str], core_hits: List[Tuple[str, List[str]]], reasons: List[str]) -> Dict[str, Any]:
    return {
        "ticker": t,
        "bucket": bucket,
        "priority": round(priority, 3),
        "need": need,
        "core_strategies": [k for k, _ in core_hits],
        "core_strategy_labels": [STRATEGIES.get(k, k) for k, _ in core_hits],
        "reasons": reasons[:8],
        "score": fnum(row.get("scanner_priority_score"), default=0.0),
        "change_3m": fnum(row.get("change_3m"), default=0.0),
        "change_5m": fnum(row.get("change_5m"), default=0.0),
        "change_15m": fnum(row.get("change_15m"), default=0.0),
        "turnover_24h": fnum(row.get("turnover_24h"), default=0.0),
        "updated_ts": now_ts(),
        "source": "strategy_worker",
    }


def _cheap_gate(row: Dict[str, Any], core_hits: List[Tuple[str, List[str]]], hard_bad: List[str]) -> Tuple[bool, str]:
    """정보를 붙일 가치가 있는 후보인지 cheap 재료만으로 먼저 가른다.
    개수 제한이 아니라 우선순위 gate다.
    - S 코어가 맞는 후보는 정보필요 후보
    - 코어가 아직 안 맞아도 돈/흐름/캔들/VWAP가 좋은 후보는 high 후보
    - 나머지는 WS/micro를 붙일 필요 없는 cheap 탈락 후보
    """
    if hard_bad:
        return False, "hard_block"
    if core_hits:
        return True, "core_hit"
    ch3=fnum(row.get("change_3m"), default=0.0)
    ch5=fnum(row.get("change_5m"), default=0.0)
    ch15=fnum(row.get("change_15m"), default=0.0)
    money=fnum(row.get("turnover_24h"), default=0.0)
    score=fnum(row.get("scanner_priority_score"), default=0.0)
    good_flow = (ch3 >= 0.35 and ch5 >= 0.45) or (ch5 >= 0.70) or (ch15 >= 1.20)
    good_position = fnum(row.get("vwap_gap_pct"), default=-9.0) >= -0.10 and fnum(row.get("ema5_gap_pct"), default=-9.0) >= -0.12
    good_signal = bool(row.get("volume_expanding") or row.get("breakout_hint") or row.get("sweep_reclaim_hint"))
    good_money = money >= 500_000_000
    if (good_flow and good_position and (good_signal or good_money)) or (score >= 88 and good_flow):
        return True, "high_cheap"
    return False, "cheap_drop"


def run_once()->Dict[str,Any]:
    st=now_ts(); ts=now_ts(); write_status("running", phase="evaluating", evaluated=0, s_count=0, target_count=0, last_sec=0)
    fobj=load_json(FEATURE,{}) or {}; rows=fobj.get("rows") if isinstance(fobj,dict) else []
    if not isinstance(rows,list): rows=[]
    ofmap=map_rows(load_json(ORDERFLOW,{}) or {})
    evals=[("leader_flow_adaptive_hold_s",eval_adaptive_hold),("money_reaccel_s",eval_money),("leader_momentum_s",eval_leader),("breakout_early_s",eval_breakout),("sweep_vwap_recovery_s",eval_sweep),("surge_rebreak_s",eval_surge)]
    events=[]; rejects=[]; priority_requests=[]; strat_counts={k:0 for k in STRATEGIES}
    info_pending=0; near_s_info_pending=0; hard_blocked=0; info_not_requested=0
    info_needed_count=0; cheap_drop_count=0; fresh_ready_count=0
    orderflow_attached_count=0; quote_ready_count=0; micro_ready_count=0; full_info_ready_count=0
    priority_buckets={}; cheap_buckets={}
    for row in rows:
        t=ticker_norm(row.get("ticker"))
        if not t: continue
        of=ofmap.get(t,{}) or {}
        if of:
            orderflow_attached_count += 1
        quote_ready = bool(of.get("quote_fresh") or of.get("ws_fresh"))
        micro_ready = bool(of.get("micro_fresh"))
        if quote_ready:
            quote_ready_count += 1
        if micro_ready:
            micro_ready_count += 1
        if quote_ready and micro_ready:
            full_info_ready_count += 1
        hard_bad = common_hard(row,of)
        s_hits=[]; reasons=[]; core_hits=[]; core_fail=[]
        for skey,fn in evals:
            ok,why,no=fn(row,of)
            if ok:
                core_hits.append((skey,why))
            else:
                core_fail += [f"{STRATEGIES.get(skey,skey)}:{x}" for x in no[:2]]
        need_info, cheap_bucket = _cheap_gate(row, core_hits, hard_bad)
        cheap_buckets[cheap_bucket]=cheap_buckets.get(cheap_bucket,0)+1
        info_bad = orderflow_info_bad(of) if need_info else []
        need=[]
        if "시세정보보강대기" in info_bad:
            need.append("quote")
        if "WS정보보강대기" in info_bad:
            need.append("ws")
        if "micro정보보강대기" in info_bad:
            need.append("micro")
        if need_info:
            info_needed_count += 1
        if need_info and not info_bad:
            fresh_ready_count += 1
        pscore=_priority_score(row, core_hits, info_bad, hard_bad)
        if info_bad:
            info_pending += 1
        for skey, why in core_hits:
            if not hard_bad and not info_bad:
                s_hits.append((skey,why)); strat_counts[skey]+=1
        if s_hits:
            ev=build_event(row,of,s_hits[0][0],s_hits[0][1])
            if len(s_hits)>1:
                ev["multi_strategy_s"]=[k for k,_ in s_hits]; ev["strategy_bucket_labels"]=[STRATEGIES.get(k,k) for k,_ in s_hits]
            events.append(ev)
            priority_requests.append(_make_priority_request(t,row,"s_candidate",130+pscore, ["quote","micro"], s_hits, ["S후보유지"]))
            priority_buckets["s_candidate"]=priority_buckets.get("s_candidate",0)+1
        elif core_hits and info_bad and not hard_bad:
            near_s_info_pending += 1
            reasons += [f"정보보강대기:{x}" for x in info_bad[:3]] + [f"S근접:{STRATEGIES.get(k,k)}" for k,_ in core_hits[:2]]
            priority_requests.append(_make_priority_request(t,row,"near_s_info_wait",110+pscore, need, core_hits, reasons))
            priority_buckets["near_s_info_wait"]=priority_buckets.get("near_s_info_wait",0)+1
        elif core_hits and hard_bad:
            hard_blocked += 1
            reasons += hard_bad[:4] + [f"S근접차단:{STRATEGIES.get(k,k)}" for k,_ in core_hits[:2]]
            if info_bad:
                info_not_requested += 1
                priority_buckets["hard_blocked_not_requested"]=priority_buckets.get("hard_blocked_not_requested",0)+1
        else:
            if info_bad:
                reasons += [f"정보보강대기:{x}" for x in info_bad[:2]]
            reasons += hard_bad[:2] + core_fail[:4]
            if info_bad:
                # cheap gate를 통과한 high 후보만 정보요청한다. cheap 탈락 후보에는 정보부족을 붙이지 않는다.
                bucket = "info_wait_high"
                priority_requests.append(_make_priority_request(t,row,bucket, 70+pscore, need, core_hits, reasons))
                priority_buckets[bucket]=priority_buckets.get(bucket,0)+1
            else:
                if cheap_bucket == "cheap_drop":
                    cheap_drop_count += 1
                elif not need_info:
                    info_not_requested += 1
        if not s_hits:
            rejects.append({"ticker":t,"score":fnum(row.get("scanner_priority_score")),"priority":pscore,"reasons":reasons[:8],"price":row.get("current_price"),"updated_ts":ts,"info_pending":bool(info_bad),"info_needed":bool(need_info),"near_s_info_pending":bool(core_hits and info_bad and not hard_bad),"cheap_bucket":cheap_bucket})
    events.sort(key=lambda e:fnum(e.get("score")), reverse=True)
    latest, appended = persist_paper_handoff(events, evaluated=len(rows))
    ctr={}
    for r in rejects:
        for reason in r.get("reasons",[])[:5]: ctr[reason]=ctr.get(reason,0)+1
    top=sorted(ctr.items(), key=lambda x:x[1], reverse=True)[:20]
    priority_requests = sorted(priority_requests, key=lambda x: fnum(x.get("priority"), default=0), reverse=True)
    target = list(dict.fromkeys([r.get("ticker") for r in priority_requests if r.get("ticker")]))
    save_json(PRIORITY_REQ,{"version":VERSION,"updated_ts":ts,"updated_text":now_text(ts),"request_count":len(priority_requests),"targets":target,"requests":priority_requests,"buckets":priority_buckets,"cheap_buckets":cheap_buckets,"note":"v0.13: entry_snapshot 순환참조 제거 + cheap gate/orderflow canonical 유지."})
    tq=load_json(TARGET_ROUTER_QUEUE,{}) or {}
    active_set=set(tq.get("active_targets",[]) if isinstance(tq,dict) and isinstance(tq.get("active_targets"),list) else [])
    priority_wait_sample=[]
    for pr in priority_requests[:12]:
        tt=ticker_norm(pr.get("ticker"))
        of=ofmap.get(tt,{}) or {}
        priority_wait_sample.append({
            "ticker": tt,
            "bucket": pr.get("bucket"),
            "need": pr.get("need"),
            "priority": pr.get("priority"),
            "quote_ready": bool(of.get("quote_fresh") or of.get("ws_fresh")),
            "micro_ready": bool(of.get("micro_fresh")),
            "info_ready": bool((of.get("quote_fresh") or of.get("ws_fresh")) and of.get("micro_fresh")),
            "router_active": tt in active_set or bool(of.get("router_active")),
            "micro_age_sec": of.get("micro_age_sec"),
            "quote_age_sec": of.get("quote_age_sec"),
            "reasons": pr.get("reasons",[])[:4],
        })
    common_summary={"version":VERSION,"updated_ts":ts,"updated_text":now_text(ts),"s_count":len(events),"paper_latest_count":len(latest),"archive_appended":appended,"strategies":strat_counts,"events":latest[:12],"evaluated":len(rows),"info_needed_count":info_needed_count,"info_pending_count":info_pending,"near_s_info_pending":near_s_info_pending,"fresh_ready_count":fresh_ready_count,"cheap_reject_count":cheap_drop_count,"hard_blocked_near_s":hard_blocked,"priority_request_count":len(priority_requests),"priority_buckets":priority_buckets,"cheap_buckets":cheap_buckets,"target_count":len(target),"info_not_requested":info_not_requested,"orderflow_attached_count":orderflow_attached_count,"quote_ready_count":quote_ready_count,"micro_ready_count":micro_ready_count,"full_info_ready_count":full_info_ready_count,"router_target_count":tq.get("active_target_count", tq.get("target_count","-")),"router_queue_count":tq.get("queue_count","-"),"router_backlog_count":tq.get("backlog_count","-"),"router_fresh_recovered":tq.get("fresh_recovered","-"),"router_need_ws":tq.get("need_ws","-"),"router_need_micro":tq.get("need_micro","-"),"router_micro_priority_target_count":tq.get("micro_priority_target_count","-"),"router_strategy_req_info_ready":tq.get("strategy_req_info_ready","-"),"priority_wait_sample":priority_wait_sample}
    save_json(SUMMARY,common_summary)
    save_json(REJECT,{**common_summary,"reject_count":len(rejects),"reason_top":[{"reason":k,"count":v} for k,v in top],"sample":rejects[:30],"note":"v0.13: 전체평가 후보에 정보부족을 찍지 않고 cheap gate 통과 후보만 정보요청. entry_snapshot 순환참조 제거."})
    sec=now_ts()-st; write_status("running", evaluated=len(rows), s_count=len(events), paper_latest_count=len(latest), info_needed_count=info_needed_count, info_pending_count=info_pending, near_s_info_pending=near_s_info_pending, cheap_reject_count=cheap_drop_count, fresh_ready_count=fresh_ready_count, info_not_requested=info_not_requested, orderflow_attached_count=orderflow_attached_count, quote_ready_count=quote_ready_count, micro_ready_count=micro_ready_count, full_info_ready_count=full_info_ready_count, priority_request_count=len(priority_requests), target_count=len(target), router_target_count=tq.get("active_target_count", tq.get("target_count","-")), router_queue_count=tq.get("queue_count","-"), router_backlog_count=tq.get("backlog_count","-"), last_sec=round(sec,3)); return {"eval":len(rows),"s":len(events),"paper_latest":len(latest),"priority_requests":len(priority_requests),"info_needed":info_needed_count,"info_pending":info_pending,"cheap_drop":cheap_drop_count}
def main()->None:
    write_status("running", phase="boot", evaluated=0, s_count=0, target_count=0, last_sec=0)
    while True:
        try: run_once()
        except KeyboardInterrupt: write_status("stopping"); raise
        except Exception as exc: append_error(ERROR,"loop",exc); write_status("error", error=f"{exc.__class__.__name__}: {exc}")
        time.sleep(max(0.5,INTERVAL_SEC))


# =============================================================================
# strategy_worker v0.15: 후보 event_id/trace_id 단일화
# - 전략 후보가 archive/latest/paper OPEN/CLOSED까지 같은 ID로 이어지도록 보강한다.
# - 조건/S통과/청산 변경 없음. handoff 추적용 메타만 추가한다.
# =============================================================================
VERSION = "strategy_worker_v0.24"


def _v014_stable_event_id(row: Dict[str, Any], skey: str, ts: Optional[float] = None) -> str:
    t = ticker_norm((row or {}).get("ticker") or (row or {}).get("market") or (row or {}).get("symbol")) or "UNKNOWN"
    sk = str(skey or (row or {}).get("strategy_key") or (row or {}).get("strategy_bucket_primary") or "strategy_s")
    base_ts = fnum((row or {}).get("candidate_created_at"), (row or {}).get("source_created_at"), (row or {}).get("detected_ts"), (row or {}).get("event_ts"), (row or {}).get("created_at"), default=0.0)
    if base_ts <= 0:
        base_ts = ts or now_ts()
    # 30초 버킷: 같은 S 후보가 너무 자주 새 ID로 갈라지지 않게 하되, 너무 오래 같은 후보로 묶이지 않게 한다.
    return f"ev:{t}:{sk}:{int(base_ts // 30)}"


def _v014_attach_trace_fields(row: Dict[str, Any], skey: Optional[str] = None) -> Dict[str, Any]:
    out = dict(row or {})
    sk = str(skey or out.get("strategy_key") or out.get("strategy_bucket_primary") or "strategy_s")
    eid = str(out.get("event_id") or out.get("event_key") or out.get("id") or "")
    if not eid:
        eid = _v014_stable_event_id(out, sk)
        out["event_id_origin"] = "v014_fallback"
    else:
        out.setdefault("event_id_origin", "strategy")
    out["event_id"] = eid
    out["event_key"] = eid
    out["trace_id"] = eid
    out["handoff_id"] = eid
    out["candidate_uid"] = eid
    out["source_event_id"] = eid
    out["handoff_stage"] = "strategy_handoff"
    out["handoff_status"] = "candidate_created"
    ctx = out.get("entry_context") if isinstance(out.get("entry_context"), dict) else {}
    ctx.update({"event_id": eid, "event_key": eid, "trace_id": eid, "handoff_id": eid, "candidate_uid": eid})
    out["entry_context"] = ctx
    snap = out.get("entry_snapshot") if isinstance(out.get("entry_snapshot"), dict) else None
    if snap is not None:
        snap["event_id"] = eid
        snap["trace_id"] = eid
        snap["handoff_id"] = eid
        flat = snap.get("flat") if isinstance(snap.get("flat"), dict) else {}
        flat.update({"event_id": eid, "trace_id": eid, "handoff_id": eid})
        snap["flat"] = flat
        out["entry_snapshot"] = snap
    return out

_v014_prev_build_event = build_event

def build_event(row, of, skey, reasons):  # type: ignore[override]
    ev = _v014_prev_build_event(row, of, skey, reasons)
    return _v014_attach_trace_fields(ev, skey)

_v014_prev_normalize_paper_event = _normalize_paper_event

def _normalize_paper_event(ev: Dict[str, Any], ttl_sec: float = CANDIDATE_TTL_SEC) -> Dict[str, Any]:  # type: ignore[override]
    row = _v014_prev_normalize_paper_event(ev, ttl_sec)
    return _v014_attach_trace_fields(row, row.get("strategy_key") or row.get("strategy_bucket_primary"))



# =============================================================================
# strategy_worker v0.15: S 단일 OPEN을 S1/S2/S3 단계로 분리
# - S1만 즉시 paper OPEN 대상이다.
# - S2는 재확인 후보로 handoff/trace에는 남기되 즉시 OPEN하지 않는다.
# - S3는 관찰/복기 후보로 남긴다.
# - ABC 등급은 새 후보에서 사용하지 않는다.
# =============================================================================
VERSION = "strategy_worker_v0.24"

_v015_prev_build_event = build_event

def _v015_bool(v: Any) -> bool:
    if isinstance(v, bool): return v
    return str(v).strip().lower() in {"1","true","yes","ok","fresh","신선"}

def _v015_stage_decision(row: Dict[str, Any], of: Dict[str, Any], skey: str) -> Tuple[str, List[str]]:
    """v0.16/v359 S1 안전문.
    점수만 높고 가격반응/체결지속/호가 검증이 비어 있던 후보가 S1로 즉시 OPEN되던 구멍을 막는다.
    결측값은 통과가 아니라 S2/S3 강등 사유로 본다.
    """
    def _known(*keys: str, src: Optional[Dict[str, Any]] = None) -> bool:
        d = src if isinstance(src, dict) else row
        for k in keys:
            v = d.get(k)
            if v is not None and str(v).strip() not in {'', '-', 'None', 'nan'}:
                return True
        return False

    ch30s=fnum(row.get('change_30s'), row.get('price_change_30s'), default=0.0)
    ch1=fnum(row.get('change_1m'), row.get('price_change_1m'), default=0.0)
    ch3=fnum(row.get('change_3m'), row.get('price_change_3m'), default=0.0)
    ch5=fnum(row.get('change_5m'), row.get('price_change_5m'), default=0.0)
    ch15=fnum(row.get('change_15m'), row.get('price_change_15m'), default=0.0)
    ch30=fnum(row.get('change_30m'), row.get('price_change_30m'), default=0.0)
    price_react_known=_known('price_reaction_score','price_recheck_pct','price_reaction_pct')
    price_react=fnum(row.get('price_reaction_score'), row.get('price_recheck_pct'), row.get('price_reaction_pct'), default=-999.0)
    vwap=fnum(row.get('vwap_gap_pct'), default=-9.0)
    ema=fnum(row.get('ema5_gap_pct'), row.get('ma5_gap_pct'), default=-9.0)
    high_gap=fnum(row.get('recent_high_gap_pct'), row.get('below_high_pct'), default=0.0)
    low_reb=fnum(row.get('recent_low_rebound_pct'), row.get('low_defense_pct'), default=0.0)
    day=fnum(row.get('day_pos_pct'), row.get('current_close_pos_ratio'), default=50.0)
    rel=fnum(row.get('relative_strength_pct'), row.get('relative_strength'), default=0.0)
    buy=fnum(of.get('buy_ratio'), of.get('buy_ratio_30s'), of.get('micro_trade_buy_ratio_30'), default=0.0)
    buy1_known=_known('buy_ratio_1m','buy_ratio_60','micro_buy_ratio_sustain_1m','buy_ratio_sustain', src=of)
    buy1=fnum(of.get('buy_ratio_1m'), of.get('buy_ratio_60'), of.get('micro_buy_ratio_sustain_1m'), of.get('buy_ratio_sustain'), default=-1.0)
    spread=fnum(of.get('spread_pct'), of.get('micro_spread_pct'), default=99.0)
    slip_known=_known('slippage_est_pct','tick_pct_est','expected_slippage_pct', src=of)
    slip=fnum(of.get('slippage_est_pct'), of.get('tick_pct_est'), of.get('expected_slippage_pct'), default=99.0)
    ask_known=_known('ask_wall_ratio','ask_wall','micro_ask_wall_ratio', src=of)
    ask_wall=fnum(of.get('ask_wall_ratio'), of.get('ask_wall'), of.get('micro_ask_wall_ratio'), default=-1.0)
    bid_wall=fnum(of.get('bid_wall_ratio'), of.get('micro_bid_ask_wall_ratio'), default=0.0)
    micro=_v015_bool(of.get('micro_fresh'))
    ws=_v015_bool(of.get('ws_fresh') or of.get('quote_fresh'))
    vol=bool(row.get('volume_expanding'))
    breakout=bool(row.get('breakout_hint'))
    sweep=bool(row.get('sweep_reclaim_hint'))
    sell=bool(of.get('sell_pressure') or of.get('ask_wall_pressure') or of.get('sell_trade_pressure'))
    hard=common_hard(row, of)
    recent_loss = any('최근반복손실' in str(x) or '하드손실' in str(x) for x in hard)

    tags: List[str]=[]
    if not micro: tags.append('micro재확인필요')
    if not ws: tags.append('WS재확인필요')
    if not price_react_known: tags.append('가격반응미확인')
    elif price_react < 0.05: tags.append('가격반응부족')
    if not buy1_known: tags.append('매수체결지속미확인')
    elif buy1 < 0.64: tags.append('매수체결지속부족')
    if buy and buy < 0.68: tags.append('매수체결우세부족')
    if spread > 0.18: tags.append('스프레드주의')
    if not slip_known or slip > 0.20: tags.append('슬리피지미확인/주의')
    if not ask_known: tags.append('매도벽미확인')
    if sell or (ask_known and ask_wall >= 1.15 and bid_wall < ask_wall): tags.append('매도압력주의')
    if recent_loss: tags.append('최근반복손실주의')

    high_end = day >= 90.0 and high_gap >= -0.20
    overheat = (ch5 >= 6.0 and (ema >= 3.0 or vwap >= 0.80)) or ch15 >= 12.0 or ema >= 8.0
    top_without_react = high_end and (not price_react_known or price_react < 0.08)
    weak_relative_money = skey == 'money_reaccel_s' and rel < 0 and ch5 < 5.0
    if high_end: tags.append('고점권')
    if overheat: tags.append('급등과열/과이격')
    if weak_relative_money: tags.append('상대강도음수')

    # S1은 결측값 대체 금지. 실제 가격반응+체결지속+호가안정이 모두 있어야 한다.
    price_alive_s1 = price_react_known and price_react >= 0.05 and (ch30s >= 0.02 or ch1 >= 0.08 or ch3 >= 0.25)
    flow_alive = (ch3 >= 0.20 or ch5 >= 0.35)
    order_ok_s1 = micro and ws and buy >= 0.70 and buy1_known and buy1 >= 0.64 and spread <= 0.18 and slip_known and slip <= 0.20 and ask_known and not sell
    position_ok_s1 = not recent_loss and not top_without_react and not overheat and not weak_relative_money and vwap >= -0.03 and ema >= -0.05
    base_s1 = order_ok_s1 and position_ok_s1 and price_alive_s1 and flow_alive

    # S2는 살려야 할 후보: 점수/흐름은 있는데 즉시진입 안전문이 부족한 경우.
    # 결측/고점/과열 후보도 버리지 않고 재확인으로 보낸다.
    price_alive_s2 = (price_react_known and price_react >= 0.00) or ch1 >= 0.05 or ch3 >= 0.18 or ch5 >= 0.30 or vol
    order_ok_s2 = micro and buy >= 0.62 and spread <= 0.28 and not sell
    position_ok_s2 = not recent_loss and vwap >= -0.08 and ema >= -0.12

    if skey == 'money_reaccel_s':
        s1 = base_s1 and ch3 >= 0.35 and ch5 >= 0.45 and vol and rel >= 0.0
        s2 = order_ok_s2 and position_ok_s2 and (ch3 >= 0.20 or ch5 >= 0.35 or vol) and not (overheat and not price_react_known)
    elif skey == 'breakout_early_s':
        s1 = base_s1 and breakout and vol and high_gap >= -0.08 and ch3 >= 0.15 and not high_end
        s2 = order_ok_s2 and breakout and high_gap >= -0.25 and (vol or ch3 >= 0.15)
    elif skey == 'sweep_vwap_recovery_s':
        s1 = base_s1 and sweep and low_reb >= 0.55 and ch3 >= 0.08 and day < 88
        s2 = order_ok_s2 and sweep and vwap >= -0.08 and low_reb >= 0.35 and price_alive_s2
    elif skey == 'surge_rebreak_s':
        s1 = base_s1 and ch15 >= 1.20 and ch3 >= 0.25 and high_gap >= -0.15 and not overheat
        s2 = order_ok_s2 and ch15 >= 1.00 and high_gap >= -0.30 and price_alive_s2
    elif skey == 'leader_flow_adaptive_hold_s':
        mid_trend = ch15 >= 0.70 and ch30 >= 0.40 and rel >= 0.0 and vwap >= -0.03 and ema >= -0.05
        early_alive = ch3 >= 0.20 or ch5 >= 0.45 or vol
        s1 = base_s1 and mid_trend and early_alive and not high_end
        s2 = order_ok_s2 and position_ok_s2 and (ch15 >= 0.55 or ch5 >= 0.55) and vwap >= -0.08 and ema >= -0.12 and not recent_loss
    elif skey == 'leader_momentum_s':
        s1 = base_s1 and ch15 >= 0.75 and ch30 >= 0.75 and rel >= 0.40 and row.get('market_mode') != '약함'
        s2 = order_ok_s2 and ch15 >= 0.60 and rel >= 0.25 and vwap >= -0.05 and price_alive_s2
    else:
        s1 = base_s1
        s2 = order_ok_s2 and position_ok_s2 and price_alive_s2

    if s1:
        return 'S1', ['즉시진입안전문통과'] + tags[:7]
    if s2:
        return 'S2', ['재확인후진입후보'] + tags[:7]
    return 'S3', ['관찰복기후보'] + tags[:7]

def _v015_apply_stage(ev: Dict[str, Any], row: Dict[str, Any], of: Dict[str, Any], skey: str) -> Dict[str, Any]:
    stage, why = _v015_stage_decision(row, of, skey)
    out = dict(ev or {})
    label = {'S1':'✅ S1 즉시진입','S2':'⚠️ S2 재확인','S3':'❔ S3 관찰복기'}[stage]
    out['s_stage'] = stage
    out['candidate_grade'] = stage
    out['grade'] = stage
    out['entry_grade'] = stage
    out['signal_grade'] = stage
    out['candidate_grade_label'] = label
    out['s_stage_reasons'] = why[:8]
    out['paper_bot_open'] = stage == 'S1'
    out['open_eligible'] = stage == 'S1'
    out['trade_ready'] = stage == 'S1'
    out['recheck_required'] = stage == 'S2'
    out['observe_only'] = stage == 'S3'
    out['decision_stage'] = stage
    ctx = out.get('entry_context') if isinstance(out.get('entry_context'), dict) else {}
    ctx.update({'s_stage': stage, 'candidate_grade': stage, 'candidate_grade_label': label, 'paper_bot_open': stage == 'S1', 'open_eligible': stage == 'S1', 'trade_ready': stage == 'S1', 's_stage_reasons': why[:8]})
    out['entry_context'] = ctx
    snap = out.get('entry_snapshot') if isinstance(out.get('entry_snapshot'), dict) else None
    if snap is not None:
        strat = snap.get('strategy') if isinstance(snap.get('strategy'), dict) else {}
        strat.update({'decision_stage': stage, 'decision_note': label, 's_stage_reasons': why[:8]})
        snap['strategy'] = strat
        flat = snap.get('flat') if isinstance(snap.get('flat'), dict) else {}
        flat.update({'s_stage': stage, 'candidate_grade': stage, 'candidate_grade_label': label})
        snap['flat'] = flat
        out['entry_snapshot'] = snap
    return out

def build_event(row, of, skey, reasons):  # type: ignore[override]
    ev = _v015_prev_build_event(row, of, skey, reasons)
    return _v015_apply_stage(ev, row, of, skey)

def _normalize_paper_event(ev: Dict[str, Any], ttl_sec: float = CANDIDATE_TTL_SEC) -> Dict[str, Any]:  # type: ignore[override]
    row = dict(ev or {})
    ts = _event_created_ts(row) or now_ts()
    ticker = ticker_norm(row.get('ticker') or row.get('market') or row.get('symbol'))
    skey = str(row.get('strategy_key') or row.get('strategy_bucket_primary') or 'strategy_s')
    scan_id = row.get('scan_id') or row.get('source_scan_id') or f"strategy_s_{int(ts // 60)}"
    eid = row.get('event_id') or row.get('id') or row.get('event_key') or f"{ticker}:{skey}:{int(ts // 60)}"
    stage = str(row.get('s_stage') or row.get('candidate_grade') or row.get('grade') or 'S3').upper()
    if stage == 'S': stage = 'S1'
    if stage not in {'S1','S2','S3'}: stage = 'S3'
    row.update({
        'ticker': ticker, 'market': f'KRW-{ticker}' if ticker else row.get('market'), 'symbol': f'{ticker}_KRW' if ticker else row.get('symbol'),
        'created_at': ts, 'candidate_created_at': ts, 'source_created_at': ts, 'detected_ts': ts, 'event_ts': ts,
        'created_at_text': row.get('created_at_text') or now_text(ts), 'detected_at_text': row.get('detected_at_text') or now_text(ts),
        'updated_ts': now_ts(), 'expires_at': row.get('expires_at') or (ts + ttl_sec), 'event_id': eid, 'event_key': eid,
        'scan_id': scan_id, 'lane': 'strict', 's_stage': stage, 'candidate_grade': stage, 'grade': stage,
        'entry_grade': stage, 'signal_grade': stage,
        'candidate_grade_label': row.get('candidate_grade_label') or {'S1':'✅ S1 즉시진입','S2':'⚠️ S2 재확인','S3':'❔ S3 관찰복기'}[stage],
        'paper_bot_open': stage == 'S1', 'open_eligible': stage == 'S1', 'trade_ready': stage == 'S1',
        'recheck_required': stage == 'S2', 'observe_only': stage == 'S3',
    })
    ctx = row.get('entry_context') if isinstance(row.get('entry_context'), dict) else {}
    for k in ('ws_fresh','micro_fresh','spread_pct','buy_ratio','sell_pressure','orderflow_score'):
        if k in ctx and row.get(k) in (None, ''):
            row[k] = ctx.get(k)
    ctx.update({'s_stage': stage, 'candidate_grade': stage, 'candidate_grade_label': row.get('candidate_grade_label'), 'paper_bot_open': stage == 'S1', 'open_eligible': stage == 'S1', 'trade_ready': stage == 'S1'})
    row['entry_context'] = ctx
    return _v014_attach_trace_fields(row, skey) if '_v014_attach_trace_fields' in globals() else row

_v015_prev_persist_paper_handoff = persist_paper_handoff

def persist_paper_handoff(events: List[Dict[str, Any]], evaluated: int = 0) -> Tuple[List[Dict[str, Any]], int]:  # type: ignore[override]
    latest, appended = _v015_prev_persist_paper_handoff(events, evaluated=evaluated)
    try:
        counts = {'S1':0,'S2':0,'S3':0}
        for r in latest:
            g = str(r.get('s_stage') or r.get('candidate_grade') or r.get('grade') or 'S3').upper()
            if g == 'S': g = 'S1'
            if g in counts: counts[g] += 1
        h = load_json(HANDOFF, {}) or {}
        h.update({'s_stage_counts': counts, 's1_count': counts.get('S1',0), 's2_count': counts.get('S2',0), 's3_count': counts.get('S3',0), 'stage_note': 'v0.15: S1만 즉시 OPEN, S2 재확인, S3 관찰복기'})
        save_json(HANDOFF, h)
    except Exception as exc:
        append_error(ERROR, 'v015_persist_stage_counts', exc)
    return latest, appended


# =============================================================================
# strategy_worker v0.17 / v360: S2/S3 관찰·재확인 배관 복구
# - v359는 S1 안전문으로 손실 폭탄은 막았지만, S 후보를 통과한 뒤에만 S2/S3를 만들었다.
# - 그래서 S1이 0이면 S2/S3도 0이 되어 복기 재료가 사라졌다.
# - v360은 S1 안전문은 유지하고, core_hit 정보대기/차단/근접 후보를 S2/S3로 저장한다.
# - S2/S3는 paper_bot_open=False라 즉시 OPEN하지 않고, 1시간 요약/복기/trace용으로만 남긴다.
# =============================================================================

def _v360_force_stage(ev: Dict[str, Any], stage: str, extra_reasons: List[str]) -> Dict[str, Any]:
    stage = str(stage or 'S3').upper()
    if stage not in {'S1','S2','S3'}:
        stage = 'S3'
    out = dict(ev or {})
    label = {'S1':'✅ S1 즉시진입','S2':'⚠️ S2 재확인','S3':'❔ S3 관찰복기'}[stage]
    reasons = list(out.get('s_stage_reasons') if isinstance(out.get('s_stage_reasons'), list) else [])
    for r in extra_reasons or []:
        if r and r not in reasons:
            reasons.append(str(r))
    out.update({
        's_stage': stage,
        'candidate_grade': stage,
        'grade': stage,
        'entry_grade': stage,
        'signal_grade': stage,
        'candidate_grade_label': label,
        's_stage_reasons': reasons[:10],
        'paper_bot_open': stage == 'S1',
        'open_eligible': stage == 'S1',
        'trade_ready': stage == 'S1',
        'recheck_required': stage == 'S2',
        'observe_only': stage == 'S3',
        'decision_stage': stage,
        'final_entry_action': 'paper_open' if stage == 'S1' else ('recheck_wait' if stage == 'S2' else 'observe'),
        'final_entry_label': label,
        'trade_ready_label': label,
        'summary_reason': ','.join(reasons[:5]) or label,
    })
    ctx = out.get('entry_context') if isinstance(out.get('entry_context'), dict) else {}
    ctx.update({
        's_stage': stage,
        'candidate_grade': stage,
        'candidate_grade_label': label,
        'paper_bot_open': stage == 'S1',
        'open_eligible': stage == 'S1',
        'trade_ready': stage == 'S1',
        'recheck_required': stage == 'S2',
        'observe_only': stage == 'S3',
        's_stage_reasons': reasons[:10],
        'final_entry_action': out.get('final_entry_action'),
        'final_entry_label': label,
    })
    out['entry_context'] = ctx
    snap = out.get('entry_snapshot') if isinstance(out.get('entry_snapshot'), dict) else None
    if snap is not None:
        strat = snap.get('strategy') if isinstance(snap.get('strategy'), dict) else {}
        strat.update({'decision_stage': stage, 'decision_note': label, 's_stage_reasons': reasons[:10]})
        snap['strategy'] = strat
        flat = snap.get('flat') if isinstance(snap.get('flat'), dict) else {}
        flat.update({'s_stage': stage, 'candidate_grade': stage, 'candidate_grade_label': label, 'paper_bot_open': stage == 'S1'})
        snap['flat'] = flat
        out['entry_snapshot'] = snap
    return out

def _v360_near_strategy_hits(row: Dict[str, Any], of: Dict[str, Any], evals: List[Tuple[str, Any]]) -> List[Tuple[str, List[str], List[str]]]:
    """S1/S strict 통과 전 단계의 근접 후보를 찾는다.
    조건을 통과하지 못한 후보를 전부 살리는 게 아니라, 한두 개 부족한 후보만 S3 관찰로 남긴다.
    """
    near: List[Tuple[str, List[str], List[str]]] = []
    for skey, fn in evals:
        try:
            ok, why, no = fn(row, of)
            if ok:
                continue
            no = list(no or [])
            # v367: S2/S3 관찰은 strict 통과 직전만 보지 않는다.
            # 거래대금 자체가 부족한 후보는 버리되, 흐름/위치/체결 중 3~4개 부족한 근접 후보는 S3 복기로 남긴다.
            no_text = ','.join(map(str, no))
            hard_missing = ('거래대금부족' in no_text) or ('흐름유지부족' in no_text and 'VWAP/EMA유지부족' in no_text and len(no) >= 5)
            limit = 4 if skey == 'leader_flow_adaptive_hold_s' else 3
            if (not hard_missing) and len(no) <= limit:
                near.append((skey, list(why or []), no))
        except Exception:
            continue
    def score(item: Tuple[str, List[str], List[str]]) -> float:
        skey, _why, no = item
        pri = _priority_score(row, [(skey, _why)], [], [])
        return pri - len(no) * 3.0
    near.sort(key=score, reverse=True)
    return near[:3]

def run_once()->Dict[str,Any]:  # type: ignore[override]
    st=now_ts(); ts=now_ts(); write_status("running", phase="evaluating_v367", evaluated=0, s_count=0, target_count=0, last_sec=0)
    fobj=load_json(FEATURE,{}) or {}; rows=fobj.get("rows") if isinstance(fobj,dict) else []
    if not isinstance(rows,list): rows=[]
    ofmap=map_rows(load_json(ORDERFLOW,{}) or {})
    evals=[("leader_flow_adaptive_hold_s",eval_adaptive_hold),("money_reaccel_s",eval_money),("leader_momentum_s",eval_leader),("breakout_early_s",eval_breakout),("sweep_vwap_recovery_s",eval_sweep),("surge_rebreak_s",eval_surge)]
    events=[]; rejects=[]; priority_requests=[]; strat_counts={k:0 for k in STRATEGIES}
    info_pending=0; near_s_info_pending=0; hard_blocked=0; info_not_requested=0
    info_needed_count=0; cheap_drop_count=0; fresh_ready_count=0
    orderflow_attached_count=0; quote_ready_count=0; micro_ready_count=0; full_info_ready_count=0
    priority_buckets={}; cheap_buckets={}; stage_source_counts={"S1":0,"S2":0,"S3":0,"core_ready":0,"core_info_wait":0,"core_hard_block":0,"near_observe":0}
    for row in rows:
        t=ticker_norm(row.get("ticker"))
        if not t: continue
        of=ofmap.get(t,{}) or {}
        if of: orderflow_attached_count += 1
        quote_ready = bool(of.get("quote_fresh") or of.get("ws_fresh"))
        micro_ready = bool(of.get("micro_fresh"))
        if quote_ready: quote_ready_count += 1
        if micro_ready: micro_ready_count += 1
        if quote_ready and micro_ready: full_info_ready_count += 1
        hard_bad = common_hard(row,of)
        reasons=[]; core_hits=[]; core_fail=[]
        for skey,fn in evals:
            ok,why,no=fn(row,of)
            if ok:
                core_hits.append((skey,why))
            else:
                core_fail += [f"{STRATEGIES.get(skey,skey)}:{x}" for x in no[:2]]
        need_info, cheap_bucket = _cheap_gate(row, core_hits, hard_bad)
        cheap_buckets[cheap_bucket]=cheap_buckets.get(cheap_bucket,0)+1
        info_bad = orderflow_info_bad(of) if need_info else []
        need=[]
        if "시세정보보강대기" in info_bad: need.append("quote")
        if "WS정보보강대기" in info_bad: need.append("ws")
        if "micro정보보강대기" in info_bad: need.append("micro")
        if need_info: info_needed_count += 1
        if need_info and not info_bad: fresh_ready_count += 1
        pscore=_priority_score(row, core_hits, info_bad, hard_bad)
        if info_bad: info_pending += 1

        # 1) core strategy가 맞고 정보/하드 문제가 없으면 기존처럼 이벤트 생성. v359 안전문이 S1/S2/S3를 최종 결정한다.
        if core_hits and not hard_bad and not info_bad:
            ev=build_event(row,of,core_hits[0][0],core_hits[0][1])
            if len(core_hits)>1:
                ev["multi_strategy_s"]=[k for k,_ in core_hits]; ev["strategy_bucket_labels"]=[STRATEGIES.get(k,k) for k,_ in core_hits]
            events.append(ev)
            g=str(ev.get('s_stage') or ev.get('candidate_grade') or 'S3').upper(); stage_source_counts[g if g in stage_source_counts else 'S3']+=1; stage_source_counts['core_ready']+=1
            strat_counts[core_hits[0][0]]+=1
            priority_requests.append(_make_priority_request(t,row,"s_candidate",130+pscore, ["quote","micro"], core_hits, ["S후보유지"]))
            priority_buckets["s_candidate"]=priority_buckets.get("s_candidate",0)+1
        # 2) core는 맞지만 정보가 모자라면 S2 재확인으로 남긴다. 즉시 OPEN은 절대 안 한다.
        elif core_hits and info_bad and not hard_bad:
            near_s_info_pending += 1
            reasons += [f"정보보강대기:{x}" for x in info_bad[:3]] + [f"S2재확인:{STRATEGIES.get(k,k)}" for k,_ in core_hits[:2]]
            ev=build_event(row,of,core_hits[0][0],core_hits[0][1])
            ev=_v360_force_stage(ev,'S2',reasons[:8])
            events.append(ev); stage_source_counts['S2']+=1; stage_source_counts['core_info_wait']+=1
            priority_requests.append(_make_priority_request(t,row,"s2_recheck_info_wait",115+pscore, need or ["quote","micro"], core_hits, reasons))
            priority_buckets["s2_recheck_info_wait"]=priority_buckets.get("s2_recheck_info_wait",0)+1
        # 3) core는 맞지만 최근손실/고점/스프레드 등 hard가 있으면 S3 관찰로 남긴다.
        elif core_hits and hard_bad:
            hard_blocked += 1
            reasons += hard_bad[:4] + [f"S3관찰:{STRATEGIES.get(k,k)}" for k,_ in core_hits[:2]]
            ev=build_event(row,of,core_hits[0][0],core_hits[0][1])
            ev=_v360_force_stage(ev,'S3',reasons[:8])
            events.append(ev); stage_source_counts['S3']+=1; stage_source_counts['core_hard_block']+=1
            if info_bad:
                info_not_requested += 1
                priority_buckets["hard_blocked_not_requested"]=priority_buckets.get("hard_blocked_not_requested",0)+1
        else:
            # 4) strict S는 아니지만 한두 조건만 부족한 후보는 S3 관찰복기로 살린다.
            near_hits = _v360_near_strategy_hits(row, of, evals)
            if near_hits and not any('거래대금부족' in str(x) for x in hard_bad):
                skey, why, missing = near_hits[0]
                reasons += [f"근접부족:{x}" for x in missing[:3]] + [f"S3관찰:{STRATEGIES.get(skey,skey)}"]
                if info_bad:
                    reasons += [f"정보보강대기:{x}" for x in info_bad[:2]]
                ev=build_event(row,of,skey,why)
                ev=_v360_force_stage(ev,'S3',reasons[:8])
                events.append(ev); stage_source_counts['S3']+=1; stage_source_counts['near_observe']+=1
                if info_bad:
                    bucket="s3_observe_info_wait"
                    priority_requests.append(_make_priority_request(t,row,bucket, 75+pscore, need, [(skey,why)], reasons))
                    priority_buckets[bucket]=priority_buckets.get(bucket,0)+1
            else:
                if info_bad:
                    reasons += [f"정보보강대기:{x}" for x in info_bad[:2]]
                reasons += hard_bad[:2] + core_fail[:4]
                if info_bad:
                    bucket = "info_wait_high"
                    priority_requests.append(_make_priority_request(t,row,bucket, 70+pscore, need, core_hits, reasons))
                    priority_buckets[bucket]=priority_buckets.get(bucket,0)+1
                else:
                    if cheap_bucket == "cheap_drop": cheap_drop_count += 1
                    elif not need_info: info_not_requested += 1
        if not core_hits:
            rejects.append({"ticker":t,"score":fnum(row.get("scanner_priority_score")),"priority":pscore,"reasons":reasons[:8] if reasons else core_fail[:8],"price":row.get("current_price"),"updated_ts":ts,"info_pending":bool(info_bad),"info_needed":bool(need_info),"near_s_info_pending":False,"cheap_bucket":cheap_bucket})
        elif not (not hard_bad and not info_bad):
            rejects.append({"ticker":t,"score":fnum(row.get("scanner_priority_score")),"priority":pscore,"reasons":reasons[:8],"price":row.get("current_price"),"updated_ts":ts,"info_pending":bool(info_bad),"info_needed":bool(need_info),"near_s_info_pending":bool(core_hits and info_bad and not hard_bad),"cheap_bucket":cheap_bucket})
    events.sort(key=lambda e:(0 if str(e.get('s_stage') or e.get('candidate_grade')).upper()=='S1' else -1, fnum(e.get("score")), _event_created_ts(e)), reverse=True)
    latest, appended = persist_paper_handoff(events, evaluated=len(rows))
    ctr={}
    for r in rejects:
        for reason in r.get("reasons",[])[:5]: ctr[reason]=ctr.get(reason,0)+1
    top=sorted(ctr.items(), key=lambda x:x[1], reverse=True)[:20]
    priority_requests = sorted(priority_requests, key=lambda x: fnum(x.get("priority"), default=0), reverse=True)
    target = list(dict.fromkeys([r.get("ticker") for r in priority_requests if r.get("ticker")]))
    save_json(PRIORITY_REQ,{"version":VERSION,"updated_ts":ts,"updated_text":now_text(ts),"request_count":len(priority_requests),"targets":target,"requests":priority_requests,"buckets":priority_buckets,"cheap_buckets":cheap_buckets,"stage_source_counts":stage_source_counts,"note":"v0.19/v367: S1 안전문 유지 + S2/S3 관찰배관 복구. core 정보대기/차단/근접 후보를 OPEN 없이 복기용으로 저장."})
    tq=load_json(TARGET_ROUTER_QUEUE,{}) or {}
    active_set=set(tq.get("active_targets",[]) if isinstance(tq,dict) and isinstance(tq.get("active_targets"),list) else [])
    priority_wait_sample=[]
    for pr in priority_requests[:12]:
        tt=ticker_norm(pr.get("ticker")); of=ofmap.get(tt,{}) or {}
        priority_wait_sample.append({"ticker": tt,"bucket": pr.get("bucket"),"need": pr.get("need"),"priority": pr.get("priority"),"quote_ready": bool(of.get("quote_fresh") or of.get("ws_fresh")),"micro_ready": bool(of.get("micro_fresh")),"info_ready": bool((of.get("quote_fresh") or of.get("ws_fresh")) and of.get("micro_fresh")),"router_active": tt in active_set or bool(of.get("router_active")),"micro_age_sec": of.get("micro_age_sec"),"quote_age_sec": of.get("quote_age_sec"),"reasons": pr.get("reasons",[])[:4]})
    stage_counts={"S1":0,"S2":0,"S3":0}
    for ev in latest:
        g=str(ev.get('s_stage') or ev.get('candidate_grade') or ev.get('grade') or 'S3').upper()
        if g == 'S': g='S1'
        if g in stage_counts: stage_counts[g]+=1
    common_summary={"version":VERSION,"updated_ts":ts,"updated_text":now_text(ts),"s_count":len(events),"paper_latest_count":len(latest),"archive_appended":appended,"strategies":strat_counts,"events":latest[:12],"evaluated":len(rows),"s_stage_counts":stage_counts,"stage_source_counts":stage_source_counts,"info_needed_count":info_needed_count,"info_pending_count":info_pending,"near_s_info_pending":near_s_info_pending,"fresh_ready_count":fresh_ready_count,"cheap_reject_count":cheap_drop_count,"hard_blocked_near_s":hard_blocked,"priority_request_count":len(priority_requests),"priority_buckets":priority_buckets,"cheap_buckets":cheap_buckets,"target_count":len(target),"info_not_requested":info_not_requested,"orderflow_attached_count":orderflow_attached_count,"quote_ready_count":quote_ready_count,"micro_ready_count":micro_ready_count,"full_info_ready_count":full_info_ready_count,"router_target_count":tq.get("active_target_count", tq.get("target_count","-")),"router_queue_count":tq.get("queue_count","-"),"router_backlog_count":tq.get("backlog_count","-"),"router_fresh_recovered":tq.get("fresh_recovered","-"),"router_need_ws":tq.get("need_ws","-"),"router_need_micro":tq.get("need_micro","-"),"router_micro_priority_target_count":tq.get("micro_priority_target_count","-"),"router_strategy_req_info_ready":tq.get("strategy_req_info_ready","-"),"priority_wait_sample":priority_wait_sample,"note":"v0.19/v367: S1은 엄격, S2/S3는 OPEN 없이 관찰·복기용으로 저장"}
    save_json(SUMMARY,common_summary)
    save_json(REJECT,{**common_summary,"reject_count":len(rejects),"reason_top":[{"reason":k,"count":v} for k,v in top],"sample":rejects[:30],"note":"v0.19/v367: S2/S3 관찰 후보를 살리되 S1 즉시진입은 안전문 유지."})
    sec=now_ts()-st; write_status("running", evaluated=len(rows), s_count=len(events), paper_latest_count=len(latest), s1_count=stage_counts.get('S1',0), s2_count=stage_counts.get('S2',0), s3_count=stage_counts.get('S3',0), info_needed_count=info_needed_count, info_pending_count=info_pending, near_s_info_pending=near_s_info_pending, cheap_reject_count=cheap_drop_count, fresh_ready_count=fresh_ready_count, info_not_requested=info_not_requested, orderflow_attached_count=orderflow_attached_count, quote_ready_count=quote_ready_count, micro_ready_count=micro_ready_count, full_info_ready_count=full_info_ready_count, priority_request_count=len(priority_requests), target_count=len(target), router_target_count=tq.get("active_target_count", tq.get("target_count","-")), router_queue_count=tq.get("queue_count","-"), router_backlog_count=tq.get("backlog_count","-"), last_sec=round(sec,3)); return {"eval":len(rows),"s":len(events),"paper_latest":len(latest),"s_stage_counts":stage_counts,"priority_requests":len(priority_requests),"info_needed":info_needed_count,"info_pending":info_pending,"cheap_drop":cheap_drop_count}



# =============================================================================
# strategy_worker v0.22 / v370: 끊긴 main_version stamping 본선 재연결
# - v367은 near 조건이 strict eval 실패 개수에 묶여 S2/S3가 0으로 죽었다.
# - v368은 strict S1 안전문은 유지하되, 거래대금·흐름·위치·주도성 기반 관찰 후보를 S2/S3로 별도 저장한다.
# - S2/S3는 paper OPEN 대상이 아니며 복기/1시간요약/정보보강 대상이다.
# =============================================================================
VERSION = "strategy_worker_v0.24"
MAIN_VERSION = "v2.13.369"


def _v370_apply_main_version(ev: Dict[str, Any]) -> Dict[str, Any]:
    """v370 worker-only surgery.
    v369 tail called a removed _v368_apply_main_version() helper and strategy worker
    stopped before writing paper/S2/S3 handoff files. This is not a fallback; it is
    the single metadata stamping path used right before S1/S2/S3 persistence.
    """
    out = dict(ev or {})
    main_version = MAIN_VERSION
    main_bot_version = globals().get("MAIN_BOT_VERSION", f"수익형 {main_version}")
    out["main_version"] = main_version
    out["deploy_version"] = main_version
    out["main_bot_version"] = main_bot_version
    out["strategy_worker_version"] = VERSION
    out["worker_patch"] = "v370_strategy_main_version_stamping"
    ctx = out.get("entry_context") if isinstance(out.get("entry_context"), dict) else {}
    ctx.update({
        "main_version": main_version,
        "deploy_version": main_version,
        "main_bot_version": main_bot_version,
        "strategy_worker_version": VERSION,
    })
    out["entry_context"] = ctx
    snap = out.get("entry_snapshot") if isinstance(out.get("entry_snapshot"), dict) else None
    if snap is not None:
        snap["main_version"] = main_version
        snap["deploy_version"] = main_version
        snap["strategy_worker_version"] = VERSION
        flat = snap.get("flat") if isinstance(snap.get("flat"), dict) else {}
        flat.update({
            "main_version": main_version,
            "deploy_version": main_version,
            "main_bot_version": main_bot_version,
            "strategy_worker_version": VERSION,
        })
        snap["flat"] = flat
        out["entry_snapshot"] = snap
    return out


def _v368_soft_signal(row: Dict[str, Any], of: Dict[str, Any]) -> Tuple[str, str, List[str], float]:
    """v369: strict S1은 아니어도 복기할 가치가 있는 후보를 S2/S3로 남긴다.
    쓰레기 후보(거래대금 부족/강한 매도압력)는 제외한다.
    """
    ch1=fnum(row.get('change_1m'), row.get('price_change_1m'), default=0.0)
    ch3=fnum(row.get('change_3m'), row.get('price_change_3m'), default=0.0)
    ch5=fnum(row.get('change_5m'), row.get('price_change_5m'), default=0.0)
    ch15=fnum(row.get('change_15m'), row.get('price_change_15m'), default=0.0)
    ch30=fnum(row.get('change_30m'), row.get('price_change_30m'), default=0.0)
    money=fnum(row.get('turnover_24h'), row.get('acc_trade_price_24h'), default=0.0)
    vwap=fnum(row.get('vwap_gap_pct'), default=-9.0)
    ema=fnum(row.get('ema5_gap_pct'), row.get('ma5_gap_pct'), default=-9.0)
    rel=fnum(row.get('relative_strength_pct'), row.get('relative_strength'), default=0.0)
    day=fnum(row.get('day_pos_pct'), row.get('current_close_pos_ratio'), default=50.0)
    score=fnum(row.get('scanner_priority_score'), default=0.0)
    buy=fnum(of.get('buy_ratio'), of.get('buy_ratio_30s'), of.get('micro_trade_buy_ratio_30'), default=0.0)
    spread=fnum(of.get('spread_pct'), of.get('micro_spread_pct'), default=99.0)
    micro=bool(of.get('micro_fresh'))
    quote=bool(of.get('quote_fresh') or of.get('ws_fresh'))
    vol=bool(row.get('volume_expanding'))
    hard=common_hard(row, of)
    hard_text=','.join(map(str, hard))
    if money < 250_000_000:
        return '', '', ['거래대금부족'], 0.0
    if '매도벽/매도체결압력' in hard_text and buy < 0.68:
        return '', '', ['매도압력+매수부족'], 0.0
    info_missing = not (micro and quote) or spread > 0.18
    position_ok = (vwap >= -0.45 and ema >= -0.35)
    not_extreme_hot = not (day >= 98.5 and ch5 >= 5.0 and rel < 3.0)
    # 유동보유: 5/15/30분 흐름, 상대강도, 위치 중 2개 이상 살아있으면 관찰
    trend_score = 0
    if ch5 >= 0.35: trend_score += 1
    if ch15 >= 0.35: trend_score += 1
    if ch30 >= 0.10: trend_score += 1
    if rel >= 1.2: trend_score += 1
    if vol: trend_score += 1
    if position_ok: trend_score += 1
    if trend_score >= 4 and not_extreme_hot:
        reasons=['유동보유근접', f'흐름점수{trend_score}', f'5m{ch5:.2f}', f'15m{ch15:.2f}', f'상대{rel:.2f}']
        return ('S3' if info_missing else 'S2'), 'leader_flow_adaptive_hold_s', reasons, 105.0 + score + trend_score
    # 돈흐름/돌파 근접: 한두 재료만 있어도 완전 폐기하지 않고 S3 복기
    if (ch3 >= 0.45 and ch5 >= 0.45 and position_ok) or (rel >= 2.0 and ch5 >= 0.20):
        reasons=['S근접관찰', f'3m{ch3:.2f}', f'5m{ch5:.2f}', f'상대{rel:.2f}']
        return ('S3' if info_missing else 'S2'), 'money_reaccel_s', reasons, 95.0 + score
    return '', '', [], 0.0

def _v370_build_stage_event(row: Dict[str, Any], of: Dict[str, Any], skey: str, why: List[str], stage: str, reasons: List[str]) -> Dict[str, Any]:
    ev=build_event(row, of, skey, why or reasons)
    ev=_v360_force_stage(ev, stage, reasons[:10])
    ev=_v370_apply_main_version(ev)
    return ev


def run_once()->Dict[str,Any]:  # type: ignore[override]
    st=now_ts(); ts=now_ts(); write_status("running", phase="evaluating_v370", evaluated=0, s_count=0, target_count=0, last_sec=0)
    fobj=load_json(FEATURE,{}) or {}; rows=fobj.get("rows") if isinstance(fobj,dict) else []
    if not isinstance(rows,list): rows=[]
    ofmap=map_rows(load_json(ORDERFLOW,{}) or {})
    evals=[("leader_flow_adaptive_hold_s",eval_adaptive_hold),("money_reaccel_s",eval_money),("leader_momentum_s",eval_leader),("breakout_early_s",eval_breakout),("sweep_vwap_recovery_s",eval_sweep),("surge_rebreak_s",eval_surge)]
    events=[]; rejects=[]; priority_requests=[]; strat_counts={k:0 for k in STRATEGIES}
    info_pending=0; near_s_info_pending=0; hard_blocked=0; info_not_requested=0
    info_needed_count=0; cheap_drop_count=0; fresh_ready_count=0
    orderflow_attached_count=0; quote_ready_count=0; micro_ready_count=0; full_info_ready_count=0
    priority_buckets={}; cheap_buckets={}; stage_source_counts={"S1":0,"S2":0,"S3":0,"core_ready":0,"core_info_wait":0,"core_hard_block":0,"soft_observe":0}
    for row in rows:
        t=ticker_norm(row.get("ticker"))
        if not t: continue
        of=ofmap.get(t,{}) or {}
        if of: orderflow_attached_count += 1
        quote_ready=bool(of.get("quote_fresh") or of.get("ws_fresh")); micro_ready=bool(of.get("micro_fresh"))
        if quote_ready: quote_ready_count += 1
        if micro_ready: micro_ready_count += 1
        if quote_ready and micro_ready: full_info_ready_count += 1
        hard_bad=common_hard(row,of)
        reasons=[]; core_hits=[]; core_fail=[]
        for skey,fn in evals:
            try:
                ok,why,no=fn(row,of)
            except Exception as exc:
                ok=False; why=[]; no=[f"eval오류:{skey}"]
            if ok: core_hits.append((skey,why))
            else: core_fail += [f"{STRATEGIES.get(skey,skey)}:{x}" for x in list(no or [])[:2]]
        need_info, cheap_bucket=_cheap_gate(row, core_hits, hard_bad)
        cheap_buckets[cheap_bucket]=cheap_buckets.get(cheap_bucket,0)+1
        info_bad=orderflow_info_bad(of) if need_info else []
        need=[]
        if "시세정보보강대기" in info_bad: need.append("quote")
        if "WS정보보강대기" in info_bad: need.append("ws")
        if "micro정보보강대기" in info_bad: need.append("micro")
        if need_info: info_needed_count += 1
        if need_info and not info_bad: fresh_ready_count += 1
        pscore=_priority_score(row, core_hits, info_bad, hard_bad)
        if info_bad: info_pending += 1
        made=False
        if core_hits and not hard_bad and not info_bad:
            ev=_v370_build_stage_event(row,of,core_hits[0][0],core_hits[0][1],'S1', ['core_ready'])
            if len(core_hits)>1:
                ev["multi_strategy_s"]=[k for k,_ in core_hits]; ev["strategy_bucket_labels"]=[STRATEGIES.get(k,k) for k,_ in core_hits]
            events.append(ev); made=True
            g=str(ev.get('s_stage') or 'S3').upper(); stage_source_counts[g if g in stage_source_counts else 'S3']+=1; stage_source_counts['core_ready']+=1
            strat_counts[core_hits[0][0]]+=1
            priority_requests.append(_make_priority_request(t,row,"s1_candidate",130+pscore,["quote","micro"],core_hits,["S1후보"]))
            priority_buckets["s1_candidate"]=priority_buckets.get("s1_candidate",0)+1
        elif core_hits and info_bad and not hard_bad:
            near_s_info_pending += 1
            reasons += [f"정보보강대기:{x}" for x in info_bad[:3]] + [f"S2재확인:{STRATEGIES.get(k,k)}" for k,_ in core_hits[:2]]
            ev=_v370_build_stage_event(row,of,core_hits[0][0],core_hits[0][1],'S2',reasons)
            events.append(ev); made=True; stage_source_counts['S2']+=1; stage_source_counts['core_info_wait']+=1
            priority_requests.append(_make_priority_request(t,row,"s2_recheck_info_wait",115+pscore,need or ["quote","micro"],core_hits,reasons))
            priority_buckets["s2_recheck_info_wait"]=priority_buckets.get("s2_recheck_info_wait",0)+1
        elif core_hits and hard_bad:
            hard_blocked += 1
            reasons += hard_bad[:4] + [f"S3관찰:{STRATEGIES.get(k,k)}" for k,_ in core_hits[:2]]
            ev=_v370_build_stage_event(row,of,core_hits[0][0],core_hits[0][1],'S3',reasons)
            events.append(ev); made=True; stage_source_counts['S3']+=1; stage_source_counts['core_hard_block']+=1
        else:
            stage, skey, soft_reasons, bonus = _v368_soft_signal(row, of)
            if stage:
                ev=_v370_build_stage_event(row,of,skey,soft_reasons,stage,soft_reasons)
                events.append(ev); made=True; stage_source_counts[stage]+=1; stage_source_counts['soft_observe']+=1
                priority = bonus + (15 if stage=='S2' else 0)
                if stage=='S2': near_s_info_pending += 1
                bucket='s2_recheck_soft' if stage=='S2' else 's3_observe_soft'
                priority_requests.append(_make_priority_request(t,row,bucket,priority,need or ["quote","micro"],[(skey,soft_reasons)],soft_reasons))
                priority_buckets[bucket]=priority_buckets.get(bucket,0)+1
        if not made:
            if info_bad:
                reasons += [f"정보보강대기:{x}" for x in info_bad[:2]]
            reasons += hard_bad[:2] + core_fail[:4]
            if info_bad:
                bucket="info_wait_high"; priority_requests.append(_make_priority_request(t,row,bucket,70+pscore,need,core_hits,reasons)); priority_buckets[bucket]=priority_buckets.get(bucket,0)+1
            else:
                if cheap_bucket == "cheap_drop": cheap_drop_count += 1
                elif not need_info: info_not_requested += 1
            rejects.append({"ticker":t,"score":fnum(row.get("scanner_priority_score")),"priority":pscore,"reasons":reasons[:8] if reasons else core_fail[:8],"price":row.get("current_price"),"updated_ts":ts,"info_pending":bool(info_bad),"info_needed":bool(need_info),"near_s_info_pending":False,"cheap_bucket":cheap_bucket})
    events.sort(key=lambda e:(0 if str(e.get('s_stage') or e.get('candidate_grade')).upper()=='S1' else (-1 if str(e.get('s_stage') or e.get('candidate_grade')).upper()=='S2' else -2), fnum(e.get("score")), _event_created_ts(e)), reverse=True)
    latest, appended = persist_paper_handoff(events, evaluated=len(rows))
    ctr={}
    for r in rejects:
        for reason in r.get("reasons",[])[:5]: ctr[reason]=ctr.get(reason,0)+1
    top=sorted(ctr.items(), key=lambda x:x[1], reverse=True)[:20]
    priority_requests=sorted(priority_requests, key=lambda x:fnum(x.get("priority"), default=0), reverse=True)
    target=list(dict.fromkeys([r.get("ticker") for r in priority_requests if r.get("ticker")]))
    save_json(PRIORITY_REQ,{"version":VERSION,"main_version":MAIN_VERSION,"updated_ts":ts,"updated_text":now_text(ts),"request_count":len(priority_requests),"targets":target,"requests":priority_requests,"buckets":priority_buckets,"cheap_buckets":cheap_buckets,"stage_source_counts":stage_source_counts,"note":"v0.24/v378: S3→S2→S1 재평가 흐름. feature/orderflow canonical 판단값을 사용하고, 정보미생성은 진짜 정보부족으로만 남긴다."})
    tq=load_json(TARGET_ROUTER_QUEUE,{}) or {}
    active_set=set(tq.get("active_targets",[]) if isinstance(tq,dict) and isinstance(tq.get("active_targets"),list) else [])
    priority_wait_sample=[]
    for pr in priority_requests[:12]:
        tt=ticker_norm(pr.get("ticker")); of=ofmap.get(tt,{}) or {}
        priority_wait_sample.append({"ticker":tt,"bucket":pr.get("bucket"),"need":pr.get("need"),"priority":pr.get("priority"),"quote_ready":bool(of.get("quote_fresh") or of.get("ws_fresh")),"micro_ready":bool(of.get("micro_fresh")),"info_ready":bool((of.get("quote_fresh") or of.get("ws_fresh")) and of.get("micro_fresh")),"router_active":tt in active_set or bool(of.get("router_active")),"micro_age_sec":of.get("micro_age_sec"),"quote_age_sec":of.get("quote_age_sec"),"reasons":pr.get("reasons",[])[:4]})
    stage_counts={"S1":0,"S2":0,"S3":0}
    for ev in latest:
        g=str(ev.get('s_stage') or ev.get('candidate_grade') or ev.get('grade') or 'S3').upper()
        if g == 'S': g='S1'
        if g in stage_counts: stage_counts[g]+=1
    common_summary={"version":VERSION,"main_version":MAIN_VERSION,"updated_ts":ts,"updated_text":now_text(ts),"s_count":len(events),"paper_latest_count":len(latest),"archive_appended":appended,"strategies":strat_counts,"events":latest[:12],"evaluated":len(rows),"s_stage_counts":stage_counts,"stage_source_counts":stage_source_counts,"info_needed_count":info_needed_count,"info_pending_count":info_pending,"near_s_info_pending":near_s_info_pending,"fresh_ready_count":fresh_ready_count,"cheap_reject_count":cheap_drop_count,"hard_blocked_near_s":hard_blocked,"priority_request_count":len(priority_requests),"priority_buckets":priority_buckets,"cheap_buckets":cheap_buckets,"target_count":len(target),"info_not_requested":info_not_requested,"orderflow_attached_count":orderflow_attached_count,"quote_ready_count":quote_ready_count,"micro_ready_count":micro_ready_count,"full_info_ready_count":full_info_ready_count,"router_target_count":tq.get("active_target_count",tq.get("target_count","-")),"router_queue_count":tq.get("queue_count","-"),"router_backlog_count":tq.get("backlog_count","-"),"priority_wait_sample":priority_wait_sample,"note":"v0.24/v378: S3 관찰→S2 재확인→S1 즉시진입 흐름. micro/WS fresh에서 판단값 누락이 생기지 않도록 canonical schema 기준으로 재평가."}
    save_json(SUMMARY,common_summary)
    save_json(REJECT,{**common_summary,"reject_count":len(rejects),"reason_top":[{"reason":k,"count":v} for k,v in top],"sample":rejects[:30],"note":"v0.23/v374: 실제 쓰레기 후보만 탈락. 정보부족 근접 후보는 S2 정보보강/긴급재확인으로 저장."})
    sec=now_ts()-st
    write_status("running", evaluated=len(rows), s_count=len(events), paper_latest_count=len(latest), s1_count=stage_counts.get('S1',0), s2_count=stage_counts.get('S2',0), s3_count=stage_counts.get('S3',0), info_needed_count=info_needed_count, info_pending_count=info_pending, near_s_info_pending=near_s_info_pending, cheap_reject_count=cheap_drop_count, fresh_ready_count=fresh_ready_count, info_not_requested=info_not_requested, orderflow_attached_count=orderflow_attached_count, quote_ready_count=quote_ready_count, micro_ready_count=micro_ready_count, full_info_ready_count=full_info_ready_count, priority_request_count=len(priority_requests), target_count=len(target), router_target_count=tq.get("active_target_count",tq.get("target_count","-")), router_queue_count=tq.get("queue_count","-"), router_backlog_count=tq.get("backlog_count","-"), last_sec=round(sec,3))
    return {"eval":len(rows),"s":len(events),"paper_latest":len(latest),"s_stage_counts":stage_counts,"priority_requests":len(priority_requests),"info_needed":info_needed_count,"info_pending":info_pending,"cheap_drop":cheap_drop_count}


# =============================================================================
# strategy_worker v0.23: S1 근접 정보부족 긴급보강
# - core_ready라고 무조건 S1로 강제하지 않는다.
# - 가격반응/체결지속/슬리피지/호가 세부값이 미확인인 S1 근접 후보는
#   S2 정보보강대기로 남기고 target_router 우선요청에 태운다.
# - 정보부족 문구를 s_stage_reasons/entry_context에 명확히 남긴다.
# =============================================================================

def _v374_is_info_shortage_reason(x: Any) -> bool:
    t = str(x or '')
    return any(k in t for k in ('미확인', '정보보강', '재확인필요', '슬리피지미확인', 'micro재확인', 'WS재확인'))

def _v374_s1_info_need(row: Dict[str, Any], of: Dict[str, Any], stage_reasons: List[str]) -> Tuple[bool, List[str], List[str]]:
    reasons = [str(x) for x in (stage_reasons or []) if str(x or '').strip()]
    info_tags = [x for x in reasons if _v374_is_info_shortage_reason(x)]
    need: List[str] = []
    txt = ','.join(info_tags)
    if 'micro' in txt or '매수체결' in txt or '스프레드' in txt or '슬리피지' in txt or '매도벽' in txt:
        need.append('micro')
    if 'WS' in txt or '가격반응' in txt or '시세' in txt:
        need.append('quote'); need.append('ws')
    # orderflow_info_bad는 quote/micro fresh만 보므로, 세부 미확인값도 여기서 보강 대상으로 승격한다.
    if not need and info_tags:
        need = ['quote', 'micro']
    return (bool(info_tags), list(dict.fromkeys(need)), info_tags[:8])

_v374_prev_build_stage_event = _v370_build_stage_event

def _v370_build_stage_event(row: Dict[str, Any], of: Dict[str, Any], skey: str, why: List[str], stage: str, reasons: List[str]) -> Dict[str, Any]:  # type: ignore[override]
    ev = build_event(row, of, skey, why or reasons)
    # build_event 안의 S1/S2/S3 실제 안전문 판단을 먼저 존중한다.
    pre_stage = str(ev.get('s_stage') or ev.get('candidate_grade') or '').upper()
    pre_reasons = list(ev.get('s_stage_reasons') if isinstance(ev.get('s_stage_reasons'), list) else [])
    requested_stage = str(stage or 'S3').upper()
    info_wait, need, info_tags = _v374_s1_info_need(row, of, pre_reasons)
    final_stage = requested_stage
    final_reasons = list(reasons or [])
    if requested_stage == 'S1' and (pre_stage != 'S1' or info_wait):
        # 전략 core는 맞지만 S1 직전 정보가 비어 있으면 탈락/무시가 아니라 S2 정보보강대기로 둔다.
        final_stage = 'S2'
        final_reasons = ['S1정보부족재확인'] + info_tags + final_reasons
    ev = _v360_force_stage(ev, final_stage, final_reasons[:10])
    if final_stage == 'S2' and (info_wait or any(_v374_is_info_shortage_reason(x) for x in final_reasons)):
        ev['info_shortage_pending'] = True
        ev['urgent_recheck_needed'] = True
        ev['info_shortage_reasons'] = info_tags or [x for x in final_reasons if _v374_is_info_shortage_reason(x)][:8]
        ev['info_shortage_need'] = need or ['quote', 'micro']
        ev['recheck_required'] = True
        ev['recheck_reason'] = 'S1정보부족재확인'
        ev['summary_reason'] = ','.join((['S1정보부족재확인'] + (info_tags or []))[:5])
        ctx = ev.get('entry_context') if isinstance(ev.get('entry_context'), dict) else {}
        ctx.update({
            'info_shortage_pending': True,
            'urgent_recheck_needed': True,
            'info_shortage_reasons': ev.get('info_shortage_reasons'),
            'info_shortage_need': ev.get('info_shortage_need'),
            'recheck_reason': 'S1정보부족재확인',
        })
        ev['entry_context'] = ctx
    ev = _v370_apply_main_version(ev)
    ev['worker_patch'] = 'v378_canonical_s123_promotion'
    return ev



# =============================================================================
# strategy_worker v0.25 / v379: S1/S2/S3 생애주기 상태머신 본선
# - S1/S2/S3는 점수 등급이 아니라 후보 흐름이다.
# - S3 관찰포착 -> S2 재확인 -> S1 최종진입 순서로만 승격한다.
# - S2/S3는 승패 대상이 아니며 승격률/놓친상승률/정보보강 상태만 추적한다.
# - 기존 전략 조건/청산/자동매수는 변경하지 않는다.
# =============================================================================
VERSION = "strategy_worker_v0.26"
LIFECYCLE = BASE_DIR / "clean_strategy_s123_lifecycle.json"
_v379_base_run_once = run_once

_STAGE_RANK = {"S3": 1, "S2": 2, "S1": 3}
_STAGE_LABEL = {"S1": "✅ S1 최종진입", "S2": "⚠️ S2 재확인", "S3": "❔ S3 관찰포착"}

def _v379_stage_norm(v: Any) -> str:
    g = str(v or "").upper().strip()
    if g == "S":
        return "S1"
    if g in {"S1", "S2", "S3"}:
        return g
    return "S3"

def _v379_life_key(ev: Dict[str, Any]) -> str:
    t = ticker_norm(ev.get("ticker") or ev.get("market") or ev.get("symbol")) or "UNKNOWN"
    # S3/S2/S1은 같은 코인의 생애주기이므로 전략별로 쪼개지 않는다.
    # 대표 전략은 별도 필드로만 보존한다.
    return t

def _v379_price(ev: Dict[str, Any]) -> float:
    ctx = ev.get("entry_context") if isinstance(ev.get("entry_context"), dict) else {}
    snap = ev.get("entry_snapshot") if isinstance(ev.get("entry_snapshot"), dict) else {}
    flat = snap.get("flat") if isinstance(snap.get("flat"), dict) else {}
    return fnum(ev.get("current_price"), ev.get("entry_price"), ev.get("price"), ev.get("detected_price"), ctx.get("current_price"), ctx.get("entry_price"), flat.get("current_price"), flat.get("entry_price"), default=0.0)

def _v379_load_lifecycle() -> Dict[str, Any]:
    obj = load_json(LIFECYCLE, {}) or {}
    if not isinstance(obj, dict):
        obj = {}
    items = obj.get("items") if isinstance(obj.get("items"), dict) else {}
    return {"version": VERSION, "updated_ts": now_ts(), "items": dict(items)}

def _v379_save_lifecycle(life: Dict[str, Any], stats: Dict[str, Any]) -> None:
    nowv = now_ts()
    items = life.get("items") if isinstance(life.get("items"), dict) else {}
    # 2시간 이상 안 보인 후보는 순환 제거. 장부/체결 기록은 건드리지 않는다.
    keep = {}
    for k, v in items.items():
        if not isinstance(v, dict):
            continue
        last = fnum(v.get("last_seen_ts"), default=0.0)
        if last and nowv - last <= 7200:
            keep[k] = v
    out = {
        "version": VERSION,
        "schema": "s123_lifecycle_v379",
        "updated_ts": nowv,
        "updated_text": now_text(nowv),
        "items": keep,
        "stats": stats,
        "note": "S3/S2/S1은 점수 등급이 아니라 생애주기다. S2/S3 승패 대신 승격/정보보강/놓친상승을 본다.",
    }
    save_json(LIFECYCLE, out)

def _v379_signal_ready(ev: Dict[str, Any]) -> Tuple[bool, List[str]]:
    """S2 -> S1 승격 전에 필요한 판단값이 실제로 채워졌는지 본다.
    조건을 새로 풀지 않고, v378 canonical 값 존재 여부와 S1 판단 결과를 함께 확인한다.
    """
    ctx = ev.get("entry_context") if isinstance(ev.get("entry_context"), dict) else {}
    snap = ev.get("entry_snapshot") if isinstance(ev.get("entry_snapshot"), dict) else {}
    flat = snap.get("flat") if isinstance(snap.get("flat"), dict) else {}
    def val(*keys: str, default: float = -999.0) -> float:
        vals = []
        for src in (ev, ctx, flat):
            if isinstance(src, dict):
                vals += [src.get(k) for k in keys]
        return fnum(*vals, default=default)
    def known(*keys: str) -> bool:
        for src in (ev, ctx, flat):
            if not isinstance(src, dict):
                continue
            for k in keys:
                v = src.get(k)
                if v is not None and str(v).strip() not in {"", "-", "None", "nan"}:
                    return True
        return False
    miss: List[str] = []
    pr_known = known("price_reaction_score", "price_reaction_pct", "price_recheck_pct", "change_1m", "change_3m")
    br_known = known("buy_ratio_1m", "micro_buy_ratio_sustain_1m", "buy_ratio", "buy_ratio_30s")
    sl_known = known("slippage_est_pct", "tick_pct_est", "spread_pct")
    if not pr_known: miss.append("가격반응판단값없음")
    if not br_known: miss.append("체결지속판단값없음")
    if not sl_known: miss.append("슬리피지판단값없음")
    spread = val("spread_pct", "micro_spread_pct", default=99.0)
    buy = val("buy_ratio_1m", "micro_buy_ratio_sustain_1m", "buy_ratio", "buy_ratio_30s", default=0.0)
    ch1 = val("price_reaction_pct", "price_recheck_pct", "change_1m", "price_change_1m", default=0.0)
    ch3 = val("money_flow_3m_pct", "three_min_flow_pct", "change_3m", "price_change_3m", default=0.0)
    # 이 기준은 신규 전략 조건이 아니라 S1 진입 가능 신호가 계산됐는지/무너졌는지 보는 최소 검문소다.
    if spread > 0.28: miss.append("스프레드과다")
    if buy and buy < 0.58: miss.append("매수체결약함")
    if ch1 < -0.40 and ch3 < -0.40: miss.append("가격반응역행")
    return (not miss), miss[:8]

def _v379_apply_lifecycle_to_event(ev: Dict[str, Any], rec: Dict[str, Any], new_stage: str, reasons: List[str], nowv: float) -> Dict[str, Any]:
    out = dict(ev or {})
    old = str(rec.get("stage") or "")
    label = _STAGE_LABEL.get(new_stage, new_stage)
    life_age = max(0.0, nowv - fnum(rec.get("first_seen_ts"), default=nowv))
    recheck_count = int(fnum(rec.get("recheck_count"), default=0))
    out.update({
        "s_stage": new_stage,
        "candidate_grade": new_stage,
        "grade": new_stage,
        "entry_grade": new_stage,
        "signal_grade": new_stage,
        "candidate_grade_label": label,
        "paper_bot_open": new_stage == "S1",
        "open_eligible": new_stage == "S1",
        "trade_ready": new_stage == "S1",
        "observe_only": new_stage == "S3",
        "recheck_required": new_stage == "S2",
        "lifecycle_schema": "s123_lifecycle_v379",
        "lifecycle_stage": new_stage,
        "previous_lifecycle_stage": old or None,
        "lifecycle_age_sec": round(life_age, 2),
        "recheck_count": recheck_count,
        "first_seen_price": rec.get("first_seen_price"),
        "highest_after_seen": rec.get("highest_price"),
        "highest_after_seen_pct": rec.get("highest_pct"),
        "stage_transition": f"{old or 'NEW'}->{new_stage}",
        "promote_reason": reasons[:8],
        "s_stage_reasons": reasons[:8] or list(out.get("s_stage_reasons") if isinstance(out.get("s_stage_reasons"), list) else [])[:8],
        "final_entry_action": "paper_open" if new_stage == "S1" else ("recheck_wait" if new_stage == "S2" else "observe"),
        "summary_reason": ",".join((reasons or [label])[:5]),
        "worker_patch": "v379_s123_lifecycle_state_machine",
    })
    ctx = out.get("entry_context") if isinstance(out.get("entry_context"), dict) else {}
    ctx.update({k: out.get(k) for k in ("lifecycle_schema", "lifecycle_stage", "previous_lifecycle_stage", "lifecycle_age_sec", "recheck_count", "first_seen_price", "highest_after_seen", "highest_after_seen_pct", "stage_transition", "promote_reason", "s_stage", "candidate_grade", "paper_bot_open", "open_eligible", "trade_ready")})
    out["entry_context"] = ctx
    snap = out.get("entry_snapshot") if isinstance(out.get("entry_snapshot"), dict) else None
    if snap is not None:
        strat = snap.get("strategy") if isinstance(snap.get("strategy"), dict) else {}
        strat.update({"decision_stage": new_stage, "decision_note": label, "lifecycle_stage": new_stage, "stage_transition": out.get("stage_transition"), "promote_reason": reasons[:8]})
        snap["strategy"] = strat
        flat = snap.get("flat") if isinstance(snap.get("flat"), dict) else {}
        flat.update({"s_stage": new_stage, "candidate_grade": new_stage, "lifecycle_stage": new_stage, "stage_transition": out.get("stage_transition")})
        snap["flat"] = flat
        out["entry_snapshot"] = snap
    return out

def _v379_finalize_lifecycle(base_result: Dict[str, Any]) -> Dict[str, Any]:
    nowv = now_ts()
    rows = [r for r in read_jsonl(PAPER_LATEST, max_lines=160) if isinstance(r, dict)]
    life = _v379_load_lifecycle()
    items = life.get("items") if isinstance(life.get("items"), dict) else {}
    revised: List[Dict[str, Any]] = []
    transitions = {"new_s3": 0, "s3_to_s2": 0, "s2_to_s1": 0, "s2_hold": 0, "s3_hold": 0, "demoted_or_reset": 0, "blocked_s1_signal": 0}
    stage_counts = {"S1": 0, "S2": 0, "S3": 0}
    for ev in rows:
        key = _v379_life_key(ev)
        obs = _v379_stage_norm(ev.get("s_stage") or ev.get("candidate_grade") or ev.get("grade"))
        price = _v379_price(ev)
        rec = items.get(key) if isinstance(items.get(key), dict) else {}
        if not rec:
            rec = {"ticker": key, "first_seen_ts": nowv, "first_seen_text": now_text(nowv), "first_seen_price": price, "stage": "S3", "recheck_count": 0, "highest_price": price, "highest_pct": 0.0, "strategy_keys": []}
            new_stage = "S3"
            reasons = ["S3관찰포착", f"관측단계:{obs}"]
            transitions["new_s3"] += 1
        else:
            old_stage = _v379_stage_norm(rec.get("stage"))
            first_price = fnum(rec.get("first_seen_price"), default=price)
            high = max(fnum(rec.get("highest_price"), default=0.0), price)
            rec["highest_price"] = high
            rec["highest_pct"] = round(((high - first_price) / first_price * 100.0), 3) if first_price else 0.0
            # 새 관측값이 S1이라도 생애주기는 S3->S2->S1 순서로만 올린다.
            if old_stage == "S3":
                if _STAGE_RANK.get(obs, 1) >= 2:
                    new_stage = "S2"; transitions["s3_to_s2"] += 1
                    reasons = ["S3→S2승격", f"관측단계:{obs}"]
                else:
                    new_stage = "S3"; transitions["s3_hold"] += 1
                    reasons = ["S3관찰유지", f"관측단계:{obs}"]
            elif old_stage == "S2":
                signal_ok, signal_miss = _v379_signal_ready(ev)
                if obs == "S1" and signal_ok:
                    new_stage = "S1"; transitions["s2_to_s1"] += 1
                    reasons = ["S2→S1승격", "최종진입판단값확인"]
                elif obs == "S1" and not signal_ok:
                    new_stage = "S2"; transitions["blocked_s1_signal"] += 1
                    reasons = ["S1승격보류"] + signal_miss
                elif obs == "S2":
                    new_stage = "S2"; transitions["s2_hold"] += 1
                    reasons = ["S2재확인유지"]
                else:
                    new_stage = "S3"; transitions["demoted_or_reset"] += 1
                    reasons = ["S2→S3강등", f"관측단계:{obs}"]
            else:  # old S1은 paper가 읽을 수 있게 한 사이클 유지하되, 다음 관측이 내려가면 강등
                if obs == "S1":
                    new_stage = "S1"; reasons = ["S1진입유지"]
                elif obs == "S2":
                    new_stage = "S2"; transitions["demoted_or_reset"] += 1; reasons = ["S1→S2강등"]
                else:
                    new_stage = "S3"; transitions["demoted_or_reset"] += 1; reasons = ["S1→S3강등"]
        rec["stage"] = new_stage
        rec["last_observed_stage"] = obs
        rec["last_seen_ts"] = nowv
        rec["last_seen_text"] = now_text(nowv)
        rec["last_price"] = price
        if not fnum(rec.get("first_seen_price"), default=0.0) and price:
            rec["first_seen_price"] = price
        first_price = fnum(rec.get("first_seen_price"), default=price)
        rec["highest_price"] = max(fnum(rec.get("highest_price"), default=0.0), price)
        rec["highest_pct"] = round(((fnum(rec.get("highest_price"), default=0.0) - first_price) / first_price * 100.0), 3) if first_price else 0.0
        rec["recheck_count"] = int(fnum(rec.get("recheck_count"), default=0)) + (1 if new_stage == "S2" else 0)
        sk = str(ev.get("strategy_key") or ev.get("strategy_bucket_primary") or "")
        if sk:
            keys = list(rec.get("strategy_keys") if isinstance(rec.get("strategy_keys"), list) else [])
            if sk not in keys:
                keys.append(sk)
            rec["strategy_keys"] = keys[:8]
        items[key] = rec
        stage_counts[new_stage] += 1
        revised.append(_v379_apply_lifecycle_to_event(ev, rec, new_stage, reasons, nowv))
    # 생애주기에서 S1/S2/S3 순서가 반영된 latest를 다시 쓴다.
    latest, appended = persist_paper_handoff(revised, evaluated=int((load_json(SUMMARY, {}) or {}).get("evaluated") or 0))
    stats = {"stage_counts": stage_counts, "transitions": transitions, "active_count": len(items), "latest_count": len(latest), "archive_appended": appended}
    _v379_save_lifecycle({"items": items}, stats)
    # strategy summary에도 생애주기 통계를 실어 main /score, /quality에서 볼 수 있게 한다.
    try:
        sm = load_json(SUMMARY, {}) or {}
        sm.update({
            "version": VERSION,
            "lifecycle_schema": "s123_lifecycle_v379",
            "lifecycle_stats": stats,
            "s_stage_counts": stage_counts,
            "paper_latest_count": len(latest),
            "s_count": len(latest),
            "note": "v0.25/v379: S1/S2/S3는 등급이 아니라 S3→S2→S1 생애주기. S2/S3는 승패가 아니라 승격/복기 지표다.",
        })
        save_json(SUMMARY, sm)
    except Exception as exc:
        append_error(ERROR, "v379_summary_update", exc)
    try:
        pr = load_json(PRIORITY_REQ, {}) or {}
        if isinstance(pr, dict):
            pr["version"] = VERSION
            pr["lifecycle_schema"] = "s123_lifecycle_v379"
            pr["lifecycle_stats"] = stats
            pr["note"] = "v379: target_router 요청은 생애주기 S2/S3 정보보강을 우선한다. S2/S3는 OPEN 승패 대상이 아니다."
            save_json(PRIORITY_REQ, pr)
    except Exception as exc:
        append_error(ERROR, "v379_priority_update", exc)
    try:
        write_status("running", evaluated=int((load_json(SUMMARY, {}) or {}).get("evaluated") or 0), s_count=len(latest), paper_latest_count=len(latest), s1_count=stage_counts.get("S1", 0), s2_count=stage_counts.get("S2", 0), s3_count=stage_counts.get("S3", 0), lifecycle_schema="s123_lifecycle_v379", lifecycle_active=len(items), lifecycle_transitions=transitions, last_sec=fnum((base_result or {}).get("last_sec"), default=0.0))
    except Exception:
        pass
    out = dict(base_result or {})
    out.update({"s_stage_counts": stage_counts, "lifecycle_stats": stats, "paper_latest": len(latest), "s": len(latest)})
    return out

def run_once() -> Dict[str, Any]:  # type: ignore[override]
    base = _v379_base_run_once()
    return _v379_finalize_lifecycle(base)


# =============================================================================
# strategy_worker v0.26 / v383: 생애주기 승격 로직 수술
# - S3에서 실제로 오른 후보(+0.7% 이상)는 단순 관찰에 묶지 않고 S2 재확인으로 올린다.
# - S2는 관측값이 S1로 직접 올라오지 않아도, 가격추적 상승 + canonical 판단값 통과 시 S1로 올린다.
# - S2/S3는 여전히 OPEN하지 않는다. S1만 paper OPEN 대상이다.
# - 조건을 풀어 무조건 매수하는 수정이 아니라, 추적값/판단값을 승격에 실제 반영하는 배관 수술이다.
# =============================================================================
VERSION = "strategy_worker_v0.26"
_v383_base_run_once = run_once


def _v383_ev_val(ev: Dict[str, Any], *keys: str, default: float = 0.0) -> float:
    ctx = ev.get("entry_context") if isinstance(ev.get("entry_context"), dict) else {}
    snap = ev.get("entry_snapshot") if isinstance(ev.get("entry_snapshot"), dict) else {}
    flat = snap.get("flat") if isinstance(snap.get("flat"), dict) else {}
    strat = snap.get("strategy") if isinstance(snap.get("strategy"), dict) else {}
    for src in (ev, ctx, flat, strat):
        if not isinstance(src, dict):
            continue
        for k in keys:
            v = src.get(k)
            if v is not None and str(v).strip() not in {"", "-", "None", "nan"}:
                return fnum(v, default=default)
    return default


def _v383_gain_now(ev: Dict[str, Any], rec: Dict[str, Any]) -> float:
    price = _v379_price(ev)
    first = fnum(rec.get("first_seen_price"), default=0.0) or price
    if not first or not price:
        return 0.0
    return round((price - first) / first * 100.0, 3)


def _v383_promote_s3_to_s2(ev: Dict[str, Any], rec: Dict[str, Any], obs: str) -> Tuple[bool, List[str]]:
    """관찰 후보가 실제로 움직였으면 재확인 단계로 올린다.
    S2는 매수 단계가 아니라 재확인/정보보강 단계라서, +0.7% 이상 놓친 상승 후보는 S2로 올리는 게 맞다.
    """
    if _STAGE_RANK.get(obs, 1) >= 2:
        return True, ["S3→S2승격", f"관측단계:{obs}"]
    hp = fnum(rec.get("highest_pct"), default=0.0)
    gn = _v383_gain_now(ev, rec)
    flow5 = _v383_ev_val(ev, "change_5m", "five_min_flow_pct", "price_change_5m", default=0.0)
    flow3 = _v383_ev_val(ev, "money_flow_3m_pct", "three_min_flow_pct", "change_3m", "price_change_3m", default=0.0)
    spread = _v383_ev_val(ev, "spread_pct", "micro_spread_pct", default=0.0)
    # 관찰 후 이미 오른 후보는 S2에서 재확인해야 한다. 스프레드가 매우 넓으면 관찰 유지.
    if hp >= 0.70 and (spread <= 0 or spread <= 0.45):
        return True, ["S3→S2승격:관찰후상승", f"최고+{hp:.2f}%", f"현재+{gn:.2f}%"]
    # 아직 +0.7% 전이라도 5분 흐름이 강하면 S2로 올려 재확인한다.
    if gn >= 0.35 and (flow5 >= 0.50 or flow3 >= 0.25) and (spread <= 0 or spread <= 0.35):
        return True, ["S3→S2승격:흐름재확인", f"현재+{gn:.2f}%", f"5m{flow5:+.2f}", f"3m{flow3:+.2f}"]
    return False, []


def _v383_promote_s2_to_s1(ev: Dict[str, Any], rec: Dict[str, Any], obs: str) -> Tuple[bool, List[str], List[str]]:
    signal_ok, miss = _v379_signal_ready(ev)
    hp = fnum(rec.get("highest_pct"), default=0.0)
    gn = _v383_gain_now(ev, rec)
    pr = _v383_ev_val(ev, "price_reaction_pct", "price_recheck_pct", "change_1m", "price_change_1m", default=0.0)
    buy = _v383_ev_val(ev, "buy_ratio_1m", "micro_buy_ratio_sustain_1m", "buy_ratio", "buy_ratio_30s", default=0.0)
    spread = _v383_ev_val(ev, "spread_pct", "micro_spread_pct", default=0.0)
    # 기존 obs S1은 그대로 존중하되 canonical 안전값이 있어야 실제 S1로 올린다.
    if obs == "S1" and signal_ok:
        return True, ["S2→S1승격", "관측S1+최종판단값확인"], []
    # S2가 이미 관찰 후 충분히 움직이고, 가격반응/체결/스프레드가 통과하면 S1로 올린다.
    strong_follow = (hp >= 0.70 and gn >= 0.10 and pr >= -0.10 and (not buy or buy >= 0.58) and (not spread or spread <= 0.28))
    if signal_ok and strong_follow:
        return True, ["S2→S1승격:재확인통과", f"최고+{hp:.2f}%", f"현재+{gn:.2f}%", f"가격반응{pr:+.2f}", f"매수비율{buy:.2f}"], []
    fail = list(miss or [])
    if not signal_ok:
        return False, [], fail[:8]
    if not strong_follow:
        if hp < 0.70: fail.append("관찰상승부족")
        if gn < 0.10: fail.append("현재반응부족")
        if pr < -0.10: fail.append("가격반응약함")
        if buy and buy < 0.58: fail.append("매수체결약함")
        if spread and spread > 0.28: fail.append("스프레드과다")
    return False, [], fail[:8]


def _v383_finalize_lifecycle(base_result: Dict[str, Any]) -> Dict[str, Any]:
    nowv = now_ts()
    rows = [r for r in read_jsonl(PAPER_LATEST, max_lines=160) if isinstance(r, dict)]
    life = _v379_load_lifecycle()
    items = life.get("items") if isinstance(life.get("items"), dict) else {}
    revised: List[Dict[str, Any]] = []
    transitions = {"new_s3": 0, "s3_to_s2": 0, "s3_to_s2_by_rise": 0, "s2_to_s1": 0, "s2_hold": 0, "s3_hold": 0, "demoted_or_reset": 0, "blocked_s1_signal": 0}
    fail_reasons: Dict[str, int] = {}
    stage_counts = {"S1": 0, "S2": 0, "S3": 0}
    for ev in rows:
        key = _v379_life_key(ev)
        obs = _v379_stage_norm(ev.get("s_stage") or ev.get("candidate_grade") or ev.get("grade"))
        price = _v379_price(ev)
        rec = items.get(key) if isinstance(items.get(key), dict) else {}
        if not rec:
            rec = {"ticker": key, "first_seen_ts": nowv, "first_seen_text": now_text(nowv), "first_seen_price": price, "stage": "S3", "recheck_count": 0, "highest_price": price, "highest_pct": 0.0, "strategy_keys": []}
            new_stage = "S3"
            reasons = ["S3관찰포착", f"관측단계:{obs}"]
            transitions["new_s3"] += 1
        else:
            old_stage = _v379_stage_norm(rec.get("stage"))
            first_price = fnum(rec.get("first_seen_price"), default=price)
            high = max(fnum(rec.get("highest_price"), default=0.0), price)
            rec["highest_price"] = high
            rec["highest_pct"] = round(((high - first_price) / first_price * 100.0), 3) if first_price else 0.0
            if old_stage == "S3":
                promote, preasons = _v383_promote_s3_to_s2(ev, rec, obs)
                if promote:
                    new_stage = "S2"
                    transitions["s3_to_s2"] += 1
                    if any("관찰후상승" in str(x) for x in preasons):
                        transitions["s3_to_s2_by_rise"] += 1
                    reasons = preasons
                else:
                    new_stage = "S3"
                    transitions["s3_hold"] += 1
                    reasons = ["S3관찰유지", f"관측단계:{obs}"]
            elif old_stage == "S2":
                ok, preasons, fail = _v383_promote_s2_to_s1(ev, rec, obs)
                if ok:
                    new_stage = "S1"
                    transitions["s2_to_s1"] += 1
                    reasons = preasons
                else:
                    new_stage = "S2"
                    transitions["s2_hold"] += 1
                    transitions["blocked_s1_signal"] += 1
                    reasons = ["S2→S1보류"] + (fail or [f"관측단계:{obs}"])
                    for r in (fail or ["미상"]):
                        fail_reasons[str(r)] = fail_reasons.get(str(r), 0) + 1
            else:
                if obs == "S1":
                    new_stage = "S1"; reasons = ["S1진입유지"]
                elif obs == "S2":
                    new_stage = "S2"; transitions["demoted_or_reset"] += 1; reasons = ["S1→S2강등"]
                else:
                    new_stage = "S3"; transitions["demoted_or_reset"] += 1; reasons = ["S1→S3강등"]
        rec["stage"] = new_stage
        rec["last_observed_stage"] = obs
        rec["last_seen_ts"] = nowv
        rec["last_seen_text"] = now_text(nowv)
        rec["last_price"] = price
        if not fnum(rec.get("first_seen_price"), default=0.0) and price:
            rec["first_seen_price"] = price
        first_price = fnum(rec.get("first_seen_price"), default=price)
        rec["highest_price"] = max(fnum(rec.get("highest_price"), default=0.0), price)
        rec["highest_pct"] = round(((fnum(rec.get("highest_price"), default=0.0) - first_price) / first_price * 100.0), 3) if first_price else 0.0
        rec["last_gain_pct"] = _v383_gain_now(ev, rec)
        rec["last_promote_reasons"] = reasons[:8]
        rec["s2_to_s1_fail_reasons"] = reasons[1:8] if new_stage == "S2" and reasons and str(reasons[0]).startswith("S2") else []
        rec["recheck_count"] = int(fnum(rec.get("recheck_count"), default=0)) + (1 if new_stage == "S2" else 0)
        sk = str(ev.get("strategy_key") or ev.get("strategy_bucket_primary") or "")
        if sk:
            keys = list(rec.get("strategy_keys") if isinstance(rec.get("strategy_keys"), list) else [])
            if sk not in keys:
                keys.append(sk)
            rec["strategy_keys"] = keys[:8]
        items[key] = rec
        stage_counts[new_stage] += 1
        revised.append(_v379_apply_lifecycle_to_event(ev, rec, new_stage, reasons, nowv))
    latest, appended = persist_paper_handoff(revised, evaluated=int((load_json(SUMMARY, {}) or {}).get("evaluated") or 0))
    stats = {"schema": "s123_lifecycle_v383", "stage_counts": stage_counts, "transitions": transitions, "s2_to_s1_fail_reasons": fail_reasons, "active_count": len(items), "latest_count": len(latest), "archive_appended": appended}
    _v379_save_lifecycle({"items": items}, stats)
    try:
        sm = load_json(SUMMARY, {}) or {}
        sm.update({"version": VERSION, "lifecycle_schema": "s123_lifecycle_v383", "lifecycle_stats": stats, "s_stage_counts": stage_counts, "paper_latest_count": len(latest), "s_count": len(latest), "note": "v0.26/v383: S3 상승후보를 S2 재확인으로 올리고, S2 최종판단값 통과 시 S1로 승격한다."})
        save_json(SUMMARY, sm)
    except Exception as exc:
        append_error(ERROR, "v383_summary_update", exc)
    try:
        pr = load_json(PRIORITY_REQ, {}) or {}
        if isinstance(pr, dict):
            pr["version"] = VERSION
            pr["lifecycle_schema"] = "s123_lifecycle_v383"
            pr["lifecycle_stats"] = stats
            pr["note"] = "v383: S3/S2 승격 실패 원인을 target_router·상태판에 전달한다."
            save_json(PRIORITY_REQ, pr)
    except Exception as exc:
        append_error(ERROR, "v383_priority_update", exc)
    try:
        write_status("running", evaluated=int((load_json(SUMMARY, {}) or {}).get("evaluated") or 0), s_count=len(latest), paper_latest_count=len(latest), s1_count=stage_counts.get("S1", 0), s2_count=stage_counts.get("S2", 0), s3_count=stage_counts.get("S3", 0), lifecycle_schema="s123_lifecycle_v383", lifecycle_active=len(items), lifecycle_transitions=transitions, s2_to_s1_fail_reasons=fail_reasons, last_sec=fnum((base_result or {}).get("last_sec"), default=0.0))
    except Exception:
        pass
    out = dict(base_result or {})
    out.update({"s_stage_counts": stage_counts, "lifecycle_stats": stats, "paper_latest": len(latest), "s": len(latest)})
    return out


def run_once() -> Dict[str, Any]:  # type: ignore[override]
    base = _v383_base_run_once()
    return _v383_finalize_lifecycle(base)


# v385: early main disabled. Final __main__ is at file end after all lifecycle tails load.
# if __name__=="__main__": main()


# =============================================================================
# v384 / 2026-05-23
# - S2/S3가 못 올라간 이유를 단계별로 남긴다.
# - 정보부족은 "정보부족"으로만 끝내지 않고, 왜 없는지(root cause)를 나눈다.
# - 전략 조건/청산/자동매수는 변경하지 않고 생애주기 진단과 승격 실패 원인만 정밀화한다.
# =============================================================================
VERSION = "strategy_worker_v0.27"

def _v384_ev_sources(ev: Dict[str, Any]) -> List[Dict[str, Any]]:
    srcs: List[Dict[str, Any]] = []
    for obj in (ev, ev.get("entry_context"), ev.get("entry_snapshot")):
        if isinstance(obj, dict):
            srcs.append(obj)
            for k in ("flat", "strategy", "orderflow", "feature"):
                v = obj.get(k)
                if isinstance(v, dict):
                    srcs.append(v)
    return srcs

def _v384_known(ev: Dict[str, Any], *keys: str) -> bool:
    for src in _v384_ev_sources(ev):
        for k in keys:
            v = src.get(k)
            if v is not None and str(v).strip() not in {"", "-", "None", "nan", "NaN"}:
                return True
    return False

def _v384_bool(ev: Dict[str, Any], *keys: str) -> bool:
    for src in _v384_ev_sources(ev):
        for k in keys:
            v = src.get(k)
            if isinstance(v, bool):
                return v
            if str(v).strip().lower() in {"1", "true", "yes", "ok", "fresh", "신선"}:
                return True
    return False

def _v384_val(ev: Dict[str, Any], *keys: str, default: float = 0.0) -> float:
    vals: List[Any] = []
    for src in _v384_ev_sources(ev):
        vals.extend(src.get(k) for k in keys)
    return fnum(*vals, default=default)

def _v384_info_root_causes(ev: Dict[str, Any]) -> List[str]:
    """S1/S2/S3 판단값이 없을 때 원천 원인을 분리한다.
    - 수집 미신선: WS/micro/candle 자체가 안 들어옴
    - 판단값 미생성: 수집은 신선한데 feature/orderflow canonical key가 안 붙음
    """
    quote_fresh = _v384_bool(ev, "quote_fresh", "ws_fresh", "rest_fresh")
    micro_fresh = _v384_bool(ev, "micro_fresh")
    candle_ready = _v384_bool(ev, "candle_ready", "candle_ok") or _v384_known(ev, "change_3m", "change_5m")
    causes: List[str] = []
    if not _v384_known(ev, "price_reaction_score", "price_reaction_pct", "price_recheck_pct", "change_1m", "price_change_1m"):
        causes.append("가격반응:시세미신선" if not quote_fresh else "가격반응:판단값미생성")
    if not _v384_known(ev, "money_flow_3m_pct", "three_min_flow_pct", "change_3m", "price_change_3m"):
        causes.append("3분흐름:candle미신선" if not candle_ready else "3분흐름:판단값미생성")
    if not _v384_known(ev, "buy_ratio_1m", "micro_buy_ratio_sustain_1m", "buy_ratio", "buy_ratio_30s"):
        causes.append("체결지속:micro미신선" if not micro_fresh else "체결지속:판단값미생성")
    if not _v384_known(ev, "slippage_est_pct", "tick_pct_est", "spread_pct", "micro_spread_pct"):
        causes.append("슬리피지:micro미신선" if not micro_fresh else "슬리피지:판단값미생성")
    if not _v384_known(ev, "ask_wall_ratio", "sell_wall_ratio", "ask_size_ratio"):
        causes.append("매도벽:micro미신선" if not micro_fresh else "매도벽:판단값미생성")
    return list(dict.fromkeys(causes))[:10]

def _v384_s3_fail_reasons(ev: Dict[str, Any], rec: Dict[str, Any], obs: str) -> List[str]:
    hp = fnum(rec.get("highest_pct"), default=0.0)
    gn = _v383_gain_now(ev, rec)
    flow5 = _v384_val(ev, "change_5m", "five_min_flow_pct", "price_change_5m", default=0.0)
    flow3 = _v384_val(ev, "money_flow_3m_pct", "three_min_flow_pct", "change_3m", "price_change_3m", default=0.0)
    spread = _v384_val(ev, "spread_pct", "micro_spread_pct", default=0.0)
    reasons: List[str] = []
    info = _v384_info_root_causes(ev)
    if info:
        reasons += ["정보부족:" + x for x in info[:5]]
    if hp < 0.70 and gn < 0.35:
        reasons.append(f"상승반응부족:최고{hp:+.2f}/현재{gn:+.2f}")
    if flow5 < 0.50 and flow3 < 0.25:
        reasons.append(f"흐름재확인부족:5m{flow5:+.2f}/3m{flow3:+.2f}")
    if spread and spread > 0.45:
        reasons.append(f"스프레드과다:{spread:.2f}%")
    if not reasons:
        reasons.append(f"관측단계유지:{obs or 'S3'}")
    return reasons[:8]

def _v384_promote_s3_to_s2(ev: Dict[str, Any], rec: Dict[str, Any], obs: str) -> Tuple[bool, List[str], List[str]]:
    promote, reasons = _v383_promote_s3_to_s2(ev, rec, obs)
    if promote:
        return True, reasons, []
    return False, [], _v384_s3_fail_reasons(ev, rec, obs)

def _v384_s2_fail_detail(ev: Dict[str, Any], rec: Dict[str, Any], fail: List[str]) -> Dict[str, Any]:
    return {
        "ticker": _v379_life_key(ev),
        "score": _v384_val(ev, "score", "trade_ready", default=0.0),
        "highest_pct": round(fnum(rec.get("highest_pct"), default=0.0), 3),
        "gain_now_pct": _v383_gain_now(ev, rec),
        "price_reaction_pct": _v384_val(ev, "price_reaction_pct", "price_recheck_pct", "change_1m", default=0.0),
        "buy_ratio": _v384_val(ev, "buy_ratio_1m", "micro_buy_ratio_sustain_1m", "buy_ratio", default=0.0),
        "spread_pct": _v384_val(ev, "spread_pct", "micro_spread_pct", default=0.0),
        "fail_reasons": list(fail or [])[:8],
        "info_root_causes": _v384_info_root_causes(ev),
    }

def _v384_finalize_lifecycle(base_result: Dict[str, Any]) -> Dict[str, Any]:
    nowv = now_ts()
    rows = [r for r in read_jsonl(PAPER_LATEST, max_lines=160) if isinstance(r, dict)]
    life = _v379_load_lifecycle()
    items = life.get("items") if isinstance(life.get("items"), dict) else {}
    revised: List[Dict[str, Any]] = []
    transitions = {"new_s3": 0, "s3_to_s2": 0, "s3_to_s2_by_rise": 0, "s2_to_s1": 0, "s2_hold": 0, "s3_hold": 0, "demoted_or_reset": 0, "blocked_s1_signal": 0}
    fail_reasons: Dict[str, int] = {}
    s3_fail_reasons: Dict[str, int] = {}
    info_root_causes: Dict[str, int] = {}
    s2_fail_samples: List[Dict[str, Any]] = []
    s3_fail_samples: List[Dict[str, Any]] = []
    stage_counts = {"S1": 0, "S2": 0, "S3": 0}
    for ev in rows:
        key = _v379_life_key(ev)
        obs = _v379_stage_norm(ev.get("s_stage") or ev.get("candidate_grade") or ev.get("grade"))
        price = _v379_price(ev)
        rec = items.get(key) if isinstance(items.get(key), dict) else {}
        if not rec:
            rec = {"ticker": key, "first_seen_ts": nowv, "first_seen_text": now_text(nowv), "first_seen_price": price, "stage": "S3", "recheck_count": 0, "highest_price": price, "highest_pct": 0.0, "strategy_keys": []}
            new_stage = "S3"
            reasons = ["S3관찰포착", f"관측단계:{obs}"]
            transitions["new_s3"] += 1
        else:
            old_stage = _v379_stage_norm(rec.get("stage"))
            first_price = fnum(rec.get("first_seen_price"), default=price)
            high = max(fnum(rec.get("highest_price"), default=0.0), price)
            rec["highest_price"] = high
            rec["highest_pct"] = round(((high - first_price) / first_price * 100.0), 3) if first_price else 0.0
            if old_stage == "S3":
                promote, preasons, fail = _v384_promote_s3_to_s2(ev, rec, obs)
                if promote:
                    new_stage = "S2"
                    transitions["s3_to_s2"] += 1
                    if any("관찰후상승" in str(x) for x in preasons):
                        transitions["s3_to_s2_by_rise"] += 1
                    reasons = preasons
                else:
                    new_stage = "S3"
                    transitions["s3_hold"] += 1
                    reasons = ["S3관찰유지", f"관측단계:{obs}"] + fail[:6]
                    for r in fail or ["미상"]:
                        s3_fail_reasons[str(r)] = s3_fail_reasons.get(str(r), 0) + 1
                        if str(r).startswith("정보부족:"):
                            k = str(r).replace("정보부족:", "", 1)
                            info_root_causes[k] = info_root_causes.get(k, 0) + 1
                    if len(s3_fail_samples) < 8:
                        s3_fail_samples.append(_v384_s2_fail_detail(ev, rec, fail))
            elif old_stage == "S2":
                ok, preasons, fail = _v383_promote_s2_to_s1(ev, rec, obs)
                if ok:
                    new_stage = "S1"
                    transitions["s2_to_s1"] += 1
                    reasons = preasons
                else:
                    new_stage = "S2"
                    transitions["s2_hold"] += 1
                    transitions["blocked_s1_signal"] += 1
                    root = _v384_info_root_causes(ev)
                    reasons = ["S2→S1보류"] + (fail or [f"관측단계:{obs}"]) + (["정보원인:" + x for x in root[:4]] if root else [])
                    for r in (fail or ["미상"]):
                        fail_reasons[str(r)] = fail_reasons.get(str(r), 0) + 1
                    for r in root:
                        info_root_causes[str(r)] = info_root_causes.get(str(r), 0) + 1
                    if len(s2_fail_samples) < 8:
                        s2_fail_samples.append(_v384_s2_fail_detail(ev, rec, fail))
            else:
                if obs == "S1":
                    new_stage = "S1"; reasons = ["S1진입유지"]
                elif obs == "S2":
                    new_stage = "S2"; transitions["demoted_or_reset"] += 1; reasons = ["S1→S2강등"]
                else:
                    new_stage = "S3"; transitions["demoted_or_reset"] += 1; reasons = ["S1→S3강등"]
        rec["stage"] = new_stage
        rec["last_observed_stage"] = obs
        rec["last_seen_ts"] = nowv
        rec["last_seen_text"] = now_text(nowv)
        rec["last_price"] = price
        if not fnum(rec.get("first_seen_price"), default=0.0) and price:
            rec["first_seen_price"] = price
        first_price = fnum(rec.get("first_seen_price"), default=price)
        rec["highest_price"] = max(fnum(rec.get("highest_price"), default=0.0), price)
        rec["highest_pct"] = round(((fnum(rec.get("highest_price"), default=0.0) - first_price) / first_price * 100.0), 3) if first_price else 0.0
        rec["last_gain_pct"] = _v383_gain_now(ev, rec)
        rec["last_promote_reasons"] = reasons[:10]
        rec["last_info_root_causes"] = _v384_info_root_causes(ev)
        if new_stage == "S3" and reasons and str(reasons[0]).startswith("S3"):
            rec["s3_to_s2_fail_reasons"] = reasons[2:10]
        if new_stage == "S2" and reasons and str(reasons[0]).startswith("S2"):
            rec["s2_to_s1_fail_reasons"] = reasons[1:10]
        rec["recheck_count"] = int(fnum(rec.get("recheck_count"), default=0)) + (1 if new_stage == "S2" else 0)
        sk = str(ev.get("strategy_key") or ev.get("strategy_bucket_primary") or "")
        if sk:
            keys = list(rec.get("strategy_keys") if isinstance(rec.get("strategy_keys"), list) else [])
            if sk not in keys:
                keys.append(sk)
            rec["strategy_keys"] = keys[:8]
        items[key] = rec
        stage_counts[new_stage] += 1
        revised.append(_v379_apply_lifecycle_to_event(ev, rec, new_stage, reasons, nowv))
    latest, appended = persist_paper_handoff(revised, evaluated=int((load_json(SUMMARY, {}) or {}).get("evaluated") or 0))
    stats = {
        "schema": "s123_lifecycle_v384",
        "stage_counts": stage_counts,
        "transitions": transitions,
        "s2_to_s1_fail_reasons": fail_reasons,
        "s3_to_s2_fail_reasons": s3_fail_reasons,
        "info_missing_root_causes": info_root_causes,
        "s2_to_s1_fail_samples": s2_fail_samples,
        "s3_to_s2_fail_samples": s3_fail_samples,
        "active_count": len(items),
        "latest_count": len(latest),
        "archive_appended": appended,
        "note": "v384: S2/S3가 못 올라간 이유와 정보부족 원천 원인을 단계별로 남긴다.",
    }
    _v379_save_lifecycle({"items": items}, stats)
    try:
        sm = load_json(SUMMARY, {}) or {}
        sm.update({"version": VERSION, "lifecycle_schema": "s123_lifecycle_v384", "lifecycle_stats": stats, "s_stage_counts": stage_counts, "paper_latest_count": len(latest), "s_count": len(latest), "note": "v0.27/v384: S3→S2, S2→S1 미승격 이유와 정보부족 root cause를 분리한다."})
        save_json(SUMMARY, sm)
    except Exception as exc:
        append_error(ERROR, "v384_summary_update", exc)
    try:
        write_status("running", evaluated=int((load_json(SUMMARY, {}) or {}).get("evaluated") or 0), s_count=len(latest), paper_latest_count=len(latest), s1_count=stage_counts.get("S1", 0), s2_count=stage_counts.get("S2", 0), s3_count=stage_counts.get("S3", 0), lifecycle_schema="s123_lifecycle_v384", lifecycle_active=len(items), lifecycle_transitions=transitions, s2_to_s1_fail_reasons=fail_reasons, s3_to_s2_fail_reasons=s3_fail_reasons, info_missing_root_causes=info_root_causes, last_sec=fnum((base_result or {}).get("last_sec"), default=0.0))
    except Exception:
        pass
    out = dict(base_result or {})
    out.update({"s_stage_counts": stage_counts, "lifecycle_stats": stats, "paper_latest": len(latest), "s": len(latest)})
    return out

def run_once() -> Dict[str, Any]:  # type: ignore[override]
    base = _v383_base_run_once()
    return _v384_finalize_lifecycle(base)


# =============================================================================
# strategy_worker v0.28 / v385: final main order fix
# - v384 code existed after an earlier if __main__: main(), so runtime started before v384 loaded.
# - Do not add another strategy condition. Ensure final loaded run_once(v384) is the one executed.
# - Paper/open problems must be diagnosed after this runtime-order fix.
# =============================================================================
VERSION = "strategy_worker_v0.28"
_v385_base_run_once = run_once

def run_once() -> Dict[str, Any]:  # type: ignore[override]
    return _v385_base_run_once()



# =============================================================================
# strategy_worker v0.29 / v386: S1 lifecycle -> paper handoff single factory seal
# - Root cause: lifecycle summary could report S1, but paper handoff merge could still expose
#   the older S2/S3 row, so paper saw S1 handoff 입구 0.
# - This is not a condition change. It seals the factory output: a lifecycle S1 row must carry
#   paper_bot_open/open_eligible/trade_ready/open_source and remain S1 in latest handoff.
# =============================================================================
VERSION = "strategy_worker_v0.29"
_v386_base_run_once = run_once

def _v386_stage_of(row: Dict[str, Any]) -> str:
    srcs: List[Dict[str, Any]] = []
    if isinstance(row, dict):
        srcs.append(row)
        for k in ("entry_context", "entry_snapshot"):
            v = row.get(k)
            if isinstance(v, dict):
                srcs.append(v)
                for kk in ("flat", "strategy", "orderflow", "feature"):
                    vv = v.get(kk)
                    if isinstance(vv, dict):
                        srcs.append(vv)
    for src in srcs:
        g = str(src.get("lifecycle_stage") or src.get("s_stage") or src.get("candidate_stage") or src.get("candidate_grade") or src.get("grade") or "").upper().strip()
        if g == "S":
            return "S1"
        if g in {"S1", "S2", "S3"}:
            return g
    return "S3"

def _v386_force_stage_fields(row: Dict[str, Any], stage: str) -> Dict[str, Any]:
    out = dict(row or {})
    stage = stage if stage in {"S1", "S2", "S3"} else "S3"
    out.update({
        "s_stage": stage,
        "candidate_grade": stage,
        "grade": stage,
        "entry_grade": stage,
        "signal_grade": stage,
        "lifecycle_stage": stage,
        "candidate_grade_label": _STAGE_LABEL.get(stage, stage) if '_STAGE_LABEL' in globals() else stage,
        "paper_bot_open": stage == "S1",
        "open_eligible": stage == "S1",
        "trade_ready": stage == "S1",
        "recheck_required": stage == "S2",
        "observe_only": stage == "S3",
    })
    if stage == "S1":
        out["open_source"] = "s1_lifecycle"
        out["paper_handoff_ready"] = True
        out["final_entry_action"] = "paper_open"
    ctx = out.get("entry_context") if isinstance(out.get("entry_context"), dict) else {}
    ctx.update({
        "s_stage": stage,
        "candidate_grade": stage,
        "grade": stage,
        "lifecycle_stage": stage,
        "paper_bot_open": stage == "S1",
        "open_eligible": stage == "S1",
        "trade_ready": stage == "S1",
    })
    if stage == "S1":
        ctx["open_source"] = "s1_lifecycle"
        ctx["paper_handoff_ready"] = True
    out["entry_context"] = ctx
    snap = out.get("entry_snapshot") if isinstance(out.get("entry_snapshot"), dict) else None
    if isinstance(snap, dict):
        flat = snap.get("flat") if isinstance(snap.get("flat"), dict) else {}
        flat.update({"s_stage": stage, "candidate_grade": stage, "grade": stage, "lifecycle_stage": stage})
        snap["flat"] = flat
        strat = snap.get("strategy") if isinstance(snap.get("strategy"), dict) else {}
        strat.update({"decision_stage": stage, "lifecycle_stage": stage, "paper_bot_open": stage == "S1"})
        snap["strategy"] = strat
        out["entry_snapshot"] = snap
    return out

def _v386_rewrite_latest_stage_priority() -> Dict[str, Any]:
    rows = [r for r in read_jsonl(PAPER_LATEST, max_lines=240) if isinstance(r, dict)]
    fixed: List[Dict[str, Any]] = []
    counts = {"S1": 0, "S2": 0, "S3": 0}
    for r in rows:
        st = _v386_stage_of(r)
        counts[st] = counts.get(st, 0) + 1
        fixed.append(_v386_force_stage_fields(r, st))
    # keep S1 first so paper's merge/picker cannot lose it behind an older S3 row
    fixed.sort(key=lambda x: ({"S1": 3, "S2": 2, "S3": 1}.get(_v386_stage_of(x), 0), fnum(x.get("updated_ts"), x.get("created_at"), default=0.0), fnum(x.get("score"), default=0.0)), reverse=True)
    if fixed:
        write_jsonl_atomic(PAPER_LATEST, fixed[:40])
    try:
        h = load_json(HANDOFF, {}) or {}
        h.update({
            "version": VERSION,
            "v386_factory_sealed": True,
            "v386_latest_stage_counts": counts,
            "s1_count": counts.get("S1", 0),
            "s2_count": counts.get("S2", 0),
            "s3_count": counts.get("S3", 0),
            "note": "v386: lifecycle S1 rows are forced into paper handoff with open_eligible/trade_ready before paper reads them.",
        })
        save_json(HANDOFF, h)
    except Exception as exc:
        append_error(ERROR, "v386_handoff_status", exc)
    return counts

def run_once() -> Dict[str, Any]:  # type: ignore[override]
    out = _v386_base_run_once()
    try:
        counts = _v386_rewrite_latest_stage_priority()
        try:
            write_status("running", evaluated=int((load_json(SUMMARY, {}) or {}).get("evaluated") or 0), s_count=sum(counts.values()), paper_latest_count=sum(counts.values()), s1_count=counts.get("S1",0), s2_count=counts.get("S2",0), s3_count=counts.get("S3",0), lifecycle_schema="s123_lifecycle_v386_factory_sealed", v386_factory_sealed=True, last_sec=fnum((out or {}).get("last_sec"), default=0.0))
        except Exception:
            pass
        if isinstance(out, dict):
            out["s_stage_counts"] = counts
            out["v386_factory_sealed"] = True
    except Exception as exc:
        append_error(ERROR, "v386_factory_seal", exc)
    return out

if __name__ == "__main__":
    main()
