코인봇 v2090 · 구조자료 누락 재수집 배관 복구

현재 확인된 문제
- 구조판은 canonical SOURCE_MISSING 후보 79개를 표시했지만 현재 full-profile 요청은 0이었다.
- 후보는 유지됐지만 기존 Strategy→Candle 재수집 요청에 실리지 않아 구조자료가 다시 들어오지 않았다.

수정
- root/nested canonical structure_context의 SOURCE_MISSING을 모두 읽는다.
- 기존 urgent 요청을 보존한 채 해당 ticker를 structure_full_htf_mtf_ltf로 추가 또는 업그레이드한다.
- 고정 개수 제한 없음.
- 자료가 갱신되면 기존 row를 수정·강제승격하지 않고 새 candidate 사건으로 다시 평가한다.
- detected/added/upgraded/full-profile 건수를 기존 runtime artifact에 남긴다.

변경하지 않음
- trigger/invalid/target 및 구조선 공식
- 후보 수·등급·rank
- 기존 OPEN과 청산계약
- v2086·v2089
- 원장
- 자동매수 OFF

판정
- 로컬 py_compile·synthetic queue 검수 PASS
- 서버 적용·Candle 소비 증명 전 CHECK
