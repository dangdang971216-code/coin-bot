현재 상태
- v2126은 서버 Python 3.11 py_compile에서 bot.py nested f-string 문법 오류로 적용되지 않음
- 서버는 기존 v2125/v2124 본선이며, v2126 시간봉인·version_score 전달 수정은 아직 미적용
- OPEN 수가 적은 현상은 이번 문법 오류와 무관하며, 인위적 OPEN/cycle 개수 제한은 현재 본선에서 0(무제한)

수정
- version_score 시간 문구를 Python 3.11 호환 방식으로 변경
- v2126의 정확한 진입 시간축 봉인과 /version_score 1회 전달 수정을 그대로 포함
- 로컬 Python 3.13 py_compile 외에 전체 변경 파일을 Python 3.11 grammar로 추가 검수

OPEN 수 판독
- 최근 자료에서는 462개 중 S1이 4~9개로 좁아지고, Paper 최종검사에서도 선택 0인 cycle이 있었음
- 개수 제한 때문이 아니라 구조계약·실제 진입가 RR/목표공간·실행자료·최종안전 조건에서 자연스럽게 줄어드는 흐름
- CLOSED 표본이 없으므로 수치·기준은 변경하지 않고, /pstatus 보류 사유와 다음 OPEN 시간봉인으로 원인만 수집

미변경
- 후보등급, 구조선, trigger/invalid/target, RR/목표공간/추격/spread/slippage, 진입·청산, OPEN/CLOSED, Shadow, 자동매수 OFF

서버 검수
- bundle py_compile PASS
- Paper running=True 및 /pstatus 응답 1회
- /version_score 핵심판 1회 + TXT 1개
- 다음 OPEN의 8단계 시간 및 병목 표시
