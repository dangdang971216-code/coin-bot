v945 HOT-WATCH 관찰 계측 본선. 인수인계와 APPLY_AFTER_v945.txt 확인. guard 변경 없음: 1회 적용.
