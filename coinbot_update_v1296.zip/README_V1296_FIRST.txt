v1296 fixes v1295 bundle ledger schema preflight and keeps Paper patch-order fix. Run /gupgrade_bundle first.
