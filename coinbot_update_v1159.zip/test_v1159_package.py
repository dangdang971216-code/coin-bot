#!/usr/bin/env python3
from pathlib import Path
import hashlib,json
R=Path(__file__).resolve().parent
for line in (R/'FILES_SHA256_v1159.tsv').read_text().splitlines():
    if not line.strip(): continue
    digest,name=line.split('\t',1); p=R/name
    assert p.is_file() and hashlib.sha256(p.read_bytes()).hexdigest()==digest,name
for p in R.rglob('*'):
    if not p.is_file(): continue
    x=str(p.relative_to(R)).lower()
    assert not any(y in x for y in ('paper_bot_open.json','paper_bot_closed.jsonl','paper_trade_log.json','decision_state','.log','__pycache__')),x
b=json.loads((R/'DEPLOY_BUNDLE.json').read_text())
assert b['workers']['strategy']=='strategy_worker_v1.022.py'
assert b['paper']=='paper_bot_v1.033.py' and b['guard']=='backga_guard_bot_v2_5_193.py' and b['main']=='coinbot_main_v2_13_1119.py'
assert b['auto_buy'] is False and b['trigger_occurrence_lifecycle_change'] is True
listed=set(b['support_files']); actual={str(p.relative_to(R)) for p in R.rglob('*') if p.is_file()}
assert not (listed-actual), sorted(listed-actual)
print('PASS v1159 package')
