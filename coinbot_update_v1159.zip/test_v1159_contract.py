#!/usr/bin/env python3
from pathlib import Path
import ast, hashlib, json, os, tempfile, threading
from typing import Any, Dict, Optional, Tuple, List
ROOT=Path(__file__).resolve().parent
S=ROOT/'strategy_worker_v1.022.py'; P=ROOT/'paper_bot_v1.033.py'; G=ROOT/'backga_guard_bot_v2_5_193.py'; M=ROOT/'coinbot_main_v2_13_1119.py'
for x in (S,P,G,M): compile(x.read_text(),str(x),'exec')

def funcs(path: Path):
    mod=ast.parse(path.read_text())
    return {n.name:n for n in mod.body if isinstance(n,ast.FunctionDef)}

def run_fn_nodes(nodes, ns, filename):
    exec(compile(ast.Module(body=nodes,type_ignores=[]),filename,'exec'),ns)

# Unrelated trading contracts stay byte-semantically identical to v1158.
exp=json.loads((ROOT/'tests/fixtures/V1159_UNCHANGED_TRADING_AST_SHA256.json').read_text())
for path,key in ((S,'strategy'),(P,'paper')):
    f=funcs(path)
    for name,digest in exp[key].items():
        actual=hashlib.sha256(ast.dump(f[name],include_attributes=False).encode()).hexdigest()
        assert actual==digest,(name,actual,digest)

sf=funcs(S); pf=funcs(P)

def num(*vals,default=0.0):
    for v in vals:
        try:
            if v not in (None,''): return float(v)
        except Exception: pass
    return default

# Strategy retires only the exact Paper-stale decision/event, then requires reset/rebreak.
nsS={'Dict':Dict,'Any':Any,'Optional':Optional,'Tuple':Tuple,'_v925_num':num,
     'build_minimal_gate_decision_key':lambda state,frozen:f'{state}|plan:{int(frozen)}'}
run_fn_nodes([sf['_v1159_terminal_feedback_match'],sf['_v1133_trigger_occurrence']],nsS,str(S))
rec={
 'trigger_contract_schema_v1133':'trigger_entry_contract_v1133','frozen_ts':1.0,
 'trigger_side_v1133':'above','trigger_occurrence_decision_key_v1133':'m|plan:1|rebreak:10000',
 'trigger_event_ts_v1133':10.0,'trigger_occurrence_seq_v1133':1,
 'trigger_occurrence_kind_v1133':'QUALIFIED_REBREAK','trigger_qualification_state_v1133':'QUALIFIED_EVENT'
}
fb={'m|plan:1|rebreak:10000':{'terminal_code':'STALE_TRIGGER_OCCURRENCE','trigger_event_ts':10.0,'first_seen_ts':20.0,'exposure_count':1}}
ev,decision=nsS['_v1133_trigger_occurrence'](rec,'m',110.0,100.0,30.0,True,fb)
assert decision=='' and ev['qualification_state']=='WAIT_RESET_BELOW' and ev['paper_terminal_feedback_applied_v1159'] is True
# Falling below arms a fresh rebreak.
ev2,decision2=nsS['_v1133_trigger_occurrence'](rec,'m',99.0,100.0,31.0,False,fb)
assert decision2=='' and ev2['qualification_state']=='WAIT_REBREAK'
# A new fully-ready cross creates a new event; old feedback cannot match it.
ev3,decision3=nsS['_v1133_trigger_occurrence'](rec,'m',101.0,100.0,32.0,True,fb)
assert decision3 and decision3!='m|plan:1|rebreak:10000' and ev3['event_ts']==32.0 and ev3['qualification_state']=='QUALIFIED_EVENT'
# Mismatched feedback must never retire a live occurrence.
rec2={
 'trigger_contract_schema_v1133':'trigger_entry_contract_v1133','frozen_ts':1.0,
 'trigger_side_v1133':'above','trigger_occurrence_decision_key_v1133':'D2',
 'trigger_event_ts_v1133':50.0,'trigger_occurrence_seq_v1133':1,
 'trigger_occurrence_kind_v1133':'QUALIFIED_REBREAK','trigger_qualification_state_v1133':'QUALIFIED_EVENT'
}
ev4,d4=nsS['_v1133_trigger_occurrence'](rec2,'m',110.0,100.0,51.0,True,{'D2':{'terminal_code':'STALE_TRIGGER_OCCURRENCE','trigger_event_ts':49.0}})
assert d4=='D2' and ev4['paper_terminal_feedback_applied_v1159'] is False
# Current occurrence identity must outrank a stale row key.
nsI={'Dict':Dict,'Any':Any,'Optional':Optional,'ticker_norm':lambda x:str(x or '').upper()}
run_fn_nodes([sf['_v1153_strategy_path_identity']],nsI,str(S))
ident=nsI['_v1153_strategy_path_identity']({'ticker':'aaa','trigger_occurrence_candidate_key_v1037':'OLD'},{'candidate_key':'CURRENT'},'D','ARG','S')
assert ident['trigger_event_key']=='CURRENT' and ident['candidate_key']=='ARG'

# Paper writes one append-once stale event and updates exposure in bounded state.
with tempfile.TemporaryDirectory() as td:
    td=Path(td); state=td/'state.json'; ledger=td/'events.jsonl'; clock=[100.0]
    def now_ts(): clock[0]+=1.0; return clock[0]
    def load_json(path,default=None):
        try:return json.loads(Path(path).read_text())
        except Exception:return default
    def atomic(path,obj):
        path=Path(path); path.parent.mkdir(parents=True,exist_ok=True); tmp=path.with_suffix('.tmp')
        with tmp.open('w',encoding='utf-8') as h:
            json.dump(obj,h,separators=(',',':')); h.flush(); os.fsync(h.fileno())
        os.replace(tmp,path)
    def tail_lines(path,max_lines):
        try:return Path(path).read_text().splitlines()[-max_lines:]
        except Exception:return []
    def gate(row): return row.get('gate',{}) if isinstance(row,dict) else {}
    def decision_key(row,g): return str(g.get('swing_gate_decision_key_v977') or row.get('decision_key') or '')
    nsP={'Dict':Dict,'Any':Any,'Path':Path,'threading':threading,'hashlib':hashlib,'json':json,'os':os,
         'V1159_TRIGGER_TERMINAL_FEEDBACK_STATE':state,'V1159_TRIGGER_TERMINAL_FEEDBACK_LEDGER':ledger,
         '_V1159_TRIGGER_TERMINAL_FEEDBACK_LOCK':threading.RLock(),'V1159_TRIGGER_TERMINAL_FEEDBACK_MAX_RECORDS':5000,
         'read_strategy_entry_gate':gate,'read_strategy_decision_key':decision_key,'fnum':num,
         'normalize_ticker':lambda x:str(x or '').replace('KRW-','').upper(),'now_ts':now_ts,'iso_ts':lambda ts:f'T{ts}',
         'tail_lines':tail_lines,'log_error':lambda *a,**k:None,'_atomic_write_small_json_v994':atomic,'load_json':load_json,
         'VERSION':'paper_bot_v1.033','BUILD_LABEL':'v1159'}
    run_fn_nodes([pf['_v1159_trigger_terminal_identity'],pf['_v1159_feedback_event_exists'],pf['_v1159_append_feedback_event_once'],pf['_v1159_save_feedback_state'],pf['_v1159_record_trigger_terminal_feedback']],nsP,str(P))
    ev={'ticker':'KRW-AAA','gate':{'swing_gate_decision_key_v977':'D1','trigger_occurrence_v1037':{'decision_key':'D1','event_ts':10.0,'candidate_key':'C1'}}}
    proof={'code':'STALE_TRIGGER_OCCURRENCE','event_ts':10.0,'decision_key':'D1','ttl_sec':120,'age_sec':500}
    a=nsP['_v1159_record_trigger_terminal_feedback'](ev,proof)
    b=nsP['_v1159_record_trigger_terminal_feedback'](ev,proof)
    assert a['recorded'] and b['recorded'] and not a['same_identity'] and b['same_identity'] and b['exposure_count']==2
    lines=ledger.read_text().splitlines(); assert len(lines)==1
    st=json.loads(state.read_text()); assert st['records']['D1']['exposure_count']==2 and st['records']['D1']['trigger_event_ts']==10.0
    assert nsP['_v1159_record_trigger_terminal_feedback'](ev,{'code':'OTHER'})['recorded'] is False

# Runtime identities and canonical ledger seed are present.
gt=G.read_text(); mt=M.read_text(); pt=P.read_text(); st=S.read_text()
assert 'guard_v2.5.193_stale_occurrence_lifecycle_map_v1159_2026-06-30' in gt
assert 'v1159-stale-occurrence-lifecycle-001' in gt and "S1-COMPLETED-GENERATION-HANDOFF-1158" in gt
assert "EXPECTED_PAPER_VERSION = 'paper_bot_v1.033'" in mt and "EXPECTED_STRATEGY_VERSION = 'strategy_worker_v1.022'" in mt
assert '코인봇 운영지도 v1159' in mt and '코인봇 후보·구조 기준판 v1159' in mt
assert 'paper_trigger_terminal_feedback_v1159.json' in pt and 'STALE_TERMINAL_WAIT_RESET' in st
print('PASS v1159 contract')
