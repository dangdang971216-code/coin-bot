# v1159 원인·수정 범위

## 증상
- v1158 완료 generation 전달은 정상화됨.
- Paper가 같은 완료 generation의 S1 6개를 실제 접수했으나 6개 모두 첫 도착부터 `STALE_TRIGGER_OCCURRENCE`로 폐기됨.
- 5개는 `quality_pass → S1 first commit`, 1개는 `trigger event → quality`가 비정상적으로 오래됨.

## 코드 원인
1. Paper는 오래된 trigger 사건을 정확히 차단했지만, 그 terminal 결과를 Strategy trigger lifecycle에 돌려주지 않았다.
2. Strategy는 같은 qualified occurrence를 계속 보유할 수 있어 다음 cycle에도 S1 재게시 가능성이 남았다.
3. v1153 시간원장은 현재 occurrence key보다 과거 row key를 먼저 선택할 수 있어, 서로 다른 사건의 시각이 붙을 수 있었다.

## 수정
- Paper: exact `decision_key + trigger_event_ts` 기준 stale terminal feedback을 append-once ledger와 bounded state에 저장.
- Strategy: exact match일 때만 해당 occurrence를 retire하고, 가격이 trigger 아래로 reset된 뒤 새 qualified rebreak가 있어야 새 decision 생성.
- Strategy 시간 identity: 현재 occurrence candidate key 우선.
- Guard/Main: v1159 runtime identity와 feedback 증거 연결.

## 변경 금지 유지
- Gate, rank, TTL 120초, RR, room, spread/slippage limit, trigger/invalid/target 산식, 재진입, 청산, OPEN 30, cycle 3, 자동매수 OFF.
