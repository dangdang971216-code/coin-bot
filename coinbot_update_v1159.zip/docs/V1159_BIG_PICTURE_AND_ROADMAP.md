# 코인봇 큰 그림 상태·남은 작업 v1159

## 현재 신뢰도
- Runtime/version/hash 구조: 상당 부분 신뢰 가능.
- Strategy→Paper 완료 generation 전달: v1158 서버에서 실제 후보 6개 동일 회차 접수로 증명.
- 후보 시간 진단: 최신 6개는 앞단 시각 100% exact로 증명.
- 후보선정·수익성: 아직 신뢰 불가. 원천 누락 7개, fresh CLOSED 25/30, path 12/50, market breadth missing.
- Live/자동매수: 불가. 자동매수 OFF 유지.

## 성과 해석
- fresh CLOSED 25: +15.612%, 평균 +0.624%, 승률 56.0%.
- 현재 OPEN 12: -10.421%.
- CLOSED+OPEN 단순합 37: +5.191%, 평균 +0.140%.
- 돈흐름 1건 +15.402%가 CLOSED 총합의 약 98.7%를 차지.
- 그 1건을 빼면 CLOSED 잔여 합은 약 +0.210%, CLOSED+OPEN은 약 -10.211%.
- 결론: 한 번의 큰 수익은 잡았지만, 현재 기대값이 안정적으로 양수라고 볼 수 없음.

## 큰 상승 놓침 판단
### 코드로 확정된 위험
- 현재 trigger 계약은 below→above 순간에 구조·품질·실행 계약이 모두 준비돼야 qualified event를 생성.
- 정보가 늦은 상태에서 가격이 재하락 없이 계속 오르면 reset/rebreak를 기다리므로 직선 상승을 놓칠 수 있음.

### 아직 미확정
- 실제로 몇 종목을 몇 % 놓쳤는지.
- 최신 stale 6개가 이후 큰 폭 상승했는지.
- 이를 확정하려면 blocked candidate→15m/1h/4h horizon exact 연결이 필요.

## 우선순위
### P0
1. v1159 stale occurrence lifecycle 서버 증명.
2. 직선 상승 누락 원인: trigger 접근 전 Feature/Orderflow 준비·priority 선행 구조 감사.
3. blocked candidate horizon 원장으로 실제 놓친 상승률 수치화.
4. 후보 기준판 누락 7개 owner 연결.
5. micro CPU 과부하·디스크 9일 전망 해소.

### P1
6. fresh CLOSED 30 / path 50 / direction 60 / baseline 100 표본.
7. outlier 제외 성과, source별 기대값, OPEN 포함 cohort 검증.
8. 수익 반납·수익→손실 7건 분석. 진입 안정화 전 청산 계약 변경 금지.
9. v1054 대비 exact 회귀 비교 완료.

### P2
10. Telegram 제목·버전 identity 동적화, compact 대시보드, 알림 편의성.

## Live 예상
- 최단 조건: P0 해결 + 24~48시간 신규 오류 0 + fresh CLOSED 30 이상 + path 50 이상 + 비용 후 기대값 양수.
- 빠르면 3~7일 내 사용자 승인형 소액 수동 테스트 가능.
- 자동매수는 최소 1~2주, 안전하게는 2~3주 이상이 현실적.
- 표본 속도와 새 P0 발견 여부에 따라 더 늦어질 수 있음.
