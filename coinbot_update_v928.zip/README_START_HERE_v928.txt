코인봇 v928 저장·지연 경량화 릴리스

1. 서버 적용: coinbot_update_v928.zip
2. 가드 새 명령이 안 보이면 /gguard_restart
3. 미리보기: /gstorage_fix dry
4. 승인된 정리 실행: /gstorage_fix
5. 2~3 cycle 뒤: /gdeep_audit 10
6. 메인봇: /health /change_verify /issue_ledger /errorlog

매매 기준과 자동매수 상태는 변경하지 않았다. 서버 숫자 확인 전 완료로 판정하지 않는다.
