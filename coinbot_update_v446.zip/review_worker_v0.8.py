#!/usr/bin/env python3
# -*- coding: utf-8 -*-
from __future__ import annotations
import json, os, time, traceback
from pathlib import Path
from typing import Any, Dict, List, Optional

BASE_DIR = Path(os.getenv("TRADING_BOT_DIR", "/home/dangdang971216/trading_bot"))
VERSION = "review_worker_v0.8"
INTERVAL_SEC = float(os.getenv("REVIEW_WORKER_INTERVAL_SEC", "30"))
RETENTION_DAYS = float(os.getenv("REVIEW_RETENTION_DAYS", "2"))

STATUS = BASE_DIR / "clean_review_worker_status.json"
ERROR = BASE_DIR / "clean_review_worker_error.log"
CLOSED = BASE_DIR / "paper_bot_closed.jsonl"
PAPER_LATEST = BASE_DIR / "paper_candidates_latest.jsonl"
FEATURE = BASE_DIR / "clean_feature_cache.json"
ORDERFLOW = BASE_DIR / "clean_orderflow_summary_cache.json"
QUEUE = BASE_DIR / "clean_missed_review_queue.json"
STATE = BASE_DIR / "clean_missed_review_state.json"
SUMMARY = BASE_DIR / "clean_missed_review_summary.json"
OLD_SUMMARY = BASE_DIR / "clean_review_summary.json"

def now_ts() -> float: return time.time()
def now_text(ts: Optional[float]=None) -> str: return time.strftime("%Y-%m-%d %H:%M:%S", time.localtime(ts or now_ts()))
def fnum(*vals: Any, default: float=0.0) -> float:
    for v in vals:
        try:
            if v is None or v == "": continue
            return float(str(v).replace(",", "").replace("%", ""))
        except Exception: continue
    return default

def load_json(path: Path, default: Any=None) -> Any:
    try:
        if not path.exists(): return default
        return json.loads(path.read_text(encoding="utf-8", errors="ignore"))
    except Exception: return default

def save_json(path: Path, obj: Any) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    tmp = path.with_suffix(path.suffix + ".tmp")
    tmp.write_text(json.dumps(obj, ensure_ascii=False, separators=(",", ":"), default=str), encoding="utf-8")
    os.replace(tmp, path)

def read_jsonl(path: Path, max_lines: int=1000) -> List[Dict[str, Any]]:
    if not path.exists(): return []
    try:
        lines = path.read_text(encoding="utf-8", errors="ignore").splitlines()
        if max_lines and len(lines) > max_lines: lines = lines[-max_lines:]
        out: List[Dict[str, Any]] = []
        for ln in lines:
            try:
                if ln.strip():
                    o=json.loads(ln)
                    if isinstance(o, dict): out.append(o)
            except Exception: pass
        return out
    except Exception: return []

def append_error(path: Path, where: str, exc: BaseException) -> None:
    try:
        path.parent.mkdir(parents=True, exist_ok=True)
        with path.open("a", encoding="utf-8") as f:
            f.write(f"[{now_text()}] {where}: {exc.__class__.__name__}: {exc}\n")
            f.write(traceback.format_exc()[-1500:] + "\n")
    except Exception: pass

def ticker_norm(x: Any) -> str:
    t = str(x or "").strip().upper().replace("/", "-").replace("_", "-")
    parts = [p for p in t.split("-") if p]
    if len(parts) >= 2:
        non = [p for p in parts if p != "KRW"]
        t = non[-1] if non else parts[-1]
    if t.endswith("KRW") and len(t) > 3: t = t[:-3]
    return t.strip().upper()

def map_rows(obj: Any) -> Dict[str, Dict[str, Any]]:
    if isinstance(obj, dict) and isinstance(obj.get("rows"), list): obj = obj.get("rows")
    elif isinstance(obj, dict) and isinstance(obj.get("rows"), dict): obj = obj.get("rows")
    elif isinstance(obj, dict) and isinstance(obj.get("cache"), dict): obj = obj.get("cache")
    out: Dict[str, Dict[str, Any]] = {}
    if isinstance(obj, list):
        for r in obj:
            if isinstance(r, dict):
                t = ticker_norm(r.get("ticker") or r.get("symbol") or r.get("market"))
                if t: out[t] = r
    elif isinstance(obj, dict):
        for k, v in obj.items():
            t = ticker_norm(k)
            if t and isinstance(v, dict):
                vv = dict(v); vv.setdefault("ticker", t); out[t] = vv
    return out

def write_status(state: str, **extra: Any) -> None:
    save_json(STATUS, {"version": VERSION, "state": state, "pid": os.getpid(), "updated_ts": now_ts(), "updated_text": now_text(), **extra})

def profit(row: Dict[str, Any]) -> float:
    return fnum(row.get("profit_pct"), row.get("return_pct"), row.get("pnl_pct"), row.get("profit_rate"), default=0.0)

def _current_price(ticker: str, fmap: Dict[str, Dict[str, Any]], ofmap: Dict[str, Dict[str, Any]]) -> float:
    f = fmap.get(ticker, {}) or {}
    o = ofmap.get(ticker, {}) or {}
    return fnum(o.get("quote_price"), o.get("current_price"), o.get("price"), f.get("current_price"), f.get("price"), f.get("last_price"), f.get("close"), default=0.0)

def _pct(cur: float, base: float) -> float:
    return round((cur - base) / base * 100.0, 3) if cur and base else 0.0

def _risk_profile(rec: Dict[str, Any]) -> Dict[str, Any]:
    """결과만 오른 위험 후보와 진짜 놓친 후보를 분리하기 위한 표시용 판정.
    조건/S1/S2/S3 기준은 바꾸지 않고 review 분류만 정리한다.
    """
    m = rec.get("metrics") if isinstance(rec.get("metrics"), dict) else {}
    spread = fnum(m.get("spread_pct"), default=0.0)
    slip = fnum(m.get("slippage_pct"), default=0.0)
    buy = fnum(m.get("buy_ratio"), default=0.0)
    sustain = fnum(m.get("buy_sustain_1m"), default=0.0)
    cur_pct = fnum(rec.get("current_pct"), default=0.0)
    reasons = " / ".join(str(x) for x in (rec.get("block_reasons") or []) if str(x).strip())
    risk: List[str] = []
    mild: List[str] = []
    if spread >= 0.30: risk.append(f"스프레드 {spread:.2f}%")
    elif spread >= 0.20: mild.append(f"스프레드 {spread:.2f}%")
    if slip >= 0.30: risk.append(f"미끄러짐 {slip:.2f}%")
    elif slip >= 0.20: mild.append(f"미끄러짐 {slip:.2f}%")
    if buy and buy < 0.55: risk.append(f"매수체결 {buy:.2f}")
    elif buy and buy < 0.68: mild.append(f"매수체결 {buy:.2f}")
    if sustain and sustain < 0.55: risk.append(f"1분지속 {sustain:.2f}")
    elif sustain and sustain < 0.64: mild.append(f"1분지속 {sustain:.2f}")
    for word in ("매도벽", "매도압력", "EMA5 아래", "추세 부담"):
        if word in reasons:
            risk.append(word)
    if cur_pct <= -1.00:
        risk.append(f"현재 되돌림 {cur_pct:+.2f}%")
    return {"risk": risk, "mild": mild, "is_high_risk": bool(risk), "risk_note": " / ".join(risk[:4]) if risk else (" / ".join(mild[:4]) if mild else "위험 낮음")}

def _decision(rec: Dict[str, Any], elapsed: float) -> str:
    max_pct = fnum(rec.get("max_pct"), default=0.0)
    cur_pct = fnum(rec.get("current_pct"), default=0.0)
    rp = _risk_profile(rec)
    rec["risk_reasons"] = rp.get("risk", [])
    rec["risk_note"] = rp.get("risk_note", "")
    if max_pct >= 1.20:
        return "🔥 결과만 오른 위험 후보" if rp.get("is_high_risk") else "❌ 진짜 놓친 후보"
    if max_pct >= 0.70:
        return "🔥 결과만 오른 위험 후보" if rp.get("is_high_risk") else "⚠️ 아까운 후보"
    if elapsed >= 1200 and max_pct < 0.30: return "✅ 안 산 게 맞음"
    if elapsed >= 300 and cur_pct <= -0.30 and max_pct < 0.50: return "✅ 안 산 게 맞음"
    return "❔ 추적중"

def _short_reasons(rec: Dict[str, Any]) -> str:
    reasons = rec.get("block_reasons") if isinstance(rec.get("block_reasons"), list) else []
    missing = rec.get("missing_info") if isinstance(rec.get("missing_info"), list) else []
    arr = [str(x) for x in (reasons + missing) if str(x).strip()]
    return " / ".join(arr[:3]) if arr else "-"


def _has_structure(rec: Dict[str, Any]) -> bool:
    if not isinstance(rec, dict):
        return False
    tags = rec.get("structure_tags")
    risk = rec.get("structure_risk_tags")
    fit = rec.get("structure_fit")
    return (isinstance(tags, list) and bool(tags)) or (isinstance(risk, list) and bool(risk)) or bool(str(fit or "").strip())

def _copy_structure(dst: Dict[str, Any], src: Dict[str, Any]) -> bool:
    if not isinstance(dst, dict) or not isinstance(src, dict) or not _has_structure(src):
        return False
    st = src.get("chart_structure") if isinstance(src.get("chart_structure"), dict) else {}
    dst["structure_tags"] = src.get("structure_tags") if isinstance(src.get("structure_tags"), list) else st.get("tags", [])
    dst["structure_good_tags"] = src.get("structure_good_tags") if isinstance(src.get("structure_good_tags"), list) else st.get("good_tags", [])
    dst["structure_risk_tags"] = src.get("structure_risk_tags") if isinstance(src.get("structure_risk_tags"), list) else st.get("risk_tags", [])
    dst["structure_fit"] = str(src.get("structure_fit") or st.get("strategy_fit") or "")
    dst["structure_summary"] = str(src.get("structure_summary") or st.get("summary") or "")
    dst["chart_structure"] = st
    dst["structure_source"] = "candidate_snapshot"
    return True

def _unique(items: List[str]) -> List[str]:
    out: List[str] = []
    for x in items:
        t = str(x or "").strip()
        if t and t not in out:
            out.append(t)
    return out

def _derive_structure_from_rec(rec: Dict[str, Any]) -> Dict[str, Any]:
    """기존 active review state처럼 구조태그가 없던 기록에 붙이는 표시용 보강.
    후보 차단·S1 승격·청산에는 쓰지 않는다.
    """
    text = " / ".join(str(x) for x in (rec.get("block_reasons") or []) if str(x).strip())
    strat = str(rec.get("strategy") or rec.get("strategy_key") or "")
    m = rec.get("metrics") if isinstance(rec.get("metrics"), dict) else {}
    spread = fnum(m.get("spread_pct"), default=0.0)
    slip = fnum(m.get("slippage_pct"), default=0.0)
    buy = fnum(m.get("buy_ratio"), default=0.0)
    cur = fnum(rec.get("current_pct"), default=0.0)
    maxp = fnum(rec.get("max_pct"), default=0.0)
    tags: List[str] = []
    risks: List[str] = []

    if "돈흐름" in strat or "reaccel" in strat:
        tags += ["눌림후재가속", "돈흐름재유입"]
        if "VWAP" not in text and "EMA" not in text:
            tags.append("VWAP방어")
    if "돌파" in strat or "breakout" in strat:
        tags += ["저항돌파", "저항돌파후재테스트"]
        if "돌파 후" in text or "돌파선" in text:
            tags.append("지지전환확인")
    if "저점" in strat or "VWAP 회복" in strat or "sweep" in strat:
        tags += ["저점유동성쓸림", "쓸림후빠른회복", "VWAP재회복"]
    if "주도흐름" in strat or "유동보유" in strat or "adaptive_hold" in strat:
        tags += ["얕은눌림", "VWAP방어", "EMA방어", "상대강도유지"]
    if "주도추세" in strat or "momentum" in strat:
        tags += ["고점저점상승", "추세지속", "채널하단방어"]
    if "급등" in strat or "재돌파" in strat or "rebreak" in strat:
        tags += ["급등후눌림", "고점재돌파", "돈흐름재유입"]

    if "고점권" in text and "가격반응" in text:
        risks.append("고점권가격반응약함")
    if "스프레드" in text or spread >= 0.30:
        risks.append("스프레드부담")
    if "미끄" in text or slip >= 0.30:
        risks.append("미끄러짐부담")
    if "매도벽" in text or "매도압력" in text:
        risks.append("매도압력부담")
    if "돌파 후" in text and "부족" in text:
        risks.append("가짜돌파위험")
    if cur <= -1.0 or (maxp >= 1.2 and cur < 0):
        risks.append("되돌림위험")
    if buy and buy < 0.55:
        risks.append("매수체결약함")

    if not tags:
        tags = ["구조정보부족"]
    tags = _unique(tags)[:10]
    risks = _unique(risks)[:8]
    fit = "구조좋음" if tags and tags != ["구조정보부족"] else "구조정보부족"
    if risks and fit == "구조좋음":
        fit = "구조좋음+위험확인"
    elif risks:
        fit = "구조위험"
    return {
        "schema": "review_structure_fallback_v446",
        "tags": tags,
        "good_tags": [t for t in tags if t != "구조정보부족"],
        "risk_tags": risks,
        "strategy_fit": fit,
        "summary": f"{fit} · 좋음 {', '.join(tags[:3]) if tags else '-'} / 위험 {', '.join(risks[:3]) if risks else '-'}",
    }

def _ensure_structure(rec: Dict[str, Any], sources: Dict[str, Dict[str, Any]]) -> None:
    if not isinstance(rec, dict) or _has_structure(rec):
        return
    t = ticker_norm(rec.get("ticker"))
    if t and _copy_structure(rec, sources.get(t, {}) or {}):
        return
    st = _derive_structure_from_rec(rec)
    rec["chart_structure"] = st
    rec["structure_tags"] = st.get("tags", [])
    rec["structure_good_tags"] = st.get("good_tags", [])
    rec["structure_risk_tags"] = st.get("risk_tags", [])
    rec["structure_fit"] = st.get("strategy_fit", "")
    rec["structure_summary"] = st.get("summary", "")
    rec["structure_source"] = "review_fallback"

def _summ_rows(rows: List[Dict[str, Any]], limit: int = 8) -> List[Dict[str, Any]]:
    rows = sorted(rows, key=lambda r: (fnum(r.get("max_pct"), default=0.0), fnum(r.get("score"), default=0.0)), reverse=True)
    out = []
    for r in rows[:limit]:
        out.append({
            "ticker": r.get("ticker"), "stage": r.get("stage"), "strategy": r.get("strategy"),
            "score": r.get("score"), "decision": r.get("decision"),
            "first_price": r.get("first_price"), "current_price": r.get("current_price"),
            "current_pct": r.get("current_pct"), "max_pct": r.get("max_pct"),
            "after_5m_pct": r.get("after_5m_pct"), "after_10m_pct": r.get("after_10m_pct"), "after_20m_pct": r.get("after_20m_pct"),
            "reasons": _short_reasons(r),
            "risk_note": r.get("risk_note", ""),
            "risk_reasons": r.get("risk_reasons", []),
            "structure_tags": r.get("structure_tags", []),
            "structure_good_tags": r.get("structure_good_tags", []),
            "structure_risk_tags": r.get("structure_risk_tags", []),
            "structure_fit": r.get("structure_fit", ""),
            "structure_summary": r.get("structure_summary", ""),
            "chart_structure": r.get("chart_structure", {}),
            "review_class": r.get("decision", ""),
        })
    return out

def _reason_top(rows: List[Dict[str, Any]], limit: int = 8) -> List[Dict[str, Any]]:
    cnt: Dict[str, int] = {}
    for r in rows:
        for x in (r.get("block_reasons") or []):
            key = str(x).split()[0].strip() or str(x).strip()
            if key: cnt[key] = cnt.get(key, 0) + 1
    return [{"reason": k, "count": v} for k, v in sorted(cnt.items(), key=lambda kv: kv[1], reverse=True)[:limit]]

def _legacy_closed_summary() -> Dict[str, Any]:
    rows = read_jsonl(CLOSED, max_lines=900)
    def pnl(r: Dict[str, Any]) -> float: return fnum(r.get("pnl_pct"), r.get("profit_pct"), default=0.0)
    def peak(r: Dict[str, Any]) -> float: return fnum(r.get("peak_pct"), r.get("max_profit_pct"), default=0.0)
    protect_needed=[]; fast_fail=[]; good_keep=[]
    for r in rows[-120:]:
        pk=peak(r); pn=pnl(r); give=max(0.0, pk-pn)
        if pk >= 0.70 and (pn < 0 or give >= 0.55):
            protect_needed.append({"ticker": ticker_norm(r.get("ticker")), "peak_pct": pk, "pnl_pct": pn, "giveback_pct": round(give,3), "reason": r.get("exit_reason"), "tag": r.get("close_review_tag") or "보호익절 필요 후보"})
        elif pn <= -0.60 and pk < 0.25:
            fast_fail.append({"ticker": ticker_norm(r.get("ticker")), "peak_pct": pk, "pnl_pct": pn, "giveback_pct": round(give,3), "reason": r.get("exit_reason"), "tag": r.get("close_review_tag") or "빠른실패 정리 후보"})
        elif pn > 0 and pk-pn <= 0.35:
            good_keep.append({"ticker": ticker_norm(r.get("ticker")), "peak_pct": pk, "pnl_pct": pn, "giveback_pct": round(give,3), "reason": r.get("exit_reason"), "tag": r.get("close_review_tag") or "수익 보존 양호"})
    big_loss = sorted([r for r in rows if profit(r) <= -0.8], key=profit)[:10]
    good_win = sorted([r for r in rows if profit(r) >= 1.0], key=profit, reverse=True)[:10]
    return {"closed_recent": len(rows), "big_loss": len(big_loss), "good_win": len(good_win), "close_review": {"protect_needed_count": len(protect_needed), "fast_fail_count": len(fast_fail), "good_keep_count": len(good_keep), "protect_needed": protect_needed[-5:], "fast_fail": fast_fail[-5:], "good_keep": good_keep[-5:]}}


def run_once() -> Dict[str, Any]:
    st = now_ts(); write_status("running", phase="refreshing", last_sec=0)
    queue = load_json(QUEUE, {}) or {}
    qrows = queue.get("review_candidates") if isinstance(queue, dict) and isinstance(queue.get("review_candidates"), list) else []
    # v446: review state에 이미 들어간 구 후보도 구조태그가 보이도록 현재 후보 snapshot/queue와 fallback 파생값으로 보강한다.
    source_rows = [r for r in read_jsonl(PAPER_LATEST, max_lines=600) if isinstance(r, dict)] + [r for r in qrows if isinstance(r, dict)]
    structure_sources: Dict[str, Dict[str, Any]] = {}
    for sr in source_rows:
        tt = ticker_norm(sr.get("ticker") or sr.get("symbol") or sr.get("market"))
        if tt and _has_structure(sr):
            structure_sources[tt] = sr
    state = load_json(STATE, {}) or {}
    active = state.get("active") if isinstance(state.get("active"), dict) else {}
    fmap = map_rows(load_json(FEATURE, {}) or {})
    ofmap = map_rows(load_json(ORDERFLOW, {}) or {})
    nowv = now_ts()
    ttl = max(3600.0, RETENTION_DAYS * 86400.0)
    # 오래된 비핵심 복기 state만 제거. paper 장부는 삭제하지 않음.
    active = {k:v for k,v in active.items() if isinstance(v, dict) and nowv - fnum(v.get("first_seen_ts"), default=nowv) <= ttl}

    for c in qrows:
        if not isinstance(c, dict): continue
        stage = str(c.get("stage") or "").upper()
        if stage not in ("S2", "S3"): continue
        t = ticker_norm(c.get("ticker"))
        if not t: continue
        cur = _current_price(t, fmap, ofmap)
        base = fnum(c.get("snapshot_price"), c.get("price"), default=0.0) or cur
        rec = active.get(t) or {
            "ticker": t, "first_seen_ts": nowv, "first_seen_text": now_text(nowv),
            "first_price": base, "min_pct": 0.0, "max_pct": 0.0, "samples": {},
        }
        rec.update({
            "stage": stage, "strategy": c.get("strategy"), "strategy_key": c.get("strategy_key"),
            "score": c.get("score"), "block_reasons": c.get("block_reasons", []),
            "missing_info": c.get("missing_info", []), "metrics": c.get("metrics", {}),
            "structure_tags": c.get("structure_tags", []),
            "structure_good_tags": c.get("structure_good_tags", []),
            "structure_risk_tags": c.get("structure_risk_tags", []),
            "structure_fit": c.get("structure_fit", ""),
            "structure_summary": c.get("structure_summary", ""),
            "chart_structure": c.get("chart_structure", {}),
            "last_seen_ts": nowv, "last_seen_text": now_text(nowv),
        })
        if not fnum(rec.get("first_price"), default=0.0) and base:
            rec["first_price"] = base
        if cur:
            rec["current_price"] = cur
            cp = _pct(cur, fnum(rec.get("first_price"), default=0.0))
            rec["current_pct"] = cp
            rec["max_pct"] = max(fnum(rec.get("max_pct"), default=cp), cp)
            rec["min_pct"] = min(fnum(rec.get("min_pct"), default=cp), cp)
            elapsed = nowv - fnum(rec.get("first_seen_ts"), default=nowv)
            samples = rec.get("samples") if isinstance(rec.get("samples"), dict) else {}
            for label, sec in (("5m",300),("10m",600),("20m",1200)):
                if elapsed >= sec and label not in samples:
                    samples[label] = {"ts": nowv, "text": now_text(nowv), "price": cur, "pct": cp}
                    rec[f"after_{label}_pct"] = cp
            rec["samples"] = samples
            rec["decision"] = _decision(rec, elapsed)
        active[t] = rec

    # v441: active state에 남은 구 decision/review_hint를 그대로 쓰지 않는다.
    # 현재 max/current/위험프로필 기준으로 다시 분류해 /review 상단 count와 후보별 문구가 어긋나지 않게 한다.
    for rec in active.values():
        if not isinstance(rec, dict):
            continue
        _ensure_structure(rec, structure_sources)
        elapsed = nowv - fnum(rec.get("first_seen_ts"), default=nowv)
        rec["decision"] = _decision(rec, elapsed)
        rec["review_class"] = rec["decision"]
        rec["review_hint"] = rec["decision"]
    all_rows = list(active.values())
    missed = [r for r in all_rows if str(r.get("decision")) == "❌ 진짜 놓친 후보"]
    regret = [r for r in all_rows if str(r.get("decision")) == "⚠️ 아까운 후보"]
    risk_rise = [r for r in all_rows if str(r.get("decision")) == "🔥 결과만 오른 위험 후보"]
    correct = [r for r in all_rows if str(r.get("decision")) == "✅ 안 산 게 맞음"]
    done = {"❌ 진짜 놓친 후보", "⚠️ 아까운 후보", "🔥 결과만 오른 위험 후보", "✅ 안 산 게 맞음"}
    pending = [r for r in all_rows if str(r.get("decision")) not in done]
    legacy = _legacy_closed_summary()
    summary = {
        "schema": "missed_review_summary_v446_structure_display",
        "version": VERSION,
        "updated_ts": nowv, "updated_text": now_text(nowv),
        "queue_age_sec": round(nowv - fnum(queue.get("updated_ts"), default=nowv), 1) if isinstance(queue, dict) else None,
        "tracking_total": len(all_rows), "queue_candidates": len(qrows),
        "missed_count": len(missed), "regret_count": len(regret), "risk_rise_count": len(risk_rise), "correct_count": len(correct), "pending_count": len(pending),
        "missed": _summ_rows(missed, 8), "regret": _summ_rows(regret, 8), "risk_rise": _summ_rows(risk_rise, 8), "correct": _summ_rows(correct, 5), "pending": _summ_rows(pending, 8),
        "missed_reason_top": _reason_top(missed + regret, 8),
        "risk_rise_reason_top": _reason_top(risk_rise, 8),
        "policy": "S2/S3 상위 후보를 5분/10분/20분 뒤 자동 추적한다. 조건/청산숫자 변경 없음. 구조태그는 표시/복기 전용으로 보존하고, 구 active state는 v446 fallback으로 구조표시를 보강한다. 고위험 급등 후보는 진짜 놓친 후보와 분리한다. 구 review_class/review_hint는 재계산해 출력모순을 제거한다. paper 장부 삭제 없음.",
        **legacy,
    }
    save_json(STATE, {"schema":"missed_review_state_v446_structure_display", "version":VERSION, "updated_ts":nowv, "active":active})
    save_json(SUMMARY, summary)
    save_json(OLD_SUMMARY, {"version":VERSION, "updated_ts":nowv, "updated_text":now_text(nowv), **legacy, "missed_review": summary})
    sec = now_ts() - st
    write_status("running", tracked=len(all_rows), missed=len(missed), regret=len(regret), risk_rise=len(risk_rise), correct=len(correct), pending=len(pending), closed_recent=legacy.get("closed_recent",0), big_loss=legacy.get("big_loss",0), good_win=legacy.get("good_win",0), last_sec=round(sec,3), structure_enriched=sum(1 for r in active.values() if isinstance(r, dict) and _has_structure(r)))
    return {"tracked": len(all_rows), "missed": len(missed), "regret": len(regret), "correct": len(correct)}

def main() -> None:
    write_status("initializing")
    while True:
        try: run_once()
        except KeyboardInterrupt: write_status("stopping"); raise
        except Exception as exc:
            append_error(ERROR, "loop", exc); write_status("error", error=f"{exc.__class__.__name__}: {exc}")
        time.sleep(max(10.0, INTERVAL_SEC))

if __name__ == "__main__": main()
