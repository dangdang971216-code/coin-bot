coinbot_update_v1456
- Read-only candidate flow fail-reason detail.
- /candidate_flow and /candidate_flow_detail now show trigger/RR/spread/slip/missing-source clues per S1 sample.
- No trading rule, candidate criteria, OPEN rule, trigger/invalid/target/exit, stale pass, BUY_READY, or auto-buy change. Auto-buy OFF.
