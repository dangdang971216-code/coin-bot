#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Paper exact exit replay analyzer v0.2 / v1250.

Read-only SHADOW_ONLY analyzer.

Canonical inputs (never modified):
- paper_exit_replay_poll_v1242.jsonl
- paper_exit_replay_close_v1242.jsonl
- paper_bot_closed.jsonl
- paper_bot_open.json
- paper_decision_state_v926.json

Owned outputs:
- canonical_paper_exact_replay_v1250.json
- clean_exact_replay_worker_status.json
- paper_exact_replay_index_v1250.sqlite3 (regenerable analysis index)

All joins use the OPEN-time direct decision key. Ticker, pos_id and time proximity
are display-only and are never used to connect records.
"""
from __future__ import annotations

import argparse
import atexit
import fcntl
import hashlib
import json
import math
import os
import signal
import sqlite3
import sys
import time
import traceback
from collections import Counter, defaultdict
from datetime import datetime, timezone, timedelta
from pathlib import Path
from typing import Any, Dict, Iterable, Iterator, List, Mapping, Optional, Sequence, Tuple

VERSION = "exact_replay_worker_v0.2"
BUILD_LABEL = "v1250_exact_replay_link_selection_scope_repair_2026-07-05"
SNAPSHOT_SCHEMA = "canonical_paper_exact_replay_v1250"
STATUS_SCHEMA = "exact_replay_worker_status_v1250"
INDEX_SCHEMA = "paper_exact_replay_index_v1250"
DEFAULT_INTERVAL_SEC = 20.0
BIG_LOSS_THRESHOLD_PCT = -1.0  # analysis label only; not a trading rule
AUTO_BUY = False
_STOP = False
_LOCK_HANDLE: Optional[Any] = None
_KST = timezone(timedelta(hours=9))

# A reason is transferable only when its decision does not depend on the current
# structure target/invalid line. The poll evidence already contains the exact
# support/weakness confirmation state used by Paper at that time.
TRANSFERABLE_POLICY_REASONS = {
    "swing_dynamic_structure_break",
    "swing_dynamic_momentum_decay",
    "swing_response_protect",
    "swing_trailing",
    "swing_no_progress",
    "swing_max_weak_hold",
    "swing_emergency_stop",
}
STRUCTURE_DEPENDENT_REASONS = {
    "structure_target",
    "target",
    "structure_invalid",
    "invalid",
    "swing_entry_failure_invalid",
}
NON_STRATEGY_REASONS = {
    "operator_reset",
    "operator_reset_v1204",
    "operator_reset_v1205",
    "manual_close",
    "force_close",
    "reset_close",
}


def base_dir() -> Path:
    value = (
        os.getenv("COINBOT_BASE_DIR", "").strip()
        or os.getenv("TRADING_BOT_DIR", "").strip()
        or os.getenv("BOT_DIR", "").strip()
    )
    return Path(value).expanduser().resolve() if value else Path(__file__).resolve().parent


def now_ts() -> float:
    return time.time()


def now_text(ts: Optional[float] = None) -> str:
    return datetime.fromtimestamp(float(ts if ts is not None else now_ts()), _KST).strftime("%Y-%m-%d %H:%M:%S KST")


def num(value: Any, default: Optional[float] = None) -> Optional[float]:
    try:
        if value in (None, ""):
            return default
        if isinstance(value, str):
            value = value.replace(",", "").replace("%", "").strip()
        out = float(value)
        return out if math.isfinite(out) else default
    except (TypeError, ValueError, OverflowError):
        return default


def integer(value: Any, default: int = 0) -> int:
    value_num = num(value, None)
    return int(value_num) if value_num is not None else default


def clean_decision_key(value: Any) -> str:
    text = str(value or "").strip()
    if text.startswith("decision:"):
        text = text[len("decision:"):].strip()
    return text


def decision_key(row: Mapping[str, Any]) -> str:
    if not isinstance(row, Mapping):
        return ""
    for key in (
        "paper_decision_key_v926",
        "swing_gate_decision_key_v977",
        "minimal_gate_decision_key_v925",
        "direct_decision_key",
        "decision_key",
        "dk",
    ):
        value = clean_decision_key(row.get(key))
        if value:
            return value
    contract = row.get("ranked_top10_contract_v1206")
    if isinstance(contract, Mapping):
        value = clean_decision_key(contract.get("decision_key"))
        if value:
            return value
    return ""


def normalize_ticker(value: Any) -> str:
    text = str(value or "").strip().upper()
    for prefix in ("KRW-", "BITHUMB:"):
        if text.startswith(prefix):
            text = text[len(prefix):]
    for suffix in ("_KRW", "-KRW", "/KRW"):
        if text.endswith(suffix):
            text = text[:-len(suffix)]
    return text


def json_digest(obj: Any) -> str:
    raw = json.dumps(obj, ensure_ascii=False, sort_keys=True, separators=(",", ":"), default=str).encode("utf-8")
    return hashlib.sha256(raw).hexdigest()


def read_json(path: Path, default: Any) -> Any:
    try:
        if not path.exists():
            return default
        return json.loads(path.read_text(encoding="utf-8", errors="strict"))
    except Exception:
        return default


def atomic_write_json(path: Path, obj: Mapping[str, Any]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    tmp = path.with_name(f".{path.name}.{os.getpid()}.{time.time_ns()}.tmp")
    try:
        with tmp.open("w", encoding="utf-8") as handle:
            json.dump(obj, handle, ensure_ascii=False, separators=(",", ":"), default=str)
            handle.flush()
            os.fsync(handle.fileno())
        os.replace(tmp, path)
        try:
            fd = os.open(str(path.parent), os.O_RDONLY)
            try:
                os.fsync(fd)
            finally:
                os.close(fd)
        except OSError:
            pass
    finally:
        try:
            tmp.unlink(missing_ok=True)
        except OSError:
            pass


def log_error(base: Path, where: str, exc: BaseException) -> None:
    path = base / "clean_exact_replay_worker_error.log"
    try:
        with path.open("a", encoding="utf-8") as handle:
            handle.write(f"[{now_text()}] {where}: {type(exc).__name__}: {exc}\n")
            handle.write(traceback.format_exc()[-8000:] + "\n")
    except OSError:
        pass


def acquire_singleton(base: Path) -> None:
    global _LOCK_HANDLE
    lock_path = base / "runtime" / "exact_replay_worker_singleton_v1250.lock"
    lock_path.parent.mkdir(parents=True, exist_ok=True)
    handle = lock_path.open("a+")
    try:
        fcntl.flock(handle.fileno(), fcntl.LOCK_EX | fcntl.LOCK_NB)
    except BlockingIOError as exc:
        handle.close()
        raise RuntimeError("exact replay worker already running") from exc
    handle.seek(0)
    handle.truncate(0)
    handle.write(str(os.getpid()))
    handle.flush()
    _LOCK_HANDLE = handle


def release_singleton() -> None:
    global _LOCK_HANDLE
    if _LOCK_HANDLE is None:
        return
    try:
        fcntl.flock(_LOCK_HANDLE.fileno(), fcntl.LOCK_UN)
        _LOCK_HANDLE.close()
    except OSError:
        pass
    _LOCK_HANDLE = None


def signal_handler(_signum: int, _frame: Any) -> None:
    global _STOP
    _STOP = True


def source_paths(base: Path) -> Dict[str, Path]:
    return {
        "poll": base / "paper_exit_replay_poll_v1242.jsonl",
        "close": base / "paper_exit_replay_close_v1242.jsonl",
        "closed": base / "paper_bot_closed.jsonl",
        "open": base / "paper_bot_open.json",
        "decision": base / "paper_decision_state_v926.json",
        "paper_status": base / "paper_exit_replay_status_v1242.json",
    }


def output_paths(base: Path) -> Dict[str, Path]:
    return {
        "snapshot": base / "canonical_paper_exact_replay_v1250.json",
        "status": base / "clean_exact_replay_worker_status.json",
        "index": base / "paper_exact_replay_index_v1250.sqlite3",
    }


def open_db(path: Path) -> sqlite3.Connection:
    path.parent.mkdir(parents=True, exist_ok=True)
    conn = sqlite3.connect(str(path), timeout=30.0)
    conn.row_factory = sqlite3.Row
    conn.execute("PRAGMA journal_mode=WAL")
    conn.execute("PRAGMA synchronous=FULL")
    conn.execute("PRAGMA foreign_keys=ON")
    conn.executescript(
        """
        CREATE TABLE IF NOT EXISTS meta(
            key TEXT PRIMARY KEY,
            value TEXT NOT NULL
        );
        CREATE TABLE IF NOT EXISTS open_meta(
            decision_key TEXT PRIMARY KEY,
            payload TEXT NOT NULL,
            updated_ts REAL NOT NULL
        );
        CREATE TABLE IF NOT EXISTS closed_event(
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            source_line INTEGER NOT NULL UNIQUE,
            decision_key TEXT NOT NULL,
            closed_result_key TEXT,
            payload_digest TEXT NOT NULL,
            payload TEXT NOT NULL,
            inserted_ts REAL NOT NULL
        );
        CREATE INDEX IF NOT EXISTS idx_closed_event_decision ON closed_event(decision_key,id);
        CREATE INDEX IF NOT EXISTS idx_closed_event_result ON closed_event(closed_result_key);
        CREATE TABLE IF NOT EXISTS close_link_event(
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            source_line INTEGER NOT NULL UNIQUE,
            decision_key TEXT NOT NULL,
            poll_key TEXT,
            closed_result_key TEXT,
            commit_ok INTEGER NOT NULL,
            semantic_digest TEXT NOT NULL,
            payload TEXT NOT NULL,
            inserted_ts REAL NOT NULL
        );
        CREATE INDEX IF NOT EXISTS idx_close_link_decision ON close_link_event(decision_key,id);
        CREATE INDEX IF NOT EXISTS idx_close_link_poll ON close_link_event(poll_key);
        CREATE TABLE IF NOT EXISTS poll_event(
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            source_line INTEGER NOT NULL,
            record_index INTEGER NOT NULL,
            decision_key TEXT NOT NULL,
            poll_key TEXT NOT NULL,
            ts REAL,
            payload_digest TEXT NOT NULL,
            payload TEXT NOT NULL,
            inserted_ts REAL NOT NULL,
            UNIQUE(source_line,record_index)
        );
        CREATE INDEX IF NOT EXISTS idx_poll_event_decision ON poll_event(decision_key,id);
        CREATE INDEX IF NOT EXISTS idx_poll_event_key ON poll_event(decision_key,poll_key,id);
        CREATE TABLE IF NOT EXISTS replay_result(
            decision_key TEXT PRIMARY KEY,
            payload TEXT NOT NULL,
            replay_state TEXT NOT NULL,
            updated_ts REAL NOT NULL
        );
        """
    )
    schema = meta_get(conn, "index_schema", "")
    if schema and schema != INDEX_SCHEMA:
        reset_index(conn)
    meta_set(conn, "index_schema", INDEX_SCHEMA)
    meta_set(conn, "worker_version", VERSION)
    conn.commit()
    return conn


def meta_get(conn: sqlite3.Connection, key: str, default: Any = None) -> Any:
    row = conn.execute("SELECT value FROM meta WHERE key=?", (key,)).fetchone()
    if row is None:
        return default
    try:
        return json.loads(row["value"])
    except Exception:
        return default


def meta_set(conn: sqlite3.Connection, key: str, value: Any) -> None:
    conn.execute(
        "INSERT INTO meta(key,value) VALUES(?,?) ON CONFLICT(key) DO UPDATE SET value=excluded.value",
        (key, json.dumps(value, ensure_ascii=False, separators=(",", ":"), default=str)),
    )


def bump_counter(conn: sqlite3.Connection, name: str, amount: int = 1) -> None:
    key = f"counter:{name}"
    value = integer(meta_get(conn, key, 0), 0) + int(amount)
    meta_set(conn, key, value)


def counters(conn: sqlite3.Connection) -> Dict[str, int]:
    out: Dict[str, int] = {}
    for row in conn.execute("SELECT key,value FROM meta WHERE key LIKE 'counter:%'"):
        key = str(row["key"])[len("counter:"):]
        try:
            out[key] = int(json.loads(row["value"]))
        except Exception:
            out[key] = 0
    return out


def reset_index(conn: sqlite3.Connection) -> None:
    conn.executescript(
        """
        DELETE FROM open_meta;
        DELETE FROM closed_event;
        DELETE FROM close_link_event;
        DELETE FROM poll_event;
        DELETE FROM replay_result;
        DELETE FROM meta;
        DELETE FROM sqlite_sequence WHERE name IN ('closed_event','close_link_event','poll_event');
        """
    )
    meta_set(conn, "index_schema", INDEX_SCHEMA)
    meta_set(conn, "worker_version", VERSION)
    meta_set(conn, "last_reset_ts", now_ts())
    conn.commit()


def cursor_key(name: str) -> str:
    return f"cursor:{name}"


def source_stat(path: Path) -> Dict[str, Any]:
    if not path.exists():
        return {"exists": False, "path": str(path), "inode": None, "size": 0, "mtime_ns": None}
    st = path.stat()
    return {
        "exists": True,
        "path": str(path),
        "inode": int(st.st_ino),
        "size": int(st.st_size),
        "mtime_ns": int(st.st_mtime_ns),
    }


def source_reset_needed(conn: sqlite3.Connection, paths: Mapping[str, Path]) -> Tuple[bool, List[str]]:
    reasons: List[str] = []
    for name in ("closed", "close", "poll"):
        path = paths[name]
        stat = source_stat(path)
        cursor = meta_get(conn, cursor_key(name), {}) or {}
        if not cursor or not stat.get("exists"):
            continue
        old_inode = cursor.get("inode")
        old_offset = integer(cursor.get("offset"), 0)
        if old_inode is not None and int(old_inode) != int(stat.get("inode")):
            reasons.append(f"{name}:inode_changed")
        if int(stat.get("size") or 0) < old_offset:
            reasons.append(f"{name}:size_shrank")
    return bool(reasons), reasons


def iter_new_jsonl(
    conn: sqlite3.Connection,
    name: str,
    path: Path,
) -> Iterator[Tuple[int, Dict[str, Any]]]:
    stat = source_stat(path)
    if not stat.get("exists"):
        return
    cursor = meta_get(conn, cursor_key(name), {}) or {}
    offset = integer(cursor.get("offset"), 0)
    line_no = integer(cursor.get("line_no"), 0)
    with path.open("rb") as handle:
        handle.seek(offset)
        data = handle.read()
    cut = data.rfind(b"\n")
    if cut < 0:
        complete = b""
        new_offset = offset
    else:
        complete = data[: cut + 1]
        new_offset = offset + cut + 1
    for raw in complete.splitlines():
        line_no += 1
        if not raw.strip():
            continue
        try:
            obj = json.loads(raw.decode("utf-8", errors="strict"))
        except Exception:
            bump_counter(conn, f"{name}_bad_json", 1)
            continue
        if not isinstance(obj, dict):
            bump_counter(conn, f"{name}_non_dict", 1)
            continue
        yield line_no, obj
    meta_set(conn, cursor_key(name), {
        "inode": stat.get("inode"),
        "offset": new_offset,
        "line_no": line_no,
        "size": stat.get("size"),
        "mtime_ns": stat.get("mtime_ns"),
        "updated_ts": now_ts(),
    })


def walk_sources(row: Mapping[str, Any], max_nodes: int = 64) -> List[Mapping[str, Any]]:
    if not isinstance(row, Mapping):
        return []
    keys = (
        "raw", "entry_context", "entry_diagnostics", "canonical_entry_snapshot",
        "entry_evidence_v983", "closed_evidence_v983", "swing_entry_gate_v977",
        "ranked_top10_contract_v1206", "structure_contract_v1212",
        "dynamic_structure_plan_v1212", "v1211_structure_shadow_v1222",
        "profitability_entry_evidence_v1034", "paper_final_safety_diagnostics",
    )
    queue: List[Mapping[str, Any]] = [row]
    out: List[Mapping[str, Any]] = []
    seen: set[int] = set()
    while queue and len(out) < max_nodes:
        obj = queue.pop(0)
        if not isinstance(obj, Mapping) or id(obj) in seen:
            continue
        seen.add(id(obj))
        out.append(obj)
        for key in keys:
            value = obj.get(key)
            if isinstance(value, Mapping):
                queue.append(value)
    return out


def first_value(row: Mapping[str, Any], keys: Sequence[str]) -> Any:
    for src in walk_sources(row):
        for key in keys:
            value = src.get(key)
            if value not in (None, "", [], {}):
                return value
    return None


def line_price(obj: Any) -> Optional[float]:
    if not isinstance(obj, Mapping):
        return None
    for key in ("rounded_price", "raw_price", "price", "line_price", "value"):
        value = num(obj.get(key), None)
        if value is not None and value > 0:
            return value
    return None


def line_meta(obj: Any, default_source: str) -> Dict[str, Any]:
    if not isinstance(obj, Mapping):
        return {"price": None, "timeframe": None, "source": default_source}
    return {
        "price": line_price(obj),
        "timeframe": str(obj.get("tf") or obj.get("timeframe") or obj.get("source_tf") or "").strip() or None,
        "source": str(obj.get("source") or obj.get("line_source") or obj.get("method") or default_source).strip() or default_source,
    }


def find_named_mapping(row: Mapping[str, Any], name: str) -> Optional[Mapping[str, Any]]:
    for src in walk_sources(row):
        value = src.get(name)
        if isinstance(value, Mapping):
            return value
    return None


def _candidate_structure_plans(row: Mapping[str, Any], kind: str) -> List[Tuple[Mapping[str, Any], str, bool]]:
    plans: List[Tuple[Mapping[str, Any], str, bool]] = []
    if kind == "current":
        for name in ("dynamic_structure_plan_v1212", "structure_contract_v1212", "swing_structure_plan_v977", "entry_plan"):
            obj = find_named_mapping(row, name)
            if isinstance(obj, Mapping):
                plans.append((obj, name, True))
        gate = find_named_mapping(row, "swing_entry_gate_v977")
        if isinstance(gate, Mapping) and isinstance(gate.get("structure_plan"), Mapping):
            plans.append((gate.get("structure_plan"), "swing_entry_gate_v977.structure_plan", True))
    else:
        obj = find_named_mapping(row, "v1211_structure_shadow_v1222")
        if isinstance(obj, Mapping):
            plans.append((obj, "v1211_structure_shadow_v1222", obj.get("source_exact") is True))
    return plans


def structure_lines(row: Mapping[str, Any], kind: str) -> Dict[str, Any]:
    source_name = "OPEN 봉인 현재 구조선" if kind == "current" else "OPEN 봉인 v1211 구조선"
    selected: Mapping[str, Any] = {}
    selected_name = ""
    selected_exact = False
    for plan, name, exact in _candidate_structure_plans(row, kind):
        trigger = line_meta(plan.get("trigger"), source_name)
        invalid = line_meta(plan.get("invalid"), source_name)
        target = line_meta(plan.get("target"), source_name)
        inv = num(invalid.get("price"), None)
        trg = num(trigger.get("price"), None)
        tgt = num(target.get("price"), None)
        if inv and tgt and inv > 0 and tgt > inv:
            selected = plan
            selected_name = name
            selected_exact = exact
            if trg and inv < trg < tgt:
                break
    plan = selected if isinstance(selected, Mapping) else {}
    result = {
        "trigger": line_meta(plan.get("trigger"), source_name),
        "invalid": line_meta(plan.get("invalid"), source_name),
        "target": line_meta(plan.get("target"), source_name),
        "source_exact": bool(selected_exact and plan),
        "source_schema": str(plan.get("schema") or plan.get("version") or "").strip() or None,
        "source_path": selected_name or None,
    }
    inv = num(result["invalid"].get("price"), None)
    trg = num(result["trigger"].get("price"), None)
    tgt = num(result["target"].get("price"), None)
    result["valid_exit_lines"] = bool(inv and tgt and 0 < inv < tgt)
    result["valid_order"] = bool(inv and trg and tgt and 0 < inv < trg < tgt)
    return result


def extract_cost(row: Mapping[str, Any]) -> Dict[str, Any]:
    # Use only values sealed in OPEN/CLOSED. No current control fallback.
    explicit_total = first_value(row, (
        "fee_and_execution_cost_pct", "roundtrip_cost_pct", "total_cost_pct", "fee_slippage_cost_pct",
    ))
    configured_fee = first_value(row, ("configured_roundtrip_fee_pct_v983", "configured_roundtrip_fee_pct", "roundtrip_fee_pct"))
    paper_reference = first_value(row, ("paper_reference_cost_pct", "reference_total_cost_pct", "cost_slippage_pct"))
    total = num(explicit_total, None)
    basis = "SEALED_TOTAL_COST" if total is not None else "CONFIGURED_FEE_ONLY"
    if total is None:
        total = num(configured_fee, None)
    return {
        "cost_pct": total,
        "basis": basis if total is not None else "MISSING",
        "configured_fee_pct": num(configured_fee, None),
        "paper_reference_cost_pct": num(paper_reference, None),
        "policy": "same sealed cost is applied to both structures; paper-reference cost is shown separately unless it is explicitly sealed as total cost",
    }


def extract_closed_meta(row: Mapping[str, Any]) -> Dict[str, Any]:
    key = decision_key(row)
    opened = num(first_value(row, ("opened_at", "opened_ts", "open_ts", "entry_open_ts")), None)
    closed = num(first_value(row, ("closed_ts", "closed_at", "exit_ts", "close_ts", "exited_ts")), None)
    entry = num(first_value(row, ("entry_price", "open_price")), None)
    exit_price = num(first_value(row, ("exit_price", "close_price", "current_price")), None)
    net = num(first_value(row, ("net_after_configured_fee_pct_v983", "net_pct", "result_pct", "pnl_pct", "return_pct", "final_realized_pnl_pct")), None)
    gross = num(first_value(row, ("gross_pnl_pct_v983", "gross_pnl_pct", "price_change_pct")), None)
    mfe = num(first_value(row, ("mfe_pct_v983", "max_net_profit_pct", "net_peak_pct", "peak_pct", "max_profit_pct")), None)
    mae = num(first_value(row, ("mae_pct_v983", "max_net_loss_pct", "net_trough_pct", "trough_pct", "min_profit_pct")), None)
    giveback = num(first_value(row, ("giveback_pct_v983", "giveback_pct", "missed_profit_pct")), None)
    if giveback is None and mfe is not None and net is not None:
        giveback = max(0.0, mfe - net)
    hold = num(first_value(row, ("hold_sec", "holding_sec", "duration_sec")), None)
    if hold is None and opened is not None and closed is not None:
        hold = max(0.0, closed - opened)
    return {
        "decision_key": key,
        "ticker": normalize_ticker(first_value(row, ("ticker", "market", "symbol"))),
        "pos_id": str(first_value(row, ("pos_id", "paper_pos_id_v926", "event_id")) or ""),
        "opened_ts": opened,
        "closed_ts": closed,
        "entry_price": entry,
        "exit_price": exit_price,
        "exit_reason": str(first_value(row, ("exit_reason", "exit_rule", "close_reason")) or "").strip(),
        "net_pnl_pct": net,
        "gross_pnl_pct": gross,
        "mfe_pct": mfe,
        "mae_pct": mae,
        "giveback_pct": giveback,
        "hold_sec": hold,
        "closed_result_key": str(first_value(row, ("closed_result_key", "result_key")) or ""),
        "contract_digest": str(first_value(row, ("exit_replay_contract_digest_v1242",)) or ""),
        "structure_contract_version": str(first_value(row, ("structure_contract_version",)) or ""),
        "structure_contract_hash": str(first_value(row, ("structure_contract_hash",)) or ""),
        "current_lines": structure_lines(row, "current"),
        "previous_lines": structure_lines(row, "previous"),
        "cost": extract_cost(row),
        "sealed_first_target_touch_ts": num(first_value(row, ("first_target_touch_ts_v983", "target_first_touch_ts")), None),
        "sealed_first_invalid_touch_ts": num(first_value(row, ("first_invalid_touch_ts_v983", "invalid_first_touch_ts")), None),
        "source_row_digest": json_digest(row),
    }


def extract_open_meta_rows(path: Path) -> Dict[str, Dict[str, Any]]:
    obj = read_json(path, {}) or {}
    if isinstance(obj, Mapping) and isinstance(obj.get("positions"), Mapping):
        rows = obj.get("positions")
    elif isinstance(obj, Mapping) and isinstance(obj.get("open"), Mapping):
        rows = obj.get("open")
    else:
        rows = obj if isinstance(obj, Mapping) else {}
    out: Dict[str, Dict[str, Any]] = {}
    for value in rows.values() if isinstance(rows, Mapping) else []:
        if not isinstance(value, Mapping):
            continue
        key = decision_key(value)
        if not key:
            continue
        out[key] = extract_closed_meta(value)
    return out


def upsert_open_meta(conn: sqlite3.Connection, rows: Mapping[str, Dict[str, Any]]) -> None:
    for key, meta in rows.items():
        conn.execute(
            """INSERT INTO open_meta(decision_key,payload,updated_ts) VALUES(?,?,?)
               ON CONFLICT(decision_key) DO UPDATE SET payload=excluded.payload,updated_ts=excluded.updated_ts""",
            (key, json.dumps(meta, ensure_ascii=False, separators=(",", ":")), now_ts()),
        )


def ingest_closed(conn: sqlite3.Connection, paths: Mapping[str, Path]) -> int:
    added = 0
    for line_no, row in iter_new_jsonl(conn, "closed", paths["closed"]):
        key = decision_key(row)
        if not key:
            bump_counter(conn, "closed_missing_decision_key", 1)
            continue
        meta = extract_closed_meta(row)
        cur = conn.execute(
            """INSERT OR IGNORE INTO closed_event(
                   source_line,decision_key,closed_result_key,payload_digest,payload,inserted_ts
               ) VALUES(?,?,?,?,?,?)""",
            (
                line_no,
                key,
                str(meta.get("closed_result_key") or ""),
                str(meta.get("source_row_digest") or json_digest(meta)),
                json.dumps(meta, ensure_ascii=False, separators=(",", ":")),
                now_ts(),
            ),
        )
        if cur.rowcount:
            added += 1
    return added


def _truthy_bool(value: Any) -> bool:
    if value is True:
        return True
    if value is False or value is None:
        return False
    return str(value).strip().lower() in {"1", "true", "yes", "ok", "success"}


def close_link_identity(row: Mapping[str, Any]) -> Dict[str, Any]:
    return {
        "poll_key": str(row.get("poll_key") or "").strip(),
        "contract_digest": str(row.get("contract_digest") or "").strip(),
        "closed_result_key": str(row.get("closed_result_key") or "").strip(),
        "exit_reason": str(row.get("exit_reason") or "").strip(),
        "closed_ts": round(num(row.get("closed_ts"), 0.0) or 0.0, 6),
        "pnl_pct": round(num(row.get("pnl_pct"), 0.0) or 0.0, 6),
    }


def ingest_close_links(conn: sqlite3.Connection, paths: Mapping[str, Path]) -> int:
    added = 0
    for line_no, row in iter_new_jsonl(conn, "close", paths["close"]):
        key = clean_decision_key(row.get("decision_key"))
        if not key:
            bump_counter(conn, "close_link_missing_decision_key", 1)
            continue
        identity = close_link_identity(row)
        cur = conn.execute(
            """INSERT OR IGNORE INTO close_link_event(
                   source_line,decision_key,poll_key,closed_result_key,commit_ok,semantic_digest,payload,inserted_ts
               ) VALUES(?,?,?,?,?,?,?,?)""",
            (
                line_no,
                key,
                identity["poll_key"],
                identity["closed_result_key"],
                1 if _truthy_bool(row.get("commit_ok")) else 0,
                json_digest(identity),
                json.dumps(dict(row), ensure_ascii=False, separators=(",", ":")),
                now_ts(),
            ),
        )
        if cur.rowcount:
            added += 1
    return added


def poll_records_from_payload(payload: Mapping[str, Any]) -> Iterable[Mapping[str, Any]]:
    records = payload.get("records")
    if isinstance(records, list):
        for row in records:
            if isinstance(row, Mapping):
                yield row
        return
    if payload.get("k") or payload.get("poll_key"):
        yield payload


def ingest_polls(conn: sqlite3.Connection, paths: Mapping[str, Path]) -> int:
    added = 0
    for line_no, payload in iter_new_jsonl(conn, "poll", paths["poll"]):
        for record_index, row in enumerate(poll_records_from_payload(payload)):
            key = clean_decision_key(row.get("dk") or row.get("decision_key"))
            if not key:
                bump_counter(conn, "poll_missing_decision_key", 1)
                continue
            poll_key = str(row.get("k") or row.get("poll_key") or "").strip()
            if not poll_key:
                bump_counter(conn, "poll_missing_poll_key", 1)
                continue
            ts = num(row.get("ts"), None)
            payload_digest = json_digest(dict(row))
            cur = conn.execute(
                """INSERT OR IGNORE INTO poll_event(
                       source_line,record_index,decision_key,poll_key,ts,payload_digest,payload,inserted_ts
                   ) VALUES(?,?,?,?,?,?,?,?)""",
                (
                    line_no,
                    record_index,
                    key,
                    poll_key,
                    ts,
                    payload_digest,
                    json.dumps(dict(row), ensure_ascii=False, separators=(",", ":")),
                    now_ts(),
                ),
            )
            if cur.rowcount:
                added += 1
    return added


def decision_closed_map(path: Path) -> Dict[str, Mapping[str, Any]]:
    obj = read_json(path, {}) or {}
    records = obj.get("records") if isinstance(obj, Mapping) and isinstance(obj.get("records"), Mapping) else {}
    out: Dict[str, Mapping[str, Any]] = {}
    for key, value in records.items():
        if not isinstance(value, Mapping):
            continue
        clean = clean_decision_key(key or value.get("paper_decision_key_v926"))
        if clean and str(value.get("status") or "").upper() == "CLOSED":
            out[clean] = value
    return out


def payload_dict(text_value: str) -> Dict[str, Any]:
    try:
        obj = json.loads(text_value)
        return obj if isinstance(obj, dict) else {}
    except Exception:
        return {}


def same_number(a: Any, b: Any, relative_tol: float = 1e-8, absolute_tol: float = 1e-10) -> bool:
    av = num(a, None)
    bv = num(b, None)
    if av is None or bv is None:
        return av is None and bv is None
    return math.isclose(av, bv, rel_tol=relative_tol, abs_tol=absolute_tol)


def result_at(
    polls: Sequence[Dict[str, Any]],
    close_index: int,
    entry: float,
    cost: float,
    reason: str,
    close_state: str,
) -> Dict[str, Any]:
    used = polls[: close_index + 1]
    close = used[-1]
    price = num(close.get("pr"), None)
    ts = num(close.get("ts"), None)
    gross = ((price / entry) - 1.0) * 100.0 if price and entry > 0 else None
    computed_net = gross - cost if gross is not None else None
    # Paper sealed the live net/MFE/MAE state in every poll. Reuse that state
    # instead of reconstructing a path from sparse poll prices. The computed
    # value remains visible for audit and must agree within the poll rounding.
    poll_net = num(close.get("net"), None)
    net = poll_net if poll_net is not None else computed_net
    mfe = num(close.get("mfe"), None)
    mae = num(close.get("mae"), None)
    metric_basis = "PAPER_POLL_SEALED_STATE"
    if mfe is None or mae is None:
        prices = [num(row.get("pr"), None) for row in used]
        prices = [x for x in prices if x is not None and x > 0]
        if mfe is None:
            mfe = (((max(prices) / entry) - 1.0) * 100.0 - cost) if prices and entry > 0 else None
        if mae is None:
            mae = (((min(prices) / entry) - 1.0) * 100.0 - cost) if prices and entry > 0 else None
        metric_basis = "PAPER_POLL_STATE_WITH_PRICE_FALLBACK"
    giveback = max(0.0, mfe - net) if mfe is not None and net is not None else None
    opened = num(close.get("ot"), None)
    age_min = num(close.get("age"), None)
    hold_sec = max(0.0, ts - opened) if ts is not None and opened is not None else (max(0.0, age_min * 60.0) if age_min is not None else None)
    return {
        "state": close_state,
        "close_poll_key": str(close.get("k") or ""),
        "close_ts": ts,
        "close_price": price,
        "exit_reason": reason,
        "gross_pnl_pct": round(gross, 6) if gross is not None else None,
        "cost_pct": round(cost, 6),
        "net_pnl_pct": round(net, 6) if net is not None else None,
        "computed_net_pnl_pct": round(computed_net, 6) if computed_net is not None else None,
        "poll_net_difference_pct": round(net - computed_net, 6) if net is not None and computed_net is not None else None,
        "mfe_pct": round(mfe, 6) if mfe is not None else None,
        "mae_pct": round(mae, 6) if mae is not None else None,
        "giveback_pct": round(giveback, 6) if giveback is not None else None,
        "hold_sec": round(hold_sec, 3) if hold_sec is not None else None,
        "metric_basis": metric_basis,
        "big_loss": bool(net is not None and net <= BIG_LOSS_THRESHOLD_PCT),
        "profit_then_loss": bool(mfe is not None and mfe > 0 and net is not None and net < 0),
        "poll_count_to_close": len(used),
    }


def first_line_touch(polls: Sequence[Dict[str, Any]], invalid: float, target: float, stop_index: Optional[int] = None) -> Tuple[Optional[int], Optional[str]]:
    end = len(polls) if stop_index is None else min(len(polls), stop_index + 1)
    for idx, row in enumerate(polls[:end]):
        price = num(row.get("pr"), None)
        if price is None:
            continue
        if price <= invalid:
            return idx, "INVALID"
        if price >= target:
            return idx, "TARGET"
    return None, None


def first_touch_ts(polls: Sequence[Dict[str, Any]], price_level: Optional[float], direction: str) -> Optional[float]:
    if price_level is None or price_level <= 0:
        return None
    for row in polls:
        price = num(row.get("pr"), None)
        if price is None:
            continue
        if direction == "up" and price >= price_level:
            return num(row.get("ts"), None)
        if direction == "down" and price <= price_level:
            return num(row.get("ts"), None)
    return None


def compare_line_to_poll(meta_line: Mapping[str, Any], poll_value: Any) -> str:
    sealed = num(meta_line.get("price"), None)
    observed = num(poll_value, None)
    if sealed is None or observed is None:
        return "MISSING"
    return "MATCH" if same_number(sealed, observed, relative_tol=1e-7) else "MISMATCH"


def _event_payloads(rows: Sequence[sqlite3.Row]) -> List[Dict[str, Any]]:
    out: List[Dict[str, Any]] = []
    for row in rows:
        payload = payload_dict(row["payload"])
        payload["_event_id"] = integer(row["id"], 0)
        payload["_source_line"] = integer(row["source_line"], 0)
        if "semantic_digest" in row.keys():
            payload["_semantic_digest"] = str(row["semantic_digest"] or "")
        if "payload_digest" in row.keys():
            payload["_payload_digest"] = str(row["payload_digest"] or "")
        out.append(payload)
    return out


def select_close_link(rows: Sequence[sqlite3.Row]) -> Tuple[Optional[Dict[str, Any]], Dict[str, Any], List[str], List[str]]:
    events = _event_payloads(rows)
    success = [row for row in events if _truthy_bool(row.get("commit_ok"))]
    failed = [row for row in events if not _truthy_bool(row.get("commit_ok"))]
    issues: List[str] = []
    warnings: List[str] = []
    groups: Dict[str, List[Dict[str, Any]]] = defaultdict(list)
    for row in success:
        digest = str(row.get("_semantic_digest") or json_digest(close_link_identity(row)))
        groups[digest].append(row)
    selected: Optional[Dict[str, Any]] = None
    if len(groups) > 1:
        issues.append("CONFLICTING_SUCCESS_CLOSE_LINKS")
    elif len(groups) == 1:
        selected = max(next(iter(groups.values())), key=lambda row: integer(row.get("_event_id"), 0))
        if len(next(iter(groups.values()))) > 1:
            warnings.append("DUPLICATE_IDENTICAL_SUCCESS_CLOSE_LINKS")
    elif failed:
        warnings.append("CLOSE_LINK_FAILURE_ONLY")
    failed_poll_keys = sorted({str(row.get("poll_key") or "").strip() for row in failed if str(row.get("poll_key") or "").strip()})
    audit = {
        "event_count": len(events),
        "success_event_count": len(success),
        "failure_event_count": len(failed),
        "success_identity_count": len(groups),
        "failed_poll_keys": failed_poll_keys,
        "selected_source_line": selected.get("_source_line") if selected else None,
        "selected_poll_key": selected.get("poll_key") if selected else None,
    }
    return selected, audit, issues, warnings


def select_closed_row(rows: Sequence[sqlite3.Row], link: Optional[Mapping[str, Any]]) -> Tuple[Optional[Dict[str, Any]], Dict[str, Any], List[str], List[str]]:
    events = _event_payloads(rows)
    issues: List[str] = []
    warnings: List[str] = []
    wanted_result = str((link or {}).get("closed_result_key") or "").strip()
    candidates = events
    if wanted_result:
        candidates = [row for row in events if str(row.get("closed_result_key") or "").strip() == wanted_result]
        if not candidates:
            issues.append("CLOSED_RESULT_KEY_NOT_FOUND")
    groups: Dict[str, List[Dict[str, Any]]] = defaultdict(list)
    for row in candidates:
        digest = str(row.get("_payload_digest") or row.get("source_row_digest") or json_digest(row))
        groups[digest].append(row)
    selected: Optional[Dict[str, Any]] = None
    if len(groups) > 1:
        issues.append("CONFLICTING_CLOSED_ROWS")
    elif len(groups) == 1:
        selected = max(next(iter(groups.values())), key=lambda row: integer(row.get("_event_id"), 0))
        if len(next(iter(groups.values()))) > 1:
            warnings.append("DUPLICATE_IDENTICAL_CLOSED_ROWS")
    elif not issues:
        issues.append("CLOSED_ROW_MISSING")
    if selected is not None and len(events) > len(candidates):
        warnings.append("OTHER_CLOSED_ROWS_SAME_DECISION_KEY")
    audit = {
        "event_count": len(events),
        "candidate_count": len(candidates),
        "semantic_identity_count": len(groups),
        "wanted_closed_result_key": wanted_result or None,
        "selected_source_line": selected.get("_source_line") if selected else None,
    }
    return selected, audit, issues, warnings


def select_poll_sequence(
    rows: Sequence[sqlite3.Row],
    link: Optional[Mapping[str, Any]],
    failed_poll_keys: Sequence[str],
) -> Tuple[List[Dict[str, Any]], Dict[str, Any], List[str], List[str]]:
    events = _event_payloads(rows)
    issues: List[str] = []
    warnings: List[str] = []
    linked_key = str((link or {}).get("poll_key") or "").strip()
    linked_digest = str((link or {}).get("contract_digest") or "").strip()
    if not linked_key:
        issues.append("LINKED_POLL_KEY_MISSING")
        return [], {"event_count": len(events)}, issues, warnings

    same_contract = events
    if linked_digest:
        same_contract = [row for row in events if str(row.get("cd") or "").strip() == linked_digest]
        if len(same_contract) < len(events):
            warnings.append("OTHER_CONTRACT_POLL_EVENTS_SAME_DECISION_KEY")
    if not same_contract:
        issues.append("POLL_SEQUENCE_MISSING_FOR_LINK_CONTRACT")
        return [], {"event_count": len(events), "same_contract_count": 0}, issues, warnings

    deduped: List[Dict[str, Any]] = []
    seen_exact: set[Tuple[str, str]] = set()
    poll_key_digests: Dict[str, set[str]] = defaultdict(set)
    duplicate_exact = 0
    for row in same_contract:
        pkey = str(row.get("k") or row.get("poll_key") or "").strip()
        pdigest = str(row.get("_payload_digest") or json_digest({k: v for k, v in row.items() if not str(k).startswith("_")}))
        poll_key_digests[pkey].add(pdigest)
        token = (pkey, pdigest)
        if token in seen_exact:
            duplicate_exact += 1
            continue
        seen_exact.add(token)
        deduped.append(row)
    conflicting_keys = sorted(key for key, values in poll_key_digests.items() if len(values) > 1)
    if conflicting_keys:
        issues.append("CONFLICTING_POLL_KEY_PAYLOADS")
    if duplicate_exact:
        warnings.append("DUPLICATE_IDENTICAL_POLL_EVENTS")

    linked_indexes = [idx for idx, row in enumerate(deduped) if str(row.get("k") or row.get("poll_key") or "").strip() == linked_key]
    if not linked_indexes:
        issues.append("LINKED_POLL_NOT_FOUND")
        return deduped, {
            "event_count": len(events), "same_contract_count": len(same_contract),
            "deduped_count": len(deduped), "duplicate_exact_count": duplicate_exact,
            "conflicting_poll_keys": conflicting_keys,
        }, issues, warnings
    if len(linked_indexes) > 1:
        issues.append("LINKED_POLL_DUPLICATE_CONFLICT")
        return deduped, {
            "event_count": len(events), "same_contract_count": len(same_contract),
            "deduped_count": len(deduped), "duplicate_exact_count": duplicate_exact,
            "conflicting_poll_keys": conflicting_keys,
        }, issues, warnings

    linked_index = linked_indexes[0]
    relevant = deduped[: linked_index + 1]
    last_ts: Optional[float] = None
    for row in relevant:
        value = num(row.get("ts"), None)
        if value is None:
            warnings.append("POLL_TS_MISSING")
            continue
        if last_ts is not None and value < last_ts:
            issues.append("POLL_TS_REVERSED")
            break
        last_ts = value

    failed_set = set(failed_poll_keys)
    earlier_close_keys = [
        str(row.get("k") or "").strip()
        for row in relevant[:-1]
        if str(row.get("a") or "").lower() == "close"
    ]
    unlinked_earlier = [key for key in earlier_close_keys if key not in failed_set]
    if unlinked_earlier:
        issues.append("UNLINKED_EARLIER_CLOSE_ACTION")
    elif earlier_close_keys:
        warnings.append("FAILED_CLOSE_RETRY_BEFORE_SUCCESS")

    audit = {
        "event_count": len(events),
        "same_contract_count": len(same_contract),
        "deduped_count": len(deduped),
        "relevant_count": len(relevant),
        "duplicate_exact_count": duplicate_exact,
        "conflicting_poll_keys": conflicting_keys,
        "linked_index": linked_index,
        "linked_poll_key": linked_key,
        "earlier_close_keys": earlier_close_keys,
    }
    return relevant, audit, issues, warnings


def _stable_poll_line(polls: Sequence[Mapping[str, Any]], key: str) -> Tuple[Optional[float], str]:
    values = {round(float(value), 12) for value in (num(row.get(key), None) for row in polls) if value is not None and value > 0}
    if not values:
        return None, "MISSING"
    if len(values) > 1:
        return None, "CHANGED"
    return next(iter(values)), "STABLE"


def _poll_backed_current_lines(meta_lines: Mapping[str, Any], polls: Sequence[Mapping[str, Any]], entry: Optional[float]) -> Dict[str, Any]:
    invalid, invalid_state = _stable_poll_line(polls, "iv")
    target, target_state = _stable_poll_line(polls, "tg")
    base = dict(meta_lines) if isinstance(meta_lines, Mapping) else {}
    trigger = base.get("trigger") if isinstance(base.get("trigger"), Mapping) else {"price": None, "source": "not required for Paper exit replay"}
    if invalid is not None and target is not None:
        result = {
            "trigger": trigger,
            "invalid": {"price": invalid, "timeframe": None, "source": "Paper poll 봉인값"},
            "target": {"price": target, "timeframe": None, "source": "Paper poll 봉인값"},
            "source_exact": True,
            "source_schema": "paper_exit_replay_poll_v1242",
            "source_path": "poll.iv/tg",
            "valid_exit_lines": bool(0 < invalid < target),
            "valid_order": bool(entry and 0 < invalid < entry < target),
            "poll_invalid_state": invalid_state,
            "poll_target_state": target_state,
        }
        return result
    base["poll_invalid_state"] = invalid_state
    base["poll_target_state"] = target_state
    return base


def replay_one(
    key: str,
    meta: Mapping[str, Any],
    link: Mapping[str, Any],
    polls: Sequence[Dict[str, Any]],
    decision_closed: bool,
    audit: Mapping[str, Any],
    initial_issues: Sequence[str] = (),
    initial_warnings: Sequence[str] = (),
) -> Dict[str, Any]:
    issues: List[str] = list(initial_issues)
    warnings: List[str] = list(initial_warnings)
    if not decision_closed:
        issues.append("DECISION_STATE_NOT_CLOSED")
    if not _truthy_bool(link.get("commit_ok")):
        issues.append("CLOSE_COMMIT_NOT_OK")
    if not polls:
        issues.append("POLL_SEQUENCE_MISSING")

    linked_key = str(link.get("poll_key") or "").strip()
    linked_index = len(polls) - 1 if polls and str(polls[-1].get("k") or "").strip() == linked_key else None
    if linked_index is None:
        issues.append("LINKED_POLL_NOT_LAST_RELEVANT_EVENT")
    linked_poll: Dict[str, Any] = polls[linked_index] if linked_index is not None else {}

    digests = {str(row.get("cd") or "").strip() for row in polls if str(row.get("cd") or "").strip()}
    link_digest = str(link.get("contract_digest") or "").strip()
    meta_digest = str(meta.get("contract_digest") or "").strip()
    if len(digests) > 1:
        issues.append("MULTIPLE_POLL_CONTRACT_DIGESTS")
    poll_digest = next(iter(digests), "")
    if not poll_digest:
        issues.append("POLL_CONTRACT_DIGEST_MISSING")
    if link_digest and poll_digest and link_digest != poll_digest:
        issues.append("LINK_CONTRACT_DIGEST_MISMATCH")
    if meta_digest and poll_digest and meta_digest != poll_digest:
        issues.append("CLOSED_CONTRACT_DIGEST_MISMATCH")
    if not meta_digest:
        warnings.append("CLOSED_CONTRACT_DIGEST_MISSING")

    entries = {round(float(value), 12) for value in (num(row.get("en"), None) for row in polls) if value is not None}
    opened_values = {round(float(value), 6) for value in (num(row.get("ot"), None) for row in polls) if value is not None}
    if len(entries) > 1:
        issues.append("ENTRY_PRICE_CHANGED_IN_POLL_SEQUENCE")
    if len(opened_values) > 1:
        issues.append("OPENED_TS_CHANGED_IN_POLL_SEQUENCE")
    entry = num(meta.get("entry_price"), None)
    if entry is None and len(entries) == 1:
        entry = next(iter(entries))
    if entry is None or entry <= 0:
        issues.append("ENTRY_PRICE_MISSING")
    elif entries and not all(same_number(entry, value, relative_tol=1e-8) for value in entries):
        issues.append("CLOSED_ENTRY_PRICE_MISMATCH")

    actual_reason = str(meta.get("exit_reason") or link.get("exit_reason") or linked_poll.get("r") or "").strip()
    link_reason = str(link.get("exit_reason") or "").strip()
    poll_reason = str(linked_poll.get("r") or "").strip()
    if actual_reason and link_reason and actual_reason != link_reason:
        issues.append("CLOSED_LINK_REASON_MISMATCH")
    if actual_reason and poll_reason and actual_reason != poll_reason:
        issues.append("CLOSED_POLL_REASON_MISMATCH")
    if linked_poll and str(linked_poll.get("a") or "").lower() != "close":
        issues.append("LINKED_POLL_ACTION_NOT_CLOSE")

    actual_exit_price = num(meta.get("exit_price"), None)
    actual_closed_ts = num(meta.get("closed_ts"), None)
    actual_net = num(meta.get("net_pnl_pct"), None)
    if actual_exit_price is None:
        issues.append("CLOSED_EXIT_PRICE_MISSING")
    if actual_closed_ts is None:
        issues.append("CLOSED_TS_MISSING")
    if actual_net is None:
        issues.append("CLOSED_NET_MISSING")

    linked_price = num(linked_poll.get("pr"), None)
    linked_ts = num(linked_poll.get("ts"), None)
    link_closed_ts = num(link.get("closed_ts"), None)
    if actual_exit_price is not None and linked_price is not None and not same_number(actual_exit_price, linked_price, relative_tol=1e-7):
        warnings.append("POLL_DECISION_PRICE_DIFFERS_FROM_EXECUTED_CLOSE")
    if actual_closed_ts is not None and linked_ts is not None and abs(actual_closed_ts - linked_ts) > 5.0:
        warnings.append("CLOSED_TS_DIFF_GT_5S")
    if actual_closed_ts is not None and link_closed_ts is not None and abs(actual_closed_ts - link_closed_ts) > 5.0:
        warnings.append("CLOSED_LINK_TS_DIFF_GT_5S")
    linked_net = num(linked_poll.get("net"), None)
    link_net = num(link.get("pnl_pct"), None)
    if actual_net is not None and linked_net is not None and abs(actual_net - linked_net) > 0.03:
        warnings.append("POLL_DECISION_NET_DIFFERS_FROM_CANONICAL_CLOSED")
    if actual_net is not None and link_net is not None and abs(actual_net - link_net) > 0.03:
        issues.append("CLOSED_LINK_NET_MISMATCH")

    closed_result_key = str(meta.get("closed_result_key") or "").strip()
    link_result_key = str(link.get("closed_result_key") or "").strip()
    if closed_result_key and link_result_key and closed_result_key != link_result_key:
        issues.append("CLOSED_RESULT_KEY_MISMATCH")

    current_meta_lines = meta.get("current_lines") if isinstance(meta.get("current_lines"), Mapping) else {}
    current_lines = _poll_backed_current_lines(current_meta_lines, polls, entry)
    previous_lines = meta.get("previous_lines") if isinstance(meta.get("previous_lines"), Mapping) else {}
    current_invalid = num(((current_lines.get("invalid") or {}).get("price") if isinstance(current_lines.get("invalid"), Mapping) else None), None)
    current_target = num(((current_lines.get("target") or {}).get("price") if isinstance(current_lines.get("target"), Mapping) else None), None)
    previous_invalid = num(((previous_lines.get("invalid") or {}).get("price") if isinstance(previous_lines.get("invalid"), Mapping) else None), None)
    previous_target = num(((previous_lines.get("target") or {}).get("price") if isinstance(previous_lines.get("target"), Mapping) else None), None)
    previous_valid = bool(
        previous_lines.get("source_exact") is True
        and previous_invalid and previous_target and entry
        and 0 < previous_invalid < entry < previous_target
    )
    if not current_lines.get("valid_exit_lines"):
        warnings.append("CURRENT_STRUCTURE_LINES_UNAVAILABLE_FOR_LINE_ONLY_ARM")
    if not previous_valid:
        warnings.append("PREVIOUS_STRUCTURE_LINES_NOT_EXACT")

    if current_meta_lines.get("valid_exit_lines"):
        invalid_match = compare_line_to_poll(current_meta_lines.get("invalid") or {}, linked_poll.get("iv"))
        target_match = compare_line_to_poll(current_meta_lines.get("target") or {}, linked_poll.get("tg"))
        if "MISMATCH" in (invalid_match, target_match):
            warnings.append("CLOSED_ROW_STRUCTURE_COPY_DIFFERS_FROM_POLL_SEALED_LINES")
    else:
        invalid_match = target_match = "POLL_SOURCE_USED"

    cost_obj = meta.get("cost") if isinstance(meta.get("cost"), Mapping) else {}
    cost = num(cost_obj.get("cost_pct"), 0.0) or 0.0
    if num(cost_obj.get("cost_pct"), None) is None:
        warnings.append("SEALED_COST_MISSING_POLL_NET_USED")
    implied_costs: List[float] = []
    for row in polls:
        price_value = num(row.get("pr"), None)
        entry_value = num(row.get("en"), None)
        net_value = num(row.get("net"), None)
        if price_value is None or entry_value is None or entry_value <= 0 or net_value is None:
            continue
        implied_costs.append(((price_value / entry_value) - 1.0) * 100.0 - net_value)
    if implied_costs:
        if max(implied_costs) - min(implied_costs) > 0.03:
            warnings.append("POLL_IMPLIED_COST_CHANGED")
        if num(cost_obj.get("cost_pct"), None) is not None and abs(sum(implied_costs) / len(implied_costs) - cost) > 0.03:
            warnings.append("SEALED_COST_DIFFERS_FROM_POLL_IMPLIED_COST")

    poll_structure_versions = {str(row.get("scv") or "").strip() for row in polls if str(row.get("scv") or "").strip()}
    poll_structure_hashes = {str(row.get("sch") or "").strip() for row in polls if str(row.get("sch") or "").strip()}
    if len(poll_structure_versions) > 1:
        issues.append("POLL_STRUCTURE_VERSION_CHANGED")
    if len(poll_structure_hashes) > 1:
        issues.append("POLL_STRUCTURE_HASH_CHANGED")

    actual_mfe = num(meta.get("mfe_pct"), None)
    actual_mae = num(meta.get("mae_pct"), None)
    actual_giveback = num(meta.get("giveback_pct"), None)
    actual_hold = num(meta.get("hold_sec"), None)
    if actual_mfe is None:
        warnings.append("CLOSED_MFE_MISSING")
    if actual_mae is None:
        warnings.append("CLOSED_MAE_MISSING")
    if actual_giveback is None:
        warnings.append("CLOSED_GIVEBACK_MISSING")
    if actual_hold is None:
        warnings.append("CLOSED_HOLD_TIME_MISSING")

    fatal = bool(issues)
    current_actual: Optional[Dict[str, Any]] = None
    current_line_only: Optional[Dict[str, Any]] = None
    previous_line_only: Optional[Dict[str, Any]] = None
    previous_same_paper: Optional[Dict[str, Any]] = None

    if not fatal and linked_index is not None and entry is not None:
        current_actual = {
            "state": "EXACT_OBSERVED_PAPER_CLOSE",
            "close_poll_key": linked_key,
            "close_ts": actual_closed_ts,
            "decision_poll_ts": linked_ts,
            "close_price": actual_exit_price,
            "decision_poll_price": linked_price,
            "exit_reason": actual_reason,
            "gross_pnl_pct": meta.get("gross_pnl_pct"),
            "cost_pct": cost_obj.get("cost_pct"),
            "net_pnl_pct": actual_net,
            "mfe_pct": actual_mfe,
            "mae_pct": actual_mae,
            "giveback_pct": actual_giveback,
            "hold_sec": actual_hold,
            "big_loss": bool(actual_net is not None and actual_net <= BIG_LOSS_THRESHOLD_PCT),
            "profit_then_loss": bool(actual_mfe is not None and actual_mfe > 0 and actual_net is not None and actual_net < 0),
            "poll_count_to_close": linked_index + 1,
            "metric_basis": "CANONICAL_CLOSED_WITH_LINKED_PAPER_DECISION_POLL",
        }
        if current_invalid is not None and current_target is not None:
            idx, reason = first_line_touch(polls, current_invalid, current_target, linked_index)
            if idx is not None and reason is not None:
                current_line_only = result_at(polls, idx, entry, cost, reason, "EXACT_POLL_LINE_TOUCH")
        if previous_valid and previous_invalid is not None and previous_target is not None:
            idx, reason = first_line_touch(polls, previous_invalid, previous_target, linked_index)
            if idx is not None and reason is not None:
                previous_line_only = result_at(polls, idx, entry, cost, reason, "EXACT_POLL_LINE_TOUCH")
                previous_same_paper = dict(previous_line_only)
                previous_same_paper["state"] = "EXACT_PREVIOUS_LINE_CLOSED_BEFORE_OR_AT_ACTUAL_PAPER_CLOSE"
            elif actual_reason in TRANSFERABLE_POLICY_REASONS:
                previous_same_paper = dict(current_actual)
                previous_same_paper["state"] = "EXACT_SAME_CANONICAL_PAPER_CLOSE_TRANSFERRED"
                previous_same_paper["transfer_basis"] = "exit reason independent of current target/invalid"
            elif actual_reason in STRUCTURE_DEPENDENT_REASONS:
                previous_same_paper = {
                    "state": "CENSORED_AT_CURRENT_STRUCTURE_CLOSE",
                    "reason": "현재 구조선으로 Paper가 종료되어 이후 이전 구조선 경로는 관측되지 않음",
                    "observed_until_ts": linked_ts,
                    "observed_until_poll_key": linked_key,
                }
            elif actual_reason in NON_STRATEGY_REASONS:
                previous_same_paper = {
                    "state": "EXCLUDED_NON_STRATEGY_CLOSE",
                    "reason": actual_reason,
                    "observed_until_ts": linked_ts,
                }
            else:
                previous_same_paper = {
                    "state": "CHECK_UNCLASSIFIED_EXIT_REASON",
                    "reason": actual_reason or "missing",
                    "observed_until_ts": linked_ts,
                }

    if fatal:
        replay_state = "AMBIGUOUS" if any(
            token in issue for issue in issues
            for token in ("CONFLICT", "MISMATCH", "MULTIPLE", "REVERSED", "UNLINKED_EARLIER", "DUPLICATE_CONFLICT")
        ) else "NOT_REPLAYABLE"
    elif not previous_valid:
        replay_state = "PARTIAL_CURRENT_EXACT_PREVIOUS_STRUCTURE_MISSING"
    elif previous_same_paper and str(previous_same_paper.get("state") or "").startswith("EXACT"):
        replay_state = "EXACT_REPLAYABLE"
    elif previous_same_paper and str(previous_same_paper.get("state") or "").startswith("CENSORED"):
        replay_state = "PARTIAL_CURRENT_EXACT_PREVIOUS_CENSORED"
    else:
        replay_state = "PARTIAL_CURRENT_EXACT"

    current_net = num((current_actual or {}).get("net_pnl_pct"), None)
    previous_net = num((previous_same_paper or {}).get("net_pnl_pct"), None)
    delta = previous_net - current_net if current_net is not None and previous_net is not None else None
    return {
        "schema": "paper_exact_replay_trade_v1250",
        "decision_key": key,
        "ticker": meta.get("ticker"),
        "pos_id": meta.get("pos_id"),
        "scope": "CAPTURED_SUCCESS_LINK",
        "replay_state": replay_state,
        "issues": sorted(set(issues)),
        "warnings": sorted(set(warnings)),
        "source_contract": {
            "join_key": "OPEN-time direct decision key only",
            "poll_count": len(polls),
            "first_poll_ts": num(polls[0].get("ts"), None) if polls else None,
            "last_poll_ts": num(polls[-1].get("ts"), None) if polls else None,
            "linked_poll_key": linked_key or None,
            "contract_digest": poll_digest or None,
            "closed_result_key": closed_result_key or None,
            "decision_state_closed": decision_closed,
            "selection_audit": dict(audit),
        },
        "same_entry_contract": {
            "entry_price": entry,
            "opened_ts": meta.get("opened_ts"),
            "cost": cost_obj,
            "entry_stable_in_polls": len(entries) <= 1,
            "opened_ts_stable_in_polls": len(opened_values) <= 1,
        },
        "structure_lines": {
            "current": current_lines,
            "previous": previous_lines,
            "current_line_poll_match": {"invalid": invalid_match, "target": target_match},
        },
        "first_observed_touch": {
            "current_target_ts": first_touch_ts(polls, current_target, "up"),
            "current_invalid_ts": first_touch_ts(polls, current_invalid, "down"),
            "previous_target_ts": first_touch_ts(polls, previous_target, "up"),
            "previous_invalid_ts": first_touch_ts(polls, previous_invalid, "down"),
            "actual_exit_ts": linked_ts,
            "touch_granularity": "Paper poll observed time; not exchange tick time",
        },
        "arms": {
            "current_structure_actual_paper": current_actual,
            "previous_structure_same_paper": previous_same_paper,
            "current_structure_line_only": current_line_only,
            "previous_structure_line_only": previous_line_only,
        },
        "comparison": {
            "previous_minus_current_net_pct": round(delta, 6) if delta is not None else None,
            "winner": ("previous" if delta is not None and delta > 0 else "current" if delta is not None and delta < 0 else "tie" if delta == 0 else "NOT_COMPARABLE"),
            "winner_is_research_only": True,
        },
        "actual_exit_changed": False,
        "actual_entry_changed": False,
        "existing_open_changed": False,
        "auto_buy": False,
        "generated_ts": now_ts(),
    }


def unresolved_replay_result(
    key: str,
    state: str,
    issues: Sequence[str],
    warnings: Sequence[str],
    meta: Optional[Mapping[str, Any]] = None,
    link: Optional[Mapping[str, Any]] = None,
    audit: Optional[Mapping[str, Any]] = None,
    decision_closed: bool = False,
) -> Dict[str, Any]:
    meta = meta if isinstance(meta, Mapping) else {}
    link = link if isinstance(link, Mapping) else {}
    scope = "HISTORICAL_PRE_CAPTURE" if state == "HISTORICAL_NOT_REPLAYABLE" else "CAPTURE_FAILURE_ONLY" if state == "CAPTURE_FAIL_ONLY" else "CAPTURED_SUCCESS_LINK"
    return {
        "schema": "paper_exact_replay_trade_v1250",
        "decision_key": key,
        "ticker": meta.get("ticker") or link.get("ticker"),
        "pos_id": meta.get("pos_id") or link.get("pos_id"),
        "scope": scope,
        "replay_state": state,
        "issues": sorted(set(issues)),
        "warnings": sorted(set(warnings)),
        "source_contract": {
            "join_key": "OPEN-time direct decision key only",
            "poll_count": 0,
            "linked_poll_key": link.get("poll_key") if link else None,
            "contract_digest": link.get("contract_digest") if link else meta.get("contract_digest"),
            "closed_result_key": link.get("closed_result_key") if link else meta.get("closed_result_key"),
            "decision_state_closed": decision_closed,
            "selection_audit": dict(audit or {}),
        },
        "same_entry_contract": {
            "entry_price": meta.get("entry_price"),
            "opened_ts": meta.get("opened_ts"),
            "cost": meta.get("cost") if isinstance(meta.get("cost"), Mapping) else {},
        },
        "structure_lines": {
            "current": meta.get("current_lines") if isinstance(meta.get("current_lines"), Mapping) else {},
            "previous": meta.get("previous_lines") if isinstance(meta.get("previous_lines"), Mapping) else {},
        },
        "first_observed_touch": {},
        "arms": {
            "current_structure_actual_paper": None,
            "previous_structure_same_paper": None,
            "current_structure_line_only": None,
            "previous_structure_line_only": None,
        },
        "comparison": {"previous_minus_current_net_pct": None, "winner": "NOT_COMPARABLE", "winner_is_research_only": True},
        "actual_exit_changed": False,
        "actual_entry_changed": False,
        "existing_open_changed": False,
        "auto_buy": False,
        "generated_ts": now_ts(),
    }


def reconcile(conn: sqlite3.Connection, decision_map: Mapping[str, Mapping[str, Any]]) -> int:
    updated = 0
    keys = [
        row["decision_key"]
        for row in conn.execute(
            """SELECT decision_key FROM close_link_event
               UNION
               SELECT decision_key FROM closed_event
               ORDER BY decision_key"""
        )
    ]
    for key in keys:
        closed_rows = conn.execute("SELECT * FROM closed_event WHERE decision_key=? ORDER BY id", (key,)).fetchall()
        link_rows = conn.execute("SELECT * FROM close_link_event WHERE decision_key=? ORDER BY id", (key,)).fetchall()
        poll_rows = conn.execute("SELECT * FROM poll_event WHERE decision_key=? ORDER BY id", (key,)).fetchall()
        decision_closed = key in decision_map

        if not link_rows:
            selected_meta, closed_audit, closed_issues, closed_warnings = select_closed_row(closed_rows, None)
            result = unresolved_replay_result(
                key,
                "HISTORICAL_NOT_REPLAYABLE",
                ["PRE_CAPTURE_NO_CLOSE_LINK"],
                closed_warnings,
                selected_meta,
                None,
                {"closed": closed_audit, "close_link": {"event_count": 0}, "poll": {"event_count": len(poll_rows)}},
                decision_closed,
            )
        else:
            selected_link, link_audit, link_issues, link_warnings = select_close_link(link_rows)
            if selected_link is None:
                selected_meta, closed_audit, closed_issues, closed_warnings = select_closed_row(closed_rows, None)
                state = "AMBIGUOUS" if link_issues else "CAPTURE_FAIL_ONLY"
                issues = list(link_issues) + (["NO_SUCCESSFUL_CLOSE_LINK"] if not link_issues else [])
                result = unresolved_replay_result(
                    key,
                    state,
                    issues,
                    list(link_warnings) + list(closed_warnings),
                    selected_meta,
                    None,
                    {"closed": closed_audit, "close_link": link_audit, "poll": {"event_count": len(poll_rows)}},
                    decision_closed,
                )
            else:
                selected_meta, closed_audit, closed_issues, closed_warnings = select_closed_row(closed_rows, selected_link)
                polls, poll_audit, poll_issues, poll_warnings = select_poll_sequence(
                    poll_rows, selected_link, link_audit.get("failed_poll_keys") or []
                )
                audit = {"closed": closed_audit, "close_link": link_audit, "poll": poll_audit}
                initial_issues = list(link_issues) + list(closed_issues) + list(poll_issues)
                initial_warnings = list(link_warnings) + list(closed_warnings) + list(poll_warnings)
                if selected_meta is None:
                    result = unresolved_replay_result(
                        key, "AMBIGUOUS" if initial_issues else "NOT_REPLAYABLE",
                        initial_issues or ["CLOSED_ROW_MISSING"], initial_warnings,
                        None, selected_link, audit, decision_closed,
                    )
                else:
                    result = replay_one(
                        key, selected_meta, selected_link, polls, decision_closed, audit,
                        initial_issues=initial_issues, initial_warnings=initial_warnings,
                    )
        conn.execute(
            """INSERT INTO replay_result(decision_key,payload,replay_state,updated_ts) VALUES(?,?,?,?)
               ON CONFLICT(decision_key) DO UPDATE SET payload=excluded.payload,replay_state=excluded.replay_state,updated_ts=excluded.updated_ts""",
            (key, json.dumps(result, ensure_ascii=False, separators=(",", ":")), result["replay_state"], now_ts()),
        )
        updated += 1
    return updated


def metric(rows: Sequence[Mapping[str, Any]], arm_name: str) -> Dict[str, Any]:
    arm_rows: List[Mapping[str, Any]] = []
    for row in rows:
        arms = row.get("arms") if isinstance(row.get("arms"), Mapping) else {}
        arm = arms.get(arm_name) if isinstance(arms.get(arm_name), Mapping) else None
        if arm and num(arm.get("net_pnl_pct"), None) is not None:
            arm_rows.append(arm)
    values = [float(arm["net_pnl_pct"]) for arm in arm_rows]
    wins = sum(1 for value in values if value > 0)
    def avg(field: str) -> Optional[float]:
        vals = [float(value) for value in (num(arm.get(field), None) for arm in arm_rows) if value is not None]
        return round(sum(vals) / len(vals), 6) if vals else None
    total = sum(values)
    return {
        "n": len(values),
        "wins": wins,
        "losses": len(values) - wins,
        "win_rate": round(wins / len(values) * 100.0, 3) if values else None,
        "total_net_pct": round(total, 6),
        "avg_net_pct": round(total / len(values), 6) if values else None,
        "avg_mfe_pct": avg("mfe_pct"),
        "avg_mae_pct": avg("mae_pct"),
        "avg_giveback_pct": avg("giveback_pct"),
        "avg_hold_sec": avg("hold_sec"),
        "big_loss_count": sum(1 for arm in arm_rows if arm.get("big_loss") is True),
        "profit_then_loss_count": sum(1 for arm in arm_rows if arm.get("profit_then_loss") is True),
    }


def build_snapshot(conn: sqlite3.Connection, paths: Mapping[str, Path], ingestion: Mapping[str, int], started: float) -> Dict[str, Any]:
    result_rows = [payload_dict(row["payload"]) for row in conn.execute("SELECT payload FROM replay_result ORDER BY updated_ts,decision_key")]
    state_counts = Counter(str(row.get("replay_state") or "CHECK") for row in result_rows)
    issue_counts: Counter[str] = Counter()
    warning_counts: Counter[str] = Counter()
    for row in result_rows:
        issue_counts.update(str(x) for x in (row.get("issues") or []))
        warning_counts.update(str(x) for x in (row.get("warnings") or []))

    exact_rows = [row for row in result_rows if row.get("replay_state") == "EXACT_REPLAYABLE"]
    current_exact_rows = [
        row for row in result_rows
        if isinstance(((row.get("arms") or {}).get("current_structure_actual_paper")), Mapping)
    ]
    active_rows = [row for row in result_rows if row.get("scope") == "CAPTURED_SUCCESS_LINK"]
    active_unresolved = [row for row in active_rows if not isinstance(((row.get("arms") or {}).get("current_structure_actual_paper")), Mapping)]
    historical_rows = [row for row in result_rows if row.get("replay_state") == "HISTORICAL_NOT_REPLAYABLE"]
    fail_only_rows = [row for row in result_rows if row.get("replay_state") == "CAPTURE_FAIL_ONLY"]

    source = {name: source_stat(path) for name, path in paths.items()}
    paper_status = read_json(paths["paper_status"], {}) or {}
    poll_decisions = integer(conn.execute("SELECT COUNT(DISTINCT decision_key) AS n FROM poll_event").fetchone()["n"], 0)
    poll_events = integer(conn.execute("SELECT COUNT(*) AS n FROM poll_event").fetchone()["n"], 0)
    closed_events = integer(conn.execute("SELECT COUNT(*) AS n FROM closed_event").fetchone()["n"], 0)
    closed_decisions = integer(conn.execute("SELECT COUNT(DISTINCT decision_key) AS n FROM closed_event").fetchone()["n"], 0)
    link_events = integer(conn.execute("SELECT COUNT(*) AS n FROM close_link_event").fetchone()["n"], 0)
    link_success_events = integer(conn.execute("SELECT COUNT(*) AS n FROM close_link_event WHERE commit_ok=1").fetchone()["n"], 0)
    link_failure_events = integer(conn.execute("SELECT COUNT(*) AS n FROM close_link_event WHERE commit_ok=0").fetchone()["n"], 0)
    success_decisions = integer(conn.execute("SELECT COUNT(DISTINCT decision_key) AS n FROM close_link_event WHERE commit_ok=1").fetchone()["n"], 0)
    fail_only_decisions = integer(conn.execute(
        """SELECT COUNT(*) AS n FROM (
               SELECT decision_key FROM close_link_event GROUP BY decision_key
               HAVING SUM(CASE WHEN commit_ok=1 THEN 1 ELSE 0 END)=0
           )"""
    ).fetchone()["n"], 0)
    closed_without_any_link = integer(conn.execute(
        """SELECT COUNT(*) AS n FROM (
               SELECT DISTINCT c.decision_key FROM closed_event c
               LEFT JOIN close_link_event l ON l.decision_key=c.decision_key
               WHERE l.decision_key IS NULL
           )"""
    ).fetchone()["n"], 0)
    success_link_without_closed = integer(conn.execute(
        """SELECT COUNT(*) AS n FROM (
               SELECT DISTINCT l.decision_key FROM close_link_event l
               LEFT JOIN closed_event c ON c.decision_key=l.decision_key
               WHERE l.commit_ok=1 AND c.decision_key IS NULL
           )"""
    ).fetchone()["n"], 0)

    if not source["poll"].get("exists"):
        state = "CHECK_POLL_LEDGER_MISSING"
    elif success_decisions <= 0:
        state = "COLLECTING_WAITING_SUCCESSFUL_CLOSE"
    elif not current_exact_rows:
        state = "CHECK_SUCCESS_LINKS_BLOCKED"
    elif exact_rows:
        state = "NORMAL_EXACT_SAMPLE_AVAILABLE"
    else:
        state = "NORMAL_CURRENT_EXACT_COLLECTING_PAIR"

    recent_active = sorted(active_rows, key=lambda row: num(row.get("generated_ts"), 0.0) or 0.0)[-20:]
    snapshot = {
        "schema": SNAPSHOT_SCHEMA,
        "version": VERSION,
        "build": BUILD_LABEL,
        "mode": "SHADOW_ONLY_READ_ONLY",
        "state": state,
        "generated_ts": now_ts(),
        "generated_text": now_text(),
        "cycle_elapsed_sec": round(now_ts() - started, 6),
        "source_owner": {
            "poll": "Paper paper_exit_replay_poll_v1242.jsonl",
            "close_link": "Paper paper_exit_replay_close_v1242.jsonl",
            "closed": "Paper paper_bot_closed.jsonl",
            "decision": "Paper paper_decision_state_v926.json",
            "join": "OPEN-time direct decision key only",
            "selection": "latest successful semantic close-link identity; failed retries remain audit-only",
        },
        "source_files": source,
        "source_status_v1242": {
            "state": paper_status.get("state"),
            "poll_records": paper_status.get("poll_records"),
            "close_commit_ok": paper_status.get("close_commit_ok"),
            "close_commit_fail": paper_status.get("close_commit_fail"),
            "evidence_append_failures": paper_status.get("evidence_append_failures"),
        },
        "counts": {
            "closed_events_indexed": closed_events,
            "closed_decisions_indexed": closed_decisions,
            "close_link_events_indexed": link_events,
            "close_link_success_events": link_success_events,
            "close_link_failure_events": link_failure_events,
            "successful_close_decisions": success_decisions,
            "fail_only_close_decisions": fail_only_decisions,
            "historical_closed_without_capture": closed_without_any_link,
            "success_link_without_closed": success_link_without_closed,
            "poll_events_indexed": poll_events,
            "poll_decisions_indexed": poll_decisions,
            "replay_results": len(result_rows),
            "active_replay_candidates": len(active_rows),
            "current_actual_exact": len(current_exact_rows),
            "complete_current_previous_exact": len(exact_rows),
            "active_unresolved": len(active_unresolved),
            "historical_not_replayable": len(historical_rows),
            "capture_fail_only": len(fail_only_rows),
            "state_counts": dict(state_counts),
            "issue_counts": dict(issue_counts),
            "warning_counts": dict(warning_counts),
            **counters(conn),
        },
        "ingestion_this_cycle": dict(ingestion),
        "metrics": {
            "current_structure_actual_paper": metric(current_exact_rows, "current_structure_actual_paper"),
            "previous_structure_same_paper_exact_only": metric(exact_rows, "previous_structure_same_paper"),
            "current_structure_line_only": metric(result_rows, "current_structure_line_only"),
            "previous_structure_line_only": metric(result_rows, "previous_structure_line_only"),
        },
        "comparability": {
            "winner_allowed": False,
            "reason": "exact sample collection continues; user approval is required before any live application",
            "exact_pair_rows": len(exact_rows),
            "current_exact_rows": len(current_exact_rows),
            "censored_rows": state_counts.get("PARTIAL_CURRENT_EXACT_PREVIOUS_CENSORED", 0),
            "missing_previous_structure_rows": state_counts.get("PARTIAL_CURRENT_EXACT_PREVIOUS_STRUCTURE_MISSING", 0),
        },
        "diagnostics": {
            "active_block_reason_counts": dict(Counter(
                issue for row in active_unresolved for issue in (row.get("issues") or [])
            )),
            "historical_rows_are_not_active_failures": True,
            "failed_close_links_are_not_selected_as_canonical": True,
            "identical_retry_duplicates_are_audit_warnings": True,
        },
        "recent_results": recent_active,
        "rows": result_rows,
        "invariants": {
            "paper_writer_changed": False,
            "review_writer_changed": False,
            "strategy_writer_changed": False,
            "actual_s1_changed": False,
            "actual_entry_changed": False,
            "actual_exit_changed": False,
            "existing_open_changed": False,
            "current_values_used_for_history": False,
            "ticker_pos_time_join_used": False,
            "missing_hidden_as_zero": False,
            "auto_buy": False,
        },
    }
    snapshot["snapshot_id"] = hashlib.sha256(json.dumps({
        "schema": snapshot["schema"],
        "generated_ts": snapshot["generated_ts"],
        "counts": snapshot["counts"],
        "source": {name: {"inode": row.get("inode"), "size": row.get("size"), "mtime_ns": row.get("mtime_ns")} for name, row in source.items()},
    }, sort_keys=True, separators=(",", ":")).encode("utf-8")).hexdigest()[:24]
    return snapshot


def write_status(base: Path, state: str, **updates: Any) -> Dict[str, Any]:
    paths = output_paths(base)
    prior = read_json(paths["status"], {}) or {}
    status = dict(prior) if isinstance(prior, dict) else {}
    status.update({
        "schema": STATUS_SCHEMA,
        "version": VERSION,
        "build": BUILD_LABEL,
        "state": state,
        "pid": os.getpid(),
        "updated_ts": now_ts(),
        "updated_text": now_text(),
        "auto_buy": False,
        "actual_entry_changed": False,
        "actual_exit_changed": False,
    })
    status.update(updates)
    atomic_write_json(paths["status"], status)
    return status


def process_once(base: Path, rebuild: bool = False) -> Dict[str, Any]:
    started = now_ts()
    paths = source_paths(base)
    outs = output_paths(base)
    conn = open_db(outs["index"])
    try:
        if rebuild:
            reset_index(conn)
        reset_needed, reset_reasons = source_reset_needed(conn, paths)
        if reset_needed:
            reset_index(conn)
            bump_counter(conn, "source_reset_rebuild", 1)
            meta_set(conn, "last_source_reset_reasons", reset_reasons)

        open_rows = extract_open_meta_rows(paths["open"])
        upsert_open_meta(conn, open_rows)
        ingestion = {
            "closed_added": ingest_closed(conn, paths),
            "close_links_added": ingest_close_links(conn, paths),
            "poll_records_added": ingest_polls(conn, paths),
            "open_meta_seen": len(open_rows),
        }
        decision_map = decision_closed_map(paths["decision"])
        ingestion["results_rebuilt"] = reconcile(conn, decision_map)
        conn.commit()
        snapshot = build_snapshot(conn, paths, ingestion, started)
        atomic_write_json(outs["snapshot"], snapshot)
        status = write_status(
            base,
            "running",
            health_state=snapshot.get("state"),
            snapshot_id=snapshot.get("snapshot_id"),
            replay_results=((snapshot.get("counts") or {}).get("replay_results")),
            current_actual_exact=((snapshot.get("counts") or {}).get("current_actual_exact")),
            complete_pair_exact=((snapshot.get("counts") or {}).get("complete_current_previous_exact")),
            active_unresolved=((snapshot.get("counts") or {}).get("active_unresolved")),
            historical_not_replayable=((snapshot.get("counts") or {}).get("historical_not_replayable")),
            successful_close_decisions=((snapshot.get("counts") or {}).get("successful_close_decisions")),
            active_block_reason_counts=((snapshot.get("diagnostics") or {}).get("active_block_reason_counts")),
            poll_records_total=((snapshot.get("source_status_v1242") or {}).get("poll_records")),
            last_sec=round(now_ts() - started, 6),
            last_error="",
        )
        return {"ok": True, "snapshot": snapshot, "status": status}
    finally:
        conn.close()


def run_loop(base: Path, interval_sec: float) -> int:
    acquire_singleton(base)
    atexit.register(release_singleton)
    signal.signal(signal.SIGTERM, signal_handler)
    signal.signal(signal.SIGINT, signal_handler)
    write_status(base, "running", health_state="STARTING", last_error="")
    while not _STOP:
        try:
            process_once(base)
        except Exception as exc:
            log_error(base, "process_once", exc)
            write_status(base, "running", health_state="ERROR", last_error=f"{type(exc).__name__}: {exc}")
        slept = 0.0
        while slept < interval_sec and not _STOP:
            step = min(0.2, interval_sec - slept)
            time.sleep(step)
            slept += step
    write_status(base, "stopped", health_state="STOPPED", last_error="")
    return 0


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--base-dir", default="")
    parser.add_argument("--interval", type=float, default=DEFAULT_INTERVAL_SEC)
    parser.add_argument("--once", action="store_true")
    parser.add_argument("--rebuild", action="store_true")
    args = parser.parse_args()
    base = Path(args.base_dir).expanduser().resolve() if args.base_dir else base_dir()
    if args.once:
        result = process_once(base, rebuild=args.rebuild)
        print(json.dumps({
            "ok": result.get("ok"),
            "state": ((result.get("snapshot") or {}).get("state")),
            "counts": ((result.get("snapshot") or {}).get("counts")),
        }, ensure_ascii=False, separators=(",", ":")))
        return 0
    return run_loop(base, max(1.0, args.interval))


if __name__ == "__main__":
    raise SystemExit(main())
