#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Coinbot policy competition worker v0.1 / v1251.

Read-only SHADOW_ONLY policy board.  It imports the active Review model owner
instead of copying probability/quality formulas, freezes one committed Strategy
generation, and lets seven policy arms compete with the same candidate event,
entry price, entry time and execution cost.

It never changes Strategy candidates, Paper OPEN/CLOSED, live exit rules, or
existing OPEN contracts.
"""
from __future__ import annotations

import argparse
import atexit
import fcntl
import hashlib
import importlib
import inspect
import json
import math
import os
import signal
import sys
import time
import traceback
from collections import Counter
from pathlib import Path
from typing import Any, Dict, Iterable, List, Mapping, Optional, Sequence, Tuple

VERSION = "policy_competition_worker_v0.2"
BUILD_LABEL = "v1252_policy_direct_decision_owner_contract_repair_2026-07-05"
STATE_SCHEMA = "policy_competition_state_v1251"
SNAPSHOT_SCHEMA = "canonical_policy_competition_v1251"
STATUS_SCHEMA = "policy_competition_worker_status_v1251"
EVENT_SCHEMA = "policy_competition_event_v1251"
DEFAULT_INTERVAL_SEC = 3.0
RETENTION_SEC = 24.0 * 3600.0
OPEN_CAP_PER_POLICY = 10
NEW_PER_GENERATION = 2
TIMEOUT_SEC = RETENTION_SEC

POLICY_IDS: Tuple[str, ...] = (
    "current_method",
    "v1211_quality",
    "expected_ev",
    "conservative_ev",
    "time_axis_exit",
    "fast_profit_protect",
    "hybrid_exit",
)
SELECTION_POLICIES = {
    "current_method", "v1211_quality", "expected_ev", "conservative_ev"
}
EXIT_VARIANT_POLICIES = {
    "current_method", "time_axis_exit", "fast_profit_protect", "hybrid_exit"
}
POLICY_LABELS = {
    "current_method": "현재 방식",
    "v1211_quality": "v1211 품질 중심",
    "expected_ev": "확률형 기대값",
    "conservative_ev": "보수적 기대값",
    "time_axis_exit": "시간축 청산",
    "fast_profit_protect": "빠른 수익보호",
    "hybrid_exit": "혼합 청산",
}

_STOP = False
_LOCK_HANDLE: Optional[Any] = None
_REVIEW_MODULE: Optional[Any] = None


def now_ts() -> float:
    return time.time()


def now_text(ts: Optional[float] = None) -> str:
    from datetime import datetime, timezone, timedelta
    kst = timezone(timedelta(hours=9))
    return datetime.fromtimestamp(float(ts if ts is not None else now_ts()), kst).strftime("%Y-%m-%d %H:%M:%S KST")


def base_dir() -> Path:
    raw = os.getenv("COINBOT_BASE_DIR", "").strip()
    return Path(raw).expanduser().resolve() if raw else Path(__file__).resolve().parent


def state_path(base: Path) -> Path:
    return base / "policy_competition_state_v1251.json"


def snapshot_path(base: Path) -> Path:
    return base / "canonical_policy_competition_v1251.json"


def status_path(base: Path) -> Path:
    return base / "clean_policy_competition_worker_status.json"


def event_path(base: Path) -> Path:
    return base / "policy_competition_events_v1251.jsonl"


def lock_path(base: Path) -> Path:
    return base / ".policy_competition_worker.lock"


def pid_path(base: Path) -> Path:
    return base / "clean_policy_competition_worker.pid"


def error_path(base: Path) -> Path:
    return base / "clean_policy_competition_worker_error.log"


def finite(value: Any) -> Optional[float]:
    try:
        out = float(value)
        if math.isfinite(out):
            return out
    except (TypeError, ValueError, OverflowError):
        pass
    return None


def integer(value: Any, default: int = 0) -> int:
    try:
        return int(value)
    except (TypeError, ValueError, OverflowError):
        return default


def read_json(path: Path, default: Any = None) -> Any:
    try:
        with path.open("r", encoding="utf-8") as handle:
            return json.load(handle)
    except (OSError, json.JSONDecodeError, TypeError, ValueError):
        return default


def atomic_write_json(path: Path, payload: Any) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    raw = json.dumps(payload, ensure_ascii=False, sort_keys=True, separators=(",", ":"))
    tmp = path.with_name(f".{path.name}.{os.getpid()}.{time.time_ns()}.tmp")
    with tmp.open("w", encoding="utf-8") as handle:
        handle.write(raw)
        handle.flush()
        os.fsync(handle.fileno())
    os.replace(tmp, path)
    try:
        dfd = os.open(str(path.parent), os.O_DIRECTORY)
        try:
            os.fsync(dfd)
        finally:
            os.close(dfd)
    except OSError:
        pass


def append_jsonl(path: Path, payload: Mapping[str, Any]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    raw = json.dumps(dict(payload), ensure_ascii=False, sort_keys=True, separators=(",", ":")) + "\n"
    with path.open("a", encoding="utf-8") as handle:
        fcntl.flock(handle.fileno(), fcntl.LOCK_EX)
        handle.write(raw)
        handle.flush()
        os.fsync(handle.fileno())
        fcntl.flock(handle.fileno(), fcntl.LOCK_UN)


def sha256_text(text: str) -> str:
    return hashlib.sha256(text.encode("utf-8")).hexdigest()


def stable_price(value: Any) -> str:
    out = finite(value)
    return f"{out:.12g}" if out is not None else "missing"


def load_review_owner() -> Any:
    global _REVIEW_MODULE
    if _REVIEW_MODULE is not None:
        return _REVIEW_MODULE
    module = importlib.import_module("review_worker")
    required = (
        "_v1241_stable_committed_rows", "_v1241_request_generation",
        "_v1236_prepare", "_v1236_estimate", "_v1234_quality_replay",
        "_v1236_line", "_v1236_line_price", "_v1233_ticker", "_v1233_price",
        "_v1237_cost", "_v1237_strength_snapshot", "_v1237_update_arm",
        "read_candidate_rows", "SpinePaths", "read_json", "stage",
    )
    missing = [name for name in required if not hasattr(module, name)]
    if missing:
        raise RuntimeError("Review model owner contract missing: " + ",".join(missing))
    _REVIEW_MODULE = module
    return module


def review_contract_digest(review: Any) -> str:
    names = (
        "_v1236_features", "_v1236_similarity", "_v1236_outcome",
        "_v1236_estimate", "_v1236_profile", "_v1234_quality_replay",
        "_v1237_update_arm",
    )
    chunks = [str(getattr(review, "VERSION", "")), str(getattr(review, "BUILD_LABEL", ""))]
    for name in names:
        obj = getattr(review, name, None)
        try:
            chunks.append(inspect.getsource(obj))
        except (OSError, TypeError):
            chunks.append(repr(obj))
    return sha256_text("\n".join(chunks))


def source_decision_identity(row: Mapping[str, Any]) -> Tuple[str, str]:
    """Read the exact Strategy/Paper direct-decision owner contract.

    Production ALT_SWING rows seal the direct decision primarily in
    swing_gate_decision_key_v977 (or the same key inside the sealed gate).
    Candidate/build keys are deliberately not accepted as a substitute.
    """
    direct_fields = (
        "swing_gate_decision_key_v977",
        "direct_decision_key",
        "entry_decision_key",
        "candidate_decision_key",
        "decision_key",
        "strategy_decision_key",
    )
    for key in direct_fields:
        value = str(row.get(key) or "").strip()
        if value:
            return value, key
    containers = (
        ("canonical_entry_decision", ("decision_key", "direct_decision_key")),
        ("swing_entry_gate_v977", ("decision_key", "direct_decision_key")),
        ("direct_decision", ("decision_key", "direct_decision_key")),
        ("entry_decision", ("decision_key", "direct_decision_key")),
    )
    for container_key, child_keys in containers:
        obj = row.get(container_key)
        if not isinstance(obj, Mapping):
            continue
        for child_key in child_keys:
            value = str(obj.get(child_key) or "").strip()
            if value:
                return value, f"{container_key}.{child_key}"
    return "", "missing"


def source_decision_key(row: Mapping[str, Any]) -> str:
    return source_decision_identity(row)[0]


def is_observation_only(row: Mapping[str, Any]) -> bool:
    if any(row.get(key) is True for key in (
        "current_cycle_observation_only_v1215", "observation_open_forbidden_v988",
        "observation_only_candidate_v988", "s3_observation_only_v988", "s3_review_only_v988",
    )):
        return True
    role = str(row.get("candidate_role_v1215") or row.get("current_candidate_role") or row.get("source_role") or "").lower()
    return role in {"observation_only", "review_only", "alert_only"}


def current_lines(review: Any, row: Mapping[str, Any]) -> Optional[Dict[str, float]]:
    trigger = review._v1236_line(dict(row), "trigger")
    invalid = review._v1236_line(dict(row), "invalid")
    target = review._v1236_line(dict(row), "target")
    values = {
        "trigger": review._v1236_line_price(trigger),
        "invalid": review._v1236_line_price(invalid),
        "target": review._v1236_line_price(target),
    }
    if any(finite(values[name]) is None for name in values):
        return None
    out = {name: float(values[name]) for name in values}
    if not (0 < out["invalid"] < out["trigger"] < out["target"]):
        return None
    return out


def current_history_rows(perf: Mapping[str, Any]) -> List[Dict[str, Any]]:
    import re
    out: List[Dict[str, Any]] = []
    for raw_row in perf.get("rows") or []:
        if not isinstance(raw_row, dict):
            continue
        raw = str(raw_row.get("structure_contract_version") or "").strip()
        match = re.search(r"structure_contract_v(\d+)", raw) if raw else None
        if match and int(match.group(1)) > 1211:
            out.append(raw_row)
    return out


def candidate_event_id(ticker: str, decision_key: str, lines: Mapping[str, float]) -> str:
    signature = "|".join((
        ticker, decision_key,
        stable_price(lines.get("trigger")), stable_price(lines.get("invalid")), stable_price(lines.get("target")),
    ))
    return sha256_text(signature)[:28]


def policy_decision_key(event_id: str, policy_id: str, generation_key: str) -> str:
    return "policy-" + sha256_text(f"{event_id}|{policy_id}|{generation_key}")[:28]


def policy_rank_value(policy_id: str, record: Mapping[str, Any]) -> Optional[float]:
    if policy_id in {"current_method", "time_axis_exit", "fast_profit_protect", "hybrid_exit"}:
        return finite(record.get("current_score"))
    if policy_id == "v1211_quality":
        return finite(record.get("quality_score"))
    if policy_id == "expected_ev":
        return finite(record.get("expected_ev_pct"))
    if policy_id == "conservative_ev":
        return finite(record.get("conservative_ev_pct"))
    return None


def policy_gate(policy_id: str, record: Mapping[str, Any]) -> Tuple[bool, str]:
    value = policy_rank_value(policy_id, record)
    if value is None:
        return False, "score_missing"
    if policy_id == "v1211_quality" and record.get("quality_would_pass") is not True:
        return False, "v1211_quality_gate_fail"
    if policy_id == "expected_ev" and value <= 0:
        return False, "expected_ev_not_positive"
    if policy_id == "conservative_ev" and value <= 0:
        return False, "conservative_ev_not_positive"
    return True, "entry_eligible"


def build_candidate_records(
    review: Any,
    rows: Sequence[Dict[str, Any]],
    prepared_history: Sequence[Dict[str, Any]],
    generated_ts: float,
) -> Tuple[List[Dict[str, Any]], Dict[str, int]]:
    records: List[Dict[str, Any]] = []
    skipped = Counter()
    for row in rows:
        stage = str(review.stage(row) or "").upper()
        if stage != "S1":
            skipped["not_s1"] += 1
            continue
        if is_observation_only(row):
            skipped["observation_only"] += 1
            continue
        decision_key, decision_key_owner = source_decision_identity(row)
        if not decision_key:
            skipped["decision_key_missing"] += 1
            continue
        ticker = str(review._v1233_ticker(row) or "").strip().upper()
        price = finite(review._v1233_price(row))
        lines = current_lines(review, row)
        if not ticker:
            skipped["ticker_missing"] += 1
            continue
        if price is None or price <= 0:
            skipped["price_missing"] += 1
            continue
        if lines is None:
            skipped["structure_missing"] += 1
            continue
        if price <= lines["invalid"] or price >= lines["target"]:
            skipped["entry_outside_contract"] += 1
            continue
        quality = review._v1234_quality_replay(row)
        model = review._v1236_estimate(row, list(prepared_history), generated_ts)
        record = {
            "ticker": ticker,
            "source_decision_key": decision_key,
            "source_decision_key_owner": decision_key_owner,
            "entry_price": price,
            "cost_pct": max(0.0, float(review._v1237_cost(row))),
            "lines": lines,
            "current_score": finite(row.get("global_entry_score_v1212") or row.get("rank_score") or row.get("score")),
            "quality_score": finite(quality.get("score")),
            "quality_would_pass": quality.get("would_pass") is True,
            "quality_reasons": list(quality.get("reasons") or []),
            "expected_ev_pct": finite(model.get("expected_net_pct")),
            "conservative_ev_pct": finite(model.get("conservative_ev_pct")),
            "confidence": finite(model.get("confidence")),
            "model_state": str(model.get("state") or "CHECK"),
            "profile": str(model.get("profile") or "balanced"),
            "exit_policy": dict(model.get("exit_policy") or {}),
            "p_win": finite(model.get("p_win")),
            "p_giveback": finite(model.get("p_giveback")),
            "p_tail_loss": finite(model.get("p_tail_loss")),
            "row": row,
        }
        record["event_id"] = candidate_event_id(ticker, decision_key, lines)
        records.append(record)
    return records, dict(skipped)


def empty_state(ts: float) -> Dict[str, Any]:
    return {
        "schema": STATE_SCHEMA,
        "version": VERSION,
        "created_ts": ts,
        "created_text": now_text(ts),
        "updated_ts": ts,
        "open": {},
        "closed": [],
        "processed_generations": {},
        "last_cycle": {},
        "event_append_errors": 0,
    }


def load_state(base: Path, ts: float) -> Dict[str, Any]:
    raw = read_json(state_path(base), {}) or {}
    if not isinstance(raw, dict) or raw.get("schema") != STATE_SCHEMA:
        return empty_state(ts)
    raw.setdefault("open", {})
    raw.setdefault("closed", [])
    raw.setdefault("processed_generations", {})
    raw.setdefault("event_append_errors", 0)
    return raw


def arm_template(policy_id: str, record: Mapping[str, Any], generation_key: str, ts: float, selected: bool, reason: str) -> Dict[str, Any]:
    lines = record.get("lines") or {}
    return {
        "policy_id": policy_id,
        "policy_label": POLICY_LABELS[policy_id],
        "policy_decision_key": policy_decision_key(str(record.get("event_id")), policy_id, generation_key),
        "selected": bool(selected),
        "selection_reason": reason,
        "rank_value": policy_rank_value(policy_id, record),
        "closed": False if selected else None,
        "opened_ts": ts if selected else None,
        "invalid_price": lines.get("invalid"),
        "target_price": lines.get("target"),
        "weak_streak": 0,
        "exit_mode": (
            "CURRENT_POLICY_OBSERVABLE_PROXY" if policy_id in SELECTION_POLICIES else
            "TIME_AXIS_SHADOW" if policy_id == "time_axis_exit" else
            "FAST_PROFIT_PROTECT_SHADOW" if policy_id == "fast_profit_protect" else
            "HYBRID_EXIT_SHADOW"
        ),
    }


def selected_policy_count(state: Mapping[str, Any], policy_id: str) -> int:
    count = 0
    for event in (state.get("open") or {}).values():
        if not isinstance(event, Mapping):
            continue
        arm = (event.get("arms") or {}).get(policy_id)
        if isinstance(arm, Mapping) and arm.get("selected") is True and arm.get("closed") is not True:
            count += 1
    return count


def open_tickers_for_policy(state: Mapping[str, Any], policy_id: str) -> set[str]:
    out: set[str] = set()
    for event in (state.get("open") or {}).values():
        if not isinstance(event, Mapping):
            continue
        arm = (event.get("arms") or {}).get(policy_id)
        if isinstance(arm, Mapping) and arm.get("selected") is True and arm.get("closed") is not True:
            ticker = str(event.get("ticker") or "")
            if ticker:
                out.add(ticker)
    return out


def all_seen_event_ids(state: Mapping[str, Any]) -> set[str]:
    out = set(str(key) for key in (state.get("open") or {}).keys())
    out.update(str(row.get("event_id") or "") for row in (state.get("closed") or []) if isinstance(row, Mapping))
    return {value for value in out if value}


def selection_plan(state: Mapping[str, Any], records: Sequence[Dict[str, Any]]) -> Tuple[Dict[str, List[str]], Dict[str, Any]]:
    selected: Dict[str, List[str]] = {policy: [] for policy in POLICY_IDS}
    audit: Dict[str, Any] = {}

    # Exit-policy arms must enter the exact same candidate events.  Use the
    # smallest free capacity and the union of their open tickers, then assign
    # one common current-score selection to all four arms.
    baseline_policies = ("current_method", "time_axis_exit", "fast_profit_protect", "hybrid_exit")
    baseline_ranked = sorted(
        records,
        key=lambda row: (
            policy_rank_value("current_method", row) if policy_rank_value("current_method", row) is not None else -1e100,
            finite(row.get("confidence")) or 0.0,
            str(row.get("ticker") or ""),
        ),
        reverse=True,
    )
    baseline_capacity = min(
        max(0, OPEN_CAP_PER_POLICY - selected_policy_count(state, policy))
        for policy in baseline_policies
    )
    baseline_limit = min(NEW_PER_GENERATION, baseline_capacity)
    baseline_open_tickers: set[str] = set()
    for policy in baseline_policies:
        baseline_open_tickers.update(open_tickers_for_policy(state, policy))
    baseline_reasons = Counter()
    baseline_list: List[str] = []
    for record in baseline_ranked:
        if len(baseline_list) >= baseline_limit:
            break
        gate_ok, gate_reason = policy_gate("current_method", record)
        if not gate_ok:
            baseline_reasons[gate_reason] += 1
            continue
        ticker = str(record.get("ticker") or "")
        if ticker in baseline_open_tickers:
            baseline_reasons["same_ticker_open_in_exit_board"] += 1
            continue
        baseline_list.append(str(record.get("event_id")))
        baseline_open_tickers.add(ticker)
    baseline_top = [
        {
            "ticker": record.get("ticker"),
            "rank_value": policy_rank_value("current_method", record),
            "entry_eligible": policy_gate("current_method", record)[0],
            "reason": policy_gate("current_method", record)[1],
        }
        for record in baseline_ranked[:10]
    ]
    for policy in baseline_policies:
        selected[policy] = list(baseline_list)
        audit[policy] = {
            "candidate_count": len(records),
            "open_before": selected_policy_count(state, policy),
            "capacity_before": max(0, OPEN_CAP_PER_POLICY - selected_policy_count(state, policy)),
            "shared_exit_board_capacity": baseline_capacity,
            "selected_new": len(baseline_list),
            "gate_or_skip_counts": dict(baseline_reasons),
            "observe_top": baseline_top,
            "same_selection_as_current_method": True,
        }

    # Entry-ranking policies use independent books but the same frozen S1 pool,
    # candidate price, timestamp and cost inside every event they select.
    for policy_id in ("v1211_quality", "expected_ev", "conservative_ev"):
        ranked = sorted(
            records,
            key=lambda row: (
                policy_rank_value(policy_id, row) if policy_rank_value(policy_id, row) is not None else -1e100,
                finite(row.get("confidence")) or 0.0,
                str(row.get("ticker") or ""),
            ),
            reverse=True,
        )
        capacity = max(0, OPEN_CAP_PER_POLICY - selected_policy_count(state, policy_id))
        limit = min(NEW_PER_GENERATION, capacity)
        open_tickers = open_tickers_for_policy(state, policy_id)
        reason_counts = Counter()
        observe_top = []
        for record in ranked[:10]:
            gate_ok, gate_reason = policy_gate(policy_id, record)
            observe_top.append({
                "ticker": record.get("ticker"),
                "rank_value": policy_rank_value(policy_id, record),
                "entry_eligible": gate_ok,
                "reason": gate_reason,
            })
        for record in ranked:
            if len(selected[policy_id]) >= limit:
                break
            gate_ok, gate_reason = policy_gate(policy_id, record)
            if not gate_ok:
                reason_counts[gate_reason] += 1
                continue
            ticker = str(record.get("ticker") or "")
            if ticker in open_tickers:
                reason_counts["same_ticker_open"] += 1
                continue
            selected[policy_id].append(str(record.get("event_id")))
            open_tickers.add(ticker)
        audit[policy_id] = {
            "candidate_count": len(records),
            "open_before": selected_policy_count(state, policy_id),
            "capacity_before": capacity,
            "selected_new": len(selected[policy_id]),
            "gate_or_skip_counts": dict(reason_counts),
            "observe_top": observe_top,
            "same_selection_as_current_method": False,
        }
    return selected, audit


def create_event(record: Mapping[str, Any], generation: Mapping[str, Any], selected: Mapping[str, Sequence[str]], ts: float) -> Dict[str, Any]:
    event_id = str(record.get("event_id") or "")
    generation_key = str(generation.get("generation_key") or "")
    arms: Dict[str, Any] = {}
    for policy_id in POLICY_IDS:
        is_selected = event_id in set(selected.get(policy_id) or [])
        gate_ok, gate_reason = policy_gate(policy_id, record)
        reason = "selected" if is_selected else (gate_reason if not gate_ok else "not_top_or_capacity")
        arms[policy_id] = arm_template(policy_id, record, generation_key, ts, is_selected, reason)
    return {
        "schema": "policy_candidate_event_v1251",
        "event_id": event_id,
        "ticker": record.get("ticker"),
        "source_decision_key": record.get("source_decision_key"),
        "source_decision_key_owner": record.get("source_decision_key_owner"),
        "candidate_cycle_id": generation.get("cycle_id"),
        "candidate_commit_id": generation.get("candidate_commit_id"),
        "candidate_generation_key": generation_key,
        "opened_ts": ts,
        "opened_text": now_text(ts),
        "entry_price": record.get("entry_price"),
        "last_price": record.get("entry_price"),
        "high_price": record.get("entry_price"),
        "low_price": record.get("entry_price"),
        "fee_and_execution_cost_pct": record.get("cost_pct"),
        "current_lines": dict(record.get("lines") or {}),
        "scores": {
            "current": record.get("current_score"),
            "v1211_quality": record.get("quality_score"),
            "expected_ev_pct": record.get("expected_ev_pct"),
            "conservative_ev_pct": record.get("conservative_ev_pct"),
            "confidence": record.get("confidence"),
        },
        "model": {
            "state": record.get("model_state"),
            "profile": record.get("profile"),
            "p_win": record.get("p_win"),
            "p_giveback": record.get("p_giveback"),
            "p_tail_loss": record.get("p_tail_loss"),
            "exit_policy": dict(record.get("exit_policy") or {}),
        },
        "arms": arms,
        "last_update_ts": ts,
    }


def append_event_safe(base: Path, state: Dict[str, Any], event_type: str, payload: Mapping[str, Any]) -> None:
    body = {
        "schema": EVENT_SCHEMA,
        "event_type": event_type,
        "created_ts": now_ts(),
        "created_text": now_text(),
        "version": VERSION,
        "mode": "SHADOW_ONLY",
        "auto_buy": False,
        **dict(payload),
    }
    try:
        append_jsonl(event_path(base), body)
    except Exception:
        state["event_append_errors"] = integer(state.get("event_append_errors")) + 1
        raise


def close_arm(base: Path, state: Dict[str, Any], event: Dict[str, Any], arm: Dict[str, Any], price: float, ts: float, reason: str) -> None:
    if arm.get("selected") is not True or arm.get("closed") is True:
        return
    entry = finite(event.get("entry_price")) or 0.0
    cost = finite(event.get("fee_and_execution_cost_pct")) or 0.0
    gross = ((price - entry) / entry * 100.0) if entry > 0 else 0.0
    high = finite(event.get("high_price")) or price
    low = finite(event.get("low_price")) or price
    mfe = ((high - entry) / entry * 100.0) if entry > 0 else 0.0
    mae = ((low - entry) / entry * 100.0) if entry > 0 else 0.0
    net = gross - cost
    arm.update({
        "closed": True,
        "closed_ts": ts,
        "closed_text": now_text(ts),
        "close_price": price,
        "exit_reason": reason,
        "gross_pnl_pct": gross,
        "net_pnl_pct": net,
        "mfe_pct": mfe,
        "mae_pct": mae,
        "giveback_pct": max(0.0, mfe - net),
        "hold_sec": max(0.0, ts - (finite(event.get("opened_ts")) or ts)),
        "big_loss": net <= -1.50,
        "profit_then_loss": mfe >= max(0.25, cost) and net <= 0.0,
    })
    append_event_safe(base, state, "POLICY_ARM_CLOSED", {
        "event_id": event.get("event_id"),
        "ticker": event.get("ticker"),
        "source_decision_key": event.get("source_decision_key"),
        "policy_id": arm.get("policy_id"),
        "policy_decision_key": arm.get("policy_decision_key"),
        "close_price": price,
        "net_pnl_pct": net,
        "exit_reason": reason,
    })


def update_custom_arm(base: Path, state: Dict[str, Any], review: Any, event: Dict[str, Any], arm: Dict[str, Any], row: Mapping[str, Any], price: float, ts: float) -> None:
    if arm.get("selected") is not True or arm.get("closed") is True:
        return
    invalid = finite(arm.get("invalid_price")) or 0.0
    target = finite(arm.get("target_price")) or 0.0
    if price <= invalid:
        close_arm(base, state, event, arm, price, ts, "INVALID")
        return
    if price >= target:
        close_arm(base, state, event, arm, price, ts, "TARGET")
        return
    entry = finite(event.get("entry_price")) or 0.0
    cost = finite(event.get("fee_and_execution_cost_pct")) or 0.0
    net = ((price - entry) / entry * 100.0 - cost) if entry > 0 else -cost
    high = finite(event.get("high_price")) or price
    peak = ((high - entry) / entry * 100.0 - cost) if entry > 0 else -cost
    giveback = max(0.0, peak - net)
    age_min = max(0.0, ts - (finite(event.get("opened_ts")) or ts)) / 60.0
    model = event.get("model") if isinstance(event.get("model"), Mapping) else {}
    policy = model.get("exit_policy") if isinstance(model.get("exit_policy"), Mapping) else {}
    no_progress = max(3.0, finite(policy.get("no_progress_review_min")) or 20.0)
    arm_level = max(cost + 0.15, finite(policy.get("profit_protect_arm_pct")) or 0.35)
    floor = max(0.02, finite(policy.get("profit_floor_pct")) or 0.03)
    strong, weak = review._v1237_strength_snapshot(dict(row))
    arm["weak_streak"] = integer(arm.get("weak_streak")) + 1 if weak >= 3 and weak > strong else 0
    arm["last_strength_count"] = strong
    arm["last_weakness_count"] = weak
    mode = str(arm.get("exit_mode") or "")
    if mode == "TIME_AXIS_SHADOW":
        recovery = max(0.25, cost)
        if age_min >= no_progress and peak < max(0.35, recovery + 0.10) and net <= max(0.05, floor):
            close_arm(base, state, event, arm, price, ts, "TIME_AXIS_NO_PROGRESS")
        return
    if mode == "FAST_PROFIT_PROTECT_SHADOW":
        if peak >= arm_level:
            protected_floor = max(floor, peak - max(0.25, peak * 0.35))
            if net <= protected_floor:
                close_arm(base, state, event, arm, price, ts, "FAST_PROFIT_PROTECT")
                return
        if peak >= max(0.25, cost) and net <= 0.0:
            close_arm(base, state, event, arm, price, ts, "FAST_RESPONSE_PROTECT")
        return
    if mode == "HYBRID_EXIT_SHADOW":
        if peak >= arm_level:
            protected_floor = max(floor, peak - max(0.30, peak * 0.42))
            if net <= protected_floor:
                close_arm(base, state, event, arm, price, ts, "HYBRID_PROFIT_PROTECT")
                return
        ratio = giveback / peak if peak > 0 else 0.0
        if integer(arm.get("weak_streak")) >= 2 and peak >= max(0.25, cost) and ratio >= 0.45:
            close_arm(base, state, event, arm, price, ts, "HYBRID_MOMENTUM_DECAY")
            return
        if peak >= max(0.25, cost) and net <= 0.0:
            close_arm(base, state, event, arm, price, ts, "HYBRID_RESPONSE_PROTECT")
            return
        if age_min >= no_progress and peak < max(0.45, arm_level) and net <= max(0.05, floor):
            close_arm(base, state, event, arm, price, ts, "HYBRID_TIME_NO_PROGRESS")


def update_open_events(base: Path, state: Dict[str, Any], review: Any, live_rows: Sequence[Dict[str, Any]], ts: float) -> None:
    rows_by_ticker = {str(review._v1233_ticker(row) or "").upper(): row for row in live_rows if review._v1233_ticker(row)}
    for event_id in list((state.get("open") or {}).keys()):
        event = state["open"].get(event_id)
        if not isinstance(event, dict):
            continue
        ticker = str(event.get("ticker") or "").upper()
        row = rows_by_ticker.get(ticker, {})
        price = finite(review._v1233_price(row)) if row else finite(event.get("last_price"))
        if price is None or price <= 0:
            continue
        event["last_price"] = price
        event["last_update_ts"] = ts
        event["high_price"] = max(finite(event.get("high_price")) or price, price)
        low = finite(event.get("low_price")) or price
        event["low_price"] = min(low, price)
        for policy_id, arm_raw in (event.get("arms") or {}).items():
            if not isinstance(arm_raw, dict) or arm_raw.get("selected") is not True or arm_raw.get("closed") is True:
                continue
            if policy_id in SELECTION_POLICIES:
                before = arm_raw.get("closed") is True
                review._v1237_update_arm(arm_raw, event, dict(row), price, ts)
                if not before and arm_raw.get("closed") is True:
                    arm_raw["big_loss"] = (finite(arm_raw.get("net_pnl_pct")) or 0.0) <= -1.50
                    arm_raw["profit_then_loss"] = (finite(arm_raw.get("mfe_pct")) or 0.0) >= max(0.25, finite(event.get("fee_and_execution_cost_pct")) or 0.0) and (finite(arm_raw.get("net_pnl_pct")) or 0.0) <= 0.0
                    append_event_safe(base, state, "POLICY_ARM_CLOSED", {
                        "event_id": event_id, "ticker": ticker,
                        "source_decision_key": event.get("source_decision_key"),
                        "policy_id": policy_id,
                        "policy_decision_key": arm_raw.get("policy_decision_key"),
                        "close_price": arm_raw.get("close_price"),
                        "net_pnl_pct": arm_raw.get("net_pnl_pct"),
                        "exit_reason": arm_raw.get("exit_reason"),
                    })
            else:
                update_custom_arm(base, state, review, event, arm_raw, row, price, ts)
        if ts - (finite(event.get("opened_ts")) or ts) >= TIMEOUT_SEC:
            for arm_raw in (event.get("arms") or {}).values():
                if isinstance(arm_raw, dict) and arm_raw.get("selected") is True and arm_raw.get("closed") is not True:
                    close_arm(base, state, event, arm_raw, price, ts, "SHADOW_24H_TIMEOUT")
        selected_arms = [arm for arm in (event.get("arms") or {}).values() if isinstance(arm, Mapping) and arm.get("selected") is True]
        if selected_arms and all(arm.get("closed") is True for arm in selected_arms):
            event["terminal_ts"] = max(finite(arm.get("closed_ts")) or ts for arm in selected_arms)
            state["open"].pop(event_id, None)
            state.setdefault("closed", []).append(event)
            append_event_safe(base, state, "POLICY_EVENT_COMPLETED", {
                "event_id": event_id,
                "ticker": ticker,
                "source_decision_key": event.get("source_decision_key"),
                "selected_policies": [arm.get("policy_id") for arm in selected_arms],
            })


def prune_state(state: Dict[str, Any], ts: float) -> None:
    cutoff = ts - RETENTION_SEC
    state["closed"] = [
        row for row in (state.get("closed") or [])
        if isinstance(row, dict) and (finite(row.get("terminal_ts")) or 0.0) >= cutoff
    ]
    processed = state.get("processed_generations") if isinstance(state.get("processed_generations"), dict) else {}
    state["processed_generations"] = {
        key: value for key, value in processed.items()
        if isinstance(value, dict) and (finite(value.get("processed_ts")) or 0.0) >= cutoff
    }


def policy_rows(state: Mapping[str, Any], policy_id: str, closed_only: bool = True) -> List[Dict[str, Any]]:
    events: List[Mapping[str, Any]] = []
    events.extend(row for row in (state.get("closed") or []) if isinstance(row, Mapping))
    if not closed_only:
        events.extend(row for row in (state.get("open") or {}).values() if isinstance(row, Mapping))
    out: List[Dict[str, Any]] = []
    for event in events:
        arm = (event.get("arms") or {}).get(policy_id)
        if not isinstance(arm, Mapping) or arm.get("selected") is not True:
            continue
        if closed_only and arm.get("closed") is not True:
            continue
        out.append(dict(arm))
    return out


def metric(rows: Sequence[Mapping[str, Any]]) -> Dict[str, Any]:
    values = [finite(row.get("net_pnl_pct")) for row in rows]
    nums = [float(value) for value in values if value is not None]
    def avg(key: str) -> Optional[float]:
        data = [finite(row.get(key)) for row in rows]
        clean = [float(value) for value in data if value is not None]
        return sum(clean) / len(clean) if clean else None
    return {
        "n": len(nums),
        "wins": sum(1 for value in nums if value > 0),
        "losses": sum(1 for value in nums if value < 0),
        "win_rate": (sum(1 for value in nums if value > 0) / len(nums) * 100.0) if nums else None,
        "total_net_pct": sum(nums),
        "avg_net_pct": sum(nums) / len(nums) if nums else None,
        "avg_mfe_pct": avg("mfe_pct"),
        "avg_mae_pct": avg("mae_pct"),
        "avg_giveback_pct": avg("giveback_pct"),
        "avg_hold_sec": avg("hold_sec"),
        "big_loss_count": sum(1 for row in rows if row.get("big_loss") is True),
        "profit_then_loss_count": sum(1 for row in rows if row.get("profit_then_loss") is True),
    }


def pair_delta(state: Mapping[str, Any], policy_a: str, policy_b: str) -> Dict[str, Any]:
    values: List[float] = []
    for event in (state.get("closed") or []):
        if not isinstance(event, Mapping):
            continue
        arms = event.get("arms") if isinstance(event.get("arms"), Mapping) else {}
        a = arms.get(policy_a)
        b = arms.get(policy_b)
        if not isinstance(a, Mapping) or not isinstance(b, Mapping):
            continue
        if a.get("selected") is not True or b.get("selected") is not True or a.get("closed") is not True or b.get("closed") is not True:
            continue
        av = finite(a.get("net_pnl_pct"))
        bv = finite(b.get("net_pnl_pct"))
        if av is not None and bv is not None:
            values.append(av - bv)
    return {
        "paired_count": len(values),
        "avg_delta_pct": sum(values) / len(values) if values else None,
        "positive_delta_count": sum(1 for value in values if value > 0),
        "negative_delta_count": sum(1 for value in values if value < 0),
    }


def selection_overlap(state: Mapping[str, Any], a: str, b: str) -> Dict[str, Any]:
    a_keys: set[str] = set()
    b_keys: set[str] = set()
    events: List[Mapping[str, Any]] = []
    events.extend(row for row in (state.get("closed") or []) if isinstance(row, Mapping))
    events.extend(row for row in (state.get("open") or {}).values() if isinstance(row, Mapping))
    for event in events:
        arms = event.get("arms") if isinstance(event.get("arms"), Mapping) else {}
        event_id = str(event.get("event_id") or "")
        if isinstance(arms.get(a), Mapping) and arms[a].get("selected") is True:
            a_keys.add(event_id)
        if isinstance(arms.get(b), Mapping) and arms[b].get("selected") is True:
            b_keys.add(event_id)
    return {"a_count": len(a_keys), "b_count": len(b_keys), "overlap_count": len(a_keys & b_keys)}


def build_snapshot(
    state: Mapping[str, Any],
    review: Any,
    generation: Mapping[str, Any],
    integrity: Mapping[str, Any],
    records: Sequence[Mapping[str, Any]],
    skipped: Mapping[str, int],
    model_digest: str,
    exact_snapshot: Mapping[str, Any],
    started: float,
) -> Dict[str, Any]:
    policy_metrics = {policy: metric(policy_rows(state, policy, True)) for policy in POLICY_IDS}
    policy_open = {policy: selected_policy_count(state, policy) for policy in POLICY_IDS}
    exit_pairs = {
        policy: pair_delta(state, policy, "current_method")
        for policy in ("time_axis_exit", "fast_profit_protect", "hybrid_exit")
    }
    selection_pairs = {
        policy: pair_delta(state, policy, "current_method")
        for policy in ("v1211_quality", "expected_ev", "conservative_ev")
    }
    overlaps = {
        policy: selection_overlap(state, policy, "current_method")
        for policy in ("v1211_quality", "expected_ev", "conservative_ev")
    }
    exact_counts = exact_snapshot.get("counts") if isinstance(exact_snapshot.get("counts"), Mapping) else {}
    closed_min = min((integer(policy_metrics[p].get("n")) for p in POLICY_IDS), default=0)
    state_name = "COLLECTING_POLICY_RESULTS"
    if not generation.get("generation_key"):
        state_name = "CHECK_GENERATION_KEY_MISSING"
    elif not records and integer(skipped.get("decision_key_missing")) > 0:
        state_name = "CHECK_DIRECT_DECISION_KEY_CONTRACT"
    elif not records and any(integer(skipped.get(key)) > 0 for key in ("ticker_missing", "price_missing", "structure_missing", "entry_outside_contract")):
        state_name = "CHECK_EXECUTABLE_S1_INPUT_CONTRACT"
    elif not records:
        state_name = "COLLECTING_NO_EXECUTABLE_S1"
    elif integer(state.get("event_append_errors")) > 0:
        state_name = "CHECK_EVENT_LEDGER_APPEND"
    return {
        "schema": SNAPSHOT_SCHEMA,
        "version": VERSION,
        "build": BUILD_LABEL,
        "mode": "SHADOW_ONLY_READ_ONLY",
        "state": state_name,
        "generated_ts": now_ts(),
        "generated_text": now_text(),
        "cycle_elapsed_sec": round(time.monotonic() - started, 6),
        "generation": {
            "cycle_id": generation.get("cycle_id"),
            "candidate_commit_id": generation.get("candidate_commit_id"),
            "generation_key": generation.get("generation_key"),
            "candidate_file_sha256": integrity.get("candidate_file_sha256"),
            "committed_rows": integrity.get("row_count") or integrity.get("candidate_rows"),
            "committed_s1_rows": integrity.get("canonical_s1_rows"),
        },
        "model_owner": {
            "module": "review_worker",
            "version": getattr(review, "VERSION", None),
            "build": getattr(review, "BUILD_LABEL", None),
            "contract_digest": model_digest,
            "calculation": "imports active Review quality/probability functions; no copied formula owner",
        },
        "contracts": {
            "same_candidate_event_entry_price_time_cost": True,
            "open_cap_per_policy": OPEN_CAP_PER_POLICY,
            "new_per_generation": NEW_PER_GENERATION,
            "zero_entry_allowed": True,
            "same_ticker_duplicate_forbidden": True,
            "same_structure_event_reentry_within_24h_forbidden": True,
            "selection_universe": "committed executable S1 only",
            "direct_decision_key_owner": "Strategy swing_gate_decision_key_v977 or same sealed gate decision_key only",
            "candidate_or_build_key_fallback": False,
            "expected_ev_entry_gate": "expected_net_pct > 0",
            "conservative_ev_entry_gate": "conservative_ev_pct > 0",
            "v1211_quality_entry_gate": "would_pass == true",
            "exit_sampling": "latest candidate price/strength at worker observation; not exchange tick exact",
        },
        "current_cycle": {
            "candidate_records": len(records),
            "skipped": dict(skipped),
            "selection": dict((state.get("last_cycle") or {}).get("selection") or {}),
            "opened_event_count": integer((state.get("last_cycle") or {}).get("opened_event_count")),
        },
        "counts": {
            "open_events": len(state.get("open") or {}),
            "closed_events": len(state.get("closed") or []),
            "processed_generations": len(state.get("processed_generations") or {}),
            "event_ledger_append_errors": integer(state.get("event_append_errors")),
            "policy_open": policy_open,
            "policy_closed": {policy: integer(policy_metrics[policy].get("n")) for policy in POLICY_IDS},
        },
        "policy_metrics": policy_metrics,
        "paired_deltas_vs_current": {**selection_pairs, **exit_pairs},
        "selection_overlap_vs_current": overlaps,
        "exact_reference": {
            "snapshot_state": exact_snapshot.get("state"),
            "current_actual_exact": integer(exact_counts.get("current_actual_exact")),
            "complete_current_previous_exact": integer(exact_counts.get("complete_current_previous_exact")),
            "used_to_change_shadow_result": False,
        },
        "readiness": {
            "winner_allowed": False,
            "decision": "MORE_SAMPLE",
            "reason": "v1251 is competition collection only; final policy selection is a later stage and requires exact plus live shadow agreement",
            "minimum_closed_across_policies": closed_min,
            "required_before_later_selection": {
                "cost_after_average_positive": True,
                "total_positive": True,
                "big_loss_reduced": True,
                "profit_then_loss_reduced": True,
                "mfe_mae_giveback_improved": True,
                "entry_count_not_abnormally_low": True,
                "ticker_and_route_concentration_checked": True,
                "exact_and_live_shadow_direction_same": True,
            },
        },
        "recent_closed": list(state.get("closed") or [])[-10:],
        "invariants": {
            "review_collection_changed": False,
            "paper_writer_changed": False,
            "strategy_pipeline_changed": False,
            "actual_candidate_rank_changed": False,
            "actual_s1_changed": False,
            "actual_entry_changed": False,
            "actual_exit_changed": False,
            "existing_open_changed": False,
            "core_ledgers_changed": False,
            "auto_buy": False,
        },
    }


def process_once(base: Path) -> Dict[str, Any]:
    started = time.monotonic()
    review = load_review_owner()
    paths = review.SpinePaths(base)
    request = review.read_json(paths.review_request, {}) or {}
    generation = review._v1241_request_generation(request)
    if not generation.get("generation_key"):
        cycle = str(request.get("pipeline_cycle_id") or request.get("candidate_pipeline_cycle_id_v1150") or "").strip()
        commit = str(request.get("candidate_commit_id") or request.get("candidate_commit_id_v1150") or "").strip()
        generation = {"cycle_id": cycle, "candidate_commit_id": commit, "generation_key": f"{cycle}|{commit}" if cycle and commit else ""}
    committed_rows, integrity = review._v1241_stable_committed_rows(base, request, require_pipeline=False)
    live_rows = review.read_candidate_rows(paths.strategy_candidates, 5000)
    perf = read_json(base / "canonical_performance_snapshot_v987.json", {}) or {}
    history_rows = current_history_rows(perf if isinstance(perf, Mapping) else {})
    prepared = review._v1236_prepare(history_rows)
    ts = now_ts()
    records, skipped = build_candidate_records(review, committed_rows, prepared, ts)
    state = load_state(base, ts)
    prune_state(state, ts)
    update_open_events(base, state, review, live_rows, ts)
    generation_key = str(generation.get("generation_key") or "")
    opened_events = 0
    selection_audit: Dict[str, Any] = {}
    if generation_key and generation_key not in (state.get("processed_generations") or {}):
        selected, selection_audit = selection_plan(state, records)
        selected_union = set(value for values in selected.values() for value in values)
        seen = all_seen_event_ids(state)
        by_event = {str(record.get("event_id")): record for record in records}
        for event_id in sorted(selected_union):
            if event_id in seen:
                continue
            record = by_event.get(event_id)
            if not record:
                continue
            event = create_event(record, generation, selected, ts)
            if not any(isinstance(arm, Mapping) and arm.get("selected") is True for arm in (event.get("arms") or {}).values()):
                continue
            state.setdefault("open", {})[event_id] = event
            opened_events += 1
            append_event_safe(base, state, "POLICY_EVENT_OPENED", {
                "event_id": event_id,
                "ticker": event.get("ticker"),
                "source_decision_key": event.get("source_decision_key"),
                "candidate_cycle_id": event.get("candidate_cycle_id"),
                "candidate_commit_id": event.get("candidate_commit_id"),
                "entry_price": event.get("entry_price"),
                "fee_and_execution_cost_pct": event.get("fee_and_execution_cost_pct"),
                "selected_policies": [policy for policy, arm in event["arms"].items() if arm.get("selected") is True],
            })
        state.setdefault("processed_generations", {})[generation_key] = {
            "processed_ts": ts,
            "cycle_id": generation.get("cycle_id"),
            "candidate_commit_id": generation.get("candidate_commit_id"),
            "candidate_records": len(records),
            "opened_event_count": opened_events,
            "selection": selection_audit,
        }
        append_event_safe(base, state, "GENERATION_POLICY_SELECTION", {
            "candidate_cycle_id": generation.get("cycle_id"),
            "candidate_commit_id": generation.get("candidate_commit_id"),
            "candidate_records": len(records),
            "opened_event_count": opened_events,
            "selection": selection_audit,
        })
    else:
        prior = (state.get("processed_generations") or {}).get(generation_key) if generation_key else None
        if isinstance(prior, Mapping):
            selection_audit = dict(prior.get("selection") or {})
    state["updated_ts"] = ts
    state["updated_text"] = now_text(ts)
    state["last_cycle"] = {
        "ts": ts,
        "cycle_id": generation.get("cycle_id"),
        "candidate_commit_id": generation.get("candidate_commit_id"),
        "generation_key": generation_key,
        "candidate_records": len(records),
        "skipped": skipped,
        "opened_event_count": opened_events,
        "selection": selection_audit,
    }
    exact = read_json(base / "canonical_paper_exact_replay_v1250.json", {}) or {}
    snapshot = build_snapshot(state, review, generation, integrity, records, skipped, review_contract_digest(review), exact if isinstance(exact, Mapping) else {}, started)
    atomic_write_json(state_path(base), state)
    atomic_write_json(snapshot_path(base), snapshot)
    return snapshot


def write_status(base: Path, health_state: str, **extra: Any) -> Dict[str, Any]:
    state = str(health_state or "COLLECTING").upper()
    payload = {
        "schema": STATUS_SCHEMA,
        "version": VERSION,
        "build": BUILD_LABEL,
        "health_state": state,
        "state": "error" if state == "ERROR" else "running",
        "running": state != "ERROR",
        "phase": extra.pop("phase", state.lower()),
        "updated_ts": now_ts(),
        "updated_text": now_text(),
        "pid": os.getpid(),
        "owner": "policy_competition_single_shadow_owner_v1251",
        "mode": "SHADOW_ONLY_READ_ONLY",
        "auto_buy": False,
        "live_ledger_write": False,
    }
    payload.update(extra)
    atomic_write_json(status_path(base), payload)
    return payload


def log_error(base: Path, where: str, exc: BaseException) -> None:
    message = f"[{now_text()}] {where}: {type(exc).__name__}: {exc}\n{traceback.format_exc()[-5000:]}\n"
    with error_path(base).open("a", encoding="utf-8") as handle:
        handle.write(message)
        handle.flush()
        os.fsync(handle.fileno())


def acquire_singleton(base: Path) -> None:
    global _LOCK_HANDLE
    path = lock_path(base)
    path.parent.mkdir(parents=True, exist_ok=True)
    handle = path.open("a+", encoding="utf-8")
    try:
        fcntl.flock(handle.fileno(), fcntl.LOCK_EX | fcntl.LOCK_NB)
    except BlockingIOError as exc:
        raise RuntimeError("policy competition worker already running") from exc
    handle.seek(0)
    handle.truncate(0)
    handle.write(json.dumps({"pid": os.getpid(), "version": VERSION, "acquired_ts": now_ts()}, separators=(",", ":")))
    handle.flush()
    os.fsync(handle.fileno())
    _LOCK_HANDLE = handle
    pid_path(base).write_text(str(os.getpid()), encoding="utf-8")


def release_singleton(base: Path) -> None:
    global _LOCK_HANDLE
    try:
        if _LOCK_HANDLE is not None:
            fcntl.flock(_LOCK_HANDLE.fileno(), fcntl.LOCK_UN)
            _LOCK_HANDLE.close()
    except OSError:
        pass
    _LOCK_HANDLE = None
    try:
        pid_path(base).unlink(missing_ok=True)
    except OSError:
        pass


def signal_handler(_signum: int, _frame: Any) -> None:
    global _STOP
    _STOP = True


def run_loop(base: Path, interval_sec: float) -> int:
    acquire_singleton(base)
    atexit.register(release_singleton, base)
    signal.signal(signal.SIGTERM, signal_handler)
    signal.signal(signal.SIGINT, signal_handler)
    write_status(base, "STARTING", phase="boot")
    while not _STOP:
        try:
            snapshot = process_once(base)
            counts = snapshot.get("counts") if isinstance(snapshot.get("counts"), Mapping) else {}
            write_status(
                base,
                "NORMAL" if str(snapshot.get("state") or "").startswith(("COLLECTING", "NORMAL")) else "CHECK",
                phase="idle",
                snapshot_state=snapshot.get("state"),
                cycle_id=(snapshot.get("generation") or {}).get("cycle_id"),
                candidate_commit_id=(snapshot.get("generation") or {}).get("candidate_commit_id"),
                candidate_rows=(snapshot.get("current_cycle") or {}).get("candidate_records"),
                row_count=(snapshot.get("current_cycle") or {}).get("candidate_records"),
                open_events=counts.get("open_events"),
                closed_events=counts.get("closed_events"),
                policy_open=counts.get("policy_open"),
                policy_closed=counts.get("policy_closed"),
                last_sec=snapshot.get("cycle_elapsed_sec"),
                last_error=None,
            )
        except Exception as exc:
            log_error(base, "run_loop", exc)
            write_status(base, "ERROR", phase="error", last_error=f"{type(exc).__name__}: {exc}")
        slept = 0.0
        while slept < interval_sec and not _STOP:
            step = min(0.2, interval_sec - slept)
            time.sleep(step)
            slept += step
    write_status(base, "STOPPED", phase="shutdown")
    return 0


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--base-dir", default="")
    parser.add_argument("--interval", type=float, default=DEFAULT_INTERVAL_SEC)
    parser.add_argument("--once", action="store_true")
    args = parser.parse_args()
    base = Path(args.base_dir).expanduser().resolve() if args.base_dir else base_dir()
    if args.once:
        result = process_once(base)
        print(json.dumps({
            "state": result.get("state"),
            "generation": result.get("generation"),
            "counts": result.get("counts"),
            "cycle_elapsed_sec": result.get("cycle_elapsed_sec"),
        }, ensure_ascii=False, indent=2))
        return 0
    return run_loop(base, max(1.0, args.interval))


if __name__ == "__main__":
    raise SystemExit(main())
