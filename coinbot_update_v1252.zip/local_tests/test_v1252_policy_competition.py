from __future__ import annotations
import importlib.util
import json
import sys
import time
from pathlib import Path
from types import SimpleNamespace

ROOT = Path(__file__).resolve().parents[1]
SPEC = importlib.util.spec_from_file_location("policy_competition_worker", ROOT / "policy_competition_worker_v0.2.py")
mod = importlib.util.module_from_spec(SPEC)
assert SPEC.loader is not None
SPEC.loader.exec_module(mod)


def row(ticker, score, quality, expected, conservative, price=100.0):
    return {
        "ticker": ticker,
        "s_stage": "S1",
        "swing_gate_decision_key_v977": f"direct-{ticker}",
        "canonical_entry_decision": {"decision_key": f"direct-{ticker}"},
        "current_price": price,
        "global_entry_score_v1212": score,
        "quality_score_fixture": quality,
        "quality_pass_fixture": quality >= 50,
        "expected_fixture": expected,
        "conservative_fixture": conservative,
        "configured_fee_pct": 0.10,
        "spread_pct": 0.05,
        "paper_reference_cost_pct": 0.0,
        "dynamic_structure_plan_v1212": {
            "trigger": {"price": 99.0, "tf": "m15"},
            "invalid": {"price": 95.0, "tf": "m30"},
            "target": {"price": 110.0, "tf": "h2"},
        },
    }


class FakeReview:
    VERSION = "review_worker_v1.035"
    BUILD_LABEL = "fixture"
    _rows = []

    @staticmethod
    def SpinePaths(base):
        return SimpleNamespace(review_request=base / "review_request.json", strategy_candidates=base / "candidates.json")

    @staticmethod
    def read_json(path, default=None):
        try:
            return json.loads(Path(path).read_text())
        except Exception:
            return default

    @staticmethod
    def _v1241_request_generation(request):
        cycle = request.get("pipeline_cycle_id", "")
        commit = request.get("candidate_commit_id", "")
        return {"cycle_id": cycle, "candidate_commit_id": commit, "generation_key": f"{cycle}|{commit}" if cycle and commit else ""}

    @classmethod
    def _v1241_stable_committed_rows(cls, base, request, require_pipeline=False):
        return list(cls._rows), {"candidate_file_sha256": "fixture-hash", "row_count": len(cls._rows), "canonical_s1_rows": len(cls._rows)}

    @classmethod
    def read_candidate_rows(cls, path, limit):
        return list(cls._rows)

    @staticmethod
    def stage(r):
        return r.get("s_stage", "")

    @staticmethod
    def _v1233_ticker(r):
        return r.get("ticker", "")

    @staticmethod
    def _v1233_price(r):
        return r.get("current_price", 0.0)

    @staticmethod
    def _v1236_line(r, name):
        return r["dynamic_structure_plan_v1212"][name]

    @staticmethod
    def _v1236_line_price(line):
        return line.get("price")

    @staticmethod
    def _v1237_cost(r):
        return r.get("configured_fee_pct", 0.1) + r.get("spread_pct", 0.0) + r.get("paper_reference_cost_pct", 0.0)

    @staticmethod
    def _v1236_prepare(rows):
        return list(rows)

    @staticmethod
    def _v1236_estimate(r, prepared, nowv):
        return {
            "expected_net_pct": r.get("expected_fixture"),
            "conservative_ev_pct": r.get("conservative_fixture"),
            "confidence": 80.0,
            "state": "HIGH",
            "profile": "balanced",
            "p_win": 0.55,
            "p_giveback": 0.3,
            "p_tail_loss": 0.1,
            "exit_policy": {"no_progress_review_min": 5.0, "profit_protect_arm_pct": 0.4, "profit_floor_pct": 0.05},
        }

    @staticmethod
    def _v1234_quality_replay(r):
        return {"score": r.get("quality_score_fixture"), "would_pass": r.get("quality_pass_fixture"), "reasons": []}

    @staticmethod
    def _v1237_strength_snapshot(r):
        return (1, 4) if r.get("weak_fixture") else (3, 0)

    @staticmethod
    def _v1237_update_arm(arm, event, r, price, nowv):
        if arm.get("closed"):
            return
        if price <= arm["invalid_price"]:
            arm.update({"closed": True, "closed_ts": nowv, "close_price": price, "exit_reason": "INVALID", "net_pnl_pct": -5.15, "mfe_pct": 0.0, "mae_pct": -5.0, "giveback_pct": 5.15, "hold_sec": nowv-event["opened_ts"]})
        elif price >= arm["target_price"]:
            arm.update({"closed": True, "closed_ts": nowv, "close_price": price, "exit_reason": "TARGET", "net_pnl_pct": 9.85, "mfe_pct": 10.0, "mae_pct": 0.0, "giveback_pct": 0.15, "hold_sec": nowv-event["opened_ts"]})

    _v1236_features = _v1236_estimate
    _v1236_similarity = _v1236_estimate
    _v1236_outcome = _v1236_estimate
    _v1236_profile = _v1236_estimate


def records():
    rows = [
        row("A", 100, 40, -0.1, -0.2),
        row("B", 90, 90, 0.1, -0.1),
        row("C", 80, 80, 0.8, 0.2),
        row("D", 70, 70, 0.6, 0.5),
    ]
    recs, skipped = mod.build_candidate_records(FakeReview, rows, [], time.time())
    assert not skipped
    return recs


def test_selection_contract_and_zero_entry_gate():
    state = mod.empty_state(time.time())
    selected, audit = mod.selection_plan(state, records())
    baseline = selected["current_method"]
    assert baseline == selected["time_axis_exit"] == selected["fast_profit_protect"] == selected["hybrid_exit"]
    assert len(baseline) == 2
    assert len(selected["v1211_quality"]) == 2
    assert len(selected["expected_ev"]) == 2
    assert len(selected["conservative_ev"]) == 2
    zero = records()
    for rec in zero:
        rec["expected_ev_pct"] = -0.1
        rec["conservative_ev_pct"] = -0.2
    selected2, _ = mod.selection_plan(mod.empty_state(time.time()), zero)
    assert selected2["expected_ev"] == []
    assert selected2["conservative_ev"] == []
    assert audit["current_method"]["same_selection_as_current_method"] is True


def test_event_same_entry_time_cost_and_keys():
    recs = records()
    state = mod.empty_state(time.time())
    selected, _ = mod.selection_plan(state, recs)
    generation = {"cycle_id": "c1", "candidate_commit_id": "m1", "generation_key": "c1|m1"}
    target = next(rec for rec in recs if rec["event_id"] in set().union(*[set(v) for v in selected.values()]))
    event = mod.create_event(target, generation, selected, 1000.0)
    chosen = [a for a in event["arms"].values() if a["selected"]]
    assert chosen
    assert all(a["opened_ts"] == 1000.0 for a in chosen)
    assert len({a["policy_decision_key"] for a in chosen}) == len(chosen)
    assert event["entry_price"] == target["entry_price"]
    assert event["fee_and_execution_cost_pct"] == target["cost_pct"]


def test_fast_and_hybrid_profit_protect(tmp_path):
    rec = records()[0]
    selected = {p: [] for p in mod.POLICY_IDS}
    for p in ("current_method", "time_axis_exit", "fast_profit_protect", "hybrid_exit"):
        selected[p] = [rec["event_id"]]
    event = mod.create_event(rec, {"cycle_id":"c","candidate_commit_id":"m","generation_key":"c|m"}, selected, 1000.0)
    state = mod.empty_state(1000.0)
    state["open"][event["event_id"]] = event
    event["high_price"] = 101.0
    event["last_price"] = 100.1
    weak_row = dict(rec["row"], current_price=100.1, weak_fixture=True)
    mod.update_custom_arm(tmp_path, state, FakeReview, event, event["arms"]["fast_profit_protect"], weak_row, 100.1, 1100.0)
    mod.update_custom_arm(tmp_path, state, FakeReview, event, event["arms"]["hybrid_exit"], weak_row, 100.1, 1100.0)
    assert event["arms"]["fast_profit_protect"]["closed"] is True
    assert event["arms"]["hybrid_exit"]["closed"] is True
    assert (tmp_path / "policy_competition_events_v1251.jsonl").exists()


def test_process_once_generation_dedupe(tmp_path, monkeypatch):
    FakeReview._rows = [
        row("A", 100, 70, 0.5, 0.2),
        row("B", 90, 80, 0.4, 0.1),
        row("C", 80, 60, -0.1, -0.2),
    ]
    (tmp_path / "review_request.json").write_text(json.dumps({"pipeline_cycle_id":"cycle-1","candidate_commit_id":"commit-1"}))
    (tmp_path / "canonical_performance_snapshot_v987.json").write_text(json.dumps({"rows": []}))
    monkeypatch.setattr(mod, "_REVIEW_MODULE", FakeReview)
    first = mod.process_once(tmp_path)
    second = mod.process_once(tmp_path)
    assert first["counts"]["processed_generations"] == 1
    assert second["counts"]["processed_generations"] == 1
    assert first["current_cycle"]["opened_event_count"] > 0
    assert second["current_cycle"]["opened_event_count"] == 0
    lines = (tmp_path / "policy_competition_events_v1251.jsonl").read_text().strip().splitlines()
    generation_events = [json.loads(x) for x in lines if json.loads(x)["event_type"] == "GENERATION_POLICY_SELECTION"]
    assert len(generation_events) == 1
    assert first["invariants"]["actual_entry_changed"] is False
    assert first["readiness"]["winner_allowed"] is False


def test_production_direct_decision_owner_contract():
    production = row("PROD", 90, 80, 0.5, 0.2)
    production.pop("canonical_entry_decision", None)
    key, owner = mod.source_decision_identity(production)
    assert key == "direct-PROD"
    assert owner == "swing_gate_decision_key_v977"
    production.pop("swing_gate_decision_key_v977", None)
    production["canonical_entry_decision"] = {"decision_key": "nested-PROD"}
    key2, owner2 = mod.source_decision_identity(production)
    assert key2 == "nested-PROD"
    assert owner2 == "canonical_entry_decision.decision_key"


def test_candidate_build_key_is_not_direct_decision_fallback():
    bad = row("BUILDONLY", 90, 80, 0.5, 0.2)
    bad.pop("swing_gate_decision_key_v977", None)
    bad.pop("canonical_entry_decision", None)
    bad["entry_build_key"] = "not-a-direct-decision"
    records, skipped = mod.build_candidate_records(FakeReview, [bad], [], time.time())
    assert records == []
    assert skipped.get("decision_key_missing") == 1

def test_server_shape_15_s1_10_observation_keeps_5_executable():
    rows = []
    for i in range(15):
        item = row(f"S{i}", 100-i, 70, 0.4, 0.1)
        if i < 10:
            item["observation_open_forbidden_v988"] = True
        rows.append(item)
    records, skipped = mod.build_candidate_records(FakeReview, rows, [], time.time())
    assert len(records) == 5
    assert skipped.get("observation_only") == 10
    assert skipped.get("decision_key_missing", 0) == 0
