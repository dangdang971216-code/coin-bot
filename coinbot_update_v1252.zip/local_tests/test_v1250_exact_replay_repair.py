import hashlib
import importlib.util
import json
import tempfile
import unittest
from pathlib import Path
import sys

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))


def load_module(name: str, path: Path):
    spec = importlib.util.spec_from_file_location(name, path)
    module = importlib.util.module_from_spec(spec)
    assert spec.loader is not None
    spec.loader.exec_module(module)
    return module


worker = load_module("exact_replay_worker_v1250_test", ROOT / "exact_replay_worker_v0.2.py")
main = load_module("coinbot_main_v1250_test", ROOT / "coinbot_main_v2_13_1155.py")


def dump_json(path: Path, obj):
    path.write_text(json.dumps(obj, ensure_ascii=False, separators=(",", ":")), encoding="utf-8")


def append_jsonl(path: Path, obj):
    with path.open("a", encoding="utf-8") as handle:
        handle.write(json.dumps(obj, ensure_ascii=False, separators=(",", ":")) + "\n")


def sha(path: Path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


class Fixture:
    def __init__(self, base: Path):
        self.base = base
        dump_json(base / "paper_bot_open.json", {})
        dump_json(base / "paper_decision_state_v926.json", {"records": {}})
        dump_json(base / "paper_exit_replay_status_v1242.json", {
            "schema": "paper_exit_replay_status_v1242",
            "state": "NORMAL",
            "poll_records": 0,
            "close_commit_ok": 0,
            "close_commit_fail": 0,
            "evidence_append_failures": 0,
        })
        for name in (
            "paper_bot_closed.jsonl",
            "paper_exit_replay_close_v1242.jsonl",
            "paper_exit_replay_poll_v1242.jsonl",
        ):
            (base / name).write_text("", encoding="utf-8")

    def add_closed(self, key: str, *, include_current=True, include_previous=True, result_key=None, reason="swing_dynamic_momentum_decay", duplicate=False):
        result_key = result_key or f"closed:{key}"
        row = {
            "paper_decision_key_v926": key,
            "ticker": "AAA",
            "pos_id": f"P-{key}",
            "opened_at": 1000.0,
            "closed_ts": 1020.0,
            "entry_price": 100.0,
            "exit_price": 101.0,
            "exit_reason": reason,
            "closed_result_key": result_key,
            "net_after_configured_fee_pct_v983": 0.9,
            "gross_pnl_pct_v983": 1.0,
            "mfe_pct_v983": 3.9,
            "mae_pct_v983": -0.1,
            "giveback_pct_v983": 3.0,
            "hold_sec": 20.0,
            "configured_roundtrip_fee_pct_v983": 0.1,
            "exit_replay_contract_digest_v1242": f"CD-{key}",
            "structure_contract_version": "v1212",
            "structure_contract_hash": f"H-{key}",
        }
        if include_current:
            row["dynamic_structure_plan_v1212"] = {
                "schema": "plan",
                "trigger": {"price": 100.0},
                "invalid": {"price": 95.0},
                "target": {"price": 110.0},
            }
        if include_previous:
            row["v1211_structure_shadow_v1222"] = {
                "schema": "old-plan",
                "source_exact": True,
                "trigger": {"price": 100.0},
                "invalid": {"price": 92.0},
                "target": {"price": 115.0},
            }
        append_jsonl(self.base / "paper_bot_closed.jsonl", row)
        if duplicate:
            append_jsonl(self.base / "paper_bot_closed.jsonl", row)
        state = json.loads((self.base / "paper_decision_state_v926.json").read_text(encoding="utf-8"))
        state["records"][key] = {"status": "CLOSED", "paper_decision_key_v926": key, "closed_result_key": result_key}
        dump_json(self.base / "paper_decision_state_v926.json", state)
        return row

    def add_poll_sequence(self, key: str, *, prices=(100.0, 104.0, 101.0), actions=None, reasons=None, duplicate_last=False):
        actions = actions or ["hold"] * (len(prices) - 1) + ["close"]
        reasons = reasons or ["hold"] * (len(prices) - 1) + ["swing_dynamic_momentum_decay"]
        records = []
        peak = -0.1
        trough = -0.1
        for i, price in enumerate(prices):
            net = (price / 100.0 - 1.0) * 100.0 - 0.1
            peak = max(peak, net)
            trough = min(trough, net)
            records.append({
                "k": f"{key}-K{i}", "p": f"P-{key}", "t": "AAA", "ts": 1000.0 + i * 10,
                "ot": 1000.0, "dk": key, "cd": f"CD-{key}", "pr": price, "en": 100.0,
                "net": net, "mfe": peak, "mae": trough, "age": i / 6.0,
                "a": actions[i], "r": reasons[i], "tg": 110.0, "iv": 95.0,
                "sp": 98.0, "bs": 0, "ws": 0, "st": 1, "wk": 0,
                "scv": "v1212", "sch": f"H-{key}",
            })
        append_jsonl(self.base / "paper_exit_replay_poll_v1242.jsonl", {"records": records})
        if duplicate_last:
            append_jsonl(self.base / "paper_exit_replay_poll_v1242.jsonl", {"records": [records[-1]]})
        status = json.loads((self.base / "paper_exit_replay_status_v1242.json").read_text(encoding="utf-8"))
        status["poll_records"] += len(records) + (1 if duplicate_last else 0)
        dump_json(self.base / "paper_exit_replay_status_v1242.json", status)
        return records

    def add_link(self, key: str, *, poll_index=2, commit_ok=True, result_key=None, reason="swing_dynamic_momentum_decay", closed_ts=1020.0, pnl=0.9):
        result_key = result_key or f"closed:{key}"
        row = {
            "schema": "paper_exit_replay_close_link_v1242",
            "decision_key": key,
            "poll_key": f"{key}-K{poll_index}",
            "contract_digest": f"CD-{key}",
            "commit_ok": commit_ok,
            "commit_reason": "appended_verified" if commit_ok else "append_verify_failed",
            "exit_reason": reason,
            "closed_ts": closed_ts,
            "closed_result_key": result_key,
            "pnl_pct": pnl,
            "ticker": "AAA",
            "pos_id": f"P-{key}",
        }
        append_jsonl(self.base / "paper_exit_replay_close_v1242.jsonl", row)
        status = json.loads((self.base / "paper_exit_replay_status_v1242.json").read_text(encoding="utf-8"))
        status["close_commit_ok" if commit_ok else "close_commit_fail"] += 1
        dump_json(self.base / "paper_exit_replay_status_v1242.json", status)
        return row

    def run(self, rebuild=True):
        return worker.process_once(self.base, rebuild=rebuild)["snapshot"]


class V1250ExactReplayRepair(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.base = Path(self.tmp.name)
        self.fx = Fixture(self.base)

    def tearDown(self):
        self.tmp.cleanup()

    def row(self, snapshot, key):
        return next(row for row in snapshot["rows"] if row["decision_key"] == key)

    def add_normal(self, key="D1", **closed_kwargs):
        self.fx.add_closed(key, **closed_kwargs)
        self.fx.add_poll_sequence(key)
        self.fx.add_link(key)

    def test_normal_success_link_produces_current_and_pair_exact(self):
        self.add_normal()
        snap = self.fx.run()
        row = self.row(snap, "D1")
        self.assertEqual(row["replay_state"], "EXACT_REPLAYABLE")
        self.assertEqual(snap["counts"]["current_actual_exact"], 1)
        self.assertEqual(snap["counts"]["complete_current_previous_exact"], 1)
        self.assertEqual(snap["state"], "NORMAL_EXACT_SAMPLE_AVAILABLE")

    def test_failed_link_then_success_selects_success_and_keeps_retry_as_warning(self):
        self.fx.add_closed("D2")
        self.fx.add_poll_sequence(
            "D2", prices=(100.0, 100.5, 101.0),
            actions=("hold", "close", "close"),
            reasons=("hold", "swing_dynamic_momentum_decay", "swing_dynamic_momentum_decay"),
        )
        self.fx.add_link("D2", poll_index=1, commit_ok=False, closed_ts=1010.0, pnl=0.4)
        self.fx.add_link("D2", poll_index=2, commit_ok=True, closed_ts=1020.0, pnl=0.9)
        row = self.row(self.fx.run(), "D2")
        self.assertEqual(row["replay_state"], "EXACT_REPLAYABLE")
        self.assertIn("FAILED_CLOSE_RETRY_BEFORE_SUCCESS", row["warnings"])
        self.assertEqual(row["source_contract"]["linked_poll_key"], "D2-K2")

    def test_identical_success_retry_is_warning_not_ambiguous(self):
        self.add_normal("D3")
        self.fx.add_link("D3")
        row = self.row(self.fx.run(), "D3")
        self.assertEqual(row["replay_state"], "EXACT_REPLAYABLE")
        self.assertIn("DUPLICATE_IDENTICAL_SUCCESS_CLOSE_LINKS", row["warnings"])

    def test_conflicting_success_links_fail_closed(self):
        self.add_normal("D4")
        self.fx.add_link("D4", poll_index=1, closed_ts=1010.0, pnl=3.9)
        row = self.row(self.fx.run(), "D4")
        self.assertEqual(row["replay_state"], "AMBIGUOUS")
        self.assertIn("CONFLICTING_SUCCESS_CLOSE_LINKS", row["issues"])

    def test_duplicate_identical_closed_rows_are_warning_only(self):
        self.fx.add_closed("D5", duplicate=True)
        self.fx.add_poll_sequence("D5")
        self.fx.add_link("D5")
        row = self.row(self.fx.run(), "D5")
        self.assertEqual(row["replay_state"], "EXACT_REPLAYABLE")
        self.assertIn("DUPLICATE_IDENTICAL_CLOSED_ROWS", row["warnings"])

    def test_current_structure_copy_missing_uses_historical_poll_lines(self):
        self.add_normal("D6", include_current=False)
        row = self.row(self.fx.run(), "D6")
        self.assertEqual(row["replay_state"], "EXACT_REPLAYABLE")
        self.assertEqual(row["structure_lines"]["current"]["source_path"], "poll.iv/tg")

    def test_previous_structure_missing_keeps_current_exact(self):
        self.add_normal("D7", include_previous=False)
        snap = self.fx.run()
        row = self.row(snap, "D7")
        self.assertEqual(row["replay_state"], "PARTIAL_CURRENT_EXACT_PREVIOUS_STRUCTURE_MISSING")
        self.assertEqual(snap["counts"]["current_actual_exact"], 1)
        self.assertEqual(snap["counts"]["complete_current_previous_exact"], 0)
        self.assertEqual(snap["state"], "NORMAL_CURRENT_EXACT_COLLECTING_PAIR")

    def test_historical_closed_is_separate_not_active_failure(self):
        for i in range(20):
            self.fx.add_closed(f"OLD{i}")
        self.add_normal("NEW")
        snap = self.fx.run()
        self.assertEqual(snap["counts"]["historical_not_replayable"], 20)
        self.assertEqual(snap["counts"]["active_unresolved"], 0)
        self.assertEqual(snap["state"], "NORMAL_EXACT_SAMPLE_AVAILABLE")

    def test_failure_only_close_link_is_separate(self):
        self.fx.add_closed("D8")
        self.fx.add_poll_sequence("D8", actions=("hold", "hold", "close"))
        self.fx.add_link("D8", commit_ok=False)
        snap = self.fx.run()
        row = self.row(snap, "D8")
        self.assertEqual(row["replay_state"], "CAPTURE_FAIL_ONLY")
        self.assertEqual(snap["counts"]["fail_only_close_decisions"], 1)
        self.assertEqual(snap["counts"]["active_unresolved"], 0)

    def test_identical_poll_duplicate_is_warning_only(self):
        self.fx.add_closed("D9")
        self.fx.add_poll_sequence("D9", duplicate_last=True)
        self.fx.add_link("D9")
        row = self.row(self.fx.run(), "D9")
        self.assertEqual(row["replay_state"], "EXACT_REPLAYABLE")
        self.assertIn("DUPLICATE_IDENTICAL_POLL_EVENTS", row["warnings"])

    def test_inputs_unchanged_and_incremental_second_run_adds_zero(self):
        self.add_normal("D10")
        names = [
            "paper_bot_closed.jsonl", "paper_exit_replay_close_v1242.jsonl",
            "paper_exit_replay_poll_v1242.jsonl", "paper_bot_open.json",
            "paper_decision_state_v926.json", "paper_exit_replay_status_v1242.json",
        ]
        before = {name: sha(self.base / name) for name in names}
        first = self.fx.run(rebuild=True)
        second = self.fx.run(rebuild=False)
        after = {name: sha(self.base / name) for name in names}
        self.assertEqual(before, after)
        self.assertEqual(second["ingestion_this_cycle"]["closed_added"], 0)
        self.assertEqual(second["ingestion_this_cycle"]["close_links_added"], 0)
        self.assertEqual(second["ingestion_this_cycle"]["poll_records_added"], 0)
        self.assertEqual(first["counts"]["current_actual_exact"], second["counts"]["current_actual_exact"])

    def test_main_board_separates_history_and_active_block(self):
        snapshot = {
            "state": "NORMAL_CURRENT_EXACT_COLLECTING_PAIR",
            "source_status_v1242": {"poll_records": 31760},
            "counts": {
                "successful_close_decisions": 2, "fail_only_close_decisions": 1,
                "current_actual_exact": 2, "complete_current_previous_exact": 0,
                "active_unresolved": 0, "historical_not_replayable": 2210,
                "close_link_success_events": 2, "close_link_failure_events": 1,
                "state_counts": {"PARTIAL_CURRENT_EXACT_PREVIOUS_STRUCTURE_MISSING": 2},
            },
            "metrics": {},
            "comparability": {"winner_allowed": False, "exact_pair_rows": 0},
            "diagnostics": {"active_block_reason_counts": {}},
        }
        text = "\n".join(main._exact_replay_lines(snapshot))
        self.assertIn("성공 연결 중 막힘 0 / 과거 poll 없음 2210", text)
        self.assertIn("승자 판정: 금지", text)
        self.assertIn("자동매수 OFF", text)

    def test_no_live_writer_changed(self):
        worker_text = (ROOT / "exact_replay_worker_v0.2.py").read_text(encoding="utf-8")
        main_text = (ROOT / "coinbot_main_v2_13_1155.py").read_text(encoding="utf-8")
        self.assertIn('"paper_writer_changed": False', worker_text)
        self.assertNotIn("AUTO_BUY = True", worker_text)
        self.assertNotIn("paper_bot_closed.jsonl\", \"w", worker_text)
        self.assertIn('BOT_VERSION = "수익형 v2.13.1155"', main_text)
        self.assertNotIn("append_jsonl", main_text)


if __name__ == "__main__":
    unittest.main(verbosity=2)
