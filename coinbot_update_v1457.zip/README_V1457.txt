coinbot_update_v1457
- Read-only trigger/RR reconcile map.
- /candidate_flow now compares direct current>=trigger with Paper trigger flag and explains RR MISSING source fields.
- No trading rule, candidate criteria, OPEN rule, trigger/invalid/target/RR, stale pass, BUY_READY, or auto-buy change. Auto-buy OFF.
