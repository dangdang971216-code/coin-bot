coinbot_update_v930

변경: paper OPEN raw payload + hourly event trace 경량화.
적용: /gupgrade_bundle
확인: bundle coinbot_update_v930.zip / paper_bot_v0.930 / /gdeep_audit 10
자동매수 OFF, 매매 조건·trigger·청산 변경 없음.
