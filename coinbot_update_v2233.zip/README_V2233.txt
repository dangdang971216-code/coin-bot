v2233
- Existing exact input rows already contained candidate-time continuation_score/state.
- Review now uses those sealed values as actual mainline history; current-code replay is not substituted.
- Existing v2215 role replay remains comparison-only; existing v2213 Shadow remains unchanged.
- Missing sealed score remains SOURCE_MISSING.
- Existing v2220 SQLite date cache is reused; canonical ledger rewrite/delete 0.
- Main labels an unfinished non-negative cycle PENDING instead of CHECK failure.
- Main/Review only. Auto-buy OFF.
