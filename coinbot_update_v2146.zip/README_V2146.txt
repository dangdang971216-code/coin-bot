Coinbot update v2146 - clean V2 readable alerts and status truth

- Restores the prior readable section layout for Paper OPEN/CLOSED, but every value comes from the clean V2 sealed contract.
- Fixes Main Paper counter field mapping and same-snapshot OPEN performance/list.
- Batch one-glance now uses the current V2 single flow instead of the retired v2122 flow.
- No strategy, prediction, entry, exit, ledger-history or generation reset. Auto-buy OFF.
- Local verification PASS; server runtime CHECK until deployment.
