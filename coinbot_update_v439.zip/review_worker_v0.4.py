#!/usr/bin/env python3
# -*- coding: utf-8 -*-
from __future__ import annotations
import json, os, time, traceback
from pathlib import Path
from typing import Any, Dict, List, Optional

BASE_DIR = Path(os.getenv("TRADING_BOT_DIR", "/home/dangdang971216/trading_bot"))
VERSION = "review_worker_v0.4"
INTERVAL_SEC = float(os.getenv("REVIEW_WORKER_INTERVAL_SEC", "30"))
RETENTION_DAYS = float(os.getenv("REVIEW_RETENTION_DAYS", "2"))

STATUS = BASE_DIR / "clean_review_worker_status.json"
ERROR = BASE_DIR / "clean_review_worker_error.log"
CLOSED = BASE_DIR / "paper_bot_closed.jsonl"
FEATURE = BASE_DIR / "clean_feature_cache.json"
ORDERFLOW = BASE_DIR / "clean_orderflow_summary_cache.json"
QUEUE = BASE_DIR / "clean_missed_review_queue.json"
STATE = BASE_DIR / "clean_missed_review_state.json"
SUMMARY = BASE_DIR / "clean_missed_review_summary.json"
OLD_SUMMARY = BASE_DIR / "clean_review_summary.json"

def now_ts() -> float: return time.time()
def now_text(ts: Optional[float]=None) -> str: return time.strftime("%Y-%m-%d %H:%M:%S", time.localtime(ts or now_ts()))
def fnum(*vals: Any, default: float=0.0) -> float:
    for v in vals:
        try:
            if v is None or v == "": continue
            return float(str(v).replace(",", "").replace("%", ""))
        except Exception: continue
    return default

def load_json(path: Path, default: Any=None) -> Any:
    try:
        if not path.exists(): return default
        return json.loads(path.read_text(encoding="utf-8", errors="ignore"))
    except Exception: return default

def save_json(path: Path, obj: Any) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    tmp = path.with_suffix(path.suffix + ".tmp")
    tmp.write_text(json.dumps(obj, ensure_ascii=False, separators=(",", ":"), default=str), encoding="utf-8")
    os.replace(tmp, path)

def read_jsonl(path: Path, max_lines: int=1000) -> List[Dict[str, Any]]:
    if not path.exists(): return []
    try:
        lines = path.read_text(encoding="utf-8", errors="ignore").splitlines()
        if max_lines and len(lines) > max_lines: lines = lines[-max_lines:]
        out: List[Dict[str, Any]] = []
        for ln in lines:
            try:
                if ln.strip():
                    o=json.loads(ln)
                    if isinstance(o, dict): out.append(o)
            except Exception: pass
        return out
    except Exception: return []

def append_error(path: Path, where: str, exc: BaseException) -> None:
    try:
        path.parent.mkdir(parents=True, exist_ok=True)
        with path.open("a", encoding="utf-8") as f:
            f.write(f"[{now_text()}] {where}: {exc.__class__.__name__}: {exc}\n")
            f.write(traceback.format_exc()[-1500:] + "\n")
    except Exception: pass

def ticker_norm(x: Any) -> str:
    t = str(x or "").strip().upper().replace("/", "-").replace("_", "-")
    parts = [p for p in t.split("-") if p]
    if len(parts) >= 2:
        non = [p for p in parts if p != "KRW"]
        t = non[-1] if non else parts[-1]
    if t.endswith("KRW") and len(t) > 3: t = t[:-3]
    return t.strip().upper()

def map_rows(obj: Any) -> Dict[str, Dict[str, Any]]:
    if isinstance(obj, dict) and isinstance(obj.get("rows"), list): obj = obj.get("rows")
    elif isinstance(obj, dict) and isinstance(obj.get("rows"), dict): obj = obj.get("rows")
    elif isinstance(obj, dict) and isinstance(obj.get("cache"), dict): obj = obj.get("cache")
    out: Dict[str, Dict[str, Any]] = {}
    if isinstance(obj, list):
        for r in obj:
            if isinstance(r, dict):
                t = ticker_norm(r.get("ticker") or r.get("symbol") or r.get("market"))
                if t: out[t] = r
    elif isinstance(obj, dict):
        for k, v in obj.items():
            t = ticker_norm(k)
            if t and isinstance(v, dict):
                vv = dict(v); vv.setdefault("ticker", t); out[t] = vv
    return out

def write_status(state: str, **extra: Any) -> None:
    save_json(STATUS, {"version": VERSION, "state": state, "pid": os.getpid(), "updated_ts": now_ts(), "updated_text": now_text(), **extra})

def profit(row: Dict[str, Any]) -> float:
    return fnum(row.get("profit_pct"), row.get("return_pct"), row.get("pnl_pct"), row.get("profit_rate"), default=0.0)

def _current_price(ticker: str, fmap: Dict[str, Dict[str, Any]], ofmap: Dict[str, Dict[str, Any]]) -> float:
    f = fmap.get(ticker, {}) or {}
    o = ofmap.get(ticker, {}) or {}
    return fnum(o.get("quote_price"), o.get("current_price"), o.get("price"), f.get("current_price"), f.get("price"), f.get("last_price"), f.get("close"), default=0.0)

def _pct(cur: float, base: float) -> float:
    return round((cur - base) / base * 100.0, 3) if cur and base else 0.0

def _decision(rec: Dict[str, Any], elapsed: float) -> str:
    max_pct = fnum(rec.get("max_pct"), default=0.0)
    cur_pct = fnum(rec.get("current_pct"), default=0.0)
    if max_pct >= 1.20: return "❌ 놓친 후보"
    if max_pct >= 0.70: return "⚠️ 아까운 후보"
    if elapsed >= 1200 and max_pct < 0.30: return "✅ 안 산 게 맞음"
    if elapsed >= 300 and cur_pct <= -0.30 and max_pct < 0.50: return "✅ 안 산 게 맞음"
    return "❔ 추적중"

def _short_reasons(rec: Dict[str, Any]) -> str:
    reasons = rec.get("block_reasons") if isinstance(rec.get("block_reasons"), list) else []
    missing = rec.get("missing_info") if isinstance(rec.get("missing_info"), list) else []
    arr = [str(x) for x in (reasons + missing) if str(x).strip()]
    return " / ".join(arr[:3]) if arr else "-"

def _summ_rows(rows: List[Dict[str, Any]], limit: int = 8) -> List[Dict[str, Any]]:
    rows = sorted(rows, key=lambda r: (fnum(r.get("max_pct"), default=0.0), fnum(r.get("score"), default=0.0)), reverse=True)
    out = []
    for r in rows[:limit]:
        out.append({
            "ticker": r.get("ticker"), "stage": r.get("stage"), "strategy": r.get("strategy"),
            "score": r.get("score"), "decision": r.get("decision"),
            "first_price": r.get("first_price"), "current_price": r.get("current_price"),
            "current_pct": r.get("current_pct"), "max_pct": r.get("max_pct"),
            "after_5m_pct": r.get("after_5m_pct"), "after_10m_pct": r.get("after_10m_pct"), "after_20m_pct": r.get("after_20m_pct"),
            "reasons": _short_reasons(r),
        })
    return out

def _reason_top(rows: List[Dict[str, Any]], limit: int = 8) -> List[Dict[str, Any]]:
    cnt: Dict[str, int] = {}
    for r in rows:
        for x in (r.get("block_reasons") or []):
            key = str(x).split()[0].strip() or str(x).strip()
            if key: cnt[key] = cnt.get(key, 0) + 1
    return [{"reason": k, "count": v} for k, v in sorted(cnt.items(), key=lambda kv: kv[1], reverse=True)[:limit]]

def _legacy_closed_summary() -> Dict[str, Any]:
    rows = read_jsonl(CLOSED, max_lines=900)
    def pnl(r: Dict[str, Any]) -> float: return fnum(r.get("pnl_pct"), r.get("profit_pct"), default=0.0)
    def peak(r: Dict[str, Any]) -> float: return fnum(r.get("peak_pct"), r.get("max_profit_pct"), default=0.0)
    protect_needed=[]; fast_fail=[]; good_keep=[]
    for r in rows[-120:]:
        pk=peak(r); pn=pnl(r); give=max(0.0, pk-pn)
        if pk >= 0.70 and (pn < 0 or give >= 0.55):
            protect_needed.append({"ticker": ticker_norm(r.get("ticker")), "peak_pct": pk, "pnl_pct": pn, "giveback_pct": round(give,3), "reason": r.get("exit_reason"), "tag": r.get("close_review_tag") or "보호익절 필요 후보"})
        elif pn <= -0.60 and pk < 0.25:
            fast_fail.append({"ticker": ticker_norm(r.get("ticker")), "peak_pct": pk, "pnl_pct": pn, "giveback_pct": round(give,3), "reason": r.get("exit_reason"), "tag": r.get("close_review_tag") or "빠른실패 정리 후보"})
        elif pn > 0 and pk-pn <= 0.35:
            good_keep.append({"ticker": ticker_norm(r.get("ticker")), "peak_pct": pk, "pnl_pct": pn, "giveback_pct": round(give,3), "reason": r.get("exit_reason"), "tag": r.get("close_review_tag") or "수익 보존 양호"})
    big_loss = sorted([r for r in rows if profit(r) <= -0.8], key=profit)[:10]
    good_win = sorted([r for r in rows if profit(r) >= 1.0], key=profit, reverse=True)[:10]
    return {"closed_recent": len(rows), "big_loss": len(big_loss), "good_win": len(good_win), "close_review": {"protect_needed_count": len(protect_needed), "fast_fail_count": len(fast_fail), "good_keep_count": len(good_keep), "protect_needed": protect_needed[-5:], "fast_fail": fast_fail[-5:], "good_keep": good_keep[-5:]}}


def run_once() -> Dict[str, Any]:
    st = now_ts(); write_status("running", phase="refreshing", last_sec=0)
    queue = load_json(QUEUE, {}) or {}
    qrows = queue.get("review_candidates") if isinstance(queue, dict) and isinstance(queue.get("review_candidates"), list) else []
    state = load_json(STATE, {}) or {}
    active = state.get("active") if isinstance(state.get("active"), dict) else {}
    fmap = map_rows(load_json(FEATURE, {}) or {})
    ofmap = map_rows(load_json(ORDERFLOW, {}) or {})
    nowv = now_ts()
    ttl = max(3600.0, RETENTION_DAYS * 86400.0)
    # 오래된 비핵심 복기 state만 제거. paper 장부는 삭제하지 않음.
    active = {k:v for k,v in active.items() if isinstance(v, dict) and nowv - fnum(v.get("first_seen_ts"), default=nowv) <= ttl}

    for c in qrows:
        if not isinstance(c, dict): continue
        stage = str(c.get("stage") or "").upper()
        if stage not in ("S2", "S3"): continue
        t = ticker_norm(c.get("ticker"))
        if not t: continue
        cur = _current_price(t, fmap, ofmap)
        base = fnum(c.get("snapshot_price"), c.get("price"), default=0.0) or cur
        rec = active.get(t) or {
            "ticker": t, "first_seen_ts": nowv, "first_seen_text": now_text(nowv),
            "first_price": base, "min_pct": 0.0, "max_pct": 0.0, "samples": {},
        }
        rec.update({
            "stage": stage, "strategy": c.get("strategy"), "strategy_key": c.get("strategy_key"),
            "score": c.get("score"), "block_reasons": c.get("block_reasons", []),
            "missing_info": c.get("missing_info", []), "metrics": c.get("metrics", {}),
            "last_seen_ts": nowv, "last_seen_text": now_text(nowv),
        })
        if not fnum(rec.get("first_price"), default=0.0) and base:
            rec["first_price"] = base
        if cur:
            rec["current_price"] = cur
            cp = _pct(cur, fnum(rec.get("first_price"), default=0.0))
            rec["current_pct"] = cp
            rec["max_pct"] = max(fnum(rec.get("max_pct"), default=cp), cp)
            rec["min_pct"] = min(fnum(rec.get("min_pct"), default=cp), cp)
            elapsed = nowv - fnum(rec.get("first_seen_ts"), default=nowv)
            samples = rec.get("samples") if isinstance(rec.get("samples"), dict) else {}
            for label, sec in (("5m",300),("10m",600),("20m",1200)):
                if elapsed >= sec and label not in samples:
                    samples[label] = {"ts": nowv, "text": now_text(nowv), "price": cur, "pct": cp}
                    rec[f"after_{label}_pct"] = cp
            rec["samples"] = samples
            rec["decision"] = _decision(rec, elapsed)
        active[t] = rec

    all_rows = list(active.values())
    missed = [r for r in all_rows if str(r.get("decision")) == "❌ 놓친 후보"]
    regret = [r for r in all_rows if str(r.get("decision")) == "⚠️ 아까운 후보"]
    correct = [r for r in all_rows if str(r.get("decision")) == "✅ 안 산 게 맞음"]
    pending = [r for r in all_rows if str(r.get("decision")) not in ("❌ 놓친 후보", "⚠️ 아까운 후보", "✅ 안 산 게 맞음")]
    legacy = _legacy_closed_summary()
    summary = {
        "schema": "missed_review_summary_v439",
        "version": VERSION,
        "updated_ts": nowv, "updated_text": now_text(nowv),
        "queue_age_sec": round(nowv - fnum(queue.get("updated_ts"), default=nowv), 1) if isinstance(queue, dict) else None,
        "tracking_total": len(all_rows), "queue_candidates": len(qrows),
        "missed_count": len(missed), "regret_count": len(regret), "correct_count": len(correct), "pending_count": len(pending),
        "missed": _summ_rows(missed, 8), "regret": _summ_rows(regret, 8), "correct": _summ_rows(correct, 5), "pending": _summ_rows(pending, 8),
        "missed_reason_top": _reason_top(missed + regret, 8),
        "policy": "S2/S3 상위 후보를 5분/10분/20분 뒤 자동 추적한다. 조건/청산숫자 변경 없음. paper 장부 삭제 없음. 청산복기는 최고수익 대비 최종손익만 집계한다.",
        **legacy,
    }
    save_json(STATE, {"schema":"missed_review_state_v439", "version":VERSION, "updated_ts":nowv, "active":active})
    save_json(SUMMARY, summary)
    save_json(OLD_SUMMARY, {"version":VERSION, "updated_ts":nowv, "updated_text":now_text(nowv), **legacy, "missed_review": summary})
    sec = now_ts() - st
    write_status("running", tracked=len(all_rows), missed=len(missed), regret=len(regret), correct=len(correct), pending=len(pending), closed_recent=legacy.get("closed_recent",0), big_loss=legacy.get("big_loss",0), good_win=legacy.get("good_win",0), last_sec=round(sec,3))
    return {"tracked": len(all_rows), "missed": len(missed), "regret": len(regret), "correct": len(correct)}

def main() -> None:
    write_status("initializing")
    while True:
        try: run_once()
        except KeyboardInterrupt: write_status("stopping"); raise
        except Exception as exc:
            append_error(ERROR, "loop", exc); write_status("error", error=f"{exc.__class__.__name__}: {exc}")
        time.sleep(max(10.0, INTERVAL_SEC))

if __name__ == "__main__": main()
