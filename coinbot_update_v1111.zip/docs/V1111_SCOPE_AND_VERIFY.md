# v1111 Strategy canonical restart fresh-proof

## Symptom
v1110 copied `strategy_worker_v1.003.py` and started a new MainPID, but the deployment verifier accepted the previous v1.002 status row. The report therefore showed new MainPID 4016271 while statusPID stayed 3825996 and lockPID was 0.

## Root cause
The v1110 custom stop/start branch reused an age-based ready reader. A recently written status from the old process could satisfy that reader before the new process completed its first cycle. The immediate `/proc` scan could also miss the just-started alias process.

## Change
- Restore the established worker deployment mainline: `cleanup_direct_worker_pids -> systemctl restart`.
- Keep the Strategy process-level flock singleton from v1110.
- Use the systemd MainPID even if the immediate `/proc` scan has not found the alias yet.
- Require a status and singleton record written after this restart request.
- Require target version `strategy_worker_v1.004`.
- Require `MainPID = statusPID = lockPID = the only matching live PID`.
- Wait up to 65 seconds so the first completed Strategy cycle can publish status.
- On timeout, report every failed axis and the service journal tail.

## Not changed
Strategy thresholds, trigger/invalid/target, actual-entry RR, slippage limits, OPEN 30/cycle 3, exit contracts, Paper logic and auto-buy OFF.

## Server verification
1. Run `/gupgrade_bundle` alone.
2. After completion, run `/gops_refresh` in Guard.
3. Run `/flow_map` and `/errorlog` together in Main.

Expected Strategy apply proof:
- target/status/lock version: `strategy_worker_v1.004`
- exactly one Strategy PID
- MainPID = statusPID = lockPID
- runtime mismatch 0
- WORKER_MULTI_INSTANCE 0
