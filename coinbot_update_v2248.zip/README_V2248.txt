코인봇 v2248 — 환경 주인·Paper 재시작·가드 이어가기 근본수리

확인된 원인
- 7일 기준 정리 중 공용 guard.env가 삭제됐다.
- 메인 프로세스의 환경값을 공용 guard.env에 복구하면서 Main/Paper/Guard/Review에 메인 토큰이 퍼져 409 Conflict와 명령·OPEN 알림 주인 충돌이 발생했다.
- v2247 Paper 검증은 종료 전 zero=False를 TERM/KILL 뒤 다시 계산하지 않아 새 Paper가 정상이어도 CHECK가 고정됐고, 상세 원인을 fresh status 없음으로 잘못 표시했다.
- Guard 재시작 뒤 bundle 이어가기가 Telegram polling 메인 스레드에서 동기 실행돼 최종결과 전까지 가드 명령 반응이 늦어졌다.

수정
1. main.env/guard.env/paper.env/review.env/common.env와 systemd drop-in을 정식 주인으로 검증·고정.
2. 토큰 원문은 읽거나 출력하지 않고 키 주인만 증명. ZIP에는 토큰·env 값 없음.
3. Paper는 마지막 KILL 뒤 종료 0개를 다시 검사하고 남으면 새 시작 금지. 실제 reasons 표시.
4. owner_ok 반복줄은 건수 요약, 오류만 상세 표시.
5. 기존 release-priority thread를 재사용해 Guard Telegram polling을 막지 않음.
6. 모든 *.env, service/drop-in owner config, deployed marker는 Guard 디스크 정리 절대 보호.
7. 앞으로 Paper unit은 paper.env, Review는 review.env, 다른 worker/sidecar는 common.env 사용.
8. Review 최근 봉인 exact 최대 500건·전체시간 상한판정 없음 유지.

전략·후보·상승예측·진입·청산·OPEN/CLOSED/decision/exact는 변경하지 않는다. 자동매수 OFF.
