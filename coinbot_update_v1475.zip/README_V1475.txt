coinbot v1475 - canonical pipeline fixed active filenames

Purpose
- Remove release numbers from active runtime status filenames and current pipeline keys.
- Strategy active writer: candidate_material_source_status.json
- Paper active writer: paper_candidate_pipeline_status.json
- Paper append-only ledger: paper_candidate_pipeline_ledger.jsonl
- Main active reader: paper_candidate_pipeline_status.json only
- Retire active writes for superseded v1465 owner and v1470/v1471 material status files.
- Preserve all old files as legacy history; do not delete or rewrite ledgers.

Candidate order
S3 observe -> S2 recheck -> newly evaluated S1 -> Paper -> trigger -> safety -> selected -> OPEN.
S2 never opens directly.

Locks
ALT_SWING unchanged. Auto-buy OFF. No Gate/TTL/RR/trigger/invalid/target/OPEN/exit contract change.
