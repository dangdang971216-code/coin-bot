v1625 fixes Paper refresh ACK -> final-safety reuse bottleneck. No thresholds changed. Auto-buy OFF.
