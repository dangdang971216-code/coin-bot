coinbot update v1426
- 후보 시간 문제 원인을 /handoff_delay 로 분리 표시한다.
- 품질→S1, S1→Paper 지연 구간과 owner를 보여준다.
- 큰 손실이 익절을 지우는 문제를 /exit_shadow 로 shadow 비교한다.
- 실제 Gate/TTL/RR/trigger/invalid/target/청산/OPEN limit/자동매수는 변경하지 않는다.
