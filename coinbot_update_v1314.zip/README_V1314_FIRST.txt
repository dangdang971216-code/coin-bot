v1314 fixes Paper NameError from v1311 no-limit shadow read_json call, keeps v1313 disk archive policy, no strategy changes.
