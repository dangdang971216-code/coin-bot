#!/usr/bin/env python3
from __future__ import annotations
import importlib.util
import sys
from pathlib import Path

BASE = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(BASE))

def load(name: str, path: Path):
    spec = importlib.util.spec_from_file_location(name, path)
    mod = importlib.util.module_from_spec(spec)
    assert spec and spec.loader
    sys.modules[name] = mod
    spec.loader.exec_module(mod)
    return mod

sp1187 = load('sp1187_v1245_test', BASE/'canonical_spine_v1187.py')
sp1190 = load('sp1190_v1245_test', BASE/'canonical_spine_v1190.py')
row = {
    's_stage': 'S1',
    'candidate_grade': 'S1',
    'swing_entry_gate_v977': {'stage': 'S2'},
    'stage': 'S2',
}
assert sp1187.stage(row) == 'S1', sp1187.stage(row)
assert sp1190.stage(row) == 'S1', sp1190.stage(row)

review = load('review_v1245_test', BASE/'review_worker_v1.032.py')
prior = {'snapshot_id':'snap-old','source':{'pipeline_cycle_id':'cycle-old','candidate_commit_id':'commit-old'},'candidate':{'total':463}}
wait = review._v1245_nonprocessed_heartbeat({
    'processed':False,
    'reason':'waiting_for_completed_generation',
    'check':'v1241 S1 mismatch request=22 canonical=12',
    'candidate_rows':None,
}, prior)
assert wait['health_state'] == 'CHECK', wait
assert wait['phase'] == 'waiting_for_completed_generation', wait
assert 'S1 mismatch' in wait['generation_alignment_error_v1245'], wait

idle = review._v1245_nonprocessed_heartbeat({
    'processed':False,
    'reason':'same_committed_generation_live_price_refresh_only',
    'candidate_rows':463,
}, prior)
assert idle['health_state'] == 'NORMAL', idle
assert idle['candidate_rows'] == 463, idle

main_source=(BASE/'coinbot_main_v2_13_1153.py').read_text(encoding='utf-8')
assert '수익형 v2.13.1153' in main_source
assert 'Review 직전 완료 후보 전달' in main_source
assert 'auto_buy = True' not in main_source
print('PASS 8/8')
