from pathlib import Path
import ast, importlib.util, tempfile

source = Path('strategy_worker_v1.034.py')
text = source.read_text(encoding='utf-8')
assert "VERSION = 'strategy_worker_v1.034'" in text
assert "BUILD_LABEL = 'v1179_execution_handoff_before_observation_2026-07-01'" in text
assert '_v1037_trigger_occurrence__v1170_recovery' not in text
assert 'def _v1177_current_cycle_occurrence' in text
assert 'execution_handoff_before_observation_v1179' in text
assert 'post_handoff_observation_sec_v1179' in text

module = ast.parse(text)
fn = next(n for n in module.body if isinstance(n, ast.FunctionDef) and n.name == '_v510_publish')
body = ast.get_source_segment(text, fn)
order = {
    'gate': body.index("'swing_entry_gate'"),
    'keys': body.index("'seal_exact_keys'"),
    's1': body.index("'s1_hold_commit_v1148'"),
    'candidate': body.index('_v1021_publish_candidate_snapshot(PAPER_LATEST'),
    'handoff': body.index('_v1158_commit_paper_handoff('),
    'pipeline_normal': body.index("_v1150_write_pipeline_status(\n        _v1150_pipeline_cycle_id, 'NORMAL'"),
    'smart': body.index("'smart_structure_shadow'"),
    'lab': body.index("'structure_lab'"),
    'hot': body.index("'hot_watch_timing_v1148'"),
    'good_s2': body.index("'good_s2_lifecycle_v1148'"),
}
assert order['gate'] < order['keys'] < order['s1'] < order['candidate'] < order['handoff'] < order['pipeline_normal']
assert order['pipeline_normal'] < order['smart'] < order['lab'] < order['hot'] < order['good_s2']

# v1177 lifecycle repair must remain active.
spec = importlib.util.spec_from_file_location('strategy_v1179', source)
mod = importlib.util.module_from_spec(spec); spec.loader.exec_module(mod)
rec = {'frozen_ts': 1000.0, 'trigger_occurrence_event_ts_v1170': 1.0,
       'trigger_occurrence_decision_key_v1037': 'old', 's1_ready_ts_v1173': 2.0,
       'trigger_side_v1037': 'above'}
occ1, key1 = mod._v1177_current_cycle_occurrence(rec, 'market:TEST', 110.0, 100.0, 2000.0)
occ2, key2 = mod._v1177_current_cycle_occurrence({'frozen_ts': 2001.0}, 'market:TEST', 110.0, 100.0, 2001.0)
assert occ1['event_ts'] == 2000.0 and occ1['prior_cycle_event_carried'] is False
assert key1 != key2 and occ2['event_ts'] == 2001.0
assert 'trigger_occurrence_event_ts_v1170' not in rec and 's1_ready_ts_v1173' not in rec
print('PASS')
