from pathlib import Path
import json, hashlib, py_compile
root=Path('.')
manifest=json.loads((root/'DEPLOY_BUNDLE.json').read_text(encoding='utf-8'))
assert manifest['version']=='v1179'
assert manifest['workers']['strategy']=='strategy_worker_v1.034.py'
assert manifest['paper'] is None and manifest['review'] is None
assert manifest['v1178_included'] is False
for name in manifest.get('support_files', []):
    assert (root/name).exists(), f'missing support file: {name}'
source=root/'strategy_worker_v1.034.py'
hashv=hashlib.sha256(source.read_bytes()).hexdigest()
assert manifest['source_sha256'][source.name]==hashv
text=source.read_text(encoding='utf-8')
assert "VERSION = 'strategy_worker_v1.034'" in text
assert 'execution_handoff_before_observation_v1179' in text
assert text.index("_v1158_commit_paper_handoff(", text.index('def _v510_publish')) < text.index("'smart_structure_shadow'", text.index('def _v510_publish'))
py_compile.compile(str(source),doraise=True)
print('PASS')
