# v1139 scope

- Separate current reset batch proof from historical cumulative operator-reset statistics.
- Current batch source: Paper canonical `paper_quality_rebuild_*_v1095` generation.
- Historical cumulative source: canonical performance `reset_transition_v1045`.
- Add the same scope contract to Guard full map.
- Append server DONE events for v1136/v1137/v1138 mechanisms only when their exact evidence is present.
- Keep v1133/v1135 and profitability recovery CHECK until natural fresh-path and fresh CLOSED evidence exist.

## Not changed

Strategy/Paper source, Gate, rank, TTL, invalid, target, trailing, OPEN 30, cycle 3, exit contract, protected ledgers, auto-buy OFF.
