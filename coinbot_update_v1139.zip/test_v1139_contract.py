from __future__ import annotations
import ast, collections, json, tempfile
from pathlib import Path
from typing import Any, Dict, Optional, List

ROOT=Path(__file__).resolve().parent
MAIN=ROOT/'coinbot_main_v2_13_1106.py'
GUARD=ROOT/'backga_guard_bot_v2_5_180.py'

def load_funcs(path: Path, names: set[str], ns: dict):
    src=path.read_text(encoding='utf-8')
    tree=ast.parse(src)
    nodes=[n for n in tree.body if isinstance(n,(ast.FunctionDef,ast.AsyncFunctionDef)) and n.name in names]
    found={n.name for n in nodes}
    missing=names-found
    assert not missing, missing
    mod=ast.Module(body=nodes,type_ignores=[])
    ast.fix_missing_locations(mod)
    exec(compile(mod,str(path),'exec'),ns)

with tempfile.TemporaryDirectory() as td:
    base=Path(td)
    paths={
        'status':base/'paper_quality_rebuild_status_v1095.json',
        'manifest':base/'paper_quality_rebuild_manifest_v1095.json',
        'execution':base/'paper_quality_rebuild_execution_v1095.json',
        'epoch':base/'paper_quality_rebuild_epoch_v1095.json',
    }
    paths['status'].write_text(json.dumps({'batch_id':'batch-new','target_open_count':30,'already_exact_closed_count':30,'remaining_target_open_count':0,'unresolved_target_count':0,'last_pass_failed':0}),encoding='utf-8')
    paths['manifest'].write_text(json.dumps({'batch_id':'batch-new','targets':[{}]*30}),encoding='utf-8')
    paths['execution'].write_text(json.dumps({'batch_id':'batch-new','failed':0}),encoding='utf-8')
    paths['epoch'].write_text(json.dumps({'epoch_id':'post-reset:batch-new','reset_batch_id':'batch-new','zero_open_proof':True,'state':'ACTIVE'}),encoding='utf-8')
    def load_json(path,default):
        try:return json.loads(Path(path).read_text(encoding='utf-8'))
        except Exception:return default
    snapshot={
        'snapshot_id':'perf-test',
        'reset_transition_v1045':{'rows':228,'stats':{'total':16.77}},
        'performance_epoch_v1045':{'epoch_id':'post-reset:batch-new','reset_batch_id':'batch-new','state':'ACTIVE','zero_open_proof':True,'current_open_count':1,'windows':{'all':{'n':0,'wins':0,'losses':0,'total':0.0,'avg':0.0},'recent_24h':{'n':0,'total':0.0}}}
    }
    ns={'Any':Any,'Dict':Dict,'Optional':Optional,'List':List,'load_json':load_json,
        'PAPER_BOOK_RESET_STATUS_V1044':paths['status'],'PAPER_BOOK_RESET_MANIFEST_V1044':paths['manifest'],
        'PAPER_BOOK_RESET_EXECUTION_V1045':paths['execution'],'PAPER_PERFORMANCE_EPOCH_V1045':paths['epoch'],
        'canonical_performance_snapshot_v987':lambda:snapshot}
    load_funcs(MAIN,{'_v1139_reset_count_scope_contract','_v1045_epoch_lines'},ns)
    c=ns['_v1139_reset_count_scope_contract'](snapshot)
    assert c['state']=='NORMAL' and c['current_batch_exact_closed_count']==30 and c['historical_operator_reset_rows']==228
    lines='\n'.join(ns['_v1045_epoch_lines'](snapshot))
    assert '현재 reset batch batch-new · 대상 30 / exact CLOSED 30' in lines
    assert '과거 운영자 정리청산 누적 228건' in lines
    assert '기존 OPEN 정리청산 228건' not in lines

    # Guard reads the same owners and reports the same split.
    (base/'canonical_performance_snapshot_v987.json').write_text(json.dumps(snapshot),encoding='utf-8')
    def read_json(path):
        try:return json.loads(Path(path).read_text(encoding='utf-8'))
        except Exception:return {}
    gns={'BOT_DIR':base,'_ops_read_json':read_json}
    load_funcs(GUARD,{'_ops_reset_count_scope_contract_v1139'},gns)
    gc=gns['_ops_reset_count_scope_contract_v1139']()
    assert gc['state']=='NORMAL' and gc['current_batch_target_count']==30 and gc['historical_operator_reset_rows']==228
    assert gc['scope_relation']=='DIFFERENT_SCOPES_EXPECTED'

# Active targeted definitions must be single-owner, not appended duplicates.
for path,names in [(MAIN,{'_v1045_epoch_lines','render_version_score_text__L46123','render_flow_map_full_text__v1137','_v1139_reset_count_scope_contract'}),
                   (GUARD,{'_ops_reset_count_scope_contract_v1139','collect_ops_map_snapshot'})]:
    tree=ast.parse(path.read_text(encoding='utf-8'))
    counts=collections.Counter(n.name for n in tree.body if isinstance(n,(ast.FunctionDef,ast.AsyncFunctionDef)))
    for name in names:
        assert counts[name]==1,(path.name,name,counts[name])

mt=MAIN.read_text(encoding='utf-8'); gt=GUARD.read_text(encoding='utf-8')
assert "BOT_VERSION = '수익형 v2.13.1106'" in mt
assert 'v1139_reset_count_scope_truth_closeout' in mt
assert 'guard_v2.5.180_reset_count_scope_map_v1139' in gt
assert 'RESET_COUNT_SCOPE_MIXED' in gt
assert "'reader_owner_contracts_v1139'" in gt
assert 'Paper v1.023' in mt and 'Strategy v1.011' in mt
assert 'quality Gate/rank' in mt and 'OPEN 30/cycle 3' in mt and 'auto-buy OFF' in mt
print('V1139_CONTRACT_PASS')
