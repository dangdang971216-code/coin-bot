코인봇 v2102 · Paper 시작상태 인계 실패 수리

현재 원인
- v2101 소스와 새 PID는 살아 있었지만 canonical status는 종료된 v2.056 PID/build에 머물렀다.
- 표시된 copy NameError는 2026-07-13 과거 로그이며 현재 소스에는 import copy가 있다.
- 실제 문제는 v2101 기존 OPEN 전환이 module load에서 먼저 실행되어 main의 새 PID/version/build 상태 공개보다 앞섰던 순서다.

수정
- Paper v2.058은 시작 즉시 새 PID/version/build를 canonical status에 먼저 기록한다.
- 그 다음 v2101 기존 OPEN overlay 전환을 1회 실행한다.
- 전환 완료를 다시 status에 기록한 뒤 첫 후보 cycle·청산 sweep을 시작한다.
- 전환 실패 시 running=false와 현재 오류를 새 PID status에 남기고 fail-closed 한다.

전략 변경 없음
- 최고 비용후 +2.0% 후 비용후 0.0% 이하 최종막 그대로
- v2100 -4% 안전막 그대로
- target·invalid·trailing·Runner 연구 그대로
- 기존 원장 재작성 없음
- 자동매수 OFF

검수
1) Guard에서 /gupgrade_bundle coinbot_update_v2102.zip 단독
2) 이어서 /grelease_verify
3) Paper에서 /pstatus, /perror
