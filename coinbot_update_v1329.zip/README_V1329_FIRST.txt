v1329 SCORE REASON AUDIT READONLY

목적:
- /score_reason_audit 추가
- invalid 손실군과 swing_trailing 수익군의 진입 당시 점수 구성 비교

변경 없음:
- 후보식, trigger, invalid, target, RR, 청산계약, Paper 실행, 자동매수
- 라이브 OPEN/CLOSED/decision 원장 포함 없음

적용 후:
- guard: /grelease_verify
- main: /score_reason_audit /version_score
