v1268 적용 전 확인
- 목적: v1267 hard block 해제 + 단순 구조선 T1 재기준
- 자동매수 OFF 유지
- 기존 원장 재작성 없음
- 적용 후 /gdeploy /grelease_verify /gstructure_case_audit /gledger_v1268 확인
