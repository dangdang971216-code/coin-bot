from pathlib import Path
text=Path('paper_bot_v1.081.py').read_text(encoding='utf-8')
assert "VERSION = 'paper_bot_v1.081'" in text
assert 'entry_quality_material_shadow_only_v1268' in text
assert "add_reason_v1122('ENTRY_QUALITY_MATERIAL_BLOCK'" not in text
assert "'ENTRY_QUALITY_MATERIAL_BLOCK'," not in text
assert "'required_for_new_open': False" in text
