from pathlib import Path
text=Path('backga_guard_bot_v2_5_246.py').read_text(encoding='utf-8')
assert 'guard_v2.5.246_v1268_simple_structure_rebase_2026-07-06' in text
assert 'def gledger_v1268_text()' in text
assert '/gledger_v1268' in text
