import json
from pathlib import Path
b=json.loads(Path('DEPLOY_BUNDLE.json').read_text(encoding='utf-8'))
assert b['release']=='v1268'
assert b['paper']=='paper_bot_v1.081.py'
assert b['workers']['strategy']=='strategy_worker_v1.065.py'
assert b['guard']=='backga_guard_bot_v2_5_246.py'
assert b['auto_buy'] is False
assert b['paper_entry_quality_material_required_for_new_open'] is False
assert b['target_selection_changed'] is True
assert b['historical_trade_ledgers_rewritten'] is False
