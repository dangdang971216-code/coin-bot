from pathlib import Path
text=Path('strategy_worker_v1.065.py').read_text(encoding='utf-8')
assert 'strategy_worker_v1.065' in text
assert 'structure_contract_v1268_simple_t1_rebase' in text
assert 'simple_t1_rebase_v1268' in text
assert 'middle_resistance_as_t1_target_v1268' in text
assert 'eligible = list(passing) if cost_complete else []' in text
assert 'minimum_final_target_room = V925_MIN_TARGET_ROOM_PCT' in text
assert 'normal_noise * 0.35' in text
