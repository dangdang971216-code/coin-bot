# v1107 전체 20단계 오류위치 계약

## 원인
v1106은 Risk와 Paper RSS에는 상세 원인 체인이 있었지만, 다른 runtime·resource·ledger·stage 오류는 큰 구역만 표시될 수 있었다. 지도는 모든 오류에서 정확한 문제 위치를 먼저 제시해야 한다.

## 수정
- 20개 lifecycle stage 각각에 owner/caller/writer/reader/artifact/input/output/fix-files 계약 추가
- 17개 데이터 연결에 upstream/downstream 단계 번호와 location_id 추가
- 모든 문제에 map_location 부착
- runtime은 worker별, ledger는 파일별로 문제 생성
- 비정상 stage는 반드시 STAGE_STATE_FAILURE 인덱스 생성
- 위치확실성과 원인확실성 분리
- Main TXT/FULL에 지도위치·흐름·writer/reader·artifact·수정파일·재검수 표시

## 변경하지 않은 영역
- Strategy/Paper/Risk/Review 매매 로직
- 품질 threshold
- actual-entry RR·spread·slippage 계약
- OPEN 30 / cycle 3
- trigger·invalid·target
- 청산계약
- 핵심 원장
- 자동매수 OFF

## 서버 검수
- Guard: `/gops_refresh`
- Main 같은 메시지: `/flow_map` + `/errorlog`
- 기대값: stage contract 20/20, unmapped problem 0
