v1713: PREOPEN WAIT Korean explanation + trigger late root-cause payload. Auto-buy OFF.
