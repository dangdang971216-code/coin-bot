coinbot_update_v1436.zip

목적: 5% 이상 수익을 먹는 runner를 놓치거나 너무 빨리 자르는지 shadow로 추적합니다.

변경:
- Main: /profit_shadow /upside_shadow /runner_shadow /missed_profit_shadow /profit_shadow_diag 추가
- Paper: paper_profit_shadow_contract_status.json 및 paper_profit_shadow_contract_ledger.jsonl 작성

금지/잠금:
- 실제 target/trailing/청산계약 변경 없음
- 후보 S1/S2/S3 흐름 변경 없음
- Paper 실제 진입/OPEN limit 변경 없음
- OPEN/CLOSED/decision/exact 원장 재작성 없음
- 자동매수 OFF
