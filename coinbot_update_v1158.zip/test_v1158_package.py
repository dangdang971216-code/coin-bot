#!/usr/bin/env python3
from pathlib import Path
import hashlib,json
R=Path(__file__).resolve().parent
for line in (R/'FILES_SHA256_v1158.tsv').read_text().splitlines():
 if line.strip():
  d,n=line.split('\t',1);p=R/n;assert p.is_file() and hashlib.sha256(p.read_bytes()).hexdigest()==d,n
for p in R.rglob('*'):
 if p.is_file():
  x=str(p.relative_to(R)).lower();assert not any(y in x for y in ('paper_bot_open.json','paper_bot_closed.jsonl','paper_trade_log.json','decision_state','.log','__pycache__')),x
b=json.loads((R/'DEPLOY_BUNDLE.json').read_text());assert b['workers']['strategy']=='strategy_worker_v1.021.py' and b['paper']=='paper_bot_v1.032.py' and b['guard']=='backga_guard_bot_v2_5_192.py' and b['main']=='coinbot_main_v2_13_1118.py' and b['auto_buy'] is False
print('PASS v1158 package')
