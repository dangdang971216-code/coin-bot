# V1158 확정 원인

Strategy의 live S1, candidate, priority는 서로 다른 시점에 갱신된다. 기존 Paper gate는 현재 commit만 NORMAL인지 검사했으며, 다음 cycle 작성 중에는 직전 완료 generation을 소비할 수 없었다. 단일 overwrite handoff도 pointer 갱신과 파일 교체 사이에 race가 남으므로, V1158은 generation별 불변 파일을 만든다. Paper는 commit 또는 last_complete가 가리키는 정확한 파일을 한 번 읽고 내용 digest까지 검증한다.
