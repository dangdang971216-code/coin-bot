# V1158 작업 잠금

- 증상: Strategy 완료 S1 1개와 Paper 평가 0개가 Strategy IN_PROGRESS 구간에서 발생
- 원인: live S1은 final commit 전에 다음 cycle로 교체되고, Paper는 current NORMAL만 허용해 직전 완료 generation의 불변 원본이 없음
- 삭제 경로: live S1 직접 소비, current commit NORMAL-only 판정
- 새 본선: generation별 immutable handoff 파일 + commit/last_complete가 가리키는 exact file 단일 read
- 보존: 최근 4개 transient generation만 유지; 거래원장 미접촉
- 전략 영향: 없음. Gate·TTL·RR·spread·slippage·trigger·invalid·target·재진입·청산·한도 불변
