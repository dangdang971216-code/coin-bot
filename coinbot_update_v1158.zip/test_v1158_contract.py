#!/usr/bin/env python3
from pathlib import Path
import ast,hashlib,json,tempfile
from typing import Any,Dict,List,Tuple,Optional
ROOT=Path(__file__).resolve().parent; S=ROOT/'strategy_worker_v1.021.py'; P=ROOT/'paper_bot_v1.032.py'
for x in (S,P):compile(x.read_text(),str(x),'exec')
def funcs(path):
 m=ast.parse(path.read_text());return {n.name:n for n in m.body if isinstance(n,ast.FunctionDef)}
exp=json.loads((ROOT/'tests/fixtures/V1158_TRADING_FUNCTION_AST_SHA256.json').read_text())
for path,key in ((S,'strategy'),(P,'paper')):
 f=funcs(path)
 for n,d in exp[key].items():assert hashlib.sha256(ast.dump(f[n],include_attributes=False).encode()).hexdigest()==d,n
sf=funcs(S);pf=funcs(P)
with tempfile.TemporaryDirectory() as td:
 td=Path(td); d=td/'gens'
 def save_json(path,obj):Path(path).parent.mkdir(parents=True,exist_ok=True);Path(path).write_text(json.dumps(obj))
 ns={'Dict':Dict,'Any':Any,'Optional':Optional,'hashlib':hashlib,'json':json,'now_ts':lambda:100.0,'now_text':lambda ts:'x','VERSION':'s','BUILD_LABEL':'b','save_json':save_json,'STRATEGY_PAPER_HANDOFF_DIR_V1158':d}
 exec(compile(ast.Module(body=[sf['_v1158_commit_paper_handoff']],type_ignores=[]),str(S),'exec'),ns)
 h={'candidate_pipeline_cycle_id_v1150':'C1','rows':[{'ticker':'AAA'}]};o=ns['_v1158_commit_paper_handoff']('C1','K1',h,461,2,1,95)
 assert Path(o['handoff_file_v1158']).is_file() and o['s1_hold_count']==1
 # commit points to immutable C1 while current C2 is in progress
 commitf=td/'commit.json'; commitf.write_text(json.dumps({'state':'STARTED','cycle_id':'C2','current_cycle_in_progress_v1152':True,'last_complete_cycle_v1152':{'state':'NORMAL','cycle_id':'C1','candidate_commit_id':'K1','completed_ts':95,'committed_handoff_id_v1158':o['handoff_id_v1158'],'committed_handoff_digest_v1158':o['digest_v1158'],'committed_handoff_file_v1158':o['handoff_file_v1158'],'committed_handoff_completed_ts_v1158':95}}))
 def load_json(path,default):
  try:return json.loads(Path(path).read_text())
  except:return default
 def fnum(*vals,default=0.0):
  for v in vals:
   try:
    if v not in (None,''):return float(v)
   except:pass
  return default
 ns2={'Dict':Dict,'Any':Any,'Optional':Optional,'Tuple':Tuple,'List':List,'Path':Path,'hashlib':hashlib,'json':json,'now_ts':lambda:100.0,'load_json':load_json,'fnum':fnum,'STRATEGY_PIPELINE_COMMIT_V1150':commitf}
 exec(compile(ast.Module(body=[pf['_v1158_handoff_content_digest'],pf['_v1158_resolve_completed_handoff_v1158'],pf['strategy_candidate_pipeline_ready_v1150'],pf['candidate_sources']],type_ignores=[]),str(P),'exec'),ns2)
 gate,obj=ns2['_v1158_resolve_completed_handoff_v1158']({'candidate_ttl_sec':120});assert gate['ready'] and gate['effective_generation_source_v1158']=='LAST_COMPLETE_WHILE_CURRENT_IN_PROGRESS'
 rows=ns2['candidate_sources']({},obj)[0][2];assert len(rows)==1 and rows[0]['paper_consumed_pipeline_cycle_id_v1158']=='C1'
 # content tamper must fail digest proof
 q=Path(o['handoff_file_v1158']);bad=json.loads(q.read_text());bad['s1_rows'].append({'ticker':'BAD'});q.write_text(json.dumps(bad));assert ns2['_v1158_resolve_completed_handoff_v1158']({})[0]['ready'] is False
pt=P.read_text();assert 'paper_s1_hold_cache.json` remains current-cycle inventory' in pt and 'handoff_content_digest_match' in pt
G=ROOT/'backga_guard_bot_v2_5_192.py';M=ROOT/'coinbot_main_v2_13_1118.py'
for x in (G,M):compile(x.read_text(),str(x),'exec')
gt=G.read_text();mt=M.read_text()
assert 'committed_generation_s1' in gt and "if s1_rows>0 and s1_seen==0" not in gt
assert 'guard_v2.5.192_completed_generation_handoff_map_v1158_2026-06-30' in mt
assert "EXPECTED_PAPER_VERSION = 'paper_bot_v1.032'" in mt and "EXPECTED_STRATEGY_VERSION = 'strategy_worker_v1.021'" in mt
print('PASS v1158 contract')
