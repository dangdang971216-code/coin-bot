v2150: diagnostics and display truth only. Current generation and all trading formulas remain unchanged. Main/Paper/Strategy only; Guard/Review unchanged. Auto-buy OFF.
