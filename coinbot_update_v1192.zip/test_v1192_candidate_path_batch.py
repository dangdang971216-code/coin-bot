import importlib.util
import json
import os
import sys
import tempfile
import unittest
from pathlib import Path

HERE = Path(__file__).resolve().parent
if str(HERE) not in sys.path:
    sys.path.insert(0, str(HERE))

spec = importlib.util.spec_from_file_location('paper_v1192_under_test', HERE / 'paper_bot_v1.051.py')
paper = importlib.util.module_from_spec(spec)
assert spec and spec.loader
spec.loader.exec_module(paper)


class CandidatePathBatchV1192Tests(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        root = Path(self.tmp.name)
        self.orig_ledger = paper.V1153_PAPER_PATH_LEDGER
        self.orig_state = paper.V1153_PAPER_PATH_STATE
        self.orig_batch = paper._V1192_PAPER_PATH_BATCH
        self.orig_last = dict(paper._V1192_PAPER_PATH_BATCH_LAST)
        self.orig_fsync = paper.os.fsync
        paper.V1153_PAPER_PATH_LEDGER = root / 'events.jsonl'
        paper.V1153_PAPER_PATH_STATE = root / 'state.json'
        paper._V1192_PAPER_PATH_BATCH = None
        paper._V1192_PAPER_PATH_BATCH_LAST = {'schema':'paper_candidate_path_batch_v1192','state':'NOT_RUN','active':False}
        self.fsync_calls = 0

        def counted_fsync(fd):
            self.fsync_calls += 1
            return self.orig_fsync(fd)

        paper.os.fsync = counted_fsync

    def tearDown(self):
        paper.os.fsync = self.orig_fsync
        paper.V1153_PAPER_PATH_LEDGER = self.orig_ledger
        paper.V1153_PAPER_PATH_STATE = self.orig_state
        paper._V1192_PAPER_PATH_BATCH = self.orig_batch
        paper._V1192_PAPER_PATH_BATCH_LAST = self.orig_last
        self.tmp.cleanup()

    @staticmethod
    def event(i):
        return {
            'ticker': f'T{i}',
            'trigger_occurrence_candidate_key': f'candidate-{i}',
            'swing_gate_decision_key_v977': f'decision-{i}',
        }

    def _record_24(self):
        returned = []
        for i in range(8):
            ev = self.event(i)
            for stage in ('PAPER_RECEIVED', 'EXECUTION_DATA_READY', 'TERMINAL_BLOCKED'):
                returned.append(paper._v1153_paper_event_once(stage, ev, reasons=['test']))
        return returned

    def test_24_stage_records_commit_with_one_ledger_and_one_state_write(self):
        self.assertTrue(paper._v1192_paper_path_batch_begin())
        timestamps = self._record_24()
        self.assertEqual(len(timestamps), 24)
        self.assertTrue(all(isinstance(x, float) and x > 0 for x in timestamps))
        self.assertFalse(paper.V1153_PAPER_PATH_LEDGER.exists())
        self.assertFalse(paper.V1153_PAPER_PATH_STATE.exists())

        result = paper._v1192_paper_path_batch_flush()
        self.assertEqual(result['state'], 'COMMITTED')
        self.assertEqual(result['event_calls'], 24)
        self.assertEqual(result['new_event_count'], 24)
        self.assertEqual(result['repeat_event_count'], 0)
        self.assertEqual(result['ledger_write_count'], 1)
        self.assertEqual(result['ledger_fsync_count'], 1)
        self.assertEqual(result['state_write_count'], 1)
        self.assertEqual(self.fsync_calls, 2)  # one ledger fsync + one atomic state fsync

        lines = paper.V1153_PAPER_PATH_LEDGER.read_text(encoding='utf-8').splitlines()
        self.assertEqual(len(lines), 24)
        stages = [json.loads(line)['stage'] for line in lines]
        self.assertEqual(stages, ['PAPER_RECEIVED','EXECUTION_DATA_READY','TERMINAL_BLOCKED'] * 8)
        state = json.loads(paper.V1153_PAPER_PATH_STATE.read_text(encoding='utf-8'))
        self.assertEqual(state['record_count'], 24)
        self.assertEqual(len(state['records']), 24)
        self.assertIn('writer_contract_v1192', state)

    def test_repeat_exposures_do_not_duplicate_append_ledger(self):
        paper._v1192_paper_path_batch_begin()
        first_timestamps = self._record_24()
        paper._v1192_paper_path_batch_flush()
        first_lines = paper.V1153_PAPER_PATH_LEDGER.read_text(encoding='utf-8').splitlines()
        self.assertEqual(len(first_lines), 24)

        self.fsync_calls = 0
        paper._v1192_paper_path_batch_begin()
        second_timestamps = self._record_24()
        result = paper._v1192_paper_path_batch_flush()
        self.assertEqual(first_timestamps, second_timestamps)
        self.assertEqual(result['new_event_count'], 0)
        self.assertEqual(result['repeat_event_count'], 24)
        self.assertEqual(result['ledger_write_count'], 0)
        self.assertEqual(result['state_write_count'], 1)
        self.assertEqual(self.fsync_calls, 1)
        self.assertEqual(len(paper.V1153_PAPER_PATH_LEDGER.read_text(encoding='utf-8').splitlines()), 24)
        state = json.loads(paper.V1153_PAPER_PATH_STATE.read_text(encoding='utf-8'))
        self.assertTrue(all(int(row['seen_count']) == 2 for row in state['records'].values()))

    def test_immediate_path_still_works_outside_selector_batch(self):
        ev = self.event(99)
        ts = paper._v1153_paper_event_once('PAPER_RECEIVED', ev, reasons=['immediate'])
        self.assertIsInstance(ts, float)
        self.assertEqual(len(paper.V1153_PAPER_PATH_LEDGER.read_text(encoding='utf-8').splitlines()), 1)
        state = json.loads(paper.V1153_PAPER_PATH_STATE.read_text(encoding='utf-8'))
        self.assertEqual(state['record_count'], 1)
        self.assertEqual(self.fsync_calls, 2)

    def test_selector_exception_still_flushes_buffered_evidence(self):
        original = paper._V1192_PREV_SELECT_CANDIDATES
        try:
            def exploding_selector(ctrl, open_pos):
                ev = self.event(7)
                paper._v1153_paper_event_once('PAPER_RECEIVED', ev, reasons=['before-error'])
                raise RuntimeError('selector-test-error')
            paper._V1192_PREV_SELECT_CANDIDATES = exploding_selector
            with self.assertRaisesRegex(RuntimeError, 'selector-test-error'):
                paper.select_candidates__v1192_path_batch({}, {})
        finally:
            paper._V1192_PREV_SELECT_CANDIDATES = original
        self.assertIsNone(paper._V1192_PAPER_PATH_BATCH)
        self.assertEqual(len(paper.V1153_PAPER_PATH_LEDGER.read_text(encoding='utf-8').splitlines()), 1)
        state = json.loads(paper.V1153_PAPER_PATH_STATE.read_text(encoding='utf-8'))
        self.assertEqual(state['record_count'], 1)
        self.assertEqual(paper._V1192_PAPER_PATH_BATCH_LAST['state'], 'COMMITTED')

    def test_selector_wrapper_exposes_write_counts_without_changing_result(self):
        original = paper._V1192_PREV_SELECT_CANDIDATES
        try:
            def fake_selector(ctrl, open_pos):
                self._record_24()
                return [('pos-1', {'ticker':'T0'})], {'selected_s1':1}, [{'ticker':'T0'}]
            paper._V1192_PREV_SELECT_CANDIDATES = fake_selector
            picked, stats, latest = paper.select_candidates__v1192_path_batch({}, {})
        finally:
            paper._V1192_PREV_SELECT_CANDIDATES = original
        self.assertEqual(picked, [('pos-1', {'ticker':'T0'})])
        self.assertEqual(latest, [{'ticker':'T0'}])
        self.assertEqual(stats['selected_s1'], 1)
        self.assertEqual(stats['paper_candidate_path_event_calls_v1192'], 24)
        self.assertEqual(stats['paper_candidate_path_ledger_write_count_v1192'], 1)
        self.assertEqual(stats['paper_candidate_path_state_write_count_v1192'], 1)
        self.assertEqual(stats['paper_candidate_path_batch_state_v1192'], 'COMMITTED')


if __name__ == '__main__':
    unittest.main(verbosity=2)
