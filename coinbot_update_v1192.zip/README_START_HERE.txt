코인봇 업데이트 v1192
생성: 2026-07-02 16:49:54 KST

목적
- Paper 후보 진행기록의 반복 전체저장을 제거한다.
- 24개 사건을 지우는 것이 아니라 같은 24개 사건을 한 번의 append로 저장한다.

변경
- Paper paper_bot_v1.050 -> paper_bot_v1.051
- select_candidates 진단 writer만 묶음저장.

변경 없음
- 전략식·S1·selector 결과·중복차단·trigger·invalid·target·RR·청산계약.
- OPEN 저장 23.649초 문제는 다음 버전으로 분리.
- 신규 차단 0 / 자동매수 OFF.

상태
- 로컬 PASS.
- 서버 미적용 CHECK_PENDING_DEPLOY.
- 서버 증거 전 DONE 금지.
