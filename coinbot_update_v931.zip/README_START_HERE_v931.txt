코인봇 v931
- 목적: 매 수정 장부 자동 append + S1 hold/reject 저장 경량화
- 적용: /gupgrade_bundle
- 첫 확인: /change_verify → /issue_ledger → /gdeep_audit 20
- 매매기준 변경 없음, 자동매수 OFF
