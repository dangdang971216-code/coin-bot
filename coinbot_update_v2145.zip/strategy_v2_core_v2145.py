from __future__ import annotations

import hashlib
import json
import math
import statistics
import time
from typing import Any, Dict, Iterable, List, Optional, Tuple

VERSION = "strategy_v2_core_v2145"
BUILD_LABEL = "v2145_clean_v2_single_trading_spine_2026-07-21"
GENERATION = "ALT_SWING_V2_CLEAN_V2145"

REQUIRED_ROWS = {"m5": 48, "m15": 32, "m30": 48, "h1": 48, "h2": 32, "h4": 20}
TF_WEIGHT = {"m5": 1.0, "m15": 1.5, "m30": 2.1, "h1": 2.9, "h2": 4.0, "h4": 5.0}


def _num(value: Any, default: Optional[float] = None) -> Optional[float]:
    try:
        if value is None or isinstance(value, bool):
            return default
        out = float(value)
        return out if math.isfinite(out) else default
    except Exception:
        return default


def _clip(value: float, low: float, high: float) -> float:
    return max(low, min(high, float(value)))


def _sigmoid(value: float) -> float:
    return 1.0 / (1.0 + math.exp(-_clip(value, -12.0, 12.0)))


def _logit(prob: float) -> float:
    p = _clip(prob, 1e-6, 1.0 - 1e-6)
    return math.log(p / (1.0 - p))


def _median(values: Iterable[float], default: float = 0.0) -> float:
    vals = [float(x) for x in values if _num(x) is not None]
    return float(statistics.median(vals)) if vals else float(default)


def _ema(values: List[float], period: int) -> Optional[float]:
    clean = [float(x) for x in values if _num(x) is not None]
    if len(clean) < max(2, period):
        return None
    alpha = 2.0 / (float(period) + 1.0)
    value = sum(clean[:period]) / float(period)
    for item in clean[period:]:
        value = alpha * item + (1.0 - alpha) * value
    return value


def _atr(rows: List[Dict[str, float]], period: int = 14) -> float:
    if len(rows) < 2:
        return 0.0
    trs: List[float] = []
    prev: Optional[float] = None
    for row in rows[-max(period * 4, 48):]:
        high = float(row.get("h") or 0.0)
        low = float(row.get("l") or 0.0)
        close = float(row.get("c") or 0.0)
        if min(high, low, close) <= 0:
            continue
        tr = high - low if prev is None else max(high - low, abs(high - prev), abs(low - prev))
        trs.append(max(0.0, tr))
        prev = close
    if not trs:
        return 0.0
    seed = min(period, len(trs))
    value = sum(trs[:seed]) / seed
    for tr in trs[seed:]:
        value = ((period - 1.0) * value + tr) / period
    return max(0.0, value)


def _pivots(rows: List[Dict[str, float]], side: str, window: int) -> List[Dict[str, Any]]:
    out: List[Dict[str, Any]] = []
    if len(rows) < window * 2 + 3:
        return out
    for idx in range(window, len(rows) - window):
        row = rows[idx]
        value = float(row["l"] if side == "low" else row["h"])
        peers = [float(rows[j]["l"] if side == "low" else rows[j]["h"]) for j in range(idx - window, idx + window + 1) if j != idx]
        confirmed = value < min(peers) if side == "low" else value > max(peers)
        if confirmed:
            out.append({"price": value, "ts": float(row["ts"]), "index": idx, "side": side})
    return out


def _cluster_levels(levels: List[Dict[str, Any]], *, atr_ref: float, current: float) -> List[Dict[str, Any]]:
    clean = [dict(x) for x in levels if (_num(x.get("price"), 0.0) or 0.0) > 0]
    clean.sort(key=lambda x: float(x["price"]))
    groups: List[List[Dict[str, Any]]] = []
    tolerance = max(atr_ref * 0.22, current * 0.0012)
    for item in clean:
        price = float(item["price"])
        if groups:
            center = sum(float(x["price"]) * float(x.get("weight") or 1.0) for x in groups[-1]) / max(1e-12, sum(float(x.get("weight") or 1.0) for x in groups[-1]))
            if abs(price - center) <= tolerance:
                groups[-1].append(item)
                continue
        groups.append([item])
    out: List[Dict[str, Any]] = []
    for group in groups:
        weight_sum = sum(float(x.get("weight") or 1.0) for x in group)
        center = sum(float(x["price"]) * float(x.get("weight") or 1.0) for x in group) / max(weight_sum, 1e-12)
        out.append({
            "price": center,
            "low": min(float(x["price"]) for x in group) - tolerance * 0.35,
            "high": max(float(x["price"]) for x in group) + tolerance * 0.35,
            "score": weight_sum + min(3.0, len({str(x.get("tf")) for x in group})) * 0.5,
            "source_count": len(group),
            "timeframes": sorted({str(x.get("tf")) for x in group}),
            "last_source_ts": max(float(x.get("ts") or 0.0) for x in group),
        })
    return out


def _level_candidates(frames: Dict[str, List[Dict[str, float]]], tfs: Tuple[str, ...], side: str) -> List[Dict[str, Any]]:
    levels: List[Dict[str, Any]] = []
    for tf in tfs:
        rows = frames.get(tf) or []
        window = 2 if tf in {"m5", "m15"} else 3
        for item in _pivots(rows[-120:], "low" if side == "support" else "high", window):
            item["tf"] = tf
            item["weight"] = TF_WEIGHT.get(tf, 1.0)
            levels.append(item)
    return levels


def _trend_axis(rows: List[Dict[str, float]]) -> Optional[float]:
    closes = [float(r["c"]) for r in rows if float(r.get("c") or 0.0) > 0]
    if len(closes) < 24:
        return None
    fast = _ema(closes, 8)
    slow = _ema(closes, 21)
    prior_fast = _ema(closes[:-3], 8) if len(closes) >= 27 else None
    if fast is None or slow is None or prior_fast is None or slow <= 0:
        return None
    spread = (fast - slow) / slow * 100.0
    slope = (fast - prior_fast) / max(abs(prior_fast), 1e-12) * 100.0
    return _clip(spread * 2.8 + slope * 5.0, -1.0, 1.0)


def _row_price(row: Dict[str, Any]) -> Optional[float]:
    for obj in (row, row.get("raw") if isinstance(row.get("raw"), dict) else {}, row.get("entry_context") if isinstance(row.get("entry_context"), dict) else {}):
        if not isinstance(obj, dict):
            continue
        for key in ("current_price", "trade_price", "price", "last_price", "close", "entry_price"):
            value = _num(obj.get(key))
            if value is not None and value > 0:
                return value
    return None


def _nested(row: Dict[str, Any], *keys: str) -> Dict[str, Any]:
    for key in keys:
        value = row.get(key)
        if isinstance(value, dict):
            return value
    return {}


def _direct_input_axes(row: Dict[str, Any], structure: Dict[str, Any]) -> Dict[str, Any]:
    market = _nested(row, "global_market_context_v2130", "market_context_v2130")
    feature = _nested(row, "feature_momentum_context_v2130")
    orderflow = _nested(row, "orderflow_continuation_v2130")
    axes: Dict[str, Optional[float]] = {}

    def norm_100(value: Any) -> Optional[float]:
        num = _num(value)
        return _clip((num - 50.0) / 50.0, -1.0, 1.0) if num is not None else None

    axes["major_trend"] = _num(structure.get("major_trend_axis"))
    axes["setup_trend"] = _num(structure.get("setup_trend_axis"))
    axes["trigger_quality"] = _num(structure.get("trigger_quality_axis"))
    axes["volume_expansion"] = _num(structure.get("volume_expansion_axis"))
    axes["market"] = norm_100(market.get("continuation_score_v2130"))
    axes["relative_strength"] = _clip((_num(feature.get("relative_strength_velocity_v2130"), 0.0) or 0.0) / 3.0, -1.0, 1.0) if feature else None
    axes["money_flow"] = _clip((_num(feature.get("money_flow_velocity_v2130"), 0.0) or 0.0) / 25.0, -1.0, 1.0) if feature else None
    axes["momentum_consistency"] = norm_100(feature.get("momentum_consistency_pct_v2130"))
    axes["orderflow"] = norm_100(orderflow.get("continuation_score_v2130"))
    axes["buy_sustain"] = _clip((_num(orderflow.get("buy_sustain_delta_v2130"), 0.0) or 0.0) * 4.0, -1.0, 1.0) if orderflow else None
    axes["ask_wall_depletion"] = _clip((_num(orderflow.get("ask_wall_depletion_v2130"), 0.0) or 0.0) * 1.5, -1.0, 1.0) if orderflow else None
    ready = {k: float(v) for k, v in axes.items() if v is not None}
    missing = [k for k, v in axes.items() if v is None]
    weights = {
        "major_trend": 1.20, "setup_trend": 1.00, "trigger_quality": 1.35, "volume_expansion": 0.80,
        "market": 0.85, "relative_strength": 1.10, "money_flow": 0.80, "momentum_consistency": 0.75,
        "orderflow": 1.10, "buy_sustain": 0.75, "ask_wall_depletion": 0.55,
    }
    numerator = sum(ready[k] * weights[k] for k in ready)
    denominator = sum(weights[k] for k in ready)
    score = numerator / denominator if denominator > 0 else None
    positive = sum(1 for v in ready.values() if v > 0.12)
    negative = sum(1 for v in ready.values() if v < -0.12)
    agreement = abs(positive - negative) / max(1, len(ready))
    coverage = len(ready) / max(1, len(axes))
    return {
        "schema": "clean_v2_direct_axes_v2145",
        "axes": axes,
        "ready_axes": len(ready),
        "missing_axes": missing,
        "input_coverage_pct": round(coverage * 100.0, 3),
        "direction_agreement_pct": round(agreement * 100.0, 3),
        "combined_axis": round(score, 6) if score is not None else None,
    }


def _prediction(row: Dict[str, Any], structure: Dict[str, Any]) -> Dict[str, Any]:
    evidence = _direct_input_axes(row, structure)
    axis = _num(evidence.get("combined_axis"))
    coverage = (_num(evidence.get("input_coverage_pct"), 0.0) or 0.0) / 100.0
    agreement = (_num(evidence.get("direction_agreement_pct"), 0.0) or 0.0) / 100.0
    consumed = _num(structure.get("entry_fraction_to_t1"), 0.0) or 0.0
    if axis is None or coverage < 0.55:
        return {
            "schema": "clean_v2_continuation_prediction_v2145", "state": "DATA_MISSING",
            "p_t1_before_invalid": None, "p_invalid_before_t1": None, "p_no_touch_6h": None,
            "input_coverage_pct": round(coverage * 100.0, 3), "model_confidence_pct": 0.0,
            "probability_is_calibrated": False, "prediction_gate_active": False,
            "evidence": evidence, "auto_buy": False,
        }
    # The previous model predicted ~44% against an observed ~6.7% 6h T1 rate.
    # This clean generation starts from a conservative low base rate and never gates entry
    # until clean-v2145 first-touch truth has been collected.
    base_rate = 0.075
    linear = 1.55 * axis + 0.55 * agreement - 1.10 * _clip(consumed, 0.0, 1.0)
    p_t1 = _clip(_sigmoid(_logit(base_rate) + linear), 0.015, 0.45)
    opposite = _clip(_sigmoid(_logit(0.11) - 1.25 * axis + 0.45 * _clip(consumed, 0.0, 1.0)), 0.025, 0.55)
    total = p_t1 + opposite
    if total > 0.82:
        scale = 0.82 / total
        p_t1 *= scale
        opposite *= scale
    p_no_touch = max(0.0, 1.0 - p_t1 - opposite)
    model_conf = min(35.0, 35.0 * coverage * (0.45 + 0.55 * agreement))
    return {
        "schema": "clean_v2_continuation_prediction_v2145", "state": "UNCALIBRATED_CLEAN_V2",
        "p_t1_before_invalid": round(p_t1, 6), "p_invalid_before_t1": round(opposite, 6),
        "p_no_touch_6h": round(p_no_touch, 6), "combined_axis": round(axis, 6),
        "input_coverage_pct": round(coverage * 100.0, 3), "model_confidence_pct": round(model_conf, 3),
        "probability_is_calibrated": False, "prediction_gate_active": False,
        "calibration_generation": GENERATION, "evidence": evidence, "auto_buy": False,
    }


def _plan_hash(payload: Dict[str, Any]) -> str:
    raw = json.dumps(payload, ensure_ascii=False, sort_keys=True, separators=(",", ":")).encode("utf-8")
    return hashlib.sha256(raw).hexdigest()[:20]


def build_clean_v2_contract(row: Dict[str, Any], frames: Dict[str, List[Dict[str, float]]], *, now_ts: Optional[float] = None) -> Dict[str, Any]:
    ts = float(now_ts if now_ts is not None else time.time())
    ticker = str(row.get("ticker") or row.get("symbol") or "").upper().replace("KRW-", "").strip()
    current = _row_price(row)
    counts = {tf: len(frames.get(tf) or []) for tf in REQUIRED_ROWS}
    missing = [tf for tf, need in REQUIRED_ROWS.items() if counts.get(tf, 0) < need]
    if current is None or current <= 0:
        missing.append("current_price")
    base: Dict[str, Any] = {
        "schema": "clean_v2_trade_contract_v2145", "version": VERSION, "build": BUILD_LABEL,
        "generation": GENERATION, "ticker": ticker, "evaluated_ts": ts,
        "candidate_preserved": True, "historical_ledger_rewritten": False,
        "legacy_structure_used": False, "legacy_entry_gate_used": False,
        "prediction_gate_active": False, "auto_buy": False,
    }
    if missing:
        base.update({
            "state": "DATA_MISSING", "decision_key": None, "plan_key": None,
            "material_diagnosis": {"state": "DATA_MISSING", "owner": "candle_worker" if "current_price" not in missing else "feature_worker", "missing": sorted(set(missing)), "candidate_quality_failed": False},
            "structure": {"state": "DATA_MISSING", "frame_counts": counts, "completed_candles_only": True},
            "prediction": {"state": "WAIT_STRUCTURE", "prediction_gate_active": False, "probability_is_calibrated": False},
        })
        return base

    m5, m15, m30, h1, h2, h4 = (frames[tf] for tf in ("m5", "m15", "m30", "h1", "h2", "h4"))
    atr5, atr15, atr30, atr1h, atr2h, atr4h = (_atr(x) for x in (m5, m15, m30, h1, h2, h4))
    major_axes = [x for x in (_trend_axis(h4), _trend_axis(h2)) if x is not None]
    setup_axes = [x for x in (_trend_axis(h1), _trend_axis(m30)) if x is not None]
    major_axis = sum(major_axes) / len(major_axes) if major_axes else 0.0
    setup_axis = sum(setup_axes) / len(setup_axes) if setup_axes else 0.0

    entry_levels = _level_candidates(frames, ("m5", "m15"), "resistance")
    entry_clusters = _cluster_levels(entry_levels, atr_ref=max(atr5, atr15 * 0.6), current=current)
    setup_levels = _level_candidates(frames, ("m30", "h1"), "support")
    support_clusters = _cluster_levels(setup_levels, atr_ref=max(atr30, atr1h * 0.55), current=current)
    target_levels = _level_candidates(frames, ("h2", "h4"), "resistance")
    target_clusters = _cluster_levels(target_levels, atr_ref=max(atr2h, atr4h * 0.55), current=current)

    # Pick a fresh trigger event first. Otherwise keep the nearest unconsumed resistance as WAIT.
    recent_closes = [float(r["c"]) for r in m5[-6:]]
    recent_lows = [float(r["l"]) for r in m5[-6:]]
    trigger_obj: Optional[Dict[str, Any]] = None
    trigger_state = "WAIT_TRIGGER"
    trigger_event_ts: Optional[float] = None
    trigger_mode = "WAIT_BREAK"
    sorted_entry = sorted(entry_clusters, key=lambda z: abs(float(z["price"]) - current))
    for zone in sorted_entry:
        level = float(zone["price"])
        crossed = len(recent_closes) >= 2 and recent_closes[-2] <= level < recent_closes[-1]
        retested = any(c > level for c in recent_closes[-5:-1]) and recent_lows[-1] <= level + max(atr5 * 0.18, current * 0.0008) and recent_closes[-1] > level
        if crossed or retested:
            trigger_obj = zone
            trigger_state = "TRIGGER_FIRED"
            trigger_event_ts = float(m5[-1]["ts"])
            trigger_mode = "COMPLETED_BREAK" if crossed else "COMPLETED_RETEST_HOLD"
            break
    if trigger_obj is None:
        above = [z for z in entry_clusters if float(z["price"]) >= current * 0.999]
        if above:
            trigger_obj = min(above, key=lambda z: float(z["price"]))
            trigger_state = "WAIT_TRIGGER"
        else:
            below = [z for z in entry_clusters if float(z["price"]) < current]
            if below:
                trigger_obj = max(below, key=lambda z: float(z["price"]))
                trigger_state = "TRIGGER_PASSED"
                trigger_mode = "OLD_LEVEL_ALREADY_CONSUMED"
    if trigger_obj is None:
        base.update({
            "state": "NO_TRIGGER_STRUCTURE", "decision_key": None, "plan_key": None,
            "material_diagnosis": {"state": "NO_TRIGGER_STRUCTURE", "owner": "strategy_v2_core_v2145", "candidate_quality_failed": False},
            "structure": {"state": "NO_TRIGGER_STRUCTURE", "frame_counts": counts, "major_trend_axis": major_axis, "setup_trend_axis": setup_axis},
        })
        base["prediction"] = _prediction(row, base["structure"])
        return base

    trigger = float(trigger_obj["price"])
    support_candidates = [z for z in support_clusters if float(z["high"]) < trigger and (int(z.get("source_count") or 0) >= 2 or "h1" in (z.get("timeframes") or []))]
    support = max(support_candidates, key=lambda z: float(z["price"]), default=None)
    if support is None:
        structure = {"state": "NO_INVALID_STRUCTURE", "trigger": trigger, "trigger_state": trigger_state, "frame_counts": counts, "major_trend_axis": major_axis, "setup_trend_axis": setup_axis}
        base.update({"state": "NO_INVALID_STRUCTURE", "decision_key": None, "plan_key": None, "material_diagnosis": {"state": "NO_INVALID_STRUCTURE", "owner": "strategy_v2_core_v2145", "candidate_quality_failed": False}, "structure": structure})
        base["prediction"] = _prediction(row, structure)
        return base

    invalid_buffer = max(atr30 * 0.22, atr1h * 0.10, trigger * 0.0008)
    invalid = float(support["low"]) - invalid_buffer
    target_floor = max(trigger, current)
    targets = [z for z in target_clusters if float(z["low"]) > target_floor * 1.00001]
    if not targets:
        structure = {"state": "NO_REACHABLE_T1", "trigger": trigger, "execution_invalid": invalid, "trigger_state": trigger_state, "frame_counts": counts, "major_trend_axis": major_axis, "setup_trend_axis": setup_axis}
        base.update({"state": "NO_REACHABLE_T1", "decision_key": None, "plan_key": None, "material_diagnosis": {"state": "NO_REACHABLE_T1", "owner": "strategy_v2_core_v2145", "candidate_quality_failed": False}, "structure": structure})
        base["prediction"] = _prediction(row, structure)
        return base
    targets.sort(key=lambda z: float(z["low"]))
    t1 = float(targets[0]["low"])
    t2 = float(targets[1]["low"]) if len(targets) > 1 else None
    reference = current if trigger_state == "TRIGGER_FIRED" else trigger
    if not (invalid < reference < t1):
        state = "PRICE_ORDER_INVALID"
    elif major_axis < -0.62 and setup_axis < -0.35:
        state = "MARKET_WEAK_WAIT"
    elif trigger_state == "WAIT_TRIGGER":
        state = "WAIT_TRIGGER"
    elif trigger_state == "TRIGGER_PASSED":
        state = "TRIGGER_PASSED"
    else:
        state = "ENTRY_READY"

    risk_pct = (reference - invalid) / reference * 100.0
    room_pct = (t1 - reference) / reference * 100.0
    rr = room_pct / risk_pct if risk_pct > 0 else None
    fraction = max(0.0, (current - trigger) / max(t1 - trigger, 1e-12))
    vol_now = sum(float(r.get("v") or 0.0) for r in m5[-3:]) / 3.0
    vol_base = _median([float(r.get("v") or 0.0) for r in m5[-30:-3]], default=0.0)
    volume_axis = _clip(math.log(max(vol_now, 1e-12) / max(vol_base, 1e-12)) / 1.2, -1.0, 1.0) if vol_base > 0 else 0.0
    trigger_quality = 0.75 if trigger_state == "TRIGGER_FIRED" and trigger_mode == "COMPLETED_RETEST_HOLD" else 0.45 if trigger_state == "TRIGGER_FIRED" else -0.15 if trigger_state == "WAIT_TRIGGER" else -0.65
    plan_seed = {
        "ticker": ticker, "trigger": round(trigger, 12), "invalid": round(invalid, 12), "t1": round(t1, 12),
        "t2": round(t2, 12) if t2 else None, "trigger_state": trigger_state,
        "trigger_event_ts": trigger_event_ts, "h4_ts": float(h4[-1]["ts"]), "m5_ts": float(m5[-1]["ts"]),
    }
    plan_key = "v2145-plan:" + _plan_hash(plan_seed)
    decision_key = None
    if state == "ENTRY_READY" and trigger_event_ts:
        decision_key = f"v2145:{ticker}:{plan_key.split(':')[-1]}:{int(trigger_event_ts * 1000)}"
    structure = {
        "schema": "clean_v2_structure_v2145", "state": state, "reference_entry": round(reference, 12),
        "current_price": round(current, 12), "trigger": round(trigger, 12), "trigger_state": trigger_state,
        "trigger_mode": trigger_mode, "trigger_event_ts": trigger_event_ts,
        "entry_zone_low": round(float(trigger_obj["low"]), 12), "entry_zone_high": round(float(trigger_obj["high"]), 12),
        "execution_invalid": round(invalid, 12), "structural_support": round(float(support["price"]), 12),
        "target_t1": round(t1, 12), "target_t2": round(t2, 12) if t2 else None,
        "risk_pct": round(risk_pct, 6), "t1_room_pct": round(room_pct, 6), "rr_t1": round(rr, 6) if rr is not None else None,
        "entry_fraction_to_t1": round(fraction, 6), "major_trend_axis": round(major_axis, 6),
        "setup_trend_axis": round(setup_axis, 6), "trigger_quality_axis": round(trigger_quality, 6),
        "volume_expansion_axis": round(volume_axis, 6), "frame_counts": counts,
        "completed_candles_only": True, "forming_candle_excluded": True,
        "timeframe_contract": {"major": "4h/2h", "setup": "1h/30m", "trigger": "15m/5m", "execution": "1m/quote"},
        "source": "strategy_v2_core_v2145_only", "legacy_structure_used": False,
    }
    prediction = _prediction(row, structure)
    base.update({
        "state": state, "decision_key": decision_key, "plan_key": plan_key,
        "material_diagnosis": {"state": "READY" if state in {"ENTRY_READY", "WAIT_TRIGGER", "TRIGGER_PASSED", "MARKET_WEAK_WAIT"} else state, "owner": "strategy_v2_core_v2145", "candidate_quality_failed": False, "missing": []},
        "structure": structure, "prediction": prediction,
        "execution_policy": {
            "schema": "clean_v2_execution_policy_v2145", "actual_price_required": True,
            "fresh_spread_slippage_required": True, "after_cost_reward_must_be_positive": True,
            "entry_must_remain_in_first_half_to_t1": True, "fixed_legacy_rr_room_chase_thresholds_used": False,
            "prediction_gate_active": False,
        },
    })
    return base


def compact_clean_v2_contract(value: Any) -> Dict[str, Any]:
    if not isinstance(value, dict):
        return {}
    structure = value.get("structure") if isinstance(value.get("structure"), dict) else {}
    prediction = value.get("prediction") if isinstance(value.get("prediction"), dict) else {}
    material = value.get("material_diagnosis") if isinstance(value.get("material_diagnosis"), dict) else {}
    evidence = prediction.get("evidence") if isinstance(prediction.get("evidence"), dict) else {}
    return {
        "schema": "clean_v2_trade_contract_v2145_compact", "version": value.get("version"), "generation": value.get("generation"),
        "state": value.get("state"), "ticker": value.get("ticker"), "evaluated_ts": value.get("evaluated_ts"),
        "decision_key": value.get("decision_key"), "plan_key": value.get("plan_key"),
        "material_diagnosis": {k: material.get(k) for k in ("state", "owner", "missing", "candidate_quality_failed")},
        "structure": {k: structure.get(k) for k in (
            "state", "reference_entry", "current_price", "trigger", "trigger_state", "trigger_mode", "trigger_event_ts",
            "entry_zone_low", "entry_zone_high", "execution_invalid", "structural_support", "target_t1", "target_t2",
            "risk_pct", "t1_room_pct", "rr_t1", "entry_fraction_to_t1", "major_trend_axis", "setup_trend_axis",
            "trigger_quality_axis", "volume_expansion_axis", "frame_counts", "completed_candles_only", "forming_candle_excluded",
            "timeframe_contract", "source", "legacy_structure_used"
        )},
        "prediction": {k: prediction.get(k) for k in (
            "state", "p_t1_before_invalid", "p_invalid_before_t1", "p_no_touch_6h", "combined_axis",
            "input_coverage_pct", "model_confidence_pct", "probability_is_calibrated", "prediction_gate_active", "calibration_generation"
        )},
        "prediction_evidence": {k: evidence.get(k) for k in ("ready_axes", "missing_axes", "input_coverage_pct", "direction_agreement_pct", "combined_axis")},
        "execution_policy": value.get("execution_policy"),
        "legacy_structure_used": False, "legacy_entry_gate_used": False,
        "candidate_preserved": True, "auto_buy": False,
    }
