Coinbot update v2145 - Clean V2 single trading spine

Purpose
- Remove legacy structure/entry/new-open/exit calculations from the NEW active trade path.
- Use independent V2 structure, direct V2 Paper OPEN, current-generation Review, and V2-only Main display.

Safety
- Auto-buy remains OFF.
- Historical ledgers and old Shadow samples are preserved.
- Existing old OPEN contracts are not recalculated or converted.
- Clean prediction starts uncalibrated and record-only; it does not gate entries until clean-generation truth is sufficient and separately approved.

Status
- Local compile/integration checks: PASS.
- Server runtime proof: CHECK until deployment commands pass.
