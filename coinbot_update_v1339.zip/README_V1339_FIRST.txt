v1339: candidate quality material audit only. No trading rule changes. Auto-buy OFF.
