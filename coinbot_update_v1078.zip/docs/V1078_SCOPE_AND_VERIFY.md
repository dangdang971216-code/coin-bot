# v1078 Strategy Candle overlay 캐시 본선 수술

## 기준

- 기준 버전: v1077 DONE
- 신규 버전: v1078
- Strategy: `strategy_worker_v0.994`
- Guard: `guard_v2.5.133`
- 전략모드: ALT_SWING
- 자동매수: OFF
- 서버 적용 전 상태: CHECK

## 증상

v1077 적용 후 불필요한 candidate full-row audit는 5.18초에서 0.03초로 줄었다. 그러나 Strategy 전체 cycle은 33초 안팎이었고 다음 병목이 확인됐다.

- `candle_cache_row_overlay`: 4.92초
- `structure_lab`: 7.38초
- `candidate_writer_compact_single_pass`: 3.91초

실제 구조계산인 `structure_lab`을 먼저 건드리지 않고 Candle overlay의 caller→reader→cache→writer를 추적했다.

## 실제 원인

1. Candle worker는 실제 ticker를 갱신할 때마다 해당 row의 `candle_ts`를 새로 봉인한다.
2. 별도로 30~60초마다 `clean_candle_cache.json` 전체 checkpoint를 atomic replace한다.
3. Strategy `_v1014_load_candle_map()`은 checkpoint 교체를 감지하면 461개 row dict를 다시 생성한다.
4. 기존 v1032 cache signature에는 `id(c)`가 포함돼 있었다.
5. 내용과 `candle_ts`가 그대로인 row도 Python 객체가 새로 생성됐다는 이유만으로 461개가 전부 cache miss가 됐다.
6. cache miss마다 v769→v823→v824→v827의 Candle material wrapper chain과 894개 보존키 경로가 다시 실행됐다.

즉, Candle 값이 전부 바뀐 것이 아니라 **checkpoint 파일 교체로 객체 주소만 바뀐 것을 실제 데이터 변경으로 오판**한 것이 4.92초 병목의 뿌리 원인이다.

## 값 owner

- Candle row 실제 변경 identity owner: `candle_worker.fetch_one()`의 `candle_ts`
- Candle full/delta reader: `strategy_worker._v1014_load_candle_map()`
- exact overlay cache owner: `strategy_worker._v597_candle_official_fields`
- 잘못된 identity owner: 기존 `_v1032_candle_source_signature()`의 process-local `id(c)`

## 수정 파일

- `strategy_worker_v0.994.py`
- `backga_guard_bot_v2_5_133.py`

## 삭제한 구 경로

- Candle cache signature에서 process-local `id(c)` 사용 제거
- checkpoint 객체 재생성을 실제 Candle 자료 변경으로 취급하던 cache miss 경로 제거

## 새 본선

- 실제 자료 변경은 Candle owner가 봉인한 `candle_ts`와 canonical row material marker로 판단한다.
- checkpoint가 dict 객체만 새로 만들고 내용은 유지한 경우 exact overlay 결과를 재사용한다.
- 실제 ticker refresh로 `candle_ts`가 바뀐 row만 기존 material builder를 실행한다.
- age 값은 기존 v1032 방식 그대로 매 cycle 갱신한다.
- overlay 결과 필드와 값은 변경하지 않는다.

## 로컬 검수

- `py_compile`: PASS
- top-level 중복 함수: 0
- Guard command route/menu: PASS
- Guard verify mock: DONE
- 461개 합성 row 비교:
  - 최초 build 결과 동일
  - full checkpoint 객체 재생성 후 결과 동일
  - 실제 `candle_ts`·material 변경 후 결과 동일
- full checkpoint 재생성 성능:
  - 기존 2.243441초
  - 신규 0.080298초
  - 약 96.42% 감소

합성시험은 서버 증명이 아니다. 실제 완료 판정은 서버에서 Candle full checkpoint를 포함한 60초 이상 표본으로 수행한다.

## 서버 검수

`/gstrategy_overlay_v1078 95`는 다음을 확인한다.

- Strategy runtime `strategy_worker_v0.994`
- active/target hash 일치
- candidate commit 증가
- writer result OK
- stable signature schema 활성
- Python object id signature 제거
- full checkpoint 객체 재생성 cache reuse 1건 이상
- `candle_cache_row_overlay` 4.92초 기준 대비 감소
- candidate JSON parse 오류 0
- S1 decision key·trigger·invalid·target 누락 0
- exact duplicate/key_missing/unlinked 0/0/0
- 자동매수 OFF

## 전략 영향

- S1/S2/S3 변경 0
- trigger·invalid·target·RR 변경 0
- 진입·청산·OPEN 한도 변경 0
- Candle 값·구조선 계산 변경 0
- OPEN/CLOSED/decision/exact 원장 변경·삭제 0
- 자동매수 OFF
