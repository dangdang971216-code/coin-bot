v1619 CANONICAL SPINE CONTRACT SEAL + PAPER INTAKE

목적:
- v1618에서 spine active event는 생겼지만 contract_complete=0이라 Paper가 후보를 받지 못한 문제 수리.
- 기존 계약완성 row의 trigger/invalid/target/source/timeframe을 spine complete_events에 봉인.
- Paper candidate_sources가 canonical spine complete_events를 첫 후보 소스로 읽음.

안 바꿈:
- 후보 기준, Gate, TTL, RR, trigger/invalid/target 공식, spread/slippage 기준, 청산, OPEN 제한, 자동매수 OFF.

검수:
- /grelease_verify
- /candidate_recheck
- /data_pipeline
- /candidate_standard
- /errorlog
