v2138 새 전략 Paper 알림·버전스코어 exact TOP·후보오류 진실
- Main·Paper만 변경, Guard/worker 변경 없음
- 기존 Paper 알림 형식 유지 + 새 전략 검증 구역 추가
- exact OPEN/CLOSED 저장 뒤 알림 1회, 중복 방지, 실패 시 원장 유지
- 기존 OPEN 미발송은 적용 후 1회 복구
- canonical TOP 유지 + exact 수익/손실/CLOSED TOP 별도 표시
- decision key는 안전조건 통과 뒤에만 필수, key 추정/생성 금지
- 수치·진입·청산·순위 비개입, 자동매수 OFF
