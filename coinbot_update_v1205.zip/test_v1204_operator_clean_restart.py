import importlib.util
import json
import sys
import tempfile
import time
import unittest
from pathlib import Path
from unittest import mock

ROOT = Path(__file__).resolve().parent
SOURCE = ROOT / 'paper_bot_v1.056.py'
sys.path.insert(0, str(ROOT))


def load_module():
    spec = importlib.util.spec_from_file_location('paper_v1204_test', SOURCE)
    module = importlib.util.module_from_spec(spec)
    assert spec and spec.loader
    spec.loader.exec_module(module)
    return module


paper = load_module()


class OperatorCleanRestartV1204Tests(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.root = Path(self.tmp.name)
        paper.V1204_RESET_CONTROL = self.root / 'control.json'
        paper.V1204_RESET_STATUS = self.root / 'status.json'
        paper.V1204_RESET_MANIFEST = self.root / 'manifest.json'
        paper.V1204_RESET_EVENTS = self.root / 'events.jsonl'
        paper.V1204_RESET_EPOCH = self.root / 'epoch.json'

    def tearDown(self):
        self.tmp.cleanup()

    def test_pause_discards_selected_rows_but_keeps_latest_and_evidence(self):
        paper.V1204_RESET_CONTROL.write_text(json.dumps({'pause_new_open': True}), encoding='utf-8')
        previous = paper._V1204_PREV_SELECT_CANDIDATES
        paper._V1204_PREV_SELECT_CANDIDATES = lambda ctrl, open_pos: ([{'ticker':'A'}, {'ticker':'B'}], {'selected_s1':2}, [{'ticker':'A'}, {'ticker':'B'}, {'ticker':'C'}])
        try:
            picked, stats, latest = paper.select_candidates__v1204_operator_pause({}, {})
        finally:
            paper._V1204_PREV_SELECT_CANDIDATES = previous
        self.assertEqual(picked, [])
        self.assertEqual(len(latest), 3)
        self.assertTrue(stats['operator_reset_entry_pause_v1204'])
        self.assertEqual(stats['operator_reset_blocked_selected_v1204'], 2)
        self.assertEqual(stats['selected_s1'], 0)

    def test_operator_close_row_is_exact_history_but_excluded_from_strategy_windows(self):
        now = time.time()
        pos = {
            'pos_id':'p1','ticker':'AAA','entry_price':100.0,'current_price':105.0,
            'last_pnl_pct':4.9,'peak_pct':7.0,'trough_pct':-1.0,
            'opened_at':now-600,'paper_decision_key_v926':'d1',
        }
        with mock.patch.object(paper, 'update_position', return_value=(dict(pos), None)), \
             mock.patch.object(paper, '_v983_seal_closed_evidence', side_effect=lambda closed, source, ctrl: closed), \
             mock.patch.object(paper, 'finalize_closed_position_metadata', side_effect=lambda source, closed, ctrl, cycle_now, before: closed), \
             mock.patch.object(paper, 'active_main_version', return_value='수익형 v2.13.1137'), \
             mock.patch.object(paper, 'active_patch_version', return_value='v1204'):
            updated, closed, reason = paper._v1204_operator_closed_row(pos, {'fee_pct_roundtrip':0.1}, 'batch-x')
        self.assertEqual(reason, 'ready')
        self.assertIsNotNone(closed)
        self.assertEqual(closed['exit_reason'], 'operator_reset_v1204')
        self.assertTrue(closed['operator_book_reset_v1045'])
        self.assertTrue(closed['excluded_from_strategy_windows_v1045'])
        self.assertEqual(closed['performance_epoch_role'], 'reset_transition_close')
        self.assertEqual(closed['book_reset_batch_id'], 'batch-x')
        self.assertEqual(closed['pnl_pct'], 4.9)

    def test_reset_uses_exact_commit_and_leaves_entry_paused(self):
        book = {
            'p1': {'pos_id':'p1','ticker':'AAA'},
            'p2': {'pos_id':'p2','ticker':'BBB'},
            'p3': {'pos_id':'p3','ticker':'CCC'},
        }
        statuses = []
        controls = []
        events = []

        def fake_load_open():
            return book

        def fake_closed(pos, ctrl, batch):
            pid = pos['pos_id']
            return dict(pos), {
                **pos,'pnl_pct':1.0,'exit_reason':'operator_reset_v1204',
                'operator_book_reset_v1045':True,'performance_epoch_role':'reset_transition_close',
                'book_reset_batch_id':batch,
            }, 'ready'

        def fake_commit(open_pos, pid, updated, closed, owner):
            open_pos.pop(pid, None)
            return closed, True, 'committed_exact_closed'

        with mock.patch.object(paper, 'load_open', side_effect=fake_load_open), \
             mock.patch.object(paper, '_v1204_operator_closed_row', side_effect=fake_closed), \
             mock.patch.object(paper, 'commit_closed_position_exact', side_effect=fake_commit) as commit, \
             mock.patch.object(paper, '_v1204_write_control', side_effect=lambda x: controls.append(dict(x)) or True), \
             mock.patch.object(paper, '_v1204_write_status', side_effect=lambda x: statuses.append(dict(x)) or True), \
             mock.patch.object(paper, '_v1204_append_event', side_effect=lambda x: events.append(dict(x))), \
             mock.patch.object(paper, '_paper_write_json_verified', return_value=True), \
             mock.patch.object(paper, 'load_control', return_value={'fee_pct_roundtrip':0.1}), \
             mock.patch.object(paper, 'write_score_cache', return_value=None):
            text = paper._v1204_execute_operator_reset()
        self.assertEqual(commit.call_count, 3)
        self.assertEqual(book, {})
        self.assertTrue(controls[0]['pause_new_open'])
        self.assertFalse(controls[0]['resume_allowed'])
        self.assertEqual(statuses[-1]['state'], 'ZERO_OPEN_ENTRY_PAUSED')
        self.assertTrue(statuses[-1]['zero_open_proof'])
        self.assertIn('현재 OPEN: 0', text)
        self.assertEqual(events[0]['event'], 'START')
        self.assertEqual(events[-1]['event'], 'DONE')

    def test_resume_is_blocked_until_top10_release(self):
        text = paper._handle_single_paper_command('/preset_resume')
        self.assertIn('TOP10', text)
        self.assertIn('잠금', text)

    def test_source_preserves_current_unlimited_policy_until_operator_pause(self):
        source = SOURCE.read_text(encoding='utf-8')
        self.assertIn("'max_open_strict':0,'max_new_per_cycle':0", source)
        self.assertIn("operator_reset_entry_pause_v1204", source)
        self.assertIn("commit_closed_position_exact", source)
        self.assertIn("excluded_from_strategy_windows_v1045", source)
        self.assertIn("auto_buy': False", source)


if __name__ == '__main__':
    unittest.main(verbosity=2)
