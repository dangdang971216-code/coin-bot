코인봇 v1205
1. /gupgrade_bundle 단독 실행
2. Paper v1.056 PID/hash 확인
3. 기존 v1204 전체정리는 자동으로 남은 OPEN부터 재개됩니다.
4. Paper봇 /preset_status /pstatus 로 진행률 확인
5. OPEN 0·zero_open_proof true·신규진입 잠금 유지 확인

주의: /preset_all 재전송은 중복 실행하지 않고 현재 진행상태만 반환합니다.
