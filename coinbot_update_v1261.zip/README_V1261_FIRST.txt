V1261 APPLY ORDER
=================
1. Guard bot: /gupgrade_bundle (alone)
2. After automatic continuation/restart: /gdeploy and /grelease_verify
3. Paper bot: /perror
4. Main bot: /strategy_final /flow_map_full /candidate_standard /version_score

Expected public score: current unified actual + v1211 actual + difference + fresh current missed candidates.
Old transition/policy/virtual/old-missed panels are retired from active readers; files and ledgers are preserved.
Auto-buy remains OFF. Server status is CHECK until runtime evidence is received.
