from __future__ import annotations
import hashlib, importlib.util, sys
from pathlib import Path

ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT))

def load(name, filename):
    spec=importlib.util.spec_from_file_location(name, ROOT/filename)
    mod=importlib.util.module_from_spec(spec)
    assert spec and spec.loader
    sys.modules[name]=mod
    spec.loader.exec_module(mod)
    return mod

def row_fixture():
    return {
        'ticker':'TEST','open_eligible':True,'trigger_reached':True,'swing_gate_decision_key_v977':'d1',
        'structure_contract_version':'current','structure_contract_hash':'h1',
        'swing_entry_gate_v977':{'trigger_price':100.0,'invalid_price':95.0,'target_price':110.0},
        'swing_trigger_price_v977':100.0,'swing_invalid_price_v977':95.0,'swing_target_price_v977':110.0,
        'dynamic_structure_plan_v1212':{'target_reach_limit_pct':15.0},
        'v1211_structure_shadow_v1222':{
            'source_exact':True,'complete':True,
            'invalid':{'rounded_price':97.0,'source':'setup_support','tf':'30m'},
            'target':{'rounded_price':120.0,'source':'major_resistance','tf':'4h'},
        },
        'price_reaction_pct':0.1,'relative_strength_rank_pct_v1095':70.0,'money_flow_score':60.0,
        'buy_ratio':0.55,'buy_sustain_1m':0.50,'quality_observation_v925':{'extreme_quality_risk_tags':[]},
        'canonical_entry_decision':{},
    }

def test_strategy_is_byte_identical_to_v1260_baseline():
    digest=hashlib.sha256((ROOT/'strategy_worker_v1.062.py').read_bytes()).hexdigest()
    assert digest=='d6019dfd4f82bbdfcd9ec144882e84e1331494813782c8fe5202a64695e7f84e'

def test_strategy_contract_and_gate_unchanged():
    m=load('strategy_reg_v1261','strategy_worker_v1.062.py')
    row=row_fixture()
    m._V1257_BASE_APPLY_SWING_ENTRY_GATE=lambda rows,nowv:(rows,{'pass_s1':1})
    out,summary=m.apply_swing_entry_gate__v1257_unified([row],123.0)
    r=out[0]; c=r['unified_strategy_contract_v1257']
    assert r['open_eligible'] is True
    assert r['swing_entry_gate_v977']['trigger_price']==100.0
    assert r['swing_entry_gate_v977']['invalid_price']==95.0
    assert r['swing_entry_gate_v977']['target_price']==110.0
    assert c['v1211_structural_support']['early_failure_invalid_price']==97.0
    assert c['v1211_structural_support']['extension_target_price']==120.0
    assert summary['candidate_pass_changed_v1257'] is False
    assert summary['global_rank_changed_v1257'] is False

def test_paper_open_contract_and_existing_open_behavior_unchanged():
    s=load('strategy_reg_for_paper','strategy_worker_v1.062.py')
    p=load('paper_reg_v1261','paper_bot_v1.076.py')
    row=row_fixture(); row['entry_price']=100.0
    row['unified_strategy_contract_v1257']=s._v1257_unified_contract(row,1.0)
    p._V1257_PREV_OPEN_POSITION=lambda pos_id,ev:dict(ev)
    pos=p.open_position__v1257_unified('p1',row)
    assert pos['exit_contract_v1257']['schema']==p.V1257_EXIT_SCHEMA
    assert pos['exit_contract_v1257']['early_failure_line']['price']==97.0
    assert pos['exit_contract_v1257']['extension_target']['price']==120.0
    old=p.open_position__v1257_unified('p2',{'ticker':'OLD','entry_price':100.0})
    assert 'exit_contract_v1257' not in old
    assert old['unified_contract_state_v1257']=='LEGACY_CANDIDATE_CONTRACT_PRESERVED'

def test_paper_exit_spine_unchanged():
    p=load('paper_reg_paths_v1261','paper_bot_v1.076.py')
    contract={
        'schema':p.V1257_EXIT_SCHEMA,'original_invalid_price':95.0,'base_target_price':110.0,
        'early_failure_line':{'active':True,'price':97.0,'source':'x','timeframe':'30m'},
        'extension_target':{'active':True,'price':120.0},'strategy_contract_digest':'d',
    }
    pos={'entry_price':100.0,'current_price':96.5,'exit_contract_v1257':contract}
    p._V1257_PREV_EXIT_DECISION=lambda *a,**k:{'action':'hold','reason':''}
    decision=p._exit_decision_spine__v1257(pos,1,0,-1,{})
    assert decision['reason']=='swing_unified_entry_failure_v1257'
    pos={'entry_price':100.0,'current_price':111.0,'exit_contract_v1257':contract}
    p._V1257_PREV_EXIT_DECISION=lambda *a,**k:{'action':'close','reason':'structure_target'}
    p._v1257_extension_runtime=lambda *a,**k:{'state':{},'role':'general','usable':True,'strengths':3,'weaknesses':1,'support_intact':True,'keep':True,'evidence':{}}
    decision=p._exit_decision_spine__v1257(pos,10,11,10,{})
    assert decision['action']=='hold' and decision['reason']=='unified_extension_armed_v1257'

def test_final_active_bindings_remain_v1257_and_v1242_commit_owners():
    paper=(ROOT/'paper_bot_v1.076.py').read_text(encoding='utf-8')
    strategy=(ROOT/'strategy_worker_v1.062.py').read_text(encoding='utf-8')
    assert strategy.rfind('apply_swing_entry_gate = apply_swing_entry_gate__v1257_unified') > strategy.rfind('apply_swing_entry_gate = apply_swing_entry_gate__v1234')
    assert paper.rfind('open_position = open_position__v1257_unified') > paper.rfind('open_position = open_position__v1207_dynamic_exit')
    assert paper.rfind('_exit_decision_spine = _exit_decision_spine__v1257') > paper.rfind('_exit_decision_spine = _exit_decision_spine__v1207')
    assert 'process_open_positions_for_exit = process_open_positions_for_exit__v1242' in paper
    assert 'commit_closed_position_exact = commit_closed_position_exact__v1242' in paper
