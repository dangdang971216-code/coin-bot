from __future__ import annotations

import importlib.util
import json
import sys
import tempfile
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))


def load_module(name: str, filename: str):
    spec = importlib.util.spec_from_file_location(name, ROOT / filename)
    module = importlib.util.module_from_spec(spec)
    assert spec and spec.loader
    sys.modules[name] = module
    spec.loader.exec_module(module)
    return module


def raw_closed(now: float, key: str, pnl: float, contract: str, current: bool = False):
    row = {
        'paper_decision_key_v926': key,
        'ticker': key.upper(),
        'entry_price': 100.0,
        'exit_price': 100.0 + pnl,
        'pnl_pct': pnl,
        'opened_at': now - 600.0,
        'closed_at': now,
        'exit_reason': 'swing_trailing' if pnl > 0 else 'structure_invalid',
        'structure_contract_version': contract,
        'mfe_pct_v983': max(pnl, 0.5),
        'mae_pct_v983': min(pnl, -0.2),
        'giveback_pct_v983': max(0.0, max(pnl, 0.5) - pnl),
        'hold_sec': 600.0,
    }
    if current:
        row['exit_contract_v1257'] = {
            'schema': 'paper_unified_exit_contract_v1257',
            'strategy_contract_digest': f'digest-{key}',
        }
        row['exit_contract_version_v1257'] = 'v1257'
    return row


def test_paper_score_has_only_current_actual_and_v1211_actual():
    paper = load_module('paper_v1261_score', 'paper_bot_v1.076.py')
    now = 1_783_270_000.0
    current = paper._v987_perf_compact_row(
        raw_closed(now, 'cur', 2.0, 'structure_contract_v1212_dynamic_zones', current=True),
        'cur', 'exact',
    )
    previous = paper._v987_perf_compact_row(
        raw_closed(now - 10_000.0, 'old', -1.0, 'structure_contract_v1211_legacy'),
        'old', 'exact',
    )
    transition = paper._v987_perf_compact_row(
        raw_closed(now - 5_000.0, 'mid', 9.0, 'structure_contract_v1229_dynamic'),
        'mid', 'exact',
    )
    open_book = {
        'pos-current': {
            'pos_id': 'pos-current', 'ticker': 'OPEN', 'entry_price': 100.0,
            'current_price': 101.0, 'pnl_pct': 0.9,
            'exit_contract_v1257': {'schema': 'paper_unified_exit_contract_v1257'},
        },
        'pos-legacy': {
            'pos_id': 'pos-legacy', 'ticker': 'LEG', 'entry_price': 100.0,
            'current_price': 110.0, 'pnl_pct': 9.9,
        },
    }
    snap = {'rows': [current, previous, transition], 'windows': {}, 'window_counts': {}, 'counts': {}, 'invariants': {}}
    out = paper._v1045_apply_performance_epoch_contract(snap, now, open_book)
    score = out['version_score_v1261']
    assert score['public_reader_scope'] == 'CURRENT_UNIFIED_ACTUAL_AND_V1211_ACTUAL_ONLY'
    assert score['current_strategy']['closed_count'] == 1
    assert score['current_strategy']['open_count'] == 1
    assert score['current_strategy']['closed_windows']['all']['total'] == 2.0
    assert score['current_strategy']['open']['total'] == 0.9
    assert score['v1211_actual']['closed_count'] == 1
    assert score['v1211_actual']['all']['total'] == -1.0
    assert transition['pnl_pct'] == 9.0
    assert score['historical_ledgers_rewritten'] is False
    assert score['auto_buy'] is False


def candidate_row(price: float = 100.0, ready: bool = False, key: str = 'decision-1'):
    return {
        'ticker': 'AAA', 'current_price': price,
        'swing_gate_decision_key_v977': key,
        'candidate_pipeline_cycle_id_v1150': 'cycle-1',
        'candidate_stage': 'S1' if ready else 'S3',
        'block_reasons': [] if ready else ['frozen_trigger_not_reached'],
        'unified_strategy_contract_v1257': {
            'schema': 'unified_alt_swing_contract_v1257', 'ready': ready,
            'primary_entry_structure': {'trigger_price': 101.0, 'invalid_price': 95.0, 'base_target_price': 110.0},
            'v1211_structural_support': {},
            'entry_quality_support': {'confirmed': True, 'reason': 'CONFIRMED'},
        },
        'v1211_structure_shadow_v1222': {
            'source_exact': True, 'complete': True,
            'trigger': {'rounded_price': 99.0},
            'invalid': {'rounded_price': 94.0},
            'target': {'rounded_price': 112.0},
        },
    }


def test_review_starts_new_state_at_zero_and_ignores_old_state():
    review = load_module('review_v1261_reset', 'review_worker_v1.037.py')
    with tempfile.TemporaryDirectory() as td:
        base = Path(td)
        (base / 'version_score_review_state_v1237.json').write_text(
            json.dumps({'schema': 'version_score_review_state_v1237', 'missed': {'events': {'old': {'ticker': 'OLD'}}}}),
            encoding='utf-8',
        )
        review.now_ts = lambda: 1000.0
        out = review.update_version_score_review(
            base, [candidate_row()], generation={'cycle_id': 'c1', 'candidate_commit_id': 'm1'}, generation_integrity={}
        )
        assert out['current_missed_v1261']['tracked_total'] == 1
        assert out['invariants']['old_review_state_imported'] is False
        assert (base / 'version_score_current_missed_state_v1261.json').exists()
        assert (base / 'canonical_version_score_review_v1261.json').exists()
        assert (base / 'version_score_review_state_v1237.json').exists()
        state = json.loads((base / 'version_score_current_missed_state_v1261.json').read_text(encoding='utf-8'))
        assert state['old_state_imported'] is False
        assert all(e.get('ticker') != 'OLD' for e in state['events'].values())


def test_review_tracks_exact_key_horizons_and_v1211_ready():
    review = load_module('review_v1261_path', 'review_worker_v1.037.py')
    with tempfile.TemporaryDirectory() as td:
        base = Path(td)
        review.now_ts = lambda: 1000.0
        first = review.update_version_score_review(base, [candidate_row(100.0)], generation={'cycle_id': 'c1'}, generation_integrity={})
        missed = first['current_missed_v1261']
        assert missed['tracked_total'] == 1
        assert missed['v1211_would_be_ready_count'] == 1
        review.now_ts = lambda: 1000.0 + 6 * 3600.0 + 1.0
        second = review.update_version_score_review(base, [candidate_row(103.0)], generation={'cycle_id': 'c2'}, generation_integrity={})
        missed2 = second['current_missed_v1261']
        assert missed2['completed_6h'] == 1
        assert missed2['gain_1_2_count'] == 1
        top = missed2['top'][0]
        assert top['return_30m_pct'] == 3.0
        assert top['return_1h_pct'] == 3.0
        assert top['return_3h_pct'] == 3.0
        assert top['return_6h_pct'] == 3.0
        assert top['exact_candidate_key'] == 'decision-1'


def test_review_does_not_use_ticker_time_fallback_and_marks_recovered_ready():
    review = load_module('review_v1261_exact', 'review_worker_v1.037.py')
    with tempfile.TemporaryDirectory() as td:
        base = Path(td)
        no_key = candidate_row()
        no_key.pop('swing_gate_decision_key_v977')
        review.now_ts = lambda: 1000.0
        out = review.update_version_score_review(base, [no_key], generation={'cycle_id': 'c1'}, generation_integrity={})
        assert out['current_missed_v1261']['tracked_total'] == 0
        assert out['current_missed_v1261']['exact_key_missing_skipped'] == 1
        review.now_ts = lambda: 1100.0
        review.update_version_score_review(base, [candidate_row(100.0, ready=False)], generation={'cycle_id': 'c2'}, generation_integrity={})
        review.now_ts = lambda: 1200.0
        recovered = review.update_version_score_review(base, [candidate_row(101.0, ready=True)], generation={'cycle_id': 'c3'}, generation_integrity={})
        assert recovered['current_missed_v1261']['recovered_to_ready'] == 1
        assert recovered['current_missed_v1261']['active_missed'] == 0


def test_main_version_score_public_scope_is_only_two_actual_cohorts_plus_fresh_missed():
    main = load_module('main_v1261_score', 'coinbot_main_v2_13_1162.py')
    current = {
        'n': 2, 'wins': 1, 'losses': 1, 'win_rate': 50.0, 'total': -1.0, 'avg': -0.5,
        'avg_win_pct': 1.0, 'avg_loss_pct': -2.0, 'avg_mfe_pct': 0.8, 'avg_mae_pct': -1.2,
        'avg_giveback_pct': 0.5, 'avg_hold_sec': 3600.0, 'profit_then_loss_count': 1,
        'no_positive_mfe_count': 1,
        'exit_reasons': {'structure_invalid': {'n': 1, 'wins': 0, 'losses': 1, 'total': -2.0, 'avg': -2.0}},
    }
    previous = {
        'n': 4, 'wins': 3, 'losses': 1, 'win_rate': 75.0, 'total': 4.0, 'avg': 1.0,
        'avg_win_pct': 1.5, 'avg_loss_pct': -0.5, 'avg_mfe_pct': 1.8, 'avg_mae_pct': -0.4,
        'avg_giveback_pct': 0.3, 'avg_hold_sec': 1800.0, 'profit_then_loss_count': 0,
        'no_positive_mfe_count': 1,
        'exit_reasons': {'structure_target': {'n': 2, 'wins': 2, 'losses': 0, 'total': 3.0, 'avg': 1.5}},
    }
    snapshot = {
        'snapshot_id': 'snap-1', 'source_owner': 'paper',
        'counts': {'raw_ledger_rows': 10, 'exact_unique_closed': 6},
        'version_score_v1261': {
            'owner': 'paper',
            'current_strategy': {
                'state': 'NORMAL', 'closed_count': 2, 'open_count': 1,
                'closed_windows': {key: current for key in ('all','today','recent_3h','recent_6h','recent_12h','recent_24h')},
                'open': {'n': 1, 'wins': 1, 'losses': 0, 'total': 0.2, 'avg': 0.2},
                'combined': {'n': 3, 'wins': 2, 'losses': 1, 'total': -0.8, 'avg': -0.2667},
            },
            'v1211_actual': {'state': 'NORMAL', 'closed_count': 4, 'all': previous, 'legacy_missing_identity_rows': 0},
        },
    }
    review = {
        'current_missed_v1261': {
            'state': 'NORMAL', 'started_text': '2026-07-06', 'tracked_total': 1, 'active_missed': 1,
            'recovered_to_ready': 0, 'completed_6h': 1, 'positive_max_count': 1,
            'gain_1_2_count': 1, 'gain_3_count': 0, 'v1211_would_be_ready_count': 1,
            'exact_key_missing_skipped': 0, 'reason_counts': {'trigger_not_reached': 1},
            'first_touch_counts': {'TARGET': 1}, 'top': [],
        }
    }
    main._performance_snapshot = lambda: snapshot
    main._version_score_review_snapshot = lambda: review
    main.file_age = lambda _path: 1.0
    text = main.render_version_score()
    assert '[현재 통합전략' in text
    assert '[v1211 실제 거래 기준판]' in text
    assert '[현재 전략 놓친 후보' in text
    assert '[차이 해석]' in text
    assert '현재 실제 CLOSED' not in text
    assert '이전 구조선 전체시장 가상거래' not in text
    assert '전환구간·정책경쟁·구조 가상수익' in text
    assert '자동매수 OFF' in text
    compact = main.render_version_score_compact()
    assert '현재 통합전략 vs v1211 실제' in compact
    assert '놓친 후보 새 장부' in compact


def test_versions_and_no_strategy_change_contract():
    main = load_module('main_v1261_version', 'coinbot_main_v2_13_1162.py')
    paper = load_module('paper_v1261_version', 'paper_bot_v1.076.py')
    review = load_module('review_v1261_version', 'review_worker_v1.037.py')
    guard = load_module('guard_v1261_version', 'backga_guard_bot_v2_5_239.py')
    assert main.BOT_VERSION == '수익형 v2.13.1162'
    assert paper.VERSION == 'paper_bot_v1.076'
    assert review.VERSION == 'review_worker_v1.037'
    assert guard.VERSION.startswith('guard_v2.5.239_')
    assert paper.V1261_VERSION_SCORE_CONTRACT['trading_rules_changed'] is False
    assert review.V1261_REVIEW_CONTRACT['trading_rules_changed'] is False
    assert guard.V1261_PUBLIC_SCORE_CONTRACT['strategy_values_changed'] is False
    assert paper.V1261_VERSION_SCORE_CONTRACT['auto_buy'] is False
