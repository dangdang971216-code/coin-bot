from __future__ import annotations

import json
import zipfile
from pathlib import Path


def test_bundle_contract():
    bundle = Path(__file__).resolve().parents[2] / 'coinbot_update_v1261.zip'
    assert bundle.exists()
    with zipfile.ZipFile(bundle) as zf:
        names = set(zf.namelist())
        required = {
            'DEPLOY_BUNDLE.json', 'ACTIVE_VERSION_MATRIX.json',
            'coinbot_main_v2_13_1162.py', 'paper_bot_v1.076.py',
            'review_worker_v1.037.py', 'strategy_worker_v1.062.py',
            'backga_guard_bot_v2_5_239.py',
            'ledger_events_pending/V1261_ISSUE_LEDGER_EVENTS.jsonl',
            'ledger_events_pending/V1261_CHANGE_VERIFY_EVENTS.jsonl',
        }
        assert required <= names
        manifest = json.loads(zf.read('DEPLOY_BUNDLE.json').decode('utf-8'))
        assert manifest['release'] == 'v1261'
        assert manifest['auto_buy'] is False
        assert manifest['actual_trading_changed'] is False
        assert manifest['paper'] == 'paper_bot_v1.076.py'
        assert manifest['main'] == 'coinbot_main_v2_13_1162.py'
        assert manifest['workers']['review'] == 'review_worker_v1.037.py'
        assert manifest['workers']['strategy'] == 'strategy_worker_v1.062.py'
        assert manifest['public_score_scope'] == 'current unified actual + v1211 actual + fresh current missed candidates'
        assert manifest['old_review_state_imported'] is False
        assert manifest['historical_ledgers_rewritten'] is False
