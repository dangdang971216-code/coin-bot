v1615: clean stale/legacy/no-request_id active Paper refresh request file at Paper startup. No trading threshold change. Auto-buy OFF.
