coinbot_update_v2103

목적
- 새 Paper PID가 살아 있어도 canonical status가 이전 종료 PID에 머무는 시작 지연 수리
- full write_status의 성과/latency/candidate reader보다 먼저 직접 atomic identity 기록
- v2101 최고 +2% 후 0% 방어, v2100 invalid 10%+ -4% 방어 수치 변경 없음
- 기존 OPEN/CLOSED/decision/exact 재작성 없음
- 자동매수 OFF

서버 기준
- Paper paper_bot_v2.059
- build v2103_paper_fast_identity_before_heavy_status_writer_2026-07-19
- status PID = writer PID = systemd PID
- running=true
