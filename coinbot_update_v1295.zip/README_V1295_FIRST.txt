v1295 fixes Paper patch order from v1294 failed apply. Run /gupgrade_bundle first.
