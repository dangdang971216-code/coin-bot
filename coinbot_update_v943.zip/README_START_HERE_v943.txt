v943 strategy key spine 단일본선. docs 인수인계와 APPLY_AFTER_v943.txt 확인. guard 변경 없음: 1회 적용.
