v2236의 Main v2.13.2188과 Review v2.099는 출력상 이미 정상입니다.
v2237은 Guard만 교체합니다. 적용 후 /gguard_restart 1회만 필요합니다.
v2236 재적용은 필요 없습니다.
