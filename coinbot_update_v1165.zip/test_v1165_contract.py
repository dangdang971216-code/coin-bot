#!/usr/bin/env python3
from pathlib import Path
import ast, hashlib, tempfile, runpy, shutil
from collections import Counter
ROOT=Path(__file__).parent
MAIN=ROOT/'coinbot_main_v2_13_1125.py'
STRATEGY=ROOT/'strategy_worker_v1.024.py'
GUARD=ROOT/'backga_guard_bot_v2_5_194.py'
for src in (MAIN,STRATEGY,GUARD):
    mod=ast.parse(src.read_text(encoding='utf-8'))
    names=Counter(n.name for n in mod.body if isinstance(n,(ast.FunctionDef,ast.AsyncFunctionDef,ast.ClassDef)))
    assert not {k:v for k,v in names.items() if v>1}, (src.name,names)
main_text=MAIN.read_text(encoding='utf-8')
assert "BOT_VERSION = '수익형 v2.13.1125'" in main_text
assert "V650_BUILD_LABEL = 'v1165_main_startup_bind_and_runtime_truth_2026-06-30'" in main_text
assert "'issue_ledger': COMMANDS.get('issue_ledger')" in main_text
assert "'issue_ledger': render_issue_ledger_text" not in main_text[main_text.index('def bind_active_commands'):main_text.index('def _v1165_seed_startup_bind_truth_once')]
assert main_text.index("COMMANDS['issue_ledger']=render_issue_ledger_text") < main_text.rindex('if __name__ == "__main__":')
strategy_text=STRATEGY.read_text(encoding='utf-8')
assert "VERSION = 'strategy_worker_v1.024'" in strategy_text
assert 'def _v1165_count_value' in strategy_text
assert "int((result or {}).get('paper_latest_count')" not in strategy_text
assert 'error_traceback_tail_v1165' in strategy_text
assert 'obj.pop(_error_key_v1165, None)' in strategy_text
expected={
'_v1133_trigger_occurrence':'9168d76eeff876e69b8a69c0f436933b0e47fcf6a749d2ab1a34dbe78090c3b4',
'_swing_quality_gate':'1d97ab0738d5eb0bab21979aecce9161603c8dc166c4c03d4549758f21ee00f1',
'apply_swing_entry_gate':'7cd11edf742e92e77d7b9b7cd75dc9a27c7e189629f234176ad7d309dff17a01',
'_v554_apply_entry_plan_state__v1115':'a256712ce2ebe9b3813e529d55211cc68d31495345c8f9d49951005fab5ccc1d'}
mod=ast.parse(strategy_text)
for name,digest in expected.items():
    node=next(n for n in mod.body if isinstance(n,ast.FunctionDef) and n.name==name)
    assert hashlib.sha256(ast.dump(node,include_attributes=False).encode()).hexdigest()==digest,name
guard_text=GUARD.read_text(encoding='utf-8')
assert 'guard_v2.5.194_bundle_truth_worker_error_v1165_2026-06-30' in guard_text
assert 'and error_ok)' in guard_text
assert 'verdict = "❌ 실행 오류"' in guard_text
assert 'component_failures_v1165' in guard_text
assert '"ok": overall_ok' in guard_text
assert 'write_deploy_markers(matched_source.name)' in guard_text
assert '(BOT_DIR / ".deployed_target").write_text(src.name' not in guard_text
print('PASS v1165 contract')
