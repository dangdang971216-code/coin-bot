# v1165 범위와 검수

## 수정
1. Main v2.13.1125: issue command startup bind 정의 순서 복구.
2. Strategy v1.024: 후보 저장 뒤 진단 count 단일 owner, traceback 보존, 성공 cycle에서 이전 오류 명시적 종료.
3. Guard v2.5.194: component/verify 실패를 성공으로 표시하지 않음, worker error 정상 오판 차단, rollback marker versioned hash owner.

## 미수정
Paper, 매매 Gate/rank/TTL/RR/trigger/invalid/target, 청산, OPEN 한도, 자동매수.

## 서버 판정
Main/Strategy/Guard exact runtime과 hash, Strategy completed cycle error 0, Main 명령 출력, 자동매수 OFF가 모두 증명돼야 DONE.
Strategy cycle 속도는 본 버전 완료 조건이 아니며 별도 issue로 유지.
