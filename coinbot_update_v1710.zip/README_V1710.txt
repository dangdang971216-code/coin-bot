v1710 PREOPEN RESET+REBUILD owner flow + bounded trace. Auto-buy OFF. Core ledgers preserved.
