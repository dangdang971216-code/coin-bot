코인봇 v2133 · 재료진실 분류와 기존 전체봉 재수집 검증

- SOURCE_MISSING은 실제 owner 자료가 없을 때만 사용
- Trigger 대기, Trigger 지나침, invalid 없음, T1 없음, 가격순서 실패, 엔진오류를 각각 분리
- 진짜 캔들 이력 부족은 기존 structure_full_htf_mtf_ltf 재수집 배관에 연결
- 재요청 누락, 잘못된 profile, API 실패, 재수집 후 반복 부족을 검수판에서 표시
- 후보·구조계약·decision 기록 보존, 실행만 보류
- 후보수·등급·확률식·실제 Paper gate·진입·청산 변경 없음
- OPEN/CLOSED/decision/exact와 기존 Shadow 자료 보존
- 자동매수 OFF
