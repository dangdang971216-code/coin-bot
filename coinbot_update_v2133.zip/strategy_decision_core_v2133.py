from __future__ import annotations

import math
import time
from typing import Any, Dict, Iterable, List, Optional, Tuple

VERSION = "strategy_decision_core_v2133"
BUILD_LABEL = "v2133_material_truth_classification_and_refresh_verify_2026-07-21"


def _num(value: Any) -> Optional[float]:
    try:
        if value is None or isinstance(value, bool):
            return None
        out = float(value)
        if not math.isfinite(out):
            return None
        return out
    except Exception:
        return None


def _clip(value: float, low: float, high: float) -> float:
    return max(low, min(high, float(value)))


def _sigmoid(value: float) -> float:
    value = _clip(value, -12.0, 12.0)
    return 1.0 / (1.0 + math.exp(-value))


def _line_price(obj: Any) -> Optional[float]:
    if not isinstance(obj, dict):
        return None
    for key in ("price", "rounded_price", "raw_price", "target2_price"):
        value = _num(obj.get(key))
        if value is not None and value > 0:
            return value
    return None


def _first_dict(row: Dict[str, Any], keys: Iterable[str]) -> Dict[str, Any]:
    for key in keys:
        value = row.get(key)
        if isinstance(value, dict):
            return value
    return {}


def _current_price(row: Dict[str, Any]) -> Optional[float]:
    for obj in (
        row,
        row.get("raw") if isinstance(row.get("raw"), dict) else {},
        row.get("candidate_row") if isinstance(row.get("candidate_row"), dict) else {},
        row.get("entry_context") if isinstance(row.get("entry_context"), dict) else {},
    ):
        if not isinstance(obj, dict):
            continue
        for key in (
            "current_price",
            "price",
            "trade_price",
            "close",
            "last_price",
            "entry_price",
            "expected_entry_price",
        ):
            value = _num(obj.get(key))
            if value is not None and value > 0:
                return value
    return None


def _event_key(row: Dict[str, Any]) -> str:
    for key in (
        "candidate_event_key_v2002",
        "candidate_event_key",
        "quality_event_key_v946",
        "event_id",
        "event_key",
        "decision_key",
    ):
        value = str(row.get(key) or "").strip()
        if value:
            return value
    contract = _first_dict(row, ("clean_entry_contract_v2038", "entry_owner_contract_v2038"))
    immutable = contract.get("immutable") if isinstance(contract.get("immutable"), dict) else {}
    return str(immutable.get("decision_key") or "").strip()


def _ticker(row: Dict[str, Any]) -> str:
    text = str(row.get("ticker") or row.get("symbol") or "").upper().strip()
    if text.startswith("KRW-"):
        text = text[4:]
    return text


def _score_linear(value: Optional[float], scale: float, *, inverse: bool = False) -> Optional[float]:
    if value is None:
        return None
    direction = -1.0 if inverse else 1.0
    return _clip(50.0 + float(value) * float(scale) * direction, 0.0, 100.0)


def _build_direct_evidence_v2133(row: Dict[str, Any]) -> Dict[str, Any]:
    """Read owner evidence directly; never reuse the v2130 aggregate score."""
    market = _first_dict(row, ("global_market_context_v2130", "market_context_v2130"))
    feature = _first_dict(row, ("feature_momentum_context_v2130",))
    orderflow = _first_dict(row, ("orderflow_continuation_v2130",))
    axes: Dict[str, Dict[str, Any]] = {}
    missing: List[str] = []

    def add(name: str, score: Optional[float], value: Any, owner: str, group: str) -> None:
        if score is None:
            axes[name] = {"state": "SOURCE_MISSING", "value": value, "owner": owner, "group": group}
            missing.append(name)
            return
        axes[name] = {"state": "READY", "score": round(_clip(score, 0.0, 100.0), 4), "value": value, "owner": owner, "group": group}

    add("global_market", _num(market.get("continuation_score_v2130")), market.get("state"), "market_regime_worker", "market")
    btc = str(market.get("btc_short_direction") or "").upper()
    add("btc_short_direction", {"STRONG_UP":82.0,"UP":72.0,"FLAT":50.0,"MIXED":48.0,"DOWN":28.0,"STRONG_DOWN":18.0}.get(btc), btc or None, "market_regime_worker", "market")
    ext = market.get("external_market_lead_v2130") if isinstance(market.get("external_market_lead_v2130"), dict) else {}
    ext_dir = str(ext.get("direction") or "").upper() if ext.get("state") == "READY" else ""
    add("external_market_lead", {"STRONG_UP":82.0,"UP":72.0,"FLAT":50.0,"MIXED":48.0,"DOWN":28.0,"STRONG_DOWN":18.0}.get(ext_dir), ext_dir or None, "market_regime_worker", "market")
    add("breadth_velocity", _score_linear(_num(market.get("breadth_velocity_pct_v2130")), 5.0), market.get("breadth_velocity_pct_v2130"), "market_regime_worker", "market")
    add("leader_persistence", _num(market.get("leader_persistence_pct_v2130")), market.get("leader_persistence_pct_v2130"), "market_regime_worker", "market")

    add("relative_strength_velocity", _score_linear(_num(feature.get("relative_strength_velocity_v2130")), 8.0), feature.get("relative_strength_velocity_v2130"), "feature_worker", "feature")
    add("money_flow_velocity", _score_linear(_num(feature.get("money_flow_velocity_v2130")), 1.6), feature.get("money_flow_velocity_v2130"), "feature_worker", "feature")
    add("momentum_consistency", _num(feature.get("momentum_consistency_pct_v2130")), feature.get("momentum_consistency_pct_v2130"), "feature_worker", "feature")
    add("location_hold", _num(feature.get("location_hold_score_v2130")), feature.get("location_state_v2130"), "feature_worker", "feature")

    add("orderflow_continuation", _num(orderflow.get("continuation_score_v2130")), orderflow.get("state"), "orderflow_worker", "orderflow")
    add("buy_sustain_velocity", _score_linear(_num(orderflow.get("buy_sustain_delta_v2130")), 180.0), orderflow.get("buy_sustain_delta_v2130"), "orderflow_worker", "orderflow")
    add("ask_wall_depletion", _score_linear(_num(orderflow.get("ask_wall_depletion_v2130")), 35.0), orderflow.get("ask_wall_depletion_v2130"), "orderflow_worker", "orderflow")
    add("spread_stability", _score_linear(_num(orderflow.get("spread_delta_v2130")), 220.0, inverse=True), orderflow.get("spread_delta_v2130"), "orderflow_worker", "orderflow")

    groups: Dict[str, List[float]] = {"market": [], "feature": [], "orderflow": []}
    for item in axes.values():
        if item.get("state") == "READY" and item.get("group") in groups:
            groups[str(item.get("group"))].append(float(item.get("score")))
    group_scores = {key: (sum(values) / len(values) if values else None) for key, values in groups.items()}
    weights = {"market": 0.30, "feature": 0.30, "orderflow": 0.40}
    numerator = sum(float(group_scores[k]) * weights[k] for k in group_scores if group_scores[k] is not None)
    denominator = sum(weights[k] for k in group_scores if group_scores[k] is not None)
    score = numerator / denominator if denominator > 0 else None
    ready_axes = sum(1 for item in axes.values() if item.get("state") == "READY")
    confidence = ready_axes / max(1, len(axes)) * 100.0
    ready_groups = sum(1 for value in group_scores.values() if value is not None)
    state = "READY" if score is not None and ready_groups >= 2 else "SOURCE_MISSING"
    return {
        "schema": "direct_continuation_evidence_v2132", "state": state,
        "score": round(score, 4) if score is not None else None, "confidence_pct": round(confidence, 3),
        "ready_groups": ready_groups, "group_scores": {k: (round(v,4) if v is not None else None) for k,v in group_scores.items()},
        "axes": axes, "source_missing": sorted(set(missing)),
        "legacy_v2130_aggregate_used": False, "structure_score_used": False, "auto_buy": False,
    }


def _structure_source(row: Dict[str, Any]) -> Dict[str, Any]:
    value = row.get("unified_structure_contract_v2110")
    return value if isinstance(value, dict) else {}


def _structure_material_diagnosis_v2133(
    row: Dict[str, Any],
    structure: Dict[str, Any],
    *,
    reference_entry: Optional[float],
    invalid: Optional[float],
    t1: Optional[float],
) -> Dict[str, Any]:
    """Separate true source gaps from normal wait states and structure absence.

    SOURCE_MISSING is reserved for missing owner-produced information.  A candidate
    that has complete candles but no trigger/support/T1 is not a data gap: it is a
    WAIT or structure-geometry result and must remain visible without refetch spam.
    """
    ticker = _ticker(row)
    current = _current_price(row)
    final_state = str(structure.get("final_state") or "RECHECK").upper()
    stage = str(structure.get("failure_stage") or "").strip().lower()
    reason = str(structure.get("failure_reason") or "").strip()
    reason_low = reason.lower()
    missing_tf = [str(x) for x in (structure.get("missing_timeframes") or []) if str(x)]
    checks = structure.get("stage_checks") if isinstance(structure.get("stage_checks"), dict) else {}
    inventory = structure.get("source_inventory_v2133") if isinstance(structure.get("source_inventory_v2133"), dict) else {}
    frame_counts = inventory.get("frame_counts") if isinstance(inventory.get("frame_counts"), dict) else {}
    source_complete = bool(inventory.get("source_complete"))

    state = "READY"
    subtype = "STRUCTURE_READY"
    owner = "strategy_worker.structure_engine"
    collectable = False
    action = "NONE"
    normal_wait = False
    true_data_missing = False
    execution_hold_only = False
    severity = "PASS"

    if not structure:
        state, subtype, owner = "ENGINE_ERROR", "STRUCTURE_CONTRACT_MISSING", "strategy_worker"
        action, severity = "REPAIR_CONTRACT_WRITER", "FAIL"
    elif final_state == "EXECUTABLE" and reference_entry and invalid and t1:
        state, subtype = "READY", "STRUCTURE_READY"
    elif stage == "source":
        true_data_missing = True
        collectable = True
        execution_hold_only = True
        severity = "CHECK"
        action = "REQUEST_EXISTING_FULL_CANDLE_PROFILE"
        owner = "candle_worker"
        if not ticker:
            state, subtype, owner = "DATA_MISSING", "TICKER_IDENTITY_MISSING", "scanner_worker"
            collectable = False
            action, severity = "REPAIR_CANDIDATE_IDENTITY", "FAIL"
        elif current is None or current <= 0:
            state, subtype, owner = "DATA_MISSING", "CURRENT_PRICE_MISSING", "feature_worker"
            action = "REFRESH_PRICE_OWNER"
        elif missing_tf:
            state, subtype = "DATA_MISSING", "COMPLETED_CANDLE_HISTORY_MISSING"
        elif "completed" in reason_low or "candle" in reason_low:
            state, subtype = "DATA_MISSING", "CANDLE_ROW_OR_PROOF_MISSING"
        else:
            state, subtype = "DATA_MISSING", "OWNER_SOURCE_MISSING_UNCLASSIFIED"
    elif stage == "trigger":
        normal_wait = True
        execution_hold_only = True
        if "too far above" in reason_low or str(checks.get("trigger_confirm") or "").upper() == "STALE_CHASE_RECHECK":
            state, subtype = "TRIGGER_PASSED", "CONFIRMED_TRIGGER_ALREADY_PASSED"
            action = "PRESERVE_FIRST_EVENT_AND_WAIT_NEW_EVENT"
        else:
            state, subtype = "WAIT_TRIGGER", "NO_COMPLETED_TRIGGER_EVENT_YET"
            action = "WAIT_FOR_FIRST_COMPLETED_TRIGGER_EVENT"
    elif stage == "invalid":
        execution_hold_only = True
        state, subtype = "NO_INVALID_STRUCTURE", "NO_CONFIRMED_SUPPORT_BELOW_TRIGGER"
        action = "OBSERVE_STRUCTURE_OR_REVIEW_ENGINE_IF_REPEATED"
        severity = "CHECK"
    elif stage == "target":
        execution_hold_only = True
        state, subtype = "NO_REACHABLE_T1", "NO_QUALIFIED_RESISTANCE_ABOVE_ENTRY"
        action = "OBSERVE_STRUCTURE_OR_REVIEW_LOOKBACK_IF_REPEATED"
        severity = "CHECK"
    elif stage == "price_order":
        execution_hold_only = True
        state, subtype = "PRICE_ORDER_INVALID", "INVALID_ENTRY_T1_ORDER_FAILED"
        action, severity = "REVIEW_STRUCTURE_GEOMETRY", "CHECK"
    elif stage == "engine_error":
        state, subtype = "ENGINE_ERROR", "STRUCTURE_ENGINE_EXCEPTION"
        action, severity = "REPAIR_STRUCTURE_ENGINE", "FAIL"
    elif stage == "event_risk":
        normal_wait = True
        execution_hold_only = True
        state, subtype = "EVENT_RISK_BLOCK", "EXPLICIT_EVENT_RISK"
        action = "KEEP_POLICY_BLOCK_AND_PRESERVE_CANDIDATE"
    elif stage == "market_regime":
        normal_wait = True
        execution_hold_only = True
        state, subtype = "MARKET_WEAK_WAIT", "MARKET_COLLAPSE_OR_WEAK_REGIME"
        action = "WAIT_MARKET_RECOVERY_WITHOUT_DELETING_CANDIDATE"
    elif reference_entry and invalid and t1 and not (invalid < reference_entry < t1):
        state, subtype = "PRICE_ORDER_INVALID", "INVALID_ENTRY_T1_ORDER_FAILED"
        action, severity = "REVIEW_STRUCTURE_GEOMETRY", "CHECK"
    else:
        execution_hold_only = True
        state, subtype = "STRUCTURE_NOT_EXECUTABLE", "UNCLASSIFIED_STRUCTURE_WAIT"
        action, severity = "KEEP_VISIBLE_AND_REVIEW_FAILURE_STAGE", "CHECK"

    return {
        "schema": "structure_material_diagnosis_v2133",
        "state": state,
        "subtype": subtype,
        "owner": owner,
        "severity": severity,
        "failure_stage": stage or None,
        "failure_reason": reason or None,
        "missing_timeframes": missing_tf,
        "frame_counts": frame_counts,
        "source_complete": source_complete,
        "true_data_missing": true_data_missing,
        "collectable": collectable,
        "required_action": action,
        "normal_wait": normal_wait,
        "execution_hold_only": execution_hold_only,
        "candidate_preserved": True,
        "candidate_quality_failed": False,
        "source_missing_label_allowed": true_data_missing,
        "auto_buy": False,
    }


def build_trade_path_contract_v2133(row: Dict[str, Any], *, now_ts: Optional[float] = None) -> Dict[str, Any]:
    """Build the clean trade-path contract and preserve material truth.

    v2133 keeps the v2132 role architecture but reserves SOURCE_MISSING for real
    owner-data gaps. Trigger wait, passed trigger, no support, no T1 and price-order
    failure are explicit non-data states. No candidate, entry, exit or gate changes.
    """
    ts = float(now_ts if now_ts is not None else time.time())
    structure = _structure_source(row)
    evidence = _build_direct_evidence_v2133(row)

    trigger = _line_price(structure.get("trigger"))
    invalid = _line_price(structure.get("execution_invalid"))
    structural_invalid = _line_price(structure.get("structural_invalid"))
    t1 = _line_price(structure.get("target_t1"))
    t2 = _line_price(structure.get("target_t2"))
    current = _current_price(row)
    reference_entry = trigger or current
    structure_state = str(structure.get("final_state") or "RECHECK").upper()
    material = _structure_material_diagnosis_v2133(
        row, structure, reference_entry=reference_entry, invalid=invalid, t1=t1
    )

    geometry_state = str(material.get("state") or "STRUCTURE_NOT_EXECUTABLE")
    risk_pct = t1_room_pct = t2_room_pct = rr_t1 = rr_t2 = None
    if reference_entry and invalid and t1:
        if invalid < reference_entry < t1:
            risk_pct = (reference_entry - invalid) / reference_entry * 100.0
            t1_room_pct = (t1 - reference_entry) / reference_entry * 100.0
            t2_room_pct = ((t2 - reference_entry) / reference_entry * 100.0) if t2 and t2 > t1 else None
            rr_t1 = t1_room_pct / risk_pct if risk_pct > 0 else None
            rr_t2 = t2_room_pct / risk_pct if risk_pct > 0 and t2_room_pct is not None else None
            if structure_state == "EXECUTABLE":
                geometry_state = "READY"
        else:
            geometry_state = "PRICE_ORDER_INVALID"

    pred_state = str(evidence.get("state") or "SOURCE_MISSING")
    evidence_score = _num(evidence.get("score"))
    confidence = _num(evidence.get("confidence_pct"))
    prediction_missing = [str(x) for x in (evidence.get("source_missing") or []) if str(x)]

    prior_state = "SOURCE_MISSING" if pred_state != "READY" else "WAIT_STRUCTURE"
    p_t1 = p_t2 = p_invalid = p_no_touch = None
    expected_mfe = expected_mae = expected_t1_sec = cost_free_ev = None
    if geometry_state == "READY" and evidence_score is not None and risk_pct and t1_room_pct is not None:
        strength_z = (evidence_score - 50.0) / 12.0
        rr = max(0.05, float(rr_t1 or 0.05))
        min_move = max(0.05, min(risk_pct, t1_room_pct))
        touch_logit = 0.55 + 0.45 * abs(strength_z) - 0.20 * max(0.0, min_move - 1.0)
        p_touch_any = _clip(_sigmoid(touch_logit), 0.18, 0.94)
        direction_logit = 0.92 * strength_z - 0.34 * math.log(max(rr, 0.10))
        p_up_given_touch = _clip(_sigmoid(direction_logit), 0.05, 0.95)
        p_t1 = p_touch_any * p_up_given_touch
        p_invalid = p_touch_any * (1.0 - p_up_given_touch)
        p_no_touch = 1.0 - p_touch_any
        if t2_room_pct is not None and t2_room_pct > t1_room_pct:
            extension_ratio = t2_room_pct / max(t1_room_pct, 0.01)
            p_extend_given_t1 = _clip(_sigmoid(0.70 * strength_z - 0.75 * (extension_ratio - 1.0)), 0.03, 0.88)
            p_t2 = p_t1 * p_extend_given_t1
        else:
            p_t2 = 0.0
        expected_mfe = (
            p_t1 * t1_room_pct
            + float(p_t2 or 0.0) * max(0.0, float(t2_room_pct or t1_room_pct) - t1_room_pct)
            + p_no_touch * min(t1_room_pct, max(0.10, t1_room_pct * 0.35))
        )
        expected_mae = -(
            p_invalid * risk_pct
            + p_t1 * min(risk_pct, max(0.10, risk_pct * 0.30))
            + p_no_touch * min(risk_pct, max(0.10, risk_pct * 0.45))
        )
        cost_free_ev = p_t1 * t1_room_pct - p_invalid * risk_pct
        speed = max(0.15, abs(strength_z) + 0.35)
        expected_t1_sec = _clip(3600.0 * (t1_room_pct / speed), 300.0, 21600.0)
        prior_state = "UNCALIBRATED_PRIOR"

    selected_target = "NONE"
    if p_t1 is not None:
        selected_target = "T2_EXTENSION" if t2 and (p_t2 or 0.0) >= 0.30 else "T1_BASE"

    preview_state = "OBSERVE"
    reasons: List[str] = []
    material_state = str(material.get("state") or "STRUCTURE_NOT_EXECUTABLE")
    if material.get("true_data_missing"):
        preview_state = "DATA_MISSING"
        reasons.append(str(material.get("subtype") or "DATA_MISSING"))
    elif material_state in {"WAIT_TRIGGER", "TRIGGER_PASSED", "MARKET_WEAK_WAIT", "EVENT_RISK_BLOCK"}:
        preview_state = material_state
        reasons.append(material_state)
    elif material_state in {"NO_INVALID_STRUCTURE", "NO_REACHABLE_T1", "STRUCTURE_NOT_EXECUTABLE"}:
        preview_state = "OBSERVE_STRUCTURE_GAP"
        reasons.append(material_state)
    elif material_state in {"PRICE_ORDER_INVALID", "ENGINE_ERROR"}:
        preview_state = material_state
        reasons.append(material_state)
    elif pred_state != "READY":
        preview_state = "PREDICTION_DATA_MISSING"
        reasons.append("PREDICTION_INPUT_NOT_READY")
    elif prior_state == "UNCALIBRATED_PRIOR" and structure_state == "EXECUTABLE":
        preview_state = "PAPER_PREVIEW_READY"

    true_source_missing: List[str] = []
    if material.get("true_data_missing"):
        true_source_missing.extend(str(x) for x in (material.get("missing_timeframes") or []) if str(x))
        if not true_source_missing:
            true_source_missing.append(str(material.get("subtype") or "structure_source"))
    true_source_missing.extend(prediction_missing)

    diagnostics = {
        "structure_owner": "strategy_worker.structure_engine",
        "prediction_owner": "strategy_decision_core_v2133",
        "execution_owner": "paper_bot.actual_price_cost_preview",
        "outcome_owner": "review_worker.first_touch_calibration",
        "material_owner": str(material.get("owner") or "strategy_worker"),
        "wrong_structure_signal": "price order/no support/no reachable T1 with source completeness separated",
        "wrong_prediction_signal": "high predicted T1 probability but invalid touches first",
        "wrong_execution_signal": "contract positive at reference but actual entry/cost EV non-positive",
        "wrong_exit_signal": "T1 touched before invalid but realized CLOSED remains materially negative",
    }

    return {
        "schema": "trade_path_contract_v2133",
        "version": VERSION,
        "build": BUILD_LABEL,
        "state": preview_state,
        "ticker": _ticker(row),
        "event_key": _event_key(row),
        "evaluated_ts": ts,
        "roles": {
            "structure": "ENTRY_LOCATION_INVALID_T1_T2_ONLY",
            "prediction": "TARGET_FIRST_TOUCH_PROBABILITY_ONLY",
            "execution": "ACTUAL_ENTRY_SPREAD_SLIPPAGE_COST_ONLY",
            "outcome": "FIRST_TOUCH_MFE_MAE_CALIBRATION_ONLY",
            "material_truth": "SOURCE_VS_WAIT_VS_STRUCTURE_GAP_CLASSIFICATION_ONLY",
        },
        "material_diagnosis": material,
        "structure": {
            "state": structure_state,
            "geometry_state": geometry_state,
            "reference_entry": round(reference_entry, 12) if reference_entry else None,
            "current_price": round(current, 12) if current else None,
            "trigger": round(trigger, 12) if trigger else None,
            "execution_invalid": round(invalid, 12) if invalid else None,
            "structural_invalid": round(structural_invalid, 12) if structural_invalid else None,
            "target_t1": round(t1, 12) if t1 else None,
            "target_t2": round(t2, 12) if t2 else None,
            "risk_pct": round(risk_pct, 6) if risk_pct is not None else None,
            "t1_room_pct": round(t1_room_pct, 6) if t1_room_pct is not None else None,
            "t2_room_pct": round(t2_room_pct, 6) if t2_room_pct is not None else None,
            "rr_t1": round(rr_t1, 6) if rr_t1 is not None else None,
            "rr_t2": round(rr_t2, 6) if rr_t2 is not None else None,
            "selected_target_role": selected_target,
        },
        "prediction": {
            "state": prior_state,
            "input_state": pred_state,
            "evidence_score": round(evidence_score, 4) if evidence_score is not None else None,
            "confidence_pct": round(confidence, 3) if confidence is not None else None,
            "p_t1_before_invalid": round(p_t1, 6) if p_t1 is not None else None,
            "p_t2_before_invalid": round(p_t2, 6) if p_t2 is not None else None,
            "p_invalid_before_t1": round(p_invalid, 6) if p_invalid is not None else None,
            "p_no_touch_6h": round(p_no_touch, 6) if p_no_touch is not None else None,
            "expected_mfe_pct_6h": round(expected_mfe, 6) if expected_mfe is not None else None,
            "expected_mae_pct_6h": round(expected_mae, 6) if expected_mae is not None else None,
            "expected_t1_time_sec": round(expected_t1_sec, 1) if expected_t1_sec is not None else None,
            "cost_free_ev_t1_pct": round(cost_free_ev, 6) if cost_free_ev is not None else None,
            "probability_is_calibrated": False,
            "model_role": "TRANSPARENT_UNCALIBRATED_PRIOR_FOR_FORWARD_VALIDATION",
            "direct_evidence": evidence,
            "legacy_v2130_aggregate_used": False,
        },
        "source_missing": sorted(set(true_source_missing)),
        "preview_reasons": sorted(set(reasons)),
        "diagnostics": diagnostics,
        "paper_trade_gate_active": False,
        "candidate_grade_changed": False,
        "candidate_deleted": False,
        "existing_open_changed": False,
        "historical_ledger_rewritten": False,
        "activation_lock": "REVIEW_CALIBRATION_PLUS_EXACT_EXPECTANCY_PLUS_USER_APPROVAL",
        "auto_buy": False,
    }

def compact_trade_path_contract_v2133(value: Any) -> Dict[str, Any]:
    if not isinstance(value, dict):
        return {}
    structure = value.get("structure") if isinstance(value.get("structure"), dict) else {}
    prediction = value.get("prediction") if isinstance(value.get("prediction"), dict) else {}
    material = value.get("material_diagnosis") if isinstance(value.get("material_diagnosis"), dict) else {}
    return {
        "schema": "trade_path_contract_v2133_compact",
        "version": value.get("version"),
        "state": value.get("state"),
        "event_key": value.get("event_key"),
        "roles": value.get("roles"),
        "material_diagnosis": {k: material.get(k) for k in (
            "state", "subtype", "owner", "severity", "failure_stage", "failure_reason",
            "missing_timeframes", "frame_counts", "source_complete", "true_data_missing",
            "collectable", "required_action", "normal_wait", "execution_hold_only",
            "candidate_preserved", "candidate_quality_failed", "source_missing_label_allowed"
        )},
        "structure": {k: structure.get(k) for k in (
            "state", "geometry_state", "reference_entry", "trigger", "execution_invalid",
            "structural_invalid", "target_t1", "target_t2", "risk_pct", "t1_room_pct",
            "t2_room_pct", "rr_t1", "rr_t2", "selected_target_role"
        )},
        "prediction": {k: prediction.get(k) for k in (
            "state", "input_state", "evidence_score", "confidence_pct", "p_t1_before_invalid",
            "p_t2_before_invalid", "p_invalid_before_t1", "p_no_touch_6h",
            "expected_mfe_pct_6h", "expected_mae_pct_6h", "expected_t1_time_sec",
            "cost_free_ev_t1_pct", "probability_is_calibrated", "model_role", "legacy_v2130_aggregate_used"
        )},
        "source_missing": list(value.get("source_missing") or [])[:16],
        "preview_reasons": list(value.get("preview_reasons") or [])[:12],
        "paper_trade_gate_active": False,
        "activation_lock": value.get("activation_lock"),
        "auto_buy": False,
    }


def build_paper_execution_preview_v2133(
    contract: Dict[str, Any],
    *,
    actual_entry_price: Optional[float],
    spread_pct: Optional[float] = None,
    slippage_pct: Optional[float] = None,
    fee_pct: Optional[float] = None,
) -> Dict[str, Any]:
    structure = contract.get("structure") if isinstance(contract.get("structure"), dict) else {}
    prediction = contract.get("prediction") if isinstance(contract.get("prediction"), dict) else {}
    entry = _num(actual_entry_price)
    invalid = _num(structure.get("execution_invalid"))
    t1 = _num(structure.get("target_t1"))
    t2 = _num(structure.get("target_t2"))
    spread = max(0.0, _num(spread_pct) or 0.0)
    slippage = max(0.0, _num(slippage_pct) or 0.0)
    fee = max(0.0, _num(fee_pct) or 0.0)
    roundtrip_cost = spread + slippage + fee
    state = "DATA_MISSING"
    rr = room = risk = net_ev = None
    reasons: List[str] = []
    if entry and invalid and t1 and invalid < entry < t1:
        risk = (entry - invalid) / entry * 100.0
        room = (t1 - entry) / entry * 100.0
        rr = room / risk if risk > 0 else None
        p_t1 = _num(prediction.get("p_t1_before_invalid"))
        p_invalid = _num(prediction.get("p_invalid_before_t1"))
        if p_t1 is not None and p_invalid is not None:
            net_ev = p_t1 * room - p_invalid * risk - roundtrip_cost
            state = "READY_UNCALIBRATED_PREVIEW"
        else:
            reasons.append("PREDICTION_PROBABILITY_MISSING")
    else:
        reasons.append("ACTUAL_PRICE_ORDER_INVALID")
    return {
        "schema": "paper_execution_preview_v2133",
        "state": state,
        "actual_entry_price": round(entry, 12) if entry else None,
        "execution_invalid": round(invalid, 12) if invalid else None,
        "target_t1": round(t1, 12) if t1 else None,
        "target_t2": round(t2, 12) if t2 else None,
        "actual_risk_pct": round(risk, 6) if risk is not None else None,
        "actual_t1_room_pct": round(room, 6) if room is not None else None,
        "actual_rr_t1": round(rr, 6) if rr is not None else None,
        "spread_pct": round(spread, 6),
        "slippage_pct": round(slippage, 6),
        "fee_pct": round(fee, 6),
        "roundtrip_cost_pct": round(roundtrip_cost, 6),
        "net_ev_t1_pct_uncalibrated": round(net_ev, 6) if net_ev is not None else None,
        "reasons": reasons,
        "paper_trade_gate_active": False,
        "actual_selection_changed": False,
        "auto_buy": False,
    }
