#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
strategy_worker_v0.710.py

TRUE REBUILD STRATEGY SPINE
- Single owner of canonical rows and S1/S2/S3_watch/coverage classification.
- No paper ledger read, no trade opening.
"""
from __future__ import annotations

import json, os, time, traceback
from pathlib import Path
from typing import Any, Dict, List, Tuple
from collections import Counter

BASE_DIR = Path(os.getenv("TRADING_BOT_DIR", Path(__file__).resolve().parent))
VERSION = "strategy_worker_v0.710"
BUILD = "v710_true_clean_strategy_spine_2026-06-04"
INTERVAL_SEC = float(os.getenv("STRATEGY_WORKER_INTERVAL_SEC", "3"))
EXPERIMENT_EXPORT_MAX = int(os.getenv("STRATEGY_EXPERIMENT_EXPORT_MAX", "12"))

def now_ts() -> float: return time.time()
def fnum(v: Any, default: float = 0.0) -> float:
    try:
        if v is None or v == "": return default
        return float(str(v).replace(",", "").replace("%", ""))
    except Exception: return default
def load_json(name: str, default: Any=None) -> Any:
    p = BASE_DIR / name
    try:
        if not p.exists(): return default
        return json.loads(p.read_text(encoding="utf-8"))
    except Exception: return default
def save_json(name: str, data: Any) -> None:
    p = BASE_DIR / name; tmp = p.with_suffix(p.suffix + ".tmp")
    tmp.write_text(json.dumps(data, ensure_ascii=False, indent=2), encoding="utf-8"); tmp.replace(p)
def write_text(name: str, text: str) -> None:
    (BASE_DIR / name).write_text(text, encoding="utf-8")
def append_jsonl(name: str, row: Dict[str,Any]) -> None:
    with (BASE_DIR/name).open("a", encoding="utf-8") as f: f.write(json.dumps(row, ensure_ascii=False)+"\n")
def log_error(where: str, exc: Exception) -> None:
    append_jsonl("strategy_worker_errorlog.jsonl", {"ts":now_ts(),"where":where,"error":repr(exc),"trace":traceback.format_exc()[-2000:]})
def extract_rows(data: Any) -> List[Dict[str,Any]]:
    if isinstance(data, list): return [x for x in data if isinstance(x, dict)]
    if not isinstance(data, dict): return []
    for k in ["rows","items","candidates","markets","tickers","data","results"]:
        v=data.get(k)
        if isinstance(v, list): return [x for x in v if isinstance(x, dict)]
        if isinstance(v, dict): return [x for x in v.values() if isinstance(x, dict)]
    vals=[v for v in data.values() if isinstance(v,dict)]
    if vals and any("symbol" in v or "ticker" in v or "market" in v for v in vals): return vals
    return []
def norm_symbol(r: Dict[str,Any]) -> str:
    for k in ["symbol","ticker","market","code"]:
        v=r.get(k)
        if v: return str(v).replace("KRW-","").upper()
    return ""
def first_num(r: Dict[str,Any], keys: List[str], default: float=0.0) -> float:
    for k in keys:
        x=fnum(r.get(k),0)
        if x: return x
    return default
def row_map(rows: List[Dict[str,Any]]) -> Dict[str,Dict[str,Any]]:
    return {norm_symbol(r): r for r in rows if norm_symbol(r)}
def cache_age(r: Dict[str,Any]) -> float:
    t=fnum(r.get("ts") or r.get("updated_at") or r.get("timestamp"),0)
    return now_ts()-t if t else 9999.0

def read_sources():
    scanner = extract_rows(load_json("clean_scanner_market_cache.json", []))
    if not scanner:
        scanner = extract_rows(load_json("clean_scanner_hot_rank_cache.json", []))
    feature = row_map(extract_rows(load_json("clean_feature_cache.json", [])))
    orderflow = row_map(extract_rows(load_json("clean_orderflow_summary_cache.json", [])))
    risk = row_map(extract_rows(load_json("clean_risk_filter_cache.json", [])))
    return scanner, feature, orderflow, risk

def canonicalize(srow: Dict[str,Any], feature: Dict[str,Any], order: Dict[str,Any], risk: Dict[str,Any]) -> Dict[str,Any]:
    sym = norm_symbol(srow)
    price = first_num(order, ["current_price","price","last_price"], 0) or first_num(feature, ["current_price","price","close"], 0) or first_num(srow, ["current_price","trade_price","price","close"], 0)
    chg1 = first_num(feature, ["change_1m_pct","price_chg_60s","chg_1m_pct"], 0)
    if not chg1:
        chg1 = first_num(srow, ["change_1m_pct","signed_change_rate","change_rate"], 0)
        if abs(chg1) < 1 and chg1 != 0: chg1 *= 100
    buy_ratio = first_num(order, ["buy_ratio","buy_trade_ratio","bid_ratio"], 0)
    buy_sustain = first_num(order, ["buy_sustain","buy_sustain_1m","sustain"], 0)
    spread = first_num(order, ["spread_pct","spread"], 0)
    slip = first_num(order, ["slippage_pct","expected_slippage_pct","slip_pct"], spread)
    R = first_num(risk, ["risk_score","R","risk"], 0)
    # Quality score is intentionally soft. It is for ranking, not fixed trade count restriction.
    q = 0.0
    q += max(0, min(25, chg1 * 25 / 0.8))
    q += max(0, min(25, buy_ratio * 25))
    q += max(0, min(25, buy_sustain * 25))
    q += max(0, min(15, (0.50 - spread) * 30))
    q += max(0, min(10, (0.50 - slip) * 20))
    q = round(q, 1)
    reasons, risks = [], []
    if chg1 < 0.35: reasons.append(f"가격반응 {chg1:+.2f}%<+0.35%")
    if buy_ratio < 0.70: reasons.append(f"매수체결 {buy_ratio:.2f}<0.70")
    if buy_sustain < 0.70: reasons.append(f"1분지속 {buy_sustain:.2f}<0.70")
    if spread > 0.22: risks.append(f"스프레드부담 {spread:.2f}%")
    if slip > 0.22: risks.append(f"미끄러짐부담 {slip:.2f}%")
    if R > 45: risks.append(f"R {R:.1f}>45")
    hard_risk = spread > 0.85 or slip > 0.85 or R > 80
    # Classification: keep S3_watch alive. Do not dump every residue into S3.
    if not hard_risk and chg1 >= 0.35 and buy_ratio >= 0.70 and buy_sustain >= 0.70 and spread <= 0.22 and slip <= 0.22 and R <= 45:
        stage = "S1"
    elif not hard_risk and q >= 65 and R <= 45:
        stage = "S2"
    elif not hard_risk and q >= 38 and (chg1 >= 0.10 or buy_ratio >= 0.45 or buy_sustain >= 0.45 or R <= 35):
        stage = "S3_watch"
    elif hard_risk:
        stage = "excluded"
    else:
        stage = "coverage"
    if stage == "coverage":
        reasons.extend(["coverage: base/spike 미통과", "전략조건 미충족·관찰 유지"])
    strategy, strategy_name = "market_coverage", "코인품질 전체커버"
    if stage in {"S1","S2","S3_watch"}:
        if chg1 >= 0.35 and buy_ratio >= 0.55: strategy, strategy_name = "flow_reaccel", "돈흐름 재가속"
        elif R <= 25 and (buy_ratio >= 0.55 or buy_sustain >= 0.55): strategy, strategy_name = "leader_flow_hold", "주도흐름 유동보유"
        else: strategy, strategy_name = "watch_quality", "관찰품질 후보"
    age = min(cache_age(x) for x in [srow, feature, order] if isinstance(x, dict)) if any([srow, feature, order]) else 9999
    exp_open = stage in {"S2","S3_watch"} and q >= 65 and R <= 25
    return {
        "ts": now_ts(), "symbol": sym, "current_price": price,
        "change_1m_pct": chg1, "buy_ratio": buy_ratio, "buy_sustain": buy_sustain,
        "spread_pct": spread, "slippage_pct": slip, "risk_score": R, "quality_score": q,
        "grade": "S3" if stage == "S3_watch" else stage, "stage": stage,
        "strategy": strategy, "strategy_name": strategy_name,
        "block_reasons": reasons, "risk_tags": risks, "stale": age > 20,
        "source": "strategy_worker_v710",
        "paper_experiment_open": exp_open, "paper_experiment_lane": "fast_quality_paper_v710" if exp_open else "",
        "trigger_price": price * 1.003 if price else 0,
    }
def top(rows,key):
    c=Counter()
    for r in rows:
        v=r.get(key) or []
        if isinstance(v,str): v=[v]
        for x in v:
            if x: c[str(x)] += 1
    return c.most_common(8)
def write_outputs(rows):
    cnt=Counter(r["stage"] for r in rows)
    actionable=[r for r in rows if r["stage"] in {"S1","S2","S3_watch"}]
    paper=[r for r in actionable if r["stage"]=="S1"]
    exp=[r for r in actionable if r.get("paper_experiment_open")][:EXPERIMENT_EXPORT_MAX]
    stale={"all":sum(1 for r in rows if r.get("stale")),"actionable":sum(1 for r in actionable if r.get("stale")),"s1_s2":sum(1 for r in rows if r["stage"] in {"S1","S2"} and r.get("stale")),"coverage":sum(1 for r in rows if r["stage"]=="coverage" and r.get("stale"))}
    summary={"schema":"strategy_canonical_summary_v710","owner":"strategy_worker_v710","ts":now_ts(),"version":VERSION,"build":BUILD,"counts":{"krw":len(rows),"scanner":len(rows),"strategy_input":len(rows),"canonical":len(rows),"actionable":len(actionable),"S1":cnt.get("S1",0),"S2":cnt.get("S2",0),"S3_watch":cnt.get("S3_watch",0),"coverage":cnt.get("coverage",0),"excluded":cnt.get("excluded",0),"raw":cnt.get("coverage",0)+cnt.get("excluded",0),"unknown":cnt.get("",0)},"stale":stale,"block_top":top(rows,"block_reasons"),"risk_top":top(rows,"risk_tags")}
    save_json("clean_strategy_canonical_summary.json",summary)
    save_json("clean_strategy_s_summary.json",summary)
    save_json("clean_strategy_s_reject_summary.json",{"ts":now_ts(),"block_top":summary["block_top"],"risk_top":summary["risk_top"]})
    save_json("clean_candidate_reason_state_cache.json",{"ts":now_ts(),"summary":summary,"top":actionable[:30]})
    text = "\n".join([
        "- source: strategy_worker canonical cache / schema strategy_canonical_summary_v710",
        "[후보 분리 · v710]",
        f"- 실전후보 S1 {cnt.get('S1',0)} / S2 {cnt.get('S2',0)} / S3_watch {cnt.get('S3_watch',0)} / coverage {cnt.get('coverage',0)} / 제외 {cnt.get('excluded',0)}",
        "- S1 막힘 TOP: " + " / ".join(f"{k} {v}" for k,v in summary["block_top"][:5]),
        "- 위험 TOP: " + " / ".join(f"{k} {v}" for k,v in summary["risk_top"][:5]),
        "[paper handoff · v710]",
        f"- 정식 S1 rows {len(paper)} / 실험 rows {len(exp)}",
    ])
    write_text("clean_candidate_reason_text_cache.txt", text)
    out=paper+exp
    (BASE_DIR/"paper_candidates_latest.jsonl").write_text("\n".join(json.dumps(r,ensure_ascii=False) for r in out)+("\n" if out else ""),encoding="utf-8")
    (BASE_DIR/"paper_candidates.jsonl").write_text("\n".join(json.dumps(r,ensure_ascii=False) for r in out)+("\n" if out else ""),encoding="utf-8")
    save_json("clean_fast_quality_paper_handoff_v674.json",{"ts":now_ts(),"rows":exp,"accepted":len(exp),"real_eligible":False,"BUY_READY":False})
    save_json("clean_strategy_paper_handoff_status.json",{"ts":now_ts(),"official_s1":len(paper),"experiment":len(exp)})
    save_json("clean_strategy_worker_status.json",{"ts":now_ts(),"status":"running","version":VERSION,"build":BUILD,"rows":len(rows),"actionable":len(actionable)})
def run_once():
    scanner, feature, order, risk = read_sources()
    rows=[]
    for sr in scanner:
        sym=norm_symbol(sr)
        if not sym: continue
        rows.append(canonicalize(sr, feature.get(sym,{}), order.get(sym,{}), risk.get(sym,{})))
    write_outputs(rows)
def main():
    while True:
        try: run_once()
        except Exception as exc:
            log_error("main_loop", exc)
            save_json("clean_strategy_worker_status.json",{"ts":now_ts(),"status":"error","error":repr(exc),"version":VERSION})
        time.sleep(INTERVAL_SEC)
if __name__=="__main__":
    main()
