#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""review_worker_v0.710.py · TRUE REBUILD REVIEW"""
from __future__ import annotations
import json, os, time, traceback
from pathlib import Path
from typing import Any, Dict, List

BASE_DIR=Path(os.getenv("TRADING_BOT_DIR",Path(__file__).resolve().parent))
VERSION="review_worker_v0.710"; BUILD="v710_true_clean_review_2026-06-04"
INTERVAL_SEC=float(os.getenv("REVIEW_WORKER_INTERVAL_SEC","20")); TTL_SEC=float(os.getenv("REVIEW_TRACK_TTL_SEC","7200"))
def now_ts(): return time.time()
def fnum(v,default=0.0):
    try:
        if v is None or v=="": return default
        return float(str(v).replace(",","").replace("%",""))
    except Exception: return default
def load_json(name,default=None):
    p=BASE_DIR/name
    try:
        if not p.exists(): return default
        return json.loads(p.read_text(encoding="utf-8"))
    except Exception: return default
def save_json(name,data):
    p=BASE_DIR/name; tmp=p.with_suffix(p.suffix+".tmp")
    tmp.write_text(json.dumps(data,ensure_ascii=False,indent=2),encoding="utf-8"); tmp.replace(p)
def read_jsonl(name):
    p=BASE_DIR/name
    if not p.exists(): return []
    out=[]
    for line in p.read_text(encoding="utf-8",errors="ignore").splitlines()[-1000:]:
        try:
            o=json.loads(line)
            if isinstance(o,dict): out.append(o)
        except Exception: pass
    return out
def append_jsonl(name,row):
    with (BASE_DIR/name).open("a",encoding="utf-8") as f: f.write(json.dumps(row,ensure_ascii=False)+"\n")
def log_error(where,exc):
    append_jsonl("review_worker_errorlog.jsonl",{"ts":now_ts(),"where":where,"error":repr(exc),"trace":traceback.format_exc()[-2000:]})
def sym(r):
    return str(r.get("symbol") or r.get("ticker") or r.get("market") or "").replace("KRW-","").upper()
def extract_rows(data):
    if isinstance(data,list): return [x for x in data if isinstance(x,dict)]
    if isinstance(data,dict):
        for k in ["rows","items","data","markets","tickers"]:
            if isinstance(data.get(k),list): return [x for x in data[k] if isinstance(x,dict)]
        return [v for v in data.values() if isinstance(v,dict)]
    return []
def current_price(symbol,fallback=0.0):
    for name in ["clean_orderflow_summary_cache.json","clean_feature_cache.json","clean_scanner_market_cache.json"]:
        for r in extract_rows(load_json(name,[])):
            if sym(r)==symbol:
                for k in ["current_price","price","trade_price","close","last_price"]:
                    p=fnum(r.get(k),0)
                    if p: return p
    return fallback
def run_once():
    state=load_json("clean_market_miss_state_v667.json",{"items":{}}) or {"items":{}}
    items=state.get("items") or {}
    for r in read_jsonl("paper_candidates_latest.jsonl"):
        s=sym(r)
        if not s or s in items: continue
        p=fnum(r.get("current_price") or r.get("entry_price"),0)
        items[s]={"symbol":s,"start_ts":now_ts(),"start_price":p,"grade":r.get("grade"),"stage":r.get("stage"),"strategy":r.get("strategy_name") or r.get("strategy"),"max_pct":0.0,"cur_pct":0.0}
    for s,r in list(items.items()):
        if now_ts()-fnum(r.get("start_ts"),0)>TTL_SEC:
            items.pop(s,None); continue
        start=fnum(r.get("start_price"),0); cur=current_price(s,start)
        pct=(cur/start-1)*100 if start else 0
        r["cur_pct"]=pct; r["max_pct"]=max(fnum(r.get("max_pct"),pct),pct)
    matured=[r for r in items.values() if now_ts()-fnum(r.get("start_ts"),0)>120]
    missed=[r for r in matured if fnum(r.get("max_pct"),0)>=0.75]
    summary={"tracking":len(items),"matured":len(matured),"rising":sum(1 for r in matured if fnum(r.get("max_pct"),0)>0.3),"true_missed":len(missed)}
    data={"schema":"missed_review_v710","owner":"review_worker_v710","ts":now_ts(),"summary":summary,"missed":sorted(missed,key=lambda r:fnum(r.get("max_pct"),0),reverse=True)[:30]}
    save_json("clean_market_miss_state_v667.json",{"ts":now_ts(),"items":items})
    save_json("clean_market_miss_review_v667.json",data); save_json("clean_review_summary.json",data)
    save_json("clean_review_worker_status.json",{"ts":now_ts(),"status":"running","version":VERSION,"build":BUILD,**summary})
def main():
    while True:
        try: run_once()
        except Exception as exc:
            log_error("main_loop",exc); save_json("clean_review_worker_status.json",{"ts":now_ts(),"status":"error","error":repr(exc),"version":VERSION})
        time.sleep(INTERVAL_SEC)
if __name__=="__main__": main()
