# v1104 Flow Map Accuracy

## Actual causes
1. Runtime version comparison used a parser that only accepted three numeric segments. Worker labels such as `v0.6` and `v1.013` were therefore reported as mismatches despite matching PID, alias and source hash.
2. Guard owner classification lacked canonical mappings for several active artifacts, so known Review/Candle/Target Router/WS/Strategy files appeared as UNKNOWN.
3. `information_missing_count` omitted unknown lineage edges and OPEN evidence gaps.
4. OPEN compact evidence read legacy generic names instead of the sealed Paper fields and used boolean `or`, which discarded valid zero MFE/MAE/PnL values.
5. Resource trend output omitted the sampling window and trend state.

## Changed path
- Guard runtime identity reader
- Guard artifact owner classifier
- Guard flow-map missing-evidence accounting
- Guard canonical OPEN evidence reader
- Main read-only flow-map text renderer

## Not changed
- Feature, Strategy, Orderflow, Risk and Paper execution code
- Quality thresholds
- Slippage calculation or limit
- OPEN 30 / cycle 3
- trigger, invalid, target or exit contracts
- Existing OPEN/CLOSED/decision/performance ledgers
- Automatic buying remains OFF

## Server verification
1. Run `/gupgrade_bundle` alone.
2. After upgrade, Guard: `/gops_refresh`
3. Main, in one message: `/flow_map` and `/errorlog`

Expected:
- Main `v2.13.1089`, Guard `v2.5.157`
- false `status_version` mismatch rows disappear when versions actually match
- owner UNKNOWN count decreases only for files with canonical ownership evidence
- missing-evidence total shows a breakdown
- OPEN FULL rows show decision key, opened timestamp, actual-entry RR and zero MFE/MAE correctly
- memory lines show trend state and sampling window
