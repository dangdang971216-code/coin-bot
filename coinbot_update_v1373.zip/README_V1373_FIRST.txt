Purpose: remove dead paper_s1_hold_cache from live Paper OPEN source and reconnect Paper to Strategy paper_candidates_latest S1 rows.
Also blocks Strategy boot fake OK until real candidate publish completes.
