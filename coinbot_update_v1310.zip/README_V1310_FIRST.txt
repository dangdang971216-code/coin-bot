v1310: 디스크 결과 미전송 + no-limit shadow 폭주 수리판.

수정:
- /gdisk_full 결과 함수가 main() 아래 붙어 결과가 안 오던 문제를 수리.
- /gdisk_full, /gdisk_status는 번호 없는 고정 명령어만 안내.
- 디스크 정리는 시작/단계/완료 상태를 clean_disk_full_cleanup_v1310.json에 저장하고 단계별 진행 알림을 보냄.
- v1309 no-limit shadow 523개 폭주분은 삭제하지 않고 v1310 성과판에서 제외. v1310 새 shadow path로 bounded/dedup 시작.

변경 없음:
- 후보식 / trigger / invalid / target / RR / 청산조건 / 자동매수 OFF / 기존 원장.
