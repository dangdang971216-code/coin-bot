import importlib.util
import json
import tempfile
import time
import unittest
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]


def load(name: str, filename: str):
    path = ROOT / filename
    spec = importlib.util.spec_from_file_location(name, path)
    module = importlib.util.module_from_spec(spec)
    assert spec and spec.loader
    spec.loader.exec_module(module)
    return module


class V1240ContractTest(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.main = load("main1240_test", "coinbot_main_v2_13_1150.py")
        cls.review = load("review1240_test", "review_worker_v1.028.py")
        cls.paper = load("paper1240_test", "paper_bot_v1.071.py")

    def test_01_versions_and_auto_buy(self):
        self.assertEqual(self.main.BOT_VERSION, "수익형 v2.13.1150")
        self.assertEqual(self.review.VERSION, "review_worker_v1.028")
        self.assertEqual(self.paper.VERSION, "paper_bot_v1.071")
        self.assertFalse(getattr(self.review, "AUTO_BUY", True))

    def test_02_kst_summary_clock(self):
        self.assertEqual(self.main._kst_text(0), "1970-01-01 09:00:00")
        self.assertEqual(self.main._kst_stamp(0), "19700101_090000")

    def test_03_paper_recent_12h_window(self):
        now = time.time()
        rows = [
            {"closed_at": now - 11 * 3600, "pnl_pct": 1.0},
            {"closed_at": now - 13 * 3600, "pnl_pct": -1.0},
        ]
        _windows, counts = self.paper._v1045_perf_windows(rows, now)
        self.assertEqual(counts["recent_12h"], 1)

    def test_04_paper_writes_closed_open_combined_once(self):
        now = time.time()
        self.paper._v1045_epoch = lambda: {
            "state": "ACTIVE", "epoch_id": "epoch-test", "started_at": now - 1000, "started_text": "x"
        }
        self.paper._v1045_manifest = lambda: {}
        active_open = {
            "p1": {
                "pos_id": "p1", "performance_epoch_id": "epoch-test",
                "last_pnl_pct": -2.0, "ticker": "AAA",
            }
        }
        closed = {
            "decision_key": "d1", "closed_at": now - 100, "pnl_pct": 1.0,
            "performance_epoch_id": "epoch-test", "performance_epoch_role": "post_reset_strategy_close",
        }
        source = {"rows": [closed], "windows": {}, "window_counts": {}, "counts": {}, "invariants": {}}
        out = self.paper._v1045_apply_performance_epoch_contract(source, now, active_open)
        book = out["book_performance_v1189"]
        self.assertEqual(book["fresh_open"]["count"], 1)
        self.assertEqual(book["fresh_closed_plus_open"]["count"], 2)
        self.assertAlmostEqual(book["fresh_closed_plus_open"]["sum_pct"], -1.0)
        self.assertTrue(book["consistency_repair_v1240"])

    def test_05_main_reads_same_book_for_detailed_output(self):
        snap = self._snapshot()
        self.main._performance_snapshot = lambda: snap
        self.main._version_score_review_snapshot = lambda: {}
        self.main.file_age = lambda _path: 1.0
        full = self.main.render_version_score()
        self.assertIn("현재 OPEN: n1", full)
        self.assertIn("CLOSED+OPEN 단순합: n3", full)
        self.assertNotIn("현재 OPEN: 정보없음", full)

    def test_06_current_structure_and_all_contract_labels_are_distinct(self):
        snap = self._snapshot()
        self.main._performance_snapshot = lambda: snap
        self.main._version_score_review_snapshot = lambda: {}
        self.main.file_age = lambda _path: 1.0
        full = self.main.render_version_score()
        self.assertIn("1️⃣ 현재 구조선 실제 거래", full)
        self.assertIn("[모든 실제 거래 · 이전/현재/미분류 계약 포함]", full)
        self.assertIn("범위가 달라 건수가 다를 수 있음", full)

    def test_07_review_uses_canonical_s1_stage(self):
        base = Path(tempfile.mkdtemp())
        (base / "canonical_performance_snapshot_v987.json").write_text(json.dumps({"rows": []}), encoding="utf-8")
        rows = [
            {"ticker": "AAA", "swing_entry_gate_v977": {"stage": "S1"}, "hybrid_entry_shadow_pass_v1234": True},
            {"ticker": "BBB", "s_stage": "S1", "hybrid_entry_shadow_pass_v1234": False},
            {"ticker": "CCC", "candidate_stage": "S2", "hybrid_entry_shadow_pass_v1234": True},
        ]
        out = self.review._v1234_hybrid_replay(base, rows, time.time())
        current = out["current_generation"]
        self.assertEqual(current["current_s1"], 2)
        self.assertEqual(current["current_s1_hybrid_block"], 1)

    def test_08_summary_filename_and_body_share_kst(self):
        self.main._ops_snapshot = lambda: {}
        self.main.render_flow_map_compact = lambda: "flow"
        self.main.render_candidate_compact = lambda: "candidate"
        self.main.render_version_score_compact = lambda: "score"
        text = self.main.build_summary_text(
            [("version_score", [])], {"version_score": "ok"},
            [{"name": "version_score", "sec": 0.01, "ok": True}], 0.02,
        )
        self.assertIn("KST", text.splitlines()[2])
        self.assertRegex(self.main._kst_stamp(), r"^\d{8}_\d{6}$")

    @staticmethod
    def _snapshot():
        return {
            "snapshot_id": "perf-test", "generated_at_text": "2026-07-05 12:44:51 KST", "source_owner": "paper",
            "windows": {
                "today": {"count": 3, "wins": 1, "losses": 2, "sum_pct": -1.0, "avg_pct": -0.333},
                "yesterday": {"count": 1, "wins": 1, "losses": 0, "sum_pct": 1.0, "avg_pct": 1.0},
                "all": {"count": 4, "wins": 2, "losses": 2, "sum_pct": 0.0, "avg_pct": 0.0},
            },
            "contract_performance_v1213": {"contracts": {
                "structure_contract_v1212_dynamic_zones": {"windows": {
                    "recent_3h": {"count": 1, "wins": 1, "losses": 0, "sum_pct": 1.0, "avg_pct": 1.0},
                    "recent_6h": {"count": 2, "wins": 1, "losses": 1, "sum_pct": 0.0, "avg_pct": 0.0},
                    "recent_12h": {"count": 2, "wins": 1, "losses": 1, "sum_pct": 0.0, "avg_pct": 0.0},
                    "recent_24h": {"count": 3, "wins": 1, "losses": 2, "sum_pct": -1.0, "avg_pct": -0.333},
                    "today": {"count": 3, "wins": 1, "losses": 2, "sum_pct": -1.0, "avg_pct": -0.333},
                    "all": {"count": 3, "wins": 1, "losses": 2, "sum_pct": -1.0, "avg_pct": -0.333},
                }},
                "structure_contract_v1211_legacy": {"windows": {"all": {}}},
            }},
            "performance_epoch_v1045": {
                "stats": {"count": 2, "wins": 1, "losses": 1, "sum_pct": 1.0, "avg_pct": 0.5},
                "current_open_count": 1,
            },
            "book_performance_v1189": {
                "open_count": 1, "valid_pnl_rows": 1, "missing_pnl_rows": 0,
                "current_total": -2.0, "current_avg": -2.0,
                "wins": 0, "losses": 1, "flats": 0,
                "positive_total": 0.0, "negative_total": -2.0,
                "fresh_closed": {"count": 2, "wins": 1, "losses": 1, "sum_pct": 1.0, "avg_pct": 0.5},
                "fresh_open": {"count": 1, "wins": 0, "losses": 1, "sum_pct": -2.0, "avg_pct": -2.0},
                "fresh_closed_plus_open": {"count": 3, "wins": 1, "losses": 2, "sum_pct": -1.0, "avg_pct": -0.333333},
            },
        }


if __name__ == "__main__":
    unittest.main(verbosity=2)
