v1621 SLIPPAGE_STALE boundary immediate refresh retry
- 35~60초 stale slippage는 바로 폐기하지 않고 실행자료를 즉시 재확인 후 final safety 1회 재검사
- 60초 초과, 위험 slippage/spread, trigger/RR/target 문제는 기존처럼 차단
- 기준/Gate/RR/trigger/invalid/target/청산/OPEN 제한/자동매수 OFF 변경 없음
