v1331 SCORE SHADOW 3H6H READONLY

목적:
- /score_reason_audit 강화
- 현재 실제 Paper 3시간·6시간 승률과 shadow 보정점수 상위/하위 50%를 같이 비교
- 보정점수가 invalid 손실군을 낮추고 trailing 수익군을 유지하는지 확인
- 현재 S1에 shadow 점수와 약점 표시 추가

변경 없음:
- 후보식, trigger, invalid, target, RR, 청산계약, Paper 실행, 자동매수
- 라이브 OPEN/CLOSED/decision 원장 포함 없음

적용 후:
- guard: /grelease_verify
- main: /score_reason_audit
