코인봇 v1324 · Strategy exact key writer 수리

목적:
- v1323 적용 후 Strategy가 trigger_occurrence_candidate_key_changed 오류로 ERROR_BEFORE_WRITE 난 문제 수리.
- compact writer가 Paper 연결용 exact key를 축약/변형하지 않게 보존.
- 선택/OPEN/청산/trigger/invalid/target/RR 변경 없음.
- 자동매수 OFF.

검수:
1) /gupgrade_bundle
2) /grelease_verify
3) 메인봇 /flow_map_full /version_score /candidate_standard

확인 기준:
- Strategy writer result OK
- candidate_commit_id 새로 생성
- trigger_occurrence_candidate_key_changed 오류 없음
- 후보 전체가 정상 universe 수준으로 회복되는지 확인
- S1 감시풀과 Paper OPEN은 분리 유지
