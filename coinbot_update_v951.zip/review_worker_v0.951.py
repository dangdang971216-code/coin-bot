#!/usr/bin/env python3
# -*- coding: utf-8 -*-
from __future__ import annotations
import json, os, time, traceback, gzip
from pathlib import Path
from typing import Any, Dict, List, Optional
from collections import Counter

BASE_DIR = Path(os.getenv("TRADING_BOT_DIR", "/home/dangdang971216/trading_bot"))
VERSION = "review_worker_v0.951"
INTERVAL_SEC = float(os.getenv("REVIEW_WORKER_INTERVAL_SEC", "30"))
RETENTION_DAYS = float(os.getenv("REVIEW_RETENTION_DAYS", "0.25"))
ACTIVE_REVIEW_MAX = int(os.getenv("REVIEW_ACTIVE_MAX", "180"))
TRIGGER_SHADOW_PENDING_TTL_SEC = float(os.getenv("TRIGGER_SHADOW_PENDING_TTL_SEC", "900"))
TRIGGER_SHADOW_ENTERED_TTL_SEC = float(os.getenv("TRIGGER_SHADOW_ENTERED_TTL_SEC", "3600"))
TRIGGER_SHADOW_ACTIVE_MAX = int(os.getenv("TRIGGER_SHADOW_ACTIVE_MAX", "900"))
SOURCE_SNAPSHOT_LINES = int(os.getenv("REVIEW_SOURCE_SNAPSHOT_LINES", "260"))

STATUS = BASE_DIR / "clean_review_worker_status.json"
ERROR = BASE_DIR / "clean_review_worker_error.log"
CLOSED = BASE_DIR / "paper_bot_closed.jsonl"
OPEN = BASE_DIR / "paper_bot_open.json"
PAPER_LATEST = BASE_DIR / "paper_candidates_latest.jsonl"
GOOD_S2_OBSERVATION_LEDGER = BASE_DIR / "good_s2_observation_ledger.jsonl"
GOOD_S2_RESULT_STATE = BASE_DIR / "good_s2_result_state_v923.json"
GOOD_S2_RESULT_SNAPSHOT = BASE_DIR / "good_s2_result_snapshot.json"
GOOD_S2_RESULT_LEDGER = BASE_DIR / "good_s2_result_ledger.jsonl"
GOOD_S2_RESULT_HORIZON_SEC = 6 * 3600.0
GOOD_S2_RESULT_RETENTION_SEC = 7 * 86400.0
GOOD_S2_RESULT_RESET_META_V925 = BASE_DIR / 'quarantine' / 'good_s2_result_state_reset_meta_v925.json'
GOOD_S2_RESULT_RESET_META_V926 = BASE_DIR / 'quarantine' / 'good_s2_result_source_spine_reset_meta_v926.json'
FEATURE = BASE_DIR / "clean_feature_cache.json"
ORDERFLOW = BASE_DIR / "clean_orderflow_summary_cache.json"
REGIME = BASE_DIR / "clean_market_regime_cache.json"
QUEUE = BASE_DIR / "clean_missed_review_queue.json"
STATE = BASE_DIR / "clean_missed_review_state.json"
SUMMARY = BASE_DIR / "clean_missed_review_summary.json"
OLD_SUMMARY = BASE_DIR / "clean_review_summary.json"
TRIGGER_SHADOW_CANDIDATES = BASE_DIR / "clean_trigger_shadow_candidates_v665.json"
TRIGGER_SHADOW_STATE = BASE_DIR / "clean_trigger_shadow_state_v665.json"
TRIGGER_SHADOW_SUMMARY = BASE_DIR / "clean_trigger_shadow_review_v665.json"
MARKET_MISS_CANDIDATES = BASE_DIR / "clean_market_miss_candidates_v667.json"
MARKET_MISS_STATE = BASE_DIR / "clean_market_miss_state_v667.json"
MARKET_MISS_SUMMARY = BASE_DIR / "clean_market_miss_review_v667.json"
QUALITY_SHADOW_STATE = BASE_DIR / "clean_quality_shadow_state_v946.json"
QUALITY_SHADOW_STATUS = BASE_DIR / "clean_quality_shadow_status_v946.json"
QUALITY_SHADOW_LEDGER = BASE_DIR / "quality_shadow_result_ledger_v946.jsonl"
QUALITY_SHADOW_RETENTION_SEC = float(os.getenv("QUALITY_SHADOW_RETENTION_SEC", str(3 * 3600)))
QUALITY_SHADOW_FINAL_GRACE_SEC = float(os.getenv("QUALITY_SHADOW_FINAL_GRACE_SEC", "300"))
# Safety ceiling only. Unfinished records are retained by time until the 60m horizon,
# so a busy market cannot evict them merely because a count cap was reached.
QUALITY_SHADOW_SAFETY_MAX_RECORDS = int(os.getenv("QUALITY_SHADOW_SAFETY_MAX_RECORDS", "20000"))
QUALITY_SHADOW_ARCHIVE = BASE_DIR / "quality_shadow_archive"
QUALITY_SHADOW_LEDGER_MAX_BYTES = int(os.getenv("QUALITY_SHADOW_LEDGER_MAX_BYTES", str(50 * 1024 * 1024)))
QUALITY_SHADOW_LEDGER_KEEP_LINES = int(os.getenv("QUALITY_SHADOW_LEDGER_KEEP_LINES", "5000"))
_QUALITY_FINAL_KEYS_CACHE: Optional[set[str]] = None
QUALITY_SHADOW_HORIZONS = (("1m",60.0),("3m",180.0),("5m",300.0),("10m",600.0),("20m",1200.0),("60m",3600.0))
LATE_PATH_STATUS = BASE_DIR / "clean_late_path_status_v947.json"
PAPER_DECISION_STATE = BASE_DIR / "paper_decision_state_v926.json"
SAMPLE_BOARD_STATUS = BASE_DIR / 'clean_sample_board_status_v948.json'
SMART_STRUCTURE_CANDIDATES = BASE_DIR / 'clean_smart_structure_shadow_candidates_v948.json'
SMART_STRUCTURE_STATE = BASE_DIR / 'clean_smart_structure_shadow_state_v948.json'
SMART_STRUCTURE_STATUS = BASE_DIR / 'clean_smart_structure_shadow_review_status_v948.json'
SMART_STRUCTURE_HORIZONS = (('1m',60.0),('3m',180.0),('5m',300.0),('10m',600.0),('20m',1200.0),('60m',3600.0))
STRUCTURE_LAB_CANDIDATES = BASE_DIR / 'clean_structure_lab_candidates_v951.json'
STRUCTURE_LAB_STATE = BASE_DIR / 'clean_structure_lab_state_v951.json'
STRUCTURE_LAB_REVIEW_STATUS = BASE_DIR / 'clean_structure_lab_review_status_v951.json'
STRUCTURE_MISSED_STATE = BASE_DIR / 'clean_structure_missed_state_v951.json'
STRUCTURE_MISSED_STATUS = BASE_DIR / 'clean_structure_missed_status_v951.json'
STRUCTURE_LAB_HORIZONS = (('1m',60.0),('3m',180.0),('5m',300.0),('10m',600.0),('20m',1200.0),('60m',3600.0),('120m',7200.0),('240m',14400.0))
STRUCTURE_LAB_RETENTION_SEC = 5 * 3600.0

def now_ts() -> float: return time.time()
def now_text(ts: Optional[float]=None) -> str: return time.strftime("%Y-%m-%d %H:%M:%S", time.localtime(ts or now_ts()))
def fnum(*vals: Any, default: float=0.0) -> float:
    for v in vals:
        try:
            if v is None or v == "": continue
            return float(str(v).replace(",", "").replace("%", ""))
        except Exception: continue
    return default

def load_json(path: Path, default: Any=None) -> Any:
    try:
        if not path.exists(): return default
        return json.loads(path.read_text(encoding="utf-8", errors="ignore"))
    except Exception: return default

def save_json(path: Path, obj: Any) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    tmp = path.with_suffix(path.suffix + ".tmp")
    tmp.write_text(json.dumps(obj, ensure_ascii=False, separators=(",", ":"), default=str), encoding="utf-8")
    os.replace(tmp, path)

_JSONL_CYCLE_CACHE: Dict[tuple, List[Dict[str, Any]]] = {}

def _tail_text_lines(path: Path, max_lines: int) -> List[str]:
    if max_lines <= 0:
        return path.read_text(encoding="utf-8", errors="ignore").splitlines()
    chunks: List[bytes] = []
    newline_count = 0
    with path.open("rb") as f:
        f.seek(0, os.SEEK_END)
        pos = f.tell()
        while pos > 0 and newline_count <= max_lines:
            size = min(65536, pos)
            pos -= size
            f.seek(pos)
            block = f.read(size)
            chunks.append(block)
            newline_count += block.count(b"\n")
    data = b"".join(reversed(chunks)).decode("utf-8", errors="ignore")
    return data.splitlines()[-max_lines:]

def read_jsonl(path: Path, max_lines: int=1000) -> List[Dict[str, Any]]:
    if not path.exists():
        return []
    try:
        stat = path.stat()
        key = (str(path), int(max_lines), int(stat.st_mtime_ns), int(stat.st_size))
        cached = _JSONL_CYCLE_CACHE.get(key)
        if cached is not None:
            return cached
        lines = _tail_text_lines(path, int(max_lines))
        out: List[Dict[str, Any]] = []
        for ln in lines:
            try:
                if ln.strip():
                    obj = json.loads(ln)
                    if isinstance(obj, dict):
                        out.append(obj)
            except Exception:
                continue
        _JSONL_CYCLE_CACHE[key] = out
        return out
    except Exception as exc:
        append_error(ERROR, "read_jsonl_v929", exc)
        return []

def append_error(path: Path, where: str, exc: BaseException) -> None:
    try:
        path.parent.mkdir(parents=True, exist_ok=True)
        with path.open("a", encoding="utf-8") as f:
            f.write(f"[{now_text()}] {where}: {exc.__class__.__name__}: {exc}\n")
            f.write(traceback.format_exc()[-1500:] + "\n")
    except Exception: pass

def ticker_norm(x: Any) -> str:
    t = str(x or "").strip().upper().replace("/", "-").replace("_", "-")
    parts = [p for p in t.split("-") if p]
    if len(parts) >= 2:
        non = [p for p in parts if p != "KRW"]
        t = non[-1] if non else parts[-1]
    if t.endswith("KRW") and len(t) > 3: t = t[:-3]
    return t.strip().upper()

def map_rows(obj: Any) -> Dict[str, Dict[str, Any]]:
    if isinstance(obj, dict) and isinstance(obj.get("rows"), list): obj = obj.get("rows")
    elif isinstance(obj, dict) and isinstance(obj.get("rows"), dict): obj = obj.get("rows")
    elif isinstance(obj, dict) and isinstance(obj.get("cache"), dict): obj = obj.get("cache")
    out: Dict[str, Dict[str, Any]] = {}
    if isinstance(obj, list):
        for r in obj:
            if isinstance(r, dict):
                t = ticker_norm(r.get("ticker") or r.get("symbol") or r.get("market"))
                if t: out[t] = r
    elif isinstance(obj, dict):
        for k, v in obj.items():
            t = ticker_norm(k)
            if t and isinstance(v, dict):
                vv = dict(v); vv.setdefault("ticker", t); out[t] = vv
    return out

def write_status(state: str, **extra: Any) -> None:
    save_json(STATUS, {"version": VERSION, "state": state, "pid": os.getpid(), "updated_ts": now_ts(), "updated_text": now_text(), **extra})

def profit(row: Dict[str, Any]) -> float:
    return fnum(row.get("profit_pct"), row.get("return_pct"), row.get("pnl_pct"), row.get("profit_rate"), default=0.0)

def _current_price(ticker: str, fmap: Dict[str, Dict[str, Any]], ofmap: Dict[str, Dict[str, Any]]) -> float:
    f = fmap.get(ticker, {}) or {}
    o = ofmap.get(ticker, {}) or {}
    return fnum(o.get("quote_price"), o.get("current_price"), o.get("price"), f.get("current_price"), f.get("price"), f.get("last_price"), f.get("close"), default=0.0)

def _pct(cur: float, base: float) -> float:
    return round((cur - base) / base * 100.0, 3) if cur and base else 0.0

def _risk_profile(rec: Dict[str, Any]) -> Dict[str, Any]:
    """결과만 오른 위험 후보와 진짜 놓친 후보를 분리하기 위한 표시용 판정.
    조건/S1/S2/S3 기준은 바꾸지 않고 review 분류만 정리한다.
    """
    m = rec.get("metrics") if isinstance(rec.get("metrics"), dict) else {}
    spread = fnum(m.get("spread_pct"), default=0.0)
    slip = fnum(m.get("slippage_pct"), default=0.0)
    buy = fnum(m.get("buy_ratio"), default=0.0)
    sustain = fnum(m.get("buy_sustain_1m"), default=0.0)
    cur_pct = fnum(rec.get("current_pct"), default=0.0)
    reasons = " / ".join(str(x) for x in (rec.get("block_reasons") or []) if str(x).strip())
    risk: List[str] = []
    mild: List[str] = []
    if spread >= 0.30: risk.append(f"스프레드 {spread:.2f}%")
    elif spread >= 0.20: mild.append(f"스프레드 {spread:.2f}%")
    if slip >= 0.30: risk.append(f"미끄러짐 {slip:.2f}%")
    elif slip >= 0.20: mild.append(f"미끄러짐 {slip:.2f}%")
    if buy and buy < 0.55: risk.append(f"매수체결 {buy:.2f}")
    elif buy and buy < 0.68: mild.append(f"매수체결 {buy:.2f}")
    if sustain and sustain < 0.55: risk.append(f"1분지속 {sustain:.2f}")
    elif sustain and sustain < 0.64: mild.append(f"1분지속 {sustain:.2f}")
    for word in ("매도벽", "매도압력", "EMA5 아래", "추세 부담"):
        if word in reasons:
            risk.append(word)
    if cur_pct <= -1.00:
        risk.append(f"현재 되돌림 {cur_pct:+.2f}%")
    return {"risk": risk, "mild": mild, "is_high_risk": bool(risk), "risk_note": " / ".join(risk[:4]) if risk else (" / ".join(mild[:4]) if mild else "위험 낮음")}

def _sample_pct(rec: Dict[str, Any], label: str) -> Optional[float]:
    # label: 5m/10m/20m. direct value가 없으면 samples[label].pct를 본다.
    key = f"after_{label}_pct"
    v = rec.get(key)
    if v not in (None, ""):
        return fnum(v, default=0.0)
    samples = rec.get("samples") if isinstance(rec.get("samples"), dict) else {}
    sample = samples.get(label) if isinstance(samples.get(label), dict) else {}
    if sample.get("pct") not in (None, ""):
        return fnum(sample.get("pct"), default=0.0)
    return None

def _timing_profile(rec: Dict[str, Any]) -> Dict[str, Any]:
    """v457: 최고수익 착시를 분리한다.
    S1 완화/승격 근거는 5/10/20분 안에 오른 후보만 쓰기 위함이다.
    """
    a5 = _sample_pct(rec, "5m")
    a10 = _sample_pct(rec, "10m")
    a20 = _sample_pct(rec, "20m")
    vals = {"5m": a5, "10m": a10, "20m": a20}
    # 초반에 명확히 간 후보만 진짜놓침 근거로 둔다.
    early_hit = (a5 is not None and a5 >= 0.30) or (a10 is not None and a10 >= 0.50) or (a20 is not None and a20 >= 0.70)
    mild_hit = (a5 is not None and a5 >= 0.10) or (a10 is not None and a10 >= 0.20) or (a20 is not None and a20 >= 0.30)
    sample_ready = any(v is not None for v in vals.values())
    note = " / ".join(f"{k} {v:+.2f}%" for k, v in vals.items() if v is not None) or "시간표 부족"
    return {"early_hit": early_hit, "mild_hit": mild_hit, "sample_ready": sample_ready, "note": note, "samples": vals}

def _decision(rec: Dict[str, Any], elapsed: float) -> str:
    max_pct = fnum(rec.get("max_pct"), default=0.0)
    cur_pct = fnum(rec.get("current_pct"), default=0.0)
    rp = _risk_profile(rec)
    tp = _timing_profile(rec)
    rec["risk_reasons"] = rp.get("risk", [])
    rec["risk_note"] = rp.get("risk_note", "")
    rec["timing_note"] = tp.get("note", "")
    rec["timing_samples"] = tp.get("samples", {})
    if max_pct >= 1.20:
        if rp.get("is_high_risk"):
            rec["timing_class"] = "위험상승"
            return "🔥 결과만 오른 위험 후보"
        if tp.get("early_hit"):
            rec["timing_class"] = "초반상승"
            return "❌ 진짜 놓친 후보"
        # 최고수익만 큰 후보는 S1 완화 근거로 쓰지 않는다.
        rec["timing_class"] = "늦게오름"
        return "⏳ 늦게 오른 후보"
    if max_pct >= 0.70:
        if rp.get("is_high_risk"):
            rec["timing_class"] = "위험상승"
            return "🔥 결과만 오른 위험 후보"
        if tp.get("mild_hit"):
            rec["timing_class"] = "아까움"
            return "⚠️ 아까운 후보"
        rec["timing_class"] = "늦게오름"
        return "⏳ 늦게 오른 후보"
    if elapsed >= 1200 and max_pct < 0.30:
        rec["timing_class"] = "초반무반응"
        return "✅ 안 산 게 맞음"
    if elapsed >= 300 and cur_pct <= -0.30 and max_pct < 0.50:
        rec["timing_class"] = "빠른약세"
        return "✅ 안 산 게 맞음"
    rec["timing_class"] = "추적중"
    return "❔ 추적중"

def _short_reasons(rec: Dict[str, Any]) -> str:
    reasons = rec.get("block_reasons") if isinstance(rec.get("block_reasons"), list) else []
    missing = rec.get("missing_info") if isinstance(rec.get("missing_info"), list) else []
    arr = [str(x) for x in (reasons + missing) if str(x).strip()]
    return " / ".join(arr[:3]) if arr else "-"


def _has_structure(rec: Dict[str, Any]) -> bool:
    if not isinstance(rec, dict):
        return False
    tags = rec.get("structure_tags")
    risk = rec.get("structure_risk_tags")
    fit = rec.get("structure_fit")
    return (isinstance(tags, list) and bool(tags)) or (isinstance(risk, list) and bool(risk)) or bool(str(fit or "").strip())

def _copy_structure(dst: Dict[str, Any], src: Dict[str, Any]) -> bool:
    if not isinstance(dst, dict) or not isinstance(src, dict) or not _has_structure(src):
        return False
    st = src.get("chart_structure") if isinstance(src.get("chart_structure"), dict) else {}
    dst["structure_tags"] = src.get("structure_tags") if isinstance(src.get("structure_tags"), list) else st.get("tags", [])
    dst["structure_good_tags"] = src.get("structure_good_tags") if isinstance(src.get("structure_good_tags"), list) else st.get("good_tags", [])
    dst["structure_risk_tags"] = src.get("structure_risk_tags") if isinstance(src.get("structure_risk_tags"), list) else st.get("risk_tags", [])
    dst["structure_fit"] = str(src.get("structure_fit") or st.get("strategy_fit") or "")
    dst["structure_summary"] = str(src.get("structure_summary") or st.get("summary") or "")
    dst["chart_structure"] = st
    dst["structure_source"] = "candidate_snapshot"
    return True


def _has_market(rec: Dict[str, Any]) -> bool:
    return isinstance(rec, dict) and (isinstance(rec.get("market_regime_tags"), list) and bool(rec.get("market_regime_tags")) or bool(str(rec.get("market_regime_summary") or "").strip()))

def _copy_market(dst: Dict[str, Any], src: Dict[str, Any]) -> bool:
    if not isinstance(dst, dict) or not isinstance(src, dict) or not _has_market(src):
        return False
    mr = src.get("market_regime") if isinstance(src.get("market_regime"), dict) else {}
    dst["market_regime_tags"] = src.get("market_regime_tags") if isinstance(src.get("market_regime_tags"), list) else mr.get("tags", [])
    dst["market_risk_tags"] = src.get("market_risk_tags") if isinstance(src.get("market_risk_tags"), list) else mr.get("risk_tags", [])
    dst["market_regime_summary"] = str(src.get("market_regime_summary") or mr.get("summary") or "")
    dst["market_regime"] = mr
    dst["market_source"] = "candidate_snapshot"
    return True

def _derive_market_from_rec(rec: Dict[str, Any], fmap: Dict[str, Dict[str, Any]], ofmap: Dict[str, Dict[str, Any]], regime: Dict[str, Any]) -> Dict[str, Any]:
    t = ticker_norm(rec.get("ticker"))
    row = fmap.get(t, {}) if t else {}
    of = ofmap.get(t, {}) if t else {}
    tags: List[str] = []
    risks: List[str] = []
    mode = str((regime or {}).get("market_mode") or (regime or {}).get("mode") or row.get("market_mode") or of.get("market_mode") or "")
    def add(arr: List[str], x: str) -> None:
        if x and x not in arr:
            arr.append(x)
    if "강" in mode:
        add(tags, "시장강함")
    elif "약" in mode:
        add(tags, "시장약함")
    elif mode:
        add(tags, "시장보통")
    else:
        add(tags, "장세정보부족")
    pressure = str((regime or {}).get("market_pressure") or row.get("market_pressure") or of.get("market_pressure") or "")
    if "급락" in mode or "급락" in pressure:
        add(risks, "시장급락위험")
    if "과열" in mode or "과열" in pressure:
        add(risks, "시장과열")
    if "횡보" in mode or "횡보" in pressure:
        add(tags, "시장횡보")
    return {"schema":"market_regime_tags_v447_review_only", "tags":tags[:8], "risk_tags":risks[:6], "summary":(", ".join(tags[:3]) if tags else "-") + (" / 위험 " + ", ".join(risks[:2]) if risks else "")}

def _ensure_market(rec: Dict[str, Any], sources: Dict[str, Dict[str, Any]], fmap: Dict[str, Dict[str, Any]], ofmap: Dict[str, Dict[str, Any]], regime: Dict[str, Any]) -> None:
    if not isinstance(rec, dict) or _has_market(rec):
        return
    t = ticker_norm(rec.get("ticker"))
    if t and _copy_market(rec, sources.get(t, {}) or {}):
        return
    mt = _derive_market_from_rec(rec, fmap, ofmap, regime)
    rec["market_regime"] = mt
    rec["market_regime_tags"] = mt.get("tags", [])
    rec["market_risk_tags"] = mt.get("risk_tags", [])
    rec["market_regime_summary"] = mt.get("summary", "")
    rec["market_source"] = "review_derived_display"

def _unique(items: List[str]) -> List[str]:
    out: List[str] = []
    for x in items:
        t = str(x or "").strip()
        if t and t not in out:
            out.append(t)
    return out

def _derive_structure_from_rec(rec: Dict[str, Any]) -> Dict[str, Any]:
    """기존 active review state처럼 구조태그가 없던 기록에 붙이는 표시용 보강.
    후보 차단·S1 승격·청산에는 쓰지 않는다.
    """
    text = " / ".join(str(x) for x in (rec.get("block_reasons") or []) if str(x).strip())
    strat = str(rec.get("strategy") or rec.get("strategy_key") or "")
    m = rec.get("metrics") if isinstance(rec.get("metrics"), dict) else {}
    spread = fnum(m.get("spread_pct"), default=0.0)
    slip = fnum(m.get("slippage_pct"), default=0.0)
    buy = fnum(m.get("buy_ratio"), default=0.0)
    cur = fnum(rec.get("current_pct"), default=0.0)
    maxp = fnum(rec.get("max_pct"), default=0.0)
    tags: List[str] = []
    risks: List[str] = []

    if "돈흐름" in strat or "reaccel" in strat:
        tags += ["눌림후재가속", "돈흐름재유입"]
        if "VWAP" not in text and "EMA" not in text:
            tags.append("VWAP방어")
    if "돌파" in strat or "breakout" in strat:
        tags += ["저항돌파", "저항돌파후재테스트"]
        if "돌파 후" in text or "돌파선" in text:
            tags.append("지지전환확인")
    if "저점" in strat or "VWAP 회복" in strat or "sweep" in strat:
        tags += ["저점유동성쓸림", "쓸림후빠른회복", "VWAP재회복"]
    if "주도흐름" in strat or "유동보유" in strat or "adaptive_hold" in strat:
        tags += ["얕은눌림", "VWAP방어", "EMA방어", "상대강도유지"]
    if "주도추세" in strat or "momentum" in strat:
        tags += ["고점저점상승", "추세지속", "채널하단방어"]
    if "급등" in strat or "재돌파" in strat or "rebreak" in strat:
        tags += ["급등후눌림", "고점재돌파", "돈흐름재유입"]

    if "고점권" in text and "가격반응" in text:
        risks.append("고점권가격반응약함")
    if "스프레드" in text or spread >= 0.30:
        risks.append("스프레드부담")
    if "미끄" in text or slip >= 0.30:
        risks.append("미끄러짐부담")
    if "매도벽" in text or "매도압력" in text:
        risks.append("매도압력부담")
    if "돌파 후" in text and "부족" in text:
        risks.append("가짜돌파위험")
    if cur <= -1.0 or (maxp >= 1.2 and cur < 0):
        risks.append("되돌림위험")
    if buy and buy < 0.55:
        risks.append("매수체결약함")

    if not tags:
        tags = ["구조정보부족"]
    tags = _unique(tags)[:10]
    risks = _unique(risks)[:8]
    fit = "구조좋음" if tags and tags != ["구조정보부족"] else "구조정보부족"
    severe = any(x in risks for x in ["스프레드부담", "미끄러짐부담", "매도압력부담", "되돌림위험", "매수체결약함", "가짜돌파위험"])
    if risks and fit == "구조좋음":
        fit = "구조좋음 · 위험동반" if severe else "구조관찰"
    elif risks:
        fit = "구조위험"
    return {
        "schema": "review_structure_derived_display_v447",
        "tags": tags,
        "good_tags": [t for t in tags if t != "구조정보부족"],
        "risk_tags": risks,
        "strategy_fit": fit,
        "summary": f"{fit} · 좋음 {', '.join(tags[:3]) if tags else '-'} / 위험 {', '.join(risks[:3]) if risks else '-'}",
    }

def _ensure_structure(rec: Dict[str, Any], sources: Dict[str, Dict[str, Any]]) -> None:
    if not isinstance(rec, dict) or _has_structure(rec):
        return
    t = ticker_norm(rec.get("ticker"))
    if t and _copy_structure(rec, sources.get(t, {}) or {}):
        return
    st = _derive_structure_from_rec(rec)
    rec["chart_structure"] = st
    rec["structure_tags"] = st.get("tags", [])
    rec["structure_good_tags"] = st.get("good_tags", [])
    rec["structure_risk_tags"] = st.get("risk_tags", [])
    rec["structure_fit"] = st.get("strategy_fit", "")
    rec["structure_summary"] = st.get("summary", "")
    rec["structure_source"] = "review_derived_display"

def _summ_rows(rows: List[Dict[str, Any]], limit: int = 8) -> List[Dict[str, Any]]:
    rows = sorted(rows, key=lambda r: (fnum(r.get("max_pct"), default=0.0), fnum(r.get("score"), default=0.0)), reverse=True)
    out = []
    for r in rows[:limit]:
        out.append({
            "ticker": r.get("ticker"), "stage": r.get("stage"), "strategy": r.get("strategy"),
            "score": r.get("score"), "decision": r.get("decision"),
            "first_price": r.get("first_price"), "current_price": r.get("current_price"),
            "current_pct": r.get("current_pct"), "max_pct": r.get("max_pct"),
            "after_5m_pct": r.get("after_5m_pct"), "after_10m_pct": r.get("after_10m_pct"), "after_20m_pct": r.get("after_20m_pct"),
            "first_seen_ts": r.get("first_seen_ts"), "first_seen_text": r.get("first_seen_text"),
            "last_seen_ts": r.get("last_seen_ts"), "last_seen_text": r.get("last_seen_text"),
            "max_seen_ts": r.get("max_seen_ts"), "max_seen_text": r.get("max_seen_text"),
            "reasons": _short_reasons(r),
            "risk_note": r.get("risk_note", ""),
            "risk_reasons": r.get("risk_reasons", []),
            "structure_tags": r.get("structure_tags", []),
            "structure_good_tags": r.get("structure_good_tags", []),
            "structure_risk_tags": r.get("structure_risk_tags", []),
            "structure_fit": r.get("structure_fit", ""),
            "structure_summary": r.get("structure_summary", ""),
            "chart_structure": r.get("chart_structure", {}),
            "market_regime_tags": r.get("market_regime_tags", []),
            "market_risk_tags": r.get("market_risk_tags", []),
            "market_regime_summary": r.get("market_regime_summary", ""),
            "market_regime": r.get("market_regime", {}),
            "review_class": r.get("decision", ""),
            "timing_class": r.get("timing_class", ""),
            "timing_note": r.get("timing_note", ""),
            "timing_samples": r.get("timing_samples", {}),
        })
    return out

def _reason_top(rows: List[Dict[str, Any]], limit: int = 8) -> List[Dict[str, Any]]:
    cnt: Dict[str, int] = {}
    for r in rows:
        for x in (r.get("block_reasons") or []):
            key = str(x).split()[0].strip() or str(x).strip()
            if key: cnt[key] = cnt.get(key, 0) + 1
    return [{"reason": k, "count": v} for k, v in sorted(cnt.items(), key=lambda kv: kv[1], reverse=True)[:limit]]

def _close_item_from_trade(r: Dict[str, Any], tag: str, give: float, sources: Dict[str, Dict[str, Any]], fmap: Dict[str, Dict[str, Any]], ofmap: Dict[str, Dict[str, Any]], regime: Dict[str, Any]) -> Dict[str, Any]:
    item = {"ticker": ticker_norm(r.get("ticker")), "peak_pct": fnum(r.get("peak_pct"), r.get("max_profit_pct"), default=0.0), "pnl_pct": fnum(r.get("pnl_pct"), r.get("profit_pct"), default=0.0), "giveback_pct": round(give,3), "reason": r.get("exit_reason"), "tag": r.get("close_review_tag") or tag}
    # closed row 자체의 entry_context/snapshot 구조를 우선 복사하고, 없으면 현재 후보 snapshot 또는 표시용 파생값을 붙인다.
    ctx = r.get("entry_context") if isinstance(r.get("entry_context"), dict) else {}
    snap = r.get("entry_snapshot") if isinstance(r.get("entry_snapshot"), dict) else {}
    flat = snap.get("flat") if isinstance(snap.get("flat"), dict) else {}
    src = dict(r)
    for k in ("chart_structure", "structure_tags", "structure_good_tags", "structure_risk_tags", "structure_fit", "structure_summary", "market_regime", "market_regime_tags", "market_risk_tags", "market_regime_summary"):
        if k not in src and k in ctx: src[k] = ctx[k]
        if k not in src and k in flat: src[k] = flat[k]
    if _has_structure(src):
        _copy_structure(item, src)
    else:
        t = ticker_norm(item.get("ticker"))
        if t:
            _copy_structure(item, sources.get(t, {}) or {})
        _ensure_structure(item, sources)
    if _has_market(src):
        _copy_market(item, src)
    else:
        t = ticker_norm(item.get("ticker"))
        if t:
            _copy_market(item, sources.get(t, {}) or {})
        _ensure_market(item, sources, fmap, ofmap, regime)
    return item

def _legacy_closed_summary(sources: Optional[Dict[str, Dict[str, Any]]]=None, fmap: Optional[Dict[str, Dict[str, Any]]]=None, ofmap: Optional[Dict[str, Dict[str, Any]]]=None, regime: Optional[Dict[str, Any]]=None) -> Dict[str, Any]:
    sources = sources or {}; fmap = fmap or {}; ofmap = ofmap or {}; regime = regime or {}
    rows = read_jsonl(CLOSED, max_lines=360)
    def pnl(r: Dict[str, Any]) -> float: return fnum(r.get("pnl_pct"), r.get("profit_pct"), default=0.0)
    def peak(r: Dict[str, Any]) -> float: return fnum(r.get("peak_pct"), r.get("max_profit_pct"), default=0.0)
    protect_needed=[]; fast_fail=[]; good_keep=[]
    for r in rows[-80:]:
        pk=peak(r); pn=pnl(r); give=max(0.0, pk-pn)
        if pk >= 0.70 and (pn < 0 or give >= 0.55):
            protect_needed.append(_close_item_from_trade(r, "보호익절 필요 후보", give, sources, fmap, ofmap, regime))
        elif pn <= -0.60 and pk < 0.25:
            fast_fail.append(_close_item_from_trade(r, "빠른실패 정리 후보", give, sources, fmap, ofmap, regime))
        elif pn > 0 and pk-pn <= 0.35:
            good_keep.append(_close_item_from_trade(r, "수익 보존 양호", give, sources, fmap, ofmap, regime))
    big_loss = sorted([r for r in rows if profit(r) <= -0.8], key=profit)[:10]
    good_win = sorted([r for r in rows if profit(r) >= 1.0], key=profit, reverse=True)[:10]
    return {"closed_recent": len(rows), "big_loss": len(big_loss), "good_win": len(good_win), "close_review": {"protect_needed_count": len(protect_needed), "fast_fail_count": len(fast_fail), "good_keep_count": len(good_keep), "protect_needed": protect_needed[-5:], "fast_fail": fast_fail[-5:], "good_keep": good_keep[-5:]}}



# v655: review_worker는 후보판단/장부 주인이 아니라 복기 요약 주인이다.
# paper CLOSED 장부는 삭제하지 않고, active missed-review state에서 의미 낮은 추적만 빨리 순환한다.
def _v655_keep_active_review(rec: Dict[str, Any], nowv: float, base_ttl: float) -> bool:
    if not isinstance(rec, dict):
        return False
    first = fnum(rec.get("first_seen_ts"), default=nowv)
    age = max(0.0, nowv - first)
    cls = str(rec.get("decision") or rec.get("review_class") or rec.get("review_hint") or "")
    maxp = fnum(rec.get("max_pct"), default=0.0)
    curp = fnum(rec.get("current_pct"), default=0.0)
    # 중요한 복기 후보는 기존 보관기한 유지.
    if any(w in cls for w in ("진짜 놓친", "아까운", "위험 후보", "위험상승")):
        return age <= base_ttl
    # 늦게 오른 후보/큰 변동 후보는 전략 보정 참고용으로 몇 시간만 유지.
    if "늦게 오른" in cls or maxp >= 0.70 or abs(curp) >= 1.00:
        return age <= min(base_ttl, 6 * 3600.0)
    # 추적중/안 산 게 맞음은 디스크·CPU를 잡아먹지 않게 짧게 순환.
    if "추적중" in cls or not cls:
        return age <= min(base_ttl, 90 * 60.0)
    if "안 산 게 맞음" in cls:
        return age <= min(base_ttl, 45 * 60.0)
    return age <= min(base_ttl, 2 * 3600.0)



def _v664_prune_active_size(active: Dict[str, Dict[str, Any]], nowv: float, max_keep: int = ACTIVE_REVIEW_MAX) -> Dict[str, Dict[str, Any]]:
    """v664: active missed-review state 크기 제한.
    paper CLOSED 장부는 손대지 않고, 상태 추적용 active dict만 핵심/최근 후보 위주로 유지한다.
    """
    if not isinstance(active, dict) or len(active) <= max_keep:
        return active
    important_words = ("진짜 놓친", "아까운", "위험 후보", "위험상승", "늦게 오른")
    rows = []
    for k, v in active.items():
        if not isinstance(v, dict):
            continue
        cls = str(v.get('decision') or v.get('review_class') or v.get('review_hint') or '')
        imp = 1 if any(w in cls for w in important_words) else 0
        maxp = fnum(v.get('max_pct'), default=0.0)
        curp = abs(fnum(v.get('current_pct'), default=0.0))
        last = fnum(v.get('last_seen_ts'), v.get('first_seen_ts'), default=0.0)
        score = imp * 1000000.0 + maxp * 1000.0 + curp * 300.0 + last / 100000.0
        rows.append((score, k, v))
    rows.sort(key=lambda x: x[0], reverse=True)
    kept = {k: v for _, k, v in rows[:max_keep]}
    return kept


# =============================================================================
# review_worker v0.14 / v665: trigger shadow benchmark 추적
# - strategy_worker가 만든 shadow 후보를 읽어 이후 가격 경로를 비교한다.
# - 실제 paper OPEN/장부/청산은 바꾸지 않는다.
# =============================================================================

def _v665_variant_key(c: Dict[str, Any], variant: Dict[str, Any]) -> str:
    return '|'.join(str(x or '-') for x in (c.get('shadow_key_base'), variant.get('key')))



def _v678_trigger_shadow_score(rec: Dict[str, Any], nowv: float) -> float:
    try:
        entered = 1 if bool(rec.get('entered')) else 0
        maxp = fnum(rec.get('max_pct'), default=0.0)
        curp = abs(fnum(rec.get('current_pct'), default=0.0))
        last = fnum(rec.get('last_seen_ts'), rec.get('first_seen_ts'), default=nowv)
        sampled = len(rec.get('samples') if isinstance(rec.get('samples'), dict) else {})
        return entered * 1000000.0 + sampled * 200000.0 + maxp * 1000.0 + curp * 200.0 + last / 100000.0
    except Exception:
        return 0.0


def _v678_prune_trigger_shadow_active(active: Dict[str, Dict[str, Any]], nowv: float) -> Dict[str, Dict[str, Any]]:
    """trigger shadow는 검증용 state라 오래 들고 있지 않는다. touched라고 TTL을 무시하지 않는다."""
    ttl_entered = max(600.0, TRIGGER_SHADOW_ENTERED_TTL_SEC)
    ttl_pending = max(300.0, TRIGGER_SHADOW_PENDING_TTL_SEC)
    max_keep = max(100, TRIGGER_SHADOW_ACTIVE_MAX)
    kept = {}
    for k, rec in (active or {}).items():
        if not isinstance(rec, dict):
            continue
        first = fnum(rec.get('first_seen_ts'), default=nowv)
        age = max(0.0, nowv - first)
        entered = bool(rec.get('entered'))
        if entered and age <= ttl_entered:
            kept[k] = rec
        elif (not entered) and age <= ttl_pending:
            kept[k] = rec
    if len(kept) <= max_keep:
        return kept
    ranked = sorted(kept.items(), key=lambda kv: _v678_trigger_shadow_score(kv[1], nowv), reverse=True)
    return {k: v for k, v in ranked[:max_keep]}

def _v665_trigger_shadow_update(nowv: float, fmap: Dict[str, Dict[str, Any]], ofmap: Dict[str, Dict[str, Any]]) -> Dict[str, Any]:
    cand_obj = load_json(TRIGGER_SHADOW_CANDIDATES, {}) or {}
    candidates = cand_obj.get('rows') if isinstance(cand_obj, dict) and isinstance(cand_obj.get('rows'), list) else []
    state_obj = load_json(TRIGGER_SHADOW_STATE, {}) or {}
    active = state_obj.get('active') if isinstance(state_obj, dict) and isinstance(state_obj.get('active'), dict) else {}
    touched = set()
    # 기존 state 정리 TTL: 미진입 30분, 진입 40분 이후 요약만 남김
    for c in candidates:
        if not isinstance(c, dict):
            continue
        t = ticker_norm(c.get('ticker'))
        if not t:
            continue
        cur = _current_price(t, fmap, ofmap)
        if not cur:
            cur = fnum(c.get('current_price'), default=0.0)
        for var in c.get('variants') or []:
            if not isinstance(var, dict):
                continue
            k = _v665_variant_key(c, var)
            touched.add(k)
            threshold = fnum(var.get('threshold_price'), default=0.0)
            rec = active.get(k) if isinstance(active.get(k), dict) else None
            if not rec:
                rec = {
                    'schema': 'trigger_shadow_variant_state_v665',
                    'key': k,
                    'ticker': t,
                    'variant': var.get('key'),
                    'variant_label': var.get('label'),
                    'entry_mode': var.get('entry_mode'),
                    'threshold_price': threshold,
                    'first_seen_ts': nowv,
                    'first_seen_text': now_text(nowv),
                    'source': c.get('trigger_source'),
                    'stage': c.get('stage'),
                    'coin_quality_score': c.get('coin_quality_score'),
                    'trigger_price': c.get('trigger_price'),
                    'trigger_gap_pct': c.get('trigger_gap_pct'),
                    'entered': False,
                    'samples': {},
                    'max_pct': 0.0,
                    'min_pct': 0.0,
                    'policy': 'v665 shadow only. 실제 주문/장부 변경 없음.',
                }
            rec['last_seen_ts'] = nowv
            rec['last_seen_text'] = now_text(nowv)
            rec['latest_price'] = cur
            # 진입 판정: immediate는 첫 가격, threshold는 해당 가격 이상 도달 시 가상진입.
            if not rec.get('entered') and cur:
                if str(var.get('entry_mode')) == 'immediate' or (threshold and cur >= threshold):
                    rec['entered'] = True
                    rec['entry_ts'] = nowv
                    rec['entry_text'] = now_text(nowv)
                    rec['entry_price'] = cur
                    rec['entry_reason'] = 'immediate_current' if str(var.get('entry_mode')) == 'immediate' else 'threshold_reached'
            if rec.get('entered') and cur:
                entry = fnum(rec.get('entry_price'), default=0.0)
                pct = _pct(cur, entry)
                rec['current_pct'] = pct
                rec['max_pct'] = max(fnum(rec.get('max_pct'), default=pct), pct)
                rec['min_pct'] = min(fnum(rec.get('min_pct'), default=pct), pct)
                elapsed = max(0.0, nowv - fnum(rec.get('entry_ts'), default=nowv))
                samples = rec.get('samples') if isinstance(rec.get('samples'), dict) else {}
                for label, sec in (('3m',180),('5m',300),('10m',600),('20m',1200)):
                    if elapsed >= sec and label not in samples:
                        samples[label] = {'ts': nowv, 'text': now_text(nowv), 'price': cur, 'pct': pct, 'max_pct': rec.get('max_pct'), 'min_pct': rec.get('min_pct')}
                rec['samples'] = samples
            else:
                wait = max(0.0, nowv - fnum(rec.get('first_seen_ts'), default=nowv))
                rec['wait_sec'] = round(wait, 1)
                if wait >= 1200:
                    rec['not_entered_timeout'] = True
            active[k] = rec
    # v678 active pruning owner
    # 이전 구경로는 k in touched면 TTL을 넘어도 계속 살려 active가 수천 개로 누적됐다.
    # touched 예외를 삭제하고, entered/pending TTL + 서버보호 safety cap으로 단일화한다.
    before_shadow_active = len(active)
    active = _v678_prune_trigger_shadow_active(active, nowv)
    pruned_shadow_active = max(0, before_shadow_active - len(active))
    rows = list(active.values())
    entered = [r for r in rows if r.get('entered')]
    pending = [r for r in rows if not r.get('entered')]
    by_variant: Dict[str, List[Dict[str, Any]]] = {}
    for r in rows:
        by_variant.setdefault(str(r.get('variant') or '-'), []).append(r)
    variant_summary = {}
    for vk, arr in by_variant.items():
        ent = [r for r in arr if r.get('entered')]
        variant_summary[vk] = {
            'total': len(arr),
            'entered': len(ent),
            'pending': len(arr) - len(ent),
            'avg_max_pct': round(sum(fnum(r.get('max_pct'), default=0.0) for r in ent) / len(ent), 3) if ent else 0.0,
            'win_0_3_count': sum(1 for r in ent if fnum(r.get('max_pct'), default=0.0) >= 0.30),
            'loss_0_3_count': sum(1 for r in ent if fnum(r.get('min_pct'), default=0.0) <= -0.30),
        }
    top = sorted(entered, key=lambda r: fnum(r.get('max_pct'), default=0.0), reverse=True)[:8]
    summary = {
        'schema': 'trigger_shadow_review_v665',
        'version': VERSION,
        'updated_ts': nowv,
        'updated_text': now_text(nowv),
        'candidate_source_age_sec': round(nowv - fnum(cand_obj.get('updated_ts'), default=nowv), 1) if isinstance(cand_obj, dict) else None,
        'active_count': len(rows),
        'entered_count': len(entered),
        'pending_count': len(pending),
        'pruned_count_v678': pruned_shadow_active,
        'active_max_v678': TRIGGER_SHADOW_ACTIVE_MAX,
        'ttl_entered_sec_v678': TRIGGER_SHADOW_ENTERED_TTL_SEC,
        'ttl_pending_sec_v678': TRIGGER_SHADOW_PENDING_TTL_SEC,
        'variant_summary': variant_summary,
        'top_entered': [{k:r.get(k) for k in ('ticker','variant','variant_label','source','stage','coin_quality_score','entry_price','latest_price','current_pct','max_pct','min_pct')} for r in top],
        'policy': 'v678 trigger shadow hot/cold. 실제 S1/paper OPEN/청산/자동매수 변경 없음. touched TTL 예외 삭제.',
    }
    save_json(TRIGGER_SHADOW_STATE, {'schema':'trigger_shadow_state_v665', 'version':VERSION, 'updated_ts':nowv, 'updated_text':now_text(nowv), 'active':active})
    save_json(TRIGGER_SHADOW_SUMMARY, summary)
    return summary



# =============================================================================
# review_worker v0.15 / v667: whole-market missed-scan review
# - strategy_worker가 저장한 전체 canonical snapshot을 추적해 3/5/10분 뒤 상승 후보가 어디서 묻혔는지 본다.
# - 실제 paper 장부/OPEN/청산/자동매수는 변경하지 않는다.
# =============================================================================

def _v667_miss_key(c: Dict[str, Any]) -> str:
    return ticker_norm(c.get('ticker'))


def _v667_market_miss_update(nowv: float, fmap: Dict[str, Dict[str, Any]], ofmap: Dict[str, Dict[str, Any]]) -> Dict[str, Any]:
    cand_obj = load_json(MARKET_MISS_CANDIDATES, {}) or {}
    candidates = cand_obj.get('rows') if isinstance(cand_obj, dict) and isinstance(cand_obj.get('rows'), list) else []
    # v668: always publish a visible summary, even before 3/5/10m maturity.
    state = load_json(MARKET_MISS_STATE, {}) or {}
    active = state.get('active') if isinstance(state, dict) and isinstance(state.get('active'), dict) else {}
    # TTL: 최근 35분만 추적. 전체 456개를 보되 ticker별 1개 state만 유지한다.
    ttl = 35 * 60.0
    active = {k:v for k,v in active.items() if isinstance(v, dict) and nowv - fnum(v.get('first_seen_ts'), default=nowv) <= ttl}
    for c in candidates:
        if not isinstance(c, dict):
            continue
        t = _v667_miss_key(c)
        if not t:
            continue
        cur = _current_price(t, fmap, ofmap)
        base = fnum(c.get('snapshot_price'), default=0.0) or cur
        if not base:
            continue
        rec = active.get(t)
        if not isinstance(rec, dict):
            rec = {
                'schema': 'market_miss_state_row_v667',
                'ticker': t,
                'first_seen_ts': nowv,
                'first_seen_text': now_text(nowv),
                'first_price': base,
                'min_pct': 0.0,
                'max_pct': 0.0,
                'samples': {},
            }
        rec.update({
            'last_seen_ts': nowv,
            'last_seen_text': now_text(nowv),
            'initial_stage': c.get('initial_stage'),
            'coin_quality_score': c.get('coin_quality_score'),
            'execution_risk_score': c.get('execution_risk_score'),
            'miss_bucket': c.get('miss_bucket'),
            'initial_reason': c.get('initial_reason'),
            'trigger_source': c.get('trigger_source'),
            'trigger_gap_pct': c.get('trigger_gap_pct'),
            'coverage_only': c.get('coverage_only'),
        })
        if cur:
            rec['latest_price'] = cur
            cp = _pct(cur, fnum(rec.get('first_price'), default=base))
            rec['current_pct'] = cp
            rec['max_pct'] = max(fnum(rec.get('max_pct'), default=cp), cp)
            rec['min_pct'] = min(fnum(rec.get('min_pct'), default=cp), cp)
            elapsed = nowv - fnum(rec.get('first_seen_ts'), default=nowv)
            rec['age_sec'] = round(elapsed, 1)
            samples = rec.get('samples') if isinstance(rec.get('samples'), dict) else {}
            for label, sec in (('3m',180),('5m',300),('10m',600)):
                if elapsed >= sec and label not in samples:
                    samples[label] = {'ts': nowv, 'text': now_text(nowv), 'price': cur, 'pct': cp, 'max_pct': rec.get('max_pct'), 'min_pct': rec.get('min_pct')}
            rec['samples'] = samples
            # 분류: 오른 후보가 왜 안 샀는지. 위험 낮고 품질 높으면 진짜 놓침 가능성.
            maxp = fnum(rec.get('max_pct'), default=0.0)
            risk = fnum(rec.get('execution_risk_score'), default=0.0)
            q = fnum(rec.get('coin_quality_score'), default=0.0)
            bucket = str(rec.get('miss_bucket') or '-')
            if maxp >= 0.70 and q >= 60 and risk <= 40 and bucket not in ('risk_filter_candidate',):
                rec['miss_decision'] = '❌ 진짜놓침_후보'
            elif maxp >= 0.70 and bucket == 'risk_filter_candidate':
                rec['miss_decision'] = '✅ 위험필터_성공검토'
            elif maxp >= 0.40:
                rec['miss_decision'] = '⚠️ 아까운상승'
            else:
                rec['miss_decision'] = '관찰중'
        active[t] = rec
    rows = list(active.values())
    matured = [r for r in rows if fnum(r.get('age_sec'), default=0) >= 180]
    risers = [r for r in rows if fnum(r.get('max_pct'), default=0) >= 0.40]
    true_missed = [r for r in rows if str(r.get('miss_decision')) == '❌ 진짜놓침_후보']
    buckets = Counter(str(r.get('miss_bucket') or '-') for r in risers)
    stages = Counter(str(r.get('initial_stage') or '-') for r in rows)
    decisions = Counter(str(r.get('miss_decision') or '-') for r in rows)
    top = sorted(risers, key=lambda r: fnum(r.get('max_pct'), default=0.0), reverse=True)[:12]
    true_top = sorted(true_missed, key=lambda r: fnum(r.get('max_pct'), default=0.0), reverse=True)[:10]
    def slim(r: Dict[str, Any]) -> Dict[str, Any]:
        return {k:r.get(k) for k in ('ticker','initial_stage','miss_bucket','miss_decision','coin_quality_score','execution_risk_score','first_price','latest_price','current_pct','max_pct','min_pct','age_sec','initial_reason','trigger_source','trigger_gap_pct')}
    summary = {
        'schema': 'market_miss_review_v671_tracking_fixed',
        'version': VERSION,
        'updated_ts': nowv,
        'updated_text': now_text(nowv),
        'candidate_source_age_sec': round(nowv - fnum(cand_obj.get('updated_ts'), default=nowv), 1) if isinstance(cand_obj, dict) else None,
        'tracking_total': len(rows),
        'matured_count': len(matured),
        'rise_count': len(risers),
        'true_missed_count': len(true_missed),
        'candidate_source_count': len(candidates),
        'active_saved_count': len(rows),
        'price_source': 'orderflow/feature current price + snapshot fallback',
        'tracking_waiting_3m': sum(1 for r in rows if fnum(r.get('age_sec'), default=0) < 180),
        'miss_bucket_counts': dict(buckets.most_common(10)),
        'initial_stage_counts': dict(stages.most_common(6)),
        'decision_counts': dict(decisions.most_common(8)),
        'recheck_lane_counts': dict(Counter(str(r.get('miss_bucket') or '-') for r in rows if str(r.get('miss_decision')) in ('❌ 진짜놓침_후보','⚠️ 아까운상승')).most_common(10)),
        'top_risers': [slim(r) for r in top],
        'true_missed_top': [slim(r) for r in true_top],
        'policy': 'v671: Counter import/runtime error 복구 + 전체 456 놓침검증 추적 상태를 항상 저장/표시. 실제 S1/paper OPEN/청산/자동매수 변경 없음.',
    }
    save_json(MARKET_MISS_STATE, {'schema':'market_miss_state_v671_tracking_fixed', 'version':VERSION, 'updated_ts':nowv, 'updated_text':now_text(nowv), 'active':active})
    save_json(MARKET_MISS_SUMMARY, summary)
    return summary

def _v923_append_jsonl(path: Path, row: Dict[str, Any]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open('a', encoding='utf-8') as f:
        f.write(json.dumps(row, ensure_ascii=False, separators=(',', ':'), default=str) + '\n')
        f.flush()
        os.fsync(f.fileno())


def _v923_open_rows() -> List[Dict[str, Any]]:
    obj = load_json(OPEN, {}) or {}
    if isinstance(obj, dict) and isinstance(obj.get('positions'), dict):
        return [dict(v) for v in obj.get('positions', {}).values() if isinstance(v, dict)]
    if isinstance(obj, dict):
        rows = []
        for k, v in obj.items():
            if isinstance(v, dict) and (v.get('ticker') or v.get('pos_id') or v.get('event_id')):
                rr = dict(v); rr.setdefault('pos_id', k); rows.append(rr)
        return rows
    if isinstance(obj, list):
        return [dict(v) for v in obj if isinstance(v, dict)]
    return []


def _v923_candidate_key_from_paper(row: Dict[str, Any]) -> str:
    if not isinstance(row, dict):
        return ''
    for k in ('candidate_entry_build_key_v923', 'candidate_entry_build_key'):
        v = row.get(k)
        if v not in (None, '', '-', [], {}):
            return str(v)
    cost = row.get('paper_execution_cost_v917') if isinstance(row.get('paper_execution_cost_v917'), dict) else {}
    v = cost.get('candidate_entry_build_key')
    return str(v) if v not in (None, '', '-', [], {}) else ''


def _v923_occurrence_from_paper(row: Dict[str, Any]) -> str:
    if not isinstance(row, dict):
        return ''
    v = row.get('good_s2_occurrence_key_v923')
    if v not in (None, '', '-', [], {}):
        return str(v)
    cost = row.get('paper_execution_cost_v917') if isinstance(row.get('paper_execution_cost_v917'), dict) else {}
    v = cost.get('good_s2_occurrence_key_v923')
    return str(v) if v not in (None, '', '-', [], {}) else ''


def _v923_exact_maps(rows: List[Dict[str, Any]]) -> Dict[str, Dict[str, Any]]:
    by_occ: Dict[str, Dict[str, Any]] = {}
    candidate_lists: Dict[str, List[Dict[str, Any]]] = {}
    for row in rows or []:
        if not isinstance(row, dict):
            continue
        occ = _v923_occurrence_from_paper(row)
        if occ:
            by_occ[occ] = row
        ck = _v923_candidate_key_from_paper(row)
        if ck:
            candidate_lists.setdefault(ck, []).append(row)
    by_candidate = {k: v[0] for k, v in candidate_lists.items() if len(v) == 1}
    ambiguous = {k: len(v) for k, v in candidate_lists.items() if len(v) > 1}
    return {'by_occurrence': by_occ, 'by_candidate': by_candidate, 'ambiguous_candidate': ambiguous}


def _v923_result_record_from_observation(obs: Dict[str, Any]) -> Dict[str, Any]:
    occurrence = str(obs.get('occurrence_key') or '')
    price = fnum(obs.get('price'), default=0.0)
    ts = fnum(obs.get('observed_ts'), default=0.0)
    return {
        'schema': 'good_s2_result_state_row_v923',
        'version': 'review_worker_v0.926',
        'build': 'good_s2_source_exact_result_v926_2026-06-18',
        'occurrence_key': occurrence,
        'observation_key': obs.get('observation_key'),
        'ticker': ticker_norm(obs.get('ticker')),
        'observed_ts': ts,
        'observed_text': obs.get('observed_text') or now_text(ts),
        'first_price': price,
        'latest_price': price,
        'current_pct': 0.0,
        'max_pct': 0.0,
        'min_pct': 0.0,
        'giveback_pct': 0.0,
        'max_seen_ts': ts,
        'min_seen_ts': ts,
        'samples': {},
        'entry_build_key': obs.get('entry_build_key'),
        'stable_event_key': obs.get('stable_event_key'),
        'candidate_follow_key': obs.get('candidate_follow_key'),
        'score_patch_version': obs.get('score_patch_version'),
        'initial_metrics': obs.get('metrics') if isinstance(obs.get('metrics'), dict) else {},
        'structure': obs.get('structure') if isinstance(obs.get('structure'), dict) else {},
        'structure_tags': list(obs.get('structure_tags') or [])[:12],
        'quality_tags': list(obs.get('quality_tags') or [])[:12],
        'open_linked': False,
        'closed_linked': False,
        'terminal': False,
        'result_state': 'tracking',
        'link_policy': 'occurrence key exact first; unique candidate event exact second; ticker never final',
    }


def _v923_result_final_key(rec: Dict[str, Any]) -> str:
    occ = str(rec.get('occurrence_key') or '')
    if rec.get('closed_linked') and rec.get('closed_result_key'):
        return f"{occ}|closed:{rec.get('closed_result_key')}"
    if rec.get('horizon_complete'):
        return f'{occ}|horizon:{int(GOOD_S2_RESULT_HORIZON_SEC)}'
    return ''



def _v925_reset_overcount_result_state_if_needed(nowv: float, valid_occurrences: set[str]) -> Dict[str, Any]:
    """Quarantine every non-source-backed review row, including old terminal rows.

    v925 removed only non-terminal cache rows. The 1,647 contaminated terminal rows
    therefore remained in the live state/final ledger and still distorted averages.
    v926 makes the strategy observation ledger the only valid occurrence spine.
    Removed rows are gzip-quarantined; OPEN/CLOSED ledgers are never touched.
    """
    qdir = BASE_DIR / 'quarantine'; qdir.mkdir(parents=True, exist_ok=True)
    stamp = time.strftime('%Y%m%d_%H%M%S', time.localtime(nowv))

    state = load_json(GOOD_S2_RESULT_STATE, {}) or {}
    records = state.get('records') if isinstance(state, dict) and isinstance(state.get('records'), dict) else {}
    stale_state = {str(k): v for k, v in records.items() if str(k) not in valid_occurrences and isinstance(v, dict)}
    kept_state = {str(k): v for k, v in records.items() if str(k) in valid_occurrences and isinstance(v, dict)}
    state_quarantine = ''
    if stale_state:
        state_dest = qdir / f'good_s2_result_state_non_source_{stamp}.json.gz'
        with gzip.open(state_dest, 'wt', encoding='utf-8', compresslevel=6) as f:
            json.dump({'schema':'good_s2_result_state_quarantine_v926','removed_records':stale_state,'source_state_meta':{k:v for k,v in state.items() if k!='records'}}, f, ensure_ascii=False, separators=(',', ':'), default=str)
        state_quarantine = state_dest.name
        save_json(GOOD_S2_RESULT_STATE, {
            'schema':'good_s2_result_state_v923','version':'review_worker_v0.926',
            'build':'good_s2_source_exact_result_v926_2026-06-18',
            'updated_ts':nowv,'updated_text':now_text(nowv),'records':kept_state,
            'retention_sec':GOOD_S2_RESULT_RETENTION_SEC,
        })

    ledger_rows = [r for r in read_jsonl(GOOD_S2_RESULT_LEDGER, max_lines=0) if isinstance(r, dict)]
    kept_ledger = [r for r in ledger_rows if str(r.get('occurrence_key') or '') in valid_occurrences]
    stale_ledger = [r for r in ledger_rows if str(r.get('occurrence_key') or '') not in valid_occurrences]
    ledger_quarantine = ''
    if stale_ledger:
        ledger_dest = qdir / f'good_s2_result_ledger_non_source_{stamp}.jsonl.gz'
        with gzip.open(ledger_dest, 'wt', encoding='utf-8', compresslevel=6) as f:
            for row in stale_ledger:
                f.write(json.dumps(row, ensure_ascii=False, separators=(',', ':'), default=str) + '\n')
        ledger_quarantine = ledger_dest.name
        tmp = GOOD_S2_RESULT_LEDGER.with_suffix(GOOD_S2_RESULT_LEDGER.suffix + '.v926tmp')
        tmp.parent.mkdir(parents=True, exist_ok=True)
        with tmp.open('w', encoding='utf-8') as f:
            for row in kept_ledger:
                f.write(json.dumps(row, ensure_ascii=False, separators=(',', ':'), default=str) + '\n')
            f.flush(); os.fsync(f.fileno())
        os.replace(tmp, GOOD_S2_RESULT_LEDGER)

    meta = {
        'schema':'good_s2_result_source_spine_reset_v926','completed':True,
        'state':'QUARANTINED_NON_SOURCE' if (stale_state or stale_ledger) else 'SOURCE_BACKED',
        'records_before':len(records),'records_kept':len(kept_state),
        'valid_occurrence_count':len(valid_occurrences),'removed_state_records':len(stale_state),
        'ledger_rows_before':len(ledger_rows),'ledger_rows_kept':len(kept_ledger),'removed_ledger_rows':len(stale_ledger),
        'state_quarantine_file':state_quarantine,'ledger_quarantine_file':ledger_quarantine,
        'performance_excluded':True,'updated_ts':nowv,'updated_text':now_text(nowv),
        'policy':'only strategy observation occurrence keys remain in live good-S2 result state/ledger; removed rows are gzip-quarantined',
    }
    save_json(GOOD_S2_RESULT_RESET_META_V926, meta)
    save_json(GOOD_S2_RESULT_RESET_META_V925, meta)
    return meta

def _v923_update_good_s2_results(nowv: float, fmap: Dict[str, Dict[str, Any]], ofmap: Dict[str, Dict[str, Any]]) -> Dict[str, Any]:
    observations = [r for r in read_jsonl(GOOD_S2_OBSERVATION_LEDGER, max_lines=5000)
                    if isinstance(r, dict) and str(r.get('schema') or '') == 'good_s2_observation_v923'
                    and str(r.get('version') or '') in {'strategy_worker_v0.923','strategy_worker_v0.925'}
                    and not bool(r.get('performance_excluded'))
                    and str(r.get('occurrence_key') or '')]
    valid_occurrences = {str(r.get('occurrence_key') or '') for r in observations if str(r.get('occurrence_key') or '')}
    reset_meta_v925 = _v925_reset_overcount_result_state_if_needed(nowv, valid_occurrences)
    state_obj = load_json(GOOD_S2_RESULT_STATE, {}) or {}
    records = state_obj.get('records') if isinstance(state_obj, dict) and isinstance(state_obj.get('records'), dict) else {}
    records = {str(k): dict(v) for k, v in records.items() if isinstance(v, dict) and (str(k) in valid_occurrences or bool(v.get('closed_linked')) or bool(v.get('final_result_key')))}
    new_records = 0
    for obs in observations:
        occ = str(obs.get('occurrence_key') or '')
        if occ not in records:
            records[occ] = _v923_result_record_from_observation(obs)
            new_records += 1

    open_rows = _v923_open_rows()
    closed_rows = [r for r in read_jsonl(CLOSED, max_lines=2500) if isinstance(r, dict)]
    open_maps = _v923_exact_maps(open_rows)
    closed_maps = _v923_exact_maps(closed_rows)
    final_existing = {str(r.get('final_result_key') or '') for r in read_jsonl(GOOD_S2_RESULT_LEDGER, max_lines=10000) if isinstance(r, dict) and r.get('final_result_key')}
    link_modes = Counter()
    samples_ready = Counter()
    appended_final = 0
    ticker_audit_open = 0
    ticker_audit_closed = 0
    open_tickers = {ticker_norm(r.get('ticker')) for r in open_rows if isinstance(r, dict)}
    closed_tickers = {ticker_norm(r.get('ticker')) for r in closed_rows if isinstance(r, dict)}

    for occ, rec in list(records.items()):
        if not isinstance(rec, dict):
            continue
        ticker = ticker_norm(rec.get('ticker'))
        first_price = fnum(rec.get('first_price'), default=0.0)
        cur = _current_price(ticker, fmap, ofmap) if ticker else 0.0
        if cur <= 0:
            cur = fnum(rec.get('latest_price'), default=first_price)
        if cur > 0 and first_price > 0:
            pct = _pct(cur, first_price)
            rec['latest_price'] = cur
            rec['current_pct'] = pct
            old_max = fnum(rec.get('max_pct'), default=pct)
            old_min = fnum(rec.get('min_pct'), default=pct)
            if pct >= old_max:
                rec['max_seen_ts'] = nowv
                rec['max_seen_text'] = now_text(nowv)
            if pct <= old_min:
                rec['min_seen_ts'] = nowv
                rec['min_seen_text'] = now_text(nowv)
            rec['max_pct'] = max(old_max, pct)
            rec['min_pct'] = min(old_min, pct)
            rec['giveback_pct'] = round(max(0.0, fnum(rec.get('max_pct'), default=0.0) - pct), 3)
        age = max(0.0, nowv - fnum(rec.get('observed_ts'), default=nowv))
        rec['age_sec'] = round(age, 1)
        rec['last_updated_ts'] = nowv
        rec['last_updated_text'] = now_text(nowv)
        samples = rec.get('samples') if isinstance(rec.get('samples'), dict) else {}
        for label, sec in (('3m',180),('5m',300),('10m',600),('20m',1200),('60m',3600)):
            if age >= sec and label not in samples:
                samples[label] = {
                    'ts': nowv, 'text': now_text(nowv), 'price': rec.get('latest_price'),
                    'pct': rec.get('current_pct'), 'max_pct': rec.get('max_pct'), 'min_pct': rec.get('min_pct'),
                    'giveback_pct': rec.get('giveback_pct'),
                }
            if label in samples:
                samples_ready[label] += 1
        rec['samples'] = samples

        exact = str(rec.get('entry_build_key') or '')
        open_row = open_maps['by_occurrence'].get(occ)
        open_mode = 'occurrence_exact' if isinstance(open_row, dict) else ''
        if open_row is None and exact:
            open_row = open_maps['by_candidate'].get(exact)
            open_mode = 'candidate_event_exact' if isinstance(open_row, dict) else ''
        if isinstance(open_row, dict):
            rec['open_linked'] = True
            rec['open_match_mode'] = open_mode
            rec['open_pos_id'] = open_row.get('pos_id') or open_row.get('event_id')
            rec['opened_at'] = fnum(open_row.get('opened_at'), default=0.0) or None
            rec['open_entry_price'] = fnum(open_row.get('entry_price'), default=0.0) or None
            rec['open_score_patch_version'] = open_row.get('score_patch_version') or open_row.get('entry_build_key')
            link_modes[f'open:{open_mode}'] += 1
        elif ticker and ticker in open_tickers:
            ticker_audit_open += 1

        closed_row = closed_maps['by_occurrence'].get(occ)
        closed_mode = 'occurrence_exact' if isinstance(closed_row, dict) else ''
        if closed_row is None and exact:
            closed_row = closed_maps['by_candidate'].get(exact)
            closed_mode = 'candidate_event_exact' if isinstance(closed_row, dict) else ''
        if isinstance(closed_row, dict):
            rec['closed_linked'] = True
            rec['closed_match_mode'] = closed_mode
            rec['closed_result_key'] = closed_row.get('closed_result_key')
            rec['closed_ts'] = fnum(closed_row.get('closed_ts'), closed_row.get('closed_at'), default=0.0) or None
            rec['closed_pnl_pct'] = fnum(closed_row.get('pnl_pct'), closed_row.get('profit_pct'), default=0.0)
            rec['closed_peak_pct'] = fnum(closed_row.get('peak_pct'), default=0.0)
            rec['closed_trough_pct'] = fnum(closed_row.get('trough_pct'), default=0.0)
            rec['closed_giveback_pct'] = fnum(closed_row.get('giveback_pct'), closed_row.get('missed_profit_pct'), default=0.0)
            rec['exit_reason'] = closed_row.get('exit_reason') or closed_row.get('exit_rule')
            rec['terminal'] = True
            rec['result_state'] = 'closed_exact'
            link_modes[f'closed:{closed_mode}'] += 1
        elif ticker and ticker in closed_tickers:
            ticker_audit_closed += 1

        if not rec.get('closed_linked') and age >= GOOD_S2_RESULT_HORIZON_SEC:
            rec['horizon_complete'] = True
            rec['terminal'] = True
            rec['result_state'] = 'review_horizon_6h'
        final_key = _v923_result_final_key(rec)
        if final_key and final_key not in final_existing:
            final_row = {
                'schema': 'good_s2_final_result_v923',
                'version': 'review_worker_v0.923',
                'build': 'good_s2_exact_result_tracker_v923_2026-06-17',
                'final_result_key': final_key,
                'finalized_ts': nowv,
                'finalized_text': now_text(nowv),
                **{k: rec.get(k) for k in (
                    'occurrence_key','observation_key','ticker','observed_ts','first_price','latest_price','current_pct','max_pct','min_pct','giveback_pct',
                    'entry_build_key','stable_event_key','candidate_follow_key','score_patch_version','open_linked','open_match_mode','open_pos_id','opened_at','open_entry_price',
                    'closed_linked','closed_match_mode','closed_result_key','closed_ts','closed_pnl_pct','closed_peak_pct','closed_trough_pct','closed_giveback_pct','exit_reason',
                    'horizon_complete','result_state','samples','initial_metrics','structure','structure_tags','quality_tags')},
                'performance_eligible': True,
                'join_policy': 'exact occurrence or unique candidate event only; no ticker final join',
            }
            _v923_append_jsonl(GOOD_S2_RESULT_LEDGER, final_row)
            final_existing.add(final_key)
            rec['final_result_key'] = final_key
            rec['finalized_ts'] = nowv
            appended_final += 1

    # Keep completed state seven days; source/final ledgers remain preserved.
    kept: Dict[str, Dict[str, Any]] = {}
    pruned = 0
    for occ, rec in records.items():
        ref = fnum(rec.get('closed_ts'), rec.get('finalized_ts'), rec.get('last_updated_ts'), rec.get('observed_ts'), default=nowv)
        if rec.get('terminal') and nowv - ref > GOOD_S2_RESULT_RETENTION_SEC:
            pruned += 1
            continue
        kept[occ] = rec
    records = kept
    rows = list(records.values())
    closed_exact = [r for r in rows if r.get('closed_linked')]
    opened_exact = [r for r in rows if r.get('open_linked')]
    tracking = [r for r in rows if not r.get('terminal')]
    max_vals = [fnum(r.get('max_pct'), default=0.0) for r in rows]
    min_vals = [fnum(r.get('min_pct'), default=0.0) for r in rows]
    give_vals = [fnum(r.get('giveback_pct'), default=0.0) for r in rows]
    closed_pnls = [fnum(r.get('closed_pnl_pct'), default=0.0) for r in closed_exact]
    result_ledger_rows = len(read_jsonl(GOOD_S2_RESULT_LEDGER, max_lines=0))
    result_ledger_bytes = GOOD_S2_RESULT_LEDGER.stat().st_size if GOOD_S2_RESULT_LEDGER.exists() else 0
    recent = sorted(rows, key=lambda r: fnum(r.get('observed_ts'), default=0.0), reverse=True)[:80]
    snapshot = {
        'schema': 'good_s2_result_snapshot_v923',
        'version': 'review_worker_v0.926',
        'build': 'good_s2_source_exact_result_v926_2026-06-18',
        'updated_ts': nowv,
        'updated_text': now_text(nowv),
        'source_observation_rows_v923': len(observations),
        'state_reset_v925': reset_meta_v925,
        'new_records_this_cycle': new_records,
        'tracked_total': len(rows),
        'tracking_active': len(tracking),
        'opened_exact': len(opened_exact),
        'closed_exact': len(closed_exact),
        'horizon_complete': sum(1 for r in rows if r.get('horizon_complete')),
        'unmatched_exact': sum(1 for r in rows if not r.get('open_linked') and not r.get('closed_linked')),
        'ticker_audit_only_open': ticker_audit_open,
        'ticker_audit_only_closed': ticker_audit_closed,
        'link_mode_counts': dict(link_modes),
        'samples_ready': dict(samples_ready),
        'avg_max_pct': round(sum(max_vals)/len(max_vals), 4) if max_vals else None,
        'avg_min_pct': round(sum(min_vals)/len(min_vals), 4) if min_vals else None,
        'avg_giveback_pct': round(sum(give_vals)/len(give_vals), 4) if give_vals else None,
        'closed_wins': sum(1 for x in closed_pnls if x > 0),
        'closed_losses': sum(1 for x in closed_pnls if x <= 0),
        'closed_avg_pnl_pct': round(sum(closed_pnls)/len(closed_pnls), 4) if closed_pnls else None,
        'closed_sum_pnl_pct': round(sum(closed_pnls), 4) if closed_pnls else None,
        'final_appended_this_cycle': appended_final,
        'final_ledger_rows': result_ledger_rows,
        'final_ledger_bytes': result_ledger_bytes,
        'state_pruned_this_cycle': pruned,
        'review_horizon_sec': GOOD_S2_RESULT_HORIZON_SEC,
        'rows': recent,
        'last_row': recent[0] if recent else None,
        'policy': 'strategy occurrence -> live price path -> paper OPEN/CLOSED exact; ticker is audit only; no trading criteria change',
        'conditions_changed': False,
        'paper_open_changed': False,
        'exit_changed': False,
    }
    save_json(GOOD_S2_RESULT_STATE, {
        'schema': 'good_s2_result_state_v923', 'version': 'review_worker_v0.926',
        'build': 'good_s2_source_exact_result_v926_2026-06-18',
        'updated_ts': nowv, 'updated_text': now_text(nowv), 'records': records,
        'retention_sec': GOOD_S2_RESULT_RETENTION_SEC,
    })
    save_json(GOOD_S2_RESULT_SNAPSHOT, snapshot)
    return snapshot



def _quality_optional_num(*values: Any) -> Optional[float]:
    for value in values:
        if value in (None, '', '-', [], {}):
            continue
        try:
            number = float(str(value).replace(',', '').replace('%', ''))
        except Exception:
            continue
        if number == number and number not in (float('inf'), float('-inf')):
            return number
    return None


def _quality_exact_identity(row: Dict[str, Any]) -> tuple[str, str]:
    """Decision exact first, candidate exact second. Ticker/time-near is never an identity."""
    if not isinstance(row, dict):
        return '', ''
    gate = row.get('minimal_entry_gate_v925') if isinstance(row.get('minimal_entry_gate_v925'), dict) else {}
    decision = row.get('minimal_gate_decision_key_v925') or gate.get('decision_key')
    if decision not in (None, '', '-', [], {}):
        return 'decision:' + str(decision).strip(), 'minimal_gate_decision_exact'
    candidate = row.get('entry_build_key')
    if candidate not in (None, '', '-', [], {}):
        return 'candidate:' + str(candidate).strip(), 'candidate_entry_build_exact'
    return '', ''


def _quality_gate(row: Dict[str, Any]) -> Dict[str, Any]:
    gate = row.get('minimal_entry_gate_v925')
    return gate if isinstance(gate, dict) else {}


def _quality_block_reasons(row: Dict[str, Any], gate: Dict[str, Any]) -> List[str]:
    values = gate.get('hard_block_reasons') if isinstance(gate.get('hard_block_reasons'), list) else row.get('final_trade_reasons')
    seq = values if isinstance(values, list) else ([values] if values not in (None, '', '-', [], {}) else [])
    out: List[str] = []
    for item in seq:
        text = str(item or '').strip()
        if text and text not in out:
            out.append(text)
    return out


def _quality_cohort(hard_pass: bool, reasons: List[str]) -> str:
    if hard_pass:
        return 's1_pass'
    priority = (
        'frozen_trigger_not_reached',
        'risk_reward_below_minimum',
        'target_room_below_minimum',
        'coherent_structure_plan_incomplete',
        'actual_structural_invalid_missing',
        'next_structural_target_missing',
        'candidate_sources_not_fresh',
        'untradable_spread',
        'untradable_liquidity',
    )
    for reason in priority:
        if reason in reasons:
            return reason
    return reasons[0] if reasons else 'other_blocked'


def _quality_initial_metrics(row: Dict[str, Any], gate: Dict[str, Any]) -> Dict[str, Any]:
    quality = row.get('quality_observation_v925') if isinstance(row.get('quality_observation_v925'), dict) else {}
    hot = row.get('hot_watch_timing_v945') if isinstance(row.get('hot_watch_timing_v945'), dict) else {}
    return {
        'price_reaction_pct': _quality_optional_num(row.get('price_reaction_pct'), row.get('change_1m_pct'), quality.get('price_reaction_pct')),
        'buy_ratio': _quality_optional_num(row.get('buy_ratio'), row.get('buy_trade_ratio'), quality.get('buy_ratio')),
        'buy_sustain_1m': _quality_optional_num(row.get('buy_sustain_1m'), row.get('buy_sustain_60s'), quality.get('buy_sustain_1m')),
        'spread_pct': _quality_optional_num(gate.get('spread_pct'), row.get('spread_pct'), row.get('micro_spread_pct')),
        'risk_reward': _quality_optional_num(gate.get('risk_reward')),
        'target_room_pct': _quality_optional_num(gate.get('target_room_pct')),
        'trigger_gap_pct': _quality_optional_num(row.get('trigger_gap_pct'), (gate.get('structure_plan') or {}).get('distance_pct') if isinstance(gate.get('structure_plan'), dict) else None),
        'relative_strength': _quality_optional_num(row.get('relative_strength'), row.get('relative_strength_score'), quality.get('relative_strength')),
        'money_flow': _quality_optional_num(row.get('money_flow'), row.get('money_flow_score'), quality.get('money_flow')),
        'scanner_to_candidate_sec': _quality_optional_num(hot.get('scanner_to_strategy_sec')),
        'scanner_to_s2_sec': _quality_optional_num(hot.get('scanner_to_s2_sec')),
        'scanner_to_s1_sec': _quality_optional_num(hot.get('scanner_to_s1_sec')),
        'first_price': _quality_optional_num(row.get('current_price'), row.get('entry_price'), row.get('price'), row.get('detected_price')),
        'volume_ratio': _quality_optional_num(row.get('volume_ratio'), row.get('trade_value_ratio'), row.get('volume_expansion_ratio')),
        'turnover_change_pct': _quality_optional_num(row.get('turnover_change_pct'), row.get('trade_value_change_pct'), row.get('volume_expansion_pct')),
        'market_strength': _quality_optional_num(row.get('market_strength'), row.get('market_breadth'), row.get('regime_strength')),
        'market_regime': str(row.get('market_regime') or row.get('regime') or row.get('market_state') or '').strip() or None,
        'confirmed_slippage_pct': _quality_optional_num(row.get('slippage_pct_confirmed')),
        'confirmed_slippage_source': str(row.get('slippage_pct_source_v903') or row.get('slippage_pct_source') or '').strip() or None,
        'smart_structure_shadow_v948': row.get('smart_structure_shadow_v948') if isinstance(row.get('smart_structure_shadow_v948'),dict) else None,
    }


def _quality_load_final_keys() -> set[str]:
    global _QUALITY_FINAL_KEYS_CACHE
    if _QUALITY_FINAL_KEYS_CACHE is not None:
        return _QUALITY_FINAL_KEYS_CACHE
    keys: set[str] = set()
    paths: List[Path] = []
    if QUALITY_SHADOW_LEDGER.exists(): paths.append(QUALITY_SHADOW_LEDGER)
    if QUALITY_SHADOW_ARCHIVE.exists(): paths.extend(sorted(QUALITY_SHADOW_ARCHIVE.glob('quality_shadow_result_*.jsonl.gz')))
    for path in paths:
        try:
            if path.suffix == '.gz':
                handle = gzip.open(path, 'rt', encoding='utf-8')
            else:
                handle = path.open('r', encoding='utf-8', errors='ignore')
            with handle:
                for line in handle:
                    try:
                        obj=json.loads(line)
                    except Exception:
                        continue
                    if isinstance(obj,dict) and obj.get('quality_event_key_v946'):
                        keys.add(str(obj.get('quality_event_key_v946')))
        except Exception as exc:
            append_error(ERROR, 'quality_shadow_final_key_load', exc)
    _QUALITY_FINAL_KEYS_CACHE=keys
    return keys


def _quality_append_final(row: Dict[str, Any]) -> bool:
    key=str(row.get('quality_event_key_v946') or '')
    if not key:
        raise ValueError('quality_event_key_v946 missing on final append')
    keys=_quality_load_final_keys()
    if key in keys:
        return False
    QUALITY_SHADOW_LEDGER.parent.mkdir(parents=True, exist_ok=True)
    with QUALITY_SHADOW_LEDGER.open('a', encoding='utf-8') as handle:
        handle.write(json.dumps(row, ensure_ascii=False, separators=(',', ':'), default=str) + '\n')
        handle.flush()
        os.fsync(handle.fileno())
    keys.add(key)
    return True


def _quality_rotate_ledger(nowv: float) -> Dict[str, Any]:
    if not QUALITY_SHADOW_LEDGER.exists() or QUALITY_SHADOW_LEDGER.stat().st_size <= QUALITY_SHADOW_LEDGER_MAX_BYTES:
        return {'rotated':False,'moved_rows':0,'archive_file':None}
    lines=QUALITY_SHADOW_LEDGER.read_text(encoding='utf-8',errors='ignore').splitlines()
    keep=max(1,min(QUALITY_SHADOW_LEDGER_KEEP_LINES,len(lines)))
    moved=lines[:-keep]; remain=lines[-keep:]
    if not moved:
        return {'rotated':False,'moved_rows':0,'archive_file':None}
    QUALITY_SHADOW_ARCHIVE.mkdir(parents=True,exist_ok=True)
    stamp=time.strftime('%Y%m%d_%H%M%S',time.localtime(nowv))
    archive=QUALITY_SHADOW_ARCHIVE/f'quality_shadow_result_{stamp}.jsonl.gz'
    with gzip.open(archive,'wt',encoding='utf-8',compresslevel=6) as handle:
        for line in moved: handle.write(line+'\n')
    tmp=QUALITY_SHADOW_LEDGER.with_suffix('.jsonl.tmp')
    tmp.write_text('\n'.join(remain)+'\n',encoding='utf-8')
    os.replace(tmp,QUALITY_SHADOW_LEDGER)
    return {'rotated':True,'moved_rows':len(moved),'archive_file':archive.name}


def _quality_percentile(values: List[float], q: float) -> Optional[float]:
    vals=sorted(float(v) for v in values if isinstance(v,(int,float)))
    if not vals: return None
    pos=(len(vals)-1)*max(0.0,min(1.0,float(q)))
    lo=int(pos); hi=min(len(vals)-1,lo+1); frac=pos-lo
    return vals[lo]*(1.0-frac)+vals[hi]*frac


def _quality_metric_stats(vals: List[float], peaks: List[float], troughs: List[float], givebacks: List[float]) -> Dict[str, Any]:
    if not vals: return {}
    return {
        'n':len(vals),
        'avg_pct':round(sum(vals)/len(vals),4),
        'median_pct':round(_quality_percentile(vals,0.50),4),
        'p10_pct':round(_quality_percentile(vals,0.10),4),
        'p90_pct':round(_quality_percentile(vals,0.90),4),
        'positive_0_1_count':sum(1 for v in vals if v>=0.10),
        'negative_0_1_count':sum(1 for v in vals if v<=-0.10),
        'avg_max_pct':round(sum(peaks)/len(peaks),4) if peaks else None,
        'avg_min_pct':round(sum(troughs)/len(troughs),4) if troughs else None,
        'avg_giveback_pct':round(sum(givebacks)/len(givebacks),4) if givebacks else None,
    }


def _quality_summary_stats(rows: List[Dict[str, Any]]) -> Dict[str, Any]:
    out: Dict[str, Any] = {}
    by_cohort: Dict[str, List[Dict[str, Any]]] = {}
    for row in rows:
        by_cohort.setdefault(str(row.get('cohort') or 'unknown'), []).append(row)
    for cohort, cohort_rows in by_cohort.items():
        item: Dict[str, Any] = {'tracked': len(cohort_rows)}
        occurrence_first: Dict[str, Dict[str, Any]] = {}
        for row in cohort_rows:
            occ=str(row.get('hot_watch_occurrence_key_v945') or '').strip()
            if not occ: continue
            current=occurrence_first.get(occ)
            if current is None or (_quality_optional_num(row.get('first_seen_ts')) or 0.0) < (_quality_optional_num(current.get('first_seen_ts')) or 0.0):
                occurrence_first[occ]=row
        item['unique_hot_occurrences']=len(occurrence_first)
        for label, _ in QUALITY_SHADOW_HORIZONS:
            vals=[]; peaks=[]; troughs=[]; givebacks=[]
            for row in cohort_rows:
                sample=(row.get('samples') or {}).get(label) if isinstance(row.get('samples'), dict) else None
                if not isinstance(sample, dict): continue
                v=_quality_optional_num(sample.get('pct')); p=_quality_optional_num(sample.get('max_pct')); t=_quality_optional_num(sample.get('min_pct')); g=_quality_optional_num(sample.get('giveback_pct'))
                if v is not None: vals.append(v)
                if p is not None: peaks.append(p)
                if t is not None: troughs.append(t)
                if g is not None: givebacks.append(g)
            stats=_quality_metric_stats(vals,peaks,troughs,givebacks)
            if stats: item[label]=stats
            occ_vals=[]; occ_peaks=[]; occ_troughs=[]; occ_givebacks=[]
            for row in occurrence_first.values():
                sample=(row.get('samples') or {}).get(label) if isinstance(row.get('samples'),dict) else None
                if not isinstance(sample,dict): continue
                v=_quality_optional_num(sample.get('pct')); p=_quality_optional_num(sample.get('max_pct')); t=_quality_optional_num(sample.get('min_pct')); g=_quality_optional_num(sample.get('giveback_pct'))
                if v is not None: occ_vals.append(v)
                if p is not None: occ_peaks.append(p)
                if t is not None: occ_troughs.append(t)
                if g is not None: occ_givebacks.append(g)
            occ_stats=_quality_metric_stats(occ_vals,occ_peaks,occ_troughs,occ_givebacks)
            if occ_stats: item[label+'_occurrence']=occ_stats
        out[cohort] = item
    return out



def _late_num(value: Any) -> Optional[float]:
    return _quality_optional_num(value)


def _late_nested_values(row: Dict[str, Any]) -> List[Dict[str, Any]]:
    out=[row]
    for key in ('paper_timing_spine_v940','quality_evidence_v938','quality_evidence_v936','entry_diagnostics'):
        obj=row.get(key) if isinstance(row,dict) else None
        if isinstance(obj,dict): out.append(obj)
    diag=row.get('entry_diagnostics') if isinstance(row,dict) and isinstance(row.get('entry_diagnostics'),dict) else {}
    for key in ('paper_timing_spine_v940','quality_evidence_v938','quality_evidence_v936'):
        obj=diag.get(key) if isinstance(diag,dict) else None
        if isinstance(obj,dict): out.append(obj)
    return out


def _late_first(row: Dict[str, Any], keys: tuple[str,...]) -> Any:
    for obj in _late_nested_values(row):
        for key in keys:
            value=obj.get(key)
            if value not in (None,'',[],{}): return value
    return None


def _late_stage_stats(values: List[float]) -> Dict[str, Any]:
    vals=[float(v) for v in values if isinstance(v,(int,float)) and v>=0]
    if not vals: return {'n':0}
    return {
        'n':len(vals),'avg_sec':round(sum(vals)/len(vals),3),'median_sec':round(_quality_percentile(vals,0.50),3),
        'p90_sec':round(_quality_percentile(vals,0.90),3),'max_sec':round(max(vals),3),
        'gt60_count':sum(1 for v in vals if v>=60.0),'gt180_count':sum(1 for v in vals if v>=180.0),
    }


def _late_outcome_quartiles(rows: List[Dict[str, Any]], delay_key: str, sample_label: str='10m') -> Dict[str, Any]:
    pairs=[]
    for rec in rows:
        delay=_late_num((rec.get('initial_metrics') or {}).get(delay_key) if isinstance(rec.get('initial_metrics'),dict) else None)
        sample=(rec.get('samples') or {}).get(sample_label) if isinstance(rec.get('samples'),dict) else None
        pct=_late_num(sample.get('pct')) if isinstance(sample,dict) else None
        if delay is not None and pct is not None: pairs.append((delay,pct,rec))
    if len(pairs)<4: return {'n':len(pairs),'sample_label':sample_label}
    delays=[x[0] for x in pairs]; q25=_quality_percentile(delays,0.25); q75=_quality_percentile(delays,0.75)
    def bundle(selected):
        vals=[x[1] for x in selected]
        return {'n':len(vals),'avg_pct':round(sum(vals)/len(vals),4) if vals else None,'median_pct':round(_quality_percentile(vals,0.50),4) if vals else None,'positive_0_1_count':sum(1 for v in vals if v>=0.1),'negative_0_1_count':sum(1 for v in vals if v<=-0.1)}
    fast=[x for x in pairs if x[0]<=q25]; slow=[x for x in pairs if x[0]>=q75]
    return {'n':len(pairs),'sample_label':sample_label,'q25_sec':round(q25,3),'q75_sec':round(q75,3),'fast':bundle(fast),'slow':bundle(slow)}


def _late_occurrence_rows(records: List[Dict[str, Any]]) -> List[Dict[str, Any]]:
    by_occ: Dict[str, Dict[str, Any]]={}
    no_occ=[]
    timing_names=('scanner_to_candidate_sec','scanner_to_s2_sec','scanner_to_s1_sec')
    for rec in records:
        occ=str(rec.get('hot_watch_occurrence_key_v945') or '').strip()
        if not occ:
            no_occ.append(rec); continue
        cur=by_occ.get(occ)
        if cur is None:
            by_occ[occ]=dict(rec); continue
        cur_ts=_late_num(cur.get('first_seen_ts')) or 0.0; new_ts=_late_num(rec.get('first_seen_ts')) or 0.0
        if new_ts and (not cur_ts or new_ts<cur_ts):
            base=dict(rec); prior=cur
        else:
            base=cur; prior=rec
        merged=base.get('initial_metrics') if isinstance(base.get('initial_metrics'),dict) else {}
        other=prior.get('initial_metrics') if isinstance(prior.get('initial_metrics'),dict) else {}
        for name in timing_names:
            values=[v for v in (_late_num(merged.get(name)),_late_num(other.get(name))) if v is not None]
            if values: merged[name]=min(values)
        base['initial_metrics']=merged
        by_occ[occ]=base
    return list(by_occ.values())+no_occ


def update_late_path_status(nowv: float, quality_records: List[Dict[str, Any]]) -> Dict[str, Any]:
    """Review-owned latency decomposition. Read-only observation; never used by entry/exit."""
    occurrence_rows=_late_occurrence_rows(quality_records)
    stage_values={'scanner_to_candidate_sec':[],'scanner_to_s2_sec':[],'scanner_to_s1_sec':[],'candidate_to_s2_sec':[],'s2_to_s1_sec':[]}
    samples=[]
    for rec in occurrence_rows:
        metrics=rec.get('initial_metrics') if isinstance(rec.get('initial_metrics'),dict) else {}
        c=_late_num(metrics.get('scanner_to_candidate_sec')); s2=_late_num(metrics.get('scanner_to_s2_sec')); s1=_late_num(metrics.get('scanner_to_s1_sec'))
        if c is not None: stage_values['scanner_to_candidate_sec'].append(c)
        if s2 is not None: stage_values['scanner_to_s2_sec'].append(s2)
        if s1 is not None: stage_values['scanner_to_s1_sec'].append(s1)
        if c is not None and s2 is not None and s2>=c: stage_values['candidate_to_s2_sec'].append(s2-c)
        if s2 is not None and s1 is not None and s1>=s2: stage_values['s2_to_s1_sec'].append(s1-s2)
        if any(v is not None and v>=60 for v in (c,s2,s1)):
            samples.append({'ticker':rec.get('ticker'),'occurrence_key':rec.get('hot_watch_occurrence_key_v945'),'scanner_to_candidate_sec':c,'scanner_to_s2_sec':s2,'scanner_to_s1_sec':s1,'cohort':rec.get('cohort'),'m10_pct':_late_num(((rec.get('samples') or {}).get('10m') or {}).get('pct')) if isinstance(rec.get('samples'),dict) else None})
    decision_obj=load_json(PAPER_DECISION_STATE,{}) or {}
    decision_records=decision_obj.get('records') if isinstance(decision_obj,dict) and isinstance(decision_obj.get('records'),dict) else {}
    paper_values={'first_to_open_sec':[],'s1_to_selected_sec':[],'trigger_to_selected_sec':[],'selected_to_open_sec':[],'trigger_to_open_sec':[]}
    for raw in decision_records.values():
        if not isinstance(raw,dict): continue
        mappings={
            'first_to_open_sec':('first_to_open_delay_sec','first_to_paper_delay_sec'),
            's1_to_selected_sec':('s1_to_selected_delay_sec',),
            'trigger_to_selected_sec':('trigger_to_selected_delay_sec',),
            'selected_to_open_sec':('selected_to_open_delay_sec','selected_delay_sec'),
            'trigger_to_open_sec':('trigger_to_open_delay_sec',),
        }
        for name,keys in mappings.items():
            value=_late_num(_late_first(raw,keys))
            if value is not None and value>=0: paper_values[name].append(value)
    stages={name:_late_stage_stats(vals) for name,vals in stage_values.items()}
    paper={name:_late_stage_stats(vals) for name,vals in paper_values.items()}
    outcome={name:_late_outcome_quartiles(occurrence_rows,name,'10m') for name in ('scanner_to_candidate_sec','scanner_to_s2_sec','scanner_to_s1_sec')}
    bottlenecks=[]
    for name,stats in stages.items():
        if stats.get('n'):
            bottlenecks.append({'stage':name,**stats})
    bottlenecks.sort(key=lambda x:(x.get('p90_sec') or 0.0,x.get('max_sec') or 0.0),reverse=True)
    status={
        'schema':'late_path_status_v947','version':'review_worker_v0.948','build':'late_exact_stage_decomposition_v947_2026-06-19','state':'ACTIVE',
        'updated_ts':nowv,'updated_text':now_text(nowv),'quality_exact_records':len(quality_records),'occurrence_normalized_records':len(occurrence_rows),
        'stages':stages,'paper_stages':paper,'outcome_quartiles_10m':outcome,'bottleneck_order':bottlenecks[:5],
        'slow_samples':sorted(samples,key=lambda x:max([v for v in (x.get('scanner_to_candidate_sec'),x.get('scanner_to_s2_sec'),x.get('scanner_to_s1_sec')) if isinstance(v,(int,float))] or [0]),reverse=True)[:8],
        'identity_policy':'hot occurrence normalized for latency distribution; exact candidate records remain source evidence; ticker never joins final results',
        'policy':'observation only; no S grade, trigger, entry, exit, protection or cost criteria change',
        'conditions_changed':False,'trigger_changed':False,'paper_open_changed':False,'exit_changed':False,'auto_buy':False,
    }
    save_json(LATE_PATH_STATUS,status)
    return status


def update_quality_shadow(nowv: float, fmap: Dict[str, Dict[str, Any]], ofmap: Dict[str, Dict[str, Any]]) -> Dict[str, Any]:
    """Observe current gate cohorts and later price paths without affecting any trade decision."""
    source_rows = [row for row in read_jsonl(PAPER_LATEST, max_lines=0) if isinstance(row, dict)]
    state_obj = load_json(QUALITY_SHADOW_STATE, {}) or {}
    records = state_obj.get('records') if isinstance(state_obj, dict) and isinstance(state_obj.get('records'), dict) else {}
    records = {str(k): dict(v) for k, v in records.items() if isinstance(v, dict)}
    exact_ready=0; exact_missing=0; created=0; finalized=0; source_seen=set(); reason_counts=Counter(); cohort_counts=Counter()

    for row in source_rows:
        exact_key, identity_mode = _quality_exact_identity(row)
        if not exact_key:
            exact_missing += 1
            continue
        exact_ready += 1; source_seen.add(exact_key)
        ticker = ticker_norm(row.get('ticker') or row.get('market') or row.get('symbol'))
        gate = _quality_gate(row); reasons = _quality_block_reasons(row, gate)
        hard_pass = bool(gate.get('hard_pass'))
        cohort = _quality_cohort(hard_pass, reasons)
        for reason in reasons: reason_counts[reason] += 1
        cohort_counts[cohort] += 1
        current = _current_price(ticker, fmap, ofmap) or _quality_optional_num(row.get('current_price'), row.get('entry_price'), row.get('price'), row.get('detected_price')) or 0.0
        rec = records.get(exact_key)
        if rec is None:
            if current <= 0:
                continue
            rec = {
                'schema':'quality_shadow_state_row_v947','version':'review_worker_v0.948','build':'quality_exact_gate_path_retention_v947_2026-06-19',
                'quality_event_key_v946':exact_key,'identity_mode_v946':identity_mode,'entry_build_key':row.get('entry_build_key'),'minimal_gate_decision_key_v925':row.get('minimal_gate_decision_key_v925'),
                'ticker':ticker,'hot_watch_occurrence_key_v945':str((row.get('hot_watch_timing_v945') or {}).get('hot_watch_occurrence_key_v945') or row.get('hot_watch_occurrence_key_v945') or ''),'first_seen_ts':nowv,'first_seen_text':now_text(nowv),'first_price':current,
                'stage_at_first':str(gate.get('stage') or row.get('s_stage') or row.get('candidate_stage') or '-'),
                'hard_pass_at_first':hard_pass,'ever_hard_pass':hard_pass,'first_pass_ts':nowv if hard_pass else None,'cohort':cohort,'hard_block_reasons':reasons,
                'initial_metrics':_quality_initial_metrics(row,gate),'samples':{},'max_pct':0.0,'min_pct':0.0,'giveback_pct':0.0,
                'last_price':current,'last_seen_ts':nowv,'last_candidate_seen_ts':nowv,'final_appended':False,
                'identity_policy':'entry_build_key exact only; ticker is price-source lookup only; no ticker result join',
                'observation_only':True,'used_for_entry_gate':False,'used_for_exit':False,
            }
            records[exact_key]=rec; created += 1
        else:
            rec['last_candidate_seen_ts']=nowv
            rec['last_hard_pass']=hard_pass
            if hard_pass and not rec.get('ever_hard_pass'):
                rec['ever_hard_pass']=True; rec['first_pass_ts']=nowv
            rec['last_stage']=str(gate.get('stage') or row.get('s_stage') or row.get('candidate_stage') or rec.get('last_stage') or '-')
            rec['last_hard_block_reasons']=reasons
            hot_key=str((row.get('hot_watch_timing_v945') or {}).get('hot_watch_occurrence_key_v945') or row.get('hot_watch_occurrence_key_v945') or '')
            if hot_key and not rec.get('hot_watch_occurrence_key_v945'): rec['hot_watch_occurrence_key_v945']=hot_key
            existing_metrics=rec.get('initial_metrics') if isinstance(rec.get('initial_metrics'),dict) else {}
            fresh_metrics=_quality_initial_metrics(row,gate)
            for metric_name,metric_value in fresh_metrics.items():
                if metric_value is not None and existing_metrics.get(metric_name) is None:
                    existing_metrics[metric_name]=metric_value
            rec['initial_metrics']=existing_metrics

    for exact_key, rec in list(records.items()):
        ticker=ticker_norm(rec.get('ticker'))
        current=_current_price(ticker,fmap,ofmap)
        base=_quality_optional_num(rec.get('first_price')) or 0.0
        if current > 0 and base > 0:
            pct=round((current-base)/base*100.0,6)
            rec['last_price']=current; rec['last_seen_ts']=nowv; rec['current_pct']=pct
            rec['max_pct']=max(_quality_optional_num(rec.get('max_pct')) or pct,pct)
            rec['min_pct']=min(_quality_optional_num(rec.get('min_pct')) or pct,pct)
            rec['giveback_pct']=round((_quality_optional_num(rec.get('max_pct')) or pct)-pct,6)
            elapsed=max(0.0,nowv-(_quality_optional_num(rec.get('first_seen_ts')) or nowv)); rec['age_sec']=round(elapsed,3)
            samples=rec.get('samples') if isinstance(rec.get('samples'),dict) else {}
            for label,sec in QUALITY_SHADOW_HORIZONS:
                if elapsed >= sec and label not in samples:
                    samples[label]={'ts':nowv,'text':now_text(nowv),'price':current,'pct':pct,'max_pct':rec.get('max_pct'),'min_pct':rec.get('min_pct'),'giveback_pct':rec.get('giveback_pct')}
            rec['samples']=samples
            if elapsed >= QUALITY_SHADOW_HORIZONS[-1][1] and not rec.get('final_appended'):
                final=dict(rec); final['schema']='quality_shadow_result_v947'; final['finalized_ts']=nowv; final['finalized_text']=now_text(nowv)
                appended=_quality_append_final(final); rec['final_appended']=True; rec['finalized_ts']=nowv
                if appended: finalized += 1
        records[exact_key]=rec

    # Time-bounded retention: unfinished exact events must survive the full 60m horizon.
    # The old 1,500-row slice evicted unfinished records before 60m in a busy market.
    keep=[]; stale_unfinished_pruned=0; finalized_pruned=0; safety_pruned=0; premature_unfinished_pruned=0
    final_horizon=QUALITY_SHADOW_HORIZONS[-1][1]
    for key,rec in records.items():
        age=max(0.0,nowv-(_quality_optional_num(rec.get('first_seen_ts')) or nowv))
        if rec.get('final_appended'):
            if age <= final_horizon + QUALITY_SHADOW_FINAL_GRACE_SEC:
                keep.append((key,rec))
            else:
                finalized_pruned += 1
        elif age <= QUALITY_SHADOW_RETENTION_SEC:
            keep.append((key,rec))
        else:
            stale_unfinished_pruned += 1
    keep.sort(key=lambda kv:_quality_optional_num(kv[1].get('first_seen_ts')) or 0.0, reverse=True)
    if len(keep) > QUALITY_SHADOW_SAFETY_MAX_RECORDS:
        # Safety ceiling is intentionally far above expected 3h flow. Prefer unfinished/new rows.
        keep.sort(key=lambda kv:(bool(kv[1].get('final_appended')), -(_quality_optional_num(kv[1].get('first_seen_ts')) or 0.0)))
        dropped=keep[QUALITY_SHADOW_SAFETY_MAX_RECORDS:]
        safety_pruned=len(dropped)
        premature_unfinished_pruned=sum(1 for _key,rec in dropped if not rec.get('final_appended') and max(0.0,nowv-(_quality_optional_num(rec.get('first_seen_ts')) or nowv))<final_horizon)
        keep=keep[:QUALITY_SHADOW_SAFETY_MAX_RECORDS]
    records=dict(keep)
    rows=list(records.values()); cohorts=_quality_summary_stats(rows)
    samples=sorted(rows,key=lambda r:_quality_optional_num(r.get('max_pct')) or -999.0,reverse=True)[:4]
    samples += sorted(rows,key=lambda r:_quality_optional_num(r.get('min_pct')) or 999.0)[:4]
    compact_samples=[]; seen=set()
    for rec in samples:
        key=str(rec.get('quality_event_key_v946') or '')
        if not key or key in seen: continue
        seen.add(key)
        compact_samples.append({k:rec.get(k) for k in ('ticker','quality_event_key_v946','identity_mode_v946','entry_build_key','minimal_gate_decision_key_v925','cohort','hard_block_reasons','age_sec','current_pct','max_pct','min_pct','giveback_pct','samples')})
    rotation=_quality_rotate_ledger(nowv)
    ledger_rows=len(_quality_load_final_keys()); ledger_bytes=0; archive_files=0; archive_bytes=0
    if QUALITY_SHADOW_LEDGER.exists():
        try:
            ledger_bytes=QUALITY_SHADOW_LEDGER.stat().st_size
        except Exception as exc:
            append_error(ERROR, 'quality_shadow_ledger_stats', exc)
            ledger_bytes=0
    if QUALITY_SHADOW_ARCHIVE.exists():
        try:
            archives=[path for path in QUALITY_SHADOW_ARCHIVE.glob('quality_shadow_result_*.jsonl.gz') if path.is_file()]
            archive_files=len(archives); archive_bytes=sum(path.stat().st_size for path in archives)
        except Exception as exc:
            append_error(ERROR, 'quality_shadow_archive_stats', exc)
    status={
        'schema':'quality_shadow_status_v947','version':'review_worker_v0.948','build':'quality_exact_gate_path_retention_v947_2026-06-19',
        'state':'ACTIVE','updated_ts':nowv,'updated_text':now_text(nowv),'candidate_rows':len(source_rows),
        'exact_key_ready':exact_ready,'exact_key_missing':exact_missing,'tracked_records':len(rows),'new_records_this_cycle':created,
        'finalized_this_cycle':finalized,'final_ledger_rows':ledger_rows,'final_ledger_bytes':ledger_bytes,'rotation':rotation,'archive_files':archive_files,'archive_bytes':archive_bytes,
        'current_cohort_counts':dict(cohort_counts),'current_block_reason_counts':dict(reason_counts),'cohorts':cohorts,'samples':compact_samples,
        'horizons':[label for label,_ in QUALITY_SHADOW_HORIZONS],
        'policy':'review-owned exact candidate gate cohort -> 1/3/5/10/20/60m path with time-bounded unfinished retention; no trade criteria/trigger/open/exit change',
        'identity_policy':'minimal gate decision exact first; candidate entry_build exact second; ticker is price lookup, never final result join',
        'oldest_unfinished_age_sec':round(max([max(0.0,nowv-(_quality_optional_num(r.get('first_seen_ts')) or nowv)) for r in rows if not r.get('final_appended')] or [0.0]),3),'unfinished_records':sum(1 for r in rows if not r.get('final_appended')),'stale_unfinished_pruned':stale_unfinished_pruned,'finalized_pruned':finalized_pruned,'safety_pruned':safety_pruned,'premature_unfinished_pruned':premature_unfinished_pruned,'retention_policy':'unfinished kept by time through 60m; finalized rows move to fsync ledger; count ceiling is safety-only','conditions_changed':False,'trigger_changed':False,'paper_open_changed':False,'exit_changed':False,'auto_buy':False,
    }
    save_json(QUALITY_SHADOW_STATE,{'schema':'quality_shadow_state_v947','version':'review_worker_v0.948','build':status['build'],'updated_ts':nowv,'updated_text':now_text(nowv),'final_ledger_rows':ledger_rows,'records':records})
    save_json(QUALITY_SHADOW_STATUS,status)
    return status



def _sample_price_unit(price: float) -> float:
    if price >= 100000: return 100.0
    if price >= 10000: return 10.0
    if price >= 1000: return 1.0
    if price >= 100: return 0.1
    if price >= 10: return 0.01
    if price >= 1: return 0.001
    return 0.00001


def _sample_trimmed_mean(values: List[float], trim_ratio: float=0.05) -> Optional[float]:
    vals=sorted(float(v) for v in values if isinstance(v,(int,float)))
    if not vals: return None
    cut=int(len(vals)*trim_ratio)
    core=vals[cut:len(vals)-cut] if cut>0 and len(vals)>cut*2 else vals
    return sum(core)/len(core) if core else None


def _sample_result_rows(records: List[Dict[str,Any]], horizon: str) -> List[Dict[str,Any]]:
    out=[]
    for rec in records:
        sample=(rec.get('samples') or {}).get(horizon) if isinstance(rec.get('samples'),dict) else None
        if not isinstance(sample,dict): continue
        pctv=_quality_optional_num(sample.get('pct'))
        if pctv is None: continue
        metrics=rec.get('initial_metrics') if isinstance(rec.get('initial_metrics'),dict) else {}
        price=_quality_optional_num(rec.get('first_price'),metrics.get('first_price')) or 0.0
        tick_pct=_sample_price_unit(price)/price*100.0 if price>0 else 0.0
        spread=_quality_optional_num(metrics.get('spread_pct'))
        slip=_quality_optional_num(metrics.get('confirmed_slippage_pct'))
        source=str(metrics.get('confirmed_slippage_source') or '').lower()
        slip_confirmed=slip is not None and any(x in source for x in ('confirmed','exchange','average_fill','paper_reference','best_ask_reference')) and 'derived_from_spread' not in source
        cost=(spread or 0.0)+(slip if slip_confirmed else 0.0)
        out.append({'ticker':ticker_norm(rec.get('ticker')),'cohort':str(rec.get('cohort') or 'unknown'),'pct':pctv,'max_pct':_quality_optional_num(sample.get('max_pct')),'min_pct':_quality_optional_num(sample.get('min_pct')),'giveback_pct':_quality_optional_num(sample.get('giveback_pct')),'price':price,'tick_pct':tick_pct,'distortion':bool(tick_pct>=0.50 or abs(pctv)>=15.0),'spread_pct':spread,'confirmed_slippage_pct':slip if slip_confirmed else None,'cost_adjusted_pct':pctv-cost,'market_regime':metrics.get('market_regime'),'market_strength':_quality_optional_num(metrics.get('market_strength')),'volume_ratio':_quality_optional_num(metrics.get('volume_ratio')),'scanner_to_s2_sec':_quality_optional_num(metrics.get('scanner_to_s2_sec')),'scanner_to_s1_sec':_quality_optional_num(metrics.get('scanner_to_s1_sec')),'event_key':rec.get('quality_event_key_v946'),'occurrence':rec.get('hot_watch_occurrence_key_v945')})
    return out


def _sample_group_stats(rows: List[Dict[str,Any]]) -> Dict[str,Any]:
    vals=[float(r['pct']) for r in rows if isinstance(r.get('pct'),(int,float))]
    clean=[float(r['pct']) for r in rows if isinstance(r.get('pct'),(int,float)) and not r.get('distortion')]
    costs=[float(r['cost_adjusted_pct']) for r in rows if isinstance(r.get('cost_adjusted_pct'),(int,float))]
    tickers=Counter(str(r.get('ticker') or '-') for r in rows)
    unique_occ={str(r.get('occurrence')) for r in rows if str(r.get('occurrence') or '').strip()}
    unique_ticker_rows=[]
    seen=set()
    for r in sorted(rows,key=lambda x:str(x.get('event_key') or '')):
        t=str(r.get('ticker') or '')
        if t and t not in seen: seen.add(t); unique_ticker_rows.append(r)
    unique_vals=[float(r['pct']) for r in unique_ticker_rows if isinstance(r.get('pct'),(int,float))]
    top_share=(tickers.most_common(1)[0][1]/len(rows)) if rows and tickers else 0.0
    trust='판단대기'
    if len(clean)>=30 and len(tickers)>=20 and top_share<=0.20: trust='참고가능'
    if len(clean)>=100 and len(tickers)>=40 and top_share<=0.12: trust='신뢰권'
    return {'n':len(vals),'unique_tickers':len(tickers),'unique_occurrences':len(unique_occ),'raw_avg_pct':round(sum(vals)/len(vals),4) if vals else None,'median_pct':round(_quality_percentile(vals,0.5),4) if vals else None,'trimmed_avg_pct':round(_sample_trimmed_mean(vals) or 0.0,4) if vals else None,'distortion_excluded_n':len(clean),'distortion_excluded_avg_pct':round(sum(clean)/len(clean),4) if clean else None,'unique_ticker_avg_pct':round(sum(unique_vals)/len(unique_vals),4) if unique_vals else None,'cost_adjusted_avg_pct':round(sum(costs)/len(costs),4) if costs else None,'distortion_count':sum(1 for r in rows if r.get('distortion')),'top_ticker_share_pct':round(top_share*100.0,2),'top_tickers':[{'ticker':k,'n':v} for k,v in tickers.most_common(5)],'positive_0_1':sum(1 for v in vals if v>=0.1),'negative_0_1':sum(1 for v in vals if v<=-0.1),'trust':trust}


def update_sample_board(nowv: float, records: List[Dict[str,Any]]) -> Dict[str,Any]:
    cohorts=('s1_pass','frozen_trigger_not_reached','risk_reward_below_minimum','target_room_below_minimum','coherent_structure_plan_incomplete','actual_structural_invalid_missing','next_structural_target_missing','candidate_sources_not_fresh','untradable_spread','untradable_liquidity','other_blocked')
    horizon_results={}
    for horizon in ('10m','60m'):
        rows=_sample_result_rows(records,horizon)
        by={c:_sample_group_stats([r for r in rows if r.get('cohort')==c]) for c in cohorts}
        by={k:v for k,v in by.items() if v.get('n')}
        narrow=_sample_group_stats([r for r in rows if (_quality_optional_num(r.get('spread_pct')) or 999)<0.20])
        wide=_sample_group_stats([r for r in rows if (_quality_optional_num(r.get('spread_pct')) or 0)>=0.20])
        high_vol=_sample_group_stats([r for r in rows if (_quality_optional_num(r.get('volume_ratio')) or 0)>=1.2])
        normal_vol=_sample_group_stats([r for r in rows if (_quality_optional_num(r.get('volume_ratio')) or 0)<1.2])
        fast_s2=_sample_group_stats([r for r in rows if (_quality_optional_num(r.get('scanner_to_s2_sec')) is not None and (_quality_optional_num(r.get('scanner_to_s2_sec')) or 0)<=30)])
        slow_s2=_sample_group_stats([r for r in rows if (_quality_optional_num(r.get('scanner_to_s2_sec')) or 0)>120])
        horizon_results[horizon]={'total':_sample_group_stats(rows),'cohorts':by,'market_splits':{'spread_narrow':narrow,'spread_wide':wide,'volume_high':high_vol,'volume_normal':normal_vol,'s2_fast_30s':fast_s2,'s2_slow_120s':slow_s2}}
    status={'schema':'sample_board_status_v948','version':VERSION,'build':BUILD_LABEL,'state':'ACTIVE','updated_ts':nowv,'updated_text':now_text(nowv),'tracked_records':len(records),'horizons':horizon_results,'rules':{'distortion':'tick_pct>=0.50% or abs(return)>=15%','dedup':'raw exact + unique ticker + unique occurrence shown together','cost':'spread + confirmed/reference slippage only; legacy spread-copy excluded','trust':'sample count + unique tickers + concentration'} ,'policy':'observation only; no gate/trigger/open/exit change','trading_rules_changed':False}
    save_json(SAMPLE_BOARD_STATUS,status); return status


def _structure_variant_stats(records: List[Dict[str,Any]], variant: str) -> Dict[str,Any]:
    reached=[]
    for rec in records:
        v=(rec.get('variants') or {}).get(variant) if isinstance(rec.get('variants'),dict) else None
        if isinstance(v,dict) and v.get('reached_ts'): reached.append(v)
    out={'tracked':len(records),'reached':len(reached),'reach_rate_pct':round(len(reached)/len(records)*100.0,2) if records else 0.0}
    for label,_ in SMART_STRUCTURE_HORIZONS:
        vals=[]; peaks=[]; troughs=[]; give=[]
        for v in reached:
            sm=(v.get('samples') or {}).get(label) if isinstance(v.get('samples'),dict) else None
            if not isinstance(sm,dict): continue
            x=_quality_optional_num(sm.get('pct')); p=_quality_optional_num(sm.get('max_pct')); t=_quality_optional_num(sm.get('min_pct')); g=_quality_optional_num(sm.get('giveback_pct'))
            if x is not None: vals.append(x)
            if p is not None: peaks.append(p)
            if t is not None: troughs.append(t)
            if g is not None: give.append(g)
        out[label]=_quality_metric_stats(vals,peaks,troughs,give)
    out['invalid_breach_count']=sum(1 for v in reached if v.get('invalid_breached'))
    out['target_hit_count']=sum(1 for v in reached if v.get('target_hit'))
    return out


def update_smart_structure_shadow(nowv: float, fmap: Dict[str,Dict[str,Any]], ofmap: Dict[str,Dict[str,Any]]) -> Dict[str,Any]:
    source=load_json(SMART_STRUCTURE_CANDIDATES,{}) or {}
    rows=source.get('rows') if isinstance(source,dict) and isinstance(source.get('rows'),list) else []
    state=load_json(SMART_STRUCTURE_STATE,{}) or {}; records=state.get('records') if isinstance(state,dict) and isinstance(state.get('records'),dict) else {}
    records={str(k):dict(v) for k,v in records.items() if isinstance(v,dict)}; new=0
    for row in rows:
        if not isinstance(row,dict): continue
        key=str(row.get('shadow_key') or '').strip(); ticker=ticker_norm(row.get('ticker'))
        if not key or not ticker: continue
        rec=records.get(key)
        ex=row.get('existing') if isinstance(row.get('existing'),dict) else {}; sm=row.get('smart') if isinstance(row.get('smart'),dict) else {}
        if rec is None:
            rec={'schema':'smart_structure_shadow_state_row_v948','key':key,'ticker':ticker,'first_seen_ts':nowv,'first_seen_text':now_text(nowv),'low_price_tick_risk':bool(row.get('low_price_tick_risk')),'dynamic_zone_tolerance_pct':row.get('dynamic_zone_tolerance_pct'),'variants':{},'observation_only':True}; new+=1
        for name,plan in (('existing',ex),('smart',sm)):
            variant=(rec.get('variants') or {}).get(name) if isinstance(rec.get('variants'),dict) else None
            if not isinstance(variant,dict): variant={'trigger':plan.get('trigger'),'invalid':plan.get('invalid'),'target':plan.get('target'),'samples':{},'max_pct':0.0,'min_pct':0.0,'giveback_pct':0.0}
            variants=rec.get('variants') if isinstance(rec.get('variants'),dict) else {}; variants[name]=variant; rec['variants']=variants
        rec['last_seen_ts']=nowv; records[key]=rec
    for key,rec in list(records.items()):
        ticker=ticker_norm(rec.get('ticker')); cur=_current_price(ticker,fmap,ofmap)
        if cur<=0: continue
        for name,v in list((rec.get('variants') or {}).items()):
            if not isinstance(v,dict): continue
            trigger=_quality_optional_num(v.get('trigger')) or 0.0
            if not v.get('reached_ts') and trigger>0 and cur>=trigger*0.999:
                v['reached_ts']=nowv; v['reached_text']=now_text(nowv); v['entry_price']=cur; v['max_pct']=0.0; v['min_pct']=0.0; v['giveback_pct']=0.0
            if v.get('reached_ts') and (_quality_optional_num(v.get('entry_price')) or 0)>0:
                base=float(v['entry_price']); pctv=(cur-base)/base*100.0; v['current_pct']=round(pctv,6); v['max_pct']=max(_quality_optional_num(v.get('max_pct')) or pctv,pctv); v['min_pct']=min(_quality_optional_num(v.get('min_pct')) or pctv,pctv); v['giveback_pct']=round(float(v['max_pct'])-pctv,6)
                invalid=_quality_optional_num(v.get('invalid')); target=_quality_optional_num(v.get('target'))
                if invalid and cur<=invalid*1.001: v['invalid_breached']=True
                if target and cur>=target*0.999: v['target_hit']=True
                elapsed=max(0.0,nowv-float(v['reached_ts'])); samples=v.get('samples') if isinstance(v.get('samples'),dict) else {}
                for label,sec in SMART_STRUCTURE_HORIZONS:
                    if elapsed>=sec and label not in samples: samples[label]={'ts':nowv,'pct':v['current_pct'],'max_pct':v['max_pct'],'min_pct':v['min_pct'],'giveback_pct':v['giveback_pct']}
                v['samples']=samples
            rec['variants'][name]=v
        records[key]=rec
    records={k:v for k,v in records.items() if nowv-(_quality_optional_num(v.get('first_seen_ts')) or nowv)<=3*3600}
    vals=list(records.values()); exstats=_structure_variant_stats(vals,'existing'); smstats=_structure_variant_stats(vals,'smart')
    def delta(label,key='avg_pct'):
        a=((smstats.get(label) or {}).get(key)); b=((exstats.get(label) or {}).get(key)); return round(float(a)-float(b),4) if isinstance(a,(int,float)) and isinstance(b,(int,float)) else None
    status={'schema':'smart_structure_shadow_review_status_v948','version':VERSION,'build':BUILD_LABEL,'state':'ACTIVE' if rows else 'WAITING','updated_ts':nowv,'updated_text':now_text(nowv),'source_rows':len(rows),'tracked_records':len(vals),'new_records_this_cycle':new,'existing':exstats,'smart':smstats,'smart_minus_existing':{'10m_avg_pct':delta('10m'),'60m_avg_pct':delta('60m'),'10m_avg_min_pct':delta('10m','avg_min_pct'),'10m_avg_giveback_pct':delta('10m','avg_giveback_pct')},'low_price_tick_risk_records':sum(1 for r in vals if r.get('low_price_tick_risk')),'policy':'smart zones are review-only; existing v925 lines remain the only trading lines','trading_rules_changed':False}
    save_json(SMART_STRUCTURE_STATE,{'schema':'smart_structure_shadow_state_v948','version':VERSION,'updated_ts':nowv,'records':records}); save_json(SMART_STRUCTURE_STATUS,status); return status



# =============================================================================
# review_worker v0.950: structure discovery, method event, and plan outcome review
# =============================================================================

def _structure_plan_stats(records: List[Dict[str,Any]], method: str) -> Dict[str,Any]:
    rows=[r for r in records if str(r.get('method') or '')==method]
    reached=[r for r in rows if r.get('trigger_reached_ts')]
    state_counts=Counter(str(r.get('structure_state') or 'unknown') for r in rows)
    activation_counts=Counter(str(r.get('trigger_activation_mode') or 'unknown') for r in rows)
    out={'tracked':len(rows),'complete_tracked':sum(1 for r in rows if r.get('source_plan_complete')),'partial_tracked':sum(1 for r in rows if not r.get('source_plan_complete')),'trigger_reached':len(reached),'support_touched':sum(1 for r in rows if r.get('support_touch_count',0)>0),'target_first':sum(1 for r in reached if r.get('first_terminal')=='target'),'invalid_first':sum(1 for r in reached if r.get('first_terminal')=='invalid'),'terminal_unknown':sum(1 for r in reached if r.get('first_terminal') in (None,'','ambiguous')),'weakened_lines':sum(1 for r in rows if r.get('line_weakened')),'role_flip_confirmed':sum(1 for r in rows if r.get('role_flip_confirmed_ts')),'stale_unreached':sum(1 for r in rows if r.get('line_state')=='stale_unreached'),'confirmed_event_started':sum(1 for r in rows if r.get('activation_source')=='confirmed_completed_candle_event_seen_by_review'),'structure_state_counts':dict(state_counts),'activation_mode_counts':dict(activation_counts)}
    for label,_sec in STRUCTURE_LAB_HORIZONS:
        vals=[]; peaks=[]; mins=[]; give=[]; rel=[]
        for r in reached:
            sample_map=r.get('samples'); sm=sample_map.get(label) if isinstance(sample_map,dict) else None
            if not isinstance(sm,dict): continue
            for arr,key in ((vals,'pct'),(peaks,'max_pct'),(mins,'min_pct'),(give,'giveback_pct'),(rel,'relative_to_btc_pct')):
                v=_quality_optional_num(sm.get(key))
                if v is not None: arr.append(v)
        out[label]={'n':len(vals),'avg_pct':round(sum(vals)/len(vals),4) if vals else None,'median_pct':round(_quality_percentile(vals,0.5),4) if vals else None,'avg_max_pct':round(sum(peaks)/len(peaks),4) if peaks else None,'avg_min_pct':round(sum(mins)/len(mins),4) if mins else None,'avg_giveback_pct':round(sum(give)/len(give),4) if give else None,'avg_relative_to_btc_pct':round(sum(rel)/len(rel),4) if rel else None}
    return out


def _structure_missed_stats(records: List[Dict[str,Any]]) -> Dict[str,Any]:
    rows=list(records); reasons=Counter(str(r.get('reason') or 'unknown') for r in rows); sources=Counter(str(r.get('source') or 'unknown') for r in rows)
    discovery=Counter(); incomplete=Counter(); method_states={m:Counter() for m in ('A_SWING','B_REACTION_ZONE','C_BREAK_RETEST','D_SUPPLY_DEMAND','E_VOLUME_PROFILE')}
    for r in rows:
        diagnostics=r.get('method_diagnostics') if isinstance(r.get('method_diagnostics'),dict) else {}
        for method,diag in diagnostics.items():
            if method not in method_states or not isinstance(diag,dict): continue
            method_states[method][str(diag.get('structure_state') or 'unknown')]+=1
            discovery_reasons=diag.get('discovery_reasons') if isinstance(diag.get('discovery_reasons'),list) else []
            incomplete_reasons=diag.get('incomplete_reasons') if isinstance(diag.get('incomplete_reasons'),list) else []
            for reason in discovery_reasons: discovery[f'{method}:{reason}']+=1
            for reason in incomplete_reasons: incomplete[f'{method}:{reason}']+=1
    out={'tracked':len(rows),'reason_top':[{'reason':k,'count':v} for k,v in reasons.most_common(15)],'source_counts':dict(sources),'method_discovery_reason_top':[{'reason':k,'count':v} for k,v in discovery.most_common(20)],'method_incomplete_reason_top':[{'reason':k,'count':v} for k,v in incomplete.most_common(20)],'method_state_counts':{m:dict(v) for m,v in method_states.items()},'later_structure_created':sum(1 for r in rows if r.get('later_structure_created_ts')),'later_complete_plan_created':sum(1 for r in rows if r.get('later_complete_plan_created_ts'))}
    for label,_sec in STRUCTURE_LAB_HORIZONS:
        vals=[]; peaks=[]; mins=[]
        for r in rows:
            sample_map=r.get('samples'); sm=sample_map.get(label) if isinstance(sample_map,dict) else None
            if not isinstance(sm,dict): continue
            v=_quality_optional_num(sm.get('pct')); p=_quality_optional_num(sm.get('max_pct')); m=_quality_optional_num(sm.get('min_pct'))
            if v is not None: vals.append(v)
            if p is not None: peaks.append(p)
            if m is not None: mins.append(m)
        out[label]={'n':len(vals),'avg_pct':round(sum(vals)/len(vals),4) if vals else None,'median_pct':round(_quality_percentile(vals,0.5),4) if vals else None,'avg_max_pct':round(sum(peaks)/len(peaks),4) if peaks else None,'avg_min_pct':round(sum(mins)/len(mins),4) if mins else None,'rise_0_5_count':sum(1 for v in peaks if v>=0.5),'rise_1_0_count':sum(1 for v in peaks if v>=1.0)}
    return out


def _structure_zone_bounds(zone: Any) -> tuple[Optional[float],Optional[float]]:
    z=zone if isinstance(zone,dict) else {}
    low=_quality_optional_num(z.get('low_raw'),z.get('low')); high=_quality_optional_num(z.get('high_raw'),z.get('high'))
    if low is None or high is None: return None,None
    return min(low,high),max(low,high)


def update_structure_laboratory(nowv: float, fmap: Dict[str,Dict[str,Any]], ofmap: Dict[str,Dict[str,Any]]) -> tuple[Dict[str,Any],Dict[str,Any]]:
    source_raw=load_json(STRUCTURE_LAB_CANDIDATES,{}); source=source_raw if isinstance(source_raw,dict) else {}
    lab_rows=source.get('rows') if isinstance(source.get('rows'),list) else []; missed_rows=source.get('missed_rows') if isinstance(source.get('missed_rows'),list) else []
    state_raw=load_json(STRUCTURE_LAB_STATE,{}); state=state_raw if isinstance(state_raw,dict) else {}; records_raw=state.get('records'); records=records_raw if isinstance(records_raw,dict) else {}; records={str(k):dict(v) for k,v in records.items() if isinstance(v,dict)}
    missed_state_raw=load_json(STRUCTURE_MISSED_STATE,{}); missed_state=missed_state_raw if isinstance(missed_state_raw,dict) else {}; missed_raw=missed_state.get('records'); missed=missed_raw if isinstance(missed_raw,dict) else {}; missed={str(k):dict(v) for k,v in missed.items() if isinstance(v,dict)}
    new_plans=0; new_missed=0; current_found_by_ticker={}; current_complete_by_ticker={}; btc_now=_current_price('BTC',fmap,ofmap)
    for lab in lab_rows:
        if not isinstance(lab,dict): continue
        ticker=ticker_norm(lab.get('ticker')); methods=lab.get('methods') if isinstance(lab.get('methods'),dict) else {}
        found_methods=lab.get('found_methods') if isinstance(lab.get('found_methods'),list) else []; complete_methods=lab.get('complete_methods') if isinstance(lab.get('complete_methods'),list) else []
        current_found_by_ticker[ticker]=set(str(x) for x in found_methods); current_complete_by_ticker[ticker]=set(str(x) for x in complete_methods)
        for method,plan in methods.items():
            if not isinstance(plan,dict) or not plan.get('trackable') or not plan.get('structure_found'): continue
            key=str(plan.get('plan_key') or '').strip()
            if not key or not ticker: continue
            rec=records.get(key)
            if rec is None:
                start=_quality_optional_num(plan.get('current_price')) or _current_price(ticker,fmap,ofmap)
                rec={'schema':'structure_lab_state_row_v951','plan_key':key,'method':str(method),'method_label':plan.get('method_label'),'ticker':ticker,'candidate_exact_identity':plan.get('candidate_exact_identity'),'first_seen_ts':nowv,'first_seen_text':now_text(nowv),'first_price':start,'structure_state':plan.get('structure_state'),'source_plan_complete':bool(plan.get('plan_complete')),'component_status':plan.get('component_status'),'discovery_reasons':plan.get('discovery_reasons'),'incomplete_reasons':plan.get('incomplete_reasons'),'trigger_activation_mode':plan.get('trigger_activation_mode'),'trigger_source_state':plan.get('trigger_source_state'),'trigger':plan.get('trigger'),'invalid':plan.get('invalid'),'target':plan.get('target'),'support_zone':plan.get('support_zone'),'trigger_zone':plan.get('trigger_zone'),'target_zone':plan.get('target_zone'),'anchor_zone':plan.get('anchor_zone'),'primary_tf':plan.get('primary_tf'),'evidence':plan.get('evidence'),'method_contract_version':plan.get('method_contract_version'),'market_context':plan.get('market_context'),'execution_snapshot':plan.get('execution_snapshot'),'tick_pct':plan.get('tick_pct'),'low_price_tick_risk':plan.get('low_price_tick_risk'),'source_event_ts':plan.get('event_source_ts'),'source_event_price':plan.get('event_source_price'),'line_state':'new','support_touch_count':0,'trigger_retest_count':0,'samples':{},'max_pct':0.0,'min_pct':0.0,'giveback_pct':0.0,'btc_start_price':btc_now or None,'observation_only':True}; new_plans+=1
                if plan.get('trigger_already_reached_on_source'):
                    rec['trigger_reached_ts']=nowv; rec['trigger_reached_text']=now_text(nowv); rec['entry_price']=start; rec['line_state']='confirmed_event_detected'; rec['activation_source']='confirmed_completed_candle_event_seen_by_review'
            rec['last_source_seen_ts']=nowv; rec['candidate_exact_identity_last']=plan.get('candidate_exact_identity'); rec['source_plan_complete']=bool(plan.get('plan_complete')); rec['structure_state']=plan.get('structure_state'); rec['component_status']=plan.get('component_status'); rec['incomplete_reasons']=plan.get('incomplete_reasons'); rec['trigger_source_state']=plan.get('trigger_source_state'); records[key]=rec
    for key,rec in list(records.items()):
        ticker=ticker_norm(rec.get('ticker')); cur=_current_price(ticker,fmap,ofmap)
        if cur<=0: continue
        age=max(0.0,nowv-float(rec.get('first_seen_ts') or nowv)); rec['line_age_sec']=round(age,1)
        tf=str(rec.get('primary_tf') or 'm1'); stale_limit={'h4':14400.0,'h2':10800.0,'h1':7200.0,'m30':5400.0,'m15':3600.0,'m5':2400.0,'m3':1800.0,'m1':1200.0}.get(tf,1800.0)
        if not rec.get('trigger_reached_ts') and age>=stale_limit: rec['line_state']='stale_unreached'
        sl,sh=_structure_zone_bounds(rec.get('support_zone'))
        zone_eps=max(1e-12,max(abs(sl or 0.0),abs(sh or 0.0),abs(cur))*1e-12)
        if sl is not None and sh is not None and sl-zone_eps<=cur<=sh+zone_eps:
            last=_quality_optional_num(rec.get('last_support_touch_ts')) or 0.0
            if nowv-last>=30.0:
                rec['support_touch_count']=int(rec.get('support_touch_count') or 0)+1; rec['last_support_touch_ts']=nowv; rec['last_support_touch_text']=now_text(nowv); rec['line_state']='support_touched'
                if rec['support_touch_count']>=3: rec['line_weakened']=True; rec['weakening_reason']='support_zone_reused_three_or_more_times'; rec['line_state']='weakened_multi_touch'
        trigger=_quality_optional_num(rec.get('trigger')) or 0.0; mode=str(rec.get('trigger_activation_mode') or '')
        can_activate=False
        if mode=='swing_resistance_breakout': can_activate=trigger>0 and cur>=trigger
        elif mode in ('support_recovery_after_touch','demand_recovery_after_touch','volume_node_reclaim_after_touch'):
            can_activate=bool(rec.get('support_touch_count',0)>0 and trigger>0 and cur>=trigger)
        elif mode=='confirmed_break_retest_event': can_activate=bool(rec.get('trigger_reached_ts'))
        if not rec.get('trigger_reached_ts') and can_activate:
            rec['trigger_reached_ts']=nowv; rec['trigger_reached_text']=now_text(nowv); rec['entry_price']=cur; rec['line_state']='trigger_reached'; rec['activation_source']='live_review_condition'; rec['max_pct']=0.0; rec['min_pct']=0.0; rec['giveback_pct']=0.0
        if rec.get('trigger_reached_ts') and (_quality_optional_num(rec.get('entry_price')) or 0)>0:
            tl,th=_structure_zone_bounds(rec.get('trigger_zone'))
            if tl is not None and th is not None and tl<=cur<=th and nowv-float(rec.get('trigger_reached_ts') or nowv)>=30.0:
                last=_quality_optional_num(rec.get('last_trigger_retest_ts')) or 0.0
                if nowv-last>=30.0:
                    rec['trigger_retest_count']=int(rec.get('trigger_retest_count') or 0)+1; rec['last_trigger_retest_ts']=nowv; rec['last_trigger_retest_text']=now_text(nowv)
                    if mode=='swing_resistance_breakout': rec['role_flip_confirmed_ts']=nowv; rec['role_flip_confirmed_text']=now_text(nowv); rec['line_state']='resistance_to_support_confirmed'
            base=float(rec['entry_price']); pctv=(cur-base)/base*100.0; rec['current_price']=cur; rec['current_pct']=round(pctv,6); rec['max_pct']=max(_quality_optional_num(rec.get('max_pct')) or pctv,pctv); rec['min_pct']=min(_quality_optional_num(rec.get('min_pct')) or pctv,pctv); rec['giveback_pct']=round(float(rec['max_pct'])-pctv,6)
            inv=_quality_optional_num(rec.get('invalid')); tgt=_quality_optional_num(rec.get('target')); terminal=[]
            if inv and cur<=inv:
                if not rec.get('invalid_ts'): rec['invalid_ts']=nowv; rec['invalid_text']=now_text(nowv)
                terminal.append('invalid')
            if tgt and cur>=tgt:
                if not rec.get('target_ts'): rec['target_ts']=nowv; rec['target_text']=now_text(nowv)
                terminal.append('target')
            if not rec.get('first_terminal'):
                if len(terminal)==1: rec['first_terminal']=terminal[0]; rec['line_state']=terminal[0]+'_first'
                elif len(terminal)>1: rec['first_terminal']='ambiguous'; rec['line_state']='terminal_order_unknown'
            elapsed=max(0.0,nowv-float(rec['trigger_reached_ts'])); samples=rec.get('samples') if isinstance(rec.get('samples'),dict) else {}; btc_start=_quality_optional_num(rec.get('btc_start_price')); btc_ret=(btc_now-btc_start)/btc_start*100.0 if btc_start and btc_now else None
            for label,sec in STRUCTURE_LAB_HORIZONS:
                if elapsed>=sec and label not in samples: samples[label]={'ts':nowv,'pct':rec['current_pct'],'max_pct':rec['max_pct'],'min_pct':rec['min_pct'],'giveback_pct':rec['giveback_pct'],'btc_pct':round(btc_ret,6) if btc_ret is not None else None,'relative_to_btc_pct':round(rec['current_pct']-btc_ret,6) if btc_ret is not None else None,'observation_source':'review snapshots after live detection; intracycle high/low order not inferred'}
            rec['samples']=samples
        records[key]=rec
    for item in missed_rows:
        if not isinstance(item,dict): continue
        key=str(item.get('miss_key') or '').strip(); ticker=ticker_norm(item.get('ticker'))
        if not key or not ticker: continue
        rec=missed.get(key)
        if rec is None:
            first=_quality_optional_num(item.get('first_price')) or _current_price(ticker,fmap,ofmap)
            rec={'schema':'structure_missed_state_row_v951','miss_key':key,'ticker':ticker,'source':item.get('source'),'reason':item.get('reason'),'method_diagnostics':item.get('method_diagnostics'),'found_methods':item.get('found_methods'),'candidate_exact_identity':item.get('candidate_exact_identity'),'structure_occurrence_key':item.get('structure_occurrence_key'),'scanner_occurrence':item.get('scanner_occurrence'),'first_seen_ts':_quality_optional_num(item.get('first_seen_ts')) or nowv,'first_seen_text':now_text(_quality_optional_num(item.get('first_seen_ts')) or nowv),'first_price':first,'samples':{},'max_pct':0.0,'min_pct':0.0,'btc_start_price':btc_now or None,'observation_only':True}; new_missed+=1
        rec['last_source_seen_ts']=nowv; rec['candidate_exact_identity_last']=item.get('candidate_exact_identity'); missed[key]=rec
    for key,rec in list(missed.items()):
        ticker=ticker_norm(rec.get('ticker')); cur=_current_price(ticker,fmap,ofmap); base=_quality_optional_num(rec.get('first_price')) or 0.0
        if cur>0 and base>0:
            pctv=(cur-base)/base*100.0; rec['current_price']=cur; rec['current_pct']=round(pctv,6); rec['max_pct']=max(_quality_optional_num(rec.get('max_pct')) or pctv,pctv); rec['min_pct']=min(_quality_optional_num(rec.get('min_pct')) or pctv,pctv)
            elapsed=max(0.0,nowv-float(rec.get('first_seen_ts') or nowv)); samples=rec.get('samples') if isinstance(rec.get('samples'),dict) else {}
            for label,sec in STRUCTURE_LAB_HORIZONS:
                if elapsed>=sec and label not in samples: samples[label]={'ts':nowv,'pct':rec['current_pct'],'max_pct':rec['max_pct'],'min_pct':rec['min_pct']}
            rec['samples']=samples
        if current_found_by_ticker.get(ticker) and not rec.get('later_structure_created_ts'):
            rec['later_structure_created_ts']=nowv; rec['later_structure_created_text']=now_text(nowv); rec['later_found_methods']=sorted(current_found_by_ticker[ticker])
        if current_complete_by_ticker.get(ticker) and not rec.get('later_complete_plan_created_ts'):
            rec['later_complete_plan_created_ts']=nowv; rec['later_complete_plan_created_text']=now_text(nowv); rec['later_complete_methods']=sorted(current_complete_by_ticker[ticker])
        missed[key]=rec
    records={k:v for k,v in records.items() if nowv-(_quality_optional_num(v.get('first_seen_ts')) or nowv)<=STRUCTURE_LAB_RETENTION_SEC}; missed={k:v for k,v in missed.items() if nowv-(_quality_optional_num(v.get('first_seen_ts')) or nowv)<=STRUCTURE_LAB_RETENTION_SEC}
    vals=list(records.values()); miss_vals=list(missed.values()); method_stats={m:_structure_plan_stats(vals,m) for m in ('A_SWING','B_REACTION_ZONE','C_BREAK_RETEST','D_SUPPLY_DEMAND','E_VOLUME_PROFILE')}
    status={'schema':'structure_lab_review_status_v951','version':VERSION,'build':BUILD_LABEL,'state':'ACTIVE' if lab_rows else 'WAITING','updated_ts':nowv,'updated_text':now_text(nowv),'source_candidate_rows':len(lab_rows),'source_candidate_unique_tickers':source.get('candidate_unique_tickers') if isinstance(source,dict) else 0,'source_total_candidate_rows':source.get('candidate_rows',0) if isinstance(source,dict) else 0,'source_analysis_ready_rows':source.get('analysis_ready_rows',0) if isinstance(source,dict) else 0,'source_partial_rows':source.get('source_partial_rows',0) if isinstance(source,dict) else 0,'source_not_ready_rows':source.get('source_not_ready_rows_count',0) if isinstance(source,dict) else 0,'source_frame_ready_counts':source.get('source_frame_ready_counts',{}) if isinstance(source,dict) else {},'tracked_structures':len(vals),'new_structures_this_cycle':new_plans,'method_stats':method_stats,'source_method_found_counts':source.get('method_found_counts') if isinstance(source,dict) else {},'source_method_complete_counts':source.get('method_complete_counts') if isinstance(source,dict) else {},'source_method_partial_counts':source.get('method_partial_counts') if isinstance(source,dict) else {},'source_method_no_structure_counts':source.get('method_no_structure_counts') if isinstance(source,dict) else {},'source_method_component_counts':source.get('method_component_counts') if isinstance(source,dict) else {},'discovery_reason_top':source.get('discovery_reason_top') if isinstance(source,dict) else [],'incomplete_reason_top':source.get('incomplete_reason_top') if isinstance(source,dict) else [],'completed_candles_only':True,'forming_candle_excluded':True,'volume_profile_note':'E remains candle typical-price approximation until exchange-confirmed price-volume history exists','policy':'structure discovery, method-specific activation, and full plan completion are separate; observation only','trading_rules_changed':False}
    missed_status={'schema':'structure_missed_status_v951','version':VERSION,'build':BUILD_LABEL,'state':'ACTIVE' if missed_rows or miss_vals else 'WAITING','updated_ts':nowv,'updated_text':now_text(nowv),'new_missed_this_cycle':new_missed,'source_not_ready_excluded':int(source.get('source_not_ready_rows_count') or 0) if isinstance(source,dict) else 0,'source_analysis_ready_rows':int(source.get('analysis_ready_rows') or 0) if isinstance(source,dict) else 0,'source_all_methods_no_structure':int(source.get('all_methods_no_structure_count') or 0) if isinstance(source,dict) else 0,'source_structure_found_no_complete':int(source.get('structure_found_no_complete_count') or 0) if isinstance(source,dict) else 0,'source_scanner_not_candidate':int(source.get('scanner_seen_not_candidate_count') or 0) if isinstance(source,dict) else 0,'source_scanner_not_candidate_unique':int(source.get('scanner_seen_not_candidate_unique_tickers') or 0) if isinstance(source,dict) else 0,'source_scanner_pool_not_candidate':int(source.get('scanner_pool_not_candidate_count') or 0) if isinstance(source,dict) else 0,'source_scanner_pool_not_candidate_unique':int(source.get('scanner_pool_not_candidate_unique_tickers') or 0) if isinstance(source,dict) else 0,'market_counts':{'candidate_rows':source.get('candidate_rows',0),'candidate_unique_tickers':source.get('candidate_unique_tickers',0),'scanner_hot_rows':source.get('scanner_hot_rows',0),'scanner_hot_unique_tickers':source.get('scanner_hot_unique_tickers',0),'scanner_pool_rows':source.get('scanner_pool_rows',0),'scanner_pool_unique_tickers':source.get('scanner_pool_unique_tickers',0)},'stats':_structure_missed_stats(miss_vals),'samples':sorted(miss_vals,key=lambda r:_quality_optional_num(r.get('max_pct')) or -999,reverse=True)[:12],'policy':'source-not-ready is excluded; only source-ready true no-structure, partial trade-plan, scanner-hot miss, and scanner-pool miss are tracked; no fallback line','trading_rules_changed':False}
    save_json(STRUCTURE_LAB_STATE,{'schema':'structure_lab_state_v951','version':VERSION,'updated_ts':nowv,'records':records}); save_json(STRUCTURE_MISSED_STATE,{'schema':'structure_missed_state_v951','version':VERSION,'updated_ts':nowv,'records':missed}); save_json(STRUCTURE_LAB_REVIEW_STATUS,status); save_json(STRUCTURE_MISSED_STATUS,missed_status)
    return status,missed_status

def run_once() -> Dict[str, Any]:
    _JSONL_CYCLE_CACHE.clear()
    st = now_ts(); write_status("running", phase="refreshing", last_sec=0, jsonl_reader_v929="tail_cached_single_cycle")
    queue = load_json(QUEUE, {}) or {}
    qrows = queue.get("review_candidates") if isinstance(queue, dict) and isinstance(queue.get("review_candidates"), list) else []
    # v446: review state에 이미 들어간 구 후보도 구조태그가 보이도록 현재 후보 snapshot/queue와 표시용 파생값으로 보강한다.
    source_rows = [r for r in read_jsonl(PAPER_LATEST, max_lines=SOURCE_SNAPSHOT_LINES) if isinstance(r, dict)] + [r for r in qrows if isinstance(r, dict)]
    structure_sources: Dict[str, Dict[str, Any]] = {}
    for sr in source_rows:
        tt = ticker_norm(sr.get("ticker") or sr.get("symbol") or sr.get("market"))
        if tt and (_has_structure(sr) or _has_market(sr)):
            structure_sources[tt] = sr
    state = load_json(STATE, {}) or {}
    active = state.get("active") if isinstance(state.get("active"), dict) else {}
    fmap = map_rows(load_json(FEATURE, {}) or {})
    ofmap = map_rows(load_json(ORDERFLOW, {}) or {})
    regime = load_json(REGIME, {}) or {}
    nowv = now_ts()
    try:
        trigger_shadow_v665 = _v665_trigger_shadow_update(nowv, fmap, ofmap)
    except Exception as exc:
        append_error(ERROR, "v665_trigger_shadow_update", exc)
        trigger_shadow_v665 = {"schema":"trigger_shadow_review_v665_error", "error": f"{exc.__class__.__name__}: {exc}"}
    try:
        market_miss_v667 = _v667_market_miss_update(nowv, fmap, ofmap)
    except Exception as exc:
        append_error(ERROR, "v667_market_miss_update", exc)
        market_miss_v667 = {"schema":"market_miss_review_v667_error", "error": f"{exc.__class__.__name__}: {exc}"}
    try:
        good_s2_result_v923 = _v923_update_good_s2_results(nowv, fmap, ofmap)
    except Exception as exc:
        append_error(ERROR, 'v923_good_s2_result_update', exc)
        good_s2_result_v923 = {'schema':'good_s2_result_snapshot_v923_error','error':f'{exc.__class__.__name__}: {exc}'}
    try:
        quality_shadow = update_quality_shadow(nowv, fmap, ofmap)
    except Exception as exc:
        append_error(ERROR, 'quality_shadow_update', exc)
        quality_shadow = {'schema':'quality_shadow_status_v947_error','state':'ERROR','error':f'{exc.__class__.__name__}: {exc}'}
    try:
        qstate=load_json(QUALITY_SHADOW_STATE,{}) or {}
        qrecords=list((qstate.get('records') or {}).values()) if isinstance(qstate,dict) and isinstance(qstate.get('records'),dict) else []
        late_path = update_late_path_status(nowv, [r for r in qrecords if isinstance(r,dict)])
    except Exception as exc:
        append_error(ERROR, 'late_path_update', exc)
        late_path = {'schema':'late_path_status_v947_error','state':'ERROR','error':f'{exc.__class__.__name__}: {exc}'}
    try:
        qstate=load_json(QUALITY_SHADOW_STATE,{}) or {}
        qrecords=list((qstate.get('records') or {}).values()) if isinstance(qstate,dict) and isinstance(qstate.get('records'),dict) else []
        sample_board = update_sample_board(nowv,[r for r in qrecords if isinstance(r,dict)])
    except Exception as exc:
        append_error(ERROR,'sample_board_update',exc); sample_board={'schema':'sample_board_status_v948_error','state':'ERROR','error':f'{exc.__class__.__name__}: {exc}'}
    try:
        smart_structure = update_smart_structure_shadow(nowv,fmap,ofmap)
    except Exception as exc:
        append_error(ERROR,'smart_structure_shadow_update',exc); smart_structure={'schema':'smart_structure_shadow_review_status_v948_error','state':'ERROR','error':f'{exc.__class__.__name__}: {exc}'}
    try:
        structure_lab, structure_missed = update_structure_laboratory(nowv,fmap,ofmap)
    except Exception as exc:
        append_error(ERROR,'structure_laboratory_update',exc)
        structure_lab={'schema':'structure_lab_review_status_v951_error','state':'ERROR','error':f'{exc.__class__.__name__}: {exc}'}
        structure_missed={'schema':'structure_missed_status_v951_error','state':'ERROR','error':f'{exc.__class__.__name__}: {exc}'}
    ttl = max(3600.0, RETENTION_DAYS * 86400.0)
    # 오래된 비핵심 복기 state만 제거. paper 장부는 삭제하지 않음.
    before_active = len(active)
    active = {k:v for k,v in active.items() if _v655_keep_active_review(v, nowv, ttl)}
    active = _v664_prune_active_size(active, nowv, ACTIVE_REVIEW_MAX)
    pruned_active = max(0, before_active - len(active))

    for c in qrows:
        if not isinstance(c, dict): continue
        stage = str(c.get("stage") or "").upper()
        if stage not in ("S2", "S3"): continue
        t = ticker_norm(c.get("ticker"))
        if not t: continue
        cur = _current_price(t, fmap, ofmap)
        base = fnum(c.get("snapshot_price"), c.get("price"), default=0.0) or cur
        rec = active.get(t) or {
            "ticker": t, "first_seen_ts": nowv, "first_seen_text": now_text(nowv),
            "first_price": base, "min_pct": 0.0, "max_pct": 0.0,
            "max_seen_ts": nowv, "max_seen_text": now_text(nowv), "samples": {},
        }
        rec.update({
            "stage": stage, "strategy": c.get("strategy"), "strategy_key": c.get("strategy_key"),
            "score": c.get("score"), "block_reasons": c.get("block_reasons", []),
            "missing_info": c.get("missing_info", []), "metrics": c.get("metrics", {}),
            "structure_tags": c.get("structure_tags", []),
            "structure_good_tags": c.get("structure_good_tags", []),
            "structure_risk_tags": c.get("structure_risk_tags", []),
            "structure_fit": c.get("structure_fit", ""),
            "structure_summary": c.get("structure_summary", ""),
            "chart_structure": c.get("chart_structure", {}),
            "last_seen_ts": nowv, "last_seen_text": now_text(nowv),
        })
        if not fnum(rec.get("first_price"), default=0.0) and base:
            rec["first_price"] = base
        if cur:
            rec["current_price"] = cur
            cp = _pct(cur, fnum(rec.get("first_price"), default=0.0))
            rec["current_pct"] = cp
            prev_max = fnum(rec.get("max_pct"), default=cp)
            if cp >= prev_max:
                rec["max_seen_ts"] = nowv
                rec["max_seen_text"] = now_text(nowv)
            rec["max_pct"] = max(prev_max, cp)
            rec["min_pct"] = min(fnum(rec.get("min_pct"), default=cp), cp)
            elapsed = nowv - fnum(rec.get("first_seen_ts"), default=nowv)
            samples = rec.get("samples") if isinstance(rec.get("samples"), dict) else {}
            for label, sec in (("5m",300),("10m",600),("20m",1200)):
                if elapsed >= sec and label not in samples:
                    samples[label] = {"ts": nowv, "text": now_text(nowv), "price": cur, "pct": cp}
                    rec[f"after_{label}_pct"] = cp
            rec["samples"] = samples
            rec["decision"] = _decision(rec, elapsed)
        active[t] = rec

    # v441: active state에 남은 구 decision/review_hint를 그대로 쓰지 않는다.
    # 현재 max/current/위험프로필 기준으로 다시 분류해 /review 상단 count와 후보별 문구가 어긋나지 않게 한다.
    for rec in active.values():
        if not isinstance(rec, dict):
            continue
        _ensure_structure(rec, structure_sources)
        _ensure_market(rec, structure_sources, fmap, ofmap, regime if isinstance(regime, dict) else {})
        elapsed = nowv - fnum(rec.get("first_seen_ts"), default=nowv)
        rec["decision"] = _decision(rec, elapsed)
        rec["review_class"] = rec["decision"]
        rec["review_hint"] = rec["decision"]
    all_rows = list(active.values())
    missed = [r for r in all_rows if str(r.get("decision")) == "❌ 진짜 놓친 후보"]
    regret = [r for r in all_rows if str(r.get("decision")) == "⚠️ 아까운 후보"]
    late_rise = [r for r in all_rows if str(r.get("decision")) == "⏳ 늦게 오른 후보"]
    risk_rise = [r for r in all_rows if str(r.get("decision")) == "🔥 결과만 오른 위험 후보"]
    correct = [r for r in all_rows if str(r.get("decision")) == "✅ 안 산 게 맞음"]
    done = {"❌ 진짜 놓친 후보", "⚠️ 아까운 후보", "⏳ 늦게 오른 후보", "🔥 결과만 오른 위험 후보", "✅ 안 산 게 맞음"}
    pending = [r for r in all_rows if str(r.get("decision")) not in done]
    legacy = _legacy_closed_summary(structure_sources, fmap, ofmap, regime if isinstance(regime, dict) else {})
    summary = {
        "schema": "missed_review_summary_v457_timing_split",
        "version": VERSION,
        "updated_ts": nowv, "updated_text": now_text(nowv),
        "queue_age_sec": round(nowv - fnum(queue.get("updated_ts"), default=nowv), 1) if isinstance(queue, dict) else None,
        "tracking_total": len(all_rows), "queue_candidates": len(qrows),
        "missed_count": len(missed), "regret_count": len(regret), "late_rise_count": len(late_rise), "risk_rise_count": len(risk_rise), "correct_count": len(correct), "pending_count": len(pending),
        "missed": _summ_rows(missed, 8), "regret": _summ_rows(regret, 8), "late_rise": _summ_rows(late_rise, 8), "risk_rise": _summ_rows(risk_rise, 8), "correct": _summ_rows(correct, 5), "pending": _summ_rows(pending, 8),
        "missed_reason_top": _reason_top(missed + regret, 8),
        "v655_active_pruned": pruned_active,
        "v655_policy": "중요 복기 후보는 유지하고 추적중/안산게맞음 active state만 짧게 순환해 CPU를 줄임. paper 장부 삭제 없음.",
        "v664_active_max": ACTIVE_REVIEW_MAX,
        "v664_source_snapshot_lines": SOURCE_SNAPSHOT_LINES,
        "v664_policy": "review_worker는 paper 장부를 지우지 않고 active missed-review 상태만 핵심/최근 후보 중심으로 제한해 CPU를 줄임.",
        "trigger_shadow_v665": trigger_shadow_v665,
        "market_miss_v667": market_miss_v667,
        "good_s2_result_v923": good_s2_result_v923,
        "quality_shadow_v946": quality_shadow,
        "late_path_v947": late_path,
        "sample_board_v948": sample_board,
        "smart_structure_shadow_v948": smart_structure,
        "structure_lab_v951": structure_lab,
        "structure_missed_v951": structure_missed,
        "late_rise_reason_top": _reason_top(late_rise, 8),
        "risk_rise_reason_top": _reason_top(risk_rise, 8),
        "policy": "v457: 최고수익 착시를 분리한다. 진짜놓침은 5/10/20분 안에 상승한 후보만 남기고, 늦게 오른 후보는 S1 완화 근거에서 제외한다. 조건/청산숫자/paper 장부 변경 없음.",
        **legacy,
    }
    save_json(STATE, {"schema":"missed_review_state_v457_timing_split", "version":VERSION, "updated_ts":nowv, "active":active})
    save_json(SUMMARY, summary)
    save_json(OLD_SUMMARY, {"version":VERSION, "updated_ts":nowv, "updated_text":now_text(nowv), **legacy, "missed_review": summary})
    sec = now_ts() - st
    write_status("running", tracked=len(all_rows), missed=len(missed), regret=len(regret), late_rise=len(late_rise), risk_rise=len(risk_rise), correct=len(correct), pending=len(pending), closed_recent=legacy.get("closed_recent",0), big_loss=legacy.get("big_loss",0), good_win=legacy.get("good_win",0), active_pruned=pruned_active, active_max=ACTIVE_REVIEW_MAX, source_snapshot_lines=SOURCE_SNAPSHOT_LINES, trigger_shadow_active=(trigger_shadow_v665 or {}).get("active_count",0), trigger_shadow_entered=(trigger_shadow_v665 or {}).get("entered_count",0), trigger_shadow_pruned=(trigger_shadow_v665 or {}).get("pruned_count_v678",0), market_miss_tracking=(market_miss_v667 or {}).get("tracking_total",0), market_miss_rise=(market_miss_v667 or {}).get("rise_count",0), good_s2_result_total=(good_s2_result_v923 or {}).get("tracked_total",0), good_s2_result_opened=(good_s2_result_v923 or {}).get("opened_exact",0), good_s2_result_closed=(good_s2_result_v923 or {}).get("closed_exact",0), good_s2_result_final=(good_s2_result_v923 or {}).get("final_ledger_rows",0), quality_shadow_tracked=(quality_shadow or {}).get("tracked_records",0), quality_shadow_final=(quality_shadow or {}).get("final_ledger_rows",0), late_path_occurrences=(late_path or {}).get("occurrence_normalized_records",0), sample_board_records=(sample_board or {}).get("tracked_records",0), smart_structure_records=(smart_structure or {}).get("tracked_records",0), structure_lab_plans=(structure_lab or {}).get("tracked_structures",0), structure_missed_records=((structure_missed or {}).get("stats") or {}).get("tracked",0), last_sec=round(sec,3), structure_enriched=sum(1 for r in active.values() if isinstance(r, dict) and _has_structure(r)))
    return {"tracked": len(all_rows), "missed": len(missed), "regret": len(regret), "late_rise": len(late_rise), "correct": len(correct), "good_s2_result": good_s2_result_v923, "quality_shadow": quality_shadow, "late_path": late_path, "sample_board": sample_board, "smart_structure": smart_structure, "structure_lab": structure_lab, "structure_missed": structure_missed}

def main() -> None:
    write_status("initializing")
    while True:
        try: run_once()
        except KeyboardInterrupt: write_status("stopping"); raise
        except Exception as exc:
            append_error(ERROR, "loop", exc); write_status("error", error=f"{exc.__class__.__name__}: {exc}")
        time.sleep(max(10.0, INTERVAL_SEC))

# =============================================================================
# review_worker v0.19 / v675: preserve canonical values in missed-review state
# =============================================================================
VERSION = "review_worker_v0.720"

def _v675_first(*vals: Any, default: Any=None) -> Any:
    for v in vals:
        if v not in (None, '', '-', [], {}): return v
    return default

_v675_prev_market_miss_update = _v667_market_miss_update

def _v667_market_miss_update(nowv: float, fmap: Dict[str, Dict[str, Any]], ofmap: Dict[str, Dict[str, Any]]) -> Dict[str, Any]:  # type: ignore[override]
    summary = _v675_prev_market_miss_update(nowv, fmap, ofmap)
    try:
        cand_obj = load_json(MARKET_MISS_CANDIDATES, {}) or {}; candidates = cand_obj.get('rows') if isinstance(cand_obj, dict) and isinstance(cand_obj.get('rows'), list) else []
        by_ticker = {ticker_norm(c.get('ticker')): c for c in candidates if isinstance(c, dict) and ticker_norm(c.get('ticker'))}
        state = load_json(MARKET_MISS_STATE, {}) or {}; active = state.get('active') if isinstance(state, dict) and isinstance(state.get('active'), dict) else {}
        for t, rec in list(active.items()):
            if not isinstance(rec, dict): continue
            c = by_ticker.get(t) or {}
            rec['coin_quality_score'] = fnum(_v675_first(c.get('coin_quality_score'), c.get('q'), rec.get('coin_quality_score')), default=0.0); rec['q'] = rec['coin_quality_score']
            rec['execution_risk_score'] = fnum(_v675_first(c.get('execution_risk_score'), c.get('risk'), rec.get('execution_risk_score')), default=0.0); rec['risk'] = rec['execution_risk_score']
            for k in ('trigger_source','trigger_confidence','trigger_gap_pct','price_reaction_pct','buy_ratio','buy_sustain_1m','spread_pct','slippage_pct','candle_age_sec'):
                if c.get(k) not in (None, '', '-'): rec[k] = c.get(k)
            maxp = fnum(rec.get('max_pct'), default=0.0); q=fnum(rec.get('coin_quality_score'), default=0.0); risk=fnum(rec.get('execution_risk_score'), default=0.0); bucket=str(rec.get('miss_bucket') or '-')
            if maxp >= 0.70 and q >= 60 and risk <= 40 and bucket not in ('risk_filter_candidate',): rec['miss_decision']='❌ 진짜놓침_후보'
            elif maxp >= 0.70 and bucket == 'risk_filter_candidate': rec['miss_decision']='✅ 위험필터_성공검토'
            elif maxp >= 0.40: rec['miss_decision']='⚠️ 아까운상승'
            else: rec['miss_decision']='관찰중'
            active[t]=rec
        rows=list(active.values()); matured=[r for r in rows if fnum(r.get('age_sec'), default=0)>=180]; risers=[r for r in rows if fnum(r.get('max_pct'), default=0)>=0.40]; true_missed=[r for r in rows if str(r.get('miss_decision'))=='❌ 진짜놓침_후보']
        buckets=Counter(str(r.get('miss_bucket') or '-') for r in risers); decisions=Counter(str(r.get('miss_decision') or '-') for r in rows)
        def slim(r: Dict[str, Any]) -> Dict[str, Any]:
            return {k:r.get(k) for k in ('ticker','initial_stage','miss_bucket','miss_decision','coin_quality_score','q','execution_risk_score','risk','first_price','latest_price','current_pct','max_pct','min_pct','age_sec','initial_reason','trigger_source','trigger_confidence','trigger_gap_pct','price_reaction_pct','buy_ratio','buy_sustain_1m','spread_pct','slippage_pct','candle_age_sec')}
        top=sorted(risers, key=lambda r:fnum(r.get('max_pct'), default=0.0), reverse=True)[:12]; true_top=sorted(true_missed, key=lambda r:fnum(r.get('max_pct'), default=0.0), reverse=True)[:10]
        summary=dict(summary or {}); summary.update({'schema':'market_miss_review_v675_value_enriched','version':VERSION,'updated_ts':nowv,'updated_text':now_text(nowv),'tracking_total':len(rows),'matured_count':len(matured),'rise_count':len(risers),'true_missed_count':len(true_missed),'miss_bucket_counts':dict(buckets.most_common(10)),'decision_counts':dict(decisions.most_common(8)),'top_risers':[slim(r) for r in top],'true_missed_top':[slim(r) for r in true_top],'value_enriched_v675':True,'policy':'v675: missed candidates keep Q/R/trigger/execution values from canonical candidate snapshot. 실제 S1/paper OPEN/청산/자동매수 변경 없음.'})
        save_json(MARKET_MISS_STATE, {'schema':'market_miss_state_v675_value_enriched','version':VERSION,'updated_ts':nowv,'updated_text':now_text(nowv),'active':active}); save_json(MARKET_MISS_SUMMARY, summary)
    except Exception as exc: append_error(ERROR, 'v675_market_miss_value_enrich', exc)
    return summary


# =============================================================================
# review_worker v0.20 / v676: market-miss CPU cache guard
# - Keep whole-market review, but do not rebuild the expensive 456-row maturity
#   summary every loop when the cache is still fresh.
# =============================================================================
VERSION = "review_worker_v0.720"
V676_MARKET_MISS_MIN_REFRESH_SEC = float(os.getenv('REVIEW_MARKET_MISS_MIN_REFRESH_SEC', '25'))
_v676_prev_market_miss_update = _v667_market_miss_update

def _v667_market_miss_update(nowv: float, fmap: Dict[str, Dict[str, Any]], ofmap: Dict[str, Dict[str, Any]]) -> Dict[str, Any]:  # type: ignore[override]
    try:
        if MARKET_MISS_SUMMARY.exists():
            age = max(0.0, nowv - MARKET_MISS_SUMMARY.stat().st_mtime)
            if age < V676_MARKET_MISS_MIN_REFRESH_SEC:
                cached = load_json(MARKET_MISS_SUMMARY, {}) or {}
                if isinstance(cached, dict) and cached.get('tracking_total'):
                    cached = dict(cached)
                    cached['cache_reused_v676'] = True
                    cached['cache_age_sec_v676'] = round(age, 3)
                    return cached
    except Exception:
        pass
    out = _v676_prev_market_miss_update(nowv, fmap, ofmap)
    try:
        if isinstance(out, dict):
            out['cache_reused_v676'] = False
            out['min_refresh_sec_v676'] = V676_MARKET_MISS_MIN_REFRESH_SEC
            save_json(MARKET_MISS_SUMMARY, out)
    except Exception as exc:
        append_error(ERROR, 'v676_market_miss_cache_mark', exc)
    return out




# =============================================================================
# review_worker v0.721 / v895: same-number seal for market-miss after review
# - 후보 row의 stable_event_key/candidate_follow_key/entry_build_key를 market-miss 결과에 보존한다.
# - 실제 S1/paper OPEN/청산/자동매수/조건은 변경하지 않는다.
# =============================================================================
VERSION = "review_worker_v0.721"
BUILD_LABEL = 'market_miss_same_key_seal_v895_2026-06-14'


def _v895_present(v: Any) -> bool:
    return v not in (None, '', '-', [], {})


def _v895_event_prefix_bucket(value: Any) -> tuple[str, Optional[int]]:
    s = str(value or '').strip()
    if not s or s == '-': return '', None
    parts = s.split(':')
    if len(parts) >= 2 and parts[-1].isdigit():
        try: return ':'.join(parts[:-1]), int(parts[-1])
        except Exception: return ':'.join(parts[:-1]), None
    return s, None


def _v895_stable_fields(c: Dict[str, Any]) -> Dict[str, Any]:
    if not isinstance(c, dict): return {}
    eid = None
    for k in ('event_id','event_key','trace_id','handoff_id','candidate_uid','candidate_id','scan_id','source_scan_id','entry_build_key','build_key'):
        if _v895_present(c.get(k)):
            eid = c.get(k); break
    stable = None
    for k in ('stable_event_key_v894','candidate_follow_key_v894','stable_event_key_v895','candidate_follow_key_v895'):
        if _v895_present(c.get(k)):
            stable = c.get(k); break
    bucket = None
    for k in ('stable_event_bucket_v894','candidate_event_bucket_v894','stable_event_bucket_v895','candidate_event_bucket_v895'):
        if _v895_present(c.get(k)):
            bucket = c.get(k); break
    if not _v895_present(stable) and _v895_present(eid):
        stable, bucket2 = _v895_event_prefix_bucket(eid)
        if not _v895_present(bucket): bucket = bucket2
    out = {
        'event_id': eid,
        'stable_event_key_v894': stable,
        'candidate_follow_key_v894': stable,
        'stable_event_key_v895': stable,
        'candidate_follow_key_v895': stable,
        'entry_build_key': c.get('entry_build_key') or c.get('build_key') or eid,
        'score_patch_version': c.get('score_patch_version') or c.get('patch_version') or VERSION,
        'signal_ts': c.get('signal_ts') or c.get('created_at') or c.get('candidate_created_at') or c.get('source_created_at'),
        'same_key_sealed_v895': bool(_v895_present(stable) or _v895_present(eid)),
        'same_key_owner_v895': 'review_worker_market_miss_writer',
        'same_key_policy_v895': 'use candidate stable key for after metric review; no trading condition change',
    }
    if _v895_present(bucket):
        try: out['stable_event_bucket_v894'] = int(float(bucket)); out['stable_event_bucket_v895'] = int(float(bucket))
        except Exception: out['stable_event_bucket_v894'] = bucket; out['stable_event_bucket_v895'] = bucket
    return {k:v for k,v in out.items() if _v895_present(v) or k == 'same_key_sealed_v895'}


_v895_prev_miss_key = _v667_miss_key

def _v667_miss_key(c: Dict[str, Any]) -> str:  # type: ignore[override]
    fields = _v895_stable_fields(c)
    return str(fields.get('stable_event_key_v895') or fields.get('stable_event_key_v894') or fields.get('entry_build_key') or _v895_prev_miss_key(c))


def _v895_enrich_market_miss_outputs(summary: Dict[str, Any], nowv: float) -> Dict[str, Any]:
    cand_obj = load_json(MARKET_MISS_CANDIDATES, {}) or {}
    candidates = cand_obj.get('rows') if isinstance(cand_obj, dict) and isinstance(cand_obj.get('rows'), list) else []
    by_key: Dict[str, Dict[str, Any]] = {}
    by_ticker: Dict[str, Dict[str, Any]] = {}
    for c in candidates:
        if not isinstance(c, dict): continue
        fields = _v895_stable_fields(c)
        key = str(fields.get('stable_event_key_v895') or fields.get('entry_build_key') or '')
        t = ticker_norm(c.get('ticker') or c.get('symbol') or c.get('market'))
        cc = dict(c); cc.update(fields)
        if key: by_key[key] = cc
        if t: by_ticker[t] = cc
    state = load_json(MARKET_MISS_STATE, {}) or {}
    active = state.get('active') if isinstance(state, dict) and isinstance(state.get('active'), dict) else {}
    sealed = 0
    rows = []
    for k, rec in list(active.items()):
        if not isinstance(rec, dict): continue
        t = ticker_norm(rec.get('ticker'))
        c = by_key.get(str(k)) or by_key.get(str(rec.get('stable_event_key_v895') or rec.get('stable_event_key_v894') or '')) or by_ticker.get(t)
        if isinstance(c, dict):
            fields = _v895_stable_fields(c)
            rec.update(fields)
        if rec.get('same_key_sealed_v895'): sealed += 1
        rows.append(rec)
    if isinstance(active, dict):
        save_json(MARKET_MISS_STATE, {'schema':'market_miss_state_v895_same_key','version':VERSION,'build':BUILD_LABEL,'updated_ts':nowv,'updated_text':now_text(nowv),'active':active})
    def enrich_arr(arr: Any) -> list:
        out=[]
        for r in arr if isinstance(arr, list) else []:
            if not isinstance(r, dict): continue
            t = ticker_norm(r.get('ticker'))
            c = by_key.get(str(r.get('stable_event_key_v895') or r.get('stable_event_key_v894') or '')) or by_ticker.get(t)
            rr = dict(r)
            if isinstance(c, dict): rr.update(_v895_stable_fields(c))
            out.append(rr)
        return out
    summary = dict(summary or {})
    for key in ('top_risers','true_missed_top','rows','items','missed','regret','late_rise'):
        if isinstance(summary.get(key), list):
            summary[key] = enrich_arr(summary.get(key))
    # main v889 reads rows too; publish a compact stable-key rows list without replacing existing summaries.
    summary['rows'] = sorted(rows, key=lambda x: fnum(x.get('max_pct'), default=0.0), reverse=True)[:240]
    summary['same_key_seal_v895'] = {'candidate_rows': len(candidates), 'active_rows': len(rows), 'sealed_rows': sealed, 'version': VERSION, 'build': BUILD_LABEL}
    summary['version'] = VERSION; summary['build'] = BUILD_LABEL
    save_json(MARKET_MISS_SUMMARY, summary)
    return summary


_v895_prev_market_miss_update = _v667_market_miss_update

def _v667_market_miss_update(nowv: float, fmap: Dict[str, Dict[str, Any]], ofmap: Dict[str, Dict[str, Any]]) -> Dict[str, Any]:  # type: ignore[override]
    summary = _v895_prev_market_miss_update(nowv, fmap, ofmap)
    try:
        return _v895_enrich_market_miss_outputs(summary if isinstance(summary, dict) else {}, nowv)
    except Exception as exc:
        append_error(ERROR, 'v895_market_miss_same_key_seal', exc)
        return summary


# =============================================================================
# review_worker v0.722 / v896: same-key alias for market-miss performance prep
# - Adds v896 aliases and match mode into market-miss result rows.
# - No trading condition, trigger, exit, paper OPEN/CLOSED, auto-buy change.
# =============================================================================
VERSION = "review_worker_v0.951"
BUILD_LABEL = 'complete_market_structure_source_readiness_review_v951_2026-06-20'


def _v896_present(v: Any) -> bool:
    return v not in (None, '', '-', [], {})


def _v896_stable_fields(c: Dict[str, Any], mode: str = 'candidate_key') -> Dict[str, Any]:
    if not isinstance(c, dict): return {}
    stable = c.get('stable_event_key_v896') or c.get('candidate_follow_key_v896') or c.get('stable_event_key_v895') or c.get('candidate_follow_key_v895') or c.get('stable_event_key_v894') or c.get('candidate_follow_key_v894')
    bucket = c.get('stable_event_bucket_v896') or c.get('candidate_event_bucket_v896') or c.get('stable_event_bucket_v895') or c.get('candidate_event_bucket_v895') or c.get('stable_event_bucket_v894') or c.get('candidate_event_bucket_v894')
    eid = c.get('entry_build_key') or c.get('event_id') or c.get('event_key') or c.get('trace_id')
    if not _v896_present(stable) and _v896_present(eid):
        try:
            stable, b2 = _v895_event_prefix_bucket(eid)
            if not _v896_present(bucket): bucket = b2
        except Exception:
            stable = eid
    out = {
        'event_id': c.get('event_id') or eid,
        'stable_event_key_v896': stable,
        'candidate_follow_key_v896': stable,
        'stable_event_key_v895': stable,
        'candidate_follow_key_v895': stable,
        'stable_event_key_v894': stable,
        'candidate_follow_key_v894': stable,
        'same_number_key_v896': stable,
        'entry_build_key': c.get('entry_build_key') or eid,
        'score_patch_version': c.get('score_patch_version') or c.get('patch_version') or VERSION,
        'signal_ts': c.get('signal_ts') or c.get('created_at') or c.get('candidate_created_at') or c.get('source_created_at'),
        'same_key_sealed_v896': bool(stable or eid),
        'same_key_owner_v896': 'review_worker_market_miss_writer',
        'same_key_match_mode_v896': mode,
        'same_key_policy_v896': 'same key for quality tag performance prep; no trading condition change',
    }
    if _v896_present(bucket):
        try:
            out['stable_event_bucket_v896'] = int(float(bucket)); out['candidate_event_bucket_v896'] = int(float(bucket))
        except Exception:
            out['stable_event_bucket_v896'] = bucket; out['candidate_event_bucket_v896'] = bucket
    return {k:v for k,v in out.items() if _v896_present(v) or k == 'same_key_sealed_v896'}

_v896_prev_miss_key = _v667_miss_key

def _v667_miss_key(c: Dict[str, Any]) -> str:  # type: ignore[override]
    fields = _v896_stable_fields(c, 'exact_candidate_key')
    return str(fields.get('same_number_key_v896') or fields.get('stable_event_key_v896') or fields.get('entry_build_key') or _v896_prev_miss_key(c))

_v896_prev_market_miss_update = _v667_market_miss_update

def _v667_market_miss_update(nowv: float, fmap: Dict[str, Dict[str, Any]], ofmap: Dict[str, Dict[str, Any]]) -> Dict[str, Any]:  # type: ignore[override]
    summary = _v896_prev_market_miss_update(nowv, fmap, ofmap)
    try:
        cand_obj = load_json(MARKET_MISS_CANDIDATES, {}) or {}
        candidates = cand_obj.get('rows') if isinstance(cand_obj, dict) and isinstance(cand_obj.get('rows'), list) else []
        by_key: Dict[str, Dict[str, Any]] = {}; by_ticker: Dict[str, Dict[str, Any]] = {}
        for c in candidates:
            if not isinstance(c, dict): continue
            fields = _v896_stable_fields(c, 'exact_candidate_key')
            cc = dict(c); cc.update(fields)
            for k in ('same_number_key_v896','stable_event_key_v896','candidate_follow_key_v896','entry_build_key','event_id'):
                if _v896_present(cc.get(k)): by_key[str(cc.get(k))] = cc
            t = ticker_norm(c.get('ticker') or c.get('symbol') or c.get('market'))
            if t: by_ticker[t] = cc
        state = load_json(MARKET_MISS_STATE, {}) or {}
        active = state.get('active') if isinstance(state, dict) and isinstance(state.get('active'), dict) else {}
        rows=[]; sealed=0; exact=0; near=0
        for k, rec in list(active.items()):
            if not isinstance(rec, dict): continue
            c = by_key.get(str(k)) or by_key.get(str(rec.get('same_number_key_v896') or rec.get('stable_event_key_v896') or rec.get('stable_event_key_v895') or rec.get('entry_build_key') or rec.get('event_id') or ''))
            mode = 'exact_candidate_key' if isinstance(c, dict) else ''
            if c is None:
                t = ticker_norm(rec.get('ticker'))
                c = by_ticker.get(t); mode = 'ticker_time_near_audit' if isinstance(c, dict) else ''
            rr = dict(rec)
            if isinstance(c, dict): rr.update(_v896_stable_fields(c, mode))
            if rr.get('same_key_sealed_v896'): sealed += 1
            if rr.get('same_key_match_mode_v896') == 'exact_candidate_key': exact += 1
            if rr.get('same_key_match_mode_v896') == 'ticker_time_near_audit': near += 1
            rows.append(rr)
        summary = dict(summary or {})
        summary['rows'] = sorted(rows, key=lambda x: fnum(x.get('max_pct'), default=0.0), reverse=True)[:240]
        summary['same_key_seal_v896'] = {'candidate_rows':len(candidates),'active_rows':len(rows),'sealed_rows':sealed,'exact_rows':exact,'near_rows':near,'version':VERSION,'build':BUILD_LABEL,'updated_ts':nowv}
        summary['version']=VERSION; summary['build']=BUILD_LABEL
        save_json(MARKET_MISS_SUMMARY, summary)
        return summary
    except Exception as exc:
        append_error(ERROR, 'v896_market_miss_same_key_alias', exc)
        return summary

if __name__ == "__main__": main()
