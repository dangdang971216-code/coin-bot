# v1131 scope

- Failed predecessor: v1130 was not applied.
- Root cause: the active upgrader compiled an undeclared archive-only `test_v1130_bundle.py` from `BOT_DIR`, but that file existed only in the unpack directory.
- Fix 1: v1131 has no undeclared root Python file, so the currently active v1129 upgrader can apply it.
- Fix 2: the new Guard compiles future undeclared archive-only Python files from the unpack directory.
- Preserved: single compressed profitability export ZIP, allowlisted trade-log fallback, read-only source snapshots, SHA256 manifest, temp cleanup.
- Unchanged: Strategy, Paper, Main, Review, Gate, rank, OPEN 30, cycle 3, entry/exit contracts, auto-buy OFF.
