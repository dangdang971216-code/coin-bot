#!/usr/bin/env python3
from __future__ import annotations
import hashlib, importlib.util, json, os, pathlib, shutil, tempfile, zipfile

SOURCE=pathlib.Path(__file__).with_name('backga_guard_bot_v2_5_176.py')

def sha(path):
    h=hashlib.sha256()
    with path.open('rb') as f:
        for chunk in iter(lambda:f.read(1024*1024), b''):
            h.update(chunk)
    return h.hexdigest()

def main():
    with tempfile.TemporaryDirectory() as td:
        root=pathlib.Path(td)
        bot=root/'bot'; bot.mkdir()
        received=root/'received'; received.mkdir()
        # >28MiB raw closed ledger proves v1129 would pre-split, while v1130 must send one compressed ZIP.
        line=b'{"pos_id":"abc","ticker":"AAA","pnl_pct":-1.2345,"reason":"structure_invalid"}\n'
        closed=line * ((34*1024*1024)//len(line)+1)
        files={
            'paper_bot_closed.jsonl': closed,
            'paper_bot_open.json': json.dumps({'positions':[{'ticker':'AAA','invalid':98,'target':102}]}).encode(),
            'paper_decision_state_v926.json': json.dumps({'rows':[{'decision_key':'d1','state':'CLOSED'}]}).encode(),
            'canonical_performance_snapshot_v987.json': json.dumps({'closed_count':2}).encode(),
            # canonical trade log intentionally absent; fallback must be resolved and archived under logical canonical name.
            'paper_bot_trade_detail_v798.jsonl': b'{"event":"open"}\n{"event":"close"}\n',
            'paper_bot_control.json': json.dumps({'auto_buy':False,'max_open':30}).encode(),
        }
        for name,data in files.items():
            (bot/name).write_bytes(data)
        before={name:(sha(bot/name),(bot/name).stat().st_size,(bot/name).stat().st_mtime_ns) for name in files}
        os.environ['GUARD_BOT_TOKEN']='dummy'
        os.environ['GUARD_CHAT_ID']='123'
        os.environ['BOT_DIR']=str(bot)
        spec=importlib.util.spec_from_file_location('guard_v1131',SOURCE)
        mod=importlib.util.module_from_spec(spec); spec.loader.exec_module(mod)
        sent=[]
        def fake_send(chat_id,path,caption=''):
            target=received/path.name
            shutil.copy2(path,target)
            sent.append((str(chat_id),target,caption))
            return True,'MOCK_OK'
        mod.telegram_send_document_v1129=fake_send
        mod.progress_notify=lambda text: None
        text=mod.gexport_profitability_text_v1129()
        assert 'DONE' in text,text
        assert len(sent)==1,sent
        after={name:(sha(bot/name),(bot/name).stat().st_size,(bot/name).stat().st_mtime_ns) for name in files}
        assert before==after,(before,after)
        assert not list(bot.glob(mod.GUARD_EXPORT_TMP_PREFIX_V1129+'*'))
        result=json.loads((bot/mod.GUARD_EXPORT_LAST_RESULT_V1129).read_text())
        assert result['status']=='DONE',result
        assert result['archive_count']==1 and result['sent_archives']==1,result
        assert result['archive']['compression']=='ZIP_LZMA'
        assert len(result['fallback_files'])==1,result['fallback_files']
        archive=sent[0][1]
        assert archive.stat().st_size < mod.GUARD_EXPORT_MAX_DOCUMENT_BYTES_V1129
        with zipfile.ZipFile(archive) as z:
            names=set(z.namelist())
            expected={
                'EXPORT_MANIFEST.json','README_EXPORT.txt',
                'data/paper_bot_closed.jsonl','data/paper_bot_open.json',
                'data/paper_decision_state_v926.json','data/canonical_performance_snapshot_v987.json',
                'data/paper_bot_trade_log.jsonl','data/paper_bot_control.json',
            }
            assert expected.issubset(names),sorted(names)
            manifest=json.loads(z.read('EXPORT_MANIFEST.json'))
            assert manifest['archive_count']==1
            assert manifest['delivery_contract'].startswith('single ZIP')
            assert manifest['fallback_files']==[{
                'logical_name':'paper_bot_trade_log.jsonl',
                'resolved_name':'paper_bot_trade_detail_v798.jsonl',
            }]
            assert z.read('data/paper_bot_closed.jsonl').endswith(b'\n')
        issue=(bot/'issue_ledger.jsonl').read_text()
        change=(bot/'change_verify_ledger.jsonl').read_text()
        assert 'GUARD-PROFITABILITY-EXPORT-1130' in issue
        assert 'v1130-guard-profitability-single-zip-server-proof-001' in change
        print(json.dumps({
            'ok':True,
            'archives_sent':len(sent),
            'raw_source_mb':round(sum(len(v) for v in files.values())/1024/1024,2),
            'zip_mb':round(archive.stat().st_size/1024/1024,2),
            'trade_log_fallback':True,
            'original_hashes_unchanged':True,
            'temp_clean':True,
        },sort_keys=True))

if __name__=='__main__': main()
