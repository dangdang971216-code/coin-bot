v1704: condition owner map fast-cache hotfix. No strategy/candidate/exit threshold changes. Auto-buy OFF.
