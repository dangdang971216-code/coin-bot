coinbot_update_v2110.zip

목적
1. 후보를 전략 분류 전에 먼저 보존
   - 전략은 다중 태그
   - 어느 전략에도 정확히 안 맞으면 UNCLASSIFIED_STRUCTURE로 후보 보존
   - candidate 입력/출력 불일치 시 현재 Strategy cycle 실패

2. 새 구조계약 전체 본선 적용(신규 OPEN만)
   - 거래/공지 위험
   - 4h·2h 시장상태
   - 눌림·돌파재확인·박스돌파·전환·하락반등·미분류 다중태그
   - 셋업별 completed-candle trigger 확인
   - 구조 invalid와 실행 중단선 분리
   - T1 첫 저항 / T2 큰 목표 / Runner 조건
   - 실제 진입가 RR·T1 공간·spread/slippage Paper 최종 재검사

3. 문제 위치 exact 봉인
   - event / regime / strategy_tag / trigger / invalid / T1 / T2 / execution
   - 이전 v2065 구조는 같은 후보 비교 Shadow로만 보존

4. Review snapshot writer 수리
   - 오늘 TOP·entry failure·shake·weak entry·새 구조판을 각각 독립 저장
   - 하나가 실패해도 나머지 결과와 실패 원인을 표시

버전
- Main: 수익형 v2.13.2092
- Paper: paper_bot_v2.063
- Review: review_worker_v2.039
- Strategy: strategy_worker_v2.030
- Guard: guard_v2.6.9
- 자동매수: OFF
- 기존 OPEN 변경 없음
- 과거 원장 재작성 없음
