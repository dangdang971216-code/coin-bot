import json
from pathlib import Path
manifest=json.loads(Path("DEPLOY_BUNDLE.json").read_text(encoding="utf-8"))
assert manifest["release"]=="v1273"
assert manifest["actual_trading_changed"] is False
assert manifest["core_ledger_original_deleted"] is False
assert manifest["guard"]=="backga_guard_bot_v2_5_251.py"
assert manifest["guard_ledger_verify_command"]=="/gledger_v1273"
assert "ledger_events_pending/V1273_ISSUE_LEDGER_EVENTS.jsonl" in manifest["ledger_event_files"]["issue"]
