from pathlib import Path
code=Path("backga_guard_bot_v2_5_251.py").read_text(encoding="utf-8")
assert "guard_v2.5.251_v1273_storage_cold_archive_prune" in code
assert "def gstorage_archive_3d_text" in code
assert "def gledger_v1273_text" in code
assert "core ledger protected" in code
assert "v1270 보호 기준 변경 없음" in code
assert "paper_bot_closed.jsonl" in code
