v1273 저장공간 압축보관 정리판

적용 후 먼저 실행:
/gstorage_archive_3d

검수:
/gdeploy
/grelease_verify
/gdeep_audit
/gledger_v1273

핵심 원장 원본 삭제 없음. 전략·v1270 보호 기준 변경 없음.
