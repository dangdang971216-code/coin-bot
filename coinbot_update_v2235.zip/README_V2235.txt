현재 실행 중인 Guard는 같은 명령 안에서 새 Guard 코드를 사용할 수 없습니다.
v2235 적용 후 /gguard_restart 1회, 그 다음 기존 v2234 ZIP을 다시 적용합니다.
