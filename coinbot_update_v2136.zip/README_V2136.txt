v2136: 새 전략 독립 Paper exact
- 전체 atomic 후보판 직접 입력
- 기존 selector 선택 0과 무관
- 기존 숫자 안전조건 유지
- 별도 exact OPEN/CLOSED
- 현재 청산계약 유지
- 순위·미보정 EV 기록 전용
- 실제 주문 0, 자동매수 OFF
