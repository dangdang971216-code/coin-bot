v1359 OLD_BASE_REBUILD version-floor apply fix. Old-base behavior with monotonic runtime labels. Auto-buy OFF. No live ledgers included.
