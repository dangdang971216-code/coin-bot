from __future__ import annotations
import importlib.util, json, os, shutil, tempfile, time
from pathlib import Path

ROOT=Path(__file__).resolve().parent

def load(name,path):
    spec=importlib.util.spec_from_file_location(name,path)
    mod=importlib.util.module_from_spec(spec); spec.loader.exec_module(mod); return mod

def write_json(path,obj):
    path.write_text(json.dumps(obj,ensure_ascii=False),encoding='utf-8')

def candidate(i,scale=1.0):
    now=time.time(); price=100.0+i*0.01; trigger=99.8+i*0.01; invalid=98.4+i*0.01; target=104.0+i*0.01
    return {
      'ticker':f'T{i:03d}','price':price,'entry_price':price,'open_eligible':True,'swing_quality_rank_score':70*scale,
      'price_reaction_pct':0.8*scale,'relative_strength_pct':1.2*scale,'money_flow_score':70*scale,'buy_ratio':0.65*scale,'buy_sustain_1m':0.7*scale,
      'swing_quality_gate':{'hard_pass':True,'rank_score':70*scale,'confirmation_count':3},
      'swing_entry_gate_v977':{'hard_pass':True,'risk_reward':2.5*scale,'target_room_pct':4.0*scale,'spread_pct':0.25/scale,'confirmed_slippage_pct':0.05/scale,'decision_key':f'dec-{i}',
        'invalid_price':invalid,'target_price':target,
        'structure_plan':{'frozen_ts':now-10,'trigger':{'source':'execution_resistance','source_key':'m15_high','tf':'15m','rounded_price':trigger},'invalid':{'source':'setup_support','source_key':'h1_low','tf':'1h','rounded_price':invalid},'target':{'source':'major_resistance','source_key':'h4_high','tf':'4h','rounded_price':target}}},
      'trigger_occurrence_v1037':{'event_ts':now-5,'candidate_key':f'cand-{i}','contract_ready_at_cross':True},
      'strategy':'leader_flow' if i%2 else 'breakout',
    }

def closed(i,epoch):
    r=candidate(i); r.update({'performance_epoch_id':epoch,'opened_at':time.time()-100,'closed_at':time.time()-10,'mfe_pct':2.2,'mae_pct':-1.0,'net_pnl_pct':0.7,'giveback_pct':1.5,'hold_sec':90}); return r

def main():
    td=Path(tempfile.mkdtemp(prefix='v1141_'))
    try:
      for fn in ('strategy_worker_v1.013.py','review_worker_v1.008.py','coinbot_main_v2_13_1108.py','backga_guard_bot_v2_5_182.py'):
        shutil.copy2(ROOT/fn,td/fn)
      os.environ['TRADING_BOT_DIR']=str(td)
      os.environ['GUARD_BOT_TOKEN']='dummy'
      os.environ['GUARD_CHAT_ID']='1'
      os.environ['BOT_DIR']=str(td)
      rows=[candidate(i) for i in range(40)]
      epoch='post-reset:test'
      closed_rows=[closed(i,epoch) for i in range(35)]
      write_json(td/'paper_bot_control.json',{'candidate_ttl_sec':120,'max_open_strict':30,'max_new_per_cycle':3,'new_open_paused':False,'swing_emergency_stop_pct':-2.5,'swing_no_progress_minutes':360,'swing_trailing_trigger_pct':2.0,'swing_trailing_giveback_pct':0.8,'time_exit_minutes':0})
      write_json(td/'paper_bot_status.json',{'version':'paper_bot_v1.024','updated_ts':time.time()})
      write_json(td/'paper_quality_rebuild_epoch_v1095.json',{'epoch_id':epoch,'state':'ACTIVE'})
      write_json(td/'clean_market_regime_cache.json',{'mode':'NORMAL','breadth_pct':55,'market_strength':1.1})
      write_json(td/'clean_quality_policy_comparison_status_v1125.json',{'state':'EVIDENCE_READY','tracked_records':100,'false_pass_60m_count':8,'false_block_60m_count':2,'verdict':'CURRENT_STABLE'})
      write_json(td/'clean_structure_lab_review_status_v956.json',{'state':'ACTIVE'})
      write_json(td/'clean_strategy_worker_status.json',{'last_sec':12.3,'version':'strategy_worker_v1.013'})
      write_json(td/'canonical_performance_snapshot_v987.json',{'rows':closed_rows})
      write_json(td/'paper_bot_open.json',[])
      (td/'paper_candidates_latest.jsonl').write_text('\n'.join(json.dumps(x,ensure_ascii=False) for x in rows)+'\n',encoding='utf-8')
      s=load('smod',td/'strategy_worker_v1.013.py'); s.BASE_DIR=td; s.CANDIDATE_STANDARD_CONTRACT_V1141=td/'clean_candidate_standard_contract_v1141.json'; s._v1141_write_candidate_standard_contract()
      r=load('rmod',td/'review_worker_v1.008.py'); r.BASE_DIR=td
      # rebind file constants used by the new board
      for name,fn in {
       'CANDIDATE_STANDARD_CONTRACT_V1141':'clean_candidate_standard_contract_v1141.json','CANDIDATE_STANDARD_STATUS_V1141':'candidate_standard_status_v1141.json','CANDIDATE_STANDARD_BASELINE_STATE_V1141':'candidate_standard_baseline_state_v1141.json','CANDIDATE_STANDARD_BASELINE_LEDGER_V1141':'candidate_standard_baseline_ledger_v1141.jsonl','CANDIDATE_STANDARD_DECISION_LEDGER_V1141':'candidate_standard_decision_ledger_v1141.jsonl','PAPER_CONTROL_V1141':'paper_bot_control.json','PAPER_STATUS_V1141':'paper_bot_status.json','STRATEGY_STATUS_V1141':'clean_strategy_worker_status.json','PERFORMANCE_EPOCH_V1141':'paper_quality_rebuild_epoch_v1095.json','QUALITY_POLICY_V1141':'clean_quality_policy_comparison_status_v1125.json','STRUCTURE_REVIEW_V1141':'clean_structure_lab_review_status_v956.json','PAPER_LATEST':'paper_candidates_latest.jsonl','OPEN':'paper_bot_open.json','REGIME':'clean_market_regime_cache.json','CANONICAL_PERFORMANCE_V987':'canonical_performance_snapshot_v987.json','STATUS':'clean_review_worker_status.json','ERROR':'clean_review_worker_error.log'}.items(): setattr(r,name,td/fn)
      pending=r.update_candidate_standard_v1141(time.time(),rows[:5],[])
      assert pending['final_judgement']['state']=='CHECK_SAMPLE',pending['final_judgement']
      assert not pending['baseline_identity']['baseline_id'],pending['baseline_identity']
      board=r.update_candidate_standard_v1141(time.time(),rows,closed_rows)
      assert board['contract_identity']['state']=='SAME',board['contract_identity']
      assert board['final_judgement']['state']=='NORMAL',board['final_judgement']
      assert len(board.keys())>=20
      assert board['section_completeness']['total']==13 and board['section_completeness']['all_sections_present'] is True
      assert board['operations_separate']['strategy_cycle_sec']==12.3
      assert board['source_performance']['group_count']>=1 and board['structure_outcomes']['combination_count']>=1
      assert 'fresh_closed_plus_open' in board['book_performance']
      # Source hash change alone must also be a system regression.
      c=json.loads((td/'clean_candidate_standard_contract_v1141.json').read_text()); c['strategy_source_sha256']='changed-source-hash'; write_json(td/'clean_candidate_standard_contract_v1141.json',c)
      board_hash=r.update_candidate_standard_v1141(time.time(),rows,closed_rows)
      assert board_hash['final_judgement']['state']=='SYSTEM_REGRESSION',board_hash['final_judgement']
      s._v1141_write_candidate_standard_contract(); r._JSON_CYCLE_CACHE.clear()
      # Contract change must dominate market blame.
      c=json.loads((td/'clean_candidate_standard_contract_v1141.json').read_text()); c['contract_digest']='changed'; write_json(td/'clean_candidate_standard_contract_v1141.json',c)
      board2=r.update_candidate_standard_v1141(time.time(),rows,closed_rows)
      assert board2['final_judgement']['state']=='SYSTEM_REGRESSION',board2['final_judgement']
      # Restore contract then degrade candidate axes.
      s._v1141_write_candidate_standard_contract(); r._JSON_CYCLE_CACHE.clear()
      bad=[candidate(i,0.5) for i in range(40)]
      board3=r.update_candidate_standard_v1141(time.time(),bad,closed_rows)
      assert board3['final_judgement']['state'] in ('CANDIDATE_DEGRADED','EXECUTION_DEGRADED','MIXED'),board3['final_judgement']
      # Main render contains every major section.
      m=load('mmod',td/'coinbot_main_v2_13_1108.py'); m.BASE_DIR=td; m.CANDIDATE_STANDARD_STATUS_V1141=td/'candidate_standard_status_v1141.json'
      rendered=m.render_candidate_standard_text()
      for token in ('[구조선 생성·선택 계약]','[구조조합별 fresh 성과]','[후보 품질 · Gate 통과군]','[유입경로별 fresh CLOSED 성과]','[Gate 선별력]','[실제 진입 품질]','[청산 품질]','[CLOSED + 현재 OPEN]','[시장 상태]','[동일시장 shadow 대조군]','[13개 기준판 포함상태]','[최종 원인판정]'):
        assert token in rendered,token
      # Guard reads the same board.
      (td/'guard.env').write_text(f'BOT_DIR={td}\n',encoding='utf-8')
      g=load('gmod',td/'backga_guard_bot_v2_5_182.py'); g.BOT_DIR=td
      gc=g._ops_candidate_standard_contract_v1141(time.time())
      assert gc['baseline_id'] and gc['final_judgement']==board3['final_judgement']['state'],gc
      assert gc['section_total']==13 and gc['section_all_present'] is True,gc
      print(json.dumps({'ok':True,'baseline_id':board['baseline_identity']['baseline_id'],'normal':board['final_judgement']['state'],'pending':pending['final_judgement']['state'],'source_hash_change':board_hash['final_judgement']['state'],'contract_change':board2['final_judgement']['state'],'degraded':board3['final_judgement']['state'],'sections':len(board),'render_chars':len(rendered),'guard_state':gc['state']},ensure_ascii=False))
    finally:
      shutil.rmtree(td,ignore_errors=True)

if __name__=='__main__': main()
