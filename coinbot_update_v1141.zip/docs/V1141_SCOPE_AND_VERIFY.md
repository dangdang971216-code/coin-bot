# v1141 후보·구조 기준판 단일 완성판

## 목적
승률 변화만 보고 코드 회귀, 후보 품질 저하, 구조선/trigger timing 문제, 실행비용, 청산 문제, 시장 악화를 혼동하지 않도록 현재 ALT_SWING 계약과 비교 기준을 한 번에 봉인한다.

## 한 번에 포함되는 13개 구역
1. 기준 신원·Strategy version/hash/digest
2. 구조선 생성·선택 계약과 실제 source/timeframe proof
3. 구조 생성→trigger→품질→S1→Paper→OPEN 시간경로
4. 후보 품질 분포와 baseline 대비 변화
5. 후보 유입경로 비중 및 fresh CLOSED 성과
6. Gate false-pass / false-block / same-market shadow
7. 실제 진입 품질(RR, room, invalid, chase, spread, slippage, occurrence age)
8. 청산 품질(MFE, MAE, giveback, touch→close, 수익→손실)
9. fresh CLOSED + 현재 OPEN 단순 합산과 계좌가중 SOURCE_MISSING 분리
10. 시장상태
11. 동일시장 current/improved shadow 대조군
12. 최종 원인판정
13. append-only baseline/decision 변경이력

모든 구역은 항상 출력한다. 값이 없으면 숨기거나 0으로 채우지 않고 SOURCE_MISSING 또는 COLLECTING으로 표시한다.

## 구조선 계약
- 4h/2h: 큰 방향과 주요 target. major resistance 우선, setup resistance fallback.
- 1h/30m: setup과 structural invalid. 현재가/trigger 아래 가장 가까운 setup/major support.
- 15m/5m: 완료봉 execution resistance와 fully-ready below→above rebreak trigger.
- 1m·호가·체결: 실제 진입가, spread, slippage, freshness만 확인하며 구조선을 다시 그리지 않음.
- 실제 진입 owner는 ALT_SWING_V977_FROZEN_PLAN.
- A/B/C/D/E Structure Lab은 관찰 전용이며 entry gate에 사용하지 않음.

## 기준 잠금
- 후보 snapshot 30개 이상과 Strategy contract가 있어야 baseline ID를 만든다.
- baseline은 append-only이며 자동 교체하지 않는다.
- Strategy digest/version/source hash 중 하나라도 기준과 다르면 SYSTEM_REGRESSION.
- SYSTEM_REGRESSION이면 MARKET_BAD 단독판정을 금지한다.
- fresh CLOSED 30 미만은 수익성 COLLECTING/CHECK, 60부터 방향판정, 100부터 새 baseline 검토만 가능하다.

## 최종 판정
NORMAL / SYSTEM_REGRESSION / STRUCTURE_DEGRADED / TRIGGER_TIMING_DEGRADED / CANDIDATE_DEGRADED / EXECUTION_DEGRADED / EXIT_DEGRADED / MARKET_BAD / SOURCE_CONCENTRATED / MIXED / CHECK_SAMPLE / CHECK_SOURCE

## 파일 owner
- Strategy: immutable contract writer
- Review: read-only full board, baseline state, append-only baseline/decision ledgers
- Guard: 전체지도 anomaly와 owner 연결
- Main: `/candidate_standard`, `/candidate_standard_full`, `/flow_map_full` 표시
- Paper: 변경 없음

## 성능 안전
Review 집계는 60초 cadence로 제한한다. Strategy의 active cache/Gate/진입·청산 출력은 변경하지 않는다.
