from __future__ import annotations
import ast,hashlib,json
from collections import Counter
from pathlib import Path
ROOT=Path(__file__).resolve().parent
BASE=json.loads((ROOT/'BASELINE_FUNCTION_HASHES_V1140.json').read_text(encoding='utf-8'))
NEW={
 'strategy_worker_v1.012.py':'strategy_worker_v1.013.py',
 'review_worker_v1.007.py':'review_worker_v1.008.py',
 'coinbot_main_v2_13_1107.py':'coinbot_main_v2_13_1108.py',
 'backga_guard_bot_v2_5_181.py':'backga_guard_bot_v2_5_182.py',
}
def tree(path): return ast.parse(path.read_text(encoding='utf-8'))
def functions(path):
    c=Counter()
    for node in tree(path).body:
        if isinstance(node,(ast.FunctionDef,ast.AsyncFunctionDef)):
            h=hashlib.sha256(ast.dump(node,include_attributes=False).encode()).hexdigest(); c[f'{node.name}|{h}']+=1
    return c
def assignments(path,names):
    out={}
    for node in tree(path).body:
        if isinstance(node,ast.Assign):
            for target in node.targets:
                if isinstance(target,ast.Name) and target.id in names:
                    try: out[target.id]=ast.literal_eval(node.value)
                    except Exception: pass
    return out
def main():
    preserved={}
    for old,new in NEW.items():
        before=Counter(BASE[old]['functions']); after=functions(ROOT/new); missing=before-after
        assert not missing,f'{old}->{new} changed original functions: {list(missing.items())[:5]}'
        preserved[f'{old}->{new}']=sum(before.values())
    locks=set(BASE['locked_strategy_constants']); actual=assignments(ROOT/'strategy_worker_v1.013.py',locks)
    assert actual==BASE['locked_strategy_constants'],(actual,BASE['locked_strategy_constants'])
    strategy=(ROOT/'strategy_worker_v1.013.py').read_text(encoding='utf-8')
    for token in ("'strategy_thresholds_changed':False","'entry_contract_changed':False","'exit_contract_changed':False","'open_limit_changed':False","'auto_buy':False"):
        assert token in strategy,token
    review=(ROOT/'review_worker_v1.008.py').read_text(encoding='utf-8')
    for token in ('candidate_standard_baseline_ledger_v1141.jsonl','candidate_standard_decision_ledger_v1141.jsonl',"'append_only':True",'SYSTEM_REGRESSION','STRUCTURE_DEGRADED','TRIGGER_TIMING_DEGRADED','CANDIDATE_DEGRADED','EXECUTION_DEGRADED','EXIT_DEGRADED','MARKET_BAD','SOURCE_CONCENTRATED','MIXED','CHECK_SAMPLE','CHECK_SOURCE'):
        assert token in review,token
    print(json.dumps({'ok':True,'preserved_top_level_functions':preserved,'locked_strategy_constants':actual,'paper_changed':False,'auto_buy':False},ensure_ascii=False,sort_keys=True))
if __name__=='__main__': main()
