from __future__ import annotations
import hashlib,json
from pathlib import Path
ROOT=Path(__file__).resolve().parent
m=json.loads((ROOT/'DEPLOY_BUNDLE.json').read_text(encoding='utf-8'))
assert m['version']=='v1141' and m['auto_buy'] is False and m['live_ledger_included'] is False
assert m['main']=='coinbot_main_v2_13_1108.py'
assert m['guard']=='backga_guard_bot_v2_5_182.py'
assert m['workers']=={'strategy':'strategy_worker_v1.013.py','review':'review_worker_v1.008.py'}
assert not m.get('paper') and m['paper_source_change'] is False and m['paper_restart_required'] is False
assert m['strategy_behavior_change'] is False and m['baseline_auto_replacement'] is False
for f in [m['main'],m['guard'],*m['workers'].values(),*m['support_files']]:
    assert (ROOT/f).is_file(),f
for forbidden in ('paper_bot.py','paper_bot_v1.024.py','paper_bot_open.json','paper_bot_closed.jsonl','paper_trade_log.json','paper_decision_state_v926.json','canonical_performance_snapshot_v987.json','change_verify_ledger.jsonl','issue_ledger.jsonl','candidate_standard_baseline_ledger_v1141.jsonl','candidate_standard_decision_ledger_v1141.jsonl'):
    assert not (ROOT/forbidden).exists(),forbidden
rows=(ROOT/'FILES_SHA256_v1141.tsv').read_text(encoding='utf-8').splitlines()
for row in rows[1:]:
    h,size,name=row.split('\t',2); p=ROOT/name
    assert p.stat().st_size==int(size),name
    assert hashlib.sha256(p.read_bytes()).hexdigest()==h,name
print('PASS v1141 extracted bundle manifest/hash/no-live-ledger/full-board contract')
