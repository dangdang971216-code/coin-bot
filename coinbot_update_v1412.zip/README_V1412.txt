v1412: v1400에서 v1401로 갈 때 했던 수정만 새 번호로 재발행.
- 목적: v1400 partial apply 수리(전체 identity apply + 서비스 재시작 + status 검수)
- 제외: v1405~v1411 디스크/ACK/async/가드흐름 실험
- 전략수치/자동매수 변경 없음
