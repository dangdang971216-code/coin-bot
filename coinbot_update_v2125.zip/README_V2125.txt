v2125: 실제 빠른배포 Paper 재시작의 권한복구 우회 제거, systemd User/Group 기준 stop-repair-start, Paper Telegram 단일 owner와 update_id 영속화. 전략·후보·수치·청산 미변경. LOCAL DONE / SERVER CHECK / 자동매수 OFF.
