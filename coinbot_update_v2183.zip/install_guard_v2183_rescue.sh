#!/usr/bin/env bash
set -euo pipefail
cd /home/dangdang971216/trading_bot
install -m 0644 backga_guard_bot_v2_6_42.py backga_guard_bot_v2_6_42.py
cp -f backga_guard_bot_v2_6_42.py backga_guard_bot.py
printf '%s\n' 'backga_guard_bot_v2_6_42.py' > .deployed_guard
python3 -m py_compile backga_guard_bot_v2_6_42.py backga_guard_bot.py
systemctl restart tradingbot-guard.service
