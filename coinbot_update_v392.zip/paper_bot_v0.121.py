#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
paper_bot_v0.43.py

새 페이퍼봇 신축판.
- 전략 판단 없음.
- 재스캔 없음.
- candidate_events 읽기/소비/fallback 없음.
- paper_candidates.jsonl / shadow_candidates.jsonl만 소비한다.
- 기존 OPEN/CLOSED 장부는 유지한다.
"""
from __future__ import annotations

import argparse
import json
import os
import re
import signal
import sys
import threading
import time
import traceback
import urllib.parse
import urllib.request
from collections import Counter, deque, defaultdict
from datetime import datetime, timezone, timedelta
from pathlib import Path
from typing import Any, Dict, Iterable, List, Optional, Tuple

VERSION = "paper_bot_v0.66"
BASE_DIR = Path(__file__).resolve().parent

TOKEN = os.getenv("PAPER_BOT_TOKEN", os.getenv("TELEGRAM_TOKEN", "")).strip()
# v0.23: 가드봇이 직접 실행할 때 PAPER_BOT_ALLOWED_CHAT_ID가 빠지는 경우가 있어
# GUARD_CHAT_ID까지 안전 fallback으로 사용한다.
ALLOWED_CHAT_ID = (
    os.getenv("PAPER_BOT_ALLOWED_CHAT_ID", "").strip()
    or os.getenv("PAPER_BOT_CHAT_ID", "").strip()
    or os.getenv("CHAT_ID", "").strip()
    or os.getenv("GUARD_CHAT_ID", "").strip()
)
NOTIFY_CHAT_ID = (
    os.getenv("PAPER_BOT_NOTIFY_CHAT_ID", "").strip()
    or ALLOWED_CHAT_ID
)

FILES = {
    "paper_candidates": BASE_DIR / "paper_candidates.jsonl",
    "shadow_candidates": BASE_DIR / "shadow_candidates.jsonl",
    "paper_latest": BASE_DIR / "paper_candidates_latest.jsonl",
    "shadow_latest": BASE_DIR / "shadow_candidates_latest.jsonl",
    "shadow_quarantine": BASE_DIR / "paper_bot_shadow_quarantine.jsonl",
    "legacy_strict_quarantine": BASE_DIR / "paper_bot_legacy_strict_quarantine.jsonl",
    "open": BASE_DIR / "paper_bot_open.json",
    "closed": BASE_DIR / "paper_bot_closed.jsonl",
    "status": BASE_DIR / "paper_bot_status.json",
    "control": BASE_DIR / "paper_bot_control.json",
    "baseline": BASE_DIR / "paper_eval_baseline_v167.json",
    "error": BASE_DIR / "paper_bot_error.log",
    "log": BASE_DIR / "paper_bot.log",
    "pid": BASE_DIR / "paper_bot.pid",
    "flag": BASE_DIR / "external_paper_bot_on.flag",
    "legacy_flag": BASE_DIR / "external_paper_runner_on.flag",
    "alert_state": BASE_DIR / "paper_bot_alert_state.json",
    "micro_urgent": BASE_DIR / "clean_micro_urgent_targets.json",
}

DEFAULT_CONTROL = {
    "running": False,
    "loop_seconds": 8,
    "max_open_strict": 0,  # v0.72: paper 검증은 고정 개수 제한 없음(0=무제한, 서버 보호는 별도)
    "max_open_shadow": 0,  # shadow는 복기 전용이라 OPEN하지 않는다
    "max_new_per_cycle": 0,  # 0 = 신규 후보를 작은 숫자로 자르지 않음
    "new_open_paused": False,  # v0.64: sweep_vwap_recovery 단일 전략 paper OPEN 재개
    "open_trade_ready_only": True,
    "track_strict_observe": True,
    "notify_on_strict_open": True,
    "notify_on_strict_close": True,
    "notify_on_shadow": False,
    "notify_real_trades_only": True,
    "notify_open_auto_ready_only": True,
    "notify_open_min_score": 4.45,
    "notify_open_require_final_pass": True,
    "notify_open_require_micro_fresh": True,
    "preopen_micro_recheck": True,
    "preopen_micro_urgent_ttl_sec": 35,
    "preopen_micro_recheck_max_targets": 40,
    "notify_open_require_ws_fresh": False,
    "notify_close_only_alerted": True,
    "notify_recheck_summary": True,
    "recheck_summary_interval_sec": 3600,
    "recheck_summary_max_rows": 8,
    "open_shadow_positions": False,  # v0.27 기본값: shadow는 OPEN하지 않고 복기 전용
    "shadow_review_only": True,
    "quarantine_shadow_open": True,
    "quarantine_legacy_strict_open": True,
    "consume_latest_candidate_files": True,
    "consume_latest_scan_only": True,
    "latest_scan_window_sec": 8,
    "fee_pct_roundtrip": 0.10,
    "take_profit_pct": 1.20,
    "protect_trigger_pct": 0.70,
    "protect_floor_pct": 0.30,
    "stop_loss_pct": -0.55,

    # v0.50: OPEN 포지션 손실 방어. 후보 읽기는 8초 유지, OPEN 감시는 더 촘촘히 본다.
    "open_monitor_interval_sec": 1.5,
    "hard_loss_guard_enabled": True,
    "hard_loss_guard_pct": -0.95,
    "long_loss_guard_enabled": False,
    "long_loss_guard_min_age_sec": 900,
    "long_loss_guard_current_under_pct": -0.45,
    "long_loss_guard_peak_under_pct": 0.60,
    "slow_minutes": 20,
    "slow_peak_under_pct": 0.25,
    # v0.47: 실제 paper 청산모드. 기존 stop/take/slow는 유지하고, 반응 없는 후보만 먼저 정리한다.
    "quick_stop_enabled": False,
    "quick_stop_min_age_sec": 90,
    "quick_stop_max_age_sec": 600,
    "quick_stop_peak_under_pct": 0.20,
    "quick_stop_current_under_pct": -0.35,
    "quick_stop_weak_buy_ratio": 0.50,
    "quick_stop_wide_spread_pct": 0.25,
    "slow_early_enabled": False,
    "slow_early_minutes": 10,
    "slow_early_peak_under_pct": 0.10,
    "slow_early_current_under_pct": 0.05,
    "slow_early_pullback_under": 1.00,
    "slow_early_weak_buy_ratio": 0.50,
    "slow_early_low_money3_krw": 15_000_000,
    "time_exit_minutes": 15,
    "block_same_ticker_open": True,
    "candidate_ttl_sec": 120,
    "candidate_read_max_lines": 800,
}

# 구 control 파일에 남아 있을 수 있는 candidate_events 옵션은 v0.21에서 강제 무시한다.
REMOVED_CONTROL_KEYS = {"allow_shadow_from_candidate_events"}

_stop_event = threading.Event()
_STOP_REASON = "running"
_state_lock = threading.RLock()
_update_offset = 0
_bad_markets: set[str] = set()
_symbols_cache: Dict[str, Any] = {"ts": 0.0, "symbols": set()}
_recent_errors = deque(maxlen=20)
PROGRAM_STARTED_TS = time.time()


def now() -> float:
    return time.time()


KST = timezone(timedelta(hours=9))
TIMEZONE_LABEL = "Asia/Seoul"

def iso_ts(ts: Optional[float] = None) -> str:
    """모든 사용자-facing 시간은 한국시간(KST)으로 표시한다.

    기존 서버가 UTC로 도는 경우 알림 시간이 실제 차트/텔레그램 체감시간보다 9시간 늦게 보였다.
    timestamp 자체는 그대로 보존하고, 문자열 표시만 KST로 통일한다.
    """
    return datetime.fromtimestamp(ts or now(), KST).strftime("%Y-%m-%d %H:%M:%S")


def float_any(*vals: Any, default: float = 0.0) -> float:
    for v in vals:
        if v is None:
            continue
        try:
            if isinstance(v, str):
                v = v.replace(",", "").replace("%", "").strip()
            x = float(v)
            if x == x:
                return x
        except Exception:
            continue
    return default


def append_line(path: Path, text: str) -> None:
    try:
        path.parent.mkdir(parents=True, exist_ok=True)
        with path.open("a", encoding="utf-8") as f:
            f.write(str(text).rstrip("\n") + "\n")
    except Exception:
        pass


def log(msg: str) -> None:
    append_line(FILES["log"], f"[{iso_ts()}] {msg}")


def log_error(where: str, exc: BaseException) -> None:
    msg = f"{where}: {exc.__class__.__name__}: {exc}"
    _recent_errors.append(msg[:300])
    try:
        append_line(FILES["error"], f"[{iso_ts()}] {msg}")
        append_line(FILES["error"], traceback.format_exc())
    except Exception:
        pass


def load_json(path: Path, default: Any) -> Any:
    try:
        if not path.exists():
            return default
        return json.loads(path.read_text(encoding="utf-8", errors="ignore"))
    except Exception as exc:
        log_error(f"load_json:{path.name}", exc)
        return default


def save_json(path: Path, obj: Any) -> None:
    """v0.72: 단일 JSON 저장 입구.

    이전 방식은 모든 writer가 같은 <file>.tmp를 공유해서, 명령어와 loop가
    동시에 paper_bot_control.json을 저장하면 한쪽 os.replace 뒤 다른 쪽 tmp가
    사라지는 FileNotFoundError가 날 수 있었다. 고유 tmp로 원인을 제거한다.
    """
    try:
        path = Path(path)
        path.parent.mkdir(parents=True, exist_ok=True)
        tid = threading.get_ident() if 'threading' in globals() else 0
        tmp = path.with_name(f".{path.name}.{os.getpid()}.{tid}.{time.time_ns()}.tmp")
        tmp.write_text(json.dumps(obj, ensure_ascii=False, indent=2, default=str), encoding="utf-8")
        os.replace(tmp, path)
    except Exception as exc:
        log_error(f"save_json:{path.name}", exc)


def load_control() -> Dict[str, Any]:
    control = DEFAULT_CONTROL.copy()
    saved = load_json(FILES["control"], {})
    if isinstance(saved, dict):
        for k, v in saved.items():
            if k in REMOVED_CONTROL_KEYS:
                continue
            if k in DEFAULT_CONTROL:
                control[k] = v
    # v0.27 고정: candidate_events 소비 옵션은 저장돼 있어도 다시 만들지 않는다.
    for k in REMOVED_CONTROL_KEYS:
        control.pop(k, None)

    # v0.27: 후보 분석은 제한하지 않되, 실제 paper OPEN은 자동매매 검증 슬롯처럼 보호한다.
    # 구 control에 과거 80/120/160/9999 같은 값이 남아 있으면 0(고정한도 없음)으로 정리한다.
    changed = False
    try:
        mos = int(float(control.get("max_open_strict", 30)))
        if mos < 0 or mos in {80, 120, 160, 9999} or mos > 60:
            control["max_open_strict"] = 0
            changed = True
    except Exception:
        control["max_open_strict"] = 0
        changed = True
    try:
        if int(float(control.get("max_open_shadow", 0))) != 0:
            control["max_open_shadow"] = 0
            changed = True
    except Exception:
        control["max_open_shadow"] = 0
        changed = True
    try:
        mn = int(float(control.get("max_new_per_cycle", 0)))
        # v0.27: 9999 같은 구값은 “사실상 제한 없음”으로 보이지만 설정판을 헷갈리게 하므로 0으로 정리한다.
        if mn in {24, 80, 120, 160, 9999} or mn < 0:
            control["max_new_per_cycle"] = 0
            changed = True
    except Exception:
        control["max_new_per_cycle"] = 0
        changed = True
    if control.get("consume_latest_scan_only") is not True:
        control["consume_latest_scan_only"] = True
        changed = True
    if control.get("consume_latest_candidate_files") is not True:
        control["consume_latest_candidate_files"] = True
        changed = True
    if control.get("quarantine_legacy_strict_open") is not True:
        control["quarantine_legacy_strict_open"] = True
        changed = True
    if control.get("open_trade_ready_only") is not True:
        control["open_trade_ready_only"] = True
        changed = True
    if control.get("track_strict_observe") is not True:
        control["track_strict_observe"] = True
        changed = True
    # v0.64: sweep_vwap_recovery 단일 전략만 신규 모의매매 OPEN을 허용한다.
    if control.get("new_open_paused") is not False:
        control["new_open_paused"] = False
        changed = True
    try:
        # v0.27: paper_bot은 *_latest 후보파일을 우선 읽는다. 큰 archive 파일을 매 cycle 읽지 않는다.
        if int(float(control.get("candidate_read_max_lines", 0))) > 1200 or int(float(control.get("candidate_read_max_lines", 0))) <= 0:
            control["candidate_read_max_lines"] = 800
            changed = True
    except Exception:
        control["candidate_read_max_lines"] = 800
        changed = True
    if changed:
        try:
            save_json(FILES["control"], control)
        except Exception:
            pass
    return control


def save_control(updates: Dict[str, Any]) -> Dict[str, Any]:
    control = load_control()
    for k, v in updates.items():
        if k in REMOVED_CONTROL_KEYS:
            continue
        if k in DEFAULT_CONTROL:
            control[k] = v
    save_json(FILES["control"], control)
    set_pause_flags(bool(control.get("running")))
    return control


def set_pause_flags(on: bool) -> None:
    for key in ["flag", "legacy_flag"]:
        p = FILES[key]
        try:
            if on:
                p.write_text(f"paper_bot_on {iso_ts()}\n", encoding="utf-8")
            else:
                p.unlink(missing_ok=True)
        except Exception as exc:
            log_error(f"set_flag:{key}", exc)


def read_jsonl(path: Path, max_lines: int = 5000) -> List[Dict[str, Any]]:
    if not path.exists():
        return []
    try:
        lines = path.read_text(encoding="utf-8", errors="ignore").splitlines()[-max_lines:]
        out = []
        for line in lines:
            line = line.strip()
            if not line:
                continue
            try:
                obj = json.loads(line)
                if isinstance(obj, dict):
                    out.append(obj)
            except Exception:
                continue
        return out
    except Exception as exc:
        log_error(f"read_jsonl:{path.name}", exc)
        return []


def append_jsonl(path: Path, obj: Dict[str, Any]) -> None:
    append_line(path, json.dumps(obj, ensure_ascii=False, separators=(",", ":"), default=str))


def line_count(path: Path) -> int:
    try:
        if not path.exists():
            return 0
        with path.open("r", encoding="utf-8", errors="ignore") as f:
            return sum(1 for _ in f)
    except Exception:
        return -1




def ensure_eval_baseline() -> Dict[str, Any]:
    data = load_json(FILES["baseline"], {})
    if isinstance(data, dict) and float_any(data.get("baseline_ts"), default=0.0) > 0:
        return data
    data = {
        "schema": "paper_eval_baseline_v157",
        "created_by": VERSION,
        "baseline_ts": now(),
        "baseline_text": iso_ts(),
        "closed_lines_at_baseline": line_count(FILES["closed"]),
        "paper_lines_at_baseline": line_count(FILES["paper_candidates"]),
        "shadow_lines_at_baseline": line_count(FILES["shadow_candidates"]),
        "note": "기존 OPEN/CLOSED는 삭제하지 않고, 기준점 이후 신규만 분리 표시한다.",
    }
    save_json(FILES["baseline"], data)
    return data


def baseline_ts() -> float:
    return float_any(ensure_eval_baseline().get("baseline_ts"), default=0.0)


def row_ts(row: Dict[str, Any], *keys: str) -> float:
    for k in keys:
        v = float_any((row or {}).get(k), default=0.0)
        if v > 0:
            return v
    return 0.0


def rows_since_baseline(rows: Iterable[Dict[str, Any]], *keys: str) -> List[Dict[str, Any]]:
    bts = baseline_ts()
    return [r for r in rows or [] if row_ts(r, *keys) >= bts]


def open_split_since_baseline(open_pos: Optional[Dict[str, Dict[str, Any]]] = None) -> Tuple[int, int, Dict[str, int], Dict[str, int]]:
    open_pos = open_pos if isinstance(open_pos, dict) else load_open()
    bts = baseline_ts()
    new_counts = {"strict": 0, "shadow": 0}
    old_counts = {"strict": 0, "shadow": 0}
    for p in (open_pos or {}).values():
        lane = str((p or {}).get("lane") or "shadow")
        target = new_counts if float_any((p or {}).get("opened_at"), default=0.0) >= bts else old_counts
        target[lane] = target.get(lane, 0) + 1
    return sum(new_counts.values()), sum(old_counts.values()), new_counts, old_counts


def candidate_is_fresh(ev: Dict[str, Any], control: Dict[str, Any]) -> bool:
    nowv = now()
    exp = float_any((ev or {}).get("expires_at"), default=0.0)
    created = float_any((ev or {}).get("created_at"), default=0.0)
    ttl = float_any(control.get("candidate_ttl_sec"), default=120.0)
    if exp > 0:
        return exp >= nowv
    if created > 0:
        return (nowv - created) <= ttl
    return False


def candidate_fresh_stats(path: Path, control: Optional[Dict[str, Any]] = None) -> Dict[str, int]:
    control = control or load_control()
    rows = read_jsonl(path, max_lines=int(float_any(control.get("candidate_read_max_lines"), default=2500)))
    fresh = sum(1 for r in rows if candidate_is_fresh(r, control))
    return {"read_window": len(rows), "fresh": fresh, "expired": max(0, len(rows) - fresh)}

def normalize_ticker(ticker: Any) -> Optional[str]:
    if not ticker:
        return None
    t = str(ticker).strip().upper().replace("/", "-").replace("_", "-")
    parts = [x for x in t.split("-") if x]
    if len(parts) >= 2:
        non_krw = [x for x in parts if x != "KRW"]
        return (non_krw[-1] if non_krw else parts[-1]).strip().upper() or None
    if t.endswith("KRW") and len(t) > 3:
        t = t[:-3]
    return t.strip().upper() or None


def short_ticker(ticker: Any) -> str:
    return normalize_ticker(ticker) or str(ticker or "").strip().upper()


def get_event_price(event: Dict[str, Any]) -> float:
    return float_any(event.get("entry_price"), event.get("detected_price"), event.get("current_price"), event.get("price"), event.get("close"), event.get("trade_price"), default=0.0)


def event_id(event: Dict[str, Any], lane: str) -> str:
    raw = event.get("event_id") or event.get("id") or event.get("event_key")
    t = normalize_ticker(event.get("ticker") or event.get("market") or event.get("symbol") or "") or "UNKNOWN"
    ts = event.get("created_at") or event.get("detected_ts") or event.get("ts") or event.get("time") or event.get("timestamp") or "0"
    decision = event.get("decision") or event.get("quality_category") or event.get("alert_bucket") or ""
    if raw:
        return f"{lane}:{raw}"
    return f"{lane}:{t}:{ts}:{decision}"


def load_open() -> Dict[str, Dict[str, Any]]:
    obj = load_json(FILES["open"], {})
    return obj if isinstance(obj, dict) else {}


def save_open(open_pos: Dict[str, Dict[str, Any]]) -> None:
    save_json(FILES["open"], open_pos)


def candidate_input_path(lane: str) -> Path:
    """paper_bot은 작은 latest 파일을 우선 소비한다. 없으면 기존 archive를 fallback으로만 읽는다."""
    try:
        if lane == "strict" and load_control().get("consume_latest_candidate_files", True) and FILES.get("paper_latest", Path("")) .exists():
            return FILES["paper_latest"]
        if lane == "shadow" and load_control().get("consume_latest_candidate_files", True) and FILES.get("shadow_latest", Path("")) .exists():
            return FILES["shadow_latest"]
    except Exception:
        pass
    return FILES["paper_candidates"] if lane == "strict" else FILES["shadow_candidates"]


def quarantine_shadow_open_positions(open_pos: Dict[str, Dict[str, Any]], control: Dict[str, Any]) -> Tuple[Dict[str, Dict[str, Any]], int]:
    """기존 shadow OPEN을 삭제하지 않고 격리 파일로 보존한 뒤 active OPEN에서 제외한다.
    shadow는 복기 전용이므로 더 이상 paper_bot cycle을 200~300개씩 붙잡지 않게 한다.
    """
    if not control.get("quarantine_shadow_open", True) or control.get("open_shadow_positions", False):
        return open_pos, 0
    kept: Dict[str, Dict[str, Any]] = {}
    moved = 0
    ts = now()
    for pid, pos in (open_pos or {}).items():
        lane = str((pos or {}).get("lane") or "shadow")
        if lane == "shadow":
            row = dict(pos or {})
            row["quarantined_at"] = ts
            row["quarantined_at_text"] = iso_ts(ts)
            row["quarantine_reason"] = "v0.28_shadow_review_only"
            append_jsonl(FILES["shadow_quarantine"], row)
            moved += 1
        else:
            kept[pid] = pos
    return kept, moved




def quarantine_legacy_strict_open_positions(open_pos: Dict[str, Dict[str, Any]], control: Dict[str, Any]) -> Tuple[Dict[str, Dict[str, Any]], int]:
    """v0.27: trade_ready 분리 전 열렸던 기존 strict OPEN은 삭제하지 않고 격리한다.
    목적은 새 기준 이후 trade_ready만 깨끗하게 모의매매하기 위한 active OPEN 정리다.
    """
    if not control.get("quarantine_legacy_strict_open", True):
        return open_pos, 0
    kept: Dict[str, Dict[str, Any]] = {}
    moved = 0
    ts = now()
    bts = baseline_ts()
    for pid, pos in (open_pos or {}).items():
        lane = str((pos or {}).get("lane") or "shadow")
        opened_at = float_any((pos or {}).get("opened_at"), default=0.0)
        is_trade_ready = bool((pos or {}).get("trade_ready") or (pos or {}).get("paper_bot_open") or (pos or {}).get("open_eligible"))
        # v0.26 이전에 strict로 열린 기존분이 active 슬롯을 막는 문제를 방지한다.
        if lane == "strict" and (opened_at < bts or not is_trade_ready):
            row = dict(pos or {})
            row["quarantined_at"] = ts
            row["quarantined_at_text"] = iso_ts(ts)
            row["quarantine_reason"] = "v0.28_legacy_strict_before_trade_ready_split"
            append_jsonl(FILES["legacy_strict_quarantine"], row)
            moved += 1
        else:
            kept[pid] = pos
    return kept, moved

def load_closed_ids(limit: int = 15000) -> set[str]:
    ids = set()
    for obj in read_jsonl(FILES["closed"], max_lines=limit):
        eid = obj.get("event_id") or obj.get("pos_id")
        if eid:
            ids.add(str(eid))
    return ids


def closed_count() -> int:
    return line_count(FILES["closed"])


def count_by_lane(open_pos: Dict[str, Dict[str, Any]]) -> Dict[str, int]:
    counts = {"strict": 0, "shadow": 0}
    for p in open_pos.values():
        lane = str(p.get("lane") or "shadow")
        counts[lane] = counts.get(lane, 0) + 1
    return counts


def open_tickers(open_pos: Dict[str, Dict[str, Any]]) -> set[str]:
    return {short_ticker(p.get("ticker")) for p in open_pos.values() if short_ticker(p.get("ticker"))}


def fetch_symbols(timeout: float = 2.0) -> set[str]:
    try:
        now_ts = now()
        cached = _symbols_cache.get("symbols")
        if cached and now_ts - float_any(_symbols_cache.get("ts"), default=0.0) < 1800:
            return set(cached)
        req = urllib.request.Request("https://api.bithumb.com/public/ticker/ALL_KRW", headers={"Accept":"application/json", "User-Agent":VERSION})
        with urllib.request.urlopen(req, timeout=timeout) as resp:
            data = json.loads(resp.read().decode("utf-8", errors="ignore"))
        rows = data.get("data") if isinstance(data, dict) else {}
        symbols = {str(k).upper() for k, v in rows.items() if isinstance(v, dict)} if isinstance(rows, dict) else set()
        symbols.discard("DATE")
        if symbols:
            _symbols_cache["ts"] = now_ts
            _symbols_cache["symbols"] = symbols
        return symbols
    except Exception:
        return set()


def fetch_bithumb_price(ticker: Any, timeout: float = 2.5) -> Optional[float]:
    sym = normalize_ticker(ticker)
    if not sym:
        return None
    if sym in _bad_markets:
        return None
    symbols = fetch_symbols(timeout=1.8)
    if symbols and sym not in symbols:
        _bad_markets.add(sym)
        return None
    urls = [
        f"https://api.bithumb.com/public/ticker/{urllib.parse.quote(sym)}_KRW",
        f"https://api.bithumb.com/public/ticker/{urllib.parse.quote(sym)}/KRW",
    ]
    for url in urls:
        try:
            req = urllib.request.Request(url, headers={"Accept":"application/json", "User-Agent":VERSION})
            with urllib.request.urlopen(req, timeout=timeout) as resp:
                data = json.loads(resp.read().decode("utf-8", errors="ignore"))
            if isinstance(data, dict) and str(data.get("status")) == "0000":
                row = data.get("data") or {}
                price = float_any(row.get("closing_price"), row.get("trade_price"), row.get("close"), default=0.0)
                return price if price > 0 else None
            if isinstance(data, dict) and str(data.get("status")) not in {"0000", "None", ""}:
                _bad_markets.add(sym)
                return None
        except urllib.error.HTTPError as exc:
            if exc.code == 404:
                _bad_markets.add(sym)
                return None
            log_error("fetch_price_http", exc)
            return None
        except Exception as exc:
            log_error("fetch_price", exc)
            return None
    return None




def _fetch_all_bithumb_prices_direct(timeout: float = 4.0) -> Dict[str, float]:
    """Bithumb ALL_KRW direct fetch. v0.45 cached wrapper below uses this only when TTL expired."""
    try:
        url = "https://api.bithumb.com/public/ticker/ALL_KRW"
        req = urllib.request.Request(url, headers={"Accept": "application/json", "User-Agent": VERSION})
        with urllib.request.urlopen(req, timeout=timeout) as resp:
            data = json.loads(resp.read().decode("utf-8"))
        rows = data.get("data") if isinstance(data, dict) else {}
        out: Dict[str, float] = {}
        if isinstance(rows, dict):
            for k, v in rows.items():
                if str(k).upper() == "DATE" or not isinstance(v, dict):
                    continue
                sym = normalize_ticker(k)
                px = float_any(v.get("closing_price"), v.get("trade_price"), v.get("close"), default=0.0)
                if sym and px > 0:
                    out[sym] = px
        return out
    except Exception as exc:
        log(f"bulk_price_fetch_failed: {exc.__class__.__name__}")
        return {}


def fetch_all_bithumb_prices(timeout: float = 4.0) -> Dict[str, float]:
    """v0.45: cycle마다 ALL_KRW를 무조건 치던 경로를 TTL 캐시로 정리한다.

    장부/청산조건은 그대로 유지한다. 네트워크가 느린 순간에는 직전 가격맵을 쓰고,
    그래도 없을 때만 빈 dict를 반환해 기존 개별 조회 fallback을 탄다.
    """
    nowv = now()
    try:
        cached = _PRICE_MAP_CACHE.get("rows") if isinstance(_PRICE_MAP_CACHE.get("rows"), dict) else {}
        if cached and nowv - float_any(_PRICE_MAP_CACHE.get("ts"), default=0.0) <= CYCLE_PRICE_CACHE_TTL_SEC:
            return dict(cached)
        rows = _fetch_all_bithumb_prices_direct(timeout=timeout)
        if rows:
            _PRICE_MAP_CACHE.update({"ts": nowv, "rows": dict(rows), "source": "fresh"})
            return rows
        if cached:
            _PRICE_MAP_CACHE["source"] = "stale_after_fetch_fail"
            return dict(cached)
        return {}
    except Exception as exc:
        log_error("fetch_all_prices_cached", exc)
        cached = _PRICE_MAP_CACHE.get("rows") if isinstance(_PRICE_MAP_CACHE.get("rows"), dict) else {}
        return dict(cached) if cached else {}

_CYCLE_PRICE_MAP: Dict[str, float] = {}

_PRICE_MAP_CACHE: Dict[str, Any] = {"ts": 0.0, "rows": {}}
CYCLE_PRICE_CACHE_TTL_SEC = float(os.getenv("PAPER_BOT_PRICE_CACHE_TTL_SEC", "12"))
_CLOSED_NEW_TOTAL_CACHE: Dict[str, Any] = {"ts": 0.0, "count": None, "file_size": -1, "mtime": 0.0}
CLOSED_NEW_TOTAL_CACHE_TTL_SEC = float(os.getenv("PAPER_BOT_CLOSED_NEW_CACHE_TTL_SEC", "60"))
_FILE_STATS_CACHE: Dict[str, Any] = {"ts": 0.0, "stats": None}
FILE_STATS_CACHE_TTL_SEC = float(os.getenv("PAPER_BOT_FILE_STATS_CACHE_TTL_SEC", "45"))


def cycle_live_price(ticker: Any) -> Optional[float]:
    sym = normalize_ticker(ticker)
    if not sym:
        return None
    px = _CYCLE_PRICE_MAP.get(sym)
    if px and px > 0:
        return px
    return fetch_bithumb_price(sym)

def latest_scan_filter(events: List[Dict[str, Any]], control: Dict[str, Any]) -> Tuple[List[Dict[str, Any]], Dict[str, Any]]:
    """고정 갯수 제한이 아니라 최신 scan 묶음만 소비한다.
    후보파일에 과거 TTL 유효 후보가 많이 남아 있어도 paper_bot이 한꺼번에 몰아먹지 않게 한다.
    scan_id가 있으면 최신 scan_id만, 없으면 최신 created_at 근처만 사용한다.
    """
    meta = {"enabled": bool(control.get("consume_latest_scan_only", True)), "latest_scan_id": "", "latest_ts": 0.0, "before": len(events), "after": len(events)}
    if not meta["enabled"] or not events:
        return events, meta
    # scan_id가 있는 새 후보는 scan_id 기준이 가장 안전하다.
    scan_rows = [e for e in events if e.get("scan_id")]
    if scan_rows:
        def key(e: Dict[str, Any]):
            return (float_any(e.get("created_at"), default=0.0), str(e.get("scan_id") or ""))
        latest = max(scan_rows, key=key)
        sid = str(latest.get("scan_id") or "")
        out = [e for e in events if str(e.get("scan_id") or "") == sid]
        meta.update({"latest_scan_id": sid, "latest_ts": float_any(latest.get("created_at"), default=0.0), "after": len(out)})
        return out, meta
    # 구 후보는 created_at 최신 묶음만 허용한다.
    latest_ts = max(float_any(e.get("created_at"), default=0.0) for e in events)
    win = max(1.0, float_any(control.get("latest_scan_window_sec"), default=8.0))
    out = [e for e in events if float_any(e.get("created_at"), default=0.0) >= latest_ts - win]
    meta.update({"latest_ts": latest_ts, "after": len(out)})
    return out, meta


def _ctx_from_event(ev: Dict[str, Any]) -> Dict[str, Any]:
    if isinstance((ev or {}).get("entry_context"), dict):
        return (ev or {}).get("entry_context") or {}
    if isinstance((ev or {}).get("profile"), dict):
        return (ev or {}).get("profile") or {}
    return ev if isinstance(ev, dict) else {}


def _event_micro_is_fresh(ev: Dict[str, Any]) -> bool:
    ctx = _ctx_from_event(ev)
    if bool((ev or {}).get("micro_fresh")) or bool(ctx.get("micro_fresh")):
        return True
    st = str((ev or {}).get("micro_row_status") or ctx.get("micro_row_status") or "").lower()
    return st == "fresh"


def _write_micro_urgent_targets(rows: List[Dict[str, Any]], reason: str = "paper_preopen_micro_stale", control: Optional[Dict[str, Any]] = None) -> None:
    try:
        limit = int(float_any((control or {}).get("preopen_micro_recheck_max_targets"), default=40))
        ttl = float_any((control or {}).get("preopen_micro_urgent_ttl_sec"), default=35.0)
        tickers: List[str] = []
        meta: Dict[str, Any] = {}
        for r in rows or []:
            t = normalize_ticker((r or {}).get("ticker") or (r or {}).get("market") or (r or {}).get("symbol"))
            if not t or t in tickers:
                continue
            tickers.append(t)
            meta[t] = {
                "source": "paper_preopen",
                "score": float_any((r or {}).get("score"), default=0.0),
                "reason": reason,
                "trade_ready": bool((r or {}).get("paper_bot_open") or (r or {}).get("open_eligible") or (r or {}).get("trade_ready")),
            }
            if len(tickers) >= max(1, limit):
                break
        if not tickers:
            return
        save_json(FILES["micro_urgent"], {
            "version": VERSION,
            "source": "paper_bot_v0.45",
            "reason": reason,
            "updated_ts": now(),
            "updated_at": iso_ts(),
            "ttl_sec": ttl,
            "targets": tickers,
            "target_meta": meta,
            "note": "paper OPEN 직전 micro stale 후보를 바로 장부에 태우지 않고 micro sidecar 최우선 재확인 대상으로 보냄",
        })
    except Exception as exc:
        log_error("write_micro_urgent_targets", exc)


def pick_candidates(control: Dict[str, Any], open_pos: Dict[str, Dict[str, Any]]) -> Tuple[List[Tuple[str, Dict[str, Any]]], Dict[str, int]]:
    existing_ids = set(open_pos.keys()) | load_closed_ids()
    blocked_tickers = open_tickers(open_pos) if control.get("block_same_ticker_open", True) else set()
    picked: List[Tuple[str, Dict[str, Any]]] = []
    stats = {
        "paper_file": 0,
        "shadow_file": 0,
        "events_file": 0,
        "dup_skip": 0,
        "same_ticker_skip": 0,
        "bad_skip": 0,
        "limit_skip": 0,
        "stale_skip": 0,
        "strict_observe_skip": 0,
        "not_trade_ready_skip": 0,
        "micro_preopen_wait": 0,
        "new_open_paused": 0,
    }
    if control.get("new_open_paused", True):
        stats["new_open_paused"] = 1
        return [], stats
    lane_counts = count_by_lane(open_pos)
    micro_wait_rows: List[Dict[str, Any]] = []
    max_strict = int(float_any(control.get("max_open_strict"), default=0))
    max_shadow = int(float_any(control.get("max_open_shadow"), default=0))
    max_new = int(float_any(control.get("max_new_per_cycle"), default=0))
    # 0 이하는 고정 갯수 제한 없음. paper_bot은 전략 판단을 하지 않고, TTL 유효 후보를 장부에 태운다.
    strict_cap_on = max_strict > 0
    shadow_cap_on = max_shadow > 0
    new_cap_on = max_new > 0

    def try_pick(ev: Dict[str, Any], lane: str) -> None:
        if new_cap_on and len(picked) >= max_new:
            return
        if strict_cap_on and lane == "strict" and lane_counts.get("strict", 0) >= max_strict:
            stats["limit_skip"] += 1
            return
        if shadow_cap_on and lane == "shadow" and lane_counts.get("shadow", 0) >= max_shadow:
            stats["limit_skip"] += 1
            return
        if not candidate_is_fresh(ev, control):
            stats["stale_skip"] += 1
            return
        if lane == "strict" and control.get("open_trade_ready_only", True):
            can_open = bool(ev.get("paper_bot_open") or ev.get("open_eligible") or ev.get("trade_ready"))
            if not can_open:
                stats["strict_observe_skip"] += 1
                stats["not_trade_ready_skip"] += 1
                return
        if lane == "strict" and control.get("preopen_micro_recheck", True) and bool(ev.get("paper_bot_open") or ev.get("open_eligible") or ev.get("trade_ready")):
            if not _event_micro_is_fresh(ev):
                stats["micro_preopen_wait"] += 1
                micro_wait_rows.append(dict(ev))
                return
        eid = event_id(ev, lane)
        if eid in existing_ids:
            stats["dup_skip"] += 1
            return
        t = normalize_ticker(ev.get("ticker") or ev.get("market") or ev.get("symbol"))
        price = get_event_price(ev)
        if not t or price <= 0:
            stats["bad_skip"] += 1
            return
        if control.get("block_same_ticker_open", True) and t in blocked_tickers:
            stats["same_ticker_skip"] += 1
            return
        ev = dict(ev)
        ev["lane"] = lane
        picked.append((eid, ev))
        existing_ids.add(eid)
        blocked_tickers.add(t)
        lane_counts[lane] = lane_counts.get(lane, 0) + 1

    read_max = int(float_any(control.get("candidate_read_max_lines"), default=2500))
    paper_events = read_jsonl(candidate_input_path("strict"), max_lines=read_max)
    shadow_events = read_jsonl(candidate_input_path("shadow"), max_lines=read_max)
    open_shadow = bool(control.get("open_shadow_positions", False))
    combined: List[Tuple[str, Dict[str, Any]]] = [("strict", ev) for ev in paper_events]
    if open_shadow:
        combined += [("shadow", ev) for ev in shadow_events]
    else:
        # v0.27: shadow는 복기 전용. OPEN 장부에 태우지 않는다.
        stats["shadow_file"] = len(shadow_events)
        stats["shadow_review_only_skip"] = len(shadow_events)
    filtered_events, meta = latest_scan_filter([dict(ev, _lane_hint=lane) for lane, ev in combined], control)
    stats["latest_scan_before"] = int(meta.get("before", len(combined)))
    stats["latest_scan_after"] = int(meta.get("after", len(filtered_events)))
    stats["latest_scan_id"] = str(meta.get("latest_scan_id") or "")

    # 최신 scan 묶음 안에서는 strict만 OPEN한다. shadow는 파일에는 남기되 복기 전용이다.
    for ev in filtered_events:
        if new_cap_on and len(picked) >= max_new:
            break
        lane = str(ev.pop("_lane_hint", ev.get("lane") or "shadow"))
        if lane == "shadow" and not open_shadow:
            stats["shadow_review_only_skip"] = stats.get("shadow_review_only_skip", 0) + 1
            continue
        if lane == "strict":
            stats["paper_file"] += 1
        else:
            stats["shadow_file"] += 1
        try_pick(ev, lane)

    # candidate_events는 v0.21에서 완전 제거. 읽지도 세지도 않는다.
    stats["events_file"] = 0
    if micro_wait_rows:
        _write_micro_urgent_targets(micro_wait_rows, reason="paper_preopen_micro_stale", control=control)
    return picked, stats


ENTRY_CONTEXT_KEYS = [
    "score", "edge", "edge_score",
    "live_price_source", "live_price", "live_age_sec", "ws_fresh", "ws_row_status", "ws_age_sec", "ws_targeted", "ws_cache_ts", "ws_turnover", "ws_volume", "current_price_ws_gap_pct",
    "micro_fresh", "micro_row_status", "micro_age_sec", "micro_targeted", "micro_spread_pct", "micro_bid_ask_wall_ratio",
    "micro_trade_buy_ratio_30", "micro_trade_buy_krw_30", "micro_trade_sell_krw_30",
    "micro_ask_wall_pressure", "micro_sell_trade_pressure", "micro_flags",
    "change_1", "change_3", "change_5", "change_15", "change_30",
    "vol_ratio", "turnover_1m", "turnover_3m", "turnover_5m", "turnover_24h", "money_flow",
    "money_flow_1m", "money_flow_3m", "money_flow_5m", "real_money_flow_status",
    "from_30m_low_pct", "below_30m_high_pct", "pullback_depth_pct", "low_defense_pct",
    "recovery_speed_pct", "rebreakout_strength", "fake_bounce_score", "pullback_quality_score",
    "major_watch", "major_watch_label", "rank_best", "current_close_pos_ratio", "current_upper_wick_pct",
    "rsi_14", "vwap_gap_pct", "ma5_gap_pct", "ema5_gap_pct", "ema12_gap_pct", "ema21_gap_pct",
    "bb_position", "bb_lower_gap_pct", "bb_middle_gap_pct", "mfi_14", "cci_20", "stoch_k", "stoch_d",
    "stoch_cross_up", "adx_14", "atr_1m_pct", "atr_3m_pct", "current_move_vs_atr", "avg_price_turn_pct", "v_rebound_score", "volume_spike_30x", "volume_pump_risk",
    "brain_version", "created_at", "created_at_text", "final_entry_action", "final_entry_label", "final_entry_reasons", "final_slow_hits", "final_stop_hits", "market_pressure", "market_context", "quality_risk_tags",
    "liquidity_grade", "slippage_risk", "tick_risk",
    "tick_pct_est", "chase_risk", "price_recheck_pct", "orderbook_spread_pct", "execution_risk_status",
    "execution_risk_flags", "auto_ready_level", "auto_ready_label", "trade_ready_label", "trade_ready_reasons",
    "data_age_sec", "freshness", "current_candle_code", "current_candle_label",
    "external_refreshed_by", "snapshot_overlay_ts", "snapshot_refresh_attempt", "snapshot_refresh_attempt_total",
    "micro_urgent_requested", "micro_urgent_source", "micro_urgent_status_at_request",
    "micro_urgent_age_sec", "micro_urgent_age_sec_at_request", "micro_urgent_updated_ts",
    "candidate_grade_label", "hold_reason",
]


def _external_status_from_ctx(ctx: Dict[str, Any], kind: str) -> str:
    if not isinstance(ctx, dict):
        return "missing"
    if kind == "micro":
        if bool(ctx.get("micro_fresh")) or str(ctx.get("micro_row_status") or "").lower() == "fresh":
            return "fresh"
        st = str(ctx.get("micro_row_status") or "").lower()
        return "stale" if st in {"stale", "old", "오래됨"} else "missing"
    if kind == "ws":
        if bool(ctx.get("ws_fresh")) or str(ctx.get("ws_row_status") or "").lower() == "fresh":
            return "fresh"
        st = str(ctx.get("ws_row_status") or "").lower()
        return "stale" if st in {"stale", "old", "오래됨"} else "missing"
    return "missing"


def _external_closed_fields_from_ctx(ctx: Dict[str, Any]) -> Dict[str, Any]:
    ctx = ctx if isinstance(ctx, dict) else {}
    micro_status = _external_status_from_ctx(ctx, "micro")
    ws_status = _external_status_from_ctx(ctx, "ws")
    urgent_used = bool(ctx.get("micro_urgent_requested") or ctx.get("urgent_recheck_used"))
    urgent_result = "fresh" if urgent_used and micro_status == "fresh" else ("not_fresh" if urgent_used else "not_requested")
    return {
        "micro_entry_status": micro_status,
        "ws_entry_status": ws_status,
        "urgent_recheck_used": urgent_used,
        "urgent_recheck_result": urgent_result,
        "micro_urgent_requested": bool(ctx.get("micro_urgent_requested")),
        "micro_urgent_source": ctx.get("micro_urgent_source"),
        "micro_urgent_status_at_request": ctx.get("micro_urgent_status_at_request"),
        "micro_urgent_age_sec_at_request": ctx.get("micro_urgent_age_sec_at_request"),
        "ws_row_status": ctx.get("ws_row_status"),
        "ws_age_sec": ctx.get("ws_age_sec"),
        "ws_targeted": ctx.get("ws_targeted"),
        "current_price_ws_gap_pct": ctx.get("current_price_ws_gap_pct"),
        "micro_targeted": ctx.get("micro_targeted"),
        "micro_age_sec": ctx.get("micro_age_sec"),
        "entry_external_context_version": "paper_bot_v0.43",
    }


def entry_context_from_event(ev: Dict[str, Any]) -> Dict[str, Any]:
    """진입 당시 이미 알 수 있던 재료만 저장한다.
    청산사유 같은 사후 결과와 분리해서 후보품질 분석에 쓴다.
    """
    ctx: Dict[str, Any] = {
        "captured_at": now(),
        "captured_at_text": iso_ts(),
        "source": "candidate_event_at_open",
    }
    raw_profile = ev.get("profile") if isinstance(ev.get("profile"), dict) else {}
    for key in ENTRY_CONTEXT_KEYS:
        val = ev.get(key)
        if val is None and raw_profile:
            val = raw_profile.get(key)
        if val is not None:
            ctx[key] = val
    # 품질 분석에서 자주 쓰는 alias도 같이 저장한다.
    if "change_5" in ctx:
        ctx["change_5m"] = ctx.get("change_5")
    if "below_30m_high_pct" in ctx:
        ctx["below_high_pct"] = ctx.get("below_30m_high_pct")
    if "from_30m_low_pct" in ctx:
        ctx["from_low_pct"] = ctx.get("from_30m_low_pct")
    if "turnover_1m" in ctx and "money_flow_1m" not in ctx:
        ctx["money_flow_1m"] = ctx.get("turnover_1m")
    if "turnover_3m" in ctx and "money_flow_3m" not in ctx:
        ctx["money_flow_3m"] = ctx.get("turnover_3m")
    if "turnover_5m" in ctx and "money_flow_5m" not in ctx:
        ctx["money_flow_5m"] = ctx.get("turnover_5m")
    ctx.update(_external_closed_fields_from_ctx(ctx))
    ctx["captured_external_note"] = "v0.44: main snapshot/paper_latest에 반영된 micro/WS fresh 값과 진입/매도/보유시간을 OPEN/CLOSED 문맥으로 고정"
    return ctx



def exit_mode_from_context(ctx: Dict[str, Any], score: Any = 0.0) -> Dict[str, Any]:
    """v0.46: 실제 청산조건을 바꾸지 않고, 후보별 청산 관찰모드를 기록한다.

    목적:
    - KAIA처럼 강한 후보는 +1.2% 전량청산이 아쉬운지 추적할 재료를 남긴다.
    - 손절/지지부진으로 자주 끝나는 후보는 조기이탈 후보인지 분리할 재료를 남긴다.
    - 이 함수는 장부/청산 판단을 바꾸지 않는다. 기록/알림/분석용이다.
    """
    ctx = ctx if isinstance(ctx, dict) else {}
    score_v = float_any(score, ctx.get("score"), default=0.0)
    money3 = float_any(ctx.get("money_flow_3m") or ctx.get("turnover_3m"), default=0.0)
    pull = float_any(ctx.get("pullback_quality_score"), default=0.0)
    rebreak = float_any(ctx.get("rebreakout_strength"), default=0.0)
    spread = float_any(ctx.get("micro_spread_pct"), default=999.0)
    buy_ratio = float_any(ctx.get("micro_trade_buy_ratio_30"), default=0.0)
    wall_ratio = float_any(ctx.get("micro_bid_ask_wall_ratio"), default=0.0)
    micro_fresh = bool(ctx.get("micro_fresh")) or str(ctx.get("micro_row_status") or "").lower() == "fresh"
    ws_fresh = bool(ctx.get("ws_fresh")) or str(ctx.get("ws_row_status") or "").lower() == "fresh"
    risk_tags = ctx.get("quality_risk_tags") if isinstance(ctx.get("quality_risk_tags"), list) else []
    tags_text = " / ".join(str(x) for x in risk_tags)

    strong_hits = []
    if score_v >= 4.45:
        strong_hits.append("점수충족")
    if money3 >= 20_000_000:
        strong_hits.append("3분돈강함")
    if pull >= 1.80:
        strong_hits.append("눌림양호")
    if micro_fresh and spread <= 0.08:
        strong_hits.append("호가신선스프레드좁음")
    if buy_ratio >= 0.62:
        strong_hits.append("매수체결우세")
    if wall_ratio >= 1.50:
        strong_hits.append("매수벽우세")
    if ws_fresh:
        strong_hits.append("WS신선")

    weak_hits = []
    if (not micro_fresh) or spread >= 0.25:
        weak_hits.append("호가불리")
    if buy_ratio and buy_ratio < 0.45:
        weak_hits.append("매수체결약함")
    if wall_ratio and wall_ratio < 0.75:
        weak_hits.append("매수벽약함")
    if rebreak and rebreak < 1.20:
        weak_hits.append("재돌파힘약함")
    if any("위주" in str(x) or "약함" in str(x) for x in risk_tags):
        weak_hits.append("위험태그")

    if len(strong_hits) >= 5 and len(weak_hits) <= 1:
        mode = "strong_trailing_watch"
        label = "강한후보: 익절 후 더감 추적"
        note = "+1.2% 전량청산이 아쉬울 수 있어 청산 후 더감 여부를 관찰"
    elif len(weak_hits) >= 3:
        mode = "quick_cut_watch"
        label = "약한후보: 빠른손절 관찰"
        note = "초반 반응 없으면 -1.2% 전 조기이탈 후보인지 관찰"
    elif "재돌파힘 약함" in tags_text or rebreak < 1.20:
        mode = "slow_cut_watch"
        label = "지지부진 관찰"
        note = "돈흐름 대비 가격반응이 약하면 지지부진 조기종료 후보"
    else:
        mode = "normal_exit_watch"
        label = "보통후보: 기존청산 관찰"
        note = "기존 익절/손절/시간종료 기준 유지 관찰"
    return {
        "exit_mode": mode,
        "exit_mode_label": label,
        "exit_mode_note": note,
        "exit_mode_strong_hits": strong_hits[:8],
        "exit_mode_weak_hits": weak_hits[:8],
        "exit_mode_metrics": {
            "score": round(score_v, 3),
            "money_flow_3m": money3,
            "pullback_quality_score": pull,
            "rebreakout_strength": rebreak,
            "micro_spread_pct": spread,
            "micro_trade_buy_ratio_30": buy_ratio,
            "micro_bid_ask_wall_ratio": wall_ratio,
            "micro_fresh": micro_fresh,
            "ws_fresh": ws_fresh,
        },
    }


def exit_mode_line(row: Dict[str, Any]) -> str:
    mode = str((row or {}).get("exit_mode_label") or (row or {}).get("exit_mode") or "")
    note = str((row or {}).get("exit_mode_note") or "")
    if not mode:
        return "- 청산관찰: -"
    return f"- 청산관찰: {mode}" + (f" / {note}" if note else "")

def open_position(pos_id: str, ev: Dict[str, Any], control: Dict[str, Any]) -> Dict[str, Any]:
    ticker = normalize_ticker(ev.get("ticker") or ev.get("market") or ev.get("symbol")) or "UNKNOWN"
    detected_price = get_event_price(ev)
    live_price = cycle_live_price(ticker) or detected_price
    entry_price = live_price if live_price > 0 else detected_price
    lane = str(ev.get("lane") or "shadow")
    entry_ctx = entry_context_from_event(ev)
    exit_mode = exit_mode_from_context(entry_ctx, score=float_any(ev.get("score"), ev.get("leader_score"), default=0.0))
    entry_ctx.update(exit_mode)
    return {
        "pos_id": pos_id,
        "event_id": pos_id,
        "ticker": ticker,
        "lane": lane,
        "opened_at": now(),
        "opened_at_text": iso_ts(),
        "opened_brain_version": ev.get("brain_version") or (ev.get("profile") or {}).get("brain_version") if isinstance(ev.get("profile"), dict) else ev.get("brain_version"),
        "opened_paper_version": VERSION,
        "entry_price": entry_price,
        "detected_price": detected_price,
        "current_price": entry_price,
        "peak_pct": 0.0,
        "trough_pct": 0.0,
        "last_update": now(),
        "strategy": ev.get("strategy") or ev.get("route") or ev.get("section") or "unknown",
        "decision": ev.get("decision") or ev.get("quality_category") or "",
        "trade_ready": bool(ev.get("trade_ready") or ev.get("paper_bot_open") or ev.get("open_eligible")),
        "trade_ready_label": ev.get("trade_ready_label") or "",
        "trade_ready_reasons": ev.get("trade_ready_reasons") or [],
        "final_entry_action": ev.get("final_entry_action") or "paper_open",
        "final_entry_label": ev.get("final_entry_label") or ev.get("trade_ready_label") or "",
        "final_entry_reasons": ev.get("final_entry_reasons") or [],
        "scan_id": ev.get("scan_id") or "",
        "brain_version": ev.get("brain_version") or (ev.get("profile") or {}).get("brain_version") if isinstance(ev.get("profile"), dict) else ev.get("brain_version"),
        "source_created_at_text": ev.get("created_at_text") or "",
        "open_source": "trade_ready" if bool(ev.get("trade_ready") or ev.get("paper_bot_open") or ev.get("open_eligible")) else "unknown",
        "score": float_any(ev.get("score"), ev.get("leader_score"), default=0.0),
        "edge": float_any(ev.get("edge"), ev.get("edge_score"), default=0.0),
        "reason": ev.get("reason") or ev.get("why") or ev.get("block_reason") or "",
        "source_created_at": float_any(ev.get("created_at"), default=0.0),
        "source_expires_at": float_any(ev.get("expires_at"), default=0.0),
        "baseline_tag": "new" if now() >= baseline_ts() else "old",
        "exit_mode": exit_mode.get("exit_mode"),
        "exit_mode_label": exit_mode.get("exit_mode_label"),
        "exit_mode_note": exit_mode.get("exit_mode_note"),
        "exit_mode_strong_hits": exit_mode.get("exit_mode_strong_hits"),
        "exit_mode_weak_hits": exit_mode.get("exit_mode_weak_hits"),
        "entry_context": entry_ctx,
        "raw": ev,
    }



def _position_entry_ctx(pos: Dict[str, Any]) -> Dict[str, Any]:
    return (pos or {}).get("entry_context") if isinstance((pos or {}).get("entry_context"), dict) else {}


def _exit_rule_decision(pos: Dict[str, Any], control: Dict[str, Any], *, age_min: float, net: float, peak: float) -> Tuple[Optional[str], str]:
    """v0.48: 빠른손절/반등실패/지지부진 조기종료 판단.

    기존 익절/손절/보호청산/시간종료를 지우지 않는다.
    - quick_stop: 아예 초반 반응이 없는 후보
    - bounce_fail: +0.1~0.5% 정도 반응 후 다시 무너지는 후보
    - slow_early_exit: 10분 이상 시간만 쓰는 후보
    """
    ctx = _position_entry_ctx(pos)
    age_sec = max(0.0, age_min * 60.0)
    buy = float_any(ctx.get("micro_trade_buy_ratio_30"), default=0.0)
    spread = float_any(ctx.get("micro_spread_pct"), default=999.0)
    pull = float_any(ctx.get("pullback_quality_score"), default=0.0)
    money3 = float_any(ctx.get("money_flow_3m") or ctx.get("turnover_3m"), default=0.0)
    rebreak = float_any(ctx.get("rebreakout_strength"), default=0.0)
    price_recheck = float_any(ctx.get("price_recheck_pct"), default=0.0)
    sell_pressure = bool(ctx.get("micro_sell_trade_pressure") or ctx.get("micro_ask_wall_pressure"))
    drawdown_from_peak = max(0.0, peak - net)

    # 1) 아예 반응 없이 밀리는 후보: 기존 -1.2% 손절 전에 먼저 정리.
    if bool(control.get("quick_stop_enabled", True)):
        min_age = float_any(control.get("quick_stop_min_age_sec"), default=90.0)
        max_age = float_any(control.get("quick_stop_max_age_sec"), default=600.0)
        peak_under = float_any(control.get("quick_stop_peak_under_pct"), default=0.20)
        current_under = float_any(control.get("quick_stop_current_under_pct"), default=-0.35)
        weak_buy = float_any(control.get("quick_stop_weak_buy_ratio"), default=0.50)
        wide_spread = float_any(control.get("quick_stop_wide_spread_pct"), default=0.25)
        weak_reason = []
        if buy > 0 and buy <= weak_buy:
            weak_reason.append(f"매수비 {buy:.2f}")
        if spread < 900 and spread >= wide_spread:
            weak_reason.append(f"스프레드 {spread:.2f}%")
        if price_recheck < 0:
            weak_reason.append(f"가격재확인 {price_recheck:.2f}%")
        if sell_pressure:
            weak_reason.append("매도압박")
        if min_age <= age_sec <= max_age and peak <= peak_under and net <= current_under and weak_reason:
            return "quick_stop", f"진입 {int(age_sec)}초 / 최고 {peak:+.2f}% / 현재 {net:+.2f}% / " + ", ".join(weak_reason[:3])

    # 2) 조금 반등했다가 실패하는 후보: KAIA처럼 +0.2~0.4% 줬다가 크게 밀리는 유형.
    if bool(control.get("bounce_fail_enabled", True)):
        min_age = float_any(control.get("bounce_fail_min_age_sec"), default=300.0)
        max_age = float_any(control.get("bounce_fail_max_age_sec"), default=900.0)
        peak_min = float_any(control.get("bounce_fail_peak_min_pct"), default=0.12)
        peak_max = float_any(control.get("bounce_fail_peak_max_pct"), default=0.55)
        current_under = float_any(control.get("bounce_fail_current_under_pct"), default=-0.55)
        dd_min = float_any(control.get("bounce_fail_drawdown_from_peak_pct"), default=0.70)
        weak_buy = float_any(control.get("bounce_fail_weak_buy_ratio"), default=0.55)
        wide_spread = float_any(control.get("bounce_fail_wide_spread_pct"), default=0.20)
        fail_reason = []
        if buy > 0 and buy <= weak_buy:
            fail_reason.append(f"매수비 {buy:.2f}")
        if spread < 900 and spread >= wide_spread:
            fail_reason.append(f"스프레드 {spread:.2f}%")
        if price_recheck < 0:
            fail_reason.append(f"가격재확인 {price_recheck:.2f}%")
        if sell_pressure:
            fail_reason.append("매도압박")
        # 외부 약점이 뚜렷하지 않아도, 고점 대비 큰 되밀림 자체는 반등실패 신호로 본다.
        if min_age <= age_sec <= max_age and peak_min <= peak <= peak_max and net <= current_under and drawdown_from_peak >= dd_min:
            extra = (", " + ", ".join(fail_reason[:2])) if fail_reason else ""
            return "bounce_fail", f"진입 {int(age_sec)}초 / 최고 {peak:+.2f}% → 현재 {net:+.2f}% / 되밀림 {drawdown_from_peak:.2f}%{extra}"

    # 3) 시간만 쓰고 안 가는 후보: 기존 20분 지지부진 전 10분 부근에서 정리.
    if bool(control.get("slow_early_enabled", True)):
        min_min = float_any(control.get("slow_early_minutes"), default=10.0)
        peak_under = float_any(control.get("slow_early_peak_under_pct"), default=0.10)
        current_under = float_any(control.get("slow_early_current_under_pct"), default=0.05)
        pull_under = float_any(control.get("slow_early_pullback_under"), default=1.0)
        weak_buy = float_any(control.get("slow_early_weak_buy_ratio"), default=0.50)
        low_money = float_any(control.get("slow_early_low_money3_krw"), default=15_000_000.0)
        weak_reason = []
        if pull > 0 and pull < pull_under:
            weak_reason.append(f"눌림 {pull:.2f}")
        if buy > 0 and buy <= weak_buy:
            weak_reason.append(f"매수비 {buy:.2f}")
        if money3 > 0 and money3 < low_money:
            weak_reason.append(f"3분돈 {money3/10000:.0f}만")
        if rebreak > 0 and rebreak < 1.20:
            weak_reason.append(f"재돌파 {rebreak:.2f}")
        if age_min >= min_min and peak <= peak_under and net <= current_under and weak_reason:
            return "slow_early_exit", f"보유 {age_min:.1f}분 / 최고 {peak:+.2f}% / 현재 {net:+.2f}% / " + ", ".join(weak_reason[:3])

    return None, ""

def update_position(pos: Dict[str, Any], control: Dict[str, Any]) -> Tuple[Dict[str, Any], Optional[Dict[str, Any]]]:
    ticker = pos.get("ticker") or ""
    entry = float_any(pos.get("entry_price"), default=0.0)
    if entry <= 0:
        return pos, None
    price = cycle_live_price(ticker) or float_any(pos.get("current_price"), pos.get("entry_price"), default=entry)
    pos["current_price"] = price
    gross = ((price / entry) - 1.0) * 100.0
    net = gross - float_any(control.get("fee_pct_roundtrip"), default=0.10)
    pos["last_pnl_pct"] = net
    pos["peak_pct"] = max(float_any(pos.get("peak_pct"), default=0.0), net)
    pos["trough_pct"] = min(float_any(pos.get("trough_pct"), default=0.0), net)
    pos["last_update"] = now()

    age_min = (now() - float_any(pos.get("opened_at"), default=now())) / 60.0
    peak = float_any(pos.get("peak_pct"), default=0.0)
    exit_reason: Optional[str] = None
    exit_rule_reason = ""

    early_reason, early_note = _exit_rule_decision(pos, control, age_min=age_min, net=net, peak=peak)
    if early_reason:
        exit_reason = early_reason
        exit_rule_reason = early_note
    elif net <= float_any(control.get("stop_loss_pct"), default=-1.2):
        exit_reason = "stop_loss"
        exit_rule_reason = f"기존 손절선 도달: 현재 {net:+.2f}%"
    elif peak >= float_any(control.get("protect_trigger_pct"), default=0.9) and net <= float_any(control.get("protect_floor_pct"), default=0.2):
        exit_reason = "protect_stop_after_tp"
        exit_rule_reason = f"익절권 후 보호선: 최고 {peak:+.2f}% / 현재 {net:+.2f}%"
    elif net >= float_any(control.get("take_profit_pct"), default=1.2):
        exit_reason = "take_profit"
        exit_rule_reason = f"기존 익절선 도달: 현재 {net:+.2f}%"
    elif age_min >= float_any(control.get("slow_minutes"), default=20) and peak < float_any(control.get("slow_peak_under_pct"), default=0.25) and net <= 0.10:
        exit_reason = "slow_no_progress"
        exit_rule_reason = f"기존 지지부진: 보유 {age_min:.1f}분 / 최고 {peak:+.2f}% / 현재 {net:+.2f}%"
    elif age_min >= float_any(control.get("time_exit_minutes"), default=120):
        exit_reason = "time_exit"
        exit_rule_reason = f"기존 시간종료: 보유 {age_min:.1f}분"

    if not exit_reason:
        return pos, None

    closed_at_ts = now()
    opened_at_ts = float_any(pos.get("opened_at"), default=closed_at_ts)
    hold_sec = hold_seconds_from_rows(opened_at_ts, closed_at_ts)
    closed = {
        "closed_at": closed_at_ts,
        "closed_at_text": iso_ts(closed_at_ts),
        "pos_id": pos.get("pos_id"),
        "event_id": pos.get("event_id"),
        "ticker": ticker,
        "lane": pos.get("lane"),
        "opened_at": pos.get("opened_at"),
        "opened_at_text": pos.get("opened_at_text"),
        "opened_brain_version": pos.get("opened_brain_version") or pos.get("brain_version"),
        "opened_paper_version": pos.get("opened_paper_version") or VERSION,
        "brain_version": pos.get("brain_version") or (pos.get("raw") or {}).get("brain_version") if isinstance(pos.get("raw"), dict) else pos.get("brain_version"),
        "source_created_at_text": pos.get("source_created_at_text"),
        "open_source": pos.get("open_source"),
        "final_entry_action": pos.get("final_entry_action"),
        "final_entry_label": pos.get("final_entry_label"),
        "final_entry_reasons": pos.get("final_entry_reasons"),
        "exit_mode": pos.get("exit_mode") or ((pos.get("entry_context") or {}).get("exit_mode") if isinstance(pos.get("entry_context"), dict) else ""),
        "exit_mode_label": pos.get("exit_mode_label") or ((pos.get("entry_context") or {}).get("exit_mode_label") if isinstance(pos.get("entry_context"), dict) else ""),
        "exit_mode_note": pos.get("exit_mode_note") or ((pos.get("entry_context") or {}).get("exit_mode_note") if isinstance(pos.get("entry_context"), dict) else ""),
        "exit_mode_strong_hits": pos.get("exit_mode_strong_hits") or ((pos.get("entry_context") or {}).get("exit_mode_strong_hits") if isinstance(pos.get("entry_context"), dict) else []),
        "exit_mode_weak_hits": pos.get("exit_mode_weak_hits") or ((pos.get("entry_context") or {}).get("exit_mode_weak_hits") if isinstance(pos.get("entry_context"), dict) else []),
        "quality_risk_tags": (pos.get("entry_context") or {}).get("quality_risk_tags") if isinstance(pos.get("entry_context"), dict) else [],
        "entry_price": entry,
        "exit_price": price,
        "pnl_pct": round(net, 4),
        "peak_pct": round(peak, 4),
        "trough_pct": round(float_any(pos.get("trough_pct"), default=0.0), 4),
        "age_min": round(age_min, 2),
        "hold_sec": hold_sec,
        "hold_text": hold_text_from_seconds(hold_sec),
        "exit_reason": exit_reason,
        "exit_rule": exit_reason,
        "exit_rule_label": exit_reason_kr(exit_reason),
        "exit_rule_reason": exit_rule_reason,
        "close_trigger_age_sec": hold_sec,
        "early_peak_pct": round(peak, 4),
        "early_low_pct": round(float_any(pos.get("trough_pct"), default=0.0), 4),
        "strategy": pos.get("strategy"),
        "decision": pos.get("decision"),
        "score": pos.get("score"),
        "edge": pos.get("edge"),
        "scan_id": (pos.get("raw") or {}).get("scan_id") if isinstance(pos.get("raw"), dict) else "",
        "auto_ready_level": (pos.get("raw") or {}).get("auto_ready_level") if isinstance(pos.get("raw"), dict) else "",
        "auto_ready_label": (pos.get("raw") or {}).get("auto_ready_label") if isinstance(pos.get("raw"), dict) else "",
        "liquidity_grade": (pos.get("raw") or {}).get("liquidity_grade") if isinstance(pos.get("raw"), dict) else "",
        "slippage_risk": (pos.get("raw") or {}).get("slippage_risk") if isinstance(pos.get("raw"), dict) else "",
        "tick_risk": (pos.get("raw") or {}).get("tick_risk") if isinstance(pos.get("raw"), dict) else "",
        "chase_risk": (pos.get("raw") or {}).get("chase_risk") if isinstance(pos.get("raw"), dict) else "",
        "entry_context": pos.get("entry_context") if isinstance(pos.get("entry_context"), dict) else {},
        "change_5": (pos.get("entry_context") or {}).get("change_5") if isinstance(pos.get("entry_context"), dict) else None,
        "change_5m": (pos.get("entry_context") or {}).get("change_5m") if isinstance(pos.get("entry_context"), dict) else None,
        "below_30m_high_pct": (pos.get("entry_context") or {}).get("below_30m_high_pct") if isinstance(pos.get("entry_context"), dict) else None,
        "below_high_pct": (pos.get("entry_context") or {}).get("below_high_pct") if isinstance(pos.get("entry_context"), dict) else None,
        "from_30m_low_pct": (pos.get("entry_context") or {}).get("from_30m_low_pct") if isinstance(pos.get("entry_context"), dict) else None,
        "from_low_pct": (pos.get("entry_context") or {}).get("from_low_pct") if isinstance(pos.get("entry_context"), dict) else None,
        "vol_ratio": (pos.get("entry_context") or {}).get("vol_ratio") if isinstance(pos.get("entry_context"), dict) else None,
        "money_flow_1m": (pos.get("entry_context") or {}).get("money_flow_1m") if isinstance(pos.get("entry_context"), dict) else None,
        "money_flow_3m": (pos.get("entry_context") or {}).get("money_flow_3m") if isinstance(pos.get("entry_context"), dict) else None,
        "money_flow_5m": (pos.get("entry_context") or {}).get("money_flow_5m") if isinstance(pos.get("entry_context"), dict) else None,
        "pullback_quality_score": (pos.get("entry_context") or {}).get("pullback_quality_score") if isinstance(pos.get("entry_context"), dict) else None,
        "rebreakout_strength": (pos.get("entry_context") or {}).get("rebreakout_strength") if isinstance(pos.get("entry_context"), dict) else None,
        "fake_bounce_score": (pos.get("entry_context") or {}).get("fake_bounce_score") if isinstance(pos.get("entry_context"), dict) else None,
        "ema5_gap_pct": (pos.get("entry_context") or {}).get("ema5_gap_pct") if isinstance(pos.get("entry_context"), dict) else None,
        "ema12_gap_pct": (pos.get("entry_context") or {}).get("ema12_gap_pct") if isinstance(pos.get("entry_context"), dict) else None,
        "ema21_gap_pct": (pos.get("entry_context") or {}).get("ema21_gap_pct") if isinstance(pos.get("entry_context"), dict) else None,
        "bb_position": (pos.get("entry_context") or {}).get("bb_position") if isinstance(pos.get("entry_context"), dict) else None,
        "bb_lower_gap_pct": (pos.get("entry_context") or {}).get("bb_lower_gap_pct") if isinstance(pos.get("entry_context"), dict) else None,
        "bb_middle_gap_pct": (pos.get("entry_context") or {}).get("bb_middle_gap_pct") if isinstance(pos.get("entry_context"), dict) else None,
        "mfi_14": (pos.get("entry_context") or {}).get("mfi_14") if isinstance(pos.get("entry_context"), dict) else None,
        "cci_20": (pos.get("entry_context") or {}).get("cci_20") if isinstance(pos.get("entry_context"), dict) else None,
        "stoch_k": (pos.get("entry_context") or {}).get("stoch_k") if isinstance(pos.get("entry_context"), dict) else None,
        "stoch_d": (pos.get("entry_context") or {}).get("stoch_d") if isinstance(pos.get("entry_context"), dict) else None,
        "stoch_cross_up": (pos.get("entry_context") or {}).get("stoch_cross_up") if isinstance(pos.get("entry_context"), dict) else None,
        "adx_14": (pos.get("entry_context") or {}).get("adx_14") if isinstance(pos.get("entry_context"), dict) else None,
        "avg_price_turn_pct": (pos.get("entry_context") or {}).get("avg_price_turn_pct") if isinstance(pos.get("entry_context"), dict) else None,
        "v_rebound_score": (pos.get("entry_context") or {}).get("v_rebound_score") if isinstance(pos.get("entry_context"), dict) else None,
        "volume_spike_30x": (pos.get("entry_context") or {}).get("volume_spike_30x") if isinstance(pos.get("entry_context"), dict) else None,
        "volume_pump_risk": (pos.get("entry_context") or {}).get("volume_pump_risk") if isinstance(pos.get("entry_context"), dict) else None,
        "major_watch": (pos.get("entry_context") or {}).get("major_watch") if isinstance(pos.get("entry_context"), dict) else None,
        "major_watch_label": (pos.get("entry_context") or {}).get("major_watch_label") if isinstance(pos.get("entry_context"), dict) else None,
        "price_recheck_pct": (pos.get("entry_context") or {}).get("price_recheck_pct") if isinstance(pos.get("entry_context"), dict) else None,
        "orderbook_spread_pct": (pos.get("entry_context") or {}).get("orderbook_spread_pct") if isinstance(pos.get("entry_context"), dict) else None,
        "tick_pct_est": (pos.get("entry_context") or {}).get("tick_pct_est") if isinstance(pos.get("entry_context"), dict) else None,
        "execution_risk_status": (pos.get("entry_context") or {}).get("execution_risk_status") if isinstance(pos.get("entry_context"), dict) else None,
        "micro_fresh": (pos.get("entry_context") or {}).get("micro_fresh") if isinstance(pos.get("entry_context"), dict) else None,
        "micro_row_status": (pos.get("entry_context") or {}).get("micro_row_status") if isinstance(pos.get("entry_context"), dict) else None,
        "micro_spread_pct": (pos.get("entry_context") or {}).get("micro_spread_pct") if isinstance(pos.get("entry_context"), dict) else None,
        "micro_bid_ask_wall_ratio": (pos.get("entry_context") or {}).get("micro_bid_ask_wall_ratio") if isinstance(pos.get("entry_context"), dict) else None,
        "micro_trade_buy_ratio_30": (pos.get("entry_context") or {}).get("micro_trade_buy_ratio_30") if isinstance(pos.get("entry_context"), dict) else None,
        "micro_ask_wall_pressure": (pos.get("entry_context") or {}).get("micro_ask_wall_pressure") if isinstance(pos.get("entry_context"), dict) else None,
        "micro_sell_trade_pressure": (pos.get("entry_context") or {}).get("micro_sell_trade_pressure") if isinstance(pos.get("entry_context"), dict) else None,
        "source_created_at": pos.get("source_created_at"),
        "source_expires_at": pos.get("source_expires_at"),
    }
    try:
        closed.update(_external_closed_fields_from_ctx(closed.get("entry_context") if isinstance(closed.get("entry_context"), dict) else {}))
    except Exception as exc:
        log_error("closed_external_context", exc)
    return pos, closed


def format_price(v: Any) -> str:
    x = float_any(v, default=0.0)
    if x >= 1000:
        return f"{x:,.0f}"
    if x >= 1:
        return f"{x:,.4f}"
    return f"{x:,.8f}"


def fmt_pct(v: Any) -> str:
    return f"{float_any(v, default=0.0):+.2f}%"


def fmt_num(v: Any, digits: int = 2, default: str = "-") -> str:
    try:
        if v is None:
            return default
        x = float(v)
        return f"{x:.{digits}f}"
    except Exception:
        return default


def fmt_money_krw_short(v: Any) -> str:
    x = float_any(v, default=0.0)
    if abs(x) >= 100_000_000:
        return f"{x/100_000_000:.1f}억"
    if abs(x) >= 10_000:
        return f"{x/10_000:.0f}만"
    if x:
        return f"{x:.0f}원"
    return "-"


def yes_fresh(v: Any) -> str:
    if v is True or str(v).lower() in {"true", "1", "fresh", "ok", "yes"}:
        return "✅ 신선"
    if v is False or str(v).lower() in {"false", "0", "stale", "old"}:
        return "⚠️ 오래됨"
    return "❔ 없음"


EXIT_REASON_KR = {
    "take_profit": "익절 종료",
    "stop_loss": "손절 종료",
    "slow_no_progress": "지지부진 종료",
    "quick_stop": "빠른손절 종료",
    "bounce_fail": "반등실패 조기손절",
    "slow_early_exit": "지지부진 조기종료",
    "time_exit": "시간 종료",
    "protect_stop_after_tp": "익절 후 보호청산",
}


def exit_reason_kr(reason: Any) -> str:
    return EXIT_REASON_KR.get(str(reason or ""), str(reason or "-"))


def strategy_kr(strategy: Any) -> str:
    s = str(strategy or "")
    if "거래대금" in s or "pull" in s.lower() or "rebreak" in s.lower():
        return "거래대금 눌림 재돌파"
    return s or "-"


def tag_text_kr(tags: Any, limit: int = 3) -> str:
    if not isinstance(tags, list):
        raw = [str(tags)] if tags else []
    else:
        raw = [str(x) for x in tags if str(x).strip()]
    mapped = []
    for t in raw[:limit]:
        low = t.lower()
        if "slow" in low or "펌핑" in t:
            mapped.append("펌핑/지지부진 위험")
        elif "stop" in low or "밀림" in t:
            mapped.append("진입 직전 밀림 위험")
        elif "spread" in low or "스프레드" in t:
            mapped.append("스프레드 주의")
        elif "weak" in low or "약함" in t:
            mapped.append(t.replace("관찰전환:", "").replace("재확인대기:", "").strip())
        else:
            mapped.append(t.replace("관찰전환:", "").replace("재확인대기:", "").strip())
    return " / ".join(mapped) if mapped else "특이사항 없음"


def micro_summary_from_ctx(ctx: Dict[str, Any]) -> str:
    if not isinstance(ctx, dict):
        return "- 호가·체결: 정보없음"
    spread = ctx.get("micro_spread_pct")
    buy_ratio = ctx.get("micro_trade_buy_ratio_30")
    wall_ratio = ctx.get("micro_bid_ask_wall_ratio")
    fresh = ctx.get("micro_fresh")
    row_status = ctx.get("micro_row_status") or "-"
    flags = []
    if ctx.get("micro_ask_wall_pressure"):
        flags.append("매도벽 주의")
    if ctx.get("micro_sell_trade_pressure"):
        flags.append("매도체결 우세")
    if not flags:
        flags.append("특이압박 없음")
    return (
        f"- 호가·체결: {yes_fresh(fresh)} / 상태 {row_status}\n"
        f"  · 스프레드 {fmt_num(spread, 2)}% / 매수체결비율 {fmt_num(buy_ratio, 2)} / 매수벽비율 {fmt_num(wall_ratio, 2)}\n"
        f"  · {' / '.join(flags[:3])}"
    )


def ws_summary_from_ctx(ctx: Dict[str, Any]) -> str:
    if not isinstance(ctx, dict):
        return "- 웹소켓: 정보없음"
    return (
        f"- 웹소켓: {yes_fresh(ctx.get('ws_fresh'))}"
        f" / REST-WS 차이 {fmt_num(ctx.get('current_price_ws_gap_pct'), 3)}%"
    )

def send_message(text: str) -> None:
    if not TOKEN or not NOTIFY_CHAT_ID:
        return
    chunks = [str(text)[i:i+3900] for i in range(0, len(str(text)), 3900)] or [""]
    for ch in chunks:
        try:
            url = f"https://api.telegram.org/bot{TOKEN}/sendMessage"
            data = urllib.parse.urlencode({"chat_id": NOTIFY_CHAT_ID, "text": ch}).encode("utf-8")
            req = urllib.request.Request(url, data=data)
            with urllib.request.urlopen(req, timeout=20) as resp:
                resp.read()
        except Exception as exc:
            log_error("send_message", exc)




def hold_text_from_seconds(sec: Any) -> str:
    s = max(0, int(float_any(sec, default=0.0)))
    h, rem = divmod(s, 3600)
    m, ss = divmod(rem, 60)
    if h > 0:
        return f"{h}시간 {m}분 {ss}초"
    if m > 0:
        return f"{m}분 {ss}초"
    return f"{ss}초"


def opened_text_from_row(row: Dict[str, Any]) -> str:
    # v0.46: 과거 row의 opened_at_text가 UTC 문자열로 저장돼 있어도, 숫자 timestamp가 있으면 KST로 다시 표시한다.
    ts = float_any((row or {}).get("opened_at"), default=0.0)
    if ts > 0:
        return iso_ts(ts)
    txt = str((row or {}).get("opened_at_text") or "").strip()
    return txt or "-"


def closed_text_from_row(row: Dict[str, Any]) -> str:
    # v0.46: 과거 row의 closed_at_text가 UTC 문자열로 저장돼 있어도, 숫자 timestamp가 있으면 KST로 다시 표시한다.
    ts = float_any((row or {}).get("closed_at"), default=0.0)
    if ts > 0:
        return iso_ts(ts)
    txt = str((row or {}).get("closed_at_text") or "").strip()
    return txt or "-"


def hold_seconds_from_rows(opened_at: Any, closed_at: Any = None) -> int:
    start = float_any(opened_at, default=0.0)
    end = float_any(closed_at, default=now())
    if start <= 0 or end <= 0 or end < start:
        return 0
    return int(end - start)


def market_links_text(ticker: Any) -> str:
    t = short_ticker(ticker)
    if not t or t == "-":
        return ""
    bithumb = f"https://www.bithumb.com/trade/order/{t}_KRW"
    tv = f"https://www.tradingview.com/chart/?symbol=BITHUMB%3A{t}KRW"
    return "🔗 바로보기\n- 빗썸: " + bithumb + "\n- 차트: " + tv


def format_open_alert(pos: Dict[str, Any]) -> str:
    """실제 paper_bot OPEN 장부에 저장된 건만 보내는 알림.
    후보/관찰/복기 알림이 아니라 실제 모의매매 진입 기록이다.
    """
    ctx = pos.get("entry_context") if isinstance(pos.get("entry_context"), dict) else {}
    tags = ctx.get("quality_risk_tags") or []
    final_label = pos.get("final_entry_label") or ctx.get("final_entry_label") or pos.get("trade_ready_label") or "최종검증 통과"
    reasons = pos.get("final_entry_reasons") or ctx.get("final_entry_reasons") or []
    if isinstance(reasons, list):
        reason_txt = " / ".join(str(x).replace("관찰전환:", "").replace("재확인대기:", "").strip() for x in reasons[:3] if str(x).strip()) or final_label
    else:
        reason_txt = str(reasons or final_label)
    lines = [
        "📥 모의매매 진입",
        "",
        f"코인: {short_ticker(pos.get('ticker'))}",
        f"진입가: {format_price(pos.get('entry_price'))}",
        f"진입시간: {opened_text_from_row(pos)}",
        f"전략: {strategy_kr(pos.get('strategy'))}",
        f"판정: {str(final_label).replace('OPEN', '진입').replace('trade_ready', '최종검증 통과')}",
        exit_mode_line(pos),
        "",
        "📌 진입 근거",
        f"- 점수: {float_any(pos.get('score'), default=0.0):.2f}",
        f"- 3분 돈흐름: {fmt_money_krw_short(ctx.get('money_flow_3m'))}",
        f"- 눌림품질: {fmt_num(ctx.get('pullback_quality_score'), 2)}",
        f"- 재돌파힘: {fmt_num(ctx.get('rebreakout_strength'), 2)}",
        f"- 위험태그: {tag_text_kr(tags)}",
        "",
        "🛰 외부정보",
        ws_summary_from_ctx(ctx),
        micro_summary_from_ctx(ctx),
        "",
        market_links_text(pos.get('ticker')),
        "",
        "참고: 실제 주문 아님 / paper_bot 모의매매 장부 OPEN 기록",
    ]
    return "\n".join(lines)


def format_close_alert(closed: Dict[str, Any]) -> str:
    """실제 paper_bot CLOSED 장부에 저장된 건만 보내는 알림."""
    ctx = closed.get("entry_context") if isinstance(closed.get("entry_context"), dict) else {}
    reason = str(closed.get("exit_reason") or "")
    pnl = float_any(closed.get("pnl_pct"), default=0.0)
    if reason == "take_profit" or pnl > 0:
        icon = "✅"
    elif reason == "stop_loss" or pnl < -0.5:
        icon = "❌"
    else:
        icon = "⚠️"
    lines = [
        f"{icon} 모의매매 종료: {exit_reason_kr(reason)}",
        "",
        f"코인: {short_ticker(closed.get('ticker'))}",
        f"수익률: {fmt_pct(closed.get('pnl_pct'))}",
        f"진입 → 청산: {format_price(closed.get('entry_price'))} → {format_price(closed.get('exit_price'))}",
        f"최고/최저: {fmt_pct(closed.get('peak_pct'))} / {fmt_pct(closed.get('trough_pct'))}",
        f"진입시간: {opened_text_from_row(closed)}",
        f"매도시간: {closed_text_from_row(closed)}",
        f"보유시간: {closed.get('hold_text') or hold_text_from_seconds(closed.get('hold_sec') or float_any(closed.get('age_min'), default=0.0) * 60)}",
        exit_mode_line(closed),
        f"청산규칙: {exit_reason_kr(reason)}" + (f" / {closed.get('exit_rule_reason')}" if closed.get('exit_rule_reason') else ""),
        "",
        "📌 진입 당시 근거",
        f"- 전략: {strategy_kr(closed.get('strategy'))}",
        f"- 점수: {float_any(closed.get('score'), default=0.0):.2f}",
        f"- 3분 돈흐름: {fmt_money_krw_short(ctx.get('money_flow_3m'))}",
        f"- 눌림품질: {fmt_num(ctx.get('pullback_quality_score'), 2)}",
        f"- 위험태그: {tag_text_kr(closed.get('quality_risk_tags') or ctx.get('quality_risk_tags'))}",
        "",
        "🛰 진입 당시 외부정보",
        ws_summary_from_ctx(ctx),
        micro_summary_from_ctx(ctx),
        "",
        market_links_text(closed.get('ticker')),
    ]
    return "\n".join(x for x in lines if x is not None)



def load_alert_state() -> Dict[str, Any]:
    data = load_json(FILES.get("alert_state", BASE_DIR / "paper_bot_alert_state.json"), {})
    return data if isinstance(data, dict) else {}


def save_alert_state(data: Dict[str, Any]) -> None:
    if not isinstance(data, dict):
        data = {}
    data["updated_at"] = now()
    data["updated_at_text"] = iso_ts()
    save_json(FILES.get("alert_state", BASE_DIR / "paper_bot_alert_state.json"), data)


def _alert_key(row: Dict[str, Any]) -> str:
    return str((row or {}).get("pos_id") or (row or {}).get("event_id") or "")


def _alerted_open_ids(state: Optional[Dict[str, Any]] = None) -> set[str]:
    state = state if isinstance(state, dict) else load_alert_state()
    vals = state.get("open_alerted_ids") if isinstance(state.get("open_alerted_ids"), list) else []
    return {str(x) for x in vals if str(x)}


def mark_open_alerted(row: Dict[str, Any], state: Optional[Dict[str, Any]] = None) -> Dict[str, Any]:
    state = state if isinstance(state, dict) else load_alert_state()
    ids = list(_alerted_open_ids(state))
    key = _alert_key(row)
    if key and key not in ids:
        ids.append(key)
    state["open_alerted_ids"] = ids[-5000:]
    state["last_open_alert_at"] = now()
    state["last_open_alert_ticker"] = short_ticker((row or {}).get("ticker"))
    save_alert_state(state)
    return state


def was_open_alerted(row: Dict[str, Any], state: Optional[Dict[str, Any]] = None) -> bool:
    key = _alert_key(row)
    return bool(key and key in _alerted_open_ids(state))


def should_send_open_alert(pos: Dict[str, Any], control: Dict[str, Any]) -> Tuple[bool, str]:
    """v0.40: 알림은 '실제 자동매매에 넣을 만한 paper OPEN'만 보낸다.
    장부 OPEN 자체는 유지하지만, 애매한 후보/관찰성 OPEN 알림은 시간 요약으로 보낸다.
    """
    if str((pos or {}).get("lane")) != "strict":
        return False, "strict 아님"
    if not bool((pos or {}).get("trade_ready")):
        return False, "trade_ready 아님"
    score = float_any((pos or {}).get("score"), default=0.0)
    min_score = float_any(control.get("notify_open_min_score"), default=4.45)
    if score < min_score:
        return False, f"점수 {score:.2f} < 알림 {min_score:.2f}"
    action = str((pos or {}).get("final_entry_action") or "")
    label = str((pos or {}).get("final_entry_label") or "")
    if control.get("notify_open_require_final_pass", True):
        if action not in {"paper_open", "trade_ready", "open", ""} and "통과" not in label:
            return False, f"최종검증 통과 아님({action or label})"
    ctx = (pos or {}).get("entry_context") if isinstance((pos or {}).get("entry_context"), dict) else {}
    if control.get("notify_open_require_micro_fresh", True) and not bool(ctx.get("micro_fresh")):
        return False, "micro fresh 아님"
    if control.get("notify_open_require_ws_fresh", False) and not bool(ctx.get("ws_fresh")):
        return False, "WS fresh 아님"
    risk_text = " / ".join(str(x) for x in ((pos or {}).get("quality_risk_tags") or ctx.get("quality_risk_tags") or []))
    if any(bad in risk_text for bad in ["펌핑", "밀림", "추격", "실전위험"]):
        return False, f"위험태그 {risk_text[:80]}"
    return True, "자동매매급 알림"


def _ambiguous_candidates(control: Dict[str, Any]) -> List[Dict[str, Any]]:
    read_max = int(float_any(control.get("candidate_read_max_lines"), default=800))
    rows = read_jsonl(candidate_input_path("strict"), max_lines=read_max)
    rows, _ = latest_scan_filter(rows, control)
    out = []
    for r in rows:
        if not isinstance(r, dict):
            continue
        can_open = bool(r.get("paper_bot_open") or r.get("open_eligible") or r.get("trade_ready"))
        action = str(r.get("final_entry_action") or "")
        if can_open:
            # 알림대상에서 탈락한 OPEN급은 요약에 함께 표시한다.
            dummy = {"lane":"strict", "trade_ready": True, "score": r.get("score"), "final_entry_action": action, "final_entry_label": r.get("final_entry_label"), "entry_context": r.get("entry_context") if isinstance(r.get("entry_context"), dict) else r}
            ok, why = should_send_open_alert(dummy, control)
            if ok:
                continue
            rr = dict(r); rr["summary_reason"] = "OPEN 알림 제외: " + why; out.append(rr); continue
        if action in {"recheck_wait", "observe"} or not can_open:
            rr = dict(r); rr.setdefault("summary_reason", r.get("final_entry_label") or r.get("trade_ready_label") or "애매/관찰 후보"); out.append(rr)
    out.sort(key=lambda x: (bool(x.get("paper_bot_open") or x.get("trade_ready") or x.get("open_eligible")), float_any(x.get("score"), default=0.0), float_any(x.get("money_flow_3m") or x.get("turnover_3m"), default=0.0)), reverse=True)
    return out



def _recent_summary_closed(limit: int = 300) -> List[Dict[str, Any]]:
    rows = rows_since_baseline(read_jsonl(FILES["closed"], max_lines=max(limit, 300)), "closed_at")
    cutoff = now() - 3600.0
    out = [r for r in rows if float_any((r or {}).get("closed_at"), default=0.0) >= cutoff]
    out.sort(key=lambda r: float_any((r or {}).get("closed_at"), default=0.0), reverse=True)
    return out


def _candidate_reason_short(row: Dict[str, Any]) -> str:
    ctx = row.get("entry_context") if isinstance(row.get("entry_context"), dict) else row
    reason = str(row.get("summary_reason") or row.get("final_entry_label") or row.get("trade_ready_label") or row.get("reason") or "-")
    risk = row.get("quality_risk_tags") or ctx.get("quality_risk_tags") or []
    if isinstance(risk, list) and risk:
        reason = (reason + " / " + " / ".join(str(x) for x in risk[:2])).strip(" / ")
    return reason[:90]


def _summary_line_from_closed(row: Dict[str, Any]) -> str:
    ctx = row.get("entry_context") if isinstance(row.get("entry_context"), dict) else {}
    return (
        f"- {short_ticker(row.get('ticker'))}: {float_any(row.get('pnl_pct'), default=0.0):+.2f}% / "
        f"최고 {float_any(row.get('peak_pct'), default=0.0):+.2f}% / {exit_reason_kr(str(row.get('exit_reason') or 'unknown'))} / "
        f"보유 {row.get('hold_text') or (str(row.get('age_min') or '-') + '분')} / "
        f"3분돈 {fmt_money_krw_short(ctx.get('money_flow_3m') or row.get('money_flow_3m'))} / "
        f"매수비 {float_any(ctx.get('micro_trade_buy_ratio_30'), default=0.0):.2f}"
    )


def _summary_line_from_candidate(row: Dict[str, Any]) -> str:
    ctx = row.get("entry_context") if isinstance(row.get("entry_context"), dict) else row
    return (
        f"- {short_ticker(row.get('ticker') or row.get('market') or row.get('symbol'))}: "
        f"점수 {float_any(row.get('score'), default=0.0):.2f} / "
        f"3분돈 {fmt_money_krw_short(ctx.get('money_flow_3m') or row.get('money_flow_3m') or row.get('turnover_3m'))} / "
        f"micro {yes_fresh(ctx.get('micro_fresh'))} / WS {yes_fresh(ctx.get('ws_fresh'))} / "
        f"{_candidate_reason_short(row)}"
    )

def format_recheck_summary(rows: List[Dict[str, Any]], control: Dict[str, Any]) -> str:
    """v0.48: 알림을 줄이는 것이 아니라 후보 흐름을 1시간 단위로 분류해서 보여준다."""
    max_rows = int(float_any(control.get("recheck_summary_max_rows"), default=8))
    recent_closed = _recent_summary_closed()
    good = [r for r in recent_closed if float_any(r.get("pnl_pct"), default=0.0) > 0]
    bad = [r for r in recent_closed if float_any(r.get("pnl_pct"), default=0.0) <= 0]
    good.sort(key=lambda r: float_any(r.get("pnl_pct"), default=0.0), reverse=True)
    bad.sort(key=lambda r: float_any(r.get("pnl_pct"), default=0.0))

    # 놓친 후보: OPEN은 안 됐지만 점수/돈흐름이 높은 재확인·관찰 후보.
    missed_watch = []
    for r in rows or []:
        ctx = r.get("entry_context") if isinstance(r.get("entry_context"), dict) else r
        if bool(r.get("paper_bot_open") or r.get("open_eligible") or r.get("trade_ready")):
            continue
        score = float_any(r.get("score"), default=0.0)
        money3 = float_any(ctx.get("money_flow_3m") or r.get("money_flow_3m") or r.get("turnover_3m"), default=0.0)
        if score >= 4.45 or money3 >= 20_000_000:
            missed_watch.append(r)
    missed_watch.sort(key=lambda r: (float_any(r.get("score"), default=0.0), float_any((r.get("entry_context") or r).get("money_flow_3m") or r.get("turnover_3m"), default=0.0)), reverse=True)

    # 버린 게 맞았는지 볼 후보: 위험 사유가 뚜렷한 관찰/보류 후보.
    rejected_ok = []
    danger_words = ["스프레드", "매도", "정보 오래", "과폭발", "약함", "VWAP", "가격재확인"]
    for r in rows or []:
        reason = _candidate_reason_short(r)
        if any(w in reason for w in danger_words):
            rejected_ok.append(r)
    rejected_ok = rejected_ok[:max_rows]

    lines = [
        "🕐 후보품질 1시간 요약",
        "- 정식 OPEN/CLOSED 알림은 즉시 유지합니다.",
        "- 재확인/관찰/놓친 후보는 시끄럽게 울리지 않고 1시간 단위로 묶어 봅니다.",
        "",
        f"요약: 종료 {len(recent_closed)}건 / 재확인·관찰 {len(rows or [])}개",
        "",
        "[좋았던 후보]",
    ]
    lines += [_summary_line_from_closed(r) for r in good[:max_rows]] or ["- 없음"]
    lines += ["", "[안 좋았던 후보]"]
    lines += [_summary_line_from_closed(r) for r in bad[:max_rows]] or ["- 없음"]
    lines += ["", "[놓친 후보 후보군]"]
    lines += [_summary_line_from_candidate(r) for r in missed_watch[:max_rows]] or ["- 없음"]
    lines += ["", "[버린 게 맞았는지 확인할 후보]"]
    lines += [_summary_line_from_candidate(r) for r in rejected_ok[:max_rows]] or ["- 없음"]
    lines += ["", "설정: /palerts"]
    return "\n".join(lines)

def maybe_send_recheck_summary(control: Dict[str, Any]) -> None:
    if not control.get("notify_recheck_summary", True):
        return
    state = load_alert_state()
    interval = max(300.0, float_any(control.get("recheck_summary_interval_sec"), default=3600.0))
    last = float_any(state.get("last_recheck_summary_at"), default=0.0)
    if now() - last < interval:
        return
    rows = _ambiguous_candidates(control)
    if not rows and not _recent_summary_closed():
        state["last_recheck_summary_at"] = now()
        save_alert_state(state)
        return
    send_message(format_recheck_summary(rows, control))
    state["last_recheck_summary_at"] = now()
    state["last_recheck_summary_count"] = len(rows)
    save_alert_state(state)


def notify_strict_events(opened: List[Dict[str, Any]], closed: List[Dict[str, Any]], control: Dict[str, Any]) -> None:
    # v0.48: 정식 OPEN/CLOSED 즉시 알림은 유지한다.
    # 재확인/관찰/놓친 후보는 알림을 없애지 않고 1시간 후보품질 요약으로 묶는다.
    try:
        state = load_alert_state()
        if control.get("notify_on_strict_open", True):
            for p in opened:
                if str(p.get("lane")) != "strict":
                    continue
                ok, why = should_send_open_alert(p, control)
                if ok:
                    send_message(format_open_alert(p))
                    state = mark_open_alerted(p, state)
                else:
                    log(f"open_alert_skip {short_ticker(p.get('ticker'))}: {why}")
        if control.get("notify_on_strict_close", True):
            for c in closed:
                if str(c.get("lane")) != "strict":
                    continue
                if control.get("notify_close_only_alerted", True) and not was_open_alerted(c, state):
                    log(f"close_alert_skip_not_alerted {short_ticker(c.get('ticker'))}")
                    continue
                send_message(format_close_alert(c))
        maybe_send_recheck_summary(control)
    except Exception as exc:
        log_error("notify_strict_events", exc)


def _file_stats_direct() -> Dict[str, Any]:
    out = {}
    for name in ["paper_candidates", "shadow_candidates", "paper_latest", "shadow_latest", "shadow_quarantine", "legacy_strict_quarantine", "open", "closed", "status", "error", "log"]:
        p = FILES[name]
        info = {"exists": p.exists(), "size": p.stat().st_size if p.exists() else 0}
        if p.suffix == ".jsonl" and p.exists():
            info["lines"] = line_count(p)
        out[name] = info
    return out


def file_stats(*, force: bool = False) -> Dict[str, Any]:
    """v0.45: status 작성 때마다 jsonl 라인수를 전부 세는 경로를 TTL 캐시로 정리한다."""
    try:
        nowv = now()
        cached = _FILE_STATS_CACHE.get("stats")
        if (not force) and isinstance(cached, dict) and nowv - float_any(_FILE_STATS_CACHE.get("ts"), default=0.0) <= FILE_STATS_CACHE_TTL_SEC:
            return cached
        stats = _file_stats_direct()
        _FILE_STATS_CACHE.update({"ts": nowv, "stats": stats})
        return stats
    except Exception as exc:
        log_error("file_stats_cached", exc)
        cached = _FILE_STATS_CACHE.get("stats")
        return cached if isinstance(cached, dict) else {}


def closed_new_total_cached() -> int:
    """v0.45: CLOSED 20000줄 tail을 매 cycle 읽지 않는다."""
    try:
        p = FILES["closed"]
        size = p.stat().st_size if p.exists() else 0
        mtime = p.stat().st_mtime if p.exists() else 0.0
        nowv = now()
        if (_CLOSED_NEW_TOTAL_CACHE.get("count") is not None
                and int(_CLOSED_NEW_TOTAL_CACHE.get("file_size", -1) or -1) == int(size)
                and abs(float_any(_CLOSED_NEW_TOTAL_CACHE.get("mtime"), default=0.0) - mtime) < 0.001
                and nowv - float_any(_CLOSED_NEW_TOTAL_CACHE.get("ts"), default=0.0) <= CLOSED_NEW_TOTAL_CACHE_TTL_SEC):
            return int(_CLOSED_NEW_TOTAL_CACHE.get("count") or 0)
        cnt = len(rows_since_baseline(read_jsonl(FILES["closed"], max_lines=20000), "closed_at"))
        _CLOSED_NEW_TOTAL_CACHE.update({"ts": nowv, "count": cnt, "file_size": size, "mtime": mtime})
        return cnt
    except Exception as exc:
        log_error("closed_new_total_cached", exc)
        return int(_CLOSED_NEW_TOTAL_CACHE.get("count") or 0)


def run_cycle() -> Dict[str, Any]:
    global _CYCLE_PRICE_MAP
    started = now()
    control = load_control()
    # v0.23: 종목별 현재가 호출 수백 개를 막고, 한 cycle에 ALL_KRW 1회로 OPEN 갱신한다.
    _CYCLE_PRICE_MAP = fetch_all_bithumb_prices()
    with _state_lock:
        open_pos = load_open()
        open_pos, quarantined_shadow = quarantine_shadow_open_positions(open_pos, control)
        open_pos, quarantined_legacy_strict = quarantine_legacy_strict_open_positions(open_pos, control)
        if quarantined_shadow or quarantined_legacy_strict:
            save_open(open_pos)
            if quarantined_shadow:
                log(f"shadow_quarantine moved={quarantined_shadow}")
            if quarantined_legacy_strict:
                log(f"legacy_strict_quarantine moved={quarantined_legacy_strict}")
        counts_before = count_by_lane(open_pos)
        picked, pick_stats = pick_candidates(control, open_pos)
        opened_items: List[Dict[str, Any]] = []
        opened = 0
        for pos_id, ev in picked:
            try:
                if pos_id not in open_pos:
                    new_pos = open_position(pos_id, ev, control)
                    open_pos[pos_id] = new_pos
                    opened_items.append(new_pos)
                    opened += 1
            except Exception as exc:
                log_error("open_position", exc)

        closed_items: List[Dict[str, Any]] = []
        for pos_id, pos in list(open_pos.items()):
            try:
                updated, closed = update_position(pos, control)
                if closed:
                    closed_items.append(closed)
                    open_pos.pop(pos_id, None)
                    append_jsonl(FILES["closed"], closed)
                else:
                    open_pos[pos_id] = updated
            except Exception as exc:
                log_error("update_position", exc)

        save_open(open_pos)
        counts_after = count_by_lane(open_pos)
        new_open_total, old_open_total, new_open_counts, old_open_counts = open_split_since_baseline(open_pos)
        write_pid()
        status = {
            "version": VERSION,
            "pid": os.getpid(),
            "self_pid": os.getpid(),
            "process_pid": os.getpid(),
            "process_alive": True,
            "updated_at": now(),
            "updated_at_text": iso_ts(),
            "running": bool(control.get("running")),
            "loop_seconds": control.get("loop_seconds"),
            "opened_this_cycle": opened,
            "closed_this_cycle": len(closed_items),
            "open_total": len(open_pos),
            "open_strict": counts_after.get("strict", 0),
            "open_shadow": counts_after.get("shadow", 0),
            "open_new_total": new_open_total,
            "open_old_total": old_open_total,
            "open_new_counts": new_open_counts,
            "open_old_counts": old_open_counts,
            "closed_total": closed_count(),
            "closed_new_total": closed_new_total_cached(),
            "quarantined_shadow_this_cycle": int(locals().get("quarantined_shadow", 0)),
            "pick_stats": pick_stats,
            "counts_before": counts_before,
            "elapsed_sec": round(now() - started, 3),
            "files": file_stats(),
            "flag_exists": FILES["flag"].exists(),
            "candidate_events_consumed": 0,
            "candidate_events_note": "v0.21: candidate_events 읽기/소비 없음",
        }
        save_json(FILES["status"], status)
        notify_strict_events(opened_items, closed_items, control)
        log(f"cycle opened={opened} closed={len(closed_items)} open={len(open_pos)} elapsed={status['elapsed_sec']}s")
        return status



def heartbeat_log(where: str = "loop") -> None:
    global _LAST_HEARTBEAT_LOG_TS
    try:
        ts = now()
        if ts - float_any(_LAST_HEARTBEAT_LOG_TS, default=0.0) < HEARTBEAT_LOG_SEC:
            return
        _LAST_HEARTBEAT_LOG_TS = ts
        control = load_control()
        open_pos = load_open()
        log(f"heartbeat {where} running={bool(control.get('running'))} open={len(open_pos)} closed={closed_count()}")
    except Exception:
        pass


def write_startup_status() -> None:
    try:
        control = load_control()
        open_pos = load_open()
        counts = count_by_lane(open_pos)
        save_json(FILES["status"], {
            "version": VERSION,
            "pid": os.getpid(),
            "self_pid": os.getpid(),
            "process_pid": os.getpid(),
            "process_alive": True,
            "updated_at": now(),
            "updated_at_text": iso_ts(),
            "running": bool(control.get("running")),
            "loop_seconds": control.get("loop_seconds"),
            "open_total": len(open_pos),
            "open_strict": counts.get("strict", 0),
            "open_shadow": counts.get("shadow", 0),
            "closed_total": closed_count(),
            "startup_status": True,
            "stop_reason": "running",
        })
    except Exception as exc:
        log_error("write_startup_status", exc)


def worker_loop() -> None:
    log("worker_loop started")
    while not _stop_event.is_set():
        try:
            control = load_control()
            heartbeat_log("worker")
            if control.get("running"):
                run_cycle()
            _stop_event.wait(float_any(control.get("loop_seconds"), default=8.0))
        except Exception as exc:
            log_error("worker_loop", exc)
            _stop_event.wait(3)
    log("worker_loop stopped")


def score_stats(rows: Iterable[Dict[str, Any]]) -> Dict[str, Any]:
    arr = list(rows or [])
    n = len(arr)
    wins = sum(1 for r in arr if float_any(r.get("pnl_pct"), default=0.0) > 0)
    total = sum(float_any(r.get("pnl_pct"), default=0.0) for r in arr)
    return {"n": n, "wins": wins, "losses": n-wins, "win_rate": wins/n*100 if n else 0.0, "total": total, "avg": total/n if n else 0.0}


EXIT_REASON_KR = {
    "take_profit": "익절 종료",
    "stop_loss": "손절 종료",
    "slow_no_progress": "지지부진 종료",
    "time_exit": "시간 종료",
    "protect_stop_after_tp": "익절 후 보호청산",
    "unknown": "사유 미확인",
}

def label_kr(label: str) -> str:
    s = str(label or "-")
    return EXIT_REASON_KR.get(s, s)

def score_icon(stat: Dict[str, Any]) -> str:
    n = int(stat.get("n", 0) or 0)
    if n <= 0:
        return "❔"
    if n < 50:
        return "⚠️"
    return "✅" if float_any(stat.get("avg"), default=0.0) > 0 else "❌"

def sample_note(n: int) -> str:
    if 0 < n < 50:
        return " / 판단보류: 50전 미만"
    return ""

def fmt_stats(label: str, rows: Iterable[Dict[str, Any]]) -> str:
    s = score_stats(rows)
    return f"{score_icon(s)} {label_kr(label)}: {s['n']}전 {s['wins']}승 {s['losses']}패 / 승률 {s['win_rate']:.1f}% / 합산 {s['total']:+.2f}% / 평균 {s['avg']:+.2f}%{sample_note(s['n'])}"




def closed_ts(row: Dict[str, Any]) -> float:
    ts = float_any(row.get("closed_at"), default=0.0)
    if ts > 0:
        return ts
    text = str(row.get("closed_at_text") or "")
    try:
        return datetime.strptime(text[:19], "%Y-%m-%d %H:%M:%S").timestamp()
    except Exception:
        return 0.0


def bucket_date(row: Dict[str, Any]) -> str:
    ts = closed_ts(row)
    return datetime.fromtimestamp(ts).strftime("%m-%d") if ts > 0 else "날짜모름"


def bucket_hour3(row: Dict[str, Any]) -> str:
    ts = closed_ts(row)
    if ts <= 0:
        return "시간모름"
    dt = datetime.fromtimestamp(ts)
    start = (dt.hour // 3) * 3
    end = (start + 3) % 24
    return f"{start:02d}-{end:02d}시"


def bucket_score(row: Dict[str, Any]) -> str:
    score = float_any(row.get("score"), default=0.0)
    if score >= 4.0:
        return "점수 4.0+"
    if score >= 3.0:
        return "점수 3.0~4.0"
    if score >= 2.0:
        return "점수 2.0~3.0"
    if score > 0:
        return "점수 0~2.0"
    return "점수없음"


def bucket_auto_ready(row: Dict[str, Any]) -> str:
    val = str(row.get("auto_ready_level") or row.get("auto_ready_label") or "").strip()
    return val or bucket_score(row)


def group_table(title: str, rows: Iterable[Dict[str, Any]], key_fn, limit: int = 8) -> str:
    groups: Dict[str, List[Dict[str, Any]]] = {}
    for r in rows or []:
        groups.setdefault(str(key_fn(r) or "기타"), []).append(r)
    lines = [title]
    if not groups:
        lines.append("- 아직 데이터 없음")
        return "\n".join(lines)
    for key, arr in sorted(groups.items(), key=lambda x: (x[0] if ("시" in x[0] or "-" in x[0]) else f"{999999-len(x[1]):06d}_{x[0]}"))[:limit]:
        st = score_stats(arr)
        icon = "⚠️" if 0 < st["n"] < 20 else ("✅" if st["avg"] > 0 else "❌")
        note = " / 표본적음" if 0 < st["n"] < 20 else ""
        lines.append(f"{icon} {key}: {st['n']}전 / 승률 {st['win_rate']:.1f}% / 평균 {st['avg']:+.2f}% / 합산 {st['total']:+.2f}%{note}")
    return "\n".join(lines)


def easy_judge_text() -> str:
    return "\n".join([
        "판독",
        "✅ 평균이 계속 +인 시간대/등급은 살릴 후보",
        "⚠️ 50전 미만은 판단보류",
        "❌ 반복 손실 구간은 조건 조정 후보",
        "❔ 지금은 새 전략 추가보다 어디가 좋은지 나눠 보는 단계",
    ])


def current_brain_version_from_files() -> str:
    """paper CLOSED에 기록된 최신 brain_version을 참고 표시한다."""
    rows = read_jsonl(FILES["closed"], max_lines=5000)
    for r in reversed(rows):
        v = r.get("opened_brain_version") or r.get("brain_version")
        if v:
            return str(v)
    return "unknown"


def row_brain_version(row: Dict[str, Any]) -> str:
    for key in ("opened_brain_version", "brain_version"):
        v = row.get(key)
        if v:
            return str(v)
    raw = row.get("raw")
    if isinstance(raw, dict):
        for key in ("opened_brain_version", "brain_version"):
            v = raw.get(key)
            if v:
                return str(v)
    return "버전 미기록"

def version_history_lines(rows: Iterable[Dict[str, Any]], limit: int = 10) -> List[str]:
    groups: Dict[str, List[Dict[str, Any]]] = {}
    for r in rows or []:
        if str(r.get("lane")) != "strict":
            continue
        groups.setdefault(row_brain_version(r), []).append(r)
    if not groups:
        return ["- 아직 버전별 CLOSED 없음"]
    items = []
    for ver, arr in groups.items():
        latest = max((closed_ts(x) for x in arr), default=0.0)
        items.append((latest, ver, arr))
    out: List[str] = []
    for _, ver, arr in sorted(items, reverse=True)[:limit]:
        st = score_stats(arr)
        reasons = Counter(label_kr(str(r.get("exit_reason") or "unknown")) for r in arr)
        reason_txt = " / ".join(f"{k} {v}" for k, v in reasons.most_common(3)) if reasons else "-"
        out.append(f"{score_icon(st)} {ver}: {st['n']}전 {st['wins']}승 {st['losses']}패 / 승률 {st['win_rate']:.1f}% / 합산 {st['total']:+.2f}% / 평균 {st['avg']:+.2f}%{sample_note(st['n'])} / 주요종료 {reason_txt}")
    return out

def version_score_text() -> str:
    rows = read_jsonl(FILES["closed"], max_lines=30000)
    version = current_brain_version_from_files()
    if version == "unknown":
        target = []
    else:
        target = [r for r in rows if str(r.get("opened_brain_version") or r.get("brain_version") or "") == version and str(r.get("lane")) == "strict"]
    by_reason = Counter(str(r.get("exit_reason") or "unknown") for r in target)
    lines = [
        "📊 현재버전 모의매매 /pversion_score",
        f"- 기준 brain_version: {version}",
        fmt_stats("현재버전 정식 모의매매", target),
        "",
        "[종료 사유]",
    ]
    if by_reason:
        for k, _ in by_reason.most_common(5):
            sub = [r for r in target if str(r.get("exit_reason") or "unknown") == k]
            lines.append(fmt_stats(k, sub))
    else:
        lines.append("- 현재버전 CLOSED 부족 또는 구기록에 brain_version 없음")
    lines += ["", "[최근 버전별 성과 - 최대 10개]", *version_history_lines(rows, limit=10)]
    return "\n".join(lines)

def summary_text() -> str:
    control = load_control()
    status = load_json(FILES["status"], {})
    open_pos = load_open()
    counts = count_by_lane(open_pos)
    new_open_total, old_open_total, new_open_counts, old_open_counts = open_split_since_baseline(open_pos)
    fs = file_stats()
    err_size = fs.get("error", {}).get("size", 0)
    pick = status.get("pick_stats") if isinstance(status.get("pick_stats"), dict) else {}
    p_fresh = candidate_fresh_stats(candidate_input_path("strict"), control)
    s_fresh = candidate_fresh_stats(candidate_input_path("shadow"), control)
    new_closed_count = closed_new_total_cached()
    base = ensure_eval_baseline()
    return "\n".join([
        f"🧪 페이퍼봇 {VERSION}",
        f"- 실행상태: {'ON' if control.get('running') else 'OFF'} / loop {control.get('loop_seconds')}s",
        f"- OPEN: 전체 {len(open_pos)} / 정식 {counts.get('strict',0)} / 기존복기 {counts.get('shadow',0)}",
        f"  · 신규 {new_open_total}(정식 {new_open_counts.get('strict',0)} / 복기 {new_open_counts.get('shadow',0)}) / 기존 {old_open_total}(정식 {old_open_counts.get('strict',0)} / 복기 {old_open_counts.get('shadow',0)})",
        "- OPEN 시간표:" if open_pos else "- OPEN 시간표: 없음",
        *(format_open_list(5).splitlines() if open_pos else []),
        f"- CLOSED: 전체 {closed_count()}건 / 신규기준 이후 {new_closed_count}건",
        f"- 기준점: {base.get('baseline_text','-')} / 기존 기록 삭제 없음",
        f"- 현재 latest 파일: 정식 {fs.get('paper_latest',{}).get('lines',0)}개(TTL {p_fresh.get('fresh',0)}) / 복기 {fs.get('shadow_latest',{}).get('lines',0)}개(TTL {s_fresh.get('fresh',0)})",
        f"- 격리보존: shadow {fs.get('shadow_quarantine',{}).get('lines',0)} / 기존strict {fs.get('legacy_strict_quarantine',{}).get('lines',0)}",
        f"- 처리: trade_ready만 신규 OPEN / shadow 복기전용 / 기존 shadow·기존 strict 격리 보존",
        f"- 이번 cycle: open +{status.get('opened_this_cycle',0)} / close +{status.get('closed_this_cycle',0)} / {status.get('elapsed_sec','-')}s",
        f"- 직전 cycle 후보: 읽음 {pick.get('paper_file',0)} / OPEN통과 {status.get('opened_this_cycle',0)} / micro재확인대기 {pick.get('micro_preopen_wait',0)} / 관찰제외 {pick.get('strict_observe_skip',0)} / 복기 {pick.get('shadow_review_only_skip',0)} / 중복 {pick.get('same_ticker_skip',0)}",
        f"- 최신 scan 소비: before {pick.get('latest_scan_before',0)} → after {pick.get('latest_scan_after',0)} / scan_id {pick.get('latest_scan_id','-') or '-'}",
        f"- 알림: 정식 OPEN/CLOSED 즉시 ON / 재확인·관찰은 1시간 요약",
        f"- 업데이트: {status.get('updated_at_text','-')}",
        f"- flag: {'ON' if FILES['flag'].exists() else 'OFF'} / 오류로그 {err_size} bytes / bad_market {len(_bad_markets)}",
    ])


def tail_file(path: Path, n: int = 40) -> str:
    if not path.exists():
        return f"파일 없음: {path.name}"
    try:
        lines = path.read_text(encoding="utf-8", errors="ignore").splitlines()[-n:]
        return "\n".join(lines) if lines else f"빈 파일: {path.name}"
    except Exception as exc:
        return f"읽기 실패 {path.name}: {exc}"



def _paper_error_line_ts(line: str) -> float:
    try:
        m = re.search(r"\[(\d{4}-\d{2}-\d{2} \d{2}:\d{2}:\d{2})\]", str(line or ""))
        if not m:
            return 0.0
        return datetime.strptime(m.group(1), "%Y-%m-%d %H:%M:%S").timestamp()
    except Exception:
        return 0.0


def perror_text(full: bool = False) -> str:
    if full:
        return "🧯 paper_bot_error.log /perror_full\n\n" + tail_file(FILES["error"], 120)[-4500:]
    if not FILES["error"].exists():
        return "🧯 paper_bot_error.log\n\n✅ 오류로그 파일 없음"
    try:
        lines = FILES["error"].read_text(encoding="utf-8", errors="ignore").splitlines()
        recent_marked = [ln for ln in lines if _paper_error_line_ts(ln) >= PROGRAM_STARTED_TS]
        size = FILES["error"].stat().st_size if FILES["error"].exists() else 0
        out = ["🧯 paper_bot_error.log", ""]
        if recent_marked:
            out.append(f"⚠️ 새 실행 이후 오류 흔적 {len(recent_marked)}건")
            out.extend(recent_marked[-8:])
        else:
            out.append("✅ 새 실행 이후 오류 없음")
            out.append(f"- 과거 오류 흔적 있음 / 로그크기 {size} bytes")
            out.append("- 자세히: /perror_full")
        return "\n".join(out)
    except Exception as exc:
        return f"🧯 paper_bot_error.log\n\n⚠️ 오류로그 요약 실패: {exc}\n자세히: /perror_full"

def tg_api(method: str, params: Dict[str, Any], timeout: int = 25) -> Dict[str, Any]:
    url = f"https://api.telegram.org/bot{TOKEN}/{method}"
    data = urllib.parse.urlencode(params).encode("utf-8")
    req = urllib.request.Request(url, data=data)
    with urllib.request.urlopen(req, timeout=timeout) as resp:
        return json.loads(resp.read().decode("utf-8", errors="ignore"))


def send_chat(chat_id: Any, text: str) -> None:
    if not TOKEN:
        print(text)
        return
    body = str(text or "")
    chunks = [body[i:i+3900] for i in range(0, len(body), 3900)] or [""]
    for ch in chunks:
        try:
            tg_api("sendMessage", {"chat_id": chat_id, "text": ch, "disable_web_page_preview": "true"}, timeout=20)
        except Exception as exc:
            log_error("send_chat", exc)




def format_open_list(limit: int = 20) -> str:
    open_pos = load_open()
    if not open_pos:
        return "OPEN 없음"
    rows = sorted(open_pos.values(), key=lambda x: float_any(x.get("opened_at"), default=0.0), reverse=True)[:limit]
    lines = []
    for pos in rows:
        age = (now() - float_any(pos.get("opened_at"), default=now())) / 60.0
        tag = "신규" if float_any(pos.get("opened_at"), default=0.0) >= baseline_ts() else "기존"
        hold_txt = hold_text_from_seconds(age * 60)
        opened_txt = opened_text_from_row(pos)[5:16] if opened_text_from_row(pos) != "-" else "-"
        lines.append(f"- {short_ticker(pos.get('ticker'))} / {tag} / {pos.get('lane','-')} / 진입 {opened_txt} {format_price(pos.get('entry_price'))} / 현재 {format_price(pos.get('current_price'))} / {float_any(pos.get('last_pnl_pct'), default=0.0):+.2f}% / 보유 {hold_txt}")
    return "\n".join(lines)


def files_text() -> str:
    fs = file_stats()
    c = load_control()
    pf = candidate_fresh_stats(candidate_input_path("strict"), c)
    sf = candidate_fresh_stats(candidate_input_path("shadow"), c)
    return "\n".join([
        "📁 페이퍼봇 파일 /pfiles",
        f"- paper_latest: {fs.get('paper_latest',{}).get('lines',0)} lines / TTL유효 {pf.get('fresh',0)} / archive {fs.get('paper_candidates',{}).get('lines',0)} lines",
        f"- shadow_latest: {fs.get('shadow_latest',{}).get('lines',0)} lines / TTL유효 {sf.get('fresh',0)} / archive {fs.get('shadow_candidates',{}).get('lines',0)} lines",
        f"- shadow_quarantine: {fs.get('shadow_quarantine',{}).get('lines',0)} lines",
        f"- legacy_strict_quarantine: {fs.get('legacy_strict_quarantine',{}).get('lines',0)} lines",
        f"- open: {fs.get('open',{}).get('size',0)} bytes",
        f"- closed: {fs.get('closed',{}).get('lines',0)} lines / {fs.get('closed',{}).get('size',0)} bytes",
        "- candidate_events: 소비 안 함 / 읽지 않음",
    ])


def control_text() -> str:
    c = load_control()
    keys = ["running", "loop_seconds", "max_open_strict", "max_open_shadow", "max_new_per_cycle", "open_trade_ready_only", "track_strict_observe", "candidate_ttl_sec", "candidate_read_max_lines", "consume_latest_scan_only", "consume_latest_candidate_files", "quarantine_shadow_open", "quarantine_legacy_strict_open", "latest_scan_window_sec", "fee_pct_roundtrip", "take_profit_pct", "protect_trigger_pct", "protect_floor_pct", "stop_loss_pct", "slow_minutes", "time_exit_minutes", "block_same_ticker_open", "preopen_micro_recheck", "preopen_micro_urgent_ttl_sec", "notify_open_auto_ready_only", "notify_open_min_score", "notify_open_require_micro_fresh", "notify_open_require_ws_fresh", "notify_close_only_alerted", "notify_recheck_summary", "recheck_summary_interval_sec"]
    lines = ["⚙️ 페이퍼봇 설정 /pcontrol"]
    for k in keys:
        lines.append(f"- {k}: {c.get(k)}")
    lines.append("- allow_shadow_from_candidate_events: 제거됨/무시됨")
    lines.append("- 분석 원칙: 후보는 줄이지 않고, paper OPEN은 trade_ready만")
    lines.append("- max_open_strict: 후보 제한이 아니라 실제 자동매매식 보유 슬롯 보호값")
    lines.append("- 과거 후보 몰아먹기 방지: consume_latest_scan_only=True이면 최신 scan 묶음만 소비")
    return "\n".join(lines)


def _command_lines(text: str) -> List[str]:
    return [ln.strip() for ln in str(text or "").splitlines() if ln.strip().startswith("/")]


def _cmd_name(line: str) -> str:
    first = line.strip().split()[0].lower() if line.strip().split() else ""
    if first.startswith("/"):
        first = first[1:]
    if "@" in first:
        first = first.split("@", 1)[0]
    return first


def command_response(text: str) -> str:
    cmd = (text or "").strip().split()[0].lower() if (text or "").strip().split() else ""
    if "@" in cmd:
        cmd = cmd.split("@", 1)[0]
    if cmd in {"/phelp", "/start"}:
        return "\n".join([
            f"🧪 {VERSION}",
            "명령어: /pbatch /pstatus /pcheck /ponce /pstart /pstop /prestart /plog /perror /perror_full /pscore /pversion_score /popen /pfiles /pcontrol /palerts",
            "여러 명령어를 줄바꿈으로 보내도 자동 묶음 처리",
            "소비파일: paper_candidates_latest 우선 / shadow는 복기 전용",
            "candidate_events는 읽지 않음",
        ])
    if cmd == "/pstatus":
        return summary_text()
    if cmd == "/pcheck":
        return "✅ 페이퍼봇 점검 /pcheck\n\n" + summary_text() + "\n\n" + files_text()
    if cmd == "/pbatch":
        rows = read_jsonl(FILES["closed"], max_lines=8000)
        new_rows = rows_since_baseline(rows, "closed_at")
        strict = [r for r in rows if str(r.get("lane")) == "strict"]
        shadow = [r for r in rows if str(r.get("lane")) == "shadow"]
        return "\n".join([
            "📦 페이퍼봇 묶음 /pbatch",
            "", "[1/5] 상태", summary_text(),
            "", "[2/5] 신규 성과", fmt_stats("신규 strict", [r for r in new_rows if str(r.get("lane")) == "strict"]), fmt_stats("신규 전체 참고", new_rows),
            "", "[3/5] 누적 성과", fmt_stats("전체", rows), fmt_stats("정식 strict", strict), fmt_stats("복기 shadow 참고", shadow),
            "", "[4/5] 파일/TTL", files_text(),
            "", "[5/5] 구조", "- strict만 OPEN", "- shadow는 복기전용/기존 shadow OPEN은 격리 보존", "- candidate_events 소비 0 / fallback 없음",
        ])
    if cmd == "/ponce":
        run_cycle()
        return "✅ 1회 cycle 완료\n" + summary_text()
    if cmd == "/pstart":
        save_control({"running": True})
        return "✅ paper_bot 실행 ON\n" + summary_text()
    if cmd == "/pstop":
        save_control({"running": False, "last_stop_reason": "user_pstop"})
        log("control running=False reason=user_pstop")
        return "⏸ paper_bot 실행 OFF\n" + summary_text()
    if cmd == "/prestart":
        save_control({"running": False, "last_stop_reason": "user_prestart"}); time.sleep(0.5); save_control({"running": True})
        return "🔁 paper_bot 논리 재시작 완료\n" + summary_text()
    if cmd == "/plog":
        return "🧾 paper_bot.log\n\n" + tail_file(FILES["log"], 60)[-3500:]
    if cmd == "/perror":
        return perror_text(False)
    if cmd == "/perror_full":
        return perror_text(True)
    if cmd == "/pversion_score":
        return version_score_text()
    if cmd == "/popen":
        return "📂 OPEN 시간표 /popen\n" + format_open_list(30)
    if cmd == "/pscore":
        rows = read_jsonl(FILES["closed"], max_lines=30000)
        new_rows = rows_since_baseline(rows, "closed_at")
        new_strict = [r for r in new_rows if str(r.get("lane")) == "strict"]
        strict = [r for r in rows if str(r.get("lane")) == "strict"]
        shadow = [r for r in rows if str(r.get("lane")) == "shadow"]
        by_reason = Counter(str(r.get("exit_reason") or "unknown") for r in new_strict)
        lines = [
            "📊 페이퍼봇 성과 /pscore",
            "- 기준: paper_bot 신규 기준점 / 기존 기록 삭제 없음",
            "",
            "[1/5] 전적",
            fmt_stats("정식 모의매매 전체", new_strict),
            fmt_stats("누적 정식 참고", strict),
            "",
            "[2/5] 종료 사유",
        ]
        if by_reason:
            for k, _ in by_reason.most_common(5):
                sub = [r for r in new_strict if str(r.get("exit_reason") or "unknown") == k]
                lines.append(fmt_stats(k, sub))
        else:
            lines.append("- 아직 신규 CLOSED 없음")
        lines += [
            "",
            "[3/5] 시간대",
            group_table("- 3시간 묶음", new_strict, bucket_hour3, limit=5),
            "",
            "[4/5] 등급",
            group_table("- 준비등급/점수대", new_strict, bucket_auto_ready, limit=5),
            "",
            "[5/5] 누적 참고",
            fmt_stats("전체", rows),
            fmt_stats("복기 shadow 참고", shadow),
            "",
            "판독",
            "❌ 평균이 계속 -면 자동매매 보류",
            "✅ 평균이 +인 시간대/등급만 살릴 후보",
            "⚠️ 50건 미만은 참고만",
        ]
        return "\n".join(lines)

    if cmd == "/palerts":
        c = load_control()
        st = load_alert_state()
        rows = _ambiguous_candidates(c)
        return "\n".join([
            "🔔 페이퍼봇 알림정책 /palerts",
            "- 실시간 OPEN 알림: 자동매매급 후보만",
            f"- OPEN 알림 최소점수: {c.get('notify_open_min_score')}",
            f"- micro fresh 요구: {c.get('notify_open_require_micro_fresh')}",
        f"- 정식 OPEN 직전 micro 재확인: {c.get('preopen_micro_recheck')} / stale이면 urgent 대기",
            f"- WS fresh 요구: {c.get('notify_open_require_ws_fresh')}",
            f"- CLOSE 알림: OPEN 알림 보낸 포지션만 {c.get('notify_close_only_alerted')}",
            f"- 후보품질 시간요약: {c.get('notify_recheck_summary')} / {int(float_any(c.get('recheck_summary_interval_sec'), default=3600))}초",
            f"- 현재 요약대상: {len(rows)}개",
            f"- 마지막 요약: {iso_ts(float_any(st.get('last_recheck_summary_at'), default=0.0)) if float_any(st.get('last_recheck_summary_at'), default=0.0)>0 else '-'}",
            "- 장부 OPEN/CLOSED 자체는 기존대로 유지, 알림만 줄임",
        ])
    if cmd == "/pfiles":
        return files_text()
    if cmd == "/pcontrol":
        return control_text()
    return "알 수 없는 명령. /phelp"


def handle_command(chat_id: str, text: str) -> None:
    lines = _command_lines(text)
    if len(lines) > 1:
        send_chat(chat_id, f"📦 자동 묶음 명령 접수\n- /pbatch 없이 여러 줄 명령을 감지\n- 실행 {len(lines)}개")
        total = len(lines)
        for idx, line in enumerate(lines, start=1):
            name = _cmd_name(line)
            if name == "pbatch":
                body = "이미 자동 묶음 처리 중이라 /pbatch는 건너뜀"
            else:
                try:
                    body = command_response(line)
                except Exception as exc:
                    log_error(f"multi:{name}", exc)
                    body = f"오류: {exc.__class__.__name__}: {exc}"
            send_chat(chat_id, f"[{idx}/{total}] /{name}\n" + body)
        return
    send_chat(chat_id, command_response(text))


def telegram_loop() -> None:
    global _update_offset
    log("telegram_loop started")
    if not TOKEN or not ALLOWED_CHAT_ID:
        log("telegram disabled: token/chat_id missing")
        return
    while not _stop_event.is_set():
        try:
            res = tg_api("getUpdates", {"timeout": 20, "offset": _update_offset + 1}, timeout=30)
            for upd in res.get("result", []):
                _update_offset = max(_update_offset, int(upd.get("update_id", 0)))
                msg = upd.get("message") or upd.get("edited_message") or {}
                chat = msg.get("chat") or {}
                chat_id = str(chat.get("id", ""))
                if ALLOWED_CHAT_ID and chat_id != str(ALLOWED_CHAT_ID):
                    continue
                text = msg.get("text") or ""
                if text.startswith("/"):
                    handle_command(chat_id, text)
        except Exception as exc:
            log_error("telegram_loop", exc)
            _stop_event.wait(3)
    log("telegram_loop stopped")


def write_pid() -> None:
    try:
        FILES["pid"].write_text(str(os.getpid()), encoding="utf-8")
    except Exception:
        pass



def write_shutdown_status(reason: str = "unknown") -> None:
    try:
        control = load_control()
        open_pos = load_open()
        counts = count_by_lane(open_pos)
        save_json(FILES["status"], {
            "version": VERSION,
            "pid": os.getpid(),
            "self_pid": os.getpid(),
            "process_pid": os.getpid(),
            "process_alive": True,
            "updated_at": now(),
            "updated_at_text": iso_ts(),
            "pid": os.getpid(),
            "self_pid": os.getpid(),
            "process_pid": os.getpid(),
            "running": False,
            "process_alive": False,
            "stop_reason": reason,
            "loop_seconds": control.get("loop_seconds"),
            "open_total": len(open_pos),
            "open_strict": counts.get("strict", 0),
            "open_shadow": counts.get("shadow", 0),
            "closed_total": closed_count(),
        })
        log(f"shutdown_status reason={reason} open={len(open_pos)} closed={closed_count()}")
    except Exception as exc:
        log_error("write_shutdown_status", exc)

def handle_signal(signum, frame) -> None:
    global _STOP_REASON
    _STOP_REASON = f"signal_{signum}"
    log(f"stop requested: {_STOP_REASON}")
    write_shutdown_status(_STOP_REASON)
    _stop_event.set()


def main() -> None:
    ensure_eval_baseline()
    parser = argparse.ArgumentParser()
    parser.add_argument("--bot", action="store_true", help="run telegram + worker")
    parser.add_argument("--once", action="store_true", help="run one paper cycle")
    args = parser.parse_args()
    write_pid()
    write_startup_status()
    signal.signal(signal.SIGTERM, handle_signal)
    signal.signal(signal.SIGINT, handle_signal)
    # 구 control에서 candidate_events 키 제거한 상태로 한 번 저장해둔다.
    save_control({})
    if args.once:
        print(json.dumps(run_cycle(), ensure_ascii=False, indent=2, default=str))
        return
    t_worker = threading.Thread(target=worker_loop, name="paper_worker", daemon=True)
    t_worker.start()
    t_tg = threading.Thread(target=telegram_loop, name="paper_telegram", daemon=True)
    t_tg.start()
    log(f"{VERSION} started pid={os.getpid()} token={'yes' if TOKEN else 'no'} chat={'yes' if ALLOWED_CHAT_ID else 'no'} env_chat_keys PAPER={bool(os.getenv('PAPER_BOT_ALLOWED_CHAT_ID'))} CHAT={bool(os.getenv('CHAT_ID'))} GUARD={bool(os.getenv('GUARD_CHAT_ID'))}")
    try:
        while not _stop_event.is_set():
            time.sleep(1)
    finally:
        reason = _STOP_REASON if _STOP_REASON != "running" else "main_loop_exit"
        write_shutdown_status(reason)
        log(f"{VERSION} stopped reason={reason}")



# ===============================
# paper_bot v0.49: latest scan_id/TTL fallback + OPEN 청산감시 표시
# - main v236의 scan_id/TTL 보강을 소비한다.
# - 구 latest row가 top-level scan_id를 빼먹어도 entry_context/raw에서 복구한다.
# - OPEN별 왜 아직 안 닫혔는지 감시 상태를 /pstatus, /popen에 표시한다.
# ===============================

def _v049_ctx(ev: Dict[str, Any]) -> Dict[str, Any]:
    if isinstance((ev or {}).get("entry_context"), dict):
        return (ev or {}).get("entry_context") or {}
    if isinstance((ev or {}).get("profile"), dict):
        return (ev or {}).get("profile") or {}
    return {}


def _v049_raw(ev: Dict[str, Any]) -> Dict[str, Any]:
    return (ev or {}).get("raw") if isinstance((ev or {}).get("raw"), dict) else {}


def _v049_first(ev: Dict[str, Any], *keys: str, default: Any = "") -> Any:
    ctx = _v049_ctx(ev)
    raw = _v049_raw(ev)
    for k in keys:
        for src in (ev, ctx, raw):
            if isinstance(src, dict):
                v = src.get(k)
                if v not in (None, "", "-"):
                    return v
    return default


def _v049_scan_id(ev: Dict[str, Any]) -> str:
    return str(_v049_first(ev, "scan_id", "snapshot_id", default="") or "")


def _v049_ts(ev: Dict[str, Any], *keys: str) -> float:
    for k in keys:
        v = _v049_first(ev, k, default=0.0)
        x = float_any(v, default=0.0)
        if x > 0:
            return x
    return 0.0


def candidate_is_fresh(ev: Dict[str, Any], control: Dict[str, Any]) -> bool:  # type: ignore[override]
    nowv = now()
    exp = _v049_ts(ev, "expires_at", "source_expires_at")
    created = _v049_ts(ev, "created_at", "candidate_created_at", "source_created_at", "detected_ts", "ts", "timestamp")
    ttl = float_any(control.get("candidate_ttl_sec"), default=120.0)
    if exp > 0:
        return exp >= nowv
    if created > 0:
        return (nowv - created) <= ttl
    return False


def candidate_fresh_stats(path: Path, control: Optional[Dict[str, Any]] = None) -> Dict[str, int]:  # type: ignore[override]
    control = control or load_control()
    rows = read_jsonl(path, max_lines=int(float_any(control.get("candidate_read_max_lines"), default=2500)))
    fresh = sum(1 for r in rows if candidate_is_fresh(r, control))
    with_scan = sum(1 for r in rows if _v049_scan_id(r))
    return {"read_window": len(rows), "fresh": fresh, "expired": max(0, len(rows) - fresh), "with_scan_id": with_scan}


def latest_scan_filter(events: List[Dict[str, Any]], control: Dict[str, Any]) -> Tuple[List[Dict[str, Any]], Dict[str, Any]]:  # type: ignore[override]
    meta = {"enabled": bool(control.get("consume_latest_scan_only", True)), "latest_scan_id": "", "latest_ts": 0.0, "before": len(events), "after": len(events), "scan_id_recovered": 0}
    if not meta["enabled"] or not events:
        return events, meta
    normalized: List[Dict[str, Any]] = []
    for ev in events or []:
        if not isinstance(ev, dict):
            continue
        row = dict(ev)
        sid = _v049_scan_id(row)
        if sid and not row.get("scan_id"):
            row["scan_id"] = sid
            meta["scan_id_recovered"] = int(meta.get("scan_id_recovered", 0)) + 1
        ts = _v049_ts(row, "created_at", "candidate_created_at", "source_created_at", "detected_ts", "ts", "timestamp")
        if ts > 0 and not float_any(row.get("created_at"), default=0.0):
            row["created_at"] = ts
        normalized.append(row)
    scan_rows = [e for e in normalized if _v049_scan_id(e)]
    if scan_rows:
        def key(e: Dict[str, Any]):
            return (_v049_ts(e, "created_at", "candidate_created_at", "source_created_at"), _v049_scan_id(e))
        latest = max(scan_rows, key=key)
        sid = _v049_scan_id(latest)
        out = [e for e in normalized if _v049_scan_id(e) == sid]
        meta.update({"latest_scan_id": sid, "latest_ts": _v049_ts(latest, "created_at", "candidate_created_at", "source_created_at"), "after": len(out)})
        return out, meta
    latest_ts = max((_v049_ts(e, "created_at", "candidate_created_at", "source_created_at") for e in normalized), default=0.0)
    if latest_ts <= 0:
        meta.update({"after": len(normalized)})
        return normalized, meta
    win = max(1.0, float_any(control.get("latest_scan_window_sec"), default=8.0))
    out = [e for e in normalized if _v049_ts(e, "created_at", "candidate_created_at", "source_created_at") >= latest_ts - win]
    meta.update({"latest_ts": latest_ts, "after": len(out)})
    return out, meta


_v048_open_position = open_position

def open_position(pos_id: str, ev: Dict[str, Any], control: Dict[str, Any]) -> Dict[str, Any]:  # type: ignore[override]
    pos = _v048_open_position(pos_id, ev, control)
    sid = _v049_scan_id(ev)
    snapshot_id = str(_v049_first(ev, "snapshot_id", default=sid) or sid)
    cand_ts = _v049_ts(ev, "candidate_created_at", "created_at", "source_created_at")
    if sid:
        pos["scan_id"] = sid
    if snapshot_id:
        pos["snapshot_id"] = snapshot_id
    if cand_ts > 0:
        pos["candidate_created_at"] = cand_ts
    ctx = pos.get("entry_context") if isinstance(pos.get("entry_context"), dict) else {}
    ctx = dict(ctx)
    if sid:
        ctx["scan_id"] = sid
    if snapshot_id:
        ctx["snapshot_id"] = snapshot_id
    if cand_ts > 0:
        ctx["candidate_created_at"] = cand_ts
    pos["entry_context"] = ctx
    return pos


def _v049_open_watch_status(pos: Dict[str, Any], control: Optional[Dict[str, Any]] = None) -> str:
    control = control or load_control()
    opened = float_any((pos or {}).get("opened_at"), default=now())
    age_sec = max(0.0, now() - opened)
    age_min = age_sec / 60.0
    net = float_any((pos or {}).get("last_pnl_pct"), default=0.0)
    peak = float_any((pos or {}).get("peak_pct"), default=0.0)
    reason, note = _exit_rule_decision(pos, control, age_min=age_min, net=net, peak=peak)
    if reason:
        return f"{exit_reason_kr(reason)} 조건감시 / {note}"
    if age_sec < float_any(control.get("quick_stop_min_age_sec"), default=180):
        return f"빠른손절 대기 {int(age_sec)}초 / 최고 {peak:+.2f}%"
    if peak > float_any(control.get("quick_stop_peak_under_pct"), default=0.10) and age_sec <= float_any(control.get("bounce_fail_max_age_sec"), default=900):
        dd = max(0.0, peak - net)
        return f"반등실패 감시 / 최고 {peak:+.2f}% 현재 {net:+.2f}% 되밀림 {dd:.2f}%"
    if age_min < float_any(control.get("slow_early_minutes"), default=10):
        return f"지지부진 감시 대기 {age_min:.1f}분 / 최고 {peak:+.2f}%"
    if age_min < float_any(control.get("time_exit_minutes"), default=120):
        return f"time_exit 대기 / 최고 {peak:+.2f}% 현재 {net:+.2f}%"
    return f"시간종료 감시 / 보유 {age_min:.1f}분"


def format_open_list(limit: int = 20) -> str:  # type: ignore[override]
    open_pos = load_open()
    if not open_pos:
        return "OPEN 없음"
    control = load_control()
    rows = sorted(open_pos.values(), key=lambda x: float_any(x.get("opened_at"), default=0.0), reverse=True)[:limit]
    lines = []
    for pos in rows:
        age = (now() - float_any(pos.get("opened_at"), default=now())) / 60.0
        tag = "신규" if float_any(pos.get("opened_at"), default=0.0) >= baseline_ts() else "기존"
        hold_txt = hold_text_from_seconds(age * 60)
        opened_txt = opened_text_from_row(pos)[5:16] if opened_text_from_row(pos) != "-" else "-"
        scan = str(pos.get("scan_id") or ((pos.get("entry_context") or {}).get("scan_id") if isinstance(pos.get("entry_context"), dict) else "") or "-")
        watch = _v049_open_watch_status(pos, control)
        lines.append(f"- {short_ticker(pos.get('ticker'))} / {tag} / {pos.get('lane','-')} / 진입 {opened_txt} {format_price(pos.get('entry_price'))} / 현재 {format_price(pos.get('current_price'))} / {float_any(pos.get('last_pnl_pct'), default=0.0):+.2f}% / 보유 {hold_txt} / scan {scan} / 감시 {watch}")
    return "\n".join(lines)


# ===============================
# paper_bot v0.50: OPEN 전용 빠른 청산감시 + 손실 하드가드
# - 후보 읽기 cycle은 기존 8초를 유지한다.
# - OPEN 포지션은 worker wait 중 1~2초 단위로 따로 감시한다.
# - -2%까지 끌리는 것을 막기 위해 -1% 안팎 하드가드를 둔다.
# - quick_stop/bounce_fail/hard_loss_guard 내부키를 한글 출력으로 정리한다.
# ===============================

EXIT_REASON_KR.update({
    "quick_stop": "빠른손절 종료",
    "bounce_fail": "반등실패 조기손절",
    "slow_early_exit": "지지부진 조기종료",
    "hard_loss_guard": "손실하드가드 종료",
    "long_loss_guard": "장기손실 정리",
})

def exit_reason_kr(reason: Any) -> str:  # type: ignore[override]
    return EXIT_REASON_KR.get(str(reason or ""), str(reason or "-"))


def _v050_weak_reasons_from_ctx(ctx: Dict[str, Any]) -> List[str]:
    buy = float_any(ctx.get("micro_trade_buy_ratio_30"), default=0.0)
    spread = float_any(ctx.get("micro_spread_pct"), default=999.0)
    pull = float_any(ctx.get("pullback_quality_score"), default=0.0)
    rebreak = float_any(ctx.get("rebreakout_strength"), default=0.0)
    price_recheck = float_any(ctx.get("price_recheck_pct"), default=0.0)
    bid_wall = float_any(ctx.get("micro_bid_ask_wall_ratio"), default=0.0)
    tags = " / ".join(str(x) for x in (ctx.get("quality_risk_tags") or [])) if isinstance(ctx.get("quality_risk_tags"), list) else str(ctx.get("quality_risk_tags") or "")
    reasons: List[str] = []
    if buy > 0 and buy <= 0.55:
        reasons.append(f"매수비 {buy:.2f}")
    if spread < 900 and spread >= 0.20:
        reasons.append(f"스프레드 {spread:.2f}%")
    if price_recheck < 0:
        reasons.append(f"가격재확인 {price_recheck:.2f}%")
    if rebreak > 0 and rebreak < 1.20:
        reasons.append(f"재돌파 {rebreak:.2f}")
    if pull > 0 and pull < 1.00:
        reasons.append(f"눌림 {pull:.2f}")
    if bid_wall > 0 and bid_wall < 0.80:
        reasons.append(f"매수벽 {bid_wall:.2f}")
    if bool(ctx.get("micro_sell_trade_pressure") or ctx.get("micro_ask_wall_pressure")):
        reasons.append("매도압박")
    if "재돌파힘 약함" in tags:
        reasons.append("재돌파힘 약함")
    if "눌림품질 약함" in tags:
        reasons.append("눌림품질 약함")
    if "매도벽" in tags:
        reasons.append("매도벽 주의")
    return list(dict.fromkeys(reasons))


def _exit_rule_decision(pos: Dict[str, Any], control: Dict[str, Any], *, age_min: float, net: float, peak: float) -> Tuple[Optional[str], str]:  # type: ignore[override]
    ctx = _position_entry_ctx(pos)
    age_sec = max(0.0, age_min * 60.0)
    drawdown = max(0.0, peak - net)
    weak = _v050_weak_reasons_from_ctx(ctx)

    # 0) 최우선 장부 보호: 어떤 후보든 -1% 안팎을 넘으면 더 끌지 않는다.
    if bool(control.get("hard_loss_guard_enabled", True)):
        hard_pct = float_any(control.get("hard_loss_guard_pct"), default=-0.95)
        if net <= hard_pct:
            return "hard_loss_guard", f"현재 {net:+.2f}% / 하드가드 {hard_pct:+.2f}% / 최고 {peak:+.2f}%"

    # 1) 초반 약반응/무반응 손절: +0.2% 이하만 주고 밀리면 기존 손절 전 정리.
    if bool(control.get("quick_stop_enabled", True)):
        min_age = float_any(control.get("quick_stop_min_age_sec"), default=90.0)
        max_age = float_any(control.get("quick_stop_max_age_sec"), default=600.0)
        peak_under = float_any(control.get("quick_stop_peak_under_pct"), default=0.20)
        current_under = float_any(control.get("quick_stop_current_under_pct"), default=-0.35)
        if min_age <= age_sec <= max_age and peak <= peak_under and net <= current_under:
            # 외부 약점이 뚜렷하거나 5분 이상 반응이 없으면 자른다.
            if weak or age_sec >= 300:
                note = ", ".join(weak[:3]) if weak else "초반반응 없음"
                return "quick_stop", f"진입 {int(age_sec)}초 / 최고 {peak:+.2f}% / 현재 {net:+.2f}% / {note}"

    # 2) 조금 갔다가 되밀리는 반등실패형.
    if bool(control.get("bounce_fail_enabled", True)):
        min_age = float_any(control.get("bounce_fail_min_age_sec"), default=180.0)
        max_age = float_any(control.get("bounce_fail_max_age_sec"), default=1800.0)
        peak_min = float_any(control.get("bounce_fail_peak_min_pct"), default=0.10)
        peak_max = float_any(control.get("bounce_fail_peak_max_pct"), default=0.70)
        current_under = float_any(control.get("bounce_fail_current_under_pct"), default=-0.45)
        dd_min = float_any(control.get("bounce_fail_drawdown_from_peak_pct"), default=0.60)
        if min_age <= age_sec <= max_age and peak_min <= peak <= peak_max and net <= current_under and drawdown >= dd_min:
            extra = (" / " + ", ".join(weak[:2])) if weak else ""
            return "bounce_fail", f"진입 {int(age_sec)}초 / 최고 {peak:+.2f}% → 현재 {net:+.2f}% / 되밀림 {drawdown:.2f}%{extra}"

    # 3) 오래 들고 있는 손실 포지션 정리: HOOK 같은 장기 손실 방지.
    if bool(control.get("long_loss_guard_enabled", True)):
        min_age = float_any(control.get("long_loss_guard_min_age_sec"), default=900.0)
        current_under = float_any(control.get("long_loss_guard_current_under_pct"), default=-0.45)
        peak_under = float_any(control.get("long_loss_guard_peak_under_pct"), default=0.60)
        if age_sec >= min_age and net <= current_under and peak < peak_under:
            return "long_loss_guard", f"보유 {age_min:.1f}분 / 최고 {peak:+.2f}% / 현재 {net:+.2f}%"

    # 4) 시간만 쓰고 안 가는 후보.
    if bool(control.get("slow_early_enabled", True)):
        min_min = float_any(control.get("slow_early_minutes"), default=10.0)
        peak_under = float_any(control.get("slow_early_peak_under_pct"), default=0.10)
        current_under = float_any(control.get("slow_early_current_under_pct"), default=0.05)
        if age_min >= min_min and peak <= peak_under and net <= current_under:
            note = ", ".join(weak[:3]) if weak else "최고수익 약함"
            return "slow_early_exit", f"보유 {age_min:.1f}분 / 최고 {peak:+.2f}% / 현재 {net:+.2f}% / {note}"
    return None, ""


_v050_original_run_cycle = run_cycle

def monitor_open_positions(control: Optional[Dict[str, Any]] = None) -> Dict[str, Any]:
    """OPEN 포지션만 빠르게 감시한다. 후보파일은 읽지 않는다."""
    global _CYCLE_PRICE_MAP
    started = now()
    control = control or load_control()
    with _state_lock:
        open_pos = load_open()
        if not open_pos:
            return {"checked": 0, "closed": 0, "elapsed_sec": round(now() - started, 3)}
        # OPEN은 보통 소수라 가격맵 1회 조회만으로 빠르게 감시한다.
        _CYCLE_PRICE_MAP = fetch_all_bithumb_prices()
        closed_items: List[Dict[str, Any]] = []
        checked = 0
        for pos_id, pos in list(open_pos.items()):
            try:
                checked += 1
                updated, closed = update_position(pos, control)
                if closed:
                    closed_items.append(closed)
                    open_pos.pop(pos_id, None)
                    append_jsonl(FILES["closed"], closed)
                else:
                    open_pos[pos_id] = updated
            except Exception as exc:
                log_error("monitor_open_position", exc)
        save_open(open_pos)
        if closed_items:
            try:
                notify_strict_events([], closed_items, control)
            except Exception as exc:
                log_error("monitor_notify_close", exc)
        # status에 빠른 감시 흔적만 가볍게 보강한다.
        st = load_json(FILES["status"], {})
        if not isinstance(st, dict):
            st = {}
        st.update({
            "version": VERSION,
            "updated_at": now(),
            "updated_at_text": iso_ts(),
            "fast_monitor_checked": checked,
            "fast_monitor_closed": len(closed_items),
            "fast_monitor_elapsed_sec": round(now() - started, 3),
            "fast_monitor_note": "v0.50: OPEN 전용 1~2초 청산감시",
            "open_total": len(open_pos),
            "closed_total": closed_count(),
        })
        save_json(FILES["status"], st)
        if closed_items:
            log(f"fast_monitor closed={len(closed_items)} checked={checked} elapsed={round(now()-started,3)}s")
        return {"checked": checked, "closed": len(closed_items), "elapsed_sec": round(now() - started, 3)}


def worker_loop() -> None:  # type: ignore[override]
    log("worker_loop v0.50 started")
    next_full = 0.0
    while not _stop_event.is_set():
        try:
            control = load_control()
            heartbeat_log("worker")
            if control.get("running"):
                nowv = now()
                if nowv >= next_full:
                    _v050_original_run_cycle()
                    next_full = now() + float_any(control.get("loop_seconds"), default=8.0)
                else:
                    monitor_open_positions(control)
            interval = max(0.8, min(3.0, float_any(control.get("open_monitor_interval_sec"), default=1.5)))
            _stop_event.wait(interval)
        except Exception as exc:
            log_error("worker_loop_v050", exc)
            _stop_event.wait(2)
    log("worker_loop v0.50 stopped")


def _v050_open_watch_status(pos: Dict[str, Any], control: Optional[Dict[str, Any]] = None) -> str:
    control = control or load_control()
    opened = float_any((pos or {}).get("opened_at"), default=now())
    age_sec = max(0.0, now() - opened)
    age_min = age_sec / 60.0
    net = float_any((pos or {}).get("last_pnl_pct"), default=0.0)
    peak = float_any((pos or {}).get("peak_pct"), default=0.0)
    reason, note = _exit_rule_decision(pos, control, age_min=age_min, net=net, peak=peak)
    if reason:
        return f"{exit_reason_kr(reason)} 조건감시 / {note}"
    hard_pct = float_any(control.get("hard_loss_guard_pct"), default=-0.95)
    if net <= hard_pct + 0.25:
        return f"손실하드가드 근접 / 현재 {net:+.2f}% / 기준 {hard_pct:+.2f}% / 최고 {peak:+.2f}%"
    if age_sec < float_any(control.get("quick_stop_min_age_sec"), default=90):
        return f"빠른손절 대기 {int(age_sec)}초 / 최고 {peak:+.2f}%"
    if age_min < float_any(control.get("slow_early_minutes"), default=10):
        return f"반응감시 / 최고 {peak:+.2f}% 현재 {net:+.2f}%"
    if age_min < float_any(control.get("time_exit_minutes"), default=120):
        return f"time_exit 대기 / 최고 {peak:+.2f}% 현재 {net:+.2f}%"
    return f"시간종료 감시 / 보유 {age_min:.1f}분"


def _v049_open_watch_status(pos: Dict[str, Any], control: Optional[Dict[str, Any]] = None) -> str:  # type: ignore[override]
    return _v050_open_watch_status(pos, control)


# /palerts 출력 문구 보강
_v050_original_alert_policy_text = alert_policy_text if 'alert_policy_text' in globals() else None



# ===============================
# paper_bot v0.64: sweep_vwap_recovery 단일 전략 검증 본선
# - v0.52~v0.63의 돈흐름/평균회귀/3전략 표시·보정 override를 active path에서 제거한다.
# - 신규 OPEN은 sweep_vwap_recovery trade_ready 후보만 허용한다.
# - 청산은 설계서 고정값만 사용한다: 익절 +1.20 / 보호 +0.70 이후 +0.30 / 손절 -0.55 / 시간 15분.
# - 기존 OPEN/CLOSED 장부 삭제 없음.
# ===============================
try:
    VERSION = "paper_bot_v0.66"
except Exception:
    pass

PAPER_FOCUS_STRATEGY_KEY = "sweep_vwap_recovery"
PAPER_FOCUS_STRATEGY_LABEL = "저점 쓸림 후 VWAP 회복 단타"
PAPER_FOCUS_TAG = "쓸림VWAP"
PAPER_FOCUS_MAIN_MODE = "sweep_vwap_recovery_only"

DEFAULT_CONTROL.update({
    "new_open_paused": False,
    "max_open_strict": 0,
    "max_open_shadow": 0,
    "max_new_per_cycle": 0,
    "open_trade_ready_only": True,
    "open_shadow_positions": False,
    "shadow_review_only": True,
    "take_profit_pct": 1.20,
    "protect_trigger_pct": 0.70,
    "protect_floor_pct": 0.30,
    "stop_loss_pct": -0.55,
    "time_exit_minutes": 15,
    "quick_stop_enabled": False,
    "slow_early_enabled": False,
    "long_loss_guard_enabled": False,
    "notify_on_strict_open": True,
    "notify_on_strict_close": True,
    "notify_open_auto_ready_only": True,
    "notify_open_min_score": 4.45,
    "notify_open_require_final_pass": True,
    "notify_open_require_micro_fresh": True,
    "preopen_micro_recheck": True,
    "notify_close_only_alerted": False,
})

_v064_base_load_control = load_control

def load_control() -> Dict[str, Any]:  # type: ignore[override]
    control = _v064_base_load_control()
    fixed = {
        "new_open_paused": False,
        "max_open_strict": 0,
        "max_open_shadow": 0,
        "max_new_per_cycle": 0,
        "open_trade_ready_only": True,
        "open_shadow_positions": False,
        "shadow_review_only": True,
        "take_profit_pct": 1.20,
        "protect_trigger_pct": 0.70,
        "protect_floor_pct": 0.30,
        "stop_loss_pct": -0.55,
        "time_exit_minutes": 15,
        "quick_stop_enabled": False,
        "slow_early_enabled": False,
        "long_loss_guard_enabled": False,
        "notify_close_only_alerted": False,
    }
    changed = False
    for k, v in fixed.items():
        if control.get(k) != v:
            control[k] = v
            changed = True
    if changed:
        try:
            save_json(FILES["control"], control)
            set_pause_flags(bool(control.get("running")))
        except Exception:
            pass
    return control


def _v064_ctx(row: Dict[str, Any]) -> Dict[str, Any]:
    return (row or {}).get("entry_context") if isinstance((row or {}).get("entry_context"), dict) else {}


def _v064_field(row: Dict[str, Any], *keys: str) -> Any:
    ctx = _v064_ctx(row)
    raw = (row or {}).get("raw") if isinstance((row or {}).get("raw"), dict) else {}
    for k in keys:
        if (row or {}).get(k) not in (None, ""):
            return (row or {}).get(k)
        if raw.get(k) not in (None, ""):
            return raw.get(k)
        if ctx.get(k) not in (None, ""):
            return ctx.get(k)
    return ""


def _v064_strategy_key(row: Dict[str, Any]) -> str:
    return str(_v064_field(row, "paper_strategy_key", "strategy_key", "paper_route", "route", "strategy") or "")


def _v052_is_focus_strategy(row: Dict[str, Any]) -> bool:  # compatibility name used by older helpers
    key = _v064_strategy_key(row)
    label = str(_v064_field(row, "paper_strategy_label", "strategy_label", "strategy_display", "strategy") or "")
    return key == PAPER_FOCUS_STRATEGY_KEY or PAPER_FOCUS_STRATEGY_KEY in key or "저점 쓸림" in label or "VWAP 회복" in label


def _v054_text_has_focus(v: Any) -> bool:
    s = str(v or "")
    return PAPER_FOCUS_STRATEGY_KEY in s or "sweep_vwap" in s or "저점 쓸림" in s or "VWAP 회복" in s


_base_strategy_kr_v064 = strategy_kr

def strategy_kr(strategy: Any) -> str:  # type: ignore[override]
    s = str(strategy or "")
    if _v054_text_has_focus(s):
        return PAPER_FOCUS_STRATEGY_LABEL
    return _base_strategy_kr_v064(strategy)


_v064_base_open_position = open_position

def open_position(pos_id: str, ev: Dict[str, Any], control: Dict[str, Any]) -> Dict[str, Any]:  # type: ignore[override]
    pos = _v064_base_open_position(pos_id, ev, control)
    if _v052_is_focus_strategy(ev):
        pos.update({
            "strategy": PAPER_FOCUS_STRATEGY_LABEL,
            "strategy_key": PAPER_FOCUS_STRATEGY_KEY,
            "strategy_label": PAPER_FOCUS_STRATEGY_LABEL,
            "paper_strategy_key": PAPER_FOCUS_STRATEGY_KEY,
            "paper_strategy_label": PAPER_FOCUS_STRATEGY_LABEL,
            "route": PAPER_FOCUS_STRATEGY_KEY,
            "paper_route": PAPER_FOCUS_STRATEGY_KEY,
            "main_mode": PAPER_FOCUS_MAIN_MODE,
            "single_strategy_mode": True,
            "strategy_test_version": "v288_sweep_vwap_recovery_30_closed_fixed",
            "take_profit_pct_at_open": float_any(control.get("take_profit_pct"), default=1.20),
            "protect_trigger_pct_at_open": float_any(control.get("protect_trigger_pct"), default=0.70),
            "protect_floor_pct_at_open": float_any(control.get("protect_floor_pct"), default=0.30),
            "stop_loss_pct_at_open": float_any(control.get("stop_loss_pct"), default=-0.55),
            "time_exit_minutes_at_open": float_any(control.get("time_exit_minutes"), default=15),
        })
        ctx = pos.get("entry_context") if isinstance(pos.get("entry_context"), dict) else {}
        ctx = dict(ctx)
        ctx.update({
            "paper_strategy_key": PAPER_FOCUS_STRATEGY_KEY,
            "paper_strategy_label": PAPER_FOCUS_STRATEGY_LABEL,
            "strategy_key": PAPER_FOCUS_STRATEGY_KEY,
            "strategy_label": PAPER_FOCUS_STRATEGY_LABEL,
        })
        pos["entry_context"] = ctx
    return pos


_v064_base_update_position = update_position

def update_position(pos: Dict[str, Any], control: Dict[str, Any]) -> Tuple[Dict[str, Any], Optional[Dict[str, Any]]]:  # type: ignore[override]
    updated, closed = _v064_base_update_position(pos, control)
    if closed is not None and _v052_is_focus_strategy(pos):
        closed.update({
            "strategy": PAPER_FOCUS_STRATEGY_LABEL,
            "strategy_key": PAPER_FOCUS_STRATEGY_KEY,
            "strategy_label": PAPER_FOCUS_STRATEGY_LABEL,
            "paper_strategy_key": PAPER_FOCUS_STRATEGY_KEY,
            "paper_strategy_label": PAPER_FOCUS_STRATEGY_LABEL,
            "route": PAPER_FOCUS_STRATEGY_KEY,
            "paper_route": PAPER_FOCUS_STRATEGY_KEY,
            "main_mode": PAPER_FOCUS_MAIN_MODE,
            "strategy_test_version": "v288_sweep_vwap_recovery_30_closed_fixed",
        })
        ctx = closed.get("entry_context") if isinstance(closed.get("entry_context"), dict) else {}
        ctx = dict(ctx)
        ctx.update({
            "paper_strategy_key": PAPER_FOCUS_STRATEGY_KEY,
            "paper_strategy_label": PAPER_FOCUS_STRATEGY_LABEL,
            "strategy_key": PAPER_FOCUS_STRATEGY_KEY,
            "strategy_label": PAPER_FOCUS_STRATEGY_LABEL,
        })
        closed["entry_context"] = ctx
    return updated, closed


def _v064_focus_closed_rows(limit: int = 20000) -> List[Dict[str, Any]]:
    rows = read_jsonl(FILES["closed"], max_lines=limit)
    return [r for r in rows if str(r.get("lane") or "strict") == "strict" and _v052_is_focus_strategy(r)]


def _v064_focus_open_positions(open_pos: Optional[Dict[str, Dict[str, Any]]] = None) -> Dict[str, Dict[str, Any]]:
    open_pos = open_pos if isinstance(open_pos, dict) else load_open()
    return {k: v for k, v in (open_pos or {}).items() if _v052_is_focus_strategy(v)}


def _v064_stats(rows: List[Dict[str, Any]]) -> Dict[str, Any]:
    vals = [float_any(r.get("net_pct"), r.get("pnl_pct"), default=0.0) for r in rows or []]
    wins = sum(1 for v in vals if v > 0)
    total = sum(vals)
    return {"n": len(vals), "wins": wins, "losses": len(vals)-wins, "win_rate": (wins/len(vals)*100 if vals else 0.0), "total": total, "avg": (total/len(vals) if vals else 0.0)}


def _v064_strategy_label(row: Dict[str, Any]) -> str:
    return PAPER_FOCUS_STRATEGY_LABEL if _v052_is_focus_strategy(row) else strategy_kr(_v064_field(row, "strategy", "route", "strategy_key"))


def _v064_open_strategy_counts(open_pos: Dict[str, Dict[str, Any]]) -> str:
    c = Counter(_v064_strategy_label(p) for p in (open_pos or {}).values())
    return " / ".join(f"{k} {v}" for k, v in c.most_common(5)) if c else "-"


def format_open_list(limit: int = 20) -> str:  # type: ignore[override]
    open_pos = load_open()
    if not open_pos:
        return "OPEN 없음"
    rows = sorted(open_pos.values(), key=lambda x: float_any(x.get("opened_at"), default=0.0), reverse=True)[:max(1, min(limit, 10))]
    control = load_control()
    lines = [f"전략별 OPEN: {_v064_open_strategy_counts(open_pos)}"]
    for pos in rows:
        age = (now() - float_any(pos.get("opened_at"), default=now())) / 60.0
        hold_txt = hold_text_from_seconds(age * 60)
        opened_txt = opened_text_from_row(pos)[5:16] if opened_text_from_row(pos) != "-" else "-"
        watch = _v049_open_watch_status(pos, control)
        cls = PAPER_FOCUS_TAG if _v052_is_focus_strategy(pos) else "기존"
        lines.append(
            f"- {short_ticker(pos.get('ticker'))} / {cls} / {_v064_strategy_label(pos)} / "
            f"진입 {opened_txt} {format_price(pos.get('entry_price'))} / 현재 {format_price(pos.get('current_price'))} / "
            f"{float_any(pos.get('last_pnl_pct'), default=0.0):+.2f}% / 보유 {hold_txt} / 감시 {watch} / 최고 {fmt_pct(pos.get('peak_pct'))}"
        )
    if len(open_pos) > len(rows):
        lines.append(f"- 나머지 {len(open_pos)-len(rows)}개는 /popen 에서 확인")
    return "\n".join(lines)


def summary_text() -> str:  # type: ignore[override]
    control = load_control()
    status = load_json(FILES["status"], {})
    open_pos = load_open()
    focus_open = _v064_focus_open_positions(open_pos)
    focus_closed = _v064_focus_closed_rows()
    fs = file_stats()
    pick = status.get("pick_stats") if isinstance(status.get("pick_stats"), dict) else {}
    st = _v064_stats(focus_closed)
    return "\n".join([
        f"🧪 페이퍼봇 {VERSION}",
        f"- 실행상태: {'ON' if control.get('running') else 'OFF'} / loop {control.get('loop_seconds')}s",
        f"- 현재전략: {PAPER_FOCUS_STRATEGY_LABEL}",
        f"- 신규 OPEN: {'중지' if control.get('new_open_paused') else '허용'} / 단, {PAPER_FOCUS_STRATEGY_KEY} trade_ready만",
        f"- OPEN: 현재전략 {len(focus_open)} / 전체 {len(open_pos)} / 한도 {control.get('max_open_strict')}",
        f"- CLOSED: 현재전략 {st['n']}/30 / 승률 {st['win_rate']:.1f}% / 합산 {st['total']:+.2f}% / 평균 {st['avg']:+.2f}%",
        f"- 청산고정: 익절 +{float_any(control.get('take_profit_pct'), default=1.2):.2f}% / 보호 +{float_any(control.get('protect_trigger_pct'), default=0.7):.2f}%→+{float_any(control.get('protect_floor_pct'), default=0.3):.2f}% / 손절 {float_any(control.get('stop_loss_pct'), default=-0.55):.2f}% / 시간 {float_any(control.get('time_exit_minutes'), default=15):.0f}분",
        "",
        "[후보]",
        f"- 읽음 {pick.get('paper_file',0)} / 신규중지 {pick.get('new_open_paused',0)} / not_ready {pick.get('not_trade_ready_skip',0)} / micro대기 {pick.get('micro_preopen_wait',0)} / 중복 {pick.get('same_ticker_skip',0)}",
        "",
        "[원칙]",
        "- CLOSED 30건 전 조건 변경 금지 / 오류·장부·정보수집 배관만 수정",
        f"- 오류로그 {fs.get('error', {}).get('size', 0)} bytes / 자세히 /perror",
    ])


# ─────────────────────────────────────────────────────────────────────────────
# v0.65: 같은 코인 반복손실 재진입 차단
# 목적: 전략 조건을 새로 추가하는 게 아니라, 설계서에 있던
# "최근 같은 코인 반복 손실 금지"를 paper OPEN 단일 입구에 실제 연결한다.
# - OPEN 중복 차단은 기존 block_same_ticker_open이 담당한다.
# - 여기서는 CLOSED 직후 같은 ticker가 다시 strict 후보로 들어와 연속 손실나는 경로를 막는다.
# - paper 장부는 읽기만 하고 삭제/수정하지 않는다.
# ─────────────────────────────────────────────────────────────────────────────
PAPER_REPEAT_LOSS_LOOKBACK_SEC = float(os.getenv("PAPER_REPEAT_LOSS_LOOKBACK_SEC", str(6 * 3600)))
PAPER_SINGLE_LOSS_COOLDOWN_SEC = float(os.getenv("PAPER_SINGLE_LOSS_COOLDOWN_SEC", str(60 * 60)))
PAPER_REPEAT_LOSS_COOLDOWN_SEC = float(os.getenv("PAPER_REPEAT_LOSS_COOLDOWN_SEC", str(6 * 3600)))
PAPER_REPEAT_LOSS_THRESHOLD = int(float(os.getenv("PAPER_REPEAT_LOSS_THRESHOLD", "2")))


def _v065_closed_pnl(row: Dict[str, Any]) -> float:
    return float_any((row or {}).get("net_pct"), (row or {}).get("pnl_pct"), default=0.0)


def _v065_closed_time(row: Dict[str, Any]) -> float:
    return float_any((row or {}).get("closed_at"), default=0.0)


def _v065_recent_loss_block_map(now_ts: Optional[float] = None, limit: int = 6000) -> Dict[str, Dict[str, Any]]:
    """최근 CLOSED 기준 같은 코인 재진입 차단표를 만든다.

    차단 기준:
    - 같은 전략에서 직전 CLOSED가 손실이고 60분 이내면 차단.
    - 최근 6시간 내 같은 ticker 손실이 2회 이상이면 6시간 차단.

    이것은 조건 완화/강화가 아니라 paper OPEN 입구의 반복손실 보호장치다.
    """
    now_ts = float(now_ts or now())
    rows = read_jsonl(FILES["closed"], max_lines=limit)
    recent_by_ticker: Dict[str, List[Dict[str, Any]]] = defaultdict(list)
    for r in rows:
        if not isinstance(r, dict) or not _v052_is_focus_strategy(r):
            continue
        t = short_ticker(r.get("ticker") or r.get("market") or r.get("symbol"))
        if not t:
            continue
        cts = _v065_closed_time(r)
        if cts <= 0 or now_ts - cts > max(PAPER_REPEAT_LOSS_LOOKBACK_SEC, PAPER_REPEAT_LOSS_COOLDOWN_SEC, PAPER_SINGLE_LOSS_COOLDOWN_SEC) + 300:
            continue
        recent_by_ticker[t].append(r)

    block: Dict[str, Dict[str, Any]] = {}
    for t, arr in recent_by_ticker.items():
        arr.sort(key=_v065_closed_time, reverse=True)
        last = arr[0]
        last_pnl = _v065_closed_pnl(last)
        last_ts = _v065_closed_time(last)
        recent_losses = [r for r in arr if now_ts - _v065_closed_time(r) <= PAPER_REPEAT_LOSS_LOOKBACK_SEC and _v065_closed_pnl(r) < 0]

        cooldown_until = 0.0
        reason = ""
        if len(recent_losses) >= max(1, PAPER_REPEAT_LOSS_THRESHOLD):
            latest_loss_ts = max(_v065_closed_time(r) for r in recent_losses)
            cooldown_until = latest_loss_ts + PAPER_REPEAT_LOSS_COOLDOWN_SEC
            reason = f"최근 {int(PAPER_REPEAT_LOSS_LOOKBACK_SEC//3600)}시간 손실 {len(recent_losses)}회"
        elif last_pnl < 0:
            cooldown_until = last_ts + PAPER_SINGLE_LOSS_COOLDOWN_SEC
            reason = "직전 CLOSED 손실"

        if cooldown_until > now_ts:
            block[t] = {
                "ticker": t,
                "reason": reason,
                "loss_count": len(recent_losses),
                "last_pnl": round(last_pnl, 4),
                "last_closed_at": last_ts,
                "last_closed_at_text": iso_ts(last_ts),
                "cooldown_until": cooldown_until,
                "cooldown_until_text": iso_ts(cooldown_until),
                "remain_min": round((cooldown_until - now_ts) / 60.0, 1),
            }
    return block


_v065_base_pick_candidates = pick_candidates


def pick_candidates(control: Dict[str, Any], open_pos: Dict[str, Dict[str, Any]]) -> Tuple[List[Tuple[str, Dict[str, Any]]], Dict[str, int]]:  # type: ignore[override]
    picked, stats = _v065_base_pick_candidates(control, open_pos)
    block_map = _v065_recent_loss_block_map()
    if not picked or not block_map:
        if isinstance(stats, dict):
            stats.setdefault("recent_loss_cooldown_skip", 0)
            stats.setdefault("recent_loss_cooldown_tickers", [])
        return picked, stats

    kept: List[Tuple[str, Dict[str, Any]]] = []
    skipped: List[str] = []
    skipped_meta: List[Dict[str, Any]] = []
    for eid, ev in picked:
        t = short_ticker((ev or {}).get("ticker") or (ev or {}).get("market") or (ev or {}).get("symbol"))
        meta = block_map.get(t)
        if meta and _v052_is_focus_strategy(ev):
            skipped.append(t)
            skipped_meta.append(meta)
            continue
        kept.append((eid, ev))
    if isinstance(stats, dict):
        stats["recent_loss_cooldown_skip"] = int(stats.get("recent_loss_cooldown_skip", 0)) + len(skipped)
        stats["recent_loss_cooldown_tickers"] = skipped[:12]
        stats["recent_loss_cooldown_meta"] = skipped_meta[:8]
    return kept, stats


_v065_base_summary_text = summary_text


def summary_text() -> str:  # type: ignore[override]
    control = load_control()
    status = load_json(FILES["status"], {})
    open_pos = load_open()
    focus_open = _v064_focus_open_positions(open_pos)
    focus_closed = _v064_focus_closed_rows()
    fs = file_stats()
    pick = status.get("pick_stats") if isinstance(status.get("pick_stats"), dict) else {}
    st = _v064_stats(focus_closed)
    repeat = int(float_any(pick.get("recent_loss_cooldown_skip"), default=0))
    repeat_ticks = pick.get("recent_loss_cooldown_tickers") if isinstance(pick.get("recent_loss_cooldown_tickers"), list) else []
    repeat_line = f" / 반복손실차단 {repeat}" + (f" ({', '.join(map(str, repeat_ticks[:5]))})" if repeat_ticks else "")
    return "\n".join([
        f"🧪 페이퍼봇 {VERSION}",
        f"- 실행상태: {'ON' if control.get('running') else 'OFF'} / loop {control.get('loop_seconds')}s",
        f"- 현재전략: {PAPER_FOCUS_STRATEGY_LABEL}",
        f"- 신규 OPEN: {'중지' if control.get('new_open_paused') else '허용'} / 단, {PAPER_FOCUS_STRATEGY_KEY} trade_ready만",
        f"- 반복손실 보호: 직전 손실 {int(PAPER_SINGLE_LOSS_COOLDOWN_SEC//60)}분 / {int(PAPER_REPEAT_LOSS_LOOKBACK_SEC//3600)}시간 내 {PAPER_REPEAT_LOSS_THRESHOLD}손실 시 {int(PAPER_REPEAT_LOSS_COOLDOWN_SEC//3600)}시간 차단",
        f"- OPEN: 현재전략 {len(focus_open)} / 전체 {len(open_pos)} / 한도 {control.get('max_open_strict')}",
        f"- CLOSED: 현재전략 {st['n']}/30 / 승률 {st['win_rate']:.1f}% / 합산 {st['total']:+.2f}% / 평균 {st['avg']:+.2f}%",
        f"- 청산고정: 익절 +{float_any(control.get('take_profit_pct'), default=1.2):.2f}% / 보호 +{float_any(control.get('protect_trigger_pct'), default=0.7):.2f}%→+{float_any(control.get('protect_floor_pct'), default=0.3):.2f}% / 손절 {float_any(control.get('stop_loss_pct'), default=-0.55):.2f}% / 시간 {float_any(control.get('time_exit_minutes'), default=15):.0f}분",
        "",
        "[후보]",
        f"- 읽음 {pick.get('paper_file',0)} / 신규중지 {pick.get('new_open_paused',0)} / not_ready {pick.get('not_trade_ready_skip',0)} / micro대기 {pick.get('micro_preopen_wait',0)} / 중복 {pick.get('same_ticker_skip',0)}" + repeat_line,
        "",
        "[원칙]",
        "- CLOSED 30건 전 조건 변경 금지 / 오류·장부·정보수집 배관만 수정",
        f"- 오류로그 {fs.get('error', {}).get('size', 0)} bytes / 자세히 /perror",
    ])


# ─────────────────────────────────────────────────────────────────────────────
# v0.66: 반복손실 완전차단 → 재진입 문턱상승 + 강한신호 예외 + 차단후보 기록
# 목적:
# - v0.65의 "직전 손실이면 60분 무조건 차단"은 좋은 2차 타이밍까지 막을 수 있다.
# - 1회 손실 코인은 기본 보류하되, 이전 진입보다 명확히 더 좋은 재진입 근거가 있을 때만 예외 허용한다.
# - 6시간 2회 이상 손실은 강한 차단 유지. 단, 차단 후보는 blocked_watch에 남겨 사후 복기한다.
# - 전략 조건/청산값/장부는 변경하지 않는다.
# ─────────────────────────────────────────────────────────────────────────────
try:
    VERSION = "paper_bot_v0.66"
except Exception:
    pass

FILES.setdefault("blocked_reentry_watch", BASE_DIR / "paper_bot_blocked_reentry_watch.jsonl")
FILES.setdefault("reentry_override_watch", BASE_DIR / "paper_bot_reentry_override_watch.jsonl")

PAPER_REENTRY_LOWER_PRICE_PCT = float(os.getenv("PAPER_REENTRY_LOWER_PRICE_PCT", "0.50"))
PAPER_REENTRY_MONEY_MULT = float(os.getenv("PAPER_REENTRY_MONEY_MULT", "1.25"))
PAPER_REENTRY_MIN_MONEY3_KRW = float(os.getenv("PAPER_REENTRY_MIN_MONEY3_KRW", "20000000"))
PAPER_REENTRY_BUY_RATIO_MIN = float(os.getenv("PAPER_REENTRY_BUY_RATIO_MIN", "0.60"))
PAPER_REENTRY_BUY_RATIO_IMPROVE = float(os.getenv("PAPER_REENTRY_BUY_RATIO_IMPROVE", "0.05"))
PAPER_REENTRY_REBREAK_MIN = float(os.getenv("PAPER_REENTRY_REBREAK_MIN", "0.80"))
PAPER_REENTRY_REBREAK_IMPROVE = float(os.getenv("PAPER_REENTRY_REBREAK_IMPROVE", "0.25"))
PAPER_REENTRY_SPREAD_MAX = float(os.getenv("PAPER_REENTRY_SPREAD_MAX", "0.25"))


def _v066_any_field(row: Dict[str, Any], *keys: str) -> Any:
    """entry/event/closed row에서 같은 의미의 값을 단일 방식으로 읽는다."""
    row = row if isinstance(row, dict) else {}
    ctx = row.get("entry_context") if isinstance(row.get("entry_context"), dict) else {}
    raw = row.get("raw") if isinstance(row.get("raw"), dict) else {}
    for k in keys:
        for src in (row, ctx, raw):
            if isinstance(src, dict) and src.get(k) not in (None, ""):
                return src.get(k)
    return ""


def _v066_metric(row: Dict[str, Any], *keys: str, default: float = 0.0) -> float:
    return float_any(_v066_any_field(row, *keys), default=default)


def _v066_entry_price(row: Dict[str, Any]) -> float:
    return float_any(
        _v066_any_field(row, "entry_price", "detected_price", "current_price", "price", "trade_price", "close"),
        default=0.0,
    )


def _v066_money3(row: Dict[str, Any]) -> float:
    return _v066_metric(
        row,
        "money_flow_3m", "turnover_3m", "turnover_3m_krw", "trade_krw_3m", "money3", "money_flow",
        default=0.0,
    )


def _v066_buy_ratio(row: Dict[str, Any]) -> float:
    return _v066_metric(row, "micro_trade_buy_ratio_30", "trade_buy_ratio_30", "buy_ratio", default=0.0)


def _v066_rebreak(row: Dict[str, Any]) -> float:
    return _v066_metric(row, "rebreakout_strength", "rebreakout", "rebreak_strength", default=0.0)


def _v066_spread(row: Dict[str, Any]) -> float:
    return _v066_metric(row, "micro_spread_pct", "orderbook_spread_pct", "spread_pct", default=999.0)


def _v066_recent_loss_gate_map(now_ts: Optional[float] = None, limit: int = 6000) -> Dict[str, Dict[str, Any]]:
    """최근 CLOSED 기준 재진입 문턱상승/강한차단 표를 만든다.

    gate 종류:
    - hard_block: 최근 6시간 내 같은 코인 손실 2회 이상. 예외 없이 OPEN 차단.
    - elevated_gate: 직전 CLOSED가 손실. 강한 재진입 조건을 통과할 때만 예외 허용.
    """
    now_ts = float(now_ts or now())
    rows = read_jsonl(FILES["closed"], max_lines=limit)
    by_ticker: Dict[str, List[Dict[str, Any]]] = defaultdict(list)
    horizon = max(PAPER_REPEAT_LOSS_LOOKBACK_SEC, PAPER_REPEAT_LOSS_COOLDOWN_SEC, PAPER_SINGLE_LOSS_COOLDOWN_SEC) + 300
    for r in rows:
        if not isinstance(r, dict) or not _v052_is_focus_strategy(r):
            continue
        t = short_ticker(r.get("ticker") or r.get("market") or r.get("symbol"))
        if not t:
            continue
        cts = _v065_closed_time(r)
        if cts <= 0 or now_ts - cts > horizon:
            continue
        by_ticker[t].append(r)

    gate: Dict[str, Dict[str, Any]] = {}
    for t, arr in by_ticker.items():
        arr.sort(key=_v065_closed_time, reverse=True)
        last = arr[0]
        last_pnl = _v065_closed_pnl(last)
        last_ts = _v065_closed_time(last)
        recent_losses = [r for r in arr if now_ts - _v065_closed_time(r) <= PAPER_REPEAT_LOSS_LOOKBACK_SEC and _v065_closed_pnl(r) < 0]
        if len(recent_losses) >= max(1, PAPER_REPEAT_LOSS_THRESHOLD):
            latest_loss_ts = max(_v065_closed_time(r) for r in recent_losses)
            until = latest_loss_ts + PAPER_REPEAT_LOSS_COOLDOWN_SEC
            if until > now_ts:
                gate[t] = {
                    "mode": "hard_block",
                    "ticker": t,
                    "reason": f"최근 {int(PAPER_REPEAT_LOSS_LOOKBACK_SEC//3600)}시간 손실 {len(recent_losses)}회",
                    "loss_count": len(recent_losses),
                    "last_loss": last,
                    "last_pnl": round(last_pnl, 4),
                    "cooldown_until": until,
                    "cooldown_until_text": iso_ts(until),
                    "remain_min": round((until - now_ts) / 60.0, 1),
                }
            continue
        if last_pnl < 0:
            until = last_ts + PAPER_SINGLE_LOSS_COOLDOWN_SEC
            if until > now_ts:
                gate[t] = {
                    "mode": "elevated_gate",
                    "ticker": t,
                    "reason": "직전 CLOSED 손실: 재진입 문턱상승",
                    "loss_count": len(recent_losses),
                    "last_loss": last,
                    "last_pnl": round(last_pnl, 4),
                    "cooldown_until": until,
                    "cooldown_until_text": iso_ts(until),
                    "remain_min": round((until - now_ts) / 60.0, 1),
                }
    return gate


def _v066_strong_reentry_ok(ev: Dict[str, Any], gate_meta: Dict[str, Any]) -> Tuple[bool, List[str]]:
    """직전 손실 코인의 예외 재진입 허용 여부.

    예외 허용은 느슨한 조건 추가가 아니라, 같은 코인 재진입 시 이전 실패보다
    명확히 더 좋은 자리인지 확인하는 보호 문턱이다.
    """
    last = gate_meta.get("last_loss") if isinstance(gate_meta.get("last_loss"), dict) else {}
    cur_price = _v066_entry_price(ev)
    last_price = _v066_entry_price(last)
    cur_money = _v066_money3(ev)
    last_money = _v066_money3(last)
    cur_buy = _v066_buy_ratio(ev)
    last_buy = _v066_buy_ratio(last)
    cur_rebreak = _v066_rebreak(ev)
    last_rebreak = _v066_rebreak(last)
    cur_spread = _v066_spread(ev)

    checks: List[Tuple[str, bool, str]] = []
    lower_ok = bool(cur_price > 0 and last_price > 0 and cur_price <= last_price * (1.0 - PAPER_REENTRY_LOWER_PRICE_PCT / 100.0))
    checks.append(("더낮은회복", lower_ok, f"현재 {cur_price:g} / 직전 {last_price:g} / 기준 -{PAPER_REENTRY_LOWER_PRICE_PCT:.2f}%"))

    if last_money > 0:
        money_need = max(PAPER_REENTRY_MIN_MONEY3_KRW, last_money * PAPER_REENTRY_MONEY_MULT)
    else:
        money_need = PAPER_REENTRY_MIN_MONEY3_KRW
    money_ok = bool(cur_money >= money_need)
    checks.append(("3분돈흐름강화", money_ok, f"현재 {cur_money/10000:.0f}만 / 기준 {money_need/10000:.0f}만"))

    buy_need = max(PAPER_REENTRY_BUY_RATIO_MIN, (last_buy + PAPER_REENTRY_BUY_RATIO_IMPROVE) if last_buy > 0 else PAPER_REENTRY_BUY_RATIO_MIN)
    buy_ok = bool(cur_buy >= buy_need)
    checks.append(("매수체결강화", buy_ok, f"현재 {cur_buy:.2f} / 기준 {buy_need:.2f}"))

    rebreak_need = max(PAPER_REENTRY_REBREAK_MIN, (last_rebreak + PAPER_REENTRY_REBREAK_IMPROVE) if last_rebreak > 0 else PAPER_REENTRY_REBREAK_MIN)
    rebreak_ok = bool(cur_rebreak >= rebreak_need)
    checks.append(("재돌파강화", rebreak_ok, f"현재 {cur_rebreak:.2f} / 기준 {rebreak_need:.2f}"))

    spread_ok = bool(cur_spread <= PAPER_REENTRY_SPREAD_MAX)
    checks.append(("스프레드양호", spread_ok, f"현재 {cur_spread:.2f}% / 기준 {PAPER_REENTRY_SPREAD_MAX:.2f}%"))

    reasons = [f"{'✅' if ok else '❌'} {name}: {txt}" for name, ok, txt in checks]
    return all(ok for _, ok, _ in checks), reasons


def _v066_watch_row(ev: Dict[str, Any], meta: Dict[str, Any], action: str, reasons: List[str]) -> Dict[str, Any]:
    t = short_ticker((ev or {}).get("ticker") or (ev or {}).get("market") or (ev or {}).get("symbol"))
    return {
        "version": VERSION,
        "ts": now(),
        "time": iso_ts(),
        "action": action,
        "ticker": t,
        "strategy_key": PAPER_FOCUS_STRATEGY_KEY,
        "event_id": event_id(ev, str((ev or {}).get("lane") or "strict")),
        "gate_mode": meta.get("mode"),
        "gate_reason": meta.get("reason"),
        "remain_min": meta.get("remain_min"),
        "last_pnl": meta.get("last_pnl"),
        "current_price": _v066_entry_price(ev),
        "money3": _v066_money3(ev),
        "buy_ratio": _v066_buy_ratio(ev),
        "rebreakout_strength": _v066_rebreak(ev),
        "spread_pct": _v066_spread(ev),
        "reasons": reasons[:8],
        "note": "반복손실 재진입 보호: OPEN 차단/예외허용 후보 사후복기용 기록. 장부 삭제 없음.",
    }


# v0.65의 완전차단 pick_candidates를 우회하고, v0.64 기본 후보선정 뒤 v0.66 gate를 적용한다.
_v066_base_pick_candidates = _v065_base_pick_candidates if "_v065_base_pick_candidates" in globals() else pick_candidates


def pick_candidates(control: Dict[str, Any], open_pos: Dict[str, Dict[str, Any]]) -> Tuple[List[Tuple[str, Dict[str, Any]]], Dict[str, int]]:  # type: ignore[override]
    picked, stats = _v066_base_pick_candidates(control, open_pos)
    gate_map = _v066_recent_loss_gate_map()
    if not picked or not gate_map:
        if isinstance(stats, dict):
            stats.setdefault("repeat_loss_hard_block", 0)
            stats.setdefault("repeat_loss_elevated_block", 0)
            stats.setdefault("repeat_loss_override_allow", 0)
            stats.setdefault("repeat_loss_block_tickers", [])
        return picked, stats

    kept: List[Tuple[str, Dict[str, Any]]] = []
    hard_blocked: List[str] = []
    elevated_blocked: List[str] = []
    override_allowed: List[str] = []
    meta_rows: List[Dict[str, Any]] = []
    for eid, ev in picked:
        t = short_ticker((ev or {}).get("ticker") or (ev or {}).get("market") or (ev or {}).get("symbol"))
        meta = gate_map.get(t)
        if not meta or not _v052_is_focus_strategy(ev):
            kept.append((eid, ev))
            continue
        mode = str(meta.get("mode") or "")
        if mode == "hard_block":
            reasons = [str(meta.get("reason") or "반복손실 강한차단")]
            hard_blocked.append(t)
            meta_rows.append({k: v for k, v in meta.items() if k != "last_loss"})
            append_jsonl(FILES["blocked_reentry_watch"], _v066_watch_row(ev, meta, "hard_block", reasons))
            continue
        ok, reasons = _v066_strong_reentry_ok(ev, meta)
        if ok:
            ev = dict(ev)
            ev["repeat_loss_reentry_override"] = True
            ev["repeat_loss_reentry_reasons"] = reasons[:8]
            override_allowed.append(t)
            append_jsonl(FILES["reentry_override_watch"], _v066_watch_row(ev, meta, "override_allow", reasons))
            kept.append((eid, ev))
        else:
            elevated_blocked.append(t)
            meta_rows.append({k: v for k, v in meta.items() if k != "last_loss"})
            append_jsonl(FILES["blocked_reentry_watch"], _v066_watch_row(ev, meta, "elevated_block", reasons))

    if isinstance(stats, dict):
        stats["repeat_loss_hard_block"] = int(stats.get("repeat_loss_hard_block", 0)) + len(hard_blocked)
        stats["repeat_loss_elevated_block"] = int(stats.get("repeat_loss_elevated_block", 0)) + len(elevated_blocked)
        stats["repeat_loss_override_allow"] = int(stats.get("repeat_loss_override_allow", 0)) + len(override_allowed)
        stats["repeat_loss_block_tickers"] = list(dict.fromkeys(hard_blocked + elevated_blocked))[:12]
        stats["repeat_loss_override_tickers"] = list(dict.fromkeys(override_allowed))[:12]
        stats["repeat_loss_gate_meta"] = meta_rows[:8]
    return kept, stats


_v066_base_summary_text = summary_text


def summary_text() -> str:  # type: ignore[override]
    control = load_control()
    status = load_json(FILES["status"], {})
    open_pos = load_open()
    focus_open = _v064_focus_open_positions(open_pos)
    focus_closed = _v064_focus_closed_rows()
    fs = file_stats()
    pick = status.get("pick_stats") if isinstance(status.get("pick_stats"), dict) else {}
    st = _v064_stats(focus_closed)
    hard = int(float_any(pick.get("repeat_loss_hard_block"), default=0))
    elevated = int(float_any(pick.get("repeat_loss_elevated_block"), default=0))
    override = int(float_any(pick.get("repeat_loss_override_allow"), default=0))
    blocked_ticks = pick.get("repeat_loss_block_tickers") if isinstance(pick.get("repeat_loss_block_tickers"), list) else []
    override_ticks = pick.get("repeat_loss_override_tickers") if isinstance(pick.get("repeat_loss_override_tickers"), list) else []
    repeat_line = f" / 반복손실 문턱 {elevated} / 강한차단 {hard} / 예외허용 {override}"
    if blocked_ticks:
        repeat_line += f" (차단 {', '.join(map(str, blocked_ticks[:5]))})"
    if override_ticks:
        repeat_line += f" (허용 {', '.join(map(str, override_ticks[:5]))})"
    return "\n".join([
        f"🧪 페이퍼봇 {VERSION}",
        f"- 실행상태: {'ON' if control.get('running') else 'OFF'} / loop {control.get('loop_seconds')}s",
        f"- 현재전략: {PAPER_FOCUS_STRATEGY_LABEL}",
        f"- 신규 OPEN: {'중지' if control.get('new_open_paused') else '허용'} / 단, {PAPER_FOCUS_STRATEGY_KEY} trade_ready만",
        "- 반복손실 보호: 1회 손실=재진입 문턱상승, 강한 재진입 근거만 예외허용 / 6시간 2손실=강한차단",
        f"- OPEN: 현재전략 {len(focus_open)} / 전체 {len(open_pos)} / 한도 {control.get('max_open_strict')}",
        f"- CLOSED: 현재전략 {st['n']}/30 / 승률 {st['win_rate']:.1f}% / 합산 {st['total']:+.2f}% / 평균 {st['avg']:+.2f}%",
        f"- 청산고정: 익절 +{float_any(control.get('take_profit_pct'), default=1.2):.2f}% / 보호 +{float_any(control.get('protect_trigger_pct'), default=0.7):.2f}%→+{float_any(control.get('protect_floor_pct'), default=0.3):.2f}% / 손절 {float_any(control.get('stop_loss_pct'), default=-0.55):.2f}% / 시간 {float_any(control.get('time_exit_minutes'), default=15):.0f}분",
        "",
        "[후보]",
        f"- 읽음 {pick.get('paper_file',0)} / 신규중지 {pick.get('new_open_paused',0)} / not_ready {pick.get('not_trade_ready_skip',0)} / micro대기 {pick.get('micro_preopen_wait',0)} / 중복 {pick.get('same_ticker_skip',0)}" + repeat_line,
        "",
        "[원칙]",
        "- CLOSED 30건 전 조건 변경 금지 / 반복손실 보호는 설계서의 기존 보호 연결",
        f"- 오류로그 {fs.get('error', {}).get('size', 0)} bytes / 자세히 /perror",
    ])



# =============================================================================
# v0.68: leader_momentum_continuation paper runner
# - sweep_vwap_recovery는 신규 OPEN 대상에서 제외
# - 새 전략은 +2.0 / -0.60 / 45분 / 보호 +1.0 → +0.45로 검증
# - 반복손실 문턱상승(v0.66)은 유지한다.
# =============================================================================
VERSION = "paper_bot_v0.68"
PAPER_FOCUS_STRATEGY_KEY = "leader_momentum_continuation"
PAPER_FOCUS_STRATEGY_LABEL = "장세 선택형 주도코인 추세 지속 전략"
PAPER_FOCUS_TAG = "주도추세"
PAPER_FOCUS_MAIN_MODE = "leader_momentum_continuation_only"

DEFAULT_CONTROL.update({
    "new_open_paused": False,
    "open_trade_ready_only": True,
    "open_shadow_positions": False,
    "shadow_review_only": True,
    "take_profit_pct": 2.00,
    "protect_trigger_pct": 1.00,
    "protect_floor_pct": 0.45,
    "stop_loss_pct": -0.60,
    "time_exit_minutes": 45,
    "quick_stop_enabled": False,
    "slow_early_enabled": False,
    "long_loss_guard_enabled": False,
    "notify_on_strict_open": True,
    "notify_on_strict_close": True,
    "notify_open_auto_ready_only": True,
    "notify_open_min_score": 4.45,
    "notify_open_require_final_pass": True,
    "notify_open_require_micro_fresh": True,
    "preopen_micro_recheck": True,
    "notify_close_only_alerted": False,
})

_v068_base_load_control = load_control

def load_control() -> Dict[str, Any]:  # type: ignore[override]
    control = _v068_base_load_control()
    fixed = {
        "new_open_paused": False,
        "open_trade_ready_only": True,
        "open_shadow_positions": False,
        "shadow_review_only": True,
        "take_profit_pct": 2.00,
        "protect_trigger_pct": 1.00,
        "protect_floor_pct": 0.45,
        "stop_loss_pct": -0.60,
        "time_exit_minutes": 45,
        "quick_stop_enabled": False,
        "slow_early_enabled": False,
        "long_loss_guard_enabled": False,
        "notify_close_only_alerted": False,
        "active_strategy_key": PAPER_FOCUS_STRATEGY_KEY,
        "active_strategy_label": PAPER_FOCUS_STRATEGY_LABEL,
    }
    changed = False
    for k, v in fixed.items():
        if control.get(k) != v:
            control[k] = v
            changed = True
    if changed:
        try:
            save_json(FILES["control"], control)
            set_pause_flags(bool(control.get("running")))
        except Exception:
            pass
    return control

# v0.66의 반복손실 보호는 _v052_is_focus_strategy가 전역 PAPER_FOCUS_*를 보므로 새 전략에 자동 적용된다.
_v068_base_summary_text = summary_text

def summary_text() -> str:  # type: ignore[override]
    control = load_control()
    status = load_json(FILES["status"], {})
    open_pos = load_open()
    focus_open = _v064_focus_open_positions(open_pos)
    focus_closed = _v064_focus_closed_rows()
    fs = file_stats()
    pick = status.get("pick_stats") if isinstance(status.get("pick_stats"), dict) else {}
    st = _v064_stats(focus_closed)
    hard = int(float_any(pick.get("repeat_loss_hard_block"), default=0))
    elevated = int(float_any(pick.get("repeat_loss_elevated_block"), default=0))
    override = int(float_any(pick.get("repeat_loss_override_allow"), default=0))
    return "\n".join([
        f"🧪 페이퍼봇 {VERSION}",
        f"- 실행상태: {'ON' if control.get('running') else 'OFF'} / loop {control.get('loop_seconds')}s",
        f"- 현재전략: {PAPER_FOCUS_STRATEGY_LABEL}",
        f"- 신규 OPEN: {'중지' if control.get('new_open_paused') else '허용'} / 단, {PAPER_FOCUS_STRATEGY_KEY} trade_ready만",
        "- 반복손실 보호: 1회 손실=재진입 문턱상승, 강한 재진입 근거만 예외허용 / 6시간 2손실=강한차단",
        f"- OPEN: 현재전략 {len(focus_open)} / 전체 {len(open_pos)} / 한도 {control.get('max_open_strict')}",
        f"- CLOSED: 현재전략 {st['n']}/30 / 승률 {st['win_rate']:.1f}% / 합산 {st['total']:+.2f}% / 평균 {st['avg']:+.2f}%",
        f"- 청산고정: 익절 +{float_any(control.get('take_profit_pct'), default=2.0):.2f}% / 보호 +{float_any(control.get('protect_trigger_pct'), default=1.0):.2f}%→+{float_any(control.get('protect_floor_pct'), default=0.45):.2f}% / 손절 {float_any(control.get('stop_loss_pct'), default=-0.60):.2f}% / 시간 {float_any(control.get('time_exit_minutes'), default=45):.0f}분",
        "",
        "[후보]",
        f"- 읽음 {pick.get('paper_file',0)} / 신규중지 {pick.get('new_open_paused',0)} / not_ready {pick.get('not_trade_ready_skip',0)} / micro대기 {pick.get('micro_preopen_wait',0)} / 중복 {pick.get('same_ticker_skip',0)} / 반복손실 문턱 {elevated} / 강한차단 {hard} / 예외허용 {override}",
        "",
        "[원칙]",
        "- CLOSED 30건 전 조건 변경 금지 / 자동매수 OFF / paper 검증 전용",
        f"- 오류로그 {fs.get('error', {}).get('size', 0)} bytes / 자세히 /perror",
    ])


# =============================================================================
# v0.69: leader_momentum S/A/B/C grade runner
# - S급: 미래 자동매매 후보급이지만 자동매수 OFF, paper OPEN 허용
# - A급: 모의매매 검증 후보, paper OPEN 허용
# - B급: 관찰/복기 후보, 기본 OPEN 안 함
# - C급: 진입 금지
# - 5~10분 초단타가 아니라 1시간 관찰형 청산 구조로 검증
# =============================================================================
VERSION = "paper_bot_v0.69"
PAPER_FOCUS_STRATEGY_KEY = "leader_momentum_continuation"
PAPER_FOCUS_STRATEGY_LABEL = "장세 선택형 주도코인 추세 지속 전략"
PAPER_FOCUS_TAG = "주도추세등급"
PAPER_FOCUS_MAIN_MODE = "leader_momentum_grade_only"

DEFAULT_CONTROL.update({
    "new_open_paused": False,
    "open_trade_ready_only": True,
    "open_shadow_positions": False,
    "shadow_review_only": True,
    "take_profit_pct": 1.20,
    "extended_target_pct": 2.00,
    "protect_trigger_pct": 0.70,
    "protect_floor_pct": 0.35,
    "stop_loss_pct": -0.60,
    "time_exit_minutes": 60,
    "slow_minutes": 60,
    "quick_stop_enabled": False,
    "slow_early_enabled": False,
    "long_loss_guard_enabled": False,
    "notify_on_strict_open": True,
    "notify_on_strict_close": True,
    "notify_open_auto_ready_only": False,
    "notify_open_min_score": 0.0,
    "notify_open_require_final_pass": True,
    "notify_open_require_micro_fresh": True,
    "preopen_micro_recheck": True,
    "notify_close_only_alerted": False,
    "paper_open_grades": ["S", "A"],
})

_v069_base_load_control = load_control

def load_control() -> Dict[str, Any]:  # type: ignore[override]
    control = _v069_base_load_control()
    fixed = {
        "new_open_paused": False,
        "open_trade_ready_only": True,
        "open_shadow_positions": False,
        "shadow_review_only": True,
        "take_profit_pct": 1.20,
        "extended_target_pct": 2.00,
        "protect_trigger_pct": 0.70,
        "protect_floor_pct": 0.35,
        "stop_loss_pct": -0.60,
        "time_exit_minutes": 60,
        "slow_minutes": 60,
        "quick_stop_enabled": False,
        "slow_early_enabled": False,
        "long_loss_guard_enabled": False,
        "notify_close_only_alerted": False,
        "notify_open_auto_ready_only": False,
        "active_strategy_key": PAPER_FOCUS_STRATEGY_KEY,
        "active_strategy_label": PAPER_FOCUS_STRATEGY_LABEL,
        "paper_open_grades": ["S", "A"],
    }
    changed = False
    for k, v in fixed.items():
        if control.get(k) != v:
            control[k] = v
            changed = True
    if changed:
        try:
            save_json(FILES["control"], control)
            set_pause_flags(bool(control.get("running")))
        except Exception:
            pass
    return control


def _v069_grade_from_event(ev: Dict[str, Any]) -> str:
    ctx = ev.get("entry_context") if isinstance(ev.get("entry_context"), dict) else {}
    g = str(ev.get("candidate_grade") or ctx.get("candidate_grade") or "").upper().strip()
    if g in {"S", "A", "B", "C"}:
        return g
    label = str(ev.get("candidate_grade_label") or ctx.get("candidate_grade_label") or ev.get("final_entry_label") or "")
    if "S급" in label:
        return "S"
    if "A급" in label:
        return "A"
    if "B급" in label:
        return "B"
    return "C"

_v069_base_pick_candidates = pick_candidates

def pick_candidates(control: Dict[str, Any], open_pos: Dict[str, Dict[str, Any]]) -> Tuple[List[Tuple[str, Dict[str, Any]]], Dict[str, int]]:  # type: ignore[override]
    picked, stats = _v069_base_pick_candidates(control, open_pos)
    allow = set(control.get("paper_open_grades") or ["S", "A"])
    out: List[Tuple[str, Dict[str, Any]]] = []
    stats = dict(stats or {})
    stats.setdefault("grade_s_seen", 0)
    stats.setdefault("grade_a_seen", 0)
    stats.setdefault("grade_b_observe_skip", 0)
    stats.setdefault("grade_c_skip", 0)
    stats.setdefault("grade_missing_skip", 0)
    for pid, ev in picked:
        g = _v069_grade_from_event(ev)
        if g == "S": stats["grade_s_seen"] += 1
        elif g == "A": stats["grade_a_seen"] += 1
        elif g == "B": stats["grade_b_observe_skip"] += 1
        elif g == "C": stats["grade_c_skip"] += 1
        else: stats["grade_missing_skip"] += 1
        if g in allow:
            ev = dict(ev)
            ev["candidate_grade"] = g
            ev["paper_grade_open"] = True
            out.append((pid, ev))
        else:
            continue
    stats["grade_filtered_out"] = max(0, len(picked) - len(out))
    return out, stats

_v069_base_open_position = open_position

def open_position(pos_id: str, ev: Dict[str, Any], control: Dict[str, Any]) -> Dict[str, Any]:  # type: ignore[override]
    pos = _v069_base_open_position(pos_id, ev, control)
    ctx = pos.get("entry_context") if isinstance(pos.get("entry_context"), dict) else {}
    g = _v069_grade_from_event(ev)
    pos["candidate_grade"] = g
    pos["candidate_grade_label"] = ev.get("candidate_grade_label") or ctx.get("candidate_grade_label") or ("✅ S급 자동매매 후보급" if g == "S" else "🟡 A급 모의매매 후보" if g == "A" else "❔ B급 관찰" if g == "B" else "❌ C급 금지")
    pos["auto_ready"] = bool(ev.get("auto_ready") or ctx.get("auto_ready") or g == "S")
    pos["take_profit_pct"] = float_any(ev.get("take_profit_pct"), ctx.get("take_profit_pct"), control.get("take_profit_pct"), default=1.20)
    pos["extended_target_pct"] = float_any(ev.get("extended_target_pct"), ctx.get("extended_target_pct"), control.get("extended_target_pct"), default=2.00)
    pos["protect_trigger_pct"] = float_any(ev.get("protect_trigger_pct"), ctx.get("protect_trigger_pct"), control.get("protect_trigger_pct"), default=0.70)
    pos["protect_floor_pct"] = float_any(ev.get("protect_floor_pct"), ctx.get("protect_floor_pct"), control.get("protect_floor_pct"), default=0.35)
    pos["stop_loss_pct"] = float_any(ev.get("stop_loss_pct"), ctx.get("stop_loss_pct"), control.get("stop_loss_pct"), default=-0.60)
    pos["time_exit_min"] = float_any(ev.get("time_exit_min"), ctx.get("time_exit_min"), control.get("time_exit_minutes"), default=60)
    ctx = dict(ctx)
    ctx.update({
        "candidate_grade": pos["candidate_grade"],
        "candidate_grade_label": pos["candidate_grade_label"],
        "auto_ready": pos["auto_ready"],
        "take_profit_pct": pos["take_profit_pct"],
        "extended_target_pct": pos["extended_target_pct"],
        "protect_trigger_pct": pos["protect_trigger_pct"],
        "protect_floor_pct": pos["protect_floor_pct"],
        "stop_loss_pct": pos["stop_loss_pct"],
        "time_exit_min": pos["time_exit_min"],
    })
    pos["entry_context"] = ctx
    return pos

_v069_base_update_position = update_position

def update_position(pos: Dict[str, Any], control: Dict[str, Any]) -> Tuple[Dict[str, Any], Optional[Dict[str, Any]]]:  # type: ignore[override]
    local = dict(control or {})
    local["take_profit_pct"] = float_any(pos.get("take_profit_pct"), default=float_any(control.get("take_profit_pct"), default=1.20))
    local["protect_trigger_pct"] = float_any(pos.get("protect_trigger_pct"), default=float_any(control.get("protect_trigger_pct"), default=0.70))
    local["protect_floor_pct"] = float_any(pos.get("protect_floor_pct"), default=float_any(control.get("protect_floor_pct"), default=0.35))
    local["stop_loss_pct"] = float_any(pos.get("stop_loss_pct"), default=float_any(control.get("stop_loss_pct"), default=-0.60))
    local["time_exit_minutes"] = float_any(pos.get("time_exit_min"), default=float_any(control.get("time_exit_minutes"), default=60))
    updated, closed = _v069_base_update_position(pos, local)
    if closed:
        closed["candidate_grade"] = updated.get("candidate_grade") or pos.get("candidate_grade")
        closed["candidate_grade_label"] = updated.get("candidate_grade_label") or pos.get("candidate_grade_label")
        closed["auto_ready"] = bool(updated.get("auto_ready") or pos.get("auto_ready"))
        closed["take_profit_pct"] = local.get("take_profit_pct")
        closed["extended_target_pct"] = float_any(updated.get("extended_target_pct"), pos.get("extended_target_pct"), local.get("extended_target_pct"), default=2.0)
    return updated, closed

_v069_base_summary_text = summary_text

def summary_text() -> str:  # type: ignore[override]
    control = load_control()
    status = load_json(FILES["status"], {})
    open_pos = load_open()
    focus_open = _v064_focus_open_positions(open_pos)
    focus_closed = _v064_focus_closed_rows()
    fs = file_stats()
    pick = status.get("pick_stats") if isinstance(status.get("pick_stats"), dict) else {}
    st = _v064_stats(focus_closed)
    grade_open = {"S": 0, "A": 0, "B": 0, "C": 0}
    for p in focus_open.values():
        g = str((p or {}).get("candidate_grade") or "C")
        if g in grade_open:
            grade_open[g] += 1
    hard = int(float_any(pick.get("repeat_loss_hard_block"), default=0))
    elevated = int(float_any(pick.get("repeat_loss_elevated_block"), default=0))
    override = int(float_any(pick.get("repeat_loss_override_allow"), default=0))
    return "\n".join([
        f"🧪 페이퍼봇 {VERSION}",
        f"- 실행상태: {'ON' if control.get('running') else 'OFF'} / loop {control.get('loop_seconds')}s",
        f"- 현재전략: {PAPER_FOCUS_STRATEGY_LABEL}",
        "- 등급: S=미래 자동매매 후보급 / A=모의검증 / B=관찰 / C=금지",
        f"- 신규 OPEN: {'중지' if control.get('new_open_paused') else '허용'} / S·A급 trade_ready만",
        "- 자동매수: OFF / S급도 실제 주문 아님",
        f"- OPEN: S {grade_open['S']} / A {grade_open['A']} / 전체전략 {len(focus_open)} / 전체 {len(open_pos)} / 한도 {control.get('max_open_strict')}",
        f"- CLOSED: 현재전략 {st['n']}/30 / 승률 {st['win_rate']:.1f}% / 합산 {st['total']:+.2f}% / 평균 {st['avg']:+.2f}%",
        f"- 청산고정: 기본익절 +{float_any(control.get('take_profit_pct'), default=1.2):.2f}% / 강한흐름 관찰 +{float_any(control.get('extended_target_pct'), default=2.0):.2f}% / 보호 +{float_any(control.get('protect_trigger_pct'), default=0.7):.2f}%→+{float_any(control.get('protect_floor_pct'), default=0.35):.2f}% / 손절 {float_any(control.get('stop_loss_pct'), default=-0.60):.2f}% / 시간 {float_any(control.get('time_exit_minutes'), default=60):.0f}분",
        "",
        "[후보]",
        f"- 읽음 {pick.get('paper_file',0)} / S {pick.get('grade_s_seen',0)} / A {pick.get('grade_a_seen',0)} / B관찰스킵 {pick.get('grade_b_observe_skip',0)} / C스킵 {pick.get('grade_c_skip',0)} / 등급필터 {pick.get('grade_filtered_out',0)} / micro대기 {pick.get('micro_preopen_wait',0)} / 중복 {pick.get('same_ticker_skip',0)} / 반복손실 문턱 {elevated} / 강한차단 {hard} / 예외허용 {override}",
        "",
        "[원칙]",
        "- CLOSED 30건 전 조건 변경 금지 / 실제 자동매매는 S급만 후보 / 지금은 paper 검증 전용",
        f"- 오류로그 {fs.get('error', {}).get('size', 0)} bytes / 자세히 /perror",
    ])



# =============================================================================
# v0.70: updated S/A/B/C semantics + B paper validation
# - S = 자동매매 상위 후보, A = 자동매매 일반 후보
# - B = 모의매매 검증 후보, C = 관찰 후보, X/제외 = 차단
# - 현재 자동매수는 OFF. paper OPEN은 S/A/B만 허용한다.
# =============================================================================
VERSION = "paper_bot_v0.70"
PAPER_FOCUS_STRATEGY_KEY = "leader_momentum_continuation"
PAPER_FOCUS_STRATEGY_LABEL = "장세 선택형 주도코인 추세 지속 전략"
PAPER_FOCUS_TAG = "주도추세등급"
PAPER_FOCUS_MAIN_MODE = "leader_momentum_grade_mode"

DEFAULT_CONTROL.update({
    "new_open_paused": False,
    "open_trade_ready_only": True,
    "open_shadow_positions": False,
    "shadow_review_only": True,
    "take_profit_pct": 1.20,
    "extended_target_pct": 2.00,
    "protect_trigger_pct": 0.70,
    "protect_floor_pct": 0.35,
    "stop_loss_pct": -0.60,
    "time_exit_minutes": 60,
    "slow_minutes": 60,
    "notify_open_auto_ready_only": False,
    "notify_open_require_final_pass": True,
    "notify_open_require_micro_fresh": True,
    "preopen_micro_recheck": True,
    "paper_open_grades": ["S", "A", "B"],
})

_v070_base_load_control = load_control

def load_control() -> Dict[str, Any]:  # type: ignore[override]
    control = _v070_base_load_control()
    fixed = {
        "new_open_paused": False,
        "open_trade_ready_only": True,
        "open_shadow_positions": False,
        "shadow_review_only": True,
        "notify_close_only_alerted": False,
        "notify_open_auto_ready_only": False,
        "active_strategy_key": PAPER_FOCUS_STRATEGY_KEY,
        "active_strategy_label": PAPER_FOCUS_STRATEGY_LABEL,
        "paper_open_grades": ["S", "A", "B"],
    }
    changed = False
    for k, v in fixed.items():
        if control.get(k) != v:
            control[k] = v
            changed = True
    if changed:
        try:
            save_json(FILES["control"], control)
            set_pause_flags(bool(control.get("running")))
        except Exception:
            pass
    return control


def _v070_grade_from_event(ev: Dict[str, Any]) -> str:
    ctx = ev.get("entry_context") if isinstance(ev.get("entry_context"), dict) else {}
    g = str(ev.get("candidate_grade") or ctx.get("candidate_grade") or "").upper().strip()
    if g in {"S", "A", "B", "C", "X"}:
        return g
    label = str(ev.get("candidate_grade_label") or ctx.get("candidate_grade_label") or ev.get("final_entry_label") or "")
    if "S급" in label:
        return "S"
    if "A급" in label:
        return "A"
    if "B급" in label:
        return "B"
    if "C급" in label:
        return "C"
    return "X" if "제외" in label or "차단" in label or "금지" in label else "C"

_v070_base_pick_candidates = pick_candidates

def pick_candidates(control: Dict[str, Any], open_pos: Dict[str, Dict[str, Any]]) -> Tuple[List[Tuple[str, Dict[str, Any]]], Dict[str, int]]:  # type: ignore[override]
    picked, stats = _v070_base_pick_candidates(control, open_pos)
    allow = set(control.get("paper_open_grades") or ["S", "A", "B"])
    out: List[Tuple[str, Dict[str, Any]]] = []
    stats = dict(stats or {})
    for k in ("grade_s_seen", "grade_a_seen", "grade_b_seen", "grade_c_observe_skip", "grade_x_block_skip", "grade_missing_skip"):
        stats.setdefault(k, 0)
    for pid, ev in picked:
        g = _v070_grade_from_event(ev)
        if g == "S": stats["grade_s_seen"] += 1
        elif g == "A": stats["grade_a_seen"] += 1
        elif g == "B": stats["grade_b_seen"] += 1
        elif g == "C": stats["grade_c_observe_skip"] += 1
        elif g == "X": stats["grade_x_block_skip"] += 1
        else: stats["grade_missing_skip"] += 1
        if g in allow:
            ev = dict(ev)
            ev["candidate_grade"] = g
            ev["paper_grade_open"] = True
            out.append((pid, ev))
    stats["grade_filtered_out"] = max(0, len(picked) - len(out))
    return out, stats

_v070_base_open_position = open_position

def open_position(pos_id: str, ev: Dict[str, Any], control: Dict[str, Any]) -> Dict[str, Any]:  # type: ignore[override]
    pos = _v070_base_open_position(pos_id, ev, control)
    ctx = pos.get("entry_context") if isinstance(pos.get("entry_context"), dict) else {}
    g = _v070_grade_from_event(ev)
    label_map = {
        "S": "✅ S급 자동매매 상위 후보",
        "A": "✅ A급 자동매매 일반 후보",
        "B": "🟡 B급 모의매매 검증 후보",
        "C": "❔ C급 관찰 후보",
        "X": "❌ 제외/차단",
    }
    pos["candidate_grade"] = g
    pos["candidate_grade_label"] = ev.get("candidate_grade_label") or ctx.get("candidate_grade_label") or label_map.get(g, "❔ 관찰")
    pos["leader_market_mode"] = ev.get("leader_market_mode") or ctx.get("leader_market_mode")
    pos["auto_ready"] = bool(ev.get("auto_ready") or ctx.get("auto_ready") or g in {"S", "A"})
    pos["take_profit_pct"] = float_any(ev.get("take_profit_pct"), ctx.get("take_profit_pct"), control.get("take_profit_pct"), default=1.20)
    pos["extended_target_pct"] = float_any(ev.get("extended_target_pct"), ctx.get("extended_target_pct"), control.get("extended_target_pct"), default=2.00)
    pos["protect_trigger_pct"] = float_any(ev.get("protect_trigger_pct"), ctx.get("protect_trigger_pct"), control.get("protect_trigger_pct"), default=0.70)
    pos["protect_floor_pct"] = float_any(ev.get("protect_floor_pct"), ctx.get("protect_floor_pct"), control.get("protect_floor_pct"), default=0.35)
    pos["stop_loss_pct"] = float_any(ev.get("stop_loss_pct"), ctx.get("stop_loss_pct"), control.get("stop_loss_pct"), default=-0.60)
    pos["time_exit_min"] = float_any(ev.get("time_exit_min"), ctx.get("time_exit_min"), control.get("time_exit_minutes"), default=60)
    ctx = dict(ctx)
    ctx.update({
        "candidate_grade": pos["candidate_grade"],
        "candidate_grade_label": pos["candidate_grade_label"],
        "leader_market_mode": pos.get("leader_market_mode"),
        "auto_ready": pos["auto_ready"],
        "take_profit_pct": pos["take_profit_pct"],
        "extended_target_pct": pos["extended_target_pct"],
        "protect_trigger_pct": pos["protect_trigger_pct"],
        "protect_floor_pct": pos["protect_floor_pct"],
        "stop_loss_pct": pos["stop_loss_pct"],
        "time_exit_min": pos["time_exit_min"],
    })
    pos["entry_context"] = ctx
    return pos

_v070_base_update_position = update_position

def update_position(pos: Dict[str, Any], control: Dict[str, Any]) -> Tuple[Dict[str, Any], Optional[Dict[str, Any]]]:  # type: ignore[override]
    local = dict(control or {})
    local["take_profit_pct"] = float_any(pos.get("take_profit_pct"), default=float_any(control.get("take_profit_pct"), default=1.20))
    local["protect_trigger_pct"] = float_any(pos.get("protect_trigger_pct"), default=float_any(control.get("protect_trigger_pct"), default=0.70))
    local["protect_floor_pct"] = float_any(pos.get("protect_floor_pct"), default=float_any(control.get("protect_floor_pct"), default=0.35))
    local["stop_loss_pct"] = float_any(pos.get("stop_loss_pct"), default=float_any(control.get("stop_loss_pct"), default=-0.60))
    local["time_exit_minutes"] = float_any(pos.get("time_exit_min"), default=float_any(control.get("time_exit_minutes"), default=60))
    updated, closed = _v070_base_update_position(pos, local)
    if closed:
        closed["candidate_grade"] = updated.get("candidate_grade") or pos.get("candidate_grade")
        closed["candidate_grade_label"] = updated.get("candidate_grade_label") or pos.get("candidate_grade_label")
        closed["leader_market_mode"] = updated.get("leader_market_mode") or pos.get("leader_market_mode")
        closed["auto_ready"] = bool(updated.get("auto_ready") or pos.get("auto_ready"))
        closed["take_profit_pct"] = local.get("take_profit_pct")
        closed["extended_target_pct"] = float_any(updated.get("extended_target_pct"), pos.get("extended_target_pct"), local.get("extended_target_pct"), default=2.0)
    return updated, closed

_v070_base_summary_text = summary_text

def summary_text() -> str:  # type: ignore[override]
    control = load_control()
    status = load_json(FILES["status"], {})
    open_pos = load_open()
    focus_open = _v064_focus_open_positions(open_pos)
    focus_closed = _v064_focus_closed_rows()
    fs = file_stats()
    pick = status.get("pick_stats") if isinstance(status.get("pick_stats"), dict) else {}
    st = _v064_stats(focus_closed)
    grade_open = {"S": 0, "A": 0, "B": 0, "C": 0, "X": 0}
    for p in focus_open.values():
        g = str((p or {}).get("candidate_grade") or "X")
        if g in grade_open:
            grade_open[g] += 1
    hard = int(float_any(pick.get("repeat_loss_hard_block"), default=0))
    elevated = int(float_any(pick.get("repeat_loss_elevated_block"), default=0))
    override = int(float_any(pick.get("repeat_loss_override_allow"), default=0))
    return "\n".join([
        f"🧪 페이퍼봇 {VERSION}",
        f"- 실행상태: {'ON' if control.get('running') else 'OFF'} / loop {control.get('loop_seconds')}s",
        f"- 현재전략: {PAPER_FOCUS_STRATEGY_LABEL}",
        "- 등급: S=자동매매 상위 / A=자동매매 일반 / B=모의매매 / C=관찰 / 제외=차단",
        f"- 신규 OPEN: {'중지' if control.get('new_open_paused') else '허용'} / paper OPEN S·A·B / 실제 자동매매 후보 S·A만",
        "- 자동매수: OFF / 실제 주문 아님",
        f"- OPEN: S {grade_open['S']} / A {grade_open['A']} / B {grade_open['B']} / 전체전략 {len(focus_open)} / 전체 {len(open_pos)} / 한도 {control.get('max_open_strict')}",
        f"- CLOSED: 현재전략 {st['n']}/30 / 승률 {st['win_rate']:.1f}% / 합산 {st['total']:+.2f}% / 평균 {st['avg']:+.2f}%",
        f"- 기본 청산: 후보별 등급/장세값 우선 / fallback 익절 +{float_any(control.get('take_profit_pct'), default=1.2):.2f}% / 보호 +{float_any(control.get('protect_trigger_pct'), default=0.7):.2f}%→+{float_any(control.get('protect_floor_pct'), default=0.35):.2f}% / 손절 {float_any(control.get('stop_loss_pct'), default=-0.60):.2f}% / 시간 {float_any(control.get('time_exit_minutes'), default=60):.0f}분",
        "",
        "[후보]",
        f"- 읽음 {pick.get('paper_file',0)} / S {pick.get('grade_s_seen',0)} / A {pick.get('grade_a_seen',0)} / B {pick.get('grade_b_seen',0)} / C관찰스킵 {pick.get('grade_c_observe_skip',0)} / 제외스킵 {pick.get('grade_x_block_skip',0)} / 등급필터 {pick.get('grade_filtered_out',0)} / micro대기 {pick.get('micro_preopen_wait',0)} / 중복 {pick.get('same_ticker_skip',0)} / 반복손실 문턱 {elevated} / 강한차단 {hard} / 예외허용 {override}",
        "",
        "[원칙]",
        "- CLOSED 30건 전 조건 변경 금지 / 실제 자동매매는 S·A만 후보 / B는 paper 검증 / C는 관찰",
        f"- 오류로그 {fs.get('error', {}).get('size', 0)} bytes / 자세히 /perror",
    ])



# =============================================================================
# v0.71: grade-level performance view
# - paper OPEN/청산 로직은 v0.70 그대로 유지한다.
# - /pscore와 /pstatus에 S/A/B/C/제외 등급별 CLOSED 성과를 추가한다.
# =============================================================================
VERSION = "paper_bot_v0.72"


def _v071_grade_from_row(row: Dict[str, Any]) -> str:
    ctx = row.get("entry_context") if isinstance(row.get("entry_context"), dict) else {}
    g = str(row.get("candidate_grade") or ctx.get("candidate_grade") or "").upper().strip()
    if g in {"S", "A", "B", "C", "X"}:
        return g
    label = str(row.get("candidate_grade_label") or ctx.get("candidate_grade_label") or row.get("final_entry_label") or "")
    if "S급" in label:
        return "S"
    if "A급" in label:
        return "A"
    if "B급" in label:
        return "B"
    if "C급" in label:
        return "C"
    if "제외" in label or "차단" in label or "금지" in label:
        return "X"
    return "U"


def _v071_focus_closed() -> List[Dict[str, Any]]:
    try:
        return _v064_focus_closed_rows()
    except Exception:
        rows = read_jsonl(FILES["closed"], max_lines=30000)
        out = []
        for r in rows:
            ctx = r.get("entry_context") if isinstance(r.get("entry_context"), dict) else {}
            if str(r.get("paper_strategy_key") or r.get("strategy_key") or ctx.get("paper_strategy_key") or ctx.get("strategy_key") or "") == PAPER_FOCUS_STRATEGY_KEY:
                out.append(r)
        return out


def _v071_stats_line(label: str, rows: Iterable[Dict[str, Any]]) -> str:
    st = score_stats(list(rows or []))
    n = int(st.get("n", 0) or 0)
    if n <= 0:
        return f"- {label}: 0전 / 아직 없음"
    vals = [float_any(r.get("net_pnl_pct"), r.get("pnl_pct"), r.get("profit_pct"), default=0.0) for r in rows or []]
    mx = max(vals) if vals else 0.0
    mn = min(vals) if vals else 0.0
    return f"- {label}: {n}전 {int(st['wins'])}승 {int(st['losses'])}패 / 승률 {st['win_rate']:.1f}% / 합산 {st['total']:+.2f}% / 평균 {st['avg']:+.2f}% / 최대 {mx:+.2f}% / 최소 {mn:+.2f}%"


def _v071_grade_groups(rows: Iterable[Dict[str, Any]]) -> Dict[str, List[Dict[str, Any]]]:
    groups = {"S": [], "A": [], "B": [], "C": [], "X": [], "U": []}
    for r in rows or []:
        groups.setdefault(_v071_grade_from_row(r), []).append(r)
    return groups


def _v071_grade_score_lines(rows: Optional[List[Dict[str, Any]]] = None) -> List[str]:
    rows = list(rows if rows is not None else _v071_focus_closed())
    g = _v071_grade_groups(rows)
    auto = g.get("S", []) + g.get("A", [])
    paper = auto + g.get("B", [])
    return [
        "[등급별 CLOSED 성과]",
        _v071_stats_line("✅ S급 자동매매 상위", g.get("S", [])),
        _v071_stats_line("✅ A급 자동매매 일반", g.get("A", [])),
        _v071_stats_line("🟡 B급 모의매매 검증", g.get("B", [])),
        _v071_stats_line("❔ C급 관찰", g.get("C", [])),
        _v071_stats_line("❌ 제외/차단", g.get("X", [])),
        "",
        "[후보군 합산]",
        _v071_stats_line("S/A 자동매매 후보군", auto),
        _v071_stats_line("S/A/B paper 검증 후보군", paper),
        _v071_stats_line("현재전략 전체", rows),
    ]

_v071_base_summary_text = summary_text

def summary_text() -> str:  # type: ignore[override]
    base = _v071_base_summary_text()
    try:
        rows = _v071_focus_closed()
        return base + "\n\n" + "\n".join(_v071_grade_score_lines(rows))
    except Exception as exc:
        log_error("v071_summary_grade_stats", exc)
        return base


def _v071_pscore_text() -> str:
    rows = _v071_focus_closed()
    by_reason = Counter(str(r.get("exit_reason") or "unknown") for r in rows)
    lines = [
        "📊 페이퍼봇 등급 성과 /pscore",
        f"- 현재전략: {PAPER_FOCUS_STRATEGY_LABEL}",
        "- v0.71: S/A/B/C/제외 등급별 CLOSED 성과 표시",
        "- S/A=미래 자동매매 후보군, B=paper 검증, C=관찰",
        "",
        *_v071_grade_score_lines(rows),
        "",
        "[종료 사유 TOP]",
    ]
    if by_reason:
        for k, _ in by_reason.most_common(6):
            sub = [r for r in rows if str(r.get("exit_reason") or "unknown") == k]
            lines.append(_v071_stats_line(label_kr(k), sub))
    else:
        lines.append("- 아직 현재전략 CLOSED 없음")
    lines += [
        "",
        "판독",
        "- S/A가 플러스여야 실제 자동매매 후보로 볼 수 있음",
        "- B는 모의검증 성과만 보고 S/A 승격 여부를 나중에 판단",
        "- C는 관찰용이라 OPEN이 없으면 성과가 없어도 정상",
    ]
    return "\n".join(lines)

_v071_base_command_response = command_response

def command_response(text: str) -> str:  # type: ignore[override]
    cmd = (text or "").strip().split()[0].lower() if (text or "").strip().split() else ""
    if "@" in cmd:
        cmd = cmd.split("@", 1)[0]
    if cmd == "/pscore":
        return _v071_pscore_text()
    return _v071_base_command_response(text)


# =============================================================================
# v0.72: count-unfixed paper validation + atomic save fix
# - paper OPEN 고정 8개 한도를 전략 조건처럼 쓰지 않는다. max_open_strict=0은 고정한도 없음.
# - S/A/B 후보를 paper로 검증하되, 실제 자동매매 후보는 여전히 S/A만 본다.
# - paper_bot_control.json 저장은 고유 tmp로 처리해 FileNotFoundError 원인을 제거한다.
# - 장부 OPEN/CLOSED/trade_log는 삭제하거나 초기화하지 않는다.
# =============================================================================
VERSION = "paper_bot_v0.72"
DEFAULT_CONTROL.update({
    "max_open_strict": 0,
    "max_new_per_cycle": 0,
    "paper_open_grades": ["S", "A", "B"],
})

_v072_base_load_control = load_control

def load_control() -> Dict[str, Any]:  # type: ignore[override]
    control = _v072_base_load_control()
    changed = False
    fixed = {
        "max_open_strict": 0,
        "max_new_per_cycle": 0,
        "paper_open_grades": ["S", "A", "B"],
        "open_trade_ready_only": True,
        "open_shadow_positions": False,
        "shadow_review_only": True,
        "new_open_paused": False,
    }
    for k, v in fixed.items():
        if control.get(k) != v:
            control[k] = v
            changed = True
    if changed:
        try:
            save_json(FILES["control"], control)
            set_pause_flags(bool(control.get("running")))
        except Exception as exc:
            log_error("v072_load_control_save", exc)
    return control


def _v072_limit_text(control: Optional[Dict[str, Any]] = None) -> str:
    control = control or load_control()
    try:
        v = int(float_any(control.get("max_open_strict"), default=0))
    except Exception:
        v = 0
    return "고정없음" if v <= 0 else str(v)

_v072_base_summary_text = summary_text

def summary_text() -> str:  # type: ignore[override]
    text = _v072_base_summary_text()
    try:
        control = load_control()
        text = text.replace(f"한도 {control.get('max_open_strict')}", f"한도 {_v072_limit_text(control)}")
        text = text.replace("paper_bot_v0.71", VERSION)
        text = text.replace("v0.71: S/A/B/C/제외 등급별 CLOSED 성과 표시", "v0.72: 등급별 성과 표시 + paper OPEN 고정개수 해제 + 저장 tmp 오류수술")
        text = text.replace("- 신규 OPEN: 허용 / paper OPEN S·A·B / 실제 자동매매 후보 S·A만", "- 신규 OPEN: 허용 / paper OPEN S·A·B / 고정개수 없음 / 실제 자동매매 후보 S·A만")
    except Exception as exc:
        log_error("v072_summary_text", exc)
    return text

_v072_base_pscore_text = _v071_pscore_text

def _v071_pscore_text() -> str:  # type: ignore[override]
    text = _v072_base_pscore_text()
    text = text.replace("v0.71: S/A/B/C/제외 등급별 CLOSED 성과 표시", "v0.72: S/A/B/C/제외 성과 표시 + paper OPEN 고정개수 해제")
    text = text.replace("- B는 모의검증 성과만 보고 S/A 승격 여부를 나중에 판단", "- B는 모의검증 성과만 보고 S/A 승격 여부를 나중에 판단. 개수 고정 대신 후보 조건으로 자연스럽게 열린다")
    return text


# =============================================================================
# v0.73: /popen grade-visible display
# - 장부/청산/OPEN 판정은 v0.72 그대로 유지한다.
# - /popen 개별 OPEN 줄에 S/A/B/C/제외 등급, 실제 자동매매 후보 여부, 위험태그를 표시한다.
# - /pstatus 안에 포함되는 OPEN 시간표도 같은 표시를 쓴다.
# =============================================================================
VERSION = "paper_bot_v0.73"


def _v073_grade_badge(row: Dict[str, Any]) -> str:
    g = _v071_grade_from_row(row)
    label_map = {
        "S": "✅ S급",
        "A": "✅ A급",
        "B": "🟡 B급",
        "C": "❔ C급",
        "X": "❌ 제외",
        "U": "❔ 등급미기록",
    }
    return label_map.get(g, "❔ 등급미기록")


def _v073_auto_candidate_text(row: Dict[str, Any]) -> str:
    g = _v071_grade_from_row(row)
    if g == "S":
        return "자동매매 상위후보"
    if g == "A":
        return "자동매매 일반후보"
    if g == "B":
        return "paper 검증"
    if g == "C":
        return "관찰"
    if g == "X":
        return "차단"
    return "등급확인"


def _v073_ctx(row: Dict[str, Any]) -> Dict[str, Any]:
    ctx = row.get("entry_context") if isinstance(row.get("entry_context"), dict) else {}
    raw = row.get("raw") if isinstance(row.get("raw"), dict) else {}
    if not ctx and isinstance(raw.get("entry_context"), dict):
        ctx = raw.get("entry_context") or {}
    return ctx if isinstance(ctx, dict) else {}


def _v073_short_reasons(row: Dict[str, Any], limit: int = 3) -> str:
    ctx = _v073_ctx(row)
    raw_reasons = (
        row.get("final_entry_reasons")
        or row.get("reasons")
        or row.get("reason_list")
        or ctx.get("final_entry_reasons")
        or ctx.get("reasons")
        or ctx.get("reason_list")
        or []
    )
    if isinstance(raw_reasons, str):
        parts = [x.strip() for x in re.split(r"[,/|]", raw_reasons) if x.strip()]
    elif isinstance(raw_reasons, list):
        parts = [str(x).strip() for x in raw_reasons if str(x).strip()]
    else:
        parts = []
    cleaned = []
    for x in parts:
        x = x.replace("관찰전환:", "").replace("재확인대기:", "").strip()
        if x and x not in cleaned:
            cleaned.append(x)
        if len(cleaned) >= limit:
            break
    return ", ".join(cleaned) if cleaned else "-"


def _v073_risk_text(row: Dict[str, Any], limit: int = 2) -> str:
    ctx = _v073_ctx(row)
    raw_tags = (
        row.get("quality_risk_tags")
        or row.get("risk_tags")
        or ctx.get("quality_risk_tags")
        or ctx.get("risk_tags")
        or ctx.get("micro_flags")
        or []
    )
    if isinstance(raw_tags, str):
        tags = [x.strip() for x in re.split(r"[,/|]", raw_tags) if x.strip()]
    elif isinstance(raw_tags, list):
        tags = [str(x).strip() for x in raw_tags if str(x).strip()]
    else:
        tags = []
    out = []
    for t in tags:
        tt = t.replace("관찰전환:", "").replace("재확인대기:", "").strip()
        if tt and tt not in out:
            out.append(tt)
        if len(out) >= limit:
            break
    return ", ".join(out) if out else "-"


_v073_base_format_open_list = format_open_list

def format_open_list(limit: int = 20) -> str:  # type: ignore[override]
    """v0.73: OPEN 개별 줄에 등급을 직접 표시한다.

    v0.71/v0.72는 /pstatus, /pscore에는 S/A/B가 나오지만 /popen 개별 줄은
    '주도추세등급'만 보여 사용자가 현재 OPEN의 등급을 바로 보기 어려웠다.
    장부와 청산 로직은 건드리지 않고 표시만 단일화한다.
    """
    open_pos = load_open()
    if not open_pos:
        return "OPEN 없음"
    rows = sorted(open_pos.values(), key=lambda x: float_any(x.get("opened_at"), default=0.0), reverse=True)[:max(1, min(limit, 30))]
    control = load_control()
    lines = [f"전략별 OPEN: {_v064_open_strategy_counts(open_pos)}"]
    for pos in rows:
        age = (now() - float_any(pos.get("opened_at"), default=now())) / 60.0
        hold_txt = hold_text_from_seconds(age * 60)
        opened_txt = opened_text_from_row(pos)[5:16] if opened_text_from_row(pos) != "-" else "-"
        watch = _v049_open_watch_status(pos, control)
        badge = _v073_grade_badge(pos)
        auto_txt = _v073_auto_candidate_text(pos)
        strategy_label = _v064_strategy_label(pos)
        ticker = short_ticker(pos.get("ticker"))
        pnl = float_any(pos.get("last_pnl_pct"), default=0.0)
        peak = fmt_pct(pos.get("peak_pct"))
        reasons = _v073_short_reasons(pos, limit=3)
        risk = _v073_risk_text(pos, limit=2)
        lines.append(
            f"- {badge} {ticker} / {auto_txt} / {strategy_label} / "
            f"진입 {opened_txt} {format_price(pos.get('entry_price'))} / 현재 {format_price(pos.get('current_price'))} / "
            f"{pnl:+.2f}% / 보유 {hold_txt} / 감시 {watch} / 최고 {peak}"
        )
        lines.append(f"  · 근거: {reasons} / 주의: {risk}")
    if len(open_pos) > len(rows):
        lines.append(f"- 나머지 {len(open_pos)-len(rows)}개는 /popen 에서 확인")
    return "\n".join(lines)


_v073_base_summary_text = summary_text

def summary_text() -> str:  # type: ignore[override]
    text = _v073_base_summary_text()
    try:
        text = text.replace("paper_bot_v0.72", VERSION)
        text = text.replace("v0.72: 등급별 성과 표시 + paper OPEN 고정개수 해제 + 저장 tmp 오류수술", "v0.73: 등급별 성과 표시 + /popen 개별 OPEN 등급표시 + paper OPEN 고정개수 해제")
    except Exception as exc:
        log_error("v073_summary_text", exc)
    return text


_v073_base_pscore_text = _v071_pscore_text

def _v071_pscore_text() -> str:  # type: ignore[override]
    text = _v073_base_pscore_text()
    try:
        text = text.replace("v0.72: S/A/B/C/제외 성과 표시 + paper OPEN 고정개수 해제", "v0.73: S/A/B/C/제외 성과 표시 + /popen 개별 OPEN 등급표시")
    except Exception as exc:
        log_error("v073_pscore_text", exc)
    return text


# =============================================================================
# v0.74: paper command compact batch + KST error-log freshness fix
# - 장부/청산/OPEN 판정은 v0.73 그대로 유지한다.
# - 여러 줄 자동 묶음에서 /pstatus /pscore /popen /perror는 compact 요약으로 먼저 보낸다.
# - 계산시간/전송시간을 분리해 페이퍼봇 명령 지연 원인을 바로 볼 수 있게 한다.
# - KST로 기록된 paper_bot_error.log를 UTC로 잘못 해석해 과거 오류가 새 오류처럼 보이던 문제를 고친다.
# =============================================================================
VERSION = "paper_bot_v0.74"

_V074_SCORE_CACHE: Dict[str, Any] = {"ts": 0.0, "rows": None}


def _v074_focus_closed_cached(ttl_sec: float = 20.0) -> List[Dict[str, Any]]:
    nowv = now()
    rows = _V074_SCORE_CACHE.get("rows")
    if isinstance(rows, list) and nowv - float_any(_V074_SCORE_CACHE.get("ts"), default=0.0) <= ttl_sec:
        return rows
    try:
        rows = _v071_focus_closed()
    except Exception as exc:
        log_error("v074_focus_closed_cached", exc)
        rows = []
    _V074_SCORE_CACHE["ts"] = nowv
    _V074_SCORE_CACHE["rows"] = list(rows or [])
    return list(rows or [])


def _v074_score_short_line(label: str, rows: Iterable[Dict[str, Any]]) -> str:
    rows = list(rows or [])
    st = score_stats(rows)
    n = int(st.get("n", 0) or 0)
    if n <= 0:
        return f"- {label}: 0전"
    return f"- {label}: {n}전 {int(st['wins'])}승 {int(st['losses'])}패 / 승률 {st['win_rate']:.1f}% / 합산 {st['total']:+.2f}% / 평균 {st['avg']:+.2f}%"


def _v074_grade_compact_lines(rows: Optional[List[Dict[str, Any]]] = None) -> List[str]:
    rows = list(rows if rows is not None else _v074_focus_closed_cached())
    g = _v071_grade_groups(rows)
    auto = g.get("S", []) + g.get("A", [])
    paper = auto + g.get("B", [])
    return [
        "[등급별 CLOSED 요약]",
        _v074_score_short_line("✅ S", g.get("S", [])),
        _v074_score_short_line("✅ A", g.get("A", [])),
        _v074_score_short_line("🟡 B", g.get("B", [])),
        _v074_score_short_line("S/A 자동매매 후보군", auto),
        _v074_score_short_line("S/A/B paper 검증", paper),
        _v074_score_short_line("현재전략 전체", rows),
    ]


def _v074_open_grade_counts(open_pos: Optional[Dict[str, Dict[str, Any]]] = None) -> Dict[str, int]:
    open_pos = open_pos if isinstance(open_pos, dict) else load_open()
    counts = {"S": 0, "A": 0, "B": 0, "C": 0, "X": 0, "U": 0}
    for row in (open_pos or {}).values():
        g = _v071_grade_from_row(row)
        counts[g] = counts.get(g, 0) + 1
    return counts


def _v074_pstatus_compact() -> str:
    control = load_control()
    status = load_json(FILES["status"], {})
    open_pos = load_open()
    grade_open = _v074_open_grade_counts(open_pos)
    rows = _v074_focus_closed_cached()
    st = score_stats(rows)
    pick = status.get("pick_stats") if isinstance(status.get("pick_stats"), dict) else {}
    lines = [
        f"🧪 /pstatus 요약 · 자동묶음 compact ({VERSION})",
        f"- 실행상태: {'ON' if control.get('running') else 'OFF'} / loop {control.get('loop_seconds')}s / OPEN 전체 {len(open_pos)}",
        f"- OPEN: S {grade_open.get('S',0)} / A {grade_open.get('A',0)} / B {grade_open.get('B',0)} / C {grade_open.get('C',0)} / 제외 {grade_open.get('X',0)} / 한도 {_v072_limit_text(control)}",
        f"- 후보읽음: {pick.get('paper_file',0)} / S {pick.get('grade_s_seen',0)} / A {pick.get('grade_a_seen',0)} / B {pick.get('grade_b_seen',0)} / C스킵 {pick.get('grade_c_observe_skip',0)} / 제외스킵 {pick.get('grade_x_block_skip',0)} / micro대기 {pick.get('micro_preopen_wait',0)}",
        f"- CLOSED 현재전략: {int(st.get('n',0))}/30 / 승률 {st.get('win_rate',0.0):.1f}% / 합산 {st.get('total',0.0):+.2f}% / 평균 {st.get('avg',0.0):+.2f}%",
        "- 신규 OPEN: S/A/B / C는 관찰 / 제외는 차단 / 자동매수 OFF",
        *_v074_grade_compact_lines(rows),
        "- 상세 전문은 /pstatus 단독 실행",
    ]
    return "\n".join(lines)


def _v074_pscore_compact() -> str:
    rows = _v074_focus_closed_cached()
    by_reason = Counter(str(r.get("exit_reason") or "unknown") for r in rows)
    lines = [
        "📊 /pscore 요약 · 자동묶음 compact",
        f"- 현재전략: {PAPER_FOCUS_STRATEGY_LABEL}",
        "- S/A=미래 자동매매 후보군, B=paper 검증, C=관찰",
        *_v074_grade_compact_lines(rows),
        "",
        "[종료 사유 TOP]",
    ]
    if by_reason:
        for k, _ in by_reason.most_common(5):
            sub = [r for r in rows if str(r.get("exit_reason") or "unknown") == k]
            lines.append(_v074_score_short_line(label_kr(k), sub))
    else:
        lines.append("- 현재전략 CLOSED 없음")
    lines.append("- 상세 전문은 /pscore 단독 실행")
    return "\n".join(lines)


def _v074_popen_compact() -> str:
    open_pos = load_open()
    lines = ["📂 /popen 요약 · 자동묶음 compact"]
    if not open_pos:
        lines.append("OPEN 없음")
    else:
        lines.append(format_open_list(8))
        if len(open_pos) > 8:
            lines.append(f"- 나머지 {len(open_pos)-8}개는 /popen 단독 실행")
    return "\n".join(lines)


def _v074_parse_error_line_ts_kst(line: str) -> float:
    try:
        m = re.search(r"\[(\d{4}-\d{2}-\d{2} \d{2}:\d{2}:\d{2})\]", str(line or ""))
        if not m:
            return 0.0
        dt = datetime.strptime(m.group(1), "%Y-%m-%d %H:%M:%S").replace(tzinfo=KST)
        return dt.timestamp()
    except Exception:
        return 0.0


def perror_text(full: bool = False) -> str:  # type: ignore[override]
    if full:
        return "🧯 paper_bot_error.log /perror_full\n\n" + tail_file(FILES["error"], 120)[-4500:]
    if not FILES["error"].exists():
        return "🧯 paper_bot_error.log\n\n✅ 오류로그 파일 없음"
    try:
        lines = FILES["error"].read_text(encoding="utf-8", errors="ignore").splitlines()
        recent_marked = [ln for ln in lines if _v074_parse_error_line_ts_kst(ln) >= PROGRAM_STARTED_TS]
        size = FILES["error"].stat().st_size if FILES["error"].exists() else 0
        out = ["🧯 paper_bot_error.log", ""]
        if recent_marked:
            out.append(f"⚠️ 새 실행 이후 오류 흔적 {len(recent_marked)}건")
            out.extend(recent_marked[-8:])
        else:
            out.append("✅ 새 실행 이후 오류 없음")
            if size > 0:
                out.append(f"- 과거 오류 흔적 있음 / 로그크기 {size} bytes")
                out.append("- 자세히: /perror_full")
        return "\n".join(out)
    except Exception as exc:
        return f"🧯 paper_bot_error.log\n\n⚠️ 오류로그 요약 실패: {exc}\n자세히: /perror_full"


_v074_base_summary_text = summary_text

def summary_text() -> str:  # type: ignore[override]
    text = _v074_base_summary_text()
    try:
        text = text.replace("paper_bot_v0.73", VERSION)
        text = text.replace("v0.73: 등급별 성과 표시 + /popen 개별 OPEN 등급표시 + paper OPEN 고정개수 해제", "v0.74: 페이퍼봇 자동묶음 compact + /popen 등급표시 + 오류시간판정 보정")
    except Exception as exc:
        log_error("v074_summary_text", exc)
    return text


_v074_base_pscore_text = _v071_pscore_text

def _v071_pscore_text() -> str:  # type: ignore[override]
    text = _v074_base_pscore_text()
    try:
        text = text.replace("v0.73: S/A/B/C/제외 성과 표시 + /popen 개별 OPEN 등급표시", "v0.74: S/A/B/C/제외 성과 표시 + /popen 등급표시 + 자동묶음 compact")
    except Exception as exc:
        log_error("v074_pscore_text", exc)
    return text


def _v074_compact_response(line: str) -> str:
    name = _cmd_name(line)
    if name == "pstatus":
        return _v074_pstatus_compact()
    if name == "pscore":
        return _v074_pscore_compact()
    if name == "popen":
        return _v074_popen_compact()
    if name == "perror":
        return perror_text(False)
    if name == "perror_full":
        return "자동묶음에서는 /perror_full 생략. 단독 실행하세요."
    if name == "pbatch":
        return "이미 자동 묶음 처리 중이라 /pbatch는 건너뜀"
    return command_response(line)


def _v074_send_timed(chat_id: str, text: str) -> float:
    t0 = now()
    send_chat(chat_id, text)
    return max(0.0, now() - t0)


def handle_command(chat_id: str, text: str) -> None:  # type: ignore[override]
    lines = _command_lines(text)
    if len(lines) > 1:
        total_start = now()
        timings: List[Dict[str, Any]] = []
        intro = (
            "📦 페이퍼봇 자동 묶음 명령 접수\n"
            "- /pbatch 없이 여러 줄 명령을 감지\n"
            f"- 실행 {len(lines)}개\n"
            "- v0.74: 묶음에서는 compact 요약을 먼저 표시, 상세 전문은 각 명령 단독 실행"
        )
        intro_send = _v074_send_timed(chat_id, intro)
        total_calc = 0.0
        total_send = intro_send
        for idx, line in enumerate(lines, start=1):
            name = _cmd_name(line)
            calc_start = now()
            try:
                body = _v074_compact_response(line)
                ok = "OK"
            except Exception as exc:
                log_error(f"v074_multi:{name}", exc)
                body = f"오류: {exc.__class__.__name__}: {exc}"
                ok = "ERR"
            calc_sec = max(0.0, now() - calc_start)
            send_sec = _v074_send_timed(chat_id, f"[{idx}/{len(lines)}] /{name} (계산 {calc_sec:.2f}s / {ok})\n" + body)
            total_calc += calc_sec
            total_send += send_sec
            timings.append({"name": name, "calc": calc_sec, "send": send_sec, "ok": ok})
        total_sec = max(0.0, now() - total_start)
        rows = [
            "🧾 페이퍼봇 자동 묶음 시간표",
            f"- 접수 전송: {intro_send:.2f}s",
        ]
        for t in timings:
            icon = "✅" if t.get("ok") == "OK" else "❌"
            rows.append(f"- {icon} /{t.get('name')}: 계산 {t.get('calc',0.0):.2f}s / 전송 {t.get('send',0.0):.2f}s / {t.get('ok')}")
        rows += [
            f"- 합계: 계산 {total_calc:.2f}s / 전송 {total_send:.2f}s / 전체 {total_sec:.2f}s",
            "- 상세 전문은 각 명령을 단독으로 실행",
        ]
        _v074_send_timed(chat_id, "\n".join(rows))
        return
    send_chat(chat_id, command_response(text))



# ──────────────────────────────────────────────────────────────────────────────
# paper_bot v0.75: S/A만 실제 paper OPEN, B/C는 shadow_eval 가상복기
# - B/C는 OPEN 장부에 태우지 않지만, 가상 포지션 파일로 60분/손절/익절 성과를 추적한다.
# - 기존 CLOSED / OPEN 장부는 건드리지 않는다.
# ──────────────────────────────────────────────────────────────────────────────
VERSION = "paper_bot_v0.75"
FILES["shadow_eval_open"] = BASE_DIR / "paper_bot_shadow_eval_open.json"
FILES["shadow_eval_closed"] = BASE_DIR / "paper_bot_shadow_eval_closed.jsonl"
SHADOW_EVAL_TTL_SEC = float(os.getenv("PAPER_SHADOW_EVAL_TTL_SEC", "90"))
SHADOW_EVAL_MAX_LATEST = int(os.getenv("PAPER_SHADOW_EVAL_MAX_LATEST", "260"))

_v075_base_load_control = load_control

def load_control() -> Dict[str, Any]:  # type: ignore[override]
    control = _v075_base_load_control()
    fixed = {
        "paper_open_grades": ["S", "A"],
        "max_open_strict": 0,
        "max_open_shadow": 0,
        "open_shadow_positions": False,
        "shadow_review_only": True,
    }
    changed = False
    for k, v in fixed.items():
        if control.get(k) != v:
            control[k] = v
            changed = True
    if changed:
        try:
            save_json(FILES["control"], control)
            set_pause_flags(bool(control.get("running")))
        except Exception:
            pass
    return control


def _v075_shadow_eval_load_open() -> Dict[str, Dict[str, Any]]:
    obj = load_json(FILES["shadow_eval_open"], {})
    return obj if isinstance(obj, dict) else {}


def _v075_shadow_eval_save_open(obj: Dict[str, Dict[str, Any]]) -> None:
    save_json(FILES["shadow_eval_open"], obj or {})


def _v075_shadow_eval_id(ev: Dict[str, Any]) -> str:
    t = normalize_ticker(ev.get("ticker") or ev.get("market") or ev.get("symbol"))
    created = int(float_any(ev.get("created_at"), ev.get("source_created_at"), ev.get("updated_ts"), default=0))
    grade = _v070_grade_from_event(ev)
    scan = str(ev.get("scan_id") or ev.get("source_scan_id") or ev.get("candidate_id") or "")[:32]
    return f"shadow_eval:{t}:{grade}:{created}:{scan}"


def _v075_shadow_eval_closed_ids(max_lines: int = 20000) -> set[str]:
    out = set()
    try:
        for r in read_jsonl(FILES["shadow_eval_closed"], max_lines=max_lines):
            sid = str(r.get("shadow_eval_id") or r.get("pos_id") or "")
            if sid:
                out.add(sid)
    except Exception:
        pass
    return out


def _v075_shadow_eval_entry(ev: Dict[str, Any], sid: str, grade: str, control: Dict[str, Any]) -> Dict[str, Any]:
    entry = get_event_price(ev)
    ctx = ev.get("entry_context") if isinstance(ev.get("entry_context"), dict) else {}
    nowv = now()
    pos = {
        "pos_id": sid,
        "shadow_eval_id": sid,
        "shadow_eval": True,
        "lane": "shadow_eval",
        "ticker": normalize_ticker(ev.get("ticker") or ev.get("market") or ev.get("symbol")),
        "strategy": ev.get("strategy") or ev.get("strategy_name") or ctx.get("strategy") or "장세 선택형 주도코인 추세 지속 전략",
        "strategy_key": ev.get("strategy_key") or ctx.get("strategy_key") or "leader_momentum_continuation",
        "entry_price": entry,
        "current_price": entry,
        "opened_at": nowv,
        "opened_at_text": iso_ts(nowv),
        "source_created_at": float_any(ev.get("created_at"), ev.get("source_created_at"), default=nowv),
        "candidate_grade": grade,
        "candidate_grade_label": ev.get("candidate_grade_label") or ctx.get("candidate_grade_label") or ("🟡 B급 관찰/복기 후보" if grade == "B" else "❔ C급 관찰 후보"),
        "strategy_bucket_hits": ev.get("strategy_bucket_hits") if isinstance(ev.get("strategy_bucket_hits"), list) else [],
        "strategy_bucket_labels": ev.get("strategy_bucket_labels") if isinstance(ev.get("strategy_bucket_labels"), list) else [],
        "strategy_eval_grades": ev.get("strategy_eval_grades") if isinstance(ev.get("strategy_eval_grades"), dict) else {},
        "strategy_eval_labels": ev.get("strategy_eval_labels") if isinstance(ev.get("strategy_eval_labels"), dict) else {},
        "leader_original_grade": ev.get("leader_original_grade") or ctx.get("leader_original_grade") or grade,
        "leader_original_label": ev.get("leader_original_label") or ctx.get("leader_original_label"),
        "take_profit_pct": float_any(ev.get("take_profit_pct"), ctx.get("take_profit_pct"), control.get("take_profit_pct"), default=1.20),
        "extended_target_pct": float_any(ev.get("extended_target_pct"), ctx.get("extended_target_pct"), control.get("extended_target_pct"), default=2.00),
        "protect_trigger_pct": float_any(ev.get("protect_trigger_pct"), ctx.get("protect_trigger_pct"), control.get("protect_trigger_pct"), default=0.70),
        "protect_floor_pct": float_any(ev.get("protect_floor_pct"), ctx.get("protect_floor_pct"), control.get("protect_floor_pct"), default=0.35),
        "stop_loss_pct": float_any(ev.get("stop_loss_pct"), ctx.get("stop_loss_pct"), control.get("stop_loss_pct"), default=-0.60),
        "time_exit_min": float_any(ev.get("time_exit_min"), ctx.get("time_exit_min"), control.get("time_exit_minutes"), default=60),
        "entry_context": dict(ctx, shadow_eval=True, candidate_grade=grade, candidate_grade_label=ev.get("candidate_grade_label") or ctx.get("candidate_grade_label")),
        "source_event": {k: ev.get(k) for k in ("ticker", "score", "leader_score", "good", "wait", "hard", "created_at", "scan_id", "strategy_bucket_primary", "strategy_bucket_primary_label")},
    }
    return pos


def _v075_shadow_eval_pick(control: Dict[str, Any], open_eval: Dict[str, Dict[str, Any]]) -> Tuple[int, Dict[str, int]]:
    stats = {"seen": 0, "opened": 0, "dup": 0, "bad": 0, "stale": 0, "grade_b": 0, "grade_c": 0}
    closed_ids = _v075_shadow_eval_closed_ids()
    rows = read_jsonl(candidate_input_path("shadow"), max_lines=SHADOW_EVAL_MAX_LATEST)
    if not rows:
        return 0, stats
    filtered, _meta = latest_scan_filter([dict(r, _lane_hint="shadow") for r in rows], control)
    nowv = now()
    for ev in filtered:
        stats["seen"] += 1
        if not isinstance(ev, dict):
            continue
        grade = _v070_grade_from_event(ev)
        if grade not in {"B", "C"}:
            continue
        if grade == "B": stats["grade_b"] += 1
        if grade == "C": stats["grade_c"] += 1
        ts = float_any(ev.get("created_at"), ev.get("source_created_at"), ev.get("updated_ts"), default=0.0)
        if ts > 0 and nowv - ts > SHADOW_EVAL_TTL_SEC:
            stats["stale"] += 1
            continue
        sid = _v075_shadow_eval_id(ev)
        if sid in open_eval or sid in closed_ids:
            stats["dup"] += 1
            continue
        if get_event_price(ev) <= 0 or not normalize_ticker(ev.get("ticker") or ev.get("market") or ev.get("symbol")):
            stats["bad"] += 1
            continue
        open_eval[sid] = _v075_shadow_eval_entry(ev, sid, grade, control)
        stats["opened"] += 1
    return stats["opened"], stats


def _v075_shadow_eval_update(control: Dict[str, Any]) -> Dict[str, Any]:
    open_eval = _v075_shadow_eval_load_open()
    opened, pick_stats = _v075_shadow_eval_pick(control, open_eval)
    closed_items: List[Dict[str, Any]] = []
    for sid, pos in list(open_eval.items()):
        try:
            updated, closed = update_position(pos, control)
            if closed:
                closed = dict(closed)
                closed["shadow_eval"] = True
                closed["shadow_eval_id"] = sid
                closed["lane"] = "shadow_eval"
                closed["candidate_grade"] = pos.get("candidate_grade")
                closed["candidate_grade_label"] = pos.get("candidate_grade_label")
                closed["strategy_eval_grades"] = pos.get("strategy_eval_grades", {})
                closed["leader_original_grade"] = pos.get("leader_original_grade")
                append_jsonl(FILES["shadow_eval_closed"], closed)
                closed_items.append(closed)
                open_eval.pop(sid, None)
            else:
                open_eval[sid] = updated
        except Exception as exc:
            log_error("shadow_eval_update", exc)
    _v075_shadow_eval_save_open(open_eval)
    return {"opened": opened, "open": len(open_eval), "closed": len(closed_items), "pick": pick_stats}


def _v075_shadow_eval_stats_lines() -> List[str]:
    rows = read_jsonl(FILES["shadow_eval_closed"], max_lines=20000)
    open_eval = _v075_shadow_eval_load_open()
    if not rows and not open_eval:
        return ["[B/C 가상복기 성과]", "- 아직 없음"]
    b = [r for r in rows if str(r.get("candidate_grade") or "").upper() == "B"]
    c = [r for r in rows if str(r.get("candidate_grade") or "").upper() == "C"]
    lines = ["[B/C 가상복기 성과 · 실제 OPEN 아님]"]
    lines.append(_v071_stats_line("🟡 B급 가상복기", b))
    lines.append(_v071_stats_line("❔ C급 가상복기", c))
    lines.append(f"- 진행중 가상복기: {len(open_eval)}개 / 실제 paper OPEN 아님")
    return lines


_v075_base_run_cycle = run_cycle

def run_cycle() -> Dict[str, Any]:  # type: ignore[override]
    status = _v075_base_run_cycle()
    try:
        control = load_control()
        shadow_eval = _v075_shadow_eval_update(control)
        status["shadow_eval"] = shadow_eval
        save_json(FILES["status"], status)
    except Exception as exc:
        log_error("v075_shadow_eval_cycle", exc)
    return status


_v075_base_summary_text = summary_text

def summary_text() -> str:  # type: ignore[override]
    text = _v075_base_summary_text()
    try:
        text = text.replace("신규 OPEN: 허용 / paper OPEN S·A·B / 고정개수 없음 / 실제 자동매매 후보 S·A만", "신규 OPEN: 허용 / 실제 paper OPEN S·A만 / B·C는 가상복기 / 고정개수 없음")
        text = text.replace("- CLOSED 30건 전 조건 변경 금지 / 실제 자동매매는 S·A만 후보 / B는 paper 검증 / C는 관찰", "- 실제 paper OPEN은 S·A만 / B·C는 OPEN 없이 가상복기 성과 추적 / 자동매수 OFF")
        text += "\n\n" + "\n".join(_v075_shadow_eval_stats_lines())
    except Exception as exc:
        log_error("v075_summary_text", exc)
    return text

_v075_base_pscore_text = _v071_pscore_text

def _v071_pscore_text() -> str:  # type: ignore[override]
    text = _v075_base_pscore_text()
    try:
        text = text.replace("v0.74: S/A/B/C/제외 성과 표시 + /popen 등급표시 + 자동묶음 compact", "v0.75: 실제 OPEN S/A만 + B/C shadow_eval 가상성과 + 자동묶음 compact")
        text = text.replace("B=paper 검증", "B=가상복기")
        text += "\n\n" + "\n".join(_v075_shadow_eval_stats_lines())
    except Exception as exc:
        log_error("v075_pscore_text", exc)
    return text

_v075_base_pstatus_compact = _v074_pstatus_compact

def _v074_pstatus_compact() -> str:  # type: ignore[override]
    text = _v075_base_pstatus_compact()
    try:
        st = load_json(FILES.get("status", BASE_DIR / "paper_bot_status.json"), {})
        se = st.get("shadow_eval") if isinstance(st, dict) else {}
        if isinstance(se, dict):
            text += f"\n- B/C 가상복기: 진행 {se.get('open',0)} / 이번 cycle 신규 {se.get('opened',0)} / 청산 {se.get('closed',0)}"
        text = text.replace("S/A/B", "S/A OPEN + B/C 가상복기")
    except Exception as exc:
        log_error("v075_pstatus_compact", exc)
    return text

_v075_base_pscore_compact = _v074_pscore_compact

def _v074_pscore_compact() -> str:  # type: ignore[override]
    text = _v075_base_pscore_compact()
    try:
        rows = read_jsonl(FILES["shadow_eval_closed"], max_lines=20000)
        if rows:
            b = [r for r in rows if str(r.get("candidate_grade") or "").upper() == "B"]
            c = [r for r in rows if str(r.get("candidate_grade") or "").upper() == "C"]
            text += "\n[B/C 가상복기]"
            text += "\n" + _v071_stats_line("🟡 B급", b)
            text += "\n" + _v071_stats_line("❔ C급", c)
    except Exception as exc:
        log_error("v075_pscore_compact", exc)
    return text

try:
    DEFAULT_CONTROL["paper_open_grades"] = ["S", "A"]
    DEFAULT_CONTROL["open_shadow_positions"] = False
    DEFAULT_CONTROL["shadow_review_only"] = True
except Exception:
    pass


# =============================================================================
# v0.76: fast-stop / larger-profit fallback + closed-read light cache
# - 후보 entry_context 청산값을 최우선으로 쓰는 구조는 유지한다.
# - 후보값이 없을 때 fallback을 v310 정책에 맞춘다.
# - 기본 명령이 매번 전체 CLOSED 장부를 훑지 않도록 읽기 범위를 줄인다.
# - 장부 파일은 삭제하지 않는다. full 재계산이 필요하면 별도 full 명령으로 본다.
# =============================================================================
VERSION = "paper_bot_v0.76"
V076_CLOSED_READ_LIMIT = int(os.getenv("PAPERBOT_CLOSED_READ_LIMIT", "2500"))

try:
    DEFAULT_CONTROL.update({
        "take_profit_pct": 1.80,
        "extended_target_pct": 2.80,
        "protect_trigger_pct": 1.00,
        "protect_floor_pct": 0.45,
        "stop_loss_pct": -0.45,
        "time_exit_minutes": 60,
        "paper_open_grades": ["S", "A"],
        "open_shadow_positions": False,
        "shadow_review_only": True,
    })
except Exception:
    pass

_v076_base_v064_focus_closed_rows = _v064_focus_closed_rows

def _v064_focus_closed_rows(limit: int = 20000) -> List[Dict[str, Any]]:  # type: ignore[override]
    """v0.76: 기본 상태/성과 명령은 최근 CLOSED만 읽는다.

    장부 보존과는 별개다. paper_bot_closed.jsonl은 그대로 유지하고,
    명령 계산에서만 서버 부담을 줄인다.
    """
    try:
        lim = max(300, min(int(limit or V076_CLOSED_READ_LIMIT), V076_CLOSED_READ_LIMIT))
    except Exception:
        lim = V076_CLOSED_READ_LIMIT
    return _v076_base_v064_focus_closed_rows(lim)

_v076_base_pstatus_compact = _v074_pstatus_compact

def _v074_pstatus_compact() -> str:  # type: ignore[override]
    text = _v076_base_pstatus_compact()
    try:
        text = text.replace("paper_bot_v0.75", VERSION)
        text += f"\n- v0.76: 기본 CLOSED 계산 최근 {V076_CLOSED_READ_LIMIT}줄 기준 / 전체 장부는 보존"
        text += "\n- fallback 청산: 익절 +1.80% / 확장 +2.80% / 보호 +1.00%→+0.45% / 손절 -0.45% / 시간 60분"
    except Exception as exc:
        log_error("v076_pstatus_compact", exc)
    return text

_v076_base_pscore_compact = _v074_pscore_compact

def _v074_pscore_compact() -> str:  # type: ignore[override]
    text = _v076_base_pscore_compact()
    try:
        text = text.replace("/pscore 요약 · 자동묶음 compact", "/pscore 요약 · 자동묶음 compact (최근 CLOSED 경량계산)")
        text += f"\n- v0.76: 기본 성과는 최근 {V076_CLOSED_READ_LIMIT}줄 읽기. 오래된 전체 장부는 삭제하지 않음"
    except Exception as exc:
        log_error("v076_pscore_compact", exc)
    return text

_v076_base_summary_text = summary_text

def summary_text() -> str:  # type: ignore[override]
    text = _v076_base_summary_text()
    try:
        text = text.replace("paper_bot_v0.75", VERSION)
        text = text.replace("fallback 익절 +1.20%", "fallback 익절 +1.80%")
        text = text.replace("보호 +0.70%→+0.35%", "보호 +1.00%→+0.45%")
        text = text.replace("손절 -0.60%", "손절 -0.45%")
        text += f"\n- v0.76 경량화: 기본 성과계산은 최근 {V076_CLOSED_READ_LIMIT}줄 기준, 장부는 보존"
    except Exception as exc:
        log_error("v076_summary_text", exc)
    return text


# =============================================================================
# paper_bot v0.77: default command cache surgery
# - /pscore, /pstatus 기본 명령이 CLOSED 6000줄을 직접 읽던 경로를 끊는다.
# - 기본 명령은 paper_bot_score_cache.json만 읽는다.
# - 직접계산은 /pscore_full, /pstatus_full에서만 허용한다.
# - 장부 OPEN/CLOSED/trade_log는 삭제하지 않는다.
# =============================================================================
VERSION = "paper_bot_v0.77"
FILES["score_cache"] = BASE_DIR / "paper_bot_score_cache.json"
V077_CACHE_TTL_SEC = float(os.getenv("PAPERBOT_SCORE_CACHE_TTL_SEC", "90"))
V077_CACHE_TAIL_LINES = int(os.getenv("PAPERBOT_SCORE_CACHE_TAIL_LINES", "450"))
V077_CACHE_TAIL_BYTES = int(os.getenv("PAPERBOT_SCORE_CACHE_TAIL_BYTES", "1200000"))


def _v077_read_jsonl_tail_fast(path: Path, max_lines: int = 500, max_bytes: int = 1_200_000) -> List[Dict[str, Any]]:
    if not path.exists():
        return []
    try:
        size = path.stat().st_size
        start = max(0, size - max_bytes)
        with path.open("rb") as f:
            f.seek(start)
            data = f.read()
        text = data.decode("utf-8", errors="ignore")
        lines = text.splitlines()
        if start > 0 and lines:
            lines = lines[1:]  # drop partial line
        out = []
        for line in lines[-max_lines:]:
            line = line.strip()
            if not line:
                continue
            try:
                obj = json.loads(line)
                if isinstance(obj, dict):
                    out.append(obj)
            except Exception:
                continue
        return out
    except Exception as exc:
        log_error("v077_read_tail_fast", exc)
        return []


def _v077_focus_rows_fast() -> List[Dict[str, Any]]:
    rows = _v077_read_jsonl_tail_fast(FILES["closed"], V077_CACHE_TAIL_LINES, V077_CACHE_TAIL_BYTES)
    # 현재전략/전략바구니 관련만. 과거 장부는 보존하지만 기본 지표에서는 최근·현재 관련만 본다.
    focus = []
    for r in rows:
        sk = str(r.get("strategy_key") or r.get("paper_strategy_key") or "")
        st = str(r.get("strategy") or r.get("strategy_name") or "")
        if ("leader_momentum" in sk or "money_reaccel" in sk or "strategy_basket" in sk or "장세 선택형" in st or "전략 바구니" in st):
            focus.append(r)
    return focus


def _v077_group_by_grade(rows: List[Dict[str, Any]]) -> Dict[str, List[Dict[str, Any]]]:
    out = {"S": [], "A": [], "B": [], "C": [], "X": []}
    for r in rows or []:
        g = _v071_grade_from_row(r) if '_v071_grade_from_row' in globals() else str(r.get("candidate_grade") or "C").upper()
        if g not in out:
            g = "C"
        out[g].append(r)
    return out


def _v077_short_stat(label: str, rows: List[Dict[str, Any]]) -> Dict[str, Any]:
    s = score_stats(rows)
    return {"label": label, "n": int(s.get("n",0)), "wins": int(s.get("wins",0)), "losses": int(s.get("losses",0)), "win_rate": round(float_any(s.get("win_rate"), default=0.0), 1), "total": round(float_any(s.get("total"), default=0.0), 2), "avg": round(float_any(s.get("avg"), default=0.0), 2)}


def _v077_reason_stats(rows: List[Dict[str, Any]]) -> List[Dict[str, Any]]:
    c = Counter(str(r.get("exit_reason") or "unknown") for r in rows or [])
    out = []
    for k, _ in c.most_common(6):
        sub = [r for r in rows if str(r.get("exit_reason") or "unknown") == k]
        d = _v077_short_stat(label_kr(k), sub)
        d["key"] = k
        out.append(d)
    return out


def _v077_strategy_stats(rows: List[Dict[str, Any]]) -> List[Dict[str, Any]]:
    buckets: Dict[str, List[Dict[str, Any]]] = {}
    for r in rows or []:
        keys = []
        evals = r.get("strategy_eval_grades") if isinstance(r.get("strategy_eval_grades"), dict) else {}
        if evals:
            keys = [str(k) for k in evals.keys()]
        else:
            k = str(r.get("strategy_bucket_primary") or r.get("strategy_key") or r.get("paper_strategy_key") or "unknown")
            keys = [k]
        for k in keys:
            buckets.setdefault(k, []).append(r)
    return [_v077_short_stat(k, v) for k, v in sorted(buckets.items())[:12]]


def _v077_build_score_cache(reason: str = "cycle") -> Dict[str, Any]:
    rows = _v077_focus_rows_fast()
    groups = _v077_group_by_grade(rows)
    auto = groups.get("S", []) + groups.get("A", [])
    paper = auto + groups.get("B", [])
    open_pos = load_open()
    status = load_json(FILES.get("status", BASE_DIR / "paper_bot_status.json"), {})
    shadow_rows = _v077_read_jsonl_tail_fast(FILES.get("shadow_eval_closed", BASE_DIR / "paper_bot_shadow_eval_closed.jsonl"), 300, 600000)
    cache = {
        "schema": "paper_score_cache_v077",
        "version": VERSION,
        "updated_at": now(),
        "updated_at_text": iso_ts(),
        "reason": reason,
        "source_tail_lines": V077_CACHE_TAIL_LINES,
        "closed_file_size": FILES["closed"].stat().st_size if FILES["closed"].exists() else 0,
        "closed_total": closed_count(),
        "open_total": len(open_pos),
        "open_grade_counts": _v074_open_grade_counts(open_pos) if '_v074_open_grade_counts' in globals() else {},
        "loop_seconds": load_control().get("loop_seconds"),
        "running": bool(load_control().get("running")),
        "pick_stats": status.get("pick_stats") if isinstance(status.get("pick_stats"), dict) else {},
        "grade_stats": {
            "S": _v077_short_stat("✅ S", groups.get("S", [])),
            "A": _v077_short_stat("✅ A", groups.get("A", [])),
            "B": _v077_short_stat("🟡 B", groups.get("B", [])),
            "C": _v077_short_stat("❔ C", groups.get("C", [])),
            "X": _v077_short_stat("❌ 제외", groups.get("X", [])),
            "AUTO": _v077_short_stat("S/A 자동매매 후보군", auto),
            "PAPER": _v077_short_stat("S/A OPEN + B/C 가상복기", paper),
            "ALL": _v077_short_stat("현재전략 최근", rows),
        },
        "reason_stats": _v077_reason_stats(rows),
        "strategy_stats": _v077_strategy_stats(rows),
        "shadow_eval": {
            "closed_rows": len(shadow_rows),
            "B": _v077_short_stat("🟡 B 가상복기", [r for r in shadow_rows if str(r.get("candidate_grade") or "").upper() == "B"]),
            "C": _v077_short_stat("❔ C 가상복기", [r for r in shadow_rows if str(r.get("candidate_grade") or "").upper() == "C"]),
        },
        "note": "v0.77: 기본 명령은 이 캐시만 읽음. 전체/직접계산은 /pscore_full 또는 /pstatus_full.",
    }
    save_json(FILES["score_cache"], cache)
    return cache


def _v077_score_cache(allow_stale: bool = True) -> Dict[str, Any]:
    c = load_json(FILES["score_cache"], {})
    if not isinstance(c, dict) or not c:
        return {}
    return c


def _v077_stat_line_from_cache(d: Dict[str, Any]) -> str:
    if not d:
        return "- 없음"
    return f"- {d.get('label','-')}: {d.get('n',0)}전 {d.get('wins',0)}승 {d.get('losses',0)}패 / 승률 {d.get('win_rate',0.0):.1f}% / 합산 {float_any(d.get('total'),default=0.0):+.2f}% / 평균 {float_any(d.get('avg'),default=0.0):+.2f}%"


def _v077_cache_age_text(c: Dict[str, Any]) -> str:
    age = max(0.0, now() - float_any(c.get("updated_at"), default=0.0)) if c else -1
    if age < 0:
        return "캐시 없음"
    flag = "✅" if age <= V077_CACHE_TTL_SEC else "⚠️"
    return f"{flag} 캐시 {age:.0f}초 전"


def _v077_pstatus_cached_text(compact: bool = True) -> str:
    c = _v077_score_cache()
    if not c:
        return "🧪 /pstatus 요약 · 캐시 준비중\n- 다음 loop에서 paper_score_cache.json 생성 후 표시됩니다.\n- 무거운 직접계산은 /pstatus_full 단독 실행"
    og = c.get("open_grade_counts") if isinstance(c.get("open_grade_counts"), dict) else {}
    gs = c.get("grade_stats") if isinstance(c.get("grade_stats"), dict) else {}
    pick = c.get("pick_stats") if isinstance(c.get("pick_stats"), dict) else {}
    lines = [
        f"🧪 /pstatus 요약 · 캐시전용 ({VERSION})",
        f"- 상태: {'ON' if c.get('running') else 'OFF'} / loop {c.get('loop_seconds','-')}s / OPEN {c.get('open_total',0)} / {_v077_cache_age_text(c)}",
        f"- OPEN: S {og.get('S',0)} / A {og.get('A',0)} / B {og.get('B',0)} / C {og.get('C',0)} / 제외 {og.get('X',0)} / 한도 고정없음",
        f"- 후보읽음: {pick.get('paper_file',0)} / S {pick.get('grade_s_seen',0)} / A {pick.get('grade_a_seen',0)} / B {pick.get('grade_b_seen',0)} / C스킵 {pick.get('grade_c_observe_skip',0)} / 제외스킵 {pick.get('grade_x_block_skip',0)}",
        "[최근 성과 캐시]",
        _v077_stat_line_from_cache(gs.get("S", {})),
        _v077_stat_line_from_cache(gs.get("A", {})),
        _v077_stat_line_from_cache(gs.get("B", {})),
        _v077_stat_line_from_cache(gs.get("AUTO", {})),
        _v077_stat_line_from_cache(gs.get("ALL", {})),
        "- 실제 paper OPEN은 S/A만. B/C는 OPEN 없이 가상복기. 자동매수 OFF",
        "- 장부는 보존. 기본명령은 캐시만 읽음. 전체 직접계산은 /pstatus_full",
    ]
    return "\n".join(lines)


def _v077_pscore_cached_text(compact: bool = True) -> str:
    c = _v077_score_cache()
    if not c:
        return "📊 /pscore 요약 · 캐시 준비중\n- 다음 loop에서 paper_score_cache.json 생성 후 표시됩니다.\n- 무거운 직접계산은 /pscore_full 단독 실행"
    gs = c.get("grade_stats") if isinstance(c.get("grade_stats"), dict) else {}
    lines = [
        f"📊 /pscore 요약 · 캐시전용 ({VERSION})",
        f"- 기준: 최근 {c.get('source_tail_lines','-')}줄 tail 캐시 / 전체 CLOSED {c.get('closed_total','-')}개 보존 / {_v077_cache_age_text(c)}",
        "[등급별 최근 성과]",
        _v077_stat_line_from_cache(gs.get("S", {})),
        _v077_stat_line_from_cache(gs.get("A", {})),
        _v077_stat_line_from_cache(gs.get("B", {})),
        _v077_stat_line_from_cache(gs.get("AUTO", {})),
        _v077_stat_line_from_cache(gs.get("PAPER", {})),
        _v077_stat_line_from_cache(gs.get("ALL", {})),
        "[종료 사유 TOP]",
    ]
    for d in c.get("reason_stats", [])[:6] if isinstance(c.get("reason_stats"), list) else []:
        lines.append(_v077_stat_line_from_cache(d))
    ss = c.get("shadow_eval") if isinstance(c.get("shadow_eval"), dict) else {}
    if ss:
        lines += ["[B/C 가상복기 캐시]", _v077_stat_line_from_cache(ss.get("B", {})), _v077_stat_line_from_cache(ss.get("C", {}))]
    lines += ["- 기본 /pscore는 직접계산 안 함. 전체 재계산은 /pscore_full 단독 실행"]
    return "\n".join(lines)


_v077_base_run_cycle = run_cycle

def run_cycle() -> Dict[str, Any]:  # type: ignore[override]
    st = _v077_base_run_cycle()
    try:
        cache = _v077_build_score_cache("run_cycle")
        if isinstance(st, dict):
            st["score_cache_version"] = VERSION
            st["score_cache_updated_at"] = cache.get("updated_at")
            st["score_cache_age_sec"] = 0
            save_json(FILES["status"], st)
    except Exception as exc:
        log_error("v077_score_cache_update", exc)
    return st


def summary_text() -> str:  # type: ignore[override]
    return _v077_pstatus_cached_text(compact=False)


def _v071_pscore_text() -> str:  # type: ignore[override]
    return _v077_pscore_cached_text(compact=False)


def _v074_pstatus_compact() -> str:  # type: ignore[override]
    return _v077_pstatus_cached_text(compact=True)


def _v074_pscore_compact() -> str:  # type: ignore[override]
    return _v077_pscore_cached_text(compact=True)


_v077_base_command_response = command_response

def command_response(text: str) -> str:  # type: ignore[override]
    cmd = (text or "").strip().split()[0].lower() if (text or "").strip().split() else ""
    if "@" in cmd:
        cmd = cmd.split("@", 1)[0]
    if cmd == "/pstatus":
        return _v077_pstatus_cached_text(False)
    if cmd == "/pscore":
        return _v077_pscore_cached_text(False)
    if cmd == "/pstatus_full":
        return _v076_summary_text() if '_v076_summary_text' in globals() else _v077_base_command_response('/pstatus')
    if cmd == "/pscore_full":
        # full은 기존 직접계산 경로를 명시적으로 사용한다. 기본 명령에서는 절대 호출하지 않는다.
        try:
            return _v075_base_pscore_text() if '_v075_base_pscore_text' in globals() else _v077_base_command_response('/pscore')
        except Exception as exc:
            return f"📊 /pscore_full\n직접계산 실패: {exc.__class__.__name__}: {exc}"
    return _v077_base_command_response(text)

try:
    DEFAULT_CONTROL.update({"paper_open_grades": ["S", "A"], "open_shadow_positions": False, "shadow_review_only": True})
except Exception:
    pass
try:
    # 시작 직후 캐시가 없으면 가볍게 한 번 만든다. 실패해도 기본 명령은 직접계산으로 돌아가지 않는다.
    if not FILES["score_cache"].exists():
        _v077_build_score_cache("startup")
except Exception as exc:
    try:
        log_error("v077_startup_cache", exc)
    except Exception:
        pass


# =============================================================================
# paper_bot v0.78: score cache freshness guard
# - v0.77 cut the heavy /pscore direct path. v0.78 keeps that surgery and adds a
#   bounded cache freshness guard so stale cache is refreshed from a small tail,
#   never from the whole CLOSED ledger in default commands.
# =============================================================================
VERSION = "paper_bot_v0.78"
V078_STALE_REFRESH_SEC = float(os.getenv("PAPERBOT_STALE_CACHE_REFRESH_SEC", "180"))
_v078_cache_refreshing = False

_v078_base_score_cache = _v077_score_cache

def _v077_score_cache(allow_stale: bool = True) -> Dict[str, Any]:  # type: ignore[override]
    global _v078_cache_refreshing
    c = _v078_base_score_cache(allow_stale=True)
    try:
        age = max(0.0, now() - float_any(c.get("updated_at"), default=0.0)) if isinstance(c, dict) and c else 999999.0
        if age > V078_STALE_REFRESH_SEC and not _v078_cache_refreshing:
            _v078_cache_refreshing = True
            try:
                c = _v077_build_score_cache("stale_cache_bounded_tail_refresh_v078")
            finally:
                _v078_cache_refreshing = False
    except Exception as exc:
        try:
            log_error("v078_stale_cache_refresh", exc)
        except Exception:
            pass
    return c if isinstance(c, dict) else {}

_v078_base_pstatus_cached_text = _v077_pstatus_cached_text

def _v077_pstatus_cached_text(compact: bool = True) -> str:  # type: ignore[override]
    text = _v078_base_pstatus_cached_text(compact)
    return text.replace("paper_bot_v0.77", VERSION).replace("v0.77:", "v0.78:") + "\n- v0.78: 기본명령은 전체 CLOSED 직접계산 금지. stale 캐시는 bounded tail로만 갱신."

_v078_base_pscore_cached_text = _v077_pscore_cached_text

def _v077_pscore_cached_text(compact: bool = True) -> str:  # type: ignore[override]
    text = _v078_base_pscore_cached_text(compact)
    return text.replace("paper_bot_v0.77", VERSION).replace("v0.77:", "v0.78:") + "\n- v0.78: /pscore 기본명령은 캐시 전용, stale 시 최근 tail만 bounded refresh. 전체 재계산은 /pscore_full."

try:
    DEFAULT_CONTROL.update({"paper_open_grades": ["S", "A"], "open_shadow_positions": False, "shadow_review_only": True})
except Exception:
    pass
try:
    cache = _v077_build_score_cache("startup_v078")
except Exception as exc:
    try:
        log_error("v078_startup_cache", exc)
    except Exception:
        pass


# =============================================================================
# paper_bot v0.79: strategy-basket display surgery
# - v0.78 speed/cache surgery remains.
# - OPEN lines previously showed the legacy focus strategy label for every entry.
# - Keep ledger/closing untouched, but preserve and display strategy_bucket_primary_label
#   and strategy_bucket_labels from the brain candidate.
# =============================================================================
VERSION = "paper_bot_v0.79"


def _v079_event_strategy_fields(ev: Dict[str, Any]) -> Dict[str, Any]:
    ctx = ev.get("entry_context") if isinstance(ev.get("entry_context"), dict) else {}
    raw = ev.get("raw") if isinstance(ev.get("raw"), dict) else {}
    source = ev.get("source_event") if isinstance(ev.get("source_event"), dict) else {}
    def pick(*keys, default=None):
        for k in keys:
            for obj in (ev, ctx, raw, source):
                if isinstance(obj, dict) and obj.get(k) not in (None, "", []):
                    return obj.get(k)
        return default
    labels = pick("strategy_bucket_labels", default=[])
    if not isinstance(labels, list):
        labels = []
    hits = pick("strategy_bucket_hits", default=[])
    if not isinstance(hits, list):
        hits = []
    eval_grades = pick("strategy_eval_grades", default={})
    if not isinstance(eval_grades, dict):
        eval_grades = {}
    eval_labels = pick("strategy_eval_labels", default={})
    if not isinstance(eval_labels, dict):
        eval_labels = {}
    primary = pick("strategy_bucket_primary", "primary_strategy_key", default="")
    primary_label = pick("strategy_bucket_primary_label", "primary_strategy_label", default="")
    return {
        "strategy_bucket_primary": primary,
        "strategy_bucket_primary_label": primary_label,
        "strategy_bucket_hits": hits,
        "strategy_bucket_labels": labels,
        "strategy_eval_grades": eval_grades,
        "strategy_eval_labels": eval_labels,
    }

_v079_base_open_position = open_position

def open_position(pos_id: str, ev: Dict[str, Any], control: Dict[str, Any]) -> Dict[str, Any]:  # type: ignore[override]
    pos = _v079_base_open_position(pos_id, ev, control)
    fields = _v079_event_strategy_fields(ev)
    ctx = pos.get("entry_context") if isinstance(pos.get("entry_context"), dict) else {}
    ctx = dict(ctx)
    for k, v in fields.items():
        if v not in (None, "", [], {}):
            pos[k] = v
            ctx[k] = v
    # Keep legacy strategy for backward filtering, but add display label for UI.
    label = fields.get("strategy_bucket_primary_label") or ""
    labels = fields.get("strategy_bucket_labels") or []
    if label:
        pos["paper_strategy_display"] = f"전략바구니: {label}"
    elif labels:
        pos["paper_strategy_display"] = "전략바구니: " + ", ".join(str(x) for x in labels[:3])
    pos["entry_context"] = ctx
    return pos


def _v079_strategy_display(row: Dict[str, Any]) -> str:
    ctx = row.get("entry_context") if isinstance(row.get("entry_context"), dict) else {}
    raw = row.get("raw") if isinstance(row.get("raw"), dict) else {}
    for obj in (row, ctx, raw):
        if not isinstance(obj, dict):
            continue
        disp = obj.get("paper_strategy_display")
        if disp:
            return str(disp)
        primary_label = obj.get("strategy_bucket_primary_label") or obj.get("primary_strategy_label")
        if primary_label:
            return "전략바구니: " + str(primary_label)
        labels = obj.get("strategy_bucket_labels")
        if isinstance(labels, list) and labels:
            return "전략바구니: " + ", ".join(str(x) for x in labels[:3])
        eval_labels = obj.get("strategy_eval_labels")
        eval_grades = obj.get("strategy_eval_grades")
        if isinstance(eval_labels, dict) and isinstance(eval_grades, dict):
            active = []
            for k, g in eval_grades.items():
                if str(g).upper() in {"S", "A"}:
                    active.append(str(eval_labels.get(k) or k))
            if active:
                return "전략바구니: " + ", ".join(active[:3])
    # fallback to legacy label only when no basket metadata exists.
    return PAPER_FOCUS_STRATEGY_LABEL if _v052_is_focus_strategy(row) else strategy_kr(_v064_field(row, "strategy", "route", "strategy_key"))


def _v064_strategy_label(row: Dict[str, Any]) -> str:  # type: ignore[override]
    return _v079_strategy_display(row or {})

_v079_base_format_open_list = format_open_list

def format_open_list(limit: int = 20) -> str:  # type: ignore[override]
    open_pos = load_open()
    if not open_pos:
        return "OPEN 없음"
    rows = sorted(open_pos.values(), key=lambda x: float_any(x.get("opened_at"), default=0.0), reverse=True)[:max(1, min(limit, 30))]
    control = load_control()
    lines = [f"전략별 OPEN: {_v064_open_strategy_counts(open_pos)}"]
    for pos in rows:
        age = (now() - float_any(pos.get("opened_at"), default=now())) / 60.0
        hold_txt = hold_text_from_seconds(age * 60)
        opened_txt = opened_text_from_row(pos)[5:16] if opened_text_from_row(pos) != "-" else "-"
        watch = _v049_open_watch_status(pos, control)
        badge = _v073_grade_badge(pos) if '_v073_grade_badge' in globals() else str(pos.get('candidate_grade') or '-')
        auto_txt = _v073_auto_candidate_text(pos) if '_v073_auto_candidate_text' in globals() else "paper"
        strategy_label = _v079_strategy_display(pos)
        ticker = short_ticker(pos.get("ticker"))
        pnl = float_any(pos.get("last_pnl_pct"), default=0.0)
        peak = fmt_pct(pos.get("peak_pct"))
        reasons = _v073_short_reasons(pos, limit=3) if '_v073_short_reasons' in globals() else "-"
        risk = _v073_risk_text(pos, limit=2) if '_v073_risk_text' in globals() else "-"
        lines.append(
            f"- {badge} {ticker} / {auto_txt} / {strategy_label} / "
            f"진입 {opened_txt} {format_price(pos.get('entry_price'))} / 현재 {format_price(pos.get('current_price'))} / "
            f"{pnl:+.2f}% / 보유 {hold_txt} / 감시 {watch} / 최고 {peak}"
        )
        lines.append(f"  · 근거: {reasons} / 주의: {risk}")
    if len(open_pos) > len(rows):
        lines.append(f"- 나머지 {len(open_pos)-len(rows)}개는 /popen 에서 확인")
    return "\n".join(lines)

_v079_base_pstatus_cached_text = _v077_pstatus_cached_text

def _v077_pstatus_cached_text(compact: bool = True) -> str:  # type: ignore[override]
    text = _v079_base_pstatus_cached_text(compact)
    return text.replace("paper_bot_v0.78", VERSION).replace("paper_bot_v0.77", VERSION) + "\n- v0.79: /popen과 OPEN 요약에 전략바구니 실제 전략명을 표시."

_v079_base_pscore_cached_text = _v077_pscore_cached_text

def _v077_pscore_cached_text(compact: bool = True) -> str:  # type: ignore[override]
    text = _v079_base_pscore_cached_text(compact)
    return text.replace("paper_bot_v0.78", VERSION).replace("paper_bot_v0.77", VERSION)

try:
    DEFAULT_CONTROL.update({"paper_open_grades": ["S", "A"], "open_shadow_positions": False, "shadow_review_only": True})
except Exception:
    pass



# =============================================================================
# paper_bot v0.80: S handoff queue + default command no-heavy refresh
# - latest가 빈 파일이면 archive fresh 후보도 같이 본다.
# - strategy_worker_v0.4의 event_ts/created_at/expires_at/event_id를 정식으로 인식한다.
# - /pstatus, /pscore 기본 명령은 score cache만 읽고 stale tail refresh를 하지 않는다.
# =============================================================================
VERSION = "paper_bot_v0.80"
try:
    FILES["paper_merged"] = BASE_DIR / "paper_candidates_handoff_merged.jsonl"
    FILES["candidate_handoff_status"] = BASE_DIR / "paper_bot_candidate_handoff_status.json"
except Exception:
    pass


def _v080_ts(ev: Dict[str, Any], *keys: str) -> float:
    keys = keys or ("created_at", "candidate_created_at", "source_created_at", "detected_ts", "event_ts", "ts", "timestamp")
    for k in keys:
        v = float_any((ev or {}).get(k), default=0.0)
        if v > 0:
            return v
    return 0.0


def _v080_normalize_candidate(ev: Dict[str, Any], control: Optional[Dict[str, Any]] = None) -> Dict[str, Any]:
    row = dict(ev or {})
    ts = _v080_ts(row)
    if ts <= 0:
        ts = now()
    t = normalize_ticker(row.get("ticker") or row.get("market") or row.get("symbol")) or str(row.get("ticker") or "UNKNOWN")
    sk = str(row.get("strategy_key") or row.get("strategy_bucket_primary") or "strategy_s")
    eid = row.get("event_id") or row.get("event_key") or row.get("id") or f"{t}:{sk}:{int(ts // 60)}"
    ttl = float_any((control or load_control()).get("candidate_ttl_sec"), default=120.0)
    row.update({
        "ticker": t,
        "created_at": ts,
        "candidate_created_at": ts,
        "source_created_at": row.get("source_created_at") or ts,
        "detected_ts": row.get("detected_ts") or row.get("event_ts") or ts,
        "event_ts": row.get("event_ts") or ts,
        "created_at_text": row.get("created_at_text") or iso_ts(ts),
        "expires_at": row.get("expires_at") or (ts + ttl),
        "event_id": eid,
        "event_key": eid,
        "lane": "strict",
    })
    ctx = row.get("entry_context") if isinstance(row.get("entry_context"), dict) else {}
    if isinstance(ctx, dict):
        for k in ("micro_fresh", "ws_fresh", "micro_row_status", "ws_row_status", "spread_pct", "buy_ratio"):
            if row.get(k) in (None, "") and ctx.get(k) not in (None, ""):
                row[k] = ctx.get(k)
    return row


def candidate_is_fresh(ev: Dict[str, Any], control: Dict[str, Any]) -> bool:  # type: ignore[override]
    nowv = now()
    row = _v080_normalize_candidate(ev, control)
    exp = float_any(row.get("expires_at"), default=0.0)
    created = _v080_ts(row)
    ttl = float_any(control.get("candidate_ttl_sec"), default=120.0)
    if exp > 0:
        return exp >= nowv
    return created > 0 and (nowv - created) <= ttl


def _v080_event_key(ev: Dict[str, Any]) -> str:
    row = _v080_normalize_candidate(ev)
    return str(row.get("event_id") or row.get("event_key") or f"{row.get('ticker')}:{row.get('strategy_key')}:{int(_v080_ts(row)//60)}")


def _v080_write_jsonl_atomic(path: Path, rows: List[Dict[str, Any]]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    tmp = path.with_suffix(path.suffix + ".tmp")
    with tmp.open("w", encoding="utf-8") as f:
        for r in rows:
            f.write(json.dumps(r, ensure_ascii=False, separators=(",", ":"), default=str) + "\n")
    os.replace(tmp, path)


def _v080_build_candidate_merge(control: Optional[Dict[str, Any]] = None) -> Path:
    control = control or load_control()
    nowv = now()
    ttl = float_any(control.get("candidate_ttl_sec"), default=120.0)
    latest_rows = [_v080_normalize_candidate(r, control) for r in read_jsonl(FILES["paper_latest"], max_lines=200)]
    archive_rows = [_v080_normalize_candidate(r, control) for r in read_jsonl(FILES["paper_candidates"], max_lines=900)]
    merged: Dict[str, Dict[str, Any]] = {}
    for r in archive_rows + latest_rows:
        if not candidate_is_fresh(r, control):
            continue
        k = _v080_event_key(r)
        prev = merged.get(k)
        if prev is None or _v080_ts(r) >= _v080_ts(prev):
            merged[k] = r
    rows = sorted(merged.values(), key=lambda x: (_v080_ts(x), float_any(x.get("score"), default=0.0)), reverse=True)[:80]
    _v080_write_jsonl_atomic(FILES["paper_merged"], rows)
    save_json(FILES["candidate_handoff_status"], {
        "version": VERSION,
        "updated_at": nowv,
        "updated_at_text": iso_ts(nowv),
        "latest_lines": len(latest_rows),
        "archive_window": len(archive_rows),
        "merged_fresh": len(rows),
        "ttl_sec": ttl,
        "tickers": [r.get("ticker") for r in rows[:20]],
        "note": "v0.80: paper_latest + paper_archive fresh 후보를 병합해 latest 빈 파일로 S 후보를 놓치지 않음",
    })
    return FILES["paper_merged"]


def candidate_input_path(lane: str) -> Path:  # type: ignore[override]
    if lane == "strict":
        try:
            if load_control().get("consume_latest_candidate_files", True):
                return _v080_build_candidate_merge(load_control())
        except Exception as exc:
            try:
                log_error("v080_candidate_merge", exc)
            except Exception:
                pass
            # merge 실패 시 기존 latest가 아니라 archive도 볼 수 있게 paper_candidates로 fallback
            return FILES["paper_candidates"]
    if lane == "shadow" and load_control().get("consume_latest_candidate_files", True) and FILES.get("shadow_latest", Path("")).exists():
        return FILES["shadow_latest"]
    return FILES["paper_candidates"] if lane == "strict" else FILES["shadow_candidates"]


def _v077_score_cache(allow_stale: bool = True) -> Dict[str, Any]:  # type: ignore[override]
    c = load_json(FILES["score_cache"], {})
    return c if isinstance(c, dict) else {}


def _v080_cache_age_text(c: Dict[str, Any]) -> str:
    age = max(0.0, now() - float_any(c.get("updated_at"), default=0.0)) if c else -1
    if age < 0:
        return "캐시 없음"
    flag = "✅" if age <= V077_CACHE_TTL_SEC else "⚠️"
    return f"{flag} 캐시 {age:.0f}초 전"


def _v077_pstatus_cached_text(compact: bool = True) -> str:  # type: ignore[override]
    c = _v077_score_cache()
    hs = load_json(FILES.get("candidate_handoff_status", BASE_DIR / "paper_bot_candidate_handoff_status.json"), {})
    if not c:
        return f"🧪 /pstatus 요약 · 캐시 준비중 ({VERSION})\n- 기본명령은 직접계산 안 함. 다음 loop의 score cache를 기다림.\n- 후보 handoff: {hs.get('merged_fresh','-')}개"
    og = c.get("open_grade_counts") if isinstance(c.get("open_grade_counts"), dict) else {}
    gs = c.get("grade_stats") if isinstance(c.get("grade_stats"), dict) else {}
    pick = c.get("pick_stats") if isinstance(c.get("pick_stats"), dict) else {}
    lines = [
        f"🧪 /pstatus 요약 · 캐시전용 ({VERSION})",
        f"- 상태: {'ON' if c.get('running') else 'OFF'} / loop {c.get('loop_seconds','-')}s / OPEN {c.get('open_total',0)} / {_v080_cache_age_text(c)}",
        f"- OPEN: S {og.get('S',0)} / A {og.get('A',0)} / B {og.get('B',0)} / C {og.get('C',0)} / 제외 {og.get('X',0)} / 한도 고정없음",
        f"- 후보읽음: {pick.get('paper_file',0)} / S {pick.get('grade_s_seen',0)} / A {pick.get('grade_a_seen',0)} / stale {pick.get('stale_skip',0)} / micro대기 {pick.get('micro_preopen_wait',0)} / 중복 {pick.get('dup_skip',0)}",
        f"- handoff: latest {hs.get('latest_lines','-')} / archive창 {hs.get('archive_window','-')} / 병합fresh {hs.get('merged_fresh','-')} / age {max(0.0, now()-float_any(hs.get('updated_at'), default=0.0)) if hs else '-'}초",
        "[최근 성과 캐시]",
        _v077_stat_line_from_cache(gs.get("S", {})),
        _v077_stat_line_from_cache(gs.get("A", {})),
        _v077_stat_line_from_cache(gs.get("B", {})),
        _v077_stat_line_from_cache(gs.get("AUTO", {})),
        _v077_stat_line_from_cache(gs.get("ALL", {})),
        "- 기본 /pstatus는 직접계산 금지. 전체 재계산은 /pstatus_full",
    ]
    return "\n".join(lines)


def _v077_pscore_cached_text(compact: bool = True) -> str:  # type: ignore[override]
    c = _v077_score_cache()
    if not c:
        return f"📊 /pscore 요약 · 캐시 준비중 ({VERSION})\n- 기본명령은 직접계산 안 함."
    gs = c.get("grade_stats") if isinstance(c.get("grade_stats"), dict) else {}
    lines = [
        f"📊 /pscore 요약 · 캐시전용 ({VERSION})",
        f"- 기준: 최근 {c.get('source_tail_lines','-')}줄 tail 캐시 / 전체 CLOSED {c.get('closed_total','-')}개 보존 / {_v080_cache_age_text(c)}",
        "[등급별 최근 성과]",
        _v077_stat_line_from_cache(gs.get("S", {})),
        _v077_stat_line_from_cache(gs.get("A", {})),
        _v077_stat_line_from_cache(gs.get("B", {})),
        _v077_stat_line_from_cache(gs.get("AUTO", {})),
        _v077_stat_line_from_cache(gs.get("PAPER", {})),
        _v077_stat_line_from_cache(gs.get("ALL", {})),
        "- 기본 /pscore는 직접계산 금지. 전체 재계산은 /pscore_full",
    ]
    return "\n".join(lines)

try:
    DEFAULT_CONTROL.update({"paper_open_grades": ["S", "A"], "open_shadow_positions": False, "shadow_review_only": True})
except Exception:
    pass



# =============================================================================
# paper_bot v0.81: 전략별 S 전적 캐시 강화
# - /score에서 전략별 몇 전인지 볼 수 있게 strategy_s_stats를 score cache에 넣는다.
# - 장부는 tail만 읽고 기본 명령은 캐시만 본다.
# =============================================================================
VERSION = "paper_bot_v0.82"

V081_STRATEGY_LABELS = {
    "money_reaccel_s": "돈흐름 재가속",
    "leader_momentum_s": "주도추세 지속",
    "breakout_early_s": "돌파 초입",
    "sweep_vwap_recovery_s": "저점 VWAP 회복",
    "surge_rebreak_s": "급등 후 재돌파",
    "unknown": "전략 미기록",
}


def _v081_strategy_keys_from_row(row: Dict[str, Any]) -> List[str]:
    keys: List[str] = []
    raw = row.get("raw") if isinstance(row.get("raw"), dict) else {}
    ctx = row.get("entry_context") if isinstance(row.get("entry_context"), dict) else {}
    for src in (row, raw, ctx):
        multi = src.get("multi_strategy_s") if isinstance(src.get("multi_strategy_s"), list) else []
        for k in multi:
            if k and str(k) not in keys:
                keys.append(str(k))
        evals = src.get("strategy_eval_grades") if isinstance(src.get("strategy_eval_grades"), dict) else {}
        for k, v in evals.items():
            # S급으로 기록된 전략만 우선 본다. 값이 없으면 참고 전략으로도 포함한다.
            if str(v).upper() in {"S", "TRUE", "1"} and str(k) not in keys:
                keys.append(str(k))
        for field in ("strategy_key", "paper_strategy_key", "strategy_bucket_primary"):
            k = src.get(field)
            if k and str(k) not in keys:
                keys.append(str(k))
    # 과거 row.strategy가 한글 라벨일 수 있어 역매핑한다.
    label = str(row.get("strategy") or raw.get("strategy") or "")
    for k, v in V081_STRATEGY_LABELS.items():
        if v and v in label and k not in keys:
            keys.append(k)
    return keys or ["unknown"]


def _v081_strategy_s_stats(rows: List[Dict[str, Any]]) -> List[Dict[str, Any]]:
    buckets: Dict[str, List[Dict[str, Any]]] = {k: [] for k in V081_STRATEGY_LABELS if k != "unknown"}
    buckets.setdefault("unknown", [])
    for r in rows or []:
        grade = str(r.get("candidate_grade") or r.get("grade") or (r.get("raw") or {}).get("candidate_grade") or "").upper()
        # 앞으로는 S만 open이 원칙이지만, 구기록 보호를 위해 strategy key가 있으면 함께 집계한다.
        for k in _v081_strategy_keys_from_row(r):
            buckets.setdefault(k, []).append(r)
    out = []
    for k, arr in buckets.items():
        st = _v077_short_stat(V081_STRATEGY_LABELS.get(k, k), arr)
        st["key"] = k
        st["label"] = V081_STRATEGY_LABELS.get(k, k)
        out.append(st)
    out.sort(key=lambda x: (int(x.get("n", 0) or 0), float_any(x.get("total"), default=0.0)), reverse=True)
    return out

_v081_base_build_score_cache = _v077_build_score_cache

def _v077_build_score_cache(reason: str = "cycle") -> Dict[str, Any]:  # type: ignore[override]
    cache = _v081_base_build_score_cache(reason)
    try:
        rows = _v077_focus_rows_fast()
        cache["schema"] = "paper_score_cache_v081"
        cache["version"] = VERSION
        cache["strategy_s_stats"] = _v081_strategy_s_stats(rows)
        cache["note"] = "v0.81: 전략별 S 전적(strategy_s_stats) 추가. 기본 명령은 캐시만 읽음."
        save_json(FILES["score_cache"], cache)
    except Exception as exc:
        log_error("v081_strategy_score_cache", exc)
    return cache

_v081_base_pscore_cached_text = _v077_pscore_cached_text

def _v077_pscore_cached_text(compact: bool = True) -> str:  # type: ignore[override]
    c = _v077_score_cache()
    text = _v081_base_pscore_cached_text(compact).replace("paper_bot_v0.80", VERSION).replace("paper_bot_v0.79", VERSION)
    stats = c.get("strategy_s_stats") if isinstance(c.get("strategy_s_stats"), list) else []
    if stats:
        lines = [text, "", "[전략별 S 전적]"]
        for st in stats[:8]:
            label = st.get("label") or st.get("key")
            lines.append(f"- {label}: {st.get('n',0)}전 {st.get('wins',0)}승 {st.get('losses',0)}패 / 승률 {st.get('win_rate',0)}% / 합산 {float_any(st.get('total'), default=0):+.2f}%")
        return "\n".join(lines)
    return text + "\n- 전략별 S 전적 캐시는 다음 loop에서 생성됩니다."

_v081_base_pstatus_cached_text = _v077_pstatus_cached_text

def _v077_pstatus_cached_text(compact: bool = True) -> str:  # type: ignore[override]
    return _v081_base_pstatus_cached_text(compact).replace("paper_bot_v0.80", VERSION).replace("paper_bot_v0.79", VERSION)



# =============================================================================
# paper_bot v0.83: canonical 필드 표시 + 현재판 캐시 + 반복손실 재진입 보호
# - v0.82 tail override가 main() 아래에 있어 실제 실행에 안 물리던 문제를 정리한다.
# - 새 5전략 canonical 필드(change_3m/spread_pct/buy_ratio/quote_fresh 등)를 알림에 표시한다.
# - 기본 /pstatus /pscore는 현재판 앵커 이후 CLOSED만 계산해 이전 버전 승률/수익률 혼입을 막는다.
# - 같은 코인 손절 직후 재진입은 OPEN 입구에서 막는다. 장부는 보존한다.
# =============================================================================
VERSION = "paper_bot_v0.83"
FILES["score_anchor"] = BASE_DIR / "paper_bot_current_score_anchor.json"

STRATEGY_S_KEYS_V083 = {
    "money_reaccel_s": "돈흐름 재가속",
    "leader_momentum_s": "주도추세 지속",
    "breakout_early_s": "돌파 초입",
    "sweep_vwap_recovery_s": "저점 VWAP 회복",
    "surge_rebreak_s": "급등 후 재돌파",
}

for _k in [
    "change_1m", "change_3m", "change_5m", "change_15m", "change_30m",
    "relative_strength", "scanner_priority_score", "turnover_24h", "volume_expanding",
    "vwap_gap_pct", "ema5_gap_pct", "quote_fresh", "quote_source", "quote_age_sec", "quote_gap_pct", "ws_gap_pct",
    "spread_pct", "buy_ratio", "bid_wall_ratio", "ask_wall_ratio", "micro_buy_ratio", "micro_pressure_label",
    "strategy_bucket_primary", "strategy_bucket_primary_label", "paper_strategy_key", "multi_strategy_s", "strategy_bucket_keys",
]:
    try:
        if _k not in ENTRY_CONTEXT_KEYS:
            ENTRY_CONTEXT_KEYS.append(_k)
    except Exception:
        pass

_v083_base_load_control = load_control

def load_control() -> Dict[str, Any]:  # type: ignore[override]
    control = _v083_base_load_control()
    defaults = {
        "same_ticker_loss_cooldown_enabled": True,
        "same_ticker_loss_cooldown_sec": 1800,
        "same_ticker_loss_cooldown_loss_pct": -0.35,
    }
    changed = False
    for k, v in defaults.items():
        if k not in control:
            control[k] = v
            changed = True
    if changed:
        try:
            save_json(FILES["control"], control)
        except Exception:
            pass
    return control


def _v083_anchor() -> Dict[str, Any]:
    data = load_json(FILES["score_anchor"], {})
    if isinstance(data, dict) and data.get("version") == VERSION and float_any(data.get("anchor_ts"), default=0.0) > 0:
        return data
    data = {
        "schema": "paper_current_score_anchor_v083",
        "version": VERSION,
        "anchor_ts": now(),
        "anchor_text": iso_ts(),
        "closed_lines_at_anchor": line_count(FILES["closed"]),
        "note": "기본 /pstatus /pscore는 이 시점 이후 CLOSED만 현재판 성과로 계산한다. 과거 장부는 삭제하지 않는다.",
    }
    save_json(FILES["score_anchor"], data)
    return data


def _v083_anchor_ts() -> float:
    return float_any(_v083_anchor().get("anchor_ts"), default=0.0)


_v083_base_focus_rows_fast = _v077_focus_rows_fast

def _v077_focus_rows_fast() -> List[Dict[str, Any]]:  # type: ignore[override]
    rows = _v077_read_jsonl_tail_fast(FILES["closed"], V077_CACHE_TAIL_LINES, V077_CACHE_TAIL_BYTES)
    anchor_ts = _v083_anchor_ts()
    out: List[Dict[str, Any]] = []
    for r in rows:
        closed_ts = float_any(r.get("closed_at"), default=0.0)
        opened_ts = float_any(r.get("opened_at"), default=0.0)
        if max(closed_ts, opened_ts) < anchor_ts:
            continue
        if _v083_strategy_keys_from_row(r):
            out.append(r)
    return out


def _v083_strategy_keys_from_row(row: Dict[str, Any]) -> List[str]:
    keys: List[str] = []
    for k in (row.get("multi_strategy_s"), row.get("strategy_bucket_keys"), row.get("strategy_keys")):
        if isinstance(k, list):
            keys += [str(x) for x in k if str(x) in STRATEGY_S_KEYS_V083]
    for k in (row.get("paper_strategy_key"), row.get("strategy_bucket_primary"), row.get("strategy_key"), row.get("strategy")):
        if str(k) in STRATEGY_S_KEYS_V083:
            keys.append(str(k))
    ctx = row.get("entry_context") if isinstance(row.get("entry_context"), dict) else {}
    for k in (ctx.get("paper_strategy_key"), ctx.get("strategy_bucket_primary"), ctx.get("strategy_key"), ctx.get("strategy")):
        if str(k) in STRATEGY_S_KEYS_V083:
            keys.append(str(k))
    out: List[str] = []
    for k in keys:
        if k not in out:
            out.append(k)
    return out


def _v077_strategy_stats(rows: List[Dict[str, Any]]) -> List[Dict[str, Any]]:  # type: ignore[override]
    buckets: Dict[str, List[Dict[str, Any]]] = {k: [] for k in STRATEGY_S_KEYS_V083}
    for r in rows or []:
        for k in _v083_strategy_keys_from_row(r):
            buckets.setdefault(k, []).append(r)
    out=[]
    for k,label in STRATEGY_S_KEYS_V083.items():
        d=_v077_short_stat(label, buckets.get(k, []))
        d["key"]=k
        d["label"]=label
        out.append(d)
    return out


def _v077_build_score_cache(reason: str = "cycle") -> Dict[str, Any]:  # type: ignore[override]
    rows = _v077_focus_rows_fast()
    groups = _v077_group_by_grade(rows)
    auto = groups.get("S", []) + groups.get("A", [])
    paper = auto + groups.get("B", [])
    open_pos = load_open()
    status = load_json(FILES.get("status", BASE_DIR / "paper_bot_status.json"), {})
    anchor = _v083_anchor()
    cache = {
        "schema": "paper_score_cache_v083",
        "version": VERSION,
        "updated_at": now(),
        "updated_at_text": iso_ts(),
        "reason": reason,
        "score_scope": "current_version_anchor",
        "anchor_ts": anchor.get("anchor_ts"),
        "anchor_text": anchor.get("anchor_text"),
        "source_tail_lines": V077_CACHE_TAIL_LINES,
        "closed_file_size": FILES["closed"].stat().st_size if FILES["closed"].exists() else 0,
        "closed_total": closed_count(),
        "current_closed_count": len(rows),
        "open_total": len(open_pos),
        "open_grade_counts": _v074_open_grade_counts(open_pos) if '_v074_open_grade_counts' in globals() else {},
        "loop_seconds": load_control().get("loop_seconds"),
        "running": bool(load_control().get("running")),
        "pick_stats": status.get("pick_stats") if isinstance(status.get("pick_stats"), dict) else {},
        "grade_stats": {
            "S": _v077_short_stat("✅ S", groups.get("S", [])),
            "A": _v077_short_stat("✅ A", groups.get("A", [])),
            "B": _v077_short_stat("🟡 B", groups.get("B", [])),
            "C": _v077_short_stat("❔ C", groups.get("C", [])),
            "X": _v077_short_stat("❌ 제외", groups.get("X", [])),
            "AUTO": _v077_short_stat("S/A 자동매매 후보군", auto),
            "PAPER": _v077_short_stat("S/A OPEN + B/C 가상복기", paper),
            "ALL": _v077_short_stat("현재판 전체", rows),
        },
        "reason_stats": _v077_reason_stats(rows),
        "strategy_s_stats": _v077_strategy_stats(rows),
        "strategy_stats": _v077_strategy_stats(rows),
        "note": "v0.83: 기본 명령은 현재판 앵커 이후 CLOSED만 표시한다. 전체 장부는 보존하고 /pscore_full에서 확인.",
    }
    save_json(FILES["score_cache"], cache)
    return cache


def _v083_fmt_val(v: Any, digits: int = 2, suffix: str = "") -> str:
    if v in (None, "", "-"):
        return "-"
    try:
        return f"{float_any(v, default=0.0):.{digits}f}{suffix}"
    except Exception:
        return str(v)


def _v083_ctx_get(ctx: Dict[str, Any], *keys: str, default: Any = None) -> Any:
    if not isinstance(ctx, dict):
        return default
    for k in keys:
        v = ctx.get(k)
        if v not in (None, "", "-"):
            return v
    return default


def _v083_bool_fresh(ctx: Dict[str, Any], *keys: str) -> bool:
    for k in keys:
        v = _v083_ctx_get(ctx, k, default=None)
        if isinstance(v, bool):
            return v
        if str(v).lower() in {"true", "fresh", "ok", "1", "yes"}:
            return True
    return False


def ws_summary_from_ctx(ctx: Dict[str, Any]) -> str:  # type: ignore[override]
    if not isinstance(ctx, dict):
        return "- 표준시세: 정보없음\n- 웹소켓: 정보없음"
    quote_fresh = _v083_bool_fresh(ctx, "quote_fresh") or _v083_bool_fresh(ctx, "ws_fresh")
    ws_fresh = _v083_bool_fresh(ctx, "ws_fresh")
    source = _v083_ctx_get(ctx, "quote_source", "live_price_source", default="-")
    qage = _v083_ctx_get(ctx, "quote_age_sec", "live_age_sec", default=None)
    wage = _v083_ctx_get(ctx, "ws_age_sec", default=None)
    gap = _v083_ctx_get(ctx, "quote_gap_pct", "ws_gap_pct", "current_price_ws_gap_pct", default=None)
    return (
        f"- 표준시세: {yes_fresh(quote_fresh)} / 출처 {source} / age {_v083_fmt_val(qage,1,'s')}\n"
        f"- 웹소켓: {yes_fresh(ws_fresh)} / age {_v083_fmt_val(wage,1,'s')} / 시세차이 {_v083_fmt_val(gap,3,'%')}"
    )


def micro_summary_from_ctx(ctx: Dict[str, Any]) -> str:  # type: ignore[override]
    if not isinstance(ctx, dict):
        return "- 호가·체결: 정보없음"
    spread = _v083_ctx_get(ctx, "spread_pct", "micro_spread_pct", default=None)
    buy_ratio = _v083_ctx_get(ctx, "buy_ratio", "micro_buy_ratio", "micro_trade_buy_ratio_30", default=None)
    wall_ratio = _v083_ctx_get(ctx, "bid_wall_ratio", "micro_bid_ask_wall_ratio", default=None)
    fresh = _v083_bool_fresh(ctx, "micro_fresh")
    row_status = _v083_ctx_get(ctx, "micro_row_status", "micro_pressure_label", default="-")
    flags = []
    if ctx.get("micro_ask_wall_pressure") or ctx.get("ask_wall_pressure"):
        flags.append("매도벽 주의")
    if ctx.get("micro_sell_trade_pressure") or ctx.get("sell_trade_pressure"):
        flags.append("매도체결 우세")
    if not flags:
        flags.append("특이압박 없음")
    return (
        f"- 호가·체결: {yes_fresh(fresh)} / 상태 {row_status}\n"
        f"  · 스프레드 {_v083_fmt_val(spread,2,'%')} / 매수체결비율 {_v083_fmt_val(buy_ratio,2)} / 매수벽비율 {_v083_fmt_val(wall_ratio,2)}\n"
        f"  · {' / '.join(flags[:3])}"
    )


def _v083_reason_lines(ctx: Dict[str, Any]) -> List[str]:
    ch3 = _v083_ctx_get(ctx, "change_3m", "price_change_3m", default=None)
    ch5 = _v083_ctx_get(ctx, "change_5m", "price_change_5m", default=None)
    ch15 = _v083_ctx_get(ctx, "change_15m", default=None)
    vwap = _v083_ctx_get(ctx, "vwap_gap_pct", default=None)
    ema = _v083_ctx_get(ctx, "ema5_gap_pct", default=None)
    rel = _v083_ctx_get(ctx, "relative_strength", default=None)
    turnover = _v083_ctx_get(ctx, "turnover_24h", default=None)
    return [
        f"- 3분/5분/15분 변화: {_v083_fmt_val(ch3,2,'%')} / {_v083_fmt_val(ch5,2,'%')} / {_v083_fmt_val(ch15,2,'%')}",
        f"- VWAP/EMA 위치: {_v083_fmt_val(vwap,2,'%')} / {_v083_fmt_val(ema,2,'%')}",
        f"- 상대강도/거래대금: {_v083_fmt_val(rel,2)} / {fmt_money_krw_short(turnover)}",
    ]


def format_open_alert(pos: Dict[str, Any]) -> str:  # type: ignore[override]
    ctx = pos.get("entry_context") if isinstance(pos.get("entry_context"), dict) else {}
    tags = ctx.get("quality_risk_tags") or []
    final_label = pos.get("final_entry_label") or ctx.get("final_entry_label") or pos.get("trade_ready_label") or "최종검증 통과"
    reasons = pos.get("final_entry_reasons") or ctx.get("final_entry_reasons") or []
    if isinstance(reasons, list):
        reason_txt = " / ".join(str(x).replace("관찰전환:", "").replace("재확인대기:", "").strip() for x in reasons[:3] if str(x).strip()) or final_label
    else:
        reason_txt = str(reasons or final_label)
    strategy_label = ctx.get("strategy_bucket_primary_label") or pos.get("strategy_name") or strategy_kr(pos.get("strategy"))
    lines = [
        "📥 모의매매 진입",
        "",
        f"코인: {short_ticker(pos.get('ticker'))}",
        f"진입가: {format_price(pos.get('entry_price'))}",
        f"진입시간: {opened_text_from_row(pos)}",
        f"전략: {strategy_label}",
        f"판정: {str(final_label).replace('OPEN', '진입').replace('trade_ready', '최종검증 통과')}",
        exit_mode_line(pos),
        "",
        "📌 진입 근거",
        f"- 점수: {float_any(pos.get('score'), default=0.0):.2f}",
        *_v083_reason_lines(ctx),
        f"- 위험태그: {tag_text_kr(tags)}",
        "",
        "🛰 외부정보",
        ws_summary_from_ctx(ctx),
        micro_summary_from_ctx(ctx),
        "",
        market_links_text(pos.get('ticker')),
        "",
        "참고: 실제 주문 아님 / paper_bot 모의매매 장부 OPEN 기록",
    ]
    return "\n".join(lines)


def format_close_alert(closed: Dict[str, Any]) -> str:  # type: ignore[override]
    ctx = closed.get("entry_context") if isinstance(closed.get("entry_context"), dict) else {}
    reason = str(closed.get("exit_reason") or "")
    pnl = float_any(closed.get("pnl_pct"), default=0.0)
    if reason == "take_profit" or pnl > 0:
        icon = "✅"
    elif reason == "stop_loss" or pnl < -0.5:
        icon = "❌"
    else:
        icon = "⚠️"
    strategy_label = ctx.get("strategy_bucket_primary_label") or closed.get("strategy_name") or strategy_kr(closed.get("strategy"))
    lines = [
        f"{icon} 모의매매 종료: {exit_reason_kr(reason)}",
        "",
        f"코인: {short_ticker(closed.get('ticker'))}",
        f"수익률: {fmt_pct(closed.get('pnl_pct'))}",
        f"진입 → 청산: {format_price(closed.get('entry_price'))} → {format_price(closed.get('exit_price'))}",
        f"최고/최저: {fmt_pct(closed.get('peak_pct'))} / {fmt_pct(closed.get('trough_pct'))}",
        f"진입시간: {opened_text_from_row(closed)}",
        f"매도시간: {closed_text_from_row(closed)}",
        f"보유시간: {closed.get('hold_text') or hold_text_from_seconds(closed.get('hold_sec') or float_any(closed.get('age_min'), default=0.0) * 60)}",
        exit_mode_line(closed),
        f"청산규칙: {exit_reason_kr(reason)}" + (f" / {closed.get('exit_rule_reason')}" if closed.get('exit_rule_reason') else ""),
        "",
        "📌 진입 당시 근거",
        f"- 전략: {strategy_label}",
        f"- 점수: {float_any(closed.get('score'), default=0.0):.2f}",
        *_v083_reason_lines(ctx),
        f"- 위험태그: {tag_text_kr(closed.get('quality_risk_tags') or ctx.get('quality_risk_tags'))}",
        "",
        "🛰 진입 당시 외부정보",
        ws_summary_from_ctx(ctx),
        micro_summary_from_ctx(ctx),
        "",
        market_links_text(closed.get('ticker')),
    ]
    return "\n".join(x for x in lines if x is not None)


def _v083_recent_loss_block_reason(ticker: str, control: Dict[str, Any]) -> str:
    if not bool(control.get("same_ticker_loss_cooldown_enabled", True)):
        return ""
    cool = float_any(control.get("same_ticker_loss_cooldown_sec"), default=1800.0)
    loss_cut = float_any(control.get("same_ticker_loss_cooldown_loss_pct"), default=-0.35)
    if cool <= 0:
        return ""
    nowv = now()
    rows = _v077_read_jsonl_tail_fast(FILES["closed"], 600, 1200000)
    for r in reversed(rows):
        if normalize_ticker(r.get("ticker") or r.get("market") or r.get("symbol")) != ticker:
            continue
        closed_at = float_any(r.get("closed_at"), default=0.0)
        if closed_at <= 0 or nowv - closed_at > cool:
            continue
        pnl = float_any(r.get("pnl_pct"), default=0.0)
        reason = str(r.get("exit_reason") or "")
        if pnl <= loss_cut or reason in {"stop_loss", "hard_loss_guard", "quick_stop", "bounce_fail"}:
            return f"최근손실쿨다운 {int(nowv-closed_at)}초 전 {pnl:+.2f}%/{exit_reason_kr(reason)}"
    return ""


_v083_base_pick_candidates = pick_candidates

def pick_candidates(control: Dict[str, Any], open_pos: Dict[str, Dict[str, Any]]) -> Tuple[List[Tuple[str, Dict[str, Any]]], Dict[str, int]]:  # type: ignore[override]
    picked, stats = _v083_base_pick_candidates(control, open_pos)
    kept: List[Tuple[str, Dict[str, Any]]] = []
    blocked: List[str] = []
    for pos_id, ev in picked:
        t = normalize_ticker(ev.get("ticker") or ev.get("market") or ev.get("symbol")) or ""
        reason = _v083_recent_loss_block_reason(t, control) if t else ""
        if reason:
            blocked.append(f"{t}:{reason}")
            continue
        kept.append((pos_id, ev))
    stats = dict(stats or {})
    stats["recent_loss_cooldown_skip"] = len(blocked)
    if blocked:
        stats["recent_loss_cooldown_sample"] = blocked[:8]
    return kept, stats


_v083_base_pstatus_cached_text = _v077_pstatus_cached_text

def _v077_pstatus_cached_text(compact: bool = True) -> str:  # type: ignore[override]
    c = _v077_score_cache()
    if not c:
        return f"🧪 /pstatus 요약 · 캐시 준비중 ({VERSION})\n- 현재판 앵커 이후 성과 캐시를 다음 loop에서 생성합니다."
    text = _v083_base_pstatus_cached_text(compact).replace("paper_bot_v0.82", VERSION).replace("paper_bot_v0.81", VERSION).replace("paper_bot_v0.80", VERSION)
    pick = c.get("pick_stats") if isinstance(c.get("pick_stats"), dict) else {}
    extra = [
        f"- 성과범위: 현재판 앵커 이후 / {c.get('anchor_text','-')} / 현재판 CLOSED {c.get('current_closed_count',0)}개",
        f"- 재진입보호: 최근손실쿨다운 스킵 {pick.get('recent_loss_cooldown_skip',0)}",
    ]
    return text + "\n" + "\n".join(extra)


_v083_base_pscore_cached_text = _v077_pscore_cached_text

def _v077_pscore_cached_text(compact: bool = True) -> str:  # type: ignore[override]
    c = _v077_score_cache()
    if not c:
        return f"📊 /pscore 요약 · 캐시 준비중 ({VERSION})\n- 현재판 앵커 이후 성과 캐시를 다음 loop에서 생성합니다."
    text = _v083_base_pscore_cached_text(compact).replace("paper_bot_v0.82", VERSION).replace("paper_bot_v0.81", VERSION).replace("paper_bot_v0.80", VERSION)
    stats = c.get("strategy_s_stats") if isinstance(c.get("strategy_s_stats"), list) else []
    lines = [text, f"- 성과범위: 현재판 앵커 이후 / {c.get('anchor_text','-')} / 현재판 CLOSED {c.get('current_closed_count',0)}개"]
    if stats:
        lines += ["", "[전략별 S 전적 · 현재판]"]
        for st in stats[:8]:
            label = st.get("label") or st.get("key")
            lines.append(f"- {label}: {st.get('n',0)}전 {st.get('wins',0)}승 {st.get('losses',0)}패 / 승률 {st.get('win_rate',0)}% / 합산 {float_any(st.get('total'), default=0):+.2f}%")
    return "\n".join(lines)


try:
    DEFAULT_CONTROL.update({
        "same_ticker_loss_cooldown_enabled": True,
        "same_ticker_loss_cooldown_sec": 1800,
        "same_ticker_loss_cooldown_loss_pct": -0.35,
    })
except Exception:
    pass


# =============================================================================
# paper_bot v0.84: 구버전 score cache 차단 + /popen canonical 표시 재정리
# - v0.83에서 구 score_cache를 그대로 읽어 이전 버전 승률/수익률이 섞여 보이던 문제를 차단한다.
# - 기본 /pstatus /pscore는 현재 VERSION이 만든 cache만 사용한다. 구 cache면 준비중으로 표시한다.
# - /popen은 OPEN entry_context의 새 canonical 필드와 후보 근거를 직접 읽어 '-' 표시를 줄인다.
# =============================================================================
VERSION = "paper_bot_v0.84"


def _v084_score_cache_valid(c: Dict[str, Any]) -> bool:
    if not isinstance(c, dict):
        return False
    if str(c.get("version") or "") != VERSION:
        return False
    if str(c.get("score_scope") or "") != "current_version_anchor":
        return False
    if c.get("current_closed_count") is None:
        return False
    return True


def _v077_score_cache(allow_stale: bool = True) -> Dict[str, Any]:  # type: ignore[override]
    c = load_json(FILES["score_cache"], {})
    return c if _v084_score_cache_valid(c) else {}


def _v077_build_score_cache(reason: str = "cycle") -> Dict[str, Any]:  # type: ignore[override]
    rows = _v077_focus_rows_fast()
    groups = _v077_group_by_grade(rows)
    auto = groups.get("S", []) + groups.get("A", [])
    paper = auto + groups.get("B", [])
    open_pos = load_open()
    status = load_json(FILES.get("status", BASE_DIR / "paper_bot_status.json"), {})
    anchor = _v083_anchor()
    cache = {
        "schema": "paper_score_cache_v084",
        "version": VERSION,
        "updated_at": now(),
        "updated_at_text": iso_ts(),
        "reason": reason,
        "score_scope": "current_version_anchor",
        "anchor_ts": anchor.get("anchor_ts"),
        "anchor_text": anchor.get("anchor_text"),
        "source_tail_lines": V077_CACHE_TAIL_LINES,
        "closed_file_size": FILES["closed"].stat().st_size if FILES["closed"].exists() else 0,
        "closed_total": closed_count(),
        "current_closed_count": len(rows),
        "open_total": len(open_pos),
        "open_grade_counts": _v074_open_grade_counts(open_pos) if '_v074_open_grade_counts' in globals() else {},
        "loop_seconds": load_control().get("loop_seconds"),
        "running": bool(load_control().get("running")),
        "pick_stats": status.get("pick_stats") if isinstance(status.get("pick_stats"), dict) else {},
        "grade_stats": {
            "S": _v077_short_stat("✅ S", groups.get("S", [])),
            "A": _v077_short_stat("✅ A", groups.get("A", [])),
            "B": _v077_short_stat("🟡 B", groups.get("B", [])),
            "C": _v077_short_stat("❔ C", groups.get("C", [])),
            "X": _v077_short_stat("❌ 제외", groups.get("X", [])),
            "AUTO": _v077_short_stat("S/A 자동매매 후보군", auto),
            "PAPER": _v077_short_stat("S/A OPEN + B/C 가상복기", paper),
            "ALL": _v077_short_stat("현재판 전체", rows),
        },
        "reason_stats": _v077_reason_stats(rows),
        "strategy_s_stats": _v077_strategy_stats(rows),
        "strategy_stats": _v077_strategy_stats(rows),
        "note": "v0.84: 기본 명령은 현재 VERSION cache만 표시한다. 구버전 score_cache는 섞어 보여주지 않는다.",
    }
    save_json(FILES["score_cache"], cache)
    return cache


def _v084_stat_line(label: str, st: Dict[str, Any]) -> str:
    n = int(float_any(st.get("n", st.get("count", 0)), default=0)) if isinstance(st, dict) else 0
    wins = int(float_any(st.get("wins", 0), default=0)) if isinstance(st, dict) else 0
    losses = int(float_any(st.get("losses", 0), default=0)) if isinstance(st, dict) else 0
    wr = float_any(st.get("win_rate", st.get("win_rate_pct", 0)), default=0.0) if isinstance(st, dict) else 0.0
    total = float_any(st.get("total", st.get("total_pct", st.get("profit_sum", 0))), default=0.0) if isinstance(st, dict) else 0.0
    avg = float_any(st.get("avg", st.get("avg_pct", 0)), default=0.0) if isinstance(st, dict) else 0.0
    return f"- {label}: {n}전 {wins}승 {losses}패 / 승률 {wr:.1f}% / 합산 {total:+.2f}% / 평균 {avg:+.2f}%"


def _v084_cache_pending_text(kind: str) -> str:
    raw = load_json(FILES["score_cache"], {})
    old_ver = raw.get("version", "없음") if isinstance(raw, dict) else "없음"
    anchor = _v083_anchor()
    if kind == "pstatus":
        open_pos = load_open()
        hs = load_json(FILES.get("candidate_handoff_status", BASE_DIR / "paper_bot_candidate_handoff_status.json"), {})
        og = _v074_open_grade_counts(open_pos) if '_v074_open_grade_counts' in globals() else {}
        return "\n".join([
            f"🧪 /pstatus 요약 · 캐시 준비중 ({VERSION})",
            f"- 상태: {'ON' if load_control().get('running') else 'OFF'} / loop {load_control().get('loop_seconds','-')}s / OPEN {len(open_pos)}",
            f"- OPEN: S {og.get('S',0)} / A {og.get('A',0)} / B {og.get('B',0)} / C {og.get('C',0)} / 제외 {og.get('X',0)} / 한도 고정없음",
            f"- handoff: latest {hs.get('latest_lines','-')} / archive창 {hs.get('archive_window','-')} / 병합fresh {hs.get('merged_fresh','-')}",
            f"- 성과범위: 현재판 앵커 이후 / {anchor.get('anchor_text','-')} / 현재판 CLOSED 0개",
            f"- 구버전 성과캐시 무시: {old_ver} → {VERSION} cache 생성 대기",
            "- 이전 버전 승률/수익률은 기본 명령에 섞어 표시하지 않습니다.",
        ])
    return "\n".join([
        f"📊 /pscore 요약 · 캐시 준비중 ({VERSION})",
        f"- 성과범위: 현재판 앵커 이후 / {anchor.get('anchor_text','-')} / 현재판 CLOSED 0개",
        f"- 구버전 성과캐시 무시: {old_ver} → {VERSION} cache 생성 대기",
        "- 이전 버전 승률/수익률은 기본 명령에 섞어 표시하지 않습니다.",
        "- 다음 loop에서 현재판 score cache가 생성되면 표시됩니다.",
    ])


def _v077_pstatus_cached_text(compact: bool = True) -> str:  # type: ignore[override]
    c = _v077_score_cache()
    if not c:
        return _v084_cache_pending_text("pstatus")
    hs = load_json(FILES.get("candidate_handoff_status", BASE_DIR / "paper_bot_candidate_handoff_status.json"), {})
    og = c.get("open_grade_counts") if isinstance(c.get("open_grade_counts"), dict) else {}
    gs = c.get("grade_stats") if isinstance(c.get("grade_stats"), dict) else {}
    pick = c.get("pick_stats") if isinstance(c.get("pick_stats"), dict) else {}
    lines = [
        f"🧪 /pstatus 요약 · 캐시전용 ({VERSION})",
        f"- 상태: {'ON' if c.get('running') else 'OFF'} / loop {c.get('loop_seconds','-')}s / OPEN {c.get('open_total',0)} / {_v080_cache_age_text(c)}",
        f"- OPEN: S {og.get('S',0)} / A {og.get('A',0)} / B {og.get('B',0)} / C {og.get('C',0)} / 제외 {og.get('X',0)} / 한도 고정없음",
        f"- 후보읽음: {pick.get('paper_file',0)} / S {pick.get('grade_s_seen',0)} / A {pick.get('grade_a_seen',0)} / stale {pick.get('stale_skip',0)} / micro대기 {pick.get('micro_preopen_wait',0)} / 중복 {pick.get('dup_skip',0)}",
        f"- handoff: latest {hs.get('latest_lines','-')} / archive창 {hs.get('archive_window','-')} / 병합fresh {hs.get('merged_fresh','-')} / age {max(0.0, now()-float_any(hs.get('updated_at'), default=0.0)) if hs else '-'}초",
        f"- 성과범위: 현재판 앵커 이후 / {c.get('anchor_text','-')} / 현재판 CLOSED {c.get('current_closed_count',0)}개",
        "[현재판 성과 캐시]",
        _v084_stat_line("✅ S", gs.get("S", {})),
        _v084_stat_line("✅ A", gs.get("A", {})),
        _v084_stat_line("🟡 B", gs.get("B", {})),
        _v084_stat_line("S/A 자동매매 후보군", gs.get("AUTO", {})),
        _v084_stat_line("현재판 전체", gs.get("ALL", {})),
        f"- 재진입보호: 최근손실쿨다운 스킵 {pick.get('recent_loss_cooldown_skip',0)}",
        "- 기본 /pstatus는 현재 VERSION cache만 읽음. 전체 재계산은 /pstatus_full",
    ]
    return "\n".join(lines)


def _v077_pscore_cached_text(compact: bool = True) -> str:  # type: ignore[override]
    c = _v077_score_cache()
    if not c:
        return _v084_cache_pending_text("pscore")
    gs = c.get("grade_stats") if isinstance(c.get("grade_stats"), dict) else {}
    lines = [
        f"📊 /pscore 요약 · 캐시전용 ({VERSION})",
        f"- 기준: 현재판 앵커 이후 / 전체 CLOSED {c.get('closed_total','-')}개 보존 / {_v080_cache_age_text(c)}",
        f"- 현재판 CLOSED {c.get('current_closed_count',0)}개 / anchor {c.get('anchor_text','-')}",
        "[등급별 현재판 성과]",
        _v084_stat_line("✅ S", gs.get("S", {})),
        _v084_stat_line("✅ A", gs.get("A", {})),
        _v084_stat_line("🟡 B", gs.get("B", {})),
        _v084_stat_line("S/A 자동매매 후보군", gs.get("AUTO", {})),
        _v084_stat_line("S/A OPEN + B/C 가상복기", gs.get("PAPER", {})),
        _v084_stat_line("현재판 전체", gs.get("ALL", {})),
        "- 기본 /pscore는 현재 VERSION cache만 읽음. 전체 재계산은 /pscore_full",
    ]
    stats = c.get("strategy_s_stats") if isinstance(c.get("strategy_s_stats"), list) else []
    if not stats:
        stats = [{"key": k, "label": label, "n": 0, "wins": 0, "losses": 0, "win_rate": 0, "total": 0, "avg": 0} for k, label in STRATEGY_S_KEYS_V083.items()]
    lines += ["", "[전략별 S 전적 · 현재판]"]
    for st in stats[:8]:
        lines.append(_v084_stat_line(str(st.get("label") or st.get("key")), st))
    return "\n".join(lines)


def _v084_list_text(v: Any, limit: int = 3) -> str:
    if isinstance(v, list):
        xs = [str(x).strip() for x in v if str(x).strip() and str(x).strip() != "-"]
        return ", ".join(xs[:limit]) if xs else ""
    if isinstance(v, str) and v.strip() and v.strip() != "-":
        return v.strip()
    return ""


def _v084_open_reason_summary(pos: Dict[str, Any]) -> str:
    ctx = pos.get("entry_context") if isinstance(pos.get("entry_context"), dict) else {}
    txt = _v084_list_text(pos.get("final_entry_reasons") or ctx.get("final_entry_reasons") or ctx.get("reasons") or pos.get("reasons"), 3)
    if txt:
        return txt
    vals = []
    ch3 = _v083_ctx_get(ctx, "change_3m", "price_change_3m", default=None)
    ch5 = _v083_ctx_get(ctx, "change_5m", "price_change_5m", default=None)
    vwap = _v083_ctx_get(ctx, "vwap_gap_pct", default=None)
    ema = _v083_ctx_get(ctx, "ema5_gap_pct", default=None)
    buy = _v083_ctx_get(ctx, "buy_ratio", "micro_buy_ratio", "micro_trade_buy_ratio_30", default=None)
    if ch3 not in (None, "", "-") or ch5 not in (None, "", "-"):
        vals.append(f"3/5분 {_v083_fmt_val(ch3,2,'%')}/{_v083_fmt_val(ch5,2,'%')}")
    if vwap not in (None, "", "-") or ema not in (None, "", "-"):
        vals.append(f"VWAP/EMA {_v083_fmt_val(vwap,2,'%')}/{_v083_fmt_val(ema,2,'%')}")
    if buy not in (None, "", "-"):
        vals.append(f"매수체결 {_v083_fmt_val(buy,2)}")
    return " / ".join(vals[:3]) if vals else "근거값 미저장(구 OPEN 또는 후보 원본 누락)"


def _v084_open_risk_summary(pos: Dict[str, Any]) -> str:
    ctx = pos.get("entry_context") if isinstance(pos.get("entry_context"), dict) else {}
    tags = pos.get("quality_risk_tags") or ctx.get("quality_risk_tags") or pos.get("risk_tags") or ctx.get("risk_tags") or []
    try:
        txt = tag_text_kr(tags)
    except Exception:
        txt = _v084_list_text(tags, 2)
    return txt if txt and txt != "-" else "특이사항 없음"


def format_open_list(limit: int = 20) -> str:  # type: ignore[override]
    open_pos = load_open()
    if not open_pos:
        return "OPEN 없음"
    rows = sorted(open_pos.values(), key=lambda x: float_any(x.get("opened_at"), default=0.0), reverse=True)[:max(1, min(limit, 30))]
    control = load_control()
    lines = [f"전략별 OPEN: {_v064_open_strategy_counts(open_pos)}"]
    for pos in rows:
        age = (now() - float_any(pos.get("opened_at"), default=now())) / 60.0
        hold_txt = hold_text_from_seconds(age * 60)
        opened_txt = opened_text_from_row(pos)[5:16] if opened_text_from_row(pos) != "-" else "-"
        watch = _v049_open_watch_status(pos, control)
        badge = _v073_grade_badge(pos) if '_v073_grade_badge' in globals() else str(pos.get('candidate_grade') or '-')
        auto_txt = _v073_auto_candidate_text(pos) if '_v073_auto_candidate_text' in globals() else "paper"
        strategy_label = _v079_strategy_display(pos) if '_v079_strategy_display' in globals() else strategy_kr(pos.get('strategy'))
        ticker = short_ticker(pos.get("ticker"))
        pnl = float_any(pos.get("last_pnl_pct"), default=0.0)
        peak = fmt_pct(pos.get("peak_pct"))
        reasons = _v084_open_reason_summary(pos)
        risk = _v084_open_risk_summary(pos)
        lines.append(
            f"- {badge} {ticker} / {auto_txt} / {strategy_label} / "
            f"진입 {opened_txt} {format_price(pos.get('entry_price'))} / 현재 {format_price(pos.get('current_price'))} / "
            f"{pnl:+.2f}% / 보유 {hold_txt} / 감시 {watch} / 최고 {peak}"
        )
        lines.append(f"  · 근거: {reasons} / 주의: {risk}")
    if len(open_pos) > len(rows):
        lines.append(f"- 나머지 {len(open_pos)-len(rows)}개는 /popen 에서 확인")
    return "\n".join(lines)


# =============================================================================
# paper_bot v0.85: 현재판 CLOSED/전략별 S 전적 캐시 실시간 갱신
# - v0.84에서 구캐시 차단은 됐지만, fast_monitor 청산은 score_cache를 갱신하지 않아
#   B3처럼 CLOSED 알림이 떠도 /pstatus /pscore가 현재판 CLOSED 0개로 보이던 문제를 고친다.
# - 기존 anchor는 보존한다. 버전업 때문에 14:06 기준점이 새로 밀리지 않게 한다.
# - 한국어 전략명(돈흐름 재가속 S 등)만 저장된 CLOSED도 5전략 key로 역매핑한다.
# =============================================================================
VERSION = "paper_bot_v0.85"

_V085_STRATEGY_LABEL_TO_KEY = {
    "돈흐름 재가속": "money_reaccel_s",
    "주도추세 지속": "leader_momentum_s",
    "돌파 초입": "breakout_early_s",
    "저점 VWAP 회복": "sweep_vwap_recovery_s",
    "저점 쓸림 후 VWAP 회복": "sweep_vwap_recovery_s",
    "급등 후 재돌파": "surge_rebreak_s",
}


def _v083_anchor() -> Dict[str, Any]:  # type: ignore[override]
    """현재판 성과 기준점은 버전업해도 보존한다.

    v0.84에서 만든 anchor를 v0.85가 다시 만들면 방금 닫힌 CLOSED가 사라져 보인다.
    그래서 anchor_ts가 있으면 version이 달라도 그대로 쓴다.
    """
    data = load_json(FILES["score_anchor"], {})
    if isinstance(data, dict) and float_any(data.get("anchor_ts"), default=0.0) > 0:
        data.setdefault("schema", "paper_current_score_anchor_v083")
        data["active_reader_version"] = VERSION
        try:
            save_json(FILES["score_anchor"], data)
        except Exception:
            pass
        return data
    data = {
        "schema": "paper_current_score_anchor_v085",
        "version": VERSION,
        "anchor_ts": now(),
        "anchor_text": iso_ts(),
        "closed_lines_at_anchor": line_count(FILES["closed"]),
        "note": "기본 /pstatus /pscore는 이 시점 이후 CLOSED만 현재판 성과로 계산한다. 과거 장부는 삭제하지 않는다.",
    }
    save_json(FILES["score_anchor"], data)
    return data


def _v083_anchor_ts() -> float:  # type: ignore[override]
    return float_any(_v083_anchor().get("anchor_ts"), default=0.0)


def _v085_text_to_strategy_key(text: Any) -> str:
    s = str(text or "")
    if not s:
        return ""
    if s in STRATEGY_S_KEYS_V083:
        return s
    for label, key in _V085_STRATEGY_LABEL_TO_KEY.items():
        if label in s:
            return key
    return ""


def _v083_strategy_keys_from_row(row: Dict[str, Any]) -> List[str]:  # type: ignore[override]
    """CLOSED row에서 새 5전략 key를 최대한 복원한다.

    일부 row는 key 대신 '돈흐름 재가속 S' 같은 표시명만 갖고 있어서 v0.84 집계에서 빠졌다.
    """
    keys: List[str] = []
    if not isinstance(row, dict):
        return []
    ctx = row.get("entry_context") if isinstance(row.get("entry_context"), dict) else {}
    list_fields = [
        row.get("multi_strategy_s"), row.get("strategy_bucket_keys"), row.get("strategy_keys"),
        ctx.get("multi_strategy_s"), ctx.get("strategy_bucket_keys"), ctx.get("strategy_keys"),
    ]
    for vals in list_fields:
        if isinstance(vals, list):
            for x in vals:
                k = _v085_text_to_strategy_key(x)
                if k:
                    keys.append(k)
    scalar_fields = [
        row.get("paper_strategy_key"), row.get("strategy_bucket_primary"), row.get("strategy_key"), row.get("strategy"), row.get("strategy_name"), row.get("strategy_label"),
        ctx.get("paper_strategy_key"), ctx.get("strategy_bucket_primary"), ctx.get("strategy_key"), ctx.get("strategy"), ctx.get("strategy_name"), ctx.get("strategy_bucket_primary_label"),
    ]
    for v in scalar_fields:
        k = _v085_text_to_strategy_key(v)
        if k:
            keys.append(k)
    out: List[str] = []
    for k in keys:
        if k not in out:
            out.append(k)
    return out


def _v085_current_closed_rows_fast() -> List[Dict[str, Any]]:
    rows = _v077_read_jsonl_tail_fast(FILES["closed"], max(V077_CACHE_TAIL_LINES, 1200), max(V077_CACHE_TAIL_BYTES, 2_500_000))
    anchor_ts = _v083_anchor_ts()
    out: List[Dict[str, Any]] = []
    for r in rows:
        if not isinstance(r, dict):
            continue
        cts = float_any(r.get("closed_at"), default=0.0)
        ots = float_any(r.get("opened_at"), default=0.0)
        # OPEN이 이전판이어도 현재판에서 청산되면 현재판 CLOSED로 본다.
        if max(cts, ots) < anchor_ts:
            continue
        if _v083_strategy_keys_from_row(r):
            out.append(r)
    return out


def _v077_focus_rows_fast() -> List[Dict[str, Any]]:  # type: ignore[override]
    return _v085_current_closed_rows_fast()


def _v077_group_by_grade(rows: List[Dict[str, Any]]) -> Dict[str, List[Dict[str, Any]]]:  # type: ignore[override]
    out = {"S": [], "A": [], "B": [], "C": [], "X": []}
    for r in rows or []:
        g = _v071_grade_from_row(r) if '_v071_grade_from_row' in globals() else str(r.get("candidate_grade") or "").upper()
        if g not in out or g == "U":
            # 현재 paper는 S만 OPEN한다. grade가 누락된 구 row라도 새 5전략 S key가 있으면 S로 복원한다.
            g = "S" if _v083_strategy_keys_from_row(r) else "C"
        out.setdefault(g, []).append(r)
    return out


def _v077_strategy_stats(rows: List[Dict[str, Any]]) -> List[Dict[str, Any]]:  # type: ignore[override]
    buckets: Dict[str, List[Dict[str, Any]]] = {k: [] for k in STRATEGY_S_KEYS_V083}
    for r in rows or []:
        for k in _v083_strategy_keys_from_row(r):
            buckets.setdefault(k, []).append(r)
    out=[]
    for k,label in STRATEGY_S_KEYS_V083.items():
        d=_v077_short_stat(label, buckets.get(k, []))
        d["key"]=k
        d["label"]=label
        out.append(d)
    return out


def _v085_score_cache_valid(c: Dict[str, Any]) -> bool:
    if not isinstance(c, dict):
        return False
    if str(c.get("version") or "") != VERSION:
        return False
    if str(c.get("schema") or "") != "paper_score_cache_v085":
        return False
    if str(c.get("score_scope") or "") != "current_version_anchor":
        return False
    return c.get("current_closed_count") is not None


def _v077_build_score_cache(reason: str = "cycle") -> Dict[str, Any]:  # type: ignore[override]
    rows = _v085_current_closed_rows_fast()
    groups = _v077_group_by_grade(rows)
    auto = groups.get("S", []) + groups.get("A", [])
    paper = auto + groups.get("B", [])
    open_pos = load_open()
    status = load_json(FILES.get("status", BASE_DIR / "paper_bot_status.json"), {})
    anchor = _v083_anchor()
    cache = {
        "schema": "paper_score_cache_v085",
        "version": VERSION,
        "updated_at": now(),
        "updated_at_text": iso_ts(),
        "reason": reason,
        "score_scope": "current_version_anchor",
        "anchor_ts": anchor.get("anchor_ts"),
        "anchor_text": anchor.get("anchor_text"),
        "source_tail_lines": max(V077_CACHE_TAIL_LINES, 1200),
        "closed_file_size": FILES["closed"].stat().st_size if FILES["closed"].exists() else 0,
        "closed_total": closed_count(),
        "current_closed_count": len(rows),
        "open_total": len(open_pos),
        "open_grade_counts": _v074_open_grade_counts(open_pos) if '_v074_open_grade_counts' in globals() else {},
        "loop_seconds": load_control().get("loop_seconds"),
        "running": bool(load_control().get("running")),
        "pick_stats": status.get("pick_stats") if isinstance(status.get("pick_stats"), dict) else {},
        "grade_stats": {
            "S": _v077_short_stat("✅ S", groups.get("S", [])),
            "A": _v077_short_stat("✅ A", groups.get("A", [])),
            "B": _v077_short_stat("🟡 B", groups.get("B", [])),
            "C": _v077_short_stat("❔ C", groups.get("C", [])),
            "X": _v077_short_stat("❌ 제외", groups.get("X", [])),
            "AUTO": _v077_short_stat("S/A 자동매매 후보군", auto),
            "PAPER": _v077_short_stat("S/A OPEN + B/C 가상복기", paper),
            "ALL": _v077_short_stat("현재판 전체", rows),
        },
        "reason_stats": _v077_reason_stats(rows),
        "strategy_s_stats": _v077_strategy_stats(rows),
        "strategy_stats": _v077_strategy_stats(rows),
        "note": "v0.85: fast_monitor 청산 직후에도 현재판 CLOSED/전략별 S 전적 cache를 갱신한다.",
    }
    save_json(FILES["score_cache"], cache)
    return cache


def _v077_score_cache(allow_stale: bool = True) -> Dict[str, Any]:  # type: ignore[override]
    c = load_json(FILES["score_cache"], {})
    if _v085_score_cache_valid(c):
        # CLOSED 파일이 바뀌었는데 cache가 구파일 크기면 bounded tail로 즉시 갱신한다.
        try:
            size = FILES["closed"].stat().st_size if FILES["closed"].exists() else 0
            if int(c.get("closed_file_size") or 0) != int(size):
                c = _v077_build_score_cache("closed_file_changed_v085")
        except Exception:
            pass
        return c if _v085_score_cache_valid(c) else {}
    # 기본 명령에서 전체 장부 직접계산은 안 하지만, 현재판 tail cache 생성은 가볍게 허용한다.
    try:
        return _v077_build_score_cache("missing_or_old_cache_v085")
    except Exception as exc:
        log_error("v085_score_cache_build", exc)
        return {}


_v085_prev_monitor_open_positions = monitor_open_positions

def monitor_open_positions(control: Optional[Dict[str, Any]] = None) -> Dict[str, Any]:  # type: ignore[override]
    res = _v085_prev_monitor_open_positions(control)
    try:
        if isinstance(res, dict) and int(float_any(res.get("closed"), default=0)) > 0:
            _v077_build_score_cache("fast_monitor_closed_v085")
    except Exception as exc:
        log_error("v085_monitor_score_cache_update", exc)
    return res


_v085_prev_command_response = command_response

def command_response(text: str) -> str:  # type: ignore[override]
    cmd = (text or "").strip().split()[0].lower() if (text or "").strip().split() else ""
    if "@" in cmd:
        cmd = cmd.split("@", 1)[0]
    if cmd in {"/pstatus", "/pscore"}:
        # 명령 직전 cache가 없거나 CLOSED 파일 크기가 바뀌었으면 tail cache를 먼저 최신화한다.
        try:
            _v077_score_cache()
        except Exception as exc:
            log_error("v085_command_cache_refresh", exc)
    return _v085_prev_command_response(text)

# 시작 시에도 한 번 갱신한다. 실패해도 loop는 계속 돈다.
try:
    _v077_build_score_cache("startup_v085")
except Exception as exc:
    try:
        log_error("v085_startup_cache", exc)
    except Exception:
        pass


# =============================================================================
# paper_bot v0.86: 대표전략/중복태그 성과 분리 + pscore 직관화
# - v0.85는 한 거래가 여러 전략 태그를 갖고 있으면 전략별 합계가 CLOSED보다 커졌다.
# - v0.86은 대표전략 기준(실제 거래수와 일치)과 중복태그 포함(참고용)을 분리한다.
# =============================================================================
VERSION = "paper_bot_v0.86"


def _v086_primary_strategy_key(row: Dict[str, Any]) -> str:
    if not isinstance(row, dict):
        return ""
    ctx = row.get("entry_context") if isinstance(row.get("entry_context"), dict) else {}
    for v in (
        row.get("strategy_bucket_primary"), row.get("primary_strategy_key"), row.get("paper_strategy_key"), row.get("strategy_key"),
        ctx.get("strategy_bucket_primary"), ctx.get("primary_strategy_key"), ctx.get("paper_strategy_key"), ctx.get("strategy_key"),
        row.get("strategy_bucket_primary_label"), row.get("strategy"), row.get("strategy_name"),
        ctx.get("strategy_bucket_primary_label"), ctx.get("strategy"), ctx.get("strategy_name"),
    ):
        k = _v085_text_to_strategy_key(v)
        if k:
            return k
    keys = _v083_strategy_keys_from_row(row)
    return keys[0] if keys else ""


def _v086_strategy_stats_primary(rows: List[Dict[str, Any]]) -> List[Dict[str, Any]]:
    buckets: Dict[str, List[Dict[str, Any]]] = {k: [] for k in STRATEGY_S_KEYS_V083}
    unknown: List[Dict[str, Any]] = []
    for r in rows or []:
        k = _v086_primary_strategy_key(r)
        if k:
            buckets.setdefault(k, []).append(r)
        else:
            unknown.append(r)
    out: List[Dict[str, Any]] = []
    for k, label in STRATEGY_S_KEYS_V083.items():
        d = _v077_short_stat(label, buckets.get(k, [])); d["key"] = k; d["label"] = label; out.append(d)
    if unknown:
        d = _v077_short_stat("대표전략 미확인", unknown); d["key"] = "unknown"; d["label"] = "대표전략 미확인"; out.append(d)
    return out


def _v086_strategy_stats_overlap(rows: List[Dict[str, Any]]) -> List[Dict[str, Any]]:
    buckets: Dict[str, List[Dict[str, Any]]] = {k: [] for k in STRATEGY_S_KEYS_V083}
    for r in rows or []:
        for k in _v083_strategy_keys_from_row(r):
            buckets.setdefault(k, []).append(r)
    out: List[Dict[str, Any]] = []
    for k, label in STRATEGY_S_KEYS_V083.items():
        d = _v077_short_stat(label, buckets.get(k, [])); d["key"] = k; d["label"] = label; out.append(d)
    return out


def _v086_sum_n(stats: Any) -> int:
    if not isinstance(stats, list): return 0
    return sum(int(float_any(x.get("n", x.get("count", 0)), default=0)) for x in stats if isinstance(x, dict))


def _v085_score_cache_valid(c: Dict[str, Any]) -> bool:  # type: ignore[override]
    return isinstance(c, dict) and str(c.get("version") or "") == VERSION and str(c.get("schema") or "") == "paper_score_cache_v086" and str(c.get("score_scope") or "") == "current_version_anchor" and c.get("current_closed_count") is not None


def _v077_build_score_cache(reason: str = "cycle") -> Dict[str, Any]:  # type: ignore[override]
    rows = _v085_current_closed_rows_fast()
    groups = _v077_group_by_grade(rows)
    auto = groups.get("S", []) + groups.get("A", [])
    paper = auto + groups.get("B", [])
    open_pos = load_open()
    status = load_json(FILES.get("status", BASE_DIR / "paper_bot_status.json"), {})
    anchor = _v083_anchor()
    primary_stats = _v086_strategy_stats_primary(rows)
    overlap_stats = _v086_strategy_stats_overlap(rows)
    primary_total = _v086_sum_n(primary_stats)
    overlap_total = _v086_sum_n(overlap_stats)
    cache = {
        "schema": "paper_score_cache_v086", "version": VERSION, "updated_at": now(), "updated_at_text": iso_ts(), "reason": reason,
        "score_scope": "current_version_anchor", "anchor_ts": anchor.get("anchor_ts"), "anchor_text": anchor.get("anchor_text"),
        "source_tail_lines": max(V077_CACHE_TAIL_LINES, 1200),
        "closed_file_size": FILES["closed"].stat().st_size if FILES["closed"].exists() else 0,
        "closed_total": closed_count(), "current_closed_count": len(rows), "open_total": len(open_pos),
        "open_grade_counts": _v074_open_grade_counts(open_pos) if '_v074_open_grade_counts' in globals() else {},
        "loop_seconds": load_control().get("loop_seconds"), "running": bool(load_control().get("running")),
        "pick_stats": status.get("pick_stats") if isinstance(status.get("pick_stats"), dict) else {},
        "grade_stats": {
            "S": _v077_short_stat("✅ S", groups.get("S", [])), "A": _v077_short_stat("✅ A", groups.get("A", [])),
            "B": _v077_short_stat("🟡 B", groups.get("B", [])), "C": _v077_short_stat("❔ C", groups.get("C", [])),
            "X": _v077_short_stat("❌ 제외", groups.get("X", [])), "AUTO": _v077_short_stat("S/A 자동매매 후보군", auto),
            "PAPER": _v077_short_stat("S/A OPEN + B/C 가상복기", paper), "ALL": _v077_short_stat("현재판 전체", rows),
        },
        "reason_stats": _v077_reason_stats(rows),
        "strategy_primary_stats": primary_stats, "strategy_overlap_stats": overlap_stats,
        "strategy_s_stats": primary_stats, "strategy_stats": primary_stats,
        "strategy_primary_total": primary_total, "strategy_overlap_total": overlap_total,
        "strategy_duplicate_extra": max(0, overlap_total - len(rows)),
        "note": "v0.86: 대표전략 기준 성과와 중복태그 포함 성과를 분리한다.",
    }
    save_json(FILES["score_cache"], cache)
    return cache


def _v077_score_cache(allow_stale: bool = True) -> Dict[str, Any]:  # type: ignore[override]
    c = load_json(FILES["score_cache"], {})
    if _v085_score_cache_valid(c):
        try:
            size = FILES["closed"].stat().st_size if FILES["closed"].exists() else 0
            if int(c.get("closed_file_size") or 0) != int(size): c = _v077_build_score_cache("closed_file_changed_v086")
        except Exception: pass
        return c if _v085_score_cache_valid(c) else {}
    try: return _v077_build_score_cache("missing_or_old_cache_v086")
    except Exception as exc:
        log_error("v086_score_cache_build", exc); return {}


def _v086_strategy_lines(stats: Any) -> List[str]:
    if not isinstance(stats, list): stats = []
    smap = {str(x.get("key") or x.get("label") or ""): x for x in stats if isinstance(x, dict)}
    lines: List[str] = []
    for k, label in STRATEGY_S_KEYS_V083.items(): lines.append(_v084_stat_line(label, smap.get(k, {})))
    if "unknown" in smap: lines.append(_v084_stat_line("대표전략 미확인", smap.get("unknown", {})))
    return lines


def _v077_pscore_cached_text(compact: bool = True) -> str:  # type: ignore[override]
    c = _v077_score_cache()
    if not c: return _v084_cache_pending_text("pscore")
    gs = c.get("grade_stats") if isinstance(c.get("grade_stats"), dict) else {}
    current_n = int(float_any(c.get("current_closed_count"), default=0)); primary_total = int(float_any(c.get("strategy_primary_total"), default=0)); overlap_total = int(float_any(c.get("strategy_overlap_total"), default=0))
    lines = [
        f"📊 /pscore 요약 · 캐시전용 ({VERSION})",
        f"- 기준: 현재판 앵커 이후 / 전체 CLOSED {c.get('closed_total','-')}개 보존 / {_v080_cache_age_text(c)}",
        f"- 현재판 CLOSED {current_n}개 / 대표전략 집계 {primary_total}개 / 중복태그 참고합계 {overlap_total}개",
        "[등급별 현재판 성과]", _v084_stat_line("✅ S", gs.get("S", {})), _v084_stat_line("S/A 자동매매 후보군", gs.get("AUTO", {})), _v084_stat_line("현재판 전체", gs.get("ALL", {})),
        "", "[대표전략 기준 · 실제 거래수와 맞는 성과]",
    ]
    lines += _v086_strategy_lines(c.get("strategy_primary_stats"))
    lines += ["", "[중복태그 포함 · 참고용]"]
    lines += _v086_strategy_lines(c.get("strategy_overlap_stats"))
    extra = int(float_any(c.get("strategy_duplicate_extra"), default=max(0, overlap_total-current_n)))
    if extra: lines.append(f"- ⚠️ 중복태그 참고합계가 실제 CLOSED보다 {extra}개 많습니다. 전략 판단은 대표전략 기준을 우선 보세요.")
    lines.append("- 기본 /pscore는 현재 VERSION cache만 읽음. 전체 재계산은 /pscore_full")
    return "\n".join(lines)


def _v077_pstatus_cached_text(compact: bool = True) -> str:  # type: ignore[override]
    c = _v077_score_cache()
    if not c: return _v084_cache_pending_text("pstatus")
    hs = load_json(FILES.get("candidate_handoff_status", BASE_DIR / "paper_bot_candidate_handoff_status.json"), {})
    og = c.get("open_grade_counts") if isinstance(c.get("open_grade_counts"), dict) else {}; gs = c.get("grade_stats") if isinstance(c.get("grade_stats"), dict) else {}; pick = c.get("pick_stats") if isinstance(c.get("pick_stats"), dict) else {}; primary_total = int(float_any(c.get("strategy_primary_total"), default=0))
    lines = [
        f"🧪 /pstatus 요약 · 캐시전용 ({VERSION})",
        f"- 상태: {'ON' if c.get('running') else 'OFF'} / loop {c.get('loop_seconds','-')}s / OPEN {c.get('open_total',0)} / {_v080_cache_age_text(c)}",
        f"- OPEN: S {og.get('S',0)} / A {og.get('A',0)} / B {og.get('B',0)} / C {og.get('C',0)} / 제외 {og.get('X',0)} / 한도 고정없음",
        f"- 후보읽음: {pick.get('paper_file',0)} / S {pick.get('grade_s_seen',0)} / stale {pick.get('stale_skip',0)} / micro대기 {pick.get('micro_preopen_wait',0)} / 중복 {pick.get('dup_skip',0)}",
        f"- handoff: latest {hs.get('latest_lines','-')} / archive창 {hs.get('archive_window','-')} / 병합fresh {hs.get('merged_fresh','-')}",
        f"- 성과범위: 현재판 앵커 이후 / {c.get('anchor_text','-')} / CLOSED {c.get('current_closed_count',0)}개 / 대표전략 집계 {primary_total}개",
        "[현재판 성과]", _v084_stat_line("✅ S", gs.get("S", {})), _v084_stat_line("현재판 전체", gs.get("ALL", {})),
        f"- 재진입보호: 최근손실쿨다운 스킵 {pick.get('recent_loss_cooldown_skip',0)}", "- 전략별 상세는 /pscore. 기본 /pstatus는 현재 VERSION cache만 읽음.",
    ]
    return "\n".join(lines)


_v086_prev_monitor_open_positions = monitor_open_positions

def monitor_open_positions(control: Optional[Dict[str, Any]] = None) -> Dict[str, Any]:  # type: ignore[override]
    res = _v086_prev_monitor_open_positions(control)
    try:
        if isinstance(res, dict) and int(float_any(res.get("closed"), default=0)) > 0: _v077_build_score_cache("fast_monitor_closed_v086")
    except Exception as exc: log_error("v086_monitor_score_cache_update", exc)
    return res


_v086_prev_command_response = command_response

def command_response(text: str) -> str:  # type: ignore[override]
    cmd = (text or "").strip().split()[0].lower() if (text or "").strip().split() else ""
    if "@" in cmd: cmd = cmd.split("@", 1)[0]
    if cmd in {"/pstatus", "/pscore"}:
        try: _v077_score_cache()
        except Exception as exc: log_error("v086_command_cache_refresh", exc)
    return _v086_prev_command_response(text)

try: _v077_build_score_cache("startup_v086")
except Exception as exc:
    try: log_error("v086_startup_cache", exc)
    except Exception: pass



# =============================================================================
# paper_bot v0.87: entry_snapshot 표시/보존 강화
# - strategy_worker_v0.11의 entry_snapshot_v1을 OPEN/CLOSED/알림/popen에서 그대로 사용한다.
# - 조건 변경 없음. 장부/청산/자동매수 변경 없음.
# =============================================================================
VERSION = "paper_bot_v0.87"

# entry_context_from_event가 snapshot을 직접 보존하게 한다.
try:
    for _k in ["entry_snapshot", "entry_snapshot_schema", "entry_snapshot_version", "price_change_30s", "change_30s", "change_1m", "change_30m", "recent_high_gap_pct", "recent_low_gap_pct", "day_pos_pct", "relative_strength_pct", "relative_strength", "buy_ratio", "spread_pct", "bid_wall_ratio", "ask_wall_ratio", "sell_pressure", "slippage_est_pct", "micro_buy_ratio_sustain_1m"]:
        if _k not in ENTRY_CONTEXT_KEYS:
            ENTRY_CONTEXT_KEYS.append(_k)
except Exception:
    pass


def _v087_snapshot(ctx: Dict[str, Any]) -> Dict[str, Any]:
    if not isinstance(ctx, dict):
        return {}
    snap = ctx.get("entry_snapshot")
    return snap if isinstance(snap, dict) else {}


def _v087_snapshot_values(ctx: Dict[str, Any]) -> Dict[str, Any]:
    out: Dict[str, Any] = {}
    snap = _v087_snapshot(ctx)
    if not snap:
        return out
    if isinstance(snap.get("flat"), dict):
        out.update(snap.get("flat") or {})
    for group in ("price_flow", "position", "money_flow", "orderflow", "risk"):
        g = snap.get(group)
        if isinstance(g, dict):
            for k, v in g.items():
                out.setdefault(k, v)
    strat = snap.get("strategy")
    if isinstance(strat, dict):
        out.setdefault("strategy_bucket_primary", strat.get("primary_key"))
        out.setdefault("strategy_bucket_primary_label", strat.get("primary_label"))
        out.setdefault("final_entry_reasons", strat.get("reasons"))
    return out


def _v083_ctx_get(ctx: Dict[str, Any], *keys: str, default: Any = None) -> Any:  # type: ignore[override]
    if not isinstance(ctx, dict):
        return default
    snapv = None
    vals = _v087_snapshot_values(ctx)
    for k in keys:
        v = ctx.get(k)
        if v not in (None, "", "-"):
            return v
        if isinstance(vals, dict):
            snapv = vals.get(k)
            if snapv not in (None, "", "-"):
                return snapv
    return default


def _v087_fmt_bool(v: Any) -> str:
    if isinstance(v, bool):
        return "✅" if v else "❌"
    if str(v).lower() in {"1", "true", "yes", "ok", "fresh"}:
        return "✅"
    if str(v).lower() in {"0", "false", "no", "stale", "old"}:
        return "❌"
    return "-"


def _v083_reason_lines(ctx: Dict[str, Any]) -> List[str]:  # type: ignore[override]
    ch30s = _v083_ctx_get(ctx, "change_30s", "price_change_30s", default=None)
    ch1 = _v083_ctx_get(ctx, "change_1m", "price_change_1m", "change_1", default=None)
    ch3 = _v083_ctx_get(ctx, "change_3m", "price_change_3m", "change_3", default=None)
    ch5 = _v083_ctx_get(ctx, "change_5m", "price_change_5m", "change_5", default=None)
    ch15 = _v083_ctx_get(ctx, "change_15m", "price_change_15m", "change_15", default=None)
    ch30 = _v083_ctx_get(ctx, "change_30m", "price_change_30m", "change_30", default=None)
    vwap = _v083_ctx_get(ctx, "vwap_gap_pct", default=None)
    ema = _v083_ctx_get(ctx, "ema5_gap_pct", "ma5_gap_pct", default=None)
    high_gap = _v083_ctx_get(ctx, "recent_high_gap_pct", "below_high_pct", "below_30m_high_pct", default=None)
    low_gap = _v083_ctx_get(ctx, "recent_low_gap_pct", "from_low_pct", "from_30m_low_pct", default=None)
    day_pos = _v083_ctx_get(ctx, "day_pos_pct", "current_close_pos_ratio", default=None)
    rel = _v083_ctx_get(ctx, "relative_strength_pct", "relative_strength", default=None)
    turnover = _v083_ctx_get(ctx, "turnover_24h", default=None)
    vol_exp = _v083_ctx_get(ctx, "volume_expanding", default=None)
    price_react = _v083_ctx_get(ctx, "price_reaction_score", "price_recheck_pct", default=None)
    return [
        f"- 가격흐름 30초/1분/3분: {_v083_fmt_val(ch30s,2,'%')} / {_v083_fmt_val(ch1,2,'%')} / {_v083_fmt_val(ch3,2,'%')}",
        f"- 가격흐름 5분/15분/30분: {_v083_fmt_val(ch5,2,'%')} / {_v083_fmt_val(ch15,2,'%')} / {_v083_fmt_val(ch30,2,'%')}",
        f"- 위치 VWAP/EMA/고점/저점: {_v083_fmt_val(vwap,2,'%')} / {_v083_fmt_val(ema,2,'%')} / {_v083_fmt_val(high_gap,2,'%')} / {_v083_fmt_val(low_gap,2,'%')}",
        f"- 상대강도/거래대금/거래량확장: {_v083_fmt_val(rel,2)} / {fmt_money_krw_short(turnover)} / {_v087_fmt_bool(vol_exp)}",
        f"- 위치/반응: day {_v083_fmt_val(day_pos,1,'%')} / 가격반응 {_v083_fmt_val(price_react,2,'%')}",
    ]


def micro_summary_from_ctx(ctx: Dict[str, Any]) -> str:  # type: ignore[override]
    if not isinstance(ctx, dict):
        return "- 호가·체결: 정보없음"
    spread = _v083_ctx_get(ctx, "spread_pct", "micro_spread_pct", default=None)
    buy_ratio = _v083_ctx_get(ctx, "buy_ratio", "micro_buy_ratio", "micro_trade_buy_ratio_30", default=None)
    buy_sustain = _v083_ctx_get(ctx, "buy_ratio_1m", "micro_buy_ratio_sustain_1m", default=None)
    wall_ratio = _v083_ctx_get(ctx, "bid_wall_ratio", "micro_bid_ask_wall_ratio", default=None)
    ask_wall = _v083_ctx_get(ctx, "ask_wall_ratio", default=None)
    slip = _v083_ctx_get(ctx, "slippage_est_pct", "tick_pct_est", default=None)
    fresh = _v083_bool_fresh(ctx, "micro_fresh")
    row_status = _v083_ctx_get(ctx, "micro_row_status", "micro_pressure_label", default="-")
    flags = []
    if ctx.get("micro_ask_wall_pressure") or ctx.get("ask_wall_pressure") or _v083_ctx_get(ctx, "ask_wall_pressure", default=False):
        flags.append("매도벽 주의")
    if ctx.get("micro_sell_trade_pressure") or ctx.get("sell_trade_pressure") or _v083_ctx_get(ctx, "sell_trade_pressure", default=False):
        flags.append("매도체결 우세")
    if _v083_ctx_get(ctx, "sell_pressure", default=False):
        flags.append("매도압력")
    if not flags:
        flags.append("특이압박 없음")
    return (
        f"- 호가·체결: {yes_fresh(fresh)} / 상태 {row_status}\n"
        f"  · 스프레드 {_v083_fmt_val(spread,2,'%')} / 매수체결 {_v083_fmt_val(buy_ratio,2)} / 지속 {_v083_fmt_val(buy_sustain,2)}\n"
        f"  · 매수벽 {_v083_fmt_val(wall_ratio,2)} / 매도벽 {_v083_fmt_val(ask_wall,2)} / 예상슬리피지 {_v083_fmt_val(slip,3,'%')}\n"
        f"  · {' / '.join(flags[:4])}"
    )


def _v084_open_reason_summary(pos: Dict[str, Any]) -> str:  # type: ignore[override]
    ctx = pos.get("entry_context") if isinstance(pos.get("entry_context"), dict) else {}
    txt = _v084_list_text(pos.get("final_entry_reasons") or ctx.get("final_entry_reasons") or ctx.get("reasons") or pos.get("reasons"), 3)
    vals = []
    ch3 = _v083_ctx_get(ctx, "change_3m", "price_change_3m", default=None)
    ch5 = _v083_ctx_get(ctx, "change_5m", "price_change_5m", default=None)
    vwap = _v083_ctx_get(ctx, "vwap_gap_pct", default=None)
    ema = _v083_ctx_get(ctx, "ema5_gap_pct", default=None)
    buy = _v083_ctx_get(ctx, "buy_ratio", "micro_buy_ratio", "micro_trade_buy_ratio_30", default=None)
    rel = _v083_ctx_get(ctx, "relative_strength_pct", "relative_strength", default=None)
    if txt:
        vals.append(txt)
    if ch3 not in (None, "", "-") or ch5 not in (None, "", "-"):
        vals.append(f"3/5분 {_v083_fmt_val(ch3,2,'%')}/{_v083_fmt_val(ch5,2,'%')}")
    if vwap not in (None, "", "-") or ema not in (None, "", "-"):
        vals.append(f"VWAP/EMA {_v083_fmt_val(vwap,2,'%')}/{_v083_fmt_val(ema,2,'%')}")
    if buy not in (None, "", "-"):
        vals.append(f"매수체결 {_v083_fmt_val(buy,2)}")
    if rel not in (None, "", "-"):
        vals.append(f"상대강도 {_v083_fmt_val(rel,2)}")
    return " / ".join(vals[:4]) if vals else "근거값 미저장(구 OPEN 또는 후보 원본 누락)"


_v087_prev_open_position = open_position

def open_position(pos_id: str, ev: Dict[str, Any], control: Dict[str, Any]) -> Dict[str, Any]:  # type: ignore[override]
    pos = _v087_prev_open_position(pos_id, ev, control)
    try:
        ctx = pos.get("entry_context") if isinstance(pos.get("entry_context"), dict) else {}
        snap = ev.get("entry_snapshot") if isinstance(ev.get("entry_snapshot"), dict) else ctx.get("entry_snapshot") if isinstance(ctx.get("entry_snapshot"), dict) else {}
        if snap:
            ctx["entry_snapshot"] = snap
            ctx["entry_snapshot_schema"] = snap.get("schema")
            flat = snap.get("flat") if isinstance(snap.get("flat"), dict) else {}
            for k, v in flat.items():
                if v not in (None, "", "-") and ctx.get(k) in (None, "", "-"):
                    ctx[k] = v
            pos["entry_context"] = ctx
            pos["entry_snapshot_schema"] = snap.get("schema")
    except Exception as exc:
        try: log_error("v087_open_snapshot_preserve", exc)
        except Exception: pass
    return pos

try:
    _v077_build_score_cache("startup_v087")
except Exception as exc:
    try: log_error("v087_startup_cache", exc)
    except Exception: pass



# =============================================================================
# paper_bot v0.88: 손실/놓친후보 복기판
# - 조건 추가 전, 현재판 CLOSED와 후보 archive에서 공통 패배/놓친 상승 후보를 본다.
# - 장부/청산/자동매수/전략조건 변경 없음.
# =============================================================================
VERSION = "paper_bot_v0.88"


def _v088_strategy_key(row: Dict[str, Any]) -> str:
    try:
        keys = _v083_strategy_keys_from_row(row)
        if keys:
            return keys[0]
    except Exception:
        pass
    return "unknown"


def _v088_strategy_label(key: str) -> str:
    try:
        return STRATEGY_S_KEYS_V083.get(key, key)
    except Exception:
        return key


def _v088_ctx(row: Dict[str, Any]) -> Dict[str, Any]:
    ctx = row.get("entry_context") if isinstance(row.get("entry_context"), dict) else {}
    snap = ctx.get("entry_snapshot") if isinstance(ctx.get("entry_snapshot"), dict) else row.get("entry_snapshot") if isinstance(row.get("entry_snapshot"), dict) else {}
    vals: Dict[str, Any] = {}
    if isinstance(snap, dict):
        if isinstance(snap.get("flat"), dict):
            vals.update(snap.get("flat") or {})
        for group in ("price_flow", "position", "money_flow", "orderflow", "risk"):
            g = snap.get(group)
            if isinstance(g, dict):
                vals.update({k: v for k, v in g.items() if k not in vals})
    vals.update({k: v for k, v in ctx.items() if k not in vals})
    return vals


def _v088_loss_causes(row: Dict[str, Any]) -> List[str]:
    causes: List[str] = []
    ctx = _v088_ctx(row)
    pnl = float_any(row.get("pnl_pct"), default=0.0)
    peak = float_any(row.get("peak_pct"), default=0.0)
    trough = float_any(row.get("trough_pct"), default=0.0)
    hold = float_any(row.get("hold_sec"), default=float_any(row.get("age_min"), default=0.0) * 60)
    spread = float_any(ctx.get("spread_pct"), default=-1.0)
    buy = float_any(ctx.get("buy_ratio"), ctx.get("micro_trade_buy_ratio_30"), default=-1.0)
    buy_sustain = float_any(ctx.get("buy_ratio_1m"), ctx.get("micro_buy_ratio_sustain_1m"), default=-1.0)
    vwap = float_any(ctx.get("vwap_gap_pct"), default=999.0)
    ema = float_any(ctx.get("ema5_gap_pct"), default=999.0)
    ch3 = float_any(ctx.get("change_3m"), ctx.get("price_change_3m"), default=999.0)
    ch5 = float_any(ctx.get("change_5m"), ctx.get("price_change_5m"), default=999.0)
    if pnl < 0:
        if peak <= 0.10:
            causes.append("진입후반응없음(최고+0.1%이하)")
        elif peak <= 0.30:
            causes.append("반응약함(최고+0.3%이하)")
        if hold <= 180:
            causes.append("초반빠른손실(3분이내)")
        if trough <= -0.70:
            causes.append("깊은역행")
    if spread >= 0.28:
        causes.append("스프레드넓음")
    if 0 <= buy < 0.65:
        causes.append("매수체결약함")
    if 0 <= buy_sustain < 0.60:
        causes.append("매수체결지속약함")
    if ctx.get("sell_pressure") or ctx.get("ask_wall_pressure") or ctx.get("sell_trade_pressure"):
        causes.append("매도압력")
    if vwap != 999.0 and vwap < -0.15:
        causes.append("VWAP아래")
    if ema != 999.0 and ema < -0.20:
        causes.append("EMA아래")
    if ch3 != 999.0 and ch5 != 999.0 and ch3 <= 0.05 and ch5 <= 0.10:
        causes.append("가격반응부족")
    if not ctx or not any(k in ctx for k in ("change_3m", "vwap_gap_pct", "buy_ratio", "spread_pct")):
        causes.append("근거스냅샷부족")
    if not causes and pnl < 0:
        causes.append("기타손실")
    return causes


def _v088_short_stat(rows: List[Dict[str, Any]]) -> str:
    st = _v077_short_stat("", rows) if '_v077_short_stat' in globals() else score_stats(rows)
    return f"{int(float_any(st.get('n'), default=len(rows)))}전 {int(float_any(st.get('wins'), default=0))}승 {int(float_any(st.get('losses'), default=0))}패 / 승률 {float_any(st.get('win_rate'), default=0):.1f}% / 합산 {float_any(st.get('total'), default=0):+.2f}% / 평균 {float_any(st.get('avg'), default=0):+.2f}%"


def _v088_loss_review_text() -> str:
    rows = _v085_current_closed_rows_fast() if '_v085_current_closed_rows_fast' in globals() else rows_since_baseline(read_jsonl(FILES["closed"], max_lines=1500), "closed_at")
    losses = [r for r in rows if float_any(r.get("pnl_pct"), default=0.0) < 0]
    wins = [r for r in rows if float_any(r.get("pnl_pct"), default=0.0) > 0]
    cause_counter: Counter[str] = Counter()
    by_strategy: Dict[str, List[Dict[str, Any]]] = {}
    strategy_causes: Dict[str, Counter[str]] = {}
    for r in losses:
        k = _v088_strategy_key(r)
        by_strategy.setdefault(k, []).append(r)
        strategy_causes.setdefault(k, Counter())
        for c in _v088_loss_causes(r):
            cause_counter[c] += 1
            strategy_causes[k][c] += 1
    lines = [
        "🧯 손실 원인 복기 /ploss_review",
        "- 조건을 바로 조이기 전에, 현재판 CLOSED 손실에서 공통 패배 패턴을 봅니다.",
        f"- 현재판 CLOSED {len(rows)}개 / 승리 {len(wins)}개 / 손실 {len(losses)}개",
        "",
        "[공통 손실 TOP]",
    ]
    if cause_counter:
        for k, v in cause_counter.most_common(10):
            lines.append(f"- ⚠️ {k}: {v}개")
    else:
        lines.append("- 아직 손실 표본 없음")
    lines += ["", "[전략별 손실 원인]"]
    for sk in STRATEGY_S_KEYS_V083:
        sub = by_strategy.get(sk, [])
        if not sub:
            lines.append(f"- {_v088_strategy_label(sk)}: 손실 0개")
            continue
        tops = ", ".join(f"{k} {v}" for k, v in strategy_causes.get(sk, Counter()).most_common(3)) or "-"
        lines.append(f"- {_v088_strategy_label(sk)}: 손실 {len(sub)}개 / {tops}")
    lines += ["", "[조건 설계 힌트]"]
    if cause_counter.get("진입후반응없음(최고+0.1%이하)", 0) >= max(3, len(losses)*0.25):
        lines.append("- 진입 전/직후 가격반응 조건을 전략별로 넣을 가치가 큼")
    if cause_counter.get("매수체결약함", 0) or cause_counter.get("매수체결지속약함", 0):
        lines.append("- 매수체결 순간값보다 지속성 조건을 봐야 함")
    if cause_counter.get("매도압력", 0):
        lines.append("- 매도벽/매도체결압력은 공통 하드차단이 아니라 전략별 강도 조절이 필요")
    if cause_counter.get("근거스냅샷부족", 0):
        lines.append("- 일부 구 OPEN/CLOSED는 snapshot 부족. v0.88 이후 신규 CLOSED를 더 신뢰")
    return "\n".join(lines)


def _v088_market_rows() -> Dict[str, Dict[str, Any]]:
    candidates = [BASE_DIR / "clean_scanner_market_cache.json", BASE_DIR / "clean_feature_cache.json"]
    out: Dict[str, Dict[str, Any]] = {}
    for p in candidates:
        obj = load_json(p, {})
        rows = []
        if isinstance(obj, dict):
            if isinstance(obj.get("rows"), list): rows = obj.get("rows")
            elif isinstance(obj.get("items"), list): rows = obj.get("items")
            elif isinstance(obj.get("cache"), dict):
                for k, v in obj.get("cache", {}).items():
                    if isinstance(v, dict):
                        vv = dict(v); vv.setdefault("ticker", k); rows.append(vv)
        elif isinstance(obj, list): rows = obj
        for r in rows or []:
            if isinstance(r, dict):
                t = str(r.get("ticker") or r.get("symbol") or r.get("market") or "").upper().replace("KRW-", "").replace("_KRW", "").replace("KRW", "")
                if t: out[t] = r
    return out


def _v088_candidate_event_id(ev: Dict[str, Any]) -> str:
    return str(ev.get("event_id") or ev.get("event_key") or ev.get("id") or "")


def _v088_missed_review_text() -> str:
    anchor_ts = _v083_anchor_ts() if '_v083_anchor_ts' in globals() else 0.0
    events = read_jsonl(FILES["paper_candidates"], max_lines=900) + read_jsonl(FILES["paper_latest"], max_lines=120)
    open_pos = load_open()
    open_tickers = {str((p or {}).get("ticker") or "").upper() for p in open_pos.values() if isinstance(p, dict)}
    closed_rows = _v085_current_closed_rows_fast() if '_v085_current_closed_rows_fast' in globals() else []
    closed_ids = {str(r.get("event_id") or (r.get("source_event") or {}).get("event_id") or "") for r in closed_rows if isinstance(r, dict)}
    market = _v088_market_rows()
    seen = set(); missed=[]; watched=0
    for ev in events:
        if not isinstance(ev, dict):
            continue
        ts = float_any(ev.get("created_at"), ev.get("candidate_created_at"), ev.get("detected_ts"), default=0.0)
        if anchor_ts and ts and ts < anchor_ts:
            continue
        t = str(ev.get("ticker") or ev.get("symbol") or "").upper().replace("_KRW", "").replace("KRW-", "")
        if not t or t in seen:
            continue
        seen.add(t); watched += 1
        eid = _v088_candidate_event_id(ev)
        if t in open_tickers or (eid and eid in closed_ids):
            continue
        cur = market.get(t, {})
        cur_price = float_any(cur.get("current_price"), cur.get("price"), cur.get("trade_price"), default=0.0)
        entry = float_any(ev.get("entry_price"), ev.get("current_price"), ev.get("detected_price"), default=0.0)
        if cur_price <= 0 or entry <= 0:
            continue
        gain = (cur_price - entry) / entry * 100.0
        if gain >= 0.70:
            missed.append({"ticker": t, "gain": gain, "entry": entry, "current": cur_price, "strategy": ev.get("strategy_bucket_primary_label") or ev.get("strategy_name") or ev.get("strategy"), "score": ev.get("score"), "reasons": ev.get("reasons") or ev.get("final_entry_reasons") or []})
    missed.sort(key=lambda x: x.get("gain", 0), reverse=True)
    lines = [
        "🔎 놓친 후보 복기 /pmissed_review",
        "- 버린 후보가 아니라, 후보 archive/latest 중 OPEN/CLOSED로 이어지지 않았는데 이후 오른 코인을 봅니다.",
        f"- 확인 후보 {watched}개 / 현재가 비교 가능 상승후보 {len(missed)}개",
        "",
        "[이후 오른 후보 TOP]",
    ]
    if missed:
        for m in missed[:10]:
            rs = m.get("reasons") if isinstance(m.get("reasons"), list) else []
            lines.append(f"- {'⚠️' if m['gain']>=1.5 else '❔'} {m['ticker']} / +{m['gain']:.2f}% / {m.get('strategy','-')} / 점수 {m.get('score','-')} / 근거 {', '.join(map(str, rs[:3]))}")
    else:
        lines.append("- 아직 뚜렷한 놓친 상승후보 없음")
    lines += ["", "[판독]", "- 여기서 자주 오르는 패턴은 조건에서 죽이면 안 됨", "- 손실필터를 넣을 때 /ploss_review와 같이 봐야 함"]
    return "\n".join(lines)


_v088_prev_command_response = command_response

def command_response(text: str) -> str:  # type: ignore[override]
    cmd = (text or "").strip().split()[0].lower() if (text or "").strip().split() else ""
    if "@" in cmd:
        cmd = cmd.split("@", 1)[0]
    if cmd in {"/ploss_review", "/ploss", "/loss_review"}:
        return _v088_loss_review_text()
    if cmd in {"/pmissed_review", "/pmissed", "/missed_review"}:
        return _v088_missed_review_text()
    if cmd in {"/preview", "/precap"}:
        return _v088_loss_review_text() + "\n\n" + _v088_missed_review_text()
    if cmd in {"/phelp", "/start"}:
        base = _v088_prev_command_response(text)
        if "/ploss_review" not in base:
            base += "\n복기: /ploss_review /pmissed_review /preview"
        return base
    return _v088_prev_command_response(text)

try:
    _v077_build_score_cache("startup_v088")
except Exception as exc:
    try: log_error("v088_startup_cache", exc)
    except Exception: pass


# =============================================================================
# paper_bot v0.89: loss/missed review 매핑 보강
# - 전략별 손실 원인이 /pscore 대표전략 집계와 맞도록 key/label/snapshot 매핑을 확장한다.
# - 놓친 후보에는 단순 상승률뿐 아니라 왜 OPEN/CLOSED로 이어지지 않았는지 추정 이유를 붙인다.
# - 장부/청산/전략조건 변경 없음.
# =============================================================================
VERSION = "paper_bot_v0.89"

_V089_LABEL_TO_KEY = {v: k for k, v in STRATEGY_S_KEYS_V083.items()}
_V089_LABEL_TO_KEY.update({(v + " S"): k for k, v in STRATEGY_S_KEYS_V083.items()})

def _v089_text_to_key(v: Any) -> str:
    s = str(v or "")
    if not s:
        return ""
    if s in STRATEGY_S_KEYS_V083:
        return s
    for label, key in _V089_LABEL_TO_KEY.items():
        if label and label in s:
            return key
    return ""


def _v089_snapshot(row: Dict[str, Any]) -> Dict[str, Any]:
    ctx = row.get("entry_context") if isinstance(row.get("entry_context"), dict) else {}
    snap = row.get("entry_snapshot") if isinstance(row.get("entry_snapshot"), dict) else ctx.get("entry_snapshot") if isinstance(ctx.get("entry_snapshot"), dict) else {}
    return snap if isinstance(snap, dict) else {}


def _v089_strategy_keys_from_row(row: Dict[str, Any], overlap: bool = True) -> List[str]:
    keys: List[str] = []
    if not isinstance(row, dict):
        return []
    ctx = row.get("entry_context") if isinstance(row.get("entry_context"), dict) else {}
    snap = _v089_snapshot(row)
    strat = snap.get("strategy") if isinstance(snap.get("strategy"), dict) else {}
    list_fields = [
        row.get("multi_strategy_s"), row.get("strategy_bucket_keys"), row.get("strategy_keys"), row.get("strategy_bucket_labels"),
        ctx.get("multi_strategy_s"), ctx.get("strategy_bucket_keys"), ctx.get("strategy_keys"), ctx.get("strategy_bucket_labels"),
    ]
    if overlap:
        for vals in list_fields:
            if isinstance(vals, list):
                for x in vals:
                    k = _v089_text_to_key(x)
                    if k:
                        keys.append(k)
    scalar_fields = [
        row.get("representative_strategy_key"), row.get("primary_strategy_key"), row.get("paper_strategy_key"), row.get("strategy_bucket_primary"), row.get("strategy_key"),
        row.get("strategy"), row.get("strategy_name"), row.get("strategy_label"), row.get("strategy_bucket_primary_label"),
        ctx.get("representative_strategy_key"), ctx.get("primary_strategy_key"), ctx.get("paper_strategy_key"), ctx.get("strategy_bucket_primary"), ctx.get("strategy_key"),
        ctx.get("strategy"), ctx.get("strategy_name"), ctx.get("strategy_bucket_primary_label"),
        strat.get("primary_key"), strat.get("primary_label"),
    ]
    for v in scalar_fields:
        k = _v089_text_to_key(v)
        if k:
            keys.append(k)
            if not overlap:
                break
    out: List[str] = []
    for k in keys:
        if k not in out:
            out.append(k)
    return out


def _v088_strategy_key(row: Dict[str, Any]) -> str:  # type: ignore[override]
    keys = _v089_strategy_keys_from_row(row, overlap=False)
    return keys[0] if keys else "unknown"


def _v088_loss_review_text() -> str:  # type: ignore[override]
    rows = _v085_current_closed_rows_fast() if '_v085_current_closed_rows_fast' in globals() else rows_since_baseline(read_jsonl(FILES["closed"], max_lines=1500), "closed_at")
    losses = [r for r in rows if float_any(r.get("pnl_pct"), default=0.0) < 0]
    wins = [r for r in rows if float_any(r.get("pnl_pct"), default=0.0) > 0]
    cause_counter: Counter[str] = Counter()
    by_strategy: Dict[str, List[Dict[str, Any]]] = {k: [] for k in STRATEGY_S_KEYS_V083}
    strategy_causes: Dict[str, Counter[str]] = {k: Counter() for k in STRATEGY_S_KEYS_V083}
    unknown_losses = 0
    for r in losses:
        k = _v088_strategy_key(r)
        if k not in STRATEGY_S_KEYS_V083:
            unknown_losses += 1
            k = "unknown"
        by_strategy.setdefault(k, []).append(r)
        strategy_causes.setdefault(k, Counter())
        for c in _v088_loss_causes(r):
            cause_counter[c] += 1
            strategy_causes[k][c] += 1
    lines = [
        "🧯 손실 원인 복기 /ploss_review",
        "- 조건을 바로 조이기 전에, 현재판 CLOSED 손실에서 공통 패배 패턴을 봅니다.",
        f"- 현재판 CLOSED {len(rows)}개 / 승리 {len(wins)}개 / 손실 {len(losses)}개 / 미분류손실 {unknown_losses}개",
        "",
        "[공통 손실 TOP]",
    ]
    if cause_counter:
        for k, v in cause_counter.most_common(10):
            lines.append(f"- ⚠️ {k}: {v}개")
    else:
        lines.append("- 아직 손실 표본 없음")
    lines += ["", "[전략별 손실 원인 · 대표전략 기준]"]
    for sk, label in STRATEGY_S_KEYS_V083.items():
        sub = by_strategy.get(sk, [])
        tops = ", ".join(f"{k} {v}" for k, v in strategy_causes.get(sk, Counter()).most_common(3)) or "-"
        lines.append(f"- {label}: 손실 {len(sub)}개 / {tops}")
    if unknown_losses:
        tops = ", ".join(f"{k} {v}" for k, v in strategy_causes.get("unknown", Counter()).most_common(3)) or "-"
        lines.append(f"- 미분류: 손실 {unknown_losses}개 / {tops}")
    lines += ["", "[조건 설계 힌트]"]
    if cause_counter.get("진입후반응없음(최고+0.1%이하)", 0) >= max(3, len(losses)*0.25):
        lines.append("- 진입 전/직후 가격반응 조건을 전략별로 넣을 가치가 큼")
    if cause_counter.get("매수체결약함", 0) or cause_counter.get("매수체결지속약함", 0):
        lines.append("- 매수체결 순간값보다 지속성 조건을 봐야 함")
    if cause_counter.get("매도압력", 0):
        lines.append("- 매도벽/매도체결압력은 공통 하드차단이 아니라 전략별 강도 조절이 필요")
    if cause_counter.get("근거스냅샷부족", 0):
        lines.append("- 일부 구 OPEN/CLOSED는 snapshot 부족. v0.89 이후 신규 CLOSED를 더 신뢰")
    return "\n".join(lines)


def _v089_missed_reason(ev: Dict[str, Any], nowv: Optional[float] = None) -> str:
    nowv = nowv or now()
    reasons: List[str] = []
    exp = float_any(ev.get("expires_at"), default=0.0)
    created = float_any(ev.get("created_at"), ev.get("candidate_created_at"), ev.get("detected_ts"), default=0.0)
    if exp and exp < nowv:
        reasons.append("handoff만료")
    if created and nowv - created > 180:
        reasons.append("후보오래됨")
    if not (ev.get("micro_fresh") or (isinstance(ev.get("entry_context"), dict) and ev.get("entry_context", {}).get("micro_fresh"))):
        reasons.append("micro미확인")
    if ev.get("stale") or ev.get("is_stale"):
        reasons.append("stale")
    if ev.get("open_eligible") is False or ev.get("paper_bot_open") is False:
        reasons.append("open_eligible_false")
    if not _v088_candidate_event_id(ev):
        reasons.append("event_id없음")
    if not reasons:
        reasons.append("paper미병합/만료확인")
    return ",".join(reasons[:4])


def _v088_missed_review_text() -> str:  # type: ignore[override]
    anchor_ts = _v083_anchor_ts() if '_v083_anchor_ts' in globals() else 0.0
    events = read_jsonl(FILES["paper_candidates"], max_lines=900) + read_jsonl(FILES["paper_latest"], max_lines=120)
    open_pos = load_open()
    open_tickers = {str((p or {}).get("ticker") or "").upper() for p in open_pos.values() if isinstance(p, dict)}
    closed_rows = _v085_current_closed_rows_fast() if '_v085_current_closed_rows_fast' in globals() else []
    closed_ids = {str(r.get("event_id") or (r.get("source_event") or {}).get("event_id") or "") for r in closed_rows if isinstance(r, dict)}
    market = _v088_market_rows()
    seen = set(); missed=[]; watched=0; reason_counter: Counter[str] = Counter()
    nowv = now()
    for ev in events:
        if not isinstance(ev, dict):
            continue
        ts = float_any(ev.get("created_at"), ev.get("candidate_created_at"), ev.get("detected_ts"), default=0.0)
        if anchor_ts and ts and ts < anchor_ts:
            continue
        t = str(ev.get("ticker") or ev.get("symbol") or "").upper().replace("_KRW", "").replace("KRW-", "")
        if not t or t in seen:
            continue
        seen.add(t); watched += 1
        eid = _v088_candidate_event_id(ev)
        if t in open_tickers or (eid and eid in closed_ids):
            continue
        cur = market.get(t, {})
        cur_price = float_any(cur.get("current_price"), cur.get("price"), cur.get("trade_price"), default=0.0)
        entry = float_any(ev.get("entry_price"), ev.get("current_price"), ev.get("detected_price"), default=0.0)
        if cur_price <= 0 or entry <= 0:
            continue
        gain = (cur_price - entry) / entry * 100.0
        if gain >= 0.70:
            reason = _v089_missed_reason(ev, nowv)
            for r in reason.split(','):
                if r:
                    reason_counter[r] += 1
            missed.append({"ticker": t, "gain": gain, "entry": entry, "current": cur_price, "strategy": ev.get("strategy_bucket_primary_label") or ev.get("strategy_name") or ev.get("strategy"), "score": ev.get("score"), "reasons": ev.get("reasons") or ev.get("final_entry_reasons") or [], "missed_reason": reason})
    missed.sort(key=lambda x: x.get("gain", 0), reverse=True)
    lines = [
        "🔎 놓친 후보 복기 /pmissed_review",
        "- 후보 archive/latest 중 OPEN/CLOSED로 이어지지 않았는데 이후 오른 코인을 봅니다.",
        f"- 확인 후보 {watched}개 / 현재가 비교 가능 상승후보 {len(missed)}개",
        "",
        "[놓친 이유 추정 TOP]",
    ]
    if reason_counter:
        for k, v in reason_counter.most_common(8):
            lines.append(f"- ❔ {k}: {v}개")
    else:
        lines.append("- 아직 분류할 상승후보 없음")
    lines += ["", "[이후 오른 후보 TOP]"]
    if missed:
        for m in missed[:10]:
            rs = m.get("reasons") if isinstance(m.get("reasons"), list) else []
            lines.append(f"- {'⚠️' if m['gain']>=1.5 else '❔'} {m['ticker']} / +{m['gain']:.2f}% / {m.get('strategy','-')} / 점수 {m.get('score','-')} / 놓친이유 {m.get('missed_reason','-')} / 근거 {', '.join(map(str, rs[:3]))}")
    else:
        lines.append("- 아직 뚜렷한 놓친 상승후보 없음")
    lines += ["", "[판독]", "- 자주 오르는 패턴은 조건에서 죽이면 안 됨", "- handoff만료/후보오래됨이 많으면 조건 문제가 아니라 진입 타이밍·병합 문제를 먼저 봐야 함", "- 손실필터를 넣을 때 /ploss_review와 같이 봐야 함"]
    return "\n".join(lines)

try:
    _v077_build_score_cache("startup_v089")
except Exception as exc:
    try: log_error("v089_startup_cache", exc)
    except Exception: pass



# =============================================================================
# paper_bot v0.90: candidate trace / missed reason 단일화
# - event_id가 없는 구 후보는 fallback trace_id로 보정하되, 신규 후보는 event_id가 반드시 이어지게 한다.
# - 놓친 후보 이유를 handoff/TTL/micro/OPEN/CLOSED 매칭 기준으로 더 세분화한다.
# - 전략조건/청산/장부 삭제 없음.
# =============================================================================
VERSION = "paper_bot_v0.90"
try:
    FILES["candidate_handoff_trace"] = BASE_DIR / "paper_bot_candidate_handoff_trace.json"
except Exception:
    pass


def _v090_event_ts(ev: Dict[str, Any]) -> float:
    return float_any((ev or {}).get("candidate_created_at"), (ev or {}).get("source_created_at"), (ev or {}).get("detected_ts"), (ev or {}).get("event_ts"), (ev or {}).get("created_at"), default=0.0)


def _v090_strategy_key(ev: Dict[str, Any]) -> str:
    source = (ev or {}).get("source_event") if isinstance((ev or {}).get("source_event"), dict) else {}
    ctx = (ev or {}).get("entry_context") if isinstance((ev or {}).get("entry_context"), dict) else {}
    snap = (ev or {}).get("entry_snapshot") if isinstance((ev or {}).get("entry_snapshot"), dict) else ctx.get("entry_snapshot") if isinstance(ctx.get("entry_snapshot"), dict) else {}
    strat = snap.get("strategy") if isinstance(snap.get("strategy"), dict) else {}
    return str((ev or {}).get("strategy_key") or (ev or {}).get("strategy_bucket_primary") or (ev or {}).get("paper_strategy_key") or source.get("strategy_key") or source.get("strategy_bucket_primary") or ctx.get("strategy_key") or ctx.get("strategy_bucket_primary") or strat.get("primary_key") or "strategy_s")


def _v090_fallback_event_id(ev: Dict[str, Any]) -> str:
    t = normalize_ticker((ev or {}).get("ticker") or (ev or {}).get("market") or (ev or {}).get("symbol")) or "UNKNOWN"
    sk = _v090_strategy_key(ev)
    ts = _v090_event_ts(ev) or now()
    return f"ev:{t}:{sk}:{int(ts // 30)}"

_v090_prev_normalize_candidate = _v080_normalize_candidate

def _v080_normalize_candidate(ev: Dict[str, Any], control: Optional[Dict[str, Any]] = None) -> Dict[str, Any]:  # type: ignore[override]
    raw_has_id = bool((ev or {}).get("event_id") or (ev or {}).get("event_key") or (ev or {}).get("id"))
    row = _v090_prev_normalize_candidate(ev, control)
    eid = str(row.get("event_id") or row.get("event_key") or "")
    if not eid:
        eid = _v090_fallback_event_id(row)
        row["event_id_origin"] = "v090_fallback"
    elif not raw_has_id:
        # _v080_normalize_candidate가 생성한 구 fallback ID도 추적 가능하게 표시한다.
        row.setdefault("event_id_origin", "legacy_fallback")
    else:
        row.setdefault("event_id_origin", "strategy")
    row["event_id"] = eid
    row["event_key"] = eid
    row["trace_id"] = row.get("trace_id") or eid
    row["handoff_id"] = row.get("handoff_id") or eid
    row["candidate_uid"] = row.get("candidate_uid") or eid
    ctx = row.get("entry_context") if isinstance(row.get("entry_context"), dict) else {}
    ctx.update({"event_id": eid, "event_key": eid, "trace_id": row["trace_id"], "handoff_id": row["handoff_id"]})
    row["entry_context"] = ctx
    snap = row.get("entry_snapshot") if isinstance(row.get("entry_snapshot"), dict) else ctx.get("entry_snapshot") if isinstance(ctx.get("entry_snapshot"), dict) else None
    if isinstance(snap, dict):
        snap["event_id"] = eid
        snap["trace_id"] = row["trace_id"]
        snap["handoff_id"] = row["handoff_id"]
        row["entry_snapshot"] = snap
    return row


def _v088_candidate_event_id(ev: Dict[str, Any]) -> str:  # type: ignore[override]
    return str(_v080_normalize_candidate(ev).get("event_id") or _v090_fallback_event_id(ev))


def _v090_match_keys(ev: Dict[str, Any]) -> set[str]:
    row = _v080_normalize_candidate(ev)
    keys = set()
    for k in ("event_id", "event_key", "trace_id", "handoff_id", "candidate_uid", "pos_id"):
        v = row.get(k)
        if v not in (None, "", "-"):
            keys.add(str(v))
    t = normalize_ticker(row.get("ticker") or row.get("market") or row.get("symbol")) or ""
    sk = _v090_strategy_key(row)
    ts = _v090_event_ts(row)
    if t and sk and ts > 0:
        keys.add(f"fb:{t}:{sk}:{int(ts // 30)}")
        keys.add(f"fbm:{t}:{sk}:{int(ts // 60)}")
    if t:
        keys.add(f"ticker:{t}")
    return {k for k in keys if k}


def _v090_closed_open_keysets() -> tuple[set[str], set[str], set[str]]:
    open_rows = list(load_open().values()) if isinstance(load_open(), dict) else []
    closed_rows = _v085_current_closed_rows_fast() if '_v085_current_closed_rows_fast' in globals() else read_jsonl(FILES["closed"], max_lines=2000)
    open_keys: set[str] = set(); closed_keys: set[str] = set(); open_tickers: set[str] = set()
    for p in open_rows:
        if isinstance(p, dict):
            open_keys |= _v090_match_keys(p)
            t = normalize_ticker(p.get("ticker") or p.get("market") or p.get("symbol")) or ""
            if t: open_tickers.add(t)
    for r in closed_rows:
        if isinstance(r, dict):
            closed_keys |= _v090_match_keys(r)
            src = r.get("source_event") if isinstance(r.get("source_event"), dict) else {}
            if src:
                closed_keys |= _v090_match_keys(src)
    return open_keys, closed_keys, open_tickers


def _v090_merged_keyset() -> set[str]:
    rows = []
    try:
        rows += read_jsonl(FILES.get("paper_merged", BASE_DIR / "paper_candidates_handoff_merged.jsonl"), max_lines=300)
    except Exception:
        pass
    try:
        rows += read_jsonl(FILES["paper_latest"], max_lines=200)
    except Exception:
        pass
    keys: set[str] = set()
    for r in rows:
        if isinstance(r, dict):
            keys |= _v090_match_keys(r)
    return keys


def _v090_reason_for_candidate(ev: Dict[str, Any], nowv: Optional[float] = None, merged_keys: Optional[set[str]] = None) -> str:
    nowv = nowv or now()
    row = _v080_normalize_candidate(ev)
    keys = _v090_match_keys(row)
    merged_keys = merged_keys if merged_keys is not None else _v090_merged_keyset()
    reasons: list[str] = []
    exp = float_any(row.get("expires_at"), default=0.0)
    created = _v090_event_ts(row)
    if exp and exp < nowv:
        reasons.append("handoff만료")
    if created and nowv - created > 180:
        reasons.append("후보오래됨")
    if not (keys & merged_keys):
        reasons.append("paper미병합")
    if not (row.get("micro_fresh") or (isinstance(row.get("entry_context"), dict) and row.get("entry_context", {}).get("micro_fresh"))):
        reasons.append("micro미확인")
    if row.get("stale") or row.get("is_stale"):
        reasons.append("stale")
    if row.get("open_eligible") is False or row.get("paper_bot_open") is False:
        reasons.append("open_eligible_false")
    if str(row.get("event_id_origin") or "") in {"legacy_fallback", "v090_fallback"}:
        reasons.append("구후보ID보정")
    if not reasons:
        reasons.append("paper미병합/만료확인")
    # 같은 이유 반복 제거
    out=[]
    for r in reasons:
        if r not in out:
            out.append(r)
    return ",".join(out[:5])


def _v090_write_handoff_trace(reason: str = "cycle") -> None:
    try:
        control = load_control()
        nowv = now()
        latest = [_v080_normalize_candidate(r, control) for r in read_jsonl(FILES["paper_latest"], max_lines=200)]
        archive = [_v080_normalize_candidate(r, control) for r in read_jsonl(FILES["paper_candidates"], max_lines=900)]
        merged = [_v080_normalize_candidate(r, control) for r in read_jsonl(FILES.get("paper_merged", BASE_DIR / "paper_candidates_handoff_merged.jsonl"), max_lines=300)]
        open_keys, closed_keys, open_tickers = _v090_closed_open_keysets()
        merged_keys = set()
        for r in merged + latest:
            merged_keys |= _v090_match_keys(r)
        rows=[]; seen=set(); counters=Counter()
        for src, seq in (("latest", latest), ("archive", archive)):
            for ev in seq:
                keys = _v090_match_keys(ev)
                key = str(ev.get("event_id") or next(iter(keys), ""))
                if not key or key in seen:
                    continue
                seen.add(key)
                t = normalize_ticker(ev.get("ticker") or ev.get("market") or ev.get("symbol")) or ""
                status = "candidate"
                if keys & closed_keys:
                    status = "closed"
                elif keys & open_keys or t in open_tickers:
                    status = "open"
                elif not candidate_is_fresh(ev, control):
                    status = "expired"
                elif not (keys & merged_keys):
                    status = "not_merged"
                else:
                    status = "merged_waiting_open"
                why = _v090_reason_for_candidate(ev, nowv, merged_keys)
                for w in why.split(','):
                    if w: counters[w]+=1
                rows.append({
                    "event_id": ev.get("event_id"), "ticker": t, "strategy_key": _v090_strategy_key(ev),
                    "strategy": ev.get("strategy_bucket_primary_label") or ev.get("strategy_name") or ev.get("strategy"),
                    "score": ev.get("score"), "source": src, "status": status, "reason": why,
                    "created_at": _v090_event_ts(ev), "expires_at": ev.get("expires_at"),
                    "fresh": candidate_is_fresh(ev, control), "gain_ref_price": ev.get("entry_price") or ev.get("current_price") or ev.get("detected_price"),
                })
        save_json(FILES.get("candidate_handoff_trace", BASE_DIR / "paper_bot_candidate_handoff_trace.json"), {
            "version": VERSION, "updated_at": nowv, "updated_at_text": iso_ts(nowv), "reason": reason,
            "latest_count": len(latest), "archive_window": len(archive), "merged_count": len(merged),
            "trace_count": len(rows), "reason_top": [{"reason": k, "count": v} for k,v in counters.most_common(10)],
            "rows": rows[:160],
        })
    except Exception as exc:
        try: log_error("v090_handoff_trace", exc)
        except Exception: pass

_v090_base_run_cycle = run_cycle

def run_cycle() -> Dict[str, Any]:  # type: ignore[override]
    res = _v090_base_run_cycle()
    _v090_write_handoff_trace("run_cycle")
    return res


def _v088_missed_review_text() -> str:  # type: ignore[override]
    anchor_ts = _v083_anchor_ts() if '_v083_anchor_ts' in globals() else 0.0
    events = read_jsonl(FILES["paper_candidates"], max_lines=900) + read_jsonl(FILES["paper_latest"], max_lines=200)
    market = _v088_market_rows()
    open_keys, closed_keys, open_tickers = _v090_closed_open_keysets()
    merged_keys = _v090_merged_keyset()
    seen=set(); missed=[]; watched=0; reason_counter: Counter[str] = Counter(); nowv=now()
    for raw in events:
        if not isinstance(raw, dict):
            continue
        ev = _v080_normalize_candidate(raw)
        ts = _v090_event_ts(ev)
        if anchor_ts and ts and ts < anchor_ts:
            continue
        t = normalize_ticker(ev.get("ticker") or ev.get("market") or ev.get("symbol")) or ""
        keys = _v090_match_keys(ev)
        dedupe = str(ev.get("event_id") or f"{t}:{_v090_strategy_key(ev)}:{int(ts//30) if ts else 0}")
        if not t or dedupe in seen:
            continue
        seen.add(dedupe); watched += 1
        if (keys & closed_keys) or (keys & open_keys) or t in open_tickers:
            continue
        cur = market.get(t, {})
        cur_price = float_any(cur.get("current_price"), cur.get("price"), cur.get("trade_price"), default=0.0)
        entry = float_any(ev.get("entry_price"), ev.get("current_price"), ev.get("detected_price"), default=0.0)
        if cur_price <= 0 or entry <= 0:
            continue
        gain = (cur_price - entry) / entry * 100.0
        if gain >= 0.70:
            reason = _v090_reason_for_candidate(ev, nowv, merged_keys)
            for r in reason.split(','):
                if r: reason_counter[r]+=1
            rs = ev.get("reasons") or ev.get("final_entry_reasons") or []
            missed.append({"ticker": t, "gain": gain, "entry": entry, "current": cur_price, "strategy": ev.get("strategy_bucket_primary_label") or ev.get("strategy_name") or ev.get("strategy"), "score": ev.get("score"), "reasons": rs if isinstance(rs, list) else [], "missed_reason": reason})
    missed.sort(key=lambda x: x.get("gain",0), reverse=True)
    lines = [
        "🔎 놓친 후보 복기 /pmissed_review",
        "- 후보 archive/latest 중 OPEN/CLOSED로 이어지지 않았는데 이후 오른 코인을 봅니다.",
        f"- 확인 후보 {watched}개 / 현재가 비교 가능 상승후보 {len(missed)}개",
        "", "[놓친 이유 추정 TOP]",
    ]
    if reason_counter:
        for k,v in reason_counter.most_common(10):
            icon = "⚠️" if k in {"paper미병합", "handoff만료", "후보오래됨", "micro미확인"} else "❔"
            lines.append(f"- {icon} {k}: {v}개")
    else:
        lines.append("- 아직 분류할 상승후보 없음")
    lines += ["", "[이후 오른 후보 TOP]"]
    if missed:
        for m in missed[:10]:
            rs = m.get("reasons") if isinstance(m.get("reasons"), list) else []
            lines.append(f"- {'⚠️' if m['gain']>=1.5 else '❔'} {m['ticker']} / +{m['gain']:.2f}% / {m.get('strategy','-')} / 점수 {m.get('score','-')} / 놓친이유 {m.get('missed_reason','-')} / 근거 {', '.join(map(str, rs[:3]))}")
    else:
        lines.append("- 아직 뚜렷한 놓친 상승후보 없음")
    lines += ["", "[판독]", "- 자주 오르는 패턴은 조건에서 죽이면 안 됨", "- paper미병합/만료/오래됨이 많으면 전략조건보다 handoff·진입타이밍 문제를 먼저 봅니다", "- 손실필터는 /ploss_review와 같이 봐야 합니다"]
    return "\n".join(lines)

try:
    _v090_write_handoff_trace("startup_v090")
    _v077_build_score_cache("startup_v090")
except Exception as exc:
    try: log_error("v090_startup", exc)
    except Exception: pass



# =============================================================================
# paper_bot v0.92: handoff trace canonical repair
# - latest_scan 8초 window 때문에 TTL 유효 S 후보가 paper 병합 전에 빠지는 문제를 줄인다.
# - latest + archive fresh 후보를 단일 handoff queue로 병합하고, 그 queue를 그대로 선별한다.
# - 조건/청산선/자동매수 변경 없음. paper가 이미 받은 S 후보를 놓치지 않도록 배관을 정리한다.
# =============================================================================
VERSION = "paper_bot_v0.92"
try:
    FILES["candidate_handoff_trace"] = BASE_DIR / "paper_bot_candidate_handoff_trace.json"
except Exception:
    pass

_V091_LAST_TRACE_ROWS: List[Dict[str, Any]] = []
_V091_LAST_TRACE_COUNTER: Counter[str] = Counter()


def _v091_candidate_sources(control: Optional[Dict[str, Any]] = None) -> List[Dict[str, Any]]:
    control = control or load_control()
    rows: List[Dict[str, Any]] = []
    for source, path, maxn in (
        ("latest", FILES.get("paper_latest", BASE_DIR/"paper_candidates_latest.jsonl"), 300),
        ("archive", FILES.get("paper_candidates", BASE_DIR/"paper_candidates.jsonl"), int(float_any(control.get("candidate_read_max_lines"), default=1200))),
    ):
        try:
            for r in read_jsonl(path, max_lines=maxn):
                if not isinstance(r, dict):
                    continue
                ev = _v080_normalize_candidate(r, control)
                ev["handoff_source"] = source
                rows.append(ev)
        except Exception as exc:
            try: log_error(f"v091_read_{source}", exc)
            except Exception: pass
    return rows


def _v091_build_candidate_merge(control: Optional[Dict[str, Any]] = None) -> Path:
    control = control or load_control()
    nowv = now()
    rows = _v091_candidate_sources(control)
    merged: Dict[str, Dict[str, Any]] = {}
    fresh_count = 0
    expired_count = 0
    for r in rows:
        fresh = candidate_is_fresh(r, control)
        if fresh:
            fresh_count += 1
        else:
            expired_count += 1
            continue
        k = _v080_event_key(r)
        prev = merged.get(k)
        if prev is None or _v080_ts(r) >= _v080_ts(prev):
            merged[k] = r
    out = sorted(merged.values(), key=lambda x: (_v080_ts(x), float_any(x.get("score"), default=0.0)), reverse=True)
    _v080_write_jsonl_atomic(FILES["paper_merged"], out)
    save_json(FILES["candidate_handoff_status"], {
        "version": VERSION,
        "updated_at": nowv,
        "updated_at_text": iso_ts(nowv),
        "latest_lines": sum(1 for r in rows if r.get("handoff_source") == "latest"),
        "archive_window": sum(1 for r in rows if r.get("handoff_source") == "archive"),
        "merged_fresh": len(out),
        "fresh_source_rows": fresh_count,
        "expired_source_rows": expired_count,
        "ttl_sec": float_any(control.get("candidate_ttl_sec"), default=120.0),
        "tickers": [r.get("ticker") for r in out[:30]],
        "note": "v0.92: TTL 유효 S 후보 병합 + 최근 후보 trace 상시 기록",
    })
    return FILES["paper_merged"]


def candidate_input_path(lane: str) -> Path:  # type: ignore[override]
    if lane == "strict":
        try:
            if load_control().get("consume_latest_candidate_files", True):
                return _v091_build_candidate_merge(load_control())
        except Exception as exc:
            try: log_error("v091_candidate_merge", exc)
            except Exception: pass
            return FILES.get("paper_candidates", BASE_DIR/"paper_candidates.jsonl")
    if lane == "shadow" and load_control().get("consume_latest_candidate_files", True) and FILES.get("shadow_latest", Path("")).exists():
        return FILES["shadow_latest"]
    return FILES["paper_candidates"] if lane == "strict" else FILES["shadow_candidates"]


def _v091_trace_row(ev: Dict[str, Any], status: str, reason: str, lane: str = "strict") -> Dict[str, Any]:
    row = _v080_normalize_candidate(ev)
    return {
        "version": VERSION,
        "updated_at": now(),
        "event_id": row.get("event_id"),
        "event_key": row.get("event_key"),
        "trace_id": row.get("trace_id") or row.get("event_id"),
        "handoff_id": row.get("handoff_id") or row.get("event_id"),
        "candidate_uid": row.get("candidate_uid") or row.get("event_id"),
        "ticker": row.get("ticker"),
        "strategy_key": _v090_strategy_key(row) if '_v090_strategy_key' in globals() else row.get("strategy_key"),
        "strategy": row.get("strategy_bucket_primary_label") or row.get("strategy_name") or row.get("strategy"),
        "score": row.get("score"),
        "lane": lane,
        "status": status,
        "reason": reason,
        "created_at": _v090_event_ts(row) if '_v090_event_ts' in globals() else _v080_ts(row),
        "expires_at": row.get("expires_at"),
        "fresh": None,
        "open_eligible": bool(row.get("paper_bot_open") or row.get("open_eligible") or row.get("trade_ready")),
        "micro_fresh": bool(row.get("micro_fresh") or (isinstance(row.get("entry_context"), dict) and row.get("entry_context",{}).get("micro_fresh"))),
        "entry_price": row.get("entry_price") or row.get("current_price") or row.get("detected_price"),
        "handoff_source": row.get("handoff_source"),
    }


def _v091_save_trace(rows: List[Dict[str, Any]], reason: str = "pick_candidates") -> None:
    try:
        counters = Counter()
        status_counter = Counter()
        for r in rows:
            status_counter[str(r.get("status") or "unknown")] += 1
            for x in str(r.get("reason") or "").split(','):
                x=x.strip()
                if x: counters[x]+=1
        save_json(FILES.get("candidate_handoff_trace", BASE_DIR/"paper_bot_candidate_handoff_trace.json"), {
            "version": VERSION,
            "updated_at": now(),
            "updated_at_text": iso_ts(),
            "reason": reason,
            "trace_count": len(rows),
            "status_top": [{"status": k, "count": v} for k,v in status_counter.most_common(12)],
            "reason_top": [{"reason": k, "count": v} for k,v in counters.most_common(12)],
            "rows": rows[:300],
            "note": "v0.91: paper 선별 단계의 실제 통과/스킵 이유를 기록",
        })
    except Exception as exc:
        try: log_error("v091_save_trace", exc)
        except Exception: pass


def pick_candidates(control: Dict[str, Any], open_pos: Dict[str, Dict[str, Any]]) -> Tuple[List[Tuple[str, Dict[str, Any]]], Dict[str, int]]:  # type: ignore[override]
    global _V091_LAST_TRACE_ROWS, _V091_LAST_TRACE_COUNTER
    existing_ids = set(open_pos.keys()) | load_closed_ids()
    blocked_tickers = open_tickers(open_pos) if control.get("block_same_ticker_open", True) else set()
    picked: List[Tuple[str, Dict[str, Any]]] = []
    trace_rows: List[Dict[str, Any]] = []
    stats = {
        "paper_file": 0, "shadow_file": 0, "events_file": 0, "dup_skip": 0, "same_ticker_skip": 0,
        "bad_skip": 0, "limit_skip": 0, "stale_skip": 0, "strict_observe_skip": 0,
        "not_trade_ready_skip": 0, "micro_preopen_wait": 0, "new_open_paused": 0,
        "latest_scan_before": 0, "latest_scan_after": 0, "latest_scan_id": "v091_no_latest_scan_filter",
        "grade_s_seen": 0, "grade_a_seen": 0, "grade_b_seen": 0, "grade_c_observe_skip": 0, "grade_x_block_skip": 0, "grade_missing_skip": 0,
        "repeat_loss_hard_block": 0, "repeat_loss_elevated_block": 0, "repeat_loss_override_allow": 0,
    }
    if control.get("new_open_paused", True):
        stats["new_open_paused"] = 1
        _v091_save_trace([], "new_open_paused")
        return [], stats
    try:
        path = candidate_input_path("strict")
        rows = [_v080_normalize_candidate(r, control) for r in read_jsonl(path, max_lines=int(float_any(control.get("candidate_read_max_lines"), default=1500)))]
    except Exception as exc:
        try: log_error("v091_pick_read", exc)
        except Exception: pass
        rows = []
    stats["paper_file"] = len(rows)
    stats["latest_scan_before"] = len(rows)
    lane_counts = count_by_lane(open_pos)
    max_strict = int(float_any(control.get("max_open_strict"), default=0)); strict_cap_on = max_strict > 0
    max_new = int(float_any(control.get("max_new_per_cycle"), default=0)); new_cap_on = max_new > 0
    allow_grades = set(control.get("paper_open_grades") or ["S", "A"])
    micro_wait_rows: List[Dict[str, Any]] = []
    gate_map = _v066_recent_loss_gate_map() if '_v066_recent_loss_gate_map' in globals() else {}
    for ev in rows:
        if new_cap_on and len(picked) >= max_new:
            stats["limit_skip"] += 1
            trace_rows.append(_v091_trace_row(ev, "skipped", "max_new_limit")); continue
        if strict_cap_on and lane_counts.get("strict", 0) >= max_strict:
            stats["limit_skip"] += 1
            trace_rows.append(_v091_trace_row(ev, "skipped", "strict_open_limit")); continue
        if not candidate_is_fresh(ev, control):
            stats["stale_skip"] += 1
            trace_rows.append(_v091_trace_row(ev, "expired", "handoff만료,후보오래됨")); continue
        g = _v070_grade_from_event(ev) if '_v070_grade_from_event' in globals() else _v069_grade_from_event(ev) if '_v069_grade_from_event' in globals() else str(ev.get("candidate_grade") or "S").upper()
        if g == "S": stats["grade_s_seen"] += 1
        elif g == "A": stats["grade_a_seen"] += 1
        elif g == "B": stats["grade_b_seen"] += 1
        elif g == "C": stats["grade_c_observe_skip"] += 1
        elif g == "X": stats["grade_x_block_skip"] += 1
        else: stats["grade_missing_skip"] += 1
        if g not in allow_grades:
            trace_rows.append(_v091_trace_row(ev, "skipped", f"grade_{g}_not_open")); continue
        if control.get("open_trade_ready_only", True):
            can_open = bool(ev.get("paper_bot_open") or ev.get("open_eligible") or ev.get("trade_ready"))
            if not can_open:
                stats["strict_observe_skip"] += 1; stats["not_trade_ready_skip"] += 1
                trace_rows.append(_v091_trace_row(ev, "skipped", "open_eligible_false")); continue
        if control.get("preopen_micro_recheck", True) and bool(ev.get("paper_bot_open") or ev.get("open_eligible") or ev.get("trade_ready")):
            if not _event_micro_is_fresh(ev):
                stats["micro_preopen_wait"] += 1
                micro_wait_rows.append(dict(ev))
                trace_rows.append(_v091_trace_row(ev, "micro_wait", "micro미확인")); continue
        eid = event_id(ev, "strict")
        t = normalize_ticker(ev.get("ticker") or ev.get("market") or ev.get("symbol"))
        price = get_event_price(ev)
        if not t or price <= 0:
            stats["bad_skip"] += 1
            trace_rows.append(_v091_trace_row(ev, "skipped", "bad_ticker_or_price")); continue
        if eid in existing_ids:
            stats["dup_skip"] += 1
            trace_rows.append(_v091_trace_row(ev, "duplicate", "already_open_or_closed")); continue
        if control.get("block_same_ticker_open", True) and t in blocked_tickers:
            stats["same_ticker_skip"] += 1
            trace_rows.append(_v091_trace_row(ev, "skipped", "same_ticker_open")); continue
        # 반복손실 보호는 기존 보조함수가 있을 때 유지한다.
        if gate_map and '_v052_is_focus_strategy' in globals() and '_v066_strong_reentry_ok' in globals():
            meta = gate_map.get(short_ticker(t))
            if meta and _v052_is_focus_strategy(ev):
                mode = str(meta.get("mode") or "")
                if mode == "hard_block":
                    stats["repeat_loss_hard_block"] += 1
                    trace_rows.append(_v091_trace_row(ev, "skipped", "recent_loss_hard_cooldown")); continue
                ok, reasons = _v066_strong_reentry_ok(ev, meta)
                if not ok:
                    stats["repeat_loss_elevated_block"] += 1
                    trace_rows.append(_v091_trace_row(ev, "skipped", "recent_loss_cooldown")); continue
                stats["repeat_loss_override_allow"] += 1
                ev = dict(ev); ev["repeat_loss_reentry_override"] = True; ev["repeat_loss_reentry_reasons"] = reasons[:8]
        ev = dict(ev); ev["lane"] = "strict"; ev["candidate_grade"] = g; ev["paper_grade_open"] = True; ev["v091_handoff_canonical"] = True
        picked.append((eid, ev)); existing_ids.add(eid); blocked_tickers.add(t); lane_counts["strict"] = lane_counts.get("strict",0)+1
        trace_rows.append(_v091_trace_row(ev, "picked", "selected_for_open"))
    if micro_wait_rows:
        _write_micro_urgent_targets(micro_wait_rows, reason="paper_preopen_micro_stale_v091", control=control)
    stats["latest_scan_after"] = len(rows)
    _V091_LAST_TRACE_ROWS = trace_rows
    _v091_save_trace(trace_rows, "pick_candidates_v092")
    return picked, stats


def _v090_write_handoff_trace(reason: str = "cycle") -> None:  # type: ignore[override]
    rows = list(_V091_LAST_TRACE_ROWS or [])
    if rows:
        _v091_save_trace(rows, reason)
    else:
        try:
            control = load_control(); _v091_build_candidate_merge(control)
            src = [_v080_normalize_candidate(r, control) for r in read_jsonl(FILES.get("paper_merged", BASE_DIR/"paper_candidates_handoff_merged.jsonl"), max_lines=500)]
            _v091_save_trace([_v091_trace_row(r, "merged_waiting_pick", _v090_reason_for_candidate(r) if '_v090_reason_for_candidate' in globals() else "merged") for r in src], reason)
        except Exception as exc:
            try: log_error("v091_write_trace", exc)
            except Exception: pass

try:
    _v091_build_candidate_merge(load_control())
    _v090_write_handoff_trace("startup_v092")
    _v077_build_score_cache("startup_v092")
except Exception as exc:
    try: log_error("v091_startup", exc)
    except Exception: pass



# =============================================================================
# paper_bot v0.92: trace rows 0 방지 + score cache version 정리
# - 후보가 현재 fresh가 아니어도 최근 archive/latest/merged 후보를 trace에 남긴다.
# - OPEN/CLOSED/expired/not_merged/micro_wait 상태를 한 파일에 기록해 메인봇 /missed_trace가 비지 않게 한다.
# - 전략/청산/자동매수 조건은 변경하지 않는다.
# =============================================================================
VERSION = "paper_bot_v0.92"

def _v092_candidate_recent_sources(control: Optional[Dict[str, Any]] = None) -> List[Dict[str, Any]]:
    control = control or load_control()
    out: List[Dict[str, Any]] = []
    specs = [
        ("latest", FILES.get("paper_latest", BASE_DIR/"paper_candidates_latest.jsonl"), 400),
        ("merged", FILES.get("paper_merged", BASE_DIR/"paper_candidates_handoff_merged.jsonl"), 500),
        ("archive", FILES.get("paper_candidates", BASE_DIR/"paper_candidates.jsonl"), int(float_any(control.get("candidate_read_max_lines"), default=1600))),
    ]
    for source, path, maxn in specs:
        try:
            for r in read_jsonl(path, max_lines=maxn):
                if not isinstance(r, dict):
                    continue
                ev = _v080_normalize_candidate(r, control)
                ev["handoff_source"] = ev.get("handoff_source") or source
                out.append(ev)
        except Exception as exc:
            try: log_error(f"v092_trace_read_{source}", exc)
            except Exception: pass
    # 중복 제거: event_id 우선, 없으면 ticker/strategy/30초 버킷
    dedup: Dict[str, Dict[str, Any]] = {}
    for ev in out:
        t = short_ticker(ev.get("ticker") or ev.get("market") or ev.get("symbol"))
        sk = _v090_strategy_key(ev) if '_v090_strategy_key' in globals() else str(ev.get("strategy_key") or "strategy")
        ts = _v090_event_ts(ev) if '_v090_event_ts' in globals() else _v080_ts(ev)
        key = str(ev.get("event_id") or ev.get("event_key") or f"{t}:{sk}:{int(ts//30) if ts else 0}")
        old = dedup.get(key)
        if old is None or (_v090_event_ts(ev) if '_v090_event_ts' in globals() else _v080_ts(ev)) >= (_v090_event_ts(old) if '_v090_event_ts' in globals() else _v080_ts(old)):
            dedup[key]=ev
    rows = list(dedup.values())
    rows.sort(key=lambda r: (_v090_event_ts(r) if '_v090_event_ts' in globals() else _v080_ts(r), float_any(r.get("score"), default=0.0)), reverse=True)
    return rows[:900]

def _v092_status_reason(ev: Dict[str, Any], control: Dict[str, Any], open_keys: set, closed_keys: set, open_tickers: set, merged_keys: set) -> tuple[str, str]:
    keys = _v090_match_keys(ev) if '_v090_match_keys' in globals() else {event_id(ev, 'strict')}
    t = short_ticker(ev.get("ticker") or ev.get("market") or ev.get("symbol"))
    if keys & closed_keys:
        return "closed", "closed_match"
    if (keys & open_keys) or (t and t in open_tickers):
        return "open", "open_match"
    fresh = candidate_is_fresh(ev, control)
    reasons: List[str] = []
    if not fresh:
        reasons += ["handoff만료", "후보오래됨"]
    if not (keys & merged_keys):
        reasons.append("paper미병합")
    if not (ev.get("micro_fresh") or (isinstance(ev.get("entry_context"), dict) and ev.get("entry_context",{}).get("micro_fresh"))):
        reasons.append("micro미확인")
    if ev.get("stale") or ev.get("is_stale"):
        reasons.append("stale")
    if ev.get("open_eligible") is False or ev.get("paper_bot_open") is False:
        reasons.append("open_eligible_false")
    if not reasons:
        if keys & merged_keys:
            return "merged_waiting_pick", "merged_waiting_pick"
        return "not_merged", "paper미병합"
    if "micro미확인" in reasons and fresh:
        return "micro_wait", ",".join(reasons)
    if not fresh:
        return "expired", ",".join(reasons)
    return "not_merged", ",".join(reasons)

def _v092_write_trace_from_sources(reason: str = "trace_refresh_v092") -> None:
    try:
        control = load_control()
        rows = _v092_candidate_recent_sources(control)
        open_keys, closed_keys, open_tickers = _v090_closed_open_keysets() if '_v090_closed_open_keysets' in globals() else (set(), set(), set())
        merged_keys = _v090_merged_keyset() if '_v090_merged_keyset' in globals() else set()
        trace_rows: List[Dict[str, Any]] = []
        for ev in rows:
            status, why = _v092_status_reason(ev, control, open_keys, closed_keys, open_tickers, merged_keys)
            trace_rows.append(_v091_trace_row(ev, status, why, "strict") if '_v091_trace_row' in globals() else {"ticker": ev.get("ticker"), "status": status, "reason": why})
        _v091_save_trace(trace_rows, reason) if '_v091_save_trace' in globals() else save_json(FILES.get("candidate_handoff_trace", BASE_DIR/"paper_bot_candidate_handoff_trace.json"), {"version": VERSION, "updated_at": now(), "rows": trace_rows})
    except Exception as exc:
        try: log_error("v092_write_trace_from_sources", exc)
        except Exception: pass

_v092_prev_pick_candidates = pick_candidates

def pick_candidates(control: Dict[str, Any], open_pos: Dict[str, Dict[str, Any]]) -> Tuple[List[Tuple[str, Dict[str, Any]]], Dict[str, int]]:  # type: ignore[override]
    picked, stats = _v092_prev_pick_candidates(control, open_pos)
    # pick 후보가 없더라도 최근 handoff/archive 후보 trace는 항상 채운다.
    _v092_write_trace_from_sources("pick_candidates_v092")
    return picked, stats

def _v090_write_handoff_trace(reason: str = "cycle") -> None:  # type: ignore[override]
    _v092_write_trace_from_sources(reason)

try:
    _v091_build_candidate_merge(load_control()) if '_v091_build_candidate_merge' in globals() else None
    _v092_write_trace_from_sources("startup_v092")
    _v077_build_score_cache("startup_v092")
except Exception as exc:
    try: log_error("v092_startup", exc)
    except Exception: pass


# =============================================================================
# paper_bot v0.93: handoff trace final canonical layer
# - v0.92에서 실제 선별 trace가 최근 source trace로 덮이면서 expired/paper미병합이 과대표시되던 문제를 막는다.
# - 실제 pick/open/closed 상태를 우선하고, source trace는 보조로 합친다.
# - 전략조건/청산/자동매수/장부는 변경하지 않는다.
# =============================================================================
VERSION = "paper_bot_v0.95"

def _v093_trace_priority(row: Dict[str, Any]) -> tuple[int, float]:
    status = str((row or {}).get("status") or "")
    priority = {
        "closed": 90, "open": 85, "picked": 80, "selected_for_open": 80,
        "merged_waiting_pick": 65, "micro_wait": 55, "not_merged": 40,
        "expired": 25, "skipped": 15, "duplicate": 10, "unknown": 0,
    }.get(status, 0)
    ts = float_any((row or {}).get("created_at"), (row or {}).get("updated_at"), default=0.0)
    return priority, ts

def _v093_trace_keys(row: Dict[str, Any]) -> set[str]:
    row = row if isinstance(row, dict) else {}
    keys: set[str] = set()
    for k in ("event_id", "event_key", "trace_id", "handoff_id", "candidate_uid", "pos_id"):
        v = row.get(k)
        if v not in (None, "", "-"):
            keys.add(str(v))
    t = short_ticker(row.get("ticker") or row.get("market") or row.get("symbol"))
    sk = str(row.get("strategy_key") or row.get("strategy") or "strategy_s")
    ts = float_any(row.get("created_at"), row.get("candidate_created_at"), row.get("event_ts"), default=0.0)
    # 표시/복기용 canonical key. 같은 코인+전략의 오래된 expired가 최신 pick/open을 덮지 못하게 한다.
    if t and sk:
        keys.add(f"ticker_strategy:{t}:{sk}")
        if ts > 0:
            keys.add(f"ticker_strategy_min:{t}:{sk}:{int(ts // 60)}")
    return {x for x in keys if x}

def _v093_merge_trace_rows(actual_rows: List[Dict[str, Any]], source_rows: List[Dict[str, Any]]) -> List[Dict[str, Any]]:
    best: Dict[str, Dict[str, Any]] = {}
    aliases: Dict[str, str] = {}
    def add(row: Dict[str, Any]) -> None:
        if not isinstance(row, dict):
            return
        keys = _v093_trace_keys(row)
        if not keys:
            return
        primary = sorted(keys)[0]
        # 이미 연결된 alias가 있으면 그 canonical bucket에 합친다.
        for k in keys:
            if k in aliases:
                primary = aliases[k]; break
        for k in keys:
            aliases[k] = primary
        old = best.get(primary)
        if old is None or _v093_trace_priority(row) > _v093_trace_priority(old):
            best[primary] = row
    # source 먼저 넣고 actual을 나중에 넣는다. priority도 actual/open/closed가 더 높다.
    for r in source_rows:
        add(r)
    for r in actual_rows:
        add(r)
    rows = list(best.values())
    rows.sort(key=lambda r: (_v093_trace_priority(r)[0], _v093_trace_priority(r)[1], float_any(r.get("score"), default=0.0)), reverse=True)
    return rows

def _v093_source_trace_rows(control: Optional[Dict[str, Any]] = None) -> List[Dict[str, Any]]:
    control = control or load_control()
    out: List[Dict[str, Any]] = []
    try:
        rows = _v092_candidate_recent_sources(control) if '_v092_candidate_recent_sources' in globals() else []
        open_keys, closed_keys, open_tickers = _v090_closed_open_keysets() if '_v090_closed_open_keysets' in globals() else (set(), set(), set())
        merged_keys = _v090_merged_keyset() if '_v090_merged_keyset' in globals() else set()
        for ev in rows:
            status, why = _v092_status_reason(ev, control, open_keys, closed_keys, open_tickers, merged_keys) if '_v092_status_reason' in globals() else ("unknown", "unknown")
            out.append(_v091_trace_row(ev, status, why, "strict") if '_v091_trace_row' in globals() else {"ticker": ev.get("ticker"), "status": status, "reason": why})
    except Exception as exc:
        try: log_error("v093_source_trace_rows", exc)
        except Exception: pass
    return out

def _v093_write_trace(reason: str = "trace_refresh_v093", actual_rows: Optional[List[Dict[str, Any]]] = None) -> None:
    try:
        source_rows = _v093_source_trace_rows(load_control())
        actual_rows = list(actual_rows or [])
        rows = _v093_merge_trace_rows(actual_rows, source_rows)
        if '_v091_save_trace' in globals():
            _v091_save_trace(rows, reason)
        else:
            save_json(FILES.get("candidate_handoff_trace", BASE_DIR/"paper_bot_candidate_handoff_trace.json"), {"version": VERSION, "updated_at": now(), "rows": rows[:300]})
    except Exception as exc:
        try: log_error("v093_write_trace", exc)
        except Exception: pass

_v093_prev_pick_candidates = pick_candidates
def pick_candidates(control: Dict[str, Any], open_pos: Dict[str, Dict[str, Any]]) -> Tuple[List[Tuple[str, Dict[str, Any]]], Dict[str, int]]:  # type: ignore[override]
    picked, stats = _v093_prev_pick_candidates(control, open_pos)
    actual = list(_V091_LAST_TRACE_ROWS or []) if '_V091_LAST_TRACE_ROWS' in globals() else []
    _v093_write_trace("pick_candidates_v093", actual)
    return picked, stats

def _v090_write_handoff_trace(reason: str = "cycle") -> None:  # type: ignore[override]
    actual = list(_V091_LAST_TRACE_ROWS or []) if '_V091_LAST_TRACE_ROWS' in globals() else []
    _v093_write_trace(reason, actual)

try:
    _v091_build_candidate_merge(load_control()) if '_v091_build_candidate_merge' in globals() else None
    _v093_write_trace("startup_v093", list(_V091_LAST_TRACE_ROWS or []) if '_V091_LAST_TRACE_ROWS' in globals() else [])
    _v077_build_score_cache("startup_v093")
except Exception as exc:
    try: log_error("v093_startup", exc)
    except Exception: pass



# =============================================================================
# paper_bot v0.95: trace 배관 단일화 수술
# - v0.92/v0.93의 archive/latest 전체 재추적(source trace) 경로를 기본 trace 본선에서 끊는다.
# - /missed_trace는 실제 pick_candidates()가 이번 cycle에서 처리한 결과만 보여준다.
# - 오래된 archive 후보를 다시 훑어 expired/paper미병합으로 과대표시하지 않는다.
# - 전략조건/청산/자동매수/장부는 변경하지 않는다.
# =============================================================================
VERSION = "paper_bot_v0.95"

def _v094_actual_trace_rows() -> List[Dict[str, Any]]:
    try:
        return [r for r in list(_V091_LAST_TRACE_ROWS or []) if isinstance(r, dict)]
    except Exception:
        return []

def _v094_dedupe_actual_trace(rows: List[Dict[str, Any]]) -> List[Dict[str, Any]]:
    best: Dict[str, Dict[str, Any]] = {}
    priority = {
        "closed": 90, "open": 85, "picked": 80, "selected_for_open": 80,
        "merged_waiting_pick": 65, "micro_wait": 55, "not_merged": 40,
        "expired": 25, "skipped": 15, "duplicate": 10, "unknown": 0,
    }
    def key_of(row: Dict[str, Any]) -> str:
        for k in ("event_id", "event_key", "trace_id", "handoff_id", "candidate_uid", "pos_id"):
            v = row.get(k)
            if v not in (None, "", "-"):
                return str(v)
        t = short_ticker(row.get("ticker") or row.get("market") or row.get("symbol"))
        sk = str(row.get("strategy_key") or row.get("strategy") or "strategy_s")
        ts = float_any(row.get("created_at"), row.get("candidate_created_at"), row.get("event_ts"), default=0.0)
        return f"{t}:{sk}:{int(ts // 30) if ts else 0}"
    for row in rows:
        if not isinstance(row, dict):
            continue
        k = key_of(row)
        old = best.get(k)
        new_score = priority.get(str(row.get("status") or "unknown"), 0)
        new_ts = float_any(row.get("created_at"), row.get("updated_at"), default=0.0)
        if old is None:
            best[k] = row
            continue
        old_score = priority.get(str(old.get("status") or "unknown"), 0)
        old_ts = float_any(old.get("created_at"), old.get("updated_at"), default=0.0)
        if (new_score, new_ts) >= (old_score, old_ts):
            best[k] = row
    out = list(best.values())
    out.sort(key=lambda r: (priority.get(str(r.get("status") or "unknown"), 0), float_any(r.get("created_at"), r.get("updated_at"), default=0.0), float_any(r.get("score"), default=0.0)), reverse=True)
    return out[:300]

def _v094_save_actual_trace(reason: str = "actual_pick_trace_v094", rows: Optional[List[Dict[str, Any]]] = None) -> None:
    try:
        actual = _v094_dedupe_actual_trace(list(rows if rows is not None else _v094_actual_trace_rows()))
        # source/archive fallback 금지: actual이 비면 비어 있다고 저장한다.
        _v091_save_trace(actual, reason) if '_v091_save_trace' in globals() else save_json(FILES.get("candidate_handoff_trace", BASE_DIR/"paper_bot_candidate_handoff_trace.json"), {"version": VERSION, "updated_at": now(), "updated_at_text": iso_ts(), "reason": reason, "trace_count": len(actual), "rows": actual})
    except Exception as exc:
        try: log_error("v094_save_actual_trace", exc)
        except Exception: pass

_v094_prev_pick_candidates = pick_candidates

def pick_candidates(control: Dict[str, Any], open_pos: Dict[str, Dict[str, Any]]) -> Tuple[List[Tuple[str, Dict[str, Any]]], Dict[str, int]]:  # type: ignore[override]
    picked, stats = _v094_prev_pick_candidates(control, open_pos)
    actual = _v094_actual_trace_rows()
    _v094_save_actual_trace("pick_candidates_v094_actual_only", actual)
    return picked, stats

def _v090_write_handoff_trace(reason: str = "cycle") -> None:  # type: ignore[override]
    _v094_save_actual_trace(f"{reason}_v094_actual_only", _v094_actual_trace_rows())

try:
    _v094_save_actual_trace("startup_v094_actual_only", _v094_actual_trace_rows())
    _v077_build_score_cache("startup_v094")
except Exception as exc:
    try: log_error("v094_startup", exc)
    except Exception: pass


# =============================================================================
# paper_bot v0.97: score cache 생성 경로 고정
# - 메인봇 v356이 읽는 paper_bot_score_cache.json을 현재 VERSION으로 즉시 생성한다.
# - 구 캐시를 보여주는 fallback은 쓰지 않고, 현재판 anchor cache만 저장한다.
# - 전략조건/청산/자동매수/장부는 변경하지 않는다.
# =============================================================================
VERSION = "paper_bot_v0.102"

_v096_prev_run_cycle = run_cycle

def _v096_refresh_score_cache(reason: str = "score_cache_v096") -> Dict[str, Any]:
    cache = _v077_build_score_cache(reason)
    try:
        st = load_json(FILES.get("status", BASE_DIR / "paper_bot_status.json"), {}) or {}
        if isinstance(st, dict) and isinstance(cache, dict):
            st["score_cache_version"] = VERSION
            st["score_cache_schema"] = cache.get("schema")
            st["score_cache_updated_at"] = cache.get("updated_at")
            st["score_cache_current_closed_count"] = cache.get("current_closed_count")
            save_json(FILES.get("status", BASE_DIR / "paper_bot_status.json"), st)
    except Exception as exc:
        try: log_error("v096_score_cache_status", exc)
        except Exception: pass
    return cache


def run_cycle() -> Dict[str, Any]:  # type: ignore[override]
    res = _v096_prev_run_cycle()
    try:
        _v096_refresh_score_cache("run_cycle_v096")
    except Exception as exc:
        try: log_error("v096_score_cache_refresh", exc)
        except Exception: pass
    return res

try:
    _v096_refresh_score_cache("startup_v096")
except Exception as exc:
    try: log_error("v096_startup_score_cache", exc)
    except Exception: pass



# =============================================================================
# paper_bot v0.97: S1/S2/S3 등급 본선화
# - S1만 실제 paper OPEN한다.
# - S2/S3는 trace/복기에는 남기되 OPEN하지 않는다.
# - A/B/C는 새 성과판 기본값에서 제거하고, 과거 S/A는 S1, B/C는 S3로 호환 집계한다.
# =============================================================================
VERSION = "paper_bot_v0.102"

def _v097_grade_value(row: Dict[str, Any]) -> str:
    ctx = row.get('entry_context') if isinstance(row.get('entry_context'), dict) else {}
    g = str(row.get('s_stage') or row.get('candidate_grade') or row.get('grade') or ctx.get('s_stage') or ctx.get('candidate_grade') or '').upper().strip()
    if g in {'S1','S2','S3','X'}: return g
    if g in {'S','A'}: return 'S1'
    if g in {'B','C'}: return 'S3'
    label = str(row.get('candidate_grade_label') or ctx.get('candidate_grade_label') or row.get('final_entry_label') or '')
    if 'S1' in label or '즉시' in label or 'S급' in label: return 'S1'
    if 'S2' in label or '재확인' in label: return 'S2'
    if 'S3' in label or '관찰' in label or '복기' in label: return 'S3'
    if '제외' in label or '차단' in label or '금지' in label: return 'X'
    return 'S3'

def _v070_grade_from_event(ev: Dict[str, Any]) -> str:  # type: ignore[override]
    return _v097_grade_value(ev)

def _v071_grade_from_row(row: Dict[str, Any]) -> str:  # type: ignore[override]
    return _v097_grade_value(row)

def _v077_group_by_grade(rows: List[Dict[str, Any]]) -> Dict[str, List[Dict[str, Any]]]:  # type: ignore[override]
    out = {'S1': [], 'S2': [], 'S3': [], 'X': []}
    for r in rows or []:
        g = _v097_grade_value(r)
        if g not in out: g = 'S3'
        out[g].append(r)
    return out

_v097_prev_pick_candidates = pick_candidates

def pick_candidates(control: Dict[str, Any], open_pos: Dict[str, Dict[str, Any]]) -> Tuple[List[Tuple[str, Dict[str, Any]]], Dict[str, int]]:  # type: ignore[override]
    c = dict(control or {})
    # 기존 control에 S/A/B가 남아 있어도 새 본선에서는 S1만 OPEN한다. 구 S는 기존 호환용으로만 허용한다.
    c['paper_open_grades'] = ['S1', 'S']
    picked, stats = _v097_prev_pick_candidates(c, open_pos)
    stats = dict(stats or {})
    for k in ('grade_s1_seen','grade_s2_seen','grade_s3_seen','grade_s1_open','grade_s2_recheck','grade_s3_observe'):
        stats.setdefault(k, 0)
    out=[]
    for pid, ev in picked:
        g = _v097_grade_value(ev)
        if g == 'S1':
            stats['grade_s1_seen'] += 1; stats['grade_s1_open'] += 1
            ev=dict(ev); ev['s_stage']='S1'; ev['candidate_grade']='S1'; ev['grade']='S1'; ev['paper_bot_open']=True; ev['open_eligible']=True; ev['trade_ready']=True
            out.append((pid, ev))
        elif g == 'S2':
            stats['grade_s2_seen'] += 1; stats['grade_s2_recheck'] += 1
        elif g == 'S3':
            stats['grade_s3_seen'] += 1; stats['grade_s3_observe'] += 1
    stats['s123_note'] = 'v0.97: S1만 OPEN, S2/S3는 재확인·관찰 trace'
    return out, stats

_v097_prev_build_score_cache = _v077_build_score_cache

def _v077_build_score_cache(reason: str = 'cycle') -> Dict[str, Any]:  # type: ignore[override]
    rows = _v085_current_closed_rows_fast()
    groups = _v077_group_by_grade(rows)
    open_pos = load_open(); status = load_json(FILES.get('status', BASE_DIR / 'paper_bot_status.json'), {})
    anchor = _v083_anchor()
    primary_stats = _v086_strategy_stats_primary(rows)
    overlap_stats = _v086_strategy_stats_overlap(rows)
    primary_total = _v086_sum_n(primary_stats); overlap_total = _v086_sum_n(overlap_stats)
    cache = {
        'schema': 'paper_score_cache_v086', 'version': VERSION, 'updated_at': now(), 'updated_at_text': iso_ts(), 'reason': reason,
        'score_scope': 'current_version_anchor', 'anchor_ts': anchor.get('anchor_ts'), 'anchor_text': anchor.get('anchor_text'),
        'source_tail_lines': max(V077_CACHE_TAIL_LINES, 1200), 'closed_file_size': FILES['closed'].stat().st_size if FILES['closed'].exists() else 0,
        'closed_total': closed_count(), 'current_closed_count': len(rows), 'open_total': len(open_pos),
        'open_grade_counts': Counter(_v097_grade_value(v) for v in open_pos.values() if isinstance(v, dict)),
        'loop_seconds': load_control().get('loop_seconds'), 'running': bool(load_control().get('running')),
        'pick_stats': status.get('pick_stats') if isinstance(status.get('pick_stats'), dict) else {},
        'grade_stats': {
            'S1': _v077_short_stat('✅ S1 즉시진입', groups.get('S1', [])),
            'S2': _v077_short_stat('⚠️ S2 재확인', groups.get('S2', [])),
            'S3': _v077_short_stat('❔ S3 관찰복기', groups.get('S3', [])),
            'X': _v077_short_stat('❌ 제외', groups.get('X', [])),
            'ALL': _v077_short_stat('현재판 전체', rows),
        },
        'reason_stats': _v077_reason_stats(rows), 'strategy_primary_stats': primary_stats, 'strategy_overlap_stats': overlap_stats,
        'strategy_s_stats': primary_stats, 'strategy_stats': primary_stats, 'strategy_primary_total': primary_total, 'strategy_overlap_total': overlap_total,
        'strategy_duplicate_extra': max(0, overlap_total - len(rows)),
        'note': 'v0.97: S1/S2/S3 성과판. 과거 S/A는 S1로, B/C는 S3로 호환 집계.',
    }
    save_json(FILES['score_cache'], cache)
    return cache

try:
    _v077_build_score_cache('startup_v097')
except Exception as exc:
    try: log_error('v097_startup_score_cache', exc)
    except Exception: pass


# =============================================================================
# paper_bot v0.99: S1 최종 진입 안전문
# - strategy_worker가 S1을 줬더라도 가격반응/체결지속/슬리피지/과열 검문이 비어 있으면 OPEN하지 않는다.
# - 막힌 후보는 삭제하지 않고 trace에 preopen_safety_blocked로 남긴다.
# =============================================================================
VERSION = "paper_bot_v0.102"

def _v098_ctx_metric(row: Dict[str, Any], *keys: str, default: float = -999.0) -> float:
    ctx = row.get('entry_context') if isinstance(row.get('entry_context'), dict) else {}
    snap = row.get('entry_snapshot') if isinstance(row.get('entry_snapshot'), dict) else {}
    flat = snap.get('flat') if isinstance(snap.get('flat'), dict) else {}
    for k in keys:
        for src in (row, ctx, flat):
            try:
                v = src.get(k)
                if v is not None and str(v).strip() not in {'', '-', 'None', 'nan'}:
                    return float(str(v).replace(',', '').replace('%',''))
            except Exception:
                pass
    return default

def _v098_has_metric(row: Dict[str, Any], *keys: str) -> bool:
    return _v098_ctx_metric(row, *keys, default=-999.0) != -999.0

def _v098_s1_safety(row: Dict[str, Any]) -> Tuple[bool, List[str]]:
    ctx = row.get('entry_context') if isinstance(row.get('entry_context'), dict) else {}
    stage = _v097_grade_value(row) if '_v097_grade_value' in globals() else str(row.get('candidate_grade') or '').upper()
    if stage != 'S1':
        return False, ['not_s1']
    buy = _v098_ctx_metric(row, 'buy_ratio', 'micro_trade_buy_ratio_30', default=0.0)
    buy1_known = _v098_has_metric(row, 'buy_ratio_1m', 'micro_buy_ratio_sustain_1m', 'buy_ratio_sustain')
    buy1 = _v098_ctx_metric(row, 'buy_ratio_1m', 'micro_buy_ratio_sustain_1m', 'buy_ratio_sustain', default=-1.0)
    spread = _v098_ctx_metric(row, 'spread_pct', 'micro_spread_pct', default=99.0)
    slip_known = _v098_has_metric(row, 'slippage_est_pct', 'expected_slippage_pct', 'tick_pct_est')
    slip = _v098_ctx_metric(row, 'slippage_est_pct', 'expected_slippage_pct', 'tick_pct_est', default=99.0)
    price_known = _v098_has_metric(row, 'price_reaction_score', 'price_recheck_pct', 'price_reaction_pct')
    price_react = _v098_ctx_metric(row, 'price_reaction_score', 'price_recheck_pct', 'price_reaction_pct', default=-999.0)
    ch1 = _v098_ctx_metric(row, 'change_1m', 'price_change_1m', default=0.0)
    ch3 = _v098_ctx_metric(row, 'change_3m', 'price_change_3m', default=0.0)
    ch5 = _v098_ctx_metric(row, 'change_5m', 'price_change_5m', default=0.0)
    ch15 = _v098_ctx_metric(row, 'change_15m', 'price_change_15m', default=0.0)
    vwap = _v098_ctx_metric(row, 'vwap_gap_pct', default=0.0)
    ema = _v098_ctx_metric(row, 'ema5_gap_pct', 'ma5_gap_pct', default=0.0)
    day = _v098_ctx_metric(row, 'day_pos_pct', default=50.0)
    high_gap = _v098_ctx_metric(row, 'recent_high_gap_pct', default=-9.0)
    rel = _v098_ctx_metric(row, 'relative_strength_pct', 'relative_strength', default=0.0)
    micro = bool(row.get('micro_fresh') or ctx.get('micro_fresh'))
    ws = bool(row.get('ws_fresh') or row.get('quote_fresh') or ctx.get('ws_fresh') or ctx.get('quote_fresh'))
    reasons=[]
    if not micro: reasons.append('micro미신선')
    if not ws: reasons.append('WS미신선')
    if not price_known or price_react < 0.05: reasons.append('가격반응미확인/부족')
    if not buy1_known or buy1 < 0.64: reasons.append('매수체결지속미확인/부족')
    if buy < 0.70: reasons.append('매수체결우세부족')
    if spread > 0.18: reasons.append('스프레드주의')
    if not slip_known or slip > 0.20: reasons.append('슬리피지미확인/주의')
    if day >= 90 and high_gap >= -0.20 and (not price_known or price_react < 0.08): reasons.append('고점권가격반응부족')
    if (ch5 >= 6.0 and (ema >= 3.0 or vwap >= 0.8)) or ch15 >= 12.0 or ema >= 8.0: reasons.append('급등과열/과이격')
    if str(row.get('strategy_key') or row.get('strategy_bucket_primary') or '').lower() == 'money_reaccel_s' and rel < 0 and ch5 < 5.0: reasons.append('상대강도음수')
    return (len(reasons) == 0), reasons

_v098_prev_pick_candidates = pick_candidates

def pick_candidates(control: Dict[str, Any], open_pos: Dict[str, Dict[str, Any]]) -> Tuple[List[Tuple[str, Dict[str, Any]]], Dict[str, int]]:  # type: ignore[override]
    picked, stats = _v098_prev_pick_candidates(control, open_pos)
    stats = dict(stats or {})
    safe=[]; blocked=[]
    for pid, ev in picked:
        ok, why = _v098_s1_safety(ev)
        if ok:
            safe.append((pid, ev))
        else:
            ev2 = dict(ev)
            ev2['s_stage'] = 'S2'
            ev2['candidate_grade'] = 'S2'
            ev2['grade'] = 'S2'
            ev2['paper_bot_open'] = False
            ev2['open_eligible'] = False
            ev2['trade_ready'] = False
            ev2['s1_block_reasons'] = why[:8]
            if '_v091_trace_row' in globals():
                blocked.append(_v091_trace_row(ev2, 's2_recheck', 'S1안전문차단:' + ','.join(map(str, why[:5]))))
    if blocked and '_v094_save_actual_trace' in globals():
        try:
            actual = list(_v094_actual_trace_rows() if '_v094_actual_trace_rows' in globals() else [])
            _v094_save_actual_trace('pick_candidates_v098_s1_safety', actual + blocked)
        except Exception as exc:
            try: log_error('v098_trace_s1_block', exc)
            except Exception: pass
    stats['v098_s1_safety_blocked'] = len(blocked)
    stats['v098_s1_safety_open'] = len(safe)
    stats['s123_note'] = 'v0.98: S1 안전문 통과 후보만 OPEN, 차단 후보는 S2 trace'
    return safe, stats

try:
    _v077_build_score_cache('startup_v098')
except Exception as exc:
    try: log_error('v098_startup_score_cache', exc)
    except Exception: pass



# =============================================================================
# paper_bot v0.100: trace stale 제거 + 버전별 score 보조 메타
# - S1이 0개인 cycle에서도 paper_bot_candidate_handoff_trace.json을 현재 VERSION으로 갱신한다.
# - 구 v0.92 trace가 남아 /missed_trace에 과거 expired 300개가 섞이는 문제를 막는다.
# - 장부/전략/청산 조건은 변경하지 않는다.
# =============================================================================
VERSION = "paper_bot_v0.102"

_v100_prev_run_cycle = run_cycle

def _v100_refresh_actual_trace(reason: str = "v100_trace_refresh") -> None:
    try:
        rows = _v094_actual_trace_rows() if '_v094_actual_trace_rows' in globals() else []
        _v094_save_actual_trace(reason, rows) if '_v094_save_actual_trace' in globals() else save_json(FILES.get('candidate_handoff_trace', BASE_DIR/'paper_bot_candidate_handoff_trace.json'), {"version": VERSION, "updated_at": now(), "updated_at_text": iso_ts(), "reason": reason, "trace_count": 0, "rows": []})
    except Exception as exc:
        try: log_error('v100_trace_refresh', exc)
        except Exception: pass

def run_cycle() -> Dict[str, Any]:  # type: ignore[override]
    res = _v100_prev_run_cycle()
    _v100_refresh_actual_trace('run_cycle_v100_clear_stale_trace')
    try:
        _v096_refresh_score_cache('run_cycle_v100_score') if '_v096_refresh_score_cache' in globals() else _v077_build_score_cache('run_cycle_v100_score')
    except Exception as exc:
        try: log_error('v100_score_refresh', exc)
        except Exception: pass
    return res

try:
    _v100_refresh_actual_trace('startup_v100_clear_stale_trace')
    _v096_refresh_score_cache('startup_v100_score') if '_v096_refresh_score_cache' in globals() else _v077_build_score_cache('startup_v100_score')
except Exception as exc:
    try: log_error('v100_startup', exc)
    except Exception: pass



# =============================================================================
# paper_bot v0.101 / v368: trace source/archive fallback 차단 + main_version 보존
# - v0.92/v0.93 source trace 경로를 pick 본선에서 우회한다.
# - /missed_trace는 이번 cycle actual pick/skip/S2/S3 trace만 저장한다.
# - 오래된 archive 300개 expired 재표시는 기본에서 금지한다.
# =============================================================================
VERSION = "paper_bot_v0.102"


def _v368_save_actual_trace(reason: str, rows: Optional[List[Dict[str, Any]]] = None) -> None:
    try:
        actual = list(rows if rows is not None else (list(_V091_LAST_TRACE_ROWS or []) if '_V091_LAST_TRACE_ROWS' in globals() else []))
        clean=[]
        for r in actual:
            if not isinstance(r, dict):
                continue
            # source/archive fallback 흔적은 여기서 끊는다.
            src=str(r.get('handoff_source') or r.get('source') or '')
            if src in {'archive','latest','merged'} and str(r.get('status')) in {'expired','not_merged'}:
                continue
            r=dict(r); r['trace_version']=VERSION
            clean.append(r)
        if '_v094_dedupe_actual_trace' in globals():
            clean=_v094_dedupe_actual_trace(clean)
        path=FILES.get('candidate_handoff_trace', BASE_DIR/'paper_bot_candidate_handoff_trace.json')
        save_json(path, {"version":VERSION,"updated_at":now(),"updated_at_text":iso_ts(),"reason":reason,"trace_count":len(clean),"rows":clean[:120],"note":"v0.101/v368 actual trace only; source/archive fallback disabled"})
    except Exception as exc:
        try: log_error('v368_save_actual_trace', exc)
        except Exception: pass


def _v368_stamp_candidate(ev: Dict[str, Any]) -> Dict[str, Any]:
    ev=dict(ev or {})
    mv=str(ev.get('main_version') or ev.get('deploy_version') or '')
    ctx=ev.get('entry_context') if isinstance(ev.get('entry_context'), dict) else {}
    if not mv:
        mv=str(ctx.get('main_version') or ctx.get('deploy_version') or 'v2.13.368')
    ev['main_version']=mv; ev['deploy_version']=mv
    ctx['main_version']=mv; ctx['deploy_version']=mv; ctx['paper_bot_version']=VERSION
    ev['entry_context']=ctx
    return ev


def _v368_pick_base(control: Dict[str, Any], open_pos: Dict[str, Dict[str, Any]]) -> Tuple[List[Tuple[str, Dict[str, Any]]], Dict[str, int]]:
    # v0.92/v0.93 source trace wrapper를 타지 않고 v0.91 실제 선별 본선으로 돌아간다.
    base = globals().get('_v092_prev_pick_candidates') or globals().get('_v093_prev_pick_candidates') or globals().get('_v094_prev_pick_candidates')
    if callable(base):
        return base(control, open_pos)
    return _v100_prev_run_cycle(control, open_pos)  # type: ignore[misc]


def pick_candidates(control: Dict[str, Any], open_pos: Dict[str, Dict[str, Any]]) -> Tuple[List[Tuple[str, Dict[str, Any]]], Dict[str, int]]:  # type: ignore[override]
    picked, stats = _v368_pick_base(control, open_pos)
    stats=dict(stats or {})
    safe=[]; trace=[]
    # base가 남긴 actual trace만 가져온다.
    try:
        trace.extend(list(_V091_LAST_TRACE_ROWS or []))
    except Exception:
        pass
    for pid, ev in picked:
        ev=_v368_stamp_candidate(ev)
        ok, why = _v098_s1_safety(ev) if '_v098_s1_safety' in globals() else (True, [])
        if ok:
            safe.append((pid, ev))
        else:
            ev2=dict(ev); ev2.update({'s_stage':'S2','candidate_grade':'S2','grade':'S2','paper_bot_open':False,'open_eligible':False,'trade_ready':False,'s1_block_reasons':why[:8]})
            if '_v091_trace_row' in globals():
                trace.append(_v091_trace_row(ev2, 's2_recheck', 'S1안전문차단:' + ','.join(map(str, why[:5]))))
    stats['v368_s1_open']=len(safe); stats['v368_s1_to_s2_blocked']=max(0, len(picked)-len(safe)); stats['s123_note']='v0.101/v368: actual trace only, S1 safety preserved'
    _v368_save_actual_trace('pick_candidates_v368_actual_only', trace)
    return safe, stats


def _v090_write_handoff_trace(reason: str = "cycle") -> None:  # type: ignore[override]
    _v368_save_actual_trace(f'{reason}_v368_actual_only')

_v368_prev_run_cycle = run_cycle

def run_cycle() -> Dict[str, Any]:  # type: ignore[override]
    res=_v368_prev_run_cycle()
    _v368_save_actual_trace('run_cycle_v368_actual_only')
    try:
        _v096_refresh_score_cache('run_cycle_v368_score') if '_v096_refresh_score_cache' in globals() else _v077_build_score_cache('run_cycle_v368_score')
    except Exception as exc:
        try: log_error('v368_score_refresh', exc)
        except Exception: pass
    return res

try:
    _v368_save_actual_trace('startup_v368_actual_only', [])
    _v096_refresh_score_cache('startup_v368_score') if '_v096_refresh_score_cache' in globals() else _v077_build_score_cache('startup_v368_score')
except Exception as exc:
    try: log_error('v368_startup', exc)
    except Exception: pass



# =============================================================================
# paper_bot v0.102 / v369: selected→OPEN 단일 배관 수술
# - base pick trace의 selected_for_open이 최종 OPEN 여부를 오염시키던 구경로를 끊는다.
# - S1 안전문 통과 후보만 OPEN 대상으로 반환하고, S1 차단/S2/S3는 trace에만 남긴다.
# - run_cycle 후에도 archive/source fallback이 trace를 덮지 못하게 v369 trace만 저장한다.
# =============================================================================
VERSION = "paper_bot_v0.102"
_V369_LAST_TRACE_ROWS: List[Dict[str, Any]] = []


def _v369_trace_row(ev: Dict[str, Any], status: str, reason: str) -> Dict[str, Any]:
    if '_v091_trace_row' in globals():
        try:
            row = _v091_trace_row(ev, status, reason)
        except Exception:
            row = {}
    else:
        row = {}
    if not isinstance(row, dict):
        row = {}
    row.update({
        'ticker': short_ticker(ev.get('ticker') or ev.get('market') or ev.get('symbol')) if 'short_ticker' in globals() else str(ev.get('ticker') or ''),
        'strategy': ev.get('strategy_label') or ev.get('strategy_bucket_label') or ev.get('strategy_key'),
        'strategy_key': ev.get('strategy_key') or ev.get('strategy_bucket_primary'),
        'score': ev.get('score'),
        'status': status,
        'reason': reason,
        'trace_version': VERSION,
        'main_version': ev.get('main_version') or (ev.get('entry_context') if isinstance(ev.get('entry_context'), dict) else {}).get('main_version') or 'v2.13.369',
    })
    return row


def _v369_load_stage_observe_rows(control: Dict[str, Any], limit: int = 120) -> List[Dict[str, Any]]:
    """candidate file 안의 S2/S3를 OPEN하지 않고 trace/요약용으로만 살린다."""
    out: List[Dict[str, Any]] = []
    try:
        path = candidate_input_path('strict') if 'candidate_input_path' in globals() else FILES.get('paper_latest', BASE_DIR/'paper_candidates_latest.jsonl')
        rows = read_jsonl(path, max_lines=int(float_any(control.get('candidate_read_max_lines'), default=1500)))
        for ev in rows:
            if not isinstance(ev, dict):
                continue
            try:
                evn = _v080_normalize_candidate(ev, control) if '_v080_normalize_candidate' in globals() else dict(ev)
            except Exception:
                evn = dict(ev)
            g = _v097_grade_value(evn) if '_v097_grade_value' in globals() else str(evn.get('candidate_grade') or '').upper()
            if g == 'S2':
                out.append(_v369_trace_row(evn, 's2_recheck', 'S2재확인대기'))
            elif g == 'S3':
                out.append(_v369_trace_row(evn, 's3_observe', 'S3관찰복기'))
            if len(out) >= limit:
                break
    except Exception as exc:
        try: log_error('v369_stage_observe_rows', exc)
        except Exception: pass
    return out


def _v369_save_trace(reason: str, rows: Optional[List[Dict[str, Any]]] = None) -> None:
    global _V369_LAST_TRACE_ROWS
    try:
        src = list(rows if rows is not None else _V369_LAST_TRACE_ROWS)
        clean=[]
        seen=set()
        for r in src:
            if not isinstance(r, dict):
                continue
            st=str(r.get('status') or '')
            # 구 archive/source expired/not_merged 대량 재표시 경로 차단
            source=str(r.get('handoff_source') or r.get('source') or '')
            if source in {'archive','latest','merged'} and st in {'expired','not_merged'}:
                continue
            key=(str(r.get('ticker') or ''), str(r.get('strategy_key') or r.get('strategy') or ''), st, str(r.get('reason') or ''))
            if key in seen:
                continue
            seen.add(key)
            rr=dict(r); rr['trace_version']=VERSION
            clean.append(rr)
        _V369_LAST_TRACE_ROWS = clean[:120]
        path=FILES.get('candidate_handoff_trace', BASE_DIR/'paper_bot_candidate_handoff_trace.json')
        status_counter={}; reason_counter={}
        for r in _V369_LAST_TRACE_ROWS:
            status_counter[str(r.get('status') or 'unknown')] = status_counter.get(str(r.get('status') or 'unknown'),0)+1
            for x in str(r.get('reason') or '').split(','):
                x=x.strip()
                if x:
                    reason_counter[x]=reason_counter.get(x,0)+1
        save_json(path, {
            'version': VERSION, 'updated_at': now(), 'updated_at_text': iso_ts(), 'reason': reason,
            'trace_count': len(_V369_LAST_TRACE_ROWS),
            'status_top': [{'status':k,'count':v} for k,v in sorted(status_counter.items(), key=lambda x:x[1], reverse=True)[:12]],
            'reason_top': [{'reason':k,'count':v} for k,v in sorted(reason_counter.items(), key=lambda x:x[1], reverse=True)[:12]],
            'rows': _V369_LAST_TRACE_ROWS,
            'note': 'v0.102/v369: selected/open trace single path; archive fallback disabled'
        })
    except Exception as exc:
        try: log_error('v369_save_trace', exc)
        except Exception: pass


def _v368_save_actual_trace(reason: str, rows: Optional[List[Dict[str, Any]]] = None) -> None:  # type: ignore[override]
    _v369_save_trace(reason, rows if rows is not None else _V369_LAST_TRACE_ROWS)


def _v090_write_handoff_trace(reason: str = 'cycle') -> None:  # type: ignore[override]
    _v369_save_trace(f'{reason}_v369')


def pick_candidates(control: Dict[str, Any], open_pos: Dict[str, Dict[str, Any]]) -> Tuple[List[Tuple[str, Dict[str, Any]]], Dict[str, int]]:  # type: ignore[override]
    global _V369_LAST_TRACE_ROWS
    # v0.92/v0.93의 source/archive trace wrapper를 타지 않고 실제 선별 base만 사용한다.
    base = globals().get('_v092_prev_pick_candidates') or globals().get('_v091_base_pick_candidates') or globals().get('_v097_prev_pick_candidates')
    if not callable(base):
        base = globals().get('_v368_pick_base')
    try:
        raw_picked, stats = base(control, open_pos) if callable(base) else ([], {})
    except Exception as exc:
        try: log_error('v369_base_pick', exc)
        except Exception: pass
        raw_picked, stats = [], {}
    stats=dict(stats or {})
    safe=[]; trace=[]
    # S2/S3 관찰 후보는 OPEN하지 않고 trace에만 남긴다.
    observe_rows=_v369_load_stage_observe_rows(control)
    trace.extend(observe_rows)
    for pid, ev in raw_picked:
        ev = _v368_stamp_candidate(ev) if '_v368_stamp_candidate' in globals() else dict(ev)
        g = _v097_grade_value(ev) if '_v097_grade_value' in globals() else str(ev.get('candidate_grade') or '').upper()
        if g not in {'S1','S'}:
            trace.append(_v369_trace_row(ev, 's2_recheck' if g == 'S2' else 's3_observe', f'{g}_not_open'))
            continue
        ok, why = _v098_s1_safety(ev) if '_v098_s1_safety' in globals() else (True, [])
        if ok:
            ev=dict(ev); ev.update({'s_stage':'S1','candidate_grade':'S1','grade':'S1','paper_bot_open':True,'open_eligible':True,'trade_ready':True})
            safe.append((pid, ev))
            trace.append(_v369_trace_row(ev, 'selected_for_open', 'S1안전문통과'))
        else:
            ev2=dict(ev); ev2.update({'s_stage':'S2','candidate_grade':'S2','grade':'S2','paper_bot_open':False,'open_eligible':False,'trade_ready':False,'s1_block_reasons':why[:8]})
            trace.append(_v369_trace_row(ev2, 's2_recheck', 'S1안전문차단:' + ','.join(map(str, why[:5]))))
    stats['v369_s1_selected']=len(safe)
    stats['v369_s2_trace']=sum(1 for r in trace if str(r.get('status'))=='s2_recheck')
    stats['v369_s3_trace']=sum(1 for r in trace if str(r.get('status'))=='s3_observe')
    stats['v369_trace_rows']=len(trace)
    stats['s123_note']='v0.102/v369: S1만 OPEN, S2/S3는 trace/요약, archive fallback 차단'
    _V369_LAST_TRACE_ROWS=trace[:120]
    _v369_save_trace('pick_candidates_v369', _V369_LAST_TRACE_ROWS)
    return safe, stats


_v369_prev_run_cycle = run_cycle

def run_cycle() -> Dict[str, Any]:  # type: ignore[override]
    res = _v369_prev_run_cycle()
    try:
        st = load_json(FILES.get('status', BASE_DIR/'paper_bot_status.json'), {}) or {}
        st['version'] = VERSION
        st['active_reader_version'] = VERSION
        st['trace_version'] = VERSION
        st['updated_at'] = now(); st['updated_at_text'] = iso_ts()
        save_json(FILES.get('status', BASE_DIR/'paper_bot_status.json'), st)
    except Exception as exc:
        try: log_error('v369_status_version', exc)
        except Exception: pass
    _v369_save_trace('run_cycle_v369_final')
    try:
        _v096_refresh_score_cache('run_cycle_v369_score') if '_v096_refresh_score_cache' in globals() else _v077_build_score_cache('run_cycle_v369_score')
    except Exception as exc:
        try: log_error('v369_score_refresh', exc)
        except Exception: pass
    return res

try:
    _v369_save_trace('startup_v369_clear', [])
    st = load_json(FILES.get('status', BASE_DIR/'paper_bot_status.json'), {}) or {}
    st.update({'version': VERSION, 'active_reader_version': VERSION, 'trace_version': VERSION, 'updated_at': now(), 'updated_at_text': iso_ts(), 'startup_status': True})
    save_json(FILES.get('status', BASE_DIR/'paper_bot_status.json'), st)
    _v096_refresh_score_cache('startup_v369_score') if '_v096_refresh_score_cache' in globals() else _v077_build_score_cache('startup_v369_score')
except Exception as exc:
    try: log_error('v369_startup', exc)
    except Exception: pass


# =============================================================================
# paper_bot v0.103 / v371: S1 OPEN grade control 단일화 수술
# - v0.102 final picker intentionally bypassed old source/archive wrappers, but it
#   called the old base picker with the raw saved control.
# - Old saved control can still contain paper_open_grades=["S","A"], so fresh S1
#   rows from strategy_worker_v0.22 were read but not picked for OPEN.
# - This block keeps the v369 actual-trace policy and forces the final pick control
#   to S1/S only before calling the base picker. S2/S3 remain trace-only.
# =============================================================================
VERSION = "paper_bot_v0.103"


def _v371_pick_control(control: Dict[str, Any]) -> Dict[str, Any]:
    c = dict(control or {})
    c['paper_open_grades'] = ['S1', 'S']
    c['open_trade_ready_only'] = True
    c['open_shadow_positions'] = False
    c['shadow_review_only'] = True
    return c


def pick_candidates(control: Dict[str, Any], open_pos: Dict[str, Dict[str, Any]]) -> Tuple[List[Tuple[str, Dict[str, Any]]], Dict[str, int]]:  # type: ignore[override]
    global _V369_LAST_TRACE_ROWS
    # 구 trace/source wrapper는 계속 우회한다. 단, base picker에는 S1/S 허용 control만 넘긴다.
    base = globals().get('_v092_prev_pick_candidates') or globals().get('_v091_base_pick_candidates') or globals().get('_v097_prev_pick_candidates')
    if not callable(base):
        base = globals().get('_v368_pick_base')
    pick_control = _v371_pick_control(control)
    try:
        raw_picked, stats = base(pick_control, open_pos) if callable(base) else ([], {})
    except Exception as exc:
        try: log_error('v371_base_pick', exc)
        except Exception: pass
        raw_picked, stats = [], {}
    stats = dict(stats or {})
    safe: List[Tuple[str, Dict[str, Any]]] = []
    trace: List[Dict[str, Any]] = []
    observe_rows = _v369_load_stage_observe_rows(pick_control) if '_v369_load_stage_observe_rows' in globals() else []
    trace.extend(observe_rows)
    for pid, ev in raw_picked:
        ev = _v368_stamp_candidate(ev) if '_v368_stamp_candidate' in globals() else dict(ev)
        g = _v097_grade_value(ev) if '_v097_grade_value' in globals() else str(ev.get('s_stage') or ev.get('candidate_grade') or ev.get('grade') or '').upper()
        if g == 'S':
            g = 'S1'
        if g != 'S1':
            trace.append(_v369_trace_row(ev, 's2_recheck' if g == 'S2' else 's3_observe', f'{g}_not_open'))
            continue
        ok, why = _v098_s1_safety(ev) if '_v098_s1_safety' in globals() else (True, [])
        if ok:
            ev = dict(ev)
            ev.update({
                's_stage': 'S1', 'candidate_grade': 'S1', 'grade': 'S1',
                'paper_bot_open': True, 'open_eligible': True, 'trade_ready': True,
                'paper_pick_version': VERSION,
            })
            safe.append((pid, ev))
            trace.append(_v369_trace_row(ev, 'selected_for_open', 'S1안전문통과'))
        else:
            ev2 = dict(ev)
            ev2.update({
                's_stage': 'S2', 'candidate_grade': 'S2', 'grade': 'S2',
                'paper_bot_open': False, 'open_eligible': False, 'trade_ready': False,
                's1_block_reasons': why[:8], 'paper_pick_version': VERSION,
            })
            trace.append(_v369_trace_row(ev2, 's2_recheck', 'S1안전문차단:' + ','.join(map(str, why[:5]))))
    stats['v369_s1_selected'] = len(safe)  # main /pstatus 호환 표시 유지
    stats['v371_s1_selected'] = len(safe)
    stats['v369_s2_trace'] = sum(1 for r in trace if str(r.get('status')) == 's2_recheck')
    stats['v369_s3_trace'] = sum(1 for r in trace if str(r.get('status')) == 's3_observe')
    stats['v369_trace_rows'] = len(trace)
    stats['v371_open_grade_control'] = 'S1,S'
    stats['s123_note'] = 'v0.103/v371: S1/S open grade control fixed, S2/S3 trace only, archive fallback disabled'
    _V369_LAST_TRACE_ROWS = trace[:120]
    _v369_save_trace('pick_candidates_v371_s1_grade_control', _V369_LAST_TRACE_ROWS)
    return safe, stats


_v371_prev_run_cycle = run_cycle


def run_cycle() -> Dict[str, Any]:  # type: ignore[override]
    res = _v371_prev_run_cycle()
    try:
        st = load_json(FILES.get('status', BASE_DIR/'paper_bot_status.json'), {}) or {}
        st['version'] = VERSION
        st['active_reader_version'] = VERSION
        st['trace_version'] = VERSION
        st['paper_pick_fix'] = 'v371_s1_open_grade_control'
        st['updated_at'] = now(); st['updated_at_text'] = iso_ts()
        save_json(FILES.get('status', BASE_DIR/'paper_bot_status.json'), st)
    except Exception as exc:
        try: log_error('v371_status_version', exc)
        except Exception: pass
    try:
        _v369_save_trace('run_cycle_v371_final')
    except Exception as exc:
        try: log_error('v371_trace_refresh', exc)
        except Exception: pass
    try:
        _v096_refresh_score_cache('run_cycle_v371_score') if '_v096_refresh_score_cache' in globals() else _v077_build_score_cache('run_cycle_v371_score')
    except Exception as exc:
        try: log_error('v371_score_refresh', exc)
        except Exception: pass
    return res

try:
    st = load_json(FILES.get('status', BASE_DIR/'paper_bot_status.json'), {}) or {}
    st.update({'version': VERSION, 'active_reader_version': VERSION, 'trace_version': VERSION, 'paper_pick_fix': 'v371_s1_open_grade_control', 'updated_at': now(), 'updated_at_text': iso_ts(), 'startup_status': True})
    save_json(FILES.get('status', BASE_DIR/'paper_bot_status.json'), st)
    _v096_refresh_score_cache('startup_v371_score') if '_v096_refresh_score_cache' in globals() else _v077_build_score_cache('startup_v371_score')
except Exception as exc:
    try: log_error('v371_startup', exc)
    except Exception: pass



# =============================================================================
# paper_bot v0.104 / v372: worker_loop latest run_cycle 재연결 수술
# - v0.50 worker_loop는 속도 개선을 위해 _v050_original_run_cycle() 포인터를 호출한다.
# - 이후 v0.102/v0.103에서 run_cycle을 감싸 S1 trace/cache/status를 갱신했지만,
#   worker_loop가 오래된 포인터를 계속 물면 /pstatus score cache가 오래되고
#   후보읽음/S1선택/실제OPEN 집계가 갱신되지 않는다.
# - 새 fallback을 붙이지 않고, worker_loop가 호출하는 포인터를 최종 run_cycle(v0.103 포함)로
#   다시 연결한다. 장부/청산/조건/자동매수는 변경하지 않는다.
# =============================================================================
VERSION = "paper_bot_v0.104"

try:
    _v372_final_run_cycle = run_cycle
    # v0.50 worker_loop 내부가 이 전역 이름을 호출하므로, 함수 본문을 새로 덧붙이지 않고
    # 포인터만 최종 run_cycle로 재연결한다.
    if '_v050_original_run_cycle' in globals():
        _v050_original_run_cycle = _v372_final_run_cycle  # type: ignore[assignment]
except Exception as exc:
    try: log_error('v372_rebind_worker_loop_run_cycle', exc)
    except Exception: pass

try:
    st = load_json(FILES.get('status', BASE_DIR/'paper_bot_status.json'), {}) or {}
    st.update({
        'version': VERSION,
        'active_reader_version': VERSION,
        'trace_version': VERSION,
        'paper_pick_fix': 'v371_s1_open_grade_control',
        'worker_loop_fix': 'v372_rebind_v050_original_run_cycle_to_final_run_cycle',
        'updated_at': now(),
        'updated_at_text': iso_ts(),
        'startup_status': True,
    })
    save_json(FILES.get('status', BASE_DIR/'paper_bot_status.json'), st)
    try:
        _v096_refresh_score_cache('startup_v372_score') if '_v096_refresh_score_cache' in globals() else _v077_build_score_cache('startup_v372_score')
    except Exception as exc:
        try: log_error('v372_startup_score', exc)
        except Exception: pass
except Exception as exc:
    try: log_error('v372_startup', exc)
    except Exception: pass


# =============================================================================
# paper_bot v0.105 / v373: final picker 단일 본선 수술
# - v0.91 base picker가 내부 trace에 picked/selected_for_open을 먼저 써서,
#   최종 S1 안전문/OPEN 결과와 trace가 어긋나는 문제가 있었다.
# - 이제 paper pick은 base picker를 호출하지 않고, 최신 merged handoff를 직접 읽어
#   S1 안전문 통과 후보만 반환한다.
# - S2/S3는 OPEN하지 않고 trace/복기만 남긴다.
# - 장부/청산/자동매수/전략조건은 변경하지 않는다.
# =============================================================================
VERSION = "paper_bot_v0.106"


def _v373_allow_open_grade(ev: Dict[str, Any]) -> str:
    try:
        g = _v097_grade_value(ev) if '_v097_grade_value' in globals() else str(ev.get('s_stage') or ev.get('candidate_grade') or ev.get('grade') or '').upper()
    except Exception:
        g = str(ev.get('s_stage') or ev.get('candidate_grade') or ev.get('grade') or '').upper()
    if g == 'S':
        return 'S1'
    return g or 'S3'


def _v373_read_handoff_rows(control: Dict[str, Any]) -> List[Dict[str, Any]]:
    """paper가 실제로 OPEN 판단할 handoff 최신 병합본만 읽는다. 구 trace/source picker는 타지 않는다."""
    try:
        # candidate_input_path('strict')는 v0.91 병합 파일 생성만 담당한다. pick trace는 저장하지 않는다.
        path = candidate_input_path('strict') if 'candidate_input_path' in globals() else FILES.get('paper_latest', BASE_DIR/'paper_candidates_latest.jsonl')
        max_lines = int(float_any(control.get('candidate_read_max_lines'), default=1500))
        rows = read_jsonl(path, max_lines=max_lines)
    except Exception as exc:
        try: log_error('v373_read_handoff_rows', exc)
        except Exception: pass
        rows = []
    out: List[Dict[str, Any]] = []
    for r in rows:
        if not isinstance(r, dict):
            continue
        try:
            out.append(_v080_normalize_candidate(r, control) if '_v080_normalize_candidate' in globals() else dict(r))
        except Exception:
            out.append(dict(r))
    return out


def pick_candidates(control: Dict[str, Any], open_pos: Dict[str, Dict[str, Any]]) -> Tuple[List[Tuple[str, Dict[str, Any]]], Dict[str, int]]:  # type: ignore[override]
    global _V369_LAST_TRACE_ROWS
    control = _v371_pick_control(control) if '_v371_pick_control' in globals() else dict(control or {})
    picked: List[Tuple[str, Dict[str, Any]]] = []
    trace: List[Dict[str, Any]] = []
    stats: Dict[str, Any] = {
        'paper_file': 0,
        'v369_s1_selected': 0,
        'v371_s1_selected': 0,
        'v373_s1_selected': 0,
        'v373_s1_safety_blocked': 0,
        'v369_s2_trace': 0,
        'v369_s3_trace': 0,
        'v369_trace_rows': 0,
        'stale_skip': 0,
        'micro_preopen_wait': 0,
        'dup_skip': 0,
        'same_ticker_skip': 0,
        'bad_skip': 0,
        'limit_skip': 0,
        'not_trade_ready_skip': 0,
        'new_open_paused': 0,
        'v373_final_picker': True,
    }
    if control.get('new_open_paused', True):
        stats['new_open_paused'] = 1
        _V369_LAST_TRACE_ROWS = []
        _v369_save_trace('v373_new_open_paused', []) if '_v369_save_trace' in globals() else None
        return [], stats

    rows = _v373_read_handoff_rows(control)
    stats['paper_file'] = len(rows)
    existing_ids = set(open_pos.keys()) | (load_closed_ids() if 'load_closed_ids' in globals() else set())
    blocked_tickers = open_tickers(open_pos) if control.get('block_same_ticker_open', True) else set()
    lane_counts = count_by_lane(open_pos) if 'count_by_lane' in globals() else {}
    max_strict = int(float_any(control.get('max_open_strict'), default=0)); strict_cap_on = max_strict > 0
    max_new = int(float_any(control.get('max_new_per_cycle'), default=0)); new_cap_on = max_new > 0
    micro_wait_rows: List[Dict[str, Any]] = []
    gate_map = _v066_recent_loss_gate_map() if '_v066_recent_loss_gate_map' in globals() else {}

    # S2/S3 관찰 후보를 먼저 살려 trace에 남긴다. OPEN에는 태우지 않는다.
    try:
        trace.extend(_v369_load_stage_observe_rows(control) if '_v369_load_stage_observe_rows' in globals() else [])
    except Exception as exc:
        try: log_error('v373_stage_observe_rows', exc)
        except Exception: pass

    for ev in rows:
        if new_cap_on and len(picked) >= max_new:
            stats['limit_skip'] += 1
            trace.append(_v369_trace_row(ev, 'skipped', 'max_new_limit') if '_v369_trace_row' in globals() else {'ticker': ev.get('ticker'), 'status':'skipped', 'reason':'max_new_limit'})
            continue
        if strict_cap_on and int(lane_counts.get('strict', 0) or 0) >= max_strict:
            stats['limit_skip'] += 1
            trace.append(_v369_trace_row(ev, 'skipped', 'strict_open_limit') if '_v369_trace_row' in globals() else {'ticker': ev.get('ticker'), 'status':'skipped', 'reason':'strict_open_limit'})
            continue
        if not candidate_is_fresh(ev, control):
            stats['stale_skip'] += 1
            trace.append(_v369_trace_row(ev, 'expired', 'handoff만료,후보오래됨') if '_v369_trace_row' in globals() else {'ticker': ev.get('ticker'), 'status':'expired', 'reason':'handoff만료,후보오래됨'})
            continue
        g = _v373_allow_open_grade(ev)
        if g == 'S2':
            stats['v369_s2_trace'] += 1
            trace.append(_v369_trace_row(ev, 's2_recheck', 'S2재확인대기') if '_v369_trace_row' in globals() else {'ticker': ev.get('ticker'), 'status':'s2_recheck', 'reason':'S2재확인대기'})
            continue
        if g == 'S3':
            stats['v369_s3_trace'] += 1
            trace.append(_v369_trace_row(ev, 's3_observe', 'S3관찰복기') if '_v369_trace_row' in globals() else {'ticker': ev.get('ticker'), 'status':'s3_observe', 'reason':'S3관찰복기'})
            continue
        if g != 'S1':
            trace.append(_v369_trace_row(ev, 'skipped', f'grade_{g}_not_open') if '_v369_trace_row' in globals() else {'ticker': ev.get('ticker'), 'status':'skipped', 'reason':f'grade_{g}_not_open'})
            continue
        if control.get('open_trade_ready_only', True):
            can_open = bool(ev.get('paper_bot_open') or ev.get('open_eligible') or ev.get('trade_ready'))
            if not can_open:
                stats['not_trade_ready_skip'] += 1
                trace.append(_v369_trace_row(ev, 'skipped', 'open_eligible_false') if '_v369_trace_row' in globals() else {'ticker': ev.get('ticker'), 'status':'skipped', 'reason':'open_eligible_false'})
                continue
        if control.get('preopen_micro_recheck', True) and bool(ev.get('paper_bot_open') or ev.get('open_eligible') or ev.get('trade_ready')):
            if not _event_micro_is_fresh(ev):
                stats['micro_preopen_wait'] += 1
                micro_wait_rows.append(dict(ev))
                trace.append(_v369_trace_row(ev, 'micro_wait', 'micro미확인') if '_v369_trace_row' in globals() else {'ticker': ev.get('ticker'), 'status':'micro_wait', 'reason':'micro미확인'})
                continue
        try:
            ev = _v368_stamp_candidate(ev) if '_v368_stamp_candidate' in globals() else dict(ev)
        except Exception:
            ev = dict(ev)
        ok, why = _v098_s1_safety(ev) if '_v098_s1_safety' in globals() else (True, [])
        if not ok:
            stats['v373_s1_safety_blocked'] += 1
            status2, reason2, info_shortage = _v374_safety_trace_status_reason(why) if '_v374_safety_trace_status_reason' in globals() else ('s2_recheck', 'S1안전문차단:' + ','.join(map(str, why[:5])), False)
            if info_shortage:
                stats['v374_s1_info_wait'] = int(stats.get('v374_s1_info_wait', 0) or 0) + 1
            ev2 = dict(ev)
            ev2.update({'s_stage':'S2','candidate_grade':'S2','grade':'S2','paper_bot_open':False,'open_eligible':False,'trade_ready':False,'s1_block_reasons':why[:8], 'info_shortage_pending': bool(info_shortage), 'urgent_recheck_needed': bool(info_shortage), 'paper_pick_version': VERSION})
            if info_shortage:
                micro_wait_rows.append(dict(ev2))
            trace.append(_v369_trace_row(ev2, status2, reason2) if '_v369_trace_row' in globals() else {'ticker': ev2.get('ticker'), 'status':status2, 'reason':reason2})
            continue
        eid = event_id(ev, 'strict') if 'event_id' in globals() else str(ev.get('event_id') or ev.get('ticker') or len(picked))
        t = normalize_ticker(ev.get('ticker') or ev.get('market') or ev.get('symbol')) if 'normalize_ticker' in globals() else str(ev.get('ticker') or '')
        price = get_event_price(ev) if 'get_event_price' in globals() else float_any(ev.get('entry_price') or ev.get('current_price') or ev.get('detected_price'), default=0.0)
        if not t or price <= 0:
            stats['bad_skip'] += 1
            trace.append(_v369_trace_row(ev, 'skipped', 'bad_ticker_or_price') if '_v369_trace_row' in globals() else {'ticker': ev.get('ticker'), 'status':'skipped', 'reason':'bad_ticker_or_price'})
            continue
        if eid in existing_ids:
            stats['dup_skip'] += 1
            trace.append(_v369_trace_row(ev, 'duplicate', 'already_open_or_closed') if '_v369_trace_row' in globals() else {'ticker': ev.get('ticker'), 'status':'duplicate', 'reason':'already_open_or_closed'})
            continue
        if control.get('block_same_ticker_open', True) and t in blocked_tickers:
            stats['same_ticker_skip'] += 1
            trace.append(_v369_trace_row(ev, 'skipped', 'same_ticker_open') if '_v369_trace_row' in globals() else {'ticker': ev.get('ticker'), 'status':'skipped', 'reason':'same_ticker_open'})
            continue
        if gate_map and '_v052_is_focus_strategy' in globals() and '_v066_strong_reentry_ok' in globals():
            meta = gate_map.get(short_ticker(t) if 'short_ticker' in globals() else t)
            if meta and _v052_is_focus_strategy(ev):
                mode = str(meta.get('mode') or '')
                if mode == 'hard_block':
                    trace.append(_v369_trace_row(ev, 'skipped', 'recent_loss_hard_cooldown') if '_v369_trace_row' in globals() else {'ticker': ev.get('ticker'), 'status':'skipped', 'reason':'recent_loss_hard_cooldown'})
                    continue
                ok2, reasons = _v066_strong_reentry_ok(ev, meta)
                if not ok2:
                    trace.append(_v369_trace_row(ev, 'skipped', 'recent_loss_cooldown') if '_v369_trace_row' in globals() else {'ticker': ev.get('ticker'), 'status':'skipped', 'reason':'recent_loss_cooldown'})
                    continue
                ev = dict(ev); ev['repeat_loss_reentry_override'] = True; ev['repeat_loss_reentry_reasons'] = reasons[:8]
        ev = dict(ev)
        ev.update({'lane':'strict', 's_stage':'S1', 'candidate_grade':'S1', 'grade':'S1', 'paper_grade_open':True, 'paper_bot_open':True, 'open_eligible':True, 'trade_ready':True, 'paper_pick_version': VERSION})
        picked.append((eid, ev)); existing_ids.add(eid); blocked_tickers.add(t); lane_counts['strict'] = int(lane_counts.get('strict', 0) or 0) + 1
        stats['v369_s1_selected'] += 1
        stats['v371_s1_selected'] += 1
        stats['v373_s1_selected'] += 1
        trace.append(_v369_trace_row(ev, 'selected_for_open', 'S1안전문통과') if '_v369_trace_row' in globals() else {'ticker': ev.get('ticker'), 'status':'selected_for_open', 'reason':'S1안전문통과'})

    if micro_wait_rows:
        try:
            _write_micro_urgent_targets(micro_wait_rows, reason='paper_preopen_micro_or_info_shortage_v374', control=control)
        except Exception as exc:
            try: log_error('v374_micro_urgent', exc)
            except Exception: pass
    stats['v369_s2_trace'] = sum(1 for r in trace if str(r.get('status')) == 's2_recheck')
    stats['v369_s3_trace'] = sum(1 for r in trace if str(r.get('status')) == 's3_observe')
    stats['v369_trace_rows'] = len(trace)
    stats['s123_note'] = 'v0.106/v374: final picker direct path + S1정보부족은 urgent 재확인으로 분리'
    _V369_LAST_TRACE_ROWS = trace[:120]
    if '_v369_save_trace' in globals():
        _v369_save_trace('pick_candidates_v373_final_direct', _V369_LAST_TRACE_ROWS)
    return picked, stats



# =============================================================================
# paper_bot v0.106: S1 정보부족 차단을 긴급보강 대기로 분리
# - 정보 미확인 때문에 못 들어간 후보를 S1안전문차단으로 뭉개지 않는다.
# - trace 문구에 S1정보부족재확인을 명확히 남기고 micro urgent 요청을 같이 보낸다.
# - 조건 불량은 기존처럼 S1안전문차단으로 남긴다.
# =============================================================================
VERSION = "paper_bot_v0.106"

def _v374_is_info_shortage_reason(reason: Any) -> bool:
    t = str(reason or '')
    return any(k in t for k in ('미확인', '정보부족', '정보보강', 'micro미확인', 'WS', '가격반응미확인', '매수체결지속미확인', '슬리피지미확인', '매도벽미확인'))

def _v374_safety_trace_status_reason(why: List[Any]) -> tuple[str, str, bool]:
    reasons = [str(x) for x in (why or []) if str(x or '').strip()]
    info = [x for x in reasons if _v374_is_info_shortage_reason(x)]
    if info:
        return 's1_info_wait', 'S1정보부족재확인:' + ','.join(info[:5]), True
    return 's2_recheck', 'S1안전문차단:' + ','.join(reasons[:5]), False

_v373_final_run_cycle = run_cycle
if '_v050_original_run_cycle' in globals():
    _v050_original_run_cycle = _v373_final_run_cycle  # type: ignore[assignment]

try:
    st = load_json(FILES.get('status', BASE_DIR/'paper_bot_status.json'), {}) or {}
    st.update({
        'version': VERSION,
        'active_reader_version': VERSION,
        'trace_version': VERSION,
        'paper_pick_fix': 'v374_s1_info_shortage_urgent_recheck',
        'worker_loop_fix': 'v374_rebind_v050_original_run_cycle_to_final_run_cycle',
        'updated_at': now(),
        'updated_at_text': iso_ts(),
        'startup_status': True,
    })
    save_json(FILES.get('status', BASE_DIR/'paper_bot_status.json'), st)
    try:
        _v096_refresh_score_cache('startup_v373_score') if '_v096_refresh_score_cache' in globals() else _v077_build_score_cache('startup_v373_score')
    except Exception as exc:
        try: log_error('v373_startup_score', exc)
        except Exception: pass
except Exception as exc:
    try: log_error('v373_startup', exc)
    except Exception: pass



# =============================================================================
# paper_bot v0.107 / v375: paper runtime 상태/trace 최신화 + 1시간 복기 요약 표시 개선
# - paper_bot.py 파일이 최신이어도 상태 캐시가 구버전이면 혼동되므로 매 cycle 현재 VERSION을 강제 갱신한다.
# - worker_loop가 항상 최종 run_cycle을 타도록 마지막에 다시 포인터를 연결한다.
# - 후보품질 1시간 요약에 이후상승률/최고상승률/3분돈 상태를 표시한다.
# - 정보부족 사유와 조건부족 사유를 분리해 보여준다.
# =============================================================================
VERSION = "paper_bot_v0.107"


def _v375_float_or_none(v: Any) -> Optional[float]:
    try:
        if v is None:
            return None
        s = str(v).strip().replace(',', '').replace('%', '')
        if s in {'', '-', 'None', 'none', 'nan', 'NaN'}:
            return None
        return float(s)
    except Exception:
        return None


def _v375_get_any(row: Dict[str, Any], *keys: str) -> Any:
    ctx = row.get('entry_context') if isinstance(row.get('entry_context'), dict) else {}
    snap = row.get('entry_snapshot') if isinstance(row.get('entry_snapshot'), dict) else {}
    flat = snap.get('flat') if isinstance(snap.get('flat'), dict) else {}
    for k in keys:
        for src in (row, ctx, flat):
            try:
                v = src.get(k)
                if v is not None and str(v).strip() not in {'', '-', 'None', 'nan'}:
                    return v
            except Exception:
                pass
    return None


def _v375_pct(row: Dict[str, Any], *keys: str) -> Optional[float]:
    v = _v375_get_any(row, *keys)
    f = _v375_float_or_none(v)
    if f is not None:
        return f
    return None


def _v375_entry_price(row: Dict[str, Any]) -> Optional[float]:
    return _v375_float_or_none(_v375_get_any(row, 'entry_price', 'detected_price', 'base_price', 'reference_price', 'price_at_signal', 'signal_price', 'price'))


def _v375_now_price(row: Dict[str, Any]) -> Optional[float]:
    return _v375_float_or_none(_v375_get_any(row, 'current_price', 'now_price', 'last_price', 'close_price', 'price_now', 'latest_price'))


def _v375_high_price(row: Dict[str, Any]) -> Optional[float]:
    return _v375_float_or_none(_v375_get_any(row, 'highest_price', 'max_price', 'peak_price', 'after_high_price', 'review_high_price', 'high_price'))


def _v375_after_pct(row: Dict[str, Any]) -> Optional[float]:
    direct = _v375_pct(row, 'after_pct', 'after_return_pct', 'future_return_pct', 'rise_pct', 'review_return_pct', 'current_return_pct', 'return_pct_after', 'profit_pct')
    if direct is not None:
        return direct
    ep = _v375_entry_price(row); cp = _v375_now_price(row)
    if ep and cp and ep > 0:
        return (cp - ep) / ep * 100.0
    return None


def _v375_high_pct(row: Dict[str, Any]) -> Optional[float]:
    direct = _v375_pct(row, 'after_high_pct', 'max_after_pct', 'max_return_pct', 'max_profit_pct', 'highest_return_pct', 'peak_return_pct', 'max_rise_pct')
    if direct is not None:
        return direct
    ep = _v375_entry_price(row); hp = _v375_high_price(row)
    if ep and hp and ep > 0:
        return (hp - ep) / ep * 100.0
    return None


def _v375_fmt_pct(v: Optional[float]) -> str:
    if v is None:
        return '정보부족'
    sign = '+' if v >= 0 else ''
    return f'{sign}{v:.2f}%'


def _v375_money3_value(row: Dict[str, Any]) -> Optional[float]:
    return _v375_float_or_none(_v375_get_any(row, 'money_flow_3m', 'turnover_3m', 'turnover_3m_krw', 'trade_krw_3m', 'money3', 'money_flow_3m_krw'))


def _v375_money3_text(row: Dict[str, Any]) -> str:
    v = _v375_money3_value(row)
    age = _v375_float_or_none(_v375_get_any(row, 'money_flow_age', 'money3_age', 'feature_age', 'scanner_age'))
    if v is None:
        return '3분돈 정보부족'
    if age is not None and age > 90:
        return f'3분돈 오래됨({int(age)}초)'
    try:
        return '3분돈 ' + fmt_money_krw_short(v)
    except Exception:
        return f'3분돈 {v:.0f}'


def _v375_split_reason_tags(row: Dict[str, Any]) -> tuple[list[str], list[str]]:
    raw = []
    for k in ('summary_reason', 'reason', 'reasons', 's1_block_reasons', 'missed_reasons', 'blocked_reasons'):
        v = row.get(k)
        if isinstance(v, list):
            raw.extend([str(x) for x in v])
        elif isinstance(v, str):
            raw.extend([x.strip() for x in re.split(r'[,/|]', v) if x.strip()])
    info_keys = ('정보부족','미확인','오래됨','micro미확인','WS','가격반응미확인','매수체결지속미확인','슬리피지미확인','매도벽미확인')
    info=[]; cond=[]
    for x in raw:
        if not x or x == '-':
            continue
        if any(k in x for k in info_keys):
            if x not in info: info.append(x)
        else:
            if x not in cond: cond.append(x)
    return info[:4], cond[:4]


def _summary_line_from_candidate(row: Dict[str, Any]) -> str:  # type: ignore[override]
    ctx = row.get('entry_context') if isinstance(row.get('entry_context'), dict) else {}
    ticker = str(row.get('ticker') or row.get('symbol') or row.get('market') or ctx.get('ticker') or '?').replace('KRW-', '')
    score = _v375_float_or_none(row.get('score') or ctx.get('score'))
    score_txt = f'{score:.2f}' if score is not None else '-'
    after = _v375_after_pct(row)
    high = _v375_high_pct(row)
    micro = micro_summary_from_ctx(ctx if ctx else row) if 'micro_summary_from_ctx' in globals() else ''
    ws = ws_summary_from_ctx(ctx if ctx else row) if 'ws_summary_from_ctx' in globals() else ''
    micro_flag = 'micro ✅ 신선' if ('✅' in micro or row.get('micro_fresh') or ctx.get('micro_fresh')) else ('micro ⚠️ 오래됨' if micro else 'micro 정보부족')
    ws_flag = 'WS ✅ 신선' if ('✅' in ws or row.get('ws_fresh') or row.get('quote_fresh') or ctx.get('ws_fresh') or ctx.get('quote_fresh')) else ('WS ⚠️ 오래됨' if ws else 'WS 정보부족')
    info, cond = _v375_split_reason_tags(row)
    info_txt = ('정보부족: ' + ','.join(info)) if info else '정보부족: 없음'
    cond_txt = ('조건부족: ' + ','.join(cond)) if cond else '조건부족: 없음'
    high_txt = _v375_fmt_pct(high) if high is not None else '정보부족'
    return f"- {ticker}: 이후 {_v375_fmt_pct(after)} / 최고 {high_txt} / 점수 {score_txt} / {_v375_money3_text(row)} / {micro_flag} / {ws_flag} / {info_txt} / {cond_txt}"


_v375_prev_run_cycle = run_cycle


def _v375_touch_status(reason: str = 'v375_status_refresh') -> None:
    try:
        st = load_json(FILES.get('status', BASE_DIR / 'paper_bot_status.json'), {}) or {}
        st.update({
            'version': VERSION,
            'active_reader_version': VERSION,
            'trace_version': VERSION,
            'paper_pick_fix': 'v375_info_display_and_runtime_refresh',
            'worker_loop_fix': 'v375_final_run_cycle_rebind',
            'updated_at': now(),
            'updated_at_text': iso_ts(),
            'status_refresh_reason': reason,
        })
        save_json(FILES.get('status', BASE_DIR / 'paper_bot_status.json'), st)
    except Exception as exc:
        try: log_error('v375_touch_status', exc)
        except Exception: pass


def _v375_refresh_trace(reason: str = 'v375_trace_refresh') -> None:
    try:
        rows = list(globals().get('_V369_LAST_TRACE_ROWS') or [])
        if '_v369_save_trace' in globals():
            _v369_save_trace(reason, rows)
        elif '_v094_save_actual_trace' in globals():
            _v094_save_actual_trace(reason, rows)
        else:
            save_json(FILES.get('candidate_handoff_trace', BASE_DIR/'paper_bot_candidate_handoff_trace.json'), {'version': VERSION, 'updated_at': now(), 'updated_at_text': iso_ts(), 'reason': reason, 'trace_count': len(rows), 'rows': rows[:120]})
    except Exception as exc:
        try: log_error('v375_refresh_trace', exc)
        except Exception: pass


def run_cycle() -> Dict[str, Any]:  # type: ignore[override]
    res = _v375_prev_run_cycle()
    _v375_touch_status('run_cycle_v375')
    _v375_refresh_trace('run_cycle_v375_actual_trace')
    return res

try:
    _v375_touch_status('startup_v375')
    _v375_refresh_trace('startup_v375_actual_trace')
    if '_v050_original_run_cycle' in globals():
        _v050_original_run_cycle = run_cycle  # type: ignore[assignment]
except Exception as exc:
    try: log_error('v375_startup', exc)
    except Exception: pass



# =============================================================================
# paper_bot v0.108 / v376: 후보품질 1시간 요약 추적값 보강
# - v375는 문구는 바꿨지만 이후/최고/3분값 원천 연결이 부족해 +0.00/정보부족이 반복됐다.
# - 후보별 기준가/최고상승률을 alert_state에 짧게 보존하고 live price로 이후/최고를 갱신한다.
# - 3분돈이 없을 때 reason의 3m±x.xx 흐름값을 별도 표시해 정보부족/0/흐름값을 구분한다.
# - 전략조건/OPEN 기준/청산조건은 변경하지 않는다.
# =============================================================================
VERSION = "paper_bot_v0.108"

_V376_PRICE_MAP: Dict[str, float] = {}
_V376_TRACKER: Dict[str, Any] = {}
_V376_TRACKER_DIRTY = False


def _v376_ticker(row: Dict[str, Any]) -> str:
    ctx = row.get('entry_context') if isinstance(row.get('entry_context'), dict) else {}
    return normalize_ticker(row.get('ticker') or row.get('symbol') or row.get('market') or ctx.get('ticker') or ctx.get('symbol') or '') or str(row.get('ticker') or '?').replace('KRW-', '')


def _v376_strategy(row: Dict[str, Any]) -> str:
    ctx = row.get('entry_context') if isinstance(row.get('entry_context'), dict) else {}
    return str(row.get('strategy_key') or row.get('strategy') or row.get('strategy_name') or ctx.get('strategy_key') or ctx.get('strategy') or '-')


def _v376_tracker_key(row: Dict[str, Any]) -> str:
    # scan마다 created_at을 키에 넣으면 최고가 추적이 끊기므로 ticker+strategy 중심으로 1~2시간 추적한다.
    return f"{_v376_ticker(row)}|{_v376_strategy(row)}"


def _v376_live_price(row: Dict[str, Any]) -> Optional[float]:
    t = _v376_ticker(row)
    px = _V376_PRICE_MAP.get(normalize_ticker(t) or t)
    if px and px > 0:
        return px
    return _v375_now_price(row)


def _v376_after_high(row: Dict[str, Any]) -> tuple[Optional[float], Optional[float], str]:
    """return after_pct, high_pct, source"""
    global _V376_TRACKER_DIRTY
    key = _v376_tracker_key(row)
    tr = _V376_TRACKER.get(key) if isinstance(_V376_TRACKER.get(key), dict) else {}
    entry = _v375_entry_price(row) or _v375_float_or_none(tr.get('entry_price'))
    live = _v376_live_price(row)
    source = '추적중'
    if (not entry or entry <= 0) and live and live > 0:
        entry = live
        tr['entry_price'] = entry
        tr['first_seen_at'] = tr.get('first_seen_at') or now()
        tr['ticker'] = _v376_ticker(row)
        tr['strategy'] = _v376_strategy(row)
        _V376_TRACKER[key] = tr
        _V376_TRACKER_DIRTY = True
        source = '추적시작'
    after = None
    if entry and entry > 0 and live and live > 0:
        after = (live - entry) / entry * 100.0
    else:
        after = _v375_after_pct(row)
        if after is not None:
            source = '기록값'
    high = _v375_high_pct(row)
    prev_high = _v375_float_or_none(tr.get('high_pct'))
    if after is not None:
        high = max(x for x in [high, prev_high, after] if x is not None)
        tr['high_pct'] = high
        tr['last_after_pct'] = after
        tr['last_price'] = live or tr.get('last_price')
        tr['last_seen_at'] = now()
        tr['ticker'] = _v376_ticker(row)
        tr['strategy'] = _v376_strategy(row)
        if entry and entry > 0:
            tr['entry_price'] = entry
        _V376_TRACKER[key] = tr
        _V376_TRACKER_DIRTY = True
    elif prev_high is not None:
        high = prev_high
    return after, high, source


def _v376_reason_text(row: Dict[str, Any]) -> str:
    parts: list[str] = []
    for k in ('summary_reason', 'reason', 'reasons', 's1_block_reasons', 'missed_reasons', 'blocked_reasons', 'final_entry_label', 'trade_ready_label'):
        v = row.get(k)
        if isinstance(v, list):
            parts.extend(str(x) for x in v)
        elif isinstance(v, str):
            parts.append(v)
    return ','.join(parts)


def _v376_flow3_pct_from_reason(row: Dict[str, Any]) -> Optional[float]:
    txt = _v376_reason_text(row)
    for pat in (r'3m\s*([+-]?\d+(?:\.\d+)?)', r'3분\s*([+-]?\d+(?:\.\d+)?)', r'3분흐름\s*([+-]?\d+(?:\.\d+)?)'):
        m = re.search(pat, txt, flags=re.IGNORECASE)
        if m:
            return _v375_float_or_none(m.group(1))
    return None


def _v376_flow_text(row: Dict[str, Any]) -> str:
    money = _v375_money3_value(row)
    if money is not None:
        age = _v375_float_or_none(_v375_get_any(row, 'money_flow_age', 'money3_age', 'feature_age', 'scanner_age'))
        suffix = f' / 오래됨({int(age)}초)' if age is not None and age > 90 else ''
        try:
            return '3분돈 ' + fmt_money_krw_short(money) + suffix
        except Exception:
            return f'3분돈 {money:.0f}' + suffix
    flow = _v376_flow3_pct_from_reason(row)
    if flow is not None:
        sign = '+' if flow >= 0 else ''
        return f'3분흐름 {sign}{flow:.2f}%'
    return '3분돈 정보부족'


def _summary_line_from_candidate(row: Dict[str, Any]) -> str:  # type: ignore[override]
    ctx = row.get('entry_context') if isinstance(row.get('entry_context'), dict) else {}
    ticker = str(row.get('ticker') or row.get('symbol') or row.get('market') or ctx.get('ticker') or '?').replace('KRW-', '')
    score = _v375_float_or_none(row.get('score') or ctx.get('score'))
    score_txt = f'{score:.2f}' if score is not None else '-'
    after, high, src = _v376_after_high(row)
    micro = micro_summary_from_ctx(ctx if ctx else row) if 'micro_summary_from_ctx' in globals() else ''
    ws = ws_summary_from_ctx(ctx if ctx else row) if 'ws_summary_from_ctx' in globals() else ''
    micro_flag = 'micro ✅ 신선' if ('✅' in micro or row.get('micro_fresh') or ctx.get('micro_fresh')) else ('micro ⚠️ 오래됨' if micro else 'micro 정보부족')
    ws_flag = 'WS ✅ 신선' if ('✅' in ws or row.get('ws_fresh') or row.get('quote_fresh') or ctx.get('ws_fresh') or ctx.get('quote_fresh')) else ('WS ⚠️ 오래됨' if ws else 'WS 정보부족')
    info, cond = _v375_split_reason_tags(row)
    info_txt = ('정보부족: ' + ','.join(info)) if info else '정보부족: 없음'
    cond_txt = ('조건부족: ' + ','.join(cond)) if cond else '조건부족: 없음'
    after_txt = _v375_fmt_pct(after)
    if src == '추적시작' and after is not None and abs(after) < 0.005:
        after_txt += '(추적시작)'
    return f"- {ticker}: 이후 {after_txt} / 최고 {_v375_fmt_pct(high)} / 점수 {score_txt} / {_v376_flow_text(row)} / {micro_flag} / {ws_flag} / {info_txt} / {cond_txt}"


def _v376_candidate_after_for_sort(row: Dict[str, Any]) -> float:
    a, h, _ = _v376_after_high(row)
    return float(h if h is not None else (a if a is not None else -999.0))


_v376_base_format_recheck_summary = format_recheck_summary


def format_recheck_summary(rows: List[Dict[str, Any]], control: Dict[str, Any]) -> str:  # type: ignore[override]
    global _V376_PRICE_MAP, _V376_TRACKER, _V376_TRACKER_DIRTY
    max_rows = int(float_any(control.get('recheck_summary_max_rows'), default=8))
    try:
        _V376_PRICE_MAP = fetch_all_bithumb_prices(timeout=3.5) if 'fetch_all_bithumb_prices' in globals() else {}
    except Exception as exc:
        _V376_PRICE_MAP = {}
        try: log_error('v376_fetch_price_map', exc)
        except Exception: pass
    st = load_alert_state()
    _V376_TRACKER = st.get('v376_candidate_price_tracker') if isinstance(st.get('v376_candidate_price_tracker'), dict) else {}
    _V376_TRACKER_DIRTY = False

    recent_closed = _recent_summary_closed()
    good = [r for r in recent_closed if float_any(r.get('pnl_pct'), default=0.0) > 0]
    bad = [r for r in recent_closed if float_any(r.get('pnl_pct'), default=0.0) <= 0]
    good.sort(key=lambda r: float_any(r.get('pnl_pct'), default=0.0), reverse=True)
    bad.sort(key=lambda r: float_any(r.get('pnl_pct'), default=0.0))

    missed_watch=[]
    for r in rows or []:
        ctx = r.get('entry_context') if isinstance(r.get('entry_context'), dict) else r
        if bool(r.get('paper_bot_open') or r.get('open_eligible') or r.get('trade_ready')):
            continue
        score = float_any(r.get('score'), default=0.0)
        money3 = float_any(ctx.get('money_flow_3m') or r.get('money_flow_3m') or r.get('turnover_3m'), default=0.0)
        flow3 = _v376_flow3_pct_from_reason(r)
        if score >= 4.45 or money3 >= 20_000_000 or flow3 is not None:
            missed_watch.append(r)
    missed_watch.sort(key=lambda r: (_v376_candidate_after_for_sort(r), float_any(r.get('score'), default=0.0)), reverse=True)

    rejected_ok=[]
    danger_words = ['스프레드', '매도', '정보 오래', '정보부족', '미확인', '과폭발', '약함', 'VWAP', '가격재확인']
    for r in rows or []:
        reason = _candidate_reason_short(r) + ',' + _v376_reason_text(r)
        if any(w in reason for w in danger_words):
            rejected_ok.append(r)
    rejected_ok.sort(key=lambda r: (_v376_candidate_after_for_sort(r), float_any(r.get('score'), default=0.0)), reverse=True)

    lines = [
        '🕐 후보품질 1시간 요약',
        '- 정식 OPEN/CLOSED 알림은 즉시 유지합니다.',
        '- 재확인/관찰/놓친 후보는 시끄럽게 울리지 않고 1시간 단위로 묶어 봅니다.',
        '',
        f'요약: 종료 {len(recent_closed)}건 / 재확인·관찰 {len(rows or [])}개 / 가격추적 {len(_V376_TRACKER)}개',
        '',
        '[좋았던 후보]',
    ]
    lines += [_summary_line_from_closed(r) for r in good[:max_rows]] or ['- 없음']
    lines += ['', '[안 좋았던 후보]']
    lines += [_summary_line_from_closed(r) for r in bad[:max_rows]] or ['- 없음']
    lines += ['', '[놓친 후보 후보군]']
    lines += [_summary_line_from_candidate(r) for r in missed_watch[:max_rows]] or ['- 없음']
    lines += ['', '[버린 게 맞았는지 확인할 후보]']
    lines += [_summary_line_from_candidate(r) for r in rejected_ok[:max_rows]] or ['- 없음']
    lines += ['', '설정: /palerts']

    try:
        # 짧은 추적 캐시만 유지. 핵심 장부는 건드리지 않는다.
        cutoff = now() - 3*3600
        slim={}
        for k,v in list(_V376_TRACKER.items()):
            if isinstance(v, dict) and float_any(v.get('last_seen_at') or v.get('first_seen_at'), default=0.0) >= cutoff:
                slim[k]=v
        st['v376_candidate_price_tracker'] = dict(list(slim.items())[-1200:])
        st['v376_summary_version'] = VERSION
        st['v376_summary_updated_at'] = now()
        save_alert_state(st)
    except Exception as exc:
        try: log_error('v376_save_tracker', exc)
        except Exception: pass
    return '\n'.join(lines)


_v376_prev_run_cycle = run_cycle


def _v376_touch_status(reason: str = 'v376_status_refresh') -> None:
    try:
        st = load_json(FILES.get('status', BASE_DIR / 'paper_bot_status.json'), {}) or {}
        st.update({
            'version': VERSION,
            'active_reader_version': VERSION,
            'trace_version': VERSION,
            'summary_version': VERSION,
            'paper_pick_fix': 'v376_summary_tracking_source_fix',
            'updated_at': now(),
            'updated_at_text': iso_ts(),
            'status_refresh_reason': reason,
        })
        save_json(FILES.get('status', BASE_DIR / 'paper_bot_status.json'), st)
    except Exception as exc:
        try: log_error('v376_touch_status', exc)
        except Exception: pass


def run_cycle() -> Dict[str, Any]:  # type: ignore[override]
    res = _v376_prev_run_cycle()
    _v376_touch_status('run_cycle_v376')
    return res

try:
    _v376_touch_status('startup_v376')
    if '_v050_original_run_cycle' in globals():
        _v050_original_run_cycle = run_cycle  # type: ignore[assignment]
except Exception as exc:
    try: log_error('v376_startup', exc)
    except Exception: pass



# =============================================================================
# paper_bot v0.109 / v377: 구 S 전적과 새 S1/S2/S3 전적 분리
# - 예전 S/A CLOSED는 LEGACY_S로 분리해 새 S1 성과 착시를 제거한다.
# - 명시 S1/S2/S3가 있는 CLOSED만 새 등급 성과로 집계한다.
# - 전략조건/OPEN/청산/장부는 건드리지 않는다.
# =============================================================================
VERSION = "paper_bot_v0.110"


def _v377_grade_value_for_score(row: Dict[str, Any]) -> str:
    ctx = row.get('entry_context') if isinstance(row.get('entry_context'), dict) else {}
    raw = row.get('raw') if isinstance(row.get('raw'), dict) else {}
    snap = row.get('entry_snapshot') if isinstance(row.get('entry_snapshot'), dict) else {}
    flat = snap.get('flat') if isinstance(snap.get('flat'), dict) else {}
    vals = []
    for src in (row, ctx, raw, flat):
        if isinstance(src, dict):
            vals.extend([src.get('s_stage'), src.get('s_grade'), src.get('s123_stage'), src.get('candidate_stage')])
    for v in vals:
        g = str(v or '').upper().strip()
        if g in {'S1','S2','S3','X'}:
            return g
    # candidate_grade/grade의 구 S는 새 S1이 아니라 LEGACY_S로 분리한다.
    for src in (row, ctx, raw, flat):
        if not isinstance(src, dict):
            continue
        g = str(src.get('candidate_grade') or src.get('grade') or src.get('entry_grade') or src.get('signal_grade') or '').upper().strip()
        if g in {'S1','S2','S3','X'}:
            return g
        if g in {'S','A'}:
            return 'LEGACY_S'
        if g in {'B','C'}:
            return 'LEGACY_OBSERVE'
    label = ' '.join(str((src or {}).get('candidate_grade_label') or (src or {}).get('final_entry_label') or '') for src in (row, ctx, raw, flat) if isinstance(src, dict))
    if 'S1' in label or '즉시' in label:
        return 'S1'
    if 'S2' in label or '재확인' in label:
        return 'S2'
    if 'S3' in label or '관찰' in label or '복기' in label:
        return 'S3'
    if 'S급' in label:
        return 'LEGACY_S'
    if '제외' in label or '차단' in label or '금지' in label:
        return 'X'
    return 'UNKNOWN'


def _v377_group_by_grade_for_score(rows: List[Dict[str, Any]]) -> Dict[str, List[Dict[str, Any]]]:
    out = {'LEGACY_S': [], 'S1': [], 'S2': [], 'S3': [], 'LEGACY_OBSERVE': [], 'X': [], 'UNKNOWN': []}
    for r in rows or []:
        g = _v377_grade_value_for_score(r)
        if g not in out:
            g = 'UNKNOWN'
        out[g].append(r)
    return out


def _v085_score_cache_valid(c: Dict[str, Any]) -> bool:  # type: ignore[override]
    return isinstance(c, dict) and str(c.get('version') or '') == VERSION and str(c.get('schema') or '') == 'paper_score_cache_v378' and str(c.get('score_scope') or '') == 'current_version_anchor' and c.get('current_closed_count') is not None


def _v077_build_score_cache(reason: str = 'cycle') -> Dict[str, Any]:  # type: ignore[override]
    rows = _v085_current_closed_rows_fast()
    groups = _v377_group_by_grade_for_score(rows)
    open_pos = load_open()
    status = load_json(FILES.get('status', BASE_DIR / 'paper_bot_status.json'), {})
    anchor = _v083_anchor()
    primary_stats = _v086_strategy_stats_primary(rows) if '_v086_strategy_stats_primary' in globals() else _v077_strategy_stats(rows)
    overlap_stats = _v086_strategy_stats_overlap(rows) if '_v086_strategy_stats_overlap' in globals() else []
    primary_total = _v086_sum_n(primary_stats) if '_v086_sum_n' in globals() else sum(int(float_any(x.get('n'), default=0)) for x in primary_stats if isinstance(x, dict))
    overlap_total = _v086_sum_n(overlap_stats) if '_v086_sum_n' in globals() else sum(int(float_any(x.get('n'), default=0)) for x in overlap_stats if isinstance(x, dict))
    cache = {
        'schema': 'paper_score_cache_v378',
        'version': VERSION,
        'updated_at': now(),
        'updated_at_text': iso_ts(),
        'reason': reason,
        'score_scope': 'current_version_anchor',
        'anchor_ts': anchor.get('anchor_ts'),
        'anchor_text': anchor.get('anchor_text'),
        'source_tail_lines': max(V077_CACHE_TAIL_LINES, 1200),
        'closed_file_size': FILES['closed'].stat().st_size if FILES['closed'].exists() else 0,
        'closed_total': closed_count(),
        'current_closed_count': len(rows),
        'open_total': len(open_pos),
        'open_grade_counts': Counter(_v097_grade_value(v) for v in open_pos.values() if isinstance(v, dict)) if '_v097_grade_value' in globals() else {},
        'loop_seconds': load_control().get('loop_seconds'),
        'running': bool(load_control().get('running')),
        'pick_stats': status.get('pick_stats') if isinstance(status.get('pick_stats'), dict) else {},
        'grade_stats': {
            'LEGACY_S': _v077_short_stat('📦 구 S 통합전적(참고)', groups.get('LEGACY_S', [])),
            'S1': _v077_short_stat('✅ 새 S1 즉시진입', groups.get('S1', [])),
            'S2': _v077_short_stat('⚠️ 새 S2 재확인', groups.get('S2', [])),
            'S3': _v077_short_stat('❔ 새 S3 관찰복기', groups.get('S3', [])),
            'LEGACY_OBSERVE': _v077_short_stat('📦 구 관찰전적(참고)', groups.get('LEGACY_OBSERVE', [])),
            'X': _v077_short_stat('❌ 제외', groups.get('X', [])),
            'UNKNOWN': _v077_short_stat('❔ 등급미기록', groups.get('UNKNOWN', [])),
            'ALL': _v077_short_stat('현재판 전체', rows),
        },
        'reason_stats': _v077_reason_stats(rows),
        'strategy_primary_stats': primary_stats,
        'strategy_overlap_stats': overlap_stats,
        'strategy_s_stats': primary_stats,
        'strategy_stats': primary_stats,
        'strategy_primary_total': primary_total,
        'strategy_overlap_total': overlap_total,
        'strategy_duplicate_extra': max(0, overlap_total - len(rows)),
        'note': 'v0.110/v378: 구 S/A CLOSED를 LEGACY_S로 분리하고, feature/orderflow canonical S1/S2/S3 승격 흐름 기준으로 새 성과만 집계.',
    }
    save_json(FILES['score_cache'], cache)
    return cache


def _v077_score_cache(allow_stale: bool = True) -> Dict[str, Any]:  # type: ignore[override]
    c = load_json(FILES['score_cache'], {})
    if _v085_score_cache_valid(c):
        try:
            size = FILES['closed'].stat().st_size if FILES['closed'].exists() else 0
            if int(c.get('closed_file_size') or 0) != int(size):
                c = _v077_build_score_cache('closed_file_changed_v378')
        except Exception:
            pass
        return c if _v085_score_cache_valid(c) else {}
    try:
        return _v077_build_score_cache('missing_or_old_cache_v378')
    except Exception as exc:
        try: log_error('v377_score_cache_build', exc)
        except Exception: pass
        return {}

try:
    _v077_build_score_cache('startup_v378')
    _v376_touch_status('startup_v378') if '_v376_touch_status' in globals() else None
except Exception as exc:
    try: log_error('v378_startup_score_cache', exc)
    except Exception: pass



# =============================================================================
# paper_bot v0.112 / v380: v379 scoring 유지 + runtime ready wait 대상
# - S2/S3는 하위단계/재료이므로 승패 표가 아니라 생애주기 승격 흐름으로 본다.
# - 구 S 통합전적은 참고로만 보이고, 새 실제 성과는 S1 OPEN만 집계한다.
# - OPEN/청산/장부 로직은 변경하지 않는다.
# =============================================================================
VERSION = "paper_bot_v0.112"
LIFECYCLE_FILE = BASE_DIR / "clean_strategy_s123_lifecycle.json"

def _v379_lifecycle_stats() -> Dict[str, Any]:
    obj = load_json(LIFECYCLE_FILE, {}) or {}
    if not isinstance(obj, dict):
        return {}
    stats = obj.get("stats") if isinstance(obj.get("stats"), dict) else {}
    items = obj.get("items") if isinstance(obj.get("items"), dict) else {}
    stage_counts = {"S1": 0, "S2": 0, "S3": 0}
    high_after = {"S2_up_07": 0, "S3_up_07": 0, "S2_up_10": 0, "S3_up_10": 0}
    info_wait = 0
    for r in items.values():
        if not isinstance(r, dict):
            continue
        st = str(r.get("stage") or "S3").upper()
        if st in stage_counts:
            stage_counts[st] += 1
        hp = float_any(r.get("highest_pct"), default=0.0)
        if st == "S2" and hp >= 0.7: high_after["S2_up_07"] += 1
        if st == "S3" and hp >= 0.7: high_after["S3_up_07"] += 1
        if st == "S2" and hp >= 1.0: high_after["S2_up_10"] += 1
        if st == "S3" and hp >= 1.0: high_after["S3_up_10"] += 1
        if r.get("info_shortage_pending") or r.get("urgent_recheck_needed"):
            info_wait += 1
    out = dict(stats)
    out["active_stage_counts"] = stage_counts
    out["missed_rise_counts"] = high_after
    out["info_wait_count"] = info_wait
    out["active_count"] = len(items)
    return out

def _v085_score_cache_valid(c: Dict[str, Any]) -> bool:  # type: ignore[override]
    return isinstance(c, dict) and str(c.get('version') or '') == VERSION and str(c.get('schema') or '') == 'paper_score_cache_v379' and str(c.get('score_scope') or '') == 'current_version_anchor' and c.get('current_closed_count') is not None

def _v077_build_score_cache(reason: str = 'cycle') -> Dict[str, Any]:  # type: ignore[override]
    rows = _v085_current_closed_rows_fast()
    groups = _v377_group_by_grade_for_score(rows) if '_v377_group_by_grade_for_score' in globals() else {'S1': [], 'LEGACY_S': [], 'UNKNOWN': rows}
    open_pos = load_open()
    status = load_json(FILES.get('status', BASE_DIR / 'paper_bot_status.json'), {})
    anchor = _v083_anchor()
    primary_stats = _v086_strategy_stats_primary(rows) if '_v086_strategy_stats_primary' in globals() else _v077_strategy_stats(rows)
    overlap_stats = _v086_strategy_stats_overlap(rows) if '_v086_strategy_stats_overlap' in globals() else []
    primary_total = _v086_sum_n(primary_stats) if '_v086_sum_n' in globals() else sum(int(float_any(x.get('n'), default=0)) for x in primary_stats if isinstance(x, dict))
    overlap_total = _v086_sum_n(overlap_stats) if '_v086_sum_n' in globals() else sum(int(float_any(x.get('n'), default=0)) for x in overlap_stats if isinstance(x, dict))
    life_stats = _v379_lifecycle_stats()
    cache = {
        'schema': 'paper_score_cache_v379',
        'version': VERSION,
        'updated_at': now(),
        'updated_at_text': iso_ts(),
        'reason': reason,
        'score_scope': 'current_version_anchor',
        'anchor_ts': anchor.get('anchor_ts'),
        'anchor_text': anchor.get('anchor_text'),
        'source_tail_lines': max(V077_CACHE_TAIL_LINES, 1200),
        'closed_file_size': FILES['closed'].stat().st_size if FILES['closed'].exists() else 0,
        'closed_total': closed_count(),
        'current_closed_count': len(rows),
        'open_total': len(open_pos),
        'open_grade_counts': Counter(_v097_grade_value(v) for v in open_pos.values() if isinstance(v, dict)) if '_v097_grade_value' in globals() else {},
        'loop_seconds': load_control().get('loop_seconds'),
        'running': bool(load_control().get('running')),
        'pick_stats': status.get('pick_stats') if isinstance(status.get('pick_stats'), dict) else {},
        'grade_stats': {
            'LEGACY_S': _v077_short_stat('📦 구 S 통합전적(참고)', groups.get('LEGACY_S', [])),
            'S1': _v077_short_stat('✅ 새 S1 실제 OPEN', groups.get('S1', [])),
            # S2/S3는 승패 집계 대상이 아니다. main은 stage_stats를 따로 표시한다.
            'ALL': _v077_short_stat('현재판 전체', rows),
            'UNKNOWN': _v077_short_stat('❔ 등급미기록', groups.get('UNKNOWN', [])),
        },
        'stage_stats': life_stats,
        'lifecycle_stats': life_stats,
        'reason_stats': _v077_reason_stats(rows),
        'strategy_primary_stats': primary_stats,
        'strategy_overlap_stats': overlap_stats,
        'strategy_s_stats': primary_stats,
        'strategy_stats': primary_stats,
        'strategy_primary_total': primary_total,
        'strategy_overlap_total': overlap_total,
        'strategy_duplicate_extra': max(0, overlap_total - len(rows)),
        'note': 'v0.112/v380: S2/S3 승패 제거. 실제 승패는 S1 OPEN만, S2/S3는 생애주기 승격/복기 지표로 본다.',
    }
    save_json(FILES['score_cache'], cache)
    return cache

def _v077_score_cache(allow_stale: bool = True) -> Dict[str, Any]:  # type: ignore[override]
    c = load_json(FILES['score_cache'], {})
    if _v085_score_cache_valid(c):
        try:
            size = FILES['closed'].stat().st_size if FILES['closed'].exists() else 0
            if int(c.get('closed_file_size') or 0) != int(size):
                c = _v077_build_score_cache('closed_file_changed_v379')
        except Exception:
            pass
        return c if _v085_score_cache_valid(c) else {}
    try:
        return _v077_build_score_cache('missing_or_old_cache_v379')
    except Exception as exc:
        try: log_error('v379_score_cache_build', exc)
        except Exception: pass
        return {}

try:
    _v077_build_score_cache('startup_v379')
    _v376_touch_status('startup_v379') if '_v376_touch_status' in globals() else None
except Exception as exc:
    try: log_error('v379_startup_score_cache', exc)
    except Exception: pass


# =============================================================================
# paper_bot v0.113 / v383: S1 성과 검증 기준 강화 + lifecycle open source 기록
# - 단순 s_stage=S1 표시만으로 실제 S1 OPEN 성과로 집계하지 않는다.
# - 앞으로 lifecycle S1로 실제 open_position을 탄 포지션은 open_source=s1_lifecycle로 남긴다.
# - 기존 애매한 S1 표시는 S1_UNVERIFIED로 분리해 성과 착시를 막는다.
# =============================================================================
VERSION = "paper_bot_v0.113"

_v383_base_open_position = open_position

def _v383_stage_from_event(ev: Dict[str, Any]) -> str:
    ctx = ev.get('entry_context') if isinstance(ev.get('entry_context'), dict) else {}
    snap = ev.get('entry_snapshot') if isinstance(ev.get('entry_snapshot'), dict) else {}
    flat = snap.get('flat') if isinstance(snap.get('flat'), dict) else {}
    for src in (ev, ctx, flat):
        if isinstance(src, dict):
            g = str(src.get('lifecycle_stage') or src.get('s_stage') or src.get('candidate_grade') or src.get('grade') or '').upper().strip()
            if g in {'S1','S2','S3'}:
                return g
    return ''


def open_position(pos_id: str, ev: Dict[str, Any], control: Dict[str, Any]) -> Dict[str, Any]:  # type: ignore[override]
    pos = _v383_base_open_position(pos_id, ev, control)
    try:
        st = _v383_stage_from_event(ev)
        ctx = pos.get('entry_context') if isinstance(pos.get('entry_context'), dict) else {}
        if st == 'S1' and (ev.get('lifecycle_schema') or ctx.get('lifecycle_schema') or ev.get('worker_patch')):
            pos['open_source'] = 's1_lifecycle'
            pos['s1_verified_open'] = True
            pos['lifecycle_stage'] = 'S1'
            ctx['open_source'] = 's1_lifecycle'
            ctx['s1_verified_open'] = True
            ctx['lifecycle_stage'] = 'S1'
            ctx['s1_open_verified_by'] = VERSION
            pos['entry_context'] = ctx
    except Exception:
        pass
    return pos


def _v383_sources_for_row(row: Dict[str, Any]) -> List[Dict[str, Any]]:
    out: List[Dict[str, Any]] = []
    for key in ('entry_context','raw','entry_snapshot'):
        v = row.get(key)
        if isinstance(v, dict):
            out.append(v)
            if key == 'entry_snapshot':
                for sub in ('flat','strategy'):
                    sv = v.get(sub)
                    if isinstance(sv, dict): out.append(sv)
    out.append(row)
    return out


def _v383_row_has_s1_stage(row: Dict[str, Any]) -> bool:
    for src in _v383_sources_for_row(row):
        g = str(src.get('lifecycle_stage') or src.get('s_stage') or src.get('candidate_stage') or src.get('candidate_grade') or src.get('grade') or '').upper().strip()
        if g == 'S1':
            return True
    return False


def _v383_row_verified_s1_open(row: Dict[str, Any]) -> bool:
    if not _v383_row_has_s1_stage(row):
        return False
    allowed = {'s1_lifecycle','s1_verified','s1_final','actual_open','selected_for_open'}
    for src in _v383_sources_for_row(row):
        if bool(src.get('s1_verified_open')):
            return True
        if str(src.get('open_source') or '').strip() in allowed:
            return True
        if str(src.get('s1_open_verified_by') or '').startswith('paper_bot_v0.113'):
            return True
    return False


def _v383_grade_value_for_score(row: Dict[str, Any]) -> str:
    # 검증된 S1만 실제 S1 성과. 표시만 S1인 CLOSED는 따로 둔다.
    if _v383_row_verified_s1_open(row):
        return 'S1'
    if _v383_row_has_s1_stage(row):
        return 'S1_UNVERIFIED'
    return _v377_grade_value_for_score(row) if '_v377_grade_value_for_score' in globals() else 'UNKNOWN'


def _v383_group_by_grade_for_score(rows: List[Dict[str, Any]]) -> Dict[str, List[Dict[str, Any]]]:
    out = {'LEGACY_S': [], 'S1': [], 'S1_UNVERIFIED': [], 'S2': [], 'S3': [], 'LEGACY_OBSERVE': [], 'X': [], 'UNKNOWN': []}
    for r in rows or []:
        g = _v383_grade_value_for_score(r)
        if g not in out:
            g = 'UNKNOWN'
        out[g].append(r)
    return out


def _v085_score_cache_valid(c: Dict[str, Any]) -> bool:  # type: ignore[override]
    return isinstance(c, dict) and str(c.get('version') or '') == VERSION and str(c.get('schema') or '') == 'paper_score_cache_v383' and str(c.get('score_scope') or '') == 'current_version_anchor' and c.get('current_closed_count') is not None


def _v077_build_score_cache(reason: str = 'cycle') -> Dict[str, Any]:  # type: ignore[override]
    rows = _v085_current_closed_rows_fast()
    groups = _v383_group_by_grade_for_score(rows)
    open_pos = load_open()
    status = load_json(FILES.get('status', BASE_DIR / 'paper_bot_status.json'), {})
    anchor = _v083_anchor()
    primary_stats = _v086_strategy_stats_primary(rows) if '_v086_strategy_stats_primary' in globals() else _v077_strategy_stats(rows)
    overlap_stats = _v086_strategy_stats_overlap(rows) if '_v086_strategy_stats_overlap' in globals() else []
    primary_total = _v086_sum_n(primary_stats) if '_v086_sum_n' in globals() else sum(int(float_any(x.get('n'), default=0)) for x in primary_stats if isinstance(x, dict))
    overlap_total = _v086_sum_n(overlap_stats) if '_v086_sum_n' in globals() else sum(int(float_any(x.get('n'), default=0)) for x in overlap_stats if isinstance(x, dict))
    life_stats = _v379_lifecycle_stats() if '_v379_lifecycle_stats' in globals() else {}
    cache = {
        'schema': 'paper_score_cache_v383',
        'version': VERSION,
        'updated_at': now(),
        'updated_at_text': iso_ts(),
        'reason': reason,
        'score_scope': 'current_version_anchor',
        'anchor_ts': anchor.get('anchor_ts'),
        'anchor_text': anchor.get('anchor_text'),
        'source_tail_lines': max(V077_CACHE_TAIL_LINES, 1200),
        'closed_file_size': FILES['closed'].stat().st_size if FILES['closed'].exists() else 0,
        'closed_total': closed_count(),
        'current_closed_count': len(rows),
        'open_total': len(open_pos),
        'open_grade_counts': Counter(_v097_grade_value(v) for v in open_pos.values() if isinstance(v, dict)) if '_v097_grade_value' in globals() else {},
        'loop_seconds': load_control().get('loop_seconds'),
        'running': bool(load_control().get('running')),
        'pick_stats': status.get('pick_stats') if isinstance(status.get('pick_stats'), dict) else {},
        'grade_stats': {
            'LEGACY_S': _v077_short_stat('📦 구 S 통합전적(참고)', groups.get('LEGACY_S', [])),
            'S1': _v077_short_stat('✅ 검증된 S1 OPEN', groups.get('S1', [])),
            'S1_UNVERIFIED': _v077_short_stat('⚠️ S1 표시 CLOSED(검증전)', groups.get('S1_UNVERIFIED', [])),
            'ALL': _v077_short_stat('현재판 전체', rows),
            'UNKNOWN': _v077_short_stat('❔ 등급미기록', groups.get('UNKNOWN', [])),
        },
        'stage_stats': life_stats,
        'lifecycle_stats': life_stats,
        'reason_stats': _v077_reason_stats(rows),
        'strategy_primary_stats': primary_stats,
        'strategy_overlap_stats': overlap_stats,
        'strategy_s_stats': primary_stats,
        'strategy_stats': primary_stats,
        'strategy_primary_total': primary_total,
        'strategy_overlap_total': overlap_total,
        'strategy_duplicate_extra': max(0, overlap_total - len(rows)),
        'note': 'v0.113/v383: S1 성과는 open_source=s1_lifecycle 등 실제 OPEN 검증 흔적이 있는 CLOSED만 집계한다. S1 표시만 있는 과거/애매한 CLOSED는 S1_UNVERIFIED로 분리한다.',
    }
    save_json(FILES['score_cache'], cache)
    return cache


def _v077_score_cache(allow_stale: bool = True) -> Dict[str, Any]:  # type: ignore[override]
    c = load_json(FILES['score_cache'], {})
    if _v085_score_cache_valid(c):
        try:
            size = FILES['closed'].stat().st_size if FILES['closed'].exists() else 0
            if int(c.get('closed_file_size') or 0) != int(size):
                c = _v077_build_score_cache('closed_file_changed_v383')
        except Exception:
            pass
        return c if _v085_score_cache_valid(c) else {}
    try:
        return _v077_build_score_cache('missing_or_old_cache_v383')
    except Exception as exc:
        try: log_error('v383_score_cache_build', exc)
        except Exception: pass
        return {}

try:
    _v077_build_score_cache('startup_v383')
    _v376_touch_status('startup_v383') if '_v376_touch_status' in globals() else None
except Exception as exc:
    try: log_error('v383_startup_score_cache', exc)
    except Exception: pass


# =============================================================================
# paper_bot v0.121 / v392: paper-only deletion surgery restore
# - Base is the last known non-broken paper runtime path before v386+ wrapper churn.
# - Do not add booting-only runtime or long-ready wait behavior.
# - Delete-by-replacement: all old trace writers are overridden to one current-version trace writer.
# - S1/S2/S3 stage-priority handoff merge is kept so stale S2/S3 cannot overwrite S1.
# - Strategy thresholds, liquidation, auto-buy and ledger schema are not changed.
# =============================================================================
VERSION = "paper_bot_v0.121"
FILES["candidate_handoff_trace"] = BASE_DIR / "paper_bot_candidate_handoff_trace.json"
FILES["paper_merged"] = BASE_DIR / "paper_candidates_handoff_merged.jsonl"


def _v392_sources(ev: Dict[str, Any]) -> List[Dict[str, Any]]:
    srcs: List[Dict[str, Any]] = []
    if isinstance(ev, dict):
        srcs.append(ev)
        for k in ("entry_context", "entry_snapshot"):
            v = ev.get(k)
            if isinstance(v, dict):
                srcs.append(v)
                for kk in ("flat", "strategy", "orderflow", "feature"):
                    vv = v.get(kk)
                    if isinstance(vv, dict):
                        srcs.append(vv)
    return srcs


def _v392_stage(ev: Dict[str, Any]) -> str:
    for src in _v392_sources(ev):
        g = str(src.get("lifecycle_stage") or src.get("s_stage") or src.get("candidate_stage") or src.get("candidate_grade") or src.get("grade") or "").upper().strip()
        if g == "S":
            return "S1"
        if g in {"S1", "S2", "S3"}:
            return g
    return "S3"


def _v097_grade_value(row: Dict[str, Any]) -> str:  # type: ignore[override]
    return _v392_stage(row)


def _v070_grade_from_event(ev: Dict[str, Any]) -> str:  # type: ignore[override]
    return _v392_stage(ev)


def _v071_grade_from_row(row: Dict[str, Any]) -> str:  # type: ignore[override]
    return _v392_stage(row)


def _v392_force_stage_fields(ev: Dict[str, Any], stage: str) -> Dict[str, Any]:
    row = dict(ev or {})
    stage = stage if stage in {"S1", "S2", "S3"} else "S3"
    row.update({
        "s_stage": stage,
        "candidate_grade": stage,
        "grade": stage,
        "entry_grade": stage,
        "signal_grade": stage,
        "lifecycle_stage": stage,
        "paper_bot_open": stage == "S1",
        "open_eligible": stage == "S1",
        "trade_ready": stage == "S1",
        "recheck_required": stage == "S2",
        "observe_only": stage == "S3",
        "v392_stage_normalized": True,
    })
    if stage == "S1":
        row["open_source"] = row.get("open_source") or "s1_lifecycle"
        row["paper_handoff_ready"] = True
    ctx = row.get("entry_context") if isinstance(row.get("entry_context"), dict) else {}
    ctx.update({
        "s_stage": stage,
        "candidate_grade": stage,
        "grade": stage,
        "lifecycle_stage": stage,
        "paper_bot_open": stage == "S1",
        "open_eligible": stage == "S1",
        "trade_ready": stage == "S1",
    })
    if stage == "S1":
        ctx["open_source"] = "s1_lifecycle"
        ctx["paper_handoff_ready"] = True
    row["entry_context"] = ctx
    return row


def _v392_merge_key(ev: Dict[str, Any]) -> str:
    t = normalize_ticker(ev.get("ticker") or ev.get("market") or ev.get("symbol")) if 'normalize_ticker' in globals() else str(ev.get("ticker") or ev.get("market") or ev.get("symbol") or "")
    sk = str(ev.get("strategy_key") or ev.get("strategy_bucket_primary") or ev.get("paper_strategy_key") or ev.get("strategy") or "strategy_s")
    return f"{t}:{sk}"


def _v392_stage_priority(ev: Dict[str, Any]) -> int:
    return {"S1": 3, "S2": 2, "S3": 1}.get(_v392_stage(ev), 0)


def _v392_ts(ev: Dict[str, Any]) -> float:
    return float_any(ev.get("updated_ts"), ev.get("created_at"), ev.get("candidate_created_at"), ev.get("event_ts"), default=0.0)


def _v392_trace_row(ev: Dict[str, Any], status: str, reason: str) -> Dict[str, Any]:
    try:
        base = _v091_trace_row(ev, status, reason) if '_v091_trace_row' in globals() else {}
    except Exception:
        base = {}
    if not isinstance(base, dict):
        base = {}
    base.update({
        "ticker": short_ticker(ev.get("ticker") or ev.get("market") or ev.get("symbol")) if 'short_ticker' in globals() else str(ev.get("ticker") or ""),
        "strategy": ev.get("strategy_label") or ev.get("strategy_bucket_label") or ev.get("strategy_key") or ev.get("strategy"),
        "strategy_key": ev.get("strategy_key") or ev.get("strategy_bucket_primary") or ev.get("strategy"),
        "score": ev.get("score"),
        "stage": _v392_stage(ev),
        "status": status,
        "reason": reason,
        "trace_version": VERSION,
    })
    return base


_V392_LAST_TRACE_ROWS: List[Dict[str, Any]] = []


def _v392_build_candidate_merge(control: Optional[Dict[str, Any]] = None) -> List[Dict[str, Any]]:
    control = control or load_control()
    rows: List[Dict[str, Any]] = []
    paths = [
        ("latest", FILES.get("paper_latest", BASE_DIR / "paper_candidates_latest.jsonl"), 600),
        ("archive", FILES.get("paper_candidates", BASE_DIR / "paper_candidates.jsonl"), int(float_any(control.get("candidate_read_max_lines"), default=1400))),
    ]
    for source, path, maxn in paths:
        try:
            for raw in read_jsonl(path, max_lines=maxn):
                if not isinstance(raw, dict):
                    continue
                raw_stage = _v392_stage(raw)
                ev = _v080_normalize_candidate(raw, control) if '_v080_normalize_candidate' in globals() else dict(raw)
                stage = raw_stage if raw_stage in {"S1", "S2", "S3"} else _v392_stage(ev)
                ev = _v392_force_stage_fields(ev, stage)
                ev["handoff_source"] = source
                rows.append(ev)
        except Exception as exc:
            try: log_error(f"v392_read_{source}", exc)
            except Exception: pass
    merged: Dict[str, Dict[str, Any]] = {}
    for ev in rows:
        try:
            if not candidate_is_fresh(ev, control):
                continue
        except Exception:
            pass
        k = _v392_merge_key(ev)
        prev = merged.get(k)
        if prev is None or (_v392_stage_priority(ev), _v392_ts(ev), float_any(ev.get("score"), default=0.0)) >= (_v392_stage_priority(prev), _v392_ts(prev), float_any(prev.get("score"), default=0.0)):
            merged[k] = ev
    out = list(merged.values())
    out.sort(key=lambda x: (_v392_stage_priority(x), _v392_ts(x), float_any(x.get("score"), default=0.0)), reverse=True)
    try:
        _v080_write_jsonl_atomic(FILES.get("paper_merged", BASE_DIR / "paper_candidates_handoff_merged.jsonl"), out)
    except Exception as exc:
        try: log_error("v392_write_merged", exc)
        except Exception: pass
    counts = {"S1": 0, "S2": 0, "S3": 0}
    for r in out:
        st = _v392_stage(r)
        if st in counts:
            counts[st] += 1
    try:
        save_json(FILES.get("candidate_handoff_status", BASE_DIR / "paper_bot_candidate_handoff_status.json"), {
            "version": VERSION,
            "updated_at": now(),
            "updated_at_text": iso_ts(),
            "latest_lines": sum(1 for r in rows if r.get("handoff_source") == "latest"),
            "archive_window": sum(1 for r in rows if r.get("handoff_source") == "archive"),
            "merged_fresh": len(out),
            "stage_counts": counts,
            "s1_handoff_count": counts.get("S1", 0),
            "note": "v392 paper-only surgery: stage-priority merge from stable loop base",
        })
    except Exception as exc:
        try: log_error("v392_handoff_status", exc)
        except Exception: pass
    return out


def _v392_save_trace(reason: str = "cycle", rows: Optional[List[Dict[str, Any]]] = None) -> None:
    global _V392_LAST_TRACE_ROWS
    try:
        if rows is None:
            control = load_control()
            rows = []
            for ev in _v392_build_candidate_merge(control)[:160]:
                st = _v392_stage(ev)
                if st == "S1":
                    rows.append(_v392_trace_row(ev, "s1_candidate", "S1_handoff_ready"))
                elif st == "S2":
                    rows.append(_v392_trace_row(ev, "s2_recheck", "S2재확인대기"))
                else:
                    rows.append(_v392_trace_row(ev, "s3_observe", "S3관찰복기"))
        clean: List[Dict[str, Any]] = []
        seen = set()
        for r in rows or []:
            if not isinstance(r, dict):
                continue
            rr = dict(r)
            rr["trace_version"] = VERSION
            key = (str(rr.get("ticker") or ""), str(rr.get("strategy_key") or rr.get("strategy") or ""), str(rr.get("status") or ""), str(rr.get("reason") or ""))
            if key in seen:
                continue
            seen.add(key)
            clean.append(rr)
        _V392_LAST_TRACE_ROWS = clean[:160]
        status_counter: Dict[str, int] = {}
        reason_counter: Dict[str, int] = {}
        for r in _V392_LAST_TRACE_ROWS:
            status_counter[str(r.get("status") or "unknown")] = status_counter.get(str(r.get("status") or "unknown"), 0) + 1
            for x in str(r.get("reason") or "").split(','):
                x = x.strip()
                if x:
                    reason_counter[x] = reason_counter.get(x, 0) + 1
        save_json(FILES.get("candidate_handoff_trace", BASE_DIR / "paper_bot_candidate_handoff_trace.json"), {
            "version": VERSION,
            "updated_at": now(),
            "updated_at_text": iso_ts(),
            "reason": reason,
            "trace_count": len(_V392_LAST_TRACE_ROWS),
            "status_top": [{"status": k, "count": v} for k, v in sorted(status_counter.items(), key=lambda x: x[1], reverse=True)[:12]],
            "reason_top": [{"reason": k, "count": v} for k, v in sorted(reason_counter.items(), key=lambda x: x[1], reverse=True)[:12]],
            "rows": _V392_LAST_TRACE_ROWS,
            "note": "v392 current-version trace writer only; legacy v0.90/v0.92 trace writers replaced",
        })
    except Exception as exc:
        try: log_error("v392_save_trace", exc)
        except Exception: pass


# Replace all old trace writer entry points. This is the active deletion surgery: old code can call
# these names, but they all land in one current-version writer instead of writing v0.90/v0.92.
def _v090_write_handoff_trace(reason: str = "cycle") -> None:  # type: ignore[override]
    _v392_save_trace(f"{reason}_v392")


def _v091_save_trace(rows: List[Dict[str, Any]], reason: str = "pick_candidates") -> None:  # type: ignore[override]
    _v392_save_trace(f"{reason}_v392", rows)


def _v094_save_actual_trace(reason: str = "actual_pick_trace_v094", rows: Optional[List[Dict[str, Any]]] = None) -> None:  # type: ignore[override]
    _v392_save_trace(f"{reason}_v392", rows)


def _v368_save_actual_trace(reason: str, rows: Optional[List[Dict[str, Any]]] = None) -> None:  # type: ignore[override]
    _v392_save_trace(f"{reason}_v392", rows)


def _v392_touch_status(reason: str = "v392_status") -> None:
    try:
        st = load_json(FILES.get("status", BASE_DIR / "paper_bot_status.json"), {}) or {}
        st.update({
            "version": VERSION,
            "active_reader_version": VERSION,
            "trace_version": VERSION,
            "running": bool(load_control().get("running", True)),
            "updated_at": now(),
            "updated_at_text": iso_ts(),
            "status_refresh_reason": reason,
            "runtime_ready": True,
            "paper_runtime_path": "v392_stable_loop_base_single_trace_writer",
        })
        save_json(FILES.get("status", BASE_DIR / "paper_bot_status.json"), st)
    except Exception as exc:
        try: log_error("v392_touch_status", exc)
        except Exception: pass


_v392_base_candidate_input_path = candidate_input_path if 'candidate_input_path' in globals() else None

def candidate_input_path(lane: str) -> Path:  # type: ignore[override]
    if lane == "strict":
        try:
            _v392_build_candidate_merge(load_control())
            return FILES.get("paper_merged", BASE_DIR / "paper_candidates_handoff_merged.jsonl")
        except Exception as exc:
            try: log_error("v392_candidate_input", exc)
            except Exception: pass
    if callable(_v392_base_candidate_input_path):
        return _v392_base_candidate_input_path(lane)
    return FILES["paper_candidates"] if lane == "strict" else FILES["shadow_candidates"]


_v392_prev_run_cycle = run_cycle

def run_cycle() -> Dict[str, Any]:  # type: ignore[override]
    try:
        res = _v392_prev_run_cycle()
    except Exception as exc:
        try: log_error("v392_base_run_cycle", exc)
        except Exception: pass
        res = {"error": str(exc), "version": VERSION}
    _v392_touch_status("run_cycle_v392")
    _v392_save_trace("run_cycle_v392")
    try:
        _v077_build_score_cache("run_cycle_v392") if '_v077_build_score_cache' in globals() else None
    except Exception as exc:
        try: log_error("v392_score_cache", exc)
        except Exception: pass
    return res if isinstance(res, dict) else {"version": VERSION}


# Replace the old pointer-based worker loop with a direct current run_cycle loop. No old
# _v050_original_run_cycle pointer can send execution back to stale trace code.
def worker_loop() -> None:  # type: ignore[override]
    log("worker_loop v392 single runtime started")
    next_full = 0.0
    while not _stop_event.is_set():
        try:
            control = load_control()
            heartbeat_log("worker")
            nowv = now()
            if nowv >= next_full:
                run_cycle()
                next_full = now() + float_any(control.get("loop_seconds"), default=8.0)
            else:
                try:
                    monitor_open_positions(control)
                except Exception as exc:
                    try: log_error("v392_monitor_open", exc)
                    except Exception: pass
            interval = max(0.8, min(3.0, float_any(control.get("open_monitor_interval_sec"), default=1.5)))
            _stop_event.wait(interval)
        except Exception as exc:
            log_error("worker_loop_v392", exc)
            _v392_touch_status("worker_loop_v392_error")
            _v392_save_trace("worker_loop_v392_error")
            _stop_event.wait(2)
    log("worker_loop v392 stopped")


try:
    _v392_touch_status("startup_v392")
    _v392_save_trace("startup_v392")
except Exception as exc:
    try: log_error("v392_startup", exc)
    except Exception: pass

if __name__ == "__main__":
    main()
