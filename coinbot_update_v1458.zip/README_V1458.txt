coinbot_update_v1458
- Read-only S1 drought gate breakdown map.
- /s1_drought shows why S1 is zero by gate/reason buckets and near-miss candidates.
- /candidate_flow appends the S1 drought summary when S1=0.
- No trading rule, candidate criteria, OPEN rule, trigger/invalid/target/RR, stale pass, BUY_READY, or auto-buy change. Auto-buy OFF.
