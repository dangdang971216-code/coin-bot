#!/usr/bin/env python3
from pathlib import Path
import json,hashlib
ROOT=Path(__file__).resolve().parent
m=json.loads((ROOT/'DEPLOY_BUNDLE.json').read_text(encoding='utf-8'))
assert m['version']=='v1168'
assert m['main'] is None and m['guard'] is None and m['paper'] is None and m['micro'] is None
assert m['workers']=={'strategy':'strategy_worker_v1.027.py'}
assert m['auto_buy'] is False and m['live_ledger_included'] is False
assert m['strategy_source_change'] is True
assert m['trigger_path_contract_change'] is False
assert m['candidate_ttl_change'] is False and m['exit_contract_change'] is False
for name,digest in m['source_sha256'].items():
    assert hashlib.sha256((ROOT/name).read_bytes()).hexdigest()==digest,(name,digest)
for name in m['support_files']:
    if name in {'FILES_SHA256_v1168.tsv','LOCAL_TEST_RESULT_V1168.txt','PACKAGE_VERIFY_V1168.txt'}:
        continue
    assert (ROOT/name).exists(),name
for forbidden in ('strategy_worker.py','paper_bot.py','bot.py','backga_guard_bot.py',
                  'paper_bot_open.json','paper_bot_closed.jsonl','paper_bot_trade_log.jsonl',
                  'issue_ledger.jsonl','change_verify_ledger.jsonl'):
    assert not (ROOT/forbidden).exists(),forbidden
print('PASS v1168 package')
