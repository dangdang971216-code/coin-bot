#!/usr/bin/env python3
from __future__ import annotations
import ast, hashlib, math
from pathlib import Path
from typing import Any, Dict, List, Optional, Tuple

ROOT=Path(__file__).resolve().parent
STRATEGY=ROOT/'strategy_worker_v1.027.py'
text=STRATEGY.read_text(encoding='utf-8')
tree=ast.parse(text)

assert "VERSION = 'strategy_worker_v1.027'" in text
assert "BUILD_LABEL = 'v1168_current_strategy_runtime_cleanup_2026-07-01'" in text

# Removed active paths must be absent.
for forbidden in (
    'strategy_candidate_path_events_v1153.jsonl',
    'strategy_candidate_path_state_v1153.json',
    'def _v1153_strategy_event_once',
    'def _v1153_capture_strategy_gate_path',
    'def _v1119_record_io',
    'def _v1119_io_snapshot',
    "hard.extend(list(quality_gate.get('block_reasons') or []))",
    "_refresh_strategy_singleton_status_v1113('cycle_start')",
    "_refresh_strategy_singleton_status_v1113('cycle_end')",
):
    assert forbidden not in text, forbidden

# Current v1167 trigger/structure/execution core must be exact.
expected_ast={
 '_v925_current_actual_plan':'52861f3e88b72c5e25cbad38f2b2d156bcbf444cb4bdf13f1669fa5f15ef6995',
 '_v925_slippage_confirmed':'ca3049cff2e4eec558e438f0631e5db1ac4edf2398c6b8de3d50ef5bde2ce716',
 '_trigger_path_points':'8a8c44e671c05f3dd63fbf458dea021a79ec7a4b7df399dc75137ad83223cf8d',
 '_latest_trigger_rebreak':'6d56857df116dcd0968e68863ee70f5d36cce439165c25c8c7cc3fab3bfb37dd',
 '_trigger_occurrence':'5f1a4bb2528c125ec0901d500efb99c4902c9bb137dae8737f8f03110256ee8b',
 '_v1039_execution_freshness':'4c711c95e8e8912f2fc4a38ba1da95e5b225edc68f6e64b75ba27f8e63138481',
}
nodes={n.name:n for n in tree.body if isinstance(n,(ast.FunctionDef,ast.AsyncFunctionDef))}
for name,digest in expected_ast.items():
    assert name in nodes,name
    actual=hashlib.sha256(ast.dump(nodes[name],include_attributes=False).encode()).hexdigest()
    assert actual==digest,(name,actual,digest)

# Numeric hard contracts remain exact.
wanted={'V925_UNTRADABLE_SPREAD_PCT','V925_MIN_RR','V925_MIN_TARGET_ROOM_PCT','V977_MAX_TRIGGER_OVERSHOOT_PCT'}
values={}
for node in tree.body:
    if isinstance(node,ast.Assign):
        for target in node.targets:
            if isinstance(target,ast.Name) and target.id in wanted:
                values[target.id]=ast.literal_eval(node.value)
assert values=={
 'V925_UNTRADABLE_SPREAD_PCT':1.2,
 'V925_MIN_RR':1.5,
 'V925_MIN_TARGET_ROOM_PCT':1.2,
 'V977_MAX_TRIGGER_OVERSHOOT_PCT':0.6,
},values

# Quality remains calculated and used in selector rank, not duplicated into hard reasons.
assert "quality_gate = _swing_quality_gate(row, rr, room, spread, confirmed_slip)" in text
assert "eligible_rows.sort(key=lambda r:(-float(r.get('swing_quality_rank_score')" in text
assert "'quality_final_hard_block_v1039':False" in text
assert "'quality_metric_hard_block_count_v1039':0" in text
assert "'quality_metric_role_v1039':'score_priority_record_only'" in text

# Only fail writes and final NORMAL remain in the pipeline status hot path.
assert "'STARTED'" not in text
assert "'S1_HOLD_COMMITTED'" not in text
assert "'CANDIDATE_COMMITTED'" not in text
assert "_v1150_pipeline_cycle_id, 'NORMAL'" in text
assert text.count("_v1150_write_pipeline_status(")==5  # definition + 3 FAIL + final NORMAL

# Candidate standard source/hash contract is written once at startup, not each cycle.
call_count=0
for node in ast.walk(tree):
    if isinstance(node,ast.Call) and isinstance(node.func,ast.Name) and node.func.id=='_v1141_write_candidate_standard_contract':
        call_count += 1
assert call_count==1,call_count

# Execute canonical trigger path fixture from the new source.
def extract(names:set[str], ns:dict):
    selected=[n for n in tree.body if isinstance(n,ast.FunctionDef) and n.name in names]
    assert names=={n.name for n in selected}
    mod=ast.Module(body=selected,type_ignores=[])
    ast.fix_missing_locations(mod)
    exec(compile(mod,str(STRATEGY),'exec'),ns)

def fnum(*values:Any,default:float=0.0)->float:
    for value in values:
        try:
            if value not in (None,'',[],{},'-'):
                return float(value)
        except Exception:
            pass
    return default

ns={'Any':Any,'Dict':Dict,'List':List,'Optional':Optional,'Tuple':Tuple,'hashlib':hashlib,'fnum':fnum}
extract({'_v925_num','build_minimal_gate_decision_key','_v1159_terminal_feedback_match',
         '_trigger_path_points','_latest_trigger_rebreak','_trigger_occurrence'},ns)
trigger=ns['_trigger_occurrence']
base=1000.0
rec={'frozen_ts':base,'trigger_occurrence_schema':'trigger_occurrence_v1'}
path={'ready':True,'source':'bithumb_transaction_history','last_ts':base+3,'age_sec':0.1,
      'points':[[base+1,99.0],[base+2,100.0],[base+3,101.0]]}
event,key=trigger(rec,'market:TEST',101.0,100.0,base+3,True,path,{})
assert key and event['kind']=='QUALIFIED_PATH_REBREAK'
assert event['event_ts']==base+2 and event['reset_ts']==base+1

# Quality ranking function still produces evidence, including a weak advisory result.
qns={'Any':Any,'Dict':Dict,'Optional':Optional,'Tuple':Tuple,'math':math}
extract({'_v1095_known_num','_v1095_clip','_swing_quality_gate'},qns)
rank=qns['_swing_quality_gate']
weak=rank({'price_reaction_pct':-0.8,'relative_strength_pct':-2.0,'money_flow_score':20,
           'buy_ratio':0.3,'buy_sustain_1m':0.2},2.0,2.0,0.3,0.0)
assert weak['hard_pass'] is False and weak['rank_score']>=0
assert 'ranking/advisory' in weak['policy']

print('PASS v1168 current Strategy cleanup contract')
