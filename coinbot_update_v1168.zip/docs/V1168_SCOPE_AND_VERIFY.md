# v1168 범위와 검수

## 목적
과거 수익 구간 코드를 현재에 이식하지 않는다. v1051과 v1167을 비교해 현재 본선에 나중에 들어온 중복 차단과 관찰용 동기식 파일쓰기만 제거한다.

## 현재 코드에서 삭제
1. quality 결과를 final hard reason에 다시 추가하는 중복 경로
2. 후보마다 JSONL append/fsync 후 전체 state JSON을 다시 쓰는 v1153 경로
3. 모든 JSON I/O에 stat·시간을 누적하던 v1119 profiler
4. cycle start/end singleton status 쓰기
5. cycle마다 전체 Strategy source SHA256을 읽던 candidate standard writer 호출
6. 완료 전 STARTED/S1/CANDIDATE 성공상태 파일쓰기

## 유지
- 현재 v1167 실제 체결 가격경로 trigger
- 구조·freshness·RR·목표공간·비용 hard contract
- quality score와 S1 후보 rank 정렬
- 실패 fail-closed와 최종 completed handoff
- Paper TTL과 청산계약

## 서버 성공 기준
표시가 늘어난 것으로 성공 처리하지 않는다. Strategy 속도와 후보 수, 같은 handoff의 Strategy S1/Paper 입력, 신규 오류, 구 파일 증가 중단으로만 판정한다.
