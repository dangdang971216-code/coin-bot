#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""수익형_v2.13.467.py

Clean main bot renewal phase v366.
- 메인봇은 무거운 전체시장 스캔/정밀/전략판정을 직접 하지 않는다.
- scanner/feature/orderflow/strategy/review worker가 만든 캐시만 읽는다.
- 실제 paper OPEN은 strategy worker의 S급 후보만 허용한다.
- A/B/C 실시간 후보와 무거운 가상복기는 메인봇 경로에서 제거한다.
"""
from __future__ import annotations
import json, os, sys, time, traceback, re
from pathlib import Path
from typing import Any, Dict, List, Optional, Tuple
import threading
from collections import Counter, defaultdict

try:
    from telegram import Bot, BotCommand
    from telegram.ext import Updater, CommandHandler, MessageHandler, Filters
except Exception:
    Bot = None; BotCommand = None; Updater = None; CommandHandler = None; MessageHandler = None; Filters = None

BOT_VERSION = '수익형 v2.13.806'
BASE_DIR=Path(__file__).resolve().parent
TELEGRAM_TOKEN=os.getenv("TELEGRAM_TOKEN","").strip()
CHAT_ID=os.getenv("CHAT_ID","").strip()
WORKERS={
    "scanner": {"file":"scanner_worker_v0.3.py", "status":"clean_scanner_status.json"},
    "candle": {"file":"candle_worker_v0.2.py", "status":"clean_candle_status.json"},
    "market": {"file":"market_regime_worker_v0.1.py", "status":"clean_market_regime_status.json"},
    "feature": {"file":"feature_worker_v0.2.py", "status":"clean_feature_status.json"},
    "orderflow": {"file":"orderflow_worker_v0.8.py", "status":"clean_orderflow_status.json"},
    "risk": {"file":"risk_worker_v0.2.py", "status":"clean_risk_status.json"},
    "strategy": {"file":"strategy_worker_v0.52.py", "status":"clean_strategy_worker_status.json"},
    "target_router": {"file":"target_router_worker_v0.8.py", "status":"clean_target_router_status.json"},
    "review": {"file":"review_worker_v0.11.py", "status":"clean_review_worker_status.json"},
}
FILES={
    "brain_status":BASE_DIR/"clean_brain_status.json",
    "brain_runtime":BASE_DIR/"clean_brain_runtime.log",
    "brain_error":BASE_DIR/"clean_brain_error.log",
    "resource":BASE_DIR/"clean_resource_status.json",
    "scanner_market":BASE_DIR/"clean_scanner_market_cache.json",
    "feature":BASE_DIR/"clean_feature_cache.json",
    "orderflow":BASE_DIR/"clean_orderflow_summary_cache.json",
    "strategy_summary":BASE_DIR/"clean_strategy_s_summary.json",
    "candle":BASE_DIR/"clean_candle_cache.json",
    "market_regime":BASE_DIR/"clean_market_regime_cache.json",
    "risk":BASE_DIR/"clean_risk_filter_cache.json",
    "strategy_reject":BASE_DIR/"clean_strategy_s_reject_summary.json",
    "review":BASE_DIR/"clean_review_summary.json",
    "paper_status":BASE_DIR/"paper_bot_status.json",
    "paper_open":BASE_DIR/"paper_bot_open.json",
    "paper_score":BASE_DIR/"paper_bot_score_cache.json",
    "paper_latest":BASE_DIR/"paper_candidates_latest.jsonl",
    "paper_archive":BASE_DIR/"paper_candidates.jsonl",
    "paper_handoff":BASE_DIR/"clean_strategy_paper_handoff_status.json",
    "paperbot_handoff":BASE_DIR/"paper_bot_candidate_handoff_status.json",
    "candidate_handoff_trace":BASE_DIR/"paper_bot_candidate_handoff_trace.json",
    "candidate_reason_text":BASE_DIR/"clean_candidate_reason_text_cache.txt",
    "candidate_reason_text_state":BASE_DIR/"clean_candidate_reason_state_cache.json",
    "trigger_shadow_review":BASE_DIR/"clean_trigger_shadow_review_v665.json",
    "paper_closed":BASE_DIR/"paper_bot_closed.jsonl",
    "score_anchor":BASE_DIR/"paper_bot_current_score_anchor.json",
    "target_router":BASE_DIR/"clean_target_router_queue.json",
    "ws_status":BASE_DIR/"clean_ws_sidecar_status.json",
    "micro_status":BASE_DIR/"clean_bithumb_micro_status.json",
    "micro_targets":BASE_DIR/"clean_micro_targets.json",
}
START_TS=time.time()
_V782_CANDIDATE_SNAPSHOT_CACHE: Dict[str, Any] = {'ts': 0.0, 'snap': None}

def now_ts()->float: return time.time()
def now_text(ts:Optional[float]=None)->str: return time.strftime("%Y-%m-%d %H:%M:%S", time.localtime(ts or now_ts()))
def fnum(v:Any, *more:Any, default:float=0.0)->float:
    """안전 숫자 변환.

    기존 호출(fnum(x, -1.0))은 두 번째 인자를 fallback 값처럼 쓰고,
    v345 preview 쪽 호출(fnum(a,b,c, default=0))은 앞에서부터 숫자값을 고른다.
    """
    for val in (v,) + tuple(more):
        try:
            if val is None or val == "":
                continue
            return float(str(val).replace(",", ""))
        except Exception:
            continue
    return default

def norm_ticker(v: Any) -> str:
    """메인봇 preview 전용 안전 티커 정규화.

    v345에서 paper 추적 로직이 norm_ticker를 참조했지만 메인봇 파일에는
    정의가 없어 /preview NameError가 났다. 여기서는 거래소 접두사/마켓 접미사만
    정리하고, 판단 로직에는 관여하지 않는다.
    """
    try:
        s = str(v or "").strip().upper()
        if not s:
            return ""
        if ":" in s:
            s = s.split(":", 1)[1]
        for suf in ("_KRW", "-KRW", "/KRW", "KRW"):
            if s.endswith(suf):
                s = s[:-len(suf)]
                break
        s = s.replace("_", "").replace("-", "").replace("/", "")
        return s
    except Exception:
        return ""

def load_json(path:Path, default:Any=None)->Any:
    try:
        if not path.exists(): return default
        return json.loads(path.read_text(encoding="utf-8", errors="ignore"))
    except Exception: return default

def save_json(path:Path,obj:Any)->None:
    path.parent.mkdir(parents=True,exist_ok=True)
    tmp=path.with_suffix(path.suffix+".tmp")
    tmp.write_text(json.dumps(obj,ensure_ascii=False,separators=(",",":"),default=str),encoding="utf-8")
    os.replace(tmp,path)

def read_jsonl(path:Path,max_lines:int=1000)->List[Dict[str,Any]]:
    """JSONL tail reader for Telegram status commands.

    Older code used path.read_text().splitlines(), which read the entire paper
    CLOSED ledger even when only recent rows were needed. That made /health,
    /pstatus and /version_score block for minutes after the ledger grew.
    This keeps default commands cache/tail-only: read only the end of the file,
    then parse at most max_lines rows.
    """
    if not path.exists(): return []
    try:
        max_lines = max(1, int(max_lines or 1000))
    except Exception:
        max_lines = 1000
    try:
        size = path.stat().st_size
        # Enough for normal JSONL status rows, bounded so a huge ledger never
        # blocks the Telegram command loop. Larger requests get a larger tail,
        # but are still capped for safety.
        tail_bytes = min(size, max(256_000, min(8_000_000, max_lines * 4096)))
        with path.open('rb') as f:
            if size > tail_bytes:
                f.seek(-tail_bytes, os.SEEK_END)
                f.readline()  # drop possible partial first line
            data = f.read().decode('utf-8', errors='ignore')
        lines = data.splitlines()
        if len(lines) > max_lines:
            lines = lines[-max_lines:]
        out=[]
        for ln in lines:
            try:
                if ln.strip():
                    o=json.loads(ln)
                    if isinstance(o,dict): out.append(o)
            except Exception:
                pass
        return out
    except Exception:
        return []

def line_count(path: Path, max_bytes: int = 2_000_000) -> int:
    try:
        if not path.exists(): return 0
        if path.stat().st_size > max_bytes:
            # 큰 archive는 기본 명령에서 전체를 세지 않는다. tail이 아니라 대략 표시만 한다.
            return -1
        return len(path.read_text(encoding="utf-8", errors="ignore").splitlines())
    except Exception: return 0

def log_runtime(msg:str)->None:
    try:
        with FILES["brain_runtime"].open("a",encoding="utf-8") as f: f.write(f"[{now_text()}] {msg}\n")
    except Exception: pass

def log_error(where:str,exc:BaseException)->None:
    try:
        with FILES["brain_error"].open("a",encoding="utf-8") as f:
            f.write(f"[{now_text()}] {where}: {exc.__class__.__name__}: {exc}\n{traceback.format_exc()[-1500:]}\n")
    except Exception: pass

def age(path:Path)->float:
    try: return max(0.0, now_ts()-path.stat().st_mtime)
    except Exception: return 999999.0

def pid_alive(pid:int)->bool:
    if pid<=0: return False
    try: os.kill(pid,0); return True
    except Exception: return False

def worker_status(name:str)->Dict[str,Any]:
    spec=WORKERS[name]; path=BASE_DIR/spec["status"]
    obj=load_json(path,{}) or {}; pid=int(fnum(obj.get("pid"),default=0)); alive=pid_alive(pid)
    a=age(path)
    state=str(obj.get("state") or "missing") if obj else "missing"
    return {"name":name,"state":state,"pid":pid,"alive":alive,"age":round(a,1),"version":obj.get("version","-"),"last_sec":obj.get("last_sec","-"),"row_count":obj.get("row_count",obj.get("evaluated",obj.get("closed_recent","-"))),"raw":obj}

def ensure_workers()->None:
    # v329: worker 실행/재시작은 가드봇 systemd 전담. 메인봇은 절대 직접 worker를 켜지 않는다.
    return

def resource_snapshot()->Dict[str,Any]:
    try:
        import shutil
        total, used, free = shutil.disk_usage(BASE_DIR)
        mem_total=mem_free=0
        try:
            for ln in Path('/proc/meminfo').read_text().splitlines():
                if ln.startswith('MemTotal:'): mem_total=int(ln.split()[1])*1024
                if ln.startswith('MemAvailable:'): mem_free=int(ln.split()[1])*1024
        except Exception: pass
        load=os.getloadavg() if hasattr(os,'getloadavg') else (0,0,0)
        return {"disk_free_gb":round(free/1024**3,2),"disk_used_pct":round(used/total*100,1),"mem_free_mb":round(mem_free/1024**2,1) if mem_free else 0,"mem_used_pct":round((1-mem_free/mem_total)*100,1) if mem_total and mem_free else 0,"load":[round(x,2) for x in load]}
    except Exception as exc:
        log_error("resource_snapshot",exc); return {}

def update_brain_status(state:str="running")->None:
    """메인봇 heartbeat/status만 저장한다.
    v329 기준 worker 실행/재시작은 가드봇 systemd 전담이다.
    """
    workers={k:worker_status(k) for k in WORKERS}
    save_json(FILES["brain_status"],{
        "version":BOT_VERSION,
        "state":state,
        "telegram_state":state,
        "pid":os.getpid(),
        "updated_ts":now_ts(),
        "updated_text":now_text(),
        "uptime_sec":round(now_ts()-START_TS,1),
        "workers":workers,
        "resource":resource_snapshot(),
        "note":"v330 main is cache-only; worker lifecycle is guard/systemd only",
    })

def worker_ok(st:Dict[str,Any])->str:
    state=str(st.get('state') or '').lower()
    a=fnum(st.get('age'), default=999999)
    if state in {'error','failed','stopped','missing','dead'}:
        return '❌'
    if state in {'running','ready','ok','initializing'}:
        return '✅' if a < 45 else '⚠️'
    return '❔'

def line_worker(st:Dict[str,Any], detail:bool=False)->str:
    icon=worker_ok(st)
    base=f"- {icon} {st['name']}: {st.get('version','-')} / {st.get('state')} / age {st.get('age')}s"
    if detail:
        base += f" / rows {st.get('row_count')} / sec {st.get('last_sec')}"
    return base

def router_flow_summary(router: Dict[str, Any]) -> str:
    """v337: target_router를 개수 제한표가 아니라 전체/우선/순환/대기/버림으로 보여준다."""
    if not isinstance(router, dict) or not router:
        return "- 정보배차: 상태 없음"
    return (
        f"- 정보배차: 전체 {router.get('queue_count','-')} / 최우선 {router.get('priority_protected_count','-')} "
        f"/ 이번내보냄 {router.get('active_target_count', router.get('target_count','-'))} "
        f"/ 순환대기 {router.get('rotation_wait_count', router.get('backlog_count','-'))} "
        f"/ 버림 {router.get('dropped_count',0)}"
    )

def router_flow_detail(router: Dict[str, Any]) -> List[str]:
    if not isinstance(router, dict) or not router:
        return ["- 정보배차 상태 없음"]
    return [
        router_flow_summary(router),
        f"- 채워야할 정보: WS필요 {router.get('need_ws','-')} / micro필요 {router.get('need_micro','-')} / fresh회복 {router.get('fresh_recovered','-')}",
        f"- 순환상태: rotation pool {router.get('rotation_pool_count','-')} / 이번순환 {router.get('rotation_export_count','-')} / 다음커서 {router.get('next_rotation_cursor','-')}",
        f"- 보호슬롯: 전략요청 {router.get('strategy_req_total_count','-')} / 강제보호 {router.get('strategy_req_forced_active_count','-')} / micro요청 {router.get('strategy_req_micro_target_count','-')}",
    ]


def health_text()->str:
    # v340: health는 기본 상태판이므로 v338 형식 유지. worker 시작/재시작/직접계산 금지.
    update_brain_status('running')
    workers=[worker_status(k) for k in WORKERS]
    res=resource_snapshot()
    paper=load_json(FILES['paper_status'],{}) or {}
    ws=load_json(FILES['ws_status'],{}) or {}
    micro=load_json(FILES['micro_status'],{}) or {}
    strat=load_json(FILES['strategy_summary'],{}) or {}
    reject=load_json(FILES['strategy_reject'],{}) or {}
    oflow=load_json(FILES['orderflow'],{}) or {}
    router=load_json(FILES['target_router'],{}) or {}
    good=sum(1 for w in workers if worker_ok(w)=='✅')
    warn=sum(1 for w in workers if worker_ok(w)=='⚠️')
    bad=sum(1 for w in workers if worker_ok(w)=='❌')
    evaluated = int(fnum(reject.get('evaluated') or strat.get('evaluated') or 0, 0))
    quote_ready = int(fnum(strat.get('quote_ready_count') or reject.get('quote_ready_count') or oflow.get('quote_fresh') or 0, 0))
    micro_ready = int(fnum(strat.get('micro_ready_count') or reject.get('micro_ready_count') or oflow.get('fresh_micro') or 0, 0))
    full_ready = int(fnum(strat.get('full_info_ready_count') or reject.get('full_info_ready_count') or oflow.get('info_ready') or 0, 0))
    sent_count = router.get('export_count', router.get('active_target_count', router.get('target_count','-')))
    lines=[
        "🧭 건강상태 /health",
        f"✅ 메인봇 {BOT_VERSION} / clean worker hub v369 / uptime {int(now_ts()-START_TS)}s",
        "",
        "[한눈요약 · 기존 health 값 유지]",
        f"✅ 전체 {evaluated or '-'}개 평가 / 시세 {quote_ready}/{evaluated or '-'} / 호가·체결 {micro_ready}/{evaluated or '-'} / 둘다 {full_ready}/{evaluated or '-'}",
        f"✅ 배차 전체 {router.get('queue_count','-')}개 → 이번내보냄 {sent_count}개 / 순환대기 {router.get('rotation_wait_count','-')}개 / 버림 {router.get('dropped_count',0)}개",
        f"✅ worker 정상 {good}개 / 주의 {warn}개 / 문제 {bad}개",
        f"✅ 오류 없음 기준은 /errorlog / 메모리 {res.get('mem_used_pct','-')}% / load {res.get('load','-')}",
        "",
        f"- worker: ✅ {good} / ⚠️ {warn} / ❌ {bad}",
        f"- paper: {paper.get('version','-')} / OPEN {paper.get('open_count', paper.get('open_total','-'))} / age {age(FILES['paper_status']):.1f}s",
        f"- WS: age {age(FILES['ws_status']):.1f}s / cache {ws.get('cache', ws.get('cache_count','-'))} / fresh {ws.get('fresh','-')}",
        f"- micro: age {age(FILES['micro_status']):.1f}s / targets {micro.get('targets','-')} / batch {micro.get('poll_batch','-')} / cached {micro.get('cached','-')} / fresh {micro.get('fresh','-')}",
        f"- orderflow: quote {oflow.get('quote_fresh','-')} / micro {oflow.get('fresh_micro','-')} / ready {oflow.get('info_ready','-')} / active {oflow.get('active_count','-')}",
        router_flow_summary(router),
        f"- S 후보 {strat.get('s_count',0)} / 평가 {reject.get('evaluated','-')} / 탈락 {reject.get('reject_count','-')}",
        f"- 디스크 {res.get('disk_used_pct','-')}% / 남음 {res.get('disk_free_gb','-')}GB / 메모리 {res.get('mem_used_pct','-')}% / load {res.get('load','-')}",
        "",
        "[worker 요약]",
    ]
    lines += [line_worker(w, detail=False) for w in workers]
    lines += ["", "[worker 품질 · v482]"]
    try:
        lines += _v482_worker_quality_lines({k: worker_status(k) for k in WORKERS})
    except Exception as exc:
        lines.append(f"- ⚠️ worker 품질 요약 생성 실패: {exc.__class__.__name__}")
    lines += ["", "[원칙] 메인봇은 worker cache만 읽음. worker 실행/재시작은 가드봇 systemd 전담. v482부터 running/age뿐 아니라 data-quality도 같이 봄."]
    return "\n".join(lines)

def _worker_metric_int(st: Dict[str, Any], *keys: str) -> Any:
    raw = st.get('raw') if isinstance(st.get('raw'), dict) else {}
    for k in keys:
        v = raw.get(k)
        if v not in (None, '', '-'):
            return v
    return '-'


def _v482_worker_quality_lines(workers: Dict[str, Dict[str, Any]]) -> List[str]:
    """v482: worker가 살아있는지만 보던 상태판 착시를 줄인다.

    메인봇은 여전히 cache/status만 읽는다. 여기서는 worker가 이미 저장한
    품질 숫자만 요약한다: hot-rank 생성, 1m/3m 실제 source, hot target 배차,
    strategy canonical source coverage. 값이 없으면 계산 fallback을 하지 않고 '-'로 표시한다.
    """
    def raw(name: str) -> Dict[str, Any]:
        st = workers.get(name, {}) if isinstance(workers, dict) else {}
        return st.get('raw') if isinstance(st.get('raw'), dict) else {}
    scanner = raw('scanner')
    feature = raw('feature')
    target = raw('target_router')
    strategy = raw('strategy')
    router = load_json(FILES.get('target_router', BASE_DIR/'clean_target_router_queue.json'), {}) or {}
    hot = load_json(BASE_DIR/'clean_scanner_hot_rank_cache.json', {}) or {}
    feat_cache = load_json(FILES.get('feature', BASE_DIR/'clean_feature_cache.json'), {}) or {}
    lines: List[str] = []
    # Scanner: process alive != hot-rank usable. Show both known count and hot cache age.
    lines.append(
        f"- scanner 품질: hot1m {scanner.get('hot_known_1m', hot.get('known_1m','-'))} / "
        f"hot3m {scanner.get('hot_known_3m', hot.get('known_3m','-'))} / "
        f"hot cache age {age(BASE_DIR/'clean_scanner_hot_rank_cache.json'):.1f}s"
    )
    # Feature: show real short-flow source coverage. v481 removed fake 24h/1440 fallback.
    lines.append(
        f"- feature 품질: 1m known {feature.get('known_1m', feat_cache.get('known_1m','-'))} / "
        f"3m known {feature.get('known_3m', feat_cache.get('known_3m','-'))} / "
        f"1m missing {feature.get('missing_1m', feat_cache.get('missing_1m','-'))} / "
        f"3m missing {feature.get('missing_3m', feat_cache.get('missing_3m','-'))} / "
        f"hot 사용 {feature.get('hot_used', feat_cache.get('hot_used','-'))}"
    )
    # Router: show whether hot-rank actually entered active collection targets.
    lines.append(
        f"- target 품질: hot 요청 {target.get('hot_rank_req_count', router.get('hot_rank_req_count','-'))} / "
        f"hot active {target.get('hot_rank_active_count', router.get('hot_rank_active_count','-'))} / "
        f"recheck 요청 {target.get('recheck_req_count', router.get('recheck_req_count','-'))} / "
        f"recheck micro {target.get('recheck_micro_target_count', router.get('recheck_micro_target_count','-'))}"
    )
    # Strategy: show current canonical source schema where available.
    lines.append(
        f"- strategy 품질: canonical {strategy.get('canonical_metric_schema', strategy.get('stage_policy_schema','-'))} / "
        f"S1 {strategy.get('s1_count','-')} / S2 {strategy.get('s2_count','-')} / S3 {strategy.get('s3_count','-')} / "
        f"target {strategy.get('target_count','-')}"
    )
    return lines

def workers_text()->str:
    update_brain_status('running')
    workers={k:worker_status(k) for k in WORKERS}
    router=load_json(FILES['target_router'],{}) or {}
    strat=load_json(FILES['strategy_summary'],{}) or {}
    oflow=load_json(FILES['orderflow'],{}) or {}
    scanner=workers.get('scanner',{})
    feature=workers.get('feature',{})
    candle=workers.get('candle',{})
    market=workers.get('market',{})
    orderflow=workers.get('orderflow',{})
    risk=workers.get('risk',{})
    strategy=workers.get('strategy',{})
    target=workers.get('target_router',{})
    review=workers.get('review',{})
    lines=["🧩 worker 상태 /workers", "- 메인봇은 상태파일만 읽고 worker를 직접 실행하지 않음.", "", "[시장/재료]"]
    lines.append(f"- {worker_ok(scanner)} 스캐너: 전체 {_worker_metric_int(scanner,'row_count','pool_count')}개 수집 / {scanner.get('last_sec','-')}초")
    lines.append(f"- {worker_ok(feature)} 특징: {_worker_metric_int(feature,'row_count')}개 표준값 / {feature.get('last_sec','-')}초")
    lines.append(f"- {worker_ok(candle)} 캔들: {_worker_metric_int(candle,'row_count')}개 보강 / target {_worker_metric_int(candle,'target_count')} / {candle.get('last_sec','-')}초")
    lines.append(f"- {worker_ok(market)} 장세: {_worker_metric_int(market,'row_count')}개 확인 / {market.get('last_sec','-')}초")
    lines += ["", "[정보 보강]"]
    lines.append(f"- {worker_ok(orderflow)} 호가요약: 전체 {_worker_metric_int(orderflow,'row_count')}개 / WS {_worker_metric_int(orderflow,'fresh_ws')} / micro {_worker_metric_int(orderflow,'fresh_micro')} / {orderflow.get('last_sec','-')}초")
    lines.append(f"- {worker_ok(target)} 정보배차: 전체 {router.get('queue_count','-')}개 → 내보냄 {router.get('export_count',router.get('active_target_count','-'))}개 / 순환대기 {router.get('rotation_wait_count','-')} / 버림 {router.get('dropped_count',0)}")
    lines += ["", "[판정/복기]"]
    # v346: strategy status가 순간적으로 rows 0으로 보일 때 summary 캐시 기준값으로 보정 표시.
    # 상태 판단은 worker status를 쓰되, 숫자 표시는 clean_strategy_s_summary / reject summary까지 같이 본다.
    reject_sum = load_json(FILES['strategy_reject'], {}) or {}
    st_eval = _worker_metric_int(strategy,'evaluated','row_count')
    if st_eval in ('-', None, '', 0, '0'):
        st_eval = strat.get('evaluated') or reject_sum.get('evaluated') or '-'
    st_s = _worker_metric_int(strategy,'s_count')
    if st_s in ('-', None, ''):
        st_s = strat.get('s_count', 0)
    st_pending = _worker_metric_int(strategy,'info_pending_count')
    if st_pending in ('-', None, ''):
        st_pending = strat.get('info_pending_count') or reject_sum.get('info_pending_count') or 0
    st_sec = strategy.get('last_sec','-')
    if st_sec in ('-', None, '', 0, '0'):
        st_sec = strat.get('last_sec') or reject_sum.get('last_sec') or st_sec
    lines.append(f"- {worker_ok(strategy)} 전략판정: 평가 {st_eval}개 / S {st_s}개 / 정보대기 {st_pending}개 / {st_sec}초")
    lines.append(f"- {worker_ok(risk)} 위험: 최근손실/쿨다운 확인 / {risk.get('last_sec','-')}초")
    lines.append(f"- {worker_ok(review)} 복기: 최근완료 {_worker_metric_int(review,'closed_recent')}개 / 큰손실 {_worker_metric_int(review,'big_loss')} / 좋은승리 {_worker_metric_int(review,'good_win')} / {review.get('last_sec','-')}초")
    lines += ["", "[데이터 품질 · v482]"]
    try:
        lines += _v482_worker_quality_lines(workers)
    except Exception as exc:
        lines.append(f"- ⚠️ 데이터 품질 요약 생성 실패: {exc.__class__.__name__}")
    lines += ["", "[상세 원본]"]
    lines += [line_worker(workers[k], detail=True) for k in WORKERS]
    return "\n".join(lines)

def _paper_score_cache_version_ok(ver: str) -> bool:
    """v355: paper score cache gate 단일화.

    기존 v354는 허용 버전을 v0.86~v0.92 목록으로 박아두어 paper_bot이 v0.95로
    올라가면 같은 current-version score cache도 구버전으로 오판했다.
    이제 schema/scope는 그대로 엄격히 보되, paper_bot_v0.86 이상은 버전 숫자로 판정한다.
    구 v0.77/v0.80 계열 cache가 섞이지 않게 86 미만은 계속 차단한다.
    """
    m = re.search(r"paper_bot_v0\.(\d+)", str(ver or ""))
    if not m:
        return False
    return int(m.group(1)) >= 86


def _current_paper_score_cache() -> Dict[str, Any]:
    """v355: /score는 현재판 paper score cache만 읽는다.

    오래된 직접계산 fallback은 쓰지 않는다. 다만 paper_bot 버전이 올라갈 때마다
    메인봇 허용목록을 손으로 추가해야 하는 구경로는 제거했다.
    """
    c = load_json(FILES['paper_score'], {}) or {}
    if not isinstance(c, dict):
        return {}
    if not _paper_score_cache_version_ok(str(c.get('version') or '')):
        return {}
    if str(c.get('schema') or '') != 'paper_score_cache_v086':
        return {}
    if str(c.get('score_scope') or '') != 'current_version_anchor':
        return {}
    if c.get('current_closed_count') is None:
        return {}
    return c


def _score_stat_line(label: str, st: Dict[str, Any]) -> str:
    if not isinstance(st, dict):
        st = {}
    n = int(fnum(st.get('n', st.get('count', 0)), default=0))
    wins = int(fnum(st.get('wins', 0), default=0))
    losses = int(fnum(st.get('losses', 0), default=0))
    wr = fnum(st.get('win_rate', st.get('win_rate_pct', 0)), default=0.0)
    total = fnum(st.get('total', st.get('total_pct', st.get('profit_sum', 0))), default=0.0)
    avg = fnum(st.get('avg', st.get('avg_pct', 0)), default=0.0)
    return f"- {label}: {n}전 {wins}승 {losses}패 / 승률 {wr:.1f}% / 합산 {total:+.2f}% / 평균 {avg:+.2f}%"



def score_text()->str:
    cache = _current_paper_score_cache()
    raw = load_json(FILES['paper_score'], {}) or {}
    lines=["📊 전략별 스코어 /score", "- 목적: 닫힌 paper 결과를 대표전략 기준으로 본다. 중복태그 성과는 참고용."]
    label_map={'money_reaccel_s':'돈흐름 재가속','leader_momentum_s':'주도추세 지속','breakout_early_s':'돌파 초입','sweep_vwap_recovery_s':'저점 VWAP 회복','surge_rebreak_s':'급등 후 재돌파','leader_flow_adaptive_hold_s':'주도흐름 유동보유'}
    if cache:
        gs = cache.get('grade_stats') if isinstance(cache.get('grade_stats'), dict) else {}
        current_n=int(fnum(cache.get('current_closed_count') or 0,0))
        primary_stats = cache.get('strategy_primary_stats') if isinstance(cache.get('strategy_primary_stats'), list) else cache.get('strategy_s_stats') if isinstance(cache.get('strategy_s_stats'), list) else []
        overlap_stats = cache.get('strategy_overlap_stats') if isinstance(cache.get('strategy_overlap_stats'), list) else []
        primary_total=int(fnum(cache.get('strategy_primary_total') or sum(int(fnum(x.get('n') or 0,0)) for x in primary_stats if isinstance(x,dict)),0))
        overlap_total=int(fnum(cache.get('strategy_overlap_total') or sum(int(fnum(x.get('n') or 0,0)) for x in overlap_stats if isinstance(x,dict)),0))
        lines.append(f"- 캐시 age {age(FILES['paper_score']):.1f}s / 현재판 CLOSED {current_n}개 / 대표전략 집계 {primary_total}개")
        lines += [
            _score_stat_line('✅ S 전체', gs.get('S', {})),
            _score_stat_line('현재판 전체', gs.get('ALL', {})),
        ]
        lines += ["", "[대표전략 기준 · 실제 거래수와 맞는 성과]"]
        stat_map={str(st.get('key') or st.get('label') or ''):st for st in primary_stats if isinstance(st,dict)}
        for key,label in label_map.items():
            lines.append(_score_stat_line(label, stat_map.get(key, {})))
        if overlap_stats:
            lines += ["", f"[중복태그 포함 · 참고용 / 합계 {overlap_total}개]"]
            over_map={str(st.get('key') or st.get('label') or ''):st for st in overlap_stats if isinstance(st,dict)}
            for key,label in label_map.items():
                lines.append(_score_stat_line(label, over_map.get(key, {})))
            if overlap_total > current_n:
                lines.append(f"- ⚠️ 중복태그 때문에 참고용 합계가 CLOSED보다 {overlap_total-current_n}개 많습니다.")
    else:
        old_ver = raw.get('version','없음') if isinstance(raw,dict) else '없음'
        old_schema = raw.get('schema','-') if isinstance(raw,dict) else '-'
        lines.append(f"- ✅ 구 score cache 차단: {old_ver} / {old_schema}")
        lines.append("- 현재판 paper_bot score cache 준비중입니다. 예전 승률·수익률은 기본 /score에 섞지 않습니다.")
    strat=load_json(FILES['strategy_summary'],{}) or {}
    pbh=load_json(FILES['paperbot_handoff'],{}) or {}
    if strat:
        router=load_json(FILES.get('target_router', BASE_DIR/'clean_target_router_queue.json'),{}) or {}
        lines += ["", "[현재 후보/정보 흐름]"]
        lines.append(f"- 현재 S {strat.get('s_count',0)} / latest {strat.get('paper_latest_count',0)} / paper 병합 {pbh.get('merged_fresh','-')} / archive {pbh.get('archive_window','-')}")
        lines.append(f"- 정보: 전체 {strat.get('evaluated','-')}개 / 시세 {strat.get('quote_ready_count','-')} / micro {strat.get('micro_ready_count','-')} / 둘다 {strat.get('full_info_ready_count','-')}")
        lines.append(f"- 배차: 전체 {router.get('queue_count','-')} / 내보냄 {router.get('export_count', router.get('active_target_count','-'))} / 대기 {router.get('rotation_wait_count','-')} / 버림 {router.get('dropped_count',0)}")
    return "\n".join(lines)



def quality_text()->str:
    reject=load_json(FILES['strategy_reject'],{}) or {}; strat=load_json(FILES['strategy_summary'],{}) or {}
    hand=load_json(FILES['paper_handoff'],{}) or {}
    pbh=load_json(FILES['paperbot_handoff'],{}) or {}
    latest_lines=line_count(FILES['paper_latest'])
    archive_lines=line_count(FILES['paper_archive'])
    router=load_json(FILES.get('target_router', BASE_DIR/'clean_target_router_queue.json'),{}) or {}
    evaluated=int(fnum(reject.get('evaluated') or strat.get('evaluated') or 0,0))
    quote=int(fnum(reject.get('quote_ready_count') or strat.get('quote_ready_count') or evaluated,0))
    micro=int(fnum(reject.get('micro_ready_count') or strat.get('micro_ready_count') or 0,0))
    both=int(fnum(reject.get('full_info_ready_count') or strat.get('full_info_ready_count') or min(quote,micro),0))
    not_micro=max(0,evaluated-micro) if evaluated else 0
    dropped=int(fnum(router.get('dropped_count') or 0,0))
    rot_wait=int(fnum(router.get('rotation_wait_count') or 0,0))
    need_micro=int(fnum(router.get('need_micro') or reject.get('info_pending_count') or 0,0))
    lines=[
        "🔍 후보품질 /quality",
        f"✅ 전체 {evaluated}개 평가 / 최종 S {strat.get('s_count',0)}개 / paper latest {latest_lines}줄 / 병합 {pbh.get('merged_fresh','-')}",
        "",
        "[정보가 얼마나 채워졌나]",
        f"- 시세: {quote}/{evaluated}개 / 호가·체결: {micro}/{evaluated}개 / 둘다: {both}/{evaluated}개",
        f"- 아직 micro 미신선: {not_micro}개 / 지금 꼭 필요한 micro: {need_micro}개",
        "",
        "[안 넣은 게 아니라 순환 상태]",
        f"- 전체배차 {router.get('queue_count','-')}개 → 이번내보냄 {router.get('export_count', router.get('active_target_count','-'))}개",
        f"- 순환대기 {rot_wait}개 / 버림 {dropped}개 / safety초과 {router.get('export_over_budget_count',0)}개",
        f"- 최우선 {router.get('priority_protected_count','-')}개 / 보호슬롯 req {router.get('strategy_req_total_count','-')}개 / req_micro_target {router.get('strategy_req_micro_target_count','-')}개",
        "",
        "[후보 판정]",
        f"- cheap탈락 {reject.get('cheap_reject_count','-')} / 정보대기 {reject.get('info_pending_count','-')} / 정보불필요 {reject.get('info_not_requested','-')} / fresh완료 {reject.get('fresh_ready_count','-')}",
        f"- paper 전달: strategy handoff {hand.get('paper_latest_count','-')} / archive {'대형' if archive_lines<0 else str(archive_lines)+'줄'}",
    ]
    evs=strat.get('events') if isinstance(strat.get('events'),list) else []
    cur_s=int(fnum(strat.get('s_count') or 0,0))
    lines += ["", "[현재 최종 S 후보 TOP]" if cur_s else "[latest/handoff 후보 TOP · 현재 S 0이면 보관 후보]"]
    if evs:
        for e in evs[:8]:
            lines.append(f"- {'✅' if cur_s else '❔'} {e.get('ticker')} / {e.get('strategy_bucket_primary_label', e.get('strategy_name'))} / 점수 {e.get('score')} / 근거 {', '.join(e.get('reasons',[])[:4])}")
    else: lines.append("- 없음")
    wait_sample=reject.get('priority_wait_sample') if isinstance(reject.get('priority_wait_sample'),list) else []
    micro_payload=load_json(FILES.get('micro_targets', BASE_DIR/'clean_micro_targets.json'),{}) or {}
    micro_targets=set(str(x).upper() for x in (micro_payload.get('targets') if isinstance(micro_payload.get('targets'),list) else []))
    active_targets=set(str(x).upper() for x in ((router.get('active_targets') or router.get('targets')) if isinstance((router.get('active_targets') or router.get('targets')),list) else []))
    lines += ["", "[정보대기 TOP · 왜 아직 못 들어갔나]"]
    if wait_sample:
        for x in wait_sample[:6]:
            t=str(x.get('ticker') or '').upper(); mt_bool=bool(x.get('micro_target')) or t in micro_targets; act_bool=bool(x.get('router_active')) or t in active_targets
            q='✅' if x.get('quote_ready') else '❌'; m='✅' if x.get('micro_ready') else '❌'; mt='✅' if mt_bool else '❌'; a='✅' if act_bool else '❌'
            if (not mt_bool): why='target 미반영'
            elif not x.get('micro_ready'): why='micro 수집대기'
            else: why='확인필요'
            lines.append(f"- {t}: 시세 {q} / micro {m} / target {mt} / active {a} / {why}")
    else:
        lines.append("- 없음")
    lines += ["", "[탈락 사유 TOP]"]
    tops=reject.get('reason_top') if isinstance(reject.get('reason_top'),list) else []
    for x in tops[:12]:
        reason=str(x.get('reason') or '-')
        icon='⚠️' if ('고점' in reason or '손실' in reason or '매도' in reason or '윗꼬리' in reason) else '❔'
        lines.append(f"- {icon} {reason}: {x.get('count')}")
    if not tops: lines.append("- 아직 없음")
    return "\n".join(lines)


def strategy_watch_text()->str:
    strat=load_json(FILES['strategy_summary'],{}) or {}
    hand=load_json(FILES['paper_handoff'],{}) or {}
    lines=["👀 전략 감시 /strategy_watch", "- 전략별 S만 감시. A/B/C는 기본화면에서 제외.", f"- handoff: latest {hand.get('paper_latest_count','-')} / 새S {hand.get('new_s_count','-')} / append {hand.get('archive_appended','-')}"]
    for k,v in (strat.get('strategies') or {}).items(): lines.append(f"- {k}: S {v}")
    evs=strat.get('events') if isinstance(strat.get('events'),list) else []
    lines += ["", "[OPEN 전달 후보]"]
    if evs:
        for e in evs[:10]: lines.append(f"- ✅ {e.get('ticker')} / {e.get('strategy_bucket_primary_label')} / {e.get('score')} / {', '.join(e.get('reasons',[])[:3])}")
    else: lines.append("- 없음")
    return "\n".join(lines)

def errorlog_text()->str:
    path=FILES['brain_error']
    header="🧯 오류로그 /errorlog"
    if not path.exists():
        return header+"\n\n✅ 새 실행 중 오류 없음"
    txt=path.read_text(encoding='utf-8',errors='ignore')
    lines=txt.splitlines()
    # 로그 형식: [YYYY-MM-DD HH:MM:SS] where: Error
    new_lines=[]; old_lines=[]
    for ln in lines[-80:]:
        ts=0.0
        m=re.match(r"\[(\d{4}-\d{2}-\d{2} \d{2}:\d{2}:\d{2})\]", ln)
        if m:
            try:
                ts=time.mktime(time.strptime(m.group(1), "%Y-%m-%d %H:%M:%S"))
            except Exception:
                ts=0.0
        if ts and ts >= START_TS:
            new_lines.append(ln)
        elif '[' in ln:
            old_lines.append(ln)
    out=[header]
    if new_lines:
        out += ["", "❌ 새 실행 이후 오류", *new_lines[-10:]]
    else:
        out += ["", "✅ 새 실행 중 오류 없음"]
        if old_lines:
            out.append(f"- 과거 오류 흔적 {len(old_lines)}줄 있음 / 최근 2개만 참고")
            out += old_lines[-2:]
    return "\n".join(out)

def open_text()->str:
    obj=load_json(FILES['paper_open'],{}) or {}
    lines=["📂 OPEN 요약 /popen_short"]
    if not obj: return "\n".join(lines+["- OPEN 없음"])
    for _,p in list(obj.items())[:12]: lines.append(f"- {p.get('ticker')} / {p.get('strategy_name',p.get('strategy_key','-'))} / {p.get('profit_pct',p.get('current_profit_pct','-'))}%")
    return "\n".join(lines)



def _rows_for_pipe(obj:Any)->List[Any]:
    if isinstance(obj,list): return obj
    if isinstance(obj,dict):
        for k in ("rows","items","targets","active","active_rows","queue","data","symbols"):
            if isinstance(obj.get(k),list): return obj.get(k)
    return []

def _sym_for_pipe(x:Any)->str:
    if isinstance(x,str): v=x
    elif isinstance(x,dict): v=x.get("symbol") or x.get("ticker") or x.get("market") or x.get("coin") or x.get("code") or ""
    else: v=""
    return str(v).replace("KRW-","").replace("_KRW","").replace("/KRW","").upper()

def _set_from_file(path:Path)->set:
    return {_sym_for_pipe(r) for r in _rows_for_pipe(load_json(path,{}) or {}) if _sym_for_pipe(r)}

def pipe_check_text()->str:
    update_brain_status('running')
    paths={
        'ws_targets': BASE_DIR/'clean_ws_targets.json',
        'micro_targets': BASE_DIR/'clean_micro_targets.json',
        'router': BASE_DIR/'clean_target_router_queue.json',
        'strategy_req': BASE_DIR/'clean_strategy_priority_requests.json',
        'strategy': BASE_DIR/'clean_strategy_s_reject_summary.json',
        'orderflow': BASE_DIR/'clean_orderflow_summary_cache.json',
        'ws_status': FILES['ws_status'],
        'micro_status': FILES['micro_status'],
    }
    sets={k:_set_from_file(p) for k,p in paths.items()}
    router=load_json(paths['router'],{}) or {}; reject=load_json(paths['strategy'],{}) or {}; req=load_json(paths['strategy_req'],{}) or {}; of=load_json(paths['orderflow'],{}) or {}; ws=load_json(paths['ws_status'],{}) or {}; mi=load_json(paths['micro_status'],{}) or {}
    of_rows=_rows_for_pipe(of)
    quote_ready=sum(1 for r in of_rows if isinstance(r,dict) and (r.get('quote_fresh') or r.get('ws_fresh')))
    micro_ready=sum(1 for r in of_rows if isinstance(r,dict) and r.get('micro_fresh'))
    full_ready=sum(1 for r in of_rows if isinstance(r,dict) and (r.get('info_ready') or ((r.get('quote_fresh') or r.get('ws_fresh')) and r.get('micro_fresh'))))
    active_ready=sum(1 for r in of_rows if isinstance(r,dict) and r.get('router_active') and (r.get('info_ready') or ((r.get('quote_fresh') or r.get('ws_fresh')) and r.get('micro_fresh'))))
    lines=["🧪 정보배관 점검 /pipe_check", "- SSH 없이 target → orderflow → strategy 병합 상태만 봅니다."]
    lines.append(f"- WS 상태: age {age(paths['ws_status']):.1f}s / fresh {ws.get('fresh','-')} / targets {len(sets['ws_targets'])}")
    lines.append(f"- micro 상태: age {age(paths['micro_status']):.1f}s / fresh {mi.get('fresh','-')} / targets {mi.get('targets','-')} / target파일 {len(sets['micro_targets'])}")
    lines.append(f"- orderflow: rows {len(of_rows)} / quote준비 {quote_ready} / micro준비 {micro_ready} / 둘다준비 {full_ready} / active준비 {active_ready}")
    lines.append(router_flow_summary(router))
    lines.append(f"- router 세부: 이번순환 {router.get('rotation_export_count','-')} / 순환대기 {router.get('rotation_wait_count','-')} / 버림 {router.get('dropped_count',0)} / fresh회복 {router.get('fresh_recovered','-')}")
    lines.append(f"- strategy: 평가 {reject.get('evaluated','-')} / cheap탈락 {reject.get('cheap_reject_count','-')} / 정보필요 {reject.get('info_needed_count','-')} / 정보대기 {reject.get('info_pending_count','-')} / fresh완료 {reject.get('fresh_ready_count','-')} / 병합 {reject.get('orderflow_attached_count','-')}")
    lines.append("")
    checks=[('ws_targets','orderflow'),('micro_targets','orderflow'),('router','ws_targets'),('router','micro_targets'),('strategy_req','orderflow')]
    for a,b in checks:
        lines.append(f"- 겹침 {a}↔{b}: {len(sets[a] & sets[b])}")
    lines.append("")
    if len(sets['ws_targets']) and len(sets['ws_targets'] & sets['orderflow']): lines.append("✅ WS target은 orderflow에 심볼 기준 붙음")
    elif len(sets['ws_targets']): lines.append("❌ WS target은 있으나 orderflow에 심볼이 안 붙음")
    else: lines.append("⚠️ WS active target 없음")
    if len(sets['micro_targets']) and len(sets['micro_targets'] & sets['orderflow']): lines.append("✅ micro target은 orderflow에 심볼 기준 붙음")
    elif len(sets['micro_targets']): lines.append("❌ micro target은 있으나 orderflow에 심볼이 안 붙음")
    else: lines.append("⚠️ micro active target 없음")
    # 전략 요청 후보를 개별로 짧게 보여준다. 흐름이 막히면 여기서 quote/micro/target 중 무엇이 빠졌는지 바로 보인다.
    of_map = { _sym_for_pipe(r): r for r in of_rows if isinstance(r, dict) and _sym_for_pipe(r) }
    req_rows = _rows_for_pipe(req)
    if isinstance(req, dict) and isinstance(req.get('requests'), list):
        req_rows = req.get('requests')
    if req_rows:
        lines += ["", "[전략요청 후보 상태]"]
        for r in req_rows[:8]:
            t=_sym_for_pipe(r)
            ofr=of_map.get(t,{})
            q=bool(ofr.get('quote_fresh') or ofr.get('ws_fresh'))
            m=bool(ofr.get('micro_fresh'))
            a=t in sets['micro_targets']
            active=bool(ofr.get('router_active'))
            qicon='✅' if q else '❌'
            micon='✅' if m else '❌'
            ticon='✅' if a else '❌'
            aicon='✅' if active else '❌'
            need = r.get('need') if isinstance(r,dict) and isinstance(r.get('need'),list) else []
            why=''
            if not a:
                why=' / 원인 microTarget 미반영'
            elif not active:
                why=' / 원인 orderflow active 미표시'
            elif not m:
                why=' / 원인 micro 수집대기'
            lines.append(f"- {t}: quote {qicon} / micro {micon} / microTarget {ticon} / active {aicon} / {r.get('bucket','-') if isinstance(r,dict) else '-'} / need {','.join(need)}{why}")
    if full_ready:
        lines.append("✅ orderflow canonical 정보가 준비된 후보 있음")
    else:
        lines.append("⚠️ orderflow canonical 둘다준비 후보 없음: micro/quote 중 하나가 부족")
    lines.append("- 판단: v340 기준: strategy는 quote_fresh(WS 또는 scanner REST)+micro_fresh를 기준으로 보고, S근접 micro 대기는 우선배차로 따로 추적합니다.")
    return "\n".join(lines)


# -----------------------------
# v343: 메인봇에서 paper 복기/성과 명령을 캐시 전용으로 읽는다.
# paper_bot은 실행/장부/알림 담당, 메인봇은 사용자가 한 방에서 볼 수 있게 요약만 읽는다.
# -----------------------------
STRATEGY_LABELS = {
    'money_reaccel_s': '돈흐름 재가속',
    'leader_momentum_s': '주도추세 지속',
    'breakout_early_s': '돌파 초입',
    'sweep_vwap_recovery_s': '저점 VWAP 회복',
    'surge_rebreak_s': '급등 후 재돌파',
    'leader_flow_adaptive_hold_s': '주도흐름 유동보유',
}

def _short_ticker(v: Any) -> str:
    return str(v or '').upper().replace('KRW-', '').replace('_KRW', '').replace('/KRW', '').replace('KRW', '').strip()

def _paper_open_positions() -> Dict[str, Dict[str, Any]]:
    obj = load_json(FILES['paper_open'], {}) or {}
    return obj if isinstance(obj, dict) else {}

def _paper_score_cache_current() -> Dict[str, Any]:
    return _current_paper_score_cache()

def _stat_line(label: str, st: Dict[str, Any]) -> str:
    return _score_stat_line(label, st)

def _paper_strategy_label(row_or_key: Any) -> str:
    if isinstance(row_or_key, dict):
        k = str(row_or_key.get('strategy_key') or row_or_key.get('primary_strategy_key') or row_or_key.get('representative_strategy_key') or '')
        name = str(row_or_key.get('strategy_bucket_primary_label') or row_or_key.get('strategy_name') or row_or_key.get('strategy') or '')
        if k in STRATEGY_LABELS:
            return STRATEGY_LABELS[k]
        for kk, vv in STRATEGY_LABELS.items():
            if vv in name:
                return vv
        return name or '-'
    k = str(row_or_key or '')
    return STRATEGY_LABELS.get(k, k or '-')

def _paper_grade(row: Dict[str, Any]) -> str:
    g = str(row.get('grade') or row.get('entry_grade') or row.get('signal_grade') or 'S').upper()
    return g if g else 'S'

def pstatus_text() -> str:
    status = load_json(FILES['paper_status'], {}) or {}
    open_pos = _paper_open_positions()
    cache = _paper_score_cache_current()
    hand = load_json(FILES['paperbot_handoff'], {}) or {}
    grade_counts = Counter(_paper_grade(p) for p in open_pos.values() if isinstance(p, dict))
    lines = [
        '🧪 paper 상태 /pstatus · 메인봇 캐시전용',
        '- paper_bot 명령을 메인봇방에서 읽는 요약입니다. 실행/장부/알림은 paper_bot 담당.',
        f"- 상태: {'ON' if status.get('running', True) else '확인필요'} / loop {status.get('loop_sec', status.get('loop_interval_sec', '-'))}s / OPEN {len(open_pos)} / age {age(FILES['paper_status']):.1f}s",
        f"- OPEN: S {grade_counts.get('S',0)} / A {grade_counts.get('A',0)} / B {grade_counts.get('B',0)} / C {grade_counts.get('C',0)} / 제외 {grade_counts.get('X',0)}",
        f"- handoff: latest {hand.get('latest_count', hand.get('paper_latest_count','-'))} / archive창 {hand.get('archive_window','-')} / 병합fresh {hand.get('merged_fresh','-')}",
        f"- 선별배관: 읽음 {status.get('pick_stats',{}).get('paper_file','-') if isinstance(status.get('pick_stats'),dict) else '-'} / S1선택 {status.get('pick_stats',{}).get('v369_s1_selected', status.get('pick_stats',{}).get('v368_s1_open','-')) if isinstance(status.get('pick_stats'),dict) else '-'} / S2보류 {status.get('pick_stats',{}).get('v369_s2_trace','-') if isinstance(status.get('pick_stats'),dict) else '-'} / S3관찰 {status.get('pick_stats',{}).get('v369_s3_trace','-') if isinstance(status.get('pick_stats'),dict) else '-'} / 실제OPEN {status.get('opened_this_cycle','-')}",
    ]
    if cache:
        gs = cache.get('grade_stats') if isinstance(cache.get('grade_stats'), dict) else {}
        current_n = int(fnum(cache.get('current_closed_count') or 0, 0))
        primary_total = int(fnum(cache.get('strategy_primary_total') or 0, 0))
        lines += [
            f"- 성과범위: 현재판 앵커 이후 / {cache.get('anchor_text','-')} / CLOSED {current_n}개 / 대표전략 집계 {primary_total}개",
            '[현재판 성과]',
            _stat_line('✅ S', gs.get('S', {})),
            _stat_line('현재판 전체', gs.get('ALL', {})),
            '- 전략별 상세는 /pscore 또는 /score',
        ]
    else:
        raw = load_json(FILES['paper_score'], {}) or {}
        lines += [
            '- 현재판 score cache 준비중',
            f"- 구버전 성과캐시 무시: {raw.get('version','-')} / {raw.get('schema','-')}",
        ]
    return '\n'.join(lines)

def pscore_text() -> str:
    # 메인봇 /score와 같은 현재판 cache를 사용하되 paper 명령 이름으로 보여준다.
    txt = score_text()
    return txt.replace('📊 전략별 스코어 /score', '📊 paper 전략별 스코어 /pscore · 메인봇 캐시전용', 1)

def _pos_profit_pct(pos: Dict[str, Any]) -> float:
    for k in ('pnl_pct','profit_pct','current_profit_pct','unrealized_pct'):
        if pos.get(k) not in (None, ''):
            return fnum(pos.get(k), 0.0)
    entry = fnum(pos.get('entry_price'), 0.0)
    cur = fnum(pos.get('current_price') or pos.get('last_price'), 0.0)
    if entry > 0 and cur > 0:
        return (cur - entry) / entry * 100.0
    return 0.0

def _pos_entry_price(pos: Dict[str, Any]) -> str:
    v = pos.get('entry_price') or pos.get('entry') or '-'
    try:
        fv = float(str(v).replace(',', ''))
        if fv >= 1000:
            return f"{fv:,.0f}"
        return f"{fv:.4f}"
    except Exception:
        return str(v)

def _pos_current_price(pos: Dict[str, Any]) -> str:
    v = pos.get('current_price') or pos.get('last_price') or pos.get('entry_price') or '-'
    try:
        fv = float(str(v).replace(',', ''))
        if fv >= 1000:
            return f"{fv:,.0f}"
        return f"{fv:.4f}"
    except Exception:
        return str(v)

def _pos_snapshot_flat(pos: Dict[str, Any]) -> Dict[str, Any]:
    ctx = pos.get('entry_context') if isinstance(pos.get('entry_context'), dict) else {}
    snap = ctx.get('entry_snapshot') if isinstance(ctx.get('entry_snapshot'), dict) else pos.get('entry_snapshot') if isinstance(pos.get('entry_snapshot'), dict) else {}
    vals: Dict[str, Any] = {}
    if isinstance(snap, dict):
        flat = snap.get('flat')
        if isinstance(flat, dict): vals.update(flat)
        for gname in ('price_flow','position','money_flow','orderflow','risk','strategy'):
            g = snap.get(gname)
            if isinstance(g, dict):
                for k, v in g.items(): vals.setdefault(k, v)
    if isinstance(ctx, dict):
        for k, v in ctx.items(): vals.setdefault(k, v)
    for k, v in pos.items():
        if k not in vals and k not in {'entry_context','entry_snapshot'}:
            vals[k] = v
    return vals

def _pos_hold_sec(pos: Dict[str, Any]) -> float:
    for k in ('hold_sec','age_sec'):
        v = fnum(pos.get(k), default=-1.0)
        if v > 0:
            return v
    for k in ('opened_at','entry_ts','open_ts','opened_ts','created_at','start_ts'):
        v = pos.get(k)
        ts = fnum(v, default=0.0)
        if ts > 10_000_000_000:
            ts = ts / 1000.0
        if ts <= 0 and isinstance(v, str):
            try:
                # ISO/text time fallback. timezone 없는 서버 로컬 기준.
                ts = time.mktime(time.strptime(v[:19].replace('T',' '), '%Y-%m-%d %H:%M:%S'))
            except Exception:
                ts = 0.0
        if ts > 0:
            return max(0.0, now_ts() - ts)
    return 0.0

def popen_text() -> str:
    open_pos = _paper_open_positions()
    lines = ['📂 paper OPEN /popen · 메인봇 캐시전용']
    if not open_pos:
        return '\n'.join(lines + ['OPEN 없음'])
    rows = [p for p in open_pos.values() if isinstance(p, dict)]
    rows.sort(key=lambda p: fnum(p.get('opened_at') or p.get('entry_ts') or 0, 0), reverse=True)
    by_strategy = Counter(_paper_strategy_label(p) for p in rows)
    lines.append('전략별 OPEN: ' + ' / '.join(f'{k} {v}' for k, v in by_strategy.items()))
    for p in rows[:10]:
        t = _short_ticker(p.get('ticker') or p.get('symbol'))
        pnl = _pos_profit_pct(p)
        hold = _pos_hold_sec(p)
        vals = _pos_snapshot_flat(p)
        buy = vals.get('buy_ratio') or vals.get('micro_trade_buy_ratio_30') or '-'
        reason = p.get('reason') or p.get('entry_reason') or p.get('watch_note') or 'time_exit 대기'
        try: buy_txt = f"{float(buy):.2f}"
        except Exception: buy_txt = str(buy)
        lines.append(f"- ✅ {_paper_grade(p)}급 {t} / {_paper_strategy_label(p)} / 진입 {_pos_entry_price(p)} / 현재 {_pos_current_price(p)} / {pnl:+.2f}% / 보유 {int(hold//60)}분 {int(hold%60)}초 / 감시 {reason}")
        lines.append(f"  · 근거: 매수체결 {buy_txt} / 주의: {p.get('risk_label') or p.get('risk_tags') or '특이사항 없음'}")
    if len(rows) > 10:
        lines.append(f"- 나머지 {len(rows)-10}개는 paper_bot /popen 단독 또는 이후 full에서 확인")
    return '\n'.join(lines)


# =============================================================================
# v347: paper review canonical module
# - 기존 v341~v346에서 덧붙은 preview/missed_review override들을 제거하고
#   단일 canonical 경로로 재작성한다.
# - 목적: /preview가 어떤 필드 타입(dict/float/list/None)을 만나도 죽지 않게 하고,
#   놓친 후보 추적/손실 복기 판단을 한 곳에서만 수행한다.
# =============================================================================

def as_dict(v: Any) -> Dict[str, Any]:
    return v if isinstance(v, dict) else {}

def as_list(v: Any) -> List[Any]:
    if isinstance(v, list):
        return v
    if isinstance(v, tuple):
        return list(v)
    return []

def first_value(*vals: Any, default: Any = None) -> Any:
    for v in vals:
        if v is None or v == "":
            continue
        return v
    return default

def price_from_any(v: Any) -> float:
    """dict/float/int/str/list 어떤 형태든 current price 후보를 안전하게 숫자로 변환."""
    if isinstance(v, dict):
        return fnum(v.get('current_price'), v.get('price'), v.get('trade_price'), v.get('close'), v.get('last'), default=0.0)
    if isinstance(v, (int, float, str)):
        return fnum(v, default=0.0)
    return 0.0

def _event_ts(ev: Dict[str, Any]) -> float:
    row = as_dict(ev)
    return fnum(
        row.get('candidate_created_at'), row.get('source_created_at'), row.get('detected_ts'),
        row.get('event_ts'), row.get('created_at'), row.get('timestamp'), default=0.0
    )

def _primary_strategy_key(row: Dict[str, Any]) -> str:
    row = as_dict(row)
    ctx = as_dict(row.get('entry_context'))
    snap = as_dict(row.get('entry_snapshot') or ctx.get('entry_snapshot'))
    strat = as_dict(snap.get('strategy'))
    candidates = [
        row.get('representative_strategy_key'), row.get('primary_strategy_key'), row.get('paper_strategy_key'),
        row.get('strategy_bucket_primary'), row.get('strategy_key'), row.get('strategy'), row.get('strategy_name'),
        row.get('strategy_label'), row.get('strategy_bucket_primary_label'),
        ctx.get('representative_strategy_key'), ctx.get('primary_strategy_key'), ctx.get('paper_strategy_key'),
        ctx.get('strategy_bucket_primary'), ctx.get('strategy_key'), ctx.get('strategy'), ctx.get('strategy_name'),
        ctx.get('strategy_bucket_primary_label'), strat.get('primary_key'), strat.get('primary_label')
    ]
    for v in candidates:
        text = str(v or '')
        if not text:
            continue
        if text in STRATEGY_LABELS:
            return text
        for k, label in STRATEGY_LABELS.items():
            if k in text or label in text or f'{label} S' in text:
                return k
    for vals in (
        row.get('multi_strategy_s'), row.get('strategy_bucket_keys'), ctx.get('multi_strategy_s'),
        ctx.get('strategy_bucket_keys'), strat.get('tags')
    ):
        for x in as_list(vals):
            text = str(x or '')
            if text in STRATEGY_LABELS:
                return text
            for k, label in STRATEGY_LABELS.items():
                if k in text or label in text:
                    return k
    return 'unknown'

def _paper_anchor_ts() -> float:
    c = _paper_score_cache_current()
    if isinstance(c, dict) and c:
        return fnum(c.get('anchor_ts'), c.get('current_anchor_ts'), default=0.0)
    a = load_json(FILES.get('score_anchor', BASE_DIR/'paper_bot_current_score_anchor.json'), {}) or {}
    return fnum(as_dict(a).get('anchor_ts'), default=0.0)

def _paper_current_closed_rows(max_lines:int=2600) -> List[Dict[str, Any]]:
    rows = read_jsonl(FILES.get('paper_closed', BASE_DIR/'paper_bot_closed.jsonl'), max_lines=max_lines)
    anchor = _paper_anchor_ts()
    if not anchor:
        return rows
    out=[]
    for r in rows:
        if not isinstance(r, dict):
            continue
        ts = fnum(r.get('closed_at'), r.get('closed_ts'), r.get('close_ts'), r.get('timestamp'), default=0.0)
        ots = fnum(r.get('opened_at'), r.get('entry_ts'), r.get('open_ts'), default=0.0)
        if max(ts, ots) >= anchor:
            out.append(r)
    return out

def _snapshot_flat(row: Dict[str, Any]) -> Dict[str, Any]:
    """entry_context/entry_snapshot nested group을 안전하게 평탄화한다."""
    row = as_dict(row)
    ctx = as_dict(row.get('entry_context'))
    snap = as_dict(row.get('entry_snapshot') or ctx.get('entry_snapshot'))
    vals: Dict[str, Any] = {}
    for gname in ('price_flow','position','money_flow','orderflow','risk','strategy'):
        g = as_dict(snap.get(gname))
        vals.update({k:v for k,v in g.items() if k not in vals})
    vals.update({k:v for k,v in ctx.items() if k not in vals and k != 'entry_snapshot'})
    vals.update({k:v for k,v in row.items() if k not in vals and k not in {'entry_context','entry_snapshot'}})
    return vals

def _loss_causes(row: Dict[str, Any]) -> List[str]:
    row = as_dict(row); ctx=_snapshot_flat(row)
    causes=[]
    pnl=fnum(row.get('pnl_pct'), row.get('profit_pct'), row.get('return_pct'), default=0.0)
    peak=fnum(row.get('peak_pct'), row.get('max_profit_pct'), row.get('max_pnl_pct'), default=0.0)
    trough=fnum(row.get('trough_pct'), row.get('min_profit_pct'), row.get('min_pnl_pct'), default=0.0)
    hold=fnum(row.get('hold_sec'), row.get('duration_sec'), default=0.0)
    spread=fnum(ctx.get('spread_pct'), default=-1.0)
    buy=fnum(ctx.get('buy_ratio'), ctx.get('micro_trade_buy_ratio_30'), ctx.get('buy_trade_ratio'), default=-1.0)
    buy_s=fnum(ctx.get('buy_ratio_1m'), ctx.get('micro_buy_ratio_sustain_1m'), ctx.get('buy_ratio_sustain'), default=-1.0)
    vwap=fnum(ctx.get('vwap_gap_pct'), default=999.0)
    ema=fnum(ctx.get('ema5_gap_pct'), ctx.get('ema_gap_pct'), default=999.0)
    ch3=fnum(ctx.get('change_3m'), ctx.get('price_change_3m'), default=999.0)
    ch5=fnum(ctx.get('change_5m'), ctx.get('price_change_5m'), default=999.0)
    if pnl < 0:
        if peak <= 0.10: causes.append('진입후반응없음(최고+0.1%이하)')
        elif peak <= 0.30: causes.append('반응약함(최고+0.3%이하)')
        if hold and hold <= 180: causes.append('초반빠른손실(3분이내)')
        if trough <= -0.70: causes.append('깊은역행')
    if spread >= 0.28: causes.append('스프레드넓음')
    if 0 <= buy < 0.65: causes.append('매수체결약함')
    if 0 <= buy_s < 0.60: causes.append('매수체결지속약함')
    if ctx.get('sell_pressure') or ctx.get('ask_wall_pressure') or ctx.get('sell_trade_pressure'):
        causes.append('매도압력')
    if vwap != 999.0 and vwap < -0.15: causes.append('VWAP아래')
    if ema != 999.0 and ema < -0.20: causes.append('EMA아래')
    if ch3 != 999.0 and ch5 != 999.0 and ch3 <= 0.05 and ch5 <= 0.10:
        causes.append('가격반응부족')
    if not any(k in ctx for k in ('change_3m','price_change_3m','vwap_gap_pct','buy_ratio','spread_pct')):
        causes.append('근거스냅샷부족')
    if not causes and pnl < 0:
        causes.append('기타손실')
    # 중복 제거, 순서 유지
    out=[]
    for c in causes:
        if c not in out: out.append(c)
    return out

def ploss_review_text() -> str:
    rows=_paper_current_closed_rows()
    losses=[r for r in rows if fnum(r.get('pnl_pct'), r.get('profit_pct'), default=0.0)<0]
    wins=[r for r in rows if fnum(r.get('pnl_pct'), r.get('profit_pct'), default=0.0)>0]
    cc=Counter(); by={k:[] for k in STRATEGY_LABELS}; sc={k:Counter() for k in STRATEGY_LABELS}; unknown=[]
    for r in losses:
        key=_primary_strategy_key(r)
        if key not in STRATEGY_LABELS:
            unknown.append(r); key='unknown'
        by.setdefault(key,[]).append(r); sc.setdefault(key,Counter())
        for cause in _loss_causes(r):
            cc[cause]+=1; sc[key][cause]+=1
    lines=['🧯 손실 원인 복기 /ploss_review · 메인봇 캐시전용', '- 현재판 CLOSED 손실에서 공통 패배 패턴을 봅니다.', f'- 현재판 CLOSED {len(rows)}개 / 승리 {len(wins)}개 / 손실 {len(losses)}개 / 미분류손실 {len(unknown)}개', '', '[공통 손실 TOP]']
    if cc:
        for k,v in cc.most_common(10): lines.append(f'- ⚠️ {k}: {v}개')
    else:
        lines.append('- 아직 손실 표본 없음')
    lines += ['', '[전략별 손실 원인 · 대표전략 기준]']
    for k,label in STRATEGY_LABELS.items():
        sub=by.get(k,[]); tops=', '.join(f'{a} {b}' for a,b in sc.get(k,Counter()).most_common(3)) or '-'
        lines.append(f'- {label}: 손실 {len(sub)}개 / {tops}')
    if unknown:
        tops=', '.join(f'{a} {b}' for a,b in sc.get('unknown',Counter()).most_common(3)) or '-'
        lines.append(f'- 미분류: 손실 {len(unknown)}개 / {tops}')
    lines += ['', '[조건 설계 힌트]']
    if cc.get('진입후반응없음(최고+0.1%이하)',0) >= max(3, len(losses)*0.25): lines.append('- 진입 전/직후 가격반응 조건을 전략별로 넣을 가치가 큼')
    if cc.get('매수체결약함',0) or cc.get('매수체결지속약함',0): lines.append('- 매수체결 순간값보다 지속성 조건을 봐야 함')
    if cc.get('매도압력',0): lines.append('- 매도벽/매도체결압력은 공통 하드차단이 아니라 전략별 강도 조절 필요')
    if cc.get('근거스냅샷부족',0): lines.append('- 일부 구 OPEN/CLOSED는 snapshot 부족. 신규 snapshot CLOSED를 더 신뢰')
    return '\n'.join(lines)

def _market_price_map() -> Dict[str, Dict[str, Any]]:
    """시장 가격 map을 항상 dict 형태로 반환한다. 기존 float 반환 경로 제거."""
    out: Dict[str, Dict[str, Any]] = {}
    for p in (FILES['scanner_market'], FILES['feature'], FILES['orderflow']):
        obj=load_json(p,{}) or {}; rows=[]
        if isinstance(obj, list):
            rows=obj
        elif isinstance(obj, dict):
            for key in ('rows','items','data'):
                if isinstance(obj.get(key), list):
                    rows=obj.get(key); break
            if not rows and isinstance(obj.get('cache'), dict):
                for k,v in obj.get('cache',{}).items():
                    if isinstance(v,dict):
                        vv=dict(v); vv.setdefault('ticker',k); rows.append(vv)
        for r in rows or []:
            if not isinstance(r,dict):
                continue
            t=norm_ticker(r.get('ticker') or r.get('symbol') or r.get('market'))
            price=price_from_any(r)
            if t and price>0:
                cur=out.setdefault(t, {})
                cur['current_price']=price
                cur.setdefault('source', p.name)
    return out

def _candidate_norm(ev: Dict[str, Any]) -> Dict[str, Any]:
    row=dict(as_dict(ev))
    raw_id = first_value(row.get('event_id'), row.get('event_key'), row.get('trace_id'), row.get('handoff_id'), row.get('candidate_uid'), row.get('id'))
    t=norm_ticker(row.get('ticker') or row.get('market') or row.get('symbol')) or 'UNKNOWN'
    sk=_primary_strategy_key(row) or 'strategy_s'
    ts=_event_ts(row) or now_ts()
    eid=str(raw_id or f"ev:{t}:{sk}:{int(ts//30)}")
    row['event_id']=eid; row['event_key']=eid
    row.setdefault('trace_id', eid); row.setdefault('handoff_id', eid); row.setdefault('candidate_uid', eid)
    if not raw_id:
        row.setdefault('event_id_origin','legacy_fallback')
    return row

def _candidate_keys(ev: Dict[str, Any]) -> set:
    row=_candidate_norm(ev); keys=set()
    for k in ('event_id','event_key','trace_id','handoff_id','candidate_uid','pos_id'):
        v=row.get(k)
        if v not in (None,'','-'): keys.add(str(v))
    t=norm_ticker(row.get('ticker') or row.get('market') or row.get('symbol')) or ''
    sk=_primary_strategy_key(row); ts=_event_ts(row)
    if t and sk and ts:
        keys.add(f'fb:{t}:{sk}:{int(ts//30)}')
        keys.add(f'fbm:{t}:{sk}:{int(ts//60)}')
    if t: keys.add(f'ticker:{t}')
    return keys

def _open_closed_candidate_keys():
    open_rows=[]
    try:
        op=load_json(BASE_DIR/'paper_open_positions.json',{})
        if isinstance(op,dict): open_rows=list(op.values())
    except Exception: pass
    closed_rows = _paper_current_closed_rows(max_lines=2600)
    open_keys=set(); closed_keys=set(); open_tickers=set()
    for p in open_rows:
        if isinstance(p,dict):
            open_keys |= _candidate_keys(p)
            t=norm_ticker(p.get('ticker') or p.get('market') or p.get('symbol')) or ''
            if t: open_tickers.add(t)
    for r in closed_rows:
        if isinstance(r,dict):
            closed_keys |= _candidate_keys(r)
            src=as_dict(r.get('source_event'))
            if src: closed_keys |= _candidate_keys(src)
    return open_keys, closed_keys, open_tickers



# v349: preview/missed_review/open-closed key canonical alias.
# 기존 pmissed_review 계열에서 _open_closed_keys 이름을 쓰는 경로와
# _open_closed_candidate_keys 이름을 쓰는 경로를 하나로 통일한다.
def _open_closed_keys():
    return _open_closed_candidate_keys()

def _merged_candidate_keys():
    rows=[]
    for name in ['paper_candidates_handoff_merged.jsonl','paper_candidates_latest.jsonl']:
        try: rows += read_jsonl(BASE_DIR/name, max_lines=500)
        except Exception: pass
    keys=set()
    for r in rows:
        if isinstance(r,dict): keys |= _candidate_keys(r)
    return keys

def _missed_reason(row: Dict[str,Any], merged_keys=None) -> str:
    row=_candidate_norm(row); nowv=now_ts(); reasons=[]
    keys=_candidate_keys(row); merged_keys=merged_keys if merged_keys is not None else _merged_candidate_keys()
    exp=fnum(row.get('expires_at'), default=0.0); ts=_event_ts(row)
    if exp and exp < nowv: reasons.append('handoff만료')
    if ts and nowv-ts>180: reasons.append('후보오래됨')
    if not (keys & merged_keys): reasons.append('paper미병합')
    ctx=as_dict(row.get('entry_context'))
    if not (row.get('micro_fresh') or ctx.get('micro_fresh')): reasons.append('micro미확인')
    if row.get('stale') or row.get('is_stale'): reasons.append('stale')
    if row.get('open_eligible') is False or row.get('paper_bot_open') is False: reasons.append('open_eligible_false')
    if row.get('event_id_origin') == 'legacy_fallback': reasons.append('구후보ID보정')
    if not reasons: reasons.append('paper미병합/만료확인')
    out=[]
    for r in reasons:
        if r not in out: out.append(r)
    return ','.join(out[:5])

def pmissed_review_text() -> str:
    anchor_ts = _paper_anchor_ts()
    events=[]
    for name,maxn in [('paper_candidates.jsonl',1000),('paper_candidates_latest.jsonl',250)]:
        try: events += read_jsonl(BASE_DIR/name, max_lines=maxn)
        except Exception: pass
    market = _market_price_map()
    open_keys, closed_keys, open_tickers = _open_closed_candidate_keys()
    merged_keys = _merged_candidate_keys()
    seen=set(); missed=[]; watched=0; counter=Counter()
    for raw in events:
        if not isinstance(raw,dict): continue
        ev=_candidate_norm(raw); ts=_event_ts(ev)
        if anchor_ts and ts and ts<anchor_ts: continue
        t=norm_ticker(ev.get('ticker') or ev.get('market') or ev.get('symbol')) or ''
        if not t: continue
        keys=_candidate_keys(ev); dedupe=str(ev.get('event_id') or f'{t}:{_primary_strategy_key(ev)}:{int(ts//30) if ts else 0}')
        if dedupe in seen: continue
        seen.add(dedupe); watched+=1
        if (keys & closed_keys) or (keys & open_keys) or t in open_tickers: continue
        cur=market.get(t,{}) if isinstance(market,dict) else {}
        cur_price=price_from_any(cur)
        entry=fnum(ev.get('entry_price'), ev.get('current_price'), ev.get('detected_price'), default=0.0)
        if cur_price<=0 or entry<=0: continue
        gain=(cur_price-entry)/entry*100.0
        if gain>=0.70:
            why=_missed_reason(ev, merged_keys)
            for r in why.split(','):
                if r: counter[r]+=1
            rs=ev.get('reasons') or ev.get('final_entry_reasons') or []
            missed.append({'ticker':t,'gain':gain,'strategy':ev.get('strategy_bucket_primary_label') or ev.get('strategy_name') or ev.get('strategy'), 'score':ev.get('score'), 'reasons':rs if isinstance(rs,list) else [], 'missed_reason':why})
    missed.sort(key=lambda x:x.get('gain',0), reverse=True)
    lines=['🔎 놓친 후보 복기 /pmissed_review · 메인봇 캐시전용','- 후보 archive/latest 중 OPEN/CLOSED로 이어지지 않았는데 이후 오른 코인을 봅니다.',f'- 확인 후보 {watched}개 / 현재가 비교 가능 상승후보 {len(missed)}개','','[놓친 이유 추정 TOP]']
    if counter:
        for k,v in counter.most_common(10):
            icon='⚠️' if k in {'paper미병합','handoff만료','후보오래됨','micro미확인'} else '❔'
            lines.append(f'- {icon} {k}: {v}개')
    else:
        lines.append('- 아직 분류할 상승후보 없음')
    lines += ['', '[이후 오른 후보 TOP]']
    if missed:
        for m in missed[:10]:
            rs=m.get('reasons') if isinstance(m.get('reasons'),list) else []
            lines.append(f"- {'⚠️' if m['gain']>=1.5 else '❔'} {m['ticker']} / +{m['gain']:.2f}% / {m.get('strategy','-')} / 점수 {m.get('score','-')} / 놓친이유 {m.get('missed_reason','-')} / 근거 {', '.join(map(str, rs[:3]))}")
    else:
        lines.append('- 아직 뚜렷한 놓친 상승후보 없음')
    lines += ['', '[판독]', '- 자주 오르는 패턴은 조건에서 죽이면 안 됨', '- paper미병합/만료/오래됨이 많으면 전략조건보다 handoff·진입타이밍 문제를 먼저 봅니다', '- 손실필터는 /ploss_review와 같이 봐야 합니다']
    return '\n'.join(lines)

def preview_text() -> str:
    # 단일 canonical preview: loss + missed를 각각 보호 실행해 한쪽 오류가 전체를 죽이지 않게 한다.
    parts=[]
    for title, fn in [('ploss_review', ploss_review_text), ('pmissed_review', pmissed_review_text)]:
        try:
            parts.append(fn())
        except Exception as exc:
            log_error(f'preview_{title}', exc)
            parts.append(f'❌ {title} 생성 오류: {exc.__class__.__name__}: {exc}')
    return '\n\n'.join(parts)



# =============================================================================
# v348: missed trace / handoff canonical review
# - paper_bot_v0.91의 candidate_handoff_trace를 우선 사용한다.
# - 같은 ticker/전략의 중복 놓친 후보는 1개로 합친다.
# - 조건 판단 전, 왜 paper OPEN으로 이어지지 않았는지 추적한다.
# =============================================================================

def _v348_trace_rows() -> List[Dict[str, Any]]:
    obj = load_json(FILES.get('candidate_handoff_trace', BASE_DIR/'paper_bot_candidate_handoff_trace.json'), {}) or {}
    rows = obj.get('rows') if isinstance(obj, dict) else []
    return [r for r in rows if isinstance(r, dict)] if isinstance(rows, list) else []


def _v348_trace_map() -> Dict[str, Dict[str, Any]]:
    out: Dict[str, Dict[str, Any]] = {}
    for r in _v348_trace_rows():
        t = norm_ticker(r.get('ticker') or r.get('market') or r.get('symbol'))
        sk = _primary_strategy_key(r) or str(r.get('strategy_key') or r.get('strategy') or '')
        for k in [str(r.get('event_id') or ''), str(r.get('event_key') or ''), str(r.get('trace_id') or ''), str(r.get('handoff_id') or ''), f'{t}:{sk}']:
            if k and k != '-':
                out[k] = r
    return out


def _v348_trace_for_candidate(ev: Dict[str, Any], trace_map: Optional[Dict[str, Dict[str, Any]]] = None) -> Dict[str, Any]:
    trace_map = trace_map or _v348_trace_map()
    t = norm_ticker(ev.get('ticker') or ev.get('market') or ev.get('symbol'))
    sk = _primary_strategy_key(ev) or str(ev.get('strategy_key') or ev.get('strategy') or '')
    keys = [str(ev.get('event_id') or ''), str(ev.get('event_key') or ''), str(ev.get('trace_id') or ''), str(ev.get('handoff_id') or ''), str(ev.get('candidate_uid') or ''), f'{t}:{sk}']
    for k in keys:
        if k and k in trace_map:
            return trace_map[k]
    return {}


def _v348_reason_from_trace(ev: Dict[str, Any], trace: Dict[str, Any], fallback: str = '') -> str:
    vals: List[str] = []
    for src in (trace, ev):
        for key in ('reason', 'missed_reason', 'status_reason'):
            v = src.get(key) if isinstance(src, dict) else None
            if isinstance(v, list):
                vals += [str(x) for x in v if str(x)]
            elif v not in (None, '', '-'):
                vals += [x.strip() for x in str(v).split(',') if x.strip()]
    if fallback:
        vals += [x.strip() for x in str(fallback).split(',') if x.strip()]
    if trace:
        st = str(trace.get('status') or '')
        if st and st not in {'candidate','unknown'}:
            vals.append(st)
    out=[]
    for v in vals:
        if v and v not in out:
            out.append(v)
    return ','.join(out[:6]) if out else 'paper미병합/만료확인'


def missed_trace_text() -> str:
    obj = load_json(FILES.get('candidate_handoff_trace', BASE_DIR/'paper_bot_candidate_handoff_trace.json'), {}) or {}
    rows = _v348_trace_rows()
    by_status = Counter(str(r.get('status') or 'unknown') for r in rows)
    reasons = Counter()
    for r in rows:
        for x in str(r.get('reason') or '').split(','):
            x=x.strip()
            if x: reasons[x]+=1
    lines = [
        '🧭 놓친 후보 추적 /missed_trace',
        '- strategy 후보 → handoff → paper 병합/OPEN/CLOSED 흐름을 추적합니다.',
        f"- trace age {age(FILES.get('candidate_handoff_trace', BASE_DIR/'paper_bot_candidate_handoff_trace.json')):.1f}s / rows {len(rows)} / version {obj.get('version','-') if isinstance(obj,dict) else '-'}",
        '', '[상태 TOP]'
    ]
    if by_status:
        for k,v in by_status.most_common(8):
            icon = '✅' if k in {'open','closed'} else '⚠️' if k in {'expired','not_merged','merged_waiting_open'} else '❔'
            lines.append(f'- {icon} {k}: {v}개')
    else:
        lines.append('- trace 없음')
    lines += ['', '[이유 TOP]']
    if reasons:
        for k,v in reasons.most_common(10):
            icon = '⚠️' if k in {'paper미병합','handoff만료','후보오래됨','micro미확인','picked_not_opened'} else '❔'
            lines.append(f'- {icon} {k}: {v}개')
    else:
        lines.append('- 이유 없음')
    lines += ['', '[주의 후보 TOP]']
    risky = [r for r in rows if str(r.get('status') or '') not in {'open','closed'}]
    risky.sort(key=lambda r: (float(first_value(r.get('score'),0) or 0), float(first_value(r.get('created_at'),0) or 0)), reverse=True)
    seen_risky=set(); shown=0
    for r in risky:
        t = norm_ticker(r.get('ticker'))
        sk = str(r.get('strategy_key') or r.get('strategy') or '-')
        key = f'{t}:{sk}:{r.get("status","-")}:{r.get("reason","-")}'
        if key in seen_risky:
            continue
        seen_risky.add(key); shown += 1
        lines.append(f"- ⚠️ {t} / {r.get('strategy') or r.get('strategy_key','-')} / score {r.get('score','-')} / status {r.get('status','-')} / 이유 {r.get('reason','-')}")
        if shown >= 10:
            break
    if not risky:
        lines.append('- 현재 주의 후보 없음')
    elif len(seen_risky) < len(risky):
        lines.append(f'- 중복 후보 {len(risky)-len(seen_risky)}개는 묶어서 숨김')
    return '\n'.join(lines)


def pmissed_review_text() -> str:  # type: ignore[override]
    anchor_ts = _paper_anchor_ts()
    events=[]
    for name,maxn in [('paper_candidates.jsonl',1200),('paper_candidates_latest.jsonl',300)]:
        events += read_jsonl(BASE_DIR/name, max_lines=maxn)
    market = _market_price_map()
    open_ids, closed_ids, open_tickers = _open_closed_keys()
    trace_map = _v348_trace_map()
    nowv=now_ts(); watched=0; by_key: Dict[str, Dict[str, Any]] = {}; reason_counter=Counter()
    for raw in events:
        if not isinstance(raw, dict):
            continue
        ev = ensure_event_id(raw)
        ts = float(first_value(ev.get('created_at'), ev.get('candidate_created_at'), ev.get('detected_ts'), ev.get('event_ts'), 0) or 0)
        if anchor_ts and ts and ts < anchor_ts:
            continue
        t=norm_ticker(ev.get('ticker') or ev.get('market') or ev.get('symbol'))
        if not t:
            continue
        watched += 1
        keys=_candidate_keys(ev)
        if (keys & open_ids) or (keys & closed_ids) or t in open_tickers:
            continue
        cur = market.get(t, {})
        cur_price = price_from_any(cur)
        entry = float(first_value(ev.get('entry_price'), ev.get('current_price'), ev.get('detected_price'), ev.get('price'), 0) or 0)
        if cur_price <= 0 or entry <= 0:
            continue
        gain = (cur_price-entry)/entry*100.0
        if gain < 0.70:
            continue
        trace = _v348_trace_for_candidate(ev, trace_map)
        why = _v348_reason_from_trace(ev, trace, _missed_reason(ev, set()))
        for x in why.split(','):
            if x: reason_counter[x]+=1
        sk = _primary_strategy_key(ev) or str(ev.get('strategy_key') or ev.get('strategy') or '')
        dedupe = f'{t}:{sk}'
        item = {'ticker':t,'gain':gain,'strategy':ev.get('strategy_bucket_primary_label') or ev.get('strategy_name') or ev.get('strategy') or trace.get('strategy'), 'score':ev.get('score') or trace.get('score'), 'reasons':ev.get('reasons') or ev.get('final_entry_reasons') or [], 'missed_reason':why, 'trace_status':trace.get('status','-') if trace else '-'}
        old = by_key.get(dedupe)
        if old is None or gain > float(old.get('gain',0)):
            by_key[dedupe]=item
    missed=list(by_key.values()); missed.sort(key=lambda x:x.get('gain',0), reverse=True)
    lines=['🔎 놓친 후보 복기 /pmissed_review · 메인봇 캐시전용', '- 후보 archive/latest 중 OPEN/CLOSED로 이어지지 않았는데 이후 오른 코인을 봅니다.', f'- 확인 후보 {watched}개 / 중복제거 상승후보 {len(missed)}개', '', '[놓친 이유 추정 TOP]']
    if reason_counter:
        for k,v in reason_counter.most_common(10):
            icon='⚠️' if k in {'paper미병합','handoff만료','후보오래됨','micro미확인','picked_not_opened'} else '❔'
            lines.append(f'- {icon} {k}: {v}개')
    else:
        lines.append('- 아직 분류할 상승후보 없음')
    lines += ['', '[이후 오른 후보 TOP]']
    if missed:
        for m in missed[:10]:
            rs=m.get('reasons') if isinstance(m.get('reasons'), list) else []
            lines.append(f"- {'⚠️' if m['gain']>=1.5 else '❔'} {m['ticker']} / +{m['gain']:.2f}% / {m.get('strategy','-')} / 점수 {m.get('score','-')} / 상태 {m.get('trace_status','-')} / 놓친이유 {m.get('missed_reason','-')} / 근거 {', '.join(map(str, rs[:3]))}")
    else:
        lines.append('- 아직 뚜렷한 놓친 상승후보 없음')
    lines += ['', '[판독]', '- 자주 오르는 패턴은 조건에서 죽이면 안 됨', '- paper미병합/만료/오래됨이 많으면 전략조건보다 handoff·진입타이밍 문제를 먼저 봅니다', '- 손실필터는 /ploss_review와 같이 봐야 합니다']
    return '\n'.join(lines)


def preview_text() -> str:  # type: ignore[override]
    parts=[]
    for title, fn in [('ploss_review', ploss_review_text), ('pmissed_review', pmissed_review_text)]:
        try:
            parts.append(fn())
        except Exception as exc:
            log_error(f'preview_{title}', exc)
            parts.append(f'⚠️ {title} 출력 오류: {type(exc).__name__}: {exc}')
    return '\n\n'.join(parts)



# =============================================================================
# v354: main review canonical final layer
# v355: score cache version gate는 목록식 whitelist 대신 paper_bot_v0.86+ 숫자 판정으로 단일화
# - preview/missed_trace에서 이름 누락/중복 override가 다시 타지 않도록 최종 단일 함수를 둔다.
# - 전략/청산/자동매수에는 관여하지 않고, paper_bot_v0.92 trace/cache를 읽는 조회 전용이다.
# =============================================================================

def _v354_trace_rows() -> List[Dict[str, Any]]:
    obj = load_json(FILES.get('candidate_handoff_trace', BASE_DIR/'paper_bot_candidate_handoff_trace.json'), {}) or {}
    rows = obj.get('rows') if isinstance(obj, dict) else []
    return [r for r in rows if isinstance(r, dict)] if isinstance(rows, list) else []

def _v354_trace_map() -> Dict[str, Dict[str, Any]]:
    out: Dict[str, Dict[str, Any]] = {}
    priority = {'closed': 60, 'open': 55, 'picked': 50, 'merged_waiting_pick': 40, 'micro_wait': 35, 'not_merged': 25, 'expired': 10, 'skipped': 5}
    for r in _v354_trace_rows():
        t = norm_ticker(r.get('ticker') or r.get('market') or r.get('symbol'))
        sk = _primary_strategy_key(r) or str(r.get('strategy_key') or r.get('strategy') or '')
        ts = fnum(r.get('created_at') or r.get('updated_at'), default=0.0)
        keys = [r.get('event_id'), r.get('event_key'), r.get('trace_id'), r.get('handoff_id'), r.get('candidate_uid'), f'{t}:{sk}']
        for k in keys:
            k=str(k or '')
            if not k or k == '-':
                continue
            old = out.get(k)
            if old is None:
                out[k] = r
                continue
            old_score = priority.get(str(old.get('status') or ''), 0)
            new_score = priority.get(str(r.get('status') or ''), 0)
            old_ts = fnum(old.get('created_at') or old.get('updated_at'), default=0.0)
            # 같은 ticker:strategy 키에서 과거 expired가 최신 open/closed/picked를 덮지 못하게 한다.
            if (new_score, ts) > (old_score, old_ts):
                out[k] = r
    return out

def _v354_trace_for_candidate(ev: Dict[str, Any], trace_map: Optional[Dict[str, Dict[str, Any]]] = None) -> Dict[str, Any]:
    trace_map = trace_map or _v354_trace_map()
    row = _candidate_norm(ev)
    t = norm_ticker(row.get('ticker') or row.get('market') or row.get('symbol'))
    sk = _primary_strategy_key(row) or str(row.get('strategy_key') or row.get('strategy') or '')
    keys = [row.get('event_id'), row.get('event_key'), row.get('trace_id'), row.get('handoff_id'), row.get('candidate_uid'), f'{t}:{sk}']
    for k in keys:
        k=str(k or '')
        if k and k in trace_map:
            return trace_map[k]
    return {}

def _v354_reason_from_trace(ev: Dict[str, Any], trace: Dict[str, Any], fallback: str = '') -> str:
    vals: List[str] = []
    for src in (trace, ev):
        if not isinstance(src, dict):
            continue
        for key in ('reason', 'missed_reason', 'status_reason'):
            v = src.get(key)
            if isinstance(v, list):
                vals += [str(x).strip() for x in v if str(x).strip()]
            elif v not in (None, '', '-'):
                vals += [x.strip() for x in str(v).split(',') if x.strip()]
    if fallback:
        vals += [x.strip() for x in str(fallback).split(',') if x.strip()]
    if trace:
        st=str(trace.get('status') or '')
        if st and st not in {'candidate','unknown'}:
            vals.append(st)
    out=[]
    for v in vals:
        if v and v not in out:
            out.append(v)
    return ','.join(out[:6]) if out else 'paper미병합/만료확인'

def missed_trace_text() -> str:  # type: ignore[override]
    obj = load_json(FILES.get('candidate_handoff_trace', BASE_DIR/'paper_bot_candidate_handoff_trace.json'), {}) or {}
    rows = _v354_trace_rows()
    by_status = Counter(str(r.get('status') or 'unknown') for r in rows)
    reasons = Counter()
    for r in rows:
        for x in str(r.get('reason') or '').split(','):
            x=x.strip()
            if x: reasons[x]+=1
    lines = [
        '🧭 놓친 후보 추적 /missed_trace',
        '- strategy 후보 → handoff → paper 병합/OPEN/CLOSED 흐름을 추적합니다.',
        f"- trace age {age(FILES.get('candidate_handoff_trace', BASE_DIR/'paper_bot_candidate_handoff_trace.json')):.1f}s / rows {len(rows)} / version {obj.get('version','-') if isinstance(obj,dict) else '-'}",
        '', '[상태 TOP]'
    ]
    if by_status:
        for k,v in by_status.most_common(10):
            icon = '✅' if k in {'open','closed','picked'} else '⚠️' if k in {'expired','not_merged','merged_waiting_pick','micro_wait','skipped'} else '❔'
            lines.append(f'- {icon} {k}: {v}개')
    else:
        lines.append('- trace 없음')
    lines += ['', '[이유 TOP]']
    if reasons:
        for k,v in reasons.most_common(10):
            icon = '⚠️' if k in {'paper미병합','handoff만료','후보오래됨','micro미확인','picked_not_opened'} else '❔'
            lines.append(f'- {icon} {k}: {v}개')
    else:
        lines.append('- 이유 없음')
    lines += ['', '[주의 후보 TOP]']
    risky = [r for r in rows if str(r.get('status') or '') not in {'open','closed'}]
    risky.sort(key=lambda r: (float(first_value(r.get('score'),0) or 0), float(first_value(r.get('created_at'),0) or 0)), reverse=True)
    for r in risky[:10]:
        lines.append(f"- ⚠️ {norm_ticker(r.get('ticker'))} / {r.get('strategy') or r.get('strategy_key','-')} / score {r.get('score','-')} / status {r.get('status','-')} / 이유 {r.get('reason','-')}")
    if not risky:
        lines.append('- 현재 주의 후보 없음')
    return '\n'.join(lines)

def _v358_recent_review_events() -> List[Dict[str, Any]]:
    """v358: /pmissed_review 기본판은 오래된 archive 전체를 다시 훑지 않는다.

    trace 수술 이후 기본 복기는 latest/handoff/actual trace 중심으로만 본다.
    archive 전체 재검사는 나중에 full 명령으로 분리할 대상이며, 기본 명령에서
    handoff만료/paper미병합을 과대표시하지 않게 한다.
    """
    events: List[Dict[str, Any]] = []
    seen: set[str] = set()
    for name, maxn in [('paper_candidates_latest.jsonl', 250), ('paper_candidates_handoff_merged.jsonl', 300)]:
        for ev in read_jsonl(BASE_DIR/name, max_lines=maxn):
            if not isinstance(ev, dict):
                continue
            key = str(ev.get('event_id') or ev.get('event_key') or ev.get('candidate_uid') or '')
            t = norm_ticker(ev.get('ticker') or ev.get('market') or ev.get('symbol'))
            ts = str(first_value(ev.get('created_at'), ev.get('candidate_created_at'), ev.get('event_ts'), ''))
            sk = str(_primary_strategy_key(ev) or ev.get('strategy_key') or ev.get('strategy') or '')
            dk = key or f'{t}:{sk}:{ts}'
            if dk in seen:
                continue
            seen.add(dk)
            events.append(ev)
    # actual trace도 후보 추적 기준으로만 보강한다. 오래된 source/archive trace fallback은 쓰지 않는다.
    obj = load_json(FILES.get('candidate_handoff_trace', BASE_DIR/'paper_bot_candidate_handoff_trace.json'), {}) or {}
    rows = obj.get('rows') if isinstance(obj, dict) else []
    if isinstance(rows, list):
        for r in rows[:300]:
            if not isinstance(r, dict):
                continue
            key = str(r.get('event_id') or r.get('event_key') or r.get('candidate_uid') or r.get('trace_id') or '')
            t = norm_ticker(r.get('ticker') or r.get('market') or r.get('symbol'))
            ts = str(first_value(r.get('created_at'), r.get('candidate_created_at'), r.get('event_ts'), ''))
            sk = str(_primary_strategy_key(r) or r.get('strategy_key') or r.get('strategy') or '')
            dk = key or f'trace:{t}:{sk}:{ts}'
            if dk in seen:
                continue
            seen.add(dk)
            events.append(r)
    return events


def pmissed_review_text() -> str:  # type: ignore[override]
    """v358 기본 missed 복기.

    기본 명령은 latest/handoff/actual trace만 본다. archive 전체 재검사는 렉과
    과대표시를 만들 수 있으므로 기본 경로에서 제외한다.
    """
    anchor_ts = _paper_anchor_ts()
    events = _v358_recent_review_events()
    market = _market_price_map()
    open_ids, closed_ids, open_tickers = _open_closed_keys()
    trace_map = _v354_trace_map()
    watched=0; by_key: Dict[str, Dict[str, Any]] = {}; reason_counter=Counter()
    for raw in events:
        if not isinstance(raw, dict):
            continue
        ev = _candidate_norm(raw)
        ts = float(first_value(ev.get('created_at'), ev.get('candidate_created_at'), ev.get('detected_ts'), ev.get('event_ts'), 0) or 0)
        if anchor_ts and ts and ts < anchor_ts:
            continue
        t=norm_ticker(ev.get('ticker') or ev.get('market') or ev.get('symbol'))
        if not t:
            continue
        watched += 1
        keys=_candidate_keys(ev)
        if (keys & open_ids) or (keys & closed_ids) or t in open_tickers:
            continue
        cur_price = price_from_any(market.get(t, {}))
        entry = float(first_value(ev.get('entry_price'), ev.get('current_price'), ev.get('detected_price'), ev.get('price'), 0) or 0)
        if cur_price <= 0 or entry <= 0:
            continue
        gain = (cur_price-entry)/entry*100.0
        if gain < 0.70:
            continue
        trace = _v354_trace_for_candidate(ev, trace_map)
        why = _v354_reason_from_trace(ev, trace, _missed_reason(ev, set()))
        for x in why.split(','):
            if x: reason_counter[x]+=1
        sk = _primary_strategy_key(ev) or str(ev.get('strategy_key') or ev.get('strategy') or '')
        dedupe = f'{t}:{sk}'
        item = {'ticker':t,'gain':gain,'strategy':ev.get('strategy_bucket_primary_label') or ev.get('strategy_name') or ev.get('strategy') or trace.get('strategy'), 'score':ev.get('score') or trace.get('score'), 'reasons':ev.get('reasons') or ev.get('final_entry_reasons') or [], 'missed_reason':why, 'trace_status':trace.get('status','-') if trace else '-'}
        old=by_key.get(dedupe)
        if old is None or gain > float(old.get('gain',0)):
            by_key[dedupe]=item
    missed=list(by_key.values()); missed.sort(key=lambda x:x.get('gain',0), reverse=True)
    lines=['🔎 놓친 후보 복기 /pmissed_review · 메인봇 캐시전용', '- 기본 범위: latest/handoff/actual trace 중심. archive 전체 재검사는 기본에서 제외.', f'- 확인 후보 {watched}개 / 중복제거 상승후보 {len(missed)}개', '', '[놓친 이유 추정 TOP]']
    if reason_counter:
        for k,v in reason_counter.most_common(8):
            icon='⚠️' if k in {'paper미병합','handoff만료','후보오래됨','micro미확인','picked_not_opened'} else '❔'
            lines.append(f'- {icon} {k}: {v}개')
    else:
        lines.append('- 아직 분류할 상승후보 없음')
    lines += ['', '[이후 오른 후보 TOP]']
    if missed:
        for m in missed[:5]:
            rs=m.get('reasons') if isinstance(m.get('reasons'), list) else []
            lines.append(f"- {'⚠️' if m['gain']>=1.5 else '❔'} {m['ticker']} / +{m['gain']:.2f}% / {m.get('strategy','-')} / 점수 {m.get('score','-')} / 상태 {m.get('trace_status','-')} / 놓친이유 {m.get('missed_reason','-')} / 근거 {', '.join(map(str, rs[:3]))}")
    else:
        lines.append('- 아직 뚜렷한 놓친 상승후보 없음')
    lines += ['', '[판독]', '- 기본판에서 paper미병합/만료가 많으면 handoff·paper 병합 타이밍을 봅니다', '- 전략조건 수정은 score/trace가 정상 출력된 뒤 판단합니다']
    return '\n'.join(lines)


def _v358_trim_loss_preview(txt: str) -> str:
    lines = txt.splitlines()
    out: List[str] = []
    keep = True
    for ln in lines:
        if ln.startswith('[전략별 손실 원인'):
            keep = False
            continue
        if ln.startswith('[조건 설계 힌트]'):
            keep = True
        if keep:
            out.append(ln)
        if len(out) >= 18:
            break
    if '[전략별 손실 원인 · 대표전략 기준]' in txt:
        out += ['', '- 전략별 상세 손실은 /ploss_review에서 확인']
    return '\n'.join(out)


def preview_text() -> str:  # type: ignore[override]
    """v358 기본 preview 경량화.

    전체 상세를 반복 출력하지 않고 손실 TOP + missed 기본판만 묶는다.
    """
    parts=[]
    try:
        parts.append(_v358_trim_loss_preview(ploss_review_text()))
    except Exception as exc:
        log_error('preview_ploss_review', exc)
        parts.append(f'⚠️ ploss_review 출력 오류: {type(exc).__name__}: {exc}')
    try:
        parts.append(pmissed_review_text())
    except Exception as exc:
        log_error('preview_pmissed_review', exc)
        parts.append(f'⚠️ pmissed_review 출력 오류: {type(exc).__name__}: {exc}')
    return '\n\n'.join(parts)




# =============================================================================



def send(update, text: str) -> None:
    try:
        if len(text) > 3900:
            text = text[:3850] + "\n…(길어 일부만 표시)"
        update.message.reply_text(text)
    except Exception as exc:
        log_error('telegram_send', exc)


def heartbeat_loop():
    while True:
        try:
            update_brain_status('running')
        except Exception as exc:
            log_error('heartbeat', exc)
        time.sleep(10)

# =============================================================================
# v650: main_bot command trunk rebuild
# - 이전 v366~v649 tail/wrapper 명령어 덮어쓰기 구간을 잘라내고,
#   기본 명령은 아래 단일 본선으로만 연결한다.
# - main_bot은 candidate/score-review/paper runtime snapshot만 읽는다.
# - 조건/S등급/청산/paper 장부/자동매수는 변경하지 않는다.
# =============================================================================
V650_BUILD_LABEL = 'v806_integrated_validation_freshness_2026-06-10'
BOT_VERSION = '수익형 v2.13.806'


def _v650_int(*vals: Any, default: int = 0) -> int:
    for v in vals:
        try:
            if v is None or v == '':
                continue
            return int(float(str(v).replace(',', '')))
        except Exception:
            continue
    return default


def _v650_num(*vals: Any, default: float = 0.0) -> float:
    for v in vals:
        try:
            if v is None or v == '':
                continue
            return float(str(v).replace(',', ''))
        except Exception:
            continue
    return default


def _v650_pct(v: Any, digits: int = 2) -> str:
    try:
        return f'{float(v):+.{digits}f}%'
    except Exception:
        return '-'


def _v650_load(path: Path, default: Any = None) -> Any:
    try:
        if not path or not path.exists():
            return default
        return json.loads(path.read_text(encoding='utf-8', errors='ignore'))
    except Exception:
        return default


def _v650_file_age(path: Path) -> float:
    try:
        return max(0.0, time.time() - path.stat().st_mtime)
    except Exception:
        return 999999.0


def _v650_read_candidate_rows(limit: int = 5000) -> List[Dict[str, Any]]:
    path = FILES.get('paper_latest', BASE_DIR / 'paper_candidates_latest.jsonl')
    out: List[Dict[str, Any]] = []
    try:
        if not path.exists():
            return []
        with path.open('r', encoding='utf-8', errors='ignore') as f:
            for ln in f:
                if not ln.strip():
                    continue
                try:
                    obj = json.loads(ln)
                    if isinstance(obj, dict):
                        out.append(obj)
                except Exception:
                    pass
        if len(out) > limit:
            # 서버 보호용 안전상한. 화면 표시/집계 제한 목적이 아니다.
            out = out[-limit:]
    except Exception as exc:
        log_error('v650_read_candidate_rows', exc)
    return out


def _v650_stage(row: Dict[str, Any]) -> str:
    for k in ('stage', 'grade', 's_grade', 'paper_grade', 'signal_grade', 'candidate_stage'):
        s = str(row.get(k) or '').strip().upper()
        if s in ('S1', 'S2', 'S3'):
            return s
        if s in ('S', 'A'):
            return 'S1'
        if s in ('B', 'C'):
            return 'S3'
    return '미집계'


def _v650_ticker(row: Dict[str, Any]) -> str:
    for k in ('ticker', 'symbol', 'market', 'code'):
        s = str(row.get(k) or '').strip().upper()
        if not s:
            continue
        for pfx in ('KRW-', 'KRW_', 'BITHUMB:'):
            if s.startswith(pfx):
                s = s[len(pfx):]
        for suf in ('-KRW', '_KRW', '/KRW'):
            if s.endswith(suf):
                s = s[:-len(suf)]
        return s
    return '-'


def _v650_strategy(row: Dict[str, Any]) -> str:
    raw = str(row.get('strategy_label') or row.get('strategy_name') or row.get('strategy') or row.get('strategy_key') or '-').strip()
    maps = {
        'leader_flow_adaptive_hold_s': '주도흐름 유동보유',
        'money_reaccel_s': '돈흐름 재가속',
        'breakout_early_s': '돌파 초입',
        'sweep_vwap_recovery_s': '저점 VWAP 회복',
        'hot_rank_recheck_s': 'hot-rank 발견/재확인',
        'leader_momentum_s': '주도추세 지속',
    }
    return maps.get(raw, raw or '-')


def _v650_listify(v: Any) -> List[str]:
    if v is None:
        return []
    if isinstance(v, list):
        out=[]
        for x in v:
            if isinstance(x, str): out.append(x)
            elif isinstance(x, dict): out += [str(y) for y in x.values() if y]
            elif x: out.append(str(x))
        return [x for x in out if x]
    if isinstance(v, dict):
        out=[]
        for k, val in v.items():
            if isinstance(val, (int, float)):
                if val: out.append(str(k))
            elif val:
                out.append(str(k) if val is True else f'{k}:{val}')
        return out
    s = str(v).strip()
    if not s:
        return []
    parts = re.split(r'[/,|]\s*|\s{2,}', s)
    return [p.strip() for p in parts if p.strip()]


def _v650_reasons(row: Dict[str, Any]) -> List[str]:
    keys = ('block_reasons','block_reason','reasons','reason','s1_block_reasons','s1_fail_reasons','why_not_s1','missing_info','recheck_reason')
    out: List[str] = []
    for k in keys:
        out += _v650_listify(row.get(k))
    return list(dict.fromkeys(out))


def _v650_risks(row: Dict[str, Any]) -> List[str]:
    keys = ('risk_tags','risk_tag','risks','risk','danger_tags','warning_tags')
    out: List[str] = []
    for k in keys:
        out += _v650_listify(row.get(k))
    # 이유 안에 위험 문구가 섞인 경우 보조로만 반영
    for r in _v650_reasons(row):
        if any(w in r for w in ('스프레드','미끄러','매도','윗꼬리','stale','오래','위험')):
            out.append(r)
    return list(dict.fromkeys(out))


def _v650_structures(row: Dict[str, Any]) -> List[str]:
    keys = ('structure_tags','structure_tag','structures','structure','entry_structure','entry_reason')
    out: List[str] = []
    for k in keys:
        out += _v650_listify(row.get(k))
    return list(dict.fromkeys(out))


def _v650_price_1m(row: Dict[str, Any]) -> Dict[str, Any]:
    cur = _v650_num(row.get('current_price'), row.get('price'), row.get('last_price'), default=0.0)
    prev = _v650_num(row.get('price_1m_ago'), row.get('prev_1m_price'), row.get('price_60s_ago'), default=0.0)
    chg = row.get('change_1m_pct')
    if chg is None:
        chg = row.get('price_chg_60s')
    chgf = _v650_num(chg, default=None) if chg is not None else None
    if chgf is None and cur and prev:
        try:
            chgf = (cur - prev) / prev * 100.0
        except Exception:
            chgf = None
    return {'ready': chgf is not None, 'chg': chgf if chgf is not None else 0.0, 'cur': cur, 'prev': prev}


def _v650_trigger(row: Dict[str, Any]) -> Tuple[float, float, float]:
    cur = _v650_num(row.get('current_price'), row.get('price'), default=0.0)
    trg = _v650_num(row.get('trigger_price'), row.get('entry_trigger_price'), row.get('planned_entry'), default=0.0)
    gap = _v650_num(row.get('trigger_gap_pct'), default=None) if row.get('trigger_gap_pct') is not None else None
    if gap is None and cur and trg:
        gap = (cur - trg) / trg * 100.0
    return cur, trg, gap if gap is not None else 0.0


def _v652_trigger_display(row: Dict[str, Any]) -> Tuple[float, str]:
    """후보 화면에서 방아쇠 0으로 gap을 계산하지 않는다.

    trigger_price가 없으면 진입타이밍 재료 누락으로 표시한다. 0원 방아쇠는
    정상 값이 아니므로 `gap +0.xx%` 같은 착시를 만들면 안 된다.
    """
    cur, trg, gap = _v650_trigger(row)
    if trg <= 0:
        return cur, '방아쇠 정보 없음 / gap 계산안함'
    return cur, f'방아쇠 {trg:g} / gap {gap:+.2f}%'


def _v650_stat_obj(obj: Any) -> Dict[str, Any]:
    if not isinstance(obj, dict):
        return {'n':0,'wins':0,'losses':0,'total':0.0,'avg':0.0}
    n = _v650_int(obj.get('n'), obj.get('count'), obj.get('trades'), obj.get('total_count'), obj.get('closed_count'), default=0)
    wins = _v650_int(obj.get('wins'), obj.get('win'), obj.get('profit_count'), default=0)
    losses = _v650_int(obj.get('losses'), obj.get('loss'), obj.get('loss_count'), default=max(0, n-wins))
    total = _v650_num(obj.get('total'), obj.get('sum'), obj.get('sum_pct'), obj.get('total_pct'), obj.get('total_pnl_pct'), obj.get('pnl_sum'), obj.get('profit_sum'), obj.get('profit_pct_sum'), default=0.0)
    avg = _v650_num(obj.get('avg'), obj.get('average'), obj.get('avg_pct'), obj.get('mean_pct'), default=(total/n if n else 0.0))
    return {'n':n,'wins':wins,'losses':losses,'total':total,'avg':avg}


def _v650_stat_line(label: str, st: Dict[str, Any]) -> str:
    n = _v650_int(st.get('n'), default=0)
    if n <= 0:
        return f'❔ {label}: 0전'
    wins = _v650_int(st.get('wins'), default=0)
    losses = _v650_int(st.get('losses'), default=max(0,n-wins))
    total = _v650_num(st.get('total'), default=0.0)
    avg = _v650_num(st.get('avg'), default=(total/n if n else 0.0))
    icon = '✅' if total > 0 else ('⚠️' if abs(total) < 0.05 else '❌')
    return f'{icon} {label}: {n}전 {wins}승 {losses}패 / 합산 {total:+.2f}% / 평균 {avg:+.2f}%'


def _v650_score() -> Dict[str, Any]:
    path = FILES.get('paper_score', BASE_DIR/'paper_bot_score_cache.json')
    obj = _v650_load(path, {}) or {}
    return obj if isinstance(obj, dict) else {}


def _v650_review() -> Dict[str, Any]:
    """Review count view follows the paper score-review owner.

    v657: paper_bot v654+ already seals review_today_closed_count in
    paper_bot_score_cache.json from the same reconciled CLOSED rows as score.
    main_bot must not read a separate stale review count and create 0/1 drift.
    It may keep review summary_text from review cache, but the displayed count/schema
    comes from the score owner cache. No CLOSED ledger direct scan here.
    """
    score = _v650_score()
    review_obj: Dict[str, Any] = {}
    for path in (BASE_DIR/'paper_bot_trade_review_cache.json', BASE_DIR/'paper_bot_review_cache.json'):
        obj = _v650_load(path, None)
        if isinstance(obj, dict) and obj:
            review_obj = dict(obj)
            break
    if isinstance(score, dict) and str(score.get('schema') or '').startswith('paper_score_cache_v654'):
        owned_n = _v650_int(score.get('review_today_closed_count'), score.get('today_closed_count'), default=0)
        review_obj['today_closed_count'] = owned_n
        review_obj['schema'] = score.get('review_schema') or 'paper_review_spine_v657_score_owner_view'
        review_obj['source_owner'] = 'paper_score_cache.review_today_closed_count'
        review_obj['score_review_same_rows'] = True
        review_obj['updated_at'] = score.get('updated_at', review_obj.get('updated_at'))
        review_obj['updated_at_text'] = score.get('updated_at_text', review_obj.get('updated_at_text'))
        return review_obj
    return review_obj


def _v650_status() -> Dict[str, Any]:
    obj = _v650_load(FILES.get('paper_status', BASE_DIR/'paper_bot_status.json'), {}) or {}
    return obj if isinstance(obj, dict) else {}


# v741: legacy _v650_open_count definition removed; canonical version is after _v680_paper_open_rows.

def _v650_score_stats() -> Tuple[Dict[str, Any], Dict[str, Any], Dict[str, Any], Dict[str, Any]]:
    score = _v650_score()
    today = _v650_stat_obj(score.get('today_global_stats') or score.get('today') or {})
    r3 = _v650_stat_obj(score.get('recent_3h_stats') or score.get('recent_3h') or {})
    r6 = _v650_stat_obj(score.get('recent_6h_stats') or score.get('recent_6h') or {})
    # count mirror 보강
    if today['n'] == 0:
        today['n'] = _v650_int(score.get('today_closed_count'), default=0)
    return score, today, r3, r6


def _v651_pick_score_stat(score: Dict[str, Any], *keys: str) -> Dict[str, Any]:
    """paper score cache 안의 여러 버전 key를 같은 성과 stat으로 읽는다.

    main_bot은 CLOSED 장부를 직접 훑지 않고, paper score cache에 이미 봉인된
    날짜창/rolling window 값만 표시한다.
    """
    if not isinstance(score, dict):
        return _v650_stat_obj({})
    for k in keys:
        v = score.get(k)
        if isinstance(v, dict):
            st = _v650_stat_obj(v)
            if st.get('n') or any(x in v for x in ('total','sum','sum_pct','total_pct','avg','wins','losses')):
                return st
    # date_stats 계열에서 어제 날짜를 찾는다.
    if 'yesterday' in keys or 'yesterday_stats' in keys or 'yesterday_global_stats' in keys:
        date_stats = score.get('date_stats') or score.get('daily_stats') or score.get('by_date')
        if isinstance(date_stats, dict):
            ymd = time.strftime('%Y-%m-%d', time.localtime(time.time() - 86400))
            for dk in (ymd, ymd.replace('-', ''), 'yesterday'):
                if isinstance(date_stats.get(dk), dict):
                    return _v650_stat_obj(date_stats.get(dk))
    return _v650_stat_obj({})


def _v651_score_windows() -> Dict[str, Any]:
    score, today, r3, r6 = _v650_score_stats()
    yesterday = _v651_pick_score_stat(
        score,
        'yesterday_global_stats', 'yesterday_stats', 'previous_day_stats',
        'prev_day_stats', 'last_day_stats', 'yesterday'
    )
    r24 = _v651_pick_score_stat(
        score,
        'recent_24h_stats', 'last_24h_stats', 'rolling_24h_stats',
        'recent_24h_global_stats', 'recent_24h', 'last_24h', 'stats_24h'
    )
    r24_note = ''
    if r24.get('n', 0) <= 0 and any((x.get('n', 0) > 0 for x in (today, r3, r6) if isinstance(x, dict))):
        # v653: main_bot에서 24h를 임시로 만들지 않는다. paper score cache가 주인이다.
        r24_note = '최근 24시간 source 없음 · paper score cache writer 연결 필요'
    try:
        hour = int(time.strftime('%H', time.localtime()))
    except Exception:
        hour = 99
    midnight_note = ''
    if today.get('n', 0) <= 0 and hour <= 3:
        midnight_note = '자정 이후라 오늘 전적은 0전일 수 있음 · 어제/최근 24시간을 같이 확인'
    return {'score': score, 'today': today, 'yesterday': yesterday, 'r3': r3, 'r6': r6, 'r24': r24, 'r24_note': r24_note, 'midnight_note': midnight_note}


def _v651_score_window_lines(compact: bool = True) -> List[str]:
    w = _v651_score_windows()
    lines = [
        _v650_stat_line('오늘', w['today']),
        _v650_stat_line('어제', w['yesterday']),
        _v650_stat_line('최근 24시간', w['r24']),
        _v650_stat_line('최근 3시간', w['r3']),
        _v650_stat_line('최근 6시간', w['r6']),
    ]
    if w.get('midnight_note'):
        lines.append(f"- 참고: {w['midnight_note']}")
    if w.get('r24_note'):
        lines.append(f"- 24h: {w['r24_note']}")
    return lines


def _v650_candidate_snapshot() -> Dict[str, Any]:
    # v783: one command should read one candidate snapshot.  This removes
    # repeated JSONL scans inside /paper_handoff while keeping the canonical
    # paper_candidates_latest source unchanged.
    try:
        c = _V782_CANDIDATE_SNAPSHOT_CACHE
        if isinstance(c.get('snap'), dict) and now_ts() - float(c.get('ts') or 0.0) <= 1.25:
            return c['snap']
    except Exception:
        pass
    rows = _v650_read_candidate_rows()

    def _lane(r: Dict[str, Any]) -> str:
        return str(r.get('canonical_lane') or r.get('lane') or r.get('source_lane') or r.get('strategy_lane') or '').lower()

    def _is_trade_candidate(r: Dict[str, Any]) -> bool:
        if r.get('trade_candidate_row_v661') is True or r.get('paper_candidate_row') is True:
            return True
        if r.get('paper_experiment_open') is True or r.get('paper_bot_open') is True:
            return True
        lane = _lane(r)
        if lane in ('coverage', 'raw', 'market', 'scanner_only', 'coverage_light'):
            return False
        sk = str(r.get('strategy_key') or r.get('strategy') or '')
        if 'coverage' in sk or r.get('v661_coverage_reason'):
            return False
        return _v650_stage(r) in ('S1','S2')

    trade_rows = [r for r in rows if isinstance(r, dict) and _is_trade_candidate(r)]
    coverage_rows = [r for r in rows if isinstance(r, dict) and not _is_trade_candidate(r)]
    stage = Counter(_v650_stage(r) for r in trade_rows)
    all_stage = Counter(_v650_stage(r) for r in rows)
    reasons = Counter()
    risks = Counter()
    mats = Counter()
    stale_all = stale_trade = stale_s12 = stale_coverage = 0
    for r in rows:
        is_trade = _is_trade_candidate(r)
        p = _v650_price_1m(r)
        if p['ready']:
            mats['1분가격 정상'] += 1
            if p['chg'] <= 0: mats['1분반응 0/음수'] += 1
            elif p['chg'] >= 0.35: mats['1분반응 통과'] += 1
            else: mats['1분반응 부족'] += 1
        else:
            mats['1분가격 없음'] += 1
        for x in _v650_reasons(r): reasons[x] += 1
        for x in _v650_risks(r): risks[x] += 1
        age_val = _v650_num(r.get('age'), r.get('source_age'), r.get('fresh_age'), r.get('candle_age'), default=0.0)
        stale_flag = age_val >= 120 or any('stale' in x.lower() or '오래' in x for x in _v650_reasons(r)+_v650_risks(r))
        if stale_flag:
            stale_all += 1
            if is_trade:
                stale_trade += 1
                if _v650_stage(r) in ('S1','S2'):
                    stale_s12 += 1
            else:
                stale_coverage += 1
    snap = {
        'rows': rows,
        'trade_rows': trade_rows,
        'coverage_rows': coverage_rows,
        'counts': stage,
        'all_counts': all_stage,
        'reasons': reasons,
        'risks': risks,
        'materials': mats,
        'stale': stale_all,
        'stale_all': stale_all,
        'stale_trade': stale_trade,
        'stale_s12': stale_s12,
        'stale_coverage': stale_coverage,
        'file_age': _v650_file_age(FILES.get('paper_latest', BASE_DIR/'paper_candidates_latest.jsonl')),
        'scope_policy_v682': '전체시장 rows는 coverage/raw로 분리 표시하고, S1/S2/S3 후보 count는 trade_candidate rows 기준으로 표시한다.',
    }
    try:
        _V782_CANDIDATE_SNAPSHOT_CACHE['ts'] = now_ts()
        _V782_CANDIDATE_SNAPSHOT_CACHE['snap'] = snap
    except Exception:
        pass
    return snap


def _v650_pipeline() -> Dict[str, Any]:
    snap = _v650_candidate_snapshot()
    rows = snap['rows']
    trade_rows_list = snap.get('trade_rows') if isinstance(snap.get('trade_rows'), list) else []
    coverage_rows_list = snap.get('coverage_rows') if isinstance(snap.get('coverage_rows'), list) else []
    scanner = _v650_load(FILES.get('scanner_market', BASE_DIR/'clean_scanner_market_cache.json'), {}) or {}
    strategy_summary = _v650_load(FILES.get('strategy_summary', BASE_DIR/'clean_strategy_s_summary.json'), {}) or {}
    if isinstance(scanner, dict):
        krw = _v650_int(scanner.get('krw_universe'), scanner.get('krw_count'), scanner.get('row_count'), scanner.get('rows'), default=0)
        sc_rows = _v650_int(scanner.get('row_count'), scanner.get('rows'), scanner.get('count'), default=krw)
        market_all = scanner.get('market_all') or scanner.get('market_all_count') or scanner.get('all_count') or '확인필요'
    elif isinstance(scanner, list):
        krw = sc_rows = len(scanner); market_all = '확인필요'
    else:
        krw = sc_rows = 0; market_all = '확인필요'
    st = snap['counts']
    all_st = snap.get('all_counts') if isinstance(snap.get('all_counts'), Counter) else Counter()
    strategy_input = _v650_int(strategy_summary.get('strategy_input_count_v661'), strategy_summary.get('evaluated'), default=len(rows)) if isinstance(strategy_summary, dict) else len(rows)
    sealed_rows = _v650_int(strategy_summary.get('strategy_coverage_rows_v661'), strategy_summary.get('paper_latest_count'), default=len(rows)) if isinstance(strategy_summary, dict) else len(rows)
    trade_rows = len(trade_rows_list) if trade_rows_list else _v650_int(strategy_summary.get('trade_candidate_rows_v661'), default=0) if isinstance(strategy_summary, dict) else 0
    coverage_rows = len(coverage_rows_list)
    return {
        'market_all': market_all or '확인필요', 'krw': krw or '확인필요', 'scanner': sc_rows or '확인필요',
        'strategy': strategy_input or len(rows), 'sealed': sealed_rows or len(rows), 'paper': trade_rows, 'coverage': coverage_rows, 'fresh': len(rows),
        'S1': int(st.get('S1',0)), 'S2': int(st.get('S2',0)), 'S3': int(st.get('S3',0)), 'uncat': int(st.get('미집계',0)),
        'raw_S3': int(all_st.get('S3',0)),
    }


def _v650_pipeline_lines() -> List[str]:
    p = _v650_pipeline()
    return [
        f"✅ 후보 배관: KRW {p['krw']} → scanner {p['scanner']} → 전략입력 {p['strategy']} → canonical봉인 {p['sealed']} → 실전후보 {p['paper']} / coverage {p['coverage']}",
        f"- 실전후보 등급: S1 {p['S1']} / S2 {p['S2']} / S3 {p['S3']} / 미집계 {p['uncat']}",
        f"- 참고: raw S3 {p['raw_S3']}개는 대부분 coverage/비후보 포함. 전체시장 감시는 하되 후보처럼 보지 않음.",
    ]


def _v650_counter_line(counter: Any, limit: int = 4) -> str:
    try:
        items = Counter(counter or {}).most_common(limit)
        return ' / '.join(f'{k} {v}' for k, v in items if v) or '-'
    except Exception:
        return '-'


def _v650_candidate_lines(limit_reasons: int = 4) -> List[str]:
    s = _v650_candidate_snapshot()
    c = s['counts']
    all_c = s.get('all_counts') if isinstance(s.get('all_counts'), Counter) else Counter()
    lines = [
        f"🚦 실전후보: S1 {int(c.get('S1',0))} / S2 {int(c.get('S2',0))} / S3 {int(c.get('S3',0))}",
        f"- 전체시장 참고: raw S3 {int(all_c.get('S3',0))} / coverage·비후보 {len(s.get('coverage_rows') or [])}",
        f"- 1분 가격: {_v650_counter_line(s['materials'], 4)}",
        f"- S1 막힘 TOP: {_v650_counter_line(s['reasons'], limit_reasons)}",
        f"- 위험 TOP: {_v650_counter_line(s['risks'], limit_reasons)}",
    ]
    if s.get('stale_all'):
        lines.append(f"- 정보 오래됨: 실전후보 {s.get('stale_trade',0)} / S1·S2 {s.get('stale_s12',0)} / coverage참고 {s.get('stale_coverage',0)} / 전체 {s.get('stale_all',0)}")
    if int(c.get('S1',0)) <= 0:
        lines.append('📌 판독: S1 실전후보는 0개. coverage/raw는 후보가 아니라 전체시장 감시 흔적입니다.')
    return lines


def _v650_resource_lines() -> List[str]:
    r = resource_snapshot() or {}
    load = r.get('load') or [0,0,0]
    try:
        cores = os.cpu_count() or 1
        per = float(load[0]) / max(1, cores)
    except Exception:
        per = 0.0
    # psutil 없이도 최소한 load 기반 CPU 체감값을 %로 같이 보여준다.
    cpu_pct = _v650_num(r.get('cpu_percent'), r.get('cpu_pct'), r.get('cpu_used_pct'), default=None) if any(k in r for k in ('cpu_percent','cpu_pct','cpu_used_pct')) else None
    if cpu_pct is None:
        cpu_pct = min(100.0, per * 100.0 / 2.5) if per else 0.0
    cpu_icon = '⚠️' if (cpu_pct >= 85 or per >= 2.0) else '✅'
    disk = _v650_num(r.get('disk_used_pct'), default=0.0)
    mem = _v650_num(r.get('mem_used_pct'), default=0.0)
    return [
        f"{cpu_icon} CPU: {cpu_pct:.1f}% / load {load} / 코어당 {per:.2f}",
        f"{'⚠️' if disk >= 85 else '✅'} 디스크: {disk:.1f}% 사용 / 남음 {r.get('disk_free_gb','-')}GB",
        f"{'⚠️' if mem >= 85 else '✅'} 메모리: {mem:.1f}% 사용 / 여유 {r.get('mem_free_mb','-')}MB",
    ]


def _v650_worker_line() -> str:
    ok=warn=bad=0; tops=[]
    for k in WORKERS:
        try:
            w=worker_status(k); a=_v650_num(w.get('age'), default=999999)
            if not w.get('alive') and str(w.get('state')) == 'missing': bad += 1
            elif a >= 60: warn += 1
            else: ok += 1
            tops.append((a,k))
        except Exception:
            warn += 1
    tops = sorted(tops, reverse=True)[:3]
    return f"- worker: ✅ {ok} / ⚠️ {warn} / ❌ {bad} · TOP " + ' / '.join(f'{k} {a:.1f}s' for a,k in tops)


def _v652_latest_file(pattern: str) -> Optional[Path]:
    try:
        files = [p for p in BASE_DIR.glob(pattern) if p.is_file()]
        if not files:
            return None
        return max(files, key=lambda x: x.stat().st_mtime)
    except Exception:
        return None


def _v653_load_trace_file(name: str) -> Dict[str, Any]:
    try:
        obj = _v650_load(BASE_DIR / name, {})
        return obj if isinstance(obj, dict) else {}
    except Exception:
        return {}


def _v653_ok(v: Any) -> str:
    if v is True or str(v).lower() in ('true','ok','sent_ok','success','✅'):
        return '✅'
    if v is False or str(v).lower() in ('false','error','send_error','❌'):
        return '❌'
    return '❔'


def _v650_hourly_lines() -> List[str]:
    # v653: paper_bot이 저장한 trace 파일을 직접 읽는다. main_bot은 상태문구를 임시 생성하지 않는다.
    st = _v650_status()
    h = _v653_load_trace_file('paper_bot_hourly_summary_trace.json') or (st.get('paper_hourly_summary_trace') if isinstance(st.get('paper_hourly_summary_trace'), dict) else {})
    raw = _v653_load_trace_file('paper_bot_hourly_raw_pack_trace.json') or (st.get('paper_hourly_raw_pack_trace') if isinstance(st.get('paper_hourly_raw_pack_trace'), dict) else {})

    def _target_ok(obj: Dict[str, Any], key: str) -> str:
        if key == 'paper':
            for k in ('paper_sent_ok','paper_ok','paper_sent','paper_room'):
                if k in obj: return _v653_ok(obj.get(k))
        if key == 'main':
            for k in ('main_sent_ok','main_ok','main_sent','main_room'):
                if k in obj: return _v653_ok(obj.get(k))
        targets = obj.get('send_targets') or obj.get('targets')
        if isinstance(targets, dict):
            t = targets.get(key) or targets.get(key + '_room') or {}
            if isinstance(t, dict):
                return _v653_ok(t.get('sent_ok') if 'sent_ok' in t else t.get('ok'))
        return '❔'

    def fmt(title: str, obj: Any) -> str:
        if not isinstance(obj, dict) or not obj:
            return f'- {title}: trace 없음'
        paper = _target_ok(obj, 'paper')
        main = _target_ok(obj, 'main')
        deleted = _v653_ok(obj.get('temp_deleted') if 'temp_deleted' in obj else obj.get('deleted') if 'deleted' in obj else obj.get('cleanup_ok'))
        ts = obj.get('updated_at_text') or obj.get('time') or obj.get('sent_at') or obj.get('created_at') or obj.get('ts') or '-'
        fn = obj.get('filename') or obj.get('file') or obj.get('path') or '-'
        result = obj.get('result') or obj.get('phase') or ''
        note = f' / {result}' if result else ''
        return f'- {title}: paper방 {paper} / main방 {main} / 삭제 {deleted} / {ts} / {Path(str(fn)).name if fn else "-"}{note}'

    out = [fmt('1시간 요약 알림', h), fmt('원문 묶음', raw)]
    if out[1].endswith('trace 없음'):
        latest = _v652_latest_file('paper_hourly_raw_pack_*.txt')
        if latest is not None:
            out[1] = f'- 원문 묶음: 최근파일 {latest.name} / trace 없음 / age {_v650_file_age(latest):.1f}s'
    if all('trace 없음' in x for x in out):
        return ['- 1시간 요약 trace 없음 · paper_bot trace 파일 미생성']
    return out


def _v678_cleanup_lines() -> List[str]:
    st = _v650_status()
    clean = _v650_load(BASE_DIR / 'paper_bot_cleanup_state.json', {})
    if not isinstance(clean, dict) or not clean:
        clean = st.get('cleanup_state') if isinstance(st.get('cleanup_state'), dict) else {}
    if not isinstance(clean, dict) or not clean:
        base = ['- cleanup: ❔ trace 없음']
    else:
        ok = '✅' if clean.get('ok', True) else '❌'
        hot = clean.get('score_hot_rows_policy') if isinstance(clean.get('score_hot_rows_policy'), dict) else {}
        pr = clean.get('jsonl_prune') if isinstance(clean.get('jsonl_prune'), dict) else {}
        tmp = clean.get('tmp_file_prune') if isinstance(clean.get('tmp_file_prune'), dict) else {}
        removed = 0
        for obj in pr.values():
            if isinstance(obj, dict):
                removed += int(_v650_int(obj.get('removed'), default=0))
        tmp_removed = 0
        for obj in tmp.values():
            if isinstance(obj, dict):
                tmp_removed += int(_v650_int(obj.get('removed'), default=0))
        age = now_ts() - _v650_num(clean.get('updated_at'), default=now_ts())
        base = [
            f'- cleanup: {ok} age {age:.1f}s / trace삭제 {removed}줄 / 임시파일 {tmp_removed}개',
            f"- score hot: 최근 {hot.get('hours','-')}h 또는 tail {hot.get('tail','-')} / CLOSED 원장 보존 {clean.get('closed_ledger_preserved', True)}",
        ]
    try:
        summ = _v681_stop_review_summary()
        base.append(f"- 손절초과: {summ.get('n',0)}건 / 평균초과 {summ.get('avg_overrun',0.0):+.2f}% / 최대초과 {summ.get('max_overrun',0.0):+.2f}% / 가격age의심 {summ.get('price_age_suspect',0)} / 루프gap의심 {summ.get('loop_gap_suspect',0)}")
    except Exception:
        try:
            q = BASE_DIR / 'paper_bot_stop_overrun_trace.jsonl'
            if q.exists():
                base.append(f'- 손절초과 trace: {len(q.read_text(encoding="utf-8", errors="ignore").splitlines()[-20:])} recent lines')
        except Exception:
            pass
    return base

def _v650_closed_source_lines(limit: int = 5) -> List[str]:
    score = _v650_score()
    lines=[]
    allc = score.get('closed_source_counts') if isinstance(score.get('closed_source_counts'), dict) else {}
    todayc = score.get('today_source_counts') if isinstance(score.get('today_source_counts'), dict) else {}
    total_ledger = _v650_int(score.get('ledger_closed_count'), score.get('closed_ledger_count'), score.get('closed_total'), allc.get('ledger'), default=0)
    total_rec = _v650_int(score.get('recovered_closed_count'), score.get('alert_recovered_count'), allc.get('alert_trace_recovered'), default=0)
    today_ledger = _v650_int(score.get('today_ledger_count'), score.get('today_ledger_closed_count'), todayc.get('ledger'), default=0)
    today_rec = _v650_int(score.get('today_recovered_count'), score.get('today_alert_recovered_count'), todayc.get('alert_trace_recovered'), default=0)
    if total_ledger or total_rec or today_ledger or today_rec:
        lines.append(f'- CLOSED 원천 전체: 장부 {total_ledger} / 알림보강 {total_rec}')
        lines.append(f'- 오늘 CLOSED 원천: 장부 {today_ledger} / 알림보강 {today_rec}')
    recent = (
        score.get('recent_closed_source_trace') or score.get('recent_closed_source') or
        score.get('recent_closed_rows') or score.get('recent_closed') or []
    )
    if isinstance(recent, list) and recent:
        lines.append('[최근 CLOSED 원천]')
        for r in recent[-limit:]:
            if not isinstance(r, dict): continue
            extra=[]
            peak=_v650_num(r.get('max_profit_pct'), r.get('peak_profit_pct'), r.get('best_pct'), default=None) if any(k in r for k in ('max_profit_pct','peak_profit_pct','best_pct')) else None
            hold=_v650_num(r.get('hold_sec'), r.get('duration_sec'), default=None) if any(k in r for k in ('hold_sec','duration_sec')) else None
            post=_v650_num(r.get('post_close_10m_pct'), r.get('after_close_10m_pct'), r.get('post_close_max_pct'), default=None) if any(k in r for k in ('post_close_10m_pct','after_close_10m_pct','post_close_max_pct')) else None
            if peak is not None: extra.append(f'최고 {peak:+.2f}%')
            if hold is not None: extra.append(f'보유 {hold/60:.1f}분')
            if post is not None: extra.append(f'청산후 {post:+.2f}%')
            ex = (' / ' + ' / '.join(extra)) if extra else ''
            src = r.get('source') or ('알림보강' if r.get('reconciled_from_close_alert_trace') else '장부')
            lines.append(f"- {_v650_ticker(r)} {_v650_pct(_v650_num(r.get('pnl_pct'), r.get('profit_pct'), default=0.0))} / {_v650_strategy(r)} / {r.get('entry_build_key') or r.get('score_patch_version') or 'legacy_unknown'} / source {src}{ex}")
    else:
        lines.append('- 최근 CLOSED 원천 상세 없음 · paper score cache 확인 필요')
    return lines


def _v650_condition_snapshot() -> Dict[str, Any]:
    rows = _v650_candidate_snapshot()['rows']
    roles = Counter(); by: Dict[str, Counter] = {}; sealed=0; s2like=0; dup=Counter()
    for r in rows:
        role_obj = r.get('condition_roles') or r.get('role_buckets') or r.get('condition_role_buckets') or r.get('condition_role_spine')
        if isinstance(role_obj, dict):
            sealed += 1
            for k in ('hard_block','execution_gate','recheck','score_only','confirm_pass','display_only'):
                if _v650_listify(role_obj.get(k)):
                    roles[k] += 1
        else:
            # fallback: reason/tag 기반 진단. worker 봉인과 구분해서 표시한다.
            rs = _v650_reasons(r); rk = _v650_risks(r); stg = _v650_structures(r)
            if rk or any(any(w in x for w in ('스프레드','미끄러','매도','stale','오래')) for x in rs): roles['hard_block'] += 1
            if any(any(w in x for w in ('방아쇠','trigger','대기','미도달')) for x in rs): roles['execution_gate'] += 1
            if rs: roles['recheck'] += 1
            if stg: roles['score_only'] += 1
            if rs or rk or stg: roles['display_only'] += 1
        name = _v650_strategy(r); by.setdefault(name, Counter()); by[name]['rows'] += 1; by[name][_v650_stage(r)] += 1
        for k in ('hard_block','execution_gate','recheck','score_only','display_only'):
            if roles[k]: pass
        if _v650_stage(r)=='S3' and _v650_structures(r) and _v650_reasons(r): s2like += 1
        for x in _v650_risks(r)+_v650_reasons(r): dup[x] += 1
    return {'rows': len(rows), 'sealed': sealed, 'roles': roles, 'by': by, 's2like': s2like, 'dup': dup}


def _v650_batch_text() -> str:
    score, today, r3, r6 = _v650_score_stats(); review = _v650_review()
    review_n = _v650_int(review.get('today_closed_count'), review.get('today_count'), default=0)
    lines = [
        '📦 코인봇 요약 /batch · v701', '',
        *_v651_score_window_lines(),
        f"✅ score/review: {score.get('today_closed_count', today['n'])} / {review.get('today_closed_count', review_n)}",
        '', *_v650_candidate_lines(4), '', *_v650_pipeline_lines(), '', '자원', *_v650_resource_lines(), '',
        '평소 보기: /menu → /health /score /stop_review /strategy_review /errorlog · 기능지도 /feature_map'
    ]
    return '\n'.join(lines)


def _v650_health_text() -> str:
    score, today, _, _ = _v650_score_stats(); review=_v650_review(); st=_v650_status()
    lines = [
        '🧭 시스템 상태 /health · v701',
        f'- 메인봇: {BOT_VERSION} / {V650_BUILD_LABEL}',
        f"- paper: {st.get('version','-')} / build {st.get('build','-')} / OPEN {_v650_open_count()}",
        f"- score/review: 오늘 {score.get('today_closed_count', today['n'])} / {review.get('today_closed_count', '-')}",
        '', _v650_worker_line(), '', '자원', *_v650_resource_lines(), '', '후보 cache', *_v650_pipeline_lines()[:2], '', '정리/순환', *_v678_cleanup_lines(), '', '요약 알림', *_v650_hourly_lines()
    ]
    return '\n'.join(lines)


def _v650_version_score_text() -> str:
    score, today, r3, r6 = _v650_score_stats(); review=_v650_review()
    lines = [
        '📊 성과 /version_score · v661', '- 기준: OPEN 당시 수정버전. 현재 실행버전으로 과거 전적 덮지 않음.', '',
        *_v651_score_window_lines(),
        f"- cache: score {score.get('schema','-')} / review {review.get('schema','-')}", '', '전략별 오늘'
    ]
    strat = score.get('today_strategy_stats') if isinstance(score.get('today_strategy_stats'), dict) else {}
    if strat:
        items=[]
        for name,obj in strat.items():
            st=_v650_stat_obj(obj); items.append((st.get('total',0.0), name, st))
        for _, name, st in sorted(items, reverse=True)[:8]:
            lines.append(_v650_stat_line(str(name), st))
    else:
        lines.append('- 오늘 전략별 집계 없음')
    lines += ['', '최근 CLOSED 원천/알림', *_v650_closed_source_lines(6)]
    return '\n'.join(lines)



def _v666_trigger_shadow_visible_block() -> str:
    """Display-only consumer for trigger shadow benchmark.

    main reads strategy/review worker cache files only and prints the shadow
    queue/result near the top of /candidate_reason. No candidate/price
    recomputation here.
    """
    try:
        cand_path = BASE_DIR / 'clean_trigger_shadow_strategy_summary_v665.json'
        review_path = FILES.get('trigger_shadow_review', BASE_DIR/'clean_trigger_shadow_review_v665.json')
        cand = _v650_load(cand_path, {}) or {}
        rev = _v650_load(review_path, {}) or {}
        lines = ['[트리거 shadow 검증 · v666]']
        if isinstance(cand, dict) and cand:
            cage = _v650_file_age(cand_path) if cand_path.exists() else 9999.0
            srcs = cand.get('source_counts') if isinstance(cand.get('source_counts'), dict) else {}
            gaps = cand.get('gap_counts') if isinstance(cand.get('gap_counts'), dict) else {}
            lines.append(f"- 후보 cache: age {cage:.1f}s / 저장후보 {cand.get('candidate_count',0)} / 방식 current·near_0_10·near_0_30·actual_trigger")
            lines.append('- source TOP: ' + (' / '.join(f'{k} {v}' for k, v in Counter(srcs).most_common(5)) if srcs else '-'))
            lines.append('- gap TOP: ' + (' / '.join(f'{k} {v}' for k, v in Counter(gaps).most_common(5)) if gaps else '-'))
        else:
            lines.append('- 후보 cache 준비중: strategy_worker shadow 후보 파일 미생성/비어 있음')
        lines.append('[트리거 shadow 결과 · v666]')
        if isinstance(rev, dict) and rev:
            rage = _v650_file_age(review_path) if review_path.exists() else 9999.0
            vs = rev.get('variant_summary') if isinstance(rev.get('variant_summary'), dict) else {}
            def vline(key: str, label: str) -> str:
                st = vs.get(key) if isinstance(vs.get(key), dict) else {}
                if not st:
                    return f'- {label}: -'
                return f'- {label}: 진입 {st.get("entered",0)}/{st.get("total",0)} / avg max {float(st.get("avg_max_pct") or 0):+.2f}% / +0.3 {st.get("win_0_3_count",0)} / -0.3 {st.get("loss_0_3_count",0)}'
            lines.append(f"- 결과 cache: age {rage:.1f}s / active {rev.get('active_count',0)} / entered {rev.get('entered_count',0)} / pending {rev.get('pending_count',0)}")
            lines.append(vline('current_price', '현재가'))
            lines.append(vline('near_0_10', '방아쇠-0.10%'))
            lines.append(vline('near_0_30', '방아쇠-0.30%'))
            lines.append(vline('actual_trigger', '기존방아쇠'))
            top = rev.get('top_entered') if isinstance(rev.get('top_entered'), list) else []
            tops=[]
            for r in top[:5]:
                if not isinstance(r, dict):
                    continue
                tops.append(f"{r.get('ticker')} {r.get('variant')} max {float(r.get('max_pct') or 0):+.2f}% cur {float(r.get('current_pct') or 0):+.2f}%")
            lines.append('- TOP: ' + (' / '.join(tops) if tops else '-'))
        else:
            lines.append('- 결과 cache 준비중: review_worker가 후보 수집 후 다음 cycle부터 집계')
        lines.append('- 기준: shadow 검증만 표시. 실제 S1/OPEN/청산/자동매수 변경 없음.')
        return '\n'.join(lines)
    except Exception as exc:
        log_error('v666_trigger_shadow_visible_block', exc)
        return '[트리거 shadow 검증 · v666]\n- cache 읽기 실패'



def _v667_market_miss_visible_block() -> str:
    """v668 display-only consumer for whole-market missed-scan review.

    review_worker owns 3/5/10m follow-up. main_bot reads only the worker caches.
    This block also shows candidate/source counts so the user does not need to
    manually wait and guess whether the 10m review is running.
    """
    try:
        result_path = BASE_DIR / 'clean_market_miss_review_v667.json'
        cand_path = BASE_DIR / 'clean_market_miss_candidates_v667.json'
        state_path = BASE_DIR / 'clean_market_miss_state_v667.json'
        obj = _v650_load(result_path, {}) or {}
        cand = _v650_load(cand_path, {}) or {}
        state = _v650_load(state_path, {}) or {}
        lines = ['[전체 스캔 놓침 검증 · v668]']
        cand_rows = cand.get('rows') if isinstance(cand, dict) and isinstance(cand.get('rows'), list) else []
        cand_age = _v650_file_age(cand_path) if cand_path.exists() else 9999.0
        active = state.get('active') if isinstance(state, dict) and isinstance(state.get('active'), dict) else {}
        active_rows = list(active.values()) if isinstance(active, dict) else []
        near_mature = sum(1 for r in active_rows if isinstance(r, dict) and float(r.get('age_sec') or 0) >= 120)
        lines.append(f"- 후보 cache: age {cand_age:.1f}s / 저장 {len(cand_rows)} / 추적중 {len(active_rows)} / 2분경과 {near_mature}")
        if isinstance(cand, dict):
            src_total = cand.get('source_total_count') or cand.get('canonical_source_count') or cand.get('candidate_count') or len(cand_rows)
            excl = cand.get('source_exclude_counts') if isinstance(cand.get('source_exclude_counts'), dict) else {}
            lines.append(f"- 저장범위: source {src_total} → 저장 {cand.get('candidate_count', len(cand_rows))} / 품질60+ {cand.get('quality_candidate_count',0)}")
            if excl:
                lines.append('- 저장제외 TOP: ' + ' / '.join(f'{k} {v}' for k, v in Counter(excl).most_common(5)))
        if not isinstance(obj, dict) or not obj:
            lines.append('- 결과 cache 준비중: review_worker가 3/5/10분 사후 가격을 자동 추적 중')
            lines.append('- 기준: 전체 canonical snapshot 사후검증. 실제 S1/OPEN/청산/자동매수 변경 없음.')
            return '\n'.join(lines)
        age = _v650_file_age(result_path) if result_path.exists() else 9999.0
        lines.append(f"- 결과 cache: age {age:.1f}s / tracking {obj.get('tracking_total',0)} / matured {obj.get('matured_count',0)} / 상승후보 {obj.get('rise_count',0)} / 진짜놓침 {obj.get('true_missed_count',0)}")
        buckets = obj.get('miss_bucket_counts') if isinstance(obj.get('miss_bucket_counts'), dict) else {}
        lines.append('- 놓침분류 TOP: ' + (' / '.join(f'{k} {v}' for k, v in Counter(buckets).most_common(7)) if buckets else '-'))
        dec = obj.get('decision_counts') if isinstance(obj.get('decision_counts'), dict) else {}
        lines.append('- 판정 TOP: ' + (' / '.join(f'{k} {v}' for k, v in Counter(dec).most_common(6)) if dec else '-'))
        top = obj.get('top_risers') if isinstance(obj.get('top_risers'), list) else []
        tops=[]
        for r in top[:6]:
            if not isinstance(r, dict):
                continue
            tops.append(f"{r.get('ticker')} {r.get('initial_stage')} max {float(r.get('max_pct') or 0):+.2f}% / {r.get('miss_bucket')} / {r.get('miss_decision','-')}")
        lines.append('- 오른 후보 TOP: ' + (' / '.join(tops) if tops else '-'))
        true_missed = obj.get('true_missed_top') if isinstance(obj.get('true_missed_top'), list) else []
        miss=[]
        for r in true_missed[:5]:
            if not isinstance(r, dict):
                continue
            miss.append(f"{r.get('ticker')} max {float(r.get('max_pct') or 0):+.2f}% / {r.get('miss_bucket')} / {r.get('initial_reason','-')}")
        lines.append('- 진짜놓침 후보 TOP: ' + (' / '.join(miss) if miss else '-'))
        lane = obj.get('recheck_lane_counts') if isinstance(obj.get('recheck_lane_counts'), dict) else {}
        if lane:
            lines.append('- 재수집 lane TOP: ' + ' / '.join(f'{k} {v}' for k, v in Counter(lane).most_common(6)))
        lines.append('- 기준: scanner/feature/candle/orderflow/strategy/trigger 중 어디서 묻혔는지 사후 상승률로 검증. 실제 매수조건 변경 없음.')
        return '\n'.join(lines)
    except Exception as exc:
        log_error('v668_market_miss_visible_block', exc)
        return '[전체 스캔 놓침 검증 · v668]\n- cache 읽기 실패'

def _v666_strip_shadow_blocks(text: str) -> str:
    """Remove old shadow blocks from worker text so v666 top block is single source."""
    out=[]; skip=False
    for line in str(text or '').splitlines():
        if '[트리거 shadow 검증' in line or '[트리거 shadow 결과' in line:
            skip=True
            continue
        if skip and line.startswith('['):
            skip=False
        if not skip:
            out.append(line)
    return '\n'.join(out).strip()


def _v673_fast_quality_visible_block() -> str:
    """Display-only consumer for fast-quality paper experiment lane.

    strategy_worker owns candidate marking and writes clean_fast_quality_paper_lane_v669.json.
    paper_bot owns actual paper selection/open counters through status/handoff pick_stats.
    main_bot only reads those caches and prints the lane state.
    """
    try:
        path = BASE_DIR / 'clean_fast_quality_paper_lane_v669.json'
        obj = _v650_load(path, {}) or {}
        hand = _v650_load(FILES.get('paperbot_handoff', BASE_DIR/'paper_bot_candidate_handoff_status.json'), {}) or {}
        pst = _v650_load(FILES.get('paper_status', BASE_DIR/'paper_bot_status.json'), {}) or {}
        pick = {}
        for src in (pst, hand):
            ps = src.get('pick_stats') if isinstance(src, dict) and isinstance(src.get('pick_stats'), dict) else {}
            if isinstance(ps, dict):
                pick.update(ps)
        lines = ['[고품질 빠른진입 paper 실험 · v673]']
        age = _v650_file_age(path) if path.exists() else 9999.0
        if isinstance(obj, dict) and obj:
            acc = obj.get('accepted_top') if isinstance(obj.get('accepted_top'), list) else []
            rej = obj.get('reject_reason_top') if isinstance(obj.get('reject_reason_top'), dict) else {}
            lines.append(f"- 후보 cache: age {age:.1f}s / accepted {obj.get('accepted_count',0)} / real_eligible false / BUY_READY false")
            if acc:
                tops=[]
                for x in acc[:6]:
                    if not isinstance(x, dict):
                        continue
                    tops.append(f"{x.get('ticker')} {x.get('stage')} Q{float(x.get('q') or 0):.1f} R{float(x.get('risk') or 0):.1f} gap {float(x.get('gap') or 0):+.2f}%")
                lines.append('- 후보 TOP: ' + (' / '.join(tops) if tops else '-'))
            else:
                lines.append('- 후보 TOP: -')
            lines.append('- 탈락 TOP: ' + (' / '.join(f'{k} {v}' for k, v in Counter(rej).most_common(6)) if rej else '-'))
        else:
            lines.append('- 후보 cache 준비중: strategy_worker가 clean_fast_quality_paper_lane_v669.json 생성 전')
        lines.append(
            '- paper 수신: seen {seen} / selected {sel} / limit_skip {lim} / hold {hold}'.format(
                seen=pick.get('fast_quality_paper_seen',0),
                sel=pick.get('selected_fast_quality_paper',0),
                lim=pick.get('fast_quality_paper_limit_skip',0),
                hold=pick.get('fast_quality_paper_final_hold', pick.get('paper_entry_hold', pick.get('paper_final_block',0))),
            )
        )
        last_hold = pick.get('last_fast_quality_paper_hold') or pick.get('last_paper_entry_hold')
        if isinstance(last_hold, dict) and last_hold:
            lines.append('- paper 최종보류: {ticker} / {reason}'.format(
                ticker=last_hold.get('ticker') or last_hold.get('market') or '-',
                reason=last_hold.get('reason') or last_hold.get('status') or '-'))
        lines.append(f"- paper version: {pst.get('version','-')} / build {pst.get('build','-')}")
        lines.append('- 기준: paper-only 실험 lane. 실제 자동매수/BUY_READY/청산조건 변경 없음.')
        return '\n'.join(lines)
    except Exception as exc:
        log_error('v673_fast_quality_visible_block', exc)
        return '[고품질 빠른진입 paper 실험 · v673]\n- cache 읽기 실패'


def _v673_strip_fast_quality_blocks(text: str) -> str:
    out=[]; skip=False
    for line in str(text or '').splitlines():
        if '[고품질 빠른진입 paper 실험' in line or '[fast quality paper 실험' in line:
            skip=True
            continue
        if skip and line.startswith('['):
            skip=False
        if not skip:
            out.append(line)
    return '\n'.join(out).strip()

def _v657_worker_candidate_reason_text() -> str:
    """Read strategy_worker-rendered candidate reason text cache only.

    The coin-quality spine is produced by strategy_worker and written to
    clean_candidate_reason_text_cache.txt. main_bot is a consumer: no candidate
    resorting, no strategy recomputation, no output-side quality calculation.
    """
    txt_path = FILES.get('candidate_reason_text', BASE_DIR/'clean_candidate_reason_text_cache.txt')
    state_path = FILES.get('candidate_reason_text_state', BASE_DIR/'clean_candidate_reason_state_cache.json')
    state = _v650_load(state_path, {}) or {}
    try:
        if not txt_path.exists():
            return '🧭 후보 이유 /candidate_reason · v661\n\n❔ strategy_worker 후보 이유 text cache 준비중\n- main_bot은 후보를 재계산하지 않습니다. strategy_worker가 만든 cache만 읽습니다.'
        text = txt_path.read_text(encoding='utf-8', errors='ignore').strip()
        if not text:
            return '🧭 후보 이유 /candidate_reason · v661\n\n❔ strategy_worker 후보 이유 text cache 비어 있음'
        age_sec = _v650_file_age(txt_path)
        header = f'🧭 후보 이유 /candidate_reason · v661\n- source: strategy_worker text cache / age {age_sec:.1f}s / schema {state.get("schema", "-")}'
        # Avoid double title spam if worker text already starts with a candidate title.
        body = text
        if body.startswith('🧭'):
            body = '\n'.join(body.split('\n')[1:]).strip()
        body = _v666_strip_shadow_blocks(body)
        body = _v673_strip_fast_quality_blocks(body)
        shadow_block = _v666_trigger_shadow_visible_block()
        fast_block = _v673_fast_quality_visible_block()
        miss_block = _v667_market_miss_visible_block()
        if '[코인 종합품질' not in body:
            body += '\n\n[코인 종합품질]\n- 품질 block 미표시: strategy_worker_v0.150 이후 cache 갱신을 한 번 더 기다리거나 /gworker_state 확인 필요'
        merged = shadow_block + '\n' + fast_block + '\n' + miss_block + ('\n' + body if body else '')
        return header + ('\n' + merged if merged else '')
    except Exception as exc:
        log_error('v657_worker_candidate_reason_text', exc)
        return f'🧭 후보 이유 /candidate_reason · v661\n\n❌ 후보 이유 cache 읽기 실패: {exc.__class__.__name__}'


def _v650_candidate_reason_text() -> str:
    return _v657_worker_candidate_reason_text()


def _v650_condition_review_text() -> str:
    d=_v650_condition_snapshot(); roles=d['roles']; by=d['by']; dup=d['dup']
    lines = [
        '🧩 조건 역할 상세 /condition_review · v657',
        '- 조건값은 바꾸지 않고, 후보 row 역할 정보와 fallback 진단을 분리해서 봅니다.', '',
        f"전체 후보 {d['rows']}개 / worker 역할봉인 {d['sealed']}개",
        f"- ❌ 진짜 차단: {roles.get('hard_block',0)}",
        f"- ⚠️ 진입 대기: {roles.get('execution_gate',0)}",
        f"- 🔁 재확인 필요: {roles.get('recheck',0)}",
        f"- ✅ 구조/가점: {roles.get('score_only',0)}",
        f"- ✅ 확인 통과: {roles.get('confirm_pass',0)}",
        f"- ❔ 참고 태그: {roles.get('display_only',0)}", '',
        f"구조는 괜찮지만 확인/대기 부족: {d['s2like']}개", '', '전략별 요약'
    ]
    for name,c in sorted(by.items(), key=lambda kv: kv[1].get('rows',0), reverse=True)[:6]:
        lines.append(f"- {name}: {c.get('rows',0)}개 / S1 {c.get('S1',0)} · S2 {c.get('S2',0)} · S3 {c.get('S3',0)}")
    if dup:
        lines += ['', '참고/중복 태그 TOP', '- ' + _v650_counter_line(dup,5)]
    lines += ['', '판독', '- 공통층은 위험/실행만, 매수 논리는 전략별로 분리합니다. 조건 수치 변경은 별도 승인 후 진행합니다.']
    return '\n'.join(lines)



def _v743_paper_active_lines() -> List[str]:
    st = _v650_status()
    ver = str(st.get("paper_version") or st.get("version") or "-")
    build = str(st.get("build") or "-")
    ok = ("paper_bot_v0.795" in ver) or ("v759" in build)
    icon = "✅" if ok else "❌"
    return [f"- paper 적용: {icon} active {ver} / build {build} / expected paper_bot_v0.795"]

def _v650_paper_handoff_text() -> str:
    hand = _v650_load(FILES.get('paperbot_handoff', BASE_DIR/'paper_bot_candidate_handoff_status.json'), {}) or {}
    score,today,_,_=_v650_score_stats(); review=_v650_review()
    lines = [
        '📨 paper 전달 /paper_handoff · v661',
        f"- OPEN: {_v650_open_count()} / status age {_v650_file_age(FILES.get('paper_status', BASE_DIR/'paper_bot_status.json')):.1f}s",
        *_v743_paper_active_lines(),
        f"- 후보선별: latest {hand.get('latest', hand.get('candidate_count','-'))} / fresh {hand.get('fresh', hand.get('fresh_count','-'))}",
        *_v743_s1_hold_lines(),
        *_v743_paper_hold_trace_lines(),
        f"- score/review: 오늘 {score.get('today_closed_count', today['n'])} / {review.get('today_closed_count','-')}", '',
        *_v650_pipeline_lines(), '', *_v650_candidate_lines(4), '', '요약 알림', *_v650_hourly_lines()
    ]
    return '\n'.join(lines)


def _v650_pstatus_text() -> str:
    st=_v650_status(); score,today,_,_=_v650_score_stats(); review=_v650_review()
    trace = st.get('s1_flow') or st.get('s1_trace') or {}
    trace_line = f"- S1 흐름 trace: 감지 {trace.get('detected', trace.get('s1_detected',0))} / 선택 {trace.get('selected',0)} / 보류 {trace.get('deferred', trace.get('hold',0))} / micro대기 {trace.get('micro_wait',0)} / OPEN {_v650_open_count()} / drop {trace.get('drop',0)}" if isinstance(trace, dict) else '- S1 흐름 trace: 준비중'
    return '\n'.join([
        '🧪 paper 상태 /pstatus · v661',
        f"- paper: {st.get('version','-')} / build {st.get('build','-')}",
        f"- OPEN: {_v650_open_count()} / CLOSED누적 {st.get('closed_total', st.get('closed_count','-'))}",
        f"- score/review: 오늘 {score.get('today_closed_count', today['n'])} / {review.get('today_closed_count','-')}",
        '- fast paper: ' + (lambda _p: f"seen {_p.get('fast_quality_paper_seen',0)} / selected {_p.get('selected_fast_quality_paper',0)} / limit {_p.get('fast_quality_paper_limit_skip',0)} / hold {_p.get('fast_quality_paper_final_hold',0)}")((_v650_status().get('pick_stats') if isinstance(_v650_status().get('pick_stats'), dict) else {})), '',
        *_v650_candidate_lines(4), '', 'S1 선택/보류 trace', trace_line, '', '최근 CLOSED 원천/알림', *_v650_closed_source_lines(5)
    ])


def _v650_trade_review_text() -> str:
    obj = _v650_review()
    txt = obj.get('summary_text') or obj.get('text') or obj.get('report')
    if txt:
        return str(txt)[:3800]
    return '📊 전략 복기 /trade_review · v650\n- paper review cache summary_text 준비중\n- /version_score의 전략별 오늘 성과를 우선 확인하세요.'


def _v650_errorlog_text() -> str:
    p = FILES.get('brain_error', BASE_DIR/'clean_brain_error.log')
    header = '🧯 오류로그 /errorlog'
    try:
        if not p.exists() or p.stat().st_size <= 0:
            return header + '\n\n✅ 새 실행 중 오류 없음'
        # v736: huge error logs made /errorlog slow. Read only tail bytes.
        with p.open('rb') as fh:
            try:
                fh.seek(0, os.SEEK_END)
                size = fh.tell()
                fh.seek(max(0, size - 16384), os.SEEK_SET)
            except Exception:
                pass
            raw = fh.read().decode('utf-8', errors='ignore')
        lines = [x for x in raw.splitlines() if x.strip()]
        new_lines: List[str] = []
        old_lines: List[str] = []
        for ln in lines[-80:]:
            parsed_ts = 0.0
            m = re.match(r"\[(\d{4}-\d{2}-\d{2} \d{2}:\d{2}:\d{2})\]", ln)
            if m:
                try:
                    parsed_ts = time.mktime(time.strptime(m.group(1), "%Y-%m-%d %H:%M:%S"))
                except Exception:
                    parsed_ts = 0.0
            if parsed_ts and parsed_ts >= START_TS:
                new_lines.append(ln)
            elif '[' in ln:
                old_lines.append(ln)
        if new_lines:
            return header + '\n\n❌ 새 실행 이후 오류\n' + '\n'.join(new_lines[-8:])
        out = [header, '', '✅ 새 실행 중 오류 없음']
        if old_lines:
            out.append(f'- 과거 오류 흔적 {len(old_lines)}줄 있음 / 최근 2개만 참고')
            out += old_lines[-2:]
        return '\n'.join(out)
    except Exception as exc:
        return f'{header}\n- 오류로그 읽기 실패: {exc.__class__.__name__}'


def _v650_safe_body(txt: Any, limit: int = 1800) -> str:
    s=str(txt or '')
    return s if len(s) <= limit else s[:limit].rstrip() + '\n…(상세 생략)'



_V797_BATCH_MARKER_PATH = BASE_DIR / 'coinbot_batch_summary_marker_v798.json'
_V797_PENDING_BATCH_MARKER_TS: float = 0.0


def _v800_kst_text(ts: Any = None) -> str:
    """항상 KST로 표시한다. 서버 localtime/UTC 혼선을 막기 위한 표시 전용 helper."""
    try:
        import datetime as _dt
        t = float(ts or now_ts())
        return _dt.datetime.fromtimestamp(t, _dt.timezone(_dt.timedelta(hours=9))).strftime('%Y-%m-%d %H:%M:%S KST')
    except Exception:
        try:
            return now_text(float(ts or now_ts())) + ' KST?'
        except Exception:
            return '-'

def _v798_batch_marker_ts() -> float:
    obj = _v650_load(_V797_BATCH_MARKER_PATH, {}) or {}
    if isinstance(obj, dict):
        return _v650_num(obj.get('last_summary_ts'), default=0.0)
    return 0.0


def _v798_save_batch_marker(ts: float) -> None:
    try:
        save_json(_V797_BATCH_MARKER_PATH, {
            'schema': 'batch_summary_marker_v798',
            'last_summary_ts': float(ts or now_ts()),
            'last_summary_text': now_text(float(ts or now_ts())),
            'note': 'main batch summary interval marker only; summary txt is still deleted after Telegram send.',
        })
    except Exception as exc:
        log_error('v798_batch_marker_save', exc)



def _v798_trade_cache_events() -> List[Dict[str, Any]]:
    """paper_bot 소유 매매상세 cache만 읽는다. v800을 우선하고 v798은 이전 cache 호환용 fallback."""
    for fname in ('paper_bot_trade_detail_cache_v800.json', 'paper_bot_trade_detail_cache_v798.json'):
        obj = _v650_load(BASE_DIR / fname, {}) or {}
        if isinstance(obj, dict) and isinstance(obj.get('events'), list):
            return [x for x in obj.get('events') or [] if isinstance(x, dict)]
    for fname in ('paper_bot_trade_detail_v800.jsonl', 'paper_bot_trade_detail_v798.jsonl'):
        try:
            rows = read_jsonl(BASE_DIR / fname, 320)
            if rows:
                return [x for x in rows if isinstance(x, dict)]
        except Exception:
            pass
    return []


def _v798_fmt_price(v: Any) -> str:
    x = _v650_num(v, default=0.0)
    if x >= 1000: return f'{x:,.0f}'
    if x >= 1: return f'{x:,.4f}'
    if x > 0: return f'{x:,.8f}'
    return '-'



def _v800_reaction_summary(ev: Dict[str, Any]) -> str:
    react = ev.get('post_entry_reaction_v800') if isinstance(ev.get('post_entry_reaction_v800'), dict) else {}
    if not react:
        react = ev.get('post_entry_reaction_v793') if isinstance(ev.get('post_entry_reaction_v793'), dict) else {}
    if not react:
        return '-'
    order = [('s30','30초'),('m1','1분'),('m3','3분'),('m5','5분'),('m10','10분')]
    parts=[]
    for key,label in order:
        o=react.get(key) if isinstance(react.get(key), dict) else {}
        if o:
            net = _v650_num(o.get('net_pct'), default=0.0)
            if o.get('gross_pct') not in (None, ''):
                gross = _v650_num(o.get('gross_pct'), default=0.0)
                parts.append(f"{label} 총{gross:+.2f}%/순{net:+.2f}%/{str(o.get('label') or '-')}")
            else:
                parts.append(f"{label} {net:+.2f}%/{str(o.get('label') or '-')}")
    return ' · '.join(parts) if parts else '-'


def _v800_entry_check_summary(ev: Dict[str, Any]) -> str:
    chk = ev.get('entry_checks_v800') if isinstance(ev.get('entry_checks_v800'), dict) else {}
    if not chk:
        return '-'
    keys=[('price_reaction_pct','반응'),('buy_ratio','체결'),('buy_sustain_1m','1분지속'),('spread_pct','스프레드'),('slippage_pct','미끄러짐'),('sell_pressure','매도압력')]
    parts=[]
    for k,label in keys:
        if k in chk and chk.get(k) not in (None,''):
            try:
                if k in ('buy_ratio','buy_sustain_1m'):
                    parts.append(f"{label} {_v650_num(chk.get(k), default=0.0):.2f}")
                else:
                    parts.append(f"{label} {_v650_num(chk.get(k), default=0.0):+.2f}%")
            except Exception:
                parts.append(f"{label} {chk.get(k)}")
    return ' / '.join(parts) if parts else '-'


def _v800_quality_warning_line(ev: Dict[str, Any]) -> str:
    flags = ev.get('quality_flags_v800') if isinstance(ev.get('quality_flags_v800'), list) else []
    label = ev.get('quality_label_v800') or '-'
    if flags:
        return f"{label} · " + ' / '.join(str(x) for x in flags[:5])
    return str(label)


def _v798_trade_line(ev: Dict[str, Any]) -> str:
    kind = str(ev.get('kind') or '-')
    icon = '🟢 OPEN' if kind == 'open' else ('🔴 CLOSED' if kind == 'closed' else kind)
    plan = ev.get('plan') if isinstance(ev.get('plan'), dict) else {}
    rr = _v650_num(plan.get('rr_ratio'), default=0.0)
    reward = _v650_num(plan.get('reward_pct'), default=0.0)
    risk = _v650_num(plan.get('risk_pct'), default=0.0)
    price = f"진입 {_v798_fmt_price(ev.get('entry_price'))}"
    if kind == 'closed':
        price += f" → 청산 {_v798_fmt_price(ev.get('exit_price'))}"
    pnl = '' if kind == 'open' else f" / 손익 {_v650_num(ev.get('pnl_pct'), default=0.0):+.2f}% / 최고 {_v650_num(ev.get('peak_pct'), default=0.0):+.2f}% / 최저 {_v650_num(ev.get('trough_pct'), default=0.0):+.2f}%"
    tags = ev.get('good_tags') if isinstance(ev.get('good_tags'), list) else []
    warns = ev.get('warning_tags') if isinstance(ev.get('warning_tags'), list) else []
    react_tags = ev.get('reaction_tags') if isinstance(ev.get('reaction_tags'), list) else []
    tag_src = tags[:3] if tags else react_tags[:3]
    tag_txt = ' / '.join(str(x) for x in tag_src) or '-'
    warn_txt = ' / '.join(str(x) for x in warns[:3]) or '-'
    route_txt = _v799_label(plan.get('entry_route_v802') or 'structure') if plan else '-'
    pat_txt = str(plan.get('common_pattern_key_v802') or '').replace('common_scalp|','') if plan else ''
    pat_line = f"  · 진입경로 {route_txt}" + (f" / 공통패턴 {pat_txt}" if pat_txt else '') + "\n"
    return (
        f"- {icon} {ev.get('ticker') or '-'} · {ev.get('ts_text_kst') or ev.get('ts_text') or '-'}\n"
        f"  · {price}{pnl}\n" +
        pat_line +
        f"  · 전략 {ev.get('strategy') or '-'} / 등급 {ev.get('grade') or '-'} / 구조 {ev.get('line_quality') or '-'} · {ev.get('line_reaction') or '-'} · {ev.get('structure_interpretation') or '-'}\n"
        f"  · 계획 {plan.get('plan_state','-')} / RR {rr:.2f} / 목표 {reward:+.2f}% / 위험 {risk:.2f}% / 결과 {ev.get('plan_result_label') or '-'}\n"
        f"  · 진입확인 {_v800_entry_check_summary(ev)}\n"
        f"  · 진입후반응 {_v800_reaction_summary(ev)}\n"
        f"  · 품질판정 {_v800_quality_warning_line(ev)}\n"
        f"  · 좋은태그 {tag_txt} / 주의 {warn_txt}"
    )



def _v798_batch_trade_detail_lines(since_ts: float, until_ts: float) -> List[str]:
    events = []
    for ev in _v798_trade_cache_events():
        ts = _v650_num(ev.get('ts'), default=0.0)
        if ts <= 0:
            continue
        if since_ts > 0 and ts <= since_ts:
            continue
        if until_ts > 0 and ts > until_ts + 2:
            continue
        events.append(ev)
    events.sort(key=lambda x: _v650_num(x.get('ts'), default=0.0))
    since_txt = _v800_kst_text(since_ts) if since_ts else 'marker 없음(최근 cache 기준)'
    lines = ['[이전 요약 이후 매매 상세]', f'- 구간: {since_txt} → {_v800_kst_text(until_ts)}', f'- 이벤트: {len(events)}개 / paper 매매상세 cache']
    if not events:
        lines.append('- 새 OPEN/CLOSED 없음')
        return lines
    opens = sum(1 for e in events if str(e.get('kind')) == 'open')
    closed = [e for e in events if str(e.get('kind')) == 'closed']
    pnl_vals = [_v650_num(e.get('pnl_pct'), default=0.0) for e in closed]
    if closed:
        wins = sum(1 for v in pnl_vals if v > 0)
        lines.append(f'- 요약: OPEN {opens} / CLOSED {len(closed)} / {wins}승 {len(closed)-wins}패 / 합산 {sum(pnl_vals):+.2f}% / 평균 {(sum(pnl_vals)/len(pnl_vals)):+.2f}%')
    else:
        lines.append(f'- 요약: OPEN {opens} / CLOSED 0')
    # 품질 bucket
    good_closed = [e for e in closed if _v650_num(e.get('pnl_pct'), default=0.0) > 0]
    bad_closed = [e for e in closed if _v650_num(e.get('pnl_pct'), default=0.0) <= 0]
    no_react = [e for e in closed if '진입후반응없음' in (e.get('quality_flags_v800') or []) or '바로역행' in (e.get('quality_flags_v800') or [])]
    risky = [e for e in events if 'hard_risk_hold_open' in (e.get('quality_flags_v800') or []) or 'rr_below_1_open' in (e.get('quality_flags_v800') or [])]
    if good_closed:
        lines.append('- 좋았던 진입: ' + ' / '.join(f"{e.get('ticker')} {_v650_num(e.get('pnl_pct'), default=0.0):+.2f}% {e.get('quality_label_v800') or e.get('line_reaction') or '-'}" for e in good_closed[:5]))
    if bad_closed:
        lines.append('- 나빴던 진입: ' + ' / '.join(f"{e.get('ticker')} {_v650_num(e.get('pnl_pct'), default=0.0):+.2f}% {e.get('plan_result_label') or e.get('quality_label_v800') or '-'}" for e in bad_closed[:5]))
    if no_react:
        lines.append('- 무반응/바로역행: ' + ' / '.join(f"{e.get('ticker')} {e.get('quality_label_v800') or '-'}" for e in no_react[:5]))
    if risky:
        lines.append('- OPEN 주의표시: ' + ' / '.join(f"{e.get('ticker')} {'/'.join(e.get('quality_flags_v800') or [])}" for e in risky[:5]))
    lines.append('')
    lines.append('[상세]')
    for ev in events[-14:]:
        lines.append(_v798_trade_line(ev))
    if len(events) > 14:
        lines.append(f'- 그 외 {len(events)-14}개 생략')
    return lines



def _v650_batch_summary_text(cmds: List[str], outputs: Dict[str,str], timings: List[Dict[str,Any]], recv_delay: float, total_sec: float) -> str:  # type: ignore[override]
    global _V797_PENDING_BATCH_MARKER_TS
    batch_until = now_ts(); _V797_PENDING_BATCH_MARKER_TS = batch_until
    since_ts = _v798_batch_marker_ts() if '_v798_batch_marker_ts' in globals() else 0.0
    lines=['코인봇 묶음 요약집 v806', f'- 생성: {_v800_kst_text(batch_until)}', f'- 메인봇: {BOT_VERSION} / {V650_BUILD_LABEL}', f'- 접수지연: {recv_delay:.2f}s / 처리합계: {total_sec:.2f}s', '', '[명령 처리시간]']
    for t in timings:
        lines.append(f"- {'✅' if not t.get('error') else '❌'} /{t.get('name','?')}: {float(t.get('sec') or 0):.2f}s / {'OK' if not t.get('error') else 'ERR'}")
    lines += ['', '[전체 요약]', _v650_safe_body(outputs.get('batch') or _v799_batch_text(), 3200), '']
    lines += _v799_trade_detail_lines_range(since_ts, batch_until)
    lines += ['', '[명령별 상세]']
    for name in cmds:
        lines += ['', f'/{name}', _v650_safe_body(outputs.get(name,''), 1700)]
    return '\n'.join(lines)


def _v650_send_summary_file(update: Any, text: str) -> str:
    path = BASE_DIR / f"coinbot_batch_summary_{time.strftime('%Y%m%d_%H%M%S')}.txt"
    sent=False
    try:
        path.write_text(text, encoding='utf-8')
        with path.open('rb') as fh:
            update.message.reply_document(document=fh, filename=path.name)
        sent=True
        try:
            _v798_save_batch_marker(float(globals().get('_V797_PENDING_BATCH_MARKER_TS') or now_ts()))
        except Exception as exc:
            log_error('v798_batch_marker_after_send', exc)
        return 'txt 전송완료 후 서버삭제'
    except Exception as exc:
        log_error('v652_batch_summary_send', exc)
        return f'txt 전송실패 {exc.__class__.__name__}'
    finally:
        if sent:
            try: path.unlink(missing_ok=True)
            except Exception as exc: log_error('v652_batch_summary_delete', exc)



# =============================================================================
# main_bot v2.13.490 / v674: real candidate board + fast handoff single-source display
# - main remains a cache consumer.  No candidate recalculation here.
# =============================================================================
def _v674_fast_handoff_visible_line() -> str:
    try:
        hpath = BASE_DIR / 'clean_fast_quality_paper_handoff_v674.json'
        obj = _v650_load(hpath, {}) or {}
        if not isinstance(obj, dict) or not obj:
            return '- 실제 handoff: cache 준비중'
        rows = obj.get('rows') if isinstance(obj.get('rows'), list) else []
        tops=[]
        for r in rows[:5]:
            if not isinstance(r, dict):
                continue
            tops.append(f"{r.get('ticker')} {r.get('stage')} Q{float(r.get('q') or 0):.1f} R{float(r.get('risk') or 0):.1f} gap {float(r.get('gap') or 0):+.2f}%")
        return f"- 실제 handoff: age {_v650_file_age(hpath):.1f}s / rows {obj.get('actual_handoff_count',0)} / " + (' / '.join(tops) if tops else '-')
    except Exception as exc:
        log_error('v674_fast_handoff_visible_line', exc)
        return '- 실제 handoff: 읽기 실패'

_v674_prev_fast_quality_visible_block = _v673_fast_quality_visible_block

def _v673_fast_quality_visible_block() -> str:  # type: ignore[override]
    txt = _v674_prev_fast_quality_visible_block()
    lines = str(txt or '').split('\n')
    # Rename block label while keeping existing content.
    if lines and '[고품질 빠른진입 paper 실험' in lines[0]:
        lines[0] = '[고품질 빠른진입 paper 실험 · v674]'
    insert_at = 1 if len(lines) > 1 else len(lines)
    lines.insert(insert_at, _v674_fast_handoff_visible_line())
    # Append raw/filter counters if paper_bot exposed them.
    try:
        hand = _v650_load(FILES.get('paperbot_handoff', BASE_DIR/'paper_bot_candidate_handoff_status.json'), {}) or {}
        pst = _v650_load(FILES.get('paper_status', BASE_DIR/'paper_bot_status.json'), {}) or {}
        pick = {}
        for src in (pst, hand):
            ps = src.get('pick_stats') if isinstance(src, dict) and isinstance(src.get('pick_stats'), dict) else {}
            if isinstance(ps, dict): pick.update(ps)
        raw = pick.get('fast_quality_paper_raw_rows')
        filt = pick.get('fast_quality_paper_filtered_rows')
        if raw is not None or filt is not None:
            lines.append(f"- paper latest 실제필터: raw_fast {raw or 0} / filtered_fast {filt or 0}")
    except Exception as exc:
        log_error('v674_fast_filter_stats_visible', exc)
    return '\n'.join(lines)


def _v674_short_reason(v: Any, max_len: int = 36) -> str:
    if isinstance(v, list):
        txt = ','.join(str(x) for x in v[:3])
    else:
        txt = str(v or '-')
    return txt if len(txt) <= max_len else txt[:max_len-1] + '…'

def _v674_miss_row_line(r: Dict[str, Any]) -> str:
    return (f"- {r.get('ticker','-')} {r.get('initial_stage','-')} "
            f"max {float(r.get('max_pct') or 0):+.2f}% / cur {float(r.get('current_pct') or 0):+.2f}% "
            f"/ {r.get('miss_bucket','-')} / Q{float(r.get('q') or r.get('quality') or 0):.1f} R{float(r.get('risk') or 0):.1f} "
            f"/ 이유 {_v674_short_reason(r.get('initial_reason') or r.get('reject_reason') or r.get('block_reason'))}")

def _v674_condition_suggestion(obj: Dict[str, Any]) -> List[str]:
    buckets = obj.get('miss_bucket_counts') if isinstance(obj.get('miss_bucket_counts'), dict) else {}
    true_n = int(obj.get('true_missed_count') or 0)
    rise_n = int(obj.get('rise_count') or 0)
    lines = ['[조건 수정 후보 · v674]']
    if not buckets:
        lines.append('- 결과 부족: market miss review cache가 아직 비어 있음')
        return lines
    cov = int(buckets.get('coverage_buried',0)); feat = int(buckets.get('feature_late',0)); of = int(buckets.get('orderflow_late',0)); trig = int(buckets.get('trigger_wait_missed',0))
    lines.append(f"- 근거: 상승후보 {rise_n} / 진짜놓침 {true_n} / coverage {cov} / feature {feat} / orderflow {of} / trigger {trig}")
    if cov:
        lines.append('- coverage_buried 상승이 많음 → coverage rescue/S2 재확인 기준 후보. 단, 위험태그 낮은 종목만')
    if feat:
        lines.append('- feature_late 상승 존재 → feature urgent 배차 강화 후보')
    if of:
        lines.append('- orderflow_late 상승 존재 → micro/orderflow urgent 강화 후보')
    if trig:
        lines.append('- trigger_wait_missed 상승 존재 → trigger gap/near 진입은 별도 paper로 비교 후보')
    lines.append('- 실제 조건값 자동 변경 없음. 이 표 보고 다음 판에서 승인 후 수치 조정')
    return lines

def _v674_missed_candidates_text() -> str:
    try:
        obj = _v650_load(BASE_DIR/'clean_market_miss_review_v667.json', {}) or {}
        hand = _v650_load(BASE_DIR/'clean_fast_quality_paper_handoff_v674.json', {}) or {}
        if not isinstance(obj, dict): obj = {}
        lines = ['🧭 놓친 후보판 /missed_candidates · v675', '- 기준: review_worker 사후검증 cache만 읽음. main 재계산 없음.']
        lines.append(f"- tracking {obj.get('tracking_total',0)} / matured {obj.get('matured_count',0)} / 상승후보 {obj.get('rise_count',0)} / 진짜놓침 {obj.get('true_missed_count',0)}")
        buckets = obj.get('miss_bucket_counts') if isinstance(obj.get('miss_bucket_counts'), dict) else {}
        lines.append('- 분류 TOP: ' + (' / '.join(f'{k} {v}' for k,v in Counter(buckets).most_common(8)) if buckets else '-'))
        true_rows = obj.get('true_missed_top') if isinstance(obj.get('true_missed_top'), list) else []
        rise_rows = obj.get('top_risers') if isinstance(obj.get('top_risers'), list) else []
        lines += ['', '[진짜놓침 TOP]']
        lines += [_v674_miss_row_line(r) for r in true_rows[:10] if isinstance(r, dict)] or ['- 없음']
        lines += ['', '[아까운상승 TOP]']
        lines += [_v674_miss_row_line(r) for r in rise_rows[:10] if isinstance(r, dict)] or ['- 없음']
        # Bucket-specific top groups.
        for bucket, title in [('coverage_buried','coverage에 묻힌 상승'),('feature_late','feature 늦은 상승'),('orderflow_late','체결/orderflow 늦은 상승'),('risk_filter_candidate','위험필터 후보 상승')]:
            rows = [r for r in rise_rows if isinstance(r, dict) and str(r.get('miss_bucket')) == bucket]
            lines += ['', f'[{title}]']
            lines += [_v674_miss_row_line(r) for r in rows[:6]] or ['- 없음']
        hrows = hand.get('rows') if isinstance(hand, dict) and isinstance(hand.get('rows'), list) else []
        lines += ['', '[fast accepted 실제 handoff]']
        if hrows:
            for r in hrows[:8]:
                lines.append(f"- {r.get('ticker')} {r.get('stage')} Q{float(r.get('q') or 0):.1f} R{float(r.get('risk') or 0):.1f} gap {float(r.get('gap') or 0):+.2f}% / scan {r.get('scan_id','-')}")
        else:
            lines.append('- 없음')
        lines += ['', *_v674_condition_suggestion(obj)]
        return '\n'.join(lines)
    except Exception as exc:
        log_error('v674_missed_candidates_text', exc)
        return f'🧭 놓친 후보판 /missed_candidates · v675\n❌ cache 읽기 실패: {exc.__class__.__name__}'



# =============================================================================
# main_bot v679: /score·/popen command registry owner restore
# - 기본 명령어는 paper_bot cache/status만 읽는다.
# - CLOSED 장부 직접조회/fallback 없이 paper_score_cache와 paper_open cache를 소비한다.
# - v678에서 COMMANDS 등록부에서 빠진 /score, /popen을 새 단일 등록부로 재연결한다.
# =============================================================================
def _v681_is_experiment_name(name: Any) -> bool:
    s = str(name or '').lower()
    return any(x in s for x in ('실험', 'experiment', 'fast_quality', 'paper_only', 'paper-only'))


def _v681_split_strategy_stats(score: Dict[str, Any]) -> Tuple[List[Tuple[str, Dict[str, Any]]], List[Tuple[str, Dict[str, Any]]]]:
    strat = score.get('today_strategy_stats') if isinstance(score.get('today_strategy_stats'), dict) else {}
    if not strat:
        strat = score.get('strategy_primary_stats') if isinstance(score.get('strategy_primary_stats'), dict) else (score.get('strategy_stats') if isinstance(score.get('strategy_stats'), dict) else {})
    official: List[Tuple[str, Dict[str, Any]]] = []
    exp: List[Tuple[str, Dict[str, Any]]] = []
    if isinstance(strat, dict):
        for name, st in strat.items():
            if not isinstance(st, dict):
                continue
            so = _v650_stat_obj(st)
            (exp if _v681_is_experiment_name(name) else official).append((str(name), so))
    official.sort(key=lambda x: (x[1].get('n',0), abs(float(x[1].get('total',0.0)))), reverse=True)
    exp.sort(key=lambda x: (x[1].get('n',0), abs(float(x[1].get('total',0.0)))), reverse=True)
    return official, exp


def _v681_experiment_open_count() -> int:
    n = 0
    for r in _v679_open_rows():
        if _v681_is_experiment_name(_v650_strategy(r)) or bool(r.get('paper_experiment_open')) or r.get('paper_experiment_lane'):
            n += 1
    return n



# main_bot v793: structure performance cache consumer
# - paper_bot score/review cache에 저장된 구조태그별 CLOSED 성과만 표시한다.
# - CLOSED 장부 직접조회/후보 재계산 없음.

def _v793_perf_stat_line(name: str, st: Dict[str, Any]) -> str:
    try:
        return f"- {name}: {int(st.get('n',0))}전 {int(st.get('wins',0))}승 {int(st.get('losses',0))}패 / 승률 {float(st.get('win_rate',0.0)):.1f}% / 합산 {float(st.get('total',0.0)):+.2f}% / 평균 {float(st.get('avg',0.0)):+.2f}%"
    except Exception:
        return f"- {name}: {st}"


def _v793_structure_performance_lines(score: Optional[Dict[str, Any]] = None, limit: int = 4) -> List[str]:
    score = score if isinstance(score, dict) else _v650_score()
    perf = score.get('structure_performance_v793') if isinstance(score.get('structure_performance_v793'), dict) else {}
    if not perf:
        review = _v650_review()
        perf = review.get('structure_performance_v793') if isinstance(review.get('structure_performance_v793'), dict) else {}
    lines = ['[구조태그별 CLOSED 성과 · v793]']
    if not isinstance(perf, dict) or not perf.get('closed_count'):
        return lines + ['- 구조태그 CLOSED 표본 대기 · paper_bot v0.788 cache 필요']
    lines.append(f"- CLOSED {perf.get('closed_count',0)}개 / 조건·청산 변경 없음")
    for title, key in (('좋은 구조', 'good_tag_stats'), ('실패 구조', 'failure_tag_stats'), ('실행위험', 'exec_risk_stats'), ('1분/3분 반응', 'post_entry_reaction_stats')):
        mp = perf.get(key) if isinstance(perf.get(key), dict) else {}
        lines.append(f'[{title}]')
        if mp:
            for name, st in list(mp.items())[:limit]:
                if isinstance(st, dict): lines.append(_v793_perf_stat_line(str(name), st))
        else:
            lines.append('- 표본 없음')
    wr = perf.get('weak_market_relative_strength_stats') if isinstance(perf.get('weak_market_relative_strength_stats'), dict) else {}
    if wr.get('n'):
        lines.append('[약장 상대강도]')
        lines.append(_v793_perf_stat_line('약장상대강도', wr))
    loss = perf.get('loss_similarity_top') if isinstance(perf.get('loss_similarity_top'), dict) else {}
    lines.append('[실패군 닮음] ' + (' / '.join(f'{k} {v}' for k, v in loss.items()) if loss else '표본 없음'))
    return lines

def _v679_score_text() -> str:
    score = _v650_score()
    review = _v650_review()
    lines = [
        '📊 성과 /score · v701 정식/실험/원천 분리',
        '- 기준: paper_bot score cache만 읽음. main_bot 장부 직접조회 없음.',
        '- 정식 S1 성과와 S2/S3 실험 lane을 분리 표시. 전체합산은 참고값.',
        f"- cache: score {score.get('schema','-')} / review {review.get('schema','-')}",
        '',
        '[기간별 전체합산 · 참고]',
        *_v651_score_window_lines(),
    ]
    grade = score.get('grade_stats') if isinstance(score.get('grade_stats'), dict) else {}
    if grade:
        lines += ['', '[등급별]']
        for k in ('S1','S2','S3','S','A','B','C','X','ALL'):
            if isinstance(grade.get(k), dict):
                lines.append(_v650_stat_line(k, _v650_stat_obj(grade.get(k))))
    official, exp = _v681_split_strategy_stats(score)
    lines += ['', '[정식/비실험 전략 성과]']
    if official:
        for name, so in official[:10]:
            lines.append(_v650_stat_line(name, so))
    else:
        lines.append('- 정식/비실험 전략 집계 없음')
    lines += ['', '[실험 lane 성과 · 자동매수/B​UY_READY 대상 아님]']
    if exp:
        for name, so in exp[:8]:
            lines.append(_v650_stat_line(name, so))
    else:
        lines.append('- 실험 lane 집계 없음')
    lines += ['', *_v793_structure_performance_lines(score, 4)]
    lines += ['', '[해석]']
    if exp and official:
        exp_total = sum(float(so.get('total',0.0)) for _, so in exp)
        off_total = sum(float(so.get('total',0.0)) for _, so in official)
        lines.append(f'- 정식/비실험 합산 {off_total:+.2f}% / 실험 lane 합산 {exp_total:+.2f}%')
        if exp_total < 0 and off_total >= 0:
            lines.append('- 전체 손실은 실험 lane 영향이 큼. 조건 수정 전 실험/정식 분리 판단 필요.')
    lines.append(f'- 현재 OPEN 중 실험 추정: {_v681_experiment_open_count()}개 / 전체 OPEN {_v650_open_count()}개')
    lines += ['', '- source owner: paper_bot_score_cache.json']
    return '\n'.join(lines)

# v741: legacy _v679_open_rows removed; final definition below uses _v680_paper_open_rows only.

def _v679_open_sort_ts(row: Dict[str, Any]) -> float:
    for k in ('opened_at','entry_ts','open_ts','created_at','ts'):
        v=row.get(k)
        try:
            f=float(str(v).replace(',',''))
            if f > 10_000_000_000: f /= 1000.0
            if f > 0: return f
        except Exception:
            pass
    return 0.0


def _v679_pos_price(row: Dict[str, Any], *keys: str) -> str:
    for k in keys:
        v=row.get(k)
        if v not in (None,''):
            try:
                f=float(str(v).replace(',',''))
                return f'{f:,.0f}' if f >= 1000 else f'{f:.4f}'
            except Exception:
                return str(v)
    return '-'


def _v679_pos_pnl(row: Dict[str, Any]) -> float:
    for k in ('pnl_pct','profit_pct','current_profit_pct','unrealized_pct'):
        if row.get(k) not in (None,''):
            return _v650_num(row.get(k), default=0.0)
    entry=_v650_num(row.get('entry_price'), row.get('entry'), default=0.0)
    cur=_v650_num(row.get('current_price'), row.get('last_price'), default=0.0)
    return ((cur-entry)/entry*100.0) if entry > 0 and cur > 0 else 0.0


def _v743_quarantine_count() -> int:
    rows = read_jsonl(BASE_DIR / "paper_bot_open_quarantine.jsonl", 500)
    return len(rows or [])


def _v679_popen_text() -> str:
    rows = _v679_open_rows()
    st = _v650_status()
    lines = ['📂 paper OPEN /popen · v754 캐시전용', '- 기준: paper_bot_open.json active OPEN만 읽음. quarantine은 별도 보존.']
    lines.append(f"- paper: {st.get('paper_version') or st.get('version') or '-'} / build {st.get('build','-')} / status age {_v650_file_age(FILES.get('paper_status', BASE_DIR/'paper_bot_status.json')):.1f}s")
    if not rows:
        return '\n'.join(lines + ['OPEN 없음'])
    normal=[]; legacy=[]; malformed=[]
    for r in rows:
        if not isinstance(r, dict):
            continue
        t=_v650_ticker(r)
        entry=_v679_pos_price(r, 'entry_price','entry')
        strat=_v650_strategy(r)
        price_num=_v650_num(r.get('entry_price'), r.get('entry'), default=0.0)
        if not t or t == "-" or price_num <= 0:
            malformed.append(r)
        elif str(r.get('paper_experiment_lane') or r.get('strategy_key') or strat).find('fast_quality') >= 0 or '고품질 빠른진입 paper 실험' in str(strat):
            legacy.append(r)
        else:
            normal.append(r)
    lines.append(f"- 정상 OPEN {len(normal)} / 구 실험 잔여 {len(legacy)} / 장부 이상 row {len(malformed)} / 격리누적 {_v743_quarantine_count()}")
    def _line(r: Dict[str, Any]) -> str:
        t=_v650_ticker(r)
        strat=_v650_strategy(r)
        pnl=_v679_pos_pnl(r)
        entry=_v679_pos_price(r, 'entry_price','entry')
        cur=_v679_pos_price(r, 'current_price','last_price','entry_price')
        reason=str(r.get('exit_watch') or r.get('reason') or r.get('entry_reason') or r.get('paper_entry_action') or '-')[:80]
        return f"- {t} / {strat} / 진입 {entry} → 현재 {cur} / {pnl:+.2f}% / {reason}"
    if normal:
        lines.append('[정상 OPEN]')
        lines.extend(_line(r) for r in normal[:8])
    if legacy:
        lines.append('[구 실험 잔여 · 신규 아님]')
        lines.extend(_line(r) for r in legacy[:6])
    if malformed:
        lines.append('[장부 이상 row · 삭제 안 함]')
        lines.extend(_line(r) for r in malformed[:4])
    return '\n'.join(lines)


# =============================================================================
# main_bot v681: exit/strategy review views
# - 조건/청산값을 변경하지 않고 paper_bot owner cache/trace만 읽는다.
# - 손절초과 해석과 전략별 문제판을 분리해 조건 수정 전 판독 가능하게 한다.
# =============================================================================
def _v681_read_jsonl_tail(path: Path, limit: int = 80) -> List[Dict[str, Any]]:
    rows: List[Dict[str, Any]] = []
    try:
        if not path.exists():
            return rows
        lines = path.read_text(encoding='utf-8', errors='ignore').splitlines()[-limit:]
        for ln in lines:
            if not ln.strip():
                continue
            try:
                obj = json.loads(ln)
                if isinstance(obj, dict):
                    rows.append(obj)
            except Exception:
                pass
    except Exception as exc:
        log_error('v681_read_jsonl_tail', exc)
    return rows


def _v681_stop_rows(limit: int = 80) -> List[Dict[str, Any]]:
    return _v681_read_jsonl_tail(BASE_DIR / 'paper_bot_stop_overrun_trace.jsonl', limit)


def _v681_stop_review_summary() -> Dict[str, Any]:
    rows = _v681_stop_rows(80)
    vals=[]; price_age=0; loop_gap=0; official=0; exp=0
    for r in rows:
        over = _v650_num(r.get('overrun_pct'), r.get('stop_overrun_pct'), r.get('extra_loss_pct'), default=0.0)
        if over == 0.0:
            pnl = _v650_num(r.get('pnl_pct'), r.get('profit_pct'), default=0.0)
            stop = _v650_num(r.get('stop_loss_pct'), r.get('stop_pct'), default=0.0)
            if pnl < stop:
                over = pnl - stop
        vals.append(over)
        if _v650_num(r.get('price_cache_age_sec'), r.get('price_age_sec'), r.get('live_price_age_sec'), default=0.0) >= 10.0:
            price_age += 1
        if _v650_num(r.get('position_update_gap_sec'), r.get('update_gap_sec'), r.get('loop_gap_sec'), default=0.0) >= 8.0:
            loop_gap += 1
        if _v681_is_experiment_name(_v650_strategy(r)) or r.get('paper_experiment_lane') or r.get('paper_experiment_open'):
            exp += 1
        else:
            official += 1
    return {
        'n': len(rows),
        'avg_overrun': (sum(vals)/len(vals) if vals else 0.0),
        'max_overrun': (min(vals) if vals else 0.0),
        'price_age_suspect': price_age,
        'loop_gap_suspect': loop_gap,
        'official': official,
        'experiment': exp,
    }


def _v681_stop_row_line(r: Dict[str, Any]) -> str:
    t = _v650_ticker(r)
    grade = str(r.get('grade') or r.get('candidate_grade') or r.get('stage') or '-')
    strat = _v650_strategy(r)
    pnl = _v650_num(r.get('pnl_pct'), r.get('profit_pct'), default=0.0)
    stop = _v650_num(r.get('stop_loss_pct'), r.get('stop_pct'), default=0.0)
    over = _v650_num(r.get('overrun_pct'), r.get('stop_overrun_pct'), r.get('extra_loss_pct'), default=0.0)
    if over == 0.0 and stop and pnl < stop:
        over = pnl - stop
    age_s = _v650_num(r.get('price_cache_age_sec'), r.get('price_age_sec'), r.get('live_price_age_sec'), default=0.0)
    gap_s = _v650_num(r.get('position_update_gap_sec'), r.get('update_gap_sec'), r.get('loop_gap_sec'), default=0.0)
    reason = str(r.get('exit_reason') or r.get('reason') or r.get('close_reason') or r.get('exit_type') or '-')
    lane = '실험' if (_v681_is_experiment_name(strat) or r.get('paper_experiment_lane') or r.get('paper_experiment_open')) else '정식'
    verdict=[]
    if age_s >= 10: verdict.append('가격age의심')
    if gap_s >= 8: verdict.append('루프gap의심')
    if not verdict: verdict.append('기준근처/체결변동')
    return f"- {t} / {lane} {grade} / {strat} / 기준 {stop:+.2f}% → 실제 {pnl:+.2f}% / 초과 {over:+.2f}% / age {age_s:.1f}s / gap {gap_s:.1f}s / {reason} / {'·'.join(verdict)}"


def _v681_stop_review_text() -> str:
    rows = _v681_stop_rows(80)
    summ = _v681_stop_review_summary()
    lines = [
        '🛑 손절 해석 /stop_review · v701',
        '- 기준: paper_bot_stop_overrun_trace.jsonl만 읽음. 손절/청산값 변경 없음.',
        f"- 최근 손절초과 {summ.get('n',0)}건 / 정식 {summ.get('official',0)} / 실험 {summ.get('experiment',0)}",
        f"- 평균 초과 {summ.get('avg_overrun',0.0):+.2f}% / 최대 초과 {summ.get('max_overrun',0.0):+.2f}% / 가격age의심 {summ.get('price_age_suspect',0)} / 루프gap의심 {summ.get('loop_gap_suspect',0)}",
    ]
    if not rows:
        lines += ['', '최근 상세', '- 손절초과 trace 없음']
        return '\n'.join(lines)
    lines += ['', '최근 상세']
    for r in rows[-12:][::-1]:
        lines.append(_v681_stop_row_line(r))
    lines += ['', '판독', '- 가격age/루프gap 의심이 많으면 손절선 문제가 아니라 가격갱신·청산루프 지연 문제부터 봅니다.']
    return '\n'.join(lines)


def _v681_strategy_review_text() -> str:
    score = _v650_score()
    official, exp = _v681_split_strategy_stats(score)
    lines = [
        '🧭 전략별 문제판 /strategy_review · v701',
        '- 기준: paper_bot score cache + worker cache 요약만 읽음. 조건값 재계산 없음.',
    ]
    lines += ['', '[정식/비실험 전략]']
    if official:
        for name, so in official[:8]:
            n = int(so.get('n',0)); total=float(so.get('total',0.0)); avg=float(so.get('avg',0.0))
            tag = '더보기' if total > 0 else ('주의' if n < 10 else '개선필요')
            lines.append(f"- {tag}: {_v650_stat_line(name, so)}")
    else:
        lines.append('- 정식/비실험 전략 집계 없음')
    lines += ['', '[실험 lane]']
    if exp:
        for name, so in exp[:8]:
            n = int(so.get('n',0)); total=float(so.get('total',0.0)); avg=float(so.get('avg',0.0))
            if n >= 30 and total < 0:
                tag = '중지/폐기검토'
            elif total > 0:
                tag = '관찰가치'
            else:
                tag = '표본대기'
            lines.append(f"- {tag}: {_v650_stat_line(name, so)}")
    else:
        lines.append('- 실험 lane 집계 없음')
    try:
        snap = _v650_candidate_snapshot()
        lines += ['', '[현재 후보 막힘 TOP]', f"- S1 막힘: {_v650_counter_line(snap.get('reasons'), 5)}", f"- 위험: {_v650_counter_line(snap.get('risks'), 5)}"]
    except Exception:
        pass
    lines += ['', *_v793_structure_performance_lines(score, 3)]
    summ = _v681_stop_review_summary()
    lines += ['', '[손절/운영 참고]', f"- 손절초과 {summ.get('n',0)}건 / 가격age의심 {summ.get('price_age_suspect',0)} / 루프gap의심 {summ.get('loop_gap_suspect',0)}"]
    lines += ['', '판독', '- 전략 조건을 바꾸기 전, 실험 lane 성과와 정식 S1 성과를 분리해서 봅니다.']
    return '\n'.join(lines)

def _v682_menu_text() -> str:
    return "\n".join([
        "🧭 코인봇 명령어 메뉴 /menu · v701",
        "- 목표: 평소 확인용 / 이상시 확인용 / 개발·상세용을 분리합니다.",
        "",
        "[평소 5개만 보면 됨]",
        "- /health: worker/cache age, CPU·메모리·디스크, cleanup 보존/삭제 정책",
        "- /score: 정식 S1 성과와 S2/S3 실험 성과 분리",
        "- /stop_review: 손절이 기준대로 닫혔는지, 루프gap/가격age 원인 확인",
        "- /strategy_review: 전략별 폐기·관찰·더보기 판단",
        "- /errorlog: 새 오류 확인",
        "",
        "[이상할 때]",
        "- /pstatus: paper_bot 내부 상태와 fast paper 수신",
        "- /popen: 현재 OPEN 목록",
        "- /candidate_reason: 왜 S1이 안 나오는지",
        "- /paper_handoff: strategy_worker → paper_bot 전달 상태",
        "",
        "[개발·상세]",
        "- /version_score: 버전 기준 성과",
        "- /missed_candidates: 놓친 후보 사후검증",
        "- /condition_review: 조건 역할/태그 상세",
        "",
        "[표시 기준]",
        "- 전체 456개는 가볍게 감시합니다. 단, coverage/raw는 실전후보 S3로 보지 않습니다.",
        "- 손절은 OPEN만 빠르게 보는 paper_bot 우선 루프가 주인입니다.",
    ])



# v736 early-safe feature map function.
# This must exist before COMMANDS/alias registration because Python executes top-down.
def _v701_feature_map_text() -> str:
    return "\n".join([
        "🧩 코인봇 기능 지도 /feature_map · v746",
        "- 목적: worker 역할과 결과 흐름을 확인하는 지도입니다.",
        "",
        "[정보 생산 직원]",
        "- scanner_worker: KRW 전체시장 스캔, hot-rank, 거래대금/변동 감지",
        "- feature_worker/candle_worker: 가격반응, 1m/3m/5m, VWAP/EMA, 구조선 재료",
        "- orderflow/micro/WS: 호가, 체결, 스프레드, 미끄러짐, 최신가격",
        "- target_router: S1근접/S2/OPEN/정보부족/급등 후보 우선순위 배차",
        "",
        "[판단 공장]",
        "- strategy_worker: worker cache를 모아 canonical row 봉인, S1/S2/S3/coverage 분류",
        "- review_worker: 놓친 후보, 아까운 상승, 버린 게 맞았던 후보 사후검증",
        "",
        "[실행 공장]",
        "- paper_bot: OPEN/CLOSED 실행, 구조계획 매매상세 cache, score/review cache, cleanup/raw pack",
        "",
        "[허브]",
        "- main_bot: 명령어, 상태판, 요약집 txt 전송/삭제 trace. 장부 직접계산 없음",
        "",
        "[이식 금지]",
        "- tail wrapper, fallback reader, 출력부 보정, alert_trace 과다복구, 중복 writer/reader",
    ])

COMMANDS = {
    'menu': _v682_menu_text, 'help': _v682_menu_text,
    'batch': _v650_batch_text,
    'health': _v650_health_text, 'core': _v650_health_text,
    'version_score': _v650_version_score_text, 'vscore': _v650_version_score_text,
    'score': _v679_score_text, 'pscore': _v679_score_text,
    'candidate_reason': _v650_candidate_reason_text, 'reason': _v650_candidate_reason_text, 'why_s1': _v650_candidate_reason_text,
    'missed_candidates': _v674_missed_candidates_text, 'missed': _v674_missed_candidates_text,
    'condition_review': _v650_condition_review_text, 'condition': _v650_condition_review_text,
    'paper_handoff': _v650_paper_handoff_text, 'handoff': _v650_paper_handoff_text,
    'pstatus': _v650_pstatus_text, 'status': _v650_pstatus_text,
    'popen': _v679_popen_text, 'open': _v679_popen_text,
    'trade_review': _v650_trade_review_text, 'review': _v650_trade_review_text,
    'stop_review': _v681_stop_review_text, 'exit_review': _v681_stop_review_text,
    'strategy_review': _v681_strategy_review_text, 'sreview': _v681_strategy_review_text,
    'errorlog': _v650_errorlog_text,
}

# v736 guard/main compatibility aliases.
# These aliases only point to existing full-flow command functions.
COMMANDS.setdefault('trade', COMMANDS.get('pstatus'))
COMMANDS.setdefault('quality', COMMANDS.get('candidate_reason'))
COMMANDS.setdefault('deploy', COMMANDS.get('health'))
COMMANDS.setdefault('upgradestatus', COMMANDS.get('health'))
COMMANDS.setdefault('retention', COMMANDS.get('health'))


COMMANDS.setdefault('feature_map', _v701_feature_map_text)
COMMANDS.setdefault('guide', _v701_feature_map_text)
COMMANDS.setdefault('map', _v701_feature_map_text)

def _v743_hourly_summary_text() -> str:
    try:
        return "\n".join(["🕐 1시간 요약 /hourly_summary · v746", *_v650_hourly_lines()])
    except Exception:
        return "🕐 1시간 요약 /hourly_summary · v746\n- hourly cache 확인 필요"
COMMANDS.setdefault('pbatch', COMMANDS.get('pstatus'))
COMMANDS.setdefault('summary', COMMANDS.get('batch'))
COMMANDS.setdefault('hourly_summary', _v743_hourly_summary_text)
# 호환용 이름도 단일 본선으로 재지정한다.
health_text = _v650_health_text
version_score_text = _v650_version_score_text
candidate_reason_text = _v650_candidate_reason_text
pstatus_text = _v650_pstatus_text
paper_handoff_text = _v650_paper_handoff_text
trade_review_text = _v650_trade_review_text
errorlog_text = _v650_errorlog_text


def batch_handler(update, context):  # type: ignore[override]
    try:
        msg_date=getattr(getattr(update,'message',None),'date',None)
        recv_delay = time.time() - msg_date.timestamp() if hasattr(msg_date,'timestamp') else 0.0
    except Exception:
        recv_delay = 0.0
    default_cmds=['batch','reason','gate_check','score','health','errorlog','menu']
    cmds = getattr(context, 'args', None) or default_cmds
    cmds = [str(x).strip().lstrip('/') for x in cmds[:8] if str(x).strip()]
    stime=time.time(); timings=[]; outputs={}
    try: send(update, f'📦 자동 묶음 확인 · v661\n- 실행 {len(cmds)}개 / 접수지연 {recv_delay:.2f}s\n- worker 후보품질 text cache 소비 / score-review same rows 표시')
    except Exception: pass
    for i,name in enumerate(cmds,1):
        fn=COMMANDS.get(name); t0=time.time(); err=None
        if not fn:
            body=f'❌ /{name} 연결 없음'; err='no_handler'
        else:
            try: body=fn()
            except Exception as exc:
                body=f'❌ /{name} 오류 {exc.__class__.__name__}: {exc}'; err=f'{exc.__class__.__name__}: {exc}'; log_error(f'v650_batch_{name}', exc)
        sec=time.time()-t0; outputs[name]=body; timings.append({'name':name,'sec':sec,'error':err})
        try: send(update, f'[{i}/{len(cmds)}] /{name} ({sec:.2f}s / {"OK" if not err else "ERR"})\n{body}')
        except Exception as exc: log_error('v650_batch_send_step', exc)
    total=time.time()-stime
    try:
        status=_v650_send_summary_file(update, _v650_batch_summary_text(cmds, outputs, timings, recv_delay, total))
    except Exception as exc:
        status=f'txt 생성실패 {exc.__class__.__name__}'; log_error('v652_batch_summary_file', exc)
    mark='✅' if '전송완료' in status else '⚠️'
    del_mark='✅' if '서버삭제' in status else ('❌' if '전송완료' in status else '❔')
    try: send(update, f'📎 묶음 요약집\n- 전송: {mark} {status}\n- 임시파일 삭제: {del_mark}\n- 처리합계: {total:.2f}s')
    except Exception: pass


def make_handler(name: str):  # type: ignore[override]
    def h(update, context):
        try:
            txt=getattr(update.message,'text','') or ''
            lines=[x.strip().lstrip('/') for x in txt.splitlines() if x.strip().startswith('/')]
            if len(lines)>=2:
                context.args=lines[:8]
                return batch_handler(update, context)
            fn=COMMANDS.get(name)
            send(update, fn() if fn else f'❌ /{name} 연결 없음')
        except Exception as exc:
            log_error(f'cmd_{name}', exc); send(update, f'❌ /{name} 오류: {exc.__class__.__name__}: {exc}')
    return h


def text_router(update, context):  # type: ignore[override]
    try:
        txt=getattr(update.message,'text','') or ''
        lines=[x.strip().lstrip('/') for x in txt.splitlines() if x.strip().startswith('/')]
        if len(lines)>=2:
            context.args=lines[:8]
            return batch_handler(update, context)
    except Exception as exc:
        log_error('v652_text_router', exc)


def set_commands(updater):  # type: ignore[override]
    try:
        updater.bot.set_my_commands([
            BotCommand('batch','핵심 상태 묶음'), BotCommand('health','시스템 상태'),
            BotCommand('version_score','성과판'), BotCommand('score','전략 성과'), BotCommand('classify','분류판'), BotCommand('stop_review','손절 해석'), BotCommand('strategy_review','전략 문제판'),
            BotCommand('candidate_reason','S1 못 가는 이유'), BotCommand('missed_candidates','놓친 후보판'), BotCommand('condition_review','조건 역할 상세'),
            BotCommand('paper_handoff','paper 전달 상태'), BotCommand('pstatus','paper 상태'), BotCommand('popen','paper OPEN'),
            BotCommand('errorlog','오류 로그')])
    except Exception as exc:
        log_error('v652_set_commands', exc)


log_runtime('v654_score_review_same_rows_loaded')


def main():
    log_runtime(f'telegram_state=initializing version={BOT_VERSION} build={V650_BUILD_LABEL}')
    update_brain_status('initializing')
    if not TELEGRAM_TOKEN:
        print('TELEGRAM_TOKEN missing; worker hub status only')
        while True:
            update_brain_status('running_no_telegram'); time.sleep(5)
    updater = Updater(token=TELEGRAM_TOKEN, use_context=True)
    dp = updater.dispatcher
    for name in COMMANDS:
        if not re.match(r'^[A-Za-z0-9_]+$', str(name)):
            log_runtime(f'skip_invalid_command={name}')
            continue
        dp.add_handler(CommandHandler(name, make_handler(name)))
    dp.add_handler(CommandHandler('batch', batch_handler))
    if MessageHandler is not None and Filters is not None:
        dp.add_handler(MessageHandler(Filters.text & (~Filters.command), text_router))
    set_commands(updater)
    update_brain_status('running')
    threading.Thread(target=heartbeat_loop, daemon=True).start()
    updater.start_polling(drop_pending_updates=True)
    try:
        if CHAT_ID:
            updater.bot.send_message(chat_id=CHAT_ID, text=f'✅ 메인봇 시작 완료\n- 버전: {BOT_VERSION}\n- build: {V650_BUILD_LABEL}\n- 명령: /commands /batch /health /cleanup_status /issue_ledger /paper_gate_audit /errorlog')
    except Exception as exc:
        log_error('v650_startup_notify', exc)
    log_runtime(f'{BOT_VERSION} telegram polling_started build={V650_BUILD_LABEL}')
    updater.idle()


# =============================================================================
# main_bot v675: missed candidate value display + info priority summary
# - main still reads worker caches only.
# - Show Q/R aliases and enough trigger/execution fields when review_worker provides them.
# =============================================================================
def _v675_miss_row_line(r: Dict[str, Any]) -> str:
    q = _v650_num(r.get('q'), r.get('quality'), r.get('coin_quality_score'), default=0.0)
    risk = _v650_num(r.get('risk'), r.get('execution_risk_score'), default=0.0)
    gap = r.get('trigger_gap_pct')
    gap_txt = f" / gap {float(gap):+.2f}%" if gap not in (None, '', '-') else ''
    exec_bits=[]
    for label,k in (('체결','buy_ratio'),('지속','buy_sustain_1m'),('스프','spread_pct'),('미끄','slippage_pct')):
        if r.get(k) not in (None,'','-'):
            try: exec_bits.append(f"{label} {float(r.get(k)):.2f}")
            except Exception: pass
    exec_txt = (' / ' + ', '.join(exec_bits[:4])) if exec_bits else ''
    return (f"- {r.get('ticker','-')} {r.get('initial_stage','-')} "
            f"max {float(r.get('max_pct') or 0):+.2f}% / cur {float(r.get('current_pct') or 0):+.2f}% "
            f"/ {r.get('miss_bucket','-')} / Q{q:.1f} R{risk:.1f}{gap_txt}{exec_txt} "
            f"/ 이유 {_v674_short_reason(r.get('initial_reason') or r.get('reject_reason') or r.get('block_reason'))}")

def _v674_miss_row_line(r: Dict[str, Any]) -> str:  # type: ignore[override]
    return _v675_miss_row_line(r)


# =============================================================================
# main_bot v676: display near-trigger/info-priority owner state from worker caches only
# =============================================================================
def _v676_info_priority_block() -> str:
    try:
        obj = _v650_load(BASE_DIR/'clean_info_priority_summary_v676.json', {}) or _v650_load(BASE_DIR/'clean_info_priority_summary_v675.json', {}) or {}
        router = _v650_load(BASE_DIR/'clean_target_router_status.json', {}) or {}
        lines=['[정보 우선순위 재수집 · v676]']
        if not isinstance(obj, dict) or not obj:
            lines.append('- cache 준비중: strategy_worker priority summary 없음')
            return '\n'.join(lines)
        age = _v650_file_age(BASE_DIR/'clean_info_priority_summary_v676.json') if (BASE_DIR/'clean_info_priority_summary_v676.json').exists() else _v650_file_age(BASE_DIR/'clean_info_priority_summary_v675.json')
        lines.append(f"- 요청 cache age {age:.1f}s / 요청 {obj.get('request_count',0)} / router active {router.get('active_target_count', router.get('target_count','-'))} / v676 active {router.get('v676_info_priority_active_count','-')}")
        tc = obj.get('tier_counts') if isinstance(obj.get('tier_counts'), dict) else {}
        nc = obj.get('owner_need_counts') if isinstance(obj.get('owner_need_counts'), dict) else {}
        lines.append('- tier TOP: ' + (' / '.join(f'{k} {v}' for k,v in Counter(tc).most_common(6)) if tc else '-'))
        lines.append('- owner need TOP: ' + (' / '.join(f'{k} {v}' for k,v in Counter(nc).most_common(6)) if nc else '-'))
        top = obj.get('top') if isinstance(obj.get('top'), list) else []
        if top:
            parts=[]
            for r in top[:5]:
                if isinstance(r, dict):
                    parts.append(f"{r.get('ticker')} {r.get('tier','-')} Q{float(r.get('coin_quality_score') or 0):.1f} R{float(r.get('execution_risk_score') or 0):.1f}")
            lines.append('- 요청 TOP: ' + (' / '.join(parts) if parts else '-'))
        lines.append('- 기준: feature/orderflow/candle 주인별 재수집 요청 표시. main은 계산하지 않음.')
        return '\n'.join(lines)
    except Exception as exc:
        log_error('v676_info_priority_block', exc)
        return '[정보 우선순위 재수집 · v676]\n- cache 읽기 실패'

_v676_prev_candidate_reason_text = _v650_candidate_reason_text

def _v650_candidate_reason_text() -> str:  # type: ignore[override]
    txt = _v676_prev_candidate_reason_text()
    if '[정보 우선순위 재수집 · v676]' in str(txt):
        return txt
    return str(txt).rstrip() + '\n' + _v676_info_priority_block()

candidate_reason_text = _v650_candidate_reason_text
try:
    COMMANDS['candidate_reason'] = _v650_candidate_reason_text
    COMMANDS['reason'] = _v650_candidate_reason_text
    COMMANDS['why_s1'] = _v650_candidate_reason_text
except Exception:
    pass




# main_bot v677: paper handoff filter owner marker only. main still reads cache, no recalculation.
def _v677_paper_handoff_filter_block() -> str:
    try:
        ps = _v650_load(BASE_DIR/'paper_bot_status.json', {}) or {}
        lines=['[paper handoff 필터 · v677]']
        lines.append(f"- paper build {ps.get('build','-')} / fast raw {ps.get('fast_quality_paper_raw_rows','-')} / filtered {ps.get('fast_quality_paper_filtered_rows','-')} / seen {ps.get('fast_quality_paper_seen','-')}")
        last = ps.get('last_fast_quality_paper_hold') or ps.get('last_fast_quality_paper_filtered') or ps.get('last_fast_quality_paper_raw')
        if isinstance(last, dict):
            lines.append(f"- 최근 fast: {last.get('ticker','-')} / {last.get('status','-')} / {last.get('reason','-')}")
        lines.append('- 기준: paper_bot이 실제 읽는 latest_scan_filter에 fast/near paper row를 보존. main 재계산 없음.')
        return '\n'.join(lines)
    except Exception as exc:
        log_error('v677_paper_handoff_filter_block', exc)
        return '[paper handoff 필터 · v677]\n- cache 읽기 실패'

_v677_prev_candidate_reason_text = candidate_reason_text

def candidate_reason_text() -> str:  # type: ignore[override]
    txt = _v677_prev_candidate_reason_text()
    if '[paper handoff 필터 · v677]' in str(txt):
        return txt
    return str(txt).rstrip() + '\n' + _v677_paper_handoff_filter_block()


# =============================================================================
# main_bot v680: paper OPEN reader count owner fix
# - /pstatus 0 vs /popen N was not a runtime-cache split.
# - Root cause: _v650_open_count treated dict-shaped paper_bot_open.json as
#   a summary object and returned open_count/count, so a position-map dict became 0.
# - One reader shape is used for /pstatus, /paper_handoff and /popen.
# - main still reads cache only. No ledger scan, no condition recalculation.
# =============================================================================
def _v680_paper_open_rows() -> List[Dict[str, Any]]:
    obj = _v650_load(FILES.get('paper_open', BASE_DIR/'paper_bot_open.json'), {})
    rows: List[Dict[str, Any]] = []
    if isinstance(obj, list):
        rows = [x for x in obj if isinstance(x, dict)]
    elif isinstance(obj, dict):
        for k in ('rows','positions','open','OPEN'):
            v = obj.get(k)
            if isinstance(v, list):
                rows = [x for x in v if isinstance(x, dict)]
                break
            if isinstance(v, dict):
                rows = [x for x in v.values() if isinstance(x, dict)]
                break
        if not rows:
            # paper_bot_open.json canonical shape is a position-map dict:
            # {pos_id: position_dict, ...}.  Summary keys are ignored.
            summary_keys = {'open_count','count','updated_at','updated_at_text','schema','version','build'}
            rows = [x for k, x in obj.items() if k not in summary_keys and isinstance(x, dict)]
    return rows



# v741: legacy _v650_open_count definition removed; canonical version is after _v680_paper_open_rows.


def _v650_open_count() -> int:  # type: ignore[override]
    # v741: /batch, /health, /popen all count the same active OPEN rows.
    return len(_v680_paper_open_rows())


def _v679_open_rows() -> List[Dict[str, Any]]:  # type: ignore[override]
    return _v680_paper_open_rows()


_v680_prev_hourly_lines = _v650_hourly_lines

def _v650_hourly_lines() -> List[str]:  # type: ignore[override]
    """Read paper-owned hourly traces, preferring a sealed delete state.

    This does not invent a display value.  If the trace file is still an old
    pre-delete schema, use the paper_bot_status embedded owner trace when it
    already contains temp_deleted/deleted from the paper owner.
    """
    try:
        st = _v650_status()
        h = _v653_load_trace_file('paper_bot_hourly_summary_trace.json') or (st.get('paper_hourly_summary_trace') if isinstance(st.get('paper_hourly_summary_trace'), dict) else {})
        raw_file = _v653_load_trace_file('paper_bot_hourly_raw_pack_trace.json') or {}
        raw_status = st.get('paper_hourly_raw_pack_trace') if isinstance(st.get('paper_hourly_raw_pack_trace'), dict) else {}
        raw = raw_file if isinstance(raw_file, dict) and raw_file else (raw_status if isinstance(raw_status, dict) else {})
        if isinstance(raw, dict) and isinstance(raw_status, dict):
            # Owner trace in status may be newer than an old file trace.  Copy only
            # delete-owner fields; do not fabricate success/failure in main.
            for k in ('temp_deleted','deleted','delete_error','raw_delete_owner','result','updated_at','updated_at_text'):
                if raw.get(k) in (None, '', '❔') and raw_status.get(k) not in (None, '', '❔'):
                    raw[k] = raw_status.get(k)

        def _target_ok(obj: Dict[str, Any], key: str) -> str:
            if key == 'paper':
                for k in ('paper_sent_ok','paper_ok','paper_sent','paper_room'):
                    if k in obj: return _v653_ok(obj.get(k))
            if key == 'main':
                for k in ('main_sent_ok','main_ok','main_sent','main_room'):
                    if k in obj: return _v653_ok(obj.get(k))
            targets = obj.get('send_targets') or obj.get('targets')
            if isinstance(targets, dict):
                t = targets.get(key) or targets.get(key + '_room') or {}
                if isinstance(t, dict):
                    return _v653_ok(t.get('sent_ok') if 'sent_ok' in t else t.get('ok'))
            return '❔'

        def fmt(title: str, obj: Any) -> str:
            if not isinstance(obj, dict) or not obj:
                return f'- {title}: trace 없음'
            paper = _target_ok(obj, 'paper')
            main_room = _target_ok(obj, 'main')
            deleted = _v653_ok(obj.get('temp_deleted') if 'temp_deleted' in obj else obj.get('deleted') if 'deleted' in obj else obj.get('cleanup_ok'))
            ts = obj.get('updated_at_text') or obj.get('time') or obj.get('sent_at') or obj.get('created_at') or obj.get('ts') or '-'
            fn = obj.get('filename') or obj.get('file') or obj.get('path') or '-'
            result = obj.get('result') or obj.get('phase') or ''
            note = f' / {result}' if result else ''
            owner = f" / owner {obj.get('raw_delete_owner')}" if obj.get('raw_delete_owner') else ''
            return f'- {title}: paper방 {paper} / main방 {main_room} / 삭제 {deleted} / {ts} / {Path(str(fn)).name if fn else "-"}{note}{owner}'

        out = [fmt('1시간 요약 알림', h), fmt('원문 묶음', raw)]
        if out[1].endswith('trace 없음'):
            latest = _v652_latest_file('paper_hourly_raw_pack_*.txt')
            if latest is not None:
                out[1] = f'- 원문 묶음: 최근파일 {latest.name} / trace 없음 / age {_v650_file_age(latest):.1f}s'
        if all('trace 없음' in x for x in out):
            return ['- 1시간 요약 trace 없음 · paper_bot trace 파일 미생성']
        return out
    except Exception as exc:
        log_error('v680_hourly_lines', exc)
        return _v680_prev_hourly_lines()



# =============================================================================
# main_bot v701: clean spine usage map + safer stop/score interpretation
# - 새 기능 추가가 아니라 사용자가 볼 명령어 의미와 기능 주인을 고정한다.
# - 장부 직접조회 없음. paper score/status/trace cache만 읽는다.
# =============================================================================
def _v701_feature_map_text() -> str:
    return "\n".join([
        "🧩 코인봇 기능 지도 /feature_map · v701",
        "- 목적: 기능 삭제 금지와 찌꺼기 삭제를 구분하기 위한 지도입니다.",
        "",
        "[정보 생산 직원]",
        "- scanner_worker: KRW 전체시장 가벼운 스캔, hot-rank, 거래대금/변동 감지",
        "- feature_worker/candle_worker: 가격반응, 1m/3m/5m, VWAP/EMA, 구조선 재료",
        "- orderflow/micro/WS: 호가, 체결, 스프레드, 미끄러짐, 최신가격",
        "- target_router: S1근접/S2/OPEN/정보부족/급등 후보 우선순위 배차",
        "",
        "[판단 공장]",
        "- strategy_worker: worker cache를 모아 canonical row 봉인, S1/S2/S3/비후보 분류",
        "- review_worker: 놓친 후보, 아까운 상승, 버린 게 맞았던 후보 사후검증",
        "",
        "[실행 공장]",
        "- paper_bot: OPEN/CLOSED, 손절/익절/시간청산, trade_log, score cache, cleanup",
        "",
        "[허브]",
        "- main_bot: /health /score /stop_review /strategy_review 등 cache 표시만 담당",
        "",
        "[삭제 대상]",
        "- tail wrapper, fallback reader, 출력부 보정, alert_trace 과다복구, 중복 writer/reader",
    ])


def _v701_stop_lane(r: Dict[str, Any]) -> str:
    name = str(_v650_strategy(r) or '').strip()
    lane = str(r.get('paper_experiment_lane') or r.get('lane') or r.get('strategy_key') or '').strip()
    raw = r.get('raw') if isinstance(r.get('raw'), dict) else {}
    if _v681_is_experiment_name(name) or _v681_is_experiment_name(lane) or bool(r.get('paper_experiment_open')) or bool(r.get('paper_experiment_lane')):
        return '실험'
    if isinstance(raw, dict):
        raw_name = str(raw.get('strategy') or raw.get('strategy_name') or raw.get('strategy_key') or raw.get('paper_experiment_lane') or '')
        if _v681_is_experiment_name(raw_name):
            return '실험'
    if name and name not in ('-', 'unknown', 'legacy_unknown'):
        return '정식'
    return '미분류'


def _v681_stop_review_summary() -> Dict[str, Any]:  # type: ignore[override]
    rows = _v681_stop_rows(120)
    vals=[]; max_over=0.0; age_sus=0; gap_sus=0; exp=0; official=0; unknown=0
    for r in rows:
        over = _v650_num(r.get('overrun_pct'), default=0.0)
        vals.append(over)
        if over < max_over: max_over = over
        if _v650_num(r.get('price_cache_age_sec'), default=0.0) >= 10: age_sus += 1
        if _v650_num(r.get('position_update_gap_sec'), default=0.0) >= 10: gap_sus += 1
        lane = _v701_stop_lane(r)
        if lane == '실험': exp += 1
        elif lane == '정식': official += 1
        else: unknown += 1
    avg = sum(vals)/len(vals) if vals else 0.0
    return {'n':len(rows),'avg_overrun':round(avg,4),'max_overrun':round(max_over,4),'price_age_suspect':age_sus,'loop_gap_suspect':gap_sus,'experiment':exp,'official':official,'unknown':unknown}


def _v681_stop_row_line(r: Dict[str, Any]) -> str:  # type: ignore[override]
    t = _v650_ticker(r)
    pnl = _v650_num(r.get('pnl_pct'), default=0.0)
    stop = _v650_num(r.get('stop_loss_pct'), default=-0.55)
    over = _v650_num(r.get('overrun_pct'), default=pnl-stop)
    age = _v650_num(r.get('price_cache_age_sec'), default=0.0)
    gap = _v650_num(r.get('position_update_gap_sec'), default=0.0)
    reason = str(r.get('exit_reason') or r.get('exit_rule') or '-')
    lane = _v701_stop_lane(r)
    strat = _v650_strategy(r)
    flags=[]
    if age >= 10: flags.append('가격age의심')
    if gap >= 10: flags.append('루프gap의심')
    if lane == '미분류': flags.append('lane미분류')
    return f"- {t} / {lane} / {strat} / 기준 {stop:+.2f}% → 실제 {pnl:+.2f}% / 초과 {over:+.2f}% / age {age:.1f}s / gap {gap:.1f}s / {reason}" + (" / " + ",".join(flags) if flags else '')


def _v681_stop_review_text() -> str:  # type: ignore[override]
    rows = _v681_stop_rows(120)
    summ = _v681_stop_review_summary()
    lines = [
        '🛑 손절 해석 /stop_review · v701',
        '- 기준: paper_bot_stop_overrun_trace.jsonl만 읽음. 손절/청산값 변경 없음.',
        f"- 최근 손절초과 {summ.get('n',0)}건 / 정식 {summ.get('official',0)} / 실험 {summ.get('experiment',0)} / 미분류 {summ.get('unknown',0)}",
        f"- 평균 초과 {summ.get('avg_overrun',0.0):+.2f}% / 최대 초과 {summ.get('max_overrun',0.0):+.2f}% / 가격age의심 {summ.get('price_age_suspect',0)} / 루프gap의심 {summ.get('loop_gap_suspect',0)}",
        '', '최근 상세'
    ]
    if not rows:
        lines.append('- 손절초과 trace 없음')
    for r in rows[-12:][::-1]:
        lines.append(_v681_stop_row_line(r))
    lines += ['', '판독', '- 루프gap이 많으면 손절선 문제가 아니라 OPEN 청산검사 지연 문제입니다.', '- 미분류가 많으면 closed/alert trace에 strategy/lane 봉인이 빠진 것입니다.']
    return '\n'.join(lines)


# =============================================================================
# main_bot v736: gate scope check + original S1/S2/S3 flow display
# =============================================================================

def _v743_section(title: str) -> List[str]:
    return ["", title]

def _v743_stage_icon(stage: str) -> str:
    s = str(stage or "").upper()
    if s == "S1": return "🟢"
    if s == "S2": return "🟡"
    if s in ("S3", "S3_WATCH"): return "🔵"
    if s in ("X", "EXCLUDED", "차단"): return "🔴"
    return "⚪"

def _v743_label(x: Any) -> str:
    s = str(x or "").strip()
    if not s:
        return s
    reps = [
        ("coverage: base/spike 미통과", "전체시장 참고: 기본/전략 관찰 기준 전 단계"),
        ("coverage: base", "전체시장 참고: 기본 관찰 기준 전 단계"),
        ("spike 미통과", "급등초입전략: 급등 초입 기준 미통과"),
        ("전략조건 미충족·관찰 유지", "전략 조건 부족 · 관찰 유지"),
        ("전체시장 참고: 아직 S1/S2/S3 관찰 기준 전 단계", "전체시장 참고: 아직 후보 단계 전"),
        ("가격반응 +0.00%<+0.35%", "가격반응 없음/부족: +0.00% < +0.35%"),
        ("가격반응", "가격반응"),
        ("1분 매수지속 부족", "1분 매수 지속 부족"),
        ("재확인: 구조/확인신호 근접 S2 승격", "재확인 필요: 구조/확인신호가 S2 근처"),
        ("hot-rank 급등 재확인", "급등 감지 후 재확인"),
        ("coverage 관찰", "전체시장 참고 관찰"),
        ("구조선 근거 재확인", "차트 구조선 근거 재확인"),
        ("윗꼬리 저항 주의", "윗꼬리/저항 주의"),
        ("스프레드부담", "스프레드 부담"),
        ("미끄러짐부담", "예상 미끄러짐 부담"),
        ("매수체결약함", "매수 체결 약함"),
        ("hot-rank는 발견신호", "급등 알림은 발견 신호일 뿐"),
        ("무효선 계산선 의심", "무효선/계산선 의심"),
        ("feature_late", "차트/가격반응 정보 늦음"),
        ("orderflow_late", "호가·체결 정보 늦음"),
        ("risk_filter_candidate", "위험필터 재검토 후보"),
        ("coverage_buried", "전체시장 참고로 분류됨"),
        ("generic source는 구조확인 필요", "구조 근거가 모호함"),
        ("trigger_not_reached", "방아쇠 가격 미도달"),
        ("near_0_50", "방아쇠 0.50% 근처"),
        ("near_0_30", "방아쇠 0.30% 근처"),
        ("near_0_10", "방아쇠 0.10% 근처"),
        ("current_price", "현재가 기준"),
        ("resistance_break_line", "저항선 돌파 근거"),
        ("structure_levels_generic", "일반 구조선 근거"),
        ("vwap_ema_defense_rebreak", "VWAP/EMA 방어 후 재돌파"),
        ("box_break_line", "박스권 상단 돌파"),
        ("vwap_recovery_line", "VWAP 회복"),
        ("BUY_READY", "자동매수 준비"),
    ]
    out = s
    for a, b in reps:
        out = out.replace(a, b)
    return out

def _v743_ticker(r: Dict[str, Any]) -> str:
    for k in ("symbol","ticker","market","code"):
        v = r.get(k)
        if v:
            return str(v).replace("KRW-","").upper()
    return "-"

def _v743_num_from(r: Dict[str, Any], keys: List[str], default: float = 0.0) -> float:
    vals = [r.get(k) for k in keys]
    return _v650_num(*vals, default=default)

def _v743_counter_line(counter: Any, limit: int = 5) -> str:
    try:
        items = Counter(counter or {}).most_common(limit)
    except Exception:
        items = []
    if not items:
        return "없음"
    return " / ".join(f"{_v743_label(k)} {v}" for k, v in items if v) or "없음"

def _v743_short_counter(counter: Any, limit: int = 5) -> List[str]:
    try:
        items = Counter(counter or {}).most_common(limit)
    except Exception:
        items = []
    if not items:
        return ["- 없음"]
    return [f"{i}. {_v743_label(k)} · {v}" for i, (k, v) in enumerate(items, 1)]

def _v743_reason_short(r: Dict[str, Any], limit: int = 2) -> str:
    arr: List[str] = []
    try:
        arr += [str(x) for x in _v650_reasons(r)[:limit]]
    except Exception:
        pass
    if not arr:
        try:
            arr += [str(x) for x in _v650_risks(r)[:limit]]
        except Exception:
            pass
    if not arr:
        return "-"
    return " / ".join(_v743_label(x) for x in arr[:limit])

def _v743_coin_line(r: Dict[str, Any]) -> str:
    stage = _v650_stage(r)
    icon = _v743_stage_icon(stage)
    sym = _v743_ticker(r)
    strat = _v743_label(_v650_strategy(r))
    chg = _v743_num_from(r, ["change_1m_pct","price_chg_60s","price_1m_pct","chg_1m_pct"], 0.0)
    buy = _v743_num_from(r, ["buy_ratio","buy_trade_ratio","bid_ratio"], 0.0)
    sustain = _v743_num_from(r, ["buy_sustain","buy_sustain_1m","sustain"], 0.0)
    spread = _v743_num_from(r, ["spread_pct","spread"], 0.0)
    q = _v743_num_from(r, ["quality_score","Q","q","score"], 0.0)
    risk = _v743_num_from(r, ["risk_score","R","risk"], 0.0)
    reason = _v743_reason_short(r, 2)
    parts = [f"{icon} {sym} {stage}"]
    if q: parts.append(f"Q{q:.1f}")
    if risk: parts.append(f"R{risk:.1f}")
    parts.append(f"1분 {chg:+.2f}%")
    if buy: parts.append(f"체결 {buy:.2f}")
    if sustain: parts.append(f"지속 {sustain:.2f}")
    if spread: parts.append(f"스프 {spread:.2f}%")
    if strat and strat != "-": parts.append(strat)
    parts.append(reason)
    return "- " + " / ".join(parts)

def _v743_top_candidate_lines(limit: int = 8) -> List[str]:
    snap = _v650_candidate_snapshot()
    trade = [r for r in (snap.get("trade_rows") or []) if isinstance(r, dict)]
    order = {"S1": 0, "S2": 1, "S3": 2}
    trade.sort(key=lambda r: (order.get(_v650_stage(r), 9), -_v743_num_from(r, ["quality_score","Q","q","score"], 0.0), _v743_ticker(r)))
    if not trade:
        return ["- 실전후보 없음"]
    return [_v743_coin_line(r) for r in trade[:limit]]

def _v743_score_per_hour(label: str, st: Dict[str, Any], hours: float) -> str:
    st = _v650_stat_obj(st or {})
    n = int(st.get("n", 0) or 0)
    total = float(st.get("total", 0.0) or 0.0)
    avg = float(st.get("avg", total / n if n else 0.0) or 0.0)
    wins = int(st.get("wins", 0) or 0)
    losses = int(st.get("losses", max(0, n - wins)) or 0)
    ph = total / hours if hours > 0 else 0.0
    icon = "✅" if total > 0 else ("❌" if n and total < 0 else "❔")
    return f"{icon} {label}: {n}전 {wins}승 {losses}패 / 합산 {total:+.2f}% / 시간당 {ph:+.2f}% / 평균 {avg:+.2f}%"

def _v743_score_windows_lines() -> List[str]:
    w = _v651_score_windows()
    return [_v743_score_per_hour("3시간", w.get("r3", {}), 3), _v743_score_per_hour("6시간", w.get("r6", {}), 6), _v743_score_per_hour("24시간", w.get("r24", {}), 24)]

def _v743_grade_stat(score: Dict[str, Any], grade: str) -> Dict[str, Any]:
    g = score.get("grade_stats") if isinstance(score.get("grade_stats"), dict) else {}
    return _v650_stat_obj(g.get(grade) if isinstance(g.get(grade), dict) else {})

def _v743_candidate_label_lines(snap: Dict[str, Any]) -> List[str]:
    c = snap.get("counts") or Counter()
    all_c = snap.get("all_counts") if isinstance(snap.get("all_counts"), Counter) else Counter()
    coverage_n = len(snap.get("coverage_rows") or [])
    raw_s3 = int(all_c.get("S3", 0))
    return ["[후보 등급]", f"- 🟢 S1 실전 후보: {int(c.get('S1',0))}", f"- 🟡 S2 재확인 후보: {int(c.get('S2',0))}", f"- 🔵 S3 관찰 후보: {int(c.get('S3',0))}", "", "[전체시장 참고]", f"- ⚪ 참고 신호: {raw_s3}개", f"- ⚫ 비후보/기준미달: {coverage_n}개", "- 참고 신호는 후보가 아니라 전체시장 감시 흔적입니다."]

def _v743_gate_scope_check_lines() -> List[str]:
    ssum = _v650_load(BASE_DIR/'clean_strategy_s_summary.json', {}) or {}
    cov = ssum.get('v661_coverage_summary') if isinstance(ssum.get('v661_coverage_summary'), dict) else {}
    check = (cov.get('gate_scope_check_v736') or cov.get('gate_scope_check_v726')) if isinstance(cov, dict) else {}
    common = (cov.get('common_gate_reason_top_v736') or cov.get('common_gate_reason_top_v726') or {}) if isinstance(cov, dict) else {}
    strat = (cov.get('strategy_gate_reason_top_v736') or cov.get('strategy_gate_reason_top_v726') or {}) if isinstance(cov, dict) else {}
    observe = cov.get('s3_observe_reason_top_v736') if isinstance(cov.get('s3_observe_reason_top_v736'), dict) else {}
    s3_added = int(cov.get('s3_observe_added_count_v736') or 0) if isinstance(cov, dict) else 0
    coverage_left = int(cov.get('coverage_light_count_v736') or cov.get('coverage_light_count_v726') or 0) if isinstance(cov, dict) else 0
    leak = int(check.get('common_gate_spike_leak_count') or 0) if isinstance(check, dict) else 0
    ok = '✅' if leak == 0 and check else ('❔' if not check else '❌')
    return [
        f"- 급등초입 조건 공통누수: {ok} / 누수 {leak}건",
        f"- S3 관찰 복구: {s3_added}개 / 전체시장 참고 유지 {coverage_left}개",
        "- 공통 막힘 TOP: " + _v743_counter_line(common, 4),
        "- 전략별 미충족 TOP: " + _v743_counter_line(strat, 4),
        "- S3 관찰 사유 TOP: " + _v743_counter_line(observe, 4),
    ]





def _v743_pick_diag_dict(diag: Dict[str, Any], base: str, default: Any = None) -> Any:
    """Read the active strategy summary while strategy_worker remains v0.732.

    This is a display spine reader, not a recalculation path.
    """
    for ver in ("v737", "v736", "v735", "v734", "v733", "v732", "v731", "v730"):
        k = f"{base}_{ver}"
        if isinstance(diag, dict) and k in diag:
            return diag.get(k)
    return default


def _v743_s2_promotion_lines() -> List[str]:
    ssum = _v650_load(BASE_DIR / 'clean_strategy_s_summary.json', {}) or {}
    diag = ssum.get('s1_diagnostic') if isinstance(ssum.get('s1_diagnostic'), dict) else {}
    spine = _v743_pick_diag_dict(diag, 'promotion_stage_spine', None)
    if not isinstance(spine, dict):
        for ver in ("v737", "v736", "v735", "v734", "v733", "v732", "v731", "v730"):
            obj = ssum.get(f'promotion_stage_spine_{ver}') if isinstance(ssum, dict) else None
            if isinstance(obj, dict):
                spine = obj
                break
    if not isinstance(spine, dict):
        spine = {}

    promoted = int(_v743_pick_diag_dict(diag, 's2_to_s1_promoted_count', spine.get('effective_s1_promotions') or 0) or 0)
    blocked = int(_v743_pick_diag_dict(diag, 's2_to_s1_blocked_count', 0) or 0)
    common_target = int(_v743_pick_diag_dict(diag, 'common_uprising_target_count', 0) or 0)
    common_pass = int(_v743_pick_diag_dict(diag, 'common_uprising_pass_count', 0) or 0)
    effective = int(spine.get('effective_s1_promotions') or promoted or 0)
    s1_after = int(spine.get('s1_count_after_reseal') or 0)
    mismatch_before = int(spine.get('mismatch_before_reseal') or 0)
    forced_s3 = int(spine.get('forced_s3_observe_rows') or 0)

    common_block = _v743_pick_diag_dict(diag, 'common_uprising_block_top', {}) or {}
    reason_top = _v743_pick_diag_dict(diag, 'promotion_reason_top', {}) or {}
    blocked_top = _v743_pick_diag_dict(diag, 'promotion_blocked_top', {}) or {}
    fam_count = _v743_pick_diag_dict(diag, 'promotion_family_count', {}) or {}
    fam_promoted = _v743_pick_diag_dict(diag, 'promotion_family_promoted', {}) or {}
    fam_blocked = _v743_pick_diag_dict(diag, 'promotion_family_blocked', {}) or {}

    lines = [
        f"- 공통 상승포착: 대상 {common_target}개 / 통과 {common_pass}개",
        f"- stage 봉인: 실제 S1 {s1_after}개 / 유효승급 {effective}개 / 봉인전 불일치 {mismatch_before}개",
        f"- S3 관찰 재봉인: {forced_s3}개",
        "- 공통 차단 TOP: " + _v743_counter_line(common_block, 4),
        f"- S2→S1 승급: {promoted}개 / 승급금지 {blocked}개",
        "- 승급 사유 TOP: " + _v743_counter_line(reason_top, 3),
        "- 승급금지 TOP: " + _v743_counter_line(blocked_top, 4),
    ]
    if isinstance(fam_count, dict) and fam_count:
        lines.append("- 전략 라벨별 보조판:")
        order = ["주도흐름", "돈흐름", "저점VWAP", "돌파", "급등감지", "기타"]
        emitted = set()
        for fam in order:
            if fam in fam_count:
                total = int(fam_count.get(fam, 0) or 0)
                p = int(fam_promoted.get(fam, 0) or 0) if isinstance(fam_promoted, dict) else 0
                b = int(fam_blocked.get(fam, 0) or 0) if isinstance(fam_blocked, dict) else 0
                lines.append(f"  · {fam}: 대상 {total} / 승급 {p} / 금지 {b}")
                emitted.add(fam)
        for fam, total in Counter(fam_count).most_common(6):
            if fam in emitted:
                continue
            p = int(fam_promoted.get(fam, 0) or 0) if isinstance(fam_promoted, dict) else 0
            b = int(fam_blocked.get(fam, 0) or 0) if isinstance(fam_blocked, dict) else 0
            lines.append(f"  · {fam}: 대상 {int(total)} / 승급 {p} / 금지 {b}")
    else:
        lines.append("- 전략 라벨별 보조판: 준비중")
    return lines


def _v743_stop_recent_lines() -> List[str]:
    path = BASE_DIR / 'paper_bot_stop_overrun_trace.jsonl'
    total = 0
    recent30 = 0
    recent60 = 0
    nowv = time.time()
    try:
        if path.exists():
            data = path.read_text(encoding='utf-8', errors='ignore').splitlines()[-220:]
            total = len([x for x in data if x.strip()])
            for ln in data:
                try:
                    obj = json.loads(ln)
                except Exception:
                    continue
                ts = _v650_num(obj.get('ts'), obj.get('created_at'), obj.get('closed_ts'), obj.get('exit_ts'), default=0.0)
                if ts <= 0:
                    continue
                age = nowv - ts
                if age <= 1800:
                    recent30 += 1
                if age <= 3600:
                    recent60 += 1
    except Exception:
        pass
    return [
        f"- 손절초과: 최근30분 {recent30}건 / 최근60분 {recent60}건 / tail {total}건",
        "- 최근값이 계속 늘면 paper 청산검사 루프를 다음 수술 대상으로 봅니다.",
    ]


def _v743_s1_hold_obj() -> Dict[str, Any]:
    return _v650_load(BASE_DIR / "paper_s1_hold_cache.json", {}) or {}

def _v743_s1_hold_lines() -> List[str]:
    obj = _v743_s1_hold_obj()
    if not isinstance(obj, dict) or not obj:
        return ["- S1 hold: 준비중"]
    status = obj.get("status_counts") if isinstance(obj.get("status_counts"), dict) else {}
    rows = obj.get("rows") if isinstance(obj.get("rows"), list) else []
    sample = []
    for r in rows[:4]:
        if not isinstance(r, dict):
            continue
        t = _v650_ticker(r)
        st = str(r.get("s1_hold_status_v738") or r.get("s1_hold_status_v736") or r.get("s1_hold_status_v733") or r.get("s1_hold_status_v732") or "-")
        trig = r.get("trigger_gate_v738") if isinstance(r.get("trigger_gate_v738"), dict) else (r.get("trigger_gate_v736") if isinstance(r.get("trigger_gate_v736"), dict) else (r.get("trigger_gate_v733") if isinstance(r.get("trigger_gate_v733"), dict) else (r.get("trigger_gate_v732") if isinstance(r.get("trigger_gate_v732"), dict) else {})))
        gap = _v650_num(trig.get("trigger_gap_pct"), r.get("trigger_gap_pct"), default=0.0)
        sample.append(f"{t}:{st}/gap {gap:+.2f}%")
    return [
        f"- S1 hold: 전체 {int(obj.get('count') or 0)} / fresh {int(obj.get('fresh_count') or 0)} / stale {int(obj.get('stale_count') or 0)} / trigger대기 {int(obj.get('trigger_wait_count') or 0)} / open_ready {int(obj.get('open_ready_count') or 0)} / 만료정리 {int(obj.get('expired_pruned_count') or 0)}",
        "- hold 상태: " + (_v743_counter_line(status, 5) if status else "없음"),
        "- hold 샘플: " + (" / ".join(sample) if sample else "-"),
    ]

def _v743_paper_hold_trace_lines() -> List[str]:
    st = _v650_status()
    obj = st.get("hold_trace_summary_v746") if isinstance(st.get("hold_trace_summary_v746"), dict) else (st.get("hold_trace_summary_v743") if isinstance(st.get("hold_trace_summary_v743"), dict) else {})
    if not obj:
        h = _v743_s1_hold_obj()
        total = int(h.get("total", 0) or 0) if isinstance(h, dict) else 0
        if total <= 0:
            return ["- paper hold 소비 trace: 소비대상 없음"]
        return ["- paper hold 소비 trace: 준비중 · paper status summary 미봉인"]

    counts = obj.get("status_counts") if isinstance(obj.get("status_counts"), dict) else {}
    final_top = obj.get("final_hold_reason_top") if isinstance(obj.get("final_hold_reason_top"), dict) else {}
    expired_top = obj.get("expired_reason_top") if isinstance(obj.get("expired_reason_top"), dict) else {}
    preopen_top = obj.get("preopen_guard_top") if isinstance(obj.get("preopen_guard_top"), dict) else {}
    recent_rows = obj.get("recent_rows") if isinstance(obj.get("recent_rows"), dict) else {}

    def _c(label: str, limit: int = 6) -> str:
        d = counts.get(label) if isinstance(counts.get(label), dict) else {}
        return _v743_counter_line(d, limit) if d else "없음"

    lines = [
        f"- paper hold 소비 trace: cycle {_c('cycle')} / 60초 {_c('last60s')} / 5분 {_c('last5m')} / tail {_c('tail')}",
    ]

    f5 = final_top.get("last5m") if isinstance(final_top.get("last5m"), dict) else {}
    e5 = expired_top.get("last5m") if isinstance(expired_top.get("last5m"), dict) else {}
    p5 = preopen_top.get("last5m") if isinstance(preopen_top.get("last5m"), dict) else {}
    if f5:
        lines.append("- final_hold 사유 TOP(5분): " + _v743_counter_line(f5, 4))
    if e5:
        lines.append("- expired 사유 TOP(5분): " + _v743_counter_line(e5, 3))
    if p5:
        lines.append("- OPEN 직전 안전문 TOP(5분): " + _v743_counter_line(p5, 3))

    rr = recent_rows.get("last60s") if isinstance(recent_rows.get("last60s"), list) else []
    if rr:
        sample = []
        for r in rr[:4]:
            if not isinstance(r, dict):
                continue
            sample.append(f"{r.get('ticker') or '-'}:{r.get('status') or '-'}:{r.get('age_sec','-')}s")
        if sample:
            lines.append("- 최근60초 샘플: " + " / ".join(sample))
    return lines



def _v743_batch_text() -> str:
    score = _v650_score(); snap = _v650_candidate_snapshot(); official, exp = _v681_split_strategy_stats(score)
    exp_n = sum(int(so.get("n", 0) or 0) for _, so in exp); exp_total = sum(float(so.get("total", 0.0) or 0.0) for _, so in exp)
    s1 = _v743_grade_stat(score, "S1"); stop = _v681_stop_review_summary()
    lines = ["📦 핵심 상태 묶음 /batch · v750"]
    lines += _v743_section("① 시스템 상태") + [_v650_worker_line(), *_v650_resource_lines(), f"- paper OPEN: {_v650_open_count()}", *_v743_paper_active_lines()]
    lines += _v743_section("② 후보품질") + _v743_candidate_label_lines(snap) + ["", "- 1분 가격: " + _v743_counter_line(snap.get("materials"), 5)]
    lines += _v743_section("③ S1 승급 못한 이유 TOP") + _v743_short_counter(snap.get("reasons"), 5)
    lines += _v743_section("④ gate 누수 확인") + _v743_gate_scope_check_lines()
    lines += _v743_section("⑤ 코인별 아까운 후보 TOP") + _v743_top_candidate_lines(6)
    lines += _v743_section("⑥ 공통 상승포착 / S1 hold·paper 연결 확인") + _v743_s2_promotion_lines() + _v743_s1_hold_lines() + _v743_paper_hold_trace_lines()
    lines += _v743_section("⑦ 성과 · 시간당") + _v743_score_windows_lines() + [f"- 누적 정식 S1 참고: {_v650_stat_line('S1', s1)}", f"- 실험 S2/S3 합산: {exp_n}전 / {exp_total:+.2f}%"]
    lines += _v743_section("⑧ 운영") + [f"- 손절초과 누적: {stop.get('n',0)}건 / 루프gap {stop.get('loop_gap_suspect',0)}", *_v743_stop_recent_lines(), "- S2/S3 신규 paper OPEN: 중지 · 관찰/복기 전용", "- 요약집 txt: 전송 후 서버 임시파일 삭제", "", "더 보기: /reason /score /health /gate_check /candidate_reason_full"]
    return "\n".join(lines)

def _v743_reason_text() -> str:
    snap = _v650_candidate_snapshot(); lines = ["🧭 S1 승급 못한 이유 /reason · v750"]
    lines += _v743_section("① 후보/참고 구분") + _v743_candidate_label_lines(snap)
    lines += _v743_section("② 1분 가격/반응") + ["- " + _v743_counter_line(snap.get("materials"), 8)]
    lines += _v743_section("③ 승급 실패 TOP") + _v743_short_counter(snap.get("reasons"), 8)
    lines += _v743_section("④ gate 누수 확인") + _v743_gate_scope_check_lines()
    lines += _v743_section("⑤ 공통 상승포착 / S1 hold·paper 연결 확인") + _v743_s2_promotion_lines() + _v743_s1_hold_lines() + _v743_paper_hold_trace_lines()
    lines += _v743_section("⑥ 위험/차단 TOP") + _v743_short_counter(snap.get("risks"), 8)
    lines += _v743_section("⑦ 코인별 아까운 후보") + _v743_top_candidate_lines(10)
    if snap.get("stale_all"):
        lines += _v743_section("⑧ 정보 신선도") + [f"- 오래됨: 실전후보 {snap.get('stale_trade',0)} / S1·S2 {snap.get('stale_s12',0)} / 전체시장 참고 {snap.get('stale_coverage',0)} / 전체 {snap.get('stale_all',0)}"]
    lines += ["", "판독 순서: 1분반응 → 체결/지속 → 스프레드/미끄러짐 → 구조/위험필터", "상세 원문: /candidate_reason_full"]
    return "\n".join(lines)

def _v743_gate_check_text() -> str:
    return "\n".join(["🧪 gate/hold 확인 /gate_check · v750", *_v743_gate_scope_check_lines(), "", "[S1 stage/hold/paper]", *_v743_s2_promotion_lines(), *_v743_s1_hold_lines(), *_v743_paper_hold_trace_lines(), "", "기준: S1은 hold cache에서 신선도/방아쇠 확인 후 paper가 소비해야 합니다."])

def _v743_score_text() -> str:
    score = _v650_score()
    official, exp = _v681_split_strategy_stats(score)
    s1 = _v743_grade_stat(score, "S1")
    s2 = _v743_grade_stat(score, "S2")
    s3 = _v743_grade_stat(score, "S3")
    lines = ["📊 성과 /score · v750"]
    lines += _v743_section("① 최근 성과 · CLOSED 시간창") + _v743_score_windows_lines()
    lines += _v743_section("② 오늘/최근24시간 정식 S1")
    w = _v651_score_windows()
    r24 = _v650_stat_obj(w.get("r24", {}))
    if int(r24.get("n", 0) or 0) == 0:
        lines.append("❔ 오늘/최근24시간 정식 S1 CLOSED 없음")
    else:
        lines.append(_v650_stat_line("최근24h S1", r24))
    lines += _v743_section("③ 누적 참고 · 과거 전체")
    lines.append("- 아래 누적값은 오늘 매매가 아니라 과거 CLOSED 전체 참고입니다.")
    lines.append("- 누적 정식 S1: " + _v650_stat_line("S1", s1))
    lines.append("- 누적 실험 S2: " + _v650_stat_line("S2", s2))
    lines.append("- 누적 실험 S3: " + _v650_stat_line("S3", s3))
    exp_n = sum(int(so.get("n", 0) or 0) for _, so in exp)
    exp_total = sum(float(so.get("total", 0.0) or 0.0) for _, so in exp)
    lines += _v743_section("④ 실험 lane 전략")
    if exp:
        for name, so in exp[:8]:
            lines.append(_v650_stat_line(name, so))
    else:
        lines.append("- 실험 lane 집계 없음")
    lines += _v743_section("⑤ 정식/비실험 전략")
    if official:
        for name, so in official[:8]:
            lines.append(_v650_stat_line(name, so))
    else:
        lines.append("- 정식/비실험 전략 집계 없음")
    lines.append("")
    lines.append(f"- 실험 S2/S3 누적 합산: {exp_n}전 / {exp_total:+.2f}%")
    lines.append(f"- source owner: paper_bot_score_cache.json / window {score.get('score_window_source_v741', '-')}")
    return "\n".join(lines)

def _v743_health_text() -> str:
    st = _v650_status(); lines = ["🧭 상태 /health · v750"]
    lines += _v743_section("① 봇/worker") + [f"- 메인봇: {BOT_VERSION} / {V650_BUILD_LABEL}", f"- paper: {st.get('version','-')} / build {st.get('build','-')} / OPEN {_v650_open_count()}", _v650_worker_line()]
    lines += _v743_section("② 자원") + _v650_resource_lines()
    lines += _v743_section("③ 정리/보관") + _v678_cleanup_lines() + _v743_stop_recent_lines()
    lines += _v743_section("④ 요약/원문 묶음") + _v650_hourly_lines()
    return "\n".join(lines)

def _v743_menu_text() -> str:
    return "\n".join(["🧭 코인봇 메뉴 /menu · v750", "", "[메인봇 · 평소 확인]", "📦 /batch  - 성과 + 후보품질 + 이전 요약 이후 매매상세", "🧭 /reason - S1 승급 못한 이유와 코인별 후보", "🧪 /gate_check - 구조계획 + S1 hold/paper 연결", "📊 /score  - 정식 S1 / 실험 S2·S3 / 시간당 성과", "🧭 /health - worker / 자원 / cleanup 보관정책", "🧯 /errorlog - 새 오류", "", "[메인봇 · 상세 원문]", "/candidate_reason_full /score_full /health_full", "/strategy_review_full /stop_review_full /paper_handoff_full", "", "[paper 확인]", "/pstatus /popen /paper_handoff", "", "[후보·복기 상세]", "/feature_map /condition_review /missed_candidates", "", "[가드봇방에서 확인]", "/gupgrade_bundle /gdeploy /glog", "/gexternal_state /gpaper_state /gmicro_state /gws_state", "", "[페이퍼봇방 단독 확인]", "/pstatus /popen /pscore /perror /pbatch", "", "[표시 기준]", "🟢 S1=실전 후보 / 🟡 S2=재확인 / 🔵 S3=관찰", "⚪ 참고 신호와 ⚫ 비후보는 실전후보가 아닙니다."])

# =============================================================================
# main_bot v747: one-shot classify board + full worker age view
# - /classify는 새 분류표를 없애지 않고 한 명령에 모아 본다.
# - main_bot은 paper_bot_classify_cache.json, paper status, candidate snapshot, worker status만 읽는다.
# - CLOSED 원장 직접 재계산/조건변경/청산값 변경 없음.
# =============================================================================
def _v747_classify_cache() -> Dict[str, Any]:
    obj = _v650_load(BASE_DIR / 'paper_bot_classify_cache.json', {}) or {}
    return obj if isinstance(obj, dict) else {}


def _v747_bucket_line(name: str, d: Any) -> str:
    if not isinstance(d, dict):
        return f"- {name}: 0건"
    n = _v650_int(d.get('n'), d.get('count'), default=0)
    total = _v650_num(d.get('total'), d.get('sum'), d.get('total_pct'), default=0.0)
    avg = _v650_num(d.get('avg'), default=(total / n if n else 0.0))
    return f"- {name}: {n}건 / 합산 {total:+.2f}% / 평균 {avg:+.2f}%"


def _v747_counter_text(obj: Any, limit: int = 6) -> str:
    try:
        return ' / '.join(f'{k} {v}' for k, v in Counter(obj or {}).most_common(limit) if v) or '없음'
    except Exception:
        return '없음'


def _v747_worker_age_lines(full: bool = True) -> List[str]:
    rows = []
    for k in WORKERS:
        try:
            w = worker_status(k)
            a = _v650_num(w.get('age'), default=999999.0)
            if (not w.get('alive') and str(w.get('state')) == 'missing') or a >= 99999:
                icon = '❌'
            elif a >= 60:
                icon = '⚠️'
            else:
                icon = '✅'
            rows.append((a, f"- {icon} {k}: {a:.1f}s / state {w.get('state','-')} / rows {w.get('row_count','-')}"))
        except Exception:
            rows.append((999999.0, f"- ❌ {k}: 상태 읽기 실패"))
    rows_sorted = sorted(rows, reverse=True)
    if full:
        return [line for _, line in rows_sorted]
    old = [line for a, line in rows_sorted if a >= 30]
    return old[:6] or ['- 오래된 worker 없음']


def _v747_performance_lines(cache: Dict[str, Any]) -> List[str]:
    perf = cache.get('performance_breakdown') if isinstance(cache.get('performance_breakdown'), dict) else {}
    if not perf:
        return ['- classify cache 준비중 · 다음 CLOSED/score write 후 표시']
    w3 = perf.get('recent_3h') if isinstance(perf.get('recent_3h'), dict) else {}
    w6 = perf.get('recent_6h') if isinstance(perf.get('recent_6h'), dict) else {}
    w24 = perf.get('recent_24h') if isinstance(perf.get('recent_24h'), dict) else {}
    lines = []
    for label, obj in [('3시간', w3), ('6시간', w6), ('24시간', w24)]:
        st = obj.get('global') if isinstance(obj.get('global'), dict) else {}
        lines.append(_v650_stat_line(label, _v650_stat_obj(st)))
    lines += ['']
    b = w3.get('buckets') if isinstance(w3.get('buckets'), dict) else {}
    if b:
        lines.append('[최근 3시간 분해]')
        for key, label in [('big_profit','큰수익'), ('normal_profit','일반익절'), ('stop_loss','손절'), ('fast_fail','빠른실패'), ('time_exit','시간청산'), ('other_loss','기타손실')]:
            lines.append(_v747_bucket_line(label, b.get(key)))
    else:
        lines.append('- 최근 3시간 분해: cache 준비중')
    return lines


def _v747_entry_quality_lines(cache: Dict[str, Any]) -> List[str]:
    q = cache.get('entry_quality') if isinstance(cache.get('entry_quality'), dict) else {}
    if not q:
        return ['- 진입품질 cache 준비중']
    rr_bad = _v650_int(q.get('rr_bad'), q.get('rr_bad_or_missing'), default=0)
    rr_missing = _v650_int(q.get('rr_missing'), default=0)
    reac_off = _v650_int(q.get('reaction_off'), q.get('reaction_off_before_entry'), default=0)
    reac_missing = _v650_int(q.get('reaction_missing'), default=0)
    lines = []
    lines.append('- snapshot: 신규분류 ' + str(_v650_int(q.get('snapshot_ready_rows'), default=0)) + ' / 빈껍데기 ' + str(_v650_int(q.get('snapshot_empty_rows_v759'), default=0)) + ' / 재구성 ' + str(_v650_int(q.get('classify_snapshot_rebuild_v758'), q.get('ledger_rebuilt_snapshot'), default=0)) + ' / 구버전snapshot없음 ' + str(_v650_int(q.get('legacy_without_entry_snapshot'), q.get('legacy_without_rebuildable_snapshot'), default=0)))
    lines.append('- 구조선/source: 구조태그 ' + str(_v650_int(q.get('structure_tag_rows_v759'), q.get('v762_structure_tag_rows'), default=0)) + ' / 공식선 ' + str(_v650_int(q.get('official_line_rows_v759'), q.get('v762_official_full_rows'), default=0)) + ' / 부분공식선 ' + str(_v650_int(q.get('v762_official_partial_rows'), default=0)) + ' / 계산선·gap ' + str(_v650_int(q.get('synthetic_or_gap_line_rows_v759'), q.get('v762_synthetic_or_missing_rows'), default=0)))
    if _v650_int(q.get('v762_strategy_snapshot_rows'), default=0) or _v650_int(q.get('v762_structure_tag_rows'), default=0):
        lines.append('- v762 구조스냅샷: rows ' + str(_v650_int(q.get('v762_strategy_snapshot_rows'), default=0)) + ' / copied ' + str(_v650_int(q.get('v762_strategy_snapshot_copied_rows'), default=0)) + ' / tag_rows ' + str(_v650_int(q.get('v762_structure_tag_rows'), default=0)))
    lines.append('- 오래된 후보 진입: ' + str(_v650_int(q.get('old_candidate_entry'), default=0)) + ' / timing오염 ' + str(_v650_int(q.get('timing_field_contaminated'), default=0)) + ' / source오래됨 ' + str(_v650_int(q.get('old_source_entry'), default=0)))
    lines.append('- 목표가 근처/위 진입: ' + str(_v650_int(q.get('target_near_or_above_entry'), default=0)))
    lines.append('- 방아쇠 gap 과다: ' + str(_v650_int(q.get('trigger_gap_high'), default=0)))
    lines.append(f'- RR 불량/확인필요: 불량 {rr_bad} / 확인불가 {rr_missing}')
    lines.append(f'- 진입 직전 반응 꺼짐: 꺼짐 {reac_off} / 확인불가 {reac_missing}')
    lines.append('- 공식캔들 stale/없음: ' + str(_v650_int(q.get('official_candle_stale_120s'), default=0)) + ' / ' + str(_v650_int(q.get('official_candle_missing'), default=0)))
    top = q.get('top') if isinstance(q.get('top'), dict) else {}
    if top:
        lines.append('- TOP: ' + _v747_counter_text(top, 8))
    return lines


def _v749_loss_split_lines(cache: Dict[str, Any]) -> List[str]:
    obj = cache.get('loss_split') if isinstance(cache.get('loss_split'), dict) else {}
    r3 = obj.get('recent_3h') if isinstance(obj.get('recent_3h'), dict) else {}
    if not r3:
        return ['- 손실군 분해 cache 준비중']
    lines = [f"- 최근3시간 손실군 표본: {_v650_int(r3.get('n'), default=0)}건"]
    st = r3.get('strategy_top') if isinstance(r3.get('strategy_top'), dict) else {}
    it = r3.get('issue_top') if isinstance(r3.get('issue_top'), dict) else {}
    lines.append('- 손실 전략 TOP: ' + _v747_counter_text(st, 6))
    lines.append('- 손실 원인 TOP: ' + _v747_counter_text(it, 8))
    ex = r3.get('examples') if isinstance(r3.get('examples'), dict) else {}
    sample_bits = []
    for k, vals in list(ex.items())[:4]:
        if isinstance(vals, list) and vals:
            sample_bits.append(f"{k}: {','.join(str(x) for x in vals[:3])}")
    if sample_bits:
        lines.append('- 샘플: ' + ' / '.join(sample_bits))
    return lines


def _v747_exit_issue_lines(cache: Dict[str, Any]) -> List[str]:
    q = cache.get('exit_issues') if isinstance(cache.get('exit_issues'), dict) else {}
    stop = _v681_stop_review_summary()
    lines = [
        f"- 손절초과: tail {stop.get('n',0)}건 / loopgap {stop.get('loop_gap_suspect',0)} / 가격age {stop.get('price_age_suspect',0)}",
        *_v743_stop_recent_lines(),
    ]
    if q:
        lines.append('- 청산문제 TOP: ' + _v747_counter_text(q.get('top'), 6))
    return lines


def _v747_lifecycle_lines(cache: Dict[str, Any]) -> List[str]:
    snap = _v650_candidate_snapshot()
    c = snap.get('counts') if isinstance(snap.get('counts'), Counter) else Counter()
    h = _v743_s1_hold_obj()
    lines = [
        f"- 현재 후보: S1 {int(c.get('S1',0))} / S2 {int(c.get('S2',0))} / S3 {int(c.get('S3',0))}",
        *_v743_s1_hold_lines(),
        *_v743_paper_hold_trace_lines(),
    ]
    life = cache.get('lifecycle') if isinstance(cache.get('lifecycle'), dict) else {}
    if life:
        lines.append('- 생애주기 TOP: ' + _v747_counter_text(life.get('top'), 6))
    return lines


def _v747_priority_lines(cache: Dict[str, Any]) -> List[str]:
    q = cache.get('entry_quality') if isinstance(cache.get('entry_quality'), dict) else {}
    loss = cache.get('loss_split') if isinstance(cache.get('loss_split'), dict) else {}
    r3 = loss.get('recent_3h') if isinstance(loss.get('recent_3h'), dict) else {}
    issues = r3.get('issue_top') if isinstance(r3.get('issue_top'), dict) else {}
    stop = _v681_stop_review_summary()
    picks = []
    if _v650_int(stop.get('loop_gap_suspect'), default=0) > 0:
        picks.append('청산 loopgap 추적/감시 우선')
    if _v650_int(q.get('old_candidate_entry'), default=0) > 0 or _v650_int(issues.get('오래된후보진입'), default=0) > 0:
        picks.append('생애주기 timestamp 오염 원천 정리')
    if _v650_int(q.get('official_candle_stale_120s'), default=0) > 0 or _v650_int(issues.get('공식캔들stale'), default=0) > 0:
        picks.append('공식캔들 stale 분리 + S2/S1 최신화 확인')
    if _v650_int(q.get('rr_bad'), q.get('rr_bad_or_missing'), default=0) > 0 or _v650_int(issues.get('RR불량'), default=0) > 0:
        picks.append('RR 불량/확인불가 분리 후 손실군 비교')
    if _v650_int(q.get('target_near_or_above_entry'), default=0) > 0:
        picks.append('목표가 근처/위 진입 차단 확인')
    if not picks:
        picks.append('S2→S1 승급 재확인 표본 누적')
    return [f"{i+1}. {x}" for i, x in enumerate(picks[:3])]


def _v747_classify_text() -> str:
    cache = _v747_classify_cache()
    age_sec = _v650_file_age(BASE_DIR / 'paper_bot_classify_cache.json')
    lines = [
        '🧾 분류판 /classify · v754',
        f"- source: paper_bot_classify_cache.json / age {age_sec:.1f}s / paper {cache.get('paper_version','-')} / build {cache.get('build','-')}",
        '- 기준: 분류표는 누적 유지. 새 문제는 이 판에 항목 추가, 기존 항목 삭제 금지.',
        '- v754: OPEN→CLOSED→classify snapshot spine을 main 이전에 활성화. legacy는 snapshot없음으로 분리.',
        '',
        '1️⃣ 성과 분해',
        *_v747_performance_lines(cache),
        '',
        '2️⃣ 진입 품질',
        *_v747_entry_quality_lines(cache),
        '',
        '2-1️⃣ 손실군 원인 분해',
        *_v749_loss_split_lines(cache),
        '',
        '3️⃣ 청산 문제',
        *_v747_exit_issue_lines(cache),
        '',
        '4️⃣ 후보 생애주기',
        *_v747_lifecycle_lines(cache),
        '',
        '5️⃣ 워커 9개 age',
        *_v747_worker_age_lines(full=True),
        '',
        '6️⃣ 수정 우선순위',
        *_v747_priority_lines(cache),
    ]
    return '\n'.join(lines)


# v747: /health에도 전체 worker age를 같이 보여준다.
def _v747_health_text() -> str:
    st = _v650_status(); lines = ["🧭 상태 /health · v750"]
    lines += _v743_section("① 봇/worker") + [f"- 메인봇: {BOT_VERSION} / {V650_BUILD_LABEL}", f"- paper: {st.get('version','-')} / build {st.get('build','-')} / OPEN {_v650_open_count()}", _v650_worker_line(), "", "[worker 9개 age]", *_v747_worker_age_lines(full=True)]
    lines += _v743_section("② 자원") + _v650_resource_lines()
    lines += _v743_section("③ 정리/보관") + _v678_cleanup_lines() + _v743_stop_recent_lines()
    lines += _v743_section("④ 요약/원문 묶음") + _v650_hourly_lines()
    return "\n".join(lines)


def _v747_menu_text() -> str:
    base = _v743_menu_text().replace('🧭 코인봇 메뉴 /menu · v750', '🧭 코인봇 메뉴 /menu · v750')
    return base.replace('📊 /score  - 정식 S1 / 실험 S2·S3 / 시간당 성과', '📊 /score  - 정식 S1 / 실험 S2·S3 / 시간당 성과\n🧾 /classify - 성과·진입·청산·생애주기·worker 분류판')

# Ensure command registry uses grouped v736 outputs by default.
COMMANDS['menu'] = _v747_menu_text
COMMANDS['help'] = _v747_menu_text
COMMANDS['batch'] = _v743_batch_text
COMMANDS['summary'] = _v743_batch_text
COMMANDS['pbatch'] = _v743_batch_text
COMMANDS['reason'] = _v743_reason_text
COMMANDS['why_s1'] = _v743_reason_text
COMMANDS['candidate_reason'] = _v743_reason_text
COMMANDS['quality'] = _v743_reason_text
COMMANDS['gate_check'] = _v743_gate_check_text
COMMANDS['score'] = _v743_score_text
COMMANDS['pscore'] = _v743_score_text
COMMANDS['health'] = _v747_health_text
COMMANDS['core'] = _v747_health_text
COMMANDS['deploy'] = _v747_health_text
COMMANDS['upgradestatus'] = _v747_health_text
COMMANDS['retention'] = _v747_health_text
COMMANDS['classify'] = _v747_classify_text
COMMANDS['review_board'] = _v747_classify_text
COMMANDS['batch_full'] = _v650_batch_text
COMMANDS['health_full'] = _v650_health_text
COMMANDS['score_full'] = _v679_score_text
COMMANDS['candidate_reason_full'] = _v650_candidate_reason_text
COMMANDS['reason_full'] = _v650_candidate_reason_text
COMMANDS['strategy_review_full'] = _v681_strategy_review_text
COMMANDS['stop_review_full'] = _v681_stop_review_text
COMMANDS['pstatus_full'] = _v650_pstatus_text
COMMANDS['paper_handoff_full'] = _v650_paper_handoff_text
COMMANDS['pstatus'] = _v650_pstatus_text
COMMANDS['status'] = _v650_pstatus_text
COMMANDS['paper_handoff'] = _v650_paper_handoff_text
COMMANDS['handoff'] = _v650_paper_handoff_text
COMMANDS['popen'] = _v679_popen_text
COMMANDS['open'] = _v679_popen_text
COMMANDS['stop_review'] = _v681_stop_review_text
COMMANDS['exit_review'] = _v681_stop_review_text
COMMANDS['strategy_review'] = _v681_strategy_review_text
COMMANDS['sreview'] = _v681_strategy_review_text
COMMANDS['feature_map'] = _v701_feature_map_text
COMMANDS['map'] = _v701_feature_map_text
COMMANDS['guide'] = _v701_feature_map_text
COMMANDS['trade'] = _v650_pstatus_text
pstatus_text = _v650_pstatus_text
paper_handoff_text = _v650_paper_handoff_text
popen_text = _v679_popen_text
stop_review_text = _v681_stop_review_text
strategy_review_text = _v681_strategy_review_text
log_runtime('v736_gate_scope_original_flow_loaded')
# =============================================================================
# main_bot v755: /classify structure taxonomy display
# - paper_bot structure_split_v755 cache만 읽는다. 조건/장부 재계산 없음.
# =============================================================================
def _v755_structure_stat_line(name: str, stat: Any) -> str:
    if not isinstance(stat, dict):
        return f"- {name}: 0전"
    n = _v650_int(stat.get('n'), stat.get('count'), default=0)
    wins = _v650_int(stat.get('wins'), stat.get('win'), default=0)
    losses = _v650_int(stat.get('losses'), stat.get('loss'), default=0)
    total = _v650_num(stat.get('total'), stat.get('sum'), stat.get('total_pct'), default=0.0)
    avg = _v650_num(stat.get('avg'), default=(total / n if n else 0.0))
    return f"- {name}: {n}전 {wins}승 {losses}패 / 합산 {total:+.2f}% / 평균 {avg:+.2f}%"

def _v755_counter_pairs_text(obj: Any, limit: int = 8) -> str:
    if not isinstance(obj, dict) or not obj:
        return '없음'
    return ' / '.join(f'{k} {v}' for k, v in list(obj.items())[:limit]) or '없음'

def _v755_structure_split_lines(cache: Dict[str, Any]) -> List[str]:
    root = cache.get('structure_split_v755') if isinstance(cache.get('structure_split_v755'), dict) else {}
    r3 = root.get('recent_3h') if isinstance(root.get('recent_3h'), dict) else {}
    if not r3:
        return ['- 구조별 손익 cache 준비중']
    side_stats = r3.get('side_stats') if isinstance(r3.get('side_stats'), dict) else {}
    lines = ['[최근 3시간 구조별]']
    label_map = {
        'good': '좋은구조', 'bad': '위험구조', 'mixed': '혼합구조', 'recheck': '재확인구조',
        'neutral': '중립', 'no_snapshot': 'snapshot없음', 'legacy_without_entry_snapshot': '구버전snapshot없음'
    }
    for key in ('good','mixed','bad','recheck','neutral','legacy_without_entry_snapshot','no_snapshot'):
        if key in side_stats:
            lines.append(_v755_structure_stat_line(label_map.get(key, key), side_stats.get(key)))
    lines.append('- 구조 태그 TOP: ' + _v755_counter_pairs_text(r3.get('tag_top'), 10))
    lines.append('- 손실 구조 TOP: ' + _v755_counter_pairs_text(r3.get('loss_tag_top'), 10))
    return lines

_v755_prev_classify_text = _v747_classify_text

def _v747_classify_text() -> str:  # type: ignore[override]
    cache = _v747_classify_cache()
    age_sec = _v650_file_age(BASE_DIR / 'paper_bot_classify_cache.json')
    lines = [
        '🧾 분류판 /classify · v763',
        f"- source: paper_bot_classify_cache.json / age {age_sec:.1f}s / paper {cache.get('paper_version','-')} / build {cache.get('build','-')}",
        '- 기준: 분류표는 누적 유지. 새 문제는 이 판에 항목 추가, 기존 항목 삭제 금지.',
        '- v763: strategy→handoff→OPEN/CLOSED 구조 snapshot 배관을 CLOSED 없이도 검증. 조건값 변경 없음.',
        '',
        '1️⃣ 성과 분해',
        *_v747_performance_lines(cache),
        '',
        '2️⃣ 진입 품질',
        *_v747_entry_quality_lines(cache),
        '',
        '2-1️⃣ 손실군 원인 분해',
        *_v749_loss_split_lines(cache),
        '',
        '2-2️⃣ 구조별 손익 분해',
        *_v755_structure_split_lines(cache),
        '',
        '3️⃣ 청산 문제',
        *_v747_exit_issue_lines(cache),
        '',
        '4️⃣ 후보 생애주기',
        *_v747_lifecycle_lines(cache),
        '',
        '5️⃣ 워커 9개 age',
        *_v747_worker_age_lines(full=True),
        '',
        '6️⃣ 수정 우선순위',
        *_v747_priority_lines(cache),
    ]
    return '\n'.join(lines)

COMMANDS['classify'] = _v747_classify_text
COMMANDS['review_board'] = _v747_classify_text


# =============================================================================
# main_bot v763: structure snapshot pipeline verification
# - 업그레이드 직후 CLOSED를 기다리지 않고 strategy -> handoff -> open/classify
#   배관에 구조 snapshot이 살아있는지 확인한다.
# - 조건/청산/S1/S2/S3 변경 없음. 표시/검증 전용.
# =============================================================================
def _v763_jsonl_tail(path: Path, limit: int = 200) -> List[Dict[str, Any]]:
    rows: List[Dict[str, Any]] = []
    try:
        if not path.exists():
            return []
        lines = path.read_text(encoding='utf-8', errors='ignore').splitlines()[-limit:]
        for ln in lines:
            try:
                obj = json.loads(ln)
                if isinstance(obj, dict):
                    rows.append(obj)
            except Exception:
                continue
    except Exception:
        return []
    return rows


def _v763_dict_get(obj: Any, key: str) -> Dict[str, Any]:
    if isinstance(obj, dict) and isinstance(obj.get(key), dict):
        return obj.get(key) or {}
    return {}


def _v763_find_snapshot(row: Dict[str, Any]) -> Dict[str, Any]:
    row = row if isinstance(row, dict) else {}
    ctx = row.get('entry_context') if isinstance(row.get('entry_context'), dict) else {}
    raw = row.get('raw') if isinstance(row.get('raw'), dict) else {}
    diag = row.get('entry_diagnostics') if isinstance(row.get('entry_diagnostics'), dict) else {}
    for src in (row, ctx, raw, diag):
        if not isinstance(src, dict):
            continue
        for key in ('canonical_entry_snapshot_v762', 'canonical_entry_snapshot_v763', 'structure_snapshot_v762', 'structure_snapshot_v763', 'canonical_entry_snapshot', 'entry_snapshot'):
            snap = src.get(key)
            if isinstance(snap, dict) and snap:
                return snap
    return {}


def _v763_snapshot_has_tags(snap: Dict[str, Any]) -> bool:
    if not isinstance(snap, dict) or not snap:
        return False
    tax = snap.get('structure_taxonomy_v762') if isinstance(snap.get('structure_taxonomy_v762'), dict) else snap.get('structure_taxonomy_v755') if isinstance(snap.get('structure_taxonomy_v755'), dict) else {}
    if tax.get('good') or tax.get('bad') or tax.get('recheck'):
        return True
    st = snap.get('structure') if isinstance(snap.get('structure'), dict) else {}
    tags = st.get('tags') if isinstance(st.get('tags'), list) else snap.get('structure_tags') if isinstance(snap.get('structure_tags'), list) else []
    return bool(tags)


def _v763_snapshot_line_quality(snap: Dict[str, Any]) -> str:
    if not isinstance(snap, dict) or not snap:
        return 'missing'
    line = snap.get('structure_line_source_v762') if isinstance(snap.get('structure_line_source_v762'), dict) else {}
    if not line:
        st = snap.get('structure') if isinstance(snap.get('structure'), dict) else {}
        line = st.get('line_source') if isinstance(st.get('line_source'), dict) else {}
    if not line:
        audit = snap.get('structure_line_audit_v759') if isinstance(snap.get('structure_line_audit_v759'), dict) else {}
        rel = str(audit.get('reliability') or audit.get('source_kind') or '')
        return rel or 'missing'
    return str(line.get('line_quality_v762') or line.get('line_source_kind_v762') or line.get('reliability') or 'missing')


def _v763_row_snapshot_counts(rows: List[Dict[str, Any]]) -> Dict[str, int]:
    out = {'rows': len(rows or []), 'snapshot': 0, 'tag_rows': 0, 'official_full': 0, 'official_partial': 0, 'synthetic_or_gap': 0, 'missing': 0}
    for r in rows or []:
        snap = _v763_find_snapshot(r)
        if not snap:
            out['missing'] += 1
            continue
        out['snapshot'] += 1
        if _v763_snapshot_has_tags(snap):
            out['tag_rows'] += 1
        q = _v763_snapshot_line_quality(snap)
        if q == 'official_full' or q == 'official_candle_lines':
            out['official_full'] += 1
        elif q in ('official_partial', 'official_weak', 'official_candle_partial', 'official_candle_stale_or_sparse'):
            out['official_partial'] += 1
        elif q and q != 'missing':
            out['synthetic_or_gap'] += 1
        else:
            out['missing'] += 1
    return out


def _v763_counts_line(label: str, c: Dict[str, int]) -> str:
    return (f"- {label}: rows {int(c.get('rows',0))} / snapshot {int(c.get('snapshot',0))} / "
            f"tag {int(c.get('tag_rows',0))} / 공식 {int(c.get('official_full',0))} / 부분 {int(c.get('official_partial',0))} / "
            f"계산·gap {int(c.get('synthetic_or_gap',0))} / 없음 {int(c.get('missing',0))}")


def _v763_structure_pipeline_lines() -> List[str]:
    lines: List[str] = []
    # 1) strategy structure snapshot cache produced by strategy_worker
    sc_path = BASE_DIR / 'clean_structure_snapshot_cache.json'
    sc = _v650_load(sc_path, {}) or {}
    sc_age = _v650_file_age(sc_path) if sc_path.exists() else 999999.0
    if isinstance(sc, dict) and sc:
        lq = sc.get('line_quality_counts') if isinstance(sc.get('line_quality_counts'), dict) else {}
        side = sc.get('taxonomy_side_counts') if isinstance(sc.get('taxonomy_side_counts'), dict) else {}
        lines.append(f"- strategy 구조캐시: age {sc_age:.1f}s / rows {_v650_int(sc.get('row_count'), default=0)} / tag {_v650_int(sc.get('structure_tag_rows'), default=0)}")
        lines.append('- structure line 품질: ' + (_v743_counter_line(lq, 6) if lq else '없음'))
        lines.append('- taxonomy side: ' + (_v743_counter_line(side, 6) if side else '없음'))
    else:
        lines.append('- strategy 구조캐시: 없음 또는 준비중')

    # 2) strategy final/paper candidate rows
    latest_rows = _v763_jsonl_tail(BASE_DIR / 'paper_candidates_latest.jsonl', 220)
    lines.append(_v763_counts_line('strategy final rows', _v763_row_snapshot_counts(latest_rows)))

    # 3) paper S1 hold rows consumed by paper
    hold = _v743_s1_hold_obj()
    hold_rows = hold.get('rows') if isinstance(hold, dict) and isinstance(hold.get('rows'), list) else []
    lines.append(_v763_counts_line('paper S1 hold rows', _v763_row_snapshot_counts([r for r in hold_rows if isinstance(r, dict)])))

    # 4) active open rows, if any
    open_obj = _v650_load(BASE_DIR / 'paper_bot_open.json', {}) or {}
    open_rows: List[Dict[str, Any]] = []
    if isinstance(open_obj, dict):
        for key in ('positions','open','rows','items'):
            val = open_obj.get(key)
            if isinstance(val, list):
                open_rows = [x for x in val if isinstance(x, dict)]
                break
            if isinstance(val, dict):
                open_rows = [x for x in val.values() if isinstance(x, dict)]
                break
        if not open_rows and all(isinstance(v, dict) for v in open_obj.values()):
            open_rows = [x for x in open_obj.values() if isinstance(x, dict)]
    lines.append(_v763_counts_line('paper OPEN rows', _v763_row_snapshot_counts(open_rows)))

    # 5) classify cache status, does not wait for new CLOSED to see pipeline state
    cc = _v747_classify_cache()
    eq = cc.get('entry_quality') if isinstance(cc.get('entry_quality'), dict) else cc.get('entry_quality_v747') if isinstance(cc.get('entry_quality_v747'), dict) else {}
    if isinstance(eq, dict) and eq:
        lines.append('- classify ledger: snapshot ' + str(_v650_int(eq.get('snapshot_ready_rows'), default=0)) + ' / 빈껍데기 ' + str(_v650_int(eq.get('snapshot_empty_rows_v759'), default=0)) + ' / 구조태그 ' + str(_v650_int(eq.get('structure_tag_rows_v759'), eq.get('v762_structure_tag_rows'), default=0)))
    lines.append('- 판정: strategy final/hold 단계에서 snapshot 0이면 CLOSED 기다리지 말고 구조공장→handoff 배관을 봐야 함')
    return lines


_v763_prev_paper_handoff_text = COMMANDS.get('paper_handoff', _v650_paper_handoff_text)

def _v763_paper_handoff_text() -> str:
    base = _v763_prev_paper_handoff_text()
    return base.rstrip() + '\n\n[구조 snapshot 배관검증 · v763]\n' + '\n'.join(_v763_structure_pipeline_lines())


_v763_prev_classify_text = COMMANDS.get('classify', _v747_classify_text)

def _v763_classify_text() -> str:
    base = _v763_prev_classify_text()
    marker = '\n\n3️⃣ 청산 문제'
    block = '\n\n2-3️⃣ 구조 snapshot 배관검증\n' + '\n'.join(_v763_structure_pipeline_lines())
    if marker in base:
        return base.replace(marker, block + marker, 1)
    return base.rstrip() + block


_v763_prev_health_text = COMMANDS.get('health', _v743_health_text)

def _v763_health_text() -> str:
    base = _v763_prev_health_text()
    sc = _v650_load(BASE_DIR / 'clean_structure_snapshot_cache.json', {}) or {}
    age = _v650_file_age(BASE_DIR / 'clean_structure_snapshot_cache.json') if (BASE_DIR / 'clean_structure_snapshot_cache.json').exists() else 999999.0
    if isinstance(sc, dict) and sc:
        brief = f"\n\n[구조 snapshot]\n- strategy 구조캐시 age {age:.1f}s / rows {_v650_int(sc.get('row_count'), default=0)} / tag {_v650_int(sc.get('structure_tag_rows'), default=0)}"
    else:
        brief = "\n\n[구조 snapshot]\n- strategy 구조캐시 준비중"
    return base.rstrip() + brief

COMMANDS['paper_handoff'] = _v763_paper_handoff_text
COMMANDS['handoff'] = _v763_paper_handoff_text
COMMANDS['classify'] = _v763_classify_text
COMMANDS['review_board'] = _v763_classify_text
COMMANDS['health'] = _v763_health_text
COMMANDS['core'] = _v763_health_text
COMMANDS['deploy'] = _v763_health_text
COMMANDS['upgradestatus'] = _v763_health_text
# =============================================================================
# main_bot v764: user-readable entry basis/source verification
# - Shows whether current price, trigger, target/invalid, RR, and line source
#   are using one sealed entry basis. Display only; no threshold change.
# =============================================================================
V650_BUILD_LABEL = 'v806_integrated_validation_freshness_2026-06-10'
BOT_VERSION = '수익형 v2.13.806'


def _v764_find_basis(row: Dict[str, Any]) -> Dict[str, Any]:
    row = row if isinstance(row, dict) else {}
    ctx = row.get('entry_context') if isinstance(row.get('entry_context'), dict) else {}
    raw = row.get('raw') if isinstance(row.get('raw'), dict) else {}
    diag = row.get('entry_diagnostics') if isinstance(row.get('entry_diagnostics'), dict) else {}
    for src in (row, ctx, raw, diag):
        if not isinstance(src, dict):
            continue
        basis = src.get('canonical_entry_basis_v764')
        if isinstance(basis, dict) and basis:
            return basis
        snap = _v763_find_snapshot(src)
        if isinstance(snap, dict):
            b = snap.get('canonical_entry_basis_v764')
            if isinstance(b, dict) and b:
                return b
    return {}


def _v764_basis_counts(rows: List[Dict[str, Any]]) -> Dict[str, int]:
    out = {'rows': len(rows or []), 'basis': 0, 'ok': 0, 'warn': 0, 'bad': 0, 'missing': 0, 'complete': 0, 'official': 0, 'calculated': 0, 'stale': 0}
    for r in rows or []:
        b = _v764_find_basis(r)
        if not b:
            out['missing'] += 1
            continue
        out['basis'] += 1
        st = b.get('basis_status') if isinstance(b.get('basis_status'), dict) else {}
        label = str(st.get('status') or '')
        if label.startswith('✅'): out['ok'] += 1
        elif label.startswith('⚠️'): out['warn'] += 1
        elif label.startswith('❌'): out['bad'] += 1
        else: out['missing'] += 1
        pb = b.get('price_basis') if isinstance(b.get('price_basis'), dict) else {}
        if pb.get('entry_price') and pb.get('trigger_price') and pb.get('target1_price') and pb.get('invalid_price'):
            out['complete'] += 1
        sb = b.get('source_basis') if isinstance(b.get('source_basis'), dict) else {}
        q = str(sb.get('structure_line_quality') or '')
        if q == 'official_full': out['official'] += 1
        elif q: out['calculated'] += 1
        ages = sb.get('age_sec') if isinstance(sb.get('age_sec'), dict) else {}
        try:
            if float(ages.get('candle', 0) or 0) > 180 or float(ages.get('orderbook', 0) or 0) > 15 or float(ages.get('trade', 0) or 0) > 15:
                out['stale'] += 1
        except Exception:
            pass
    return out


def _v764_basis_counts_line(label: str, c: Dict[str, int]) -> str:
    return (f"- {label}: rows {c.get('rows',0)} / 기준표 {c.get('basis',0)} / "
            f"✅일치 {c.get('ok',0)} / ⚠️주의 {c.get('warn',0)} / ❌불일치 {c.get('bad',0)} / "
            f"❔없음 {c.get('missing',0)} / 가격선완성 {c.get('complete',0)} / 공식선 {c.get('official',0)} / 계산선·부분 {c.get('calculated',0)} / 오래됨 {c.get('stale',0)}")


def _v764_entry_basis_lines() -> List[str]:
    lines: List[str] = []
    cache_path = BASE_DIR / 'clean_entry_basis_audit_cache_v764.json'
    cache = _v650_load(cache_path, {}) or {}
    age = _v650_file_age(cache_path) if cache_path.exists() else 999999.0
    if isinstance(cache, dict) and cache:
        sc = cache.get('status_counts') if isinstance(cache.get('status_counts'), dict) else {}
        lq = cache.get('line_quality_counts') if isinstance(cache.get('line_quality_counts'), dict) else {}
        lines.append(f"- strategy 기준표 캐시: age {age:.1f}s / rows {_v650_int(cache.get('row_count'), default=0)} / 가격선완성 {_v650_int(cache.get('basis_complete_rows'), default=0)}")
        lines.append('- 기준상태: ' + (_v743_counter_line(sc, 6) if sc else '없음'))
        lines.append('- 구조선 출처: ' + (_v743_counter_line(lq, 6) if lq else '없음'))
    else:
        lines.append('- strategy 기준표 캐시: 준비중')

    latest_rows = _v763_jsonl_tail(BASE_DIR / 'paper_candidates_latest.jsonl', 220)
    lines.append(_v764_basis_counts_line('strategy final rows', _v764_basis_counts(latest_rows)))
    hold = _v743_s1_hold_obj()
    hold_rows = hold.get('rows') if isinstance(hold, dict) and isinstance(hold.get('rows'), list) else []
    lines.append(_v764_basis_counts_line('paper S1 hold rows', _v764_basis_counts([r for r in hold_rows if isinstance(r, dict)])))
    open_obj = _v650_load(BASE_DIR / 'paper_bot_open.json', {}) or {}
    open_rows: List[Dict[str, Any]] = []
    if isinstance(open_obj, dict):
        for key in ('positions','open','rows','items'):
            val = open_obj.get(key)
            if isinstance(val, list):
                open_rows = [x for x in val if isinstance(x, dict)]; break
            if isinstance(val, dict):
                open_rows = [x for x in val.values() if isinstance(x, dict)]; break
        if not open_rows and all(isinstance(v, dict) for v in open_obj.values()):
            open_rows = [x for x in open_obj.values() if isinstance(x, dict)]
    lines.append(_v764_basis_counts_line('paper OPEN rows', _v764_basis_counts(open_rows)))
    cc = _v747_classify_cache()
    eb = cc.get('entry_basis_v764') if isinstance(cc.get('entry_basis_v764'), dict) else {}
    if eb:
        st = eb.get('status_counts') if isinstance(eb.get('status_counts'), dict) else {}
        lines.append('- classify ledger 기준표: rows ' + str(_v650_int(eb.get('rows_with_basis'), default=0)) + ' / 가격선완성 ' + str(_v650_int(eb.get('basis_complete_rows'), default=0)) + ' / ' + (_v743_counter_line(st, 5) if st else '상태 없음'))
    lines.append('- 판정: ❌불일치가 OPEN에 있으면 진입값 기준이 섞인 것. ⚠️주의는 계산선/오래된 정보 의존 후보입니다.')
    return lines


_v764_prev_paper_handoff_text = COMMANDS.get('paper_handoff', _v763_paper_handoff_text)

def _v764_paper_handoff_text() -> str:
    base = _v764_prev_paper_handoff_text()
    return base.rstrip() + '\n\n🧭 진입 기준 확인 · v764\n' + '\n'.join(_v764_entry_basis_lines())


_v764_prev_classify_text = COMMANDS.get('classify', _v763_classify_text)

def _v764_classify_text() -> str:
    base = _v764_prev_classify_text()
    block = '\n\n2-4️⃣ 진입 기준 일치도\n' + '\n'.join(_v764_entry_basis_lines())
    marker = '\n\n3️⃣ 청산 문제'
    if marker in base:
        return base.replace(marker, block + marker, 1)
    return base.rstrip() + block


_v764_prev_health_text = COMMANDS.get('health', _v763_health_text)

def _v764_health_text() -> str:
    base = _v764_prev_health_text()
    cache_path = BASE_DIR / 'clean_entry_basis_audit_cache_v764.json'
    cache = _v650_load(cache_path, {}) or {}
    age = _v650_file_age(cache_path) if cache_path.exists() else 999999.0
    if isinstance(cache, dict) and cache:
        sc = cache.get('status_counts') if isinstance(cache.get('status_counts'), dict) else {}
        brief = f"\n\n[진입 기준]\n- 기준표 age {age:.1f}s / rows {_v650_int(cache.get('row_count'), default=0)} / " + (_v743_counter_line(sc, 4) if sc else '상태 없음')
    else:
        brief = "\n\n[진입 기준]\n- 기준표 캐시 준비중"
    return base.rstrip() + brief

COMMANDS['paper_handoff'] = _v764_paper_handoff_text
COMMANDS['handoff'] = _v764_paper_handoff_text
COMMANDS['classify'] = _v764_classify_text
COMMANDS['review_board'] = _v764_classify_text
COMMANDS['health'] = _v764_health_text
COMMANDS['core'] = _v764_health_text
COMMANDS['deploy'] = _v764_health_text
COMMANDS['upgradestatus'] = _v764_health_text



# =============================================================================
# main_bot v765: readable /classify and entry-basis reason split
# - Cleans up long developer-like classify output into user-readable sections.
# - Splits "일부 주의" by reason counts from strategy_worker cache.
# - Display/cache wiring only; no strategy threshold or exit change.
# =============================================================================
V650_BUILD_LABEL = 'v806_integrated_validation_freshness_2026-06-10'
BOT_VERSION = '수익형 v2.13.806'


def _v765_counter_label(d: Any, limit: int = 5, empty: str = '없음') -> str:
    if not isinstance(d, dict) or not d:
        return empty
    try:
        items = sorted(d.items(), key=lambda kv: float(kv[1] or 0), reverse=True)[:limit]
        return ' / '.join(f"{k} {int(v)}" for k, v in items if int(v or 0) != 0) or empty
    except Exception:
        return empty


def _v765_basis_cache() -> Dict[str, Any]:
    return _v650_load(BASE_DIR / 'clean_entry_basis_audit_cache_v764.json', {}) or {}


def _v765_basis_simple_lines() -> List[str]:
    cache = _v765_basis_cache()
    age = _v650_file_age(BASE_DIR / 'clean_entry_basis_audit_cache_v764.json') if (BASE_DIR / 'clean_entry_basis_audit_cache_v764.json').exists() else 999999.0
    if not isinstance(cache, dict) or not cache:
        return ['- 기준표 캐시: 준비중']
    status = cache.get('status_counts') if isinstance(cache.get('status_counts'), dict) else {}
    warn = cache.get('warning_reason_counts') if isinstance(cache.get('warning_reason_counts'), dict) else {}
    issue = cache.get('issue_reason_counts') if isinstance(cache.get('issue_reason_counts'), dict) else {}
    lineq = cache.get('line_quality_counts') if isinstance(cache.get('line_quality_counts'), dict) else {}
    rows = _v650_int(cache.get('row_count'), default=0)
    complete = _v650_int(cache.get('basis_complete_rows'), default=0)
    ok = sum(int(v or 0) for k, v in status.items() if str(k).startswith('✅'))
    caution = sum(int(v or 0) for k, v in status.items() if str(k).startswith('⚠️'))
    bad = sum(int(v or 0) for k, v in status.items() if str(k).startswith('❌'))
    unknown = max(0, rows - ok - caution - bad)
    return [
        f"- 기준표: age {age:.1f}s / rows {rows} / 가격선완성 {complete}",
        f"- 판정: ✅ 기준일치 {ok} / ⚠️ 일부주의 {caution} / ❌ 불일치 {bad} / ❔ 없음 {unknown}",
        f"- 일부주의 이유 TOP: {_v765_counter_label(warn, 5)}",
        f"- 불일치 이유 TOP: {_v765_counter_label(issue, 5)}",
        f"- 구조선 출처: {_v765_counter_label(lineq, 5)}",
    ]


def _v765_pipeline_compact_lines() -> List[str]:
    lines = _v763_structure_pipeline_lines()
    # Keep the useful rows, remove repeated long explanatory tail.
    keep: List[str] = []
    for ln in lines:
        if '판정:' in ln:
            continue
        if ln.startswith('- strategy 구조캐시') or ln.startswith('- structure line 품질') or ln.startswith('- taxonomy side') or ln.startswith('- strategy final rows') or ln.startswith('- paper S1 hold rows') or ln.startswith('- paper OPEN rows') or ln.startswith('- classify ledger'):
            keep.append(ln)
    # Add a short human-readable cut point.
    try:
        final = _v763_row_snapshot_counts(_v763_jsonl_tail(BASE_DIR / 'paper_candidates_latest.jsonl', 220))
        hold = _v743_s1_hold_obj()
        hold_rows = hold.get('rows') if isinstance(hold, dict) and isinstance(hold.get('rows'), list) else []
        hc = _v763_row_snapshot_counts([r for r in hold_rows if isinstance(r, dict)])
        open_obj = _v650_load(BASE_DIR / 'paper_bot_open.json', {}) or {}
        open_rows: List[Dict[str, Any]] = []
        if isinstance(open_obj, dict):
            for key in ('positions','open','rows','items'):
                val = open_obj.get(key)
                if isinstance(val, list):
                    open_rows = [x for x in val if isinstance(x, dict)]; break
                if isinstance(val, dict):
                    open_rows = [x for x in val.values() if isinstance(x, dict)]; break
            if not open_rows and all(isinstance(v, dict) for v in open_obj.values()):
                open_rows = [x for x in open_obj.values() if isinstance(x, dict)]
        oc = _v763_row_snapshot_counts(open_rows)
        if int(final.get('snapshot',0)) == 0:
            keep.append('- 끊긴 지점: strategy final 전에 snapshot 없음')
        elif int(hc.get('rows',0)) > 0 and int(hc.get('snapshot',0)) == 0:
            keep.append('- 끊긴 지점: strategy final → paper S1 hold 사이')
        elif int(oc.get('rows',0)) > 0 and int(oc.get('snapshot',0)) == 0:
            keep.append('- 끊긴 지점: paper S1 hold → OPEN 사이')
        else:
            keep.append('- 끊긴 지점: 현재 후보/OPEN 단계는 통과. CLOSED 발생 후 ledger 확인')
    except Exception:
        pass
    return keep


def _v765_perf_summary(cache: Dict[str, Any]) -> List[str]:
    return _v747_performance_lines(cache)[:8]


def _v765_entry_quality_lines(cache: Dict[str, Any]) -> List[str]:
    eq = cache.get('entry_quality') if isinstance(cache.get('entry_quality'), dict) else cache.get('entry_quality_v747') if isinstance(cache.get('entry_quality_v747'), dict) else {}
    if not isinstance(eq, dict):
        eq = {}
    return [
        f"- snapshot: 신규 { _v650_int(eq.get('snapshot_ready_rows'), default=0) } / 빈껍데기 { _v650_int(eq.get('snapshot_empty_rows_v759'), default=0) } / 구버전없음 { _v650_int(eq.get('legacy_without_entry_snapshot'), default=0) }",
        f"- 구조/source: 구조태그 { _v650_int(eq.get('structure_tag_rows_v759'), eq.get('v762_structure_tag_rows'), default=0) } / 공식선 { _v650_int(eq.get('official_line_rows_v759'), default=0) } / 부분공식 { _v650_int(eq.get('official_partial_rows_v759'), default=0) } / 계산선·gap { _v650_int(eq.get('synthetic_line_rows_v759'), default=0) }",
        f"- 진입위험: 오래된후보 { _v650_int(eq.get('old_entry_count'), default=0) } / timing오염 { _v650_int(eq.get('timing_polluted_count'), default=0) } / 목표근처 { _v650_int(eq.get('near_target_entry_count'), default=0) } / gap과다 { _v650_int(eq.get('trigger_gap_excess_count'), default=0) }",
        f"- 재료누락: RR확인불가 { _v650_int(eq.get('rr_missing_count'), eq.get('rr_unknown_count'), default=0) } / 반응확인불가 { _v650_int(eq.get('reaction_missing_count'), default=0) } / 공식캔들없음 { _v650_int(eq.get('official_candle_missing_count'), default=0) }",
    ]


def _v765_loss_short_lines(cache: Dict[str, Any]) -> List[str]:
    rows = _v749_loss_split_lines(cache)
    out = []
    for ln in rows:
        if ln.startswith('- 최근3시간') or ln.startswith('- 손실 전략 TOP') or ln.startswith('- 손실 원인 TOP') or ln.startswith('- 샘플'):
            out.append(ln)
    return out or ['- 손실군 cache 준비중']


def _v765_classify_text() -> str:
    cache = _v747_classify_cache()
    age_sec = _v650_file_age(BASE_DIR / 'paper_bot_classify_cache.json')
    lines = [
        '🧾 분류판 /classify · v765',
        f"- source age {age_sec:.1f}s / paper {cache.get('paper_version','-')} / build {cache.get('build','-')}",
        '- 목적: 성과·진입기준·구조배관을 한 화면에서 확인. 조건값 변경 없음.',
        '',
        '1️⃣ 성과 요약',
        *_v765_perf_summary(cache),
        '',
        '2️⃣ 진입 기준 확인',
        *_v765_basis_simple_lines(),
        '',
        '2-1️⃣ 진입 품질 요약',
        *_v765_entry_quality_lines(cache),
        '',
        '2-2️⃣ 손실군 원인 요약',
        *_v765_loss_short_lines(cache),
        '',
        '2-3️⃣ 구조 snapshot 배관검증',
        *_v765_pipeline_compact_lines(),
        '',
        '3️⃣ 청산/루프 확인',
        *_v747_exit_issue_lines(cache),
        '',
        '4️⃣ 후보 생애주기',
        *_v747_lifecycle_lines(cache)[:8],
    ]
    return '\n'.join(lines)


def _v765_strip_old_verify_sections(text: str) -> str:
    out = str(text or '')
    for marker in ('\n\n🧭 진입 기준 확인 · v764', '\n\n[구조 snapshot 배관검증 · v763]'):
        if marker in out:
            out = out.split(marker, 1)[0]
    return out.rstrip()


_v765_prev_paper_handoff_text = COMMANDS.get('paper_handoff', _v764_paper_handoff_text)

def _v765_paper_handoff_text() -> str:
    base = _v765_strip_old_verify_sections(_v765_prev_paper_handoff_text())
    block = '\n\n🧭 진입 기준 확인 · v765\n' + '\n'.join(_v765_basis_simple_lines())
    block += '\n\n[구조 snapshot 배관검증 · v765]\n' + '\n'.join(_v765_pipeline_compact_lines())
    return base.rstrip() + block


_v765_prev_health_text = COMMANDS.get('health', _v764_health_text)

def _v765_health_text() -> str:
    base = _v765_prev_health_text()
    cache = _v765_basis_cache()
    status = cache.get('status_counts') if isinstance(cache, dict) and isinstance(cache.get('status_counts'), dict) else {}
    warn = cache.get('warning_reason_counts') if isinstance(cache, dict) and isinstance(cache.get('warning_reason_counts'), dict) else {}
    rows = _v650_int(cache.get('row_count'), default=0) if isinstance(cache, dict) else 0
    brief = '\n\n[진입 기준 요약 v765]\n- rows ' + str(rows) + ' / ' + (_v765_counter_label(status, 4, '상태 없음')) + '\n- 주의 이유 TOP: ' + _v765_counter_label(warn, 3)
    return base.rstrip() + brief


COMMANDS['classify'] = _v765_classify_text
COMMANDS['review_board'] = _v765_classify_text
COMMANDS['paper_handoff'] = _v765_paper_handoff_text
COMMANDS['handoff'] = _v765_paper_handoff_text
COMMANDS['health'] = _v765_health_text
COMMANDS['core'] = _v765_health_text
COMMANDS['deploy'] = _v765_health_text
COMMANDS['upgradestatus'] = _v765_health_text


# =============================================================================
# main_bot v766: readable classify/handoff + detailed basis reason split
# - User-facing Korean labels for internal cache terms.
# - Splits broad "일부 주의" reasons into 호가/체결/캔들/구조선 buckets.
# - Display/cache wiring only. No condition, exit, S1/S2/S3, BUY_READY, or auto-buy change.
# =============================================================================
V650_BUILD_LABEL = 'v806_integrated_validation_freshness_2026-06-10'
BOT_VERSION = '수익형 v2.13.806'


def _v766_counter(d: Any, limit: int = 5, empty: str = '없음') -> str:
    if not isinstance(d, dict) or not d:
        return empty
    try:
        items = sorted(d.items(), key=lambda kv: float(kv[1] or 0), reverse=True)[:limit]
        return ' / '.join(f"{k} {int(v)}" for k, v in items if int(v or 0) != 0) or empty
    except Exception:
        return empty


def _v766_basis_cache() -> Dict[str, Any]:
    return _v650_load(BASE_DIR / 'clean_entry_basis_audit_cache_v764.json', {}) or {}


def _v766_status_numbers(cache: Dict[str, Any]) -> Tuple[int, int, int, int, int]:
    status = cache.get('status_counts') if isinstance(cache.get('status_counts'), dict) else {}
    rows = _v650_int(cache.get('row_count'), default=0)
    ok = sum(int(v or 0) for k, v in status.items() if str(k).startswith('✅'))
    warn = sum(int(v or 0) for k, v in status.items() if str(k).startswith('⚠️'))
    bad = sum(int(v or 0) for k, v in status.items() if str(k).startswith('❌'))
    unknown = max(0, rows - ok - warn - bad)
    return rows, ok, warn, bad, unknown


def _v766_sample_line(cache: Dict[str, Any], focus: bool = False) -> str:
    arr = cache.get('focus_sample' if focus else 'sample')
    if not isinstance(arr, list) or not arr:
        return '- 샘플: 없음'
    parts = []
    for x in arr[:4]:
        if not isinstance(x, dict):
            continue
        ticker = str(x.get('ticker') or '-')
        grade = str(x.get('grade') or x.get('stage') or '-')
        reason = str(x.get('reason') or x.get('status') or '-')
        parts.append(f"{ticker}({grade}: {reason[:36]})")
    return '- 샘플: ' + (' / '.join(parts) if parts else '없음')


def _v766_basis_readable_lines(compact: bool = False) -> List[str]:
    cache = _v766_basis_cache()
    age = _v650_file_age(BASE_DIR / 'clean_entry_basis_audit_cache_v764.json') if (BASE_DIR / 'clean_entry_basis_audit_cache_v764.json').exists() else 999999.0
    if not isinstance(cache, dict) or not cache:
        return ['- 진입 기준표: 준비중']
    rows, ok, warn, bad, unknown = _v766_status_numbers(cache)
    complete = _v650_int(cache.get('basis_complete_rows'), default=0)
    warn_big = cache.get('warning_reason_counts') if isinstance(cache.get('warning_reason_counts'), dict) else {}
    issues = cache.get('issue_reason_counts') if isinstance(cache.get('issue_reason_counts'), dict) else {}
    ob = cache.get('orderbook_detail_counts') if isinstance(cache.get('orderbook_detail_counts'), dict) else {}
    tr = cache.get('trade_detail_counts') if isinstance(cache.get('trade_detail_counts'), dict) else {}
    cd = cache.get('candle_detail_counts') if isinstance(cache.get('candle_detail_counts'), dict) else {}
    ln = cache.get('line_detail_counts') if isinstance(cache.get('line_detail_counts'), dict) else {}
    lineq = cache.get('line_quality_counts') if isinstance(cache.get('line_quality_counts'), dict) else {}
    focus = cache.get('focus_status_counts') if isinstance(cache.get('focus_status_counts'), dict) else {}
    out = [
        f"- 전체 기준표: {rows}개 / 가격선 완성 {complete}개 / age {age:.1f}s",
        f"- 판정: ✅ 바로 신뢰 {ok} / ⚠️ 확인 필요 {warn} / ❌ 기준 안 맞음 {bad} / ❔ 정보 부족 {unknown}",
        f"- 큰 주의 이유: {_v766_counter(warn_big, 5)}",
        f"- 호가/체결 상태: 호가 {_v766_counter(ob, 3)} / 체결 {_v766_counter(tr, 3)}",
        f"- 캔들/구조선 상태: 캔들 {_v766_counter(cd, 3)} / 구조선 {_v766_counter(ln, 4)}",
        f"- 구조선 출처: {_v766_counter(lineq, 5)}",
    ]
    if focus:
        out.append(f"- S1/S2 후보 기준: {_v766_counter(focus, 6)}")
    if issues:
        out.append(f"- 기준 불일치 이유: {_v766_counter(issues, 5)}")
    if not compact:
        out.append(_v766_sample_line(cache, focus=False))
        if focus:
            out.append(_v766_sample_line(cache, focus=True))
    return out


def _v766_line_quality_kor(k: str) -> str:
    return {
        'official_full': '공식선 확실',
        'official_partial': '공식선 일부',
        'official_weak': '공식근거 약함',
        'missing_official': '공식캔들 부족',
        'fallback_gap': '계산선 의존',
        'synthetic_pct_line': '계산선 의존',
        'missing': '정보 없음',
    }.get(str(k), str(k))


def _v766_structure_cache_lines() -> List[str]:
    sc_path = BASE_DIR / 'clean_structure_snapshot_cache.json'
    sc = _v650_load(sc_path, {}) or {}
    age = _v650_file_age(sc_path) if sc_path.exists() else 999999.0
    if not isinstance(sc, dict) or not sc:
        return ['- 구조공장: 준비중']
    lq = sc.get('line_quality_counts') if isinstance(sc.get('line_quality_counts'), dict) else {}
    side = sc.get('taxonomy_side_counts') if isinstance(sc.get('taxonomy_side_counts'), dict) else {}
    lq_kor = {_v766_line_quality_kor(str(k)): v for k, v in lq.items()} if isinstance(lq, dict) else {}
    return [
        f"- 구조공장: rows {_v650_int(sc.get('row_count'), default=0)} / 구조태그 {_v650_int(sc.get('structure_tag_rows'), default=0)} / age {age:.1f}s",
        f"- 구조선 품질: {_v766_counter(lq_kor, 5)}",
        f"- 구조판정: {_v766_counter(side, 5)}",
    ]


def _v766_pipeline_readable_lines() -> List[str]:
    latest_rows = _v763_jsonl_tail(BASE_DIR / 'paper_candidates_latest.jsonl', 220)
    final = _v763_row_snapshot_counts(latest_rows)
    hold = _v743_s1_hold_obj()
    hold_rows = hold.get('rows') if isinstance(hold, dict) and isinstance(hold.get('rows'), list) else []
    hc = _v763_row_snapshot_counts([r for r in hold_rows if isinstance(r, dict)])
    open_obj = _v650_load(BASE_DIR / 'paper_bot_open.json', {}) or {}
    open_rows: List[Dict[str, Any]] = []
    if isinstance(open_obj, dict):
        for key in ('positions','open','rows','items'):
            val = open_obj.get(key)
            if isinstance(val, list):
                open_rows = [x for x in val if isinstance(x, dict)]; break
            if isinstance(val, dict):
                open_rows = [x for x in val.values() if isinstance(x, dict)]; break
        if not open_rows and all(isinstance(v, dict) for v in open_obj.values()):
            open_rows = [x for x in open_obj.values() if isinstance(x, dict)]
    oc = _v763_row_snapshot_counts(open_rows)
    cc = _v747_classify_cache()
    eq = cc.get('entry_quality') if isinstance(cc.get('entry_quality'), dict) else cc.get('entry_quality_v747') if isinstance(cc.get('entry_quality_v747'), dict) else {}
    ledger = {
        'snapshot': _v650_int(eq.get('snapshot_ready_rows'), default=0) if isinstance(eq, dict) else 0,
        'empty': _v650_int(eq.get('snapshot_empty_rows_v759'), default=0) if isinstance(eq, dict) else 0,
        'tag': _v650_int(eq.get('structure_tag_rows_v759'), eq.get('v762_structure_tag_rows'), default=0) if isinstance(eq, dict) else 0,
    }
    lines = [
        f"- 전략 최종후보: {final.get('rows',0)}개 중 기준표 {final.get('snapshot',0)} / 구조태그 {final.get('tag_rows',0)}",
        f"- 페이퍼 대기후보: {hc.get('rows',0)}개 중 기준표 {hc.get('snapshot',0)} / 구조태그 {hc.get('tag_rows',0)}",
        f"- 현재 OPEN: {oc.get('rows',0)}개 중 기준표 {oc.get('snapshot',0)} / 구조태그 {oc.get('tag_rows',0)}",
        f"- 청산 장부: 기준표 {ledger.get('snapshot',0)} / 빈 기준표 {ledger.get('empty',0)} / 구조태그 {ledger.get('tag',0)}",
    ]
    if int(final.get('snapshot',0)) == 0:
        lines.append('- 판정: 구조공장 → 전략 최종후보 사이가 끊김')
    elif int(hc.get('rows',0)) > 0 and int(hc.get('snapshot',0)) == 0:
        lines.append('- 판정: 전략 최종후보 → 페이퍼 대기후보 사이가 끊김')
    elif int(oc.get('rows',0)) > 0 and int(oc.get('snapshot',0)) == 0:
        lines.append('- 판정: 페이퍼 대기후보 → OPEN 사이가 끊김')
    elif int(oc.get('rows',0)) == 0 and int(hc.get('rows',0)) == 0:
        lines.append('- 판정: 현재 S1/OPEN 없음 · 구조공장과 전략 최종후보까지만 확인')
    else:
        lines.append('- 판정: 후보/OPEN 단계는 통과 · 청산 후 장부 반영 확인')
    return lines


def _v766_perf_lines(cache: Dict[str, Any]) -> List[str]:
    rows = _v747_performance_lines(cache)[:7]
    return rows or ['- 성과 cache 준비중']


def _v766_loss_lines(cache: Dict[str, Any]) -> List[str]:
    rows = _v749_loss_split_lines(cache)
    out = []
    for ln in rows:
        if ln.startswith('- 최근3시간') or ln.startswith('- 손실 전략 TOP') or ln.startswith('- 손실 원인 TOP') or ln.startswith('- 샘플'):
            out.append(ln)
    return out or ['- 손실군 cache 준비중']


def _v766_entry_quality_lines(cache: Dict[str, Any]) -> List[str]:
    eq = cache.get('entry_quality') if isinstance(cache.get('entry_quality'), dict) else cache.get('entry_quality_v747') if isinstance(cache.get('entry_quality_v747'), dict) else {}
    if not isinstance(eq, dict):
        eq = {}
    return [
        f"- 청산장부 기준표: 신규 {_v650_int(eq.get('snapshot_ready_rows'), default=0)} / 빈껍데기 {_v650_int(eq.get('snapshot_empty_rows_v759'), default=0)} / 구버전없음 {_v650_int(eq.get('legacy_without_entry_snapshot'), default=0)}",
        f"- 청산장부 구조태그: {_v650_int(eq.get('structure_tag_rows_v759'), eq.get('v762_structure_tag_rows'), default=0)} / 공식선 {_v650_int(eq.get('official_line_rows_v759'), default=0)} / 부분공식 {_v650_int(eq.get('official_partial_rows_v759'), default=0)}",
        f"- 진입 위험: 오래된후보 {_v650_int(eq.get('old_entry_count'), default=0)} / timing오염 {_v650_int(eq.get('timing_polluted_count'), default=0)} / 목표근처 {_v650_int(eq.get('near_target_entry_count'), default=0)} / gap과다 {_v650_int(eq.get('trigger_gap_excess_count'), default=0)}",
    ]


def _v766_classify_text() -> str:
    cache = _v747_classify_cache()
    age_sec = _v650_file_age(BASE_DIR / 'paper_bot_classify_cache.json')
    lines = [
        '🧾 분류판 /classify · v766',
        f"- cache age {age_sec:.1f}s / paper {cache.get('paper_version','-')} / build {cache.get('build','-')}",
        '- 보는 법: 성과 → 진입 기준 → 구조 배관 → 손실/청산 순서로 확인합니다. 조건값 변경 없음.',
        '',
        '1️⃣ 성과 요약',
        *_v766_perf_lines(cache),
        '',
        '2️⃣ 진입 기준 확인',
        *_v766_basis_readable_lines(compact=False),
        '',
        '2-1️⃣ 구조선/기준표 배관',
        *_v766_structure_cache_lines(),
        *_v766_pipeline_readable_lines(),
        '',
        '2-2️⃣ 청산장부 진입 품질',
        *_v766_entry_quality_lines(cache),
        '',
        '3️⃣ 손실군 원인 요약',
        *_v766_loss_lines(cache),
        '',
        '4️⃣ 청산/루프 확인',
        *_v747_exit_issue_lines(cache),
        '',
        '5️⃣ 후보 생애주기',
        *_v747_lifecycle_lines(cache)[:7],
    ]
    return '\n'.join(lines)


def _v766_paper_handoff_text() -> str:
    hand = _v650_load(FILES.get('paperbot_handoff', BASE_DIR/'paper_bot_candidate_handoff_status.json'), {}) or {}
    score, today, _, _ = _v650_score_stats(); review = _v650_review()
    st = _v650_status()
    ver = str(st.get('paper_version') or st.get('version') or '-')
    build = str(st.get('build') or '-')
    ok = ('paper_bot_v0.795' in ver) or ('v766' in build)
    lines = [
        '📨 페이퍼 전달 /paper_handoff · v766',
        '',
        '① 적용 상태',
        f"- {'✅' if ok else '❌'} paper {ver} / build {build} / expected paper_bot_v0.795",
        f"- OPEN {_v650_open_count()} / status age {_v650_file_age(FILES.get('paper_status', BASE_DIR/'paper_bot_status.json')):.1f}s",
        '',
        '② 후보 전달',
        *_v650_pipeline_lines(),
        *_v650_candidate_lines(4),
        '',
        '③ S1 대기/페이퍼 소비',
        *_v743_s1_hold_lines(),
        *_v743_paper_hold_trace_lines()[:3],
        f"- score/review 오늘 {score.get('today_closed_count', today['n'])} / {review.get('today_closed_count','-')}",
        '',
        '④ 진입 기준 확인',
        *_v766_basis_readable_lines(compact=False),
        '',
        '⑤ 구조선/기준표 배관',
        *_v766_structure_cache_lines(),
        *_v766_pipeline_readable_lines(),
        '',
        '⑥ 요약 알림',
        *_v650_hourly_lines(),
    ]
    return '\n'.join(lines)


def _v766_health_text() -> str:
    base = _v765_prev_health_text() if '_v765_prev_health_text' in globals() else _v765_health_text()
    cache = _v766_basis_cache()
    rows, ok, warn, bad, unknown = _v766_status_numbers(cache if isinstance(cache, dict) else {})
    warn_big = cache.get('warning_reason_counts') if isinstance(cache, dict) and isinstance(cache.get('warning_reason_counts'), dict) else {}
    brief = '\n\n[진입 기준 요약 v766]\n'
    brief += f"- rows {rows} / ✅ 기준일치 {ok} / ⚠️ 주의 {warn} / ❌ 불일치 {bad} / ❔ 없음 {unknown}\n"
    brief += '- 주의 TOP: ' + _v766_counter(warn_big, 3)
    return base.rstrip() + brief


COMMANDS['classify'] = _v766_classify_text
COMMANDS['review_board'] = _v766_classify_text
COMMANDS['paper_handoff'] = _v766_paper_handoff_text
COMMANDS['handoff'] = _v766_paper_handoff_text
COMMANDS['health'] = _v766_health_text
COMMANDS['core'] = _v766_health_text
COMMANDS['deploy'] = _v766_health_text
COMMANDS['upgradestatus'] = _v766_health_text




# =============================================================================
# main_bot v767: readable source/basis focus after root age-key/TTL fix
# - Keeps v766 sections but removes duplicate wording and labels S1/S2 counts as
#   strategy-final-row diagnostics, not current live candidate count.
# - Display only. No threshold/exit change.
# =============================================================================
V650_BUILD_LABEL = 'v806_integrated_validation_freshness_2026-06-10'
BOT_VERSION = '수익형 v2.13.806'


def _v767_counter_clean(d: Any, limit: int = 5, empty: str = '없음') -> str:
    if not isinstance(d, dict) or not d:
        return empty
    try:
        items = sorted(d.items(), key=lambda kv: float(kv[1] or 0), reverse=True)[:limit]
        return ' / '.join(f"{str(k).replace('호가 ', '').replace('체결 ', '').replace('캔들 ', '')} {int(v)}" for k, v in items if int(v or 0) != 0) or empty
    except Exception:
        return empty


def _v766_basis_readable_lines(compact: bool = False) -> List[str]:  # type: ignore[override]
    cache = _v766_basis_cache()
    age = _v650_file_age(BASE_DIR / 'clean_entry_basis_audit_cache_v764.json') if (BASE_DIR / 'clean_entry_basis_audit_cache_v764.json').exists() else 999999.0
    if not isinstance(cache, dict) or not cache:
        return ['- 진입 기준표: 준비중']
    rows, ok, warn, bad, unknown = _v766_status_numbers(cache)
    complete = _v650_int(cache.get('basis_complete_rows'), default=0)
    warn_big = cache.get('warning_reason_counts') if isinstance(cache.get('warning_reason_counts'), dict) else {}
    issues = cache.get('issue_reason_counts') if isinstance(cache.get('issue_reason_counts'), dict) else {}
    ob = cache.get('orderbook_detail_counts') if isinstance(cache.get('orderbook_detail_counts'), dict) else {}
    tr = cache.get('trade_detail_counts') if isinstance(cache.get('trade_detail_counts'), dict) else {}
    cd = cache.get('candle_detail_counts') if isinstance(cache.get('candle_detail_counts'), dict) else {}
    ln = cache.get('line_detail_counts') if isinstance(cache.get('line_detail_counts'), dict) else {}
    lineq = cache.get('line_quality_counts') if isinstance(cache.get('line_quality_counts'), dict) else {}
    focus = cache.get('focus_status_counts') if isinstance(cache.get('focus_status_counts'), dict) else {}
    out = [
        f"- 전체 기준표: {rows}개 / 가격선 완성 {complete}개 / age {age:.1f}s",
        f"- 판정: ✅ 바로 신뢰 {ok} / ⚠️ 확인 필요 {warn} / ❌ 기준 안 맞음 {bad} / ❔ 정보 부족 {unknown}",
        f"- 큰 주의 이유: {_v767_counter_clean(warn_big, 6)}",
        f"- 호가 상태: {_v767_counter_clean(ob, 4)}",
        f"- 체결 상태: {_v767_counter_clean(tr, 4)}",
        f"- 캔들 상태: {_v767_counter_clean(cd, 4)}",
        f"- 구조선 근거: {_v767_counter_clean(ln, 5)}",
        f"- 구조선 출처: {_v767_counter_clean(lineq, 5)}",
    ]
    if focus:
        out.append(f"- 전략 최종후보 S1/S2 기준: {_v767_counter_clean(focus, 6)}")
        out.append('- 참고: 이 줄은 전략 최종후보 row 기준입니다. 현재 화면의 실시간 S1/S2 개수와 다를 수 있습니다.')
    if issues:
        out.append(f"- 기준 불일치 이유: {_v767_counter_clean(issues, 5)}")
    if not compact:
        out.append(_v766_sample_line(cache, focus=False))
        if focus:
            out.append(_v766_sample_line(cache, focus=True))
    return out


def _v766_classify_text() -> str:  # type: ignore[override]
    cache = _v747_classify_cache()
    age_sec = _v650_file_age(BASE_DIR / 'paper_bot_classify_cache.json')
    lines = [
        '🧾 분류판 /classify · v767',
        f"- cache age {age_sec:.1f}s / paper {cache.get('paper_version','-')} / build {cache.get('build','-')}",
        '- 보는 법: 성과 → 진입 기준 → 구조 배관 → 손실/청산 순서로 확인합니다. 조건값 변경 없음.',
        '',
        '1️⃣ 성과 요약',
        *_v766_perf_lines(cache),
        '',
        '2️⃣ 진입 기준 확인',
        *_v766_basis_readable_lines(compact=False),
        '',
        '2-1️⃣ 구조선/기준표 배관',
        *_v766_structure_cache_lines(),
        *_v766_pipeline_readable_lines(),
        '',
        '2-2️⃣ 청산장부 진입 품질',
        *_v766_entry_quality_lines(cache),
        '',
        '3️⃣ 손실군 원인 요약',
        *_v766_loss_lines(cache),
        '',
        '4️⃣ 청산/루프 확인',
        *_v747_exit_issue_lines(cache),
        '',
        '5️⃣ 후보 생애주기',
        *_v747_lifecycle_lines(cache)[:7],
    ]
    return '\n'.join(lines)



def _v766_paper_handoff_text() -> str:  # type: ignore[override]
    hand = _v650_load(FILES.get('paperbot_handoff', BASE_DIR/'paper_bot_candidate_handoff_status.json'), {}) or {}
    score, today, _, _ = _v650_score_stats(); review = _v650_review()
    st = _v650_status()
    ver = str(st.get('paper_version') or st.get('version') or '-')
    build = str(st.get('build') or '-')
    ok = ('paper_bot_v0.795' in ver) or ('v767' in build)
    lines = [
        '📨 페이퍼 전달 /paper_handoff · v767',
        '',
        '① 적용 상태',
        f"- {'✅' if ok else '❌'} paper {ver} / build {build} / expected paper_bot_v0.795",
        f"- OPEN {_v650_open_count()} / status age {_v650_file_age(FILES.get('paper_status', BASE_DIR/'paper_bot_status.json')):.1f}s",
        '',
        '② 후보 전달',
        *_v650_pipeline_lines(),
        *_v650_candidate_lines(4),
        '',
        '③ S1 대기/페이퍼 소비',
        *_v743_s1_hold_lines(),
        *_v743_paper_hold_trace_lines()[:3],
        f"- score/review 오늘 {score.get('today_closed_count', today['n'])} / {review.get('today_closed_count','-')}",
        '',
        '④ 진입 기준 확인',
        *_v766_basis_readable_lines(compact=False),
        '',
        '⑤ 구조선/기준표 배관',
        *_v766_structure_cache_lines(),
        *_v766_pipeline_readable_lines(),
        '',
        '⑥ 요약 알림',
        *_v650_hourly_lines(),
    ]
    return '\n'.join(lines)



def _v766_health_text() -> str:  # type: ignore[override]
    base = _v765_prev_health_text() if '_v765_prev_health_text' in globals() else _v765_health_text()
    cache = _v766_basis_cache(); rows, ok, warn, bad, unknown = _v766_status_numbers(cache if isinstance(cache, dict) else {})
    warn_big = cache.get('warning_reason_counts') if isinstance(cache, dict) and isinstance(cache.get('warning_reason_counts'), dict) else {}
    brief = '\n\n[진입 기준 요약 v769]\n'
    brief += f"- rows {rows} / ✅ 기준일치 {ok} / ⚠️ 주의 {warn} / ❌ 불일치 {bad} / ❔ 없음 {unknown}\n"
    brief += '- 주의 TOP: ' + _v769_counter_clean(warn_big, 4) + '\n'
    brief += '\n'.join(_v769_material_lines())
    return base.rstrip() + brief

COMMANDS['classify'] = _v766_classify_text
COMMANDS['review_board'] = _v766_classify_text
COMMANDS['paper_handoff'] = _v766_paper_handoff_text
COMMANDS['handoff'] = _v766_paper_handoff_text
COMMANDS['health'] = _v766_health_text
COMMANDS['core'] = _v766_health_text
COMMANDS['deploy'] = _v766_health_text
COMMANDS['upgradestatus'] = _v766_health_text



# =============================================================================
# main_bot v769: official candle material status display
# - Shows root material collection state before any structure/condition tuning.
# - Display only. No condition, exit, S1/S2/S3, BUY_READY, or auto-buy change.
# =============================================================================
V650_BUILD_LABEL = 'v806_integrated_validation_freshness_2026-06-10'
BOT_VERSION = '수익형 v2.13.806'


def _v769_counter_clean(d: Any, limit: int = 5, empty: str = '없음') -> str:
    return _v767_counter_clean(d, limit=limit, empty=empty) if '_v767_counter_clean' in globals() else _v766_counter(d, limit=limit, empty=empty)


def _v769_material_lines() -> List[str]:
    cache = _v766_basis_cache()
    if not isinstance(cache, dict) or not cache:
        return ['- 공식캔들 재료: 준비중']
    material = cache.get('official_material_counts_v769') if isinstance(cache.get('official_material_counts_v769'), dict) else {}
    weak = cache.get('weak_reason_counts_v769') if isinstance(cache.get('weak_reason_counts_v769'), dict) else {}
    tfmiss = cache.get('timeframe_missing_counts_v769') if isinstance(cache.get('timeframe_missing_counts_v769'), dict) else {}
    return [
        f"- 공식캔들 재료 상태: {_v769_counter_clean(material, 5)}",
        f"- 부족한 뿌리 TOP: {_v769_counter_clean(weak, 6)}",
        f"- 시간봉 부족 요약: {_v769_counter_clean(tfmiss, 4)}",
    ]


def _v766_basis_readable_lines(compact: bool = False) -> List[str]:  # type: ignore[override]
    cache = _v766_basis_cache()
    age = _v650_file_age(BASE_DIR / 'clean_entry_basis_audit_cache_v764.json') if (BASE_DIR / 'clean_entry_basis_audit_cache_v764.json').exists() else 999999.0
    if not isinstance(cache, dict) or not cache:
        return ['- 진입 기준표: 준비중']
    rows, ok, warn, bad, unknown = _v766_status_numbers(cache)
    complete = _v650_int(cache.get('basis_complete_rows'), default=0)
    warn_big = cache.get('warning_reason_counts') if isinstance(cache.get('warning_reason_counts'), dict) else {}
    issues = cache.get('issue_reason_counts') if isinstance(cache.get('issue_reason_counts'), dict) else {}
    ob = cache.get('orderbook_detail_counts') if isinstance(cache.get('orderbook_detail_counts'), dict) else {}
    tr = cache.get('trade_detail_counts') if isinstance(cache.get('trade_detail_counts'), dict) else {}
    cd = cache.get('candle_detail_counts') if isinstance(cache.get('candle_detail_counts'), dict) else {}
    ln = cache.get('line_detail_counts') if isinstance(cache.get('line_detail_counts'), dict) else {}
    lineq = cache.get('line_quality_counts') if isinstance(cache.get('line_quality_counts'), dict) else {}
    focus = cache.get('focus_status_counts') if isinstance(cache.get('focus_status_counts'), dict) else {}
    out = [
        f"- 전체 기준표: {rows}개 / 가격선 완성 {complete}개 / age {age:.1f}s",
        f"- 판정: ✅ 바로 신뢰 {ok} / ⚠️ 확인 필요 {warn} / ❌ 기준 안 맞음 {bad} / ❔ 정보 부족 {unknown}",
        f"- 큰 주의 이유: {_v769_counter_clean(warn_big, 6)}",
        *_v769_material_lines(),
        f"- 호가 상태: {_v769_counter_clean(ob, 4)}",
        f"- 체결 상태: {_v769_counter_clean(tr, 4)}",
        f"- 캔들 상태: {_v769_counter_clean(cd, 4)}",
        f"- 구조선 근거: {_v769_counter_clean(ln, 5)}",
        f"- 구조선 출처: {_v769_counter_clean(lineq, 5)}",
    ]
    if focus:
        out.append(f"- 전략 최종후보 S1/S2 기준: {_v769_counter_clean(focus, 6)}")
        out.append('- 참고: 이 줄은 전략 최종후보 row 기준입니다. 현재 화면의 실시간 S1/S2 개수와 다를 수 있습니다.')
    if issues:
        out.append(f"- 기준 불일치 이유: {_v769_counter_clean(issues, 5)}")
    if not compact:
        out.append(_v766_sample_line(cache, focus=True if focus else False))
    return out


def _v766_classify_text() -> str:  # type: ignore[override]
    cache = _v747_classify_cache()
    age_sec = _v650_file_age(BASE_DIR / 'paper_bot_classify_cache.json')
    lines = [
        '🧾 분류판 /classify · v769',
        f"- cache age {age_sec:.1f}s / paper {cache.get('paper_version','-')} / build {cache.get('build','-')}",
        '- 보는 법: 성과 → 진입 기준 → 공식캔들 재료 → 구조 배관 → 손실/청산 순서로 확인합니다. 조건값 변경 없음.',
        '', '1️⃣ 성과 요약', *_v766_perf_lines(cache),
        '', '2️⃣ 진입 기준 확인', *_v766_basis_readable_lines(compact=False),
        '', '2-1️⃣ 구조선/기준표 배관', *_v766_structure_cache_lines(), *_v766_pipeline_readable_lines(),
        '', '2-2️⃣ 청산장부 진입 품질', *_v766_entry_quality_lines(cache),
        '', '3️⃣ 손실군 원인 요약', *_v766_loss_lines(cache),
        '', '4️⃣ 청산/루프 확인', *_v747_exit_issue_lines(cache),
        '', '5️⃣ 후보 생애주기', *_v747_lifecycle_lines(cache)[:7],
    ]
    return '\n'.join(lines)


def _v766_paper_handoff_text() -> str:  # type: ignore[override]
    hand = _v650_load(FILES.get('paperbot_handoff', BASE_DIR/'paper_bot_candidate_handoff_status.json'), {}) or {}
    score, today, _, _ = _v650_score_stats(); review = _v650_review(); st = _v650_status()
    ver = str(st.get('paper_version') or st.get('version') or '-')
    build = str(st.get('build') or '-')
    ok = ('paper_bot_v0.795' in ver) or ('v769' in build)
    lines = [
        '📨 페이퍼 전달 /paper_handoff · v769', '',
        '① 적용 상태',
        f"- {'✅' if ok else '❌'} paper {ver} / build {build} / expected paper_bot_v0.795",
        f"- OPEN {_v650_open_count()} / status age {_v650_file_age(FILES.get('paper_status', BASE_DIR/'paper_bot_status.json')):.1f}s",
        '', '② 후보 전달', *_v650_pipeline_lines(), *_v650_candidate_lines(4),
        '', '③ S1 대기/페이퍼 소비', *_v743_s1_hold_lines(), *_v743_paper_hold_trace_lines()[:3], f"- score/review 오늘 {score.get('today_closed_count', today['n'])} / {review.get('today_closed_count','-')}",
        '', '④ 진입 기준 확인', *_v766_basis_readable_lines(compact=False),
        '', '⑤ 구조선/기준표 배관', *_v766_structure_cache_lines(), *_v766_pipeline_readable_lines(),
        '', '⑥ 요약 알림', *_v650_hourly_lines(),
    ]
    return '\n'.join(lines)


def _v766_health_text() -> str:  # type: ignore[override]
    base = _v765_prev_health_text() if '_v765_prev_health_text' in globals() else _v765_health_text()
    cache = _v766_basis_cache(); rows, ok, warn, bad, unknown = _v766_status_numbers(cache if isinstance(cache, dict) else {})
    warn_big = cache.get('warning_reason_counts') if isinstance(cache, dict) and isinstance(cache.get('warning_reason_counts'), dict) else {}
    brief = '\n\n[진입 기준 요약 v769]\n'
    brief += f"- rows {rows} / ✅ 기준일치 {ok} / ⚠️ 주의 {warn} / ❌ 불일치 {bad} / ❔ 없음 {unknown}\n"
    brief += '- 주의 TOP: ' + _v769_counter_clean(warn_big, 4) + '\n'
    brief += '\n'.join(_v769_material_lines())
    return base.rstrip() + brief

COMMANDS['classify'] = _v766_classify_text
COMMANDS['review_board'] = _v766_classify_text
COMMANDS['paper_handoff'] = _v766_paper_handoff_text
COMMANDS['handoff'] = _v766_paper_handoff_text
COMMANDS['health'] = _v766_health_text
COMMANDS['core'] = _v766_health_text
COMMANDS['deploy'] = _v766_health_text
COMMANDS['upgradestatus'] = _v766_health_text



# =============================================================================
# main_bot v771: grade-source + ledger snapshot probe
# - Root check after v770: official candle material works, but final S2 counts and
#   visible trade-candidate S2 counts may diverge. Also verify OPEN/CLOSED snapshot
#   handoff without waiting blindly. Display/diagnostic only; no thresholds changed.
# =============================================================================
V650_BUILD_LABEL = 'v806_integrated_validation_freshness_2026-06-10'
BOT_VERSION = '수익형 v2.13.806'


def _v771_stage_of(row: Dict[str, Any]) -> str:
    try:
        return _v650_stage(row)
    except Exception:
        return '미집계'


def _v771_lane_of(row: Dict[str, Any]) -> str:
    return str(row.get('canonical_lane') or row.get('lane') or row.get('source_lane') or row.get('strategy_lane') or '').lower()


def _v771_is_trade_candidate(row: Dict[str, Any]) -> bool:
    if not isinstance(row, dict):
        return False
    if row.get('trade_candidate_row_v661') is True or row.get('paper_candidate_row') is True:
        return True
    if row.get('paper_experiment_open') is True or row.get('paper_bot_open') is True:
        return True
    lane = _v771_lane_of(row)
    if lane in ('coverage', 'raw', 'market', 'scanner_only', 'coverage_light'):
        return False
    sk = str(row.get('strategy_key') or row.get('strategy') or '')
    if 'coverage' in sk or row.get('v661_coverage_reason'):
        return False
    return _v771_stage_of(row) in ('S1', 'S2')


def _v771_exclusion_reason(row: Dict[str, Any]) -> str:
    lane = _v771_lane_of(row)
    if lane in ('coverage', 'raw', 'market', 'scanner_only', 'coverage_light'):
        return 'coverage/전체시장 참고로 분리'
    sk = str(row.get('strategy_key') or row.get('strategy') or '')
    if 'coverage' in sk or row.get('v661_coverage_reason'):
        return 'coverage 전략/비후보 표시'
    if _v771_stage_of(row) not in ('S1','S2'):
        return 'S3/관찰 단계로 재봉인'
    if not (row.get('trade_candidate_row_v661') is True or row.get('paper_candidate_row') is True):
        return 'paper 후보 플래그 없음'
    return '기타/확인필요'


def _v771_grade_source_lines() -> List[str]:
    rows = _v763_jsonl_tail(BASE_DIR / 'paper_candidates_latest.jsonl', 260)
    if not rows:
        return ['- 등급 경로: 후보 row 없음']
    all_stage = Counter(_v771_stage_of(r) for r in rows if isinstance(r, dict))
    trade_rows = [r for r in rows if isinstance(r, dict) and _v771_is_trade_candidate(r)]
    trade_stage = Counter(_v771_stage_of(r) for r in trade_rows)
    non_trade_s12 = [r for r in rows if isinstance(r, dict) and _v771_stage_of(r) in ('S1','S2') and not _v771_is_trade_candidate(r)]
    reason_counter = Counter(_v771_exclusion_reason(r) for r in non_trade_s12)
    samples = []
    for r in non_trade_s12[:4]:
        samples.append(f"{_v650_ticker(r)}({_v771_stage_of(r)}:{_v771_exclusion_reason(r)})")
    final_s12 = int(all_stage.get('S1',0)+all_stage.get('S2',0))
    trade_s12 = int(trade_stage.get('S1',0)+trade_stage.get('S2',0))
    lines = [
        '🧭 등급 전달 확인 · v771',
        f"- 전략 최종 row: S1 {int(all_stage.get('S1',0))} / S2 {int(all_stage.get('S2',0))} / S3 {int(all_stage.get('S3',0))}",
        f"- 실제 paper 후보: S1 {int(trade_stage.get('S1',0))} / S2 {int(trade_stage.get('S2',0))} / S3 {int(trade_stage.get('S3',0))}",
        f"- S1/S2에서 빠진 row: {max(0, final_s12-trade_s12)}개",
        f"- 빠진 이유 TOP: {_v769_counter_clean(dict(reason_counter), 5)}",
    ]
    if samples:
        lines.append('- 샘플: ' + ' / '.join(samples))
    lines.append('- 보는 법: strategy row와 실제 paper 후보 숫자가 다르면, 여기서 어느 단계에서 빠졌는지 봅니다.')
    return lines


def _v771_closed_tail_rows(limit: int = 40) -> List[Dict[str, Any]]:
    return _v763_jsonl_tail(FILES.get('paper_closed', BASE_DIR/'paper_bot_closed.jsonl'), limit)


def _v771_has_basis(row: Dict[str, Any]) -> bool:
    if not isinstance(row, dict):
        return False
    for src in (row, row.get('entry_context'), row.get('entry_diagnostics'), row.get('raw')):
        if not isinstance(src, dict):
            continue
        if isinstance(src.get('canonical_entry_basis_v764'), dict) and src.get('canonical_entry_basis_v764'):
            return True
        for k in ('canonical_entry_snapshot_v764','canonical_entry_snapshot_v762','canonical_entry_snapshot','entry_snapshot'):
            snap = src.get(k)
            if isinstance(snap, dict) and snap:
                if isinstance(snap.get('canonical_entry_basis_v764'), dict) and snap.get('canonical_entry_basis_v764'):
                    return True
                # structure snapshot without basis still counts as snapshot, but not full 기준표
    return False


def _v771_has_structure_tag(row: Dict[str, Any]) -> bool:
    if not isinstance(row, dict):
        return False
    keys = ('structure_tags','entry_structure_tags','structure_good_tags_v755','structure_bad_tags_v755','structure_recheck_tags_v755')
    for src in (row, row.get('entry_context'), row.get('entry_diagnostics'), row.get('raw')):
        if not isinstance(src, dict):
            continue
        for k in keys:
            v = src.get(k)
            if isinstance(v, list) and v:
                return True
        for sk in ('canonical_entry_snapshot_v762','canonical_entry_snapshot_v764','canonical_entry_snapshot','entry_snapshot'):
            snap = src.get(sk)
            if isinstance(snap, dict):
                st = snap.get('structure') if isinstance(snap.get('structure'), dict) else {}
                if isinstance(st.get('tags'), list) and st.get('tags'):
                    return True
                tax = snap.get('structure_taxonomy_v755') if isinstance(snap.get('structure_taxonomy_v755'), dict) else snap.get('structure_taxonomy_v762') if isinstance(snap.get('structure_taxonomy_v762'), dict) else {}
                if any(tax.get(x) for x in ('good','bad','recheck')):
                    return True
    return False


def _v771_ledger_snapshot_lines() -> List[str]:
    open_obj = _v650_load(FILES.get('paper_open', BASE_DIR/'paper_bot_open.json'), {}) or {}
    open_rows: List[Dict[str, Any]] = []
    if isinstance(open_obj, dict):
        for key in ('positions','open','rows','items'):
            val = open_obj.get(key)
            if isinstance(val, list):
                open_rows = [x for x in val if isinstance(x, dict)]; break
            if isinstance(val, dict):
                open_rows = [x for x in val.values() if isinstance(x, dict)]; break
        if not open_rows and all(isinstance(v, dict) for v in open_obj.values()):
            open_rows = [x for x in open_obj.values() if isinstance(x, dict)]
    closed = _v771_closed_tail_rows(40)
    open_basis = sum(1 for r in open_rows if _v771_has_basis(r))
    open_tag = sum(1 for r in open_rows if _v771_has_structure_tag(r))
    closed_basis = sum(1 for r in closed if _v771_has_basis(r))
    closed_tag = sum(1 for r in closed if _v771_has_structure_tag(r))
    last = closed[-1] if closed else {}
    sample = '-'
    if isinstance(last, dict) and last:
        sample = f"{_v650_ticker(last)} / 기준표 {'있음' if _v771_has_basis(last) else '없음'} / 구조태그 {'있음' if _v771_has_structure_tag(last) else '없음'}"
    lines = [
        '📒 장부 전달 확인 · v771',
        f"- 현재 OPEN: {len(open_rows)}개 중 기준표 {open_basis} / 구조태그 {open_tag}",
        f"- 최근 청산 장부 tail: {len(closed)}개 중 기준표 {closed_basis} / 구조태그 {closed_tag}",
        f"- 마지막 청산 샘플: {sample}",
    ]
    if len(open_rows) > 0 and open_basis == len(open_rows):
        lines.append('- 판정: OPEN까지 기준표 전달 OK. 다음 청산 후 장부 반영 확인.')
    elif len(open_rows) > 0:
        lines.append('- 판정: OPEN row 기준표 누락 있음. paper OPEN 저장부 확인 필요.')
    elif closed_basis == 0:
        lines.append('- 판정: 최근 청산은 구버전/빈 기준표일 수 있음. 새 OPEN 청산 후 재확인.')
    return lines


def _v771_material_sample_lines() -> List[str]:
    cache = _v766_basis_cache()
    sample = cache.get('focus_sample') if isinstance(cache, dict) and isinstance(cache.get('focus_sample'), list) else []
    picked = []
    for x in sample:
        if not isinstance(x, dict):
            continue
        reason = str(x.get('reason') or '')
        if any(s in reason for s in ('구조선 출처', '구조재료 부족', '장기', '단기', '중기', '공식')):
            picked.append(f"{x.get('ticker','-')}({x.get('grade','-')}: {reason[:60]})")
    if not picked:
        sample2 = cache.get('sample') if isinstance(cache, dict) and isinstance(cache.get('sample'), list) else []
        for x in sample2:
            if isinstance(x, dict):
                reason = str(x.get('reason') or '')
                if any(s in reason for s in ('구조선 출처', '구조재료 부족', '장기', '단기', '중기', '공식')):
                    picked.append(f"{x.get('ticker','-')}({x.get('grade','-')}: {reason[:60]})")
            if len(picked) >= 4:
                break
    return ['🔎 남은 공식캔들 부족 샘플 · v771', '- 샘플: ' + (' / '.join(picked[:4]) if picked else '없음')]


def _v771_classify_text() -> str:
    cache = _v747_classify_cache()
    age_sec = _v650_file_age(BASE_DIR / 'paper_bot_classify_cache.json')
    lines = [
        '🧾 분류판 /classify · v771',
        f"- cache age {age_sec:.1f}s / paper {cache.get('paper_version','-')} / build {cache.get('build','-')}",
        '- 보는 법: 성과 → 진입 기준 → 등급 전달 → 장부 전달 순서로 확인합니다. 조건값 변경 없음.',
        '', '1️⃣ 성과 요약', *_v766_perf_lines(cache),
        '', '2️⃣ 진입 기준 확인', *_v766_basis_readable_lines(compact=False),
        '', '2-1️⃣ 등급 전달 확인', *_v771_grade_source_lines(),
        '', '2-2️⃣ 구조선/기준표 배관', *_v766_structure_cache_lines(), *_v766_pipeline_readable_lines(), *_v771_material_sample_lines(),
        '', '2-3️⃣ 장부 전달 확인', *_v771_ledger_snapshot_lines(),
        '', '3️⃣ 손실군 원인 요약', *_v766_loss_lines(cache),
        '', '4️⃣ 청산/루프 확인', *_v747_exit_issue_lines(cache),
    ]
    return '\n'.join(lines)


def _v771_paper_handoff_text() -> str:
    score, today, _, _ = _v650_score_stats(); review = _v650_review(); st = _v650_status()
    ver = str(st.get('paper_version') or st.get('version') or '-')
    build = str(st.get('build') or '-')
    ok = ('paper_bot_v0.795' in ver) or ('v771' in build)
    lines = [
        '📨 페이퍼 전달 /paper_handoff · v771', '',
        '① 적용 상태',
        f"- {'✅' if ok else '❌'} paper {ver} / build {build} / expected paper_bot_v0.795",
        f"- OPEN {_v650_open_count()} / status age {_v650_file_age(FILES.get('paper_status', BASE_DIR/'paper_bot_status.json')):.1f}s",
        '', '② 후보 전달', *_v650_pipeline_lines(), *_v650_candidate_lines(4),
        '', '③ S1 대기/페이퍼 소비', *_v743_s1_hold_lines(), *_v743_paper_hold_trace_lines()[:3], f"- score/review 오늘 {score.get('today_closed_count', today['n'])} / {review.get('today_closed_count','-')}",
        '', '④ 진입 기준 확인', *_v766_basis_readable_lines(compact=False),
        '', '⑤ 등급 전달 확인', *_v771_grade_source_lines(),
        '', '⑥ 장부 전달 확인', *_v771_ledger_snapshot_lines(),
        '', '⑦ 요약 알림', *_v650_hourly_lines(),
    ]
    return '\n'.join(lines)


def _v771_health_text() -> str:
    base = _v766_health_text()
    # keep health concise: only add the two root probes as a short line
    gs = _v771_grade_source_lines()
    ls = _v771_ledger_snapshot_lines()
    brief = '\n\n[배관 확인 v771]\n'
    brief += '- ' + (gs[1].replace('- ', '') if len(gs) > 1 else '등급 전달 준비중') + '\n'
    brief += '- ' + (gs[2].replace('- ', '') if len(gs) > 2 else '') + '\n'
    brief += '- ' + (ls[1].replace('- ', '') if len(ls) > 1 else '장부 전달 준비중')
    return base.rstrip() + brief

COMMANDS['classify'] = _v771_classify_text
COMMANDS['review_board'] = _v771_classify_text
COMMANDS['paper_handoff'] = _v771_paper_handoff_text
COMMANDS['handoff'] = _v771_paper_handoff_text
COMMANDS['health'] = _v771_health_text
COMMANDS['core'] = _v771_health_text
COMMANDS['deploy'] = _v771_health_text
COMMANDS['upgradestatus'] = _v771_health_text

# =============================================================================
# main_bot v772: easy terms + chart-line reaction state + ledger entry-check view
# - Renames developer terms into user-readable Korean.
# - Adds immediate chart reaction verification without waiting for new CLOSED.
# - Reads the same entry-check object from v772/v771/v764 so ledger false-negative is removed.
# =============================================================================
V650_BUILD_LABEL = 'v806_integrated_validation_freshness_2026-06-10'


def _v772_humanize_line(line: str) -> str:
    s = str(line)
    repl = [
        ('기준표', '진입 전 체크'),
        ('가격선 완성', '가격·방아쇠·목표 확인'),
        ('snapshot', '진입 당시 기록'),
        ('Snapshot', '진입 당시 기록'),
        ('ledger', '청산 장부'),
        ('Ledger', '청산 장부'),
        ('structure tag', '차트 모양'),
        ('구조태그', '차트 모양'),
        ('구조공장', '차트선 공장'),
        ('strategy final rows', '전략 최종후보'),
        ('paper S1 hold rows', '페이퍼 대기후보'),
        ('paper OPEN rows', '현재 OPEN'),
        ('classify ledger', '청산 장부'),
        ('official_full', '공식 캔들선 확실'),
        ('official_partial', '공식 캔들 일부만 사용'),
        ('official_weak', '공식근거 약함'),
        ('missing_official', '공식캔들 부족'),
        ('S2 기준일치', '재확인 후보 중 바로 신뢰'),
        ('S2 일부주의', '재확인 후보 중 확인 필요'),
        ('S1 기준일치', 'S1 중 바로 신뢰'),
        ('S1 일부주의', 'S1 중 확인 필요'),
        ('canonical', '최종'),
        ('basis', '진입 전 체크'),
    ]
    for a,b in repl:
        s = s.replace(a,b)
    return s


def _v772_humanize_lines(lines: List[str]) -> List[str]:
    return [_v772_humanize_line(x) for x in (lines or [])]


def _v772_find_entry_check(row: Dict[str, Any]) -> Dict[str, Any]:
    if not isinstance(row, dict): return {}
    sources = [row]
    for k in ('entry_context','entry_diagnostics','raw','source_event'):
        v = row.get(k)
        if isinstance(v, dict): sources.append(v)
    for src in sources:
        for key in ('canonical_entry_basis_v772','entry_check_v772','canonical_entry_basis_v771','canonical_entry_basis_v764','entry_check'):
            v = src.get(key)
            if isinstance(v, dict) and v: return v
        for sk in ('canonical_entry_snapshot_v772','canonical_entry_snapshot_v771','canonical_entry_snapshot_v764','canonical_entry_snapshot_v762','canonical_entry_snapshot','entry_record_v772','entry_snapshot_v771','entry_snapshot_v762','entry_snapshot'):
            snap = src.get(sk)
            if isinstance(snap, dict):
                for bk in ('canonical_entry_basis_v772','entry_check_v772','canonical_entry_basis_v771','canonical_entry_basis_v764','entry_check'):
                    b = snap.get(bk)
                    if isinstance(b, dict) and b: return b
    return {}


def _v771_has_basis(row: Dict[str, Any]) -> bool:  # type: ignore[override]
    return bool(_v772_find_entry_check(row))


def _v772_find_entry_record(row: Dict[str, Any]) -> Dict[str, Any]:
    if not isinstance(row, dict): return {}
    sources = [row]
    for k in ('entry_context','entry_diagnostics','raw','source_event'):
        v = row.get(k)
        if isinstance(v, dict): sources.append(v)
    for src in sources:
        for key in ('canonical_entry_snapshot_v772','entry_record_v772','canonical_entry_snapshot_v771','canonical_entry_snapshot_v764','canonical_entry_snapshot_v762','structure_snapshot_v762','canonical_entry_snapshot','entry_snapshot_v771','entry_snapshot_v762','entry_snapshot'):
            snap = src.get(key)
            if isinstance(snap, dict) and snap: return snap
    return {}


def _v772_find_chart_reaction(row: Dict[str, Any]) -> Dict[str, Any]:
    if not isinstance(row, dict): return {}
    for src in (row, row.get('entry_context'), row.get('entry_diagnostics'), row.get('raw')):
        if not isinstance(src, dict): continue
        v = src.get('chart_line_reaction_v772')
        if isinstance(v, dict) and v: return v
        snap = _v772_find_entry_record(src)
        v = snap.get('chart_line_reaction_v772') if isinstance(snap, dict) else {}
        if isinstance(v, dict) and v: return v
    snap = _v772_find_entry_record(row)
    v = snap.get('chart_line_reaction_v772') if isinstance(snap, dict) else {}
    return v if isinstance(v, dict) else {}


def _v771_has_structure_tag(row: Dict[str, Any]) -> bool:  # type: ignore[override]
    if not isinstance(row, dict): return False
    if _v772_find_chart_reaction(row): return True
    for src in (row, row.get('entry_context'), row.get('entry_diagnostics'), row.get('raw')):
        if not isinstance(src, dict): continue
        for k in ('chart_state_tags_v772','structure_tags','entry_structure_tags','structure_good_tags_v755','structure_bad_tags_v755','structure_recheck_tags_v755'):
            v = src.get(k)
            if isinstance(v, list) and v: return True
    snap = _v772_find_entry_record(row)
    if snap:
        st = snap.get('structure') if isinstance(snap.get('structure'), dict) else {}
        if isinstance(st.get('tags'), list) and st.get('tags'): return True
        tax = snap.get('structure_taxonomy_v755') if isinstance(snap.get('structure_taxonomy_v755'), dict) else snap.get('structure_taxonomy_v762') if isinstance(snap.get('structure_taxonomy_v762'), dict) else {}
        if any(tax.get(x) for x in ('good','bad','recheck')): return True
    return False


def _v772_counter_clean(counter: Any, limit: int = 5) -> str:
    if isinstance(counter, dict):
        items = sorted(counter.items(), key=lambda kv: (-int(kv[1] or 0), str(kv[0])))[:limit]
    elif isinstance(counter, Counter):
        items = counter.most_common(limit)
    else:
        items = []
    return ' / '.join(f'{k} {v}' for k,v in items if int(v or 0) > 0) or '없음'


def _v772_chart_reaction_summary_lines() -> List[str]:
    sc = _v650_load(BASE_DIR / 'clean_structure_snapshot_cache.json', {}) or {}
    age = _v650_file_age(BASE_DIR / 'clean_structure_snapshot_cache.json') if (BASE_DIR / 'clean_structure_snapshot_cache.json').exists() else 999999.0
    side = sc.get('chart_reaction_side_counts_v772') if isinstance(sc.get('chart_reaction_side_counts_v772'), dict) else {}
    tags = sc.get('chart_reaction_tag_counts_v772') if isinstance(sc.get('chart_reaction_tag_counts_v772'), dict) else {}
    sample = sc.get('chart_reaction_sample_v772') if isinstance(sc.get('chart_reaction_sample_v772'), list) else []
    pretty_side = {'good':'좋은 반응','risk':'위험 반응','mixed':'좋고 나쁨 섞임','wait':'확인 대기','neutral':'중립','unknown':'확인중'}
    side_pretty = Counter()
    for k,v in side.items(): side_pretty[pretty_side.get(str(k), str(k))] += int(v or 0)
    lines = [
        '🧭 차트선 반응 확인 · v773',
        f"- 차트선 반응 캐시: age {age:.1f}s / {_v772_counter_clean(dict(side_pretty), 6)}",
        '- 차트 반응 TOP: ' + _v772_counter_clean(tags, 8),
    ]
    samples = []
    for x in sample[:4]:
        if isinstance(x, dict):
            ts = x.get('tags') if isinstance(x.get('tags'), list) else []
            samples.append(f"{x.get('ticker','-')}({x.get('stage','-')}: {' / '.join(str(t) for t in ts[:3]) or x.get('side','-')})")
    if samples: lines.append('- 샘플: ' + ' / '.join(samples))
    lines.append('- 뜻: 지지/저항/VWAP/EMA 선을 가격이 어떻게 건드렸는지 보는 항목입니다. 아직 매수조건으로 쓰지 않습니다.')
    return lines


def _v772_ledger_check_lines() -> List[str]:
    open_obj = _v650_load(FILES.get('paper_open', BASE_DIR/'paper_bot_open.json'), {}) or {}
    open_rows: List[Dict[str, Any]] = []
    if isinstance(open_obj, dict):
        for key in ('positions','open','rows','items'):
            val = open_obj.get(key)
            if isinstance(val, list): open_rows=[x for x in val if isinstance(x, dict)]; break
            if isinstance(val, dict): open_rows=[x for x in val.values() if isinstance(x, dict)]; break
        if not open_rows and all(isinstance(v, dict) for v in open_obj.values()):
            open_rows=[x for x in open_obj.values() if isinstance(x, dict)]
    closed = _v771_closed_tail_rows(40) if '_v771_closed_tail_rows' in globals() else _v763_jsonl_tail(FILES.get('paper_closed', BASE_DIR/'paper_bot_closed.jsonl'), 40)
    open_check=sum(1 for r in open_rows if _v772_find_entry_check(r))
    open_chart=sum(1 for r in open_rows if _v772_find_chart_reaction(r) or _v771_has_structure_tag(r))
    closed_check=sum(1 for r in closed if _v772_find_entry_check(r))
    closed_chart=sum(1 for r in closed if _v772_find_chart_reaction(r) or _v771_has_structure_tag(r))
    sample='-'
    if closed:
        last=closed[-1]
        sample=f"{_v650_ticker(last)} / 진입 전 체크 {'있음' if _v772_find_entry_check(last) else '없음'} / 차트 모양 {'있음' if (_v772_find_chart_reaction(last) or _v771_has_structure_tag(last)) else '없음'}"
    lines=[
        '📒 청산 기록 전달 확인 · v773',
        f"- 현재 OPEN: {len(open_rows)}개 중 진입 전 체크 {open_check} / 차트 모양 {open_chart}",
        f"- 최근 청산 40건: 진입 전 체크 {closed_check} / 차트 모양 {closed_chart}",
        f"- 마지막 청산 샘플: {sample}",
    ]
    if len(open_rows)>0 and open_check==len(open_rows): lines.append('- 판정: OPEN까지 진입 전 체크 전달 OK. 다음 청산 후 기록 확인.')
    elif len(open_rows)>0: lines.append('- 판정: OPEN에 진입 전 체크 누락 있음. paper OPEN 저장부 확인 필요.')
    elif closed_check==0: lines.append('- 판정: 최근 청산은 구버전일 수 있음. 새 OPEN 청산 후 확인.')
    return lines


def _v772_basis_lines(compact: bool = False) -> List[str]:
    lines = _v766_basis_readable_lines(compact=compact) if '_v766_basis_readable_lines' in globals() else []
    return _v772_humanize_lines(lines)


def _v772_structure_lines() -> List[str]:
    lines = _v766_structure_cache_lines() if '_v766_structure_cache_lines' in globals() else []
    lines = _v772_humanize_lines(lines)
    # rename one confusing sentence if present
    return lines


def _v772_classify_text() -> str:
    cache = _v747_classify_cache()
    age_sec = _v650_file_age(BASE_DIR / 'paper_bot_classify_cache.json')
    lines = [
        '🧾 분류판 /classify · v773',
        f"- cache age {age_sec:.1f}s / paper {cache.get('paper_version','-')} / build {cache.get('build','-')}",
        '- 보는 법: 성과 → 진입 전 체크 → 차트선 반응 → 청산 기록 순서로 보면 됩니다. 조건값 변경 없음.',
        '', '1️⃣ 성과 요약', *_v766_perf_lines(cache),
        '', '2️⃣ 진입 전 체크', *_v772_basis_lines(compact=False),
        '', '2-1️⃣ 차트선 반응 확인', *_v772_chart_reaction_summary_lines()[1:],
        '', '2-2️⃣ 차트선/진입 전 체크 배관', *_v772_structure_lines(), *_v766_pipeline_readable_lines(), _v771_material_sample_lines()[0], *_v771_material_sample_lines()[1:],
        '', '2-3️⃣ 등급 전달 확인', *_v772_humanize_lines(_v771_grade_source_lines()),
        '', '2-4️⃣ 청산 기록 전달 확인', *_v772_ledger_check_lines(),
        '', '3️⃣ 손실군 원인 요약', *_v766_loss_lines(cache),
        '', '4️⃣ 청산/루프 확인', *_v747_exit_issue_lines(cache),
    ]
    # remove accidental duplicate sample lines while preserving order
    out=[]; seen=set()
    for ln in lines:
        key=ln if ln.startswith('- 샘플:') else None
        if key and key in seen: continue
        if key: seen.add(key)
        out.append(_v772_humanize_line(ln))
    return '\n'.join(out)


def _v772_paper_handoff_text() -> str:
    score, today, _, _ = _v650_score_stats(); review = _v650_review(); st = _v650_status()
    ver = str(st.get('paper_version') or st.get('version') or '-')
    build = str(st.get('build') or '-')
    ok = ('paper_bot_v0.795' in ver) 
    lines = [
        '📨 페이퍼 전달 /paper_handoff · v773', '',
        '① 적용 상태',
        f"- {'✅' if ok else '❌'} paper {ver} / build {build} / expected paper_bot_v0.795",
        f"- OPEN {_v650_open_count()} / status age {_v650_file_age(FILES.get('paper_status', BASE_DIR/'paper_bot_status.json')):.1f}s",
        '', '② 후보 전달', *_v650_pipeline_lines(), *_v650_candidate_lines(4),
        '', '③ S1 대기/페이퍼 소비', *_v743_s1_hold_lines(), *_v743_paper_hold_trace_lines()[:3], f"- score/review 오늘 {score.get('today_closed_count', today['n'])} / {review.get('today_closed_count','-')}",
        '', '④ 진입 전 체크', *_v772_basis_lines(compact=False),
        '', '⑤ 차트선 반응 확인', *_v772_chart_reaction_summary_lines()[1:],
        '', '⑥ 등급 전달 확인', *_v772_humanize_lines(_v771_grade_source_lines()),
        '', '⑦ 청산 기록 전달 확인', *_v772_ledger_check_lines(),
        '', '⑧ 요약 알림', *_v650_hourly_lines(),
    ]
    return '\n'.join(_v772_humanize_line(x) for x in lines)


def _v772_health_text() -> str:
    base = _v771_health_text() if '_v771_health_text' in globals() else COMMANDS.get('health', _v743_health_text)()
    # Keep health concise; append only chart-reaction summary.
    cr = _v772_chart_reaction_summary_lines()
    return base.rstrip() + '\n\n[차트선 반응]\n- ' + (cr[1].replace('- ', '') if len(cr) > 1 else '준비중') + '\n- ' + (cr[2].replace('- ', '') if len(cr) > 2 else '')

COMMANDS['classify'] = _v772_classify_text
COMMANDS['review_board'] = _v772_classify_text
COMMANDS['paper_handoff'] = _v772_paper_handoff_text
COMMANDS['handoff'] = _v772_paper_handoff_text
COMMANDS['health'] = _v772_health_text
COMMANDS['core'] = _v772_health_text
COMMANDS['deploy'] = _v772_health_text
COMMANDS['upgradestatus'] = _v772_health_text


# =============================================================================
# main_bot v773: structure-first routing + chart reaction performance check
# - Keeps easy terms from v772.
# - Makes structure route visible: S1 possible / S2 recheck / risk block / observe.
# - Moves closed-ledger delivery check and chart reaction performance near the top.
# =============================================================================
V650_BUILD_LABEL = 'v806_integrated_validation_freshness_2026-06-10'


def _v773_load_structure_cache() -> Dict[str, Any]:
    for path in (BASE_DIR / 'clean_structure_snapshot_cache.json', BASE_DIR / 'structure_snapshot_cache.json'):
        try:
            obj = _v650_load(path, {}) if '_v650_load' in globals() else {}
            if isinstance(obj, dict) and obj:
                return obj
        except Exception:
            pass
    return {}


def _v773_counter_text(d: Any, limit: int = 5) -> str:
    if isinstance(d, dict):
        items = sorted(d.items(), key=lambda kv: (-int(kv[1] or 0), str(kv[0])))[:limit]
    else:
        items = []
    return ' / '.join(f'{k} {v}' for k,v in items if int(v or 0)>0) or '없음'


def _v773_structure_route_lines() -> List[str]:
    c = _v773_load_structure_cache()
    age = _v650_file_age(BASE_DIR / 'clean_structure_snapshot_cache.json') if (BASE_DIR / 'clean_structure_snapshot_cache.json').exists() else 999999.0
    routes = c.get('structure_first_route_counts_v773') if isinstance(c.get('structure_first_route_counts_v773'), dict) else {}
    stages = c.get('structure_first_route_stage_counts_v773') if isinstance(c.get('structure_first_route_stage_counts_v773'), dict) else {}
    sample = c.get('structure_first_route_sample_v773') if isinstance(c.get('structure_first_route_sample_v773'), list) else []
    samples=[]
    for x in sample[:5]:
        if isinstance(x, dict):
            why = x.get('why') if isinstance(x.get('why'), list) else []
            samples.append(f"{x.get('ticker','-')}({x.get('stage','-')}: {x.get('route','-')} · {' / '.join(str(w) for w in why[:2])})")
    return [
        '🧭 구조 우선 진입 판단 · v773',
        f"- 구조 판단 캐시: age {age:.1f}s / {_v773_counter_text(routes, 4)}",
        f"- 현재 등급별 구조판단 TOP: {_v773_counter_text(stages, 6)}",
        '- 샘플: ' + (' / '.join(samples) if samples else '준비중'),
        '- 뜻: 차트 구조가 확실하면 S1 후보, 구조는 괜찮지만 확인이 부족하면 S2 재확인, 위험 구조는 S1 보류·재확인 쪽으로 보는 분류입니다.',
    ]


def _v773_closed_tail() -> List[Dict[str, Any]]:
    try:
        return _v771_closed_tail_rows(60) if '_v771_closed_tail_rows' in globals() else []
    except Exception:
        try:
            return _v763_jsonl_tail(FILES.get('paper_closed', BASE_DIR/'paper_bot_closed.jsonl'), 60)
        except Exception:
            return []


def _v773_row_pnl(row: Dict[str, Any]) -> float:
    for k in ('pnl_pct','profit_pct','ret_pct','return_pct'):
        try:
            if row.get(k) is not None:
                return float(row.get(k))
        except Exception:
            pass
    return 0.0


def _v779_chart_reaction_for_perf(row: Dict[str, Any]) -> Dict[str, Any]:
    react = _v772_find_chart_reaction(row) if '_v772_find_chart_reaction' in globals() else {}
    if isinstance(react, dict) and react:
        return react
    tags=[]
    for src in (row, row.get('entry_context'), row.get('entry_diagnostics'), row.get('raw')):
        if not isinstance(src, dict):
            continue
        for k in ('chart_state_tags_v772','structure_tags','entry_structure_tags','structure_good_tags_v755','structure_bad_tags_v755','structure_recheck_tags_v755'):
            v=src.get(k)
            if isinstance(v, list): tags.extend(str(x) for x in v[:10])
    snap = _v772_find_entry_record(row) if '_v772_find_entry_record' in globals() else {}
    if isinstance(snap, dict):
        for k in ('chart_state_tags_v772','structure_tags','entry_structure_tags'):
            v=snap.get(k)
            if isinstance(v, list): tags.extend(str(x) for x in v[:10])
    tags=list(dict.fromkeys([t for t in tags if t]))
    if not tags:
        return {}
    joined=' / '.join(tags)
    if any(w in joined for w in ('저항 바로 아래','윗꼬리','VWAP·EMA 아래','지지선 이탈','가짜 돌파','밀림')):
        side='risk'
    elif any(w in joined for w in ('지지선 터치 후 반등','지지선 위에서 유지','VWAP·EMA 위 유지','박스 상단 돌파','저점 쓸림','매수세 확인')):
        side='good'
    elif any(w in joined for w in ('대기','근처','재확인')):
        side='wait'
    else:
        side='mixed'
    return {'schema':'chart_perf_from_tags_v779','side':side,'tags':tags,'source':'chart_tags_fallback_v779'}

def _v773_chart_perf_lines() -> List[str]:
    rows = _v773_closed_tail()
    groups: Dict[str, List[float]] = {}
    tag_groups: Dict[str, List[float]] = {}
    known = 0
    for r in rows:
        if not isinstance(r, dict):
            continue
        react = _v779_chart_reaction_for_perf(r) if '_v779_chart_reaction_for_perf' in globals() else (_v772_find_chart_reaction(r) if '_v772_find_chart_reaction' in globals() else {})
        if not react:
            continue
        known += 1
        side = str(react.get('side') or '확인중')
        p = _v773_row_pnl(r)
        groups.setdefault(side, []).append(p)
        for t in (react.get('tags') if isinstance(react.get('tags'), list) else [])[:6]:
            tag_groups.setdefault(str(t), []).append(p)
    def fmt(name, vals):
        n=len(vals); win=sum(1 for x in vals if x>0); s=sum(vals); avg=s/n if n else 0.0
        icon='✅' if avg>0 else '❌' if avg<0 else '⚠️'
        return f"{icon} {name}: {n}전 {win}승 {n-win}패 / 합산 {s:+.2f}% / 평균 {avg:+.2f}%"
    order=[('good','좋은 반응'),('mixed','좋고 나쁨 섞임'),('risk','위험 반응'),('wait','확인 대기'),('neutral','중립')]
    lines=['📊 차트선 반응별 성과 · v773']
    if known == 0:
        lines.append(f"- 최근 청산 {len(rows)}건 중 차트선 반응 기록 0건")
        lines.append('- 판정: 새 v772/v773 OPEN이 청산된 뒤부터 성과가 보입니다.')
        return lines
    lines.append(f"- 최근 청산 {len(rows)}건 중 차트선 반응 기록 {known}건")
    for key, label in order:
        if key in groups:
            lines.append('- ' + fmt(label, groups[key]))
    # show worst and best tags with enough samples
    tag_items=[]
    for t, vals in tag_groups.items():
        if len(vals) >= 1:
            tag_items.append((sum(vals)/len(vals), t, vals))
    tag_items.sort(key=lambda x: x[0])
    bad = [f"{t} {len(vals)}전 평균 {avg:+.2f}%" for avg,t,vals in tag_items[:4] if avg < 0]
    good = [f"{t} {len(vals)}전 평균 {avg:+.2f}%" for avg,t,vals in tag_items[::-1][:4] if avg > 0]
    lines.append('- 손실 구조 TOP: ' + (' / '.join(bad) if bad else '표본 부족'))
    lines.append('- 수익 구조 TOP: ' + (' / '.join(good) if good else '표본 부족'))
    return lines


def _v773_ledger_check_lines() -> List[str]:
    # Same data as v772, but clearer and shorter so it is not hidden below long sections.
    base = _v772_ledger_check_lines() if '_v772_ledger_check_lines' in globals() else []
    out=[]
    for ln in base:
        ln = _v772_humanize_line(ln) if '_v772_humanize_line' in globals() else str(ln)
        ln = ln.replace('차트 모양', '차트선 반응/모양')
        out.append(ln)
    return out


def _v773_classify_text() -> str:
    cache = _v747_classify_cache()
    age_sec = _v650_file_age(BASE_DIR / 'paper_bot_classify_cache.json')
    lines = [
        '🧾 분류판 /classify · v773',
        f"- cache age {age_sec:.1f}s / paper {cache.get('paper_version','-')} / build {cache.get('build','-')}",
        '- 보는 법: 성과 → 청산 기록 전달 → 구조 우선 판단 → 차트선 성과 순서로 확인합니다. 조건값 변경 없음.',
        '', '1️⃣ 성과 요약', *_v766_perf_lines(cache),
        '', '2️⃣ 청산 기록 전달 확인', *_v773_ledger_check_lines(),
        '', '3️⃣ 구조 우선 진입 판단', *_v773_structure_route_lines()[1:],
        '', '4️⃣ 차트선 반응별 성과', *_v773_chart_perf_lines()[1:],
        '', '5️⃣ 진입 전 체크', *_v772_basis_lines(compact=False),
        '', '6️⃣ 차트선 반응 현재상태', *_v772_chart_reaction_summary_lines()[1:],
        '', '7️⃣ 손실군 원인 요약', *_v766_loss_lines(cache),
        '', '8️⃣ 청산/루프 확인', *_v747_exit_issue_lines(cache),
    ]
    out=[]; seen=set()
    for ln in lines:
        key=ln if str(ln).startswith('- 샘플:') else None
        if key and key in seen: continue
        if key: seen.add(key)
        out.append(_v772_humanize_line(ln) if '_v772_humanize_line' in globals() else str(ln))
    return '\n'.join(out)


def _v773_paper_handoff_text() -> str:
    score, today, _, _ = _v650_score_stats(); review = _v650_review(); st = _v650_status()
    ver = str(st.get('paper_version') or st.get('version') or '-')
    build = str(st.get('build') or '-')
    ok = ('paper_bot_v0.795' in ver) 
    lines = [
        '📨 페이퍼 전달 /paper_handoff · v773', '',
        '① 적용 상태',
        f"- {'✅' if ok else '❌'} paper {ver} / build {build} / expected paper_bot_v0.795",
        f"- OPEN {_v650_open_count()} / status age {_v650_file_age(FILES.get('paper_status', BASE_DIR/'paper_bot_status.json')):.1f}s",
        '', '② 후보 전달', *_v650_pipeline_lines(), *_v650_candidate_lines(4),
        '', '③ S1 대기/페이퍼 소비', *_v743_s1_hold_lines(), *_v743_paper_hold_trace_lines()[:3], f"- score/review 오늘 {score.get('today_closed_count', today['n'])} / {review.get('today_closed_count','-')}",
        '', '④ 구조 우선 진입 판단', *_v773_structure_route_lines()[1:],
        '', '⑤ 진입 전 체크', *_v772_basis_lines(compact=False),
        '', '⑥ 차트선 반응 확인', *_v772_chart_reaction_summary_lines()[1:],
        '', '⑦ 청산 기록 전달 확인', *_v773_ledger_check_lines(),
        '', '⑧ 요약 알림', *_v650_hourly_lines(),
    ]
    return '\n'.join(_v772_humanize_line(x) if '_v772_humanize_line' in globals() else str(x) for x in lines)


def _v773_health_text() -> str:
    base = _v772_health_text() if '_v772_health_text' in globals() else COMMANDS.get('health', _v743_health_text)()
    route = _v773_structure_route_lines()
    perf = _v773_chart_perf_lines()
    return base.rstrip() + '\n\n[구조 우선 판단]\n- ' + (route[1].replace('- ', '') if len(route)>1 else '준비중') + '\n- ' + (perf[1].replace('- ', '') if len(perf)>1 else '성과 준비중')

COMMANDS['classify'] = _v773_classify_text
COMMANDS['review_board'] = _v773_classify_text
COMMANDS['paper_handoff'] = _v773_paper_handoff_text
COMMANDS['handoff'] = _v773_paper_handoff_text
COMMANDS['health'] = _v773_health_text
COMMANDS['core'] = _v773_health_text
COMMANDS['deploy'] = _v773_health_text
COMMANDS['upgradestatus'] = _v773_health_text



# =============================================================================
# main_bot v774: applied structure routing + observation queue + ledger check view
# - Easy wording stays. Reads v774 routing/queue caches and v774 ledger keys.
# =============================================================================
V650_BUILD_LABEL = 'v806_integrated_validation_freshness_2026-06-10'
MAIN_DEPLOY_VERSION = 'v2.13.781'
MAIN_BOT_VERSION = '수익형 v2.13.806'


def _v774_load_json(path: Path) -> Dict[str, Any]:
    try:
        obj = _v650_load(path, {}) if '_v650_load' in globals() else {}
        return obj if isinstance(obj, dict) else {}
    except Exception:
        return {}


def _v774_find_entry_check(row: Dict[str, Any]) -> Dict[str, Any]:
    if not isinstance(row, dict): return {}
    sources=[row]
    for k in ('entry_context','entry_diagnostics','raw','source_event'):
        v=row.get(k)
        if isinstance(v, dict): sources.append(v)
    for src in sources:
        for key in ('canonical_entry_basis_v774','entry_check_v774','canonical_entry_basis_v772','entry_check_v772','canonical_entry_basis_v771','canonical_entry_basis_v764','entry_check'):
            v=src.get(key)
            if isinstance(v, dict) and v: return v
        for sk in ('canonical_entry_snapshot_v774','entry_record_v774','canonical_entry_snapshot_v772','entry_record_v772','canonical_entry_snapshot_v773','canonical_entry_snapshot_v762','canonical_entry_snapshot','entry_snapshot'):
            snap=src.get(sk)
            if isinstance(snap, dict):
                for bk in ('canonical_entry_basis_v774','entry_check_v774','canonical_entry_basis_v772','entry_check_v772','canonical_entry_basis_v764','entry_check'):
                    b=snap.get(bk)
                    if isinstance(b, dict) and b: return b
    return {}


def _v774_find_route(row: Dict[str, Any]) -> Dict[str, Any]:
    if not isinstance(row, dict): return {}
    sources=[row]
    for k in ('entry_context','entry_diagnostics','raw','source_event'):
        v=row.get(k)
        if isinstance(v, dict): sources.append(v)
    for src in sources:
        for key in ('structure_route_applied_v774','structure_first_route_v774','structure_first_route_v773'):
            v=src.get(key)
            if isinstance(v, dict) and v: return v
        for sk in ('canonical_entry_snapshot_v774','entry_record_v774','canonical_entry_snapshot_v772','entry_record_v772','canonical_entry_snapshot_v762','canonical_entry_snapshot','entry_snapshot'):
            snap=src.get(sk)
            if isinstance(snap, dict):
                for key in ('structure_route_applied_v774','structure_first_route_v774','structure_first_route_v773'):
                    v=snap.get(key)
                    if isinstance(v, dict) and v: return v
    return {}


def _v774_counter_text(d: Any, limit: int = 6) -> str:
    if isinstance(d, dict):
        items=sorted(d.items(), key=lambda kv:(-int(kv[1] or 0), str(kv[0])))[:limit]
    else: items=[]
    return ' / '.join(f'{k} {v}' for k,v in items if int(v or 0)>0) or '없음'


def _v774_route_apply_lines() -> List[str]:
    cache=_v773_load_structure_cache() if '_v773_load_structure_cache' in globals() else _v774_load_json(BASE_DIR/'clean_structure_snapshot_cache.json')
    obj=cache.get('structure_route_apply_summary_v774') if isinstance(cache.get('structure_route_apply_summary_v774'), dict) else {}
    if not obj:
        return ['🧭 구조 우선 라우팅 적용 · v782', '- 적용 캐시 준비중']
    before=obj.get('before_stage_counts') if isinstance(obj.get('before_stage_counts'), dict) else {}
    after=obj.get('after_stage_counts') if isinstance(obj.get('after_stage_counts'), dict) else {}
    actions=obj.get('action_counts') if isinstance(obj.get('action_counts'), dict) else {}
    samples=obj.get('sample') if isinstance(obj.get('sample'), list) else []
    s2_samples=obj.get('s2_recheck_sample') if isinstance(obj.get('s2_recheck_sample'), list) else obj.get('strict_s3_to_s2_sample') if isinstance(obj.get('strict_s3_to_s2_sample'), list) else []
    s=[]
    for x in samples[:5]:
        if isinstance(x, dict):
            s.append(f"{x.get('ticker','-')}({x.get('before','-')}→{x.get('after','-')}: {x.get('action','-')})")
    ss=[]
    for x in s2_samples[:5]:
        if isinstance(x, dict):
            d=x.get('s2_detail') if isinstance(x.get('s2_detail'), dict) else x.get('strict_detail') if isinstance(x.get('strict_detail'), dict) else {}
            hits=d.get('confirm_hits') if isinstance(d.get('confirm_hits'), list) else []
            miss=d.get('missing_confirmations') if isinstance(d.get('missing_confirmations'), list) else []
            pr=str(d.get('s2_priority') or 'S2재확인')
            risk=x.get('risk') if isinstance(x.get('risk'), dict) else {}
            risk_txt='주의' if risk.get('caution') else '정상'
            basis=('/'.join(str(h) for h in hits[:2]) or '구조우선')
            lack=('/'.join(str(m) for m in miss[:2]) or '부족값없음')
            ss.append(f"{x.get('ticker','-')}({pr}/{risk_txt}/{basis}/부족:{lack})")
    s2=int(obj.get('s2_recheck_promoted') or obj.get('true_structure_s3_to_s2') or obj.get('s3_to_s2') or 0)
    weak=int(obj.get('weak_recheck_s3_kept') or 0)
    hard=int(obj.get('hard_risk_to_s3') or 0)
    caution_to_s2=int(obj.get('caution_to_s2') or 0)
    caution_kept=int(obj.get('caution_kept') or 0)
    return [
        '🧭 구조 우선 라우팅 적용 · v782',
        f"- 적용 전 등급: {_v774_counter_text(before, 4)}",
        f"- 적용 후 등급: {_v774_counter_text(after, 4)}",
        f"- 적용 내용: {_v774_counter_text(actions, 8)}",
        f"- S2 재확인 승격: {s2} / 주의구조 S2유지·승격: {caution_to_s2} / 구조는 있으나 S3유지: {weak} / 하드위험 S3관찰: {hard} / 주의구조 S3유지: {caution_kept} / S1 가능: {obj.get('structure_good_to_s1',0)}",
        '- S2 재확인 샘플: ' + (' / '.join(ss) if ss else '없음'),
        '- 전체 샘플: ' + (' / '.join(s) if s else '준비중'),
        '- 뜻: S1은 그대로 빡세게 두고, S2는 매수 후보가 아니라 구조 좋은 애를 다시 확인하는 대기줄입니다. 확인값 부족은 차단이 아니라 재확인 우선순위입니다.',
    ]

def _v774_observation_queue_lines() -> List[str]:
    q=_v774_load_json(BASE_DIR/'clean_structure_observation_queue_v774.json')
    if not q:
        return ['🔄 구조 관찰 큐 · v782', '- 큐 준비중']
    buckets=q.get('buckets') if isinstance(q.get('buckets'), dict) else {}
    rows=q.get('rows') if isinstance(q.get('rows'), list) else []
    sample=[]
    for x in rows[:5]:
        if isinstance(x, dict): sample.append(f"{x.get('ticker','-')}({x.get('bucket','-')}/{x.get('stage','-')})")
    pretty={
        'structure_core_open_s1':'최우선 OPEN/S1',
        'structure_recheck_s2':'자주 갱신 S2/재확인',
        'structure_good_s3_watch':'중간 갱신 구조좋은 S3',
        'structure_recheck_s3_watch':'중간 갱신 재확인 S3',
        'structure_coverage_slow':'느린 순환 coverage',
    }
    pb={pretty.get(k,k):v for k,v in buckets.items()}
    age=_v650_file_age(BASE_DIR/'clean_structure_observation_queue_v774.json') if (BASE_DIR/'clean_structure_observation_queue_v774.json').exists() else 999999.0
    return [
        '🔄 구조 관찰 큐 · v782',
        f"- age {age:.1f}s / 전체 {q.get('count', len(rows))}개 / {_v774_counter_text(pb, 6)}",
        '- 우선순위: OPEN/S1 최우선 → S2 자주 → 구조좋은 S3 중간 → coverage 느린 순환',
        '- 샘플: ' + (' / '.join(sample) if sample else '준비중'),
    ]


def _v774_ledger_check_lines() -> List[str]:
    open_obj=_v650_load(FILES.get('paper_open', BASE_DIR/'paper_bot_open.json'), {}) or {}
    open_rows=[]
    if isinstance(open_obj, dict):
        for key in ('positions','open','rows','items'):
            val=open_obj.get(key)
            if isinstance(val, list): open_rows=[x for x in val if isinstance(x, dict)]; break
            if isinstance(val, dict): open_rows=[x for x in val.values() if isinstance(x, dict)]; break
        if not open_rows and all(isinstance(v, dict) for v in open_obj.values()): open_rows=[x for x in open_obj.values() if isinstance(x, dict)]
    closed=_v773_closed_tail() if '_v773_closed_tail' in globals() else []
    open_check=sum(1 for r in open_rows if _v774_find_entry_check(r))
    open_chart=sum(1 for r in open_rows if (_v772_find_chart_reaction(r) if '_v772_find_chart_reaction' in globals() else {}) or (_v771_has_structure_tag(r) if '_v771_has_structure_tag' in globals() else False))
    open_route=sum(1 for r in open_rows if _v774_find_route(r))
    closed_check=sum(1 for r in closed if _v774_find_entry_check(r))
    closed_chart=sum(1 for r in closed if (_v772_find_chart_reaction(r) if '_v772_find_chart_reaction' in globals() else {}) or (_v771_has_structure_tag(r) if '_v771_has_structure_tag' in globals() else False))
    closed_route=sum(1 for r in closed if _v774_find_route(r))
    sample='-'
    if closed:
        last=closed[-1]
        sample=f"{_v650_ticker(last)} / 진입 전 체크 {'있음' if _v774_find_entry_check(last) else '없음'} / 차트선 {'있음' if ((_v772_find_chart_reaction(last) if '_v772_find_chart_reaction' in globals() else {}) or (_v771_has_structure_tag(last) if '_v771_has_structure_tag' in globals() else False)) else '없음'} / 구조판단 {'있음' if _v774_find_route(last) else '없음'}"
    lines=[
        '📒 청산 기록 전달 확인 · v782',
        f"- 현재 OPEN: {len(open_rows)}개 중 진입 전 체크 {open_check} / 차트선 반응 {open_chart} / 구조판단 {open_route}",
        f"- 최근 청산 {len(closed)}건: 진입 전 체크 {closed_check} / 차트선 반응 {closed_chart} / 구조판단 {closed_route}",
        f"- 마지막 청산 샘플: {sample}",
    ]
    if open_rows and open_check==len(open_rows) and open_route==len(open_rows): lines.append('- 판정: OPEN까지 전달 OK. 청산 후 같은 값이 남는지 확인.')
    elif open_rows: lines.append('- 판정: OPEN에 일부 누락 있음. paper OPEN 저장부 확인 필요.')
    elif closed_check==0: lines.append('- 판정: 최근 청산은 구버전일 수 있음. 새 OPEN 청산 후 확인.')
    return lines


def _v774_classify_text() -> str:
    cache=_v747_classify_cache()
    age_sec=_v650_file_age(BASE_DIR/'paper_bot_classify_cache.json')
    lines=[
        '🧾 분류판 /classify · v798',
        f"- cache age {age_sec:.1f}s / paper {cache.get('paper_version','-')} / build {cache.get('build','-')}",
        '- 보는 법: 성과 → 구조 라우팅 → 구조 관찰 큐 → 청산 기록 순서로 확인합니다. 조건값/청산값 변경 없음.',
        '', '1️⃣ 성과 요약', *_v766_perf_lines(cache),
        '', '2️⃣ 구조 우선 라우팅 적용', *_v774_route_apply_lines()[1:],
        '', '3️⃣ 구조 관찰 큐', *_v774_observation_queue_lines()[1:],
        '', '4️⃣ 청산 기록 전달 확인', *_v774_ledger_check_lines(),
        '', '5️⃣ 차트선 반응별 성과', *_v773_chart_perf_lines()[1:],
        '', '6️⃣ 진입 전 체크', *_v772_basis_lines(compact=False),
        '', '7️⃣ 손실군 원인 요약', *_v766_loss_lines(cache),
        '', '8️⃣ 청산/루프 확인', *_v747_exit_issue_lines(cache),
    ]
    return '\n'.join(_v772_humanize_line(x) if '_v772_humanize_line' in globals() else str(x) for x in lines)


def _v774_paper_handoff_text() -> str:
    score,today,_,_=_v650_score_stats(); review=_v650_review(); st=_v650_status()
    ver=str(st.get('paper_version') or st.get('version') or '-')
    build=str(st.get('build') or '-')
    ok=('paper_bot_v0.795' in ver) 
    lines=[
        '📨 페이퍼 전달 /paper_handoff · v798','',
        '① 적용 상태', f"- {'✅' if ok else '❌'} paper {ver} / build {build} / expected paper_bot_v0.795", f"- OPEN {_v650_open_count()} / status age {_v650_file_age(FILES.get('paper_status', BASE_DIR/'paper_bot_status.json')):.1f}s",
        '', '② 후보 전달', *_v650_pipeline_lines(), *_v650_candidate_lines(4),
        '', '③ S1 대기/페이퍼 소비', *_v743_s1_hold_lines(), *_v743_paper_hold_trace_lines()[:3], f"- score/review 오늘 {score.get('today_closed_count', today['n'])} / {review.get('today_closed_count','-')}",
        '', '④ 구조 우선 라우팅 적용', *_v774_route_apply_lines()[1:],
        '', '⑤ 구조 관찰 큐', *_v774_observation_queue_lines()[1:],
        '', '⑥ 진입 전 체크', *_v772_basis_lines(compact=False),
        '', '⑦ 차트선 반응 확인', *_v772_chart_reaction_summary_lines()[1:],
        '', '⑧ 청산 기록 전달 확인', *_v774_ledger_check_lines(),
        '', '⑨ 요약 알림', *_v650_hourly_lines(),
    ]
    return '\n'.join(_v772_humanize_line(x) if '_v772_humanize_line' in globals() else str(x) for x in lines)


def _v774_health_text() -> str:
    base=_v773_health_text() if '_v773_health_text' in globals() else COMMANDS.get('health', _v743_health_text)()
    r=_v774_route_apply_lines(); q=_v774_observation_queue_lines()
    return base.rstrip()+"\n\n[구조 라우팅 v787]\n- "+(r[2].replace('- ','') if len(r)>2 else '준비중')+"\n- "+(q[1].replace('- ','') if len(q)>1 else '구조 관찰 큐 준비중')

COMMANDS['classify']=_v774_classify_text
COMMANDS['review_board']=_v774_classify_text
COMMANDS['paper_handoff']=_v774_paper_handoff_text
COMMANDS['handoff']=_v774_paper_handoff_text
COMMANDS['health']=_v774_health_text
COMMANDS['core']=_v774_health_text
COMMANDS['deploy']=_v774_health_text
COMMANDS['upgradestatus']=_v774_health_text


# =============================================================================
# main_bot v784: command source unification + recheck freshness board
# - /health, /paper_handoff, /classify read the same candidate snapshot counts.
# - Active paper version is shown only from paper_bot_status.json.
# - Old v771 tail-count diagnostic is no longer consumed by basic health.
# - /paper_handoff 기본 출력 avoids repeated heavy blocks; full diagnostics remain in dedicated commands.

def _v783_active_paper_line(expected: str = 'paper_bot_v0.795') -> List[str]:
    st = _v650_status()
    ver = str(st.get('paper_version') or st.get('version') or '-')
    build = str(st.get('build') or '-')
    age_sec = _v650_file_age(FILES.get('paper_status', BASE_DIR/'paper_bot_status.json'))
    ok = expected in ver
    icon = '✅' if ok and age_sec < 90 else ('⚠️' if ok else '❌')
    return [f"- {icon} active paper(status): {ver} / build {build} / expected {expected} / age {age_sec:.1f}s"]


def _v783_candidate_unified_lines() -> List[str]:
    snap = _v650_candidate_snapshot()
    c = snap.get('counts') if isinstance(snap.get('counts'), Counter) else Counter(snap.get('counts') or {})
    all_c = snap.get('all_counts') if isinstance(snap.get('all_counts'), Counter) else Counter(snap.get('all_counts') or {})
    return [
        f"- 후보 snapshot: S1 {int(c.get('S1',0))} / S2 {int(c.get('S2',0))} / S3 {int(c.get('S3',0))} / 실전후보 {len(snap.get('trade_rows') or [])} / coverage {len(snap.get('coverage_rows') or [])} / raw S3 {int(all_c.get('S3',0))} / age {float(snap.get('file_age') or 0.0):.1f}s",
        "- 기준: 모든 기본 명령은 paper_candidates_latest.jsonl canonical snapshot 기준. 구 v771 tail 진단은 기본 출력에서 제외.",
    ]


def _v787_recheck_freshness_base_lines() -> List[str]:
    sw = worker_status('strategy')
    tw = worker_status('target_router')
    cand_age = _v650_file_age(FILES.get('paper_latest', BASE_DIR/'paper_candidates_latest.jsonl'))
    route_age = _v650_file_age(BASE_DIR/'clean_structure_snapshot_cache.json')
    queue_age = _v650_file_age(BASE_DIR/'clean_structure_observation_queue_v774.json')
    hand_age = _v650_file_age(FILES.get('paper_handoff', BASE_DIR/'clean_strategy_paper_handoff_status.json'))
    warn = []
    if float(sw.get('age') or 999999) >= 60: warn.append('strategy status 60초+ 지연')
    if cand_age >= 60: warn.append('후보 snapshot 60초+ 지연')
    if queue_age >= 60: warn.append('구조 관찰 큐 60초+ 지연')
    if hand_age >= 60: warn.append('paper handoff 60초+ 지연')
    icon = '⚠️' if warn else '✅'
    return [
        f"{icon} 재확인 배관: strategy status {float(sw.get('age') or 0):.1f}s/rows {sw.get('row_count','-')} · candidate {cand_age:.1f}s · structure {route_age:.1f}s · queue {queue_age:.1f}s · target_router {float(tw.get('age') or 0):.1f}s · handoff {hand_age:.1f}s",
        '- 판정: ' + (' / '.join(warn) if warn else '재확인 캐시 최신권'),
    ]


def _v783_health_text() -> str:
    st = _v650_status()
    lines = ['🧭 상태 /health · v798']
    lines += _v743_section('① 봇/worker') + [
        f"- 메인봇: {BOT_VERSION} / {V650_BUILD_LABEL}",
        f"- paper: {st.get('version','-')} / build {st.get('build','-')} / OPEN {_v650_open_count()}",
        _v650_worker_line(),
        '', '[worker 9개 age]', *_v747_worker_age_lines(full=True),
    ]
    lines += _v743_section('② 후보/재확인 source') + _v783_candidate_unified_lines() + _v787_recheck_freshness_lines()
    lines += _v743_section('③ 자원') + _v650_resource_lines()
    lines += _v743_section('④ 정리/보관') + _v678_cleanup_lines() + _v743_stop_recent_lines()
    lines += _v743_section('⑤ 요약/원문 묶음') + _v650_hourly_lines()
    lines += ['', '[구조 라우팅 v787]', '- ' + (_v774_route_apply_lines()[2].replace('- ', '') if len(_v774_route_apply_lines())>2 else '구조 라우팅 준비중'), '- ' + (_v774_observation_queue_lines()[1].replace('- ', '') if len(_v774_observation_queue_lines())>1 else '구조 관찰 큐 준비중')]
    return '\n'.join(lines)


def _v783_paper_handoff_text() -> str:
    score, today, _, _ = _v650_score_stats(); review = _v650_review()
    lines = [
        '📨 페이퍼 전달 /paper_handoff · v798','',
        '① 적용 상태', *_v783_active_paper_line('paper_bot_v0.795'), f"- OPEN {_v650_open_count()}",
        '', '② 후보 전달', *_v650_pipeline_lines(), *_v650_candidate_lines(4),
        '', '③ 재확인 배관', *_v787_recheck_freshness_lines(),
        '', '④ S1 대기/페이퍼 소비', *_v743_s1_hold_lines(), *_v743_paper_hold_trace_lines()[:3], f"- score/review 오늘 {score.get('today_closed_count', today['n'])} / {review.get('today_closed_count','-')}",
        '', '⑤ 구조 우선 라우팅 적용', *_v774_route_apply_lines()[1:],
        '', '⑥ 구조 관찰 큐', *_v774_observation_queue_lines()[1:],
        '', '⑦ 청산 기록 전달 확인', *_v774_ledger_check_lines(),
    ]
    return '\n'.join(_v772_humanize_line(x) if '_v772_humanize_line' in globals() else str(x) for x in lines)


def _v783_classify_text() -> str:
    cache = _v747_classify_cache()
    age_sec = _v650_file_age(BASE_DIR/'paper_bot_classify_cache.json')
    lines = [
        '🧾 분류판 /classify · v798',
        *_v783_active_paper_line('paper_bot_v0.795'),
        f"- classify cache: age {age_sec:.1f}s / writer paper {cache.get('paper_version','-')} / build {cache.get('build','-')}",
        '- 보는 법: 후보 snapshot → 재확인 배관 → 성과 → 구조 라우팅 순서로 확인합니다.',
        '', '0️⃣ 후보/재확인 source', *_v783_candidate_unified_lines(), *_v787_recheck_freshness_lines(),
        '', '1️⃣ 성과 요약', *_v766_perf_lines(cache),
        '', '2️⃣ 구조 우선 라우팅 적용', *_v774_route_apply_lines()[1:],
        '', '3️⃣ 구조 관찰 큐', *_v774_observation_queue_lines()[1:],
        '', '4️⃣ 청산 기록 전달 확인', *_v774_ledger_check_lines(),
        '', '5️⃣ 차트선 반응별 성과', *_v773_chart_perf_lines()[1:],
        '', '6️⃣ 손실군 원인 요약', *_v766_loss_lines(cache),
        '', '7️⃣ 청산/루프 확인', *_v747_exit_issue_lines(cache),
    ]
    return '\n'.join(_v772_humanize_line(x) if '_v772_humanize_line' in globals() else str(x) for x in lines)

COMMANDS['health'] = _v783_health_text
COMMANDS['core'] = _v783_health_text
COMMANDS['deploy'] = _v783_health_text
COMMANDS['upgradestatus'] = _v783_health_text
COMMANDS['paper_handoff'] = _v783_paper_handoff_text
COMMANDS['handoff'] = _v783_paper_handoff_text
COMMANDS['classify'] = _v783_classify_text
COMMANDS['review_board'] = _v783_classify_text
# keep the previous heavier board under a stable full command before redefining the light board.
_v783_classify_full_text = _v783_classify_text


# =============================================================================
# main_bot v784: strategy bottleneck + cleanup report + lighter default classify/errorlog
# =============================================================================

def _v783_cleanup_lines() -> List[str]:
    st = _v650_status()
    clean = _v650_load(BASE_DIR / 'paper_bot_cleanup_state.json', {})
    if not isinstance(clean, dict) or not clean:
        clean = st.get('cleanup_state') if isinstance(st.get('cleanup_state'), dict) else {}
    base = _v678_cleanup_lines()
    if not isinstance(clean, dict) or not clean:
        return base + ['- cleanup v787: ❔ broad rotation trace 없음']
    br = clean.get('broad_rotation_v783') if isinstance(clean.get('broad_rotation_v783'), dict) else {}
    if not br:
        return base + ['- cleanup v787: ❔ 넓은 순환정리 결과 없음 · paper_bot v783 cycle 이후 확인']
    deleted = int(_v650_int(br.get('deleted_files'), default=0))
    deleted_mb = _v650_num(br.get('deleted_mb'), default=0.0)
    preserved = int(_v650_int(br.get('preserved'), default=0))
    errors = int(_v650_int(br.get('errors'), default=0))
    checked = int(_v650_int(br.get('checked_files'), default=0))
    icon = '✅' if errors == 0 else '⚠️'
    lines = [
        f'- cleanup v787: {icon} checked {checked} / 삭제 파일 {deleted}개 / 삭제 용량 {deleted_mb:.2f}MB / 보존 {preserved}개 / 실패 {errors}개',
    ]
    by = br.get('by_reason') if isinstance(br.get('by_reason'), dict) else {}
    if by:
        parts=[]
        for k,v in list(by.items())[:5]:
            if isinstance(v, dict):
                parts.append(f"{k} {int(_v650_int(v.get('files'), default=0))}개/{_v650_num(v.get('bytes'), default=0.0)/1024/1024:.1f}MB")
        if parts:
            lines.append('- cleanup 대상: ' + ' / '.join(parts))
    top = br.get('large_file_top_outside_target') if isinstance(br.get('large_file_top_outside_target'), list) else []
    if top:
        lines.append('- 대상 밖 큰 파일 TOP: ' + ' / '.join(f"{x.get('name')} {x.get('mb')}MB" for x in top[:5] if isinstance(x, dict)))
    else:
        lines.append('- 대상 밖 큰 파일 TOP: 5MB 이상 없음')
    return base + lines


# v798: show short-retention cleanup separately from broad v783 rotation.
_v798_prev_cleanup_lines = _v783_cleanup_lines

def _v783_cleanup_lines() -> List[str]:  # type: ignore[override]
    lines = _v798_prev_cleanup_lines()
    st = _v650_status()
    clean = _v650_load(BASE_DIR / 'paper_bot_cleanup_state.json', {})
    if not isinstance(clean, dict) or not clean:
        clean = st.get('cleanup_state') if isinstance(st.get('cleanup_state'), dict) else {}
    sr = clean.get('short_rotation_v798') if isinstance(clean, dict) and isinstance(clean.get('short_rotation_v798'), dict) else {}
    if not sr:
        return lines + ['- cleanup v798: ❔ 짧은 보관 순환 결과 없음 · paper_bot v0.790 cycle 이후 확인']
    deleted = int(_v650_int(sr.get('deleted_files'), default=0))
    deleted_mb = _v650_num(sr.get('deleted_mb'), default=0.0)
    preserved = int(_v650_int(sr.get('preserved'), default=0))
    errors = int(_v650_int(sr.get('errors'), default=0))
    checked = int(_v650_int(sr.get('checked_files'), default=0))
    icon = '✅' if errors == 0 else '⚠️'
    out = [f'- cleanup v798: {icon} 임시cache checked {checked} / 삭제 {deleted}개 {deleted_mb:.2f}MB / 보존 {preserved}개 / 실패 {errors}개']
    by = sr.get('by_reason') if isinstance(sr.get('by_reason'), dict) else {}
    if by:
        parts=[]
        for k,v in list(by.items())[:6]:
            if isinstance(v, dict):
                parts.append(f"{k} {int(_v650_int(v.get('files'), default=0))}개/{_v650_num(v.get('bytes'), default=0.0)/1024/1024:.1f}MB")
        if parts:
            out.append('- cleanup v798 대상: ' + ' / '.join(parts))
    out.append('- 보존정책: OPEN/CLOSED/trade_log/score 원장 보존 · 구조계획/후보/재확인/상세 cache 1~2일 순환')
    return lines + out


def _v787_recheck_freshness_lines() -> List[str]:
    lines = _v787_recheck_freshness_base_lines()
    sw = worker_status('strategy')
    summ = _v650_load(BASE_DIR / 'clean_strategy_s_summary.json', {}) or {}
    if not isinstance(summ, dict): summ = {}
    status_schema = str(sw.get('status_route_schema') or sw.get('schema') or '-')
    phase = str(sw.get('phase') or '-')
    last_sec = _v650_num(sw.get('last_sec'), summ.get('cycle_elapsed_sec'), default=0.0)
    pub_sec = _v650_num(sw.get('publish_sec_v783'), default=0.0)
    throttled = bool(sw.get('display_cache_throttled_v783') or summ.get('display_cache_throttled_v783'))
    d_age = _v650_num(sw.get('display_cache_age_sec_v783'), summ.get('display_cache_age_sec_v783'), default=0.0)
    s2_block = summ.get('s2_to_s1_block_top_v783') if isinstance(summ.get('s2_to_s1_block_top_v783'), dict) else {}
    lines.append(f"- 전략공장 병목: phase {phase} / last {last_sec:.2f}s / publish {pub_sec:.2f}s / display_throttle {'ON' if throttled else 'OFF'} / display_age {d_age:.1f}s / schema {status_schema}")
    if s2_block:
        lines.append('- S2→S1 미승격 TOP: ' + _v743_counter_line(s2_block, 5))
    else:
        lines.append('- S2→S1 미승격 TOP: 아직 summary 없음 또는 S2 없음')
    return lines


def _v783_health_text() -> str:
    st = _v650_status()
    lines = ['🧭 상태 /health · v798']
    lines += _v743_section('① 봇/worker') + [
        f"- 메인봇: {BOT_VERSION} / {V650_BUILD_LABEL}",
        f"- paper: {st.get('version','-')} / build {st.get('build','-')} / OPEN {_v650_open_count()}",
        _v650_worker_line(),
        '', '[worker 9개 age]', *_v747_worker_age_lines(full=True),
    ]
    lines += _v743_section('② 후보/재확인 source') + _v783_candidate_unified_lines() + _v787_recheck_freshness_lines()
    lines += _v743_section('③ 자원') + _v650_resource_lines()
    lines += _v743_section('④ 정리/보관') + _v783_cleanup_lines() + _v743_stop_recent_lines()
    lines += _v743_section('⑤ 요약/원문 묶음') + _v650_hourly_lines()
    lines += ['', '[구조 라우팅 v787]', '- ' + (_v774_route_apply_lines()[2].replace('- ', '') if len(_v774_route_apply_lines())>2 else '구조 라우팅 준비중'), '- ' + (_v774_observation_queue_lines()[1].replace('- ', '') if len(_v774_observation_queue_lines())>1 else '구조 관찰 큐 준비중')]
    return '\n'.join(lines)


def _v783_paper_handoff_text() -> str:
    score, today, _, _ = _v650_score_stats(); review = _v650_review()
    lines = [
        '📨 페이퍼 전달 /paper_handoff · v798','',
        '① 적용 상태', *_v783_active_paper_line('paper_bot_v0.795'), f"- OPEN {_v650_open_count()}",
        '', '② 후보 전달', *_v650_pipeline_lines(), *_v650_candidate_lines(4),
        '', '③ 재확인 배관', *_v787_recheck_freshness_lines(),
        '', '④ S1 대기/페이퍼 소비', *_v743_s1_hold_lines(), *_v743_paper_hold_trace_lines()[:3], f"- score/review 오늘 {score.get('today_closed_count', today['n'])} / {review.get('today_closed_count','-')}",
        '', '⑤ 구조 우선 라우팅 적용', *_v774_route_apply_lines()[1:],
        '', '⑥ 구조 관찰 큐', *_v774_observation_queue_lines()[1:],
        '', '⑦ 청산 기록 전달 확인', *_v774_ledger_check_lines(),
    ]
    return '\n'.join(_v772_humanize_line(x) if '_v772_humanize_line' in globals() else str(x) for x in lines)


def _v783_classify_text() -> str:
    cache = _v747_classify_cache()
    age_sec = _v650_file_age(BASE_DIR/'paper_bot_classify_cache.json')
    lines = [
        '🧾 분류판 /classify · v798',
        *_v783_active_paper_line('paper_bot_v0.795'),
        f"- classify cache: age {age_sec:.1f}s / writer paper {cache.get('paper_version','-')} / build {cache.get('build','-')}",
        '- 기본판은 경량화: 후보 snapshot → 재확인 배관 → 성과 → 구조 라우팅만 표시. 상세 손실/차트 성과는 /classify_full.',
        '', '0️⃣ 후보/재확인 source', *_v783_candidate_unified_lines(), *_v787_recheck_freshness_lines(),
        '', '1️⃣ 성과 요약', *_v766_perf_lines(cache),
        '', '2️⃣ 구조 우선 라우팅 적용', *_v774_route_apply_lines()[1:],
        '', '3️⃣ 구조 관찰 큐', *_v774_observation_queue_lines()[1:],
        '', '4️⃣ 청산 기록 전달 확인', *_v774_ledger_check_lines(),
    ]
    return '\n'.join(_v772_humanize_line(x) if '_v772_humanize_line' in globals() else str(x) for x in lines)

# Keep heavy old board behind full command, not the default button.
COMMANDS['classify_full'] = _v783_classify_full_text
COMMANDS['review_board_full'] = _v783_classify_full_text
COMMANDS['health'] = _v783_health_text
COMMANDS['core'] = _v783_health_text
COMMANDS['deploy'] = _v783_health_text
COMMANDS['upgradestatus'] = _v783_health_text
COMMANDS['paper_handoff'] = _v783_paper_handoff_text
COMMANDS['handoff'] = _v783_paper_handoff_text
COMMANDS['classify'] = _v783_classify_text
COMMANDS['review_board'] = _v783_classify_text


# =============================================================================
# main_bot v790: /candidate_reason source 단일화 + 중복 출력 축소
# - 원인: 실제 후보 snapshot/S1 hold는 v789 최종 row를 보는데,
#   /candidate_reason의 가운데 승급 집계 박스는 v732 전용 진단표만 읽어 S1 1개를 0개처럼 표시했다.
# - 수정: 기본 /candidate_reason은 paper_candidates_latest.jsonl 최종 row와
#   v789 post-structure rejudge summary만 읽는다.
# - /paper_handoff와 겹치는 paper 소비 trace 상세는 /candidate_reason 기본판에서 제거한다.
# - 조건값/구조해석/청산/자동매수/BUY_READY/paper 장부는 변경하지 않는다.
# =============================================================================

V650_BUILD_LABEL = 'v806_integrated_validation_freshness_2026-06-10'
BOT_VERSION = '수익형 v2.13.806'


def _v790_summary_spine() -> Tuple[Dict[str, Any], Dict[str, Any], Dict[str, Any]]:
    summ = _v650_load(BASE_DIR / 'clean_strategy_s_summary.json', {}) or {}
    if not isinstance(summ, dict):
        summ = {}
    diag = summ.get('s1_diagnostic') if isinstance(summ.get('s1_diagnostic'), dict) else {}
    spine = {}
    # Prefer the active v789 result nested under the v732 reseal spine; fall back to top-level if present.
    for src in (diag, summ):
        if not isinstance(src, dict):
            continue
        obj = src.get('promotion_stage_spine_v732') or src.get('promotion_stage_spine_v737') or src.get('promotion_stage_spine_v736')
        if isinstance(obj, dict):
            spine = obj
            break
    if not spine:
        obj = summ.get('promotion_stage_spine_v732')
        if isinstance(obj, dict):
            spine = obj
    rejudge = spine.get('post_structure_route_s1_rejudge_v789') if isinstance(spine.get('post_structure_route_s1_rejudge_v789'), dict) else {}
    if not rejudge and isinstance(summ.get('post_structure_route_s1_rejudge_v789'), dict):
        rejudge = summ.get('post_structure_route_s1_rejudge_v789') or {}
    outcome = spine.get('s2_recheck_outcome_summary_v789') if isinstance(spine.get('s2_recheck_outcome_summary_v789'), dict) else {}
    if not outcome and isinstance(summ.get('s2_recheck_outcome_summary_v789'), dict):
        outcome = summ.get('s2_recheck_outcome_summary_v789') or {}
    return summ, rejudge if isinstance(rejudge, dict) else {}, outcome if isinstance(outcome, dict) else {}


def _v790_gate_obj(row: Dict[str, Any]) -> Dict[str, Any]:
    if not isinstance(row, dict):
        return {}
    gate = row.get('s1_promotion_gate') if isinstance(row.get('s1_promotion_gate'), dict) else {}
    if not gate:
        ctx = row.get('entry_context') if isinstance(row.get('entry_context'), dict) else {}
        gate = ctx.get('s1_promotion_gate') if isinstance(ctx.get('s1_promotion_gate'), dict) else {}
    return gate if isinstance(gate, dict) else {}


def _v790_is_v789_s1(row: Dict[str, Any]) -> bool:
    if not isinstance(row, dict):
        return False
    gate = _v790_gate_obj(row)
    ctx = row.get('entry_context') if isinstance(row.get('entry_context'), dict) else {}
    return bool(
        row.get('promotion_spine_v789')
        or (isinstance(ctx, dict) and ctx.get('promotion_spine_v789'))
        or str(row.get('s2_recheck_last_state_v788') or '') == 'promoted_s1'
        or (str(gate.get('schema') or '').endswith('v789') and bool(gate.get('pass')))
    )


def _v790_final_s1_lines() -> List[str]:
    snap = _v650_candidate_snapshot()
    trade_rows = [r for r in (snap.get('trade_rows') or []) if isinstance(r, dict)]
    s1_rows = [r for r in trade_rows if _v650_stage(r) == 'S1']
    s2_rows = [r for r in trade_rows if _v650_stage(r) == 'S2']
    v789_s1 = [r for r in s1_rows if _v790_is_v789_s1(r)]
    hold = _v743_s1_hold_obj()
    hold_count = int(hold.get('count') or hold.get('total') or 0) if isinstance(hold, dict) else 0
    hold_status = hold.get('status_counts') if isinstance(hold, dict) and isinstance(hold.get('status_counts'), dict) else {}
    _, rejudge, outcome = _v790_summary_spine()
    rc = rejudge.get('counts') if isinstance(rejudge.get('counts'), dict) else {}
    oc = outcome.get('counts') if isinstance(outcome.get('counts'), dict) else {}
    target = int(_v650_int(rc.get('target'), default=0))
    promoted = int(_v650_int(rc.get('promoted_s1'), default=0))
    kept = int(_v650_int(rc.get('kept_s2'), default=0))
    down = int(_v650_int(rc.get('downgraded_or_observe'), default=0))
    if target <= 0:
        # derive a display count from final rows if the worker summary has not rotated yet.
        target = sum(1 for r in trade_rows if _v790_gate_obj(r))
        promoted = max(promoted, len(v789_s1))
    block_top = rejudge.get('blocked_top') if isinstance(rejudge.get('blocked_top'), dict) else {}
    state_top: Counter = Counter()
    block_from_rows: Counter = Counter()
    for r in trade_rows:
        gate = _v790_gate_obj(r)
        state = str(r.get('s2_recheck_last_state_v788') or gate.get('state') or '')
        if state:
            state_top[state] += 1
        blocks = gate.get('block_reasons') if isinstance(gate.get('block_reasons'), list) else []
        for b in blocks[:6]:
            if b:
                block_from_rows[str(b)] += 1
    if not block_top and block_from_rows:
        block_top = dict(block_from_rows.most_common(8))
    s1_sample=[]
    for r in s1_rows[:4]:
        gate = _v790_gate_obj(r)
        src = 'v789재심사' if _v790_is_v789_s1(r) else '기존S1'
        s1_sample.append(f"{_v650_ticker(r)}({src}/{gate.get('state') or r.get('s2_recheck_last_state_v788') or '-'})")
    lines = [
        f"- 최종 후보 row: S1 {len(s1_rows)} / S2 {len(s2_rows)} / 실전후보 {len(trade_rows)}",
        f"- S1 hold: {hold_count}개 / 상태 {(_v743_counter_line(hold_status, 4) if hold_status else '없음')}",
        f"- v789 재심사: 대상 {target}개 / S1승격 {promoted}개 / S2유지 {kept}개 / 관찰·강등 {down}개",
        "- 재확인 상태 TOP: " + (_v743_counter_line(oc or state_top, 6) if (oc or state_top) else '없음'),
        "- 미승격 TOP: " + (_v743_counter_line(block_top, 6) if block_top else '없음'),
        "- S1 샘플: " + (' / '.join(s1_sample) if s1_sample else '-'),
        "- 기준: paper_candidates_latest.jsonl 최종 후보 row + v789 재심사 결과만 표시. 구 v732 전용 집계는 기본판에서 제외.",
    ]
    return lines


def _v790_s2_promotion_lines() -> List[str]:
    # Keep the old function name behavior focused on the active source.
    return _v790_final_s1_lines()


# Replace the old v732-only display helper so /gate_check and /batch also stop showing stale promotion counts.
_v743_s2_promotion_lines = _v790_s2_promotion_lines  # type: ignore[assignment]



def _v792_quality_obj(row: Dict[str, Any]) -> Dict[str, Any]:
    q = row.get('structure_quality_v792') if isinstance(row.get('structure_quality_v792'), dict) else {}
    if q:
        return q
    ctx = row.get('entry_context') if isinstance(row.get('entry_context'), dict) else {}
    return ctx.get('structure_quality_v792') if isinstance(ctx.get('structure_quality_v792'), dict) else {}


def _v792_structure_quality_lines() -> List[str]:
    snap = _v650_candidate_snapshot()
    rows = [r for r in (snap.get('trade_rows') or []) if isinstance(r, dict)]
    if not rows:
        return ['- 구조정교화 자료 없음']
    good = Counter()
    risk = Counter()
    fail = Counter()
    exec_cls = Counter()
    line_quality = Counter()
    line_reaction = Counter()
    interpretation = Counter()
    sustain_source = Counter()
    weak_rel = 0
    early = Counter()
    samples = []
    for r in rows:
        q = _v792_quality_obj(r)
        if not q:
            continue
        for x in (q.get('good_tags') or []):
            good[str(x)] += 1
        for x in (q.get('risk_tags') or []):
            risk[str(x)] += 1
        for x in (q.get('failure_pattern_tags') or []):
            fail[str(x)] += 1
        for x in (q.get('early_fail_watch_tags') or []):
            early[str(x)] += 1
        if q.get('exec_risk_class'):
            exec_cls[str(q.get('exec_risk_class'))] += 1
        if q.get('line_quality_v794'):
            line_quality[str(q.get('line_quality_v794'))] += 1
        for x in (q.get('line_reaction_tags_v794') or []):
            line_reaction[str(x)] += 1
        if q.get('structure_interpretation_v794'):
            interpretation[str(q.get('structure_interpretation_v794'))] += 1
        if q.get('buy_sustain_source_v794'):
            sustain_source[str(q.get('buy_sustain_source_v794'))] += 1
        if q.get('weak_market_relative_strength'):
            weak_rel += 1
        if len(samples) < 6 and _v650_stage(r) in ('S1','S2') and (q.get('good_tags') or q.get('failure_pattern_tags') or q.get('exec_risk_class') or q.get('line_reaction_tags_v794')):
            gt = '/'.join(str(x) for x in (q.get('good_tags') or [])[:2]) or '-'
            ft = '/'.join(str(x) for x in (q.get('failure_pattern_tags') or [])[:2]) or '-'
            lr = '/'.join(str(x) for x in (q.get('line_reaction_tags_v794') or [])[:2]) or '-'
            samples.append(f"{_v650_ticker(r)}({_v650_stage(r)}/선:{q.get('line_quality_v794') or '-'}/반응:{lr}/해석:{q.get('structure_interpretation_v794') or '-'}/주의:{ft}/실행:{q.get('exec_risk_class') or '-'})")
    if not (good or risk or fail or exec_cls or line_quality or line_reaction):
        return ['- v795 선 품질/반응 태그 아직 없음 또는 worker cache 미회전']
    return [
        '- 선 품질 TOP: ' + (_v743_counter_line(line_quality, 5) if line_quality else '없음'),
        '- 선 반응 TOP: ' + (_v743_counter_line(line_reaction, 5) if line_reaction else '없음'),
        '- 구조 해석 TOP: ' + (_v743_counter_line(interpretation, 5) if interpretation else '없음'),
        '- 좋은 구조 TOP: ' + (_v743_counter_line(good, 5) if good else '없음'),
        '- 주의패턴 TOP: ' + (_v743_counter_line(fail, 5) if fail else '없음'),
        '- 실행위험 분리: ' + (_v743_counter_line(exec_cls, 5) if exec_cls else '없음'),
        '- 1분지속 source: ' + (_v743_counter_line(sustain_source, 4) if sustain_source else '없음'),
        f'- 약장 상대강도: {weak_rel}개 / 빠른실패 주의: ' + (_v743_counter_line(early, 4) if early else '없음'),
        '- 샘플: ' + (' / '.join(samples) if samples else '-'),
        '- 기준: 구조태그는 S1 차단문이 아니라 선 품질/선 반응/복기 태그. 조건 완화 없음.',
    ]

def _v790_reason_text() -> str:
    snap = _v650_candidate_snapshot()
    lines = ['🧭 S1 승급 못한 이유 /reason · v798']
    lines += _v743_section('① 후보/참고 구분') + _v743_candidate_label_lines(snap)
    lines += _v743_section('② 1분 가격/반응') + ['- ' + _v743_counter_line(snap.get('materials'), 8)]
    lines += _v743_section('③ 승급 실패 TOP') + _v743_short_counter(snap.get('reasons'), 8)
    lines += _v743_section('④ S1 최종 심사 / hold') + _v790_final_s1_lines()
    lines += _v743_section('⑤ 선 품질·반응 정교화 / 실행위험 분리') + _v792_structure_quality_lines()
    lines += _v743_section('⑥ 위험/차단 TOP') + _v743_short_counter(snap.get('risks'), 8)
    lines += _v743_section('⑦ 코인별 아까운 후보') + _v743_top_candidate_lines(8)
    if snap.get('stale_all'):
        lines += _v743_section('⑧ 정보 신선도') + [f"- 오래됨: 실전후보 {snap.get('stale_trade',0)} / S1·S2 {snap.get('stale_s12',0)} / 전체시장 참고 {snap.get('stale_coverage',0)} / 전체 {snap.get('stale_all',0)}"]
    lines += ['', '상세 paper 소비 trace는 /paper_handoff, gate 상세는 /gate_check에서 확인.']
    return '\n'.join(lines)


def _v790_gate_check_text() -> str:
    return '\n'.join([
        '🧪 gate/hold 확인 /gate_check · v798',
        '[S1 최종 심사]', *_v790_final_s1_lines(),
        '', '[선 품질·반응 정교화 / 실행위험 분리]', *_v792_structure_quality_lines(),
        '', '[gate scope 참고]', *_v743_gate_scope_check_lines(),
        '', '[paper hold 소비]', *_v743_paper_hold_trace_lines(),
    ])


COMMANDS['candidate_reason'] = _v790_reason_text
COMMANDS['reason'] = _v790_reason_text
COMMANDS['why_s1'] = _v790_reason_text
COMMANDS['quality'] = _v790_reason_text
COMMANDS['gate_check'] = _v790_gate_check_text



# =============================================================================
# main v796: display structure-first trade plan spine
# - Reads final candidate rows only. No recalculation, no ledger lookup.
# =============================================================================
V650_BUILD_LABEL = 'v806_integrated_validation_freshness_2026-06-10'
BOT_VERSION = '수익형 v2.13.806'
EXPECTED_PAPER_VERSION = 'paper_bot_v0.795'


def _v796_plan_obj(row: Dict[str, Any]) -> Dict[str, Any]:
    p = row.get('structure_trade_plan_v796') if isinstance(row.get('structure_trade_plan_v796'), dict) else {}
    if p:
        return p
    ctx = row.get('entry_context') if isinstance(row.get('entry_context'), dict) else {}
    return ctx.get('structure_trade_plan_v796') if isinstance(ctx.get('structure_trade_plan_v796'), dict) else {}


def _v796_structure_plan_lines() -> List[str]:
    snap = _v650_candidate_snapshot()
    rows = [r for r in (snap.get('trade_rows') or []) if isinstance(r, dict)]
    if not rows:
        return ['- 구조계획 자료 없음']
    state = Counter(); role = Counter(); line = Counter(); reason = Counter()
    rr_vals=[]; samples=[]; promoted=0
    for r in rows:
        p = _v796_plan_obj(r)
        if not p:
            continue
        state[str(p.get('plan_state') or 'unknown')] += 1
        role[str(p.get('plan_role') or 'unknown')] += 1
        line[str(p.get('line_quality') or 'missing_line')] += 1
        if p.get('plan_reason'):
            reason[str(p.get('plan_reason'))] += 1
        try:
            if p.get('rr_ratio'):
                rr_vals.append(float(p.get('rr_ratio')))
        except Exception:
            pass
        gate = _v790_gate_obj(r) if '_v790_gate_obj' in globals() else {}
        if str(gate.get('source_v796') or '') == 'structure_first_plan_reorder' and _v650_stage(r) == 'S1':
            promoted += 1
        if len(samples) < 6 and _v650_stage(r) in ('S1','S2'):
            samples.append(f"{_v650_ticker(r)}({_v650_stage(r)}/{p.get('plan_state') or '-'}/RR {p.get('rr_ratio') or 0}/손절 {p.get('risk_pct') or 0}%/목표 {p.get('reward_pct') or 0}%/선 {p.get('line_quality') or '-'})")
    if not state:
        return ['- 구조계획 v796 아직 없음 또는 worker cache 미회전']
    avg_rr = round(sum(rr_vals)/len(rr_vals), 2) if rr_vals else 0.0
    return [
        '- 계획 상태 TOP: ' + (_v743_counter_line(state, 6) if state else '없음'),
        '- 계획 역할 TOP: ' + (_v743_counter_line(role, 6) if role else '없음'),
        '- 선 품질 TOP: ' + (_v743_counter_line(line, 5) if line else '없음'),
        f'- 평균 RR: {avg_rr} / 구조계획 S1승격 {promoted}개',
        '- 계획 미충족 TOP: ' + (_v743_counter_line(reason, 6) if reason else '없음'),
        '- 샘플: ' + (' / '.join(samples) if samples else '-'),
        '- 기준: 구조선→진입/무효/목표→손익비→확인값→실행위험 순서. 조건 수치 직접 완화 없음.',
    ]


_v796_prev_structure_quality_lines = _v792_structure_quality_lines

def _v792_structure_quality_lines() -> List[str]:  # type: ignore[override]
    base = _v796_prev_structure_quality_lines()
    return base + [''] + ['[구조계획 v796]'] + _v796_structure_plan_lines()


def _v796_reason_text() -> str:
    snap = _v650_candidate_snapshot()
    lines = ['🧭 S1 승급 못한 이유 /reason · v798']
    lines += _v743_section('① 후보/참고 구분') + _v743_candidate_label_lines(snap)
    lines += _v743_section('② 1분 가격/반응') + ['- ' + _v743_counter_line(snap.get('materials'), 8)]
    lines += _v743_section('③ 승급 실패 TOP') + _v743_short_counter(snap.get('reasons'), 8)
    lines += _v743_section('④ S1 최종 심사 / hold') + _v790_final_s1_lines()
    lines += _v743_section('⑤ 선 품질·반응 / 구조계획') + _v792_structure_quality_lines()
    lines += _v743_section('⑥ 위험/차단 TOP') + _v743_short_counter(snap.get('risks'), 8)
    lines += _v743_section('⑦ 코인별 아까운 후보') + _v743_top_candidate_lines(8)
    return '\n'.join(lines)


def _v796_gate_check_text() -> str:
    return '\n'.join([
        '🧪 gate/hold 확인 /gate_check · v798',
        '[S1 최종 심사]', *_v790_final_s1_lines(),
        '', '[선 품질·반응 / 구조계획]', *_v792_structure_quality_lines(),
        '', '[gate scope 참고]', *_v743_gate_scope_check_lines(),
        '', '[paper hold 소비]', *_v743_paper_hold_trace_lines(),
    ])

COMMANDS['candidate_reason'] = _v796_reason_text
COMMANDS['reason'] = _v796_reason_text
COMMANDS['why_s1'] = _v796_reason_text
COMMANDS['quality'] = _v796_reason_text
COMMANDS['gate_check'] = _v796_gate_check_text



# =============================================================================
# main v799: default command readability + hold trace count fix
# - Default commands become compact, Korean-readable boards.
# - Full/legacy heavy commands remain under *_full.
# - No candidate recomputation and no ledger scan in default handlers.
# =============================================================================
V650_BUILD_LABEL = 'v806_integrated_validation_freshness_2026-06-10'
BOT_VERSION = '수익형 v2.13.806'
EXPECTED_PAPER_VERSION = 'paper_bot_v0.795'

_V799_LABELS = {
    'raw S3': '전체시장 참고 신호',
    'coverage': '후보 전 단계',
    'coverage·비후보': '후보 전 단계/감시만 한 코인',
    'hard_risk_hold': '위험 커서 보류',
    'plan_good': '구조계획 좋음',
    'plan_ready': '구조계획 준비됨',
    'risk_hold': '위험 보류',
    's1_review_candidate': 'S1 심사 후보',
    's2_fast_recheck': '빠른 재확인 후보',
    'exec_risk_wait': '실행위험 재확인 대기',
    'trigger_wait': '방아쇠 가격 대기',
    'promoted_s1': 'S1 승격',
    'fresh_open_ready': 'paper 진입 준비',
    'paper_final_hold': 'paper 최종보류',
    'hold_read': 'hold 읽음',
    'candidate_expired': '후보 만료',
    'same_ticker_skip': '같은 종목 중복 제외',
    'selected_for_open': 'OPEN 선택',
    'opened': 'OPEN 완료',
    'confirmed_line': '확정선',
    'reactive_line': '실제 반응선',
    'calculated_line_recheck': '계산선 재확인',
    'missing_line': '선 없음',
    'exec_ok': '실행 가능',
    'exec_recheck': '실행 재확인',
    'hard_exec_risk': '실행위험 큼',
    'spread_only_recheckable': '스프레드만 재확인',
    'rr_wait': '손익비 대기',
    's2_or_observe': 'S2/관찰',
    'plan_incomplete': '구조계획 부족',
    'line_quality_wait': '선 품질 재확인',
    'support_rebound': '지지선 반등형',
    'vwap_ema_hold': 'VWAP·EMA 방어형',
    'breakout_hold': '돌파 유지형',
    'box_breakout_hold': '박스 돌파형',
    'calculated_recheck': '계산선 재확인형',
    'common_structure': '공통 구조형',
    'common_scalp_entry': '공통초입형',
    'common_scalp': '공통초입',
    'common_scalp_good': '공통초입 좋음',
    'common_scalp_s1_review': '공통초입 S1심사',
    'structure': '구조형',
    'trigger_not_reached_v628': '방아쇠 가격 미도달',
    'common_scalp_watch': '공통초입 관찰',
    'common_scalp_ok': '공통초입 통과',
    'watch_only': '관찰만',
    'strict_pass': '통과',
    'blocked': '차단',
}


def _v799_label(x: Any) -> str:
    t = str(x or '-')
    if t.startswith('trigger_not_reached_v628'):
        return t.replace('trigger_not_reached_v628', '방아쇠 가격 미도달')
    if t.startswith('structure_plan_hold_v800'):
        return t.replace('structure_plan_hold_v800', '구조계획 OPEN 보류')
    return _V799_LABELS.get(t, t)

def _v799_counter_line(counter: Any, limit: int = 5) -> str:
    try:
        items = Counter(counter or {}).most_common(limit)
        return ' / '.join(f'{_v799_label(k)} {v}' for k, v in items if v) or '없음'
    except Exception:
        return '없음'

def _v799_section(title: str) -> List[str]:
    return ['', title]

def _v799_candidate_brief_lines() -> List[str]:
    s = _v650_candidate_snapshot(); c = s.get('counts') if isinstance(s.get('counts'), Counter) else Counter(); all_c = s.get('all_counts') if isinstance(s.get('all_counts'), Counter) else Counter()
    trade = len(s.get('trade_rows') or []); cov = len(s.get('coverage_rows') or [])
    lines = [
        f"- 실전후보: 🟢S1 {int(c.get('S1',0))} / 🟡S2 {int(c.get('S2',0))} / 🔵S3 {int(c.get('S3',0))} / 합계 {trade}",
        f"- 전체시장 참고: {int(all_c.get('S3',0))}개 / 후보 전 단계·감시만 한 코인 {cov}개",
        f"- 1분 반응: {_v799_counter_line(s.get('materials'), 4)}",
    ]
    if int(c.get('S1',0)) <= 0:
        lines.append('- 판독: 현재 S1 없음. S2 재확인/구조계획/실행위험을 봐야 함.')
    return lines

def _v799_pipeline_brief_lines() -> List[str]:
    p = _v650_pipeline()
    return [
        f"- 시장→후보 배관: KRW {p['krw']} → 스캔 {p['scanner']} → 전략판단 {p['strategy']} → 봉인 {p['sealed']} → 실전후보 {p['paper']}",
        f"- 참고/감시만 한 코인: {p['coverage']}개 · 전체시장 S3 흔적 {p['raw_S3']}개",
    ]

def _v799_plan_lines(limit: int = 5) -> List[str]:
    snap = _v650_candidate_snapshot(); rows = [r for r in (snap.get('trade_rows') or []) if isinstance(r, dict)]
    state=Counter(); role=Counter(); line=Counter(); reason=Counter(); route=Counter(); pattern=Counter(); pattern_watch=Counter(); rr=[]; samples=[]; promoted=0; common_promoted=0; common_watch=0; common_ok=0
    for r in rows:
        p = _v796_plan_obj(r) if '_v796_plan_obj' in globals() else {}
        if not p: continue
        state[str(p.get('plan_state') or 'unknown')] += 1
        role[str(p.get('plan_role') or 'unknown')] += 1
        line[str(p.get('line_quality') or 'missing_line')] += 1
        if '_v801_trigger_type' not in locals():
            _v801_trigger_type = Counter(); _v801_adjusted = Counter()
        _v801_trigger_type[str(p.get('trigger_archetype_v801') or 'common_structure')] += 1
        if p.get('trigger_adjusted_v801'):
            _v801_adjusted[str(p.get('trigger_archetype_v801') or 'common_structure')] += 1
        route[str(p.get('entry_route_v802') or 'structure')] += 1
        cs = p.get('common_scalp_entry_v802') if isinstance(p.get('common_scalp_entry_v802'), dict) else {}
        if cs.get('common_scalp_watch'):
            common_watch += 1
            pattern_watch[str(p.get('common_pattern_key_v802') or cs.get('common_pattern_key') or 'common_scalp')] += 1
        if cs.get('common_scalp_ok'):
            common_ok += 1
            pattern[str(p.get('common_pattern_key_v802') or cs.get('common_pattern_key') or 'common_scalp')] += 1
        if p.get('plan_reason'): reason[str(p.get('plan_reason'))] += 1
        try:
            if p.get('rr_ratio') not in (None, ''): rr.append(float(p.get('rr_ratio')))
        except Exception: pass
        gate = _v790_gate_obj(r) if '_v790_gate_obj' in globals() else {}
        if str(gate.get('source_v796') or '') == 'structure_first_plan_reorder' and _v650_stage(r) == 'S1':
            promoted += 1
            if str(p.get('entry_route_v802') or '') == 'common_scalp': common_promoted += 1
        if len(samples) < limit and _v650_stage(r) in ('S1','S2'):
            route_txt = _v799_label(p.get('entry_route_v802') or 'structure')
            pat = str(p.get('common_pattern_key_v802') or '').replace('common_scalp|','')[:32]
            pat_txt = ('/' + pat) if pat else ''
            samples.append(f"{_v650_ticker(r)}({_v650_stage(r)}/{route_txt}/{_v799_label(p.get('plan_state'))}/{_v799_label(p.get('trigger_archetype_v801'))}{pat_txt}/RR {p.get('rr_ratio') or 0}/gap {p.get('trigger_gap_pct') or 0}%/{_v799_label(p.get('line_quality'))})")
    if not state:
        return ['- 구조계획: 아직 없음 또는 strategy worker cache 회전 대기']
    avg_rr = round(sum(rr)/len(rr), 2) if rr else 0.0
    return [
        '- 계획상태: ' + _v799_counter_line(state, 5),
        '- 후보역할: ' + _v799_counter_line(role, 5),
        '- 선 품질: ' + _v799_counter_line(line, 4),
        '- 구조별 방아쇠: ' + _v799_counter_line(locals().get('_v801_trigger_type', Counter()), 5),
        '- 진입 경로: ' + _v799_counter_line(route, 5),
        '- 방아쇠 재배치: ' + (_v799_counter_line(locals().get('_v801_adjusted', Counter()), 5) if locals().get('_v801_adjusted', Counter()) else '없음'),
        '- 공통초입 패턴: 통과 ' + (_v799_counter_line(pattern, 4) if pattern else '없음') + ' / 관찰 ' + (_v799_counter_line(pattern_watch, 4) if pattern_watch else '없음'),
        f'- 평균 손익비(RR): {avg_rr} / 구조계획 기준 S1승격 {promoted}개 / 공통초입 관찰 {common_watch}개 / 통과 {common_ok}개 / 승격 {common_promoted}개',
        '- 미충족 이유: ' + _v799_counter_line(reason, 5),
        '- 샘플: ' + (' / '.join(samples) if samples else '-'),
    ]

def _v799_final_s1_lines() -> List[str]:
    raw = _v790_final_s1_lines() if '_v790_final_s1_lines' in globals() else []
    out=[]
    for ln in raw:
        x=str(ln)
        x=x.replace('최종 후보 row', '최종 후보')
        x=x.replace('v789 재심사', 'S2→S1 재심사')
        x=x.replace('재확인 상태 TOP', '재확인 상태')
        x=x.replace('미승격 TOP', 'S1 못 간 이유')
        x=x.replace('구 v732 전용 집계는 기본판에서 제외.', '구버전 집계 제외.')
        for k,v in _V799_LABELS.items(): x=x.replace(k, v)
        out.append(x)
    return out

def _v799_paper_hold_trace_lines() -> List[str]:
    st = _v650_status()
    obj = st.get('hold_trace_summary_v746') if isinstance(st.get('hold_trace_summary_v746'), dict) else (st.get('hold_trace_summary_v743') if isinstance(st.get('hold_trace_summary_v743'), dict) else {})
    h = _v743_s1_hold_obj() if '_v743_s1_hold_obj' in globals() else {}
    hold_count = int(_v650_int(h.get('count'), h.get('total'), h.get('fresh_count'), default=0)) if isinstance(h, dict) else 0
    if not obj:
        if hold_count > 0:
            return [f'- paper 소비 확인: S1 hold {hold_count}개 있음 · 아직 paper status trace 미봉인', '- 판독: 다음 paper cycle에서 hold_read/OPEN/보류 사유가 찍히는지 확인']
        return ['- paper 소비 확인: 현재 S1 hold 없음']
    counts = obj.get('status_counts') if isinstance(obj.get('status_counts'), dict) else {}
    final_top = obj.get('final_hold_reason_top') if isinstance(obj.get('final_hold_reason_top'), dict) else {}
    expired_top = obj.get('expired_reason_top') if isinstance(obj.get('expired_reason_top'), dict) else {}
    preopen_top = obj.get('preopen_guard_top') if isinstance(obj.get('preopen_guard_top'), dict) else {}
    recent_rows = obj.get('recent_rows') if isinstance(obj.get('recent_rows'), dict) else {}
    def _c(label: str, limit: int = 5) -> str:
        d = counts.get(label) if isinstance(counts.get(label), dict) else {}
        return _v799_counter_line(d, limit) if d else '없음'
    lines = [f"- paper 소비 흐름: 현재 cycle {_c('cycle')} / 최근60초 {_c('last60s')} / 최근5분 {_c('last5m')}"]
    f5 = final_top.get('last5m') if isinstance(final_top.get('last5m'), dict) else {}
    e5 = expired_top.get('last5m') if isinstance(expired_top.get('last5m'), dict) else {}
    p5 = preopen_top.get('last5m') if isinstance(preopen_top.get('last5m'), dict) else {}
    if f5: lines.append('- paper 최종보류 이유(5분): ' + _v799_counter_line(f5, 4))
    if e5: lines.append('- 후보 만료 이유(5분): ' + _v799_counter_line(e5, 3))
    if p5: lines.append('- OPEN 직전 안전문(5분): ' + _v799_counter_line(p5, 3))
    rr = recent_rows.get('last60s') if isinstance(recent_rows.get('last60s'), list) else []
    if rr:
        sample=[]
        for r in rr[:4]:
            if isinstance(r, dict): sample.append(f"{r.get('ticker') or '-'}:{_v799_label(r.get('status'))}:{r.get('age_sec','-')}s")
        if sample: lines.append('- 최근60초 샘플: ' + ' / '.join(sample))
    open_ready = int(_v650_int(h.get('open_ready_count'), default=0)) if isinstance(h, dict) else 0
    if open_ready > 0:
        lines.append(f'- paper 대기: 진입준비 hold {open_ready}개 · 다음 paper cycle에서 selected/open/보류 trace 확인')
    if hold_count > 0 and not any(('hold 읽음' in x or 'OPEN' in x or 'paper 최종보류' in x) for x in lines):
        lines.append(f'- 주의: S1 hold {hold_count}개가 있으나 이번 status에 소비 결과가 아직 없음')
    return lines

# Redirect the old helper name so existing sections also use the corrected wording/count logic.
_v743_paper_hold_trace_lines = _v799_paper_hold_trace_lines  # type: ignore[assignment]



def _v799_trade_detail_lines_range(since_ts: float, until_ts: float) -> List[str]:
    return _v798_batch_trade_detail_lines(since_ts, until_ts)



def _v799_trade_detail_lines() -> List[str]:
    since_ts = _v798_batch_marker_ts() if '_v798_batch_marker_ts' in globals() else 0.0
    return _v798_batch_trade_detail_lines(since_ts, now_ts())



def _v799_batch_text() -> str:
    score=_v650_score(); review=_v650_review(); stop=_v681_stop_review_summary() if '_v681_stop_review_summary' in globals() else {}
    lines=['📦 코인봇 전체 요약 /batch']
    lines += _v799_section('① 성과') + _v651_score_window_lines() + [f"- score/review 오늘: {score.get('today_closed_count','-')} / {review.get('today_closed_count','-')}"]
    lines += _v799_section('② 후보 현황') + _v799_candidate_brief_lines() + _v799_pipeline_brief_lines()
    snap=_v650_candidate_snapshot()
    lines += _v799_section('③ S1 못 간 이유') + ['- ' + _v799_counter_line(snap.get('reasons'), 6), '- 위험/주의: ' + _v799_counter_line(snap.get('risks'), 5)]
    lines += _v799_section('④ 구조계획') + _v799_plan_lines(4)
    lines += _v799_section('⑤ S1 hold → paper 소비') + _v743_s1_hold_lines() + _v799_paper_hold_trace_lines()
    lines += _v799_section('⑥ 이전 요약 이후 매매') + ['- 상세 매매 복기표는 이 요약 txt 하단 [이전 요약 이후 매매 상세]에 1회만 표시']
    lines += _v799_section('⑦ 자원/정리') + _v650_resource_lines() + [f"- 손절초과: 최근 trace {stop.get('n',0)}건 / loop gap 의심 {stop.get('loop_gap_suspect',0)}건", '- 요약 txt는 전송 후 서버 임시파일 삭제']
    lines += ['', '더 보기: /candidate_reason /gate_check /paper_handoff /pstatus /errorlog']
    return '\n'.join(lines)


def _v799_health_text() -> str:
    st=_v650_status()
    lines=['🧭 시스템 건강상태 /health']
    lines += _v799_section('① 실행 상태') + [f"- 메인봇: {BOT_VERSION} / {V650_BUILD_LABEL}", f"- paper: {st.get('version','-')} / build {st.get('build','-')} / OPEN {_v650_open_count()}", _v650_worker_line()]
    lines += _v799_section('② worker 최신성') + _v747_worker_age_lines(full=True)
    lines += _v799_section('③ 후보/cache') + _v783_candidate_unified_lines() + _v787_recheck_freshness_lines()
    lines += _v799_section('④ 자원') + _v650_resource_lines()
    lines += _v799_section('⑤ 정리/보관') + _v799_cleanup_lines()
    return '\n'.join(lines)

def _v799_cleanup_lines() -> List[str]:
    base = []
    try:
        base = _v783_cleanup_lines() if '_v783_cleanup_lines' in globals() else _v678_cleanup_lines()
    except Exception:
        base = _v678_cleanup_lines()
    out=['- 보존: paper OPEN/CLOSED 원장, trade_log, score 요약']
    out.append('- 삭제/순환: 구조계획 상세 cache, batch 임시 txt, 후보/recheck/debug/trace 임시파일')
    for ln in base[:8]:
        x=str(ln).replace('cleanup v787', '자동 정리').replace('broad rotation trace', '넓은 순환정리 기록').replace('paper_bot v783 cycle 이후 확인', 'paper 정리 cycle 이후 확인')
        x=x.replace('trace삭제', 'trace 정리').replace('임시파일', '임시 파일')
        out.append(x)
    return out

def _v799_reason_text() -> str:
    snap=_v650_candidate_snapshot()
    lines=['🧭 S1 못 간 이유 /candidate_reason']
    lines += _v799_section('① 후보 구분') + _v799_candidate_brief_lines()
    lines += _v799_section('② 가장 많이 막힌 이유') + _v743_short_counter(snap.get('reasons'), 8)
    lines += _v799_section('③ 구조계획') + _v799_plan_lines(6)
    lines += _v799_section('④ 선 품질/반응·실행위험') + _v799_structure_quality_compact_lines()
    lines += _v799_section('⑤ S1 최종심사') + _v799_final_s1_lines()
    lines += _v799_section('⑥ 아까운 후보') + _v743_top_candidate_lines(6)
    return '\n'.join(lines)

def _v799_structure_quality_compact_lines() -> List[str]:
    # Keep this compact; full raw structure-quality details are available in /candidate_reason_full.
    snap=_v650_candidate_snapshot(); rows=[r for r in (snap.get('trade_rows') or []) if isinstance(r, dict)]
    lq=Counter(); lr=Counter(); interp=Counter(); execs=Counter(); warn=Counter(); samples=[]
    for r in rows:
        q=_v792_quality_obj(r) if '_v792_quality_obj' in globals() else {}
        if not q: continue
        if q.get('line_quality_v794'): lq[str(q.get('line_quality_v794'))]+=1
        for x in q.get('line_reaction_tags_v794') or []: lr[str(x)]+=1
        if q.get('structure_interpretation_v794'): interp[str(q.get('structure_interpretation_v794'))]+=1
        if q.get('exec_risk_class'): execs[str(q.get('exec_risk_class'))]+=1
        for x in q.get('failure_pattern_tags') or []: warn[str(x)]+=1
        if len(samples)<4 and _v650_stage(r) in ('S1','S2'):
            samples.append(f"{_v650_ticker(r)}({_v650_stage(r)}/{_v799_label(q.get('line_quality_v794'))}/{q.get('structure_interpretation_v794') or '-'}/{_v799_label(q.get('exec_risk_class'))})")
    if not (lq or lr or execs): return ['- 선 품질/실행위험 자료 대기']
    return ['- 선 품질: '+_v799_counter_line(lq,4), '- 선 반응: '+_v799_counter_line(lr,4), '- 구조 해석: '+_v799_counter_line(interp,4), '- 실행위험: '+_v799_counter_line(execs,4), '- 주의패턴: '+_v799_counter_line(warn,4), '- 샘플: '+(' / '.join(samples) if samples else '-')]

def _v799_gate_check_text() -> str:
    return '\n'.join(['🧪 S1 최종심사 /gate_check', '① S1 hold·재심사', *_v799_final_s1_lines(), '', '② 구조계획', *_v799_plan_lines(6), '', '③ paper 소비', *_v743_s1_hold_lines(), *_v799_paper_hold_trace_lines(), '', '④ 참고: gate 누수', *_v743_gate_scope_check_lines()])

def _v799_paper_handoff_text() -> str:
    st=_v650_status(); score,today,_,_=_v650_score_stats(); review=_v650_review()
    lines=['📨 메인→페이퍼 전달 상태 /paper_handoff']
    lines += _v799_section('① 적용 상태') + _v783_active_paper_line('paper_bot_v0.795') + [f"- OPEN {_v650_open_count()}"]
    lines += _v799_section('② 후보 전달') + _v799_pipeline_brief_lines() + _v799_candidate_brief_lines()
    lines += _v799_section('③ 재확인/구조 큐') + _v787_recheck_freshness_lines() + _v774_observation_queue_lines()[1:4]
    lines += _v799_section('④ S1 hold → paper 소비') + _v743_s1_hold_lines() + _v799_paper_hold_trace_lines() + [f"- score/review 오늘 {score.get('today_closed_count', today['n'])} / {review.get('today_closed_count','-')}"]
    return '\n'.join(lines)

def _v799_pstatus_text() -> str:
    st=_v650_status(); score=_v650_score(); review=_v650_review()
    lines=['🧪 페이퍼 매매 상태 /pstatus']
    src_counts = score.get('closed_source_counts') if isinstance(score.get('closed_source_counts'), dict) else {}
    closed_total = score.get('closed_total') or score.get('total_closed_count') or score.get('ledger_closed_count') or score.get('closed_ledger_count') or src_counts.get('ledger') or '-'
    lines += [f"- paper: {st.get('version','-')} / build {st.get('build','-')}", f"- OPEN: {_v650_open_count()} / CLOSED누적 {closed_total}", f"- score/review 오늘: {score.get('today_closed_count','-')} / {review.get('today_closed_count','-')}"]
    lines += _v799_section('① 현재 후보') + _v799_candidate_brief_lines()
    lines += _v799_section('② S1 선택/소비') + _v743_s1_hold_lines() + _v799_paper_hold_trace_lines()
    lines += _v799_section('③ 최근 CLOSED') + _v650_closed_source_lines(5)
    return '\n'.join(lines)

def _v799_menu_text() -> str:
    return '\n'.join(['🧭 코인봇 메뉴 /menu', '', '자주 보는 명령어', '- /batch: 전체 요약 + 이전 요약 이후 매매 상세', '- /health: worker/cache/자원/정리 상태', '- /candidate_reason: S1 못 간 이유와 구조계획', '- /gate_check: S1 최종심사와 paper 소비 확인', '- /paper_handoff: 메인→페이퍼 전달 상태', '- /pstatus: 페이퍼 OPEN/CLOSED/hold 소비', '- /errorlog: 새 오류 확인', '', '상세 원문', '- /candidate_reason_full /health_full /pstatus_full /paper_handoff_full', '', '표시 기준', '- S1=실전 후보 / S2=빠른 재확인 / S3=관찰', '- 전체시장 참고 신호는 실전후보가 아님'])

def _v650_batch_summary_text(cmds: List[str], outputs: Dict[str,str], timings: List[Dict[str,Any]], recv_delay: float, total_sec: float) -> str:  # type: ignore[override]
    global _V797_PENDING_BATCH_MARKER_TS
    batch_until = now_ts(); _V797_PENDING_BATCH_MARKER_TS = batch_until
    since_ts = _v798_batch_marker_ts() if '_v798_batch_marker_ts' in globals() else 0.0
    lines=['코인봇 묶음 요약집 v806', f'- 생성: {_v800_kst_text(batch_until)}', f'- 메인봇: {BOT_VERSION} / {V650_BUILD_LABEL}', f'- 접수지연: {recv_delay:.2f}s / 처리합계: {total_sec:.2f}s', '', '[명령 처리시간]']
    for t in timings:
        lines.append(f"- {'✅' if not t.get('error') else '❌'} /{t.get('name','?')}: {float(t.get('sec') or 0):.2f}s / {'OK' if not t.get('error') else 'ERR'}")
    lines += ['', '[전체 요약]', _v650_safe_body(outputs.get('batch') or _v799_batch_text(), 3200), '']
    lines += _v799_trade_detail_lines_range(since_ts, batch_until)
    lines += ['', '[명령별 상세]']
    for name in cmds:
        lines += ['', f'/{name}', _v650_safe_body(outputs.get(name,''), 1700)]
    return '\n'.join(lines)

def batch_handler(update, context):  # type: ignore[override]
    try:
        msg_date=getattr(getattr(update,'message',None),'date',None)
        recv_delay=time.time()-msg_date.timestamp() if hasattr(msg_date,'timestamp') else 0.0
    except Exception: recv_delay=0.0
    default_cmds=['batch','candidate_reason','gate_check','paper_handoff','pstatus','health','errorlog']
    cmds=getattr(context,'args',None) or default_cmds
    cmds=[str(x).strip().lstrip('/') for x in cmds[:8] if str(x).strip()]
    stime=time.time(); timings=[]; outputs={}
    try: send(update, f'📦 묶음 확인 시작\n- 실행 {len(cmds)}개 / 접수지연 {recv_delay:.2f}s\n- 요약 txt에는 이전 요약 이후 매매 상세도 포함')
    except Exception: pass
    for i,name in enumerate(cmds,1):
        fn=COMMANDS.get(name); t0=time.time(); err=None
        if not fn:
            body=f'❌ /{name} 연결 없음'; err='no_handler'
        else:
            try: body=fn()
            except Exception as exc:
                body=f'❌ /{name} 오류 {exc.__class__.__name__}: {exc}'; err=f'{exc.__class__.__name__}: {exc}'; log_error(f'v799_batch_{name}', exc)
        sec=time.time()-t0; outputs[name]=body; timings.append({'name':name,'sec':sec,'error':err})
        try: send(update, f'[{i}/{len(cmds)}] /{name} ({sec:.2f}s / {"OK" if not err else "ERR"})\n{body}')
        except Exception as exc: log_error('v799_batch_send_step', exc)
    total=time.time()-stime
    try: status=_v650_send_summary_file(update, _v650_batch_summary_text(cmds, outputs, timings, recv_delay, total))
    except Exception as exc:
        status=f'txt 생성실패 {exc.__class__.__name__}'; log_error('v799_batch_summary_file', exc)
    mark='✅' if '전송완료' in status else '⚠️'; del_mark='✅' if '서버삭제' in status else ('❌' if '전송완료' in status else '❔')
    try: send(update, f'📎 묶음 요약집\n- 전송: {mark} {status}\n- 임시파일 삭제: {del_mark}\n- 처리합계: {total:.2f}s')
    except Exception: pass

# default command registry: compact v799 boards
COMMANDS['batch'] = _v799_batch_text
COMMANDS['summary'] = _v799_batch_text
COMMANDS['pbatch'] = _v799_batch_text
COMMANDS['health'] = _v799_health_text
COMMANDS['core'] = _v799_health_text
COMMANDS['deploy'] = _v799_health_text
COMMANDS['upgradestatus'] = _v799_health_text
COMMANDS['candidate_reason'] = _v799_reason_text
COMMANDS['reason'] = _v799_reason_text
COMMANDS['why_s1'] = _v799_reason_text
COMMANDS['quality'] = _v799_reason_text
COMMANDS['gate_check'] = _v799_gate_check_text
COMMANDS['paper_handoff'] = _v799_paper_handoff_text
COMMANDS['handoff'] = _v799_paper_handoff_text
COMMANDS['pstatus'] = _v799_pstatus_text
COMMANDS['status'] = _v799_pstatus_text
COMMANDS['trade'] = _v799_pstatus_text
COMMANDS['menu'] = _v799_menu_text
COMMANDS['help'] = _v799_menu_text

# compatibility aliases used by older handlers/tests
health_text = _v799_health_text
candidate_reason_text = _v799_reason_text
pstatus_text = _v799_pstatus_text
paper_handoff_text = _v799_paper_handoff_text


# =============================================================================
# main_bot v2.13.805: missed-candidate review summary in /batch
# - main remains a cache/status reader.  It does not recalculate candidate quality.
# - Owner is review_worker cache: clean_market_miss_review_v667.json.
# - Adds compact "아까운 후보/놓친 후보" section to /batch and the summary txt.
# =============================================================================
V650_BUILD_LABEL = 'v806_integrated_validation_freshness_2026-06-10'
BOT_VERSION = '수익형 v2.13.806'
MAIN_BOT_VERSION = BOT_VERSION
EXPECTED_PAPER_VERSION = 'paper_bot_v0.795'

_V805_MISS_BUCKET_LABELS = {
    'trigger_wait_missed': '방아쇠 대기 후 상승',
    'trigger_wait': '방아쇠 대기',
    'confirmation_wait_missed': '확인값 대기 후 상승',
    'confirm_wait_missed': '확인값 대기 후 상승',
    'price_confirm_wait': '가격/체결 확인 대기',
    'coverage_buried': '후보 전 단계에 묻힘',
    'feature_late': 'feature 반응 늦음',
    'orderflow_late': '체결/orderflow 늦음',
    'risk_filter_candidate': '위험필터였지만 상승',
    'hard_risk_hold': '위험 커서 보류 후 상승',
    'exec_risk_wait': '실행위험 재확인 후 상승',
    'common_scalp_watch': '공통초입 관찰 후 상승',
    'structure_recheck_s2': '구조 재확인 중 상승',
    's2_recheck': 'S2 재확인 중 상승',
}


def _v805_miss_label(v: Any) -> str:
    t = str(v or '-')
    return _V805_MISS_BUCKET_LABELS.get(t, _v799_label(t) if '_v799_label' in globals() else t)


def _v805_float(*vals: Any, default: float = 0.0) -> float:
    for v in vals:
        try:
            if v is None or v == '':
                continue
            return float(str(v).replace(',', '').replace('%', ''))
        except Exception:
            continue
    return default


def _v805_short(v: Any, limit: int = 34) -> str:
    if isinstance(v, list):
        txt = ','.join(str(x) for x in v[:3])
    else:
        txt = str(v or '-')
    txt = txt.replace('\n', ' ').strip()
    return txt if len(txt) <= limit else txt[:limit-1] + '…'


def _v805_missed_row_line(r: Dict[str, Any]) -> str:
    t = r.get('ticker') or r.get('market') or '-'
    stage = r.get('initial_stage') or r.get('stage') or r.get('grade') or '-'
    maxp = _v805_float(r.get('max_pct'), r.get('max_after_pct'), r.get('future_max_pct'), r.get('max_gain_pct'), default=0.0)
    curp = _v805_float(r.get('current_pct'), r.get('cur_pct'), r.get('end_pct'), default=0.0)
    bucket = _v805_miss_label(r.get('miss_bucket') or r.get('bucket') or r.get('missed_reason') or r.get('reason'))
    route = _v799_label(r.get('entry_route_v802') or r.get('entry_route') or r.get('route') or '') if '_v799_label' in globals() else str(r.get('entry_route') or '')
    route_txt = f' / {route}' if route and route != '-' else ''
    struct = _v799_label(r.get('trigger_archetype_v801') or r.get('structure_type') or r.get('plan_type') or '') if '_v799_label' in globals() else str(r.get('structure_type') or '')
    struct_txt = f' / {struct}' if struct and struct != '-' else ''
    rr = r.get('rr_ratio') or r.get('rr') or r.get('risk_reward') or ''
    rr_txt = f' / RR {rr}' if rr not in (None, '') else ''
    why = _v805_short(r.get('initial_reason') or r.get('reject_reason') or r.get('block_reason') or r.get('reason') or r.get('missed_reason'), 42)
    return f"- {t} {stage}{route_txt}{struct_txt} / 이후최고 {maxp:+.2f}% / 현재 {curp:+.2f}% / {bucket}{rr_txt} / 이유 {why}"


def _v805_missed_summary_lines(limit: int = 5) -> List[str]:
    path = BASE_DIR / 'clean_market_miss_review_v667.json'
    try:
        obj = _v650_load(path, {}) or {}
    except Exception as exc:
        log_error('v805_missed_summary_load', exc)
        obj = {}
    if not isinstance(obj, dict) or not obj:
        return [
            '- source: review_worker 놓친 후보 cache 없음 또는 아직 회전 전',
            '- 기준: main_bot은 후보 재계산하지 않고 review_worker cache만 읽음',
        ]
    try:
        age_txt = f"{_v650_file_age(path):.1f}s"
    except Exception:
        age_txt = '-'
    buckets = obj.get('miss_bucket_counts') if isinstance(obj.get('miss_bucket_counts'), dict) else {}
    bucket_line = ' / '.join(f"{_v805_miss_label(k)} {v}" for k, v in Counter(buckets or {}).most_common(7)) if buckets else '없음'
    true_rows = obj.get('true_missed_top') if isinstance(obj.get('true_missed_top'), list) else []
    rise_rows = obj.get('top_risers') if isinstance(obj.get('top_risers'), list) else []
    lines = [
        f"- source: review_worker missed cache / age {age_txt}",
        f"- 추적 {obj.get('tracking_total',0)} / 판정완료 {obj.get('matured_count',0)} / 상승후보 {obj.get('rise_count',0)} / 진짜 아까움 {obj.get('true_missed_count',0)}",
        '- 놓친 이유 TOP: ' + bucket_line,
    ]
    if not true_rows and not rise_rows:
        lines.append('- 아직 요약에 올릴 아까운 상승 후보 없음')
        return lines
    lines.append('[진짜 아까운 후보 TOP]')
    rows = [r for r in true_rows if isinstance(r, dict)]
    lines += [_v805_missed_row_line(r) for r in rows[:limit]] or ['- 없음']
    lines.append('[아까운 상승 후보 TOP]')
    rows2 = [r for r in rise_rows if isinstance(r, dict)]
    lines += [_v805_missed_row_line(r) for r in rows2[:limit]] or ['- 없음']
    # Add small bucket-specific hints so the next surgery can decide whether to move trigger/route/queue.
    hints=[]
    for key, label in [('trigger_wait_missed','방아쇠'), ('confirmation_wait_missed','확인값'), ('coverage_buried','coverage'), ('orderflow_late','orderflow'), ('risk_filter_candidate','위험필터')]:
        n = int(_v805_float((buckets or {}).get(key), default=0))
        if n:
            hints.append(f'{label} {n}')
    if hints:
        lines.append('- 다음 판정 포인트: ' + ' / '.join(hints))
    lines.append('- 판독: 이 표는 조건완화가 아니라 “안 샀는데 오른 이유”를 보는 복기표')
    return lines


def _v805_batch_text() -> str:
    score=_v650_score(); review=_v650_review(); stop=_v681_stop_review_summary() if '_v681_stop_review_summary' in globals() else {}
    lines=['📦 코인봇 전체 요약 /batch']
    lines += _v799_section('① 성과') + _v651_score_window_lines() + [f"- score/review 오늘: {score.get('today_closed_count','-')} / {review.get('today_closed_count','-')}"]
    lines += _v799_section('② 후보 현황') + _v799_candidate_brief_lines() + _v799_pipeline_brief_lines()
    snap=_v650_candidate_snapshot()
    lines += _v799_section('③ S1 못 간 이유') + ['- ' + _v799_counter_line(snap.get('reasons'), 6), '- 위험/주의: ' + _v799_counter_line(snap.get('risks'), 5)]
    lines += _v799_section('④ 구조계획') + _v799_plan_lines(4)
    lines += _v799_section('⑤ S1 hold → paper 소비') + _v743_s1_hold_lines() + _v799_paper_hold_trace_lines()
    lines += _v799_section('⑥ 이전 요약 이후 매매') + ['- 상세 매매 복기표는 이 요약 txt 하단 [이전 요약 이후 매매 상세]에 1회만 표시']
    lines += _v799_section('⑦ 아까운 후보 / 놓친 후보') + _v805_missed_summary_lines(5)
    lines += _v799_section('⑧ 자원/정리') + _v650_resource_lines() + [f"- 손절초과: 최근 trace {stop.get('n',0)}건 / loop gap 의심 {stop.get('loop_gap_suspect',0)}건", '- 요약 txt는 전송 후 서버 임시파일 삭제']
    lines += ['', '더 보기: /candidate_reason /gate_check /paper_handoff /pstatus /errorlog /missed_candidates']
    return '\n'.join(lines)


def _v805_menu_text() -> str:
    return '\n'.join(['🧭 코인봇 메뉴 /menu', '', '자주 보는 명령어', '- /batch: 전체 요약 + 매매상세 + 아까운 후보 요약', '- /missed_candidates: 놓친 후보/아까운 상승 상세', '- /health: worker/cache/자원/정리 상태', '- /candidate_reason: S1 못 간 이유와 구조계획', '- /gate_check: S1 최종심사와 paper 소비 확인', '- /paper_handoff: 메인→페이퍼 전달 상태', '- /pstatus: 페이퍼 OPEN/CLOSED/hold 소비', '- /errorlog: 새 오류 확인', '', '표시 기준', '- S1=실전 후보 / S2=빠른 재확인 / S3=관찰', '- 아까운 후보는 review_worker 사후검증 cache 기준이며 main에서 재계산하지 않음'])


def _v650_batch_summary_text(cmds: List[str], outputs: Dict[str,str], timings: List[Dict[str,Any]], recv_delay: float, total_sec: float) -> str:  # type: ignore[override]
    global _V797_PENDING_BATCH_MARKER_TS
    batch_until = now_ts(); _V797_PENDING_BATCH_MARKER_TS = batch_until
    since_ts = _v798_batch_marker_ts() if '_v798_batch_marker_ts' in globals() else 0.0
    lines=['코인봇 묶음 요약집 v806', f'- 생성: {_v800_kst_text(batch_until)}', f'- 메인봇: {BOT_VERSION} / {V650_BUILD_LABEL}', f'- 접수지연: {recv_delay:.2f}s / 처리합계: {total_sec:.2f}s', '', '[명령 처리시간]']
    for t in timings:
        lines.append(f"- {'✅' if not t.get('error') else '❌'} /{t.get('name','?')}: {float(t.get('sec') or 0):.2f}s / {'OK' if not t.get('error') else 'ERR'}")
    lines += ['', '[전체 요약]', _v650_safe_body(outputs.get('batch') or _v805_batch_text(), 4600), '']
    lines += _v799_trade_detail_lines_range(since_ts, batch_until)
    lines += ['', '[아까운 후보 / 놓친 후보 상세]'] + _v805_missed_summary_lines(10)
    lines += ['', '[명령별 상세]']
    for name in cmds:
        lines += ['', f'/{name}', _v650_safe_body(outputs.get(name,''), 1700)]
    return '\n'.join(lines)


# =============================================================================
# main_bot v2.13.806: integrated validation board + S2→S1 freshness trace
# - main remains a cache/status reader. It does not change S1/S2/S3 conditions.
# - Combines: bought-trade validation, missed-candidate validation,
#   common-scalp failure checklist, structure route board, and recheck freshness.
# =============================================================================
V650_BUILD_LABEL = 'v806_integrated_validation_freshness_2026-06-10'
BOT_VERSION = '수익형 v2.13.806'
MAIN_BOT_VERSION = BOT_VERSION
EXPECTED_PAPER_VERSION = 'paper_bot_v0.795'


def _v806_list(v: Any, limit: int = 20) -> List[Any]:
    if isinstance(v, list):
        return v[:limit]
    if isinstance(v, (tuple, set)):
        return list(v)[:limit]
    if v in (None, '', {}, []):
        return []
    return [v]


def _v806_nested_dict(obj: Dict[str, Any], *keys: str) -> Dict[str, Any]:
    cur: Any = obj
    for k in keys:
        if not isinstance(cur, dict):
            return {}
        cur = cur.get(k)
    return cur if isinstance(cur, dict) else {}


def _v806_timing_obj(row: Dict[str, Any]) -> Dict[str, Any]:
    if not isinstance(row, dict):
        return {}
    for src in (
        row.get('entry_timing_spine'),
        row.get('entry_timing_trace'),
        _v806_nested_dict(row, 'entry_context', 'entry_timing_spine'),
        _v806_nested_dict(row, 'entry_context', 'entry_timing_trace'),
        _v806_nested_dict(row, 'plan', 'entry_timing_spine'),
        _v806_nested_dict(row, 'plan', 'entry_timing_trace'),
    ):
        if isinstance(src, dict) and src:
            return src
    return {}


def _v806_recheck_trace_obj(row: Dict[str, Any]) -> Dict[str, Any]:
    if not isinstance(row, dict):
        return {}
    for src in (
        row.get('recheck_freshness_trace_v806'),
        _v806_nested_dict(row, 'entry_context', 'recheck_freshness_trace_v806'),
        _v806_nested_dict(row, 'plan', 'recheck_freshness_trace_v806'),
    ):
        if isinstance(src, dict) and src:
            return src
    return {}


def _v806_metric(row: Dict[str, Any], *keys: str, default: float = 0.0) -> float:
    vals: List[Any] = []
    for k in keys:
        vals.append(row.get(k))
    plan = _v796_plan_obj(row) if '_v796_plan_obj' in globals() else {}
    for k in keys:
        if isinstance(plan, dict):
            vals.append(plan.get(k))
    levels = row.get('structure_levels') if isinstance(row.get('structure_levels'), dict) else {}
    for k in keys:
        vals.append(levels.get(k))
    return _v805_float(*vals, default=default) if '_v805_float' in globals() else _v650_num(*vals, default=default)


def _v806_missed_validation_lines(limit: int = 5) -> List[str]:
    path = BASE_DIR / 'clean_market_miss_review_v667.json'
    obj = _v650_load(path, {}) or {}
    if not isinstance(obj, dict) or not obj:
        return ['[안 산 후보 검증]', '- missed cache 없음 · review_worker 회전 후 확인']
    rows: List[Dict[str, Any]] = []
    for key in ('true_missed_top', 'top_risers', 'rows', 'items'):
        v = obj.get(key)
        if isinstance(v, list):
            rows += [x for x in v if isinstance(x, dict)]
    # de-duplicate by ticker + max pct
    dedup: Dict[str, Dict[str, Any]] = {}
    for r in rows:
        t = str(r.get('ticker') or r.get('market') or '-').upper()
        maxp = _v805_float(r.get('max_pct'), r.get('max_after_pct'), r.get('future_max_pct'), r.get('max_gain_pct'), default=0.0)
        k = t
        if k not in dedup or maxp > _v805_float(dedup[k].get('max_pct'), dedup[k].get('max_after_pct'), dedup[k].get('future_max_pct'), dedup[k].get('max_gain_pct'), default=0.0):
            dedup[k] = r
    rows = list(dedup.values())
    cats: Counter = Counter()
    samples: Dict[str, List[str]] = {'tradable_miss': [], 'impossible_rise': [], 'queue_fail': [], 'trigger_fail': [], 'confirm_late': [], 'risk_filter': []}
    for r in rows:
        maxp = _v805_float(r.get('max_pct'), r.get('max_after_pct'), r.get('future_max_pct'), r.get('max_gain_pct'), default=0.0)
        if maxp < 0.7:
            continue
        t = str(r.get('ticker') or r.get('market') or '-').upper()
        stage = str(r.get('initial_stage') or r.get('stage') or r.get('grade') or '-')
        bucket = str(r.get('miss_bucket') or r.get('bucket') or r.get('missed_reason') or r.get('reason') or '')
        why_txt = ' '.join(str(x) for x in _v806_list(r.get('reason') or r.get('initial_reason') or r.get('block_reason') or r.get('missed_reason'), 6))
        spread = _v805_float(r.get('spread_pct'), r.get('spread'), default=0.0)
        slip = _v805_float(r.get('slippage_pct'), r.get('slippage'), default=spread)
        buy = _v805_float(r.get('buy_ratio'), r.get('buy'), default=0.0)
        sus = _v805_float(r.get('buy_sustain_1m'), r.get('sustain'), r.get('buy_sustain'), default=0.0)
        gap = _v805_float(r.get('trigger_gap_pct'), r.get('gap_pct'), default=0.0)
        tradable = bool(spread <= 0.45 and slip <= 0.45 and (buy >= 0.40 or sus >= 0.40))
        impossible = bool(spread >= 0.85 or slip >= 0.85 or ('스프레드' in why_txt and spread > 0.60))
        line = f"{t} {stage} max {maxp:+.2f}% / gap {gap:+.2f}% / 체결 {buy:.2f}, 지속 {sus:.2f}, 스프 {spread:.2f}, 미끄 {slip:.2f}"
        if impossible:
            cats['못 사는 상승'] += 1
            if len(samples['impossible_rise']) < limit: samples['impossible_rise'].append(line)
        elif 'trigger' in bucket or '방아쇠' in why_txt:
            cats['방아쇠 실패'] += 1
            if len(samples['trigger_fail']) < limit: samples['trigger_fail'].append(line)
        elif 'confirm' in bucket or '확인' in why_txt or 'feature' in bucket or 'orderflow' in bucket:
            cats['확인값 늦음'] += 1
            if len(samples['confirm_late']) < limit: samples['confirm_late'].append(line)
        elif 'risk' in bucket or '위험' in why_txt or '하드 위험' in why_txt:
            cats['위험필터 확인대상'] += 1
            if len(samples['risk_filter']) < limit: samples['risk_filter'].append(line)
        elif 'coverage' in bucket or '전 단계' in why_txt:
            cats['배차/coverage 실패'] += 1
            if len(samples['queue_fail']) < limit: samples['queue_fail'].append(line)
        elif tradable:
            cats['거래가능 놓침'] += 1
            if len(samples['tradable_miss']) < limit: samples['tradable_miss'].append(line)
        else:
            cats['분류보류 상승'] += 1
    bucket_counts = obj.get('miss_bucket_counts') if isinstance(obj.get('miss_bucket_counts'), dict) else {}
    lines = ['[안 산 후보 검증]', f"- 추적 {obj.get('tracking_total',0)} / 판정완료 {obj.get('matured_count',0)} / 상승후보 {obj.get('rise_count',0)} / 검증분류 {sum(cats.values())}"]
    lines.append('- 검증분류: ' + (_v799_counter_line(cats, 8) if cats else '상승후보 없음'))
    if bucket_counts:
        lines.append('- 원인원본: ' + _v799_counter_line(Counter(bucket_counts), 6))
    for title, key in [('거래가능 놓침', 'tradable_miss'), ('배차/coverage 실패', 'queue_fail'), ('못 사는 상승', 'impossible_rise'), ('방아쇠 실패', 'trigger_fail'), ('확인값 늦음', 'confirm_late'), ('위험필터 확인대상', 'risk_filter')]:
        if samples[key]:
            lines.append(f'- {title} 샘플: ' + ' / '.join(samples[key][:3]))
    return lines


def _v806_trade_validation_lines(since_ts: float = 0.0, until_ts: float = 0.0, limit: int = 5) -> List[str]:
    events = []
    until_ts = until_ts or now_ts()
    for ev in _v798_trade_cache_events() if '_v798_trade_cache_events' in globals() else []:
        if not isinstance(ev, dict):
            continue
        ts = _v650_num(ev.get('ts'), default=0.0)
        if ts <= 0:
            continue
        if since_ts > 0 and ts <= since_ts:
            continue
        if until_ts > 0 and ts > until_ts + 2:
            continue
        events.append(ev)
    closed = [e for e in events if str(e.get('kind')) == 'closed']
    cats: Counter = Counter()
    samples: Dict[str, List[str]] = {'late': [], 'structure_miss': [], 'confirm_illusion': [], 'instant_reverse': [], 'normal_fail': [], 'timing_missing': []}
    for e in closed:
        t = str(e.get('ticker') or '-')
        pnl = _v650_num(e.get('pnl_pct'), default=0.0)
        peak = _v650_num(e.get('peak_pct'), default=0.0)
        flags = [str(x) for x in _v806_list(e.get('quality_flags_v800'), 10)]
        qlabel = str(e.get('quality_label_v800') or '')
        plan = e.get('plan') if isinstance(e.get('plan'), dict) else {}
        timing = _v806_timing_obj(e)
        first_delay = _v650_num(timing.get('first_to_s1_delay_sec'), timing.get('first_to_open_delay_sec'), timing.get('first_to_now_delay_sec'), default=-1.0)
        s2_delay = _v650_num(timing.get('s2_to_s1_delay_sec'), timing.get('s2_to_open_delay_sec'), default=-1.0)
        pre_ret = _v650_num(timing.get('first_to_now_return_pct'), timing.get('first_to_current_return_pct'), default=0.0)
        line = f"{t} {pnl:+.2f}% / 최고 {peak:+.2f}% / first→open {first_delay:.0f}s / S2→open {s2_delay:.0f}s / 전상승 {pre_ret:+.2f}%"
        if first_delay < 0 and not timing:
            cats['시간표 없음'] += 1
            if len(samples['timing_missing']) < limit: samples['timing_missing'].append(f"{t} {pnl:+.2f}%")
        if '바로역행' in flags or '바로역행' in qlabel or (peak <= 0.05 and pnl < 0):
            cats['바로역행'] += 1
            if len(samples['instant_reverse']) < limit: samples['instant_reverse'].append(line)
        if first_delay >= 90 or s2_delay >= 70 or pre_ret >= 0.80:
            cats['늦은 진입 의심'] += 1
            if len(samples['late']) < limit: samples['late'].append(line)
        if '계산선재확인' in flags or str(e.get('line_quality') or '').find('calculated') >= 0 or str(e.get('line_quality') or '').find('계산선') >= 0:
            cats['계산선/구조 재확인'] += 1
            if len(samples['structure_miss']) < limit: samples['structure_miss'].append(line)
        chk = e.get('entry_checks_v800') if isinstance(e.get('entry_checks_v800'), dict) else {}
        buy = _v650_num(chk.get('buy_ratio'), default=0.0)
        sus = _v650_num(chk.get('buy_sustain_1m'), default=0.0)
        react = _v650_num(chk.get('price_reaction_pct'), default=0.0)
        if pnl < 0 and react >= 0.30 and buy >= 0.70 and sus >= 0.70 and peak <= 0.05:
            cats['확인값 착시'] += 1
            if len(samples['confirm_illusion']) < limit: samples['confirm_illusion'].append(f"{t} 반응 {react:+.2f}% 체결 {buy:.2f} 지속 {sus:.2f} → {pnl:+.2f}%")
        if pnl < 0 and not any(x in cats for x in ()):  # no-op guard for lint-free branch shape
            pass
    lines = ['[산 후보 검증]', f"- 구간 CLOSED {len(closed)}개 / 검증: " + (_v799_counter_line(cats, 8) if cats else '새 CLOSED 없음')]
    for title, key in [('바로역행', 'instant_reverse'), ('늦은 진입 의심', 'late'), ('확인값 착시', 'confirm_illusion'), ('구조/계산선 재확인', 'structure_miss'), ('시간표 없음', 'timing_missing')]:
        if samples[key]:
            lines.append(f'- {title}: ' + ' / '.join(samples[key][:3]))
    if closed and not any(samples.values()):
        lines.append('- 판독: 새 CLOSED는 있으나 검증 태그가 부족함 · paper detail 필드 확인 필요')
    return lines


def _v806_common_scalp_validation_lines(limit: int = 5) -> List[str]:
    snap = _v650_candidate_snapshot()
    rows = [r for r in (snap.get('trade_rows') or []) if isinstance(r, dict)]
    watch = ok = promoted = 0
    fail: Counter = Counter(); pat: Counter = Counter(); samples=[]
    for r in rows:
        p = _v796_plan_obj(r) if '_v796_plan_obj' in globals() else {}
        if not isinstance(p, dict):
            p = {}
        cs = p.get('common_scalp_entry_v802') if isinstance(p.get('common_scalp_entry_v802'), dict) else {}
        route = str(p.get('entry_route_v802') or 'structure')
        key = str(p.get('common_pattern_key_v802') or cs.get('common_pattern_key') or '')
        if cs.get('common_scalp_watch') or key:
            watch += 1
            if key: pat[key] += 1
        if cs.get('common_scalp_ok'):
            ok += 1
        if route == 'common_scalp' and _v650_stage(r) == 'S1':
            promoted += 1
        # failure checklist from available metrics, display only
        react = _v806_metric(r, 'price_reaction_pct', 'reaction_pct', default=0.0)
        buy = _v806_metric(r, 'buy_ratio', default=0.0)
        sus = _v806_metric(r, 'buy_sustain_1m', 'buy_sustain_60s', default=0.0)
        spread = _v806_metric(r, 'spread_pct', default=99.0)
        slip = _v806_metric(r, 'slippage_pct', default=spread)
        if key or cs:
            if react < 0.30: fail['가격반응 부족'] += 1
            if buy < 0.75: fail['체결 부족'] += 1
            if sus < 0.75: fail['1분지속 부족'] += 1
            if spread > 0.20 or slip > 0.22: fail['실행비용 부담'] += 1
            txt = ' '.join(str(x) for x in (_v806_list(r.get('risk_tags'), 8) + _v806_list(r.get('structure_risk_tags'), 8)))
            if 'VWAP/EMA하단' in txt or '하단' in txt: fail['VWAP/EMA 위치 불량'] += 1
            if len(samples) < limit:
                samples.append(f"{_v650_ticker(r)}({_v650_stage(r)}/{_v799_label(route)}/{key.replace('common_scalp|','')[:26] or '-'} / 반응 {react:+.2f} 체결 {buy:.2f} 지속 {sus:.2f} 스프 {spread:.2f})")
    lines = ['[공통초입 검증]', f'- 관찰 {watch} / 통과 {ok} / 승격 {promoted}']
    lines.append('- 막힌 체크: ' + (_v799_counter_line(fail, 8) if fail else '체크대상 없음'))
    if pat:
        lines.append('- 패턴 TOP: ' + _v799_counter_line(pat, 5))
    if samples:
        lines.append('- 샘플: ' + ' / '.join(samples[:4]))
    return lines


def _v806_structure_validation_lines(limit: int = 5) -> List[str]:
    # Current candidate-route board. Trade-result by structure requires future paper detail with plan fields, so current board is candidate-side validation.
    snap = _v650_candidate_snapshot()
    rows = [r for r in (snap.get('trade_rows') or []) if isinstance(r, dict)]
    typ = Counter(); state = Counter(); risky = Counter(); samples=[]
    for r in rows:
        p = _v796_plan_obj(r) if '_v796_plan_obj' in globals() else {}
        if not p: continue
        arche = str(p.get('trigger_archetype_v801') or 'common_structure')
        typ[arche] += 1
        state[str(p.get('plan_state') or 'unknown')] += 1
        if str(p.get('line_quality') or '') == 'calculated_line_recheck':
            risky['계산선 재확인'] += 1
        if str(p.get('structure_interpretation') or '').find('후속약함') >= 0:
            risky['선반응 후속약함'] += 1
        if len(samples) < limit and _v650_stage(r) in ('S1','S2'):
            samples.append(f"{_v650_ticker(r)}({_v650_stage(r)}/{_v799_label(arche)}/{_v799_label(p.get('plan_state'))}/RR {p.get('rr_ratio') or 0}/gap {p.get('trigger_gap_pct') or 0}%)")
    return ['[구조별 검증]', '- 구조타입: ' + (_v799_counter_line(typ, 6) if typ else '없음'), '- 계획상태: ' + (_v799_counter_line(state, 5) if state else '없음'), '- 구조주의: ' + (_v799_counter_line(risky, 5) if risky else '없음'), '- 샘플: ' + (' / '.join(samples[:4]) if samples else '-')]


def _v806_freshness_validation_lines(limit: int = 5) -> List[str]:
    snap = _v650_candidate_snapshot()
    rows = [r for r in (snap.get('trade_rows') or []) if isinstance(r, dict)]
    s2_rows = [r for r in rows if _v650_stage(r) == 'S2']
    counts: Counter = Counter(); source_age_counter: Counter = Counter(); samples=[]
    for r in s2_rows:
        tr = _v806_recheck_trace_obj(r)
        timing = _v806_timing_obj(r)
        status = str(tr.get('fresh_status') or tr.get('status') or '')
        if not status:
            age = _v650_num(timing.get('source_event_age_sec_v752'), timing.get('source_event_age_sec_v750'), default=999999.0)
            if age <= 20: status = 'fresh_update'
            elif age <= 60: status = 'fresh_age_watch'
            else: status = 'trace_missing_or_stale'
        counts[status] += 1
        src_age = _v650_num(tr.get('source_event_age_sec'), timing.get('source_event_age_sec_v752'), timing.get('source_event_age_sec_v750'), default=999999.0)
        if src_age <= 20: source_age_counter['source<=20s'] += 1
        elif src_age <= 60: source_age_counter['source<=60s'] += 1
        elif src_age < 99999: source_age_counter['source>60s'] += 1
        else: source_age_counter['source age 없음'] += 1
        if len(samples) < limit:
            p = _v796_plan_obj(r) if '_v796_plan_obj' in globals() else {}
            seen = tr.get('seen_count') or tr.get('recheck_count') or '-'
            changed = tr.get('value_changed_count') if tr.get('value_changed_count') not in (None, '') else '-'
            gap = p.get('trigger_gap_pct') if isinstance(p, dict) else r.get('trigger_gap_pct')
            buy = _v806_metric(r, 'buy_ratio', default=0.0)
            sus = _v806_metric(r, 'buy_sustain_1m', default=0.0)
            samples.append(f"{_v650_ticker(r)} S2 / {status} / 확인 {seen}회 / 변화 {changed} / age {src_age if src_age<99999 else '-'}s / gap {gap or 0}% / 체결 {buy:.2f}, 지속 {sus:.2f}")
    # Use worker/cache age board too, because sometimes row-level history is not available yet.
    try:
        worker_age = f"strategy {_v650_file_age(BASE_DIR/'clean_strategy_worker_status.json'):.1f}s / candidate {_v650_file_age(FILES.get('paper_latest', BASE_DIR/'paper_candidates_latest.jsonl')):.1f}s / router {_v650_file_age(FILES.get('target_router', BASE_DIR/'clean_target_router_queue.json')):.1f}s / handoff {_v650_file_age(FILES.get('paper_handoff', BASE_DIR/'clean_strategy_paper_handoff_status.json')):.1f}s"
    except Exception:
        worker_age = '-'
    lines = ['[재확인 freshness]', f'- S2 대상 {len(s2_rows)} / 상태: ' + (_v799_counter_line(counts, 8) if counts else 'S2 없음'), '- source age: ' + (_v799_counter_line(source_age_counter, 5) if source_age_counter else '없음'), f'- cache age: {worker_age}']
    if samples:
        lines.append('- 샘플: ' + ' / '.join(samples[:4]))
    lines.append('- 판독기준: 여러 번 확인했는지(seen), 값이 변했는지, source age가 60초를 넘는지 확인')
    return lines


def _v806_integrated_validation_lines(since_ts: float = 0.0, until_ts: float = 0.0, compact: bool = True) -> List[str]:
    lines: List[str] = []
    lines += _v806_trade_validation_lines(since_ts, until_ts, 4 if compact else 8)
    lines += _v806_missed_validation_lines(4 if compact else 8)
    lines += _v806_common_scalp_validation_lines(4 if compact else 8)
    lines += _v806_structure_validation_lines(4 if compact else 8)
    lines += _v806_freshness_validation_lines(4 if compact else 8)
    lines.append('- 다음 판단: 열면 안 됐던 패턴 / 놓친 패턴 / 새 구조 후보 / 배차 우선순위 수정 후보를 이 판에서 같이 봄')
    return lines


def _v806_batch_text() -> str:
    score=_v650_score(); review=_v650_review(); stop=_v681_stop_review_summary() if '_v681_stop_review_summary' in globals() else {}
    since_ts = _v798_batch_marker_ts() if '_v798_batch_marker_ts' in globals() else 0.0
    until_ts = now_ts()
    lines=['📦 코인봇 전체 요약 /batch']
    lines += _v799_section('① 성과') + _v651_score_window_lines() + [f"- score/review 오늘: {score.get('today_closed_count','-')} / {review.get('today_closed_count','-')}"]
    lines += _v799_section('② 후보 현황') + _v799_candidate_brief_lines() + _v799_pipeline_brief_lines()
    snap=_v650_candidate_snapshot()
    lines += _v799_section('③ S1 못 간 이유') + ['- ' + _v799_counter_line(snap.get('reasons'), 6), '- 위험/주의: ' + _v799_counter_line(snap.get('risks'), 5)]
    lines += _v799_section('④ 구조계획') + _v799_plan_lines(4)
    lines += _v799_section('⑤ S1 hold → paper 소비') + _v743_s1_hold_lines() + _v799_paper_hold_trace_lines()
    lines += _v799_section('⑥ 이전 요약 이후 매매') + ['- 상세 매매 복기표는 이 요약 txt 하단 [이전 요약 이후 매매 상세]에 1회만 표시']
    lines += _v799_section('⑦ 통합 검증판') + _v806_integrated_validation_lines(since_ts, until_ts, compact=True)
    lines += _v799_section('⑧ 아까운 후보 / 놓친 후보') + _v805_missed_summary_lines(5)
    lines += _v799_section('⑨ 자원/정리') + _v650_resource_lines() + [f"- 손절초과: 최근 trace {stop.get('n',0)}건 / loop gap 의심 {stop.get('loop_gap_suspect',0)}건", '- 요약 txt는 전송 후 서버 임시파일 삭제']
    lines += ['', '더 보기: /candidate_reason /gate_check /paper_handoff /pstatus /errorlog /missed_candidates /validation_board']
    return '\n'.join(lines)


def _v806_validation_board_text() -> str:
    since_ts = _v798_batch_marker_ts() if '_v798_batch_marker_ts' in globals() else 0.0
    lines = ['🧪 통합 검증판 /validation_board · v806', '- 기준: candidate snapshot + paper trade detail cache + review_worker missed cache. main 재계산/조건변경 없음.']
    lines += _v806_integrated_validation_lines(since_ts, now_ts(), compact=False)
    return '\n'.join(lines)


def _v806_menu_text() -> str:
    return '\n'.join(['🧭 코인봇 메뉴 /menu', '', '자주 보는 명령어', '- /batch: 전체 요약 + 통합 검증판 + 매매상세', '- /validation_board: 산 후보/안 산 후보/공통초입/구조/freshness 검증', '- /missed_candidates: 놓친 후보/아까운 상승 상세', '- /health: worker/cache/자원/정리 상태', '- /candidate_reason: S1 못 간 이유와 구조계획', '- /gate_check: S1 최종심사와 paper 소비 확인', '- /paper_handoff: 메인→페이퍼 전달 상태', '- /pstatus: 페이퍼 OPEN/CLOSED/hold 소비', '- /errorlog: 새 오류 확인', '', '표시 기준', '- S1=실전 후보 / S2=빠른 재확인 / S3=관찰', '- 통합 검증판은 조건완화가 아니라 다음 수술 근거를 한 화면에 모으는 판'])


def _v650_batch_summary_text(cmds: List[str], outputs: Dict[str,str], timings: List[Dict[str,Any]], recv_delay: float, total_sec: float) -> str:  # type: ignore[override]
    global _V797_PENDING_BATCH_MARKER_TS
    batch_until = now_ts(); _V797_PENDING_BATCH_MARKER_TS = batch_until
    since_ts = _v798_batch_marker_ts() if '_v798_batch_marker_ts' in globals() else 0.0
    lines=['코인봇 묶음 요약집 v806', f'- 생성: {_v800_kst_text(batch_until)}', f'- 메인봇: {BOT_VERSION} / {V650_BUILD_LABEL}', f'- 접수지연: {recv_delay:.2f}s / 처리합계: {total_sec:.2f}s', '', '[명령 처리시간]']
    for t in timings:
        lines.append(f"- {'✅' if not t.get('error') else '❌'} /{t.get('name','?')}: {float(t.get('sec') or 0):.2f}s / {'OK' if not t.get('error') else 'ERR'}")
    lines += ['', '[전체 요약]', _v650_safe_body(outputs.get('batch') or _v806_batch_text(), 6200), '']
    lines += _v799_trade_detail_lines_range(since_ts, batch_until)
    lines += ['', '[통합 검증판 상세]'] + _v806_integrated_validation_lines(since_ts, batch_until, compact=False)
    lines += ['', '[아까운 후보 / 놓친 후보 상세]'] + _v805_missed_summary_lines(10)
    lines += ['', '[명령별 상세]']
    for name in cmds:
        lines += ['', f'/{name}', _v650_safe_body(outputs.get(name,''), 1700)]
    return '\n'.join(lines)

# v806 command registry override: swap compact boards only. Conditions/ledger untouched.
COMMANDS['batch'] = _v806_batch_text
COMMANDS['summary'] = _v806_batch_text
COMMANDS['pbatch'] = _v806_batch_text
COMMANDS['validation_board'] = _v806_validation_board_text
COMMANDS['validate'] = _v806_validation_board_text
COMMANDS['menu'] = _v806_menu_text
COMMANDS['help'] = _v806_menu_text

# v805 registry superseded by v806 above.



# =============================================================================
# main_bot v2.13.807: price-lag quality board
# - Purpose: separate "체결/지속 선행 후 가격후행" from "체결만 강한 착시".
# - main remains a cache/status reader. No S1/S2/S3 thresholds, no paper/ledger changes.
# =============================================================================
V650_BUILD_LABEL = 'v807_price_lag_quality_board_2026-06-10'
BOT_VERSION = '수익형 v2.13.807'
MAIN_BOT_VERSION = BOT_VERSION
EXPECTED_PAPER_VERSION = 'paper_bot_v0.795'


def _v807_plan_obj(row: Dict[str, Any]) -> Dict[str, Any]:
    try:
        return _v796_plan_obj(row) if '_v796_plan_obj' in globals() else {}
    except Exception:
        p = row.get('structure_trade_plan_v796') if isinstance(row.get('structure_trade_plan_v796'), dict) else {}
        return p


def _v807_common_obj(row: Dict[str, Any]) -> Dict[str, Any]:
    p = _v807_plan_obj(row)
    cs = p.get('common_scalp_entry_v802') if isinstance(p.get('common_scalp_entry_v802'), dict) else {}
    if not cs and isinstance(row.get('common_scalp_entry_v802'), dict):
        cs = row.get('common_scalp_entry_v802')
    return cs if isinstance(cs, dict) else {}


def _v807_metric(row: Dict[str, Any], *keys: str, default: float = 0.0) -> float:
    vals: List[Any] = []
    for k in keys:
        vals.append(row.get(k))
    p = _v807_plan_obj(row)
    for k in keys:
        vals.append(p.get(k))
    cs = _v807_common_obj(row)
    met = cs.get('metrics') if isinstance(cs.get('metrics'), dict) else {}
    aliases = {
        'price_reaction_pct': ('react', 'reaction', 'price_reaction_pct'),
        'reaction_pct': ('react', 'reaction', 'price_reaction_pct'),
        'buy_ratio': ('buy', 'buy_ratio'),
        'buy_sustain_1m': ('sustain', 'sustain20', 'buy_sustain_1m'),
        'buy_sustain_60s': ('sustain', 'sustain20', 'buy_sustain_1m'),
        'spread_pct': ('spread', 'spread_pct'),
        'slippage_pct': ('slippage', 'slippage_pct'),
        'change_3m_pct': ('ch3', 'change_3m_pct'),
        'change_5m_pct': ('ch5', 'change_5m_pct'),
        'volume_ratio': ('volume_ratio',),
        'volume_expansion_pct': ('volume_expansion_pct',),
        'vwap_gap_pct': ('vwap_gap_pct',),
        'ema_gap_pct': ('ema_gap_pct',),
    }
    for k in keys:
        for mk in aliases.get(k, (k,)):
            vals.append(met.get(mk))
    try:
        return _v805_float(*vals, default=default)
    except Exception:
        return _v650_num(*vals, default=default)


def _v807_metrics_obj(row: Dict[str, Any]) -> Dict[str, float]:
    spread = _v807_metric(row, 'spread_pct', default=99.0)
    return {
        'react': _v807_metric(row, 'price_reaction_pct', 'reaction_pct', 'change_1m_pct', 'price_chg_60s', default=0.0),
        'buy': _v807_metric(row, 'buy_ratio', default=0.0),
        'sustain': _v807_metric(row, 'buy_sustain_1m', 'buy_sustain_60s', default=0.0),
        'spread': spread,
        'slippage': _v807_metric(row, 'slippage_pct', default=spread),
        'ch3': _v807_metric(row, 'change_3m_pct', 'price_chg_3m', default=0.0),
        'ch5': _v807_metric(row, 'change_5m_pct', 'price_chg_5m', default=0.0),
        'vwap': _v807_metric(row, 'vwap_gap_pct', default=0.0),
        'ema': _v807_metric(row, 'ema_gap_pct', default=0.0),
    }


def _v807_quality_bucket_from_values(react: float, buy: float, sustain: float, spread: float, slip: float, future_max: Optional[float] = None) -> str:
    exec_ok = bool(spread <= 0.45 and slip <= 0.45)
    impossible = bool(spread >= 0.85 or slip >= 0.85)
    lead = bool(exec_ok and buy >= 0.62 and sustain >= 0.62 and -0.12 <= react < 0.18)
    strong_lead = bool(exec_ok and buy >= 0.72 and sustain >= 0.70 and -0.08 <= react < 0.16)
    both_strong = bool(exec_ok and react >= 0.30 and buy >= 0.68 and sustain >= 0.65)
    if impossible:
        return '거래불가 상승/품질제외'
    if future_max is not None:
        if lead and future_max >= 0.70:
            return '가격후행 성공'
        if strong_lead and future_max < 0.40:
            return '체결착시 확인'
        if both_strong and future_max < 0.40:
            return '강한확인값 착시'
        if both_strong and future_max >= 0.70:
            return '동시강한 정상상승'
        if future_max >= 0.70 and exec_ok:
            return '상승했지만 품질불명'
        return '상승부족/보류'
    if strong_lead:
        return '체결선행 가격대기'
    if lead:
        return '체결선행 관찰'
    if both_strong:
        return '가격체결 동시강함'
    if exec_ok and buy >= 0.72 and sustain >= 0.70 and react <= 0.02:
        return '체결착시 위험'
    if not exec_ok:
        return '실행비용 부담'
    return '품질보류'


def _v807_missed_rows() -> List[Dict[str, Any]]:
    obj = _v650_load(BASE_DIR / 'clean_market_miss_review_v667.json', {}) or {}
    if not isinstance(obj, dict):
        return []
    rows: List[Dict[str, Any]] = []
    for key in ('true_missed_top', 'top_risers', 'rows', 'items'):
        v = obj.get(key)
        if isinstance(v, list):
            rows.extend([x for x in v if isinstance(x, dict)])
    dedup: Dict[str, Dict[str, Any]] = {}
    for r in rows:
        t = str(r.get('ticker') or r.get('market') or '-').upper()
        if not t or t == '-':
            continue
        maxp = _v805_float(r.get('max_pct'), r.get('max_after_pct'), r.get('future_max_pct'), r.get('max_gain_pct'), default=0.0)
        old = dedup.get(t)
        if old is None or maxp > _v805_float(old.get('max_pct'), old.get('max_after_pct'), old.get('future_max_pct'), old.get('max_gain_pct'), default=0.0):
            dedup[t] = r
    return list(dedup.values())


def _v807_price_lag_quality_lines(limit: int = 5) -> List[str]:
    snap = _v650_candidate_snapshot()
    rows = [r for r in (snap.get('trade_rows') or []) if isinstance(r, dict)]
    current_counts: Counter = Counter(); current_samples: Dict[str, List[str]] = defaultdict(list)
    for r in rows:
        m = _v807_metrics_obj(r)
        b = _v807_quality_bucket_from_values(m['react'], m['buy'], m['sustain'], m['spread'], m['slippage'])
        current_counts[b] += 1
        if len(current_samples[b]) < limit and b in ('체결선행 가격대기', '체결착시 위험', '가격체결 동시강함', '실행비용 부담'):
            current_samples[b].append(f"{_v650_ticker(r)}({_v650_stage(r)} 반응 {m['react']:+.2f} 체결 {m['buy']:.2f} 지속 {m['sustain']:.2f} 스프 {m['spread']:.2f})")

    missed_counts: Counter = Counter(); missed_samples: Dict[str, List[str]] = defaultdict(list)
    for r in _v807_missed_rows():
        maxp = _v805_float(r.get('max_pct'), r.get('max_after_pct'), r.get('future_max_pct'), r.get('max_gain_pct'), default=0.0)
        if maxp < 0.40:
            continue
        t = str(r.get('ticker') or r.get('market') or '-').upper()
        stage = str(r.get('initial_stage') or r.get('stage') or r.get('grade') or '-')
        react = _v805_float(r.get('price_reaction_pct'), r.get('reaction_pct'), r.get('change_1m_pct'), r.get('price_chg_60s'), default=0.0)
        buy = _v805_float(r.get('buy_ratio'), r.get('buy'), default=0.0)
        sus = _v805_float(r.get('buy_sustain_1m'), r.get('sustain'), r.get('buy_sustain'), default=0.0)
        spread = _v805_float(r.get('spread_pct'), r.get('spread'), default=0.0)
        slip = _v805_float(r.get('slippage_pct'), r.get('slippage'), default=spread)
        bucket = _v807_quality_bucket_from_values(react, buy, sus, spread, slip, future_max=maxp)
        missed_counts[bucket] += 1
        if len(missed_samples[bucket]) < limit and bucket in ('가격후행 성공', '체결착시 확인', '강한확인값 착시', '거래불가 상승/품질제외', '상승했지만 품질불명'):
            missed_samples[bucket].append(f"{t} {stage} max {maxp:+.2f}% / 반응 {react:+.2f} 체결 {buy:.2f} 지속 {sus:.2f} 스프 {spread:.2f} 미끄 {slip:.2f}")

    # closed trades: verify whether high confirmation actually followed through.
    since_ts = _v798_batch_marker_ts() if '_v798_batch_marker_ts' in globals() else 0.0
    closed_counts: Counter = Counter(); closed_samples: Dict[str, List[str]] = defaultdict(list)
    for ev in _v798_trade_cache_events() if '_v798_trade_cache_events' in globals() else []:
        if not isinstance(ev, dict) or str(ev.get('kind')) != 'closed':
            continue
        ts = _v650_num(ev.get('ts'), default=0.0)
        if since_ts and ts <= since_ts:
            continue
        t = str(ev.get('ticker') or '-')
        pnl = _v650_num(ev.get('pnl_pct'), default=0.0)
        peak = _v650_num(ev.get('peak_pct'), default=0.0)
        chk = ev.get('entry_checks_v800') if isinstance(ev.get('entry_checks_v800'), dict) else {}
        react = _v650_num(chk.get('price_reaction_pct'), default=0.0)
        buy = _v650_num(chk.get('buy_ratio'), default=0.0)
        sus = _v650_num(chk.get('buy_sustain_1m'), default=0.0)
        if buy >= 0.70 and sus >= 0.70 and react >= 0.30 and peak <= 0.15 and pnl < 0:
            closed_counts['강한확인값 후속실패'] += 1
            if len(closed_samples['강한확인값 후속실패']) < limit:
                closed_samples['강한확인값 후속실패'].append(f"{t} 반응 {react:+.2f} 체결 {buy:.2f} 지속 {sus:.2f} / 최고 {peak:+.2f} → {pnl:+.2f}%")
        elif buy >= 0.70 and sus >= 0.70 and peak > 0.15 and pnl < 0:
            closed_counts['초반약상승 후 꺾임'] += 1
            if len(closed_samples['초반약상승 후 꺾임']) < limit:
                closed_samples['초반약상승 후 꺾임'].append(f"{t} 최고 {peak:+.2f} → {pnl:+.2f}% / 반응 {react:+.2f}")

    lines = ['[가격반응 지연·체결착시 품질판]']
    lines.append('- 현재 후보 품질: ' + (_v799_counter_line(current_counts, 8) if current_counts else '후보 없음'))
    lines.append('- 놓친 상승 품질: ' + (_v799_counter_line(missed_counts, 8) if missed_counts else 'missed 없음'))
    lines.append('- 산 후보 후속검증: ' + (_v799_counter_line(closed_counts, 6) if closed_counts else '새 CLOSED 후속검증 없음'))
    for title, bag in (('가격후행 성공', missed_samples), ('체결착시 확인', missed_samples), ('거래불가 상승/품질제외', missed_samples), ('체결선행 가격대기', current_samples), ('체결착시 위험', current_samples), ('강한확인값 후속실패', closed_samples), ('초반약상승 후 꺾임', closed_samples)):
        if bag.get(title):
            lines.append(f'- {title}: ' + ' / '.join(bag[title][:3]))
    lines.append('- 판독: 가격반응을 무조건 기다릴지, 체결선행을 일부 살릴지, 체결착시를 막을지 보는 품질판')
    return lines


def _v807_integrated_validation_lines(since_ts: float = 0.0, until_ts: float = 0.0, compact: bool = True) -> List[str]:
    lines: List[str] = []
    lines += _v806_trade_validation_lines(since_ts, until_ts, 4 if compact else 8)
    lines += _v806_missed_validation_lines(4 if compact else 8)
    lines += _v807_price_lag_quality_lines(4 if compact else 8)
    lines += _v806_common_scalp_validation_lines(4 if compact else 8)
    lines += _v806_structure_validation_lines(4 if compact else 8)
    lines += _v806_freshness_validation_lines(4 if compact else 8)
    lines.append('- 다음 판단: 가격후행 성공은 살릴 후보, 체결착시/후속실패는 차단 후보, 거래불가 상승은 버릴 후보')
    return lines


def _v807_batch_text() -> str:
    score=_v650_score(); review=_v650_review(); stop=_v681_stop_review_summary() if '_v681_stop_review_summary' in globals() else {}
    since_ts = _v798_batch_marker_ts() if '_v798_batch_marker_ts' in globals() else 0.0
    until_ts = now_ts()
    lines=['📦 코인봇 전체 요약 /batch']
    lines += _v799_section('① 성과') + _v651_score_window_lines() + [f"- score/review 오늘: {score.get('today_closed_count','-')} / {review.get('today_closed_count','-')}"]
    lines += _v799_section('② 후보 현황') + _v799_candidate_brief_lines() + _v799_pipeline_brief_lines()
    snap=_v650_candidate_snapshot()
    lines += _v799_section('③ S1 못 간 이유') + ['- ' + _v799_counter_line(snap.get('reasons'), 6), '- 위험/주의: ' + _v799_counter_line(snap.get('risks'), 5)]
    lines += _v799_section('④ 구조계획') + _v799_plan_lines(4)
    lines += _v799_section('⑤ S1 hold → paper 소비') + _v743_s1_hold_lines() + _v799_paper_hold_trace_lines()
    lines += _v799_section('⑥ 이전 요약 이후 매매') + ['- 상세 매매 복기표는 이 요약 txt 하단 [이전 요약 이후 매매 상세]에 1회만 표시']
    lines += _v799_section('⑦ 통합 검증판') + _v807_integrated_validation_lines(since_ts, until_ts, compact=True)
    lines += _v799_section('⑧ 아까운 후보 / 놓친 후보') + _v805_missed_summary_lines(5)
    lines += _v799_section('⑨ 자원/정리') + _v650_resource_lines() + [f"- 손절초과: 최근 trace {stop.get('n',0)}건 / loop gap 의심 {stop.get('loop_gap_suspect',0)}건", '- 요약 txt는 전송 후 서버 임시파일 삭제']
    lines += ['', '더 보기: /candidate_reason /gate_check /paper_handoff /pstatus /errorlog /missed_candidates /validation_board /quality_board']
    return '\n'.join(lines)


def _v807_validation_board_text() -> str:
    since_ts = _v798_batch_marker_ts() if '_v798_batch_marker_ts' in globals() else 0.0
    lines = ['🧪 통합 검증판 /validation_board · v807', '- 기준: candidate snapshot + paper trade detail cache + review_worker missed cache. main 재계산/조건변경 없음.']
    lines += _v807_integrated_validation_lines(since_ts, now_ts(), compact=False)
    return '\n'.join(lines)


def _v807_quality_board_text() -> str:
    lines = ['🧪 가격반응 지연·체결착시 품질판 /quality_board · v807', '- 기준: 현재 후보 canonical row + missed review cache + paper trade detail cache. 조건변경 없음.']
    lines += _v807_price_lag_quality_lines(10)
    return '\n'.join(lines)


def _v807_menu_text() -> str:
    return '\n'.join(['🧭 코인봇 메뉴 /menu', '', '자주 보는 명령어', '- /batch: 전체 요약 + 통합 검증판 + 품질판 + 매매상세', '- /validation_board: 산 후보/안 산 후보/공통초입/구조/freshness 검증', '- /quality_board: 가격후행 성공 vs 체결착시 품질판', '- /missed_candidates: 놓친 후보/아까운 상승 상세', '- /health: worker/cache/자원/정리 상태', '- /candidate_reason: S1 못 간 이유와 구조계획', '- /gate_check: S1 최종심사와 paper 소비 확인', '- /pstatus: 페이퍼 OPEN/CLOSED/hold 소비', '- /errorlog: 새 오류 확인', '', '표시 기준', '- 가격후행 성공=체결/지속이 먼저 좋았고 이후 가격이 따라온 후보', '- 체결착시=체결/지속은 좋아 보였지만 가격이 못 따라오거나 진입 후 후속실패'])


def _v650_batch_summary_text(cmds: List[str], outputs: Dict[str,str], timings: List[Dict[str,Any]], recv_delay: float, total_sec: float) -> str:  # type: ignore[override]
    global _V797_PENDING_BATCH_MARKER_TS
    batch_until = now_ts(); _V797_PENDING_BATCH_MARKER_TS = batch_until
    since_ts = _v798_batch_marker_ts() if '_v798_batch_marker_ts' in globals() else 0.0
    lines=['코인봇 묶음 요약집 v807', f'- 생성: {_v800_kst_text(batch_until)}', f'- 메인봇: {BOT_VERSION} / {V650_BUILD_LABEL}', f'- 접수지연: {recv_delay:.2f}s / 처리합계: {total_sec:.2f}s', '', '[명령 처리시간]']
    for t in timings:
        lines.append(f"- {'✅' if not t.get('error') else '❌'} /{t.get('name','?')}: {float(t.get('sec') or 0):.2f}s / {'OK' if not t.get('error') else 'ERR'}")
    lines += ['', '[전체 요약]', _v650_safe_body(outputs.get('batch') or _v807_batch_text(), 6500), '']
    lines += _v799_trade_detail_lines_range(since_ts, batch_until)
    lines += ['', '[통합 검증판 상세]'] + _v807_integrated_validation_lines(since_ts, batch_until, compact=False)
    lines += ['', '[가격반응 지연·체결착시 품질판 상세]'] + _v807_price_lag_quality_lines(10) + _v810_quality_route_lines()
    lines += ['', '[OPEN직전 보류 사후검증]'] + _v810_preopen_review_lines(10)
    lines += ['', '[아까운 후보 / 놓친 후보 상세]'] + _v805_missed_summary_lines(10)
    lines += ['', '[명령별 상세]']
    for name in cmds:
        lines += ['', f'/{name}', _v650_safe_body(outputs.get(name,''), 1700)]
    return '\n'.join(lines)


COMMANDS['batch'] = _v807_batch_text
COMMANDS['summary'] = _v807_batch_text
COMMANDS['pbatch'] = _v807_batch_text
COMMANDS['validation_board'] = _v807_validation_board_text
COMMANDS['validate'] = _v807_validation_board_text
COMMANDS['quality_board'] = _v807_quality_board_text
COMMANDS['quality'] = _v807_quality_board_text
COMMANDS['menu'] = _v807_menu_text
COMMANDS['help'] = _v807_menu_text


# =============================================================================
# main_bot v2.13.808: short chat summary + full txt detail separation
# - Purpose: Telegram chat shows only key judgement; batch summary txt keeps full detailed logs.
# - main remains a cache/status reader. No condition/ledger/auto-buy changes.
# =============================================================================
V650_BUILD_LABEL = 'v808_short_chat_full_txt_2026-06-10'
BOT_VERSION = '수익형 v2.13.808'
MAIN_BOT_VERSION = BOT_VERSION
EXPECTED_PAPER_VERSION = 'paper_bot_v0.795'


def _v808_score_short_lines() -> List[str]:
    raw = _v651_score_window_lines() if '_v651_score_window_lines' in globals() else []
    keep: List[str] = []
    for line in raw:
        s = str(line)
        if '최근 3시간' in s or '최근 6시간' in s or '최근 24시간' in s:
            keep.append(s)
    return keep or [str(x) for x in raw[:3]] or ['- 성과 cache 없음']


def _v808_candidate_short_lines() -> List[str]:
    out: List[str] = []
    try:
        for line in _v799_candidate_brief_lines():
            s = str(line)
            if '실전후보' in s or '판독:' in s:
                out.append(s)
        if not out:
            snap = _v650_candidate_snapshot()
            out.append(f"- 실전후보: S1 {snap.get('s1',0)} / S2 {snap.get('s2',0)} / S3 {snap.get('s3',0)}")
    except Exception as exc:
        log_error('v808_candidate_short', exc)
        out.append('- 후보 요약 읽기 실패')
    return out[:3]


def _v808_quality_short_lines() -> List[str]:
    try:
        raw = _v807_price_lag_quality_lines(3) if '_v807_price_lag_quality_lines' in globals() else []
    except Exception as exc:
        log_error('v808_quality_short', exc)
        raw = []
    keep: List[str] = []
    for line in raw:
        s = str(line)
        if s.startswith('- 현재 후보 품질:') or s.startswith('- 놓친 상승 품질:') or s.startswith('- 산 후보 후속검증:'):
            keep.append(s)
    return keep or ['- 품질판 cache 없음']


def _v808_recent_trade_short_lines(since_ts: float = 0.0) -> List[str]:
    try:
        events = _v798_trade_cache_events() if '_v798_trade_cache_events' in globals() else []
    except Exception as exc:
        log_error('v808_trade_short_events', exc)
        events = []
    closed: List[Dict[str, Any]] = []
    opens = 0
    for ev in events:
        if not isinstance(ev, dict):
            continue
        ts = _v650_num(ev.get('ts'), default=0.0)
        if since_ts and ts <= since_ts:
            continue
        kind = str(ev.get('kind') or '')
        if kind == 'open':
            opens += 1
        elif kind == 'closed':
            closed.append(ev)
    if not closed and not opens:
        return ['- 이전 요약 이후 새 OPEN/CLOSED 없음']
    pnl_sum = sum(_v650_num(x.get('pnl_pct'), default=0.0) for x in closed)
    wins = sum(1 for x in closed if _v650_num(x.get('pnl_pct'), default=0.0) > 0)
    losses = len(closed) - wins
    lines = [f"- 이벤트: OPEN {opens} / CLOSED {len(closed)} / {wins}승 {losses}패 / 합산 {pnl_sum:+.2f}%"]
    if closed:
        best = max(closed, key=lambda x: _v650_num(x.get('pnl_pct'), default=0.0))
        worst = min(closed, key=lambda x: _v650_num(x.get('pnl_pct'), default=0.0))
        bt = str(best.get('ticker') or '-')
        wt = str(worst.get('ticker') or '-')
        bp = _v650_num(best.get('pnl_pct'), default=0.0)
        wp = _v650_num(worst.get('pnl_pct'), default=0.0)
        bq = _v805_short(best.get('quality_verdict') or best.get('result') or best.get('close_reason'), 18) if '_v805_short' in globals() else ''
        wq = _v805_short(worst.get('quality_verdict') or worst.get('result') or worst.get('close_reason'), 18) if '_v805_short' in globals() else ''
        lines.append(f"- 좋았던/최악: {bt} {bp:+.2f}% {bq} / {wt} {wp:+.2f}% {wq}")
    return lines


def _v808_missed_short_lines() -> List[str]:
    path = BASE_DIR / 'clean_market_miss_review_v667.json'
    try:
        obj = _v650_load(path, {}) or {}
    except Exception as exc:
        log_error('v808_missed_short_load', exc)
        obj = {}
    if not isinstance(obj, dict) or not obj:
        return ['- missed cache 없음']
    buckets = obj.get('miss_bucket_counts') if isinstance(obj.get('miss_bucket_counts'), dict) else {}
    bucket_line = ' / '.join(f"{_v805_miss_label(k)} {v}" for k, v in Counter(buckets or {}).most_common(3)) if buckets else '없음'
    true_rows = obj.get('true_missed_top') if isinstance(obj.get('true_missed_top'), list) else []
    top_txt = '없음'
    if true_rows:
        r = next((x for x in true_rows if isinstance(x, dict)), None)
        if r:
            t = str(r.get('ticker') or r.get('market') or '-').upper()
            maxp = _v805_float(r.get('max_pct'), r.get('max_after_pct'), r.get('future_max_pct'), r.get('max_gain_pct'), default=0.0)
            bucket = _v805_miss_label(r.get('miss_bucket') or r.get('bucket') or r.get('reason'))
            top_txt = f"{t} {maxp:+.2f}% / {bucket}"
    return [
        f"- 상승후보 {obj.get('rise_count',0)} / 진짜 아까움 {obj.get('true_missed_count',0)}",
        f"- 놓친 이유 TOP: {bucket_line}",
        f"- 대표 놓침: {top_txt}",
    ]


def _v808_next_action_lines() -> List[str]:
    return [
        '- 가격후행 성공 후보는 S2 상위 재확인 후보로 검토',
        '- 체결착시 위험은 S1 보류/차단 후보로 검토',
        '- 상세 후보명·샘플·명령별 원문은 첨부 txt에서 확인',
    ]


def _v808_batch_text() -> str:
    since_ts = _v798_batch_marker_ts() if '_v798_batch_marker_ts' in globals() else 0.0
    lines = ['📦 코인봇 핵심요약 /batch · v808']
    lines += _v799_section('① 성과') + _v808_score_short_lines()
    lines += _v799_section('② 현재 후보') + _v808_candidate_short_lines()
    lines += _v799_section('③ 품질판 핵심') + _v808_quality_short_lines()
    lines += _v799_section('④ 최근 매매') + _v808_recent_trade_short_lines(since_ts)
    lines += _v799_section('⑤ 놓친 후보') + _v808_missed_short_lines()
    lines += _v799_section('⑥ 다음 판단') + _v808_next_action_lines()
    lines += ['', '📎 전체 상세는 묶음 요약 txt에 보존됨']
    return '\n'.join(lines)


def _v808_validation_board_text() -> str:
    since_ts = _v798_batch_marker_ts() if '_v798_batch_marker_ts' in globals() else 0.0
    lines = ['🧪 통합 검증판 /validation_board · v808', '- 기준: candidate snapshot + paper trade detail cache + review_worker missed cache. main 재계산/조건변경 없음.']
    lines += _v807_integrated_validation_lines(since_ts, now_ts(), compact=False)
    return '\n'.join(lines)


def _v808_quality_board_text() -> str:
    lines = ['📊 가격반응 지연·체결착시 품질판 /quality_board · v811', '- 기준: 현재 후보 canonical row + missed review cache + paper trade detail cache + quality route tags. 조건변경 없음.']
    lines += _v807_price_lag_quality_lines(10)
    lines += [''] + _v810_quality_route_lines()
    lines += [''] + _v810_preopen_review_lines(6)
    return '\n'.join(lines)


def _v808_menu_text() -> str:
    return '\n'.join([
        '🧭 코인봇 메뉴 /menu · v808', '',
        '평소 확인',
        '- /batch: 채팅은 핵심요약만, 상세는 txt 첨부',
        '- /quality_board: 가격후행 성공 vs 체결착시 + 판단연결 태그',
        '- /preopen_review: OPEN직전 보류 사후검증',
        '- /validation_board: 산 후보/안 산 후보/구조/freshness 검증',
        '- /missed_candidates: 놓친 후보 상세',
        '- /health /candidate_reason /gate_check /pstatus /errorlog', '',
        '원칙',
        '- 채팅 출력은 짧게',
        '- 요약 txt에는 전체 상세 보존',
        '- main_bot은 snapshot/cache 표시만 수행',
    ])


def _v650_batch_summary_text(cmds: List[str], outputs: Dict[str,str], timings: List[Dict[str,Any]], recv_delay: float, total_sec: float) -> str:  # type: ignore[override]
    global _V797_PENDING_BATCH_MARKER_TS
    batch_until = now_ts(); _V797_PENDING_BATCH_MARKER_TS = batch_until
    since_ts = _v798_batch_marker_ts() if '_v798_batch_marker_ts' in globals() else 0.0
    lines=['코인봇 묶음 요약집 v808', f'- 생성: {_v800_kst_text(batch_until)}', f'- 메인봇: {BOT_VERSION} / {V650_BUILD_LABEL}', f'- 접수지연: {recv_delay:.2f}s / 처리합계: {total_sec:.2f}s', '', '[명령 처리시간]']
    for t in timings:
        lines.append(f"- {'✅' if not t.get('error') else '❌'} /{t.get('name','?')}: {float(t.get('sec') or 0):.2f}s / {'OK' if not t.get('error') else 'ERR'}")
    # Chat is short, but the txt keeps the full detailed batch body from v807.
    lines += ['', '[채팅 핵심 요약]', _v650_safe_body(_v808_batch_text(), 2200), '']
    lines += ['', '[전체 상세 요약]', _v650_safe_body(_v807_batch_text(), 9000), '']
    lines += _v799_trade_detail_lines_range(since_ts, batch_until)
    lines += ['', '[통합 검증판 상세]'] + _v807_integrated_validation_lines(since_ts, batch_until, compact=False)
    lines += ['', '[가격반응 지연·체결착시 품질판 상세]'] + _v807_price_lag_quality_lines(10) + _v810_quality_route_lines()
    lines += ['', '[OPEN직전 보류 사후검증]'] + _v810_preopen_review_lines(10)
    lines += ['', '[아까운 후보 / 놓친 후보 상세]'] + _v805_missed_summary_lines(10)
    lines += ['', '[명령별 상세]']
    for name in cmds:
        lines += ['', f'/{name}', _v650_safe_body(outputs.get(name,''), 2200)]
    return '\n'.join(lines)


def batch_handler(update, context):  # type: ignore[override]
    """v808: run full checks for txt, but send only compact chat summary."""
    try:
        msg_date=getattr(getattr(update,'message',None),'date',None)
        recv_delay=time.time()-msg_date.timestamp() if hasattr(msg_date,'timestamp') else 0.0
    except Exception:
        recv_delay=0.0
    default_cmds=['batch','validation_board','quality_board','missed_candidates','candidate_reason','gate_check','paper_handoff','pstatus','health','errorlog']
    raw_args = getattr(context,'args',None) or []
    cmds=[str(x).strip().lstrip('/') for x in (raw_args or default_cmds)[:10] if str(x).strip()]
    stime=time.time(); timings=[]; outputs={}
    try:
        send(update, f'📦 묶음 확인 시작\n- 채팅은 핵심만 표시\n- 전체 상세는 txt 첨부\n- 접수지연 {recv_delay:.2f}s')
    except Exception:
        pass
    for name in cmds:
        fn=COMMANDS.get(name); t0=time.time(); err=None
        if not fn:
            body=f'❌ /{name} 연결 없음'; err='no_handler'
        else:
            try:
                body=fn()
            except Exception as exc:
                body=f'❌ /{name} 오류 {exc.__class__.__name__}: {exc}'; err=f'{exc.__class__.__name__}: {exc}'; log_error(f'v808_batch_{name}', exc)
        sec=time.time()-t0; outputs[name]=body; timings.append({'name':name,'sec':sec,'error':err})
    total=time.time()-stime
    try:
        send(update, _v808_batch_text())
    except Exception as exc:
        log_error('v808_batch_short_send', exc)
    try:
        status=_v650_send_summary_file(update, _v650_batch_summary_text(cmds, outputs, timings, recv_delay, total))
    except Exception as exc:
        status=f'txt 생성실패 {exc.__class__.__name__}'; log_error('v808_batch_summary_file', exc)
    mark='✅' if '전송완료' in status else '⚠️'; del_mark='✅' if '서버삭제' in status else ('❌' if '전송완료' in status else '❔')
    try:
        send(update, f'📎 묶음 요약집\n- 전송: {mark} {status}\n- 임시파일 삭제: {del_mark}\n- 처리합계: {total:.2f}s')
    except Exception:
        pass


COMMANDS['batch'] = _v808_batch_text
COMMANDS['summary'] = _v808_batch_text
COMMANDS['pbatch'] = _v808_batch_text
COMMANDS['batch_full'] = _v807_batch_text
COMMANDS['validation_board'] = _v808_validation_board_text
COMMANDS['validate'] = _v808_validation_board_text
COMMANDS['quality_board'] = _v808_quality_board_text
COMMANDS['quality'] = _v808_quality_board_text
COMMANDS['menu'] = _v808_menu_text
COMMANDS['help'] = _v808_menu_text


# main_bot v2.13.810: quality route + preopen review summary + calmer chat output
# - Purpose: Telegram chat shows actionable operator summary with worker/cache/resource/error status.
# - Detailed candidate/quality/validation logs remain in the attached txt summary.
V650_BUILD_LABEL = 'structure_board_mainline_2026-06-10'
BOT_VERSION = '수익형 v2.13.812'
MAIN_BOT_VERSION = BOT_VERSION
EXPECTED_PAPER_VERSION = 'paper_bot_v0.795'


def _v809_first_matching(lines: List[str], needles: Tuple[str, ...], default: str = '-') -> str:
    for ln in lines or []:
        s = str(ln)
        if any(n in s for n in needles):
            return s
    return default


def _v809_apply_short_lines() -> List[str]:
    st = _v650_status()
    paper_ver = st.get('version','-')
    paper_build = st.get('build','-')
    open_n = _v650_open_count()
    return [
        f"- 🧠 main: {BOT_VERSION}",
        f"- 🧪 paper: {paper_ver} / OPEN {open_n}",
        f"- 🏷️ build: {V650_BUILD_LABEL}",
    ]


def _v809_worker_short_lines() -> List[str]:
    lines: List[str] = []
    try:
        lines.append('🟢 ' + _v650_worker_line().lstrip('- ').replace('worker:', 'worker 생존:'))
        # Keep TOP ages visible without dumping all 9 workers.
        age_lines = _v747_worker_age_lines(full=True) if '_v747_worker_age_lines' in globals() else []
        top=[]
        for ln in age_lines:
            s=str(ln).strip().lstrip('- ').replace('✅ ','').replace('⚠️ ','').replace('❌ ','')
            if ':' in s:
                top.append(s.split('/ state')[0].strip())
            if len(top) >= 3:
                break
        if top:
            lines.append('- ⏱️ 느린 worker TOP: ' + ' / '.join(top))
    except Exception as exc:
        log_error('v809_worker_short', exc)
        lines.append('- ⚠️ worker 요약 읽기 실패')
    return lines


def _v809_freshness_short_lines() -> List[str]:
    out: List[str] = []
    try:
        cand = _v783_candidate_unified_lines()[0] if '_v783_candidate_unified_lines' in globals() else ''
        if cand:
            # Condense but keep core counts + age.
            out.append('📦 ' + cand.lstrip('- '))
        base = _v787_recheck_freshness_base_lines() if '_v787_recheck_freshness_base_lines' in globals() else []
        if base:
            out.append('🔄 ' + str(base[0]).lstrip('- '))
            if len(base) > 1:
                out.append('📌 ' + str(base[1]).lstrip('- '))
    except Exception as exc:
        log_error('v809_freshness_short', exc)
        out.append('- ⚠️ freshness 요약 읽기 실패')
    return out[:4]


def _v809_resource_error_short_lines() -> List[str]:
    out: List[str] = []
    try:
        for ln in _v650_resource_lines():
            s = str(ln)
            if 'CPU:' in s:
                out.append('🖥️ ' + s)
            elif '디스크:' in s:
                out.append('💾 ' + s)
            elif '메모리:' in s:
                out.append('🧠 ' + s)
            else:
                out.append(s)
    except Exception as exc:
        log_error('v809_resource_short', exc)
        out.append('- ⚠️ 자원 요약 읽기 실패')
    try:
        err = _v650_errorlog_text()
        if '❌ 새 실행 이후 오류' in err:
            out.append('🚨 errorlog: 새 오류 있음')
        elif '✅ 새 실행 중 오류 없음' in err:
            out.append('✅ errorlog: 새 실행 중 오류 없음')
        else:
            out.append('⚠️ errorlog: 확인 필요')
    except Exception as exc:
        log_error('v809_error_short', exc)
        out.append('⚠️ errorlog: 읽기 실패')
    return out[:5]


def _v809_candidate_short_lines() -> List[str]:
    out: List[str] = []
    try:
        raw = _v799_candidate_brief_lines()
        for line in raw:
            s = str(line)
            if '실전후보' in s:
                out.append('🎯 ' + s.lstrip('- '))
            elif '판독:' in s:
                out.append('📌 ' + s.lstrip('- '))
        # Add 1m reaction because it explains why S1 is empty.
        one = _v809_first_matching(raw, ('1분 반응',), '')
        if one:
            out.append('⚡ ' + one.lstrip('- '))
    except Exception as exc:
        log_error('v809_candidate_short', exc)
        out.append('- ⚠️ 후보 요약 읽기 실패')
    return out[:4]




def _v810_quality_route_counts() -> Tuple[Counter, Dict[str, List[str]]]:
    counts: Counter = Counter(); samples: Dict[str, List[str]] = defaultdict(list)
    try:
        snap = _v650_candidate_snapshot()
        rows = [r for r in (snap.get('trade_rows') or []) if isinstance(r, dict)]
        for r in rows:
            q = r.get('quality_route_v810') if isinstance(r.get('quality_route_v810'), dict) else {}
            action = str(r.get('quality_bucket_v810') or q.get('action') or '')
            if not action:
                if r.get('quality_recheck_s2_v810'):
                    action = 'quality_recheck_s2'
                elif r.get('flow_trap_watch_v810'):
                    action = 'flow_trap_watch'
            if not action:
                continue
            counts[action] += 1
            if action in {'quality_recheck_s2','flow_trap_watch'} and len(samples[action]) < 4:
                m = q.get('metrics') if isinstance(q.get('metrics'), dict) else _v807_metrics_obj(r)
                samples[action].append(f"{_v650_ticker(r)}({_v650_stage(r)} 반응 {_v650_num(m.get('react'), default=0.0):+.2f} 체결 {_v650_num(m.get('buy'), default=0.0):.2f} 지속 {_v650_num(m.get('sustain'), default=0.0):.2f})")
    except Exception as exc:
        log_error('v810_quality_route_counts', exc)
    return counts, samples


def _v810_preopen_review_obj() -> Dict[str, Any]:
    try:
        return _v650_load(BASE_DIR / 'paper_preopen_miss_review_cache.json', {}) or {}
    except Exception as exc:
        log_error('v810_preopen_review_load', exc)
        return {}


def _v810_preopen_review_lines(limit: int = 4) -> List[str]:
    obj = _v810_preopen_review_obj()
    if not isinstance(obj, dict) or not obj:
        return ['- OPEN직전 보류검증: cache 없음']
    kinds = obj.get('hold_kind_counts') if isinstance(obj.get('hold_kind_counts'), dict) else {}
    states = obj.get('review_state_counts') if isinstance(obj.get('review_state_counts'), dict) else {}
    rows = obj.get('top_missed_after_hold') if isinstance(obj.get('top_missed_after_hold'), list) else []
    lines = [
        f"- OPEN직전 보류검증: rows {obj.get('row_count',0)} / 막은뒤상승 {obj.get('missed_after_hold_count',0)} / 잘막음 {obj.get('held_correct_so_far_count',0)}",
        '- 보류사유 TOP: ' + (_v799_counter_line(Counter(kinds), 5) if kinds else '없음'),
        '- 검증상태 TOP: ' + (_v799_counter_line(Counter(states), 5) if states else '없음'),
    ]
    sample=[]
    for r in rows[:limit]:
        if not isinstance(r, dict):
            continue
        sample.append(f"{str(r.get('ticker') or '-')} {str(r.get('hold_kind') or '-')} max {_v650_num(r.get('max_after_pct'), default=0.0):+.2f}%")
    if sample:
        lines.append('- 막은 뒤 간 후보: ' + ' / '.join(sample))
    return lines


def _v810_quality_route_lines() -> List[str]:
    counts, samples = _v810_quality_route_counts()
    lines=[]
    if counts:
        lines.append('- 판단연결 태그: ' + _v799_counter_line(counts, 6))
    if samples.get('quality_recheck_s2'):
        lines.append('- quality_recheck_s2: ' + ' / '.join(samples['quality_recheck_s2'][:3]))
    if samples.get('flow_trap_watch'):
        lines.append('- flow_trap_watch: ' + ' / '.join(samples['flow_trap_watch'][:3]))
    return lines or ['- 판단연결 태그: 아직 없음']


def _v810_preopen_review_text() -> str:
    return '\n'.join(['📊 OPEN직전 보류 사후검증 /preopen_review · v811', '- 기준: paper_bot이 봉인한 preopen miss review cache. main 재계산 없음.'] + _v810_preopen_review_lines(8))

def _v809_quality_short_lines() -> List[str]:
    try:
        raw = _v807_price_lag_quality_lines(3) if '_v807_price_lag_quality_lines' in globals() else []
    except Exception as exc:
        log_error('v810_quality_short', exc)
        raw = []
    keep=[]
    for line in raw:
        s = str(line)
        if s.startswith('- 현재 후보 품질:'):
            keep.append(s)
        elif s.startswith('- 놓친 상승 품질:'):
            keep.append(s)
        elif s.startswith('- 산 후보 후속검증:'):
            keep.append(s)
        elif s.startswith('- 가격후행 성공:') and len(keep) < 4:
            keep.append(s)
        elif s.startswith('- 체결착시 위험:') and len(keep) < 5:
            keep.append(s)
    keep += _v810_quality_route_lines()[:3]
    return keep or ['- 품질판 cache 없음']


def _v809_recent_trade_short_lines(since_ts: float = 0.0) -> List[str]:
    lines = _v808_recent_trade_short_lines(since_ts) if '_v808_recent_trade_short_lines' in globals() else []
    out=[]
    for x in lines:
        s=str(x)
        if '새 OPEN/CLOSED 없음' in s:
            out.append('➖ ' + s.lstrip('- '))
        elif '이벤트:' in s:
            out.append('📊 ' + s.lstrip('- '))
        elif '좋았던/최악' in s:
            out.append('🏁 ' + s.lstrip('- '))
        else:
            out.append(s)
    return out or ['- 최근 매매 cache 없음']


def _v809_missed_short_lines() -> List[str]:
    raw = _v808_missed_short_lines() if '_v808_missed_short_lines' in globals() else []
    out=[]
    for s in raw:
        t=str(s)
        if '상승후보' in t:
            out.append('📈 ' + t.lstrip('- '))
        elif '놓친 이유' in t:
            out.append('🧭 ' + t.lstrip('- '))
        elif '대표 놓침' in t:
            out.append('🎯 ' + t.lstrip('- '))
        else:
            out.append(t)
    return out or ['- missed cache 없음']


def _v809_next_action_lines() -> List[str]:
    return [
        '- 1순위: paper_preopen_miss_review로 OPEN직전 보류가 잘 막은 건지 확인',
        '- 2순위: quality_recheck_s2는 target_router 상위 재확인으로 소비',
        '- 3순위: flow_trap_watch는 S1 OPEN직전 보류근거로 확인',
        '- 전체 상세는 첨부 txt에서 확인',
    ]


def _v809_batch_text() -> str:
    since_ts = _v798_batch_marker_ts() if '_v798_batch_marker_ts' in globals() else 0.0
    lines = ['📊 코인봇 운영 핵심요약 /batch · v811']
    lines += _v799_section('① 적용/생존') + _v809_apply_short_lines() + _v809_worker_short_lines()
    lines += _v799_section('② 성과') + _v808_score_short_lines()
    lines += _v799_section('③ 현재 후보') + _v809_candidate_short_lines()
    lines += _v799_section('④ 정보 freshness') + _v809_freshness_short_lines()
    lines += _v799_section('⑤ 품질판') + _v809_quality_short_lines()
    lines += _v799_section('⑥ OPEN직전 보류검증') + _v810_preopen_review_lines(3)
    lines += _v799_section('⑦ 최근 매매') + _v809_recent_trade_short_lines(since_ts)
    lines += _v799_section('⑧ 놓친 후보') + _v809_missed_short_lines()
    lines += _v799_section('⑨ 자원/오류') + _v809_resource_error_short_lines()
    lines += _v799_section('⑩ 다음 판단') + _v809_next_action_lines()
    lines += ['', '📎 전체 상세는 묶음 요약 txt에 보존됨']
    return '\n'.join(lines)


def _v809_menu_text() -> str:
    return '\n'.join([
        '🧭 코인봇 메뉴 /menu · v811', '',
        '📌 평소 확인',
        '- /batch: 운영 핵심요약 + 상세 txt 첨부',
        '- /quality_board: 가격후행 성공 vs 체결착시 + 판단연결 태그',
        '- /preopen_review: OPEN직전 보류 사후검증',
        '- /validation_board: 산 후보/안 산 후보/구조/freshness 검증',
        '- /missed_candidates: 놓친 후보 상세',
        '- /health /candidate_reason /gate_check /pstatus /errorlog', '',
        '📌 원칙',
        '- 채팅에는 운영 필수정보만',
        '- txt에는 전체 상세 보존',
        '- main_bot은 snapshot/cache 표시만 수행',
    ])


def _v650_batch_summary_text(cmds: List[str], outputs: Dict[str,str], timings: List[Dict[str,Any]], recv_delay: float, total_sec: float) -> str:  # type: ignore[override]
    global _V797_PENDING_BATCH_MARKER_TS
    batch_until = now_ts(); _V797_PENDING_BATCH_MARKER_TS = batch_until
    since_ts = _v798_batch_marker_ts() if '_v798_batch_marker_ts' in globals() else 0.0
    lines=['코인봇 묶음 요약집 v811', f'- 생성: {_v800_kst_text(batch_until)}', f'- 메인봇: {BOT_VERSION} / {V650_BUILD_LABEL}', f'- 접수지연: {recv_delay:.2f}s / 처리합계: {total_sec:.2f}s', '', '[명령 처리시간]']
    for t in timings:
        lines.append(f"- {'✅' if not t.get('error') else '❌'} /{t.get('name','?')}: {float(t.get('sec') or 0):.2f}s / {'OK' if not t.get('error') else 'ERR'}")
    lines += ['', '[채팅 운영 핵심 요약]', _v650_safe_body(_v809_batch_text(), 3200), '']
    lines += ['', '[전체 상세 요약]', _v650_safe_body(_v807_batch_text(), 9000), '']
    lines += _v799_trade_detail_lines_range(since_ts, batch_until)
    lines += ['', '[통합 검증판 상세]'] + _v807_integrated_validation_lines(since_ts, batch_until, compact=False)
    lines += ['', '[가격반응 지연·체결착시 품질판 상세]'] + _v807_price_lag_quality_lines(10)
    lines += ['', '[아까운 후보 / 놓친 후보 상세]'] + _v805_missed_summary_lines(10)
    lines += ['', '[명령별 상세]']
    for name in cmds:
        lines += ['', f'/{name}', _v650_safe_body(outputs.get(name,''), 2200)]
    return '\n'.join(lines)


def batch_handler(update, context):  # type: ignore[override]
    """v810: chat shows operational summary; txt keeps full detailed logs."""
    try:
        msg_date=getattr(getattr(update,'message',None),'date',None)
        recv_delay=time.time()-msg_date.timestamp() if hasattr(msg_date,'timestamp') else 0.0
    except Exception:
        recv_delay=0.0
    default_cmds=['batch','health','validation_board','quality_board','preopen_review','missed_candidates','candidate_reason','gate_check','paper_handoff','pstatus','errorlog']
    raw_args = getattr(context,'args',None) or []
    cmds=[str(x).strip().lstrip('/') for x in (raw_args or default_cmds)[:10] if str(x).strip()]
    stime=time.time(); timings=[]; outputs={}
    try:
        send(update, f'📊 묶음 확인 시작\n- 채팅: 운영 핵심요약\n- txt: 전체 상세 보존\n- 접수지연 {recv_delay:.2f}s')
    except Exception:
        pass
    for name in cmds:
        fn=COMMANDS.get(name); t0=time.time(); err=None
        if not fn:
            body=f'❌ /{name} 연결 없음'; err='no_handler'
        else:
            try:
                body=fn()
            except Exception as exc:
                body=f'❌ /{name} 오류 {exc.__class__.__name__}: {exc}'; err=f'{exc.__class__.__name__}: {exc}'; log_error(f'v810_batch_{name}', exc)
        sec=time.time()-t0; outputs[name]=body; timings.append({'name':name,'sec':sec,'error':err})
    total=time.time()-stime
    try:
        send(update, _v809_batch_text())
    except Exception as exc:
        log_error('v809_batch_short_send', exc)
    try:
        status=_v650_send_summary_file(update, _v650_batch_summary_text(cmds, outputs, timings, recv_delay, total))
    except Exception as exc:
        status=f'txt 생성실패 {exc.__class__.__name__}'; log_error('v809_batch_summary_file', exc)
    mark='✅' if '전송완료' in status else '⚠️'; del_mark='✅' if '서버삭제' in status else ('❌' if '전송완료' in status else '❔')
    try:
        send(update, f'📎 묶음 요약집\n- 전송: {mark} {status}\n- 임시파일 삭제: {del_mark}\n- 처리합계: {total:.2f}s')
    except Exception:
        pass


COMMANDS['batch'] = _v809_batch_text
COMMANDS['summary'] = _v809_batch_text
COMMANDS['pbatch'] = _v809_batch_text
COMMANDS['batch_full'] = _v807_batch_text
COMMANDS['validation_board'] = _v808_validation_board_text
COMMANDS['validate'] = _v808_validation_board_text
COMMANDS['quality_board'] = _v808_quality_board_text
COMMANDS['quality'] = _v808_quality_board_text
COMMANDS['preopen_review'] = _v810_preopen_review_text
COMMANDS['preopen'] = _v810_preopen_review_text
COMMANDS['menu'] = _v809_menu_text
COMMANDS['help'] = _v809_menu_text


# =============================================================================
# main_bot v2.13.811: batch source lock + compact chat / detailed txt
# - batch chat is short; txt keeps full command/detail boards.
# - paper status/score are captured once per /batch to avoid mixed 24h/build lines.
# - main still reads cache/snapshot only; no CLOSED ledger scan or condition recalculation.
# =============================================================================
V650_BUILD_LABEL = 'structure_board_mainline_2026-06-10'
BOT_VERSION = '수익형 v2.13.812'
MAIN_BOT_VERSION = BOT_VERSION

_V811_BATCH_SOURCE_LOCK: Dict[str, Any] = {}


def _v811_begin_batch_source_lock() -> None:
    global _V811_BATCH_SOURCE_LOCK
    _V811_BATCH_SOURCE_LOCK = {
        'active': True,
        'captured_ts': now_ts(),
        'paper_status': _v650_load(FILES.get('paper_status', BASE_DIR/'paper_bot_status.json'), {}) or {},
        'paper_score': _v650_load(FILES.get('paper_score', BASE_DIR/'paper_bot_score_cache.json'), {}) or {},
    }


def _v811_end_batch_source_lock() -> None:
    global _V811_BATCH_SOURCE_LOCK
    _V811_BATCH_SOURCE_LOCK = {}


def _v650_score() -> Dict[str, Any]:  # type: ignore[override]
    if isinstance(_V811_BATCH_SOURCE_LOCK, dict) and _V811_BATCH_SOURCE_LOCK.get('active'):
        obj = _V811_BATCH_SOURCE_LOCK.get('paper_score')
        return obj if isinstance(obj, dict) else {}
    obj = _v650_load(FILES.get('paper_score', BASE_DIR/'paper_bot_score_cache.json'), {}) or {}
    return obj if isinstance(obj, dict) else {}


def _v650_status() -> Dict[str, Any]:  # type: ignore[override]
    if isinstance(_V811_BATCH_SOURCE_LOCK, dict) and _V811_BATCH_SOURCE_LOCK.get('active'):
        obj = _V811_BATCH_SOURCE_LOCK.get('paper_status')
        return obj if isinstance(obj, dict) else {}
    obj = _v650_load(FILES.get('paper_status', BASE_DIR/'paper_bot_status.json'), {}) or {}
    return obj if isinstance(obj, dict) else {}


_v811_prev_pick_score_stat = _v651_pick_score_stat if '_v651_pick_score_stat' in globals() else None

def _v651_pick_score_stat(score: Dict[str, Any], *keys: str) -> Dict[str, Any]:  # type: ignore[override]
    """Read only sealed paper score windows, including nested {'global': stat} forms."""
    if not isinstance(score, dict):
        return _v650_stat_obj({})
    for k in keys:
        v = score.get(k)
        if isinstance(v, dict):
            for subkey in ('global', 'stats', 'summary'):
                if isinstance(v.get(subkey), dict):
                    st = _v650_stat_obj(v.get(subkey))
                    if st.get('n') or any(x in v.get(subkey, {}) for x in ('total','sum','sum_pct','total_pct','avg','wins','losses')):
                        return st
            st = _v650_stat_obj(v)
            if st.get('n') or any(x in v for x in ('total','sum','sum_pct','total_pct','avg','wins','losses')):
                return st
    # Classify cache/performance board sometimes seals nested windows under performance_breakdown.
    perf = score.get('performance_breakdown') if isinstance(score.get('performance_breakdown'), dict) else {}
    for k in keys:
        v = perf.get(k)
        if isinstance(v, dict):
            st = _v650_stat_obj(v.get('global') if isinstance(v.get('global'), dict) else v)
            if st.get('n'):
                return st
    if callable(_v811_prev_pick_score_stat):
        return _v811_prev_pick_score_stat(score, *keys)
    return _v650_stat_obj({})


def _v811_score_short_lines() -> List[str]:
    raw = _v651_score_window_lines() if '_v651_score_window_lines' in globals() else []
    out=[]
    for line in raw:
        s=str(line)
        if '최근 3시간' in s or '최근 6시간' in s or '최근 24시간' in s or '24h:' in s:
            out.append(s)
    return out or ['- 성과 cache 없음']


def _v811_batch_text() -> str:
    since_ts = _v798_batch_marker_ts() if '_v798_batch_marker_ts' in globals() else 0.0
    lines = ['📊 코인봇 운영 핵심요약 /batch · v811']
    lines += _v799_section('① 적용/생존') + _v809_apply_short_lines() + _v809_worker_short_lines()
    lines += _v799_section('② 성과') + _v811_score_short_lines()
    lines += _v799_section('③ 현재 후보') + _v809_candidate_short_lines()
    lines += _v799_section('④ 정보 freshness') + _v809_freshness_short_lines()
    lines += _v799_section('⑤ 품질판') + _v809_quality_short_lines()
    lines += _v799_section('⑥ OPEN직전 보류검증') + _v810_preopen_review_lines(3)
    lines += _v799_section('⑦ 최근 매매') + _v809_recent_trade_short_lines(since_ts)
    lines += _v799_section('⑧ 놓친 후보') + _v809_missed_short_lines()
    lines += _v799_section('⑨ 자원/오류') + _v809_resource_error_short_lines()
    lines += _v799_section('⑩ 다음 판단') + [
        '- preopen writer/reader 단일화 결과 확인',
        '- quality_recheck_s2는 상위 재확인 소비 유지',
        '- 강한확인값 후속실패는 복기태그만 누적, 즉시 차단 금지',
        '- 전체 상세는 첨부 txt에서 확인',
    ]
    lines += ['', '📎 전체 상세는 묶음 요약 txt에 보존됨']
    return '\n'.join(lines)


def _v811_batch_summary_text(cmds: List[str], outputs: Dict[str,str], timings: List[Dict[str,Any]], recv_delay: float, total_sec: float, chat_body: str = '') -> str:
    global _V797_PENDING_BATCH_MARKER_TS
    batch_until = now_ts(); _V797_PENDING_BATCH_MARKER_TS = batch_until
    since_ts = _v798_batch_marker_ts() if '_v798_batch_marker_ts' in globals() else 0.0
    lines=['코인봇 묶음 요약집 v811', f'- 생성: {_v800_kst_text(batch_until)}', f'- 메인봇: {BOT_VERSION} / {V650_BUILD_LABEL}', f'- 접수지연: {recv_delay:.2f}s / 처리합계: {total_sec:.2f}s', '', '[명령 처리시간]']
    for t in timings:
        lines.append(f"- {'✅' if not t.get('error') else '❌'} /{t.get('name','?')}: {float(t.get('sec') or 0):.2f}s / {'OK' if not t.get('error') else 'ERR'}")
    lines += ['', '[채팅 운영 핵심 요약]', _v650_safe_body(chat_body or _v811_batch_text(), 3200), '']
    lines += ['', '[전체 상세 요약]', _v650_safe_body(_v807_batch_text(), 9000), '']
    lines += _v799_trade_detail_lines_range(since_ts, batch_until)
    lines += ['', '[통합 검증판 상세]'] + _v807_integrated_validation_lines(since_ts, batch_until, compact=False)
    lines += ['', '[가격반응 지연·체결착시 품질판 상세]'] + _v807_price_lag_quality_lines(10) + _v810_quality_route_lines()
    lines += ['', '[OPEN직전 보류 사후검증]'] + _v810_preopen_review_lines(10)
    lines += ['', '[아까운 후보 / 놓친 후보 상세]'] + _v805_missed_summary_lines(10)
    lines += ['', '[명령별 상세]']
    for name in cmds:
        lines += ['', f'/{name}', _v650_safe_body(outputs.get(name,''), 2200)]
    return '\n'.join(lines)


def batch_handler(update, context):  # type: ignore[override]
    """v811: chat stays compact; one locked source snapshot feeds all txt details."""
    try:
        msg_date=getattr(getattr(update,'message',None),'date',None)
        recv_delay=time.time()-msg_date.timestamp() if hasattr(msg_date,'timestamp') else 0.0
    except Exception:
        recv_delay=0.0
    default_cmds=['health','validation_board','quality_board','preopen_review','missed_candidates','candidate_reason','gate_check','paper_handoff','pstatus','errorlog']
    raw_args = getattr(context,'args',None) or []
    cmds=[str(x).strip().lstrip('/') for x in (raw_args or default_cmds)[:10] if str(x).strip()]
    stime=time.time(); timings=[]; outputs={}; chat_body=''
    _v811_begin_batch_source_lock()
    try:
        try:
            send(update, f'📊 묶음 확인 시작\n- 채팅: 운영 핵심요약\n- txt: 전체 상세 보존\n- 접수지연 {recv_delay:.2f}s')
        except Exception:
            pass
        for name in cmds:
            fn=COMMANDS.get(name); t0=time.time(); err=None
            if not fn:
                body=f'❌ /{name} 연결 없음'; err='no_handler'
            else:
                try:
                    body=fn()
                except Exception as exc:
                    body=f'❌ /{name} 오류 {exc.__class__.__name__}: {exc}'; err=f'{exc.__class__.__name__}: {exc}'; log_error(f'v811_batch_{name}', exc)
            sec=time.time()-t0; outputs[name]=body; timings.append({'name':name,'sec':sec,'error':err})
        total=time.time()-stime
        try:
            chat_body = _v811_batch_text()
            send(update, chat_body)
        except Exception as exc:
            log_error('v811_batch_short_send', exc)
        try:
            status=_v650_send_summary_file(update, _v811_batch_summary_text(cmds, outputs, timings, recv_delay, total, chat_body=chat_body))
        except Exception as exc:
            status=f'txt 생성실패 {exc.__class__.__name__}'; log_error('v811_batch_summary_file', exc)
        mark='✅' if '전송완료' in status else '⚠️'; del_mark='✅' if '서버삭제' in status else ('❌' if '전송완료' in status else '❔')
        try:
            send(update, f'📎 묶음 요약집\n- 전송: {mark} {status}\n- 임시파일 삭제: {del_mark}\n- 처리합계: {total:.2f}s')
        except Exception:
            pass
    finally:
        _v811_end_batch_source_lock()


def _v811_menu_text() -> str:
    return '\n'.join([
        '🧭 코인봇 메뉴 /menu · v811', '',
        '- /batch: 채팅 핵심요약 + txt 전체상세',
        '- /quality_board: 가격후행/체결착시/후속실패 품질판',
        '- /preopen_review: OPEN직전 보류 사후검증',
        '- /validation_board: 산 후보/안 산 후보/구조/freshness 검증',
        '- /health /candidate_reason /gate_check /paper_handoff /pstatus /errorlog', '',
        '- main_bot은 snapshot/cache 표시만 수행',
    ])


COMMANDS['batch'] = _v811_batch_text
COMMANDS['summary'] = _v811_batch_text
COMMANDS['pbatch'] = _v811_batch_text
COMMANDS['menu'] = _v811_menu_text
COMMANDS['help'] = _v811_menu_text
COMMANDS['preopen_review'] = _v810_preopen_review_text
COMMANDS['preopen'] = _v810_preopen_review_text



# =============================================================================
# main_bot v2.13.812: structure-board display, cache names are versionless
# - main reads canonical snapshots only. It does not recalc conditions.
# - Chat stays compact; txt keeps structure-board details.
# =============================================================================
V650_BUILD_LABEL = 'structure_board_mainline_2026-06-10'
BOT_VERSION = '수익형 v2.13.812'
MAIN_BOT_VERSION = BOT_VERSION


def _v812_structure_board_counts() -> Tuple[Counter, Counter, Counter, List[str]]:
    stage_counts: Counter = Counter(); setup_counts: Counter = Counter(); role_counts: Counter = Counter(); samples: List[str] = []
    try:
        snap = _v650_candidate_snapshot()
        rows = [r for r in (snap.get('trade_rows') or []) if isinstance(r, dict)]
        for r in rows:
            b = r.get('structure_board_v812') if isinstance(r.get('structure_board_v812'), dict) else (r.get('structure_board') if isinstance(r.get('structure_board'), dict) else {})
            if not b:
                continue
            st = _v650_stage(r)
            setup = str(b.get('setup_type') or '-')
            role = str(b.get('role') or '-')
            stage_counts[st] += 1; setup_counts[setup] += 1; role_counts[role] += 1
            if len(samples) < 8 and st in ('S1','S2'):
                reason = ' / '.join(str(x) for x in (b.get('stage_reasons') or [])[:2])
                samples.append(f"{_v650_ticker(r)} {st}/{setup}/{role} · {reason}")
    except Exception as exc:
        log_error('v812_structure_board_counts', exc)
    return stage_counts, setup_counts, role_counts, samples


def _v812_structure_short_lines() -> List[str]:
    stage_counts, setup_counts, role_counts, samples = _v812_structure_board_counts()
    if not stage_counts and not setup_counts:
        return ['- 구조판: 아직 v812 필드 없음']
    lines = [
        '- 구조판 stage: ' + _v799_counter_line(stage_counts, 4),
        '- 구조타입 TOP: ' + _v799_counter_line(setup_counts, 5),
        '- 구조역할 TOP: ' + _v799_counter_line(role_counts, 5),
    ]
    if samples:
        lines.append('- 구조 샘플: ' + ' / '.join(samples[:3]))
    return lines


def _v812_structure_board_text() -> str:
    lines = ['📊 구조판 /structure_board · v812', '- 기준: candidate canonical row의 structure_board. main 재계산 없음.']
    lines += _v812_structure_short_lines()
    return '\n'.join(lines)


def _v812_next_action_lines() -> List[str]:
    return [
        '- 구조판이 S1/S2/S3 주인인지 확인: 조건 미달문구보다 structure_board stage를 봄',
        '- 조건은 생존위험(fresh/trigger/spread/slippage/매도압력)만 하드가드로 남김',
        '- 좋은 구조 S2는 structure_recheck_s2로 빠른 재확인 소비',
        '- 전체 상세는 첨부 txt에서 확인',
    ]


def _v812_batch_text() -> str:
    since_ts = _v798_batch_marker_ts() if '_v798_batch_marker_ts' in globals() else 0.0
    lines = ['📊 코인봇 운영 핵심요약 /batch · v812']
    lines += _v799_section('① 적용/생존') + _v809_apply_short_lines() + _v809_worker_short_lines()
    lines += _v799_section('② 성과') + _v811_score_short_lines()
    lines += _v799_section('③ 현재 후보') + _v809_candidate_short_lines()
    lines += _v799_section('④ 구조판') + _v812_structure_short_lines()
    lines += _v799_section('⑤ 정보 freshness') + _v809_freshness_short_lines()
    lines += _v799_section('⑥ 품질판') + _v809_quality_short_lines()
    lines += _v799_section('⑦ OPEN직전 보류검증') + _v810_preopen_review_lines(3)
    lines += _v799_section('⑧ 최근 매매') + _v809_recent_trade_short_lines(since_ts)
    lines += _v799_section('⑨ 자원/오류') + _v809_resource_error_short_lines()
    lines += _v799_section('⑩ 다음 판단') + _v812_next_action_lines()
    lines += ['', '📎 전체 상세는 묶음 요약 txt에 보존됨']
    return '\n'.join(lines)


def _v812_batch_summary_text(cmds: List[str], outputs: Dict[str,str], timings: List[Dict[str,Any]], recv_delay: float, total_sec: float, chat_body: str = '') -> str:
    global _V797_PENDING_BATCH_MARKER_TS
    batch_until = now_ts(); _V797_PENDING_BATCH_MARKER_TS = batch_until
    since_ts = _v798_batch_marker_ts() if '_v798_batch_marker_ts' in globals() else 0.0
    lines=['코인봇 묶음 요약집 v812', f'- 생성: {_v800_kst_text(batch_until)}', f'- 메인봇: {BOT_VERSION} / {V650_BUILD_LABEL}', f'- 접수지연: {recv_delay:.2f}s / 처리합계: {total_sec:.2f}s', '', '[명령 처리시간]']
    for t in timings:
        lines.append(f"- {'✅' if not t.get('error') else '❌'} /{t.get('name','?')}: {float(t.get('sec') or 0):.2f}s / {'OK' if not t.get('error') else 'ERR'}")
    lines += ['', '[채팅 운영 핵심 요약]', _v650_safe_body(chat_body or _v812_batch_text(), 3200), '']
    lines += ['', '[전체 상세 요약]', _v650_safe_body(_v807_batch_text(), 9000), '']
    lines += ['', '[구조판 상세]'] + _v812_structure_short_lines()
    lines += _v799_trade_detail_lines_range(since_ts, batch_until)
    lines += ['', '[통합 검증판 상세]'] + _v807_integrated_validation_lines(since_ts, batch_until, compact=False)
    lines += ['', '[가격반응 지연·체결착시 품질판 상세]'] + _v807_price_lag_quality_lines(10) + _v810_quality_route_lines()
    lines += ['', '[OPEN직전 보류 사후검증]'] + _v810_preopen_review_lines(10)
    lines += ['', '[아까운 후보 / 놓친 후보 상세]'] + _v805_missed_summary_lines(10)
    lines += ['', '[명령별 상세]']
    for name in cmds:
        lines += ['', f'/{name}', _v650_safe_body(outputs.get(name,''), 2200)]
    return '\n'.join(lines)


def _v812_menu_text() -> str:
    return '\n'.join([
        '🧭 코인봇 메뉴 /menu · v812', '',
        '- /batch: 채팅 핵심요약 + txt 전체상세',
        '- /structure_board: 구조판 stage/type/role',
        '- /quality_board: 가격후행/체결착시/후속실패 품질판',
        '- /preopen_review: OPEN직전 보류 사후검증',
        '- /validation_board: 산 후보/안 산 후보/구조/freshness 검증',
        '- /health /candidate_reason /gate_check /paper_handoff /pstatus /errorlog', '',
        '- main_bot은 snapshot/cache 표시만 수행',
    ])

COMMANDS['batch'] = _v812_batch_text
COMMANDS['summary'] = _v812_batch_text
COMMANDS['pbatch'] = _v812_batch_text
COMMANDS['structure_board'] = _v812_structure_board_text
COMMANDS['structure'] = _v812_structure_board_text
COMMANDS['menu'] = _v812_menu_text
COMMANDS['help'] = _v812_menu_text

# Replace batch handler summary writer without changing command flow.
_v812_prev_batch_handler = batch_handler

def batch_handler(update, context):  # type: ignore[override]
    try:
        msg_date=getattr(getattr(update,'message',None),'date',None)
        recv_delay=time.time()-msg_date.timestamp() if hasattr(msg_date,'timestamp') else 0.0
    except Exception:
        recv_delay=0.0
    default_cmds=['health','structure_board','validation_board','quality_board','preopen_review','missed_candidates','candidate_reason','gate_check','paper_handoff','pstatus','errorlog']
    raw_args = getattr(context,'args',None) or []
    cmds=[str(x).strip().lstrip('/') for x in (raw_args or default_cmds)[:10] if str(x).strip()]
    stime=time.time(); timings=[]; outputs={}; chat_body=''
    _v811_begin_batch_source_lock()
    try:
        try:
            send(update, f'📊 묶음 확인 시작\n- 채팅: 운영 핵심요약\n- txt: 전체 상세 보존\n- 접수지연 {recv_delay:.2f}s')
        except Exception:
            pass
        for name in cmds:
            fn=COMMANDS.get(name); t0=time.time(); err=None
            if not fn:
                body=f'❌ /{name} 연결 없음'; err='no_handler'
            else:
                try:
                    body=fn()
                except Exception as exc:
                    body=f'❌ /{name} 오류 {exc.__class__.__name__}: {exc}'; err=f'{exc.__class__.__name__}: {exc}'; log_error(f'v812_batch_{name}', exc)
            sec=time.time()-t0; outputs[name]=body; timings.append({'name':name,'sec':sec,'error':err})
        total=time.time()-stime
        try:
            chat_body = _v812_batch_text()
            send(update, chat_body)
        except Exception as exc:
            log_error('v812_batch_short_send', exc)
        try:
            status=_v650_send_summary_file(update, _v812_batch_summary_text(cmds, outputs, timings, recv_delay, total, chat_body=chat_body))
        except Exception as exc:
            status=f'txt 생성실패 {exc.__class__.__name__}'; log_error('v812_batch_summary_file', exc)
        mark='✅' if '전송완료' in status else '⚠️'; del_mark='✅' if '서버삭제' in status else ('❌' if '전송완료' in status else '❔')
        try:
            send(update, f'📎 묶음 요약집\n- 전송: {mark} {status}\n- 임시파일 삭제: {del_mark}\n- 처리합계: {total:.2f}s')
        except Exception:
            pass
    finally:
        _v811_end_batch_source_lock()

# =============================================================================
# main_bot v2.13.813: compact chat, structure_board publish-owner display
# - Chat is shorter to reduce Telegram/app lag.
# - TXT keeps detailed diagnostics.
# =============================================================================
V650_BUILD_LABEL = 'structure_board_publish_owner_2026-06-10'
BOT_VERSION = '수익형 v2.13.813'
MAIN_BOT_VERSION = BOT_VERSION


def _v813_batch_text() -> str:
    since_ts = _v798_batch_marker_ts() if '_v798_batch_marker_ts' in globals() else 0.0
    lines = ['📊 /batch · v813 핵심요약']
    lines += ['① 적용/성과'] + _v809_apply_short_lines()[:3] + _v811_score_short_lines()[:3]
    lines += ['② 후보/구조'] + _v809_candidate_short_lines()[:2] + _v812_structure_short_lines()[:4]
    lines += ['③ freshness/품질'] + _v809_freshness_short_lines()[:2] + _v809_quality_short_lines()[:4]
    lines += ['④ 최근매매/오류'] + _v809_recent_trade_short_lines(since_ts)[:2] + _v809_resource_error_short_lines()[-1:]
    lines += ['⑤ 다음'] + ['- structure_board 필드가 실제 row에 박히는지 확인', '- 상세는 txt 요약집 확인']
    return '\n'.join(str(x) for x in lines)


def _v813_structure_board_text() -> str:
    lines = ['📊 구조판 /structure_board · v813', '- 기준: candidate canonical row의 structure_board. main 재계산 없음.']
    lines += _v812_structure_short_lines()
    return '\n'.join(lines)


def _v813_batch_summary_text(cmds: List[str], outputs: Dict[str,str], timings: List[Dict[str,Any]], recv_delay: float, total_sec: float, chat_body: str = '') -> str:
    global _V797_PENDING_BATCH_MARKER_TS
    batch_until = now_ts(); _V797_PENDING_BATCH_MARKER_TS = batch_until
    since_ts = _v798_batch_marker_ts() if '_v798_batch_marker_ts' in globals() else 0.0
    lines=['코인봇 묶음 요약집 v813', f'- 생성: {_v800_kst_text(batch_until)}', f'- 메인봇: {BOT_VERSION} / {V650_BUILD_LABEL}', f'- 접수지연: {recv_delay:.2f}s / 처리합계: {total_sec:.2f}s', '', '[명령 처리시간]']
    for t in timings:
        lines.append(f"- {'✅' if not t.get('error') else '❌'} /{t.get('name','?')}: {float(t.get('sec') or 0):.2f}s / {'OK' if not t.get('error') else 'ERR'}")
    lines += ['', '[채팅 핵심요약]', _v650_safe_body(chat_body or _v813_batch_text(), 1800), '']
    lines += ['', '[전체 상세 요약]', _v650_safe_body(_v807_batch_text(), 9000), '']
    lines += ['', '[구조판 상세]'] + _v812_structure_short_lines()
    lines += _v799_trade_detail_lines_range(since_ts, batch_until)
    lines += ['', '[통합 검증판 상세]'] + _v807_integrated_validation_lines(since_ts, batch_until, compact=False)
    lines += ['', '[가격반응 지연·체결착시 품질판 상세]'] + _v807_price_lag_quality_lines(10) + _v810_quality_route_lines()
    lines += ['', '[OPEN직전 보류 사후검증]'] + _v810_preopen_review_lines(10)
    lines += ['', '[아까운 후보 / 놓친 후보 상세]'] + _v805_missed_summary_lines(10)
    lines += ['', '[명령별 상세]']
    for name in cmds:
        lines += ['', f'/{name}', _v650_safe_body(outputs.get(name,''), 2200)]
    return '\n'.join(lines)

COMMANDS['batch'] = _v813_batch_text
COMMANDS['summary'] = _v813_batch_text
COMMANDS['pbatch'] = _v813_batch_text
COMMANDS['structure_board'] = _v813_structure_board_text
COMMANDS['structure'] = _v813_structure_board_text


def batch_handler(update, context):  # type: ignore[override]
    try:
        msg_date=getattr(getattr(update,'message',None),'date',None)
        recv_delay=time.time()-msg_date.timestamp() if hasattr(msg_date,'timestamp') else 0.0
    except Exception:
        recv_delay=0.0
    default_cmds=['health','structure_board','validation_board','quality_board','preopen_review','missed_candidates','candidate_reason','gate_check','paper_handoff','pstatus','errorlog']
    raw_args = getattr(context,'args',None) or []
    cmds=[str(x).strip().lstrip('/') for x in (raw_args or default_cmds)[:10] if str(x).strip()]
    stime=time.time(); timings=[]; outputs={}; chat_body=''
    _v811_begin_batch_source_lock()
    try:
        try: send(update, f'📊 묶음 시작 · 채팅 짧게 / 상세 txt · 지연 {recv_delay:.2f}s')
        except Exception: pass
        for name in cmds:
            fn=COMMANDS.get(name); t0=time.time(); err=None
            if not fn:
                body=f'❌ /{name} 연결 없음'; err='no_handler'
            else:
                try: body=fn()
                except Exception as exc:
                    body=f'❌ /{name} 오류 {exc.__class__.__name__}: {exc}'; err=f'{exc.__class__.__name__}: {exc}'; log_error(f'v813_batch_{name}', exc)
            timings.append({'name':name,'sec':time.time()-t0,'error':err}); outputs[name]=body
        total=time.time()-stime
        try:
            chat_body=_v813_batch_text(); send(update, chat_body)
        except Exception as exc: log_error('v813_batch_short_send', exc)
        try:
            status=_v650_send_summary_file(update, _v813_batch_summary_text(cmds, outputs, timings, recv_delay, total, chat_body=chat_body))
        except Exception as exc:
            status=f'txt 생성실패 {exc.__class__.__name__}'; log_error('v813_batch_summary_file', exc)
        mark='✅' if '전송완료' in status else '⚠️'; del_mark='✅' if '서버삭제' in status else ('❌' if '전송완료' in status else '❔')
        try: send(update, f'📎 txt {mark} / 삭제 {del_mark} / {total:.2f}s')
        except Exception: pass
    finally:
        _v811_end_batch_source_lock()


# =============================================================================
# main_bot v2.13.815: deploy compile-list fix + balanced command summaries
# - Fix actual runtime map by shipping the same main under likely live filenames.
# - Chat keeps short summaries for every core command; TXT keeps full details.
# - No strategy threshold/exit/paper ledger change.
# =============================================================================
V650_BUILD_LABEL = 'deploy_compile_list_fix_2026-06-10'
BOT_VERSION = '수익형 v2.13.815'
MAIN_BOT_VERSION = BOT_VERSION


def _v815_pick_lines(body: str, patterns: List[str], limit: int = 2) -> List[str]:
    out: List[str] = []
    text = str(body or '')
    for raw in text.splitlines():
        line = raw.strip()
        if not line:
            continue
        for p in patterns:
            if p in line:
                out.append(line)
                break
        if len(out) >= limit:
            break
    return out


def _v815_first_signal_lines(name: str, body: str) -> List[str]:
    body = str(body or '')
    if not body.strip():
        return ['출력 없음']
    n = str(name or '').strip().lstrip('/')
    if n == 'health':
        lines = _v815_pick_lines(body, ['worker:', '후보 snapshot:', '재확인 배관:', 'CPU:', '디스크:'], 2)
    elif n in ('structure_board','structure'):
        lines = _v815_pick_lines(body, ['구조판:', '구조타입', 'structure_stage', 'structure_setup', 'S1', '필드 없음'], 3)
    elif n == 'quality_board':
        lines = _v815_pick_lines(body, ['현재 후보 품질:', '판단연결 태그:', '가격후행 성공:', '체결착시 위험:'], 2)
    elif n == 'preopen_review':
        lines = _v815_pick_lines(body, ['OPEN직전 보류검증:', '보류사유 TOP:', '검증상태 TOP:', '막은 뒤 간 후보:'], 2)
    elif n == 'validation_board':
        lines = _v815_pick_lines(body, ['[산 후보 검증]', '- 구간 CLOSED', '검증분류:', '원인원본:'], 2)
    elif n == 'pstatus':
        lines = _v815_pick_lines(body, ['OPEN:', 'paper 소비 흐름:', '최근 CLOSED', 'S1 hold:'], 2)
    elif n == 'errorlog':
        lines = _v815_pick_lines(body, ['새 실행 중 오류 없음', '오류', 'NameError', 'Traceback'], 2)
    else:
        lines = []
        for raw in body.splitlines():
            line=raw.strip()
            if line and not line.startswith('📊') and not line.startswith('🧭'):
                lines.append(line)
            if len(lines)>=2: break
    return lines or ['핵심 줄 추출 없음']


def _v815_command_summary_lines(outputs: Dict[str,str], timings: List[Dict[str,Any]]) -> List[str]:
    if not outputs:
        return ['- 명령별 요약: batch handler 실행 시 표시']
    sec_map={str(t.get('name','')): float(t.get('sec') or 0) for t in (timings or [])}
    err_map={str(t.get('name','')): t.get('error') for t in (timings or [])}
    order=['health','structure_board','quality_board','preopen_review','validation_board','pstatus','errorlog']
    lines=[]
    for name in order:
        if name not in outputs:
            continue
        mark='✅' if not err_map.get(name) else '❌'
        picked=_v815_first_signal_lines(name, outputs.get(name,''))
        joined=' / '.join(p.replace('  ',' ') for p in picked[:2])
        lines.append(f"- {mark} /{name} {sec_map.get(name,0.0):.2f}s: {joined}")
    return lines or ['- 명령별 요약 없음']


def _v815_batch_text(outputs: Optional[Dict[str,str]] = None, timings: Optional[List[Dict[str,Any]]] = None) -> str:
    since_ts = _v798_batch_marker_ts() if '_v798_batch_marker_ts' in globals() else 0.0
    lines = ['📊 코인봇 운영요약 /batch · v815']
    lines += ['① 적용/성과'] + _v809_apply_short_lines()[:3] + _v811_score_short_lines()[:3]
    lines += ['② 후보/구조'] + _v809_candidate_short_lines()[:2] + _v812_structure_short_lines()[:3]
    lines += ['③ freshness/품질'] + _v809_freshness_short_lines()[:2] + _v809_quality_short_lines()[:3]
    lines += ['④ preopen/매매/오류'] + _v810_preopen_review_lines(3)[:3] + _v809_recent_trade_short_lines(since_ts)[:2] + _v809_resource_error_short_lines()[-1:]
    lines += ['⑤ 명령별 핵심'] + _v815_command_summary_lines(outputs or {}, timings or [])
    lines += ['⑥ 다음', '- /structure_board에서 필드 없음 사라졌는지 확인', '- 상세는 txt 요약집 보존']
    return '\n'.join(str(x) for x in lines)


def _v815_structure_board_text() -> str:
    lines = ['📊 구조판 /structure_board · v815', '- 기준: candidate canonical row의 structure_board. main 재계산 없음.']
    lines += _v812_structure_short_lines()
    return '\n'.join(lines)


def _v815_batch_summary_text(cmds: List[str], outputs: Dict[str,str], timings: List[Dict[str,Any]], recv_delay: float, total_sec: float, chat_body: str = '') -> str:
    global _V797_PENDING_BATCH_MARKER_TS
    batch_until = now_ts(); _V797_PENDING_BATCH_MARKER_TS = batch_until
    since_ts = _v798_batch_marker_ts() if '_v798_batch_marker_ts' in globals() else 0.0
    lines=['코인봇 묶음 요약집 v815', f'- 생성: {_v800_kst_text(batch_until)}', f'- 메인봇: {BOT_VERSION} / {V650_BUILD_LABEL}', f'- 접수지연: {recv_delay:.2f}s / 처리합계: {total_sec:.2f}s', '', '[명령 처리시간]']
    for t in timings:
        lines.append(f"- {'✅' if not t.get('error') else '❌'} /{t.get('name','?')}: {float(t.get('sec') or 0):.2f}s / {'OK' if not t.get('error') else 'ERR'}")
    lines += ['', '[채팅 핵심요약]', _v650_safe_body(chat_body or _v815_batch_text(outputs, timings), 2600), '']
    lines += ['', '[명령별 짧은 요약]'] + _v815_command_summary_lines(outputs, timings)
    lines += ['', '[전체 상세 요약]', _v650_safe_body(_v807_batch_text(), 9000), '']
    lines += ['', '[구조판 상세]'] + _v812_structure_short_lines()
    lines += _v799_trade_detail_lines_range(since_ts, batch_until)
    lines += ['', '[통합 검증판 상세]'] + _v807_integrated_validation_lines(since_ts, batch_until, compact=False)
    lines += ['', '[가격반응 지연·체결착시 품질판 상세]'] + _v807_price_lag_quality_lines(10) + _v810_quality_route_lines()
    lines += ['', '[OPEN직전 보류 사후검증]'] + _v810_preopen_review_lines(10)
    lines += ['', '[아까운 후보 / 놓친 후보 상세]'] + _v805_missed_summary_lines(10)
    lines += ['', '[명령별 상세]']
    for name in cmds:
        lines += ['', f'/{name}', _v650_safe_body(outputs.get(name,''), 4200)]
    return '\n'.join(lines)

COMMANDS['batch'] = _v815_batch_text
COMMANDS['summary'] = _v815_batch_text
COMMANDS['pbatch'] = _v815_batch_text
COMMANDS['structure_board'] = _v815_structure_board_text
COMMANDS['structure'] = _v815_structure_board_text


def batch_handler(update, context):  # type: ignore[override]
    try:
        msg_date=getattr(getattr(update,'message',None),'date',None)
        recv_delay=time.time()-msg_date.timestamp() if hasattr(msg_date,'timestamp') else 0.0
    except Exception:
        recv_delay=0.0
    # Core commands are not omitted. Each gets a short chat summary; full raw output goes to txt.
    default_cmds=['health','structure_board','quality_board','preopen_review','validation_board','pstatus','errorlog']
    raw_args = getattr(context,'args',None) or []
    cmds=[str(x).strip().lstrip('/') for x in (raw_args or default_cmds)[:12] if str(x).strip()]
    stime=time.time(); timings=[]; outputs={}; chat_body=''
    _v811_begin_batch_source_lock()
    try:
        try: send(update, f'📊 묶음 시작 · 명령별 짧은요약 + 상세txt · 지연 {recv_delay:.2f}s')
        except Exception: pass
        for name in cmds:
            fn=COMMANDS.get(name); t0=time.time(); err=None
            if not fn:
                body=f'❌ /{name} 연결 없음'; err='no_handler'
            else:
                try: body=fn()
                except Exception as exc:
                    body=f'❌ /{name} 오류 {exc.__class__.__name__}: {exc}'; err=f'{exc.__class__.__name__}: {exc}'; log_error(f'v815_batch_{name}', exc)
            timings.append({'name':name,'sec':time.time()-t0,'error':err}); outputs[name]=body
        total=time.time()-stime
        try:
            chat_body=_v815_batch_text(outputs, timings); send(update, chat_body)
        except Exception as exc: log_error('v815_batch_short_send', exc)
        try:
            status=_v650_send_summary_file(update, _v815_batch_summary_text(cmds, outputs, timings, recv_delay, total, chat_body=chat_body))
        except Exception as exc:
            status=f'txt 생성실패 {exc.__class__.__name__}'; log_error('v815_batch_summary_file', exc)
        mark='✅' if '전송완료' in status else '⚠️'; del_mark='✅' if '서버삭제' in status else ('❌' if '전송완료' in status else '❔')
        try: send(update, f'📎 txt {mark} / 삭제 {del_mark} / {total:.2f}s')
        except Exception: pass
    finally:
        _v811_end_batch_source_lock()


# =============================================================================
# main_bot v2.13.817: command-by-command short chat + full txt detail
# - Do not omit core commands.
# - /batch sends 1/N, 2/N... short summaries for each command, while the txt keeps
#   full raw command details.
# - /structure_board remains canonical-read only. No output-side fake structure board.
# =============================================================================
V650_BUILD_LABEL = 'deploy_manifest_main_v817_command_structure_2026-06-10'
BOT_VERSION = '수익형 v2.13.817'
MAIN_BOT_VERSION = BOT_VERSION


def _v817_structure_board_text() -> str:
    lines = ['📊 구조판 /structure_board · v817', '- 기준: candidate canonical row의 structure_board. main 재계산 없음.']
    lines += _v812_structure_short_lines()
    return '\n'.join(lines)


def _v817_command_short_block(idx: int, total: int, name: str, body: str, sec: float, err: Optional[str] = None) -> str:
    mark = '✅' if not err else '❌'
    picked = _v815_first_signal_lines(name, body)
    # 2~4 lines, not omitted, not full raw spam.
    max_lines = 4 if name in ('batch','health','structure_board') else 3
    lines = [f'{idx}/{total} {mark} /{name} · {sec:.2f}s']
    for x in picked[:max_lines]:
        sx = str(x).strip()
        if sx:
            lines.append(f'- {sx}')
    if err:
        lines.append(f'- error: {err}')
    return '\n'.join(lines)


def _v817_command_summary_lines(outputs: Dict[str,str], timings: List[Dict[str,Any]], order: Optional[List[str]] = None) -> List[str]:
    if order is None:
        order = ['health','batch','structure_board','quality_board','preopen_review','validation_board','pstatus','errorlog']
    sec_map={str(t.get('name','')): float(t.get('sec') or 0) for t in (timings or [])}
    err_map={str(t.get('name','')): t.get('error') for t in (timings or [])}
    lines=[]
    total=len([n for n in order if n in outputs]) or len(outputs)
    i=0
    for name in order:
        if name not in outputs:
            continue
        i += 1
        block = _v817_command_short_block(i, total, name, outputs.get(name,''), sec_map.get(name,0.0), err_map.get(name))
        lines.extend(block.splitlines())
    return lines or ['- 명령별 요약 없음']


def _v817_batch_text(outputs: Optional[Dict[str,str]] = None, timings: Optional[List[Dict[str,Any]]] = None) -> str:
    since_ts = _v798_batch_marker_ts() if '_v798_batch_marker_ts' in globals() else 0.0
    lines = ['📊 코인봇 운영요약 /batch · v817']
    lines += ['① 적용/성과'] + _v809_apply_short_lines()[:3] + _v811_score_short_lines()[:3]
    lines += ['② 후보/구조'] + _v809_candidate_short_lines()[:2] + _v812_structure_short_lines()[:3]
    lines += ['③ preopen/매매/오류'] + _v810_preopen_review_lines(3)[:3] + _v809_recent_trade_short_lines(since_ts)[:2] + _v809_resource_error_short_lines()[-1:]
    if outputs:
        lines += ['④ 명령별 핵심'] + _v817_command_summary_lines(outputs, timings or [])
    lines += ['⑤ 다음', '- 명령은 생략하지 않고 1/N 짧은요약으로 표시', '- 상세 원문은 txt 요약집 보존']
    return '\n'.join(str(x) for x in lines)


def _v817_batch_summary_text(cmds: List[str], outputs: Dict[str,str], timings: List[Dict[str,Any]], recv_delay: float, total_sec: float, chat_body: str = '') -> str:
    global _V797_PENDING_BATCH_MARKER_TS
    batch_until = now_ts(); _V797_PENDING_BATCH_MARKER_TS = batch_until
    since_ts = _v798_batch_marker_ts() if '_v798_batch_marker_ts' in globals() else 0.0
    lines=['코인봇 묶음 요약집 v817', f'- 생성: {_v800_kst_text(batch_until)}', f'- 메인봇: {BOT_VERSION} / {V650_BUILD_LABEL}', f'- 접수지연: {recv_delay:.2f}s / 처리합계: {total_sec:.2f}s', '', '[명령 처리시간]']
    for t in timings:
        lines.append(f"- {'✅' if not t.get('error') else '❌'} /{t.get('name','?')}: {float(t.get('sec') or 0):.2f}s / {'OK' if not t.get('error') else 'ERR'}")
    lines += ['', '[채팅 핵심요약]', _v650_safe_body(chat_body or _v817_batch_text(outputs, timings), 5200), '']
    lines += ['', '[명령별 짧은 요약]'] + _v817_command_summary_lines(outputs, timings, cmds)
    lines += ['', '[전체 상세 요약]', _v650_safe_body(_v807_batch_text(), 9000), '']
    lines += ['', '[구조판 상세]'] + _v812_structure_short_lines()
    lines += _v799_trade_detail_lines_range(since_ts, batch_until)
    lines += ['', '[통합 검증판 상세]'] + _v807_integrated_validation_lines(since_ts, batch_until, compact=False)
    lines += ['', '[가격반응 지연·체결착시 품질판 상세]'] + _v807_price_lag_quality_lines(10) + _v810_quality_route_lines()
    lines += ['', '[OPEN직전 보류 사후검증]'] + _v810_preopen_review_lines(10)
    lines += ['', '[아까운 후보 / 놓친 후보 상세]'] + _v805_missed_summary_lines(10)
    lines += ['', '[명령별 상세]']
    for name in cmds:
        lines += ['', f'/{name}', _v650_safe_body(outputs.get(name,''), 5200)]
    return '\n'.join(lines)

COMMANDS['batch'] = _v817_batch_text
COMMANDS['summary'] = _v817_batch_text
COMMANDS['pbatch'] = _v817_batch_text
COMMANDS['structure_board'] = _v817_structure_board_text
COMMANDS['structure'] = _v817_structure_board_text


def batch_handler(update, context):  # type: ignore[override]
    try:
        msg_date=getattr(getattr(update,'message',None),'date',None)
        recv_delay=time.time()-msg_date.timestamp() if hasattr(msg_date,'timestamp') else 0.0
    except Exception:
        recv_delay=0.0
    # Keep the command flow. Do not omit /batch; call COMMANDS['batch'] as a text function, not this handler.
    default_cmds=['health','batch','structure_board','quality_board','preopen_review','validation_board','pstatus','errorlog']
    raw_args = getattr(context,'args',None) or []
    cmds=[str(x).strip().lstrip('/') for x in (raw_args or default_cmds)[:12] if str(x).strip()]
    stime=time.time(); timings=[]; outputs={}
    _v811_begin_batch_source_lock()
    try:
        try: send(update, f'📊 묶음 시작 · {len(cmds)}개 명령 / 각 명령 짧은요약 + 상세txt · 지연 {recv_delay:.2f}s')
        except Exception: pass
        total_cmds=len(cmds)
        for idx, name in enumerate(cmds, start=1):
            fn=COMMANDS.get(name); t0=time.time(); err=None
            if not fn:
                body=f'❌ /{name} 연결 없음'; err='no_handler'
            else:
                try: body=fn()
                except Exception as exc:
                    body=f'❌ /{name} 오류 {exc.__class__.__name__}: {exc}'; err=f'{exc.__class__.__name__}: {exc}'; log_error(f'v817_batch_{name}', exc)
            sec=time.time()-t0
            timings.append({'name':name,'sec':sec,'error':err}); outputs[name]=body
            try:
                send(update, _v817_command_short_block(idx, total_cmds, name, body, sec, err))
            except Exception as exc:
                log_error('v817_batch_step_send', exc)
        total=time.time()-stime
        chat_body=_v817_batch_text(outputs, timings)
        try: send(update, chat_body)
        except Exception as exc: log_error('v817_batch_overall_send', exc)
        try:
            status=_v650_send_summary_file(update, _v817_batch_summary_text(cmds, outputs, timings, recv_delay, total, chat_body=chat_body))
        except Exception as exc:
            status=f'txt 생성실패 {exc.__class__.__name__}'; log_error('v817_batch_summary_file', exc)
        mark='✅' if '전송완료' in status else '⚠️'; del_mark='✅' if '서버삭제' in status else ('❌' if '전송완료' in status else '❔')
        try: send(update, f'📎 txt {mark} / 삭제 {del_mark} / {total:.2f}s')
        except Exception: pass
    finally:
        _v811_end_batch_source_lock()

# END v817 main command-step summaries



# =============================================================================
# main_bot v2.13.818: fixed core batch flow + structure board command label
# - /batch always runs the 8 core command summaries unless explicitly called with
#   "custom/only". This prevents a 4-command verification list from becoming
#   the default batch spine.
# - Chat keeps 1/N short summaries for every core command; txt keeps full raw details.
# - No output-side fake structure board. /structure_board still reads canonical row only.
# =============================================================================
V650_BUILD_LABEL = 'batch_core8_and_worker_manifest_v818_2026-06-10'
BOT_VERSION = '수익형 v2.13.818'
MAIN_BOT_VERSION = BOT_VERSION


def _v818_structure_board_text() -> str:
    lines = ['📊 구조판 /structure_board · v818', '- 기준: candidate canonical row의 structure_board. main 재계산 없음.']
    lines += _v812_structure_short_lines()
    return '\n'.join(lines)


def _v818_batch_text(outputs: Optional[Dict[str,str]] = None, timings: Optional[List[Dict[str,Any]]] = None) -> str:
    since_ts = _v798_batch_marker_ts() if '_v798_batch_marker_ts' in globals() else 0.0
    lines = ['📊 코인봇 운영요약 /batch · v818']
    lines += ['① 적용/성과'] + _v809_apply_short_lines()[:3] + _v811_score_short_lines()[:3]
    lines += ['② 후보/구조'] + _v809_candidate_short_lines()[:2] + _v812_structure_short_lines()[:3]
    lines += ['③ preopen/매매/오류'] + _v810_preopen_review_lines(3)[:3] + _v809_recent_trade_short_lines(since_ts)[:2] + _v809_resource_error_short_lines()[-1:]
    if outputs:
        lines += ['④ 명령별 핵심'] + _v817_command_summary_lines(outputs, timings or [], _v818_core_batch_cmds())
    lines += ['⑤ 다음', '- /batch는 기본 8개 명령을 1/8~8/8로 요약', '- 상세 원문은 txt 요약집 보존', '- 구조판은 strategy canonical row 봉인 여부만 표시']
    return '\n'.join(str(x) for x in lines)


def _v818_core_batch_cmds() -> List[str]:
    return ['health','batch','structure_board','quality_board','preopen_review','validation_board','pstatus','errorlog']


def _v818_select_batch_cmds(raw_args: Any) -> List[str]:
    args = [str(x).strip().lstrip('/') for x in (raw_args or []) if str(x).strip()]
    # Default is always the full core spine. Custom mode is explicit only.
    if args and args[0].lower() in ('custom','only','cmds'):
        custom = [x for x in args[1:13] if x]
        return custom or _v818_core_batch_cmds()
    return _v818_core_batch_cmds()


def _v818_batch_summary_text(cmds: List[str], outputs: Dict[str,str], timings: List[Dict[str,Any]], recv_delay: float, total_sec: float, chat_body: str = '') -> str:
    global _V797_PENDING_BATCH_MARKER_TS
    batch_until = now_ts(); _V797_PENDING_BATCH_MARKER_TS = batch_until
    since_ts = _v798_batch_marker_ts() if '_v798_batch_marker_ts' in globals() else 0.0
    lines=['코인봇 묶음 요약집 v818', f'- 생성: {_v800_kst_text(batch_until)}', f'- 메인봇: {BOT_VERSION} / {V650_BUILD_LABEL}', f'- 접수지연: {recv_delay:.2f}s / 처리합계: {total_sec:.2f}s', '', '[명령 처리시간]']
    for t in timings:
        lines.append(f"- {'✅' if not t.get('error') else '❌'} /{t.get('name','?')}: {float(t.get('sec') or 0):.2f}s / {'OK' if not t.get('error') else 'ERR'}")
    lines += ['', '[채팅 핵심요약]', _v650_safe_body(chat_body or _v818_batch_text(outputs, timings), 5200), '']
    lines += ['', '[명령별 짧은 요약]'] + _v817_command_summary_lines(outputs, timings, cmds)
    lines += ['', '[전체 상세 요약]', _v650_safe_body(_v807_batch_text(), 9000), '']
    lines += ['', '[구조판 상세]'] + _v812_structure_short_lines()
    lines += _v799_trade_detail_lines_range(since_ts, batch_until)
    lines += ['', '[통합 검증판 상세]'] + _v807_integrated_validation_lines(since_ts, batch_until, compact=False)
    lines += ['', '[가격반응 지연·체결착시 품질판 상세]'] + _v807_price_lag_quality_lines(10) + _v810_quality_route_lines()
    lines += ['', '[OPEN직전 보류 사후검증]'] + _v810_preopen_review_lines(10)
    lines += ['', '[아까운 후보 / 놓친 후보 상세]'] + _v805_missed_summary_lines(10)
    lines += ['', '[명령별 상세]']
    for name in cmds:
        lines += ['', f'/{name}', _v650_safe_body(outputs.get(name,''), 5200)]
    return '\n'.join(lines)

COMMANDS['batch'] = _v818_batch_text
COMMANDS['summary'] = _v818_batch_text
COMMANDS['pbatch'] = _v818_batch_text
COMMANDS['structure_board'] = _v818_structure_board_text
COMMANDS['structure'] = _v818_structure_board_text


def batch_handler(update, context):  # type: ignore[override]
    try:
        msg_date=getattr(getattr(update,'message',None),'date',None)
        recv_delay=time.time()-msg_date.timestamp() if hasattr(msg_date,'timestamp') else 0.0
    except Exception:
        recv_delay=0.0
    cmds = _v818_select_batch_cmds(getattr(context,'args',None) or [])
    stime=time.time(); timings=[]; outputs={}
    _v811_begin_batch_source_lock()
    try:
        try: send(update, f'📊 묶음 시작 · {len(cmds)}개 명령 / 1~{len(cmds)} 짧은요약 + 상세txt · 지연 {recv_delay:.2f}s')
        except Exception: pass
        total_cmds=len(cmds)
        for idx, name in enumerate(cmds, start=1):
            fn=COMMANDS.get(name); t0=time.time(); err=None
            if not fn:
                body=f'❌ /{name} 연결 없음'; err='no_handler'
            else:
                try: body=fn()
                except Exception as exc:
                    body=f'❌ /{name} 오류 {exc.__class__.__name__}: {exc}'; err=f'{exc.__class__.__name__}: {exc}'; log_error(f'v818_batch_{name}', exc)
            sec=time.time()-t0
            timings.append({'name':name,'sec':sec,'error':err}); outputs[name]=body
            try: send(update, _v817_command_short_block(idx, total_cmds, name, body, sec, err))
            except Exception as exc: log_error('v818_batch_step_send', exc)
        total=time.time()-stime
        chat_body=_v818_batch_text(outputs, timings)
        try: send(update, chat_body)
        except Exception as exc: log_error('v818_batch_overall_send', exc)
        try:
            status=_v650_send_summary_file(update, _v818_batch_summary_text(cmds, outputs, timings, recv_delay, total, chat_body=chat_body))
        except Exception as exc:
            status=f'txt 생성실패 {exc.__class__.__name__}'; log_error('v818_batch_summary_file', exc)
        mark='✅' if '전송완료' in status else '⚠️'; del_mark='✅' if '서버삭제' in status else ('❌' if '전송완료' in status else '❔')
        try: send(update, f'📎 txt {mark} / 삭제 {del_mark} / {total:.2f}s')
        except Exception: pass
    finally:
        _v811_end_batch_source_lock()

# END v818 main batch-core8 fix


# =============================================================================
# main_bot v2.13.819: command flow rollback + structure read only
# - /batch with no args shows only /batch summary. It does NOT force-run 8 commands.
# - If user explicitly passes multiple commands to /batch, each command is shown as 1/N.
# - Full details for executed commands remain in the txt attachment.
# - Structure board remains canonical-read only; no output-side fake board.
# =============================================================================
V650_BUILD_LABEL = 'command_flow_rollback_structure_worker_owner_v819_2026-06-10'
BOT_VERSION = '수익형 v2.13.819'
MAIN_BOT_VERSION = BOT_VERSION


def _v819_structure_board_text() -> str:
    lines = ['📊 구조판 /structure_board · v819', '- 기준: candidate canonical row의 structure_board. main 재계산 없음.']
    lines += _v812_structure_short_lines()
    return '\n'.join(lines)


def _v819_batch_text(outputs: Optional[Dict[str,str]] = None, timings: Optional[List[Dict[str,Any]]] = None) -> str:
    since_ts = _v798_batch_marker_ts() if '_v798_batch_marker_ts' in globals() else 0.0
    lines = ['📊 코인봇 운영요약 /batch · v819']
    lines += ['① 적용/성과'] + _v809_apply_short_lines()[:3] + _v811_score_short_lines()[:3]
    lines += ['② 후보/구조'] + _v809_candidate_short_lines()[:2] + _v812_structure_short_lines()[:3]
    lines += ['③ preopen/매매/오류'] + _v810_preopen_review_lines(3)[:3] + _v809_recent_trade_short_lines(since_ts)[:2] + _v809_resource_error_short_lines()[-1:]
    lines += ['④ 다음', '- 단일 명령은 단일 출력. 여러 명령을 같이 넣었을 때만 1/N 표시', '- 구조판은 strategy가 candidate row에 봉인한 값만 표시', '- 상세 원문은 txt 요약집 보존']
    return '\n'.join(str(x) for x in lines)


def _v819_select_batch_cmds(raw_args: Any) -> List[str]:
    args = [str(x).strip().lstrip('/') for x in (raw_args or []) if str(x).strip()]
    # No forced command bundle. /batch alone means /batch only.
    if not args:
        return ['batch']
    return args[:12]


def _v819_batch_summary_text(cmds: List[str], outputs: Dict[str,str], timings: List[Dict[str,Any]], recv_delay: float, total_sec: float, chat_body: str = '') -> str:
    global _V797_PENDING_BATCH_MARKER_TS
    batch_until = now_ts(); _V797_PENDING_BATCH_MARKER_TS = batch_until
    since_ts = _v798_batch_marker_ts() if '_v798_batch_marker_ts' in globals() else 0.0
    lines=['코인봇 묶음 요약집 v819', f'- 생성: {_v800_kst_text(batch_until)}', f'- 메인봇: {BOT_VERSION} / {V650_BUILD_LABEL}', f'- 접수지연: {recv_delay:.2f}s / 처리합계: {total_sec:.2f}s', '', '[명령 처리시간]']
    for t in timings:
        lines.append(f"- {'✅' if not t.get('error') else '❌'} /{t.get('name','?')}: {float(t.get('sec') or 0):.2f}s / {'OK' if not t.get('error') else 'ERR'}")
    lines += ['', '[채팅 핵심요약]', _v650_safe_body(chat_body or _v819_batch_text(outputs, timings), 4200), '']
    lines += ['', '[명령별 짧은 요약]'] + _v817_command_summary_lines(outputs, timings, cmds)
    lines += ['', '[전체 상세 요약]', _v650_safe_body(_v807_batch_text(), 9000), '']
    lines += ['', '[구조판 상세]'] + _v812_structure_short_lines()
    lines += _v799_trade_detail_lines_range(since_ts, batch_until)
    lines += ['', '[통합 검증판 상세]'] + _v807_integrated_validation_lines(since_ts, batch_until, compact=False)
    lines += ['', '[가격반응 지연·체결착시 품질판 상세]'] + _v807_price_lag_quality_lines(10) + _v810_quality_route_lines()
    lines += ['', '[OPEN직전 보류 사후검증]'] + _v810_preopen_review_lines(10)
    lines += ['', '[아까운 후보 / 놓친 후보 상세]'] + _v805_missed_summary_lines(10)
    lines += ['', '[명령별 상세]']
    for name in cmds:
        lines += ['', f'/{name}', _v650_safe_body(outputs.get(name,''), 5200)]
    return '\n'.join(lines)

COMMANDS['batch'] = _v819_batch_text
COMMANDS['summary'] = _v819_batch_text
COMMANDS['pbatch'] = _v819_batch_text
COMMANDS['structure_board'] = _v819_structure_board_text
COMMANDS['structure'] = _v819_structure_board_text


def batch_handler(update, context):  # type: ignore[override]
    try:
        msg_date=getattr(getattr(update,'message',None),'date',None)
        recv_delay=time.time()-msg_date.timestamp() if hasattr(msg_date,'timestamp') else 0.0
    except Exception:
        recv_delay=0.0
    cmds = _v819_select_batch_cmds(getattr(context,'args',None) or [])
    stime=time.time(); timings=[]; outputs={}
    _v811_begin_batch_source_lock()
    try:
        multi = len(cmds) > 1
        if multi:
            try: send(update, f'📊 묶음 시작 · {len(cmds)}개 명령 / 각 명령 짧은요약 + 상세txt · 지연 {recv_delay:.2f}s')
            except Exception: pass
        total_cmds=len(cmds)
        for idx, name in enumerate(cmds, start=1):
            fn=COMMANDS.get(name); t0=time.time(); err=None
            if not fn:
                body=f'❌ /{name} 연결 없음'; err='no_handler'
            else:
                try: body=fn()
                except Exception as exc:
                    body=f'❌ /{name} 오류 {exc.__class__.__name__}: {exc}'; err=f'{exc.__class__.__name__}: {exc}'; log_error(f'v819_batch_{name}', exc)
            sec=time.time()-t0
            timings.append({'name':name,'sec':sec,'error':err}); outputs[name]=body
            try:
                if multi:
                    send(update, _v817_command_short_block(idx, total_cmds, name, body, sec, err))
                else:
                    send(update, body)
            except Exception as exc: log_error('v819_batch_send', exc)
        total=time.time()-stime
        chat_body = outputs.get(cmds[0], '') if len(cmds) == 1 else _v819_batch_text(outputs, timings)
        try:
            status=_v650_send_summary_file(update, _v819_batch_summary_text(cmds, outputs, timings, recv_delay, total, chat_body=chat_body))
        except Exception as exc:
            status=f'txt 생성실패 {exc.__class__.__name__}'; log_error('v819_batch_summary_file', exc)
        mark='✅' if '전송완료' in status else '⚠️'; del_mark='✅' if '서버삭제' in status else ('❌' if '전송완료' in status else '❔')
        try: send(update, f'📎 txt {mark} / 삭제 {del_mark} / {total:.2f}s')
        except Exception: pass
    finally:
        _v811_end_batch_source_lock()

# END v819 command flow rollback

# =============================================================================
# main_bot v2.13.820: command-owned information placement + structure board view
# - Single commands keep their own information owners.
# - /pstatus owns OPEN coins, S1 hold, and paper consume flow.
# - /health continues to own workers/resources.
# - /structure_board owns structure stage/type/role only, with S1 gate warning.
# - /batch remains a compact overall summary; it does not force-run other commands.
# =============================================================================
V650_BUILD_LABEL = 'command_owner_info_structure_s1_gate_v820_2026-06-10'
BOT_VERSION = '수익형 v2.13.820'
MAIN_BOT_VERSION = BOT_VERSION


def _v820_open_position_lines(limit: int = 8) -> List[str]:
    rows = _v680_paper_open_rows() if '_v680_paper_open_rows' in globals() else []
    lines = [f"- 현재 OPEN: {len(rows)}개"]
    if not rows:
        return lines + ['- OPEN 코인: 없음']
    sample: List[str] = []
    for r in rows[:max(1, int(limit or 8))]:
        if not isinstance(r, dict):
            continue
        t = _v650_ticker(r) if '_v650_ticker' in globals() else str(r.get('ticker') or r.get('market') or '-')
        grade = str(r.get('grade') or r.get('entry_grade') or r.get('stage') or '-')
        entry = _v650_num(r.get('entry_price'), r.get('avg_entry_price'), r.get('open_price'), default=0.0) if '_v650_num' in globals() else 0.0
        cur = _v650_num(r.get('current_price'), r.get('last_price'), r.get('mark_price'), default=0.0) if '_v650_num' in globals() else 0.0
        pnl = _v650_num(r.get('pnl_pct'), r.get('profit_pct'), r.get('current_profit_pct'), r.get('unrealized_pct'), default=0.0) if '_v650_num' in globals() else 0.0
        if (not pnl) and entry > 0 and cur > 0:
            try: pnl = (cur - entry) / entry * 100.0
            except Exception: pnl = 0.0
        strat = str(r.get('strategy_bucket_primary_label') or r.get('strategy_name') or r.get('strategy') or r.get('strategy_key') or '-')
        plan = str(r.get('plan_state') or r.get('structure_plan_state') or '-')
        q = str(r.get('quality_route_v810') or r.get('quality_bucket_v810') or r.get('quality_route') or '-')
        sample.append(f"- {t} {grade} / 진입 {entry:g} / 손익 {pnl:+.2f}% / {strat} / 계획 {plan} / 품질 {q}")
    if len(rows) > len(sample):
        sample.append(f"- 외 {len(rows)-len(sample)}개는 paper OPEN cache 상세")
    return lines + (sample or ['- OPEN 코인: 읽을 수 없음'])


def _v820_pstatus_text() -> str:
    st = _v650_status() if '_v650_status' in globals() else {}
    score = _v650_score() if '_v650_score' in globals() else {}
    review = _v650_review() if '_v650_review' in globals() else {}
    src_counts = score.get('closed_source_counts') if isinstance(score.get('closed_source_counts'), dict) else {}
    closed_total = score.get('closed_total') or score.get('total_closed_count') or score.get('ledger_closed_count') or score.get('closed_ledger_count') or src_counts.get('ledger') or '-'
    lines = ['🧪 페이퍼 매매 상태 /pstatus · v820']
    lines += _v799_section('① 현재 OPEN 코인') + _v820_open_position_lines(8)
    lines += _v799_section('② paper 상태') + [
        f"- paper: {st.get('version','-')} / build {st.get('build','-')}",
        f"- OPEN {_v650_open_count() if '_v650_open_count' in globals() else '-'} / CLOSED누적 {closed_total} / status age {_v650_file_age(FILES.get('paper_status', BASE_DIR/'paper_bot_status.json')):.1f}s",
        f"- score/review 오늘: {score.get('today_closed_count','-')} / {review.get('today_closed_count','-')}",
    ]
    lines += _v799_section('③ S1 hold → paper 소비') + _v743_s1_hold_lines() + _v799_paper_hold_trace_lines()
    since_ts = _v798_batch_marker_ts() if '_v798_batch_marker_ts' in globals() else 0.0
    lines += _v799_section('④ 이전 요약 이후 매매') + _v809_recent_trade_short_lines(since_ts)
    lines += _v799_section('⑤ 최근 CLOSED') + _v650_closed_source_lines(5)
    return '\n'.join(str(x) for x in lines)


def _v820_structure_short_lines() -> List[str]:
    lines = _v812_structure_short_lines()
    try:
        stage_counts, setup_counts, role_counts, samples = _v812_structure_board_counts()
        s1 = int(stage_counts.get('S1') or 0)
        if s1 > 50:
            lines.append(f'- ⚠️ S1 과다: {s1}개 · v820 S1 gate 반영/strategy 재시작 확인 필요')
        else:
            lines.append(f'- S1 gate: v820 구조좋음+생존위험통과+실행비용/trigger 정상+flow_trap 없음 기준')
    except Exception as exc:
        try: log_error('v820_structure_short_lines', exc)
        except Exception: pass
    return lines


def _v820_structure_board_text() -> str:
    lines = ['📊 구조판 /structure_board · v820', '- 기준: strategy가 candidate canonical row에 봉인한 structure_board. main 재계산 없음.']
    lines += _v820_structure_short_lines()
    return '\n'.join(str(x) for x in lines)


def _v820_batch_text(outputs: Optional[Dict[str,str]] = None, timings: Optional[List[Dict[str,Any]]] = None) -> str:
    since_ts = _v798_batch_marker_ts() if '_v798_batch_marker_ts' in globals() else 0.0
    lines = ['📊 코인봇 운영요약 /batch · v820']
    lines += ['① 적용/성과'] + _v809_apply_short_lines()[:3] + _v811_score_short_lines()[:3]
    lines += ['② 후보/구조'] + _v809_candidate_short_lines()[:3] + _v820_structure_short_lines()[:3]
    lines += ['③ paper/보류'] + [f"- OPEN {_v650_open_count() if '_v650_open_count' in globals() else '-'}"] + _v810_preopen_review_lines(3)[:3] + _v809_recent_trade_short_lines(since_ts)[:2]
    lines += ['④ 다음', '- 자세한 OPEN/paper 소비는 /pstatus', '- worker/자원은 /health', '- 구조 상세는 /structure_board', '- 품질은 /quality_board']
    return '\n'.join(str(x) for x in lines)


def _v820_select_batch_cmds(raw_args: Any) -> List[str]:
    args = [str(x).strip().lstrip('/') for x in (raw_args or []) if str(x).strip()]
    return args[:12] if args else ['batch']


def _v820_batch_summary_text(cmds: List[str], outputs: Dict[str,str], timings: List[Dict[str,Any]], recv_delay: float, total_sec: float, chat_body: str = '') -> str:
    global _V797_PENDING_BATCH_MARKER_TS
    batch_until = now_ts(); _V797_PENDING_BATCH_MARKER_TS = batch_until
    since_ts = _v798_batch_marker_ts() if '_v798_batch_marker_ts' in globals() else 0.0
    lines=['코인봇 묶음 요약집 v820', f'- 생성: {_v800_kst_text(batch_until)}', f'- 메인봇: {BOT_VERSION} / {V650_BUILD_LABEL}', f'- 접수지연: {recv_delay:.2f}s / 처리합계: {total_sec:.2f}s', '', '[명령 처리시간]']
    for t in timings:
        lines.append(f"- {'✅' if not t.get('error') else '❌'} /{t.get('name','?')}: {float(t.get('sec') or 0):.2f}s / {'OK' if not t.get('error') else 'ERR'}")
    lines += ['', '[채팅 핵심요약]', _v650_safe_body(chat_body or _v820_batch_text(outputs, timings), 5200), '']
    lines += ['', '[명령별 짧은 요약]'] + _v817_command_summary_lines(outputs, timings, cmds)
    lines += ['', '[전체 상세 요약]', _v650_safe_body(_v807_batch_text(), 9000), '']
    lines += ['', '[구조판 상세]'] + _v820_structure_short_lines()
    lines += _v799_trade_detail_lines_range(since_ts, batch_until)
    lines += ['', '[통합 검증판 상세]'] + _v807_integrated_validation_lines(since_ts, batch_until, compact=False)
    lines += ['', '[가격반응 지연·체결착시 품질판 상세]'] + _v807_price_lag_quality_lines(10) + _v810_quality_route_lines()
    lines += ['', '[OPEN직전 보류 사후검증]'] + _v810_preopen_review_lines(10)
    lines += ['', '[아까운 후보 / 놓친 후보 상세]'] + _v805_missed_summary_lines(10)
    lines += ['', '[명령별 상세]']
    for name in cmds:
        lines += ['', f'/{name}', _v650_safe_body(outputs.get(name,''), 5200)]
    return '\n'.join(str(x) for x in lines)


COMMANDS['batch'] = _v820_batch_text
COMMANDS['summary'] = _v820_batch_text
COMMANDS['pbatch'] = _v820_batch_text
COMMANDS['structure_board'] = _v820_structure_board_text
COMMANDS['structure'] = _v820_structure_board_text
COMMANDS['pstatus'] = _v820_pstatus_text
COMMANDS['status'] = _v820_pstatus_text
COMMANDS['trade'] = _v820_pstatus_text


def batch_handler(update, context):  # type: ignore[override]
    try:
        msg_date=getattr(getattr(update,'message',None),'date',None)
        recv_delay=time.time()-msg_date.timestamp() if hasattr(msg_date,'timestamp') else 0.0
    except Exception:
        recv_delay=0.0
    cmds = _v820_select_batch_cmds(getattr(context,'args',None) or [])
    stime=time.time(); timings=[]; outputs={}
    _v811_begin_batch_source_lock()
    try:
        multi = len(cmds) > 1
        if multi:
            try: send(update, f'📊 묶음 시작 · {len(cmds)}개 명령 / 각 명령 짧은요약 + 상세txt · 지연 {recv_delay:.2f}s')
            except Exception: pass
        total_cmds=len(cmds)
        for idx, name in enumerate(cmds, start=1):
            fn=COMMANDS.get(name); t0=time.time(); err=None
            if not fn:
                body=f'❌ /{name} 연결 없음'; err='no_handler'
            else:
                try: body=fn()
                except Exception as exc:
                    body=f'❌ /{name} 오류 {exc.__class__.__name__}: {exc}'; err=f'{exc.__class__.__name__}: {exc}'; log_error(f'v820_batch_{name}', exc)
            sec=time.time()-t0
            timings.append({'name':name,'sec':sec,'error':err}); outputs[name]=body
            try:
                if multi:
                    send(update, _v817_command_short_block(idx, total_cmds, name, body, sec, err))
                else:
                    send(update, body)
            except Exception as exc: log_error('v820_batch_send', exc)
        total=time.time()-stime
        chat_body = outputs.get(cmds[0], '') if len(cmds) == 1 else _v820_batch_text(outputs, timings)
        try:
            status=_v650_send_summary_file(update, _v820_batch_summary_text(cmds, outputs, timings, recv_delay, total, chat_body=chat_body))
        except Exception as exc:
            status=f'txt 생성실패 {exc.__class__.__name__}'; log_error('v820_batch_summary_file', exc)
        mark='✅' if '전송완료' in status else '⚠️'; del_mark='✅' if '서버삭제' in status else ('❌' if '전송완료' in status else '❔')
        try: send(update, f'📎 txt {mark} / 삭제 {del_mark} / {total:.2f}s')
        except Exception: pass
    finally:
        _v811_end_batch_source_lock()

# END v820 command-owned output


# =============================================================================
# main_bot v2.13.821: fast candidate snapshot reader + publish-age truth
# - Main no longer parses huge paper_candidates_latest.jsonl for default commands.
# - Reads versionless clean_candidate_latest_snapshot.json written by strategy.
# - /structure_board reads clean_structure_board_publish_status.json first.
# - Conditions/S1/S2/S3/exit/BUY_READY/auto-buy/paper ledgers unchanged.
# =============================================================================
V650_BUILD_LABEL = 'candidate_snapshot_lite_publish_age_v821_2026-06-10'
BOT_VERSION = '수익형 v2.13.821'
MAIN_BOT_VERSION = BOT_VERSION
CANDIDATE_LITE_SNAPSHOT_V821 = BASE_DIR / 'clean_candidate_latest_snapshot.json'
STRUCTURE_BOARD_STATUS_V821 = BASE_DIR / 'clean_structure_board_publish_status.json'


def _v821_jsonl_tail_fast(path: Path, limit: int = 200, max_bytes: int = 8 * 1024 * 1024) -> List[Dict[str, Any]]:
    """Read only the tail bytes of a JSONL file.

    This is for samples/diagnostics only. Default commands must use the compact
    strategy snapshot and must not parse a 100MB+ candidate latest file.
    """
    rows: List[Dict[str, Any]] = []
    try:
        if not path.exists() or limit <= 0:
            return []
        size = path.stat().st_size
        with path.open('rb') as f:
            seek = max(0, size - int(max_bytes))
            f.seek(seek)
            data = f.read()
        txt = data.decode('utf-8', errors='ignore')
        lines = txt.splitlines()
        if seek > 0 and lines:
            lines = lines[1:]  # first line may be partial
        for ln in lines[-int(limit):]:
            try:
                if not ln.strip():
                    continue
                obj = json.loads(ln)
                if isinstance(obj, dict):
                    rows.append(obj)
            except Exception:
                continue
    except Exception as exc:
        try: log_error('v821_jsonl_tail_fast', exc)
        except Exception: pass
    return rows


def _v763_jsonl_tail(path: Path, limit: int = 200) -> List[Dict[str, Any]]:  # type: ignore[override]
    return _v821_jsonl_tail_fast(path, limit=limit, max_bytes=8 * 1024 * 1024)


def _v650_read_candidate_rows(limit: int = 5000) -> List[Dict[str, Any]]:  # type: ignore[override]
    """Fast candidate rows for display boards.

    Prefer strategy's compact candidate snapshot. Full paper_candidates_latest is
    paper/strategy canonical storage, not a main command read target.
    """
    try:
        obj = _v650_load(CANDIDATE_LITE_SNAPSHOT_V821, {}) or {}
        rows = obj.get('rows_lite') or obj.get('rows')
        if isinstance(rows, list) and rows:
            out = [r for r in rows if isinstance(r, dict)]
            return out[-int(limit):] if len(out) > int(limit) else out
    except Exception as exc:
        try: log_error('v821_read_candidate_lite', exc)
        except Exception: pass
    # Fallback is bounded tail bytes, not full-file parse.
    return _v821_jsonl_tail_fast(FILES.get('paper_latest', BASE_DIR / 'paper_candidates_latest.jsonl'), limit=min(int(limit or 800), 800), max_bytes=12 * 1024 * 1024)


def _v821_lite_age(obj: Dict[str, Any]) -> float:
    try:
        ts = float(obj.get('updated_ts') or obj.get('latest_publish_ts') or 0.0)
        if ts > 0:
            return max(0.0, now_ts() - ts)
    except Exception:
        pass
    return _v650_file_age(CANDIDATE_LITE_SNAPSHOT_V821)


def _v650_candidate_snapshot() -> Dict[str, Any]:  # type: ignore[override]
    try:
        c = _V782_CANDIDATE_SNAPSHOT_CACHE
        if isinstance(c.get('snap'), dict) and now_ts() - float(c.get('ts') or 0.0) <= 5.0:
            return c['snap']
    except Exception:
        pass

    lite_obj: Dict[str, Any] = {}
    try:
        lite_obj = _v650_load(CANDIDATE_LITE_SNAPSHOT_V821, {}) or {}
        if not isinstance(lite_obj, dict):
            lite_obj = {}
    except Exception:
        lite_obj = {}
    rows = _v650_read_candidate_rows()

    def _lane(r: Dict[str, Any]) -> str:
        return str(r.get('canonical_lane') or r.get('lane') or r.get('source_lane') or r.get('strategy_lane') or '').lower()

    def _is_trade_candidate(r: Dict[str, Any]) -> bool:
        if r.get('trade_candidate_row_v661') is True or r.get('paper_candidate_row') is True:
            return True
        if r.get('paper_experiment_open') is True or r.get('paper_bot_open') is True:
            return True
        lane = _lane(r)
        if lane in ('coverage', 'raw', 'market', 'scanner_only', 'coverage_light'):
            return False
        sk = str(r.get('strategy_key') or r.get('strategy') or '')
        if 'coverage' in sk or r.get('v661_coverage_reason'):
            return False
        return _v650_stage(r) in ('S1', 'S2')

    trade_rows = [r for r in rows if isinstance(r, dict) and _is_trade_candidate(r)]
    coverage_rows = [r for r in rows if isinstance(r, dict) and not _is_trade_candidate(r)]

    def _counter_from(obj: Any) -> Counter:
        if isinstance(obj, Counter):
            return obj
        if isinstance(obj, dict):
            return Counter({str(k): int(v or 0) for k, v in obj.items()})
        return Counter()

    stage = _counter_from(lite_obj.get('stage_counts') or lite_obj.get('trade_stage_counts'))
    all_stage = _counter_from(lite_obj.get('all_stage_counts'))
    mats = _counter_from(lite_obj.get('materials'))
    reasons = _counter_from(lite_obj.get('reason_top'))
    risks = _counter_from(lite_obj.get('risk_top'))

    if not stage:
        stage = Counter(_v650_stage(r) for r in trade_rows)
    if not all_stage:
        all_stage = Counter(_v650_stage(r) for r in rows)
    if not mats or not reasons or not risks:
        for r in rows:
            if not mats:
                p = _v650_price_1m(r)
                if p['ready']:
                    mats['1분가격 정상'] += 1
                    if p['chg'] <= 0: mats['1분반응 0/음수'] += 1
                    elif p['chg'] >= 0.35: mats['1분반응 통과'] += 1
                    else: mats['1분반응 부족'] += 1
                else:
                    mats['1분가격 없음'] += 1
            if not reasons:
                for x in _v650_reasons(r): reasons[x] += 1
            if not risks:
                for x in _v650_risks(r): risks[x] += 1

    stale_all = stale_trade = stale_s12 = stale_coverage = 0
    for r in rows:
        is_trade = _is_trade_candidate(r)
        age_val = _v650_num(r.get('age'), r.get('source_age'), r.get('fresh_age'), r.get('candle_age'), default=0.0)
        stale_flag = age_val >= 120 or any('stale' in x.lower() or '오래' in x for x in _v650_reasons(r)+_v650_risks(r))
        if stale_flag:
            stale_all += 1
            if is_trade:
                stale_trade += 1
                if _v650_stage(r) in ('S1','S2'):
                    stale_s12 += 1
            else:
                stale_coverage += 1

    trade_count = _v650_int(lite_obj.get('trade_count'), default=len(trade_rows)) if '_v650_int' in globals() else len(trade_rows)
    coverage_count = _v650_int(lite_obj.get('coverage_count'), default=len(coverage_rows)) if '_v650_int' in globals() else len(coverage_rows)
    # Keep real lite rows for samples; keep virtual lengths only in metadata.
    snap = {
        'rows': rows,
        'trade_rows': trade_rows,
        'coverage_rows': coverage_rows,
        'counts': stage,
        'all_counts': all_stage,
        'reasons': reasons,
        'risks': risks,
        'materials': mats,
        'stale': stale_all,
        'stale_all': stale_all,
        'stale_trade': stale_trade,
        'stale_s12': stale_s12,
        'stale_coverage': stale_coverage,
        'file_age': _v821_lite_age(lite_obj) if lite_obj else _v650_file_age(FILES.get('paper_latest', BASE_DIR/'paper_candidates_latest.jsonl')),
        'source_age_v821': _v821_lite_age(lite_obj) if lite_obj else _v650_file_age(FILES.get('paper_latest', BASE_DIR/'paper_candidates_latest.jsonl')),
        'snapshot_source_v821': 'clean_candidate_latest_snapshot.json' if lite_obj else 'bounded_tail_fallback',
        'full_file_age_v821': _v650_file_age(FILES.get('paper_latest', BASE_DIR/'paper_candidates_latest.jsonl')),
        'trade_count_v821': trade_count,
        'coverage_count_v821': coverage_count,
        'scope_policy_v682': '전체시장 rows는 coverage/raw로 분리 표시하고, S1/S2/S3 후보 count는 trade_candidate rows 기준으로 표시한다.',
    }
    try:
        _V782_CANDIDATE_SNAPSHOT_CACHE['ts'] = now_ts()
        _V782_CANDIDATE_SNAPSHOT_CACHE['snap'] = snap
    except Exception:
        pass
    return snap


def _v783_candidate_unified_lines() -> List[str]:  # type: ignore[override]
    snap = _v650_candidate_snapshot()
    c = snap.get('counts') if isinstance(snap.get('counts'), Counter) else Counter(snap.get('counts') or {})
    all_c = snap.get('all_counts') if isinstance(snap.get('all_counts'), Counter) else Counter(snap.get('all_counts') or {})
    trade = int(snap.get('trade_count_v821') or len(snap.get('trade_rows') or []))
    cov = int(snap.get('coverage_count_v821') or len(snap.get('coverage_rows') or []))
    age = float(snap.get('source_age_v821') if snap.get('source_age_v821') is not None else snap.get('file_age') or 0.0)
    src = str(snap.get('snapshot_source_v821') or 'candidate_snapshot')
    return [
        f"- 후보 snapshot: S1 {int(c.get('S1',0))} / S2 {int(c.get('S2',0))} / S3 {int(c.get('S3',0))} / 실전후보 {trade} / coverage {cov} / raw S3 {int(all_c.get('S3',0))} / age {age:.1f}s",
        f"- 기준: strategy compact snapshot 우선({src}). 기본 명령은 paper_candidates_latest.jsonl 전체파싱 금지.",
    ]


def _v812_structure_board_counts() -> Tuple[Counter, Counter, Counter, List[str]]:  # type: ignore[override]
    try:
        obj = _v650_load(STRUCTURE_BOARD_STATUS_V821, {}) or {}
        if isinstance(obj, dict) and obj:
            stage_counts = Counter({str(k): int(v or 0) for k, v in (obj.get('stage_counts') or {}).items()})
            setup_counts = Counter({str(k): int(v or 0) for k, v in (obj.get('setup_type_top') or obj.get('setup_counts') or {}).items()})
            role_counts = Counter({str(k): int(v or 0) for k, v in (obj.get('role_top') or obj.get('role_counts') or {}).items()})
            samples: List[str] = []
            for s in obj.get('samples') or []:
                if not isinstance(s, dict):
                    continue
                samples.append(f"{s.get('ticker','-')} {s.get('stage','-')}/{s.get('setup','-')}/{s.get('role','-')} · {s.get('reason','-')}")
                if len(samples) >= 8:
                    break
            if stage_counts or setup_counts:
                return stage_counts, setup_counts, role_counts, samples
    except Exception as exc:
        try: log_error('v821_structure_status_counts', exc)
        except Exception: pass
    # bounded fallback from compact rows, not full JSONL.
    stage_counts: Counter = Counter(); setup_counts: Counter = Counter(); role_counts: Counter = Counter(); samples: List[str] = []
    try:
        snap = _v650_candidate_snapshot()
        rows = [r for r in (snap.get('trade_rows') or []) if isinstance(r, dict)]
        for r in rows:
            b = r.get('structure_board_v812') if isinstance(r.get('structure_board_v812'), dict) else (r.get('structure_board') if isinstance(r.get('structure_board'), dict) else {})
            if not b:
                continue
            st = _v650_stage(r); setup = str(b.get('setup_type') or '-'); role = str(b.get('role') or '-')
            stage_counts[st] += 1; setup_counts[setup] += 1; role_counts[role] += 1
            if len(samples) < 8 and st in ('S1','S2'):
                reason = ' / '.join(str(x) for x in (b.get('stage_reasons') or [])[:2])
                samples.append(f"{_v650_ticker(r)} {st}/{setup}/{role} · {reason}")
    except Exception as exc:
        try: log_error('v821_structure_fallback_counts', exc)
        except Exception: pass
    return stage_counts, setup_counts, role_counts, samples


def _v787_recheck_freshness_base_lines() -> List[str]:  # type: ignore[override]
    sw = worker_status('strategy')
    tw = worker_status('target_router')
    snap = _v650_candidate_snapshot()
    cand_age = float(snap.get('source_age_v821') if snap.get('source_age_v821') is not None else snap.get('file_age') or 999999.0)
    full_age = float(snap.get('full_file_age_v821') or _v650_file_age(FILES.get('paper_latest', BASE_DIR/'paper_candidates_latest.jsonl')))
    structure_age = _v650_file_age(STRUCTURE_BOARD_STATUS_V821)
    queue_age = _v650_file_age(BASE_DIR/'clean_structure_observation_queue_v774.json')
    hand_age = _v650_file_age(FILES.get('paper_handoff', BASE_DIR/'clean_strategy_paper_handoff_status.json'))
    latest_publish_age = sw.get('latest_publish_age_sec_v821') if isinstance(sw, dict) else None
    try: latest_publish_age = float(latest_publish_age)
    except Exception: latest_publish_age = cand_age
    warn = []
    if float(sw.get('age') or 999999) >= 60: warn.append('strategy status 60초+ 지연')
    if latest_publish_age >= 60: warn.append('candidate publish 60초+ 지연')
    if cand_age >= 60: warn.append('compact snapshot 60초+ 지연')
    if structure_age >= 60: warn.append('structure_board status 60초+ 지연')
    if hand_age >= 60: warn.append('paper handoff 60초+ 지연')
    icon = '⚠️' if warn else '✅'
    return [
        f"{icon} 재확인 배관: strategy status {float(sw.get('age') or 0):.1f}s/rows {sw.get('row_count','-')} · publish {latest_publish_age:.1f}s · compact {cand_age:.1f}s · latest파일 {full_age:.1f}s · structure {structure_age:.1f}s · queue {queue_age:.1f}s · target_router {float(tw.get('age') or 0):.1f}s · handoff {hand_age:.1f}s",
        '- 판정: ' + (' / '.join(warn) if warn else '재확인 캐시 최신권'),
    ]


def _v821_structure_short_lines() -> List[str]:
    lines = _v812_structure_short_lines()
    try:
        stage_counts, _, _, _ = _v812_structure_board_counts()
        s1 = int(stage_counts.get('S1') or 0)
        if s1 > 50:
            lines.append(f'- ⚠️ S1 과다: {s1}개 · v820/v821 S1 gate 반영/strategy 재시작 확인 필요')
        else:
            lines.append('- S1 gate: 구조좋음+생존위험통과+실행비용/trigger 정상+flow_trap 없음 기준')
    except Exception as exc:
        try: log_error('v821_structure_short_lines', exc)
        except Exception: pass
    return lines


def _v821_structure_board_text() -> str:
    lines = ['📊 구조판 /structure_board · v821', '- 기준: strategy가 candidate canonical row에 봉인한 structure_board status. main 재계산 없음.']
    lines += _v821_structure_short_lines()
    return '\n'.join(str(x) for x in lines)


def _v821_pstatus_text() -> str:
    return _v820_pstatus_text().replace('/pstatus · v820', '/pstatus · v821')


def _v821_batch_text(outputs: Optional[Dict[str,str]] = None, timings: Optional[List[Dict[str,Any]]] = None) -> str:
    since_ts = _v798_batch_marker_ts() if '_v798_batch_marker_ts' in globals() else 0.0
    lines = ['📊 코인봇 운영요약 /batch · v821']
    lines += ['① 적용/성과'] + _v809_apply_short_lines()[:3] + _v811_score_short_lines()[:3]
    lines += ['② 후보/구조'] + _v809_candidate_short_lines()[:3] + _v821_structure_short_lines()[:3]
    lines += ['③ paper/보류'] + [f"- OPEN {_v650_open_count() if '_v650_open_count' in globals() else '-'}"] + _v810_preopen_review_lines(3)[:3] + _v809_recent_trade_short_lines(since_ts)[:2]
    lines += ['④ 다음', '- 자세한 OPEN/paper 소비는 /pstatus', '- worker/자원은 /health', '- 구조 상세는 /structure_board', '- 품질은 /quality_board']
    return '\n'.join(str(x) for x in lines)


def _v821_batch_summary_text(cmds: List[str], outputs: Dict[str,str], timings: List[Dict[str,Any]], recv_delay: float, total_sec: float, chat_body: str = '') -> str:
    global _V797_PENDING_BATCH_MARKER_TS
    batch_until = now_ts(); _V797_PENDING_BATCH_MARKER_TS = batch_until
    since_ts = _v798_batch_marker_ts() if '_v798_batch_marker_ts' in globals() else 0.0
    lines=['코인봇 묶음 요약집 v821', f'- 생성: {_v800_kst_text(batch_until)}', f'- 메인봇: {BOT_VERSION} / {V650_BUILD_LABEL}', f'- 접수지연: {recv_delay:.2f}s / 처리합계: {total_sec:.2f}s', '', '[명령 처리시간]']
    for t in timings:
        lines.append(f"- {'✅' if not t.get('error') else '❌'} /{t.get('name','?')}: {float(t.get('sec') or 0):.2f}s / {'OK' if not t.get('error') else 'ERR'}")
    lines += ['', '[채팅 핵심요약]', _v650_safe_body(chat_body or _v821_batch_text(outputs, timings), 5200), '']
    lines += ['', '[명령별 짧은 요약]'] + _v817_command_summary_lines(outputs, timings, cmds)
    lines += ['', '[전체 상세 요약]', _v650_safe_body(_v807_batch_text(), 9000), '']
    lines += ['', '[구조판 상세]'] + _v821_structure_short_lines()
    lines += _v799_trade_detail_lines_range(since_ts, batch_until)
    lines += ['', '[통합 검증판 상세]'] + _v807_integrated_validation_lines(since_ts, batch_until, compact=False)
    lines += ['', '[가격반응 지연·체결착시 품질판 상세]'] + _v807_price_lag_quality_lines(10) + _v810_quality_route_lines()
    lines += ['', '[OPEN직전 보류 사후검증]'] + _v810_preopen_review_lines(10)
    lines += ['', '[아까운 후보 / 놓친 후보 상세]'] + _v805_missed_summary_lines(10)
    lines += ['', '[명령별 상세]']
    for name in cmds:
        lines += ['', f'/{name}', _v650_safe_body(outputs.get(name,''), 5200)]
    return '\n'.join(str(x) for x in lines)


COMMANDS['batch'] = _v821_batch_text
COMMANDS['summary'] = _v821_batch_text
COMMANDS['pbatch'] = _v821_batch_text
COMMANDS['structure_board'] = _v821_structure_board_text
COMMANDS['structure'] = _v821_structure_board_text
COMMANDS['pstatus'] = _v821_pstatus_text
COMMANDS['status'] = _v821_pstatus_text
COMMANDS['trade'] = _v821_pstatus_text


def batch_handler(update, context):  # type: ignore[override]
    try:
        msg_date=getattr(getattr(update,'message',None),'date',None)
        recv_delay=time.time()-msg_date.timestamp() if hasattr(msg_date,'timestamp') else 0.0
    except Exception:
        recv_delay=0.0
    cmds = _v820_select_batch_cmds(getattr(context,'args',None) or [])
    stime=time.time(); timings=[]; outputs={}
    _v811_begin_batch_source_lock()
    try:
        multi = len(cmds) > 1
        if multi:
            try: send(update, f'📊 묶음 시작 · {len(cmds)}개 명령 / 각 명령 짧은요약 + 상세txt · 지연 {recv_delay:.2f}s')
            except Exception: pass
        total_cmds=len(cmds)
        for idx, name in enumerate(cmds, start=1):
            fn=COMMANDS.get(name); t0=time.time(); err=None
            if not fn:
                body=f'❌ /{name} 연결 없음'; err='no_handler'
            else:
                try: body=fn()
                except Exception as exc:
                    body=f'❌ /{name} 오류 {exc.__class__.__name__}: {exc}'; err=f'{exc.__class__.__name__}: {exc}'; log_error(f'v821_batch_{name}', exc)
            sec=time.time()-t0
            timings.append({'name':name,'sec':sec,'error':err}); outputs[name]=body
            try:
                if multi:
                    send(update, _v817_command_short_block(idx, total_cmds, name, body, sec, err))
                else:
                    send(update, body)
            except Exception as exc: log_error('v821_batch_send', exc)
        total=time.time()-stime
        chat_body = outputs.get(cmds[0], '') if len(cmds) == 1 else _v821_batch_text(outputs, timings)
        try:
            status=_v650_send_summary_file(update, _v821_batch_summary_text(cmds, outputs, timings, recv_delay, total, chat_body=chat_body))
        except Exception as exc:
            status=f'txt 생성실패 {exc.__class__.__name__}'; log_error('v821_batch_summary_file', exc)
        mark='✅' if '전송완료' in status else '⚠️'; del_mark='✅' if '서버삭제' in status else ('❌' if '전송완료' in status else '❔')
        try: send(update, f'📎 txt {mark} / 삭제 {del_mark} / {total:.2f}s')
        except Exception: pass
    finally:
        _v811_end_batch_source_lock()

# END v821 fast candidate snapshot reader


# =============================================================================
# main_bot v2.13.822: structure scope split + recheck trace compact reader
# - Does not change strategy thresholds, exits, BUY_READY, auto-buy, or ledgers.
# - /structure_board separates trade-candidate scope from all strategy rows.
# - Recheck freshness uses compact rows with recheck_freshness_trace_v806.
# =============================================================================
V650_BUILD_LABEL = 'structure_scope_recheck_trace_v822_2026-06-11'
BOT_VERSION = '수익형 v2.13.822'
MAIN_BOT_VERSION = BOT_VERSION


def _v822_counter_from_obj(obj: Any, key: str) -> Counter:
    try:
        v = obj.get(key) if isinstance(obj, dict) else {}
        if isinstance(v, dict):
            return Counter({str(k): int(val or 0) for k, val in v.items()})
    except Exception:
        pass
    return Counter()


def _v822_structure_status_obj() -> Dict[str, Any]:
    try:
        obj = _v650_load(STRUCTURE_BOARD_STATUS_V821, {}) or {}
        return obj if isinstance(obj, dict) else {}
    except Exception as exc:
        try: log_error('v822_structure_status_load', exc)
        except Exception: pass
        return {}


def _v822_structure_scope_counts() -> Tuple[Counter, Counter, Counter, Counter, Counter, Counter, List[str]]:
    """Return trade-stage/setup/role and all-stage/setup/role, plus samples."""
    obj = _v822_structure_status_obj()
    trade_stage = _v822_counter_from_obj(obj, 'trade_stage_counts') or _v822_counter_from_obj(obj, 'candidate_stage_counts')
    trade_setup = _v822_counter_from_obj(obj, 'trade_setup_type_top') or _v822_counter_from_obj(obj, 'trade_setup_counts')
    trade_role = _v822_counter_from_obj(obj, 'trade_role_top') or _v822_counter_from_obj(obj, 'trade_role_counts')
    all_stage = _v822_counter_from_obj(obj, 'all_stage_counts') or _v822_counter_from_obj(obj, 'stage_counts')
    all_setup = _v822_counter_from_obj(obj, 'all_setup_type_top') or _v822_counter_from_obj(obj, 'setup_type_top') or _v822_counter_from_obj(obj, 'setup_counts')
    all_role = _v822_counter_from_obj(obj, 'all_role_top') or _v822_counter_from_obj(obj, 'role_top') or _v822_counter_from_obj(obj, 'role_counts')
    samples: List[str] = []
    try:
        for s in obj.get('trade_samples') or obj.get('samples') or []:
            if not isinstance(s, dict):
                continue
            samples.append(f"{s.get('ticker','-')} {s.get('stage','-')}/{s.get('setup','-')}/{s.get('role','-')} · {s.get('reason','-')}")
            if len(samples) >= 8:
                break
    except Exception:
        pass
    # fallback from compact snapshot trade_rows when v822 status has not been produced yet
    if not trade_stage:
        try:
            snap = _v650_candidate_snapshot()
            rows = [r for r in (snap.get('trade_rows') or []) if isinstance(r, dict)]
            for r in rows:
                b = r.get('structure_board_v812') if isinstance(r.get('structure_board_v812'), dict) else (r.get('structure_board') if isinstance(r.get('structure_board'), dict) else {})
                if not b:
                    continue
                st = _v650_stage(r); setup = str(b.get('setup_type') or '-'); role = str(b.get('role') or '-')
                trade_stage[st] += 1; trade_setup[setup] += 1; trade_role[role] += 1
                if len(samples) < 8 and st in ('S1','S2'):
                    reason = ' / '.join(str(x) for x in (b.get('stage_reasons') or [])[:2])
                    samples.append(f"{_v650_ticker(r)} {st}/{setup}/{role} · {reason}")
        except Exception as exc:
            try: log_error('v822_structure_scope_fallback', exc)
            except Exception: pass
    return trade_stage, trade_setup, trade_role, all_stage, all_setup, all_role, samples


def _v812_structure_short_lines() -> List[str]:  # type: ignore[override]
    trade_stage, trade_setup, trade_role, all_stage, all_setup, all_role, samples = _v822_structure_scope_counts()
    if not trade_stage and not all_stage and not trade_setup and not all_setup:
        return ['- 구조판: 아직 structure status 없음']
    trade_total = sum(int(v or 0) for v in trade_stage.values())
    all_total = sum(int(v or 0) for v in all_stage.values())
    lines = [
        '- 구조판 실전후보: ' + (_v799_counter_line(trade_stage, 4) if trade_stage else '없음') + (f' / 합계 {trade_total}' if trade_total else ''),
        '- 구조판 전체전략: ' + (_v799_counter_line(all_stage, 4) if all_stage else '없음') + (f' / 합계 {all_total}' if all_total else ''),
        '- 구조타입(실전후보) TOP: ' + (_v799_counter_line(trade_setup, 5) if trade_setup else '없음'),
        '- 구조역할(실전후보) TOP: ' + (_v799_counter_line(trade_role, 5) if trade_role else '없음'),
    ]
    if all_setup and all_setup != trade_setup:
        lines.append('- 구조타입(전체전략) TOP: ' + _v799_counter_line(all_setup, 5))
    if samples:
        lines.append('- 구조 샘플: ' + ' / '.join(samples[:3]))
    return lines


def _v821_structure_short_lines() -> List[str]:  # type: ignore[override]
    lines = _v812_structure_short_lines()
    try:
        trade_stage, _, _, _, _, _, _ = _v822_structure_scope_counts()
        s1 = int(trade_stage.get('S1') or 0)
        if s1 > 50:
            lines.append(f'- ⚠️ 실전후보 S1 과다: {s1}개 · S1 gate/worker 확인 필요')
        else:
            lines.append('- S1 gate: 구조좋음+생존위험통과+실행비용/trigger 정상+flow_trap 없음 기준')
    except Exception as exc:
        try: log_error('v822_structure_short_lines', exc)
        except Exception: pass
    return lines


def _v822_structure_board_text() -> str:
    lines = ['📊 구조판 /structure_board · v822', '- 기준: strategy structure status. 실전후보와 전체전략판단을 분리 표시. main 재계산 없음.']
    lines += _v821_structure_short_lines()
    return '\n'.join(str(x) for x in lines)


def _v822_pstatus_text() -> str:
    try:
        return _v820_pstatus_text().replace('/pstatus · v820', '/pstatus · v822')
    except Exception:
        return _v821_pstatus_text().replace('/pstatus · v821', '/pstatus · v822')


def _v822_batch_text(outputs: Optional[Dict[str,str]] = None, timings: Optional[List[Dict[str,Any]]] = None) -> str:
    since_ts = _v798_batch_marker_ts() if '_v798_batch_marker_ts' in globals() else 0.0
    lines = ['📊 코인봇 운영요약 /batch · v822']
    lines += ['① 적용/성과'] + _v809_apply_short_lines()[:3] + _v811_score_short_lines()[:3]
    lines += ['② 후보/구조'] + _v809_candidate_short_lines()[:3] + _v821_structure_short_lines()[:4]
    lines += ['③ paper/보류'] + [f"- OPEN {_v650_open_count() if '_v650_open_count' in globals() else '-'}"] + _v810_preopen_review_lines(3)[:3] + _v809_recent_trade_short_lines(since_ts)[:2]
    lines += ['④ 다음', '- 재확인 freshness는 /validation_board 또는 txt 상세', '- 자세한 OPEN/paper 소비는 /pstatus', '- worker/자원은 /health', '- 품질은 /quality_board']
    return '\n'.join(str(x) for x in lines)


def _v822_batch_summary_text(cmds: List[str], outputs: Dict[str,str], timings: List[Dict[str,Any]], recv_delay: float, total_sec: float, chat_body: str = '') -> str:
    global _V797_PENDING_BATCH_MARKER_TS
    batch_until = now_ts(); _V797_PENDING_BATCH_MARKER_TS = batch_until
    since_ts = _v798_batch_marker_ts() if '_v798_batch_marker_ts' in globals() else 0.0
    lines=['코인봇 묶음 요약집 v822', f'- 생성: {_v800_kst_text(batch_until)}', f'- 메인봇: {BOT_VERSION} / {V650_BUILD_LABEL}', f'- 접수지연: {recv_delay:.2f}s / 처리합계: {total_sec:.2f}s', '', '[명령 처리시간]']
    for t in timings:
        lines.append(f"- {'✅' if not t.get('error') else '❌'} /{t.get('name','?')}: {float(t.get('sec') or 0):.2f}s / {'OK' if not t.get('error') else 'ERR'}")
    lines += ['', '[채팅 핵심요약]', _v650_safe_body(chat_body or _v822_batch_text(outputs, timings), 5200), '']
    lines += ['', '[명령별 짧은 요약]'] + _v817_command_summary_lines(outputs, timings, cmds)
    lines += ['', '[전체 상세 요약]', _v650_safe_body(_v807_batch_text(), 9000), '']
    lines += ['', '[구조판 상세]'] + _v821_structure_short_lines()
    lines += _v799_trade_detail_lines_range(since_ts, batch_until)
    lines += ['', '[통합 검증판 상세]'] + _v807_integrated_validation_lines(since_ts, batch_until, compact=False)
    lines += ['', '[가격반응 지연·체결착시 품질판 상세]'] + _v807_price_lag_quality_lines(10) + _v810_quality_route_lines()
    lines += ['', '[OPEN직전 보류 사후검증]'] + _v810_preopen_review_lines(10)
    lines += ['', '[아까운 후보 / 놓친 후보 상세]'] + _v805_missed_summary_lines(10)
    lines += ['', '[명령별 상세]']
    for name in cmds:
        lines += ['', f'/{name}', _v650_safe_body(outputs.get(name,''), 5200)]
    return '\n'.join(str(x) for x in lines)


COMMANDS['batch'] = _v822_batch_text
COMMANDS['summary'] = _v822_batch_text
COMMANDS['pbatch'] = _v822_batch_text
COMMANDS['structure_board'] = _v822_structure_board_text
COMMANDS['structure'] = _v822_structure_board_text
COMMANDS['pstatus'] = _v822_pstatus_text
COMMANDS['status'] = _v822_pstatus_text
COMMANDS['trade'] = _v822_pstatus_text


def batch_handler(update, context):  # type: ignore[override]
    try:
        msg_date=getattr(getattr(update,'message',None),'date',None)
        recv_delay=time.time()-msg_date.timestamp() if hasattr(msg_date,'timestamp') else 0.0
    except Exception:
        recv_delay=0.0
    cmds = _v820_select_batch_cmds(getattr(context,'args',None) or [])
    stime=time.time(); timings=[]; outputs={}
    _v811_begin_batch_source_lock()
    try:
        multi = len(cmds) > 1
        if multi:
            try: send(update, f'📊 묶음 시작 · {len(cmds)}개 명령 / 각 명령 짧은요약 + 상세txt · 지연 {recv_delay:.2f}s')
            except Exception: pass
        total_cmds=len(cmds)
        for idx, name in enumerate(cmds, start=1):
            fn=COMMANDS.get(name); t0=time.time(); err=None
            if not fn:
                body=f'❌ /{name} 연결 없음'; err='no_handler'
            else:
                try: body=fn()
                except Exception as exc:
                    body=f'❌ /{name} 오류 {exc.__class__.__name__}: {exc}'; err=f'{exc.__class__.__name__}: {exc}'; log_error(f'v822_batch_{name}', exc)
            sec=time.time()-t0
            timings.append({'name':name,'sec':sec,'error':err}); outputs[name]=body
            try:
                if multi:
                    send(update, _v817_command_short_block(idx, total_cmds, name, body, sec, err))
                else:
                    send(update, body)
            except Exception as exc: log_error('v822_batch_send', exc)
        total=time.time()-stime
        chat_body = outputs.get(cmds[0], '') if len(cmds) == 1 else _v822_batch_text(outputs, timings)
        try:
            status=_v650_send_summary_file(update, _v822_batch_summary_text(cmds, outputs, timings, recv_delay, total, chat_body=chat_body))
        except Exception as exc:
            status=f'txt 생성실패 {exc.__class__.__name__}'; log_error('v822_batch_summary_file', exc)
        mark='✅' if '전송완료' in status else '⚠️'; del_mark='✅' if '서버삭제' in status else ('❌' if '전송완료' in status else '❔')
        try: send(update, f'📎 txt {mark} / 삭제 {del_mark} / {total:.2f}s')
        except Exception: pass
    finally:
        _v811_end_batch_source_lock()

# END v822 structure scope split + recheck trace compact reader


# =============================================================================
# main_bot v2.13.823: MTF structure spine display
# - main reads strategy structure status only; no recalculation.
# - Shows HTF(15m/30m/1h), MTF(3m/5m/15m), LTF(1m/orderflow) separately.
# - Does not change exits, auto-buy, ledgers, or thresholds in main.
# =============================================================================
V650_BUILD_LABEL = 'mtf_structure_spine_v823_2026-06-11'
BOT_VERSION = '수익형 v2.13.823'
MAIN_BOT_VERSION = BOT_VERSION


def _v823_counter_from_obj(obj: Any, key: str) -> Counter:
    try:
        v = obj.get(key) if isinstance(obj, dict) else {}
        if isinstance(v, dict):
            return Counter({str(k): int(val or 0) for k, val in v.items()})
    except Exception:
        pass
    return Counter()


def _v823_counter_line(c: Counter, n: int = 5) -> str:
    try:
        if '_v799_counter_line' in globals():
            return _v799_counter_line(c, n)
    except Exception:
        pass
    try:
        return ' / '.join(f'{k} {v}' for k, v in c.most_common(n)) or '없음'
    except Exception:
        return '없음'


def _v823_structure_status() -> Dict[str, Any]:
    try:
        obj = _v650_load(STRUCTURE_BOARD_STATUS_V821, {}) or {}
        return obj if isinstance(obj, dict) else {}
    except Exception as exc:
        try: log_error('v823_structure_status_load', exc)
        except Exception: pass
        return {}


def _v823_structure_short_lines() -> List[str]:
    obj = _v823_structure_status()
    if not obj:
        return ['- 구조판: strategy structure status 없음']
    trade_stage = _v823_counter_from_obj(obj, 'trade_stage_counts') or _v823_counter_from_obj(obj, 'candidate_stage_counts')
    all_stage = _v823_counter_from_obj(obj, 'all_stage_counts') or _v823_counter_from_obj(obj, 'stage_counts')
    trade_setup = _v823_counter_from_obj(obj, 'trade_setup_type_top') or _v823_counter_from_obj(obj, 'trade_setup_counts')
    trade_role = _v823_counter_from_obj(obj, 'trade_role_top') or _v823_counter_from_obj(obj, 'trade_role_counts')
    htf_trade = _v823_counter_from_obj(obj, 'trade_htf_state_counts')
    mtf_trade = _v823_counter_from_obj(obj, 'trade_mtf_state_counts')
    ltf_trade = _v823_counter_from_obj(obj, 'trade_ltf_state_counts')
    gate_blocks = _v823_counter_from_obj(obj, 'trade_mtf_s1_block_top')
    lines = [
        '- 구조판 실전후보: ' + (_v823_counter_line(trade_stage, 4) if trade_stage else '없음') + (f' / 합계 {sum(trade_stage.values())}' if trade_stage else ''),
        '- 구조판 전체전략: ' + (_v823_counter_line(all_stage, 4) if all_stage else '없음') + (f' / 합계 {sum(all_stage.values())}' if all_stage else ''),
        '- 상위구조(15m/30m/1h): ' + (_v823_counter_line(htf_trade, 5) if htf_trade else '미집계'),
        '- 중간setup(3m/5m/15m): ' + (_v823_counter_line(mtf_trade, 5) if mtf_trade else '미집계'),
        '- 진입trigger(1m/orderflow): ' + (_v823_counter_line(ltf_trade, 5) if ltf_trade else '미집계'),
        '- 구조타입(실전후보) TOP: ' + (_v823_counter_line(trade_setup, 5) if trade_setup else '없음'),
        '- 구조역할(실전후보) TOP: ' + (_v823_counter_line(trade_role, 5) if trade_role else '없음'),
    ]
    if gate_blocks:
        lines.append('- S1 보류 TOP: ' + _v823_counter_line(gate_blocks, 5))
    try:
        samples = obj.get('trade_samples') or obj.get('mtf_trade_samples') or obj.get('samples') or []
        out = []
        for s in samples:
            if not isinstance(s, dict):
                continue
            htf = s.get('htf') or '-'; mtf = s.get('mtf') or '-'; ltf = s.get('ltf') or '-'
            out.append(f"{s.get('ticker','-')} {s.get('stage','-')}/{s.get('setup','-')}/{s.get('role','-')} · HTF {htf} / MTF {mtf} / LTF {ltf} · {s.get('reason','-')}")
            if len(out) >= 3: break
        if out:
            lines.append('- 구조 샘플: ' + ' / '.join(out))
    except Exception:
        pass
    lines.append('- S1 gate: 15m/30m/1h 상위구조 + 3m/5m setup + 1m trigger 모두 확인. 1m 단독 S1 금지')
    return lines


def _v812_structure_short_lines() -> List[str]:  # type: ignore[override]
    return _v823_structure_short_lines()


def _v821_structure_short_lines() -> List[str]:  # type: ignore[override]
    return _v823_structure_short_lines()


def _v823_structure_board_text() -> str:
    lines = ['📊 구조판 /structure_board · v823', '- 기준: strategy MTF structure spine. main 재계산 없음.', '- 순서: 상위구조(15m/30m/1h) → 중간setup(3m/5m/15m) → 진입trigger(1m/orderflow)']
    lines += _v823_structure_short_lines()
    return '\n'.join(str(x) for x in lines)


def _v823_pstatus_text() -> str:
    try:
        return _v822_pstatus_text().replace('/pstatus · v822', '/pstatus · v823').replace('/pstatus · v820', '/pstatus · v823')
    except Exception:
        return _v820_pstatus_text().replace('/pstatus · v820', '/pstatus · v823')


def _v823_batch_text(outputs: Optional[Dict[str,str]] = None, timings: Optional[List[Dict[str,Any]]] = None) -> str:
    since_ts = _v798_batch_marker_ts() if '_v798_batch_marker_ts' in globals() else 0.0
    lines = ['📊 코인봇 운영요약 /batch · v823']
    lines += ['① 적용/성과'] + _v809_apply_short_lines()[:3] + _v811_score_short_lines()[:3]
    lines += ['② 후보/MTF구조'] + _v809_candidate_short_lines()[:3] + _v823_structure_short_lines()[:6]
    lines += ['③ paper/보류'] + [f"- OPEN {_v650_open_count() if '_v650_open_count' in globals() else '-'}"] + _v810_preopen_review_lines(3)[:3] + _v809_recent_trade_short_lines(since_ts)[:2]
    lines += ['④ 다음', '- 구조 상세는 /structure_board', '- 재확인 freshness는 /validation_board', '- OPEN/paper 소비는 /pstatus', '- worker/자원은 /health', '- 품질은 /quality_board']
    return '\n'.join(str(x) for x in lines)


def _v823_batch_summary_text(cmds: List[str], outputs: Dict[str,str], timings: List[Dict[str,Any]], recv_delay: float, total_sec: float, chat_body: str = '') -> str:
    global _V797_PENDING_BATCH_MARKER_TS
    batch_until = now_ts(); _V797_PENDING_BATCH_MARKER_TS = batch_until
    since_ts = _v798_batch_marker_ts() if '_v798_batch_marker_ts' in globals() else 0.0
    lines=['코인봇 묶음 요약집 v823', f'- 생성: {_v800_kst_text(batch_until)}', f'- 메인봇: {BOT_VERSION} / {V650_BUILD_LABEL}', f'- 접수지연: {recv_delay:.2f}s / 처리합계: {total_sec:.2f}s', '', '[명령 처리시간]']
    for t in timings:
        lines.append(f"- {'✅' if not t.get('error') else '❌'} /{t.get('name','?')}: {float(t.get('sec') or 0):.2f}s / {'OK' if not t.get('error') else 'ERR'}")
    lines += ['', '[채팅 핵심요약]', _v650_safe_body(chat_body or _v823_batch_text(outputs, timings), 5200), '']
    lines += ['', '[명령별 짧은 요약]'] + _v817_command_summary_lines(outputs, timings, cmds)
    lines += ['', '[전체 상세 요약]', _v650_safe_body(_v807_batch_text(), 9000), '']
    lines += ['', '[MTF 구조판 상세]'] + _v823_structure_short_lines()
    lines += _v799_trade_detail_lines_range(since_ts, batch_until)
    lines += ['', '[통합 검증판 상세]'] + _v807_integrated_validation_lines(since_ts, batch_until, compact=False)
    lines += ['', '[가격반응 지연·체결착시 품질판 상세]'] + _v807_price_lag_quality_lines(10) + _v810_quality_route_lines()
    lines += ['', '[OPEN직전 보류 사후검증]'] + _v810_preopen_review_lines(10)
    lines += ['', '[아까운 후보 / 놓친 후보 상세]'] + _v805_missed_summary_lines(10)
    lines += ['', '[명령별 상세]']
    for name in cmds:
        lines += ['', f'/{name}', _v650_safe_body(outputs.get(name,''), 5200)]
    return '\n'.join(str(x) for x in lines)

COMMANDS['batch'] = _v823_batch_text
COMMANDS['summary'] = _v823_batch_text
COMMANDS['pbatch'] = _v823_batch_text
COMMANDS['structure_board'] = _v823_structure_board_text
COMMANDS['structure'] = _v823_structure_board_text
COMMANDS['pstatus'] = _v823_pstatus_text
COMMANDS['status'] = _v823_pstatus_text
COMMANDS['trade'] = _v823_pstatus_text


def batch_handler(update, context):  # type: ignore[override]
    try:
        msg_date=getattr(getattr(update,'message',None),'date',None)
        recv_delay=time.time()-msg_date.timestamp() if hasattr(msg_date,'timestamp') else 0.0
    except Exception:
        recv_delay=0.0
    cmds = _v820_select_batch_cmds(getattr(context,'args',None) or [])
    stime=time.time(); timings=[]; outputs={}
    _v811_begin_batch_source_lock()
    try:
        multi = len(cmds) > 1
        if multi:
            try: send(update, f'📊 묶음 시작 · {len(cmds)}개 명령 / 각 명령 짧은요약 + 상세txt · 지연 {recv_delay:.2f}s')
            except Exception: pass
        total_cmds=len(cmds)
        for idx, name in enumerate(cmds, start=1):
            fn=COMMANDS.get(name); t0=time.time(); err=None
            if not fn:
                body=f'❌ /{name} 연결 없음'; err='no_handler'
            else:
                try: body=fn()
                except Exception as exc:
                    body=f'❌ /{name} 오류 {exc.__class__.__name__}: {exc}'; err=f'{exc.__class__.__name__}: {exc}'; log_error(f'v823_batch_{name}', exc)
            sec=time.time()-t0
            timings.append({'name':name,'sec':sec,'error':err}); outputs[name]=body
            try:
                if multi:
                    send(update, _v817_command_short_block(idx, total_cmds, name, body, sec, err))
                else:
                    send(update, body)
            except Exception as exc: log_error('v823_batch_send', exc)
        total=time.time()-stime
        chat_body = outputs.get(cmds[0], '') if len(cmds) == 1 else _v823_batch_text(outputs, timings)
        try:
            status=_v650_send_summary_file(update, _v823_batch_summary_text(cmds, outputs, timings, recv_delay, total, chat_body=chat_body))
        except Exception as exc:
            status=f'txt 생성실패 {exc.__class__.__name__}'; log_error('v823_batch_summary_file', exc)
        mark='✅' if '전송완료' in status else '⚠️'; del_mark='✅' if '서버삭제' in status else ('❌' if '전송완료' in status else '❔')
        try: send(update, f'📎 txt {mark} / 삭제 {del_mark} / {total:.2f}s')
        except Exception: pass
    finally:
        _v811_end_batch_source_lock()

# END v823 MTF structure spine display


# =============================================================================
# main_bot v2.13.825: runtime entrypoint spine fix + v824 health/MTF source display
# - main remains display-only. No candidate recalculation and no ledger/exit/autobuy changes.
# - /health short block includes CPU/disk/memory again.
# - /structure_board shows whether MTF spine is candle_worker v824 material or fallback.
# =============================================================================
V650_BUILD_LABEL = 'runtime_version_spine_entrypoint_v825_2026-06-11'
BOT_VERSION = '수익형 v2.13.825'
MAIN_BOT_VERSION = BOT_VERSION

_v824_prev_v815_first_signal_lines = _v815_first_signal_lines
_v824_prev_v823_structure_short_lines = _v823_structure_short_lines
_v824_prev_v823_structure_board_text = _v823_structure_board_text
_v824_prev_v823_batch_text = _v823_batch_text
_v824_prev_v823_batch_summary_text = _v823_batch_summary_text

def _v824_resource_brief_line() -> str:
    try:
        parts = []
        for ln in _v650_resource_lines():
            s = str(ln).strip().lstrip('-').strip()
            if 'CPU:' in s:
                parts.append(s.replace('✅ ', '').replace('⚠️ ', '').replace('🛑 ', ''))
            elif '디스크:' in s:
                parts.append(s.replace('✅ ', '').replace('⚠️ ', '').replace('🛑 ', ''))
            elif '메모리:' in s:
                parts.append(s.replace('✅ ', '').replace('⚠️ ', '').replace('🛑 ', ''))
        return '자원: ' + ' / '.join(parts[:3]) if parts else '자원: 자료 없음'
    except Exception as exc:
        try: log_error('v824_resource_brief_line', exc)
        except Exception: pass
        return '자원: 오류'

def _v815_first_signal_lines(name: str, body: str) -> List[str]:  # type: ignore[override]
    n = str(name or '').strip().lstrip('/')
    if n == 'health':
        out: List[str] = []
        for raw in str(body or '').splitlines():
            s = raw.strip()
            if not s:
                continue
            if 'worker:' in s and len(out) < 1:
                out.append(s)
            elif '후보 snapshot:' in s and not any('후보 snapshot:' in x for x in out):
                out.append(s)
            elif '재확인 배관:' in s and not any('재확인 배관:' in x for x in out):
                out.append(s)
        out.insert(2 if len(out) >= 2 else len(out), '- ' + _v824_resource_brief_line())
        # Keep exactly the operator essentials visible in batch command short summary.
        return out[:4] or ['health 요약 없음', '- ' + _v824_resource_brief_line()]
    return _v824_prev_v815_first_signal_lines(name, body)

def _v823_structure_short_lines() -> List[str]:  # type: ignore[override]
    lines = _v824_prev_v823_structure_short_lines()
    try:
        obj = _v823_structure_status()
        hsrc = _v823_counter_from_obj(obj, 'htf_source_counts')
        msrc = _v823_counter_from_obj(obj, 'mtf_source_counts')
        if hsrc or msrc:
            lines.insert(5, '- 구조재료 source: HTF ' + (_v823_counter_line(hsrc, 3) if hsrc else '-') + ' / MTF ' + (_v823_counter_line(msrc, 3) if msrc else '-'))
    except Exception as exc:
        try: log_error('v824_structure_source_lines', exc)
        except Exception: pass
    return lines

def _v812_structure_short_lines() -> List[str]:  # type: ignore[override]
    return _v823_structure_short_lines()

def _v821_structure_short_lines() -> List[str]:  # type: ignore[override]
    return _v823_structure_short_lines()

def _v824_structure_board_text() -> str:
    lines = ['📊 구조판 /structure_board · v825', '- 기준: candle_worker HTF/MTF 구조재료 → strategy MTF spine. main 재계산 없음.', '- 순서: 상위구조(15m/30m/1h) → 중간setup(3m/5m/15m) → 진입trigger(1m/orderflow)']
    lines += _v823_structure_short_lines()
    return '\n'.join(str(x) for x in lines)

def _v824_batch_text(outputs: Optional[Dict[str,str]] = None, timings: Optional[List[Dict[str,Any]]] = None) -> str:
    since_ts = _v798_batch_marker_ts() if '_v798_batch_marker_ts' in globals() else 0.0
    lines = ['📊 코인봇 운영요약 /batch · v825']
    lines += ['① 적용/성과'] + _v809_apply_short_lines()[:3] + _v811_score_short_lines()[:3]
    lines += ['② 후보/MTF구조'] + _v809_candidate_short_lines()[:3] + _v823_structure_short_lines()[:7]
    lines += ['③ paper/보류'] + [f"- OPEN {_v650_open_count() if '_v650_open_count' in globals() else '-'}"] + _v810_preopen_review_lines(3)[:3] + _v809_recent_trade_short_lines(since_ts)[:2]
    lines += ['④ 다음', '- 구조 상세는 /structure_board', '- 재확인 freshness는 /validation_board', '- OPEN/paper 소비는 /pstatus', '- worker/자원은 /health', '- 품질은 /quality_board']
    return '\n'.join(str(x) for x in lines)

def _v824_batch_summary_text(cmds: List[str], outputs: Dict[str,str], timings: List[Dict[str,Any]], recv_delay: float, total_sec: float, chat_body: str = '') -> str:
    global _V797_PENDING_BATCH_MARKER_TS
    batch_until = now_ts(); _V797_PENDING_BATCH_MARKER_TS = batch_until
    since_ts = _v798_batch_marker_ts() if '_v798_batch_marker_ts' in globals() else 0.0
    lines=['코인봇 묶음 요약집 v825', f'- 생성: {_v800_kst_text(batch_until)}', f'- 메인봇: {BOT_VERSION} / {V650_BUILD_LABEL}', f'- 접수지연: {recv_delay:.2f}s / 처리합계: {total_sec:.2f}s', '', '[명령 처리시간]']
    for t in timings:
        lines.append(f"- {'✅' if not t.get('error') else '❌'} /{t.get('name','?')}: {float(t.get('sec') or 0):.2f}s / {'OK' if not t.get('error') else 'ERR'}")
    lines += ['', '[채팅 핵심요약]', _v650_safe_body(chat_body or _v824_batch_text(outputs, timings), 5200), '']
    lines += ['', '[명령별 짧은 요약]'] + _v817_command_summary_lines(outputs, timings, cmds)
    lines += ['', '[전체 상세 요약]', _v650_safe_body(_v807_batch_text(), 9000), '']
    lines += ['', '[MTF 구조판 상세]'] + _v823_structure_short_lines()
    lines += _v799_trade_detail_lines_range(since_ts, batch_until)
    lines += ['', '[통합 검증판 상세]'] + _v807_integrated_validation_lines(since_ts, batch_until, compact=False)
    lines += ['', '[가격반응 지연·체결착시 품질판 상세]'] + _v807_price_lag_quality_lines(10) + _v810_quality_route_lines()
    lines += ['', '[OPEN직전 보류 사후검증]'] + _v810_preopen_review_lines(10)
    lines += ['', '[아까운 후보 / 놓친 후보 상세]'] + _v805_missed_summary_lines(10)
    lines += ['', '[명령별 상세]']
    for name in cmds:
        lines += ['', f'/{name}', _v650_safe_body(outputs.get(name,''), 5200)]
    return '\n'.join(str(x) for x in lines)

COMMANDS['batch'] = _v824_batch_text
COMMANDS['summary'] = _v824_batch_text
COMMANDS['pbatch'] = _v824_batch_text
COMMANDS['structure_board'] = _v824_structure_board_text
COMMANDS['structure'] = _v824_structure_board_text

def batch_handler(update, context):  # type: ignore[override]
    try:
        msg_date=getattr(getattr(update,'message',None),'date',None)
        recv_delay=time.time()-msg_date.timestamp() if hasattr(msg_date,'timestamp') else 0.0
    except Exception:
        recv_delay=0.0
    cmds = _v820_select_batch_cmds(getattr(context,'args',None) or [])
    stime=time.time(); timings=[]; outputs={}
    _v811_begin_batch_source_lock()
    try:
        multi = len(cmds) > 1
        if multi:
            try: send(update, f'📊 묶음 시작 · {len(cmds)}개 명령 / 각 명령 짧은요약 + 상세txt · 지연 {recv_delay:.2f}s')
            except Exception: pass
        total_cmds=len(cmds)
        for idx, name in enumerate(cmds, start=1):
            fn=COMMANDS.get(name); t0=time.time(); err=None
            if not fn:
                body=f'❌ /{name} 연결 없음'; err='no_handler'
            else:
                try: body=fn()
                except Exception as exc:
                    body=f'❌ /{name} 오류 {exc.__class__.__name__}: {exc}'; err=f'{exc.__class__.__name__}: {exc}'; log_error(f'v824_batch_{name}', exc)
            sec=time.time()-t0
            timings.append({'name':name,'sec':sec,'error':err}); outputs[name]=body
            try:
                if multi:
                    send(update, _v817_command_short_block(idx, total_cmds, name, body, sec, err))
                else:
                    send(update, body)
            except Exception as exc: log_error('v824_batch_send', exc)
        total=time.time()-stime
        chat_body = outputs.get(cmds[0], '') if len(cmds) == 1 else _v824_batch_text(outputs, timings)
        try:
            status=_v650_send_summary_file(update, _v824_batch_summary_text(cmds, outputs, timings, recv_delay, total, chat_body=chat_body))
        except Exception as exc:
            status=f'txt 생성실패 {exc.__class__.__name__}'; log_error('v824_batch_summary_file', exc)
        mark='✅' if '전송완료' in status else '⚠️'; del_mark='✅' if '서버삭제' in status else ('❌' if '전송완료' in status else '❔')
        try: send(update, f'📎 txt {mark} / 삭제 {del_mark} / {total:.2f}s')
        except Exception: pass
    finally:
        _v811_end_batch_source_lock()

# END v824 health resource + MTF source display


# =============================================================================
# main_bot v2.13.826: MTF 자료없음 display + structure material status spine
# - v825 runtime entrypoint fix is kept.
# - main remains display-only: no candidate recalculation, no ledger readback, no exits.
# - '-' / 재료없음 are rendered as 자료없음 so operators can distinguish missing data from a real state.
# =============================================================================
V650_BUILD_LABEL = 'candle_material_preserve_spine_v827_2026-06-11'
BOT_VERSION = '수익형 v2.13.827'
MAIN_BOT_VERSION = BOT_VERSION

_v826_prev_v815_first_signal_lines = _v815_first_signal_lines

def _v826_clean_label(v: Any) -> str:
    s = str(v if v is not None else '').strip()
    if not s or s in ('-', 'None', 'none', 'null', 'NULL'):
        return '자료없음'
    # User-facing wording: 자료없음, not 재료없음. Keep source names intact.
    repl = {
        '재료없음': '자료없음',
        '재료 없음': '자료없음',
        'candle 구조재료 없음': 'candle 구조자료 없음',
        '구조재료 없음': '구조자료 없음',
        'setup 재료 없음': 'setup 자료 없음',
    }
    for a,b in repl.items():
        s = s.replace(a,b)
    return s


def _v826_counter_from_obj(obj: Any, key: str) -> Counter:
    try:
        v = obj.get(key) if isinstance(obj, dict) else {}
        if isinstance(v, dict):
            c: Counter = Counter()
            for k, val in v.items():
                try: n = int(val or 0)
                except Exception: n = 0
                if n <= 0: continue
                c[_v826_clean_label(k)] += n
            return c
    except Exception:
        pass
    return Counter()


def _v826_counter_line(c: Counter, n: int = 5) -> str:
    try:
        if not c:
            return '자료없음'
        return ' / '.join(f'{_v826_clean_label(k)} {v}' for k,v in c.most_common(n)) or '자료없음'
    except Exception:
        return '자료없음'


def _v823_counter_from_obj(obj: Any, key: str) -> Counter:  # type: ignore[override]
    return _v826_counter_from_obj(obj, key)


def _v823_counter_line(c: Counter, n: int = 5) -> str:  # type: ignore[override]
    return _v826_counter_line(c, n)


def _v826_structure_short_lines() -> List[str]:
    obj = _v823_structure_status()
    if not obj:
        return ['- 구조판: strategy structure status 자료없음']
    trade_stage = _v826_counter_from_obj(obj, 'trade_stage_counts') or _v826_counter_from_obj(obj, 'candidate_stage_counts')
    all_stage = _v826_counter_from_obj(obj, 'all_stage_counts') or _v826_counter_from_obj(obj, 'stage_counts')
    trade_setup = _v826_counter_from_obj(obj, 'trade_setup_type_top') or _v826_counter_from_obj(obj, 'trade_setup_counts')
    trade_role = _v826_counter_from_obj(obj, 'trade_role_top') or _v826_counter_from_obj(obj, 'trade_role_counts')
    htf_trade = _v826_counter_from_obj(obj, 'trade_htf_state_counts')
    mtf_trade = _v826_counter_from_obj(obj, 'trade_mtf_state_counts')
    ltf_trade = _v826_counter_from_obj(obj, 'trade_ltf_state_counts')
    htf_src = _v826_counter_from_obj(obj, 'htf_source_counts')
    mtf_src = _v826_counter_from_obj(obj, 'mtf_source_counts')
    gate_blocks = _v826_counter_from_obj(obj, 'trade_mtf_s1_block_top')
    rows = _v650_int(obj.get('rows'), default=0) if '_v650_int' in globals() else int(obj.get('rows') or 0)
    missing = _v650_int(obj.get('missing_structure_board_rows'), default=0) if '_v650_int' in globals() else int(obj.get('missing_structure_board_rows') or 0)
    lines = [
        '- 구조판 실전후보: ' + (_v826_counter_line(trade_stage, 4) if trade_stage else '자료없음') + (f' / 합계 {sum(trade_stage.values())}' if trade_stage else ''),
        '- 구조판 전체전략: ' + (_v826_counter_line(all_stage, 4) if all_stage else '자료없음') + (f' / 합계 {sum(all_stage.values())}' if all_stage else ''),
        '- 상위구조(15m/30m/1h): ' + (_v826_counter_line(htf_trade, 5) if htf_trade else '자료없음'),
        '- 중간setup(3m/5m/15m): ' + (_v826_counter_line(mtf_trade, 5) if mtf_trade else '자료없음'),
        '- 진입trigger(1m/orderflow): ' + (_v826_counter_line(ltf_trade, 5) if ltf_trade else '자료없음'),
        '- 구조자료 source: HTF ' + (_v826_counter_line(htf_src, 3) if htf_src else '자료없음') + ' / MTF ' + (_v826_counter_line(mtf_src, 3) if mtf_src else '자료없음'),
        '- 구조타입(실전후보) TOP: ' + (_v826_counter_line(trade_setup, 5) if trade_setup else '자료없음'),
        '- 구조역할(실전후보) TOP: ' + (_v826_counter_line(trade_role, 5) if trade_role else '자료없음'),
    ]
    if missing:
        lines.append(f'- 자료누락: structure_board 미봉인 {missing}/{rows or "?"} · strategy writer 연결 확인')
    if gate_blocks:
        lines.append('- S1 보류 TOP: ' + _v826_counter_line(gate_blocks, 5))
    try:
        samples = obj.get('trade_samples') or obj.get('mtf_trade_samples') or obj.get('samples') or []
        out = []
        for s in samples:
            if not isinstance(s, dict):
                continue
            setup = _v826_clean_label(s.get('setup'))
            role = _v826_clean_label(s.get('role'))
            htf = _v826_clean_label(s.get('htf'))
            mtf = _v826_clean_label(s.get('mtf'))
            ltf = _v826_clean_label(s.get('ltf'))
            reason = _v826_clean_label(s.get('reason'))
            out.append(f"{s.get('ticker','-')} {s.get('stage','-')}/{setup}/{role} · HTF {htf} / MTF {mtf} / LTF {ltf} · {reason}")
            if len(out) >= 3: break
        if out:
            lines.append('- 구조 샘플: ' + ' / '.join(out))
    except Exception:
        pass
    lines.append('- S1 gate: 15m/30m/1h 상위구조 + 3m/5m setup + 1m trigger 모두 확인. 1m 단독 S1 금지')
    return lines


def _v823_structure_short_lines() -> List[str]:  # type: ignore[override]
    return _v826_structure_short_lines()


def _v812_structure_short_lines() -> List[str]:  # type: ignore[override]
    return _v826_structure_short_lines()


def _v821_structure_short_lines() -> List[str]:  # type: ignore[override]
    return _v826_structure_short_lines()


def _v826_structure_board_text() -> str:
    lines = ['📊 구조판 /structure_board · v827', '- 기준: candle_worker HTF/MTF 구조자료 → strategy MTF spine. main 재계산 없음.', '- 순서: 상위구조(15m/30m/1h) → 중간setup(3m/5m/15m) → 진입trigger(1m/orderflow)']
    lines += _v826_structure_short_lines()
    return '\n'.join(str(x) for x in lines)


def _v826_batch_text(outputs: Optional[Dict[str,str]] = None, timings: Optional[List[Dict[str,Any]]] = None) -> str:
    since_ts = _v798_batch_marker_ts() if '_v798_batch_marker_ts' in globals() else 0.0
    lines = ['📊 코인봇 운영요약 /batch · v827']
    lines += ['① 적용/성과'] + _v809_apply_short_lines()[:3] + _v811_score_short_lines()[:3]
    lines += ['② 후보/MTF구조'] + _v809_candidate_short_lines()[:3] + _v826_structure_short_lines()[:8]
    lines += ['③ paper/보류'] + [f"- OPEN {_v650_open_count() if '_v650_open_count' in globals() else '-'}"] + _v810_preopen_review_lines(3)[:3] + _v809_recent_trade_short_lines(since_ts)[:2]
    lines += ['④ 다음', '- 구조 상세는 /structure_board', '- 재확인 freshness는 /validation_board', '- OPEN/paper 소비는 /pstatus', '- worker/자원은 /health', '- 품질은 /quality_board']
    return '\n'.join(str(x) for x in lines)


def _v826_batch_summary_text(cmds: List[str], outputs: Dict[str,str], timings: List[Dict[str,Any]], recv_delay: float, total_sec: float, chat_body: str = '') -> str:
    global _V797_PENDING_BATCH_MARKER_TS
    batch_until = now_ts(); _V797_PENDING_BATCH_MARKER_TS = batch_until
    since_ts = _v798_batch_marker_ts() if '_v798_batch_marker_ts' in globals() else 0.0
    lines=['코인봇 묶음 요약집 v827', f'- 생성: {_v800_kst_text(batch_until)}', f'- 메인봇: {BOT_VERSION} / {V650_BUILD_LABEL}', f'- 접수지연: {recv_delay:.2f}s / 처리합계: {total_sec:.2f}s', '', '[명령 처리시간]']
    for t in timings:
        lines.append(f"- {'✅' if not t.get('error') else '❌'} /{t.get('name','?')}: {float(t.get('sec') or 0):.2f}s / {'OK' if not t.get('error') else 'ERR'}")
    lines += ['', '[채팅 핵심요약]', _v650_safe_body(chat_body or _v826_batch_text(outputs, timings), 5200), '']
    lines += ['', '[명령별 짧은 요약]'] + _v817_command_summary_lines(outputs, timings, cmds)
    lines += ['', '[전체 상세 요약]', _v650_safe_body(_v807_batch_text(), 9000), '']
    lines += ['', '[MTF 구조판 상세]'] + _v826_structure_short_lines()
    lines += _v799_trade_detail_lines_range(since_ts, batch_until)
    lines += ['', '[통합 검증판 상세]'] + _v807_integrated_validation_lines(since_ts, batch_until, compact=False)
    lines += ['', '[가격반응 지연·체결착시 품질판 상세]'] + _v807_price_lag_quality_lines(10) + _v810_quality_route_lines()
    lines += ['', '[OPEN직전 보류 사후검증]'] + _v810_preopen_review_lines(10)
    lines += ['', '[아까운 후보 / 놓친 후보 상세]'] + _v805_missed_summary_lines(10)
    lines += ['', '[명령별 상세]']
    for name in cmds:
        lines += ['', f'/{name}', _v650_safe_body(outputs.get(name,''), 5200)]
    return '\n'.join(str(x) for x in lines)

COMMANDS['batch'] = _v826_batch_text
COMMANDS['summary'] = _v826_batch_text
COMMANDS['pbatch'] = _v826_batch_text
COMMANDS['structure_board'] = _v826_structure_board_text
COMMANDS['structure'] = _v826_structure_board_text


def batch_handler(update, context):  # type: ignore[override]
    try:
        msg_date=getattr(getattr(update,'message',None),'date',None)
        recv_delay=time.time()-msg_date.timestamp() if hasattr(msg_date,'timestamp') else 0.0
    except Exception:
        recv_delay=0.0
    cmds = _v820_select_batch_cmds(getattr(context,'args',None) or [])
    stime=time.time(); timings=[]; outputs={}
    _v811_begin_batch_source_lock()
    try:
        multi = len(cmds) > 1
        if multi:
            try: send(update, f'📊 묶음 시작 · {len(cmds)}개 명령 / 각 명령 짧은요약 + 상세txt · 지연 {recv_delay:.2f}s')
            except Exception: pass
        total_cmds=len(cmds)
        for idx, name in enumerate(cmds, start=1):
            fn=COMMANDS.get(name); t0=time.time(); err=None
            if not fn:
                body=f'❌ /{name} 연결 없음'; err='no_handler'
            else:
                try: body=fn()
                except Exception as exc:
                    body=f'❌ /{name} 오류 {exc.__class__.__name__}: {exc}'; err=f'{exc.__class__.__name__}: {exc}'; log_error(f'v826_batch_{name}', exc)
            sec=time.time()-t0
            timings.append({'name':name,'sec':sec,'error':err}); outputs[name]=body
            try:
                if multi:
                    send(update, _v817_command_short_block(idx, total_cmds, name, body, sec, err))
                else:
                    send(update, body)
            except Exception as exc: log_error('v826_batch_send', exc)
        total=time.time()-stime
        chat_body = outputs.get(cmds[0], '') if len(cmds) == 1 else _v826_batch_text(outputs, timings)
        try:
            status=_v650_send_summary_file(update, _v826_batch_summary_text(cmds, outputs, timings, recv_delay, total, chat_body=chat_body))
        except Exception as exc:
            status=f'txt 생성실패 {exc.__class__.__name__}'; log_error('v826_batch_summary_file', exc)
        mark='✅' if '전송완료' in status else '⚠️'; del_mark='✅' if '서버삭제' in status else ('❌' if '전송완료' in status else '❔')
        try: send(update, f'📎 txt {mark} / 삭제 {del_mark} / {total:.2f}s')
        except Exception: pass
    finally:
        _v811_end_batch_source_lock()

# END v826 MTF 자료없음 display spine




# =============================================================================
# main_bot v2.13.827: candle material preserve deployment marker
# - Main remains a status/command hub. It does not recalculate candidates.
# - v827 pairs with strategy v0.827, which preserves candle_worker v824 material fields.
# - Guard/deploy method/thresholds/exits/paper ledgers unchanged.
# =============================================================================
V650_BUILD_LABEL = 'candle_material_preserve_spine_v827_2026-06-11'
BOT_VERSION = '수익형 v2.13.827'
MAIN_BOT_VERSION = BOT_VERSION

# Keep v826 command bodies; only runtime/build marker moves to v827.
COMMANDS['batch'] = _v826_batch_text
COMMANDS['summary'] = _v826_batch_text
COMMANDS['pbatch'] = _v826_batch_text
COMMANDS['structure_board'] = _v826_structure_board_text
COMMANDS['structure'] = _v826_structure_board_text



# =============================================================================
# main_bot v2.13.828: operator readability board + persistent surgery ledger
# - Main remains display-only. No candidate recalculation, no thresholds, no exits.
# - /batch chat is the operator board; txt keeps detailed evidence and the full backlog.
# - The backlog prevents losing known issues across staged fixes.
# =============================================================================
V650_BUILD_LABEL = 'operator_board_surgery_ledger_v828_2026-06-11'
BOT_VERSION = '수익형 v2.13.828'
MAIN_BOT_VERSION = BOT_VERSION


def _v828_counter_get(c: Any, key: str) -> int:
    try:
        return int((c or {}).get(key) or 0)
    except Exception:
        return 0


def _v828_counter_sum(c: Any) -> int:
    try:
        return sum(int(v or 0) for v in dict(c or {}).values())
    except Exception:
        return 0


def _v828_human_label(s: Any) -> str:
    t = _v826_clean_label(s) if '_v826_clean_label' in globals() else str(s or '').strip()
    repl = {
        'vwap_ema_hold': 'VWAP·EMA 방어',
        'liquidity_sweep_recovery': '저점쓸림 후 회복',
        'breakout_hold': '돌파 유지',
        'common_structure_watch': '공통 관찰',
        'structure_recheck': '구조 재확인',
        'mtf_quality_recheck': 'MTF+품질 재확인',
        'structure_invalid_recheck': '구조 약함 재확인',
        'survival_risk_observe': '위험 관찰',
        'survival_risk_recheck': '생존위험 재확인',
        'htf_confirmed': '상위확인',
        'htf_watch': '상위관찰',
        'htf_missing': '상위자료없음',
        'mtf_setup_confirmed': 'setup확인',
        'mtf_setup_watch': 'setup관찰',
        'mtf_setup_missing': 'setup자료없음',
        'ltf_trigger_ready': 'trigger준비',
        'ltf_trigger_wait': 'trigger대기',
        'ltf_not_ready': 'trigger미준비',
        'candle_worker_v824_structure_material': 'candle본선',
        'v823_numeric_fallback_no_candle_v824_material': 'v823보조',
    }
    for a,b in repl.items():
        t = t.replace(a,b)
    return t


def _v828_counter_line_kor(c: Any, limit: int = 5) -> str:
    try:
        items = sorted(dict(c or {}).items(), key=lambda kv: int(kv[1] or 0), reverse=True)[:limit]
        return ' / '.join(f"{_v828_human_label(k)} {int(v or 0)}" for k,v in items) if items else '자료없음'
    except Exception:
        return '자료없음'


def _v828_structure_obj() -> Dict[str, Any]:
    try:
        obj = _v823_structure_status() if '_v823_structure_status' in globals() else {}
        return obj if isinstance(obj, dict) else {}
    except Exception as exc:
        try: log_error('v828_structure_obj', exc)
        except Exception: pass
        return {}


def _v828_structure_digest_lines() -> List[str]:
    obj = _v828_structure_obj()
    if not obj:
        return ['- 구조판: 자료없음 · strategy structure snapshot 확인 필요']
    trade_stage = _v826_counter_from_obj(obj, 'trade_stage_counts') if '_v826_counter_from_obj' in globals() else Counter()
    all_stage = _v826_counter_from_obj(obj, 'all_stage_counts') if '_v826_counter_from_obj' in globals() else Counter()
    htf = _v826_counter_from_obj(obj, 'trade_htf_state_counts') if '_v826_counter_from_obj' in globals() else Counter()
    mtf = _v826_counter_from_obj(obj, 'trade_mtf_state_counts') if '_v826_counter_from_obj' in globals() else Counter()
    ltf = _v826_counter_from_obj(obj, 'trade_ltf_state_counts') if '_v826_counter_from_obj' in globals() else Counter()
    hsrc = _v826_counter_from_obj(obj, 'htf_source_counts') if '_v826_counter_from_obj' in globals() else Counter()
    msrc = _v826_counter_from_obj(obj, 'mtf_source_counts') if '_v826_counter_from_obj' in globals() else Counter()
    setup = _v826_counter_from_obj(obj, 'trade_setup_type_top') if '_v826_counter_from_obj' in globals() else Counter()
    role = _v826_counter_from_obj(obj, 'trade_role_top') if '_v826_counter_from_obj' in globals() else Counter()
    blocks = _v826_counter_from_obj(obj, 'trade_mtf_s1_block_top') if '_v826_counter_from_obj' in globals() else Counter()

    s1 = _v828_counter_get(trade_stage, 'S1')
    s2 = _v828_counter_get(trade_stage, 'S2')
    s3 = _v828_counter_get(trade_stage, 'S3')
    total = _v828_counter_sum(trade_stage)
    h_confirm = _v828_counter_get(htf, 'htf_confirmed')
    h_watch = _v828_counter_get(htf, 'htf_watch')
    m_confirm = _v828_counter_get(mtf, 'mtf_setup_confirmed')
    m_watch = _v828_counter_get(mtf, 'mtf_setup_watch')
    m_missing = _v828_counter_get(mtf, 'mtf_setup_missing')
    l_ready = _v828_counter_get(ltf, 'ltf_trigger_ready')
    l_wait = _v828_counter_get(ltf, 'ltf_trigger_wait')
    l_not = _v828_counter_get(ltf, 'ltf_not_ready')
    h_candle = sum(int(v or 0) for k,v in dict(hsrc).items() if 'candle_worker_v824' in str(k))
    m_candle = sum(int(v or 0) for k,v in dict(msrc).items() if 'candle_worker_v824' in str(k))
    h_total = _v828_counter_sum(hsrc)
    m_total = _v828_counter_sum(msrc)

    if s1 > 0:
        verdict = f'🟢 S1 {s1}개 있음 · paper 소비/OPEN직전 보류 확인'
    elif l_ready <= 1 and (h_confirm + m_confirm) > 0:
        verdict = f'🟡 S1 없음: 상위/중간은 살아있고 LTF trigger 준비가 {l_ready}개뿐'
    elif m_confirm == 0 and m_missing > 0:
        verdict = '🟡 S1 없음: MTF setup 자료/확인 부족'
    else:
        verdict = '🟡 S1 없음: 구조계획·trigger·실행위험 재확인 필요'

    lines = [
        f'- 실전후보: S1 {s1} / S2 {s2} / S3 {s3} / 합계 {total}',
        f'- 판독: {verdict}',
        f'- 구조자료: HTF candle {h_candle}/{h_total or "?"} · MTF candle {m_candle}/{m_total or "?"}',
        f'- 병목: HTF 확인 {h_confirm}/관찰 {h_watch} · MTF 확인 {m_confirm}/관찰 {m_watch}/자료없음 {m_missing} · LTF ready {l_ready}/wait {l_wait}/not_ready {l_not}',
        '- 구조타입 TOP: ' + _v828_counter_line_kor(setup, 4),
        '- 후보역할 TOP: ' + _v828_counter_line_kor(role, 4),
    ]
    if blocks:
        lines.append('- S1 막힘 TOP: ' + _v828_counter_line_kor(blocks, 5))
    return lines


def _v828_recent_loss_digest_lines(since_ts: float = 0.0) -> List[str]:
    out: List[str] = []
    try:
        raw = _v806_trade_validation_lines(since_ts, now_ts(), 4) if '_v806_trade_validation_lines' in globals() else []
        for s in raw:
            t = str(s)
            if any(x in t for x in ('구간 CLOSED', '바로역행:', '늦은 진입 의심:', '확인값 착시:', '진입후반응')):
                out.append(t)
        if not out:
            out.append('- 산 후보 검증: 새 CLOSED 없음 또는 검증 cache 없음')
    except Exception as exc:
        try: log_error('v828_recent_loss_digest', exc)
        except Exception: pass
        out = ['- 산 후보 검증: 오류']
    return out[:5]


def _v828_quality_digest_lines() -> List[str]:
    keep: List[str] = []
    try:
        raw = _v807_price_lag_quality_lines(3) if '_v807_price_lag_quality_lines' in globals() else []
        for s in raw:
            t = str(s)
            if t.startswith('- 현재 후보 품질:') or t.startswith('- 산 후보 후속검증:') or t.startswith('- 가격후행 성공:') or t.startswith('- 체결착시 위험:') or t.startswith('- 강한확인값 후속실패:') or t.startswith('- 초반약상승 후 꺾임:'):
                keep.append(t)
        keep += (_v810_quality_route_lines()[:2] if '_v810_quality_route_lines' in globals() else [])
    except Exception as exc:
        try: log_error('v828_quality_digest', exc)
        except Exception: pass
    return keep[:6] or ['- 품질판: 자료없음']


def _v828_preopen_digest_lines() -> List[str]:
    try:
        return (_v810_preopen_review_lines(5) if '_v810_preopen_review_lines' in globals() else ['- OPEN직전 보류검증: 자료없음'])[:5]
    except Exception as exc:
        try: log_error('v828_preopen_digest', exc)
        except Exception: pass
        return ['- OPEN직전 보류검증: 오류']


def _v828_missed_digest_lines() -> List[str]:
    try:
        raw = _v805_missed_summary_lines(5) if '_v805_missed_summary_lines' in globals() else []
        keep = []
        for s in raw:
            t = str(s)
            if any(x in t for x in ('추적', '놓친 이유 TOP', '진짜 아까운 후보', '다음 판정 포인트', '판독')):
                keep.append(t)
            if len(keep) >= 5: break
        return keep or raw[:5] or ['- 놓친 후보: 자료없음']
    except Exception as exc:
        try: log_error('v828_missed_digest', exc)
        except Exception: pass
        return ['- 놓친 후보: 오류']


def _v828_surgery_ledger_lines() -> List[str]:
    return [
        '- A 출력판: /batch·/structure_board 채팅은 운영판, txt는 상세판으로 계속 분리',
        '- B LTF/방아쇠: trigger_ready 부족, trigger_not_reached·막은뒤상승 중복/진짜놓침 분리 필요',
        '- C 체결착시: 체결 높고 가격무반응(ZRO류)은 별도 차단/보류 후보로 검증 필요',
        '- D 늦은진입: first→open 120초+ 늦은 진입 의심은 paper handoff 흐름으로 분리 필요',
        '- E 품질후보: 가격후행 성공은 살리고 거래불가 상승/flow_trap은 버리는 품질판 유지',
        '- F 자원/보관: 큰 cache/log 순환정리, paper 원장/trade_log는 보존',
    ]


def _v828_next_action_lines() -> List[str]:
    return [
        '- 지금은 조건 변경 금지. v828 적용 후 30~60분 관찰',
        '- 우선 확인: /batch → /structure_board → /pstatus → /quality_board → /validation_board',
        '- 다음 수술은 장부에서 1개 선택: LTF방아쇠 / 체결착시 / 늦은진입 / trigger_not_reached',
    ]


def _v828_structure_board_text() -> str:
    lines = [
        '📊 구조판 /structure_board · v828',
        '- 기준: candle_worker HTF/MTF 구조자료 → strategy canonical row → main 표시. main 재계산 없음.',
        '- 목적: 영어 태그 나열보다 “어디서 막혔는지”를 먼저 표시.',
        '',
        '① 구조/병목 판독',
    ]
    lines += _v828_structure_digest_lines()
    lines += ['', '② S1/진입 보류 판독'] + _v828_preopen_digest_lines()[:4]
    lines += ['', '③ 안 까먹기 장부'] + _v828_surgery_ledger_lines()[:4]
    lines += ['', '④ 다음'] + _v828_next_action_lines()[:2]
    return '\n'.join(str(x) for x in lines)


def _v828_batch_text(outputs: Optional[Dict[str,str]] = None, timings: Optional[List[Dict[str,Any]]] = None) -> str:
    since_ts = _v798_batch_marker_ts() if '_v798_batch_marker_ts' in globals() else 0.0
    lines: List[str] = ['📊 코인봇 운영판 /batch · v828']
    lines += ['① 적용/성과'] + _v809_apply_short_lines()[:3] + _v811_score_short_lines()[:3]
    lines += ['', '② 지금 병목'] + _v828_structure_digest_lines()[:5]
    lines += ['', '③ paper/최근 매매 해석'] + [f"- OPEN {_v650_open_count() if '_v650_open_count' in globals() else '-'}"] + _v809_recent_trade_short_lines(since_ts)[:2] + _v828_recent_loss_digest_lines(since_ts)[:3]
    lines += ['', '④ 방아쇠/놓침'] + _v828_preopen_digest_lines()[:3] + _v828_missed_digest_lines()[:3]
    lines += ['', '⑤ 품질판 핵심'] + _v828_quality_digest_lines()[:5]
    lines += ['', '⑥ 안 까먹기 수술장부'] + _v828_surgery_ledger_lines()
    lines += ['', '⑦ 다음'] + _v828_next_action_lines()
    return '\n'.join(str(x) for x in lines)


def _v828_batch_summary_text(cmds: List[str], outputs: Dict[str,str], timings: List[Dict[str,Any]], recv_delay: float, total_sec: float, chat_body: str = '') -> str:
    global _V797_PENDING_BATCH_MARKER_TS
    batch_until = now_ts(); _V797_PENDING_BATCH_MARKER_TS = batch_until
    since_ts = _v798_batch_marker_ts() if '_v798_batch_marker_ts' in globals() else 0.0
    lines=['코인봇 묶음 요약집 v828', f'- 생성: {_v800_kst_text(batch_until)}', f'- 메인봇: {BOT_VERSION} / {V650_BUILD_LABEL}', f'- 접수지연: {recv_delay:.2f}s / 처리합계: {total_sec:.2f}s', '', '[명령 처리시간]']
    for t in timings:
        lines.append(f"- {'✅' if not t.get('error') else '❌'} /{t.get('name','?')}: {float(t.get('sec') or 0):.2f}s / {'OK' if not t.get('error') else 'ERR'}")
    lines += ['', '[채팅 운영판]', _v650_safe_body(chat_body or _v828_batch_text(outputs, timings), 6500), '']
    lines += ['', '[안 까먹기 전체 수술장부]'] + _v828_surgery_ledger_lines() + _v828_next_action_lines()
    lines += ['', '[명령별 짧은 요약]'] + _v817_command_summary_lines(outputs, timings, cmds)
    lines += ['', '[전체 상세 요약]', _v650_safe_body(_v807_batch_text(), 10000), '']
    lines += ['', '[MTF 구조판 상세]'] + _v826_structure_short_lines()
    lines += _v799_trade_detail_lines_range(since_ts, batch_until)
    lines += ['', '[최근 산 후보 원인 요약]'] + _v828_recent_loss_digest_lines(since_ts)
    lines += ['', '[통합 검증판 상세]'] + _v807_integrated_validation_lines(since_ts, batch_until, compact=False)
    lines += ['', '[가격반응 지연·체결착시 품질판 상세]'] + _v807_price_lag_quality_lines(10) + _v810_quality_route_lines()
    lines += ['', '[OPEN직전 보류 사후검증]'] + _v810_preopen_review_lines(10)
    lines += ['', '[아까운 후보 / 놓친 후보 상세]'] + _v805_missed_summary_lines(10)
    lines += ['', '[명령별 상세]']
    for name in cmds:
        lines += ['', f'/{name}', _v650_safe_body(outputs.get(name,''), 5200)]
    return '\n'.join(str(x) for x in lines)

COMMANDS['batch'] = _v828_batch_text
COMMANDS['summary'] = _v828_batch_text
COMMANDS['pbatch'] = _v828_batch_text
COMMANDS['structure_board'] = _v828_structure_board_text
COMMANDS['structure'] = _v828_structure_board_text


def batch_handler(update, context):  # type: ignore[override]
    try:
        msg_date=getattr(getattr(update,'message',None),'date',None)
        recv_delay=time.time()-msg_date.timestamp() if hasattr(msg_date,'timestamp') else 0.0
    except Exception:
        recv_delay=0.0
    cmds = _v820_select_batch_cmds(getattr(context,'args',None) or [])
    stime=time.time(); timings=[]; outputs={}
    _v811_begin_batch_source_lock()
    try:
        multi = len(cmds) > 1
        if multi:
            try: send(update, f'📊 묶음 시작 · {len(cmds)}개 명령 / 운영판 + 상세txt · 지연 {recv_delay:.2f}s')
            except Exception: pass
        total_cmds=len(cmds)
        for idx, name in enumerate(cmds, start=1):
            fn=COMMANDS.get(name); t0=time.time(); err=None
            if not fn:
                body=f'❌ /{name} 연결 없음'; err='no_handler'
            else:
                try: body=fn()
                except Exception as exc:
                    body=f'❌ /{name} 오류 {exc.__class__.__name__}: {exc}'; err=f'{exc.__class__.__name__}: {exc}'; log_error(f'v828_batch_{name}', exc)
            sec=time.time()-t0
            timings.append({'name':name,'sec':sec,'error':err}); outputs[name]=body
            try:
                if multi:
                    send(update, _v817_command_short_block(idx, total_cmds, name, body, sec, err))
                else:
                    send(update, body)
            except Exception as exc: log_error('v828_batch_send', exc)
        total=time.time()-stime
        chat_body = outputs.get(cmds[0], '') if len(cmds) == 1 else _v828_batch_text(outputs, timings)
        try:
            status=_v650_send_summary_file(update, _v828_batch_summary_text(cmds, outputs, timings, recv_delay, total, chat_body=chat_body))
        except Exception as exc:
            status=f'txt 생성실패 {exc.__class__.__name__}'; log_error('v828_batch_summary_file', exc)
        mark='✅' if '전송완료' in status else '⚠️'; del_mark='✅' if '서버삭제' in status else ('❌' if '전송완료' in status else '❔')
        try: send(update, f'📎 txt {mark} / 삭제 {del_mark} / {total:.2f}s')
        except Exception: pass
    finally:
        _v811_end_batch_source_lock()



# =============================================================================
# main_bot v2.13.831: v830 TRIGGER decomposition float helper hotfix
# - Main remains display-only. No candidate recalculation, no thresholds, no exits.
# - Decomposes trigger_not_reached into duplicate trace / impossible rise / true miss
#   / calculated-line overhigh suspicion / confirmed-line miss / handoff-lag suspicion.
# - CANDLE-001 status is based on source coverage ratio, not a strict zero-fallback rule.
# =============================================================================
V650_BUILD_LABEL = 'trigger_decomposition_float_hotfix_v831_2026-06-11'
BOT_VERSION = '수익형 v2.13.831'
MAIN_BOT_VERSION = BOT_VERSION


def _v830_float(*values: Any, default: Optional[float] = None) -> Optional[float]:
    # v831 hotfix: accept multiple candidate values plus keyword default.
    # Existing v830 call sites used both _v830_float(a, b) and
    # _v830_float(a, b, c, default=None), so the helper must scan candidates
    # instead of treating the second positional argument as the named default.
    if not values:
        return default
    for x in values:
        try:
            if x in (None, ''):
                continue
            return float(str(x).replace(',', '').replace('%', '').strip())
        except Exception:
            continue
    return default


def _v830_label(s: Any) -> str:
    t = _v828_human_label(s) if '_v828_human_label' in globals() else str(s or '').strip()
    repl = {
        'calculated_line_recheck': '계산선 재확인',
        'confirmed_line': '확정선',
        'reacted_line': '실제 반응선',
        'missing_line': '선자료없음',
        'calc_recheck': '계산선 재확인',
        'vwap_ema_hold': 'VWAP·EMA 방어형',
        'breakout_hold': '돌파 유지형',
        'liquidity_sweep_recovery': '저점쓸림 회복형',
        'common_structure': '공통 구조형',
        'common_structure_watch': '공통 관찰형',
        'support_rebound': '지지 반등형',
        'trigger_not_reached': '방아쇠 미도달',
        'target_room_short': '목표여유 부족',
        'missed_ran_after_hold': '막은뒤상승',
        'held_correct_so_far': '잘막음',
        'expired_no_followthrough': '후속없음 만료',
        'pending': '검증대기',
    }
    for a, b in repl.items():
        t = t.replace(a, b)
    return t or '자료없음'


def _v830_counter_line(c: Any, limit: int = 6) -> str:
    try:
        items = sorted(dict(c or {}).items(), key=lambda kv: int(kv[1] or 0), reverse=True)[:limit]
        return ' / '.join(f"{_v830_label(k)} {int(v or 0)}" for k, v in items) if items else '자료없음'
    except Exception:
        return '자료없음'


def _v830_preopen_obj() -> Dict[str, Any]:
    obj = _v810_preopen_review_obj() if '_v810_preopen_review_obj' in globals() else {}
    return obj if isinstance(obj, dict) else {}


def _v830_preopen_rows() -> List[Dict[str, Any]]:
    obj = _v830_preopen_obj()
    rows = obj.get('rows') if isinstance(obj.get('rows'), list) else []
    return [r for r in rows if isinstance(r, dict)]


def _v830_preopen_stats() -> Dict[str, Any]:
    obj = _v830_preopen_obj()
    kinds = obj.get('hold_kind_counts') if isinstance(obj.get('hold_kind_counts'), dict) else {}
    states = obj.get('review_state_counts') if isinstance(obj.get('review_state_counts'), dict) else {}
    trigger_not = 0; target_short = 0
    for k, v in dict(kinds).items():
        ks = str(k)
        if 'trigger_not_reached' in ks or '방아쇠' in ks:
            trigger_not += int(v or 0)
        if 'target_room_short' in ks or '목표여유' in ks:
            target_short += int(v or 0)
    pending = sum(int(v or 0) for k, v in dict(states).items() if 'pending' in str(k) or '대기' in str(k))
    return {
        'obj': obj,
        'kinds': Counter(kinds),
        'states': Counter(states),
        'rows': int(obj.get('row_count') or 0),
        'trigger_not_reached': trigger_not,
        'target_room_short': target_short,
        'missed_after_hold': int(obj.get('missed_after_hold_count') or 0),
        'held_correct': int(obj.get('held_correct_so_far_count') or 0),
        'pending': pending,
    }


def _v830_trade_rows() -> List[Dict[str, Any]]:
    snap = _v650_candidate_snapshot() if '_v650_candidate_snapshot' in globals() else {}
    rows = (snap.get('trade_rows') or []) if isinstance(snap, dict) else []
    return [r for r in rows if isinstance(r, dict)]


def _v830_ticker_from(row: Dict[str, Any]) -> str:
    try:
        if '_v650_ticker' in globals():
            return str(_v650_ticker(row) or '').upper()
    except Exception:
        pass
    return str(row.get('ticker') or row.get('market') or row.get('symbol') or '').upper().replace('KRW-', '')


def _v830_candidate_info_by_ticker() -> Dict[str, Dict[str, Any]]:
    out: Dict[str, Dict[str, Any]] = {}
    for r in _v830_trade_rows():
        t = _v830_ticker_from(r)
        if not t:
            continue
        p = _v796_plan_obj(r) if '_v796_plan_obj' in globals() else {}
        p = p if isinstance(p, dict) else {}
        m = _v807_metrics_obj(r) if '_v807_metrics_obj' in globals() else {}
        m = m if isinstance(m, dict) else {}
        line_quality = str(p.get('line_quality') or r.get('structure_line_quality') or r.get('line_quality') or 'missing_line')
        trigger_type = str(p.get('trigger_archetype_v801') or p.get('trigger_archetype') or r.get('trigger_archetype_v801') or 'common_structure')
        info = {
            'ticker': t,
            'stage': _v650_stage(r) if '_v650_stage' in globals() else str(r.get('stage') or r.get('grade') or '-'),
            'line_quality': line_quality,
            'trigger_type': trigger_type,
            'trigger_gap_pct': _v830_float(p.get('trigger_gap_pct', r.get('trigger_gap_pct')), None),
            'rr': p.get('rr_ratio') if p.get('rr_ratio') not in (None, '') else r.get('rr_ratio'),
            'spread': _v830_float(m.get('spread'), r.get('spread_pct'), r.get('spread'), default=None),
            'slippage': _v830_float(m.get('slippage'), r.get('slippage_pct'), r.get('slippage'), default=None),
            'buy': _v830_float(m.get('buy'), r.get('buy_ratio'), r.get('buy'), default=None),
            'sustain': _v830_float(m.get('sustain'), r.get('buy_sustain_1m'), r.get('sustain'), default=None),
        }
        prev = out.get(t)
        if prev is None or str(info.get('stage')) == 'S1' or str(prev.get('stage')) not in ('S1','S2'):
            out[t] = info
    return out


def _v830_line_trigger_audit_obj() -> Dict[str, Any]:
    rows = _v830_trade_rows()
    line = Counter(); trig = Counter(); gap_bins = Counter(); stage = Counter(); samples = []
    calc_cnt = 0; confirmed_cnt = 0
    for r in rows:
        stg = _v650_stage(r) if '_v650_stage' in globals() else str(r.get('stage') or r.get('grade') or '-')
        stage[str(stg or '-')] += 1
        p = _v796_plan_obj(r) if '_v796_plan_obj' in globals() else {}
        p = p if isinstance(p, dict) else {}
        lq = str(p.get('line_quality') or r.get('structure_line_quality') or r.get('line_quality') or 'missing_line')
        ta = str(p.get('trigger_archetype_v801') or p.get('trigger_archetype') or r.get('trigger_archetype_v801') or 'common_structure')
        line[lq] += 1; trig[ta] += 1
        if 'calculated' in lq or '계산선' in lq or 'recheck' in lq:
            calc_cnt += 1
        if 'confirmed' in lq or '확정' in lq:
            confirmed_cnt += 1
        gap = _v830_float(p.get('trigger_gap_pct', r.get('trigger_gap_pct')), None)
        if gap is None:
            gap_bins['gap자료없음'] += 1
        else:
            ag = abs(gap)
            if ag <= 0.05:
                gap_bins['근접≤0.05%'] += 1
            elif ag <= 0.15:
                gap_bins['대기0.05~0.15%'] += 1
            elif ag <= 0.30:
                gap_bins['대기0.15~0.30%'] += 1
            else:
                gap_bins['대기0.30%+'] += 1
        if len(samples) < 4 and str(stg) in ('S1','S2'):
            ticker = _v830_ticker_from(r) or '-'
            rr = p.get('rr_ratio') if p else r.get('rr_ratio')
            samples.append(f"{ticker} {stg}/{_v830_label(lq)}/{_v830_label(ta)} gap {gap if gap is not None else '-'}% RR {rr if rr not in (None,'') else '-'}")
    pre = _v830_preopen_stats()
    total = sum(stage.values()) or len(rows)
    calc_ratio = (calc_cnt / total * 100.0) if total else 0.0
    return {
        'rows': len(rows),
        'stage': stage,
        'line_quality': line,
        'trigger_type': trig,
        'gap_bins': gap_bins,
        'calc_count': calc_cnt,
        'confirmed_count': confirmed_cnt,
        'calc_ratio': calc_ratio,
        'samples': samples,
        'preopen': pre,
    }


def _v830_line_trigger_audit_lines() -> List[str]:
    a = _v830_line_trigger_audit_obj(); pre = a.get('preopen') or {}
    trigger_not = int(pre.get('trigger_not_reached') or 0)
    missed = int(pre.get('missed_after_hold') or 0)
    rows = int(pre.get('rows') or 0)
    calc_ratio = float(a.get('calc_ratio') or 0.0)
    if trigger_not > 0 and missed > 0 and calc_ratio >= 50:
        verdict = f'❌ 검산 필요: 계산선 비중 {calc_ratio:.0f}% + 방아쇠 미도달 {trigger_not} + 막은뒤상승 {missed}'
    elif trigger_not > 0 and missed > 0:
        verdict = f'🟡 검산 필요: 방아쇠 미도달 {trigger_not} / 막은뒤상승 {missed}'
    elif trigger_not > 0:
        verdict = f'🟡 방아쇠 미도달 {trigger_not}건 · 막은뒤 상승 여부 관찰'
    else:
        verdict = '✅ 현재 trigger_not_reached 대량 문제 없음'
    lines = [
        f'- 판독: {verdict}',
        f"- 구조선 품질: {_v830_counter_line(a.get('line_quality'), 5)}",
        f"- 구조별 방아쇠: {_v830_counter_line(a.get('trigger_type'), 5)}",
        f"- trigger gap 분포: {_v830_counter_line(a.get('gap_bins'), 5)}",
        f"- OPEN직전 보류: rows {rows} / 방아쇠미도달 {trigger_not} / 막은뒤상승 {missed} / 잘막음 {int(pre.get('held_correct') or 0)}",
    ]
    samples = a.get('samples') or []
    if samples:
        lines.append('- 검산 샘플: ' + ' / '.join(str(x) for x in samples[:3]))
    return lines


def _v830_row_start_gap_pct(row: Dict[str, Any]) -> Optional[float]:
    start = _v830_float(row.get('start_price'), None)
    trig = _v830_float(row.get('trigger_price'), None)
    if start and start > 0 and trig and trig > 0:
        return (trig / start - 1.0) * 100.0
    return None


def _v830_trigger_classification_obj() -> Dict[str, Any]:
    rows = [r for r in _v830_preopen_rows() if 'trigger_not_reached' in str(r.get('hold_kind') or '')]
    info_map = _v830_candidate_info_by_ticker()
    counts: Counter = Counter(); samples: Dict[str, List[str]] = defaultdict(list)
    seen: Counter = Counter(); duplicate_count = 0
    missed_rows = 0

    def add_sample(bucket: str, line: str) -> None:
        if len(samples[bucket]) < 3:
            samples[bucket].append(line)

    for r in rows:
        t = str(r.get('ticker') or '-').upper().replace('KRW-', '')
        maxp = _v830_float(r.get('max_after_pct'), 0.0) or 0.0
        latest = _v830_float(r.get('latest_after_pct'), 0.0) or 0.0
        state = str(r.get('review_state') or '')
        start_gap = _v830_row_start_gap_pct(r)
        info = info_map.get(t, {})
        lq = str(info.get('line_quality') or r.get('line_quality') or r.get('structure_line_quality') or '자료없음')
        ta = str(info.get('trigger_type') or r.get('trigger_archetype') or '-')
        row_gap = info.get('trigger_gap_pct') if info.get('trigger_gap_pct') is not None else start_gap
        spread = _v830_float(info.get('spread'), None)
        slip = _v830_float(info.get('slippage'), spread)
        buy = _v830_float(info.get('buy'), None)
        sus = _v830_float(info.get('sustain'), None)
        sig = (t, str(r.get('hold_kind') or ''), round(_v830_float(r.get('start_price'), 0.0) or 0.0, 8), round(_v830_float(r.get('trigger_price'), 0.0) or 0.0, 8))
        seen[sig] += 1
        is_dup = seen[sig] > 1
        if is_dup:
            duplicate_count += 1
        if maxp >= 0.70:
            missed_rows += 1
        impossible = bool((spread is not None and spread >= 0.85) or (slip is not None and slip >= 0.85))
        calc_line = bool('calculated' in lq or '계산선' in lq or 'recheck' in lq)
        confirmed_line = bool('confirmed' in lq or '확정' in lq)
        gap_abs = abs(float(row_gap)) if row_gap is not None else None
        gap_txt = f'{row_gap:+.3f}%' if row_gap is not None else '-'
        exec_txt = f"스프 {spread:.2f}/미끄 {slip:.2f}" if spread is not None and slip is not None else '실행비용 -'
        flow_txt = f"체결 {buy:.2f}/지속 {sus:.2f}" if buy is not None and sus is not None else '체결 -'
        line = f"{t} max {maxp:+.2f}% now {latest:+.2f}% / gap {gap_txt} / {_v830_label(lq)}·{_v830_label(ta)} / {flow_txt} / {exec_txt}"
        if is_dup:
            bucket = '중복 trace'
        elif maxp >= 0.70 and impossible:
            bucket = '거래불가 상승'
        elif maxp >= 0.70 and calc_line and (gap_abs is None or gap_abs >= 0.15):
            bucket = '계산선 과상향 의심'
        elif maxp >= 0.70 and confirmed_line and (gap_abs is None or gap_abs >= 0.05):
            bucket = '확정선 미도달'
        elif maxp >= 0.70 and gap_abs is not None and gap_abs <= 0.05:
            bucket = 'handoff/급등통과 의심'
        elif maxp >= 0.70:
            bucket = '진짜 놓침'
        elif state == 'held_correct_so_far':
            bucket = '잘 막음'
        elif state == 'expired_no_followthrough':
            bucket = '후속없음 만료'
        elif 'pending' in state or not state:
            bucket = '검증대기'
        else:
            bucket = '분류보류'
        counts[bucket] += 1
        add_sample(bucket, line)

    return {
        'total': len(rows),
        'missed_rows': missed_rows,
        'duplicate_rows': duplicate_count,
        'counts': counts,
        'samples': samples,
        'policy': '표시/분류 전용. S1/S2/S3 조건·paper OPEN 허용·청산은 변경하지 않음.',
    }


def _v830_trigger_classification_lines(detail: bool = False) -> List[str]:
    c = _v830_trigger_classification_obj()
    counts = c.get('counts') if isinstance(c.get('counts'), Counter) else Counter(c.get('counts') or {})
    total = int(c.get('total') or 0); missed = int(c.get('missed_rows') or 0)
    lines = [
        f'- 대상: trigger_not_reached {total} / 막은뒤상승 {missed}',
        '- 세부분류: ' + (_v830_counter_line(counts, 8) if counts else '자료없음'),
    ]
    if counts.get('계산선 과상향 의심', 0) > 0:
        lines.append(f"- 판독: 계산선 과상향 의심 {counts.get('계산선 과상향 의심',0)}건 → 구조선/trigger 산식 검산 우선")
    elif counts.get('handoff/급등통과 의심', 0) > 0:
        lines.append(f"- 판독: handoff/급등통과 의심 {counts.get('handoff/급등통과 의심',0)}건 → paper handoff 시점 검산")
    elif counts.get('진짜 놓침', 0) > 0:
        lines.append(f"- 판독: 진짜 놓침 {counts.get('진짜 놓침',0)}건 → 방아쇠 거리/재확인 속도 검산")
    else:
        lines.append('- 판독: 아직 조건 변경 금지. 분류값 누적 필요')
    samples = c.get('samples') if isinstance(c.get('samples'), dict) else {}
    order = ['계산선 과상향 의심','확정선 미도달','handoff/급등통과 의심','진짜 놓침','거래불가 상승','중복 trace','잘 막음']
    max_sections = 6 if detail else 3
    used = 0
    for k in order:
        vals = samples.get(k) or []
        if vals and used < max_sections:
            lines.append(f'- {k} 샘플: ' + ' / '.join(vals[:3]))
            used += 1
    lines.append('- 닫는 기준: 중복·거래불가·진짜놓침·계산선오류·확정선미도달·handoff지연 분류 완료')
    return lines


def _v830_candle_status() -> Dict[str, Any]:
    struct = _v828_structure_obj() if '_v828_structure_obj' in globals() else {}
    hsrc = _v826_counter_from_obj(struct, 'htf_source_counts') if '_v826_counter_from_obj' in globals() else Counter()
    msrc = _v826_counter_from_obj(struct, 'mtf_source_counts') if '_v826_counter_from_obj' in globals() else Counter()
    h_total = _v828_counter_sum(hsrc) if '_v828_counter_sum' in globals() else sum(Counter(hsrc).values())
    m_total = _v828_counter_sum(msrc) if '_v828_counter_sum' in globals() else sum(Counter(msrc).values())
    h_candle = sum(int(v or 0) for k, v in dict(hsrc).items() if 'candle_worker_v824' in str(k))
    m_candle = sum(int(v or 0) for k, v in dict(msrc).items() if 'candle_worker_v824' in str(k))
    h_ratio = (h_candle / h_total) if h_total else 0.0
    m_ratio = (m_candle / m_total) if m_total else 0.0
    min_ratio = min(h_ratio, m_ratio)
    if min_ratio >= 0.985:
        status = 'DONE'; note = '정상권'
    elif min_ratio >= 0.95:
        status = 'CHECK'; note = '정상권·소수 fallback 관찰'
    else:
        status = 'OPEN'; note = '본선 연결 부족'
    return {'status': status, 'note': note, 'h_candle': h_candle, 'h_total': h_total, 'm_candle': m_candle, 'm_total': m_total, 'h_ratio': h_ratio, 'm_ratio': m_ratio}


def _v830_missed_digest_lines() -> List[str]:
    try:
        raw = _v805_missed_summary_lines(10) if '_v805_missed_summary_lines' in globals() else []
        if not raw:
            return ['- 놓친 후보: 자료없음']
        out: List[str] = []
        capture_true = 0
        for s in raw:
            t = str(s)
            if any(x in t for x in ('추적', '놓친 이유 TOP', '다음 판정 포인트', '판독')):
                out.append(t)
            if '진짜 아까운 후보 TOP' in t:
                out.append(t)
                capture_true = 3
                continue
            if capture_true > 0:
                if t.strip().startswith('-'):
                    out.append(t)
                    capture_true -= 1
                continue
            if len(out) >= 8:
                break
        return out[:8] or raw[:8]
    except Exception as exc:
        try: log_error('v830_missed_digest', exc)
        except Exception: pass
        return ['- 놓친 후보: 오류']


def _v830_issue_items() -> List[Dict[str, str]]:
    pre = _v830_preopen_stats(); audit = _v830_line_trigger_audit_obj(); cls = _v830_trigger_classification_obj()
    counts = cls.get('counts') if isinstance(cls.get('counts'), Counter) else Counter(cls.get('counts') or {})
    candle = _v830_candle_status()
    true_missed = [x for x in _v830_missed_digest_lines() if str(x).startswith('- ') and ('이후최고' in str(x) or 'max +' in str(x))]
    q_counts, _q_samples = _v810_quality_route_counts() if '_v810_quality_route_counts' in globals() else (Counter(), {})
    flow_cnt = int(q_counts.get('flow_trap_watch') or 0) if isinstance(q_counts, (Counter, dict)) else 0
    recent_loss = _v828_recent_loss_digest_lines(_v798_batch_marker_ts() if '_v798_batch_marker_ts' in globals() else 0.0) if '_v828_recent_loss_digest_lines' in globals() else []
    late_flag = any('늦은 진입' in str(x) or 'first→open' in str(x) for x in recent_loss)
    trigger_short = f"미도달 {int(pre.get('trigger_not_reached') or 0)} / 과상향 {int(counts.get('계산선 과상향 의심') or 0)} / 진짜 {int(counts.get('진짜 놓침') or 0)} / handoff {int(counts.get('handoff/급등통과 의심') or 0)}"
    return [
        {
            'id': 'TRIGGER-001',
            'status': 'OPEN' if int(pre.get('trigger_not_reached') or 0) > 0 else 'DONE',
            'title': 'trigger_not_reached 세부분류',
            'short': trigger_short,
            'owner': 'strategy 구조선 → paper trigger gate',
            'close': '중복·거래불가·진짜놓침·계산선오류·확정선미도달·handoff지연 분류 완료',
        },
        {
            'id': 'DISPLAY-001',
            'status': 'DONE' if true_missed else 'CHECK',
            'title': '진짜 아까운 후보 TOP 채팅 표시',
            'short': 'TOP 샘플 표시됨' if true_missed else 'TOP 제목만 있고 샘플 확인 필요',
            'owner': 'main 출력부',
            'close': '채팅 /batch에 TOP 후보 1~3개 표시',
        },
        {
            'id': 'CANDLE-001',
            'status': str(candle.get('status') or 'OPEN'),
            'title': 'candle 구조자료 본선 연결',
            'short': f"{candle.get('note')} · HTF {candle.get('h_candle')}/{candle.get('h_total') or '?'} · MTF {candle.get('m_candle')}/{candle.get('m_total') or '?'}",
            'owner': 'candle_worker → strategy canonical row',
            'close': 'HTF/MTF candle source 98.5% 이상이면 정상권, fallback은 소수 관찰',
        },
        {
            'id': 'QUALITY-001',
            'status': 'OPEN' if flow_cnt > 0 else 'CHECK',
            'title': '체결착시/가격무반응 분리',
            'short': f'flow_trap_watch {flow_cnt}',
            'owner': 'quality/review → strategy/paper 보류판',
            'close': '가격후행 성공과 체결착시를 분리해 후속검증 완료',
        },
        {
            'id': 'LATE-001',
            'status': 'OPEN' if late_flag else 'CHECK',
            'title': '늦은 진입 분리',
            'short': '최근 늦은 진입 의심 있음' if late_flag else '최근 구간 샘플 없음/관찰',
            'owner': 'paper handoff trace',
            'close': 'handoff 지연·trigger대기·진짜 추격을 분리',
        },
    ]


def _v830_status_emoji(status: str) -> str:
    s = str(status or '').upper()
    if s == 'DONE': return '✅'
    if s == 'OPEN': return '❌'
    return '🟡'


def _v830_issue_ledger_chat_lines(limit: int = 5) -> List[str]:
    lines = ['🧾 미해결/해결 장부']
    for it in _v830_issue_items()[:limit]:
        lines.append(f"- {it['id']} {_v830_status_emoji(it.get('status',''))} {it.get('title','-')}: {it.get('short','-')}")
    return lines


def _v830_issue_ledger_detail_lines() -> List[str]:
    lines = ['[문제장부: 해결될 때까지 유지]']
    for it in _v830_issue_items():
        lines += [
            f"- {it['id']} {_v830_status_emoji(it.get('status',''))} {it.get('title','-')}",
            f"  · 상태: {it.get('status','-')} / 현재: {it.get('short','-')}",
            f"  · 주인: {it.get('owner','-')}",
            f"  · 닫는 기준: {it.get('close','-')}",
        ]
    return lines


def _v830_next_action_lines() -> List[str]:
    return [
        '- 지금은 조건 변경 금지. v831은 v830 TRIGGER-001 세부분류판의 float 헬퍼 핫픽스 버전',
        '- 우선 확인: /batch → /structure_board → /issue_ledger → /preopen_review → /quality_board',
        '- 다음 수술 선택 기준: 분류 TOP이 계산선이면 구조선, handoff면 paper, 진짜놓침이면 방아쇠/재확인 속도만 1개 선택',
    ]


def _v830_structure_board_text() -> str:
    lines = [
        '📊 구조판 /structure_board · v831',
        '- 기준: candle_worker HTF/MTF 구조자료 → strategy canonical row → paper preopen review → main 표시. main 재계산 없음.',
        '- 목적: trigger_not_reached를 원인별로 쪼개 다음 수술 대상을 고른다. 조건 변경 없음.',
        '',
        '① 구조/병목 판독',
    ]
    lines += _v828_structure_digest_lines()
    lines += ['', '② 구조선→방아쇠 검산'] + _v830_line_trigger_audit_lines()
    lines += ['', '③ TRIGGER-001 세부분류'] + _v830_trigger_classification_lines(detail=False)
    lines += ['', '④ OPEN직전 보류 판독'] + _v828_preopen_digest_lines()[:4]
    lines += ['', '⑤ 문제장부'] + _v830_issue_ledger_chat_lines(5)
    lines += ['', '⑥ 다음'] + _v830_next_action_lines()[:2]
    return '\n'.join(str(x) for x in lines)


def _v831_batch_text(outputs: Optional[Dict[str,str]] = None, timings: Optional[List[Dict[str,Any]]] = None) -> str:
    since_ts = _v798_batch_marker_ts() if '_v798_batch_marker_ts' in globals() else 0.0
    lines: List[str] = ['📊 코인봇 운영판 /batch · v831']
    lines += ['① 적용/성과'] + _v809_apply_short_lines()[:3] + _v811_score_short_lines()[:3]
    lines += ['', '② 지금 병목'] + _v828_structure_digest_lines()[:5]
    lines += ['', '③ 구조선→방아쇠 검산'] + _v830_line_trigger_audit_lines()[:5]
    lines += ['', '④ TRIGGER-001 세부분류'] + _v830_trigger_classification_lines(detail=False)[:6]
    lines += ['', '⑤ paper/최근 매매 해석'] + [f"- OPEN {_v650_open_count() if '_v650_open_count' in globals() else '-'}"] + _v809_recent_trade_short_lines(since_ts)[:2] + _v828_recent_loss_digest_lines(since_ts)[:3]
    lines += ['', '⑥ 방아쇠/놓침'] + _v828_preopen_digest_lines()[:3] + _v830_missed_digest_lines()[:5]
    lines += ['', '⑦ 품질판 핵심'] + _v828_quality_digest_lines()[:5]
    lines += ['', '⑧ 문제장부'] + _v830_issue_ledger_chat_lines(5)
    lines += ['', '⑨ 다음'] + _v830_next_action_lines()
    return '\n'.join(str(x) for x in lines)


def _v830_issue_ledger_text() -> str:
    lines = ['🧾 문제장부 /issue_ledger · v831']
    lines += _v830_issue_ledger_detail_lines()
    lines += ['', '[구조선→방아쇠 검산]'] + _v830_line_trigger_audit_lines()
    lines += ['', '[TRIGGER-001 세부분류]'] + _v830_trigger_classification_lines(detail=True)
    lines += ['', '[다음]'] + _v830_next_action_lines()
    return '\n'.join(str(x) for x in lines)


def _v830_trigger_audit_text() -> str:
    lines = ['🧨 TRIGGER-001 세부분류 /trigger_audit · v831']
    lines += _v830_line_trigger_audit_lines()
    lines += ['', '[세부분류]'] + _v830_trigger_classification_lines(detail=True)
    lines += ['', '[장부]'] + _v830_issue_ledger_chat_lines(5)
    return '\n'.join(str(x) for x in lines)


def _v831_batch_summary_text(cmds: List[str], outputs: Dict[str,str], timings: List[Dict[str,Any]], recv_delay: float, total_sec: float, chat_body: str = '') -> str:
    global _V797_PENDING_BATCH_MARKER_TS
    batch_until = now_ts(); _V797_PENDING_BATCH_MARKER_TS = batch_until
    since_ts = _v798_batch_marker_ts() if '_v798_batch_marker_ts' in globals() else 0.0
    lines=['코인봇 묶음 요약집 v831', f'- 생성: {_v800_kst_text(batch_until)}', f'- 메인봇: {BOT_VERSION} / {V650_BUILD_LABEL}', f'- 접수지연: {recv_delay:.2f}s / 처리합계: {total_sec:.2f}s', '', '[명령 처리시간]']
    for t in timings:
        lines.append(f"- {'✅' if not t.get('error') else '❌'} /{t.get('name','?')}: {float(t.get('sec') or 0):.2f}s / {'OK' if not t.get('error') else 'ERR'}")
    lines += ['', '[채팅 운영판]', _v650_safe_body(chat_body or _v831_batch_text(outputs, timings), 7600), '']
    lines += ['', '[문제장부 전체]'] + _v830_issue_ledger_detail_lines()
    lines += ['', '[구조선→방아쇠 검산 상세]'] + _v830_line_trigger_audit_lines()
    lines += ['', '[TRIGGER-001 세부분류 상세]'] + _v830_trigger_classification_lines(detail=True)
    lines += ['', '[명령별 짧은 요약]'] + _v817_command_summary_lines(outputs, timings, cmds)
    lines += ['', '[전체 상세 요약]', _v650_safe_body(_v807_batch_text(), 10000), '']
    lines += ['', '[MTF 구조판 상세]'] + _v826_structure_short_lines()
    lines += _v799_trade_detail_lines_range(since_ts, batch_until)
    lines += ['', '[최근 산 후보 원인 요약]'] + _v828_recent_loss_digest_lines(since_ts)
    lines += ['', '[통합 검증판 상세]'] + _v807_integrated_validation_lines(since_ts, batch_until, compact=False)
    lines += ['', '[가격반응 지연·체결착시 품질판 상세]'] + _v807_price_lag_quality_lines(10) + _v810_quality_route_lines()
    lines += ['', '[OPEN직전 보류 사후검증]'] + _v810_preopen_review_lines(10)
    lines += ['', '[아까운 후보 / 놓친 후보 상세]'] + _v805_missed_summary_lines(10)
    lines += ['', '[명령별 상세]']
    for name in cmds:
        lines += ['', f'/{name}', _v650_safe_body(outputs.get(name,''), 5200)]
    return '\n'.join(str(x) for x in lines)

COMMANDS['batch'] = _v831_batch_text
COMMANDS['summary'] = _v831_batch_text
COMMANDS['pbatch'] = _v831_batch_text
COMMANDS['structure_board'] = _v830_structure_board_text
COMMANDS['structure'] = _v830_structure_board_text
COMMANDS['issue_ledger'] = _v830_issue_ledger_text
COMMANDS['ledger'] = _v830_issue_ledger_text
COMMANDS['trigger_audit'] = _v830_trigger_audit_text
COMMANDS['trigger'] = _v830_trigger_audit_text


def batch_handler(update, context):  # type: ignore[override]
    try:
        msg_date=getattr(getattr(update,'message',None),'date',None)
        recv_delay=time.time()-msg_date.timestamp() if hasattr(msg_date,'timestamp') else 0.0
    except Exception:
        recv_delay=0.0
    cmds = _v820_select_batch_cmds(getattr(context,'args',None) or [])
    stime=time.time(); timings=[]; outputs={}
    _v811_begin_batch_source_lock()
    try:
        multi = len(cmds) > 1
        if multi:
            try: send(update, f'📊 묶음 시작 · {len(cmds)}개 명령 / 운영판 + TRIGGER분류txt(v831 hotfix) · 지연 {recv_delay:.2f}s')
            except Exception: pass
        total_cmds=len(cmds)
        for idx, name in enumerate(cmds, start=1):
            fn=COMMANDS.get(name); t0=time.time(); err=None
            if not fn:
                body=f'❌ /{name} 연결 없음'; err='no_handler'
            else:
                try: body=fn()
                except Exception as exc:
                    body=f'❌ /{name} 오류 {exc.__class__.__name__}: {exc}'; err=f'{exc.__class__.__name__}: {exc}'; log_error(f'v831_batch_{name}', exc)
            sec=time.time()-t0
            timings.append({'name':name,'sec':sec,'error':err}); outputs[name]=body
            try:
                if multi:
                    send(update, _v817_command_short_block(idx, total_cmds, name, body, sec, err))
                else:
                    send(update, body)
            except Exception as exc: log_error('v831_batch_send', exc)
        total=time.time()-stime
        chat_body = outputs.get(cmds[0], '') if len(cmds) == 1 else _v831_batch_text(outputs, timings)
        try:
            status=_v650_send_summary_file(update, _v831_batch_summary_text(cmds, outputs, timings, recv_delay, total, chat_body=chat_body))
        except Exception as exc:
            status=f'txt 생성실패 {exc.__class__.__name__}'; log_error('v831_batch_summary_file', exc)
        mark='✅' if '전송완료' in status else '⚠️'; del_mark='✅' if '서버삭제' in status else ('❌' if '전송완료' in status else '❔')
        try: send(update, f'📎 txt {mark} / 삭제 {del_mark} / {total:.2f}s')
        except Exception: pass
    finally:
        _v811_end_batch_source_lock()

# =============================================================================
# main_bot v2.13.832: S1 hold -> paper final-hold audit board
# - Display-only audit for S1 hold/open_ready rows that paper finally blocked.
# - Keeps v831 TRIGGER decomposition, adds PAPER-001 ledger item and /paper_gate_audit.
# - No strategy thresholds, exits, paper OPEN permission, guard, or ledgers changed.
# =============================================================================
V650_BUILD_LABEL = 's1_hold_paper_final_audit_v832_2026-06-11'
BOT_VERSION = '수익형 v2.13.832'
MAIN_BOT_VERSION = BOT_VERSION

import re as _v832_re


def _v832_num(*values: Any, default: Optional[float] = None) -> Optional[float]:
    try:
        return _v830_float(*values, default=default) if '_v830_float' in globals() else default
    except Exception:
        for x in values:
            try:
                if x in (None, ''): continue
                return float(str(x).replace(',', '').replace('%','').strip())
            except Exception:
                continue
        return default


def _v832_fmt_num(x: Any, digits: int = 4, dash: str = '-') -> str:
    v = _v832_num(x, default=None)
    if v is None:
        return dash
    try:
        if abs(v) >= 1000:
            return f"{v:,.0f}"
        return f"{v:.{digits}f}".rstrip('0').rstrip('.')
    except Exception:
        return str(v)


def _v832_fmt_pct(x: Any, digits: int = 2, dash: str = '-') -> str:
    v = _v832_num(x, default=None)
    if v is None:
        return dash
    return f"{v:+.{digits}f}%"


def _v832_walk_values(obj: Any, keys: set, depth: int = 0) -> Optional[Any]:
    if depth > 4:
        return None
    if isinstance(obj, dict):
        for k, v in obj.items():
            if str(k) in keys:
                return v
        for v in obj.values():
            got = _v832_walk_values(v, keys, depth+1)
            if got not in (None, ''):
                return got
    elif isinstance(obj, list):
        for v in obj[:12]:
            got = _v832_walk_values(v, keys, depth+1)
            if got not in (None, ''):
                return got
    return None


def _v832_any(row: Dict[str, Any], *names: str) -> Any:
    keys=set(names)
    for n in names:
        if n in row and row.get(n) not in (None, ''):
            return row.get(n)
    return _v832_walk_values(row, keys)


def _v832_hold_obj() -> Dict[str, Any]:
    try:
        obj = _v743_s1_hold_obj() if '_v743_s1_hold_obj' in globals() else {}
        return obj if isinstance(obj, dict) else {}
    except Exception:
        return {}


def _v832_hold_rows() -> List[Dict[str, Any]]:
    obj = _v832_hold_obj()
    rows = obj.get('rows') if isinstance(obj.get('rows'), list) else []
    return [r for r in rows if isinstance(r, dict)]


def _v832_trace_obj() -> Dict[str, Any]:
    try:
        st = _v650_status() if '_v650_status' in globals() else {}
        if not isinstance(st, dict):
            return {}
        obj = st.get('hold_trace_summary_v746') if isinstance(st.get('hold_trace_summary_v746'), dict) else (st.get('hold_trace_summary_v743') if isinstance(st.get('hold_trace_summary_v743'), dict) else {})
        return obj if isinstance(obj, dict) else {}
    except Exception:
        return {}


def _v832_trace_rows() -> List[Dict[str, Any]]:
    obj = _v832_trace_obj()
    rr = obj.get('recent_rows') if isinstance(obj.get('recent_rows'), dict) else {}
    out=[]
    if isinstance(rr, dict):
        for _bucket, rows in rr.items():
            if isinstance(rows, list):
                for r in rows:
                    if isinstance(r, dict):
                        out.append(r)
    return out


def _v832_final_reason_top() -> Dict[str, int]:
    obj = _v832_trace_obj()
    top = obj.get('final_hold_reason_top') if isinstance(obj.get('final_hold_reason_top'), dict) else {}
    # prefer 5m, fall back 60s/cycle/tail
    for k in ('last5m','last60s','cycle','tail'):
        d = top.get(k) if isinstance(top.get(k), dict) else {}
        if d:
            return dict(d)
    return {}


def _v832_reason_for_ticker(ticker: str) -> str:
    ticker = str(ticker or '').upper().replace('KRW-','')
    if not ticker:
        return '-'
    best='-'
    for r in _v832_trace_rows():
        t = str(r.get('ticker') or r.get('market') or r.get('symbol') or '').upper().replace('KRW-','')
        if t != ticker:
            continue
        status = str(r.get('status') or r.get('event') or r.get('kind') or '')
        reason = str(r.get('reason') or r.get('hold_reason') or r.get('final_reason') or r.get('message') or '')
        if reason:
            best = reason
        if '최종보류' in status or 'final' in status.lower() or 'hold' in status.lower():
            if reason:
                return reason
    return best


def _v832_reaction_value(row: Dict[str, Any], minutes: int) -> Optional[float]:
    keys = []
    if minutes == 1:
        keys = ['price_reaction_1m_pct','price_change_1m_pct','change_1m_pct','m1_change_pct','ret_1m_pct','p1m_pct','one_minute_pct']
    elif minutes == 3:
        keys = ['price_reaction_3m_pct','price_change_3m_pct','change_3m_pct','m3_change_pct','ret_3m_pct','p3m_pct']
    elif minutes == 5:
        keys = ['price_reaction_5m_pct','price_change_5m_pct','change_5m_pct','m5_change_pct','ret_5m_pct','p5m_pct']
    return _v832_num(_v832_any(row, *keys), default=None)


def _v832_hold_row_summary(row: Dict[str, Any]) -> Dict[str, Any]:
    t = _v830_ticker_from(row) if '_v830_ticker_from' in globals() else str(row.get('ticker') or row.get('market') or '-').replace('KRW-','')
    p = _v796_plan_obj(row) if '_v796_plan_obj' in globals() else {}
    p = p if isinstance(p, dict) else {}
    m = _v807_metrics_obj(row) if '_v807_metrics_obj' in globals() else {}
    m = m if isinstance(m, dict) else {}
    status = str(_v832_any(row, 's1_hold_status_v738','s1_hold_status_v736','s1_hold_status_v733','s1_hold_status_v732','hold_status','status') or '-')
    line_quality = str(p.get('line_quality') or _v832_any(row, 'structure_line_quality','line_quality') or '자료없음')
    trig_type = str(p.get('trigger_archetype_v801') or p.get('trigger_archetype') or _v832_any(row, 'trigger_archetype_v801','trigger_archetype') or '자료없음')
    trig_price = _v832_num(_v832_any(row, 'trigger_price','entry_trigger_price','breakout_trigger_price','s1_trigger_price'), default=None)
    entry_price = _v832_num(_v832_any(row, 'entry_price','candidate_entry_price','planned_entry_price','live_entry_price'), default=None)
    live_price = _v832_num(_v832_any(row, 'live_price','current_price','last_price','price','close','start_price'), default=None)
    gap = _v832_num(_v832_any(row, 'trigger_gap_pct'), p.get('trigger_gap_pct'), default=None)
    reached = _v832_any(row, 'trigger_reached','entry_trigger_reached','trigger_gate_reached')
    if reached in (None, ''):
        reached_txt = '-'
    else:
        reached_txt = 'Y' if str(reached).lower() in ('1','true','yes','y','도달') else 'N'
    buy = _v832_num(m.get('buy'), _v832_any(row, 'buy_ratio','buy'), default=None)
    sustain = _v832_num(m.get('sustain'), _v832_any(row, 'buy_sustain_1m','sustain'), default=None)
    spread = _v832_num(m.get('spread'), _v832_any(row, 'spread_pct','spread'), default=None)
    slip = _v832_num(m.get('slippage'), _v832_any(row, 'slippage_pct','slippage'), spread, default=None)
    age = _v832_num(_v832_any(row, 'age_sec','hold_age_sec','s1_hold_age_sec','candidate_age_sec'), default=None)
    handoff_age = _v832_num(_v832_any(row, 'handoff_age_sec','paper_handoff_age_sec','handoff_age','source_age_sec'), default=None)
    reason = _v832_reason_for_ticker(t)
    r1 = _v832_reaction_value(row, 1); r3 = _v832_reaction_value(row, 3); r5 = _v832_reaction_value(row, 5)
    if r1 is None and r3 is None and r5 is None:
        # fallback: use metrics reaction if present
        r1 = _v832_num(m.get('price_reaction'), m.get('reaction'), _v832_any(row, 'price_reaction_pct','reaction_pct'), default=None)
    block_flags=[]
    if '방아쇠' in reason or 'trigger' in reason.lower() or reached_txt == 'N': block_flags.append('방아쇠')
    if '무반응' in reason or ((r1 is not None and abs(r1) < 0.01) and (r3 is None or abs(r3) < 0.01)): block_flags.append('무반응')
    if handoff_age is not None and handoff_age >= 20: block_flags.append('handoff_age')
    if gap is not None and abs(gap) <= 0.05 and ('방아쇠' in reason or 'trigger' in reason.lower()): block_flags.append('gap근접인데보류')
    if 'flow_trap' in str(_v832_any(row, 'quality_tags','quality_tag','route_tags','block_reasons')): block_flags.append('체결착시')
    return {
        'ticker': t or '-', 'status': status, 'line_quality': line_quality, 'trigger_type': trig_type,
        'trigger_price': trig_price, 'entry_price': entry_price, 'live_price': live_price, 'gap': gap,
        'reached': reached_txt, 'buy': buy, 'sustain': sustain, 'spread': spread, 'slip': slip,
        'age': age, 'handoff_age': handoff_age, 'r1': r1, 'r3': r3, 'r5': r5, 'reason': reason,
        'flags': block_flags,
    }


def _v832_paper_gate_audit_obj() -> Dict[str, Any]:
    h = _v832_hold_obj(); rows = _v832_hold_rows(); trace = _v832_trace_obj()
    summaries = [_v832_hold_row_summary(r) for r in rows[:20]]
    counts = Counter()
    for s in summaries:
        if not s.get('flags'):
            counts['원인표시부족'] += 1
        for f in s.get('flags') or []:
            counts[f] += 1
    status_counts = h.get('status_counts') if isinstance(h.get('status_counts'), dict) else {}
    final_top = _v832_final_reason_top()
    tr_counts = trace.get('status_counts') if isinstance(trace.get('status_counts'), dict) else {}
    return {
        'hold_count': int(_v832_num(h.get('count'), h.get('total'), h.get('fresh_count'), default=0) or 0),
        'fresh_count': int(_v832_num(h.get('fresh_count'), default=0) or 0),
        'open_ready_count': int(_v832_num(h.get('open_ready_count'), default=0) or 0),
        'stale_count': int(_v832_num(h.get('stale_count'), default=0) or 0),
        'status_counts': Counter(status_counts),
        'final_reason_top': Counter(final_top),
        'trace_counts': tr_counts,
        'samples': summaries[:6],
        'flag_counts': counts,
    }


def _v832_paper_gate_audit_lines(detail: bool = False) -> List[str]:
    obj = _v832_paper_gate_audit_obj()
    hold = int(obj.get('hold_count') or 0); ready = int(obj.get('open_ready_count') or 0); fresh = int(obj.get('fresh_count') or 0)
    lines = [
        f"- 대상: S1 hold {hold} / fresh {fresh} / open_ready {ready}",
    ]
    ftop = obj.get('final_reason_top') if isinstance(obj.get('final_reason_top'), Counter) else Counter()
    flags = obj.get('flag_counts') if isinstance(obj.get('flag_counts'), Counter) else Counter()
    if ftop:
        lines.append('- paper 최종보류 TOP: ' + _v830_counter_line(ftop, 4))
    else:
        lines.append('- paper 최종보류 TOP: 최근 보류사유 없음/미봉인')
    if flags:
        lines.append('- 보류 검산 분류: ' + _v830_counter_line(flags, 5))
    if ready > 0 and ftop:
        verdict = '❌ S1 open_ready가 paper에서 최종보류됨: trigger/무반응/가격 age를 검산해야 함'
    elif ready > 0:
        verdict = '🟡 S1 open_ready 있음: 다음 paper cycle 소비 trace 확인'
    elif hold > 0:
        verdict = '🟡 S1 hold 있음: open_ready 전 단계 확인'
    else:
        verdict = '✅ 현재 S1 hold 없음'
    lines.insert(0, f'- 판독: {verdict}')
    samples = obj.get('samples') if isinstance(obj.get('samples'), list) else []
    if samples:
        lines.append('- hold 샘플:')
        maxn = 6 if detail else 3
        for s in samples[:maxn]:
            reaction = f"1m {_v832_fmt_pct(s.get('r1'))} / 3m {_v832_fmt_pct(s.get('r3'))} / 5m {_v832_fmt_pct(s.get('r5'))}"
            price = f"entry {_v832_fmt_num(s.get('entry_price'))} / live {_v832_fmt_num(s.get('live_price'))} / trigger {_v832_fmt_num(s.get('trigger_price'))} / gap {_v832_fmt_pct(s.get('gap'),3)} / reached {s.get('reached','-')}"
            flow = f"체결 {_v832_fmt_num(s.get('buy'),2)} / 지속 {_v832_fmt_num(s.get('sustain'),2)} / 스프 {_v832_fmt_num(s.get('spread'),2)} / 미끄 {_v832_fmt_num(s.get('slip'),2)}"
            ages = f"hold_age {_v832_fmt_num(s.get('age'),1)}s / handoff_age {_v832_fmt_num(s.get('handoff_age'),1)}s"
            reason = str(s.get('reason') or '-')
            if len(reason) > 90: reason = reason[:87] + '…'
            lines.append(f"  · {s.get('ticker','-')} {s.get('status','-')} / {_v830_label(s.get('line_quality'))}·{_v830_label(s.get('trigger_type'))} / {price} / {reaction} / {flow} / {ages} / 보류 {reason}")
    if detail:
        lines.append('- 닫는 기준: S1 open_ready가 paper에서 trigger/무반응/handoff/가격age 중 어디서 막히는지 후보별로 표시 완료')
    return lines

# Preserve previous ledger provider, then add PAPER-001 without deleting existing 장부.
_V831_ISSUE_ITEMS_PREV = _v830_issue_items if '_v830_issue_items' in globals() else None

def _v832_issue_items() -> List[Dict[str, str]]:
    prev = _V831_ISSUE_ITEMS_PREV() if callable(_V831_ISSUE_ITEMS_PREV) else []
    audit = _v832_paper_gate_audit_obj()
    ready = int(audit.get('open_ready_count') or 0)
    ftop = audit.get('final_reason_top') if isinstance(audit.get('final_reason_top'), Counter) else Counter()
    status = 'OPEN' if ready > 0 and sum(ftop.values()) > 0 else ('CHECK' if ready > 0 else 'CHECK')
    short = f"S1 open_ready {ready} / 보류사유 {sum(ftop.values()) if ftop else 0} / 분류 {(_v830_counter_line(audit.get('flag_counts'),3) if audit.get('flag_counts') else '관찰')}"
    item = {
        'id': 'PAPER-001',
        'status': status,
        'title': 'S1 hold→paper 최종보류 검산',
        'short': short,
        'owner': 'paper runtime snapshot → main 표시판',
        'close': 'S1 open_ready 후보별 trigger_price·entry/live·무반응·handoff age 표시 완료',
    }
    # insert after TRIGGER-001 for visibility, keep all existing IDs.
    out=[]; inserted=False
    for p in prev:
        out.append(p)
        if isinstance(p, dict) and p.get('id') == 'TRIGGER-001':
            out.append(item); inserted=True
    if not inserted: out.insert(0, item)
    return out

_v830_issue_items = _v832_issue_items  # type: ignore[assignment]


def _v832_next_action_lines() -> List[str]:
    return [
        '- 지금은 조건 변경 금지. v832는 S1 hold→paper 최종보류 검산판만 추가한 버전',
        '- 우선 확인: /batch → /paper_gate_audit → /pstatus → /trigger_audit → /quality_board',
        '- 다음 수술 선택 기준: paper가 trigger로 막으면 paper/trigger gate, 무반응이면 preopen 재확인, handoff age면 paper 소비속도만 1개 선택',
    ]

_v830_next_action_lines = _v832_next_action_lines  # type: ignore[assignment]


def _v832_structure_board_text() -> str:
    lines = [
        '📊 구조판 /structure_board · v832',
        '- 기준: candle_worker/strategy canonical row + paper runtime snapshot. main 재계산 없음.',
        '- 목적: S1이 떴는데 paper가 왜 막았는지 trigger/무반응/handoff로 검산한다. 조건 변경 없음.',
        '',
        '① 구조/병목 판독',
    ]
    lines += _v828_structure_digest_lines()
    lines += ['', '② S1 hold→paper 최종보류 검산'] + _v832_paper_gate_audit_lines(detail=False)
    lines += ['', '③ 구조선→방아쇠 검산'] + _v830_line_trigger_audit_lines()
    lines += ['', '④ TRIGGER-001 세부분류'] + _v830_trigger_classification_lines(detail=False)
    lines += ['', '⑤ 문제장부'] + _v830_issue_ledger_chat_lines(6)
    lines += ['', '⑥ 다음'] + _v832_next_action_lines()[:2]
    return '\n'.join(str(x) for x in lines)


def _v832_batch_text(outputs: Optional[Dict[str,str]] = None, timings: Optional[List[Dict[str,Any]]] = None) -> str:
    since_ts = _v798_batch_marker_ts() if '_v798_batch_marker_ts' in globals() else 0.0
    lines: List[str] = ['📊 코인봇 운영판 /batch · v832']
    lines += ['① 적용/성과'] + _v809_apply_short_lines()[:3] + _v811_score_short_lines()[:3]
    lines += ['', '② 지금 병목'] + _v828_structure_digest_lines()[:5]
    lines += ['', '③ S1 hold→paper 최종보류 검산'] + _v832_paper_gate_audit_lines(detail=False)[:8]
    lines += ['', '④ TRIGGER-001 세부분류'] + _v830_trigger_classification_lines(detail=False)[:5]
    lines += ['', '⑤ paper/최근 매매 해석'] + [f"- OPEN {_v650_open_count() if '_v650_open_count' in globals() else '-'}"] + _v809_recent_trade_short_lines(since_ts)[:2] + _v828_recent_loss_digest_lines(since_ts)[:3]
    lines += ['', '⑥ 방아쇠/놓침'] + _v828_preopen_digest_lines()[:3] + _v830_missed_digest_lines()[:4]
    lines += ['', '⑦ 품질판 핵심'] + _v828_quality_digest_lines()[:5]
    lines += ['', '⑧ 문제장부'] + _v830_issue_ledger_chat_lines(6)
    lines += ['', '⑨ 다음'] + _v832_next_action_lines()
    return '\n'.join(str(x) for x in lines)


def _v832_paper_gate_audit_text() -> str:
    lines = ['🧪 PAPER-001 S1 hold→paper 최종보류 검산 /paper_gate_audit · v832']
    lines += _v832_paper_gate_audit_lines(detail=True)
    lines += ['', '[기존 paper 소비 요약]'] + (_v799_paper_hold_trace_lines() if '_v799_paper_hold_trace_lines' in globals() else _v743_paper_hold_trace_lines())
    lines += ['', '[장부]'] + _v830_issue_ledger_chat_lines(6)
    return '\n'.join(str(x) for x in lines)


def _v832_issue_ledger_text() -> str:
    lines = ['🧾 문제장부 /issue_ledger · v832']
    lines += _v830_issue_ledger_detail_lines()
    lines += ['', '[PAPER-001 S1 hold→paper 보류 검산]'] + _v832_paper_gate_audit_lines(detail=True)
    lines += ['', '[TRIGGER-001 세부분류]'] + _v830_trigger_classification_lines(detail=True)
    lines += ['', '[다음]'] + _v832_next_action_lines()
    return '\n'.join(str(x) for x in lines)


def _v832_trigger_audit_text() -> str:
    lines = ['🧨 TRIGGER-001 세부분류 /trigger_audit · v832']
    lines += _v830_line_trigger_audit_lines()
    lines += ['', '[세부분류]'] + _v830_trigger_classification_lines(detail=True)
    lines += ['', '[PAPER-001 연결 참고]'] + _v832_paper_gate_audit_lines(detail=False)[:7]
    lines += ['', '[장부]'] + _v830_issue_ledger_chat_lines(6)
    return '\n'.join(str(x) for x in lines)


def _v832_batch_summary_text(cmds: List[str], outputs: Dict[str,str], timings: List[Dict[str,Any]], recv_delay: float, total_sec: float, chat_body: str = '') -> str:
    global _V797_PENDING_BATCH_MARKER_TS
    batch_until = now_ts(); _V797_PENDING_BATCH_MARKER_TS = batch_until
    since_ts = _v798_batch_marker_ts() if '_v798_batch_marker_ts' in globals() else 0.0
    lines=['코인봇 묶음 요약집 v832', f'- 생성: {_v800_kst_text(batch_until)}', f'- 메인봇: {BOT_VERSION} / {V650_BUILD_LABEL}', f'- 접수지연: {recv_delay:.2f}s / 처리합계: {total_sec:.2f}s', '', '[명령 처리시간]']
    for t in timings:
        lines.append(f"- {'✅' if not t.get('error') else '❌'} /{t.get('name','?')}: {float(t.get('sec') or 0):.2f}s / {'OK' if not t.get('error') else 'ERR'}")
    lines += ['', '[채팅 운영판]', _v650_safe_body(chat_body or _v832_batch_text(outputs, timings), 7600), '']
    lines += ['', '[문제장부 전체]'] + _v830_issue_ledger_detail_lines()
    lines += ['', '[PAPER-001 S1 hold→paper 보류 검산 상세]'] + _v832_paper_gate_audit_lines(detail=True)
    lines += ['', '[TRIGGER-001 세부분류 상세]'] + _v830_trigger_classification_lines(detail=True)
    lines += ['', '[구조선→방아쇠 검산 상세]'] + _v830_line_trigger_audit_lines()
    lines += ['', '[명령별 짧은 요약]'] + _v817_command_summary_lines(outputs, timings, cmds)
    lines += ['', '[전체 상세 요약]', _v650_safe_body(_v807_batch_text(), 10000), '']
    lines += ['', '[MTF 구조판 상세]'] + _v826_structure_short_lines()
    lines += _v799_trade_detail_lines_range(since_ts, batch_until)
    lines += ['', '[최근 산 후보 원인 요약]'] + _v828_recent_loss_digest_lines(since_ts)
    lines += ['', '[통합 검증판 상세]'] + _v807_integrated_validation_lines(since_ts, batch_until, compact=False)
    lines += ['', '[가격반응 지연·체결착시 품질판 상세]'] + _v807_price_lag_quality_lines(10) + _v810_quality_route_lines()
    lines += ['', '[OPEN직전 보류 사후검증]'] + _v810_preopen_review_lines(10)
    lines += ['', '[아까운 후보 / 놓친 후보 상세]'] + _v805_missed_summary_lines(10)
    lines += ['', '[명령별 상세]']
    for name in cmds:
        lines += ['', f'/{name}', _v650_safe_body(outputs.get(name,''), 5200)]
    return '\n'.join(str(x) for x in lines)

COMMANDS['batch'] = _v832_batch_text
COMMANDS['summary'] = _v832_batch_text
COMMANDS['pbatch'] = _v832_batch_text
COMMANDS['structure_board'] = _v832_structure_board_text
COMMANDS['structure'] = _v832_structure_board_text
COMMANDS['issue_ledger'] = _v832_issue_ledger_text
COMMANDS['ledger'] = _v832_issue_ledger_text
COMMANDS['trigger_audit'] = _v832_trigger_audit_text
COMMANDS['trigger'] = _v832_trigger_audit_text
COMMANDS['paper_gate_audit'] = _v832_paper_gate_audit_text
COMMANDS['paper_audit'] = _v832_paper_gate_audit_text
COMMANDS['hold_audit'] = _v832_paper_gate_audit_text


def batch_handler(update, context):  # type: ignore[override]
    try:
        msg_date=getattr(getattr(update,'message',None),'date',None)
        recv_delay=time.time()-msg_date.timestamp() if hasattr(msg_date,'timestamp') else 0.0
    except Exception:
        recv_delay=0.0
    cmds = _v820_select_batch_cmds(getattr(context,'args',None) or [])
    stime=time.time(); timings=[]; outputs={}
    _v811_begin_batch_source_lock()
    try:
        multi = len(cmds) > 1
        if multi:
            try: send(update, f'📊 묶음 시작 · {len(cmds)}개 명령 / 운영판 + PAPER검산txt(v832) · 지연 {recv_delay:.2f}s')
            except Exception: pass
        total_cmds=len(cmds)
        for idx, name in enumerate(cmds, start=1):
            fn=COMMANDS.get(name); t0=time.time(); err=None
            if not fn:
                body=f'❌ /{name} 연결 없음'; err='no_handler'
            else:
                try: body=fn()
                except Exception as exc:
                    body=f'❌ /{name} 오류 {exc.__class__.__name__}: {exc}'; err=f'{exc.__class__.__name__}: {exc}'; log_error(f'v832_batch_{name}', exc)
            sec=time.time()-t0
            timings.append({'name':name,'sec':sec,'error':err}); outputs[name]=body
            try:
                if multi:
                    send(update, _v817_command_short_block(idx, total_cmds, name, body, sec, err))
                else:
                    send(update, body)
            except Exception as exc: log_error('v832_batch_send', exc)
        total=time.time()-stime
        chat_body = outputs.get(cmds[0], '') if len(cmds) == 1 else _v832_batch_text(outputs, timings)
        try:
            status=_v650_send_summary_file(update, _v832_batch_summary_text(cmds, outputs, timings, recv_delay, total, chat_body=chat_body))
        except Exception as exc:
            status=f'txt 생성실패 {exc.__class__.__name__}'; log_error('v832_batch_summary_file', exc)
        mark='✅' if '전송완료' in status else '⚠️'; del_mark='✅' if '서버삭제' in status else ('❌' if '전송완료' in status else '❔')
        try: send(update, f'📎 txt {mark} / 삭제 {del_mark} / {total:.2f}s')
        except Exception: pass
    finally:
        _v811_end_batch_source_lock()


# =============================================================================
# main_bot v2.13.833: SOURCE-001 stale audit + easy Telegram wording
# - Display-only patch. No strategy thresholds, no exits, no paper OPEN changes.
# - Adds /source_audit to check whether "자료 오래됨" is real or a stale-label mismatch.
# - Keeps internal keys unchanged; only user-facing Telegram wording is simplified.
# =============================================================================
V650_BUILD_LABEL = 'source_stale_audit_easy_words_v833_2026-06-11'
BOT_VERSION = '수익형 v2.13.833'
MAIN_BOT_VERSION = BOT_VERSION


def _v833_easy_text(text: Any) -> str:
    s = str(text or '')
    repl = [
        ('source stale', '자료 오래됨 의심'),
        ('source_stale', '자료 오래됨 의심'),
        ('stale_or_wait', '자료 오래됨/대기'),
        ('stale_repeat', '오래됨 반복'),
        ('fresh_but_no_value_change', '최신이지만 값 변화 없음'),
        ('fresh_update', '최신 업데이트'),
        ('source<=20s', '자료 20초 이내'),
        ('source age', '자료 나이'),
        ('cache age', '보관자료 나이'),
        ('trigger_not_reached', '방아쇠 미도달'),
        ('target_room_short', '목표여유 부족'),
        ('missed_ran_after_hold', '막은 뒤 상승'),
        ('held_correct_so_far', '잘 막음'),
        ('expired_no_followthrough', '후속 없음 만료'),
        ('pending', '검증대기'),
        ('flow_trap_watch', '체결은 강한데 가격이 안 따라옴'),
        ('quality_recheck_s2', '가격 따라붙는지 재확인'),
        ('quality_watch', '품질 관찰'),
        ('calculated_recheck', '계산선 재확인'),
        ('confirmed_line', '확정선'),
        ('missing_line', '선자료 없음'),
        ('vwap_ema_hold', 'VWAP·EMA 방어'),
        ('breakout_hold', '돌파 유지'),
        ('liquidity_sweep_recovery', '저점쓸림 후 회복'),
        ('common_structure_watch', '공통 관찰'),
        ('survival_risk_recheck', '위험 재확인'),
        ('survival_risk_observe', '위험 관찰'),
        ('structure_recheck', '구조 재확인'),
        ('structure_invalid_recheck', '구조 약함 재확인'),
        ('mtf_quality_recheck', '중간흐름+품질 재확인'),
        ('candle_worker_v824_structure_material', '캔들공장 구조자료'),
        ('v823_numeric_fallback_no_candle_v824_material', '예전 숫자보정 자료'),
        ('open_ready', '진입준비'),
        ('fresh_open_ready', '최신 진입준비'),
        ('handoff', 'paper 전달'),
    ]
    for a,b in repl:
        s = s.replace(a,b)
    # Common reason phrase cleanup after literal replacement.
    s = s.replace('생존위험: 자료 오래됨 의심', '자료 오래됨 의심')
    return s


def _v833_contains_stale(values: List[Any]) -> bool:
    joined = ' / '.join(str(x or '') for x in values).lower()
    return any(k in joined for k in ('stale', '오래', '자료 오래'))


def _v833_row_age(row: Dict[str, Any]) -> Optional[float]:
    keys = (
        'source_age','fresh_age','age','candidate_age','row_age','source_age_sec','source_age_s',
        'price_age','price_age_s','orderflow_age','feature_age','candle_age','metrics_age',
        'fresh_age_sec','source_updated_age','publish_age','compact_age','updated_age'
    )
    vals = []
    for k in keys:
        vals.append(row.get(k))
    try:
        if '_v832_any' in globals():
            vals.append(_v832_any(row, *keys))
    except Exception:
        pass
    try:
        return _v832_num(*vals, default=None) if '_v832_num' in globals() else _v830_float(*vals, default=None)
    except Exception:
        return None


def _v833_stale_reasons(row: Dict[str, Any]) -> List[str]:
    vals: List[str] = []
    try: vals += [str(x) for x in _v650_reasons(row)]
    except Exception: pass
    try: vals += [str(x) for x in _v650_risks(row)]
    except Exception: pass
    return [x for x in vals if _v833_contains_stale([x])]


def _v833_worker_age_summary() -> str:
    parts=[]
    for name in ('strategy','orderflow','feature','candle','target_router','review'):
        try:
            w=worker_status(name)
            label={'strategy':'전략','orderflow':'체결/호가','feature':'가격특징','candle':'캔들','target_router':'재확인배차','review':'복기'}.get(name,name)
            parts.append(f"{label} {float(w.get('age') or 0):.1f}s")
        except Exception:
            pass
    return ' / '.join(parts) if parts else '자료없음'


def _v833_source_audit_obj() -> Dict[str, Any]:
    """SOURCE-001 audit.
    v845: stale labels are not accepted as truth when worker/candidate ages are fresh.
    The effective issue source is actual age + worker status, not duplicated stale text counters.
    """
    snap = _v650_candidate_snapshot() if '_v650_candidate_snapshot' in globals() else {}
    rows = snap.get('rows') if isinstance(snap, dict) and isinstance(snap.get('rows'), list) else []
    trade_rows = snap.get('trade_rows') if isinstance(snap, dict) and isinstance(snap.get('trade_rows'), list) else []
    reasons = snap.get('reasons') if isinstance(snap, dict) and isinstance(snap.get('reasons'), Counter) else Counter(snap.get('reasons') or {})
    risks = snap.get('risks') if isinstance(snap, dict) and isinstance(snap.get('risks'), Counter) else Counter(snap.get('risks') or {})
    raw_stale_reason_total = 0
    stale_counter = Counter()
    for c in (reasons, risks):
        for k,v in dict(c).items():
            if _v833_contains_stale([k]):
                try: n=int(v or 0)
                except Exception: n=0
                raw_stale_reason_total += n
                stale_counter[str(k)] += n
    cand_file_age = None
    try: cand_file_age = float(snap.get('file_age'))
    except Exception: cand_file_age = None
    real_old = suspect = no_age = row_count = 0
    stage_counter = Counter(); sample_suspect=[]; sample_old=[]; sample_noage=[]
    for r in rows:
        if not isinstance(r, dict):
            continue
        srs = _v833_stale_reasons(r)
        agev = _v833_row_age(r)
        actual_old = (agev is not None and agev >= 120)
        label_stale = bool(srs)
        if not label_stale and not actual_old:
            continue
        row_count += 1
        stg = _v650_stage(r) if '_v650_stage' in globals() else str(r.get('stage') or r.get('grade') or '-')
        stage_counter[str(stg or '-')] += 1
        ticker = _v830_ticker_from(r) if '_v830_ticker_from' in globals() else str(r.get('ticker') or r.get('market') or '-')
        why = _v833_easy_text(' / '.join(srs[:2])) or '나이값 기준'
        age_txt = '-' if agev is None else f'{agev:.1f}s'
        line = f"{ticker} {stg} / 자료나이 {age_txt} / {why}"
        if actual_old:
            real_old += 1
            if len(sample_old) < 4: sample_old.append(line)
        elif agev is not None and agev <= 60 and label_stale:
            suspect += 1
            if len(sample_suspect) < 4: sample_suspect.append(line)
        elif agev is None and label_stale:
            no_age += 1
            if len(sample_noage) < 4: sample_noage.append(line)
    worker_ages=[]; worker_ok=True
    for name in ('strategy','orderflow','feature','candle','target_router'):
        try:
            a=float(worker_status(name).get('age') or 999999)
            worker_ages.append(a)
            if a > 60: worker_ok=False
        except Exception:
            worker_ok=False
    cand_fresh = cand_file_age is not None and cand_file_age <= 60
    # v845 source unification: if the actual material is fresh, stale text labels are old/derived noise.
    ignored_label_total = 0
    effective_stale_reason_total = raw_stale_reason_total
    effective_row_count = row_count
    effective_suspect = suspect
    if worker_ok and cand_fresh and real_old == 0:
        ignored_label_total = raw_stale_reason_total
        effective_stale_reason_total = 0
        effective_row_count = 0
        effective_suspect = 0
        no_age = 0
        stage_counter = Counter()
        stale_counter = Counter()
        sample_suspect = []
        verdict = '✅ stale 표시 단일화: worker/candidate age 정상, 구 stale 라벨은 무시'
    elif effective_stale_reason_total <= 0 and effective_row_count <= 0:
        verdict = '✅ 자료 오래됨 판정 거의 없음'
    elif worker_ok and cand_fresh and effective_suspect >= real_old:
        verdict = '⚠️ worker는 정상인데 오래됨 표시가 많음: 오판정 가능성 큼'
    elif real_old > 0:
        verdict = '🟡 실제 오래된 후보도 있음: 오래된 자료/오판정 분리 필요'
    else:
        verdict = '🟡 자료 오래됨 표시 원인 확인 필요'
    return {
        'stale_reason_total': effective_stale_reason_total,
        'raw_stale_reason_total': raw_stale_reason_total,
        'ignored_label_total_v845': ignored_label_total,
        'stale_row_count': effective_row_count,
        'raw_stale_row_count': row_count,
        'real_old': real_old,
        'suspect': effective_suspect,
        'raw_suspect': suspect,
        'no_age': no_age,
        'candidate_file_age': cand_file_age,
        'stage_counter': stage_counter,
        'stale_counter': stale_counter,
        'sample_suspect': sample_suspect,
        'sample_old': sample_old,
        'sample_noage': sample_noage,
        'worker_ok': worker_ok,
        'worker_age_summary': _v833_worker_age_summary(),
        'verdict': verdict,
        'trade_rows': len(trade_rows or []),
        'all_rows': len(rows or []),
    }


def _v833_source_audit_lines(detail: bool = False) -> List[str]:
    a = _v833_source_audit_obj()
    cand_age = a.get('candidate_file_age')
    cand_txt = '-' if cand_age is None else f"{float(cand_age):.1f}s"
    lines = [
        f"- 판독: {a.get('verdict')}",
        f"- 자료 오래됨 표시: 이유횟수 {int(a.get('stale_reason_total') or 0)} / 후보행 {int(a.get('stale_row_count') or 0)}",
        f"- 분류: 실제 오래됨 {int(a.get('real_old') or 0)} / 멀쩡한데 오래됨 의심 {int(a.get('suspect') or 0)} / 나이값 없음 {int(a.get('no_age') or 0)}",
        f"- 실제 자료 나이: 후보파일 {cand_txt} / worker {a.get('worker_age_summary')}",
    ]
    sc = a.get('stage_counter') if isinstance(a.get('stage_counter'), Counter) else Counter()
    if sc:
        lines.append('- 오래됨 표시 단계: ' + _v830_counter_line(sc, 5))
    stale_counter = a.get('stale_counter') if isinstance(a.get('stale_counter'), Counter) else Counter()
    if stale_counter:
        lines.append('- 오래됨 문구 TOP: ' + _v833_easy_text(_v830_counter_line(stale_counter, 5)))
    if a.get('sample_suspect'):
        lines.append('- 오판정 의심 샘플: ' + ' / '.join(a.get('sample_suspect')[:3]))
    if detail:
        if a.get('sample_old'):
            lines.append('- 실제 오래됨 샘플: ' + ' / '.join(a.get('sample_old')[:4]))
        if a.get('sample_noage'):
            lines.append('- 나이값 없음 샘플: ' + ' / '.join(a.get('sample_noage')[:4]))
        lines.append('- 닫는 기준: 자료 오래됨 표시를 실제 지연/오판정/나이값 없음으로 분리 완료')
    return [_v833_easy_text(x) for x in lines]


_V832_ISSUE_ITEMS_PREV = _v830_issue_items if '_v830_issue_items' in globals() else None

def _v833_issue_items() -> List[Dict[str, str]]:
    prev = _V832_ISSUE_ITEMS_PREV() if callable(_V832_ISSUE_ITEMS_PREV) else []
    a = _v833_source_audit_obj()
    status = 'OPEN' if int(a.get('suspect') or 0) > 0 or int(a.get('stale_reason_total') or 0) > 0 else 'DONE'
    icon_status = status
    item = {
        'id': 'SOURCE-001',
        'status': icon_status,
        'title': '자료 오래됨 판정 확인',
        'short': f"오래됨 표시 {int(a.get('stale_reason_total') or 0)} / 실제 {int(a.get('real_old') or 0)} / 오판정의심 {int(a.get('suspect') or 0)}",
        'owner': 'strategy canonical row + worker status',
        'close': '자료 오래됨 표시가 실제 지연/오판정/나이값 없음으로 분리 완료',
    }
    out=[]; inserted=False
    for p in prev:
        out.append(p)
        if isinstance(p, dict) and p.get('id') == 'TRIGGER-001':
            out.append(item); inserted=True
    if not inserted: out.insert(0, item)
    # Easy wording for all issue titles/shorts without changing IDs.
    for p in out:
        if isinstance(p, dict):
            for k in ('title','short','owner','close'):
                if k in p: p[k]=_v833_easy_text(p[k])
    return out

_v830_issue_items = _v833_issue_items  # type: ignore[assignment]


def _v833_next_action_lines() -> List[str]:
    return [
        '- 지금은 조건 변경 금지. v833은 자료 오래됨 판정 확인판 + 쉬운 문구 변환 버전',
        '- 우선 확인: /batch → /source_audit → /issue_ledger → /trigger_audit → /quality_board',
        '- 다음 수술 선택 기준: 자료 오래됨이 오판정이면 stale 판정 경로, 실제 지연이면 worker/cache 갱신 경로만 1개 선택',
    ]

_v830_next_action_lines = _v833_next_action_lines  # type: ignore[assignment]


def _v833_source_audit_text() -> str:
    lines = ['🧭 SOURCE-001 자료 오래됨 판정 확인 /source_audit · v833']
    lines += _v833_source_audit_lines(detail=True)
    lines += ['', '[장부]'] + _v830_issue_ledger_chat_lines(7)
    return _v833_easy_text('\n'.join(str(x) for x in lines))


def _v833_batch_text(outputs: Optional[Dict[str,str]] = None, timings: Optional[List[Dict[str,Any]]] = None) -> str:
    since_ts = _v798_batch_marker_ts() if '_v798_batch_marker_ts' in globals() else 0.0
    lines: List[str] = ['📊 코인봇 운영판 /batch · v833']
    lines += ['① 적용/성과'] + _v809_apply_short_lines()[:3] + _v811_score_short_lines()[:3]
    lines += ['', '② 지금 병목'] + _v828_structure_digest_lines()[:5]
    lines += ['', '③ 자료 오래됨 판정 확인'] + _v833_source_audit_lines(detail=False)[:7]
    lines += ['', '④ S1 hold→paper 최종보류 검산'] + _v832_paper_gate_audit_lines(detail=False)[:6]
    lines += ['', '⑤ TRIGGER-001 세부분류'] + _v830_trigger_classification_lines(detail=False)[:4]
    lines += ['', '⑥ paper/최근 매매 해석'] + [f"- OPEN {_v650_open_count() if '_v650_open_count' in globals() else '-'}"] + _v809_recent_trade_short_lines(since_ts)[:2] + _v828_recent_loss_digest_lines(since_ts)[:2]
    lines += ['', '⑦ 방아쇠/놓침'] + _v828_preopen_digest_lines()[:3] + _v830_missed_digest_lines()[:3]
    lines += ['', '⑧ 품질판 핵심'] + _v828_quality_digest_lines()[:4]
    lines += ['', '⑨ 문제장부'] + _v830_issue_ledger_chat_lines(7)
    lines += ['', '⑩ 다음'] + _v833_next_action_lines()
    return _v833_easy_text('\n'.join(str(x) for x in lines))


def _v833_structure_board_text() -> str:
    lines = [
        '📊 구조판 /structure_board · v833',
        '- 기준: candle_worker/strategy canonical row + worker 상태 + paper runtime snapshot. main 재계산 없음.',
        '- 목적: 자료 오래됨 판정이 진짜인지 먼저 확인한다. 조건 변경 없음.',
        '',
        '① 구조/병목 판독',
    ]
    lines += _v828_structure_digest_lines()
    lines += ['', '② 자료 오래됨 판정 확인'] + _v833_source_audit_lines(detail=True)
    lines += ['', '③ S1 hold→paper 최종보류 검산'] + _v832_paper_gate_audit_lines(detail=False)
    lines += ['', '④ TRIGGER-001 세부분류'] + _v830_trigger_classification_lines(detail=False)[:6]
    lines += ['', '⑤ 문제장부'] + _v830_issue_ledger_chat_lines(7)
    lines += ['', '⑥ 다음'] + _v833_next_action_lines()[:2]
    return _v833_easy_text('\n'.join(str(x) for x in lines))


def _v833_issue_ledger_text() -> str:
    lines = ['🧾 문제장부 /issue_ledger · v833']
    lines += _v830_issue_ledger_detail_lines()
    lines += ['', '[SOURCE-001 자료 오래됨 판정 확인]'] + _v833_source_audit_lines(detail=True)
    lines += ['', '[PAPER-001 S1 hold→paper 보류 검산]'] + _v832_paper_gate_audit_lines(detail=True)
    lines += ['', '[TRIGGER-001 세부분류]'] + _v830_trigger_classification_lines(detail=True)
    lines += ['', '[다음]'] + _v833_next_action_lines()
    return _v833_easy_text('\n'.join(str(x) for x in lines))


def _v833_trigger_audit_text() -> str:
    lines = ['🧨 TRIGGER-001 세부분류 /trigger_audit · v833']
    lines += _v830_line_trigger_audit_lines()
    lines += ['', '[세부분류]'] + _v830_trigger_classification_lines(detail=True)
    lines += ['', '[SOURCE-001 연결 참고]'] + _v833_source_audit_lines(detail=False)[:6]
    lines += ['', '[PAPER-001 연결 참고]'] + _v832_paper_gate_audit_lines(detail=False)[:6]
    lines += ['', '[장부]'] + _v830_issue_ledger_chat_lines(7)
    return _v833_easy_text('\n'.join(str(x) for x in lines))


def _v833_paper_gate_audit_text() -> str:
    lines = ['🧪 PAPER-001 S1 hold→paper 최종보류 검산 /paper_gate_audit · v833']
    lines += _v832_paper_gate_audit_lines(detail=True)
    lines += ['', '[SOURCE-001 연결 참고]'] + _v833_source_audit_lines(detail=False)[:5]
    lines += ['', '[기존 paper 소비 요약]'] + (_v799_paper_hold_trace_lines() if '_v799_paper_hold_trace_lines' in globals() else _v743_paper_hold_trace_lines())
    lines += ['', '[장부]'] + _v830_issue_ledger_chat_lines(7)
    return _v833_easy_text('\n'.join(str(x) for x in lines))


def _v833_batch_summary_text(cmds: List[str], outputs: Dict[str,str], timings: List[Dict[str,Any]], recv_delay: float, total_sec: float, chat_body: str = '') -> str:
    global _V797_PENDING_BATCH_MARKER_TS
    batch_until = now_ts(); _V797_PENDING_BATCH_MARKER_TS = batch_until
    since_ts = _v798_batch_marker_ts() if '_v798_batch_marker_ts' in globals() else 0.0
    lines=['코인봇 묶음 요약집 v833', f'- 생성: {_v800_kst_text(batch_until)}', f'- 메인봇: {BOT_VERSION} / {V650_BUILD_LABEL}', f'- 접수지연: {recv_delay:.2f}s / 처리합계: {total_sec:.2f}s', '', '[명령 처리시간]']
    for t in timings:
        lines.append(f"- {'✅' if not t.get('error') else '❌'} /{t.get('name','?')}: {float(t.get('sec') or 0):.2f}s / {'OK' if not t.get('error') else 'ERR'}")
    lines += ['', '[채팅 운영판]', _v650_safe_body(chat_body or _v833_batch_text(outputs, timings), 7600), '']
    lines += ['', '[문제장부 전체]'] + _v830_issue_ledger_detail_lines()
    lines += ['', '[SOURCE-001 자료 오래됨 판정 상세]'] + _v833_source_audit_lines(detail=True)
    lines += ['', '[PAPER-001 S1 hold→paper 보류 검산 상세]'] + _v832_paper_gate_audit_lines(detail=True)
    lines += ['', '[TRIGGER-001 세부분류 상세]'] + _v830_trigger_classification_lines(detail=True)
    lines += ['', '[구조선→방아쇠 검산 상세]'] + _v830_line_trigger_audit_lines()
    lines += ['', '[명령별 짧은 요약]'] + _v817_command_summary_lines(outputs, timings, cmds)
    lines += ['', '[전체 상세 요약]', _v650_safe_body(_v833_easy_text(_v807_batch_text()), 10000), '']
    lines += ['', '[MTF 구조판 상세]'] + [_v833_easy_text('\n'.join(_v826_structure_short_lines()))]
    lines += _v799_trade_detail_lines_range(since_ts, batch_until)
    lines += ['', '[최근 산 후보 원인 요약]'] + _v828_recent_loss_digest_lines(since_ts)
    lines += ['', '[통합 검증판 상세]'] + [_v833_easy_text('\n'.join(_v807_integrated_validation_lines(since_ts, batch_until, compact=False)))]
    lines += ['', '[가격반응 지연·체결착시 품질판 상세]'] + [_v833_easy_text('\n'.join(_v807_price_lag_quality_lines(10) + _v810_quality_route_lines()))]
    lines += ['', '[OPEN직전 보류 사후검증]'] + _v810_preopen_review_lines(10)
    lines += ['', '[아까운 후보 / 놓친 후보 상세]'] + _v805_missed_summary_lines(10)
    lines += ['', '[명령별 상세]']
    for name in cmds:
        lines += ['', f'/{name}', _v650_safe_body(_v833_easy_text(outputs.get(name,'')), 5200)]
    return _v833_easy_text('\n'.join(str(x) for x in lines))

COMMANDS['batch'] = _v833_batch_text
COMMANDS['summary'] = _v833_batch_text
COMMANDS['pbatch'] = _v833_batch_text
COMMANDS['structure_board'] = _v833_structure_board_text
COMMANDS['structure'] = _v833_structure_board_text
COMMANDS['issue_ledger'] = _v833_issue_ledger_text
COMMANDS['ledger'] = _v833_issue_ledger_text
COMMANDS['trigger_audit'] = _v833_trigger_audit_text
COMMANDS['trigger'] = _v833_trigger_audit_text
COMMANDS['paper_gate_audit'] = _v833_paper_gate_audit_text
COMMANDS['paper_audit'] = _v833_paper_gate_audit_text
COMMANDS['hold_audit'] = _v833_paper_gate_audit_text
COMMANDS['source_audit'] = _v833_source_audit_text
COMMANDS['stale_audit'] = _v833_source_audit_text
COMMANDS['data_age'] = _v833_source_audit_text


def batch_handler(update, context):  # type: ignore[override]
    try:
        msg_date=getattr(getattr(update,'message',None),'date',None)
        recv_delay=time.time()-msg_date.timestamp() if hasattr(msg_date,'timestamp') else 0.0
    except Exception:
        recv_delay=0.0
    cmds = _v820_select_batch_cmds(getattr(context,'args',None) or [])
    stime=time.time(); timings=[]; outputs={}
    _v811_begin_batch_source_lock()
    try:
        multi = len(cmds) > 1
        if multi:
            try: send(update, f'📊 묶음 시작 · {len(cmds)}개 명령 / 자료오래됨 확인txt(v833) · 지연 {recv_delay:.2f}s')
            except Exception: pass
        total_cmds=len(cmds)
        for idx, name in enumerate(cmds, start=1):
            fn=COMMANDS.get(name); t0=time.time(); err=None
            if not fn:
                body=f'❌ /{name} 연결 없음'; err='no_handler'
            else:
                try: body=fn()
                except Exception as exc:
                    body=f'❌ /{name} 오류 {exc.__class__.__name__}: {exc}'; err=f'{exc.__class__.__name__}: {exc}'; log_error(f'v833_batch_{name}', exc)
            body = _v833_easy_text(body)
            sec=time.time()-t0
            timings.append({'name':name,'sec':sec,'error':err}); outputs[name]=body
            try:
                if multi:
                    send(update, _v817_command_short_block(idx, total_cmds, name, body, sec, err))
                else:
                    send(update, body)
            except Exception as exc: log_error('v833_batch_send', exc)
        total=time.time()-stime
        chat_body = outputs.get(cmds[0], '') if len(cmds) == 1 else _v833_batch_text(outputs, timings)
        try:
            status=_v650_send_summary_file(update, _v833_batch_summary_text(cmds, outputs, timings, recv_delay, total, chat_body=chat_body))
        except Exception as exc:
            status=f'txt 생성실패 {exc.__class__.__name__}'; log_error('v833_batch_summary_file', exc)
        mark='✅' if '전송완료' in status else '⚠️'; del_mark='✅' if '서버삭제' in status else ('❌' if '전송완료' in status else '❔')
        try: send(update, f'📎 txt {mark} / 삭제 {del_mark} / {total:.2f}s')
        except Exception: pass
    finally:
        _v811_end_batch_source_lock()



# =============================================================================
# main_bot v2.13.834: paper gate mismatch ledger + review issue backlog
# - Adds ledger persistence for problems found during result review.
# - Makes PAPER-001 explicitly track MAY-style reached/missed conflict.
# - Adds PAPER-002 for v628 trigger-miss legacy label/path check.
# - Adds OXT evidence to QUALITY-001 and LATE-001 ledger notes.
# - Display/ledger only. No thresholds, trigger formula, exits, paper OPEN permission, workers, or guard changes.
# =============================================================================
V650_BUILD_LABEL = 'paper_gate_ledger_backlog_v834_2026-06-11'
BOT_VERSION = '수익형 v2.13.834'
MAIN_BOT_VERSION = BOT_VERSION


def _v834_easy_text(text: Any) -> str:
    try:
        return _v833_easy_text(text) if '_v833_easy_text' in globals() else str(text)
    except Exception:
        return str(text)


def _v834_parse_paper_trigger_reason(reason: Any) -> Dict[str, Optional[float]]:
    txt = str(reason or '')
    out: Dict[str, Optional[float]] = {'entry': None, 'trigger': None}
    try:
        m = _v832_re.search(r'진입\s*([0-9,]+(?:\.[0-9]+)?)\s*<\s*방아쇠\s*([0-9,]+(?:\.[0-9]+)?)', txt)
        if not m:
            return out
        out['entry'] = _v832_num(m.group(1), default=None)
        out['trigger'] = _v832_num(m.group(2), default=None)
    except Exception:
        pass
    return out


def _v834_dominant_final_reason() -> str:
    try:
        ftop = _v832_final_reason_top() if '_v832_final_reason_top' in globals() else {}
        if isinstance(ftop, dict) and ftop:
            return str(max(ftop.items(), key=lambda kv: int(kv[1] or 0))[0])
    except Exception:
        pass
    return ''


def _v834_paper_mismatch_obj() -> Dict[str, Any]:
    base = _v832_paper_gate_audit_obj() if '_v832_paper_gate_audit_obj' in globals() else {}
    samples = base.get('samples') if isinstance(base.get('samples'), list) else []
    top_reason = _v834_dominant_final_reason()
    enriched: List[Dict[str, Any]] = []
    counts = Counter()
    for raw in samples[:12]:
        if not isinstance(raw, dict):
            continue
        s = dict(raw)
        reason = str(s.get('reason') or '')
        # Some paper trace rows expose only the hold dict while the real final reason is in final_reason_top.
        if ('방아쇠' not in reason and 'trigger' not in reason.lower()) and top_reason:
            reason = top_reason
        parsed = _v834_parse_paper_trigger_reason(reason)
        paper_entry = parsed.get('entry')
        paper_trigger = parsed.get('trigger')
        hold_trigger = _v832_num(s.get('trigger_price'), default=None) if '_v832_num' in globals() else None
        reached = str(s.get('reached') or '-')
        conflict_flags: List[str] = []
        if 'v628' in reason:
            conflict_flags.append('v628 문구/구경로 확인')
            counts['v628 문구/구경로 확인'] += 1
        if ('방아쇠' in reason or 'trigger' in reason.lower()) and reached == 'Y':
            conflict_flags.append('도달/미도달 동시표시')
            counts['도달/미도달 동시표시'] += 1
        if paper_trigger is not None and (hold_trigger is None or abs(float(hold_trigger)) < 1e-12):
            conflict_flags.append('hold 표시 trigger 없음/0')
            counts['hold 표시 trigger 없음/0'] += 1
        elif paper_trigger is not None and hold_trigger is not None:
            try:
                denom = max(abs(float(paper_trigger)), 1e-9)
                diff_pct = abs(float(paper_trigger)-float(hold_trigger))/denom*100.0
                if diff_pct >= 0.02:
                    conflict_flags.append(f'paper/hold trigger 불일치 {diff_pct:.3f}%')
                    counts['paper/hold trigger 불일치'] += 1
            except Exception:
                pass
        if not conflict_flags and ('무반응' in reason or '무반응' in ' '.join(str(x) for x in (s.get('flags') or []))):
            counts['무반응 보류'] += 1
        s['paper_reason_v834'] = reason or '-'
        s['paper_entry_v834'] = paper_entry
        s['paper_trigger_v834'] = paper_trigger
        s['hold_trigger_v834'] = hold_trigger
        s['conflict_flags_v834'] = conflict_flags
        enriched.append(s)
    final_top = base.get('final_reason_top') if isinstance(base.get('final_reason_top'), Counter) else Counter()
    old_path_count = 0
    try:
        old_path_count = sum(int(v or 0) for k, v in final_top.items() if 'v628' in str(k))
    except Exception:
        old_path_count = 0
    if old_path_count:
        counts['v628 문구/구경로 확인'] += old_path_count
    return {
        'base': base,
        'samples': enriched,
        'conflict_counts': counts,
        'old_path_count': old_path_count,
        'dominant_reason': top_reason,
    }


def _v834_paper_mismatch_lines(detail: bool = False) -> List[str]:
    obj = _v834_paper_mismatch_obj()
    base = obj.get('base') if isinstance(obj.get('base'), dict) else {}
    hold = int(base.get('hold_count') or 0)
    ready = int(base.get('open_ready_count') or 0)
    counts = obj.get('conflict_counts') if isinstance(obj.get('conflict_counts'), Counter) else Counter()
    samples = obj.get('samples') if isinstance(obj.get('samples'), list) else []
    if counts:
        verdict = '❌ paper가 본 방아쇠값과 hold 표시값이 다름: 같은 후보가 도달/미도달로 보일 수 있음'
    elif ready > 0:
        verdict = '🟡 S1 진입준비 있음: paper 보류값 계속 확인'
    elif hold > 0:
        verdict = '🟡 S1 hold 있음: 진입준비 전 단계 확인'
    else:
        verdict = '✅ 현재 S1 hold 없음'
    lines = [f'- 판독: {verdict}']
    lines.append(f"- 대상: S1 hold {hold} / 진입준비 {ready}")
    if counts:
        lines.append('- 판정 충돌/확인: ' + _v830_counter_line(counts, 5))
    else:
        lines.append('- 판정 충돌/확인: 현재 샘플 없음')
    if obj.get('old_path_count'):
        lines.append(f"- v628 확인: paper 최종보류 문구에 v628 표시 {int(obj.get('old_path_count') or 0)}회 · 실제 구경로인지 단순 문구인지 확인 필요")
    dom = str(obj.get('dominant_reason') or '')
    if dom:
        lines.append('- paper 최종보류 대표사유: ' + _v834_easy_text(dom))
    show_samples = [s for s in samples if isinstance(s, dict) and (s.get('conflict_flags_v834') or detail)]
    if show_samples:
        lines.append('- 충돌/검산 샘플:')
        for s in show_samples[:(6 if detail else 3)]:
            flags = ' / '.join(str(x) for x in (s.get('conflict_flags_v834') or ['관찰']))
            price = f"entry {_v832_fmt_num(s.get('entry_price'))} / live {_v832_fmt_num(s.get('live_price'))} / hold_trigger {_v832_fmt_num(s.get('hold_trigger_v834'))} / paper_trigger {_v832_fmt_num(s.get('paper_trigger_v834'))} / reached {s.get('reached','-')}"
            flow = f"1m {_v832_fmt_pct(s.get('r1'))} / 3m {_v832_fmt_pct(s.get('r3'))} / 5m {_v832_fmt_pct(s.get('r5'))} / 체결 {_v832_fmt_num(s.get('buy'),2)} / 지속 {_v832_fmt_num(s.get('sustain'),2)}"
            reason = _v834_easy_text(str(s.get('paper_reason_v834') or '-'))
            if len(reason) > 105:
                reason = reason[:102] + '…'
            lines.append(f"  · {s.get('ticker','-')} / {flags} / {price} / {flow} / paper사유 {reason}")
    if detail:
        lines.append('- 닫는 기준: paper 최종보류가 본 trigger_price와 hold 표시 trigger/reached가 같은 원천값으로 표시될 것')
    return [_v834_easy_text(x) for x in lines]


def _v834_oxt_quality_lines() -> List[str]:
    return [
        '- v833 복기증거: OXT는 체결 0.84 / 1분지속 0.83인데 진입반응 +0.00%, 최고 +0.00%, -0.18% 종료',
        '- 판독: 체결은 강했지만 가격이 안 따라온 케이스라 QUALITY-001 증거로 유지',
    ]


def _v834_oxt_late_lines() -> List[str]:
    return [
        '- v833 복기증거: OXT first→open 210초 / S2→open -1초 / 전상승 +0.00%',
        '- 판독: 늦은 진입인지, 애초에 후속 가격반응이 없던 후보인지 분리 필요',
    ]


_V833_ISSUE_ITEMS_PREV = _v830_issue_items if '_v830_issue_items' in globals() else None

def _v834_issue_items() -> List[Dict[str, str]]:
    prev = _V833_ISSUE_ITEMS_PREV() if callable(_V833_ISSUE_ITEMS_PREV) else []
    audit = _v834_paper_mismatch_obj()
    base = audit.get('base') if isinstance(audit.get('base'), dict) else {}
    counts = audit.get('conflict_counts') if isinstance(audit.get('conflict_counts'), Counter) else Counter()
    ready = int(base.get('open_ready_count') or 0)
    old_path_count = int(audit.get('old_path_count') or 0)
    conflict_short = _v830_counter_line(counts, 4) if counts else '현재 충돌 샘플 없음/관찰'
    paper001 = {
        'id': 'PAPER-001',
        'status': 'OPEN' if (counts or ready > 0) else 'CHECK',
        'title': 'S1 진입준비인데 paper가 막음·판정값 충돌',
        'short': f'S1 진입준비 {ready} / {conflict_short}',
        'owner': 'paper runtime snapshot → trigger gate 표시값',
        'close': 'paper가 본 trigger_price와 hold 표시 trigger/reached가 같은 원천값으로 일치',
    }
    paper002 = {
        'id': 'PAPER-002',
        'status': 'OPEN' if old_path_count else 'CHECK',
        'title': 'v628 방아쇠 미도달 문구/구경로 확인',
        'short': f'v628 표시 {old_path_count}회 / 실제 구경로인지 단순 문구인지 확인',
        'owner': 'paper final hold reason → main 표시판',
        'close': 'v628 표시가 단순 문자열인지 구버전 판정경로인지 확인하고 단일 본선 문구로 정리',
    }
    out: List[Dict[str, str]] = []
    inserted_paper002 = False
    seen: set = set()
    for raw in prev:
        if not isinstance(raw, dict):
            continue
        pid = str(raw.get('id') or '')
        if pid == 'PAPER-001':
            if 'PAPER-001' not in seen:
                out.append(dict(paper001)); seen.add('PAPER-001')
            if 'PAPER-002' not in seen:
                out.append(dict(paper002)); seen.add('PAPER-002'); inserted_paper002 = True
            continue
        p = dict(raw)
        if pid == 'QUALITY-001':
            p['status'] = 'OPEN'
            p['short'] = '체결은 강한데 가격이 안 따라옴 37 / OXT 체결0.84·지속0.83·최고+0.00·-0.18 종료'
            p['close'] = '가격후행 성공과 체결착시를 분리하고, OXT형 무반응 진입을 후속검증 완료'
        elif pid == 'LATE-001':
            p['status'] = 'OPEN'
            p['short'] = 'OXT first→open 210초 늦은 진입 의심 / paper 전달·trigger대기·후속무반응 분리 필요'
            p['close'] = 'paper 전달 지연·trigger대기·진짜 추격·후속무반응을 분리'
        if pid and pid not in seen:
            out.append(p); seen.add(pid)
    if 'PAPER-001' not in seen:
        # Insert after TRIGGER-001 when possible.
        new=[]; done=False
        for p in out:
            new.append(p)
            if p.get('id') == 'TRIGGER-001':
                new.append(dict(paper001)); new.append(dict(paper002)); done=True
        out = new if done else [dict(paper001), dict(paper002)] + out
    elif not inserted_paper002 and 'PAPER-002' not in seen:
        new=[]
        for p in out:
            new.append(p)
            if p.get('id') == 'PAPER-001':
                new.append(dict(paper002))
        out = new
    return out

_v830_issue_items = _v834_issue_items  # type: ignore[assignment]


def _v834_next_action_lines() -> List[str]:
    return [
        '- 지금은 조건 변경 금지. v834는 paper 판정값 충돌과 복기 문제를 장부에 고정한 버전',
        '- 우선 확인: /batch → /paper_gate_audit → /issue_ledger → /trigger_audit → /quality_board',
        '- 다음 수술 선택: paper trigger 표시값 단일화 → v628 문구/구경로 확인 → OXT형 무반응 진입 분리 순서',
    ]

_v830_next_action_lines = _v834_next_action_lines  # type: ignore[assignment]


def _v834_batch_text(outputs: Optional[Dict[str,str]] = None, timings: Optional[List[Dict[str,Any]]] = None) -> str:
    since_ts = _v798_batch_marker_ts() if '_v798_batch_marker_ts' in globals() else 0.0
    lines: List[str] = ['📊 코인봇 운영판 /batch · v834']
    lines += ['① 적용/성과'] + _v809_apply_short_lines()[:3] + _v811_score_short_lines()[:3]
    lines += ['', '② 지금 병목'] + _v828_structure_digest_lines()[:5]
    lines += ['', '③ 자료 오래됨 판정 확인'] + _v833_source_audit_lines(detail=False)[:6]
    lines += ['', '④ paper 판정값 충돌 확인'] + _v834_paper_mismatch_lines(detail=False)[:8]
    lines += ['', '⑤ TRIGGER-001 세부분류'] + _v830_trigger_classification_lines(detail=False)[:4]
    lines += ['', '⑥ paper/최근 매매 해석'] + [f"- OPEN {_v650_open_count() if '_v650_open_count' in globals() else '-'}"] + _v809_recent_trade_short_lines(since_ts)[:2] + _v828_recent_loss_digest_lines(since_ts)[:2]
    lines += ['', '⑦ 방아쇠/놓침'] + _v828_preopen_digest_lines()[:3] + _v830_missed_digest_lines()[:3]
    lines += ['', '⑧ 품질/늦은진입 증거'] + _v834_oxt_quality_lines() + _v834_oxt_late_lines()[:1]
    lines += ['', '⑨ 문제장부'] + _v830_issue_ledger_chat_lines(8)
    lines += ['', '⑩ 다음'] + _v834_next_action_lines()
    return _v834_easy_text('\n'.join(str(x) for x in lines))


def _v834_issue_ledger_text() -> str:
    lines = ['🧾 문제장부 /issue_ledger · v834']
    lines += _v830_issue_ledger_detail_lines()
    lines += ['', '[PAPER-001 paper 판정값 충돌]'] + _v834_paper_mismatch_lines(detail=True)
    lines += ['', '[PAPER-002 v628 문구/구경로 확인]']
    lines += [f"- 판독: {'❌ v628 표시가 남아 실제 구경로인지 확인 필요' if int(_v834_paper_mismatch_obj().get('old_path_count') or 0) else '🟡 현재 v628 표시 샘플 없음/관찰'}"]
    lines += [f"- 대상: v628 표시 {int(_v834_paper_mismatch_obj().get('old_path_count') or 0)}회"]
    lines += ['- 닫는 기준: 단순 과거 문구인지, 실제 구버전 paper gate가 살아있는지 확인 완료']
    lines += ['', '[QUALITY-001 OXT 체결착시 증거]'] + _v834_oxt_quality_lines()
    lines += ['', '[LATE-001 OXT 늦은진입 증거]'] + _v834_oxt_late_lines()
    lines += ['', '[TRIGGER-001 세부분류]'] + _v830_trigger_classification_lines(detail=True)
    lines += ['', '[다음]'] + _v834_next_action_lines()
    return _v834_easy_text('\n'.join(str(x) for x in lines))


def _v834_paper_gate_audit_text() -> str:
    lines = ['🧪 PAPER-001 paper 판정값 충돌 확인 /paper_gate_audit · v834']
    lines += _v834_paper_mismatch_lines(detail=True)
    lines += ['', '[기존 S1 hold→paper 검산]'] + _v832_paper_gate_audit_lines(detail=True)
    lines += ['', '[장부]'] + _v830_issue_ledger_chat_lines(8)
    return _v834_easy_text('\n'.join(str(x) for x in lines))


def _v834_trigger_audit_text() -> str:
    lines = ['🧨 TRIGGER-001 세부분류 /trigger_audit · v834']
    lines += _v830_line_trigger_audit_lines()
    lines += ['', '[세부분류]'] + _v830_trigger_classification_lines(detail=True)
    lines += ['', '[PAPER-001 연결 참고]'] + _v834_paper_mismatch_lines(detail=False)[:8]
    lines += ['', '[장부]'] + _v830_issue_ledger_chat_lines(8)
    return _v834_easy_text('\n'.join(str(x) for x in lines))


def _v834_structure_board_text() -> str:
    lines = [
        '📊 구조판 /structure_board · v834',
        '- 기준: candle_worker/strategy canonical row + paper runtime snapshot. main 재계산 없음.',
        '- 목적: paper가 같은 후보를 도달/미도달로 다르게 말하는지 확인한다. 조건 변경 없음.',
        '',
        '① 구조/병목 판독',
    ]
    lines += _v828_structure_digest_lines()
    lines += ['', '② paper 판정값 충돌 확인'] + _v834_paper_mismatch_lines(detail=False)
    lines += ['', '③ 자료 오래됨 판정 확인'] + _v833_source_audit_lines(detail=False)[:6]
    lines += ['', '④ TRIGGER-001 세부분류'] + _v830_trigger_classification_lines(detail=False)[:6]
    lines += ['', '⑤ 문제장부'] + _v830_issue_ledger_chat_lines(8)
    lines += ['', '⑥ 다음'] + _v834_next_action_lines()[:2]
    return _v834_easy_text('\n'.join(str(x) for x in lines))


def _v834_source_audit_text() -> str:
    lines = ['🧭 SOURCE-001 자료 오래됨 판정 확인 /source_audit · v834']
    lines += _v833_source_audit_lines(detail=True)
    lines += ['', '[장부]'] + _v830_issue_ledger_chat_lines(8)
    return _v834_easy_text('\n'.join(str(x) for x in lines))


def _v834_batch_summary_text(cmds: List[str], outputs: Dict[str,str], timings: List[Dict[str,Any]], recv_delay: float, total_sec: float, chat_body: str = '') -> str:
    global _V797_PENDING_BATCH_MARKER_TS
    batch_until = now_ts(); _V797_PENDING_BATCH_MARKER_TS = batch_until
    since_ts = _v798_batch_marker_ts() if '_v798_batch_marker_ts' in globals() else 0.0
    lines=['코인봇 묶음 요약집 v834', f'- 생성: {_v800_kst_text(batch_until)}', f'- 메인봇: {BOT_VERSION} / {V650_BUILD_LABEL}', f'- 접수지연: {recv_delay:.2f}s / 처리합계: {total_sec:.2f}s', '', '[명령 처리시간]']
    for t in timings:
        lines.append(f"- {'✅' if not t.get('error') else '❌'} /{t.get('name','?')}: {float(t.get('sec') or 0):.2f}s / {'OK' if not t.get('error') else 'ERR'}")
    lines += ['', '[채팅 운영판]', _v650_safe_body(chat_body or _v834_batch_text(outputs, timings), 7600), '']
    lines += ['', '[문제장부 전체]'] + _v830_issue_ledger_detail_lines()
    lines += ['', '[PAPER-001 paper 판정값 충돌 상세]'] + _v834_paper_mismatch_lines(detail=True)
    lines += ['', '[PAPER-002 v628 문구/구경로 확인 상세]'] + [f"- v628 표시 {int(_v834_paper_mismatch_obj().get('old_path_count') or 0)}회", '- 실제 구경로인지 단순 문구인지 확인 대상']
    lines += ['', '[QUALITY-001/OXT 증거]'] + _v834_oxt_quality_lines()
    lines += ['', '[LATE-001/OXT 증거]'] + _v834_oxt_late_lines()
    lines += ['', '[SOURCE-001 자료 오래됨 판정 상세]'] + _v833_source_audit_lines(detail=True)
    lines += ['', '[TRIGGER-001 세부분류 상세]'] + _v830_trigger_classification_lines(detail=True)
    lines += ['', '[구조선→방아쇠 검산 상세]'] + _v830_line_trigger_audit_lines()
    lines += ['', '[명령별 짧은 요약]'] + _v817_command_summary_lines(outputs, timings, cmds)
    lines += ['', '[전체 상세 요약]', _v650_safe_body(_v833_easy_text(_v807_batch_text()), 10000), '']
    lines += ['', '[MTF 구조판 상세]'] + [_v833_easy_text('\n'.join(_v826_structure_short_lines()))]
    lines += _v799_trade_detail_lines_range(since_ts, batch_until)
    lines += ['', '[최근 산 후보 원인 요약]'] + _v828_recent_loss_digest_lines(since_ts)
    lines += ['', '[통합 검증판 상세]'] + [_v833_easy_text('\n'.join(_v807_integrated_validation_lines(since_ts, batch_until, compact=False)))]
    lines += ['', '[가격반응 지연·체결착시 품질판 상세]'] + [_v833_easy_text('\n'.join(_v807_price_lag_quality_lines(10) + _v810_quality_route_lines()))]
    lines += ['', '[OPEN직전 보류 사후검증]'] + _v810_preopen_review_lines(10)
    lines += ['', '[아까운 후보 / 놓친 후보 상세]'] + _v805_missed_summary_lines(10)
    lines += ['', '[명령별 상세]']
    for name in cmds:
        lines += ['', f'/{name}', _v650_safe_body(_v834_easy_text(outputs.get(name,'')), 5200)]
    return _v834_easy_text('\n'.join(str(x) for x in lines))

COMMANDS['batch'] = _v834_batch_text
COMMANDS['summary'] = _v834_batch_text
COMMANDS['pbatch'] = _v834_batch_text
COMMANDS['structure_board'] = _v834_structure_board_text
COMMANDS['structure'] = _v834_structure_board_text
COMMANDS['issue_ledger'] = _v834_issue_ledger_text
COMMANDS['ledger'] = _v834_issue_ledger_text
COMMANDS['trigger_audit'] = _v834_trigger_audit_text
COMMANDS['trigger'] = _v834_trigger_audit_text
COMMANDS['paper_gate_audit'] = _v834_paper_gate_audit_text
COMMANDS['paper_audit'] = _v834_paper_gate_audit_text
COMMANDS['hold_audit'] = _v834_paper_gate_audit_text
COMMANDS['paper_mismatch_audit'] = _v834_paper_gate_audit_text
COMMANDS['gate_mismatch'] = _v834_paper_gate_audit_text
COMMANDS['source_audit'] = _v834_source_audit_text
COMMANDS['stale_audit'] = _v834_source_audit_text
COMMANDS['data_age'] = _v834_source_audit_text


def batch_handler(update, context):  # type: ignore[override]
    try:
        msg_date=getattr(getattr(update,'message',None),'date',None)
        recv_delay=time.time()-msg_date.timestamp() if hasattr(msg_date,'timestamp') else 0.0
    except Exception:
        recv_delay=0.0
    cmds = _v820_select_batch_cmds(getattr(context,'args',None) or [])
    stime=time.time(); timings=[]; outputs={}
    _v811_begin_batch_source_lock()
    try:
        multi = len(cmds) > 1
        if multi:
            try: send(update, f'📊 묶음 시작 · {len(cmds)}개 명령 / paper판정충돌 장부txt(v834) · 지연 {recv_delay:.2f}s')
            except Exception: pass
        total_cmds=len(cmds)
        for idx, name in enumerate(cmds, start=1):
            fn=COMMANDS.get(name); t0=time.time(); err=None
            if not fn:
                body=f'❌ /{name} 연결 없음'; err='no_handler'
            else:
                try: body=fn()
                except Exception as exc:
                    body=f'❌ /{name} 오류 {exc.__class__.__name__}: {exc}'; err=f'{exc.__class__.__name__}: {exc}'; log_error(f'v834_batch_{name}', exc)
            body = _v834_easy_text(body)
            sec=time.time()-t0
            timings.append({'name':name,'sec':sec,'error':err}); outputs[name]=body
            try:
                if multi:
                    send(update, _v817_command_short_block(idx, total_cmds, name, body, sec, err))
                else:
                    send(update, body)
            except Exception as exc: log_error('v834_batch_send', exc)
        total=time.time()-stime
        chat_body = outputs.get(cmds[0], '') if len(cmds) == 1 else _v834_batch_text(outputs, timings)
        try:
            status=_v650_send_summary_file(update, _v834_batch_summary_text(cmds, outputs, timings, recv_delay, total, chat_body=chat_body))
        except Exception as exc:
            status=f'txt 생성실패 {exc.__class__.__name__}'; log_error('v834_batch_summary_file', exc)
        mark='✅' if '전송완료' in status else '⚠️'; del_mark='✅' if '서버삭제' in status else ('❌' if '전송완료' in status else '❔')
        try: send(update, f'📎 txt {mark} / 삭제 {del_mark} / {total:.2f}s')
        except Exception: pass
    finally:
        _v811_end_batch_source_lock()



# =============================================================================
# main_bot v2.13.835: ledger/disk cleanup status board
# - Adds LEDGER-001/DISK-001 to issue ledger.
# - Adds /cleanup_status /ledger_cleanup /disk_cleanup.
# - Reads paper cleanup state and disk facts only; no S1/S2/S3, exit, trigger formula,
#   paper OPEN permission, or guard changes.
# =============================================================================
V650_BUILD_LABEL = 'ledger_disk_rotation_cleanup_v835_2026-06-11'
BOT_VERSION = '수익형 v2.13.835'


def _v835_file_mb(path: Path) -> float:
    try:
        return round(float(path.stat().st_size) / 1024.0 / 1024.0, 2)
    except Exception:
        return 0.0


def _v835_file_age(path: Path) -> float:
    try:
        return max(0.0, now_ts() - path.stat().st_mtime)
    except Exception:
        return 0.0


def _v835_disk_obj() -> Dict[str, Any]:
    try:
        import shutil
        du = shutil.disk_usage(str(BASE_DIR))
        total = float(du.total or 1)
        return {
            'total_gb': round(total / 1024 / 1024 / 1024, 2),
            'used_gb': round(float(du.used) / 1024 / 1024 / 1024, 2),
            'free_gb': round(float(du.free) / 1024 / 1024 / 1024, 2),
            'used_pct': round(float(du.used) / total * 100.0, 1),
        }
    except Exception:
        return {'total_gb': 0, 'used_gb': 0, 'free_gb': 0, 'used_pct': 0}


def _v835_protected_cleanup_names() -> set:
    return {
        'paper_bot_open.json', 'paper_bot_closed.jsonl', 'paper_bot_trade_log.jsonl',
        'paper_bot_open_positions.json', 'paper_bot_score_cache.json', 'paper_bot_review_cache.json',
        'paper_bot_status.json', 'clean_strategy_worker_status.json', 'clean_candidate_latest_snapshot.json',
        'DEPLOY_TARGET.txt', 'DEPLOY_BUNDLE.json', 'bot.py', 'paper_bot.py', 'strategy_worker.py',
    }


def _v835_large_files(limit: int = 10) -> List[Dict[str, Any]]:
    out: List[Dict[str, Any]] = []
    protected = _v835_protected_cleanup_names()
    try:
        for path in BASE_DIR.iterdir():
            try:
                if not path.is_file():
                    continue
                mb = _v835_file_mb(path)
                if mb < 5.0:
                    continue
                out.append({
                    'name': path.name,
                    'mb': mb,
                    'age_sec': round(_v835_file_age(path), 1),
                    'protected': path.name in protected,
                })
            except Exception:
                pass
    except Exception:
        pass
    out.sort(key=lambda x: float(x.get('mb') or 0.0), reverse=True)
    return out[:limit]


def _v835_cleanup_state() -> Dict[str, Any]:
    obj = _v650_load(BASE_DIR / 'paper_bot_cleanup_state.json', {}) if '_v650_load' in globals() else {}
    return obj if isinstance(obj, dict) else {}


def _v835_cleanup_v835_state(cleanup: Optional[Dict[str, Any]] = None) -> Dict[str, Any]:
    cleanup = cleanup if isinstance(cleanup, dict) else _v835_cleanup_state()
    for key in ('ledger_disk_rotation_v835', 'broad_rotation_v835', 'disk_rotation_v835'):
        v = cleanup.get(key)
        if isinstance(v, dict):
            return v
    return {}


def _v835_int(v: Any, default: int = 0) -> int:
    try:
        if v is None or v == '':
            return default
        return int(float(v))
    except Exception:
        return default


def _v835_float(v: Any, default: float = 0.0) -> float:
    try:
        if v is None or v == '':
            return default
        return float(v)
    except Exception:
        return default


def _v835_cleanup_summary_obj() -> Dict[str, Any]:
    cleanup = _v835_cleanup_state()
    v835 = _v835_cleanup_v835_state(cleanup)
    v798 = cleanup.get('short_rotation_v798') if isinstance(cleanup.get('short_rotation_v798'), dict) else {}
    v783 = cleanup.get('broad_rotation_v783') if isinstance(cleanup.get('broad_rotation_v783'), dict) else {}
    disk = _v835_disk_obj()
    large = []
    if isinstance(v835.get('large_file_top_outside_target'), list):
        large = v835.get('large_file_top_outside_target') or []
    elif isinstance(v798.get('large_file_top_outside_target'), list):
        large = v798.get('large_file_top_outside_target') or []
    elif isinstance(v783.get('large_file_top_outside_target'), list):
        large = v783.get('large_file_top_outside_target') or []
    if not large:
        large = _v835_large_files(8)
    updated = _v835_float(v835.get('updated_at'), 0.0) or _v835_float(cleanup.get('updated_at'), 0.0)
    age = max(0.0, now_ts() - updated) if updated else -1.0
    return {
        'cleanup': cleanup,
        'v835': v835,
        'v798': v798,
        'v783': v783,
        'disk': disk,
        'large': large,
        'age_sec': age,
        'deleted_files': _v835_int(v835.get('deleted_files'), 0) + _v835_int(v835.get('pruned_jsonl_files'), 0),
        'deleted_mb': round(_v835_float(v835.get('deleted_mb'), 0.0) + _v835_float(v835.get('trimmed_mb'), 0.0), 2),
        'archived_done': _v835_int(v835.get('done_archived'), 0),
        'open_kept': _v835_int(v835.get('open_kept'), 0),
        'check_kept': _v835_int(v835.get('check_kept'), 0),
        'sample_compacted': _v835_int(v835.get('sample_compacted'), 0) + _v835_int(v835.get('jsonl_removed_lines'), 0),
        'errors': _v835_int(v835.get('errors'), 0) + _v835_int(cleanup.get('errors_v798'), 0) + _v835_int(cleanup.get('errors_v783'), 0),
    }


def _v835_cleanup_status_lines(detail: bool = False) -> List[str]:
    obj = _v835_cleanup_summary_obj()
    v835 = obj.get('v835') if isinstance(obj.get('v835'), dict) else {}
    disk = obj.get('disk') if isinstance(obj.get('disk'), dict) else {}
    large = obj.get('large') if isinstance(obj.get('large'), list) else []
    age = _v835_float(obj.get('age_sec'), -1.0)
    if age >= 0 and age <= 180:
        verdict = '✅ 순환정리 상태 최신'
    elif age >= 0:
        verdict = '🟡 순환정리 상태 오래됨: paper cycle 갱신 확인'
    else:
        verdict = '🟡 순환정리 상태파일 없음: paper cleanup 갱신 대기'
    lines = [f'- 판독: {verdict}']
    lines.append(f"- 디스크: 사용 {disk.get('used_pct', 0)}% / 남음 {disk.get('free_gb', 0)}GB")
    if age >= 0:
        lines.append(f'- cleanup age: {age:.1f}s')
    else:
        lines.append('- cleanup age: -')
    lines.append(f"- 이번 정리: 삭제/축약 파일 {obj.get('deleted_files', 0)}개 / 회수 {obj.get('deleted_mb', 0)}MB / 실패 {obj.get('errors', 0)}개")
    lines.append(f"- 장부 정리: OPEN 유지 {obj.get('open_kept', 0)} / CHECK 유지 {obj.get('check_kept', 0)} / DONE 보관 {obj.get('archived_done', 0)} / 샘플축약 {obj.get('sample_compacted', 0)}")
    if v835:
        lines.append('- 보존: paper OPEN/CLOSED/trade_log/score 핵심 원장 보존')
    else:
        lines.append('- 보존: paper OPEN/CLOSED/trade_log/score 핵심 원장 보존 · v835 정리결과 대기')
    if large:
        def _lf(x: Any) -> str:
            if isinstance(x, dict):
                return f"{x.get('name','-')} {x.get('mb','-')}MB"
            return str(x)
        lines.append('- 큰 파일 TOP: ' + ' / '.join(_lf(x) for x in large[:5]))
    if detail:
        policy = str(v835.get('policy') or 'OPEN/CLOSED/trade_log/score는 보존, 문제장부 DONE/오래된 샘플/임시cache/log만 순환정리')
        lines += [
            '- 정책: ' + policy,
            '- 금지: 미해결 OPEN/CHECK 장부 삭제 금지 / paper 원장 삭제 금지 / 현재 OPEN trace 삭제 금지',
        ]
        by_reason = v835.get('by_reason') if isinstance(v835.get('by_reason'), dict) else {}
        if by_reason:
            parts=[]
            for k, val in list(by_reason.items())[:8]:
                if isinstance(val, dict):
                    parts.append(f"{k} {val.get('files', 0)}개/{round(float(val.get('bytes', 0))/1024/1024,2)}MB")
            if parts:
                lines.append('- 사유별 정리: ' + ' / '.join(parts))
    return lines


_V835_PREV_ISSUE_ITEMS = _v830_issue_items if '_v830_issue_items' in globals() else None

def _v835_issue_items() -> List[Dict[str, str]]:
    prev = _V835_PREV_ISSUE_ITEMS() if callable(_V835_PREV_ISSUE_ITEMS) else []
    obj = _v835_cleanup_summary_obj()
    disk = obj.get('disk') if isinstance(obj.get('disk'), dict) else {}
    free = _v835_float(disk.get('free_gb'), 0.0)
    errors = _v835_int(obj.get('errors'), 0)
    cleanup_age = _v835_float(obj.get('age_sec'), -1.0)
    ledger_status = 'CHECK' if errors == 0 else 'OPEN'
    disk_status = 'OPEN' if free and free < 3.0 else ('CHECK' if free and free < 5.0 else 'DONE')
    add_items = [
        {
            'id': 'LEDGER-001',
            'status': ledger_status,
            'title': '전체 장부/복기/샘플 순환정리',
            'short': f"OPEN 유지 {obj.get('open_kept',0)} / CHECK 유지 {obj.get('check_kept',0)} / DONE 보관 {obj.get('archived_done',0)} / 샘플축약 {obj.get('sample_compacted',0)} / age {cleanup_age:.1f}s",
            'owner': 'paper cleanup state → main cleanup board',
            'close': 'OPEN/CHECK 미해결 항목은 유지하고 DONE/오래된 샘플/반복노이즈만 보관·축약',
        },
        {
            'id': 'DISK-001',
            'status': disk_status,
            'title': '디스크 큰 파일 순환정리',
            'short': f"남음 {disk.get('free_gb',0)}GB / 사용 {disk.get('used_pct',0)}% / 회수 {obj.get('deleted_mb',0)}MB / 실패 {errors}",
            'owner': 'paper cleanup owner + main resource board',
            'close': '남은 용량이 안정권이고 큰 로그/cache가 정책 대상에 들어가며 정리 결과가 표시됨',
        },
    ]
    seen=set(); out=[]
    for raw in prev:
        if not isinstance(raw, dict):
            continue
        pid=str(raw.get('id') or '')
        if pid in ('LEDGER-001','DISK-001'):
            continue
        out.append(dict(raw)); seen.add(pid)
    # Put cleanup items near the end but before pure DONE items when possible.
    out.extend(add_items)
    return out

_v830_issue_items = _v835_issue_items  # type: ignore[assignment]


def _v835_next_action_lines() -> List[str]:
    return [
        '- 지금은 조건 변경 금지. v835는 장부/복기/디스크 순환정리 기능 추가 버전',
        '- 우선 확인: /batch → /cleanup_status → /issue_ledger → /paper_gate_audit → /errorlog',
        '- 다음 수술 선택: paper trigger 표시값 단일화 → v628 문구/구경로 확인 → OXT형 무반응 진입 분리',
    ]

_v830_next_action_lines = _v835_next_action_lines  # type: ignore[assignment]


def _v835_cleanup_status_text() -> str:
    lines = ['🧹 장부/디스크 순환정리 /cleanup_status · v835']
    lines += _v835_cleanup_status_lines(detail=True)
    lines += ['', '[장부 연결]'] + _v830_issue_ledger_chat_lines(10)
    return _v834_easy_text('\n'.join(str(x) for x in lines))


def _v835_batch_text(outputs: Optional[Dict[str,str]] = None, timings: Optional[List[Dict[str,Any]]] = None) -> str:
    since_ts = _v798_batch_marker_ts() if '_v798_batch_marker_ts' in globals() else 0.0
    lines: List[str] = ['📊 코인봇 운영판 /batch · v835']
    lines += ['① 적용/성과'] + _v809_apply_short_lines()[:3] + _v811_score_short_lines()[:3]
    lines += ['', '② 지금 병목'] + _v828_structure_digest_lines()[:5]
    lines += ['', '③ 장부/디스크 순환정리'] + _v835_cleanup_status_lines(detail=False)[:7]
    lines += ['', '④ paper 판정값 충돌 확인'] + _v834_paper_mismatch_lines(detail=False)[:8]
    lines += ['', '⑤ TRIGGER-001 세부분류'] + _v830_trigger_classification_lines(detail=False)[:4]
    lines += ['', '⑥ paper/최근 매매 해석'] + [f"- OPEN {_v650_open_count() if '_v650_open_count' in globals() else '-'}"] + _v809_recent_trade_short_lines(since_ts)[:2] + _v828_recent_loss_digest_lines(since_ts)[:2]
    lines += ['', '⑦ 방아쇠/놓침'] + _v828_preopen_digest_lines()[:3] + _v830_missed_digest_lines()[:3]
    lines += ['', '⑧ 품질/늦은진입 증거'] + _v834_oxt_quality_lines() + _v834_oxt_late_lines()[:1]
    lines += ['', '⑨ 문제장부'] + _v830_issue_ledger_chat_lines(10)
    lines += ['', '⑩ 다음'] + _v835_next_action_lines()
    return _v834_easy_text('\n'.join(str(x) for x in lines))


def _v835_issue_ledger_text() -> str:
    lines = ['🧾 문제장부 /issue_ledger · v835']
    lines += _v830_issue_ledger_detail_lines()
    lines += ['', '[LEDGER-001 장부/복기 순환정리]'] + _v835_cleanup_status_lines(detail=True)
    lines += ['', '[PAPER-001 paper 판정값 충돌]'] + _v834_paper_mismatch_lines(detail=True)
    lines += ['', '[PAPER-002 v628 문구/구경로 확인]']
    lines += [f"- 판독: {'❌ v628 표시가 남아 실제 구경로인지 확인 필요' if int(_v834_paper_mismatch_obj().get('old_path_count') or 0) else '🟡 현재 v628 표시 샘플 없음/관찰'}"]
    lines += [f"- 대상: v628 표시 {int(_v834_paper_mismatch_obj().get('old_path_count') or 0)}회"]
    lines += ['- 닫는 기준: 단순 과거 문구인지, 실제 구버전 paper gate가 살아있는지 확인 완료']
    lines += ['', '[QUALITY-001 OXT 체결착시 증거]'] + _v834_oxt_quality_lines()
    lines += ['', '[LATE-001 OXT 늦은진입 증거]'] + _v834_oxt_late_lines()
    lines += ['', '[TRIGGER-001 세부분류]'] + _v830_trigger_classification_lines(detail=True)
    lines += ['', '[다음]'] + _v835_next_action_lines()
    return _v834_easy_text('\n'.join(str(x) for x in lines))


def _v835_paper_gate_audit_text() -> str:
    lines = ['🧪 PAPER-001 paper 판정값 충돌 확인 /paper_gate_audit · v835']
    lines += _v834_paper_mismatch_lines(detail=True)
    lines += ['', '[정리상태 참고]'] + _v835_cleanup_status_lines(detail=False)[:5]
    lines += ['', '[기존 S1 hold→paper 검산]'] + _v832_paper_gate_audit_lines(detail=True)
    lines += ['', '[장부]'] + _v830_issue_ledger_chat_lines(10)
    return _v834_easy_text('\n'.join(str(x) for x in lines))


def _v835_trigger_audit_text() -> str:
    lines = ['🧨 TRIGGER-001 세부분류 /trigger_audit · v835']
    lines += _v830_line_trigger_audit_lines()
    lines += ['', '[세부분류]'] + _v830_trigger_classification_lines(detail=True)
    lines += ['', '[PAPER-001 연결 참고]'] + _v834_paper_mismatch_lines(detail=False)[:8]
    lines += ['', '[장부]'] + _v830_issue_ledger_chat_lines(10)
    return _v834_easy_text('\n'.join(str(x) for x in lines))


def _v835_structure_board_text() -> str:
    lines = [
        '📊 구조판 /structure_board · v835',
        '- 기준: candle_worker/strategy canonical row + paper runtime snapshot. main 재계산 없음.',
        '- 목적: paper 판정값 충돌과 장부/디스크 정리 상태를 같이 확인한다. 조건 변경 없음.',
        '',
        '① 구조/병목 판독',
    ]
    lines += _v828_structure_digest_lines()
    lines += ['', '② 장부/디스크 순환정리'] + _v835_cleanup_status_lines(detail=False)[:7]
    lines += ['', '③ paper 판정값 충돌 확인'] + _v834_paper_mismatch_lines(detail=False)
    lines += ['', '④ TRIGGER-001 세부분류'] + _v830_trigger_classification_lines(detail=False)[:6]
    lines += ['', '⑤ 문제장부'] + _v830_issue_ledger_chat_lines(10)
    lines += ['', '⑥ 다음'] + _v835_next_action_lines()[:2]
    return _v834_easy_text('\n'.join(str(x) for x in lines))


def _v835_batch_summary_text(cmds: List[str], outputs: Dict[str,str], timings: List[Dict[str,Any]], recv_delay: float, total_sec: float, chat_body: str = '') -> str:
    global _V797_PENDING_BATCH_MARKER_TS
    batch_until = now_ts(); _V797_PENDING_BATCH_MARKER_TS = batch_until
    since_ts = _v798_batch_marker_ts() if '_v798_batch_marker_ts' in globals() else 0.0
    lines=['코인봇 묶음 요약집 v835', f'- 생성: {_v800_kst_text(batch_until)}', f'- 메인봇: {BOT_VERSION} / {V650_BUILD_LABEL}', f'- 접수지연: {recv_delay:.2f}s / 처리합계: {total_sec:.2f}s', '', '[명령 처리시간]']
    for t in timings:
        lines.append(f"- {'✅' if not t.get('error') else '❌'} /{t.get('name','?')}: {float(t.get('sec') or 0):.2f}s / {'OK' if not t.get('error') else 'ERR'}")
    lines += ['', '[채팅 운영판]', _v650_safe_body(chat_body or _v835_batch_text(outputs, timings), 7600), '']
    lines += ['', '[문제장부 전체]'] + _v830_issue_ledger_detail_lines()
    lines += ['', '[장부/디스크 순환정리 상세]'] + _v835_cleanup_status_lines(detail=True)
    lines += ['', '[PAPER-001 paper 판정값 충돌 상세]'] + _v834_paper_mismatch_lines(detail=True)
    lines += ['', '[PAPER-002 v628 문구/구경로 확인 상세]'] + [f"- v628 표시 {int(_v834_paper_mismatch_obj().get('old_path_count') or 0)}회", '- 실제 구경로인지 단순 문구인지 확인 대상']
    lines += ['', '[QUALITY-001/OXT 증거]'] + _v834_oxt_quality_lines()
    lines += ['', '[LATE-001/OXT 증거]'] + _v834_oxt_late_lines()
    lines += ['', '[SOURCE-001 자료 오래됨 판정 상세]'] + _v833_source_audit_lines(detail=True)
    lines += ['', '[TRIGGER-001 세부분류 상세]'] + _v830_trigger_classification_lines(detail=True)
    lines += ['', '[구조선→방아쇠 검산 상세]'] + _v830_line_trigger_audit_lines()
    lines += ['', '[명령별 짧은 요약]'] + _v817_command_summary_lines(outputs, timings, cmds)
    lines += ['', '[전체 상세 요약]', _v650_safe_body(_v833_easy_text(_v807_batch_text()), 10000), '']
    lines += ['', '[MTF 구조판 상세]'] + [_v833_easy_text('\n'.join(_v826_structure_short_lines()))]
    lines += _v799_trade_detail_lines_range(since_ts, batch_until)
    lines += ['', '[최근 산 후보 원인 요약]'] + _v828_recent_loss_digest_lines(since_ts)
    lines += ['', '[통합 검증판 상세]'] + [_v833_easy_text('\n'.join(_v807_integrated_validation_lines(since_ts, batch_until, compact=False)))]
    lines += ['', '[가격반응 지연·체결착시 품질판 상세]'] + [_v833_easy_text('\n'.join(_v807_price_lag_quality_lines(10) + _v810_quality_route_lines()))]
    lines += ['', '[OPEN직전 보류 사후검증]'] + _v810_preopen_review_lines(10)
    lines += ['', '[아까운 후보 / 놓친 후보 상세]'] + _v805_missed_summary_lines(10)
    lines += ['', '[명령별 상세]']
    for name in cmds:
        lines += ['', f'/{name}', _v650_safe_body(_v834_easy_text(outputs.get(name,'')), 5200)]
    return _v834_easy_text('\n'.join(str(x) for x in lines))

COMMANDS['batch'] = _v835_batch_text
COMMANDS['summary'] = _v835_batch_text
COMMANDS['pbatch'] = _v835_batch_text
COMMANDS['structure_board'] = _v835_structure_board_text
COMMANDS['structure'] = _v835_structure_board_text
COMMANDS['issue_ledger'] = _v835_issue_ledger_text
COMMANDS['ledger'] = _v835_issue_ledger_text
COMMANDS['cleanup_status'] = _v835_cleanup_status_text
COMMANDS['ledger_cleanup'] = _v835_cleanup_status_text
COMMANDS['disk_cleanup'] = _v835_cleanup_status_text
COMMANDS['cleanup'] = _v835_cleanup_status_text
COMMANDS['trigger_audit'] = _v835_trigger_audit_text
COMMANDS['trigger'] = _v835_trigger_audit_text
COMMANDS['paper_gate_audit'] = _v835_paper_gate_audit_text
COMMANDS['paper_audit'] = _v835_paper_gate_audit_text
COMMANDS['hold_audit'] = _v835_paper_gate_audit_text
COMMANDS['paper_mismatch_audit'] = _v835_paper_gate_audit_text
COMMANDS['gate_mismatch'] = _v835_paper_gate_audit_text


def batch_handler(update, context):  # type: ignore[override]
    try:
        msg_date=getattr(getattr(update,'message',None),'date',None)
        recv_delay=time.time()-msg_date.timestamp() if hasattr(msg_date,'timestamp') else 0.0
    except Exception:
        recv_delay=0.0
    cmds = _v820_select_batch_cmds(getattr(context,'args',None) or [])
    stime=time.time(); timings=[]; outputs={}
    _v811_begin_batch_source_lock()
    try:
        multi = len(cmds) > 1
        if multi:
            try: send(update, f'📊 묶음 시작 · {len(cmds)}개 명령 / 장부순환정리 txt(v835) · 지연 {recv_delay:.2f}s')
            except Exception: pass
        total_cmds=len(cmds)
        for idx, name in enumerate(cmds, start=1):
            fn=COMMANDS.get(name); t0=time.time(); err=None
            if not fn:
                body=f'❌ /{name} 연결 없음'; err='no_handler'
            else:
                try: body=fn()
                except Exception as exc:
                    body=f'❌ /{name} 오류 {exc.__class__.__name__}: {exc}'; err=f'{exc.__class__.__name__}: {exc}'; log_error(f'v835_batch_{name}', exc)
            body = _v834_easy_text(body)
            sec=time.time()-t0
            timings.append({'name':name,'sec':sec,'error':err}); outputs[name]=body
            try:
                if multi:
                    send(update, _v817_command_short_block(idx, total_cmds, name, body, sec, err))
                else:
                    send(update, body)
            except Exception as exc: log_error('v835_batch_send', exc)
        total=time.time()-stime
        chat_body = outputs.get(cmds[0], '') if len(cmds) == 1 else _v835_batch_text(outputs, timings)
        try:
            status=_v650_send_summary_file(update, _v835_batch_summary_text(cmds, outputs, timings, recv_delay, total, chat_body=chat_body))
        except Exception as exc:
            status=f'txt 생성실패 {exc.__class__.__name__}'; log_error('v835_batch_summary_file', exc)
        mark='✅' if '전송완료' in status else '⚠️'; del_mark='✅' if '서버삭제' in status else ('❌' if '전송완료' in status else '❔')
        try: send(update, f'📎 txt {mark} / 삭제 {del_mark} / {total:.2f}s')
        except Exception: pass
    finally:
        _v811_end_batch_source_lock()

# =============================================================================
# main_bot v2.13.835: single runtime entrypoint
# =============================================================================


# =============================================================================
# main_bot v2.13.836: menu sync + cleanup policy 강화 + error ledger
# - Adds full command menu/help and MENU-001/ERROR-001 ledger entries.
# - Reads v836 cleanup state including target/protected/age미달 reasons.
# - No strategy conditions, trigger formula, exits, paper OPEN permission, or guard change.
# =============================================================================
BOT_VERSION = '수익형 v2.13.839'
V650_BUILD_LABEL = 'v839_legacy_cache_archive_cleanup_2026-06-11'
_V836_MENU_STATUS_PATH = BASE_DIR / 'clean_menu_command_status.json'


def _v836_json_dump(path: Path, obj: Dict[str, Any]) -> None:
    try:
        tmp = path.with_suffix(path.suffix + '.tmp')
        tmp.write_text(json.dumps(obj, ensure_ascii=False, indent=2), encoding='utf-8')
        os.replace(tmp, path)
    except Exception as exc:
        try: log_error('v836_json_dump', exc)
        except Exception: pass


def _v836_menu_commands() -> List[Tuple[str, str, str]]:
    # (command, description, group)
    return [
        ('batch', '운영 핵심 묶음', '운영'),
        ('health', '시스템/worker/디스크', '운영'),
        ('pstatus', 'paper 상태', '운영'),
        ('errorlog', '새 오류 로그', '운영'),
        ('commands', '명령어 메뉴', '운영'),
        ('structure_board', '구조/병목판', '후보·구조'),
        ('candidate_reason', 'S1 못 간 이유', '후보·구조'),
        ('trigger_audit', '방아쇠 검산', '후보·구조'),
        ('paper_gate_audit', 'paper 진입보류 검산', 'paper'),
        ('paper_handoff', 'paper 전달 상태', 'paper'),
        ('trade_review', '매매 복기', '복기'),
        ('quality_board', '체결착시/가격무반응', '복기'),
        ('validation_board', '통합 검증판', '복기'),
        ('version_score', '버전별 성과', '복기'),
        ('issue_ledger', '문제장부', '장부·정리'),
        ('cleanup_status', '장부/디스크 정리', '장부·정리'),
        ('source_audit', '자료 오래됨 확인', '배관'),
    ]


def _v836_menu_status_obj() -> Dict[str, Any]:
    obj = load_json(_V836_MENU_STATUS_PATH, {}) if 'load_json' in globals() else {}
    return obj if isinstance(obj, dict) else {}


def _v836_set_menu_status(ok: bool, status: str, error: str = '', command_count: int = 0) -> None:
    _v836_json_dump(_V836_MENU_STATUS_PATH, {
        'schema': 'telegram_menu_command_status_v836',
        'ok': bool(ok),
        'status': str(status),
        'error': str(error or ''),
        'command_count': int(command_count or 0),
        'updated_at': now_ts(),
        'updated_text': _v800_kst_text(now_ts()) if '_v800_kst_text' in globals() else str(now_ts()),
        'build': V650_BUILD_LABEL,
        'policy': '메뉴 등록 실패는 매매오류가 아니라 MENU/ERROR 장부로 추적. 조건/청산/paper OPEN 영향 없음.',
    })


def set_commands(updater):  # type: ignore[override]
    cmds = _v836_menu_commands()
    try:
        if BotCommand is None or not getattr(updater, 'bot', None):
            _v836_set_menu_status(False, 'telegram_lib_missing', 'BotCommand unavailable', len(cmds))
            return
        payload = [BotCommand(c, d) for c, d, _g in cmds]
        try:
            updater.bot.set_my_commands(payload, timeout=20)
        except TypeError:
            # Some python-telegram-bot versions do not accept timeout kwarg.
            updater.bot.set_my_commands(payload)
        _v836_set_menu_status(True, 'registered', '', len(cmds))
    except Exception as exc:
        err = f'{exc.__class__.__name__}: {exc}'
        _v836_set_menu_status(False, 'set_commands_failed', err, len(cmds))
        # TimedOut is an external Telegram menu registration issue. Track in ledger,
        # but avoid polluting runtime errorlog as if trading logic broke.
        if 'TimedOut' not in exc.__class__.__name__ and 'timed out' not in str(exc).lower():
            try: log_error('v836_set_commands', exc)
            except Exception: pass


def _v836_commands_text() -> str:
    groups: Dict[str, List[Tuple[str,str]]] = {}
    for cmd, desc, group in _v836_menu_commands():
        groups.setdefault(group, []).append((cmd, desc))
    lines = ['🧭 명령어 메뉴 /commands · v841', '- 자주 쓰는 것만 그룹별로 정리. 조건 변경 없음.']
    order = ['운영', '후보·구조', 'paper', '복기', '장부·정리', '배관']
    for idx, g in enumerate(order, start=1):
        arr = groups.get(g) or []
        if not arr: continue
        lines += ['', f'{idx}️⃣ {g}']
        for c, d in arr:
            lines.append(f'- /{c} · {d}')
    st = _v836_menu_status_obj()
    if st:
        ok = '✅' if st.get('ok') else '🟡'
        lines += ['', '[메뉴 등록 상태]', f"- {ok} {st.get('status','-')} / 명령 {st.get('command_count',0)}개 / {st.get('updated_text','-')}"]
        if st.get('error'):
            lines.append(f"- 오류: {st.get('error')}")
    lines += ['', '[다음 확인]', '- /batch → /cleanup_status → /issue_ledger → /paper_gate_audit → /errorlog']
    return _v834_easy_text('\n'.join(lines)) if '_v834_easy_text' in globals() else '\n'.join(lines)


def _v836_cleanup_summary_obj() -> Dict[str, Any]:
    obj = _v835_cleanup_summary_obj() if '_v835_cleanup_summary_obj' in globals() else {}
    cleanup = _v835_cleanup_state() if '_v835_cleanup_state' in globals() else {}
    v836 = {}
    source_key = ''
    if isinstance(cleanup, dict):
        for key in ('legacy_cache_archive_v839', 'cleanup_policy_v839', 'cleanup_policy_v836', 'ledger_disk_rotation_v836', 'disk_rotation_v836'):
            if isinstance(cleanup.get(key), dict):
                v836 = cleanup.get(key) or {}; source_key = key; break
    if not isinstance(obj, dict): obj = {}
    if v836:
        deleted_mb = (_v835_float(v836.get('deleted_mb'), 0.0) + _v835_float(v836.get('trimmed_mb'), 0.0) +
                      _v835_float(v836.get('compacted_mb'), 0.0) + _v835_float(v836.get('saved_mb'), 0.0))
        obj['v836'] = v836
        obj['cleanup_source_key'] = source_key
        obj['deleted_files'] = (_v835_int(v836.get('deleted_files'), 0) + _v835_int(v836.get('trimmed_files'), 0) +
                                _v835_int(v836.get('pruned_jsonl_files'), 0) + _v835_int(v836.get('compacted_files'), 0) +
                                _v835_int(v836.get('archived_files'), 0))
        obj['deleted_mb'] = round(deleted_mb, 2)
        obj['errors'] = _v835_int(v836.get('errors'), 0)
        obj['open_kept'] = _v835_int(v836.get('open_kept'), obj.get('open_kept',0))
        obj['check_kept'] = _v835_int(v836.get('check_kept'), obj.get('check_kept',0))
        obj['archived_done'] = _v835_int(v836.get('done_archived'), obj.get('archived_done',0))
        obj['sample_compacted'] = _v835_int(v836.get('sample_compacted'), obj.get('sample_compacted',0)) + _v835_int(v836.get('jsonl_removed_lines'), 0)
        obj['legacy_archived_files'] = _v835_int(v836.get('archived_files'), 0)
        obj['legacy_saved_mb'] = _v835_float(v836.get('saved_mb'), 0.0)
        obj['legacy_archive_mb'] = _v835_float(v836.get('archive_mb'), 0.0)
        obj['recreated_empty_files'] = _v835_int(v836.get('recreated_empty_files'), 0)
        obj['age_sec'] = max(0.0, now_ts() - _v835_float(v836.get('updated_at'), now_ts()))
        if isinstance(v836.get('large_file_top'), list): obj['large'] = v836.get('large_file_top')
    return obj


def _v836_cleanup_status_lines(detail: bool = False) -> List[str]:
    obj = _v836_cleanup_summary_obj()
    disk = obj.get('disk') if isinstance(obj.get('disk'), dict) else _v835_disk_obj()
    v836 = obj.get('v836') if isinstance(obj.get('v836'), dict) else {}
    age = _v835_float(obj.get('age_sec'), -1.0)
    errors = _v835_int(obj.get('errors'), 0)
    deleted_mb = _v835_float(obj.get('deleted_mb'), 0.0)
    archived_n = _v835_int(obj.get('legacy_archived_files'), 0)
    if archived_n > 0:
        verdict = '✅ 구형 cache/state 격리정리 실행됨'
    elif deleted_mb > 0:
        verdict = '✅ 순환정리 실행됨'
    elif v836:
        verdict = '🟡 v839 정리 실행됨 · 회수 적음/재생성 대기'
    else:
        verdict = '🟡 v839 구형 cache/state 정리결과 대기'
    lines = [
        f'- 판독: {verdict}',
        f"- 디스크: 사용 {disk.get('used_pct',0)}% / 남음 {disk.get('free_gb',0)}GB",
        f"- cleanup age: {age:.1f}s" if age >= 0 else '- cleanup age: -',
        f"- 이번 정리: 삭제/축약/격리 파일 {obj.get('deleted_files',0)}개 / 회수 {deleted_mb}MB / 실패 {errors}개",
        f"- 구형 cache 격리: {archived_n}개 / 절감 {obj.get('legacy_saved_mb',0)}MB / 압축보관 {obj.get('legacy_archive_mb',0)}MB / 재생성 placeholder {obj.get('recreated_empty_files',0)}개",
        f"- 장부 정리: OPEN 유지 {obj.get('open_kept',0)} / CHECK 유지 {obj.get('check_kept',0)} / DONE 보관 {obj.get('archived_done',0)} / 샘플축약 {obj.get('sample_compacted',0)}",
    ]
    policy = str(v836.get('policy') or '최근 7일 상세 보관, 오래된 raw/cache/log는 압축·삭제. 핵심 원장/score/trade_log는 삭제 금지.')
    lines.append('- 정책: ' + policy)
    large = obj.get('large') if isinstance(obj.get('large'), list) else []
    if large:
        parts=[]
        for x in large[:5]:
            if not isinstance(x, dict): continue
            cls = x.get('class') or ('보호' if x.get('protected') else '대상검토')
            action = x.get('action') or '-'
            parts.append(f"{x.get('name')} {x.get('mb')}MB/{cls}/{action}")
        if parts: lines.append('- 큰 파일 TOP: ' + ' / '.join(parts))
    if detail and v836:
        by_reason = v836.get('by_reason') if isinstance(v836.get('by_reason'), dict) else {}
        if by_reason:
            parts=[]
            for k, val in list(by_reason.items())[:10]:
                if isinstance(val, dict):
                    parts.append(f"{k} {val.get('files',0)}개/{round(float(val.get('bytes',0))/1024/1024,2)}MB")
            if parts: lines.append('- 사유별 정리: ' + ' / '.join(parts))
        archived = v836.get('legacy_archived') if isinstance(v836.get('legacy_archived'), list) else []
        if archived:
            lines.append('- 격리/재생성:')
            for r in archived[:8]:
                if isinstance(r, dict):
                    lines.append(f"  · {r.get('name')} 원본 {r.get('original_mb')}MB → 압축 {r.get('archive_mb')}MB / 절감 {r.get('saved_mb')}MB / {r.get('reason','')}")
        reviewed = v836.get('target_review') if isinstance(v836.get('target_review'), list) else []
        if reviewed:
            lines.append('- 대상분류:')
            for r in reviewed[:8]:
                if isinstance(r, dict):
                    lines.append(f"  · {r.get('name')} {r.get('mb')}MB → {r.get('class')} / {r.get('action')} / {r.get('reason','')}")
    return lines


_V836_PREV_ISSUE_ITEMS = _v830_issue_items if '_v830_issue_items' in globals() else None

def _v836_issue_items() -> List[Dict[str, str]]:
    prev = _V836_PREV_ISSUE_ITEMS() if callable(_V836_PREV_ISSUE_ITEMS) else []
    obj = _v836_cleanup_summary_obj()
    disk = obj.get('disk') if isinstance(obj.get('disk'), dict) else _v835_disk_obj()
    free = _v835_float(disk.get('free_gb'), 0.0)
    deleted_mb = _v835_float(obj.get('deleted_mb'), 0.0)
    errors = _v835_int(obj.get('errors'), 0)
    menu = _v836_menu_status_obj()
    menu_ok = bool(menu.get('ok')) if menu else False
    menu_status = 'DONE' if menu_ok else 'CHECK'
    err_status = 'DONE'
    err_short = '새 오류 없음'
    if menu and (not menu_ok) and ('TimedOut' in str(menu.get('error')) or 'timed out' in str(menu.get('error')).lower()):
        err_status = 'CHECK'; err_short = 'set_commands timeout · 메뉴 등록 재시도/상태 추적'
    elif menu and not menu_ok:
        err_status = 'OPEN'; err_short = f"메뉴 등록 오류: {str(menu.get('error'))[:80]}"
    ledger_status = 'OPEN' if errors else ('CHECK' if deleted_mb <= 0 else 'DONE')
    disk_status = 'OPEN' if free and free < 3.0 else ('CHECK' if free and free < 5.0 else 'DONE')
    add = [
        {'id':'MENU-001','status':menu_status,'title':'명령어 메뉴 최신화','short':f"메뉴등록 {menu.get('status','대기') if menu else '대기'} / 명령 {menu.get('command_count',0) if menu else len(_v836_menu_commands())}개",'owner':'main set_commands + /commands 도움말','close':'실제 사용 가능한 핵심 명령이 텔레그램 메뉴와 /commands에 표시'},
        {'id':'ERROR-001','status':('CHECK' if err_status == 'DONE' else err_status),'title':'v836/v837 출력함수 NameError + 메뉴등록 오류 추적','short':('v839 구형 cache/state 정리 적용 · ' + err_short),'owner':'main 출력 함수 연결 + Telegram command menu registration','close':'/batch·/paper_gate_audit·/commands·/cleanup_status가 모두 정상이고 새 실행 오류 없음'},
        {'id':'OUTPUT-001','status':'CHECK','title':'구버전 출력함수 호출 잔존 제거','short':'v838에서 미정의 호출 제거 완료 · v839에서는 cache/state 정리만 추가','owner':'main /batch 출력 builder','close':'정의 없는 _v숫자_ 함수 호출 0개 + /batch 정상'},
        {'id':'LEDGER-001','status':ledger_status,'title':'전체 장부/복기/샘플 순환정리','short':f"OPEN 유지 {obj.get('open_kept',0)} / CHECK 유지 {obj.get('check_kept',0)} / DONE 보관 {obj.get('archived_done',0)} / 샘플축약 {obj.get('sample_compacted',0)} / 회수 {deleted_mb}MB",'owner':'paper cleanup state → main cleanup board','close':'OPEN/CHECK 미해결은 유지, DONE/오래된 샘플/반복노이즈는 보관·축약'},
        {'id':'DISK-001','status':disk_status,'title':'디스크 큰 파일 순환정리','short':f"남음 {disk.get('free_gb',0)}GB / 사용 {disk.get('used_pct',0)}% / 회수 {deleted_mb}MB / 실패 {errors}",'owner':'paper cleanup owner + main resource board','close':'큰 로그/cache가 보호/정리대상/age미달로 분류되고 정리 결과가 표시됨'},
        {'id':'DISK-002','status':('CHECK' if _v835_int(obj.get('legacy_archived_files'),0) > 0 else 'OPEN'),'title':'구형 cache/state 격리·재생성 정리','short':f"격리 {_v835_int(obj.get('legacy_archived_files'),0)}개 / 절감 {_v835_float(obj.get('legacy_saved_mb'),0.0)}MB / 재생성 {_v835_int(obj.get('recreated_empty_files'),0)}개",'owner':'paper cleanup v839 → worker cache 재생성','close':'candidate_reason/recheck/s1_lifecycle 구형 파일이 격리되고 현재 worker가 새 cache를 재생성'},
    ]
    replace = {x['id'] for x in add}
    out=[]
    for raw in prev:
        if not isinstance(raw, dict): continue
        if str(raw.get('id') or '') in replace: continue
        out.append(dict(raw))
    out.extend(add)
    return out

_v830_issue_items = _v836_issue_items  # type: ignore[assignment]


def _v836_next_action_lines() -> List[str]:
    return [
        '- 지금은 조건 변경 금지. v839는 구형 cache/state 격리정리 + 재생성 대기 버전',
        '- 우선 확인: /batch → /cleanup_status → /issue_ledger → /paper_gate_audit → /errorlog',
        '- 다음 확인: 구형 cache 재생성 상태 → paper trigger 표시값 단일화',
    ]

_v830_next_action_lines = _v836_next_action_lines  # type: ignore[assignment]


def _v836_cleanup_status_text() -> str:
    lines = ['🧹 장부/디스크 순환정리 /cleanup_status · v839']
    lines += _v836_cleanup_status_lines(detail=True)
    lines += ['', '[장부 연결]'] + _v830_issue_ledger_chat_lines(12)
    return _v834_easy_text('\n'.join(lines))


def _v836_batch_text(outputs: Optional[Dict[str,str]] = None, timings: Optional[List[Dict[str,Any]]] = None) -> str:
    lines: List[str] = ['📊 코인봇 운영판 /batch · v839']
    lines += ['① 적용/성과'] + _v809_apply_short_lines()[:3] + _v811_score_short_lines()[:3]
    lines += ['', '② 지금 병목'] + _v828_structure_digest_lines()
    lines += ['', '③ 장부/디스크 순환정리'] + _v836_cleanup_status_lines(detail=False)[:8]
    lines += ['', '④ 명령어 메뉴/오류'] + _v836_commands_text().splitlines()[-4:]
    lines += ['', '⑤ paper 판정값 충돌 확인'] + _v834_paper_mismatch_lines(detail=False)
    lines += ['', '⑥ TRIGGER-001 세부분류'] + _v830_trigger_classification_lines(detail=False)[:6]
    lines += ['', '⑦ paper/최근 매매 해석'] + [f"- OPEN {_v650_open_count() if '_v650_open_count' in globals() else '-'}"] + _v809_recent_trade_short_lines(_v798_batch_marker_ts() if '_v798_batch_marker_ts' in globals() else 0.0)[:2] + _v828_recent_loss_digest_lines(_v798_batch_marker_ts() if '_v798_batch_marker_ts' in globals() else 0.0)[:2]
    lines += ['', '⑧ 품질/늦은진입 증거'] + _v834_oxt_quality_lines()[:2] + _v834_oxt_late_lines()[:1]
    lines += ['', '⑨ 문제장부'] + _v830_issue_ledger_chat_lines(12)
    lines += ['', '⑩ 다음'] + _v836_next_action_lines()
    return _v834_easy_text('\n'.join(str(x) for x in lines))


def _v836_issue_ledger_text() -> str:
    lines = ['🧾 문제장부 /issue_ledger · v839']
    lines += _v830_issue_ledger_detail_lines()
    lines += ['', '[LEDGER-001 장부/복기 순환정리]'] + _v836_cleanup_status_lines(detail=True)
    lines += ['', '[MENU-001 명령어 메뉴]'] + _v836_commands_text().splitlines()[0:18]
    lines += ['', '[PAPER-001 paper 판정값 충돌]'] + _v834_paper_mismatch_lines(detail=True)
    lines += ['', '[QUALITY-001 OXT 체결착시 증거]'] + _v834_oxt_quality_lines()
    lines += ['', '[LATE-001 OXT 늦은진입 증거]'] + _v834_oxt_late_lines()
    lines += ['', '[TRIGGER-001 세부분류]'] + _v830_trigger_classification_lines(detail=True)
    lines += ['', '[다음]'] + _v836_next_action_lines()
    return _v834_easy_text('\n'.join(str(x) for x in lines))


def _v836_paper_gate_audit_text() -> str:
    lines = ['🧪 PAPER-001 paper 판정값 충돌 확인 /paper_gate_audit · v839']
    lines += _v834_paper_mismatch_lines(detail=True)
    lines += ['', '[정리상태 참고]'] + _v836_cleanup_status_lines(detail=False)[:5]
    lines += ['', '[기존 S1 hold→paper 검산]'] + _v832_paper_gate_audit_lines(detail=True)
    lines += ['', '[장부]'] + _v830_issue_ledger_chat_lines(12)
    return _v834_easy_text('\n'.join(str(x) for x in lines))


def _v836_trigger_audit_text() -> str:
    lines = ['🧨 TRIGGER-001 세부분류 /trigger_audit · v839']
    lines += _v830_line_trigger_audit_lines()
    lines += ['', '[세부분류]'] + _v830_trigger_classification_lines(detail=True)
    lines += ['', '[PAPER-001 연결 참고]'] + _v834_paper_mismatch_lines(detail=False)
    lines += ['', '[장부]'] + _v830_issue_ledger_chat_lines(12)
    return _v834_easy_text('\n'.join(str(x) for x in lines))


def _v836_batch_summary_text(cmds: List[str], outputs: Dict[str,str], timings: List[Dict[str,Any]], recv_delay: float, total_sec: float, chat_body: str = '') -> str:
    global _V797_PENDING_BATCH_MARKER_TS
    batch_until = now_ts(); _V797_PENDING_BATCH_MARKER_TS = batch_until
    since_ts = _v798_batch_marker_ts() if '_v798_batch_marker_ts' in globals() else 0.0
    lines=['코인봇 묶음 요약집 v839', f'- 생성: {_v800_kst_text(batch_until)}', f'- 메인봇: {BOT_VERSION} / {V650_BUILD_LABEL}', f'- 접수지연: {recv_delay:.2f}s / 처리합계: {total_sec:.2f}s', '', '[명령 처리시간]']
    for t in timings:
        lines.append(f"- {'✅' if not t.get('error') else '❌'} /{t.get('name','?')}: {float(t.get('sec') or 0):.2f}s / {'OK' if not t.get('error') else 'ERR'}")
    lines += ['', '[채팅 운영판]', _v650_safe_body(chat_body or _v836_batch_text(outputs, timings), 7600), '']
    lines += ['', '[문제장부 전체]'] + _v830_issue_ledger_detail_lines()
    lines += ['', '[장부/디스크 순환정리 상세]'] + _v836_cleanup_status_lines(detail=True)
    lines += ['', '[명령어 메뉴 상세]', _v836_commands_text()]
    lines += ['', '[PAPER-001 paper 판정값 충돌 상세]'] + _v834_paper_mismatch_lines(detail=True)
    lines += ['', '[QUALITY-001/OXT 증거]'] + _v834_oxt_quality_lines()
    lines += ['', '[LATE-001/OXT 증거]'] + _v834_oxt_late_lines()
    lines += ['', '[TRIGGER-001 세부분류 상세]'] + _v830_trigger_classification_lines(detail=True)
    lines += ['', '[구조선→방아쇠 검산 상세]'] + _v830_line_trigger_audit_lines()
    lines += ['', '[명령별 짧은 요약]'] + _v817_command_summary_lines(outputs, timings, cmds)
    lines += ['', '[전체 상세 요약]', _v650_safe_body(_v833_easy_text(_v807_batch_text()), 10000), '']
    lines += ['', '[MTF 구조판 상세]'] + [_v833_easy_text('\n'.join(_v826_structure_short_lines()))]
    lines += _v799_trade_detail_lines_range(since_ts, batch_until)
    lines += ['', '[통합 검증판 상세]'] + [_v833_easy_text('\n'.join(_v807_integrated_validation_lines(since_ts, batch_until, compact=False)))]
    lines += ['', '[가격반응 지연·체결착시 품질판 상세]'] + [_v833_easy_text('\n'.join(_v807_price_lag_quality_lines(10) + _v810_quality_route_lines()))]
    lines += ['', '[OPEN직전 보류 사후검증]'] + _v810_preopen_review_lines(10)
    lines += ['', '[아까운 후보 / 놓친 후보 상세]'] + _v805_missed_summary_lines(10)
    lines += ['', '[명령별 상세]']
    for name in cmds:
        lines += ['', f'/{name}', _v650_safe_body(_v834_easy_text(outputs.get(name,'')), 5200)]
    return _v834_easy_text('\n'.join(str(x) for x in lines))

# command binding
COMMANDS['batch'] = _v836_batch_text
COMMANDS['summary'] = _v836_batch_text
COMMANDS['pbatch'] = _v836_batch_text
COMMANDS['commands'] = _v836_commands_text
COMMANDS['menu'] = _v836_commands_text
COMMANDS['help'] = _v836_commands_text
COMMANDS['issue_ledger'] = _v836_issue_ledger_text
COMMANDS['ledger'] = _v836_issue_ledger_text
COMMANDS['cleanup_status'] = _v836_cleanup_status_text
COMMANDS['ledger_cleanup'] = _v836_cleanup_status_text
COMMANDS['disk_cleanup'] = _v836_cleanup_status_text
COMMANDS['cleanup'] = _v836_cleanup_status_text
COMMANDS['trigger_audit'] = _v836_trigger_audit_text
COMMANDS['trigger'] = _v836_trigger_audit_text
COMMANDS['paper_gate_audit'] = _v836_paper_gate_audit_text
COMMANDS['paper_audit'] = _v836_paper_gate_audit_text
COMMANDS['hold_audit'] = _v836_paper_gate_audit_text
COMMANDS['paper_mismatch_audit'] = _v836_paper_gate_audit_text
COMMANDS['gate_mismatch'] = _v836_paper_gate_audit_text
COMMANDS['source_audit'] = _v833_source_audit_text
COMMANDS['stale_audit'] = _v833_source_audit_text
COMMANDS['data_age'] = _v833_source_audit_text

# Make common aliases available in Telegram menu routing as well.
for _c in [c for c, _d, _g in _v836_menu_commands()]:
    if _c not in COMMANDS and _c in globals():
        pass


def batch_handler(update, context):  # type: ignore[override]
    try:
        msg_date=getattr(getattr(update,'message',None),'date',None)
        recv_delay=time.time()-msg_date.timestamp() if hasattr(msg_date,'timestamp') else 0.0
    except Exception:
        recv_delay=0.0
    cmds = _v820_select_batch_cmds(getattr(context,'args',None) or [])
    stime=time.time(); timings=[]; outputs={}
    _v811_begin_batch_source_lock()
    try:
        multi = len(cmds) > 1
        if multi:
            try: send(update, f'📊 묶음 시작 · {len(cmds)}개 명령 / 구형cache정리 txt(v839) · 지연 {recv_delay:.2f}s')
            except Exception: pass
        total_cmds=len(cmds)
        for idx, name in enumerate(cmds, start=1):
            fn=COMMANDS.get(name); t0=time.time(); err=None
            if not fn:
                body=f'❌ /{name} 연결 없음'; err='no_handler'
            else:
                try: body=fn()
                except Exception as exc:
                    body=f'❌ /{name} 오류 {exc.__class__.__name__}: {exc}'; err=f'{exc.__class__.__name__}: {exc}'; log_error(f'v839_batch_{name}', exc)
            body = _v834_easy_text(body)
            sec=time.time()-t0
            timings.append({'name':name,'sec':sec,'error':err}); outputs[name]=body
            try:
                if multi: send(update, _v817_command_short_block(idx, total_cmds, name, body, sec, err))
                else: send(update, body)
            except Exception as exc: log_error('v839_batch_send', exc)
        total=time.time()-stime
        chat_body = outputs.get(cmds[0], '') if len(cmds) == 1 else _v836_batch_text(outputs, timings)
        try:
            status=_v650_send_summary_file(update, _v836_batch_summary_text(cmds, outputs, timings, recv_delay, total, chat_body=chat_body))
        except Exception as exc:
            status=f'txt 생성실패 {exc.__class__.__name__}'; log_error('v839_batch_summary_file', exc)
        mark='✅' if '전송완료' in status else '⚠️'; del_mark='✅' if '서버삭제' in status else ('❌' if '전송완료' in status else '❔')
        try: send(update, f'📎 txt {mark} / 삭제 {del_mark} / {total:.2f}s')
        except Exception: pass
    finally:
        _v811_end_batch_source_lock()



# =============================================================================
# main_bot v2.13.840: emergency disk growth stop / 2~3 day retention
# - main-side cleanup runs because paper cleanup owner may not restart immediately.
# - Core ledgers are protected: OPEN/CLOSED/trade_log/score/current snapshots.
# - No S1/S2/S3 thresholds, trigger formula, exit, paper OPEN permission, or guard change.
# =============================================================================
BOT_VERSION = '수익형 v2.13.841'
MAIN_BOT_VERSION = BOT_VERSION
V650_BUILD_LABEL = 'v841_queue_paper_owner_cleanup_2026-06-11'

_V840_RETENTION_DAYS_GENERAL = 2.0
_V840_TARGET_FREE_GB = 5.0
_V840_MIN_INTERVAL_SEC = 90.0

_V840_EXACT_RESET_TARGETS = {
    'clean_candidate_reason_compact_cache.json': ('candidate_reason_legacy_cache_force_reset', '{}\n', 5.0),
    'clean_recheck_candidates_state.json': ('recheck_legacy_state_force_reset', '{}\n', 5.0),
    'clean_recheck_candidates_cache.json': ('recheck_legacy_cache_force_reset', '{}\n', 5.0),
    'clean_s1_lifecycle_state.json': ('s1_lifecycle_state_force_reset', '{}\n', 5.0),
    'clean_s1_lifecycle_trace.json': ('s1_lifecycle_trace_force_reset', '', 5.0),
    'paper_bot_hourly_event_trace.jsonl': ('paper_hourly_event_trace_force_reset', '', 8.0),
}

_V840_PROTECTED_NAMES = {
    'paper_bot_open.json', 'paper_bot_closed.jsonl', 'paper_bot_trade_log.jsonl',
    'paper_bot_score_cache.json', 'paper_bot_current_score_anchor.json',
    'paper_bot_open_positions.json', 'paper_bot_status.json',
    'clean_candidate_latest_snapshot.json', 'clean_strategy_worker_status.json',
    'bot.py', 'paper_bot.py', 'strategy_worker.py', 'DEPLOY_BUNDLE.json', 'DEPLOY_TARGET.txt',
    'coin_factory_store.sqlite3',
}


def _v840_disk_obj() -> Dict[str, Any]:
    try:
        import shutil
        total, used, free = shutil.disk_usage(BASE_DIR)
        return {'total_gb': round(total/1024/1024/1024,2), 'used_gb': round(used/1024/1024/1024,2), 'free_gb': round(free/1024/1024/1024,2), 'used_pct': round(used/max(total,1)*100,1)}
    except Exception:
        return {'free_gb': 0.0, 'used_pct': 0.0}


def _v840_file_size(path: Path) -> int:
    try: return int(path.stat().st_size)
    except Exception: return 0


def _v840_mb(n: Any) -> float:
    try: return round(float(n or 0)/1024.0/1024.0, 2)
    except Exception: return 0.0


def _v840_add_reason(res: Dict[str, Any], reason: str, files: int, bytes_count: int) -> None:
    try:
        slot = res.setdefault('by_reason', {}).setdefault(str(reason), {'files':0,'bytes':0})
        slot['files'] = int(slot.get('files') or 0) + int(files or 0)
        slot['bytes'] = int(slot.get('bytes') or 0) + int(bytes_count or 0)
    except Exception:
        pass


def _v840_cleanup_state_load() -> Dict[str, Any]:
    p = BASE_DIR / 'paper_bot_cleanup_state.json'
    try:
        obj = load_json(p, {}) if 'load_json' in globals() else {}
        return obj if isinstance(obj, dict) else {}
    except Exception:
        return {}


def _v840_cleanup_state_save(cleanup: Dict[str, Any]) -> None:
    try:
        if 'save_json' in globals():
            save_json(BASE_DIR / 'paper_bot_cleanup_state.json', cleanup)
        else:
            (BASE_DIR / 'paper_bot_cleanup_state.json').write_text(json.dumps(cleanup, ensure_ascii=False, indent=2), encoding='utf-8')
    except Exception as exc:
        try: log_error('v840_cleanup_state_save', exc)
        except Exception: pass


def _v840_archive_dir() -> Path:
    return BASE_DIR / 'legacy_v840_archive'


def _v840_gzip_copy_then_truncate(path: Path, payload: bytes, res: Dict[str, Any], reason: str, min_mb: float = 5.0) -> None:
    try:
        if not path.exists() or not path.is_file():
            return
        res['checked_files'] = int(res.get('checked_files') or 0) + 1
        if path.name in _V840_PROTECTED_NAMES:
            res['protected_files'] = int(res.get('protected_files') or 0) + 1
            return
        size = _v840_file_size(path)
        if size < int(float(min_mb)*1024*1024):
            res['small_or_skip'] = int(res.get('small_or_skip') or 0) + 1
            return
        arch = _v840_archive_dir(); arch.mkdir(parents=True, exist_ok=True)
        stamp = time.strftime('%Y%m%d_%H%M%S', time.localtime(now_ts() if 'now_ts' in globals() else time.time()))
        gz_final = arch / f'{path.name}.{stamp}.v840.gz'
        gz_tmp = arch / f'{path.name}.{stamp}.v840.gz.tmp'
        gz_size = 0
        try:
            import gzip, shutil
            with path.open('rb') as src, gzip.open(gz_tmp, 'wb', compresslevel=3) as dst:
                shutil.copyfileobj(src, dst, length=1024*1024)
            os.replace(gz_tmp, gz_final)
            gz_size = _v840_file_size(gz_final)
        except Exception as exc:
            res['errors'] = int(res.get('errors') or 0) + 1
            res.setdefault('error_sample', []).append(f'{path.name}: gzip_{type(exc).__name__}')
            try:
                if gz_tmp.exists(): gz_tmp.unlink(missing_ok=True)
            except Exception: pass
        try:
            # In-place truncate keeps the live path and avoids breaking active file handles as much as possible.
            with path.open('wb') as f:
                f.write(payload)
        except Exception as exc:
            res['errors'] = int(res.get('errors') or 0) + 1
            res.setdefault('error_sample', []).append(f'{path.name}: truncate_{type(exc).__name__}')
            try: log_error('v840_gzip_copy_then_truncate', exc)
            except Exception: pass
            return
        after = _v840_file_size(path)
        saved = max(0, size - after - gz_size)
        res['force_reset_files'] = int(res.get('force_reset_files') or 0) + 1
        res['force_reset_original_bytes'] = int(res.get('force_reset_original_bytes') or 0) + size
        res['force_reset_archive_bytes'] = int(res.get('force_reset_archive_bytes') or 0) + gz_size
        res['force_reset_saved_bytes'] = int(res.get('force_reset_saved_bytes') or 0) + saved
        res.setdefault('force_reset', []).append({'name': path.name, 'original_mb': _v840_mb(size), 'archive_mb': _v840_mb(gz_size), 'live_mb': _v840_mb(after), 'saved_mb': _v840_mb(saved), 'reason': reason})
        _v840_add_reason(res, reason, 1, saved)
    except Exception as exc:
        res['errors'] = int(res.get('errors') or 0) + 1
        res.setdefault('error_sample', []).append(f'{path.name}: {type(exc).__name__}')
        try: log_error('v840_gzip_copy_then_truncate_outer', exc)
        except Exception: pass


def _v840_compact_tail_inplace(path: Path, res: Dict[str, Any], max_mb: float, keep_mb: float, reason: str) -> None:
    try:
        if not path.exists() or not path.is_file(): return
        res['checked_files'] = int(res.get('checked_files') or 0) + 1
        if path.name in _V840_PROTECTED_NAMES:
            res['protected_files'] = int(res.get('protected_files') or 0) + 1; return
        size = _v840_file_size(path); max_b = int(max_mb*1024*1024); keep_b = int(keep_mb*1024*1024)
        if size <= max_b:
            res['small_or_skip'] = int(res.get('small_or_skip') or 0) + 1; return
        with path.open('rb') as f:
            f.seek(max(0, size-keep_b)); data = f.read(keep_b)
        if path.suffix == '.jsonl' and b'\n' in data:
            data = data[data.find(b'\n')+1:]
        if path.suffix != '.jsonl':
            header = (f"[v840 compact {time.strftime('%Y-%m-%d %H:%M:%S')}] original_bytes={size} kept={len(data)}\n").encode('utf-8', errors='ignore')
            data = header + data
        with path.open('wb') as f:
            f.write(data)
        after = _v840_file_size(path); saved = max(0, size-after)
        res['tail_compacted_files'] = int(res.get('tail_compacted_files') or 0) + 1
        res['tail_compacted_bytes'] = int(res.get('tail_compacted_bytes') or 0) + saved
        res.setdefault('tail_compacted', []).append({'name': path.name, 'from_mb': _v840_mb(size), 'to_mb': _v840_mb(after), 'saved_mb': _v840_mb(saved), 'reason': reason})
        _v840_add_reason(res, reason, 1, saved)
    except Exception as exc:
        res['errors'] = int(res.get('errors') or 0)+1
        res.setdefault('error_sample', []).append(f'{path.name}: {type(exc).__name__}')
        try: log_error('v840_compact_tail_inplace', exc)
        except Exception: pass


def _v840_delete_old_glob(pattern: str, max_age_sec: float, res: Dict[str, Any], reason: str, keep_newest: int = 1) -> None:
    try:
        nowv = now_ts() if 'now_ts' in globals() else time.time()
        files = [p for p in BASE_DIR.glob(pattern) if p.is_file()]
        files.sort(key=lambda p: p.stat().st_mtime if p.exists() else 0, reverse=True)
        keep = set(files[:max(0, int(keep_newest))])
        for p in files:
            try:
                res['checked_files'] = int(res.get('checked_files') or 0)+1
                if p in keep or p.name in _V840_PROTECTED_NAMES:
                    res['protected_files'] = int(res.get('protected_files') or 0)+1; continue
                if nowv - p.stat().st_mtime < float(max_age_sec):
                    res['age_skip'] = int(res.get('age_skip') or 0)+1; continue
                sz = _v840_file_size(p); p.unlink(missing_ok=True)
                res['deleted_files'] = int(res.get('deleted_files') or 0)+1
                res['deleted_bytes'] = int(res.get('deleted_bytes') or 0)+sz
                _v840_add_reason(res, reason, 1, sz)
            except Exception as exc:
                res['errors'] = int(res.get('errors') or 0)+1
                res.setdefault('error_sample', []).append(f'{p.name}: {type(exc).__name__}')
    except Exception as exc:
        res['errors'] = int(res.get('errors') or 0)+1
        try: log_error('v840_delete_old_glob', exc)
        except Exception: pass


def _v840_prune_archives(res: Dict[str, Any], max_age_sec: float = 2*24*3600.0, keep_newest: int = 6) -> None:
    try:
        for arch in [BASE_DIR/'legacy_v839_archive', BASE_DIR/'legacy_v840_archive']:
            if not arch.exists() or not arch.is_dir(): continue
            files = [p for p in arch.glob('*') if p.is_file()]
            files.sort(key=lambda p: p.stat().st_mtime if p.exists() else 0, reverse=True)
            keep=set(files[:max(0,int(keep_newest))])
            nowv=now_ts() if 'now_ts' in globals() else time.time()
            for p in files:
                try:
                    if p in keep or nowv - p.stat().st_mtime < max_age_sec: continue
                    sz=_v840_file_size(p); p.unlink(missing_ok=True)
                    res['deleted_files']=int(res.get('deleted_files') or 0)+1
                    res['deleted_bytes']=int(res.get('deleted_bytes') or 0)+sz
                    _v840_add_reason(res, 'old_legacy_archive_2d_delete', 1, sz)
                except Exception as exc:
                    res['errors']=int(res.get('errors') or 0)+1
                    res.setdefault('error_sample', []).append(f'{p.name}: {type(exc).__name__}')
    except Exception as exc:
        res['errors']=int(res.get('errors') or 0)+1
        try: log_error('v840_prune_archives', exc)
        except Exception: pass


def _v840_classify_large_file(path: Path) -> Dict[str, Any]:
    name=path.name; mb=_v840_mb(_v840_file_size(path))
    if name in _V840_EXACT_RESET_TARGETS:
        return {'name':name,'mb':mb,'class':'강제정리대상','action':'gzip보관+live reset','reason':'구형 cache/state 또는 급증 trace · 2~3일 보관정책'}
    if name == 'paper_candidates_latest.jsonl':
        return {'name':name,'mb':mb,'class':'상한관리','action':'tail 20MB 유지','reason':'append-only 후보전달 · 전체파싱 금지'}
    if name in _V840_PROTECTED_NAMES:
        return {'name':name,'mb':mb,'class':'보호','action':'삭제금지','reason':'핵심 원장/현재 snapshot'}
    if name.endswith('.log') or 'error' in name:
        return {'name':name,'mb':mb,'class':'상한관리','action':'tail 3~5MB 유지','reason':'로그 급증 방지'}
    if name.endswith('.jsonl') and any(k in name for k in ('trace','detail','review','candidate','event')):
        return {'name':name,'mb':mb,'class':'상한관리','action':'tail 8~20MB 유지','reason':'trace/detail 급증 방지'}
    if name.endswith('.zip') or name.endswith('.bak') or 'backup' in name:
        return {'name':name,'mb':mb,'class':'2~3일보관','action':'오래된 파일 삭제','reason':'개발단계 배포/backup 보관 짧게'}
    return {'name':name,'mb':mb,'class':'관찰','action':'정책검토','reason':'v840 미지정'}


def _v840_large_top(limit:int=10) -> List[Dict[str,Any]]:
    """Large-file board using the same paper_latest owner snapshot as cleanup_status.
    v845: paper_candidates_latest is paper-owned; do not let health show a different direct-scan value.
    """
    out=[]
    try:
        paper_obj = None
        fn = globals().get('_v845_paper_latest_canonical_obj')
        if callable(fn):
            try: paper_obj = fn()
            except Exception: paper_obj = None
        for p in BASE_DIR.iterdir():
            if not p.is_file(): continue
            sz=_v840_file_size(p)
            if sz < 5*1024*1024 and p.name != 'paper_candidates_latest.jsonl': continue
            if p.name == 'paper_candidates_latest.jsonl' and isinstance(paper_obj, dict):
                mb = float(paper_obj.get('display_mb') or paper_obj.get('latest_mb') or _v840_mb(sz) or 0.0)
                if mb < 5.0:
                    continue
                d={'name':p.name,'mb':_v840_mb(mb*1024*1024),'class':'상한관리','action':'paper owner snapshot 기준','reason':'v845 cleanup_status/health paper_latest 크기 단일화','source':'paper_latest_owner_snapshot_v845'}
            else:
                d=_v840_classify_large_file(p)
            try: d['age_sec']=round(max(0.0,(now_ts() if 'now_ts' in globals() else time.time())-p.stat().st_mtime),1)
            except Exception: pass
            out.append(d)
    except Exception: pass
    out.sort(key=lambda x: float(x.get('mb') or 0), reverse=True)
    return out[:limit]


def _v840_emergency_disk_cleanup(force: bool = False) -> Dict[str, Any]:
    cleanup = _v840_cleanup_state_load()
    prev = cleanup.get('emergency_disk_cleanup_v840') if isinstance(cleanup.get('emergency_disk_cleanup_v840'), dict) else {}
    before = _v840_disk_obj()
    nowv = now_ts() if 'now_ts' in globals() else time.time()
    if (not force) and isinstance(prev, dict) and nowv - float(prev.get('updated_at') or 0) < _V840_MIN_INTERVAL_SEC and float(before.get('free_gb') or 0) >= 2.0:
        return prev
    res: Dict[str, Any] = {
        'schema':'main_emergency_disk_cleanup_v840', 'version':BOT_VERSION, 'build':V650_BUILD_LABEL,
        'updated_at':nowv, 'updated_at_text':time.strftime('%Y-%m-%d %H:%M:%S'),
        'target_free_gb':_V840_TARGET_FREE_GB, 'retention_days_general':_V840_RETENTION_DAYS_GENERAL,
        'before_disk':before, 'checked_files':0, 'deleted_files':0, 'deleted_bytes':0,
        'force_reset_files':0, 'force_reset_saved_bytes':0, 'tail_compacted_files':0, 'tail_compacted_bytes':0,
        'protected_files':0, 'age_skip':0, 'small_or_skip':0, 'errors':0, 'by_reason':{},
        'policy':'개발단계: 일반 파일 2~3일, trace/debug/cache 2일 중심. OPEN/CLOSED 핵심·trade_log·score는 삭제 금지.',
    }
    try:
        # 1) exact legacy/state reset: these were proven current-structure stale and kept growing.
        for name,(reason,payload,min_mb) in _V840_EXACT_RESET_TARGETS.items():
            _v840_gzip_copy_then_truncate(BASE_DIR/name, payload.encode('utf-8'), res, reason, min_mb=float(min_mb))
        # 2) append-only candidate handoff and runtime trace/log caps.
        # v841: paper_candidates_latest.jsonl is owned by paper_bot. Main only reports it;
        # direct truncate from main caused PermissionError and is intentionally removed.
        p_latest = BASE_DIR / 'paper_candidates_latest.jsonl'
        if p_latest.exists() and _v840_file_size(p_latest) > int(45.0*1024*1024):
            res.setdefault('owner_deferred', []).append({'name':'paper_candidates_latest.jsonl','mb':_v840_mb(_v840_file_size(p_latest)),'owner':'paper_bot','reason':'paper_latest_owner_cleanup_required'})
            _v840_add_reason(res, 'paper_latest_owner_deferred_no_main_truncate', 0, 0)
        for pat in ('*.log','*error*.log'):
            for p in BASE_DIR.glob(pat):
                _v840_compact_tail_inplace(p, res, max_mb=20.0, keep_mb=3.0, reason='log_20mb_cap_tail3')
        for p in BASE_DIR.glob('*.jsonl'):
            if p.name in _V840_PROTECTED_NAMES: continue
            if any(k in p.name for k in ('trace','detail','review','event')):
                _v840_compact_tail_inplace(p, res, max_mb=35.0, keep_mb=8.0, reason='jsonl_trace_35mb_cap_tail8')
        # 3) short retention for development clutter. Keep newest active-looking bundles only.
        two_days = 2*24*3600.0
        three_days = 3*24*3600.0
        for pat in ('coinbot_update_v*.zip','코인봇_최신코드묶음_*.zip','코인봇_*코드묶음*.zip','코인봇_인수인계_*.txt'):
            _v840_delete_old_glob(pat, two_days, res, 'deploy_artifact_2d_retention', keep_newest=3)
        for pat in ('*.bak','*.backup*','*backup*','*_tmp*','*.tmp','*.v835tmp','*.v836tmp','*.v840tmp'):
            _v840_delete_old_glob(pat, 6*3600.0, res, 'tmp_backup_short_retention', keep_newest=1)
        for pat in ('coinbot_batch_summary_*.txt','paper_hourly_raw_pack_*.txt','paper_hourly_summary_tmp*.txt'):
            _v840_delete_old_glob(pat, 6*3600.0, res, 'txt_temp_6h_retention', keep_newest=1)
        _v840_prune_archives(res, max_age_sec=two_days, keep_newest=6)
        try:
            for pyc in BASE_DIR.rglob('__pycache__'):
                if pyc.is_dir():
                    import shutil
                    sz=sum(_v840_file_size(x) for x in pyc.rglob('*') if x.is_file())
                    shutil.rmtree(pyc, ignore_errors=True)
                    res['deleted_files']=int(res.get('deleted_files') or 0)+1; res['deleted_bytes']=int(res.get('deleted_bytes') or 0)+sz
                    _v840_add_reason(res,'pycache_delete',1,sz)
        except Exception: pass
    except Exception as exc:
        res['errors']=int(res.get('errors') or 0)+1
        res.setdefault('error_sample', []).append(f'outer: {type(exc).__name__}')
        try: log_error('v840_emergency_disk_cleanup', exc)
        except Exception: pass
    after=_v840_disk_obj(); res['after_disk']=after
    res['deleted_mb']=_v840_mb(res.get('deleted_bytes'))
    res['force_reset_saved_mb']=_v840_mb(res.get('force_reset_saved_bytes'))
    res['tail_compacted_mb']=_v840_mb(res.get('tail_compacted_bytes'))
    res['total_saved_mb']=round(float(res.get('deleted_mb') or 0)+float(res.get('force_reset_saved_mb') or 0)+float(res.get('tail_compacted_mb') or 0),2)
    res['free_gain_gb']=round(float(after.get('free_gb') or 0)-float(before.get('free_gb') or 0),2)
    res['goal_status']='DONE' if float(after.get('free_gb') or 0) >= _V840_TARGET_FREE_GB else 'OPEN'
    res['large_file_top']=_v840_large_top(10)
    cleanup['emergency_disk_cleanup_v840']=res
    cleanup['cleanup_policy_v840']=res
    cleanup['deleted_files_v840']=int(res.get('deleted_files') or 0)+int(res.get('force_reset_files') or 0)+int(res.get('tail_compacted_files') or 0)
    cleanup['deleted_mb_v840']=res.get('total_saved_mb')
    cleanup['errors_v840']=int(res.get('errors') or 0)
    cleanup['policy_v840']=res.get('policy')
    cleanup['updated_at']=nowv
    _v840_cleanup_state_save(cleanup)
    return res


def _v840_cleanup_summary_obj() -> Dict[str, Any]:
    # Run emergency cleanup when the command/batch opens. This is intentional for disk safety.
    res = _v840_emergency_disk_cleanup(force=False)
    obj = _v836_cleanup_summary_obj() if '_v836_cleanup_summary_obj' in globals() else {}
    if not isinstance(obj, dict): obj = {}
    obj['v840'] = res
    obj['disk'] = res.get('after_disk') if isinstance(res.get('after_disk'), dict) else _v840_disk_obj()
    obj['deleted_files'] = int(res.get('deleted_files') or 0)+int(res.get('force_reset_files') or 0)+int(res.get('tail_compacted_files') or 0)
    obj['deleted_mb'] = float(res.get('total_saved_mb') or 0.0)
    obj['errors'] = int(res.get('errors') or 0)
    obj['legacy_archived_files'] = int(res.get('force_reset_files') or 0)
    obj['legacy_saved_mb'] = float(res.get('force_reset_saved_mb') or 0.0)
    obj['legacy_archive_mb'] = _v840_mb(res.get('force_reset_archive_bytes'))
    obj['recreated_empty_files'] = int(res.get('force_reset_files') or 0)
    obj['large'] = res.get('large_file_top') if isinstance(res.get('large_file_top'), list) else _v840_large_top(10)
    obj['age_sec'] = max(0.0, (now_ts() if 'now_ts' in globals() else time.time()) - float(res.get('updated_at') or 0))
    return obj


def _v840_cleanup_status_lines(detail: bool = False) -> List[str]:
    obj = _v840_cleanup_summary_obj(); v840 = obj.get('v840') if isinstance(obj.get('v840'), dict) else {}
    disk = obj.get('disk') if isinstance(obj.get('disk'), dict) else _v840_disk_obj()
    free = float(disk.get('free_gb') or 0.0); saved = float(obj.get('deleted_mb') or 0.0); errors = int(obj.get('errors') or 0)
    verdict = '✅ 목표 5GB 이상 확보' if free >= _V840_TARGET_FREE_GB else ('🟡 정리 실행됨 · 5GB 목표 미달' if saved > 0 else '❌ 정리 필요 · 회수 부족')
    lines = [
        f'- 판독: {verdict}',
        f"- 디스크: 사용 {disk.get('used_pct',0)}% / 남음 {disk.get('free_gb',0)}GB / 목표 {_V840_TARGET_FREE_GB:.1f}GB",
        f"- v840 정리: 대상 {obj.get('deleted_files',0)}개 / 회수 {saved}MB / 실패 {errors}개 / free +{v840.get('free_gain_gb',0)}GB",
        f"- 구형 cache/state: 격리·reset {obj.get('legacy_archived_files',0)}개 / 절감 {obj.get('legacy_saved_mb',0)}MB / placeholder {obj.get('recreated_empty_files',0)}개",
        '- 보관정책: 일반 파일 2~3일, trace/debug/cache 2일 중심, 요약txt 6시간, archive 2일',
        '- 보존: OPEN/CLOSED 핵심 원장 · trade_log · score 핵심 · 현재 latest snapshot 삭제 금지',
    ]
    large = obj.get('large') if isinstance(obj.get('large'), list) else []
    if large:
        parts=[]
        for x in large[:5]:
            if isinstance(x, dict): parts.append(f"{x.get('name')} {x.get('mb')}MB/{x.get('class','관찰')}/{x.get('action','-')}")
        if parts: lines.append('- 큰 파일 TOP: ' + ' / '.join(parts))
    if detail and v840:
        by=v840.get('by_reason') if isinstance(v840.get('by_reason'),dict) else {}
        if by:
            parts=[]
            for k,val in list(by.items())[:12]:
                if isinstance(val,dict): parts.append(f"{k} {val.get('files',0)}개/{_v840_mb(val.get('bytes',0))}MB")
            if parts: lines.append('- 사유별 정리: ' + ' / '.join(parts))
        fr=v840.get('force_reset') if isinstance(v840.get('force_reset'),list) else []
        if fr:
            lines.append('- 격리/reset 파일:')
            for r in fr[:8]:
                if isinstance(r,dict): lines.append(f"  · {r.get('name')} {r.get('original_mb')}MB → live {r.get('live_mb')}MB / archive {r.get('archive_mb')}MB / 절감 {r.get('saved_mb')}MB")
        tc=v840.get('tail_compacted') if isinstance(v840.get('tail_compacted'),list) else []
        if tc:
            lines.append('- tail compact:')
            for r in tc[:8]:
                if isinstance(r,dict): lines.append(f"  · {r.get('name')} {r.get('from_mb')}MB → {r.get('to_mb')}MB / 절감 {r.get('saved_mb')}MB")
        if errors and v840.get('error_sample'):
            lines.append('- 실패샘플: ' + ' / '.join(str(x) for x in v840.get('error_sample',[])[:5]))
    return lines


_V840_PREV_ISSUE_ITEMS = _v830_issue_items if '_v830_issue_items' in globals() else None

def _v840_issue_items() -> List[Dict[str, str]]:
    prev = _V840_PREV_ISSUE_ITEMS() if callable(_V840_PREV_ISSUE_ITEMS) else []
    obj = _v840_cleanup_summary_obj(); disk = obj.get('disk') if isinstance(obj.get('disk'),dict) else _v840_disk_obj(); free=float(disk.get('free_gb') or 0)
    saved=float(obj.get('deleted_mb') or 0); errors=int(obj.get('errors') or 0); reset_n=int(obj.get('legacy_archived_files') or 0)
    status='DONE' if free >= _V840_TARGET_FREE_GB else 'OPEN'
    add=[
        {'id':'DISK-001','status':('OPEN' if free < _V840_TARGET_FREE_GB else 'DONE'),'title':'디스크 큰 파일 순환정리','short':f"남음 {disk.get('free_gb',0)}GB / 목표 {_V840_TARGET_FREE_GB}GB / 회수 {saved}MB / 실패 {errors}",'owner':'main v840 emergency cleanup + paper cleanup','close':'남은 용량 5GB 근처 확보 및 큰 cache/log 상한관리'},
        {'id':'DISK-002','status':('CHECK' if reset_n>0 else 'OPEN'),'title':'구형 cache/state 격리·재생성 정리','short':f"격리/reset {reset_n}개 / 절감 {obj.get('legacy_saved_mb',0)}MB",'owner':'main v840 emergency cleanup','close':'candidate_reason/recheck/s1_lifecycle 구형 파일이 live reset되고 현재 worker가 재생성'},
        {'id':'DISK-003','status':status,'title':'디스크 급증 방지 상한선','short':f"paper latest/log/trace/cache 상한 적용 · free {disk.get('free_gb',0)}GB",'owner':'main/paper cleanup policy','close':'파일 급증이 멈추고 free 5GB 전후 유지'},
        {'id':'RETENTION-001','status':'CHECK','title':'2~3일 보관정책','short':'일반 파일 2~3일, trace/cache 2일, 요약txt 6시간, archive 2일','owner':'cleanup policy','close':'핵심 원장 제외 파일이 짧은 보관정책으로 자동 순환'},
    ]
    replace={x['id'] for x in add}; out=[]
    for raw in prev:
        if not isinstance(raw,dict): continue
        if str(raw.get('id') or '') in replace: continue
        out.append(dict(raw))
    out.extend(add)
    return out

_v830_issue_items = _v840_issue_items  # type: ignore[assignment]


def _v840_next_action_lines() -> List[str]:
    return [
        '- 지금은 디스크 안정화가 우선. 조건/trigger/청산은 변경 금지.',
        '- 확인: /cleanup_status → /health → /batch → /source_audit → /errorlog',
        '- 5GB 근처 회복 확인 후 paper trigger 표시값 단일화로 이동',
    ]
_v830_next_action_lines = _v840_next_action_lines  # type: ignore[assignment]


def _v840_cleanup_status_text() -> str:
    lines=['🧹 긴급 디스크 순환정리 /cleanup_status · v840']
    lines += _v840_cleanup_status_lines(detail=True)
    lines += ['', '[장부 연결]'] + _v830_issue_ledger_chat_lines(14)
    return _v834_easy_text('\n'.join(str(x) for x in lines))


def _v840_batch_text(outputs: Optional[Dict[str,str]] = None, timings: Optional[List[Dict[str,Any]]] = None) -> str:
    lines=['📊 코인봇 운영판 /batch · v840']
    lines += ['① 적용/성과'] + _v809_apply_short_lines()[:3] + _v811_score_short_lines()[:3]
    lines += ['', '② 디스크 긴급정리'] + _v840_cleanup_status_lines(detail=False)[:7]
    lines += ['', '③ 지금 병목'] + _v828_structure_digest_lines()
    lines += ['', '④ 명령어 메뉴/오류'] + _v836_commands_text().splitlines()[-4:]
    lines += ['', '⑤ paper 판정값 충돌 확인'] + _v834_paper_mismatch_lines(detail=False)
    lines += ['', '⑥ TRIGGER-001 세부분류'] + _v830_trigger_classification_lines(detail=False)[:6]
    lines += ['', '⑦ paper/최근 매매 해석'] + [f"- OPEN {_v650_open_count() if '_v650_open_count' in globals() else '-'}"] + _v809_recent_trade_short_lines(_v798_batch_marker_ts() if '_v798_batch_marker_ts' in globals() else 0.0)[:2] + _v828_recent_loss_digest_lines(_v798_batch_marker_ts() if '_v798_batch_marker_ts' in globals() else 0.0)[:2]
    lines += ['', '⑧ 문제장부'] + _v830_issue_ledger_chat_lines(14)
    lines += ['', '⑨ 다음'] + _v840_next_action_lines()
    return _v834_easy_text('\n'.join(str(x) for x in lines))


def _v840_issue_ledger_text() -> str:
    lines=['🧾 문제장부 /issue_ledger · v840']
    lines += _v830_issue_ledger_detail_lines()
    lines += ['', '[DISK/RETENTION 상세]'] + _v840_cleanup_status_lines(detail=True)
    lines += ['', '[PAPER-001 paper 판정값 충돌]'] + _v834_paper_mismatch_lines(detail=True)
    lines += ['', '[TRIGGER-001 세부분류]'] + _v830_trigger_classification_lines(detail=True)
    lines += ['', '[다음]'] + _v840_next_action_lines()
    return _v834_easy_text('\n'.join(str(x) for x in lines))


def _v840_paper_gate_audit_text() -> str:
    lines=['🧪 PAPER-001 paper 판정값 충돌 확인 /paper_gate_audit · v840']
    lines += _v834_paper_mismatch_lines(detail=True)
    lines += ['', '[정리상태 참고]'] + _v840_cleanup_status_lines(detail=False)[:5]
    lines += ['', '[기존 S1 hold→paper 검산]'] + _v832_paper_gate_audit_lines(detail=True)
    lines += ['', '[장부]'] + _v830_issue_ledger_chat_lines(14)
    return _v834_easy_text('\n'.join(str(x) for x in lines))


def _v840_trigger_audit_text() -> str:
    lines=['🧨 TRIGGER-001 세부분류 /trigger_audit · v840']
    lines += _v830_line_trigger_audit_lines()
    lines += ['', '[세부분류]'] + _v830_trigger_classification_lines(detail=True)
    lines += ['', '[PAPER-001 연결 참고]'] + _v834_paper_mismatch_lines(detail=False)
    lines += ['', '[장부]'] + _v830_issue_ledger_chat_lines(14)
    return _v834_easy_text('\n'.join(str(x) for x in lines))


def _v840_batch_summary_text(cmds: List[str], outputs: Dict[str,str], timings: List[Dict[str,Any]], recv_delay: float, total_sec: float, chat_body: str = '') -> str:
    global _V797_PENDING_BATCH_MARKER_TS
    batch_until = now_ts(); _V797_PENDING_BATCH_MARKER_TS = batch_until
    since_ts = _v798_batch_marker_ts() if '_v798_batch_marker_ts' in globals() else 0.0
    lines=['코인봇 묶음 요약집 v840', f'- 생성: {_v800_kst_text(batch_until)}', f'- 메인봇: {BOT_VERSION} / {V650_BUILD_LABEL}', f'- 접수지연: {recv_delay:.2f}s / 처리합계: {total_sec:.2f}s', '', '[명령 처리시간]']
    for t in timings:
        lines.append(f"- {'✅' if not t.get('error') else '❌'} /{t.get('name','?')}: {float(t.get('sec') or 0):.2f}s / {'OK' if not t.get('error') else 'ERR'}")
    lines += ['', '[채팅 운영판]', _v650_safe_body(chat_body or _v840_batch_text(outputs, timings), 7600), '']
    lines += ['', '[문제장부 전체]'] + _v830_issue_ledger_detail_lines()
    lines += ['', '[디스크 긴급정리 상세]'] + _v840_cleanup_status_lines(detail=True)
    lines += ['', '[명령어 메뉴 상세]', _v836_commands_text()]
    lines += ['', '[PAPER-001 paper 판정값 충돌 상세]'] + _v834_paper_mismatch_lines(detail=True)
    lines += ['', '[TRIGGER-001 세부분류 상세]'] + _v830_trigger_classification_lines(detail=True)
    lines += ['', '[구조선→방아쇠 검산 상세]'] + _v830_line_trigger_audit_lines()
    lines += ['', '[명령별 짧은 요약]'] + _v817_command_summary_lines(outputs, timings, cmds)
    lines += ['', '[전체 상세 요약]', _v650_safe_body(_v833_easy_text(_v807_batch_text()), 10000), '']
    lines += ['', '[MTF 구조판 상세]'] + [_v833_easy_text('\n'.join(_v826_structure_short_lines()))]
    lines += _v799_trade_detail_lines_range(since_ts, batch_until)
    lines += ['', '[통합 검증판 상세]'] + [_v833_easy_text('\n'.join(_v807_integrated_validation_lines(since_ts, batch_until, compact=False)))]
    lines += ['', '[가격반응 지연·체결착시 품질판 상세]'] + [_v833_easy_text('\n'.join(_v807_price_lag_quality_lines(10) + _v810_quality_route_lines()))]
    lines += ['', '[OPEN직전 보류 사후검증]'] + _v810_preopen_review_lines(10)
    lines += ['', '[아까운 후보 / 놓친 후보 상세]'] + _v805_missed_summary_lines(10)
    lines += ['', '[명령별 상세]']
    for name in cmds:
        lines += ['', f'/{name}', _v650_safe_body(_v834_easy_text(outputs.get(name,'')), 5200)]
    return _v834_easy_text('\n'.join(str(x) for x in lines))

# v840 command binding
COMMANDS['batch'] = _v840_batch_text
COMMANDS['summary'] = _v840_batch_text
COMMANDS['pbatch'] = _v840_batch_text
COMMANDS['cleanup_status'] = _v840_cleanup_status_text
COMMANDS['ledger_cleanup'] = _v840_cleanup_status_text
COMMANDS['disk_cleanup'] = _v840_cleanup_status_text
COMMANDS['cleanup'] = _v840_cleanup_status_text
COMMANDS['issue_ledger'] = _v840_issue_ledger_text
COMMANDS['ledger'] = _v840_issue_ledger_text
COMMANDS['trigger_audit'] = _v840_trigger_audit_text
COMMANDS['trigger'] = _v840_trigger_audit_text
COMMANDS['paper_gate_audit'] = _v840_paper_gate_audit_text
COMMANDS['paper_audit'] = _v840_paper_gate_audit_text
COMMANDS['hold_audit'] = _v840_paper_gate_audit_text


def batch_handler(update, context):  # type: ignore[override]
    try:
        msg_date=getattr(getattr(update,'message',None),'date',None)
        recv_delay=time.time()-msg_date.timestamp() if hasattr(msg_date,'timestamp') else 0.0
    except Exception:
        recv_delay=0.0
    cmds = _v820_select_batch_cmds(getattr(context,'args',None) or [])
    stime=time.time(); timings=[]; outputs={}
    _v811_begin_batch_source_lock()
    try:
        multi = len(cmds) > 1
        if multi:
            try: send(update, f'📊 묶음 시작 · {len(cmds)}개 명령 / 긴급디스크정리 txt(v840) · 지연 {recv_delay:.2f}s')
            except Exception: pass
        total_cmds=len(cmds)
        for idx, name in enumerate(cmds, start=1):
            fn=COMMANDS.get(name); t0=time.time(); err=None
            if not fn:
                body=f'❌ /{name} 연결 없음'; err='no_handler'
            else:
                try: body=fn()
                except Exception as exc:
                    body=f'❌ /{name} 오류 {exc.__class__.__name__}: {exc}'; err=f'{exc.__class__.__name__}: {exc}'; log_error(f'v840_batch_{name}', exc)
            body = _v834_easy_text(body)
            sec=time.time()-t0
            timings.append({'name':name,'sec':sec,'error':err}); outputs[name]=body
            try:
                if multi: send(update, _v817_command_short_block(idx, total_cmds, name, body, sec, err))
                else: send(update, body)
            except Exception as exc: log_error('v840_batch_send', exc)
        total=time.time()-stime
        chat_body = outputs.get(cmds[0], '') if len(cmds) == 1 else _v840_batch_text(outputs, timings)
        try:
            status=_v650_send_summary_file(update, _v840_batch_summary_text(cmds, outputs, timings, recv_delay, total, chat_body=chat_body))
        except Exception as exc:
            status=f'txt 생성실패 {exc.__class__.__name__}'; log_error('v840_batch_summary_file', exc)
        mark='✅' if '전송완료' in status else '⚠️'; del_mark='✅' if '서버삭제' in status else ('❌' if '전송완료' in status else '❔')
        try: send(update, f'📎 txt {mark} / 삭제 {del_mark} / {total:.2f}s')
        except Exception: pass
    finally:
        _v811_end_batch_source_lock()



# =============================================================================
# main_bot v2.13.841: work queue ledger + paper-owned latest cleanup
# - Adds QUEUE-001 so urgent fixes cannot hide the original next surgery.
# - Adds DISK-004 for paper_candidates_latest owner/permission cleanup.
# - Main no longer truncates paper_candidates_latest directly.
# =============================================================================

def _v841_paper_latest_obj() -> Dict[str, Any]:
    path = BASE_DIR / 'paper_candidates_latest.jsonl'
    cleanup = _v840_cleanup_state_load() if '_v840_cleanup_state_load' in globals() else {}
    v840 = cleanup.get('emergency_disk_cleanup_v840') if isinstance(cleanup.get('emergency_disk_cleanup_v840'), dict) else {}
    paper_owner = cleanup.get('paper_latest_owner_cleanup_v841') if isinstance(cleanup.get('paper_latest_owner_cleanup_v841'), dict) else {}
    err_sample = []
    if isinstance(v840.get('error_sample'), list):
        err_sample += [str(x) for x in v840.get('error_sample', []) if 'paper_candidates_latest' in str(x)]
    mb = _v840_mb(_v840_file_size(path)) if '_v840_mb' in globals() else 0.0
    needs = mb > 45.0 or bool(err_sample)
    return {
        'name': 'paper_candidates_latest.jsonl', 'mb': mb, 'limit_mb': 45.0, 'keep_mb': 20.0,
        'needs_owner_cleanup': needs, 'main_permission_error': bool(err_sample),
        'error_sample': err_sample[:3], 'paper_owner': paper_owner,
        'owner_done': isinstance(paper_owner, dict) and float(paper_owner.get('after_mb') or 9999) <= 50.0,
    }


def _v841_work_queue_lines(detail: bool = False) -> List[str]:
    lines = [
        '- 1순위 원래 수술: PAPER-001/PAPER-002 · paper trigger 표시값 단일화 + v628 문구/구경로 확인',
        '- 긴급 끼어듦: DISK-003/v840 디스크 응급처리 완료 후 잔여 확인',
        '- 새 하위문제: DISK-004 · paper_candidates_latest 권한/owner 정리',
        '- 다음 순서 고정: DISK-004 안정화 → PAPER-001/PAPER-002 → TRIGGER-001',
        '- 금지: 조건/S1·S2·S3 기준/trigger 산식/청산/paper OPEN/guard 변경 금지',
    ]
    if detail:
        lines.append('- 닫는 기준: /batch와 /issue_ledger에 이 큐가 고정 표시되고, 긴급수정 뒤에도 PAPER-001/PAPER-002가 다음 수술로 유지됨')
    return lines


_V841_PREV_ISSUE_ITEMS = _v830_issue_items if '_v830_issue_items' in globals() else None

def _v841_issue_items() -> List[Dict[str, str]]:
    prev = _V841_PREV_ISSUE_ITEMS() if callable(_V841_PREV_ISSUE_ITEMS) else []
    latest = _v841_paper_latest_obj()
    q_short = '원래 큐 PAPER-001/PAPER-002 유지 · 긴급 DISK-004는 하위 처리'
    d4_status = 'DONE' if bool(latest.get('owner_done')) else 'OPEN'
    d4_short = f"{latest.get('name')} {latest.get('mb')}MB / main권한오류 {bool(latest.get('main_permission_error'))} / paper owner 정리 필요 {bool(latest.get('needs_owner_cleanup'))}"
    add = [
        {'id':'QUEUE-001','status':'OPEN','title':'긴급수정 후 원래 작업 누락 방지','short':q_short,'owner':'issue ledger next-surgery queue','close':'/batch와 /issue_ledger에 다음 수술 큐가 고정 표시되고 PAPER-001/PAPER-002가 처리될 때까지 유지'},
        {'id':'DISK-004','status':d4_status,'title':'paper_candidates_latest 권한/owner 정리','short':d4_short,'owner':'paper_bot cleanup owner','close':'main PermissionError 없이 paper가 paper_candidates_latest를 20~50MB 상한으로 유지'},
    ]
    replace = {x['id'] for x in add}
    out=[]
    for raw in prev:
        if not isinstance(raw, dict):
            continue
        if str(raw.get('id') or '') in replace:
            continue
        out.append(dict(raw))
    # put queue near top, disk-004 near disk items
    return add[:1] + out + add[1:]

_v830_issue_items = _v841_issue_items  # type: ignore[assignment]


def _v841_next_action_lines() -> List[str]:
    return [
        '- 다음 수술 큐는 고정: PAPER-001/PAPER-002가 원래 본수술이다.',
        '- 단, 남은 디스크 하위문제 DISK-004는 paper owner cleanup으로 먼저 안정화한다.',
        '- 안정화 확인 후 바로 paper trigger 표시값 단일화 + v628 구경로/문구 정리로 이동한다.',
    ]

_v830_next_action_lines = _v841_next_action_lines  # type: ignore[assignment]


def _v841_cleanup_status_lines(detail: bool = False) -> List[str]:
    lines = _v840_cleanup_status_lines(detail=detail) if '_v840_cleanup_status_lines' in globals() else []
    latest = _v841_paper_latest_obj()
    lines.append(f"- DISK-004: {latest.get('name')} {latest.get('mb')}MB / 상한 {latest.get('limit_mb')}MB / 정리주인 paper_bot / main 직접 truncate 금지")
    if latest.get('main_permission_error'):
        lines.append('- 권한오류 확인: main 직접 정리 경로 제거됨 · paper owner cleanup으로 이관')
    if detail:
        owner = latest.get('paper_owner') if isinstance(latest.get('paper_owner'), dict) else {}
        if owner:
            lines.append(f"- paper owner 결과: before {owner.get('before_mb','-')}MB → after {owner.get('after_mb','-')}MB / saved {owner.get('saved_mb','-')}MB / errors {owner.get('errors',0)}")
        else:
            lines.append('- paper owner 결과: 아직 없음 · paper 재시작/cleanup 실행 후 확인')
    return lines


def _v841_cleanup_status_text() -> str:
    lines=['🧹 긴급 디스크 순환정리 /cleanup_status · v841']
    lines += _v841_cleanup_status_lines(detail=True)
    lines += ['', '[다음 수술 큐]'] + _v841_work_queue_lines(detail=False)
    lines += ['', '[장부 연결]'] + _v830_issue_ledger_chat_lines(16)
    return _v834_easy_text('\n'.join(str(x) for x in lines))


def _v841_batch_text(outputs: Optional[Dict[str,str]] = None, timings: Optional[List[Dict[str,Any]]] = None) -> str:
    lines=['📊 코인봇 운영판 /batch · v841']
    lines += ['① 적용/성과'] + _v809_apply_short_lines()[:3] + _v811_score_short_lines()[:3]
    lines += ['', '② 다음 수술 큐'] + _v841_work_queue_lines(detail=False)
    lines += ['', '③ 디스크 긴급정리'] + _v841_cleanup_status_lines(detail=False)[:8]
    lines += ['', '④ 지금 병목'] + _v828_structure_digest_lines()
    lines += ['', '⑤ paper 판정값 충돌 확인'] + _v834_paper_mismatch_lines(detail=False)
    lines += ['', '⑥ TRIGGER-001 세부분류'] + _v830_trigger_classification_lines(detail=False)[:6]
    lines += ['', '⑦ 문제장부'] + _v830_issue_ledger_chat_lines(16)
    lines += ['', '⑧ 다음'] + _v841_next_action_lines()
    return _v834_easy_text('\n'.join(str(x) for x in lines))


def _v841_issue_ledger_text() -> str:
    lines=['🧾 문제장부 /issue_ledger · v841']
    lines += _v830_issue_ledger_detail_lines()
    lines += ['', '[QUEUE-001 다음 수술 큐]'] + _v841_work_queue_lines(detail=True)
    lines += ['', '[DISK-004 paper latest owner]'] + [f"- {x}" for x in [f"대상 paper_candidates_latest.jsonl { _v841_paper_latest_obj().get('mb') }MB", 'main 직접 truncate 금지', 'paper_bot cleanup owner가 20~50MB로 유지']]
    lines += ['', '[DISK/RETENTION 상세]'] + _v841_cleanup_status_lines(detail=True)
    lines += ['', '[PAPER-001/PAPER-002 상세]'] + _v834_paper_mismatch_lines(detail=True)
    lines += ['', '[다음]'] + _v841_next_action_lines()
    return _v834_easy_text('\n'.join(str(x) for x in lines))


def _v841_paper_gate_audit_text() -> str:
    lines=['🧪 PAPER-001 paper 판정값 충돌 확인 /paper_gate_audit · v841']
    lines += _v834_paper_mismatch_lines(detail=True)
    lines += ['', '[다음 수술 큐]'] + _v841_work_queue_lines(detail=False)
    lines += ['', '[기존 S1 hold→paper 검산]'] + _v832_paper_gate_audit_lines(detail=True)
    lines += ['', '[장부]'] + _v830_issue_ledger_chat_lines(16)
    return _v834_easy_text('\n'.join(str(x) for x in lines))


def _v841_batch_summary_text(cmds: List[str], outputs: Dict[str,str], timings: List[Dict[str,Any]], recv_delay: float, total_sec: float, chat_body: str = '') -> str:
    global _V797_PENDING_BATCH_MARKER_TS
    batch_until = now_ts(); _V797_PENDING_BATCH_MARKER_TS = batch_until
    since_ts = _v798_batch_marker_ts() if '_v798_batch_marker_ts' in globals() else 0.0
    lines=['코인봇 묶음 요약집 v841', f'- 생성: {_v800_kst_text(batch_until)}', f'- 메인봇: {BOT_VERSION} / {V650_BUILD_LABEL}', f'- 접수지연: {recv_delay:.2f}s / 처리합계: {total_sec:.2f}s', '', '[명령 처리시간]']
    for t in timings:
        lines.append(f"- {'✅' if not t.get('error') else '❌'} /{t.get('name','?')}: {float(t.get('sec') or 0):.2f}s / {'OK' if not t.get('error') else 'ERR'}")
    lines += ['', '[채팅 운영판]', _v650_safe_body(chat_body or _v841_batch_text(outputs, timings), 7600), '']
    lines += ['', '[다음 수술 큐]'] + _v841_work_queue_lines(detail=True)
    lines += ['', '[문제장부 전체]'] + _v830_issue_ledger_detail_lines()
    lines += ['', '[디스크 긴급정리 상세]'] + _v841_cleanup_status_lines(detail=True)
    lines += ['', '[PAPER-001/PAPER-002 상세]'] + _v834_paper_mismatch_lines(detail=True)
    lines += ['', '[TRIGGER-001 세부분류 상세]'] + _v830_trigger_classification_lines(detail=True)
    lines += ['', '[명령별 짧은 요약]'] + _v817_command_summary_lines(outputs, timings, cmds)
    lines += ['', '[전체 상세 요약]', _v650_safe_body(_v833_easy_text(_v807_batch_text()), 10000), '']
    lines += ['', '[MTF 구조판 상세]'] + [_v833_easy_text('\n'.join(_v826_structure_short_lines()))]
    lines += _v799_trade_detail_lines_range(since_ts, batch_until)
    lines += ['', '[통합 검증판 상세]'] + [_v833_easy_text('\n'.join(_v807_integrated_validation_lines(since_ts, batch_until, compact=False)))]
    lines += ['', '[가격반응 지연·체결착시 품질판 상세]'] + [_v833_easy_text('\n'.join(_v807_price_lag_quality_lines(10) + _v810_quality_route_lines()))]
    lines += ['', '[OPEN직전 보류 사후검증]'] + _v810_preopen_review_lines(10)
    lines += ['', '[아까운 후보 / 놓친 후보 상세]'] + _v805_missed_summary_lines(10)
    lines += ['', '[명령별 상세]']
    for name in cmds:
        lines += ['', f'/{name}', _v650_safe_body(_v834_easy_text(outputs.get(name,'')), 5200)]
    return _v834_easy_text('\n'.join(str(x) for x in lines))

# v841 command binding
COMMANDS['batch'] = _v841_batch_text
COMMANDS['summary'] = _v841_batch_text
COMMANDS['pbatch'] = _v841_batch_text
COMMANDS['cleanup_status'] = _v841_cleanup_status_text
COMMANDS['ledger_cleanup'] = _v841_cleanup_status_text
COMMANDS['disk_cleanup'] = _v841_cleanup_status_text
COMMANDS['cleanup'] = _v841_cleanup_status_text
COMMANDS['issue_ledger'] = _v841_issue_ledger_text
COMMANDS['ledger'] = _v841_issue_ledger_text
COMMANDS['paper_gate_audit'] = _v841_paper_gate_audit_text
COMMANDS['paper_audit'] = _v841_paper_gate_audit_text
COMMANDS['hold_audit'] = _v841_paper_gate_audit_text


def batch_handler(update, context):  # type: ignore[override]
    try:
        msg_date=getattr(getattr(update,'message',None),'date',None)
        recv_delay=time.time()-msg_date.timestamp() if hasattr(msg_date,'timestamp') else 0.0
    except Exception:
        recv_delay=0.0
    cmds = _v820_select_batch_cmds(getattr(context,'args',None) or [])
    stime=time.time(); timings=[]; outputs={}
    _v811_begin_batch_source_lock()
    try:
        multi = len(cmds) > 1
        if multi:
            try: send(update, f'📊 묶음 시작 · {len(cmds)}개 명령 / 작업큐+paper-owner cleanup txt(v841) · 지연 {recv_delay:.2f}s')
            except Exception: pass
        total_cmds=len(cmds)
        for idx, name in enumerate(cmds, start=1):
            fn=COMMANDS.get(name); t0=time.time(); err=None
            if not fn:
                body=f'❌ /{name} 연결 없음'; err='no_handler'
            else:
                try: body=fn()
                except Exception as exc:
                    body=f'❌ /{name} 오류 {exc.__class__.__name__}: {exc}'; err=f'{exc.__class__.__name__}: {exc}'; log_error(f'v841_batch_{name}', exc)
            body = _v834_easy_text(body)
            sec=time.time()-t0
            timings.append({'name':name,'sec':sec,'error':err}); outputs[name]=body
            try:
                if multi: send(update, _v817_command_short_block(idx, total_cmds, name, body, sec, err))
                else: send(update, body)
            except Exception as exc: log_error('v841_batch_send', exc)
        total=time.time()-stime
        chat_body = outputs.get(cmds[0], '') if len(cmds) == 1 else _v841_batch_text(outputs, timings)
        try:
            status=_v650_send_summary_file(update, _v841_batch_summary_text(cmds, outputs, timings, recv_delay, total, chat_body=chat_body))
        except Exception as exc:
            status=f'txt 생성실패 {exc.__class__.__name__}'; log_error('v841_batch_summary_file', exc)
        mark='✅' if '전송완료' in status else '⚠️'; del_mark='✅' if '서버삭제' in status else ('❌' if '전송완료' in status else '❔')
        try: send(update, f'📎 txt {mark} / 삭제 {del_mark} / {total:.2f}s')
        except Exception: pass
    finally:
        _v811_end_batch_source_lock()



# =============================================================================
# main_bot v2.13.842: paper runtime bundle - DISK-004 + PAPER-001/PAPER-002
# - Keeps QUEUE-001 fixed while finishing paper latest owner cleanup and trigger display spine.
# - Main reads paper-owned runtime snapshots; it does not truncate paper_candidates_latest.
# - No S1/S2/S3 thresholds, trigger formula, exit, paper OPEN, guard, or auto-buy change.
# =============================================================================
BOT_VERSION = '수익형 v2.13.842'
MAIN_BOT_VERSION = BOT_VERSION
V650_BUILD_LABEL = 'v842_paper_runtime_trigger_spine_2026-06-11'


def _v842_read_status() -> Dict[str, Any]:
    try:
        obj = load_json(BASE_DIR/'paper_bot_status.json', {}) if 'load_json' in globals() else {}
        return obj if isinstance(obj, dict) else {}
    except Exception:
        return {}


def _v842_cleanup_state() -> Dict[str, Any]:
    return _v840_cleanup_state_load() if '_v840_cleanup_state_load' in globals() else {}


def _v842_paper_runtime_obj() -> Dict[str, Any]:
    st = _v842_read_status(); cleanup = _v842_cleanup_state()
    latest = _v841_paper_latest_obj() if '_v841_paper_latest_obj' in globals() else {}
    owner = cleanup.get('paper_latest_owner_cleanup_v842') or cleanup.get('paper_latest_owner_cleanup_v841')
    if not isinstance(owner, dict): owner = {}
    spine = cleanup.get('paper_trigger_spine_v842') if isinstance(cleanup.get('paper_trigger_spine_v842'), dict) else (st.get('paper_trigger_spine_v842') if isinstance(st.get('paper_trigger_spine_v842'), dict) else {})
    version = str(st.get('version') or st.get('paper_version') or cleanup.get('paper_runtime_version_v842') or cleanup.get('paper_runtime_version_v841') or '-')
    build = str(st.get('build') or st.get('paper_runtime_build') or cleanup.get('paper_runtime_build_v842') or cleanup.get('paper_runtime_build_v841') or '-')
    latest_mb = float(latest.get('mb') or 0.0)
    owner_after = float(owner.get('after_mb') or latest_mb or 0.0)
    owner_done = bool(owner) and owner_after <= 50.0 and int(owner.get('errors') or 0) == 0
    spine_active = bool(spine) and ('v842' in str(spine.get('schema') or '') or 'v842' in str(spine.get('build') or ''))
    return {
        'status': st, 'cleanup': cleanup, 'version': version, 'build': build,
        'latest': latest, 'latest_mb': latest_mb, 'owner': owner, 'owner_done': owner_done,
        'spine': spine, 'spine_active': spine_active,
        'paper_v842_active': ('v0.801' in version or 'v842' in build or spine_active),
    }


def _v842_paper_runtime_lines(detail: bool = False) -> List[str]:
    o = _v842_paper_runtime_obj(); owner=o.get('owner') if isinstance(o.get('owner'),dict) else {}; spine=o.get('spine') if isinstance(o.get('spine'),dict) else {}
    lines = [
        f"- paper runtime: {o.get('version')} / build {o.get('build')}",
        f"- DISK-004: paper_candidates_latest {o.get('latest_mb')}MB / owner_done {bool(o.get('owner_done'))}",
        f"- trigger spine: active {bool(o.get('spine_active'))} / owner paper_runtime_snapshot / formula_changed False",
    ]
    if owner:
        lines.append(f"- paper owner 결과: before {owner.get('before_mb','-')}MB → after {owner.get('after_mb','-')}MB / saved {owner.get('saved_mb','-')}MB / errors {owner.get('errors',0)}")
    if spine:
        lines.append(f"- spine 상태: schema {spine.get('schema','-')} / v628문구제거 {spine.get('v628_user_visible_reason_removed', spine.get('old_v628_label_removed','-'))}")
    if detail:
        lines.append('- 닫는 기준: paper v0.801/v842가 돌고, paper_latest 20~50MB 유지, paper gate reason에 v628 표시가 사라짐')
    return lines


def _v842_clean_reason_text(text: Any) -> str:
    t = str(text or '')
    t = t.replace('trigger_not_reached_v628:', '방아쇠 가격 미도달:')
    t = t.replace('trigger_missing_v628:', '방아쇠 가격 없음:')
    t = t.replace('trigger_reached_v628:', '방아쇠 도달 확인:')
    t = t.replace('trigger_not_reached_v675', '방아쇠 가격 미도달')
    return t.strip()


_V842_PREV_PAPER_MISMATCH_OBJ = _v834_paper_mismatch_obj if '_v834_paper_mismatch_obj' in globals() else None

def _v834_paper_mismatch_obj() -> Dict[str, Any]:  # type: ignore[override]
    obj = _V842_PREV_PAPER_MISMATCH_OBJ() if callable(_V842_PREV_PAPER_MISMATCH_OBJ) else {}
    if not isinstance(obj, dict): obj={}
    rt = _v842_paper_runtime_obj()
    obj['paper_runtime_v842'] = rt
    counts = obj.get('conflict_counts') if isinstance(obj.get('conflict_counts'), Counter) else Counter()
    samples = obj.get('samples') if isinstance(obj.get('samples'), list) else []
    # Re-label v628 findings as legacy until paper v842 runtime proves it is active; do not hide conflict.
    old_count = int(obj.get('old_path_count') or 0)
    if bool(rt.get('paper_v842_active')):
        # Current v842 runtime is the owner. Old v628 strings in previous summary/cache are legacy evidence only.
        if old_count:
            obj['legacy_v628_cache_count_v842'] = old_count
            obj['old_path_count'] = 0
            try:
                if 'v628 문구/구경로 확인' in counts:
                    del counts['v628 문구/구경로 확인']
            except Exception:
                pass
        for s in samples:
            if isinstance(s, dict):
                s['paper_reason_v834'] = _v842_clean_reason_text(s.get('paper_reason_v834') or s.get('reason'))
                s['paper_reason_v842'] = s['paper_reason_v834']
                flags = [x for x in (s.get('conflict_flags_v834') or []) if 'v628' not in str(x)]
                s['conflict_flags_v834'] = flags
                s['conflict_flags_v842'] = flags
    return obj


def _v842_paper_mismatch_lines(detail: bool = False) -> List[str]:
    obj = _v834_paper_mismatch_obj()
    base = obj.get('base') if isinstance(obj.get('base'), dict) else {}
    counts = obj.get('conflict_counts') if isinstance(obj.get('conflict_counts'), Counter) else Counter()
    ready = int(base.get('open_ready_count') or 0); hold=int(base.get('hold_count') or 0)
    rt = obj.get('paper_runtime_v842') if isinstance(obj.get('paper_runtime_v842'),dict) else _v842_paper_runtime_obj()
    legacy_v628 = int(obj.get('legacy_v628_cache_count_v842') or 0)
    old = int(obj.get('old_path_count') or 0)
    if counts:
        verdict = '❌ paper trigger 표시값 충돌 남음: paper runtime snapshot 기준으로 계속 검산'
    elif not bool(rt.get('paper_v842_active')):
        verdict = '🟡 paper v842 runtime 확인 전: trigger spine 적용 대기'
    else:
        verdict = '✅ paper trigger spine 본선 표시 중: v628 현재 문구는 제거됨'
    lines=[
        f'- 판독: {verdict}',
        f'- 대상: S1 hold {hold} / 진입준비 {ready}',
        f"- paper runtime: {rt.get('version')} / build {rt.get('build')}",
        f"- trigger spine active: {bool(rt.get('spine_active'))} / formula_changed False",
    ]
    if counts:
        lines.append('- 판정 충돌/확인: ' + _v830_counter_line(counts, 4))
    else:
        lines.append('- 판정 충돌/확인: 현재 충돌 샘플 없음/관찰')
    lines.append(f'- v628 확인: 현재표시 {old}회 / legacy cache {legacy_v628}회')
    dom = _v842_clean_reason_text(str(obj.get('dominant_reason') or ''))
    if dom:
        lines.append(f'- paper 최종보류 대표사유: {dom}')
    if detail:
        lines += ['- 닫는 기준: paper 최종보류가 본 trigger_price와 hold 표시 trigger/reached가 같은 paper runtime spine으로 표시될 것']
        lines += _v842_paper_runtime_lines(detail=True)
    return lines


_V842_PREV_ISSUE_ITEMS = _v830_issue_items if '_v830_issue_items' in globals() else None

def _v842_issue_items() -> List[Dict[str, str]]:
    prev = _V842_PREV_ISSUE_ITEMS() if callable(_V842_PREV_ISSUE_ITEMS) else []
    rt = _v842_paper_runtime_obj(); audit = _v834_paper_mismatch_obj()
    counts = audit.get('conflict_counts') if isinstance(audit.get('conflict_counts'), Counter) else Counter()
    ready = int((audit.get('base') if isinstance(audit.get('base'),dict) else {}).get('open_ready_count') or 0)
    old = int(audit.get('old_path_count') or 0); legacy=int(audit.get('legacy_v628_cache_count_v842') or 0)
    p1_status = 'OPEN' if counts or ready > 0 or not bool(rt.get('spine_active')) else 'CHECK'
    p2_status = 'OPEN' if old or not bool(rt.get('paper_v842_active')) else 'CHECK'
    d4_status = 'DONE' if bool(rt.get('owner_done')) else 'OPEN'
    q_status = 'OPEN' if p1_status == 'OPEN' or p2_status == 'OPEN' or d4_status == 'OPEN' else 'CHECK'
    replacements = {
        'QUEUE-001': {'id':'QUEUE-001','status':q_status,'title':'긴급수정 후 원래 작업 누락 방지','short':'원래 큐 PAPER-001/PAPER-002 유지 · v842에서 DISK-004와 묶음 처리','owner':'issue ledger next-surgery queue','close':'PAPER-001/PAPER-002 처리 완료 전까지 다음 수술 큐 유지'},
        'PAPER-001': {'id':'PAPER-001','status':p1_status,'title':'paper trigger 표시값 단일화','short':f"spine_active {bool(rt.get('spine_active'))} / 충돌 {(_v830_counter_line(counts,3) if counts else '관찰')} / ready {ready}", 'owner':'paper runtime snapshot → trigger gate 표시값','close':'paper가 본 trigger_price와 hold 표시 trigger/reached가 같은 paper runtime spine으로 일치'},
        'PAPER-002': {'id':'PAPER-002','status':p2_status,'title':'v628 방아쇠 미도달 문구/구경로 정리','short':f'현재 v628 {old}회 / legacy cache {legacy}회 / paper_v842 {bool(rt.get("paper_v842_active"))}', 'owner':'paper final hold reason → main 표시판','close':'현재 paper 최종보류 문구에서 v628 제거, 기존 흔적은 legacy cache로만 분리'},
        'DISK-004': {'id':'DISK-004','status':d4_status,'title':'paper_candidates_latest 권한/owner 정리','short':f"paper_latest {rt.get('latest_mb')}MB / owner_done {bool(rt.get('owner_done'))}", 'owner':'paper_bot cleanup owner','close':'main PermissionError 없이 paper가 paper_candidates_latest를 20~50MB 상한으로 유지'},
    }
    out=[]; seen=set()
    for raw in prev:
        if not isinstance(raw, dict): continue
        pid=str(raw.get('id') or '')
        if pid in replacements:
            if pid not in seen: out.append(replacements[pid]); seen.add(pid)
        else:
            out.append(dict(raw)); seen.add(pid)
    for pid in ('QUEUE-001','PAPER-001','PAPER-002','DISK-004'):
        if pid not in seen:
            out.insert(0 if pid=='QUEUE-001' else len(out), replacements[pid]); seen.add(pid)
    return out

_v830_issue_items = _v842_issue_items  # type: ignore[assignment]


def _v842_work_queue_lines(detail: bool = False) -> List[str]:
    rt=_v842_paper_runtime_obj()
    lines=[
        '- 1순위 묶음 수술: DISK-004 + PAPER-001/PAPER-002 · 같은 paper runtime 라인',
        f"- DISK-004: paper_candidates_latest {rt.get('latest_mb')}MB / owner_done {bool(rt.get('owner_done'))}",
        f"- PAPER-001/PAPER-002: trigger spine active {bool(rt.get('spine_active'))} / paper_v842 {bool(rt.get('paper_v842_active'))}",
        '- 다음 순서 고정: v842 적용확인 → TRIGGER-001 계산선 검산 → QUALITY/LATE 분리',
        '- 금지: 조건/S1·S2·S3 기준/trigger 산식/청산/paper OPEN/guard 변경 금지',
    ]
    if detail:
        lines.append('- 닫는 기준: DISK-004 owner_done + PAPER-001 spine 표시 + PAPER-002 현재 v628 문구 0회')
    return lines


def _v842_next_action_lines() -> List[str]:
    return [
        '- v842 확인: paper v0.801/v842 runtime, paper_latest 20~50MB, v628 현재표시 0회.',
        '- 확인되면 다음은 TRIGGER-001 계산선 과상향 검산으로 이동한다.',
        '- 조건/trigger 산식/청산 변경은 아직 금지. 먼저 구조선/표시값 검산만 한다.',
    ]

_v830_next_action_lines = _v842_next_action_lines  # type: ignore[assignment]


def _v842_cleanup_status_text() -> str:
    lines=['🧹 paper runtime 정리 /cleanup_status · v842']
    lines += _v841_cleanup_status_lines(detail=True) if '_v841_cleanup_status_lines' in globals() else []
    lines += ['', '[paper runtime bundle]'] + _v842_paper_runtime_lines(detail=True)
    lines += ['', '[다음 수술 큐]'] + _v842_work_queue_lines(detail=False)
    lines += ['', '[장부 연결]'] + _v830_issue_ledger_chat_lines(18)
    return _v834_easy_text('\n'.join(str(x) for x in lines))


def _v842_batch_text(outputs: Optional[Dict[str,str]] = None, timings: Optional[List[Dict[str,Any]]] = None) -> str:
    lines=['📊 코인봇 운영판 /batch · v842']
    lines += ['① 적용/성과'] + _v809_apply_short_lines()[:3] + _v811_score_short_lines()[:3]
    lines += ['', '② 다음 수술 큐'] + _v842_work_queue_lines(detail=False)
    lines += ['', '③ paper runtime/DISK-004'] + _v842_paper_runtime_lines(detail=False)
    lines += ['', '④ 지금 병목'] + _v828_structure_digest_lines()
    lines += ['', '⑤ PAPER-001/PAPER-002'] + _v842_paper_mismatch_lines(detail=False)
    lines += ['', '⑥ TRIGGER-001 세부분류'] + _v830_trigger_classification_lines(detail=False)[:6]
    lines += ['', '⑦ 문제장부'] + _v830_issue_ledger_chat_lines(18)
    lines += ['', '⑧ 다음'] + _v842_next_action_lines()
    return _v834_easy_text('\n'.join(str(x) for x in lines))


def _v842_issue_ledger_text() -> str:
    lines=['🧾 문제장부 /issue_ledger · v842']
    lines += _v830_issue_ledger_detail_lines()
    lines += ['', '[QUEUE 다음 수술 큐]'] + _v842_work_queue_lines(detail=True)
    lines += ['', '[paper runtime/DISK-004]'] + _v842_paper_runtime_lines(detail=True)
    lines += ['', '[PAPER-001/PAPER-002 상세]'] + _v842_paper_mismatch_lines(detail=True)
    lines += ['', '[TRIGGER-001 세부분류]'] + _v830_trigger_classification_lines(detail=True)
    lines += ['', '[다음]'] + _v842_next_action_lines()
    return _v834_easy_text('\n'.join(str(x) for x in lines))


def _v842_paper_gate_audit_text() -> str:
    lines=['🧪 PAPER-001/PAPER-002 trigger spine /paper_gate_audit · v842']
    lines += _v842_paper_mismatch_lines(detail=True)
    lines += ['', '[paper runtime]'] + _v842_paper_runtime_lines(detail=True)
    lines += ['', '[다음 수술 큐]'] + _v842_work_queue_lines(detail=False)
    lines += ['', '[기존 S1 hold→paper 검산]'] + _v832_paper_gate_audit_lines(detail=True)
    lines += ['', '[장부]'] + _v830_issue_ledger_chat_lines(18)
    return _v834_easy_text('\n'.join(str(x) for x in lines))


def _v842_batch_summary_text(cmds: List[str], outputs: Dict[str,str], timings: List[Dict[str,Any]], recv_delay: float, total_sec: float, chat_body: str = '') -> str:
    global _V797_PENDING_BATCH_MARKER_TS
    batch_until = now_ts(); _V797_PENDING_BATCH_MARKER_TS = batch_until
    since_ts = _v798_batch_marker_ts() if '_v798_batch_marker_ts' in globals() else 0.0
    lines=['코인봇 묶음 요약집 v842', f'- 생성: {_v800_kst_text(batch_until)}', f'- 메인봇: {BOT_VERSION} / {V650_BUILD_LABEL}', f'- 접수지연: {recv_delay:.2f}s / 처리합계: {total_sec:.2f}s', '', '[명령 처리시간]']
    for t in timings:
        lines.append(f"- {'✅' if not t.get('error') else '❌'} /{t.get('name','?')}: {float(t.get('sec') or 0):.2f}s / {'OK' if not t.get('error') else 'ERR'}")
    lines += ['', '[채팅 운영판]', _v650_safe_body(chat_body or _v842_batch_text(outputs, timings), 7600), '']
    lines += ['', '[다음 수술 큐]'] + _v842_work_queue_lines(detail=True)
    lines += ['', '[문제장부 전체]'] + _v830_issue_ledger_detail_lines()
    lines += ['', '[paper runtime/DISK-004]'] + _v842_paper_runtime_lines(detail=True)
    lines += ['', '[PAPER-001/PAPER-002 상세]'] + _v842_paper_mismatch_lines(detail=True)
    lines += ['', '[TRIGGER-001 세부분류 상세]'] + _v830_trigger_classification_lines(detail=True)
    lines += ['', '[명령별 짧은 요약]'] + _v817_command_summary_lines(outputs, timings, cmds)
    lines += ['', '[전체 상세 요약]', _v650_safe_body(_v833_easy_text(_v807_batch_text()), 10000), '']
    lines += ['', '[MTF 구조판 상세]'] + [_v833_easy_text('\n'.join(_v826_structure_short_lines()))]
    lines += _v799_trade_detail_lines_range(since_ts, batch_until)
    lines += ['', '[통합 검증판 상세]'] + [_v833_easy_text('\n'.join(_v807_integrated_validation_lines(since_ts, batch_until, compact=False)))]
    lines += ['', '[가격반응 지연·체결착시 품질판 상세]'] + [_v833_easy_text('\n'.join(_v807_price_lag_quality_lines(10) + _v810_quality_route_lines()))]
    lines += ['', '[OPEN직전 보류 사후검증]'] + _v810_preopen_review_lines(10)
    lines += ['', '[아까운 후보 / 놓친 후보 상세]'] + _v805_missed_summary_lines(10)
    lines += ['', '[명령별 상세]']
    for name in cmds:
        lines += ['', f'/{name}', _v650_safe_body(_v834_easy_text(outputs.get(name,'')), 5200)]
    return _v834_easy_text('\n'.join(str(x) for x in lines))

# v842 command binding
COMMANDS['batch'] = _v842_batch_text
COMMANDS['summary'] = _v842_batch_text
COMMANDS['pbatch'] = _v842_batch_text
COMMANDS['cleanup_status'] = _v842_cleanup_status_text
COMMANDS['ledger_cleanup'] = _v842_cleanup_status_text
COMMANDS['disk_cleanup'] = _v842_cleanup_status_text
COMMANDS['cleanup'] = _v842_cleanup_status_text
COMMANDS['issue_ledger'] = _v842_issue_ledger_text
COMMANDS['ledger'] = _v842_issue_ledger_text
COMMANDS['paper_gate_audit'] = _v842_paper_gate_audit_text
COMMANDS['paper_audit'] = _v842_paper_gate_audit_text
COMMANDS['hold_audit'] = _v842_paper_gate_audit_text


def batch_handler(update, context):  # type: ignore[override]
    try:
        msg_date=getattr(getattr(update,'message',None),'date',None)
        recv_delay=time.time()-msg_date.timestamp() if hasattr(msg_date,'timestamp') else 0.0
    except Exception:
        recv_delay=0.0
    cmds = _v820_select_batch_cmds(getattr(context,'args',None) or [])
    stime=time.time(); timings=[]; outputs={}
    _v811_begin_batch_source_lock()
    try:
        multi = len(cmds) > 1
        if multi:
            try: send(update, f'📊 묶음 시작 · {len(cmds)}개 명령 / paper runtime trigger spine txt(v842) · 지연 {recv_delay:.2f}s')
            except Exception: pass
        total_cmds=len(cmds)
        for idx, name in enumerate(cmds, start=1):
            fn=COMMANDS.get(name); t0=time.time(); err=None
            if not fn:
                body=f'❌ /{name} 연결 없음'; err='no_handler'
            else:
                try: body=fn()
                except Exception as exc:
                    body=f'❌ /{name} 오류 {exc.__class__.__name__}: {exc}'; err=f'{exc.__class__.__name__}: {exc}'; log_error(f'v842_batch_{name}', exc)
            body = _v834_easy_text(body)
            sec=time.time()-t0
            timings.append({'name':name,'sec':sec,'error':err}); outputs[name]=body
            try:
                if multi: send(update, _v817_command_short_block(idx, total_cmds, name, body, sec, err))
                else: send(update, body)
            except Exception as exc: log_error('v842_batch_send', exc)
        total=time.time()-stime
        chat_body = outputs.get(cmds[0], '') if len(cmds) == 1 else _v842_batch_text(outputs, timings)
        try:
            status=_v650_send_summary_file(update, _v842_batch_summary_text(cmds, outputs, timings, recv_delay, total, chat_body=chat_body))
        except Exception as exc:
            status=f'txt 생성실패 {exc.__class__.__name__}'; log_error('v842_batch_summary_file', exc)
        mark='✅' if '전송완료' in status else '⚠️'; del_mark='✅' if '서버삭제' in status else ('❌' if '전송완료' in status else '❔')
        try: send(update, f'📎 txt {mark} / 삭제 {del_mark} / {total:.2f}s')
        except Exception: pass
    finally:
        _v811_end_batch_source_lock()


# =============================================================================
# main_bot v2.13.843: paper runtime entrypoint pin
# - v842 main applied, but paper stayed v0.800/v841. This version makes the
#   paper runtime/entrypoint mismatch explicit and treats DISK-004 + PAPER-001/2
#   as blocked until the real paper process runs the pinned paper file.
# - No condition, trigger formula, exit, paper OPEN, guard, or auto-buy changes.
# =============================================================================
BOT_VERSION = '수익형 v2.13.843'
MAIN_BOT_VERSION = BOT_VERSION
V650_BUILD_LABEL = 'v843_paper_entrypoint_pin_2026-06-12'
EXPECTED_PAPER_VERSION = 'paper_bot_v0.802'
EXPECTED_PAPER_BUILD = 'paper_entrypoint_pin_v843_2026-06-12'


def _v843_paper_runtime_obj() -> Dict[str, Any]:
    st = _v650_status() if '_v650_status' in globals() else (_v650_load(FILES.get('paper_status', BASE_DIR/'paper_bot_status.json'), {}) or {})
    cleanup = _v650_load(BASE_DIR/'paper_bot_cleanup_state.json', {}) or {}
    latest_path = BASE_DIR/'paper_candidates_latest.jsonl'
    tmp_path = BASE_DIR/'paper_candidates_latest.jsonl.tmp'
    try:
        live_mb = round(latest_path.stat().st_size/1024/1024, 2) if latest_path.exists() else 0.0
    except Exception:
        live_mb = 0.0
    try:
        tmp_mb = round(tmp_path.stat().st_size/1024/1024, 2) if tmp_path.exists() else 0.0
    except Exception:
        tmp_mb = 0.0
    ver = str((st or {}).get('paper_version') or (st or {}).get('version') or '-')
    build = str((st or {}).get('paper_runtime_build') or (st or {}).get('build') or '-')
    pin_status = (st.get('paper_entrypoint_pin_v843') if isinstance(st, dict) else None) or (cleanup.get('paper_entrypoint_pin_v843') if isinstance(cleanup, dict) else None)
    if not isinstance(pin_status, dict):
        pin_status = {}
    spine843 = (st.get('paper_trigger_spine_v843') if isinstance(st, dict) else None) or (cleanup.get('paper_trigger_spine_v843') if isinstance(cleanup, dict) else None)
    spine842 = (st.get('paper_trigger_spine_v842') if isinstance(st, dict) else None) or (cleanup.get('paper_trigger_spine_v842') if isinstance(cleanup, dict) else None)
    owner843 = cleanup.get('paper_latest_owner_cleanup_v843') if isinstance(cleanup.get('paper_latest_owner_cleanup_v843'), dict) else {}
    owner842 = cleanup.get('paper_latest_owner_cleanup_v842') if isinstance(cleanup.get('paper_latest_owner_cleanup_v842'), dict) else {}
    owner841 = cleanup.get('paper_latest_owner_cleanup_v841') if isinstance(cleanup.get('paper_latest_owner_cleanup_v841'), dict) else {}
    owner = owner843 or owner842 or owner841 or {}
    paper_v843 = ('paper_bot_v0.802' in ver) or ('paper_entrypoint_pin_v843' in build) or bool(pin_status.get('active'))
    spine_active = bool((isinstance(spine843, dict) and spine843.get('schema')) or ((isinstance(spine842, dict) and spine842.get('schema')) and paper_v843))
    latest_ok = (0.0 < live_mb <= 50.0)
    tmp_stale = False
    try:
        tmp_stale = tmp_path.exists() and (_v650_file_age(tmp_path) > 60.0)
    except Exception:
        tmp_stale = False
    return {
        'version': ver,
        'build': build,
        'expected_version': EXPECTED_PAPER_VERSION,
        'expected_build': EXPECTED_PAPER_BUILD,
        'paper_v843_active': bool(paper_v843),
        'spine_active': bool(spine_active),
        'owner_done': bool(latest_ok and (paper_v843 or bool(owner.get('ok')))),
        'latest_mb': live_mb,
        'latest_ok': bool(latest_ok),
        'tmp_mb': tmp_mb,
        'tmp_stale': bool(tmp_stale),
        'owner': owner,
        'pin_status': pin_status,
        'formula_changed': False,
    }


def _v843_paper_runtime_lines(detail: bool=False) -> List[str]:
    o=_v843_paper_runtime_obj()
    lines=[
        f"- paper runtime: {o.get('version')} / build {o.get('build')}",
        f"- expected: {o.get('expected_version')} / {o.get('expected_build')}",
        f"- entrypoint pinned: {bool(o.get('paper_v843_active'))} / trigger spine active {bool(o.get('spine_active'))} / formula_changed {bool(o.get('formula_changed'))}",
        f"- DISK-004: paper_candidates_latest {o.get('latest_mb')}MB / latest_ok {bool(o.get('latest_ok'))} / owner_done {bool(o.get('owner_done'))}",
        f"- tmp 잔여: {o.get('tmp_mb')}MB / stale {bool(o.get('tmp_stale'))}",
    ]
    if detail:
        lines.append('- 닫는 기준: paper v0.802/v843가 실제 실행되고, latest 20~50MB 유지, trigger spine active True, v628 현재표시 0회')
    return lines


def _v843_paper_mismatch_lines(detail: bool=False) -> List[str]:
    rt=_v843_paper_runtime_obj()
    audit = _v834_paper_mismatch_obj() if '_v834_paper_mismatch_obj' in globals() else {}
    old = int(audit.get('v628_count') or audit.get('legacy_v628_count') or 0) if isinstance(audit, dict) else 0
    ready = int(audit.get('ready') or 0) if isinstance(audit, dict) else 0
    collision = int(audit.get('conflict') or audit.get('collision') or 0) if isinstance(audit, dict) else 0
    verdict = '✅ paper runtime spine 정상' if rt.get('paper_v843_active') and rt.get('spine_active') and old == 0 else '❌ paper runtime/trigger spine 미완료'
    lines=[
        f'- 판독: {verdict}',
        f"- paper_v843: {bool(rt.get('paper_v843_active'))} / trigger spine active {bool(rt.get('spine_active'))}",
        f"- 대상: S1 진입준비 {ready} / 도달·미도달 충돌 {collision}",
        f"- v628 현재표시: {old}회",
        '- 닫는 기준: paper 최종보류가 본 trigger_price와 hold 표시 trigger/reached가 같은 paper runtime spine으로 표시될 것',
    ]
    if detail:
        lines += _v843_paper_runtime_lines(detail=True)
    return lines


_v843_prev_issue_items = _v830_issue_items if '_v830_issue_items' in globals() else None

def _v843_issue_items() -> List[Dict[str, Any]]:
    prev = _v843_prev_issue_items() if callable(_v843_prev_issue_items) else []
    rt=_v843_paper_runtime_obj()
    audit = _v834_paper_mismatch_obj() if '_v834_paper_mismatch_obj' in globals() else {}
    old = int(audit.get('v628_count') or audit.get('legacy_v628_count') or 0) if isinstance(audit, dict) else 0
    d4_status = 'DONE' if rt.get('owner_done') else 'OPEN'
    pr_status = 'DONE' if rt.get('paper_v843_active') else 'OPEN'
    p1_status = 'DONE' if rt.get('spine_active') and old == 0 else 'OPEN'
    replacements={
        'QUEUE-001': {'id':'QUEUE-001','status':'OPEN','title':'긴급수정 후 원래 작업 누락 방지','short':'PAPER-001/PAPER-002 완료 전까지 다음 수술 큐 유지 · v843은 paper entrypoint 고정', 'owner':'issue ledger next-surgery queue','close':'PAPER-001/PAPER-002 처리 완료 전까지 다음 수술 큐 유지'},
        'PAPER-RUNTIME-001': {'id':'PAPER-RUNTIME-001','status':pr_status,'title':'paper 실제 실행 entrypoint 본선 고정','short':f"paper {rt.get('version')} / build {rt.get('build')} / expected {rt.get('expected_version')}", 'owner':'paper process entrypoint','close':'paper_bot.py/구버전 alias가 같은 v843 paper 본선을 실행'},
        'PAPER-001': {'id':'PAPER-001','status':p1_status,'title':'paper trigger 표시값 단일화','short':f"spine_active {bool(rt.get('spine_active'))} / paper_v843 {bool(rt.get('paper_v843_active'))} / v628 {old}회", 'owner':'paper runtime snapshot → trigger gate 표시값','close':'paper가 본 trigger_price와 hold 표시 trigger/reached가 같은 paper runtime spine으로 일치'},
        'PAPER-002': {'id':'PAPER-002','status':p1_status,'title':'v628 방아쇠 미도달 문구/구경로 정리','short':f"현재 v628 {old}회 / paper_v843 {bool(rt.get('paper_v843_active'))}", 'owner':'paper final hold reason → main 표시판','close':'현재 paper 최종보류 문구에서 v628 제거, 기존 흔적은 legacy cache로만 분리'},
        'DISK-004': {'id':'DISK-004','status':d4_status,'title':'paper_candidates_latest 권한/owner 정리','short':f"paper_latest {rt.get('latest_mb')}MB / tmp {rt.get('tmp_mb')}MB / owner_done {bool(rt.get('owner_done'))}", 'owner':'paper_bot cleanup owner','close':'main PermissionError 없이 paper가 paper_candidates_latest를 20~50MB 상한으로 유지'},
    }
    out=[]; seen=set()
    for raw in prev:
        if not isinstance(raw, dict):
            continue
        pid=str(raw.get('id') or '')
        if pid in replacements:
            if pid not in seen:
                out.append(replacements[pid]); seen.add(pid)
        else:
            out.append(dict(raw)); seen.add(pid)
    for pid in ('QUEUE-001','PAPER-RUNTIME-001','PAPER-001','PAPER-002','DISK-004'):
        if pid not in seen:
            out.insert(0 if pid=='QUEUE-001' else len(out), replacements[pid]); seen.add(pid)
    return out

_v830_issue_items = _v843_issue_items  # type: ignore[assignment]


def _v843_work_queue_lines(detail: bool=False) -> List[str]:
    rt=_v843_paper_runtime_obj()
    lines=[
        '- 1순위 수술: PAPER-RUNTIME-001 · paper 실제 실행 entrypoint 본선 고정',
        f"- 확인값: paper_v843 {bool(rt.get('paper_v843_active'))} / trigger spine {bool(rt.get('spine_active'))} / latest {rt.get('latest_mb')}MB / tmp {rt.get('tmp_mb')}MB",
        '- 다음 순서 고정: paper runtime 일치 확인 → PAPER-001/PAPER-002 닫기 → TRIGGER-001 계산선 검산',
        '- 금지: 조건/S1·S2·S3 기준/trigger 산식/청산/paper OPEN/guard 변경 금지',
    ]
    if detail:
        lines.append('- 닫는 기준: /health와 /paper_gate_audit가 paper v0.802/v843 + trigger spine active True를 표시')
    return lines


def _v843_next_action_lines() -> List[str]:
    return [
        '- 먼저 paper 실제 실행 버전이 v0.802/v843인지 확인한다.',
        '- 확인되면 PAPER-001/PAPER-002를 닫고, 다음은 TRIGGER-001 계산선 과상향 검산으로 이동한다.',
        '- 조건/trigger 산식/청산 변경은 아직 금지. 실행경로/표시값 검산만 한다.',
    ]

_v830_next_action_lines = _v843_next_action_lines  # type: ignore[assignment]


def _v843_cleanup_status_text() -> str:
    lines=['🧹 paper entrypoint 고정 /cleanup_status · v843']
    lines += _v841_cleanup_status_lines(detail=True) if '_v841_cleanup_status_lines' in globals() else []
    lines += ['', '[paper runtime entrypoint]'] + _v843_paper_runtime_lines(detail=True)
    lines += ['', '[다음 수술 큐]'] + _v843_work_queue_lines(detail=True)
    lines += ['', '[장부 연결]'] + _v830_issue_ledger_chat_lines(20)
    return _v834_easy_text('\n'.join(str(x) for x in lines))


def _v843_batch_text(outputs: Optional[Dict[str,str]] = None, timings: Optional[List[Dict[str,Any]]] = None) -> str:
    lines=['📊 코인봇 운영판 /batch · v843']
    lines += ['① 적용/성과'] + _v809_apply_short_lines()[:3] + _v811_score_short_lines()[:3]
    lines += ['', '② 다음 수술 큐'] + _v843_work_queue_lines(detail=False)
    lines += ['', '③ paper runtime entrypoint'] + _v843_paper_runtime_lines(detail=False)
    lines += ['', '④ PAPER-001/PAPER-002'] + _v843_paper_mismatch_lines(detail=False)
    lines += ['', '⑤ 지금 병목'] + _v828_structure_digest_lines()
    lines += ['', '⑥ TRIGGER-001 세부분류'] + _v830_trigger_classification_lines(detail=False)[:6]
    lines += ['', '⑦ 문제장부'] + _v830_issue_ledger_chat_lines(20)
    lines += ['', '⑧ 다음'] + _v843_next_action_lines()
    return _v834_easy_text('\n'.join(str(x) for x in lines))


def _v843_issue_ledger_text() -> str:
    lines=['🧾 문제장부 /issue_ledger · v843']
    lines += _v830_issue_ledger_detail_lines()
    lines += ['', '[QUEUE 다음 수술 큐]'] + _v843_work_queue_lines(detail=True)
    lines += ['', '[paper runtime entrypoint]'] + _v843_paper_runtime_lines(detail=True)
    lines += ['', '[PAPER-001/PAPER-002 상세]'] + _v843_paper_mismatch_lines(detail=True)
    lines += ['', '[TRIGGER-001 세부분류]'] + _v830_trigger_classification_lines(detail=True)
    lines += ['', '[다음]'] + _v843_next_action_lines()
    return _v834_easy_text('\n'.join(str(x) for x in lines))


def _v843_paper_gate_audit_text() -> str:
    lines=['🧪 PAPER-RUNTIME/PAPER-001 trigger spine /paper_gate_audit · v843']
    lines += _v843_paper_mismatch_lines(detail=True)
    lines += ['', '[paper runtime entrypoint]'] + _v843_paper_runtime_lines(detail=True)
    lines += ['', '[다음 수술 큐]'] + _v843_work_queue_lines(detail=False)
    lines += ['', '[기존 S1 hold→paper 검산]'] + _v832_paper_gate_audit_lines(detail=True)
    lines += ['', '[장부]'] + _v830_issue_ledger_chat_lines(20)
    return _v834_easy_text('\n'.join(str(x) for x in lines))


def _v843_batch_summary_text(cmds: List[str], outputs: Dict[str,str], timings: List[Dict[str,Any]], recv_delay: float, total_sec: float, chat_body: str = '') -> str:
    global _V797_PENDING_BATCH_MARKER_TS
    batch_until = now_ts(); _V797_PENDING_BATCH_MARKER_TS = batch_until
    since_ts = _v798_batch_marker_ts() if '_v798_batch_marker_ts' in globals() else 0.0
    lines=['코인봇 묶음 요약집 v843', f'- 생성: {_v800_kst_text(batch_until)}', f'- 메인봇: {BOT_VERSION} / {V650_BUILD_LABEL}', f'- 접수지연: {recv_delay:.2f}s / 처리합계: {total_sec:.2f}s', '', '[명령 처리시간]']
    for t in timings:
        lines.append(f"- {'✅' if not t.get('error') else '❌'} /{t.get('name','?')}: {float(t.get('sec') or 0):.2f}s / {'OK' if not t.get('error') else 'ERR'}")
    lines += ['', '[채팅 운영판]', _v650_safe_body(chat_body or _v843_batch_text(outputs, timings), 7600), '']
    lines += ['', '[다음 수술 큐]'] + _v843_work_queue_lines(detail=True)
    lines += ['', '[문제장부 전체]'] + _v830_issue_ledger_detail_lines()
    lines += ['', '[paper runtime entrypoint]'] + _v843_paper_runtime_lines(detail=True)
    lines += ['', '[PAPER-001/PAPER-002 상세]'] + _v843_paper_mismatch_lines(detail=True)
    lines += ['', '[TRIGGER-001 세부분류 상세]'] + _v830_trigger_classification_lines(detail=True)
    lines += ['', '[명령별 짧은 요약]'] + _v817_command_summary_lines(outputs, timings, cmds)
    lines += ['', '[전체 상세 요약]', _v650_safe_body(_v833_easy_text(_v807_batch_text()), 10000), '']
    lines += ['', '[MTF 구조판 상세]'] + [_v833_easy_text('\n'.join(_v826_structure_short_lines()))]
    lines += _v799_trade_detail_lines_range(since_ts, batch_until)
    lines += ['', '[통합 검증판 상세]'] + [_v833_easy_text('\n'.join(_v807_integrated_validation_lines(since_ts, batch_until, compact=False)))]
    lines += ['', '[가격반응 지연·체결착시 품질판 상세]'] + [_v833_easy_text('\n'.join(_v807_price_lag_quality_lines(10) + _v810_quality_route_lines()))]
    lines += ['', '[OPEN직전 보류 사후검증]'] + _v810_preopen_review_lines(10)
    lines += ['', '[아까운 후보 / 놓친 후보 상세]'] + _v805_missed_summary_lines(10)
    lines += ['', '[명령별 상세]']
    for name in cmds:
        lines += ['', f'/{name}', _v650_safe_body(_v834_easy_text(outputs.get(name,'')), 5200)]
    return _v834_easy_text('\n'.join(str(x) for x in lines))

COMMANDS['batch'] = _v843_batch_text
COMMANDS['summary'] = _v843_batch_text
COMMANDS['pbatch'] = _v843_batch_text
COMMANDS['cleanup_status'] = _v843_cleanup_status_text
COMMANDS['ledger_cleanup'] = _v843_cleanup_status_text
COMMANDS['disk_cleanup'] = _v843_cleanup_status_text
COMMANDS['cleanup'] = _v843_cleanup_status_text
COMMANDS['issue_ledger'] = _v843_issue_ledger_text
COMMANDS['ledger'] = _v843_issue_ledger_text
COMMANDS['paper_gate_audit'] = _v843_paper_gate_audit_text
COMMANDS['paper_audit'] = _v843_paper_gate_audit_text
COMMANDS['hold_audit'] = _v843_paper_gate_audit_text


def batch_handler(update, context):  # type: ignore[override]
    try:
        msg_date=getattr(getattr(update,'message',None),'date',None)
        recv_delay=time.time()-msg_date.timestamp() if hasattr(msg_date,'timestamp') else 0.0
    except Exception:
        recv_delay=0.0
    cmds = _v820_select_batch_cmds(getattr(context,'args',None) or [])
    stime=time.time(); timings=[]; outputs={}
    _v811_begin_batch_source_lock()
    try:
        multi = len(cmds) > 1
        if multi:
            try: send(update, f'📊 묶음 시작 · {len(cmds)}개 명령 / paper entrypoint pin txt(v843) · 지연 {recv_delay:.2f}s')
            except Exception: pass
        total_cmds=len(cmds)
        for idx, name in enumerate(cmds, start=1):
            fn=COMMANDS.get(name); t0=time.time(); err=None
            if not fn:
                body=f'❌ /{name} 연결 없음'; err='no_handler'
            else:
                try: body=fn()
                except Exception as exc:
                    body=f'❌ /{name} 오류 {exc.__class__.__name__}: {exc}'; err=f'{exc.__class__.__name__}: {exc}'; log_error(f'v843_batch_{name}', exc)
            body = _v834_easy_text(body)
            sec=time.time()-t0
            timings.append({'name':name,'sec':sec,'error':err}); outputs[name]=body
            try:
                if multi: send(update, _v817_command_short_block(idx, total_cmds, name, body, sec, err))
                else: send(update, body)
            except Exception as exc: log_error('v843_batch_send', exc)
        total=time.time()-stime
        chat_body = outputs.get(cmds[0], '') if len(cmds) == 1 else _v843_batch_text(outputs, timings)
        try:
            status=_v650_send_summary_file(update, _v843_batch_summary_text(cmds, outputs, timings, recv_delay, total, chat_body=chat_body))
        except Exception as exc:
            status=f'txt 생성실패 {exc.__class__.__name__}'; log_error('v843_batch_summary_file', exc)
        mark='✅' if '전송완료' in status else '⚠️'; del_mark='✅' if '서버삭제' in status else ('❌' if '전송완료' in status else '❔')
        try: send(update, f'📎 txt {mark} / 삭제 {del_mark} / {total:.2f}s')
        except Exception: pass
    finally:
        _v811_end_batch_source_lock()


# =============================================================================
# main_bot v2.13.844: live ledger + zip ledger seed spine
# - zip ledger = release-time baseline notebook.
# - server live ledger = runtime board/source of truth.
# - Telegram commands only display live ledger; they do not become the ledger.
# - No condition, trigger formula, exit, paper OPEN, guard, or auto-buy changes.
# =============================================================================
BOT_VERSION = '수익형 v2.13.844'
MAIN_BOT_VERSION = BOT_VERSION
V650_BUILD_LABEL = 'v844_live_ledger_zip_seed_2026-06-12'

V844_LEDGER_DIR = BASE_DIR / 'ledger'
V844_LIVE_LEDGER_PATH = V844_LEDGER_DIR / 'issue_ledger_live.json'
V844_EVENT_LOG_PATH = V844_LEDGER_DIR / 'issue_ledger_events.jsonl'
V844_QUEUE_PATH = V844_LEDGER_DIR / 'next_work_queue_live.json'
V844_SEED_PATH = V844_LEDGER_DIR / 'issue_ledger_seed.json'
V844_RELEASE_MANIFEST_PATH = V844_LEDGER_DIR / 'release_manifest.json'
V844_VERIFY_PATH = V844_LEDGER_DIR / 'verify_after_apply.txt'
V844_POLICY_PATH = V844_LEDGER_DIR / 'protected_files_policy.json'
_V844_LEDGER_REFRESH_LAST_TS = 0.0
_V844_LEDGER_LAST_SIGNATURE = ''


def _v844_kst_now_text() -> str:
    try:
        return _v800_kst_text(now_ts())
    except Exception:
        return time.strftime('%Y-%m-%d %H:%M:%S')


def _v844_status_rank(status: str) -> int:
    s = str(status or '').upper()
    if s == 'OPEN': return 0
    if s == 'CHECK': return 1
    if s == 'DONE': return 2
    return 1


def _v844_write_json(path: Path, obj: Any) -> Optional[str]:
    try:
        path.parent.mkdir(parents=True, exist_ok=True)
        tmp = path.with_suffix(path.suffix + '.tmp')
        tmp.write_text(json.dumps(obj, ensure_ascii=False, indent=2, default=str), encoding='utf-8')
        os.replace(tmp, path)
        return None
    except Exception as exc:
        try:
            log_error('v844_live_ledger_write', exc)
        except Exception:
            pass
        return f'{exc.__class__.__name__}: {exc}'


def _v844_append_event(event: Dict[str, Any]) -> Optional[str]:
    try:
        V844_EVENT_LOG_PATH.parent.mkdir(parents=True, exist_ok=True)
        with V844_EVENT_LOG_PATH.open('a', encoding='utf-8') as f:
            f.write(json.dumps(event, ensure_ascii=False, default=str) + '\n')
        return None
    except Exception as exc:
        try:
            log_error('v844_live_ledger_event', exc)
        except Exception:
            pass
        return f'{exc.__class__.__name__}: {exc}'


_V844_PREV_ISSUE_ITEMS = _v830_issue_items if '_v830_issue_items' in globals() else None


def _v844_seed_extra_items() -> List[Dict[str, Any]]:
    rt = _v843_paper_runtime_obj() if '_v843_paper_runtime_obj' in globals() else {}
    return [
        {
            'id': 'LIVE_LEDGER-001', 'status': 'OPEN', 'title': '실시간 작업장부 spine',
            'short': 'zip seed는 출발점, server live ledger는 실제 상황판, Telegram은 표시층',
            'owner': 'main live ledger writer + worker/paper evidence writers',
            'close': 'issue_ledger_live.json/next_work_queue_live.json이 생성되고 /batch·/issue_ledger가 live ledger age와 next queue를 표시',
        },
        {
            'id': 'ZIP_LEDGER-001', 'status': 'OPEN', 'title': '배포 zip 내부 장부 seed 포함',
            'short': 'coinbot_update zip 안에 ledger seed/queue/manifest/verify/policy 포함',
            'owner': 'release bundle manifest',
            'close': 'zip 장부가 서버 live 장부를 덮어쓰지 않고 merge 기준표로만 작동',
        },
        {
            'id': 'AUTO_LEDGER-001', 'status': 'OPEN', 'title': '오류·재발·새 문제 자동 장부 반영',
            'short': '새 오류/재발/복기 새 문제/작업순서 밀림을 장부에 자동 기록',
            'owner': 'errorlog/cleanup/paper/trigger audit ledger writer',
            'close': '새 오류가 ERROR-001 또는 신규 issue로 기록되고 next queue의 resume_to가 유지',
        },
        {
            'id': 'PAPER-RUNTIME-001', 'status': 'DONE' if bool(rt.get('paper_v843_active')) else 'OPEN',
            'title': 'paper 실제 실행 entrypoint 본선 고정',
            'short': f"paper {rt.get('version','-')} / build {rt.get('build','-')} / expected {rt.get('expected_version','-')}",
            'owner': 'paper process entrypoint',
            'close': 'paper_bot.py/구버전 alias가 같은 v843+ paper 본선을 실행',
        },
    ]


def _v844_collect_runtime_items() -> List[Dict[str, Any]]:
    base = _V844_PREV_ISSUE_ITEMS() if callable(_V844_PREV_ISSUE_ITEMS) else []
    items: List[Dict[str, Any]] = []
    seen = set()
    for raw in base:
        if not isinstance(raw, dict):
            continue
        item = dict(raw)
        pid = str(item.get('id') or '').strip()
        if not pid or pid in seen:
            continue
        items.append(item); seen.add(pid)
    for raw in _v844_seed_extra_items():
        pid = str(raw.get('id') or '').strip()
        if not pid:
            continue
        if pid in seen:
            for idx, old in enumerate(items):
                if str(old.get('id') or '') == pid:
                    merged = dict(old); merged.update(raw); items[idx] = merged
                    break
        else:
            items.insert(0 if pid.startswith('LIVE_LEDGER') else len(items), dict(raw)); seen.add(pid)
    # Keep the forgotten-work guard near the top, then live ledger items.
    order = ['QUEUE-001', 'LIVE_LEDGER-001', 'ZIP_LEDGER-001', 'AUTO_LEDGER-001', 'PAPER-RUNTIME-001', 'PAPER-001', 'PAPER-002', 'DISK-004', 'TRIGGER-001']
    rank = {pid:i for i,pid in enumerate(order)}
    items.sort(key=lambda x: (rank.get(str(x.get('id') or ''), 100), _v844_status_rank(str(x.get('status') or '')), str(x.get('id') or '')))
    return items


def _v844_next_queue_obj(items: Optional[List[Dict[str, Any]]] = None) -> Dict[str, Any]:
    if items is None:
        items = _v844_collect_runtime_items()
    rt = _v843_paper_runtime_obj() if '_v843_paper_runtime_obj' in globals() else {}
    d4 = next((x for x in items if str(x.get('id')) == 'DISK-004'), {})
    p1 = next((x for x in items if str(x.get('id')) == 'PAPER-001'), {})
    p2 = next((x for x in items if str(x.get('id')) == 'PAPER-002'), {})
    runtime_ready = bool(rt.get('paper_v843_active')) and bool(rt.get('spine_active'))
    if not runtime_ready:
        current = 'PAPER-RUNTIME-001'
        reason = 'paper 실제 실행본이 기대 build를 타는지 확인 전'
    elif str(d4.get('status','')).upper() != 'DONE':
        current = 'DISK-004'
        reason = 'paper_candidates_latest 상한/owner_done 확인 전'
    elif str(p1.get('status','')).upper() != 'DONE' or str(p2.get('status','')).upper() != 'DONE':
        current = 'PAPER-001/PAPER-002'
        reason = 'trigger 표시값/v628 문구 정리 미완료'
    else:
        current = 'TRIGGER-001'
        reason = 'paper runtime·표시값 spine 확인 후 계산선 검산으로 이동'
    return {
        'schema': 'next_work_queue_live_v844',
        'updated_at': now_ts(),
        'updated_at_text': _v844_kst_now_text(),
        'current_work': current,
        'reason': reason,
        'resume_to': 'PAPER-001/PAPER-002 until DONE, then TRIGGER-001',
        'blocked_by': [] if runtime_ready else ['paper runtime not on expected v843/v844 entrypoint'],
        'order': ['PAPER-RUNTIME-001', 'DISK-004', 'PAPER-001/PAPER-002', 'TRIGGER-001', 'QUALITY-001/LATE-001'],
        'do_not_touch': ['conditions', 'S1/S2/S3 thresholds', 'trigger formula', 'exit rules', 'paper OPEN rule', 'guard', 'auto-buy'],
        'checks_after_apply': ['/health', '/cleanup_status', '/batch', '/issue_ledger', '/paper_gate_audit', '/errorlog'],
    }


def _v844_merge_live_ledger(runtime_items: List[Dict[str, Any]], queue_obj: Dict[str, Any], source: str) -> Tuple[Dict[str, Any], List[str]]:
    old = load_json(V844_LIVE_LEDGER_PATH, {}) or {}
    old_items = {str(x.get('id') or ''): x for x in old.get('issues', []) if isinstance(x, dict)} if isinstance(old, dict) else {}
    changed: List[str] = []
    out_items: List[Dict[str, Any]] = []
    for cur in runtime_items:
        pid = str(cur.get('id') or '')
        prev = old_items.get(pid, {}) if isinstance(old_items.get(pid), dict) else {}
        merged = dict(prev)
        # Current runtime evidence wins for status/short/title/owner/close, but preserve created_at and notes.
        for key in ('id','status','title','short','owner','close'):
            if key in cur:
                merged[key] = cur.get(key)
        merged.setdefault('created_at', prev.get('created_at') or now_ts())
        merged.setdefault('created_at_text', prev.get('created_at_text') or _v844_kst_now_text())
        merged['updated_at'] = now_ts()
        merged['updated_at_text'] = _v844_kst_now_text()
        merged['last_source'] = source
        if prev and (str(prev.get('status')) != str(merged.get('status')) or str(prev.get('short')) != str(merged.get('short'))):
            changed.append(pid)
        elif not prev:
            changed.append(pid)
        out_items.append(merged)
    # Keep server-only custom OPEN/CHECK issues that were not in current seed.
    current_ids = {str(x.get('id') or '') for x in out_items}
    for pid, prev in old_items.items():
        if pid and pid not in current_ids and str(prev.get('status','')).upper() in ('OPEN','CHECK'):
            keep = dict(prev); keep['last_source'] = 'server_live_preserved'; out_items.append(keep)
    live = {
        'schema': 'issue_ledger_live_v844',
        'version': BOT_VERSION,
        'build': V650_BUILD_LABEL,
        'updated_at': now_ts(),
        'updated_at_text': _v844_kst_now_text(),
        'source': source,
        'policy': {
            'zip_ledger_role': 'release baseline only',
            'server_live_role': 'runtime source of truth',
            'telegram_role': 'display only',
            'zip_must_not_overwrite_live': True,
        },
        'auto_capture_rules': [
            '새 오류 발생', '기존 문제 재발', '복기 중 새 문제 발견', '긴급수정으로 작업 순서 밀림',
        ],
        'next_work_queue': queue_obj,
        'issues': out_items,
        'changed_issue_ids': changed[:50],
    }
    return live, changed


def _v844_live_ledger_refresh(source: str = 'command', force: bool = False) -> Dict[str, Any]:
    global _V844_LEDGER_REFRESH_LAST_TS, _V844_LEDGER_LAST_SIGNATURE
    now = now_ts()
    if not force and _V844_LEDGER_REFRESH_LAST_TS and now - _V844_LEDGER_REFRESH_LAST_TS < 2.0:
        cached = load_json(V844_LIVE_LEDGER_PATH, {}) or {}
        if isinstance(cached, dict) and cached.get('schema'):
            return cached
    items = _v844_collect_runtime_items()
    queue_obj = _v844_next_queue_obj(items)
    live, changed = _v844_merge_live_ledger(items, queue_obj, source)
    write_err = _v844_write_json(V844_LIVE_LEDGER_PATH, live)
    queue_err = _v844_write_json(V844_QUEUE_PATH, queue_obj)
    signature = json.dumps({'changed': changed, 'current': queue_obj.get('current_work'), 'statuses': [(x.get('id'), x.get('status'), x.get('short')) for x in live.get('issues', [])]}, ensure_ascii=False, default=str)
    if force or signature != _V844_LEDGER_LAST_SIGNATURE:
        _v844_append_event({
            'schema': 'issue_ledger_event_v844', 'ts': now, 'ts_text': _v844_kst_now_text(),
            'source': source, 'changed_issue_ids': changed[:50], 'current_work': queue_obj.get('current_work'),
            'write_error': write_err, 'queue_write_error': queue_err,
        })
        _V844_LEDGER_LAST_SIGNATURE = signature
    _V844_LEDGER_REFRESH_LAST_TS = now
    if write_err:
        live['write_error'] = write_err
    if queue_err:
        live['queue_write_error'] = queue_err
    return live


def _v844_live_issue_items() -> List[Dict[str, Any]]:
    live = _v844_live_ledger_refresh('issue_items')
    issues = live.get('issues', []) if isinstance(live, dict) else []
    return [dict(x) for x in issues if isinstance(x, dict)]


_v830_issue_items = _v844_live_issue_items  # type: ignore[assignment]


def _v844_ledger_age_obj() -> Dict[str, Any]:
    live = load_json(V844_LIVE_LEDGER_PATH, {}) or {}
    age = _v650_file_age(V844_LIVE_LEDGER_PATH) if V844_LIVE_LEDGER_PATH.exists() else 999999.0
    ev_age = _v650_file_age(V844_EVENT_LOG_PATH) if V844_EVENT_LOG_PATH.exists() else 999999.0
    return {
        'exists': bool(V844_LIVE_LEDGER_PATH.exists()),
        'age': round(age, 1),
        'event_age': round(ev_age, 1),
        'updated_at_text': live.get('updated_at_text') if isinstance(live, dict) else '-',
        'issue_count': len(live.get('issues', [])) if isinstance(live, dict) and isinstance(live.get('issues'), list) else 0,
        'current_work': ((live.get('next_work_queue') or {}).get('current_work') if isinstance(live, dict) else '-') or '-',
        'write_error': live.get('write_error') if isinstance(live, dict) else None,
    }


def _v844_live_ledger_lines(detail: bool = False) -> List[str]:
    live = _v844_live_ledger_refresh('display')
    age = _v844_ledger_age_obj()
    q = live.get('next_work_queue', {}) if isinstance(live, dict) else {}
    stale = age.get('age', 999999) > 60.0
    lines = [
        f"- live ledger: {'✅' if age.get('exists') else '❌'} age {age.get('age')}s / issue {age.get('issue_count')}개 / stale {bool(stale)}",
        f"- current_work: {q.get('current_work','-')} / resume_to: {q.get('resume_to','-')}",
        '- zip ledger: 배포 기준표 · 서버 live 장부를 덮어쓰지 않음',
        '- Telegram: live ledger를 읽어 보여주는 화면',
    ]
    if age.get('write_error'):
        lines.append(f"- ledger write error: {age.get('write_error')}")
    if detail:
        lines += [
            f"- live path: {V844_LIVE_LEDGER_PATH}",
            f"- events path: {V844_EVENT_LOG_PATH}",
            f"- queue path: {V844_QUEUE_PATH}",
            '- 자동 장부 반영: 새 오류/재발/복기 새 문제/작업순서 밀림',
        ]
    return lines


def _v844_work_queue_lines(detail: bool = False) -> List[str]:
    live = _v844_live_ledger_refresh('queue_display')
    q = live.get('next_work_queue', {}) if isinstance(live, dict) else {}
    lines = [
        f"- 현재 작업: {q.get('current_work','-')} · {q.get('reason','-')}",
        f"- 복귀 작업: {q.get('resume_to','-')}",
        '- 순서: ' + ' → '.join(str(x) for x in (q.get('order') or [])),
        '- 금지: 조건/S1·S2·S3 기준/trigger 산식/청산/paper OPEN/guard 변경 금지',
    ]
    blocked = q.get('blocked_by') or []
    if blocked:
        lines.append('- blocked_by: ' + ' / '.join(str(x) for x in blocked))
    if detail:
        lines.append('- 닫는 기준: LIVE_LEDGER-001/ZIP_LEDGER-001 생성 + PAPER-001/PAPER-002가 처리될 때까지 next queue 유지')
    return lines


def _v844_next_action_lines() -> List[str]:
    live = _v844_live_ledger_refresh('next_action')
    q = live.get('next_work_queue', {}) if isinstance(live, dict) else {}
    current = q.get('current_work') or '-'
    if current == 'PAPER-RUNTIME-001':
        return ['- paper 실제 실행 버전이 v0.802/v843 이상인지 먼저 확인한다.', '- 확인되면 PAPER-001/PAPER-002를 닫고 TRIGGER-001 계산선 검산으로 이동한다.', '- 조건/trigger 산식/청산 변경 금지.']
    if current == 'DISK-004':
        return ['- paper_candidates_latest owner_done과 20~50MB 유지 여부를 확인한다.', '- 확인 후 PAPER-001/PAPER-002 trigger 표시값 단일화로 복귀한다.', '- 조건/trigger 산식/청산 변경 금지.']
    if 'PAPER' in str(current):
        return ['- paper trigger 표시값과 v628 문구/구경로를 같은 runtime spine으로 정리한다.', '- 처리 후 TRIGGER-001 계산선 과상향 검산으로 이동한다.', '- 조건/trigger 산식/청산 변경 금지.']
    return ['- live ledger의 current_work 기준으로 다음 수술을 진행한다.', '- 긴급수정이 끼어도 resume_to를 유지한다.', '- 조건/trigger 산식/청산 변경 금지.']


_v830_next_action_lines = _v844_next_action_lines  # type: ignore[assignment]


def _v844_cleanup_status_text() -> str:
    _v844_live_ledger_refresh('cleanup_status', force=True)
    lines=['🧹 live ledger/정리 상태 /cleanup_status · v844']
    lines += _v841_cleanup_status_lines(detail=True) if '_v841_cleanup_status_lines' in globals() else []
    lines += ['', '[실시간 장부]'] + _v844_live_ledger_lines(detail=True)
    lines += ['', '[다음 수술 큐]'] + _v844_work_queue_lines(detail=True)
    lines += ['', '[장부 연결]'] + _v830_issue_ledger_chat_lines(22)
    return _v834_easy_text('\n'.join(str(x) for x in lines))


def _v844_batch_text(outputs: Optional[Dict[str,str]] = None, timings: Optional[List[Dict[str,Any]]] = None) -> str:
    _v844_live_ledger_refresh('batch', force=True)
    lines=['📊 코인봇 운영판 /batch · v844']
    lines += ['① 적용/성과'] + _v809_apply_short_lines()[:3] + _v811_score_short_lines()[:3]
    lines += ['', '② 실시간 장부'] + _v844_live_ledger_lines(detail=False)
    lines += ['', '③ 다음 수술 큐'] + _v844_work_queue_lines(detail=False)
    lines += ['', '④ paper runtime entrypoint'] + _v843_paper_runtime_lines(detail=False)
    lines += ['', '⑤ PAPER-001/PAPER-002'] + _v843_paper_mismatch_lines(detail=False)
    lines += ['', '⑥ 지금 병목'] + _v828_structure_digest_lines()
    lines += ['', '⑦ TRIGGER-001 세부분류'] + _v830_trigger_classification_lines(detail=False)[:6]
    lines += ['', '⑧ 문제장부'] + _v830_issue_ledger_chat_lines(22)
    lines += ['', '⑨ 다음'] + _v844_next_action_lines()
    return _v834_easy_text('\n'.join(str(x) for x in lines))


def _v844_issue_ledger_text() -> str:
    _v844_live_ledger_refresh('issue_ledger', force=True)
    lines=['🧾 실시간 문제장부 /issue_ledger · v844']
    lines += _v844_live_ledger_lines(detail=True)
    lines += ['', '[문제장부: 해결될 때까지 유지]']
    for it in _v830_issue_items():
        lines += [
            f"- {it.get('id','-')} {_v830_status_emoji(it.get('status',''))} {it.get('title','-')}",
            f"  · 상태: {it.get('status','-')} / 현재: {it.get('short','-')}",
            f"  · 주인: {it.get('owner','-')}",
            f"  · 닫는 기준: {it.get('close','-')}",
        ]
    lines += ['', '[QUEUE 다음 수술 큐]'] + _v844_work_queue_lines(detail=True)
    lines += ['', '[paper runtime entrypoint]'] + _v843_paper_runtime_lines(detail=True)
    lines += ['', '[PAPER-001/PAPER-002 상세]'] + _v843_paper_mismatch_lines(detail=True)
    lines += ['', '[TRIGGER-001 세부분류]'] + _v830_trigger_classification_lines(detail=True)
    lines += ['', '[다음]'] + _v844_next_action_lines()
    return _v834_easy_text('\n'.join(str(x) for x in lines))


def _v844_paper_gate_audit_text() -> str:
    _v844_live_ledger_refresh('paper_gate_audit', force=True)
    lines=['🧪 PAPER-RUNTIME/PAPER-001 trigger spine /paper_gate_audit · v844']
    lines += _v844_live_ledger_lines(detail=False)
    lines += ['', '[PAPER-001/PAPER-002]'] + _v843_paper_mismatch_lines(detail=True)
    lines += ['', '[paper runtime entrypoint]'] + _v843_paper_runtime_lines(detail=True)
    lines += ['', '[다음 수술 큐]'] + _v844_work_queue_lines(detail=False)
    lines += ['', '[기존 S1 hold→paper 검산]'] + _v832_paper_gate_audit_lines(detail=True)
    lines += ['', '[장부]'] + _v830_issue_ledger_chat_lines(22)
    return _v834_easy_text('\n'.join(str(x) for x in lines))


def _v844_batch_summary_text(cmds: List[str], outputs: Dict[str,str], timings: List[Dict[str,Any]], recv_delay: float, total_sec: float, chat_body: str = '') -> str:
    global _V797_PENDING_BATCH_MARKER_TS
    _v844_live_ledger_refresh('batch_summary', force=True)
    batch_until = now_ts(); _V797_PENDING_BATCH_MARKER_TS = batch_until
    since_ts = _v798_batch_marker_ts() if '_v798_batch_marker_ts' in globals() else 0.0
    lines=['코인봇 묶음 요약집 v844', f'- 생성: {_v800_kst_text(batch_until)}', f'- 메인봇: {BOT_VERSION} / {V650_BUILD_LABEL}', f'- 접수지연: {recv_delay:.2f}s / 처리합계: {total_sec:.2f}s', '', '[명령 처리시간]']
    for t in timings:
        lines.append(f"- {'✅' if not t.get('error') else '❌'} /{t.get('name','?')}: {float(t.get('sec') or 0):.2f}s / {'OK' if not t.get('error') else 'ERR'}")
    lines += ['', '[채팅 운영판]', _v650_safe_body(chat_body or _v844_batch_text(outputs, timings), 7800), '']
    lines += ['', '[실시간 장부]'] + _v844_live_ledger_lines(detail=True)
    lines += ['', '[다음 수술 큐]'] + _v844_work_queue_lines(detail=True)
    lines += ['', '[문제장부 전체]'] + _v830_issue_ledger_detail_lines()
    lines += ['', '[paper runtime entrypoint]'] + _v843_paper_runtime_lines(detail=True)
    lines += ['', '[PAPER-001/PAPER-002 상세]'] + _v843_paper_mismatch_lines(detail=True)
    lines += ['', '[TRIGGER-001 세부분류 상세]'] + _v830_trigger_classification_lines(detail=True)
    lines += ['', '[명령별 짧은 요약]'] + _v817_command_summary_lines(outputs, timings, cmds)
    lines += ['', '[전체 상세 요약]', _v650_safe_body(_v833_easy_text(_v807_batch_text()), 10000), '']
    lines += ['', '[MTF 구조판 상세]'] + [_v833_easy_text('\n'.join(_v826_structure_short_lines()))]
    lines += _v799_trade_detail_lines_range(since_ts, batch_until)
    lines += ['', '[통합 검증판 상세]'] + [_v833_easy_text('\n'.join(_v807_integrated_validation_lines(since_ts, batch_until, compact=False)))]
    lines += ['', '[가격반응 지연·체결착시 품질판 상세]'] + [_v833_easy_text('\n'.join(_v807_price_lag_quality_lines(10) + _v810_quality_route_lines()))]
    lines += ['', '[OPEN직전 보류 사후검증]'] + _v810_preopen_review_lines(10)
    lines += ['', '[아까운 후보 / 놓친 후보 상세]'] + _v805_missed_summary_lines(10)
    lines += ['', '[명령별 상세]']
    for name in cmds:
        lines += ['', f'/{name}', _v650_safe_body(_v834_easy_text(outputs.get(name,'')), 5200)]
    return _v834_easy_text('\n'.join(str(x) for x in lines))


COMMANDS['batch'] = _v844_batch_text
COMMANDS['summary'] = _v844_batch_text
COMMANDS['pbatch'] = _v844_batch_text
COMMANDS['cleanup_status'] = _v844_cleanup_status_text
COMMANDS['ledger_cleanup'] = _v844_cleanup_status_text
COMMANDS['disk_cleanup'] = _v844_cleanup_status_text
COMMANDS['cleanup'] = _v844_cleanup_status_text
COMMANDS['issue_ledger'] = _v844_issue_ledger_text
COMMANDS['ledger'] = _v844_issue_ledger_text
COMMANDS['paper_gate_audit'] = _v844_paper_gate_audit_text
COMMANDS['paper_audit'] = _v844_paper_gate_audit_text
COMMANDS['hold_audit'] = _v844_paper_gate_audit_text


def batch_handler(update, context):  # type: ignore[override]
    try:
        msg_date=getattr(getattr(update,'message',None),'date',None)
        recv_delay=time.time()-msg_date.timestamp() if hasattr(msg_date,'timestamp') else 0.0
    except Exception:
        recv_delay=0.0
    cmds = _v820_select_batch_cmds(getattr(context,'args',None) or [])
    stime=time.time(); timings=[]; outputs={}
    _v811_begin_batch_source_lock()
    try:
        _v844_live_ledger_refresh('batch_handler_start', force=True)
        multi = len(cmds) > 1
        if multi:
            try: send(update, f'📊 묶음 시작 · {len(cmds)}개 명령 / live ledger spine txt(v844) · 지연 {recv_delay:.2f}s')
            except Exception: pass
        total_cmds=len(cmds)
        for idx, name in enumerate(cmds, start=1):
            fn=COMMANDS.get(name); t0=time.time(); err=None
            if not fn:
                body=f'❌ /{name} 연결 없음'; err='no_handler'
            else:
                try: body=fn()
                except Exception as exc:
                    body=f'❌ /{name} 오류 {exc.__class__.__name__}: {exc}'; err=f'{exc.__class__.__name__}: {exc}'; log_error(f'v844_batch_{name}', exc)
                    _v844_append_event({'schema':'issue_ledger_event_v844','ts':now_ts(),'ts_text':_v844_kst_now_text(),'source':f'batch_error_{name}','issue_id':'ERROR-001','error':err})
            body = _v834_easy_text(body)
            sec=time.time()-t0
            timings.append({'name':name,'sec':sec,'error':err}); outputs[name]=body
            try:
                if multi: send(update, _v817_command_short_block(idx, total_cmds, name, body, sec, err))
                else: send(update, body)
            except Exception as exc: log_error('v844_batch_send', exc)
        total=time.time()-stime
        chat_body = outputs.get(cmds[0], '') if len(cmds) == 1 else _v844_batch_text(outputs, timings)
        try:
            status=_v650_send_summary_file(update, _v844_batch_summary_text(cmds, outputs, timings, recv_delay, total, chat_body=chat_body))
        except Exception as exc:
            status=f'txt 생성실패 {exc.__class__.__name__}'; log_error('v844_batch_summary_file', exc)
            _v844_append_event({'schema':'issue_ledger_event_v844','ts':now_ts(),'ts_text':_v844_kst_now_text(),'source':'batch_summary_error','issue_id':'ERROR-001','error':str(exc)})
        mark='✅' if '전송완료' in status else '⚠️'; del_mark='✅' if '서버삭제' in status else ('❌' if '전송완료' in status else '❔')
        try: send(update, f'📎 txt {mark} / 삭제 {del_mark} / {total:.2f}s')
        except Exception: pass
    finally:
        _v811_end_batch_source_lock()


# =============================================================================
# main_bot v2.13.845: active ledger archive + display source unification
# - Active issue board shows OPEN/CHECK only.
# - DONE issues are compacted to ledger/done_archive.jsonl and removed from active display.
# - paper_candidates_latest size uses one owner snapshot across cleanup/health.
# - SOURCE-001 stale labels use actual worker/candidate age as the source of truth.
# - No condition, trigger formula, exit, paper OPEN, guard, or auto-buy changes.
# =============================================================================
BOT_VERSION = '수익형 v2.13.845'
MAIN_BOT_VERSION = BOT_VERSION
V650_BUILD_LABEL = 'v845_ledger_archive_source_unify_2026-06-12'
V845_DONE_ARCHIVE_PATH = V844_LEDGER_DIR / 'done_archive.jsonl'
V845_DONE_RETENTION_SEC = 3 * 24 * 3600.0


def _v845_paper_latest_canonical_obj() -> Dict[str, Any]:
    rt = _v843_paper_runtime_obj() if '_v843_paper_runtime_obj' in globals() else {}
    cleanup = _v840_cleanup_state_load() if '_v840_cleanup_state_load' in globals() else {}
    owner = {}
    for k in ('paper_latest_owner_cleanup_v843','paper_latest_owner_cleanup_v842','paper_latest_owner_cleanup_v841'):
        v = cleanup.get(k) if isinstance(cleanup.get(k), dict) else {}
        if v:
            owner = v; break
    latest_mb = float(rt.get('latest_mb') or 0.0) if isinstance(rt, dict) else 0.0
    owner_after = None
    try: owner_after = float(owner.get('after_mb'))
    except Exception: owner_after = None
    display_mb = round(owner_after if owner_after is not None and 0 < owner_after <= 50.0 else latest_mb, 2)
    tmp_mb = float(rt.get('tmp_mb') or 0.0) if isinstance(rt, dict) else 0.0
    ok = bool(display_mb > 0 and display_mb <= 50.0 and rt.get('owner_done'))
    return {'latest_mb': latest_mb, 'owner_after_mb': owner_after, 'display_mb': display_mb, 'tmp_mb': round(tmp_mb,2), 'owner_done': bool(rt.get('owner_done')), 'latest_ok': bool(ok), 'source':'paper_latest_owner_snapshot_v845'}


def _v845_archive_existing_signatures() -> set:
    sigs=set()
    try:
        if not V845_DONE_ARCHIVE_PATH.exists(): return sigs
        with V845_DONE_ARCHIVE_PATH.open('r', encoding='utf-8') as f:
            for line in f:
                try:
                    o=json.loads(line)
                    sigs.add((str(o.get('id') or ''), str(o.get('closed_short') or o.get('short') or '')))
                except Exception:
                    continue
    except Exception:
        pass
    return sigs


def _v845_prune_done_archive() -> Dict[str, Any]:
    now = now_ts()
    kept=[]; deleted=0
    try:
        if V845_DONE_ARCHIVE_PATH.exists():
            with V845_DONE_ARCHIVE_PATH.open('r', encoding='utf-8') as f:
                for line in f:
                    try:
                        o=json.loads(line)
                    except Exception:
                        continue
                    ts=float(o.get('archived_at') or o.get('updated_at') or now)
                    if now - ts <= V845_DONE_RETENTION_SEC:
                        kept.append(o)
                    else:
                        deleted += 1
            tmp=V845_DONE_ARCHIVE_PATH.with_suffix('.jsonl.tmp')
            with tmp.open('w', encoding='utf-8') as f:
                for o in kept[-300:]:
                    f.write(json.dumps(o, ensure_ascii=False, default=str)+'\n')
            os.replace(tmp, V845_DONE_ARCHIVE_PATH)
    except Exception as exc:
        try: log_error('v845_done_archive_prune', exc)
        except Exception: pass
    return {'kept':len(kept[-300:]), 'deleted_old':deleted}


def _v845_archive_done_items(done_items: List[Dict[str, Any]], source: str) -> Dict[str, Any]:
    _v845_prune_done_archive()
    existing=_v845_archive_existing_signatures()
    appended=0
    try:
        V845_DONE_ARCHIVE_PATH.parent.mkdir(parents=True, exist_ok=True)
        with V845_DONE_ARCHIVE_PATH.open('a', encoding='utf-8') as f:
            for it in done_items:
                pid=str(it.get('id') or '')
                short=str(it.get('short') or '')
                sig=(pid, short)
                if not pid or sig in existing:
                    continue
                rec={
                    'schema':'done_issue_archive_v845', 'id':pid, 'status':'DONE',
                    'title':it.get('title'), 'closed_short':short,
                    'owner':it.get('owner'), 'close':it.get('close'),
                    'archived_at':now_ts(), 'archived_at_text':_v844_kst_now_text(),
                    'source':source, 'retention_days':3,
                }
                f.write(json.dumps(rec, ensure_ascii=False, default=str)+'\n')
                existing.add(sig); appended += 1
    except Exception as exc:
        try: log_error('v845_done_archive_write', exc)
        except Exception: pass
    stat=_v845_done_archive_stats()
    stat['appended_now']=appended
    return stat


def _v845_done_archive_stats() -> Dict[str, Any]:
    cnt=0; recent=[]
    try:
        if V845_DONE_ARCHIVE_PATH.exists():
            with V845_DONE_ARCHIVE_PATH.open('r', encoding='utf-8') as f:
                for line in f:
                    try: o=json.loads(line)
                    except Exception: continue
                    cnt += 1
                    recent.append(o)
        age=_v650_file_age(V845_DONE_ARCHIVE_PATH) if V845_DONE_ARCHIVE_PATH.exists() else 999999.0
    except Exception:
        age=999999.0
    return {'count':cnt, 'age':round(age,1), 'recent_ids':[str(x.get('id')) for x in recent[-8:] if isinstance(x,dict)]}


def _v845_collect_runtime_items() -> Tuple[List[Dict[str, Any]], List[Dict[str, Any]]]:
    raw = _v844_collect_runtime_items()
    active=[]; done=[]
    seen=set()
    raw_by_id={str(x.get('id') or ''): x for x in raw if isinstance(x, dict)}
    p1_done = str((raw_by_id.get('PAPER-001') or {}).get('status','')).upper() == 'DONE'
    p2_done = str((raw_by_id.get('PAPER-002') or {}).get('status','')).upper() == 'DONE'
    for it in raw:
        if not isinstance(it, dict):
            continue
        pid=str(it.get('id') or '')
        if not pid or pid in seen:
            continue
        item=dict(it)
        # v845: housekeeping items should not occupy active board after their evidence exists.
        if pid == 'QUEUE-001' and p1_done and p2_done:
            item['status']='DONE'; item['short']='PAPER-001/PAPER-002 완료 확인 · 다음 큐는 TRIGGER-001로 복귀'
        elif pid == 'LIVE_LEDGER-001' and V844_LIVE_LEDGER_PATH.parent.exists():
            item['status']='DONE'; item['short']='server live ledger 생성/표시 정상 · active는 OPEN/CHECK만 유지'
        elif pid == 'ZIP_LEDGER-001' and V844_SEED_PATH.exists() and V844_RELEASE_MANIFEST_PATH.exists():
            item['status']='DONE'; item['short']='zip seed/queue/manifest/verify/policy 포함 · 서버 live 장부 덮어쓰기 금지'
        elif pid == 'AUTO_LEDGER-001' and V844_EVENT_LOG_PATH.parent.exists():
            item['status']='DONE'; item['short']='새 오류/재발/복기 새 문제는 event/live ledger에 기록하는 본선 생성'
        seen.add(pid)
        st=str(item.get('status') or '').upper()
        if st == 'DONE':
            done.append(item)
        else:
            active.append(item)
    return active, done


def _v845_merge_live_ledger(runtime_items: List[Dict[str, Any]], queue_obj: Dict[str, Any], source: str, archive_stat: Optional[Dict[str,Any]]=None) -> Tuple[Dict[str, Any], List[str]]:
    old = load_json(V844_LIVE_LEDGER_PATH, {}) or {}
    old_items = {str(x.get('id') or ''): x for x in old.get('issues', []) if isinstance(x, dict)} if isinstance(old, dict) else {}
    changed=[]; out_items=[]
    for cur in runtime_items:
        pid=str(cur.get('id') or '')
        prev=old_items.get(pid,{}) if isinstance(old_items.get(pid),dict) else {}
        merged=dict(prev)
        for key in ('id','status','title','short','owner','close'):
            if key in cur: merged[key]=cur.get(key)
        merged.setdefault('created_at', prev.get('created_at') or now_ts())
        merged.setdefault('created_at_text', prev.get('created_at_text') or _v844_kst_now_text())
        merged['updated_at']=now_ts(); merged['updated_at_text']=_v844_kst_now_text(); merged['last_source']=source
        if prev and (str(prev.get('status')) != str(merged.get('status')) or str(prev.get('short')) != str(merged.get('short'))): changed.append(pid)
        elif not prev: changed.append(pid)
        out_items.append(merged)
    current_ids={str(x.get('id') or '') for x in out_items}
    for pid, prev in old_items.items():
        if pid and pid not in current_ids and str(prev.get('status','')).upper() in ('OPEN','CHECK'):
            keep=dict(prev); keep['last_source']='server_live_preserved'; out_items.append(keep)
    live={
        'schema':'issue_ledger_live_v845', 'version':BOT_VERSION, 'build':V650_BUILD_LABEL,
        'updated_at':now_ts(), 'updated_at_text':_v844_kst_now_text(), 'source':source,
        'policy':{'zip_ledger_role':'release baseline only','server_live_role':'runtime source of truth','telegram_role':'display only','zip_must_not_overwrite_live':True,'active_statuses':['OPEN','CHECK'],'done_policy':'archive_then_hide_from_active'},
        'auto_capture_rules':['새 오류 발생','기존 문제 재발','복기 중 새 문제 발견','긴급수정으로 작업 순서 밀림'],
        'next_work_queue':queue_obj, 'issues':out_items, 'changed_issue_ids':changed[:50],
        'done_archive':archive_stat or _v845_done_archive_stats(),
    }
    return live, changed


def _v845_next_queue_obj(active_items: Optional[List[Dict[str, Any]]] = None) -> Dict[str, Any]:
    if active_items is None:
        active_items, _ = _v845_collect_runtime_items()
    # Source board cleanup must be stable before trigger formula audit.
    source = next((x for x in active_items if str(x.get('id')) == 'SOURCE-001'), {})
    disk5 = next((x for x in active_items if str(x.get('id')) == 'DISK-005'), {})
    if source and str(source.get('status','')).upper() in ('OPEN','CHECK'):
        current='SOURCE-001'
        reason='stale 표시 source 단일화 확인 전'
    elif disk5 and str(disk5.get('status','')).upper() in ('OPEN','CHECK'):
        current='DISK-005'
        reason='paper_latest 크기 source 단일화 확인 전'
    else:
        current='TRIGGER-001'
        reason='장부/표시 source 정리 후 계산선 검산으로 이동'
    return {
        'schema':'next_work_queue_live_v845', 'updated_at':now_ts(), 'updated_at_text':_v844_kst_now_text(),
        'current_work':current, 'reason':reason,
        'resume_to':'TRIGGER-001 after ledger/source board is trustworthy',
        'blocked_by':[] if current == 'TRIGGER-001' else ['display/source mismatch cleanup'],
        'order':['LEDGER-DONE-001','DISK-005','SOURCE-001','TRIGGER-001','QUALITY-001/LATE-001'],
        'do_not_touch':['conditions','S1/S2/S3 thresholds','trigger formula','exit rules','paper OPEN rule','guard','auto-buy'],
        'checks_after_apply':['/health','/cleanup_status','/batch','/issue_ledger','/paper_gate_audit','/errorlog'],
    }


def _v845_live_ledger_refresh(source: str='command', force: bool=False) -> Dict[str, Any]:
    global _V844_LEDGER_REFRESH_LAST_TS, _V844_LEDGER_LAST_SIGNATURE
    now=now_ts()
    if not force and _V844_LEDGER_REFRESH_LAST_TS and now-_V844_LEDGER_REFRESH_LAST_TS < 2.0:
        cached=load_json(V844_LIVE_LEDGER_PATH,{}) or {}
        if isinstance(cached,dict) and cached.get('schema') == 'issue_ledger_live_v845':
            return cached
    active, done = _v845_collect_runtime_items()
    archive_stat = _v845_archive_done_items(done, source)
    # Add v845 housekeeping issues after archive work.
    archive_count = int(archive_stat.get('count') or 0)
    active_ids={str(x.get('id') or '') for x in active}
    if 'LEDGER-DONE-001' not in active_ids:
        led_status = 'DONE' if archive_count > 0 else 'CHECK'
        led_item = {'id':'LEDGER-DONE-001','status':led_status,'title':'DONE active 제거와 archive 순환정리','short':f"active OPEN/CHECK만 표시 · DONE archive {archive_count}개 / age {archive_stat.get('age')}s", 'owner':'live ledger writer','close':'DONE은 active에서 빠지고 done_archive.jsonl에 2~3일만 보관'}
        if led_status == 'DONE':
            _v845_archive_done_items([led_item], source + '_ledger_done')
        else:
            active.insert(1, led_item)
    pcan=_v845_paper_latest_canonical_obj()
    disk5_status = 'DONE' if pcan.get('latest_ok') else 'OPEN'
    disk5_item = {'id':'DISK-005','status':disk5_status,'title':'paper_latest 크기 표시 source 단일화','short':f"display {pcan.get('display_mb')}MB / live {pcan.get('latest_mb')}MB / owner_done {bool(pcan.get('owner_done'))}", 'owner':'cleanup snapshot → health/batch display','close':'cleanup_status와 health 큰 파일 TOP이 같은 paper_latest owner snapshot을 사용'}
    if disk5_status == 'DONE':
        _v845_archive_done_items([disk5_item], source + '_disk5')
    else:
        active.insert(2, disk5_item)
    queue_obj=_v845_next_queue_obj(active)
    live, changed=_v845_merge_live_ledger(active, queue_obj, source, archive_stat)
    write_err=_v844_write_json(V844_LIVE_LEDGER_PATH, live)
    queue_err=_v844_write_json(V844_QUEUE_PATH, queue_obj)
    signature=json.dumps({'changed':changed,'current':queue_obj.get('current_work'),'statuses':[(x.get('id'),x.get('status'),x.get('short')) for x in live.get('issues', [])],'archive':live.get('done_archive')}, ensure_ascii=False, default=str)
    if force or signature != _V844_LEDGER_LAST_SIGNATURE:
        _v844_append_event({'schema':'issue_ledger_event_v845','ts':now,'ts_text':_v844_kst_now_text(),'source':source,'changed_issue_ids':changed[:50],'current_work':queue_obj.get('current_work'),'archived_done_count':archive_stat.get('count'),'write_error':write_err,'queue_write_error':queue_err})
        _V844_LEDGER_LAST_SIGNATURE=signature
    _V844_LEDGER_REFRESH_LAST_TS=now
    if write_err: live['write_error']=write_err
    if queue_err: live['queue_write_error']=queue_err
    return live


def _v845_live_issue_items() -> List[Dict[str, Any]]:
    live=_v845_live_ledger_refresh('issue_items')
    issues=live.get('issues', []) if isinstance(live,dict) else []
    return [dict(x) for x in issues if isinstance(x,dict) and str(x.get('status','')).upper() in ('OPEN','CHECK')]

_v830_issue_items = _v845_live_issue_items  # type: ignore[assignment]
_v844_live_ledger_refresh = _v845_live_ledger_refresh  # type: ignore[assignment]
_v844_live_issue_items = _v845_live_issue_items  # type: ignore[assignment]


def _v845_ledger_age_obj() -> Dict[str, Any]:
    live=load_json(V844_LIVE_LEDGER_PATH,{}) or {}
    age=_v650_file_age(V844_LIVE_LEDGER_PATH) if V844_LIVE_LEDGER_PATH.exists() else 999999.0
    arc=live.get('done_archive', {}) if isinstance(live,dict) and isinstance(live.get('done_archive'),dict) else _v845_done_archive_stats()
    return {'exists':bool(V844_LIVE_LEDGER_PATH.exists()),'age':round(age,1),'issue_count':len(live.get('issues',[])) if isinstance(live,dict) and isinstance(live.get('issues'),list) else 0,'done_count':int(arc.get('count') or 0),'done_age':arc.get('age'), 'current_work':((live.get('next_work_queue') or {}).get('current_work') if isinstance(live,dict) else '-') or '-', 'write_error':live.get('write_error') if isinstance(live,dict) else None}


def _v845_live_ledger_lines(detail: bool=False) -> List[str]:
    live=_v845_live_ledger_refresh('display')
    age=_v845_ledger_age_obj()
    q=live.get('next_work_queue',{}) if isinstance(live,dict) else {}
    stale=float(age.get('age') or 999999) > 60.0
    lines=[
        f"- live ledger: {'✅' if age.get('exists') else '❌'} age {age.get('age')}s / active {age.get('issue_count')}개 / DONE archive {age.get('done_count')}개 / stale {bool(stale)}",
        f"- current_work: {q.get('current_work','-')} / resume_to: {q.get('resume_to','-')}",
        '- active 장부: OPEN/CHECK만 표시 · DONE은 archive로 이동',
        '- zip ledger: 배포 기준표 · 서버 live 장부를 덮어쓰지 않음',
        '- Telegram: live ledger를 읽어 보여주는 화면',
    ]
    if age.get('write_error'): lines.append(f"- ledger write error: {age.get('write_error')}")
    if detail:
        lines += [f"- live path: {V844_LIVE_LEDGER_PATH}", f"- done archive: {V845_DONE_ARCHIVE_PATH}", f"- events path: {V844_EVENT_LOG_PATH}", f"- queue path: {V844_QUEUE_PATH}", '- 자동 장부 반영: 새 오류/재발/복기 새 문제/작업순서 밀림']
    return lines


def _v845_work_queue_lines(detail: bool=False) -> List[str]:
    live=_v845_live_ledger_refresh('queue_display')
    q=live.get('next_work_queue',{}) if isinstance(live,dict) else {}
    lines=[f"- 현재 작업: {q.get('current_work','-')} · {q.get('reason','-')}", f"- 복귀 작업: {q.get('resume_to','-')}", '- 순서: ' + ' → '.join(str(x) for x in (q.get('order') or [])), '- 금지: 조건/S1·S2·S3 기준/trigger 산식/청산/paper OPEN/guard 변경 금지']
    blocked=q.get('blocked_by') or []
    if blocked: lines.append('- blocked_by: ' + ' / '.join(str(x) for x in blocked))
    if detail: lines.append('- 닫는 기준: active는 OPEN/CHECK만, DONE archive 표시, paper_latest/SOURCE source 일치 후 TRIGGER-001 이동')
    return lines


def _v845_next_action_lines() -> List[str]:
    live=_v845_live_ledger_refresh('next_action')
    q=live.get('next_work_queue',{}) if isinstance(live,dict) else {}
    cur=str(q.get('current_work') or '-')
    if 'SOURCE' in cur or 'DISK-005' in cur:
        return ['- 먼저 장부/표시 source가 같은 값을 보게 만든다.', '- paper_latest와 SOURCE stale 오판정이 0인지 확인한다.', '- 통과 후 TRIGGER-001 계산선 검산으로 이동한다.']
    return ['- live ledger의 current_work 기준으로 다음 수술을 진행한다.', '- 긴급수정이 끼어도 resume_to를 유지한다.', '- 조건/trigger 산식/청산 변경 금지.']

_v830_next_action_lines = _v845_next_action_lines  # type: ignore[assignment]


def _v845_cleanup_status_text() -> str:
    _v845_live_ledger_refresh('cleanup_status', force=True)
    lines=['🧹 live ledger/archive/source 정리 /cleanup_status · v845']
    lines += _v841_cleanup_status_lines(detail=True) if '_v841_cleanup_status_lines' in globals() else []
    pcan=_v845_paper_latest_canonical_obj()
    lines += ['', '[paper_latest source 단일화]', f"- 기준: {pcan.get('source')} / 표시 {pcan.get('display_mb')}MB / live {pcan.get('latest_mb')}MB / owner_done {bool(pcan.get('owner_done'))}"]
    lines += ['', '[실시간 장부]'] + _v845_live_ledger_lines(detail=True)
    lines += ['', '[다음 수술 큐]'] + _v845_work_queue_lines(detail=True)
    lines += ['', '[장부 연결: OPEN/CHECK만]'] + _v830_issue_ledger_chat_lines(18)
    return _v834_easy_text('\n'.join(str(x) for x in lines))


def _v845_batch_text(outputs: Optional[Dict[str,str]]=None, timings: Optional[List[Dict[str,Any]]]=None) -> str:
    _v845_live_ledger_refresh('batch', force=True)
    lines=['📊 코인봇 운영판 /batch · v845']
    lines += ['① 적용/성과'] + _v809_apply_short_lines()[:3] + _v811_score_short_lines()[:3]
    lines += ['', '② 실시간 장부'] + _v845_live_ledger_lines(detail=False)
    lines += ['', '③ 다음 수술 큐'] + _v845_work_queue_lines(detail=False)
    lines += ['', '④ source/정리 신뢰도'] + _v833_source_audit_lines(detail=False)[:4]
    pcan=_v845_paper_latest_canonical_obj(); lines += [f"- paper_latest: {pcan.get('display_mb')}MB / owner_done {bool(pcan.get('owner_done'))} / source {pcan.get('source')}"]
    lines += ['', '⑤ 지금 병목'] + _v828_structure_digest_lines()
    lines += ['', '⑥ TRIGGER-001 세부분류'] + _v830_trigger_classification_lines(detail=False)[:6]
    lines += ['', '⑦ 문제장부'] + _v830_issue_ledger_chat_lines(18)
    lines += ['', '⑧ 다음'] + _v845_next_action_lines()
    return _v834_easy_text('\n'.join(str(x) for x in lines))


def _v845_issue_ledger_text() -> str:
    _v845_live_ledger_refresh('issue_ledger', force=True)
    lines=['🧾 실시간 문제장부 /issue_ledger · v845']
    lines += _v845_live_ledger_lines(detail=True)
    arc=_v845_done_archive_stats(); lines += ['', f"[DONE archive: {arc.get('count')}개 / active에서 숨김]", '- 최근 archive: ' + (' / '.join(arc.get('recent_ids') or []) or '-')]
    lines += ['', '[문제장부: OPEN/CHECK만 유지]']
    for it in _v830_issue_items():
        lines += [f"- {it.get('id','-')} {_v830_status_emoji(it.get('status',''))} {it.get('title','-')}", f"  · 상태: {it.get('status','-')} / 현재: {it.get('short','-')}", f"  · 주인: {it.get('owner','-')}", f"  · 닫는 기준: {it.get('close','-')}"]
    lines += ['', '[QUEUE 다음 수술 큐]'] + _v845_work_queue_lines(detail=True)
    lines += ['', '[SOURCE-001 stale source 상세]'] + _v833_source_audit_lines(detail=True)
    lines += ['', '[TRIGGER-001 세부분류]'] + _v830_trigger_classification_lines(detail=True)
    lines += ['', '[다음]'] + _v845_next_action_lines()
    return _v834_easy_text('\n'.join(str(x) for x in lines))


def _v845_paper_gate_audit_text() -> str:
    _v845_live_ledger_refresh('paper_gate_audit', force=True)
    lines=['🧪 PAPER-RUNTIME/PAPER-001 trigger spine /paper_gate_audit · v845']
    lines += _v845_live_ledger_lines(detail=False)
    lines += ['', '[PAPER-001/PAPER-002]'] + _v843_paper_mismatch_lines(detail=True)
    lines += ['', '[paper runtime entrypoint]'] + _v843_paper_runtime_lines(detail=True)
    lines += ['', '[다음 수술 큐]'] + _v845_work_queue_lines(detail=False)
    lines += ['', '[기존 S1 hold→paper 검산]'] + _v832_paper_gate_audit_lines(detail=True)
    lines += ['', '[장부: OPEN/CHECK만]'] + _v830_issue_ledger_chat_lines(18)
    return _v834_easy_text('\n'.join(str(x) for x in lines))


def _v845_batch_summary_text(cmds: List[str], outputs: Dict[str,str], timings: List[Dict[str,Any]], recv_delay: float, total_sec: float, chat_body: str='') -> str:
    global _V797_PENDING_BATCH_MARKER_TS
    _v845_live_ledger_refresh('batch_summary', force=True)
    batch_until=now_ts(); _V797_PENDING_BATCH_MARKER_TS=batch_until
    since_ts=_v798_batch_marker_ts() if '_v798_batch_marker_ts' in globals() else 0.0
    lines=['코인봇 묶음 요약집 v845', f'- 생성: {_v800_kst_text(batch_until)}', f'- 메인봇: {BOT_VERSION} / {V650_BUILD_LABEL}', f'- 접수지연: {recv_delay:.2f}s / 처리합계: {total_sec:.2f}s', '', '[명령 처리시간]']
    for t in timings:
        lines.append(f"- {'✅' if not t.get('error') else '❌'} /{t.get('name','?')}: {float(t.get('sec') or 0):.2f}s / {'OK' if not t.get('error') else 'ERR'}")
    lines += ['', '[채팅 운영판]', _v650_safe_body(chat_body or _v845_batch_text(outputs,timings), 7800), '']
    lines += ['', '[실시간 장부]'] + _v845_live_ledger_lines(detail=True)
    lines += ['', '[다음 수술 큐]'] + _v845_work_queue_lines(detail=True)
    lines += ['', '[문제장부 OPEN/CHECK]'] + _v830_issue_ledger_detail_lines()
    lines += ['', '[SOURCE-001 source 상세]'] + _v833_source_audit_lines(detail=True)
    lines += ['', '[TRIGGER-001 세부분류 상세]'] + _v830_trigger_classification_lines(detail=True)
    lines += ['', '[명령별 짧은 요약]'] + _v817_command_summary_lines(outputs,timings,cmds)
    lines += ['', '[전체 상세 요약]', _v650_safe_body(_v833_easy_text(_v807_batch_text()), 10000), '']
    lines += ['', '[MTF 구조판 상세]'] + [_v833_easy_text('\n'.join(_v826_structure_short_lines()))]
    lines += _v799_trade_detail_lines_range(since_ts,batch_until)
    lines += ['', '[통합 검증판 상세]'] + [_v833_easy_text('\n'.join(_v807_integrated_validation_lines(since_ts,batch_until,compact=False)))]
    lines += ['', '[가격반응 지연·체결착시 품질판 상세]'] + [_v833_easy_text('\n'.join(_v807_price_lag_quality_lines(10)+_v810_quality_route_lines()))]
    lines += ['', '[OPEN직전 보류 사후검증]'] + _v810_preopen_review_lines(10)
    lines += ['', '[아까운 후보 / 놓친 후보 상세]'] + _v805_missed_summary_lines(10)
    lines += ['', '[명령별 상세]']
    for name in cmds:
        lines += ['', f'/{name}', _v650_safe_body(_v834_easy_text(outputs.get(name,'')), 5200)]
    return _v834_easy_text('\n'.join(str(x) for x in lines))

COMMANDS['batch'] = _v845_batch_text
COMMANDS['summary'] = _v845_batch_text
COMMANDS['pbatch'] = _v845_batch_text
COMMANDS['cleanup_status'] = _v845_cleanup_status_text
COMMANDS['ledger_cleanup'] = _v845_cleanup_status_text
COMMANDS['disk_cleanup'] = _v845_cleanup_status_text
COMMANDS['cleanup'] = _v845_cleanup_status_text
COMMANDS['issue_ledger'] = _v845_issue_ledger_text
COMMANDS['ledger'] = _v845_issue_ledger_text
COMMANDS['paper_gate_audit'] = _v845_paper_gate_audit_text
COMMANDS['paper_audit'] = _v845_paper_gate_audit_text
COMMANDS['hold_audit'] = _v845_paper_gate_audit_text


def batch_handler(update, context):  # type: ignore[override]
    try:
        msg_date=getattr(getattr(update,'message',None),'date',None)
        recv_delay=time.time()-msg_date.timestamp() if hasattr(msg_date,'timestamp') else 0.0
    except Exception:
        recv_delay=0.0
    cmds=_v820_select_batch_cmds(getattr(context,'args',None) or [])
    stime=time.time(); timings=[]; outputs={}
    _v811_begin_batch_source_lock()
    try:
        _v845_live_ledger_refresh('batch_handler_start', force=True)
        multi=len(cmds)>1
        if multi:
            try: send(update, f'📊 묶음 시작 · {len(cmds)}개 명령 / ledger archive+source unify txt(v845) · 지연 {recv_delay:.2f}s')
            except Exception: pass
        total_cmds=len(cmds)
        for idx,name in enumerate(cmds,start=1):
            fn=COMMANDS.get(name); t0=time.time(); err=None
            if not fn:
                body=f'❌ /{name} 연결 없음'; err='no_handler'
            else:
                try: body=fn()
                except Exception as exc:
                    body=f'❌ /{name} 오류 {exc.__class__.__name__}: {exc}'; err=f'{exc.__class__.__name__}: {exc}'; log_error(f'v845_batch_{name}', exc)
                    _v844_append_event({'schema':'issue_ledger_event_v845','ts':now_ts(),'ts_text':_v844_kst_now_text(),'source':f'batch_error_{name}','issue_id':'ERROR-001','error':err})
            body=_v834_easy_text(body); sec=time.time()-t0
            timings.append({'name':name,'sec':sec,'error':err}); outputs[name]=body
            try:
                if multi: send(update, _v817_command_short_block(idx,total_cmds,name,body,sec,err))
                else: send(update, body)
            except Exception as exc: log_error('v845_batch_send', exc)
        total=time.time()-stime
        chat_body=outputs.get(cmds[0],'') if len(cmds)==1 else _v845_batch_text(outputs,timings)
        try:
            status=_v650_send_summary_file(update, _v845_batch_summary_text(cmds,outputs,timings,recv_delay,total,chat_body=chat_body))
        except Exception as exc:
            status=f'txt 생성실패 {exc.__class__.__name__}'; log_error('v845_batch_summary_file', exc)
            _v844_append_event({'schema':'issue_ledger_event_v845','ts':now_ts(),'ts_text':_v844_kst_now_text(),'source':'batch_summary_error','issue_id':'ERROR-001','error':str(exc)})
        mark='✅' if '전송완료' in status else '⚠️'; del_mark='✅' if '서버삭제' in status else ('❌' if '전송완료' in status else '❔')
        try: send(update, f'📎 txt {mark} / 삭제 {del_mark} / {total:.2f}s')
        except Exception: pass
    finally:
        _v811_end_batch_source_lock()



# =============================================================================
# main_bot v2.13.846: paper_latest actual cleanup + ledger meta archive
# - v845 fixed the active/DONE display, but paper_candidates_latest actual file
#   could still grow back above the 45MB cap while owner_done stayed False.
# - This version treats actual file size as the only close criterion and uses the
#   paper v846 owner snapshot only as evidence, not as a substitute for reality.
# - It also prevents archived/DONE ledger meta issues from being preserved back
#   into the active board by the live-merge routine.
# - No condition, S1/S2/S3 threshold, trigger formula, exit, paper OPEN, guard,
#   or auto-buy change.
# =============================================================================
BOT_VERSION = '수익형 v2.13.846'
MAIN_BOT_VERSION = BOT_VERSION
V650_BUILD_LABEL = 'v846_paper_latest_actual_cleanup_ledger_meta_2026-06-12'
EXPECTED_PAPER_VERSION = 'paper_bot_v0.803'
EXPECTED_PAPER_BUILD = 'paper_latest_actual_cleanup_v846_2026-06-12'
V846_CLOSED_META_IDS = {'QUEUE-001','LIVE_LEDGER-001','ZIP_LEDGER-001','AUTO_LEDGER-001','LEDGER-DONE-001','PAPER-RUNTIME-001','PAPER-001','PAPER-002'}


def _v846_paper_runtime_obj() -> Dict[str, Any]:
    st = _v650_status() if '_v650_status' in globals() else (_v650_load(FILES.get('paper_status', BASE_DIR/'paper_bot_status.json'), {}) or {})
    cleanup = _v650_load(BASE_DIR/'paper_bot_cleanup_state.json', {}) or {}
    latest_path = BASE_DIR/'paper_candidates_latest.jsonl'
    tmp_path = BASE_DIR/'paper_candidates_latest.jsonl.tmp'
    try:
        live_mb = round(latest_path.stat().st_size/1024/1024, 2) if latest_path.exists() else 0.0
    except Exception:
        live_mb = 0.0
    try:
        tmp_mb = round(tmp_path.stat().st_size/1024/1024, 2) if tmp_path.exists() else 0.0
    except Exception:
        tmp_mb = 0.0
    ver = str((st or {}).get('paper_version') or (st or {}).get('version') or '-')
    build = str((st or {}).get('paper_runtime_build') or (st or {}).get('build') or '-')
    owner846 = cleanup.get('paper_latest_actual_cleanup_v846') if isinstance(cleanup.get('paper_latest_actual_cleanup_v846'), dict) else {}
    owner843 = cleanup.get('paper_latest_owner_cleanup_v843') if isinstance(cleanup.get('paper_latest_owner_cleanup_v843'), dict) else {}
    owner842 = cleanup.get('paper_latest_owner_cleanup_v842') if isinstance(cleanup.get('paper_latest_owner_cleanup_v842'), dict) else {}
    owner841 = cleanup.get('paper_latest_owner_cleanup_v841') if isinstance(cleanup.get('paper_latest_owner_cleanup_v841'), dict) else {}
    owner = owner846 or owner843 or owner842 or owner841 or {}
    pin_status = (st.get('paper_entrypoint_pin_v846') if isinstance(st, dict) else None) or (cleanup.get('paper_entrypoint_pin_v846') if isinstance(cleanup, dict) else None) or (st.get('paper_entrypoint_pin_v843') if isinstance(st, dict) else None) or (cleanup.get('paper_entrypoint_pin_v843') if isinstance(cleanup, dict) else None)
    if not isinstance(pin_status, dict):
        pin_status = {}
    spine846 = (st.get('paper_trigger_spine_v846') if isinstance(st, dict) else None) or (cleanup.get('paper_trigger_spine_v846') if isinstance(cleanup, dict) else None)
    spine843 = (st.get('paper_trigger_spine_v843') if isinstance(st, dict) else None) or (cleanup.get('paper_trigger_spine_v843') if isinstance(cleanup, dict) else None)
    spine842 = (st.get('paper_trigger_spine_v842') if isinstance(st, dict) else None) or (cleanup.get('paper_trigger_spine_v842') if isinstance(cleanup, dict) else None)
    paper_active = ('paper_bot_v0.803' in ver) or ('paper_latest_actual_cleanup_v846' in build) or bool(pin_status.get('active'))
    spine_active = bool((isinstance(spine846, dict) and spine846.get('schema')) or (isinstance(spine843, dict) and spine843.get('schema')) or (isinstance(spine842, dict) and spine842.get('schema')))
    latest_ok = (0.0 < live_mb <= 50.0)
    try:
        tmp_stale = tmp_path.exists() and (_v650_file_age(tmp_path) > 60.0)
    except Exception:
        tmp_stale = False
    return {
        'version': ver, 'build': build, 'expected_version': EXPECTED_PAPER_VERSION, 'expected_build': EXPECTED_PAPER_BUILD,
        'paper_v843_active': bool(paper_active), 'paper_v846_active': bool(paper_active), 'spine_active': bool(spine_active),
        'owner_done': bool(latest_ok and paper_active), 'latest_mb': live_mb, 'latest_ok': bool(latest_ok), 'tmp_mb': tmp_mb,
        'tmp_stale': bool(tmp_stale), 'owner': owner, 'pin_status': pin_status, 'formula_changed': False,
    }

_v843_paper_runtime_obj = _v846_paper_runtime_obj  # type: ignore[assignment]


def _v846_paper_latest_canonical_obj() -> Dict[str, Any]:
    rt = _v846_paper_runtime_obj()
    cleanup = _v840_cleanup_state_load() if '_v840_cleanup_state_load' in globals() else {}
    owner = cleanup.get('paper_latest_actual_cleanup_v846') if isinstance(cleanup.get('paper_latest_actual_cleanup_v846'), dict) else {}
    live_mb = float(rt.get('latest_mb') or 0.0)
    try:
        owner_after = float(owner.get('after_mb'))
    except Exception:
        owner_after = None
    ok = bool(0.0 < live_mb <= 50.0 and rt.get('paper_v846_active') and int(owner.get('errors') or 0) == 0)
    return {
        'latest_mb': round(live_mb,2), 'owner_after_mb': owner_after, 'display_mb': round(live_mb,2),
        'tmp_mb': round(float(rt.get('tmp_mb') or 0.0),2), 'owner_done': bool(ok), 'latest_ok': bool(ok),
        'source':'paper_latest_actual_cleanup_v846', 'owner_action': owner.get('action','-'), 'owner_errors': int(owner.get('errors') or 0),
    }

_v845_paper_latest_canonical_obj = _v846_paper_latest_canonical_obj  # type: ignore[assignment]

_v846_prev_collect_runtime_items = _v845_collect_runtime_items


def _v846_collect_runtime_items() -> Tuple[List[Dict[str, Any]], List[Dict[str, Any]]]:
    active, done = _v846_prev_collect_runtime_items()
    pcan = _v846_paper_latest_canonical_obj()
    for arr in (active, done):
        for it in arr:
            if str(it.get('id')) == 'DISK-004':
                it['status'] = 'DONE' if pcan.get('owner_done') else 'OPEN'
                it['short'] = f"paper_latest {pcan.get('display_mb')}MB / tmp {pcan.get('tmp_mb')}MB / owner_done {bool(pcan.get('owner_done'))}"
            if str(it.get('id')) == 'DISK-005':
                it['status'] = 'DONE' if pcan.get('owner_done') else 'OPEN'
                it['short'] = f"actual {pcan.get('display_mb')}MB / source {pcan.get('source')} / owner_done {bool(pcan.get('owner_done'))}"
    new_active=[]
    for it in active:
        if str(it.get('status','')).upper() == 'DONE':
            done.append(it)
        else:
            new_active.append(it)
    return new_active, done

_v845_collect_runtime_items = _v846_collect_runtime_items  # type: ignore[assignment]


def _v846_merge_live_ledger(runtime_items: List[Dict[str, Any]], queue_obj: Dict[str, Any], source: str, archive_stat: Optional[Dict[str,Any]]=None) -> Tuple[Dict[str, Any], List[str]]:
    old = load_json(V844_LIVE_LEDGER_PATH, {}) or {}
    old_items = {str(x.get('id') or ''): x for x in old.get('issues', []) if isinstance(x, dict)} if isinstance(old, dict) else {}
    changed=[]; out_items=[]; current_ids=set()
    for cur in runtime_items:
        pid=str(cur.get('id') or '')
        if not pid or str(cur.get('status','')).upper() not in ('OPEN','CHECK'):
            continue
        current_ids.add(pid)
        prev=old_items.get(pid,{}) if isinstance(old_items.get(pid),dict) else {}
        merged=dict(prev)
        for key in ('id','status','title','short','owner','close'):
            if key in cur: merged[key]=cur.get(key)
        merged.setdefault('created_at', prev.get('created_at') or now_ts())
        merged.setdefault('created_at_text', prev.get('created_at_text') or _v844_kst_now_text())
        merged['updated_at']=now_ts(); merged['updated_at_text']=_v844_kst_now_text(); merged['last_source']=source
        if prev and (str(prev.get('status')) != str(merged.get('status')) or str(prev.get('short')) != str(merged.get('short'))): changed.append(pid)
        elif not prev: changed.append(pid)
        out_items.append(merged)
    for pid, prev in old_items.items():
        if pid and pid not in current_ids and str(prev.get('status','')).upper() in ('OPEN','CHECK') and pid not in V846_CLOSED_META_IDS:
            keep=dict(prev); keep['last_source']='server_live_preserved_v846'; out_items.append(keep)
    live={
        'schema':'issue_ledger_live_v846', 'version':BOT_VERSION, 'build':V650_BUILD_LABEL,
        'updated_at':now_ts(), 'updated_at_text':_v844_kst_now_text(), 'source':source,
        'policy':{'zip_ledger_role':'release baseline only','server_live_role':'runtime source of truth','telegram_role':'display only','zip_must_not_overwrite_live':True,'active_statuses':['OPEN','CHECK'],'done_policy':'archive_then_hide_from_active','done_dedup':'id+short'},
        'auto_capture_rules':['새 오류 발생','기존 문제 재발','복기 중 새 문제 발견','긴급수정으로 작업 순서 밀림'],
        'next_work_queue':queue_obj, 'issues':out_items, 'changed_issue_ids':changed[:50],
        'done_archive':archive_stat or _v845_done_archive_stats(),
    }
    return live, changed

_v845_merge_live_ledger = _v846_merge_live_ledger  # type: ignore[assignment]


def _v846_next_queue_obj(active_items: Optional[List[Dict[str, Any]]] = None) -> Dict[str, Any]:
    if active_items is None:
        active_items, _ = _v845_collect_runtime_items()
    pcan=_v846_paper_latest_canonical_obj()
    source = next((x for x in active_items if str(x.get('id')) == 'SOURCE-001'), {})
    disk_open = not bool(pcan.get('owner_done'))
    if disk_open:
        current='DISK-004/DISK-005'; reason='paper_latest 실제 파일 상한 45MB 초과 또는 owner_done False'
    elif source and str(source.get('status','')).upper() in ('OPEN','CHECK'):
        current='SOURCE-001'; reason='stale 표시 source 단일화 확인 전'
    else:
        current='TRIGGER-001'; reason='장부/표시 source 정리 후 계산선 검산으로 이동'
    return {'schema':'next_work_queue_live_v846','updated_at':now_ts(),'updated_at_text':_v844_kst_now_text(),'current_work':current,'reason':reason,'resume_to':'TRIGGER-001 after disk/source board is trustworthy','blocked_by':[] if current == 'TRIGGER-001' else ['paper_latest actual cleanup' if disk_open else 'display/source mismatch cleanup'],'order':['DISK-004/DISK-005','SOURCE-001','TRIGGER-001','QUALITY-001/LATE-001'],'do_not_touch':['conditions','S1/S2/S3 thresholds','trigger formula','exit rules','paper OPEN rule','guard','auto-buy'],'checks_after_apply':['/health','/cleanup_status','/batch','/issue_ledger','/paper_gate_audit','/errorlog']}

_v845_next_queue_obj = _v846_next_queue_obj  # type: ignore[assignment]


def _v846_header(text: str) -> str:
    text = str(text)
    for a,b in [('/batch · v845','/batch · v846'),('/cleanup_status · v845','/cleanup_status · v846'),('/issue_ledger · v845','/issue_ledger · v846'),('/paper_gate_audit · v845','/paper_gate_audit · v846'),('묶음 요약집 v845','묶음 요약집 v846')]:
        text=text.replace(a,b)
    return text


def _v846_cleanup_status_text() -> str: return _v846_header(_v845_cleanup_status_text())
def _v846_batch_text(outputs: Optional[Dict[str,str]]=None, timings: Optional[List[Dict[str,Any]]]=None) -> str: return _v846_header(_v845_batch_text(outputs,timings))
def _v846_issue_ledger_text() -> str: return _v846_header(_v845_issue_ledger_text())
def _v846_paper_gate_audit_text() -> str: return _v846_header(_v845_paper_gate_audit_text())
def _v846_batch_summary_text(cmds: List[str], outputs: Dict[str,str], timings: List[Dict[str,Any]], recv_delay: float, total_sec: float, chat_body: str='') -> str: return _v846_header(_v845_batch_summary_text(cmds,outputs,timings,recv_delay,total_sec,chat_body=chat_body))

COMMANDS['batch'] = _v846_batch_text; COMMANDS['summary'] = _v846_batch_text; COMMANDS['pbatch'] = _v846_batch_text
COMMANDS['cleanup_status'] = _v846_cleanup_status_text; COMMANDS['ledger_cleanup'] = _v846_cleanup_status_text; COMMANDS['disk_cleanup'] = _v846_cleanup_status_text; COMMANDS['cleanup'] = _v846_cleanup_status_text
COMMANDS['issue_ledger'] = _v846_issue_ledger_text; COMMANDS['ledger'] = _v846_issue_ledger_text
COMMANDS['paper_gate_audit'] = _v846_paper_gate_audit_text; COMMANDS['paper_audit'] = _v846_paper_gate_audit_text; COMMANDS['hold_audit'] = _v846_paper_gate_audit_text


def batch_handler(update, context):  # type: ignore[override]
    try:
        msg_date=getattr(getattr(update,'message',None),'date',None)
        recv_delay=time.time()-msg_date.timestamp() if hasattr(msg_date,'timestamp') else 0.0
    except Exception:
        recv_delay=0.0
    cmds=_v820_select_batch_cmds(getattr(context,'args',None) or [])
    stime=time.time(); timings=[]; outputs={}; _v811_begin_batch_source_lock()
    try:
        _v845_live_ledger_refresh('batch_handler_start_v846', force=True)
        multi=len(cmds)>1
        if multi:
            try: send(update, f'📊 묶음 시작 · {len(cmds)}개 명령 / actual paper_latest cleanup txt(v846) · 지연 {recv_delay:.2f}s')
            except Exception: pass
        total_cmds=len(cmds)
        for idx,name in enumerate(cmds,start=1):
            fn=COMMANDS.get(name); t0=time.time(); err=None
            if not fn:
                body=f'❌ /{name} 연결 없음'; err='no_handler'
            else:
                try: body=fn()
                except Exception as exc:
                    body=f'❌ /{name} 오류 {exc.__class__.__name__}: {exc}'; err=f'{exc.__class__.__name__}: {exc}'; log_error(f'v846_batch_{name}', exc); _v844_append_event({'schema':'issue_ledger_event_v846','ts':now_ts(),'ts_text':_v844_kst_now_text(),'source':f'batch_error_{name}','issue_id':'ERROR-001','error':err})
            body=_v834_easy_text(body); sec=time.time()-t0; timings.append({'name':name,'sec':sec,'error':err}); outputs[name]=body
            try:
                if multi: send(update, _v817_command_short_block(idx,total_cmds,name,body,sec,err))
                else: send(update, body)
            except Exception as exc: log_error('v846_batch_send', exc)
        total=time.time()-stime; chat_body=outputs.get(cmds[0],'') if len(cmds)==1 else _v846_batch_text(outputs,timings)
        try: status=_v650_send_summary_file(update, _v846_batch_summary_text(cmds,outputs,timings,recv_delay,total,chat_body=chat_body))
        except Exception as exc:
            status=f'txt 생성실패 {exc.__class__.__name__}'; log_error('v846_batch_summary_file', exc); _v844_append_event({'schema':'issue_ledger_event_v846','ts':now_ts(),'ts_text':_v844_kst_now_text(),'source':'batch_summary_error','issue_id':'ERROR-001','error':str(exc)})
        mark='✅' if '전송완료' in status else '⚠️'; del_mark='✅' if '서버삭제' in status else ('❌' if '전송완료' in status else '❔')
        try: send(update, f'📎 txt {mark} / 삭제 {del_mark} / {total:.2f}s')
        except Exception: pass
    finally:
        _v811_end_batch_source_lock()

# =============================================================================
# main_bot v2.13.846: single runtime entrypoint
# =============================================================================
if __name__ == "__main__":
    main()
