v2121 restores the Main final launcher and the Guard standalone release-manifest reader only. Workers, Paper, trading logic, ledgers and Shadow are unchanged. Auto-buy OFF.
