#!/usr/bin/env python3
from __future__ import annotations

import importlib
import importlib.util
import json
import os
import shutil
import sys
import tempfile
import time
import unittest
from datetime import datetime, timedelta, timezone
from pathlib import Path

SOURCE = Path(__file__).resolve().parents[1] / "source"
if str(SOURCE) not in sys.path:
    sys.path.insert(0, str(SOURCE))

import canonical_spine_v1190 as spine


class V1190RuntimeTruthTests(unittest.TestCase):
    def test_kst_timestamp_is_not_shifted_by_server_timezone(self):
        actual = spine.parse_ts("2026-07-02 10:59:06 KST")
        expected = datetime(2026, 7, 2, 10, 59, 6, tzinfo=timezone(timedelta(hours=9))).timestamp()
        self.assertEqual(actual, expected)

    def test_error_scope_uses_current_pid_start_and_keeps_old_error_historical(self):
        with tempfile.TemporaryDirectory() as td:
            base = Path(td)
            runtime_start = datetime(2026, 7, 2, 11, 0, 0, tzinfo=timezone(timedelta(hours=9))).timestamp()
            (base / "paper_bot_status.json").write_text(json.dumps({"process_started_at": runtime_start}), encoding="utf-8")
            (base / "paper_bot_error.log").write_text(
                "[2026-07-02 10:59:06 KST] old: FileNotFoundError\n"
                "Traceback old\n"
                "[2026-07-02 11:01:00 KST] new: RuntimeError\n"
                "Traceback new\n",
                encoding="utf-8",
            )
            result = spine._error_scope_summary(base)
            self.assertEqual(result["current_count"], 1)
            self.assertEqual(result["historical_count"], 1)
            self.assertEqual(result["current_cause_count"], 1)

    def test_async_review_lag_is_collecting_not_fail(self):
        with tempfile.TemporaryDirectory() as td:
            base = Path(td)
            now = time.time()
            pipeline = {
                "cycle_id": "cycle-current",
                "candidate_commit_id": "commit-current",
                "committed_handoff_file_v1158": "strategy_paper_handoff_committed_v1158.json",
            }
            request = {
                "cycle_id": "cycle-current",
                "candidate_commit_id": "commit-current",
                "updated_ts": now - 2,
            }
            review = {
                "generated_ts": now - 30,
                "source": {"pipeline_cycle_id": "cycle-previous", "candidate_commit_id": "commit-previous"},
            }
            for name in (
                "strategy_candidate_pipeline_commit_v1150.json",
                "strategy_paper_handoff_committed_v1158.json",
                "review_observation_request_v1181.json",
                "canonical_review_snapshot_v1181.json",
                "canonical_candidate_standard_v1181.json",
                "paper_bot_status.json",
                "paper_bot_open.json",
                "paper_closed_append_status_v925.json",
                "canonical_performance_snapshot_v987.json",
            ):
                (base / name).write_text("{}", encoding="utf-8")
            (base / "strategy_paper_handoff_committed_v1158.json").write_text(
                json.dumps({"cycle_id": "cycle-current", "candidate_commit_id": "commit-current"}), encoding="utf-8"
            )
            result = spine._artifact_chain_summary(base, now, pipeline, request, review, {}, {"snapshot_id": "perf"})
            self.assertEqual(result["review_relation"], "ASYNC_REVIEW_LAG")
            self.assertEqual(result["state"], "COLLECTING")
            self.assertEqual(result["mismatched_ids"], [])

    def test_same_cycle_wrong_review_commit_is_fail(self):
        with tempfile.TemporaryDirectory() as td:
            base = Path(td)
            now = time.time()
            pipeline = {"cycle_id": "cycle-current", "candidate_commit_id": "commit-current"}
            request = {"cycle_id": "cycle-current", "candidate_commit_id": "commit-current", "updated_ts": now}
            review = {"generated_ts": now, "source": {"pipeline_cycle_id": "cycle-current", "candidate_commit_id": "wrong"}}
            for name in (
                "strategy_candidate_pipeline_commit_v1150.json", "strategy_paper_handoff_committed_v1158.json",
                "review_observation_request_v1181.json", "canonical_review_snapshot_v1181.json",
                "canonical_candidate_standard_v1181.json", "paper_bot_status.json", "paper_bot_open.json",
                "paper_closed_append_status_v925.json", "canonical_performance_snapshot_v987.json",
            ):
                (base / name).write_text("{}", encoding="utf-8")
            result = spine._artifact_chain_summary(base, now, pipeline, request, review, {}, {})
            self.assertEqual(result["state"], "FAIL")
            self.assertIn("review_snapshot", result["mismatched_ids"])

    def test_resource_summary_surfaces_60_percent_cpu_and_1gb_rss(self):
        result = spine._resource_summary(Path("/tmp"), {
            "server": {"disk_free_gb": 10.0, "disk_used_pct": 50.0, "mem_used_pct": 20.0},
            "components": {
                "paper": {"cpu_pct": 71.3, "rss_mb": 1862.5},
                "strategy": {"cpu_pct": 61.6, "rss_mb": 548.4},
            },
        })
        self.assertEqual(result["state"], "CHECK")
        self.assertEqual({x["component"] for x in result["slow_cpu"]}, {"paper", "strategy"})
        self.assertEqual(result["high_rss"][0]["component"], "paper")

    def test_phase_profile_pid_and_version_relation(self):
        with tempfile.TemporaryDirectory() as td:
            base = Path(td)
            runtime = {"components": [{"component": "scanner", "main_pid": 222, "status_version": "scanner_worker_v0.946"}]}
            p = base / "runtime" / "runtime_phase_profile_scanner_v1190.json"
            p.parent.mkdir(parents=True)
            p.write_text(json.dumps({
                "version": "scanner_worker_v0.946", "pid": 111, "updated_ts": time.time(),
                "scopes": {"cycle": {"state": "NORMAL", "total_sec": 1.2, "top_functions": []}},
            }), encoding="utf-8")
            result = spine._phase_profile_summary(base, time.time(), runtime)
            scanner = next(x for x in result["components"] if x["component"] == "scanner")
            self.assertEqual(scanner["state"], "CHECK")
            self.assertFalse(scanner["pid_match"])

    def test_profiler_writes_bounded_scope_evidence_and_handles_nested_calls(self):
        with tempfile.TemporaryDirectory() as td:
            old = os.environ.get("TRADING_BOT_DIR")
            os.environ["TRADING_BOT_DIR"] = td
            try:
                import runtime_phase_probe_v1190 as probe
                probe = importlib.reload(probe)
                ns = {}

                def inner():
                    total = 0
                    for i in range(20000):
                        total += i * i
                    return total

                ns["inner"] = inner

                def outer():
                    return ns["inner"]()

                ns["outer"] = outer
                self.assertTrue(probe.wrap_function(ns, "inner", "unit", "inner", "unit_v1", 300.0, 10.0))
                self.assertTrue(probe.wrap_function(ns, "outer", "unit", "outer", "unit_v1", 300.0, 10.0))
                self.assertGreater(ns["outer"](), 0)
                path = Path(td) / "runtime" / "runtime_phase_profile_unit_v1190.json"
                obj = json.loads(path.read_text(encoding="utf-8"))
                self.assertEqual(obj["schema"], "coinbot_runtime_phase_profile_v1190")
                self.assertEqual(obj["pid"], os.getpid())
                self.assertIn("outer", obj["scopes"])
                self.assertIn("inner", obj["scopes"])
                self.assertGreater(obj["scopes"]["outer"]["last_sec"], 0)
                self.assertGreaterEqual(obj["scopes"]["outer"]["window_count"], 1)
            finally:
                if old is None:
                    os.environ.pop("TRADING_BOT_DIR", None)
                else:
                    os.environ["TRADING_BOT_DIR"] = old

    def test_main_giveback_top_uses_giveback_not_current_pnl(self):
        import bot
        lines = bot._open_book_lines({
            "open_count": 1,
            "valid_pnl_rows": 1,
            "current_total": -6.63,
            "current_avg": -6.63,
            "losses": 1,
            "giveback_top_rows": [{"ticker": "OPG", "pnl_pct": -6.63, "giveback_pct": 9.50}],
        })
        text = "\n".join(lines)
        self.assertIn("OPG +9.50%p", text)
        self.assertIn("수익 반납 TOP3 · 합 +9.50%p", text)

    def test_pycache_cleanup_prunes_bundle_temp_tree(self):
        spec = importlib.util.spec_from_file_location("paper_bot_v1190_test", SOURCE / "paper_bot.py")
        self.assertIsNotNone(spec)
        module = importlib.util.module_from_spec(spec)
        assert spec and spec.loader
        spec.loader.exec_module(module)
        with tempfile.TemporaryDirectory() as td:
            base = Path(td)
            transient_cache = base / ".bundle_unpack_123" / "__pycache__"
            transient_cache.mkdir(parents=True)
            (transient_cache / "x.pyc").write_bytes(b"x")
            stable_cache = base / "stable" / "__pycache__"
            stable_cache.mkdir(parents=True)
            (stable_cache / "y.pyc").write_bytes(b"y")
            old = time.time() - 2 * 24 * 3600
            for path in (stable_cache / "y.pyc", stable_cache):
                os.utime(path, (old, old))
            module.BASE_DIR = base
            result = {"errors": 0, "preserved": 0, "deleted_files": 0, "error_sample": []}
            module._v783_remove_pycache(result)
            self.assertEqual(result["errors"], 0)
            self.assertTrue(transient_cache.exists(), "Guard-owned bundle tree must be pruned from Paper traversal")
            self.assertFalse(stable_cache.exists(), "Old stable pycache should still be cleaned")


if __name__ == "__main__":
    unittest.main(verbosity=2)
