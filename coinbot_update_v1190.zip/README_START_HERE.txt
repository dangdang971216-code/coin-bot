coinbot v1190 update bundle

목적
- 모든 worker/Main/Guard/Paper가 자기 내부에서 무엇을 하는지 함수별 시간을 기록
- 지도에서 현재 PID·버전·cycle·오류·자원·원장 증거를 함께 표시
- v1189에서 확인된 KST 오류분류, Review 비동기 오판, 0초 정상표시, 고CPU 숨김, giveback 필드, Paper pycache 배포폴더 race를 수리

중요
- 이 버전은 진단·가시성 및 확인된 runtime 오류수리다.
- Paper 82초의 실제 느린 함수는 서버 v1190 profile 표본으로 확정한 뒤 다음 버전에서 수리한다.
- 신규 차단 없음, 자동매수 OFF, 라이브 원장 미포함.
