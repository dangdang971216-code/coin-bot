# v1149 Work Lock

- Symptom: `paper_s1_hold_cache.json` continued to refresh while `paper_candidates_latest.jsonl` and `clean_strategy_priority_requests.json` stopped for about 48 minutes.
- Proven cause: v1148 measurement line evaluated `int(summary['rows'])`. `summary['rows']` is a non-empty list, so every cycle with S1 rows raised `TypeError` immediately after S1 cache commit.
- Impact: canonical candidate and priority commits after S1 were skipped; Paper received stale trigger occurrences and fresh candidate display/queues stopped.
- Owner: Strategy `_v510_publish` measurement block directly after `write_s1_hold_cache`.
- Change: use explicit numeric `count`; if absent, use `len(rows)`; never coerce the row list.
- Not changed: Gate, rank, trigger, invalid, target, RR, TTL, trailing, exits, OPEN/cycle limits, candidate keys, Paper, Risk, Main, Guard.
- Auto-buy: OFF.
