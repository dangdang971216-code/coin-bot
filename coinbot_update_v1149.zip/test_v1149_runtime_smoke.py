#!/usr/bin/env python3
from __future__ import annotations
import importlib.util
import json
import os
import tempfile
from pathlib import Path

SRC=Path(__file__).resolve().parent/'strategy_worker_v1.017.py'

def main():
    with tempfile.TemporaryDirectory() as td:
        os.environ['TRADING_BOT_DIR']=td
        spec=importlib.util.spec_from_file_location('strategy_v1149_smoke',str(SRC))
        mod=importlib.util.module_from_spec(spec); assert spec and spec.loader; spec.loader.exec_module(mod)
        cases=[
            ({'count':3,'rows':[{}, {}, {}]},3),
            ({'rows':[{},{}]},2),
            ({'count':0,'rows':[{}]},0),
            ({'count':'3','rows':[{}]},1),
            ({},0),
            (None,0),
        ]
        got=[]
        for payload,expected in cases:
            value=mod._v1149_s1_hold_count(payload)
            assert value==expected,(payload,value,expected)
            got.append(value)
        profile={'phases':{
            's1_hold_commit_v1148':{'wall_sec':0.7,'cpu_sec':0.6},
            'key_spine_status_v1148':{'wall_sec':0.1,'cpu_sec':0.1},
            'row_aggregation_and_promotion_stats':{'wall_sec':0.2,'cpu_sec':0.2},
            'candidate_writer_full_row_audit':{'wall_sec':0.1,'cpu_sec':0.1},
            'candidate_writer_compact_single_pass':{'wall_sec':2.0,'cpu_sec':1.9},
        }}
        grouped=mod._v1113_phase_group_totals(profile)
        writer=next(x for x in grouped['groups'] if x['group']=='candidate_writer')
        assert writer['wall_sec']==2.1,writer
        print(json.dumps({
            'result':'PASS','version':mod.VERSION,'count_cases':got,
            'candidate_writer_group_visible':writer,
            'post_s1_path_expected':'key_spine -> row aggregation -> candidate commit -> priority commit',
        },ensure_ascii=False,indent=2))

if __name__=='__main__': main()
