#!/usr/bin/env python3
from __future__ import annotations
import ast
import importlib.util
import json
import os
import tempfile
from pathlib import Path

HERE=Path(__file__).resolve().parent
NEW=HERE/'strategy_worker_v1.017.py'
OLD=Path('/mnt/data/v1148_inspect/strategy_worker_v1.016.py')


def load_module(path: Path, name: str, base: Path):
    old_env=os.environ.get('TRADING_BOT_DIR')
    os.environ['TRADING_BOT_DIR']=str(base)
    try:
        spec=importlib.util.spec_from_file_location(name,str(path))
        mod=importlib.util.module_from_spec(spec)
        assert spec and spec.loader
        spec.loader.exec_module(mod)
        return mod
    finally:
        if old_env is None: os.environ.pop('TRADING_BOT_DIR',None)
        else: os.environ['TRADING_BOT_DIR']=old_env


def tree(path: Path):
    return ast.parse(path.read_text(encoding='utf-8'))


def last_function(path: Path, name: str):
    matches=[n for n in tree(path).body if isinstance(n,(ast.FunctionDef,ast.AsyncFunctionDef)) and n.name==name]
    assert matches, name
    return matches[-1]


def function_dump(path: Path, name: str):
    return ast.dump(last_function(path,name),include_attributes=False)


def call_names(path: Path, function_name: str, selected: set[str]):
    fn=last_function(path,function_name)
    out=[]
    for node in ast.walk(fn):
        if not isinstance(node,ast.Call):
            continue
        name=None
        if isinstance(node.func,ast.Name): name=node.func.id
        elif isinstance(node.func,ast.Attribute): name=node.func.attr
        if name in selected:
            out.append((getattr(node,'lineno',0),name))
    return [name for _,name in sorted(out)]


def main():
    with tempfile.TemporaryDirectory() as td:
        base=Path(td)
        old=load_module(OLD,'strategy_v1148_baseline',base/'old')
        new=load_module(NEW,'strategy_v1149_test',base/'new')
        assert new.VERSION=='strategy_worker_v1.017'
        assert new.BUILD_LABEL=='v1149_strategy_post_s1_commit_count_type_fix_2026-06-30'

        # Reproduce the exact v1148 failure and prove the new count owner.
        summary={'count':4,'rows':[{'ticker':'A'},{'ticker':'B'},{'ticker':'C'},{'ticker':'D'}]}
        try:
            int(summary.get('rows') or summary.get('count') or 0)
        except TypeError:
            old_failure_reproduced=True
        else:
            old_failure_reproduced=False
        assert old_failure_reproduced
        assert new._v1149_s1_hold_count(summary)==4
        assert new._v1149_s1_hold_count({'rows':[{},{}]})==2
        assert new._v1149_s1_hold_count({'count':0,'rows':[{}]})==0
        assert new._v1149_s1_hold_count(None)==0

        # Trading formulas and sealed contracts are untouched.
        critical_functions=(
            'apply_swing_entry_gate','_v925_current_actual_plan','_swing_quality_gate',
            '_v554_apply_entry_plan_state__v1115','seal_canonical_candidate_keys',
            'attach_smart_structure_shadow','attach_structure_lab','attach_hot_watch_timing',
            'observe_good_s2_lifecycle','write_s1_hold_cache','write_strategy_key_spine_status',
            '_v1021_publish_candidate_snapshot',
        )
        for name in critical_functions:
            assert function_dump(OLD,name)==function_dump(NEW,name),name
        critical_constants=(
            'V925_MIN_RR','V925_MIN_TARGET_ROOM_PCT','V925_UNTRADABLE_SPREAD_PCT',
            'V977_MAX_TRIGGER_OVERSHOOT_PCT','STRUCTURE_LAB_RECOMPUTE_BUDGET',
            'STRUCTURE_LAB_LIVE_METHOD_BUDGET','STRUCTURE_EVENT_DELIVERY_TTL_SEC',
        )
        for name in critical_constants:
            assert getattr(old,name)==getattr(new,name),(name,getattr(old,name),getattr(new,name))

        selected={
            'attach_smart_structure_shadow','attach_structure_lab','attach_hot_watch_timing',
            'observe_good_s2_lifecycle','write_s1_hold_cache','write_strategy_key_spine_status',
            '_v1021_publish_candidate_snapshot',
        }
        old_names=call_names(OLD,'_v510_publish',selected)
        new_names=call_names(NEW,'_v510_publish',selected)
        assert old_names==new_names,(old_names,new_names)
        assert new_names==[
            'attach_smart_structure_shadow','attach_structure_lab','attach_hot_watch_timing',
            'observe_good_s2_lifecycle','write_s1_hold_cache','write_strategy_key_spine_status',
            '_v1021_publish_candidate_snapshot',
        ]

        src=NEW.read_text(encoding='utf-8')
        assert "int((v732_s1_hold_summary or {}).get('rows')" not in src
        assert "_v1149_s1_hold_count(v732_s1_hold_summary)" in src
        assert "post_s1_candidate_commit_path_restored_v1149" in src

        print(json.dumps({
            'result':'PASS','version':new.VERSION,'build':new.BUILD_LABEL,
            'v1148_typeerror_reproduced':old_failure_reproduced,
            'nonempty_s1_count_result':new._v1149_s1_hold_count(summary),
            'exact_publish_call_order_unchanged':new_names,
            'critical_trade_functions_unchanged':list(critical_functions),
            'critical_constants_unchanged':list(critical_constants),
            'auto_buy':False,
        },ensure_ascii=False,indent=2))

if __name__=='__main__': main()
