# v1126 scope and verification

## 실제 원인

1. 진행 중 active row가 누적 비교 객체에 들어간 뒤, 없는 60분 MFE를 `0.0`으로 보정해 false-pass로 집계했다.
2. MFE·MAE·spread·slippage가 없을 때도 0으로 평균과 비용 후 성과에 넣었다.
3. 실제 표본 owner는 `trigger_occurrence_v1037.decision_key`였지만 status/Main 문구는 candidate occurrence key를 본선처럼 표시했다.
4. Guard의 최근 60분 증가율에는 v1125 적용 전 구간이 섞일 수 있어 구 v946 writer가 현재도 살아 있는지 구분할 수 없었다.

## 수정 owner

- Review: horizon 판정, missing 분모, identity owner, 신규 사건 분류
- Main: `/quality_shadow` exact renderer
- Guard: v946/v1125 writer truth

## 삭제한 구 경로

- 표본 identity의 swing-gate/candidate/entry-build fallback 사용
- 60분 미완료 row를 final false-pass에 넣는 경로
- missing MFE·MAE·cost를 0으로 보정하는 집계 경로
- rolling 60분 증가율만으로 현재 writer를 추정하는 단일 표시

과거 파일과 원장은 삭제하지 않았다.

## 변경하지 않은 영역

- Strategy 품질 Gate·rank
- improved shadow 공식
- trigger·invalid·target
- 실제 진입 RR·room·chase·spread·slippage·비용 계약
- OPEN 30 / cycle 신규 3
- Paper 진입·청산·commit
- 자동매수 OFF

## 로컬 검수

- 세 수정 파일 py_compile PASS
- 10분 미완료 false-pass 0
- 10분 완료 provisional false-pass만 증가
- 60분 완료 후 final false-pass 증가
- missing cost/MFE/MAE 평균 None, 별도 missing count
- 같은 owner에서 candidate/direct key 변경 시 신규 0, churn blocked 1
- reset/rebreak owner key는 신규 1
- owner key 누락은 신규 0, MISSING_OWNER_KEY 1
- `/quality_shadow`에 owner field/value, 네 분류, 10m/60m 판정, writer truth 표시
- Guard collector는 inode·mtime·rolling 60m·Review process start 이후 증가·current write-FD PID를 분리
- Review live quality formula 5개 AST hash v1125와 동일
- Strategy/Paper 파일 hash v1125 baseline과 동일하며 bundle 미포함

## 서버 상태

로컬 PASS / 서버 적용·runtime 증명 전 CHECK.
