#!/usr/bin/env python3
from __future__ import annotations
import importlib.util, os, pathlib, tempfile, time
ROOT=pathlib.Path(__file__).resolve().parent
base=tempfile.mkdtemp(prefix='coinbot_review_identity_v1126_')
os.environ['TRADING_BOT_DIR']=base
spec=importlib.util.spec_from_file_location('review_identity_v1126',ROOT/'review_worker_v1.004.py')
mod=importlib.util.module_from_spec(spec); spec.loader.exec_module(mod)
now=time.time(); fmap={'ABC':{'current_price':100.0}}
def row(decision='plan1',kind='INITIAL_ABOVE',sequence=0,entry='e1',direct='d1'):
    return {'ticker':'ABC','entry_build_key':entry,'direct_decision_key':direct,'trigger_occurrence_candidate_key_v1037':'cand-'+entry,'trigger_occurrence_v1037':{'decision_key':decision,'base_plan_decision_key':'plan1','kind':kind,'sequence':sequence},'current_price':100.0}
s1,rows=mod.update_quality_shadow(now,fmap,{},[row()],{})
assert s1['new_records_this_cycle']==1 and s1['identity_event_counts_v1126']['NEW_PLAN']==1
assert s1['identity_owner_field_v1126']=='trigger_occurrence_v1037.decision_key'
assert s1['identity_owner_values_sample_v1126']==['plan1']
s2,rows=mod.update_quality_shadow(now+1,fmap,{},[row(entry='e2',direct='d2')],{})
assert s2['new_records_this_cycle']==0
assert s2['identity_event_counts_v1126']['SAME_PLAN_KEY_CHURN_BLOCKED']==1
s3,rows=mod.update_quality_shadow(now+2,fmap,{},[row(decision='plan1|rebreak:1',kind='REBREAK',sequence=1,entry='e3')],{})
assert s3['new_records_this_cycle']==1 and s3['identity_event_counts_v1126']['NEW_RESET_REBREAK']==1
s4,rows=mod.update_quality_shadow(now+3,fmap,{},[{'ticker':'ABC','entry_build_key':'e4','current_price':100.0}],{})
assert s4['new_records_this_cycle']==0 and s4['identity_event_counts_v1126']['MISSING_OWNER_KEY']==1
assert len(rows)==2
assert sorted(r.get('identity_event_class_v1126') for r in rows)==['NEW_PLAN','NEW_RESET_REBREAK']
assert not list(pathlib.Path(base).glob('*v946*'))
print('PASS review identity: NEW_PLAN / NEW_RESET_REBREAK / SAME_PLAN_KEY_CHURN_BLOCKED / MISSING_OWNER_KEY')
