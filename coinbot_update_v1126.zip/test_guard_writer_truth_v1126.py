#!/usr/bin/env python3
from __future__ import annotations
import ast, pathlib
ROOT=pathlib.Path(__file__).resolve().parent
path=ROOT/'backga_guard_bot_v2_5_172.py'
text=path.read_text(encoding='utf-8')
ast.parse(text)
for required in (
 'guard_v2.5.172_quality_writer_since_start_truth_v1126_2026-06-29',
 'quality_shadow_result_ledger_v946.jsonl','clean_quality_shadow_state_v946.json',
 'quality_shadow_result_ledger_v1125.jsonl','clean_quality_shadow_state_v1125.json',
 'quality_shadow_writer_truth_v1126','rolling_60m_scope','MAY_INCLUDE_PRE_DEPLOY_HISTORY',
 'since_owner_start_growth_bytes','current_write_fd_pids','inode','mtime_ts','LEGACY_WRITE_STILL_ACTIVE',
):
    assert required in text, required
collect=next(n for n in ast.walk(ast.parse(text)) if isinstance(n,ast.FunctionDef) and n.name=='collect_ops_map_snapshot')
collect_text=ast.get_source_segment(text,collect) or ''
assert 'unlink(' not in collect_text and '.truncate(' not in collect_text
print('PASS guard writer truth: legacy/current files, inode/mtime, post-owner-start growth, current write-FD PID; read-only')
