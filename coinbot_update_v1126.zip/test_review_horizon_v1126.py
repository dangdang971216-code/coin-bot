#!/usr/bin/env python3
from __future__ import annotations
import copy, importlib.util, os, pathlib, tempfile
ROOT=pathlib.Path(__file__).resolve().parent
base=tempfile.mkdtemp(prefix='coinbot_review_horizon_v1126_')
os.environ['TRADING_BOT_DIR']=base
spec=importlib.util.spec_from_file_location('review_horizon_v1126',ROOT/'review_worker_v1.004.py')
mod=importlib.util.module_from_spec(spec); spec.loader.exec_module(mod)
epoch={'epoch_id':'E','epoch_start_ts':1.0,'epoch_start_text':'test'}
variants={k:{'selected':True,'block_reasons':[]} for k in ('safety_only','current_quality','improved_quality')}
base_row={'quality_eye_epoch_id_v1124':'E','identity_mode_v946':'trigger_occurrence_v1037.decision_key','ticker':'AAA','quality_event_key_v946':'trigger_decision:plan','policy_variants_v1120':variants,'initial_metrics':{'spread_pct':0.1,'confirmed_slippage_pct':0.2},'samples':{}}
agg=mod._quality_eye_empty_aggregate_v1124(epoch)
status=mod._quality_eye_status_from_aggregate_v1124(100.0,agg,[base_row],epoch)
assert status['false_pass_10m_provisional']['no_positive_mfe']==0
assert status['false_pass_60m_final']['no_positive_mfe']==0
assert status['minimum_ready_n']==0 and status['leader_60m'] is None
r10=copy.deepcopy(base_row); r10['samples']['10m']={'pct':-1.0,'max_pct':0.0,'min_pct':-1.0,'giveback_pct':0.0}
status=mod._quality_eye_status_from_aggregate_v1124(100.0,agg,[r10],epoch)
assert status['false_pass_10m_provisional']['no_positive_mfe']==1
assert status['false_pass_60m_final']['no_positive_mfe']==0
assert status['horizons']['60m']['current_quality']['n']==0
r60=copy.deepcopy(r10); r60['samples']['60m']={'pct':-2.0,'max_pct':0.0,'min_pct':-3.0,'giveback_pct':0.0}
status=mod._quality_eye_status_from_aggregate_v1124(100.0,agg,[r60],epoch)
assert status['false_pass_60m_final']['no_positive_mfe']==1
assert status['horizons']['60m']['current_quality']['comparison_ready_n']==1
assert status['horizons']['60m']['current_quality']['cost_adjusted_avg_pct']==-2.3
missing=copy.deepcopy(base_row); missing['initial_metrics']={'spread_pct':0.1}; missing['samples']['60m']={'pct':-2.0}
status=mod._quality_eye_status_from_aggregate_v1124(100.0,agg,[missing],epoch)
row=status['horizons']['60m']['current_quality']
assert row['n']==1 and row['adjusted_n']==0 and row['comparison_ready_n']==0
assert row['cost_adjusted_avg_pct'] is None and row['avg_mfe_pct'] is None and row['avg_mae_pct'] is None
assert row['cost_missing']==1 and row['mfe_missing']==1 and row['mae_missing']==1
print('PASS review horizon: pre-10m false-pass 0; 10m provisional only; 60m final only; missing never zero-filled')
