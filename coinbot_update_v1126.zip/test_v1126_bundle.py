#!/usr/bin/env python3
from __future__ import annotations
import ast, hashlib, json, pathlib, py_compile, subprocess, sys
ROOT=pathlib.Path(__file__).resolve().parent
FILES={'main':ROOT/'coinbot_main_v2_13_1098.py','review':ROOT/'review_worker_v1.004.py','guard':ROOT/'backga_guard_bot_v2_5_172.py'}
EXPECTED_AST={
 '_quality_gate':'eabbf7d72e8b00afc287bb0830e65a9983917d9912c069716f3dd1d4d4d42e7e',
 '_quality_block_reasons':'31186b4094cb219f215a7191f90ede51bd5045858c705641e4c5a673acfd7e24',
 '_quality_cohort':'806735a9c7829d727c4b7832c64efd53db8da9dc5f79e3d811f27cd453750a68',
 '_quality_initial_metrics':'b8204256973797b2582c418564228755ffb4d91836197b508dfab68eb14d0758',
 '_quality_policy_variants_v1120':'b224d0bb7e65894cf7529e050348d79a32c0f95a3eee3489c81bf3fa7989d70f',
}
def ast_hashes(path):
    tree=ast.parse(path.read_text(encoding='utf-8'))
    return {n.name:hashlib.sha256(ast.dump(n,include_attributes=False).encode()).hexdigest() for n in ast.walk(tree) if isinstance(n,(ast.FunctionDef,ast.AsyncFunctionDef))}
def main():
    result={'ok':True,'compile':{},'versions':{},'contracts':{},'tests':{}}
    for key,path in FILES.items():
        py_compile.compile(str(path),doraise=True); result['compile'][key]='PASS'
    manifest=json.loads((ROOT/'DEPLOY_BUNDLE.json').read_text(encoding='utf-8'))
    assert manifest['version']=='v1126' and manifest['main']==FILES['main'].name and manifest['guard']==FILES['guard'].name and manifest['workers']['review']==FILES['review'].name
    assert manifest['strategy_mode']=='ALT_SWING' and manifest['auto_buy'] is False
    for flag in ('strategy_contract_change','quality_threshold_change','quality_formula_change','rank_formula_change','open_limit_change','cycle_limit_change','exit_contract_change'):
        assert manifest[flag] is False, flag
    got=ast_hashes(FILES['review'])
    for name,digest in EXPECTED_AST.items(): assert got.get(name)==digest,(name,got.get(name),digest)
    assert not list(ROOT.glob('strategy_worker*.py')) and not list(ROOT.glob('paper_bot*.py'))
    forbidden=('paper_bot_open.json','paper_bot_closed.jsonl','trade_log.json','decision_ledger.jsonl','change_verify_ledger.jsonl','issue_ledger.jsonl')
    all_names=[p.name for p in ROOT.rglob('*') if p.is_file()]
    assert not any(name in all_names for name in forbidden)
    for test_name in ('test_review_horizon_v1126.py','test_review_identity_v1126.py','test_main_command_v1126.py','test_guard_writer_truth_v1126.py'):
        run=subprocess.run([sys.executable,str(ROOT/test_name)],capture_output=True,text=True,check=True)
        result['tests'][test_name]=run.stdout.strip()
    result['versions']={'main':'v2.13.1098','review':'v1.004','guard':'v2.5.172','strategy':'v1.009 unchanged','paper':'v1.020 unchanged'}
    result['contracts']={'horizon_gate':'PASS','missing_not_zero':'PASS','identity_owner':'PASS','event_classification':'PASS','writer_truth':'PASS','live_quality_formula':'UNCHANGED','open_limit':'30_UNCHANGED','cycle_limit':'3_UNCHANGED','exit_contract':'UNCHANGED','auto_buy':'OFF'}
    print(json.dumps(result,ensure_ascii=False,sort_keys=True)); return 0
if __name__=='__main__': raise SystemExit(main())
