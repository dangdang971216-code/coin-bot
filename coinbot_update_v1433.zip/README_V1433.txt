v1433 GUARD_COMMAND_FIRST_ACK_FAST_POLL

목적
- 가드봇 명령 접수 지연 수리.
- 업그레이드 자체가 아니라 Telegram polling 전에 돌던 주기 작업이 접수를 막는 문제 차단.

수정
- Telegram getUpdates를 루프 맨 앞으로 이동.
- 다중명령/일반명령에 즉시 접수 ACK 전송.
- runtime/ops_map/core shadow/release delivery 주기작업은 poll idle 때만 실행.
- /gquick 빠른 상태 명령 추가.

변경하지 않음
- 후보 흐름, S1/S2/S3, Paper 진입, OPEN limit, 실제 청산계약, 자동매수 OFF.
