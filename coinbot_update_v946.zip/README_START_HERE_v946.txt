코인봇 v946 시작 안내

마지막 실서버 성공: v945
최신 적용대기: v946 QUALITY exact shadow

먼저 읽기
1. 코인봇_프로젝트공통지침_v946_FINAL_20260619.txt
2. 코인봇_인수인계_v946_FINAL_20260619.txt
3. APPLY_AFTER_v946.txt

자동매수 OFF. 매매기준 변경 없음.
