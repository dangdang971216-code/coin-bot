코인봇 v2217 — 업그레이드·메인 시작 지연과 v2215 재배치판 NameError 근본수리

현재 상태
- 자동매수 OFF
- Review/Strategy/Core/Paper 미변경·미재시작
- 현재 Review 전체스캔·exact·기존 v2213 Shadow 그대로 보존
- 상승예측 식/가중치/후보/진입/청산 변경 없음

확인된 원인
1. v2215 재배치 출력이 존재하지 않는 _v2196_review_snapshot을 호출해 NameError
2. Main이 Telegram polling 전에 setMyCommands 네트워크 호출을 동기로 실행해 시작 알림·명령수신이 지연될 수 있음
3. Guard가 최근 업로드 ZIP이 있어도 GitHub 확인을 먼저 수행
4. Review fresh-boot 검수 상한이 100초로 남음
5. 최종 적용 PASS가 Main polling 준비까지 증명하지 않음

수정
- 기존 canonical _v2208_review_owner/cache로 직접 연결
- Main polling 먼저 시작하고 polling-ready 봉인 후 시작 알림, 메뉴등록은 백그라운드
- 최근 30분 내 로컬 ZIP 우선, 없을 때만 기존 GitHub 흐름
- Review PID/version/lock exact 검수는 유지하고 대기 상한 24초
- Guard 최종 PASS는 Main PID/version/build/polling-ready까지 확인

서버 완료조건
- /gupgrade_bundle 최종결과에 Main polling-ready PASS
- Main 시작 알림이 최종 완료 전후 즉시 도착
- /trade_review의 v2215 재배치판에 NameError 없음
- Review/Strategy PID 유지, 현재 scan/Shadow 초기화 없음
- 자동매수 OFF
