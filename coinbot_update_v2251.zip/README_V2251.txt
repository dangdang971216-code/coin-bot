v2251 re-applies the complete v2249 error-first bundle and fixes Review ownership from the selected manifest, not from a fixed version or stale marker.
- Read workers.review from the current DEPLOY_BUNDLE.json on every apply.
- Verify exact manifest target, active alias hash and internal VERSION before atomically repairing the deployed marker.
- Restart Review when the manifest requests it even if a failed prior run already copied the same alias hash.
- Prove systemd ExecStart, MainPID cmdline, alias, target, VERSION, status PID and lock PID as one owner.
- The same code passed simulated v2.107 then v2.108 target changes without modification.
- Preserve v2249 Main/Paper OPEN truth, loss-defense, Review max-500 and Guard single-delivery/timing changes.
- No live ledgers, env files or tokens. Auto-buy OFF.
