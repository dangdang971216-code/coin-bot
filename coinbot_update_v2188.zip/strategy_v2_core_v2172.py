from __future__ import annotations

import hashlib
import json
import math
import statistics
import time
from typing import Any, Dict, Iterable, List, Optional, Tuple

VERSION = "strategy_v2_core_v2171"
BUILD_LABEL = "v2171_snapshot_receipt_rollback_history_2026-07-23"
GENERATION = "ALT_SWING_V2_COMBINED_V2149_RESET_20260722"
PREDICTION_MODEL_GENERATION = "FULL_INPUT_V2171"

REQUIRED_ROWS = {"m5": 48, "m15": 32, "m30": 48, "h1": 48, "h2": 32, "h4": 20}
TF_WEIGHT = {"m5": 1.0, "m15": 1.5, "m30": 2.1, "h1": 2.9, "h2": 4.0, "h4": 5.0}

QUALITY_STRUCTURE_MIN_V2170 = -999.0
QUALITY_STRUCTURE_SOURCE_V2170 = "V2170_FAILED_GATE_ROLLED_BACK_V2171"


def _num(value: Any, default: Optional[float] = None) -> Optional[float]:
    try:
        if value is None or isinstance(value, bool):
            return default
        out = float(value)
        return out if math.isfinite(out) else default
    except Exception:
        return default


def _clip(value: float, low: float, high: float) -> float:
    return max(low, min(high, float(value)))


def _sigmoid(value: float) -> float:
    return 1.0 / (1.0 + math.exp(-_clip(value, -12.0, 12.0)))


def _logit(prob: float) -> float:
    p = _clip(prob, 1e-6, 1.0 - 1e-6)
    return math.log(p / (1.0 - p))


def _median(values: Iterable[float], default: float = 0.0) -> float:
    vals = [float(x) for x in values if _num(x) is not None]
    return float(statistics.median(vals)) if vals else float(default)


def _ema(values: List[float], period: int) -> Optional[float]:
    clean = [float(x) for x in values if _num(x) is not None]
    if len(clean) < max(2, period):
        return None
    alpha = 2.0 / (float(period) + 1.0)
    value = sum(clean[:period]) / float(period)
    for item in clean[period:]:
        value = alpha * item + (1.0 - alpha) * value
    return value


def _atr(rows: List[Dict[str, float]], period: int = 14) -> float:
    if len(rows) < 2:
        return 0.0
    trs: List[float] = []
    prev: Optional[float] = None
    for row in rows[-max(period * 4, 48):]:
        high = float(row.get("h") or 0.0)
        low = float(row.get("l") or 0.0)
        close = float(row.get("c") or 0.0)
        if min(high, low, close) <= 0:
            continue
        tr = high - low if prev is None else max(high - low, abs(high - prev), abs(low - prev))
        trs.append(max(0.0, tr))
        prev = close
    if not trs:
        return 0.0
    seed = min(period, len(trs))
    value = sum(trs[:seed]) / seed
    for tr in trs[seed:]:
        value = ((period - 1.0) * value + tr) / period
    return max(0.0, value)


def _pivots(rows: List[Dict[str, float]], side: str, window: int) -> List[Dict[str, Any]]:
    out: List[Dict[str, Any]] = []
    if len(rows) < window * 2 + 3:
        return out
    for idx in range(window, len(rows) - window):
        row = rows[idx]
        value = float(row["l"] if side == "low" else row["h"])
        peers = [float(rows[j]["l"] if side == "low" else rows[j]["h"]) for j in range(idx - window, idx + window + 1) if j != idx]
        confirmed = value < min(peers) if side == "low" else value > max(peers)
        if confirmed:
            out.append({"price": value, "ts": float(row["ts"]), "index": idx, "side": side})
    return out


def _cluster_levels(levels: List[Dict[str, Any]], *, atr_ref: float, current: float) -> List[Dict[str, Any]]:
    clean = [dict(x) for x in levels if (_num(x.get("price"), 0.0) or 0.0) > 0]
    clean.sort(key=lambda x: float(x["price"]))
    groups: List[List[Dict[str, Any]]] = []
    tolerance = max(atr_ref * 0.22, current * 0.0012)
    for item in clean:
        price = float(item["price"])
        if groups:
            center = sum(float(x["price"]) * float(x.get("weight") or 1.0) for x in groups[-1]) / max(1e-12, sum(float(x.get("weight") or 1.0) for x in groups[-1]))
            if abs(price - center) <= tolerance:
                groups[-1].append(item)
                continue
        groups.append([item])
    out: List[Dict[str, Any]] = []
    for group in groups:
        weight_sum = sum(float(x.get("weight") or 1.0) for x in group)
        center = sum(float(x["price"]) * float(x.get("weight") or 1.0) for x in group) / max(weight_sum, 1e-12)
        out.append({
            "price": center,
            "low": min(float(x["price"]) for x in group) - tolerance * 0.35,
            "high": max(float(x["price"]) for x in group) + tolerance * 0.35,
            "score": weight_sum + min(3.0, len({str(x.get("tf")) for x in group})) * 0.5,
            "source_count": len(group),
            "timeframes": sorted({str(x.get("tf")) for x in group}),
            "last_source_ts": max(float(x.get("ts") or 0.0) for x in group),
        })
    return out


def _level_candidates(frames: Dict[str, List[Dict[str, float]]], tfs: Tuple[str, ...], side: str) -> List[Dict[str, Any]]:
    levels: List[Dict[str, Any]] = []
    for tf in tfs:
        rows = frames.get(tf) or []
        window = 2 if tf in {"m5", "m15"} else 3
        for item in _pivots(rows[-120:], "low" if side == "support" else "high", window):
            item["tf"] = tf
            item["weight"] = TF_WEIGHT.get(tf, 1.0)
            levels.append(item)
    return levels


def _trend_axis(rows: List[Dict[str, float]]) -> Optional[float]:
    closes = [float(r["c"]) for r in rows if float(r.get("c") or 0.0) > 0]
    if len(closes) < 24:
        return None
    fast = _ema(closes, 8)
    slow = _ema(closes, 21)
    prior_fast = _ema(closes[:-3], 8) if len(closes) >= 27 else None
    if fast is None or slow is None or prior_fast is None or slow <= 0:
        return None
    spread = (fast - slow) / slow * 100.0
    slope = (fast - prior_fast) / max(abs(prior_fast), 1e-12) * 100.0
    return _clip(spread * 2.8 + slope * 5.0, -1.0, 1.0)


def _row_price(row: Dict[str, Any]) -> Optional[float]:
    for obj in (row, row.get("raw") if isinstance(row.get("raw"), dict) else {}, row.get("entry_context") if isinstance(row.get("entry_context"), dict) else {}):
        if not isinstance(obj, dict):
            continue
        for key in ("current_price", "trade_price", "price", "last_price", "close", "entry_price"):
            value = _num(obj.get(key))
            if value is not None and value > 0:
                return value
    return None


def _nested(row: Dict[str, Any], *keys: str) -> Dict[str, Any]:
    for key in keys:
        value = row.get(key)
        if isinstance(value, dict):
            return value
    return {}


def _weighted_group(axes: Dict[str, Optional[float]], specs: Tuple[Tuple[str, float], ...]) -> Dict[str, Any]:
    ready: List[Tuple[str, float, float]] = []
    for key, weight in specs:
        value = axes.get(key)
        if value is not None:
            ready.append((key, float(value), float(weight)))
    denominator = sum(w for _, _, w in ready)
    score = sum(v * w for _, v, w in ready) / denominator if denominator > 0 else None
    if score is None:
        dispersion = None
    else:
        dispersion = math.sqrt(sum(w * ((v - score) ** 2) for _, v, w in ready) / denominator) if denominator > 0 else None
    return {
        "score": round(score, 6) if score is not None else None,
        "coverage_pct": round(len(ready) / max(1, len(specs)) * 100.0, 3),
        "ready": [k for k, _, _ in ready],
        "missing": [k for k, _ in specs if axes.get(k) is None],
        "dispersion": round(dispersion, 6) if dispersion is not None else None,
    }


def _direct_input_axes(row: Dict[str, Any], structure: Dict[str, Any]) -> Dict[str, Any]:
    """Build the single complete prediction input contract.

    Every directional input is sealed with owner, source field, raw level,
    normalized score, freshness and used/not-used state.  Missing/stale values
    remain missing; no zero-fill or output-only repair is allowed.
    """
    market = _nested(row, "global_market_context_v2130", "market_context_v2130")
    feature = _nested(row, "feature_momentum_context_v2130")
    orderflow = _nested(row, "orderflow_continuation_v2130")
    reaction = feature.get("vwap_ema_reaction_v2155") if isinstance(feature.get("vwap_ema_reaction_v2155"), dict) else {}
    micro = orderflow.get("micro_reaction_v2155") if isinstance(orderflow.get("micro_reaction_v2155"), dict) else {}
    owner_meta = row.get("prediction_owner_meta_v2155") if isinstance(row.get("prediction_owner_meta_v2155"), dict) else {}
    nowv = _num(owner_meta.get("strategy_cycle_ts"), time.time()) or time.time()

    axes: Dict[str, Optional[float]] = {}
    connections: Dict[str, Dict[str, Any]] = {}
    weights: Dict[str, float] = {}

    def raw_num(*vals: Any) -> Optional[float]:
        for value in vals:
            n = _num(value)
            if n is not None:
                return n
        return None

    def mean_ready(values: Iterable[Optional[float]]) -> Optional[float]:
        ready = [float(x) for x in values if x is not None]
        return sum(ready) / len(ready) if ready else None

    def age_from(*vals: Any) -> Optional[float]:
        ts = raw_num(*vals)
        return max(0.0, nowv - ts) if ts is not None and ts > 0 else None

    feature_age = age_from(feature.get("updated_ts"), row.get("feature_ts"), (owner_meta.get("feature") or {}).get("updated_ts"))
    market_age = age_from(market.get("updated_ts"), (owner_meta.get("market") or {}).get("updated_ts"))
    order_age = age_from(orderflow.get("sample_ts"), row.get("orderflow_ts"), (owner_meta.get("orderflow") or {}).get("updated_ts"))
    candle_age = raw_num((owner_meta.get("candle") or {}).get("age_sec"), row.get("official_candle_age"))

    def add(name: str, group: str, owner: str, source: str, raw: Any, score: Optional[float], *, weight: float, age: Optional[float], ttl: float, required: bool = True) -> None:
        state = "READY"
        used = True
        if score is None:
            state = "MISSING"
            used = False
        elif age is not None and age > ttl:
            state = "STALE"
            used = False
        value = _clip(float(score), -1.0, 1.0) if used and score is not None else None
        axes[name] = value
        weights[name] = float(weight)
        if isinstance(raw, dict):
            raw_out = {str(k): (round(float(v), 6) if _num(v) is not None else v) for k, v in raw.items()}
        elif isinstance(raw, (list, tuple)):
            raw_out = [round(float(v), 6) if _num(v) is not None else v for v in raw]
        else:
            raw_out = round(float(raw), 6) if _num(raw) is not None else raw
        connections[name] = {
            "group": group, "owner": owner, "source": source, "state": state,
            "raw": raw_out, "score": round(value, 6) if value is not None else None,
            "age_sec": round(age, 3) if age is not None else None, "ttl_sec": ttl,
            "weight": round(float(weight), 4), "required": bool(required), "used_in_prediction": bool(used),
        }

    # 1) completed-candle structure, actual price reaction and volatility fit.
    add("major_trend", "structure_context", "strategy_v2_core", "4h/2h completed trend", structure.get("major_trend_axis"), _num(structure.get("major_trend_axis")), weight=1.0, age=candle_age, ttl=420.0)
    add("setup_trend", "structure_context", "strategy_v2_core", "1h/30m completed trend", structure.get("setup_trend_axis"), _num(structure.get("setup_trend_axis")), weight=0.9, age=candle_age, ttl=300.0)

    vwap = raw_num(feature.get("vwap_gap_pct_v2155"), reaction.get("vwap_gap_pct"), row.get("vwap_gap_pct"))
    ema5 = raw_num(feature.get("ema5_gap_pct_v2155"), reaction.get("ema5_gap_pct"), row.get("ema5_gap_pct"))
    ema10 = raw_num(reaction.get("ema10_gap_pct"), row.get("ema10_gap_pct"))
    ema20 = raw_num(reaction.get("ema20_gap_pct"), row.get("ema20_gap_pct"))
    loc_parts = [_clip(x / 1.2, -1.0, 1.0) for x in (vwap, ema5, ema10, ema20) if x is not None]
    loc_score = mean_ready(loc_parts)
    add("location_hold", "structure_context", "feature_worker", "VWAP/EMA current position", {"vwap": vwap, "ema5": ema5, "ema10": ema10, "ema20": ema20}, loc_score, weight=1.0, age=feature_age, ttl=180.0)

    support_touch = raw_num(reaction.get("support_touch_count"), row.get("support_touch_count"))
    resistance_touch = raw_num(reaction.get("resistance_touch_count"), row.get("resistance_touch_count"))
    lower_wick = raw_num(reaction.get("lower_wick_pct"), row.get("lower_wick_pct"))
    upper_wick = raw_num(reaction.get("upper_wick_pct"), row.get("upper_wick_pct"))
    react_parts: List[float] = []
    if support_touch is not None: react_parts.append(_clip(support_touch / 3.0, 0.0, 1.0))
    if lower_wick is not None and upper_wick is not None: react_parts.append(_clip((lower_wick - upper_wick) / 80.0, -1.0, 1.0))
    for flag, val in ((reaction.get("sweep_reclaim_hint"), 0.75), (reaction.get("support_reclaim_hint"), 0.55), (reaction.get("pullback_volume_contract"), 0.35), (reaction.get("reclaim_volume_expand"), 0.55), (reaction.get("resistance_reject_hint"), -0.70), (reaction.get("long_upper_wick"), -0.55)):
        if flag is True: react_parts.append(val)
    reaction_score = mean_ready(react_parts)
    add("price_reaction", "structure_context", "candle/feature_worker", "touch/wick/reclaim/volume reaction", {"support_touch": support_touch, "resistance_touch": resistance_touch, "lower_wick": lower_wick, "upper_wick": upper_wick, "sweep": bool(reaction.get("sweep_reclaim_hint")), "reject": bool(reaction.get("resistance_reject_hint"))}, reaction_score, weight=1.15, age=feature_age, ttl=180.0)

    add("trigger_quality", "trigger_flow", "strategy_v2_core", "completed 5m break/retest quality", structure.get("trigger_quality_axis"), _num(structure.get("trigger_quality_axis")), weight=0.95, age=candle_age, ttl=180.0)
    body = raw_num(structure.get("breakout_body_pct")); upwick = raw_num(structure.get("breakout_upper_wick_pct")); close_pos = raw_num(structure.get("breakout_close_position_pct")); hold = raw_num(structure.get("trigger_hold_above_pct"))
    breakout_parts = []
    if body is not None: breakout_parts.append(_clip((body - 25.0) / 50.0, -1.0, 1.0))
    if upwick is not None: breakout_parts.append(_clip((35.0 - upwick) / 35.0, -1.0, 1.0))
    if close_pos is not None: breakout_parts.append(_clip((close_pos - 50.0) / 50.0, -1.0, 1.0))
    if hold is not None: breakout_parts.append(_clip(hold / 0.8, -1.0, 1.0))
    breakout_score = mean_ready(breakout_parts)
    add("breakout_reaction", "trigger_flow", "strategy_v2_core", "breakout body/wick/close/hold", {"body_pct": body, "upper_wick_pct": upwick, "close_position_pct": close_pos, "hold_above_pct": hold}, breakout_score, weight=1.15, age=candle_age, ttl=180.0)

    volume_ratio = raw_num(reaction.get("volume_ratio"), row.get("volume_ratio"))
    volume_exp = raw_num(reaction.get("volume_expansion_pct"), row.get("volume_expansion_pct"))
    volume_axis = _num(structure.get("volume_expansion_axis"))
    volume_parts = [volume_axis]
    if volume_ratio is not None: volume_parts.append(_clip((volume_ratio - 1.0) / 1.5, -1.0, 1.0))
    if volume_exp is not None: volume_parts.append(_clip(volume_exp / 150.0, -1.0, 1.0))
    if reaction.get("pullback_volume_contract") is True: volume_parts.append(0.35)
    if reaction.get("reclaim_volume_expand") is True: volume_parts.append(0.55)
    add("volume_response", "participation", "candle/feature_worker", "current volume + pullback/reclaim response", {"axis": volume_axis, "ratio": volume_ratio, "expansion_pct": volume_exp}, mean_ready(volume_parts), weight=1.0, age=feature_age, ttl=180.0)

    invalid_noise = raw_num(structure.get("invalid_noise_multiple")); target_atr = raw_num(structure.get("target_atr_multiple")); atr_exp = raw_num(structure.get("short_atr_expansion_ratio"))
    vol_parts = []
    if invalid_noise is not None:
        vol_parts.append(1.0 if 0.9 <= invalid_noise <= 2.8 else _clip(1.0 - abs(invalid_noise - 1.7) / 2.5, -1.0, 1.0))
    if target_atr is not None:
        vol_parts.append(1.0 if 0.45 <= target_atr <= 3.0 else _clip(1.0 - abs(target_atr - 1.6) / 3.0, -1.0, 1.0))
    if atr_exp is not None: vol_parts.append(_clip(1.0 - abs(atr_exp - 1.25) / 1.75, -1.0, 1.0))
    add("volatility_fit", "structure_context", "strategy_v2_core", "invalid/target distance versus ATR", {"invalid_noise_multiple": invalid_noise, "target_atr_multiple": target_atr, "short_atr_expansion_ratio": atr_exp}, mean_ready(vol_parts), weight=0.8, age=candle_age, ttl=300.0)

    consumed = _clip(_num(structure.get("entry_fraction_to_t1"), 0.0) or 0.0, 0.0, 1.0)
    timing_score = _clip(1.0 - 2.0 * consumed, -1.0, 1.0)
    add("entry_timing", "structure_context", "strategy_v2_core", "trigger-to-T1 path consumed", consumed, timing_score, weight=0.9, age=0.0, ttl=999999.0)

    # 2) ticker strength and actual money participation: level + rank + velocity.
    rs_level = raw_num(feature.get("relative_strength_level_v2155"), row.get("relative_strength_pct"))
    rs_rank = raw_num(feature.get("relative_strength_rank_pct_v2155"), row.get("relative_strength_rank_pct_v1095"))
    rs_velocity = raw_num(feature.get("relative_strength_velocity_v2130"))
    rs_level_score = mean_ready([_clip(rs_level / 5.0, -1.0, 1.0) if rs_level is not None else None, _clip((rs_rank - 50.0) / 50.0, -1.0, 1.0) if rs_rank is not None else None])
    add("relative_strength_level", "participation", "feature_worker", "current RS level + market rank", {"level_pct": rs_level, "rank_pct": rs_rank}, rs_level_score, weight=1.25, age=feature_age, ttl=180.0)
    add("relative_strength_velocity", "participation", "feature_worker", "RS change from prior feature sample", rs_velocity, _clip(rs_velocity / 3.0, -1.0, 1.0) if rs_velocity is not None else None, weight=0.55, age=feature_age, ttl=180.0, required=False)

    money_level = raw_num(feature.get("money_flow_level_v2155"), row.get("money_flow_score"))
    turnover_rank = raw_num(feature.get("turnover_rank_pct_v2155"), row.get("turnover_rank_pct_v1095"))
    volume_rank = raw_num(feature.get("volume_flow_rank_pct_v2155"), row.get("volume_flow_rank_pct_v1095"))
    short_rank = raw_num(feature.get("short_flow_rank_pct_v2155"), row.get("short_flow_rank_pct_v1095"))
    money_velocity = raw_num(feature.get("money_flow_velocity_v2130"))
    money_level_score = mean_ready([_clip((x - 50.0) / 50.0, -1.0, 1.0) for x in (money_level, turnover_rank, volume_rank, short_rank) if x is not None])
    add("money_flow_level", "participation", "feature_worker", "money-flow score + turnover/volume/short ranks", {"score": money_level, "turnover_rank": turnover_rank, "volume_rank": volume_rank, "short_rank": short_rank}, money_level_score, weight=1.25, age=feature_age, ttl=180.0)
    add("money_flow_velocity", "participation", "feature_worker", "money-flow change from prior feature sample", money_velocity, _clip(money_velocity / 25.0, -1.0, 1.0) if money_velocity is not None else None, weight=0.55, age=feature_age, ttl=180.0, required=False)

    changes = feature.get("momentum_changes_pct_v2155") if isinstance(feature.get("momentum_changes_pct_v2155"), dict) else {k: row.get(k) for k in ("change_1m", "change_3m", "change_5m", "change_15m", "change_30m")}
    moment_parts = []
    moment_weights = {"change_1m": 0.15, "change_3m": 0.25, "change_5m": 0.25, "change_15m": 0.25, "change_30m": 0.10}
    denom = 0.0
    for key, w in moment_weights.items():
        value = raw_num(changes.get(key))
        if value is not None:
            moment_parts.append(_clip(value / (1.2 if key in {"change_1m","change_3m"} else 2.5), -1.0, 1.0) * w); denom += w
    momentum_level = sum(moment_parts) / denom if denom > 0 else None
    consistency = raw_num(feature.get("momentum_consistency_pct_v2130"))
    add("momentum_level", "participation", "feature_worker", "1m/3m/5m/15m/30m current momentum", changes, momentum_level, weight=0.95, age=feature_age, ttl=180.0)
    add("momentum_consistency", "participation", "feature_worker", "positive timeframe consistency", consistency, _clip((consistency - 50.0) / 50.0, -1.0, 1.0) if consistency is not None else None, weight=0.8, age=feature_age, ttl=180.0)

    # 3) global market components remain separate. Risk state is never hidden inside one average.
    breadth = raw_num(market.get("breadth_up_pct")); breadth_vel = raw_num(market.get("breadth_velocity_pct_v2130")); leader = raw_num(market.get("leader_persistence_pct_v2130"))
    btc_dir = str(market.get("btc_short_direction") or "").upper(); ext = market.get("external_market_lead_v2130") if isinstance(market.get("external_market_lead_v2130"), dict) else {}
    ext_dir = str(ext.get("direction") or "").upper(); risk_state = str(market.get("risk_state_v2130") or "").upper()
    direction_map = {"STRONG_UP": 1.0, "UP": 0.55, "FLAT": 0.0, "DOWN": -0.55, "STRONG_DOWN": -1.0}
    risk_map = {"NORMAL": 0.25, "WEAK": -0.35, "DANGER": -0.75, "RISK_OFF": -1.0}
    add("market_breadth", "market_context", "market_regime_worker", "alt breadth current level", breadth, _clip((breadth - 50.0) / 50.0, -1.0, 1.0) if breadth is not None else None, weight=0.9, age=market_age, ttl=180.0)
    add("market_breadth_velocity", "market_context", "market_regime_worker", "breadth change speed", breadth_vel, _clip(breadth_vel / 10.0, -1.0, 1.0) if breadth_vel is not None else None, weight=0.55, age=market_age, ttl=180.0, required=False)
    add("btc_direction", "market_context", "market_regime_worker", "BTC 1m/3m/5m completed direction", btc_dir or None, direction_map.get(btc_dir), weight=1.05, age=market_age, ttl=180.0)
    add("leader_persistence", "market_context", "market_regime_worker", "top turnover leaders persistence", leader, _clip((leader - 50.0) / 50.0, -1.0, 1.0) if leader is not None else None, weight=0.6, age=market_age, ttl=180.0, required=False)
    add("external_market", "market_context", "market_regime_worker", "external BTC lead", ext_dir or None, direction_map.get(ext_dir), weight=0.45, age=raw_num(ext.get("age_sec"), market_age), ttl=90.0, required=False)
    add("market_risk", "market_context", "market_regime_worker", "separate market risk state", risk_state or None, risk_map.get(risk_state), weight=1.25, age=market_age, ttl=180.0)
    concentration = raw_num(market.get("turnover_concentration_top10_pct_v2130")); concentration_vel = raw_num(market.get("turnover_concentration_velocity_v2130")); dispersion_mkt = raw_num(market.get("market_change_dispersion_pct_v2155"))
    concentration_score = mean_ready([_clip((concentration - 25.0) / 35.0, -1.0, 1.0) if concentration is not None else None, _clip(concentration_vel / 8.0, -1.0, 1.0) if concentration_vel is not None else None, _clip(1.0 - (dispersion_mkt or 0.0) / 12.0, -1.0, 1.0) if dispersion_mkt is not None else None])
    add("market_liquidity_regime", "market_context", "market_regime_worker", "turnover concentration + market dispersion", {"concentration": concentration, "velocity": concentration_vel, "dispersion": dispersion_mkt}, concentration_score, weight=0.55, age=market_age, ttl=180.0, required=False)

    # 4) current orderflow level + persistence + wall pressure + acceleration.
    buy_ratio = raw_num(orderflow.get("buy_ratio_level_v2155"), row.get("buy_ratio"), row.get("buy_ratio_1m"))
    buy_sustain = raw_num(orderflow.get("buy_sustain_level_v2155"), row.get("buy_sustain_1m"), row.get("buy_sustain_60s"))
    buy_persist = raw_num(orderflow.get("buy_persist_level_v2155"), row.get("buy_persist_1m"))
    ask_wall = raw_num(orderflow.get("ask_wall_ratio_level_v2155"), row.get("ask_wall_ratio"), row.get("micro_ask_wall_ratio"))
    sell_pressure = orderflow.get("sell_pressure_level_v2155") if "sell_pressure_level_v2155" in orderflow else row.get("sell_pressure")
    order_velocity = raw_num(orderflow.get("continuation_score_v2130"))
    add("buy_ratio_level", "trigger_flow", "orderflow_worker", "current aggressive buy ratio", buy_ratio, _clip((buy_ratio - 0.50) / 0.25, -1.0, 1.0) if buy_ratio is not None else None, weight=1.15, age=order_age, ttl=45.0)
    sustain_score = mean_ready([_clip((buy_sustain - 0.50) / 0.25, -1.0, 1.0) if buy_sustain is not None else None, _clip((buy_persist - 0.50) / 0.35, -1.0, 1.0) if buy_persist is not None else None])
    add("buy_sustain_level", "trigger_flow", "orderflow_worker", "current 20s/60s buy persistence", {"sustain": buy_sustain, "persist": buy_persist}, sustain_score, weight=1.15, age=order_age, ttl=45.0)
    add("orderflow_velocity", "trigger_flow", "orderflow_worker", "buy/wall/spread change speed", order_velocity, _clip((order_velocity - 50.0) / 50.0, -1.0, 1.0) if order_velocity is not None else None, weight=0.65, age=order_age, ttl=45.0, required=False)
    add("ask_wall_pressure", "trigger_flow", "orderflow_worker", "current ask-wall ratio", ask_wall, _clip((1.0 - ask_wall) / 0.8, -1.0, 1.0) if ask_wall is not None else None, weight=0.85, age=order_age, ttl=45.0)
    sell_score = None if sell_pressure is None else (-0.85 if bool(sell_pressure) else 0.15)
    add("sell_pressure", "trigger_flow", "orderflow_worker", "current sell pressure flag", sell_pressure, sell_score, weight=0.75, age=order_age, ttl=45.0, required=False)

    micro_parts = []
    for key, scale in (("price_accel_10s", 0.6), ("price_accel_20s", 0.8), ("price_chg_20s", 0.8), ("price_chg_60s", 1.2)):
        value = raw_num(micro.get(key))
        if value is not None: micro_parts.append(_clip(value / scale, -1.0, 1.0))
    br10 = raw_num(micro.get("buy_ratio_10s")); bs20 = raw_num(micro.get("buy_sustain_20s")); burst = raw_num(micro.get("trade_burst_10s"))
    if br10 is not None: micro_parts.append(_clip((br10 - 0.5) / 0.25, -1.0, 1.0))
    if bs20 is not None: micro_parts.append(_clip((bs20 - 0.5) / 0.25, -1.0, 1.0))
    if burst is not None: micro_parts.append(_clip(burst / 4.0, -1.0, 1.0))
    if micro.get("spread_widening_10s") is True: micro_parts.append(-0.65)
    add("micro_acceleration", "trigger_flow", "orderflow_worker", "5-60s price/buy/trade acceleration", {k: micro.get(k) for k in ("price_accel_10s","price_accel_20s","price_chg_20s","price_chg_60s","buy_ratio_10s","buy_sustain_20s","trade_burst_10s","spread_widening_10s")}, mean_ready(micro_parts), weight=0.65, age=order_age, ttl=30.0, required=False)

    # Group scores and one auditable connection summary.
    group_specs = {
        "structure_context": tuple((k, weights[k]) for k in axes if connections[k]["group"] == "structure_context"),
        "market_context": tuple((k, weights[k]) for k in axes if connections[k]["group"] == "market_context"),
        "participation": tuple((k, weights[k]) for k in axes if connections[k]["group"] == "participation"),
        "trigger_flow": tuple((k, weights[k]) for k in axes if connections[k]["group"] == "trigger_flow"),
    }
    groups = {name: _weighted_group(axes, specs) for name, specs in group_specs.items()}
    structure_score = _num(groups["structure_context"].get("score")); market_score = _num(groups["market_context"].get("score"))
    groups["context"] = {
        "score": round((0.58 * structure_score + 0.42 * market_score), 6) if structure_score is not None and market_score is not None else None,
        "coverage_pct": round((groups["structure_context"]["coverage_pct"] + groups["market_context"]["coverage_pct"]) / 2.0, 3),
        "ready": list(groups["structure_context"]["ready"]) + list(groups["market_context"]["ready"]),
        "missing": list(groups["structure_context"]["missing"]) + list(groups["market_context"]["missing"]),
        "dispersion": mean_ready([_num(groups["structure_context"].get("dispersion")), _num(groups["market_context"].get("dispersion"))]),
    }

    ready = {k: float(v) for k, v in axes.items() if v is not None}
    missing = [k for k, c in connections.items() if c["state"] == "MISSING"]
    stale = [k for k, c in connections.items() if c["state"] == "STALE"]
    required_missing = [k for k, c in connections.items() if c["required"] and c["state"] != "READY"]
    denominator = sum(weights[k] for k in ready)
    combined = sum(ready[k] * weights[k] for k in ready) / denominator if denominator > 0 else None
    dispersion = math.sqrt(sum(weights[k] * ((ready[k] - combined) ** 2) for k in ready) / denominator) if combined is not None and denominator > 0 else None
    contradictions = [k for k, v in ready.items() if combined is not None and ((combined >= 0 and v < -0.12) or (combined < 0 and v > 0.12))]
    positive = sum(1 for v in ready.values() if v > 0.12); negative = sum(1 for v in ready.values() if v < -0.12)
    coverage = len(ready) / max(1, len(axes)); agreement = abs(positive - negative) / max(1, len(ready))
    critical_keys = ("market_risk", "relative_strength_level", "money_flow_level", "momentum_level", "volume_response", "buy_ratio_level", "buy_sustain_level", "ask_wall_pressure", "breakout_reaction")
    critical_negative = [k for k in critical_keys if axes.get(k) is not None and float(axes[k]) < -0.12]
    fake_inputs = [axes.get(k) for k in ("breakout_reaction", "volume_response", "relative_strength_level", "buy_ratio_level", "buy_sustain_level", "ask_wall_pressure", "micro_acceleration") if axes.get(k) is not None]
    weak_fraction = sum(1 for v in fake_inputs if float(v) < -0.12) / max(1, len(fake_inputs)); negative_pressure = sum(max(0.0, -float(v)) for v in fake_inputs) / max(1, len(fake_inputs))
    fake_break_risk = _clip(0.58 * weak_fraction + 0.42 * negative_pressure, 0.0, 1.0)
    owner_summary: Dict[str, Dict[str, int]] = {}
    for c in connections.values():
        owner = str(c["owner"]); state = str(c["state"]); owner_summary.setdefault(owner, {"READY":0,"MISSING":0,"STALE":0,"TOTAL":0}); owner_summary[owner][state] = owner_summary[owner].get(state,0)+1; owner_summary[owner]["TOTAL"] += 1
    return {
        "schema": "combined_v2_prediction_evidence_v2155", "prediction_model_generation": PREDICTION_MODEL_GENERATION,
        "axes": axes, "groups": groups, "input_connections_v2155": connections,
        "owner_connection_summary_v2155": owner_summary, "required_input_failures_v2155": required_missing,
        "ready_axes": len(ready), "missing_axes": missing, "stale_axes_v2155": stale,
        "input_coverage_pct": round(coverage * 100.0, 3), "required_input_coverage_pct_v2155": round((sum(1 for c in connections.values() if c["required"] and c["state"]=="READY") / max(1, sum(1 for c in connections.values() if c["required"]))) * 100.0, 3),
        "direction_agreement_pct": round(agreement * 100.0, 3), "combined_axis": round(combined, 6) if combined is not None else None,
        "axis_dispersion": round(dispersion, 6) if dispersion is not None else None, "contradiction_axes": contradictions,
        "contradiction_ratio": round(len(contradictions) / max(1, len(ready)), 6), "critical_negative_axes": critical_negative,
        "fake_break_risk": round(fake_break_risk, 6), "owner_meta_v2155": owner_meta,
        "all_required_inputs_connected_v2155": not required_missing, "zero_fill_used_v2155": False, "auto_buy": False,
    }


def _entry_timing_diagnosis(structure: Dict[str, Any]) -> Dict[str, Any]:
    """Diagnostic-only explanation of whether target room was consumed by lateness.

    The 50% boundary is already the sealed Paper execution policy.  This helper
    only names the condition; it does not change Strategy or Paper eligibility.
    """
    fraction = _clip(_num(structure.get("entry_fraction_to_t1"), 0.0) or 0.0, 0.0, 1.0)
    room = _num(structure.get("t1_room_pct"), 0.0) or 0.0
    rr = _num(structure.get("rr_t1"))
    current = _num(structure.get("current_price"), 0.0) or 0.0
    trigger = _num(structure.get("trigger"), 0.0) or 0.0
    if fraction >= 0.50:
        state = "LATE_TARGET_PATH_CONSUMED"
        reason = "Trigger 이후 가격이 T1 경로의 절반 이상 진행해 진입이 늦음"
    elif fraction > 0.0 and current > trigger > 0.0:
        state = "TARGET_PATH_PARTLY_CONSUMED"
        reason = "Trigger 이후 일부 상승해 목표공간을 이미 사용함"
    elif rr is not None and rr < 1.0:
        state = "TARGET_NEAR_RELATIVE_TO_INVALID"
        reason = "진입이 늦다기보다 T1이 invalid 대비 가까워 구조 손익비가 작음"
    elif room > 0.0 and room < 0.50:
        state = "TARGET_ABSOLUTE_ROOM_SMALL"
        reason = "진입 위치는 늦지 않지만 가까운 2h·4h 저항 때문에 절대 목표공간이 작음"
    else:
        state = "ENTRY_LOCATION_NOT_LATE"
        reason = "T1 경로 절반 이상을 소비한 늦은 진입은 아님"
    return {
        "state": state, "reason": reason,
        "entry_fraction_to_t1": round(fraction, 6),
        "t1_room_pct": round(room, 6),
        "rr_t1": round(rr, 6) if rr is not None else None,
        "diagnostic_only": True,
    }


def _prediction(row: Dict[str, Any], structure: Dict[str, Any]) -> Dict[str, Any]:
    evidence = _direct_input_axes(row, structure)
    groups = evidence.get("groups") if isinstance(evidence.get("groups"), dict) else {}
    structure_context = _num((groups.get("structure_context") or {}).get("score")) if isinstance(groups.get("structure_context"), dict) else None
    market_context = _num((groups.get("market_context") or {}).get("score")) if isinstance(groups.get("market_context"), dict) else None
    participation = _num((groups.get("participation") or {}).get("score")) if isinstance(groups.get("participation"), dict) else None
    trigger_flow = _num((groups.get("trigger_flow") or {}).get("score")) if isinstance(groups.get("trigger_flow"), dict) else None
    coverage = (_num(evidence.get("input_coverage_pct"), 0.0) or 0.0) / 100.0
    required_coverage = (_num(evidence.get("required_input_coverage_pct_v2155"), 0.0) or 0.0) / 100.0
    dispersion_value = _num(evidence.get("axis_dispersion"))
    contradiction_value = _num(evidence.get("contradiction_ratio"))
    fake_break_value = _num(evidence.get("fake_break_risk"))
    dispersion = 1.0 if dispersion_value is None else dispersion_value
    contradiction = 1.0 if contradiction_value is None else contradiction_value
    fake_break = 1.0 if fake_break_value is None else fake_break_value
    required_failures = list(evidence.get("required_input_failures_v2155") or [])
    group_coverages = {key: (_num((value or {}).get("coverage_pct"), 0.0) or 0.0) / 100.0 for key, value in groups.items() if isinstance(value, dict)}
    missing_groups = [key for key in ("structure_context", "market_context", "participation", "trigger_flow") if group_coverages.get(key, 0.0) < 0.60]
    if any(x is None for x in (structure_context, market_context, participation, trigger_flow)) or coverage < 0.72 or required_coverage < 1.0 or missing_groups or required_failures:
        return {
            "schema": "combined_v2_continuation_prediction_v2155", "state": "DATA_MISSING",
            "prediction_model_generation": PREDICTION_MODEL_GENERATION,
            "p_t1_before_invalid": None, "p_invalid_before_t1": None, "p_no_touch_6h": None,
            "directional_edge": None, "structural_ev_pct": None, "continuation_score": None,
            "input_coverage_pct": round(coverage * 100.0, 3), "required_input_coverage_pct_v2155": round(required_coverage * 100.0, 3),
            "model_confidence_pct": 0.0, "probability_is_calibrated": False,
            "prediction_used_in_final_decision": True, "decision_combiner_active": True,
            "missing_groups": missing_groups, "required_input_failures_v2155": required_failures,
            "entry_timing_diagnosis": _entry_timing_diagnosis(structure),
            "decision_detail_reasons": ["필수 후보품질 입력이 모두 연결되지 않음"],
            "decision_components": {"lower_bound_positive": None, "first_touch_edge_positive": None, "structural_ev_positive": None},
            "evidence": evidence, "auto_buy": False,
        }

    axes = evidence.get("axes") if isinstance(evidence.get("axes"), dict) else {}
    timing_axis = _num(axes.get("entry_timing"), 0.0) or 0.0
    market_risk_axis = _num(axes.get("market_risk"), 0.0) or 0.0
    volatility_axis = _num(axes.get("volatility_fit"), 0.0) or 0.0
    group_floor = min(structure_context, market_context, participation, trigger_flow)
    interaction = 0.28 * group_floor if group_floor >= 0 else 0.58 * group_floor
    # v2159: market_risk already belongs to market_context. Do not add it again.
    continuation_score = (
        0.22 * structure_context + 0.22 * market_context + 0.28 * participation + 0.28 * trigger_flow + interaction
        + 0.10 * timing_axis + 0.08 * volatility_axis
        - 0.72 * fake_break - 0.34 * contradiction
    )
    uncertainty = _clip(0.09 + 0.24 * dispersion + 0.50 * (1.0 - required_coverage) + 0.30 * (1.0 - coverage) + 0.22 * contradiction, 0.08, 0.78)
    lower = continuation_score - uncertainty; upper = continuation_score + uncertainty

    # Compatibility probability proxies remain visible for audit only. They are not calibrated
    # and are no longer allowed to decide ENTRY_READY. Far T1 geometry is reachability-adjusted
    # with the already existing 3-ATR fit boundary instead of inflating expected value.
    base_rate = 0.075
    p_t1_raw = _clip(_sigmoid(_logit(base_rate) + 2.05 * continuation_score), 0.01, 0.55)
    p_invalid = _clip(_sigmoid(_logit(0.11) - 1.90 * continuation_score + 0.70 * fake_break), 0.02, 0.65)
    target_atr_multiple = _num(structure.get("target_atr_multiple"))
    reachability_factor = 1.0 if target_atr_multiple is None or target_atr_multiple <= 3.0 else _clip(3.0 / max(target_atr_multiple, 1e-12), 0.05, 1.0)
    p_t1 = p_t1_raw * math.sqrt(reachability_factor)
    total = p_t1 + p_invalid
    if total > 0.90:
        scale = 0.90 / total; p_t1 *= scale; p_invalid *= scale
    p_no_touch = max(0.0, 1.0 - p_t1 - p_invalid)
    risk_pct = _num(structure.get("risk_pct"), 0.0) or 0.0; room_pct = _num(structure.get("t1_room_pct"), 0.0) or 0.0
    effective_room_pct = room_pct * reachability_factor
    structural_ev = p_t1 * effective_room_pct - p_invalid * risk_pct if risk_pct > 0 and room_pct > 0 else None
    edge = p_t1 - p_invalid

    # v2161: the uncertainty band is hand-built and not calibrated against outcomes.
    # Keep lower/upper visible for diagnosis, but never use either as an ENTRY_READY gate.
    score_positive = continuation_score > 0.0
    participation_positive = participation > 0.0
    trigger_flow_positive = trigger_flow > 0.0
    volatility_reachable = volatility_axis > 0.0
    structure_quality_positive_v2170 = True  # v2171 rollback: failed +0.341 gate is not used in entry
    if score_positive and participation_positive and trigger_flow_positive and volatility_reachable and structure_quality_positive_v2170:
        state = "CONTINUATION_FAVORED"; reason = "종합 상승점수·큰흐름 구조·거래대금·상대강도·Trigger·체결·T1 도달성이 모두 확인됨"
    elif score_positive and participation_positive and trigger_flow_positive and volatility_reachable and not structure_quality_positive_v2170:
        state = "STRUCTURE_QUALITY_WAIT"; reason = "상승 신호는 있으나 4h·2h 큰흐름과 1h·30m 구조 품질이 손실방어 기준에 미달"
    elif continuation_score < 0.0 and (not participation_positive) and (not trigger_flow_positive):
        state = "INVALID_RISK_FAVORED"; reason = "종합 상승점수가 음수이고 거래대금·상대강도와 Trigger·체결도 함께 약함"
    else:
        state = "CONTINUATION_UNCLEAR"; reason = "종합 상승점수 또는 거래대금·체결·T1 도달성 중 하나가 독립적으로 확인되지 않음"
    timing = _entry_timing_diagnosis(structure)
    details: List[str] = []
    if not score_positive: details.append("종합 상승점수가 양수로 확인되지 않음")
    if lower <= 0.0 <= upper: details.append("진단용 오차범위가 상승·하락 양쪽에 걸침")
    elif upper < 0.0: details.append("진단용 상단값도 하락 쪽")
    if not participation_positive: details.append("현재 거래대금·상대강도·모멘텀 참여가 양수로 확인되지 않음")
    if not trigger_flow_positive: details.append("현재 Trigger 이후 체결·매수지속이 양수로 확인되지 않음")
    if not volatility_reachable: details.append("변동성 대비 Invalid·T1 도달성이 양수로 확인되지 않음")
    if not structure_quality_positive_v2170: details.append(f"큰흐름·구조 기준 {structure_context:+.3f} < {QUALITY_STRUCTURE_MIN_V2170:+.3f}")
    if reachability_factor < 1.0: details.append("T1이 3ATR보다 멀어 기대공간을 도달가능 범위로 축소")
    if market_risk_axis <= -0.7: details.append("시장 위험상태가 DANGER/RISK_OFF")
    if timing.get("state") != "ENTRY_LOCATION_NOT_LATE": details.append(str(timing.get("reason") or timing.get("state")))
    for axis in evidence.get("critical_negative_axes") or []:
        details.append(f"핵심 약점축 {axis}")
    if not details: details.append(reason)
    confidence = _clip(required_coverage * coverage * (1.0 - 0.40 * dispersion) * (1.0 - 0.48 * contradiction) * (1.0 - 0.30 * uncertainty), 0.0, 0.78)
    expected_mfe = effective_room_pct * p_t1 + min(effective_room_pct, risk_pct) * p_no_touch * max(0.0, continuation_score) * 0.20
    expected_mae = -(risk_pct * p_invalid + min(room_pct, risk_pct) * p_no_touch * max(0.0, -continuation_score) * 0.20)
    return {
        "schema": "combined_v2_continuation_prediction_v2155", "state": state,
        "prediction_model_generation": PREDICTION_MODEL_GENERATION,
        "p_t1_before_invalid": round(p_t1, 6), "p_invalid_before_t1": round(p_invalid, 6), "p_no_touch_6h": round(p_no_touch, 6),
        "directional_edge": round(edge, 6), "structural_ev_pct": round(structural_ev, 6) if structural_ev is not None else None,
        "continuation_score": round(continuation_score, 6), "uncertainty_margin": round(uncertainty, 6),
        "continuation_lower_bound": round(lower, 6), "continuation_upper_bound": round(upper, 6),
        "expected_mfe_pct_6h": round(expected_mfe, 6), "expected_mae_pct_6h": round(expected_mae, 6),
        "input_coverage_pct": round(coverage * 100.0, 3), "required_input_coverage_pct_v2155": round(required_coverage * 100.0, 3),
        "model_confidence_pct": round(confidence * 100.0, 3), "probability_is_calibrated": False,
        "probability_used_in_final_decision_v2159": False,
        "probability_role_v2159": "DIAGNOSTIC_PROXY_ONLY",
        "market_risk_direct_duplicate_removed_v2159": True,
        "target_reachability_factor_v2159": round(reachability_factor, 6),
        "effective_t1_room_pct_v2159": round(effective_room_pct, 6),
        "p_t1_raw_proxy_v2159": round(p_t1_raw, 6),
        "prediction_used_in_final_decision": True, "decision_combiner_active": True, "calibration_generation": GENERATION,
        "decision_reason": reason, "decision_detail_reasons": details,
        "decision_components": {
            "lower_bound_positive": bool(lower > 0.0),
            "lower_bound_diagnostic_only_v2161": True,
            "uncalibrated_lower_bound_used_v2161": False,
            "continuation_score_positive_v2161": score_positive,
            "participation_positive_v2159": participation_positive,
            "trigger_flow_positive_v2159": trigger_flow_positive,
            "volatility_reachable_v2159": volatility_reachable,
            "structure_quality_positive_v2170": structure_quality_positive_v2170,
            "structure_quality_score_v2170": round(structure_context, 6),
            "structure_quality_min_v2170": QUALITY_STRUCTURE_MIN_V2170,
            "structure_quality_source_v2170": QUALITY_STRUCTURE_SOURCE_V2170,
            "structure_quality_gate_active_v2171": False,
            "v2170_failed_gate_rolled_back_v2171": True,
            "uncalibrated_probability_used_v2159": False,
            "first_touch_edge_diagnostic_only_v2159": bool(edge > 0.0),
            "structural_ev_diagnostic_only_v2159": bool(structural_ev is not None and structural_ev > 0.0),
            "all_required_inputs_connected_v2155": True,
        },
        "entry_timing_diagnosis": timing, "evidence": evidence, "auto_buy": False,
    }


def _combine_structure_prediction(structure: Dict[str, Any], prediction: Dict[str, Any]) -> Dict[str, Any]:
    structure_state = str(structure.get("state") or "ENGINE_ERROR")
    prediction_state = str(prediction.get("state") or "DATA_MISSING")
    if structure_state != "STRUCTURE_READY":
        final_state = structure_state
        eligible = False
        owner = "structure"
        reason = f"구조 상태 {structure_state}"
    elif prediction_state == "CONTINUATION_FAVORED":
        final_state = "ENTRY_READY"
        eligible = True
        owner = "structure_prediction_combiner"
        reason = str(prediction.get("decision_reason") or "구조와 상승예측 동시 통과")
    elif prediction_state == "STRUCTURE_QUALITY_WAIT":
        final_state = "QUALITY_STRUCTURE_WAIT"
        eligible = False
        owner = "prediction_structure_quality"
        reason = str(prediction.get("decision_reason") or "큰흐름·구조 품질 기준 대기")
    elif prediction_state == "DATA_MISSING":
        final_state = "PREDICTION_DATA_WAIT"
        eligible = False
        owner = "prediction"
        reason = "상승예측 핵심 입력자료 부족 · 후보 보존, 실행만 대기"
    elif prediction_state == "INVALID_RISK_FAVORED":
        final_state = "PREDICTION_RISK_WAIT"
        eligible = False
        owner = "prediction"
        reason = str(prediction.get("decision_reason") or "invalid 선도달 위험 우위")
    else:
        final_state = "PREDICTION_UNCLEAR_WAIT"
        eligible = False
        owner = "prediction"
        reason = str(prediction.get("decision_reason") or "상승 지속 근거 불명확")
    return {
        "schema": "structure_prediction_combiner_v2149",
        "state": final_state,
        "entry_eligible": eligible,
        "owner": owner,
        "reason": reason,
        "structure_state": structure_state,
        "prediction_state": prediction_state,
        "prediction_recomputed_in_paper": False,
        "candidate_preserved": True,
        "auto_buy": False,
    }

def _plan_hash(payload: Dict[str, Any]) -> str:
    raw = json.dumps(payload, ensure_ascii=False, sort_keys=True, separators=(",", ":")).encode("utf-8")
    return hashlib.sha256(raw).hexdigest()[:20]


def build_combined_v2_contract(row: Dict[str, Any], frames: Dict[str, List[Dict[str, float]]], *, now_ts: Optional[float] = None) -> Dict[str, Any]:
    ts = float(now_ts if now_ts is not None else time.time())
    ticker = str(row.get("ticker") or row.get("symbol") or "").upper().replace("KRW-", "").strip()
    current = _row_price(row)
    counts = {tf: len(frames.get(tf) or []) for tf in REQUIRED_ROWS}
    missing = [tf for tf, need in REQUIRED_ROWS.items() if counts.get(tf, 0) < need]
    if current is None or current <= 0:
        missing.append("current_price")
    base: Dict[str, Any] = {
        "schema": "combined_v2_trade_contract_v2149", "version": VERSION, "build": BUILD_LABEL,
        "generation": GENERATION, "prediction_model_generation": PREDICTION_MODEL_GENERATION, "ticker": ticker, "evaluated_ts": ts,
        "candidate_preserved": True, "historical_ledger_rewritten": False,
        "legacy_structure_used": False, "legacy_entry_gate_used": False,
        "prediction_gate_active": True, "decision_combiner_active": True, "auto_buy": False,
    }
    if missing:
        base.update({
            "state": "DATA_MISSING", "decision_key": None, "plan_key": None,
            "material_diagnosis": {"state": "DATA_MISSING", "owner": "candle_worker" if "current_price" not in missing else "feature_worker", "missing": sorted(set(missing)), "candidate_quality_failed": False},
            "structure": {"state": "DATA_MISSING", "frame_counts": counts, "completed_candles_only": True},
            "prediction": {"state": "WAIT_STRUCTURE", "prediction_used_in_final_decision": True, "decision_combiner_active": True, "probability_is_calibrated": False},
            "decision_combiner": {"state": "WAIT_STRUCTURE", "entry_eligible": False, "candidate_preserved": True, "auto_buy": False},
        })
        return base

    m5, m15, m30, h1, h2, h4 = (frames[tf] for tf in ("m5", "m15", "m30", "h1", "h2", "h4"))
    atr5, atr15, atr30, atr1h, atr2h, atr4h = (_atr(x) for x in (m5, m15, m30, h1, h2, h4))
    major_axes = [x for x in (_trend_axis(h4), _trend_axis(h2)) if x is not None]
    setup_axes = [x for x in (_trend_axis(h1), _trend_axis(m30)) if x is not None]
    major_axis = sum(major_axes) / len(major_axes) if major_axes else 0.0
    setup_axis = sum(setup_axes) / len(setup_axes) if setup_axes else 0.0

    entry_levels = _level_candidates(frames, ("m5", "m15"), "resistance")
    entry_clusters = _cluster_levels(entry_levels, atr_ref=max(atr5, atr15 * 0.6), current=current)
    setup_levels = _level_candidates(frames, ("m30", "h1"), "support")
    support_clusters = _cluster_levels(setup_levels, atr_ref=max(atr30, atr1h * 0.55), current=current)
    target_levels = _level_candidates(frames, ("h2", "h4"), "resistance")
    target_clusters = _cluster_levels(target_levels, atr_ref=max(atr2h, atr4h * 0.55), current=current)

    # v2159 Trigger correctness repair.
    # - A resistance is a zone, so breakout ownership is the zone HIGH, never the center.
    # - A completed breakout remains valid for up to three completed 5m bars while closes hold above it.
    # - Among equally near zones (same clustering tolerance), prefer the better confirmed/recent zone.
    recent_rows = m5[-6:]
    recent_closes = [float(r["c"]) for r in recent_rows]
    recent_lows = [float(r["l"]) for r in recent_rows]
    # v2166: the 5m close remains the primary confirmation, but completed 1m/3m
    # candles may confirm the same already-built WAIT_TRIGGER contract earlier.
    # Forming candles are still excluded by the candle owner.
    m1 = list(frames.get("m1") or [])
    m3 = list(frames.get("m3") or [])
    short_frames_ready_v2166 = bool(len(m1) >= 3 or len(m3) >= 2)
    trigger_obj: Optional[Dict[str, Any]] = None
    trigger_state = "WAIT_TRIGGER"
    trigger_event_ts: Optional[float] = None
    trigger_mode = "WAIT_BREAK"
    trigger_break_index: Optional[int] = None
    trigger_selection_policy = "ZONE_HIGH_RECENT_HOLD_QUALITY_WITHIN_NEAREST_CLUSTER_BAND_V2159"

    def zone_line(zone: Dict[str, Any]) -> float:
        return float(zone.get("high") or zone.get("price") or 0.0)

    def zone_quality(zone: Dict[str, Any]) -> Tuple[float, float, float, float]:
        return (
            float(len(zone.get("timeframes") or [])),
            float(zone.get("source_count") or 0),
            float(zone.get("score") or 0.0),
            float(zone.get("last_source_ts") or 0.0),
        )

    fired: List[Tuple[float, Tuple[float, float, float, float], Dict[str, Any], str, int]] = []
    for zone in entry_clusters:
        level = zone_line(zone)
        if level <= 0 or len(recent_closes) < 2:
            continue
        break_idx: Optional[int] = None
        # Only the last three completed bars can own a still-valid breakout.
        first_idx = max(1, len(recent_closes) - 4)
        for idx in range(first_idx, len(recent_closes)):
            if recent_closes[idx - 1] <= level < recent_closes[idx]:
                break_idx = idx
        crossed_now = break_idx == len(recent_closes) - 1
        held_after_break = break_idx is not None and all(c > level for c in recent_closes[break_idx:])
        retested_now = (
            any(c > level for c in recent_closes[-5:-1])
            and recent_lows[-1] <= level + max(atr5 * 0.18, current * 0.0008)
            and recent_closes[-1] > level
        )
        early_mode = None
        early_event_ts = None
        early_tolerance = max(atr5 * 0.10, current * 0.0005)
        if len(m1) >= 3:
            c0, c1, c2 = (float(m1[-3]["c"]), float(m1[-2]["c"]), float(m1[-1]["c"]))
            l1, l2 = float(m1[-2]["l"]), float(m1[-1]["l"])
            if c0 <= level < c1 and c2 > level and min(l1, l2) >= level - early_tolerance:
                early_mode = "EARLY_M1_DOUBLE_HOLD"
                early_event_ts = float(m1[-2]["ts"])
        if early_mode is None and len(m3) >= 2:
            c0, c1 = float(m3[-2]["c"]), float(m3[-1]["c"])
            l1 = float(m3[-1]["l"])
            if c0 <= level < c1 and l1 >= level - early_tolerance:
                early_mode = "EARLY_M3_BREAK_HOLD"
                early_event_ts = float(m3[-1]["ts"])
        if crossed_now:
            mode = "COMPLETED_BREAK"
            event_idx = len(recent_closes) - 1
        elif retested_now:
            mode = "COMPLETED_RETEST_HOLD"
            event_idx = len(recent_closes) - 1
        elif held_after_break:
            mode = "COMPLETED_BREAK_HOLD"
            event_idx = int(break_idx)
        elif early_mode is not None and early_event_ts is not None:
            mode = early_mode
            event_idx = -1
        else:
            continue
        event_ts = float(early_event_ts if mode.startswith("EARLY_") else recent_rows[event_idx]["ts"])
        fired.append((event_ts, zone_quality(zone), zone, mode, event_idx))

    if fired:
        fired.sort(key=lambda item: (item[0], item[1]), reverse=True)
        trigger_event_ts, _, trigger_obj, trigger_mode, trigger_break_index = fired[0]
        trigger_state = "TRIGGER_FIRED"
    else:
        above = [z for z in entry_clusters if zone_line(z) >= current * 0.999]
        if above:
            nearest = min(zone_line(z) for z in above)
            selection_band = max(max(atr5, atr15 * 0.6) * 0.22, current * 0.0012)
            near_band = [z for z in above if zone_line(z) <= nearest + selection_band]
            trigger_obj = max(near_band, key=lambda z: (zone_quality(z), -abs(zone_line(z) - current)))
            trigger_state = "WAIT_TRIGGER"
        else:
            below = [z for z in entry_clusters if zone_line(z) < current]
            if below:
                trigger_obj = max(below, key=lambda z: zone_line(z))
                trigger_state = "TRIGGER_PASSED"
                trigger_mode = "OLD_LEVEL_ALREADY_CONSUMED"
    if trigger_obj is None:
        base.update({
            "state": "NO_TRIGGER_STRUCTURE", "decision_key": None, "plan_key": None,
            "material_diagnosis": {"state": "NO_TRIGGER_STRUCTURE", "owner": "strategy_v2_core_v2161", "candidate_quality_failed": False},
            "structure": {"state": "NO_TRIGGER_STRUCTURE", "frame_counts": counts, "major_trend_axis": major_axis, "setup_trend_axis": setup_axis},
        })
        base["prediction"] = _prediction(row, base["structure"])
        return base

    trigger = float(trigger_obj.get("high") or trigger_obj["price"])
    support_candidates = [z for z in support_clusters if float(z["high"]) < trigger and (int(z.get("source_count") or 0) >= 2 or "h1" in (z.get("timeframes") or []))]
    support = max(support_candidates, key=lambda z: float(z["price"]), default=None)
    if support is None:
        structure = {"state": "NO_INVALID_STRUCTURE", "trigger": trigger, "trigger_state": trigger_state, "frame_counts": counts, "major_trend_axis": major_axis, "setup_trend_axis": setup_axis}
        base.update({"state": "NO_INVALID_STRUCTURE", "decision_key": None, "plan_key": None, "material_diagnosis": {"state": "NO_INVALID_STRUCTURE", "owner": "strategy_v2_core_v2161", "candidate_quality_failed": False}, "structure": structure})
        base["prediction"] = _prediction(row, structure)
        return base

    invalid_buffer = max(atr30 * 0.22, atr1h * 0.10, trigger * 0.0008)
    invalid = float(support["low"]) - invalid_buffer
    target_floor = max(trigger, current)
    targets = [z for z in target_clusters if float(z["low"]) > target_floor * 1.00001]
    if not targets:
        structure = {"state": "NO_REACHABLE_T1", "trigger": trigger, "execution_invalid": invalid, "trigger_state": trigger_state, "frame_counts": counts, "major_trend_axis": major_axis, "setup_trend_axis": setup_axis}
        base.update({"state": "NO_REACHABLE_T1", "decision_key": None, "plan_key": None, "material_diagnosis": {"state": "NO_REACHABLE_T1", "owner": "strategy_v2_core_v2161", "candidate_quality_failed": False}, "structure": structure})
        base["prediction"] = _prediction(row, structure)
        return base
    targets.sort(key=lambda z: float(z["low"]))
    t1 = float(targets[0]["low"])
    t2 = float(targets[1]["low"]) if len(targets) > 1 else None
    reference = current if trigger_state == "TRIGGER_FIRED" else trigger
    if not (invalid < reference < t1):
        structure_state = "PRICE_ORDER_INVALID"
    elif trigger_state == "WAIT_TRIGGER":
        structure_state = "WAIT_TRIGGER"
    elif trigger_state == "TRIGGER_PASSED":
        structure_state = "TRIGGER_PASSED"
    else:
        structure_state = "STRUCTURE_READY"

    risk_pct = (reference - invalid) / reference * 100.0
    room_pct = (t1 - reference) / reference * 100.0
    rr = room_pct / risk_pct if risk_pct > 0 else None
    fraction = max(0.0, (current - trigger) / max(t1 - trigger, 1e-12))
    # v2166 candidate-quality axis: after early detection is enabled, a remaining
    # non-retest entry that already consumed a large part of T1 and arrived after
    # an outsized 15m/30m run is held for a retest instead of chased.
    change_15m = _num(row.get("change_15m"), 0.0) or 0.0
    change_30m = _num(row.get("change_30m"), 0.0) or 0.0
    pre_entry_run_pct_v2166 = max(change_15m, change_30m)
    atr15_pct_v2166 = (atr15 / current * 100.0) if current > 0 else 0.0
    late_run_limit_v2166 = max(2.0, atr15_pct_v2166 * 2.4)
    entry_timing_wait_v2166 = bool(
        trigger_state == "TRIGGER_FIRED"
        and trigger_mode not in {"COMPLETED_RETEST_HOLD"}
        and fraction >= 0.32
        and pre_entry_run_pct_v2166 >= late_run_limit_v2166
    )
    if entry_timing_wait_v2166:
        structure_state = "ENTRY_TIMING_WAIT"
    vol_now = sum(float(r.get("v") or 0.0) for r in m5[-3:]) / 3.0
    vol_base = _median([float(r.get("v") or 0.0) for r in m5[-30:-3]], default=0.0)
    volume_axis = _clip(math.log(max(vol_now, 1e-12) / max(vol_base, 1e-12)) / 1.2, -1.0, 1.0) if vol_base > 0 else 0.0
    trigger_quality = (
        0.75 if trigger_state == "TRIGGER_FIRED" and trigger_mode == "COMPLETED_RETEST_HOLD"
        else 0.62 if trigger_state == "TRIGGER_FIRED" and trigger_mode == "EARLY_M1_DOUBLE_HOLD"
        else 0.58 if trigger_state == "TRIGGER_FIRED" and trigger_mode == "EARLY_M3_BREAK_HOLD"
        else 0.60 if trigger_state == "TRIGGER_FIRED" and trigger_mode == "COMPLETED_BREAK_HOLD"
        else 0.45 if trigger_state == "TRIGGER_FIRED"
        else -0.15 if trigger_state == "WAIT_TRIGGER"
        else -0.65
    )
    last_bar=m5[-1];bar_range=max(float(last_bar["h"])-float(last_bar["l"]),1e-12)
    breakout_body_pct=abs(float(last_bar["c"])-float(last_bar["o"]))/bar_range*100.0
    breakout_upper_wick_pct=(float(last_bar["h"])-max(float(last_bar["o"]),float(last_bar["c"])))/bar_range*100.0
    breakout_close_position_pct=(float(last_bar["c"])-float(last_bar["l"]))/bar_range*100.0
    trigger_hold_above_pct=(float(last_bar["c"])-trigger)/trigger*100.0 if trigger>0 else None
    atr_pct={"m5":atr5/current*100.0,"m15":atr15/current*100.0,"m30":atr30/current*100.0,"h1":atr1h/current*100.0,"h2":atr2h/current*100.0,"h4":atr4h/current*100.0}
    tr_now=_median([float(r["h"])-float(r["l"]) for r in m5[-5:]],default=0.0)
    tr_base=_median([float(r["h"])-float(r["l"]) for r in m5[-30:-5]],default=0.0)
    short_atr_expansion_ratio=(tr_now/tr_base) if tr_base>0 else None
    invalid_noise_ref=max(atr_pct["m30"],atr_pct["h1"]*0.55,0.000001)
    target_atr_ref=max(atr_pct["h2"],atr_pct["h4"]*0.55,0.000001)
    invalid_noise_multiple=risk_pct/invalid_noise_ref if invalid_noise_ref>0 else None
    target_atr_multiple=room_pct/target_atr_ref if target_atr_ref>0 else None
    plan_seed = {
        "ticker": ticker, "trigger": round(trigger, 12), "invalid": round(invalid, 12), "t1": round(t1, 12),
        "t2": round(t2, 12) if t2 else None, "trigger_state": trigger_state,
        "trigger_event_ts": trigger_event_ts, "h4_ts": float(h4[-1]["ts"]), "m5_ts": float(m5[-1]["ts"]),
    }
    plan_key = "v2149-plan:" + _plan_hash(plan_seed)
    structure = {
        "schema": "combined_v2_structure_v2149", "state": structure_state, "reference_entry": round(reference, 12),
        "current_price": round(current, 12), "trigger": round(trigger, 12), "trigger_state": trigger_state,
        "trigger_mode": trigger_mode, "trigger_event_ts": trigger_event_ts,
        "trigger_selection_policy_v2159": trigger_selection_policy,
        "trigger_breakout_line_source_v2159": "entry_zone_high",
        "trigger_valid_hold_bars_v2159": 3,
        "trigger_early_completed_frames_v2166": ["m1", "m3"],
        "trigger_short_frames_ready_v2166": short_frames_ready_v2166,
        "pretrigger_contract_ready_v2166": True,
        "entry_timing_wait_v2166": entry_timing_wait_v2166,
        "pre_entry_run_pct_v2166": round(pre_entry_run_pct_v2166, 6),
        "late_run_limit_pct_v2166": round(late_run_limit_v2166, 6),
        "trigger_break_index_v2159": trigger_break_index,
        "trigger_zone_score_v2159": round(float(trigger_obj.get("score") or 0.0), 6),
        "trigger_zone_source_count_v2159": int(trigger_obj.get("source_count") or 0),
        "trigger_zone_timeframes_v2159": list(trigger_obj.get("timeframes") or []),
        "entry_zone_low": round(float(trigger_obj["low"]), 12), "entry_zone_high": round(float(trigger_obj["high"]), 12),
        "execution_invalid": round(invalid, 12), "structural_support": round(float(support["price"]), 12),
        "target_t1": round(t1, 12), "target_t2": round(t2, 12) if t2 else None,
        "risk_pct": round(risk_pct, 6), "t1_room_pct": round(room_pct, 6), "rr_t1": round(rr, 6) if rr is not None else None,
        "entry_fraction_to_t1": round(fraction, 6), "major_trend_axis": round(major_axis, 6),
        "setup_trend_axis": round(setup_axis, 6), "trigger_quality_axis": round(trigger_quality, 6),
        "volume_expansion_axis": round(volume_axis, 6), "frame_counts": counts,
        "breakout_body_pct":round(breakout_body_pct,6),"breakout_upper_wick_pct":round(breakout_upper_wick_pct,6),
        "breakout_close_position_pct":round(breakout_close_position_pct,6),"trigger_hold_above_pct":round(trigger_hold_above_pct,6) if trigger_hold_above_pct is not None else None,
        "trigger_age_sec":round(max(0.0,ts-trigger_event_ts),3) if trigger_event_ts else None,"atr_pct_v2155":{k:round(v,6) for k,v in atr_pct.items()},
        "short_atr_expansion_ratio":round(short_atr_expansion_ratio,6) if short_atr_expansion_ratio is not None else None,
        "invalid_noise_multiple":round(invalid_noise_multiple,6) if invalid_noise_multiple is not None else None,
        "target_atr_multiple":round(target_atr_multiple,6) if target_atr_multiple is not None else None,
        "completed_candles_only": True, "forming_candle_excluded": True,
        "timeframe_contract": {"major": "4h/2h", "setup": "1h/30m", "trigger": "15m/5m", "execution": "1m/quote"},
        "source": "strategy_v2_core_v2168_only", "legacy_structure_used": False,
    }
    prediction = _prediction(row, structure)
    combiner = _combine_structure_prediction(structure, prediction)
    state = str(combiner.get("state") or "ENGINE_ERROR")
    decision_key = None
    if state == "ENTRY_READY" and trigger_event_ts:
        decision_key = f"v2149:{ticker}:{plan_key.split(':')[-1]}:{int(trigger_event_ts * 1000)}"
    base.update({
        "state": state, "decision_key": decision_key, "plan_key": plan_key,
        "material_diagnosis": {"state": "READY" if state in {"ENTRY_READY", "WAIT_TRIGGER", "TRIGGER_PASSED", "PREDICTION_DATA_WAIT", "PREDICTION_UNCLEAR_WAIT", "PREDICTION_RISK_WAIT"} else state, "owner": str(combiner.get("owner") or "strategy_v2_core_v2161"), "candidate_quality_failed": False, "missing": []},
        "structure": structure, "prediction": prediction, "decision_combiner": combiner,
        "execution_policy": {
            "schema": "combined_v2_execution_policy_v2149", "actual_price_required": True,
            "fresh_spread_slippage_required": True, "after_cost_reward_must_be_positive": True,
            "entry_must_remain_in_first_half_to_t1": True, "fixed_legacy_rr_room_chase_thresholds_used": False,
            "prediction_recomputed_in_paper": False, "decision_combiner_active": True,
            "prediction_used_in_strategy": True,
        },
    })
    return base


def compact_combined_v2_contract(value: Any) -> Dict[str, Any]:
    if not isinstance(value, dict):
        return {}
    structure = value.get("structure") if isinstance(value.get("structure"), dict) else {}
    prediction = value.get("prediction") if isinstance(value.get("prediction"), dict) else {}
    combiner = value.get("decision_combiner") if isinstance(value.get("decision_combiner"), dict) else {}
    material = value.get("material_diagnosis") if isinstance(value.get("material_diagnosis"), dict) else {}
    evidence = prediction.get("evidence") if isinstance(prediction.get("evidence"), dict) else {}
    return {
        "schema": "combined_v2_trade_contract_v2155_compact", "version": value.get("version"), "generation": value.get("generation"), "prediction_model_generation": value.get("prediction_model_generation"),
        "state": value.get("state"), "ticker": value.get("ticker"), "evaluated_ts": value.get("evaluated_ts"),
        "decision_key": value.get("decision_key"), "plan_key": value.get("plan_key"),
        "material_diagnosis": {k: material.get(k) for k in ("state", "owner", "missing", "candidate_quality_failed")},
        "structure": {k: structure.get(k) for k in (
            "state", "reference_entry", "current_price", "trigger", "trigger_state", "trigger_mode", "trigger_event_ts",
            "entry_zone_low", "entry_zone_high", "execution_invalid", "structural_support", "target_t1", "target_t2",
            "risk_pct", "t1_room_pct", "rr_t1", "entry_fraction_to_t1", "major_trend_axis", "setup_trend_axis",
            "trigger_quality_axis", "volume_expansion_axis", "frame_counts", "completed_candles_only", "forming_candle_excluded",
            "timeframe_contract", "source", "legacy_structure_used", "breakout_body_pct", "breakout_upper_wick_pct", "breakout_close_position_pct", "trigger_hold_above_pct", "trigger_age_sec", "atr_pct_v2155", "short_atr_expansion_ratio", "invalid_noise_multiple", "target_atr_multiple",
            "trigger_selection_policy_v2159", "trigger_breakout_line_source_v2159", "trigger_valid_hold_bars_v2159",
            "trigger_break_index_v2159", "trigger_zone_score_v2159", "trigger_zone_source_count_v2159", "trigger_zone_timeframes_v2159"
        )},
        "prediction": {k: prediction.get(k) for k in (
            "state", "p_t1_before_invalid", "p_invalid_before_t1", "p_no_touch_6h", "directional_edge",
            "structural_ev_pct", "continuation_score", "uncertainty_margin", "continuation_lower_bound",
            "continuation_upper_bound", "expected_mfe_pct_6h", "expected_mae_pct_6h", "input_coverage_pct",
            "model_confidence_pct", "probability_is_calibrated", "probability_used_in_final_decision_v2159",
            "probability_role_v2159", "market_risk_direct_duplicate_removed_v2159",
            "target_reachability_factor_v2159", "effective_t1_room_pct_v2159", "p_t1_raw_proxy_v2159",
            "prediction_used_in_final_decision", "decision_combiner_active", "calibration_generation", "decision_reason",
            "decision_detail_reasons", "decision_components", "entry_timing_diagnosis", "prediction_model_generation", "required_input_coverage_pct_v2155"
        )},
        "prediction_evidence": {k: evidence.get(k) for k in ("axes", "ready_axes", "missing_axes", "stale_axes_v2155", "input_coverage_pct", "required_input_coverage_pct_v2155", "direction_agreement_pct", "combined_axis", "axis_dispersion", "contradiction_axes", "contradiction_ratio", "critical_negative_axes", "fake_break_risk", "groups", "input_connections_v2155", "owner_connection_summary_v2155", "required_input_failures_v2155", "all_required_inputs_connected_v2155", "zero_fill_used_v2155")},
        "decision_combiner": {k: combiner.get(k) for k in ("state", "entry_eligible", "owner", "reason", "structure_state", "prediction_state", "prediction_recomputed_in_paper", "candidate_preserved")},
        "execution_policy": value.get("execution_policy"),
        "legacy_structure_used": False, "legacy_entry_gate_used": False,
        "decision_combiner_active": True, "candidate_preserved": True, "auto_buy": False,
    }


# =============================================================================
# v2156 single input-truth contract.
# Diagnostic/classification repair only for STRUCTURE_READY candidates: the
# prediction formula, weights, thresholds and model generation remain v2155.
# Structural prerequisites that do not yet exist are WAIT_STRUCTURE, never a
# fake source disconnection. Every axis exposes current/prior/delta/age/reason.
# =============================================================================
_V2156_ORIG_DIRECT_INPUT_AXES = _direct_input_axes
_V2156_ORIG_PREDICTION = _prediction
_V2156_ORIG_COMPACT = compact_combined_v2_contract
_V2156_STRUCTURE_PENDING_STATES = {"NO_TRIGGER_STRUCTURE", "NO_INVALID_STRUCTURE", "NO_REACHABLE_T1"}
_V2156_STRUCTURE_DEPENDENT_AXES = {"trigger_quality", "breakout_reaction", "volatility_fit", "entry_timing"}


def _v2156_neutral_reason(score: Optional[float], raw: Any, delta: Any = None) -> Optional[str]:
    value = _num(score)
    if value is None or abs(value) > 0.12:
        return None
    d = _num(delta)
    if d is not None and abs(d) <= 1e-9:
        return "STABLE_DELTA_ZERO"
    if isinstance(raw, str) and raw.upper() in {"FLAT", "MIXED", "NORMAL"}:
        return "SOURCE_FLAT_OR_BALANCED"
    if isinstance(raw, dict):
        nums = [_num(v) for v in raw.values()]
        nums = [float(v) for v in nums if v is not None]
        if nums and any(v > 0 for v in nums) and any(v < 0 for v in nums):
            return "MIXED_COMPONENTS_CANCELLED"
        if nums and max(abs(v) for v in nums) <= 1e-9:
            return "ALL_COMPONENTS_ZERO"
    return "BALANCED_LEVEL"


def _v2156_truth_for_axis(row: Dict[str, Any], axis: str, raw: Any) -> Dict[str, Any]:
    feature = _nested(row, "feature_momentum_context_v2130")
    market = _nested(row, "global_market_context_v2130", "market_context_v2130")
    orderflow = _nested(row, "orderflow_continuation_v2130")
    current = raw
    prior = None
    delta = None
    source_state = None
    if axis == "relative_strength_velocity":
        truth = feature.get("relative_strength_change_truth_v2156") if isinstance(feature.get("relative_strength_change_truth_v2156"), dict) else {}
        current, prior, delta, source_state = truth.get("current"), truth.get("prior"), truth.get("delta"), truth.get("state")
    elif axis == "money_flow_velocity":
        truth = feature.get("money_flow_change_truth_v2156") if isinstance(feature.get("money_flow_change_truth_v2156"), dict) else {}
        current, prior, delta, source_state = truth.get("current"), truth.get("prior"), truth.get("delta"), truth.get("state")
    elif axis == "market_breadth_velocity":
        truth_all = market.get("component_truth_v2156") if isinstance(market.get("component_truth_v2156"), dict) else {}
        truth = truth_all.get("breadth") if isinstance(truth_all.get("breadth"), dict) else {}
        current, prior, delta, source_state = truth.get("current"), truth.get("prior"), truth.get("delta"), truth.get("state")
    elif axis == "btc_direction":
        truth_all = market.get("component_truth_v2156") if isinstance(market.get("component_truth_v2156"), dict) else {}
        truth = truth_all.get("btc") if isinstance(truth_all.get("btc"), dict) else {}
        current = {k: truth.get(k) for k in ("direction", "change_1m", "change_3m", "change_5m", "source")}
        source_state = truth.get("state")
    elif axis == "external_market":
        truth_all = market.get("component_truth_v2156") if isinstance(market.get("component_truth_v2156"), dict) else {}
        truth = truth_all.get("external") if isinstance(truth_all.get("external"), dict) else {}
        current = {k: truth.get(k) for k in ("direction", "change_1m", "change_3m", "change_5m", "source", "age_sec")}
        source_state = truth.get("state")
    elif axis == "market_risk":
        truth_all = market.get("component_truth_v2156") if isinstance(market.get("component_truth_v2156"), dict) else {}
        truth = truth_all.get("risk") if isinstance(truth_all.get("risk"), dict) else {}
        current = truth or raw
    elif axis == "market_liquidity_regime":
        truth_all = market.get("component_truth_v2156") if isinstance(market.get("component_truth_v2156"), dict) else {}
        truth = truth_all.get("liquidity") if isinstance(truth_all.get("liquidity"), dict) else {}
        current = truth or raw
        prior = truth.get("concentration_prior")
        delta = truth.get("concentration_delta")
    elif axis == "orderflow_velocity":
        truth = orderflow.get("change_truth_v2156") if isinstance(orderflow.get("change_truth_v2156"), dict) else {}
        current = {k: truth.get(k) for k in ("buy_ratio", "buy_sustain", "ask_wall", "bid_wall", "spread")}
        delta_values = []
        for item in current.values():
            if isinstance(item, dict) and _num(item.get("delta")) is not None:
                delta_values.append(float(item.get("delta")))
        delta = sum(delta_values) / len(delta_values) if delta_values else None
        source_state = truth.get("state")
    return {"current": current, "prior": prior, "delta": delta, "source_state": source_state}


def _direct_input_axes(row: Dict[str, Any], structure: Dict[str, Any]) -> Dict[str, Any]:  # type: ignore[override]
    evidence = _V2156_ORIG_DIRECT_INPUT_AXES(row, structure)
    axes = evidence.get("axes") if isinstance(evidence.get("axes"), dict) else {}
    conns = evidence.get("input_connections_v2155") if isinstance(evidence.get("input_connections_v2155"), dict) else {}
    structure_state = str(structure.get("state") or "DATA_MISSING")
    wait_axes: List[str] = []
    neutral_counts: Dict[str, int] = {}
    actual_missing: List[str] = []
    stale: List[str] = []
    wiring_disconnected: List[str] = []

    for axis, meta in conns.items():
        if not isinstance(meta, dict):
            continue
        meta["connection_schema"] = "prediction_input_connection_truth_v2156"
        meta["applicability"] = "APPLICABLE"
        meta["wait_reason"] = None
        owner = str(meta.get("owner") or "").strip()
        source = str(meta.get("source") or "").strip()
        meta["wiring_connected"] = bool(owner and source)
        if not meta["wiring_connected"]:
            wiring_disconnected.append(axis)
        truth = _v2156_truth_for_axis(row, axis, meta.get("raw"))
        meta["current"] = truth.get("current")
        meta["prior"] = truth.get("prior")
        meta["delta"] = truth.get("delta")
        meta["source_state_v2156"] = truth.get("source_state")

        if structure_state in _V2156_STRUCTURE_PENDING_STATES and axis in _V2156_STRUCTURE_DEPENDENT_AXES:
            meta["state"] = "WAIT_STRUCTURE"
            meta["applicability"] = "PENDING_COMPLETE_STRUCTURE"
            meta["wait_reason"] = structure_state
            meta["used_in_prediction"] = False
            meta["score"] = None
            axes[axis] = None
            wait_axes.append(axis)
            meta["neutral_reason"] = None
            continue

        state = str(meta.get("state") or "MISSING")
        if state == "MISSING":
            actual_missing.append(axis)
        elif state == "STALE":
            stale.append(axis)
        nr = _v2156_neutral_reason(_num(meta.get("score")), meta.get("current"), meta.get("delta"))
        meta["neutral_reason"] = nr
        if nr:
            neutral_counts[nr] = neutral_counts.get(nr, 0) + 1

    required_applicable = [m for m in conns.values() if isinstance(m, dict) and m.get("required") and m.get("applicability") == "APPLICABLE"]
    required_ready = [m for m in required_applicable if m.get("state") == "READY"]
    all_applicable = [m for m in conns.values() if isinstance(m, dict) and m.get("applicability") == "APPLICABLE"]
    all_ready = [m for m in all_applicable if m.get("state") == "READY"]
    required_failures = [axis for axis, m in conns.items() if isinstance(m, dict) and m.get("required") and m.get("applicability") == "APPLICABLE" and m.get("state") in {"MISSING", "STALE"}]

    evidence["schema"] = "combined_v2_prediction_evidence_v2156"
    evidence["input_connections_v2156"] = conns
    evidence["input_connections_v2155"] = conns  # compatibility reader, same canonical contract
    evidence["structure_state_v2156"] = structure_state
    evidence["structure_wait_axes_v2156"] = wait_axes
    evidence["actual_missing_axes_v2156"] = actual_missing
    evidence["stale_axes_v2156"] = stale
    evidence["wiring_disconnected_axes_v2156"] = wiring_disconnected
    evidence["neutral_reason_counts_v2156"] = neutral_counts
    evidence["all_28_axes_present_v2156"] = len(conns) == 28
    evidence["all_input_wiring_connected_v2156"] = not wiring_disconnected and len(conns) == 28
    evidence["all_applicable_required_inputs_ready_v2156"] = not required_failures
    evidence["required_input_failures_v2156"] = required_failures
    evidence["required_input_failures_v2155"] = required_failures
    evidence["missing_axes"] = actual_missing
    evidence["stale_axes_v2155"] = stale
    evidence["ready_axes"] = len(all_ready)
    evidence["input_coverage_pct"] = round(len(all_ready) / max(1, len(all_applicable)) * 100.0, 3)
    required_pct = round(len(required_ready) / max(1, len(required_applicable)) * 100.0, 3)
    evidence["required_input_coverage_pct_v2156"] = required_pct
    evidence["required_input_coverage_pct_v2155"] = required_pct
    evidence["all_required_inputs_connected_v2155"] = not required_failures
    evidence["zero_fill_used_v2156"] = False
    evidence["groups_valid_for_prediction_v2156"] = structure_state not in _V2156_STRUCTURE_PENDING_STATES
    return evidence


def _prediction(row: Dict[str, Any], structure: Dict[str, Any]) -> Dict[str, Any]:  # type: ignore[override]
    structure_state = str(structure.get("state") or "DATA_MISSING")
    if structure_state in _V2156_STRUCTURE_PENDING_STATES:
        evidence = _direct_input_axes(row, structure)
        return {
            "schema": "combined_v2_continuation_prediction_v2161",
            "state": "WAIT_STRUCTURE",
            "prediction_model_generation": PREDICTION_MODEL_GENERATION,
            "p_t1_before_invalid": None, "p_invalid_before_t1": None, "p_no_touch_6h": None,
            "directional_edge": None, "structural_ev_pct": None, "continuation_score": None,
            "input_coverage_pct": evidence.get("input_coverage_pct"),
            "required_input_coverage_pct_v2155": evidence.get("required_input_coverage_pct_v2155"),
            "required_input_coverage_pct_v2156": evidence.get("required_input_coverage_pct_v2156"),
            "model_confidence_pct": 0.0, "probability_is_calibrated": False,
            "prediction_used_in_final_decision": True, "decision_combiner_active": True,
            "decision_reason": "구조계약이 완성되기 전이라 구조 의존 입력은 계산 대기",
            "decision_detail_reasons": [f"구조 대기: {structure_state}", "자료 연결 실패가 아니라 Trigger·Invalid·T1 구조 완성 대기"],
            "decision_components": {"structure_wait": True, "actual_input_missing": bool(evidence.get("actual_missing_axes_v2156"))},
            "entry_timing_diagnosis": _entry_timing_diagnosis(structure),
            "evidence": evidence, "auto_buy": False,
        }
    result = _V2156_ORIG_PREDICTION(row, structure)
    if isinstance(result, dict):
        result["schema"] = "combined_v2_continuation_prediction_v2161"
        result["required_input_coverage_pct_v2156"] = result.get("required_input_coverage_pct_v2155")
    return result


def compact_combined_v2_contract(value: Any) -> Dict[str, Any]:  # type: ignore[override]
    out = _V2156_ORIG_COMPACT(value)
    if not isinstance(value, dict) or not isinstance(out, dict):
        return out
    prediction = value.get("prediction") if isinstance(value.get("prediction"), dict) else {}
    evidence = prediction.get("evidence") if isinstance(prediction.get("evidence"), dict) else {}
    out["schema"] = "combined_v2_trade_contract_v2161_compact"
    out["version"] = value.get("version")
    out_pred = out.get("prediction") if isinstance(out.get("prediction"), dict) else {}
    out_pred["required_input_coverage_pct_v2156"] = prediction.get("required_input_coverage_pct_v2156")
    out["prediction"] = out_pred
    out_ev = out.get("prediction_evidence") if isinstance(out.get("prediction_evidence"), dict) else {}
    full_conns = evidence.get("input_connections_v2156") if isinstance(evidence.get("input_connections_v2156"), dict) else {}
    slim = {}
    for axis, meta in full_conns.items():
        if not isinstance(meta, dict):
            continue
        slim[axis] = {k: meta.get(k) for k in (
            "group", "owner", "source", "state", "score", "age_sec", "ttl_sec", "weight",
            "required", "used_in_prediction", "applicability", "wait_reason", "neutral_reason", "wiring_connected"
        )}
    # Compatibility reader receives one slim canonical connection map. Raw
    # current/prior/delta truth stays in Strategy status, not each candidate row.
    out_ev["input_connections_v2155"] = slim
    out_ev.pop("input_connections_v2156", None)
    for key in ("structure_state_v2156", "structure_wait_axes_v2156", "actual_missing_axes_v2156",
                "wiring_disconnected_axes_v2156", "neutral_reason_counts_v2156", "all_28_axes_present_v2156",
                "all_input_wiring_connected_v2156", "all_applicable_required_inputs_ready_v2156",
                "required_input_failures_v2156", "required_input_coverage_pct_v2156", "zero_fill_used_v2156"):
        out_ev[key] = evidence.get(key)
    out["prediction_evidence"] = out_ev
    structure = value.get("structure") if isinstance(value.get("structure"), dict) else {}
    out_structure = out.get("structure") if isinstance(out.get("structure"), dict) else {}
    for key in (
        "trigger_early_completed_frames_v2166", "trigger_short_frames_ready_v2166",
        "pretrigger_contract_ready_v2166", "entry_timing_wait_v2166",
        "pre_entry_run_pct_v2166", "late_run_limit_pct_v2166"
    ):
        out_structure[key] = structure.get(key)
    out["structure"] = out_structure
    out["runtime_identity_v2167"] = value.get("runtime_identity_v2167") if isinstance(value.get("runtime_identity_v2167"), dict) else None
    out["schema"] = "combined_v2_trade_contract_v2167_compact"
    return out

# v2171 final seals: V2170 +0.341 gate is rolled back; structure score remains diagnostic.
QUALITY_STRUCTURE_GATE_ACTIVE_V2171 = False
V2170_FAILED_GATE_ROLLED_BACK_V2171 = True



# =============================================================================
# v2188 prediction-primary order repair.
# Rising prediction chooses the candidate first. Structure is retained as the
# sealed entry/exit map when available and becomes a bounded fallback contract
# when a high-quality prediction has no usable invalid or target.
# =============================================================================
VERSION = "strategy_v2_core_v2172"
BUILD_LABEL = "v2188_prediction_primary_structure_execution_contract_2026-07-24"
PREDICTION_MODEL_GENERATION = "FULL_INPUT_V2188_PRIMARY"
V2188_EMERGENCY_INVALID_PCT = 2.0
V2188_PRIMARY_GROUP_WEIGHTS = {
    "market_context": 0.22 / 0.78,
    "participation": 0.28 / 0.78,
    "trigger_flow": 0.28 / 0.78,
}
V2188_STRUCTURE_ONLY_AXES = {
    "major_trend", "setup_trend", "location_hold", "price_reaction",
    "volatility_fit", "entry_timing", "trigger_quality", "breakout_reaction",
}
_V2188_BASE_BUILD = build_combined_v2_contract
_V2188_BASE_COMPACT = compact_combined_v2_contract
_V2188_BASE_DIRECT_INPUTS = _V2156_ORIG_DIRECT_INPUT_AXES


def _v2188_compact_value(value: Any, depth: int = 0) -> Any:
    if depth >= 3:
        if isinstance(value, (dict, list, tuple)):
            return None
        return value
    if isinstance(value, dict):
        out = {}
        for key in list(value.keys())[:10]:
            compacted = _v2188_compact_value(value.get(key), depth + 1)
            if compacted is not None:
                out[str(key)] = compacted
        return out
    if isinstance(value, (list, tuple)):
        return [_v2188_compact_value(x, depth + 1) for x in list(value)[:12]]
    if isinstance(value, str):
        return value[:120]
    if isinstance(value, float):
        return round(value, 8) if math.isfinite(value) else None
    return value


def _v2188_weighted_group(evidence: Dict[str, Any], group: str) -> Dict[str, Any]:
    axes = evidence.get("axes") if isinstance(evidence.get("axes"), dict) else {}
    conns = evidence.get("input_connections_v2155") if isinstance(evidence.get("input_connections_v2155"), dict) else {}
    ready = []
    total = 0
    required_failures = []
    for axis, meta in conns.items():
        if not isinstance(meta, dict) or str(meta.get("group") or "") != group or axis in V2188_STRUCTURE_ONLY_AXES:
            continue
        total += 1
        state = str(meta.get("state") or "MISSING")
        score = _num(axes.get(axis))
        weight = max(0.0001, _num(meta.get("weight"), 1.0) or 1.0)
        if meta.get("required") is True and state != "READY":
            required_failures.append(axis)
        if state == "READY" and score is not None:
            ready.append((axis, float(score), weight))
    den = sum(x[2] for x in ready)
    score = sum(x[1] * x[2] for x in ready) / den if den > 0 else None
    return {
        "score": round(score, 6) if score is not None else None,
        "coverage_pct": round(len(ready) / max(1, total) * 100.0, 3),
        "ready": [x[0] for x in ready],
        "required_failures": required_failures,
        "total_axes": total,
    }


def _v2188_primary_prediction(row: Dict[str, Any], structure: Dict[str, Any]) -> Dict[str, Any]:
    # Use the original detailed input owner. Structure-derived axes stay visible
    # but are not allowed to veto candidate selection.
    evidence = _V2188_BASE_DIRECT_INPUTS(row, structure)
    truth = _direct_input_axes(row, structure)
    base_conns = evidence.get("input_connections_v2155") if isinstance(evidence.get("input_connections_v2155"), dict) else {}
    truth_conns = truth.get("input_connections_v2155") if isinstance(truth.get("input_connections_v2155"), dict) else {}
    for axis, meta in base_conns.items():
        if not isinstance(meta, dict):
            continue
        tmeta = truth_conns.get(axis) if isinstance(truth_conns.get(axis), dict) else {}
        for key in ("current", "prior", "delta", "source_state_v2156", "neutral_reason", "wiring_connected"):
            if key in tmeta:
                meta[key] = tmeta.get(key)
    evidence["input_connections_v2155"] = base_conns
    groups = {name: _v2188_weighted_group(evidence, name) for name in V2188_PRIMARY_GROUP_WEIGHTS}
    market = _num(groups["market_context"].get("score"))
    participation = _num(groups["participation"].get("score"))
    trigger = _num(groups["trigger_flow"].get("score"))
    missing_groups = [name for name, meta in groups.items() if _num(meta.get("coverage_pct"), 0.0) < 60.0 or _num(meta.get("score")) is None]
    required_failures = sorted({axis for meta in groups.values() for axis in (meta.get("required_failures") or [])})
    total_axes = sum(int(meta.get("total_axes") or 0) for meta in groups.values())
    ready_axes = sum(len(meta.get("ready") or []) for meta in groups.values())
    coverage = ready_axes / max(1, total_axes)

    all_axes = evidence.get("axes") if isinstance(evidence.get("axes"), dict) else {}
    primary_axes = {}
    weights = {}
    for axis, meta in base_conns.items():
        if not isinstance(meta, dict) or axis in V2188_STRUCTURE_ONLY_AXES:
            continue
        group = str(meta.get("group") or "")
        if group not in V2188_PRIMARY_GROUP_WEIGHTS:
            continue
        score = _num(all_axes.get(axis))
        if str(meta.get("state") or "") == "READY" and score is not None:
            primary_axes[axis] = float(score)
            weights[axis] = max(0.0001, _num(meta.get("weight"), 1.0) or 1.0)
    combined_den = sum(weights.values())
    combined = sum(primary_axes[k] * weights[k] for k in primary_axes) / combined_den if combined_den > 0 else None
    contradiction_axes = []
    if combined is not None:
        contradiction_axes = [k for k, v in primary_axes.items() if (combined >= 0 and v < -0.12) or (combined < 0 and v > 0.12)]
    contradiction = len(contradiction_axes) / max(1, len(primary_axes))
    dispersion = None
    if combined is not None and combined_den > 0:
        dispersion = math.sqrt(sum(weights[k] * ((primary_axes[k] - combined) ** 2) for k in primary_axes) / combined_den)
    fake_keys = ("volume_response", "relative_strength_level", "money_flow_level", "momentum_level", "buy_ratio_level", "buy_sustain_level", "ask_wall_pressure", "sell_pressure", "micro_acceleration")
    fake_values = [primary_axes[k] for k in fake_keys if k in primary_axes]
    weak_fraction = sum(1 for v in fake_values if v < -0.12) / max(1, len(fake_values))
    negative_pressure = sum(max(0.0, -v) for v in fake_values) / max(1, len(fake_values))
    fake_break = _clip(0.58 * weak_fraction + 0.42 * negative_pressure, 0.0, 1.0)

    if missing_groups or required_failures or coverage < 0.72 or any(x is None for x in (market, participation, trigger)):
        state = "DATA_MISSING"
        score = None
        reason = "상승예측 핵심자료가 부족해 실행만 대기"
    else:
        group_floor = min(float(market), float(participation), float(trigger))
        interaction = 0.28 * group_floor if group_floor >= 0 else 0.58 * group_floor
        score = (
            V2188_PRIMARY_GROUP_WEIGHTS["market_context"] * float(market)
            + V2188_PRIMARY_GROUP_WEIGHTS["participation"] * float(participation)
            + V2188_PRIMARY_GROUP_WEIGHTS["trigger_flow"] * float(trigger)
            + interaction - 0.72 * fake_break - 0.34 * contradiction
        )
        if score > 0.0 and participation > 0.0 and trigger > 0.0:
            state = "CONTINUATION_FAVORED"
            reason = "거래대금·상대강도·매수지속·체결 흐름이 상승 우위"
        elif score < 0.0 and participation <= 0.0 and trigger <= 0.0:
            state = "INVALID_RISK_FAVORED"
            reason = "상승점수와 현재 매수·체결 흐름이 함께 약함"
        else:
            state = "CONTINUATION_UNCLEAR"
            reason = "상승점수 또는 현재 매수·체결 흐름이 한쪽으로 모이지 않음"

    evidence["schema"] = "combined_v2_prediction_evidence_v2188"
    evidence["groups_v2188_primary"] = groups
    evidence["primary_axes_v2188"] = primary_axes
    evidence["structure_axes_diagnostic_only_v2188"] = sorted(V2188_STRUCTURE_ONLY_AXES)
    evidence["primary_input_coverage_pct_v2188"] = round(coverage * 100.0, 3)
    evidence["primary_required_failures_v2188"] = required_failures
    evidence["primary_missing_groups_v2188"] = missing_groups
    evidence["primary_contradiction_axes_v2188"] = contradiction_axes
    evidence["primary_contradiction_ratio_v2188"] = round(contradiction, 6)
    evidence["primary_fake_break_risk_v2188"] = round(fake_break, 6)
    confidence = 0.0 if score is None else _clip(coverage * (1.0 - 0.45 * (dispersion or 0.0)) * (1.0 - 0.50 * contradiction), 0.0, 0.82)
    detail = []
    if required_failures:
        detail.append("필수자료 부족: " + ", ".join(required_failures[:8]))
    if missing_groups:
        detail.append("자료묶음 부족: " + ", ".join(missing_groups))
    if score is not None and score <= 0:
        detail.append("종합 상승점수 양수 아님")
    if participation is not None and participation <= 0:
        detail.append("거래대금·상대강도 약함")
    if trigger is not None and trigger <= 0:
        detail.append("매수지속·체결 약함")
    if not detail:
        detail.append(reason)
    return {
        "schema": "combined_v2_continuation_prediction_v2188",
        "state": state,
        "prediction_model_generation": PREDICTION_MODEL_GENERATION,
        "continuation_score": round(score, 6) if score is not None else None,
        "primary_market_score_v2188": round(market, 6) if market is not None else None,
        "primary_participation_score_v2188": round(participation, 6) if participation is not None else None,
        "primary_trigger_flow_score_v2188": round(trigger, 6) if trigger is not None else None,
        "input_coverage_pct": round(coverage * 100.0, 3),
        "required_input_coverage_pct_v2155": round(coverage * 100.0, 3),
        "model_confidence_pct": round(confidence * 100.0, 3),
        "probability_is_calibrated": False,
        "probability_used_in_final_decision_v2159": False,
        "prediction_used_in_final_decision": True,
        "decision_combiner_active": True,
        "decision_reason": reason,
        "decision_detail_reasons": detail,
        "decision_components": {
            "prediction_primary_v2188": True,
            "structure_veto_active_v2188": False,
            "score_positive": bool(score is not None and score > 0.0),
            "participation_positive": bool(participation is not None and participation > 0.0),
            "trigger_flow_positive": bool(trigger is not None and trigger > 0.0),
        },
        "evidence": evidence,
        "auto_buy": False,
    }


def _v2188_last_completed_event_ts(frames: Dict[str, List[Dict[str, float]]], nowv: float) -> float:
    for tf in ("m5", "m3", "m1", "m15"):
        rows = frames.get(tf) if isinstance(frames.get(tf), list) else []
        if rows and _num(rows[-1].get("ts"), 0.0):
            return float(rows[-1]["ts"])
    return nowv


def build_combined_v2_contract(row: Dict[str, Any], frames: Dict[str, List[Dict[str, float]]], *, now_ts: Optional[float] = None) -> Dict[str, Any]:  # type: ignore[override]
    nowv = float(now_ts if now_ts is not None else time.time())
    contract = _V2188_BASE_BUILD(row, frames, now_ts=nowv)
    if not isinstance(contract, dict):
        return contract
    # Actual source/candle absence remains fail-closed. Structure absence is not
    # source absence and therefore cannot stop the prediction from being scored.
    if str(contract.get("state") or "") == "DATA_MISSING":
        contract["version"] = VERSION
        contract["build"] = BUILD_LABEL
        contract["prediction_model_generation"] = PREDICTION_MODEL_GENERATION
        return contract
    current = _row_price(row)
    if current is None or current <= 0:
        return contract
    ticker = str(contract.get("ticker") or row.get("ticker") or row.get("symbol") or "").upper().replace("KRW-", "").strip()
    original_structure = contract.get("structure") if isinstance(contract.get("structure"), dict) else {}
    structure = dict(original_structure)
    original_state = str(original_structure.get("state") or contract.get("state") or "STRUCTURE_UNKNOWN")
    structure.setdefault("current_price", round(current, 12))
    structure.setdefault("reference_entry", round(current, 12))
    structure.setdefault("major_trend_axis", _num(original_structure.get("major_trend_axis")))
    structure.setdefault("setup_trend_axis", _num(original_structure.get("setup_trend_axis")))
    prediction = _v2188_primary_prediction(row, structure)

    structural_invalid = _num(original_structure.get("execution_invalid"))
    structural_target = _num(original_structure.get("target_t1"))
    structural_trigger = _num(original_structure.get("trigger"))
    invalid_is_structural = bool(structural_invalid is not None and 0 < structural_invalid < current)
    target_is_structural = bool(structural_target is not None and structural_target > current)
    execution_invalid = float(structural_invalid) if invalid_is_structural else current * (1.0 - V2188_EMERGENCY_INVALID_PCT / 100.0)
    target = float(structural_target) if target_is_structural else None
    if invalid_is_structural and target_is_structural:
        entry_mode = "NORMAL_STRUCTURE"
    elif invalid_is_structural and not target_is_structural:
        entry_mode = "TARGETLESS_STRENGTH_EXIT"
    elif not invalid_is_structural and target_is_structural:
        entry_mode = "EMERGENCY_INVALID_2PCT"
    else:
        entry_mode = "PREDICTION_ONLY_FALLBACK"
    event_ts = _v2188_last_completed_event_ts(frames, nowv)
    trigger_event_ts = _num(original_structure.get("trigger_event_ts"), event_ts) or event_ts
    structure.update({
        "schema": "combined_v2_structure_v2188",
        "state": "PREDICTION_PRIMARY_READY" if prediction.get("state") == "CONTINUATION_FAVORED" else original_state,
        "original_structure_state_v2188": original_state,
        "reference_entry": round(current, 12),
        "current_price": round(current, 12),
        "structural_trigger_v2188": structural_trigger,
        "trigger": round(current, 12),
        "trigger_state": "PREDICTION_PRIMARY_TRIGGER",
        "trigger_mode": "PREDICTION_PRIMARY_COMPLETED_BAR",
        "trigger_event_ts": trigger_event_ts,
        "structural_invalid_v2188": structural_invalid,
        "execution_invalid": round(execution_invalid, 12),
        "invalid_mode_v2188": "STRUCTURE_INVALID" if invalid_is_structural else "EMERGENCY_INVALID_2PCT",
        "structural_target_t1_v2188": structural_target,
        "target_t1": round(target, 12) if target is not None else None,
        "target_mode_v2188": "STRUCTURE_TARGET" if target is not None else "TARGETLESS_STRENGTH_EXIT",
        "entry_contract_mode_v2188": entry_mode,
        "targetless_strength_exit_v2188": target is None,
        "risk_pct": round((current - execution_invalid) / current * 100.0, 6),
        "t1_room_pct": round((target - current) / current * 100.0, 6) if target is not None else None,
        "rr_t1": round(((target - current) / (current - execution_invalid)), 6) if target is not None and current > execution_invalid else None,
        "entry_fraction_to_t1": 0.0 if target is not None else None,
        "structure_used_as_entry_exit_map_v2188": True,
        "structure_used_as_candidate_veto_v2188": False,
        "completed_candles_only": True,
        "forming_candle_excluded": True,
    })
    state_map = {
        "DATA_MISSING": "PREDICTION_DATA_WAIT",
        "INVALID_RISK_FAVORED": "PREDICTION_RISK_WAIT",
        "CONTINUATION_UNCLEAR": "PREDICTION_UNCLEAR_WAIT",
    }
    favored = prediction.get("state") == "CONTINUATION_FAVORED"
    final_state = "ENTRY_READY" if favored else state_map.get(str(prediction.get("state") or ""), "PREDICTION_UNCLEAR_WAIT")
    plan_seed = {
        "ticker": ticker,
        "model": PREDICTION_MODEL_GENERATION,
        "event_ts": round(event_ts, 3),
        "entry_mode": entry_mode,
        "original_structure_state": original_state,
    }
    plan_key = "v2188-plan:" + _plan_hash(plan_seed)
    decision_key = f"v2188:{ticker}:{plan_key.split(':')[-1]}:{int(event_ts * 1000)}" if favored else None
    combiner = {
        "schema": "prediction_primary_structure_contract_v2188",
        "state": final_state,
        "entry_eligible": favored,
        "owner": "rise_prediction_primary_v2188",
        "reason": str(prediction.get("decision_reason") or final_state),
        "structure_state": original_state,
        "prediction_state": prediction.get("state"),
        "prediction_first_v2188": True,
        "structure_veto_active_v2188": False,
        "entry_contract_mode_v2188": entry_mode,
        "candidate_preserved": True,
        "prediction_recomputed_in_paper": False,
        "auto_buy": False,
    }
    contract.update({
        "schema": "combined_v2_trade_contract_v2188",
        "version": VERSION,
        "build": BUILD_LABEL,
        "generation": GENERATION,
        "prediction_model_generation": PREDICTION_MODEL_GENERATION,
        "state": final_state,
        "plan_key": plan_key,
        "decision_key": decision_key,
        "structure": structure,
        "prediction": prediction,
        "prediction_evidence": prediction.get("evidence"),
        "decision_combiner": combiner,
        "prediction_first_order_v2188": ["rise_prediction", "structure_entry_exit_contract", "paper_execution_cost"],
        "material_diagnosis": {
            "state": "READY" if favored else final_state,
            "owner": "rise_prediction_primary_v2188",
            "missing": list((prediction.get("evidence") or {}).get("primary_required_failures_v2188") or []),
            "candidate_quality_failed": False,
        },
        "execution_policy": {
            "schema": "combined_v2_execution_policy_v2188",
            "actual_price_required": True,
            "fresh_spread_slippage_required": True,
            "prediction_recomputed_in_paper": False,
            "prediction_used_in_strategy": True,
            "structure_target_optional_v2188": True,
            "structure_invalid_fallback_2pct_v2188": True,
            "targetless_strength_exit_v2188": target is None,
            "auto_buy": False,
        },
        "candidate_preserved": True,
        "auto_buy": False,
    })
    return contract


def compact_combined_v2_contract(value: Any) -> Dict[str, Any]:  # type: ignore[override]
    out = _V2188_BASE_COMPACT(value)
    if not isinstance(value, dict) or not isinstance(out, dict):
        return out
    out["schema"] = "combined_v2_trade_contract_v2188_compact"
    out["version"] = value.get("version")
    out["build"] = value.get("build")
    out["prediction_model_generation"] = value.get("prediction_model_generation")
    out["prediction_first_order_v2188"] = value.get("prediction_first_order_v2188")
    structure = value.get("structure") if isinstance(value.get("structure"), dict) else {}
    out_structure = out.get("structure") if isinstance(out.get("structure"), dict) else {}
    for key in (
        "original_structure_state_v2188", "structural_trigger_v2188", "structural_invalid_v2188",
        "invalid_mode_v2188", "structural_target_t1_v2188", "target_mode_v2188",
        "entry_contract_mode_v2188", "targetless_strength_exit_v2188",
        "structure_used_as_entry_exit_map_v2188", "structure_used_as_candidate_veto_v2188",
    ):
        out_structure[key] = structure.get(key)
    out["structure"] = out_structure
    pred = value.get("prediction") if isinstance(value.get("prediction"), dict) else {}
    out_pred = out.get("prediction") if isinstance(out.get("prediction"), dict) else {}
    for key in ("primary_market_score_v2188", "primary_participation_score_v2188", "primary_trigger_flow_score_v2188"):
        out_pred[key] = pred.get(key)
    out["prediction"] = out_pred
    evidence = pred.get("evidence") if isinstance(pred.get("evidence"), dict) else value.get("prediction_evidence") if isinstance(value.get("prediction_evidence"), dict) else {}
    out_ev = out.get("prediction_evidence") if isinstance(out.get("prediction_evidence"), dict) else {}
    for key in ("groups_v2188_primary", "primary_axes_v2188", "primary_input_coverage_pct_v2188", "primary_required_failures_v2188", "primary_missing_groups_v2188", "primary_contradiction_axes_v2188", "primary_contradiction_ratio_v2188", "primary_fake_break_risk_v2188", "structure_axes_diagnostic_only_v2188"):
        out_ev[key] = evidence.get(key)
    full_conns = evidence.get("input_connections_v2155") if isinstance(evidence.get("input_connections_v2155"), dict) else {}
    slim = out_ev.get("input_connections_v2155") if isinstance(out_ev.get("input_connections_v2155"), dict) else {}
    for axis, meta in full_conns.items():
        if not isinstance(meta, dict):
            continue
        item = slim.get(axis) if isinstance(slim.get(axis), dict) else {}
        for key in ("current", "prior", "delta", "source_state_v2156"):
            if key in meta:
                item[key] = _v2188_compact_value(meta.get(key))
        slim[axis] = item
    out_ev["input_connections_v2155"] = slim
    out["prediction_evidence"] = out_ev
    out["decision_combiner"] = {k: (value.get("decision_combiner") or {}).get(k) for k in ("state", "entry_eligible", "owner", "reason", "structure_state", "prediction_state", "prediction_first_v2188", "structure_veto_active_v2188", "entry_contract_mode_v2188", "candidate_preserved")}
    out["execution_policy"] = value.get("execution_policy")
    out["auto_buy"] = False
    return out

if __name__ == '__main__':
    main()
