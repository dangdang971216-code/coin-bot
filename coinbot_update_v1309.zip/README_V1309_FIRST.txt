v1309: v1308 장부 preflight 실패 수리판.

무엇을 고쳤나:
- V1308_ISSUE_LEDGER_EVENTS.jsonl 에 issue_id가 없어 /gupgrade_bundle이 runtime 적용 전에 중단됨.
- v1309는 pending issue/change ledger schema를 고쳐 preflight PASS되게 함.
- v1308의 no-limit shadow picked-S1 수리와 /gdisk_status 기능은 유지.

변경하지 않은 것:
- 후보식 / trigger / invalid / target / RR / 청산조건 / 자동매수 OFF / 기존 원장.

적용 후:
- Guard: /grelease_verify
- Main: /version_score /flow_map_full /candidate_standard
- Guard disk: /gdisk_status 또는 /gdisk_full
