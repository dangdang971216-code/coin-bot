v1281 운영 자원 정리판. 전략·Paper 매매 로직 변경 없음. 적용 후 /gops_resource_cleanup_v1281 실행.
