from pathlib import Path
import json
m=json.loads(Path('DEPLOY_BUNDLE.json').read_text(encoding='utf-8'))
assert m['schema']=='coinbot_deploy_bundle_v1173'
assert m['version']=='v1173'
assert m['paper']=='paper_bot_v1.040.py'
assert m['workers']['strategy']=='strategy_worker_v1.032.py'
assert 'strategy' not in [k for k in m if k=='strategy']
assert Path(m['paper']).exists() and Path(m['workers']['strategy']).exists()
assert m['auto_buy'] is False
print('PASS')
