from pathlib import Path
s=Path('strategy_worker_v1.032.py').read_text(encoding='utf-8')
p=Path('paper_bot_v1.040.py').read_text(encoding='utf-8')
assert "VERSION = 'strategy_worker_v1.032'" in s
assert "VERSION = 'paper_bot_v1.040'" in p
assert "event_time_owner'] = 'actual_trigger_crossing'" in s
assert "s1_ready_ts_v1173" in s and "transport_ttl_owner_v1173" in s
assert "source':'trigger_occurrence.event_ts + s1_ready_ts_v1173'" in p
assert "STALE_S1_TRANSPORT" in p
assert "actual_trigger_age_sec" in p
assert "paper_final_reaction_proof_enabled']=False" in p  # inherited v1170 baseline, not newly changed
assert "candidate-first scheduler" not in p
assert "one price snapshot per exit sweep" not in p
print('PASS')
