v1455 read-only candidate flow drought map: /candidate_flow and /candidate_flow_detail. No trading rule change. Auto-buy OFF.
