from pathlib import Path
s=Path('strategy_worker_v1.066.py').read_text(encoding='utf-8')
assert "VERSION = 'strategy_worker_v1.066'" in s
assert 'invalid_distance_uses_buffered_stop_line_v1269' in s
assert 'v1270_contract_relative_profit_guard' not in s
