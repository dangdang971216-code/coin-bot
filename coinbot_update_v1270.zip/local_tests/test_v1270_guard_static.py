from pathlib import Path
s=Path('backga_guard_bot_v2_5_248.py').read_text(encoding='utf-8')
assert 'guard_v2.5.248_v1270_contract_relative_profit_guard_2026-07-06' in s
assert '/gledger_v1270' in s
assert 'V1270-CONTRACT-RELATIVE-PROFIT-GUARD' in s
