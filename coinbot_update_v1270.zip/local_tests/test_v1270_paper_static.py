from pathlib import Path
s=Path('paper_bot_v1.082.py').read_text(encoding='utf-8')
assert "VERSION = 'paper_bot_v1.082'" in s
assert "BUILD_LABEL = 'v1270_contract_relative_profit_guard_2026-07-06'" in s
assert 'V1270_RELATIVE_PROFIT_SCHEMA' in s
assert 'swing_contract_relative_profit_guard_v1270' in s
assert 'target_progress_ratio' in s
assert 'fixed_plus_2pct_trigger_used' in s
assert "add_reason_v1122('ENTRY_QUALITY_MATERIAL_BLOCK'" not in s
