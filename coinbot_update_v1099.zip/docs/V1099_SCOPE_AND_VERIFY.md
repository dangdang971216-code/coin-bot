# v1099 Candidate Quality → Paper Funnel Observability

## Root cause

The candidate quality transport repaired in v1098 was working, but the next decision segment was not observable:

1. Strategy S1 hold compaction did not preserve the execution-freshness proof inside the compact swing gate.
2. Paper status counted that missing proof as zero, even though the candidate had already passed the Strategy execution gate.
3. `/candidate_summary` read recent `paper_candidates_latest.jsonl` rows instead of the canonical `paper_s1_hold_cache.json` consumed by Paper.
4. The ops map exposed candidate-select duration but not the S1 → OPEN decision funnel or final hold reasons.
5. The quality audit independently rebuilt a shadow rank instead of reading Strategy-owned rank.

## New canonical observation path

`Strategy quality gate/rank → compact S1 hold with proof → Paper selection funnel → paper_bot_status.pick_stats → Guard ops snapshot → Main/Paper commands`

## Funnel

- S1 detected
- candidate TTL passed
- Strategy execution proof present
- Paper execution freshness passed
- final safety checked
- final safety passed
- loss re-entry passed
- selected
- OPEN committed

## Hold evidence

Each current-cycle hold can expose:

- ticker
- candidate key
- direct decision key
- hold stage
- normalized reason codes and original reasons
- Strategy quality rank and rank score
- actual-entry RR and target room
- spread
- confirmed slippage value and source
- execution freshness proof
- price/micro/orderflow/source ages

## Non-changes

No quality threshold, OPEN cap, cycle cap, trigger, invalid, target, exit contract, forced entry, ledger rewrite, or auto-buy change.

## Server proof

- `/gquality_spine_verify 120`
- `/gworker_state`
- `/gops_refresh`
- `/gquality_open_audit_v1093`
- `/system_map`
- `/ops_focus`
- `/quality_rebuild_status`
- `/quality_open_audit`
- `/pstatus`
- `/candidate_summary`
- `/errorlog`
- `/perror`
