코인봇 v2209
- Review 재시작 후 전체 원장은 1회만 스캔하고 이후 추가행만 증분 처리
- SCANNING 단계·처리행·바이트·진행률 표시
- 오류 발생 시 단계와 원문을 ERROR로 봉인하고 자동 재시도로 지우지 않음
- 완료 snapshot 검증 전 cycle_complete=False, 검증 후에만 PASS
- Paper 성과는 구조·epoch·decision key·건수 검증을 유지하고 45초 초과 경고, 90초 초과에서만 stale FAIL
- 상승예측식·후보·S1·Paper 매매·구조선·청산·원장 변경 없음
- 자동매수 OFF
