Release seed only. Do not overwrite or delete live change_verify, issue, OPEN, CLOSED, trade_log, decision, or exact performance ledgers.
