coinbot_update_v1307

목적:
- v1306 Main 적용 실패 원인 수리: 파일 하단 BOT_VERSION 재정의 제거.
- 디스크 정리 명령은 번호 없는 /gdisk_full 을 기본으로 표시/실행.
- /gdisk_full 입력 즉시 접수 알림을 먼저 보내고, 완료 후 결과판 전송.

변경 없음:
- 후보식, trigger, invalid, target, RR, 청산조건, 자동매수 OFF, 핵심 원장.

적용 후:
1) /gupgrade_bundle
2) /grelease_verify
3) Main: /version_score /flow_map_full /candidate_standard
4) Disk: /gdisk_full 또는 /gdisk_full dry
