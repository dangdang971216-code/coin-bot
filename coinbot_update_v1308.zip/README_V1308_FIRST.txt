v1308: no-limit shadow 0개 오류 수리 + /gdisk_status 추가. 후보식/trigger/invalid/target/RR/청산/자동매수 변경 없음.
