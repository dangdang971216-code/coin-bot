이 폴더의 JSONL은 v1008 배포 증거용 release event 예시다.
서버의 OPEN/CLOSED/trade_log/decision/exact/change_verify/issue_ledger 원장을 덮어쓰거나 삭제하지 않는다.
main v1008은 기존 v870 append writer를 통해 change_verify/issue event만 추가한다.
