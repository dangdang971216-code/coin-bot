v1278: restore good v977/v869 structure spine active. Dynamic structure shadow only. Auto-buy OFF.
