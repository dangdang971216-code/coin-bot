#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
coinbot_ledger_clean_start_v1407.py

목적:
- v1152 명령어/지도/성과 화면으로 복구한 뒤, 복잡해진 라이브 장부를 삭제하지 않고 보관한다.
- 새 장부 파일을 빈 상태로 시작하게 만든다.
- 핵심 원장은 archive manifest에 size/mtime/sha256을 남긴다.

안전 원칙:
- 기본은 DRY-RUN이다. 실제 이동은 --apply 필요.
- OPEN/CLOSED/trade_log/decision/exact/change/issue 계열은 삭제하지 않고 archive로 이동한다.
- 새 빈 파일 생성은 원래 파일 형식(json/jsonl/txt)에 맞춰 최소값만 쓴다.
- runtime cache/status/log는 --include-runtime-cache를 준 경우에만 별도 archive 처리한다.
"""
from __future__ import annotations
import argparse, hashlib, json, os, shutil, sys, time
from datetime import datetime, timezone, timedelta
from pathlib import Path

KST = timezone(timedelta(hours=9))
LEDGER_PATTERNS = [
    'paper_bot_open.json',
    'paper_bot_closed.jsonl',
    'paper_bot_trade_log.jsonl',
    'paper_trade_log.jsonl',
    'paper_decision_state_v926.json',
    'paper_decision_events_v926.jsonl',
    'paper_decision_status_v926.json',
    'paper_execution_cost_ledger.jsonl',
    'paper_closed_append_events_v925.jsonl',
    'paper_closed_append_status_v925.json',
    'paper_closed_commit_events.jsonl',
    'paper_closed_commit_status.json',
    'paper_open_alert_trace.jsonl',
    'paper_close_alert_trace.jsonl',
    'paper_open_quarantine.jsonl',
    'paper_open_backup.json',
    'paper_bot_score_cache.json',
    'paper_bot_classify_cache.json',
    'paper_bot_trade_review_cache.json',
    'paper_bot_trade_detail_v798.jsonl',
    'paper_bot_trade_detail_cache_v798.json',
    'paper_bot_trade_detail_v800.jsonl',
    'paper_bot_trade_detail_cache_v800.json',
    'change_verify_ledger.jsonl',
    'issue_ledger.jsonl',
    'coinbot_change_verify_ledger.jsonl',
    'coinbot_issue_ledger.jsonl',
    'exact_*.jsonl',
    'paper_exact_*.jsonl',
    'decision_*.jsonl',
    'trade_*ledger*.jsonl',
]
RUNTIME_PATTERNS = [
    '*status*.json', '*cache*.json', '*trace*.jsonl', '*runtime*.log', '*error*.log',
    'paper_candidates*.jsonl', 'clean_strategy_*cache*.json', 'clean_*_cache.json',
]

EMPTY_BY_NAME = {
    'paper_bot_open.json': [],
    'paper_decision_state_v926.json': {},
    'paper_decision_status_v926.json': {'state': 'CLEAN_START', 'rows': 0},
    'paper_bot_score_cache.json': {
        'state': 'CLEAN_START_COLLECTING',
        'reason': 'v1407 clean ledger start; previous ledgers archived with manifest',
        'closed_count': 0,
        'open_count': 0,
    },
    'paper_bot_classify_cache.json': {'state': 'CLEAN_START_COLLECTING', 'rows': 0},
    'paper_bot_trade_review_cache.json': {'state': 'CLEAN_START_COLLECTING', 'rows': 0},
}


def sha256_path(p: Path) -> str:
    h = hashlib.sha256()
    with p.open('rb') as f:
        for chunk in iter(lambda: f.read(1024 * 1024), b''):
            h.update(chunk)
    return h.hexdigest()


def unique_paths(root: Path, patterns: list[str]) -> list[Path]:
    seen = set(); out = []
    for pat in patterns:
        for p in root.glob(pat):
            if not p.is_file():
                continue
            if p.resolve() in seen:
                continue
            seen.add(p.resolve()); out.append(p)
    return sorted(out, key=lambda x: str(x))


def empty_content_for(path: Path) -> bytes:
    name = path.name
    if name in EMPTY_BY_NAME:
        return (json.dumps(EMPTY_BY_NAME[name], ensure_ascii=False, indent=2) + '\n').encode('utf-8')
    if name.endswith('.json'):
        return b'{}\n'
    if name.endswith('.jsonl') or name.endswith('.log') or name.endswith('.txt'):
        return b''
    return b''


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument('--bot-dir', default=os.environ.get('COINBOT_HOME') or os.getcwd(), help='coinbot runtime directory')
    ap.add_argument('--apply', action='store_true', help='actually archive and create clean files')
    ap.add_argument('--include-runtime-cache', action='store_true', help='also archive runtime cache/status/log files')
    ap.add_argument('--archive-root', default=None, help='archive root directory; default BOT_DIR/archive_clean_start')
    args = ap.parse_args()

    root = Path(args.bot_dir).resolve()
    if not root.exists():
        print(f'FAIL: bot dir not found: {root}', file=sys.stderr)
        return 2

    ts = datetime.now(KST).strftime('%Y%m%d_%H%M%S_KST')
    archive_root = Path(args.archive_root).resolve() if args.archive_root else root / 'archive_clean_start'
    archive_dir = archive_root / f'v1407_clean_start_{ts}'
    targets = unique_paths(root, LEDGER_PATTERNS)
    if args.include_runtime_cache:
        runtime_targets = [p for p in unique_paths(root, RUNTIME_PATTERNS) if p not in targets]
    else:
        runtime_targets = []

    manifest = {
        'schema': 'coinbot_v1407_clean_ledger_start_manifest',
        'created_kst': ts,
        'bot_dir': str(root),
        'mode': 'APPLY' if args.apply else 'DRY_RUN',
        'strategy_mode': 'ALT_SWING',
        'auto_buy': False,
        'ledger_policy': 'archive_then_empty_start; no protected ledger deletion',
        'ledger_files': [],
        'runtime_cache_files': [],
    }

    def collect(p: Path, kind: str):
        rel = p.relative_to(root)
        item = {
            'kind': kind,
            'relative_path': str(rel),
            'size_bytes': p.stat().st_size,
            'mtime': p.stat().st_mtime,
            'sha256': sha256_path(p),
            'archive_relative_path': str(Path(kind) / rel.name),
        }
        manifest['ledger_files' if kind == 'ledger' else 'runtime_cache_files'].append(item)
        return item

    ledger_items = [collect(p, 'ledger') for p in targets]
    runtime_items = [collect(p, 'runtime_cache') for p in runtime_targets]

    print(f"BOT_DIR={root}")
    print(f"MODE={'APPLY' if args.apply else 'DRY_RUN'}")
    print(f"LEDGER_FILES={len(ledger_items)}")
    print(f"RUNTIME_CACHE_FILES={len(runtime_items)}")
    print(f"ARCHIVE_DIR={archive_dir}")

    if not args.apply:
        print('DRY_RUN only. Re-run with --apply to archive and create clean ledger files.')
        return 0

    (archive_dir / 'ledger').mkdir(parents=True, exist_ok=True)
    (archive_dir / 'runtime_cache').mkdir(parents=True, exist_ok=True)

    # Move ledgers to archive, then create clean empty replacement at original path.
    for item in ledger_items:
        src = root / item['relative_path']
        dst = archive_dir / item['archive_relative_path']
        dst.parent.mkdir(parents=True, exist_ok=True)
        shutil.move(str(src), str(dst))
        src.parent.mkdir(parents=True, exist_ok=True)
        src.write_bytes(empty_content_for(src))

    for item in runtime_items:
        src = root / item['relative_path']
        dst = archive_dir / item['archive_relative_path']
        dst.parent.mkdir(parents=True, exist_ok=True)
        shutil.move(str(src), str(dst))
        # runtime cache/status/log does not need replacement; workers will recreate.

    manifest_path = archive_dir / 'MANIFEST_v1407_clean_start.json'
    manifest_path.write_text(json.dumps(manifest, ensure_ascii=False, indent=2), encoding='utf-8')

    # Write a small status marker in bot dir so Main/Guard humans can see clean-start happened.
    marker = {
        'schema': 'coinbot_v1407_clean_start_marker',
        'created_kst': ts,
        'archive_dir': str(archive_dir),
        'ledger_files_archived': len(ledger_items),
        'runtime_cache_files_archived': len(runtime_items),
        'auto_buy': False,
        'state': 'CLEAN_START_COLLECTING',
    }
    (root / 'coinbot_clean_start_v1407_status.json').write_text(json.dumps(marker, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')
    print('DONE: archived ledgers and created clean-start files.')
    print(f'MANIFEST={manifest_path}')
    return 0

if __name__ == '__main__':
    raise SystemExit(main())
