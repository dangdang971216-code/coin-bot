coinbot_update_v1407
목적: v1406의 과한 묶음 흐름을 되돌리고, v1405식 가벼운 명령 흐름으로 복구.
- /gupgrade_bundle은 적용과 최소 검수 중심
- /gdisk_full은 즉시 ACK 유지
- v1405 큰 파일 정리 NameError 수정
- 전략수치·자동매수·진입/청산 계약 변경 없음
- 자동매수 OFF
