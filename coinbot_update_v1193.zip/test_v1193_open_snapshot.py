import importlib.util
import json
import os
import tempfile
import unittest
from pathlib import Path
from unittest import mock

HERE = Path(__file__).resolve().parent


def load_module(name: str, filename: str):
    spec = importlib.util.spec_from_file_location(name, HERE / filename)
    module = importlib.util.module_from_spec(spec)
    assert spec and spec.loader
    spec.loader.exec_module(module)
    return module


paper = load_module('paper_v1193_under_test', 'paper_bot_v1.052.py')


class OpenSnapshotV1193Tests(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.root = Path(self.tmp.name)
        self.orig_open = paper.FILES['open']
        paper.FILES['open'] = self.root / 'paper_bot_open.json'
        paper._V1054_OPEN_CACHE_ROWS = None
        paper._V1054_OPEN_CACHE_FINGERPRINT = None
        paper._V1054_OPEN_CACHE_STATS.clear()

    def tearDown(self):
        paper.FILES['open'] = self.orig_open
        self.tmp.cleanup()

    @staticmethod
    def sample_rows(count: int = 12):
        rows = {}
        for i in range(count):
            pid = f'pos-{i:04d}'
            rows[pid] = {
                'pos_id': pid,
                'ticker': f'T{i}',
                'opened_at': 1782979000.0 + i,
                'entry_price': 123.45 + i,
                'paper_decision_key_v926': f'decision-{i}',
                'korean': '진입계약 보존',
                'nested': {
                    'trigger': 100 + i,
                    'invalid': 90 + i,
                    'target': 140 + i,
                    'values': list(range(40)),
                    'rows': [{'x': x, 'text': '근거' * 20} for x in range(8)],
                },
            }
        return rows

    def test_row_encoder_roundtrip_and_bounded_write_calls(self):
        rows = self.sample_rows(25)
        self.assertTrue(paper._v1054_stream_write_open_verified(rows))
        raw_bytes = paper.FILES['open'].read_bytes()
        loaded = json.loads(raw_bytes.decode('utf-8'))
        self.assertEqual(loaded, rows)
        expected_bytes = json.dumps(rows, ensure_ascii=False, separators=(',', ':'), default=str).encode('utf-8')
        self.assertEqual(raw_bytes, expected_bytes)
        stats = paper._V1054_OPEN_CACHE_STATS
        self.assertEqual(stats['serialization_mode_v1193'], 'top_level_row_c_encoder_bounded_memory')
        self.assertEqual(stats['last_encoded_rows_v1193'], 25)
        self.assertLessEqual(stats['last_encoder_write_calls_v1193'], 4 * 25 + 1)
        self.assertGreater(stats['last_written_bytes_v1193'], 0)

    def test_empty_book_is_valid_json(self):
        self.assertTrue(paper._v1054_stream_write_open_verified({}))
        self.assertEqual(json.loads(paper.FILES['open'].read_text(encoding='utf-8')), {})
        self.assertEqual(paper._V1054_OPEN_CACHE_STATS['last_encoded_rows_v1193'], 0)

    def test_directory_fsync_failure_restores_prior_open_snapshot(self):
        prior = self.sample_rows(3)
        self.assertTrue(paper._v1054_stream_write_open_verified(prior))
        prior_bytes = paper.FILES['open'].read_bytes()
        new_rows = self.sample_rows(4)
        real_fsync = paper.os.fsync
        calls = {'n': 0}

        def fail_once_on_directory(fd):
            calls['n'] += 1
            if calls['n'] == 2:
                raise OSError('forced directory fsync failure')
            return real_fsync(fd)

        with mock.patch.object(paper.os, 'fsync', side_effect=fail_once_on_directory):
            self.assertFalse(paper._v1054_stream_write_open_verified(new_rows))
        self.assertEqual(paper.FILES['open'].read_bytes(), prior_bytes)
        self.assertEqual(json.loads(prior_bytes.decode('utf-8')), prior)

    def _run_core(self, maintenance_changed: bool, selected: bool):
        persist_calls = []
        open_pos = {'old': {'pos_id': 'old', 'paper_decision_key_v926': 'decision-old'}}

        def fake_persist(rows):
            persist_calls.append(list(rows.keys()))
            return True

        def fake_commit(rows, prepared):
            if not prepared:
                return [], []
            pid, pos, ev = prepared[0]
            staged = dict(rows)
            staged[pid] = pos
            self.assertTrue(fake_persist(staged))
            rows.clear()
            rows.update(staged)
            return [pos], [(pid, ev)]

        picked = [('new', {'ticker': 'NEW'})] if selected else []
        fake_path = self.root / 'request.json'

        patches = [
            mock.patch.object(paper, 'reconcile_decision_state_at_startup', return_value={}),
            mock.patch.object(paper, 'load_control', return_value={'running': True, 'loop_seconds': 1}),
            mock.patch.object(paper, 'load_open', return_value=open_pos),
            mock.patch.object(paper, '_v930_compact_existing_open_rows', return_value=1 if maintenance_changed else 0),
            mock.patch.object(paper, '_v739_quarantine_open_positions', return_value=[]),
            mock.patch.object(paper, 'select_candidates', return_value=(picked, {}, [])),
            mock.patch.object(paper, 'open_position', return_value={
                'pos_id': 'new', 'paper_decision_key_v926': 'decision-new', 'ticker': 'NEW', 'entry_price': 1.0
            }),
            mock.patch.object(paper, '_v926_decision_key_from_row', side_effect=lambda row: row.get('paper_decision_key_v926')),
            mock.patch.object(paper, '_v1180_commit_open_batch', side_effect=fake_commit),
            mock.patch.object(paper, 'persist_open_positions', side_effect=fake_persist),
            mock.patch.object(paper, '_v734_is_hold', return_value=False),
            mock.patch.object(paper, 'line_count_cached', return_value=0),
            mock.patch.object(paper, 'write_status', return_value=None),
            mock.patch.object(paper, '_v1181_queue_postprocess', return_value=fake_path),
            mock.patch.object(paper, '_set_runtime_phase_v994', return_value=None),
            mock.patch.object(paper, 'log', return_value=None),
        ]
        for p in patches:
            p.start()
        try:
            status = paper.run_cycle__v1181_fast_core()
        finally:
            for p in reversed(patches):
                p.stop()
        return status, persist_calls

    def test_maintenance_and_new_open_share_one_snapshot_write(self):
        status, calls = self._run_core(maintenance_changed=True, selected=True)
        self.assertEqual(len(calls), 1)
        self.assertEqual(status['opened_this_cycle'], 1)
        self.assertTrue(status['open_maintenance_coalesced_into_open_batch_v1193'])
        self.assertEqual(status['open_maintenance_snapshot_write_count_v1193'], 0)
        self.assertEqual(status['open_total_snapshot_write_count_v1193'], 1)

    def test_maintenance_without_new_open_writes_once(self):
        status, calls = self._run_core(maintenance_changed=True, selected=False)
        self.assertEqual(len(calls), 1)
        self.assertEqual(status['opened_this_cycle'], 0)
        self.assertFalse(status['open_maintenance_coalesced_into_open_batch_v1193'])
        self.assertEqual(status['open_maintenance_snapshot_write_count_v1193'], 1)
        self.assertEqual(status['open_total_snapshot_write_count_v1193'], 1)

    def test_no_change_and_no_new_open_writes_zero_times(self):
        status, calls = self._run_core(maintenance_changed=False, selected=False)
        self.assertEqual(calls, [])
        self.assertEqual(status['open_total_snapshot_write_count_v1193'], 0)


if __name__ == '__main__':
    unittest.main(verbosity=2)
