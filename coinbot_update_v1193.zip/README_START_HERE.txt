코인봇 업데이트 v1193
생성: 2026-07-02 17:16:57 KST

목적
- 신규 OPEN이 생긴 cycle에서 기존 OPEN 정리 저장과 신규 OPEN 저장이 겹쳐 전체 OPEN을 2번 쓰는 원인을 제거한다.
- OPEN JSON을 약 1천만 개의 작은 조각으로 만드는 Python iterencode 병목을 행 단위 C 인코더로 교체한다.

변경
- Paper paper_bot_v1.051 -> paper_bot_v1.052
- 기존 OPEN 정리와 신규 OPEN commit을 같은 canonical snapshot 1회로 합침.
- 159개 OPEN은 행별로 한 번씩 인코딩하며 rollback/fsync/hash 검증은 그대로 유지.

변경 없음
- 후보식·S1·selector·중복차단·trigger·invalid·target·RR·청산계약.
- OPEN/CLOSED/decision 원장 계약과 실패 rollback 순서.
- 신규 차단 0 / 자동매수 OFF.

상태
- 로컬 PASS.
- 서버 미적용 CHECK_PENDING_DEPLOY.
- 서버 profile 전 속도개선 DONE 금지.
