#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Read-only runtime phase profiler for coinbot v1190.

Each runtime owner publishes one bounded timing snapshot under ``runtime/``.
The helper never changes candidates, entry/exit rules, or ledgers.

Design notes
------------
* Wall time is observed on every wrapped call in memory.
* Disk publication is rate-limited, so high-frequency WS/Micro functions do
  not create a new write for every message.
* cProfile is sampled periodically and is never nested in the same thread.
* Exceptions are re-raised unchanged after visible timing evidence is written.
"""
from __future__ import annotations

import cProfile
import functools
import json
import os
import pstats
import threading
import time
from pathlib import Path
from typing import Any, Callable, Dict, Mapping, Optional, TypeVar

T = TypeVar("T")
_SCHEMA = "coinbot_runtime_phase_profile_v1190"
_PROCESS_STARTED_AT = time.time()
_LOCK = threading.RLock()
_TLS = threading.local()
_LAST_PROFILED: Dict[str, float] = {}
_LAST_PUBLISHED: Dict[str, float] = {}
_AGGREGATES: Dict[str, Dict[str, float]] = {}


def _base_dir() -> Path:
    raw = os.getenv("TRADING_BOT_DIR", "").strip() or os.getenv("COINBOT_BASE_DIR", "").strip()
    return Path(raw).expanduser().resolve() if raw else Path(__file__).resolve().parent


def _atomic_json(path: Path, payload: Mapping[str, Any]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    tmp = path.with_name(f".{path.name}.tmp.{os.getpid()}.{time.time_ns()}")
    data = json.dumps(dict(payload), ensure_ascii=False, indent=2, default=str)
    try:
        with tmp.open("w", encoding="utf-8") as handle:
            handle.write(data)
            handle.flush()
            os.fsync(handle.fileno())
        os.replace(tmp, path)
    finally:
        try:
            tmp.unlink(missing_ok=True)
        except OSError:
            pass


def _read_json(path: Path) -> Dict[str, Any]:
    try:
        obj = json.loads(path.read_text(encoding="utf-8", errors="ignore"))
        return obj if isinstance(obj, dict) else {}
    except Exception:
        return {}


def _category(name: str, filename: str) -> str:
    s = f"{filename} {name}".lower()
    if any(x in s for x in ("urlopen", "http", "request", "recv", "websocket", "fetch", "poll_many", "poll_budgeted")):
        return "네트워크·거래소 수집"
    if any(x in s for x in ("load_json", "read_json", "read_text", "open_positions", "load_open", "read_candidate")):
        return "입력·원장 읽기"
    if any(x in s for x in ("save_json", "atomic", "write_json", "append_json", "persist", "fsync", "replace")):
        return "파일·원장 저장"
    if any(x in s for x in ("select_candidates", "candidate", "quality", "rank", "gate", "structure", "entry_plan")):
        return "후보·구조·선택 계산"
    if any(x in s for x in ("exit", "close", "monitor", "mfe", "mae", "invalid", "target")):
        return "보유·청산 감시"
    if any(x in s for x in ("performance", "score_cache", "classify", "review", "snapshot")):
        return "성과·복기·snapshot"
    if any(x in s for x in ("notify", "telegram", "send_message", "send_document")):
        return "알림·Telegram"
    if any(x in s for x in ("json", "dumps", "loads", "encode", "decode")):
        return "직렬화·파싱"
    if any(x in s for x in ("sort", "sorted", "median", "counter")):
        return "정렬·집계"
    return "기타 내부 처리"


def _profile_rows(profile: cProfile.Profile, limit: int = 16) -> list[dict[str, Any]]:
    stats = pstats.Stats(profile)
    rows: list[dict[str, Any]] = []
    for (filename, line, name), values in stats.stats.items():
        cc, nc, tt, ct, _callers = values
        if name in {"profiled_call", "wrapped"} or "runtime_phase_probe_v1190" in filename:
            continue
        if ct < 0.0005 and tt < 0.0005:
            continue
        rows.append({
            "function": name,
            "file": Path(filename).name,
            "line": int(line),
            "primitive_calls": int(cc),
            "calls": int(nc),
            "self_sec": round(float(tt), 6),
            "cumulative_sec": round(float(ct), 6),
            "category": _category(name, filename),
        })
    rows.sort(key=lambda row: (float(row["cumulative_sec"]), float(row["self_sec"])), reverse=True)
    return rows[: max(1, int(limit))]


def _update_window(key: str, elapsed: float) -> Dict[str, float]:
    row = _AGGREGATES.setdefault(key, {
        "count": 0.0, "total_sec": 0.0, "max_sec": 0.0,
        "min_sec": 0.0, "last_sec": 0.0,
    })
    row["count"] += 1.0
    row["total_sec"] += elapsed
    row["last_sec"] = elapsed
    row["max_sec"] = max(row["max_sec"], elapsed)
    row["min_sec"] = elapsed if row["count"] <= 1 else min(row["min_sec"], elapsed)
    return dict(row)


def _reset_window(key: str) -> None:
    _AGGREGATES[key] = {"count": 0.0, "total_sec": 0.0, "max_sec": 0.0, "min_sec": 0.0, "last_sec": 0.0}


def profiled_call(
    component: str,
    scope: str,
    version: str,
    func: Callable[..., T],
    *args: Any,
    sample_interval_sec: float = 300.0,
    publish_interval_sec: float = 10.0,
    **kwargs: Any,
) -> T:
    """Call ``func`` and publish bounded timing evidence without changing it."""
    key = f"{component}:{scope}"
    now = time.time()
    depth = int(getattr(_TLS, "profile_depth", 0) or 0)
    with _LOCK:
        last_profiled = float(_LAST_PROFILED.get(key) or 0.0)
        should_profile = depth == 0 and now - last_profiled >= max(30.0, float(sample_interval_sec))
        if should_profile:
            _LAST_PROFILED[key] = now
    profiler: Optional[cProfile.Profile] = cProfile.Profile() if should_profile else None
    started_wall = time.time()
    started_mono = time.perf_counter()
    error: Optional[str] = None
    _TLS.profile_depth = depth + 1
    try:
        if profiler is not None:
            profiler.enable()
        return func(*args, **kwargs)
    except Exception as exc:
        error = f"{type(exc).__name__}: {exc}"
        raise
    finally:
        if profiler is not None:
            profiler.disable()
        _TLS.profile_depth = depth
        completed = time.time()
        elapsed = max(0.0, time.perf_counter() - started_mono)
        path = _base_dir() / "runtime" / f"runtime_phase_profile_{component}_v1190.json"
        with _LOCK:
            window = _update_window(key, elapsed)
            last_published = float(_LAST_PUBLISHED.get(key) or 0.0)
            should_publish = bool(error or profiler is not None or completed - last_published >= max(1.0, float(publish_interval_sec)))
            if not should_publish:
                return
            _LAST_PUBLISHED[key] = completed
            existing = _read_json(path)
            scopes = existing.get("scopes") if isinstance(existing.get("scopes"), dict) else {}
            prior = scopes.get(scope) if isinstance(scopes.get(scope), dict) else {}
            rows = _profile_rows(profiler) if profiler is not None else list(prior.get("top_functions") or [])
            count = int(window.get("count") or 0)
            window_total = float(window.get("total_sec") or 0.0)
            scopes[scope] = {
                "scope": scope,
                "state": "FAIL" if error else "NORMAL",
                "started_ts": started_wall,
                "completed_ts": completed,
                "total_sec": round(elapsed, 6),
                "last_sec": round(elapsed, 6),
                "window_count": count,
                "window_total_sec": round(window_total, 6),
                "window_avg_sec": round(window_total / count, 6) if count else None,
                "window_min_sec": round(float(window.get("min_sec") or 0.0), 6) if count else None,
                "window_max_sec": round(float(window.get("max_sec") or 0.0), 6) if count else None,
                "profiled_this_call": bool(profiler is not None),
                "last_profiled_ts": completed if profiler is not None else prior.get("last_profiled_ts"),
                "sample_interval_sec": float(sample_interval_sec),
                "publish_interval_sec": float(publish_interval_sec),
                "top_functions": rows,
                "slowest_function": rows[0] if rows else None,
                "error": error,
            }
            payload = {
                "schema": _SCHEMA,
                "component": component,
                "version": version,
                "pid": os.getpid(),
                "process_started_at": _PROCESS_STARTED_AT,
                "updated_ts": completed,
                "state": "FAIL" if any(isinstance(v, dict) and v.get("state") == "FAIL" for v in scopes.values()) else "NORMAL",
                "scopes": scopes,
                "policy": "read-only timing evidence; rate-limited disk writes; no gate, blocker, strategy, exit, or ledger mutation",
                "auto_buy": False,
            }
            try:
                _atomic_json(path, payload)
            except Exception:
                # Timing evidence must never alter or stop the trading path.
                pass
            _reset_window(key)


def wrap_function(
    namespace: Dict[str, Any],
    name: str,
    component: str,
    scope: str,
    version: str,
    sample_interval_sec: float = 300.0,
    publish_interval_sec: float = 10.0,
) -> bool:
    original = namespace.get(name)
    if not callable(original) or getattr(original, "_v1190_profile_wrapped", False):
        return False

    @functools.wraps(original)
    def wrapped(*args: Any, **kwargs: Any):
        return profiled_call(
            component, scope, version, original, *args,
            sample_interval_sec=sample_interval_sec,
            publish_interval_sec=publish_interval_sec,
            **kwargs,
        )

    wrapped._v1190_profile_wrapped = True  # type: ignore[attr-defined]
    wrapped._v1190_original = original  # type: ignore[attr-defined]
    namespace[name] = wrapped
    return True
