# v1084 Paper allocator + exact-exit memory owner probe

Measurement only. v1083 was invalid because it completed only one cycle, reported self RSS 0,
started tracemalloc with five frames before main(), and omitted the one-second exact exit monitor.

v1084 uses low-overhead `/proc/self/status`, `smaps_rollup`, glibc `mallinfo2`, bounded global-object
sizes, and includes `load_open`, OPEN persistence, all-OPEN exit processing, and the exact exit monitor.
It completes after three normal cycles and six exact-exit sweeps.

No strategy, entry, exit, OPEN limit, or canonical ledger contract is changed.
