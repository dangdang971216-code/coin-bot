# v1120 범위와 검수

## 목적
후보를 보는 눈을 실제 수치로 비교한다. 동일한 exact candidate 사건과 동일한 최초 관찰 가격 경로를 세 정책으로 동시에 추적한다.

1. `safety_only`: 품질 Gate만 제거하고 구조·trigger·actual-entry 안전·RR·목표공간·freshness·spread·slippage·비용 등 필수 계약은 유지한다.
2. `current_quality`: 현재 품질 Gate 결과를 그대로 봉인한다.
3. `improved_quality`: RR·목표공간·가격반응·상대강도·money flow·buy flow·비용을 조합한 임시 shadow 점수다.

개선안은 관찰 전용이다. 실제 Strategy/Paper 선택, 품질 threshold, rank, OPEN 30, cycle 3을 바꾸지 않는다.

## 측정
- 1m / 3m / 5m / 10m / 20m / 60m
- 현재수익, MFE, MAE, 반납
- 비용 차감 참고 손익
- 양수 MFE 없음
- +5%, +8%, +10% 도달
- current false-pass / false-block 대표 표본

## 정확성 계약
- exact identity는 active swing gate decision key를 우선한다.
- ticker 근접결합으로 다른 사건의 결과를 붙이지 않는다.
- 이벤트 최초 생성 시 정책·품질값을 봉인한다.
- 과거 OPEN/CLOSED를 현재 조건으로 재분류하지 않는다.
- 이 단계는 forward path 비교이며 canonical CLOSED 청산 시뮬레이션이 아니다.

## 함께 수정한 오류
FLOW-04 Candle, FLOW-06 Orderflow, FLOW-07 Target Router는 현재 cycle universe와 지속 cache/queue inventory를 서로 terminal accounting처럼 비교하고 있었다. `CACHE_INVENTORY_COVERAGE`로 분리해 cache의 추가 보유 종목은 오류가 아니라 inventory extra로 표시한다. 현재 universe 미커버는 pending으로 계속 드러나며, 실제 후보·Paper funnel은 기존 strict accounting을 유지한다.

## 서버 DONE 기준
- Guard/Review 최신 버전 실행 증명
- runtime mismatch 0, 새 실행 오류 0
- FLOW-04·06·07 accounting gap 0
- quality comparison status 파일 생성·갱신
- 실제 매매조건·한도·자동매수 변화 0
