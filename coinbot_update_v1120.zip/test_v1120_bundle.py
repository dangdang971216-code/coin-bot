#!/usr/bin/env python3
import ast, importlib.util, json, os, tempfile
from pathlib import Path
os.environ.setdefault('GUARD_BOT_TOKEN','test-token')
os.environ.setdefault('GUARD_CHAT_ID','1')
ROOT=Path(__file__).resolve().parent

def load(name,path,base):
    os.environ['TRADING_BOT_DIR']=str(base)
    spec=importlib.util.spec_from_file_location(name,path)
    mod=importlib.util.module_from_spec(spec); spec.loader.exec_module(mod); return mod

def count_top(path,name):
    tree=ast.parse(Path(path).read_text(encoding='utf-8'))
    return sum(isinstance(n,(ast.FunctionDef,ast.AsyncFunctionDef)) and n.name==name for n in tree.body)

def main():
    with tempfile.TemporaryDirectory() as td:
        base=Path(td)
        review=load('review_v1120',ROOT/'review_worker_v0.998.py',base)
        strong_metrics={
            'risk_reward':3.2,'target_room_pct':16.0,'price_reaction_pct':0.45,
            'relative_strength_rank_pct':82.0,'relative_strength_pct':1.1,
            'money_flow_score':82.0,'buy_ratio':0.76,'buy_sustain_1m':0.72,
            'spread_pct':0.10,'confirmed_slippage_pct':0.10,'trigger_gap_pct':0.35,
            'current_quality_rank_score':76.0,'current_quality_tier':'A',
        }
        quality_only_gate={'hard_pass':False,'hard_block_reasons':['quality_confirmation_absent:relative/money/buyflow']}
        variants=review._quality_policy_variants_v1120({},quality_only_gate,strong_metrics)
        assert variants['safety_only']['selected'] is True
        assert variants['current_quality']['selected'] is False
        assert variants['improved_quality']['selected'] is True, variants
        unsafe_gate={'hard_pass':False,'hard_block_reasons':['untradable_spread','quality_confirmation_absent:relative/money/buyflow']}
        unsafe=review._quality_policy_variants_v1120({},unsafe_gate,strong_metrics)
        assert unsafe['safety_only']['selected'] is False
        assert unsafe['improved_quality']['selected'] is False
        records=[
            {'ticker':'AAA','quality_event_key_v946':'e1','initial_metrics':strong_metrics,'policy_variants_v1120':variants,
             'samples':{'60m':{'pct':2.0,'max_pct':8.5,'min_pct':-0.4,'giveback_pct':6.5}}},
            {'ticker':'BBB','quality_event_key_v946':'e2','initial_metrics':strong_metrics,'policy_variants_v1120':{
                'safety_only':{'selected':True},'current_quality':{'selected':True},'improved_quality':{'selected':True}},
             'samples':{'60m':{'pct':-1.0,'max_pct':0.0,'min_pct':-1.4,'giveback_pct':1.0}}},
        ]
        status=review.update_quality_policy_comparison_v1120(1000.0,records)
        assert status['horizons']['60m']['safety_only']['n']==2
        assert status['horizons']['60m']['safety_only']['hit_8_count']==1
        assert status['false_pass_60m_count']==1
        assert status['limits_ignored_for_comparison']=={'open_limit':True,'cycle_limit':True}
        assert (base/'clean_quality_policy_comparison_status_v1120.json').exists()
        compact=review._quality_active_compact_v1007({'quality_event_key_v946':'x','ticker':'AAA','policy_variants_v1120':variants,'initial_metrics':strong_metrics,'samples':{}})
        assert 'policy_variants_v1120' in compact
        assert compact['initial_metrics']['risk_reward']==3.2

        guard=load('guard_v1120',ROOT/'backga_guard_bot_v2_5_168.py',base)
        coverage=guard._ops_stage_v1102(4,'x','x','NORMAL',389,394,accounting_mode='CACHE_INVENTORY_COVERAGE')
        assert coverage['state']=='NORMAL' and coverage['balance_ok'] is True
        assert coverage['inventory_extra_count_v1120']==5 and coverage['overaccounted_count']==0
        pending=guard._ops_stage_v1102(4,'x','x','NORMAL',389,300,pending_count=89,accounting_mode='CACHE_INVENTORY_COVERAGE')
        assert pending['state']=='NORMAL' and pending['balance_ok'] is True
        terminal=guard._ops_stage_v1102(9,'x','x','NORMAL',10,12)
        assert terminal['state']=='CHECK' and terminal['overaccounted_count']==2
        assert count_top(ROOT/'review_worker_v0.998.py','update_quality_policy_comparison_v1120')==1
        assert count_top(ROOT/'backga_guard_bot_v2_5_168.py','_ops_stage_v1102')==1
        print(json.dumps({'status':'PASS','quality_variants':variants,'comparison_counts':status['event_selected_counts'],'guard_inventory_extra':coverage['inventory_extra_count_v1120']},ensure_ascii=False))
if __name__=='__main__': main()
