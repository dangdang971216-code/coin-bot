import importlib.util, os, tempfile, json, time
from pathlib import Path
root=Path(tempfile.mkdtemp(prefix='main1125_'))
os.environ['TRADING_BOT_DIR']=str(root)
bundle_root=Path(__file__).resolve().parent
spec=importlib.util.spec_from_file_location('main1125',str(bundle_root/'coinbot_main_v2_13_1097.py'))
m=importlib.util.module_from_spec(spec); spec.loader.exec_module(m)
assert callable(m.COMMANDS.get('quality_shadow'))
assert m.COMMANDS['quality_shadow'] is m.render_quality_shadow_text
assert 'quality_shadow' in (m.ACTIVE_BIND_STATUS.get('public_commands') or [])
assert '/quality_shadow' in m.render_commands_text()
now=time.time()
m.QUALITY_SHADOW_STATUS.write_text(json.dumps({'updated_ts':now,'version':'review_worker_v1.003','source_rows_raw_v1125':461,'source_unique_trigger_decisions_v1125':80,'source_duplicate_trigger_decision_rows_v1125':381,'tracked_records':90,'new_records_this_cycle':2}),encoding='utf-8')
pol={k:{'n':30,'cost_adjusted_avg_pct':v,'avg_mfe_pct':v+1,'avg_mae_pct':-0.5,'win_rate_pct':55,'no_positive_mfe_count':5,'hit_5_count':2,'hit_8_count':1,'hit_10_count':0} for k,v in [('safety_only',0.1),('current_quality',-0.2),('improved_quality',0.5)]}
m.QUALITY_EYE_STATUS_V1124.write_text(json.dumps({'updated_ts':now,'version':'review_worker_v1.003','state':'READY_FOR_REVIEW','identity_contract':'trigger_occurrence_v1037.decision_key exact','finalized_events':40,'active_unfinalized_events':10,'horizons':{'10m':pol,'60m':pol},'leader_60m':'improved_quality','leader_state':'EVIDENCE_READY','minimum_ready_n':30,'minimum_60m_samples_per_policy':30,'delta_improved_vs_current_60m':{'cost_adjusted_avg_pct':0.7},'delta_current_vs_no_quality_60m':{'cost_adjusted_avg_pct':-0.3},'false_pass':{'no_positive_mfe':4,'negative_after_cost':8,'caught_by_improved':3,'improved_block_reason_top':[['score_low',3]]},'false_block':{'hit_1':7,'hit_5':2,'hit_8':1,'hit_10':0,'recovered_by_improved_hit_1':5,'current_block_reason_top':[['confirmation_missing',7]]}}),encoding='utf-8')
text=m.render_command_text('quality_shadow')
assert '공개 명령 없음' not in text
assert 'v1125 후보 보는 눈' in text and '조건 없음' in text and '개선 조건' in text
print(json.dumps({'ok':True,'registered':True,'public':True,'render_head':text.splitlines()[0]},ensure_ascii=False))
