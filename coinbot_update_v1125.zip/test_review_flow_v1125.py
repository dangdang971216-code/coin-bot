import importlib.util, os, tempfile, json
from pathlib import Path
root=Path(tempfile.mkdtemp(prefix='review1125_flow_'))
os.environ['TRADING_BOT_DIR']=str(root)
# Historical files must remain untouched and unread by the clean experiment.
old_ledger=root/'quality_shadow_result_ledger_v946.jsonl'; old_ledger.write_text('LEGACY_SENTINEL\n',encoding='utf-8')
old_state=root/'clean_quality_shadow_state_v946.json'; old_state.write_text('{"legacy":true}',encoding='utf-8')
bundle_root=Path(__file__).resolve().parent
spec=importlib.util.spec_from_file_location('rw1125',str(bundle_root/'review_worker_v1.003.py'))
m=importlib.util.module_from_spec(spec); spec.loader.exec_module(m)
seen=set()
m._dedup_contains_v1013=lambda kind,key: (kind,key) in seen
m._dedup_commit_v1013=lambda kind,key: seen.add((kind,key))
m._dedup_count_v1013=lambda kind: sum(1 for k,_ in seen if k==kind)
now=1_780_000_000.0
occ='market:AAA|plan:1779999000000|rebreak:1779999900000'
def make(candidate,direct):
    trigger={'decision_key':occ,'candidate_key':candidate,'kind':'REBREAK','rebreak_ts':1779999900.0}
    gate={'hard_pass':True,'stage':'S1','decision_key':direct,'trigger_occurrence_v1037':trigger,
          'hard_block_reasons':[],'risk_reward':2.0,'target_room_pct':5.0,'spread_pct':0.1}
    return {'ticker':'AAA','entry_build_key':candidate,'trigger_occurrence_candidate_key_v1037':candidate,
      'swing_gate_decision_key_v977':direct,'trigger_occurrence_v1037':trigger,'swing_entry_gate_v977':gate,
      'current_price':100.0,'price_reaction_pct':0.1,'relative_strength_pct':1.0,
      'relative_strength_rank_pct':80,'money_flow_score':70.0,'buy_ratio':0.65,'buy_sustain_1m':0.6,
      'spread_pct':0.1,'confirmed_slippage_pct':0.1,'risk_reward':2.0,'target_room_pct':5.0,'trigger_gap_pct':0.1}
r1=make('scanner-event-A','direct-A'); r2=make('scanner-event-B','direct-A-resealed')
status,rows=m.update_quality_shadow(now,{'AAA':{'current_price':100.0}},{},[r1,r2],{})
assert status['source_rows_raw_v1125']==2
assert status['source_unique_trigger_decisions_v1125']==1
assert status['source_duplicate_trigger_decision_rows_v1125']==1
assert len(rows)==1
assert not m.QUALITY_SHADOW_LEDGER.exists()
for rec in m._QUALITY_STATE_CACHE_V1011.values(): rec['next_review_due_ts_v1011']=0.0
status2,rows2=m.update_quality_shadow(now+3601,{'AAA':{'current_price':104.0}},{},[r1],{})
assert status2['finalized_this_cycle']==1
assert (m.QUALITY_DEDUP_KIND_V1125,m._quality_exact_identity(r1)[0]) in seen
assert m.QUALITY_SHADOW_LEDGER.name=='quality_shadow_result_ledger_v1125.jsonl'
lines=m.QUALITY_SHADOW_LEDGER.read_text(encoding='utf-8').strip().splitlines()
assert len(lines)==1
final=json.loads(lines[0]); assert final['quality_event_key_v946'].startswith('trigger_decision:')
assert old_ledger.read_text(encoding='utf-8')=='LEGACY_SENTINEL\n'
assert old_state.read_text(encoding='utf-8')=='{"legacy":true}'
comp=m.update_quality_policy_comparison_v1120(now+3601,rows2)
assert comp['finalized_events']==1 and comp['horizons']['60m']['safety_only']['n']==1
print(json.dumps({'ok':True,'root':str(root),'unique':1,'ledger_lines':len(lines),'line_bytes':len(lines[0].encode()),'dedup_kind':m.QUALITY_DEDUP_KIND_V1125,'legacy_preserved':True},ensure_ascii=False))
