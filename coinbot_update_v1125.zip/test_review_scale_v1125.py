import importlib.util, os, tempfile, json
from pathlib import Path
root=Path(tempfile.mkdtemp(prefix='review1125_scale_'))
os.environ['TRADING_BOT_DIR']=str(root)
bundle_root=Path(__file__).resolve().parent
spec=importlib.util.spec_from_file_location('rw1125_scale',str(bundle_root/'review_worker_v1.003.py'))
m=importlib.util.module_from_spec(spec); spec.loader.exec_module(m)
seen=set(); m._dedup_contains_v1013=lambda k,x:(k,x) in seen; m._dedup_commit_v1013=lambda k,x:seen.add((k,x)); m._dedup_count_v1013=lambda k:sum(1 for a,_ in seen if a==k)
now=1_780_000_000.0; rows=[]; fmap={}
for i in range(461):
    ticker=f'T{i:03d}'; occurrence=f'market:{ticker}|plan:1779999000000'
    trigger={'decision_key':occurrence,'candidate_key':f'scanner-A-{i}'}
    gate={'hard_pass':True,'stage':'S1','decision_key':occurrence,'trigger_occurrence_v1037':trigger,'hard_block_reasons':[],'risk_reward':2.0,'target_room_pct':5.0,'spread_pct':0.1}
    rows.append({'ticker':ticker,'entry_build_key':f'scanner-A-{i}','trigger_occurrence_candidate_key_v1037':f'scanner-A-{i}','trigger_occurrence_v1037':trigger,'swing_entry_gate_v977':gate,'current_price':100.0,'price_reaction_pct':0.1,'relative_strength_pct':1.0,'money_flow_score':70.0,'buy_ratio':0.6,'buy_sustain_1m':0.55,'spread_pct':0.1,'confirmed_slippage_pct':0.1,'risk_reward':2.0,'target_room_pct':5.0})
    fmap[ticker]={'current_price':100.0}
first,_=m.update_quality_shadow(now,fmap,{},rows,{})
rows2=[]
for i,row in enumerate(rows):
    x=dict(row); x['entry_build_key']=f'scanner-B-{i}'; x['trigger_occurrence_candidate_key_v1037']=f'scanner-B-{i}'
    x['trigger_occurrence_v1037']=dict(row['trigger_occurrence_v1037'],candidate_key=f'scanner-B-{i}')
    x['swing_entry_gate_v977']=dict(row['swing_entry_gate_v977'],decision_key=f'resealed-display-{i}',trigger_occurrence_v1037=x['trigger_occurrence_v1037'])
    x['swing_gate_decision_key_v977']=f'resealed-display-{i}'; rows2.append(x)
second,_=m.update_quality_shadow(now+30,fmap,{},rows2,{})
assert first['new_records_this_cycle']==461
assert second['new_records_this_cycle']==0
assert second['tracked_records']==461
print(json.dumps({'ok':True,'first_new':461,'second_new':0,'tracked':461,'same_trigger_decision_dedup':True,'checkpoint_bytes':m.QUALITY_SHADOW_STATE.stat().st_size},ensure_ascii=False))
