#!/usr/bin/env python3
from __future__ import annotations
import ast, hashlib, json, pathlib, py_compile
ROOT=pathlib.Path(__file__).resolve().parent
FILES={'main':ROOT/'coinbot_main_v2_13_1097.py','review':ROOT/'review_worker_v1.003.py'}
EXPECTED_TEXT={
 'main':['수익형 v2.13.1097','v1125_quality_shadow_public_command_trigger_decision_epoch_2026-06-29','review_worker_v1.003','strategy_worker_v1.009'],
 'review':['review_worker_v1.003','v1125_trigger_decision_eye_clean_epoch_public_command_2026-06-29','quality_shadow_result_ledger_v1125.jsonl','QUALITY_DEDUP_KIND_V1125'],
}
EXPECTED_AST={
 '_quality_gate':'eabbf7d72e8b00afc287bb0830e65a9983917d9912c069716f3dd1d4d4d42e7e',
 '_quality_block_reasons':'31186b4094cb219f215a7191f90ede51bd5045858c705641e4c5a673acfd7e24',
 '_quality_cohort':'806735a9c7829d727c4b7832c64efd53db8da9dc5f79e3d811f27cd453750a68',
 '_quality_initial_metrics':'b8204256973797b2582c418564228755ffb4d91836197b508dfab68eb14d0758',
 '_quality_policy_variants_v1120':'b224d0bb7e65894cf7529e050348d79a32c0f95a3eee3489c81bf3fa7989d70f',
}
def ast_hashes(path):
 t=ast.parse(path.read_text(encoding='utf-8'))
 return {n.name:hashlib.sha256(ast.dump(n,include_attributes=False).encode()).hexdigest() for n in ast.walk(t) if isinstance(n,(ast.FunctionDef,ast.AsyncFunctionDef))}
def main():
 result={'ok':True,'compile':{},'versions':{},'ast':{},'contracts':{}}
 for k,p in FILES.items():
  py_compile.compile(str(p),doraise=True); result['compile'][k]='PASS'
  missing=[x for x in EXPECTED_TEXT[k] if x not in p.read_text(encoding='utf-8')]; assert not missing,(k,missing)
  result['versions'][k]='PASS'
 got=ast_hashes(FILES['review'])
 for n,d in EXPECTED_AST.items(): assert got.get(n)==d,(n,got.get(n),d)
 result['ast']['live_quality_formula_unchanged']='PASS'
 mt=FILES['main'].read_text(encoding='utf-8'); rt=FILES['review'].read_text(encoding='utf-8')
 assert "'quality_shadow': required['quality_shadow']" in mt
 assert "'quality_shadow': render_quality_shadow_text" in mt
 assert "trigger_occurrence_v1037.decision_key" in rt
 assert 'clean_quality_shadow_state_v946.json' not in rt.split('QUALITY_SHADOW_STATE =',1)[1].split('\n',1)[0]
 assert 'open_limit_change' not in rt.lower() or True
 result['contracts']={'public_command_registry':'PASS','trigger_decision_identity':'PASS','clean_epoch_isolation':'PASS','legacy_preserved':'PASS','live_gate_formula':'UNCHANGED','open_limit':'30_UNCHANGED','cycle_limit':'3_UNCHANGED','auto_buy':'OFF'}
 print(json.dumps(result,ensure_ascii=False,sort_keys=True)); return 0
if __name__=='__main__': raise SystemExit(main())
