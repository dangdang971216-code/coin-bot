# v1125 scope and verification

## Proven causes

1. `render_quality_shadow_text` existed, but the final `bind_active_commands()` canonical table cleared every earlier registration and omitted `quality_shadow`. The server therefore returned `공개 명령 없음`.
2. v1124 used `trigger_occurrence_candidate_key_v1037`, whose base is scanner `entry_build_key`. A new scanner candidate event can be produced while Strategy is still holding the same frozen plan and same trigger occurrence, multiplying one swing decision into multiple quality samples.
3. Reusing the v946/v1124 active state and ledger would carry contaminated identities and an old one-hour write backlog into the corrected experiment.

## New canonical path

`Strategy trigger_occurrence_v1037.decision_key`
→ Review exact identity
→ v1125 active state
→ v1125 append-only final ledger
→ v1125 cumulative aggregate/status
→ Main canonical `/quality_shadow` command.

The decision key is created from market state + frozen plan timestamp and changes only when the plan is replaced or an actual below-trigger reset followed by an above-trigger rebreak occurs. No ticker/time-near inference is used.

## Preserved

- All v946/v1124 files remain untouched.
- Actual quality Gate, rank, trigger, invalid, target, RR, costs, OPEN 30, cycle 3 and exit contract are unchanged.
- Automatic buying remains OFF.

## Server verification

- Main `수익형 v2.13.1097`
- Review `review_worker_v1.003`
- `/quality_shadow` public command works.
- First normal cycle writes `clean_quality_shadow_status_v1125.json`.
- Repeated cycles on the same trigger decision do not increase `new_records_this_cycle`.
- Old v946 ledger growth stops; new v1125 ledger only appends completed corrected occurrences.
