import importlib.util, os, tempfile, time, json
from pathlib import Path
root=Path(tempfile.mkdtemp(prefix='review1125_unit_'))
os.environ['TRADING_BOT_DIR']=str(root)
bundle_root=Path(__file__).resolve().parent
spec=importlib.util.spec_from_file_location('rw1125',str(bundle_root/'review_worker_v1.003.py'))
m=importlib.util.module_from_spec(spec); spec.loader.exec_module(m)

def row(candidate, direct, occurrence):
    trigger={'decision_key':occurrence,'candidate_key':candidate,'kind':'REBREAK','rebreak_ts':123.0}
    gate={'decision_key':direct,'trigger_occurrence_v1037':trigger,'hard_pass':True,'hard_block_reasons':[]}
    return {'ticker':'AAA','entry_build_key':candidate,'trigger_occurrence_candidate_key_v1037':candidate,
            'swing_gate_decision_key_v977':direct,'trigger_occurrence_v1037':trigger,'swing_entry_gate_v977':gate}

r1=row('scanner-event-1','direct-A','market:AAA|plan:1000|rebreak:123000')
r2=row('scanner-event-2','direct-A-resealed','market:AAA|plan:1000|rebreak:123000')
r3=row('scanner-event-3','direct-B','market:AAA|plan:1000|rebreak:456000')
assert m._quality_exact_identity(r1)==m._quality_exact_identity(r2), (m._quality_exact_identity(r1),m._quality_exact_identity(r2))
assert m._quality_exact_identity(r1)!=m._quality_exact_identity(r3)
assert m._quality_exact_identity(r1)[0].startswith('trigger_decision:')
assert 'AAA' not in m._quality_exact_identity({'ticker':'AAA'})[0]  # no ticker/time-near inference
now=time.time(); epoch=m._quality_eye_epoch_v1124(now)
assert epoch['schema']=='quality_eye_epoch_v1125'
assert 'trigger_occurrence_v1037.decision_key' in epoch['identity_contract']
base={
 'quality_event_key_v946':m._quality_exact_identity(r1)[0],
 'quality_eye_epoch_id_v1124':epoch['epoch_id'],'ticker':'AAA',
 'initial_metrics':{'spread_pct':0.1,'confirmed_slippage_pct':0.1},
 'samples':{'60m':{'pct':-1.0,'max_pct':0.0,'min_pct':-2.0,'giveback_pct':1.0}},
 'policy_variants_v1120':{
  'safety_only':{'selected':True},'current_quality':{'selected':True},
  'improved_quality':{'selected':False,'block_reasons':['improved_score_below_62']},
 }
}
agg=m._quality_eye_empty_aggregate_v1124(epoch); m._quality_eye_aggregate_add_row_v1124(agg,base)
status=m._quality_eye_status_from_aggregate_v1124(now,agg,[],epoch)
assert status['false_pass']['no_positive_mfe']==1
assert status['false_pass']['caught_by_improved']==1
assert status['horizons']['60m']['current_quality']['n']==1
print(json.dumps({'ok':True,'identity':m._quality_exact_identity(r1),'new_occurrence':m._quality_exact_identity(r3),'epoch':epoch['epoch_id']},ensure_ascii=False))
