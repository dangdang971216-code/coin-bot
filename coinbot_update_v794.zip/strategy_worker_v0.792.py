#!/usr/bin/env python3
# -*- coding: utf-8 -*-

from __future__ import annotations
import json, os, time, math, traceback, urllib.request
from pathlib import Path
from typing import Any, Dict, List, Tuple, Optional
import re
from collections import Counter
BASE_DIR = Path(os.getenv("TRADING_BOT_DIR", "/home/dangdang971216/trading_bot"))
def now_ts() -> float: return time.time()
def now_text(ts: Optional[float]=None) -> str: return time.strftime("%Y-%m-%d %H:%M:%S", time.localtime(ts or now_ts()))
def fnum(*vals: Any, default: float=0.0) -> float:
    for v in vals:
        try:
            if v is None or v == "": continue
            return float(str(v).replace(",", "").replace("%", ""))
        except Exception: continue
    return default
def load_json(path: Path, default: Any=None) -> Any:
    try:
        if not path.exists(): return default
        return json.loads(path.read_text(encoding="utf-8", errors="ignore"))
    except Exception: return default
def save_json(path: Path, obj: Any) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    tmp = path.with_suffix(path.suffix + ".tmp")
    tmp.write_text(json.dumps(obj, ensure_ascii=False, separators=(",", ":"), default=str), encoding="utf-8")
    os.replace(tmp, path)
def append_jsonl(path: Path, obj: Dict[str, Any]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("a", encoding="utf-8") as f:
        f.write(json.dumps(obj, ensure_ascii=False, separators=(",", ":"), default=str)+"\n")
def write_jsonl_atomic(path: Path, rows: List[Dict[str, Any]]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    tmp = path.with_suffix(path.suffix + ".tmp")
    with tmp.open("w", encoding="utf-8") as f:
        for r in rows:
            f.write(json.dumps(r, ensure_ascii=False, separators=(",", ":"), default=str)+"\n")
    os.replace(tmp, path)
def read_jsonl(path: Path, max_lines: int=1000) -> List[Dict[str, Any]]:
    if not path.exists(): return []
    try:
        lines = path.read_text(encoding="utf-8", errors="ignore").splitlines()
        if max_lines and len(lines) > max_lines: lines = lines[-max_lines:]
        out=[]
        for ln in lines:
            try:
                if ln.strip():
                    o=json.loads(ln)
                    if isinstance(o,dict): out.append(o)
            except Exception: pass
        return out
    except Exception: return []
def read_fresh_jsonl_by_ttl(path: Path, ttl_sec: float) -> List[Dict[str, Any]]:
    """TTL 기준으로 fresh 후보만 읽는다. 개수 제한으로 후보를 자르지 않는다.

    기존 latest/후보 복구 경로의 max_lines=120/500 및 [:40] 고정 상한을
    제거하기 위한 단일 읽기 경로다. 서버 보호는 후보 수 제한이 아니라 TTL로 처리한다.
    """
    if not path.exists():
        return []
    try:
        nowv = now_ts()
        lines = path.read_text(encoding="utf-8", errors="ignore").splitlines()
        out: List[Dict[str, Any]] = []
        for ln in reversed(lines):
            try:
                if not ln.strip():
                    continue
                o = json.loads(ln)
                if not isinstance(o, dict):
                    continue
                exp = fnum(o.get("expires_at"), default=0.0)
                ts = _event_created_ts(o)
                fresh = (exp >= nowv) if exp > 0 else (ts > 0 and (nowv - ts) <= ttl_sec)
                if fresh:
                    out.append(o)
                    continue
                # 파일은 시간순 append라, TTL의 여유구간보다 오래된 항목을 만나면 더 과거는 볼 필요 없다.
                if ts > 0 and (nowv - ts) > max(ttl_sec * 3.0, ttl_sec + 60.0):
                    break
            except Exception:
                continue
        out.reverse()
        return out
    except Exception:
        return []

def append_error(path: Path, where: str, exc: BaseException) -> None:
    try:
        path.parent.mkdir(parents=True, exist_ok=True)
        with path.open("a", encoding="utf-8") as f:
            f.write(f"[{now_text()}] {where}: {exc.__class__.__name__}: {exc}\n")
            f.write(traceback.format_exc()[-1500:]+"\n")
    except Exception: pass
def ticker_norm(x: Any) -> str:
    t = str(x or "").strip().upper().replace("/", "-").replace("_", "-")
    parts=[p for p in t.split("-") if p]
    if len(parts)>=2:
        non=[p for p in parts if p != "KRW"]
        t = non[-1] if non else parts[-1]
    if t.endswith("KRW") and len(t)>3: t=t[:-3]
    return t.strip().upper()
def pct(a: float, b: float) -> float: return ((a-b)/b*100.0) if b else 0.0
def age_sec(path: Path) -> float:
    try: return max(0.0, now_ts()-path.stat().st_mtime)
    except Exception: return 999999.0
def map_rows(obj: Any) -> Dict[str, Dict[str, Any]]:
    if isinstance(obj, dict) and isinstance(obj.get("rows"), list): obj = obj.get("rows")
    elif isinstance(obj, dict) and isinstance(obj.get("rows"), dict): obj = obj.get("rows")
    elif isinstance(obj, dict) and isinstance(obj.get("cache"), dict): obj = obj.get("cache")
    out: Dict[str, Dict[str, Any]] = {}
    if isinstance(obj, list):
        for r in obj:
            if isinstance(r, dict):
                t=ticker_norm(r.get("ticker") or r.get("symbol") or r.get("market"))
                if t: out[t]=r
    elif isinstance(obj, dict):
        for k,v in obj.items():
            t=ticker_norm(k)
            if t and isinstance(v, dict):
                vv=dict(v); vv.setdefault("ticker", t); out[t]=vv
    return out

def feature_rows(obj: Any) -> List[Dict[str, Any]]:
    """feature_worker cache를 한 본선으로 읽는다.
    rows/list/cache/dict 형태를 모두 map_rows로 표준화한다.
    전략 조건 수치는 변경하지 않는다.
    """
    return list(map_rows(obj).values())

INTERVAL_SEC=float(os.getenv("STRATEGY_WORKER_INTERVAL_SEC","2.0"))
STATUS=BASE_DIR/"clean_strategy_worker_status.json"; ERROR=BASE_DIR/"clean_strategy_worker_error.log"
FEATURE=BASE_DIR/"clean_feature_cache.json"; CANDLE=BASE_DIR/"clean_candle_cache.json"; ORDERFLOW=BASE_DIR/"clean_orderflow_summary_cache.json"; REGIME=BASE_DIR/"clean_market_regime_cache.json"; RISK=BASE_DIR/"clean_risk_filter_cache.json"
PAPER=BASE_DIR/"paper_candidates.jsonl"; PAPER_LATEST=BASE_DIR/"paper_candidates_latest.jsonl"; SUMMARY=BASE_DIR/"clean_strategy_s_summary.json"; REJECT=BASE_DIR/"clean_strategy_s_reject_summary.json"; HANDOFF=BASE_DIR/"clean_strategy_paper_handoff_status.json"; WS_TARGETS=BASE_DIR/"clean_ws_targets.json"; MICRO_TARGETS=BASE_DIR/"clean_micro_targets.json"; MICRO_URGENT=BASE_DIR/"clean_micro_urgent_targets.json"; PRIORITY_REQ=BASE_DIR/"clean_strategy_priority_requests.json"; TARGET_ROUTER_QUEUE=BASE_DIR/"clean_target_router_queue.json"; MISSED_REVIEW_QUEUE=BASE_DIR/"clean_missed_review_queue.json"; SCANNER_HOT=BASE_DIR/"clean_scanner_hot_rank_cache.json"; SCANNER_POOL=BASE_DIR/"clean_scanner_candidate_pool.json"
CANDIDATE_TTL_SEC=float(os.getenv("STRATEGY_PAPER_CANDIDATE_TTL_SEC","120"))
ENTRY_PLAN_STATE=BASE_DIR/"clean_strategy_entry_plan_state.json"
STRATEGIES={"money_reaccel_s":"돈흐름 재가속 S","leader_momentum_s":"주도추세 지속 S","breakout_early_s":"돌파 초입 S","sweep_vwap_recovery_s":"저점 VWAP 회복 S","surge_rebreak_s":"급등 후 재돌파 S","leader_flow_adaptive_hold_s":"주도흐름 유동보유 S"}

# v597: official structure-input keys must survive strategy row creation.
# v596 produced/loaded candle features, but candidate row construction dropped those fields before
# structure_line_evidence ran. Keep the source-cache values on the canonical candidate row.
V597_OFFICIAL_STRUCTURE_KEYS = (
    "official_candle_source", "official_candle_age", "official_candle_intervals", "official_candle_cache_schema", "official_structure_source",
    "swing_high_price", "swing_low_price", "box_high_price", "box_low_price", "recent_high_price", "recent_low_price",
    "support_touch_count", "resistance_touch_count", "upper_wick_pct", "lower_wick_pct",
    "vwap_gap_pct", "ema5_gap_pct", "ema10_gap_pct", "ema20_gap_pct",
    "volume_ratio", "volume_expansion_pct", "breakout_hint", "sweep_reclaim_hint", "box_breakout_hint",
    "support_reclaim_hint", "resistance_reject_hint", "pullback_volume_contract", "reclaim_volume_expand",
    "long_upper_wick", "volume_expanding", "close_near_high",
)

def _v597_pick_candle_value(c: Dict[str, Any], key: str, prefixes: Tuple[str, ...] = ("m5", "m3", "m1", "m30")) -> Any:
    if not isinstance(c, dict):
        return None
    for pref in prefixes:
        k = f"{pref}_{key}"
        if c.get(k) not in (None, ""):
            return c.get(k)
    return None

def _v597_candle_official_fields(c: Dict[str, Any], nowv: Optional[float] = None) -> Dict[str, Any]:
    """Convert candle_worker cache row into the unprefixed official structure fields used by strategy.
    No API call here. candle_worker remains the owner of official OHLCV collection.
    """
    if not isinstance(c, dict) or not c:
        return {}
    ts = nowv or now_ts()
    candle_ts = _v510_num(c.get("candle_ts"), default=0.0) if "_v510_num" in globals() else 0.0
    # accept only rows that actually have at least one interval ok or key feature; don't turn missing into zeroes.
    has_interval = bool(c.get("m5_ok") or c.get("m3_ok") or c.get("m1_ok") or c.get("m30_ok") or c.get("m5_swing_high_price") or c.get("m3_swing_high_price"))
    if not has_interval:
        return {}
    out: Dict[str, Any] = {
        "official_candle_source": "candle_worker_direct_cache_v597",
        "official_candle_intervals": "1m/3m/5m/30m",
        "official_candle_cache_schema": c.get("official_structure_schema") or c.get("schema") or "candle_cache_v2_official_structure_inputs",
        "official_structure_source": "candle_worker_cache_overlay_v597",
    }
    if candle_ts > 0:
        out["official_candle_age"] = round(max(0.0, ts - candle_ts), 1)
    for key in V597_OFFICIAL_STRUCTURE_KEYS:
        if key in out:
            continue
        v = _v597_pick_candle_value(c, key)
        if v not in (None, ""):
            out[key] = v
    return out

def _v597_overlay_candle_cache(src: Dict[str, Any], candle_map: Dict[str, Dict[str, Any]], nowv: Optional[float] = None) -> Dict[str, Any]:
    if not isinstance(src, dict):
        return src
    t = ticker_norm(src.get("ticker") or src.get("market") or src.get("symbol"))
    c = candle_map.get(t, {}) if t else {}
    add = _v597_candle_official_fields(c, nowv)
    if not add:
        return dict(src)
    rr = dict(src)
    for k, v in add.items():
        if rr.get(k) in (None, "", 0, 0.0) or k.startswith("official_"):
            rr[k] = v
    return rr
MAIN_DEPLOY_VERSION = "v2.13.764"
MAIN_BOT_VERSION = "수익형 v2.13.787"
def write_status(state:str, **extra:Any)->None:
    # v434: cycle 시작부의 evaluated=0/target=0 상태가 마지막 정상값을 지우지 않게
    # 중앙 status 저장부에서 구 0 초기화 경로를 제거한다.
    prev: Dict[str, Any] = {}
    phase = str(extra.get("phase") or "")
    is_cycle_start_zero = (
        state == "running"
        and phase.startswith("evaluating")
        and int(float(extra.get("evaluated") or 0)) <= 0
        and int(float(extra.get("target_count") or 0)) <= 0
    )
    if is_cycle_start_zero:
        try:
            prev = load_json(STATUS, {}) or {}
        except Exception:
            prev = {}
    obj={"version":VERSION,"state":state,"pid":os.getpid(),"updated_ts":now_ts(),"updated_text":now_text(),"last_error":""}
    obj.update(extra)
    if is_cycle_start_zero and prev:
        for key in ("evaluated", "target_count", "s_count", "paper_latest_count", "s1_count", "s2_count", "s3_count", "router_target_count", "router_queue_count", "router_backlog_count", "last_sec"):
            if key in prev and (obj.get(key) in (None, "", 0, "0", "-")):
                obj[key] = prev.get(key)
        obj["status_route_schema"] = "strategy_status_v435_no_zero_cycle_start_no_40_cap"
        obj["status_route_note"] = "v436: S1/S2/S3 단순화 + cycle 시작 0 초기화 방지 + 후보 latest 고정 40개 제한 제거"
    if state == "error" and "error" in extra:
        obj["last_error"] = str(extra.get("error") or "")[:240]
    save_json(STATUS,obj)

def _event_created_ts(ev: Dict[str, Any]) -> float:
    return fnum(ev.get("created_at"), ev.get("candidate_created_at"), ev.get("source_created_at"), ev.get("detected_ts"), ev.get("event_ts"), ev.get("ts"), ev.get("timestamp"), default=0.0)

# v533 removed legacy unused function: _normalize_paper_event

def _paper_event_fresh(ev: Dict[str, Any], nowv: Optional[float] = None) -> bool:
    nowv = nowv or now_ts()
    exp = fnum(ev.get("expires_at"), default=0.0)
    ts = _event_created_ts(ev)
    if exp > 0:
        return exp >= nowv
    return ts > 0 and (nowv - ts) <= CANDIDATE_TTL_SEC

def _paper_dedupe_key(ev: Dict[str, Any]) -> str:
    t = ticker_norm(ev.get("ticker") or ev.get("market") or ev.get("symbol"))
    sk = str(ev.get("strategy_key") or ev.get("strategy_bucket_primary") or "strategy_s")
    return f"{t}:{sk}"

# v510: legacy persist_paper_handoff removed from runtime. paper_candidates_latest is written once by _v510_publish.

# v655: risk cache는 worker cycle 안에서 ticker마다 파일을 다시 읽지 않는다.
# common_hard()가 전체시장 row마다 risk_bad()를 호출하므로, 여기서 파일 I/O를
# 반복하면 strategy_worker가 4vCPU를 계속 물고 후보 fresh가 밀린다.
# 값 주인은 risk_worker 그대로이고, strategy_worker는 최신 risk cache를 1회 읽어 소비만 한다.
_V655_RISK_CACHE_MTIME: float = -1.0
_V655_RISK_CACHE_OBJ: Dict[str, Any] = {}
_V655_RISK_OPEN_SET: set = set()

def _v655_risk_cache() -> Dict[str, Any]:
    global _V655_RISK_CACHE_MTIME, _V655_RISK_CACHE_OBJ, _V655_RISK_OPEN_SET
    try:
        mt = RISK.stat().st_mtime if RISK.exists() else 0.0
    except Exception:
        mt = 0.0
    if mt != _V655_RISK_CACHE_MTIME:
        obj = load_json(RISK, {}) or {}
        _V655_RISK_CACHE_OBJ = obj if isinstance(obj, dict) else {}
        _V655_RISK_OPEN_SET = set(str(x).upper() for x in (_V655_RISK_CACHE_OBJ.get("open_tickers") or []))
        _V655_RISK_CACHE_MTIME = mt
    return _V655_RISK_CACHE_OBJ

def risk_bad(t:str)->List[str]:
    r=_v655_risk_cache(); cd=(r.get("cooldown") or {}) if isinstance(r,dict) else {}
    out=[]
    if t in cd: out.append("최근반복손실/하드손실")
    if t in _V655_RISK_OPEN_SET: out.append("이미OPEN중")
    return out
def common_hard(row:Dict[str,Any], of:Dict[str,Any])->List[str]:
    """cheap/기본 차단만 본다.
    WS/micro 부족은 여기서 붙이지 않는다.
    v0.8: 붙일 필요도 없는 후보까지 정보부족으로 보이는 문제를 막기 위해
    정보부족은 cheap gate 통과 후보에게만 별도 부여한다.
    """
    hard=[]; t=ticker_norm(row.get("ticker")); hard+=risk_bad(t)
    if row.get("major_watch"): hard.append("대형주는시장참고")
    if bool(of.get("micro_fresh")):
        spread=fnum(of.get("spread_pct"),default=0)
        buy=fnum(of.get("buy_ratio"),default=0)
        if spread>0.28: hard.append(f"스프레드넓음 {spread:.2f}%")
        if buy and buy<0.58: hard.append(f"매수체결약함 {buy:.2f}")
        if of.get("sell_pressure"): hard.append("매도벽/매도체결압력")
    if fnum(row.get("turnover_24h"))<250_000_000: hard.append("거래대금부족")
    if row.get("long_upper_wick"): hard.append("윗꼬리위험")
    if fnum(row.get("day_pos_pct"),default=50)>94 and fnum(row.get("change_5m"))<0.2: hard.append("고점끝물위험")
    return hard[:8]

def orderflow_info_bad(of:Dict[str,Any])->List[str]:
    """v0.9: strategy는 WS 단독 fresh가 아니라 표준 시세(quote_fresh)를 본다.
    quote_fresh는 orderflow_worker가 WS 또는 scanner/feature REST 현재가로 만든 canonical 시세다.
    micro는 호가·체결 판단 재료라 별도로 필요하다.
    """
    info=[]
    if not bool(of.get("quote_fresh") or of.get("ws_fresh")):
        info.append("시세정보보강대기")
    if not bool(of.get("micro_fresh")):
        info.append("micro정보보강대기")
    return info[:4]
def eval_money(r,o):
    no=[]
    if fnum(r.get("change_3m"))<0.25 or fnum(r.get("change_5m"))<0.35: no.append("3/5분재가속부족")
    if fnum(r.get("vwap_gap_pct"))<-0.05 or fnum(r.get("ema5_gap_pct"))<-0.08: no.append("VWAP/EMA유지부족")
    if not r.get("volume_expanding"): no.append("캔들거래량확장부족")
    # micro가 fresh일 때만 매수체결비를 전략 실패로 본다. fresh가 없으면 정보보강대기로 분리한다.
    if o.get("micro_fresh") and fnum(o.get("buy_ratio"))<0.65: no.append("매수체결우세부족")
    return (not no, ["돈흐름재가속","3/5분재가속","VWAP/EMA유지","체결우세"], no)
def eval_leader(r,o):
    no=[]
    if fnum(r.get("change_15m"))<0.65 or fnum(r.get("change_30m"))<0.65: no.append("15/30분주도부족")
    if fnum(r.get("relative_strength_pct"))<0.3: no.append("시장대비강도부족")
    if fnum(r.get("vwap_gap_pct"))<0 or fnum(r.get("ema5_gap_pct"))<0: no.append("VWAP/EMA위치부족")
    if r.get("market_mode") == "약함": no.append("장세약함")
    return (not no, ["15/30분주도","시장대비강함","VWAP/EMA위"], no)
def eval_breakout(r,o):
    no=[]
    if not r.get("breakout_hint"): no.append("돌파캔들미확인")
    if fnum(r.get("recent_high_gap_pct"))<-0.15: no.append("돌파후유지부족")
    if fnum(r.get("change_15m"))>5.0 and not r.get("volume_expanding"): no.append("끝물추격위험")
    return (not no, ["돌파초입","거래량확장","고점돌파유지"], no)
def eval_sweep(r,o):
    no=[]
    if not r.get("sweep_reclaim_hint"): no.append("저점쓸림회복미확인")
    if fnum(r.get("vwap_gap_pct"))<-0.05: no.append("VWAP회복부족")
    if fnum(r.get("recent_low_rebound_pct"))<0.4: no.append("저점방어반등부족")
    return (not no, ["저점이탈실패","VWAP회복","매수회복"], no)
def eval_surge(r,o):
    no=[]
    if fnum(r.get("change_15m"))<1.2: no.append("1차상승부족")
    if fnum(r.get("change_3m"))<0.15: no.append("재돌파시도부족")
    if fnum(r.get("recent_high_gap_pct"))<-0.25: no.append("고점재접근부족")
    if r.get("long_upper_wick"): no.append("윗꼬리반락위험")
    return (not no, ["급등후재돌파","얕은눌림","체결재상승"], no)


def eval_adaptive_hold(r,o):
    """v0.19/v367 주도흐름 유동보유 전략.
    시간 고정이 아니라 0~5분 검증, 5~30분 확인, 30~120분 확장으로 나눠 본다.
    """
    no=[]
    ch1=fnum(r.get("change_1m"), r.get("price_change_1m"), default=0.0)
    ch3=fnum(r.get("change_3m"), r.get("price_change_3m"), default=0.0)
    ch5=fnum(r.get("change_5m"), r.get("price_change_5m"), default=0.0)
    ch15=fnum(r.get("change_15m"), r.get("price_change_15m"), default=0.0)
    ch30=fnum(r.get("change_30m"), r.get("price_change_30m"), default=0.0)
    vwap=fnum(r.get("vwap_gap_pct"), default=-9.0)
    ema=fnum(r.get("ema5_gap_pct"), r.get("ma5_gap_pct"), default=-9.0)
    rel=fnum(r.get("relative_strength_pct"), r.get("relative_strength"), default=0.0)
    day=fnum(r.get("day_pos_pct"), r.get("current_close_pos_ratio"), default=50.0)
    high_gap=fnum(r.get("recent_high_gap_pct"), r.get("below_high_pct"), default=-9.0)
    money=fnum(r.get("turnover_24h"), default=0.0)
    buy=fnum(o.get("buy_ratio"), o.get("micro_trade_buy_ratio_30"), default=0.0)
    spread=fnum(o.get("spread_pct"), default=99.0)
    if not ((ch3 >= 0.20 and ch5 >= 0.25) or (ch15 >= 0.70 and ch30 >= 0.40) or (ch5 >= 0.80 and ch15 >= 0.40)):
        no.append("흐름유지부족")
    if vwap < -0.10 or ema < -0.15:
        no.append("VWAP/EMA유지부족")
    if rel < -1.0 and ch5 < 1.0:
        no.append("시장대비약함")
    if money < 300_000_000:
        no.append("거래대금부족")
    if o.get("micro_fresh") and buy < 0.58:
        no.append("매수체결최소부족")
    if o.get("micro_fresh") and spread > 0.30:
        no.append("스프레드과다")
    if day >= 97.0 and high_gap >= -0.05 and ch1 <= 0.05:
        no.append("고점끝물재확인필요")
    if ch5 >= 12.0 and ema >= 6.0:
        no.append("급등과열재확인필요")
    return (not no, ["주도흐름유지","유동보유","VWAP/EMA방어","시간확장후보"], no)

def _pickv(src: Dict[str, Any], *keys: str, default: Any = None) -> Any:
    for k in keys:
        if isinstance(src, dict) and src.get(k) not in (None, "", "-"):
            return src.get(k)
    return default

def _boolv(v: Any) -> bool:
    if isinstance(v, bool): return v
    return str(v).lower() in {"1", "true", "yes", "ok", "fresh", "신선"}

# v533 removed legacy unused function: _entry_snapshot

def _v361_adaptive_hold_profile(row: Dict[str, Any], of: Dict[str, Any], skey: str) -> Dict[str, Any]:
    """유동 보유형 후보별 청산/복기 프로필."""
    ch5=fnum(row.get('change_5m'), row.get('price_change_5m'), default=0.0)
    ch15=fnum(row.get('change_15m'), row.get('price_change_15m'), default=0.0)
    ch30=fnum(row.get('change_30m'), row.get('price_change_30m'), default=0.0)
    rel=fnum(row.get('relative_strength_pct'), row.get('relative_strength'), default=0.0)
    vwap=fnum(row.get('vwap_gap_pct'), default=0.0)
    ema=fnum(row.get('ema5_gap_pct'), row.get('ma5_gap_pct'), default=0.0)
    strong = (ch15 >= 1.2 and ch30 >= 0.8 and rel >= 0.3) or (ch5 >= 1.2 and ch15 >= 0.8 and vwap >= 0 and ema >= 0)
    ext_tp = 2.20 if strong else 1.80
    max_min = 120 if strong else 75
    return {
        'strategy_family': 'adaptive_hold',
        'strategy_family_label': '주도흐름 유동보유',
        'hold_model': 'adaptive_0_5_30_120',
        'phase_1': '0~5분 진입검증: 가격반응/체결지속/VWAP 방어 없으면 빠른정리',
        'phase_2': '5~30분 수익확인: +0.5~1.2% 도달·VWAP/EMA 유지 시 보유',
        'phase_3': '30~120분 확장: +1.2% 이상 도달 후 추세 유지 시 보호익절로 연장',
        'take_profit_pct': 1.20,
        'extended_target_pct': ext_tp,
        'extended_take_profit_pct': ext_tp,
        'protect_trigger_pct': 0.70,
        'protect_floor_pct': 0.35,
        'stop_loss_pct': -0.60,
        'hard_loss_guard_pct': -0.90,
        'time_exit_minutes': max_min,
        'time_exit_min': max_min,
        'early_validation_minutes': 5,
        'mid_validation_minutes': 30,
        'adaptive_hold_note': '나쁜 후보는 0~5분 검증 실패로 빨리 정리하고, +1.2% 이상 간 후보만 30~120분 확장 관찰',
    }

# v533 removed legacy unused function: build_event

def _priority_score(row: Dict[str, Any], core_hits: List[Tuple[str, List[str]]], info_bad: List[str], hard_bad: List[str]) -> float:
    score = 0.0
    score += fnum(row.get("scanner_priority_score"), default=0.0)
    score += min(30.0, max(0.0, fnum(row.get("change_3m"), default=0.0) * 8))
    score += min(30.0, max(0.0, fnum(row.get("change_5m"), default=0.0) * 6))
    score += min(25.0, max(0.0, fnum(row.get("change_15m"), default=0.0) * 3))
    score += min(20.0, max(0.0, fnum(row.get("turnover_24h"), default=0.0) / 400_000_000))
    score += 25.0 * len(core_hits)
    if info_bad:
        score += 15.0
    if hard_bad:
        score -= 35.0
    return round(score, 3)


def _make_priority_request(t: str, row: Dict[str, Any], bucket: str, priority: float, need: List[str], core_hits: List[Tuple[str, List[str]]], reasons: List[str]) -> Dict[str, Any]:
    return {
        "ticker": t,
        "bucket": bucket,
        "priority": round(priority, 3),
        "need": need,
        "core_strategies": [k for k, _ in core_hits],
        "core_strategy_labels": [STRATEGIES.get(k, k) for k, _ in core_hits],
        "reasons": reasons[:8],
        "score": fnum(row.get("scanner_priority_score"), default=0.0),
        "change_3m": fnum(row.get("change_3m"), default=0.0),
        "change_5m": fnum(row.get("change_5m"), default=0.0),
        "change_15m": fnum(row.get("change_15m"), default=0.0),
        "turnover_24h": fnum(row.get("turnover_24h"), default=0.0),
        "updated_ts": now_ts(),
        "source": "strategy_worker",
    }


def _cheap_gate(row: Dict[str, Any], core_hits: List[Tuple[str, List[str]]], hard_bad: List[str]) -> Tuple[bool, str]:
    """정보를 붙일 가치가 있는 후보인지 cheap 재료만으로 먼저 가른다.
    개수 제한이 아니라 우선순위 gate다.
    - S 코어가 맞는 후보는 정보필요 후보
    - 코어가 아직 안 맞아도 돈/흐름/캔들/VWAP가 좋은 후보는 high 후보
    - 나머지는 WS/micro를 붙일 필요 없는 cheap 탈락 후보
    """
    if hard_bad:
        return False, "hard_block"
    if core_hits:
        return True, "core_hit"
    ch3=fnum(row.get("change_3m"), default=0.0)
    ch5=fnum(row.get("change_5m"), default=0.0)
    ch15=fnum(row.get("change_15m"), default=0.0)
    money=fnum(row.get("turnover_24h"), default=0.0)
    score=fnum(row.get("scanner_priority_score"), default=0.0)
    good_flow = (ch3 >= 0.35 and ch5 >= 0.45) or (ch5 >= 0.70) or (ch15 >= 1.20)
    good_position = fnum(row.get("vwap_gap_pct"), default=-9.0) >= -0.10 and fnum(row.get("ema5_gap_pct"), default=-9.0) >= -0.12
    good_signal = bool(row.get("volume_expanding") or row.get("breakout_hint") or row.get("sweep_reclaim_hint"))
    good_money = money >= 500_000_000
    if (good_flow and good_position and (good_signal or good_money)) or (score >= 88 and good_flow):
        return True, "high_cheap"
    return False, "cheap_drop"



# =============================================================================
# strategy_worker v0.87 / v510: clean single-pass canonical spine
# - Does not call legacy run_once / tail overrides.
# - Reads feature/orderflow once, builds base/spike lanes independently, merges once.
# - Writes paper_candidates_latest once. No old_latest re-mix, no archive runtime append.
# - Publishes candidate_reason / recheck / lifecycle / summary from the same final rows.
# =============================================================================
VERSION = "strategy_worker_v0.789"
MAIN_VERSION = "v2.13.764"
MAIN_DEPLOY_VERSION = "v2.13.764"
MAIN_BOT_VERSION = "수익형 v2.13.787"
V510_SCHEMA = "strategy_canonical_spine_v525_latest_only_publish"
CANDIDATE_REASON_COMPACT_CACHE = BASE_DIR / "clean_candidate_reason_compact_cache.json"
CANDIDATE_REASON_TEXT_CACHE = BASE_DIR / "clean_candidate_reason_text_cache.txt"
CANDIDATE_REASON_STATE_CACHE = BASE_DIR / "clean_candidate_reason_state_cache.json"
CANDLE_URGENT_TARGETS = BASE_DIR / "clean_candle_urgent_targets.json"
CANDLE_URGENT_RESULT = BASE_DIR / "clean_candle_urgent_result.json"
S1_LIFECYCLE_TRACE = BASE_DIR / "clean_s1_lifecycle_trace.json"
S1_LIFECYCLE_STATE = BASE_DIR / "clean_s1_lifecycle_state.json"
# v512: main command readers have used different historical names. We write the same object
# to explicit alias files, but all aliases are produced from one final_rows payload.
# v525: legacy candidate_reason/lifecycle alias cache files are no longer published.
# Main commands read paper_candidates_latest.jsonl directly. Keeping these lists empty prevents
# old cache readers from being revived by stale files.
CANDIDATE_REASON_ALIAS_FILES: List[Path] = []
S1_LIFECYCLE_ALIAS_FILES: List[Path] = []
RECHECK_CACHE = BASE_DIR / "clean_recheck_candidates_cache.json"
RECHECK_STATE = BASE_DIR / "clean_recheck_candidates_state.json"
CANONICAL_STRATEGY_SUMMARY = BASE_DIR / "clean_strategy_canonical_summary.json"
V510_TRACE = BASE_DIR / "clean_strategy_v510_single_pass_trace.json"

_STAGE_ORDER = {"S1": 3, "S2": 2, "S3": 1}


def _v510_num(*vals: Any, default: float = 0.0) -> float:
    return fnum(*vals, default=default)


def _v510_stage(row: Dict[str, Any]) -> str:
    st = str(row.get("s_stage") or row.get("candidate_grade") or row.get("stage") or row.get("grade") or "S3").upper()
    return st if st in ("S1", "S2", "S3") else "S3"


def _v510_uniq(xs: List[Any], maxn: int = 12) -> List[str]:
    out: List[str] = []
    seen = set()
    for x in xs or []:
        s = str(x or "").strip()
        if not s or s in seen:
            continue
        seen.add(s); out.append(s)
        if len(out) >= maxn:
            break
    return out


def _v510_bool(v: Any) -> bool:
    if isinstance(v, bool): return v
    return str(v).lower() in {"1", "true", "yes", "ok", "fresh", "신선"}


def _v510_age_from_of(of: Dict[str, Any], *keys: str, default: float = 999999.0) -> float:
    return _v510_num(*[of.get(k) for k in keys], default=default)



def _v521_file_age(path: Path) -> float:
    try:
        return max(0.0, now_ts() - path.stat().st_mtime)
    except Exception:
        return 999999.0


def _v521_row_age(row: Dict[str, Any], cache_age: float, *ts_keys: str) -> float:
    # 999999 means "age field missing", not "really stale".
    for k in ("age_sec", "cache_age_sec", "row_age_sec", "updated_age_sec"):
        a = _v510_num(row.get(k), default=-1.0)
        if 0 <= a < 999998:
            return a
    for k in ts_keys or ("updated_ts", "ts", "timestamp", "created_at", "event_ts"):
        ts = _v510_num(row.get(k), default=0.0)
        if ts > 1_000_000_000:
            return max(0.0, now_ts() - ts)
    return cache_age


def _v521_load_map_with_cache_age(path: Path, cache_name: str) -> Dict[str, Dict[str, Any]]:
    obj = load_json(path, {}) or {}
    c_age = _v521_file_age(path)
    out = map_rows(obj)
    top_ts = _v510_num(obj.get("updated_ts") if isinstance(obj, dict) else 0.0, default=0.0)
    top_age = max(0.0, now_ts() - top_ts) if top_ts > 1_000_000_000 else c_age
    for t, r in list(out.items()):
        rr = dict(r)
        rr.setdefault("_cache_name", cache_name)
        rr.setdefault("_cache_age_sec", min(c_age, top_age))
        rr.setdefault("_cache_updated_ts", top_ts or now_ts() - c_age)
        out[t] = rr
    return out


def _v521_hot_map() -> Dict[str, Dict[str, Any]]:
    out = _v521_load_map_with_cache_age(SCANNER_HOT, "scanner_hot")
    c_age = _v521_file_age(SCANNER_HOT)
    for t, r in list(out.items()):
        rr = dict(r)
        if "scanner_change_1m_pct" in rr and "change_1m" not in rr:
            rr["change_1m"] = rr.get("scanner_change_1m_pct")
        if "scanner_change_3m_pct" in rr and "change_3m" not in rr:
            rr["change_3m"] = rr.get("scanner_change_3m_pct")
        rr.setdefault("hot_signal_age_sec", _v521_row_age(rr, c_age, "updated_ts", "ts", "timestamp"))
        rr.setdefault("hot_fresh", c_age <= 10)
        rr.setdefault("scanner_hot_fresh", c_age <= 10)
        out[t] = rr
    return out


def _v521_overlay_feature(src: Dict[str, Any], hot: Dict[str, Any]) -> Dict[str, Any]:
    if not hot:
        return dict(src)
    merged = dict(src)
    for k in ("scanner_hot_score", "scanner_hot_rank_1m", "scanner_hot_rank_3m", "hot_signal_age_sec", "hot_fresh", "scanner_hot_fresh"):
        if merged.get(k) in (None, "", 0, 0.0, 999999, 999999.0):
            merged[k] = hot.get(k)
    if merged.get("change_1m") in (None, "", 0, 0.0) and hot.get("change_1m") is not None:
        merged["change_1m"] = hot.get("change_1m")
    if merged.get("change_3m") in (None, "", 0, 0.0) and hot.get("change_3m") is not None:
        merged["change_3m"] = hot.get("change_3m")
    merged["_scanner_hot_cache_age_sec"] = hot.get("_cache_age_sec", _v521_file_age(SCANNER_HOT))
    return merged


def _v521_age_from_sources(primary: Dict[str, Any], secondary: Dict[str, Any], cache_key: str, keys: Tuple[str, ...], default_cache_age: float = 999999.0) -> float:
    for row in (primary, secondary):
        for k in keys:
            a = _v510_num(row.get(k), default=-1.0)
            if 0 <= a < 999998:
                return a
    for row in (primary, secondary):
        c = _v510_num(row.get(cache_key), row.get("_cache_age_sec"), default=-1.0)
        if 0 <= c < 999998:
            return c
    return default_cache_age


def _v521_value_present(row: Dict[str, Any], *keys: str) -> bool:
    for k in keys:
        v = row.get(k)
        if v in (None, "", [], {}):
            continue
        try:
            if float(str(v).replace(",", "").replace("%", "")) != 0:
                return True
        except Exception:
            return True
    return False



def _v522_parse_age_item(item: Any) -> Tuple[str, float]:
    s = str(item or "").strip()
    m = re.search(r'(hot|micro|orderflow|price|quote|paper)\s+([0-9]+(?:\.[0-9]+)?)s', s)
    if not m:
        return s, 999999.0
    return m.group(1), _v510_num(m.group(2), default=999999.0)


def _v522_filter_stale_items(items: List[Any], strict: bool = True) -> List[str]:
    # A stale reason is valid only when the component is actually over TTL.
    ttl = {
        "hot": 35.0 if strict else 60.0,
        "micro": 20.0,
        "orderflow": 20.0,
        "price": 30.0,
        "quote": 20.0,
        "paper": 45.0,
    }
    out: List[str] = []
    for raw in items or []:
        comp, a = _v522_parse_age_item(raw)
        if comp in ttl:
            if a >= ttl[comp]:
                out.append(f"{comp} {a:.1f}s")
            continue
        s = str(raw or "").strip()
        if s:
            out.append(s)
    return _v510_uniq(out, 8)


def _v522_strip_freshness_text(raw: List[Any]) -> List[str]:
    # Old route may still pass "신선도재확인:hot 0.8s" as an existing reason.
    # Remove all freshness strings here; the single gate will re-add only real stale items.
    out: List[str] = []
    for x in raw or []:
        s = str(x or "").strip()
        if not s:
            continue
        if "신선" in s or "final_entry_gate" in s:
            continue
        out.append(s)
    return out


def _v520_age_ok(age_val: float, limit: float) -> bool:
    return age_val < 999998 and age_val <= limit


def _v520_bool_any(*vals: Any) -> bool:
    for v in vals:
        try:
            if _v510_bool(v):
                return True
        except Exception:
            continue
    return False


def _v520_fresh_stale_items(src: Dict[str, Any], of: Dict[str, Any], hot_age: float, micro_age: float, order_age: float, price_age: float, quote_age: float, sealed_price: float, strict: bool = True) -> List[str]:
    """v522 single freshness gate.
    Age under TTL is fresh. Value/cache presence is a bonus, not a second stale route.
    """
    hot_cache_age = _v510_num(src.get("_scanner_hot_cache_age_sec"), src.get("_cache_age_sec"), default=999999.0)
    of_cache_age = _v510_num(of.get("_cache_age_sec"), default=999999.0)

    ch1 = _v510_num(src.get("change_1m"), src.get("price_change_1m"), src.get("scanner_change_1m_pct"), default=0.0)
    ch3 = _v510_num(src.get("change_3m"), src.get("price_change_3m"), src.get("scanner_change_3m_pct"), default=0.0)
    hot_present = max(abs(ch1), abs(ch3)) > 0 or _v521_value_present(src, "scanner_hot_score", "scanner_hot_rank_1m", "scanner_hot_rank_3m")
    micro_present = _v521_value_present(of, "buy_ratio", "micro_trade_buy_ratio_30", "trade_buy_ratio", "spread_pct", "best_bid", "best_ask")
    order_present = micro_present or _v521_value_present(of, "orderflow_score", "sell_wall_ratio", "trade_count", "buy_count", "sell_count")
    quote_present = sealed_price > 0 or _v521_value_present(of, "quote_price", "current_price", "mid_price", "best_bid", "best_ask")
    price_present = sealed_price > 0 or _v521_value_present(src, "current_price", "price", "trade_price", "close", "last_price")

    # Missing embedded age uses cache age. If either age is fresh or value exists with fresh cache, it is fresh.
    hot_ok = bool(src.get("hot_fresh") or src.get("scanner_hot_fresh")) or _v520_age_ok(hot_age, 35) or (hot_cache_age <= 12 and hot_present)
    micro_ok = bool(of.get("micro_fresh")) or _v520_age_ok(micro_age, 20) or (of_cache_age <= 12 and micro_present)
    order_ok = bool(of.get("orderflow_fresh") or of.get("trade_fresh")) or _v520_age_ok(order_age, 20) or (of_cache_age <= 12 and order_present)
    quote_ok = bool(of.get("quote_fresh") or of.get("ws_fresh") or src.get("quote_fresh") or src.get("ws_fresh")) or _v520_age_ok(quote_age, 20) or (of_cache_age <= 12 and quote_present)
    price_ok = bool(src.get("price_reaction_fresh") or src.get("feature_fresh")) or _v520_age_ok(price_age, 30) or price_present

    stale: List[str] = []
    if strict and not hot_ok:
        stale.append(f"hot {hot_age:.1f}s")
    if not quote_ok:
        stale.append(f"quote {quote_age:.1f}s")
    if not micro_ok:
        stale.append(f"micro {micro_age:.1f}s")
    if strict and not order_ok:
        stale.append(f"orderflow {order_age:.1f}s")
    if not price_ok:
        stale.append(f"price {price_age:.1f}s")
    return _v522_filter_stale_items(stale, strict=strict)[:5]




def _v520_split_reasons(raw: List[Any], stale: List[str]) -> Tuple[List[str], List[str]]:
    decision: List[str] = []
    structure: List[str] = []
    raw = _v522_strip_freshness_text(raw)
    for x in raw or []:
        s = str(x or "").strip()
        if not s:
            continue
        if s.startswith("구조:"):
            structure.append(s.replace("구조:", "", 1).strip())
            continue
        if "fresh urgent" in s or "급등 확인" in s:
            decision.append("급등확인")
            continue
        decision.append(s)
    stale = _v522_filter_stale_items(stale, strict=True)
    if stale:
        decision.append("신선도재확인:" + "/".join(stale[:3]))
    return _v510_uniq(decision, 12), _v510_uniq(structure, 8)


def _v520_normalize_reason_row(r: Dict[str, Any]) -> Dict[str, Any]:
    stale = _v522_filter_stale_items([str(x).strip() for x in (r.get("stale_reasons") or []) if str(x).strip()], strict=True)
    reasons, structures = _v520_split_reasons(list(r.get("s_stage_reasons") or []) + list(r.get("block_reasons") or []), stale)
    base_structures = r.get("structure_tags") if isinstance(r.get("structure_tags"), list) else []
    r["structure_tags"] = _v510_uniq(list(base_structures) + structures, 10)
    r["s_stage_reasons"] = reasons
    r["reason"] = " / ".join(reasons)
    r["freshness_status"] = "recheck" if stale else "fresh"
    if stale:
        r["stale_reasons"] = stale
    else:
        r["stale_reasons"] = []
    ctx = r.get("entry_context") if isinstance(r.get("entry_context"), dict) else {}
    ctx = dict(ctx)
    ctx["structure_tags"] = r["structure_tags"]
    ctx["reasons"] = reasons
    ctx["freshness_status"] = r["freshness_status"]
    ctx["stale_reasons"] = r["stale_reasons"]
    r["entry_context"] = ctx
    return r


def _v510_price_reaction(row: Dict[str, Any], of: Dict[str, Any]) -> float:
    return _v510_num(of.get("price_reaction_pct"), of.get("reaction_pct"), row.get("price_reaction_pct"), row.get("change_1m"), row.get("price_change_1m"), default=0.0)


def _v510_spread(of: Dict[str, Any], row: Dict[str, Any]) -> float:
    return _v510_num(of.get("spread_pct"), row.get("spread_pct"), default=99.0)


def _v510_buy(of: Dict[str, Any], row: Dict[str, Any]) -> float:
    return _v510_num(of.get("buy_ratio"), of.get("micro_trade_buy_ratio_30"), row.get("buy_ratio"), default=0.0)


def _v524_sustain_detail(of: Dict[str, Any], row: Dict[str, Any]) -> Tuple[float, str, bool]:
    real_keys = (
        "buy_sustain_1m", "buy_sustain_60s", "buy_persist_1m",
        "buy_flow_1m", "buy_pressure_1m", "micro_buy_sustain_1m",
    )
    for k in real_keys:
        v = _v510_num(of.get(k), default=-1.0)
        if v >= 0:
            return v, k, True
    for k in real_keys:
        v = _v510_num(row.get(k), default=-1.0)
        if v >= 0:
            return v, k, True
    fb = _v510_num(of.get("buy_ratio"), of.get("micro_trade_buy_ratio_30"), row.get("buy_ratio"), default=_v510_buy(of, row))
    return fb, "buy_ratio_fallback", False


def _v510_sustain(of: Dict[str, Any], row: Dict[str, Any]) -> float:
    return _v524_sustain_detail(of, row)[0]


def _v510_structure_tags(row: Dict[str, Any]) -> List[str]:
    tags: List[str] = []
    if row.get("sweep_reclaim_hint"): tags += ["저점유동성쓸림", "쓸림후빠른회복"]
    if row.get("breakout_hint"): tags += ["저항돌파후재테스트"]
    if _v510_num(row.get("vwap_gap_pct"), default=-9.0) >= -0.05: tags.append("VWAP방어")
    if _v510_num(row.get("ema5_gap_pct"), row.get("ma5_gap_pct"), default=-9.0) >= -0.10: tags.append("EMA방어")
    if row.get("volume_expanding"): tags.append("거래량확장")
    if _v510_num(row.get("change_3m"), default=0.0) >= 0.35: tags.append("돈흐름재유입")
    return _v510_uniq(tags, 8)


def _v510_risk_tags(row: Dict[str, Any], of: Dict[str, Any], hard: List[str]) -> List[str]:
    tags: List[str] = []
    spread = _v510_spread(of, row)
    buy = _v510_buy(of, row)
    if spread >= 0.35: tags.append("스프레드부담")
    if spread >= 0.35: tags.append("미끄러짐부담")
    if buy and buy < 0.58: tags.append("매수체결약함")
    if row.get("long_upper_wick"): tags.append("윗꼬리위험")
    if _v510_num(row.get("day_pos_pct"), default=50.0) > 94 and _v510_num(row.get("change_1m"), default=0.0) <= 0.05:
        tags.append("되돌림위험")
    for h in hard or []:
        if "매도" in h: tags.append("매도압력부담")
        if "스프레드" in h: tags.append("스프레드부담")
    return _v510_uniq(tags, 8)


def _v510_event_id(ticker: str, skey: str, lane: str, nowv: float) -> str:
    return f"{ticker}:{lane}:{skey}:{int(nowv // 10)}"



# =============================================================================
# v529: S1 체크리스트 inline helper
# - 함수 덮어쓰기/override 없음.
# - _v510_make_row/_v510_final_gate/_v510_publish 본체에서 직접 호출한다.
# - 조건값 변경 없음. 진단값만 row에 봉인한다.
# =============================================================================
def _v529_core_ok_from_row(row: Dict[str, Any]) -> bool:
    keys = row.get("matched_strategy_keys") if isinstance(row.get("matched_strategy_keys"), list) else []
    sk = str(row.get("strategy_key") or "")
    if keys:
        return any(str(k) and not str(k).startswith("hot_rank") for k in keys)
    return bool(sk and not sk.startswith("hot_rank"))


def _v544_is_hot_rank_row(row: Dict[str, Any], labels: List[Any], keys: List[Any]) -> bool:
    hay = " ".join(str(x) for x in ([row.get("strategy_label"), row.get("strategy"), row.get("strategy_key")] + list(labels or []) + list(keys or []))).lower()
    return ("hot-rank" in hay) or ("hot_rank" in hay) or ("hot rank" in hay)


def _v545_guard_text(row: Dict[str, Any], labels: List[Any], keys: List[Any], risks: List[Any], structures: List[Any]) -> str:
    return " ".join(str(x) for x in ([
        row.get("strategy_label"), row.get("strategy"), row.get("strategy_key"), row.get("paper_strategy_key")
    ] + list(labels or []) + list(keys or []) + list(risks or []) + list(structures or []))).lower()


def _v545_has_any(hay: str, words: Tuple[str, ...]) -> bool:
    return any(str(w).lower() in hay for w in words)


def _v545_strategy_recheck_reasons(row: Dict[str, Any], react: float, buy: float, sustain: float, sustain20: float, spread: float, slippage: float, chg30: float, chg60: float, risks: List[Any], structures: List[Any], labels: List[Any], keys: List[Any]) -> Tuple[List[str], List[str]]:
    """v545 multi-strategy S1 quality guard.

    This reflects v543 win/loss analysis, but never blocks by itself.
    Compound loss-like S1 rows are moved to S2 recheck; very weak low-confidence rows
    may be marked as S3 observe. Global S1/S2/S3 thresholds and exit rules are unchanged.
    """
    hay = _v545_guard_text(row, labels, keys, risks, structures)
    risk_txt = " ".join(str(x) for x in (risks or []))
    struct_txt = " ".join(str(x) for x in (structures or []))
    spread_bad = spread >= 0.45 or slippage >= 0.45 or "스프레드부담" in risk_txt or "미끄러짐부담" in risk_txt
    spread_severe = spread >= 0.65 or slippage >= 0.65
    sustain_weak = sustain < 0.70 or sustain20 < 0.55
    buy_weak = buy < 0.70
    chase_like = react >= 0.30 or chg30 >= 0.45 or chg60 >= 1.20
    vwap_ema = ("VWAP" in struct_txt or "EMA" in struct_txt)
    money_structure = ("돈흐름" in struct_txt or "거래량" in struct_txt)

    recheck: List[str] = []
    observe: List[str] = []

    # 1) hot-rank 급등 재확인: v543에서 손실군은 추격성 가격반응 + 약한 지속 + 나쁜 스프레드/미끄러짐이 반복됨.
    if _v545_has_any(hay, ("hot-rank", "hot_rank", "hot rank", "급등 재확인")):
        if spread_bad and sustain_weak and chase_like:
            recheck.append("재확인: hot-rank 추격+스프레드/지속약함")
        if spread_severe and (buy_weak or sustain_weak):
            recheck.append("재확인: hot-rank 높은 미끄러짐+체결확인 부족")

    # 2) 주도흐름 유동보유: 단순 체결/스프레드 차이는 작았고, 손실군은 고점권/되돌림/채널상단 위험이 반복됨.
    if _v545_has_any(hay, ("leader_flow_adaptive_hold", "주도흐름 유동보유")):
        overheat_hits = sum(1 for w in ("고점권가격반응약함", "되돌림위험", "채널상단과열", "윗꼬리위험") if w in risk_txt or w in struct_txt)
        if overheat_hits >= 2:
            recheck.append("재확인: 주도흐름 고점권/되돌림 위험")
        elif overheat_hits >= 1 and chase_like and sustain_weak:
            recheck.append("재확인: 주도흐름 추격+지속 약화")

    # 3) 돈흐름 재가속: 성과는 손실우세이나 단순 평균값 차이는 애매함.
    #    그래서 최근반복손실/하드손실/윗꼬리 같은 명시 위험이 있고 확인값이 충분치 않을 때만 재확인.
    if _v545_has_any(hay, ("money_reaccel", "pullback_reaccel", "돈흐름 재가속")):
        loss_like = _v545_has_any(risk_txt, ("최근반복손실", "하드손실", "윗꼬리위험", "매도압력"))
        structure_ok = bool(vwap_ema and money_structure and buy >= 0.85 and sustain >= 0.75)
        if loss_like and not structure_ok:
            recheck.append("재확인: 돈흐름 손실유사 위험+확인부족")
        elif ("윗꼬리위험" in risk_txt or "매도압력" in risk_txt) and (buy < 0.80 or sustain < 0.75):
            recheck.append("재확인: 돈흐름 윗꼬리/매도압력")

    # 4) 돌파 초입: 표본은 작지만 손실군에 거래량없는돌파가 보임. 스프레드/미끄러짐과 같이 있을 때만 재확인.
    if _v545_has_any(hay, ("breakout_early", "돌파 초입")):
        no_volume_break = "거래량없는돌파" in risk_txt or "거래량없는돌파" in struct_txt
        if no_volume_break and (spread_bad or sustain_weak):
            recheck.append("재확인: 돌파 초입 거래량없는돌파+위험부담")

    # 5) 저점 VWAP 회복: 표본은 작지만 손익비가 나빴고, 손실군은 스프레드/미끄러짐+체결 약함이 반복됨.
    #    아주 약한 조합은 paper 즉시진입보다 S3 관찰로 내린다.
    if _v545_has_any(hay, ("sweep_vwap", "저점 vwap", "저점 VWAP")):
        if spread_bad and (buy < 0.75 or sustain < 0.70):
            observe.append("관찰: 저점 VWAP 스프레드/체결약함")

    return _v510_uniq(recheck, 5), _v510_uniq(observe, 3)


def _v532_build_canonical_entry_decision(row: Dict[str, Any]) -> Dict[str, Any]:
    """v535 canonical S1 판단 원천.
    normal_common은 기존 안정형 기준을 유지하고, 급등형은 별도 entry_profile로 paper-test한다.
    """
    react = _v510_num(row.get("price_reaction_pct"), default=0.0)
    buy = _v510_num(row.get("buy_ratio"), default=0.0)
    sustain = _v510_num(row.get("buy_sustain_1m"), default=0.0)
    sustain20 = _v510_num(row.get("buy_sustain_20s"), row.get("buy_ratio_20s"), default=sustain)
    buy10 = _v510_num(row.get("buy_ratio_10s"), default=buy)
    spread = _v510_num(row.get("spread_pct"), default=99.0)
    slippage = _v510_num(row.get("slippage_pct"), default=spread)
    chg10 = _v510_num(row.get("price_chg_10s"), default=0.0)
    chg20 = _v510_num(row.get("price_chg_20s"), default=0.0)
    chg30 = _v510_num(row.get("price_chg_30s"), default=0.0)
    chg60 = _v510_num(row.get("price_chg_60s"), row.get("change_1m_pct"), default=0.0)
    accel10 = _v510_num(row.get("price_accel_10s"), default=0.0)
    accel20 = _v510_num(row.get("price_accel_20s"), default=0.0)
    spread_widen = _v510_num(row.get("spread_widening_10s"), default=0.0)
    sustain_real = bool(row.get("buy_sustain_1m_real"))
    stale = row.get("stale_reasons") if isinstance(row.get("stale_reasons"), list) else []
    risks = row.get("risk_tags") if isinstance(row.get("risk_tags"), list) else []
    structures = row.get("structure_tags") if isinstance(row.get("structure_tags"), list) else []
    hard_like = [str(x) for x in risks if any(w in str(x) for w in ("매도압력", "스프레드부담", "미끄러짐부담"))]
    upper_wick = any("윗꼬리" in str(x) for x in risks)
    sell_pressure = any("매도압력" in str(x) for x in risks)
    vwap_ema_ok = any(("VWAP" in str(x) or "EMA" in str(x)) for x in structures)
    money_ok = any(("돈흐름" in str(x) or "거래량" in str(x)) for x in structures)
    matched_labels = row.get("matched_strategy_labels") if isinstance(row.get("matched_strategy_labels"), list) else []
    matched_keys = row.get("matched_strategy_keys") if isinstance(row.get("matched_strategy_keys"), list) else []
    strategy_label = row.get("strategy_label") or row.get("strategy") or row.get("strategy_key") or "-"

    def ok_missing(checks: List[Dict[str, Any]]) -> Tuple[bool, List[Dict[str, Any]], List[str]]:
        missing = [c for c in checks if not c.get("ok")]
        return (len(missing) == 0), missing, [str(c.get("reason")) for c in missing if str(c.get("reason") or "").strip()]

    normal_checks = [
        {"name": "전략태그", "ok": True, "value": matched_labels or strategy_label, "need": "tag only", "reason": "태그", "weight": 0},
        {"name": "신선도", "ok": not bool(stale), "value": stale[:3] if stale else "-", "need": "fresh", "reason": "신선도 재확인:" + "/".join(str(x) for x in stale[:3]) if stale else "통과", "weight": 2},
        {"name": "가격반응", "ok": react >= 0.35, "value": round(react,4), "need": ">=0.35", "reason": f"가격반응 {react:+.2f}% < +0.35%", "weight": 1},
        {"name": "매수체결", "ok": buy >= 0.70, "value": round(buy,4), "need": ">=0.70", "reason": f"매수체결 {buy:.2f} < 0.70", "weight": 1},
        {"name": "1분지속", "ok": bool(sustain_real and sustain >= 0.70), "value": round(sustain,4), "need": "real >=0.70", "reason": ("1분지속 실측없음" if not sustain_real else f"1분지속 {sustain:.2f} < 0.70"), "weight": 1},
        {"name": "스프레드", "ok": spread <= 0.18, "value": round(spread,4), "need": "<=0.18", "reason": f"스프레드 {spread:.2f}% > 0.18%", "weight": 1},
        {"name": "미끄러짐", "ok": slippage <= 0.20, "value": round(slippage,4), "need": "<=0.20", "reason": f"미끄러짐 {slippage:.2f}% > 0.20%", "weight": 1},
        {"name": "강한위험", "ok": not bool(hard_like), "value": hard_like[:3], "need": "none", "reason": "위험부담:" + "/".join(hard_like[:3]) if hard_like else "통과", "weight": 1},
    ]
    normal_ok, normal_missing, normal_reasons = ok_missing(normal_checks)

    spike_signal = bool(chg20 >= 0.30 or chg30 >= 0.45 or react >= 0.70 or accel10 >= 0.18 or accel20 >= 0.22)
    late_chase = bool((chg60 >= 2.50 and (buy10 < 0.55 or spread > 0.85 or spread_widen > 0.35)) or upper_wick or (spread > 1.10) or (slippage > 1.20))
    spike_fast_checks = [
        {"name": "신선도", "ok": not bool(stale), "value": stale[:3] if stale else "-", "need": "fresh", "reason": "신선도 재확인:" + "/".join(str(x) for x in stale[:3]) if stale else "통과", "weight": 2},
        {"name": "급등초입", "ok": spike_signal, "value": {"chg20": round(chg20,3), "chg30": round(chg30,3), "react": round(react,3), "accel10": round(accel10,3)}, "need": "20s>=0.30 or 30s>=0.45 or react>=0.70", "reason": "급등초입 신호 부족", "weight": 1},
        {"name": "매수체결", "ok": buy >= 0.55, "value": round(buy,4), "need": ">=0.55", "reason": f"급등형 매수체결 {buy:.2f} < 0.55", "weight": 1},
        {"name": "짧은매수", "ok": (sustain20 >= 0.55 or buy10 >= 0.65), "value": {"buy10": round(buy10,3), "sustain20": round(sustain20,3)}, "need": "20s>=0.55 or 10s>=0.65", "reason": f"짧은 매수세 부족 10s {buy10:.2f} / 20s {sustain20:.2f}", "weight": 1},
        {"name": "스프레드", "ok": spread <= 0.85, "value": round(spread,4), "need": "<=0.85", "reason": f"급등형 스프레드 {spread:.2f}% > 0.85%", "weight": 1},
        {"name": "미끄러짐", "ok": slippage <= 0.85, "value": round(slippage,4), "need": "<=0.85", "reason": f"급등형 미끄러짐 {slippage:.2f}% > 0.85%", "weight": 1},
        {"name": "최소체결", "ok": buy >= 0.40 and sustain20 >= 0.35, "value": {"buy": round(buy,3), "sustain20": round(sustain20,3)}, "need": "buy>=0.40 & 20s>=0.35", "reason": "급등형 최소 체결/지속 미달", "weight": 2},
        {"name": "늦은추격", "ok": not late_chase, "value": {"chg60": round(chg60,3), "spread_widen": round(spread_widen,3)}, "need": "not late chase", "reason": "늦은추격 위험", "weight": 2},
        {"name": "강한위험", "ok": not bool(sell_pressure or upper_wick), "value": risks[:3], "need": "none", "reason": "급등형 매도압력/윗꼬리 위험", "weight": 2},
    ]
    spike_fast_ok, spike_fast_missing, spike_fast_reasons = ok_missing(spike_fast_checks)

    runner_signal = bool(react >= 0.80 or chg60 >= 1.20 or chg30 >= 0.90)
    spike_runner_checks = [
        {"name": "신선도", "ok": not bool(stale), "value": stale[:3] if stale else "-", "need": "fresh", "reason": "신선도 재확인:" + "/".join(str(x) for x in stale[:3]) if stale else "통과", "weight": 2},
        {"name": "runner신호", "ok": runner_signal, "value": {"react": round(react,3), "chg60": round(chg60,3)}, "need": "react>=0.80 or 60s>=1.20", "reason": "runner 가격힘 부족", "weight": 1},
        {"name": "매수체결", "ok": buy >= 0.68, "value": round(buy,4), "need": ">=0.68", "reason": f"runner 매수체결 {buy:.2f} < 0.68", "weight": 1},
        {"name": "지속", "ok": sustain20 >= 0.65 and sustain >= 0.60, "value": {"20s": round(sustain20,3), "1m": round(sustain,3)}, "need": "20s>=0.65 and 1m>=0.60", "reason": "runner 매수지속 부족", "weight": 1},
        {"name": "스프레드", "ok": spread <= 0.55, "value": round(spread,4), "need": "<=0.55", "reason": f"runner 스프레드 {spread:.2f}% > 0.55%", "weight": 1},
        {"name": "미끄러짐", "ok": slippage <= 0.65, "value": round(slippage,4), "need": "<=0.65", "reason": f"runner 미끄러짐 {slippage:.2f}% > 0.65%", "weight": 1},
        {"name": "구조", "ok": bool(vwap_ema_ok and money_ok), "value": structures[:4], "need": "VWAP/EMA + money", "reason": "runner 구조 부족", "weight": 1},
        {"name": "강한위험", "ok": not bool(sell_pressure or upper_wick), "value": risks[:3], "need": "none", "reason": "runner 매도압력/윗꼬리 위험", "weight": 2},
    ]
    spike_runner_ok, spike_runner_missing, spike_runner_reasons = ok_missing(spike_runner_checks)

    spike_ok = bool(spike_fast_ok or spike_runner_ok)
    spike_watch = bool(spike_signal or runner_signal)
    spike_missing = spike_runner_missing if spike_runner_ok else spike_fast_missing
    spike_reasons = spike_runner_reasons if spike_runner_ok else spike_fast_reasons
    spike_checks = spike_runner_checks if spike_runner_ok else spike_fast_checks

    if normal_ok:
        entry_profile = "normal_common"
        exit_profile = "normal_exit"
        active_checks = normal_checks
        active_missing = normal_missing
        active_reasons = normal_reasons
    elif spike_ok:
        # v536: 급등형 진입은 spike 하나로만 기록한다. fast/runner 세부분류는 exit_reason/성과에서 본다.
        entry_profile = "spike"
        exit_profile = "spike_trailing"
        active_checks = spike_checks
        active_missing = spike_missing
        active_reasons = spike_reasons
    else:
        entry_profile = "watch"
        exit_profile = "watch_exit"
        active_checks = spike_fast_checks if spike_watch else normal_checks
        active_missing = spike_fast_missing if spike_watch else normal_missing
        active_reasons = spike_fast_reasons if spike_watch else normal_reasons

    raw_s1_allowed = bool(normal_ok or spike_ok)
    if raw_s1_allowed:
        recheck_guard_reasons, observe_guard_reasons = _v545_strategy_recheck_reasons(row, react, buy, sustain, sustain20, spread, slippage, chg30, chg60, risks, structures, matched_labels, matched_keys)
    else:
        recheck_guard_reasons, observe_guard_reasons = [], []
    # v547 surgery: S2 재확인은 출력부에서 꾸미지 않고, canonical decision에서 stage로 봉인한다.
    # - raw S1 손실유사 조합은 S2 재확인/S3 관찰로 분리한다.
    # - raw S3라도 구조/확인값이 살아 있고 부족값이 회복 가능한 경우는 S2 재확인으로 남긴다.
    block_score_pre = sum(int(c.get("weight", 1)) for c in active_missing)
    structure_present = bool(matched_labels or matched_keys or structures)
    strong_confirm = bool(buy >= 0.70 and sustain >= 0.70)
    partial_confirm = bool(buy >= 0.55 and sustain >= 0.55)
    severe_risk = bool(spread >= 1.20 or slippage >= 1.20 or (buy < 0.40 and sustain < 0.40))
    recoverable_recheck_reasons: List[str] = []
    if (not observe_guard_reasons) and (not severe_risk) and structure_present:
        if stale and (partial_confirm or react >= 0.05 or spike_signal or runner_signal):
            recoverable_recheck_reasons.append("재확인: 신선도 갱신 대기")
        if (spread > 0.18 or slippage > 0.20) and (strong_confirm or (react >= 0.30 and partial_confirm)):
            recoverable_recheck_reasons.append("재확인: 스프레드/미끄러짐 회복 대기")
        if (buy < 0.70 or sustain < 0.70) and (buy >= 0.55 or sustain >= 0.55) and (react >= 0.05 or spike_signal or runner_signal):
            recoverable_recheck_reasons.append("재확인: 체결/1분지속 회복 대기")
        if react < 0.35 and strong_confirm and (spread <= 0.85 and slippage <= 0.85):
            recoverable_recheck_reasons.append("재확인: 가격반응 확인 대기")
    recoverable_recheck_reasons = _v510_uniq(recoverable_recheck_reasons, 4)
    # v732: 전략에 억지로 맞추는 구조가 아니라, 공통 상승포착을 본선으로 둔다.
    # 전략명은 왜 오를 수 있는지 설명하는 라벨이고, S2→S1 승급 집계는 S2 row만 본다.
    promo_hay = " ".join(str(x) for x in ([strategy_label] + list(matched_labels or []) + list(matched_keys or []) + list(structures or []))).lower()
    if any(w in promo_hay for w in ("주도흐름", "leader_flow", "leader", "유동보유")):
        promo_family_v732 = "주도흐름"
    elif any(w in promo_hay for w in ("돈흐름", "money_flow", "flow_reaccel", "재가속")):
        promo_family_v732 = "돈흐름"
    elif any(w in promo_hay for w in ("저점", "vwap", "sweep_vwap", "vwap 회복", "vwap회복")):
        promo_family_v732 = "저점VWAP"
    elif any(w in promo_hay for w in ("돌파", "breakout")):
        promo_family_v732 = "돌파"
    elif any(w in promo_hay for w in ("hot-rank", "hot_rank", "급등", "spike")):
        promo_family_v732 = "급등감지"
    else:
        promo_family_v732 = "기타"

    s2_to_s1_promotion_reasons_v732: List[str] = []
    blocked_from_promotion_v732: List[str] = []
    common_uprising_reasons_v732: List[str] = []
    common_uprising_blocked_v732: List[str] = []
    observe_row_only = bool(row.get("s3_observe_v732") or row.get("s3_observe_v729") or row.get("s3_observe_v728") or row.get("s3_observe_v727") or str(row.get("strategy_key") or "").startswith("coin_quality_s3_observe"))

    safe_risk_for_promotion = bool(
        not stale
        and not hard_like
        and not sell_pressure
        and not upper_wick
        and spread <= 0.18
        and slippage <= 0.20
        and sustain_real
        and not observe_row_only
    )
    structure_hint_for_common = bool(structure_present or vwap_ema_ok or money_ok or matched_labels or matched_keys)

    common_uprising_pass_v732 = bool(
        safe_risk_for_promotion
        and structure_hint_for_common
        and (
            (react >= 0.30 and buy >= 0.65 and sustain >= 0.70)
            or (0.22 <= react < 0.35 and buy >= 0.78 and sustain >= 0.75)
            or (react >= 0.45 and buy >= 0.70 and sustain >= 0.58)
        )
    )
    if common_uprising_pass_v732:
        common_uprising_reasons_v732.append("공통 상승포착: 가격반응+체결+지속+위험낮음")
        s2_to_s1_promotion_reasons_v732.append("공통 상승포착 S2→S1: 전략라벨 무관 상승조건 통과")
    else:
        if observe_row_only:
            common_uprising_blocked_v732.append("S3 관찰 row는 상승포착 OPEN 제외")
        if stale:
            common_uprising_blocked_v732.append("신선도 부족")
        if hard_like or sell_pressure or upper_wick:
            common_uprising_blocked_v732.append("위험태그/매도압력 우세")
        if spread > 0.18 or slippage > 0.20:
            common_uprising_blocked_v732.append("스프레드/미끄러짐 부담")
        if not sustain_real:
            common_uprising_blocked_v732.append("1분지속 실측없음")
        if not structure_hint_for_common:
            common_uprising_blocked_v732.append("구조 힌트 부족")
        if react < 0.22:
            common_uprising_blocked_v732.append("가격반응 부족")
        if buy < 0.65:
            common_uprising_blocked_v732.append("매수체결 부족")
        if sustain < 0.58:
            common_uprising_blocked_v732.append("1분지속 부족")

    # 전략별 문구는 보조 설명이다. 공통 상승포착이 통과하면 전략별 부족문구로 다시 막지 않는다.
    if not common_uprising_pass_v732:
        if observe_row_only:
            blocked_from_promotion_v732.append("S3 관찰/복기 row: S1 승급 금지")
        elif not safe_risk_for_promotion:
            if stale:
                blocked_from_promotion_v732.append(f"{promo_family_v732} 신선도 부족: S1 승급 금지")
            if hard_like or sell_pressure or upper_wick:
                blocked_from_promotion_v732.append(f"{promo_family_v732} 위험태그 우세: S1 승급 금지")
            if spread > 0.18 or slippage > 0.20:
                blocked_from_promotion_v732.append(f"{promo_family_v732} 스프레드/미끄러짐 부담: S1 승급 금지")
            if not sustain_real:
                blocked_from_promotion_v732.append(f"{promo_family_v732} 1분지속 실측없음: S1 승급 금지")
        if promo_family_v732 == "급등감지":
            if buy < 0.55 or sustain20 < 0.55 or sustain < 0.55:
                blocked_from_promotion_v732.append("급등감지 체결/짧은지속 부족: S1 승급 금지")
        elif promo_family_v732 == "주도흐름":
            if sustain < 0.58:
                blocked_from_promotion_v732.append("주도흐름 1분지속 부족: S1 승급 금지")
            elif buy < 0.65:
                blocked_from_promotion_v732.append("주도흐름 매수체결 부족: S1 승급 금지")
            elif react < 0.22:
                blocked_from_promotion_v732.append("주도흐름 가격반응 부족: S1 승급 금지")
        elif promo_family_v732 == "돈흐름":
            if buy < 0.65 or sustain < 0.58:
                blocked_from_promotion_v732.append("돈흐름 체결지속 부족: S1 승급 금지")
        elif promo_family_v732 == "저점VWAP":
            if not vwap_ema_ok:
                blocked_from_promotion_v732.append("저점VWAP 회복근거 부족: S1 승급 금지")
            elif buy < 0.65 or sustain < 0.58:
                blocked_from_promotion_v732.append("저점VWAP 체결지속 부족: S1 승급 금지")
        elif promo_family_v732 == "돌파":
            if react < 0.35:
                blocked_from_promotion_v732.append("돌파 가격반응 부족: S1 승급 금지")
            elif sustain20 < 0.60 or sustain < 0.58:
                blocked_from_promotion_v732.append("돌파 짧은지속 부족: S1 승급 금지")

    common_uprising_reasons_v732 = _v510_uniq(common_uprising_reasons_v732, 3)
    common_uprising_blocked_v732 = _v510_uniq(common_uprising_blocked_v732, 5)
    blocked_from_promotion_v732 = _v510_uniq(blocked_from_promotion_v732, 5)
    s2_to_s1_promotion_reasons_v732 = _v510_uniq(s2_to_s1_promotion_reasons_v732, 3)
    s2_to_s1_promoted_v732 = bool(s2_to_s1_promotion_reasons_v732 and not blocked_from_promotion_v732)
    if s2_to_s1_promoted_v732:
        recoverable_recheck_reasons = [r for r in recoverable_recheck_reasons if all(w not in str(r) for w in ("가격반응", "체결/1분지속", "스프레드/미끄러짐"))]
        active_missing = [c for c in active_missing if str(c.get("name") or "") not in ("가격반응", "매수체결", "1분지속", "스프레드", "미끄러짐", "S2재확인", "S3관찰")]
        active_reasons = [r for r in active_reasons if all(w not in str(r) for w in ("가격반응", "매수체결", "1분지속", "스프레드", "미끄러짐"))]
        active_checks = list(active_checks) + [{"name": "공통상승포착", "ok": True, "value": common_uprising_reasons_v732, "need": "rising coin capture", "reason": "통과", "weight": 0}]
        entry_profile = "normal_common"
        exit_profile = "normal_exit"

    recheck_all_reasons = _v510_uniq(list(recheck_guard_reasons) + list(recoverable_recheck_reasons), 6)
    if s2_to_s1_promoted_v732:
        recheck_all_reasons = [r for r in recheck_all_reasons if "가격반응" not in str(r)]
        observe_guard_reasons = []
    guard_reasons = list(recheck_all_reasons) + list(observe_guard_reasons)
    s1_allowed = bool((raw_s1_allowed and not guard_reasons) or s2_to_s1_promoted_v732)
    if guard_reasons:
        active_missing = list(active_missing) + [
            {"name": "S2재확인" if str(reason).startswith("재확인") else "S3관찰", "ok": False, "value": reason, "need": "recheck/observe", "reason": reason, "weight": 1}
            for reason in guard_reasons
        ]
        active_reasons = list(active_reasons) + guard_reasons
    block_score = sum(int(c.get("weight", 1)) for c in active_missing)
    s2_recheck = bool((recheck_all_reasons and not observe_guard_reasons) or ((not guard_reasons) and (not severe_risk) and structure_present and block_score <= 6 and ((react >= 0.15 and buy >= 0.55) or spike_signal or runner_signal or strong_confirm)))
    near = bool(block_score <= 3 or bool(recoverable_recheck_reasons))
    passed = [str(c.get("name")) for c in active_checks if c.get("ok")]
    raw_entry_profile = entry_profile
    if guard_reasons:
        entry_profile = "watch"
        exit_profile = "watch_exit"
    return {
        "schema": "canonical_entry_decision_v732_promotion_stage_spine",
        "version": VERSION,
        "strategy_role": "tag",
        "entry_profile": entry_profile,
        "exit_profile": exit_profile,
        "profile_family": "spike" if entry_profile == "spike" else ("normal" if entry_profile == "normal_common" else "watch"),
        "matched_strategy_keys": matched_keys,
        "matched_strategy_labels": matched_labels or [str(strategy_label)],
        "gate_pass": s1_allowed,
        "raw_s1_allowed": raw_s1_allowed,
        "s1_allowed": s1_allowed,
        "s2_to_s1_promoted_v732": bool(s2_to_s1_promoted_v732),
        "s2_to_s1_promotion_reasons_v732": s2_to_s1_promotion_reasons_v732,
        "s2_to_s1_promotion_blocked_v732": blocked_from_promotion_v732,
        "s2_to_s1_promotion_family_v732": promo_family_v732,
        "common_uprising_pass_v732": bool(common_uprising_pass_v732),
        "common_uprising_reasons_v732": common_uprising_reasons_v732,
        "common_uprising_blocked_v732": common_uprising_blocked_v732,
        "s1_recheck_guard": bool(guard_reasons),
        "s1_recheck_guard_reasons": guard_reasons,
        "s1_recheck_reasons": recheck_all_reasons,
        "s2_recheck_reasons": recheck_all_reasons,
        "s1_observe_reasons": observe_guard_reasons,
        "s1_recheck_basis": "v547 surgery: recheck reasons are sealed as visible S2 in canonical stage spine, not patched in output",
        "s2_recheck": bool(s2_recheck and not s1_allowed),
        "recoverable_recheck_reasons": recoverable_recheck_reasons,
        "action": "paper_open_candidate" if s1_allowed else ("recheck" if s2_recheck else "observe"),
        "freshness_ok": not bool(stale),
        "stale_reasons": list(stale),
        "checks": active_checks,
        "passed_conditions": passed,
        "missing_conditions": active_reasons,
        "missing_names": [str(c.get("name")) for c in active_missing],
        "block_count": len(active_missing),
        "block_score": block_score,
        "s1_distance": block_score,
        "s1_near_miss": near,
        "s1_near_miss_level": "near" if near else ("mid" if block_score <= 5 else "far"),
        "display_reasons": active_reasons,
        "profile_decisions": {
            "normal_common": {"pass": normal_ok, "missing": normal_reasons[:6]},
            "spike": {"pass": spike_ok, "missing": spike_reasons[:6], "fast_pass": spike_fast_ok, "runner_pass": spike_runner_ok},
            "watch": {"pass": False, "missing": active_reasons[:6]},
            "raw_entry_profile": raw_entry_profile,
        },
        "metrics": {
            "price_reaction_pct": react,
            "price_chg_10s": chg10,
            "price_chg_20s": chg20,
            "price_chg_30s": chg30,
            "price_chg_60s": chg60,
            "price_accel_10s": accel10,
            "price_accel_20s": accel20,
            "buy_ratio": buy,
            "buy_ratio_10s": buy10,
            "buy_sustain_20s": sustain20,
            "buy_sustain_1m": sustain,
            "buy_sustain_1m_real": sustain_real,
            "spread_pct": spread,
            "slippage_pct": slippage,
            "spread_widening_10s": spread_widen,
        },
        "policy": "v732: common uprising pass is resealed to actual S1 before publish; strategy family remains label/diagnostic.",
    }


def _v532_apply_canonical_entry_decision(row: Dict[str, Any]) -> Dict[str, Any]:
    if not isinstance(row, dict):
        return row
    dec = _v532_build_canonical_entry_decision(row)
    row["canonical_entry_decision"] = dec
    row["common_entry_decision"] = dec
    row["common_entry_pass"] = bool(dec.get("s1_allowed"))
    row["common_entry_schema"] = dec.get("schema")
    row["strategy_role"] = "tag"
    row["entry_profile"] = dec.get("entry_profile")
    row["exit_profile"] = dec.get("exit_profile")
    row["profile_family"] = dec.get("profile_family")
    row["profile_decisions"] = dec.get("profile_decisions", {})
    row["s1_checklist"] = dec.get("checks", [])
    row["s1_passed_conditions"] = dec.get("passed_conditions", [])
    row["s1_missing_conditions"] = dec.get("missing_conditions", [])
    row["s1_missing_names"] = dec.get("missing_names", [])
    row["s1_block_count"] = dec.get("block_count", 0)
    row["s1_block_score"] = dec.get("block_score", 0)
    row["s1_distance"] = dec.get("s1_distance", 0)
    row["s1_near_miss"] = bool(dec.get("s1_near_miss"))
    row["s1_near_miss_level"] = dec.get("s1_near_miss_level")
    row["s1_short_reason"] = " / ".join(str(x) for x in (dec.get("display_reasons") or [])[:4]) if dec.get("display_reasons") else "S1 조건 통과"
    row["s2_to_s1_promoted_v732"] = bool(dec.get("s2_to_s1_promoted_v732"))
    row["s2_to_s1_promotion_reasons_v732"] = dec.get("s2_to_s1_promotion_reasons_v732") or []
    row["s2_to_s1_promotion_blocked_v732"] = dec.get("s2_to_s1_promotion_blocked_v732") or []
    row["s2_to_s1_promotion_family_v732"] = dec.get("s2_to_s1_promotion_family_v732") or "-"
    row["common_uprising_pass_v732"] = bool(dec.get("common_uprising_pass_v732"))
    row["common_uprising_reasons_v732"] = dec.get("common_uprising_reasons_v732") or []
    row["common_uprising_blocked_v732"] = dec.get("common_uprising_blocked_v732") or []
    observe_row_only_v732 = bool(row.get("s3_observe_v732") or row.get("s3_observe_v729") or row.get("s3_observe_v728") or row.get("s3_observe_v727") or str(row.get("strategy_key") or "").startswith("coin_quality_s3_observe"))
    if bool(dec.get("s1_allowed")) and not observe_row_only_v732:
        row["s_stage"] = row["candidate_stage"] = row["candidate_grade"] = row["stage"] = row["grade"] = "S1"
        row["open_eligible"] = True
        row["paper_bot_open"] = True
        row["trade_ready"] = True
    elif observe_row_only_v732:
        row["s_stage"] = row["candidate_stage"] = row["candidate_grade"] = row["stage"] = row["grade"] = "S3"
        row["open_eligible"] = False
        row["paper_bot_open"] = False
        row["trade_ready"] = False
        row["recheck_state"] = "S3 관찰/복기"
    elif bool(dec.get("s2_recheck") or dec.get("action") == "recheck"):
        # v547: 재확인 사유가 있으면 출력 보정이 아니라 canonical stage를 S2로 봉인한다.
        row["s_stage"] = row["candidate_stage"] = row["candidate_grade"] = row["stage"] = row["grade"] = "S2"
        row["open_eligible"] = False
        row["paper_bot_open"] = False
        row["trade_ready"] = False
        row["recheck_state"] = "S2 재확인"
        row["s2_recheck_reasons"] = dec.get("s2_recheck_reasons") or dec.get("s1_recheck_reasons") or []
    elif _v510_stage(row) == "S1":
        row["s_stage"] = row["candidate_stage"] = row["candidate_grade"] = row["stage"] = row["grade"] = "S3"
        row["open_eligible"] = False
        row["paper_bot_open"] = False
        row["trade_ready"] = False
    else:
        st = _v510_stage(row)
        row["s_stage"] = row["candidate_stage"] = row["candidate_grade"] = row["stage"] = row["grade"] = st
        if st != "S1":
            row["open_eligible"] = False
            row["paper_bot_open"] = False
            row["trade_ready"] = False
    ctx = row.get("entry_context") if isinstance(row.get("entry_context"), dict) else {}
    ctx = dict(ctx)
    for k in (
        "canonical_entry_decision", "common_entry_decision", "common_entry_pass", "common_entry_schema", "strategy_role",
        "entry_profile", "exit_profile", "profile_family", "profile_decisions",
        "s1_checklist", "s1_passed_conditions", "s1_missing_conditions", "s1_missing_names",
        "s1_block_count", "s1_block_score", "s1_distance", "s1_near_miss", "s1_near_miss_level", "s1_short_reason", "s2_recheck_reasons", "recheck_state", "s2_to_s1_promoted_v732", "s2_to_s1_promotion_reasons_v732", "s2_to_s1_promotion_blocked_v732", "s2_to_s1_promotion_family_v732", "common_uprising_pass_v732", "common_uprising_reasons_v732", "common_uprising_blocked_v732",
    ):
        ctx[k] = row.get(k)
    row["entry_context"] = ctx
    return row


# =============================================================================
# v553: 매수판단 정보 재분류 spine
# - 조건 수치/청산/S1 판정은 바꾸지 않는다.
# - strategy row 안에서 구조/확인/위험/신선도/재확인/차단/진입근거를 분리해 봉인한다.
# - paper_bot은 이 필드만 읽어 알림을 만든다. 위험태그를 진입근거로 출력하지 않는다.
# =============================================================================
def _v553_as_list(v: Any) -> List[str]:
    if v in (None, "", [], {}):
        return []
    raw = v if isinstance(v, list) else [v]
    out: List[str] = []
    for x in raw:
        if isinstance(x, dict):
            txt = str(x.get("reason") or x.get("name") or x.get("value") or "").strip()
        else:
            txt = str(x).strip()
        if txt and txt not in out:
            out.append(txt)
    return out


def _v553_has(txt: str, words: Tuple[str, ...]) -> bool:
    low = str(txt or "").lower()
    return any(str(w).lower() in low for w in words)


def _v553_bucket_reason(txt: str) -> str:
    t = str(txt or "").strip()
    if not t:
        return "other"
    if t.startswith("구조:") or _v553_has(t, ("저점", "쓸림", "VWAP", "EMA", "거래량확장", "돈흐름", "돌파", "재돌파", "주도", "상대강도", "눌림")):
        # 부족/위험 문장에 VWAP 같은 단어가 섞일 수 있으니 위험/부족을 먼저 제외한다.
        if _v553_has(t, ("부족", "미확인", "실패", "위험", "과다", "약함", "대기", "재확인", "차단", "손실", "고점끝물")):
            pass
        else:
            return "structure"
    if t.startswith("재확인") or _v553_has(t, ("갱신 대기", "회복 대기", "확인 대기", "hot-rank 급등 재확인", "신선도 재확인")):
        return "recheck"
    if _v553_has(t, ("스프레드", "미끄러짐", "매도", "윗꼬리", "되돌림", "늦은추격", "추격", "하드손실", "반복손실", "고점끝물", "거래대금부족", "대형주는시장참고")):
        return "risk"
    if _v553_has(t, ("micro", "시세정보", "정보보강", "신선도", "오래됨", "stale", "quote", "ws")):
        return "freshness"
    if _v553_has(t, ("부족", "미달", "약함", "미확인", "과다", "<", ">")):
        return "block"
    return "other"


def _v553_confirm_signals(row: Dict[str, Any], dec: Dict[str, Any]) -> List[str]:
    sig: List[str] = []
    passed = _v553_as_list(dec.get("passed_conditions") or row.get("s1_passed_conditions"))
    metrics = dec.get("metrics") if isinstance(dec.get("metrics"), dict) else {}
    react = _v510_num(metrics.get("price_reaction_pct"), row.get("price_reaction_pct"), default=0.0)
    buy = _v510_num(metrics.get("buy_ratio"), row.get("buy_ratio"), default=-1.0)
    sustain = _v510_num(metrics.get("buy_sustain_1m"), row.get("buy_sustain_1m"), default=-1.0)
    spread = _v510_num(metrics.get("spread_pct"), row.get("spread_pct"), default=99.0)
    slip = _v510_num(metrics.get("slippage_pct"), row.get("slippage_pct"), default=spread)
    if "신선도" in passed or dec.get("freshness_ok"):
        sig.append("신선도 통과")
    if react >= 0.35:
        sig.append(f"가격반응 통과 {react:+.2f}%")
    if buy >= 0.70:
        sig.append(f"매수체결 통과 {buy:.2f}")
    if sustain >= 0.70:
        sig.append(f"1분지속 통과 {sustain:.2f}")
    if spread <= 0.18:
        sig.append(f"스프레드 정상 {spread:.2f}%")
    if slip <= 0.20:
        sig.append(f"미끄러짐 정상 {slip:.2f}%")
    for p in passed:
        if p in {"급등초입", "짧은매수", "runner신호", "구조"} and p not in sig:
            sig.append(str(p) + " 통과")
    return _v510_uniq(sig, 10)


def _v553_apply_reason_taxonomy(row: Dict[str, Any]) -> Dict[str, Any]:
    if not isinstance(row, dict):
        return row
    dec = row.get("canonical_entry_decision") if isinstance(row.get("canonical_entry_decision"), dict) else {}
    raw_reasons = _v553_as_list(row.get("s_stage_reasons") or row.get("reason"))
    structures = _v510_uniq(_v553_as_list(row.get("structure_tags")) + _v553_as_list(row.get("matched_strategy_labels")), 12)
    risk_tags = _v510_uniq(_v553_as_list(row.get("risk_tags")), 12)
    freshness = _v510_uniq(_v553_as_list(row.get("stale_reasons")), 10)
    rechecks = _v510_uniq(_v553_as_list(dec.get("s2_recheck_reasons")) + _v553_as_list(row.get("s2_recheck_reasons")), 10)
    blocks = _v510_uniq(_v553_as_list(dec.get("missing_conditions")) + _v553_as_list(row.get("s1_missing_conditions")), 12)

    # 기존 s_stage_reasons/reason에 섞인 텍스트를 의미별로 분리한다.
    for txt in raw_reasons:
        b = _v553_bucket_reason(txt)
        clean = txt.replace("구조:", "").strip()
        if b == "structure":
            structures.append(clean)
        elif b == "risk":
            risk_tags.append(clean)
        elif b == "freshness":
            freshness.append(clean)
        elif b == "recheck":
            rechecks.append(clean)
        elif b == "block":
            blocks.append(clean)

    structures = _v510_uniq(structures, 12)
    risk_tags = _v510_uniq(risk_tags, 12)
    freshness = _v510_uniq(freshness, 10)
    rechecks = _v510_uniq(rechecks, 10)
    blocks = _v510_uniq(blocks, 12)
    confirm = _v553_confirm_signals(row, dec)

    # 진입근거는 좋은 구조 + 실제 확인 통과만 넣는다. 위험/부족/재확인은 절대 섞지 않는다.
    entry_reasons = _v510_uniq(structures[:5] + confirm[:5], 10)
    if not entry_reasons and bool(dec.get("s1_allowed")):
        entry_reasons = ["최종확인 통과"]

    row["reason_taxonomy_schema"] = "v553_entry_structure_confirm_risk_split"
    row["entry_structure_tags"] = structures
    row["confirm_signals"] = confirm
    row["execution_risk_tags"] = risk_tags
    row["freshness_flags"] = freshness
    row["recheck_reasons"] = rechecks
    row["block_reasons"] = blocks
    row["entry_reasons"] = entry_reasons
    row["final_entry_reasons"] = entry_reasons
    row["trade_ready_reasons"] = entry_reasons if bool(row.get("trade_ready") or row.get("open_eligible") or _v510_stage(row) == "S1") else []
    row["risk_tags"] = risk_tags
    row["structure_risk_tags"] = risk_tags
    row["missing_info"] = _v510_uniq(rechecks + blocks + freshness, 12)
    row["entry_reason_policy"] = "v553: 진입근거는 구조/확인만, 위험·재확인·부족은 별도 필드로 분리"

    ctx = row.get("entry_context") if isinstance(row.get("entry_context"), dict) else {}
    ctx = dict(ctx)
    for k in (
        "reason_taxonomy_schema", "entry_structure_tags", "confirm_signals", "execution_risk_tags",
        "freshness_flags", "recheck_reasons", "block_reasons", "entry_reasons", "final_entry_reasons",
        "trade_ready_reasons", "risk_tags", "structure_risk_tags", "missing_info", "entry_reason_policy",
    ):
        ctx[k] = row.get(k)
    row["entry_context"] = ctx
    return row


# =============================================================================
# v554: structure levels + S2 entry plan spine
# - Conditions/exits are not changed here.
# v555: ENTRY_PLAN_STATE 정의 누락 수정.
# v556: entry plan state를 실제 생애주기 spine으로 안정화.
# - Every strategy row receives structure_levels / entry_plan / risk_reward.
# - S2 means "entry-plan waiting candidate" rather than a vague maybe-candidate.
# =============================================================================
def _v554_price_from_gap(price: float, gap_pct: float) -> float:
    try:
        if price <= 0:
            return 0.0
        denom = 1.0 + (float(gap_pct) / 100.0)
        if abs(denom) < 0.0001:
            return 0.0
        return price / denom
    except Exception:
        return 0.0


def _v554_pct_to_price(price: float, pctv: float) -> float:
    try:
        return price * (1.0 + float(pctv) / 100.0) if price > 0 else 0.0
    except Exception:
        return 0.0


def _v554_pct_between(a: float, b: float) -> float:
    return ((a - b) / b * 100.0) if b else 0.0


def _v554_round_price(x: float) -> float:
    if not x or x <= 0:
        return 0.0
    if x >= 100000:
        return round(x, -2)
    if x >= 10000:
        return round(x, -1)
    if x >= 1000:
        return round(x, 0)
    if x >= 100:
        return round(x, 1)
    if x >= 10:
        return round(x, 2)
    if x >= 1:
        return round(x, 3)
    return round(x, 5)


def _v554_strategy_family(row: Dict[str, Any]) -> str:
    sk = str(row.get("strategy_key") or row.get("paper_strategy_key") or "").lower()
    labels = " ".join(str(x) for x in (row.get("matched_strategy_labels") or [])) + " " + str(row.get("strategy_label") or row.get("strategy") or "")
    hay = (sk + " " + labels).lower()
    if "money_reaccel" in hay or "돈흐름 재가속" in labels:
        return "money_reaccel"
    if "sweep_vwap" in hay or "저점 vwap" in hay or "저점 VWAP" in labels:
        return "sweep_vwap"
    if "leader_flow" in hay or "주도흐름 유동보유" in labels:
        return "leader_flow"
    if "leader_momentum" in hay or "주도추세 지속" in labels:
        return "leader_momentum"
    if "breakout" in hay or "돌파 초입" in labels:
        return "breakout"
    if "surge_rebreak" in hay or "급등 후 재돌파" in labels:
        return "surge_rebreak"
    if "hot_rank" in hay or "hot-rank" in hay:
        return "hot_rank"
    return "common"


def _v554_build_structure_levels(row: Dict[str, Any]) -> Dict[str, Any]:
    price = _v510_num(row.get("current_price"), row.get("entry_price"), row.get("price"), default=0.0)
    if price <= 0:
        return {"schema": "structure_levels_v554", "available": False, "reason": "price_missing"}
    fam = _v554_strategy_family(row)
    vwap_gap = _v510_num(row.get("vwap_gap_pct"), row.get("vwap_pos_pct"), row.get("vwap_position_pct"), default=0.0)
    ema_gap = _v510_num(row.get("ema5_gap_pct"), row.get("ema5_pos_pct"), row.get("ma5_gap_pct"), default=0.0)
    high_gap = _v510_num(row.get("recent_high_gap_pct"), row.get("below_high_pct"), row.get("high_gap_pct"), default=0.0)
    low_rebound = _v510_num(row.get("recent_low_rebound_pct"), row.get("low_rebound_pct"), default=0.0)
    react = _v510_num(row.get("price_reaction_pct"), default=0.0)
    ch1 = _v510_num(row.get("change_1m_pct"), row.get("change_1m"), default=0.0)
    ch3 = _v510_num(row.get("change_3m_pct"), row.get("change_3m"), default=0.0)
    spread = _v510_num(row.get("spread_pct"), default=0.0)

    vwap_price = _v554_price_from_gap(price, vwap_gap)
    ema_price = _v554_price_from_gap(price, ema_gap)
    recent_high = _v554_price_from_gap(price, high_gap) if abs(high_gap) > 0.0001 else 0.0
    recent_low = _v554_price_from_gap(price, low_rebound) if low_rebound > 0.0001 else 0.0

    supports = [x for x in (vwap_price, ema_price, recent_low, _v554_pct_to_price(price, -0.45)) if x and x < price * 1.003]
    resistances = [x for x in (recent_high, _v554_pct_to_price(price, 0.30 + min(max(react, 0.0), 1.2) * 0.15)) if x and x > price * 0.997]
    support = max([x for x in supports if x < price] or [_v554_pct_to_price(price, -0.45)])
    resistance = min([x for x in resistances if x > price] or [_v554_pct_to_price(price, 0.60)])

    # Strategy-specific structure line interpretation. These are plan/reference levels,
    # not new entry/exit thresholds.
    if fam == "money_reaccel":
        trigger = max(resistance, _v554_pct_to_price(price, 0.18))
        invalid = min(support, _v554_pct_to_price(price, -0.35))
        target1 = max(resistance, _v554_pct_to_price(trigger, 0.65))
        target2 = max(target1, _v554_pct_to_price(trigger, 1.20))
        plan_type = "눌림후 재가속 방아쇠"
        reason = "눌림 고점/직전 저항 재돌파 + 돈흐름 유지"
    elif fam == "sweep_vwap":
        trigger = max(vwap_price or price, _v554_pct_to_price(price, 0.10))
        invalid = min(recent_low or support, _v554_pct_to_price(price, -0.40))
        target1 = max(resistance, _v554_pct_to_price(trigger, 0.70))
        target2 = max(target1, _v554_pct_to_price(trigger, 1.25))
        plan_type = "저점쓸림 후 VWAP 회복 방아쇠"
        reason = "VWAP 재회복 + 저점 재이탈 없음"
    elif fam == "leader_flow":
        trigger = max(resistance, _v554_pct_to_price(price, 0.16))
        invalid = min(vwap_price or support, ema_price or support, _v554_pct_to_price(price, -0.45))
        target1 = max(resistance, _v554_pct_to_price(trigger, 0.55))
        target2 = max(target1, _v554_pct_to_price(trigger, 1.10))
        plan_type = "주도흐름 눌림회복 방아쇠"
        reason = "VWAP/EMA 방어 후 직전 고점 재접근"
    elif fam == "leader_momentum":
        trigger = max(resistance, _v554_pct_to_price(price, 0.20))
        invalid = min(vwap_price or support, ema_price or support, _v554_pct_to_price(price, -0.50))
        target1 = max(resistance, _v554_pct_to_price(trigger, 0.70))
        target2 = max(target1, _v554_pct_to_price(trigger, 1.35))
        plan_type = "주도추세 지속 돌파 방아쇠"
        reason = "주도성 유지 + 저항 재돌파"
    elif fam in {"breakout", "surge_rebreak", "hot_rank"}:
        trigger = max(resistance, _v554_pct_to_price(price, 0.25))
        invalid = min(support, _v554_pct_to_price(price, -0.50))
        target1 = max(resistance, _v554_pct_to_price(trigger, 0.55))
        target2 = max(target1, _v554_pct_to_price(trigger, 1.05))
        plan_type = "돌파/재돌파 방아쇠"
        reason = "저항 돌파 + 돌파선 위 유지"
    else:
        trigger = max(resistance, _v554_pct_to_price(price, 0.20))
        invalid = min(support, _v554_pct_to_price(price, -0.45))
        target1 = max(resistance, _v554_pct_to_price(trigger, 0.65))
        target2 = max(target1, _v554_pct_to_price(trigger, 1.15))
        plan_type = "공통 구조 방아쇠"
        reason = "구조선 도달 + 확인신호 통과"

    expected_up = _v554_pct_between(target1, price)
    expected_down = abs(_v554_pct_between(invalid, price))
    rr = (expected_up / expected_down) if expected_down > 0 else 0.0
    late_chase = bool((ch1 >= 1.80 or ch3 >= 3.20 or react >= 1.80) and fam in {"leader_flow", "leader_momentum", "breakout", "hot_rank", "surge_rebreak"})
    if spread >= 0.60:
        late_chase = True
    status = "triggered" if price >= trigger * 0.999 else "waiting"
    return {
        "schema": "structure_levels_v554_all_strategy",
        "available": True,
        "strategy_family": fam,
        "current_price": _v554_round_price(price),
        "support_price": _v554_round_price(support),
        "resistance_price": _v554_round_price(resistance),
        "trigger_price": _v554_round_price(trigger),
        "invalid_price": _v554_round_price(invalid),
        "target1_price": _v554_round_price(target1),
        "target2_price": _v554_round_price(target2),
        "distance_to_trigger_pct": round(_v554_pct_between(trigger, price), 3),
        "distance_to_invalid_pct": round(_v554_pct_between(invalid, price), 3),
        "expected_upside_pct": round(expected_up, 3),
        "expected_downside_pct": round(-abs(expected_down), 3),
        "expected_downside_abs_pct": round(abs(expected_down), 3),
        "rr_ratio": round(rr, 2),
        "plan_type": plan_type,
        "trigger_reason": reason,
        "target_reason": "다음 저항/구조 목표 우선, 기존 고정 청산은 유지",
        "stop_reason": "구조 무효화 가격. 실제 paper 손절조건은 변경 없음",
        "late_chase_flag": late_chase,
        "late_chase_basis": {"change_1m": round(ch1, 3), "change_3m": round(ch3, 3), "reaction": round(react, 3), "spread": round(spread, 3)},
        "late_chase_reason": ("가격반응/단기상승/스프레드 기준 늦은추격" if late_chase else ""),
        "status": status,
    }


def _v554_apply_entry_plan(row: Dict[str, Any], state: Dict[str, Any], nowv: float) -> Dict[str, Any]:
    if not isinstance(row, dict):
        return row
    out = dict(row)
    t = ticker_norm(out.get("ticker") or out.get("market") or out.get("symbol"))
    sk = str(out.get("strategy_key") or out.get("paper_strategy_key") or "-")
    fam = _v554_strategy_family(out)
    # v556: state key는 매 cycle마다 바뀔 수 있는 세부 strategy_key보다
    # ticker + strategy family를 우선한다. 기존 v554/v555 key도 migrate해서
    # first_seen/S2/S1 생애주기가 끊기지 않게 한다.
    key = f"{t}:{fam}" if t else fam
    legacy_keys = [f"{t}:{sk}" if t else sk, str(t or ""), f"{t}:common" if t else "common"]
    price = _v510_num(out.get("current_price"), out.get("entry_price"), out.get("price"), default=0.0)
    prev = state.get(key) if isinstance(state.get(key), dict) else {}
    if not prev:
        for lk in legacy_keys:
            if lk and isinstance(state.get(lk), dict):
                prev = dict(state.get(lk) or {})
                break
    event_key_v750 = str(out.get("event_key") or out.get("event_id") or "")
    event_ts_v750 = _v510_num(out.get("candidate_created_at"), out.get("source_created_at"), out.get("event_ts"), out.get("detected_ts"), out.get("created_at"), default=nowv)
    prev_last_seen_v750 = _v510_num(prev.get("last_seen_ts"), default=0.0)
    prev_first_v750 = _v510_num(prev.get("first_seen_ts"), default=0.0)
    prev_event_key_v752 = str(prev.get("event_key") or "") if isinstance(prev, dict) else ""
    stage_pre_v752 = _v510_stage(out)
    source_age_v752 = max(0.0, nowv - event_ts_v750) if event_ts_v750 else 999999.0
    # v752: S1/S2 이상 fresh source는 구 first_seen/S2_seen을 계속 끌고 가지 않는다.
    # 오래된 후보를 차단하는 게 아니라, 새 source row 기준으로 생애주기를 다시 시작해 paper가 최신 row를 판단하게 한다.
    reset_lifecycle_v750 = False
    reset_reason_v750 = ""
    if prev and prev_last_seen_v750 and nowv - prev_last_seen_v750 > 300:
        reset_lifecycle_v750 = True
        reset_reason_v750 = f"last_seen_gap {nowv - prev_last_seen_v750:.0f}s > 300s"
    if prev and stage_pre_v752 in {"S1", "S2"} and source_age_v752 <= 120 and prev_first_v750 and nowv - prev_first_v750 > 300:
        reset_lifecycle_v750 = True
        reset_reason_v750 = f"fresh {stage_pre_v752} source resets legacy first_seen {nowv - prev_first_v750:.0f}s"
    if prev and stage_pre_v752 == "S1" and source_age_v752 <= 120 and prev_event_key_v752 and event_key_v750 and prev_event_key_v752 != event_key_v750:
        reset_lifecycle_v750 = True
        reset_reason_v750 = f"new S1 event_key {event_key_v750} resets prev {prev_event_key_v752}"
    if prev and prev_first_v750 and nowv - prev_first_v750 > 7200 and event_ts_v750 and nowv - event_ts_v750 <= 120:
        reset_lifecycle_v750 = True
        reset_reason_v750 = f"legacy first_seen {nowv - prev_first_v750:.0f}s with fresh source"
    if reset_lifecycle_v750:
        out["entry_timing_reset_v750"] = True
        out["entry_timing_reset_reason_v750"] = reset_reason_v750
        prev = {}
    first_ts = _v510_num(prev.get("first_seen_ts"), default=0.0) or event_ts_v750 or nowv
    first_price = _v510_num(prev.get("first_seen_price"), default=0.0) or price
    structure_ts = _v510_num(prev.get("structure_seen_ts"), default=0.0) or event_ts_v750 or nowv
    structure_price = _v510_num(prev.get("structure_seen_price"), default=0.0) or price
    stage = _v510_stage(out)
    if stage == "S2":
        s2_ts = _v510_num(prev.get("s2_seen_ts"), default=0.0) or nowv
        s2_price = _v510_num(prev.get("s2_price"), default=0.0) or price
        s1_ts = _v510_num(prev.get("s1_seen_ts"), default=0.0)
        s1_price = _v510_num(prev.get("s1_price"), default=0.0)
    elif stage == "S1":
        s2_ts = _v510_num(prev.get("s2_seen_ts"), default=0.0) or nowv
        s2_price = _v510_num(prev.get("s2_price"), default=0.0) or price
        s1_ts = _v510_num(prev.get("s1_seen_ts"), default=0.0) or nowv
        s1_price = _v510_num(prev.get("s1_price"), default=0.0) or price
    else:
        s2_ts = _v510_num(prev.get("s2_seen_ts"), default=0.0)
        s2_price = _v510_num(prev.get("s2_price"), default=0.0)
        s1_ts = _v510_num(prev.get("s1_seen_ts"), default=0.0)
        s1_price = _v510_num(prev.get("s1_price"), default=0.0)

    levels = _v554_build_structure_levels(out)
    entry_plan = {
        "schema": "entry_plan_v554_s2_trigger_waiting",
        "role": "S2=진입계획 대기 / S1=방아쇠+확인통과 / S3=구조관찰",
        "plan_type": levels.get("plan_type") or "구조선 대기",
        "trigger_price": levels.get("trigger_price"),
        "trigger_reason": levels.get("trigger_reason"),
        "invalid_price": levels.get("invalid_price"),
        "target1_price": levels.get("target1_price"),
        "target2_price": levels.get("target2_price"),
        "required_confirm": ["신선도", "가격반응", "매수체결", "1분지속", "스프레드/미끄러짐 정상"],
        "cancel_conditions": ["무효화 가격 이탈", "강한 매도압력", "스프레드/미끄러짐 과다", "늦은추격 위험"],
        "timeout_sec": 180 if stage != "S1" else 70,
        "status": "paper_open_ready" if stage == "S1" else ("entry_plan_wait" if stage == "S2" else "structure_observe"),
    }
    timing = {
        "schema": "entry_timing_spine_v554",
        "first_seen_ts": first_ts,
        "first_seen_price": _v554_round_price(first_price),
        "structure_seen_ts": structure_ts,
        "structure_seen_price": _v554_round_price(structure_price),
        "s2_seen_ts": s2_ts,
        "s2_price": _v554_round_price(s2_price),
        "s1_seen_ts": s1_ts,
        "s1_price": _v554_round_price(s1_price),
        "first_to_s1_delay_sec": round(max(0.0, s1_ts - first_ts), 1) if s1_ts else None,
        "s2_to_s1_delay_sec": round(max(0.0, s1_ts - s2_ts), 1) if s1_ts and s2_ts else None,
        "first_to_now_delay_sec": round(max(0.0, nowv - first_ts), 1),
        "s2_to_now_delay_sec": round(max(0.0, nowv - s2_ts), 1) if s2_ts else None,
        "first_to_current_delay_sec": round(max(0.0, nowv - first_ts), 1),
        "s2_to_current_delay_sec": round(max(0.0, nowv - s2_ts), 1) if s2_ts else None,
        "first_to_now_return_pct": round(_v554_pct_between(price, first_price), 3) if first_price else 0.0,
        "s2_to_now_return_pct": round(_v554_pct_between(price, s2_price), 3) if s2_price else 0.0,
        "first_to_current_return_pct": round(_v554_pct_between(price, first_price), 3) if first_price else 0.0,
        "s2_to_current_return_pct": round(_v554_pct_between(price, s2_price), 3) if s2_price else 0.0,
        "s1_to_now_return_pct": round(_v554_pct_between(price, s1_price), 3) if s1_price else 0.0,
        "late_chase_flag": bool(levels.get("late_chase_flag")),
        "late_chase_reason": levels.get("late_chase_reason") or "",
        "state_key": key,
        "event_key_v750": event_key_v750,
        "event_key_v752": event_key_v750,
        "source_event_age_sec_v750": round(max(0.0, nowv - event_ts_v750), 1) if event_ts_v750 else None,
        "source_event_age_sec_v752": round(source_age_v752, 1) if source_age_v752 < 999999 else None,
        "lifecycle_reset_v750": bool(out.get("entry_timing_reset_v750")),
        "lifecycle_reset_reason_v750": out.get("entry_timing_reset_reason_v750") or "",
    }
    rr = {
        "schema": "risk_reward_v556_structure_target",
        "expected_upside_pct": levels.get("expected_upside_pct"),
        "expected_downside_pct": levels.get("expected_downside_pct"),
        "expected_downside_abs_pct": levels.get("expected_downside_abs_pct"),
        "rr_ratio": levels.get("rr_ratio"),
        "target_reason": levels.get("target_reason"),
        "stop_reason": levels.get("stop_reason"),
    }
    out["structure_levels"] = levels
    out["entry_plan"] = entry_plan
    out["risk_reward"] = rr
    out["entry_timing_spine"] = timing
    out["late_chase_flag"] = bool(levels.get("late_chase_flag"))
    out["late_chase_basis"] = levels.get("late_chase_basis")
    if bool(out.get("late_chase_flag")):
        risks = out.get("risk_tags") if isinstance(out.get("risk_tags"), list) else []
        out["risk_tags"] = _v510_uniq(list(risks) + ["늦은추격위험"], 12)
        out["execution_risk_tags"] = out["risk_tags"]
    ctx = out.get("entry_context") if isinstance(out.get("entry_context"), dict) else {}
    ctx = dict(ctx)
    ctx.update({"structure_levels": levels, "entry_plan": entry_plan, "risk_reward": rr, "entry_timing_spine": timing, "late_chase_flag": out.get("late_chase_flag"), "late_chase_basis": out.get("late_chase_basis"), "late_chase_reason": levels.get("late_chase_reason")})
    out["entry_context"] = ctx
    state[key] = {
        "ticker": t,
        "strategy_key": sk,
        "first_seen_ts": first_ts,
        "first_seen_price": first_price,
        "structure_seen_ts": structure_ts,
        "structure_seen_price": structure_price,
        "s2_seen_ts": s2_ts,
        "s2_price": s2_price,
        "s1_seen_ts": s1_ts,
        "s1_price": s1_price,
        "last_seen_ts": nowv,
        "last_seen_price": price,
        "last_stage": stage,
        "event_key": event_key_v750,
        "event_ts": event_ts_v750,
        "strategy_family": fam,
        "state_key": key,
        "seen_count": int(_v510_num(prev.get("seen_count"), default=0.0)) + 1,
    }
    return out


def _v554_apply_entry_plan_state(rows: List[Dict[str, Any]], nowv: float) -> List[Dict[str, Any]]:
    obj = load_json(ENTRY_PLAN_STATE, {}) or {}
    state = obj.get("items") if isinstance(obj, dict) and isinstance(obj.get("items"), dict) else (obj if isinstance(obj, dict) else {})
    # old/no-longer-seen state is short-lived; it is only for timing/plan continuity.
    for k in list(state.keys()):
        try:
            if nowv - float(state.get(k, {}).get("last_seen_ts") or 0.0) > 1800:
                state.pop(k, None)
        except Exception:
            state.pop(k, None)
    out = [_v554_apply_entry_plan(r, state, nowv) for r in rows if isinstance(r, dict)]
    save_json(ENTRY_PLAN_STATE, {"schema": "entry_plan_state_v556_lifecycle", "version": VERSION, "updated_ts": nowv, "updated_text": now_text(nowv), "count": len(state), "items": state})
    return out

def _v510_make_row(src: Dict[str, Any], of: Dict[str, Any], stage: str, skey: str, label: str, lane: str, score: float, reasons: List[str], nowv: float, hard: Optional[List[str]] = None) -> Dict[str, Any]:
    t = ticker_norm(src.get("ticker") or src.get("market") or src.get("symbol"))
    react = _v510_price_reaction(src, of)
    spread = _v510_spread(of, src)
    buy = _v510_buy(of, src)
    sustain, sustain_source, sustain_real = _v524_sustain_detail(of, src)
    # v519: paper_bot OPEN 필수 가격값을 strategy canonical row에서 봉인한다.
    sealed_price = _v510_num(
        src.get("current_price"), src.get("price"), src.get("trade_price"), src.get("close"), src.get("last_price"),
        of.get("quote_price"), of.get("current_price"), of.get("price"), of.get("trade_price"), of.get("last_price"),
        of.get("mid_price"), of.get("best_bid"), of.get("bid_price"),
        default=0.0,
    )
    hot_age = _v521_age_from_sources(src, of, "_scanner_hot_cache_age_sec", ("hot_signal_age_sec", "hot_age_sec"), default_cache_age=_v521_file_age(SCANNER_HOT))
    micro_age = _v521_age_from_sources(of, src, "_cache_age_sec", ("micro_age_sec", "trade_age_sec"), default_cache_age=_v510_num(of.get("_cache_age_sec"), default=999999.0))
    order_age = _v521_age_from_sources(of, src, "_cache_age_sec", ("orderflow_age_sec", "trade_age_sec", "micro_age_sec"), default_cache_age=micro_age)
    price_age = _v521_age_from_sources(src, of, "_cache_age_sec", ("price_reaction_age_sec", "price_age_sec", "feature_age_sec"), default_cache_age=0.0)
    quote_age = _v521_age_from_sources(of, src, "_cache_age_sec", ("quote_age_sec", "ws_age_sec"), default_cache_age=_v510_num(of.get("_cache_age_sec"), default=999999.0))
    stale_items = _v520_fresh_stale_items(src, of, hot_age, micro_age, order_age, price_age, quote_age, sealed_price, strict=True)
    decision_reasons, reason_structure_tags = _v520_split_reasons(reasons, stale_items)
    row = {
        "schema": "paper_candidate_v520_reason_spine_row",
        "version": VERSION,
        "ticker": t,
        "market": f"KRW-{t}" if t else src.get("market"),
        "symbol": f"{t}_KRW" if t else src.get("symbol"),
        "event_id": _v510_event_id(t, skey, lane, nowv),
        "event_key": _v510_event_id(t, skey, lane, nowv),
        "created_at": nowv,
        "candidate_created_at": nowv,
        "source_created_at": nowv,
        "detected_ts": nowv,
        "event_ts": nowv,
        "created_at_text": now_text(nowv),
        "updated_ts": nowv,
        "expires_at": nowv + (70 if stage == "S1" else 180),
        "strategy_key": skey,
        "paper_strategy_key": skey,
        "strategy_label": label,
        "strategy": label,
        "matched_strategy_keys": list(src.get("_matched_strategy_keys") or [skey]),
        "matched_strategy_labels": list(src.get("_matched_strategy_labels") or [label]),
        "canonical_lane": lane,
        "s_stage": stage,
        "candidate_stage": stage,
        "candidate_grade": stage,
        "stage": stage,
        "grade": stage,
        "score": round(score, 3),
        "current_price": sealed_price,
        "entry_price": sealed_price,
        "detected_price": sealed_price,
        "live_price": sealed_price,
        "price": sealed_price,
        "trade_price": sealed_price,
        "price_source": "strategy_v522_sealed",
        "price_ready": bool(sealed_price and sealed_price > 0),
        "price_reaction_pct": round(react, 4),
        "spread_pct": round(spread, 4),
        "slippage_pct": round(spread, 4),
        "buy_ratio": round(buy, 4),
        "buy_sustain_1m": round(sustain, 4),
        "buy_sustain_1m_source": sustain_source,
        "buy_sustain_1m_real": bool(sustain_real),
        "buy_sustain_1m_is_fallback": not bool(sustain_real),
        "sustain_source": sustain_source,
        "change_1m_pct": _v510_num(src.get("change_1m"), src.get("price_change_1m"), default=0.0),
        "change_3m_pct": _v510_num(src.get("change_3m"), src.get("price_change_3m"), default=0.0),
        "change_5m_pct": _v510_num(src.get("change_5m"), src.get("price_change_5m"), default=0.0),
        "price_chg_5s": _v510_num(of.get("price_chg_5s"), src.get("price_chg_5s"), default=0.0),
        "price_chg_10s": _v510_num(of.get("price_chg_10s"), src.get("price_chg_10s"), default=0.0),
        "price_chg_20s": _v510_num(of.get("price_chg_20s"), src.get("price_chg_20s"), default=0.0),
        "price_chg_30s": _v510_num(of.get("price_chg_30s"), src.get("price_chg_30s"), default=0.0),
        "price_chg_60s": _v510_num(of.get("price_chg_60s"), src.get("price_chg_60s"), default=0.0),
        "price_accel_10s": _v510_num(of.get("price_accel_10s"), src.get("price_accel_10s"), default=0.0),
        "price_accel_20s": _v510_num(of.get("price_accel_20s"), src.get("price_accel_20s"), default=0.0),
        "buy_ratio_5s": _v510_num(of.get("buy_ratio_5s"), src.get("buy_ratio_5s"), default=buy),
        "buy_ratio_10s": _v510_num(of.get("buy_ratio_10s"), src.get("buy_ratio_10s"), default=buy),
        "buy_sustain_20s": _v510_num(of.get("buy_sustain_20s"), src.get("buy_sustain_20s"), default=sustain),
        "trade_burst_10s": _v510_num(of.get("trade_burst_10s"), src.get("trade_burst_10s"), default=0.0),
        "spread_widening_10s": _v510_num(of.get("spread_widening_10s"), src.get("spread_widening_10s"), default=0.0),
        "spike_fast_ready": bool(of.get("spike_fast_ready") or src.get("spike_fast_ready")),
        "hot_signal_age_sec": hot_age,
        "micro_age_sec": micro_age,
        "orderflow_age_sec": order_age,
        "price_reaction_age_sec": price_age,
        "quote_age_sec": quote_age,
        "structure_tags": _v510_uniq(_v510_structure_tags(src) + reason_structure_tags, 10),
        "risk_tags": _v510_risk_tags(src, of, hard or []),
        "stale_reasons": stale_items,
        "freshness_status": "recheck" if stale_items else "fresh",
        "official_structure_inputs_raw": {},
        "reason": " / ".join(decision_reasons),
        "s_stage_reasons": decision_reasons,
    }
    # v597: preserve official candle/structure inputs from feature/candle source row.
    # These are evidence fields, not new strategy conditions. Missing stays missing; no 0 fallback.
    _official_pack = {}
    for _ok in V597_OFFICIAL_STRUCTURE_KEYS:
        _ov = src.get(_ok)
        if _ov not in (None, ""):
            row[_ok] = _ov
            _official_pack[_ok] = _ov
    if _official_pack:
        row["official_structure_inputs_raw"] = _official_pack

    row["entry_context"] = {
        "strategy_key": skey,
        "strategy_label": label,
        "canonical_lane": lane,
        "structure_tags": row["structure_tags"],
        "risk_tags": row["risk_tags"],
        "hot_signal_age_sec": hot_age,
        "micro_age_sec": micro_age,
        "orderflow_age_sec": order_age,
        "price_reaction_age_sec": price_age,
        "quote_age_sec": quote_age,
        "freshness_status": "recheck" if stale_items else "fresh",
        "stale_reasons": stale_items,
        "current_price": sealed_price,
        "entry_price": sealed_price,
        "detected_price": sealed_price,
        "live_price": sealed_price,
        "price": sealed_price,
        "price_ready": bool(sealed_price and sealed_price > 0),
        "price_source": "strategy_v522_sealed",
        "price_reaction_pct": react,
        "buy_ratio": buy,
        "buy_sustain_1m": sustain,
        "buy_sustain_1m_source": sustain_source,
        "buy_sustain_1m_real": bool(sustain_real),
        "buy_sustain_1m_is_fallback": not bool(sustain_real),
        "spread_pct": spread,
        "price_chg_20s": row.get("price_chg_20s"),
        "price_chg_30s": row.get("price_chg_30s"),
        "price_chg_60s": row.get("price_chg_60s"),
        "price_accel_10s": row.get("price_accel_10s"),
        "buy_ratio_10s": row.get("buy_ratio_10s"),
        "buy_sustain_20s": row.get("buy_sustain_20s"),
        "spread_widening_10s": row.get("spread_widening_10s"),
        "reasons": row["s_stage_reasons"],
    }
    row = _v532_apply_canonical_entry_decision(row)
    row = _v553_apply_reason_taxonomy(row)
    return row


def _v510_final_gate(row: Dict[str, Any], nowv: float) -> Dict[str, Any]:
    r = dict(row)
    stage = _v510_stage(r)
    skey = str(r.get("strategy_key") or "")
    is_spike = skey in {"spike_momentum_ride", "spike_pullback_reaccel"}
    hot = _v510_num(r.get("hot_signal_age_sec"), default=999999.0)
    micro = _v510_num(r.get("micro_age_sec"), default=999999.0)
    order = _v510_num(r.get("orderflow_age_sec"), default=micro)
    price = _v510_num(r.get("price_reaction_age_sec"), default=999999.0)
    quote = _v510_num(r.get("quote_age_sec"), default=999999.0)
    paper_delay = max(0.0, nowv - _event_created_ts(r))
    sealed_price = _v510_num(r.get("current_price"), r.get("entry_price"), r.get("price"), default=0.0)
    stale: List[str] = _v520_fresh_stale_items(r, r, hot, micro, order, price, quote, sealed_price, strict=is_spike)
    if is_spike and paper_delay > 20:
        stale.append(f"paper {paper_delay:.1f}s")
    elif (not is_spike) and paper_delay > 45:
        stale.append(f"paper {paper_delay:.1f}s")
    stale = _v522_filter_stale_items(_v510_uniq(stale, 6), strict=is_spike)
    allowed = not stale
    if stage == "S1" and not allowed:
        r["v510_downgraded_from_s1"] = True
        r["s_stage"] = r["candidate_stage"] = r["candidate_grade"] = r["stage"] = r["grade"] = "S2"
        rr = list(r.get("s_stage_reasons") or []) + ["final_entry_gate 신선도 재확인: " + " / ".join(stale[:5])]
        r["s_stage_reasons"] = _v510_uniq(rr, 12)
    r["stale_reasons"] = stale
    r = _v520_normalize_reason_row(r)
    r["fresh_gate_ok"] = bool(allowed)
    r = _v532_apply_canonical_entry_decision(r)
    decision = r.get("canonical_entry_decision") if isinstance(r.get("canonical_entry_decision"), dict) else {}
    final_allowed = bool(decision.get("s1_allowed") and allowed)
    if not final_allowed and _v510_stage(r) == "S1":
        r["v510_downgraded_from_s1"] = True
        target_stage = "S2" if (stale or decision.get("s2_recheck") or decision.get("action") == "recheck") else "S3"
        r["s_stage"] = r["candidate_stage"] = r["candidate_grade"] = r["stage"] = r["grade"] = target_stage
    r["open_eligible"] = bool(final_allowed)
    r["paper_bot_open"] = bool(final_allowed)
    r["trade_ready"] = bool(final_allowed)
    r["v510_final_entry_gate"] = {
        "schema": "final_entry_gate_v536_profile_simplified",
        "version": VERSION,
        "checked_ts": nowv,
        "age_values": {"hot": hot, "micro": micro, "orderflow": order, "price": price, "quote": quote, "paper": paper_delay},
        "stale_reasons": stale,
        "s1_allowed": bool(final_allowed),
        "policy": "v536: canonical_entry_decision with simplified entry_profile; paper_candidates_latest.jsonl is canonical",
    }
    ctx = r.get("entry_context") if isinstance(r.get("entry_context"), dict) else {}
    ctx = dict(ctx); ctx["v510_final_entry_gate"] = r["v510_final_entry_gate"]
    r["entry_context"] = ctx
    dec = r.get("canonical_entry_decision") if isinstance(r.get("canonical_entry_decision"), dict) else {}
    if isinstance(dec, dict):
        dec = dict(dec)
        dec["v510_final_entry_gate"] = r["v510_final_entry_gate"]
        dec["s1_allowed"] = bool(final_allowed)
        dec["gate_pass"] = bool(final_allowed)
        dec["action"] = "paper_open_candidate" if final_allowed else ("recheck" if dec.get("s2_recheck") else "observe")
        r["canonical_entry_decision"] = dec
        r["common_entry_decision"] = dec
        r["entry_context"]["canonical_entry_decision"] = dec
        r["entry_context"]["common_entry_decision"] = dec
    r = _v553_apply_reason_taxonomy(r)
    return r


def _v510_base_lane(nowv: float, feature_list: List[Dict[str, Any]], ofmap: Dict[str, Dict[str, Any]]) -> Tuple[List[Dict[str, Any]], List[Dict[str, Any]], List[Dict[str, Any]]]:
    evals=[("leader_flow_adaptive_hold_s",eval_adaptive_hold),("money_reaccel_s",eval_money),("leader_momentum_s",eval_leader),("breakout_early_s",eval_breakout),("sweep_vwap_recovery_s",eval_sweep),("surge_rebreak_s",eval_surge)]
    rows: List[Dict[str, Any]] = []
    rejects: List[Dict[str, Any]] = []
    requests: List[Dict[str, Any]] = []
    for src in feature_list:
        t = ticker_norm(src.get("ticker") or src.get("market") or src.get("symbol"))
        if not t: continue
        of = ofmap.get(t, {}) or {}
        hard = common_hard(src, of)
        core_hits: List[Tuple[str, List[str]]] = []
        core_fail: List[str] = []
        for skey, fn in evals:
            ok, why, no = fn(src, of)
            if ok: core_hits.append((skey, why))
            else: core_fail += [f"{STRATEGIES.get(skey, skey)}:{x}" for x in no[:2]]
        need_info, cheap_bucket = _cheap_gate(src, core_hits, hard)
        info_bad = orderflow_info_bad(of) if need_info else []
        react = _v510_price_reaction(src, of)
        buy = _v510_buy(of, src)
        sustain, sustain_source, sustain_real = _v524_sustain_detail(of, src)
        spread = _v510_spread(of, src)
        score = _priority_score(src, core_hits, info_bad, hard)
        reasons: List[str] = []
        skey = core_hits[0][0] if core_hits else "leader_flow_adaptive_hold_s"
        label = STRATEGIES.get(skey, skey).replace(" S", "")
        if core_hits:
            reasons += [f"구조:{STRATEGIES.get(k,k)}" for k,_ in core_hits[:2]]
        reasons += hard[:4] + info_bad[:3]
        if react < 0.05: reasons.append("가격반응 기준근접(+0.00%→+0.05%)")
        if react < 0.35: reasons.append("가격반응 약함(+0.05%→+0.35%)")
        if buy < 0.70: reasons.append(f"매수체결 0.70 미만({buy:.2f})")
        if sustain < 0.70 and sustain_real:
            reasons.append("1분 매수지속 부족")
        elif sustain < 0.70 and not sustain_real:
            reasons.append("1분지속 실측없음(buy_ratio대체)")
        if spread > 0.35: reasons.append(f"스프레드 과다({spread:.2f}%)")
        elif spread > 0.18: reasons.append(f"스프레드 경계값({spread:.2f}%)→재확인")
        stage = ""
        common_s2 = (not hard and react >= 0.15 and buy >= 0.55 and spread <= 0.35)
        if core_hits or common_s2 or (need_info and cheap_bucket in {"core_hit", "high_cheap"}) or score >= 88:
            # S1 is not decided here. _v532_apply_canonical_entry_decision is the only S1 source.
            stage = "S2" if (core_hits or react >= 0.25 or score >= 105 or common_s2) else "S3"
        elif cheap_bucket == "high_cheap":
            stage = "S3"
        if not stage:
            rejects.append({"ticker": t, "score": score, "reasons": _v510_uniq(reasons + core_fail, 8), "updated_ts": nowv})
            continue
        src_for_row = dict(src)
        src_for_row["_matched_strategy_keys"] = [k for k, _ in core_hits] or [skey, "common_rise_entry"]
        src_for_row["_matched_strategy_labels"] = [STRATEGIES.get(k, k) for k, _ in core_hits] or [label, "공통상승조건"]
        row = _v510_make_row(src_for_row, of, stage, skey, label, "base", score, reasons or ["구조관찰"], nowv, hard)
        rows.append(row)
        need = []
        if not _v510_bool(of.get("quote_fresh") or of.get("ws_fresh")): need.append("quote")
        if not _v510_bool(of.get("micro_fresh")): need.append("micro")
        requests.append(_make_priority_request(t, src, "s_candidate" if stage == "S1" else "recheck_candidate", 100 + score + _STAGE_ORDER.get(stage,1)*20, need or ["micro"], core_hits, row.get("s_stage_reasons") or []))
    return rows, rejects, requests


def _v510_spike_lane(nowv: float, feature_list: List[Dict[str, Any]], ofmap: Dict[str, Dict[str, Any]]) -> List[Dict[str, Any]]:
    rows: List[Dict[str, Any]] = []
    for src in feature_list:
        t = ticker_norm(src.get("ticker") or src.get("market") or src.get("symbol"))
        if not t: continue
        of = ofmap.get(t, {}) or {}
        ch1 = _v510_num(src.get("change_1m"), src.get("price_change_1m"), default=0.0)
        ch3 = _v510_num(src.get("change_3m"), src.get("price_change_3m"), default=0.0)
        react = _v510_price_reaction(src, of)
        short20 = _v510_num(of.get("price_chg_20s"), src.get("price_chg_20s"), default=0.0)
        short30 = _v510_num(of.get("price_chg_30s"), src.get("price_chg_30s"), default=0.0)
        accel10 = _v510_num(of.get("price_accel_10s"), src.get("price_accel_10s"), default=0.0)
        # Wide prefilter only. It does not cap candidates.
        if max(ch1, ch3, react, short20, short30, accel10) < 0.30:
            continue
        spread = _v510_spread(of, src); buy = _v510_buy(of, src); sustain, sustain_source, sustain_real = _v524_sustain_detail(of, src)
        hot_age = _v521_age_from_sources(src, of, "_scanner_hot_cache_age_sec", ("hot_signal_age_sec", "hot_age_sec"), default_cache_age=_v521_file_age(SCANNER_HOT))
        micro_age = _v521_age_from_sources(of, src, "_cache_age_sec", ("micro_age_sec", "trade_age_sec"), default_cache_age=_v510_num(of.get("_cache_age_sec"), default=999999.0))
        order_age = _v521_age_from_sources(of, src, "_cache_age_sec", ("orderflow_age_sec", "trade_age_sec", "micro_age_sec"), default_cache_age=micro_age)
        price_age = _v521_age_from_sources(src, of, "_cache_age_sec", ("price_reaction_age_sec", "price_age_sec", "feature_age_sec"), default_cache_age=0.0)
        quote_age = _v521_age_from_sources(of, src, "_cache_age_sec", ("quote_age_sec", "ws_age_sec"), default_cache_age=_v510_num(of.get("_cache_age_sec"), default=999999.0))
        sealed_price_probe = _v510_num(
            src.get("current_price"), src.get("price"), src.get("trade_price"), src.get("close"), src.get("last_price"),
            of.get("quote_price"), of.get("current_price"), of.get("price"), of.get("trade_price"), of.get("last_price"),
            of.get("mid_price"), of.get("best_bid"), of.get("bid_price"),
            default=0.0,
        )
        fresh = not _v520_fresh_stale_items(src, of, hot_age, micro_age, order_age, price_age, quote_age, sealed_price_probe, strict=True)
        evals=[("leader_flow_adaptive_hold_s",eval_adaptive_hold),("money_reaccel_s",eval_money),("leader_momentum_s",eval_leader),("breakout_early_s",eval_breakout),("sweep_vwap_recovery_s",eval_sweep),("surge_rebreak_s",eval_surge)]
        core_hits: List[Tuple[str, List[str]]] = []
        for _skey, _fn in evals:
            _ok, _why, _no = _fn(src, of)
            if _ok:
                core_hits.append((_skey, _why))
        # S1 is not decided here. _v532_apply_canonical_entry_decision is the only S1 source.
        strong = (react >= 0.80 or ch1 >= 0.70 or ch3 >= 1.20) and buy >= 0.78 and sustain >= 0.78 and spread <= 0.18
        late_risk = (buy < 0.70 or sustain < 0.70 or spread > 0.35 or row_bool(src, "long_upper_wick"))
        stage = "S2" if (fresh and (react >= 0.35 or strong) and spread <= 0.50) else "S3"
        if core_hits:
            skey = core_hits[0][0]
            label = STRATEGIES.get(skey, skey).replace(" S", "")
        else:
            skey = "hot_rank_recheck"
            label = "hot-rank 급등 재확인"
        reasons: List[str] = []
        if stage == "S1":
            reasons.append("fresh urgent 급등 확인")
        elif core_hits:
            reasons.append("급등확인 재확인")
        else:
            reasons.append("hot-rank 급등 재확인")
        if buy < 0.70: reasons.append(f"매수체결 0.70 미만({buy:.2f})")
        if sustain < 0.70 and sustain_real:
            reasons.append("1분 매수지속 부족")
        elif sustain < 0.70 and not sustain_real:
            reasons.append("1분지속 실측없음(buy_ratio대체)")
        if spread > 0.35: reasons.append(f"스프레드 과다({spread:.2f}%)")
        score = 100 + max(0.0, react)*10 + max(0.0, ch1)*4 + max(0.0, ch3)*3 + max(0.0, buy)*2 + max(0.0, short20)*5 + max(0.0, accel10)*4
        src_for_row = dict(src)
        src_for_row["_matched_strategy_keys"] = [k for k, _ in core_hits] or [skey, "common_rise_entry"]
        src_for_row["_matched_strategy_labels"] = [STRATEGIES.get(k, k) for k, _ in core_hits] or [label, "공통상승조건"]
        row = _v510_make_row(src_for_row, of, stage, skey, label, "spike", score, reasons, nowv, [])
        rows.append(_v520_normalize_reason_row(row))
    return rows


def row_bool(row: Dict[str, Any], key: str) -> bool:
    try:
        return _v510_bool(row.get(key))
    except Exception:
        return False


def _v510_merge_rows(rows: List[Dict[str, Any]], nowv: float) -> List[Dict[str, Any]]:
    merged: Dict[str, Dict[str, Any]] = {}
    for r in rows:
        if not isinstance(r, dict): continue
        r = _v510_final_gate(r, nowv)
        t = ticker_norm(r.get("ticker") or r.get("market") or r.get("symbol"))
        if not t: continue
        key = t
        prev = merged.get(key)
        if prev is None:
            merged[key] = r; continue
        merged_keys = _v510_uniq(list(prev.get("matched_strategy_keys") or []) + list(r.get("matched_strategy_keys") or []), 8)
        merged_labels = _v510_uniq(list(prev.get("matched_strategy_labels") or []) + list(r.get("matched_strategy_labels") or []), 8)
        a = (_STAGE_ORDER.get(_v510_stage(r), 0), 1 if str(r.get("canonical_lane")) == "base" else 0, _v510_num(r.get("score"), default=0.0), _event_created_ts(r))
        b = (_STAGE_ORDER.get(_v510_stage(prev), 0), 1 if str(prev.get("canonical_lane")) == "base" else 0, _v510_num(prev.get("score"), default=0.0), _event_created_ts(prev))
        chosen = r if a >= b else prev
        chosen["matched_strategy_keys"] = merged_keys
        chosen["matched_strategy_labels"] = merged_labels
        merged[key] = chosen
    out = sorted(merged.values(), key=lambda x: (_STAGE_ORDER.get(_v510_stage(x),0), _v510_num(x.get("score"), default=0.0), _event_created_ts(x)), reverse=True)
    return out


def _v510_counts(rows: List[Dict[str, Any]]) -> Dict[str, int]:
    c = {"S1": 0, "S2": 0, "S3": 0}
    for r in rows:
        st = _v510_stage(r)
        c[st] = c.get(st, 0) + 1
    return c


def _v510_reason_top(rows: List[Dict[str, Any]], maxn: int = 20) -> List[Dict[str, Any]]:
    ctr: Dict[str, int] = {}
    for r in rows:
        if _v510_stage(r) == "S1": continue
        for reason in (r.get("s_stage_reasons") or r.get("block_reasons") or [])[:6]:
            s = str(reason or "").strip()
            if not s: continue
            # Collapse numeric variants lightly for panel readability.
            if "스프레드" in s: s = "스프레드"
            elif "미끄러짐" in s: s = "미끄러짐"
            elif "매수체결" in s: s = "매수체결"
            elif "1분" in s: s = "1분지속"
            elif "가격반응" in s: s = "가격반응"
            elif "신선" in s: s = "신선도재확인"
            ctr[s] = ctr.get(s, 0) + 1
    return [{"reason": k, "count": v} for k, v in sorted(ctr.items(), key=lambda kv: kv[1], reverse=True)[:maxn]]



def _v512_info_quality(feature_list: List[Dict[str, Any]], ofmap: Dict[str, Dict[str, Any]]) -> Dict[str, int]:
    """상태판이 읽는 정보품질 숫자를 single-pass canonical 기준으로 채운다.

    v510은 final_rows는 정상 생산했지만 /health 상단 정보요약이 0/전체로 표시됐다.
    이유는 예전 status/summary reader가 기대하던 quote_ready_count/micro_ready_count/full_info_ready_count
    계열 필드를 publish하지 않았기 때문이다. 여기서는 후보 조건을 바꾸지 않고, 같은 입력 feature/orderflow에서
    정보품질 숫자만 확정한다.
    """
    evaluated = len(feature_list)
    quote_ready = 0
    micro_ready = 0
    both_ready = 0
    orderflow_attached = 0
    price_ready = 0
    for row in feature_list:
        t = ticker_norm(row.get("ticker"))
        of = ofmap.get(t, {}) if t else {}
        has_price = _v510_num(row.get("current_price"), row.get("price"), of.get("quote_price"), of.get("current_price"), default=0.0) > 0
        quote = bool(of.get("quote_fresh") or of.get("ws_fresh") or has_price)
        micro = bool(of.get("micro_fresh") or of.get("orderflow_fresh") or of.get("buy_ratio") is not None or of.get("spread_pct") is not None)
        attached = bool(of)
        if has_price:
            price_ready += 1
        if attached:
            orderflow_attached += 1
        if quote:
            quote_ready += 1
        if micro:
            micro_ready += 1
        if quote and micro:
            both_ready += 1
    return {
        "price_ready_count": price_ready,
        "quote_ready_count": quote_ready,
        "market_price_ready_count": price_ready,
        "micro_ready_count": micro_ready,
        "full_info_ready_count": both_ready,
        "both_ready_count": both_ready,
        "orderflow_attached_count": orderflow_attached,
    }


def _v512_display_rows(rows: List[Dict[str, Any]], maxn: int = 80) -> List[Dict[str, Any]]:
    """candidate_reason/s1_lifecycle이 모두 볼 수 있는 표시 row aliases를 만든다.

    명령어 handler마다 top_candidates/items/rows/display_rows 중 서로 다른 key를 보던 구버전 흔적이 남아 있으므로,
    v512에서는 같은 canonical row를 여러 alias로만 publish한다. 새 계산 경로는 만들지 않는다.
    """
    out: List[Dict[str, Any]] = []
    for r in rows[:maxn]:
        rr = dict(r)
        rr.setdefault("display_name", rr.get("ticker") or rr.get("symbol"))
        rr.setdefault("stage", _v510_stage(rr))
        rr.setdefault("s_stage", _v510_stage(rr))
        rr.setdefault("strategy_label", rr.get("strategy") or rr.get("strategy_name") or rr.get("paper_strategy_label"))
        rr.setdefault("strategy_name", rr.get("strategy_label"))
        rr.setdefault("block_reasons", rr.get("s_stage_reasons") or rr.get("reasons") or [])
        rr.setdefault("missing_info", rr.get("missing_info") or [])
        rr.setdefault("structure_tags", rr.get("structure_tags") or rr.get("quality_structure_tags") or [])
        rr.setdefault("risk_tags", rr.get("risk_tags") or rr.get("quality_risk_tags") or [])
        out.append(rr)
    return out

# v533 removed legacy unused function: _v512_save_aliases

def _v512_enrich_summary_pointers(summary: Dict[str, Any], compact: Dict[str, Any], life: Dict[str, Any], recheck: Dict[str, Any]) -> None:
    """Expose cache pointers expected by older main-bot status readers."""
    ts = compact.get("updated_ts")
    summary.update({
        "candidate_reason_compact_cache_schema": compact.get("schema"),
        "candidate_reason_compact_cache_ts": ts,
        "candidate_reason_compact_cache_updated_ts": ts,
        "candidate_reason_compact_cache_status": compact.get("status", "fresh"),
        "candidate_reason_compact_cache_count": compact.get("candidate_count", 0),
        "candidate_reason_compact_cache_display_count": compact.get("display_count", 0),
        "candidate_reason_cache_file": str(CANDIDATE_REASON_COMPACT_CACHE), "candidate_reason_text_cache_file": str(CANDIDATE_REASON_TEXT_CACHE),
        "s1_lifecycle_schema": life.get("schema"),
        "s1_lifecycle_ts": life.get("updated_ts"),
        "s1_lifecycle_worker": life.get("worker"),
        "s1_lifecycle_fresh_count": life.get("fresh_count", 0),
        "s1_lifecycle_raw_count": life.get("raw_count", 0),
        "s1_lifecycle_cache_file": str(S1_LIFECYCLE_TRACE),
        "recheck_cache_schema": recheck.get("schema"),
        "recheck_cache_ts": recheck.get("updated_ts"),
        "recheck_candidate_count": recheck.get("candidate_count", 0),
    })


def _v513_legacy_candidate_reason_top(display_rows: List[Dict[str, Any]], limit: int = 10) -> List[Dict[str, Any]]:
    """Build the old /candidate_reason top_candidates shape from the same canonical display rows.

    Main-bot v468 is strict about the compact-cache schema/key shape.  We keep one
    canonical row source, but publish the compact payload in the legacy-compatible
    shape so the command does not report "cache 없음" while health/lifecycle can
    still read the same final rows.
    """
    top: List[Dict[str, Any]] = []
    for rr in display_rows[:limit]:
        st = _v510_stage(rr)
        fail = rr.get("block_reasons") or rr.get("s_stage_reasons") or rr.get("reasons") or []
        miss = rr.get("missing_info") or rr.get("entry_missing_info") or []
        risk = rr.get("risk_tags") or rr.get("structure_risk_tags") or []
        metrics = {
            "price_reaction_pct": _v510_num(rr.get("price_reaction_pct"), default=0.0),
            "spread_pct": _v510_num(rr.get("spread_pct"), default=0.0),
            "slippage_pct": _v510_num(rr.get("slippage_pct"), rr.get("spread_pct"), default=0.0),
            "buy_ratio": _v510_num(rr.get("buy_ratio"), default=0.0),
            "buy_sustain_1m": _v510_num(rr.get("buy_sustain_1m"), rr.get("buy_ratio"), default=0.0),
        }
        top.append({
            "ticker": ticker_norm(rr.get("ticker") or rr.get("market") or rr.get("symbol")),
            "stage": st,
            "s_stage": st,
            "strategy": str(rr.get("strategy_label") or rr.get("strategy") or rr.get("strategy_key") or "-"),
            "strategy_key": str(rr.get("strategy_key") or rr.get("paper_strategy_key") or "-"),
            "score": round(_v510_num(rr.get("score"), default=0.0), 2),
            "decision": str(rr.get("recheck_state") or rr.get("review_decision") or "-"),
            "block_reasons": _v510_uniq([str(x) for x in fail], 4),
            "missing_info": _v510_uniq([str(x) for x in miss], 3),
            "metrics": metrics,
            "metric_spine_source": "v513_canonical_final_rows",
            "needed_recovery": rr.get("needed_recovery") or rr.get("need_recovery") or [],
            "relative_context": rr.get("relative_context") or {},
            "structure_tags": rr.get("structure_tags") or [],
            "structure_good_tags": rr.get("structure_good_tags") or rr.get("structure_tags") or [],
            "structure_risk_tags": risk,
            "risk_tags": risk,
            "structure_fit": rr.get("structure_fit") or rr.get("structure_summary") or ("구조위험" if risk else "구조관찰"),
            "structure_summary": rr.get("structure_summary") or "",
            "market_regime_tags": rr.get("market_regime_tags") or [],
            "market_risk_tags": rr.get("market_risk_tags") or [],
            "market_regime_summary": rr.get("market_regime_summary") or "",
            "snapshot_ts": rr.get("updated_ts") or rr.get("created_at") or now_ts(),
            "snapshot_text": rr.get("updated_text") or now_text(),
            "fresh_for_paper": True,
        })
    return top


# =============================================================================
# strategy_worker v0.144 / v609: S3 near-S2 structure candle urgent lane
# - 조건/S등급 변경 없음.
# - strategy가 fresh_wait 후보뿐 아니라 S3 중 S2에 가까운 구조 후보도 candle_worker 긴급라인 파일로 봉인한다.
# - candle_worker 결과 cache를 candidate_reason에 같이 표시한다.
# =============================================================================
def _v608_candle_age_index() -> Dict[str, float]:
    obj = load_json(CANDLE, {}) or {}
    rows = obj.get('rows') if isinstance(obj, dict) else []
    nowv = now_ts(); out: Dict[str, float] = {}
    if isinstance(rows, list):
        for r in rows:
            if not isinstance(r, dict):
                continue
            t = ticker_norm(r.get('ticker') or r.get('symbol') or r.get('market'))
            ts = _v510_num(r.get('candle_ts'), default=0.0)
            if t:
                out[t] = max(999999.0 if ts <= 0 else 0.0, nowv - ts) if ts <= 0 else max(0.0, nowv - ts)
    return out

def _v608_row_text(row: Dict[str, Any]) -> str:
    vals: List[str] = []
    for k in ('final_trade_state','final_decision','final_trade_label','final_trade_reasons','v575_urgent_action_state','v574_fresh_urgent_reason','s2_promotion_lifecycle','s_stage_reasons','missing_info','risk_tags'):
        v = row.get(k)
        if isinstance(v, list): vals += [str(x) for x in v]
        elif isinstance(v, dict): vals.append(json.dumps(v, ensure_ascii=False, default=str))
        elif v not in (None, ''): vals.append(str(v))
    cm = row.get('canonical_metric_row') if isinstance(row.get('canonical_metric_row'), dict) else {}
    if isinstance(cm, dict):
        for k in ('final_trade_state','final_decision','final_trade_reasons','decision_reference'):
            v = cm.get(k)
            if isinstance(v, list): vals += [str(x) for x in v]
            elif v not in (None, ''): vals.append(str(v))
    return ' '.join(vals).lower()

def _v608_is_hard_risk_for_candle(row: Dict[str, Any]) -> bool:
    txt = _v608_row_text(row)
    # 캔들 긴급갱신 우선순위에서만 낮춘다. 후보 등급/조건 차단이 아니다.
    hard_words = (
        '가짜돌파', '방어실패', '구조위험', '늦은추격', '매도압력', '매도벽',
        '손실군', '위험우세', '상단저항', '윗꼬리', '실행위험 재확인'
    )
    return any(w in txt for w in hard_words)


def _v608_structure_good_for_candle(row: Dict[str, Any]) -> bool:
    vals: List[str] = []
    for k in ('entry_structure_tags','structure_tags','matched_strategy_labels','strategy_tags','entry_reasons','entry_basis','strategy','strategy_label'):
        v = row.get(k)
        if isinstance(v, list): vals += [str(x) for x in v]
        elif v not in (None, '', [], {}): vals.append(str(v))
    txt = ' '.join(vals) + ' ' + _v608_row_text(row)
    good_words = (
        'VWAP방어', 'EMA방어', '돈흐름재유입', '돈흐름', '눌림회복', '재가속',
        '주도흐름', '유동보유', '지지전환', '돌파', '회복', '방아쇠', 'recheck', 'trigger'
    )
    return any(w.lower() in txt.lower() for w in good_words)


def _v608_trigger_gap_for_candle(row: Dict[str, Any]) -> float:
    # 이미 row에 봉인된 gap이 있으면 먼저 사용한다.
    vals = [row.get('trigger_gap_pct'), row.get('s2_trigger_gap_pct'), row.get('gap_pct')]
    plan = row.get('entry_plan') if isinstance(row.get('entry_plan'), dict) else {}
    levels = row.get('structure_levels') if isinstance(row.get('structure_levels'), dict) else {}
    vals += [plan.get('trigger_gap_pct'), levels.get('trigger_gap_pct')]
    for v in vals:
        try:
            if v not in (None, ''):
                return abs(float(str(v).replace('%','')))
        except Exception:
            pass
    price = _v510_num(row.get('current_price'), row.get('entry_price'), row.get('price'), default=0.0)
    trigger = _v510_num(plan.get('trigger_price'), levels.get('trigger_price'), default=0.0)
    if price and trigger:
        try:
            return abs((trigger - price) / price * 100.0)
        except Exception:
            return 999.0
    return 999.0


def _v608_publish_candle_urgent_targets(rows: List[Dict[str, Any]], nowv: float) -> Dict[str, Any]:
    """v610 본선.
    v609는 S3까지 urgent에 올렸지만 모두 같은 무게로 처리해 candle_worker 처리량이 밀렸다.
    v610은 후보를 줄이지 않고 정보 투입량을 3단계로 나눈다.
    - core: OPEN/S1/S2/fresh_wait. 1m/3m/5m 전부.
    - near: near-S2/방아쇠근처 S3. 1m/3m 우선.
    - watch: 구조 좋은 S3/hot 구조 후보. 1m 최소 정보.
    조건/S등급/청산/장부는 변경하지 않는다.
    """
    age_map = _v608_candle_age_index()
    targets: List[Dict[str, Any]] = []
    seen=set()
    bucket_counter: Counter = Counter()
    lane_counter: Counter = Counter()

    lane_rank = {'core': 3000, 'near': 2000, 'watch': 1000}
    profile_by_lane = {'core': 'full_1m3m5m', 'near': 'mid_1m3m', 'watch': 'light_1m'}

    def add_target(row: Dict[str, Any], bucket: str, priority: int, target_age: int, reason: List[str], lane: str) -> None:
        t = ticker_norm(row.get('ticker') or row.get('symbol') or row.get('market'))
        if not t or t in seen:
            return
        lane = lane if lane in lane_rank else 'watch'
        age = age_map.get(t, 999999.0)
        targets.append({
            'ticker': t,
            'stage': _v510_stage(row),
            'bucket': bucket,
            'lane': lane,
            'profile': profile_by_lane.get(lane, 'light_1m'),
            'priority': int(lane_rank[lane] + priority),
            'raw_priority': priority,
            'required_age_sec': target_age,
            'current_age_sec': round(age, 1) if age < 999998 else None,
            'reason': ' / '.join(dict.fromkeys([str(x) for x in reason if x])),
            'retry_until_fresh': True,
            'requested_ts': nowv,
            'requested_text': now_text(nowv),
            'source': 'strategy_worker_v610_info_tier_candle_lane',
        })
        bucket_counter[bucket] += 1
        lane_counter[lane] += 1
        seen.add(t)

    for r in rows:
        if not isinstance(r, dict):
            continue
        st = _v510_stage(r)
        t = ticker_norm(r.get('ticker') or r.get('symbol') or r.get('market'))
        if not t or t in seen:
            continue
        txt = _v608_row_text(r)
        age = age_map.get(t, 999999.0)
        reason: List[str] = []

        if st == 'S1':
            if age > 75:
                add_target(r, 'core_S1_candle_fresh_lock', 1000, 90, ['S1 candle age >75s'], 'core')
            continue

        if st == 'S2':
            needs = False
            if bool(r.get('v574_fresh_urgent_request')):
                needs = True; reason.append('S2 fresh urgent')
            if any(w in txt for w in ('fresh_wait','신선','정보','공식 캔들','공식캔들','candle')):
                needs = True; reason.append('S2 candle/fresh wait')
            if age > 120 and ('s2_recheck' in txt or 'trigger_wait' in txt or 'fresh_wait' in txt):
                needs = True; reason.append('S2 stale while waiting')
            # S2는 fresh_wait 문구가 없어도 core lane에서 신선도 유지가 필요하다.
            if age > 180:
                needs = True; reason.append('S2 stale protection')
            if needs:
                add_target(r, 'core_S2_candle_fresh_lock', 940, 120, reason, 'core')
            continue

        if st != 'S3':
            continue
        if age <= 120:
            continue
        hard_risk = _v608_is_hard_risk_for_candle(r)
        structure_good = _v608_structure_good_for_candle(r)
        gap = _v608_trigger_gap_for_candle(r)
        s1_near = bool(r.get('s1_near_miss')) or str(r.get('s1_near_miss_level') or '').lower() in ('near','mid') or 'near_s1' in txt or 'would_be_s1' in txt
        hot_like = any(w in txt for w in ('hot', 'spike', '급등', '재확인', 'recheck'))
        fresh_text = any(w in txt for w in ('fresh_wait','신선','정보','공식 캔들','공식캔들','candle'))

        if s1_near and not hard_risk:
            add_target(r, 'near_S2_structure_candle', 860, 150, ['S3 near-S2 structure', f'age {round(age,1)}s'], 'near')
        elif gap <= 0.80 and not hard_risk:
            add_target(r, 'near_S3_trigger_candle', 820, 150, [f'trigger_gap {gap:.2f}%', f'age {round(age,1)}s'], 'near')
        elif structure_good and fresh_text and not hard_risk:
            add_target(r, 'near_S3_structure_good_fresh_wait', 780, 180, ['structure good + candle/fresh wait', f'age {round(age,1)}s'], 'near')
        elif hot_like and structure_good and age > 180 and not hard_risk:
            add_target(r, 'watch_S3_hot_structure_candle', 720, 240, ['hot/recheck + structure', f'age {round(age,1)}s'], 'watch')
        elif structure_good and age > 300 and not hard_risk:
            add_target(r, 'watch_S3_structure_refresh', 640, 300, ['structure watch stale refresh', f'age {round(age,1)}s'], 'watch')

    # v610: 고정 개수 제한 금지. 대상은 전부 유지하고, candle_worker가 처리순서/정보깊이만 차등 적용한다.
    targets = sorted(targets, key=lambda x: int(x.get('priority') or 0), reverse=True)
    obj = {
        'schema': 'candle_urgent_targets_v610_info_tier',
        'version': VERSION,
        'updated_ts': nowv,
        'updated_text': now_text(nowv),
        'request_count': len(targets),
        'targets': [x.get('ticker') for x in targets],
        'bucket_counts': dict(bucket_counter),
        'lane_counts': dict(lane_counter),
        'rows': targets,
        'policy': 'v610: no fixed candidate-count cap; all eligible rows stay in urgent queue. Information depth is tiered: core=1m/3m/5m, near=1m/3m, watch=1m. No strategy thresholds changed.',
    }
    save_json(CANDLE_URGENT_TARGETS, obj)
    result = load_json(CANDLE_URGENT_RESULT, {}) or {}
    lane_result = result.get('lane_result') if isinstance(result, dict) and isinstance(result.get('lane_result'), dict) else {}
    return {
        'schema': 'strategy_candle_urgent_lock_summary_v610_info_tier',
        'version': VERSION,
        'request_count': len(targets),
        'targets': obj.get('targets'),
        'bucket_counts': obj.get('bucket_counts'),
        'lane_counts': obj.get('lane_counts'),
        'result_schema': result.get('schema') if isinstance(result, dict) else None,
        'result_requested': result.get('requested_count') if isinstance(result, dict) else None,
        'result_refreshed': result.get('refreshed_count') if isinstance(result, dict) else None,
        'result_under_target': result.get('under_target_age_count') if isinstance(result, dict) else None,
        'result_miss': result.get('miss_count') if isinstance(result, dict) else None,
        'lane_result': lane_result,
        'result_rows': (result.get('rows') or [])[:12] if isinstance(result, dict) else [],
        'policy': obj.get('policy'),
    }


# =============================================================================
# strategy_worker v0.149 / v655: 자동매매 전 단계용 S2 재확인 lane + CPU 수술
# - S1/청산/자동매수는 변경하지 않는다.
# - S3 중 구조/확인값이 살아 있고 실행위험이 낮은 후보만 S2 재확인으로 올려
#   target_router/WS/micro/candle이 먼저 신선도를 붙이게 한다.
# - hot-rank 추격, 스프레드/미끄러짐 과다, 매도압력은 그대로 S3/차단.
# =============================================================================
V655_STRATEGY_BUILD = "strategy_worker_v0.150_v655_strategy_cpu_recheck_lane"

def _v655_metric(row: Dict[str, Any], *keys: str, default: float = 0.0) -> float:
    return _v510_num(*[row.get(k) for k in keys], default=default)

def _v655_text_blob(row: Dict[str, Any]) -> str:
    vals: List[str] = []
    for k in ("strategy_label","strategy","strategy_key","s_stage_reasons","block_reasons","risk_tags","structure_tags","s1_missing_conditions","condition_roles"):
        v = row.get(k)
        if isinstance(v, dict):
            vals += [str(x) for arr in v.values() if isinstance(arr, list) for x in arr]
        elif isinstance(v, list):
            vals += [str(x) for x in v]
        else:
            vals.append(str(v or ""))
    return " ".join(vals)

def _v655_recheck_classify(row: Dict[str, Any]) -> Tuple[str, List[str]]:
    st = _v510_stage(row)
    blob = _v655_text_blob(row)
    react = _v655_metric(row, "price_reaction_pct", "change_1m_pct", "price_chg_60s")
    buy = _v655_metric(row, "buy_ratio")
    sustain = _v655_metric(row, "buy_sustain_1m", "buy_sustain_20s", "buy_ratio_20s")
    spread = _v655_metric(row, "spread_pct", default=99.0)
    slip = _v655_metric(row, "slippage_pct", "spread_pct", default=spread)
    ch30 = _v655_metric(row, "price_chg_30s")
    ch60 = _v655_metric(row, "price_chg_60s", "change_1m_pct")
    stale = row.get("stale_reasons") if isinstance(row.get("stale_reasons"), list) else []
    hard_words = ("매도벽/매도체결압력", "강한 매도압력", "가짜돌파", "늦은추격 위험", "급등형 매도압력", "거래정지", "비정상")
    severe_risk = bool(spread >= 0.65 or slip >= 0.65 or any(w in blob for w in hard_words))
    hot_chase_bad = bool(("hot-rank" in blob or "급등" in blob) and (spread > 0.85 or buy < 0.45 or sustain < 0.45))
    structure_good = any(w in blob for w in ("VWAP", "EMA", "돈흐름", "주도흐름", "상대강도", "눌림", "재돌파", "저점유동성쓸림", "돌파"))
    confirm_near = bool(react >= 0.20 or ch30 >= 0.25 or ch60 >= 0.35 or buy >= 0.58 or sustain >= 0.58)
    exec_okish = bool(spread <= 0.35 and slip <= 0.35 and buy >= 0.50)
    reasons: List[str] = []
    if stale and (confirm_near or structure_good): reasons.append("정보 오래됨→긴급 재수집")
    if structure_good and confirm_near: reasons.append("구조+확인신호 근접")
    if exec_okish: reasons.append("실행위험 재확인 가능")
    if severe_risk or hot_chase_bad:
        return "risk_observe", ["실행위험/추격위험 우선"]
    if st == "S2":
        return "s2_keepalive", reasons or ["S2 신선도 유지"]
    if st == "S3" and structure_good and confirm_near and exec_okish:
        return "s3_to_s2_recheck", reasons or ["S3→S2 재확인 승격"]
    if st == "S3" and stale and (structure_good or react >= 0.05):
        return "s3_info_urgent", reasons or ["정보오래됨 우선갱신"]
    return "observe", reasons or ["관찰"]

def _v655_apply_strategy_recheck_lanes(rows: List[Dict[str, Any]], nowv: float) -> Tuple[List[Dict[str, Any]], Dict[str, Any]]:
    counts: Dict[str, int] = {}
    out: List[Dict[str, Any]] = []
    for r in rows or []:
        if not isinstance(r, dict):
            continue
        rr = dict(r)
        lane, reasons = _v655_recheck_classify(rr)
        counts[lane] = counts.get(lane, 0) + 1
        rr["v655_strategy_lane"] = lane
        rr["v655_strategy_lane_reasons"] = reasons[:5]
        rr["strategy_cpu_recheck_build"] = V655_STRATEGY_BUILD
        if lane == "s3_to_s2_recheck" and _v510_stage(rr) == "S3":
            rr["s_stage"] = rr["candidate_stage"] = rr["candidate_grade"] = rr["stage"] = rr["grade"] = "S2"
            rr["recheck_state"] = "S2 재확인"
            prev = rr.get("s2_recheck_reasons") if isinstance(rr.get("s2_recheck_reasons"), list) else []
            rr["s2_recheck_reasons"] = _v510_uniq(list(prev) + ["v655:S3 구조/확인근접 재확인"] + reasons, 8)
            br = rr.get("block_reasons") if isinstance(rr.get("block_reasons"), list) else []
            rr["block_reasons"] = _v510_uniq(list(br) + ["재확인: 구조/확인신호 근접 S2 승격"], 12)
            rr["open_eligible"] = False; rr["paper_bot_open"] = False; rr["trade_ready"] = False
        out.append(rr)
    return out, {"schema":"strategy_recheck_lane_summary_v655", "version":VERSION, "updated_ts":nowv, "counts":counts, "policy":"S1/청산/자동매수 변경 없음. S3 중 실행위험 낮고 구조+확인신호가 근접한 후보만 S2 재확인으로 올려 정보배관 우선순위를 높임."}


def _v732_reseal_common_uprising_promotions(rows: List[Dict[str, Any]], nowv: float) -> Tuple[List[Dict[str, Any]], Dict[str, Any]]:
    """공통 상승포착 승급판과 실제 stage/paper handoff를 같은 spine으로 맞춘다.

    - S3 관찰/복기 row는 어떤 구경로가 다시 S2로 올려도 S3로 재봉인한다.
    - common_uprising_pass + s2_to_s1_promoted row는 현재 cycle의 승급 이벤트로 보고
      created/event timestamp를 now로 재봉인해 final_entry_gate의 old paper age 착시를 제거한다.
    - summary count는 실제 S1/open_eligible row 기준으로 다시 세운다.
    """
    out: List[Dict[str, Any]] = []
    effective = 0
    blocked = Counter()
    family = Counter()
    family_effective = Counter()
    family_blocked = Counter()
    forced_s3 = 0
    mismatch_before = 0

    for src in rows or []:
        if not isinstance(src, dict):
            continue
        r = dict(src)
        fam = str(r.get("s2_to_s1_promotion_family_v732") or "-")
        observe_only = bool(
            r.get("s3_observe_v732") or r.get("s3_observe_v730") or r.get("s3_observe_v729") or r.get("s3_observe_v728") or r.get("s3_observe_v727")
            or str(r.get("strategy_key") or "").startswith("coin_quality_s3_observe")
        )

        if observe_only:
            if _v510_stage(r) != "S3":
                forced_s3 += 1
            r["s_stage"] = r["candidate_stage"] = r["candidate_grade"] = r["stage"] = r["grade"] = "S3"
            r["open_eligible"] = False
            r["paper_bot_open"] = False
            r["trade_ready"] = False
            r["v732_stage_resealed"] = "S3_observe_only"
            r["s2_to_s1_promoted_v732"] = False
            r["common_uprising_pass_v732"] = False
            out.append(r)
            continue

        promo = bool(r.get("s2_to_s1_promoted_v732") and r.get("common_uprising_pass_v732"))
        if fam and fam != "-":
            family[fam] += 1

        if promo and _v510_stage(r) != "S1":
            mismatch_before += 1
        if promo:
            # 승급은 현재 cycle에서 새로 발생한 entry candidate이므로 timestamp를 현재로 봉인한다.
            for k in ("created_at", "candidate_created_at", "source_created_at", "detected_ts", "event_ts", "updated_ts"):
                r[k] = nowv
            r["expires_at"] = nowv + max(60.0, float(CANDIDATE_TTL_SEC or 90))
            r["promoted_at_v732"] = nowv
            r["promoted_at_text_v732"] = now_text(nowv)
            r["promotion_spine_v732"] = "common_uprising_to_s1_resealed"
            r["s_stage"] = r["candidate_stage"] = r["candidate_grade"] = r["stage"] = r["grade"] = "S1"
            r["open_eligible"] = True
            r["paper_bot_open"] = True
            r["trade_ready"] = True
            r["v732_stage_resealed"] = "S1_common_uprising"
            stale = [x for x in (r.get("stale_reasons") or []) if not str(x).startswith("paper ")]
            r["stale_reasons"] = stale
            ctx = r.get("entry_context") if isinstance(r.get("entry_context"), dict) else {}
            ctx = dict(ctx)
            ctx.update({
                "promotion_spine_v732": "common_uprising_to_s1_resealed",
                "promoted_at_v732": nowv,
                "stage_after_promotion_v732": "S1",
                "open_eligible": True,
            })
            r["entry_context"] = ctx
            effective += 1
            if fam and fam != "-":
                family_effective[fam] += 1
        else:
            # S2 대상에서 승급 안 된 row만 blocked로 집계한다.
            stage_now = _v510_stage(r)
            is_target = bool(stage_now == "S2")
            if is_target:
                br = list(r.get("s2_to_s1_promotion_blocked_v732") or r.get("common_uprising_blocked_v732") or [])
                if not br:
                    br = ["공통 상승포착 미통과"]
                for b in br[:5]:
                    blocked[str(b)] += 1
                if fam and fam != "-":
                    family_blocked[fam] += 1
        out.append(r)

    counts_after = _v510_counts(out)
    return out, {
        "schema": "promotion_stage_spine_v732",
        "version": VERSION,
        "updated_ts": nowv,
        "effective_s1_promotions": effective,
        "mismatch_before_reseal": mismatch_before,
        "forced_s3_observe_rows": forced_s3,
        "s1_count_after_reseal": int(counts_after.get("S1", 0)),
        "s2_count_after_reseal": int(counts_after.get("S2", 0)),
        "s3_count_after_reseal": int(counts_after.get("S3", 0)),
        "blocked_top": dict(blocked.most_common(8)),
        "family_target": dict(family.most_common(8)),
        "family_effective": dict(family_effective.most_common(8)),
        "family_blocked": dict(family_blocked.most_common(8)),
        "policy": "common_uprising pass rows are resealed to actual S1 before publish/summary/paper handoff; S3 observe rows remain S3.",
    }



def _v732_age_value_for_hold(row: Dict[str, Any], keys: Tuple[str, ...], default: float = 0.0) -> float:
    ctx = row.get("entry_context") if isinstance(row.get("entry_context"), dict) else {}
    for src in (row, ctx, row.get("canonical_metric_row") if isinstance(row.get("canonical_metric_row"), dict) else {}):
        if not isinstance(src, dict):
            continue
        for k in keys:
            try:
                v = src.get(k)
                if v not in (None, "", [], {}):
                    return _v510_num(v, default=default)
            except Exception:
                pass
    return default


def _v732_trigger_state_for_hold(row: Dict[str, Any]) -> Dict[str, Any]:
    ctx = row.get("entry_context") if isinstance(row.get("entry_context"), dict) else {}
    trigger = _v510_num(row.get("trigger_price"), ctx.get("trigger_price"), row.get("entry_trigger_price"), default=0.0)
    price = _v510_num(row.get("current_price"), row.get("entry_price"), row.get("live_price"), row.get("price"), default=0.0)
    reached = True
    gap = 0.0
    if trigger > 0 and price > 0:
        reached = price >= trigger
        gap = ((price - trigger) / trigger) * 100.0
    return {
        "trigger_price": trigger,
        "entry_price": price,
        "trigger_reached": bool(reached),
        "trigger_gap_pct": round(gap, 4),
        "reason": "방아쇠 도달" if reached else "방아쇠 미도달",
    }


def _v732_write_s1_hold_cache(rows: List[Dict[str, Any]], nowv: float) -> Dict[str, Any]:
    """Write the paper S1 hold cache from the current sealed S1 rows only.

    v790 fix:
    - The old writer merged previous hold rows for TTL 60s and used a 10-second bucket key.
      That allowed `paper_s1_hold_cache.json` to show S1 hold rows after the current
      canonical candidate rows had already dropped to S1=0, and it could duplicate the
      same ticker several times (e.g. BFC/BFC/BFC).
    - This writer rebuilds the hold cache from the current canonical rows each cycle and
      deduplicates by ticker. It does not loosen any S1/trigger/exit condition.
    """
    hold_path = BASE_DIR / "paper_s1_hold_cache.json"
    ttl = 60.0
    old_obj = load_json(hold_path, {}) or {}
    old_rows = old_obj.get("rows") if isinstance(old_obj, dict) and isinstance(old_obj.get("rows"), list) else []
    old_count = len([x for x in old_rows if isinstance(x, dict)])

    current_s1_by_ticker: Dict[str, Dict[str, Any]] = {}
    source_s1_count = 0
    duplicate_current = 0

    for src in rows or []:
        if not isinstance(src, dict):
            continue
        if _v510_stage(src) != "S1" or not bool(src.get("open_eligible")) or not bool(src.get("paper_bot_open")):
            continue
        source_s1_count += 1
        r = dict(src)
        t = _v661_row_ticker(r)
        if not t:
            continue
        prev = current_s1_by_ticker.get(t)
        if prev is not None:
            duplicate_current += 1
            prev_score = _v510_num(prev.get("score"), prev.get("candidate_quality_score"), default=0.0)
            new_score = _v510_num(r.get("score"), r.get("candidate_quality_score"), default=0.0)
            prev_ts = _v510_num(prev.get("updated_ts"), prev.get("created_at"), default=0.0)
            new_ts = _v510_num(r.get("updated_ts"), r.get("created_at"), default=0.0)
            if (new_ts, new_score) <= (prev_ts, prev_score):
                continue
        current_s1_by_ticker[t] = r

    fresh_count = stale_count = trigger_wait = open_ready_count = 0
    rows_out: List[Dict[str, Any]] = []

    for t, src in current_s1_by_ticker.items():
        r = dict(src)
        # Stable per-ticker key: one live hold row per ticker, no 10-second bucket duplicates.
        key = f"{t}:S1"
        price_age = _v732_age_value_for_hold(r, ("price_reaction_age_sec", "price_age_sec", "quote_age_sec", "price_source_age_sec"), 0.0)
        micro_age = _v732_age_value_for_hold(r, ("micro_age_sec", "trade_age_sec", "quote_age_sec"), 0.0)
        order_age = _v732_age_value_for_hold(r, ("orderflow_age_sec", "trade_age_sec", "micro_age_sec"), 0.0)
        source_age = _v732_age_value_for_hold(r, ("source_age", "fresh_age", "age", "candidate_age_sec"), 0.0)
        stale_reasons = list(r.get("stale_reasons") or [])
        if price_age > 60:
            stale_reasons.append(f"price_age {price_age:.0f}s")
        if micro_age > 35:
            stale_reasons.append(f"micro_age {micro_age:.0f}s")
        if order_age > 35:
            stale_reasons.append(f"orderflow_age {order_age:.0f}s")
        if source_age > 120:
            stale_reasons.append(f"source_age {source_age:.0f}s")
        trigger = _v732_trigger_state_for_hold(r)
        is_stale = bool(stale_reasons)
        is_trigger_wait = not bool(trigger.get("trigger_reached"))
        open_ready = bool((not is_stale) and (not is_trigger_wait))
        if open_ready:
            open_ready_count += 1
            status = "fresh_open_ready"
        elif is_stale:
            stale_count += 1
            status = "stale_hold"
        else:
            trigger_wait += 1
            status = "trigger_wait"

        ctx = r.get("entry_context") if isinstance(r.get("entry_context"), dict) else {}
        ctx = dict(ctx)
        hold_reasons_v738 = ["S1 hold 통과", str(trigger.get("reason") or "방아쇠 도달")]
        hold_decision_v738 = {
            "schema": "canonical_entry_decision_v790_s1_hold_current_row_only",
            "gate_pass": True,
            "s1_allowed": True,
            "action": "paper_open_candidate",
            "final_entry_action": "paper_open_candidate",
            "display_reasons": hold_reasons_v738,
            "entry_profile": r.get("entry_profile") or ctx.get("entry_profile") or "normal_common",
            "exit_profile": r.get("exit_profile") or ctx.get("exit_profile") or "normal_exit",
            "profile_family": r.get("profile_family") or ctx.get("profile_family") or "s1_hold",
            "source": "strategy_worker_s1_hold_v790_current_row_only",
            "rechecked_after_hold": False,
            "paper_open_allowed_by_hold": True,
        }
        ctx.update({
            "s1_hold_v732": True,
            "s1_hold_v738": True,
            "s1_hold_v790": True,
            "s1_hold_status_v732": status,
            "s1_hold_status_v738": status,
            "s1_hold_status_v790": status,
            "s1_hold_open_ready_v732": open_ready,
            "s1_hold_open_ready_v738": open_ready,
            "s1_hold_open_ready_v790": open_ready,
            "s1_hold_freshness_v732": {"price_age": price_age, "micro_age": micro_age, "orderflow_age": order_age, "source_age": source_age, "stale_reasons": _v510_uniq(stale_reasons, 8)},
            "s1_hold_freshness_v738": {"price_age": price_age, "micro_age": micro_age, "orderflow_age": order_age, "source_age": source_age, "stale_reasons": _v510_uniq(stale_reasons, 8)},
            "s1_hold_freshness_v790": {"price_age": price_age, "micro_age": micro_age, "orderflow_age": order_age, "source_age": source_age, "stale_reasons": _v510_uniq(stale_reasons, 8)},
            "trigger_gate_v732": trigger,
            "trigger_gate_v738": trigger,
            "trigger_gate_v790": trigger,
            "canonical_entry_decision": hold_decision_v738,
            "common_entry_decision": hold_decision_v738,
            "final_trade_state": "S1_PASS",
            "final_trade_allowed": True,
            "final_trade_label": "S1 hold canonical resealed current-row-only",
        })
        r.update({
            "schema": "paper_s1_hold_row_v790_current_row_only",
            "s1_hold_v732": True,
            "s1_hold_v738": True,
            "s1_hold_v790": True,
            "hold_key": key,
            "hold_created_at": nowv,
            "hold_expires_at": nowv + ttl,
            "created_at": nowv,
            "candidate_created_at": nowv,
            "source_created_at": nowv,
            "detected_ts": nowv,
            "event_ts": nowv,
            "updated_ts": nowv,
            "expires_at": nowv + ttl,
            "s1_hold_status_v732": status,
            "s1_hold_status_v738": status,
            "s1_hold_status_v790": status,
            "s1_hold_open_ready_v732": open_ready,
            "s1_hold_open_ready_v738": open_ready,
            "s1_hold_open_ready_v790": open_ready,
            "freshness_status": "fresh" if not is_stale else "stale",
            "stale_reasons": _v510_uniq(stale_reasons, 8),
            "price_age_sec": price_age,
            "micro_age_sec": micro_age,
            "orderflow_age_sec": order_age,
            "source_age": source_age,
            "trigger_price": trigger.get("trigger_price"),
            "trigger_reached": trigger.get("trigger_reached"),
            "trigger_gap_pct": trigger.get("trigger_gap_pct"),
            "trigger_gate_v732": trigger,
            "trigger_gate_v738": trigger,
            "trigger_gate_v790": trigger,
            "canonical_entry_decision": hold_decision_v738,
            "common_entry_decision": hold_decision_v738,
            "entry_context": ctx,
            "final_entry_action": "paper_open_candidate",
            "final_entry_label": "S1 hold canonical resealed current-row-only",
            "final_trade_state": "S1_PASS",
            "final_trade_label": "S1 hold canonical resealed current-row-only",
            "final_trade_allowed": True,
            "s1_hold_canonical_resealed_v738": True,
            "s1_hold_canonical_resealed_v790": True,
            "paper_bot_open": True,
            "open_eligible": True,
            "trade_ready": True,
            "paper_source_v732": "s1_hold_cache_only",
            "paper_source_v790": "current_s1_row_only",
            "candidate_grade": "S1",
            "s_stage": "S1",
            "stage": "S1",
            "grade": "S1",
            "s_stage_reasons": _v510_uniq(["S1 hold bridge current row only"] + list(r.get("s_stage_reasons") or []), 10),
        })
        rows_out.append(r)
        if not is_stale:
            fresh_count += 1

    rows_out = sorted(rows_out, key=lambda x: _v510_num(x.get("updated_ts"), x.get("hold_created_at"), default=0.0), reverse=True)[:80]
    status_counter = Counter(str(x.get("s1_hold_status_v732") or "-") for x in rows_out)
    pruned_old_count = max(0, old_count - len(rows_out))
    obj = {
        "schema": "paper_s1_hold_cache_v790_current_row_only",
        "version": VERSION,
        "updated_ts": nowv,
        "updated_text": now_text(nowv),
        "hold_ttl_sec": ttl,
        "count": len(rows_out),
        "source_s1_count": source_s1_count,
        "deduped_ticker_count": len(current_s1_by_ticker),
        "duplicate_current_pruned_count": duplicate_current,
        "old_hold_pruned_count_v790": pruned_old_count,
        "fresh_count": fresh_count,
        "stale_count": stale_count,
        "trigger_wait_count": trigger_wait,
        "open_ready_count": open_ready_count,
        "expired_pruned_count": pruned_old_count,
        "status_counts": dict(status_counter),
        "rows": rows_out,
        "policy": "v790: hold cache is rebuilt from current canonical S1 rows only; no old TTL merge and one row per ticker. Paper still performs final trigger/safety gate.",
    }
    save_json(hold_path, obj)
    write_jsonl_atomic(BASE_DIR / "paper_s1_hold_cache.jsonl", rows_out)
    return obj


def _v510_publish(rows: List[Dict[str, Any]], rejects: List[Dict[str, Any]], priority_requests: List[Dict[str, Any]], evaluated: int, cycle_ts: float, info_quality: Optional[Dict[str, int]] = None) -> Dict[str, Any]:
    nowv = now_ts()
    rows, v655_recheck_lane_summary = _v655_apply_strategy_recheck_lanes(rows, nowv)
    # v554: publish structure-level entry plans for every strategy row before all caches are rendered.
    rows = _v554_apply_entry_plan_state(rows, nowv)
    # v584: 구조/fresh/실행위험/진입타이밍을 canonical_metric_row로 봉인한다.
    rows = _v583_attach_structure_freshness(rows, nowv)
    # v563: S2->S1 승격 실패 생애주기를 같은 canonical row에 봉인한다.
    rows, s2_promotion_trace = _v563_attach_s2_promotion_lifecycle(rows, nowv)
    # v574: S2->S1 근접인데 fresh가 오래된 후보는 S2에 묵히지 않고
    # target_router/micro urgent 갱신 요청으로 보낸다. 조건/S등급 수치는 변경하지 않는다.
    priority_requests, v574_fresh_urgent_summary = _v574_attach_s2_fresh_urgent_requests(rows, priority_requests, nowv)
    v608_candle_urgent_summary = _v608_publish_candle_urgent_targets(rows, nowv)
    # v732: 승급판 summary와 실제 canonical stage/paper handoff가 갈라지지 않게 재봉인한다.
    rows, v732_promotion_spine_summary = _v732_reseal_common_uprising_promotions(rows, nowv)
    v732_s1_hold_summary = _v732_write_s1_hold_cache(rows, nowv)
    counts = _v510_counts(rows)
    info_quality = info_quality or {}
    display_rows = _v512_display_rows(rows, 120)
    lane_counts: Dict[str, int] = {}
    for r in rows:
        lane = str(r.get("canonical_lane") or "base")
        lane_counts[lane] = lane_counts.get(lane, 0) + 1
    s1_missing_counter = Counter()
    for r in rows:
        for x in (r.get("s1_missing_names") or []):
            s1_missing_counter[str(x)] += 1
    s1_near_count = sum(1 for r in rows if bool(r.get("s1_near_miss")))
    s2_to_s1_promoted_count_v732 = sum(1 for r in rows if bool(r.get("s2_to_s1_promoted_v732")) and _v510_stage(r) == "S1" and bool(r.get("open_eligible")))
    s2_to_s1_promotion_blocked_count_v732 = 0
    s2_to_s1_promotion_reason_top_v732 = Counter()
    s2_to_s1_promotion_blocked_top_v732 = Counter()
    s2_to_s1_promotion_family_counter_v732 = Counter()
    s2_to_s1_promotion_family_promoted_v732 = Counter()
    s2_to_s1_promotion_family_blocked_v732 = Counter()
    common_uprising_target_count_v732 = 0
    common_uprising_pass_count_v732 = 0
    common_uprising_block_top_v732 = Counter()
    for r in rows:
        fam = str(r.get("s2_to_s1_promotion_family_v732") or "-")
        stage_now = _v510_stage(r)
        observe_only = bool(r.get("s3_observe_v732") or r.get("s3_observe_v729") or r.get("s3_observe_v728") or r.get("s3_observe_v727") or str(r.get("strategy_key") or "").startswith("coin_quality_s3_observe"))
        promotion_target = bool((stage_now == "S2" and not observe_only) or bool(r.get("s2_to_s1_promoted_v732")))
        if promotion_target:
            common_uprising_target_count_v732 += 1
            if bool(r.get("common_uprising_pass_v732")):
                common_uprising_pass_count_v732 += 1
            for x in (r.get("common_uprising_blocked_v732") or []):
                common_uprising_block_top_v732[str(x)] += 1
            if fam and fam != "-":
                s2_to_s1_promotion_family_counter_v732[fam] += 1
                if bool(r.get("s2_to_s1_promoted_v732")):
                    s2_to_s1_promotion_family_promoted_v732[fam] += 1
                if r.get("s2_to_s1_promotion_blocked_v732"):
                    s2_to_s1_promotion_family_blocked_v732[fam] += 1
            for x in (r.get("s2_to_s1_promotion_reasons_v732") or []):
                s2_to_s1_promotion_reason_top_v732[str(x)] += 1
            for x in (r.get("s2_to_s1_promotion_blocked_v732") or []):
                s2_to_s1_promotion_blocked_top_v732[str(x)] += 1
    s2_to_s1_promotion_blocked_count_v732 = sum(s2_to_s1_promotion_family_blocked_v732.values())
    write_jsonl_atomic(PAPER_LATEST, rows)
    # v782: publish the canonical candidate spine immediately after latest rows are sealed.
    # Heavy display caches can finish later; paper/main should not wait 60~80s to see S2 recheck rows.
    try:
        _v782_now = now_ts()
        _v782_price_ready = sum(1 for _r in rows if _v510_num(_r.get('current_price'), _r.get('entry_price'), _r.get('price'), default=0.0) > 0)
        save_json(HANDOFF, {
            'schema': 'paper_handoff_status_v782_fast_after_latest',
            'version': VERSION,
            'updated_ts': _v782_now,
            'updated_text': now_text(_v782_now),
            'latest_count': len(rows),
            'stage_counts': counts,
            'lane_counts': lane_counts,
            'price_ready_count': _v782_price_ready,
            'source': 'paper_candidates_latest',
            'source_policy': 'v782: strategy seals candidate rows first; display summary is throttled separately. No condition/exit change.',
        })
        write_status(
            'running',
            phase='latest_published_v782',
            phase_note='candidate rows sealed before display-cache build',
            strategy_worker_version=VERSION,
            main_version=MAIN_VERSION,
            deploy_version=MAIN_DEPLOY_VERSION,
            evaluated=evaluated,
            row_count=evaluated,
            s_count=len(rows),
            paper_latest_count=len(rows),
            s1_count=counts.get('S1',0),
            s2_count=counts.get('S2',0),
            s3_count=counts.get('S3',0),
            target_count=len(priority_requests),
            priority_request_count=len(priority_requests),
            last_sec=round(_v782_now-cycle_ts,3),
            status_route_schema='strategy_status_v782_fast_candidate_publish',
            **info_quality
        )
    except Exception as exc:
        append_error(ERROR, 'v782_fast_publish', exc)
    # Runtime OPEN does not append to archive. Archive/trade log stays paper-owned/history-only.
    priority_requests = sorted(priority_requests, key=lambda x: _v510_num(x.get("priority"), default=0.0), reverse=True)
    targets = list(dict.fromkeys([ticker_norm(r.get("ticker")) for r in priority_requests if ticker_norm(r.get("ticker"))]))
    pr_obj = {"schema": "strategy_priority_requests_v512", "version": VERSION, "updated_ts": nowv, "updated_text": now_text(nowv), "request_count": len(priority_requests), "targets": targets, "requests": priority_requests, "buckets": {}}
    for pr in priority_requests:
        b = str(pr.get("bucket") or "-"); pr_obj["buckets"][b] = pr_obj["buckets"].get(b, 0) + 1
    save_json(PRIORITY_REQ, pr_obj)

    # v783: split fast candidate production from heavy display/review cache production.
    # The strategy factory must publish PAPER_LATEST/HANDOFF/priority requests every cycle,
    # while long candidate_reason/recheck/lifecycle display caches may be throttled.
    # This does not change S1/S2/S3 thresholds, exit logic, BUY_READY, or paper ledger.
    try:
        _v783_display_age = min(
            _v521_file_age(CANDIDATE_REASON_COMPACT_CACHE),
            _v521_file_age(RECHECK_CACHE),
            _v521_file_age(S1_LIFECYCLE_TRACE),
            _v521_file_age(SUMMARY),
        )
    except Exception:
        _v783_display_age = 999999.0
    _v783_display_due = bool(_v783_display_age >= float(os.getenv('STRATEGY_DISPLAY_CACHE_THROTTLE_SEC','30')))
    if not _v783_display_due:
        try:
            _v783_now = now_ts()
            reason_top_light = _v510_reason_top(rows)
            s2_rows = [r for r in rows if _v510_stage(r) == 'S2']
            s1_rows_fast = [r for r in rows if _v510_stage(r) == 'S1']
            s2_block_top = Counter()
            for _r in s2_rows:
                for _x in (_r.get('s2_to_s1_promotion_blocked_v732') or _r.get('s1_missing_names') or _r.get('block_reasons') or []):
                    s2_block_top[str(_x)] += 1
            summary_light = {
                'schema': 'strategy_summary_v783_fast_candidate_only',
                'version': VERSION,
                'main_version': MAIN_VERSION,
                'updated_ts': _v783_now,
                'updated_text': now_text(_v783_now),
                'cycle_started_ts': cycle_ts,
                'cycle_elapsed_sec': round(_v783_now - cycle_ts, 3),
                'evaluated': evaluated,
                'paper_latest_count': len(rows),
                's_count': len(rows),
                's_stage_counts': counts,
                'stage_counts': counts,
                's1_count': counts.get('S1',0),
                's2_count': counts.get('S2',0),
                's3_count': counts.get('S3',0),
                'lane_counts': lane_counts,
                'reason_top': reason_top_light,
                'target_count': len(targets),
                'priority_request_count': len(priority_requests),
                's2_recheck_count_v783': len(s2_rows),
                's1_hold_candidate_count_v783': len(s1_rows_fast),
                's2_to_s1_block_top_v783': dict(s2_block_top.most_common(8)),
                'display_cache_throttled_v783': True,
                'display_cache_age_sec_v783': round(float(_v783_display_age),3),
                'policy': 'v783: fast candidate/handoff/priority publish every cycle; heavy display caches are throttled. S1 strict, S2/S3 wide, exits unchanged.',
            }
            save_json(SUMMARY, summary_light)
            save_json(CANONICAL_STRATEGY_SUMMARY, {
                'schema': 'strategy_canonical_summary_v783_fast_candidate_only',
                'version': VERSION,
                'updated_ts': _v783_now,
                'cycle_started_ts': cycle_ts,
                'cycle_elapsed_sec': round(_v783_now-cycle_ts,3),
                's_stage_counts': counts,
                'paper_latest_count': len(rows),
                's2_recheck_count_v783': len(s2_rows),
                's2_to_s1_block_top_v783': dict(s2_block_top.most_common(8)),
                'display_cache_throttled_v783': True,
                'source_policy': summary_light['policy'],
            })
            save_json(V510_TRACE, {
                'schema': 'strategy_trace_v783_fast_candidate_only',
                'version': VERSION,
                'updated_ts': _v783_now,
                'elapsed_sec': round(_v783_now-cycle_ts,3),
                'evaluated': evaluated,
                'stage_counts': counts,
                'lane_counts': lane_counts,
                'reason_top': reason_top_light,
                'sample': rows[:8],
            })
            write_status(
                'running',
                phase='fast_cycle_done_v783',
                phase_note='candidate/priority published; heavy display cache skipped by throttle',
                phase_started_ts=cycle_ts,
                strategy_worker_version=VERSION,
                main_version=MAIN_VERSION,
                deploy_version=MAIN_DEPLOY_VERSION,
                evaluated=evaluated,
                row_count=evaluated,
                s_count=len(rows),
                paper_latest_count=len(rows),
                s1_count=counts.get('S1',0),
                s2_count=counts.get('S2',0),
                s3_count=counts.get('S3',0),
                target_count=len(targets),
                priority_request_count=len(priority_requests),
                last_sec=round(_v783_now-cycle_ts,3),
                publish_sec_v783=round(_v783_now-cycle_ts,3),
                display_cache_throttled_v783=True,
                display_cache_age_sec_v783=round(float(_v783_display_age),3),
                status_route_schema='strategy_status_v783_fast_cycle_split',
                **info_quality
            )
            return summary_light
        except Exception as exc:
            append_error(ERROR, 'v783_fast_cycle_split', exc)

    reason_top = _v510_reason_top(rows)
    summary = {"schema": V510_SCHEMA, "version": VERSION, "main_version": MAIN_VERSION, "updated_ts": nowv, "updated_text": now_text(nowv), "evaluated": evaluated, "paper_latest_count": len(rows), "s_count": len(rows), "s_stage_counts": counts, "stage_counts": counts, "s1_count": counts.get("S1",0), "s2_count": counts.get("S2",0), "s3_count": counts.get("S3",0), "lane_counts": lane_counts, "reason_top": reason_top, "s1_diagnostic": {"schema":"v732_promotion_stage_spine", "near_miss_count": s1_near_count, "missing_top": dict(s1_missing_counter.most_common(8)), "s2_to_s1_promoted_count_v732": s2_to_s1_promoted_count_v732, "s2_to_s1_blocked_count_v732": s2_to_s1_promotion_blocked_count_v732, "promotion_reason_top_v732": dict(s2_to_s1_promotion_reason_top_v732.most_common(8)), "promotion_blocked_top_v732": dict(s2_to_s1_promotion_blocked_top_v732.most_common(8)), "promotion_family_count_v732": dict(s2_to_s1_promotion_family_counter_v732.most_common(8)), "promotion_family_promoted_v732": dict(s2_to_s1_promotion_family_promoted_v732.most_common(8)), "promotion_family_blocked_v732": dict(s2_to_s1_promotion_family_blocked_v732.most_common(8)), "common_uprising_target_count_v732": common_uprising_target_count_v732, "common_uprising_pass_count_v732": common_uprising_pass_count_v732, "common_uprising_block_top_v732": dict(common_uprising_block_top_v732.most_common(8)), "promotion_stage_spine_v732": v732_promotion_spine_summary, "s1_hold_summary_v732": {"count": v732_s1_hold_summary.get("count"), "fresh": v732_s1_hold_summary.get("fresh_count"), "stale": v732_s1_hold_summary.get("stale_count"), "trigger_wait": v732_s1_hold_summary.get("trigger_wait_count"), "open_ready": v732_s1_hold_summary.get("open_ready_count")}}, "target_count": len(targets), "priority_request_count": len(priority_requests), "events": display_rows[:20], "sample": display_rows[:20], "top_candidates": display_rows[:20], "last_sec": round(nowv - cycle_ts, 3), "policy": "v754: fresh S1/S2 source lifecycle reset 유지. paper entry snapshot spine은 pre-main active owner. 조건값/청산/자동매수 변경 없음."}
    summary["promotion_stage_spine_v732"] = v732_promotion_spine_summary
    summary["s1_hold_summary_v732"] = v732_s1_hold_summary
    summary.update(info_quality)
    try:
        cov = summary.get('v661_coverage_summary') if isinstance(summary.get('v661_coverage_summary'), dict) else {}
        summary['strategy_input_count_v661'] = int(cov.get('feature_input_count') or summary.get('evaluated') or len(rows))
        summary['strategy_coverage_rows_v661'] = int(summary.get('strategy_coverage_rows_v661') or len(rows))
        summary['trade_candidate_rows_v661'] = int(summary.get('trade_candidate_rows_v661') or max(0, len(rows) - int(cov.get('coverage_added_count') or 0)))
    except Exception:
        pass
    summary["freshness_overlay"] = {"schema": "v536_profile_simplified", "scanner_hot_cache_age_sec": round(_v521_file_age(SCANNER_HOT), 3), "orderflow_cache_age_sec": round(_v521_file_age(ORDERFLOW), 3)}
    summary["v574_fresh_urgent_summary"] = v574_fresh_urgent_summary
    summary["v608_candle_urgent_summary"] = v608_candle_urgent_summary
    summary["v655_recheck_lane_summary"] = v655_recheck_lane_summary
    summary["v655_recheck_lane_counts"] = v655_recheck_lane_summary.get("counts") if isinstance(v655_recheck_lane_summary, dict) else {}
    summary["fresh_urgent_request_count_v574"] = int(v574_fresh_urgent_summary.get("request_count") or 0) if isinstance(v574_fresh_urgent_summary, dict) else 0
    summary["s2_promotion_trace"] = s2_promotion_trace
    summary["s2_promotion_trace_schema"] = s2_promotion_trace.get("schema")
    summary["s2_promotion_trace_file"] = str(S2_PROMOTION_TRACE)
    save_json(SUMMARY, summary)
    save_json(REJECT, {**summary, "reject_count": len(rejects), "reject_sample": rejects[:30]})
    legacy_top = _v513_legacy_candidate_reason_top(display_rows, limit=10)
    compact = {"schema": "candidate_reason_compact_cache_v557_worker_rendered", "version": VERSION, "updated_ts": nowv, "updated_text": now_text(nowv), "status": "fresh", "evaluated": evaluated, "paper_latest_count": len(rows), "candidate_count": len(rows), "raw_candidate_count": len(rows), "stale_candidate_count": 0, "stale_s1_ignored_count": 0, "display_count": len(display_rows), "s_stage_counts": counts, "stage_counts": counts, "reason_top": reason_top, "missing_info_top": [x for x in reason_top if "정보" in x.get("reason", "")], "metric_spine_source_top": [{"reason": "v513_canonical_final_rows", "count": len(rows)}], "top_candidates": legacy_top, "display_rows": display_rows, "display_candidates": display_rows, "candidates": display_rows, "items": display_rows, "rows": display_rows, "top": legacy_top, "policy": summary["policy"]}
    compact["s2_promotion_trace"] = s2_promotion_trace
    compact["v574_fresh_urgent_summary"] = v574_fresh_urgent_summary
    compact["v608_candle_urgent_summary"] = v608_candle_urgent_summary
    compact["v655_recheck_lane_summary"] = v655_recheck_lane_summary
    compact["fresh_urgent_request_count_v574"] = int(v574_fresh_urgent_summary.get("request_count") or 0) if isinstance(v574_fresh_urgent_summary, dict) else 0
    compact["s2_promotion_trace_file"] = str(S2_PROMOTION_TRACE)
    if 'v661_coverage_summary' in summary:
        compact['v661_coverage_summary'] = summary.get('v661_coverage_summary')
        compact['strategy_input_count_v661'] = summary.get('strategy_input_count_v661')
        compact['strategy_coverage_rows_v661'] = summary.get('strategy_coverage_rows_v661')
        compact['trade_candidate_rows_v661'] = summary.get('trade_candidate_rows_v661')
    # v782: candidate_reason text is display-only and expensive.
    # Build it on a short throttle; every cycle still publishes PAPER_LATEST/HANDOFF/SUMMARY.
    _v782_text_age = _v521_file_age(CANDIDATE_REASON_TEXT_CACHE)
    _v782_prev_compact = load_json(CANDIDATE_REASON_COMPACT_CACHE, {}) or {}
    if _v782_text_age > 30.0 or not isinstance(_v782_prev_compact, dict) or not _v782_prev_compact.get('summary_text'):
        v557_summary = _v557_build_candidate_reason_summary(display_rows, counts, reason_top, nowv)
        try:
            v557_summary = _v661_append_trigger_audit_text(v557_summary, rows, nowv)
        except Exception as exc:
            append_error(ERROR, 'v661_append_trigger_audit_text', exc)
    else:
        v557_summary = {
            'schema': 'candidate_reason_summary_text_v782_throttled_display',
            'summary_text': _v782_prev_compact.get('summary_text') or '',
            'batch_state': _v782_prev_compact.get('batch_state') if isinstance(_v782_prev_compact.get('batch_state'), dict) else {},
            'throttled_display_cache_v782': True,
            'text_age_sec': round(_v782_text_age, 3),
        }
    compact["summary_schema"] = v557_summary.get("schema")
    compact["summary_text"] = v557_summary.get("summary_text")
    compact["batch_state"] = v557_summary.get("batch_state")
    # v604: /candidate_reason 기본 명령이 큰 JSON을 파싱하지 않도록
    # worker가 미리 만든 text cache를 별도 파일로 봉인한다.
    # 정보 삭제가 아니라 소비 경로 변경이다: main_bot은 이 작은 text cache만 읽는다.
    try:
        text_summary = str(v557_summary.get("summary_text") or "").strip()
        CANDIDATE_REASON_TEXT_CACHE.parent.mkdir(parents=True, exist_ok=True)
        tmp_txt = CANDIDATE_REASON_TEXT_CACHE.with_suffix(CANDIDATE_REASON_TEXT_CACHE.suffix + ".tmp")
        tmp_txt.write_text(text_summary + "\n", encoding="utf-8")
        os.replace(tmp_txt, CANDIDATE_REASON_TEXT_CACHE)
        state_obj = {
            "schema": "candidate_reason_text_state_v610",
            "version": VERSION,
            "updated_ts": nowv,
            "updated_text": now_text(nowv),
            "text_cache_file": str(CANDIDATE_REASON_TEXT_CACHE),
            "text_len": len(text_summary),
            "stage_counts": counts,
            "rows": len(rows),
            "s1_count": counts.get("S1", 0),
            "s2_count": counts.get("S2", 0),
            "s3_count": counts.get("S3", 0),
            "priority_request_count": len(priority_requests),
            "policy": "v610: main /candidate_reason reads this text file directly; candle information depth is tiered by core/near/watch.",
        }
        save_json(CANDIDATE_REASON_STATE_CACHE, state_obj)
    except Exception as exc:
        append_error(ERROR, "v604_candidate_reason_text_cache", exc)
    summary["candidate_reason_worker_rendered"] = True
    summary["candidate_reason_summary_schema"] = v557_summary.get("schema")
    compact.update(info_quality)
    compact["top_rows"] = legacy_top
    compact["display_candidates"] = compact.get("display_rows", [])
    compact["source_file"] = str(PAPER_LATEST)
    compact["source_policy"] = summary["policy"]
    summary["legacy_candidate_reason_alias_publish"] = False  # v525: disabled
    re_rows = [r for r in rows if _v510_stage(r) in ("S2", "S3")]
    re_state_counts: Dict[str, int] = {}
    for r in re_rows:
        st = "위험우선" if r.get("risk_tags") else ("유연재확인" if _v510_stage(r) == "S2" else "추적중")
        r["recheck_state"] = st
        re_state_counts[st] = re_state_counts.get(st, 0) + 1
    recheck_display = _v512_display_rows(re_rows, 160)
    recheck = {"schema": "recheck_candidates_cache_v513", "version": VERSION, "updated_ts": nowv, "updated_text": now_text(nowv), "candidate_count": len(re_rows), "state_counts": re_state_counts, "top": recheck_display[:80], "top_candidates": recheck_display[:80], "display_rows": recheck_display, "rows": recheck_display, "promotion_summary": {"s1_promotion_count": counts.get("S1",0), "policy": "S2=진입계획 대기, S3=구조관찰. paper OPEN은 S1만."}, "s2_promotion_trace": s2_promotion_trace}
    summary["legacy_recheck_cache_publish"] = False  # v525: disabled; target_router reads paper_latest
    summary["legacy_recheck_state_publish"] = False  # v525 disabled
    s1_rows = [r for r in display_rows if _v510_stage(r)=="S1"]
    life = {"schema": "s1_lifecycle_trace_v563_canonical_s2_promotion", "version": VERSION, "worker": VERSION, "updated_ts": nowv, "updated_text": now_text(nowv), "current_s1_count": counts.get("S1",0), "current_s2_count": counts.get("S2",0), "current_s3_count": counts.get("S3",0), "recent_s1_count": counts.get("S1",0), "paper_waiting_count": 0, "paper_pre_downgrade_count": 0, "paper_block_count": 0, "paper_final_block_count": 0, "expired_s1_ignored_count": 0, "fresh_count": len(rows), "raw_count": len(rows), "current_fresh_count": len(rows), "current_raw_count": len(rows), "fresh_candidate_count": len(rows), "raw_candidate_count": len(rows), "counts": counts, "stage_counts": counts, "current_s1": s1_rows, "current_s1_rows": s1_rows, "paper_waiting": [], "paper_pre_downgrade": [], "paper_blocked": [], "paper_final_blocked": [], "expired_s1_ignored": [], "flow_rows": display_rows[:80], "recent_flow": display_rows[:80], "recent_rows": display_rows[:80], "top": display_rows[:80], "rows": display_rows, "s2_promotion_trace": s2_promotion_trace, "policy": "candidate_reason/s1_lifecycle/summary all read the same final_rows with S2 promotion lifecycle."}
    summary["legacy_s1_lifecycle_alias_publish"] = False  # v525: disabled
    summary["legacy_s1_lifecycle_state_publish"] = False  # v525 disabled
    # v550: publish every canonical read cache from the same final_rows batch.
    # This removes the split where paper_candidates_latest was current but
    # /candidate_reason kept reading an old compact cache.  No strategy or exit
    # threshold is changed here; this is a factory-output spine fix only.
    save_json(CANDIDATE_REASON_COMPACT_CACHE, compact)
    save_json(RECHECK_CACHE, recheck)
    save_json(RECHECK_STATE, recheck)
    save_json(S1_LIFECYCLE_TRACE, life)
    save_json(S1_LIFECYCLE_STATE, life)

    # v512: summary/health readers also need direct pointers to compact/lifecycle caches.
    _v512_enrich_summary_pointers(summary, compact, life, recheck)
    save_json(SUMMARY, summary)
    save_json(REJECT, {**summary, "reject_count": len(rejects), "reject_sample": rejects[:30]})
    can = {"schema": "strategy_canonical_summary_v584_canonical_metric_row", "version": VERSION, "updated_ts": nowv, "cycle_started_ts": cycle_ts, "cycle_elapsed_sec": round(nowv-cycle_ts,3), "s_stage_counts": counts, "paper_latest_count": len(rows), "candidate_reason": {"schema": compact["schema"], "updated_ts": nowv, "candidate_count": len(rows)}, "recheck": {"schema": recheck["schema"], "updated_ts": nowv, "candidate_count": len(re_rows)}, "s1_lifecycle": {"schema": life["schema"], "updated_ts": nowv, "current_s1_count": counts.get("S1",0)}, "s2_promotion_trace": s2_promotion_trace, "v574_fresh_urgent_summary": v574_fresh_urgent_summary, "source_policy": summary["policy"]}
    save_json(CANONICAL_STRATEGY_SUMMARY, can)
    price_ready_count = sum(1 for r in rows if _v510_num(r.get("current_price"), r.get("entry_price"), r.get("price"), default=0.0) > 0)
    save_json(HANDOFF, {"schema": "paper_handoff_status_v525", "version": VERSION, "updated_ts": nowv, "updated_text": now_text(nowv), "latest_count": len(rows), "stage_counts": counts, "lane_counts": lane_counts, "price_ready_count": price_ready_count, "source": "paper_candidates_latest", "archive_runtime_open": False, "old_latest_remix": False, "price_policy": "strategy seals current_price/entry_price/detected_price and v554 structure_levels/entry_plan for paper_bot"})
    save_json(V510_TRACE, {"schema": V510_SCHEMA, "version": VERSION, "updated_ts": nowv, "elapsed_sec": round(nowv-cycle_ts,3), "evaluated": evaluated, "stage_counts": counts, "lane_counts": lane_counts, "reason_top": reason_top, "sample": rows[:12], "strategy_input_count_v661": summary.get('strategy_input_count_v661'), "strategy_coverage_rows_v661": summary.get('strategy_coverage_rows_v661'), "trade_candidate_rows_v661": summary.get('trade_candidate_rows_v661')})
    write_status("running", phase="cycle_done_v525", phase_note="v584 canonical metric row publish", phase_started_ts=cycle_ts, strategy_worker_version=VERSION, main_version=MAIN_VERSION, deploy_version=MAIN_DEPLOY_VERSION, evaluated=evaluated, row_count=evaluated, s_count=len(rows), paper_latest_count=len(rows), s1_count=counts.get("S1",0), s2_count=counts.get("S2",0), s3_count=counts.get("S3",0), target_count=len(targets), priority_request_count=len(priority_requests), last_sec=round(nowv-cycle_ts,3), status_route_schema="strategy_status_v584_canonical_metric_row", **info_quality)
    return summary


# =============================================================================
# strategy_worker v0.153 / v660: strategy input rows restore
# - v659 이후 feature/candle 갱신 타이밍에 따라 strategy 평가 rows가 80개대까지 줄어드는
#   부작용을 막는다.
# - feature_worker rows를 우선 사용하되, scanner/orderflow에는 있는데 feature에 없는 티커는
#   "feature_missing/stale" 후보 row로 보강해 평가 대상에서 사라지지 않게 한다.
# - 이 보강 row는 S1 조건을 통과시키기 위한 값 보정이 아니라, 누락 원인을 canonical row에
#   봉인하고 target_router/candle/feature가 다시 보게 하기 위한 입력 spine 복구다.
# =============================================================================
V660_STRATEGY_BUILD = "strategy_worker_v0.157_v664_trigger_wait_lifecycle"


def _v660_load_scanner_pool_map() -> Dict[str, Dict[str, Any]]:
    try:
        return map_rows(load_json(SCANNER_POOL, {}) or {})
    except Exception:
        return {}


def _v660_price_from_any(row: Dict[str, Any]) -> float:
    return _v510_num(
        row.get('current_price'), row.get('trade_price'), row.get('price'), row.get('close'),
        row.get('last_price'), row.get('detected_price'), default=0.0
    )


def _v660_widen_strategy_input(raw_feature_list: List[Dict[str, Any]], cycle_ts: float) -> Tuple[List[Dict[str, Any]], Dict[str, Any]]:
    fmap: Dict[str, Dict[str, Any]] = {}
    for r in raw_feature_list or []:
        if not isinstance(r, dict):
            continue
        t = ticker_norm(r.get('ticker') or r.get('symbol') or r.get('market'))
        if not t:
            continue
        rr = dict(r)
        rr.setdefault('ticker', t)
        rr.setdefault('strategy_input_source', rr.get('source') or 'feature_worker')
        rr.setdefault('feature_present_for_strategy', True)
        fmap[t] = rr

    scanner_map = _v660_load_scanner_pool_map()
    added: List[str] = []
    for t, src in scanner_map.items():
        if not t or t in fmap or not isinstance(src, dict):
            continue
        price = _v660_price_from_any(src)
        rr = dict(src)
        rr['ticker'] = t
        if price:
            rr.setdefault('current_price', price)
            rr.setdefault('price', price)
            rr.setdefault('detected_price', price)
        rr['strategy_input_source'] = 'scanner_pool_feature_missing_v660'
        rr['feature_present_for_strategy'] = False
        rr['feature_missing_for_strategy'] = True
        rr['v660_input_restore_reason'] = 'feature_worker row missing at strategy cycle; scanner pool row preserved for stale/missing diagnosis'
        stale = rr.get('stale_reasons') if isinstance(rr.get('stale_reasons'), list) else []
        rr['stale_reasons'] = _v510_uniq(list(stale) + ['feature_missing_v660'], 10)
        br = rr.get('block_reasons') if isinstance(rr.get('block_reasons'), list) else []
        rr['block_reasons'] = _v510_uniq(list(br) + ['정보오래됨: feature row missing'], 12)
        fmap[t] = rr
        added.append(t)

    out = list(fmap.values())
    scanner_count = len(scanner_map)
    feature_count = len(raw_feature_list or [])
    restored_count = len(added)
    ratio = round((len(out) / scanner_count * 100.0), 1) if scanner_count else 0.0
    summary = {
        'schema': 'strategy_input_restore_v660',
        'version': VERSION,
        'feature_input_count': feature_count,
        'scanner_pool_count': scanner_count,
        'restored_from_scanner_count': restored_count,
        'strategy_input_count': len(out),
        'strategy_input_vs_scanner_pct': ratio,
        'restored_sample': added[:20],
        'policy': '후보 판단 rows를 줄이지 않는다. feature 누락 티커는 S1 통과가 아니라 missing/stale reason 봉인용으로 strategy input에 보존한다.',
    }
    return out, summary




# =============================================================================
# strategy_worker v0.154 / v661: coverage rows + trigger writer 본선 고정
# - base/spike를 통과하지 못한 feature/scanner 입력도 후보판단 coverage row로 봉인한다.
# - paper OPEN 후보를 늘리는 것이 아니라, 사라진 티커를 S3 coverage/missing reason으로 남긴다.
# - trigger 감사 블록은 override 체인이 아니라 _v510_publish text writer 직전에 직접 보강한다.
# =============================================================================
V661_STRATEGY_BUILD = "strategy_worker_v0.157_v664_trigger_wait_lifecycle"


def _v661_row_ticker(row: Dict[str, Any]) -> str:
    try:
        return ticker_norm(row.get('ticker') or row.get('symbol') or row.get('market'))
    except Exception:
        return ''


def _v661_build_coverage_rows(feature_list: List[Dict[str, Any]], final_rows: List[Dict[str, Any]], ofmap: Dict[str, Dict[str, Any]], nowv: float) -> Tuple[List[Dict[str, Any]], Dict[str, Any]]:
    """v732: coverage/참고 row와 S3 관찰 row를 분리한다.

    원칙:
    - 급등초입 기준 미통과는 급등초입 전략의 미충족일 뿐, 공통 차단 사유가 아니다.
    - S3는 paper OPEN 대상이 아니라 관찰/놓친후보 복기 대상이다.
    - S3 관찰 기준은 고정 개수 제한이 아니라 가격반응/체결/지속/스프레드/구조 힌트 기반으로 판정한다.
    """
    existing = {_v661_row_ticker(r) for r in (final_rows or []) if isinstance(r, dict)}
    existing.discard('')
    rows: List[Dict[str, Any]] = []
    reason_counter: Counter = Counter()
    common_counter: Counter = Counter()
    strategy_counter: Counter = Counter()
    stale_counter: Counter = Counter()
    observe_counter: Counter = Counter()
    leak_count = 0

    for src in feature_list or []:
        if not isinstance(src, dict):
            continue
        t = _v661_row_ticker(src)
        if not t or t in existing:
            continue
        of = ofmap.get(t, {}) or {}

        react = _v510_price_reaction(src, of)
        buy = _v510_buy(of, src)
        sustain, sustain_source, sustain_real = _v524_sustain_detail(of, src)
        spread = _v510_spread(of, src)
        price = _v510_num(src.get('current_price'), src.get('price'), src.get('trade_price'), src.get('close'), of.get('quote_price'), of.get('current_price'), default=0.0)
        chg1 = _v510_num(src.get('change_1m'), src.get('price_change_1m'), default=0.0)
        chg3 = _v510_num(src.get('change_3m'), src.get('price_change_3m'), default=0.0)
        chg5 = _v510_num(src.get('change_5m'), src.get('price_change_5m'), default=0.0)
        short20 = _v510_num(of.get('price_chg_20s'), src.get('price_chg_20s'), default=0.0)
        short30 = _v510_num(of.get('price_chg_30s'), src.get('price_chg_30s'), default=0.0)
        accel10 = _v510_num(of.get('price_accel_10s'), src.get('price_accel_10s'), default=0.0)
        spike_probe_ok = max(chg1, chg3, react, short20, short30, accel10) >= 0.30

        structures = _v510_uniq(_v510_structure_tags(src), 10)
        struct_txt = " ".join(str(x) for x in structures)

        common_reasons: List[str] = ['전체시장 참고: 아직 후보 기준 전 단계']
        strategy_specific_misses: List[str] = []
        observe_reasons: List[str] = []

        if bool(src.get('feature_missing_for_strategy')):
            common_reasons.append('정보오래됨: feature row missing')
        if react < 0.35:
            common_reasons.append(f'가격반응 {react:+.2f}%<+0.35%')
        if buy < 0.55:
            common_reasons.append(f'매수체결 {buy:.2f}<0.55')
        if sustain < 0.70:
            common_reasons.append(f'1분지속 {sustain:.2f}<0.70')
        if spread > 0.35:
            common_reasons.append(f'스프레드 {spread:.2f}%>0.35%')

        if not spike_probe_ok:
            strategy_specific_misses.append('급등초입전략: 급등 초입 기준 미통과')
        strategy_specific_misses.append('기타전략: 구조/확인신호 부족으로 관찰 유지')

        # S3 관찰 기준: OPEN이 아니라 놓친 후보 복기용이다.
        # 너무 좁게 잠기지 않도록 가격/체결/지속/스프레드/구조 힌트 중 일부만 있어도 S3 관찰로 봉인한다.
        if react >= 0.10 or chg1 >= 0.10 or chg3 >= 0.30 or short20 >= 0.20 or short30 >= 0.20:
            observe_reasons.append('가격반응 관찰가치')
        if buy >= 0.55 or sustain >= 0.55:
            observe_reasons.append('체결/지속 관찰가치')
        if spread <= 0.18 and (react >= 0.00 or buy >= 0.45 or sustain >= 0.45):
            observe_reasons.append('스프레드 양호 관찰가치')
        if any(w in struct_txt for w in ('VWAP', 'EMA', '돌파', '박스', '지지', '저항', '돈흐름', '구조')):
            observe_reasons.append('차트구조 관찰가치')

        stale: List[str] = []
        candle_age = _v510_num(src.get('official_candle_age'), src.get('candle_age_sec'), src.get('candle_age'), default=-1.0)
        micro_age = _v510_num(of.get('micro_age_sec'), of.get('trade_age_sec'), of.get('_cache_age_sec'), default=-1.0)
        order_age = _v510_num(of.get('orderflow_age_sec'), of.get('trade_age_sec'), of.get('_cache_age_sec'), default=-1.0)
        if candle_age > 120:
            stale.append(f'candle {candle_age:.0f}s'); stale_counter['candle'] += 1
        if micro_age > 20:
            stale.append(f'micro {micro_age:.0f}s'); stale_counter['micro'] += 1
        if order_age > 20:
            stale.append(f'orderflow {order_age:.0f}s'); stale_counter['orderflow'] += 1

        severe_stale = (candle_age > 300) or (micro_age > 90) or (order_age > 90)
        observe_stage = bool(observe_reasons) and spread <= 0.50 and not severe_stale

        for rr in common_reasons[:8]:
            reason_counter[str(rr)] += 1; common_counter[str(rr)] += 1
            if '급등초입전략' in str(rr) or 'spike' in str(rr).lower():
                leak_count += 1
        for rr in strategy_specific_misses[:8]:
            strategy_counter[str(rr)] += 1
        for rr in observe_reasons[:8]:
            observe_counter[str(rr)] += 1

        score = _v510_num(src.get('score'), default=0.0) + max(0.0, react) * 8.0 + max(0.0, chg3) * 3.0 + min(10.0, max(0.0, buy) * 5.0) + min(10.0, max(0.0, sustain) * 5.0)

        lane = 's3_observe' if observe_stage else 'coverage'
        stage = 'S3' if observe_stage else '비후보'
        strategy_key = 'coin_quality_s3_observe' if observe_stage else 'coin_quality_coverage'
        strategy_label = 'S3 관찰/복기 후보' if observe_stage else '코인품질 전체커버'
        row_reasons = _v510_uniq((observe_reasons if observe_stage else common_reasons), 12)
        block_reasons = _v510_uniq((observe_reasons + common_reasons) if observe_stage else common_reasons, 12)
        risk_tags = _v510_uniq((['S3 관찰/복기 전용'] if observe_stage else ['coverage 관찰']) + ([f'스프레드부담 {spread:.2f}'] if spread > 0.35 else []), 8)

        row = {
            'schema': 'strategy_coverage_light_row_v732_s3_observe',
            'version': VERSION,
            'ticker': t,
            'market': f'KRW-{t}' if t else src.get('market'),
            'symbol': f'{t}_KRW' if t else src.get('symbol'),
            'event_id': _v510_event_id(t, strategy_key, lane, nowv),
            'event_key': _v510_event_id(t, strategy_key, lane, nowv),
            'created_at': nowv,
            'candidate_created_at': nowv,
            'source_created_at': nowv,
            'detected_ts': nowv,
            'event_ts': nowv,
            'created_at_text': now_text(nowv),
            'updated_ts': nowv,
            'expires_at': nowv + 180,
            'strategy_key': strategy_key,
            'paper_strategy_key': strategy_key,
            'strategy_label': strategy_label,
            'strategy': strategy_label,
            'matched_strategy_keys': [strategy_key],
            'matched_strategy_labels': [strategy_label],
            'canonical_lane': lane,
            'gate_scope_v732': 's3_observe_or_coverage_reference',
            's_stage': stage, 'candidate_stage': stage, 'candidate_grade': stage, 'stage': stage, 'grade': stage,
            'score': round(score, 3),
            'current_price': price, 'entry_price': price, 'detected_price': price, 'live_price': price, 'price': price, 'trade_price': price,
            'price_source': 'strategy_v732_s3_observe' if observe_stage else 'strategy_v732_coverage_light',
            'price_ready': bool(price and price > 0),
            'price_reaction_pct': round(react, 4),
            'change_1m_pct': chg1, 'change_3m_pct': chg3, 'change_5m_pct': chg5,
            'spread_pct': round(spread, 4), 'slippage_pct': round(spread, 4),
            'buy_ratio': round(buy, 4), 'buy_sustain_1m': round(sustain, 4),
            'buy_sustain_1m_source': sustain_source, 'buy_sustain_1m_real': bool(sustain_real),
            'structure_tags': structures,
            'risk_tags': risk_tags,
            'stale_reasons': stale,
            'freshness_status': 'recheck' if stale else 'fresh',
            'reason': ' / '.join(row_reasons),
            's_stage_reasons': row_reasons,
            'block_reasons': block_reasons,
            'strategy_specific_misses': _v510_uniq(strategy_specific_misses, 12),
            's3_observe_v732': bool(observe_stage),
            'coverage_only_v661': not observe_stage,
            'coverage_light_v662': True,
            'coverage_light_v732': not observe_stage,
            'trade_candidate_row_v661': bool(observe_stage),
            'open_eligible': False,
            'paper_bot_open': False,
            'paper_experiment_open': False,
            'paper_experiment_handoff_ready_v674': False,
            'trade_ready': False,
            'v661_coverage_reason': '전략별 gate 미충족 row를 삭제하지 않고 coverage/비후보 또는 S3 관찰로 봉인',
            'v732_policy': 'S3는 paper OPEN이 아니라 놓친후보 복기용 관찰 후보다.',
            'canonical_entry_decision': {'schema':'coverage_light_v732_s3_observe', 's1_allowed': False, 'action': 'observe' if observe_stage else 'coverage', 'reasons': block_reasons, 'strategy_specific_misses': _v510_uniq(strategy_specific_misses, 12)},
            'entry_context': {'strategy_key': strategy_key, 'canonical_lane': lane, 'current_price': price, 'stale_reasons': stale, 'reasons': block_reasons, 'strategy_specific_misses': _v510_uniq(strategy_specific_misses, 12), 's3_observe_v732': bool(observe_stage)},
        }
        for _ok in V597_OFFICIAL_STRUCTURE_KEYS:
            _ov = src.get(_ok)
            if _ov not in (None, ''):
                row[_ok] = _ov
        rows.append(row)

    summary = {
        'schema': 'strategy_coverage_rows_v732_s3_observe',
        'version': VERSION,
        'feature_input_count': len(feature_list or []),
        'final_before_coverage_count': len(final_rows or []),
        'coverage_added_count': len(rows),
        's3_observe_added_count_v732': sum(1 for r in rows if r.get('s3_observe_v732')),
        'coverage_light_count_v732': sum(1 for r in rows if not r.get('s3_observe_v732')),
        'coverage_reason_top': dict(reason_counter.most_common(10)),
        'common_gate_reason_top_v732': dict(common_counter.most_common(10)),
        'strategy_gate_reason_top_v732': dict(strategy_counter.most_common(10)),
        's3_observe_reason_top_v732': dict(observe_counter.most_common(10)),
        'coverage_stale_top_v732': dict(stale_counter.most_common(8)),
        'gate_scope_check_v732': {'common_gate_spike_leak_count': leak_count, 'policy_ok': leak_count == 0, 'spike_gate_scope': 'breakout/spike strategy only'},
        'policy': 'S3 관찰 후보는 OPEN하지 않고 놓친후보 복기용으로 봉인한다. 급등초입 미충족은 공통 차단이 아니라 전략별 미충족으로 분리한다.',
    }
    return rows, summary

def _v661_append_trigger_audit_text(v557_summary: Dict[str, Any], display_rows: List[Dict[str, Any]], nowv: float) -> Dict[str, Any]:
    """v662: trigger audit block을 summary_text 끝이 아니라 상단 품질판 근처에 직접 삽입한다."""
    base = dict(v557_summary or {})
    text = str(base.get('summary_text') or '').rstrip()
    # 기존 v659/v661 블록이 있으면 제거하고 v662 블록으로 다시 넣는다.
    for marker in ('[방아쇠 구조검증 · v659]', '[방아쇠 구조검증 · v662]'):
        if marker in text:
            text = text.split(marker)[0].rstrip()
    rows = [r for r in (display_rows or []) if isinstance(r, dict)]
    audits: List[Dict[str, Any]] = []
    for r in rows:
        if not isinstance(r, dict):
            continue
        if bool(r.get('coverage_only_v661')) or bool(r.get('coverage_light_v662')):
            # trigger 정밀검증은 실제 후보/고품질/S2 중심으로 한다. coverage row는 전체판단 표시용이다.
            continue
        try:
            a = r.get('trigger_structure_audit_v659') if isinstance(r.get('trigger_structure_audit_v659'), dict) else _v659_trigger_audit(r)
        except Exception:
            a = {'status': 'audit_error', 'risk_flags': ['audit_error'], 'source': 'error'}
        q = _v510_num(r.get('coin_quality_score'), default=0.0)
        risk = _v510_num(r.get('execution_risk_score'), default=99.0)
        stage = _v510_stage(r)
        if stage in ('S1','S2') or q >= 58 or str(a.get('status')) in ('trigger_wait','trigger_missing'):
            audits.append({'ticker': _v661_row_ticker(r), 'stage': stage, 'q': round(q,1), 'risk': round(risk,1), 'audit': a})
    status_counter = Counter(str(x['audit'].get('status') or '-') for x in audits)
    flag_counter: Counter = Counter()
    for x in audits:
        for f in x['audit'].get('risk_flags') or []:
            flag_counter[str(f)] += 1
    wait_rows = [x for x in audits if str(x['audit'].get('status')) in ('trigger_wait','trigger_missing')]
    wait_rows.sort(key=lambda x: (0 if x['stage']=='S2' else 1, -float(x['q']), float(x['risk'])))
    def fmt(x: Dict[str, Any]) -> str:
        a = x['audit']
        gap = a.get('trigger_gap_pct')
        gap_txt = '-' if gap is None else f"{float(gap):+.2f}%"
        trig = a.get('trigger_price')
        trig_txt = '-' if trig in (None, '') else f"{float(trig):.8g}"
        cur = a.get('current_price')
        cur_txt = '-' if cur in (None, '') else f"{float(cur):.8g}"
        conf = a.get('trigger_confidence')
        conf_txt = '-' if conf is None else f"{float(conf):.0f}"
        c_age = a.get('candle_age_sec')
        c_txt = '-' if c_age is None else f"{float(c_age):.0f}s"
        flags = ','.join(str(f) for f in (a.get('risk_flags') or [])[:3]) or 'ok'
        return f"{x['ticker']} {x['stage']} Q{x['q']} 현재 {cur_txt} / 방아쇠 {trig_txt} / gap {gap_txt} / src {a.get('source')} / conf {conf_txt} / candle {c_txt} / {flags}"
    block = [
        '[방아쇠 구조검증 · v662]',
        '- 상태 TOP: ' + (' / '.join(f'{k} {v}' for k, v in status_counter.most_common(6)) if status_counter else '-'),
        '- 의심 TOP: ' + (' / '.join(f'{k} {v}' for k, v in flag_counter.most_common(8)) if flag_counter else '-'),
        '- 대기/누락 TOP: ' + (' / '.join(fmt(x) for x in wait_rows[:6]) if wait_rows else '-'),
        '- 기준: S2/고품질 후보의 trigger_price·현재가·gap·source·candle age만 감사. 방아쇠 미도달 OPEN 금지 유지.',
    ]
    lines = text.splitlines() if text else []
    insert_at = min(len(lines), 7)
    # 품질판 바로 앞 또는 fresh_wait 뒤에 넣어 batch 요약에서 잘리지 않게 한다.
    for i, line in enumerate(lines):
        if '[코인 종합품질' in line or '[fresh_wait 상세' in line:
            insert_at = i
            break
    lines[insert_at:insert_at] = block
    base['summary_text'] = '\n'.join(lines)
    bs = base.get('batch_state') if isinstance(base.get('batch_state'), dict) else {}
    bs = dict(bs)
    bs['schema'] = 'candidate_reason_batch_state_v662_trigger_audit_visible'
    bs['trigger_audit_v662'] = {'status_counts': dict(status_counter), 'risk_top': dict(flag_counter.most_common(8)), 'wait_top': wait_rows[:12]}
    base['batch_state'] = bs
    base['schema'] = 'candidate_reason_summary_text_v662_trigger_audit_visible'
    return base



def run_once() -> Dict[str, Any]:  # type: ignore[override]
    cycle_ts = now_ts()
    try:
        write_status("running", phase="evaluating_v544", phase_note="v529 S1 checklist inline publish 시작", strategy_worker_version=VERSION)
        fobj = load_json(FEATURE, {}) or {}
        raw_feature_list = feature_rows(fobj)
        raw_feature_list, v660_input_restore_summary = _v660_widen_strategy_input(raw_feature_list, cycle_ts)
        # v597: feature rows may be produced by an older feature worker during deploy overlap.
        # Read candle_worker cache directly as a worker-cache overlay so official structure inputs
        # reach canonical rows without strategy calling external APIs.
        candle_map = map_rows(load_json(CANDLE, {}) or {})
        raw_feature_list = [_v597_overlay_candle_cache(src, candle_map, cycle_ts) for src in raw_feature_list]
        hotmap = _v521_hot_map()
        feature_list = [_v521_overlay_feature(src, hotmap.get(ticker_norm(src.get("ticker") or src.get("market") or src.get("symbol")), {})) for src in raw_feature_list]
        ofmap = _v521_load_map_with_cache_age(ORDERFLOW, "orderflow")
        base_rows, rejects, reqs = _v510_base_lane(cycle_ts, feature_list, ofmap)
        spike_rows = _v510_spike_lane(cycle_ts, feature_list, ofmap)
        final_rows = _v510_merge_rows(base_rows + spike_rows, cycle_ts)
        coverage_rows_v661, v661_coverage_summary = _v661_build_coverage_rows(feature_list, final_rows, ofmap, cycle_ts)
        if coverage_rows_v661:
            # v662: active trade rows는 기존 final gate를 이미 통과했다. coverage row는 S3 관찰용 경량 row라
            # 다시 _v510_final_gate/entry-plan을 태우지 않고 중복 ticker만 안전 병합한다.
            _merged_by_ticker = {_v661_row_ticker(r): r for r in final_rows if isinstance(r, dict) and _v661_row_ticker(r)}
            for _cr in coverage_rows_v661:
                _ct = _v661_row_ticker(_cr)
                if _ct and _ct not in _merged_by_ticker:
                    _merged_by_ticker[_ct] = _cr
            final_rows = sorted(_merged_by_ticker.values(), key=lambda x: (_STAGE_ORDER.get(_v510_stage(x),0), _v510_num(x.get('score'), default=0.0), _event_created_ts(x)), reverse=True)
        info_quality = _v512_info_quality(feature_list, ofmap)
        if isinstance(info_quality, dict):
            info_quality['v660_input_restore_summary'] = v660_input_restore_summary
            info_quality['strategy_input_count_v660'] = v660_input_restore_summary.get('strategy_input_count')
            info_quality['strategy_input_restored_v660'] = v660_input_restore_summary.get('restored_from_scanner_count')
            info_quality['v661_coverage_summary'] = v661_coverage_summary
            info_quality['coverage_rows_v661'] = v661_coverage_summary.get('coverage_added_count')
            info_quality['strategy_coverage_rows_v661'] = len(final_rows)
            info_quality['trade_candidate_rows_v661'] = max(0, len(final_rows) - int(v661_coverage_summary.get('coverage_added_count') or 0))
        # Requests from spike rows are added after merge so stale/blocked rows still get recheck/urgent targets if useful.
        for r in final_rows:
            t = ticker_norm(r.get("ticker"))
            if not t: continue
            bucket = "s1_candidate" if _v510_stage(r)=="S1" else ("spike_recheck" if str(r.get("canonical_lane"))=="spike" else "recheck_candidate")
            pri = 180 if _v510_stage(r)=="S1" else (130 if _v510_stage(r)=="S2" else 90)
            reqs.append({"ticker": t, "bucket": bucket, "priority": pri + _v510_num(r.get("score"), default=0.0), "need": ["quote", "micro"], "source": "strategy_worker_v529", "strategy_key": r.get("strategy_key"), "stage": _v510_stage(r), "reasons": r.get("s_stage_reasons", [])[:6], "updated_ts": cycle_ts})
        return _v510_publish(final_rows, rejects, reqs, len(feature_list), cycle_ts, info_quality)
    except Exception as exc:
        append_error(ERROR, "v513_run_once", exc)
        write_status("error", error=f"{exc.__class__.__name__}: {exc}", strategy_worker_version=VERSION)
        raise



# =============================================================================
# strategy_worker v0.121 / v558: worker-rendered candidate summary cache producer
# - 메인봇 기본 명령은 후보 정렬/포맷을 하지 않고 이 summary_text만 읽는다.
# - paper_candidates_latest, candidate_reason compact, handoff status를 같은 final_rows에서 함께 생산한다.
# - 조건/S1/S2/S3/청산 수치 변경 없음.
# =============================================================================
def _v558_label_list(vals: Any, limit: int = 5) -> str:
    if not isinstance(vals, list):
        return "-"
    out: List[str] = []
    for v in vals:
        txt = str(v or "").strip()
        if txt and txt not in out:
            out.append(txt)
        if len(out) >= limit:
            break
    return ", ".join(out) if out else "-"


def _v558_price(x: Any) -> str:
    v = _v510_num(x, default=0.0)
    if v <= 0:
        return "-"
    if v >= 1000:
        return f"{v:,.0f}"
    if v >= 100:
        return f"{v:.1f}".rstrip("0").rstrip(".")
    if v >= 10:
        return f"{v:.2f}".rstrip("0").rstrip(".")
    if v >= 1:
        return f"{v:.4f}".rstrip("0").rstrip(".")
    return f"{v:.6f}".rstrip("0").rstrip(".")


def _v558_top_join(items: Any, limit: int = 5) -> str:
    if not items:
        return "-"
    out: List[str] = []
    if isinstance(items, dict):
        seq = sorted(items.items(), key=lambda kv: -int(kv[1] or 0))
        for k, v in seq[:limit]:
            out.append(f"{k} {v}")
    elif isinstance(items, list):
        for it in items[:limit]:
            if isinstance(it, dict):
                name = str(it.get("reason") or it.get("name") or it.get("key") or "-")
                cnt = it.get("count") or it.get("n") or ""
                out.append(f"{name} {cnt}".strip())
            else:
                out.append(str(it))
    return " / ".join([x for x in out if x and x != "-"]) or "-"


def _v558_counter_top(rows: List[Dict[str, Any]], keys: Tuple[str, ...], limit: int = 5) -> str:
    c: Counter = Counter()
    for r in rows:
        for k in keys:
            vals = r.get(k)
            if isinstance(vals, list):
                for v in vals:
                    txt = str(v or "").strip()
                    if txt: c[txt] += 1
            elif vals not in (None, "", [], {}):
                txt = str(vals).strip()
                if txt: c[txt] += 1
    return " / ".join(f"{k} {v}" for k, v in c.most_common(limit)) if c else "-"


def _v558_metric(row: Dict[str, Any], key: str, default: float = 0.0) -> float:
    m = row.get("metrics") if isinstance(row.get("metrics"), dict) else {}
    return _v510_num(row.get(key), m.get(key), default=default)


def _v558_build_candidate_reason_summary(display_rows: List[Dict[str, Any]], counts: Dict[str, int], reason_top: Any, nowv: float) -> Dict[str, Any]:
    rows = [r for r in display_rows if isinstance(r, dict)]
    s2_rows = [r for r in rows if _v510_stage(r) == "S2"]
    s1_near = sum(1 for r in rows if bool(r.get("s1_near_miss")) or str(r.get("s1_distance_label") or "").startswith("S1"))
    strategy_top = _v558_counter_top(rows, ("matched_strategy_labels", "strategy_tags", "structure_tags", "strategy", "strategy_key"), 5)
    risk_top = _v558_counter_top(rows, ("risk_tags", "execution_risk_tags", "structure_risk_tags"), 5)
    s2_recheck_top = _v558_counter_top(s2_rows, ("recheck_reasons", "s2_recheck_reasons", "missing_info", "block_reasons"), 5)
    top = rows[:3]
    lines = [
        "🧭 후보판정 이유 /candidate_reason · v558 worker-rendered cache",
        "- 기준: strategy_worker가 미리 만든 summary_text만 읽습니다. 후보 재계산 없음.",
        f"- rows {len(rows)} / updated {now_text(nowv)} / fresh",
        f"- 현재 단계: S1 {counts.get('S1',0)} / S2 {counts.get('S2',0)} / S3 {counts.get('S3',0)} / 제외 {counts.get('제외', counts.get('X',0))}",
        f"- S1 근접후보: {s1_near} / S2 재확인 TOP: {s2_recheck_top}",
        f"- 전략/발견 TOP: {strategy_top}",
        f"- 위험 TOP: {risk_top}",
        "",
        "[상위 후보 3개 · 구조선/계획]",
    ]
    if not top:
        lines.append("- 표시 후보 없음")
    for idx, r in enumerate(top, 1):
        t = ticker_norm(r.get("ticker") or r.get("symbol") or r.get("market")) or "-"
        st = _v510_stage(r)
        strat = str(r.get("strategy_label") or r.get("strategy") or r.get("strategy_key") or "-")
        price = _v510_num(r.get("current_price"), r.get("entry_price"), r.get("price"), default=0.0)
        react = _v558_metric(r, "price_reaction_pct")
        buy = _v558_metric(r, "buy_ratio")
        sustain = _v558_metric(r, "buy_sustain_1m")
        spread = _v558_metric(r, "spread_pct")
        levels = r.get("structure_levels") if isinstance(r.get("structure_levels"), dict) else {}
        plan = r.get("entry_plan") if isinstance(r.get("entry_plan"), dict) else {}
        rr = r.get("risk_reward") if isinstance(r.get("risk_reward"), dict) else {}
        timing = r.get("entry_timing_spine") if isinstance(r.get("entry_timing_spine"), dict) else {}
        late = "-"
        if r.get("late_chase_flag") or timing.get("late_chase_flag") or levels.get("late_chase_flag"):
            basis = levels.get("late_chase_basis") if isinstance(levels.get("late_chase_basis"), dict) else {}
            br = _v510_num(basis.get("reaction"), react, default=0.0)
            bs = _v510_num(basis.get("spread"), spread, default=0.0)
            late = f"⚠️ 주의({br:+.2f}%/{bs:.2f}%)"
        first_sec = timing.get("first_to_now_delay_sec", timing.get("first_to_current_delay_sec"))
        s2_sec = timing.get("s2_to_now_delay_sec", timing.get("s2_to_current_delay_sec"))
        first_ret = _v510_num(timing.get("first_to_now_return_pct"), timing.get("first_to_current_return_pct"), default=0.0)
        s2_ret = _v510_num(timing.get("s2_to_now_return_pct"), timing.get("s2_to_current_return_pct"), default=0.0)
        down = _v510_num(rr.get("expected_downside_pct"), levels.get("expected_downside_pct"), default=0.0)
        if down > 0: down = -abs(down)
        up = _v510_num(rr.get("expected_upside_pct"), levels.get("expected_upside_pct"), default=0.0)
        ratio = _v510_num(rr.get("rr_ratio"), levels.get("rr_ratio"), default=0.0)
        lines.extend([
            f"{idx}) {t} · {st} · {strat}",
            f"   수치: 반응 {react:+.2f}% / 매수 {buy:.2f} / 1분 {sustain:.2f} / 스프 {spread:.2f}% / 가격 {_v558_price(price)}",
            f"   구조: {_v558_label_list(r.get('entry_structure_tags') or r.get('structure_tags') or r.get('matched_strategy_labels'), 6)}",
            f"   구조선: 지지 {_v558_price(levels.get('support_price'))} / 방아쇠 {_v558_price(levels.get('trigger_price'))} / 무효 {_v558_price(levels.get('invalid_price'))} / 목표 {_v558_price(levels.get('target1_price'))}→{_v558_price(levels.get('target2_price'))}",
            f"   진입계획: {plan.get('trigger_reason') or levels.get('trigger_reason') or plan.get('plan_type') or '-'}",
            f"   손익비: 기대 {up:+.2f}% / 무효손실 {down:+.2f}% / RR {ratio:.2f}",
            f"   타이밍: 최초→현재 {first_sec if first_sec is not None else '-'}s/{first_ret:+.2f}% · S2→현재 {s2_sec if s2_sec is not None else '-'}s/{s2_ret:+.2f}% · 늦은추격 {late}",
            f"   재확인: {_v558_label_list(r.get('recheck_reasons') or r.get('s2_recheck_reasons') or r.get('missing_info'), 5)}",
            f"   위험: {_v558_label_list(r.get('execution_risk_tags') or r.get('risk_tags') or r.get('structure_risk_tags'), 5)}",
            "",
        ])
    lines.extend(["[안내]", "- 상세 후보 전체는 /candidate_reason_full에서 확인. 기본판은 worker-rendered cache만 표시합니다."])
    batch_state = {
        "schema": "candidate_reason_batch_state_v558",
        "rows": len(rows),
        "stage_counts": dict(counts or {}),
        "s1_near_count": s1_near,
        "s2_recheck_top": s2_recheck_top,
        "strategy_top": strategy_top,
        "risk_top": risk_top,
        "updated_ts": nowv,
        "updated_text": now_text(nowv),
    }
    return {"schema": "candidate_reason_summary_text_v558", "summary_text": "\n".join(lines), "batch_state": batch_state}

# Keep v557 callsite name, but the producer is v558.
_v557_build_candidate_reason_summary = _v558_build_candidate_reason_summary


# =============================================================================
# strategy_worker v0.123 / v560: compact worker-rendered summary
# - 기본 명령 속도 개선을 위해 summary_text를 더 짧게 생성한다.
# - count는 row별 중복 태그를 줄여 과대집계 착시를 줄인다.
# - 조건/S1/S2/S3/청산 기준 변경 없음.
# =============================================================================
def _v559_counter_top(rows: List[Dict[str, Any]], keys: Tuple[str, ...], limit: int = 5) -> str:
    c: Counter = Counter()
    for r in rows:
        seen: set[str] = set()
        for k in keys:
            vals = r.get(k)
            if isinstance(vals, list):
                for v in vals:
                    txt = str(v or '').strip()
                    if txt:
                        seen.add(txt)
            elif vals not in (None, '', [], {}):
                seen.add(str(vals).strip())
        for txt in seen:
            c[txt] += 1
    return ' / '.join(f'{k} {v}' for k, v in c.most_common(limit)) if c else '-'


def _v559_build_candidate_reason_summary(display_rows: List[Dict[str, Any]], counts: Dict[str, int], reason_top: Any, nowv: float) -> Dict[str, Any]:
    rows = [r for r in display_rows if isinstance(r, dict)]
    s2_rows = [r for r in rows if _v510_stage(r) == 'S2']
    s1_near = sum(1 for r in rows if bool(r.get('s1_near_miss')) or str(r.get('s1_distance_label') or '').startswith('S1'))
    strategy_top = _v559_counter_top(rows, ('matched_strategy_labels','strategy_tags','structure_tags','strategy','strategy_key'), 5)
    risk_top = _v559_counter_top(rows, ('risk_tags','execution_risk_tags','structure_risk_tags'), 5)
    s2_recheck_top = _v559_counter_top(s2_rows, ('recheck_reasons','s2_recheck_reasons','missing_info','block_reasons'), 5)
    top = rows[:2]
    lines = [
        '🧭 후보판정 이유 /candidate_reason · v560 worker-rendered cache',
        '- 기준: strategy_worker가 미리 만든 summary_text만 읽습니다. 후보 재계산 없음.',
        f'- rows {len(rows)} / updated {now_text(nowv)} / fresh',
        f'- 현재 단계: S1 {counts.get("S1",0)} / S2 {counts.get("S2",0)} / S3 {counts.get("S3",0)} / 제외 {counts.get("제외", counts.get("X",0))}',
        f'- S1 근접후보: {s1_near} / S2 재확인 TOP: {s2_recheck_top}',
        f'- 전략/발견 TOP: {strategy_top}',
        f'- 위험 TOP: {risk_top}',
        '',
        '[상위 후보 2개 · 구조선/계획]',
    ]
    if not top:
        lines.append('- 표시 후보 없음')
    for idx, r in enumerate(top, 1):
        t = ticker_norm(r.get('ticker') or r.get('symbol') or r.get('market')) or '-'
        st = _v510_stage(r)
        strat = str(r.get('strategy_label') or r.get('strategy') or r.get('strategy_key') or '-')
        price = _v510_num(r.get('current_price'), r.get('entry_price'), r.get('price'), default=0.0)
        react = _v558_metric(r, 'price_reaction_pct')
        buy = _v558_metric(r, 'buy_ratio')
        sustain = _v558_metric(r, 'buy_sustain_1m')
        spread = _v558_metric(r, 'spread_pct')
        levels = r.get('structure_levels') if isinstance(r.get('structure_levels'), dict) else {}
        plan = r.get('entry_plan') if isinstance(r.get('entry_plan'), dict) else {}
        rr = r.get('risk_reward') if isinstance(r.get('risk_reward'), dict) else {}
        timing = r.get('entry_timing_spine') if isinstance(r.get('entry_timing_spine'), dict) else {}
        first_sec = timing.get('first_to_now_delay_sec', timing.get('first_to_current_delay_sec'))
        s2_sec = timing.get('s2_to_now_delay_sec', timing.get('s2_to_current_delay_sec'))
        first_ret = _v510_num(timing.get('first_to_now_return_pct'), timing.get('first_to_current_return_pct'), default=0.0)
        s2_ret = _v510_num(timing.get('s2_to_now_return_pct'), timing.get('s2_to_current_return_pct'), default=0.0)
        down = _v510_num(rr.get('expected_downside_pct'), levels.get('expected_downside_pct'), default=0.0)
        if down > 0: down = -abs(down)
        up = _v510_num(rr.get('expected_upside_pct'), levels.get('expected_upside_pct'), default=0.0)
        ratio = _v510_num(rr.get('rr_ratio'), levels.get('rr_ratio'), default=0.0)
        late = '-'
        if r.get('late_chase_flag') or timing.get('late_chase_flag') or levels.get('late_chase_flag'):
            basis = levels.get('late_chase_basis') if isinstance(levels.get('late_chase_basis'), dict) else {}
            br = _v510_num(basis.get('reaction'), react, default=0.0)
            bs = _v510_num(basis.get('spread'), spread, default=0.0)
            late = f'⚠️ {br:+.2f}%/스프 {bs:.2f}%'
        lines.extend([
            f'{idx}) {t} · {st} · {strat}',
            f'   수치: 반응 {react:+.2f}% / 매수 {buy:.2f} / 1분 {sustain:.2f} / 스프 {spread:.2f}% / 가격 {_v558_price(price)}',
            f'   구조선: 지지 {_v558_price(levels.get("support_price"))} / 방아쇠 {_v558_price(levels.get("trigger_price"))} / 무효 {_v558_price(levels.get("invalid_price"))} / 목표 {_v558_price(levels.get("target1_price"))}→{_v558_price(levels.get("target2_price"))}',
            f'   계획: {plan.get("trigger_reason") or levels.get("trigger_reason") or plan.get("plan_type") or "-"} / RR {ratio:.2f} / 기대 {up:+.2f}% / 무효 {down:+.2f}%',
            f'   타이밍: 최초 {first_sec if first_sec is not None else "-"}s/{first_ret:+.2f}% · S2 {s2_sec if s2_sec is not None else "-"}s/{s2_ret:+.2f}% · 늦은추격 {late}',
            f'   재확인: {_v558_label_list(r.get("recheck_reasons") or r.get("s2_recheck_reasons") or r.get("missing_info"), 4)}',
            f'   위험: {_v558_label_list(r.get("execution_risk_tags") or r.get("risk_tags") or r.get("structure_risk_tags"), 4)}',
            '',
        ])
    lines.extend(['[안내]', '- 상세 후보 전체는 /candidate_reason_full에서 확인. 기본판은 worker-rendered cache만 표시합니다.'])
    batch_state = {
        'schema': 'candidate_reason_batch_state_v560',
        'rows': len(rows),
        'stage_counts': dict(counts or {}),
        's1_near_count': s1_near,
        's2_recheck_top': s2_recheck_top,
        'strategy_top': strategy_top,
        'risk_top': risk_top,
        'updated_ts': nowv,
        'updated_text': now_text(nowv),
    }
    return {'schema': 'candidate_reason_summary_text_v560', 'summary_text': '\n'.join(lines), 'batch_state': batch_state}


# =============================================================================
# strategy_worker v0.124 / v563: S2 -> S1 promotion lifecycle trace
# - 조건/S1·S2·S3/청산 수치 변경 없음.
# - S2 후보가 왜 S1으로 못 올라갔는지 canonical row/cache에 봉인한다.
# =============================================================================
S2_PROMOTION_TRACE = BASE_DIR / "clean_s2_promotion_lifecycle_trace.json"

def _v563_has_text(row: Dict[str, Any], needles: Tuple[str, ...]) -> bool:
    vals: List[str] = []
    for k in ("recheck_reasons", "s2_recheck_reasons", "missing_info", "block_reasons", "risk_tags", "execution_risk_tags", "structure_risk_tags", "s1_missing_names", "s_stage_reasons", "reasons"):
        v = row.get(k)
        if isinstance(v, list):
            vals.extend(str(x or "") for x in v)
        elif v not in (None, "", [], {}):
            vals.append(str(v))
    hay = " ".join(vals)
    return any(n in hay for n in needles)

def _v563_bool_ok(row: Dict[str, Any], metric: float, bad_words: Tuple[str, ...], min_value: Optional[float] = None, max_value: Optional[float] = None) -> bool:
    if _v563_has_text(row, bad_words):
        return False
    if min_value is not None and metric < min_value:
        return False
    if max_value is not None and metric > max_value:
        return False
    return True

def _v563_s2_promotion_record(row: Dict[str, Any], nowv: float) -> Dict[str, Any]:
    st = _v510_stage(row)
    levels = row.get("structure_levels") if isinstance(row.get("structure_levels"), dict) else {}
    timing = row.get("entry_timing_spine") if isinstance(row.get("entry_timing_spine"), dict) else {}
    plan = row.get("entry_plan") if isinstance(row.get("entry_plan"), dict) else {}
    t = ticker_norm(row.get("ticker") or row.get("symbol") or row.get("market"))
    price = _v510_num(row.get("current_price"), row.get("entry_price"), row.get("price"), default=0.0)
    trigger = _v510_num(levels.get("trigger_price"), plan.get("trigger_price"), default=0.0)
    trigger_gap = round(_v554_pct_between(trigger, price), 3) if price and trigger else None
    trigger_reached = bool(st == "S1" or (price and trigger and price >= trigger * 0.999) or str(levels.get("status") or "") == "triggered")
    react = _v510_num(row.get("price_reaction_pct"), default=0.0)
    buy = _v510_num(row.get("buy_ratio"), default=0.0)
    sustain = _v510_num(row.get("buy_sustain_1m"), row.get("buy_ratio"), default=0.0)
    spread = _v510_num(row.get("spread_pct"), default=0.0)
    slip = _v510_num(row.get("slippage_pct"), row.get("expected_slippage_pct"), row.get("spread_pct"), default=0.0)
    freshness_age = _v510_num(row.get("micro_age_sec"), row.get("orderflow_age_sec"), row.get("price_reaction_age_sec"), row.get("cache_age_sec"), default=0.0)
    freshness_ok = not _v563_has_text(row, ("신선도", "정보부족", "정보 부족", "갱신 대기", "stale"))
    price_reaction_ok = _v563_bool_ok(row, react, ("가격반응", "반응 약함"), min_value=0.35)
    buy_persist_ok = _v563_bool_ok(row, sustain, ("1분", "지속 부족"), min_value=0.60)
    buy_ratio_ok = _v563_bool_ok(row, buy, ("매수체결", "체결약함"), min_value=0.60)
    spread_ok = _v563_bool_ok(row, spread, ("스프레드",), max_value=0.50)
    slippage_ok = _v563_bool_ok(row, slip, ("미끄러짐", "슬리피지"), max_value=0.50)
    failed: List[str] = []
    if not trigger_reached:
        failed.append("방아쇠 미도달")
    if not freshness_ok:
        failed.append("정보/신선도 지연")
    if not price_reaction_ok:
        failed.append("가격반응 부족")
    if not buy_persist_ok:
        failed.append("1분 매수지속 부족")
    if not buy_ratio_ok:
        failed.append("매수체결 부족")
    if not spread_ok:
        failed.append("스프레드 회복 대기")
    if not slippage_ok:
        failed.append("미끄러짐 회복 대기")
    if row.get("late_chase_flag"):
        failed.append("늦은추격 위험")
    if st == "S1":
        promote_state = "promoted_s1"
    elif not trigger_reached:
        promote_state = "waiting_trigger"
    elif not freshness_ok:
        promote_state = "blocked_by_freshness_delay"
    elif not spread_ok or not slippage_ok:
        promote_state = "blocked_by_execution_risk"
    elif failed:
        promote_state = "blocked_by_confirm_signal"
    else:
        promote_state = "near_s1_needs_final_gate"
    would = []
    if not trigger_reached: would.append("방아쇠 가격 도달")
    if not freshness_ok: would.append("신선정보 갱신")
    if not price_reaction_ok: would.append("가격반응 회복")
    if not buy_persist_ok: would.append("1분 매수지속 회복")
    if not buy_ratio_ok: would.append("매수체결 회복")
    if not spread_ok: would.append("스프레드 회복")
    if not slippage_ok: would.append("미끄러짐 회복")
    rec = {
        "schema": "s2_promotion_lifecycle_row_v563",
        "ticker": t,
        "strategy": row.get("strategy_label") or row.get("strategy") or row.get("strategy_key"),
        "strategy_key": row.get("strategy_key") or row.get("paper_strategy_key"),
        "stage": st,
        "s2_seen_ts": timing.get("s2_seen_ts"),
        "s2_age_sec": timing.get("s2_to_now_delay_sec", timing.get("s2_to_current_delay_sec")),
        "first_seen_ts": timing.get("first_seen_ts"),
        "first_age_sec": timing.get("first_to_now_delay_sec", timing.get("first_to_current_delay_sec")),
        "current_price": price,
        "trigger_price": trigger,
        "trigger_reached": trigger_reached,
        "trigger_gap_pct": trigger_gap,
        "freshness_ok": freshness_ok,
        "freshness_age_sec": freshness_age,
        "spread_ok": spread_ok,
        "spread_pct": spread,
        "slippage_ok": slippage_ok,
        "slippage_pct": slip,
        "price_reaction_ok": price_reaction_ok,
        "price_reaction_pct": react,
        "buy_persist_ok": buy_persist_ok,
        "buy_sustain_1m": sustain,
        "buy_ratio_ok": buy_ratio_ok,
        "buy_ratio": buy,
        "promote_state": promote_state,
        "promote_block_reason": failed[:8],
        "failed_confirm": failed[:8],
        "would_be_s1_if": would[:8],
        "updated_ts": nowv,
        "updated_text": now_text(nowv),
    }
    return rec

def _v563_attach_s2_promotion_lifecycle(rows: List[Dict[str, Any]], nowv: float) -> Tuple[List[Dict[str, Any]], Dict[str, Any]]:
    out: List[Dict[str, Any]] = []
    records: List[Dict[str, Any]] = []
    state_counter: Counter = Counter()
    block_counter: Counter = Counter()
    for r in rows:
        rr = dict(r)
        st = _v510_stage(rr)
        rec = _v563_s2_promotion_record(rr, nowv)
        if st in ("S1", "S2"):
            records.append(rec)
            state_counter[rec.get("promote_state") or "-"] += 1
            for x in rec.get("promote_block_reason") or []:
                block_counter[str(x)] += 1
        rr["s2_promotion_lifecycle"] = rec
        rr["promotion_trace"] = rec
        rr["trigger_reached"] = rec.get("trigger_reached")
        rr["trigger_gap_pct"] = rec.get("trigger_gap_pct")
        rr["promote_state"] = rec.get("promote_state")
        rr["promote_block_reason"] = rec.get("promote_block_reason")
        rr["would_be_s1_if"] = rec.get("would_be_s1_if")
        ctx = rr.get("entry_context") if isinstance(rr.get("entry_context"), dict) else {}
        ctx = dict(ctx)
        ctx["s2_promotion_lifecycle"] = rec
        rr["entry_context"] = ctx
        out.append(rr)
    trace = {
        "schema": "s2_promotion_lifecycle_trace_v563",
        "version": VERSION,
        "updated_ts": nowv,
        "updated_text": now_text(nowv),
        "candidate_count": len(records),
        "state_counts": dict(state_counter),
        "block_top": [{"reason": k, "count": v} for k, v in block_counter.most_common(8)],
        "rows": records[:160],
        "policy": "조건/S등급/청산 변경 없이 S2->S1 승격 실패 원인만 기록",
    }
    save_json(S2_PROMOTION_TRACE, trace)
    return out, trace

def _v563_counter_text(counter_rows: List[Dict[str, Any]], key: str, limit: int = 5) -> str:
    c: Counter = Counter()
    for r in counter_rows:
        v = r.get(key)
        if isinstance(v, list):
            for x in v:
                if x: c[str(x)] += 1
        elif v:
            c[str(v)] += 1
    return " / ".join(f"{k} {v}" for k, v in c.most_common(limit)) if c else "-"

def _v563_build_candidate_reason_summary(display_rows: List[Dict[str, Any]], counts: Dict[str, int], reason_top: Any, nowv: float) -> Dict[str, Any]:
    rows = [r for r in display_rows if isinstance(r, dict)]
    s2_rows = [r for r in rows if _v510_stage(r) == 'S2']
    s1_near = sum(1 for r in rows if bool(r.get('s1_near_miss')) or str(r.get('s1_distance_label') or '').startswith('S1'))
    strategy_top = _v559_counter_top(rows, ('matched_strategy_labels','strategy_tags','structure_tags','strategy','strategy_key'), 5)
    risk_top = _v559_counter_top(rows, ('risk_tags','execution_risk_tags','structure_risk_tags'), 5)
    promo_state_top = _v563_counter_text([r.get('s2_promotion_lifecycle') or {} for r in rows], 'promote_state', 5)
    promo_block_top = _v559_counter_top(s2_rows, ('promote_block_reason','would_be_s1_if'), 5)
    top = rows[:2]
    lines = [
        '🧭 후보판정 이유 /candidate_reason · v563 S2 승격 생애주기',
        '- 기준: strategy_worker가 미리 만든 summary_text만 읽습니다. 후보 재계산 없음.',
        f'- rows {len(rows)} / updated {now_text(nowv)} / fresh',
        f'- 현재 단계: S1 {counts.get("S1",0)} / S2 {counts.get("S2",0)} / S3 {counts.get("S3",0)} / 제외 {counts.get("제외", counts.get("X",0))}',
        f'- S1 근접후보: {s1_near} / 승격상태 TOP: {promo_state_top}',
        f'- S2 막힘 TOP: {promo_block_top}',
        f'- 전략/발견 TOP: {strategy_top}',
        f'- 위험 TOP: {risk_top}',
        '',
        '[상위 후보 2개 · 구조선/계획/승격추적]',
    ]
    if not top:
        lines.append('- 표시 후보 없음')
    for idx, r in enumerate(top, 1):
        t = ticker_norm(r.get('ticker') or r.get('symbol') or r.get('market')) or '-'
        st = _v510_stage(r)
        strat = str(r.get('strategy_label') or r.get('strategy') or r.get('strategy_key') or '-')
        price = _v510_num(r.get('current_price'), r.get('entry_price'), r.get('price'), default=0.0)
        react = _v558_metric(r, 'price_reaction_pct')
        buy = _v558_metric(r, 'buy_ratio')
        sustain = _v558_metric(r, 'buy_sustain_1m')
        spread = _v558_metric(r, 'spread_pct')
        levels = r.get('structure_levels') if isinstance(r.get('structure_levels'), dict) else {}
        promo = r.get('s2_promotion_lifecycle') if isinstance(r.get('s2_promotion_lifecycle'), dict) else {}
        lines.extend([
            f'{idx}) {t} · {st} · {strat}',
            f'   수치: 반응 {react:+.2f}% / 매수 {buy:.2f} / 1분 {sustain:.2f} / 스프 {spread:.2f}% / 가격 {_v558_price(price)}',
            f'   구조선: 방아쇠 {_v558_price(levels.get("trigger_price"))} / 무효 {_v558_price(levels.get("invalid_price"))} / 목표 {_v558_price(levels.get("target1_price"))}',
            f'   승격추적: {promo.get("promote_state") or "-"} / 방아쇠 {"도달" if promo.get("trigger_reached") else "미도달"} / gap {promo.get("trigger_gap_pct") if promo.get("trigger_gap_pct") is not None else "-"}%',
            f'   막힘: {_v558_label_list(promo.get("promote_block_reason") or r.get("promote_block_reason"), 5)}',
            f'   S1조건화: {_v558_label_list(promo.get("would_be_s1_if") or r.get("would_be_s1_if"), 5)}',
            f'   위험: {_v558_label_list(r.get("execution_risk_tags") or r.get("risk_tags") or r.get("structure_risk_tags"), 4)}',
            '',
        ])
    lines.extend(['[안내]', '- 조건/S등급/청산은 변경하지 않고, S2가 왜 S1이 못 됐는지만 기록합니다.'])
    batch_state = {
        'schema': 'candidate_reason_batch_state_v563_s2_promotion',
        'rows': len(rows),
        'stage_counts': dict(counts or {}),
        's1_near_count': s1_near,
        'promotion_state_top': promo_state_top,
        'promotion_block_top': promo_block_top,
        'strategy_top': strategy_top,
        'risk_top': risk_top,
        'updated_ts': nowv,
        'updated_text': now_text(nowv),
    }
    return {'schema': 'candidate_reason_summary_text_v563_s2_promotion', 'summary_text': '\n'.join(lines), 'batch_state': batch_state}

# v563 최종 summary producer: v560 compact 경량화를 유지하면서 승격 생애주기를 표시한다.
_v557_build_candidate_reason_summary = _v563_build_candidate_reason_summary



# =============================================================================
# strategy_worker v0.125 / v573: freshness numeric proof + refined late-chase gate
# - 위치 원칙: S1/S2 승격 판단은 strategy_worker가 주인이다.
# - 조건 수치/청산/자동매수/BUY_READY 변경 없음.
# - 신선도 문구만 있고 숫자 근거가 없는 후보는 S1 직행 금지 -> S2 재확인.
# - 늦은추격 라벨은 좋은 후보까지 죽이지 않도록 hard/broad로 분리한다.
# =============================================================================
_V573_AGE_KEYS = (
    "micro_age_sec", "orderflow_age_sec", "trade_age_sec", "quote_age_sec", "ws_age_sec",
    "price_reaction_age_sec", "feature_age_sec", "hot_signal_age_sec", "scanner_hot_age_sec", "cache_age_sec",
)

def _v573_text_blob(row: Dict[str, Any]) -> str:
    vals: List[str] = []
    for k in ("stale_reasons", "freshness_flags", "recheck_reasons", "s2_recheck_reasons", "missing_info", "block_reasons", "risk_tags", "execution_risk_tags", "s1_missing_conditions"):
        v = row.get(k)
        if isinstance(v, list):
            vals.extend(str(x or "") for x in v)
        elif v not in (None, "", [], {}):
            vals.append(str(v))
    dec = row.get("canonical_entry_decision") if isinstance(row.get("canonical_entry_decision"), dict) else {}
    for k in ("stale_reasons", "display_reasons", "s1_recheck_reasons", "s2_recheck_reasons", "missing_conditions"):
        v = dec.get(k)
        if isinstance(v, list):
            vals.extend(str(x or "") for x in v)
    return " ".join(vals)

def _v573_age_value(row: Dict[str, Any], key: str) -> Optional[float]:
    v = row.get(key)
    if v is None and isinstance(row.get("entry_context"), dict):
        v = row.get("entry_context", {}).get(key)
    try:
        if v in (None, "", [], {}):
            return None
        f = float(str(v).replace(",", "").replace("%", ""))
        if f < 0:
            return None
        return f
    except Exception:
        return None

def _v573_freshness_numeric_profile(row: Dict[str, Any]) -> Dict[str, Any]:
    blob = _v573_text_blob(row)
    has_fresh_text = any(w in blob for w in ("신선", "정보", "fresh", "stale", "갱신 대기", "오래됨"))
    ages: Dict[str, float] = {}
    for k in _V573_AGE_KEYS:
        v = _v573_age_value(row, k)
        if v is not None:
            ages[k] = round(v, 3)
    # 핵심값 기준. 없는 값은 통과가 아니라 숫자근거 부족으로 둔다.
    core_keys = ("micro_age_sec", "orderflow_age_sec", "trade_age_sec", "quote_age_sec", "ws_age_sec", "price_reaction_age_sec", "feature_age_sec")
    core_ages = {k: ages[k] for k in core_keys if k in ages}
    numeric_present = bool(core_ages)
    worst_core_age = max(core_ages.values()) if core_ages else None
    numeric_stale = bool(worst_core_age is not None and worst_core_age > 25.0)
    text_without_numeric = bool(has_fresh_text and not numeric_present)
    numeric_ok = bool(numeric_present and not numeric_stale and not text_without_numeric)
    if text_without_numeric:
        state = "text_only_no_numeric"
    elif numeric_stale:
        state = "numeric_age_stale"
    elif numeric_ok:
        state = "numeric_fresh"
    elif has_fresh_text:
        state = "freshness_text_unclear"
    else:
        state = "no_freshness_warning"
    return {
        "schema": "freshness_numeric_profile_v573",
        "state": state,
        "has_freshness_text": has_fresh_text,
        "numeric_present": numeric_present,
        "text_without_numeric": text_without_numeric,
        "numeric_stale": numeric_stale,
        "numeric_ok": numeric_ok,
        "worst_core_age_sec": worst_core_age,
        "ages": ages,
        "policy": "신선도 문구만 있고 숫자근거 없으면 S1 직행 금지/S2 재확인",
    }

def _v573_refined_late_chase_profile(row: Dict[str, Any]) -> Dict[str, Any]:
    levels = row.get("structure_levels") if isinstance(row.get("structure_levels"), dict) else {}
    timing = row.get("entry_timing_spine") if isinstance(row.get("entry_timing_spine"), dict) else {}
    react = _v510_num(row.get("price_reaction_pct"), default=0.0)
    spread = _v510_num(row.get("spread_pct"), default=0.0)
    slip = _v510_num(row.get("slippage_pct"), row.get("expected_slippage_pct"), default=spread)
    buy = _v510_num(row.get("buy_ratio"), default=0.0)
    sustain = _v510_num(row.get("buy_sustain_1m"), row.get("buy_ratio"), default=0.0)
    ch1 = _v510_num(row.get("change_1m_pct"), row.get("change_1m"), default=0.0)
    ch3 = _v510_num(row.get("change_3m_pct"), row.get("change_3m"), default=0.0)
    first_ret = _v510_num(timing.get("first_to_now_return_pct"), timing.get("first_to_current_return_pct"), default=0.0)
    s2_ret = _v510_num(timing.get("s2_to_now_return_pct"), timing.get("s2_to_current_return_pct"), default=0.0)
    base_late = bool(row.get("late_chase_flag") or levels.get("late_chase_flag") or timing.get("late_chase_flag"))
    fast_move = bool(first_ret >= 1.20 or s2_ret >= 0.80 or ch1 >= 1.80 or ch3 >= 3.20 or react >= 1.80)
    weak_confirm = bool(buy < 0.70 or sustain < 0.70)
    exec_risk = bool(spread > 0.35 or slip > 0.35)
    wick_or_sell = _v563_has_text(row, ("윗꼬리", "매도압력", "되돌림위험", "고점권"))
    freshness = _v573_freshness_numeric_profile(row)
    freshness_risk = bool(freshness.get("text_without_numeric") or freshness.get("numeric_stale"))
    hard_late = bool(base_late and fast_move and (weak_confirm or exec_risk or wick_or_sell or freshness_risk))
    broad_only = bool(base_late and not hard_late)
    if hard_late:
        state = "hard_late_chase"
    elif broad_only:
        state = "broad_late_label_only"
    else:
        state = "not_late_chase"
    reasons: List[str] = []
    if fast_move: reasons.append("가격이 이미 많이 움직임")
    if freshness_risk: reasons.append("신선도 숫자근거 부족/지연")
    if weak_confirm: reasons.append("확인신호 약함")
    if exec_risk: reasons.append("스프레드/미끄러짐 부담")
    if wick_or_sell: reasons.append("되돌림/매도압력 위험")
    return {
        "schema": "refined_late_chase_profile_v573",
        "state": state,
        "base_late_chase_flag": base_late,
        "hard_late_chase": hard_late,
        "broad_late_label_only": broad_only,
        "fast_move": fast_move,
        "weak_confirm": weak_confirm,
        "execution_risk": exec_risk,
        "freshness_risk": freshness_risk,
        "basis": {"first_ret": round(first_ret,3), "s2_ret": round(s2_ret,3), "chg1": round(ch1,3), "chg3": round(ch3,3), "reaction": round(react,3), "spread": round(spread,3), "slippage": round(slip,3), "buy": round(buy,3), "sustain": round(sustain,3)},
        "reasons": reasons[:6],
    }

_v573_base_build_structure_levels = _v554_build_structure_levels

def _v554_build_structure_levels(row: Dict[str, Any]) -> Dict[str, Any]:  # type: ignore[override]
    levels = _v573_base_build_structure_levels(row)
    if not isinstance(levels, dict):
        return levels
    # base late flag는 남기되, S1 판단용 late flag는 refined hard late만 사용한다.
    temp = dict(row)
    temp["structure_levels"] = levels
    refined = _v573_refined_late_chase_profile(temp)
    base_flag = bool(levels.get("late_chase_flag"))
    levels["base_late_chase_flag"] = base_flag
    levels["late_chase_flag"] = bool(refined.get("hard_late_chase"))
    levels["refined_late_chase_profile"] = refined
    levels["late_chase_reason"] = " / ".join(refined.get("reasons") or []) if refined.get("hard_late_chase") else ("넓은 늦은추격 라벨만 있음" if refined.get("broad_late_label_only") else "")
    levels["schema"] = "structure_levels_v573_refined_late_chase"
    return levels

_v573_base_build_entry_decision = _v532_build_canonical_entry_decision

def _v532_build_canonical_entry_decision(row: Dict[str, Any]) -> Dict[str, Any]:  # type: ignore[override]
    dec = _v573_base_build_entry_decision(row)
    if not isinstance(dec, dict):
        return dec
    fresh = _v573_freshness_numeric_profile(row)
    late = _v573_refined_late_chase_profile(row)
    guard: List[str] = []
    if fresh.get("text_without_numeric"):
        guard.append("재확인: 신선도 숫자근거 확인 대기")
    # 숫자로도 오래된 신선도 + 진짜 늦은추격 조합은 S1 직행 금지. 단순 늦은추격 라벨만으로는 막지 않는다.
    if fresh.get("numeric_stale") and late.get("hard_late_chase"):
        guard.append("재확인: 신선도지연+진짜늦은추격")
    if guard:
        prev_guard = list(dec.get("s1_recheck_guard_reasons") or [])
        prev_recheck = list(dec.get("s1_recheck_reasons") or dec.get("s2_recheck_reasons") or [])
        merged = _v510_uniq(prev_guard + guard, 8)
        rechecks = _v510_uniq(prev_recheck + guard, 8)
        missing = list(dec.get("missing_conditions") or []) + guard
        checks = list(dec.get("checks") or [])
        for g in guard:
            checks.append({"name": "신선도근거" if "신선도" in g else "늦은추격정교화", "ok": False, "value": fresh.get("state"), "need": "numeric proof before S1", "reason": g, "weight": 2})
        dec.update({
            "schema": "canonical_entry_decision_v573_fresh_late_refined",
            "gate_pass": False,
            "s1_allowed": False,
            "s1_recheck_guard": True,
            "s1_recheck_guard_reasons": merged,
            "s1_recheck_reasons": rechecks,
            "s2_recheck_reasons": rechecks,
            "s2_recheck": True,
            "action": "recheck",
            "entry_profile": "watch",
            "exit_profile": "watch_exit",
            "profile_family": "watch",
            "missing_conditions": missing,
            "display_reasons": list(dec.get("display_reasons") or []) + guard,
            "checks": checks,
            "block_count": int(dec.get("block_count") or 0) + len(guard),
            "block_score": int(dec.get("block_score") or 0) + 2 * len(guard),
            "s1_distance": int(dec.get("s1_distance") or 0) + 2 * len(guard),
            "s1_near_miss": True,
            "s1_near_miss_level": "near",
        })
    dec["freshness_numeric_profile"] = fresh
    dec["refined_late_chase_profile"] = late
    dec["v573_policy"] = "신선도 숫자근거 없음은 S1 직행 금지, 늦은추격은 hard/broad로 분리"
    return dec

_v573_base_apply_entry_decision = _v532_apply_canonical_entry_decision

def _v532_apply_canonical_entry_decision(row: Dict[str, Any]) -> Dict[str, Any]:  # type: ignore[override]
    out = _v573_base_apply_entry_decision(row)
    if not isinstance(out, dict):
        return out
    dec = out.get("canonical_entry_decision") if isinstance(out.get("canonical_entry_decision"), dict) else {}
    fresh = dec.get("freshness_numeric_profile") if isinstance(dec.get("freshness_numeric_profile"), dict) else _v573_freshness_numeric_profile(out)
    late = dec.get("refined_late_chase_profile") if isinstance(dec.get("refined_late_chase_profile"), dict) else _v573_refined_late_chase_profile(out)
    out["freshness_numeric_profile"] = fresh
    out["freshness_numeric_state"] = fresh.get("state")
    out["freshness_text_without_numeric"] = bool(fresh.get("text_without_numeric"))
    out["freshness_numeric_stale"] = bool(fresh.get("numeric_stale"))
    out["refined_late_chase_profile"] = late
    out["late_chase_refined_state"] = late.get("state")
    out["hard_late_chase_flag"] = bool(late.get("hard_late_chase"))
    out["broad_late_label_only"] = bool(late.get("broad_late_label_only"))
    ctx = out.get("entry_context") if isinstance(out.get("entry_context"), dict) else {}
    ctx = dict(ctx)
    ctx["freshness_numeric_profile"] = fresh
    ctx["refined_late_chase_profile"] = late
    out["entry_context"] = ctx
    return out

_v573_base_s2_promotion_record = _v563_s2_promotion_record

def _v563_s2_promotion_record(row: Dict[str, Any], nowv: float) -> Dict[str, Any]:  # type: ignore[override]
    rec = _v573_base_s2_promotion_record(row, nowv)
    fresh = row.get("freshness_numeric_profile") if isinstance(row.get("freshness_numeric_profile"), dict) else _v573_freshness_numeric_profile(row)
    late = row.get("refined_late_chase_profile") if isinstance(row.get("refined_late_chase_profile"), dict) else _v573_refined_late_chase_profile(row)
    failed = list(rec.get("promote_block_reason") or [])
    would = list(rec.get("would_be_s1_if") or [])
    if fresh.get("text_without_numeric"):
        failed.append("신선도 숫자근거 없음")
        would.append("신선도 숫자근거 확보")
    if fresh.get("numeric_stale") and late.get("hard_late_chase"):
        failed.append("신선도지연+진짜늦은추격")
        would.append("긴급 신선정보 갱신 후 재판정")
    failed = _v510_uniq(failed, 10)
    would = _v510_uniq(would, 10)
    rec.update({
        "schema": "s2_promotion_lifecycle_row_v573_fresh_late_refined",
        "freshness_numeric_profile": fresh,
        "refined_late_chase_profile": late,
        "freshness_numeric_state": fresh.get("state"),
        "late_chase_refined_state": late.get("state"),
        "promote_block_reason": failed,
        "failed_confirm": failed,
        "would_be_s1_if": would,
    })
    if fresh.get("text_without_numeric"):
        rec["promote_state"] = "blocked_by_freshness_numeric_missing"
    elif fresh.get("numeric_stale") and late.get("hard_late_chase"):
        rec["promote_state"] = "blocked_by_freshness_late_chase"
    return rec

_v573_base_build_candidate_reason_summary = _v563_build_candidate_reason_summary

def _v573_counter_rows(rows: List[Dict[str, Any]], getter, limit: int = 5) -> str:
    c: Counter = Counter()
    for r in rows:
        try:
            v = getter(r)
        except Exception:
            v = None
        if isinstance(v, list):
            for x in v:
                if x: c[str(x)] += 1
        elif v not in (None, "", [], {}):
            c[str(v)] += 1
    return " / ".join(f"{k} {v}" for k, v in c.most_common(limit)) if c else "-"

def _v573_build_candidate_reason_summary(display_rows: List[Dict[str, Any]], counts: Dict[str, int], reason_top: Any, nowv: float) -> Dict[str, Any]:
    base = _v573_base_build_candidate_reason_summary(display_rows, counts, reason_top, nowv)
    rows = [r for r in display_rows if isinstance(r, dict)]
    fresh_top = _v573_counter_rows(rows, lambda r: (r.get("freshness_numeric_profile") or {}).get("state"), 4)
    late_top = _v573_counter_rows(rows, lambda r: (r.get("refined_late_chase_profile") or {}).get("state"), 4)
    text_missing = sum(1 for r in rows if bool(r.get("freshness_text_without_numeric")))
    hard_late = sum(1 for r in rows if bool(r.get("hard_late_chase_flag")))
    summary = str(base.get("summary_text") or "")
    head = [
        "🧭 후보판정 이유 /candidate_reason · v573 신선도근거+늦은추격 정교화",
        "- 기준: strategy_worker가 미리 만든 summary_text만 읽습니다. 후보 재계산 없음.",
        f"- 신선도근거 TOP: {fresh_top} / 숫자근거없음 {text_missing}",
        f"- 늦은추격 정교화 TOP: {late_top} / 진짜늦은추격 {hard_late}",
    ]
    # 기존 제목/기준 2줄은 v563 문구라서 핵심만 교체하고 나머지는 유지한다.
    parts = summary.split("\n")
    if parts and parts[0].startswith("🧭 후보판정 이유"):
        parts = parts[2:] if len(parts) > 2 else []
    base["summary_text"] = "\n".join(head + parts)
    base["schema"] = "candidate_reason_summary_text_v573_fresh_late_refined"
    bs = base.get("batch_state") if isinstance(base.get("batch_state"), dict) else {}
    bs.update({"schema": "candidate_reason_batch_state_v573", "freshness_numeric_top": fresh_top, "late_chase_refined_top": late_top, "freshness_text_without_numeric_count": text_missing, "hard_late_chase_count": hard_late})
    base["batch_state"] = bs
    return base


# =============================================================================
# strategy_worker v0.126 / v574: S2->S1 fresh urgent loop
# - S2가 방아쇠 근처인데 신선정보가 오래된 경우, 최종 막힘 사유로 묵히지 않고
#   target_router/micro/orderflow urgent 보강 요청을 만든다.
# - 조건 수치/S1/S2/S3 기준/청산/BUY_READY는 바꾸지 않는다.
# - 정보 생산은 target_router+micro/orderflow 공장, 전략 판단은 strategy_worker가 담당한다.
# =============================================================================
def _v574_is_s2_fresh_urgent_candidate(row: Dict[str, Any]) -> Tuple[bool, List[str], float]:
    if _v510_stage(row) != "S2":
        return False, [], 999.0
    promo = row.get("s2_promotion_lifecycle") if isinstance(row.get("s2_promotion_lifecycle"), dict) else {}
    fresh = row.get("freshness_numeric_profile") if isinstance(row.get("freshness_numeric_profile"), dict) else _v573_freshness_numeric_profile(row)
    dec = row.get("canonical_entry_decision") if isinstance(row.get("canonical_entry_decision"), dict) else {}
    reasons = []
    gap = _v510_num(promo.get("trigger_gap_pct"), default=999.0)
    trigger_near = bool((gap <= 0.65) or bool(row.get("s1_near_miss")) or "방아쇠" in " ".join(str(x) for x in (promo.get("would_be_s1_if") or [])))
    stale_numeric = bool(fresh.get("numeric_stale") or fresh.get("text_without_numeric"))
    stale_text = bool(_v563_has_text(row, ("신선정보 갱신", "신선도", "정보/신선도 지연", "fresh")))
    if trigger_near:
        reasons.append("S2 방아쇠 근접")
    if stale_numeric:
        reasons.append("신선정보 숫자 오래됨/부족")
    elif stale_text:
        reasons.append("신선정보 갱신 필요")
    if bool(dec.get("s1_near_miss")):
        reasons.append("S1 근접")
    ok = bool(trigger_near and (stale_numeric or stale_text or bool(dec.get("s1_near_miss"))))
    return ok, _v510_uniq(reasons, 6), gap


def _v574_attach_s2_fresh_urgent_requests(rows: List[Dict[str, Any]], priority_requests: List[Dict[str, Any]], nowv: float) -> Tuple[List[Dict[str, Any]], Dict[str, Any]]:
    out_reqs = list(priority_requests or [])
    urgent_rows: List[Dict[str, Any]] = []
    seen = set()
    for row in rows:
        ok, reasons, gap = _v574_is_s2_fresh_urgent_candidate(row)
        if not ok:
            row["v574_fresh_urgent_request"] = False
            continue
        t = ticker_norm(row.get("ticker") or row.get("market") or row.get("symbol"))
        if not t:
            continue
        fresh = row.get("freshness_numeric_profile") if isinstance(row.get("freshness_numeric_profile"), dict) else _v573_freshness_numeric_profile(row)
        promo = row.get("s2_promotion_lifecycle") if isinstance(row.get("s2_promotion_lifecycle"), dict) else {}
        pri = 760.0
        if gap <= 0.35:
            pri += 60.0
        elif gap <= 0.65:
            pri += 35.0
        if str(fresh.get("state")) == "numeric_age_stale":
            pri += 25.0
        if bool(row.get("s1_near_miss")):
            pri += 20.0
        req = {
            "ticker": t,
            "bucket": "near_s_info_wait",
            "priority": round(pri + min(40.0, _v510_num(row.get("score"), default=0.0)), 3),
            "need": ["quote", "ws", "micro"],
            "source": "strategy_worker_v574_s2_fresh_urgent",
            "stage": "S2",
            "strategy_key": row.get("strategy_key"),
            "trigger_gap_pct": gap if gap < 900 else None,
            "freshness_numeric_state": fresh.get("state"),
            "freshness_worst_age_sec": fresh.get("worst_core_age_sec"),
            "promote_state": promo.get("promote_state"),
            "reasons": reasons,
            "micro_urgent": True,
            "updated_ts": nowv,
            "policy": "S2 근접+fresh 부족은 S1 직행이 아니라 urgent refresh 후 재판정",
        }
        row["v574_fresh_urgent_request"] = True
        row["v574_fresh_urgent_reason"] = reasons
        row["v574_fresh_urgent_priority"] = req["priority"]
        row["v574_fresh_urgent_bucket"] = "near_s_info_wait"
        row["v574_fresh_urgent_requested_ts"] = nowv
        if t not in seen:
            out_reqs.append(req)
            urgent_rows.append(req)
            seen.add(t)
    return out_reqs, {
        "schema": "strategy_s2_fresh_urgent_summary_v574",
        "version": VERSION,
        "updated_ts": nowv,
        "request_count": len(urgent_rows),
        "targets": [r.get("ticker") for r in urgent_rows],
        "rows": urgent_rows[:60],
        "policy": "S2 근접 후보의 신선정보 갱신 필요를 최종 막힘으로 남기지 않고 target_router urgent refresh로 보낸다.",
    }

_v574_base_candidate_reason_summary = _v573_build_candidate_reason_summary

def _v574_build_candidate_reason_summary(display_rows: List[Dict[str, Any]], counts: Dict[str, int], reason_top: Any, nowv: float) -> Dict[str, Any]:
    base = _v574_base_candidate_reason_summary(display_rows, counts, reason_top, nowv)
    rows = [r for r in display_rows if isinstance(r, dict)]
    req_cnt = sum(1 for r in rows if bool(r.get("v574_fresh_urgent_request")))
    targets = [ticker_norm(r.get("ticker")) for r in rows if bool(r.get("v574_fresh_urgent_request")) and ticker_norm(r.get("ticker"))]
    summary = str(base.get("summary_text") or "")
    line = f"- 신선정보 긴급요청: {req_cnt}개" + (f" / {', '.join(targets[:5])}" if targets else "")
    parts = summary.split("\n")
    insert_at = 2 if len(parts) >= 2 else len(parts)
    parts.insert(insert_at, line)
    base["summary_text"] = "\n".join(parts)
    base["schema"] = "candidate_reason_summary_text_v574_s2_fresh_urgent"
    bs = base.get("batch_state") if isinstance(base.get("batch_state"), dict) else {}
    bs.update({"schema": "candidate_reason_batch_state_v574", "fresh_urgent_request_count": req_cnt, "fresh_urgent_targets": targets[:20]})
    base["batch_state"] = bs
    return base

_v557_build_candidate_reason_summary = _v574_build_candidate_reason_summary


# =============================================================================
# strategy_worker v0.127 / v575: S2 urgent fresh loop action result
# - 새 조건을 추가하지 않는다.
# - v574가 보낸 urgent fresh 요청이 현재 row에서 어떤 결과로 돌아왔는지 같은 canonical row에 봉인한다.
# - 목표는 "요청만 보냄"이 아니라, 회복/미회복/S2유지 사유/S1승격 가능성을 바로 보이게 하는 것이다.
# =============================================================================
def _v575_text_has_any(vals: Any, words: Tuple[str, ...]) -> bool:
    try:
        if isinstance(vals, dict):
            vals = list(vals.values())
        if not isinstance(vals, list):
            vals = [vals]
        blob = " / ".join(str(x) for x in vals if x is not None)
    except Exception:
        blob = str(vals or "")
    return any(w in blob for w in words)


def _v575_fresh_ok(row: Dict[str, Any]) -> bool:
    fresh = row.get("freshness_numeric_profile") if isinstance(row.get("freshness_numeric_profile"), dict) else _v573_freshness_numeric_profile(row)
    st = str(fresh.get("state") or "")
    if bool(fresh.get("text_without_numeric") or fresh.get("numeric_stale")):
        return False
    return st in {"numeric_fresh", "no_freshness_warning"}


def _v575_block_bucket(row: Dict[str, Any]) -> str:
    promo = row.get("s2_promotion_lifecycle") if isinstance(row.get("s2_promotion_lifecycle"), dict) else {}
    failed = list(promo.get("failed_confirm") or promo.get("promote_block_reason") or [])
    would = list(promo.get("would_be_s1_if") or [])
    reasons = list(row.get("s_stage_reasons") or []) + list(row.get("s2_recheck_reasons") or []) + failed + would
    if not _v575_fresh_ok(row):
        return "fresh_wait"
    if _v575_text_has_any(reasons, ("스프레드", "미끄러짐")):
        return "exec_risk_wait"
    if _v575_text_has_any(reasons, ("방아쇠", "trigger")):
        return "trigger_wait"
    if _v575_text_has_any(reasons, ("1분", "매수체결", "체결", "가격반응")):
        return "confirm_wait"
    if _v510_stage(row) == "S1":
        return "promoted_s1"
    return "s2_other_wait"


def _v575_attach_urgent_action_result(rows: List[Dict[str, Any]], summary: Dict[str, Any], nowv: float) -> Dict[str, Any]:
    counts: Counter = Counter()
    samples: List[Dict[str, Any]] = []
    for row in rows:
        requested = bool(row.get("v574_fresh_urgent_request"))
        if not requested:
            row["v575_urgent_action_state"] = "not_requested"
            continue
        bucket = _v575_block_bucket(row)
        fresh_ok = _v575_fresh_ok(row)
        counts[bucket] += 1
        row["v575_urgent_action_state"] = bucket
        row["v575_urgent_fresh_recovered"] = bool(fresh_ok)
        row["v575_urgent_result_policy"] = "urgent 갱신 후 fresh 회복이면 남은 실행/방아쇠/확인 사유로 S1 또는 S2 유지"
        if len(samples) < 12:
            promo = row.get("s2_promotion_lifecycle") if isinstance(row.get("s2_promotion_lifecycle"), dict) else {}
            samples.append({
                "ticker": ticker_norm(row.get("ticker") or row.get("market") or row.get("symbol")),
                "stage": _v510_stage(row),
                "action_state": bucket,
                "fresh_recovered": bool(fresh_ok),
                "trigger_gap_pct": promo.get("trigger_gap_pct"),
                "spread_pct": row.get("spread_pct"),
                "slippage_pct": row.get("slippage_pct"),
                "buy_ratio": row.get("buy_ratio"),
                "buy_sustain_1m": row.get("buy_sustain_1m"),
            })
    total = sum(counts.values())
    recovered = int(counts.get("exec_risk_wait",0)+counts.get("trigger_wait",0)+counts.get("confirm_wait",0)+counts.get("promoted_s1",0)+counts.get("s2_other_wait",0))
    result = {
        "schema": "s2_urgent_fresh_action_result_v575",
        "version": VERSION,
        "updated_ts": nowv,
        "request_count": total,
        "fresh_recovered_count": recovered,
        "s1_promoted_count": int(counts.get("promoted_s1",0)),
        "s2_keep_count": int(total - counts.get("promoted_s1",0)),
        "state_counts": dict(counts),
        "sample": samples,
        "policy": "S2 근접 fresh 부족은 urgent refresh를 태운 뒤 결과에 따라 S1 또는 S2 유지. 조건 수치 변경 없음.",
    }
    return result


_v575_prev_attach_s2_fresh_urgent_requests = _v574_attach_s2_fresh_urgent_requests

def _v575_attach_s2_fresh_urgent_requests(rows: List[Dict[str, Any]], priority_requests: List[Dict[str, Any]], nowv: float) -> Tuple[List[Dict[str, Any]], Dict[str, Any]]:
    out_reqs, base_summary = _v575_prev_attach_s2_fresh_urgent_requests(rows, priority_requests, nowv)
    action = _v575_attach_urgent_action_result(rows, base_summary if isinstance(base_summary, dict) else {}, nowv)
    if isinstance(base_summary, dict):
        base_summary = dict(base_summary)
    else:
        base_summary = {}
    base_summary["v575_action_result"] = action
    base_summary["schema"] = "strategy_s2_fresh_urgent_summary_v575_action"
    base_summary["policy"] = "urgent 요청 생성+현재 cycle 결과 분류를 함께 저장한다. 요청만 세지 않고 S1/S2 결과까지 본다."
    return out_reqs, base_summary

# v510_publish는 런타임 name lookup을 하므로 여기서 단일 본선 함수로 교체한다.
_v574_attach_s2_fresh_urgent_requests = _v575_attach_s2_fresh_urgent_requests


# =============================================================================
# strategy_worker v0.139 / v603: 공식 캔들 fresh 대기 후보를 candle_worker 우선요청으로 보냄
# - 조건 완화가 아니다. final_trade_state가 캔들 오래됨 때문에 S2_RECHECK인 경우
#   paper가 보기 전에 candle_worker가 그 종목을 먼저 갱신하도록 요청만 명확히 남긴다.
# =============================================================================
def _v603_has_candle_wait(row: Dict[str, Any]) -> Tuple[bool, float, List[str]]:
    reasons = _v602_list(row.get('final_trade_reasons'), row.get('s_stage_reasons'), row.get('s2_recheck_reasons'), limit=16)
    blob = ' / '.join(str(x) for x in reasons)
    canon = row.get('canonical_metric_row') if isinstance(row.get('canonical_metric_row'), dict) else {}
    struct = canon.get('structure') if isinstance(canon.get('structure'), dict) else {}
    official = struct.get('official_structure_inputs') if isinstance(struct.get('official_structure_inputs'), dict) else _v596_official_structure_inputs(row)
    age = _v510_num(official.get('official_candle_age'), row.get('official_candle_age'), row.get('candle_age_sec'), default=-1.0) if isinstance(official, dict) else -1.0
    present = _v510_num(official.get('present_count'), default=-1.0) if isinstance(official, dict) else -1.0
    text_wait = any(w in blob for w in ('공식 캔들 오래됨', '공식캔들 stale', '공식 구조재료 부족', '캔들 오래됨'))
    age_wait = bool(age > 45)
    missing_wait = bool(0 <= present < 6)
    return bool(text_wait or age_wait or missing_wait), age, reasons


_v603_prev_attach_s2_fresh_urgent_requests = _v574_attach_s2_fresh_urgent_requests

def _v603_attach_s2_fresh_urgent_requests(rows: List[Dict[str, Any]], priority_requests: List[Dict[str, Any]], nowv: float) -> Tuple[List[Dict[str, Any]], Dict[str, Any]]:
    out_reqs, base_summary = _v603_prev_attach_s2_fresh_urgent_requests(rows, priority_requests, nowv)
    out_reqs = list(out_reqs or [])
    added: List[Dict[str, Any]] = []
    seen = {ticker_norm(r.get('ticker')) for r in out_reqs if isinstance(r, dict) and ticker_norm(r.get('ticker'))}
    for row in rows or []:
        if not isinstance(row, dict):
            continue
        state = str(row.get('final_trade_state') or '')
        stage = _v510_stage(row)
        if state not in {'S2_RECHECK', 'S1_PASS'} and stage not in {'S1', 'S2'}:
            row['v603_candle_fresh_request'] = False
            continue
        need, age, reasons = _v603_has_candle_wait(row)
        if not need:
            row['v603_candle_fresh_request'] = False
            continue
        t = ticker_norm(row.get('ticker') or row.get('market') or row.get('symbol'))
        if not t:
            continue
        pri = 900.0 if stage == 'S1' or state == 'S1_PASS' else 850.0
        if age > 300:
            pri += 70.0
        elif age > 120:
            pri += 40.0
        req = {
            'ticker': t,
            'bucket': 's2_candle_fresh_wait' if stage == 'S2' else 's1_candle_preopen',
            'priority': round(pri + min(40.0, _v510_num(row.get('score'), default=0.0)), 3),
            'need': ['candle'],
            'source': 'strategy_worker_v603_final_trade_state_candle_wait',
            'stage': stage,
            'final_trade_state': state,
            'official_candle_age': age if age >= 0 else None,
            'reasons': reasons[:6] or ['공식 캔들 최신화 필요'],
            'updated_ts': nowv,
            'policy': '캔들이 오래돼 S1_PASS가 막힌 후보는 candle_worker가 먼저 갱신한다. 조건/S등급/청산 변경 없음.',
        }
        row['v603_candle_fresh_request'] = True
        row['v603_candle_fresh_age'] = age if age >= 0 else None
        row['v603_candle_fresh_bucket'] = req['bucket']
        if t not in seen:
            out_reqs.append(req)
            added.append(req)
            seen.add(t)
    if isinstance(base_summary, dict):
        base_summary = dict(base_summary)
    else:
        base_summary = {}
    base_summary['v603_candle_fresh_summary'] = {
        'schema': 'strategy_candle_fresh_priority_summary_v603',
        'version': VERSION,
        'request_count': len(added),
        'targets': [r.get('ticker') for r in added],
        'rows': added[:40],
        'policy': 'final_trade_state에서 공식 캔들 오래됨으로 막힌 S1/S2 후보를 candle_worker 우선순위로 보낸다.',
    }
    return out_reqs, base_summary


_v574_attach_s2_fresh_urgent_requests = _v603_attach_s2_fresh_urgent_requests

_v575_base_candidate_reason_summary = _v574_build_candidate_reason_summary

def _v575_build_candidate_reason_summary(display_rows: List[Dict[str, Any]], counts: Dict[str, int], reason_top: Any, nowv: float) -> Dict[str, Any]:
    base = _v575_base_candidate_reason_summary(display_rows, counts, reason_top, nowv)
    rows = [r for r in display_rows if isinstance(r, dict)]
    c = Counter(str(r.get("v575_urgent_action_state") or "not_requested") for r in rows if bool(r.get("v574_fresh_urgent_request")))
    req = sum(c.values())
    recovered = sum(c.get(k,0) for k in ("exec_risk_wait","trigger_wait","confirm_wait","promoted_s1","s2_other_wait"))
    promoted = c.get("promoted_s1", 0)
    keep = req - promoted
    top = " / ".join(f"{k} {v}" for k,v in c.most_common(5)) if c else "-"
    short = [
        "🧭 후보판정 이유 /candidate_reason · v575 긴급갱신 결과판",
        "- 기준: strategy_worker summary_text만 읽습니다. 후보 재계산 없음.",
        f"- 긴급갱신: 요청 {req} / fresh회복 {recovered} / S1승격 {promoted} / S2유지 {keep}",
        f"- 유지이유 TOP: {top}",
    ]
    summary = str(base.get("summary_text") or "")
    parts = summary.split("\n")
    if parts and parts[0].startswith("🧭 후보판정 이유"):
        # 기존 제목/상단 2~4줄은 v573/v574가 길게 붙인 부분이라 v575 요약으로 교체한다.
        drop = 0
        while drop < len(parts) and (parts[drop].startswith("🧭") or parts[drop].startswith("- 기준") or parts[drop].startswith("- 신선") or parts[drop].startswith("- 늦은") or parts[drop].startswith("- 긴급")):
            drop += 1
        parts = parts[drop:]
    base["summary_text"] = "\n".join(short + parts)
    base["schema"] = "candidate_reason_summary_text_v575_urgent_result"
    bs = base.get("batch_state") if isinstance(base.get("batch_state"), dict) else {}
    bs.update({"schema":"candidate_reason_batch_state_v575", "urgent_request_count": req, "urgent_fresh_recovered_count": recovered, "urgent_s1_promoted_count": promoted, "urgent_s2_keep_count": keep, "urgent_state_counts": dict(c)})
    base["batch_state"] = bs
    return base


# =============================================================================
# strategy_worker v0.128 / v580: S2 fresh/진입품질 원인 분리 표시
# - 조건/S1·S2·S3/청산 수치 변경 없음.
# - 현재 막힘(promote_block_reason)과 S1 필요조건(would_be_s1_if)을 섞어 집계하지 않는다.
# - fresh 회복 후 남은 병목이 실행위험/방아쇠/확인신호인지 한 줄로 분리한다.
# =============================================================================

def _v580_list_counter(rows: List[Dict[str, Any]], key: str, limit: int = 5) -> str:
    c: Counter = Counter()
    for r in rows:
        v = r.get(key)
        if isinstance(v, list):
            for x in v:
                if x:
                    c[str(x)] += 1
        elif v:
            c[str(v)] += 1
    return " / ".join(f"{k} {v}" for k, v in c.most_common(limit)) if c else "-"


def _v580_replace_or_insert(lines: List[str], prefix: str, replacement: List[str]) -> List[str]:
    out: List[str] = []
    done = False
    for line in lines:
        if (not done) and line.startswith(prefix):
            out.extend(replacement)
            done = True
        else:
            out.append(line)
    if not done:
        # 단계 줄 뒤에 끼워 넣는다.
        insert_at = 0
        for i, line in enumerate(out):
            if line.startswith('- 현재 단계:'):
                insert_at = i + 1
                break
        out[insert_at:insert_at] = replacement
    return out


def _v580_build_candidate_reason_summary(display_rows: List[Dict[str, Any]], counts: Dict[str, int], reason_top: Any, nowv: float) -> Dict[str, Any]:
    base = _v575_build_candidate_reason_summary(display_rows, counts, reason_top, nowv)
    rows = [r for r in display_rows if isinstance(r, dict)]
    s2_rows = [r for r in rows if _v510_stage(r) == 'S2']
    lifecycles = [r.get('s2_promotion_lifecycle') or {} for r in s2_rows]
    current_block_top = _v580_list_counter(lifecycles, 'promote_block_reason', 6)
    need_top = _v580_list_counter(lifecycles, 'would_be_s1_if', 6)
    c = Counter(str(r.get('v575_urgent_action_state') or 'not_requested') for r in rows if bool(r.get('v574_fresh_urgent_request')))
    req = sum(c.values())
    recovered = sum(c.get(k, 0) for k in ('exec_risk_wait', 'trigger_wait', 'confirm_wait', 'promoted_s1', 's2_other_wait'))
    fresh_wait = c.get('fresh_wait', 0)
    exec_wait = c.get('exec_risk_wait', 0)
    trigger_wait = c.get('trigger_wait', 0)
    confirm_wait = c.get('confirm_wait', 0)
    promoted = c.get('promoted_s1', 0)
    fresh_line = f"- fresh 분리: 요청 {req} / 회복 {recovered} / 미회복 {fresh_wait} / 회복후 실행위험 {exec_wait} / 방아쇠대기 {trigger_wait} / 확인대기 {confirm_wait} / S1 {promoted}"
    title = "🧭 후보판정 이유 /candidate_reason · v580 fresh·진입품질 분리판"
    summary = str(base.get('summary_text') or '')
    lines = summary.split('\n') if summary else []
    if lines and lines[0].startswith('🧭 후보판정 이유'):
        lines[0] = title
    else:
        lines.insert(0, title)
    # 기존 혼합 집계 한 줄을 현재막힘/필요조건으로 분리한다.
    lines = _v580_replace_or_insert(lines, '- S2 막힘 TOP:', [
        f'- S2 현재막힘 TOP: {current_block_top}',
        f'- S1 필요조건 TOP: {need_top}',
    ])
    # fresh 분리 줄은 긴급갱신/유지이유 뒤에 배치한다.
    insert_at = 0
    for i, line in enumerate(lines):
        if line.startswith('- 유지이유 TOP:'):
            insert_at = i + 1
            break
    if insert_at:
        lines.insert(insert_at, fresh_line)
    elif fresh_line not in lines:
        lines.insert(2 if len(lines) > 2 else len(lines), fresh_line)
    base['summary_text'] = '\n'.join(lines)
    base['schema'] = 'candidate_reason_summary_text_v580_fresh_entry_split'
    bs = base.get('batch_state') if isinstance(base.get('batch_state'), dict) else {}
    bs.update({
        'schema': 'candidate_reason_batch_state_v580',
        's2_current_block_top_text': current_block_top,
        's1_needed_top_text': need_top,
        'urgent_fresh_wait_count': fresh_wait,
        'urgent_exec_wait_count': exec_wait,
        'urgent_trigger_wait_count': trigger_wait,
        'urgent_confirm_wait_count': confirm_wait,
    })
    base['batch_state'] = bs
    return base

# 최종 summary 생산 본선 교체: 출력부 보정이 아니라 strategy_worker summary_text 생산부에서 분리한다.
_v557_build_candidate_reason_summary = _v580_build_candidate_reason_summary


# =============================================================================
# strategy_worker v0.130 / v584: 정보 주인표 + canonical metric row 본선
# - 기능 삭제 없음. 기존 structure_freshness/entry_context 호환 필드는 유지한다.
# - 새 정보는 생산 공장 → strategy canonical row → paper/main cache reader 순서로만 흐른다.
# - 조건/S등급/청산/자동매수 수치 변경 없음.
# =============================================================================

INFO_OWNER_TABLE_V584 = {
    'scanner': {'owner': 'scanner_worker', 'produces': ['ticker','hot_rank','volume','change_1m/3m/5m'], 'cache': 'scanner/feature input'},
    'feature': {'owner': 'feature_worker', 'produces': ['price','VWAP','EMA','relative_strength','price_reaction'], 'cache': 'feature cache'},
    'orderflow': {'owner': 'orderflow_worker+micro_ws', 'produces': ['quote','trade','spread','slippage','buy_ratio','sell_pressure'], 'cache': 'orderflow/micro cache'},
    'strategy': {'owner': 'strategy_worker', 'produces': ['structure','freshness_map','S1/S2/S3','entry_plan','risk_reward','block_reasons'], 'cache': 'canonical row + handoff'},
    'paper': {'owner': 'paper_bot', 'produces': ['OPEN','CLOSED','entry_reaction','score_cache','review_cache'], 'cache': 'paper status/trace/score/review'},
    'main': {'owner': 'main_bot', 'produces': ['display only'], 'cache': 'reads existing cache only'},
}


def _v584_num(row: Dict[str, Any], *keys: str, default: float = 0.0) -> float:
    vals = [row.get(k) for k in keys]
    return _v510_num(*vals, default=default)


def _v584_age_state(age: float, ttl: float) -> str:
    try:
        a = float(age)
    except Exception:
        a = 999999.0
    if a >= 99999:
        return 'missing'
    if a <= ttl:
        return 'fresh'
    return 'stale'


def _v584_build_freshness_map(row: Dict[str, Any], nowv: float) -> Dict[str, Any]:
    age_values = {
        'scanner_hot': _v584_num(row, 'hot_signal_age_sec', default=999999.0),
        'micro': _v584_num(row, 'micro_age_sec', default=999999.0),
        'orderflow': _v584_num(row, 'orderflow_age_sec', 'micro_age_sec', default=999999.0),
        'price_reaction': _v584_num(row, 'price_reaction_age_sec', default=999999.0),
        'quote': _v584_num(row, 'quote_age_sec', default=999999.0),
        'paper_row': max(0.0, nowv - _event_created_ts(row)),
    }
    ttl = {'scanner_hot': 35.0, 'micro': 20.0, 'orderflow': 20.0, 'price_reaction': 30.0, 'quote': 20.0, 'paper_row': 45.0}
    owners = {'scanner_hot': 'scanner_worker', 'micro': 'micro_sidecar/ws', 'orderflow': 'orderflow_worker', 'price_reaction': 'feature_worker', 'quote': 'micro_sidecar/ws', 'paper_row': 'strategy_worker'}
    items: Dict[str, Any] = {}
    stale_fields: List[str] = []
    for k, age in age_values.items():
        state = _v584_age_state(age, ttl[k])
        items[k] = {'owner': owners[k], 'age_sec': round(float(age), 3), 'ttl_sec': ttl[k], 'state': state}
        if state != 'fresh':
            stale_fields.append(f'{k} {float(age):.1f}s')
    for x in row.get('stale_reasons') or []:
        sx = str(x or '').strip()
        if sx and sx not in stale_fields:
            stale_fields.append(sx)
    core_keys = ('micro','orderflow','price_reaction','quote')
    core_states = [items[k]['state'] for k in core_keys]
    if all(x == 'fresh' for x in core_states):
        overall = 'fresh_ok'
    elif any(x == 'missing' for x in core_states):
        overall = 'fresh_missing'
    else:
        overall = 'fresh_recheck'
    max_core_age = max(float(items[k]['age_sec']) for k in core_keys)
    return {'schema': 'freshness_map_v584', 'overall': overall, 'max_core_age_sec': round(max_core_age, 3), 'items': items, 'stale_fields': stale_fields[:10]}


def _v584_structure_state(row: Dict[str, Any]) -> Tuple[str, List[str]]:
    levels = row.get('structure_levels') if isinstance(row.get('structure_levels'), dict) else {}
    timing = row.get('entry_timing_spine') if isinstance(row.get('entry_timing_spine'), dict) else {}
    tags = [str(x) for x in (row.get('structure_tags') or [])]
    risks = [str(x) for x in (row.get('risk_tags') or [])]
    price = _v584_num(row, 'current_price', 'entry_price', 'price', default=0.0)
    first_price = _v510_num(timing.get('first_seen_price'), timing.get('structure_seen_price'), default=0.0)
    s2_price = _v510_num(timing.get('s2_seen_price'), default=0.0)
    first_ret = round(((price - first_price) / first_price * 100.0), 3) if price and first_price else _v510_num(timing.get('first_to_now_return'), timing.get('first_to_now_return_pct'), default=0.0)
    s2_ret = round(((price - s2_price) / s2_price * 100.0), 3) if price and s2_price else _v510_num(timing.get('s2_to_now_return'), timing.get('s2_to_now_return_pct'), default=0.0)
    trigger_gap = _v510_num(row.get('trigger_gap_pct'), levels.get('distance_to_trigger_pct'), default=999999.0)
    defense_fail = any(('방어실패' in x or '이탈' in x or '윗꼬리' in x or '가짜돌파' in x) for x in tags + risks)
    recovery = any(('VWAP' in x or 'EMA' in x or '눌림' in x or '회복' in x or '방어' in x) for x in tags)
    late = bool(row.get('late_chase_flag') or (first_ret >= 1.4) or (s2_ret >= 0.8) or any('늦은추격' in x for x in risks))
    if defense_fail:
        state = '방어실패/가짜돌파위험'
    elif late:
        state = '늦은추격주의'
    elif recovery:
        state = '눌림회복/방어구조'
    elif trigger_gap < 0.35:
        state = '방아쇠근접'
    else:
        state = '구조관찰'
    basis = [f'first→now {first_ret:+.2f}%', f'S2→now {s2_ret:+.2f}%', f'trigger_gap {trigger_gap if trigger_gap < 900000 else 0:.3f}%']
    if tags:
        basis.append('tags:' + ','.join(tags[:3]))
    if risks:
        basis.append('risk:' + ','.join(risks[:3]))
    return state, basis[:8]


def _v584_execution_risk(row: Dict[str, Any]) -> Dict[str, Any]:
    spread = _v584_num(row, 'spread_pct', default=0.0)
    slippage = _v584_num(row, 'slippage_pct', 'spread_pct', default=spread)
    buy = _v584_num(row, 'buy_ratio', default=0.0)
    sustain = _v584_num(row, 'buy_sustain_1m', default=0.0)
    tags = [str(x) for x in (row.get('risk_tags') or [])]
    obs: List[str] = []
    if spread > 0.18: obs.append('스프레드부담')
    if slippage > 0.18: obs.append('미끄러짐부담')
    if buy < 0.70: obs.append('매수체결약함')
    if sustain < 0.70: obs.append('1분지속약함')
    for x in tags:
        if x not in obs: obs.append(x)
    level = 'risk_high' if any(x in obs for x in ['스프레드부담','미끄러짐부담','매도압력부담','매도벽/매도체결압력']) else ('risk_watch' if obs else 'risk_ok')
    return {'schema': 'execution_risk_v584', 'state': level, 'tags': obs[:10], 'spread_pct': round(spread,4), 'slippage_pct': round(slippage,4), 'buy_ratio': round(buy,4), 'buy_sustain_1m': round(sustain,4)}


def _v584_timing_spine(row: Dict[str, Any], nowv: float) -> Dict[str, Any]:
    old = row.get('entry_timing_spine') if isinstance(row.get('entry_timing_spine'), dict) else {}
    price = _v584_num(row, 'current_price', 'entry_price', 'price', default=0.0)
    first_ts = _v510_num(old.get('first_seen_ts'), row.get('first_seen_ts'), row.get('created_at'), default=0.0)
    s2_ts = _v510_num(old.get('s2_seen_ts'), row.get('s2_seen_ts'), default=0.0)
    s1_ts = _v510_num(old.get('s1_seen_ts'), row.get('s1_seen_ts'), default=0.0)
    first_price = _v510_num(old.get('first_seen_price'), row.get('first_seen_price'), row.get('detected_price'), price, default=0.0)
    s2_price = _v510_num(old.get('s2_seen_price'), row.get('s2_seen_price'), price if _v510_stage(row) == 'S2' else 0.0, default=0.0)
    s1_price = _v510_num(old.get('s1_seen_price'), row.get('s1_seen_price'), price if _v510_stage(row) == 'S1' else 0.0, default=0.0)
    first_to_now = round(((price-first_price)/first_price*100.0),3) if price and first_price else 0.0
    s2_to_now = round(((price-s2_price)/s2_price*100.0),3) if price and s2_price else 0.0
    return {'schema': 'entry_timing_spine_v584', 'first_seen_ts': first_ts or _event_created_ts(row), 's2_seen_ts': s2_ts, 's1_seen_ts': s1_ts, 'now_ts': nowv, 'first_seen_price': first_price, 's2_seen_price': s2_price, 's1_seen_price': s1_price, 'current_price': price, 'first_to_now_return_pct': first_to_now, 's2_to_now_return_pct': s2_to_now, 'first_to_s1_delay_sec': round(max(0.0, (s1_ts-first_ts)),3) if first_ts and s1_ts else None, 'late_chase_flag': bool(row.get('late_chase_flag') or first_to_now >= 1.4 or s2_to_now >= 0.8)}


def _v584_canonical_decision(structure_state: str, freshness: Dict[str, Any], execution: Dict[str, Any]) -> str:
    if freshness.get('overall') != 'fresh_ok':
        return '구조판단 fresh 재확인'
    if structure_state in {'늦은추격주의','방어실패/가짜돌파위험'}:
        return '구조위험 재확인'
    if execution.get('state') != 'risk_ok':
        return '실행위험 재확인'
    return '구조+fresh 관찰양호'


def _v584_build_canonical_metric_row(row: Dict[str, Any], nowv: float) -> Dict[str, Any]:
    structure_state, basis = _v584_structure_state(row)
    freshness = _v584_build_freshness_map(row, nowv)
    execution = _v584_execution_risk(row)
    timing = _v584_timing_spine(row, nowv)
    decision = _v584_canonical_decision(structure_state, freshness, execution)
    levels = row.get('structure_levels') if isinstance(row.get('structure_levels'), dict) else {}
    plan = row.get('entry_plan') if isinstance(row.get('entry_plan'), dict) else {}
    rr = row.get('risk_reward') if isinstance(row.get('risk_reward'), dict) else {}
    return {
        'schema': 'strategy_canonical_metric_row_v584',
        'version': VERSION,
        'updated_ts': nowv,
        'updated_text': now_text(nowv),
        'owner_policy': INFO_OWNER_TABLE_V584,
        'symbol': row.get('symbol') or row.get('ticker'),
        'ticker': row.get('ticker'),
        'strategy_key': row.get('strategy_key'),
        'strategy_label': row.get('strategy_label') or row.get('strategy'),
        'grade': _v510_stage(row),
        'metrics': {
            'price_reaction_pct': _v584_num(row, 'price_reaction_pct', default=0.0),
            'buy_ratio': _v584_num(row, 'buy_ratio', default=0.0),
            'buy_sustain_1m': _v584_num(row, 'buy_sustain_1m', default=0.0),
            'spread_pct': _v584_num(row, 'spread_pct', default=0.0),
            'slippage_pct': _v584_num(row, 'slippage_pct', 'spread_pct', default=0.0),
        },
        'freshness_map': freshness,
        'structure': {'state': structure_state, 'tags': list(row.get('structure_tags') or []), 'levels': levels, 'basis': basis},
        'entry_plan': plan,
        'risk_reward': rr,
        'execution_risk': execution,
        'timing_spine': timing,
        'block_reasons': list(row.get('block_reasons') or row.get('s_stage_reasons') or []),
        'entry_reasons': list(row.get('entry_reasons') or row.get('s_stage_reasons') or []),
        'source_snapshot': {'scanner': row.get('hot_signal_age_sec'), 'feature': row.get('price_reaction_age_sec'), 'orderflow': row.get('orderflow_age_sec'), 'micro': row.get('micro_age_sec'), 'quote': row.get('quote_age_sec')},
        'decision_reference': decision,
        'policy': '기능 유지. strategy_worker가 판단값을 봉인하고 paper/main은 읽기만 한다. 조건/S등급/청산 변경 없음.',
    }


def _v584_attach_canonical_metric_rows(rows: List[Dict[str, Any]], nowv: float) -> List[Dict[str, Any]]:
    out: List[Dict[str, Any]] = []
    for r in rows or []:
        if not isinstance(r, dict):
            continue
        rr = dict(r)
        canon = _v584_build_canonical_metric_row(rr, nowv)
        sf = {
            'schema': 'structure_freshness_spine_v584_alias',
            'version': VERSION,
            'updated_ts': nowv,
            'updated_text': now_text(nowv),
            'structure_state': canon['structure']['state'],
            'structure_basis': canon['structure']['basis'],
            'freshness_state': canon['freshness_map']['overall'],
            'age_values': {k: v.get('age_sec') for k, v in canon['freshness_map']['items'].items()},
            'max_core_age_sec': canon['freshness_map']['max_core_age_sec'],
            'stale_fields': canon['freshness_map']['stale_fields'],
            'execution_risk_observed': canon['execution_risk']['state'] != 'risk_ok',
            'decision_reference': canon['decision_reference'],
            'policy': canon['policy'],
        }
        rr['canonical_metric_row'] = canon
        rr['canonical_row_schema'] = canon['schema']
        rr['freshness_map'] = canon['freshness_map']
        rr['execution_risk'] = canon['execution_risk']
        rr['timing_spine_v584'] = canon['timing_spine']
        rr['structure_freshness'] = sf
        rr['structure_state_v584'] = sf['structure_state']
        rr['structure_freshness_state'] = sf['freshness_state']
        rr['structure_fresh_decision'] = sf['decision_reference']
        # v602: strategy canonical row 안에서 최종 매수 가능/대기/관찰/차단을 한 번 더 봉인한다.
        rr = _v602_seal_final_trade_state(rr, canon)
        canon = rr.get('canonical_metric_row') if isinstance(rr.get('canonical_metric_row'), dict) else canon
        ctx = rr.get('entry_context') if isinstance(rr.get('entry_context'), dict) else {}
        ctx = dict(ctx)
        ctx['canonical_metric_row'] = canon
        ctx['freshness_map'] = canon['freshness_map']
        ctx['execution_risk'] = canon['execution_risk']
        ctx['timing_spine_v584'] = canon['timing_spine']
        ctx['structure_freshness'] = sf
        ctx['final_trade_state'] = rr.get('final_trade_state')
        ctx['final_trade_allowed'] = rr.get('final_trade_allowed')
        ctx['final_trade_label'] = rr.get('final_trade_label')
        ctx['final_trade_reasons'] = rr.get('final_trade_reasons')
        rr['entry_context'] = ctx
        out.append(rr)
    return out

# _v510_publish 본체가 호출하는 v583 hook 자체를 v584 본선으로 교체한다.
_v583_attach_structure_freshness = _v584_attach_canonical_metric_rows



# =============================================================================
# strategy_worker v0.139 / v603: 공식캔들 반영 후 최종판정 확정
# - paper OPEN 최종 기준은 final_trade_state == S1_PASS 하나로 봉인한다.
# - paper_bot은 이 값을 읽기만 한다. 새 매수 판단은 paper에 추가하지 않는다.
# - 기존 canonical_entry_decision은 재료로 유지하되, 최종 허용값은 여기서 한 번 더 맞춘다.
# =============================================================================

def _v602_first_dict(*items: Any) -> Dict[str, Any]:
    for x in items:
        if isinstance(x, dict) and x:
            return x
    return {}


def _v602_list(*items: Any, limit: int = 12) -> List[str]:
    out: List[str] = []
    for item in items:
        if isinstance(item, list):
            src = item
        elif item in (None, "", {}, []):
            src = []
        else:
            src = [item]
        for v in src:
            sv = str(v or "").strip()
            if sv and sv not in out:
                out.append(sv)
            if len(out) >= limit:
                return out
    return out


def _v602_stage_for_state(state: str) -> str:
    if state == "S1_PASS":
        return "S1"
    if state == "S2_RECHECK":
        return "S2"
    return "S3"


def _v602_state_label(state: str) -> str:
    return {
        "S1_PASS": "✅ 매수 가능",
        "S2_RECHECK": "⚠️ 대기: 확인 더 필요",
        "S3_WATCH": "❔ 관찰만",
        "BLOCKED": "❌ 매수 금지: 위험",
    }.get(str(state or ""), "❔ 확인중")



# =============================================================================
# strategy_worker v0.149 / v620: S1 trigger reached gate
# - 조건값을 새로 조이지 않는다. 이미 봉인된 structure_levels/entry_plan의
#   trigger_price가 실제 현재가/진입가로 도달했는지 S1_PASS 직전에 한 번 더 연결한다.
# - trigger 미도달이면 S2_RECHECK로 남기고, paper는 그 row를 OPEN하지 않는다.
# =============================================================================
def _v620_price_fmt(v: Any) -> str:
    try:
        f = float(str(v).replace(',', ''))
        if f >= 1000:
            return f"{f:,.0f}"
        if f >= 10:
            return f"{f:,.2f}".rstrip('0').rstrip('.')
        return f"{f:,.4f}".rstrip('0').rstrip('.')
    except Exception:
        return '-'


def _v620_trigger_gate(row: Dict[str, Any], canon: Optional[Dict[str, Any]] = None) -> Dict[str, Any]:
    canon = canon if isinstance(canon, dict) else {}
    structure = canon.get('structure') if isinstance(canon.get('structure'), dict) else {}
    levels = structure.get('levels') if isinstance(structure.get('levels'), dict) else (row.get('structure_levels') if isinstance(row.get('structure_levels'), dict) else {})
    plan = canon.get('entry_plan') if isinstance(canon.get('entry_plan'), dict) else (row.get('entry_plan') if isinstance(row.get('entry_plan'), dict) else {})
    timing = canon.get('timing_spine') if isinstance(canon.get('timing_spine'), dict) else (row.get('entry_timing_spine') if isinstance(row.get('entry_timing_spine'), dict) else {})
    price = _v510_num(row.get('current_price'), row.get('entry_price'), row.get('price'), timing.get('current_price'), default=0.0)
    trigger = _v510_num(levels.get('trigger_price'), plan.get('trigger_price'), row.get('trigger_price'), default=0.0)
    tolerance = 0.999
    reached = bool(price and trigger and price >= trigger * tolerance)
    # 표시용 gap은 trigger 기준. 음수면 방아쇠 아래다.
    gap = None
    try:
        if price and trigger:
            gap = round((price - trigger) / trigger * 100.0, 3)
    except Exception:
        gap = None
    status = 'trigger_reached' if reached else ('trigger_missing' if not trigger else 'trigger_wait')
    reason = '방아쇠 도달 확인' if reached else ('방아쇠 가격 없음' if not trigger else f"방아쇠 미도달: 현재 {_v620_price_fmt(price)} < 방아쇠 {_v620_price_fmt(trigger)}")
    return {
        'schema': 'trigger_gate_v620',
        'current_price': round(price, 8) if price else None,
        'trigger_price': round(trigger, 8) if trigger else None,
        'trigger_reached': reached,
        'trigger_gap_pct': gap,
        'status': status,
        'reason': reason,
        'tolerance': tolerance,
        'policy': 'S1_PASS 전 trigger_reached를 확인한다. 방아쇠 미도달이면 S2_RECHECK.',
    }

def _v602_final_trade_decision(row: Dict[str, Any], canon: Dict[str, Any]) -> Dict[str, Any]:
    stage = _v510_stage(row)
    ctx = row.get("entry_context") if isinstance(row.get("entry_context"), dict) else {}
    dec = _v602_first_dict(row.get("canonical_entry_decision"), ctx.get("canonical_entry_decision"), row.get("common_entry_decision"), ctx.get("common_entry_decision"))
    freshness = canon.get("freshness_map") if isinstance(canon.get("freshness_map"), dict) else {}
    execution = canon.get("execution_risk") if isinstance(canon.get("execution_risk"), dict) else {}
    structure = canon.get("structure") if isinstance(canon.get("structure"), dict) else {}
    structure_state = str(structure.get("state") or row.get("structure_state_v584") or "")
    plan = canon.get("entry_plan") if isinstance(canon.get("entry_plan"), dict) else (row.get("entry_plan") if isinstance(row.get("entry_plan"), dict) else {})
    rr = canon.get("risk_reward") if isinstance(canon.get("risk_reward"), dict) else (row.get("risk_reward") if isinstance(row.get("risk_reward"), dict) else {})
    timing = canon.get("timing_spine") if isinstance(canon.get("timing_spine"), dict) else (row.get("entry_timing_spine") if isinstance(row.get("entry_timing_spine"), dict) else {})
    line_ev = structure.get("line_evidence") if isinstance(structure.get("line_evidence"), dict) else {}
    official = structure.get("official_structure_inputs") if isinstance(structure.get("official_structure_inputs"), dict) else _v596_official_structure_inputs(row) if "_v596_official_structure_inputs" in globals() else {}

    hard: List[str] = []
    wait: List[str] = []
    watch: List[str] = []

    if stage != "S1":
        if stage == "S2":
            wait.append("아직 S1이 아니라 재확인 대기")
        else:
            watch.append("S1 후보가 아니라 관찰")

    if not bool(dec.get("s1_allowed") or dec.get("gate_pass")):
        rs = dec.get("display_reasons") if isinstance(dec.get("display_reasons"), list) else (dec.get("s1_recheck_reasons") if isinstance(dec.get("s1_recheck_reasons"), list) else [])
        wait.append("전략 조건 최종통과 아님" + ((": " + " / ".join(str(x) for x in rs[:3])) if rs else ""))

    if row.get("fresh_gate_ok") is False:
        wait.append("정보가 오래돼 재확인 필요")
    if row.get("paper_bot_open") is False or row.get("open_eligible") is False or row.get("trade_ready") is False:
        wait.append("기존 OPEN 허용값이 꺼져 있음")

    if freshness.get("overall") != "fresh_ok":
        stale = freshness.get("stale_fields") if isinstance(freshness.get("stale_fields"), list) else []
        wait.append("최신정보 재확인 필요" + ((": " + " / ".join(str(x) for x in stale[:3])) if stale else ""))

    official_age = _v510_num(official.get("official_candle_age"), row.get("official_candle_age"), row.get("candle_age_sec"), default=-1.0) if isinstance(official, dict) else -1.0
    if official_age > 45:
        wait.append(f"공식 캔들 오래됨 {official_age:.0f}s")
    present = _v510_num(official.get("present_count"), default=-1.0) if isinstance(official, dict) else -1.0
    if 0 <= present < 6:
        wait.append("공식 구조재료 부족")

    line_risks = _v602_list(line_ev.get("line_risk_tags") if isinstance(line_ev, dict) else [], row.get("risk_tags"), execution.get("tags"), limit=12)
    if structure_state in {"늦은추격주의", "방어실패/가짜돌파위험"}:
        hard.append("차트 모양 위험: " + structure_state)
    if any(("가짜돌파" in x or "방어실패" in x or "윗꼬리" in x or "늦은추격" in x) for x in line_risks):
        hard.append("차트 위험태그: " + " / ".join(line_risks[:3]))

    exec_state = str(execution.get("state") or "")
    if exec_state == "risk_high":
        hard.append("진입 직전 거래위험 큼: " + " / ".join(line_risks[:4]))
    elif exec_state and exec_state != "risk_ok":
        wait.append("체결·스프레드 재확인 필요: " + exec_state)

    rr_ratio = _v510_num(rr.get("rr_ratio"), default=0.0) if isinstance(rr, dict) else 0.0
    if rr_ratio > 0 and rr_ratio < 1.0:
        wait.append(f"손익비 부족 {rr_ratio:.2f}")

    plan_status = str(plan.get("status") or "") if isinstance(plan, dict) else ""
    if plan_status and plan_status != "paper_open_ready":
        wait.append("진입계획 아직 대기: " + plan_status)

    trigger_gate = canon.get("trigger_gate") if isinstance(canon.get("trigger_gate"), dict) else _v620_trigger_gate(row, canon)
    # v620: stage가 S1이어도 price가 trigger 아래면 S1_PASS 금지. TON처럼 표시 trigger와 실행 가격이 갈라지는 경로를 차단한다.
    if trigger_gate.get("trigger_price") and trigger_gate.get("current_price") and not bool(trigger_gate.get("trigger_reached")):
        wait.append(str(trigger_gate.get("reason") or "방아쇠 미도달"))

    if bool(timing.get("late_chase_flag")):
        hard.append("늦은 진입 위험")

    if hard:
        state = "BLOCKED"
    elif wait:
        state = "S2_RECHECK"
    elif watch:
        state = "S3_WATCH"
    else:
        state = "S1_PASS"

    reasons = _v602_list(hard, wait, watch, canon.get("decision_reference"), limit=10)
    if state == "S1_PASS" and not reasons:
        reasons = ["전략공장 최종 매수 가능"]
    return {
        "state": state,
        "allowed": state == "S1_PASS",
        "stage": _v602_stage_for_state(state),
        "label": _v602_state_label(state),
        "reasons": reasons,
        "decision_reference": canon.get("decision_reference"),
        "schema": "final_trade_state_v603_strategy_single_source",
    }


def _v602_seal_final_trade_state(row: Dict[str, Any], canon: Optional[Dict[str, Any]] = None) -> Dict[str, Any]:
    if not isinstance(row, dict):
        return row
    rr = dict(row)
    canon = canon if isinstance(canon, dict) else (rr.get("canonical_metric_row") if isinstance(rr.get("canonical_metric_row"), dict) else {})
    if not isinstance(canon, dict):
        canon = {}
    canon = dict(canon)
    trigger_gate = _v620_trigger_gate(rr, canon)
    canon["trigger_gate"] = trigger_gate
    canon["trigger_reached"] = bool(trigger_gate.get("trigger_reached"))
    canon["trigger_gap_pct"] = trigger_gate.get("trigger_gap_pct")
    rr["trigger_gate"] = trigger_gate
    rr["trigger_reached"] = bool(trigger_gate.get("trigger_reached"))
    rr["trigger_gap_pct"] = trigger_gate.get("trigger_gap_pct")
    final = _v602_final_trade_decision(rr, canon)
    state = str(final.get("state") or "")
    allowed = bool(final.get("allowed"))
    final_stage = str(final.get("stage") or _v602_stage_for_state(state))

    canon["schema"] = "strategy_canonical_metric_row_v620_trigger_gate_final_trade_state"
    canon["final_trade_state"] = state
    canon["final_trade_allowed"] = allowed
    canon["final_trade_label"] = final.get("label")
    canon["final_trade_reasons"] = final.get("reasons") or []
    canon["final_decision"] = final.get("label")
    canon["final_decision_schema"] = final.get("schema")
    canon["paper_open_policy"] = "paper OPEN은 final_trade_state == S1_PASS 한 가지만 본다"

    rr["canonical_metric_row"] = canon
    rr["final_trade_state"] = state
    rr["final_trade_allowed"] = allowed
    rr["final_trade_label"] = final.get("label")
    rr["final_trade_reasons"] = final.get("reasons") or []
    rr["final_decision"] = final.get("label")
    rr["final_decision_schema"] = final.get("schema")
    rr["final_trade_state_source"] = "strategy_worker_canonical_metric_row_v603"
    rr["s_stage"] = rr["candidate_stage"] = rr["candidate_grade"] = rr["stage"] = rr["grade"] = final_stage
    rr["open_eligible"] = allowed
    rr["paper_bot_open"] = allowed
    rr["trade_ready"] = allowed
    rr["trade_ready_label"] = final.get("label")
    rr["final_entry_action"] = "paper_open" if allowed else "hold"
    rr["final_entry_label"] = final.get("label")
    rr["final_entry_reasons"] = final.get("reasons") or []
    rr["s1_short_reason"] = " / ".join((final.get("reasons") or [])[:3]) if not allowed else "최종 매수 가능"

    dec = rr.get("canonical_entry_decision") if isinstance(rr.get("canonical_entry_decision"), dict) else {}
    if dec:
        dec = dict(dec)
        dec["raw_s1_allowed_before_final_trade_state"] = bool(dec.get("s1_allowed") or dec.get("gate_pass"))
        dec["final_trade_state"] = state
        dec["final_trade_allowed"] = allowed
        dec["final_trade_label"] = final.get("label")
        dec["final_trade_reasons"] = final.get("reasons") or []
        dec["s1_allowed"] = allowed
        dec["gate_pass"] = allowed
        dec["action"] = "paper_open_candidate" if allowed else ("recheck" if final_stage == "S2" else "observe")
        rr["canonical_entry_decision"] = dec
        rr["common_entry_decision"] = dec
        rr["common_entry_pass"] = allowed

    sf = rr.get("structure_freshness") if isinstance(rr.get("structure_freshness"), dict) else {}
    if sf:
        sf = dict(sf)
        sf["final_trade_state"] = state
        sf["final_trade_label"] = final.get("label")
        sf["final_trade_reasons"] = final.get("reasons") or []
        rr["structure_freshness"] = sf

    ctx = rr.get("entry_context") if isinstance(rr.get("entry_context"), dict) else {}
    ctx = dict(ctx)
    ctx["canonical_metric_row"] = canon
    ctx["final_trade_state"] = state
    ctx["final_trade_allowed"] = allowed
    ctx["final_trade_label"] = final.get("label")
    ctx["final_trade_reasons"] = final.get("reasons") or []
    ctx["final_decision"] = final.get("label")
    ctx["final_decision_schema"] = final.get("schema")
    ctx["trigger_gate"] = trigger_gate
    ctx["trigger_reached"] = bool(trigger_gate.get("trigger_reached"))
    ctx["trigger_gap_pct"] = trigger_gate.get("trigger_gap_pct")
    if dec:
        ctx["canonical_entry_decision"] = dec
        ctx["common_entry_decision"] = dec
    rr["entry_context"] = ctx
    return rr

def _v584_counter_text(rows: List[Dict[str, Any]], path: Tuple[str, ...], limit: int = 5) -> str:
    c: Counter = Counter()
    for r in rows:
        v: Any = r
        for k in path:
            if isinstance(v, dict):
                v = v.get(k)
            else:
                v = None
                break
        if v:
            c[str(v)] += 1
    return ' / '.join(f'{k} {v}' for k, v in c.most_common(limit)) if c else '-'


def _v584_build_candidate_reason_summary(display_rows: List[Dict[str, Any]], counts: Dict[str, int], reason_top: Any, nowv: float) -> Dict[str, Any]:
    base = _v580_build_candidate_reason_summary(display_rows, counts, reason_top, nowv)
    rows = [r for r in display_rows if isinstance(r, dict)]
    title = '🧭 후보판정 이유 /candidate_reason · v584 canonical row 구조'
    lines = str(base.get('summary_text') or '').split('\n')
    if lines and lines[0].startswith('🧭 후보판정 이유'):
        lines[0] = title
    else:
        lines.insert(0, title)
    struct_top = _v584_counter_text(rows, ('canonical_metric_row','structure','state'), 5)
    fresh_top = _v584_counter_text(rows, ('canonical_metric_row','freshness_map','overall'), 5)
    exec_top = _v584_counter_text(rows, ('canonical_metric_row','execution_risk','state'), 5)
    decision_top = _v584_counter_text(rows, ('canonical_metric_row','decision_reference'), 5)
    block = [
        '- 정보 위치: scanner/feature/orderflow는 생산만 · strategy가 canonical row 봉인 · paper/main은 읽기만',
        f'- canonical 구조 TOP: {struct_top}',
        f'- canonical fresh TOP: {fresh_top}',
        f'- canonical 실행위험 TOP: {exec_top}',
        f'- canonical 판정 TOP: {decision_top}',
    ]
    insert_at = 0
    for i, line in enumerate(lines):
        if line.startswith('- fresh 분리:'):
            insert_at = i + 1
            break
    if insert_at:
        lines[insert_at:insert_at] = block
    else:
        lines[2:2] = block
    base['summary_text'] = '\n'.join(lines)
    base['schema'] = 'candidate_reason_summary_text_v584_canonical_metric_row'
    bs = base.get('batch_state') if isinstance(base.get('batch_state'), dict) else {}
    bs.update({'schema': 'candidate_reason_batch_state_v584', 'canonical_structure_top_text': struct_top, 'canonical_fresh_top_text': fresh_top, 'canonical_execution_top_text': exec_top, 'canonical_decision_top_text': decision_top})
    base['batch_state'] = bs
    return base

_v557_build_candidate_reason_summary = _v584_build_candidate_reason_summary



# =============================================================================
# strategy_worker v0.131 / v595: reaction-based structure line refinement
# - 기능 추가가 아니라 구조선 생성/봉인 위치를 strategy_worker 본선으로 고정한다.
# - support/resistance/trigger/invalid가 계산선인지 실제 반응선인지 reason/confidence를 남긴다.
# - S1/S2/S3 체계, paper, main, 청산, 장부는 변경하지 않는다.
# =============================================================================

def _v595_num(row: Dict[str, Any], *keys: str, default: float = 0.0) -> float:
    for k in keys:
        try:
            if isinstance(row, dict) and row.get(k) not in (None, ""):
                return float(str(row.get(k)).replace(',', '').replace('%', ''))
        except Exception:
            continue
    return default


def _v595_has_any(row: Dict[str, Any], *keys: str) -> bool:
    return any(isinstance(row, dict) and row.get(k) not in (None, "", 0, 0.0) for k in keys)


def _v595_list(row: Dict[str, Any], *keys: str) -> List[str]:
    out: List[str] = []
    for k in keys:
        v = row.get(k) if isinstance(row, dict) else None
        if isinstance(v, list):
            out += [str(x) for x in v if x]
        elif v not in (None, ""):
            out.append(str(v))
    return out


def _v595_clip_conf(x: float) -> int:
    try:
        return max(0, min(100, int(round(float(x)))))
    except Exception:
        return 0


def _v595_structure_line_evidence(row: Dict[str, Any], levels: Dict[str, Any]) -> Dict[str, Any]:
    """실제 차트 반응 기반 구조선 근거를 만든다. 없는 값을 0으로 신뢰하지 않는다."""
    price = _v595_num(row, 'current_price', 'entry_price', 'price', default=0.0)
    fam = str(levels.get('strategy_family') or _v554_strategy_family(row))
    tags = _v595_list(row, 'structure_tags', 'matched_strategy_labels', 'entry_structure_tags')
    risks = _v595_list(row, 'risk_tags', 'execution_risk_tags', 'structure_risk_tags')
    react = _v595_num(row, 'price_reaction_pct', default=0.0)
    buy = _v595_num(row, 'buy_ratio', default=0.0)
    sustain = _v595_num(row, 'buy_sustain_1m', default=0.0)
    spread = _v595_num(row, 'spread_pct', default=0.0)
    slip = _v595_num(row, 'slippage_pct', 'spread_pct', default=spread)
    ch1 = _v595_num(row, 'change_1m_pct', 'change_1m', default=0.0)
    ch3 = _v595_num(row, 'change_3m_pct', 'change_3m', default=0.0)
    high_gap = _v595_num(row, 'recent_high_gap_pct', 'below_high_pct', 'high_gap_pct', default=0.0)
    low_rebound = _v595_num(row, 'recent_low_rebound_pct', 'low_rebound_pct', default=0.0)
    vwap_gap = _v595_num(row, 'vwap_gap_pct', 'vwap_pos_pct', 'vwap_position_pct', default=999999.0)
    ema_gap = _v595_num(row, 'ema5_gap_pct', 'ema5_pos_pct', 'ma5_gap_pct', default=999999.0)
    upper_wick = _v595_num(row, 'upper_wick_pct', 'upper_shadow_pct', 'long_upper_wick_pct', default=0.0)
    lower_wick = _v595_num(row, 'lower_wick_pct', 'lower_shadow_pct', 'long_lower_wick_pct', default=0.0)
    vol_exp = _v595_num(row, 'volume_expansion_pct', 'volume_change_pct', 'trade_value_change_pct', default=0.0)
    sell_wall = any(('매도벽' in x or '매도압력' in x) for x in risks)
    fake_or_fail = any(('가짜돌파' in x or '방어실패' in x or '재이탈' in x or '윗꼬리' in x) for x in risks + tags)
    late = bool(row.get('late_chase_flag') or ch1 >= 1.8 or ch3 >= 3.2 or react >= 1.8 or any('늦은추격' in x for x in risks))

    support_reasons: List[str] = []
    resistance_reasons: List[str] = []
    trigger_reasons: List[str] = []
    invalid_reasons: List[str] = []
    risk_tags: List[str] = []
    missing: List[str] = []

    support_conf = 0.0
    resistance_conf = 0.0

    if low_rebound > 0.12 or _v595_has_any(row, 'recent_low_price', 'swing_low_price', 'box_low_price'):
        support_conf += 30; support_reasons.append('최근 저점/박스하단 반응')
    else:
        missing.append('swing_low')
    if abs(vwap_gap) <= 0.35 or abs(ema_gap) <= 0.35:
        support_conf += 25; support_reasons.append('VWAP/EMA 근접 겹침')
    elif vwap_gap < -0.20 and ema_gap < -0.20:
        risk_tags.append('VWAP/EMA 하단 구조')
    if lower_wick >= 0.20 or any('쓸림' in x or '저점' in x for x in tags):
        support_conf += 15; support_reasons.append('아랫꼬리/쓸림 후 회복 근거')
    if react > 0.20 and buy >= 0.65:
        support_conf += 15; support_reasons.append('반응+매수체결 동반')
    if spread <= 0.18 and slip <= 0.18:
        support_conf += 10; support_reasons.append('실행위험 정상권')

    if high_gap < -0.05 or _v595_has_any(row, 'recent_high_price', 'swing_high_price', 'box_high_price'):
        resistance_conf += 35; resistance_reasons.append('직전 고점/박스상단 근거')
    else:
        missing.append('swing_high')
    if upper_wick >= 0.20:
        resistance_conf += 15; resistance_reasons.append('윗꼬리 저항 흔적')
        risk_tags.append('윗꼬리 저항 주의')
    if sell_wall:
        resistance_conf += 15; resistance_reasons.append('매도벽/매도압력 구간')
    if vol_exp > 0.0:
        resistance_conf += 10; resistance_reasons.append('거래량/거래대금 반응')

    # 방아쇠는 저항선 근거 + 진입 확인신호가 같이 있어야 신뢰한다.
    trigger_conf = resistance_conf * 0.55
    if react >= 0.35:
        trigger_conf += 15; trigger_reasons.append(f'가격반응 {react:+.2f}%')
    if buy >= 0.70:
        trigger_conf += 12; trigger_reasons.append(f'매수체결 {buy:.2f}')
    if sustain >= 0.70:
        trigger_conf += 12; trigger_reasons.append(f'1분지속 {sustain:.2f}')
    if spread <= 0.18 and slip <= 0.18:
        trigger_conf += 10; trigger_reasons.append(f'스프레드/미끄러짐 정상 {spread:.2f}/{slip:.2f}%')
    if fake_or_fail:
        trigger_conf -= 30; risk_tags.append('가짜돌파/방어실패 위험')
    if late:
        trigger_conf -= 25; risk_tags.append('늦은추격 구조위험')
    if fam == 'hot_rank':
        trigger_conf -= 10; risk_tags.append('hot-rank는 발견신호')
    if fam == 'sweep_vwap' and support_conf < 55:
        trigger_conf -= 15; risk_tags.append('저점 VWAP 회복 지지근거 약함')

    invalid_conf = support_conf * 0.75
    if support_conf >= 55:
        invalid_reasons.append('지지선 재이탈 기준')
    if vwap_gap > -0.10 or ema_gap > -0.10:
        invalid_reasons.append('VWAP/EMA 방어 실패 기준')
    if not invalid_reasons:
        invalid_reasons.append('구조 무효 근거 부족')
        risk_tags.append('무효선 계산선 의심')

    support_conf_i = _v595_clip_conf(support_conf)
    resistance_conf_i = _v595_clip_conf(resistance_conf)
    trigger_conf_i = _v595_clip_conf(trigger_conf)
    invalid_conf_i = _v595_clip_conf(invalid_conf)

    if trigger_conf_i >= 70 and support_conf_i >= 55 and not fake_or_fail:
        quality = 'reactive_line_confirmed'
    elif trigger_conf_i >= 50 and support_conf_i >= 40:
        quality = 'reactive_line_watch'
    else:
        quality = 'calculated_line_recheck'
        risk_tags.append('구조선 근거 재확인')

    return {
        'schema': 'structure_line_evidence_v595',
        'quality': quality,
        'support_confidence': support_conf_i,
        'resistance_confidence': resistance_conf_i,
        'trigger_confidence': trigger_conf_i,
        'invalid_confidence': invalid_conf_i,
        'support_reason': ' / '.join(support_reasons[:5]) or '실제 반응선 근거 부족',
        'resistance_reason': ' / '.join(resistance_reasons[:5]) or '실제 저항 근거 부족',
        'trigger_reason': ' / '.join(trigger_reasons[:6]) or '방아쇠 확인신호 부족',
        'invalid_reason': ' / '.join(invalid_reasons[:4]),
        'line_risk_tags': _v510_uniq(risk_tags, 8),
        'missing_structure_inputs': _v510_uniq(missing, 6),
        'basis': {'family': fam, 'price': price, 'react': round(react,3), 'buy': round(buy,3), 'sustain': round(sustain,3), 'spread': round(spread,3), 'slippage': round(slip,3), 'vwap_gap': round(vwap_gap if vwap_gap < 900000 else 0,3), 'ema_gap': round(ema_gap if ema_gap < 900000 else 0,3), 'high_gap': round(high_gap,3), 'low_rebound': round(low_rebound,3), 'late_chase': late},
    }


_v595_base_build_structure_levels = _v554_build_structure_levels

def _v554_build_structure_levels(row: Dict[str, Any]) -> Dict[str, Any]:  # type: ignore[override]
    levels = _v595_base_build_structure_levels(row)
    if not isinstance(levels, dict) or not levels.get('available'):
        return levels
    ev = _v595_structure_line_evidence(row, levels)
    levels = dict(levels)
    levels['schema'] = 'structure_levels_v595_reactive_lines'
    levels['line_policy'] = '실제 차트 반응선 우선. 계산선은 recheck로 표시하고 기능/청산은 변경하지 않는다.'
    levels['structure_line_evidence'] = ev
    levels['structure_line_quality'] = ev['quality']
    levels['support_reason'] = ev['support_reason']
    levels['resistance_reason'] = ev['resistance_reason']
    levels['trigger_reason'] = ev['trigger_reason'] if ev['trigger_reason'] != '방아쇠 확인신호 부족' else levels.get('trigger_reason') or ev['trigger_reason']
    levels['invalid_reason'] = ev['invalid_reason']
    levels['support_confidence'] = ev['support_confidence']
    levels['resistance_confidence'] = ev['resistance_confidence']
    levels['trigger_confidence'] = ev['trigger_confidence']
    levels['invalid_confidence'] = ev['invalid_confidence']
    levels['line_risk_tags'] = ev['line_risk_tags']
    levels['missing_structure_inputs'] = ev['missing_structure_inputs']
    # 목표/손익비 수치는 기존 값 유지. 단, 근거 문자열만 실제 반응선 근거로 보강한다.
    levels['target_reason'] = (levels.get('target_reason') or '') + ' / v595: 저항선·방아쇠 신뢰도 참고'
    return levels


def _v595_apply_structure_line_gate(row: Dict[str, Any]) -> Dict[str, Any]:
    r = dict(row)
    levels = r.get('structure_levels') if isinstance(r.get('structure_levels'), dict) else {}
    ev = levels.get('structure_line_evidence') if isinstance(levels.get('structure_line_evidence'), dict) else {}
    quality = str(levels.get('structure_line_quality') or ev.get('quality') or '')
    trig_conf = _v510_num(levels.get('trigger_confidence'), ev.get('trigger_confidence'), default=0.0)
    support_conf = _v510_num(levels.get('support_confidence'), ev.get('support_confidence'), default=0.0)
    line_risks = [str(x) for x in (levels.get('line_risk_tags') or ev.get('line_risk_tags') or [])]
    severe = any(('가짜돌파' in x or '방어실패' in x or '늦은추격' in x or '지지근거 약함' in x) for x in line_risks)
    needs_recheck = quality == 'calculated_line_recheck' or trig_conf < 45 or support_conf < 35 or severe
    r['structure_line_quality'] = quality
    r['structure_line_confidence'] = {'trigger': trig_conf, 'support': support_conf, 'quality': quality}
    r['structure_line_risk_tags'] = line_risks
    if line_risks:
        r['structure_risk_tags'] = _v510_uniq(list(r.get('structure_risk_tags') or []) + line_risks, 12)
        r['risk_tags'] = _v510_uniq(list(r.get('risk_tags') or []) + line_risks, 12)
    if _v510_stage(r) == 'S1' and needs_recheck:
        r['v595_downgraded_from_s1_structure_line'] = True
        r['s_stage'] = r['candidate_stage'] = r['candidate_grade'] = r['stage'] = r['grade'] = 'S2'
        r['open_eligible'] = False
        r['paper_bot_open'] = False
        r['trade_ready'] = False
        reason = f"구조선 재확인: {quality or 'unknown'} / trigger_conf {trig_conf:.0f} / support_conf {support_conf:.0f}"
        r['s_stage_reasons'] = _v510_uniq(list(r.get('s_stage_reasons') or []) + [reason], 14)
        r['s2_recheck_reasons'] = _v510_uniq(list(r.get('s2_recheck_reasons') or []) + [reason], 12)
    return r


_v595_base_attach_canonical_metric_rows = _v584_attach_canonical_metric_rows

def _v595_attach_reactive_structure_rows(rows: List[Dict[str, Any]], nowv: float) -> List[Dict[str, Any]]:
    gated = [_v595_apply_structure_line_gate(r) for r in (rows or []) if isinstance(r, dict)]
    out = _v595_base_attach_canonical_metric_rows(gated, nowv)
    for rr in out:
        levels = rr.get('structure_levels') if isinstance(rr.get('structure_levels'), dict) else {}
        ev = levels.get('structure_line_evidence') if isinstance(levels.get('structure_line_evidence'), dict) else {}
        canon = rr.get('canonical_metric_row') if isinstance(rr.get('canonical_metric_row'), dict) else {}
        if isinstance(canon, dict):
            canon['schema'] = 'strategy_canonical_metric_row_v595_reactive_structure_lines'
            struct = canon.get('structure') if isinstance(canon.get('structure'), dict) else {}
            struct['levels'] = levels
            struct['line_evidence'] = ev
            struct['line_quality'] = levels.get('structure_line_quality')
            struct['line_risk_tags'] = levels.get('line_risk_tags') or []
            canon['structure'] = struct
            canon['policy'] = 'v595: 구조선은 실제 반응선 reason/confidence로 봉인. paper/main은 읽기만. 청산/자동매수/장부 변경 없음.'
            rr['canonical_metric_row'] = canon
            ctx = rr.get('entry_context') if isinstance(rr.get('entry_context'), dict) else {}
            ctx = dict(ctx); ctx['canonical_metric_row'] = canon; rr['entry_context'] = ctx
    return out

_v583_attach_structure_freshness = _v595_attach_reactive_structure_rows


_v595_base_build_candidate_reason_summary = _v584_build_candidate_reason_summary

def _v595_counter_text(rows: List[Dict[str, Any]], path: Tuple[str, ...], limit: int = 5) -> str:
    c: Counter = Counter()
    for r in rows:
        v: Any = r
        for k in path:
            if isinstance(v, dict):
                v = v.get(k)
            else:
                v = None; break
        if isinstance(v, list):
            for x in v:
                if x: c[str(x)] += 1
        elif v:
            c[str(v)] += 1
    return ' / '.join(f'{k} {v}' for k, v in c.most_common(limit)) if c else '-'


def _v595_build_candidate_reason_summary(display_rows: List[Dict[str, Any]], counts: Dict[str, int], reason_top: Any, nowv: float) -> Dict[str, Any]:
    base = _v595_base_build_candidate_reason_summary(display_rows, counts, reason_top, nowv)
    rows = [r for r in display_rows if isinstance(r, dict)]
    lines = str(base.get('summary_text') or '').split('\n')
    title = '🧭 후보판정 이유 /candidate_reason · v595 구조선 정교화'
    if lines and lines[0].startswith('🧭 후보판정 이유'):
        lines[0] = title
    else:
        lines.insert(0, title)
    quality_top = _v595_counter_text(rows, ('structure_levels','structure_line_quality'), 5)
    line_risk_top = _v595_counter_text(rows, ('structure_levels','line_risk_tags'), 5)
    trigger_conf_values = []
    for r in rows:
        levels = r.get('structure_levels') if isinstance(r.get('structure_levels'), dict) else {}
        tv = _v510_num(levels.get('trigger_confidence'), default=-1)
        if tv >= 0: trigger_conf_values.append(tv)
    avg_trigger = round(sum(trigger_conf_values)/len(trigger_conf_values), 1) if trigger_conf_values else 0.0
    block = [
        '- 구조선 정책: 실제 반응선 reason/confidence를 strategy canonical row에 봉인',
        f'- 구조선 품질 TOP: {quality_top}',
        f'- 구조선 위험 TOP: {line_risk_top}',
        f'- 방아쇠 신뢰도 평균: {avg_trigger:.1f}',
    ]
    insert_at = 0
    for i, line in enumerate(lines):
        if line.startswith('- 정보 위치:'):
            insert_at = i + 1
            break
    if insert_at:
        lines[insert_at:insert_at] = block
    else:
        lines[2:2] = block
    base['summary_text'] = '\n'.join(lines)
    base['schema'] = 'candidate_reason_summary_text_v595_reactive_structure_lines'
    bs = base.get('batch_state') if isinstance(base.get('batch_state'), dict) else {}
    bs.update({'schema': 'candidate_reason_batch_state_v595', 'structure_line_quality_top_text': quality_top, 'structure_line_risk_top_text': line_risk_top, 'trigger_confidence_avg': avg_trigger})
    base['batch_state'] = bs
    return base

_v557_build_candidate_reason_summary = _v595_build_candidate_reason_summary


# =============================================================================
# strategy_worker v0.132 / v596: official API structure-input spine
# - candle/feature worker가 빗썸 공식 캔들 OHLCV에서 생산한 swing/box/wick/VWAP/EMA 정보를 우선 사용한다.
# - strategy_worker는 API 직접 호출 금지. 공식 데이터 cache만 읽고 canonical row에 봉인한다.
# - S1/S2/S3 수치 조건, 청산, paper, 장부는 변경하지 않는다.
# =============================================================================

def _v596_num_known(row: Dict[str, Any], *keys: str) -> Tuple[Optional[float], bool]:
    for k in keys:
        try:
            if isinstance(row, dict) and row.get(k) not in (None, ""):
                return float(str(row.get(k)).replace(',', '').replace('%', '')), True
        except Exception:
            continue
    return None, False


def _v596_official_structure_inputs(row: Dict[str, Any]) -> Dict[str, Any]:
    """feature_worker가 공식 캔들 API 기반으로 넘긴 구조선 재료를 표준화한다."""
    keys = [
        'official_candle_source','official_candle_age','official_candle_intervals',
        'swing_high_price','swing_low_price','box_high_price','box_low_price',
        'recent_high_price','recent_low_price','support_touch_count','resistance_touch_count',
        'upper_wick_pct','lower_wick_pct','vwap_gap_pct','ema5_gap_pct','ema10_gap_pct','ema20_gap_pct',
        'volume_ratio','volume_expansion_pct','breakout_hint','sweep_reclaim_hint','box_breakout_hint',
        'support_reclaim_hint','resistance_reject_hint','pullback_volume_contract','reclaim_volume_expand'
    ]
    out={k:row.get(k) for k in keys if isinstance(row,dict) and row.get(k) not in (None,'')}
    present=[k for k in keys if isinstance(row,dict) and row.get(k) not in (None,'')]
    missing=[]
    for k in ('swing_high_price','swing_low_price','box_high_price','box_low_price','upper_wick_pct','lower_wick_pct','vwap_gap_pct','ema5_gap_pct','volume_ratio'):
        if k not in present:
            missing.append(k)
    out['present_count']=len(present)
    out['missing_core']=missing[:12]
    out['source_policy']='v596: 공식 API OHLCV 구조 재료는 feature_worker 생산, strategy_worker 봉인만 수행'
    return out


_v596_prev_structure_line_evidence = _v595_structure_line_evidence

def _v595_structure_line_evidence(row: Dict[str, Any], levels: Dict[str, Any]) -> Dict[str, Any]:  # type: ignore[override]
    ev = _v596_prev_structure_line_evidence(row, levels)
    if not isinstance(ev, dict):
        ev={}
    official = _v596_official_structure_inputs(row)
    risk_tags=list(ev.get('line_risk_tags') or [])
    missing=list(ev.get('missing_structure_inputs') or [])
    support_reason=str(ev.get('support_reason') or '')
    resistance_reason=str(ev.get('resistance_reason') or '')
    trigger_reason=str(ev.get('trigger_reason') or '')
    support_conf=float(ev.get('support_confidence') or 0)
    resistance_conf=float(ev.get('resistance_confidence') or 0)
    trigger_conf=float(ev.get('trigger_confidence') or 0)

    support_touch, support_touch_ok = _v596_num_known(row,'support_touch_count')
    resist_touch, resist_touch_ok = _v596_num_known(row,'resistance_touch_count')
    swing_low, swing_low_ok = _v596_num_known(row,'swing_low_price','recent_low_price','box_low_price')
    swing_high, swing_high_ok = _v596_num_known(row,'swing_high_price','recent_high_price','box_high_price')
    vwap_gap, vwap_ok = _v596_num_known(row,'vwap_gap_pct')
    ema5_gap, ema5_ok = _v596_num_known(row,'ema5_gap_pct')
    upper, upper_ok = _v596_num_known(row,'upper_wick_pct')
    lower, lower_ok = _v596_num_known(row,'lower_wick_pct')
    vol_ratio, vol_ok = _v596_num_known(row,'volume_ratio')
    official_age, official_age_ok = _v596_num_known(row,'official_candle_age','candle_age_sec')

    add_support=[]; add_resist=[]; add_trigger=[]
    if support_touch_ok and support_touch >= 2:
        support_conf += 18; add_support.append(f'공식캔들 지지반응 {int(support_touch)}회')
    if swing_low_ok:
        support_conf += 10; add_support.append('공식 swing low/box low 존재')
    if vwap_ok and abs(vwap_gap or 0) <= 0.35:
        support_conf += 10; add_support.append('공식 VWAP 근접')
    if ema5_ok and abs(ema5_gap or 0) <= 0.35:
        support_conf += 8; add_support.append('공식 EMA5 근접')
    if lower_ok and lower >= 35:
        support_conf += 10; add_support.append('공식 아랫꼬리 회복')
    if bool(row.get('support_reclaim_hint') or row.get('sweep_reclaim_hint')):
        support_conf += 12; add_support.append('쓸림/지지 회복 힌트')

    if resist_touch_ok and resist_touch >= 2:
        resistance_conf += 18; add_resist.append(f'공식캔들 저항반응 {int(resist_touch)}회')
    if swing_high_ok:
        resistance_conf += 10; add_resist.append('공식 swing high/box high 존재')
    if upper_ok and upper >= 35:
        resistance_conf += 8; add_resist.append('공식 윗꼬리 저항')
    if bool(row.get('resistance_reject_hint')):
        resistance_conf += 10; add_resist.append('저항 거절 힌트')
    if vol_ok and vol_ratio >= 1.15:
        resistance_conf += 7; add_resist.append(f'공식 거래량반응 {vol_ratio:.2f}x')

    if bool(row.get('box_breakout_hint') or row.get('breakout_hint')) and swing_high_ok:
        trigger_conf += 15; add_trigger.append('공식 박스/직전고점 돌파 힌트')
    if bool(row.get('reclaim_volume_expand')):
        trigger_conf += 10; add_trigger.append('회복 거래량 재증가')
    if official_age_ok and official_age > 45:
        risk_tags.append(f'공식캔들 stale {official_age:.0f}s')
    if official.get('present_count',0) < 6:
        risk_tags.append('공식구조재료 부족')
    for m in official.get('missing_core') or []:
        if m not in missing:
            missing.append(m)

    support_conf_i=_v595_clip_conf(support_conf)
    resistance_conf_i=_v595_clip_conf(resistance_conf)
    trigger_conf_i=_v595_clip_conf(trigger_conf)
    severe = any(('가짜돌파' in x or '방어실패' in x or '늦은추격' in x or 'stale' in x) for x in risk_tags)
    if trigger_conf_i >= 72 and support_conf_i >= 60 and not severe:
        quality='official_reactive_line_confirmed'
    elif trigger_conf_i >= 52 and support_conf_i >= 42:
        quality='official_reactive_line_watch'
    else:
        quality=ev.get('quality') or 'calculated_line_recheck'

    ev.update({
        'schema':'structure_line_evidence_v596_official_api_inputs',
        'quality':quality,
        'support_confidence':support_conf_i,
        'resistance_confidence':resistance_conf_i,
        'trigger_confidence':trigger_conf_i,
        'support_reason':' / '.join([x for x in [support_reason]+add_support if x and x!='실제 반응선 근거 부족'][:7]) or '실제 반응선 근거 부족',
        'resistance_reason':' / '.join([x for x in [resistance_reason]+add_resist if x and x!='실제 저항 근거 부족'][:7]) or '실제 저항 근거 부족',
        'trigger_reason':' / '.join([x for x in [trigger_reason]+add_trigger if x and x!='방아쇠 확인신호 부족'][:8]) or '방아쇠 확인신호 부족',
        'line_risk_tags':_v510_uniq(risk_tags,10),
        'missing_structure_inputs':_v510_uniq(missing,12),
        'official_structure_inputs':official,
    })
    basis=ev.get('basis') if isinstance(ev.get('basis'),dict) else {}
    basis.update({'official_present':official.get('present_count'), 'official_age':official.get('official_candle_age'), 'support_touch':support_touch if support_touch_ok else None, 'resistance_touch':resist_touch if resist_touch_ok else None})
    ev['basis']=basis
    return ev


_v596_prev_attach_reactive_structure_rows = _v583_attach_structure_freshness

def _v596_attach_official_structure_rows(rows: List[Dict[str, Any]], nowv: float) -> List[Dict[str, Any]]:
    out = _v596_prev_attach_reactive_structure_rows(rows, nowv)
    # v603: 공식 candle/구조선 evidence를 붙인 뒤 final_trade_state를 다시 봉인하고,
    #       그 결과를 반드시 out[index]에 되돌려 넣는다.
    #       v602는 rr 로컬 변수만 재할당될 수 있어 paper row가 공식 candle 반영 전 판정으로 남을 수 있었다.
    for idx, rr0 in enumerate(out):
        if not isinstance(rr0, dict):
            continue
        rr = dict(rr0)
        levels=rr.get('structure_levels') if isinstance(rr.get('structure_levels'),dict) else {}
        ev=levels.get('structure_line_evidence') if isinstance(levels.get('structure_line_evidence'),dict) else {}
        canon=rr.get('canonical_metric_row') if isinstance(rr.get('canonical_metric_row'),dict) else {}
        if isinstance(canon,dict):
            canon=dict(canon)
            canon['schema']='strategy_canonical_metric_row_v603_official_structure_final_trade_state'
            struct=canon.get('structure') if isinstance(canon.get('structure'),dict) else {}
            struct=dict(struct)
            struct['official_structure_inputs']=ev.get('official_structure_inputs') or _v596_official_structure_inputs(rr)
            struct['line_evidence']=ev
            struct['line_quality']=levels.get('structure_line_quality') or ev.get('quality')
            canon['structure']=struct
            canon['policy']='v603: 공식 API 구조재료 반영 후 final_trade_state를 다시 봉인하고 paper/main은 그 값만 읽는다.'
            rr['canonical_metric_row']=canon
            rr = _v602_seal_final_trade_state(rr, canon)
            canon = rr.get('canonical_metric_row') if isinstance(rr.get('canonical_metric_row'), dict) else canon
            ctx=rr.get('entry_context') if isinstance(rr.get('entry_context'),dict) else {}
            ctx=dict(ctx); ctx['canonical_metric_row']=canon; ctx['final_trade_state']=rr.get('final_trade_state'); ctx['final_trade_label']=rr.get('final_trade_label'); ctx['final_trade_reasons']=rr.get('final_trade_reasons'); ctx['final_trade_allowed']=rr.get('final_trade_allowed'); rr['entry_context']=ctx
            rr['v603_official_final_state_resealed'] = True
            out[idx] = rr
    return out

_v583_attach_structure_freshness = _v596_attach_official_structure_rows


_v596_prev_build_candidate_reason_summary = _v557_build_candidate_reason_summary

def _v596_build_candidate_reason_summary(display_rows: List[Dict[str, Any]], counts: Dict[str,int], reason_top: Any, nowv: float) -> Dict[str,Any]:
    base=_v596_prev_build_candidate_reason_summary(display_rows, counts, reason_top, nowv)
    rows=[r for r in display_rows if isinstance(r,dict)]
    lines=str(base.get('summary_text') or '').split('\n')
    title='🧭 후보판정 이유 /candidate_reason · v596 공식API 구조선 재료'
    if lines and lines[0].startswith('🧭 후보판정 이유'):
        lines[0]=title
    else:
        lines.insert(0,title)
    official_ok=0; official_missing=0; ages=[]
    for r in rows:
        official=_v596_official_structure_inputs(r)
        if official.get('present_count',0) >= 6: official_ok+=1
        else: official_missing+=1
        try:
            if official.get('official_candle_age') not in (None,''):
                ages.append(float(official.get('official_candle_age')))
        except Exception: pass
    avg_age=round(sum(ages)/len(ages),1) if ages else 0.0
    block=[
        '- 공식API 구조재료: candle_worker/feature_worker가 OHLCV·swing·box·wick·VWAP/EMA 생산, strategy가 봉인',
        f'- 공식 구조재료 충분/부족: {official_ok}/{official_missing}',
        f'- 공식 candle age 평균: {avg_age:.1f}s' if ages else '- 공식 candle age 평균: -',
    ]
    insert_at=0
    for i,line in enumerate(lines):
        if line.startswith('- 구조선 정책:'):
            insert_at=i+1; break
    if insert_at:
        lines[insert_at:insert_at]=block
    else:
        lines[2:2]=block
    base['summary_text']='\n'.join(lines)
    base['schema']='candidate_reason_summary_text_v596_official_structure_inputs'
    bs=base.get('batch_state') if isinstance(base.get('batch_state'),dict) else {}
    bs.update({'schema':'candidate_reason_batch_state_v596','official_structure_ok':official_ok,'official_structure_missing':official_missing,'official_candle_age_avg':avg_age})
    base['batch_state']=bs
    return base

_v557_build_candidate_reason_summary = _v596_build_candidate_reason_summary


# v598: candidate_reason label/diagnostics for official candle evidence propagation runtime-fix.
_v597_prev_build_candidate_reason_summary = _v557_build_candidate_reason_summary

def _v597_build_candidate_reason_summary(display_rows: List[Dict[str, Any]], counts: Dict[str,int], reason_top: Any, nowv: float) -> Dict[str,Any]:
    base = _v597_prev_build_candidate_reason_summary(display_rows, counts, reason_top, nowv)
    lines = str(base.get('summary_text') or '').split('\n')
    title = '🧭 후보판정 이유 /candidate_reason · v598 공식API 구조재료 배관복구'
    if lines and lines[0].startswith('🧭 후보판정 이유'):
        lines[0] = title
    else:
        lines.insert(0, title)
    # Replace/add one concise line so we can distinguish v596 logic from the v597 propagation fix.
    diag = '- v598 배관복구: _v510_make_row UnboundLocalError 제거, candle_worker cache → strategy canonical row 보존. API 직접조회 없음.'
    if diag not in lines:
        insert_at = 0
        for i, line in enumerate(lines):
            if line.startswith('- 공식API 구조재료:'):
                insert_at = i + 1
                break
        if insert_at:
            lines.insert(insert_at, diag)
        else:
            lines.insert(2, diag)
    base['summary_text'] = '\n'.join(lines)
    bs = base.get('batch_state') if isinstance(base.get('batch_state'), dict) else {}
    bs['schema'] = 'candidate_reason_batch_state_v598'
    bs['official_structure_pipe'] = 'candle_worker_cache_to_strategy_canonical_row'
    base['batch_state'] = bs
    base['schema'] = 'candidate_reason_summary_text_v598_official_structure_pipe'
    return base

_v557_build_candidate_reason_summary = _v597_build_candidate_reason_summary


# v599: keep strategy->paper handoff/status fresh even when late summary/post-processing is slow.
# This is not a strategy-condition change.  It republishes the already-produced
# paper_candidates_latest into the handoff/status spine so paper/main do not keep
# reading a stale v0.132 handoff while candidate_reason has a newer compact cache.
def _v599_publish_handoff_from_latest(note: str = "cycle") -> None:
    nowv = now_ts()
    rows = read_jsonl(PAPER_LATEST, max_lines=2000)
    counts: Dict[str, int] = {"S1": 0, "S2": 0, "S3": 0}
    lane_counts: Dict[str, int] = {}
    price_ready_count = 0
    for r in rows:
        if not isinstance(r, dict):
            continue
        st = _v510_stage(r)
        counts[st] = counts.get(st, 0) + 1
        lane = str(r.get("canonical_lane") or "base")
        lane_counts[lane] = lane_counts.get(lane, 0) + 1
        if _v510_num(r.get("current_price"), r.get("entry_price"), r.get("price"), default=0.0) > 0:
            price_ready_count += 1
    obj = {
        "schema": "paper_handoff_status_v599_strategy_fresh_republish",
        "version": VERSION,
        "updated_ts": nowv,
        "updated_text": now_text(nowv),
        "latest_count": len(rows),
        "stage_counts": counts,
        "lane_counts": lane_counts,
        "price_ready_count": price_ready_count,
        "source": "paper_candidates_latest",
        "republish_note": note,
        "source_policy": "v599: candidate rows are produced by strategy_worker; this only republishes the already-produced latest rows into the handoff/status spine. No condition, grade, exit, paper or ledger change.",
    }
    save_json(HANDOFF, obj)
    # Health uses the worker status file for version/age. Do not erase real cycle metrics.
    # v599 used target_count=0/last_sec=0 here, so guard looked normal while strategy timing/targets
    # were hidden. v655 republishes handoff but preserves the cycle metrics from _v510_publish.
    prev_status = load_json(STATUS, {}) or {}
    pr = load_json(PRIORITY_REQ, {}) or {}
    write_status(
        "running",
        phase="cycle_done_v655_handoff_republish",
        phase_note="v655 handoff republish without metric wipe",
        strategy_worker_version=VERSION,
        main_version=MAIN_VERSION,
        deploy_version=MAIN_DEPLOY_VERSION,
        evaluated=len(rows),
        row_count=len(rows),
        s_count=len(rows),
        paper_latest_count=len(rows),
        s1_count=counts.get("S1", 0),
        s2_count=counts.get("S2", 0),
        s3_count=counts.get("S3", 0),
        target_count=(len(pr.get("targets") or []) if isinstance(pr, dict) and isinstance(pr.get("targets"), list) else int(_v510_num(prev_status.get("target_count"), default=0.0))),
        priority_request_count=int(_v510_num(pr.get("request_count"), prev_status.get("priority_request_count"), default=0.0)) if isinstance(pr, dict) else int(_v510_num(prev_status.get("priority_request_count"), default=0.0)),
        last_sec=_v510_num(prev_status.get("last_sec"), default=0.0),
        v655_recheck_lane_counts=(load_json(SUMMARY, {}) or {}).get("v655_recheck_lane_counts", {}),
        status_route_schema="strategy_status_v655_handoff_fresh_republish_metric_keep",
    )

_v599_prev_run_once = run_once

def run_once() -> Any:  # type: ignore[override]
    # v679: remove old finally republish path. _v510_publish is now the single
    # strategy->paper handoff/status owner. Re-reading paper_candidates_latest and
    # rewriting HANDOFF/STATUS after every cycle made strategy_worker look fresh
    # while hiding true cycle timing and added duplicate I/O under high CPU.
    return _v599_prev_run_once()

_v599_prev_build_candidate_reason_summary = _v557_build_candidate_reason_summary

def _v599_build_candidate_reason_summary(display_rows: List[Dict[str, Any]], counts: Dict[str,int], reason_top: Any, nowv: float) -> Dict[str,Any]:
    base = _v599_prev_build_candidate_reason_summary(display_rows, counts, reason_top, nowv)
    lines = str(base.get('summary_text') or '').split('\n')
    title = '🧭 후보판정 이유 /candidate_reason · v599 공식구조재료 fresh·handoff 배관'
    if lines and lines[0].startswith('🧭 후보판정 이유'):
        lines[0] = title
    else:
        lines.insert(0, title)
    diag = '- v599 배관: candle target 우선순위 + strategy handoff/status 최신 republish. 조건/S등급/청산 변경 없음.'
    if diag not in lines:
        insert_at = 0
        for i, line in enumerate(lines):
            if line.startswith('- v598 배관복구:'):
                insert_at = i + 1
                break
        lines.insert(insert_at if insert_at else min(3, len(lines)), diag)
    base['summary_text'] = '\n'.join(lines)
    bs = base.get('batch_state') if isinstance(base.get('batch_state'), dict) else {}
    bs['schema'] = 'candidate_reason_batch_state_v599'
    bs['handoff_fresh_republish'] = True
    base['batch_state'] = bs
    base['schema'] = 'candidate_reason_summary_text_v599_official_structure_fresh_handoff'
    return base

_v557_build_candidate_reason_summary = _v599_build_candidate_reason_summary


# =============================================================================

# =============================================================================
# strategy_worker v0.140 / v604: candidate_reason text cache + candle priority handoff clarity
# - 기본 명령은 큰 compact JSON을 파싱하지 않고 text cache만 읽는다.
# - S1/S2 캔들 fresh 요청은 clean_strategy_priority_requests에 명확히 남긴다.
# - 조건/S등급/청산/BUY_READY 변경 없음.
# =============================================================================

# strategy_worker v0.139 / v603: final_trade_state + candle fresh priority
# - 조건/S등급/청산 변경 없음.
# - candle_worker_v0.7의 실제 갱신량/age를 기본 candidate_reason에 짧게 표시한다.
# - v600에서 main() 뒤에 붙어 실행되지 않던 진단 override를 main 이전으로 고정한다.
# =============================================================================

def _v601_candle_priority_status() -> Dict[str, Any]:
    obj = load_json(CANDLE, {}) or {}
    st = load_json(BASE_DIR / "clean_candle_status.json", {}) or {}
    plan = obj.get("priority_plan") if isinstance(obj, dict) else {}
    if not isinstance(plan, dict):
        plan = {}
    counts = st.get("priority_bucket_counts") if isinstance(st, dict) else None
    if not isinstance(counts, dict):
        counts = plan.get("bucket_counts") if isinstance(plan.get("bucket_counts"), dict) else {}
    top = st.get("priority_top") if isinstance(st, dict) else None
    if not isinstance(top, list):
        top = plan.get("top") if isinstance(plan.get("top"), list) else []
    age_diag = st.get("age_diag") if isinstance(st, dict) and isinstance(st.get("age_diag"), dict) else (obj.get("age_diag") if isinstance(obj, dict) and isinstance(obj.get("age_diag"), dict) else {})
    urgent_result = st.get("urgent_result") if isinstance(st, dict) and isinstance(st.get("urgent_result"), dict) else (obj.get("urgent_result") if isinstance(obj, dict) and isinstance(obj.get("urgent_result"), dict) else (load_json(CANDLE_URGENT_RESULT, {}) or {}))
    urgent_targets = load_json(CANDLE_URGENT_TARGETS, {}) or {}
    return {
        "schema": "candle_priority_diag_v601",
        "candle_worker_version": st.get("version") if isinstance(st, dict) else None,
        "phase": st.get("phase") if isinstance(st, dict) else None,
        "status_age": round(max(0.0, now_ts() - _v510_num(st.get("updated_ts"), default=0.0)), 1) if isinstance(st, dict) and st.get("updated_ts") else None,
        "cache_age": round(max(0.0, now_ts() - _v510_num(obj.get("updated_ts"), default=0.0)), 1) if isinstance(obj, dict) and obj.get("updated_ts") else None,
        "target_count": (obj.get("target_count") if isinstance(obj, dict) else None) or plan.get("target_count"),
        "row_count": obj.get("row_count") if isinstance(obj, dict) else None,
        "updated_batch": obj.get("updated_batch") if isinstance(obj, dict) else None,
        "failed_batch": (obj.get("failed_batch") if isinstance(obj, dict) else None) or (st.get("failed_batch") if isinstance(st, dict) else None),
        "urgent_request_count": urgent_targets.get("request_count") if isinstance(urgent_targets, dict) else None,
        "urgent_bucket_counts": urgent_targets.get("bucket_counts") if isinstance(urgent_targets, dict) else {},
        "urgent_lane_counts": urgent_targets.get("lane_counts") if isinstance(urgent_targets, dict) else {},
        "urgent_result": urgent_result if isinstance(urgent_result, dict) else {},
        "bucket_counts": counts or {},
        "top": top[:8] if isinstance(top, list) else [],
        "age_diag": age_diag,
        "last_sec": st.get("last_sec") if isinstance(st, dict) else None,
        "max_workers": st.get("max_workers") if isinstance(st, dict) else None,
    }

def _v601_bucket_text(counts: Dict[str, Any], limit: int = 5) -> str:
    if not isinstance(counts, dict) or not counts:
        return "-"
    items=[]
    for k,v in counts.items():
        try: items.append((str(k), int(float(v))))
        except Exception: pass
    items.sort(key=lambda x:x[1], reverse=True)
    return " / ".join(f"{k} {v}" for k,v in items[:limit]) if items else "-"

_v601_prev_build_candidate_reason_summary = _v557_build_candidate_reason_summary

def _v601_build_candidate_reason_summary(display_rows: List[Dict[str, Any]], counts: Dict[str,int], reason_top: Any, nowv: float) -> Dict[str,Any]:
    base = _v601_prev_build_candidate_reason_summary(display_rows, counts, reason_top, nowv)
    raw_lines = [x for x in str(base.get('summary_text') or '').split('\n') if x.strip()]
    # Keep only high-value lines in the default command.  Full detail belongs to full/debug commands.
    keep_prefixes = (
        '- 기준:', '- 긴급갱신:', '- 유지이유 TOP:', '- fresh 분리:', '- 정보 위치:',
        '- 구조선 정책:', '- 공식API 구조재료:', '- v598 배관복구:', '- v599 배관:',
        '- 공식 구조재료 충분/부족:', '- 공식 candle age 평균:', '- 구조선 품질 TOP:',
        '- 구조선 위험 TOP:', '- 방아쇠 신뢰도 평균:', '- canonical 구조 TOP:', '- canonical fresh TOP:',
        '- canonical 실행위험 TOP:', '- canonical 판정 TOP:', '- rows ', '- 현재 단계:', '- S1 근접후보:',
        '- S2 현재막힘 TOP:', '- S1 필요조건 TOP:'
    )
    lines=['🧭 후보판정 이유 /candidate_reason · v611 캐시전용·캔들실패사유']
    for ln in raw_lines[1:]:
        if any(ln.startswith(p) for p in keep_prefixes):
            lines.append(ln)
    diag = _v601_candle_priority_status()
    top = diag.get('top') if isinstance(diag.get('top'), list) else []
    top_txt = ' / '.join(str(x.get('ticker')) + ':' + str(x.get('bucket')) + (f" age {x.get('age')}s" if x.get('age') is not None else '') for x in top[:4] if isinstance(x, dict) and x.get('ticker')) or '-'
    age_diag = diag.get('age_diag') if isinstance(diag.get('age_diag'), dict) else {}
    age_txt = f"avg {age_diag.get('avg')}s / <=120s {age_diag.get('under_120')} / >300s {age_diag.get('over_300')} / max {age_diag.get('max')}s" if age_diag else '-'
    block = [
        '- v611 캔들실패사유: core는 1m/3m/5m, near는 1m/3m, watch는 1m만 우선 갱신. 조건/S등급/청산 변경 없음.',
        f"- candle worker: {diag.get('candle_worker_version') or '-'} / phase {diag.get('phase') or '-'} / cache age {diag.get('cache_age') if diag.get('cache_age') is not None else '-'}s / row {diag.get('row_count') or '-'} / target {diag.get('target_count') or '-'} / last {diag.get('last_sec') if diag.get('last_sec') is not None else '-'}s",
        f"- candle age diag: {age_txt}",
        f"- candle urgent: 요청 {diag.get('urgent_request_count') if diag.get('urgent_request_count') is not None else '-'} / 결과요청 {(diag.get('urgent_result') or {}).get('requested_count','-')} / 갱신 {(diag.get('urgent_result') or {}).get('refreshed_count','-')} / 120초이하 {(diag.get('urgent_result') or {}).get('under_target_age_count','-')} / 미회복 {(diag.get('urgent_result') or {}).get('miss_count','-')}",
        f"- candle 실패사유 TOP: {_v601_bucket_text((diag.get('urgent_result') or {}).get('reason_counts') or {})}",
        f"- candle urgent bucket TOP: {_v601_bucket_text(diag.get('urgent_bucket_counts') or {})}",
        f"- candle urgent lane: {_v601_bucket_text(diag.get('urgent_lane_counts') or {})}",
        f"- candle tier 결과: core {(diag.get('urgent_result') or {}).get('lane_result',{}).get('core','-')} / near {(diag.get('urgent_result') or {}).get('lane_result',{}).get('near','-')} / watch {(diag.get('urgent_result') or {}).get('lane_result',{}).get('watch','-')}",
        f"- candle priority bucket TOP: {_v601_bucket_text(diag.get('bucket_counts') or {})}",
        f"- candle priority top: {top_txt}",
        '- 안내: 기본판은 경량화했습니다. 후보별 긴 구조선/계산 상세는 full 계열에서만 봅니다.',
    ]
    # Place v601 block after v599 line if present, otherwise near top.
    insert_at = 4
    for i, line in enumerate(lines):
        if line.startswith('- v599 배관:'):
            insert_at = i + 1
            break
    lines[insert_at:insert_at] = block
    # hard cap to avoid command bloat in default /candidate_reason
    if len(lines) > 42:
        lines = lines[:42] + ['- … 기본판 경량화로 이하 생략. 상세는 full 계열 확인.']
    base['summary_text'] = '\n'.join(lines)
    bs = base.get('batch_state') if isinstance(base.get('batch_state'), dict) else {}
    bs['schema'] = 'candidate_reason_batch_state_v611_reasoned'
    bs['candle_priority_diag'] = diag
    bs['default_summary_light'] = True
    base['batch_state'] = bs
    base['schema'] = 'candidate_reason_summary_text_v611_reasoned_candle_light'
    return base

_v557_build_candidate_reason_summary = _v601_build_candidate_reason_summary

def main() -> None:  # type: ignore[override]
    write_status("running", phase="boot_v611", evaluated=0, s_count=0, target_count=0, last_sec=0, strategy_worker_version=VERSION)
    while True:
        try:
            run_once()
        except KeyboardInterrupt:
            write_status("stopping", strategy_worker_version=VERSION)
            raise
        except Exception as exc:
            append_error(ERROR, "loop_v512", exc)
            write_status("error", error=f"{exc.__class__.__name__}: {exc}", strategy_worker_version=VERSION)
        time.sleep(max(0.5, INTERVAL_SEC))



# =============================================================================
# strategy_worker v0.147 / v612: fresh_wait 원인 분해
# - fresh_wait를 캔들/feature/orderflow/micro/strategy row로 나눠 candidate_reason text cache에 봉인한다.
# - 조건/S등급/청산/자동매수/BUY_READY 변경 없음.
# =============================================================================

def _v612_nested(d: Dict[str, Any], *keys: str, default: Any=None) -> Any:
    cur: Any = d
    for k in keys:
        if not isinstance(cur, dict):
            return default
        cur = cur.get(k)
    return cur if cur is not None else default

def _v612_age_item_state(items: Dict[str, Any], key: str) -> Tuple[str, float, float]:
    it = items.get(key) if isinstance(items, dict) else None
    if not isinstance(it, dict):
        return ('missing', 999999.0, 0.0)
    return (str(it.get('state') or 'missing'), _v510_num(it.get('age_sec'), default=999999.0), _v510_num(it.get('ttl_sec'), default=0.0))

def _v612_is_fresh_wait_row(row: Dict[str, Any]) -> bool:
    stage = _v510_stage(row)
    if stage not in ('S1','S2'):
        return False
    texts: List[str] = []
    for k in ('v575_urgent_action_state','v574_fresh_urgent_reason','final_decision','final_trade_label','final_trade_state','block_reason','s1_block_reason'):
        v = row.get(k)
        if v is not None:
            texts.append(str(v))
    for k in ('final_trade_reasons','s_stage_reasons','missing_info','stale_reasons','risk_tags'):
        v = row.get(k)
        if isinstance(v, list):
            texts.extend(str(x) for x in v[:8])
    fm = _v612_nested(row, 'canonical_metric_row', 'freshness_map', default={})
    if isinstance(fm, dict) and fm.get('overall') not in (None, '', 'fresh_ok'):
        return True
    low = ' '.join(texts).lower()
    return any(x in low for x in ('fresh_wait','fresh','신선','최신정보','오래됨','stale','정보'))

def _v612_fresh_cause_for_row(row: Dict[str, Any], nowv: float) -> Dict[str, Any]:
    t = ticker_norm(row.get('ticker') or row.get('market') or row.get('symbol')) or '-'
    canon = row.get('canonical_metric_row') if isinstance(row.get('canonical_metric_row'), dict) else {}
    fm = canon.get('freshness_map') if isinstance(canon.get('freshness_map'), dict) else (row.get('freshness_map') if isinstance(row.get('freshness_map'), dict) else {})
    items = fm.get('items') if isinstance(fm.get('items'), dict) else {}
    causes: List[str] = []
    detail: List[str] = []

    # 1) 공식 캔들/구조재료 freshness
    official_age = _v510_num(
        _v612_nested(canon, 'structure', 'official_structure_inputs', 'official_candle_age'),
        row.get('official_candle_age'), row.get('candle_age_sec'), default=-1.0)
    if official_age >= 0 and official_age > 120:
        causes.append('candle')
        detail.append(f'캔들 {official_age:.0f}s')

    # 2) feature freshness: 가격반응/VWAP/EMA/1분지속 계열
    st, agev, ttl = _v612_age_item_state(items, 'price_reaction')
    feature_age = _v510_num(row.get('feature_age_sec'), row.get('price_reaction_age_sec'), default=agev)
    if st != 'fresh' or feature_age > max(ttl or 30.0, 30.0):
        causes.append('feature')
        detail.append(f'feature {feature_age:.0f}s')

    # 3) orderflow freshness: 매수체결/매도압력 계열
    st, agev, ttl = _v612_age_item_state(items, 'orderflow')
    order_age = _v510_num(row.get('orderflow_age_sec'), default=agev)
    if st != 'fresh' or order_age > max(ttl or 20.0, 20.0):
        causes.append('orderflow')
        detail.append(f'체결 {order_age:.0f}s')

    # 4) micro freshness: 스프레드/미끄러짐/시세 계열
    micro_bad = False
    st, agev, ttl = _v612_age_item_state(items, 'micro')
    micro_age = _v510_num(row.get('micro_age_sec'), default=agev)
    if st != 'fresh' or micro_age > max(ttl or 20.0, 20.0):
        micro_bad = True
    stq, ageq, ttlq = _v612_age_item_state(items, 'quote')
    quote_age = _v510_num(row.get('quote_age_sec'), default=ageq)
    if stq != 'fresh' or quote_age > max(ttlq or 20.0, 20.0):
        micro_bad = True
    if micro_bad:
        causes.append('micro')
        detail.append(f'micro {micro_age:.0f}s/시세 {quote_age:.0f}s')

    # 5) strategy row freshness: strategy가 봉인한 row 자체가 오래됨
    st, agev, ttl = _v612_age_item_state(items, 'paper_row')
    row_age = _v510_num(row.get('paper_row_age_sec'), default=agev)
    if st != 'fresh' or row_age > max(ttl or 45.0, 45.0):
        causes.append('strategy_row')
        detail.append(f'판단row {row_age:.0f}s')

    if not causes:
        stale = fm.get('stale_fields') if isinstance(fm.get('stale_fields'), list) else []
        if stale:
            causes.append('other')
            detail.extend(str(x) for x in stale[:3])
        elif fm.get('overall') not in (None, '', 'fresh_ok'):
            causes.append('unknown')
            detail.append(str(fm.get('overall')))

    return {'ticker': t, 'stage': _v510_stage(row), 'causes': causes or ['none'], 'detail': detail[:5], 'freshness_overall': fm.get('overall') if isinstance(fm, dict) else '-'}

def _v612_build_fresh_wait_detail(rows: List[Dict[str, Any]], nowv: float) -> Dict[str, Any]:
    targets = [r for r in rows if isinstance(r, dict) and _v612_is_fresh_wait_row(r)]
    counter: Counter = Counter()
    examples: List[Dict[str, Any]] = []
    for r in targets:
        d = _v612_fresh_cause_for_row(r, nowv)
        for c in d.get('causes') or []:
            counter[str(c)] += 1
        examples.append(d)
    return {'schema': 'fresh_wait_detail_v612', 'count': len(targets), 'cause_counts': dict(counter.most_common()), 'examples': examples[:6]}

def _v612_counter_ko(cause_counts: Dict[str, Any]) -> str:
    labels = {'candle':'캔들', 'feature':'가격/VWAP', 'orderflow':'체결', 'micro':'호가/스프레드', 'strategy_row':'판단row', 'other':'기타', 'unknown':'원인미상', 'none':'문제없음'}
    items=[]
    for k,v in cause_counts.items():
        try: n=int(v)
        except Exception: n=0
        if n:
            items.append(f"{labels.get(str(k), str(k))} {n}")
    return ' / '.join(items) if items else '-'

_v612_prev_build_candidate_reason_summary = _v557_build_candidate_reason_summary

def _v612_build_candidate_reason_summary(display_rows: List[Dict[str, Any]], counts: Dict[str,int], reason_top: Any, nowv: float) -> Dict[str,Any]:
    base = _v612_prev_build_candidate_reason_summary(display_rows, counts, reason_top, nowv)
    detail = _v612_build_fresh_wait_detail(display_rows, nowv)
    lines = [x for x in str(base.get('summary_text') or '').split('\n')]
    block = [
        '[fresh_wait 상세 · v612]',
        f"- fresh_wait 후보: {detail.get('count',0)}개",
        f"- 원인 TOP: {_v612_counter_ko(detail.get('cause_counts') if isinstance(detail.get('cause_counts'), dict) else {})}",
    ]
    examples = detail.get('examples') if isinstance(detail.get('examples'), list) else []
    if examples:
        block.append('- 후보별 원인:')
        label = {'candle':'캔들', 'feature':'가격/VWAP', 'orderflow':'체결', 'micro':'호가', 'strategy_row':'판단row', 'other':'기타', 'unknown':'원인미상', 'none':'문제없음'}
        for ex in examples[:5]:
            causes = ','.join(label.get(str(c), str(c)) for c in (ex.get('causes') or []))
            det = ' / '.join(str(x) for x in (ex.get('detail') or [])[:3]) or '-'
            block.append(f"  · {ex.get('ticker','-')}({ex.get('stage','-')}): {causes} · {det}")
    else:
        block.append('- 후보별 원인: -')
    block += [
        '- 용어: 캔들=1/3/5분 차트, 가격/VWAP=feature, 체결=orderflow, 호가=스프레드/미끄러짐, 판단row=strategy 봉인시간',
    ]
    insert_at = 4
    for i, line in enumerate(lines):
        if line.startswith('- fresh 분리:'):
            insert_at = i + 1
            break
    lines[insert_at:insert_at] = block
    base['summary_text'] = '\n'.join(lines)
    bs = base.get('batch_state') if isinstance(base.get('batch_state'), dict) else {}
    bs['fresh_wait_detail'] = detail
    bs['schema'] = 'candidate_reason_batch_state_v612_fresh_wait_detail'
    base['batch_state'] = bs
    base['schema'] = 'candidate_reason_summary_text_v612_fresh_wait_detail'
    return base

_v557_build_candidate_reason_summary = _v612_build_candidate_reason_summary


# =============================================================================
# strategy_worker v0.148 / v613: 체결·호가 fresh_wait 긴급배관
# - fresh_wait 원인이 orderflow/micro인 S2/S1근접 후보를 target_router/micro/WS urgent로 보낸다.
# - 캔들/조건/S등급/청산/paper 장부는 변경하지 않는다.
# - candidate_reason에는 요청→target 포함→micro/orderflow fresh→미회복 사유를 표시한다.
# =============================================================================
ORDERFLOW_MICRO_URGENT_TARGETS = BASE_DIR / "clean_orderflow_micro_urgent_targets.json"
ORDERFLOW_MICRO_URGENT_RESULT = BASE_DIR / "clean_orderflow_micro_urgent_result.json"
ORDERFLOW_MICRO_URGENT_ACK = BASE_DIR / "clean_orderflow_micro_urgent_ack.json"
TARGET_ROUTER_STATE = BASE_DIR / "clean_s2_urgent_refresh_state.json"
TARGET_ROUTER_QUEUE = BASE_DIR / "clean_target_router_queue.json"

def _v613_of_rows_map() -> Dict[str, Dict[str, Any]]:
    return _v521_load_map_with_cache_age(ORDERFLOW, "orderflow")

def _v613_list_targets(obj: Any, key: str = 'targets') -> List[str]:
    try:
        vals = obj.get(key) if isinstance(obj, dict) else []
        if not isinstance(vals, list):
            return []
        return [ticker_norm(x) for x in vals if ticker_norm(x)]
    except Exception:
        return []

def _v613_bool_fresh(row: Dict[str, Any], key: str, age_key: str, ttl: float = 20.0) -> bool:
    if bool(row.get(key)):
        return True
    age = _v510_num(row.get(age_key), default=999999.0)
    return bool(age <= ttl)

def _v613_reasoned_of_micro_state(targets: List[Dict[str, Any]], nowv: float) -> Dict[str, Any]:
    req_targets = [ticker_norm(x.get('ticker')) for x in targets if isinstance(x, dict) and ticker_norm(x.get('ticker'))]
    req_set = set(req_targets)
    ofmap = _v613_of_rows_map()
    micro_urgent = load_json(MICRO_URGENT, {}) or {}
    micro_targets = set(_v613_list_targets(micro_urgent))
    ws_obj = load_json(WS_TARGETS, {}) or {}
    ws_targets = set(_v613_list_targets(ws_obj))
    router_state = load_json(TARGET_ROUTER_STATE, {}) or {}
    router_targets = set(_v613_list_targets(router_state)) | set(_v613_list_targets(router_state, 'micro_targets'))
    router_queue = load_json(TARGET_ROUTER_QUEUE, {}) or {}
    queue_targets = set(_v613_list_targets(router_queue)) | set(_v613_list_targets(router_queue, 'urgent_targets'))
    # v614: target_router가 봉인한 ACK를 우선 읽는다. strategy가 요청 직후 같은 cycle의
    # clean_micro_urgent_targets를 직접 판정하면 router 반영 전 상태를 not_in_micro_urgent로 오판할 수 있다.
    router_ack = load_json(ORDERFLOW_MICRO_URGENT_ACK, {}) or {}
    ack_ts = _v510_num(router_ack.get('updated_ts'), default=0.0) if isinstance(router_ack, dict) else 0.0
    ack_recent = bool(ack_ts > 0 and nowv - ack_ts <= 35.0)
    ack_targets = set(_v613_list_targets(router_ack))
    ack_active_targets = set(_v613_list_targets(router_ack, 'active_targets'))
    ack_micro_targets = set(_v613_list_targets(router_ack, 'micro_targets'))
    ack_micro_urgent_targets = set(_v613_list_targets(router_ack, 'micro_urgent_targets'))
    ack_row_map: Dict[str, Dict[str, Any]] = {}
    if isinstance(router_ack, dict) and isinstance(router_ack.get('rows'), list):
        for ar in router_ack.get('rows') or []:
            if not isinstance(ar, dict):
                continue
            at = ticker_norm(ar.get('ticker'))
            if at:
                ack_row_map[at] = ar
    rows: List[Dict[str, Any]] = []
    reason_counter: Counter = Counter()
    fresh_count = micro_fresh_count = order_fresh_count = quote_fresh_count = 0
    selected_count = 0
    req_ts_map = {ticker_norm(x.get('ticker')): _v510_num(x.get('requested_ts'), x.get('updated_ts'), default=0.0) for x in targets if isinstance(x, dict) and ticker_norm(x.get('ticker'))}
    for t in req_targets:
        of = ofmap.get(t, {}) or {}
        req_ts = req_ts_map.get(t, 0.0)
        ack_row = ack_row_map.get(t, {})
        ack_row_ts = _v510_num(ack_row.get('ack_ts'), ack_row.get('updated_ts'), ack_ts, default=0.0) if isinstance(ack_row, dict) else ack_ts
        ack_req_ts = _v510_num(ack_row.get('request_ts'), default=0.0) if isinstance(ack_row, dict) else 0.0
        ack_has_ticker = bool(t in ack_targets or t in ack_active_targets or t in ack_micro_targets or t in ack_micro_urgent_targets or ack_row)
        # v615: ACK는 전체 최신 여부가 아니라 ticker별 요청을 반영했는지로 본다.
        # 이전에는 다른 ticker의 최신 ACK가 있으면 새 요청 ticker가 not_in_micro_urgent로 오판됐다.
        ack_covers_request = bool(ack_has_ticker and ack_row_ts > 0 and (req_ts <= 0 or ack_row_ts + 0.001 >= req_ts) and (ack_req_ts <= 0 or req_ts <= 0 or ack_req_ts + 0.001 >= req_ts))
        in_router = t in router_targets or t in queue_targets or (ack_covers_request and (t in ack_targets or t in ack_active_targets or bool(ack_row.get('in_active_targets') if isinstance(ack_row, dict) else False)))
        in_micro = t in micro_targets or (ack_covers_request and (t in ack_micro_targets or t in ack_micro_urgent_targets or bool(ack_row.get('in_micro_targets') if isinstance(ack_row, dict) else False) or bool(ack_row.get('in_micro_urgent_targets') if isinstance(ack_row, dict) else False)))
        in_ws = t in ws_targets or (ack_covers_request and (t in ack_active_targets or bool(ack_row.get('in_active_targets') if isinstance(ack_row, dict) else False)))
        ack_pending = bool((not ack_covers_request) or ((not in_router or not in_micro) and (not ack_recent)))
        order_age = _v510_num(of.get('orderflow_age_sec'), of.get('trade_age_sec'), of.get('micro_age_sec'), default=999999.0)
        micro_age = _v510_num(of.get('micro_age_sec'), of.get('trade_age_sec'), default=999999.0)
        quote_age = _v510_num(of.get('quote_age_sec'), of.get('price_age_sec'), default=999999.0)
        order_ok = bool(of.get('orderflow_fresh') or of.get('trade_fresh')) or order_age <= 20.0
        micro_ok = bool(of.get('micro_fresh')) or micro_age <= 20.0
        quote_ok = bool(of.get('quote_fresh') or of.get('ws_fresh')) or quote_age <= 20.0
        if in_router or in_micro or in_ws:
            selected_count += 1
        if order_ok: order_fresh_count += 1
        if micro_ok: micro_fresh_count += 1
        if quote_ok: quote_fresh_count += 1
        fresh_ok = bool(order_ok and micro_ok and quote_ok)
        if fresh_ok:
            fresh_count += 1
            reason = 'ok_fresh'
        elif ack_pending:
            reason = 'router_ack_pending'
        elif not in_router:
            reason = 'not_in_target_router'
        elif not in_micro:
            reason = 'not_in_micro_urgent'
        elif not in_ws:
            reason = 'not_in_ws_targets'
        elif not of:
            reason = 'orderflow_row_missing'
        elif not quote_ok:
            reason = 'quote_stale_or_missing'
        elif not micro_ok:
            reason = 'micro_stale_or_missing'
        elif not order_ok:
            reason = 'orderflow_stale_or_missing'
        else:
            reason = 'unknown_not_fresh'
        reason_counter[reason] += 1
        rows.append({
            'ticker': t,
            'in_router': in_router,
            'in_micro_urgent': in_micro,
            'in_ws_targets': in_ws,
            'orderflow_fresh': order_ok,
            'micro_fresh': micro_ok,
            'quote_fresh': quote_ok,
            'fresh_ok': fresh_ok,
            'orderflow_age_sec': None if order_age >= 999998 else round(order_age, 1),
            'micro_age_sec': None if micro_age >= 999998 else round(micro_age, 1),
            'quote_age_sec': None if quote_age >= 999998 else round(quote_age, 1),
            'reason': reason,
            'router_ack_recent': ack_recent,
            'router_ack_age_sec': None if ack_ts <= 0 else round(max(0.0, nowv - ack_ts), 1),
            'request_ts': req_ts,
            'router_ack_covers_request': ack_covers_request,
            'router_ack_row_age_sec': None if ack_row_ts <= 0 else round(max(0.0, nowv - ack_row_ts), 1),
        })
    obj = {
        'schema': 'orderflow_micro_urgent_result_v619_normal_keepalive_aware',
        'version': VERSION,
        'updated_ts': nowv,
        'updated_text': now_text(nowv),
        'requested_count': len(req_targets),
        'selected_count': selected_count,
        'micro_urgent_count': sum(1 for t in req_targets if t in micro_targets),
        'ws_target_count': sum(1 for t in req_targets if t in ws_targets),
        'orderflow_fresh_count': order_fresh_count,
        'micro_fresh_count': micro_fresh_count,
        'quote_fresh_count': quote_fresh_count,
        'fresh_ok_count': fresh_count,
        'miss_count': max(0, len(req_targets) - fresh_count),
        'reason_counts': dict(reason_counter.most_common()),
        'rows': rows[:80],
        'policy': 'v619: ticker별 ACK + micro urgent 우선 + normal keepalive 기준으로 판정한다. 조건/S등급/청산 변경 없음.',
    }
    save_json(ORDERFLOW_MICRO_URGENT_RESULT, obj)
    return obj

def _v613_build_orderflow_micro_urgent_targets(rows: List[Dict[str, Any]], nowv: float) -> Tuple[List[Dict[str, Any]], Dict[str, Any]]:
    targets: List[Dict[str, Any]] = []
    seen = set()
    cause_counter: Counter = Counter()
    for row in rows or []:
        if not isinstance(row, dict):
            continue
        if _v510_stage(row) not in ('S1', 'S2'):
            continue
        if not _v612_is_fresh_wait_row(row):
            continue
        d = _v612_fresh_cause_for_row(row, nowv)
        causes = set(str(x) for x in (d.get('causes') or []))
        if not ({'orderflow', 'micro'} & causes):
            continue
        t = ticker_norm(row.get('ticker') or row.get('market') or row.get('symbol'))
        if not t or t in seen:
            continue
        seen.add(t)
        for c in causes:
            cause_counter[c] += 1
        stage = _v510_stage(row)
        pri = 990.0 if stage == 'S1' else 960.0
        if 'micro' in causes: pri += 15.0
        if 'orderflow' in causes: pri += 15.0
        pri += min(30.0, _v510_num(row.get('score'), default=0.0))
        detail = d.get('detail') if isinstance(d.get('detail'), list) else []
        targets.append({
            'ticker': t,
            'stage': stage,
            'bucket': 'near_s_info_wait',
            'sub_bucket': 'core_S2_orderflow_micro_fresh_lock',
            'priority': round(pri, 3),
            'need': ['quote', 'ws', 'micro'],
            'need_orderflow': True,
            'need_micro': True,
            'source': 'strategy_worker_v613_orderflow_micro_urgent',
            'causes': sorted(list(causes & {'orderflow','micro'})),
            'detail': detail[:5],
            'final_trade_state': row.get('final_trade_state'),
            'final_decision': row.get('final_decision'),
            'requested_ts': nowv,
            'requested_text': now_text(nowv),
            'policy': 'S2 fresh_wait 원인이 체결/호가면 target_router/micro/WS 최우선 보강 후 strategy가 재판정한다.',
        })
    targets = sorted(targets, key=lambda x: _v510_num(x.get('priority'), default=0.0), reverse=True)
    obj = {
        'schema': 'orderflow_micro_urgent_targets_v613',
        'version': VERSION,
        'updated_ts': nowv,
        'updated_text': now_text(nowv),
        'request_count': len(targets),
        'targets': [x.get('ticker') for x in targets],
        'cause_counts': dict(cause_counter.most_common()),
        'rows': targets,
        'policy': 'No fixed ticker cap. All eligible S1/S2 fresh_wait rows caused by orderflow/micro remain in the queue; target_router/sidecar budgets handle server protection.',
    }
    save_json(ORDERFLOW_MICRO_URGENT_TARGETS, obj)
    result = _v613_reasoned_of_micro_state(targets, nowv)
    return targets, {
        'schema': 'strategy_orderflow_micro_urgent_summary_v613',
        'version': VERSION,
        'request_count': len(targets),
        'targets': obj.get('targets'),
        'cause_counts': obj.get('cause_counts'),
        'result': result,
        'policy': obj.get('policy'),
    }

_v613_prev_attach_s2_fresh_urgent_requests = _v574_attach_s2_fresh_urgent_requests

def _v613_attach_s2_fresh_urgent_requests(rows: List[Dict[str, Any]], priority_requests: List[Dict[str, Any]], nowv: float) -> Tuple[List[Dict[str, Any]], Dict[str, Any]]:
    out_reqs, base_summary = _v613_prev_attach_s2_fresh_urgent_requests(rows, priority_requests, nowv)
    out_reqs = list(out_reqs or [])
    targets, summary = _v613_build_orderflow_micro_urgent_targets(rows, nowv)
    for req in targets:
        # target_router가 이미 쓰는 near_s_info_wait 본선을 사용한다.
        # 새 조건이 아니라 정보 보강 요청이다.
        out_reqs.append(dict(req))
    if isinstance(base_summary, dict):
        base_summary = dict(base_summary)
    else:
        base_summary = {}
    base_summary['v613_orderflow_micro_urgent_summary'] = summary
    base_summary['schema'] = 'strategy_s2_fresh_urgent_summary_v619_orderflow_micro_normal_keepalive'
    return out_reqs, base_summary

_v574_attach_s2_fresh_urgent_requests = _v613_attach_s2_fresh_urgent_requests

_v613_prev_build_candidate_reason_summary = _v557_build_candidate_reason_summary

def _v613_reason_counts_ko(reason_counts: Dict[str, Any]) -> str:
    labels = {
        'ok_fresh': '정상 fresh',
        'router_ack_pending': 'router ACK 대기',
        'not_in_target_router': 'target_router 미포함',
        'not_in_micro_urgent': 'micro 긴급 미포함',
        'not_in_ws_targets': 'WS 대상 미포함',
        'orderflow_row_missing': '체결 row 없음',
        'quote_stale_or_missing': '시세 stale/없음',
        'micro_stale_or_missing': '호가 stale/없음',
        'orderflow_stale_or_missing': '체결 stale/없음',
        'unknown_not_fresh': '원인미상 미회복',
    }
    out=[]
    for k,v in (reason_counts or {}).items():
        try: n=int(v)
        except Exception: n=0
        if n:
            out.append(f"{labels.get(str(k), str(k))} {n}")
    return ' / '.join(out) if out else '-'

def _v613_build_candidate_reason_summary(display_rows: List[Dict[str, Any]], counts: Dict[str,int], reason_top: Any, nowv: float) -> Dict[str,Any]:
    base = _v613_prev_build_candidate_reason_summary(display_rows, counts, reason_top, nowv)
    req = load_json(ORDERFLOW_MICRO_URGENT_TARGETS, {}) or {}
    res = load_json(ORDERFLOW_MICRO_URGENT_RESULT, {}) or {}
    lines = [x for x in str(base.get('summary_text') or '').split('\n')]
    rows = res.get('rows') if isinstance(res.get('rows'), list) else []
    block = [
        '[체결/호가 fresh 긴급 · v619]',
        f"- 요청: {req.get('request_count', 0)} / target 포함: {res.get('selected_count', '-')} / fresh 통과: {res.get('fresh_ok_count', '-')} / 미회복: {res.get('miss_count', '-')}",
        f"- 세부: 체결 fresh {res.get('orderflow_fresh_count','-')} / 호가 fresh {res.get('micro_fresh_count','-')} / 시세 fresh {res.get('quote_fresh_count','-')}",
        f"- 미회복 사유 TOP: {_v613_reason_counts_ko(res.get('reason_counts') if isinstance(res.get('reason_counts'), dict) else {})}",
        f"- ACK 기준: {res.get('schema','-')}",
    ]
    if rows:
        block.append('- 후보별 상태:')
        for r in rows[:5]:
            age_txt = f"체결 {r.get('orderflow_age_sec','-')}s / 호가 {r.get('micro_age_sec','-')}s / 시세 {r.get('quote_age_sec','-')}s"
            block.append(f"  · {r.get('ticker','-')}: {r.get('reason','-')} · {age_txt}")
    block.append('- 용어: 체결=매수체결비/매도압력, 호가=스프레드/미끄러짐, 시세=WS/REST 최신가격')
    # fresh_wait 상세 뒤에 삽입한다.
    insert_at = len(lines)
    for i, line in enumerate(lines):
        if line.startswith('- 용어: 캔들='):
            insert_at = i + 1
            break
    lines[insert_at:insert_at] = block
    base['summary_text'] = '\n'.join(lines)
    bs = base.get('batch_state') if isinstance(base.get('batch_state'), dict) else {}
    bs['orderflow_micro_urgent_v619'] = {'request': req, 'result': res}
    bs['schema'] = 'candidate_reason_batch_state_v619_orderflow_micro_normal_keepalive'
    base['batch_state'] = bs
    base['schema'] = 'candidate_reason_summary_text_v619_orderflow_micro_normal_keepalive'
    return base

_v557_build_candidate_reason_summary = _v613_build_candidate_reason_summary



# =============================================================================
# strategy_worker v0.148 / v635: 1분 가격 재료 canonical 봉인
# - S1 막힘 사유가 "1분 가격 없음"일 때 출력부 보정이 아니라 canonical row에 재료 상태를 남긴다.
# - API 직접조회/fallback 없음. scanner/feature/orderflow cache에 있는 값만 봉인한다.
# - 조건/S1/S2/S3 기준값은 변경하지 않는다.
# =============================================================================
V635_STRATEGY_BUILD = 'strategy_worker_v0.148_v635_1m_price_material_spine'

_V635_1M_PREV_KEYS = ('price_1m_ago','price_60s_ago','one_min_ago_price','prev_1m_price','price_before_60s','price_1m_before')
_V635_1M_CHG_KEYS = ('change_1m_pct','change_1m','price_change_1m','scanner_change_1m_pct','price_chg_60s')

def _v635_first_present(src: Dict[str, Any], of: Dict[str, Any], keys: Tuple[str, ...]) -> Tuple[Any, str]:
    for owner, obj in (('feature/scanner', src), ('orderflow', of)):
        if isinstance(obj, dict):
            for k in keys:
                if obj.get(k) not in (None, '', [], {}):
                    return obj.get(k), f'{owner}.{k}'
    return None, ''

def _v635_build_price_1m_material(src: Dict[str, Any], of: Dict[str, Any], current_price: float) -> Dict[str, Any]:
    prev_raw, prev_source = _v635_first_present(src, of, _V635_1M_PREV_KEYS)
    chg_raw, chg_source = _v635_first_present(src, of, _V635_1M_CHG_KEYS)
    prev = _v510_num(prev_raw, default=0.0)
    chg_present = chg_raw not in (None, '', [], {})
    chg = _v510_num(chg_raw, default=0.0)
    ready = False
    source = 'missing'
    derived = False
    if current_price > 0 and prev > 0:
        ready = True
        source = prev_source or 'explicit_price_1m_ago'
        try:
            chg = ((current_price / prev) - 1.0) * 100.0
        except Exception:
            pass
    elif current_price > 0 and chg_present:
        ready = True
        source = chg_source or 'change_1m_pct'
        derived = True
        try:
            prev = current_price / (1.0 + chg / 100.0) if abs(1.0 + chg / 100.0) > 1e-9 else 0.0
        except Exception:
            prev = 0.0
    return {
        'schema': 'price_1m_material_v635',
        'ready': bool(ready),
        'current_price': round(current_price, 8) if current_price else None,
        'price_1m_ago': round(prev, 8) if prev else None,
        'change_1m_pct': round(chg, 4) if ready else None,
        'source': source,
        'derived_from_change_pct': bool(derived),
        'missing_reason': '' if ready else '1분 가격 없음',
        'policy': 'strategy_worker canonical row에 1분 가격 재료 상태만 봉인. 조건값 변경 없음.',
    }

_v635_prev_make_row = _v510_make_row

def _v510_make_row(src: Dict[str, Any], of: Dict[str, Any], stage: str, skey: str, label: str, lane: str, score: float, reasons: List[str], nowv: float, hard: Optional[List[str]] = None) -> Dict[str, Any]:  # type: ignore[override]
    row = _v635_prev_make_row(src, of, stage, skey, label, lane, score, reasons, nowv, hard)
    try:
        cur = _v510_num(row.get('current_price'), row.get('entry_price'), row.get('price'), default=0.0)
        mat = _v635_build_price_1m_material(src if isinstance(src, dict) else {}, of if isinstance(of, dict) else {}, cur)
        row['price_1m_material'] = mat
        row['price_1m_ready'] = bool(mat.get('ready'))
        row['price_1m_source'] = mat.get('source')
        if mat.get('price_1m_ago') is not None:
            row['price_1m_ago'] = mat.get('price_1m_ago')
        if mat.get('change_1m_pct') is not None:
            row['change_1m_pct'] = mat.get('change_1m_pct')
            row['price_chg_60s'] = mat.get('change_1m_pct') if _v510_num(row.get('price_chg_60s'), default=0.0) == 0.0 else row.get('price_chg_60s')
        if not mat.get('ready'):
            miss = row.get('missing_info') if isinstance(row.get('missing_info'), list) else []
            if '1분 가격 없음' not in [str(x) for x in miss]:
                row['missing_info'] = list(miss) + ['1분 가격 없음']
    except Exception as exc:
        try: log_error('v635_make_row_price_1m_material', exc)
        except Exception: pass
    return row

_v635_prev_build_canonical_metric_row = _v584_build_canonical_metric_row

def _v584_build_canonical_metric_row(row: Dict[str, Any], nowv: float) -> Dict[str, Any]:  # type: ignore[override]
    canon = _v635_prev_build_canonical_metric_row(row, nowv)
    try:
        mat = row.get('price_1m_material') if isinstance(row.get('price_1m_material'), dict) else {}
        metrics = canon.get('metrics') if isinstance(canon.get('metrics'), dict) else {}
        metrics['price_1m_ready'] = bool(mat.get('ready'))
        metrics['price_1m_ago'] = mat.get('price_1m_ago')
        metrics['change_1m_pct'] = mat.get('change_1m_pct') if mat.get('change_1m_pct') is not None else _v510_num(row.get('change_1m_pct'), row.get('change_1m'), default=0.0)
        metrics['price_1m_source'] = mat.get('source') or row.get('price_1m_source') or 'missing'
        canon['metrics'] = metrics
        canon['price_1m_material'] = mat or {'ready': False, 'missing_reason': '1분 가격 없음'}
        src = canon.get('source_snapshot') if isinstance(canon.get('source_snapshot'), dict) else {}
        src['price_1m_source'] = metrics.get('price_1m_source')
        canon['source_snapshot'] = src
        if not metrics.get('price_1m_ready'):
            br = canon.get('block_reasons') if isinstance(canon.get('block_reasons'), list) else []
            if '1분 가격 없음' not in [str(x) for x in br]:
                canon['block_reasons'] = list(br) + ['1분 가격 없음']
    except Exception as exc:
        try: log_error('v635_canonical_metric_price_1m_material', exc)
        except Exception: pass
    return canon


# =============================================================================
# strategy_worker v0.149 / v646: 전략별 조건 역할 spine 봉인
# - 조건 수치/S1·S2·S3/청산은 바꾸지 않는다.
# - main_bot이 reason 문구를 사후 분류하지 않도록 row에 역할별 조건을 직접 봉인한다.
# - 공통층은 위험/실행 가능성, 전략층은 구조/확인 신호로 분리한다.
# =============================================================================
V646_STRATEGY_BUILD = 'strategy_worker_v0.150_v646_strategy_condition_role_spine'

_V646_ROLE_KEYS = ('hard_block', 'execution_gate', 'recheck', 'strategy_structure', 'confirm_signal', 'display_only')
_V646_ROLE_KO = {
    'hard_block': '진짜 차단',
    'execution_gate': '진입 대기',
    'recheck': '재확인 필요',
    'strategy_structure': '구조/가점 재료',
    'confirm_signal': '확인 통과',
    'display_only': '참고 태그',
}

def _v646_text(v: Any) -> str:
    if isinstance(v, dict):
        return str(v.get('reason') or v.get('name') or v.get('value') or '').strip()
    return str(v or '').strip()

def _v646_list(v: Any, limit: int = 20) -> List[str]:
    if v in (None, '', [], {}):
        return []
    raw = v if isinstance(v, list) else [v]
    out: List[str] = []
    for x in raw:
        s = _v646_text(x)
        if s and s not in out:
            out.append(s)
        if len(out) >= limit:
            break
    return out

def _v646_has(txt: str, words: Tuple[str, ...]) -> bool:
    low = str(txt or '').lower()
    return any(str(w).lower() in low for w in words)

def _v646_strategy_family(row: Dict[str, Any]) -> str:
    vals: List[str] = []
    for k in ('strategy_label', 'strategy', 'strategy_key', 'paper_strategy_key'):
        if row.get(k) not in (None, '', [], {}):
            vals.append(str(row.get(k)))
    vals += _v646_list(row.get('matched_strategy_labels'), 6)
    vals += _v646_list(row.get('matched_strategy_keys'), 6)
    s = ' '.join(vals)
    low = s.lower()
    if '저점' in s or '쓸림' in s or 'sweep' in low or 'vwap recovery' in low or 'vwap 회복' in s:
        return '저점 쓸림/VWAP 회복'
    if '돈흐름' in s or '재가속' in s or 'reaccel' in low or 'pullback' in low:
        return '돈흐름 재가속'
    if '돌파' in s or 'breakout' in low:
        return '돌파 초입'
    if '주도' in s or '유동보유' in s or 'leader' in low or 'momentum' in low or '추세' in s:
        return '주도흐름 유동보유'
    if 'hot-rank' in low or 'hot_rank' in low or '급등' in s:
        return 'hot-rank 발견/재확인'
    return str(row.get('strategy_label') or row.get('strategy') or row.get('strategy_key') or '기타')

_V646_STRATEGY_GUIDE = {
    '저점 쓸림/VWAP 회복': {
        'structure': ['저점유동성쓸림', '쓸림후빠른회복', 'VWAP 재회복', '저점 재이탈 없음'],
        'confirm': ['매수체결 회복', '1분 지속 회복', '저점 재이탈 없음'],
        'danger': ['저점 재이탈', '강한 매도압력', '스프레드 과다'],
    },
    '돈흐름 재가속': {
        'structure': ['눌림 후 돈흐름 재유입', 'VWAP/EMA 방어', '거래대금 재유입'],
        'confirm': ['체결 회복', '1분 지속 회복', '상대강도 유지'],
        'danger': ['윗꼬리/매도압력', '스프레드 과다', '반복손실 유사'],
    },
    '돌파 초입': {
        'structure': ['저항 돌파', '거래량 확장', '돌파선 유지', '재테스트 방어'],
        'confirm': ['돌파 유지', '체결 동반', '윗꼬리 제한'],
        'danger': ['가짜돌파', '윗꼬리', '늦은추격', '스프레드 과다'],
    },
    '주도흐름 유동보유': {
        'structure': ['15/30분 주도성', '상대강도', 'VWAP/EMA 유지', '얕은 눌림'],
        'confirm': ['추세 유지', '매도압력 약화', '돈흐름 유지'],
        'danger': ['고점권 되돌림', '강한 매도압력', '심한 stale'],
    },
    'hot-rank 발견/재확인': {
        'structure': ['급등 발견', '거래량 확장', '공통상승조건'],
        'confirm': ['짧은 체결 확인', '스프레드 회복', '윗꼬리 제한'],
        'danger': ['늦은추격', '스프레드/미끄러짐 과다', '체결 약함'],
    },
}

def _v646_add_unique(d: Dict[str, List[str]], key: str, val: Any, limit: int = 12) -> None:
    s = _v646_text(val)
    if not s:
        return
    arr = d.setdefault(key, [])
    if s not in arr and len(arr) < limit:
        arr.append(s)

def _v646_classify_reason(txt: str, family: str, source: str = '') -> str:
    t = str(txt or '').strip()
    if not t:
        return 'display_only'
    # 실행 타이밍은 위험 차단이 아니라 entry gate다.
    if _v646_has(t, ('방아쇠', 'trigger')) and _v646_has(t, ('미도달', 'gap', '도달 전')):
        return 'execution_gate'
    if _v646_has(t, ('진입타이밍 정보없음', 'entry timing')):
        return 'execution_gate'
    # 정보 자체가 없거나 비정상인 경우만 hard.
    if _v646_has(t, ('1분 가격 없음', '재료없음', '재료 없음', '거래정지', '비정상 데이터', '시세정보 없음')):
        return 'hard_block'
    # 실제 실행 위험.
    if _v646_has(t, ('스프레드 과다', '미끄러짐 과다', '급등형 스프레드', '급등형 미끄러짐')) and '회복 대기' not in t:
        return 'hard_block'
    if _v646_has(t, ('매도벽/매도체결압력', '강한 매도압력', '급등형 매도압력/윗꼬리 위험', '늦은추격 위험', '가짜돌파')):
        return 'hard_block'
    if _v646_has(t, ('stale 심함', '공식캔들 stale')):
        return 'hard_block'
    # 부족/근접/대기류는 전략별 확인 신호 부족이므로 재확인이다.
    if _v646_has(t, ('회복 대기', '기준근접', '가격반응 약함', '가격반응 +0.00%', '가격반응', '1분 매수지속 부족', '1분지속', '매수체결', '짧은 매수세 부족', '거래대금부족', 'runner 가격힘 부족', '급등초입 신호 부족')):
        return 'recheck'
    # 구조/알파 재료.
    if _v646_has(t, ('VWAP', 'EMA', '돈흐름', '거래량확장', '저항돌파', '저점유동성쓸림', '쓸림후빠른회복', '공통상승조건', '주도흐름', '상대강도', '눌림', '재돌파')):
        return 'strategy_structure'
    # 발견/설명용.
    if _v646_has(t, ('hot-rank', 'hot_rank', '발견신호', '구조선 근거 재확인')):
        return 'display_only'
    return 'display_only'

def _v646_build_condition_roles(row: Dict[str, Any]) -> Dict[str, Any]:
    family = _v646_strategy_family(row)
    roles: Dict[str, List[str]] = {k: [] for k in _V646_ROLE_KEYS}
    # 이미 v553가 분리한 원천을 우선 사용한다. 없으면 legacy reason으로 보강한다.
    for x in _v646_list(row.get('entry_structure_tags') or row.get('structure_tags'), 12):
        _v646_add_unique(roles, 'strategy_structure', x)
    for x in _v646_list(row.get('confirm_signals'), 12):
        _v646_add_unique(roles, 'confirm_signal', x)
    for x in _v646_list(row.get('execution_risk_tags') or row.get('risk_tags'), 12):
        _v646_add_unique(roles, _v646_classify_reason(x, family, 'risk'), x)
    for x in _v646_list(row.get('freshness_flags') or row.get('stale_reasons'), 10):
        # 정보 오래됨은 기본적으로 재확인. 심한 stale만 classifier가 hard로 올린다.
        role = _v646_classify_reason(x, family, 'freshness')
        if role == 'display_only':
            role = 'recheck'
        _v646_add_unique(roles, role, x)
    for x in _v646_list(row.get('recheck_reasons') or row.get('s2_recheck_reasons'), 12):
        _v646_add_unique(roles, 'recheck', x)
    for x in _v646_list(row.get('block_reasons') or row.get('s1_missing_conditions'), 12):
        _v646_add_unique(roles, _v646_classify_reason(x, family, 'block'), x)
    # 방아쇠는 별도 실행대기로 봉인한다.
    try:
        cur = _v510_num(row.get('current_price'), row.get('entry_price'), row.get('price'), default=0.0)
        trg = _v510_num(row.get('trigger_price'), default=0.0)
        reached = bool(row.get('trigger_reached'))
        if cur > 0 and trg > 0 and cur < trg and not reached:
            gap = ((cur / trg) - 1.0) * 100.0
            _v646_add_unique(roles, 'execution_gate', f'방아쇠 미도달 {gap:+.2f}%')
    except Exception:
        pass
    # legacy reason이 남아 있으면 보조로 분류한다. 단, 기존 분리 필드보다 우선하지 않는다.
    legacy = _v646_list(row.get('s_stage_reasons') or row.get('reason'), 14)
    for x in legacy:
        clean = str(x).replace('구조:', '').strip()
        _v646_add_unique(roles, _v646_classify_reason(clean, family, 'legacy'), clean)
    # hot-rank는 발견/참고 태그로만 둔다.
    hay = ' '.join([str(row.get(k) or '') for k in ('strategy_label','strategy','strategy_key','paper_strategy_key')] + _v646_list(row.get('matched_strategy_labels'), 6) + _v646_list(row.get('matched_strategy_keys'), 6)).lower()
    if 'hot-rank' in hay or 'hot_rank' in hay or '급등' in hay:
        _v646_add_unique(roles, 'display_only', 'hot-rank 발견신호')
    # 각 역할 내부 중복 제거/제한
    clean_roles: Dict[str, List[str]] = {}
    for k in _V646_ROLE_KEYS:
        seen=set(); arr=[]
        for x in roles.get(k, []):
            s=_v646_text(x)
            if s and s not in seen:
                seen.add(s); arr.append(s)
            if len(arr) >= 10:
                break
        clean_roles[k]=arr
    guide = _V646_STRATEGY_GUIDE.get(family, {})
    return {
        'schema': 'strategy_condition_role_spine_v646',
        'strategy_family': family,
        'roles': clean_roles,
        'role_labels': _V646_ROLE_KO,
        'guide': guide,
        'policy': '조건 수치/S등급/청산 변경 없음. strategy_worker가 조건 역할을 row에 직접 봉인하고 main_bot은 표시만 한다.',
    }

_v646_prev_apply_reason_taxonomy = _v553_apply_reason_taxonomy

def _v553_apply_reason_taxonomy(row: Dict[str, Any]) -> Dict[str, Any]:  # type: ignore[override]
    row = _v646_prev_apply_reason_taxonomy(row)
    try:
        cr = _v646_build_condition_roles(row)
        row['condition_role_schema'] = cr.get('schema')
        row['condition_roles'] = cr.get('roles')
        row['condition_role_labels'] = cr.get('role_labels')
        row['strategy_condition_family'] = cr.get('strategy_family')
        row['strategy_condition_guide'] = cr.get('guide')
        row['condition_role_policy'] = cr.get('policy')
        ctx = row.get('entry_context') if isinstance(row.get('entry_context'), dict) else {}
        ctx = dict(ctx)
        for k in ('condition_role_schema','condition_roles','condition_role_labels','strategy_condition_family','strategy_condition_guide','condition_role_policy'):
            ctx[k] = row.get(k)
        row['entry_context'] = ctx
    except Exception as exc:
        try: log_error('v646_apply_condition_role_spine', exc)
        except Exception: pass
    return row



# =============================================================================
# strategy_worker v0.150 / v656: 코인 종합품질 spine
# - 새 전략을 추가하지 않는다. 전략명은 복기용 구조 태그로 유지한다.
# - 구조/돈흐름/확인신호/실행위험/신선도 점수를 strategy_worker canonical row에 봉인한다.
# - paper OPEN/S1 하드 기준/청산/자동매수는 변경하지 않는다.
# - S3 중 코인 자체 품질이 좋고 실행위험이 낮은 row만 S2 재확인으로 올려 정보배관을 우선 배차한다.
# =============================================================================
V656_STRATEGY_BUILD = 'strategy_worker_v0.156_v663_trigger_source_owner'
V658_STRATEGY_BUILD = 'strategy_worker_v0.156_v663_trigger_source_owner'


def _v656_clamp(v: float, lo: float = 0.0, hi: float = 100.0) -> float:
    try:
        return max(lo, min(hi, float(v)))
    except Exception:
        return lo


def _v656_list(v: Any, limit: int = 30) -> List[str]:
    if v in (None, '', [], {}):
        return []
    raw = v if isinstance(v, list) else [v]
    out: List[str] = []
    for x in raw:
        if isinstance(x, dict):
            s = str(x.get('reason') or x.get('name') or x.get('value') or x.get('tag') or '').strip()
        else:
            s = str(x or '').strip()
        if s and s not in out:
            out.append(s)
        if len(out) >= limit:
            break
    return out


def _v656_role_items(row: Dict[str, Any], role: str) -> List[str]:
    roles = row.get('condition_roles') if isinstance(row.get('condition_roles'), dict) else {}
    return _v656_list(roles.get(role), 20)


def _v658_age_value(row: Dict[str, Any], keys: Tuple[str, ...]) -> float:
    for k in keys:
        v = row.get(k)
        n = _v510_num(v, default=-1.0)
        if n >= 0:
            return n
    return -1.0


def _v658_text_stale_sources(stale_texts: List[str]) -> List[Dict[str, Any]]:
    out: List[Dict[str, Any]] = []
    patterns = [
        ('candle', ('candle','캔들','official_candle','공식캔들','구조재료')),
        ('feature', ('feature','vwap','ema','가격/VWAP','가격반응')),
        ('orderflow', ('orderflow','체결','매수체결','매도압력')),
        ('micro', ('micro','호가','스프레드','미끄러짐')),
        ('ws', ('ws','websocket','시세')),
        ('quote', ('quote','호가시세')),
        ('price', ('price','가격')),
        ('strategy', ('strategy','판단row','봉인')),
    ]
    for raw in stale_texts or []:
        txt = str(raw or '').strip()
        if not txt:
            continue
        low = txt.lower()
        source = 'unknown'
        for name, words in patterns:
            if any(str(w).lower() in low for w in words):
                source = name
                break
        age = -1.0
        m = re.search(r'([0-9]+(?:\.[0-9]+)?)\s*s', txt)
        if m:
            try:
                age = float(m.group(1))
            except Exception:
                age = -1.0
        out.append({'source': source, 'age_sec': round(age, 3) if age >= 0 else None, 'reason': txt, 'from': 'text'})
    return out


def _v658_stale_origin(row: Dict[str, Any]) -> Dict[str, Any]:
    """strategy row 안에서 정보 오래됨의 주인을 봉인한다.

    main_bot 출력부가 임의로 stale을 재계산하지 않도록, candle/feature/orderflow/micro/ws 등
    생산 공장별 원인을 여기서 확정한다. 임계값은 매수조건이 아니라 원인 표시/urgent 배차용이다.
    """
    specs = [
        ('candle', ('candle_age_sec','official_candle_age','official_candle_age_sec','candle_source_age_sec'), 180.0),
        ('feature', ('feature_age_sec','feature_source_age_sec','vwap_age_sec','ema_age_sec'), 45.0),
        ('orderflow', ('orderflow_age_sec','orderflow_source_age_sec','trade_age_sec'), 35.0),
        ('micro', ('micro_age_sec','micro_source_age_sec','orderbook_age_sec'), 35.0),
        ('ws', ('ws_age_sec','websocket_age_sec','price_ws_age_sec'), 35.0),
        ('quote', ('quote_age_sec','quote_source_age_sec'), 35.0),
        ('price', ('price_age_sec','source_age_sec','current_price_age_sec'), 45.0),
        ('strategy', ('strategy_age_sec','row_age_sec','sealed_age_sec'), 45.0),
    ]
    items: List[Dict[str, Any]] = []
    for source, keys, ttl in specs:
        age = _v658_age_value(row, keys)
        if age >= 0 and age > ttl:
            items.append({'source': source, 'age_sec': round(age, 3), 'ttl_sec': ttl, 'reason': f'{source} {age:.1f}s>{ttl:.0f}s', 'from': 'numeric'})
    text_items = _v658_text_stale_sources(_v656_list(row.get('stale_reasons') or row.get('freshness_flags'), 20))
    seen = {(x.get('source'), str(x.get('reason'))) for x in items}
    for it in text_items:
        key = (it.get('source'), str(it.get('reason')))
        if key not in seen:
            items.append(it); seen.add(key)
    cnt = Counter(str(x.get('source') or 'unknown') for x in items)
    top = [f'{k} {v}' for k, v in cnt.most_common(8)]
    return {
        'schema': 'stale_origin_v658',
        'has_stale': bool(items),
        'items': items[:12],
        'source_counts': dict(cnt),
        'top_sources': top,
        'policy': '정보오래됨 원인은 strategy_worker canonical row에서 생산 공장별로 봉인하고 main은 표시만 한다.',
    }


def _v658_quality_hold_reasons(row: Dict[str, Any], q: float, structure_score: float, flow_score: float, confirmation_score: float, risk_score: float, freshness_score: float, stale_origin: Dict[str, Any]) -> List[str]:
    reasons: List[str] = []
    react = _v655_metric(row, 'price_reaction_pct', 'change_1m_pct', 'price_chg_60s')
    buy = _v655_metric(row, 'buy_ratio')
    sustain = _v655_metric(row, 'buy_sustain_1m', 'buy_sustain_20s', 'buy_ratio_20s')
    if structure_score < 55:
        reasons.append(f'구조점수 {structure_score:.0f}<55')
    if flow_score < 55:
        reasons.append(f'돈흐름 {flow_score:.0f}<55')
    if confirmation_score < 42:
        reasons.append(f'확인신호 {confirmation_score:.0f}<42')
    elif confirmation_score < 58:
        reasons.append(f'확인신호 근접 {confirmation_score:.0f}')
    if react < 0.35:
        reasons.append(f'가격반응 {react:+.2f}%<+0.35%')
    if buy < 0.55:
        reasons.append(f'매수체결 {buy:.2f}<0.55')
    if sustain < 0.70:
        reasons.append(f'1분지속 {sustain:.2f}<0.70')
    if risk_score > 42:
        reasons.append(f'실행위험 {risk_score:.0f}>42')
    if freshness_score < 60:
        stale_top = stale_origin.get('top_sources') if isinstance(stale_origin, dict) else []
        reasons.append('신선도 부족' + (': ' + '/'.join(str(x) for x in stale_top[:3]) if stale_top else ''))
    trig = row.get('trigger_price') or row.get('entry_trigger_price') or row.get('trigger')
    if trig in (None, '', 0, 0.0):
        reasons.append('방아쇠 정보 없음')
    hard = _v656_role_items(row, 'hard_block')
    if hard:
        reasons.append('하드차단:' + '/'.join(hard[:2]))
    return _v510_uniq(reasons, 10)


def _v656_blob(row: Dict[str, Any]) -> str:
    vals: List[str] = []
    for k in ('strategy_key','strategy_label','strategy','strategy_condition_family','structure_tags','entry_structure_tags','matched_strategy_labels','matched_strategy_keys','block_reasons','risk_tags','s2_recheck_reasons','condition_roles'):
        v = row.get(k)
        if isinstance(v, dict):
            for vv in v.values():
                vals += _v656_list(vv, 20)
        else:
            vals += _v656_list(v, 20)
    return ' '.join(vals)


def _v656_coin_quality(row: Dict[str, Any]) -> Dict[str, Any]:
    blob = _v656_blob(row)
    low = blob.lower()
    react = _v655_metric(row, 'price_reaction_pct', 'change_1m_pct', 'price_chg_60s')
    ch30 = _v655_metric(row, 'price_chg_30s')
    ch60 = _v655_metric(row, 'price_chg_60s', 'change_1m_pct')
    ch3 = _v655_metric(row, 'change_3m_pct', 'change_3m', 'price_change_3m')
    ch5 = _v655_metric(row, 'change_5m_pct', 'change_5m', 'price_change_5m')
    ch15 = _v655_metric(row, 'change_15m_pct', 'change_15m', 'price_change_15m')
    buy = _v655_metric(row, 'buy_ratio')
    sustain = _v655_metric(row, 'buy_sustain_1m', 'buy_sustain_20s', 'buy_ratio_20s')
    buy10 = _v655_metric(row, 'buy_ratio_10s', 'buy_sustain_10s')
    buy20 = _v655_metric(row, 'buy_ratio_20s', 'buy_sustain_20s')
    spread = _v655_metric(row, 'spread_pct', default=99.0)
    slip = _v655_metric(row, 'slippage_pct', 'spread_pct', default=spread)
    score_base = _v655_metric(row, 'score')
    stale = _v656_list(row.get('stale_reasons') or row.get('freshness_flags'), 20)
    stale_origin_v658 = _v658_stale_origin(row)
    hard = _v656_role_items(row, 'hard_block')
    recheck = _v656_role_items(row, 'recheck')
    struct_items = _v656_list(row.get('structure_tags'), 20) + _v656_role_items(row, 'strategy_structure')
    confirm_items = _v656_role_items(row, 'confirm_signal')
    risk_items = _v656_list(row.get('risk_tags') or row.get('structure_risk_tags'), 20) + _v656_role_items(row, 'execution_gate')

    structure_words = ('VWAP','EMA','돈흐름','주도흐름','상대강도','눌림','재돌파','저점유동성쓸림','쓸림','박스','지지','저항','돌파','공통상승조건')
    structure_hits = sum(1 for w in structure_words if w in blob)
    structure_score = 18.0 + min(48.0, structure_hits * 8.0) + min(18.0, len(set(struct_items)) * 3.0)
    if 'hot-rank' in low or '급등' in blob:
        structure_score += 4.0  # 발견 신호일 뿐, 큰 가점은 주지 않는다.
    structure_score = _v656_clamp(structure_score)

    flow_score = 20.0
    flow_score += _v656_clamp(ch3 * 12.0, 0, 24)
    flow_score += _v656_clamp(ch5 * 8.0, 0, 18)
    flow_score += _v656_clamp(ch15 * 3.0, 0, 14)
    if any(w in blob for w in ('돈흐름','주도흐름','상대강도','거래대금','거래량')):
        flow_score += 14.0
    flow_score += _v656_clamp(score_base / 8.0, 0, 12)
    flow_score = _v656_clamp(flow_score)

    confirmation_score = 15.0
    confirmation_score += _v656_clamp(react * 55.0, 0, 30)
    confirmation_score += _v656_clamp(ch30 * 35.0, 0, 12)
    confirmation_score += _v656_clamp(ch60 * 28.0, 0, 12)
    confirmation_score += _v656_clamp((buy - 0.35) * 70.0, 0, 20)
    confirmation_score += _v656_clamp((sustain - 0.35) * 70.0, 0, 18)
    confirmation_score += _v656_clamp((max(buy10, buy20) - 0.35) * 35.0, 0, 8)
    confirmation_score += min(8.0, len(confirm_items) * 3.0)
    confirmation_score = _v656_clamp(confirmation_score)

    risk_score = 0.0
    risk_score += _v656_clamp((spread - 0.12) * 80.0, 0, 38)
    risk_score += _v656_clamp((slip - 0.12) * 80.0, 0, 38)
    risk_text = ('매도벽','매도체결압력','강한 매도압력','늦은추격','가짜돌파','윗꼬리','스프레드부담','미끄러짐부담')
    risk_score += min(36.0, sum(1 for w in risk_text if w in blob) * 7.0)
    if ('hot-rank' in low or '급등' in blob) and (spread > 0.65 or slip > 0.65 or buy < 0.45 or sustain < 0.45):
        risk_score += 18.0
    if hard:
        risk_score += min(24.0, len(hard) * 6.0)
    execution_risk_score = _v656_clamp(risk_score)
    execution_score = _v656_clamp(100.0 - execution_risk_score)

    freshness_score = 100.0
    freshness_score -= min(70.0, len(stale) * 16.0)
    if stale_origin_v658.get('items'):
        freshness_score -= min(35.0, len(stale_origin_v658.get('items') or []) * 6.0)
    # numeric age fields, when present, reduce the freshness score without creating a fallback value.
    for k in ('source_age_sec','orderflow_age_sec','micro_age_sec','quote_age_sec','feature_age_sec','candle_age_sec','official_candle_age'):
        age = _v510_num(row.get(k), default=-1.0)
        if age > 30:
            freshness_score -= min(35.0, (age - 30.0) / 6.0)
    freshness_score = _v656_clamp(freshness_score)

    quality = (structure_score * 0.24) + (flow_score * 0.22) + (confirmation_score * 0.30) + (execution_score * 0.18) + (freshness_score * 0.06)
    quality = _v656_clamp(quality)
    hot_like = bool('hot-rank' in low or '급등' in blob)
    reasons: List[str] = []
    if structure_score >= 62: reasons.append('구조 양호')
    if flow_score >= 62: reasons.append('돈흐름 양호')
    if confirmation_score >= 58: reasons.append('확인신호 양호')
    elif confirmation_score >= 44: reasons.append('확인신호 근접')
    if execution_risk_score <= 35: reasons.append('실행위험 낮음')
    elif execution_risk_score >= 65: reasons.append('실행위험 높음')
    if freshness_score < 60: reasons.append('신선도 재수집 필요')

    lane = 'observe'
    if execution_risk_score >= 70 or (hot_like and execution_risk_score >= 55):
        lane = 'late_chase_or_execution_risk'
    elif freshness_score < 60 and quality >= 52 and execution_risk_score <= 55:
        lane = 'quality_info_urgent'
    elif quality >= 66 and execution_risk_score <= 42 and freshness_score >= 45 and ((structure_score >= 55 and confirmation_score >= 42) or (quality >= 74 and execution_risk_score <= 25 and confirmation_score >= 35)):
        lane = 'quality_s2_recheck'
    elif quality >= 58 and execution_risk_score <= 55:
        lane = 'quality_watch'
    elif quality < 45:
        lane = 'weak_coin_observe'

    quality_s3_hold_reasons_v658 = _v658_quality_hold_reasons(row, quality, structure_score, flow_score, confirmation_score, execution_risk_score, freshness_score, stale_origin_v658)

    return {
        'schema': 'coin_quality_spine_v658',
        'build': V656_STRATEGY_BUILD,
        'coin_quality_score': round(quality, 2),
        'candidate_quality_score': round(quality, 2),
        'structure_score': round(structure_score, 2),
        'flow_score': round(flow_score, 2),
        'confirmation_score': round(confirmation_score, 2),
        'execution_risk_score': round(execution_risk_score, 2),
        'execution_score': round(execution_score, 2),
        'freshness_score': round(freshness_score, 2),
        'quality_lane': lane,
        'quality_lane_reasons': _v510_uniq(reasons or ['관찰'], 8),
        'stale_origin_v658': stale_origin_v658,
        'stale_origin_top_v658': stale_origin_v658.get('top_sources') if isinstance(stale_origin_v658, dict) else [],
        'quality_s3_hold_reasons_v658': quality_s3_hold_reasons_v658,
        'quality_hold_reason_v658': ' / '.join(quality_s3_hold_reasons_v658[:4]) if quality_s3_hold_reasons_v658 else '-',
        'strategy_key': row.get('strategy_key'),
        'strategy_label': row.get('strategy_label') or row.get('strategy') or row.get('strategy_name'),
        'structure_tags': _v510_uniq(struct_items or _v656_list(row.get('structure_tags'), 12), 12),
        'policy': '전략 추가 없음. 전략명은 구조/복기 태그로 유지하고 코인 자체 품질·실행위험·신선도를 canonical row에 봉인한다.',
    }


def _v656_attach_coin_quality(rows: List[Dict[str, Any]], nowv: float) -> Tuple[List[Dict[str, Any]], Dict[str, Any]]:
    out: List[Dict[str, Any]] = []
    counts: Dict[str, int] = {}
    promoted = 0
    score_sum = 0.0
    for r in rows or []:
        if not isinstance(r, dict):
            continue
        rr = dict(r)
        q = _v656_coin_quality(rr)
        lane = str(q.get('quality_lane') or 'observe')
        counts[lane] = counts.get(lane, 0) + 1
        score_sum += _v510_num(q.get('coin_quality_score'), default=0.0)
        rr['coin_quality_spine'] = q
        for k in ('coin_quality_score','candidate_quality_score','structure_score','flow_score','confirmation_score','execution_risk_score','execution_score','freshness_score','quality_lane','quality_lane_reasons','stale_origin_v658','stale_origin_top_v658','quality_s3_hold_reasons_v658','quality_hold_reason_v658'):
            rr[k] = q.get(k)
        rr['quality_structure_tags'] = q.get('structure_tags') or rr.get('structure_tags') or []
        rr['quality_spine_build'] = V656_STRATEGY_BUILD
        ctx = rr.get('entry_context') if isinstance(rr.get('entry_context'), dict) else {}
        ctx = dict(ctx)
        ctx['coin_quality_spine'] = q
        rr['entry_context'] = ctx
        if _v510_stage(rr) == 'S3' and lane == 'quality_s2_recheck':
            rr['s_stage'] = rr['candidate_stage'] = rr['candidate_grade'] = rr['stage'] = rr['grade'] = 'S2'
            rr['recheck_state'] = 'S2 재확인'
            prev = rr.get('s2_recheck_reasons') if isinstance(rr.get('s2_recheck_reasons'), list) else []
            rr['s2_recheck_reasons'] = _v510_uniq(list(prev) + ['v656:코인품질 양호 S2 재확인'] + _v656_list(q.get('quality_lane_reasons'), 6), 10)
            br = rr.get('block_reasons') if isinstance(rr.get('block_reasons'), list) else []
            rr['block_reasons'] = _v510_uniq(list(br) + ['재확인: 코인품질 양호·실행위험 낮음'], 12)
            rr['open_eligible'] = False; rr['paper_bot_open'] = False; rr['trade_ready'] = False
            promoted += 1
        out.append(rr)
    avg = round(score_sum / len(out), 2) if out else 0.0
    return out, {
        'schema': 'coin_quality_summary_v658',
        'version': VERSION,
        'build': V656_STRATEGY_BUILD,
        'updated_ts': nowv,
        'row_count': len(out),
        'avg_coin_quality_score': avg,
        'lane_counts': counts,
        's3_to_s2_quality_promoted': promoted,
        'policy': '전략 추가/조건 완화가 아니라 코인 자체 품질 spine 봉인 및 저위험 품질후보 S2 재확인 승격.',
    }


_v656_prev_apply_strategy_recheck_lanes = _v655_apply_strategy_recheck_lanes

def _v655_apply_strategy_recheck_lanes(rows: List[Dict[str, Any]], nowv: float) -> Tuple[List[Dict[str, Any]], Dict[str, Any]]:  # type: ignore[override]
    rows2, base = _v656_prev_apply_strategy_recheck_lanes(rows, nowv)
    rows3, qsum = _v656_attach_coin_quality(rows2, nowv)
    if isinstance(base, dict):
        base = dict(base)
    else:
        base = {}
    base['v656_coin_quality_summary'] = qsum
    base['schema'] = 'strategy_recheck_lane_summary_v656_coin_quality_spine'
    return rows3, base


_v656_prev_attach_s2_fresh_urgent_requests = _v574_attach_s2_fresh_urgent_requests

def _v574_attach_s2_fresh_urgent_requests(rows: List[Dict[str, Any]], priority_requests: List[Dict[str, Any]], nowv: float) -> Tuple[List[Dict[str, Any]], Dict[str, Any]]:  # type: ignore[override]
    out_reqs, base_summary = _v656_prev_attach_s2_fresh_urgent_requests(rows, priority_requests, nowv)
    out_reqs = list(out_reqs or [])
    seen = {(ticker_norm(r.get('ticker')), str(r.get('bucket') or '')) for r in out_reqs if isinstance(r, dict)}
    added: List[Dict[str, Any]] = []
    for r in rows or []:
        if not isinstance(r, dict):
            continue
        t = ticker_norm(r.get('ticker'))
        if not t:
            continue
        lane = str(r.get('quality_lane') or '')
        if lane not in ('quality_s2_recheck', 'quality_info_urgent'):
            continue
        bucket = 'coin_quality_s2_recheck' if lane == 'quality_s2_recheck' else 'coin_quality_info_urgent'
        key = (t, bucket)
        if key in seen:
            continue
        seen.add(key)
        q = _v510_num(r.get('coin_quality_score'), default=0.0)
        risk = _v510_num(r.get('execution_risk_score'), default=99.0)
        fresh = _v510_num(r.get('freshness_score'), default=100.0)
        pri = 820.0 + min(80.0, q) - min(40.0, risk / 2.0)
        if lane == 'quality_s2_recheck':
            pri += 80.0
        if fresh < 60:
            pri += 35.0
        req = {
            'ticker': t,
            'bucket': bucket,
            'sub_bucket': lane,
            'priority': round(pri, 3),
            'need': ['quote', 'ws', 'micro', 'candle'],
            'need_orderflow': True,
            'need_micro': True,
            'need_candle': True,
            'source': 'strategy_worker_v658_stale_origin_hold_reason',
            'stage': _v510_stage(r),
            'quality_lane': lane,
            'coin_quality_score': q,
            'execution_risk_score': risk,
            'freshness_score': fresh,
            'reasons': _v656_list(r.get('quality_lane_reasons'), 6),
            'updated_ts': nowv,
            'updated_text': now_text(nowv),
            'policy': '코인품질 양호/S2재확인/정보오래됨 후보를 target_router 우선수집으로 보낸다. 후보 수 고정 제한 아님.',
        }
        out_reqs.append(req)
        added.append(req)
    if isinstance(base_summary, dict):
        base_summary = dict(base_summary)
    else:
        base_summary = {}
    base_summary['v656_coin_quality_urgent_summary'] = {
        'schema': 'coin_quality_urgent_requests_v658',
        'version': VERSION,
        'request_count': len(added),
        'targets': [x.get('ticker') for x in added[:50]],
        'lane_counts': dict(Counter(str(x.get('quality_lane') or '-') for x in added)),
        'policy': 'strategy_worker가 봉인한 coin_quality_spine 중 우선 보강 대상만 priority_requests에 추가.',
    }
    base_summary['schema'] = 'strategy_s2_fresh_urgent_summary_v656_coin_quality_spine'
    return out_reqs, base_summary


_v656_prev_build_candidate_reason_summary = _v557_build_candidate_reason_summary

def _v557_build_candidate_reason_summary(display_rows: List[Dict[str, Any]], counts: Dict[str,int], reason_top: Any, nowv: float) -> Dict[str,Any]:  # type: ignore[override]
    base = _v656_prev_build_candidate_reason_summary(display_rows, counts, reason_top, nowv)
    lane_counter: Counter = Counter()
    stale_counter: Counter = Counter()
    good: List[Dict[str, Any]] = []
    risk: List[Dict[str, Any]] = []
    stale_good: List[Dict[str, Any]] = []
    hold_s3: List[Dict[str, Any]] = []
    total = 0.0
    n = 0
    for r in display_rows or []:
        if not isinstance(r, dict):
            continue
        lane = str(r.get('quality_lane') or 'unknown')
        lane_counter[lane] += 1
        q = _v510_num(r.get('coin_quality_score'), default=0.0)
        risk_score = _v510_num(r.get('execution_risk_score'), default=0.0)
        total += q; n += 1
        stale_obj = r.get('stale_origin_v658') if isinstance(r.get('stale_origin_v658'), dict) else {}
        for src, cnt in (stale_obj.get('source_counts') or {}).items():
            try: stale_counter[str(src)] += int(cnt)
            except Exception: stale_counter[str(src)] += 1
        hold_reasons = _v656_list(r.get('quality_s3_hold_reasons_v658'), 4)
        item = {'ticker': ticker_norm(r.get('ticker')), 'stage': _v510_stage(r), 'q': round(q,1), 'risk': round(risk_score,1), 'why': _v656_list(r.get('quality_lane_reasons'), 3), 'hold': hold_reasons, 'stale': _v656_list(r.get('stale_origin_top_v658'), 3)}
        if lane in ('quality_s2_recheck','quality_info_urgent','quality_watch'):
            good.append(item)
        if lane == 'late_chase_or_execution_risk':
            risk.append(item)
        if q >= 58 and risk_score <= 55 and item['stale']:
            stale_good.append(item)
        if _v510_stage(r) == 'S3' and q >= 60 and risk_score <= 45:
            hold_s3.append(item)
    avg = round(total / n, 1) if n else 0.0
    label = {
        'quality_s2_recheck':'살릴 S2재확인',
        'quality_info_urgent':'좋은데 정보재수집',
        'quality_watch':'관찰가치',
        'late_chase_or_execution_risk':'추격/실행위험',
        'weak_coin_observe':'약한 후보',
        'observe':'일반관찰',
        'unknown':'미봉인',
    }
    cnt_txt = ' / '.join(f"{label.get(k,k)} {v}" for k,v in lane_counter.most_common(6)) or '-'
    lines = [x for x in str(base.get('summary_text') or '').split('\n')]
    stale_txt = ' / '.join(f'{k} {v}' for k,v in stale_counter.most_common(6)) or '-'
    block = [
        '[코인 종합품질 · v658]',
        f"- 평균품질 {avg} / 분류: {cnt_txt}",
        '- 기준: 전략명은 구조태그로 유지, 매수판단은 구조·돈흐름·확인신호·실행위험·신선도 점수로 봉인',
        '[정보 오래됨 원인 · v658]',
        f'- 원인 TOP: {stale_txt}',
    ]
    if good:
        block.append('- 살릴 후보 TOP: ' + ' / '.join(f"{x['ticker']} {x['stage']} Q{x['q']} R{x['risk']}" for x in good[:5]))
    if stale_good:
        block.append('- 고품질 stale 재수집 TOP: ' + ' / '.join(f"{x['ticker']} {x['stage']} Q{x['q']} {'/'.join(x['stale'][:2])}" for x in stale_good[:5]))
    if hold_s3:
        block.append('[고품질 S3 미승격 · v658]')
        block.append('- 원인 TOP: ' + ' / '.join(f"{x['ticker']} Q{x['q']} R{x['risk']}: {'; '.join(x['hold'][:3]) or '-'}" for x in hold_s3[:5]))
    if risk:
        block.append('- 추격/실행위험 TOP: ' + ' / '.join(f"{x['ticker']} {x['stage']} Q{x['q']} R{x['risk']}" for x in risk[:5]))
    insert_at = 0
    for i,line in enumerate(lines):
        if 'S1 직전 후보 TOP' in line or line.startswith('S1 직전 후보'):
            insert_at = i
            break
    else:
        insert_at = min(len(lines), 8)
    lines[insert_at:insert_at] = block
    base['summary_text'] = '\n'.join(lines)
    bs = base.get('batch_state') if isinstance(base.get('batch_state'), dict) else {}
    bs['schema'] = 'candidate_reason_batch_state_v658_stale_hold_reason'
    bs['coin_quality_v658'] = {'avg': avg, 'lane_counts': dict(lane_counter), 'stale_origin_top': dict(stale_counter), 'good_top': good[:10], 'stale_good_top': stale_good[:10], 'hold_s3_top': hold_s3[:10], 'risk_top': risk[:10]}
    base['batch_state'] = bs
    base['schema'] = 'candidate_reason_summary_text_v658_stale_hold_reason'
    return base


# =============================================================================
# strategy_worker v0.152 / v659: candle priority + trigger structure audit
# - 조건/청산/자동매수는 변경하지 않는다.
# - strategy_worker는 trigger 구조 근거와 candle stale 원인을 canonical row/text cache에 봉인한다.
# - target_router/candle_worker가 쓸 candle urgent priority request만 추가한다.
# =============================================================================
V659_STRATEGY_BUILD = 'strategy_worker_v0.156_v663_trigger_source_owner'


def _v659_age(row: Dict[str, Any], *keys: str, default: float = -1.0) -> float:
    for k in keys:
        v = _v510_num(row.get(k), default=None)
        if v is not None:
            return float(v)
    return default


def _v659_trigger_audit(row: Dict[str, Any]) -> Dict[str, Any]:
    if not isinstance(row, dict):
        return {'schema': 'trigger_structure_audit_v659', 'status': 'invalid_row'}
    levels = row.get('structure_levels') if isinstance(row.get('structure_levels'), dict) else {}
    plan = row.get('entry_plan') if isinstance(row.get('entry_plan'), dict) else {}
    tg = row.get('trigger_gate') if isinstance(row.get('trigger_gate'), dict) else {}
    canon = row.get('canonical_metric_row') if isinstance(row.get('canonical_metric_row'), dict) else {}
    if not tg and isinstance(canon.get('trigger_gate'), dict):
        tg = canon.get('trigger_gate') or {}
    price = _v510_num(tg.get('current_price'), row.get('current_price'), row.get('entry_price'), row.get('price'), default=0.0)
    trigger = _v510_num(tg.get('trigger_price'), levels.get('trigger_price'), plan.get('trigger_price'), row.get('trigger_price'), default=0.0)
    gap = _v510_num(tg.get('trigger_gap_pct'), default=None)
    if gap is None and price and trigger:
        try:
            gap = round((price - trigger) / trigger * 100.0, 3)
        except Exception:
            gap = None
    source = 'missing'
    if _v510_num(levels.get('trigger_price'), default=0.0) > 0:
        source = 'structure_levels'
    elif _v510_num(plan.get('trigger_price'), default=0.0) > 0:
        source = 'entry_plan'
    elif _v510_num(row.get('trigger_price'), default=0.0) > 0:
        source = 'row_trigger_price'
    line_quality = str(levels.get('structure_line_quality') or '')
    trigger_conf = _v510_num(levels.get('trigger_confidence'), default=-1.0)
    support_conf = _v510_num(levels.get('support_confidence'), default=-1.0)
    candle_age = _v659_age(row, 'official_candle_age', 'candle_age_sec', 'candle_age', default=-1.0)
    stale_obj = row.get('stale_origin_v658') if isinstance(row.get('stale_origin_v658'), dict) else {}
    top_sources = _v656_list(stale_obj.get('top_sources'), 8) if isinstance(stale_obj, dict) else []
    has_candle_stale = any(str(x).startswith('candle') for x in top_sources) or any('candle' in str(x).lower() or '캔들' in str(x) for x in _v656_list(row.get('stale_reasons'), 12))
    status = str(tg.get('status') or ('trigger_missing' if not trigger else ('trigger_reached' if price and trigger and price >= trigger * 0.999 else 'trigger_wait')))
    risk_flags: List[str] = []
    if source == 'missing':
        risk_flags.append('trigger_source_missing')
    if line_quality in ('calculated_line_recheck', 'official_reactive_line_watch', 'reactive_line_watch'):
        risk_flags.append('line_quality_recheck')
    if 0 <= trigger_conf < 45:
        risk_flags.append('trigger_conf_low')
    if 0 <= support_conf < 35:
        risk_flags.append('support_conf_low')
    if candle_age > 90 or has_candle_stale:
        risk_flags.append('candle_stale')
    if gap is not None and gap < -1.2:
        risk_flags.append('trigger_too_far')
    if gap is not None and gap > 1.0 and not bool(tg.get('trigger_reached')):
        risk_flags.append('trigger_gap_inconsistent')
    reason = str(tg.get('reason') or '')
    if source == 'missing':
        reason = '방아쇠 가격 없음'
    elif status == 'trigger_wait' and not reason:
        reason = f"방아쇠 대기: gap {gap if gap is not None else '-'}%"
    elif status == 'trigger_reached' and not reason:
        reason = '방아쇠 도달 확인'
    return {
        'schema': 'trigger_structure_audit_v659',
        'build': V659_STRATEGY_BUILD,
        'status': status,
        'source': source,
        'current_price': round(price, 8) if price else None,
        'trigger_price': round(trigger, 8) if trigger else None,
        'trigger_gap_pct': gap,
        'trigger_reason': levels.get('trigger_reason') or plan.get('trigger_reason') or reason,
        'plan_type': levels.get('plan_type') or plan.get('plan_type') or '-',
        'line_quality': line_quality or '-',
        'trigger_confidence': trigger_conf if trigger_conf >= 0 else None,
        'support_confidence': support_conf if support_conf >= 0 else None,
        'candle_age_sec': round(candle_age, 1) if candle_age >= 0 else None,
        'stale_top': top_sources[:6],
        'risk_flags': risk_flags,
        'reason': reason or '-',
        'policy': 'trigger는 strategy_worker가 봉인한 structure_levels/entry_plan 기준만 감사한다. 조건/청산/자동매수 변경 없음.',
    }


_v659_prev_v656_attach_coin_quality = _v656_attach_coin_quality

def _v656_attach_coin_quality(rows: List[Dict[str, Any]], nowv: float) -> Tuple[List[Dict[str, Any]], Dict[str, Any]]:  # type: ignore[override]
    rows2, qsum = _v659_prev_v656_attach_coin_quality(rows, nowv)
    trig_counter: Counter = Counter()
    risk_counter: Counter = Counter()
    candle_stale_highq = 0
    for rr in rows2 or []:
        if not isinstance(rr, dict):
            continue
        audit = _v659_trigger_audit(rr)
        rr['trigger_structure_audit_v659'] = audit
        ctx = rr.get('entry_context') if isinstance(rr.get('entry_context'), dict) else {}
        ctx = dict(ctx)
        ctx['trigger_structure_audit_v659'] = audit
        rr['entry_context'] = ctx
        canon = rr.get('canonical_metric_row') if isinstance(rr.get('canonical_metric_row'), dict) else {}
        canon = dict(canon)
        canon['trigger_structure_audit_v659'] = audit
        rr['canonical_metric_row'] = canon
        trig_counter[str(audit.get('status') or '-')] += 1
        for flag in audit.get('risk_flags') or []:
            risk_counter[str(flag)] += 1
        q = _v510_num(rr.get('coin_quality_score'), default=0.0)
        risk = _v510_num(rr.get('execution_risk_score'), default=99.0)
        if q >= 62 and risk <= 55 and ('candle_stale' in (audit.get('risk_flags') or [])):
            candle_stale_highq += 1
    if isinstance(qsum, dict):
        qsum = dict(qsum)
    else:
        qsum = {}
    qsum['v659_trigger_audit_summary'] = {
        'schema': 'trigger_audit_summary_v659',
        'version': VERSION,
        'trigger_status_counts': dict(trig_counter),
        'trigger_risk_top': dict(risk_counter.most_common(8)),
        'high_quality_candle_stale_count': candle_stale_highq,
        'policy': 'trigger 감사/표시만 추가. S1 조건 완화 없음.',
    }
    return rows2, qsum


_v659_prev_attach_s2_fresh_urgent_requests = _v574_attach_s2_fresh_urgent_requests

def _v574_attach_s2_fresh_urgent_requests(rows: List[Dict[str, Any]], priority_requests: List[Dict[str, Any]], nowv: float) -> Tuple[List[Dict[str, Any]], Dict[str, Any]]:  # type: ignore[override]
    out_reqs, base_summary = _v659_prev_attach_s2_fresh_urgent_requests(rows, priority_requests, nowv)
    out_reqs = list(out_reqs or [])
    seen = {(ticker_norm(r.get('ticker')), str(r.get('bucket') or '')) for r in out_reqs if isinstance(r, dict)}
    added: List[Dict[str, Any]] = []
    for r in rows or []:
        if not isinstance(r, dict):
            continue
        t = ticker_norm(r.get('ticker'))
        if not t:
            continue
        q = _v510_num(r.get('coin_quality_score'), default=0.0)
        risk = _v510_num(r.get('execution_risk_score'), default=99.0)
        audit = r.get('trigger_structure_audit_v659') if isinstance(r.get('trigger_structure_audit_v659'), dict) else _v659_trigger_audit(r)
        flags = [str(x) for x in (audit.get('risk_flags') or [])]
        lane = str(r.get('quality_lane') or '')
        stage = _v510_stage(r)
        trigger_wait = str(audit.get('status') or '') == 'trigger_wait'
        needs_candle = 'candle_stale' in flags or lane == 'quality_info_urgent' or (trigger_wait and q >= 58)
        worth = bool((q >= 62 and risk <= 55) or (stage == 'S2' and q >= 55) or lane == 'quality_s2_recheck')
        if not (needs_candle and worth):
            continue
        bucket = 'coin_quality_candle_trigger_urgent_v659'
        key = (t, bucket)
        if key in seen:
            continue
        seen.add(key)
        pri = 1180.0 + min(120.0, q) - min(45.0, risk / 2.0)
        if stage == 'S2':
            pri += 90.0
        if trigger_wait:
            pri += 45.0
        req = {
            'ticker': t,
            'bucket': bucket,
            'sub_bucket': 'candle_stale_trigger_wait' if trigger_wait else 'candle_stale_quality',
            'priority': round(pri, 3),
            'need': ['candle'],
            'need_candle': True,
            'required_age_sec': 35,
            'target_age': 35,
            'source': 'strategy_worker_v659_candle_trigger_priority',
            'stage': stage,
            'quality_lane': lane,
            'coin_quality_score': q,
            'execution_risk_score': risk,
            'trigger_status': audit.get('status'),
            'trigger_gap_pct': audit.get('trigger_gap_pct'),
            'trigger_source': audit.get('source'),
            'trigger_risk_flags': flags[:8],
            'reasons': _v656_list(r.get('quality_s3_hold_reasons_v658'), 4) + _v656_list(r.get('quality_lane_reasons'), 4),
            'updated_ts': nowv,
            'updated_text': now_text(nowv),
            'policy': '고품질/S2/trigger_wait 후보 중 candle stale 후보만 candle 우선보강. 후보 수 고정제한 아님.',
        }
        out_reqs.append(req)
        added.append(req)
    if isinstance(base_summary, dict):
        base_summary = dict(base_summary)
    else:
        base_summary = {}
    base_summary['v659_candle_trigger_urgent_summary'] = {
        'schema': 'candle_trigger_urgent_requests_v659',
        'version': VERSION,
        'added_count': len(added),
        'targets': [x.get('ticker') for x in added[:20]],
        'trigger_status_counts': dict(Counter(str(x.get('trigger_status') or '-') for x in added)),
        'policy': 'strategy_worker가 candle_worker로 넘길 고품질/방아쇠대기 candle urgent 요청을 만든다.',
    }
    base_summary['schema'] = 'strategy_s2_fresh_urgent_summary_v659_candle_trigger'
    return out_reqs, base_summary


_v659_prev_build_candidate_reason_summary = _v557_build_candidate_reason_summary

def _v557_build_candidate_reason_summary(display_rows: List[Dict[str, Any]], counts: Dict[str, int], reason_top: Any, nowv: float) -> Dict[str, Any]:  # type: ignore[override]
    base = _v659_prev_build_candidate_reason_summary(display_rows, counts, reason_top, nowv)
    text = str(base.get('summary_text') or '') if isinstance(base, dict) else ''
    rows = [r for r in (display_rows or []) if isinstance(r, dict)]
    audits: List[Dict[str, Any]] = []
    for r in rows:
        a = r.get('trigger_structure_audit_v659') if isinstance(r.get('trigger_structure_audit_v659'), dict) else _v659_trigger_audit(r)
        q = _v510_num(r.get('coin_quality_score'), default=0.0)
        risk = _v510_num(r.get('execution_risk_score'), default=99.0)
        stage = _v510_stage(r)
        if stage in ('S1','S2') or q >= 62 or str(a.get('status')) in ('trigger_wait','trigger_missing'):
            audits.append({'ticker': ticker_norm(r.get('ticker')), 'stage': stage, 'q': round(q,1), 'risk': round(risk,1), 'audit': a})
    status_counter = Counter(str(x['audit'].get('status') or '-') for x in audits)
    flag_counter: Counter = Counter()
    for x in audits:
        for f in x['audit'].get('risk_flags') or []:
            flag_counter[str(f)] += 1
    wait_rows = [x for x in audits if str(x['audit'].get('status')) in ('trigger_wait','trigger_missing')]
    wait_rows.sort(key=lambda x: (0 if x['stage']=='S2' else 1, -float(x['q']), float(x['risk'])))
    def _fmt_audit(x: Dict[str, Any]) -> str:
        a = x['audit']
        gap = a.get('trigger_gap_pct')
        gap_txt = '-' if gap is None else f"{float(gap):+.2f}%"
        flags = ','.join(str(f) for f in (a.get('risk_flags') or [])[:3]) or 'ok'
        conf = a.get('trigger_confidence')
        conf_txt = '-' if conf is None else f"{float(conf):.0f}"
        c_age = a.get('candle_age_sec')
        c_txt = '-' if c_age is None else f"{float(c_age):.0f}s"
        return f"{x['ticker']} {x['stage']} Q{x['q']} gap {gap_txt} src {a.get('source')} conf {conf_txt} candle {c_txt} {flags}"
    block = [
        '[방아쇠 구조검증 · v659]',
        '- 상태 TOP: ' + (' / '.join(f'{k} {v}' for k,v in status_counter.most_common(5)) if status_counter else '-'),
        '- 의심 TOP: ' + (' / '.join(f'{k} {v}' for k,v in flag_counter.most_common(6)) if flag_counter else '-'),
        '- 대기/누락 TOP: ' + (' / '.join(_fmt_audit(x) for x in wait_rows[:5]) if wait_rows else '-'),
        '- 기준: trigger_price는 strategy_worker structure_levels/entry_plan 봉인값만 감사. 방아쇠 미도달은 OPEN 금지 유지.',
    ]
    if text:
        # v658 블록 뒤에 붙여 main은 계속 worker text cache만 읽게 한다.
        text = text.rstrip() + '\n' + '\n'.join(block)
    else:
        text = '\n'.join(block)
    if isinstance(base, dict):
        base = dict(base)
    else:
        base = {}
    base['summary_text'] = text
    bs = base.get('batch_state') if isinstance(base.get('batch_state'), dict) else {}
    bs = dict(bs)
    bs['schema'] = 'candidate_reason_batch_state_v659_candle_trigger_audit'
    bs['trigger_audit_v659'] = {
        'status_counts': dict(status_counter),
        'risk_top': dict(flag_counter.most_common(8)),
        'wait_top': wait_rows[:10],
    }
    base['batch_state'] = bs
    base['schema'] = 'candidate_reason_summary_text_v659_candle_trigger_audit'
    return base



# =============================================================================
# strategy_worker v0.156 / v663: trigger source owner + source-missing 분해
# - v662에서 trigger audit은 보였지만 source_missing이 대량 발생했다.
# - 원인은 coin_quality/trigger audit이 entry_plan 생성 전에도 돌 수 있어, 이미 missing audit이
#   row에 남는 경로가 있었기 때문이다.
# - 여기서는 entry_plan/structure_levels 생성 직후 trigger source owner를 다시 봉인한다.
# - 조건/S1/청산/자동매수는 변경하지 않는다.
# =============================================================================
V663_STRATEGY_BUILD = "strategy_worker_v0.157_v664_trigger_wait_lifecycle"


def _v663_trigger_source_name(row: Dict[str, Any], levels: Dict[str, Any], plan: Dict[str, Any]) -> str:
    fam = str(levels.get('strategy_family') or _v554_strategy_family(row) or 'common')
    plan_txt = ' '.join(str(x or '') for x in (levels.get('plan_type'), levels.get('trigger_reason'), plan.get('plan_type'), plan.get('trigger_reason')))
    if 'VWAP' in plan_txt or fam == 'sweep_vwap':
        return 'vwap_recovery_line'
    if 'EMA' in plan_txt or '방어' in plan_txt or fam in ('leader_flow','leader_momentum'):
        return 'vwap_ema_defense_rebreak'
    if '박스' in plan_txt:
        return 'box_break_line'
    if '저항' in plan_txt or '돌파' in plan_txt or fam in ('breakout','surge_rebreak','hot_rank'):
        return 'resistance_break_line'
    if '눌림' in plan_txt or '재가속' in plan_txt or fam == 'money_reaccel':
        return 'pullback_reaccel_line'
    if _v510_num(levels.get('trigger_price'), default=0.0) > 0:
        return 'structure_levels_generic'
    if _v510_num(plan.get('trigger_price'), default=0.0) > 0:
        return 'entry_plan_generic'
    return 'missing'


def _v663_trigger_confidence(row: Dict[str, Any], levels: Dict[str, Any], plan: Dict[str, Any], source: str, candle_age: float) -> float:
    q = _v510_num(row.get('coin_quality_score'), default=0.0)
    structure = _v510_num(row.get('structure_score'), default=0.0)
    confirm = _v510_num(row.get('confirmation_score'), default=0.0)
    risk = _v510_num(row.get('execution_risk_score'), default=60.0)
    conf = 40.0
    if source not in ('missing','trigger_not_applicable'):
        conf += 18.0
    if source in ('vwap_recovery_line','vwap_ema_defense_rebreak','resistance_break_line','pullback_reaccel_line','box_break_line'):
        conf += 10.0
    if structure >= 55:
        conf += 10.0
    elif structure < 45:
        conf -= 8.0
    if confirm >= 55:
        conf += 6.0
    if q >= 70:
        conf += 6.0
    if risk >= 65:
        conf -= 12.0
    if candle_age > 180:
        conf -= 18.0
    elif candle_age > 90:
        conf -= 10.0
    if bool(row.get('coverage_only_v661')) or bool(row.get('coverage_light_v662')):
        conf -= 22.0
    return round(_v656_clamp(conf, 0.0, 100.0), 1)


def _v663_missing_reasons(row: Dict[str, Any], levels: Dict[str, Any], plan: Dict[str, Any], source: str, candle_age: float, conf: float) -> List[str]:
    reasons: List[str] = []
    if source == 'missing':
        if _v510_num(row.get('current_price'), row.get('entry_price'), row.get('price'), default=0.0) <= 0:
            reasons.append('price_missing')
        if candle_age < 0:
            reasons.append('candle_missing')
        elif candle_age > 90:
            reasons.append('candle_stale')
        reasons.append('no_structure_line')
    if source in ('structure_levels_generic','entry_plan_generic'):
        reasons.append('generic_structure_line')
    if source == 'resistance_break_line' and ('hot-rank' in _v656_blob(row).lower() or '급등' in _v656_blob(row)):
        reasons.append('only_hot_rank_or_breakout_watch')
    if conf < 45:
        reasons.append('line_conf_low')
    if bool(row.get('coverage_only_v661')) or bool(row.get('coverage_light_v662')):
        reasons.append('coverage_observe_only')
    return _v510_uniq(reasons, 8)


def _v659_trigger_audit(row: Dict[str, Any]) -> Dict[str, Any]:  # type: ignore[override]
    """v663: entry_plan/structure_levels 생성 이후의 trigger source owner.

    이전 v659/v662 audit이 entry_plan 생성 전 row를 보고 missing을 봉인하는 경로가 있었기 때문에,
    같은 함수명을 재정의해 이후 모든 writer/urgent 요청이 최신 source owner를 보게 한다.
    """
    if not isinstance(row, dict):
        return {'schema': 'trigger_structure_audit_v663', 'status': 'invalid_row', 'source': 'invalid'}
    levels = row.get('structure_levels') if isinstance(row.get('structure_levels'), dict) else {}
    plan = row.get('entry_plan') if isinstance(row.get('entry_plan'), dict) else {}
    tg = row.get('trigger_gate') if isinstance(row.get('trigger_gate'), dict) else {}
    canon = row.get('canonical_metric_row') if isinstance(row.get('canonical_metric_row'), dict) else {}
    if not levels and isinstance(canon.get('structure'), dict):
        st_obj = canon.get('structure') or {}
        if isinstance(st_obj.get('levels'), dict):
            levels = st_obj.get('levels') or {}
    if not plan and isinstance(canon.get('entry_plan'), dict):
        plan = canon.get('entry_plan') or {}
    if not tg and isinstance(canon.get('trigger_gate'), dict):
        tg = canon.get('trigger_gate') or {}

    price = _v510_num(tg.get('current_price'), row.get('current_price'), row.get('entry_price'), row.get('price'), default=0.0)
    level_trigger = _v510_num(levels.get('trigger_price'), default=0.0)
    plan_trigger = _v510_num(plan.get('trigger_price'), default=0.0)
    row_trigger = _v510_num(row.get('trigger_price'), default=0.0)
    trigger = _v510_num(tg.get('trigger_price'), level_trigger, plan_trigger, row_trigger, default=0.0)
    source = _v663_trigger_source_name(row, levels, plan)
    if trigger <= 0 and row_trigger > 0:
        source = 'row_trigger_price'
        trigger = row_trigger
    gap = _v510_num(tg.get('trigger_gap_pct'), default=None)
    if gap is None and price and trigger:
        try:
            gap = round((price - trigger) / trigger * 100.0, 3)
        except Exception:
            gap = None
    candle_age = _v659_age(row, 'official_candle_age', 'official_candle_age_sec', 'candle_age_sec', 'candle_age', default=-1.0)
    stale_obj = row.get('stale_origin_v658') if isinstance(row.get('stale_origin_v658'), dict) else {}
    top_sources = _v656_list(stale_obj.get('top_sources'), 8) if isinstance(stale_obj, dict) else []
    has_candle_stale = any(str(x).startswith('candle') for x in top_sources) or any('candle' in str(x).lower() or '캔들' in str(x) for x in _v656_list(row.get('stale_reasons'), 12))
    if has_candle_stale and candle_age < 0:
        candle_age = 999.0
    conf = _v663_trigger_confidence(row, levels, plan, source, candle_age)
    if not trigger:
        status = 'trigger_missing'
    elif price and trigger and price >= trigger * 0.999:
        status = 'trigger_reached'
    else:
        status = 'trigger_wait'
    risk_flags: List[str] = []
    missing_reasons = _v663_missing_reasons(row, levels, plan, source, candle_age, conf)
    if source == 'missing':
        risk_flags.append('trigger_source_missing')
    for mr in missing_reasons:
        if mr not in risk_flags:
            risk_flags.append(mr)
    if candle_age > 90 or has_candle_stale:
        risk_flags.append('candle_stale')
    if conf < 45:
        risk_flags.append('trigger_conf_low')
    if gap is not None and gap < -1.2:
        risk_flags.append('trigger_too_far')
    if gap is not None and gap > 1.0 and status != 'trigger_reached':
        risk_flags.append('trigger_gap_inconsistent')
    risk_flags = _v510_uniq(risk_flags, 12)
    reason = str(levels.get('trigger_reason') or plan.get('trigger_reason') or tg.get('reason') or '')
    if source == 'missing':
        reason = '방아쇠 source 없음: ' + (', '.join(missing_reasons[:4]) if missing_reasons else 'no_structure_line')
    elif status == 'trigger_wait' and not reason:
        reason = f'방아쇠 대기: {source}'
    elif status == 'trigger_reached' and not reason:
        reason = f'방아쇠 도달: {source}'
    return {
        'schema': 'trigger_structure_audit_v663',
        'build': V663_STRATEGY_BUILD,
        'status': status,
        'source': source,
        'current_price': round(price, 8) if price else None,
        'trigger_price': round(trigger, 8) if trigger else None,
        'trigger_gap_pct': gap,
        'trigger_reason': reason,
        'plan_type': levels.get('plan_type') or plan.get('plan_type') or '-',
        'line_quality': source,
        'trigger_confidence': conf,
        'support_confidence': None,
        'candle_age_sec': round(candle_age, 1) if candle_age >= 0 else None,
        'stale_top': top_sources[:6],
        'risk_flags': risk_flags,
        'missing_reasons': missing_reasons,
        'reason': reason or '-',
        'policy': 'v663: trigger source owner는 entry_plan/structure_levels 생성 이후 strategy_worker가 봉인한다. fallback trigger로 S1 통과 금지.',
    }


def _v663_attach_trigger_source_owner(rows: List[Dict[str, Any]], nowv: float) -> List[Dict[str, Any]]:
    out: List[Dict[str, Any]] = []
    for r in rows or []:
        if not isinstance(r, dict):
            continue
        rr = dict(r)
        audit = _v659_trigger_audit(rr)
        rr['trigger_structure_audit_v659'] = audit
        rr['trigger_structure_audit_v663'] = audit
        rr['trigger_source_v663'] = audit.get('source')
        rr['trigger_confidence_v663'] = audit.get('trigger_confidence')
        rr['trigger_missing_reasons_v663'] = audit.get('missing_reasons') or []
        ctx = rr.get('entry_context') if isinstance(rr.get('entry_context'), dict) else {}
        ctx = dict(ctx)
        ctx['trigger_structure_audit_v663'] = audit
        rr['entry_context'] = ctx
        canon = rr.get('canonical_metric_row') if isinstance(rr.get('canonical_metric_row'), dict) else {}
        canon = dict(canon)
        canon['trigger_structure_audit_v663'] = audit
        canon['trigger_structure_audit_v659'] = audit
        rr['canonical_metric_row'] = canon
        out.append(rr)
    return out


_v663_prev_v554_apply_entry_plan_state = _v554_apply_entry_plan_state

def _v554_apply_entry_plan_state(rows: List[Dict[str, Any]], nowv: float) -> List[Dict[str, Any]]:  # type: ignore[override]
    rows2 = _v663_prev_v554_apply_entry_plan_state(rows, nowv)
    return _v663_attach_trigger_source_owner(rows2, nowv)


_v663_prev_attach_s2_fresh_urgent_requests = _v574_attach_s2_fresh_urgent_requests

def _v574_attach_s2_fresh_urgent_requests(rows: List[Dict[str, Any]], priority_requests: List[Dict[str, Any]], nowv: float) -> Tuple[List[Dict[str, Any]], Dict[str, Any]]:  # type: ignore[override]
    out_reqs, base_summary = _v663_prev_attach_s2_fresh_urgent_requests(rows, priority_requests, nowv)
    out_reqs = list(out_reqs or [])
    seen = {(ticker_norm(r.get('ticker')), str(r.get('bucket') or '')) for r in out_reqs if isinstance(r, dict)}
    added: List[Dict[str, Any]] = []
    for r in rows or []:
        if not isinstance(r, dict):
            continue
        t = ticker_norm(r.get('ticker'))
        if not t:
            continue
        audit = r.get('trigger_structure_audit_v663') if isinstance(r.get('trigger_structure_audit_v663'), dict) else _v659_trigger_audit(r)
        q = _v510_num(r.get('coin_quality_score'), default=0.0)
        risk = _v510_num(r.get('execution_risk_score'), default=99.0)
        stage = _v510_stage(r)
        flags = [str(x) for x in (audit.get('risk_flags') or [])]
        source_missing = 'trigger_source_missing' in flags or str(audit.get('source')) == 'missing'
        candle_issue = 'candle_stale' in flags or 'candle_missing' in flags
        worth = bool((q >= 62 and risk <= 55) or stage == 'S2')
        if not (worth and (source_missing or candle_issue)):
            continue
        bucket = 'quality_trigger_source_urgent_v663'
        key = (t, bucket)
        if key in seen:
            continue
        seen.add(key)
        need = ['candle', 'feature'] if source_missing else ['candle']
        pri = 1260.0 + min(150.0, q) - min(50.0, risk / 2.0)
        if stage == 'S2':
            pri += 100.0
        req = {
            'ticker': t,
            'bucket': bucket,
            'priority': round(pri, 3),
            'need': need,
            'need_candle': 'candle' in need,
            'need_feature': 'feature' in need,
            'required_age_sec': 30,
            'target_age': 30,
            'source': 'strategy_worker_v663_trigger_source_owner',
            'stage': stage,
            'coin_quality_score': q,
            'execution_risk_score': risk,
            'trigger_status': audit.get('status'),
            'trigger_source': audit.get('source'),
            'trigger_confidence': audit.get('trigger_confidence'),
            'trigger_missing_reasons': audit.get('missing_reasons') or [],
            'trigger_risk_flags': flags[:10],
            'reasons': _v656_list(r.get('quality_s3_hold_reasons_v658'), 4) + flags[:4],
            'updated_ts': nowv,
            'updated_text': now_text(nowv),
            'policy': '고품질/S2 후보 중 trigger source missing 또는 candle stale인 경우 구조재료 우선 갱신. S1 조건 완화 없음.',
        }
        out_reqs.append(req)
        added.append(req)
    if isinstance(base_summary, dict):
        base_summary = dict(base_summary)
    else:
        base_summary = {}
    base_summary['v663_trigger_source_urgent_summary'] = {
        'schema': 'trigger_source_urgent_requests_v663',
        'version': VERSION,
        'added_count': len(added),
        'targets': [x.get('ticker') for x in added[:20]],
        'reason_top': dict(Counter('/'.join(str(y) for y in (x.get('trigger_missing_reasons') or [])) or str(x.get('trigger_source')) for x in added).most_common(8)),
        'policy': 'trigger source owner가 missing/candle 원인을 쪼개고 고품질 후보만 candle/feature urgent로 보낸다.',
    }
    base_summary['schema'] = 'strategy_s2_fresh_urgent_summary_v663_trigger_source'
    return out_reqs, base_summary


def _v663_remove_old_trigger_blocks(text: str) -> str:
    markers = ('[방아쇠 구조검증 · v659]', '[방아쇠 구조검증 · v662]', '[방아쇠 source 검증 · v663]')
    lines = str(text or '').splitlines()
    out: List[str] = []
    skip = False
    for line in lines:
        if any(m in line for m in markers):
            skip = True
            continue
        if skip and line.startswith('['):
            skip = False
        if not skip:
            out.append(line)
    return '\n'.join(out).strip()


def _v663_trigger_source_summary_text(base_summary: Dict[str, Any], display_rows: List[Dict[str, Any]], nowv: float) -> Dict[str, Any]:
    base = dict(base_summary or {})
    text = _v663_remove_old_trigger_blocks(str(base.get('summary_text') or ''))
    rows = [r for r in (display_rows or []) if isinstance(r, dict)]
    audits: List[Dict[str, Any]] = []
    for r in rows:
        if bool(r.get('coverage_only_v661')) or bool(r.get('coverage_light_v662')):
            continue
        audit = r.get('trigger_structure_audit_v663') if isinstance(r.get('trigger_structure_audit_v663'), dict) else _v659_trigger_audit(r)
        q = _v510_num(r.get('coin_quality_score'), default=0.0)
        risk = _v510_num(r.get('execution_risk_score'), default=99.0)
        stage = _v510_stage(r)
        if stage in ('S1','S2') or q >= 58 or str(audit.get('status')) in ('trigger_wait','trigger_missing'):
            audits.append({'ticker': _v661_row_ticker(r), 'stage': stage, 'q': round(q,1), 'risk': round(risk,1), 'audit': audit})
    status_counter = Counter(str(x['audit'].get('status') or '-') for x in audits)
    source_counter = Counter(str(x['audit'].get('source') or '-') for x in audits)
    missing_counter: Counter = Counter()
    flag_counter: Counter = Counter()
    for x in audits:
        for f in x['audit'].get('risk_flags') or []:
            flag_counter[str(f)] += 1
        for m in x['audit'].get('missing_reasons') or []:
            missing_counter[str(m)] += 1
    wait_rows = [x for x in audits if str(x['audit'].get('status')) in ('trigger_wait','trigger_missing')]
    wait_rows.sort(key=lambda x: (0 if x['stage']=='S2' else 1, -float(x['q']), float(x['risk'])))
    def fmt(x: Dict[str, Any]) -> str:
        a = x['audit']
        gap = a.get('trigger_gap_pct')
        gap_txt = '-' if gap is None else f"{float(gap):+.2f}%"
        trig = a.get('trigger_price')
        trig_txt = '-' if trig in (None, '') else f"{float(trig):.8g}"
        cur = a.get('current_price')
        cur_txt = '-' if cur in (None, '') else f"{float(cur):.8g}"
        conf = a.get('trigger_confidence')
        conf_txt = '-' if conf is None else f"{float(conf):.0f}"
        c_age = a.get('candle_age_sec')
        c_txt = '-' if c_age is None else f"{float(c_age):.0f}s"
        flags = ','.join(str(f) for f in (a.get('risk_flags') or [])[:3]) or 'ok'
        return f"{x['ticker']} {x['stage']} Q{x['q']} 현재 {cur_txt} / 방아쇠 {trig_txt} / gap {gap_txt} / src {a.get('source')} / conf {conf_txt} / candle {c_txt} / {flags}"
    block = [
        '[방아쇠 source 검증 · v663]',
        '- 상태 TOP: ' + (' / '.join(f'{k} {v}' for k, v in status_counter.most_common(6)) if status_counter else '-'),
        '- source TOP: ' + (' / '.join(f'{k} {v}' for k, v in source_counter.most_common(6)) if source_counter else '-'),
        '- 누락/의심 TOP: ' + (' / '.join(f'{k} {v}' for k, v in (missing_counter + flag_counter).most_common(8)) if (missing_counter or flag_counter) else '-'),
        '- S2/고품질 TOP: ' + (' / '.join(fmt(x) for x in wait_rows[:6]) if wait_rows else '-'),
        '- 기준: trigger source는 entry_plan/structure_levels 생성 이후 봉인. source/confidence 없는 S1 승격 금지.',
    ]
    lines = text.splitlines() if text else []
    insert_at = min(len(lines), 7)
    for i, line in enumerate(lines):
        if '[fresh_wait 상세' in line or '[코인 종합품질' in line:
            insert_at = i
            break
    lines[insert_at:insert_at] = block
    base['summary_text'] = '\n'.join(lines)
    bs = base.get('batch_state') if isinstance(base.get('batch_state'), dict) else {}
    bs = dict(bs)
    bs['schema'] = 'candidate_reason_batch_state_v663_trigger_source_owner'
    bs['trigger_source_v663'] = {
        'status_counts': dict(status_counter),
        'source_top': dict(source_counter.most_common(8)),
        'missing_top': dict(missing_counter.most_common(8)),
        'risk_top': dict(flag_counter.most_common(8)),
        'wait_top': wait_rows[:12],
    }
    base['batch_state'] = bs
    base['schema'] = 'candidate_reason_summary_text_v663_trigger_source_owner'
    return base




# strategy_worker v0.157 / v664: trigger_wait 생애주기 추적
# - v663에서 source는 잡혔지만 S2가 trigger_wait에서 멈췄다.
# - 여기서는 S1 조건을 완화하지 않고, trigger_wait 후보가 다음 cycle에 도달/미도달/도달후차단인지 추적만 한다.
# - 상태 파일은 strategy_worker 소유이며 main은 summary_text만 읽는다.
TRIGGER_LIFECYCLE_STATE_V664 = BASE_DIR / "clean_trigger_wait_lifecycle_state_v664.json"
TRIGGER_LIFECYCLE_TRACE_V664 = BASE_DIR / "clean_trigger_wait_lifecycle_trace_v664.json"
V664_STRATEGY_BUILD = "strategy_worker_v0.157_v664_trigger_wait_lifecycle"


def _v664_trigger_key(row: Dict[str, Any]) -> str:
    return ticker_norm(row.get('ticker') or row.get('symbol') or row.get('market'))


def _v664_gap_bucket(gap: Any) -> str:
    try:
        g = float(gap)
    except Exception:
        return 'gap_unknown'
    # gap은 (현재-trigger)/trigger 기준. 음수면 방아쇠 아래.
    if g >= 0:
        return 'reached_or_above'
    ag = abs(g)
    if ag <= 0.10:
        return 'near_0_10'
    if ag <= 0.30:
        return 'near_0_30'
    if ag <= 0.50:
        return 'near_0_50'
    return 'far_wait'


def _v664_trigger_lifecycle_update(display_rows: List[Dict[str, Any]], nowv: float) -> Dict[str, Any]:
    """trigger_wait 후보 생애주기 추적.
    S1 승격/OPEN 조건은 바꾸지 않고, 도달 여부와 도달 후 차단 이유만 봉인한다.
    """
    prev_obj = load_json(TRIGGER_LIFECYCLE_STATE_V664, {}) or {}
    prev_active = prev_obj.get('active') if isinstance(prev_obj.get('active'), dict) else {}
    active: Dict[str, Dict[str, Any]] = {}
    events: List[Dict[str, Any]] = []
    wait_rows: List[Dict[str, Any]] = []
    now_rows_by_key: Dict[str, Dict[str, Any]] = {}
    for r in display_rows or []:
        if not isinstance(r, dict):
            continue
        key = _v664_trigger_key(r)
        if key:
            now_rows_by_key[key] = r
        audit = r.get('trigger_structure_audit_v663') if isinstance(r.get('trigger_structure_audit_v663'), dict) else (r.get('trigger_structure_audit_v659') if isinstance(r.get('trigger_structure_audit_v659'), dict) else None)
        if not isinstance(audit, dict):
            continue
        st = _v510_stage(r)
        q = _v510_num(r.get('coin_quality_score'), default=0.0)
        status = str(audit.get('status') or '')
        if status in ('trigger_wait', 'trigger_missing') and (st in ('S1','S2') or q >= 58):
            wait_rows.append(r)
    # 현재 wait 후보 업데이트
    for r in wait_rows:
        key = _v664_trigger_key(r)
        if not key:
            continue
        audit = r.get('trigger_structure_audit_v663') if isinstance(r.get('trigger_structure_audit_v663'), dict) else r.get('trigger_structure_audit_v659')
        audit = audit if isinstance(audit, dict) else {}
        cur = _v510_num(audit.get('current_price'), r.get('current_price'), r.get('price'), default=0.0)
        trigger = _v510_num(audit.get('trigger_price'), r.get('trigger_price'), default=0.0)
        gap = audit.get('trigger_gap_pct')
        try:
            gap = float(gap) if gap is not None else (round((cur-trigger)/trigger*100.0,3) if cur and trigger else None)
        except Exception:
            gap = None
        reached = bool(cur and trigger and cur >= trigger * 0.999)
        old = prev_active.get(key) if isinstance(prev_active.get(key), dict) else {}
        first_ts = _v510_num(old.get('first_seen_ts'), default=nowv) if old else nowv
        first_gap = old.get('first_gap_pct') if old else gap
        reached_ts = _v510_num(old.get('reached_ts'), default=0.0)
        if reached and not reached_ts:
            reached_ts = nowv
        stage = _v510_stage(r)
        reasons = _v656_list(r.get('block_reasons'), 4) + _v656_list(r.get('risk_tags'), 3)
        if reached and stage != 'S1':
            life_state = 'reached_but_blocked'
        elif reached and stage == 'S1':
            life_state = 'reached_s1'
        elif str(audit.get('status')) == 'trigger_missing' or not trigger:
            life_state = 'source_missing_wait'
        else:
            life_state = 'waiting_trigger'
        rec = {
            'ticker': key,
            'schema': 'trigger_wait_lifecycle_item_v664',
            'stage': stage,
            'coin_quality_score': round(_v510_num(r.get('coin_quality_score'), default=0.0), 2),
            'execution_risk_score': round(_v510_num(r.get('execution_risk_score'), default=0.0), 2),
            'first_seen_ts': first_ts,
            'first_seen_text': old.get('first_seen_text') if old else now_text(first_ts),
            'last_seen_ts': nowv,
            'last_seen_text': now_text(nowv),
            'age_sec': round(max(0.0, nowv - first_ts), 1),
            'current_price': cur or None,
            'trigger_price': trigger or None,
            'first_gap_pct': first_gap,
            'trigger_gap_pct': gap,
            'gap_bucket': _v664_gap_bucket(gap),
            'trigger_source': audit.get('source'),
            'trigger_confidence': audit.get('trigger_confidence'),
            'trigger_status': audit.get('status'),
            'candle_age_sec': audit.get('candle_age_sec'),
            'risk_flags': audit.get('risk_flags') or [],
            'missing_reasons': audit.get('missing_reasons') or [],
            'trigger_reached': reached,
            'reached_ts': reached_ts or None,
            'reached_text': now_text(reached_ts) if reached_ts else None,
            'life_state': life_state,
            'post_reach_block_reasons': reasons if reached and stage != 'S1' else [],
            'policy': 'v664: trigger_wait 생애주기 추적만 한다. 방아쇠 미도달 OPEN 금지와 S1 조건은 유지한다.',
        }
        active[key] = rec
        if old.get('life_state') != life_state or old.get('gap_bucket') != rec['gap_bucket']:
            events.append({'event': life_state, **{k: rec.get(k) for k in ('ticker','stage','coin_quality_score','trigger_gap_pct','gap_bucket','trigger_source','trigger_confidence','post_reach_block_reasons')}})
    # 이전 active 중 사라진 후보는 drop 처리 후 짧게 기록
    for key, old in (prev_active or {}).items():
        if not isinstance(old, dict) or key in active:
            continue
        age = max(0.0, nowv - _v510_num(old.get('first_seen_ts'), default=nowv))
        if age <= 1800:
            old2 = dict(old)
            old2['life_state'] = 'dropped_before_trigger' if not old2.get('trigger_reached') else 'dropped_after_reach'
            old2['dropped_ts'] = nowv
            old2['dropped_text'] = now_text(nowv)
            old2['age_sec'] = round(age,1)
            # 상태 추적용으로 10분만 유지
            if nowv - _v510_num(old2.get('last_seen_ts'), default=nowv) <= 600:
                active[key] = old2
    counts = Counter(str(v.get('life_state') or '-') for v in active.values())
    gap_counts = Counter(str(v.get('gap_bucket') or '-') for v in active.values())
    source_counts = Counter(str(v.get('trigger_source') or '-') for v in active.values())
    reached = [v for v in active.values() if v.get('trigger_reached')]
    blocked = [v for v in active.values() if v.get('life_state') == 'reached_but_blocked']
    near = [v for v in active.values() if v.get('gap_bucket') in ('near_0_10','near_0_30','reached_or_above')]
    near.sort(key=lambda x: (0 if x.get('stage') == 'S2' else 1, abs(_v510_num(x.get('trigger_gap_pct'), default=999.0)), -_v510_num(x.get('coin_quality_score'), default=0.0)))
    blocked.sort(key=lambda x: (-_v510_num(x.get('coin_quality_score'), default=0.0), abs(_v510_num(x.get('trigger_gap_pct'), default=999.0))))
    state = {
        'schema': 'trigger_wait_lifecycle_state_v664',
        'version': VERSION,
        'build': V664_STRATEGY_BUILD,
        'updated_ts': nowv,
        'updated_text': now_text(nowv),
        'active': active,
        'counts': dict(counts),
        'gap_counts': dict(gap_counts),
        'source_counts': dict(source_counts.most_common(8)),
        'reached_count': len(reached),
        'reached_but_blocked_count': len(blocked),
        'near_count': len(near),
        'events': events[-30:],
        'policy': 'trigger_wait 후보의 도달/미도달/drop/도달후차단을 추적한다. paper OPEN/S1 조건 변경 없음.',
    }
    save_json(TRIGGER_LIFECYCLE_STATE_V664, state)
    save_json(TRIGGER_LIFECYCLE_TRACE_V664, {k: state[k] for k in ('schema','version','build','updated_ts','updated_text','counts','gap_counts','source_counts','reached_count','reached_but_blocked_count','near_count','events','policy')})
    return {'state': state, 'near': near[:8], 'blocked': blocked[:8]}


def _v664_append_trigger_lifecycle_text(base_summary: Dict[str, Any], display_rows: List[Dict[str, Any]], nowv: float) -> Dict[str, Any]:
    base = dict(base_summary or {})
    try:
        life = _v664_trigger_lifecycle_update(display_rows, nowv)
        st = life.get('state') if isinstance(life.get('state'), dict) else {}
        counts = st.get('counts') if isinstance(st.get('counts'), dict) else {}
        gaps = st.get('gap_counts') if isinstance(st.get('gap_counts'), dict) else {}
        srcs = st.get('source_counts') if isinstance(st.get('source_counts'), dict) else {}
        near = life.get('near') if isinstance(life.get('near'), list) else []
        blocked = life.get('blocked') if isinstance(life.get('blocked'), list) else []
        def fmt_row(x: Dict[str, Any]) -> str:
            gap = x.get('trigger_gap_pct')
            gap_txt = '-' if gap is None else f"{float(gap):+.2f}%"
            cur = x.get('current_price')
            trg = x.get('trigger_price')
            cur_txt = '-' if cur in (None, '') else f"{float(cur):.8g}"
            trg_txt = '-' if trg in (None, '') else f"{float(trg):.8g}"
            post = x.get('post_reach_block_reasons') or []
            suffix = (' / 차단 ' + ','.join(str(y) for y in post[:2])) if post else ''
            return f"{x.get('ticker')} {x.get('stage')} Q{x.get('coin_quality_score')} 현재 {cur_txt}/방아쇠 {trg_txt}/gap {gap_txt}/{x.get('gap_bucket')}/{x.get('trigger_source')}{suffix}"
        block = [
            '[방아쇠 생애주기 · v664]',
            '- 상태 TOP: ' + (' / '.join(f'{k} {v}' for k, v in Counter(counts).most_common(6)) if counts else '-'),
            '- gap TOP: ' + (' / '.join(f'{k} {v}' for k, v in Counter(gaps).most_common(6)) if gaps else '-'),
            '- source TOP: ' + (' / '.join(f'{k} {v}' for k, v in Counter(srcs).most_common(6)) if srcs else '-'),
            f"- 도달 {st.get('reached_count',0)} / 도달후차단 {st.get('reached_but_blocked_count',0)} / 근접 {st.get('near_count',0)}",
            '- 근접 TOP: ' + (' / '.join(fmt_row(x) for x in near[:5]) if near else '-'),
            '- 도달후차단 TOP: ' + (' / '.join(fmt_row(x) for x in blocked[:5]) if blocked else '-'),
            '- 기준: 방아쇠 생애주기는 추적 전용. S1 조건/OPEN/청산 변경 없음.',
        ]
        text = str(base.get('summary_text') or '')
        # 기존 생애주기 블록 제거 후 방아쇠 source 검증 뒤에 삽입
        lines = []
        skip = False
        for line in text.splitlines():
            if '[방아쇠 생애주기 · v664]' in line:
                skip = True
                continue
            if skip and line.startswith('['):
                skip = False
            if not skip:
                lines.append(line)
        insert_at = min(len(lines), 12)
        for i, line in enumerate(lines):
            if '[fresh_wait 상세' in line or '[코인 종합품질' in line:
                insert_at = i
                break
        lines[insert_at:insert_at] = block
        base['summary_text'] = '\n'.join(lines)
        bs = base.get('batch_state') if isinstance(base.get('batch_state'), dict) else {}
        bs = dict(bs)
        bs['trigger_lifecycle_v664'] = {k: st.get(k) for k in ('schema','counts','gap_counts','source_counts','reached_count','reached_but_blocked_count','near_count')}
        bs['schema'] = 'candidate_reason_batch_state_v664_trigger_lifecycle'
        base['batch_state'] = bs
        base['schema'] = 'candidate_reason_summary_text_v664_trigger_lifecycle'
    except Exception as exc:
        append_error(ERROR, 'v664_trigger_lifecycle_text', exc)
    return base


# v662 writer hook을 v663 source owner text로 교체한다.
def _v661_append_trigger_audit_text(v557_summary: Dict[str, Any], display_rows: List[Dict[str, Any]], nowv: float) -> Dict[str, Any]:  # type: ignore[override]
    base = _v663_trigger_source_summary_text(v557_summary, display_rows, nowv)
    return _v664_append_trigger_lifecycle_text(base, display_rows, nowv)



# =============================================================================
# strategy_worker v0.158 / v665: trigger shadow benchmark 후보 생산
# - 실제 S1/paper 조건은 유지한다.
# - trigger_wait/near 후보를 shadow 비교용 파일로만 저장한다.
# - review_worker가 이후 가격을 추적해 current/near/actual trigger 방식을 비교한다.
# =============================================================================
TRIGGER_SHADOW_CANDIDATES_V665 = BASE_DIR / "clean_trigger_shadow_candidates_v665.json"
TRIGGER_SHADOW_STRATEGY_SUMMARY_V665 = BASE_DIR / "clean_trigger_shadow_strategy_summary_v665.json"
V665_STRATEGY_BUILD = "strategy_worker_v0.158_v665_trigger_shadow_benchmark"


def _v665_shadow_num(*vals: Any, default: float = 0.0) -> float:
    return _v510_num(*vals, default=default)


def _v665_shadow_variant_rows(cur: float, trigger: float) -> List[Dict[str, Any]]:
    if not cur or not trigger:
        return []
    return [
        {'key': 'current_price', 'label': '현재가 즉시진입', 'entry_mode': 'immediate', 'threshold_price': cur},
        {'key': 'near_0_10', 'label': '방아쇠 -0.10%', 'entry_mode': 'threshold', 'threshold_price': trigger * 0.999},
        {'key': 'near_0_30', 'label': '방아쇠 -0.30%', 'entry_mode': 'threshold', 'threshold_price': trigger * 0.997},
        {'key': 'actual_trigger', 'label': '기존 방아쇠', 'entry_mode': 'threshold', 'threshold_price': trigger},
    ]


def _v665_shadow_candidate_from_row(row: Dict[str, Any], nowv: float, source_hint: str = 'display_row') -> Optional[Dict[str, Any]]:
    if not isinstance(row, dict):
        return None
    t = _v661_row_ticker(row)
    if not t:
        return None
    audit = row.get('trigger_structure_audit_v663') if isinstance(row.get('trigger_structure_audit_v663'), dict) else (row.get('trigger_structure_audit_v659') if isinstance(row.get('trigger_structure_audit_v659'), dict) else {})
    levels = row.get('structure_levels') if isinstance(row.get('structure_levels'), dict) else {}
    plan = row.get('entry_plan') if isinstance(row.get('entry_plan'), dict) else {}
    cur = _v665_shadow_num(audit.get('current_price'), row.get('current_price'), row.get('price'), row.get('trade_price'), row.get('entry_price'), default=0.0)
    trig = _v665_shadow_num(audit.get('trigger_price'), row.get('trigger_price'), levels.get('trigger_price'), plan.get('trigger_price'), default=0.0)
    if cur <= 0 or trig <= 0:
        return None
    q = _v665_shadow_num(row.get('coin_quality_score'), row.get('score'), default=0.0)
    risk = _v665_shadow_num(row.get('execution_risk_score'), default=0.0)
    stage = _v510_stage(row)
    gap = round((cur - trig) / trig * 100.0, 3) if trig else None
    status = str(audit.get('status') or ('trigger_wait' if cur < trig else 'reached_or_above'))
    # shadow는 S2/고품질/trigger 근접/trigger_wait만 저장한다. coverage-only 저품질 row는 제외.
    if bool(row.get('coverage_only_v661') or row.get('coverage_light_v662')) and q < 65:
        return None
    if not (stage in ('S1','S2') or q >= 60 or status in ('trigger_wait','reached_or_above') or (gap is not None and gap >= -0.60)):
        return None
    src = str(audit.get('source') or row.get('trigger_source_v663') or plan.get('trigger_reason') or levels.get('trigger_source') or '-')
    variants = _v665_shadow_variant_rows(cur, trig)
    if not variants:
        return None
    key_base = f"{t}|{src}|{round(trig,8)}"
    return {
        'schema': 'trigger_shadow_candidate_v665',
        'version': VERSION,
        'build': V665_STRATEGY_BUILD,
        'ticker': t,
        'stage': stage,
        'source_hint': source_hint,
        'event_key': row.get('event_key') or row.get('event_id') or key_base,
        'shadow_key_base': key_base,
        'created_ts': nowv,
        'created_text': now_text(nowv),
        'current_price': cur,
        'trigger_price': trig,
        'trigger_gap_pct': gap,
        'trigger_source': src,
        'trigger_status': status,
        'trigger_confidence': audit.get('trigger_confidence'),
        'candle_age_sec': audit.get('candle_age_sec'),
        'coin_quality_score': round(q, 3),
        'execution_risk_score': round(risk, 3),
        'structure_tags': row.get('structure_tags') if isinstance(row.get('structure_tags'), list) else [],
        'block_reasons': row.get('block_reasons') if isinstance(row.get('block_reasons'), list) else [],
        'risk_flags': audit.get('risk_flags') if isinstance(audit.get('risk_flags'), list) else [],
        'variants': variants,
        'policy': 'v665 shadow benchmark only. 실제 S1/paper OPEN/청산/자동매수 조건 변경 없음.',
    }


def _v665_publish_trigger_shadow_candidates(display_rows: List[Dict[str, Any]], nowv: float) -> Dict[str, Any]:
    rows: List[Dict[str, Any]] = []
    seen = set()
    for r in display_rows or []:
        cand = _v665_shadow_candidate_from_row(r, nowv, 'display_row')
        if cand and cand['shadow_key_base'] not in seen:
            rows.append(cand); seen.add(cand['shadow_key_base'])
    # v664 생애주기 active 중 drop/대기 후보도 shadow 후보로 유지한다.
    try:
        life = load_json(TRIGGER_LIFECYCLE_STATE_V664, {}) or {}
        active = life.get('active') if isinstance(life.get('active'), dict) else {}
        for v in active.values():
            if not isinstance(v, dict):
                continue
            if str(v.get('life_state') or '') not in ('waiting_trigger','dropped_before_trigger','reached_but_blocked'):
                continue
            q = _v665_shadow_num(v.get('coin_quality_score'), default=0.0)
            if q < 58 and str(v.get('stage') or '') != 'S2':
                continue
            row = {
                'ticker': v.get('ticker'), 'stage': v.get('stage'), 'current_price': v.get('current_price'),
                'trigger_price': v.get('trigger_price'), 'coin_quality_score': q,
                'execution_risk_score': v.get('execution_risk_score'),
                'trigger_source_v663': v.get('trigger_source'),
                'trigger_structure_audit_v663': {
                    'current_price': v.get('current_price'), 'trigger_price': v.get('trigger_price'),
                    'source': v.get('trigger_source'), 'status': 'trigger_wait',
                    'trigger_gap_pct': v.get('trigger_gap_pct'), 'trigger_confidence': v.get('trigger_confidence'),
                },
                'block_reasons': v.get('post_reach_block_reasons') or [],
            }
            cand = _v665_shadow_candidate_from_row(row, nowv, 'trigger_lifecycle_state')
            if cand and cand['shadow_key_base'] not in seen:
                cand['life_state'] = v.get('life_state')
                cand['first_seen_ts'] = v.get('first_seen_ts')
                cand['dropped_ts'] = v.get('dropped_ts')
                rows.append(cand); seen.add(cand['shadow_key_base'])
    except Exception as exc:
        append_error(ERROR, 'v665_lifecycle_shadow_candidates', exc)
    # 과도한 파일 비대화를 막고, 최근/고품질/S2 우선으로 저장한다.
    rows.sort(key=lambda x: (0 if x.get('stage') == 'S2' else 1, -_v665_shadow_num(x.get('coin_quality_score'), default=0.0), abs(_v665_shadow_num(x.get('trigger_gap_pct'), default=-999.0))), reverse=False)
    rows = rows[:120]
    source_counts = Counter(str(r.get('trigger_source') or '-') for r in rows)
    stage_counts = Counter(str(r.get('stage') or '-') for r in rows)
    gap_counts = Counter(_v664_gap_bucket(r.get('trigger_gap_pct')) for r in rows)
    summary = {
        'schema': 'trigger_shadow_candidates_v665',
        'version': VERSION,
        'build': V665_STRATEGY_BUILD,
        'updated_ts': nowv,
        'updated_text': now_text(nowv),
        'candidate_count': len(rows),
        'stage_counts': dict(stage_counts),
        'source_counts': dict(source_counts.most_common(8)),
        'gap_counts': dict(gap_counts),
        'rows': rows,
        'policy': 'trigger 방식 비교용 후보 생산. current/near_0_10/near_0_30/actual_trigger shadow만 저장하고 실제 OPEN 조건은 바꾸지 않는다.',
    }
    save_json(TRIGGER_SHADOW_CANDIDATES_V665, summary)
    save_json(TRIGGER_SHADOW_STRATEGY_SUMMARY_V665, {k: summary[k] for k in ('schema','version','build','updated_ts','updated_text','candidate_count','stage_counts','source_counts','gap_counts','policy')})
    return summary


def _v665_append_shadow_queue_text(base_summary: Dict[str, Any], shadow: Dict[str, Any]) -> Dict[str, Any]:
    base = dict(base_summary or {})
    try:
        text = str(base.get('summary_text') or '')
        # 기존 v665 block 제거
        lines = []
        skip = False
        for line in text.splitlines():
            if '[트리거 shadow 검증 · v665]' in line:
                skip = True
                continue
            if skip and line.startswith('['):
                skip = False
            if not skip:
                lines.append(line)
        srcs = shadow.get('source_counts') if isinstance(shadow.get('source_counts'), dict) else {}
        gaps = shadow.get('gap_counts') if isinstance(shadow.get('gap_counts'), dict) else {}
        rows = shadow.get('rows') if isinstance(shadow.get('rows'), list) else []
        def topfmt(r: Dict[str, Any]) -> str:
            gap = r.get('trigger_gap_pct')
            gap_txt = '-' if gap is None else f"{float(gap):+.2f}%"
            return f"{r.get('ticker')} {r.get('stage')} Q{r.get('coin_quality_score')} gap {gap_txt} src {r.get('trigger_source')}"
        block = [
            '[트리거 shadow 검증 · v665]',
            f"- 저장후보 {shadow.get('candidate_count',0)} / 방식: 현재가·방아쇠-0.10%·방아쇠-0.30%·기존방아쇠 비교",
            '- source TOP: ' + (' / '.join(f'{k} {v}' for k, v in Counter(srcs).most_common(5)) if srcs else '-'),
            '- gap TOP: ' + (' / '.join(f'{k} {v}' for k, v in Counter(gaps).most_common(5)) if gaps else '-'),
            '- 후보 TOP: ' + (' / '.join(topfmt(r) for r in rows[:5]) if rows else '-'),
            '- 기준: shadow 검증만 저장. 실제 S1/OPEN/청산/자동매수 변경 없음.',
        ]
        insert_at = len(lines)
        for i, line in enumerate(lines):
            if '[fresh_wait 상세' in line or '[코인 종합품질' in line:
                insert_at = i
                break
        lines[insert_at:insert_at] = block
        base['summary_text'] = '\n'.join(lines)
        bs = base.get('batch_state') if isinstance(base.get('batch_state'), dict) else {}
        bs = dict(bs)
        bs['trigger_shadow_v665'] = {k: shadow.get(k) for k in ('schema','candidate_count','stage_counts','source_counts','gap_counts')}
        bs['schema'] = 'candidate_reason_batch_state_v665_trigger_shadow'
        base['batch_state'] = bs
        base['schema'] = 'candidate_reason_summary_text_v665_trigger_shadow'
    except Exception as exc:
        append_error(ERROR, 'v665_shadow_queue_text', exc)
    return base


_v665_prev_append_trigger_audit_text = _v661_append_trigger_audit_text

def _v661_append_trigger_audit_text(v557_summary: Dict[str, Any], display_rows: List[Dict[str, Any]], nowv: float) -> Dict[str, Any]:  # type: ignore[override]
    base = _v665_prev_append_trigger_audit_text(v557_summary, display_rows, nowv)
    try:
        shadow = _v665_publish_trigger_shadow_candidates(display_rows, nowv)
        return _v665_append_shadow_queue_text(base, shadow)
    except Exception as exc:
        append_error(ERROR, 'v665_trigger_shadow_writer', exc)
        return base



# =============================================================================
# strategy_worker v0.159 / v667: whole-market missed-scan snapshot producer
# - 전체 canonical coverage row를 대상으로 사후 상승 검증용 snapshot만 저장한다.
# - 실제 S1/S2/S3, paper OPEN, 청산, 자동매수 조건은 바꾸지 않는다.
# =============================================================================
MARKET_MISS_CANDIDATES_V667 = BASE_DIR / "clean_market_miss_candidates_v667.json"
MARKET_MISS_STRATEGY_SUMMARY_V667 = BASE_DIR / "clean_market_miss_strategy_summary_v667.json"
V667_STRATEGY_BUILD = "strategy_worker_v0.160_v668_miss_recheck_lane"


def _v667_simple_reason(row: Dict[str, Any]) -> str:
    for keys in (('block_reasons',), ('risk_flags',), ('quality_lane_reasons',), ('missing_info',)):
        for k in keys:
            v = row.get(k)
            if isinstance(v, list) and v:
                return ' / '.join(str(x) for x in v[:3])
            if isinstance(v, str) and v.strip():
                return v.strip()
    return str(row.get('reason') or row.get('block_reason') or '-')


def _v667_miss_bucket(row: Dict[str, Any]) -> str:
    reasons = ' '.join(str(x) for x in (row.get('block_reasons') or row.get('risk_flags') or row.get('missing_info') or [])).lower()
    if row.get('coverage_only_v661') or row.get('coverage_light_v662') or 'coverage' in reasons or 'base/spike' in reasons:
        return 'coverage_buried'
    if 'trigger' in reasons or str(row.get('trigger_status') or '').startswith('trigger'):
        return 'trigger_wait_missed'
    stale = row.get('stale_cause_v658') or row.get('stale_causes_v658') or row.get('freshness_missing') or []
    stale_s = ' '.join(str(x) for x in stale) if isinstance(stale, list) else str(stale or '')
    if 'candle' in stale_s or '캔들' in reasons:
        return 'candle_late'
    if 'feature' in stale_s or 'vwap' in reasons or '가격' in reasons:
        return 'feature_late'
    if 'orderflow' in stale_s or 'micro' in stale_s or '체결' in reasons or '호가' in reasons:
        return 'orderflow_late'
    if any(w in reasons for w in ('스프레드', '미끄러짐', '매도', '윗꼬리', 'risk')):
        return 'risk_filter_candidate'
    return 'strategy_rejected_or_observed'


def _v667_market_miss_candidate(row: Dict[str, Any], nowv: float) -> Optional[Dict[str, Any]]:
    if not isinstance(row, dict):
        return None
    t = _v661_row_ticker(row)
    if not t:
        return None
    cur = _v510_num(row.get('current_price'), row.get('price'), row.get('trade_price'), row.get('entry_price'), default=0.0)
    if cur <= 0:
        return None
    stage = _v510_stage(row)
    q = _v510_num(row.get('coin_quality_score'), row.get('score'), default=0.0)
    risk = _v510_num(row.get('execution_risk_score'), default=0.0)
    audit = row.get('trigger_structure_audit_v663') if isinstance(row.get('trigger_structure_audit_v663'), dict) else {}
    return {
        'schema': 'market_miss_candidate_v667',
        'version': VERSION,
        'build': V667_STRATEGY_BUILD,
        'ticker': t,
        'snapshot_ts': nowv,
        'snapshot_text': now_text(nowv),
        'snapshot_price': cur,
        'initial_stage': stage,
        'coin_quality_score': round(q, 3),
        'execution_risk_score': round(risk, 3),
        'miss_bucket': _v667_miss_bucket(row),
        'feature_late_hint': bool(row.get('feature_missing_for_strategy') or '가격' in _v667_simple_reason(row) or 'VWAP' in _v667_simple_reason(row)),
        'orderflow_late_hint': bool('체결' in _v667_simple_reason(row) or '호가' in _v667_simple_reason(row) or 'orderflow' in ' '.join(str(x) for x in (row.get('stale_reasons') or []))),
        'candle_late_hint': bool('candle' in ' '.join(str(x) for x in (row.get('stale_reasons') or [])) or '캔들' in _v667_simple_reason(row)),
        'initial_reason': _v667_simple_reason(row),
        'strategy': row.get('strategy'),
        'strategy_key': row.get('strategy_key'),
        'quality_lane': row.get('quality_lane'),
        'trigger_source': audit.get('source') or row.get('trigger_source_v663') or row.get('trigger_source'),
        'trigger_gap_pct': audit.get('trigger_gap_pct') or row.get('trigger_gap_pct'),
        'coverage_only': bool(row.get('coverage_only_v661') or row.get('coverage_light_v662')),
        'structure_tags': row.get('structure_tags') if isinstance(row.get('structure_tags'), list) else [],
        'policy': 'v667 whole-market missed-scan review only. 실제 S1/OPEN/청산/자동매수 변경 없음.',
    }


def _v667_publish_market_miss_candidates(display_rows: List[Dict[str, Any]], nowv: float) -> Dict[str, Any]:
    """v668: store the whole canonical coverage set for missed-scan review.

    Earlier v667 used the display list that was capped for screen readability.
    v668 receives all canonical rows from _v510_publish and records source/exclude
    counts explicitly.  This is a review snapshot only; it does not change S1 or
    paper OPEN eligibility.
    """
    rows=[]; seen=set(); exclude_counter: Counter = Counter()
    source_total = len([r for r in (display_rows or []) if isinstance(r, dict)])
    for r in display_rows or []:
        if not isinstance(r, dict):
            exclude_counter['non_dict'] += 1; continue
        cand = _v667_market_miss_candidate(r, nowv)
        if cand and cand.get('ticker') not in seen:
            rows.append(cand); seen.add(cand.get('ticker'))
        elif cand and cand.get('ticker') in seen:
            exclude_counter['duplicate_ticker'] += 1
        else:
            exclude_counter['no_price_or_ticker'] += 1
    buckets = Counter(str(r.get('miss_bucket') or '-') for r in rows)
    stages = Counter(str(r.get('initial_stage') or '-') for r in rows)
    quality = [r for r in rows if _v510_num(r.get('coin_quality_score'), default=0) >= 60]
    obj = {
        'schema': 'market_miss_candidates_v668',
        'version': VERSION,
        'build': V667_STRATEGY_BUILD,
        'updated_ts': nowv,
        'updated_text': now_text(nowv),
        'source_total_count': source_total,
        'canonical_source_count': source_total,
        'candidate_count': len(rows),
        'quality_candidate_count': len(quality),
        'source_exclude_counts': dict(exclude_counter.most_common(8)),
        'miss_bucket_counts': dict(buckets.most_common(10)),
        'initial_stage_counts': dict(stages.most_common(6)),
        'rows': rows,
        'policy': 'v668 whole-canonical missed-scan review. 전체 coverage rows 기준 저장, S1/OPEN 조건 변경 없음.',
    }
    save_json(MARKET_MISS_CANDIDATES_V667, obj)
    save_json(MARKET_MISS_STRATEGY_SUMMARY_V667, {k: obj[k] for k in ('schema','version','build','updated_ts','updated_text','source_total_count','candidate_count','quality_candidate_count','source_exclude_counts','miss_bucket_counts','initial_stage_counts','policy')})
    return obj


_v667_prev_append_trigger_audit_text = _v661_append_trigger_audit_text

def _v661_append_trigger_audit_text(v557_summary: Dict[str, Any], display_rows: List[Dict[str, Any]], nowv: float) -> Dict[str, Any]:  # type: ignore[override]
    base = _v667_prev_append_trigger_audit_text(v557_summary, display_rows, nowv)
    try:
        snap = _v667_publish_market_miss_candidates(display_rows, nowv)
        text = str(base.get('summary_text') or '')
        # worker text에는 짧은 생산상태만 표시. 실제 결과는 review/main cache가 표시한다.
        block = [
            '[전체 스캔 놓침 후보저장 · v667]',
            f"- snapshot {snap.get('candidate_count',0)} / 품질60+ {snap.get('quality_candidate_count',0)}",
            '- 분류 TOP: ' + (' / '.join(f'{k} {v}' for k, v in Counter(snap.get('miss_bucket_counts') or {}).most_common(6)) if snap.get('miss_bucket_counts') else '-'),
            '- 기준: 전체 canonical row 저장만 수행. 실제 매수조건 변경 없음.',
        ]
        lines=[]; skip=False
        for line in text.splitlines():
            if '[전체 스캔 놓침 후보저장' in line:
                skip=True; continue
            if skip and line.startswith('['):
                skip=False
            if not skip:
                lines.append(line)
        insert_at = len(lines)
        for i, line in enumerate(lines):
            if '[트리거 shadow 검증' in line or '[방아쇠 source 검증' in line:
                insert_at = i
                break
        lines[insert_at:insert_at] = block
        base['summary_text'] = '\n'.join(lines)
        bs = base.get('batch_state') if isinstance(base.get('batch_state'), dict) else {}
        bs = dict(bs); bs['market_miss_v667'] = {k: snap.get(k) for k in ('schema','candidate_count','quality_candidate_count','miss_bucket_counts','initial_stage_counts')}
        bs['schema'] = 'candidate_reason_batch_state_v667_market_miss_snapshot'
        base['batch_state'] = bs
        base['schema'] = 'candidate_reason_summary_text_v667_market_miss_snapshot'
    except Exception as exc:
        append_error(ERROR, 'v667_market_miss_snapshot_writer', exc)
    return base


# =============================================================================
# strategy_worker v0.160 / v668: buried/late recheck lane
# - coverage_buried / feature_late / orderflow_late candidates are not promoted.
# - They are sent as priority recheck targets so feature/candle/orderflow can refresh
#   and the next strategy cycle can decide from fresh canonical rows.
# =============================================================================
V668_RECHECK_SUMMARY = BASE_DIR / "clean_market_miss_recheck_lane_v668.json"


def _v668_recheck_need(bucket: str, row: Dict[str, Any]) -> List[str]:
    need = ['quote']
    if bucket in ('coverage_buried', 'feature_late'):
        need += ['candle', 'micro']
    if bucket == 'orderflow_late':
        need += ['micro']
    if bucket == 'trigger_wait_missed':
        need += ['candle', 'micro']
    return _v510_uniq(need, 5)


def _v668_is_recheck_worthy(row: Dict[str, Any]) -> Tuple[bool, str, float, List[str]]:
    bucket = _v667_miss_bucket(row)
    q = _v510_num(row.get('coin_quality_score'), row.get('score'), default=0.0)
    risk = _v510_num(row.get('execution_risk_score'), default=99.0)
    react = _v510_num(row.get('price_reaction_pct'), row.get('change_1m_pct'), default=0.0)
    buy = _v510_num(row.get('buy_ratio'), default=0.0)
    sustain = _v510_num(row.get('buy_sustain_1m'), default=0.0)
    stage = _v510_stage(row)
    worthy = False
    reasons: List[str] = []
    if stage == 'S2':
        worthy = True; reasons.append('S2 재확인')
    if q >= 60 and risk <= 45:
        worthy = True; reasons.append(f'품질 {q:.1f}/위험 {risk:.1f}')
    if bucket in ('feature_late','orderflow_late','candle_late','trigger_wait_missed') and (q >= 55 or react >= 0.05 or buy >= 0.45 or sustain >= 0.55):
        worthy = True; reasons.append(bucket)
    if bucket == 'coverage_buried' and (q >= 60 or (react >= 0.05 and (buy >= 0.45 or sustain >= 0.55))):
        worthy = True; reasons.append('묻힌후보 재확인')
    if risk >= 70 and stage != 'S2':
        worthy = False; reasons.append('위험높음 제외')
    pri = 118.0 + min(60.0, q) + max(0.0, react) * 6.0 + (15.0 if stage == 'S2' else 0.0)
    return worthy, bucket, pri, _v510_uniq(reasons, 8)


_v668_prev_attach_s2_fresh_urgent_requests = _v574_attach_s2_fresh_urgent_requests

def _v574_attach_s2_fresh_urgent_requests(rows: List[Dict[str, Any]], priority_requests: List[Dict[str, Any]], nowv: float) -> Tuple[List[Dict[str, Any]], Dict[str, Any]]:  # type: ignore[override]
    out_reqs, base_summary = _v668_prev_attach_s2_fresh_urgent_requests(rows, priority_requests, nowv)
    reqs = list(out_reqs or [])
    counts: Counter = Counter(); added=[]
    existing_keys = {f"{ticker_norm(r.get('ticker'))}:{r.get('bucket')}" for r in reqs if isinstance(r, dict)}
    for row in rows or []:
        if not isinstance(row, dict):
            continue
        t = _v661_row_ticker(row)
        if not t:
            continue
        worthy, bucket, pri, reasons = _v668_is_recheck_worthy(row)
        if not worthy or bucket == 'risk_filter_candidate':
            continue
        rbucket = f'v668_{bucket}_recheck'
        key = f'{t}:{rbucket}'
        if key in existing_keys:
            continue
        req = {
            'ticker': t,
            'bucket': rbucket,
            'priority': round(pri, 3),
            'need': _v668_recheck_need(bucket, row),
            'source': 'strategy_worker_v668_market_miss_recheck_lane',
            'stage': _v510_stage(row),
            'strategy_key': row.get('strategy_key'),
            'coin_quality_score': round(_v510_num(row.get('coin_quality_score'), row.get('score'), default=0.0), 3),
            'execution_risk_score': round(_v510_num(row.get('execution_risk_score'), default=99.0), 3),
            'miss_bucket': bucket,
            'reasons': reasons,
            'updated_ts': nowv,
        }
        reqs.append(req); existing_keys.add(key); counts[rbucket] += 1
        added.append({k:req.get(k) for k in ('ticker','bucket','priority','need','stage','coin_quality_score','execution_risk_score','miss_bucket','reasons')})
    summary = dict(base_summary or {})
    summary['v668_recheck_lane'] = {
        'schema': 'market_miss_recheck_lane_v668',
        'request_count': sum(counts.values()),
        'bucket_counts': dict(counts.most_common(10)),
        'top': sorted(added, key=lambda x: _v510_num(x.get('priority'), default=0.0), reverse=True)[:20],
        'policy': 'coverage/feature/orderflow late 후보를 정보 재수집 lane으로 보냄. S1/OPEN 조건 변경 없음.',
    }
    try:
        save_json(V668_RECHECK_SUMMARY, {'version': VERSION, 'updated_ts': nowv, 'updated_text': now_text(nowv), **summary['v668_recheck_lane']})
    except Exception as exc:
        append_error(ERROR, 'v668_recheck_lane_save', exc)
    return reqs, summary



# =============================================================================
# strategy_worker v0.161 / v669: fast-quality paper experiment lane
# - S1 조건을 일괄 완화하지 않는다.
# - coverage/feature/orderflow 묻힘 후보 중 품질·위험·근접도가 좋은 일부만 paper 실험 lane으로 표시한다.
# - paper_bot은 이 lane을 실제 자동매수 후보가 아니라 paper-only 실험 장부로 분리해 OPEN한다.
# =============================================================================
FAST_QUALITY_SUMMARY_V669 = BASE_DIR / "clean_fast_quality_paper_lane_v669.json"


def _v669_reason_text(row: Dict[str, Any]) -> str:
    parts: List[str] = []
    for k in ('s_stage_reasons','block_reasons','risk_tags','execution_risk_tags','stale_reasons','quality_lane_reasons'):
        v = row.get(k)
        if isinstance(v, list):
            parts.extend(str(x) for x in v[:8])
        elif v not in (None, '', {}, []):
            parts.append(str(v))
    return ' / '.join(parts)


def _v669_fast_quality_decision(row: Dict[str, Any]) -> Tuple[bool, List[str], Dict[str, Any]]:
    if not isinstance(row, dict):
        return False, ['invalid_row'], {}
    t = _v661_row_ticker(row)
    if not t:
        return False, ['ticker_missing'], {}
    q = _v510_num(row.get('coin_quality_score'), row.get('score'), default=0.0)
    risk = _v510_num(row.get('execution_risk_score'), default=99.0)
    audit = row.get('trigger_structure_audit_v663') if isinstance(row.get('trigger_structure_audit_v663'), dict) else {}
    gap = _v510_num(audit.get('trigger_gap_pct'), row.get('trigger_gap_pct'), default=-999.0)
    conf = _v510_num(audit.get('trigger_confidence'), row.get('trigger_confidence_v663'), default=0.0)
    src = str(audit.get('source') or row.get('trigger_source_v663') or row.get('trigger_source') or '')
    c_age = _v510_num(audit.get('candle_age_sec'), row.get('candle_age_sec'), default=9999.0)
    react = _v510_num(row.get('price_reaction_pct'), row.get('change_1m_pct'), default=0.0)
    buy = _v510_num(row.get('buy_ratio'), default=0.0)
    sustain = _v510_num(row.get('buy_sustain_1m'), row.get('buy_sustain'), default=0.0)
    spread = _v510_num(row.get('spread_pct'), row.get('spread'), default=0.0)
    slip = _v510_num(row.get('slippage_pct'), row.get('expected_slippage_pct'), default=0.0)
    flags = [str(x) for x in (audit.get('risk_flags') or [])]
    reason_text = _v669_reason_text(row)
    reasons: List[str] = []

    # 고품질/저위험 기본선. 너무 많이 태우지 않기 위해 보수적으로 시작한다.
    if q < 70:
        reasons.append(f'Q {q:.1f}<70')
    if risk > 25:
        reasons.append(f'R {risk:.1f}>25')
    if not src or src in ('missing','generic_structure_line','structure_levels_generic','-'):
        reasons.append('trigger source 약함')
    if conf < 70:
        reasons.append(f'trigger conf {conf:.0f}<70')
    if gap < -0.35 or gap > 0.08:
        reasons.append(f'gap {gap:+.2f}% 범위밖')
    if c_age > 90:
        reasons.append(f'candle {c_age:.0f}s>90')
    # 확인신호는 하나 이상 근접해야 한다. current 전체진입 폭탄 방지.
    if not (react >= 0.03 or buy >= 0.45 or sustain >= 0.55):
        reasons.append('확인신호 근접 부족')
    if spread > 0.75:
        reasons.append(f'스프레드 {spread:.2f}>0.75')
    if slip > 0.75:
        reasons.append(f'미끄러짐 {slip:.2f}>0.75')
    bad_words = ('강한 매도압력','윗꼬리','늦은추격 위험','매도벽')
    if any(w in reason_text for w in bad_words) and risk > 12:
        reasons.append('매도/윗꼬리/늦은추격 위험')
    if 'candle_stale' in flags or 'line_conf_low' in flags or 'trigger_conf_low' in flags:
        reasons.append('trigger/candle 신뢰부족')

    ok = len(reasons) == 0
    diag = {
        'ticker': t,
        'q': round(q, 3), 'risk': round(risk, 3), 'gap': round(gap, 3),
        'trigger_source': src, 'trigger_confidence': round(conf, 3), 'candle_age_sec': round(c_age, 1),
        'price_reaction_pct': round(react, 3), 'buy_ratio': round(buy, 3), 'buy_sustain_1m': round(sustain, 3),
        'spread_pct': round(spread, 3), 'slippage_pct': round(slip, 3),
        'reject_reasons': reasons[:8],
    }
    return ok, reasons, diag


def _v669_apply_fast_quality_paper_lane(rows: List[Dict[str, Any]], nowv: float) -> Tuple[List[Dict[str, Any]], Dict[str, Any]]:
    out: List[Dict[str, Any]] = []
    accepted: List[Dict[str, Any]] = []
    rejected_top: List[Dict[str, Any]] = []
    reason_counter: Counter = Counter()
    # 한 cycle paper 실험 후보는 과도하게 만들지 않는다. top 6만 표시/허용.
    scored: List[Tuple[float, Dict[str, Any], Dict[str, Any], List[str], bool]] = []
    for row in rows or []:
        if not isinstance(row, dict):
            continue
        rr = dict(row)
        ok, reasons, diag = _v669_fast_quality_decision(rr)
        score = float(diag.get('q') or 0.0) - float(diag.get('risk') or 99.0) + max(0.0, 0.35 + float(diag.get('gap') or -9.0)) * 20.0
        scored.append((score, rr, diag, reasons, ok))
    scored.sort(key=lambda x: x[0], reverse=True)
    allowed_tickers: set[str] = set()
    for score, rr, diag, reasons, ok in scored:
        t = diag.get('ticker') or _v661_row_ticker(rr)
        if ok and len(allowed_tickers) < 6:
            allowed_tickers.add(str(t))
    for score, rr, diag, reasons, ok in scored:
        t = str(diag.get('ticker') or _v661_row_ticker(rr))
        if ok and t in allowed_tickers:
            rr['paper_experiment_open'] = True
            rr['paper_experiment_lane'] = 'fast_quality_paper_v669'
            rr['paper_experiment_label'] = '고품질 빠른진입 paper 실험'
            rr['paper_experiment_real_eligible'] = False
            rr['real_eligible'] = False
            rr['auto_buy_ready'] = False
            rr['buy_ready'] = False
            rr['fast_quality_paper_v669'] = diag
            rr['strategy_key'] = 'fast_quality_paper_v669'
            rr['strategy_label'] = '고품질 빠른진입 paper 실험'
            rr['paper_strategy_key'] = 'fast_quality_paper_v669'
            rr['paper_strategy_label'] = '고품질 빠른진입 paper 실험'
            # 기존 S1 조건은 그대로 두기 위해 stage는 변경하지 않는다. paper_bot의 실험 lane에서만 수신한다.
            accepted.append({**diag, 'stage': _v510_stage(rr), 'score_rank': round(score,3)})
        else:
            if reasons:
                for r in reasons[:3]: reason_counter[str(r)] += 1
            if len(rejected_top) < 15 and float(diag.get('q') or 0) >= 65:
                rejected_top.append({**diag, 'stage': _v510_stage(rr), 'score_rank': round(score,3)})
        out.append(rr)
    summary = {
        'schema': 'fast_quality_paper_lane_v669',
        'version': VERSION,
        'updated_ts': nowv,
        'updated_text': now_text(nowv),
        'accepted_count': len(accepted),
        'accepted_top': accepted[:10],
        'reject_reason_top': dict(reason_counter.most_common(10)),
        'high_quality_rejected_top': rejected_top[:10],
        'policy': '고품질·저위험·trigger 근접 후보만 paper 실험 lane으로 표시. S1 조건/청산/자동매수/BUY_READY 변경 없음.',
    }
    try:
        save_json(FAST_QUALITY_SUMMARY_V669, summary)
    except Exception as exc:
        append_error(ERROR, 'v669_fast_quality_summary_save', exc)
    return out, summary


def _v669_insert_fast_quality_text(base_summary: Dict[str, Any]) -> Dict[str, Any]:
    base = dict(base_summary or {})
    text = str(base.get('summary_text') or '')
    # 기존 블록 제거
    lines=[]; skip=False
    for line in text.splitlines():
        if '[fast quality paper 실험 · v669]' in line or '[고품질 빠른진입 paper 실험 · v669]' in line:
            skip=True; continue
        if skip and line.startswith('['):
            skip=False
        if not skip:
            lines.append(line)
    obj = load_json(FAST_QUALITY_SUMMARY_V669, {}) or {}
    acc = obj.get('accepted_top') if isinstance(obj.get('accepted_top'), list) else []
    rej = obj.get('reject_reason_top') if isinstance(obj.get('reject_reason_top'), dict) else {}
    def fmt(x: Dict[str, Any]) -> str:
        return f"{x.get('ticker')} {x.get('stage')} Q{float(x.get('q') or 0):.1f} R{float(x.get('risk') or 0):.1f} gap {float(x.get('gap') or 0):+.2f}% src {x.get('trigger_source')}"
    block = [
        '[고품질 빠른진입 paper 실험 · v669]',
        f"- paper실험 후보 {obj.get('accepted_count',0)} / real_eligible false / BUY_READY false",
        '- 후보 TOP: ' + (' / '.join(fmt(x) for x in acc[:6]) if acc else '-'),
        '- 탈락 TOP: ' + (' / '.join(f'{k} {v}' for k, v in Counter(rej).most_common(6)) if rej else '-'),
        '- 기준: Q70↑·R25↓·trigger gap -0.35~+0.08·신선/체결근접. 실제 자동매수/청산/S1 조건 변경 없음.',
    ]
    insert_at = 1 if lines else 0
    for i, line in enumerate(lines):
        if '[트리거 shadow 검증' in line or '[전체 스캔 놓침 검증' in line:
            insert_at = i
            break
    lines[insert_at:insert_at] = block
    base['summary_text'] = '\n'.join(lines)
    bs = base.get('batch_state') if isinstance(base.get('batch_state'), dict) else {}
    bs = dict(bs)
    bs['fast_quality_paper_v669'] = {k: obj.get(k) for k in ('schema','accepted_count','reject_reason_top')}
    bs['schema'] = 'candidate_reason_batch_state_v669_fast_quality_paper'
    base['batch_state'] = bs
    base['schema'] = 'candidate_reason_summary_text_v669_fast_quality_paper'
    return base

# Publish wrapper: mutate canonical rows before all strategy-owned caches are written.
_v669_prev_publish = _v510_publish

def _v510_publish(rows: List[Dict[str, Any]], rejects: List[Dict[str, Any]], priority_requests: List[Dict[str, Any]], evaluated: int, cycle_ts: float, info_quality: Optional[Dict[str, int]] = None) -> Dict[str, Any]:  # type: ignore[override]
    rows2, fast_summary = _v669_apply_fast_quality_paper_lane(rows, cycle_ts)
    iq = dict(info_quality or {})
    iq['fast_quality_paper_v669'] = {k: fast_summary.get(k) for k in ('schema','accepted_count','reject_reason_top')}
    return _v669_prev_publish(rows2, rejects, priority_requests, evaluated, cycle_ts, iq)

_v669_prev_append_trigger_text = _v661_append_trigger_audit_text

def _v661_append_trigger_audit_text(v557_summary: Dict[str, Any], display_rows: List[Dict[str, Any]], nowv: float) -> Dict[str, Any]:  # type: ignore[override]
    base = _v669_prev_append_trigger_text(v557_summary, display_rows, nowv)
    try:
        return _v669_insert_fast_quality_text(base)
    except Exception as exc:
        append_error(ERROR, 'v669_insert_fast_quality_text', exc)
        return base


# =============================================================================
# strategy_worker v0.162 / v671: fast paper field-owner mapping + correct hook order
# - v669 fast paper 선별기가 coin_quality/trigger 값을 top-level에서만 읽어 Q=0/R=99/source missing으로
#   전부 탈락시키던 문제를 고친다.
# - fast paper 판정은 entry_plan/structure_levels/trigger audit 생성 이후, 실제 canonical row가 완성된 위치에서만 실행한다.
# - 기존 S1 조건/청산/자동매수/BUY_READY는 바꾸지 않는다.
# =============================================================================
V671_STRATEGY_BUILD = 'strategy_worker_v0.162_v671_fast_paper_field_owner_2026-06-03'
_V671_LAST_FAST_SUMMARY: Dict[str, Any] = {}


def _v671_dicts(row: Dict[str, Any]) -> List[Dict[str, Any]]:
    out: List[Dict[str, Any]] = []
    if isinstance(row, dict):
        out.append(row)
        for k in ('coin_quality_spine','entry_context','canonical_metric_row','fast_quality_paper_v669'):
            v = row.get(k)
            if isinstance(v, dict):
                out.append(v)
                for kk in ('coin_quality_spine','trigger_structure_audit_v663','trigger_structure_audit_v659','entry_plan','structure_levels','trigger_gate'):
                    vv = v.get(kk)
                    if isinstance(vv, dict):
                        out.append(vv)
        for k in ('entry_plan','structure_levels','trigger_gate','trigger_structure_audit_v663','trigger_structure_audit_v659'):
            v = row.get(k)
            if isinstance(v, dict):
                out.append(v)
    # keep order and identity unique enough
    uniq: List[Dict[str, Any]] = []
    seen: set[int] = set()
    for d in out:
        if id(d) not in seen:
            uniq.append(d); seen.add(id(d))
    return uniq


def _v671_pick_num(row: Dict[str, Any], keys: List[str], default: float=0.0) -> float:
    for d in _v671_dicts(row):
        for k in keys:
            if k in d:
                v = _v510_num(d.get(k), default=None)
                if v is not None:
                    return float(v)
    return default


def _v671_pick_str(row: Dict[str, Any], keys: List[str], default: str='') -> str:
    for d in _v671_dicts(row):
        for k in keys:
            v = d.get(k)
            if v not in (None, '', '-', [], {}):
                return str(v)
    return default


def _v671_pick_list(row: Dict[str, Any], keys: List[str]) -> List[str]:
    out: List[str] = []
    for d in _v671_dicts(row):
        for k in keys:
            v = d.get(k)
            if isinstance(v, list):
                out.extend(str(x) for x in v if x not in (None, ''))
            elif v not in (None, '', {}, []):
                out.append(str(v))
    return _v510_uniq(out, 20)


def _v671_pick_audit(row: Dict[str, Any]) -> Dict[str, Any]:
    for d in _v671_dicts(row):
        for k in ('trigger_structure_audit_v663','trigger_structure_audit_v659'):
            v = d.get(k)
            if isinstance(v, dict) and (v.get('source') or v.get('trigger_price') or v.get('trigger_gap_pct') is not None):
                return dict(v)
    # fallback: build a light audit from row fields/entry plan. This does not create a trade trigger; it only normalizes display/decision inputs.
    levels = row.get('structure_levels') if isinstance(row.get('structure_levels'), dict) else {}
    plan = row.get('entry_plan') if isinstance(row.get('entry_plan'), dict) else {}
    tg = row.get('trigger_gate') if isinstance(row.get('trigger_gate'), dict) else {}
    price = _v671_pick_num(row, ['current_price','price','trade_price','entry_price'], 0.0)
    trigger = _v510_num(tg.get('trigger_price'), levels.get('trigger_price'), plan.get('trigger_price'), row.get('trigger_price'), default=0.0)
    gap = _v510_num(tg.get('trigger_gap_pct'), levels.get('trigger_gap_pct'), plan.get('trigger_gap_pct'), row.get('trigger_gap_pct'), default=None)
    if gap is None and price and trigger:
        try: gap = round((price-trigger)/trigger*100.0, 3)
        except Exception: gap = None
    src = str(tg.get('source') or levels.get('trigger_source') or plan.get('trigger_source') or row.get('trigger_source_v663') or row.get('trigger_source') or '')
    return {'schema':'trigger_structure_audit_v671_normalized_fallback','source':src,'current_price':price or None,'trigger_price':trigger or None,'trigger_gap_pct':gap,'trigger_confidence':_v510_num(tg.get('trigger_confidence'), levels.get('trigger_confidence'), plan.get('trigger_confidence'), row.get('trigger_confidence_v663'), default=None),'risk_flags': _v671_pick_list(row, ['risk_flags','trigger_risk_flags','risk_tags'])}


def _v671_fast_quality_diag(row: Dict[str, Any]) -> Dict[str, Any]:
    q = _v671_pick_num(row, ['coin_quality_score','candidate_quality_score','quality_score','q','score'], 0.0)
    risk = _v671_pick_num(row, ['execution_risk_score','risk_score','execution_risk','R','risk'], 99.0)
    if risk == 99.0:
        ex_score = _v671_pick_num(row, ['execution_score'], -1.0)
        if ex_score >= 0:
            risk = max(0.0, min(100.0, 100.0 - ex_score))
    audit = _v671_pick_audit(row)
    gap = _v510_num(audit.get('trigger_gap_pct'), row.get('trigger_gap_pct'), default=-999.0)
    conf = _v510_num(audit.get('trigger_confidence'), row.get('trigger_confidence_v663'), default=0.0)
    src = str(audit.get('source') or _v671_pick_str(row, ['trigger_source_v663','trigger_source','trigger_reason'], ''))
    c_age = _v510_num(audit.get('candle_age_sec'), _v671_pick_num(row, ['candle_age_sec','official_candle_age','candle_age'], 9999.0), default=9999.0)
    react = _v671_pick_num(row, ['price_reaction_pct','change_1m_pct','price_chg_60s','price_chg_30s'], 0.0)
    buy = _v671_pick_num(row, ['buy_ratio','buy_ratio_20s','buy_ratio_10s'], 0.0)
    sustain = _v671_pick_num(row, ['buy_sustain_1m','buy_sustain','buy_sustain_20s','buy_ratio_20s'], 0.0)
    spread = _v671_pick_num(row, ['spread_pct','spread'], 0.0)
    slip = _v671_pick_num(row, ['slippage_pct','expected_slippage_pct'], spread)
    flags = [str(x) for x in (audit.get('risk_flags') or [])] + _v671_pick_list(row, ['risk_tags','execution_risk_tags','structure_risk_tags','block_reasons'])
    return {
        'ticker': _v661_row_ticker(row),
        'q': round(q, 3), 'risk': round(risk, 3), 'gap': round(gap, 3),
        'trigger_source': src, 'trigger_confidence': round(conf, 3), 'candle_age_sec': round(c_age, 1),
        'price_reaction_pct': round(react, 3), 'buy_ratio': round(buy, 3), 'buy_sustain_1m': round(sustain, 3),
        'spread_pct': round(spread, 3), 'slippage_pct': round(slip, 3),
        'risk_flags': flags[:12],
        'field_owner': 'v671_normalized_from_canonical_row',
    }


def _v671_fast_quality_decision(row: Dict[str, Any]) -> Tuple[bool, List[str], Dict[str, Any]]:
    if not isinstance(row, dict):
        return False, ['invalid_row'], {}
    t = _v661_row_ticker(row)
    if not t:
        return False, ['ticker_missing'], {}
    diag = _v671_fast_quality_diag(row)
    q = float(diag.get('q') or 0.0); risk = float(diag.get('risk') or 99.0); gap = float(diag.get('gap') or -999.0)
    conf = float(diag.get('trigger_confidence') or 0.0); src = str(diag.get('trigger_source') or '')
    c_age = float(diag.get('candle_age_sec') or 9999.0)
    react = float(diag.get('price_reaction_pct') or 0.0); buy = float(diag.get('buy_ratio') or 0.0); sustain = float(diag.get('buy_sustain_1m') or 0.0)
    spread = float(diag.get('spread_pct') or 0.0); slip = float(diag.get('slippage_pct') or 0.0)
    flags = [str(x) for x in diag.get('risk_flags') or []]
    reasons: List[str] = []
    weak_srcs = ('', 'missing', 'generic_structure_line', 'structure_levels_generic', '-')

    # Primary paper experiment: narrow, high-quality current/near-trigger candidate.
    primary = bool(q >= 70 and risk <= 25 and src not in weak_srcs and conf >= 70 and -0.35 <= gap <= 0.08 and c_age <= 120 and (react >= 0.03 or buy >= 0.45 or sustain >= 0.55) and spread <= 0.75 and slip <= 0.75)
    # Secondary paper experiment: very high quality/low risk but just below trigger.  Paper-only, max count capped later.
    near_high_quality = bool(q >= 78 and risk <= 18 and src not in weak_srcs and conf >= 80 and -0.55 <= gap < -0.35 and c_age <= 90 and (react >= 0.00 or buy >= 0.42 or sustain >= 0.52) and spread <= 0.55 and slip <= 0.55)

    if q < 70: reasons.append(f'Q {q:.1f}<70')
    if risk > 25: reasons.append(f'R {risk:.1f}>25')
    if src in weak_srcs: reasons.append('trigger source 약함')
    if conf < 70: reasons.append(f'trigger conf {conf:.0f}<70')
    if gap < -0.55 or gap > 0.08: reasons.append(f'gap {gap:+.2f}% 범위밖')
    elif gap < -0.35 and not near_high_quality: reasons.append(f'gap {gap:+.2f}% near실험 미달')
    if c_age > 120: reasons.append(f'candle {c_age:.0f}s>120')
    if not (react >= 0.03 or buy >= 0.45 or sustain >= 0.55 or (near_high_quality and (buy >= 0.42 or sustain >= 0.52))): reasons.append('확인신호 근접 부족')
    if spread > 0.75: reasons.append(f'스프레드 {spread:.2f}>0.75')
    if slip > 0.75: reasons.append(f'미끄러짐 {slip:.2f}>0.75')
    bad_words = ('강한 매도압력','윗꼬리','늦은추격 위험','매도벽')
    if any(any(w in f for w in bad_words) for f in flags) and risk > 12:
        reasons.append('매도/윗꼬리/늦은추격 위험')
    if any(x in flags for x in ('candle_stale','line_conf_low','trigger_conf_low')) and not near_high_quality:
        reasons.append('trigger/candle 신뢰부족')
    ok = bool(primary or near_high_quality) and not any(r.startswith('스프레드') or r.startswith('미끄러짐') or r == '매도/윗꼬리/늦은추격 위험' for r in reasons)
    diag['reject_reasons'] = [] if ok else reasons[:8]
    diag['fast_lane_type'] = 'primary' if primary else ('near_high_quality' if near_high_quality else 'reject')
    diag['schema'] = 'fast_quality_diag_v671_field_owner'
    return ok, ([] if ok else reasons), diag


def _v671_apply_fast_quality_paper_lane(rows: List[Dict[str, Any]], nowv: float) -> Tuple[List[Dict[str, Any]], Dict[str, Any]]:
    out: List[Dict[str, Any]] = []
    accepted: List[Dict[str, Any]] = []
    rejected_top: List[Dict[str, Any]] = []
    reason_counter: Counter = Counter()
    scored: List[Tuple[float, Dict[str, Any], Dict[str, Any], List[str], bool]] = []
    for row in rows or []:
        if not isinstance(row, dict):
            continue
        rr = dict(row)
        ok, reasons, diag = _v671_fast_quality_decision(rr)
        # q/risk/gap 기반 랭킹. gap은 방아쇠와 가까울수록 가점.
        gap = float(diag.get('gap') or -9.0)
        score = float(diag.get('q') or 0.0) - float(diag.get('risk') or 99.0) + max(0.0, 0.55 + gap) * 18.0
        scored.append((score, rr, diag, reasons, ok))
    scored.sort(key=lambda x: x[0], reverse=True)
    allowed: set[str] = set()
    for score, rr, diag, reasons, ok in scored:
        t = str(diag.get('ticker') or _v661_row_ticker(rr))
        if ok and len(allowed) < 8:
            allowed.add(t)
    for score, rr, diag, reasons, ok in scored:
        t = str(diag.get('ticker') or _v661_row_ticker(rr))
        if ok and t in allowed:
            rr['paper_experiment_open'] = True
            rr['paper_experiment_lane'] = 'fast_quality_paper_v669'
            rr['paper_experiment_label'] = '고품질 빠른진입 paper 실험'
            rr['paper_experiment_real_eligible'] = False
            rr['real_eligible'] = False; rr['auto_buy_ready'] = False; rr['buy_ready'] = False
            rr['fast_quality_paper_v669'] = diag
            rr['fast_quality_paper_v671'] = diag
            rr['strategy_key'] = 'fast_quality_paper_v669'
            rr['strategy_label'] = '고품질 빠른진입 paper 실험'
            rr['paper_strategy_key'] = 'fast_quality_paper_v669'
            rr['paper_strategy_label'] = '고품질 빠른진입 paper 실험'
            accepted.append({**diag, 'stage': _v510_stage(rr), 'score_rank': round(score,3)})
        else:
            if reasons:
                for r in reasons[:3]: reason_counter[str(r)] += 1
            if len(rejected_top) < 20 and float(diag.get('q') or 0) >= 60:
                rejected_top.append({**diag, 'stage': _v510_stage(rr), 'score_rank': round(score,3)})
        out.append(rr)
    summary = {
        'schema': 'fast_quality_paper_lane_v671_field_owner',
        'version': VERSION,
        'build': V671_STRATEGY_BUILD,
        'updated_ts': nowv,
        'updated_text': now_text(nowv),
        'accepted_count': len(accepted),
        'accepted_top': accepted[:12],
        'reject_reason_top': dict(reason_counter.most_common(12)),
        'high_quality_rejected_top': rejected_top[:12],
        'field_owner': 'strategy_worker canonical row normalized after entry_plan/trigger owner',
        'policy': 'v671: fast paper 실험 후보는 canonical quality/trigger 필드를 정규화한 뒤 paper-only로 표시한다. 실제 자동매수/BUY_READY/S1 조건/청산 변경 없음.',
    }
    try:
        save_json(FAST_QUALITY_SUMMARY_V669, summary)
    except Exception as exc:
        append_error(ERROR, 'v671_fast_quality_summary_save', exc)
    return out, summary

# run fast paper marking at the correct owner location: after v554 entry_plan + v663 trigger owner, before publish writes PAPER_LATEST.
_v671_prev_v554_apply_entry_plan_state = _v554_apply_entry_plan_state

def _v554_apply_entry_plan_state(rows: List[Dict[str, Any]], nowv: float) -> List[Dict[str, Any]]:  # type: ignore[override]
    global _V671_LAST_FAST_SUMMARY
    rows2 = _v671_prev_v554_apply_entry_plan_state(rows, nowv)
    try:
        rows3, summary = _v671_apply_fast_quality_paper_lane(rows2, nowv)
        _V671_LAST_FAST_SUMMARY = summary
        return rows3
    except Exception as exc:
        append_error(ERROR, 'v671_fast_quality_after_entry_plan', exc)
        _V671_LAST_FAST_SUMMARY = {'schema':'fast_quality_paper_lane_v671_error','error':f'{exc.__class__.__name__}: {exc}'}
        return rows2

# bypass the old v669 early wrapper that ran before coin_quality/trigger fields existed.
def _v510_publish(rows: List[Dict[str, Any]], rejects: List[Dict[str, Any]], priority_requests: List[Dict[str, Any]], evaluated: int, cycle_ts: float, info_quality: Optional[Dict[str, int]] = None) -> Dict[str, Any]:  # type: ignore[override]
    iq = dict(info_quality or {})
    if isinstance(_V671_LAST_FAST_SUMMARY, dict) and _V671_LAST_FAST_SUMMARY:
        iq['fast_quality_paper_v669'] = {k: _V671_LAST_FAST_SUMMARY.get(k) for k in ('schema','accepted_count','reject_reason_top','field_owner')}
        iq['fast_quality_paper_v671'] = {k: _V671_LAST_FAST_SUMMARY.get(k) for k in ('schema','accepted_count','reject_reason_top','field_owner')}
    return _v669_prev_publish(rows, rejects, priority_requests, evaluated, cycle_ts, iq)



# =============================================================================
# strategy_worker v0.163 / v672: paper-only fast lane minimum relaxation
# - v671 fixed field mapping but accepted stayed 0 because the paper experiment gate
#   was still S1-like.  This is NOT a real-trading gate and does not change S1.
# - Only paper_experiment_open candidates are marked; real_eligible/BUY_READY remain false.
# =============================================================================
V672_STRATEGY_BUILD = "strategy_worker_v0.165_v674_fast_handoff_single_source"
_V672_LAST_FAST_SUMMARY: Dict[str, Any] = {}

def _v672_fast_quality_decision(row: Dict[str, Any]) -> Tuple[bool, List[str], Dict[str, Any]]:
    if not isinstance(row, dict):
        return False, ['invalid_row'], {}
    t = _v661_row_ticker(row)
    if not t:
        return False, ['ticker_missing'], {}
    diag = _v671_fast_quality_diag(row)
    q = float(diag.get('q') or 0.0)
    risk = float(diag.get('risk') or 99.0)
    gap = float(diag.get('gap') if diag.get('gap') is not None else -999.0)
    conf = float(diag.get('trigger_confidence') or 0.0)
    src = str(diag.get('trigger_source') or '')
    c_age = float(diag.get('candle_age_sec') or 9999.0)
    react = float(diag.get('price_reaction_pct') or 0.0)
    buy = float(diag.get('buy_ratio') or 0.0)
    sustain = float(diag.get('buy_sustain_1m') or 0.0)
    spread = float(diag.get('spread_pct') or 0.0)
    slip = float(diag.get('slippage_pct') or 0.0)
    flags = [str(x) for x in diag.get('risk_flags') or []]
    block_text = ' / '.join(flags)
    weak_srcs = ('', 'missing', '-')
    generic_srcs = ('generic_structure_line', 'structure_levels_generic')
    reasons: List[str] = []

    # Paper-only experiment lanes.  They are intentionally looser than S1,
    # but still block obvious execution danger.
    primary = bool(
        q >= 65 and risk <= 45 and src not in weak_srcs and conf >= 45 and
        -0.55 <= gap <= 0.12 and c_age <= 240 and
        (react >= 0.00 or buy >= 0.38 or sustain >= 0.45) and
        spread <= 0.85 and slip <= 0.85
    )
    # Strong near-trigger candidate with generic source: allow paper-only observation,
    # not real trading.  This targets coverage_buried / feature_late missed moves.
    rescue_generic = bool(
        q >= 72 and risk <= 35 and src in generic_srcs and conf >= 20 and
        -0.45 <= gap <= 0.08 and c_age <= 180 and
        (react >= 0.03 or buy >= 0.42 or sustain >= 0.50) and
        spread <= 0.65 and slip <= 0.65
    )
    # Very high quality but a bit farther below trigger.
    near_high_quality = bool(
        q >= 78 and risk <= 32 and src not in weak_srcs and conf >= 55 and
        -0.70 <= gap < -0.55 and c_age <= 180 and
        (react >= 0.00 or buy >= 0.42 or sustain >= 0.50) and
        spread <= 0.65 and slip <= 0.65
    )

    if q < 65: reasons.append(f'Q {q:.1f}<65')
    if risk > 45: reasons.append(f'R {risk:.1f}>45')
    if src in weak_srcs: reasons.append('trigger source 없음')
    if src in generic_srcs and not rescue_generic: reasons.append('generic source는 구조확인 필요')
    if conf < 45 and not rescue_generic: reasons.append(f'trigger conf {conf:.0f}<45')
    if gap < -0.70 or gap > 0.12: reasons.append(f'gap {gap:+.2f}% 범위밖')
    elif gap < -0.55 and not near_high_quality: reasons.append(f'gap {gap:+.2f}% near실험 미달')
    if c_age > 240: reasons.append(f'candle {c_age:.0f}s>240')
    if not (react >= 0.00 or buy >= 0.38 or sustain >= 0.45 or rescue_generic or near_high_quality):
        reasons.append('확인신호 근접 부족')
    if spread > 0.85: reasons.append(f'스프레드 {spread:.2f}>0.85')
    if slip > 0.85: reasons.append(f'미끄러짐 {slip:.2f}>0.85')
    hard_words = ('강한 매도압력','매도벽')
    soft_words = ('윗꼬리','늦은추격 위험')
    if any(w in block_text for w in hard_words):
        reasons.append('강한 매도압력/매도벽')
    if any(w in block_text for w in soft_words) and risk > 35:
        reasons.append('윗꼬리/늦은추격 위험')

    ok = bool(primary or rescue_generic or near_high_quality) and not any(
        r.startswith('스프레드') or r.startswith('미끄러짐') or r in ('강한 매도압력/매도벽','윗꼬리/늦은추격 위험')
        for r in reasons
    )
    diag['reject_reasons'] = [] if ok else reasons[:8]
    diag['fast_lane_type'] = 'primary_v672' if primary else ('rescue_generic_v672' if rescue_generic else ('near_high_quality_v672' if near_high_quality else 'reject'))
    diag['schema'] = 'fast_quality_diag_v672_paper_only_relax'
    diag['policy'] = 'paper-only: S1/real/BUY_READY/exit unchanged; execution danger remains hard-blocked'
    return ok, ([] if ok else reasons), diag

def _v672_apply_fast_quality_paper_lane(rows: List[Dict[str, Any]], nowv: float) -> Tuple[List[Dict[str, Any]], Dict[str, Any]]:
    out: List[Dict[str, Any]] = []
    accepted: List[Dict[str, Any]] = []
    rejected_top: List[Dict[str, Any]] = []
    reason_counter: Counter = Counter()
    scored: List[Tuple[float, Dict[str, Any], Dict[str, Any], List[str], bool]] = []
    for row in rows or []:
        if not isinstance(row, dict):
            continue
        rr = dict(row)
        ok, reasons, diag = _v672_fast_quality_decision(rr)
        gap = float(diag.get('gap') if diag.get('gap') is not None else -9.0)
        score = float(diag.get('q') or 0.0) - float(diag.get('risk') or 99.0) + max(0.0, 0.70 + gap) * 20.0
        if str(diag.get('fast_lane_type') or '').startswith('rescue'):
            score += 4.0
        scored.append((score, rr, diag, reasons, ok))
    scored.sort(key=lambda x: x[0], reverse=True)
    allowed: set[str] = set()
    for score, rr, diag, reasons, ok in scored:
        t = str(diag.get('ticker') or _v661_row_ticker(rr))
        if ok and len(allowed) < 10:
            allowed.add(t)
    for score, rr, diag, reasons, ok in scored:
        t = str(diag.get('ticker') or _v661_row_ticker(rr))
        if ok and t in allowed:
            rr['paper_experiment_open'] = True
            rr['paper_experiment_lane'] = 'fast_quality_paper_v669'
            rr['paper_experiment_label'] = '고품질 빠른진입 paper 실험'
            rr['paper_experiment_real_eligible'] = False
            rr['real_eligible'] = False; rr['auto_buy_ready'] = False; rr['buy_ready'] = False
            rr['fast_quality_paper_v669'] = diag
            rr['fast_quality_paper_v671'] = diag
            rr['fast_quality_paper_v672'] = diag
            rr['strategy_key'] = 'fast_quality_paper_v669'
            rr['strategy_label'] = '고품질 빠른진입 paper 실험'
            rr['paper_strategy_key'] = 'fast_quality_paper_v669'
            rr['paper_strategy_label'] = '고품질 빠른진입 paper 실험'
            accepted.append({**diag, 'stage': _v510_stage(rr), 'score_rank': round(score,3)})
        else:
            if reasons:
                for r in reasons[:3]: reason_counter[str(r)] += 1
            if len(rejected_top) < 20 and float(diag.get('q') or 0) >= 55:
                rejected_top.append({**diag, 'stage': _v510_stage(rr), 'score_rank': round(score,3)})
        out.append(rr)
    summary = {
        'schema': 'fast_quality_paper_lane_v672_paper_only_relax',
        'version': VERSION,
        'build': V672_STRATEGY_BUILD,
        'updated_ts': nowv,
        'updated_text': now_text(nowv),
        'accepted_count': len(accepted),
        'accepted_top': accepted[:12],
        'reject_reason_top': dict(reason_counter.most_common(12)),
        'high_quality_rejected_top': rejected_top[:12],
        'field_owner': 'strategy_worker canonical row normalized after entry_plan/trigger owner',
        'policy': 'v672: paper-only fast lane relaxed enough to create experiment OPENs. real_eligible/BUY_READY/S1/exit unchanged.',
    }
    try:
        save_json(FAST_QUALITY_SUMMARY_V669, summary)
    except Exception as exc:
        append_error(ERROR, 'v672_fast_quality_summary_save', exc)
    return out, summary

# Replace v671 fast lane with v672 owner.  The hook location remains after entry_plan/trigger owner.
def _v671_apply_fast_quality_paper_lane(rows: List[Dict[str, Any]], nowv: float) -> Tuple[List[Dict[str, Any]], Dict[str, Any]]:  # type: ignore[override]
    return _v672_apply_fast_quality_paper_lane(rows, nowv)




# =============================================================================
# strategy_worker v0.164 / v673: fast paper risk hard-block + late-entry separation
# - v672 proved OPEN can happen, but risk-tagged/late candidates also entered.
# - This keeps paper-only experiment lane, but restores execution hard-blocks and
#   separates too-late big-move candidates into scout/watch metadata instead of fast OPEN.
# - S1/real/BUY_READY/exit conditions are not changed here.
# =============================================================================
V673_STRATEGY_BUILD = "strategy_worker_v0.165_v674_fast_handoff_single_source"

def _v673_timing_diag(row: Dict[str, Any]) -> Dict[str, Any]:
    timing = {}
    for d in _v671_dicts(row):
        v = d.get('entry_timing_spine')
        if isinstance(v, dict):
            timing.update(v)
    first_ret = _v510_num(timing.get('first_to_now_return_pct'), timing.get('first_to_current_return_pct'), default=0.0) or 0.0
    s2_ret = _v510_num(timing.get('s2_to_now_return_pct'), timing.get('s2_to_current_return_pct'), timing.get('s2_to_current_return'), default=0.0) or 0.0
    first_sec = _v510_num(timing.get('first_to_now_delay_sec'), timing.get('first_to_current_delay_sec'), default=0.0) or 0.0
    s2_sec = _v510_num(timing.get('s2_to_now_delay_sec'), timing.get('s2_to_current_delay_sec'), default=0.0) or 0.0
    late = bool(first_ret >= 5.0 or s2_ret >= 3.0 or row.get('late_chase_flag') is True)
    return {'first_ret': round(float(first_ret),3), 's2_ret': round(float(s2_ret),3), 'first_sec': round(float(first_sec),1), 's2_sec': round(float(s2_sec),1), 'late_entry': late}

def _v673_fast_quality_decision(row: Dict[str, Any]) -> Tuple[bool, List[str], Dict[str, Any]]:
    if not isinstance(row, dict):
        return False, ['invalid_row'], {}
    t = _v661_row_ticker(row)
    if not t:
        return False, ['ticker_missing'], {}
    diag = _v671_fast_quality_diag(row)
    timing = _v673_timing_diag(row)
    diag.update({'timing_v673': timing})
    q = float(diag.get('q') or 0.0)
    risk = float(diag.get('risk') or 99.0)
    gap = float(diag.get('gap') if diag.get('gap') is not None else -999.0)
    conf = float(diag.get('trigger_confidence') or 0.0)
    src = str(diag.get('trigger_source') or '')
    c_age = float(diag.get('candle_age_sec') or 9999.0)
    react = float(diag.get('price_reaction_pct') or 0.0)
    buy = float(diag.get('buy_ratio') or 0.0)
    sustain = float(diag.get('buy_sustain_1m') or 0.0)
    spread = float(diag.get('spread_pct') or 0.0)
    slip = float(diag.get('slippage_pct') or 0.0)
    flags = [str(x) for x in diag.get('risk_flags') or []]
    blob = ' / '.join(flags)
    weak_srcs = ('', 'missing', '-')
    generic_srcs = ('generic_structure_line', 'structure_levels_generic')
    reasons: List[str] = []

    # v673 hard execution blocks: these were visible in PIEVERSE and should not fast-open.
    hard_exec = False
    if spread > 0.22:
        reasons.append(f'스프레드 {spread:.2f}>0.22'); hard_exec = True
    if slip > 0.22:
        reasons.append(f'미끄러짐 {slip:.2f}>0.22'); hard_exec = True
    for word in ('강한 매도압력','매도벽','매수체결약함'):
        if word in blob:
            reasons.append(word); hard_exec = True
    if ('윗꼬리' in blob or '늦은추격' in blob) and risk > 18:
        reasons.append('윗꼬리/늦은추격 위험'); hard_exec = True
    if 'hot-rank는 발견신호' in blob and not any(w in blob for w in ('VWAP','EMA','돈흐름','저점유동성쓸림','쓸림후빠른회복')) and risk > 12:
        reasons.append('hot-rank 단독성 위험'); hard_exec = True

    late_entry = bool(timing.get('late_entry'))
    if late_entry:
        # Do not fast-open very late entries; keep them for a separate big-move scout/review lane.
        reasons.append(f"늦은진입 first {timing.get('first_ret',0):+.2f}% / S2 {timing.get('s2_ret',0):+.2f}%")
        diag['big_move_scout_candidate_v673'] = True
        diag['big_move_scout_reason'] = 'late_entry_large_move_watch_not_fast_open'

    primary = bool(
        q >= 65 and risk <= 45 and src not in weak_srcs and src not in generic_srcs and conf >= 45 and
        -0.55 <= gap <= 0.12 and c_age <= 240 and
        (react >= 0.00 or buy >= 0.38 or sustain >= 0.45)
    )
    rescue_generic = bool(
        q >= 74 and risk <= 30 and src in generic_srcs and conf >= 30 and
        -0.40 <= gap <= 0.08 and c_age <= 150 and
        (react >= 0.05 or buy >= 0.48 or sustain >= 0.55)
    )
    near_high_quality = bool(
        q >= 80 and risk <= 25 and src not in weak_srcs and src not in generic_srcs and conf >= 60 and
        -0.70 <= gap < -0.55 and c_age <= 150 and
        (react >= 0.00 or buy >= 0.48 or sustain >= 0.55)
    )

    if q < 65: reasons.append(f'Q {q:.1f}<65')
    if risk > 45: reasons.append(f'R {risk:.1f}>45')
    if src in weak_srcs: reasons.append('trigger source 없음')
    if src in generic_srcs and not rescue_generic: reasons.append('generic source는 구조확인 필요')
    if conf < 45 and not rescue_generic: reasons.append(f'trigger conf {conf:.0f}<45')
    if gap < -0.70 or gap > 0.12: reasons.append(f'gap {gap:+.2f}% 범위밖')
    elif gap < -0.55 and not near_high_quality: reasons.append(f'gap {gap:+.2f}% near실험 미달')
    if c_age > 240: reasons.append(f'candle {c_age:.0f}s>240')
    if not (react >= 0.00 or buy >= 0.38 or sustain >= 0.45 or rescue_generic or near_high_quality):
        reasons.append('확인신호 근접 부족')

    ok = bool(primary or rescue_generic or near_high_quality) and not hard_exec and not late_entry
    diag['reject_reasons'] = [] if ok else reasons[:10]
    diag['fast_lane_type'] = 'primary_v673' if primary else ('rescue_generic_v673' if rescue_generic else ('near_high_quality_v673' if near_high_quality else 'reject'))
    diag['schema'] = 'fast_quality_diag_v673_risk_profit_guard'
    diag['policy'] = 'paper-only fast lane: hard execution risk and late entries are blocked; big-move scout separated.'
    return ok, ([] if ok else reasons), diag

def _v673_apply_fast_quality_paper_lane(rows: List[Dict[str, Any]], nowv: float) -> Tuple[List[Dict[str, Any]], Dict[str, Any]]:
    out: List[Dict[str, Any]] = []
    accepted: List[Dict[str, Any]] = []
    rejected_top: List[Dict[str, Any]] = []
    scout_top: List[Dict[str, Any]] = []
    reason_counter: Counter = Counter()
    scored: List[Tuple[float, Dict[str, Any], Dict[str, Any], List[str], bool]] = []
    for row in rows or []:
        if not isinstance(row, dict):
            continue
        rr = dict(row)
        ok, reasons, diag = _v673_fast_quality_decision(rr)
        gap = float(diag.get('gap') if diag.get('gap') is not None else -9.0)
        score = float(diag.get('q') or 0.0) - float(diag.get('risk') or 99.0) + max(0.0, 0.70 + gap) * 20.0
        if diag.get('big_move_scout_candidate_v673') and len(scout_top) < 12:
            scout_top.append({**diag, 'stage': _v510_stage(rr), 'score_rank': round(score,3)})
        scored.append((score, rr, diag, reasons, ok))
    scored.sort(key=lambda x: x[0], reverse=True)
    allowed: set[str] = set()
    for score, rr, diag, reasons, ok in scored:
        t = str(diag.get('ticker') or _v661_row_ticker(rr))
        if ok and len(allowed) < 10:
            allowed.add(t)
    for score, rr, diag, reasons, ok in scored:
        t = str(diag.get('ticker') or _v661_row_ticker(rr))
        if ok and t in allowed:
            rr['paper_experiment_open'] = True
            rr['paper_experiment_lane'] = 'fast_quality_paper_v669'
            rr['paper_experiment_label'] = '고품질 빠른진입 paper 실험'
            rr['paper_experiment_real_eligible'] = False
            rr['real_eligible'] = False; rr['auto_buy_ready'] = False; rr['buy_ready'] = False
            rr['fast_quality_paper_v669'] = diag
            rr['fast_quality_paper_v671'] = diag
            rr['fast_quality_paper_v672'] = diag
            rr['fast_quality_paper_v673'] = diag
            rr['strategy_key'] = 'fast_quality_paper_v669'
            rr['strategy_label'] = '고품질 빠른진입 paper 실험'
            rr['paper_strategy_key'] = 'fast_quality_paper_v669'
            rr['paper_strategy_label'] = '고품질 빠른진입 paper 실험'
            accepted.append({**diag, 'stage': _v510_stage(rr), 'score_rank': round(score,3)})
        else:
            if reasons:
                for r in reasons[:3]: reason_counter[str(r)] += 1
            if len(rejected_top) < 20 and float(diag.get('q') or 0) >= 55:
                rejected_top.append({**diag, 'stage': _v510_stage(rr), 'score_rank': round(score,3)})
        out.append(rr)
    summary = {
        'schema': 'fast_quality_paper_lane_v673_risk_profit_guard',
        'version': VERSION,
        'build': V673_STRATEGY_BUILD,
        'updated_ts': nowv,
        'updated_text': now_text(nowv),
        'accepted_count': len(accepted),
        'accepted_top': accepted[:12],
        'reject_reason_top': dict(reason_counter.most_common(12)),
        'high_quality_rejected_top': rejected_top[:12],
        'big_move_scout_watch_count': len(scout_top),
        'big_move_scout_watch_top': scout_top[:8],
        'field_owner': 'strategy_worker canonical row normalized after entry_plan/trigger owner',
        'policy': 'v673: paper-only fast lane blocks spread/slip/weak-buy/late entry; big move scout separated. real_eligible/BUY_READY/S1 unchanged.',
    }
    try:
        save_json(FAST_QUALITY_SUMMARY_V669, summary)
    except Exception as exc:
        append_error(ERROR, 'v673_fast_quality_summary_save', exc)
    return out, summary

# Override v672 owner in-place. Hook remains after entry_plan/trigger source creation.
def _v671_apply_fast_quality_paper_lane(rows: List[Dict[str, Any]], nowv: float) -> Tuple[List[Dict[str, Any]], Dict[str, Any]]:  # type: ignore[override]
    return _v673_apply_fast_quality_paper_lane(rows, nowv)

def _v672_apply_fast_quality_paper_lane(rows: List[Dict[str, Any]], nowv: float) -> Tuple[List[Dict[str, Any]], Dict[str, Any]]:  # type: ignore[override]
    return _v673_apply_fast_quality_paper_lane(rows, nowv)



# =============================================================================
# strategy_worker v0.165 / v674: fast paper handoff single-source owner
# - v673 showed accepted>0 in strategy summary but paper seen=0.
# - Root issue: accepted summary and paper_bot consumption could diverge because
#   paper_bot reads paper_candidates_latest through latest_scan_filter, while the
#   summary was written from strategy-local scoring.
# - This hook stamps accepted paper-experiment rows with a fresh handoff scan_id
#   and writes a handoff cache from the actual rows that will be published to
#   paper_candidates_latest. Conditions/exit/BUY_READY/real trading are unchanged.
# =============================================================================
V674_STRATEGY_BUILD = "strategy_worker_v0.166_v675_info_priority_value_owner"
FAST_QUALITY_HANDOFF_V674 = BASE_DIR / "clean_fast_quality_paper_handoff_v674.json"

_v674_prev_v554_apply_entry_plan_state = _v554_apply_entry_plan_state

def _v674_is_fast_row(row: Dict[str, Any]) -> bool:
    return isinstance(row, dict) and row.get('paper_experiment_open') is True and str(row.get('paper_experiment_lane') or '') == 'fast_quality_paper_v669'

def _v674_fast_brief(row: Dict[str, Any]) -> Dict[str, Any]:
    diag = row.get('fast_quality_paper_v673') if isinstance(row.get('fast_quality_paper_v673'), dict) else (row.get('fast_quality_paper_v672') if isinstance(row.get('fast_quality_paper_v672'), dict) else (row.get('fast_quality_paper_v669') if isinstance(row.get('fast_quality_paper_v669'), dict) else {}))
    return {
        'ticker': _v661_row_ticker(row),
        'stage': _v510_stage(row),
        'q': round(_v510_num(diag.get('q'), row.get('coin_quality_score'), row.get('score'), default=0.0), 3),
        'risk': round(_v510_num(diag.get('risk'), row.get('execution_risk_score'), default=99.0), 3),
        'gap': round(_v510_num(diag.get('gap'), default=0.0), 3),
        'trigger_source': diag.get('trigger_source') or row.get('trigger_source') or row.get('trigger_source_v663'),
        'trigger_confidence': round(_v510_num(diag.get('trigger_confidence'), default=0.0), 3),
        'created_at': row.get('created_at'),
        'scan_id': row.get('scan_id'),
        'event_id': row.get('event_id'),
        'strategy_key': row.get('strategy_key'),
        'paper_experiment_open': bool(row.get('paper_experiment_open')),
        'paper_experiment_lane': row.get('paper_experiment_lane'),
    }

def _v554_apply_entry_plan_state(rows: List[Dict[str, Any]], nowv: float) -> List[Dict[str, Any]]:  # type: ignore[override]
    rows2 = _v674_prev_v554_apply_entry_plan_state(rows, nowv)
    out: List[Dict[str, Any]] = []
    handoff_rows: List[Dict[str, Any]] = []
    scan_id = f"fast_quality_paper_v674_{int(nowv // 30)}"
    for row in rows2 or []:
        if not isinstance(row, dict):
            out.append(row); continue
        rr = dict(row)
        if _v674_is_fast_row(rr):
            t = _v661_row_ticker(rr) or 'UNKNOWN'
            eid = f"fast_quality_paper_v674:{t}:{int(nowv // 30)}"
            # Preserve first_seen/timing fields; stamp only the runtime handoff identity
            # used by paper_bot latest_scan_filter and duplicate guard.
            rr['scan_id'] = scan_id
            rr['source_scan_id'] = scan_id
            rr['strategy_scan_id'] = scan_id
            rr['event_id'] = eid
            rr['event_key'] = eid
            rr['trace_id'] = eid
            rr['handoff_id'] = eid
            rr['candidate_uid'] = eid
            rr['created_at'] = nowv
            rr['candidate_created_at'] = nowv
            rr['source_created_at'] = nowv
            rr['event_ts'] = nowv
            rr['timestamp'] = nowv
            rr['updated_ts'] = nowv
            rr['paper_handoff_ts'] = nowv
            rr['paper_handoff_text'] = now_text(nowv)
            rr['paper_experiment_handoff_ready_v674'] = True
            rr['paper_experiment_handoff_source'] = 'paper_candidates_latest_actual_row_v674'
            # Make paper/open traces explicit without changing real-trading flags.
            rr['open_eligible'] = False
            rr['paper_bot_open'] = False
            rr['trade_ready'] = False
            rr['real_eligible'] = False
            rr['auto_buy_ready'] = False
            rr['buy_ready'] = False
            handoff_rows.append(_v674_fast_brief(rr))
        out.append(rr)
    summary = {
        'schema': 'fast_quality_paper_handoff_v674_actual_paper_latest_rows',
        'version': VERSION,
        'build': V674_STRATEGY_BUILD,
        'updated_ts': nowv,
        'updated_text': now_text(nowv),
        'scan_id': scan_id,
        'actual_handoff_count': len(handoff_rows),
        'rows': handoff_rows[:20],
        'policy': 'accepted 표시는 paper_candidates_latest 실제 row 기준. accepted>0이면 paper_bot latest_scan_filter가 볼 수 있게 scan_id/created_at을 handoff 전용으로 봉인한다. S1/BUY_READY/자동매수/청산 변경 없음.',
    }
    try:
        save_json(FAST_QUALITY_HANDOFF_V674, summary)
    except Exception as exc:
        append_error(ERROR, 'v674_fast_handoff_save', exc)
    return out

# =============================================================================
# strategy_worker v0.166 / v675: canonical values for missed review + fine info priorities
# - Keep paper/open conditions unchanged.
# - Fix missed-review rows so Q/R/trigger/execution values are preserved.
# - Split information-priority requests by owner worker rather than vague quote/candle/micro.
# =============================================================================
VERSION = "strategy_worker_v0.789"
V675_STRATEGY_BUILD = "strategy_worker_v0.738_gate_scope_surgery_2026-06-04"
INFO_PRIORITY_SUMMARY_V675 = BASE_DIR / "clean_info_priority_summary_v675.json"

def _v675_diag(row: Dict[str, Any]) -> Dict[str, Any]:
    try:
        if '_v671_fast_quality_diag' in globals():
            return _v671_fast_quality_diag(row)  # type: ignore[name-defined]
    except Exception:
        pass
    return {
        'ticker': _v661_row_ticker(row),
        'q': _v510_num(row.get('coin_quality_score'), row.get('score'), default=0.0),
        'risk': _v510_num(row.get('execution_risk_score'), default=99.0),
        'gap': _v510_num(row.get('trigger_gap_pct'), default=None),
        'trigger_source': row.get('trigger_source') or row.get('trigger_source_v663'),
        'trigger_confidence': _v510_num(row.get('trigger_confidence'), row.get('trigger_confidence_v663'), default=0.0),
        'price_reaction_pct': _v510_num(row.get('price_reaction_pct'), row.get('change_1m_pct'), default=0.0),
        'buy_ratio': _v510_num(row.get('buy_ratio'), default=0.0),
        'buy_sustain_1m': _v510_num(row.get('buy_sustain_1m'), default=0.0),
        'spread_pct': _v510_num(row.get('spread_pct'), default=0.0),
        'slippage_pct': _v510_num(row.get('slippage_pct'), default=0.0),
        'candle_age_sec': _v510_num(row.get('candle_age_sec'), row.get('candle_age'), default=9999.0),
    }

def _v667_market_miss_candidate(row: Dict[str, Any], nowv: float) -> Optional[Dict[str, Any]]:  # type: ignore[override]
    if not isinstance(row, dict):
        return None
    t = _v661_row_ticker(row)
    if not t:
        return None
    cur = _v510_num(row.get('current_price'), row.get('price'), row.get('trade_price'), row.get('entry_price'), default=0.0)
    if cur <= 0:
        return None
    d = _v675_diag(row)
    stage = _v510_stage(row)
    q = _v510_num(d.get('q'), row.get('coin_quality_score'), row.get('score'), default=0.0)
    risk = _v510_num(d.get('risk'), row.get('execution_risk_score'), default=0.0)
    bucket = _v667_miss_bucket(row)
    return {
        'schema': 'market_miss_candidate_v675_value_owner',
        'version': VERSION,
        'build': V675_STRATEGY_BUILD,
        'ticker': t,
        'snapshot_ts': nowv,
        'snapshot_text': now_text(nowv),
        'snapshot_price': cur,
        'initial_stage': stage,
        'coin_quality_score': round(q, 3),
        'q': round(q, 3),
        'execution_risk_score': round(risk, 3),
        'risk': round(risk, 3),
        'miss_bucket': bucket,
        'feature_late_hint': bool(bucket == 'feature_late'),
        'orderflow_late_hint': bool(bucket == 'orderflow_late'),
        'candle_late_hint': bool(bucket == 'candle_late'),
        'initial_reason': _v667_simple_reason(row),
        'strategy': row.get('strategy'),
        'strategy_key': row.get('strategy_key'),
        'quality_lane': row.get('quality_lane'),
        'trigger_source': d.get('trigger_source') or row.get('trigger_source_v663') or row.get('trigger_source'),
        'trigger_confidence': d.get('trigger_confidence'),
        'trigger_gap_pct': d.get('gap'),
        'price_reaction_pct': d.get('price_reaction_pct'),
        'buy_ratio': d.get('buy_ratio'),
        'buy_sustain_1m': d.get('buy_sustain_1m'),
        'spread_pct': d.get('spread_pct'),
        'slippage_pct': d.get('slippage_pct'),
        'candle_age_sec': d.get('candle_age_sec'),
        'coverage_only': bool(row.get('coverage_only_v661') or row.get('coverage_light_v662')),
        'structure_tags': row.get('structure_tags') if isinstance(row.get('structure_tags'), list) else [],
        'policy': 'v675: whole-market missed-scan review with canonical Q/R/trigger/execution values. 실제 S1/OPEN/청산/자동매수 변경 없음.',
    }

def _v668_recheck_need(bucket: str, row: Dict[str, Any]) -> List[str]:  # type: ignore[override]
    if bucket == 'feature_late': return ['feature', 'price_vwap_ema', 'quote']
    if bucket == 'orderflow_late': return ['orderflow', 'micro', 'trade_buy_ratio', 'spread_slippage']
    if bucket == 'candle_late': return ['candle', 'structure_levels', 'support_resistance']
    if bucket == 'trigger_wait_missed': return ['candle', 'feature', 'orderflow', 'trigger_recheck']
    if bucket == 'coverage_buried': return ['feature', 'orderflow', 'candle', 'coverage_rescue']
    return ['quote']

def _v675_priority_tier(bucket: str, row: Dict[str, Any]) -> Tuple[str, float]:
    d = _v675_diag(row); q = _v510_num(d.get('q'), default=0.0); risk = _v510_num(d.get('risk'), default=99.0); stage = _v510_stage(row)
    if row.get('paper_experiment_open') is True or row.get('paper_experiment_handoff_ready_v674') is True: return 'T0_paper_handoff', 260.0 + min(q, 80.0)
    if stage == 'S2': return 'T2_s2_trigger_recheck', 220.0 + min(q, 70.0)
    if bucket == 'coverage_buried': return 'T3_coverage_rescue', 180.0 + min(q, 60.0) - max(0.0, risk-45.0)
    if bucket == 'feature_late': return 'T4_feature_urgent', 170.0 + min(q, 60.0)
    if bucket == 'orderflow_late': return 'T5_orderflow_urgent', 165.0 + min(q, 60.0)
    if bucket == 'candle_late': return 'T6_candle_urgent', 155.0 + min(q, 60.0)
    return 'T7_market_rotation', 100.0 + min(q, 40.0)

_v675_prev_attach_s2_fresh_urgent_requests = _v574_attach_s2_fresh_urgent_requests

def _v574_attach_s2_fresh_urgent_requests(rows: List[Dict[str, Any]], priority_requests: List[Dict[str, Any]], nowv: float) -> Tuple[List[Dict[str, Any]], Dict[str, Any]]:  # type: ignore[override]
    out_reqs, base_summary = _v675_prev_attach_s2_fresh_urgent_requests(rows, priority_requests, nowv)
    reqs = list(out_reqs or []); counts: Counter = Counter(); owner_counts: Counter = Counter(); added=[]
    existing_keys = {f"{ticker_norm(r.get('ticker'))}:{r.get('bucket')}" for r in reqs if isinstance(r, dict)}
    for row in rows or []:
        if not isinstance(row, dict): continue
        t = _v661_row_ticker(row)
        if not t: continue
        bucket = _v667_miss_bucket(row); d = _v675_diag(row)
        q = _v510_num(d.get('q'), default=0.0); risk = _v510_num(d.get('risk'), default=99.0)
        react = _v510_num(d.get('price_reaction_pct'), default=0.0); buy = _v510_num(d.get('buy_ratio'), default=0.0); sustain = _v510_num(d.get('buy_sustain_1m'), default=0.0)
        worthy = _v510_stage(row) == 'S2' or row.get('paper_experiment_open') is True or q >= 55 or react >= 0.05 or buy >= 0.45 or sustain >= 0.55
        if risk >= 80 and _v510_stage(row) != 'S2': worthy = False
        if not worthy or bucket == 'risk_filter_candidate': continue
        tier, pri = _v675_priority_tier(bucket, row); rbucket = f'v675_{tier}_{bucket}'; key = f'{t}:{rbucket}'
        if key in existing_keys: continue
        need = _v668_recheck_need(bucket, row)
        for n in need: owner_counts[n] += 1
        req = {'ticker': t, 'bucket': rbucket, 'priority': round(pri, 3), 'tier': tier, 'need': need, 'source': 'strategy_worker_v675_info_priority_spine', 'stage': _v510_stage(row), 'coin_quality_score': round(q, 3), 'execution_risk_score': round(risk, 3), 'miss_bucket': bucket, 'reasons': [tier, bucket, f'Q{q:.1f}', f'R{risk:.1f}'], 'updated_ts': nowv}
        reqs.append(req); existing_keys.add(key); counts[rbucket] += 1; added.append({k:req.get(k) for k in ('ticker','bucket','tier','priority','need','stage','coin_quality_score','execution_risk_score','miss_bucket','reasons')})
    summary = dict(base_summary or {})
    summary['v675_info_priority'] = {'schema': 'info_priority_spine_v675', 'request_count': sum(counts.values()), 'tier_counts': dict(counts.most_common(12)), 'owner_need_counts': dict(owner_counts.most_common(12)), 'top': sorted(added, key=lambda x: _v510_num(x.get('priority'), default=0.0), reverse=True)[:20], 'policy': '정보부족 후보를 T0~T7 우선순위와 owner need(feature/orderflow/candle 등)로 세분화. S1/OPEN 조건 변경 없음.'}
    try: save_json(INFO_PRIORITY_SUMMARY_V675, {'version': VERSION, 'updated_ts': nowv, 'updated_text': now_text(nowv), **summary['v675_info_priority']})
    except Exception as exc: append_error(ERROR, 'v675_info_priority_save', exc)
    return reqs, summary


# =============================================================================
# strategy_worker v0.167 / v676: near-trigger paper lane + stronger owner priority
# - v675 proved missed candidates are concentrated around Q60~69/R<=25/gap near -0.30.
# - This does NOT change real/S1/BUY_READY. It only marks paper-only near-trigger
#   experiment rows and makes information priority owner-specific.
# =============================================================================
VERSION = "strategy_worker_v0.789"
V676_STRATEGY_BUILD = "strategy_worker_v0.720_v679_no_finally_handoff_republish_2026-06-04"
INFO_PRIORITY_SUMMARY_V676 = BASE_DIR / "clean_info_priority_summary_v676.json"

_v676_prev_fast_decision = _v673_fast_quality_decision

def _v676_has_hard_exec_risk(diag: Dict[str, Any]) -> Tuple[bool, List[str]]:
    flags = [str(x) for x in (diag.get('risk_flags') or [])]
    blob = ' / '.join(flags)
    spread = float(diag.get('spread_pct') or 0.0)
    slip = float(diag.get('slippage_pct') or 0.0)
    risk = float(diag.get('risk') or 99.0)
    reasons=[]
    if spread > 0.28: reasons.append(f'스프레드 {spread:.2f}>0.28')
    if slip > 0.28: reasons.append(f'미끄러짐 {slip:.2f}>0.28')
    if '강한 매도압력' in blob or '매도벽' in blob: reasons.append('강한 매도압력/매도벽')
    if ('윗꼬리' in blob or '늦은추격' in blob) and risk > 25: reasons.append('윗꼬리/늦은추격 위험')
    return (len(reasons)>0), reasons

def _v673_fast_quality_decision(row: Dict[str, Any]) -> Tuple[bool, List[str], Dict[str, Any]]:  # type: ignore[override]
    ok, reasons, diag = _v676_prev_fast_decision(row)
    try:
        if ok:
            diag['schema'] = 'fast_quality_diag_v676_existing_ok'
            return ok, reasons, diag
        d = _v675_diag(row)
        diag = dict(diag or {})
        diag.update({k: d.get(k) for k in ('ticker','q','risk','gap','trigger_source','trigger_confidence','candle_age_sec','price_reaction_pct','buy_ratio','buy_sustain_1m','spread_pct','slippage_pct','risk_flags') if k not in diag or diag.get(k) in (None,'',0,0.0,-999)})
        q=float(diag.get('q') or 0.0); risk=float(diag.get('risk') or 99.0)
        gap=float(diag.get('gap') if diag.get('gap') is not None else -999.0)
        conf=float(diag.get('trigger_confidence') or 0.0)
        src=str(diag.get('trigger_source') or '')
        c_age=float(diag.get('candle_age_sec') or 9999.0)
        react=float(diag.get('price_reaction_pct') or 0.0); buy=float(diag.get('buy_ratio') or 0.0); sustain=float(diag.get('buy_sustain_1m') or 0.0)
        hard, hard_reasons = _v676_has_hard_exec_risk(diag)
        weak_src = src in ('', '-', 'missing')
        # Evidence-based near-trigger paper lane from v675 missed_candidates:
        # MERL/PROMPT/TON/BCH group was Q60~69, R<=25, gap around -0.30,
        # buy/sustain near 0.58+ and spread mostly <=0.28.  Paper-only.
        near_trigger_ok = bool(
            q >= 60 and risk <= 25 and (not weak_src) and conf >= 25 and
            -0.40 <= gap <= 0.05 and c_age <= 300 and
            (buy >= 0.58 or sustain >= 0.58 or react >= 0.20) and not hard
        )
        if near_trigger_ok:
            diag['schema'] = 'fast_quality_diag_v676_near_trigger_paper'
            diag['fast_lane_type'] = 'near_trigger_paper_v676'
            diag['paper_experiment_allow_pretrigger_v676'] = True
            diag['paper_experiment_entry_mode'] = 'near_trigger_preentry_v676'
            diag['paper_experiment_reason_v676'] = 'Q60+/R25-/gap near -0.30 evidence lane from missed_candidates'
            diag['reject_reasons'] = []
            return True, [], diag
        # enrich rejection reason with explicit v676 near-trigger miss, without hiding original reasons
        more=[]
        if q < 60: more.append(f'near Q {q:.1f}<60')
        if risk > 25: more.append(f'near R {risk:.1f}>25')
        if weak_src: more.append('near trigger source 없음')
        if conf < 25: more.append(f'near trigger conf {conf:.0f}<25')
        if not (-0.40 <= gap <= 0.05): more.append(f'near gap {gap:+.2f}% 범위밖')
        if not (buy >= 0.58 or sustain >= 0.58 or react >= 0.20): more.append('near 확인신호 부족')
        if hard_reasons: more.extend(hard_reasons[:2])
        diag['v676_near_reject'] = more[:8]
        return False, list(reasons or []) + more[:4], diag
    except Exception as exc:
        try: append_error(ERROR, 'v676_near_trigger_decision', exc)
        except Exception: pass
        return ok, reasons, diag

_v676_prev_fast_apply = _v673_apply_fast_quality_paper_lane

def _v673_apply_fast_quality_paper_lane(rows: List[Dict[str, Any]], nowv: float) -> Tuple[List[Dict[str, Any]], Dict[str, Any]]:  # type: ignore[override]
    """v732: S2/S3 fast-quality는 paper OPEN이 아니라 관찰/복기 shadow다.

    기존 fast-quality open path를 다시 호출하지 않는다.
    조건검증용 diag만 계산하고 paper_experiment_open/handoff_ready는 생성하지 않는다.
    """
    out: List[Dict[str, Any]] = []
    watch_rows: List[Dict[str, Any]] = []
    reject_counter: Counter = Counter()
    scored: List[Tuple[float, Dict[str, Any], Dict[str, Any], List[str], bool]] = []
    for row in rows or []:
        if not isinstance(row, dict):
            continue
        rr = dict(row)
        try:
            ok, reasons, diag = _v672_fast_quality_decision(rr) if '_v672_fast_quality_decision' in globals() else _v671_fast_quality_decision(rr)
        except Exception as exc:
            ok, reasons, diag = False, [f'fast_diag_error:{exc.__class__.__name__}'], {'ticker': _v661_row_ticker(rr), 'stage': _v510_stage(rr)}
        q = _v510_num(diag.get('q'), default=0.0) if isinstance(diag, dict) else 0.0
        risk = _v510_num(diag.get('risk'), default=99.0) if isinstance(diag, dict) else 99.0
        gap = _v510_num(diag.get('gap'), default=-9.0) if isinstance(diag, dict) else -9.0
        score = q - risk + max(0.0, 0.55 + gap) * 18.0
        scored.append((score, rr, diag if isinstance(diag, dict) else {}, list(reasons or []), bool(ok)))
    scored.sort(key=lambda x: x[0], reverse=True)
    for score, rr, diag, reasons, ok in scored:
        # S2/S3 검증 가치는 shadow로만 보존한다. paper 신규 OPEN 플래그는 만들지 않는다.
        for flag in ('paper_experiment_open','paper_experiment_handoff_ready_v674','paper_experiment_allow_pretrigger_v676'):
            rr[flag] = False
        rr['paper_experiment_lane'] = ''
        rr['paper_experiment_label'] = 'S2/S3 관찰·복기 전용'
        rr['paper_experiment_real_eligible'] = False
        rr['paper_experiment_disabled_v732'] = True
        rr['s2s3_observe_review_only_v732'] = True
        rr['s2s3_review_diag_v732'] = diag
        if _v510_stage(rr) != 'S1':
            rr['open_eligible'] = False
            rr['paper_bot_open'] = False
            rr['trade_ready'] = False
        rr['real_eligible'] = False
        rr['auto_buy_ready'] = False
        rr['buy_ready'] = False
        if ok and len(watch_rows) < 20:
            brief = dict(diag)
            brief.setdefault('ticker', _v661_row_ticker(rr))
            brief.setdefault('stage', _v510_stage(rr))
            brief['score_rank'] = round(score, 3)
            brief['paper_open'] = False
            brief['review_only_v732'] = True
            watch_rows.append(brief)
        else:
            for r in reasons[:3]:
                reject_counter[str(r)] += 1
        out.append(rr)
    summary = {
        'schema': 'fast_quality_paper_lane_v732_observe_only',
        'version': VERSION,
        'build': 'v732_s2s3_observe_only_original_flow',
        'updated_ts': nowv,
        'updated_text': now_text(nowv),
        'accepted_count': 0,
        'paper_open_disabled_count_v732': len(watch_rows),
        'watch_count_v732': len(watch_rows),
        'watch_rows': watch_rows[:20],
        'reject_reason_top': dict(reject_counter.most_common(12)),
        'policy': 'S1만 paper 신규 OPEN. S2/S3 fast-quality는 조건검증/놓친후보 복기용 shadow로만 유지.',
    }
    try:
        save_json(FAST_QUALITY_SUMMARY_V669, summary)
    except Exception as exc:
        append_error(ERROR, 'v732_fast_quality_observe_summary_save', exc)
    return out, summary

def _v671_apply_fast_quality_paper_lane(rows: List[Dict[str, Any]], nowv: float) -> Tuple[List[Dict[str, Any]], Dict[str, Any]]:  # type: ignore[override]
    return _v673_apply_fast_quality_paper_lane(rows, nowv)

def _v676_bucket_for_info(row: Dict[str, Any]) -> str:
    b = _v667_miss_bucket(row)
    if row.get('paper_experiment_open') is True or row.get('paper_experiment_handoff_ready_v674') is True:
        return 'paper_handoff_near_trigger'
    d = _v675_diag(row)
    gap = _v510_num(d.get('gap'), default=-999.0)
    if _v510_stage(row) == 'S2' and -0.50 <= gap <= 0.10:
        return 'near_trigger_fresh'
    return b

_v676_prev_attach_info_priority = _v574_attach_s2_fresh_urgent_requests

def _v574_attach_s2_fresh_urgent_requests(rows: List[Dict[str, Any]], priority_requests: List[Dict[str, Any]], nowv: float) -> Tuple[List[Dict[str, Any]], Dict[str, Any]]:  # type: ignore[override]
    reqs, summary = _v676_prev_attach_info_priority(rows, priority_requests, nowv)
    reqs=list(reqs or []); counts=Counter(); need_counts=Counter(); added=[]
    existing={f"{ticker_norm(r.get('ticker'))}:{r.get('bucket')}" for r in reqs if isinstance(r, dict)}
    for row in rows or []:
        if not isinstance(row, dict): continue
        t=_v661_row_ticker(row)
        if not t: continue
        b=_v676_bucket_for_info(row); d=_v675_diag(row)
        q=_v510_num(d.get('q'), default=0.0); risk=_v510_num(d.get('risk'), default=99.0); gap=_v510_num(d.get('gap'), default=-999.0)
        stage=_v510_stage(row)
        if b in ('paper_handoff_near_trigger','near_trigger_fresh'):
            tier='T0_paper_near_trigger' if b=='paper_handoff_near_trigger' else 'T2_near_trigger_fresh'
            need=['feature','orderflow','micro','candle','trigger_recheck','quote']
            pri=310.0 + min(q,80.0) - max(0.0,risk-30.0)
        elif b=='feature_late':
            tier='T4_feature_urgent'; need=['feature','price_vwap_ema','quote']; pri=235.0+min(q,70.0)
        elif b=='orderflow_late':
            tier='T5_orderflow_urgent'; need=['orderflow','micro','trade_buy_ratio','spread_slippage','quote']; pri=235.0+min(q,70.0)
        elif b=='coverage_buried' and q>=55 and risk<=45:
            tier='T3_coverage_rescue'; need=['feature','orderflow','micro','candle','coverage_rescue','quote']; pri=210.0+min(q,70.0)-max(0.0,risk-25.0)
        else:
            continue
        key=f'{t}:v676_{tier}_{b}'
        if key in existing: continue
        req={'ticker':t,'bucket':f'v676_{tier}_{b}','priority':round(pri,3),'tier':tier,'need':need,'source':'strategy_worker_v676_info_priority_owner','stage':stage,'coin_quality_score':round(q,3),'execution_risk_score':round(risk,3),'trigger_gap_pct':round(gap,3),'miss_bucket':b,'reasons':[tier,b,f'Q{q:.1f}',f'R{risk:.1f}',f'gap{gap:+.2f}'],'updated_ts':nowv}
        reqs.append(req); existing.add(key); counts[req['bucket']]+=1
        for n in need: need_counts[n]+=1
        added.append({k:req.get(k) for k in ('ticker','bucket','tier','priority','need','stage','coin_quality_score','execution_risk_score','trigger_gap_pct','miss_bucket')})
    if isinstance(summary, dict):
        summary=dict(summary)
    else: summary={}
    summary['v676_info_priority']={'schema':'info_priority_spine_v676_near_trigger_owner','request_count':sum(counts.values()),'tier_counts':dict(counts.most_common(12)),'owner_need_counts':dict(need_counts.most_common(12)),'top':sorted(added,key=lambda x:_v510_num(x.get('priority'),default=0.0),reverse=True)[:20],'policy':'near-trigger/feature/orderflow/coverage rescue를 owner need로 분리. target_router v0.22가 v676 bucket을 high lane으로 소비.'}
    try: save_json(INFO_PRIORITY_SUMMARY_V676, {'version':VERSION,'updated_ts':nowv,'updated_text':now_text(nowv),**summary['v676_info_priority']})
    except Exception as exc: append_error(ERROR,'v676_info_priority_save',exc)
    return reqs, summary


# =============================================================================
# strategy_worker v0.755: structure taxonomy spine
# - 전략 추가/조건 강화가 아니라, 기존 canonical row 안에서 구조를 good/bad/recheck로 분류한다.
# - risk_tags/structure_tags를 S1 판정용으로 조작하지 않는다. 별도 taxonomy 필드만 봉인한다.
# =============================================================================
VERSION = 'strategy_worker_v0.787'
MAIN_DEPLOY_VERSION = 'v2.13.764'
BUILD_LABEL = 'v787_missing_v782_helper_cut_2026-06-09'

def _v755_has_text(items: Any, *words: str) -> bool:
    hay = ' '.join(str(x) for x in (items if isinstance(items, list) else [items])).lower()
    return any(str(w).lower() in hay for w in words)

def _v755_num(row: Dict[str, Any], *keys: str, default: float = 0.0) -> float:
    vals = [row.get(k) for k in keys]
    ctx = row.get('entry_context') if isinstance(row.get('entry_context'), dict) else {}
    vals += [ctx.get(k) for k in keys]
    return _v510_num(*vals, default=default)

def _v755_structure_taxonomy(row: Dict[str, Any]) -> Dict[str, Any]:
    row = row if isinstance(row, dict) else {}
    src_tags = _v553_as_list(row.get('structure_tags')) + _v553_as_list(row.get('matched_strategy_labels'))
    risk_src = _v553_as_list(row.get('risk_tags'))
    good: List[str] = []
    bad: List[str] = []
    recheck: List[str] = []

    vwap_gap = _v755_num(row, 'vwap_gap_pct', default=-999.0)
    ema5_gap = _v755_num(row, 'ema5_gap_pct', 'ma5_gap_pct', default=-999.0)
    ema10_gap = _v755_num(row, 'ema10_gap_pct', default=-999.0)
    react = _v755_num(row, 'price_reaction_pct', 'change_1m_pct', default=0.0)
    chg3 = _v755_num(row, 'change_3m_pct', 'change_3m', default=0.0)
    chg5 = _v755_num(row, 'change_5m_pct', 'change_5m', default=0.0)
    chg20 = _v755_num(row, 'price_chg_20s', default=0.0)
    chg30 = _v755_num(row, 'price_chg_30s', default=0.0)
    chg60 = _v755_num(row, 'price_chg_60s', default=react)
    accel10 = _v755_num(row, 'price_accel_10s', default=0.0)
    buy = _v755_num(row, 'buy_ratio', default=0.0)
    buy10 = _v755_num(row, 'buy_ratio_10s', default=buy)
    sustain = _v755_num(row, 'buy_sustain_1m', default=0.0)
    sustain20 = _v755_num(row, 'buy_sustain_20s', default=sustain)
    spread = _v755_num(row, 'spread_pct', default=99.0)
    slip = _v755_num(row, 'slippage_pct', default=spread)
    vol_ratio = _v755_num(row, 'volume_ratio', default=0.0)
    vol_exp = _v755_num(row, 'volume_expansion_pct', default=0.0)
    wick_up = _v755_num(row, 'upper_wick_pct', default=0.0)
    candle_age = _v755_num(row, 'official_candle_age', default=0.0)
    candle_src = str(row.get('official_candle_source') or '')
    current = _v755_num(row, 'current_price', 'price', 'entry_price', default=0.0)
    trigger = _v755_num(row, 'trigger_price', default=0.0)
    target = _v755_num(row, 'target_price', 'target1_price', default=0.0)
    invalid = _v755_num(row, 'invalid_price', 'stop_price', default=0.0)

    if bool(row.get('sweep_reclaim_hint')) or _v755_has_text(src_tags, '저점유동성쓸림', '쓸림후빠른회복'):
        good.append('저점쓸림후빠른회복')
    if vwap_gap >= 0.0:
        good.append('VWAP재회복/방어')
    elif -0.25 <= vwap_gap < 0.0:
        recheck.append('VWAP근처회복대기')
    if ema5_gap >= 0.0 and (chg20 >= 0.20 or chg30 >= 0.30 or react >= 0.35):
        good.append('EMA방어후재가속')
    if bool(row.get('breakout_hint')) or bool(row.get('box_breakout_hint')) or _v755_has_text(src_tags, '저항돌파'):
        if bool(row.get('support_reclaim_hint')) or bool(row.get('close_near_high')):
            good.append('저항돌파후재테스트성공')
        else:
            recheck.append('재테스트대기')
        good.append('박스상단돌파')
    if bool(row.get('volume_expanding')) or bool(row.get('reclaim_volume_expand')) or vol_ratio >= 1.20 or vol_exp >= 20.0:
        if chg3 >= 0.15 or react >= 0.35:
            good.append('눌림후거래량재유입')
    if chg3 >= 0.35 and buy >= 0.70:
        good.append('돈흐름재가속')
    if bool(row.get('close_near_high')) and wick_up < 25.0 and sustain >= 0.70:
        good.append('고점근처버티기')
    if bool(row.get('support_reclaim_hint')) or (_v755_num(row, 'support_touch_count', default=0.0) >= 2.0 and vwap_gap >= -0.10):
        good.append('지지전환확인')

    if bool(row.get('long_upper_wick')) or wick_up >= 35.0 or _v755_has_text(risk_src, '윗꼬리'):
        bad.append('윗꼬리저항')
    if (bool(row.get('breakout_hint')) or bool(row.get('box_breakout_hint'))) and (bool(row.get('resistance_reject_hint')) or not bool(row.get('close_near_high'))):
        bad.append('가짜돌파위험')
    if current > 0 and target > 0 and current >= target * 0.995:
        bad.append('목표가근처진입')
    if vwap_gap < -0.05 or ema5_gap < -0.10 or ema10_gap < -0.15:
        bad.append('VWAP/EMA하단구조')
    if react >= 0.35 and (vol_ratio <= 0.50 or vol_exp <= -40.0):
        bad.append('거래량없는상승')
    if accel10 <= -0.20 or (buy > 0 and buy10 < max(0.0, buy - 0.15)) or sustain20 < 0.55:
        bad.append('매수세꺼짐')
    if candle_age >= 120.0 or candle_src == 'missing' or _v755_has_text(risk_src, '공식캔들 stale'):
        bad.append('구조선stale/missing')
    if chg5 >= 3.0 or vwap_gap >= 3.0:
        bad.append('늦은추격위험')
    if bool(row.get('resistance_reject_hint')):
        bad.append('저항밀림')
    if vol_exp <= -50.0 and react >= 0.20:
        bad.append('거래량급감')
    if spread > 0.18 or slip > 0.20:
        bad.append('체결비용부담')

    if trigger > 0 and current > 0 and current < trigger:
        recheck.append('구조좋음+방아쇠미도달')
    if buy >= 0.75 and sustain >= 0.70 and react < 0.35:
        recheck.append('체결좋음+가격반응대기')
    if react >= 0.35 and (buy < 0.70 or sustain < 0.70):
        recheck.append('가격반응좋음+체결지속대기')
    if good and not bad and (react < 0.35 or buy < 0.70 or sustain < 0.70):
        recheck.append('구조좋음+확인신호대기')

    rr = 0.0
    if current > 0 and target > current and invalid > 0 and invalid < current:
        rr = (target - current) / (current - invalid)
    side = 'mixed'
    if good and not bad:
        side = 'good'
    elif bad and not good:
        side = 'bad'
    elif not good and not bad and recheck:
        side = 'recheck'
    elif not good and not bad:
        side = 'neutral'
    return {
        'schema': 'structure_taxonomy_v755',
        'good': _v510_uniq(good, 20),
        'bad': _v510_uniq(bad, 20),
        'recheck': _v510_uniq(recheck, 20),
        'side': side,
        'good_count': len(_v510_uniq(good, 20)),
        'bad_count': len(_v510_uniq(bad, 20)),
        'recheck_count': len(_v510_uniq(recheck, 20)),
        'rr_calc_hint': round(rr, 4) if rr else None,
        'policy': 'classification only; does not alter S1/S2/S3 thresholds',
    }

def _v755_attach_structure_taxonomy(row: Dict[str, Any]) -> Dict[str, Any]:
    if not isinstance(row, dict):
        return row
    tax = _v755_structure_taxonomy(row)
    row['structure_taxonomy_v755'] = tax
    row['structure_good_tags_v755'] = tax.get('good') or []
    row['structure_bad_tags_v755'] = tax.get('bad') or []
    row['structure_recheck_tags_v755'] = tax.get('recheck') or []
    row['structure_signal_side_v755'] = tax.get('side') or 'neutral'
    row['structure_taxonomy_policy_v755'] = 'classification_only_no_threshold_change'
    ctx = row.get('entry_context') if isinstance(row.get('entry_context'), dict) else {}
    ctx = dict(ctx)
    ctx['structure_taxonomy_v755'] = tax
    ctx['structure_good_tags_v755'] = row['structure_good_tags_v755']
    ctx['structure_bad_tags_v755'] = row['structure_bad_tags_v755']
    ctx['structure_recheck_tags_v755'] = row['structure_recheck_tags_v755']
    ctx['structure_signal_side_v755'] = row['structure_signal_side_v755']
    row['entry_context'] = ctx
    return row

_v755_prev_apply_canonical_entry_decision = _v532_apply_canonical_entry_decision

def _v532_apply_canonical_entry_decision(row: Dict[str, Any]) -> Dict[str, Any]:  # type: ignore[override]
    row = _v755_prev_apply_canonical_entry_decision(row)
    return _v755_attach_structure_taxonomy(row)

try:
    BUILD_LABEL = 'v787_missing_v782_helper_cut_2026-06-09'
except Exception:
    pass



# =============================================================================
# strategy_worker v0.759: structure-line source audit, classification only
# - 구조선 가격 자체/전략조건/S1·S2·S3 기준은 변경하지 않는다.
# - 기존 structure_levels가 실제 공식 캔들 기반인지, gap/synthetic 계산선인지 source를 봉인한다.
# - 구조 태그는 좋은/위험/재확인 분류용으로만 보강한다.
# =============================================================================
VERSION = "strategy_worker_v0.789"
BUILD_LABEL = 'v787_missing_v782_helper_cut_2026-06-09'


def _v759_num(row: Dict[str, Any], *keys: str, default: float = 0.0) -> float:
    for k in keys:
        try:
            if isinstance(row, dict) and row.get(k) not in (None, ''):
                return float(str(row.get(k)).replace(',', '').replace('%',''))
        except Exception:
            continue
    return default


def _v759_dict_any(*vals: Any) -> Dict[str, Any]:
    for v in vals:
        if isinstance(v, dict) and v:
            return v
    return {}


def _v759_official_inputs_from(row: Dict[str, Any], levels: Optional[Dict[str, Any]] = None) -> Dict[str, Any]:
    row = row if isinstance(row, dict) else {}
    levels = levels if isinstance(levels, dict) else {}
    ev = levels.get('structure_line_evidence') if isinstance(levels.get('structure_line_evidence'), dict) else {}
    official = _v759_dict_any(
        row.get('official_structure_inputs_raw'),
        row.get('official_structure_inputs'),
        ev.get('official_structure_inputs'),
        levels.get('official_structure_inputs'),
    )
    if not official:
        try:
            official = _v596_official_structure_inputs(row) if '_v596_official_structure_inputs' in globals() else {}
        except Exception:
            official = {}
    return official if isinstance(official, dict) else {}


def _v759_structure_line_audit(row: Dict[str, Any], levels: Dict[str, Any]) -> Dict[str, Any]:
    row = row if isinstance(row, dict) else {}
    levels = levels if isinstance(levels, dict) else {}
    ev = levels.get('structure_line_evidence') if isinstance(levels.get('structure_line_evidence'), dict) else {}
    official = _v759_official_inputs_from(row, levels)
    present = int(official.get('present_count') or 0) if str(official.get('present_count') or '').replace('.','',1).isdigit() else 0
    age = _v759_num(official, 'official_candle_age', default=_v759_num(row, 'official_candle_age', 'candle_age_sec', default=-1.0))
    quality = str(ev.get('quality') or levels.get('quality') or '')
    schema = str(levels.get('schema') or '')
    trigger_conf = _v759_num(ev, 'trigger_confidence', default=_v759_num(levels, 'trigger_confidence', default=0.0))
    support_conf = _v759_num(ev, 'support_confidence', default=0.0)
    resistance_conf = _v759_num(ev, 'resistance_confidence', default=0.0)
    source_kind = 'synthetic_pct_line'
    if present >= 6 and age >= 0 and age <= 180 and ('official' in quality or trigger_conf >= 52 or support_conf >= 42):
        source_kind = 'official_candle_reactive_line'
    elif present >= 3:
        source_kind = 'official_partial_watch_line'
    elif schema in ('structure_levels_v554_all_strategy','structure_levels_v573_refined_late_chase','structure_levels_v595_reactive_lines'):
        source_kind = 'gap_calculated_line'
    stale = bool(age >= 180 and age >= 0)
    missing = bool(present <= 0)
    if missing:
        reliability = 'missing_official_material'
    elif stale:
        reliability = 'stale_official_material'
    elif source_kind == 'official_candle_reactive_line':
        reliability = 'official_reactive'
    elif source_kind == 'official_partial_watch_line':
        reliability = 'official_partial'
    else:
        reliability = 'synthetic_or_gap'
    return {
        'schema': 'structure_line_source_audit_v759',
        'source_kind': source_kind,
        'reliability': reliability,
        'official_present_count': present,
        'official_candle_age': age if age >= 0 else None,
        'evidence_quality': quality or None,
        'support_confidence': support_conf,
        'resistance_confidence': resistance_conf,
        'trigger_confidence': trigger_conf,
        'line_price_policy': 'v759 audit only; existing trigger/support/target prices are not changed',
    }


_v759_prev_build_structure_levels = _v554_build_structure_levels

def _v554_build_structure_levels(row: Dict[str, Any]) -> Dict[str, Any]:  # type: ignore[override]
    levels = _v759_prev_build_structure_levels(row)
    if not isinstance(levels, dict):
        levels = {}
    try:
        audit = _v759_structure_line_audit(row, levels)
        levels['structure_line_audit_v759'] = audit
        levels['line_source_kind_v759'] = audit.get('source_kind')
        levels['line_reliability_v759'] = audit.get('reliability')
        levels['line_price_policy_v759'] = audit.get('line_price_policy')
        official = _v759_official_inputs_from(row, levels)
        if official:
            levels['official_structure_inputs_raw_v759'] = official
    except Exception as exc:
        try: log_error('v759_structure_line_audit', exc)
        except Exception: pass
    return levels


_v759_prev_taxonomy = _v755_structure_taxonomy

def _v755_structure_taxonomy(row: Dict[str, Any]) -> Dict[str, Any]:  # type: ignore[override]
    tax = _v759_prev_taxonomy(row)
    if not isinstance(tax, dict):
        tax = {'good': [], 'bad': [], 'recheck': [], 'side': 'neutral'}
    levels = row.get('structure_levels') if isinstance(row.get('structure_levels'), dict) else {}
    audit = levels.get('structure_line_audit_v759') if isinstance(levels.get('structure_line_audit_v759'), dict) else row.get('structure_line_audit_v759') if isinstance(row.get('structure_line_audit_v759'), dict) else {}
    good = list(tax.get('good') or [])
    bad = list(tax.get('bad') or [])
    recheck = list(tax.get('recheck') or [])
    rel = str(audit.get('reliability') or '')
    src = str(audit.get('source_kind') or '')
    if rel == 'official_reactive':
        good.append('공식구조선반응확인')
    elif rel == 'official_partial':
        recheck.append('공식구조선부분확인')
    elif rel in ('missing_official_material','stale_official_material'):
        bad.append('구조선stale/missing')
    elif src in ('gap_calculated_line','synthetic_pct_line'):
        recheck.append('계산선검증필요')
    good = _v510_uniq(good, 24)
    bad = _v510_uniq(bad, 24)
    recheck = _v510_uniq(recheck, 24)
    side = 'neutral'
    if good and not bad:
        side = 'good'
    elif bad and not good:
        side = 'bad'
    elif good and bad:
        side = 'mixed'
    elif recheck:
        side = 'recheck'
    tax.update({'good': good, 'bad': bad, 'recheck': recheck, 'side': side, 'structure_line_audit_v759': audit, 'policy': 'classification only; no threshold/exit change'})
    return tax


_v759_prev_apply_canonical_entry_decision = _v532_apply_canonical_entry_decision

def _v532_apply_canonical_entry_decision(row: Dict[str, Any]) -> Dict[str, Any]:  # type: ignore[override]
    row = _v759_prev_apply_canonical_entry_decision(row)
    try:
        levels = row.get('structure_levels') if isinstance(row.get('structure_levels'), dict) else {}
        audit = levels.get('structure_line_audit_v759') if isinstance(levels.get('structure_line_audit_v759'), dict) else _v759_structure_line_audit(row, levels)
        row['structure_line_audit_v759'] = audit
        row['structure_line_source_kind_v759'] = audit.get('source_kind')
        row['structure_line_reliability_v759'] = audit.get('reliability')
        ctx = row.get('entry_context') if isinstance(row.get('entry_context'), dict) else {}
        ctx = dict(ctx)
        ctx['structure_line_audit_v759'] = audit
        ctx['structure_line_source_kind_v759'] = audit.get('source_kind')
        ctx['structure_line_reliability_v759'] = audit.get('reliability')
        row['entry_context'] = ctx
    except Exception as exc:
        try: log_error('v759_apply_line_audit', exc)
        except Exception: pass
    return row

# =============================================================================
# strategy_worker v0.762: official candle structure_snapshot spine owner
# - Root fix after v760 rollback: do not add heavy middle-path structure logic.
# - After v554 entry_plan/structure_levels are created, build a lightweight
#   structure_snapshot from candle cache fields already overlaid on each row.
# - This is data sealing only. It does not change S1/S2/S3 thresholds, trigger
#   gate, exits, BUY_READY, or auto-buy.
# =============================================================================
STRUCTURE_SNAPSHOT_CACHE = BASE_DIR / "clean_structure_snapshot_cache.json"


def _v762_as_list(v: Any) -> List[str]:
    out: List[str] = []
    if isinstance(v, (list, tuple, set)):
        src = list(v)
    elif isinstance(v, str) and v.strip():
        src = [x.strip() for x in v.replace('|', '/').split('/')]
    else:
        src = []
    for x in src:
        s = str(x or '').strip()
        if s and s not in out:
            out.append(s)
    return out


def _v762_num(*vals: Any, default: float = 0.0) -> float:
    for v in vals:
        if v in (None, '', [], {}):
            continue
        try:
            return float(str(v).replace(',', '').replace('%', ''))
        except Exception:
            continue
    return default


def _v762_existing_official_pack(row: Dict[str, Any]) -> Dict[str, Any]:
    row = row if isinstance(row, dict) else {}
    ctx = row.get('entry_context') if isinstance(row.get('entry_context'), dict) else {}
    raw = row.get('official_structure_inputs_raw') if isinstance(row.get('official_structure_inputs_raw'), dict) else {}
    out: Dict[str, Any] = {}
    for src in (raw, row, ctx):
        if not isinstance(src, dict):
            continue
        for k in V597_OFFICIAL_STRUCTURE_KEYS:
            v = src.get(k)
            if v not in (None, '', [], {}) and k not in out:
                out[k] = v
    if out:
        out.setdefault('official_candle_source', row.get('official_candle_source') or ctx.get('official_candle_source') or 'candle_worker_cache_overlay_v762')
        out.setdefault('official_candle_age', _v762_num(row.get('official_candle_age'), ctx.get('official_candle_age'), default=999999.0))
        out.setdefault('official_candle_intervals', row.get('official_candle_intervals') or ctx.get('official_candle_intervals') or '1m/3m/5m/30m')
        out.setdefault('official_structure_source', row.get('official_structure_source') or ctx.get('official_structure_source') or 'strategy_final_row_overlay_v762')
    return out


def _v762_support_resistance_from_official(row: Dict[str, Any], official: Dict[str, Any]) -> Dict[str, Any]:
    price = _v762_num(row.get('current_price'), row.get('entry_price'), row.get('price'), default=0.0)
    vals = {
        'swing_high_price': _v762_num(official.get('swing_high_price'), row.get('swing_high_price'), default=0.0),
        'swing_low_price': _v762_num(official.get('swing_low_price'), row.get('swing_low_price'), default=0.0),
        'box_high_price': _v762_num(official.get('box_high_price'), row.get('box_high_price'), default=0.0),
        'box_low_price': _v762_num(official.get('box_low_price'), row.get('box_low_price'), default=0.0),
        'recent_high_price': _v762_num(official.get('recent_high_price'), row.get('recent_high_price'), default=0.0),
        'recent_low_price': _v762_num(official.get('recent_low_price'), row.get('recent_low_price'), default=0.0),
    }
    support_cands = [v for k, v in vals.items() if ('low' in k or 'box_low' in k) and v and (not price or v <= price * 1.003)]
    resist_cands = [v for k, v in vals.items() if ('high' in k or 'box_high' in k) and v and (not price or v >= price * 0.997)]
    support = max([x for x in support_cands if not price or x <= price] or support_cands or [0.0])
    resistance = min([x for x in resist_cands if not price or x >= price] or resist_cands or [0.0])
    present = sum(1 for v in vals.values() if v)
    age = _v762_num(official.get('official_candle_age'), row.get('official_candle_age'), default=999999.0)
    if present >= 4 and age <= 180:
        kind, quality = 'official_candle_lines', 'official_full'
    elif present >= 2 and age <= 300:
        kind, quality = 'official_candle_partial', 'official_partial'
    elif present >= 1:
        kind, quality = 'official_candle_stale_or_sparse', 'official_weak'
    else:
        kind, quality = 'gap_or_synthetic_line', 'missing_official'
    return {
        'schema': 'structure_line_source_v762',
        'line_source_kind_v762': kind,
        'line_quality_v762': quality,
        'official_present_count_v762': present,
        'official_candle_age': age if age < 999999 else None,
        'support_price_official_v762': _v554_round_price(support) if support else 0.0,
        'resistance_price_official_v762': _v554_round_price(resistance) if resistance else 0.0,
        'raw_levels': vals,
        'policy': 'audit/sealing only; legacy trigger/target/invalid values are not changed in v762',
    }


def _v762_structure_taxonomy(row: Dict[str, Any], line: Dict[str, Any]) -> Dict[str, Any]:
    good: List[str] = []
    bad: List[str] = []
    recheck: List[str] = []
    official = _v762_existing_official_pack(row)
    price = _v762_num(row.get('current_price'), row.get('entry_price'), row.get('price'), default=0.0)
    resistance = _v762_num(line.get('resistance_price_official_v762'), default=0.0)
    support = _v762_num(line.get('support_price_official_v762'), default=0.0)
    vwap_gap = _v762_num(row.get('vwap_gap_pct'), default=0.0)
    ema_gap = _v762_num(row.get('ema5_gap_pct'), default=0.0)
    upper_wick = _v762_num(official.get('upper_wick_pct'), row.get('upper_wick_pct'), default=0.0)
    volume_ratio = _v762_num(official.get('volume_ratio'), row.get('volume_ratio'), default=0.0)
    if str(line.get('line_quality_v762') or '').startswith('official'):
        recheck.append('공식구조선확인')
    if price and resistance and price >= resistance * 0.998:
        good.append('저항돌파/상단접근')
    if price and support and price >= support:
        good.append('지지선상단유지')
    if vwap_gap >= 0:
        good.append('VWAP상단/재회복')
    if ema_gap >= 0:
        good.append('EMA방어')
    if bool(official.get('box_breakout_hint')):
        good.append('박스상단돌파힌트')
    if bool(official.get('sweep_reclaim_hint')) or bool(official.get('support_reclaim_hint')):
        good.append('저점쓸림후회복')
    if bool(official.get('reclaim_volume_expand')) or volume_ratio >= 1.2:
        good.append('거래량재유입')
    if upper_wick >= 0.7 or bool(official.get('long_upper_wick')):
        bad.append('윗꼬리저항')
    if bool(official.get('resistance_reject_hint')):
        bad.append('저항밀림')
    if str(line.get('line_quality_v762') or '') in ('missing_official', 'official_weak'):
        recheck.append('구조선근거재확인')
    if not good and not bad:
        recheck.append('구조중립/추가확인')
    side = 'neutral'
    if good and not bad:
        side = 'good'
    elif bad and not good:
        side = 'bad'
    elif good and bad:
        side = 'mixed'
    elif recheck:
        side = 'recheck'
    return {
        'schema': 'structure_taxonomy_v762_observation_only',
        'good': _v510_uniq(good, 16),
        'bad': _v510_uniq(bad, 16),
        'recheck': _v510_uniq(recheck, 16),
        'side': side,
        'policy': 'observation/classify only; not used as a new entry threshold in v762',
    }


def _v762_attach_structure_snapshot(row: Dict[str, Any], nowv: float) -> Dict[str, Any]:
    if not isinstance(row, dict):
        return row
    r = dict(row)
    official = _v762_existing_official_pack(r)
    levels = r.get('structure_levels') if isinstance(r.get('structure_levels'), dict) else {}
    line = _v762_support_resistance_from_official(r, official)
    taxonomy = _v762_structure_taxonomy(r, line)
    metrics = {
        'price_reaction_pct': _v762_num(r.get('price_reaction_pct'), default=0.0),
        'buy_ratio': _v762_num(r.get('buy_ratio'), default=0.0),
        'buy_sustain_1m': _v762_num(r.get('buy_sustain_1m'), default=0.0),
        'spread_pct': _v762_num(r.get('spread_pct'), default=0.0),
        'slippage_pct': _v762_num(r.get('slippage_pct'), r.get('spread_pct'), default=0.0),
    }
    rr = r.get('risk_reward') if isinstance(r.get('risk_reward'), dict) else {}
    snap = {
        'schema': 'canonical_entry_snapshot_v762_structure_snapshot_spine',
        'version': VERSION,
        'build': 'v787_missing_v782_helper_cut_2026-06-09',
        'ticker': r.get('ticker'),
        'created_at': nowv,
        'entry_price': _v762_num(r.get('entry_price'), r.get('current_price'), r.get('price'), default=0.0),
        'metrics': metrics,
        'price_reaction_pct': metrics.get('price_reaction_pct'),
        'buy_ratio': metrics.get('buy_ratio'),
        'buy_sustain_1m': metrics.get('buy_sustain_1m'),
        'structure_levels': levels,
        'entry_plan': r.get('entry_plan') if isinstance(r.get('entry_plan'), dict) else {},
        'risk_reward': rr,
        'rr_ratio': _v762_num(rr.get('rr_ratio'), levels.get('rr_ratio'), r.get('rr_ratio'), default=0.0),
        'structure': {
            'tags': _v510_uniq(_v762_as_list(r.get('entry_structure_tags')) + _v762_as_list(r.get('structure_tags')), 24),
            'line_source': line,
            'taxonomy': taxonomy,
            'official_inputs': official,
        },
        'structure_taxonomy_v762': taxonomy,
        'structure_taxonomy_v755': taxonomy,
        'structure_line_source_v762': line,
        'structure_line_audit_v759': {
            'schema': 'structure_line_source_audit_v762_compat',
            'source_kind': line.get('line_source_kind_v762'),
            'reliability': line.get('line_quality_v762'),
            'official_present_count': line.get('official_present_count_v762'),
            'official_candle_age': line.get('official_candle_age'),
            'line_price_policy': line.get('policy'),
        },
        'official_structure_inputs_raw': official,
        'official_candle_age': official.get('official_candle_age'),
        'official_candle_source': official.get('official_candle_source'),
        'freshness': {'ages': {'micro_age_sec': r.get('micro_age_sec'), 'orderflow_age_sec': r.get('orderflow_age_sec'), 'price_reaction_age_sec': r.get('price_reaction_age_sec')}},
        'source_owner': 'strategy_worker_structure_snapshot_spine_v762',
        'policy': 'single sealed snapshot passed to paper; no entry/exit threshold change',
    }
    r['structure_snapshot_v762'] = snap
    r['canonical_entry_snapshot_v762'] = snap
    r['canonical_entry_snapshot'] = snap
    r['structure_line_source_v762'] = line
    r['structure_taxonomy_v762'] = taxonomy
    r['structure_line_source_kind_v762'] = line.get('line_source_kind_v762')
    r['structure_line_quality_v762'] = line.get('line_quality_v762')
    ctx = r.get('entry_context') if isinstance(r.get('entry_context'), dict) else {}
    ctx = dict(ctx)
    ctx['structure_snapshot_v762'] = snap
    ctx['canonical_entry_snapshot_v762'] = snap
    ctx['structure_line_source_v762'] = line
    ctx['structure_taxonomy_v762'] = taxonomy
    r['entry_context'] = ctx
    return r


def _v762_apply_structure_snapshot(rows: List[Dict[str, Any]], nowv: float) -> List[Dict[str, Any]]:
    out = [_v762_attach_structure_snapshot(r, nowv) for r in (rows or []) if isinstance(r, dict)]
    try:
        kind_counter: Counter = Counter()
        side_counter: Counter = Counter()
        tag_rows = 0
        for r in out:
            line = r.get('structure_line_source_v762') if isinstance(r.get('structure_line_source_v762'), dict) else {}
            tax = r.get('structure_taxonomy_v762') if isinstance(r.get('structure_taxonomy_v762'), dict) else {}
            kind_counter[str(line.get('line_quality_v762') or line.get('line_source_kind_v762') or 'missing')] += 1
            side_counter[str(tax.get('side') or 'neutral')] += 1
            if (tax.get('good') or tax.get('bad') or tax.get('recheck')):
                tag_rows += 1
        save_json(STRUCTURE_SNAPSHOT_CACHE, {
            'schema': 'structure_snapshot_cache_v762',
            'version': VERSION,
            'updated_ts': nowv,
            'updated_text': now_text(nowv),
            'row_count': len(out),
            'structure_tag_rows': tag_rows,
            'line_quality_counts': dict(kind_counter),
            'taxonomy_side_counts': dict(side_counter),
            'sample': [{
                'ticker': x.get('ticker'),
                'stage': _v510_stage(x),
                'line': x.get('structure_line_source_kind_v762'),
                'quality': x.get('structure_line_quality_v762'),
                'side': (x.get('structure_taxonomy_v762') if isinstance(x.get('structure_taxonomy_v762'), dict) else {}).get('side'),
            } for x in out[:10]],
            'policy': 'lightweight cache built from existing candle/strategy row fields; no API call and no thresholds changed',
        })
    except Exception as exc:
        try: append_error(ERROR, 'v762_structure_snapshot_cache', exc)
        except Exception: pass
    return out


_v762_prev_apply_entry_plan_state = _v554_apply_entry_plan_state

def _v554_apply_entry_plan_state(rows: List[Dict[str, Any]], nowv: float) -> List[Dict[str, Any]]:  # type: ignore[override]
    rows2 = _v762_prev_apply_entry_plan_state(rows, nowv)
    return _v762_apply_structure_snapshot(rows2, nowv)

# =============================================================================
# strategy_worker v0.764: canonical entry basis/source unification
# - One user-readable basis table is sealed beside the structure snapshot.
# - This does not change candidate thresholds, exits, S1/S2/S3, BUY_READY, or auto-buy.
# =============================================================================
MAIN_BOT_VERSION = "수익형 v2.13.787"
VERSION = "strategy_worker_v0.789"
BUILD_LABEL = "v789_s2_to_s1_post_route_rejudge_2026-06-09"
ENTRY_BASIS_CACHE_V764 = BASE_DIR / "clean_entry_basis_audit_cache_v764.json"


def _v764_basis_float(*vals: Any, default: float = 0.0) -> float:
    return _v762_num(*vals, default=default)


def _v764_basis_age(row: Dict[str, Any], *keys: str, default: float = 999999.0) -> float:
    for k in keys:
        v = row.get(k)
        try:
            if v is not None and v != "":
                return float(v)
        except Exception:
            pass
    ctx = row.get('entry_context') if isinstance(row.get('entry_context'), dict) else {}
    for k in keys:
        v = ctx.get(k)
        try:
            if v is not None and v != "":
                return float(v)
        except Exception:
            pass
    return default


def _v764_price_basis(row: Dict[str, Any], snap: Dict[str, Any]) -> Dict[str, Any]:
    levels = row.get('structure_levels') if isinstance(row.get('structure_levels'), dict) else (snap.get('structure_levels') if isinstance(snap.get('structure_levels'), dict) else {})
    rr = row.get('risk_reward') if isinstance(row.get('risk_reward'), dict) else (snap.get('risk_reward') if isinstance(snap.get('risk_reward'), dict) else {})
    entry = _v764_basis_float(row.get('entry_price'), row.get('current_price'), row.get('price'), snap.get('entry_price'), default=0.0)
    current = _v764_basis_float(row.get('current_price'), row.get('price'), entry, default=0.0)
    trigger = _v764_basis_float(row.get('trigger_price'), levels.get('trigger_price'), levels.get('trigger'), snap.get('trigger_price'), default=0.0)
    target1 = _v764_basis_float(row.get('target1_price'), row.get('target_price'), levels.get('target1_price'), levels.get('target_price'), default=0.0)
    target2 = _v764_basis_float(row.get('target2_price'), levels.get('target2_price'), default=0.0)
    invalid = _v764_basis_float(row.get('invalid_price'), levels.get('invalid_price'), levels.get('stop_price'), default=0.0)
    rr_ratio = _v764_basis_float(rr.get('rr_ratio'), levels.get('rr_ratio'), row.get('rr_ratio'), snap.get('rr_ratio'), default=0.0)
    gap = None
    try:
        if entry > 0 and trigger > 0:
            gap = round((entry - trigger) / trigger * 100.0, 4)
    except Exception:
        gap = None
    return {
        'schema': 'price_basis_v764',
        'current_price': current,
        'entry_price': entry,
        'entry_price_basis': row.get('entry_price_basis') or row.get('current_price_source') or 'ticker_or_trade_latest',
        'trigger_price': trigger,
        'target1_price': target1,
        'target2_price': target2,
        'invalid_price': invalid,
        'trigger_gap_pct_from_entry': gap,
        'rr_ratio': rr_ratio,
        'rr_basis': 'entry_price_vs_target_invalid_same_snapshot_v764' if (entry and target1 and invalid) else 'rr_basis_incomplete',
    }


def _v764_source_basis(row: Dict[str, Any], snap: Dict[str, Any]) -> Dict[str, Any]:
    line = row.get('structure_line_source_v762') if isinstance(row.get('structure_line_source_v762'), dict) else (snap.get('structure_line_source_v762') if isinstance(snap.get('structure_line_source_v762'), dict) else {})
    official = snap.get('official_structure_inputs_raw') if isinstance(snap.get('official_structure_inputs_raw'), dict) else _v762_existing_official_pack(row)
    return {
        'schema': 'source_basis_v764',
        'current_price_source': row.get('current_price_source') or row.get('price_source') or 'ticker/trade/cache',
        'orderbook_source': row.get('orderbook_source') or 'orderflow_worker_cache',
        'trade_source': row.get('trade_source') or 'orderflow_worker_cache',
        'candle_source': official.get('official_candle_source') or row.get('official_candle_source') or 'candle_worker_cache',
        'structure_line_source': line.get('line_source_kind_v762') or line.get('source_kind') or 'derived_unknown',
        'structure_line_quality': line.get('line_quality_v762') or line.get('reliability') or 'missing',
        'formula_version': 'entry_basis_unify_v764',
        'age_sec': {
            'price': _v764_basis_age(row, 'price_age_sec', 'ticker_age_sec', 'current_price_age_sec', default=999999.0),
            'orderbook': _v764_basis_age(row, 'orderbook_age_sec', 'micro_age_sec', default=999999.0),
            'trade': _v764_basis_age(row, 'trade_age_sec', 'orderflow_age_sec', default=999999.0),
            'candle': _v764_basis_float(official.get('official_candle_age'), row.get('official_candle_age'), default=999999.0),
            'structure_snapshot': _v764_basis_age(row, 'structure_snapshot_age_sec', default=0.0),
        },
    }


def _v764_status_from_basis(price_basis: Dict[str, Any], source_basis: Dict[str, Any], snap: Dict[str, Any]) -> Dict[str, Any]:
    issues: List[str] = []
    warns: List[str] = []
    ages = source_basis.get('age_sec') if isinstance(source_basis.get('age_sec'), dict) else {}
    line_q = str(source_basis.get('structure_line_quality') or '')
    if not price_basis.get('entry_price') or not price_basis.get('trigger_price'):
        issues.append('현재가/방아쇠 기준값 부족')
    if not price_basis.get('target1_price') or not price_basis.get('invalid_price'):
        warns.append('목표/무효선 기준 일부 부족')
    if line_q in ('missing', 'missing_official', ''):
        warns.append('구조선 출처 확인 필요')
    elif line_q in ('official_weak', 'fallback_gap', 'synthetic_pct_line'):
        warns.append('일부 계산선 의존')
    try:
        if float(ages.get('candle', 999999.0)) > 180.0:
            warns.append('캔들 정보 오래됨')
        if float(ages.get('orderbook', 999999.0)) > 15.0:
            warns.append('호가 정보 오래됨')
        if float(ages.get('trade', 999999.0)) > 15.0:
            warns.append('체결 정보 오래됨')
    except Exception:
        pass
    if issues:
        status = '❌ 기준 불일치'
    elif warns:
        status = '⚠️ 일부 주의'
    else:
        status = '✅ 기준 일치'
    return {'status': status, 'issues': issues, 'warnings': warns, 'user_text': status + ((' · ' + ' / '.join((issues + warns)[:3])) if (issues or warns) else '')}


def _v764_attach_entry_basis(row: Dict[str, Any]) -> Dict[str, Any]:
    if not isinstance(row, dict):
        return row
    r = dict(row)
    snap = r.get('canonical_entry_snapshot_v762') if isinstance(r.get('canonical_entry_snapshot_v762'), dict) else (r.get('canonical_entry_snapshot') if isinstance(r.get('canonical_entry_snapshot'), dict) else {})
    if not snap:
        # Keep a visible, non-blocking reason for downstream verification.
        r['canonical_entry_basis_v764'] = {'schema': 'canonical_entry_basis_v764', 'status': '❔ 정보 없음', 'missing_reason': 'no_strategy_snapshot_yet'}
        return r
    price_basis = _v764_price_basis(r, snap)
    source_basis = _v764_source_basis(r, snap)
    status = _v764_status_from_basis(price_basis, source_basis, snap)
    basis = {
        'schema': 'canonical_entry_basis_v764',
        'version': VERSION,
        'build': BUILD_LABEL,
        'ticker': r.get('ticker'),
        'price_basis': price_basis,
        'source_basis': source_basis,
        'basis_status': status,
        'structure_snapshot_schema': snap.get('schema'),
        'source_owner': 'strategy_worker_entry_basis_unify_v764',
        'policy': 'verification/sealing only; thresholds unchanged',
    }
    # Attach basis both as standalone and inside snapshot so paper can copy one object.
    snap2 = dict(snap)
    snap2['canonical_entry_basis_v764'] = basis
    snap2['entry_basis_check_v764'] = status
    r['canonical_entry_basis_v764'] = basis
    r['entry_basis_check_v764'] = status
    r['canonical_entry_snapshot_v764'] = snap2
    r['canonical_entry_snapshot'] = snap2
    ctx = r.get('entry_context') if isinstance(r.get('entry_context'), dict) else {}
    ctx = dict(ctx)
    ctx['canonical_entry_basis_v764'] = basis
    ctx['canonical_entry_snapshot_v764'] = snap2
    r['entry_context'] = ctx
    return r


def _v764_apply_entry_basis(rows: List[Dict[str, Any]], nowv: float) -> List[Dict[str, Any]]:
    out = [_v764_attach_entry_basis(r) for r in (rows or []) if isinstance(r, dict)]
    try:
        status_counter: Counter = Counter()
        line_counter: Counter = Counter()
        complete = 0
        samples = []
        for r in out:
            basis = r.get('canonical_entry_basis_v764') if isinstance(r.get('canonical_entry_basis_v764'), dict) else {}
            status = basis.get('basis_status') if isinstance(basis.get('basis_status'), dict) else {}
            label = str(status.get('status') or '❔ 정보 없음')
            status_counter[label] += 1
            sb = basis.get('source_basis') if isinstance(basis.get('source_basis'), dict) else {}
            line_counter[str(sb.get('structure_line_quality') or 'missing')] += 1
            pb = basis.get('price_basis') if isinstance(basis.get('price_basis'), dict) else {}
            if pb.get('entry_price') and pb.get('trigger_price') and pb.get('target1_price') and pb.get('invalid_price'):
                complete += 1
            if len(samples) < 8:
                samples.append({'ticker': r.get('ticker'), 'stage': _v510_stage(r), 'status': label, 'line_quality': sb.get('structure_line_quality'), 'rr': pb.get('rr_ratio')})
        save_json(ENTRY_BASIS_CACHE_V764, {
            'schema': 'entry_basis_audit_cache_v764',
            'version': VERSION,
            'updated_ts': nowv,
            'updated_text': now_text(nowv),
            'row_count': len(out),
            'basis_complete_rows': complete,
            'status_counts': dict(status_counter),
            'line_quality_counts': dict(line_counter),
            'sample': samples,
            'policy': 'source/basis audit only; no threshold change',
        })
    except Exception as exc:
        try: append_error(ERROR, 'v764_entry_basis_cache', exc)
        except Exception: pass
    return out


_v764_prev_apply_entry_plan_state = _v554_apply_entry_plan_state

def _v554_apply_entry_plan_state(rows: List[Dict[str, Any]], nowv: float) -> List[Dict[str, Any]]:  # type: ignore[override]
    rows2 = _v764_prev_apply_entry_plan_state(rows, nowv)
    return _v764_apply_entry_basis(rows2, nowv)



# =============================================================================
# strategy_worker v0.765: entry-basis warning reason split for readable classify
# - Keeps v764 canonical_entry_basis_v764 schema/path.
# - Adds reason counters so main_bot can show why rows are "일부 주의".
# - No threshold, exit, S1/S2/S3, BUY_READY, or auto-buy change.
# =============================================================================
MAIN_BOT_VERSION = "수익형 v2.13.787"
VERSION = "strategy_worker_v0.789"
BUILD_LABEL = "v789_s2_to_s1_post_route_rejudge_2026-06-09"


def _v765_apply_entry_basis(rows: List[Dict[str, Any]], nowv: float) -> List[Dict[str, Any]]:
    out = [_v764_attach_entry_basis(r) for r in (rows or []) if isinstance(r, dict)]
    try:
        status_counter: Counter = Counter()
        line_counter: Counter = Counter()
        reason_counter: Counter = Counter()
        issue_counter: Counter = Counter()
        complete = 0
        samples = []
        for r in out:
            basis = r.get('canonical_entry_basis_v764') if isinstance(r.get('canonical_entry_basis_v764'), dict) else {}
            status = basis.get('basis_status') if isinstance(basis.get('basis_status'), dict) else {}
            label = str(status.get('status') or '❔ 정보 없음')
            status_counter[label] += 1
            for w in status.get('warnings') if isinstance(status.get('warnings'), list) else []:
                reason_counter[str(w)] += 1
            for i in status.get('issues') if isinstance(status.get('issues'), list) else []:
                issue_counter[str(i)] += 1
            sb = basis.get('source_basis') if isinstance(basis.get('source_basis'), dict) else {}
            line_counter[str(sb.get('structure_line_quality') or 'missing')] += 1
            pb = basis.get('price_basis') if isinstance(basis.get('price_basis'), dict) else {}
            if pb.get('entry_price') and pb.get('trigger_price') and pb.get('target1_price') and pb.get('invalid_price'):
                complete += 1
            if len(samples) < 8:
                samples.append({
                    'ticker': r.get('ticker'),
                    'stage': _v510_stage(r),
                    'status': label,
                    'reason': ' / '.join((status.get('issues') or []) + (status.get('warnings') or []))[:120],
                    'line_quality': sb.get('structure_line_quality'),
                    'rr': pb.get('rr_ratio'),
                })
        save_json(ENTRY_BASIS_CACHE_V764, {
            'schema': 'entry_basis_audit_cache_v765',
            'version': VERSION,
            'updated_ts': nowv,
            'updated_text': now_text(nowv),
            'row_count': len(out),
            'basis_complete_rows': complete,
            'status_counts': dict(status_counter),
            'warning_reason_counts': dict(reason_counter),
            'issue_reason_counts': dict(issue_counter),
            'line_quality_counts': dict(line_counter),
            'sample': samples,
            'policy': 'source/basis audit only; no threshold change',
        })
    except Exception as exc:
        try: append_error(ERROR, 'v765_entry_basis_reason_cache', exc)
        except Exception: pass
    return out


_v765_prev_apply_entry_plan_state = globals().get('_v764_prev_apply_entry_plan_state', _v554_apply_entry_plan_state)

def _v554_apply_entry_plan_state(rows: List[Dict[str, Any]], nowv: float) -> List[Dict[str, Any]]:  # type: ignore[override]
    rows2 = _v765_prev_apply_entry_plan_state(rows, nowv)
    return _v765_apply_entry_basis(rows2, nowv)


# =============================================================================
# strategy_worker v0.766: readable entry-basis detail split
# - Splits "일부 주의" into actionable buckets: orderbook/trade/candle/line.
# - Adds S1/S2-focused counts and samples for main_bot readability.
# - Verification/cache only. No threshold, exit, S1/S2/S3, BUY_READY, or auto-buy change.
# =============================================================================
MAIN_BOT_VERSION = "수익형 v2.13.787"
VERSION = "strategy_worker_v0.789"
BUILD_LABEL = "v789_s2_to_s1_post_route_rejudge_2026-06-09"


def _v766_stage_bucket(row: Dict[str, Any]) -> str:
    try:
        st = str(_v510_stage(row) or row.get('grade') or row.get('stage') or '').upper()
    except Exception:
        st = str(row.get('grade') or row.get('stage') or '').upper() if isinstance(row, dict) else ''
    if 'S1' in st:
        return 'S1'
    if 'S2' in st:
        return 'S2'
    if 'S3' in st:
        return 'S3'
    if 'COVER' in st or 'RAW' in st:
        return 'coverage'
    return '기타'


def _v766_age_bucket(age: Any, base: str) -> str:
    try:
        a = float(age)
    except Exception:
        return f'{base} timestamp 없음'
    if a >= 999998:
        return f'{base} timestamp 없음'
    if a > 300:
        return f'{base} 5분 초과'
    if a > 60:
        return f'{base} 1분 초과'
    if a > 15:
        return f'{base} 15~60초'
    return f'{base} 정상'


def _v766_line_reason(row: Dict[str, Any], basis: Dict[str, Any]) -> str:
    sb = basis.get('source_basis') if isinstance(basis.get('source_basis'), dict) else {}
    q = str(sb.get('structure_line_quality') or '')
    snap = row.get('canonical_entry_snapshot_v764') if isinstance(row.get('canonical_entry_snapshot_v764'), dict) else (row.get('canonical_entry_snapshot') if isinstance(row.get('canonical_entry_snapshot'), dict) else {})
    line = snap.get('structure_line_source_v762') if isinstance(snap.get('structure_line_source_v762'), dict) else {}
    if not line:
        st = snap.get('structure') if isinstance(snap.get('structure'), dict) else {}
        line = st.get('line_source') if isinstance(st.get('line_source'), dict) else {}
    present = _v762_num(line.get('official_present_count_v762'), default=0.0) if isinstance(line, dict) else 0.0
    age = None
    try:
        ages = sb.get('age_sec') if isinstance(sb.get('age_sec'), dict) else {}
        age = float(ages.get('candle', 999999.0))
    except Exception:
        age = 999999.0
    if q in ('missing', 'missing_official', ''):
        return '공식캔들 부족'
    if q == 'official_weak':
        if age and age > 300:
            return '공식캔들 오래됨'
        if present <= 1:
            return 'swing/box 근거 부족'
        return '공식근거 약함'
    if q in ('fallback_gap', 'synthetic_pct_line'):
        return '계산선 fallback 사용'
    if q == 'official_partial':
        return '공식선 일부만 사용'
    if q == 'official_full':
        return '공식선 확실'
    return q or '구조선 출처 불명확'


def _v766_apply_entry_basis(rows: List[Dict[str, Any]], nowv: float) -> List[Dict[str, Any]]:
    out = [_v764_attach_entry_basis(r) for r in (rows or []) if isinstance(r, dict)]
    try:
        status_counter: Counter = Counter()
        warn_counter: Counter = Counter()
        issue_counter: Counter = Counter()
        line_counter: Counter = Counter()
        orderbook_counter: Counter = Counter()
        trade_counter: Counter = Counter()
        candle_counter: Counter = Counter()
        line_reason_counter: Counter = Counter()
        focus_counter: Counter = Counter()
        stage_counter: Counter = Counter()
        complete = 0
        samples = []
        focus_samples = []
        for r in out:
            basis = r.get('canonical_entry_basis_v764') if isinstance(r.get('canonical_entry_basis_v764'), dict) else {}
            st = basis.get('basis_status') if isinstance(basis.get('basis_status'), dict) else {}
            label = str(st.get('status') or '❔ 정보 없음')
            status_counter[label] += 1
            stage = _v766_stage_bucket(r)
            stage_counter[stage] += 1
            for w in st.get('warnings') if isinstance(st.get('warnings'), list) else []:
                warn_counter[str(w)] += 1
            for i in st.get('issues') if isinstance(st.get('issues'), list) else []:
                issue_counter[str(i)] += 1
            sb = basis.get('source_basis') if isinstance(basis.get('source_basis'), dict) else {}
            ages = sb.get('age_sec') if isinstance(sb.get('age_sec'), dict) else {}
            line_q = str(sb.get('structure_line_quality') or 'missing')
            line_counter[line_q] += 1
            orderbook_reason = _v766_age_bucket(ages.get('orderbook', 999999.0), '호가')
            trade_reason = _v766_age_bucket(ages.get('trade', 999999.0), '체결')
            candle_reason = _v766_age_bucket(ages.get('candle', 999999.0), '캔들')
            if '정상' not in orderbook_reason:
                orderbook_counter[orderbook_reason] += 1
            if '정상' not in trade_reason:
                trade_counter[trade_reason] += 1
            if '정상' not in candle_reason:
                candle_counter[candle_reason] += 1
            lr = _v766_line_reason(r, basis)
            if lr not in ('공식선 확실',):
                line_reason_counter[lr] += 1
            if stage in ('S1', 'S2'):
                if label.startswith('⚠️'):
                    focus_counter[f'{stage} 일부주의'] += 1
                elif label.startswith('✅'):
                    focus_counter[f'{stage} 기준일치'] += 1
                elif label.startswith('❌'):
                    focus_counter[f'{stage} 불일치'] += 1
                else:
                    focus_counter[f'{stage} 정보없음'] += 1
            pb = basis.get('price_basis') if isinstance(basis.get('price_basis'), dict) else {}
            if pb.get('entry_price') and pb.get('trigger_price') and pb.get('target1_price') and pb.get('invalid_price'):
                complete += 1
            if len(samples) < 8:
                reason_parts = []
                reason_parts.extend(st.get('issues') if isinstance(st.get('issues'), list) else [])
                reason_parts.extend(st.get('warnings') if isinstance(st.get('warnings'), list) else [])
                if lr and lr not in reason_parts:
                    reason_parts.append(lr)
                samples.append({
                    'ticker': r.get('ticker'),
                    'grade': stage,
                    'status': label,
                    'reason': ' / '.join([str(x) for x in reason_parts if x])[:160],
                    'line_quality': line_q,
                    'rr': pb.get('rr_ratio'),
                })
            if stage in ('S1', 'S2') and len(focus_samples) < 6:
                focus_samples.append(samples[-1] if samples else {'ticker': r.get('ticker'), 'grade': stage, 'status': label})
        save_json(ENTRY_BASIS_CACHE_V764, {
            'schema': 'entry_basis_audit_cache_v766',
            'version': VERSION,
            'updated_ts': nowv,
            'updated_text': now_text(nowv),
            'row_count': len(out),
            'basis_complete_rows': complete,
            'status_counts': dict(status_counter),
            'warning_reason_counts': dict(warn_counter),
            'issue_reason_counts': dict(issue_counter),
            'line_quality_counts': dict(line_counter),
            'orderbook_detail_counts': dict(orderbook_counter),
            'trade_detail_counts': dict(trade_counter),
            'candle_detail_counts': dict(candle_counter),
            'line_detail_counts': dict(line_reason_counter),
            'focus_status_counts': dict(focus_counter),
            'stage_counts': dict(stage_counter),
            'sample': samples,
            'focus_sample': focus_samples,
            'policy': 'readable source/basis diagnostics only; no threshold change',
        })
    except Exception as exc:
        try: append_error(ERROR, 'v766_entry_basis_detail_cache', exc)
        except Exception: pass
    return out


_v766_prev_apply_entry_plan_state = globals().get('_v765_prev_apply_entry_plan_state', _v554_apply_entry_plan_state)

def _v554_apply_entry_plan_state(rows: List[Dict[str, Any]], nowv: float) -> List[Dict[str, Any]]:  # type: ignore[override]
    rows2 = _v766_prev_apply_entry_plan_state(rows, nowv)
    return _v766_apply_entry_basis(rows2, nowv)




# =============================================================================
# strategy_worker v0.769: source-age key unification + timeframe TTL fix
# - Root fix after v766: the basis table was reading too narrow age keys and
#   treating all candle lines with one short TTL. This block replaces the source
#   basis reader/status maker used by _v764_attach_entry_basis, then reuses the
#   existing v766 readable cache writer.
# - Verification/cache only. No threshold, exit, S1/S2/S3, BUY_READY, or auto-buy change.
# =============================================================================
MAIN_BOT_VERSION = "수익형 v2.13.787"
VERSION = "strategy_worker_v0.789"
BUILD_LABEL = "v789_s2_to_s1_post_route_rejudge_2026-06-09"

_V767_AGE_KEY_MAP = {
    'price': (
        'price_age_sec','ticker_age_sec','current_price_age_sec','last_price_age_sec','trade_price_age_sec',
        'ticker_source_age_sec','price_source_age_sec','ws_price_age_sec','market_age_sec','source_age_sec'
    ),
    'orderbook': (
        'orderbook_age_sec','orderbook_source_age_sec','orderbook_cache_age_sec','orderbook_updated_age_sec',
        'quote_age_sec','quote_source_age_sec','best_bid_age_sec','best_ask_age_sec','bid_age_sec','ask_age_sec',
        'spread_age_sec','micro_orderbook_age_sec','micro_quote_age_sec','micro_source_age_sec','micro_age_sec',
        'ws_orderbook_age_sec','ws_quote_age_sec'
    ),
    'trade': (
        'trade_age_sec','trades_age_sec','trade_source_age_sec','trade_cache_age_sec','last_trade_age_sec',
        'orderflow_age_sec','orderflow_source_age_sec','orderflow_cache_age_sec','buy_ratio_age_sec','buy_sustain_age_sec',
        'micro_trade_age_sec','micro_trades_age_sec','micro_source_age_sec','micro_age_sec','ws_trade_age_sec','ws_trades_age_sec'
    ),
    'candle': (
        'official_candle_age','official_candle_age_sec','candle_age_sec','candle_source_age_sec','candle_cache_age_sec',
        'ohlcv_age_sec','ohlcv_source_age_sec','candle_updated_age_sec','structure_candle_age_sec','source_age_sec'
    ),
    'structure_snapshot': ('structure_snapshot_age_sec','snapshot_age_sec','canonical_snapshot_age_sec'),
}

_V767_TS_KEYS = (
    'updated_ts','update_ts','last_update_ts','source_ts','received_ts','recv_ts','ts','timestamp',
    'event_ts','created_at','time','datetime'
)


def _v767_now_ts() -> float:
    try:
        return float(time.time())
    except Exception:
        return 0.0


def _v767_as_ts(v: Any) -> float:
    if v in (None, '', [], {}):
        return 0.0
    try:
        x = float(str(v).replace(',', '').strip())
        if x > 1000000000000:  # ms
            x = x / 1000.0
        # ignore tiny OHLCV values accidentally passed as ts
        if x > 1000000000:
            return x
    except Exception:
        pass
    return 0.0


def _v767_age_from_ts(v: Any) -> float:
    ts = _v767_as_ts(v)
    if not ts:
        return 999999.0
    nowv = _v767_now_ts()
    if not nowv:
        return 999999.0
    age = nowv - ts
    if age < 0:
        return 0.0
    if age < 86400 * 7:
        return float(age)
    return 999999.0


def _v767_float_age(v: Any) -> float:
    try:
        if v not in (None, '', [], {}):
            a = float(str(v).replace(',', '').replace('s','').strip())
            if 0 <= a < 86400 * 7:
                return a
    except Exception:
        pass
    return 999999.0


def _v767_sources(row: Dict[str, Any]) -> List[Dict[str, Any]]:
    row = row if isinstance(row, dict) else {}
    ctx = row.get('entry_context') if isinstance(row.get('entry_context'), dict) else {}
    raw = row.get('raw') if isinstance(row.get('raw'), dict) else {}
    diag = row.get('entry_diagnostics') if isinstance(row.get('entry_diagnostics'), dict) else {}
    snap = row.get('canonical_entry_snapshot_v762') if isinstance(row.get('canonical_entry_snapshot_v762'), dict) else row.get('canonical_entry_snapshot') if isinstance(row.get('canonical_entry_snapshot'), dict) else {}
    out: List[Dict[str, Any]] = []
    for src in (row, ctx, raw, diag, snap):
        if isinstance(src, dict):
            out.append(src)
            for nk in ('orderbook','quote','quotes','micro','orderflow','trade','trades','ticker','market','price','candle','candles','ohlcv','feature','features','structure','freshness','ages','source_age','source_ages'):
                v = src.get(nk)
                if isinstance(v, dict):
                    out.append(v)
    return out


def _v767_lookup_age(row: Dict[str, Any], group: str, *extra_keys: str, default: float = 999999.0) -> float:
    keys: List[str] = []
    keys.extend(_V767_AGE_KEY_MAP.get(group, ()))
    keys.extend(extra_keys or ())
    sources = _v767_sources(row)
    # direct age fields
    for src in sources:
        for k in keys:
            if k in src:
                a = _v767_float_age(src.get(k))
                if a < 999998:
                    return a
    # common age_sec fields inside nested sources
    for src in sources:
        for k in ('age_sec','age','source_age_sec','cache_age_sec','updated_age_sec','fresh_age_sec'):
            if k in src:
                a = _v767_float_age(src.get(k))
                if a < 999998:
                    return a
    # timestamp fields
    for src in sources:
        for k in list(keys) + list(_V767_TS_KEYS):
            if k in src:
                a = _v767_age_from_ts(src.get(k))
                if a < 999998:
                    return a
    return default


def _v767_candle_interval_info(row: Dict[str, Any], official: Dict[str, Any]) -> Dict[str, Any]:
    row = row if isinstance(row, dict) else {}
    official = official if isinstance(official, dict) else {}
    intervals = official.get('official_candle_intervals') or row.get('official_candle_intervals') or ''
    if isinstance(intervals, (list, tuple, set)):
        ints = [str(x).lower() for x in intervals]
    else:
        ints = [x.strip().lower() for x in str(intervals).replace('|', '/').replace(',', '/').split('/') if x.strip()]
    # Look for timeframe-specific ages if future workers provide them.
    ages_by_tf: Dict[str, float] = {}
    for tf in ('1m','3m','5m','15m','30m','1h','2h','4h'):
        for k in (f'candle_{tf}_age_sec', f'{tf}_candle_age_sec', f'ohlcv_{tf}_age_sec', f'age_{tf}', f'{tf}_age_sec'):
            val = official.get(k, row.get(k))
            a = _v767_float_age(val)
            if a < 999998:
                ages_by_tf[tf] = a
                break
    raw_age = _v767_float_age(official.get('official_candle_age'))
    if raw_age >= 999998:
        raw_age = _v767_lookup_age(row, 'candle', default=999999.0)
    has_short = any(tf in ints for tf in ('1m','3m','5m')) or not ints
    has_mid = any(tf in ints for tf in ('15m','30m'))
    has_long = any(tf in ints for tf in ('1h','2h','4h','60m'))
    # A single mixed official_candle_age may represent long-structure age; don't use 5m TTL blindly.
    if ages_by_tf:
        max_short = max([ages_by_tf.get(tf, 0) for tf in ('1m','3m','5m')] or [0])
        max_mid = max([ages_by_tf.get(tf, 0) for tf in ('15m','30m')] or [0])
        max_long = max([ages_by_tf.get(tf, 0) for tf in ('1h','2h','4h')] or [0])
        stale = False
        reason = []
        if max_short and max_short > 90:
            stale = True; reason.append('단기 캔들 오래됨')
        if max_mid and max_mid > 900:
            stale = True; reason.append('중기 캔들 오래됨')
        if max_long and max_long > 5400:
            stale = True; reason.append('장기 캔들 오래됨')
        status = 'stale' if stale else 'ok'
        effective_age = max(ages_by_tf.values()) if ages_by_tf else raw_age
    else:
        # No timeframe split. Use a looser TTL when long/mid intervals are present.
        if raw_age >= 999998:
            status, reason, effective_age = 'missing_ts', ['캔들 timestamp 없음'], raw_age
        else:
            ttl = 300.0
            if has_long:
                ttl = 5400.0
            elif has_mid:
                ttl = 900.0
            elif has_short:
                ttl = 180.0
            status = 'stale' if raw_age > ttl else 'ok'
            reason = ['캔들 시간봉 기준 오래됨'] if status == 'stale' else []
            effective_age = raw_age
    return {
        'intervals': ints,
        'ages_by_tf': ages_by_tf,
        'raw_age_sec': raw_age,
        'effective_age_sec': effective_age,
        'status': status,
        'reason': reason,
        'policy': 'timeframe-aware TTL: short 90~180s, mid 900s, long 5400s; audit only',
    }


def _v767_source_basis(row: Dict[str, Any], snap: Dict[str, Any]) -> Dict[str, Any]:
    line = row.get('structure_line_source_v762') if isinstance(row.get('structure_line_source_v762'), dict) else (snap.get('structure_line_source_v762') if isinstance(snap.get('structure_line_source_v762'), dict) else {})
    official = snap.get('official_structure_inputs_raw') if isinstance(snap.get('official_structure_inputs_raw'), dict) else _v762_existing_official_pack(row)
    candle_info = _v767_candle_interval_info(row, official)
    return {
        'schema': 'source_basis_v767',
        'current_price_source': row.get('current_price_source') or row.get('price_source') or 'ticker/trade/cache',
        'orderbook_source': row.get('orderbook_source') or row.get('quote_source') or 'orderflow_or_micro_cache',
        'trade_source': row.get('trade_source') or row.get('orderflow_source') or 'orderflow_or_micro_cache',
        'candle_source': official.get('official_candle_source') or row.get('official_candle_source') or 'candle_worker_cache',
        'structure_line_source': line.get('line_source_kind_v762') or line.get('source_kind') or 'derived_unknown',
        'structure_line_quality': line.get('line_quality_v762') or line.get('reliability') or 'missing',
        'formula_version': 'entry_basis_source_unify_v767',
        'age_sec': {
            'price': _v767_lookup_age(row, 'price', default=999999.0),
            'orderbook': _v767_lookup_age(row, 'orderbook', default=999999.0),
            'trade': _v767_lookup_age(row, 'trade', default=999999.0),
            'candle': candle_info.get('effective_age_sec', 999999.0),
            'structure_snapshot': _v767_lookup_age(row, 'structure_snapshot', default=0.0),
        },
        'candle_timeframe_check_v767': candle_info,
        'age_key_policy_v767': 'read multiple worker/cache age keys and timestamp keys; missing only after all sources fail',
    }


def _v767_status_from_basis(price_basis: Dict[str, Any], source_basis: Dict[str, Any], snap: Dict[str, Any]) -> Dict[str, Any]:
    issues: List[str] = []
    warns: List[str] = []
    ages = source_basis.get('age_sec') if isinstance(source_basis.get('age_sec'), dict) else {}
    line_q = str(source_basis.get('structure_line_quality') or '')
    if not price_basis.get('entry_price') or not price_basis.get('trigger_price'):
        issues.append('현재가/방아쇠 기준값 부족')
    if not price_basis.get('target1_price') or not price_basis.get('invalid_price'):
        warns.append('목표/무효선 기준 일부 부족')
    if line_q in ('missing', 'missing_official', ''):
        warns.append('구조선 출처 확인 필요')
    elif line_q in ('official_weak', 'fallback_gap', 'synthetic_pct_line'):
        warns.append('일부 계산선 의존')
    try:
        ob = float(ages.get('orderbook', 999999.0))
        tr = float(ages.get('trade', 999999.0))
        if ob >= 999998:
            warns.append('호가 timestamp 없음')
        elif ob > 60:
            warns.append('호가 1분 초과')
        elif ob > 15:
            warns.append('호가 15~60초')
        if tr >= 999998:
            warns.append('체결 timestamp 없음')
        elif tr > 60:
            warns.append('체결 1분 초과')
        elif tr > 15:
            warns.append('체결 15~60초')
    except Exception:
        pass
    ci = source_basis.get('candle_timeframe_check_v767') if isinstance(source_basis.get('candle_timeframe_check_v767'), dict) else {}
    if ci.get('status') == 'missing_ts':
        warns.append('캔들 timestamp 없음')
    elif ci.get('status') == 'stale':
        for r in ci.get('reason') if isinstance(ci.get('reason'), list) else ['캔들 오래됨']:
            warns.append(str(r))
    if issues:
        status = '❌ 기준 불일치'
    elif warns:
        status = '⚠️ 일부 주의'
    else:
        status = '✅ 기준 일치'
    return {'status': status, 'issues': issues, 'warnings': _v510_uniq(warns, 12), 'user_text': status + ((' · ' + ' / '.join((issues + warns)[:3])) if (issues or warns) else '')}

# Replace the source/basis readers used by the canonical entry-basis sealer.
_v764_source_basis = _v767_source_basis  # type: ignore[assignment]
_v764_status_from_basis = _v767_status_from_basis  # type: ignore[assignment]


def _v766_age_bucket(age: Any, base: str = '') -> str:  # type: ignore[override]
    try:
        a = float(age)
    except Exception:
        return 'timestamp 없음'
    if a >= 999998:
        return 'timestamp 없음'
    if a > 300:
        return '5분 초과'
    if a > 60:
        return '1분 초과'
    if a > 15:
        return '15~60초'
    return '정상'

# Keep the v766 readable cache writer, but now it uses the v767 source reader/status maker.
_v767_prev_apply_entry_plan_state = globals().get('_v766_prev_apply_entry_plan_state', _v554_apply_entry_plan_state)

def _v554_apply_entry_plan_state(rows: List[Dict[str, Any]], nowv: float) -> List[Dict[str, Any]]:  # type: ignore[override]
    rows2 = _v767_prev_apply_entry_plan_state(rows, nowv)
    return _v766_apply_entry_basis(rows2, nowv)



# =============================================================================
# strategy_worker v0.769: official candle material spine root fix
# - Root cause fixed before more output-only classification:
#   candle official material extraction now reads short/mid/long timeframe keys.
# - Adds timeframe-specific material/age fields into the canonical row and uses
#   those fields when deciding structure-line source quality.
# - No entry threshold, exit, S1/S2/S3, BUY_READY, or auto-buy change.
# =============================================================================
BUILD_LABEL = "v789_s2_to_s1_post_route_rejudge_2026-06-09"
MAIN_DEPLOY_VERSION = "v2.13.783"
MAIN_BOT_VERSION = "수익형 v2.13.787"
VERSION = "strategy_worker_v0.789"

_V769_TF_PREFIXES = ("m1", "m3", "m5", "m15", "m30", "h1", "1h", "h2", "2h", "h4", "4h")
_V769_TF_LABEL = {"m1":"1m","m3":"3m","m5":"5m","m15":"15m","m30":"30m","h1":"1h","1h":"1h","h2":"2h","2h":"2h","h4":"4h","4h":"4h"}
_V769_SHORT = {"1m", "3m", "5m"}
_V769_MID = {"15m", "30m"}
_V769_LONG = {"1h", "2h", "4h"}


def _v769_first_existing(src: Dict[str, Any], *keys: str) -> Any:
    if not isinstance(src, dict):
        return None
    for k in keys:
        v = src.get(k)
        if v not in (None, "", [], {}):
            return v
    return None


def _v769_pick_candle_value(c: Dict[str, Any], key: str, prefixes: Tuple[str, ...] = _V769_TF_PREFIXES) -> Any:
    if not isinstance(c, dict):
        return None
    for pref in prefixes:
        for k in (f"{pref}_{key}", f"{_V769_TF_LABEL.get(pref, pref)}_{key}"):
            v = c.get(k)
            if v not in (None, ""):
                return v
    return c.get(key) if c.get(key) not in (None, "") else None

# override the narrow v597 picker used by the overlay path
_v597_pick_candle_value = _v769_pick_candle_value  # type: ignore[assignment]


def _v769_age_from_cache(c: Dict[str, Any], pref: str, nowv: float) -> float:
    label = _V769_TF_LABEL.get(pref, pref)
    # age fields first
    for k in (
        f"{pref}_age_sec", f"{pref}_candle_age_sec", f"candle_{label}_age_sec", f"{label}_candle_age_sec",
        f"ohlcv_{label}_age_sec", f"age_{label}", f"{label}_age_sec",
    ):
        a = _v767_float_age(c.get(k)) if '_v767_float_age' in globals() else _v762_num(c.get(k), default=999999.0)
        if a < 999998:
            return float(a)
    # timestamp fields
    for k in (
        f"{pref}_ts", f"{pref}_candle_ts", f"{label}_ts", f"{label}_candle_ts",
        f"ohlcv_{label}_ts", f"{pref}_updated_at", f"{label}_updated_at",
    ):
        ts = _v767_as_ts(c.get(k)) if '_v767_as_ts' in globals() else 0.0
        if ts > 0:
            return round(max(0.0, nowv - ts), 1)
    return 999999.0


def _v769_tf_material(c: Dict[str, Any], nowv: float) -> Dict[str, Any]:
    out: Dict[str, Any] = {}
    groups = {'short': set(), 'mid': set(), 'long': set()}
    present_by_tf: Dict[str, int] = {}
    age_by_tf: Dict[str, float] = {}
    keys = ('swing_high_price','swing_low_price','box_high_price','box_low_price','recent_high_price','recent_low_price','upper_wick_pct','lower_wick_pct','support_touch_count','resistance_touch_count')
    for pref in _V769_TF_PREFIXES:
        label = _V769_TF_LABEL.get(pref, pref)
        cnt = 0
        for key in keys:
            if _v769_first_existing(c, f"{pref}_{key}", f"{label}_{key}") not in (None, "", [], {}):
                cnt += 1
        ok = bool(c.get(f"{pref}_ok") or c.get(f"{label}_ok") or cnt > 0)
        if ok:
            present_by_tf[label] = cnt
            age = _v769_age_from_cache(c, pref, nowv)
            age_by_tf[label] = age
            if label in _V769_SHORT:
                groups['short'].add(label)
            elif label in _V769_MID:
                groups['mid'].add(label)
            elif label in _V769_LONG:
                groups['long'].add(label)
    out['tf_present_by_group_v769'] = {k: sorted(v) for k, v in groups.items()}
    out['tf_present_counts_v769'] = present_by_tf
    out['tf_age_sec_v769'] = age_by_tf
    out['official_candle_intervals'] = '/'.join([*sorted(groups['short']), *sorted(groups['mid']), *sorted(groups['long'])]) or ''
    # flat age keys read by v767 TTL logic
    for tf, age in age_by_tf.items():
        out[f'candle_{tf}_age_sec'] = age
        out[f'{tf}_candle_age_sec'] = age
    out['short_tf_count_v769'] = len(groups['short'])
    out['mid_tf_count_v769'] = len(groups['mid'])
    out['long_tf_count_v769'] = len(groups['long'])
    return out


def _v597_candle_official_fields(c: Dict[str, Any], nowv: Optional[float] = None) -> Dict[str, Any]:  # type: ignore[override]
    """v769: official candle overlay now reads 1m/3m/5m + 15m/30m + 1h/2h/4h.
    candle_worker remains the raw-data owner; strategy only seals available cache fields.
    """
    if not isinstance(c, dict) or not c:
        return {}
    ts = nowv or now_ts()
    tfmat = _v769_tf_material(c, ts)
    if not any(tfmat.get('tf_present_by_group_v769', {}).values()) and not any(c.get(f'{p}_swing_high_price') for p in _V769_TF_PREFIXES):
        return {}
    out: Dict[str, Any] = {
        'official_candle_source': 'candle_worker_direct_cache_v769',
        'official_candle_cache_schema': c.get('official_structure_schema') or c.get('schema') or 'candle_cache_multi_tf_official_structure_inputs_v769',
        'official_structure_source': 'candle_worker_cache_overlay_v769',
        'official_structure_formula_v769': 'multi_tf_material_spine_v769',
    }
    out.update(tfmat)
    # Representative age: prefer shortest fresh available age, otherwise raw cache ts.
    ages = [a for a in (tfmat.get('tf_age_sec_v769') or {}).values() if isinstance(a, (int,float)) and a < 999998]
    if ages:
        out['official_candle_age'] = round(min(ages), 1)
    else:
        candle_ts = _v510_num(c.get('candle_ts'), default=0.0) if '_v510_num' in globals() else 0.0
        if candle_ts > 0:
            out['official_candle_age'] = round(max(0.0, ts - candle_ts), 1)
    # Unprefixed canonical values: short first for timing lines, but long/mid are retained in tf fields above.
    for key in V597_OFFICIAL_STRUCTURE_KEYS:
        if key in out:
            continue
        v = _v769_pick_candle_value(c, key)
        if v not in (None, ''):
            out[key] = v
    # Per-timeframe raw levels for audit/next surgery.
    for pref in _V769_TF_PREFIXES:
        label = _V769_TF_LABEL.get(pref, pref)
        for key in ('swing_high_price','swing_low_price','box_high_price','box_low_price','recent_high_price','recent_low_price'):
            v = _v769_first_existing(c, f'{pref}_{key}', f'{label}_{key}')
            if v not in (None, '', [], {}):
                out[f'{label}_{key}'] = v
    return out


def _v769_tf_ok(age_by_tf: Dict[str, Any], group: str) -> bool:
    vals: List[float] = []
    wanted = _V769_SHORT if group == 'short' else _V769_MID if group == 'mid' else _V769_LONG
    for tf in wanted:
        try:
            a = float(age_by_tf.get(tf, 999999.0))
        except Exception:
            a = 999999.0
        if a < 999998:
            vals.append(a)
    if not vals:
        return False
    ttl = 180.0 if group == 'short' else 900.0 if group == 'mid' else 5400.0
    return min(vals) <= ttl


def _v762_support_resistance_from_official(row: Dict[str, Any], official: Dict[str, Any]) -> Dict[str, Any]:  # type: ignore[override]
    price = _v762_num(row.get('current_price'), row.get('entry_price'), row.get('price'), default=0.0)
    vals = {
        'swing_high_price': _v762_num(official.get('swing_high_price'), row.get('swing_high_price'), default=0.0),
        'swing_low_price': _v762_num(official.get('swing_low_price'), row.get('swing_low_price'), default=0.0),
        'box_high_price': _v762_num(official.get('box_high_price'), row.get('box_high_price'), default=0.0),
        'box_low_price': _v762_num(official.get('box_low_price'), row.get('box_low_price'), default=0.0),
        'recent_high_price': _v762_num(official.get('recent_high_price'), row.get('recent_high_price'), default=0.0),
        'recent_low_price': _v762_num(official.get('recent_low_price'), row.get('recent_low_price'), default=0.0),
    }
    support_cands = [v for k, v in vals.items() if ('low' in k or 'box_low' in k) and v and (not price or v <= price * 1.003)]
    resist_cands = [v for k, v in vals.items() if ('high' in k or 'box_high' in k) and v and (not price or v >= price * 0.997)]
    support = max([x for x in support_cands if not price or x <= price] or support_cands or [0.0])
    resistance = min([x for x in resist_cands if not price or x >= price] or resist_cands or [0.0])
    present = sum(1 for v in vals.values() if v)
    candle_info = _v767_candle_interval_info(row, official) if '_v767_candle_interval_info' in globals() else {}
    age_by_tf = candle_info.get('ages_by_tf') if isinstance(candle_info.get('ages_by_tf'), dict) else {}
    short_ok = _v769_tf_ok(age_by_tf, 'short') or bool(official.get('short_tf_count_v769') or row.get('short_tf_count_v769'))
    mid_ok = _v769_tf_ok(age_by_tf, 'mid') or bool(official.get('mid_tf_count_v769') or row.get('mid_tf_count_v769'))
    long_ok = _v769_tf_ok(age_by_tf, 'long') or bool(official.get('long_tf_count_v769') or row.get('long_tf_count_v769'))
    reasons: List[str] = []
    if not short_ok: reasons.append('단기 1/3/5분 구조재료 부족')
    if not mid_ok: reasons.append('중기 15/30분 구조재료 부족')
    if not long_ok: reasons.append('장기 1h이상 구조재료 부족')
    if present < 4: reasons.append('swing/box 핵심선 부족')
    # Quality is now based on material availability, not a single stale official_candle_age.
    if present >= 4 and short_ok and (mid_ok or long_ok):
        kind, quality = 'official_candle_multi_tf_lines', 'official_full'
    elif present >= 2 and (short_ok or mid_ok or long_ok):
        kind, quality = 'official_candle_multi_tf_partial', 'official_partial'
    elif present >= 1:
        kind, quality = 'official_candle_multi_tf_weak', 'official_weak'
    else:
        kind, quality = 'gap_or_synthetic_line', 'missing_official'
    raw_age = _v762_num(official.get('official_candle_age'), row.get('official_candle_age'), default=999999.0)
    return {
        'schema': 'structure_line_source_v769_multi_tf_material',
        'line_source_kind_v762': kind,
        'line_quality_v762': quality,
        'official_present_count_v762': present,
        'official_candle_age': raw_age if raw_age < 999999 else None,
        'support_price_official_v762': _v554_round_price(support) if support else 0.0,
        'resistance_price_official_v762': _v554_round_price(resistance) if resistance else 0.0,
        'raw_levels': vals,
        'timeframe_material_v769': {
            'short_ok': bool(short_ok), 'mid_ok': bool(mid_ok), 'long_ok': bool(long_ok),
            'ages_by_tf': age_by_tf,
            'reason': reasons,
        },
        'weak_reasons_v769': reasons,
        'policy': 'v769 audit/sealing only; legacy trigger/target/invalid values are not changed',
    }


# v769: show official material root status in the basis cache before tuning conditions.
_v769_prev_apply_entry_plan_state = globals().get('_v767_prev_apply_entry_plan_state', _v554_apply_entry_plan_state)


def _v769_material_bucket(row: Dict[str, Any], basis: Dict[str, Any]) -> Tuple[str, List[str]]:
    snap = row.get('canonical_entry_snapshot_v764') if isinstance(row.get('canonical_entry_snapshot_v764'), dict) else row.get('canonical_entry_snapshot_v762') if isinstance(row.get('canonical_entry_snapshot_v762'), dict) else {}
    st = snap.get('structure') if isinstance(snap.get('structure'), dict) else {}
    line = st.get('line_source') if isinstance(st.get('line_source'), dict) else row.get('structure_line_source_v762') if isinstance(row.get('structure_line_source_v762'), dict) else {}
    tm = line.get('timeframe_material_v769') if isinstance(line.get('timeframe_material_v769'), dict) else {}
    parts = []
    if tm.get('short_ok'): parts.append('단기정상')
    else: parts.append('단기부족')
    if tm.get('mid_ok'): parts.append('중기정상')
    else: parts.append('중기부족')
    if tm.get('long_ok'): parts.append('장기정상')
    else: parts.append('장기부족')
    reasons = [str(x) for x in (line.get('weak_reasons_v769') or tm.get('reason') or []) if x]
    return '+'.join(parts), reasons


def _v766_apply_entry_basis(rows: List[Dict[str, Any]], nowv: float) -> List[Dict[str, Any]]:  # type: ignore[override]
    out = [_v764_attach_entry_basis(r) for r in (rows or []) if isinstance(r, dict)]
    try:
        status_counter: Counter = Counter(); warn_counter: Counter = Counter(); issue_counter: Counter = Counter()
        line_counter: Counter = Counter(); orderbook_counter: Counter = Counter(); trade_counter: Counter = Counter(); candle_counter: Counter = Counter()
        line_reason_counter: Counter = Counter(); focus_counter: Counter = Counter(); stage_counter: Counter = Counter()
        material_counter: Counter = Counter(); weak_reason_counter: Counter = Counter(); tf_missing_counter: Counter = Counter()
        complete = 0; samples = []; focus_samples = []
        for r in out:
            basis = r.get('canonical_entry_basis_v764') if isinstance(r.get('canonical_entry_basis_v764'), dict) else {}
            st = basis.get('basis_status') if isinstance(basis.get('basis_status'), dict) else {}
            label = str(st.get('status') or '❔ 정보 없음'); status_counter[label] += 1
            stage = _v766_stage_bucket(r); stage_counter[stage] += 1
            for w in st.get('warnings') if isinstance(st.get('warnings'), list) else []: warn_counter[str(w)] += 1
            for i in st.get('issues') if isinstance(st.get('issues'), list) else []: issue_counter[str(i)] += 1
            sb = basis.get('source_basis') if isinstance(basis.get('source_basis'), dict) else {}
            ages = sb.get('age_sec') if isinstance(sb.get('age_sec'), dict) else {}
            line_q = str(sb.get('structure_line_quality') or 'missing'); line_counter[line_q] += 1
            orderbook_reason = _v766_age_bucket(ages.get('orderbook', 999999.0), '호가')
            trade_reason = _v766_age_bucket(ages.get('trade', 999999.0), '체결')
            # Candle reason from timeframe-aware checker, not a single mixed age.
            ci = sb.get('candle_timeframe_check_v767') if isinstance(sb.get('candle_timeframe_check_v767'), dict) else {}
            if ci.get('status') == 'stale':
                for reason in ci.get('reason') if isinstance(ci.get('reason'), list) else ['캔들 오래됨']:
                    candle_counter[str(reason)] += 1
            elif ci.get('status') == 'missing_ts':
                candle_counter['캔들 timestamp 없음'] += 1
            if '정상' not in orderbook_reason: orderbook_counter[orderbook_reason] += 1
            if '정상' not in trade_reason: trade_counter[trade_reason] += 1
            lr = _v766_line_reason(r, basis)
            if lr not in ('공식선 확실',): line_reason_counter[lr] += 1
            mat_bucket, weak_reasons = _v769_material_bucket(r, basis)
            material_counter[mat_bucket] += 1
            for reason in weak_reasons:
                weak_reason_counter[reason] += 1
                if '단기' in reason: tf_missing_counter['단기 부족'] += 1
                elif '중기' in reason: tf_missing_counter['중기 부족'] += 1
                elif '장기' in reason: tf_missing_counter['장기 부족'] += 1
            if stage in ('S1','S2'):
                if label.startswith('⚠️'): focus_counter[f'{stage} 일부주의'] += 1
                elif label.startswith('✅'): focus_counter[f'{stage} 기준일치'] += 1
                elif label.startswith('❌'): focus_counter[f'{stage} 불일치'] += 1
                else: focus_counter[f'{stage} 정보없음'] += 1
            pb = basis.get('price_basis') if isinstance(basis.get('price_basis'), dict) else {}
            if pb.get('entry_price') and pb.get('trigger_price') and pb.get('target1_price') and pb.get('invalid_price'):
                complete += 1
            if len(samples) < 8 or (stage in ('S1','S2') and len(focus_samples) < 6):
                reason_parts = []
                reason_parts.extend(st.get('issues') if isinstance(st.get('issues'), list) else [])
                reason_parts.extend(st.get('warnings') if isinstance(st.get('warnings'), list) else [])
                reason_parts.extend([x for x in weak_reasons if x not in reason_parts])
                obj = {'ticker': r.get('ticker'), 'grade': stage, 'status': label, 'reason': ' / '.join([str(x) for x in reason_parts if x])[:180], 'line_quality': line_q, 'rr': pb.get('rr_ratio')}
                if len(samples) < 8: samples.append(obj)
                if stage in ('S1','S2') and len(focus_samples) < 6: focus_samples.append(obj)
        save_json(ENTRY_BASIS_CACHE_V764, {
            'schema': 'entry_basis_audit_cache_v769_official_material_spine',
            'version': VERSION, 'build': BUILD_LABEL, 'updated_ts': nowv, 'updated_text': now_text(nowv),
            'row_count': len(out), 'basis_complete_rows': complete,
            'status_counts': dict(status_counter), 'warning_reason_counts': dict(warn_counter), 'issue_reason_counts': dict(issue_counter),
            'line_quality_counts': dict(line_counter), 'orderbook_detail_counts': dict(orderbook_counter), 'trade_detail_counts': dict(trade_counter), 'candle_detail_counts': dict(candle_counter),
            'line_detail_counts': dict(line_reason_counter), 'focus_status_counts': dict(focus_counter), 'stage_counts': dict(stage_counter),
            'official_material_counts_v769': dict(material_counter), 'weak_reason_counts_v769': dict(weak_reason_counter), 'timeframe_missing_counts_v769': dict(tf_missing_counter),
            'sample': samples, 'focus_sample': focus_samples,
            'policy': 'v769 official candle material root diagnostics; no threshold/exit change',
        })
    except Exception as exc:
        try: append_error(ERROR, 'v769_entry_basis_material_cache', exc)
        except Exception: pass
    return out


def _v554_apply_entry_plan_state(rows: List[Dict[str, Any]], nowv: float) -> List[Dict[str, Any]]:  # type: ignore[override]
    rows2 = _v769_prev_apply_entry_plan_state(rows, nowv)
    return _v766_apply_entry_basis(rows2, nowv)


# =============================================================================
# strategy_worker v0.771: official material fields must survive candidate row creation
# Root cause found in v769: candle overlay produced tf_present/age/material fields,
# but _v510_base_lane only copied V597_OFFICIAL_STRUCTURE_KEYS, so v769 material was
# dropped before structure_snapshot/basis audit. This patch extends the canonical
# preservation key-list and official input reader. No thresholds/exits are changed.
# =============================================================================
BUILD_LABEL = "v789_s2_to_s1_post_route_rejudge_2026-06-09"
MAIN_DEPLOY_VERSION = "v2.13.783"
MAIN_BOT_VERSION = "수익형 v2.13.787"
VERSION = "strategy_worker_v0.789"

_V770_MATERIAL_KEYS = (
    'tf_present_by_group_v769','tf_present_counts_v769','tf_age_sec_v769',
    'short_tf_count_v769','mid_tf_count_v769','long_tf_count_v769',
    'official_structure_formula_v769',
    'candle_1m_age_sec','1m_candle_age_sec','candle_3m_age_sec','3m_candle_age_sec','candle_5m_age_sec','5m_candle_age_sec',
    'candle_15m_age_sec','15m_candle_age_sec','candle_30m_age_sec','30m_candle_age_sec',
    'candle_1h_age_sec','1h_candle_age_sec','candle_2h_age_sec','2h_candle_age_sec','candle_4h_age_sec','4h_candle_age_sec',
    '1m_swing_high_price','1m_swing_low_price','1m_box_high_price','1m_box_low_price','1m_recent_high_price','1m_recent_low_price',
    '3m_swing_high_price','3m_swing_low_price','3m_box_high_price','3m_box_low_price','3m_recent_high_price','3m_recent_low_price',
    '5m_swing_high_price','5m_swing_low_price','5m_box_high_price','5m_box_low_price','5m_recent_high_price','5m_recent_low_price',
    '15m_swing_high_price','15m_swing_low_price','15m_box_high_price','15m_box_low_price','15m_recent_high_price','15m_recent_low_price',
    '30m_swing_high_price','30m_swing_low_price','30m_box_high_price','30m_box_low_price','30m_recent_high_price','30m_recent_low_price',
    '1h_swing_high_price','1h_swing_low_price','1h_box_high_price','1h_box_low_price','1h_recent_high_price','1h_recent_low_price',
    '2h_swing_high_price','2h_swing_low_price','2h_box_high_price','2h_box_low_price','2h_recent_high_price','2h_recent_low_price',
    '4h_swing_high_price','4h_swing_low_price','4h_box_high_price','4h_box_low_price','4h_recent_high_price','4h_recent_low_price',
)
try:
    V597_OFFICIAL_STRUCTURE_KEYS = tuple(dict.fromkeys(list(V597_OFFICIAL_STRUCTURE_KEYS) + list(_V770_MATERIAL_KEYS)))  # type: ignore[assignment]
except Exception:
    pass

_v770_prev_official_structure_inputs = _v596_official_structure_inputs

def _v596_official_structure_inputs(row: Dict[str, Any]) -> Dict[str, Any]:  # type: ignore[override]
    out = _v770_prev_official_structure_inputs(row)
    if not isinstance(out, dict):
        out = {}
    for k in _V770_MATERIAL_KEYS:
        if isinstance(row, dict) and row.get(k) not in (None, '', [], {}):
            out[k] = row.get(k)
    # If the candidate row preserved the raw pack, merge material fields from there too.
    raw = row.get('official_structure_inputs_raw') if isinstance(row.get('official_structure_inputs_raw'), dict) else {}
    for k in _V770_MATERIAL_KEYS:
        if raw.get(k) not in (None, '', [], {}) and out.get(k) in (None, '', [], {}):
            out[k] = raw.get(k)
    groups = out.get('tf_present_by_group_v769') if isinstance(out.get('tf_present_by_group_v769'), dict) else {}
    if groups:
        out['short_tf_count_v769'] = int(out.get('short_tf_count_v769') or len(groups.get('short') or []))
        out['mid_tf_count_v769'] = int(out.get('mid_tf_count_v769') or len(groups.get('mid') or []))
        out['long_tf_count_v769'] = int(out.get('long_tf_count_v769') or len(groups.get('long') or []))
    out['source_policy'] = 'v770: official multi-timeframe material preserved from candle overlay into canonical row; no threshold change'
    return out

# Improve v770 audit labels: when material was unavailable because no S1/OPEN has occurred yet,
# keep it diagnostic-only. The existing scoring/grade logic is unchanged.

def _v770_material_debug_row(row: Dict[str, Any]) -> Dict[str, Any]:
    official = _v596_official_structure_inputs(row)
    return {
        'schema': 'official_material_debug_v770',
        'short_count': int(official.get('short_tf_count_v769') or 0),
        'mid_count': int(official.get('mid_tf_count_v769') or 0),
        'long_count': int(official.get('long_tf_count_v769') or 0),
        'intervals': official.get('official_candle_intervals') or '',
        'age_by_tf': official.get('tf_age_sec_v769') or {},
    }



# =============================================================================
# strategy_worker v0.771: official-material sample markers
# - Adds explicit sample reason tags into the existing basis cache path without
#   changing scoring/grade thresholds. Main v771 reads these for root-cause view.
# =============================================================================
BUILD_LABEL = "v789_s2_to_s1_post_route_rejudge_2026-06-09"
MAIN_DEPLOY_VERSION = "v2.13.783"
MAIN_BOT_VERSION = "수익형 v2.13.787"
VERSION = "strategy_worker_v0.789"

# No extra runtime override here: v770 material-preserve path is the active root fix.
# v771 analysis is intentionally main/paper diagnostic so strategy stays light.

# =============================================================================
# strategy_worker v0.772: chart-line reaction state spine
# - Root direction: structure lines are not enough; seal how price reacted to
#   support/resistance/VWAP/EMA lines. Observation only, no thresholds changed.
# =============================================================================
BUILD_LABEL = "v789_s2_to_s1_post_route_rejudge_2026-06-09"
MAIN_DEPLOY_VERSION = "v2.13.783"
MAIN_BOT_VERSION = "수익형 v2.13.787"
VERSION = "strategy_worker_v0.789"


def _v772_pct_dist(price: float, line: float) -> float:
    try:
        if price and line:
            return (price - line) / line * 100.0
    except Exception:
        pass
    return 999999.0


def _v772_chart_reaction_state(row: Dict[str, Any], snap: Dict[str, Any], line: Dict[str, Any]) -> Dict[str, Any]:
    """Classify how price is behaving around already-produced chart lines.
    This is a sealed observation for review/classify only; it does not change S1/S2/S3.
    """
    row = row if isinstance(row, dict) else {}
    snap = snap if isinstance(snap, dict) else {}
    line = line if isinstance(line, dict) else {}
    official = snap.get('official_structure_inputs_raw') if isinstance(snap.get('official_structure_inputs_raw'), dict) else _v762_existing_official_pack(row)
    price = _v762_num(row.get('current_price'), row.get('entry_price'), row.get('price'), snap.get('entry_price'), default=0.0)
    support = _v762_num(line.get('support_price_official_v762'), default=0.0)
    resistance = _v762_num(line.get('resistance_price_official_v762'), default=0.0)
    vwap_gap = _v762_num(row.get('vwap_gap_pct'), official.get('vwap_gap_pct'), default=0.0)
    ema_gap = _v762_num(row.get('ema5_gap_pct'), official.get('ema5_gap_pct'), default=0.0)
    reaction = _v762_num(row.get('price_reaction_pct'), row.get('change_1m_pct'), default=0.0)
    buy_ratio = _v762_num(row.get('buy_ratio'), default=0.0)
    buy_sustain = _v762_num(row.get('buy_sustain_1m'), row.get('buy_sustain'), default=0.0)
    upper_wick = _v762_num(official.get('upper_wick_pct'), row.get('upper_wick_pct'), default=0.0)
    lower_wick = _v762_num(official.get('lower_wick_pct'), row.get('lower_wick_pct'), default=0.0)
    support_dist = _v772_pct_dist(price, support)
    resistance_dist = _v772_pct_dist(price, resistance)
    tags: List[str] = []
    good: List[str] = []
    risk: List[str] = []
    wait: List[str] = []

    # Support/reclaim behavior
    if support and price:
        if -0.35 <= support_dist <= 0.80:
            tags.append('지지선 근처')
            if reaction >= 0.15 or buy_ratio >= 0.72 or buy_sustain >= 0.72 or lower_wick >= 0.40:
                good.append('지지선 터치 후 반등')
            else:
                wait.append('지지선 근처 반응 대기')
        elif support_dist < -0.35:
            risk.append('지지선 이탈')
        elif support_dist > 0.80:
            good.append('지지선 위에서 유지')

    # Resistance/breakout behavior
    if resistance and price:
        if -0.35 <= resistance_dist <= 0.25:
            tags.append('저항선 근처')
            if upper_wick >= 0.55 and reaction <= 0.10:
                risk.append('저항 터치 후 밀림')
            else:
                wait.append('저항 돌파 확인 대기')
        elif resistance_dist > 0.25:
            if reaction >= 0.20 or buy_ratio >= 0.72 or buy_sustain >= 0.72:
                good.append('저항 돌파 후 유지')
            else:
                wait.append('저항 위 돌파 확인 대기')
        elif -1.50 <= resistance_dist < -0.35:
            wait.append('저항 바로 아래 추격 주의')

    # Box/sweep/retest hints already provided by official candle factory if present.
    if bool(official.get('box_breakout_hint')):
        good.append('박스 상단 돌파')
    if bool(official.get('box_break_fail_hint')) or bool(official.get('false_breakout_hint')):
        risk.append('가짜 돌파 위험')
    if bool(official.get('support_reclaim_hint')) or bool(official.get('sweep_reclaim_hint')):
        good.append('저점 쓸림 후 회복')
    if bool(official.get('resistance_reject_hint')):
        risk.append('저항선에서 윗꼬리 밀림')
    if bool(official.get('retest_success_hint')):
        good.append('돌파 후 재테스트 성공')
    if bool(official.get('retest_wait_hint')):
        wait.append('돌파 후 재테스트 대기')

    # VWAP / EMA behavior
    if vwap_gap >= 0 and ema_gap >= 0:
        good.append('VWAP·EMA 위 유지')
    elif vwap_gap >= 0 > ema_gap:
        wait.append('VWAP 위지만 EMA 확인 필요')
    elif vwap_gap < 0 <= ema_gap:
        wait.append('EMA는 지키지만 VWAP 회복 대기')
    else:
        risk.append('VWAP·EMA 아래 구조')

    # Flow confirmation around lines
    if (buy_ratio >= 0.75 or buy_sustain >= 0.75) and reaction >= 0.15:
        good.append('선 반응 후 매수세 확인')
    elif reaction >= 0.20 and buy_ratio < 0.65:
        wait.append('가격은 반응했지만 체결 확인 필요')

    good = _v510_uniq(good, 12)
    risk = _v510_uniq(risk, 12)
    wait = _v510_uniq(wait, 12)
    tags = _v510_uniq(tags + good + risk + wait, 24)
    if risk and not good:
        side = 'risk'
    elif good and not risk:
        side = 'good'
    elif good and risk:
        side = 'mixed'
    elif wait:
        side = 'wait'
    else:
        side = 'neutral'
    return {
        'schema': 'chart_line_reaction_state_v772',
        'side': side,
        'tags': tags,
        'good': good,
        'risk': risk,
        'wait': wait,
        'support_distance_pct': round(support_dist, 4) if support_dist != 999999.0 else None,
        'resistance_distance_pct': round(resistance_dist, 4) if resistance_dist != 999999.0 else None,
        'basis': {
            'support': support, 'resistance': resistance, 'price': price,
            'reaction_1m_pct': reaction, 'buy_ratio': buy_ratio, 'buy_sustain': buy_sustain,
            'vwap_gap_pct': vwap_gap, 'ema5_gap_pct': ema_gap,
        },
        'policy': 'observation only; no condition/exit/grade threshold change in v772',
    }


_v772_prev_attach_structure_snapshot = _v762_attach_structure_snapshot

def _v762_attach_structure_snapshot(row: Dict[str, Any], nowv: float) -> Dict[str, Any]:  # type: ignore[override]
    r = _v772_prev_attach_structure_snapshot(row, nowv)
    try:
        snap = r.get('canonical_entry_snapshot_v762') if isinstance(r.get('canonical_entry_snapshot_v762'), dict) else r.get('canonical_entry_snapshot') if isinstance(r.get('canonical_entry_snapshot'), dict) else {}
        line = r.get('structure_line_source_v762') if isinstance(r.get('structure_line_source_v762'), dict) else snap.get('structure_line_source_v762') if isinstance(snap.get('structure_line_source_v762'), dict) else {}
        reaction = _v772_chart_reaction_state(r, snap, line)
        snap2 = dict(snap) if isinstance(snap, dict) else {}
        snap2['chart_line_reaction_v772'] = reaction
        snap2['chart_state_tags_v772'] = reaction.get('tags') or []
        # Keep the existing snapshot keys; paper already copies these.
        r['canonical_entry_snapshot_v762'] = snap2
        r['canonical_entry_snapshot'] = snap2
        r['structure_snapshot_v762'] = snap2
        r['chart_line_reaction_v772'] = reaction
        r['chart_state_tags_v772'] = reaction.get('tags') or []
        ctx = r.get('entry_context') if isinstance(r.get('entry_context'), dict) else {}
        ctx = dict(ctx)
        ctx['chart_line_reaction_v772'] = reaction
        ctx['chart_state_tags_v772'] = reaction.get('tags') or []
        ctx['canonical_entry_snapshot_v762'] = snap2
        r['entry_context'] = ctx
    except Exception as exc:
        try: append_error(ERROR, 'v772_chart_line_reaction_attach', exc)
        except Exception: pass
    return r


_v772_prev_apply_structure_snapshot = _v762_apply_structure_snapshot

def _v762_apply_structure_snapshot(rows: List[Dict[str, Any]], nowv: float) -> List[Dict[str, Any]]:  # type: ignore[override]
    out = _v772_prev_apply_structure_snapshot(rows, nowv)
    try:
        side_counter: Counter = Counter()
        tag_counter: Counter = Counter()
        sample: List[Dict[str, Any]] = []
        for r in out or []:
            react = r.get('chart_line_reaction_v772') if isinstance(r.get('chart_line_reaction_v772'), dict) else {}
            side_counter[str(react.get('side') or 'unknown')] += 1
            for t in react.get('tags') if isinstance(react.get('tags'), list) else []:
                tag_counter[str(t)] += 1
            if len(sample) < 8:
                sample.append({'ticker': r.get('ticker'), 'stage': _v510_stage(r), 'side': react.get('side'), 'tags': (react.get('tags') or [])[:4]})
        # Merge into structure snapshot cache instead of replacing other v770 fields.
        try:
            cache = load_json(STRUCTURE_SNAPSHOT_CACHE, {}) if 'load_json' in globals() else {}
        except Exception:
            cache = {}
        if not isinstance(cache, dict): cache = {}
        cache.update({
            'chart_reaction_schema_v772': 'chart_line_reaction_state_v772',
            'chart_reaction_side_counts_v772': dict(side_counter),
            'chart_reaction_tag_counts_v772': dict(tag_counter),
            'chart_reaction_sample_v772': sample,
            'chart_reaction_policy_v772': 'observation only; no entry/exit threshold change',
        })
        save_json(STRUCTURE_SNAPSHOT_CACHE, cache)
    except Exception as exc:
        try: append_error(ERROR, 'v772_chart_reaction_cache', exc)
        except Exception: pass
    return out


# =============================================================================
# strategy_worker v0.773: structure-first routing advisory spine
# - Uses chart-line reaction as first-layer decision material.
# - Does not change S1/S2/S3 thresholds or paper OPEN gate in this version.
# - Seals a simple route so main/paper can verify: S1-ready / S2 recheck / risk-block / observe.
# =============================================================================
BUILD_LABEL = "v789_s2_to_s1_post_route_rejudge_2026-06-09"
MAIN_DEPLOY_VERSION = "v2.13.783"
MAIN_BOT_VERSION = "수익형 v2.13.787"
VERSION = "strategy_worker_v0.789"


def _v773_structure_route(row: Dict[str, Any]) -> Dict[str, Any]:
    r = row if isinstance(row, dict) else {}
    react = r.get('chart_line_reaction_v772') if isinstance(r.get('chart_line_reaction_v772'), dict) else {}
    tags = [str(x) for x in (react.get('tags') if isinstance(react.get('tags'), list) else [])]
    good = [str(x) for x in (react.get('good') if isinstance(react.get('good'), list) else [])]
    risk = [str(x) for x in (react.get('risk') if isinstance(react.get('risk'), list) else [])]
    wait = [str(x) for x in (react.get('wait') if isinstance(react.get('wait'), list) else [])]
    side = str(react.get('side') or 'unknown')
    stage = _v510_stage(r) if '_v510_stage' in globals() else str(r.get('stage') or r.get('grade') or '')
    confirm_lack = []
    try:
        if _v762_num(r.get('price_reaction_pct'), r.get('change_1m_pct'), default=0.0) < 0.35:
            confirm_lack.append('가격반응 확인 대기')
        if _v762_num(r.get('buy_ratio'), default=0.0) < 0.70:
            confirm_lack.append('매수체결 확인 대기')
        if _v762_num(r.get('buy_sustain_1m'), r.get('buy_sustain'), default=0.0) < 0.70:
            confirm_lack.append('1분지속 확인 대기')
    except Exception:
        pass
    danger_words = ('저항 바로 아래 추격 주의','저항 터치 후 밀림','저항선에서 윗꼬리 밀림','지지선 이탈','VWAP·EMA 아래 구조','가짜 돌파 위험')
    strong_words = ('지지선 터치 후 반등','지지선 위에서 유지','VWAP·EMA 위 유지','박스 상단 돌파','저점 쓸림 후 회복','돌파 후 재테스트 성공','선 반응 후 매수세 확인')
    wait_words = ('저항 돌파 확인 대기','돌파 후 재테스트 대기','가격은 반응했지만 체결 확인 필요','지지선 근처 반응 대기','EMA는 지키지만 VWAP 회복 대기','저항선 근처')
    has_danger = any(any(w in t for w in danger_words) for t in (risk + tags))
    has_strong = any(any(w in t for w in strong_words) for t in (good + tags))
    has_wait = any(any(w in t for w in wait_words) for t in (wait + tags))
    if has_danger:
        route = '❌ 위험 구조: S1 금지/보류'
        simple = '위험 구조라 바로 진입 금지'
        reasons = _v510_uniq(risk[:6] + [t for t in tags if any(w in t for w in danger_words)][:4], 8)
    elif has_strong and not confirm_lack and side in ('good','mixed'):
        route = '✅ 구조 양호: S1 가능'
        simple = '구조 좋고 확인값 양호'
        reasons = _v510_uniq(good[:6], 8)
    elif has_strong or has_wait or confirm_lack:
        route = '⚠️ 구조 재확인: S2로 살림'
        simple = '구조는 볼 만하지만 확인 더 필요'
        reasons = _v510_uniq((good[:4] + wait[:4] + confirm_lack[:4]), 8)
    else:
        route = '👀 관찰 구조: S3/복기'
        simple = '뚜렷한 구조 반응 부족'
        reasons = _v510_uniq((wait[:4] + tags[:4]), 8)
    return {
        'schema': 'structure_first_route_v773',
        'route': route,
        'simple': simple,
        'reasons': reasons,
        'chart_side': side,
        'current_stage': stage,
        'confirm_lack': confirm_lack,
        'policy': 'structure-first routing advice sealed for S1/S2 review; no threshold/exit/BUY_READY change in v773',
    }


_v773_prev_apply_structure_snapshot = _v762_apply_structure_snapshot

def _v762_apply_structure_snapshot(rows: List[Dict[str, Any]], nowv: float) -> List[Dict[str, Any]]:  # type: ignore[override]
    out = _v773_prev_apply_structure_snapshot(rows, nowv)
    try:
        route_counter: Counter = Counter()
        stage_counter: Counter = Counter()
        sample: List[Dict[str, Any]] = []
        for r in out or []:
            if not isinstance(r, dict):
                continue
            route = _v773_structure_route(r)
            r['structure_first_route_v773'] = route
            ctx = r.get('entry_context') if isinstance(r.get('entry_context'), dict) else {}
            ctx = dict(ctx); ctx['structure_first_route_v773'] = route; r['entry_context'] = ctx
            snap = r.get('canonical_entry_snapshot') if isinstance(r.get('canonical_entry_snapshot'), dict) else r.get('canonical_entry_snapshot_v762') if isinstance(r.get('canonical_entry_snapshot_v762'), dict) else {}
            if isinstance(snap, dict):
                snap2 = dict(snap); snap2['structure_first_route_v773'] = route
                r['canonical_entry_snapshot'] = snap2; r['canonical_entry_snapshot_v762'] = snap2; r['structure_snapshot_v762'] = snap2
            route_counter[str(route.get('route') or '-')] += 1
            st = str(route.get('current_stage') or '-')
            stage_counter[f"{st} / {route.get('route')}"] += 1
            if len(sample) < 8 or st in ('S1','S2'):
                sample.append({'ticker': r.get('ticker'), 'stage': st, 'route': route.get('route'), 'why': (route.get('reasons') or [])[:3]})
        try:
            cache = load_json(STRUCTURE_SNAPSHOT_CACHE, {}) if 'load_json' in globals() else {}
        except Exception:
            cache = {}
        if not isinstance(cache, dict): cache = {}
        cache.update({
            'structure_first_route_schema_v773': 'structure_first_route_v773',
            'structure_first_route_counts_v773': dict(route_counter),
            'structure_first_route_stage_counts_v773': dict(stage_counter),
            'structure_first_route_sample_v773': sample[:12],
            'structure_first_route_policy_v773': 'advisory/verification; no entry threshold changed',
        })
        save_json(STRUCTURE_SNAPSHOT_CACHE, cache)
    except Exception as exc:
        try: append_error(ERROR, 'v773_structure_first_route_cache', exc)
        except Exception: pass
    return out



# =============================================================================
# strategy_worker v0.775: structure-first routing is now applied before paper handoff
# - Root connection point: after v732 promotion reseal, before S1 hold cache writer.
# - Also keeps a structure-observation priority queue for target_router/worker refresh.
# - No exit rule, BUY_READY, auto-buy, or paper ledger deletion changes.
# =============================================================================
BUILD_LABEL = "v789_s2_to_s1_post_route_rejudge_2026-06-09"
MAIN_DEPLOY_VERSION = "v2.13.783"
MAIN_BOT_VERSION = "수익형 v2.13.787"
VERSION = "strategy_worker_v0.789"
STRUCTURE_OBSERVATION_QUEUE_V774 = BASE_DIR / "clean_structure_observation_queue_v774.json"


def _v774_get_structure_route(row: Dict[str, Any]) -> Dict[str, Any]:
    if not isinstance(row, dict):
        return {}
    sources = [row]
    for k in ('entry_context','canonical_entry_snapshot','canonical_entry_snapshot_v762','structure_snapshot_v762'):
        v = row.get(k)
        if isinstance(v, dict):
            sources.append(v)
    for src in sources:
        v = src.get('structure_first_route_v773') or src.get('structure_first_route_v774')
        if isinstance(v, dict) and v:
            return v
    return _v773_structure_route(row) if '_v773_structure_route' in globals() else {}


def _v774_route_kind(route: Dict[str, Any]) -> str:
    txt = str((route or {}).get('route') or '')
    if '위험' in txt or '금지' in txt:
        return 'risk_block'
    if '양호' in txt or 'S1 가능' in txt:
        return 's1_possible'
    if '재확인' in txt or 'S2' in txt:
        return 's2_recheck'
    return 'observe'


def _v774_confirm_pass(row: Dict[str, Any]) -> bool:
    try:
        react = _v762_num(row.get('price_reaction_pct'), row.get('change_1m_pct'), row.get('price_chg_60s'), default=0.0)
        buy = _v762_num(row.get('buy_ratio'), default=0.0)
        sustain = _v762_num(row.get('buy_sustain_1m'), row.get('buy_sustain'), row.get('buy_sustain_20s'), default=0.0)
        spread = _v762_num(row.get('spread_pct'), default=99.0)
        slip = _v762_num(row.get('slippage_pct'), row.get('spread_pct'), default=spread)
        stale = bool(row.get('stale_reasons'))
        trigger = _v732_trigger_state_for_hold(row) if '_v732_trigger_state_for_hold' in globals() else {'trigger_reached': True}
        return bool((react >= 0.30 or (react >= 0.22 and buy >= 0.78)) and buy >= 0.65 and sustain >= 0.58 and spread <= 0.35 and slip <= 0.35 and not stale and bool(trigger.get('trigger_reached', True)))
    except Exception:
        return False


def _v774_set_stage(row: Dict[str, Any], stage: str, reason: str, open_allowed: bool = False) -> None:
    for k in ('s_stage','candidate_stage','candidate_grade','stage','grade'):
        row[k] = stage
    row['open_eligible'] = bool(open_allowed and stage == 'S1')
    row['paper_bot_open'] = bool(open_allowed and stage == 'S1')
    row['trade_ready'] = bool(open_allowed and stage == 'S1')
    prev = row.get('s_stage_reasons') if isinstance(row.get('s_stage_reasons'), list) else []
    row['s_stage_reasons'] = _v510_uniq([reason] + [str(x) for x in prev], 12)
    br = row.get('block_reasons') if isinstance(row.get('block_reasons'), list) else []
    if not open_allowed:
        row['block_reasons'] = _v510_uniq([reason] + [str(x) for x in br], 14)
    ctx = row.get('entry_context') if isinstance(row.get('entry_context'), dict) else {}
    ctx = dict(ctx)
    ctx.update({'structure_route_stage_v774': stage, 'structure_route_reason_v774': reason, 'open_eligible': row.get('open_eligible')})
    row['entry_context'] = ctx


def _v774_apply_structure_routing(rows: List[Dict[str, Any]], nowv: float) -> Tuple[List[Dict[str, Any]], Dict[str, Any]]:
    out: List[Dict[str, Any]] = []
    before = Counter(); after = Counter(); applied = Counter(); samples: List[Dict[str, Any]] = []
    risk_s1_blocked = good_to_s1 = good_to_s2 = s3_to_s2 = risk_to_s3 = observe_kept = 0
    for src in rows or []:
        if not isinstance(src, dict):
            continue
        r = dict(src)
        before_stage = _v510_stage(r)
        before[before_stage] += 1
        route = _v774_get_structure_route(r)
        kind = _v774_route_kind(route)
        confirm_ok = _v774_confirm_pass(r)
        reason_list = route.get('reasons') if isinstance(route.get('reasons'), list) else []
        reason_text = ' / '.join(str(x) for x in reason_list[:3]) or str(route.get('simple') or route.get('route') or '구조 우선 판단')
        final_stage = before_stage
        action = 'kept'
        # Risk first: risky structure must not become S1/open.
        if kind == 'risk_block':
            if before_stage == 'S1':
                final_stage = 'S2'
                _v774_set_stage(r, 'S2', '구조 위험: S1 금지, S2 보류', False)
                risk_s1_blocked += 1; action = 'risk_s1_to_s2_hold'
            elif before_stage == 'S2':
                final_stage = 'S3'
                _v774_set_stage(r, 'S3', '구조 위험: S2 재확인 제외, 관찰로 전환', False)
                risk_to_s3 += 1; action = 'risk_s2_to_s3'
            else:
                final_stage = 'S3'
                _v774_set_stage(r, 'S3', '구조 위험: S3 관찰', False)
                risk_to_s3 += 1; action = 'risk_observe'
        elif kind == 's1_possible':
            if before_stage in ('S1','S2') and confirm_ok:
                final_stage = 'S1'
                _v774_set_stage(r, 'S1', '구조 양호 + 확인값 통과: S1 가능', True)
                good_to_s1 += 1; action = 'structure_good_to_s1'
            elif before_stage == 'S3':
                final_stage = 'S2'
                _v774_set_stage(r, 'S2', '구조 양호: S2 재확인으로 살림', False)
                s3_to_s2 += 1; good_to_s2 += 1; action = 'structure_good_s3_to_s2'
            else:
                final_stage = 'S2'
                _v774_set_stage(r, 'S2', '구조 양호하지만 확인값 재확인', False)
                good_to_s2 += 1; action = 'structure_good_recheck'
        elif kind == 's2_recheck':
            if before_stage == 'S3':
                final_stage = 'S2'
                _v774_set_stage(r, 'S2', '구조는 볼 만함: S2 재확인', False)
                s3_to_s2 += 1; action = 'structure_recheck_s3_to_s2'
            elif before_stage == 'S1' and not confirm_ok:
                final_stage = 'S2'
                _v774_set_stage(r, 'S2', '구조는 좋지만 확인값 부족: S2 재확인', False)
                action = 's1_to_s2_recheck'
            else:
                final_stage = before_stage if before_stage in ('S1','S2') else 'S3'
                if final_stage == 'S2':
                    _v774_set_stage(r, 'S2', '구조 재확인 유지', False)
                action = 'recheck_keep'
        else:
            observe_kept += 1
            if before_stage == 'S1':
                final_stage = 'S2'
                _v774_set_stage(r, 'S2', '구조 반응 확인 대기: S1 보류', False)
                action = 's1_to_s2_observe'
            elif before_stage not in ('S1','S2','S3'):
                final_stage = 'S3'
                _v774_set_stage(r, 'S3', '관찰 구조', False)
                action = 'observe_to_s3'
        strict_detail = _v779_s3_recheck_detail(r, route) if before_stage == 'S3' else {}
        r['structure_route_applied_v774'] = {
            'schema': 'structure_route_applied_v774',
            'before_stage': before_stage,
            'after_stage': _v510_stage(r),
            'route_kind': kind,
            'action': action,
            'confirm_pass': bool(confirm_ok),
            'route': route.get('route') if isinstance(route, dict) else None,
            'reasons': reason_list[:6],
            'updated_ts': nowv,
            'policy': 'structure-first final routing before paper S1 hold; exits/BUY_READY/autobuy unchanged',
        }
        ctx = r.get('entry_context') if isinstance(r.get('entry_context'), dict) else {}
        ctx = dict(ctx); ctx['structure_route_applied_v774'] = r['structure_route_applied_v774']; r['entry_context'] = ctx
        snap = r.get('canonical_entry_snapshot') if isinstance(r.get('canonical_entry_snapshot'), dict) else r.get('canonical_entry_snapshot_v762') if isinstance(r.get('canonical_entry_snapshot_v762'), dict) else {}
        if isinstance(snap, dict):
            snap2 = dict(snap); snap2['structure_route_applied_v774'] = r['structure_route_applied_v774']; snap2['structure_first_route_v774'] = route
            r['canonical_entry_snapshot'] = snap2; r['canonical_entry_snapshot_v762'] = snap2; r['structure_snapshot_v762'] = snap2
        after[_v510_stage(r)] += 1; applied[action] += 1
        if len(samples) < 12 or _v510_stage(r) in ('S1','S2'):
            samples.append({'ticker': r.get('ticker'), 'before': before_stage, 'after': _v510_stage(r), 'action': action, 'route': route.get('route') if isinstance(route, dict) else '-', 'why': reason_text, 'strict_detail': strict_detail if isinstance(strict_detail, dict) else {}})
        out.append(r)
    summary = {
        'schema': 'structure_route_apply_summary_v774', 'version': VERSION, 'updated_ts': nowv, 'updated_text': now_text(nowv),
        'before_stage_counts': dict(before), 'after_stage_counts': dict(after), 'action_counts': dict(applied),
        'risk_s1_blocked': risk_s1_blocked, 'risk_to_s3': risk_to_s3, 'structure_good_to_s1': good_to_s1, 'structure_good_to_s2': good_to_s2, 's3_to_s2': s3_to_s2, 'observe_kept': observe_kept,
        'sample': samples[:16],
        'policy': '구조 좋음은 S1/S2로 살리고, 위험 구조는 S1에서 차단. 청산/자동매수/BUY_READY 변경 없음.',
    }
    try:
        cache = load_json(STRUCTURE_SNAPSHOT_CACHE, {}) or {}
        if not isinstance(cache, dict): cache = {}
        cache['structure_route_apply_summary_v774'] = summary
        cache['structure_route_apply_counts_v774'] = dict(applied)
        cache['structure_route_apply_sample_v774'] = samples[:12]
        save_json(STRUCTURE_SNAPSHOT_CACHE, cache)
    except Exception as exc:
        try: append_error(ERROR, 'v774_structure_route_cache', exc)
        except Exception: pass
    return out, summary


_v774_prev_reseal_common = _v732_reseal_common_uprising_promotions

def _v732_reseal_common_uprising_promotions(rows: List[Dict[str, Any]], nowv: float) -> Tuple[List[Dict[str, Any]], Dict[str, Any]]:  # type: ignore[override]
    resealed, summary = _v774_prev_reseal_common(rows, nowv)
    try:
        routed, rsum = _v774_apply_structure_routing(resealed, nowv)
        if isinstance(summary, dict):
            summary = dict(summary)
            summary['structure_route_apply_summary_v774'] = rsum
        return routed, summary
    except Exception as exc:
        try: append_error(ERROR, 'v774_reseal_structure_route_apply', exc)
        except Exception: pass
        return resealed, summary


def _v774_priority_bucket(row: Dict[str, Any]) -> Tuple[str, int, int, List[str]]:
    stage = _v510_stage(row)
    route = _v774_get_structure_route(row)
    kind = _v774_route_kind(route)
    if stage == 'S1' or bool(row.get('open_eligible')):
        return 'structure_core_open_s1', 990, 45, ['OPEN/S1/S1 hold 최우선 구조 갱신']
    if stage == 'S2' or kind in ('s1_possible','s2_recheck'):
        return 'structure_recheck_s2', 900, 90, ['S2/재확인 구조 자주 갱신']
    if stage == 'S3' and kind == 's1_possible':
        return 'structure_good_s3_watch', 800, 180, ['구조 좋은 S3 중간 갱신']
    if stage == 'S3' and kind == 's2_recheck':
        return 'structure_recheck_s3_watch', 760, 240, ['재확인 가치 있는 S3 순환 갱신']
    return 'structure_coverage_slow', 520, 420, ['coverage 느린 순환']


def _v774_publish_observation_queue(rows: List[Dict[str, Any]], nowv: float) -> Dict[str, Any]:
    buckets = Counter(); samples=[]; q=[]
    for r in rows or []:
        if not isinstance(r, dict): continue
        t = ticker_norm(r.get('ticker') or r.get('market') or r.get('symbol'))
        if not t: continue
        bucket, prio, target_age, reason = _v774_priority_bucket(r)
        buckets[bucket] += 1
        item={'ticker':t, 'bucket':bucket, 'priority':prio, 'required_age_sec':target_age, 'stage':_v510_stage(r), 'route':(_v774_get_structure_route(r).get('route') if isinstance(_v774_get_structure_route(r), dict) else '-'), 'reasons':reason, 'source':'strategy_structure_observation_v774'}
        q.append(item)
        if len(samples)<12: samples.append(item)
    obj={'schema':'structure_observation_queue_v774','version':VERSION,'updated_ts':nowv,'updated_text':now_text(nowv),'count':len(q),'buckets':dict(buckets),'rows':sorted(q,key=lambda x:int(x.get('priority') or 0),reverse=True),'sample':samples,'policy':'No fixed candidate cap; priority/TTL/time-budget observation queue for structure refresh.'}
    try: save_json(STRUCTURE_OBSERVATION_QUEUE_V774, obj)
    except Exception as exc:
        try: append_error(ERROR, 'v774_observation_queue_save', exc)
        except Exception: pass
    return obj


_v774_prev_fresh_urgent = _v574_attach_s2_fresh_urgent_requests

def _v574_attach_s2_fresh_urgent_requests(rows: List[Dict[str, Any]], priority_requests: List[Dict[str, Any]], nowv: float) -> Tuple[List[Dict[str, Any]], Dict[str, Any]]:  # type: ignore[override]
    pr, summary = _v774_prev_fresh_urgent(rows, priority_requests, nowv)
    try:
        qobj = _v774_publish_observation_queue(rows, nowv)
        seen = {ticker_norm(x.get('ticker')) for x in (pr or []) if isinstance(x, dict)}
        added = 0
        for item in qobj.get('rows') or []:
            if not isinstance(item, dict): continue
            t = ticker_norm(item.get('ticker'))
            if not t or t in seen: continue
            # Keep coverage in queue cache, but only push recheck/core/good-structure rows into router priority requests.
            if str(item.get('bucket')) == 'structure_coverage_slow':
                continue
            pr.append({'ticker':t,'priority':int(item.get('priority') or 0),'bucket':item.get('bucket'),'reason':item.get('reasons') or ['구조 관찰 큐'],'source':'structure_observation_queue_v774','required_age_sec':item.get('required_age_sec')})
            seen.add(t); added += 1
        if isinstance(summary, dict):
            summary = dict(summary)
            summary['structure_observation_queue_v774'] = {'count':qobj.get('count'), 'buckets':qobj.get('buckets'), 'priority_added':added}
        return pr, summary
    except Exception as exc:
        try: append_error(ERROR, 'v774_priority_queue_attach', exc)
        except Exception: pass
        return pr, summary


# =============================================================================
# strategy_worker v0.779: strict structure routing + queue de-bloat
# - v776 showed S3->S2 over-promotion (S2 188) because generic recheck was promoted.
# - Keep structure-first idea, but promote S3 to S2 only when structure is strong AND confirmation is near.
# - Weak/ambiguous recheck stays S3 observation; target queue does not flood with weak S3.
# - No exit rule, BUY_READY, auto-buy, or paper ledger deletion changes.
# =============================================================================
BUILD_LABEL = "v789_s2_to_s1_post_route_rejudge_2026-06-09"
MAIN_DEPLOY_VERSION = "v2.13.783"
MAIN_BOT_VERSION = "수익형 v2.13.787"
VERSION = "strategy_worker_v0.789"


def _v777_text_blob(row: Dict[str, Any], route: Dict[str, Any]) -> str:
    parts: List[str] = []
    try:
        for x in (route.get('reasons') or []):
            parts.append(str(x))
    except Exception:
        pass
    for key in ('chart_state_tags_v772','structure_tags','risk_tags','s_stage_reasons','block_reasons'):
        v = row.get(key)
        if isinstance(v, list):
            parts.extend(str(x) for x in v[:10])
        elif isinstance(v, str):
            parts.append(v)
    ctx = row.get('entry_context') if isinstance(row.get('entry_context'), dict) else {}
    for key in ('chart_state_tags_v772','structure_tags','risk_tags'):
        v = ctx.get(key)
        if isinstance(v, list): parts.extend(str(x) for x in v[:10])
    return ' / '.join(parts)


def _v777_has_word(text: str, words: Tuple[str, ...]) -> bool:
    return any(w in text for w in words)


def _v780_structure_risk_detail(row: Dict[str, Any], route: Dict[str, Any]) -> Dict[str, Any]:
    """Split structure risk into hard block vs caution.
    Hard risk stays S3/S2 hold. Caution is allowed to S2 recheck only when structure hint + near confirmation exists.
    """
    txt = _v777_text_blob(row, route)
    hard_words = (
        '지지선 이탈', '저항 터치 후 밀림', '저항선에서 윗꼬리 밀림',
        '가짜 돌파 위험', 'VWAP·EMA 아래 구조', '윗꼬리 저항 주의',
        '매도압력 강함', '매도벽 강함'
    )
    caution_words = (
        '저항 바로 아래 추격 주의', '저항선 근처', '목표가 근처',
        '저항 돌파 확인 대기', '돌파 후 재테스트 대기', '체결 확인 필요',
        '지지선 근처 반응 대기'
    )
    try:
        spread = _v762_num(row.get('spread_pct'), default=99.0)
        slip = _v762_num(row.get('slippage_pct'), row.get('spread_pct'), default=spread)
    except Exception:
        spread = slip = 99.0
    hard_hits = [w for w in hard_words if w in txt]
    caution_hits = [w for w in caution_words if w in txt]
    if spread > 0.50 or slip > 0.50:
        hard_hits.append('스프레드/미끄러짐 과다')
    elif spread > 0.40 or slip > 0.40:
        caution_hits.append('스프레드/미끄러짐 주의')
    return {
        'schema': 'structure_risk_split_v780',
        'hard': bool(hard_hits),
        'caution': bool(caution_hits) and not bool(hard_hits),
        'hard_hits': hard_hits[:6],
        'caution_hits': caution_hits[:6],
        'spread': spread,
        'slip': slip,
    }


def _v777_s3_recheck_quality_ok(row: Dict[str, Any], route: Dict[str, Any]) -> bool:
    """S3->S2 recheck gate, corrected in v781.
    S1 remains strict elsewhere. S2 is a recheck queue, not an almost-S1 gate.
    Good/meaningful structure + no hard risk is enough for S2; missing confirmations become priority reasons.
    """
    detail = _v780_s3_recheck_detail(row, route) if '_v780_s3_recheck_detail' in globals() else {}
    return bool(detail.get('ok'))

def _v780_s3_recheck_detail(row: Dict[str, Any], route: Dict[str, Any]) -> Dict[str, Any]:
    txt = _v777_text_blob(row, route) if '_v777_text_blob' in globals() else ''
    primary_words = (
        '지지선 터치 후 반등','박스 상단 돌파','저점 쓸림 후 회복',
        '돌파 후 재테스트 성공','선 반응 후 매수세 확인','아래꼬리 회복'
    )
    support_words = ('지지선 위에서 유지','VWAP·EMA 위 유지','EMA 방어','VWAP 재회복')
    wait_words = (
        '저항 돌파 확인 대기','돌파 후 재테스트 대기',
        '가격은 반응했지만 체결 확인 필요','지지선 근처 반응 대기','저항선 근처'
    )
    try:
        react = _v762_num(row.get('price_reaction_pct'), row.get('change_1m_pct'), row.get('price_chg_60s'), default=0.0)
        buy = _v762_num(row.get('buy_ratio'), default=0.0)
        sustain = _v762_num(row.get('buy_sustain_1m'), row.get('buy_sustain'), row.get('buy_sustain_20s'), default=0.0)
        spread = _v762_num(row.get('spread_pct'), default=99.0)
        slip = _v762_num(row.get('slippage_pct'), row.get('spread_pct'), default=spread)
    except Exception:
        react=buy=sustain=0.0; spread=slip=99.0
    risk = _v780_structure_risk_detail(row, route) if '_v780_structure_risk_detail' in globals() else {'hard': False, 'caution': False}

    confirm_hits=[]
    missing=[]
    if react >= 0.10: confirm_hits.append('가격반응 재확인권')
    else: missing.append('가격반응 부족')
    if buy >= 0.64: confirm_hits.append('매수체결 재확인권')
    else: missing.append('매수체결 부족')
    if sustain >= 0.42: confirm_hits.append('1분지속 재확인권')
    else: missing.append('1분지속 부족')

    has_primary = _v777_has_word(txt, primary_words) if '_v777_has_word' in globals() else False
    has_support = _v777_has_word(txt, support_words) if '_v777_has_word' in globals() else False
    has_wait = _v777_has_word(txt, wait_words) if '_v777_has_word' in globals() else False
    if has_support and (react >= 0.08 or buy >= 0.60 or sustain >= 0.38):
        confirm_hits.append('지지/VWAP 유지 재확인권')

    safe = spread <= 0.45 and slip <= 0.45 and not row.get('stale_reasons')
    meaningful_structure = bool(has_primary or has_support)
    wait_with_hint = bool(has_wait and len(confirm_hits) >= 1)

    # v781: S2는 매수 직전 게이트가 아니라 재확인 큐다.
    # 구조가 의미 있고 하드위험이 없으면 확인값이 여러 개 빠져도 S2로 살린다.
    # 단, 단순 대기/저항근처 같은 wait-only 구조는 확인 힌트 1개 이상이 있어야 한다.
    ok = bool((meaningful_structure or wait_with_hint) and not risk.get('hard') and safe)
    priority = 'S2상위' if len(missing) <= 1 else ('S2일반' if len(missing) == 2 else 'S2낮음')
    if not ok:
        priority = 'S3관찰'
    return {
        'schema': 's2_recheck_reason_v781',
        'ok': ok,
        'primary_reaction': has_primary,
        'support_state': has_support,
        'wait_structure': has_wait,
        'meaningful_structure': meaningful_structure,
        'wait_with_hint': wait_with_hint,
        'hard_risk': bool(risk.get('hard')),
        'caution_risk': bool(risk.get('caution')),
        'risk_hits': (risk.get('hard_hits') or risk.get('caution_hits') or [])[:5],
        'confirm_hits': confirm_hits[:5],
        'confirm_hit_count': len(confirm_hits),
        'missing_confirmations': missing[:5],
        'missing_confirm_count': len(missing),
        's2_priority': priority,
        'safe_exec': bool(safe),
        'react': react, 'buy': buy, 'sustain': sustain, 'spread': spread, 'slip': slip,
    }

def _v777_set_stage_keep_reason(row: Dict[str, Any], stage: str, reason: str, open_allowed: bool = False) -> None:
    _v774_set_stage(row, stage, reason, open_allowed) if '_v774_set_stage' in globals() else None


def _v774_apply_structure_routing(rows: List[Dict[str, Any]], nowv: float) -> Tuple[List[Dict[str, Any]], Dict[str, Any]]:  # type: ignore[override]
    out: List[Dict[str, Any]] = []
    before = Counter(); after = Counter(); applied = Counter(); samples: List[Dict[str, Any]] = []
    risk_s1_blocked = good_to_s1 = good_to_s2 = s3_to_s2 = risk_to_s3 = observe_kept = weak_recheck_s3_kept = 0
    caution_to_s2 = caution_kept = hard_risk_to_s3 = 0
    for src in rows or []:
        if not isinstance(src, dict):
            continue
        r = dict(src)
        before_stage = _v510_stage(r)
        before[before_stage] += 1
        route = _v774_get_structure_route(r)
        kind = _v774_route_kind(route)
        confirm_ok = _v774_confirm_pass(r)
        reason_list = route.get('reasons') if isinstance(route.get('reasons'), list) else []
        reason_text = ' / '.join(str(x) for x in reason_list[:3]) or str(route.get('simple') or route.get('route') or '구조 우선 판단')
        detail = _v780_s3_recheck_detail(r, route) if before_stage == 'S3' and '_v780_s3_recheck_detail' in globals() else {}
        risk = _v780_structure_risk_detail(r, route) if '_v780_structure_risk_detail' in globals() else {'hard': False, 'caution': False}
        action = 'kept'

        if kind == 'risk_block':
            if risk.get('hard'):
                if before_stage == 'S1':
                    _v777_set_stage_keep_reason(r, 'S2', '하드 위험 구조라 S1 금지, S2 보류', False)
                    risk_s1_blocked += 1; action = 'hard_risk_s1_to_s2_hold'
                elif before_stage == 'S2':
                    _v777_set_stage_keep_reason(r, 'S3', '하드 위험 구조라 S2 제외, 관찰 전환', False)
                    risk_to_s3 += 1; hard_risk_to_s3 += 1; action = 'hard_risk_s2_to_s3'
                else:
                    _v777_set_stage_keep_reason(r, 'S3', '하드 위험 구조: S3 관찰', False)
                    risk_to_s3 += 1; hard_risk_to_s3 += 1; action = 'hard_risk_observe'
            else:
                # caution risk is not a buy block for S2; it is a recheck/watch state.
                if before_stage == 'S1':
                    _v777_set_stage_keep_reason(r, 'S2', '주의 구조라 S1 보류, S2 재확인', False)
                    risk_s1_blocked += 1; caution_to_s2 += 1; action = 'caution_s1_to_s2_recheck'
                elif before_stage == 'S2':
                    _v777_set_stage_keep_reason(r, 'S2', '주의 구조 S2 재확인 유지', False)
                    caution_to_s2 += 1; action = 'caution_s2_keep'
                elif before_stage == 'S3' and bool(detail.get('ok')):
                    _v777_set_stage_keep_reason(r, 'S2', '주의 구조지만 선반응/확인값 근접: S2 재확인', False)
                    s3_to_s2 += 1; caution_to_s2 += 1; action = 'caution_s3_to_s2_recheck'
                else:
                    _v777_set_stage_keep_reason(r, 'S3', '주의 구조지만 확인근거 부족: S3 관찰 유지', False)
                    caution_kept += 1; weak_recheck_s3_kept += 1; action = 'caution_s3_kept'

        elif kind == 's1_possible':
            if before_stage in ('S1','S2') and confirm_ok:
                _v777_set_stage_keep_reason(r, 'S1', '구조 양호 + 확인값 통과: S1 가능', True)
                good_to_s1 += 1; action = 'structure_good_to_s1'
            elif before_stage == 'S3' and bool(detail.get('ok')):
                _v777_set_stage_keep_reason(r, 'S2', '구조 양호 + 재확인값 근접: S2 재확인', False)
                s3_to_s2 += 1; good_to_s2 += 1; action = 'structure_good_s3_to_s2_recheck'
            elif before_stage in ('S1','S2'):
                _v777_set_stage_keep_reason(r, 'S2', '구조 양호하지만 확인값 재확인', False)
                good_to_s2 += 1; action = 'structure_good_recheck'
            else:
                _v777_set_stage_keep_reason(r, 'S3', '구조 양호하지만 확인값 부족: S3 관찰 유지', False)
                weak_recheck_s3_kept += 1; action = 'good_but_weak_s3_kept'

        elif kind == 's2_recheck':
            if before_stage == 'S3':
                if bool(detail.get('ok')):
                    _v777_set_stage_keep_reason(r, 'S2', '구조 재확인권 + 확인값 근접: S2 재확인', False)
                    s3_to_s2 += 1; action = 'structure_recheck_s3_to_s2_recheck'
                else:
                    _v777_set_stage_keep_reason(r, 'S3', '구조 재확인 후보지만 확인근거 부족: S3 관찰 유지', False)
                    weak_recheck_s3_kept += 1; action = 'weak_recheck_s3_kept'
            elif before_stage == 'S1' and not confirm_ok:
                _v777_set_stage_keep_reason(r, 'S2', '구조는 좋지만 확인값 부족: S2 재확인', False)
                action = 's1_to_s2_recheck'
            elif before_stage == 'S2':
                _v777_set_stage_keep_reason(r, 'S2', '구조 재확인 유지', False)
                action = 'recheck_keep'
            else:
                _v777_set_stage_keep_reason(r, before_stage if before_stage in ('S1','S2','S3') else 'S3', '구조 관찰 유지', False)
                action = 'recheck_observe_keep'

        else:
            observe_kept += 1
            if before_stage == 'S1':
                _v777_set_stage_keep_reason(r, 'S2', '구조 반응 확인 대기: S1 보류', False)
                action = 's1_to_s2_observe'
            elif before_stage not in ('S1','S2','S3'):
                _v777_set_stage_keep_reason(r, 'S3', '관찰 구조', False)
                action = 'observe_to_s3'

        r['structure_route_applied_v774'] = {
            'schema': 'structure_route_applied_v781',
            'before_stage': before_stage,
            'after_stage': _v510_stage(r),
            'route_kind': kind,
            'action': action,
            'confirm_pass': bool(confirm_ok),
            's2_recheck_ok': bool(detail.get('ok')) if before_stage == 'S3' else None,
            's2_recheck_detail_v780': detail if before_stage == 'S3' else {},
            'risk_split_v780': risk,
            'route': route.get('route') if isinstance(route, dict) else None,
            'reasons': reason_list[:6],
            'updated_ts': nowv,
            'policy': 'v781 S1 strict / S2 true recheck queue: missing confirmations are priority reasons, hard risk stays blocked; exits/BUY_READY/autobuy unchanged',
        }
        ctx = r.get('entry_context') if isinstance(r.get('entry_context'), dict) else {}
        ctx = dict(ctx); ctx['structure_route_applied_v774'] = r['structure_route_applied_v774']; r['entry_context'] = ctx
        snap = r.get('canonical_entry_snapshot') if isinstance(r.get('canonical_entry_snapshot'), dict) else r.get('canonical_entry_snapshot_v762') if isinstance(r.get('canonical_entry_snapshot_v762'), dict) else {}
        if isinstance(snap, dict):
            snap2 = dict(snap); snap2['structure_route_applied_v774'] = r['structure_route_applied_v774']; snap2['structure_first_route_v774'] = route
            r['canonical_entry_snapshot'] = snap2; r['canonical_entry_snapshot_v762'] = snap2; r['structure_snapshot_v762'] = snap2
        after[_v510_stage(r)] += 1; applied[action] += 1
        if len(samples) < 12 or _v510_stage(r) in ('S1','S2'):
            samples.append({'ticker': r.get('ticker'), 'before': before_stage, 'after': _v510_stage(r), 'action': action, 'route': route.get('route') if isinstance(route, dict) else '-', 'why': reason_text, 's2_detail': detail if isinstance(detail, dict) else {}, 'risk': risk if isinstance(risk, dict) else {}})
        out.append(r)

    s2_actions = ('structure_good_s3_to_s2_recheck','structure_recheck_s3_to_s2_recheck','caution_s3_to_s2_recheck')
    summary = {
        'schema': 'structure_route_apply_summary_v781', 'version': VERSION, 'updated_ts': nowv, 'updated_text': now_text(nowv),
        'before_stage_counts': dict(before), 'after_stage_counts': dict(after), 'action_counts': dict(applied),
        'risk_s1_blocked': risk_s1_blocked, 'risk_to_s3': risk_to_s3, 'hard_risk_to_s3': hard_risk_to_s3,
        'caution_to_s2': caution_to_s2, 'caution_kept': caution_kept,
        'structure_good_to_s1': good_to_s1, 'structure_good_to_s2': good_to_s2,
        's2_recheck_promoted': s3_to_s2, 'true_structure_s3_to_s2': s3_to_s2, 's3_to_s2': s3_to_s2,
        'weak_recheck_s3_kept': weak_recheck_s3_kept, 'observe_kept': observe_kept,
        's2_recheck_sample': [x for x in samples if str(x.get('action','')) in s2_actions][:8],
        'strict_s3_to_s2_sample': [x for x in samples if str(x.get('action','')) in s2_actions][:8],
        'sample': samples[:16],
        'policy': 'S1은 기존처럼 빡세게 유지하고, S2는 의미있는 구조+하드위험 없음이면 확인값이 여러 개 부족해도 재확인으로 살림. 부족값은 차단이 아니라 우선순위로 기록. 청산/자동매수/BUY_READY 변경 없음.',
    }
    try:
        cache = load_json(STRUCTURE_SNAPSHOT_CACHE, {}) or {}
        if not isinstance(cache, dict): cache = {}
        cache['structure_route_apply_summary_v774'] = summary
        cache['structure_route_apply_counts_v774'] = dict(applied)
        cache['structure_route_apply_sample_v774'] = samples[:12]
        save_json(STRUCTURE_SNAPSHOT_CACHE, cache)
    except Exception as exc:
        try: append_error(ERROR, 'v781_structure_route_cache', exc)
        except Exception: pass
    return out, summary

def _v774_priority_bucket(row: Dict[str, Any]) -> Tuple[str, int, int, List[str]]:  # type: ignore[override]
    stage = _v510_stage(row)
    route = _v774_get_structure_route(row)
    kind = _v774_route_kind(route)
    if stage == 'S1' or bool(row.get('open_eligible')):
        return 'structure_core_open_s1', 990, 45, ['OPEN/S1/S1 hold 최우선 구조 갱신']
    if stage == 'S2':
        return 'structure_recheck_s2', 900, 90, ['S2/재확인 구조 자주 갱신']
    if stage == 'S3' and kind == 's1_possible' and _v777_s3_recheck_quality_ok(row, route):
        return 'structure_good_s3_watch', 800, 180, ['구조 좋은 S3 중간 갱신']
    if stage == 'S3' and kind == 's2_recheck' and _v777_s3_recheck_quality_ok(row, route):
        return 'structure_recheck_s3_watch', 760, 240, ['재확인 가치 있는 S3 순환 갱신']
    return 'structure_coverage_slow', 520, 420, ['coverage 느린 순환']



# =============================================================================
# strategy_worker v0.788: S2 재확인 결과 확정 저장 spine
# - 조건값/S1 기준/청산/BUY_READY/자동매수는 바꾸지 않는다.
# - v774 구조 라우팅 뒤 새로 S2가 된 row도 같은 cycle에서 "왜 S1이 아닌지 / 다음 재확인 액션"을
#   최종 후보 row에 저장한다.
# - target_router가 읽는 s1_promotion_gate / relative_context / recheck_score를 같은 row에 같이 둔다.
# =============================================================================
def _v788_s2_num(row: Dict[str, Any], *keys: str, default: float = 0.0) -> float:
    vals = []
    ctx = row.get('entry_context') if isinstance(row.get('entry_context'), dict) else {}
    cmr = row.get('canonical_metric_row') if isinstance(row.get('canonical_metric_row'), dict) else {}
    dec = row.get('canonical_entry_decision') if isinstance(row.get('canonical_entry_decision'), dict) else {}
    metrics = dec.get('metrics') if isinstance(dec.get('metrics'), dict) else {}
    for src in (row, ctx, cmr, metrics):
        if not isinstance(src, dict):
            continue
        for k in keys:
            vals.append(src.get(k))
    return _v510_num(*vals, default=default)


def _v788_as_list(v: Any) -> List[str]:
    if v in (None, '', [], {}):
        return []
    raw = v if isinstance(v, list) else [v]
    out: List[str] = []
    for x in raw:
        if isinstance(x, dict):
            txt = str(x.get('reason') or x.get('name') or x.get('value') or x.get('state') or '').strip()
        else:
            txt = str(x).strip()
        if txt and txt not in out:
            out.append(txt)
    return out


def _v788_trigger_state(row: Dict[str, Any]) -> Dict[str, Any]:
    plan = row.get('entry_plan') if isinstance(row.get('entry_plan'), dict) else {}
    ctx = row.get('entry_context') if isinstance(row.get('entry_context'), dict) else {}
    current = _v788_s2_num(row, 'current_price', 'entry_price', 'price', 'trade_price', default=0.0)
    trigger = _v788_s2_num(row, 'trigger_price', default=0.0)
    if trigger <= 0 and isinstance(plan, dict):
        trigger = _v510_num(plan.get('trigger_price'), default=0.0)
    reached = bool(current > 0 and trigger > 0 and current >= trigger)
    gap = round(((trigger - current) / current * 100.0), 4) if current > 0 and trigger > 0 else None
    return {
        'current_price': current,
        'trigger_price': trigger,
        'trigger_reached': reached if trigger > 0 else None,
        'trigger_gap_pct': gap,
        'trigger_reason': plan.get('trigger_reason') or ctx.get('trigger_reason'),
    }


def _v788_s2_outcome(row: Dict[str, Any], nowv: float) -> Tuple[Dict[str, Any], float]:
    dec = row.get('canonical_entry_decision') if isinstance(row.get('canonical_entry_decision'), dict) else {}
    route_applied = row.get('structure_route_applied_v774') if isinstance(row.get('structure_route_applied_v774'), dict) else {}
    route_detail = route_applied.get('s2_recheck_detail_v780') if isinstance(route_applied.get('s2_recheck_detail_v780'), dict) else {}
    risk_detail = route_applied.get('risk_split_v780') if isinstance(route_applied.get('risk_split_v780'), dict) else {}
    trigger = _v788_trigger_state(row)
    react = _v788_s2_num(row, 'price_reaction_pct', 'change_1m_pct', 'price_chg_60s', default=0.0)
    buy = _v788_s2_num(row, 'buy_ratio', default=0.0)
    sustain = _v788_s2_num(row, 'buy_sustain_1m', 'buy_sustain', 'buy_sustain_20s', default=0.0)
    spread = _v788_s2_num(row, 'spread_pct', default=99.0)
    slip = _v788_s2_num(row, 'slippage_pct', 'spread_pct', default=spread)
    stale = _v788_as_list(row.get('stale_reasons'))
    blocks = _v510_uniq(
        _v788_as_list(row.get('common_uprising_blocked_v732'))
        + _v788_as_list(row.get('s2_to_s1_promotion_blocked_v732'))
        + _v788_as_list(dec.get('s1_recheck_guard_reasons'))
        + _v788_as_list(row.get('s1_missing_conditions'))
        + _v788_as_list(row.get('s2_recheck_reasons')),
        12,
    )
    hard_risk = bool(risk_detail.get('hard')) or any(any(w in str(x) for w in ('하드 위험', '위험태그', '매도압력', '가짜돌파', '윗꼬리')) for x in blocks)
    exec_risk = bool(spread > 0.18 or slip > 0.20 or any(any(w in str(x) for w in ('스프레드', '미끄러짐')) for x in blocks))
    confirm_wait = bool(react < 0.35 or buy < 0.70 or sustain < 0.70 or any(any(w in str(x) for w in ('가격반응', '매수체결', '1분지속', '체결')) for x in blocks))
    trigger_wait = bool(trigger.get('trigger_reached') is False and trigger.get('trigger_price'))
    if hard_risk:
        state = 'hard_risk_hold'
        label = '하드위험 보류'
        next_action = 'observe_or_downgrade'
    elif stale:
        state = 'fresh_wait'
        label = '신선정보 재수집 대기'
        next_action = 'target_router_refresh'
    elif exec_risk:
        state = 'exec_risk_wait'
        label = '스프레드/미끄러짐 회복 대기'
        next_action = 'target_router_refresh'
    elif trigger_wait:
        state = 'trigger_wait'
        label = '방아쇠 가격 대기'
        next_action = 'target_router_refresh'
    elif confirm_wait:
        state = 'confirm_wait'
        label = '가격/체결/지속 확인 대기'
        next_action = 'target_router_refresh'
    else:
        state = 's2_recheck_active'
        label = 'S2 재확인 유지'
        next_action = 'target_router_refresh'
    structure_score = 0.0
    if route_detail.get('meaningful_structure') or route_detail.get('primary_reaction'):
        structure_score += 18.0
    if route_detail.get('support_state'):
        structure_score += 10.0
    if route_detail.get('wait_with_hint'):
        structure_score += 6.0
    confirm_score = 0.0
    confirm_score += min(18.0, max(0.0, react) * 30.0)
    confirm_score += min(14.0, max(0.0, buy - 0.45) * 40.0)
    confirm_score += min(14.0, max(0.0, sustain - 0.35) * 35.0)
    risk_penalty = 25.0 if hard_risk else (10.0 if exec_risk else 0.0)
    stale_penalty = 8.0 if stale else 0.0
    trigger_bonus = 8.0 if trigger_wait and _v510_num(trigger.get('trigger_gap_pct'), default=999.0) <= 0.35 else 0.0
    near_bonus = 8.0 if bool(row.get('s1_near_miss')) else 0.0
    score = max(0.0, 40.0 + structure_score + confirm_score + trigger_bonus + near_bonus - risk_penalty - stale_penalty)
    outcome = {
        'schema': 's2_recheck_outcome_v788',
        'version': VERSION,
        'updated_ts': nowv,
        'state': state,
        'label': label,
        'next_action': next_action,
        'metrics': {'price_reaction_pct': react, 'buy_ratio': buy, 'buy_sustain_1m': sustain, 'spread_pct': spread, 'slippage_pct': slip},
        'trigger': trigger,
        'block_reasons': blocks[:10],
        'stale_reasons': stale[:6],
        'structure_route_action': route_applied.get('action'),
        'structure_recheck_detail': route_detail,
        'risk_detail': risk_detail,
        'policy': 'S1 기준값 변경 없음. 구조 라우팅 후 S2 재확인 결과/다음 액션만 canonical row에 확정 저장.',
    }
    return outcome, round(score, 3)


def _v788_attach_s2_recheck_outcome_spine(rows: List[Dict[str, Any]], nowv: float) -> Tuple[List[Dict[str, Any]], Dict[str, Any]]:
    out: List[Dict[str, Any]] = []
    counts: Counter = Counter()
    samples: List[Dict[str, Any]] = []
    for src in rows or []:
        if not isinstance(src, dict):
            continue
        r = dict(src)
        st = _v510_stage(r)
        if st == 'S1' and bool(r.get('open_eligible')):
            r['s2_recheck_last_state_v788'] = 'promoted_s1'
            r['s2_recheck_outcome_v788'] = {'schema': 's2_recheck_outcome_v788', 'version': VERSION, 'updated_ts': nowv, 'state': 'promoted_s1', 'label': 'S1 승격 완료', 'next_action': 'paper_handoff'}
            counts['promoted_s1'] += 1
        elif st == 'S2':
            outcome, score = _v788_s2_outcome(r, nowv)
            state = str(outcome.get('state') or 's2_recheck_active')
            counts[state] += 1
            r['s2_recheck_outcome_v788'] = outcome
            r['s2_recheck_last_state_v788'] = state
            r['recheck_state'] = 'S2 재확인'
            old_reasons = _v788_as_list(r.get('s2_recheck_reasons'))
            state_reason = str(outcome.get('label') or state)
            r['s2_recheck_reasons'] = _v510_uniq(old_reasons + [f'v788:{state_reason}'], 10)
            r['recheck_score'] = max(_v510_num(r.get('recheck_score'), r.get('score'), default=0.0), score)
            gate_blocks = _v788_as_list(outcome.get('block_reasons')) or _v788_as_list(r.get('s1_missing_conditions'))
            r['s1_promotion_gate'] = {
                'schema': 's1_promotion_gate_v788',
                'version': VERSION,
                'updated_ts': nowv,
                'pass': False,
                'state': state,
                'block_reasons': gate_blocks[:10],
                'next_action': outcome.get('next_action'),
                'recheck_score': r.get('recheck_score'),
            }
            rel = r.get('relative_context') if isinstance(r.get('relative_context'), dict) else {}
            rel = dict(rel)
            rel['missing'] = _v510_uniq(_v788_as_list(rel.get('missing')) + gate_blocks[:8], 12)
            rel['s2_recheck_state_v788'] = state
            r['relative_context'] = rel
            ctx = r.get('entry_context') if isinstance(r.get('entry_context'), dict) else {}
            ctx = dict(ctx)
            ctx['s2_recheck_outcome_v788'] = outcome
            ctx['s1_promotion_gate'] = r['s1_promotion_gate']
            r['entry_context'] = ctx
            if len(samples) < 12:
                samples.append({'ticker': ticker_norm(r.get('ticker') or r.get('market') or r.get('symbol')), 'state': state, 'score': r.get('recheck_score'), 'blocks': gate_blocks[:4], 'metrics': outcome.get('metrics'), 'trigger': outcome.get('trigger')})
        out.append(r)
    return out, {
        'schema': 's2_recheck_outcome_summary_v788',
        'version': VERSION,
        'updated_ts': nowv,
        'counts': dict(counts),
        'samples': samples,
        'policy': '구조 라우팅으로 S2가 된 후보의 재확인 결과를 같은 canonical row에 저장하고 target_router가 읽을 gate/recheck_score를 단일화. 조건값/청산/자동매수 변경 없음.',
    }



# =============================================================================
# strategy_worker v0.789: structure route 후 S2→S1 승급판 재심사
# - v788의 S2 재확인 결과 저장 helper는 유지한다.
# - 단, 최종 reseal 순서는 구조 라우팅 뒤 S2를 canonical S1 승급판에 다시 태운 뒤
#   S2 결과표를 마지막에 다시 맞춘다.
# - 조건값/S1 기준/청산/BUY_READY/자동매수/paper 장부는 변경하지 않는다.
# =============================================================================
BUILD_LABEL = "strategy_worker_v0.791_structure_quality_exec_split_2026-06-09"
VERSION = "strategy_worker_v0.791"


def _v789_is_observe_only(row: Dict[str, Any]) -> bool:
    return bool(
        row.get("s3_observe_v732") or row.get("s3_observe_v730") or row.get("s3_observe_v729")
        or row.get("s3_observe_v728") or row.get("s3_observe_v727")
        or str(row.get("strategy_key") or "").startswith("coin_quality_s3_observe")
    )


def _v789_blocks_from(row: Dict[str, Any]) -> List[str]:
    dec = row.get("canonical_entry_decision") if isinstance(row.get("canonical_entry_decision"), dict) else {}
    return _v510_uniq(
        _v788_as_list(row.get("s2_to_s1_promotion_blocked_v732"))
        + _v788_as_list(row.get("common_uprising_blocked_v732"))
        + _v788_as_list(row.get("s1_missing_conditions"))
        + _v788_as_list(row.get("s2_recheck_reasons"))
        + _v788_as_list(dec.get("display_reasons")),
        12,
    )


def _v789_seal_post_route_s1(row: Dict[str, Any], nowv: float, source_stage: str) -> Dict[str, Any]:
    r = dict(row)
    for k in ("created_at", "candidate_created_at", "source_created_at", "detected_ts", "event_ts", "updated_ts"):
        r[k] = nowv
    try:
        r["expires_at"] = nowv + max(60.0, float(CANDIDATE_TTL_SEC or 90))
    except Exception:
        r["expires_at"] = nowv + 90.0
    r["promoted_at_v789"] = nowv
    r["promoted_at_text_v789"] = now_text(nowv)
    r["promotion_spine_v789"] = "post_structure_route_rejudged_to_s1"
    r["s_stage"] = r["candidate_stage"] = r["candidate_grade"] = r["stage"] = r["grade"] = "S1"
    r["open_eligible"] = True
    r["paper_bot_open"] = True
    r["trade_ready"] = True
    r["s2_recheck_last_state_v788"] = "promoted_s1"
    r["s2_recheck_outcome_v788"] = {
        "schema": "s2_recheck_outcome_v788",
        "version": VERSION,
        "updated_ts": nowv,
        "state": "promoted_s1",
        "label": "S1 승격 완료",
        "next_action": "paper_handoff",
        "source": "v789_post_structure_route_rejudge",
    }
    r["s1_promotion_gate"] = {
        "schema": "s1_promotion_gate_v789",
        "version": VERSION,
        "updated_ts": nowv,
        "pass": True,
        "state": "promoted_s1",
        "block_reasons": [],
        "next_action": "paper_handoff",
        "source_stage_before_rejudge": source_stage,
    }
    ctx = r.get("entry_context") if isinstance(r.get("entry_context"), dict) else {}
    ctx = dict(ctx)
    ctx.update({
        "promotion_spine_v789": r["promotion_spine_v789"],
        "promoted_at_v789": nowv,
        "stage_after_promotion_v789": "S1",
        "open_eligible": True,
        "s2_recheck_outcome_v788": r["s2_recheck_outcome_v788"],
        "s1_promotion_gate": r["s1_promotion_gate"],
    })
    r["entry_context"] = ctx
    return r


def _v789_post_structure_route_rejudge(rows: List[Dict[str, Any]], nowv: float) -> Tuple[List[Dict[str, Any]], Dict[str, Any]]:
    out: List[Dict[str, Any]] = []
    counts: Counter = Counter()
    block_top: Counter = Counter()
    samples: List[Dict[str, Any]] = []
    for src in rows or []:
        if not isinstance(src, dict):
            continue
        before = _v510_stage(src)
        r = dict(src)
        route = r.get("structure_route_applied_v774") if isinstance(r.get("structure_route_applied_v774"), dict) else {}
        action = str(route.get("action") or "")
        should_rejudge = bool(before == "S2" and not _v789_is_observe_only(r))
        if should_rejudge:
            counts["target"] += 1
            judged = _v532_apply_canonical_entry_decision(dict(r))
            after = _v510_stage(judged)
            if after == "S1" and bool(judged.get("open_eligible")) and bool(judged.get("common_uprising_pass_v732") or judged.get("common_entry_pass")):
                judged = _v789_seal_post_route_s1(judged, nowv, before)
                counts["promoted_s1"] += 1
            else:
                if _v510_stage(judged) == "S2":
                    counts["kept_s2"] += 1
                else:
                    counts["downgraded_or_observe"] += 1
                blocks = _v789_blocks_from(judged) or ["S1 승급 조건 미통과"]
                for b in blocks[:5]:
                    block_top[str(b)] += 1
                gate = judged.get("s1_promotion_gate") if isinstance(judged.get("s1_promotion_gate"), dict) else {}
                gate = dict(gate)
                gate.update({
                    "schema": "s1_promotion_gate_v789",
                    "version": VERSION,
                    "updated_ts": nowv,
                    "pass": False,
                    "state": str(judged.get("s2_recheck_last_state_v788") or gate.get("state") or "confirm_wait"),
                    "block_reasons": blocks[:10],
                    "next_action": gate.get("next_action") or "target_router_refresh",
                    "source": "v789_post_structure_route_rejudge",
                    "source_stage_before_rejudge": before,
                })
                judged["s1_promotion_gate"] = gate
                ctx = judged.get("entry_context") if isinstance(judged.get("entry_context"), dict) else {}
                ctx = dict(ctx)
                ctx["s1_promotion_gate"] = gate
                ctx["post_structure_rejudge_v789"] = True
                judged["entry_context"] = ctx
            if len(samples) < 12:
                samples.append({
                    "ticker": ticker_norm(judged.get("ticker") or judged.get("market") or judged.get("symbol")),
                    "before": before,
                    "after": _v510_stage(judged),
                    "action": action,
                    "common_pass": bool(judged.get("common_uprising_pass_v732")),
                    "promoted": bool(judged.get("s2_to_s1_promoted_v732")),
                    "blocks": _v789_blocks_from(judged)[:4],
                })
            r = judged
        out.append(r)
    return out, {
        "schema": "post_structure_route_s1_rejudge_v789",
        "version": VERSION,
        "updated_ts": nowv,
        "updated_text": now_text(nowv),
        "counts": dict(counts),
        "blocked_top": dict(block_top.most_common(8)),
        "sample": samples,
        "policy": "구조 라우팅으로 S2가 된 후보를 같은 cycle에서 canonical S1 승급판에 다시 태움. 조건값/청산/자동매수/BUY_READY 변경 없음.",
    }


_v789_prev_reseal_common = _v732_reseal_common_uprising_promotions


def _v732_reseal_common_uprising_promotions(rows: List[Dict[str, Any]], nowv: float) -> Tuple[List[Dict[str, Any]], Dict[str, Any]]:  # type: ignore[override]
    # _v789_prev_reseal_common은 v774까지의 본선: base v732 reseal → structure routing.
    routed, summary = _v789_prev_reseal_common(rows, nowv)
    try:
        rejudged, rejudge_summary = _v789_post_structure_route_rejudge(routed, nowv)
        final_rows, outcome_summary = _v788_attach_s2_recheck_outcome_spine(rejudged, nowv)
        if isinstance(summary, dict):
            summary = dict(summary)
            summary["post_structure_route_s1_rejudge_v789"] = rejudge_summary
            summary["s2_recheck_outcome_summary_v789"] = outcome_summary
        return final_rows, summary
    except Exception as exc:
        try: append_error(ERROR, "v789_post_structure_route_rejudge", exc)
        except Exception: pass
        return routed, summary




# =============================================================================
# strategy_worker v0.792 / bundle v794: 구조 선품질·반응 해석 spine
# - 조건 완화가 아니다. S1 기준값/청산/자동매수/BUY_READY/paper 장부 변경 없음.
# - 구조 좋은/주의 태그는 차단문이 아니라 선 품질·선 반응 해석/복기용으로 저장한다.
# - 약장은 차단하지 않고, 약장 속 상대강도만 태그로 남긴다.
# - exec_risk_wait는 "진짜 실행위험"과 "스프레드만 회복 대기"를 분리 표시한다. S1 조건값 직접 완화 없음.
# =============================================================================
def _v792_blob(row: Dict[str, Any]) -> str:
    parts: List[str] = []
    for k in (
        'strategy_label','strategy','strategy_key','entry_reasons','entry_basis','matched_strategy_labels',
        'matched_strategy_keys','structure_tags','entry_structure_tags','risk_tags','structure_risk_tags',
        'execution_risk_tags','s_stage_reasons','block_reasons','s2_recheck_reasons','s1_missing_conditions'
    ):
        v = row.get(k)
        if isinstance(v, list):
            parts += [str(x) for x in v]
        elif isinstance(v, dict):
            parts += [str(x) for x in v.values()]
        elif v not in (None, ''):
            parts.append(str(v))
    ctx = row.get('entry_context') if isinstance(row.get('entry_context'), dict) else {}
    for k in ('entry_structure_tags','risk_tags','structure_tags','entry_basis'):
        v = ctx.get(k)
        if isinstance(v, list): parts += [str(x) for x in v]
        elif v not in (None, ''): parts.append(str(v))
    return ' '.join(parts)



def _v794_first_nonempty(row: Dict[str, Any], keys: List[str], default: Any = '') -> Any:
    for k in keys:
        v = row.get(k)
        if v not in (None, '', [], {}):
            return v
    ctx = row.get('entry_context') if isinstance(row.get('entry_context'), dict) else {}
    for k in keys:
        v = ctx.get(k)
        if v not in (None, '', [], {}):
            return v
    sb = row.get('source_basis') if isinstance(row.get('source_basis'), dict) else {}
    for k in keys:
        v = sb.get(k)
        if v not in (None, '', [], {}):
            return v
    levels = row.get('structure_levels') if isinstance(row.get('structure_levels'), dict) else {}
    for k in keys:
        v = levels.get(k)
        if v not in (None, '', [], {}):
            return v
    return default


def _v794_line_quality(row: Dict[str, Any]) -> str:
    q = str(_v794_first_nonempty(row, [
        'line_quality_v794','structure_line_quality','structure_line_quality_v762','line_quality_v762','line_quality','reliability','structure_line_reliability'
    ], '') or '')
    if not q or q in ('-', 'None'):
        return 'missing_line'
    ql = q.lower()
    if any(x in q for x in ('무효', '의심', 'invalid')) or 'invalid' in ql:
        return 'invalid_or_suspect_line'
    if any(x in q for x in ('stale', '오래', 'old')) or 'stale' in ql:
        return 'stale_line'
    if any(x in q for x in ('official', '공식', '확실', 'confirmed')) or 'official' in ql:
        return 'confirmed_line'
    if any(x in q for x in ('reactive', 'reaction', '반응')) or 'reactive' in ql:
        return 'reactive_line'
    if any(x in q for x in ('calculated', '계산', '임시')) or 'calculated' in ql:
        return 'calculated_line_recheck'
    if any(x in q for x in ('weak', '부족')) or 'weak' in ql:
        return 'weak_line'
    return q[:60]


def _v794_buy_sustain_source(row: Dict[str, Any], sustain: float) -> str:
    real = row.get('buy_sustain_1m_real')
    if real is True:
        return 'measured'
    if real is False:
        return 'estimated_or_missing'
    src = str(_v794_first_nonempty(row, ['buy_sustain_source','buy_sustain_1m_source','orderflow_source','micro_source'], '') or '')
    if src:
        return src[:60]
    if sustain == 0:
        return 'zero_unknown_source'
    return 'source_unknown'


def _v794_line_reaction_tags(row: Dict[str, Any], blob: str, react: float, ch3: float, ch5: float, buy: float, sustain: float, vwap: float, ema: float) -> List[str]:
    tags: List[str] = []
    if ('지지' in blob or '저점' in blob or '쓸림' in blob) and react >= 0.12 and (buy >= 0.55 or sustain >= 0.55):
        tags.append('지지·저점선반응')
    if ('저항' in blob or '돌파' in blob or '박스상단' in blob) and react >= 0.18 and ch3 >= -0.05:
        tags.append('저항돌파후유지')
    if ('재테스트' in blob or '지지전환' in blob) and react >= 0.10 and sustain >= 0.55:
        tags.append('돌파후재테스트반응')
    if (vwap >= -0.03 and ema >= -0.05 and sustain >= 0.55):
        tags.append('VWAP·EMA선방어')
    if react >= 0.35 and (ch3 < 0.05 or ch5 < 0.05):
        tags.append('초반반응후후속약함')
    if react <= 0.03 and buy >= 0.75 and sustain >= 0.75:
        tags.append('체결대비가격무반응')
    return _v510_uniq(tags, 8)


def _v794_structure_interpretation(good: List[str], risk: List[str], fail: List[str], line_reaction: List[str], line_quality: str) -> str:
    if line_quality in ('invalid_or_suspect_line','stale_line'):
        return '선품질재확인'
    if line_reaction and good and not fail:
        return '선반응양호'
    if line_reaction and fail:
        return '선반응있지만후속약함'
    if good and not fail:
        return '구조양호관찰'
    if fail:
        return '실패패턴주의'
    if line_quality in ('missing_line','weak_line','calculated_line_recheck'):
        return '구조선근거재확인'
    return '중립구조'

def _v792_quality_tags(row: Dict[str, Any], nowv: float) -> Dict[str, Any]:
    blob = _v792_blob(row)
    react = _v788_s2_num(row, 'price_reaction_pct', 'change_1m_pct', 'price_chg_60s', 'change_1m', 'price_change_1m', default=0.0)
    ch3 = _v788_s2_num(row, 'change_3m', 'price_change_3m', 'change_3m_pct', default=0.0)
    ch5 = _v788_s2_num(row, 'change_5m', 'price_change_5m', 'change_5m_pct', default=0.0)
    ch15 = _v788_s2_num(row, 'change_15m', 'price_change_15m', default=0.0)
    ch30 = _v788_s2_num(row, 'change_30m', 'price_change_30m', default=0.0)
    buy = _v788_s2_num(row, 'buy_ratio', default=0.0)
    sustain = _v788_s2_num(row, 'buy_sustain_1m', 'buy_sustain', 'buy_sustain_20s', default=0.0)
    spread = _v788_s2_num(row, 'spread_pct', default=99.0)
    slip = _v788_s2_num(row, 'slippage_pct', 'spread_pct', default=spread)
    vwap = _v788_s2_num(row, 'vwap_gap_pct', default=0.0)
    ema = _v788_s2_num(row, 'ema5_gap_pct', 'ma5_gap_pct', default=0.0)
    rel = _v788_s2_num(row, 'relative_strength_pct', 'relative_strength', default=0.0)
    high_gap = _v788_s2_num(row, 'recent_high_gap_pct', 'below_high_pct', default=-9.0)
    low_rebound = _v788_s2_num(row, 'recent_low_rebound_pct', default=0.0)
    market_mode = str(row.get('market_mode') or row.get('market_regime') or row.get('market_state') or '')
    weak_market = bool(('약' in market_mode) or ('weak' in market_mode.lower()) or (rel >= 0.45 and ch3 >= 0.0 and ch5 >= 0.0 and ch15 < 0.25))

    good: List[str] = []
    risk: List[str] = []
    fail: List[str] = []
    early: List[str] = []
    line_quality = _v794_line_quality(row)
    sustain_source = _v794_buy_sustain_source(row, sustain)

    if vwap >= -0.03 and ema >= -0.05 and (buy >= 0.65 or sustain >= 0.65):
        good.append('VWAP/EMA방어+체결유지')
    if ('저점' in blob or '쓸림' in blob or low_rebound >= 0.35) and vwap >= -0.05 and buy >= 0.60:
        good.append('저점쓸림후회복')
    if ('재테스트' in blob or '지지전환' in blob or '박스상단' in blob or '돌파후유지' in blob) and react >= 0.15 and sustain >= 0.55:
        good.append('돌파후재테스트/지지전환')
    if ('돈흐름' in blob or '거래량' in blob or '재유입' in blob) and ch3 >= 0.10 and ch5 >= 0.10 and buy >= 0.60:
        good.append('돈흐름재유입')
    if weak_market and ((react >= 0.25 and buy >= 0.60) or (ch3 >= 0.20 and ch5 >= 0.20) or rel >= 0.80):
        good.append('약장상대강도')
    if ch15 >= 0.7 and ch30 >= 0.4 and vwap >= 0 and ema >= 0:
        good.append('주도흐름유지')

    if '윗꼬리' in blob or '저항' in blob and high_gap >= -0.05:
        risk.append('윗꼬리/저항추격주의')
    if vwap < -0.12 or ema < -0.18:
        risk.append('VWAP/EMA하단구조')
    if react <= 0.05 and buy >= 0.80 and sustain >= 0.80:
        fail.append('체결높은데가격무반응')
        early.append('진입후1~2분무반응빠른확인')
    if react >= 0.35 and (ch3 < 0.05 or ch5 < 0.05) and sustain < 0.62:
        fail.append('1분반응후3/5분약화')
    if spread > 0.30 or slip > 0.32:
        risk.append('실행비용높음')
    if spread > 0.18 or slip > 0.20:
        if buy >= 0.75 and sustain >= 0.70 and react >= 0.20 and not any('매도압력' in x for x in _v788_as_list(row.get('risk_tags'))):
            exec_class = 'spread_only_recheckable'
            exec_label = '스프레드만 회복 대기'
        elif spread > 0.35 or slip > 0.35 or buy < 0.55:
            exec_class = 'hard_exec_risk'
            exec_label = '실행위험 큼'
        else:
            exec_class = 'exec_recheck'
            exec_label = '실행위험 재확인'
    else:
        exec_class = 'exec_ok'
        exec_label = '실행위험 정상권'

    # v794: 구조 실패패턴은 차단문이 아니라 선 반응/복기/빠른확인 태그다.
    # 진짜 차단은 기존 하드위험·실행위험 경로가 담당한다. 여기서는 S1 조건값을 직접 바꾸지 않는다.
    line_reaction = _v794_line_reaction_tags(row, blob, react, ch3, ch5, buy, sustain, vwap, ema)
    structure_interpretation = _v794_structure_interpretation(good, risk, fail, line_reaction, line_quality)
    fail_score = len(fail) + (1 if 'VWAP/EMA하단구조' in risk else 0) + (1 if '윗꼬리/저항추격주의' in risk and react < 0.20 else 0)
    s1_block = False

    return {
        'schema': 'structure_quality_v794',
        'version': VERSION,
        'updated_ts': nowv,
        'good_tags': _v510_uniq(good, 8),
        'risk_tags': _v510_uniq(risk, 8),
        'failure_pattern_tags': _v510_uniq(fail, 8),
        'early_fail_watch_tags': _v510_uniq(early, 6),
        'weak_market_relative_strength': bool('약장상대강도' in good),
        'line_quality_v794': line_quality,
        'line_reaction_tags_v794': line_reaction,
        'structure_interpretation_v794': structure_interpretation,
        'buy_sustain_source_v794': sustain_source,
        'failure_pattern_score_v794': fail_score,
        'exec_risk_class': exec_class,
        'exec_risk_label': exec_label,
        's1_structure_block_candidate': s1_block,
        'metrics': {'react': react, 'ch3': ch3, 'ch5': ch5, 'ch15': ch15, 'ch30': ch30, 'buy': buy, 'sustain': sustain, 'spread': spread, 'slippage': slip, 'vwap_gap_pct': vwap, 'ema5_gap_pct': ema, 'relative_strength_pct': rel},
        'policy': '구조태그는 차단문이 아니라 선 품질/선 반응/복기 태그로 사용. 조건 완화 없음.',
    }


def _v792_apply_quality_to_row(row: Dict[str, Any], nowv: float) -> Dict[str, Any]:
    r = dict(row)
    q = _v792_quality_tags(r, nowv)
    r['structure_quality_v792'] = q
    r['structure_good_tags_v792'] = q.get('good_tags') or []
    r['structure_failure_tags_v792'] = q.get('failure_pattern_tags') or []
    r['early_fail_watch_tags_v792'] = q.get('early_fail_watch_tags') or []
    r['exec_risk_class_v792'] = q.get('exec_risk_class')
    r['weak_market_relative_strength_v792'] = bool(q.get('weak_market_relative_strength'))
    r['line_quality_v794'] = q.get('line_quality_v794')
    r['line_reaction_tags_v794'] = q.get('line_reaction_tags_v794') or []
    r['structure_interpretation_v794'] = q.get('structure_interpretation_v794')
    r['buy_sustain_source_v794'] = q.get('buy_sustain_source_v794')
    r['structure_warning_tags_v794'] = _v510_uniq(_v788_as_list(q.get('risk_tags')) + _v788_as_list(q.get('failure_pattern_tags')), 12)

    if q.get('good_tags'):
        r['structure_tags'] = _v510_uniq(_v788_as_list(r.get('structure_tags')) + _v788_as_list(q.get('good_tags')), 14)
    if q.get('risk_tags'):
        r['risk_tags'] = _v510_uniq(_v788_as_list(r.get('risk_tags')) + _v788_as_list(q.get('risk_tags')), 14)
    # v794: failure_pattern_tags는 risk_tags에 섞어 하드차단처럼 쓰지 않고 별도 주의/복기 태그로 둔다.
    if q.get('failure_pattern_tags'):
        r['review_tags_v794'] = _v510_uniq(_v788_as_list(r.get('review_tags_v794')) + _v788_as_list(q.get('failure_pattern_tags')), 14)
    if _v510_stage(r) == 'S2':
        add_reasons: List[str] = []
        if q.get('good_tags'):
            add_reasons.append('v792:좋은구조 ' + '/'.join(_v788_as_list(q.get('good_tags'))[:2]))
        if q.get('weak_market_relative_strength'):
            add_reasons.append('v792:약장상대강도 재확인가치')
        if q.get('exec_risk_class') in ('spread_only_recheckable', 'exec_recheck'):
            add_reasons.append('v792:' + str(q.get('exec_risk_label')))
        if q.get('failure_pattern_tags'):
            add_reasons.append('v792:실패패턴주의 ' + '/'.join(_v788_as_list(q.get('failure_pattern_tags'))[:2]))
        if add_reasons:
            r['s2_recheck_reasons'] = _v510_uniq(_v788_as_list(r.get('s2_recheck_reasons')) + add_reasons, 12)
    gate = r.get('s1_promotion_gate') if isinstance(r.get('s1_promotion_gate'), dict) else {}
    gate = dict(gate)
    # v794: 구조 실패패턴은 S1 금지문으로 쓰지 않는다. 기존 공통 단타/S1 gate는 그대로 두고,
    # 선 품질·반응·실패패턴만 warning/source로 남긴다.
    if q.get('failure_pattern_tags') or q.get('line_reaction_tags_v794') or q.get('line_quality_v794'):
        gate['line_quality_v794'] = q.get('line_quality_v794')
        gate['line_reaction_tags_v794'] = q.get('line_reaction_tags_v794') or []
        gate['structure_interpretation_v794'] = q.get('structure_interpretation_v794')
        gate['structure_warning_tags_v794'] = _v510_uniq(_v788_as_list(q.get('risk_tags')) + _v788_as_list(q.get('failure_pattern_tags')), 12)
        gate['source_v794'] = 'line_quality_reaction_note_only'
        r['s1_promotion_gate'] = gate
    outcome = r.get('s2_recheck_outcome_v788') if isinstance(r.get('s2_recheck_outcome_v788'), dict) else {}
    if outcome:
        outcome = dict(outcome)
        outcome['exec_risk_class_v792'] = q.get('exec_risk_class')
        outcome['exec_risk_label_v792'] = q.get('exec_risk_label')
        outcome['structure_good_tags_v792'] = q.get('good_tags') or []
        outcome['failure_pattern_tags_v792'] = q.get('failure_pattern_tags') or []
        outcome['line_quality_v794'] = q.get('line_quality_v794')
        outcome['line_reaction_tags_v794'] = q.get('line_reaction_tags_v794') or []
        outcome['structure_interpretation_v794'] = q.get('structure_interpretation_v794')
        outcome['buy_sustain_source_v794'] = q.get('buy_sustain_source_v794')
        if str(outcome.get('state') or '') == 'exec_risk_wait' and q.get('exec_risk_label'):
            outcome['label'] = str(q.get('exec_risk_label'))
        r['s2_recheck_outcome_v788'] = outcome
    ctx = r.get('entry_context') if isinstance(r.get('entry_context'), dict) else {}
    ctx = dict(ctx)
    ctx['structure_quality_v792'] = q
    r['entry_context'] = ctx
    return r


def _v792_attach_structure_quality_spine(rows: List[Dict[str, Any]], nowv: float) -> Tuple[List[Dict[str, Any]], Dict[str, Any]]:
    out: List[Dict[str, Any]] = []
    good_top: Counter = Counter()
    risk_top: Counter = Counter()
    fail_top: Counter = Counter()
    exec_top: Counter = Counter()
    line_quality_top: Counter = Counter()
    line_reaction_top: Counter = Counter()
    interpretation_top: Counter = Counter()
    sustain_source_top: Counter = Counter()
    weak_rel = 0
    s1_fail_block = 0
    samples: List[Dict[str, Any]] = []
    for src in rows or []:
        if not isinstance(src, dict):
            continue
        r = _v792_apply_quality_to_row(src, nowv)
        q = r.get('structure_quality_v792') if isinstance(r.get('structure_quality_v792'), dict) else {}
        for x in _v788_as_list(q.get('good_tags')): good_top[x] += 1
        for x in _v788_as_list(q.get('risk_tags')): risk_top[x] += 1
        for x in _v788_as_list(q.get('failure_pattern_tags')): fail_top[x] += 1
        if q.get('exec_risk_class'): exec_top[str(q.get('exec_risk_class'))] += 1
        if q.get('line_quality_v794'): line_quality_top[str(q.get('line_quality_v794'))] += 1
        for x in _v788_as_list(q.get('line_reaction_tags_v794')): line_reaction_top[str(x)] += 1
        if q.get('structure_interpretation_v794'): interpretation_top[str(q.get('structure_interpretation_v794'))] += 1
        if q.get('buy_sustain_source_v794'): sustain_source_top[str(q.get('buy_sustain_source_v794'))] += 1
        if q.get('weak_market_relative_strength'): weak_rel += 1
        if q.get('s1_structure_block_candidate'): s1_fail_block += 1
        if len(samples) < 10 and (_v510_stage(r) in ('S1','S2')):
            samples.append({'ticker': ticker_norm(r.get('ticker') or r.get('market') or r.get('symbol')), 'stage': _v510_stage(r), 'good': _v788_as_list(q.get('good_tags'))[:3], 'warn': _v788_as_list(q.get('failure_pattern_tags'))[:3], 'exec': q.get('exec_risk_class'), 'line_quality': q.get('line_quality_v794'), 'line_reaction': _v788_as_list(q.get('line_reaction_tags_v794'))[:2], 'interpretation': q.get('structure_interpretation_v794'), 'weak_rel': q.get('weak_market_relative_strength')})
        out.append(r)
    return out, {
        'schema': 'structure_quality_summary_v794',
        'version': VERSION,
        'updated_ts': nowv,
        'updated_text': now_text(nowv),
        'good_top': dict(good_top.most_common(8)),
        'risk_top': dict(risk_top.most_common(8)),
        'failure_top': dict(fail_top.most_common(8)),
        'exec_risk_class_top': dict(exec_top.most_common(8)),
        'line_quality_top_v794': dict(line_quality_top.most_common(8)),
        'line_reaction_top_v794': dict(line_reaction_top.most_common(8)),
        'structure_interpretation_top_v794': dict(interpretation_top.most_common(8)),
        'buy_sustain_source_top_v794': dict(sustain_source_top.most_common(8)),
        'weak_market_relative_strength_count': weak_rel,
        's1_structure_block_candidate_count': s1_fail_block,
        'samples': samples,
        'policy': '조건 완화 없음. 구조태그는 S1 금지문이 아니라 선 품질/선 반응/복기 태그로 저장.',
    }


_v792_prev_reseal_common = _v732_reseal_common_uprising_promotions

def _v732_reseal_common_uprising_promotions(rows: List[Dict[str, Any]], nowv: float) -> Tuple[List[Dict[str, Any]], Dict[str, Any]]:  # type: ignore[override]
    sealed, summary = _v792_prev_reseal_common(rows, nowv)
    try:
        refined, q_summary = _v792_attach_structure_quality_spine(sealed, nowv)
        if isinstance(summary, dict):
            summary = dict(summary)
            summary['structure_quality_summary_v792'] = q_summary
        return refined, summary
    except Exception as exc:
        try: append_error(ERROR, 'v792_structure_quality_spine', exc)
        except Exception: pass
        return sealed, summary

if __name__ == "__main__":
    main()
