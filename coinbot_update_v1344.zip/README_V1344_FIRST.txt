v1344 old keep/recheck/observe live candidate grade connection. Auto-buy OFF. No exit/trigger/invalid/target/RR change.
