coinbot_update_v1461

Release: v1461_PAPER_TRIGGER_FLAG_SYNC_AUTOBUY_OFF_2026-07-11
Status: LOCAL_DONE_SERVER_CHECK

Purpose:
- Fix the remaining v1460 issue: current price crossed sealed trigger, but Paper trigger flag stayed 0.
- Sync Paper trigger occurrence/flag from the restored canonical S1 candidate row.

Not changed:
- Auto-buy OFF
- No S1 forcing / BUY_READY forcing / OPEN forcing
- No trigger formula, target formula, invalid formula, RR threshold, stale TTL, or exit-contract change
- Existing OPEN contracts are not recalculated

Verify:
Guard:
/gupgrade_bundle
/grelease_verify

Main:
/trigger_sync
/snapshot_restore
/contract_restore
/candidate_flow
/version_score
/errorlog
