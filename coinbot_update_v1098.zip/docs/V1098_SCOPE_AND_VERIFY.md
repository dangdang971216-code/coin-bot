# v1098 Feature → Strategy 품질 전달 spine 복구

## 확정 원인

v1097 서버 관측에서 Feature는 상대강도와 money-flow를 전체 row에 생성했다. 그러나 Strategy의 candidate row 생성 및 gate 직전 Feature cache overlay는 가격반응 값만 보존하고, 상대강도·money-flow·owner/source 필드를 최종 후보 row에 전달하지 않았다. 품질 gate는 최종 row만 읽기 때문에 전 후보가 `quality_source_missing:relative_strength,money_flow`로 차단됐다.

이는 threshold 문제나 Feature 계산 실패가 아니라 **canonical 전달 spine 단절**이다.

## 수정 내용

- Strategy에 Feature-owned 품질 필드 전달 helper 하나를 추가했다.
- 후보 최초 생성 시 전달한다.
- compact overlay와 gate 직전 overlay에서도 같은 helper를 사용한다.
- 기존 값이 있으면 덮어쓰지 않는다.
- Feature에 없는 값은 만들지 않으며 0으로 보정하지 않는다.
- `feature_quality_transport_v1098`에 value owner, transport owner, source, copied fields, source missing, recomputed=false를 기록한다.
- latest compact writer가 상대강도·money-flow·owner/source·transport provenance를 보존한다.
- Strategy status에 Feature→Strategy matched, 상대강도 known, money-flow known, owner rows, both-missing block, missing-axis 분포를 기록한다.
- Main과 Guard는 실제 runtime identity와 전달 통계를 함께 검증한다.

## 변경하지 않은 계약

- ALT_SWING 품질 threshold와 조합식
- actual-entry RR, target room, chase, spread, slippage 계약
- OPEN 최대 30개와 cycle 신규 최대 3개
- trigger, invalid, target, exit 계약
- Paper/Feature 공식
- 자동매수 OFF
- OPEN/CLOSED/trade_log/decision/exact/change/issue 원장 형식

## 서버 적용 순서

1. 가드봇에서 `/gupgrade_bundle`을 단독 실행한다.
2. 새 Guard가 재시작되고 나머지 컴포넌트 자동 이어적용 결과를 보낸 뒤 아래를 실행한다.

### Guard

```text
/gquality_spine_verify 120
/gworker_state
/gops_refresh
/gquality_open_audit_v1093
```

### Main

```text
/quality_rebuild_status
/quality_open_audit
/ops_focus
/errorlog
```

### Paper

```text
/pstatus
/perror
```

## v1098 전달 spine DONE 조건

- Main v2.13.1084, Guard v2.5.151, Strategy v0.999 실제 runtime/hash 일치.
- Paper v1.010 runtime이 fresh하고 startup에 고착되지 않음.
- Feature 상대강도 known > 0, money-flow known > 0.
- Strategy quality rows > 0.
- Feature→Strategy matched, 상대강도 known, money-flow known이 각각 > 0.
- 전 row가 두 품질축 source_missing인 상태가 아님.
- 현재 OPEN ≤ 30.
- 자동매수 OFF.
- 새 심각 오류 없음.

품질 pass > 0과 block < evaluated는 새 시장 cycle 표본에서 별도로 확인한다. 전달 spine가 정상이어도 시장 조건상 후보가 실제로 모두 차단될 수 있으므로, 전달 복구 DONE과 전략 epoch 성과 DONE을 같은 판정으로 섞지 않는다.

## 상태

- 로컬: PASS
- 서버: CHECK / 실제 적용·runtime·다음 cycle 검증 대기
