먼저 /gupgrade_bundle 단독 실행.
그 다음 Guard에서 /grelease_verify /gpaper_selector_audit /gpaper_ttl_audit 실행.
Main에서 /flow_map_full /version_score 확인.
정상 기대값: paper_s1_hold_cache age가 60초 이내로 갱신되고 terminal STALE 10/10이 해소된다.
