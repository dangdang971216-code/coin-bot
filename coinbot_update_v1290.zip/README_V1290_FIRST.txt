v1290 hotfix: fixes v1289 Main startup NameError COMMANDS is not defined. Apply /gupgrade_bundle first. Then /grelease_verify /gledger_v1290 and /version_score. Trading rules unchanged; auto-buy OFF.
