v1266은 전략 변경이 아니라 읽기전용 구조선 케이스 감사 버전입니다.
먼저 /gupgrade_bundle 적용 후 /gdeploy /grelease_verify /gstructure_case_audit /gledger_v1266을 실행하세요.
자동매수 OFF, trigger/invalid/target/RR/청산/OPEN cap 변경 없음.
