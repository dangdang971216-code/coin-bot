from pathlib import Path
text=Path('backga_guard_bot_v2_5_244.py').read_text(encoding='utf-8')
assert 'guard_v2.5.244_v1266_structure_case_audit_2026-07-06' in text
assert 'def collect_structure_case_audit_v1266' in text
assert 'def gstructure_case_audit_text_v1266' in text
assert 'STRUCTURE_CASE_AUDIT_STATUS_V1266' in text
assert '/gstructure_case_audit' in text
assert "'strategy_changed': False" in text
assert "'threshold_changed': False" in text
assert "'entry_changed': False" in text
assert "'exit_changed': False" in text
assert "'ledger_mutated': False" in text
assert "'auto_buy': False" in text
