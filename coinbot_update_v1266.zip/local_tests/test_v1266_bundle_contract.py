import json
from pathlib import Path
bundle=json.loads(Path('DEPLOY_BUNDLE.json').read_text(encoding='utf-8'))
assert bundle['version']=='v1266'
assert bundle['guard']=='backga_guard_bot_v2_5_244.py'
assert bundle['actual_trading_changed'] is False
assert bundle['trigger_invalid_target_rr_changed'] is False
assert bundle['candidate_formula_changed'] is False
assert bundle['auto_buy'] is False
assert 'gstructure_case_audit' in ' '.join(bundle['purpose'])
