v2232 Paper runtime status repair
- Current PID is alive; prior _STOP_EVENT/copy lines are historical.
- Reuse the existing S1 receipt thread to refresh the canonical Paper status every 8 seconds from startup.
- No new worker, command, prediction/structure/entry/exit change, ledger rewrite, or auto-buy.
