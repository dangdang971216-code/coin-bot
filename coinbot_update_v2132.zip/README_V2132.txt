코인봇 v2132 · 새 전략 코어 재작성

- 운영 편의·명령·원장·배포 뼈대 유지
- 구조: 진입위치·invalid·T1·T2만 담당
- 새 전략코어: Market/Feature/Orderflow 원자료를 직접 읽고 T1/T2/invalid 선도달 prior 생성
- Paper: 실제 진입가·spread·slippage·fee·실제 RR·비용후 EV 미리보기만 담당
- Review: T1/invalid 최초접촉, MFE/MAE, 확률구간, Brier score, 틀린 owner 판정
- 기존 v2130 종합점수는 새 예측에 재사용하지 않음
- 확률은 아직 미보정 prior이며 실제 Paper gate OFF
- 기존 진입·청산·OPEN/CLOSED/decision/exact·Shadow 보존
- 자동매수 OFF
