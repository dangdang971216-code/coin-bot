from __future__ import annotations

import math
import time
from typing import Any, Dict, Iterable, List, Optional, Tuple

VERSION = "strategy_decision_core_v2132"
BUILD_LABEL = "v2132_clean_contract_probability_architecture_2026-07-21"


def _num(value: Any) -> Optional[float]:
    try:
        if value is None or isinstance(value, bool):
            return None
        out = float(value)
        if not math.isfinite(out):
            return None
        return out
    except Exception:
        return None


def _clip(value: float, low: float, high: float) -> float:
    return max(low, min(high, float(value)))


def _sigmoid(value: float) -> float:
    value = _clip(value, -12.0, 12.0)
    return 1.0 / (1.0 + math.exp(-value))


def _line_price(obj: Any) -> Optional[float]:
    if not isinstance(obj, dict):
        return None
    for key in ("price", "rounded_price", "raw_price", "target2_price"):
        value = _num(obj.get(key))
        if value is not None and value > 0:
            return value
    return None


def _first_dict(row: Dict[str, Any], keys: Iterable[str]) -> Dict[str, Any]:
    for key in keys:
        value = row.get(key)
        if isinstance(value, dict):
            return value
    return {}


def _current_price(row: Dict[str, Any]) -> Optional[float]:
    for obj in (
        row,
        row.get("raw") if isinstance(row.get("raw"), dict) else {},
        row.get("candidate_row") if isinstance(row.get("candidate_row"), dict) else {},
        row.get("entry_context") if isinstance(row.get("entry_context"), dict) else {},
    ):
        if not isinstance(obj, dict):
            continue
        for key in (
            "current_price",
            "price",
            "trade_price",
            "close",
            "last_price",
            "entry_price",
            "expected_entry_price",
        ):
            value = _num(obj.get(key))
            if value is not None and value > 0:
                return value
    return None


def _event_key(row: Dict[str, Any]) -> str:
    for key in (
        "candidate_event_key_v2002",
        "candidate_event_key",
        "quality_event_key_v946",
        "event_id",
        "event_key",
        "decision_key",
    ):
        value = str(row.get(key) or "").strip()
        if value:
            return value
    contract = _first_dict(row, ("clean_entry_contract_v2038", "entry_owner_contract_v2038"))
    immutable = contract.get("immutable") if isinstance(contract.get("immutable"), dict) else {}
    return str(immutable.get("decision_key") or "").strip()


def _ticker(row: Dict[str, Any]) -> str:
    text = str(row.get("ticker") or row.get("symbol") or "").upper().strip()
    if text.startswith("KRW-"):
        text = text[4:]
    return text


def _score_linear(value: Optional[float], scale: float, *, inverse: bool = False) -> Optional[float]:
    if value is None:
        return None
    direction = -1.0 if inverse else 1.0
    return _clip(50.0 + float(value) * float(scale) * direction, 0.0, 100.0)


def _build_direct_evidence_v2132(row: Dict[str, Any]) -> Dict[str, Any]:
    """Read owner evidence directly; never reuse the v2130 aggregate score."""
    market = _first_dict(row, ("global_market_context_v2130", "market_context_v2130"))
    feature = _first_dict(row, ("feature_momentum_context_v2130",))
    orderflow = _first_dict(row, ("orderflow_continuation_v2130",))
    axes: Dict[str, Dict[str, Any]] = {}
    missing: List[str] = []

    def add(name: str, score: Optional[float], value: Any, owner: str, group: str) -> None:
        if score is None:
            axes[name] = {"state": "SOURCE_MISSING", "value": value, "owner": owner, "group": group}
            missing.append(name)
            return
        axes[name] = {"state": "READY", "score": round(_clip(score, 0.0, 100.0), 4), "value": value, "owner": owner, "group": group}

    add("global_market", _num(market.get("continuation_score_v2130")), market.get("state"), "market_regime_worker", "market")
    btc = str(market.get("btc_short_direction") or "").upper()
    add("btc_short_direction", {"STRONG_UP":82.0,"UP":72.0,"FLAT":50.0,"MIXED":48.0,"DOWN":28.0,"STRONG_DOWN":18.0}.get(btc), btc or None, "market_regime_worker", "market")
    ext = market.get("external_market_lead_v2130") if isinstance(market.get("external_market_lead_v2130"), dict) else {}
    ext_dir = str(ext.get("direction") or "").upper() if ext.get("state") == "READY" else ""
    add("external_market_lead", {"STRONG_UP":82.0,"UP":72.0,"FLAT":50.0,"MIXED":48.0,"DOWN":28.0,"STRONG_DOWN":18.0}.get(ext_dir), ext_dir or None, "market_regime_worker", "market")
    add("breadth_velocity", _score_linear(_num(market.get("breadth_velocity_pct_v2130")), 5.0), market.get("breadth_velocity_pct_v2130"), "market_regime_worker", "market")
    add("leader_persistence", _num(market.get("leader_persistence_pct_v2130")), market.get("leader_persistence_pct_v2130"), "market_regime_worker", "market")

    add("relative_strength_velocity", _score_linear(_num(feature.get("relative_strength_velocity_v2130")), 8.0), feature.get("relative_strength_velocity_v2130"), "feature_worker", "feature")
    add("money_flow_velocity", _score_linear(_num(feature.get("money_flow_velocity_v2130")), 1.6), feature.get("money_flow_velocity_v2130"), "feature_worker", "feature")
    add("momentum_consistency", _num(feature.get("momentum_consistency_pct_v2130")), feature.get("momentum_consistency_pct_v2130"), "feature_worker", "feature")
    add("location_hold", _num(feature.get("location_hold_score_v2130")), feature.get("location_state_v2130"), "feature_worker", "feature")

    add("orderflow_continuation", _num(orderflow.get("continuation_score_v2130")), orderflow.get("state"), "orderflow_worker", "orderflow")
    add("buy_sustain_velocity", _score_linear(_num(orderflow.get("buy_sustain_delta_v2130")), 180.0), orderflow.get("buy_sustain_delta_v2130"), "orderflow_worker", "orderflow")
    add("ask_wall_depletion", _score_linear(_num(orderflow.get("ask_wall_depletion_v2130")), 35.0), orderflow.get("ask_wall_depletion_v2130"), "orderflow_worker", "orderflow")
    add("spread_stability", _score_linear(_num(orderflow.get("spread_delta_v2130")), 220.0, inverse=True), orderflow.get("spread_delta_v2130"), "orderflow_worker", "orderflow")

    groups: Dict[str, List[float]] = {"market": [], "feature": [], "orderflow": []}
    for item in axes.values():
        if item.get("state") == "READY" and item.get("group") in groups:
            groups[str(item.get("group"))].append(float(item.get("score")))
    group_scores = {key: (sum(values) / len(values) if values else None) for key, values in groups.items()}
    weights = {"market": 0.30, "feature": 0.30, "orderflow": 0.40}
    numerator = sum(float(group_scores[k]) * weights[k] for k in group_scores if group_scores[k] is not None)
    denominator = sum(weights[k] for k in group_scores if group_scores[k] is not None)
    score = numerator / denominator if denominator > 0 else None
    ready_axes = sum(1 for item in axes.values() if item.get("state") == "READY")
    confidence = ready_axes / max(1, len(axes)) * 100.0
    ready_groups = sum(1 for value in group_scores.values() if value is not None)
    state = "READY" if score is not None and ready_groups >= 2 else "SOURCE_MISSING"
    return {
        "schema": "direct_continuation_evidence_v2132", "state": state,
        "score": round(score, 4) if score is not None else None, "confidence_pct": round(confidence, 3),
        "ready_groups": ready_groups, "group_scores": {k: (round(v,4) if v is not None else None) for k,v in group_scores.items()},
        "axes": axes, "source_missing": sorted(set(missing)),
        "legacy_v2130_aggregate_used": False, "structure_score_used": False, "auto_buy": False,
    }


def _structure_source(row: Dict[str, Any]) -> Dict[str, Any]:
    value = row.get("unified_structure_contract_v2110")
    return value if isinstance(value, dict) else {}


def build_trade_path_contract_v2132(row: Dict[str, Any], *, now_ts: Optional[float] = None) -> Dict[str, Any]:
    """Build the clean v2132 contract without changing candidate grade or trading.

    The output separates four owners:
    1) structure: entry location, invalid, T1/T2;
    2) prediction: continuation evidence only;
    3) execution: Paper actual price/cost preview;
    4) outcome: Review first-touch and horizon validation.

    Probabilities are transparent *uncalibrated priors*. They are never allowed to
    self-promote into the Paper gate. Review must prove calibration before a later,
    user-approved cutover.
    """
    ts = float(now_ts if now_ts is not None else time.time())
    structure = _structure_source(row)
    evidence = _build_direct_evidence_v2132(row)
    missing: List[str] = []

    trigger = _line_price(structure.get("trigger"))
    invalid = _line_price(structure.get("execution_invalid"))
    structural_invalid = _line_price(structure.get("structural_invalid"))
    t1 = _line_price(structure.get("target_t1"))
    t2 = _line_price(structure.get("target_t2"))
    current = _current_price(row)
    reference_entry = trigger or current

    structure_state = str(structure.get("final_state") or "RECHECK").upper()
    if not structure:
        missing.append("structure_contract")
    if reference_entry is None:
        missing.append("reference_entry")
    if invalid is None:
        missing.append("execution_invalid")
    if t1 is None:
        missing.append("target_t1")

    geometry_state = "SOURCE_MISSING"
    risk_pct = t1_room_pct = t2_room_pct = rr_t1 = rr_t2 = None
    if reference_entry and invalid and t1:
        if invalid < reference_entry < t1:
            risk_pct = (reference_entry / invalid - 1.0) * 100.0
            # Use entry-relative percentages for user-facing contract values.
            risk_pct = (reference_entry - invalid) / reference_entry * 100.0
            t1_room_pct = (t1 - reference_entry) / reference_entry * 100.0
            t2_room_pct = ((t2 - reference_entry) / reference_entry * 100.0) if t2 and t2 > t1 else None
            rr_t1 = t1_room_pct / risk_pct if risk_pct > 0 else None
            rr_t2 = t2_room_pct / risk_pct if risk_pct > 0 and t2_room_pct is not None else None
            geometry_state = "READY"
        else:
            geometry_state = "PRICE_ORDER_INVALID"

    pred_state = str(evidence.get("state") or "SOURCE_MISSING")
    evidence_score = _num(evidence.get("score"))
    confidence = _num(evidence.get("confidence_pct"))
    pred_missing = [str(x) for x in (evidence.get("source_missing") or []) if str(x)]
    if evidence_score is None:
        missing.append("continuation_evidence")
    missing.extend(pred_missing)

    prior_state = "SOURCE_MISSING"
    p_t1 = p_t2 = p_invalid = p_no_touch = None
    expected_mfe = expected_mae = expected_t1_sec = cost_free_ev = None
    if geometry_state == "READY" and evidence_score is not None and risk_pct and t1_room_pct is not None:
        # Transparent prior model. It ranks evidence and geometry but does not claim
        # empirical calibration. Review validates every forecast by score bucket.
        strength_z = (evidence_score - 50.0) / 12.0
        rr = max(0.05, float(rr_t1 or 0.05))
        min_move = max(0.05, min(risk_pct, t1_room_pct))
        touch_logit = 0.55 + 0.45 * abs(strength_z) - 0.20 * max(0.0, min_move - 1.0)
        p_touch_any = _clip(_sigmoid(touch_logit), 0.18, 0.94)
        direction_logit = 0.92 * strength_z - 0.34 * math.log(max(rr, 0.10))
        p_up_given_touch = _clip(_sigmoid(direction_logit), 0.05, 0.95)
        p_t1 = p_touch_any * p_up_given_touch
        p_invalid = p_touch_any * (1.0 - p_up_given_touch)
        p_no_touch = 1.0 - p_touch_any
        if t2_room_pct is not None and t2_room_pct > t1_room_pct:
            extension_ratio = t2_room_pct / max(t1_room_pct, 0.01)
            p_extend_given_t1 = _clip(_sigmoid(0.70 * strength_z - 0.75 * (extension_ratio - 1.0)), 0.03, 0.88)
            p_t2 = p_t1 * p_extend_given_t1
        else:
            p_t2 = 0.0
        expected_mfe = (
            p_t1 * t1_room_pct
            + float(p_t2 or 0.0) * max(0.0, float(t2_room_pct or t1_room_pct) - t1_room_pct)
            + p_no_touch * min(t1_room_pct, max(0.10, t1_room_pct * 0.35))
        )
        expected_mae = -(
            p_invalid * risk_pct
            + p_t1 * min(risk_pct, max(0.10, risk_pct * 0.30))
            + p_no_touch * min(risk_pct, max(0.10, risk_pct * 0.45))
        )
        cost_free_ev = p_t1 * t1_room_pct - p_invalid * risk_pct
        speed = max(0.15, abs(strength_z) + 0.35)
        expected_t1_sec = _clip(3600.0 * (t1_room_pct / speed), 300.0, 21600.0)
        prior_state = "UNCALIBRATED_PRIOR"

    selected_target = "NONE"
    if p_t1 is not None:
        selected_target = "T2_EXTENSION" if t2 and (p_t2 or 0.0) >= 0.30 else "T1_BASE"

    preview_state = "SOURCE_MISSING"
    reasons: List[str] = []
    if missing:
        reasons.append("SOURCE_MISSING")
    if structure_state != "EXECUTABLE":
        reasons.append("STRUCTURE_NOT_EXECUTABLE")
    if geometry_state != "READY":
        reasons.append("GEOMETRY_NOT_READY")
    if pred_state != "READY":
        reasons.append("PREDICTION_INPUT_NOT_READY")
    if prior_state == "UNCALIBRATED_PRIOR" and structure_state == "EXECUTABLE" and not missing:
        preview_state = "PAPER_PREVIEW_READY"
    elif not reasons:
        preview_state = "OBSERVE"

    diagnostics = {
        "structure_owner": "strategy_worker.structure_engine",
        "prediction_owner": "strategy_decision_core_v2132",
        "execution_owner": "paper_bot.actual_price_cost_preview",
        "outcome_owner": "review_worker.first_touch_calibration",
        "wrong_structure_signal": "price order/source/T1/invalid failure",
        "wrong_prediction_signal": "high predicted T1 probability but invalid touches first",
        "wrong_execution_signal": "contract positive at reference but actual entry/cost EV non-positive",
        "wrong_exit_signal": "T1 touched before invalid but realized CLOSED remains materially negative",
    }

    return {
        "schema": "trade_path_contract_v2132",
        "version": VERSION,
        "build": BUILD_LABEL,
        "state": preview_state,
        "ticker": _ticker(row),
        "event_key": _event_key(row),
        "evaluated_ts": ts,
        "roles": {
            "structure": "ENTRY_LOCATION_INVALID_T1_T2_ONLY",
            "prediction": "TARGET_FIRST_TOUCH_PROBABILITY_ONLY",
            "execution": "ACTUAL_ENTRY_SPREAD_SLIPPAGE_COST_ONLY",
            "outcome": "FIRST_TOUCH_MFE_MAE_CALIBRATION_ONLY",
        },
        "structure": {
            "state": structure_state,
            "geometry_state": geometry_state,
            "reference_entry": round(reference_entry, 12) if reference_entry else None,
            "current_price": round(current, 12) if current else None,
            "trigger": round(trigger, 12) if trigger else None,
            "execution_invalid": round(invalid, 12) if invalid else None,
            "structural_invalid": round(structural_invalid, 12) if structural_invalid else None,
            "target_t1": round(t1, 12) if t1 else None,
            "target_t2": round(t2, 12) if t2 else None,
            "risk_pct": round(risk_pct, 6) if risk_pct is not None else None,
            "t1_room_pct": round(t1_room_pct, 6) if t1_room_pct is not None else None,
            "t2_room_pct": round(t2_room_pct, 6) if t2_room_pct is not None else None,
            "rr_t1": round(rr_t1, 6) if rr_t1 is not None else None,
            "rr_t2": round(rr_t2, 6) if rr_t2 is not None else None,
            "selected_target_role": selected_target,
        },
        "prediction": {
            "state": prior_state,
            "input_state": pred_state,
            "evidence_score": round(evidence_score, 4) if evidence_score is not None else None,
            "confidence_pct": round(confidence, 3) if confidence is not None else None,
            "p_t1_before_invalid": round(p_t1, 6) if p_t1 is not None else None,
            "p_t2_before_invalid": round(p_t2, 6) if p_t2 is not None else None,
            "p_invalid_before_t1": round(p_invalid, 6) if p_invalid is not None else None,
            "p_no_touch_6h": round(p_no_touch, 6) if p_no_touch is not None else None,
            "expected_mfe_pct_6h": round(expected_mfe, 6) if expected_mfe is not None else None,
            "expected_mae_pct_6h": round(expected_mae, 6) if expected_mae is not None else None,
            "expected_t1_time_sec": round(expected_t1_sec, 1) if expected_t1_sec is not None else None,
            "cost_free_ev_t1_pct": round(cost_free_ev, 6) if cost_free_ev is not None else None,
            "probability_is_calibrated": False,
            "model_role": "TRANSPARENT_UNCALIBRATED_PRIOR_FOR_FORWARD_VALIDATION",
            "direct_evidence": evidence,
            "legacy_v2130_aggregate_used": False,
        },
        "source_missing": sorted(set(missing)),
        "preview_reasons": sorted(set(reasons)),
        "diagnostics": diagnostics,
        "paper_trade_gate_active": False,
        "candidate_grade_changed": False,
        "candidate_deleted": False,
        "existing_open_changed": False,
        "historical_ledger_rewritten": False,
        "activation_lock": "REVIEW_CALIBRATION_PLUS_EXACT_EXPECTANCY_PLUS_USER_APPROVAL",
        "auto_buy": False,
    }


def compact_trade_path_contract_v2132(value: Any) -> Dict[str, Any]:
    if not isinstance(value, dict):
        return {}
    structure = value.get("structure") if isinstance(value.get("structure"), dict) else {}
    prediction = value.get("prediction") if isinstance(value.get("prediction"), dict) else {}
    return {
        "schema": "trade_path_contract_v2132_compact",
        "version": value.get("version"),
        "state": value.get("state"),
        "event_key": value.get("event_key"),
        "roles": value.get("roles"),
        "structure": {k: structure.get(k) for k in (
            "state", "geometry_state", "reference_entry", "trigger", "execution_invalid",
            "structural_invalid", "target_t1", "target_t2", "risk_pct", "t1_room_pct",
            "t2_room_pct", "rr_t1", "rr_t2", "selected_target_role"
        )},
        "prediction": {k: prediction.get(k) for k in (
            "state", "input_state", "evidence_score", "confidence_pct", "p_t1_before_invalid",
            "p_t2_before_invalid", "p_invalid_before_t1", "p_no_touch_6h",
            "expected_mfe_pct_6h", "expected_mae_pct_6h", "expected_t1_time_sec",
            "cost_free_ev_t1_pct", "probability_is_calibrated", "model_role", "legacy_v2130_aggregate_used"
        )},
        "source_missing": list(value.get("source_missing") or [])[:16],
        "preview_reasons": list(value.get("preview_reasons") or [])[:12],
        "paper_trade_gate_active": False,
        "activation_lock": value.get("activation_lock"),
        "auto_buy": False,
    }


def build_paper_execution_preview_v2132(
    contract: Dict[str, Any],
    *,
    actual_entry_price: Optional[float],
    spread_pct: Optional[float] = None,
    slippage_pct: Optional[float] = None,
    fee_pct: Optional[float] = None,
) -> Dict[str, Any]:
    structure = contract.get("structure") if isinstance(contract.get("structure"), dict) else {}
    prediction = contract.get("prediction") if isinstance(contract.get("prediction"), dict) else {}
    entry = _num(actual_entry_price)
    invalid = _num(structure.get("execution_invalid"))
    t1 = _num(structure.get("target_t1"))
    t2 = _num(structure.get("target_t2"))
    spread = max(0.0, _num(spread_pct) or 0.0)
    slippage = max(0.0, _num(slippage_pct) or 0.0)
    fee = max(0.0, _num(fee_pct) or 0.0)
    roundtrip_cost = spread + slippage + fee
    state = "SOURCE_MISSING"
    rr = room = risk = net_ev = None
    reasons: List[str] = []
    if entry and invalid and t1 and invalid < entry < t1:
        risk = (entry - invalid) / entry * 100.0
        room = (t1 - entry) / entry * 100.0
        rr = room / risk if risk > 0 else None
        p_t1 = _num(prediction.get("p_t1_before_invalid"))
        p_invalid = _num(prediction.get("p_invalid_before_t1"))
        if p_t1 is not None and p_invalid is not None:
            net_ev = p_t1 * room - p_invalid * risk - roundtrip_cost
            state = "READY_UNCALIBRATED_PREVIEW"
        else:
            reasons.append("PREDICTION_PROBABILITY_MISSING")
    else:
        reasons.append("ACTUAL_PRICE_ORDER_INVALID")
    return {
        "schema": "paper_execution_preview_v2132",
        "state": state,
        "actual_entry_price": round(entry, 12) if entry else None,
        "execution_invalid": round(invalid, 12) if invalid else None,
        "target_t1": round(t1, 12) if t1 else None,
        "target_t2": round(t2, 12) if t2 else None,
        "actual_risk_pct": round(risk, 6) if risk is not None else None,
        "actual_t1_room_pct": round(room, 6) if room is not None else None,
        "actual_rr_t1": round(rr, 6) if rr is not None else None,
        "spread_pct": round(spread, 6),
        "slippage_pct": round(slippage, 6),
        "fee_pct": round(fee, 6),
        "roundtrip_cost_pct": round(roundtrip_cost, 6),
        "net_ev_t1_pct_uncalibrated": round(net_ev, 6) if net_ev is not None else None,
        "reasons": reasons,
        "paper_trade_gate_active": False,
        "actual_selection_changed": False,
        "auto_buy": False,
    }
