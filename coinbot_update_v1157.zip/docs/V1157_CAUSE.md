# V1157 확정 원인

`candidate_snapshot.s1_count`는 현재 후보파일의 S1 재고이며, `pick_stats.s1_seen`은 해당 Paper cycle이 실제 평가한 S1 수다.
기존 최종 writer는 boolean `or`로 둘을 합쳐 실제 평가 0을 재고 2로 바꿨다. 이 때문에 terminal reason이 누락된 것이 아니라, 평가하지 않은 후보가 평가된 것처럼 지도에 표시됐다.
