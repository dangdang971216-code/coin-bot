# V1157 작업 잠금

- 증상: 같은 Paper snapshot에서 S1 입력 2, terminal accounted 0, reason 없음으로 표시
- 실제 원인: `_v582_make_snapshot`이 실제 `s1_seen=0`을 유효값으로 보존하지 않고 candidate snapshot의 S1 재고 2로 대체
- owner: Paper 최종 status snapshot writer `_v582_make_snapshot`
- 삭제 경로: `pick.get('s1_seen') or snapshot['s1_count']`
- 새 본선: Paper 실제 평가수와 candidate inventory를 별도 필드로 저장
- 변경 파일: paper_bot_v1.031.py만
- 전략 영향: 없음
- 변경 금지: Gate, TTL, RR, room, spread, slippage, trigger, invalid, target, reentry, exit, OPEN 30, cycle 3
- 서버 완료 기준: 실제 평가 0이면 FLOW-11 입력 0, unclassified 0, 가짜 STAGE_STATE_FAILURE/PAPER_FUNNEL_UNCLASSIFIED 0
