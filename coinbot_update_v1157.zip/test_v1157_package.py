#!/usr/bin/env python3
from pathlib import Path
import csv, hashlib, json, zipfile, sys
z=Path(sys.argv[1])
with zipfile.ZipFile(z) as f:
    assert f.testzip() is None
    names=set(f.namelist())
    m=json.loads(f.read('DEPLOY_BUNDLE.json'))
    assert m['paper']=='paper_bot_v1.031.py'
    forbidden=('paper_bot_open.json','paper_bot_closed.jsonl','paper_trade_log.json','paper_decision_state_v926.json','ops_map_snapshot.json','paper_bot_status.json')
    assert not any(any(x.endswith(b) for b in forbidden) for x in names)
print('PASS v1157 package')
