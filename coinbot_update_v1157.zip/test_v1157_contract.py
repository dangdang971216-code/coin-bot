#!/usr/bin/env python3
from pathlib import Path
import ast, hashlib, json
from typing import Any, Dict, List, Tuple, Optional
from collections import Counter
ROOT=Path(__file__).resolve().parent
PAPER=ROOT/'paper_bot_v1.031.py'
text=PAPER.read_text(encoding='utf-8')
compile(text,str(PAPER),'exec')
module=ast.parse(text)
funcs={n.name:n for n in module.body if isinstance(n,ast.FunctionDef)}
expected=json.loads((ROOT/'tests/fixtures/V1157_TRADING_FUNCTION_AST_SHA256.json').read_text())
for name,digest in expected.items():
    got=hashlib.sha256(ast.dump(funcs[name],include_attributes=False).encode()).hexdigest()
    assert got==digest,(name,got,digest)

# Execute only the status snapshot function in a sealed namespace.
node=funcs['_v582_make_snapshot']
ns={}

def _v565_int(v,default=0):
    try:
        if v in (None,''): return int(default)
        return int(v)
    except Exception:return int(default)
ns.update({
    'List':List,'Dict':Dict,'Any':Any,'Tuple':Tuple,'Optional':Optional,
    'Counter':Counter,'candidate_is_fresh':lambda r,c:True,
    '_v582_stage_key':lambda r:r.get('stage','X'),
    'now_ts':lambda:1000.0,'iso_ts':lambda ts:'x','VERSION':'paper_bot_v1.031',
    'BUILD_LABEL':'v1157','_v565_int':_v565_int,
})
exec(compile(ast.Module(body=[node],type_ignores=[]),str(PAPER),'exec'),ns)
rows=[{'stage':'S1'},{'stage':'S1'}]
# Valid zero must stay zero; candidate inventory remains separate.
snap,pick=ns['_v582_make_snapshot'](rows,{}, {'s1_seen':0,'paper_funnel_accounted_v1102':0}, {})
assert snap['s1_count']==2
assert pick['s1_seen']==0
assert pick['candidate_snapshot_s1_count_v1157']==2
assert pick['s1_seen_snapshot_fallback_removed_v1157'] is True
# Missing evaluated count must be zero, never borrowed from candidate inventory.
snap2,pick2=ns['_v582_make_snapshot'](rows,{}, {}, {})
assert pick2['s1_seen']==0
assert pick2['candidate_snapshot_s1_count_v1157']==2
# Exact prohibited fallback removed.
assert "pick.get('s1_seen') or snapshot['s1_count']" not in text
assert "VERSION = 'paper_bot_v1.031'" in text
print('PASS v1157 contract')
