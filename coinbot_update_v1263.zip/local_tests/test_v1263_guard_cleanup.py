import importlib.util
import json
import tempfile
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
spec=importlib.util.spec_from_file_location('guard_v1263',ROOT/'backga_guard_bot_v2_5_241.py')
mod=importlib.util.module_from_spec(spec); spec.loader.exec_module(mod)
with tempfile.TemporaryDirectory() as td:
    base=Path(td); mod.BOT_DIR=base
    (base/'clean_review_worker_status.json').write_text(json.dumps({'version':'review_worker_v1.039'}))
    (base/'version_score_current_missed_state_v1263.json').write_text(json.dumps({'schema':'current_strategy_missed_state_v1263','fresh_start_v1263':True,'retired_state_imported':False,'events':{}}))
    retired=['version_score_current_missed_state_v1261.json','version_score_current_missed_state_v1262.json','version_score_review_state_v1233.json','review_append_dedup_v1013.sqlite3']
    for name in retired: (base/name).write_bytes(b'x'*100)
    core=base/'paper_bot_closed.jsonl'; core.write_text('{}\n')
    preview=mod.cleanup_retired_review_artifacts_v1263(dry_run=True)
    assert preview['state']=='DONE',preview
    assert preview['deleted']==len(retired),preview
    assert all((base/name).exists() for name in retired)
    done=mod.cleanup_retired_review_artifacts_v1263(dry_run=False)
    assert done['state']=='DONE',done
    assert done['deleted']==len(retired),done
    assert all(not (base/name).exists() for name in retired)
    assert core.exists()
print('PASS v1263 guard cleanup')
