import importlib.util
import json
import tempfile
from pathlib import Path

ROOT=Path(__file__).resolve().parents[1]

def load(name, path):
    spec=importlib.util.spec_from_file_location(name, path)
    mod=importlib.util.module_from_spec(spec)
    assert spec and spec.loader
    spec.loader.exec_module(mod)
    return mod

review=load('review_v1263', ROOT/'review_worker_v1.039.py')
main=load('main_v1263', ROOT/'coinbot_main_v2_13_1164.py')


def row(exact, frozen, trigger=100.0, invalid=98.0, target=104.0, ready=False):
    return {
        'ticker':'AAA', 'current_price':101.0,
        'trigger_occurrence_candidate_key_v1037':exact,
        'scanner_occurrence_key_v1203':'scan-occ-1',
        'candidate_pipeline_cycle_id_v1150':'cycle-x',
        'candidate_commit_id':'commit-x',
        'swing_entry_gate_v977':{
            'structure_plan':{'frozen_ts':frozen, 'trigger_price':trigger, 'invalid_price':invalid, 'target_price':target},
            'hard_block_reasons':['frozen_trigger_not_reached'],
        },
        'final_entry_reasons':['frozen_trigger_not_reached'],
        'unified_strategy_contract_v1257':{
            'schema':'unified_alt_swing_contract_v1257',
            'ready':ready,
            'primary_entry_structure':{
                'trigger_price':trigger,'invalid_price':invalid,'base_target_price':target,
                'structure_contract_hash':f'hash-{int(frozen)}',
            },
            'v1211_structural_support':{},
            'entry_quality_support':{'confirmed':True},
        },
    }

with tempfile.TemporaryDirectory() as td:
    base=Path(td)
    # A retired v1262 state must never be imported.
    (base/'version_score_current_missed_state_v1262.json').write_text(json.dumps({'schema':'current_strategy_missed_state_v1262','events':{'bad':{'ticker':'OLD'}}}))
    now=2_000_000_000.0
    state=review._v1263_load_state(base, now)
    assert state['fresh_start_v1263'] is True
    assert state['retired_state_imported'] is False
    assert state['events']=={}

    # Exact key and floating line changes inside one frozen plan stay one event.
    state=review._v1263_update_state(state,[row('exact-1',1111.0,100,98,104)],now)
    state=review._v1263_update_state(state,[row('exact-2',1111.0,100.2,98.1,104.2)],now+30)
    assert len(state['events'])==1, len(state['events'])
    event=next(iter(state['events'].values()))
    assert event['observation_count']==2
    assert event['exact_candidate_key']=='exact-1'
    assert event['exact_candidate_key_last']=='exact-2'

    # A genuinely new frozen plan is a new event.
    state=review._v1263_update_state(state,[row('exact-3',2222.0)],now+60)
    assert len(state['events'])==2

    # Horizon maturation uses the original created time.
    first=next(iter(state['events'].values()))
    first['created_ts']=now-7*3600
    review._v1261_update_event_path(first,105.0,now)
    assert first['return_6h_pct'] is not None

    compact=review._v1263_compact_state(state,now)
    review._v1263_persist_state(base,compact,now,force=True)
    saved=json.loads((base/'version_score_current_missed_state_v1263.json').read_text())
    assert saved['schema']=='current_strategy_missed_state_v1263'
    assert saved['retired_state_imported'] is False
    assert len(saved['events'])==2

# Current-first score renderer with blockers and missed outcomes.
perf={
    'snapshot_id':'perf-test','source_owner':'paper_bot_single_canonical_performance_writer',
    'performance_epoch_v1045':{'windows':{
        'today':{'count':10,'wins':6,'losses':4,'sum_pct':2.5,'avg_pct':0.25},
        'all':{'count':20,'wins':11,'losses':9,'sum_pct':1.0,'avg_pct':0.05},
    }},
    'book_performance_v1189':{'open_count':10,'valid_pnl_rows':10,'wins':6,'losses':4,'flats':0,'current_total':1.2,'current_avg':0.12},
    'version_score_v1262':{'owner':'paper_bot_single_canonical_performance_writer','current_strategy':{'closed_count':0,'open_count':0,'closed_windows':{'all':{}}},'v1211_actual':{'closed_count':0},'unclassified':{'closed_count':1578}},
    'counts':{'raw_ledger_rows':100,'exact_unique_closed':80,'duplicate_closed_rows':0,'missing_decision_key':0,'decision_not_closed_or_missing':0,'bad_json_rows':0},
}
candidate={'candidate':{'total':463,'s1':18,'s2':101,'s3':344},'reason_accounting':{'hard_reason_top':{'frozen_trigger_not_reached':438,'dynamic_structure_source_missing':331}}}
ops={'paper_funnel':{'s1_seen':7,'selected':2,'opened':2,'actual_integrity_exclusions':{'관찰전용':3,'동일종목중복':1},'audit_only_findings':{'WS':7}}}
review_summary={'current_missed_v1263':{'state':'NORMAL','active_missed':50,'source_observation_total':500,'state_age_sec':1000,'completed_6h':0,'positive_max_count':20,'gain_1_2_count':5,'gain_3_count':1,'recovered_to_ready':2,'semantic_key_missing_skipped':0,'exact_key_missing_skipped':0,'reason_counts':{'trigger_not_reached':40},'first_touch_counts':{'NONE':50},'top':[]}}
main._performance_snapshot=lambda: perf
main._candidate_snapshot=lambda: candidate
main._ops_snapshot=lambda: ops
main._version_score_review_snapshot=lambda: review_summary
main.file_age=lambda _p: 1.0
text=main.render_version_score()
for token in ('지금 운영 성과','많이 막힌 이유','Paper에서 실제로 못 들어간 이유','놓친 후보','trigger 미도달 438개'):
    assert token in text, token
print('PASS v1263 review/storage/score')
