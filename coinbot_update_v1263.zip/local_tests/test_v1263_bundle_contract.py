from pathlib import Path
import json

base = Path(__file__).resolve().parents[1]
bundle = json.loads((base / 'DEPLOY_BUNDLE.json').read_text(encoding='utf-8'))
assert bundle['release'] == 'v1263'
assert bundle['server_status'] == 'CHECK_PENDING_APPLY'
assert bundle['auto_buy'] is False
assert bundle['runtime_files']['main'] == 'coinbot_main_v2_13_1164.py'
assert bundle['runtime_files']['paper'] == 'paper_bot_v1.077.py'
assert bundle['runtime_files']['review'] == 'review_worker_v1.039.py'
assert bundle['runtime_files']['strategy'] == 'strategy_worker_v1.062.py'
assert bundle['runtime_files']['guard'] == 'backga_guard_bot_v2_5_241.py'
for rel in bundle['runtime_files'].values():
    assert (base / rel).is_file(), rel
for rel in bundle['support_files']:
    assert (base / rel).is_file(), rel
for forbidden in ('paper_bot_open.json','paper_bot_closed.jsonl','paper_trade_log.jsonl','paper_decision_state.jsonl','change_verify_ledger.jsonl','issue_ledger.jsonl'):
    assert not (base / forbidden).exists(), forbidden
main = (base / bundle['runtime_files']['main']).read_text(encoding='utf-8')
review = (base / bundle['runtime_files']['review']).read_text(encoding='utf-8')
guard = (base / bundle['runtime_files']['guard']).read_text(encoding='utf-8')
assert '수익형 v2.13.1164' in main
assert '지금 성과와 막힌 이유' in main
assert 'review_worker_v1.039' in review
assert "V1263_STATE_FILE = 'version_score_current_missed_state_v1263.json'" in review
assert 'V1263_STATE_WRITE_INTERVAL_SEC = 60.0' in review
assert 'cleanup_retired_review_artifacts_v1263' in guard
assert 'version_score_current_missed_state_v1263.json' in guard
assert 'paper_bot_closed.jsonl' not in str(bundle.get('retired_review_cleanup'))
print('PASS v1263 bundle contract')
