# v1079 Strategy·Paper·Review 통합 병목 수술

## 상태
- 로컬: PASS
- 서버: CHECK_SERVER_UNVERIFIED
- 전략모드: ALT_SWING
- 자동매수: OFF

## 코드에서 확정한 원인

### 1. Strategy 후보 압축
`candidate_writer_compact_single_pass`가 선택 필드마다 `{key:value}`를 `json.dumps`하여 정확한 byte 크기를 다시 계산했다. 461개 후보에서 수십만 번 작은 JSON 직렬화가 반복됐다.

수정:
- 문자열·숫자·bool·None은 기존 JSON과 같은 정확한 byte 수를 직접 계산한다.
- list/dict 같은 중첩 값만 기존 JSON 직렬화를 유지한다.
- 같은 row 안에서 동일한 context 객체를 반복 축약하지 않는다.
- 최종 후보 내용·ceiling 판정·atomic writer는 유지한다.

### 2. Paper 후보 진입 확인
`candidate_select`가 Bithumb `ALL_KRW`를 Paper에서 다시 호출했다. Scanner가 같은 endpoint를 주기적으로 읽고 Orderflow가 `rest_price/rest_age_sec`로 이미 배포하고 있어 최신가격 owner가 중복됐다.

수정:
- 4초 이내의 Orderflow scanner REST 값을 entry confirmation에 사용한다.
- 누락·오래된 값은 기존 Paper Bithumb `ALL_KRW` REST로 fallback한다.
- trigger 수치·도달 비교식·exit 가격 owner는 변경하지 않는다.
- CLOSED recent identity tail은 파일 signature가 같으면 재사용한다.

주의:
- entry confirmation의 데이터 owner는 Paper 독립 REST에서 Orderflow가 배포한 동일 upstream scanner REST 우선으로 정리된다.
- 임계값은 변경되지 않지만 실제 확인 source가 바뀌는 시스템 owner 수정이므로 서버 검수에서 source·freshness·fallback을 반드시 확인한다.

### 3. Review 성과 파생 인덱스
300초 성과분석 때 Review가 자신이 단독으로 쓰는 structure/cost/C-shadow 인덱스 JSON 전체를 다시 읽고 해석한 뒤 작은 JSONL delta를 추가했다.

수정:
- 최초 1회만 persisted index를 읽는다.
- 같은 Review process에서는 parsed canonical checkpoint를 재사용한다.
- ledger inode/size/mtime 기반 rebuild·truncate·replace 판정과 JSON checkpoint write는 유지한다.
- 파생 분석 결과는 이전 코드와 동일하다.

## 수정하지 않은 경로
Paper `performance_write`는 새 CLOSED·decision membership·시간창 경계에서 canonical exact snapshot을 다시 봉인하는 단일 writer다. 단순 중복으로 확정되지 않아 v1079에서는 건드리지 않는다.

## 검수 계약
- Strategy/Paper/Review runtime version과 active-target hash
- Strategy 후보 writer commit 증가
- 후보 parse 오류 0
- S1 decision key·trigger·invalid·target 누락 0
- exact duplicate/key_missing/unlinked = 0/0/0
- Paper local owner cache 오류 0, stale/missing REST fallback 유지
- Review structure/cost/C-shadow memory reuse 실제 발생
- 자동매수 OFF
- 전략수치·청산계약·핵심 원장 변경 0
