from pathlib import Path
import ast
import json
import zipfile

ROOT = Path(__file__).resolve().parents[1]


def test_python_sources_parse():
    for name in ("policy_competition_worker_v0.1.py", "coinbot_main_v2_13_1156.py", "backga_guard_bot_v2_5_230.py"):
        ast.parse((ROOT / name).read_text(encoding="utf-8"))


def test_main_command_and_read_only_text():
    text = (ROOT / "coinbot_main_v2_13_1156.py").read_text()
    assert '"policy_matchup": render_policy_matchup' in text
    assert 'POLICY_COMPETITION_PATH' in text
    assert '자동매수 OFF' in text


def test_guard_worker_contract():
    text = (ROOT / "backga_guard_bot_v2_5_230.py").read_text()
    assert '"policy_competition"' in text
    assert 'tradingbot-policy-competition-worker' in text
    assert '/gpolicy_matchup' in text


def test_deploy_contract():
    manifest = json.loads((ROOT / "DEPLOY_BUNDLE.json").read_text())
    assert manifest["version"] == "v1251"
    assert manifest["workers"]["policy_competition"] == "policy_competition_worker_v0.1.py"
    assert manifest["actual_trading_changed"] is False
    assert manifest["auto_buy"] is False
