import importlib.util, json, os, tempfile, time, shutil
from pathlib import Path
ROOT=Path(__file__).resolve().parent

def load(name,path):
    spec=importlib.util.spec_from_file_location(name,path)
    mod=importlib.util.module_from_spec(spec)
    spec.loader.exec_module(mod)
    return mod

# Main must ignore a historical raw error when current_error_active is false.
with tempfile.TemporaryDirectory() as td:
    td=Path(td)
    module_dir=td/'module'
    module_dir.mkdir()
    main_copy=module_dir/'coinbot_main_v2_13_1111.py'
    shutil.copy2(ROOT/'coinbot_main_v2_13_1111.py',main_copy)
    main=load('main_v1144',main_copy)
    board={
        'updated_ts':time.time(),
        'baseline_identity':{'baseline_id':'B1','candidate_reference_state':'COLLECTING','candidate_reference_unique_n':0},
        'contract_identity':{'state':'SAME_SEMANTIC_RELEASE_CHANGED','semantic_state':'SAME','release_identity_changed':True},
        'candidate_quality':{'all_rows':460,'gate_pass_rows':3,'gate_pass_metrics':{},'baseline_comparison':{}},
        'final_judgement':{'state':'CHECK_SAMPLE','reasons':['candidate_reference_0_of_30'],'confirmed_flags':[],'critical_source_missing':[]},
        'section_completeness':{'total':13,'all_sections_present':True,'normal_count':3,'collecting_count':7,'source_missing_count':2,'source_gap_count':7,'items':[]},
        'readiness':{},'source_gaps':[],'preliminary_signals':[],
        'invariants':{'gate_changed':False,'rank_changed':False,'trigger_invalid_target_changed':False,'exit_changed':False,'open_limit_changed':False,'auto_buy':False},
    }
    main.CANDIDATE_STANDARD_STATUS_V1141=module_dir/'candidate_standard_status_v1141.json'
    main.CANDIDATE_STANDARD_STATUS_V1141.write_text(json.dumps(board))
    (module_dir/'clean_review_worker_status.json').write_text(json.dumps({
        'phase':'idle','state':'running','error':'NameError: historical only',
        'current_error_active_v1144':False,'current_error_v1144':None,'last_success_ts':time.time(),
    }))
    main.BASE_DIR=module_dir
    rendered=main.render_candidate_standard_text()
    assert '현재판정 사용 금지' not in rendered
    assert 'CHECK_SAMPLE' in rendered

print(json.dumps({'ok':True,'main_historical_error_ignored':True},ensure_ascii=False))
