# v1144 scope and verification

## Proven root cause

1. Review `write_status` copied the previous status object and only updated new fields. A resolved legacy `error` key therefore survived successful `running/idle` cycles.
2. Candidate Standard required semantic contract digest, full Strategy source SHA, and Strategy version all to match. Instrumentation/status-only releases therefore became false `SYSTEM_REGRESSION` events despite an unchanged semantic contract digest.
3. Guard first proved Risk and Performance as `EVENT_DRIVEN_IDLE`, but later re-promoted raw source/output mtime deltas as edge CHECKs.

## Removed paths

- Historical Review error as current runtime error.
- Full-file source SHA/version as the owner of strategy semantic regression.
- Raw mtime edge verdict overriding canonical semantic owner proof.

## New single truth

- Review error state: `current_error_active_v1144/current_error_v1144`; old errors remain only in `last_error_*`.
- Candidate strategy regression: semantic contract digest only. Version/source SHA remain audit evidence.
- Event-driven freshness: canonical owner heartbeat/signature owns final state; raw mtime delta is reference-only.

## Unchanged

Strategy and Paper sources, Gate, rank, TTL, trigger, invalid, target, RR, entry/exit contracts, OPEN 30, cycle 3, ledgers and auto-buy OFF.
