import importlib.util, json, tempfile, time, os
from pathlib import Path

ROOT=Path(__file__).resolve().parent

def load(name,path):
    spec=importlib.util.spec_from_file_location(name,path)
    mod=importlib.util.module_from_spec(spec)
    spec.loader.exec_module(mod)
    return mod

review=load('review_v1144',ROOT/'review_worker_v1.011.py')
assert '_V1141_PREV_RUN_ONCE' not in (ROOT/'review_worker_v1.011.py').read_text()
# Semantic contract stays same even when release version/source hash changes.
ident=review._cs_contract_identity_v1144(
    {'baseline_id':'B1','strategy_contract_digest':'D1','strategy_version':'old','strategy_source_sha256':'oldhash'},
    {'contract_digest':'D1','version':'new','strategy_source_sha256':'newhash'},
)
assert ident['semantic_match'] is True
assert ident['release_identity_changed'] is True
assert ident['state']=='SAME_SEMANTIC_RELEASE_CHANGED'
ident_bad=review._cs_contract_identity_v1144(
    {'baseline_id':'B1','strategy_contract_digest':'D1','strategy_version':'old','strategy_source_sha256':'oldhash'},
    {'contract_digest':'D2','version':'new','strategy_source_sha256':'newhash'},
)
assert ident_bad['semantic_match'] is False
assert ident_bad['state']=='CHANGED_OR_MISSING'

# Review current error lifecycle: history preserved, current error cleared only on success.
with tempfile.TemporaryDirectory() as td:
    review.STATUS=Path(td)/'review_status.json'
    review.write_status('error',phase='idle_after_error',error='NameError: old wrapper')
    first=json.loads(review.STATUS.read_text())
    assert first['current_error_active_v1144'] is True
    assert first['current_error_v1144']=='NameError: old wrapper'
    review.write_status('running',phase='idle',last_success_ts=time.time(),_clear_current_error_v1144=True)
    second=json.loads(review.STATUS.read_text())
    assert second['current_error_active_v1144'] is False
    assert second['current_error_v1144'] is None
    assert 'error' not in second
    assert second['last_error_text_v1144']=='NameError: old wrapper'
    review.write_status('running',phase='idle',heartbeat=True)
    third=json.loads(review.STATUS.read_text())
    assert third['current_error_active_v1144'] is False
    assert 'error' not in third

# Guard semantic event-driven normalization is single-owner truth.
os.environ.setdefault('GUARD_BOT_TOKEN','dummy-token')
os.environ.setdefault('GUARD_CHAT_ID','1')
guard=load('guard_v1144',ROOT/'backga_guard_bot_v2_5_185.py')
lineage=[{'from':'risk','to':'strategy','artifact':{'status':'CHECK','event_driven_contract':{'state':'CHECK_OUTPUT_NOT_REFRESHED_AFTER_SOURCE_CHANGE','source_changed_after_output':True}}},
         {'from':'performance','to':'main','artifact':{'status':'NORMAL','event_driven_contract':{'state':'CHECK_OWNER_HEARTBEAT_STALE'}}}]
normalized=guard._ops_normalize_semantic_lineage_v1144(
    lineage,
    {'diagnosis_state':'PROVEN_EVENT_DRIVEN_IDLE'},
    {'diagnosis_state':'PROVEN_EVENT_DRIVEN_IDLE'},
)
for row in normalized:
    art=row['artifact']
    assert art['status']=='NORMAL'
    assert art['semantic_status']=='EVENT_DRIVEN_IDLE'
    assert art['event_driven_contract']['state']=='PROVEN_EVENT_DRIVEN_IDLE'


# Guard candidate-standard mechanism accepts semantic SAME while release identity differs.
with tempfile.TemporaryDirectory() as td:
    td=Path(td)
    guard.BOT_DIR=td
    (td/'candidate_standard_status_v1141.json').write_text(json.dumps({
        'contract_identity':{'state':'SAME_SEMANTIC_RELEASE_CHANGED','semantic_state':'SAME','semantic_match':True},
        'baseline_identity':{'baseline_id':'B1','candidate_reference_state':'COLLECTING','candidate_reference_unique_n':0},
        'final_judgement':{'state':'CHECK_SAMPLE','reasons':['candidate_reference_0_of_30'],'confirmed_flags':[],'critical_source_missing':[],'fresh_closed_count':4},
        'candidate_quality':{'all_rows':460,'gate_pass_rows':3},
        'section_completeness':{'total':13,'all_sections_present':True,'normal_count':3,'collecting_count':7,'source_missing_count':2,'source_gap_count':7},
        'readiness':{},'paper_contract':{'state':'NORMAL'},'source_gaps':[],
    }))
    (td/'clean_candidate_standard_contract_v1141.json').write_text(json.dumps({'contract_digest':'D1'}))
    (td/'candidate_standard_baseline_state_v1141.json').write_text(json.dumps({'active_baseline':{'baseline_id':'B1'}}))
    (td/'candidate_standard_reference_state_v1142.json').write_text(json.dumps({'reference_state':'COLLECTING','unique_sample_count':0}))
    out=guard._ops_candidate_standard_contract_v1141(time.time())
    assert out['state']=='NORMAL', out
    assert out['semantic_state']=='SAME'

print(json.dumps({'ok':True,'semantic_identity':ident['state'],'review_error_cleared':True,'semantic_lineage_normalized':True,'guard_semantic_mechanism':True},ensure_ascii=False))
