#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Coinbot Review worker v1.012 / v1181.

Single owner for observation, candidate-standard, and read-only trade review.
The worker never changes Strategy candidate decisions, Paper OPEN/CLOSED, or
trading rules. It consumes the immutable Strategy generation committed before
handoff and the canonical Paper performance snapshot.
"""
from __future__ import annotations

import argparse
import atexit
import fcntl
import os
import signal
import sys
import time
import traceback
from pathlib import Path
from typing import Any, Dict, Optional

from canonical_spine_v1181 import (
    AUTO_BUY,
    SPINE_SCHEMA,
    STRATEGY_MODE,
    SpinePaths,
    append_jsonl,
    atomic_write_json,
    build_candidate_standard,
    build_review_snapshot,
    digest_obj,
    now_text,
    now_ts,
    read_json,
)

VERSION = "review_worker_v1.012"
BUILD_LABEL = "v1181_review_single_owner_candidate_standard_2026-07-02"
DEFAULT_INTERVAL_SEC = 3.0
HEARTBEAT_SEC = 5.0
_STOP = False
_LOCK_HANDLE: Optional[Any] = None


def base_dir() -> Path:
    override = os.getenv("COINBOT_BASE_DIR", "").strip()
    return Path(override).expanduser().resolve() if override else Path(__file__).resolve().parent


def status_path(base: Path) -> Path:
    return base / "clean_review_worker_status.json"


def error_path(base: Path) -> Path:
    return base / "clean_review_worker_error.log"


def pid_path(base: Path) -> Path:
    return base / "review_worker.pid"


def lock_path(base: Path) -> Path:
    return base / ".review_worker_v1181.lock"


def log_error(base: Path, where: str, exc: BaseException) -> None:
    path = error_path(base)
    path.parent.mkdir(parents=True, exist_ok=True)
    message = (
        f"[{now_text()}] {where}: {type(exc).__name__}: {exc}\n"
        f"{traceback.format_exc()[-4000:]}\n"
    )
    with path.open("a", encoding="utf-8") as handle:
        handle.write(message)


def write_status(base: Path, state: str, **extra: Any) -> Dict[str, Any]:
    payload: Dict[str, Any] = {
        "schema": "review_worker_status_v1181",
        "version": VERSION,
        "build": BUILD_LABEL,
        "running": state not in {"STOPPED", "ERROR"},
        "state": state,
        "phase": extra.pop("phase", state.lower()),
        "updated_ts": now_ts(),
        "updated_text": now_text(),
        "pid": os.getpid(),
        "strategy_mode": STRATEGY_MODE,
        "auto_buy": False,
        "owner": "review_worker_single_candidate_standard_owner_v1181",
        "legacy_dedup_index_retired": True,
        "legacy_trace_rebuild_retired": True,
        "live_ledger_write": False,
    }
    payload.update(extra)
    atomic_write_json(status_path(base), payload)
    return payload


def acquire_singleton(base: Path) -> None:
    global _LOCK_HANDLE
    path = lock_path(base)
    path.parent.mkdir(parents=True, exist_ok=True)
    handle = path.open("a+", encoding="utf-8")
    try:
        fcntl.flock(handle.fileno(), fcntl.LOCK_EX | fcntl.LOCK_NB)
    except BlockingIOError as exc:
        raise RuntimeError("review_worker v1181 already running") from exc
    handle.seek(0)
    handle.truncate(0)
    handle.write(str(os.getpid()))
    handle.flush()
    _LOCK_HANDLE = handle
    pid_path(base).write_text(str(os.getpid()), encoding="utf-8")


def release_singleton(base: Path) -> None:
    global _LOCK_HANDLE
    try:
        if _LOCK_HANDLE is not None:
            fcntl.flock(_LOCK_HANDLE.fileno(), fcntl.LOCK_UN)
            _LOCK_HANDLE.close()
    except OSError:
        pass
    _LOCK_HANDLE = None
    try:
        pid_path(base).unlink(missing_ok=True)
    except OSError:
        pass


def signal_handler(signum: int, _frame: Any) -> None:
    global _STOP
    _STOP = True


def process_once(base: Path, force: bool = False) -> Dict[str, Any]:
    paths = SpinePaths(base)
    request = read_json(paths.review_request, {}) or {}
    prior = read_json(paths.review_snapshot, {}) or {}
    request_identity = (
        str(request.get("candidate_commit_id") or request.get("candidate_commit_id_v1150") or ""),
        str(request.get("pipeline_cycle_id") or request.get("candidate_pipeline_cycle_id_v1150") or ""),
    )
    prior_source = prior.get("source") if isinstance(prior.get("source"), dict) else {}
    prior_identity = (
        str(prior_source.get("candidate_commit_id") or ""),
        str(prior_source.get("pipeline_cycle_id") or ""),
    )
    if not force and request_identity == prior_identity and prior_identity != ("", ""):
        return {
            "processed": False,
            "reason": "same_committed_generation",
            "snapshot_id": prior.get("snapshot_id"),
            "candidate_rows": (prior.get("candidate") or {}).get("total") if isinstance(prior.get("candidate"), dict) else None,
        }

    started = time.monotonic()
    write_status(
        base,
        "RUNNING",
        phase="candidate_standard_build",
        current_pipeline_cycle_id=request_identity[1] or None,
        current_candidate_commit_id=request_identity[0] or None,
    )
    snapshot = build_review_snapshot(base, request=request)
    standard = build_candidate_standard(snapshot)
    atomic_write_json(paths.review_snapshot, snapshot)
    atomic_write_json(paths.candidate_standard, standard)

    event = {
        "schema": "review_generation_event_v1181",
        "event": "REVIEW_GENERATION_COMMITTED",
        "created_ts": now_ts(),
        "created_text": now_text(),
        "pipeline_cycle_id": (snapshot.get("source") or {}).get("pipeline_cycle_id"),
        "candidate_commit_id": (snapshot.get("source") or {}).get("candidate_commit_id"),
        "review_snapshot_id": snapshot.get("snapshot_id"),
        "candidate_standard_state": standard.get("state"),
        "candidate_rows": (snapshot.get("candidate") or {}).get("total"),
        "live_ledger_write": False,
        "auto_buy": False,
    }
    append_jsonl(base / "review_generation_events_v1181.jsonl", event)
    elapsed = max(0.0, time.monotonic() - started)
    write_status(
        base,
        "NORMAL",
        phase="idle",
        last_success_ts=now_ts(),
        last_cycle_sec=round(elapsed, 6),
        last_pipeline_cycle_id=event["pipeline_cycle_id"],
        last_candidate_commit_id=event["candidate_commit_id"],
        last_review_snapshot_id=event["review_snapshot_id"],
        candidate_standard_state=event["candidate_standard_state"],
        candidate_rows=event["candidate_rows"],
        source_state=(snapshot.get("source") or {}).get("state"),
        snapshot_digest=digest_obj(snapshot),
    )
    return {
        "processed": True,
        "elapsed_sec": elapsed,
        "snapshot": snapshot,
        "candidate_standard": standard,
    }


def run_loop(base: Path, interval_sec: float) -> int:
    acquire_singleton(base)
    atexit.register(release_singleton, base)
    signal.signal(signal.SIGTERM, signal_handler)
    signal.signal(signal.SIGINT, signal_handler)
    write_status(base, "STARTING", phase="boot")
    last_heartbeat = 0.0
    consecutive_errors = 0
    while not _STOP:
        try:
            result = process_once(base)
            consecutive_errors = 0
            now = now_ts()
            if not result.get("processed") and now - last_heartbeat >= HEARTBEAT_SEC:
                prior = read_json(SpinePaths(base).review_snapshot, {}) or {}
                source = prior.get("source") if isinstance(prior.get("source"), dict) else {}
                candidate = prior.get("candidate") if isinstance(prior.get("candidate"), dict) else {}
                write_status(
                    base,
                    "NORMAL" if prior else "COLLECTING",
                    phase="idle",
                    last_review_snapshot_id=prior.get("snapshot_id"),
                    last_pipeline_cycle_id=source.get("pipeline_cycle_id"),
                    last_candidate_commit_id=source.get("candidate_commit_id"),
                    candidate_rows=candidate.get("total"),
                    heartbeat=True,
                )
                last_heartbeat = now
        except Exception as exc:  # fail visible; no stale fallback
            consecutive_errors += 1
            log_error(base, "review_loop", exc)
            write_status(
                base,
                "ERROR",
                phase="error",
                last_error=f"{type(exc).__name__}: {exc}",
                consecutive_errors=consecutive_errors,
            )
        slept = 0.0
        while slept < interval_sec and not _STOP:
            step = min(0.2, interval_sec - slept)
            time.sleep(step)
            slept += step
    write_status(base, "STOPPED", phase="shutdown")
    return 0


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--base-dir", default="")
    parser.add_argument("--interval", type=float, default=DEFAULT_INTERVAL_SEC)
    parser.add_argument("--once", action="store_true")
    parser.add_argument("--force", action="store_true")
    args = parser.parse_args()
    base = Path(args.base_dir).expanduser().resolve() if args.base_dir else base_dir()
    if args.once:
        result = process_once(base, force=args.force)
        print(result.get("candidate_standard") or result)
        return 0
    return run_loop(base, max(0.5, args.interval))


if __name__ == "__main__":
    raise SystemExit(main())
