#!/usr/bin/env python3
from __future__ import annotations

import ast
import importlib.util
import json
import os
import subprocess
import sys
import tempfile
import time
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
SRC = (ROOT / "source") if (ROOT / "source").exists() else ROOT


def load(name: str, path: Path):
    spec = importlib.util.spec_from_file_location(name, str(path))
    assert spec and spec.loader
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


def write(path: Path, obj) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(obj, ensure_ascii=False, indent=2), encoding="utf-8")


def test_static_contracts() -> None:
    main_path = SRC / "coinbot_main_v2_13_1127.py"
    review_path = SRC / "review_worker_v1.012.py"
    strategy_path = SRC / "strategy_worker_v1.036.py"
    paper_path = SRC / "paper_bot_v1.045.py"
    guard_path = SRC / "backga_guard_bot_v2_5_195.py"

    main_src = main_path.read_text(encoding="utf-8")
    review_src = review_path.read_text(encoding="utf-8")
    strategy_src = strategy_path.read_text(encoding="utf-8")
    paper_src = paper_path.read_text(encoding="utf-8")
    guard_src = guard_path.read_text(encoding="utf-8")

    assert len(main_src.splitlines()) < 1000
    assert "paper_bot_closed.jsonl" not in main_src
    assert "candidate_recalculation\": False" in main_src
    assert "performance_recalculation\": False" in main_src
    assert "dedup_index_build" not in review_src
    assert "legacy_trace_rebuild_retired" in review_src
    assert "run_cycle = run_cycle__v1181_fast_core" in paper_src
    assert "paper_bot_v1.045" in paper_src
    assert "_v1181_postprocess_loop" in paper_src
    assert "build_trace(latest_rows" not in paper_src[paper_src.index("def run_cycle__v1181_fast_core"):paper_src.index("def _v1181_write_postprocess_status")]
    assert "legacy_ops_map_collector_active" in guard_src
    assert "guard_v2.5.195_canonical_ops_spine_v1181" in guard_src

    tree = ast.parse(strategy_src)
    publish = next(node for node in tree.body if isinstance(node, ast.FunctionDef) and node.name == "_v510_publish")
    body = ast.get_source_segment(strategy_src, publish) or ""
    for retired in (
        "attach_structure_lab(rows",
        "attach_hot_watch_timing(rows",
        "observe_good_s2_lifecycle(rows",
        "_v1180_enrich_observation_rows(rows",
    ):
        assert retired not in body, retired
    assert "review_observation_request_v1181.json" in body
    assert "post_handoff_observation_owner_v1181='review_worker'" in body
    assert "strategy_worker_v1.036" in strategy_src


def test_paper_batch_and_fast_core() -> None:
    paper = load("paper_v1181_contract", SRC / "paper_bot_v1.045.py")
    assert paper.VERSION == "paper_bot_v1.045", paper.VERSION

    stores = []
    decisions = []
    events = []
    paper.persist_open_positions = lambda obj: stores.append(dict(obj)) or True
    paper._v926_load_decision_state = lambda: {"records": {}}
    paper._v926_save_decision_state = lambda obj: decisions.append(obj) or True
    paper._v938_quality_evidence_from_row = lambda row: {}
    paper._v1153_paper_event_once = lambda *a, **kw: 123.0
    paper._v1153_set_path_ts = lambda *a, **kw: None
    paper.append_jsonl = lambda *a, **kw: events.append((a, kw))
    paper._exact_commit_enter_v994 = lambda: None
    paper._exact_commit_exit_v994 = lambda: None
    paper._v926_decision_key_from_row = lambda row: row.get("paper_decision_key_v926")
    paper.normalize_ticker = lambda x: str(x or "")
    paper.now_ts = lambda: 1000.0
    paper.iso_ts = lambda x=None: "T"
    paper.fnum = lambda *args, **kwargs: next((float(x) for x in args if x not in (None, "")), kwargs.get("default", 0.0))
    open_pos = {"old": {"pos_id": "old", "ticker": "OLD", "paper_decision_key_v926": "d-old"}}
    prepared = []
    for idx in range(3):
        pid = f"p{idx}"
        prepared.append((pid, {"pos_id": pid, "ticker": f"T{idx}", "paper_decision_key_v926": f"d{idx}", "opened_at": 900 + idx}, {"ticker": f"T{idx}"}))
    opened, traces = paper._v1180_commit_open_batch(open_pos, prepared)
    assert len(opened) == 3 and len(traces) == 3
    assert len(stores) == 1
    assert len(decisions) == 1
    assert len(events) == 3

    # Fast execution core must call one batch owner and queue postprocessing.
    batch_calls = []
    status_calls = []
    queue_calls = []
    phases = []
    clock = iter([2000.0, 2000.4, 2000.5, 2000.6])
    paper.now_ts = lambda: next(clock, 2000.6)
    paper._STOP = False
    paper._RUNTIME_INSTANCE_ID = "runtime-test"
    paper._set_runtime_phase_v994 = lambda phase, *args: phases.append(phase)
    paper.reconcile_decision_state_at_startup = lambda force=False: {"completed": True}
    paper.load_control = lambda: {"running": True, "loop_seconds": 2, "write_score_cache": True}
    core_open = {}
    paper.load_open = lambda: core_open
    paper._v930_compact_existing_open_rows = lambda obj: False
    paper._v739_quarantine_open_positions = lambda obj: []
    picks = [("x1", {"ticker": "A"}), ("x2", {"ticker": "B"})]
    paper.select_candidates = lambda ctrl, op: (picks, {"s1_seen": 2, "selected_s1": 2}, [x[1] for x in picks])
    paper.open_position = lambda pid, ev: {"pos_id": pid, "ticker": ev["ticker"], "paper_decision_key_v926": f"d-{pid}"}
    paper._v926_decision_key_from_row = lambda row: row.get("paper_decision_key_v926")
    def batch(op, prepared_rows):
        batch_calls.append(list(prepared_rows))
        for pid, pos, _ev in prepared_rows:
            op[pid] = pos
        return [pos for _pid, pos, _ev in prepared_rows], [(pid, ev) for pid, _pos, ev in prepared_rows]
    paper._v1180_commit_open_batch = batch
    paper._v734_is_hold = lambda ev: False
    paper.line_count_cached = lambda *a, **kw: 0
    paper.write_status = lambda status: status_calls.append(dict(status))
    paper._v1181_queue_postprocess = lambda payload: queue_calls.append(dict(payload)) or Path("queued.json")
    paper.log = lambda *a, **kw: None
    status = paper.run_cycle__v1181_fast_core()
    assert len(batch_calls) == 1 and len(batch_calls[0]) == 2
    assert len(status_calls) == 1
    assert len(queue_calls) == 1 and queue_calls[0]["opened_count"] == 2
    assert status["paper_fast_core_v1181"] is True
    assert "v1181_open_batch_commit" in phases


def test_review_guard_main_pipeline() -> None:
    with tempfile.TemporaryDirectory(prefix="coinbot-v1181-fixture-") as tmp:
        base = Path(tmp)
        now = time.time()
        request = {
            "pipeline_cycle_id": "strategy-cycle-test",
            "candidate_commit_id": "commit-test",
            "candidate_rows": 2,
            "created_ts": now,
            "committed_handoff_completed_ts": now,
        }
        write(base / "review_observation_request_v1181.json", request)
        rows = [
            {
                "ticker": "AAA", "s_stage": "S1", "candidate_key": "c-aaa", "paper_decision_key_v926": "d-aaa",
                "source_lane": "coverage", "swing_trigger_price_v977": 100, "swing_invalid_price_v977": 95, "swing_target_price_v977": 120,
                "swing_trigger_source_v977": "5m:resistance", "swing_invalid_source_v977": "1h:support", "swing_target_source_v977": "4h:resistance",
                "risk_reward": 4.0, "target_room_pct": 20.0, "invalid_distance_pct": 5.0, "spread_pct": 0.2, "confirmed_slippage_pct": 0.05,
                "actual_trigger_event_at_v1173": now - 2,
            },
            {
                "ticker": "BBB", "s_stage": "S2", "candidate_key": "c-bbb", "paper_decision_key_v926": "d-bbb",
                "source_lane": "money_flow", "swing_trigger_price_v977": 200, "swing_invalid_price_v977": 190, "swing_target_price_v977": 240,
                "swing_trigger_source_v977": "15m:resistance", "swing_invalid_source_v977": "30m:support", "swing_target_source_v977": "2h:resistance",
                "risk_reward": 4.0, "target_room_pct": 20.0, "invalid_distance_pct": 5.0, "spread_pct": 0.15, "confirmed_slippage_pct": 0.03,
                "actual_trigger_event_at_v1173": now - 3,
            },
        ]
        (base / "paper_candidates_latest.jsonl").write_text("\n".join(json.dumps(row, ensure_ascii=False) for row in rows) + "\n", encoding="utf-8")
        write(base / "clean_candidate_standard_contract_v1141.json", {"schema": "contract", "contract_digest": "locked-digest", "invariants": {"auto_buy": False}})
        write(base / "canonical_performance_snapshot_v987.json", {"snapshot_id": "perf-test", "source_owner": "paper", "summary": {"count": 30, "wins": 18, "losses": 12, "win_rate": 60.0, "sum_pct": 12.5, "avg_pct": 0.416}})

        status_files = {
            "clean_scanner_status.json": {"version": "scanner", "running": True, "phase": "idle"},
            "clean_feature_status.json": {"version": "feature", "running": True, "phase": "idle"},
            "clean_candle_status.json": {"version": "candle", "running": True, "phase": "idle"},
            "clean_market_regime_status.json": {"version": "market", "running": True, "phase": "idle"},
            "clean_orderflow_status.json": {"version": "orderflow", "running": True, "phase": "idle"},
            "clean_target_router_status.json": {"version": "target", "running": True, "phase": "idle"},
            "clean_risk_status.json": {"version": "risk", "running": True, "phase": "idle"},
            "clean_ws_sidecar_status.json": {"version": "ws", "running": True, "phase": "idle"},
            "clean_bithumb_micro_status.json": {"version": "micro", "running": True, "phase": "idle"},
            "clean_strategy_worker_status.json": {"strategy_worker_version": "strategy_worker_v1.036", "running": True, "phase": "cycle_done_v1181", "paper_latest_count": 2, "s1_count": 1, "execution_handoff_elapsed_sec_v1179": 1.2, "last_sec": 1.3},
            "paper_bot_status.json": {"paper_version": "paper_bot_v1.045", "version": "paper_bot_v1.045", "running": True, "phase": "idle", "elapsed_sec": 0.4, "opened_this_cycle": 0, "open_count": 0, "paper_fast_core_v1181": True, "pick_stats": {"paper_generation_candidate_count_v1158": 1}},
            "clean_brain_status.json": {"version": "main", "running": True, "phase": "idle"},
            "clean_guard_runtime_status_v1010.json": {"version": "guard", "running": True, "phase": "idle"},
        }
        for filename, payload in status_files.items():
            write(base / filename, payload)
        write(base / "paper_bot_open.json", {})

        env = dict(os.environ)
        env["PYTHONPATH"] = str(SRC)
        subprocess.run([sys.executable, str(SRC / "review_worker_v1.012.py"), "--once", "--force", "--base-dir", str(base)], check=True, env=env, stdout=subprocess.PIPE, text=True)
        review = json.loads((base / "canonical_review_snapshot_v1181.json").read_text(encoding="utf-8"))
        standard = json.loads((base / "canonical_candidate_standard_v1181.json").read_text(encoding="utf-8"))
        assert review["source"]["state"] == "NORMAL"
        assert standard["state"] == "NORMAL", standard

        sys.path.insert(0, str(SRC))
        from canonical_spine_v1181 import atomic_write_json, build_ops_snapshot
        ops = build_ops_snapshot(base)
        atomic_write_json(base / "ops_spine_snapshot_v1181.json", ops)
        assert ops["overall_state"] == "NORMAL", ops["problems"]
        assert len(ops["stages"]) == 20

        os.environ["COINBOT_BASE_DIR"] = str(base)
        main = load("main_v1181_fixture", SRC / "coinbot_main_v2_13_1127.py")
        flow = main.render_flow_map_full()
        candidate = main.render_candidate_standard()
        assert "전체: 🟢 NORMAL" in flow
        assert "20단계 흐름" in flow
        assert "🟢 NORMAL" in candidate
        assert "자동매수" in flow and "OFF" in flow and "자동매수" in candidate and "OFF" in candidate


def main() -> int:
    test_static_contracts()
    test_paper_batch_and_fast_core()
    test_review_guard_main_pipeline()
    print("PASS v1181 full rebuild contracts: static + Paper batch/core + Review→Guard→Main")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
