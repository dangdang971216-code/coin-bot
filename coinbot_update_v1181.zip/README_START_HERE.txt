코인봇 v1181 전체 재구축 전달물
작성: 2026-07-02 06:40:35 KST

상태
- LOCAL: PASS
- SERVER: CHECK_PENDING_DEPLOY
- 전략모드: ALT_SWING
- 자동매수: OFF
- 라이브 원장: 미포함

가장 먼저 읽기
1. 코인봇_인수인계_v1181_CHECK_20260702.txt
2. docs/V1181_REBUILD_REPORT.txt
3. docs/V1181_WORK_LOCK.txt
4. ACTIVE_VERSION_MATRIX.json
5. apply_bundle/coinbot_update_v1181.zip 또는 별도 제공된 coinbot_update_v1181.zip

핵심
- Main snapshot-only
- Strategy 실행 generation 선봉인
- Paper fast core / postprocess 분리
- Review 관찰 단일 owner
- Guard canonical 20단계 지도 writer
- 중복·죽은 active 경로 제거

주의
- 서버 증거 전 DONE 아님
- 전략수치·청산계약 변경 없음
- 자동매수 OFF
