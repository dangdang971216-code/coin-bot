v2082: read-only instant-death structure/quality probe.
- Keeps v2080 shadow_easy/loss_defense fix and fast default readout.
- Adds /instant_death_audit and /instant_death_audit_full.
- Does not change structure formula, trigger/invalid/target, entry/exit, ledgers, or auto-buy.
