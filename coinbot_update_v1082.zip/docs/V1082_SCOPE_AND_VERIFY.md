# v1082 system resource closeout

## Scope
- Paper v1.004: remove unchanged-cycle full canonical performance snapshot parsing.
- Risk v0.12: split CLOSED fingerprint/cache from frequently changing OPEN fingerprint/cache.
- Guard v2.5.137: `/gsystem_closeout_v1082 240` verifies Paper RSS stability, compact metadata reuse, Risk fast cached/open-only cycles, worker runtime/hash, disk bounds, exact 0/0/0, and auto-buy OFF.

## Unchanged
- Strategy thresholds, trigger, invalid, target, RR, spread, slippage, trailing, time exit, OPEN limit.
- OPEN/CLOSED/trade_log/decision/exact/change/issue ledger contents.
- Canonical performance membership, rows, digest, windows, and writer owner.
- Risk loss-reentry thresholds and output contract fields.

## Local proof
- Paper trading-critical active functions remained AST-identical: select_candidates, open_position, run_cycle, run_exact_exit_monitor, commit_closed_position_exact, persist_open_positions, update_position.
- 21.64MB canonical snapshot, eight unchanged cycles: old 0.6531s and +31,200KB max-RSS high-water; v1082 0.0000s, +0KB, eight full parses avoided.
- Risk old/new first-build semantic common fields matched on synthetic CLOSED/OPEN data.
- OPEN-only update in v1082 performed zero CLOSED scans.
- OPEN file timestamp/content refresh with unchanged ticker membership did not rewrite risk output.

## Server status before apply
CHECK. DONE requires `/gsystem_closeout_v1082 240` after deployment.
