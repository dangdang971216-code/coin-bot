#!/usr/bin/env bash
set -euo pipefail
# v1375: restore v1152 command board/screens and optionally clean-start ledgers.
# Usage:
#   BOT_DIR=/home/dangdang971216/trading_bot bash apply_v1375_restore_v1152_clean_start.sh
#   CLEAN_START=1 BOT_DIR=/home/dangdang971216/trading_bot bash apply_v1375_restore_v1152_clean_start.sh
BOT_DIR="${BOT_DIR:-/home/dangdang971216/trading_bot}"
PKG_DIR="$(cd "$(dirname "$0")" && pwd)"
SRC_DIR="$PKG_DIR/source/latest_intended"
if [ ! -d "$SRC_DIR" ]; then
  SRC_DIR="$PKG_DIR"
fi
mkdir -p "$BOT_DIR"
backup="$BOT_DIR/archive_source_before_v1375_$(date +%Y%m%d_%H%M%S)"
mkdir -p "$backup"
files=(
  bot.py coinbot_main_v2_13_1113.py
  backga_guard_bot.py backga_guard_bot_v2_5_189.py
  paper_bot.py paper_bot_v1.028.py
  strategy_worker.py strategy_worker_v1.019.py
  review_worker.py review_worker_v1.011.py
  candle_worker.py candle_worker_v0.960.py
  feature_worker.py feature_worker_v0.6.py
  market_regime_worker.py market_regime_worker_v0.1.py
  orderflow_worker.py orderflow_worker_v0.11.py
  risk_worker.py risk_worker_v0.13.py
  scanner_worker.py scanner_worker_v0.945.py
  target_router_worker.py target_router_worker_v0.28.py
  ws_sidecar.py ws_sidecar_v0.7.py
  bithumb_micro_sidecar.py bithumb_micro_sidecar_v0.14.py
)
for f in "${files[@]}"; do
  if [ -f "$BOT_DIR/$f" ]; then cp -p "$BOT_DIR/$f" "$backup/$f"; fi
  if [ -f "$SRC_DIR/$f" ]; then cp -p "$SRC_DIR/$f" "$BOT_DIR/$f"; else echo "MISSING_SOURCE $f" >&2; exit 3; fi
done
cp -p "$PKG_DIR/coinbot_ledger_clean_start_v1375.py" "$BOT_DIR/coinbot_ledger_clean_start_v1375.py"
python3 -m py_compile "${files[@]/#/$BOT_DIR/}" "$BOT_DIR/coinbot_ledger_clean_start_v1375.py"
if [ "${CLEAN_START:-0}" = "1" ]; then
  python3 "$BOT_DIR/coinbot_ledger_clean_start_v1375.py" --bot-dir "$BOT_DIR" --apply
else
  python3 "$BOT_DIR/coinbot_ledger_clean_start_v1375.py" --bot-dir "$BOT_DIR"
fi
cat > "$BOT_DIR/RESTORE_V1152_COMMAND_BOARD_V1375_APPLIED.txt" <<EOF
v1375 restore package applied at $(date -Is)
- Runtime source restored to v1152 command board/screens.
- Source backup: $backup
- Clean start executed: ${CLEAN_START:-0}
- Auto-buy remains OFF.
EOF
echo "DONE v1375 restore source copied. Restart services and verify runtime/hash."
