코인봇 v1375 · v1152 명령어/지도 복구 + 장부 새 시작 도구

상태: LOCAL_DONE_SERVER_CHECK
전략모드: ALT_SWING
자동매수: OFF

핵심 목적
1. v1374의 복잡한 명령어/화면을 유지하지 않는다.
2. v1152 당시의 /flow_map_full, /candidate_standard, /version_score 계열 화면과 명령어 구성을 기준으로 되돌린다.
3. trigger/invalid/target/RR/trailing/time exit/OPEN 제한은 변경하지 않는다.
4. 복잡해진 장부는 삭제하지 않고 archive 후 새 빈 장부로 시작할 수 있는 도구를 제공한다.

적용 방식
- source/latest_intended 안의 파일은 v1152 active alias/source 그대로다.
- apply_v1375_restore_v1152_clean_start.sh 는 source를 BOT_DIR에 복사하고 py_compile을 수행한다.
- CLEAN_START=1 을 주면 coinbot_ledger_clean_start_v1375.py --apply 를 실행한다.
- CLEAN_START를 주지 않으면 DRY-RUN만 수행한다.

주의
- 서버 적용·재시작·runtime/hash 검수 전에는 SERVER_CHECK다.
- 장부 clean start는 archive manifest를 남긴다.
- 과거 원장을 현재 성과로 재계산하지 않는다.
