coinbot_update_v2191.zip

Changed components
- Main v2.13.2157
- Paper v2.106
- Review v2.078

Unchanged
- Strategy v2.072
- Core v2172
- Guard, Scanner, Candle, Feature, Orderflow, Market, Risk, Target Router, Micro, WS
- Prediction scores and thresholds
- Trigger, Invalid, Target, RR, entry, exit and Paper cost rules
- Auto-buy OFF

Expected result
- /version_score shows only the active post-reset epoch.
- Old DEXE/old CLOSED history cannot reappear as current performance.
- /trade_review uses unique candidate-event horizon counts.
- 6h price results and finalized outcome-ledger rows are shown separately.
- /pzero_status shows exact decision repair state for the prior SOLV append-verified gap.
