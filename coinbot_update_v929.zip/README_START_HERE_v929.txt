코인봇 v929 저장·연산 구경로 평탄화 번들

변경: strategy publish/writer 중복 경로 제거, review 실제 tail reader, S1 hold 최초시각 보존.
미변경: S기준, trigger, entry, invalid/target, 청산, 비용기준, 자동매수 OFF, 핵심 원장.
적용 후 APPLY_AFTER_v929.txt 순서로 실서버 숫자를 확인한다.
