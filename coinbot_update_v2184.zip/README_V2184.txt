Coinbot v2184

Purpose
- Restore the established update flow.
- Remove the v2183-added hard-coded runtime identity gate and selection ledger path.
- Keep the selected ZIP visible through the existing new-guard start/final messages.
- Stop 15-day core-ledger and Shadow compaction inside the existing /gclean_disk path.

Not changed
- Strategy numbers, candidate quality, Trigger/Invalid/Target/RR, entry/exit contract
- Main/Paper/Strategy/Review/Micro/WS runtime files
- Historical ledger rows or Shadow data
- Auto-buy remains OFF

Server status
- LOCAL PASS / SERVER CHECK
