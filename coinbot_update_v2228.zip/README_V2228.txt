v2228 가드 단독 복구

목적
- GitHub ZIP 선택 뒤 구형 207초 적용 경로로 들어가던 연결 오류만 수정.
- 기존 빠른 compile/hash/원자교체/변경 runtime 검수 함수를 직접 사용.
- 새 명령·새 worker·새 Shadow·전략 변경 없음.
- 자동매수 OFF.

적용
1) GitHub에 coinbot_update_v2228.zip 업로드
2) Guard /gupgrade_bundle
3) /guard에서 v2.6.55 확인
