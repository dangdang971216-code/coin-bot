코인봇 v2210

1. 후보를 숫자로 자르지 않는다.
   - 모든 후보 사건은 보존한다.
   - 첫 단계로 장기 흐름 trend/capital/persistence 3개 중 2개 이상이 실제 양수일 때만 S1/Paper 진입 가능.
   - 이후 조건은 /trade_review 수익군·손실군 비교 후 하나씩 추가한다.

2. 임시 손실 방어
   - 비용 포함 순손익 -2.0% 도달 시 temporary_loss_cap_2pct로 Paper 청산.
   - 원래 구조 invalid는 그대로 봉인·보존한다.
   - target 도달은 기존대로 우선한다.

3. 재진입
   - -2% 청산 뒤 고정 대기시간은 없다.
   - 이전과 다른 decision key와 청산 뒤 실제 새 trigger 시각이 있어야 새 candidate/OPEN으로 진입한다.
   - 단순 재출력 created_ts는 새 trigger로 인정하지 않는다.

4. 상승예측 검증
   - 기존 완료 캔들 cache에서 30m/1h/3h/6h를 각각 정확한 시각으로 계산한다.
   - 각 구간 MFE·MAE도 독립 계산한다.
   - Review 계산 시점 현재가격 대체는 사용하지 않는다.
   - 같은 초기화 epoch의 수익 CLOSED와 손실 CLOSED를 비교한다.

5. 변경하지 않음
   - 상승예측 기존 가중치와 양수 점수선
   - 구조 trigger/invalid/target/RR 수치
   - 과거 OPEN/CLOSED/decision/exact 원장
   - 성과 초기화
   - 새 Shadow·새 명령·강제 후보수 제한
   - 자동매수 OFF

로컬 검수 PASS / 서버 적용·결과 검수 CHECK.
