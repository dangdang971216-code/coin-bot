v2222 repairs two confirmed deployment faults:
1) a newer command selected/resumed v2220 instead of the newly supplied bundle;
2) Paper v2.115 ran its startup OPEN sweep before publishing exact runtime identity.

It preserves v2220 Review recent-7-day/date backfill, v2219 influence decomposition, all ledgers and Shadow, and auto-buy OFF.
