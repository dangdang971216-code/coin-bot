코인봇 v927 운영 통합감사 릴리스

1. 서버 적용: coinbot_update_v927.zip
2. 가드 우선 적용 응답이면 /gdeploy 확인 후 같은 bundle을 한 번 더 적용
3. 원인감사: /gdeep_audit
4. 결과 TXT 전체를 다음 채팅에 전달

이번 릴리스는 guard 진단기능만 변경했다. 매매코드·조건·OPEN/CLOSED 장부는 변경하지 않았다.
