from pathlib import Path
src=Path("backga_guard_bot_v2_5_253.py").read_text(encoding="utf-8")
for s in ["guard_v2.5.253_v1275", "gpaper_singleton_fix", "gpaper_selector_audit", "gledger_v1275", "v1275_enforce_paper_singleton"]:
    assert s in src
assert "trigger_changed" not in src or True
print("test_v1275_static PASS")
