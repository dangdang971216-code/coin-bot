import json
from pathlib import Path
b=json.loads(Path("DEPLOY_BUNDLE.json").read_text(encoding="utf-8"))
assert b["release"]=="v1275"
assert b["runtime_files"]["guard"]=="backga_guard_bot_v2_5_253.py"
assert b["actual_trading_changed"] is False
assert b["auto_buy"] is False
print("test_v1275_bundle_contract PASS")
