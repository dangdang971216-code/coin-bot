v1275: Paper 중복 재발 방지 + selector 선택0 사유 감사 + 구조감사 source mismatch 보호표시. 전략수치 변경 없음.
