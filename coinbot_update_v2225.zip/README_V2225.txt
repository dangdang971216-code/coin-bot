코인봇 v2225
- v2000 검증된 빠른 선택 적용 복구
- 접수 → 선택 ZIP/시작 → 최종 결과
- Paper alias/versioned 잔류 PID 전부 종료 후 단일 재시작
- Paper 중복 pre-main sweep 제거, 기존 canonical 첫 cycle sweep 유지
- Main/Review/Strategy/Core 미변경
- 전략/상승예측/구조/진입/청산 수치 변경 없음
- 자동매수 OFF
