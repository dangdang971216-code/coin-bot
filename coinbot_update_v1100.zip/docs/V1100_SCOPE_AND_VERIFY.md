# v1100 Scope and Verification

## Root cause

v1099 proved that current S1 candidates reached Paper final safety but were all held as `SLIPPAGE_SOURCE_MISSING`. Orderflow, Strategy and Paper used different field/source contracts, while the old Orderflow fallback could copy spread into slippage.

## Repair

- Orderflow v0.11 owns one canonical entry-slippage contract.
- Trusted micro/orderbook depth estimates are accepted only when their source explicitly identifies a depth calculation.
- Otherwise, with fresh micro data, slippage is the fresh best ask relative to the freshest quote/trade reference.
- Spread is never substituted for slippage.
- No Paper notional is invented. The amount is null and the state is `paper_notional_not_configured`.
- Strategy replaces the entire canonical contract each cycle and seals it into S1 hold.
- Paper reads only the canonical contract and blocks missing, stale and over-limit values.
- OPEN seals the entry-time value, source, timestamp, basis, amount state and limit.

## Not changed

Quality thresholds, slippage limit, OPEN 30/cycle 3, trigger, invalid, target, exit contract and auto-buy state were not changed.

## Server proof

The update remains CHECK until actual runtime versions, canonical slippage population, Paper funnel reasons, OPEN ledger sealing and absence of new errors are verified. Zero OPEN alone is not a failure if current candidates are blocked by real post-slippage gates. Forced entry is prohibited.
