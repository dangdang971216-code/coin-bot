import importlib.util
import json
import os
import tempfile
import time
import sys
import unittest
from pathlib import Path

ROOT = Path(__file__).resolve().parent


def load_module(name: str, path: Path):
    spec = importlib.util.spec_from_file_location(name, path)
    mod = importlib.util.module_from_spec(spec)
    assert spec and spec.loader
    sys.modules[name] = mod
    spec.loader.exec_module(mod)
    return mod


class PaperDeltaStateTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.mod = load_module("paper_v1210_test", ROOT / "paper_bot_v1.064.py")

    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        base = Path(self.tmp.name)
        m = self.mod
        m.V1153_PAPER_PATH_STATE = base / "state.json"
        m.V1153_PAPER_PATH_LEDGER = base / "events.jsonl"
        m.V1210_PAPER_PATH_STATE_DELTA = base / "delta.jsonl"
        now = time.time()
        records = {
            f"old-{i}": {
                "recorded_at": now - 10,
                "first_seen_at": now - 10,
                "last_seen_at": now - 10,
                "seen_count": 1,
                "repeat_exposure_count": 0,
                "stage": "PAPER_RECEIVED",
                "anchor": f"anchor-{i}",
            }
            for i in range(5000)
        }
        m.V1153_PAPER_PATH_STATE.write_text(json.dumps({"updated_ts": now, "records": records}), encoding="utf-8")
        m._V1210_PAPER_PATH_CACHE.clear()
        m._V1210_PAPER_PATH_CACHE.update({"loaded": False, "records": {}, "checkpoint_ts": 0.0, "delta_count": 0, "load_count": 0, "replayed_delta_count": 0})
        m._V1192_PAPER_PATH_BATCH = None
        m._V1192_PAPER_PATH_BATCH_LAST = {"state": "NOT_RUN"}

    def tearDown(self):
        self.tmp.cleanup()

    def test_selector_flush_appends_small_delta_without_full_snapshot_rewrite(self):
        m = self.mod
        before = m.V1153_PAPER_PATH_STATE.stat().st_mtime_ns
        self.assertTrue(m._v1192_paper_path_batch_begin())
        ev = {"ticker": "BTC", "trigger_occurrence_candidate_key": "candidate-new-1"}
        first = m._v1153_paper_event_once("PAPER_RECEIVED", ev, ["test"])
        self.assertIsNotNone(first)
        result = m._v1192_paper_path_batch_flush()
        self.assertEqual(result["state"], "COMMITTED_DELTA")
        self.assertEqual(result["state_delta_record_count"], 1)
        self.assertEqual(result["checkpoint_write_count"], 0)
        self.assertEqual(before, m.V1153_PAPER_PATH_STATE.stat().st_mtime_ns)
        lines = m.V1210_PAPER_PATH_STATE_DELTA.read_text(encoding="utf-8").strip().splitlines()
        self.assertEqual(len(lines), 1)
        self.assertIn("candidate-new-1", m._V1210_PAPER_PATH_CACHE["records"][next(k for k in m._V1210_PAPER_PATH_CACHE["records"] if k not in {f'old-{i}' for i in range(5000)})]["anchor"])

    def test_checkpoint_plus_delta_replay_is_exact(self):
        m = self.mod
        records = m._v1210_path_state_load_once()
        uid = "manual-uid"
        records[uid] = {"anchor": "manual", "seen_count": 3, "repeat_exposure_count": 2}
        m._v1210_path_state_append_deltas(records, {uid}, time.time())
        m._v1210_path_state_checkpoint_if_due(records, time.time(), force=True)
        self.assertEqual(m.V1210_PAPER_PATH_STATE_DELTA.read_text(encoding="utf-8"), "")
        m._V1210_PAPER_PATH_CACHE.clear()
        m._V1210_PAPER_PATH_CACHE.update({"loaded": False, "records": {}, "checkpoint_ts": 0.0, "delta_count": 0, "load_count": 0, "replayed_delta_count": 0})
        loaded = m._v1210_path_state_load_once()
        self.assertEqual(loaded[uid]["repeat_exposure_count"], 2)


class MicroOptimizationTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.mod = load_module("micro_v1210_test", ROOT / "bithumb_micro_sidecar_v0.17.py")

    def tearDown(self):
        m = self.mod
        if m._EXECUTOR is not None:
            m._EXECUTOR.shutdown(wait=True, cancel_futures=True)
            m._EXECUTOR = None

    def test_all_orderbook_snapshot_preserves_ticker_coverage(self):
        m = self.mod
        calls = []
        old_http = m.http_json
        def fake_http(url, timeout=m.REQUEST_TIMEOUT):
            calls.append(url)
            if "ALL_KRW" in url:
                return {"status": "0000", "data": {
                    "timestamp": "1",
                    "BTC": {"order_currency": "BTC", "bids": [{"price": "100", "quantity": "2"}], "asks": [{"price": "101", "quantity": "3"}]},
                    "ETH": {"order_currency": "ETH", "bids": [{"price": "200", "quantity": "2"}], "asks": [{"price": "202", "quantity": "2"}]},
                }}
            return {"status": "0000", "data": {"bids": [{"price": "50", "quantity": "1"}], "asks": [{"price": "51", "quantity": "1"}]}}
        m.http_json = fake_http
        try:
            result = m.refresh_all_orderbooks()
            self.assertEqual(result["rows"], 2)
            btc = m.parse_orderbook("BTC")
            self.assertTrue(btc["orderbook_ok"])
            self.assertEqual(btc["orderbook_source_v1210"], "bithumb_public_orderbook_all_krw")
            self.assertEqual(len(calls), 1)
            xrp = m.parse_orderbook("XRP")
            self.assertTrue(xrp["orderbook_ok"])
            self.assertEqual(xrp["orderbook_source_v1210"], "bithumb_public_orderbook_per_ticker_fallback")
            self.assertEqual(len(calls), 2)
            plan = m.select_poll_batch(["BTC", "ETH", "XRP", "KRW-DOGE"], include_urgent=True)
            self.assertEqual(set(plan), {"BTC", "ETH", "XRP", "DOGE"})
        finally:
            m.http_json = old_http

    def test_executor_is_reused(self):
        m = self.mod
        a = m._persistent_executor()
        b = m._persistent_executor()
        self.assertIs(a, b)


class StrategySharedEvalTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.mod = load_module("strategy_v1210_test", ROOT / "strategy_worker_v1.046.py")

    def sample(self):
        rows = [
            {
                "ticker": "KRW-BTC", "current_price": 100.0, "price": 100.0,
                "change_1m": 0.8, "change_3m": 1.4, "price_reaction_pct": 0.6,
                "relative_strength_pct": 1.0, "money_flow_score": 60.0,
                "volume_ratio": 1.2, "vwap_gap_pct": 0.3, "ema5_gap_pct": 0.2,
                "feature_ts": time.time(), "scanner_hot_score": 90.0,
            },
            {
                "ticker": "ETH", "current_price": 200.0, "price": 200.0,
                "change_1m": 0.0, "change_3m": 0.1, "price_reaction_pct": 0.0,
                "relative_strength_pct": -0.2, "money_flow_score": 40.0,
                "volume_ratio": 0.8, "vwap_gap_pct": -0.1, "ema5_gap_pct": -0.1,
                "feature_ts": time.time(),
            },
        ]
        of = {
            "BTC": {"trade_buy_ratio_30": 0.75, "buy_sustain_1m": 0.74, "micro_spread_pct": 0.1, "quote_fresh": True, "micro_fresh": True},
            "ETH": {"trade_buy_ratio_30": 0.45, "buy_sustain_1m": 0.45, "micro_spread_pct": 0.2, "quote_fresh": True, "micro_fresh": True},
        }
        return rows, of

    def test_shared_values_match_direct_owner_functions(self):
        m = self.mod
        rows, ofmap = self.sample()
        shared = m._v1210_shared_candidate_eval(rows, ofmap)
        self.assertEqual(set(shared), {"BTC", "ETH"})
        for src in rows:
            t = m.ticker_norm(src["ticker"])
            of = ofmap[t]
            self.assertEqual(shared[t]["react"], m._v510_price_reaction(src, of))
            self.assertEqual(shared[t]["buy"], m._v510_buy(of, src))
            self.assertEqual(shared[t]["spread"], m._v510_spread(of, src))
            direct_hits = []
            for skey, fn in m._V1210_EVALS:
                ok, why, _ = fn(src, of)
                if ok:
                    direct_hits.append((skey, why))
            self.assertEqual(shared[t]["core_hits"], direct_hits)

    def test_lane_results_same_with_explicit_or_internal_cycle_cache(self):
        m = self.mod
        rows, ofmap = self.sample()
        shared = m._v1210_shared_candidate_eval(rows, ofmap)
        base_a = m._v510_base_lane(time.time(), rows, ofmap, shared)
        base_b = m._v510_base_lane(time.time(), rows, ofmap, None)
        self.assertEqual([r.get("ticker") for r in base_a[0]], [r.get("ticker") for r in base_b[0]])
        spike_a = m._v510_spike_lane(time.time(), rows, ofmap, shared)
        spike_b = m._v510_spike_lane(time.time(), rows, ofmap, None)
        self.assertEqual([r.get("ticker") for r in spike_a], [r.get("ticker") for r in spike_b])
        self.assertEqual(m.ticker_norm("KRW-BTC"), "BTC")
        self.assertEqual(m.ticker_norm("BTC_KRW"), "BTC")


class CanonicalDeltaReaderTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.mod = load_module("spine_v1210_test", ROOT / "canonical_spine_v1190.py")

    def test_snapshot_and_delta_merge(self):
        with tempfile.TemporaryDirectory() as td:
            base = Path(td)
            (base / "paper_candidate_path_state_v1153.json").write_text(json.dumps({"records": {"a": {"seen_count": 1}}}), encoding="utf-8")
            (base / "paper_candidate_path_state_delta_v1210.jsonl").write_text(
                json.dumps({"event_uid": "a", "record": {"seen_count": 2}}) + "\n" +
                json.dumps({"event_uid": "b", "record": {"seen_count": 1}}) + "\n",
                encoding="utf-8",
            )
            out = self.mod._read_candidate_path_state_v1210(base)
            self.assertEqual(out["record_count"], 2)
            self.assertEqual(out["records"]["a"]["seen_count"], 2)
            self.assertEqual(out["delta_applied_v1210"], 2)


if __name__ == "__main__":
    unittest.main(verbosity=2)
