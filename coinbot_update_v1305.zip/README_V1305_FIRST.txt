coinbot_update_v1305 · KST 오늘 성과 보정 + 후보품질 원인 TOP + 디스크 정리 결과판 강화

상태: LOCAL_DONE / SERVER_CHECK
자동매수: OFF
전략 변경: 없음

수정 내용:
1. /version_score 오늘 계산 보정
   - active score anchor가 오늘 시작됐는데 today가 0전으로 보이던 표시 오류 수정
   - 최근 3h가 있으면 오늘도 같은 새 epoch 기준으로 표시
   - 과거 CLOSED fallback 없음
2. 후보품질 원인 TOP 보강
   - Strategy status의 swing_gate_hard_reason_top_v979 등 canonical reason owner에서 읽음
   - 없을 때만 후보 row tail을 읽어 보조 표시
   - 후보식·trigger·invalid·target·RR 변경 없음
3. Guard 통합 디스크 정리 명령 강화
   - /gdisk_full_v1305
   - 기존 압축·정리에 stale .bundle_unpack_* 정리 추가
   - 정리 전/후 용량, 변화량, 단계별 결과, 남은 큰 파일 TOP 표시
   - 핵심 원장 원본 삭제·축소·재작성 없음

적용 후 확인:
가드봇: /gupgrade_bundle
가드 재시작 후: /grelease_verify
메인봇: /version_score /flow_map_full /candidate_standard
디스크 정리: /gdisk_full_v1305
미리보기: /gdisk_full_v1305 dry
Paper 초기화 필요 시: /pzero_reset_v1305 /pzero_status_v1305
