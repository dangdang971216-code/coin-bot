코인봇 업데이트 v1187

현재 사용자 증거 기준
- Guard v2.5.199
- Strategy v1.037
- Review v1.016
- Main v2.13.1129
- Paper v1.047
- 후보→선택→OPEN 재개 확인
- 자동매수 OFF

v1187 대상
- Guard v2.5.199 유지
- Strategy v1.037 유지
- Review v1.016 유지
- Main v2.13.1130
- Paper v1.048

핵심 변경
- /version_score를 예전처럼 보기 쉬운 기간별 블록으로 복원
- Paper canonical OPEN 평가손익·수익/손실·MFE·반납 연결
- /pstatus와 /candidate_summary의 실제 제외·진단·해석 분리
- /flow_map_full과 /candidate_standard 핵심화면 문구 정리

적용
1. 가드봇에서 /gupgrade_bundle 단독 실행
2. 자동 이어적용 완료 후 가드·Paper·Main 검수
3. runtime exact/hash, 다음 cycle, 재시작 유지 확인 전 DONE 금지

검수 핵심
- /version_score에서 오늘·어제·3h·6h·24h가 블록형으로 표시
- 현재 OPEN 평가 가능·평가손익·수익/손실·MFE·반납 표시
- /pstatus에서 이번 cycle→실제 제외→진단→해석 순서
- /candidate_summary에서 현재판→실제 제외→진단→S1 표본 순서
- 전략수치·청산계약 변경 없음
- 자동매수 OFF
