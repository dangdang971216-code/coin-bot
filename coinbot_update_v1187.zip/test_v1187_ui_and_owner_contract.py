#!/usr/bin/env python3
from __future__ import annotations

import importlib.util
import json
import os
import sys
import tempfile
from pathlib import Path

ROOT = Path(__file__).resolve().parent
BASE = Path(tempfile.mkdtemp(prefix='coinbot_v1187_test_'))
os.environ['COINBOT_BASE_DIR'] = str(BASE)
os.environ.pop('TELEGRAM_TOKEN', None)
sys.path.insert(0, str(ROOT))

perf = {
    'snapshot_id': 'perf-v1187-test',
    'generated_at_text': 'now',
    'source_owner': 'paper_bot_single_canonical_performance_writer',
    'counts': {'raw_ledger_rows': 130, 'exact_unique_closed': 100, 'current_epoch_exact_rows_v1045': 12},
    'windows': {
        'today': {'n': 8, 'wins': 5, 'losses': 3, 'win_rate': 62.5, 'total': 3.0, 'avg': 0.375},
        'yesterday': {'n': 7, 'wins': 3, 'losses': 4, 'win_rate': 42.9, 'total': -1.0, 'avg': -0.143},
        'recent_3h': {'n': 3, 'wins': 2, 'losses': 1, 'win_rate': 66.7, 'total': 1.2, 'avg': 0.4},
        'recent_6h': {'n': 5, 'wins': 3, 'losses': 2, 'win_rate': 60.0, 'total': 1.0, 'avg': 0.2},
        'recent_24h': {'n': 9, 'wins': 5, 'losses': 4, 'win_rate': 55.6, 'total': 2.2, 'avg': 0.244},
        'all': {'n': 100, 'wins': 50, 'losses': 50, 'win_rate': 50.0, 'total': 10.0, 'avg': 0.1},
    },
    'performance_epoch_v1045': {
        'stats': {'n': 12, 'wins': 7, 'losses': 5, 'win_rate': 58.3, 'total': 4.2, 'avg': 0.35},
        'current_open_count': 4,
    },
    'book_performance_v1043': {
        'open_count': 4,
        'valid_pnl_rows': 4,
        'missing_pnl_rows': 0,
        'wins': 2,
        'losses': 2,
        'flats': 0,
        'current_total': 1.5,
        'current_avg': 0.375,
        'positive_total': 3.0,
        'negative_total': -1.5,
        'mfe_total': 6.5,
        'giveback_total': 5.0,
        'giveback_avg': 1.25,
    },
}
(BASE / 'canonical_performance_snapshot_v987.json').write_text(json.dumps(perf), encoding='utf-8')
(BASE / 'ops_spine_snapshot_v1181.json').write_text(json.dumps({
    'overall_state': 'NORMAL',
    'current_cycle': {'state':'NORMAL','candidate_rows':461,'s1_count':6,'paper_received':461},
    'timing': {'strategy_execution_handoff_sec':9.2,'strategy_full_cycle_sec':19.0,'paper_fast_cycle_sec':10.5},
    'problems': [],
}), encoding='utf-8')
(BASE / 'canonical_candidate_standard_v1181.json').write_text(json.dumps({
    'state':'NORMAL','easy_state':'전체 정상','missing':[],
    'delivery':{'pipeline_cycle_id':'cy','candidate_commit_id':'cm'},
    'candidate':{'total':461,'s1':6,'s2':210,'s3':245},
    'time':{'strategy_execution_handoff_sec':9.2,'occurrence_age_median_sec':12.0},
    'performance':{'count':12,'win_rate':58.3,'sum_pct':4.2},
}), encoding='utf-8')
(BASE / 'paper_bot_status.json').write_text(json.dumps({'running': True, 'version': 'paper_bot_v1.048'}), encoding='utf-8')
(BASE / 'paper_bot_open.json').write_text('{}', encoding='utf-8')

spec = importlib.util.spec_from_file_location('main_v1187', ROOT / 'coinbot_main_v2_13_1130.py')
main = importlib.util.module_from_spec(spec)
assert spec and spec.loader
spec.loader.exec_module(main)

score = main.render_version_score_compact()
labels = ['오늘', '어제', '최근 3시간', '최근 6시간', '최근 24시간', '새 성과구간', '현재 OPEN 4개', '전체 누적']
for label in labels:
    assert label in score, (label, score)
assert [score.index(label) for label in labels] == sorted(score.index(label) for label in labels)
for text in ['평가 가능 4개', '전체 평가손익 +1.50%', '수익 2개', '손실 2개', '보유 중 최고수익 합 +6.50%', '현재까지 반납 합 5.00%p']:
    assert text in score, (text, score)
assert 'canonical book snapshot 대기' not in score

flow = main.render_flow_map_compact()
for text in ['현재 cycle', '전체 후보 461 → S1 6 → Paper 확인 461', '현재 문제 0개']:
    assert text in flow, (text, flow)

candidate = main.render_candidate_compact()
for text in ['후보 전달', '전체 461 → S1 6 / S2 210 / S3 245', '원천 누락 0개 · 없음']:
    assert text in candidate, (text, candidate)

paper_source = (ROOT / 'paper_bot_v1.048.py').read_text(encoding='utf-8')
for text in ['📌 이번 cycle', '🚫 실제 진입 제외', '🧪 진단 전용 · 실제 차단 아님', '📍 현재 후보판']:
    assert text in paper_source, text
assert "VERSION = 'paper_bot_v1.048'" in paper_source
print('PASS')
