#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Coinbot Main v2.13.1130 / v1187.

Canonical snapshot-only Main with the familiar command UX restored.
It never recalculates candidates, performance, OPEN/CLOSED, or strategy values.
Large canonical JSON files are cached only while their exact size+mtime signature
is unchanged. A missing or unreadable current file is never replaced with an old
cached value.
"""
from __future__ import annotations

import json
import os
import re
import signal
import tempfile
import threading
import time
import traceback
from pathlib import Path
from typing import Any, Callable, Dict, Iterable, List, Mapping, Optional, Sequence, Tuple

from canonical_spine_v1186 import (
    STRATEGY_MODE,
    SpinePaths,
    atomic_write_json,
    file_age,
    find_ledger,
    integer,
    mapping,
    now_text,
    now_ts,
    num,
    pct_text,
    read_json,
    read_jsonl_tail,
    safe_error_tail,
    text,
)

try:
    from telegram import BotCommand
    from telegram.ext import CommandHandler, Filters, MessageHandler, Updater
except Exception:
    BotCommand = None
    CommandHandler = None
    Filters = None
    MessageHandler = None
    Updater = None

BOT_VERSION = "수익형 v2.13.1130"
MAIN_BOT_VERSION = BOT_VERSION
BUILD_LABEL = "v1187_readable_score_open_book_and_paper_board_2026-07-02"
V650_BUILD_LABEL = BUILD_LABEL
RELEASE_TAG = "v1187"
HEARTBEAT_SEC = 5.0
TELEGRAM_LIMIT = 3900
_STOP = False
_STARTED_TS = now_ts()
_TELEGRAM_STATE = "initializing"
_TELEGRAM_ERROR = ""
_TELEGRAM_NOTE = "boot"
_SCAN_RUNNING = False
_SCAN_STAGE = "idle"


def base_dir() -> Path:
    override = os.getenv("COINBOT_BASE_DIR", "").strip()
    return Path(override).expanduser().resolve() if override else Path(__file__).resolve().parent


BASE_DIR = base_dir()
PATHS = SpinePaths(BASE_DIR)
TELEGRAM_TOKEN = os.getenv("TELEGRAM_TOKEN", "").strip()
CHAT_ID = os.getenv("CHAT_ID", "").strip()
COMMAND_SUMMARY_STATUS = BASE_DIR / "command_summary_status_v1187.json"
RUNTIME_LOG = BASE_DIR / "clean_brain_runtime.log"
ERROR_LOG = BASE_DIR / "clean_brain_error.log"

_CACHE_LOCK = threading.RLock()
_JSON_CACHE: Dict[str, Tuple[Tuple[int, int], Any]] = {}
_COMMAND_LOCK = threading.Lock()
_REQUEST_LOCK = threading.Lock()
_REQUEST_SEEN: Dict[str, float] = {}


def log_error(where: str, exc: BaseException) -> None:
    message = (
        f"[{now_text()}] {where}: {type(exc).__name__}: {exc}\n"
        f"{traceback.format_exc()[-4000:]}\n"
    )
    try:
        with ERROR_LOG.open("a", encoding="utf-8") as handle:
            handle.write(message)
    except OSError:
        pass


def log_runtime(message: str) -> None:
    try:
        with RUNTIME_LOG.open("a", encoding="utf-8") as handle:
            handle.write(f"[{now_text()}] {message}\n")
    except OSError:
        pass


def _path_signature(path: Path) -> Optional[Tuple[int, int]]:
    try:
        stat = path.stat()
        return int(stat.st_mtime_ns), int(stat.st_size)
    except OSError:
        return None


def current_json(path: Path, default: Any = None) -> Any:
    """Read the current canonical file with exact-signature reuse only.

    If the file disappeared or the current bytes cannot be parsed, the previous
    object is removed and never used as a fallback.
    """
    key = str(path)
    signature = _path_signature(path)
    if signature is None:
        with _CACHE_LOCK:
            _JSON_CACHE.pop(key, None)
        return default
    with _CACHE_LOCK:
        cached = _JSON_CACHE.get(key)
        if cached and cached[0] == signature:
            return cached[1]
    obj = read_json(path, None)
    if obj is None:
        with _CACHE_LOCK:
            _JSON_CACHE.pop(key, None)
        return default
    with _CACHE_LOCK:
        _JSON_CACHE[key] = (signature, obj)
    return obj


def warm_canonical_cache() -> None:
    for path in (
        PATHS.ops_snapshot,
        PATHS.candidate_standard,
        PATHS.review_snapshot,
        PATHS.paper_status,
        PATHS.paper_open,
        PATHS.performance,
    ):
        try:
            current_json(path, None)
        except Exception as exc:
            log_error(f"warm_cache_{path.name}", exc)


def set_runtime_state(*, telegram_state: Optional[str] = None, telegram_error: Optional[str] = None,
                      telegram_note: Optional[str] = None, scan_running: Optional[bool] = None,
                      scan_stage: Optional[str] = None) -> None:
    global _TELEGRAM_STATE, _TELEGRAM_ERROR, _TELEGRAM_NOTE, _SCAN_RUNNING, _SCAN_STAGE
    if telegram_state is not None:
        _TELEGRAM_STATE = telegram_state
    if telegram_error is not None:
        _TELEGRAM_ERROR = telegram_error
    if telegram_note is not None:
        _TELEGRAM_NOTE = telegram_note
    if scan_running is not None:
        _SCAN_RUNNING = bool(scan_running)
    if scan_stage is not None:
        _SCAN_STAGE = str(scan_stage or "idle")


def write_status(state: str = "running", **extra: Any) -> None:
    updated = now_ts()
    payload: Dict[str, Any] = {
        "schema": "main_status_v1186",
        "version": BOT_VERSION,
        "brain_version": BOT_VERSION,
        "build": BUILD_LABEL,
        "running": state not in {"stopped", "error"},
        "state": state,
        "phase": extra.pop("phase", _SCAN_STAGE if _SCAN_RUNNING else "idle"),
        "updated_ts": updated,
        "updated_text": now_text(updated),
        "started_at": _STARTED_TS,
        "pid": os.getpid(),
        "owner": "main_canonical_snapshot_renderer_and_ux_v1186",
        "strategy_mode": STRATEGY_MODE,
        "auto_buy": False,
        "candidate_recalculation": False,
        "performance_recalculation": False,
        "legacy_command_override_chain": False,
        # Exact fields consumed by Guard /gdeploy.
        "telegram_state": _TELEGRAM_STATE,
        "telegram_error": _TELEGRAM_ERROR or "-",
        "telegram_note": _TELEGRAM_NOTE,
        "telegram_updated_ts": updated,
        "command_count": len(COMMANDS) if "COMMANDS" in globals() else 0,
        "scan_running": _SCAN_RUNNING,
        "scan_last_stage": _SCAN_STAGE,
        "scan_last_ts": updated,
    }
    payload.update(extra)
    atomic_write_json(PATHS.main_status, payload)


def icon(state: Any) -> str:
    value = str(state or "CHECK").upper()
    if value in {"NORMAL", "DONE", "PASS", "READY", "RUNNING", "REVIEWABLE", "ACTIVE"}:
        return "🟢"
    if value in {"FAIL", "FAILED", "ERROR", "DOWN", "SYSTEM_REGRESSION"}:
        return "🔴"
    return "🟡"


def fmt_sec(value: Any, digits: int = 3) -> str:
    parsed = num(value, default=None)
    return "수집 중" if parsed is None else f"{parsed:.{digits}f}초"


def fmt_num(value: Any, digits: int = 3, signed: bool = False) -> str:
    parsed = num(value, default=None)
    if parsed is None:
        return "정보없음"
    sign = "+" if signed else ""
    return f"{parsed:{sign}.{digits}f}"


def fmt_pct(value: Any, digits: int = 3) -> str:
    parsed = num(value, default=None)
    return "정보없음" if parsed is None else f"{parsed:+.{digits}f}%"


def split_text(message: str, limit: int = TELEGRAM_LIMIT) -> List[str]:
    if len(message) <= limit:
        return [message]
    chunks: List[str] = []
    current: List[str] = []
    size = 0
    for line in message.splitlines(True):
        if current and size + len(line) > limit:
            chunks.append("".join(current).rstrip())
            current = []
            size = 0
        if len(line) > limit:
            for start in range(0, len(line), limit):
                if current:
                    chunks.append("".join(current).rstrip())
                    current = []
                    size = 0
                chunks.append(line[start:start + limit].rstrip())
            continue
        current.append(line)
        size += len(line)
    if current:
        chunks.append("".join(current).rstrip())
    return [chunk for chunk in chunks if chunk]


def send_text(update: Any, message: str) -> None:
    target = getattr(update, "effective_message", None) or getattr(update, "message", None)
    if target is None:
        return
    for chunk in split_text(message):
        target.reply_text(chunk)


def _chat_allowed(update: Any) -> bool:
    if not CHAT_ID:
        return True
    chat_id = str(getattr(getattr(update, "effective_chat", None), "id", ""))
    return chat_id == CHAT_ID


def request_key(update: Any) -> str:
    message = getattr(update, "effective_message", None) or getattr(update, "message", None)
    chat_id = getattr(message, "chat_id", None) or getattr(getattr(message, "chat", None), "id", None)
    message_id = getattr(message, "message_id", None)
    update_id = getattr(update, "update_id", None)
    return f"{chat_id}:{message_id}:{update_id}"


def acquire_request(update: Any) -> bool:
    key = request_key(update)
    now_value = time.time()
    with _REQUEST_LOCK:
        for old_key, ts in list(_REQUEST_SEEN.items()):
            if now_value - ts > 180:
                _REQUEST_SEEN.pop(old_key, None)
        if key in _REQUEST_SEEN:
            return False
        _REQUEST_SEEN[key] = now_value
    return True


def _deep_mapping(obj: Mapping[str, Any], *paths: str) -> Dict[str, Any]:
    for path in paths:
        cur: Any = obj
        okay = True
        for part in path.split("."):
            if not isinstance(cur, dict) or part not in cur:
                okay = False
                break
            cur = cur[part]
        if okay and isinstance(cur, dict):
            return cur
    return {}


def _deep_value(obj: Mapping[str, Any], *paths: str, default: Any = None) -> Any:
    for path in paths:
        cur: Any = obj
        okay = True
        for part in path.split("."):
            if not isinstance(cur, dict) or part not in cur:
                okay = False
                break
            cur = cur[part]
        if okay and cur not in (None, "", [], {}):
            return cur
    return default


def _stat_count(stat: Mapping[str, Any]) -> int:
    return integer(stat.get("count"), stat.get("n"), stat.get("closed_count"), default=0)


def _stat_wins(stat: Mapping[str, Any]) -> int:
    return integer(stat.get("wins"), stat.get("win"), default=0)


def _stat_losses(stat: Mapping[str, Any]) -> int:
    n = _stat_count(stat)
    wins = _stat_wins(stat)
    return integer(stat.get("losses"), stat.get("loss"), default=max(0, n - wins))


def _stat_total(stat: Mapping[str, Any]) -> Optional[float]:
    return num(stat.get("sum_pct"), stat.get("total"), stat.get("total_pct"), stat.get("pnl_sum_pct"), default=None)


def _stat_avg(stat: Mapping[str, Any]) -> Optional[float]:
    return num(stat.get("avg_pct"), stat.get("avg"), stat.get("mean_pct"), default=None)


def _stat_win_rate(stat: Mapping[str, Any]) -> Optional[float]:
    value = num(stat.get("win_rate"), stat.get("win_rate_pct"), default=None)
    if value is not None:
        return value
    n = _stat_count(stat)
    return (100.0 * _stat_wins(stat) / n) if n else None


def stat_line(label: str, stat_obj: Any, include_path: bool = True) -> str:
    stat = stat_obj if isinstance(stat_obj, dict) else {}
    n = _stat_count(stat)
    if not stat and n == 0:
        return f"- {label}: 정보없음"
    parts = [
        f"- {label}: n{n}",
        f"{_stat_wins(stat)}승 {_stat_losses(stat)}패",
        f"승률 {fmt_num(_stat_win_rate(stat), 1)}%" if _stat_win_rate(stat) is not None else "승률 정보없음",
        f"합산 {fmt_pct(_stat_total(stat), 3)}",
        f"평균 {fmt_pct(_stat_avg(stat), 3)}",
    ]
    if include_path:
        mfe = num(stat.get("avg_mfe_pct"), stat.get("mfe"), stat.get("mfe_median_pct"), default=None)
        mae = num(stat.get("avg_mae_pct"), stat.get("mae"), stat.get("mae_median_pct"), default=None)
        giveback = num(stat.get("avg_giveback_pct"), stat.get("giveback"), stat.get("giveback_median_pct"), default=None)
        if mfe is not None:
            parts.append(f"MFE {mfe:+.3f}%")
        if mae is not None:
            parts.append(f"MAE {mae:+.3f}%")
        if giveback is not None:
            parts.append(f"반납 {giveback:+.3f}%")
    return " · ".join(parts)


def _performance_snapshot() -> Dict[str, Any]:
    obj = current_json(PATHS.performance, {}) or {}
    return obj if isinstance(obj, dict) else {}


def _ops_snapshot() -> Dict[str, Any]:
    obj = current_json(PATHS.ops_snapshot, {}) or {}
    return obj if isinstance(obj, dict) else {}


def _candidate_snapshot() -> Dict[str, Any]:
    obj = current_json(PATHS.candidate_standard, {}) or {}
    return obj if isinstance(obj, dict) else {}


def _paper_status() -> Dict[str, Any]:
    obj = current_json(PATHS.paper_status, {}) or {}
    return obj if isinstance(obj, dict) else {}


def render_flow_map_compact(_args: Sequence[str] = ()) -> str:
    obj = _ops_snapshot()
    if not obj:
        return "🗺️ 운영지도 · 핵심\n🚦 전체 🟡 CHECK_SOURCE\n- Guard의 canonical 운영지도 snapshot 대기\n- 자동매수 OFF"
    current = mapping(obj.get("current_cycle"))
    timing = mapping(obj.get("timing"))
    problems = [x for x in (obj.get("problems") or []) if isinstance(x, dict)]
    overall = obj.get('overall_state') or 'CHECK'
    lines = [
        "🗺️ 운영지도 · 한눈에 보기",
        f"🚦 전체 {icon(overall)} {overall}",
        "",
        "📍 현재 cycle",
        f"- 상태 {icon(current.get('state'))} {current.get('state') or 'CHECK'}",
        f"- 전체 후보 {integer(current.get('candidate_rows'))} → S1 {integer(current.get('s1_count'))} → Paper 확인 {integer(current.get('paper_received'))}",
        "",
        "⏱️ 처리속도",
        f"- Strategy 전달 {fmt_sec(timing.get('strategy_execution_handoff_sec'))}",
        f"- Strategy 전체 {fmt_sec(timing.get('strategy_full_cycle_sec'))} · Paper core {fmt_sec(timing.get('paper_fast_cycle_sec'))}",
        "",
        f"🧯 현재 문제 {len(problems)}개",
    ]
    if not problems:
        lines.append("- 없음")
    for item in problems[:3]:
        lines.append(f"- {item.get('code') or '-'} · {item.get('reason') or '원인 정보없음'}")
    lines += ["", "- 전략수치·청산계약 변경 없음 · 자동매수 OFF"]
    return "\n".join(lines)


def render_flow_map_full(_args: Sequence[str] = ()) -> str:
    obj = _ops_snapshot()
    if not obj:
        return render_flow_map_compact()
    overall = text(obj.get("overall_state"), default="CHECK")
    current = mapping(obj.get("current_cycle"))
    last = mapping(obj.get("last_completed_cycle"))
    timing = mapping(obj.get("timing"))
    disk = mapping(obj.get("disk"))
    lines = [
        f"코인봇 운영지도 {RELEASE_TAG}",
        "=" * 72,
        "",
        "[1. 한눈에 보기]",
        render_flow_map_compact(),
        "",
        "[2. 현재·직전 cycle 분리]",
        f"- 현재: {icon(current.get('state'))} {current.get('state') or 'CHECK'} / cycle {current.get('pipeline_cycle_id') or '-'} / commit {current.get('candidate_commit_id') or '-'}",
        f"- 현재 후보: 전체 {integer(current.get('candidate_rows'))} / S1 {integer(current.get('s1_count'))} / Paper 확인 {integer(current.get('paper_received'))}",
        f"- 직전 완료: {last.get('state') or 'CHECK'} / cycle {last.get('pipeline_cycle_id') or '-'} / commit {last.get('candidate_commit_id') or '-'}",
        "",
        "[3. 20단계 흐름]",
    ]
    for row in obj.get("stages") or []:
        if not isinstance(row, dict):
            continue
        io = ""
        if row.get("input") is not None or row.get("output") is not None:
            io = f" · 입력 {row.get('input')} → 출력 {row.get('output')}"
        reason = f" · 이유 {row.get('reason')}" if row.get("reason") else ""
        lines.append(
            f"{int(row.get('index') or 0):02d}. {icon(row.get('state'))} {row.get('label') or row.get('key')}"
            f"{io} · owner {row.get('owner') or '-'}{reason}"
        )
    problems = [x for x in (obj.get("problems") or []) if isinstance(x, dict)]
    lines += ["", "[4. 중요 오류와 조치]"]
    if not problems:
        lines.append("- 없음")
    for idx, item in enumerate(problems[:15], 1):
        lines.append(
            f"{idx}. {icon(item.get('state'))} {item.get('code') or '-'}\n"
            f"   원인: {item.get('reason') or '원인 정보없음'}\n"
            f"   영향: {item.get('impact') or '영향 정보없음'}\n"
            f"   owner: {item.get('owner') or '-'}"
        )
    lines += [
        "",
        "[5. 속도·자원]",
        f"- Strategy 전달 {fmt_sec(timing.get('strategy_execution_handoff_sec'))} / 전체 {fmt_sec(timing.get('strategy_full_cycle_sec'))}",
        f"- Paper core {fmt_sec(timing.get('paper_fast_cycle_sec'))} / Review {fmt_sec(timing.get('review_cycle_sec'))}",
        f"- 디스크 남음 {disk.get('free_mb') if disk.get('free_mb') is not None else '정보없음'}MB",
        "",
        "[판독 원칙]",
        "- 현재 cycle과 직전 완료 cycle을 섞지 않음",
        "- Main은 Guard snapshot을 표시만 하며 재계산하지 않음",
        "- 구 cache fallback 없음",
        "- Gate·trigger·invalid·target·RR·청산계약 변경 없음",
        "- 자동매수 OFF",
    ]
    return "\n".join(lines)


def render_candidate_compact(_args: Sequence[str] = ()) -> str:
    obj = _candidate_snapshot()
    if not obj:
        return "📐 후보 기준판 · 핵심\n🚦 판정 🟡 CHECK_SOURCE\n- Review canonical 기준판 대기\n- 과거판 fallback 없음 · 자동매수 OFF"
    delivery = mapping(obj.get("delivery"))
    candidate = mapping(obj.get("candidate"))
    time_info = mapping(obj.get("time"))
    performance = mapping(obj.get("performance"))
    missing = list(obj.get('missing') or [])
    lines = [
        "📐 후보 기준판 · 한눈에 보기",
        f"🚦 판정 {icon(obj.get('state'))} {obj.get('state') or 'CHECK'} · {obj.get('easy_state') or '-'}",
        "",
        "🚰 후보 전달",
        f"- 전체 {integer(candidate.get('total'))} → S1 {integer(candidate.get('s1'))} / S2 {integer(candidate.get('s2'))} / S3 {integer(candidate.get('s3'))}",
        f"- cycle {delivery.get('pipeline_cycle_id') or '-'}",
        f"- commit {delivery.get('candidate_commit_id') or '-'}",
        "",
        "⏱️ 시간",
        f"- Strategy 전달 {fmt_sec(time_info.get('strategy_execution_handoff_sec'))} · occurrence 중앙 {fmt_sec(time_info.get('occurrence_age_median_sec'))}",
        "",
        "📊 fresh CLOSED",
        f"- n{integer(performance.get('count'))} · 승률 {fmt_num(performance.get('win_rate'), 1)}% · 합산 {fmt_pct(performance.get('sum_pct'))}",
        "",
        f"🧩 원천 누락 {len(missing)}개" + (f" · {', '.join(str(x) for x in missing[:4])}" if missing else " · 없음"),
        "- 전략수치·청산계약 변경 없음 · 자동매수 OFF",
    ]
    return "\n".join(lines)


def render_candidate_standard(_args: Sequence[str] = ()) -> str:
    obj = _candidate_snapshot()
    if not obj:
        return render_candidate_compact()
    delivery = mapping(obj.get("delivery"))
    candidate = mapping(obj.get("candidate"))
    structure = mapping(obj.get("structure"))
    quality = mapping(obj.get("quality"))
    time_info = mapping(obj.get("time"))
    performance = mapping(obj.get("performance"))
    contract = mapping(obj.get("contract"))
    lines = [
        f"코인봇 후보·구조 기준판 {RELEASE_TAG}",
        "=" * 72,
        "",
        "[한눈에 보기]",
        render_candidate_compact(),
        "",
        "[숫자 범위 · 섞어 보지 않음]",
        f"- 전달: {mapping(obj.get('scope')).get('delivery') or 'current Strategy committed generation'}",
        f"- 후보: {mapping(obj.get('scope')).get('candidate') or 'same candidate commit rows'}",
        f"- 성과: {mapping(obj.get('scope')).get('performance') or 'Paper canonical performance snapshot only'}",
        "",
        "[후보 전달 배관]",
        f"- cycle {delivery.get('pipeline_cycle_id') or '-'}",
        f"- commit {delivery.get('candidate_commit_id') or '-'}",
        f"- source state {delivery.get('state') or '-'} / age {fmt_sec(delivery.get('request_age_sec'))}",
        "",
        "[구조선 근거 완전성]",
        f"- 평가 {integer(structure.get('evaluated'))} / 근거완전 {integer(structure.get('complete'))} / source missing {integer(structure.get('source_missing'))}",
        f"- trigger source 누락 {integer(structure.get('trigger_source_missing'))} / invalid {integer(structure.get('invalid_source_missing'))} / target {integer(structure.get('target_source_missing'))}",
        "",
        "[후보 품질 · 같은 commit]",
    ]
    labels = {
        "price_reaction": "가격반응", "relative_strength": "상대강도", "money_flow": "money flow",
        "buy_ratio": "매수체결 비율", "buy_sustain": "매수지속", "rank_score": "rank score",
        "rr": "실제 진입 RR", "target_room": "target 공간%", "invalid_distance": "invalid 거리%",
        "chase": "추격률%", "spread": "spread%", "slippage": "slippage%",
    }
    for key, label in labels.items():
        metric = mapping(quality.get(key))
        lines.append(f"- {label}: n{integer(metric.get('n'))} / 중앙 {fmt_num(metric.get('median'), 3)}")
    lines += [
        "",
        "[시간 경로]",
        f"- occurrence age: n{integer(time_info.get('occurrence_age_count'))} / 중앙 {fmt_sec(time_info.get('occurrence_age_median_sec'))}",
        f"- Strategy 전달 {fmt_sec(time_info.get('strategy_execution_handoff_sec'))} / 전체 {fmt_sec(time_info.get('strategy_full_cycle_sec'))}",
        "",
        "[fresh 성과]",
        stat_line("fresh CLOSED", performance),
        f"- snapshot {performance.get('snapshot_id') or '-'} / owner {performance.get('source_owner') or '-'}",
        "",
        "[Paper 실행·청산 계약]",
        f"- 상태 {contract.get('state') or '정보없음'} / owner {contract.get('owner') or '정보없음'}",
        "- 이 기준판은 현재 계약을 표시만 하며 변경하지 않음",
        "",
        "[원천 누락]",
        "- " + (", ".join(str(x) for x in (obj.get("missing") or [])) if obj.get("missing") else "없음"),
        "",
        "[잠금]",
        "- 후보식·trigger·invalid·target·RR·청산계약 변경 없음",
        "- 자동매수 OFF",
    ]
    return "\n".join(lines)


def render_health(_args: Sequence[str] = ()) -> str:
    obj = _ops_snapshot()
    workers = mapping(obj.get("workers"))
    disk = mapping(obj.get("disk"))
    lines = [
        f"🩺 코인봇 상태 · {BOT_VERSION}",
        f"- 운영지도: {icon(obj.get('overall_state'))} {obj.get('overall_state') or 'CHECK_SOURCE'}",
        f"- snapshot age: {fmt_sec(file_age(PATHS.ops_snapshot))}",
        f"- 디스크 남음: {disk.get('free_mb') if disk.get('free_mb') is not None else '정보없음'}MB",
        "- 자동매수: OFF",
        "",
        "[공장 상태]",
    ]
    if not workers:
        lines.append("- Guard snapshot 없음")
    for key, item in workers.items():
        if not isinstance(item, dict):
            continue
        lines.append(
            f"- {icon(item.get('state'))} {key}: {item.get('state') or 'CHECK'} · "
            f"{item.get('version') or '-'} · age {fmt_sec(item.get('age_sec'))} · phase {item.get('phase') or '-'}"
        )
    return "\n".join(lines)


def render_swing_status(_args: Sequence[str] = ()) -> str:
    standard = _candidate_snapshot()
    paper = _paper_status()
    contract = mapping(standard.get("contract"))
    return "\n".join([
        "🎯 ALT_SWING 상태",
        f"- 전략모드: {STRATEGY_MODE}",
        "- 시간축: 4h·2h 대세/target → 1h·30m setup/invalid → 15m·5m trigger → 1m·호가 실행비용",
        f"- 후보 기준판: {icon(standard.get('state'))} {standard.get('state') or 'CHECK_SOURCE'}",
        f"- Paper: {paper.get('version') or paper.get('paper_version') or '-'} / phase {paper.get('runtime_phase_v994') or paper.get('phase') or paper.get('startup_phase') or '-'}",
        f"- 실행 core: {'정상 분리' if paper.get('paper_fast_core_v1181') is True else '확인 필요'} / cycle {fmt_sec(paper.get('elapsed_sec'))}",
        f"- 계약 owner: {contract.get('owner') or '정보없음'}",
        "- 후보식·Gate·trigger·invalid·target·RR·청산계약 변경 없음",
        "- 자동매수 OFF",
    ])


def render_pstatus(_args: Sequence[str] = ()) -> str:
    obj = _paper_status()
    if not obj:
        return "📄 Paper 상태\n- CHECK_SOURCE · paper_bot_status.json 없음\n- 자동매수 OFF"
    stats = mapping(obj.get("pick_stats"))
    post = mapping(obj.get("paper_postprocess_v1181"))
    return "\n".join([
        "📄 Paper 실행 core",
        f"- 상태: {icon('NORMAL' if obj.get('running') is not False else 'FAIL')} {'실행 중' if obj.get('running') is not False else '중지'}",
        f"- 버전: {obj.get('version') or obj.get('paper_version') or '-'} / {obj.get('build') or '-'}",
        f"- phase: {obj.get('runtime_phase_v994') or obj.get('phase') or obj.get('startup_phase') or '-'}",
        f"- cycle: {fmt_sec(obj.get('elapsed_sec'))}",
        f"- OPEN: {integer(obj.get('open_count'), obj.get('open_total'))} / 신규 {integer(obj.get('opened_this_cycle'))} / CLOSED {integer(obj.get('closed_this_cycle'))}",
        f"- batch prepared/committed: {integer(stats.get('open_batch_prepared_v1180'))}/{integer(stats.get('open_batch_committed_v1180'))}",
        f"- OPEN snapshot write: {integer(stats.get('open_snapshot_write_count_v1180'))} / decision write: {integer(stats.get('decision_state_write_count_v1180'))}",
        f"- 후처리: {post.get('state') or '수집 중'} · {fmt_sec(post.get('elapsed_sec'))}",
        "- 자동매수 OFF",
    ])


def _open_rows() -> List[Dict[str, Any]]:
    obj = current_json(PATHS.paper_open, {}) or {}
    rows: List[Dict[str, Any]] = []
    if isinstance(obj, list):
        rows = [dict(x) for x in obj if isinstance(x, dict)]
    elif isinstance(obj, dict):
        for key, value in obj.items():
            if isinstance(value, dict):
                row = dict(value)
                row.setdefault("pos_id", key)
                rows.append(row)
    return rows


def render_popen(args: Sequence[str] = ()) -> str:
    rows = _open_rows()
    ticker_filter = str(args[0]).upper() if args else ""
    if ticker_filter:
        rows = [row for row in rows if ticker_filter in str(row.get("ticker") or row.get("market") or "").upper()]
    lines = [f"📂 현재 OPEN {len(rows)}개"]
    for row in rows[:30]:
        pnl = num(row.get("pnl_pct"), row.get("current_pnl_pct"), row.get("unrealized_pnl_pct"), default=None)
        lines.append(
            f"- {row.get('ticker') or row.get('market') or '-'} · 진입 {row.get('entry_price') or '-'} · "
            f"현재 {row.get('current_price') or row.get('last_price') or '-'} · 손익 {fmt_pct(pnl)} · pos {row.get('pos_id') or '-'}"
        )
    if not rows:
        lines.append("- 없음")
    if len(rows) > 30:
        lines.append(f"- 외 {len(rows)-30}개 · 상세는 /open_book_audit")
    return "\n".join(lines)


def _window_stat(snapshot: Mapping[str, Any], *names: str) -> Dict[str, Any]:
    windows = mapping(snapshot.get("windows"))
    for name in names:
        value = windows.get(name)
        if isinstance(value, dict):
            return value
    return {}


def _book_map(snapshot: Mapping[str, Any]) -> Dict[str, Any]:
    return _deep_mapping(
        snapshot,
        "book_performance",
        "book_performance_v1043",
        "open_book",
        "diagnostics_v1010.book_performance",
    )


def _fresh_epoch(snapshot: Mapping[str, Any]) -> Dict[str, Any]:
    return _deep_mapping(
        snapshot,
        "performance_epoch_v1045.stats",
        "performance_epoch_v1045.windows.all",
        "fresh_epoch_stats",
        "fresh_epoch",
        "summary",
    )


def _recent_diag(snapshot: Mapping[str, Any]) -> Dict[str, Any]:
    return _deep_mapping(snapshot, "diagnostics_v1010.recent_24h", "diagnostics.recent_24h")


def render_version_score(_args: Sequence[str] = ()) -> str:
    snapshot = _performance_snapshot()
    if not snapshot:
        return "📊 성과 /version_score · canonical 단일본선\n❌ canonical snapshot 준비 안 됨\n- 구 cache fallback 없음"
    counts = mapping(snapshot.get("counts"))
    fresh = _fresh_epoch(snapshot)
    if not fresh:
        fresh = _window_stat(snapshot, "all")
    book = _book_map(snapshot)
    diag = _recent_diag(snapshot)
    reasons = mapping(diag.get("primary_exit_reason"))
    tags = mapping(diag.get("auxiliary_loss_tags"))
    methods = mapping(diag.get("by_entry_method"))
    source_perf = _deep_mapping(snapshot, "source_inflow_performance", "by_source_lane", "diagnostics_v1010.source_inflow_performance")
    age = file_age(PATHS.performance)
    trust_state = "NORMAL" if age is not None and age <= 900 else "CHECK"
    lines = [
        "📊 성과 /version_score · canonical 단일본선",
        "",
        "[성과 신뢰판정]",
        f"- 데이터 신뢰: {icon(trust_state)} {trust_state} / snapshot age {fmt_sec(age)}",
        f"- snapshot: {snapshot.get('snapshot_id') or '-'}",
        f"- 생성: {snapshot.get('generated_at_text') or snapshot.get('generated_at') or snapshot.get('generated_text') or '-'}",
        f"- owner: {snapshot.get('source_owner') or snapshot.get('owner') or '-'}",
        "- Main 독립 재계산·구 cache fallback 없음",
        "",
        "[시간별 실현 CLOSED · 현재 흐름 먼저]",
    ]
    windows_to_show = [
        ("최근 3시간", ("recent_3h", "last_3h")),
        ("최근 6시간", ("recent_6h", "last_6h")),
        ("최근 24시간", ("recent_24h", "last_24h")),
        ("오늘", ("today",)),
        ("어제", ("yesterday",)),
    ]
    for label, names in windows_to_show:
        lines.append(stat_line(label, _window_stat(snapshot, *names)))
    lines += [
        "",
        "[새 성과구간 · fresh exact CLOSED]",
        stat_line("새 성과구간", fresh),
        "",
        "[전체 누적 · 참고값]",
        stat_line("전체", _window_stat(snapshot, "all")),
    ]

    lines += ["", "━━━━━━━━━━━━━━━━━━━━", "⚖️ CLOSED + 현재 OPEN 함께 보기", "━━━━━━━━━━━━━━━━━━━━"]
    closed_stat = mapping(book.get("fresh_closed"), fresh)
    open_stat = mapping(book.get("fresh_open"), book.get("current_open"), book.get("current"))
    combined = mapping(book.get("fresh_closed_plus_open"), book.get("combined"))
    if closed_stat or open_stat or combined:
        lines.append(stat_line("fresh CLOSED", closed_stat))
        lines.append(stat_line("현재 OPEN", open_stat, include_path=False))
        lines.append(stat_line("CLOSED+OPEN 단순합", combined, include_path=False))
        account = num(book.get("account_weighted_compound_pct"), book.get("account_compound_pct"), default=None)
        lines.append(f"- 계좌 가중 누적수익률: {fmt_pct(account)}")
    else:
        lines.append("- Paper canonical book 성과 필드 수집 중")
    lines.append("- 거래별 % 단순합은 계좌 누적수익률이 아님")

    if source_perf:
        lines += ["", "[유입경로별 fresh CLOSED 성과]"]
        for name, stat in sorted(source_perf.items(), key=lambda item: _stat_count(item[1] if isinstance(item[1], dict) else {}), reverse=True):
            if isinstance(stat, dict):
                lines.append(stat_line(str(name), stat))

    if reasons:
        lines += ["", "[주 청산원인 · 거래당 1개]"]
        for name, stat in sorted(reasons.items(), key=lambda item: _stat_count(item[1] if isinstance(item[1], dict) else {}), reverse=True)[:12]:
            if isinstance(stat, dict) and _stat_count(stat):
                lines.append(stat_line(str(name), stat))
    if tags:
        lines += ["", "[보조 손실태그 · 서로 중복 가능]"]
        labels = {
            "positive_mfe_then_loss": "수익구간 후 손실전환",
            "no_positive_mfe": "양수 MFE 없이 종료",
            "mfe_missing": "MFE 미기록",
            "repeated_ticker_entry": "반복 종목 진입",
        }
        for key, label in labels.items():
            stat = mapping(tags.get(key))
            if stat and _stat_count(stat):
                lines.append(stat_line(label, stat))
    if methods:
        lines += ["", "[실제 진입방식별 · 최근 24시간]"]
        for name, stat in sorted(methods.items(), key=lambda item: _stat_count(item[1] if isinstance(item[1], dict) else {}), reverse=True)[:10]:
            if isinstance(stat, dict):
                lines.append(stat_line(str(name), stat))

    recent = snapshot.get("recent_rows") if isinstance(snapshot.get("recent_rows"), list) else []
    lines += ["", "[최근 CLOSED 5건]"]
    if not recent:
        lines.append("- 정보없음")
    for row in recent[-5:]:
        if not isinstance(row, dict):
            continue
        lines.append(
            f"- {row.get('ticker') or row.get('market') or '-'} · {fmt_pct(row.get('net_pnl_pct') or row.get('pnl_pct'))} · "
            f"{row.get('reason') or row.get('exit_reason') or '-'} · MFE {fmt_pct(row.get('mfe_pct'))} / MAE {fmt_pct(row.get('mae_pct'))}"
        )
    lines += [
        "",
        "[snapshot·원장]",
        f"- raw {integer(counts.get('raw_ledger_rows'))} · exact {integer(counts.get('exact_unique_closed'), counts.get('included'))} · 중복 {integer(counts.get('duplicate_closed_rows'), counts.get('duplicates'))}",
        f"- key 누락 {integer(counts.get('missing_decision_key'), counts.get('missing_key'))} · 미연결 {integer(counts.get('decision_not_closed_or_missing'), counts.get('unlinked'))} · bad JSON {integer(counts.get('bad_json_rows'))}",
        "- 기술통계만 표시 · 전략 수치 자동 변경 없음",
        "- 자동매수 OFF",
    ]
    return "\n".join(lines)


def _score_period_icon(stat_obj: Any) -> str:
    stat = stat_obj if isinstance(stat_obj, dict) else {}
    total = _stat_total(stat)
    if total is None:
        return "⚪"
    if total > 0:
        return "✅"
    if total < 0:
        return "❌"
    return "➖"


def _score_period_lines(label: str, stat_obj: Any) -> List[str]:
    stat = stat_obj if isinstance(stat_obj, dict) else {}
    n = _stat_count(stat)
    if not stat and n == 0:
        return [f"⚪ {label} · 정보 수집 중"]
    return [
        f"{_score_period_icon(stat)} {label} · {n}전 {_stat_wins(stat)}승 {_stat_losses(stat)}패 · 승률 {fmt_num(_stat_win_rate(stat), 1)}%",
        f"   합산 {fmt_pct(_stat_total(stat), 2)} · 평균 {fmt_pct(_stat_avg(stat), 2)}",
    ]


def _open_book_lines(book: Mapping[str, Any], fallback_open_count: int = 0) -> List[str]:
    raw = dict(book or {})
    open_stat = mapping(raw.get("fresh_open"), raw.get("current_open"), raw.get("current"))
    open_count = integer(raw.get("open_count"), open_stat.get("count"), open_stat.get("n"), fallback_open_count, default=0)
    valid = integer(raw.get("valid_pnl_rows"), open_stat.get("count"), open_stat.get("n"), default=0)
    missing = integer(raw.get("missing_pnl_rows"), default=max(0, open_count - valid))
    current_total = num(raw.get("current_total"), _stat_total(open_stat), default=None)
    current_avg = num(raw.get("current_avg"), _stat_avg(open_stat), default=None)
    wins = integer(raw.get("wins"), open_stat.get("wins"), default=0)
    losses = integer(raw.get("losses"), open_stat.get("losses"), default=0)
    flats = integer(raw.get("flats"), default=max(0, valid - wins - losses))
    positive_total = num(raw.get("positive_total"), default=None)
    negative_total = num(raw.get("negative_total"), default=None)
    lines = [
        "━━━━━━━━━━━━━━━━━━━━",
        f"📦 현재 OPEN {open_count}개 · 미종료 거래",
        "━━━━━━━━━━━━━━━━━━━━",
    ]
    if not raw and not open_stat:
        lines += [
            "📊 평가손익 원천 수집 중",
            "- OPEN 수는 Paper epoch 기준 · 손익은 canonical book snapshot 대기",
        ]
        return lines
    lines += [
        f"📊 평가 가능 {valid}개 · 확인 필요 {missing}개",
        f"💰 전체 평가손익 {fmt_pct(current_total, 2)} · 평균 {fmt_pct(current_avg, 2)}",
        "",
        f"🟢 수익 {wins}개" + (f" · 합계 {fmt_pct(positive_total, 2)}" if positive_total is not None else ""),
        f"🔴 손실 {losses}개" + (f" · 합계 {fmt_pct(negative_total, 2)}" if negative_total is not None else ""),
        f"⚪ 보합 {flats}개",
    ]
    mfe_total = num(raw.get("mfe_total"), default=None)
    giveback_total = num(raw.get("giveback_total"), default=None)
    giveback_avg = num(raw.get("giveback_avg"), default=None)
    if mfe_total is not None or giveback_total is not None:
        lines += [
            "",
            f"🚀 보유 중 최고수익 합 {fmt_pct(mfe_total, 2)}",
            f"↩️ 현재까지 반납 합 {fmt_num(giveback_total, 2)}%p · 평균 {fmt_num(giveback_avg, 2)}%p",
        ]
    lines += [
        "⚠️ 위 CLOSED 승률에는 현재 OPEN이 포함되지 않음",
        "- 손익 합계는 종목별 수익률 단순합 · 계좌 가중수익률 아님",
    ]
    return lines


def render_version_score_compact(_args: Sequence[str] = ()) -> str:
    snapshot = _performance_snapshot()
    if not snapshot:
        return render_version_score()
    age = file_age(PATHS.performance)
    epoch = _deep_mapping(snapshot, "performance_epoch_v1045")
    fallback_open_count = integer(epoch.get("current_open_count"), default=0)
    lines = [
        "📊 성과 /version_score · canonical 단일본선",
        "",
        "[기간별 전략 결과 · 현재 흐름]",
        f"- 신뢰: {icon('NORMAL' if age is not None and age <= 900 else 'CHECK')} snapshot age {fmt_sec(age)}",
    ]
    windows_to_show = [
        ("오늘", ("today",)),
        ("어제", ("yesterday",)),
        ("최근 3시간", ("recent_3h", "last_3h")),
        ("최근 6시간", ("recent_6h", "last_6h")),
        ("최근 24시간", ("recent_24h", "last_24h")),
    ]
    for label, names in windows_to_show:
        lines.extend(_score_period_lines(label, _window_stat(snapshot, *names)))
    fresh = _fresh_epoch(snapshot)
    lines += [
        "",
        "━━━━━━━━━━━━━━━━━━━━",
        "🧪 새 성과구간 · fresh exact CLOSED",
        "━━━━━━━━━━━━━━━━━━━━",
    ]
    lines.extend(_score_period_lines("새 성과구간", fresh))
    lines.extend([""] + _open_book_lines(_book_map(snapshot), fallback_open_count))
    lines += [
        "",
        "📚 전체 누적 · 과거 참고",
    ]
    lines.extend(_score_period_lines("전체 누적", _window_stat(snapshot, "all")))
    lines += [
        f"- snapshot {snapshot.get('snapshot_id') or '-'}",
        "- 상세 원인·진입방식·최근거래는 TXT",
        "- 자동매수 OFF",
    ]
    return "\n".join(lines)


def render_performance_lab(_args: Sequence[str] = ()) -> str:
    snapshot = _performance_snapshot()
    if not snapshot:
        return "📈 /performance_lab\n- CHECK_SOURCE · canonical performance snapshot 없음"
    counts = mapping(snapshot.get("counts"))
    diag = _recent_diag(snapshot)
    overall = mapping(diag.get("overall_metrics"))
    classes = mapping(diag.get("contract_classification"))
    lines = [
        "📈 /performance_lab · canonical 단일본선",
        "",
        "[canonical 연결]",
        f"- snapshot {snapshot.get('snapshot_id') or '-'} / owner {snapshot.get('source_owner') or snapshot.get('owner') or '-'} / age {fmt_sec(file_age(PATHS.performance))}",
        f"- exact CLOSED {integer(counts.get('exact_unique_closed'), counts.get('included'))} · raw {integer(counts.get('raw_ledger_rows'))}",
        f"- 중복 {integer(counts.get('duplicate_closed_rows'))} · key 누락 {integer(counts.get('missing_decision_key'))} · 미연결 {integer(counts.get('decision_not_closed_or_missing'))}",
        "",
        "[최근 24시간 품질]",
        stat_line("전체", overall),
    ]
    if classes:
        lines += ["", "[계약 분류]"]
        for name, stat in classes.items():
            if isinstance(stat, dict):
                lines.append(stat_line(str(name), stat))
    lines += ["", "- Main은 snapshot을 읽기만 함 · 전략수치 변경 없음"]
    return "\n".join(lines)


def render_profit_audit(_args: Sequence[str] = ()) -> str:
    snapshot = _performance_snapshot()
    if not snapshot:
        return "💰 /profit_audit\n- CHECK_SOURCE · canonical performance snapshot 없음"
    book = _book_map(snapshot)
    source_perf = _deep_mapping(snapshot, "source_inflow_performance", "by_source_lane", "diagnostics_v1010.source_inflow_performance")
    lines = ["💰 수익성 감사 · canonical", stat_line("fresh CLOSED", _fresh_epoch(snapshot) or _window_stat(snapshot, "all"))]
    if book:
        lines += [stat_line("현재 OPEN", mapping(book.get("fresh_open"), book.get("current_open")), False), stat_line("CLOSED+OPEN", mapping(book.get("fresh_closed_plus_open"), book.get("combined")), False)]
    if source_perf:
        lines += ["", "[유입경로]"]
        for name, stat in source_perf.items():
            if isinstance(stat, dict):
                lines.append(stat_line(str(name), stat))
    lines += ["", "- 비용 후 기대값과 현재 OPEN 포함 결과가 검증되기 전 실매수 금지", "- 자동매수 OFF"]
    return "\n".join(lines)


def render_open_book_audit(_args: Sequence[str] = ()) -> str:
    snapshot = _performance_snapshot()
    book = _book_map(snapshot)
    rows = _open_rows()
    lines = ["📚 /open_book_audit · canonical OPEN", f"- 현재 OPEN row {len(rows)}"]
    if book:
        lines += [stat_line("현재 OPEN", mapping(book.get("fresh_open"), book.get("current_open"), book.get("current")), False), stat_line("CLOSED+OPEN", mapping(book.get("fresh_closed_plus_open"), book.get("combined")), False)]
    else:
        lines.append("- canonical OPEN 성과요약 수집 중")
    lines += ["", "[보유 표본]"]
    for row in rows[:20]:
        lines.append(f"- {row.get('ticker') or row.get('market') or '-'} · 손익 {fmt_pct(row.get('pnl_pct') or row.get('current_pnl_pct'))} · MFE {fmt_pct(row.get('mfe_pct'))} · MAE {fmt_pct(row.get('mae_pct'))}")
    if len(rows) > 20:
        lines.append(f"- 외 {len(rows)-20}개")
    lines += ["", "- OPEN/CLOSED/decision 원장 재작성 없음", "- 기존 OPEN 계약 변경 없음 · 자동매수 OFF"]
    return "\n".join(lines)


def render_book_reset_status(_args: Sequence[str] = ()) -> str:
    paths = [
        BASE_DIR / "paper_quality_rebuild_status_v1095.json",
        BASE_DIR / "paper_quality_rebuild_manifest_v1095.json",
        BASE_DIR / "paper_quality_rebuild_control_v1095.json",
        BASE_DIR / "paper_quality_rebuild_execution_v1045.json",
    ]
    objs = [(path, current_json(path, {}) or {}) for path in paths]
    lines = ["📘 /book_reset_status · canonical", "- 과거 reset·성과구간 참고판"]
    found = False
    for path, obj in objs:
        if isinstance(obj, dict) and obj:
            found = True
            lines.append(f"- {path.name}: {obj.get('state') or obj.get('status') or '기록 있음'} / age {fmt_sec(file_age(path))}")
    if not found:
        lines.append("- 현재 원천 없음 · 구 cache fallback 사용 안 함")
    lines += ["- 현재 전략·OPEN 계약 변경 없음 · 자동매수 OFF"]
    return "\n".join(lines)


def render_trade_review(_args: Sequence[str] = ()) -> str:
    obj = current_json(PATHS.review_snapshot, {}) or {}
    if not isinstance(obj, dict) or not obj:
        return "🔎 거래 복기\n- CHECK_SOURCE · Review snapshot 없음"
    candidate = mapping(obj.get("candidate"))
    structure = mapping(obj.get("structure"))
    timing = mapping(obj.get("time"))
    perf = mapping(obj.get("performance"))
    return "\n".join([
        "🔎 거래·후보 복기",
        f"- snapshot: {obj.get('snapshot_id') or '-'}",
        f"- 후보 {integer(candidate.get('total'))} / S1 {integer(candidate.get('s1'))}",
        f"- 구조근거 완전 {integer(structure.get('complete'))}/{integer(structure.get('evaluated'))}",
        f"- occurrence age 중앙 {fmt_sec(timing.get('occurrence_age_median_sec'))}",
        stat_line("fresh CLOSED", perf),
        "- 관찰값은 진입조건을 새로 만들지 않음",
    ])


def render_early_audit(_args: Sequence[str] = ()) -> str:
    standard = _candidate_snapshot()
    samples = [x for x in (standard.get("samples") or []) if isinstance(x, dict)]
    lines = ["🚀 /early_audit · 현재 candidate commit 표본", f"- 표본 {len(samples)}개"]
    for row in samples[:20]:
        lines.append(f"- {row.get('ticker') or row.get('market') or '-'} · grade {row.get('candidate_grade') or row.get('stage') or '-'} · source {row.get('source_lane') or row.get('candidate_source') or '-'}")
    if not samples:
        lines.append("- 표본 없음")
    lines += ["- 분석 전용 · selector 자동 반영 없음"]
    return "\n".join(lines)


def _ledger_path(kind: str) -> Optional[Path]:
    return find_ledger(BASE_DIR, kind)


def render_issue_ledger(_args: Sequence[str] = (), full: bool = False) -> str:
    path = _ledger_path("issue")
    if path is None:
        return "📒 문제장부\n- CHECK_SOURCE · canonical issue ledger 없음"
    rows = read_jsonl_tail(path, limit=3000 if full else 700)
    latest: Dict[str, Dict[str, Any]] = {}
    for row in rows:
        key = text(row.get("issue_id"), row.get("id"), row.get("key"))
        if key:
            latest[key] = row
    active = [row for row in latest.values() if str(row.get("status") or row.get("state") or "").upper() not in {"DONE", "CLOSED", "RESOLVED"}]
    lines = [f"📒 문제장부 · 활성 {len(active)}개", f"- source: {path.name}"]
    limit = 100 if full else 30
    for row in active[-limit:]:
        state = text(row.get("status"), row.get("state"), default="CHECK")
        lines.append(f"- {icon(state)} {row.get('issue_id') or row.get('id') or '-'} · {state}\n  {row.get('title') or row.get('detail') or row.get('symptom') or '내용 정보없음'}")
    if not active:
        lines.append("- 활성 issue 없음")
    return "\n".join(lines)


def render_change_verify(_args: Sequence[str] = (), full: bool = False) -> str:
    path = _ledger_path("change")
    if path is None:
        return "🧾 변경·검수장부\n- CHECK_SOURCE · canonical change ledger 없음"
    rows = read_jsonl_tail(path, limit=500 if full else 80)
    lines = ["🧾 변경·검수장부 · 최근 기록", f"- source: {path.name}"]
    limit = 100 if full else 20
    for row in rows[-limit:]:
        state = text(row.get("verify_result"), row.get("status"), default="CHECK")
        lines.append(f"- {icon(state)} {row.get('change_id') or row.get('id') or '-'} · {state}\n  {row.get('symptom') or row.get('new_mainline') or row.get('detail') or '-'}")
    return "\n".join(lines)


def render_ledger_audit(_args: Sequence[str] = ()) -> str:
    snapshot = _performance_snapshot()
    counts = mapping(snapshot.get("counts"))
    return "\n".join([
        "📚 /ledger_audit · canonical",
        f"- snapshot {snapshot.get('snapshot_id') or '-'} / age {fmt_sec(file_age(PATHS.performance))}",
        f"- raw {integer(counts.get('raw_ledger_rows'))} / exact {integer(counts.get('exact_unique_closed'), counts.get('included'))}",
        f"- 중복 {integer(counts.get('duplicate_closed_rows'), counts.get('duplicates'))}",
        f"- decision key 누락 {integer(counts.get('missing_decision_key'), counts.get('missing_key'))}",
        f"- decision 미연결 {integer(counts.get('decision_not_closed_or_missing'), counts.get('unlinked'))}",
        f"- bad JSON {integer(counts.get('bad_json_rows'))}",
        "- 원장 삭제·축소·재작성 없음",
    ])


def render_errorlog(_args: Sequence[str] = ()) -> str:
    lines = safe_error_tail(BASE_DIR, max_lines=80)
    if not lines:
        return "🧯 /errorlog · canonical\n\n✅ 새 실행 중 오류 없음"
    return "🧯 /errorlog · canonical\n\n" + "\n".join(lines[-80:])


def render_readiness(_args: Sequence[str] = ()) -> str:
    ops = _ops_snapshot()
    standard = _candidate_snapshot()
    paper = _paper_status()
    performance = _performance_snapshot()
    checks = [
        ("운영 흐름", ops.get("overall_state") == "NORMAL"),
        ("후보 기준판", standard.get("state") == "NORMAL"),
        ("Paper 실행 core", paper.get("paper_fast_core_v1181") is True),
        ("성과 snapshot", bool(performance.get("snapshot_id"))),
        ("자동매수 OFF", True),
    ]
    ready = all(value for _label, value in checks[:-1])
    lines = [f"🚦 준비도 · {'🟢 REVIEWABLE' if ready else '🟡 CHECK'}"]
    for label, value in checks:
        lines.append(f"- {'✅' if value else '⚠️'} {label}")
    lines.append("- 실매수는 사용자 승인 전 항상 OFF")
    return "\n".join(lines)


def render_commands(_args: Sequence[str] = ()) -> str:
    return "\n".join([
        "🧭 코인봇 메뉴 · canonical",
        "",
        "[평소 확인]",
        "/batch - 운영 핵심 + Telegram 요약 + TXT 1개",
        "/health - 공장·자원 상태",
        "/core /deploy /upgradestatus - 이전 상태명령 호환",
        "/swing_status - ALT_SWING 계약·runtime",
        "/version_score - 최근 3h·6h·24h·오늘·어제 성과",
        "/popen [티커] - 현재 OPEN",
        "/trade_review - 후보·거래 복기",
        "",
        "[지도·후보]",
        "/flow_map_full - 전체 20단계 지도 + TXT",
        "/candidate_standard - 후보·구조 기준판 + TXT",
        "/readiness_board - 실매매 준비도",
        "",
        "[정밀 확인]",
        "/batch_full - 정밀 명령 + TXT 1개",
        "/performance_lab - 성과 배관·계약 분류",
        "/profit_audit - 유입경로·CLOSED+OPEN",
        "/open_book_audit - 현재 OPEN 전수판",
        "/book_reset_status - 성과구간 참고판",
        "/early_audit - 현재 candidate 표본",
        "/ledger_audit - 중복·key 누락·미연결",
        "/issue_ledger /issue_history - 문제장부",
        "/change_verify /change_verify_full - 변경장부",
        "/errorlog - 오류",
        "",
        "[편의]",
        "- 여러 명령을 한 메시지에 줄바꿈해 보내면 각각 실행하고 TXT 1개로 묶음",
        "- Telegram은 핵심, TXT는 같은 snapshot의 상세",
        "- 자동매수 OFF",
    ])


Render = Callable[[Sequence[str]], str]
COMMANDS: Dict[str, Render] = {
    "flow_map": render_flow_map_compact,
    "flow_map_full": render_flow_map_full,
    "ops_map": render_flow_map_full,
    "candidate_standard": render_candidate_standard,
    "candidate_standard_full": render_candidate_standard,
    "candidate_reason": render_candidate_standard,
    "quality": render_candidate_standard,
    "structure_board": render_candidate_standard,
    "health": render_health,
    "core": render_health,
    "deploy": render_health,
    "upgradestatus": render_health,
    "swing_status": render_swing_status,
    "pstatus": render_pstatus,
    "paper_handoff": render_pstatus,
    "popen": render_popen,
    "version_score": render_version_score,
    "score": render_version_score,
    "performance_lab": render_performance_lab,
    "profit_audit": render_profit_audit,
    "open_book_audit": render_open_book_audit,
    "book_reset_status": render_book_reset_status,
    "trade_review": render_trade_review,
    "early_audit": render_early_audit,
    "issue_ledger": render_issue_ledger,
    "issue_history": lambda args=(): render_issue_ledger(args, full=True),
    "change_verify": render_change_verify,
    "change_verify_full": lambda args=(): render_change_verify(args, full=True),
    "ledger_audit": render_ledger_audit,
    "readiness_board": render_readiness,
    "errorlog": render_errorlog,
    "commands": render_commands,
    "help": render_commands,
}

BATCH_DEFAULT = [
    "flow_map_full", "candidate_standard", "health", "swing_status", "version_score",
    "performance_lab", "change_verify", "issue_ledger", "errorlog",
]
BATCH_FULL = BATCH_DEFAULT + ["pstatus", "open_book_audit", "profit_audit", "ledger_audit", "readiness_board"]
BATCH_ALIASES = {"batch", "summary", "pbatch"}
SINGLE_TXT = {"flow_map_full", "candidate_standard", "version_score"}
ALWAYS_COMPACT = {"flow_map_full", "candidate_standard", "version_score", "issue_ledger", "change_verify", "errorlog"}


def render_command(name: str, args: Sequence[str] = ()) -> str:
    key = str(name or "").strip().lstrip("/").lower()
    renderer = COMMANDS.get(key)
    if renderer is None:
        return f"알 수 없는 명령: /{key}\n/commands에서 확인"
    try:
        return renderer(args)
    except Exception as exc:
        log_error(f"render_{key}", exc)
        return f"❌ /{key} 표시 실패\n- {type(exc).__name__}: {exc}"


def compact_command_output(name: str, body: str) -> str:
    key = str(name).lower()
    if key in {"flow_map", "flow_map_full", "ops_map"}:
        return render_flow_map_compact()
    if key in {"candidate_standard", "candidate_standard_full", "candidate_reason", "quality", "structure_board"}:
        return render_candidate_compact()
    if key in {"version_score", "score"}:
        return render_version_score_compact()
    lines = str(body or "").splitlines()
    if key == "errorlog":
        if any("새 실행 중 오류 없음" in line for line in lines):
            return "🧯 오류 요약\n- ✅ 새 실행 중 오류 없음"
        return "🧯 오류 요약\n" + "\n".join([line for line in lines[1:] if line.strip()][:6])
    if key == "issue_ledger":
        return "\n".join(lines[:15] + (["- 상세는 TXT"] if len(lines) > 15 else []))
    if key == "change_verify":
        return "\n".join(lines[:10] + (["- 상세는 TXT"] if len(lines) > 10 else []))
    if key in {"health", "performance_lab", "pstatus", "swing_status"}:
        return "\n".join(lines[:20])
    return "\n".join(lines[:14])


def parse_command_lines(raw: str) -> List[Tuple[str, List[str]]]:
    out: List[Tuple[str, List[str]]] = []
    for line in str(raw or "").splitlines():
        stripped = line.strip()
        if not stripped.startswith("/"):
            continue
        parts = stripped.split()
        name = parts[0].lstrip("/").split("@", 1)[0].lower()
        if name:
            out.append((name, parts[1:]))
    return out


def _unique_commands(items: Iterable[Tuple[str, List[str]]]) -> List[Tuple[str, List[str]]]:
    seen = set()
    result: List[Tuple[str, List[str]]] = []
    for name, args in items:
        key = (name, tuple(args))
        if key in seen:
            continue
        seen.add(key)
        result.append((name, list(args)))
    return result


def build_summary_text(order: Sequence[Tuple[str, List[str]]], outputs: Mapping[str, str], timings: Sequence[Mapping[str, Any]], total_sec: float, full_mode: bool = False) -> str:
    ops = _ops_snapshot()
    title = f"코인봇 통합 상세집 {RELEASE_TAG}" if full_mode else f"코인봇 운영 요약집 {RELEASE_TAG}"
    names = [name for name, _args in order]
    lines = [
        title,
        "=" * 72,
        f"- 생성: {now_text()} KST",
        f"- 메인봇: {BOT_VERSION} / {BUILD_LABEL}",
        f"- 요청·포함: {', '.join('/'+name for name in names)}",
        f"- 화면 생성 합계: {sum(float(x.get('sec') or 0.0) for x in timings):.2f}s",
        f"- Telegram·TXT 포함 총시간: {total_sec:.2f}s",
        f"- 운영지도 snapshot: {ops.get('snapshot_id') or '-'}",
        "- 자동매수: OFF",
        "",
        "[한눈에 보기]",
        render_flow_map_compact(),
        "",
        render_candidate_compact(),
        "",
        render_version_score_compact(),
        "",
        "[명령 처리시간]",
    ]
    for item in timings:
        lines.append(f"- {'✅' if item.get('ok') else '❌'} /{item.get('name')}: {float(item.get('sec') or 0.0):.2f}s")
    lines += ["", "=" * 72, "[상세 결과]"]
    for name, _args in order:
        lines += ["", f"## /{name}", "-" * 72, outputs.get(name, "")]
    lines += [
        "",
        "=" * 72,
        "[판독 원칙]",
        "- Telegram은 현재 상태·원인·우선순위만 표시",
        "- TXT는 같은 canonical snapshot의 상세 근거를 표시",
        "- Main 독립 재계산·구 cache fallback 없음",
        "- 전략수치·진입·청산계약 변경 없음",
        "- 자동매수 OFF",
    ]
    return "\n".join(lines)


def send_summary_file(update: Any, content: str) -> str:
    stamp = time.strftime("%Y%m%d_%H%M%S")
    path = BASE_DIR / f"coinbot_batch_summary_{stamp}.txt"
    sent = False
    try:
        path.write_text(content, encoding="utf-8")
        target = getattr(update, "effective_message", None) or getattr(update, "message", None)
        if target is None:
            raise RuntimeError("telegram message target missing")
        with path.open("rb") as handle:
            target.reply_document(document=handle, filename=path.name)
        sent = True
        return "TXT 전송완료 후 서버삭제"
    except Exception as exc:
        log_error("send_summary_file", exc)
        return f"TXT 전송실패 · 서버파일 유지 {path.name} · {type(exc).__name__}"
    finally:
        if sent:
            try:
                path.unlink(missing_ok=True)
            except OSError as exc:
                log_error("summary_delete", exc)


def collect_and_send(update: Any, requested: Sequence[Tuple[str, List[str]]], *, batch: bool = False, full_mode: bool = False) -> None:
    if not _chat_allowed(update) or not acquire_request(update):
        return
    if not _COMMAND_LOCK.acquire(blocking=False):
        send_text(update, "⏳ 메인봇 명령 묶음이 이미 실행 중\n- 잠시 뒤 다시 실행")
        return
    started = time.time()
    set_runtime_state(scan_running=True, scan_stage="command_collect")
    write_status("running", phase="command_collect")
    try:
        order = list(_unique_commands(requested))
        if batch:
            base_names = BATCH_FULL if full_mode else BATCH_DEFAULT
            existing = {name for name, _args in order}
            for name in base_names:
                if name not in existing:
                    order.append((name, []))
        # Remove aliases from execution list.
        order = [(name, args) for name, args in order if name not in BATCH_ALIASES and name != "batch_full"]
        send_text(update, f"📚 {'상세 batch' if full_mode else ('핵심 batch' if batch else '묶음 명령')} {len(order)}개 · {RELEASE_TAG} · TXT 1개")
        outputs: Dict[str, str] = {}
        timings: List[Dict[str, Any]] = []
        for idx, (name, args) in enumerate(order, 1):
            set_runtime_state(scan_running=True, scan_stage=f"{idx}/{len(order)} /{name}")
            write_status("running", phase="command_render")
            item_started = time.time()
            body = render_command(name, args)
            elapsed = time.time() - item_started
            ok = not body.startswith("❌")
            outputs[name] = body
            timings.append({"name": name, "sec": round(elapsed, 3), "ok": ok})
            # Explicit commands and the familiar batch cards are visible in Telegram.
            if not batch or name in {"flow_map_full", "candidate_standard", "health", "swing_status", "version_score", "issue_ledger", "errorlog"}:
                send_text(update, compact_command_output(name, body))
        set_runtime_state(scan_running=True, scan_stage="summary_txt")
        total = time.time() - started
        summary = build_summary_text(order, outputs, timings, total, full_mode=full_mode)
        status = send_summary_file(update, summary)
        payload = {
            "schema": "command_summary_status_v1185",
            "ok": status.startswith("TXT 전송완료"),
            "requested": [name for name, _args in requested],
            "included": [name for name, _args in order],
            "status": status,
            "txt_count": 1 if status.startswith("TXT 전송완료") else 0,
            "snapshot_id": _ops_snapshot().get("snapshot_id"),
            "render_sum_sec": round(sum(float(x.get("sec") or 0.0) for x in timings), 3),
            "delivery_total_sec": round(time.time() - started, 3),
            "updated_ts": now_ts(),
        }
        atomic_write_json(COMMAND_SUMMARY_STATUS, payload)
        send_text(update, f"✅ 완료 · 화면생성 {payload['render_sum_sec']:.2f}s / 전송포함 {payload['delivery_total_sec']:.2f}s / {status}")
    except Exception as exc:
        log_error("collect_and_send", exc)
        send_text(update, f"❌ 명령 묶음 실패\n- {type(exc).__name__}: {exc}")
    finally:
        set_runtime_state(scan_running=False, scan_stage="idle")
        write_status("running", phase="idle")
        _COMMAND_LOCK.release()


def make_handler(name: str):
    def handler(update: Any, context: Any) -> None:
        if not _chat_allowed(update):
            return
        raw = str(getattr(getattr(update, "effective_message", None), "text", "") or "")
        parsed = parse_command_lines(raw)
        if len(parsed) >= 2:
            batch = any(cmd in BATCH_ALIASES or cmd == "batch_full" for cmd, _args in parsed)
            full = any(cmd == "batch_full" for cmd, _args in parsed)
            collect_and_send(update, parsed, batch=batch, full_mode=full)
            return
        args = list(getattr(context, "args", []) or [])
        command = str(name).lower()
        if command in BATCH_ALIASES:
            collect_and_send(update, [(command, args)], batch=True, full_mode=False)
            return
        if command == "batch_full":
            collect_and_send(update, [(command, args)], batch=True, full_mode=True)
            return
        if command in SINGLE_TXT:
            collect_and_send(update, [(command, args)], batch=False, full_mode=False)
            return
        if not acquire_request(update):
            return
        started = time.time()
        set_runtime_state(scan_running=True, scan_stage=f"/{command}")
        write_status("running", phase="command_render")
        try:
            body = render_command(command, args)
            send_text(update, compact_command_output(command, body) if command in ALWAYS_COMPACT else body)
        finally:
            set_runtime_state(scan_running=False, scan_stage="idle")
            write_status("running", phase="idle", last_command=command, last_command_sec=round(time.time() - started, 3))
    return handler


def text_router(update: Any, _context: Any) -> None:
    raw = str(getattr(getattr(update, "effective_message", None), "text", "") or "").strip()
    parsed = parse_command_lines(raw)
    if not parsed:
        return
    batch = any(cmd in BATCH_ALIASES or cmd == "batch_full" for cmd, _args in parsed)
    full = any(cmd == "batch_full" for cmd, _args in parsed)
    if len(parsed) >= 2 or batch:
        collect_and_send(update, parsed, batch=batch, full_mode=full)
        return
    name, args = parsed[0]
    handler = make_handler(name)
    class Context:
        pass
    ctx = Context()
    ctx.args = args
    handler(update, ctx)


def heartbeat_loop() -> None:
    while not _STOP:
        try:
            warm_canonical_cache()
            write_status("running", phase=_SCAN_STAGE if _SCAN_RUNNING else "idle")
        except Exception as exc:
            log_error("heartbeat", exc)
        slept = 0.0
        while slept < HEARTBEAT_SEC and not _STOP:
            step = min(0.2, HEARTBEAT_SEC - slept)
            time.sleep(step)
            slept += step


def signal_handler(_signum: int, _frame: Any) -> None:
    global _STOP
    _STOP = True
    set_runtime_state(telegram_state="stopping", telegram_note="signal received")
    try:
        write_status("stopped", phase="shutdown")
    except Exception:
        pass


def set_commands(updater: Any) -> None:
    if BotCommand is None:
        return
    commands = [
        BotCommand("batch", "운영 핵심 + TXT"),
        BotCommand("batch_full", "정밀 상세 + TXT"),
        BotCommand("health", "공장·자원 상태"),
        BotCommand("core", "공장·배포 상태"),
        BotCommand("deploy", "공장·배포 상태"),
        BotCommand("upgradestatus", "업그레이드 상태"),
        BotCommand("swing_status", "ALT_SWING 계약"),
        BotCommand("version_score", "CLOSED+OPEN 성과"),
        BotCommand("popen", "현재 OPEN"),
        BotCommand("trade_review", "거래·후보 복기"),
        BotCommand("flow_map_full", "전체 20단계 지도"),
        BotCommand("candidate_standard", "후보·구조 기준판"),
        BotCommand("performance_lab", "성과 배관"),
        BotCommand("profit_audit", "수익성 감사"),
        BotCommand("open_book_audit", "OPEN 전수판"),
        BotCommand("ledger_audit", "원장 연결 감사"),
        BotCommand("change_verify", "수정검수 장부"),
        BotCommand("issue_ledger", "문제장부"),
        BotCommand("readiness_board", "실매매 준비도"),
        BotCommand("errorlog", "오류"),
        BotCommand("commands", "메뉴"),
    ]
    updater.bot.set_my_commands(commands)


# Register aliases after helper definitions.
COMMANDS["batch"] = lambda _args=(): "배치 handler 전용"
COMMANDS["batch_full"] = lambda _args=(): "상세 배치 handler 전용"
COMMANDS["summary"] = COMMANDS["batch"]
COMMANDS["pbatch"] = COMMANDS["batch"]


def main() -> int:
    signal.signal(signal.SIGTERM, signal_handler)
    signal.signal(signal.SIGINT, signal_handler)
    set_runtime_state(telegram_state="initializing", telegram_note="main boot")
    write_status("initializing", phase="boot")
    log_runtime(f"telegram_state=initializing version={BOT_VERSION} build={BUILD_LABEL}")
    threading.Thread(target=heartbeat_loop, name="main-heartbeat-v1186", daemon=True).start()
    if not TELEGRAM_TOKEN or Updater is None:
        set_runtime_state(telegram_state="disabled", telegram_note="headless_no_telegram")
        write_status("running", phase="headless_no_telegram", telegram=False)
        log_runtime(f"{BOT_VERSION} headless snapshot renderer active")
        while not _STOP:
            time.sleep(1.0)
        return 0
    try:
        updater = Updater(token=TELEGRAM_TOKEN, use_context=True)
        dispatcher = updater.dispatcher
        for name in sorted(COMMANDS):
            if re.fullmatch(r"[A-Za-z0-9_]+", name):
                dispatcher.add_handler(CommandHandler(name, make_handler(name)))
        # Non-command text containing slash-lines still uses the same multi-command router.
        if MessageHandler is not None and Filters is not None:
            dispatcher.add_handler(MessageHandler(Filters.text & (~Filters.command), text_router))
        set_commands(updater)
        set_runtime_state(telegram_state="commands_installed", telegram_note="telegram commands installed")
        write_status("running", phase="commands_installed", telegram=True)
        updater.start_polling(drop_pending_updates=True)
        set_runtime_state(telegram_state="polling_started", telegram_error="", telegram_note="command receive ready")
        write_status("running", phase="telegram_polling", telegram=True)
        log_runtime(f"{BOT_VERSION} telegram polling_started build={BUILD_LABEL}")
        try:
            if CHAT_ID:
                updater.bot.send_message(
                    chat_id=CHAT_ID,
                    text=(
                        f"✅ 메인봇 시작 완료\n- {BOT_VERSION}\n- {BUILD_LABEL}\n"
                        "- 기존 명령·요약집 편의 복원\n- canonical snapshot 전용\n- 자동매수 OFF"
                    ),
                )
        except Exception as exc:
            log_error("startup_notice", exc)
            set_runtime_state(telegram_state="polling_started_notify_failed", telegram_error=f"{type(exc).__name__}: {exc}", telegram_note="polling is active; startup notice failed")
            write_status("running", phase="telegram_polling", telegram=True)
        updater.idle()
    except Exception as exc:
        log_error("main", exc)
        set_runtime_state(telegram_state="error", telegram_error=f"{type(exc).__name__}: {exc}", telegram_note="main telegram loop failed")
        write_status("error", phase="telegram_error", telegram=False)
        return 1
    set_runtime_state(telegram_state="stopping", telegram_note="updater idle ended")
    write_status("stopped", phase="shutdown")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
