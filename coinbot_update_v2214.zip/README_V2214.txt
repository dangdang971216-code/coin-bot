코인봇 v2214

1. 이번 목적
   - 상승예측 재료 자체가 약한지, 원재료는 맞지만 현재 보정·해석이 망가뜨렸는지 분리한다.
   - 단순히 부호를 뒤집지 않고 반전·과열·지연·시간대 불일치·무효 재료를 구분한다.

2. 검증 방식
   - 같은 exact event key와 같은 완료봉 결과를 사용한다.
   - 진입 당시 봉인된 원시 axis와 현재 보정된 axis를 직접 비교한다.
   - 30분·1시간·3시간·6시간을 각각 본다.
   - 값 구간은 강한 음수/음수/중립/양수/강한 양수로 나눠 상승률·평균종가·MFE·MAE를 계산한다.

3. 판정
   - DIRECT: 현재 방향대로 높을수록 결과가 좋아짐
   - REVERSED: 현재 예상과 반대로 움직임
   - OVERHEAT: 중간값은 좋지만 과도하게 높으면 나빠짐
   - WEAK: 원재료와 보정값 모두 구분력이 약함
   - DELAYED/SHORT_ONLY/HORIZON_SPLIT: 유효 시간대가 다름
   - INTERPRETATION_DAMAGED: 원재료는 의미가 있는데 보정 후 나빠짐

4. 기존 Shadow
   - v2213 단일 실제거래 Shadow 계약·시작시각·표본을 그대로 보존한다.
   - 새 Shadow, 새 worker, 새 명령, 새 별도 원장을 만들지 않는다.

5. 변경하지 않은 것
   - 상승예측 식·가중치·양수 기준
   - 후보·S1·Paper 접수와 후보 수
   - Trigger·invalid·target·RR
   - 실제 진입·청산계약
   - Paper/Strategy/Core 및 성과 초기화
   - 자동매수 OFF

6. 배포 범위
   - Main v2.13.2179 / Review v2.093만 교체·재시작한다.
   - Paper v2.114 / Strategy v2.077 / Core v2176은 유지한다.

로컬 검수 PASS / 서버 적용·runtime·실제 factor 판정 CHECK.
