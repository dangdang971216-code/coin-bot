V1318: Paper selector / Review snapshot generation spine alignment. No strategy, trigger, RR, exit or auto-buy change.
