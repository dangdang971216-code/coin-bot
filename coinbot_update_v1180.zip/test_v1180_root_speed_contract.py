import importlib.util
from pathlib import Path

ROOT=Path('/mnt/data/v1180_work')

def load(name,path):
    spec=importlib.util.spec_from_file_location(name,str(path))
    mod=importlib.util.module_from_spec(spec)
    spec.loader.exec_module(mod)
    return mod

s=load('strategy_v1180_test',ROOT/'strategy_worker_v1.035.py')
assert s.VERSION=='strategy_worker_v1.035',s.VERSION
calls=[]
def base(rows,nowv):
    calls.append((len(rows),nowv)); return [dict(x,core=True) for x in rows]
s._v554_apply_entry_plan_state__L2086=base
out=s._v1180_apply_execution_entry_plan_core([{'ticker':'A'},{'ticker':'B'}],123.0)
assert len(calls)==1 and calls[0]==(2,123.0)
assert all(x.get('core') for x in out)
src=(ROOT/'strategy_worker_v1.035.py').read_text()
pos_core=src.index("'publish_entry_plan_core_v1180'")
pos_handoff=src.index("execution_handoff_completed_ts_v1179")
pos_observe=src.index("_v1180_enrich_observation_rows(rows, nowv)")
assert pos_core < pos_handoff < pos_observe
assert '_v554_apply_entry_plan_state(rows, nowv)' not in src[src.index('def _v510_publish'):pos_handoff]

p=load('paper_v1180_test',ROOT/'paper_bot_v1.044.py')
assert p.VERSION=='paper_bot_v1.044',p.VERSION
store=[]; decision_saves=[]; events=[]; path_events=[]
p.persist_open_positions=lambda obj: store.append(dict(obj)) or True
p._v926_load_decision_state=lambda: {'records':{}}
p._v926_save_decision_state=lambda obj: decision_saves.append(obj) or True
p._v938_quality_evidence_from_row=lambda row: {}
p._v1153_paper_event_once=lambda *a,**kw: 123.0
p._v1153_set_path_ts=lambda *a,**kw: path_events.append((a,kw))
p.append_jsonl=lambda *a,**kw: events.append((a,kw))
p._exact_commit_enter_v994=lambda: None
p._exact_commit_exit_v994=lambda: None
p._v926_decision_key_from_row=lambda row: row.get('paper_decision_key_v926')
p.normalize_ticker=lambda x: str(x or '')
p.now_ts=lambda: 1000.0
p.iso_ts=lambda x: 'T'
p.fnum=lambda *args,**kwargs: next((float(x) for x in args if x not in (None,'')),kwargs.get('default',0.0))
open_pos={'old':{'pos_id':'old','ticker':'OLD','paper_decision_key_v926':'d-old'}}
prepared=[]
for i in range(3):
    pid=f'p{i}'; pos={'pos_id':pid,'ticker':f'T{i}','paper_decision_key_v926':f'd{i}','opened_at':900+i}
    prepared.append((pid,pos,{'ticker':f'T{i}'}))
opened,traces=p._v1180_commit_open_batch(open_pos,prepared)
assert len(opened)==3 and len(traces)==3
assert len(store)==1,store
assert len(decision_saves)==1
assert len(open_pos)==4
assert len(events)==3

# decision failure must roll OPEN snapshot back in a second write and not mutate caller state
store2=[]
p.persist_open_positions=lambda obj: store2.append(dict(obj)) or True
p._v926_load_decision_state=lambda: {'records':{}}
p._v926_save_decision_state=lambda obj: False
open2={'old':{'pos_id':'old','ticker':'OLD','paper_decision_key_v926':'d-old'}}
failed=False
try:
    p._v1180_commit_open_batch(open2,prepared[:2])
except RuntimeError:
    failed=True
assert failed
assert len(store2)==2
assert set(store2[0])=={'old','p0','p1'} and set(store2[1])=={'old'}
assert set(open2)=={'old'}
print('PASS v1180 strategy single-core + paper one-batch commit/rollback')
