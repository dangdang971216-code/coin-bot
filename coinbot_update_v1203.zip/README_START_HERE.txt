코인봇 업데이트 v1203

목적: 후보 품질 기준판 증거 완성.
적용: Strategy v1.040 / Review v1.019 / Main v2.13.1137 / canonical spine v1187.
Paper v1.054와 Guard v2.5.206은 변경하지 않는다.

이 버전은 매매 기준을 바꾸지 않는다. Strategy가 이미 만든 값을 같은 candidate commit에서 읽어 보여준다.
서버 적용 전 상태는 CHECK_PENDING_DEPLOY다.
