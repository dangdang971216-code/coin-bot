#!/usr/bin/env python3
from __future__ import annotations
import importlib.util
import os
import tempfile
from pathlib import Path

HERE=Path(__file__).resolve().parent

def main():
    with tempfile.TemporaryDirectory() as td:
        os.environ['COINBOT_BASE_DIR']=td
        spec=importlib.util.spec_from_file_location('strategy1203',HERE/'strategy_worker_v1.040.py')
        mod=importlib.util.module_from_spec(spec); spec.loader.exec_module(mod)
        row={
            'ticker':'AAA','s_stage':'S1','current_price':100.0,
            'invalid_distance_pct':3.0,'trigger_chase_pct':0.5,
            'trigger_chase_source_v1203':'current_candidate_price_vs_frozen_trigger',
            'invalid_distance_source_v1203':'current_candidate_price_to_frozen_invalid',
            'scanner_occurrence_started_ts_v1203':123.0,'scanner_occurrence_key_v1203':'occ-1',
            'scanner_occurrence_source_v1203':'scanner_worker.hot_watch_occurrence_v945',
            'vwap_gap_pct':0.1,'ema5_gap_pct':0.2,'turnover_24h_for_quality_v1095':2_000_000_000,
            'turnover_rank_pct_v1095':80.0,'volume_ratio':1.5,'volume_expansion_pct':40.0,
            'recent_high_gap_pct':1.2,'day_pos_pct':70.0,'upper_wick_pct':0.3,'market_mode':'상승',
            'swing_gate_decision_key_v977':'dec','trigger_occurrence_candidate_key_v1037':'cand',
            'swing_entry_gate_v977':{'schema':'gate','decision_key':'dec','stage':'S1','hard_pass':True,'risk_reward':4.0,'target_room_pct':10.0,'invalid_distance_pct':3.0,'trigger_chase_pct':0.5},
        }
        out=mod._v861_compact_row_for_latest(row)
        for key in ('invalid_distance_pct','trigger_chase_pct','scanner_occurrence_started_ts_v1203','vwap_gap_pct','turnover_24h_for_quality_v1095','volume_ratio','market_mode'):
            assert out.get(key)==row.get(key),(key,out.get(key),row.get(key))
        source=Path(HERE/'strategy_worker_v1.040.py').read_text()
        assert "row['trigger_chase_pct']" in source
        assert "row['invalid_distance_pct']" in source
        print('PASS v1203 strategy evidence transport')

if __name__=='__main__':
    main()
