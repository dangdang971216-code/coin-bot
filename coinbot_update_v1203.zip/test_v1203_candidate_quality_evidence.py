#!/usr/bin/env python3
from __future__ import annotations
import importlib.util
import json
import os
import sys
import tempfile
import time
from pathlib import Path

HERE=Path(__file__).resolve().parent
sys.path.insert(0,str(HERE))
from canonical_spine_v1187 import SpinePaths, build_review_snapshot, build_candidate_standard, atomic_write_json


def write_jsonl(path: Path, rows):
    path.write_text(''.join(json.dumps(x,ensure_ascii=False)+'\n' for x in rows),encoding='utf-8')


def candidate(ticker: str, score: float, lane: str, now: float):
    return {
        'ticker':ticker,'s_stage':'S1','strategy_key':lane,'strategy_label':lane,
        'swing_gate_decision_key_v977':f'dec-{ticker}','trigger_occurrence_candidate_key_v1037':f'cand-{ticker}',
        'current_price':100.0,'swing_trigger_price_v977':99.5,'swing_invalid_price_v977':97.0,'swing_target_price_v977':112.0,
        'swing_trigger_source_v977':'15m resistance','swing_invalid_source_v977':'30m support','swing_target_source_v977':'4h resistance',
        'risk_reward_ratio':4.1,'target_room_pct':12.5,'invalid_distance_pct':3.0,'trigger_chase_pct':0.5025,
        'spread_pct':0.21,'slippage_pct':0.04,'price_reaction_pct':0.35,'relative_strength_rank_pct_v1095':72.0,
        'money_flow_score':68.0,'buy_ratio':0.66,'buy_sustain_1m':0.61,'vwap_gap_pct':0.15,'ema5_gap_pct':0.22,
        'turnover_24h_for_quality_v1095':2_500_000_000,'turnover_rank_pct_v1095':88.0,'volume_ratio':1.8,'volume_expansion_pct':42.0,
        'recent_high_gap_pct':1.2,'day_pos_pct':76.0,'upper_wick_pct':0.3,'change_1m':0.4,'change_3m':1.1,
        'price_age_sec':0.4,'micro_age_sec':0.8,'orderflow_age_sec':0.7,'market_mode':'상승',
        'scanner_occurrence_started_ts_v1203':now-45,'scanner_occurrence_key_v1203':f'occ-{ticker}',
        'actual_trigger_event_at_v1173':now-8,'s1_ready_at_v1173':now-3,
        'swing_quality_gate':{
            'quality_tier':'A','rank_score':score,'missing_axes':[],
            'score_components':{'structure':22.0,'reaction':14.0,'relative_strength':15.0,'money_flow':13.0,'execution':8.0},
        },
        'risk_tags':['테스트위험'],
    }


def main():
    with tempfile.TemporaryDirectory() as td:
        base=Path(td); paths=SpinePaths(base); now=time.time()
        rows=[candidate('AAA',81.0,'money_reaccel_s',now),candidate('BBB',75.0,'leader_momentum_s',now)]
        write_jsonl(paths.strategy_candidates,rows)
        atomic_write_json(paths.review_request,{'pipeline_cycle_id':'cycle-1','candidate_commit_id':'commit-1','candidate_rows':2,'updated_ts':now})
        atomic_write_json(paths.strategy_status,{'version':'strategy_worker_v1.040','elapsed_sec':9.0,'strategy_execution_handoff_sec':8.5})
        atomic_write_json(paths.paper_status,{
            'version':'paper_bot_v1.054',
            'paper_raw_intake_contract_v1174':{
                'state':'RAW_PAPER_NO_LATE_SAFETY_BLOCKS',
                'disabled_blockers':['OPEN total limit','cycle new-OPEN limit','micro freshness'],
                'kept_integrity':['Strategy exact S1 decision','exact decision duplicate','same ticker duplicate'],
                'candidate_quality_changed':False,'exit_contract_changed':False,
            },
            'effective_control_contract_v1142':{'exit_contract':{
                'swing_emergency_stop_pct':-2.5,'swing_no_progress_minutes':360,
                'swing_trailing_trigger_pct':2.0,'swing_trailing_giveback_pct':0.8,'time_exit_minutes':0,
            }},
        })
        atomic_write_json(paths.performance,{'snapshot_id':'perf-1','source_owner':'paper_bot_single_canonical_performance_writer','windows':{'all':{'count':10,'wins':6,'losses':4,'win_rate':60.0,'sum_pct':8.0,'avg_pct':0.8}},'counts':{}})
        atomic_write_json(base/'clean_candidate_standard_contract_v1141.json',{'schema':'contract','contract_digest':'abc','strategy_source_sha256':'def','invariants':{}})
        snap=build_review_snapshot(base)
        std=build_candidate_standard(snap)
        assert std['state']=='NORMAL',std
        q=std['quality']
        assert q['invalid_distance']['n']==2
        assert q['chase']['n']==2
        assert q['turnover_24h_krw']['n']==2
        assert std['time']['occurrence_age_count']==2
        assert std['contract']['paper']['count_policy']=='UNLIMITED'
        assert std['samples'][0]['ticker']=='AAA'
        assert std['quality']['lane_summaries']
        assert std['structure']['trigger_source_missing']==0
        atomic_write_json(paths.candidate_standard,std)
        os.environ['COINBOT_BASE_DIR']=str(base)
        spec=importlib.util.spec_from_file_location('main1203',HERE/'coinbot_main_v2_13_1137.py')
        mod=importlib.util.module_from_spec(spec); spec.loader.exec_module(mod)
        text=mod.render_candidate_standard(())
        for needle in ('[진입계약 핵심 · 같은 commit]','[경로별 S1 비교]','[현재 S1 상위 후보 · rank score 순]','후보·OPEN·cycle 개수 제한 없음'):
            assert needle in text,needle
        print('PASS v1203 candidate quality evidence')

if __name__=='__main__':
    main()
