v2137 후보입력 진실·오류퍼널
- Main·Paper만 변경
- Guard/worker 재시작 없음
- 같은 commit 전후 + writer expected=parsed 검증
- candidate 0 불일치를 FAIL로 표시
- 마지막 정상 cycle 보존
- 후보 전수 terminal accounting + 모든 reason 표시
- 수치·진입·청산·순위 비개입
- 자동매수 OFF
