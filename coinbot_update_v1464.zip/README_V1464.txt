coinbot_update_v1464
=====================

목적
- v1463에서 trigger_selector는 통과처럼 보이는데 candidate_flow는 여전히 Paper trigger 0을 읽는 문제를 단일화.
- Paper selector가 쓰는 paper_candidate_selection_single_owner_v1464.json 하나를 주인으로 지정.
- Main /candidate_flow, /trigger_selector, /s2_recheck, /protection_audit는 이 주인 파일만 읽음.
- v1457/v1461/v1462/v1463 누적 reader chain은 메인 판단에서 제외.

수정
- paper_bot.py / paper_bot_v1.443.py
  - VERSION paper_bot_v1.443
  - BUILD_LABEL v1464_single_source_owner_cleanup_2026-07-11
  - paper_candidate_selection_single_owner_v1464.json 작성
  - selector terminal accounting에서 S2_RECHECK/HARD_EXCLUDE/UNCLASSIFIED를 분류
  - PEAQ invalid거리 계산을 nested entry_price↔invalid_price 기준으로 보정

- bot.py / coinbot_main_v2_13_1464.py
  - BOT_VERSION 수익형 v2.13.1464
  - V650_BUILD_LABEL v1464_SINGLE_SOURCE_OWNER_CLEANUP_AUTOBUY_OFF_2026-07-11
  - /source_owner 추가
  - /candidate_flow를 v1464 단일 owner reader로 교체

불변
- 자동매수 OFF
- trigger 공식 변경 없음
- RR 기준 변경 없음
- target/invalid 변경 없음
- stale 강제통과 없음
- BUY_READY 강제 없음
- OPEN 강제 없음
- 청산계약 변경 없음
- 과거 OPEN/CLOSED 재계산 없음

검수
- python3 -m py_compile PASS
