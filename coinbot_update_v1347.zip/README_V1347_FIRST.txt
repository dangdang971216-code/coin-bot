v1347 fixes v1346 material overlay not running because it was registered after main(). No trading rule, entry, exit, RR, trigger, invalid, target, or autobuy changes.
